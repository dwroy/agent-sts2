# Roy已授权新功能：静默boss模拟校准定期刷新

本批只做独立授权的新功能校准刷新，不是bug-infra，不处理silent-0213或其他队列。方法/固定切分/准入标准来自Roy架构授权；样本、胜败、残差和准入结论来自已结束SILENT日志。

实际发布完成：source cf36dba65ac18c6bef58b3d90292851a5ba08c3c → live 8c7657bac63f42830854b069a7da894fb295ba62 → publication b155d00a36080418149e63d2f21b491d34d7f40a/tree 184868e76c9b64366dd75796475cda97cef6eb69。正式release_id和shipped交ops核实，学习者不代填。

356已结束局，1564次尝试，634可用首回合，461胜/173实败；929次SL截断和1次缺首回合排除，完整原因与局号保留。20新实际结局12胜8死，只扩固定验证507→527；成功验证各525，调参keys107/成功106。固定切点2026-10-06T02:46:11.648000，模型7e1193cef9467416bc10c8e344a49f4fd98390c7，200样本，seed=1+完整输入行号×101。两场控制逐值一致（仅忽略耗时），复用612场、重放22场，原6个no-solve行保留，无新增错误。

Platt B2={'a': 2.0844, 'b': 0.4502, 'c': 0.0}；B3={'a': 2.2754, 'b': 0.5047, 'c': 0.0}，与上一发布逐值相同；没有按验证集调参或增加进阶项。

| boss | n（B2/B3） | 数量缺口 | B2 Brier / 打穿比 / 失败 | B3 Brier / 打穿比 / 失败 |
|---|---|---|---|---|
| 永世沙漏 (AEONGLASS) | 38/38 | 0/0 | 0.2075/3.797/brier,gap,leak | 0.2186/3.889/brier,gap,leak |
| 仪式兽 (CEREMONIAL_BEAST) | 43/43 | 0/0 | 0.0593/1.169/达标 | 0.0515/1.185/达标 |
| 帝王蟹 (KAISER_CRAB) | 50/50 | 0/0 | 0.1624/1.329/brier,leak | 0.1818/1.352/brier,leak |
| 知识恶魔 (KNOWLEDGE_DEMON) | 48/48 | 0/0 | 0.1045/1.342/leak | 0.0922/1.383/leak |
| 乐加维林族母 (LAGAVULIN_MATRIARCH) | 47/47 | 0/0 | 0.0588/0.958/达标 | 0.0559/1.028/达标 |
| 女王 (QUEEN) | 34/34 | 0/0 | 0.2645/1.062/brier,gap | 0.2522/1.176/brier,gap |
| 灵魂异鱼 (SOUL_FYSH) | 40/40 | 0/0 | 0.0316/0.867/达标 | 0.0339/0.873/达标 |
| 实验体 (TEST_SUBJECT) | 31/31 | 0/0 | 0.1905/3.543/brier,leak | 0.1839/3.483/brier,leak |
| 无厌沙虫 (THE_INSATIABLE) | 51/51 | 0/0 | 0.1411/1.247/达标 | 0.1604/1.288/brier |
| 同族 (THE_KIN) | 46/46 | 0/0 | 0.105/1.181/达标 | 0.1146/1.151/达标 |
| 墨影幻灵 (VANTOM) | 56/56 | 0/0 | 0.0538/0.975/达标 | 0.0481/0.948/达标 |
| 瀑布巨兽 (WATERFALL_GIANT) | 41/41 | 0/0 | 0.1109/0.929/达标 | 0.1107/0.9/达标 |

准入一律用未取整值：验证≥10，Brier≤整体1.25倍，胜率差≤15个百分点，打穿比0.7–1.3；缺指标也不准入。B2可信7、B3可信6，无厌沙虫B2新增达标；B3仍因Brier失败。

A10独立验证525：B2/B3预测胜率76.1%/76.5%，实际72.0%，残差+4.1/+4.5个百分点，Brier0.1183/0.1200，整体打穿比1.314/1.333仍偏高，不能声称模型全面通过。A0–4和A5–9独立验证各0，仅有调参残差，不能外推该段可靠性。F49总实际结局34、验证32，数量缺口0；B2/B3 Brier0.202262/0.180740、胜率残差+32.2/+27.9个百分点、打穿比2.482/2.597，均继续低可信。F48胜利不等于F49或联合通关；本批没有新F49。A10固定DB伤害定义中仍有TEST_SUBJECT BIG_POUNCE由A9估值的1项，不补人写机制。

完整来源/SL排除/开场/回合/结果/切分/拟合/残差/质量表：/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/experiments/boss-sim/silent/da07348370065202d28758637df38f299ad22f74b8a2c112934a197fb564d404。主报告：paper/materials/silent/boss-sim-calibration.md。634开场均有开场前run-config，新增20场原runs.code均为current，补核14个实际配置提交身份，保留dirty_files、物理行/偏移/长度/SHA；不复原当时dirty字节。封存fingerprint=da07348370065202d28758637df38f299ad22f74b8a2c112934a197fb564d404；初始未补版本审计的原产物9dca20aed017c682663011996b888c5fc4396827b318a72d1c2cdbfe1b413d2d留scratch未覆盖。

本报告只验证冻结7e1193模型及本角色统计，不认证后来H0/H1生产模型、有限预算、自然采用或F48/F49联合概率；费用/药水/保血/目标/SL/终局规则不改，铁甲及其他角色数据不改。原主分支接续的历史记录/研究保留，不混作本批交付。

定期入口agent/tools/boss-sim/refresh-silent.py；trust.py --character silent；ops/learner_jobs.py:calibration_job每小时:13/:43和学习完成事件检查，升阶或20次新的实际结局触发，SL截断不计；旧切点/调参keys/模型不移动，只延伸验证。固定夹具16项通过，固定快照实际重复入口new0跳过、输出SHA不变，回执idempotence-final.json。

学习账本silent-0515，kind=fight、status=proposed，只经根目录ledger.py add/update写入；来源提交已CLI追加，不登记shipped。code_proposals=[]，implementation_domains=[]，本批未实现新策略域或新机制。

测试：Python固定16项和源端tsc/相关8项/paths11通过；脚本第二段重复相关8项，不虚计27个独立测试。原main完整1（490文件/4442项过，唯一15s超时）、同源原用例单项2.28s补验0及paths11过分别保留；两次过早中断130及判断勘误保留。实际live原sandbox入口完整0，日志SHA256 10a6b5bf41d30bc272f0a2a9bff2346d52d6213fbbd999934b387e8a9f0df30e，blocks={'files': ['492 passed (492)', '1 passed (1)'], 'tests': ['4453 passed (4453)', '11 passed (11)']}；真实production trust accessor24项读回0。两处Gitleaks标记经逐文件SHA证明为公开校验和；原误报/Unicode尝试保留，最终明文列排版解析等价，数据、参数和清单内所列SHA均不变；清单自身排版/字节SHA的变化另存manifest-aligned-checksums.json，原扫描0，无规则/阈值修改。完整外部检查交调度器，不借旧树结果。

唯一eval专题：S1.silent-boss-calibration-refresh-20261018-da073483；pending-primary-ops，正式号不由学习者猜测。源工作树干净，生产代码差异为空，实际live只窄合本批静默数据和记录，之前刷新已保存，其他源码/经验/角色保持；未做策略代码提案。根双通知已追加并读回，不代表下游确认。

最后一次额外报告/状态检查曾在沙箱构造阶段遇到其他学习者临时目录消失；原命令原权限一次重试0，未运行失败命令、未影响已通过的测试/实际发布，记录final-environment-note.json，不修其他队列。

```json
{
  "task": "fix-batch",
  "character": "silent",
  "task_nature": "Roy已授权新功能的定期校准刷新，非bug-infra",
  "base": "535254a8a063098342173c9b5b45ba9e53ad3de4",
  "fixes": [
    {
      "item": "Roy 已授权新功能：静默 boss 模拟校准",
      "commit": "cf36dba65ac18c6bef58b3d90292851a5ba08c3c",
      "source_parent": "9d9f5adb00766a6a3865c46b301bfd62c7ddd7da",
      "code_scope_diff_empty": true,
      "test": "源tsc/固定相关8项+paths11/Python16/幂等/原Gitleaks0；实际live完整sandbox0、production trust24读回0",
      "fails_without_fix": "固定覆盖消融：旧发布缺本批20个实际结局、验证507且无厌沙虫B2低；新发布验证527且其原四闸全部达标。不是伪造基础设施bug。",
      "ledger": [
        "silent-0515"
      ]
    }
  ],
  "skipped": [
    "A0–4/A5–9独立验证各0，不外推样本外可靠性。",
    "F49验证32/数量缺口0，质量三项失败，保持低可信；未验证F48/F49联合通关。",
    "原6个no-solve记录保留；当前H0/H1生产模型/有限预算/自然收益未由本冻结模型校准认证。"
  ],
  "merged": "8c7657bac63f42830854b069a7da894fb295ba62",
  "published_commit": "b155d00a36080418149e63d2f21b491d34d7f40a",
  "published_tree": "184868e76c9b64366dd75796475cda97cef6eb69",
  "tested_tree": "e63a1367b1aa7849edaeed6eb81a6aee32be3331",
  "version": {
    "eval_name": "S1.silent-boss-calibration-refresh-20261018-da073483",
    "release_id": null,
    "status": "pending-primary-ops-numbering"
  },
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "python": 0,
    "python_cases": 16,
    "source_selected_exit": 0,
    "source_unique_cases": 19,
    "live_blocks": {
      "files": [
        "492 passed (492)",
        "1 passed (1)"
      ],
      "tests": [
        "4453 passed (4453)",
        "11 passed (11)"
      ]
    },
    "consumer_checks": 24,
    "gitleaks": 0,
    "main_original_full": 1,
    "main_exact_supplement": 0,
    "main_interrupted": [
      130,
      130
    ],
    "external_full": "scheduler-pending",
    "live_log": "/home/dw/Projects/agent-sts2/learner/runs/20261018-083038-15a4e2b1-b8c5-4300-81af-b17a493e89f8-silent-boss-calibration/live-sandbox.log",
    "live_log_sha256": "10a6b5bf41d30bc272f0a2a9bff2346d52d6213fbbd999934b387e8a9f0df30e",
    "cases": 4464,
    "live_files": 493,
    "source_gitleaks_log": "/home/dw/Projects/agent-sts2/learner/runs/20261018-083038-15a4e2b1-b8c5-4300-81af-b17a493e89f8-silent-boss-calibration/source-gitleaks-aligned.log"
  },
  "boss_trust": [
    {
      "boss": "AEONGLASS",
      "name": "永世沙漏",
      "n_b2": 38,
      "n_b3": 38,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": false,
      "b3": false,
      "failed_b2": [
        "brier",
        "gap",
        "leak"
      ],
      "failed_b3": [
        "brier",
        "gap",
        "leak"
      ]
    },
    {
      "boss": "CEREMONIAL_BEAST",
      "name": "仪式兽",
      "n_b2": 43,
      "n_b3": 43,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": true,
      "failed_b2": [],
      "failed_b3": []
    },
    {
      "boss": "KAISER_CRAB",
      "name": "帝王蟹",
      "n_b2": 50,
      "n_b3": 50,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": false,
      "b3": false,
      "failed_b2": [
        "brier",
        "leak"
      ],
      "failed_b3": [
        "brier",
        "leak"
      ]
    },
    {
      "boss": "KNOWLEDGE_DEMON",
      "name": "知识恶魔",
      "n_b2": 48,
      "n_b3": 48,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": false,
      "b3": false,
      "failed_b2": [
        "leak"
      ],
      "failed_b3": [
        "leak"
      ]
    },
    {
      "boss": "LAGAVULIN_MATRIARCH",
      "name": "乐加维林族母",
      "n_b2": 47,
      "n_b3": 47,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": true,
      "failed_b2": [],
      "failed_b3": []
    },
    {
      "boss": "QUEEN",
      "name": "女王",
      "n_b2": 34,
      "n_b3": 34,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": false,
      "b3": false,
      "failed_b2": [
        "brier",
        "gap"
      ],
      "failed_b3": [
        "brier",
        "gap"
      ]
    },
    {
      "boss": "SOUL_FYSH",
      "name": "灵魂异鱼",
      "n_b2": 40,
      "n_b3": 40,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": true,
      "failed_b2": [],
      "failed_b3": []
    },
    {
      "boss": "TEST_SUBJECT",
      "name": "实验体",
      "n_b2": 31,
      "n_b3": 31,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": false,
      "b3": false,
      "failed_b2": [
        "brier",
        "leak"
      ],
      "failed_b3": [
        "brier",
        "leak"
      ]
    },
    {
      "boss": "THE_INSATIABLE",
      "name": "无厌沙虫",
      "n_b2": 51,
      "n_b3": 51,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": false,
      "failed_b2": [],
      "failed_b3": [
        "brier"
      ]
    },
    {
      "boss": "THE_KIN",
      "name": "同族",
      "n_b2": 46,
      "n_b3": 46,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": true,
      "failed_b2": [],
      "failed_b3": []
    },
    {
      "boss": "VANTOM",
      "name": "墨影幻灵",
      "n_b2": 56,
      "n_b3": 56,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": true,
      "failed_b2": [],
      "failed_b3": []
    },
    {
      "boss": "WATERFALL_GIANT",
      "name": "瀑布巨兽",
      "n_b2": 41,
      "n_b3": 41,
      "missing_b2": 0,
      "missing_b3": 0,
      "b2": true,
      "b3": true,
      "failed_b2": [],
      "failed_b3": []
    }
  ],
  "a10": {
    "t1": {
      "n": 525,
      "gap": 0.041000000000000036,
      "brier": 0.1183,
      "mean_pred": 0.761,
      "actual_win": 0.72,
      "leak_ratio": 1.314
    },
    "pre": {
      "n": 525,
      "gap": 0.04500000000000004,
      "brier": 0.12,
      "mean_pred": 0.765,
      "actual_win": 0.72,
      "leak_ratio": 1.333
    }
  },
  "refresh": {
    "entry": "agent/tools/boss-sim/refresh-silent.py",
    "trigger": "升阶或20个新增实际结局；每小时:13/:43和学习完成事件检查",
    "idempotence": "固定快照new0跳过，输出SHA不变",
    "artifact": "da07348370065202d28758637df38f299ad22f74b8a2c112934a197fb564d404",
    "model_commit": "7e1193cef9467416bc10c8e344a49f4fd98390c7",
    "frozen_cutoff": "2026-10-06T02:46:11.648000",
    "tune": 107,
    "validation_candidates": 527,
    "validation_successful": 525
  },
  "report": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/paper/materials/silent/boss-sim-calibration.md",
  "task_report": "/home/dw/Projects/agent-sts2/learner/runs/20261018-083038-15a4e2b1-b8c5-4300-81af-b17a493e89f8-silent-boss-calibration/report.md",
  "commits": {
    "local_main_sync_not_published": "e93b9a276b3d84f0bb54495445c2f53a9fa4c709",
    "source": "cf36dba65ac18c6bef58b3d90292851a5ba08c3c",
    "saved_live_refresh": "a66b9bb813fe6635cc9db8a7e423e00484a7f6d7",
    "actual_merge": "8c7657bac63f42830854b069a7da894fb295ba62",
    "publication": "b155d00a36080418149e63d2f21b491d34d7f40a"
  },
  "ledger": [
    "silent-0515"
  ],
  "code_proposals": [],
  "implementation_domains": [],
  "ledger_check_exit": 0,
  "notifications": "/home/dw/Projects/agent-sts2/learner/runs/20261018-083038-15a4e2b1-b8c5-4300-81af-b17a493e89f8-silent-boss-calibration/notification.json"
}
```

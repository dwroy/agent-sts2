import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { dirname, join } from 'node:path';

const root = process.argv[2];
const own = dirname(new URL(import.meta.url).pathname);
const data = JSON.parse(readFileSync(join(root, 'knowledge/characters/silent/boss-trust.json'), 'utf8'));
const expected = JSON.parse(readFileSync(join(own, 'sealed-artifact.json'), 'utf8'));
assert.equal(data.refresh.artifact, expected.artifact);
const files = await import(pathToFileURL(join(root, 'agent/src/knowledge/files.ts')).href);
files.setKnowledgeCharacter('silent');
const trust = await import(pathToFileURL(join(root, 'agent/src/sim/boss-trust.ts')).href);
assert.deepEqual(trust.silentBossCalibration('start'), data.overall.t1.platt);
assert.deepEqual(trust.silentBossCalibration('mid'), data.overall.t1.platt);
assert.deepEqual(trust.silentBossCalibration('pre'), data.overall.pre.platt);
const rows = [];
for (const key of trust.BOSS_KEYS) {
  for (const use of ['b2', 'b3']) {
    const admitted = data[`trusted_${use}`].includes(key);
    const reason = trust.bossTrustReason(key, use, 10, 48);
    assert.equal(reason === null, admitted);
    assert.ok(trust.bossTrustReason(key, use, 10, 49));
    assert.ok(trust.bossTrustReason(key, use, 11, 48));
    rows.push({ key, use, admitted, reason });
  }
}
writeFileSync(join(own, 'live-consumer.json'), JSON.stringify({
  character: files.knowledgeCharacter(), artifact: expected.artifact, checks: rows,
  scope: 'Actual production trust loader and B2/B3 accessors only; no simulation, LLM or natural-use claim.',
}, null, 2) + '\n');
console.log(JSON.stringify({ passed: true, consumer_checks: rows.length, artifact: expected.artifact }));

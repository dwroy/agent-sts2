"""Record the actual publication, append the authorized notices, and emit the completion report."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
WORK = ROOT / '.worktrees/silent-boss-calibration'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(LIVE), *args], text=True).strip()

def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

state = json.loads((OUT / 'publication.json').read_text())
source = json.loads((OUT / 'source-phase.json').read_text())
seal = json.loads((OUT / 'sealed-artifact.json').read_text())
data = json.loads((Path(seal['archive']) / 'boss-trust.json').read_text())
assert state['publication'] and state['live_sandbox_exit'] == 0 and state['consumer_exit'] == 0
assert git('rev-parse', state['publication'] + '^{tree}') == state['fixed_release_tree']
for commit in (source['source_commit'], state['merged'], state['publication']):
    subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', commit, 'HEAD'], check=True)
assert git('diff', '--name-only', state['merged'], state['publication'], '--', 'agent', 'learner', 'ops', 'knowledge') == ''
for path in source['owned_paths']:
    if path != 'paper/materials/decision-log.md':
        assert git('rev-parse', source['source_commit'] + ':' + path) == git('rev-parse', state['publication'] + ':' + path)

at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
current_report = (OUT / 'report.md').read_text()
current_report = current_report.replace('当前阶段：候选已封存；源码尚未提交，live尚未合入，不登记shipped。',
    f'实际发布完成：source {source["source_commit"]} → live {state["merged"]} → publication {state["publication"]}/tree {state["fixed_release_tree"]}。正式release_id和shipped由ops核实。')
(OUT / 'report.md').write_text(current_report)
notice = (f'\n- {at} Roy已授权新功能：静默boss模拟校准定期刷新已实际发布。'
    f'source {source["source_commit"]} → actual live {state["merged"]} → publication {state["publication"]}'
    f'/tree {state["fixed_release_tree"]}；eval专题 {state["version"]}，正式release_id由ops锁内核号，账本silent-0515保持proposed待ops核shipped。'
    '旧：固定验证507候选/505成功，B2可信6；无厌沙虫B2 n49、未取整Brier0.1463971657超过原整体1.25倍0.1463425997，保持低可信。'
    '新：仅20新实结局12胜8死延伸验证到527/成功525，B2/B3 Brier0.1183/0.1200，可信7/6；无厌沙虫B2 n51、Brier0.1411、打穿比1.247并同时过胜率差闸，自动进入B2名单；'
    'B3 Brier0.1604仍失败，不因数量达标准入。原107调参keys/UTC切点/7e1193模型/Platt/200样本/原行号seed/原四闸不变，费用/药水/保血/目标/SL/终局规则及其他角色不改。'
    '证据：356已结束SILENT局/1564尝试/634可用，929次SL截断不算实败，原6个no-solve行保留；634开场SHA/角色及开场前run-config物理偏移核同，新增14个配置提交身份。'
    f'完整来源/报告在experiments/boss-sim/silent/{seal["artifact"]}/及paper/materials/silent/boss-sim-calibration.md；任务报告{OUT}/report.md。'
    'A10残差+4.1/+4.5个百分点，整体打穿1.314/1.333仍偏高；F49验证32虽数量足但Brier/胜率差/打穿三项失败，低阶独立验证0；不认证当前H0/H1有限预算模型、自然收益或F48/F49联合通关，不关闭其他研究父要求。'
    '自测：源相关8项+paths11/Python16/tsc通过，固定快照幂等new0且SHA不变；实际live原sandbox入口完整0、实际production trust accessor24项读回0。'
    '原main完整1中的15s超时、精确单项2.28s补验0、两次中断及已核为公开SHA的扫描误报保留，不改写历史；最终原Gitleaks扫描0。'
    '预期仅允许既有B2流程按新名单消费，其他门槛继续生效，不声明通关收益。回退仅逆向本批trust/当前报告及对应版本别名，保所有指纹档案、保存的live刷新和其他并行源码/经验；行为回退另记统一发布号。'
    '本通知为本地双追加并读回，不代表watcher或Roy确认。\n')
records = []
for path in (ROOT / 'notes/for-roy.md', ROOT / 'ops/inbox-dev.md'):
    payload = notice.encode()
    with path.open('a+b') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        offset = handle.seek(0, os.SEEK_END)
        handle.write(payload); handle.flush(); os.fsync(handle.fileno())
        handle.seek(offset); assert handle.read(len(payload)) == payload
    records.append({'path': str(path), 'offset': offset, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
    save('notification.json', {'at': at, 'status': 'appended-and-read-back' if len(records) == 2 else 'partial',
                              'evidence': records, 'scope': 'Authorized local append readback, no recipient acknowledgement asserted.'})

change = {'id': 'silent-0515', 'by': 'learner:silent-boss-calibration',
    'where': {'commits': [source['source_commit']]},
    'note': f'已核实际live合入{state["merged"]}、发布{state["publication"]}/tree{state["fixed_release_tree"]}，'
    f'eval专题{state["version"]}已登记；实际组合原sandbox完整0和production trust24读回0。保留全部旧失败/中断/误报，'
    '未新增策略代码或更改阈值。根双通知实际追加读回；正式release_id/shipped及完整外部检查由ops/调度器核，不代填确认。'}
payload = json.dumps(change, ensure_ascii=False) + '\n'
(OUT / 'ledger-live-facts.json').write_text(payload)
updated = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], input=payload, text=True, capture_output=True)
(OUT / 'ledger-live-facts.stdout').write_text(updated.stdout)
(OUT / 'ledger-live-facts.stderr').write_text(updated.stderr)
assert updated.returncode == 0, updated.stderr
checked = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'check'], text=True, capture_output=True)
(OUT / 'ledger-check.log').write_text(checked.stdout + checked.stderr)

live_log = (OUT / 'live-sandbox.log').read_text()
blocks = {'files': re.findall(r'Test Files\s+([^\n]+)', live_log), 'tests': re.findall(r'\n\s+Tests\s+([^\n]+)', live_log)}
table = []
for key, boss in sorted(data['bosses'].items()):
    b2, b3 = boss['t1'], boss['pre']
    table.append({'boss': key, 'name': boss['name'], 'n_b2': b2['n'], 'n_b3': b3['n'],
        'missing_b2': b2['missing'], 'missing_b3': b3['missing'],
        'b2': not b2['failed'], 'b3': not b3['failed'], 'failed_b2': b2['failed'], 'failed_b3': b3['failed']})
result = {
    'task': 'fix-batch', 'character': 'silent', 'task_nature': 'Roy已授权新功能的定期校准刷新，非bug-infra',
    'base': source['initial_base'],
    'fixes': [{'item': 'Roy 已授权新功能：静默 boss 模拟校准', 'commit': source['source_commit'],
        'source_parent': source['source_parent'], 'code_scope_diff_empty': True,
        'test': '源tsc/固定相关8项+paths11/Python16/幂等/原Gitleaks0；实际live完整sandbox0、production trust24读回0',
        'fails_without_fix': '固定覆盖消融：旧发布缺本批20个实际结局、验证507且无厌沙虫B2低；新发布验证527且其原四闸全部达标。不是伪造基础设施bug。',
        'ledger': ['silent-0515']}],
    'skipped': ['A0–4/A5–9独立验证各0，不外推样本外可靠性。',
        'F49验证32/数量缺口0，质量三项失败，保持低可信；未验证F48/F49联合通关。',
        '原6个no-solve记录保留；当前H0/H1生产模型/有限预算/自然收益未由本冻结模型校准认证。'],
    'merged': state['merged'], 'published_commit': state['publication'], 'published_tree': state['fixed_release_tree'],
    'tested_tree': state['preflight_tree'],
    'version': {'eval_name': state['version'], 'release_id': None, 'status': 'pending-primary-ops-numbering'},
    'tests': {'tsc': 0, 'vitest': 0, 'python': 0, 'python_cases': 16, 'source_selected_exit': 0,
        'source_unique_cases': 19, 'live_blocks': blocks, 'consumer_checks': 24, 'gitleaks': 0,
        'main_original_full': 1, 'main_exact_supplement': 0, 'main_interrupted': [130, 130],
        'external_full': 'scheduler-pending', 'live_log': str(OUT / 'live-sandbox.log'), 'live_log_sha256': sha(OUT / 'live-sandbox.log')},
    'boss_trust': table,
    'a10': {k: data['residuals'][k]['val']['A10'] for k in ('t1', 'pre')},
    'refresh': {'entry': 'agent/tools/boss-sim/refresh-silent.py', 'trigger': '升阶或20个新增实际结局；每小时:13/:43和学习完成事件检查',
        'idempotence': '固定快照new0跳过，输出SHA不变', 'artifact': seal['artifact']},
    'report': str(WORK / 'paper/materials/silent/boss-sim-calibration.md'), 'task_report': str(OUT / 'report.md'),
    'commits': {'local_main_sync_not_published': source['main_sync_commit'], 'source': source['source_commit'],
        'saved_live_refresh': state.get('saved_refresh_commit'), 'actual_merge': state['merged'], 'publication': state['publication']},
    'ledger': ['silent-0515'], 'code_proposals': [], 'implementation_domains': [],
    'ledger_check_exit': checked.returncode,
    'notifications': str(OUT / 'notification.json')}
save('result.json', result)
body = (OUT / 'report-draft.md').read_text()
body = body.replace('当前阶段：候选已封存；源码尚未提交，live尚未合入，不登记shipped。',
    f'实际发布完成：source {source["source_commit"]} → live {state["merged"]} → publication {state["publication"]}/tree {state["fixed_release_tree"]}。正式release_id和shipped交ops核实，学习者不代填。')
body = body.replace('真实重复入口的幂等回执待源码阶段补齐', '固定快照实际重复入口new0跳过、输出SHA不变，回执idempotence-final.json')
body = body.replace('source提交待追加', '来源提交已CLI追加')
body = body.split('测试：Python固定夹具16项通过；')[0]
body += ('测试：Python固定16项和源端tsc/相关8项/paths11通过；脚本第二段重复相关8项，不虚计27个独立测试。'
    '原main完整1（490文件/4442项过，唯一15s超时）、同源原用例单项2.28s补验0及paths11过分别保留；两次过早中断130及判断勘误保留。'
    f'实际live原sandbox入口完整0，日志SHA256 {sha(OUT / "live-sandbox.log")}，blocks={blocks}；真实production trust accessor24项读回0。'
    '两处Gitleaks标记经逐文件SHA证明为公开校验和；原误报/Unicode尝试保留，最终明文列排版解析等价，所有数据/参数/哈希不变，原扫描0，无规则/阈值修改。'
    '完整外部检查交调度器，不借旧树结果。\n\n'
    f'唯一eval专题：{state["version"]}；pending-primary-ops，正式号不由学习者猜测。源工作树干净，生产代码差异为空，'
    '实际live只窄合本批静默数据和记录，之前刷新已保存，其他源码/经验/角色保持；未做策略代码提案。'
    '根双通知已追加并读回，不代表下游确认。\n\n```json\n' + json.dumps(result, ensure_ascii=False, indent=2) + '\n```\n')
(OUT / 'report.md').write_text(body)
print(json.dumps({k: result[k] for k in ('merged', 'published_commit', 'published_tree', 'version', 'ledger')}, ensure_ascii=False))

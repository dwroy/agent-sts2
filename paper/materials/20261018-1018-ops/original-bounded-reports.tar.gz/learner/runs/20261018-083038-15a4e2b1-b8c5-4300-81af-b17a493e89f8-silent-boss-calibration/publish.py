"""Publish only the owned calibration delta; preserve other live code and refreshes."""
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/silent-boss-calibration'
LIVE = ROOT / '.worktrees/live'
BASE, SOURCE = sys.argv[1:3]
ENV = {**os.environ, 'PATH': str(Path.home() / '.local/node/bin') + ':' + os.environ['PATH'],
       'TMPDIR': str(OUT), 'SANDBOX_WORKERS': '2'}
ENV.pop('GIT_INDEX_FILE', None)
COAUTHOR = '\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
state = {'source': SOURCE, 'source_parent': BASE, 'merged': None, 'publication': None, 'release_id': None}

def run(args, cwd=LIVE, env=ENV, check=True, data=None):
    result = subprocess.run(args, cwd=cwd, env=env, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and result.returncode:
        raise RuntimeError(str(args[:5]) + ': ' + result.stderr.decode(errors='replace')[-1800:])
    return result

def git(*args, cwd=LIVE, env=ENV):
    return run(['git', '-c', 'core.hooksPath=/dev/null', *args], cwd, env).stdout.decode().strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def persist():
    (OUT / 'publication.json').write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n')

def blob(ref, path, cwd=LIVE):
    result = run(['git', 'show', ref + ':' + path], cwd=cwd, check=False)
    return result.stdout if result.returncode == 0 else None

def commit(message, label):
    scan = run(['nice', '-n', '19', 'gitleaks', 'git', '--pre-commit', '--staged', '--redact', '--no-banner'], check=False)
    (OUT / (label + '-gitleaks.log')).write_bytes(scan.stdout + scan.stderr)
    assert scan.returncode == 0, label + ' gitleaks failed'
    git('commit', '-m', message + COAUTHOR)
    return git('rev-parse', 'HEAD')

artifact = json.loads((OUT / 'sealed-artifact.json').read_text())['artifact']
paths = git('diff', '--name-only', BASE, SOURCE, cwd=WORK).splitlines()
allowed = lambda p: p in ('knowledge/characters/silent/boss-trust.json', 'paper/materials/silent/boss-sim-calibration.md',
    'paper/materials/decision-log.md') or p.startswith('experiments/boss-sim/silent/' + artifact + '/')
assert paths and all(allowed(p) for p in paths), paths
state['owned_paths'] = paths
assert git('status', '--porcelain', cwd=WORK) == ''
lock = (ROOT / 'ops/live-merge.lock').open('a')
deadline = time.monotonic() + 1800
while True:
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        break
    except BlockingIOError:
        assert time.monotonic() < deadline, 'live merge lock stayed busy; no live changes'
        print('Waiting for existing live merge lock; live untouched.', flush=True)
        time.sleep(30)
before = None
version_before = None
version_written = None
try:
    state['initial_live'] = git('rev-parse', 'HEAD')
    assert run(['git', 'rev-parse', '--verify', 'MERGE_HEAD'], check=False).returncode != 0
    assert run(['git', 'diff', '--cached', '--quiet'], check=False).returncode == 0, 'Unowned live index is active'
    def signatures():
        try:
            return {str(p.relative_to(LIVE)): (p.stat().st_size, p.stat().st_mtime_ns)
                    for d in (LIVE / 'knowledge/common', LIVE / 'knowledge/characters/silent')
                    for p in d.rglob('*.json') if p.is_file()}
        except FileNotFoundError:
            return None
    while True:
        assert time.monotonic() < deadline, 'Refresh did not settle; live unchanged'
        first = signatures()
        runs = [json.loads(line) for line in (ROOT / 'logs/runs.jsonl').open() if line.strip()]
        latest = max(dt.datetime.fromisoformat(r['ended'].replace('Z', '+00:00')).timestamp()
                     for r in runs if r.get('character') == 'SILENT' and r.get('ended'))
        final = LIVE / 'notes/fight-value-backtest-silent.md'
        if first is None or not final.exists() or final.stat().st_mtime < latest or time.time() - final.stat().st_mtime < 60:
            print('Waiting for final Silent refresh output.', flush=True)
            time.sleep(15)
            continue
        print('Checking a stable 30 second knowledge window.', flush=True)
        time.sleep(30)
        if first == signatures():
            state['refresh_check'] = {'stable_seconds': 30, 'latest_ended_epoch': latest,
                'final_note_mtime': final.stat().st_mtime, 'host_process_exit_claimed': False}
            break
    status = run(['git', 'status', '--porcelain', '--untracked-files=all']).stdout.decode().rstrip('\n')
    (OUT / 'live-status-before.txt').write_text(status + '\n')
    dirty = [line[3:] for line in status.splitlines()]
    assert not any(p.startswith(('agent/', 'learner/', 'eval/', 'ops/')) and p.endswith(('.ts', '.py', '.js', '.mjs')) for p in dirty)
    assert not set(dirty) & (set(paths) | {'eval/versions.json'}), 'Uncommitted parallel records overlap owned publication paths'
    refresh = [p for p in dirty if ((p.startswith('knowledge/common/') or p.startswith('knowledge/characters/silent/'))
        and p.endswith('.json')) or p in ('notes/fight-value-backtest-silent.md', 'notes/monster-db-check.md')]
    assert not set(refresh) & set(paths), 'Uncommitted refresh overlaps owned data'
    state['refresh_files'] = {p: sha(LIVE / p) for p in refresh}
    if refresh:
        for p in refresh:
            if p.endswith('.json'):
                json.loads((LIVE / p).read_text())
        git('add', '--sparse', '--', *refresh)
        state['saved_refresh_commit'] = commit('Preserve live knowledge before Silent calibration refresh', 'save-refresh')
    before = git('rev-parse', 'HEAD')
    state['before_merge'] = before
    assert sha(LIVE / 'knowledge/characters/silent/boss-trust.json') == sha(OUT / 'published-trust-before.json'), 'Published calibration advanced'
    index_env = {**ENV, 'GIT_INDEX_FILE': str(OUT / 'live-preflight.index')}
    git('read-tree', 'HEAD', env=index_env)
    for path in paths:
        old, ours, current = blob(BASE, path, cwd=WORK), blob(SOURCE, path, cwd=WORK), blob(before, path)
        assert ours is not None
        if path == 'paper/materials/decision-log.md':
            assert ours.startswith(old), 'Source log must be append-only'
            merged = current + ours[len(old):]
        else:
            assert current == old or current == ours or old is None and current is None, 'Overlapping live path: ' + path
            merged = ours
        stored = run(['git', 'hash-object', '-w', '--stdin'], data=merged).stdout.decode().strip()
        mode = git('ls-tree', SOURCE, '--', path, cwd=WORK).split()[0]
        git('update-index', '--add', '--cacheinfo', mode + ',' + stored + ',' + path, env=index_env)
    state['preflight_tree'] = git('write-tree', env=index_env)
    changed = git('diff', '--name-only', before, state['preflight_tree']).splitlines()
    assert set(changed) <= set(paths)
    assert not git('diff', '--name-only', before, state['preflight_tree'], '--', 'agent', 'learner', 'ops', 'eval', 'knowledge/common', 'knowledge/characters/ironclad')
    (OUT / 'owned-live-diff.patch').write_bytes(run(['git', 'diff', '--binary', before, state['preflight_tree']]).stdout)
    state['integration_scope'] = 'Narrow tree merge of owned calibration leaves; all unrelated branch history excluded from the resulting live delta.'
    persist()
    git('merge', '--no-ff', '--no-commit', '-s', 'ours', SOURCE)
    git('read-tree', state['preflight_tree'])
    git('restore', '--source', state['preflight_tree'], '--worktree', '--ignore-skip-worktree-bits', '--', *paths)
    state['merged'] = commit('Refresh Silent boss validation with 20 new observed outcomes', 'live-merge')
    assert git('rev-parse', 'HEAD^{tree}') == state['preflight_tree']
    persist()
    with (OUT / 'live-sandbox.log').open('wb') as log:
        checked = subprocess.run(['nice', '-n', '19', 'bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', env=ENV,
                                 stdout=log, stderr=subprocess.STDOUT)
    state['live_sandbox_exit'] = checked.returncode
    (OUT / 'live-sandbox.exit').write_text(str(checked.returncode) + '\n')
    persist()
    assert checked.returncode == 0, 'Actual live sandbox failed; original log retained'
    with (OUT / 'live-consumer.log').open('wb') as log:
        checked = subprocess.run(['nice', '-n', '19', 'node', '--import', 'tsx', str(OUT / 'consumer.mjs'), str(LIVE)],
            cwd=LIVE / 'agent', env={**ENV, 'CHARACTER': 'silent'}, stdout=log, stderr=subprocess.STDOUT)
    state['consumer_exit'] = checked.returncode
    assert checked.returncode == 0, 'Actual live consumer failed'
    data = json.loads((LIVE / 'knowledge/characters/silent/boss-trust.json').read_text())
    assert data['refresh']['artifact'] == artifact
    at = run(['date', '+%Y-%m-%d %H:%M:%S %Z']).stdout.decode().strip()
    state['version'] = 'S1.silent-boss-calibration-refresh-20261018-' + artifact[:8]
    versions_path = LIVE / 'eval/versions.json'
    version_before = versions_path.read_bytes()
    versions = json.loads(versions_path.read_text())
    assert not any(v['name'] == state['version'] for v in versions['versions'])
    versions['versions'].append({'name': state['version'], 'family': 'V5', 'character': 'SILENT',
        'commit': state['merged'], 'release_status': 'pending-primary-ops',
        'source': at + '; Roy-authorized new-feature calibration refresh; source ' + SOURCE + '; fixed 107 tuning keys and cutoff, '
        '20 new actual outcomes extend validation507->527, frozen 7e1193 model/Platt/seeds/original gates unchanged. '
        'Per-boss quality, A10/F49 and run-config physical provenance in artifact ' + artifact + '. '
        'Source and actual combined sandbox and actual trust consumer passed. Official release_id/shipped by ops.'})
    versions_path.write_text(json.dumps(versions, ensure_ascii=False, indent=2) + '\n')
    version_written = versions_path.read_bytes()
    with (LIVE / 'paper/materials/decision-log.md').open('a') as handle:
        handle.write(f'\n- {at} Roy已授权新功能：静默boss模拟校准定期刷新；source {SOURCE} → actual live {state["merged"]}，'
            f'{state["version"]}，artifact {artifact}；356完局/1564尝试/634可用，20新实结局12胜8死，仅验证507→527；'
            '107调参keys/切点/7e1193模型/Platt/200样本/原四闸保持。逐boss质量和A10/F49见专报，run-config版本逐偏移补核；'
            '源码与实际组合sandbox0、实际静默trust消费0。仅本批数据及报告窄合，保其他代码/经验/刷新；'
            '未验证当前H0/H1生产模型、自然收益或联合通关，不改费用/药水/保血/目标/SL阈值。正式号和shipped交ops。\n')
    git('add', '--sparse', '--', 'eval/versions.json', 'paper/materials/decision-log.md')
    state['publication'] = commit('Record Silent boss calibration refresh publication', 'publication')
    state['fixed_release_tree'] = git('rev-parse', 'HEAD^{tree}')
    assert run(['git', 'merge-base', '--is-ancestor', SOURCE, 'HEAD']).returncode == 0
    assert not git('diff', '--name-only', state['merged'], 'HEAD', '--', 'agent', 'learner', 'ops', 'knowledge')
    state['release_id_status'] = 'Pending actual ops allocation; no borrowed number or learner shipped claim.'
    persist()
    print(json.dumps(state, ensure_ascii=False), flush=True)
except BaseException as error:
    (OUT / 'failed-live-diff.patch').write_bytes(run(['git', 'diff', '--binary', 'HEAD'], check=False).stdout)
    if run(['git', 'rev-parse', '--verify', 'MERGE_HEAD'], check=False).returncode == 0:
        git('merge', '--abort')
    if state['merged'] and not state['publication'] and git('rev-parse', 'HEAD') == state['merged']:
        git('update-ref', 'refs/learner-preserved/silent-calibration-failed-' + state['merged'][:12], state['merged'])
        git('reset', '--mixed', before)
        for path in paths:
            if blob(before, path) is not None:
                git('restore', '--source', before, '--staged', '--worktree', '--ignore-skip-worktree-bits', '--', path)
            elif (LIVE / path).exists() and (LIVE / path).read_bytes() == blob(SOURCE, path, cwd=WORK):
                (LIVE / path).unlink()
        state['rolled_back_commit'] = state['merged']
        state['merged'] = None
        if version_written is not None:
            if (LIVE / 'eval/versions.json').read_bytes() == version_written:
                (LIVE / 'eval/versions.json').write_bytes(version_before)
            else:
                state['version_rollback_overlap'] = 'Parallel version edits retained; ops must remove only this unpublished alias.'
    state['error'] = str(error)
    persist()
    raise

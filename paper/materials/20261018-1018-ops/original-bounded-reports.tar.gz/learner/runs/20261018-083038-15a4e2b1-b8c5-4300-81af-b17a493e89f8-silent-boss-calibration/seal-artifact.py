"""Seal this batch's supplemental log provenance without changing fitted parameters."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

WORK = Path('/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK / 'agent/tools/boss-sim'))
from silent_calibration import render

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=1) + '\n')

receipt = json.loads((OUT / 'refresh.log').read_text().splitlines()[-1])
original = Path(receipt['archive'])
data = json.loads((original / 'boss-trust.json').read_text())
previous = json.loads((OUT / 'published-trust-before.json').read_text())
assert data['split']['tune'] == previous['split']['tune']
assert data['split']['cutoff_ts'] == previous['split']['cutoff_ts']
for start in ('t1', 'pre'):
    assert data['overall'][start]['platt'] == previous['overall'][start]['platt']
    assert data['selection'][start] == previous['selection'][start]
provenance = json.loads((original / 'provenance.json').read_text())
provenance['runtime_source_audit_sha256'] = sha(OUT / 'runtime-source-audit.json')
provenance['runtime_source_audit_scope'] = ('634 actual-outcome openings; latest logged run-config at or before each opening, '
    'physical byte offsets and SHA256; original runs.code fields preserved. Dirty working bytes and later transitions are not reconstructed.')
identity = hashlib.sha256(json.dumps({'source': provenance, 'split': data['split']}, sort_keys=True).encode()).hexdigest()
archive = OUT / identity
archive.mkdir(exist_ok=False)
for path in original.iterdir():
    if path.is_file() and path.name not in ('completed.json', 'provenance.json', 'boss-trust.json', 'report.md'):
        shutil.copyfile(path, archive / path.name)
shutil.copyfile(OUT / 'runtime-source-audit.json', archive / 'runtime-source-audit.json')
data['source'] = provenance
data['refresh']['artifact'] = identity
write(archive / 'provenance.json', provenance)
write(archive / 'boss-trust.json', data)
sources = [json.loads(line) for line in (archive / 'sources.jsonl').read_text().splitlines()]
extraction = json.loads((archive / 'extraction.json').read_text())
report = render(data, sources, extraction)
audit = json.loads((OUT / 'runtime-source-audit.json').read_text())
new = {r['key'] for r in json.loads((OUT / 'dataset-audit.json').read_text())['added']}
report += ('\n## 本批运行版本来源审计\n\n'
    '原提取的 runs.code=current 保留；逐开场再核日志 run-config 的已记录源码身份。634 个开场均有开场之前的配置，'
    '完整局号、时间、源码/dirty_files、物理行/偏移/长度和 SHA256 见同指纹 runtime-source-audit.json。'
    '以下为新增20场；配置中有 dirty 时不复原当时未提交字节，也不把它视为纯提交树认证。固定模拟对象仍是原7e1193，'
    '本次不验证后来 H0/H1 的生产模型、部分预算、自然采用或 F48/F49 联合通关。\n\n'
    '| 开场key | run-config源码 | 配置时间 |\n|---|---|---|\n')
for row in audit['rows']:
    if row['key'] in new:
        config = row['latest_config_before_opening']
        code = config['code']
        report += f"| {row['key']} | {code['commit']}{'+dirty' if code.get('dirty') else ''} | {config['ts']} |\n"
(archive / 'report.md').write_text(report)
write(archive / 'completed.json', {
    'artifact': identity, 'trust_sha256': sha(archive / 'boss-trust.json'), 'report_sha256': sha(archive / 'report.md'),
    'files_sha256': {p.name: sha(p) for p in archive.iterdir() if p.is_file() and p.name != 'completed.json'},
    'sealed_from': receipt['artifact'], 'scope': 'Supplemental physical log provenance only; model, split, Platt, selection and results unchanged.'})
destination = WORK / 'experiments/boss-sim/silent' / identity
destination.mkdir(exist_ok=False)
for path in archive.iterdir():
    shutil.copyfile(path, destination / path.name)
shutil.copyfile(archive / 'boss-trust.json', WORK / 'knowledge/characters/silent/boss-trust.json')
shutil.copyfile(archive / 'report.md', WORK / 'paper/materials/silent/boss-sim-calibration.md')
write(OUT / 'sealed-artifact.json', {'artifact': identity, 'archive': str(archive), 'repository': str(destination),
    'original_refresh_artifact': receipt['artifact'], 'unchanged_model_split_parameters': True})
print(json.dumps({'artifact': identity, 'files': len(list(archive.iterdir())), 'trusted_b2': data['trusted_b2'], 'trusted_b3': data['trusted_b3']}))

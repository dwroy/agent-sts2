# 策略队列批次回报

记录时间：2026-10-17 09:28:42 CST。batch=20261017-091302-strategy-proposal，character=silent。

已逐项处理十个派发ID，全部waiting，具体理由、证据局号/层/回合、既有账本ID、反例与验证计划见[proposal.md](proposal.md)及[proposal-results.json](proposal-results.json)。本批没有找到足以完成剩余范围的新可隔离策略改动；未改源码/知识，fixes=[]，merged=null，无新提交/版本，不冒称implemented或shipped。

## 身份与基线

- 工作树：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-091302。
- base/HEAD：1fcbbfa59ac00e9bf04552d376ba693969f54e9f，普通任务已执行git merge --no-edit main且无需更新。
- learn.json只读本批，reason=proposal、十ID和工作树绑定通过。无专题/implementation绑定，不读取其他请求替代身份，不领取其他ID。
- 派发锚点仅原十局；补充UJ0与9Y只因原提案引用，不能冒称新增两局独立支持。10G A3、1LM A4、9YT A7，其余锚点A10；补充UJ0 A10、9Y A4，不混阶拟合。
- 历史runs.code为dirty记录，当前源码不能复原其完整运行树；历史脑引擎记录原样保留，不倒写为纯Codex。当前工具未提供实际原生会话/请求模型、推理强度和计费档的独立读回，不冒称已核。

## 原证据及局部核验

共用extract_evidence.py提取：states8295、decisions7971、sl-attempts67、run-config12、run-plans60、brain385、runs12、fight-plans0，共16802行。选中封套内容及其原日志字节全部核过，源截点分别保存在evidence-manifest.json。全源扫描states/decisions/brain各有2条无效JSON，未把它们归到某局，也不据此补缺帧或断言缺日志；各流不完整末行均0。未做旧截点复核，不覆盖旧报告或0行初稿。

固定材料27项全部通过，见material-checks.json；不是生产测试：

- F27T2铁心：d286123，s292788→292789，挡0→0、覆甲0→7。原c64“16挡”只作为已纠正旧稿保存，9c3更正稿SHA独立核对。
- K2 F46T1：零毒升级蜃景1能、16挡不变；T6普通版8毒+2敏实际10挡。现有零毒源码子项已live，不重做。
- 79 F14T6/T10净血价32/11；T11三感染时2血7挡，饮毒使目标4→10毒而8HP不变，随后先死且毒未结，不能把毒足当实赢。
- 七局107次单弃按真实选择帧和后帧复算：100次敌HP+挡合减3、7次减1；分局18/19/27/9/13/2/19。保留全部敌状态，滑溜同现不是已隔离因果；没有把合计差额当随机分配定律。
- ZTRG F11T1刀扇8手→10、建1层、添3刀，当前是单敌场景；不由此外推全部多敌后继。
- 三处HP guard实际位于rationale：d285301、285405、285745。同题候选血价/扣血25/26→20/18、15/12→12/3、2/7→0/0，保留推演文本与SL尝试，不累加成整战因果。

同局尝试不作为独立训练/验证局，不拟合HP安全线、药水持有价/时点、出牌权重、SL必死阈值、固定目标序或尾端估计参数。

## 已有消费者与源码

三局从本批冻结封套生成输入并实际运行既有learner/audit-selection.ts，均exit0；三份resource_chain也由同版本函数在相同冻结状态上实际计算，调用与输出保存在scratch，不重扫角色全史、不调用模型/游戏/网络：

|局号|有ID动作|候选段|可核整轮端点|整轮未知|
|---|---:|---:|---:|---:|
|ZTRGYYMLR8SC|594|130|69|39|
|K2JAGKVJAWZJ|720|138|25|97|
|79UCJ0K6R9C1|235|78|0|42|

346候选段的actual_full_candidate_result及actual_rollout_best均null。这是消费者设计保留未知，并不等于实盘没有执行。观察区间有526个端点/1023未知；79旧尝试字段缺失使严格消费者不能连接，原帧的局部实值仍可单独核对。K2的d285853/285888两条无decision_id元数据明确排除、保留原offset/SHA，不伪造ID。94个整轮端点不等于94个完整候选或独立样本。

资源链保留全部赢战及截断尝试：ZTRG同族六次均68与原两瓶、前五缺退出；K2蟹第一试62→10后SL，第二次62→28胜且留原瓶；79 F8/F12/F14实际净血价40/19/51。净损不等完整敌伤，恢复不等回血，未走路线不填实际结果。

source-readback.json冻结23个当前源码/固定夹具叶及8个实际base/live祖先；核对时live=99737be9fdb9c2ea92089d768947c49b49b62382。其中route来源7c43bbbb、零毒蜃景5e0f8845、普通蜃景cf0f2495、持有伤害0fbd5bc3、蟹当步事实154c9542、离线工具a32050fb、钨棍4367250b、臂甲ec1ceef3均实祖先。23叶中两叶与live只差原Roy/Dai注释署名，其余字节相同，精确差分另存live-source-differences.patch；这不是整个历史dirty树等价声明。窄祖先不能关闭本批宽提案。

## 验证、变更与交接边界

生产tsc=null、vitest=null、cases=null；没有源码提交，因此没有撤源码失败/恢复通过、整套沙箱或合后测试，不伪造绿灯。材料核验27通过、三份TypeScript离线消费exit0另列，未运行生产求解/整战模拟，不声称策略收益或自然采用。

无新代码提案，code_proposals沿用本批十个已由CLI登记的原ID；implementation_domains=[]表示本批没有实现域改动。已通过根ledger.py update成功追加20个原账本条目的本批proposal/report追溯与waiting理由，只加where/note。22,369,315字节旧前缀SHA保持，claim/首证/prior/evidence/status/version/shipped等保护字段逐项相同，没有新增支持次数。追加行的offset/bytes/SHA与CLI读回见ledger-update-receipt.json。

未合入live，无源提交需ops兜底，无eval版本或规则双通知；不用报告结束冒称经验实际入库或消费者自然采用。十项等待proposal-results.json所列具体数据。proposal交运维路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-091302/learner/runs/20261017-091309-04fdb029-22e6-4e28-99a4-5f8457cb4c6c-strategy-proposal/proposal.md。

## 限制与保留

旧数据没有完整反事实；K2首试末轮被SL截断、T7额外2损伤未隔离，同类虫实体与新增血池不能按敌index连续当同一实体。K2首29抽是原提案结论，本轮仅独立核同入口/瓶及T3/T4手牌，不扩大成重新验证全部29抽。现有经验文字中的后续多弃/多敌样本不作本批原帧，未追加未派发局。

工具偏差见tooling-deviations.json：首次沙箱启动glob竞态未执行提取、几个只读路径拼写、路线夹具列表误按对象读取、首次只查hp_guard字段漏掉rationale、消费者无status字段的初版计数，均是工具/研究脚本问题；相关初稿保留，不当游戏反例、日志缺失或生产失败。修正后的材料与消费者结果使用真实字段。最初自写账本简化折叠亦保留initial，正式读回改用原ledger.fold；从未据简化副本修改根账本。

原始日志只读，全部临时材料在本批scratch；不删除旧材料/失败记录，不修改请求、派发状态、原提案、其他角色知识、账号/环境、运维prompt或历史记录。

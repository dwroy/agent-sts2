"""Verify frozen evidence and prepare character-scoped offline consumer inputs."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
WT = OUT.parents[2]
PRIMARY = ['ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1']


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def citation(item):
    return {key: item[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def summarize(item):
    state = item['row']['state']
    combat, run = state.get('combat') or {}, state.get('run') or {}
    player = combat.get('player') or {}
    return {'source': citation(item), 'ts': item['row'].get('ts'),
            'observed_ts': item['row'].get('observed_ts'), 'screen': state.get('screen'),
            'floor': run.get('floor'), 'turn': state.get('turn'),
            'hp': player.get('current_hp', run.get('current_hp')),
            'max_hp': player.get('max_hp', run.get('max_hp')),
            'block': player.get('block'), 'energy': player.get('energy'),
            'powers': player.get('powers'), 'potions': run.get('potions'),
            'relics': run.get('relics'),
            'hand': combat.get('hand'), 'enemies': combat.get('enemies')}


def main():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    identities = json.loads((OUT / 'runs-identity.json').read_text())
    source_spec = importlib.util.spec_from_file_location('frozen_extract', WT / 'learner/extract_evidence.py')
    extractor = importlib.util.module_from_spec(source_spec)
    source_spec.loader.exec_module(extractor)
    all_streams, verified = {}, []
    for entry in manifest:
        stream = entry['stream']
        path = OUT / 'evidence' / (stream + '.evidence.jsonl')
        digest, counts, items = hashlib.sha256(), collections.Counter(), []
        source = Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')
        with source.open('rb') as original, path.open('rb') as selected:
            for encoded in selected:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['source'] == str(source)
                assert item['offset'] + item['bytes'] <= entry['source_size']
                original.seek(item['offset'])
                raw = original.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                run = extractor.run_identity(item['row'])
                assert run == item['run_id'] and run in identities
                if stream == 'states':
                    assert item['row']['state']['run']['character_id'].lower() == 'silent'
                    assert item['row']['state']['run'].get('ascension') == identities[run][0]['ascension']
                counts[run] += 1
                items.append(item)
        assert digest.hexdigest() == entry['output_sha256']
        assert all(counts[run] == count for run, count in entry['counts'].items())
        verified.append({'stream': stream, 'source_size': entry['source_size'],
                         'selected': sum(counts.values()), 'counts': dict(counts),
                         'output_sha256': digest.hexdigest(), 'all_original_bytes_verified': True})
        all_streams[stream] = items
    save('evidence-validation.json', {'streams': verified, 'total': sum(x['selected'] for x in verified)})

    by_line = {x['line']: x for x in all_streams['states']}
    requested = [291892, 292343, 292344, 292345, 292346, 292347, 292348, 292349,
                 292398, 292399, 292400, 292401, 292402,
                 292940, 292941, 292942, 293158, 293159, 293196, 293197,
                 293442, 293443, 293460, 293461, 293462, 293463, 293464, 293465]
    selected_facts = [summarize(by_line[line]) for line in requested if line in by_line]
    save('cited-frames.json', selected_facts)
    save('missing-requested-lines.json', [line for line in requested if line not in by_line])

    # Keep raw source positions when a consumer requires adjacent original rows.
    consumers, exclusions = [], []
    for run in PRIMARY:
        decisions, states = [], []
        for item in all_streams['decisions']:
            if item['run_id'] != run:
                continue
            row = item['row']
            if not row.get('decision_id') or row.get('run_id') != run:
                exclusions.append({'source': citation(item), 'reason': '缺少唯一decision_id或顶层局身份；不伪造历史字段'})
                continue
            decisions.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
        for item in all_streams['states']:
            if item['run_id'] == run:
                states.append({**item['row'], '_line': item['line'], '_source_sha256': item['sha256']})
        decisions.sort(key=lambda row: (row.get('observed_ts') or '', row['_line']))
        path = run + '.selection-input.json'
        save(path, {'run': identities[run][0], 'decisions': decisions, 'states': states})
        consumers.append({'run': run, 'input': path, 'decisions': len(decisions), 'states': len(states)})
    save('selection-input-manifest.json', {'consumers': consumers, 'excluded_metadata': exclusions})

    resource_spec = importlib.util.spec_from_file_location('frozen_resource', WT / 'learner/resource_chain.py')
    resource = importlib.util.module_from_spec(resource_spec)
    resource_spec.loader.exec_module(resource)
    resources = []
    for run in PRIMARY:
        events = [x['row'] for x in all_streams['sl-attempts'] if x['run_id'] == run]
        starts = collections.defaultdict(list)
        for row in events:
            if row.get('attempt', 1) > 1 and row.get('started_at'):
                starts[row.get('floor')].append(row['started_at'])
        rows = [{**x['row'], '_line': x['line']} for x in all_streams['states'] if x['run_id'] == run]
        result = resource.resource_chain(rows, run, 'silent', starts)
        result['sl_events'] = [{k: row.get(k) for k in ('floor', 'attempt', 'started_at', 'ended_at', 'result')} for row in events]
        save(run + '.resources.json', result)
        resources.append({'run': run, 'combats': [{
            'sequence': x['sequence'], 'floor': x['floor'], 'entry': x['entry'],
            'last': x['last'], 'exit': x['exit'], 'end': x['end'],
            'net_hp_loss': x['observed_net_hp_loss']} for x in result['combats']],
            'sl_events': result['sl_events']})
    save('resource-summary.json', resources)

    # Inspect potion requests with their unique pre-observation and immediate next source state.
    timeline = []
    for run in PRIMARY:
        states = [x for x in all_streams['states'] if x['run_id'] == run]
        observed = collections.defaultdict(list)
        for at, item in enumerate(states):
            observed[item['row'].get('observed_ts')].append(at)
        for item in all_streams['decisions']:
            row = item['row']
            if item['run_id'] != run or (row.get('chosen') or {}).get('action') not in ('use_potion', 'discard_potion'):
                continue
            matches = observed.get(row.get('observed_ts'), [])
            same = [at for at in matches if states[at]['row'].get('fingerprint') == row.get('fingerprint')]
            at = same[0] if len(same) == 1 else None
            timeline.append({'source': citation(item), 'floor': row.get('floor'), 'turn': row.get('turn'),
                             'attempt': row.get('sl_attempt'), 'chosen': row.get('chosen'),
                             'expect': row.get('expect'), 'result': row.get('result'),
                             'before': summarize(states[at]) if at is not None else None,
                             'next_source_state': summarize(states[at + 1]) if at is not None and at + 1 < len(states) else None,
                             'causal_attribution': None})
    save('potion-request-observations.json', timeline)
    print(json.dumps({'verified_lines': sum(x['selected'] for x in verified), 'streams': len(verified),
                      'consumer_inputs': consumers, 'excluded_metadata': len(exclusions),
                      'potion_requests': len(timeline), 'cited_frames': len(selected_facts)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

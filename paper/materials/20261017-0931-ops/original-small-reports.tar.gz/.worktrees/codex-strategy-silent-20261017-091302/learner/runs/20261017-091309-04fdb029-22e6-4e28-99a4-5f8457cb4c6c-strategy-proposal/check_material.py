"""Check observed local arithmetic without executing or changing gameplay code."""
import collections
import json
from pathlib import Path
from study import OUT, citation, save, summarize

frames = {x['source']['line']: x for x in json.loads((OUT / 'cited-frames.json').read_text())}
requests = json.loads((OUT / 'potion-request-observations.json').read_text())
checks = []


def check(name, observed, expected):
    assert observed == expected, (name, observed, expected)
    checks.append({'name': name, 'observed': observed, 'expected': expected})


def power(frame, name):
    return next((x['amount'] for x in frame['powers'] if x['power_id'] == name), 0)


def enemy_power(frame, index, name):
    enemy = next(x for x in frame['enemies'] if x['index'] == index)
    return next((x['amount'] for x in enemy['powers'] if x['power_id'] == name), 0)


def hp(frame, index):
    return next(x['current_hp'] for x in frame['enemies'] if x['index'] == index)


check('升级零毒蜃景格挡', [frames[293158]['block'], frames[293159]['block']], [16, 16])
check('升级零毒蜃景耗能', frames[293158]['energy'] - frames[293159]['energy'], 1)
check('普通蜃景8毒加2敏捷实增挡', frames[293197]['block'] - frames[293196]['block'], 10)
check('普通蜃景现场毒量', sum(enemy_power(frames[293196], x['index'], 'POISON_POWER') for x in frames[293196]['enemies']), 8)
check('普通蜃景现场敏捷', power(frames[293196], 'DEXTERITY_POWER'), 2)
check('四感染轮净血价', frames[293442]['hp'] - frames[293443]['hp'], 32)
check('两感染轮净血价', frames[293460]['hp'] - frames[293461]['hp'], 11)
check('三感染末轮持有数', sum(x['card_id'] == 'INFECTION' for x in frames[293464]['hand']), 3)
check('三感染末轮玩家HP和挡', [frames[293464]['hp'], frames[293464]['block'], frames[293465]['hp']], [2, 7, 0])
check('先死亡未兑现毒杀', [hp(frames[293464], 0), hp(frames[293465], 0), enemy_power(frames[293465], 0, 'POISON_POWER')], [8, 8, 10])
check('碾碎爪饮毒当步', [enemy_power(frames[292940], 0, 'POISON_POWER'), enemy_power(frames[292941], 0, 'POISON_POWER'), hp(frames[292940], 0), hp(frames[292941], 0)], [42, 48, 54, 54])
check('碾碎爪SL资源恢复', [frames[292941]['hp'], frames[292942]['hp'], frames[292942]['turn']], [10, 62, 1])
check('扭动虫饮毒当步', [enemy_power(frames[293463], 0, 'POISON_POWER'), enemy_power(frames[293464], 0, 'POISON_POWER'), hp(frames[293463], 0), hp(frames[293464], 0)], [4, 10, 8, 8])
heart27 = next(x for x in requests if x['source']['line'] == 286123)
check('F27勘误药前后即时挡', [heart27['before']['block'], heart27['next_source_state']['block']], [0, 0])
check('F27覆甲实际建立', [power(heart27['before'], 'PLATING_POWER'), power(heart27['next_source_state'], 'PLATING_POWER')], [0, 7])
check('同族末次T2覆甲及下一轮HP', [power(frames[292343], 'PLATING_POWER'), frames[292343]['block'], frames[292343]['hp'] - frames[292344]['hp']], [7, 7, 4])
check('同族末T14牌挡', [frames[292398]['block'], frames[292400]['block']], [3, 6])
check('同族末T14死亡截断', [frames[292401]['hp'], frames[292402]['hp']], [4, 0])
check('同族铜钹完成单弃额外伤害', hp(frames[292398], 0) - hp(frames[292399], 0), 3)

for run in ['ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1']:
    resource = json.loads((OUT / (run + '.resources.json')).read_text())
    if run == 'ZTRGYYMLR8SC':
        boss = [x for x in resource['combats'] if x['floor'] == 17]
        check('同族六尝试入口血量', [x['entry']['hp'] for x in boss], [68] * 6)
        check('同族六尝试双药恢复', [x['entry']['potions'] for x in boss], [[[0, 'HEART_OF_IRON'], [1, 'BOTTLED_POTENTIAL']]] * 6)
        check('同族前五尝试缺退出帧', [x['exit'] for x in boss[:5]], [None] * 5)
        check('同族新获与SL恢复区分', sum(x['floor'] == 17 and x['expect']['potion']['id'] == 'HEART_OF_IRON' for x in requests if x['source']['run_id'] == run), 6)
    if run == 'K2JAGKVJAWZJ':
        crab = [x for x in resource['combats'] if x['floor'] == 33]
        check('帝王蟹两次原入口', [x['entry']['hp'] for x in crab], [62, 62])
        check('帝王蟹首试缺完整末轮', crab[0]['exit'], None)
        check('帝王蟹第二次胜后血量', crab[1]['exit']['hp'], 28)
    if run == '79UCJ0K6R9C1':
        check('79三场实际净血价', [x['observed_net_hp_loss'] for x in resource['combats'] if x['floor'] in (8, 12, 14)], [40, 19, 51])

states_by_run = collections.defaultdict(list)
state_index = {}
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    item = json.loads(line)
    states_by_run[item['run_id']].append(item)
for run, items in states_by_run.items():
    for at, item in enumerate(items):
        key = (run, item['row'].get('observed_ts'), json.dumps(item['row'].get('fingerprint'), sort_keys=True))
        state_index.setdefault(key, []).append((at, item))

discards, plays, three_guards, plan_facts = [], [], [], []
for line in (OUT / 'evidence/decisions.evidence.jsonl').open():
    item = json.loads(line)
    row = item['row']
    action = row.get('chosen') or {}
    key = (item['run_id'], row.get('observed_ts'), json.dumps(row.get('fingerprint'), sort_keys=True))
    matched = state_index.get(key, [])
    if len(matched) != 1:
        continue
    at, before = matched[0]
    items = states_by_run[item['run_id']]
    if at + 1 >= len(items):
        continue
    after = items[at + 1]
    state = before['row']['state']
    selection = state.get('selection') or {}
    relics = [x['relic_id'] for x in (state.get('run') or {}).get('relics') or []]
    if (action.get('action') == 'select_deck_card' and 'TINGSHA' in relics
            and selection.get('kind') == 'combat_hand_select' and '丢弃' in selection.get('prompt', '')
            and selection.get('min_select') == selection.get('max_select') == 1
            and not selection.get('requires_confirmation')
            and after['row']['state'].get('screen') != 'CARD_SELECTION'):
        a, b = summarize(before), summarize(after)
        def total(frame):
            return sum(x['current_hp'] + x.get('block', 0) for x in frame['enemies'] or [])
        discards.append({'decision': citation(item), 'before': citation(before), 'after': citation(after),
                         'floor': a['floor'], 'turn': a['turn'], 'visible_hp_and_block_decrease': total(a) - total(b),
                         'before_enemies': a['enemies'], 'after_enemies': b['enemies'],
                         'causal_attribution': None})
    card = (row.get('expect') or {}).get('card') or {}
    if action.get('action') == 'play_card' and card.get('id') in ('FAN_OF_KNIVES', 'SHADOWMELD', 'BURST', 'PIERCING_WAIL', 'FOOTWORK'):
        plays.append({'decision': citation(item), 'floor': row.get('floor'), 'turn': row.get('turn'),
                      'attempt': row.get('sl_attempt'), 'card': card, 'result': row.get('result'),
                      'before': summarize(before), 'after': summarize(after)})
    if item['run_id'] == 'ZTRGYYMLR8SC' and (row.get('hp_guard') or 'HP guard:' in str(row.get('rationale'))):
        three_guards.append({'source': citation(item), 'floor': row.get('floor'), 'turn': row.get('turn'),
                             'hp_guard': row.get('hp_guard'), 'rationale': row.get('rationale'), 'questions': row.get('questions'),
                             'selection_audit': row.get('selection_audit'), 'journal': row.get('journal'),
                             'chosen': action, 'result': row.get('result')})
    if item['run_id'] == '79UCJ0K6R9C1' and row.get('floor') == 14 and row.get('turn') == 3 and row.get('questions'):
        plan_facts.append({'source': citation(item), 'row': row})

save('single-discard-observations.json', discards)
save('modifier-card-observations.json', plays)
save('guard-observations.json', three_guards)
save('79-f14-t3-forecast.json', plan_facts)
save('material-checks.json', {'passed': len(checks), 'checks': checks,
     'scope': '原帧与局部算术核验，不是生产tsc/vitest或整战因果验证',
     'single_discard_count': len(discards), 'single_discard_deltas': dict(collections.Counter(x['visible_hp_and_block_decrease'] for x in discards)),
     'modifier_card_count': len(plays), 'hp_guard_count': len(three_guards)})
print(json.dumps({'passed_material_checks': len(checks), 'single_discards': len(discards),
                 'discard_deltas': dict(collections.Counter(x['visible_hp_and_block_decrease'] for x in discards)),
                 'modifier_plays': len(plays), 'hp_guards': len(three_guards)}, ensure_ascii=False))

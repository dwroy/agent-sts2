"""Write this batch's evidence-qualified dispositions without changing production data."""
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = '1fcbbfa59ac00e9bf04552d376ba693969f54e9f'
BATCH = '20261017-091302-strategy-proposal'
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())

details = {
    '0b8ef30de463f317': {
        'evidence': 'ZTRGYYMLR8SC A10 F6T3、F11T1、F14T1、F17六次入口及末次T2—T14。d285252/285694；s291891→291892、292342→292343、292343→292344、292398—292402。',
        'finding': 'F6药后已有挡6保持6，覆甲建7；同族末次T2已有挡7保持7，下一轮68→64、覆甲6。六次均68/70、原两瓶进场，前五缺退出结算，末试实死。36个主局药水请求的原动作/药栏/前后帧已单独保存，不能把读档恢复叫作新获或回血。',
        'existing': 'card-model.ts、turn-solver.ts与rollout.ts已有覆甲建层及分轮处理；potion-cost.ts区分no_table/no_value/worthless。当前缺表提示并未冒称实测价值0。',
        'counter': '第2次提前T1喝铁心，同时目标及抽牌后继改变，不能归因早喝更好或更差。',
        'reason': '缺药水取得/实饮/弃用/SL恢复到消费者的完整联合归属，以及同资源晚饮或留药的整战对照；覆甲和缺表来源已有处理，不重复改规则。',
        'validation': '后续用同角色固定完整资源链核来源与药栏守恒；只校准已观测转移，饮药阈值须另有时点对照。',
    },
    '5367449b857450a7': {
        'evidence': '原七局ZTRGYYMLR8SC、1LMBFGSMCWKU、9YT51CK8RC39、25226ZFLNR1J、TCFAHJ9K19VY、ULP4TN1GNHMK、61E2QS63Y9WU；ZTRG F11T1 d285287、F17末T14 s292398→292399。107条逐次原引用在single-discard-observations.json。',
        'finding': '独立复算七局107个不需确认的单弃选择：100次可见敌HP+挡合减3、7次减1；不是107个独立局。ZTRG刀扇施放8手→10手、建1层、现三刀为AllEnemies；这里只实见单敌战。',
        'existing': '现有力量/虚弱、脆弱牌挡与覆甲路径保留。单弃附伤事实不等于完整随机分配、过量击杀和求解器/rollout后继均已验证。',
        'counter': '7次减1与ULP的滑溜同现，不能忽略；不能由合计差额认定每个随机受击目标。后续经验文字另含单敌多弃，非本批新增原帧样本。',
        'reason': '107次单弃只确认局部附伤，缺多敌随机分配、混合减损/击杀与完整后继的消费者校准；刀扇本批单敌，不能据此关闭整组机制提案。',
        'validation': '补含完整修饰条件的单弃/多弃、多敌分配及击杀前后连续帧；按伤源分别回放，未知组合继续未知。',
    },
    '9b8890c2649a2734': {
        'evidence': 'ZTRGYYMLR8SC A10 F11T3 d285301、F17首试T10 d285405、末试T13 d285745；三次记录均在原rationale的HP guard文本，不是后来新增的hp_guard字段。',
        'finding': '同题原/替候选分别为血价25/20且扣26/18、15/12且扣12/3、2/0且扣7/0。原题、日志最终文字、动作与重问均保存。三次局部差额不能累加成另一整战结果。',
        'existing': '现有audit-selection离线消费者已运行：本局130候选段、594动作，69个整轮端点/39未知；所有完整候选结果null。',
        'counter': '六次同族同一初始资源均失败，仍不是任意换序必死；前五判死截断。末T13两线0/24赢及24/24死是有限推演。',
        'reason': '缺原线/替线完整执行归属及连续资源联合对照；三次局部省血不能累加成整场收益，未走路线和晚饮铁心没有实际整战结果。',
        'validation': '按原decision_id、尝试、回合核动作与完整出口；分别留预测/实际、恢复/回血，不拟合新的护栏或SL阈值。',
    },
    '645ff7b72e0b9991': {
        'evidence': 'K2JAGKVJAWZJ A10 F46T1 s293158→293159及T6 s293196→293197；79UCJ0K6R9C1 A10 F14T3 d286684、T6 s293442→293443、T10 s293460→293461、T11 s293464→293465。9YBKCNBFP0X5 A4仅作原提案首证上下文。',
        'finding': '零毒升级蜃景耗1能、挡16不变；普通版8毒+2敏实增10。79空过题0/8地平线实赢与约76%尾端估计分列；感染轮实净损32/11，末轮三感染先致死，敌8血10毒未兑现。',
        'existing': '5e0f884586521220d451b717c29b99e7876d6244已实现限定零毒升级分支；cf0f2495354d9cf5dcb96dc31a2de0f4c53f441a普通蜃景、0fbd5bc39b835bc58fef3f95c5b589ae31577b73持有伤害边界均为base/live祖先。只是子项，不是全提案duplicate。',
        'counter': '普通蜃景实得10挡反对整类归零；非即时输出的能力也可能实际增挡。79未执行另外四个固定牌方案，未知不填作失败或胜利。',
        'reason': '零毒与感染窄分支已有实现，剩余尾端估计尚缺实结校准及替代整战结果；不能由0/8或即时伤害调权、禁止空过或关闭整项。',
        'validation': '保留已实现正反例；以新完局按时间留出检验估计偏差，实际胜负与估计贡献分别登记，不把同局八采样当八局。',
    },
    '68ef2857229d1287': {
        'evidence': 'K2JAGKVJAWZJ A10 F33首试T10 d286255、s292940→292941→292942；79UCJ0K6R9C1 A10 F14T11 d286715—286716、s293463→293465。',
        'finding': '碾碎爪毒42→48且54HP不变，随后SL恢复10→62与原瓶；扭动虫毒4→10且8HP不变，玩家2血7挡/三感染随后先死。修饰条件保留在potion-request-observations.json，不把两次饮用当完整组合模型。',
        'existing': '当前combat-plan只向已观察双Boss/恶魔注入observedPoison；crabPoisonFacts的154c9542711a4daf17bfa0b97eaa1ca81dc3d385实际live祖先仅覆盖SB5另一组观测当步事实，不覆盖本两局整轮。',
        'counter': 'K2末试未饮原瓶仍赢，79实加6仍先死，均反对由药效推导必须喝或毒足即可活。K2没有首试该轮实结，79还有同类虫实体/索引变化。',
        'reason': '两次原帧确认当步加6；K2该轮判死后直接SL、79感染先死，仍缺完整修饰与整轮后继的联合消费者校准，不能扩成通用非双Boss药水模型。',
        'validation': '补无加量/阻挡及实际相关修饰条件下的连续完整轮出口，分别核施毒、持有代价和后续结算；未核组合保留饮后重算。',
    },
    '9edfef7a6b2873c2': {
        'evidence': 'K2JAGKVJAWZJ A10 F31—F46资源链及F34计划d286314；79UCJ0K6R9C1 A10 F8/F12/F13/F14。K2原无ID路线元数据d285853/d285888另列排除。',
        'finding': 'K2 F31 75→40、F32到62，蟹首试10后恢复62、末试28；F35/38/39净损24/8/11，末战86/91。79 F8净损40、F12净损19、F13到51，F14投影70与实际51不同。旧分母不能用后来最大HP替换。',
        'existing': '7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a已保存Silent A10计划currentNode、起始HP/maxHP、房间代价、假设与绝对到达值；base/live祖先及当前源码均核实。resource_chain已区分重启与缺出口，并保留敌血池观察。',
        'counter': '投影可高可低；不能统一减19或加11。旧无ID元数据不能通过归一化唯一补回历史身份；原dirty源码快照也缺失。',
        'reason': '路线绝对来源子项已实现；宽资源链仍缺药水/SL/终局的联合消费者归属，旧无decision_id元数据及归一化计划不能唯一补回，不整项duplicate。',
        'validation': '按同计划节点/替换边界核当前绝对字段，药水来源和模拟入场资源另连完整消费者；未执行路线与缺口留未知。',
    },
    'ff1d168227e369e0': {
        'evidence': 'K2JAGKVJAWZJ A10 F46T1/T2/T6/T7/T9及F33暗影；10GPK5XGHCK3 A3 F17T5；原提案补充UJ0K3G10609Y A10 F33T7/F48逐击窗口。',
        'finding': '本批保存192次相关修饰牌动作的原前后帧。蜃景零毒及普通正毒已分列；末轮死亡实际只扣剩余13血，不把负余血当完整入伤。当前钨棍固定证据也保留UJ来源。',
        'existing': '零毒蜃景、4367250b5fbf1484ca7ea8f312d13e4ce9d327a2钨棍逐击与ec1ceef3acbc168cf03c73c9fb38226b4a0b63b8脆弱下臂甲均为实际base/live祖先；完整组合不因此自动认证。',
        'counter': 'K2三骑士T7可见意图与净损仍差2，不能强拟所有伤源。低阶A3样本不冒称A10验证；持有暗影不能当已建立。',
        'reason': '零毒/臂甲/钨棍窄实现已在live；重放、暗影、临时减力及钨棍完整修饰组合尚未逐消费者核齐，K2T7额外2伤未隔离，不关闭整项。',
        'validation': '固定逐动作重放/能力建立/新增挡与逐击损伤，保留真实恢复时点及死亡截断；只对隔离组合实施条件化模型。',
    },
    'c64bdd50a949d16f': {
        'evidence': 'K2JAGKVJAWZJ A10 F15T2、F27T2 d286123/s292788→292789、F33首T10及末试、F45弃毒/F46末战；勘误以派发9c3原文为准。',
        'finding': 'F27旧稿16即时挡被原帧与已保存勘误否定，实际0→0挡、0→7覆甲。资源链保留前战能力、实饮、主动弃瓶、SL恢复及跨幕回复的不同来源；不重写旧原文。',
        'existing': '现有牌挡、覆甲、能力建立/跨战重新读取及离线药槽观察均保留；经验与追溯记录存在不等于终局联合消费者完成。',
        'counter': '持有雾/暗影不等建立；首试饮毒被SL撤回，末试未饮胜；F45弃瓶换液态记忆后败也不证明换瓶导致败。',
        'reason': '按9c3勘误采用F27零即时挡，旧稿保留；仍缺持续能力/药水取得、实饮、弃用、SL恢复到终局的联合消费者及早饮/换瓶整战对照。',
        'validation': '在保留旧稿的前提下只用更正数字；补完整资源事件至消费者链，同帧区分持有/拟建/已建，不改饮药和终局阈值。',
    },
    '243ad8dd038a4ff6': {
        'evidence': 'K2JAGKVJAWZJ A10 F33两次入口62、原毒瓶及第二次胜后28；F31/32/35/38/39/42/43/44/45资源轨迹与F46三骑士。',
        'finding': '原提案记录首29抽相同；本轮只独立复核同入口原瓶、两次T3/T4开轮手牌一致与实际不同动作后继，不冒称重新认证29抽全量。第一试T10缺实结即SL；第二试获胜，末F46仍败。',
        'existing': '现有离线消费者本局138候选段/720有ID动作、25整轮端点/97未知，两个无ID元数据单列。重打与资源工具没有认证完整替线或因果。',
        'counter': '首轮目标、后续动作、药水使用同时改变；洗牌后抽牌和未走路线不可控，不能独立归因固定杀序、留瓶或运气。高血/两药也没有保证末战安全。',
        'reason': '同入口和局部同手牌不能隔离首目标/留药胜因；缺洗牌后同条件及单动作整战对照，替路线/休息未执行，不能改固定杀序或SL边界。',
        'validation': '同局SL整体同组，完整保存首试截断与胜试；后续以单项变化和完整整战后继核因果，未控因素逐项列未知。',
    },
    '9c3ff04261867dd2': {
        'evidence': 'K2JAGKVJAWZJ A10 F27T2 d286123、s292788→292789；同时承接c64同组F15/F33/F45/F46资源证据与silent-0021/0243/0276/0277/0278。',
        'finding': '更正独立由原帧核对：药前后均0挡、覆甲0→7。勘误没有被省略，也没有覆盖旧提案原文/指纹。',
        'existing': '旧能力/药水消费者与资源链的窄来源字段保留；更正文档已存在，不是本批新源码实现或整项duplicate。',
        'counter': '正确的单点数字不提供早喝/晚喝、换瓶或未建立能力的整战结果，也不证明当前全部消费者都完成联合校准。',
        'reason': 'F27零即时挡勘误已核；实际能力、取得/实饮/弃用/SL恢复到终局的完整联合归属及饮药时点整战对照仍缺，勘误不充源码实现。',
        'validation': '用原两帧及同一账本组作回归输入，继续补资源/能力到实际消费者的连接；保留原稿和更正稿并行历史。',
    },
}

results, sections = [], []
for proposal in proposals:
    ident = proposal['id']
    detail = details[ident.removeprefix('silent-proposal-')]
    results.append({'id': ident, 'state': 'waiting', 'reason': detail['reason']})
    sections.append('\n'.join([
        '## ' + ident, '', proposal['summary'], '',
        '账本：' + '、'.join(proposal['ledger']) + '。来源任务：' + proposal['source_task'] + '；实现任务：strategy-proposal。',
        '原文：`' + proposal['proposal'] + '`；SHA256：`' + proposal['proposal_sha256'] + '`。原字节另存同ID的.original.md。', '',
        '**证据局号/层/回合**：' + detail['evidence'], '',
        '**核实结果**：' + detail['finding'], '',
        '**既有行为与源码**：' + detail['existing'], '',
        '**反例、未知与范围**：' + detail['counter'], '',
        '**本批处置**：waiting。' + detail['reason'], '',
        '**预期行为及验证**：' + detail['validation'], '',
        '**拟合/切分/回退**：本批不拟合参数，同局SL不拆独立样本；未来同角色完局按时间留出。未改源码，无回退提交；后续实际实现按净补丁回退，保留本批全部原证据与失败初稿。',
    ]))

(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
intro = f'''# 本批十项策略提案核证与处置

记录时间：{stamp}。batch={BATCH}，角色silent，base={BASE}。

本批为普通队列任务，严格只处理派发十ID。learn.json对应行task/character/worktree/proposal_ids均核对，无research_request、implementation_request或proposal_repair。普通专题条件不成立，不承接另一批专题。开工git status干净；按要求git merge --no-edit main返回Already up to date，HEAD保留完整base。未派子agent，不联网，不运行play。

十项全部waiting。没有源码/知识修改，没有新提案ID、提交、合入、发布号或shipped。当前已实现窄子项只作已核事实，不把宽父项整项标duplicate，也不要求为了验证局部机制必须先证明整战提升。剩余处置分别针对尚未完成的条件/来源/消费者校准或参数反事实，不用预训练补齐。

提取范围是十派发锚点，加原提案明确引用的UJ0K3G10609Y、9YBKCNBFP0X5两局；12局的runs与所有8295选中状态角色/进阶均核。8流16802选中行全部按原source/offset/bytes/SHA/JSON重读验证。manifest保留各流source_size与计数。fight-plans在该截点选中0行，只表示截点未选到，不推断日志不存在。完整证据见evidence/、evidence-validation.json。

跨任务原文与Markdown SHA均核对后复制，旧账本通过原CLI模块折叠读取，仅本角色20个关联ID；不重写历史复盘，不将重复历史证据增记support或repeat。更正后的F27与旧稿并存，以已核原帧为准。无本批新科学异议或待发送的新反证通知。

所有后续行为改动仍仅依据本角色已观察条件；本批不改变铁甲或任何角色行为。固定材料核验与离线消费者不是生产tsc/vitest，不能报成功测试或已自然采用。
'''
(OUT / 'proposal.md').write_text(intro + '\n' + '\n\n'.join(sections) + '\n')

report = f'''# 策略队列批次回报

记录时间：{stamp}。batch={BATCH}，character=silent。

已逐项处理十个派发ID，全部waiting，具体理由、证据局号/层/回合、既有账本ID、反例与验证计划见[proposal.md](proposal.md)及[proposal-results.json](proposal-results.json)。本批没有找到足以完成剩余范围的新可隔离策略改动；未改源码/知识，fixes=[]，merged=null，无新提交/版本，不冒称implemented或shipped。

## 身份与基线

- 工作树：{OUT.parents[2]}。
- base/HEAD：{BASE}，普通任务已执行git merge --no-edit main且无需更新。
- learn.json只读本批，reason=proposal、十ID和工作树绑定通过。无专题/implementation绑定，不读取其他请求替代身份，不领取其他ID。
- 派发锚点仅原十局；补充UJ0与9Y只因原提案引用，不能冒称新增两局独立支持。10G A3、1LM A4、9YT A7，其余锚点A10；补充UJ0 A10、9Y A4，不混阶拟合。
- 历史runs.code为dirty记录，当前源码不能复原其完整运行树；历史脑引擎记录原样保留，不倒写为纯Codex。当前工具未提供实际原生会话/请求模型、推理强度和计费档的独立读回，不冒称已核。

## 原证据及局部核验

共用extract_evidence.py提取：states8295、decisions7971、sl-attempts67、run-config12、run-plans60、brain385、runs12、fight-plans0，共16802行。选中封套内容及其原日志字节全部核过，源截点分别保存在evidence-manifest.json。全源扫描states/decisions/brain各有2条无效JSON，未把它们归到某局，也不据此补缺帧或断言缺日志；各流不完整末行均0。未做旧截点复核，不覆盖旧报告或0行初稿。

固定材料27项全部通过，见material-checks.json；不是生产测试：

- F27T2铁心：d286123，s292788→292789，挡0→0、覆甲0→7。原c64“16挡”只作为已纠正旧稿保存，9c3更正稿SHA独立核对。
- K2 F46T1：零毒升级蜃景1能、16挡不变；T6普通版8毒+2敏实际10挡。现有零毒源码子项已live，不重做。
- 79 F14T6/T10净血价32/11；T11三感染时2血7挡，饮毒使目标4→10毒而8HP不变，随后先死且毒未结，不能把毒足当实赢。
- 七局107次单弃按真实选择帧和后帧复算：100次敌HP+挡合减3、7次减1；分局18/19/27/9/13/2/19。保留全部敌状态，滑溜同现不是已隔离因果；没有把合计差额当随机分配定律。
- ZTRG F11T1刀扇8手→10、建1层、添3刀，当前是单敌场景；不由此外推全部多敌后继。
- 三处HP guard实际位于rationale：d285301、285405、285745。同题候选血价/扣血25/26→20/18、15/12→12/3、2/7→0/0，保留推演文本与SL尝试，不累加成整战因果。

同局尝试不作为独立训练/验证局，不拟合HP安全线、药水持有价/时点、出牌权重、SL必死阈值、固定目标序或尾端估计参数。

## 已有消费者与源码

三局从本批冻结封套生成输入并实际运行既有learner/audit-selection.ts，均exit0；三份resource_chain也由同版本函数在相同冻结状态上实际计算，调用与输出保存在scratch，不重扫角色全史、不调用模型/游戏/网络：

|局号|有ID动作|候选段|可核整轮端点|整轮未知|
|---|---:|---:|---:|---:|
|ZTRGYYMLR8SC|594|130|69|39|
|K2JAGKVJAWZJ|720|138|25|97|
|79UCJ0K6R9C1|235|78|0|42|

346候选段的actual_full_candidate_result及actual_rollout_best均null。这是消费者设计保留未知，并不等于实盘没有执行。观察区间有526个端点/1023未知；79旧尝试字段缺失使严格消费者不能连接，原帧的局部实值仍可单独核对。K2的d285853/285888两条无decision_id元数据明确排除、保留原offset/SHA，不伪造ID。94个整轮端点不等于94个完整候选或独立样本。

资源链保留全部赢战及截断尝试：ZTRG同族六次均68与原两瓶、前五缺退出；K2蟹第一试62→10后SL，第二次62→28胜且留原瓶；79 F8/F12/F14实际净血价40/19/51。净损不等完整敌伤，恢复不等回血，未走路线不填实际结果。

source-readback.json冻结23个当前源码/固定夹具叶及8个实际base/live祖先；核对时live=99737be9fdb9c2ea92089d768947c49b49b62382。其中route来源7c43bbbb、零毒蜃景5e0f8845、普通蜃景cf0f2495、持有伤害0fbd5bc3、蟹当步事实154c9542、离线工具a32050fb、钨棍4367250b、臂甲ec1ceef3均实祖先。23叶中两叶与live只差原Roy/Dai注释署名，其余字节相同，精确差分另存live-source-differences.patch；这不是整个历史dirty树等价声明。窄祖先不能关闭本批宽提案。

## 验证、变更与交接边界

生产tsc=null、vitest=null、cases=null；没有源码提交，因此没有撤源码失败/恢复通过、整套沙箱或合后测试，不伪造绿灯。材料核验27通过、三份TypeScript离线消费exit0另列，未运行生产求解/整战模拟，不声称策略收益或自然采用。

无新代码提案，code_proposals沿用本批十个已由CLI登记的原ID；implementation_domains=[]表示本批没有实现域改动。现有账本状态/版本/首证/prior/evidence均不应因本批复核改变；后续只通过根ledger.py update追加本批proposal/report追溯与waiting理由，不标proposed覆盖旧shipped、不新增支持次数。追加与保护字段读回见ledger-update-receipt.json（完成后生成）。

未合入live，无源提交需ops兜底，无eval版本或规则双通知；不用报告结束冒称经验实际入库或消费者自然采用。十项等待proposal-results.json所列具体数据。proposal交运维路径：{OUT / 'proposal.md'}。

## 限制与保留

旧数据没有完整反事实；K2首试末轮被SL截断、T7额外2损伤未隔离，同类虫实体与新增血池不能按敌index连续当同一实体。K2首29抽是原提案结论，本轮仅独立核同入口/瓶及T3/T4手牌，不扩大成重新验证全部29抽。现有经验文字中的后续多弃/多敌样本不作本批原帧，未追加未派发局。

工具偏差见tooling-deviations.json：首次沙箱启动glob竞态未执行提取、几个只读路径拼写、路线夹具列表误按对象读取、首次只查hp_guard字段漏掉rationale、消费者无status字段的初版计数，均是工具/研究脚本问题；相关初稿保留，不当游戏反例、日志缺失或生产失败。修正后的材料与消费者结果使用真实字段。最初自写账本简化折叠亦保留initial，正式读回改用原ledger.fold；从未据简化副本修改根账本。

原始日志只读，全部临时材料在本批scratch；不删除旧材料/失败记录，不修改请求、派发状态、原提案、其他角色知识、账号/环境、运维prompt或历史记录。
'''
(OUT / 'report.md').write_text(report)

final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
         'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposals': len(results), 'states': ['waiting'], 'report': final['report']}, ensure_ascii=False))

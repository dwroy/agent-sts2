import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
pins = json.loads((OUT / 'source-manifest.json').read_text())
base = pins['base']
details = [
    ('751FN9QM9MHQ F17 T2/T7/T13；第1/3试损13→18、净扣敌9→18；第2/4试损13→23、净扣敌12→18；第1/6试损8→2、净扣敌17→11。',
     '已有SL资源预测、配对B2及选择/派发记录；未确定弃牌和续问之后仍不认证完整执行。',
     '缺各候选实际持牌/能力成本归属、同后继整战对照和独立局验证；三组局部血价不足以确定探索准入阈值。',
     '补同指纹原答→护栏→SL→实际动作→抽弃牌重问→轮末结算链；分别核敌伤、持牌自损、能力建立及配对误差，再用独立后期局验证。'),
    ('751FN9QM9MHQ F13 T3，decisions272361/272362；F17 T7/T13/T17，肌肉药水仅实际执行饮用支线；未决弃牌不能预扣一张呼唤。',
     'silentPotionReference已显示hold_hp=null及同题无药参考；silentHeldLossFacts已显示保守持牌损血与弃牌未决。',
     '缺无药或留至后战的完整实果，以及已确定敌伤/持牌损血逐来源结算；缺表记0不能拟成留药价值0。',
     '保留F13原题与无药模型范围，新增自然证据须核完整无药/留药分支、随机/抽弃牌续步和跨战入口资源；不以Boss空栏失败倒推药价。'),
    ('与366288801d9150d9共用751FN9QM9MHQ F17 T2/T7/T13及同一六次尝试；关联silent-fysh-resource-sl-observation和silent-beckon-held-end-turn-loss。',
     '已有结构预测为窄实现；经验任务与复盘任务的相同帧不构成两个独立支持。',
     '缺完整候选实际成本归属、受控整战和后期独立验证；同主题、相同账本及已有预测不证明整项实现。',
     '复用前项六个端点，不重复计数；验证实际手持呼唤、弃牌、能力后继与整战输出，再决定是否改变探索。'),
    ('751FN9QM9MHQ F13 T3、F17 T3/T5/T7/T13/T17；原提案关联敏捷、毒、荆棘、呼唤等九类经验，已有账本分别记载局部结算。',
     '已有持牌预测、未知留药价、同题无药参考和原求解组件；本批未复算原提案所述101局历史。',
     '缺敏捷/毒/荆棘/未决弃牌的完整联合消费者实际结算和跨战留药对照；局部组件存在不能认证九类经验整项覆盖。',
     '按每个子机制保存实际施放与后继，不共用有效样本分母；固定联合帧核抽弃牌重算及各来源，再用独立局验证。'),
    ('KV0JHNJCKXLS F33第4/5试T5，同指纹；删致命毒药+后当轮零损均未变，净扣敌36→29。末试states279559→279560为敌327/15毒→342/14毒。',
     '现有SL预测分列当轮损血、输出与次轮毒；端点净血量不能自动恢复完整毛伤、回血和能力收益来源。',
     '缺完整毛伤/回血/成长归属、保持后继不变的胜线及独立验证；零损删输出不能被记成已证保血收益或路线参数。',
     '逐来源核结毒与回血、实际后继能力，并将已走营火/血瓶/幕间/SL恢复分账；原未走路线仍保持反事实未知。'),
    ('YQL8RZ8BWN1E F17末试T10，states280160→280161毒2→8，HP26/挡13/自爆41不变。L9SGRBB5R698 F17 T14及PU80F84P6HPN F17 T17有占位血排序记录。',
     '本体/自爆事实、毒药水局部观察和最终资源限制已有；enemyHpLeft/anchorRank仍保留原始占位血作原同轮参考排序。',
     '缺改序后的受控整战与完整最终资源、提前饮药结果；直接归零占位HP会改变同轮排序，阶段显示已实现不足以认证排序收益。',
     '固定普通血量/占位态/未知态核指标和原始字段；若改序必须保存新旧参考及自爆末态/净HP/药水对照，不以本体结束判胜。'),
    ('与e18d3f18e6cac2a0共享YQL/L9/PU阶段证据；PU80F84P6HPN F17第5试确为won，整局在F33失败，二者分开。',
     '已有阶段和局部药水事实；PU胜次同时改变多处后继，不作单步归因。',
     '缺阶段改序、提前用药及路线的受控验证；现有阶段子实现和同源经验不能登记整项duplicate。',
     '复用阶段端点与原sl-attempts，不重计独立局；补同后继参考排序对照和完整退出资源，另核路线实际回血。'),
    ('KEN58SH9SLZ6 F3 T2/F4 T1/F5 T2/F11 T1-T2/F15 T1七次饮药，七个前后槽位窗均已核；六次F17入口均75/86、空药栏。',
     '原动作、选择预测和单动作回执可读；随机选牌、发光水后的重问不等于原候选整线执行完毕。',
     '缺随机选牌和发光水重问后的完整收益归属，以及不饮用或留到Boss的完整分支；不能拟合持有价值与跨战预算。',
     '逐槽位核饮用请求、状态、选择所得、实际出牌和轮末结果，赢战资源消耗追溯到Boss入口；与保留药水的完整分支及后期独立局比较。'),
    ('KEN58SH9SLZ6 F17第4/5试T10同指纹，净损15→21、净扣敌2→4；第4/6试T5净损7→5、净扣敌1→2，但步法建立T5→T9。',
     'SL资源预测、选择阶段与派发回执已有；能力长期分数和未执行续步不能当当前挡量或实际收益。',
     '缺完整能力后继、逐来源实际归属、同后轮整战对照及独立验证；不能拟统一6血/2伤准入阈值。',
     '同盘核无实体逐段伤、呼唤末持牌和步法建立时点，续问追加小刀单列；留后期独立局，不把单轮最少损血当全局最优。'),
    ('与86a7db08d1a31976共享KEN同一局T5/T10两组对照；六次SL只算一个独立局；新增伤害与能力建立的双向取舍均存在。',
     '已有预测与单动作派发诊断；原经验和复盘的两条提案不扩充样本。',
     '缺续问后完整执行归属、受控整战与后期独立验证；不能据省血或未试线直接关闭探索、改变HP护栏。',
     '复用KEN两组固定端点，联核持牌血价、能力建立及后续抽牌；训练/验证按独立局时间切分，缺反事实保持未知。'),
]
results = []
sections = []
for entry, (evidence, existing, missing, validation) in zip(assigned, details, strict=True):
    ident = entry['id']
    results.append({'id': ident, 'state': 'waiting', 'reason': missing})
    sections.append(f"## {ident}\n\n来源任务：{entry['source_task']}；实现任务：strategy-proposal / {dispatch['worktree'].split('/')[-1]}；账本：{'、'.join(entry['ledger'])}。\n\n"
                    f"证据与范围：{evidence}\n\n已有行为：{existing}\n\n处置 waiting：{missing}\n\n预期行为：保留当前规则及合法选项，保留预测/实际/未知边界；本批没有新增权重、排序或药水/SL门槛。\n\n验证方法：{validation}\n\n反例与未知：局部差额不认证整战胜因；同局后续抽序/动作改变不作单因归因。回退：本批无源码、知识或规则改动，无新增提交可撤回；原提案、失败与证据均保留。\n")

proposal = f"""# 静默猎手十项策略提案复核

写入前已执行date；准确命令时刻见本批执行记录，本文不另造事件时间。

批次20261018-070101-strategy-proposal；基线{base}。普通proposal批次，仅处理dispatch.json的十个id；无research_request/implementation_request/proposal_repair，未承接根目录旧手动专题。worktree、角色及派发六局集合已核。初始干净，按要求git merge --no-edit main快进，无冲突。独立执行、未派子agent。

所有结论只限本批六局Silent A10和已关联silent经验/账本；不读取其他角色知识，不从预训练补游戏结论。十份原Markdown逐SHA匹配，原文另存.original.md。旧101/102/103/104局历史统计仅为原提案背景，本批不声称重做全历史审计；六局的SL尝试不拆为独立训练/验证样本。

共用取证入口extract_evidence.py八流冻结后逐条seek复核offset/bytes/SHA、原JSON、归局身份和输出SHA。准确合计8444条，不是早先进度消息误写的6995。states/decisions/brain各有2条全源坏行计数，不能归为本批局缺失；fight-plans在其2233957字节截点选中0行，不据此断言源文件缺失。明细见byte-verification.json。局部验证仅核事实，不运行生产模拟器或LLM、不拟合游戏参数。

当前实际live观察提交：{pins['observed_live']}。source-manifest.json保存19个基线/live源或固定测试叶的Git blob、SHA256、最后实际live祖先源码提交及祖先检查0；16叶同字节，3叶仅旧署名注释差，完整patch保留。这里是窄源码审计，不声称整树等价或运行态已采用。

已存在的窄实现：silent-sl-resource-comparison.ts（0e4fe4df89a06682468e0e4716c12126e76369d5）保留模型预测与execution=unverified；silent-selection-audit.ts/silent-held-loss.ts（05cd292c6f01bb31e406473d3a9843e659d62b93）保留候选阶段/弃牌未决且actual_turn为null；silent-selection-dispatch.ts（bade647f9fe4c9103b40e2f26b26296692ad24b7）只认证单动作回执、whole_plan_executed为null；silent-potion-reference.ts（04921bd785ac6838066522f91ea0bb6ab95cb6a1）区分未知留药价、当轮不喝与抽样整战无药；silent-giant-potion.ts（d5e20aa4dd44168ce30944dfcce74f8322144953）保留本次毒药端点；sl/attempts.ts、controller.ts、explore.ts（最后所核源码0d092f6b928a6221eabf3516abad25c48ceaac9c）另列本体/自爆和有条件最终资源，仍保留原anchorRank排序。以上是已有子项，十项均不据此登记整项duplicate/implemented。

无新源码/知识数据修改，因此无消融、tsc/vitest、live合入、eval版本、shipped或实际消费者新增验证；tests三项为null。代码规则若将来改动须固定输入消融红/恢复绿及原沙箱入口，再按live流程上线和双通知。证据不足保留原行为符合已有授权，无额外审批门槛。

""" + '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal)

report = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-070101-strategy-proposal',
          'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
table = '\n'.join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
text = f"""# 静默策略任务回报

本批十项均waiting。已有子实现有实际live祖先源码证据；剩余完整执行/逐来源收益、受控整战或留药对照不足，未新增策略规则或重复实现诊断。

base：{base}；观察live：{pins['observed_live']}。初始工作树干净，普通批次快进main成功；无专题绑定、未扩队列，六局均Silent A10。提案全文与逐项账本/层/回合/反例/预期行为/验证方法见[proposal.md](proposal.md)，交运维的真实绝对路径：{OUT / 'proposal.md'}。

原始证据8444条：states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、runs6、fight-plans0。抽取manifest保存各流截点与输出SHA；byte-verification.json逐行核原字节、身份、计数全部通过。首条进度消息6995为计数表述错误，已更正；不改抽取原件。全源六条坏行不能归为本批缺帧，fight-plans零行仅限本截点。

六组局部净端点、六组同指纹、KEN七次实际耗药槽位、六次75/86空栏Boss入口、步法建立轮[3,5,5,5,5,9]及KV末T4→T5端点均已核。YQL末T10残壳毒2→8而26血/13挡/41来袭不变；PU的F17第5试won不等于整局获胜。净差不是逐来源毛伤，未执行分支/被SL截断后继仍未知。详见local-facts.json、paired-fingerprints.json、ken-potion-windows.json与giant-poison-endpoints.json。

19个源码/固定测试叶已按冻结base与实际live提交核Git blob/SHA/祖先；16同字节、3仅署名注释差，完整source-manifest.json和patch保留。只核相关源码与原固定测试内容，没有运行生产测试或新消费者验证。

| 提案 | 处置 | 未实现原因 |
|---|---|---|
{table}

未改源码/知识/跟踪记录，fixes=[]、merged=null；没有新提交、合入提交、eval版本、release_id或shipped。无源码消融/恢复测试，tsc/vitest/cases均null；不借旧批次绿灯作本次测试。无规则实际上线，不触发规则双通知或上线decision-log。

原字节审计首轮已完成全部8444条和配对检查，但在读药水槽位时误用slot_index而KeyError退出1；原日志evidence-audit-first.log保留。按真实schema的index修正后evidence-audit-corrected.log退出0；local-facts-check.log退出0。这两次只修改scratch分析脚本，不是生产源码红绿测试。早先一次shell沙箱路径竞态、一次不存在的giant-phase.ts探针和进程查询空结果不作产品失败或日志缺失；源码已改核实际sl/attempts.ts。

账本只经根ledger.py update追加本报告/提案路径及waiting原因，保留已有claim/首证/evidence/prior/status/version/effect，不增加新支持/重复样本、不改shipped；执行结果见ledger-update.log及record-verification.json。专用提案不重复add，不手改队列，由原调度器消费proposal_results。

最终字节/工作树/账本与gitleaks验收见final-check.json、artifact-manifest.json及扫描原件。没有新代码故工作树应保持HEAD=base且干净。

```json
{json.dumps(report, ensure_ascii=False, indent=2)}
```
"""
(OUT / 'report.md').write_text(text)
updates = []
for ledger in sorted({i for x in assigned for i in x['ledger']}):
    related = [x['id'] for x in assigned if ledger in x['ledger']]
    updates.append({'id': ledger, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261018-070101-strategy-proposal：本批六局A10、8444条原字节复核；' +
                            '、'.join(related) + ' 均waiting，逐项原因见报告；现有预测/单动作回执不认证完整候选执行，受控后继/留药与独立验证仍缺。仅补追溯，不新增支持、不改claim/状态/版本。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal': str(OUT / 'proposal.md'),
                  'proposal_results': len(results), 'ledger_updates': len(updates)}, ensure_ascii=False))

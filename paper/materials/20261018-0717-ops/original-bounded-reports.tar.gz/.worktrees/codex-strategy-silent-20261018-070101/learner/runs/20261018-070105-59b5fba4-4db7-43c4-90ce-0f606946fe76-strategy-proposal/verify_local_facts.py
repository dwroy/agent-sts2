import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
sl = json.loads((OUT / 'attempt-summaries.json').read_text())
states = json.loads((OUT / 'compact-states.json').read_text())
cases = [
    ('751FN9QM9MHQ', 17, 2, 1, 3, [(13, 9), (18, 18)]),
    ('751FN9QM9MHQ', 17, 7, 2, 4, [(13, 12), (23, 18)]),
    ('751FN9QM9MHQ', 17, 13, 1, 6, [(8, 17), (2, 11)]),
    ('KEN58SH9SLZ6', 17, 10, 4, 5, [(15, 2), (21, 4)]),
    ('KEN58SH9SLZ6', 17, 5, 4, 6, [(7, 1), (5, 2)]),
    ('KV0JHNJCKXLS', 33, 5, 4, 5, [(0, 36), (0, 29)]),
]
comparisons = []
for run, floor, turn, a, b, expected in cases:
    outcomes = []
    for attempt in (a, b):
        row = next(r for r in sl if r['run_id'] == run and r['floor'] == floor and r['attempt'] == attempt)
        turns = row['summary']['turns']
        index = next(i for i, t in enumerate(turns) if t['turn'] == turn)
        start, end = turns[index:index + 2]
        hp = lambda t: int(re.search(r' (\d+)/\d+', t['enemies'])[1])
        outcomes.append({'attempt': attempt, 'source_sl_line': row['line'], 'start': start, 'next': end,
                         'hp_loss': start['hp'] - end['hp'], 'net_enemy_loss': hp(start) - hp(end)})
    assert [(r['hp_loss'], r['net_enemy_loss']) for r in outcomes] == expected
    comparisons.append({'run': run, 'floor': floor, 'turn': turn, 'outcomes': outcomes,
                        '限制': '轮初端点净变化；不是逐来源毛伤或保持后继不变的整战反事实'})

segments = {}
previous = {}
for state in states:
    if state['screen'] != 'COMBAT' or not state['turn']:
        continue
    key = (state['run'], state['floor'])
    attempts = segments.setdefault(key, [[]])
    if key in previous and state['turn'] < previous[key]:
        attempts.append([])
    attempts[-1].append(state)
    previous[key] = state['turn']
ken = segments[('KEN58SH9SLZ6', 17)]
assert len(ken) == 6
assert all(s[0]['hp'] == 75 and s[0]['max_hp'] == 86 and s[0]['potions'] == [] for s in ken)
dex = [next(s for s in attempt if s['powers'].get('DEXTERITY_POWER') == 2) for attempt in ken]
assert [s['turn'] for s in dex] == [3, 5, 5, 5, 5, 9]
by_line = {s['line']: s for s in states}
before, after = by_line[279559], by_line[279560]
assert [before['enemies'][0]['hp'], after['enemies'][0]['hp']] == [327, 342]
assert [before['enemies'][0]['powers']['POISON_POWER'], after['enemies'][0]['powers']['POISON_POWER']] == [15, 14]

ds = {x['line']: x for x in map(json.loads, (OUT / 'evidence/decisions.evidence.jsonl').open())}
additional_pairs = []
for run, floor, turn, a, b in [('751FN9QM9MHQ', 17, 13, 1, 6), ('KV0JHNJCKXLS', 33, 5, 4, 5)]:
    rows = [e for e in ds.values() if e['run_id'] == run and e['row'].get('floor') == floor and
            e['row'].get('turn') == turn and e['row'].get('label') == 'combat/plan-choice']
    aa = next(e for e in rows if e['row'].get('sl_attempt') == a)
    bb = next(e for e in rows if e['row'].get('sl_attempt') == b)
    assert aa['row']['fingerprint'] == bb['row']['fingerprint']
    additional_pairs.append({'run': run, 'floor': floor, 'turn': turn, 'decision_lines': [aa['line'], bb['line']],
                             'same_fingerprint': True})
result = {'local_comparisons': comparisons, 'additional_fingerprint_pairs': additional_pairs,
          'ken_boss_entries': [s[0] for s in ken], 'ken_dex_first_observed': dex,
          'kv_heal_endpoints': [before, after],
          '限制': '独立事实复核，不运行生产模拟器、不拟合权重，不把同局SL当独立样本。'}
(OUT / 'local-facts.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('六组净端点、两组补充指纹、六次空栏入口、能力建立轮和回血端点核对通过；不是生产测试。')

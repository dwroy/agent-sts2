import bisect
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', OUT.parents[2] / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


streams = {}
checks = []
for manifest in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
    stream = manifest['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
    rows = []
    counts = collections.Counter()
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for line in path.open():
            entry = json.loads(line)
            source.seek(entry['offset'])
            raw = source.read(entry['bytes'])
            assert hashlib.sha256(raw).hexdigest() == entry['sha256']
            assert json.loads(raw) == entry['row']
            assert entry['offset'] + entry['bytes'] <= manifest['source_size']
            assert extract.run_identity(entry['row']) == entry['run_id']
            counts[entry['run_id']] += 1
            rows.append(entry)
    assert all(counts[run] == n for run, n in manifest['counts'].items())
    streams[stream] = rows
    checks.append({'stream': stream, 'verified_rows': len(rows), 'source_size': manifest['source_size'],
                   'counts': manifest['counts'], 'output_sha256': manifest['output_sha256']})
save('byte-verification.json', {'streams': checks, 'verified_rows': sum(len(x) for x in streams.values())})


def powers(obj):
    return {p['power_id']: p.get('amount') for p in obj.get('powers', [])}


def compact(entry):
    state = entry['row']['state']
    combat, run = state.get('combat') or {}, state.get('run') or {}
    player = combat.get('player') or {}
    return {'line': entry['line'], 'run': entry['run_id'], 'ts': entry['row']['ts'],
            'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'), 'block': player.get('block'),
            'powers': powers(player),
            'potions': [[p.get('slot_index', p.get('index')), p.get('potion_id')] for p in run.get('potions', []) if p.get('occupied')],
            'hand': [[c.get('index'), c.get('card_id'), c.get('block')] for c in combat.get('hand', [])],
            'enemies': [{'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                         'alive': e.get('is_alive'), 'move': e.get('move_id'), 'intents': e.get('intents'),
                         'powers': powers(e)} for e in combat.get('enemies', [])]}


states = {e['line']: e for e in streams['states']}
decisions = {e['line']: e for e in streams['decisions']}
save('compact-states.json', [compact(e) for e in streams['states']])
selected_lines = [272361, 272362, 272434, 272575, 272531, 272652, 274087,
                  274131, 274156, 274185, 274235, 274237, 274267, 274272,
                  274354, 274484, 274505, 274568, 274601]
selected = []
for number in selected_lines:
    entry = decisions[number]
    row = entry['row']
    result = {k: row.get(k) for k in ['run_id', 'floor', 'turn', 'sl_attempt', 'chosen', 'result',
                                     'answers', 'sl_explore', 'rationale', 'confidence']}
    result.update(line=number, source_offset=entry['offset'], source_bytes=entry['bytes'], sha256=entry['sha256'])
    criteria = row.get('questions', {}).get('plan', {}).get('criteria', {})
    result['criteria'] = {k: json.loads(v) if isinstance(v, str) and v.startswith('{') else v for k, v in criteria.items()}
    selected.append(result)
save('selected-decisions.json', selected)

pairs = []
for a, b in [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601)]:
    ra, rb = decisions[a]['row'], decisions[b]['row']
    assert ra['run_id'] == rb['run_id']
    assert ra['fingerprint'] == rb['fingerprint']
    pairs.append({'decision_lines': [a, b], 'run': ra['run_id'], 'floor': ra['floor'], 'turn': ra['turn'],
                  'same_fingerprint': True, 'sl_attempts': [ra.get('sl_attempt'), rb.get('sl_attempt')],
                  'fingerprint_sha256': hashlib.sha256(ra['fingerprint'].encode()).hexdigest()})
save('paired-fingerprints.json', pairs)

before, after = compact(states[280160]), compact(states[280161])
assert [before['hp'], before['block'], before['enemies'][0]['powers']['POISON_POWER']] == [26, 13, 2]
assert [after['hp'], after['block'], after['enemies'][0]['powers']['POISON_POWER']] == [26, 13, 8]
assert before['enemies'][0]['intents'] == after['enemies'][0]['intents']
assert before['enemies'][0]['intents'][0]['damage'] == 41
save('giant-poison-endpoints.json', {'before': before, 'after': after, '结论边界': '仅本次实际饮用的可见端点，不是提前饮用的反事实'})

potion_windows = []
for a, b in [(280206, 280207), (280232, 280233), (280262, 280263), (280313, 280314),
             (280315, 280316), (280348, 280349), (280354, 280355)]:
    ra, rb = states[a]['row']['state'], states[b]['row']['state']
    pa = {p['index']: p['potion_id'] for p in ra['run']['potions'] if p.get('occupied')}
    pb = {p['index']: p['potion_id'] for p in rb['run']['potions'] if p.get('occupied')}
    removed = {k: v for k, v in pa.items() if k not in pb}
    assert len(removed) == 1 and ra['run_id'] == rb['run_id'] == 'KEN58SH9SLZ6'
    potion_windows.append({'before': compact(states[a]), 'after': compact(states[b]), 'removed': removed})
save('ken-potion-windows.json', potion_windows)

sl = []
for entry in streams['sl-attempts']:
    row = entry['row']
    sl.append({'line': entry['line'], **{k: row.get(k) for k in ['run_id', 'floor', 'attempt', 'result', 'turns',
                'start_hp', 'end_hp', 'end_block', 'incoming', 'summary', 'explore']}})
save('attempt-summaries.json', sl)
print(json.dumps({'原字节已核': sum(len(x) for x in streams.values()), '同指纹对照': len(pairs),
                  '药水槽位窗': len(potion_windows), '巨兽端点': [before['line'], after['line']]}, ensure_ascii=False))

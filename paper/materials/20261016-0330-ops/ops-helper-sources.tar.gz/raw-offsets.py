from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
root=Path.cwd();sys.path.insert(0,str(root/'agent/tools/logdb'))
import query
p=root/'ops/codex-ops/record-staging/20261016-0330';run='0BHQCPAF33N6';result={}
with query.logsync.read_lock(str(root/'data/logdb'),shared=True,wait=False) as got:
    assert got,'read lock busy; no sync or replacement requested'
    con=query.connect(str(root/'data/logdb'),threads=1)
    for stream,table,condition in [('states','frames',''),('decisions','decisions',''),('sl-attempts','sl_attempts',''),('run-config','run_config',''),('run-plans','run_plans',''),('runs','runs_raw',''),('brain','llm_calls_raw'," AND src='brain'")]:
        rows=con.execute(f"SELECT off,len FROM {table} WHERE run_id=?{condition} ORDER BY off",[run]).fetchall();result[stream]=[dict(offset=off,bytes=size) for off,size in rows]
    con.close()
(p/'raw-offsets.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:len(v) for k,v in result.items()}))

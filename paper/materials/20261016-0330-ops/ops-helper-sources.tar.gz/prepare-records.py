from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, tarfile
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0330'; pub=r/'paper/materials/20261016-0330-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1; log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut; runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected=[x for x in runs if x['run_id']=='0BHQCPAF33N6']; assert len(selected)==1; row=selected[0]
assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max='17',n_decisions='695',has_postmortem='1',performance_included='1').items()); brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':17} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],run={k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r))); write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==13; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==13
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(z)==set(a)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['evidence','where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['evidence','where','history','notes']}
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert a[ident].get(key)==z[ident].get(key),(ident,key)
 previous=a[ident].get('evidence',[]); later=z[ident].get('evidence',[]); assert later[:len(previous)]==previous; assert all(x['run']=='0BHQCPAF33N6' and x['role']==('repeat' if ident=='silent-0009' else 'support') for x in later[len(previous):])
 for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
 for key,values in a[ident]['where'].items():assert all(value in z[ident]['where'][key] for value in values)
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==20509 and b'## 0BHQCPAF33N6' not in oldlesson and lesson in (r/'notes/lessons.md').read_bytes(); readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged13_rows']=True; readback['parallel_physical_rows_preserved']='Only own chapter and13 original CLI rows staged; other root records and pre-existing whitespace differences remain physical/uncommitted.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0330原031301复盘0BHQCPAF33N6 done0闭环，无新增纯bug，不追加重复修复队列或复派。七流1429原行经既有只读logdb偏移逐bytes/SHA/JSON/显式身份核，原来源行号保留为学习者报告值；Silent A10/F17负局、695决策/704状态/17原accepted Codex Sol6.1/xhigh。八赢战及六终战尝试分列，前五SL轮末截断、末试7HP7挡对18攻完整需损11/实际扣7，不封顶替换需求或假造提前启毒胜线。正式20509字节单次追加章与旧物理前缀SHA核，30原材料检查非生产测试；13所属CLI含八旧项补证（0009一次repeat、七support）及五提案追溯，私有fold旧claim/首证/prior/status/version及证据前缀保，不重复CLI或新增shipped。原b1b5a008/4e06d8a8两提案SHA沿原策略链pending；本局六毒模板不当六独立局，T9参考分歧与1/1200、0/1200及原HP护栏未知保持。原脑用量初稿误读顶层snake_case为0、正式嵌套camelCase3024731入/21288出/1094016缓存/18462推理及原重建草稿均保，不当产品故障。当前三源码引用不复原运行dirty知识；原cfa1启动先于R365，不作自然消费者，逐击/过量/前五SL/未选后继/完整候选/时钟及后续Boss/纯战斗耗时/Jev缓存/实付账单未知保持。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0、cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性/keyscan CLEAN，本局has_postmortem1/695决策/17成功Codex入表；原计数告警与成本独立cut估计非账单保留。仅所属复盘/13CLI/生成表及证据提交，保并行物理记录/旧空白差，无代码/知识/版本/补测/派发/对局重启/账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261016-0330-ops/。\n'
note=f'\n- {at} [ops 学习闭环] 0BHQCPAF33N6复盘及13所属CLI已核，无新增纯bug；0009一次repeat与七项support、两原提案沿策略链，未知后继不补造。论文唯一刷新exit0、{len(runs)}局、五一致性/keyscan通过；本局早于R365，不作其自然消费者。回执paper/materials/20261016-0330-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in p.glob('*.py'):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortem='0BHQCPAF33N6',original_rows_checked=1429,original_lesson_bytes=20509,new_bug=False,owned_ledger_rows=13,evidence_updates=8,repeat_evidence=1,support_evidence=7,proposal_links=5,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=13,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

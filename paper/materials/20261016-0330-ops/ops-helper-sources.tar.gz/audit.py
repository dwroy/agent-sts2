from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0330';pub=r/'paper/materials/20261016-0330-ops';pub.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
bid='20261016-031301';run='0BHQCPAF33N6';s=r/'learner/runs/20261016-031304-e7ac4d3a-2aa3-48d0-ae2e-b8f14adadb93-postmortem';report=load(s/'report.json');b=load(r/'ops/codex-ops/learn.json')['batches'][bid]
assert report['appended']==[run] and report['bugs']==[] and report['ledger']['added']==[] and report['ledger']['repeats']==['silent-0009'] and len(report['ledger']['updated'])==8 and report['ledger']['check']==0
assert b['state']=='done' and b['rc']==0 and b['done']==[run] and b['missing']==[] and b['proposal_audit_errors']==[]
out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output)
spec=importlib.util.spec_from_file_location('raw_identity',r/'learner/extract_evidence.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
for name,entry in load(s/'artifacts-manifest.json').items():assert len((s/name).read_bytes())==entry['bytes'] and sha((s/name).read_bytes())==entry['sha256']
offsets=load(p/'raw-offsets.json');refs=[];counts={};runrow=None;config=None;brains=[]
for stream,entries in offsets.items():
    frozen=[json.loads(line) for line in (s/(stream+'.jsonl')).read_text().splitlines()];assert len(frozen)==len(entries)
    with (r/'logs'/(stream+'.jsonl')).open('rb') as original:
        for selected,entry in zip(frozen,entries):
            original.seek(entry['offset']);raw=original.read(entry['bytes']);row=json.loads(raw)
            assert len(raw)==entry['bytes'] and raw.endswith(b'\n') and extract.run_identity(row)==run
            assert row=={k:v for k,v in selected.items() if k!='_source_line'}
            if stream=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
            if stream=='runs':assert row['character']=='SILENT' and row['ascension']==10 and row['floor']==17 and row['victory'] is False;runrow=row
            if stream=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains.append(row)
            if stream=='run-config':config=row
            refs.append(dict(stream=stream,learner_reported_source_line=selected['_source_line'],offset=entry['offset'],bytes=len(raw),sha256=sha(raw)))
    counts[stream]=len(entries)
assert len(refs)==1429 and counts['decisions']==695 and counts['states']==704 and len(brains)==17
assert load(s/'deepseek-window-check.json')['matches']==0
post=load(s/'validation-after-append.json');before=load(s/'validation-before-append.json')
assert post['appended'] and len(post['checks'])==30 and len(before['checks'])==29 and post['checks'][:-1]==before['checks']
physical=(r/'notes/lessons.md').read_bytes();assert sha(physical[:post['prefix_bytes']])==post['prefix_sha256']
lesson=(s/'lesson-draft.md').read_bytes();assert len(lesson)==post['section_bytes']==20509 and sha(lesson)==post['section_sha256']
assert physical[post['prefix_bytes']:post['prefix_bytes']+len(lesson)]==lesson and physical.count(b'## 0BHQCPAF33N6')==1;(p/'owned-lessons.md').write_bytes(lesson)
source=load(s/'source-manifest.json')
for path,entry in source.items():
    if path=='live_head':continue
    copy=(s/path.replace('/','__')).read_bytes();assert len(copy)==entry['bytes'] and sha(copy)==entry['sha256'] and copy==subprocess.check_output(['git','show',source['live_head']+':'+path])
assert (s/'source-diff.patch').read_bytes()==b''
stats=load(s/'stats.json');assert stats['brain_usage']==dict(inputTokens=3024731,outputTokens=21288,cacheHitTokens=1094016,reasoningTokens=18462)
assert all(sum(row['usage'][key] for row in brains)==value for key,value in stats['brain_usage'].items())
assert stats['fallback']==0 and stats['brain_latency_ms']==sum(row['latency_ms'] for row in brains)
ids=set(report['ledger']['updated']);owned=[];ledgerrefs=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('by')=='learner:postmortem' and row.get('id') in ids and (any(e.get('run')==run for e in row.get('evidence',[])) or str(s) in raw.decode() or run in row.get('where',{}).get('lessons',[])):
            assert row['op']=='update' and set(row)<={'op','id','ts','by','evidence','where','note'}
            assert all(e['run']==run and e['role']==('repeat' if row['id']=='silent-0009' else 'support') for e in row.get('evidence',[]))
            owned.append(raw);ledgerrefs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==13 and sum('evidence' in json.loads(raw) for raw in owned)==8 and sum(e['role']=='repeat' for raw in owned for e in json.loads(raw).get('evidence',[]))==1
inputs=[json.loads(line) for line in (s/'ledger-updates.jsonl').read_text().splitlines()];assert len(inputs)==8
for item in inputs:assert any(all(row.get(k)==v for k,v in item.items()) for row in [json.loads(raw) for raw in owned])
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'owned-ledger-references.json',ledgerrefs)
spec=importlib.util.spec_from_file_location('original_proposals',r/'learner/code_proposals.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);queue=m.fold(r/'paper/materials/learning/code-proposals.jsonl');proposals=[]
for ident in report['code_proposals']:
    item=queue[ident];f=Path(item['proposal']);assert item['character']=='silent' and item['runs']==[run] and item['source_task']=='postmortem' and item['target_task']=='strategy-proposal' and sha(f.read_bytes())==item['proposal_sha256']
    proposals.append({k:item.get(k) for k in ['id','state','proposal','proposal_sha256','ledger','implemented_commit']})
assert config['code']['commit']=='cfa1c0be88147b4eac65c13d8c550b23ed4eef17'
write(pub/'postmortem-original-references.json',refs)
write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,native=native,original_rows_checked=1429,stream_counts=counts,raw_binding='Read-only existing logdb offsets; actual original JSON and run identity verified. Source line numbers retained as learner-reported, not inferred from database row numbering.',actual_accepted_codex=17,original_run_row=runrow,actual_run_config=config,source_reference=source,source_reference_does_not_reconstruct_run_dirty_knowledge=True,post_append=post,original_lesson_bytes=20509,old_lesson_prefix_preserved=True,original_ledger_rows=13,new_ledger_ids=[],old_support_ids=[x for x in report['ledger']['updated'] if x!='silent-0009'],repeats=['silent-0009'],original_proposals=proposals,new_bug=False,material_stats_initial_retained='Initial snake_case top-level brain usage zero was corrected against nested camelCase usage; initial materials and reconstructed draft retained, not a product failure.',limits='Per-hit/overkill and first five SL exit tails, unchosen routes/early-poison/full successors, whole-candidate realization, dirty knowledge inputs, calibrated clocks/unvisited Boss, pure combat time, Jev cache and paid invoices remain unknown. This cfa1-started run is not an R365 natural consumer.'))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);print(json.dumps(dict(rows=1429,ledger_rows=13,lesson_bytes=20509,new_bug=False)))

import pathlib,json,subprocess,hashlib,collections,datetime
P=pathlib.Path(__file__).parent
R=json.loads((P/'0BHQCPAF33N6-resources.json').read_text())
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
S=[json.loads(x) for x in (P/'states.jsonl').open()]
B=[json.loads(x) for x in (P/'brain.jsonl').open()]
T=json.loads((P/'turns.json').read_text())
now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
text='''

## 0BHQCPAF33N6（A10，静默猎手，第17层，死于一幕boss仪式兽 CEREMONIAL_BEAST：六次均53/70进场，前五次判死读档，末次T13以7血、7挡对虚弱后18跺地阵亡，完整需损11、差4血；6毒结算后敌仍93/262血）

- [计划用毒药水启毒，六次却都拖到判死轮；打法（DeepSeek构筑栏，实际Codex／Jev出牌，含代码模型覆盖）] F14大脑买毒药水（POISON_POTION）、咕嘟冒泡（BUBBLE_BUBBLE）时原话为“Reserve Poison to enable Bubble’s repeatable boss scaling.”（d404385）；F16仍要求用药启毒。仪式兽（CEREMONIAL_BEAST）六次尝试分别直到T18／16／18／18／14／13才喝毒，之前敌人一直无毒，冒泡全场施放0次；末试T7还将它弃掉（d404800）。每次药水实加6毒、当步不扣敌血，前五次随即SL而没有结算，末试只实扣6，99→93，仍死亡。毒药水一直以合法但未模拟的单独饮用项出现，不是按钮缺失；当前只读live的observedPoison条件入口见agent/src/reflex/combat-plan.ts:3241、card-model.ts:1878，仅作当前覆盖定位。这里重现的是“启毒计划未兑现”，本局没有对无毒敌人空打冒泡；未实打提前喝药后继，不能说早喝足以赢，另存限定代码提案。（之前学过：silent-0009，S1.exp201）
- [短程少死样本与整场参考分歧，空过不能写成已证保血；打法（Jev出牌／代码参考排序）] 末试F17T9（d404806）仪式兽121血，玩家22血、3能量，打击（STRIKE_SILENT）＋小刀（SHIV）方案报14伤／当轮损0，直接结束报0伤／损0。五轮死亡为24/24对20/24、短程更偏好结束；整场攻击线实际模拟1/1200胜、结束线0/1200胜，题面四舍五入都写“win 0%”，不能写成两线均零胜样本。S参考攻击−0.127078、结束−0.152033，配对结束减攻击−0.024955±0.002202（均值标准误），仍只属条件模型。Jev以0.67选结束，rollout_best_chosen=false；实22血不变、敌仍121。与旧0472“无当轮血价而空过”的观察相似，但旧例是实验体且按最佳参考，本例所选不是整场参考第一，故只加support，不冒称同一错误repeat、固定强制出刀或已定位纯bug；配对完整后继另提案核验。（之前见过：silent-0472）
- [休息补回的是前序消耗，必须连同赢战和商店回血核算；打法（DeepSeek路线／休息栏，实际Codex）] F5低语空洞（WHISPERING_HOLLOW）变防御（DEFEND_SILENT）为计算下注（CALCULATED_GAMBLE）实付9血，56→47；F6雾菇（FOGMOG）／利齿之眼（EYE_WITH_TEETH）赢仍损23，F7毛绒伏地虫（FUZZY_WURM_CRAWLER）／缩小甲虫（SHRINKER_BEETLE）赢仍损21，至首火只3血。F8／12／16实际各回21，F14餐券（MEAL_TICKET）另回15；F15多尼斯异鸟（BYRDONIS）43→32后才休到53进王，带骨肉（MEAT_ON_THE_BONE）是此战后取得，未把该战32血再抬高。不能把53血入口说成满资源或把休息无升级归为已证失误；没有保留事件9血、其他路线或锻造的整战对照，本条为旧经验补证，不记repeat。（之前学过：silent-0020，S1.exp203）

- [记录] 复盘时间：TIME。runs.jsonl:794确认SILENT／A10／victory=false／F17／code=current；这只是汇总字段，run-config另记启动源码cfa1c0be88147b4eac65c13d8c550b23ed4eef17（cfa1c0b+dirty），含知识刷新，不能用“current”还原完整历史dirty知识。本次file:line按只读live e716bd28fd8eca9e4d76d066680304fd11935e37；两个引用源码叶与启动提交并不逐字节相同，已保存当前叶、SHA及git diff，不倒填为原局精确源码。已读唯一notes/run-1016-0301-0BHQCPAF33N6.md；本局695决策、704状态、5计划、6条SL尝试、17条brain请求均按局号抽出，原始行号保留在本任务目录。决策窗2026-10-15T18:21:55.411Z—19:00:50.984Z；deepseek-reasoning从文件尾seek核末条2026-10-06T23:38:26.270Z，早于本窗，窗内无记录。实际大脑17次均accepted的Codex gpt-6.1-sol／xhigh，22条codex决策包含计划续步；“DeepSeek”是职责与兼容字段名，本局不是DeepSeek实际调用。

  实盘资源链：下表HP均为进场→实际出口，最大HP全程70；槽0／槽1之外没有药。D＝敏捷药水 DEXTERITY_POTION，S＝力量药水 STRENGTH_POTION，E＝爆炸安瓿 EXPLOSIVE_AMPOULE，C＝稳定血清 STABLE_SERUM，P＝毒药水 POISON_POTION，U＝复制药水 DUPLICATOR；∅为空栏。s／d／sl分别为logs/states.jsonl、decisions.jsonl、sl-attempts.jsonl原始行号。全部窗口首帧均T1；非首领八场均由REWARD出口及领奖确认获胜，首领前五次缺真正战斗出口，不当死亡结算或回血。

RESOURCE_TABLE

  场间来源逐段：F1药瓶皮套 PHIAL_HOLSTER给出槽0 D、槽1 S，HP仍56；F2／F3／F4三场赢战均无损，F2奖励补槽1 E、F4奖励补槽1 C。F5事件付9血后，F6→F7两个赢战依次47→24→3，F8休息3→24；F9方柱构装体 CUBEX_CONSTRUCT赢24→14，F10宝箱取餐券不即时回血，F11“这个或那个” THIS_OR_THAT取摆动球 PENDULUM并添笨拙 CLUMSY，HP仍14，F12休息14→35。F13赢35→28，F14进商店餐券实28→43，买槽0 P、槽1 U及冒泡、切割 SLICE，不再回血；F15赢43→32、喝掉U，战后补槽1 S并获得带骨肉，离店／领奖后并无额外回血，F16休息32→53，F17六次入口均53且槽0 P／槽1 S。三次HEAL合63、餐券15；SL各恢复34／42／50／52／47血与P＋S，是存档资源恢复，全部单列，不计治疗或新获药。F15→F16→F17是实盘连续链；未记录另一条路线的胜负，不从反事实省血／留药断言可过王。

  逐轮伤害与需求：下表“需”是每个玩家回合首帧存活敌血池，“扣”是到后继帧可逐体核对的可见扣血下界，含实际毒，不能冒充逐击毛伤／过量伤。“损”是玩家净HP损失，末次死亡只实扣剩余7，完整需求另为11；前五次末轮的0只表示SL前未再损血，敌方响应未派发、真实轮末损失未记录。F6T1另外出现6血利齿之眼，不能把78初始血当全场总需；它在T7被明确打到0，雾菇剩3后消失缺尾击。其他消失帧也不擅自把残血算入实际伤害。

DAMAGE_TABLE

  消失尾击限制：F2末5、F3T1两小史莱姆末5／9与T2中史莱姆末5、F4末4、F6雾菇末3、F7T10毛绒伏地虫末3及T15甲虫末2、F9末4、F13T3树叶史莱姆末18及T9飞蝇菌子末5、F15末2均缺归零中间帧，胜利由出口核；这里不从消失量补齐“扣”。首领每轮都能对齐同一实体；末次总实扣169＝262−93，其中末轮6来自毒，仍需93。首试总可见扣218、SL时仍44；其余四次SL前仍98／43／34／52，不是已击杀或实死。

  首领尝试与SL：六次分别至T18／16／18／18／14／13，sl2245—2250；前五次末盘HP／挡／来袭为19／7／29、11／8／20、3／7／29、1／7／29、6／7／25，净攻击需求依次22／12／22／22／18，超过当时HP分别3／1／19／21／12。第二次在least-loss线派发之前就读档，其余四次在结束动作前读档；不能替它们补尚未结算的6毒或致死扣血。末次s417939—417942是7血、7挡、18攻击，需11且实扣7；毒99→93之后GAME_OVER，无复活。五次reload均ok，全部从T1恢复，首领并非只有自动局报中的一个合并战斗。SL有替换与抽牌后重问：如d404725把第五次T2三防御换连续反弹 RICOCHET＋手上技法 HAND_TRICK，实53→42、敌240→220；第三／四／五次开头重放与最后T1换线详见原SL字段，不能把最初Jev回答视为完整执行结果。没有新增SL门槛建议。

  构筑、路线与休息：F1原话“前三战补输出，双精英后接营火，晚店集中补强。”（d404129），奖励F2取铭记死亡 MEMENTO_MORI、F3偏折 DEFLECT、F4扫腿 LEG_SWEEP，F5事件得计算下注，F6取灵动步法 FOOTWORK后改线跳过F11精英，最终仅F15一场精英。F7取斗篷与匕首 CLOAK_AND_DAGGER，F8用“immediate survival outweighs every upgrade”选回血（d404300）；F9跳牌；F11事件保血取遗物；F12优先回到35并明确餐券进店回复；F13取手上技法补防御；F14商店四项205金＝P48＋冒泡36＋切割49＋U72（d404385—404388）。F15取连续反弹，原计划承认“Ricochet offers partial help, not proven survival.”（p3766），F16再回到53，没有任何锻造。终局牌组23张、全部未升级，五打击／四防御仍在；取防御组件有自己的成对模拟理由，不把单局失败倒推为都不该拿。F16独立计划脑明确“No calibrated damage gap is available.”（p3767），不能把F15诊断缺口当已校准时钟。

  Jev与代码：284次Jev低信心＜0.35共19＝战斗选线8＋单行动4＋弃牌选择7；256道战斗方案题rollout_best_chosen真217／假39，原回答选参考最佳比例217/256＝84.77%，不代表HP护栏、支配替换、SL改线及抽牌重问后仍兑现完整候选。原始decider为code389／jev284／codex22，其中code的271条plan-continue有247条沿Jev计划、24条沿代码计划，局报因此重分为code142／jev-plan247。代码自主战斗主决策63条＝plan44＋lethal9＋least-loss1＋end_turn9，含5条SL未派发；实际执行58条、涉及47个（层／尝试／回合）窗口；包含未派发则52窗口，全局实际观察153个战斗回合窗口。同轮仍可有Jev回答，不能把63或142都叫“代码独占回合”。

  目标与focus：显式focus共15题31项；F3T1三个史莱姆方向，实爆炸安瓿后同一边界两小史莱姆消失、顺序未记录，中史莱姆T2退场。F6先杀利齿之眼（T7实至0），再结束雾菇；F7九题含双目标focus，d404237原选毛绒伏地虫，实该虫T10先退、甲虫T15后退，残血尾击缺帧，不据focus直接倒填击杀。F13五题双目标，树叶史莱姆中 LEAF_SLIME_M在T3退，飞蝇菌子 FLYCONID在T9退；d404351／404352都在生成／选择后重问，原方案不等于整轮实线。首领只有仪式兽，无多敌击杀顺序或focus比较。

  HP护栏仅两次、都在首试F17：T7 d404480原选打击／斗篷／生存者 SURVIVOR预测损12、伤8，替为打击／铭记死亡／打击预测损0、伤27；模型少12血且多19伤，代价是没有原线生存者抽弃与斗篷生成后继，未实打原线，不能宣称实省12。替代线实34→34、敌179→152，端点吻合。T16 d404508原选打击／铭记死亡／生存者预测损17、伤19，替防御／扫腿预测损0、伤0，模型少17血但少19伤、保留2虚弱；实19→19、敌68未变，二线五轮均8/8死亡，模型省血不是整战获胜。两次模型省血合29、伤害净差0只作账目，不能把正负代价抵销后宣称无代价；与silent-0125旧取舍观察补证。两次均非纯bug。另有低信心支配替换，和这两次HP护栏分账。

  推演／实际：除护栏替代线的完整端点外，末试T3攻击线预测27伤／损22，实敌221→194、我53→31；T4打击／偏折／防御／手上技法预测的当轮端点另保留原题，实敌194→186、我31→29。T5切割／连续反弹后重问中和／打击，共实41伤，186→145，越阈值后眩晕而损0；不拿最初只含两牌的候选独占全41伤。T9结束线预测0伤／损0，实22／121均不变；攻击替线14没有实打。首试T7短程所谓约49%胜机会其实五轮内0/8真胜，含末端外推；同题整场首选0/200真胜，不把它当观测胜率或靠49%宣称护栏杀掉胜线。

  药水：非SL真实取得7瓶，来源F1赠D／S两瓶、F2奖E、F4奖C、F14购P／U、F15奖S；不把SL十瓶恢复算十瓶新增。共17次实际use_potion＝王前5次＋首领六次各2，discard_potion为0、事件支付药为0；一条原始首试路径加终战只消耗原7瓶，五次SL另恢复并重喝10。王前饮用是F2T1槽1 S（d404130，s417243→417244）、F3T1槽1 E（d404157）、F6T2槽1 C（d404200）、F7T5槽0 D（d404248）、F15T1槽1 U（d404395，后续复制手上技法而非步法，不能写成已复制灵动步法）。首领每次T1喝槽1 S，槽0 P到各次末轮才喝，动作行依次d404450／404516、404518／404577、404581／404646、404650／404714、404718／404768、404771／404819，清槽与实际加层均有后继帧；前五次毒6未结算即SL，末次结算6。奖励／购买补槽与饮用、弃药、恢复分账；未提出固定早喝或留药阈值，代码提案只核已有毒量、条件与同盘后继。

  路线投影：F2选牌题b14889仍走原线，投影F8入口44、实3；期间F5付血、两场赢战损耗及F6改线分别记录，不把偏差归于同一原因。F6改线决策明确新线F15精英入口57（p75 40）、实43；旧F11精英未走。F8已选HEAL后投影F15入口39、F17入口38（b14895），实43／53；F12已选HEAL后的F15投影32、F17投影31（b14898），实43／53，期间餐券实回15、实际普通战及精英损耗与房间参考不同。不能混入未回血基础投影中的0血耗尽。F16HEAL题b14902独立after_action_hp／projected_boss_hp／simulated_entry_hp均53，实入王53。未走路线、其他选择及留药整战结果未记录。

  boss时钟：act_boss_clock明确“尚无 silent 的 boss 时钟校准”，deck_damage_per_turn_estimate／hp_loss_per_turn／survivable_turns／gap_per_turn均null，需要／估计及实打／校准估值比均未记录；本体参考262已被实盘确认。F15诊断进攻缺口中位9.1只是线性敏感度诊断，非校准需求。F16回血选项另有300样本、原始0胜、模拟终止均11.18轮、有效DPR均14.2673，总伤均158.2533；实际末试13轮169伤（均13.00/轮），即169/158.2533＝1.0679只是一条实死轨迹与该条件均值的描述，既非同牌序配对也非校准。六次末状态及SL截断不同，不用前五次未结算死亡去算打穿率。

  机制：本局限定补证旧机制，不另造通则。灵动步法 FOOTWORK在末试T1实建2敏捷，力量药水实建2力量；后续防御基础5→7、偏折4→6、斗篷6→8，多牌分别兑现增量，末T13的7挡仍不足18攻击，缺4血不是“没有敏捷”。2力量使切割6→8、打击6→8、连续反弹每击3→5（四击20）；末试T1切割实扣8（s417893→417894）、计算下注换手但敌血不变、连续反弹实扣20（s417895→417896），合28。仪式兽本局横冲直撞 PLOW_POWER显示阈值160，T3力量2时22攻、T5力量6时26攻；T5实186→145，越阈值当步清力及横冲直撞并改STUNNED，0挡仍损0，不能把旧A0的150阈值硬套到A10。之后力量重新增长，末T13力量8、虚弱1显示18攻；跨阈值不等于胜利。兽吼后RINGING_POWER1的T13只打出一张防御，余2能量、剩余牌均不可用，随后仍能饮P；饮用当步加6毒但敌99不动，结束后毒使99→93且我死亡。补证silent-0005／0133／0222／0278，既有claim、首证、prior、状态及上线版本保持，尤其0133原150只属其A0观察，本文160属本局A10，不跨进阶改写。

  用量与限制：首末决策2335.573秒＝38.93分钟；进程启动18:20:51.192Z到结束19:00:50.984Z为2399.792秒，纯战斗耗时未记录。Jev输入2421985／输出14208，共2436193＝runs.tokens；17次Codex脑输入3024731／输出21288，其中推理18462，缓存命中1094016/3024731＝36.17%，累计请求延迟626932毫秒，已包含独立run-plan输入144110／输出2366，不重复相加。Jev缓存命中与实付账单未记录，旧局报约价不当实际账单；fallback全false。其他未记录项为消失尾击／完整逐击毛伤与过量伤、前五次SL真实轮末结算、未选路线／提前启毒及攻击替线的完整实战后继、完整候选兑现率、启动dirty知识完整快照、校准boss时钟与未到后续首领。三条经验分别记0009 repeat、0472 support、0020 support，机制与护栏条目另补support；出牌／药水提案交独立strategy-proposal，本任务只写记录，未改代码、未实现或上线、不提交、不推送。
'''.replace('TIME',now)
rows=['  | 战斗（按实际顺序，含赢战） | HP／净损 | 药槽进→出或SL前末态 | 证据s／结束 |','  | --- | --- | --- | --- |']
labels={2:'F2 缩小甲虫 SHRINKER_BEETLE',3:'F3 树枝小 TWIG_SLIME_S／树叶中 LEAF_SLIME_M／树叶小 LEAF_SLIME_S',4:'F4 小啃兽 NIBBIT',6:'F6 雾菇 FOGMOG／利齿之眼 EYE_WITH_TEETH',7:'F7 毛绒伏地虫 FUZZY_WURM_CRAWLER／缩小甲虫 SHRINKER_BEETLE',9:'F9 方柱构装体 CUBEX_CONSTRUCT',13:'F13 树叶中 LEAF_SLIME_M／飞蝇菌子 FLYCONID',15:'F15 多尼斯异鸟 BYRDONIS'}
short={'DEXTERITY_POTION':'D','STRENGTH_POTION':'S','EXPLOSIVE_AMPOULE':'E','STABLE_SERUM':'C','POISON_POTION':'P','DUPLICATOR':'U'}
def belt(v):return '、'.join(str(a)+short[b] for a,b in v) or '∅'
for c in R['combats']:
 e=c['entry'];out=c.get('exit') or c['last'];label=labels.get(c['floor'],f"F17 仪式兽第{c['sequence']-8}试")
 loss=e['hp']-out['hp'];note=f"净损{loss}" if c.get('exit') else f"SL前已损{loss}；出口未记录"
 ending='胜' if c['floor']<17 else ('实际死亡' if c.get('exit') else '判死读档')
 rows.append(f"  | {label}，T1—{out['turn']} | {e['hp']}→{out['hp']}／{note} | {belt(e['potions'])}→{belt(out['potions'])} | {e['line']}→{out['line']}，{ending} |")
text=text.replace('RESOURCE_TABLE','\n'.join(rows))
rows=['  | 战斗 | 各轮需 | 各轮可见扣血下界 | 各轮我方净损 |','  | --- | --- | --- | --- |']
for c in T:
 a=c['floor'];label=f"F{a}" if a<17 else f"F17第{c['seq']-8}试"
 arr=lambda k:'／'.join(str(t[k]) for t in c['turns'])
 rows.append(f"  | {label} | {arr('need')} | {arr('visible_damage')} | {arr('net_hp_loss')} |")
text=text.replace('DAMAGE_TABLE','\n'.join(rows))
(P/'lesson-draft.md').write_text(text)
print('初稿字节',len(text.encode()),'生成时间',now)

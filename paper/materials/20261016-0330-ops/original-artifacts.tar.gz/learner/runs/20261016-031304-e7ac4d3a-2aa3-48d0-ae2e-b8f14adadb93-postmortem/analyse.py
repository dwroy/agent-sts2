import json,pathlib,collections,hashlib,subprocess,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
S=[json.loads(x) for x in (P/'states.jsonl').open()]
R=json.loads((P/'0BHQCPAF33N6-resources.json').read_text())
B=[json.loads(x) for x in (P/'brain.jsonl').open()]
SL=[json.loads(x) for x in (P/'sl-attempts.jsonl').open()]
idx={s['_source_line']:s for s in S}
summary=[]
for c in R['combats']:
 first=c['entry']['line']; last=(c.get('exit') or c['last'])['line']; frames=[s for s in S if first<=s['_source_line']<=last]
 turns=[]
 for j,t in enumerate(c['enemy_hp_audit']['turns']):
  start=idx[t['start_line']]; end=idx.get(t.get('end_line'),frames[-1]); state=start['state']; co=state.get('combat') or {}; player=co.get('player') or state.get('player') or {}
  turns.append({'turn':t['turn'],'line':t['start_line'],'hp':state['run']['current_hp'],'end_hp':end['state']['run']['current_hp'],'net_hp_loss':state['run']['current_hp']-end['state']['run']['current_hp'],'need':t['live_enemy_hp_start'],'visible_damage':t['visible_enemy_hp_loss_lower_bound'],'remaining':t.get('live_enemy_hp_end'),'gaps':list({g for a in t['transitions'] for g in a.get('gaps',[])}) if False else t.get('gaps'), 'player':player,'enemies':state.get('enemies',co.get('enemies'))})
 summary.append({'seq':c['sequence'],'floor':c['floor'],'entry':c['entry'],'exit':c.get('exit'),'last':c['last'],'turns':turns})
(P/'turns.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with (P/'turns.txt').open('w') as o:
 for c in summary:
  o.write(str({k:v for k,v in c.items() if k!='turns'})+'\n')
  o.write('需 '+str([t['need'] for t in c['turns']])+'\n扣下界 '+str([t['visible_damage'] for t in c['turns']])+'\n净损 '+str([t['net_hp_loss'] for t in c['turns']])+'\n')
  for t in c['turns']:
   if c['floor']==17:o.write(json.dumps(t,ensure_ascii=False)+'\n')
def criteria(d):
 out={}
 for q in d.get('questions',{}).values():
  for k,v in q.get('criteria',{}).items():
   try:out[k]=json.loads(v) if isinstance(v,str) else v
   except ValueError:out[k]=v
 return out
special=[]
for d in D:
 if 'HP guard' in d.get('rationale','') or (d['floor']==17 and d.get('sl_attempt')==6 and d.get('turn') in [6,7,9,11,12,13]):
  special.append({'line':d['_source_line'],'floor':d['floor'],'turn':d['turn'],'attempt':d.get('sl_attempt'),'chosen':d['chosen'],'answers':d.get('answers'),'rationale':d['rationale'],'hp_guard':d.get('hp_guard'),'rollout':d.get('rollout'),'best_chosen':d.get('rollout_best_chosen'),'potions':d.get('potions'),'criteria':criteria(d)})
(P/'special-decisions.json').write_text(json.dumps(special,ensure_ascii=False,indent=2))
stats={'jev_low':collections.Counter(d['label'] for d in D if d['decider']=='jev' and d.get('confidence',1)<.35),'jev_rollout':collections.Counter(str(d.get('rollout_best_chosen')) for d in D if d['decider']=='jev' and d['label'].startswith('combat/plan-choice')),'raw_deciders':collections.Counter(d['decider'] for d in D),'usage':{k:sum(d.get('usage',{}).get(k,0) or 0 for d in D if d['decider']=='jev') for k in ['input_tokens','output_tokens','cache_hit_tokens']},'brain_usage':{k:sum(b.get(k,0) or 0 for b in B) for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens','latency_ms']},'brain_fields':list(B[0]),'brain_models':list({(b.get('engine'),b.get('model'),b.get('effort')) for b in B}),'fallback':sum(bool(d.get('fallback')) for d in D)}
main=[d for d in D if d['decider']=='code' and d['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]
stats['code_main_count']=len(main);stats['code_main_turns']=len({(d['floor'],d.get('sl_attempt',0),d['turn']) for d in main});stats['code_main_results']=dict(collections.Counter(d.get('result') for d in main));stats['all_turns']=sum(len(c['turns']) for c in summary)
(P/'stats.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2));print(json.dumps(stats,ensure_ascii=False))
for c in summary:print(c['seq'],c['floor'],'需',[t['need'] for t in c['turns']],'扣',[t['visible_damage'] for t in c['turns']],'损',[t['net_hp_loss'] for t in c['turns']])
print('state structure',S[-2]['state'].keys()); print('combat keys',S[-2]['state'].get('combat',{}).keys());print('player',S[-2]['state'].get('player')); print('last enemies',S[-2]['state'].get('enemies'))

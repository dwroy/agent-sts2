import pathlib,json,hashlib,subprocess,datetime,collections
P=pathlib.Path(__file__).parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
S=[json.loads(x) for x in (P/'states.jsonl').open()]
R=json.loads((P/'0BHQCPAF33N6-resources.json').read_text())
B=[json.loads(x) for x in (P/'brain.jsonl').open()]
SL=[json.loads(x) for x in (P/'sl-attempts.jsonl').open()]
checks=[]
def check(name,value):
 assert value,name
 checks.append(name)
def frame(n):return next(s for s in S if s['_source_line']==n)['state']
def dec(n):return next(d for d in D if d['_source_line']==n)
check('已结束且角色进阶正确',json.loads((P/'runs.jsonl').read_text())['character'].lower()=='silent' and json.loads((P/'runs.jsonl').read_text())['ascension']==10)
check('决策与状态计数',len(D)==695 and len(S)==704)
check('战斗窗口及全部T1',len(R['combats'])==14 and all(c['entry_is_turn_one'] for c in R['combats']))
check('八场赢战入口出口',[(c['entry']['hp'],c['exit']['hp']) for c in R['combats'][:8]]==[(56,56),(56,56),(56,56),(47,24),(24,3),(24,14),(35,28),(43,32)])
check('首领入口资源',all(c['entry']['hp']==53 and c['entry']['max_hp']==70 and c['entry']['potions']==[[0,'POISON_POTION'],[1,'STRENGTH_POTION']] for c in R['combats'][8:]))
check('前五次缺出口',all(c['exit'] is None for c in R['combats'][8:13]))
check('末次死亡回合及净损',R['combats'][-1]['exit']['turn']==13 and R['combats'][-1]['observed_net_hp_loss']==53)
check('六次末盘',[(x['turns'],x['end_hp'],x['end_block'],x['incoming']) for x in SL]==[(18,19,7,29),(16,11,8,20),(18,3,7,29),(18,1,7,29),(14,6,7,25),(13,0,None,18)])
check('五次读档成功',all(x['reload']['ok'] for x in SL[:5]))
check('末次7血7挡18攻及敌99',frame(417940)['run']['current_hp']==7 and frame(417940)['combat']['player']['block']==7 and frame(417940)['combat']['enemies'][0]['intents'][0]['total_damage']==18 and frame(417940)['combat']['enemies'][0]['current_hp']==99)
check('最后6毒99到93',frame(417941)['combat']['enemies'][0]['current_hp']==99 and frame(417941)['combat']['enemies'][0]['powers'][-1]['amount']==6 and frame(417942)['combat']['enemies'][0]['current_hp']==93)
check('所有毒药饮用当步加6不扣血',all(frame(a)['combat']['enemies'][0]['current_hp']==frame(a+1)['combat']['enemies'][0]['current_hp'] and any(q['power_id']=='POISON_POWER' and q['amount']==6 for q in frame(a+1)['combat']['enemies'][0]['powers']) for a in [417637,417698,417767,417835,417889,417940]))
check('HP护栏两次及代价',[d['_source_line'] for d in D if d.get('hp_guard')]==[404480,404508] and [dec(n)['hp_guard']['predicted_hp_saved'] for n in [404480,404508]]==[12,17] and [dec(n)['hp_guard']['predicted_damage_change'] for n in [404480,404508]]==[19,-19])
check('药水17饮且无丢弃',sum((d.get('chosen') or {}).get('action')=='use_potion' for d in D)==17 and not any((d.get('chosen') or {}).get('action')=='discard_potion' for d in D))
check('冒泡从未施放',not any((d.get('chosen') or {}).get('action')=='play_card' and d.get('expect',{}).get('card',{}).get('id')=='BUBBLE_BUBBLE' for d in D))
check('Jev低信心19及参考217比256',sum(d['decider']=='jev' and d.get('confidence',1)<.35 for d in D)==19 and sum(d.get('rollout_best_chosen') is True for d in D)==217 and sum('rollout_best_chosen' in d and d['decider']=='jev' and d['label'].startswith('combat/plan-choice') for d in D)==256)
check('原始决策者计数',collections.Counter(d['decider'] for d in D)=={'code':389,'jev':284,'codex':22})
check('真实大脑17次正确身份',len(B)==17 and all(b['engine']=='codex' and b['model']=='gpt-6.1-sol' and b['effort']=='xhigh' and b['accepted'] for b in B))
check('Jev用量',sum(d.get('usage',{}).get('input_tokens',0) or 0 for d in D if d['decider']=='jev')==2421985 and sum(d.get('usage',{}).get('output_tokens',0) or 0 for d in D if d['decider']=='jev')==14208)
check('脑用量与缓存',[(k,sum(b.get('usage',{}).get(k,0) for b in B)) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']]==[('inputTokens',3024731),('outputTokens',21288),('cacheHitTokens',1094016),('reasoningTokens',18462)])
check('末次T1切割与反弹',frame(417893)['combat']['enemies'][0]['current_hp']-frame(417894)['combat']['enemies'][0]['current_hp']==8 and frame(417895)['combat']['enemies'][0]['current_hp']-frame(417896)['combat']['enemies'][0]['current_hp']==20)
check('事件实际损9',frame(417305)['run']['current_hp']==56 and frame(417306)['run']['current_hp']==47)
check('三次休息合63',sum(frame(a+1)['run']['current_hp']-frame(a)['run']['current_hp'] for a in [417417,417455,417565])==63)
check('餐券实回15',frame(417503)['run']['current_hp']-frame(417502)['run']['current_hp']==15)
check('末T9空过',dec(404806)['chosen']['action']=='end_turn' and dec(404806)['rollout_best_chosen'] is False and frame(417927)['run']['current_hp']==frame(417928)['run']['current_hp']==22)
check('A10阈值160与眩晕',any(x['power_id']=='PLOW_POWER' and x['amount']==160 for x in frame(417911)['combat']['enemies'][0]['powers']) and frame(417915)['combat']['enemies'][0]['move_id']=='STUNNED' and frame(417915)['combat']['enemies'][0]['current_hp']==145)
lesson=pathlib.Path('/home/dw/Projects/agent-sts2/notes/lessons.md');draft=(P/'lesson-draft.md').read_text()
check('初稿三条经验',sum(l.startswith('- [') and not l.startswith('- [记录]') for l in draft.splitlines())==3)
check('原文件无重复标题',not any(l.startswith('## 0BHQCPAF33N6') for l in lesson.open()))
check('没有占位符',all(w not in draft for w in ['RESOURCE_TABLE','DAMAGE_TABLE','TIME']))
size=lesson.stat().st_size;h=hashlib.sha256()
with lesson.open('rb') as f:
 while b:=f.read(1024*1024):h.update(b)
meta={'prefix_bytes':size,'prefix_sha256':h.hexdigest(),'section_bytes':len(draft.encode()),'section_sha256':hashlib.sha256(draft.encode()).hexdigest(),'checks':checks}
(P/'validation-before-append.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
subprocess.run(['date'],check=True)
subprocess.run(['bash','-c',"cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+draft+"EOF\n"],check=True)
with lesson.open('rb') as f:
 old=f.read(size);section=f.read(len(draft.encode()))
check('只追加且旧前缀逐字节保持',hashlib.sha256(old).hexdigest()==meta['prefix_sha256'] and section==draft.encode())
(P/'validation-after-append.json').write_text(json.dumps({**meta,'checks':checks,'appended':True},ensure_ascii=False,indent=2))
print('已单次cat追加；核验通过',len(checks),'项；旧前缀',size,'字节保持；追加',len(section),'字节')

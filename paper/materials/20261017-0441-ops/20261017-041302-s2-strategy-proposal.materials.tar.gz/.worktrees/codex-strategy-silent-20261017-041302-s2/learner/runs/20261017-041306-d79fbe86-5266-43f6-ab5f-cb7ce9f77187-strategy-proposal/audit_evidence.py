import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).parent
WORKSPACE = OUT.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
RUNS = {'CNKR125PFHJ5', 'PF90JTU0UZ5M'}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('extract_module', WORKSPACE / 'learner/extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
byte_checks = 0
for item in manifest:
    path = OUT / 'evidence' / (item['stream'] + '.evidence.jsonl')
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == item['output_sha256']
    rows = [json.loads(line) for line in data.splitlines()]
    counts = dict.fromkeys(RUNS, 0)
    with (ROOT / 'logs' / (item['stream'] + '.jsonl')).open('rb') as source:
        for row in rows:
            assert row['offset'] + row['bytes'] <= item['source_size']
            source.seek(row['offset'])
            raw = source.read(row['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == row['sha256']
            assert json.loads(raw) == row['row']
            assert module.run_identity(row['row']) == row['run_id']
            assert row['run_id'] in RUNS
            counts[row['run_id']] += 1
            byte_checks += 1
    assert counts == item['counts']
    streams[item['stream']] = rows

states = {row['line']: row['row']['state'] for row in streams['states']}
decisions = {row['line']: row['row'] for row in streams['decisions']}
checks = []
def check(name, condition, detail):
    assert condition, (name, detail)
    checks.append({'name': name, 'detail': detail})

def power(entity, ident):
    return sum(p['amount'] for p in entity.get('powers', []) if p['power_id'] == ident)

def hp(line):
    return states[line]['run']['current_hp']

for row in streams['runs']:
    run = row['row']
    check('角色和进阶', run['character'].lower() == 'silent' and run['ascension'] == 10, run)

before = states[304125]['combat']['enemies']
after = states[304126]['combat']['enemies']
mother = lambda enemies: next(e for e in enemies if e['enemy_id'] == 'OVICOPTER')
check('随机施毒未给母体', power(mother(before), 'POISON_POWER') == power(mother(after), 'POISON_POWER') == 18,
      {'run': 'CNKR125PFHJ5', 'floor': 23, 'turn': 5, 'lines': [304125, 304126]})
gains = [power(b, 'POISON_POWER') - power(a, 'POISON_POWER') for a, b in zip(before, after)]
check('三次随机施毒落子体', gains == [0, 3, 0, 3, 3, 0], gains)
check('母体三结后仍16血', mother(states[304127]['combat']['enemies'])['current_hp'] == 67 - (18 + 17 + 16) == 16,
      {'lines': [304125, 304127], 'player_hp': [hp(304125), hp(304127)]})
check('当轮损22而非整场保证斩杀', hp(304125) == 24 and hp(304127) == 2, [24, 2])

last = states[304228]['combat']
check('沙坑截止前攻击后12血', hp(304228) == 27 and last['player']['block'] == 9 and
      power(last['enemies'][0], 'SANDPIT_POWER') == 1, {'counted_hp_after': 27 - (24 - 9)})
check('沙坑归零而毒未终结', hp(304229) == 0 and states[304229]['combat']['enemies'][0]['current_hp'] == 217 - (33 + 32 + 31) == 121,
      {'run': 'CNKR125PFHJ5', 'floor': 33, 'turn': 6, 'lines': [304228, 304229]})
check('逃离延长沙坑不支付攻击', power(states[304222]['combat']['enemies'][0], 'SANDPIT_POWER') == 1 and
      power(states[304223]['combat']['enemies'][0], 'SANDPIT_POWER') == 2 and
      power(states[304225]['combat']['enemies'][0], 'SANDPIT_POWER') == 1, [304222, 304223, 304225])

potion_pairs = [(304580, 304581), (304628, 304629), (304647, 304648), (304666, 304667), (304685, 304686)]
for a, b in potion_pairs:
    ea, eb = states[a]['combat']['enemies'], states[b]['combat']['enemies']
    delta = sum(power(e, 'POISON_POWER') for e in eb) - sum(power(e, 'POISON_POWER') for e in ea)
    check('毒药水当步加6且本体HP不变', delta == 6 and [e['current_hp'] for e in ea] == [e['current_hp'] for e in eb],
          {'run': 'PF90JTU0UZ5M', 'floor': states[a]['run']['floor'], 'turn': states[a]['turn'], 'lines': [a, b]})
    check('本次未见头骨和制品', 'SNECKO_SKULL' not in [r['relic_id'] for r in states[a]['run']['relics']] and
          all(power(e, 'ARTIFACT_POWER') == 0 for e in ea), {'line': a})
for a, b in [(304289, 304290), (304448, 304449)]:
    check('固化乘已有挡', states[a]['combat']['player']['block'] == 5 and states[b]['combat']['player']['block'] == 15,
          {'run': 'PF90JTU0UZ5M', 'lines': [a, b]})
check('末轮持牌伤和敌攻共需29', hp(304686) == 1 and last is not None and
      states[304686]['combat']['player']['block'] == 27 and
      sum(card['card_id'] == 'TOXIC' for card in states[304686]['combat']['hand']) == 2 and
      sum(i.get('total_damage') or 0 for e in states[304686]['combat']['enemies'] for i in e.get('intents', [])) == 19,
      {'run': 'PF90JTU0UZ5M', 'floor': 22, 'turn': 3, 'calculation': '19+2*5-27=2; HP=1', 'line': 304686})
check('末药先施毒后观察到9毒伤', states[304686]['combat']['enemies'][1]['current_hp'] == 25 and
      power(states[304686]['combat']['enemies'][1], 'POISON_POWER') == 9 and
      states[304687]['combat']['enemies'][1]['current_hp'] == 16 and hp(304687) == 0,
      {'lines': [304685, 304686, 304687], 'internal_order': '同帧内部先后未知'})
check('锚线两个初始手牌相同', states[304651]['combat']['hand'] == states[304670]['combat']['hand'] and
      hp(304651) == hp(304670) == 3, {'lines': [304651, 304670], 'same_full_future': False})

focus_decisions = [v for n, v in decisions.items() if n in {296696, 296700, 296795, 296796, 296797, 296798, 297210, 297229, 297245}]
save('focus-decisions.json', focus_decisions)
save('evidence-audit.json', {'raw_envelopes_checked': byte_checks, 'manifest_streams_checked': len(manifest),
     'identity_runs': sorted(RUNS), 'checks': checks, 'checks_count': len(checks),
     'scope': '材料、身份、字节与实盘算术核验；不是生产测试、整战反事实或自然消费者验收'})

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORKSPACE, text=True).strip()

commits = ['1ffc0746d7de299fbb7856d397af9da0ab899558', '0bf701b583e905fcde2bc6d9b5ec1bc0d1131332',
           '1698adc96ba434a46942321e0237b70657e625b2']
live = git('rev-parse', 'live')
ancestry = []
for commit in commits:
    result = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live], cwd=WORKSPACE)
    assert result.returncode == 0
    ancestry.append({'commit': commit, 'live_ancestor': True, 'subject': git('show', '-s', '--format=%s', commit)})
paths = ['agent/src/reflex/combat.ts', 'agent/src/sl/judge.ts', 'agent/src/reflex/card-model.ts',
         'agent/src/reflex/turn-solver.ts', 'agent/src/reflex/combat-plan.ts', 'agent/src/reflex/rollout-live.ts',
         'agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/reflex/silent-sl-comparison.ts',
         'agent/src/reflex/silent-demon-potion.ts', 'agent/src/reflex/silent-crab-potion.ts',
         'agent/src/reflex/silent-potion-reference.ts', 'agent/src/reflex/silent-phase-current.ts',
         'agent/src/reflex/silent-simulation-reference.ts', 'agent/src/hand/screens/map.ts',
         'agent/src/knowledge/double-boss.ts']
leaves = [{'path': path, 'base_blob': git('rev-parse', 'HEAD:' + path),
           'live_blob': git('rev-parse', live + ':' + path)} for path in paths]
save('source-audit.json', {'base': git('rev-parse', 'HEAD'), 'live_checked': live,
                         'ancestry': ancestry, 'leaves': leaves})
print(json.dumps({'raw_envelopes': byte_checks, 'checks': len(checks), 'live': live}, ensure_ascii=False))

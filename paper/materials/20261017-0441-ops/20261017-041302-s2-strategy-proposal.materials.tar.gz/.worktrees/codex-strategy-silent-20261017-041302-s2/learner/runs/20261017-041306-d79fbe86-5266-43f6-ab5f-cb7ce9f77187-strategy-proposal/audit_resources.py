import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).parent
WORKSPACE = OUT.parents[2]
rows = [json.loads(line) for line in (OUT / 'evidence/states.evidence.jsonl').open()]
states = {row['line']: row['row']['state'] for row in rows}
checks = []
def check(name, condition, data):
    assert condition, (name, data)
    checks.append({'name': name, 'data': data})

hp = lambda line: states[line]['run']['current_hp']
for a, b, before, after in [
    (304038, 304056, 62, 58), (304065, 304090, 58, 38), (304102, 304128, 38, 2),
    (304150, 304174, 60, 37), (304180, 304192, 37, 29), (304203, 304229, 53, 0),
    (304493, 304520, 65, 47), (304525, 304561, 47, 21), (304567, 304604, 21, 3),
]:
    check('实际进出战HP', hp(a) == before and hp(b) == after,
          {'run': states[a]['run_id'], 'floor': states[a]['run']['floor'], 'lines': [a, b],
           'hp': [before, after], 'scope': '实际净HP；SL/事件/奖励另核'})
for a, b, before, after in [(304137, 304139, 12, 36), (304147, 304149, 36, 60), (304200, 304202, 29, 53)]:
    check('实际营火回血24', hp(a) == before and hp(b) == after and after - before == 24,
          {'run': 'CNKR125PFHJ5', 'floor': states[a]['run']['floor'], 'lines': [a, b]})
check('事件升级上限而非饮药', hp(304134) == 2 and hp(304136) == 12 and
      states[304134]['run']['max_hp'] == 70 and states[304136]['run']['max_hp'] == 80 and
      states[304134]['run']['potions'][1]['potion_id'] == 'POISON_POTION' and
      states[304136]['run']['potions'][1]['potion_id'] is None,
      {'run': 'CNKR125PFHJ5', 'floor': 24, 'lines': [304134, 304136]})
check('罐装幽灵由战后奖励取得并留至死亡',
      states[304192]['run']['potions'][0]['potion_id'] is None and
      states[304197]['run']['potions'][0]['potion_id'] == 'GHOST_IN_A_JAR' and
      states[304229]['run']['potions'][0]['potion_id'] == 'GHOST_IN_A_JAR',
      {'run': 'CNKR125PFHJ5', 'lines': [304192, 304197, 304229], 'sandpit_protection_observed': False})
for a, b in [(304180, 304181), (304203, 304204)]:
    check('首行动前净扣3', states[a]['combat']['enemies'][0]['current_hp'] -
          states[b]['combat']['enemies'][0]['current_hp'] == 3 and hp(a) == hp(b),
          {'run': 'CNKR125PFHJ5', 'floor': states[a]['run']['floor'], 'lines': [a, b],
           'limitation': '未隔离被动交互，不外推全敌固定毛伤'})
check('异螨三次恢复均回3血', all(hp(line) == 3 for line in [304609, 304632, 304651, 304670]),
      {'run': 'PF90JTU0UZ5M', 'lines': [304609, 304632, 304651, 304670], 'independent_runs': 1})
check('锚重放即时多损2', hp(304651) == hp(304670) == 3 and hp(304655) == 3 and hp(304674) == 1,
      {'run': 'PF90JTU0UZ5M', 'floor': 22, 'turn': 1, 'lines': [304651, 304655, 304670, 304674]})

source = json.loads((OUT / 'source-audit.json').read_text())
classifications = []
for item in source['leaves']:
    base = subprocess.check_output(['git', 'show', source['base'] + ':' + item['path']], cwd=WORKSPACE)
    live = subprocess.check_output(['git', 'show', source['live_checked'] + ':' + item['path']], cwd=WORKSPACE)
    equal = base == live
    assert equal or base.replace(b'Roy', b'Dai') == live
    classifications.append({'path': item['path'], 'byte_equal': equal,
        'difference': None if equal else '已逐hunk读回，仅既有注释中的Roy/Dai署名差',
        'base_sha256': hashlib.sha256(base).hexdigest(), 'live_sha256': hashlib.sha256(live).hexdigest()})
result = {'checks': checks, 'checks_count': len(checks), 'source_equivalence': classifications,
          'scope': '材料算术/资源和既有源码差异核验；无生产测试或完整反事实'}
(OUT / 'resource-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'source_leaves': len(classifications)}))

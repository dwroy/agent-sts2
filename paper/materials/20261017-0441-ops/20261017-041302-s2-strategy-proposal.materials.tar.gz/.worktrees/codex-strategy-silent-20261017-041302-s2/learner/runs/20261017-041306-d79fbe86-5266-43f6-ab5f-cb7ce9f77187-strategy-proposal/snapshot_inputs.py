import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
OUT = Path(__file__).parent
BATCH = '20261017-041302-s2-strategy-proposal'

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

batch = json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())['batches'][BATCH]
assert batch['character'] == 'silent'
assert batch['worktree'] == str(OUT.parents[2])
assert not batch.get('research_request') and not batch.get('implementation_request')
save('dispatch.json', batch)
ids = batch['proposal_ids']
rows = []
for line in (ROOT / 'paper/materials/learning/code-proposals.jsonl').open():
    row = json.loads(line)
    if row.get('id') in ids:
        rows.append(row)
save('proposal-queue.json', rows)
adds = {row['id']: row for row in rows if row['op'] == 'add'}
assert set(adds) == set(ids)
manifest = []
ledger_ids = set()
for index, ident in enumerate(ids, 1):
    row = adds[ident]
    assert row['character'] == 'silent'
    assert set(row['runs']) <= set(batch['runs'])
    path = Path(row['proposal'])
    data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    assert sha == row['proposal_sha256'], (ident, sha)
    name = f'original-{index:02d}-{ident}.md'
    (OUT / name).write_bytes(data)
    ledger_ids.update(row['ledger'])
    manifest.append({'id': ident, 'source': str(path), 'bytes': len(data), 'sha256': sha,
                     'copy': name, 'ledger': row['ledger'], 'runs': row['runs']})
save('proposal-input-manifest.json', manifest)
spec = importlib.util.spec_from_file_location('ledger_module', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
selected = []
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
offset = 0
digest = hashlib.sha256()
with ledger_path.open('rb') as handle:
    for number, raw in enumerate(handle, 1):
        digest.update(raw)
        row = json.loads(raw)
        if row.get('id') in ledger_ids:
            selected.append((number, row))
        offset += len(raw)
folded = module.fold(selected)
assert set(folded) == ledger_ids
assert all(item['character'] == 'silent' for item in folded.values())
save('ledger-before.json', folded)
save('ledger-prefix-before.json', {'source_size': offset, 'sha256': digest.hexdigest()})
for ident, item in sorted(folded.items()):
    print(json.dumps({'id': ident, 'status': item['status'], 'claim': item['claim'],
        'evidence': [e for e in item['evidence'] if e['run'] in batch['runs']],
        'last_note': item.get('notes', [])[-1:]}, ensure_ascii=False))

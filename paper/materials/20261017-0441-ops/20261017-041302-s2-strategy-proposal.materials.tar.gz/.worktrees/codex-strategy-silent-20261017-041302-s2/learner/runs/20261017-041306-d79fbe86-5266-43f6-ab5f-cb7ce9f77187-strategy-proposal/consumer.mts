import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const scratch = fileURLToPath(new URL('.', import.meta.url));
const workspace = resolve(scratch, '../../..');
const read = fs.readFileSync;
// Optional live knowledge is excluded; these checks use frozen observed frames only.
(fs as any).readFileSync = (path: any, ...args: any[]) => {
  const name = path instanceof URL ? fileURLToPath(path) : String(path);
  if (resolve(name).startsWith(resolve(workspace, 'knowledge') + '/') ||
      resolve(name).startsWith('/home/dw/Projects/agent-sts2/knowledge/')) {
    throw Object.assign(new Error('ENOENT: frozen evidence consumer'), { code: 'ENOENT' });
  }
  return (read as any)(path, ...args);
};
syncBuiltinESMExports();
const { setKnowledgeCharacter } = await import(`${workspace}/agent/src/knowledge/files.ts`);
setKnowledgeCharacter('silent');
const { parseGameState } = await import(`${workspace}/agent/src/hand/mod/schema.ts`);
const { makeKnowledge } = await import(`${workspace}/agent/src/knowledge/index.ts`);
const { buildRunBrief } = await import(`${workspace}/agent/src/memory/run-brief.ts`);
const { createScreenMemory } = await import(`${workspace}/agent/src/memory/types.ts`);
const { loadConfig } = await import(`${workspace}/agent/src/core/config.ts`);
const { planCombat } = await import(`${workspace}/agent/src/reflex/combat.ts`);
const { modelHandCard, modelPotion } = await import(`${workspace}/agent/src/reflex/card-model.ts`);
const { enemySims } = await import(`${workspace}/agent/src/reflex/combat-plan.ts`);
const { replaySteps } = await import(`${workspace}/agent/src/reflex/turn-solver.ts`);
const { observedDemonPoison } = await import(`${workspace}/agent/src/reflex/silent-demon-potion.ts`);
const { silentSlComparison } = await import(`${workspace}/agent/src/reflex/silent-sl-comparison.ts`);
const frames = JSON.parse(read(new URL('./focus-frames.json', import.meta.url), 'utf8'));
const frame = (line: number) => structuredClone(frames.find((entry: any) => entry.line === line).row.state);
const knowledge = makeKnowledge({ cards: [
  { id: 'BOUNCING_FLASK', type: 'Skill' }, { id: 'DEFEND_SILENT', type: 'Skill' },
  { id: 'STRIKE_SILENT', type: 'Attack' }, { id: 'FOOTWORK', type: 'Power' },
] }, 'cache');
const checks: any[] = [];
const record = (name: string, data: any) => checks.push({ name, ...data });

for (const line of [304225, 304226, 304227, 304228]) {
  const raw = frame(line), state = parseGameState(raw);
  const decision = planCombat({ state, knowledge, brief: buildRunBrief(state, knowledge),
    thresholds: loadConfig({}).thresholds, runStart: 'auto', characterPreference: null,
    allowFtueModals: false, strictJev: true, screenMemory: createScreenMemory('COMBAT'), shopDiscardPotions: [] });
  assert.equal(decision?.kind, 'ask');
  const end = JSON.parse((decision as any).questions.play.criteria.end_turn);
  assert.equal(end.lethal, true);
  assert.equal(end.hp_after_enemy_turn, 0);
  assert.equal(end.sandpit_deadline.scope, 'current_end_turn_only');
  assert.ok(Object.keys((decision as any).questions.play.criteria).some(key => key.startsWith('p0')));
  if (line === 304228) assert.equal(end.hp_after_counted_damage, 12);
  record('single-action-deadline', { line, end_turn: end });
}

const raw = frame(304125), state = parseGameState(raw), c = raw.combat;
const flask = c.hand.find((card: any) => card.card_id === 'BOUNCING_FLASK');
const card = modelHandCard(flask, flask.index, knowledge, 'silent', 10);
assert.equal(card.deferRandomPoison, true);
const input: any = { hand: [card], player: {
  hp: c.player.current_hp, maxHp: c.player.max_hp, block: c.player.block, energy: c.player.energy,
  weak: false, vulnerable: true, intangible: false, strengthNow: 1, poisonExtraTriggers: 2,
}, enemies: enemySims(c, 10, 'silent'), fightKind: 'monster', turn: 5 };
const step = { cardIndex: card.index, cardId: card.cardId, name: card.name, upgraded: card.upgraded, target: null };
const plan = replaySteps(input, [step]);
assert.ok(plan);
assert.equal(plan.outcome.randomPoisonUnresolved, true);
assert.equal(plan.outcome.winsFight, false);
assert.ok(plan.outcome.unknownCards.some((text: string) => text.includes('未计新增毒')));
record('random-poison-certainty', { line: 304125, outcome: plan.outcome });

for (const line of [304580, 304628, 304647, 304666, 304685]) {
  const raw = frame(line), state = parseGameState(raw);
  assert.equal(observedDemonPoison(state), null);
  const slot = raw.run.potions.find((p: any) => p.potion_id === 'POISON_POTION');
  assert.ok(slot);
  const targets = raw.combat.enemies.map((e: any) => e.index);
  const potion = modelPotion(slot.potion_id, slot.name, slot.slot_index ?? 0, targets,
    { enemyTargets: targets, strength: 0, weak: false });
  assert.ok(!potion?.poison);
  record('corridor-poison-coverage-gap', { line, demon_scope: null, modelled_poison: potion?.poison ?? null });
}
record('sl-comparison-capability', { available: typeof silentSlComparison === 'function',
  limitation: '现有候选对照不提供本提案要求的后继敏捷、必要锚条件或完整同抽序反事实。' });
fs.writeFileSync(new URL('./consumer-results.json', import.meta.url), JSON.stringify({
  scope: '现有源码的冻结证据消费者核验；无新源码、无生产测试或自然动作验收', checks,
}, null, 2) + '\n');
console.log(JSON.stringify({ checks: checks.length, status: 'passed' }));

import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
OUT = Path(__file__).parent
WORKSPACE = OUT.parents[2]
before = json.loads((OUT / 'ledger-before.json').read_text())
updates = json.loads((OUT / 'ledger-updates.json').read_text())
assert (OUT / 'ledger-cli.exit.txt').read_text().strip() == '0'
assert not (OUT / 'ledger-cli.stderr.log').read_text().strip()
spec = importlib.util.spec_from_file_location('ledger_module', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
path = ROOT / 'paper/materials/learning/ledger.jsonl'
prefix = json.loads((OUT / 'ledger-prefix-before.json').read_text())
data = path.read_bytes()
assert hashlib.sha256(data[:prefix['source_size']]).hexdigest() == prefix['sha256']
selected = []
ours = []
offset = 0
for number, raw in enumerate(data.splitlines(keepends=True), 1):
    row = json.loads(raw)
    if row.get('id') in before:
        selected.append((number, row))
    if row.get('id') in before and row.get('by') == 'learner:strategy-proposal' and \
            '20261017-041302-s2-strategy-proposal：' in row.get('note', ''):
        assert set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'}
        expected = next(item for item in updates if item['id'] == row['id'])
        assert all(row[key] == value for key, value in expected.items())
        ours.append({'id': row['id'], 'line': number, 'offset': offset, 'bytes': len(raw),
                     'sha256': hashlib.sha256(raw).hexdigest()})
    offset += len(raw)
assert len(ours) == len(updates) == 29
after = module.fold(selected)
protected = ['character', 'kind', 'claim', 'evidence', 'first_run', 'prior', 'prior_note',
             'prior_runs', 'asc', 'status', 'version', 'shipped_at', 'effect']
differences = []
for ident, item in before.items():
    for key in protected:
        if item.get(key) != after[ident].get(key):
            differences.append({'id': ident, 'field': key})
assert not differences, differences
readback = {'cli_exit': 0, 'physical_rows': ours, 'old_prefix_unchanged': True,
            'protected_fields': protected, 'protected_differences': differences,
            'only_where_note_appended': True, 'shipped_not_registered': True}
(OUT / 'ledger-readback.json').write_text(json.dumps(readback, ensure_ascii=False, indent=2) + '\n')

result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert {row['id'] for row in result['proposal_results']} == set(dispatch['proposal_ids'])
assert len(result['proposal_results']) == len(dispatch['proposal_ids']) == 10
assert result['fixes'] == [] and result['merged'] is None
assert all(value is None for value in result['tests'].values())
assert Path(result['report']).is_file() and (OUT / 'proposal.md').is_file()
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKSPACE, text=True).strip()
assert base == result['base']
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=WORKSPACE, text=True)
assert not status.strip(), status
live = subprocess.check_output(['git', 'rev-parse', 'live'], cwd=WORKSPACE, text=True).strip()
for row in result['proposal_results']:
    if row['state'] == 'duplicate':
        subprocess.run(['git', 'merge-base', '--is-ancestor', row['commit'], live], cwd=WORKSPACE, check=True)
final = {'base': base, 'git_status': status, 'live_at_final_check': live,
         'proposal_count': 10, 'duplicate': 3, 'waiting': 7,
         'ledger_updates': len(ours), 'tests': result['tests']}
(OUT / 'final-verification.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
files = []
for file in sorted(OUT.rglob('*')):
    if file.is_file() and file.name != 'artifact-manifest.json' and not file.name.startswith('final-readback.'):
        raw = file.read_bytes()
        files.append({'path': str(file.relative_to(OUT)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(OUT / 'artifact-manifest.json').write_text(json.dumps(files, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(final, ensure_ascii=False))

import json
from pathlib import Path

OUT = Path(__file__).parent
BATCH = '20261017-041302-s2-strategy-proposal'
BASE = 'edff4b9a3f6a9a8061c077a5ce731781fc7d4c79'
SANDPIT = '1ffc0746d7de299fbb7856d397af9da0ab899558'
FLASK = '0bf701b583e905fcde2bc6d9b5ec1bc0d1131332'
dispatch = json.loads((OUT / 'dispatch.json').read_text())
originals = {row['id']: row for row in json.loads((OUT / 'proposal-queue.json').read_text()) if row['op'] == 'add'}

details = [
    ('silent-proposal-0ff91bb5da98a252', 'duplicate', SANDPIT,
     '单动作沙坑截止的窄事实接线已由实际live祖先1ffc0746完成；本批CNKR F33T6四原帧均显示当前结束致死，并保留攻击后剩血12和药水选择。未改SL资格或声称幽灵可抵沙坑。',
     'CNKR125PFHJ5 A10 F33 T5—6；s304222/223/225—229、d296795—296798。27血9挡对24攻击后12血，沙坑1归零实际0，敌217经33+32+31毒伤余121。',
     '旧题lethal=false；所需新行为是只修当前结束题面，分别显示已计伤害后HP与沙坑完整结局。当前源码已做到；保留全部原候选及未饮药的未知。',
     '沙坑2、敌人可能先结束、已有保护或复活等条件不能机械当沙坑1必死；本局未饮幽灵，不证明其抵截止。',
     'consumer-results.json四原帧核验；combat.ts使用judgeCurrentEndTurn，仅current_end_turn_only。无需重复补丁，保留既有源与完整检查历史。'),
    ('silent-proposal-7bcb766a47aed4bc', 'duplicate', FLASK,
     '普通2费、三次各3毒、多活体的随机药瓶已有实际live祖先0bf701b5：标记未展开、禁止保证斩杀并等待实落点。本批s304125的当前消费者同样不认证winsFight，原随机选项仍保留。',
     'CNKR125PFHJ5 A10 F23 T5—6；s304125—128、d296696/296700。三份毒落原索引1/3/4子体，母体67血18毒未变，三结51仅余16；玩家24→2，下一轮才胜。',
     '旧逻辑把最高HP目标当随机毒保证；新行为对已观察普通药瓶标随机未展开、不给整场保证，实分配后重读。当前card-model/turn-solver/combat-plan/rollout-live已有联动。',
     '单敌无分配歧义；普通牌以外的升级、改费、附魔和重放范围沿既有实现保持，不从本局扩展。T6赢不能倒写T5确定终结。',
     'consumer.mts直接建模s304125，deferRandomPoison=true、randomPoisonUnresolved=true、winsFight=false；实际源0bf701b5为live祖先。'),
    ('silent-proposal-910db627f14d4eba', 'waiting', None,
     '已有持药价值未知说明、沙坑接线和候选/SL预测对照只是子项。仍缺本局截止输出、已建立能力、毒伤分源、实际HP/药槽及逐次路线投影在同一消费者上的完整配对；未饮幽灵无沙坑保护对照，不补药价或强喝/SL规则。',
     'CNKR125PFHJ5 A10 F23/F24/F25/F28/F29/F30/F32/F33；末战T1—6。赢战38→2，事件2/70→12/80且消耗毒药，三次实休息+24，F29 60→37、F30 37→29，F32 29→53，F33死亡。',
     '保留现有独立事实和未知持药说明；待能按同一时间/库存联结预测与实到后，再补统一截止/资源审计视图。当前silentPotionReference不等完整资源链实现。',
     '休息31.25%是当时模型，8样本4胜不是本抽序胜率；胜局条件损血不等全样本死亡预测。F30以后持幽灵而未饮不是无实体保护证据。',
     '材料核验资源链和末轮；将来须冻结预测版本、对应实际动作/药槽与阶段，核对消费者真实读回；没有受控全战，不拟合规则阈值。'),
    ('silent-proposal-39b4e686237c1193', 'waiting', None,
     '十五经验联合项仅部分有现成力敏/毒/随机边界模型。首行动前净扣3只在两帧对观察，未隔离水银与其他被动；缺逐牌挡/实建能力/随机分配/污染及被动在完整执行链上的联合校准，不能由窄修复关闭整项。',
     'CNKR125PFHJ5 A10 F23T1/T4/T5，F29技能污染，F30T1，F33T1—6；s304125—127、304180/181、304203—229。首行动前138→135、341→338且玩家不变。',
     '只采实建能力、实际挡和已结毒，未发生随机不预定；已正确的模型维持，沙漏只留观察，待联合固定回放与真实消费者配对。',
     '余像持有未施放不计挡；母体随机未收尾但翌轮胜；延长沙坑不抵攻击。没有单组件移除的整战对照。',
     '本批已核随机与截止窄子项、首行动净伤及资源；待同资源逐动作/逐结算可追溯的完整联合输入，不设置全敌固定被动伤或牌值常数。'),
    ('silent-proposal-7369f01e2887a6ab', 'duplicate', SANDPIT,
     '与0ff91bb5相同的沙坑事实传播子项已有实际live祖先1ffc0746；整回合求解保留独立sandpitAfter，单动作复用已有保守end-now判定。原提案要求保留未知和不强喝/不强制SL，未要求证明幽灵可保护或改收益阈值。',
     'CNKR125PFHJ5 A10 F33 T5—6；沙坑1→逃离2→次轮1，末攻击账12血但实际0、敌121。账本silent-0018/0021。',
     '旧单动作漏独立截止；新题面分列攻击后HP、完整结局及当前结束范围。现有整回合sandpitAfter与新接线共同覆盖所要求事实。',
     '敌人先结束、未观察保护仍未知；触媒末轮96毒不足并不证明提早触媒一定赢。幽灵未饮，保持原未知边界。',
     '同四原帧消费者核验及现有turn-solver独立沙坑结算源码读回；无重复实现、无新SL规则。'),
    ('silent-proposal-4ddaf22806904bc5', 'waiting', None,
     '实际HP/药槽和三次休息已核，但缺逐个路线/休息投影修订与真实后续窗口、实际问号战、SL恢复的完整消费者配对；不能从一个死亡局推安全血线、营火优先级或房间价格。已有未知持药提示不等本项路线闭环完成。',
     'CNKR125PFHJ5 A10 F19/21/23三胜62→58→38→2；F24事件、F25/28/32各+24；F29/30净损23/8，F33 53→0。跨幕回复与营火/事件/战后奖励分账。',
     '旧计划和分支投影容易混为实到；预期新增已选分支到真实战斗首帧的审计。现有投影保留条件标签；等待可识别的逐版本配对再实现本项。',
     '同局休息确实回血但仍沙坑死，不证明锻造更优；缺未选路线的实到HP，不能造因果收益。',
     'resource-audit.json核对每段实到与事件耗药；待下一组同角色配对预测/执行及消费者读回，不改原价格和选择。'),
    ('silent-proposal-1a129a730c02e845', 'waiting', None,
     '现有1698adc9等已记录原答/替线即时预测，但未覆盖本项后继敏捷/必要锚条件，也缺完整同抽序原线与锚线整战配对。PF末试T2还另换步法，19/24与22/24不能单独确定新准入阈值。',
     'PF90JTU0UZ5M A10 F22 第3/4试T1—3；s304651/670同3血、2敏、五手，原答防御双打击，末锚线毒药双打击，实损0/2，末试T2再建步法、T3仍死；d297210/229。',
     '保留重放现有准入和当前预测对照；待补后继能力/抽序及锚必要性后研究是否重选偏离点。本批不把样本死亡率差变成新阈值。',
     '两个T1底板近似不代表完整未来相同；前三试为判死截断，没有完整原路径胜负。记录决策源不等整线已执行。',
     '已核源祖先1698adc9和现有comparison接线；材料核对0/2血价与末轮27挡不足，等待完整本角色配对和后继执行证据。'),
    ('silent-proposal-f6f3783ef2387b07', 'waiting', None,
     '确认五次相关实饮均加6且当步本体0伤，当前走廊入口仍未模型化。F21含HardToKill9，F22含两毒素/同帧敌毒结算；缺全部合法目标与已观察修正条件下的独立结算/完整候选配对，不能把单瓶SL重复泛化为通用6毒模型；保留每瓶原选择及未知。',
     'PF90JTU0UZ5M A10 F21T2、F22四试T3；s304580/581、628/629、647/648、666/667、685/686。末25血毒3→9，本体当步不变，结束25→16；1血27挡对19攻+10持牌伤仍死。',
     '旧走廊显示效果未知；预期应由带条件的角色机制数据驱动目标级模型。现有observedDemonPoison和双Boss入口不适用本局，不能登记duplicate；未核组合继续未知，禁止通用硬编码6。',
     '五次包含同瓶恢复，不是五局/五瓶独立样本；末GAME_OVER同帧敌毒和玩家死亡内部先后未知。已有TOXIC成本没有新漏算，固化5→15已正确。',
     'consumer-results.json五原盘面均确认现有走廊模型缺口；材料核对加6/0即时伤/后结9/需损2。待目标级条件与完整结算消费者证据，不推更早喝可赢。'),
    ('silent-proposal-2b4575ca64988cfe', 'waiting', None,
     '已重建65→47→21→3和实际三场赢战；缺路线预测修订、实际问号战窗口/SL恢复与消费者事实区的稳定配对输入。地图口径2战与实战口径3战定义不同，不能据此报纯计数bug或修改问号价格；未来F27/29/32恢复均未到。',
     'PF90JTU0UZ5M A10 F18计划、F19/20/21实际赢战、F22失败；s304493/520/525/561/567/604/609、run-plans2752/2753及brain原记录。F21问号战净损18。',
     '预期同时保留地图普通/精英/问号定义、另列实发生战斗和当前HP/药槽留存；不将未来火/店计为当前资源。等待可审计消费者配对，不改原选线。',
     'F21更新对F22入口3/该房耗尽并非失准；F8/F12投影与恢复的不同阶段不可并成统一误差。SL恢复不是新药或正常回血。',
     '核对三赢战净损18+26+18=62及F22入口3；待可联结的逐版路线/窗口/恢复证据与真实题面读回。'),
    ('silent-proposal-67ee9ff5277558ff', 'waiting', None,
     '十二经验的联合实现不能由现有毒/格挡/固化/胆小窄模型代替。走廊毒药水仍有已确认入口缺口；同帧毒素/敌毒内部顺序、重规划后完整牌线与替目标/药时点的受控后继未齐，不重复实现已覆盖子项或造组合胜率。',
     'PF90JTU0UZ5M A10 F9T1—8、F17T1—10、F19—22；普通药瓶9毒+普通触媒两结17，固化两次5→15；末两毒素10+19攻超过27挡，二幕三胜后3血入异螨。',
     '已建敏捷不追补旧挡，实结毒与当步施毒分开，已有挡倍率只在饮用时核；现成模型保持。待完整联合回放及当前消费者验证，不加药水或集火优先级。',
     '四敏与27挡仍能死亡；到T6才首退一鳗，不能由高血/高敏推整场安全；南瓜蜡烛恢复和续火计划不当已执行。',
     '本批联合材料核验支持原观察，未提供全部十二经验的逐动作独立输入和时间留出，继续waiting。'),
]
assert {row[0] for row in details} == set(dispatch['proposal_ids'])
result_rows = []
sections = []
for ident, state, commit, reason, evidence, behavior, counter, verify in details:
    original = originals[ident]
    result = {'id': ident, 'state': state, 'reason': reason}
    if commit:
        result['commit'] = commit
    result_rows.append(result)
    sections.append(f'''## {ident}

处置：{state}。{reason}

来源：{original['source_task']} → 本批 strategy-proposal；原稿 `{original['proposal']}`；SHA256 `{original['proposal_sha256']}`。

账本：{', '.join(original['ledger'])}。证据：{evidence}

旧规则与预期行为：{behavior}

反例及限制：{counter}

验证与再派条件：{verify}

源码来源：{commit or '本批无新源码；原提案未完整实现'}。预期影响是事实一致与可追溯；没有胜率收益估计。回退：已有窄实现如需回退由原发布链处理，保留全部原证据与账本；本批无新补丁可回退。
''')

proposal = f'''# Silent 指定十提案逐项核验

批次：{BATCH}；派发局：CNKR125PFHJ5、PF90JTU0UZ5M，均核为Silent A10。原HEAD `6fadcefe24c662c768fa33870aa98a3d632e6dff`，普通任务按要求fast-forward main后基线 `{BASE}`。本批无research_request、implementation_request或proposal_repair，仅消费这十id。

本批3项duplicate、7项waiting；无新源码/知识、提交、合入或版本。不另建重复提案id，不把经验shipped或父项排队当源码实现。本报告只在本角色冻结两局范围作结论，未读取其他角色经验。

证据提取使用learner/extract_evidence.py八流，1791封套全部原offset/bytes/SHA和显式身份读回；871状态、843决策、10SL、2配置、10run-plans、53brain、2结果、0fight-plans。run-plans按run字段选取，未把正文提及当身份。source_size与逐行封套在evidence/。fight-plans零行仅表示本截点未选中，不断言原日志缺失。全源states/decisions/brain各2个无效行已记manifest，不冒称全源完全有效。

拟合与时间切分：不拟合常数或阈值。这两局是旧提案的发现/重复证据，不当作独立留出；SL次数不计独立局。实际旧dirty运行树缺失，不声称完整重放当时源码。当前基线消费者使用冻结原帧和禁读可刷新知识输入；无新模拟抽样/LLM/网络/对局。

当前源码与live核对15叶，10叶字节相同，5叶只含已逐hunk核对的Roy/Dai历史注释署名差；保留base-live-leaves.patch及双SHA，不覆盖live叶。实际live `{json.loads((OUT / 'source-audit.json').read_text())['live_checked']}`。

''' + '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal)
(OUT / 'proposal-results.json').write_text(json.dumps(result_rows, ensure_ascii=False, indent=2) + '\n')

ledger_before = json.loads((OUT / 'ledger-before.json').read_text())
updates = []
for ident in sorted(ledger_before):
    linked = [row for row in result_rows if ident in originals[row['id']]['ledger']]
    text = '；'.join(row['id'] + '=' + row['state'] for row in linked)
    commits = sorted({row['commit'] for row in linked if row.get('commit')})
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md')], **({'commits': commits} if commits else {})},
        'note': BATCH + '：' + text + '。两Silent/A10局八流1791封套逐字节/身份核对；3窄项去重、7宽项缺数据详见proposal-results.json。仅where/note追溯，不新增support/repeat，不改claim/首证/prior/evidence/status/version/shipped；无本批源码、合入、版本或生产测试。'})
(OUT / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')

final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
    'runs': dispatch['runs'], 'fixes': [], 'skipped': [row['id'] for row in result_rows if row['state'] == 'waiting'],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': result_rows, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
report = f'''# 本批回报

3项duplicate、7项waiting。完整逐项证据、层/回合、账本、反例、预期行为及验证方法见 `{OUT / 'proposal.md'}`；机器处置见proposal-results.json。所有派发id已覆盖，无扩队列。

base：`{BASE}`。fixes=[]，merged=null。本批未改源码/知识、未提交、未合入、未新建版本或标shipped，工作树应保持干净。原main只按普通任务fast-forward；当前源码15叶与live对照的注释署名差原样保持。

已实现去重来源：0ff91bb5与7369f01e使用实际live祖先 `{SANDPIT}`（单动作沙坑事实，原V5-R376）；7bcb766a使用实际live祖先 `{FLASK}`（已观察普通多敌药瓶不确定性）。这只是既有源码去重，不是本批发布或自然采用/收益验收。原R376精确宿主终局不在本批完成范围，未借其测试绿。

证据：CNKR125PFHJ5与PF90JTU0UZ5M均Silent A10；8流1791原封套逐offset/bytes/SHA/身份核。10份原提案Markdown SHA逐一相同。材料算术24项、资源18项核验通过；当前消费者11条记录（4沙坑原帧、1随机毒原帧、5走廊毒药入口缺口、1SL能力边界）保存consumer-results.json。以上不是生产测试或完整反事实。

初次consumer输入抽取遗漏304666/304667导致scratch TypeError，原focus-frames.json.r1与consumer.*.r1保留；补回原冻结流中这两帧后58帧齐备、同一脚本通过。原日志与提案未变，不报生产bug或测试失败。extract_evidence原manifest与stderr均保存。

tsc/vitest/cases：均null；没有新源码，因此未执行原生产测试、撤源码失败/恢复通过、gitleaks提交闸或live合入流程。没有以0冒称测试成功。现有窄源码已逐祖先核实，未为此撤改生产源。

仍缺：完整联合机制/结算消费者配对，逐版路线投影与实到资源链，后继敏捷及必要锚条件的同抽序整战对照，走廊毒药的目标/修正条件与完整候选执行边界。实饮加6不等全目标通用模型；未来休息未到不算当前资源。没有新增科学反证或经验claim变更，保留原假设和未知，不据无充分证据否定原观察。

账本只经根learner/ledger.py update追加本批where/note与实际窄源码来源；保留原status/claim/first_run/prior/evidence/version/shipped，不添加重复支持。CLI结果及前缀/保护字段复核在ledger-readback.json；本批不代运维登记shipped。

最终JSON：result.json。提案与报告均真实保存在本批工作树learner/runs/，交原调度器消费；等待项留待后续本角色证据重派。
'''
(OUT / 'report.md').write_text(report)
print(json.dumps({'duplicate': 3, 'waiting': 7, 'ledger_updates': len(updates), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

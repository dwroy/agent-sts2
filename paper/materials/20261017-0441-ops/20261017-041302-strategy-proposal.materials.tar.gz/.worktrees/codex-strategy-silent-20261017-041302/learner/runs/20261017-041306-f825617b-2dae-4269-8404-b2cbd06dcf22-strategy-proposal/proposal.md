# 本批十项策略提案处置

批次：20261017-041302-strategy-proposal；角色：silent。
基线：`edff4b9a3f6a9a8061c077a5ce731781fc7d4c79`。开工初始HEAD为`6fadcefe24c662c768fa33870aa98a3d632e6dff`且干净；普通批次按要求快进main至上述base。
根learn.json只读本批记录，reason=proposal，明确领取这十个proposal_ids，没有research_request、implementation_request或proposal_repair；普通专题文件绑定其他批次，未读取其work_spec/manifest，也未转为专题。未派子agent。

## 证据及假设边界

只使用静默猎手证据。48个原提案关联及派发局号均经runs.jsonl核角色；其中本批10个派发锚点及QHK1XQ928TTM、UZ1T7AH49WMB、7BNC8QX746YP共13局冻结八流。
10锚点为A0两局、A1/A4/A6/A9各一局、A10四局；额外三局均A10。48局身份核验不冒充48局内容分析，原提案所称137/140局历史统计本批没有全量重做。
10份原Markdown的实际SHA逐项等于专用队列SHA，并保存原字节副本；未改原文、未新建重复提案ID或历史复盘。

共20198条原记录逐条回读offset/bytes/SHA/JSON并重验显式run身份，见evidence-readback.json。states=9923、decisions=9586、sl-attempts=90、run-config=13、run-plans=81、brain=492、runs=13、fight-plans=0；各源字节截点见evidence/evidence-manifest.json。
run-plans按run字段归属，不用正文提及归属；本批没有旧截点零行复核。fight-plans零行仅表示本次截点未选到，不宣称原日志缺失。

本批固定事实包括：

- C48LLXBGKXQ9 A0 F19实盘满血70→32；高血量/后续回血不能当成已无代价，F33多试没有受控替代构筑结局。该局资源消费者结果另存C48LLXBGKXQ9-resources.json。
- QHK1XQ928TTM A10 F31 T1—T7事件赢战36→17、F32休息17→38。s303052/303053可核，F29投影57与实38差19不证明问号完全漏建模。账本0019/0020。
- QHK F33 T1 s303058→303059三类齐后新增1力/1敏，s303061后续同类不重加；原RAINBOW_RING.stack为null、无powers_played_this_turn，不能将未分类牌数差直接等同能力牌。支持0305机制，不能据此给所有轮次固定加层。
- QHK F33 T4 s303218→303221：生命15→9→9→7、格挡16→16→22→22。祭品与附魔撞击的直接血价分别6、2；不把已有格挡抵扣直接生命支付，也不把它们全算敌方入伤。账本0306；当前card-model已有HpLoss/文本自损处理。
- QHK F33第3/6试T3原答和SL执行有差异，d295737/d295821保留原选择及替换；47/47、14/20、差6未超8宽限。有限全败不决定固定朝向或新终局优先级。账本0062/0065/0079。
- UZ1T7AH49WMB A10 F25 T1四次迅捷请求为d296165/186/208/226，含代码potion-now与Jev选择；三次SL恢复不是新获药。末T3 d296241括号-15为预计余血6−21，实际6血/13挡对34攻击。已建触媒和毒雾但敌零毒不等于已结毒伤。账本0011/0027/0023/0079。
- 7BNC8QX746YP A10 F14 T2 d296385选单牌带毒刺击+后，d296386重新选冲刺+；s303798/799/800/801挡14→14→27→0，血31保持。原单牌1/8与组合0/8是不同停止策略，不能把追加执行后的整轮实值归给单牌预测。账本0239/0242/0307。

同局重试和同轮重问不新增独立样本。上述事实及反例支持保留“实际到手/建立/结算”与“预测/持有/未来资源”的区分，没有证明另一方案必胜。无新参数拟合，未来时间更晚的独立同角色局及同输入完整轨迹仍是后续验证输入。

## 已有实现及消费者

当前base与只读live快照`f1a334a372c9ea63fdfda78378a83f36b317d42b`比较18个相关源码叶：13个原字节相同，5个只有独立单词Roy/Dai历史署名差，r2逐叶核实；初版错误地替换Royal子串导致的失败及原输出保持，不充源码或机制失败。
card-model已有直接生命成本、combat-plan已有8点最小护栏、候选answer/before_sl/after_sl与单动作回执；boss-start已有可可首轮能量而不保证能力到手；route-projection/休息模拟本来就是条件投影，不能把不同入口数值混用为同一次预测错误。

只认已有窄源码范围：a32050fbce4c2863f640468c2dbf378fc9157074（离线药槽）、e75438488df159b2e8e9d3458cf219b39aadd933（整轮窗口）、83512ddcd2c70fd9b983dc38524ff25c8970c1d3（终态端点）、dc0e6080cb20c508d94c006648cc3edf0188d306（能力/HP端点）均经git核为base及live实际祖先，见source-readback.json。它们不证明完整候选执行、线上采用或原宽提案完成，十项均不登记duplicate/implemented。

现有audit-selection.ts真实固定输入读回：QHK 746动作/207片段/120轮窗，UZ 405/45/63，7BNC 152/18/23，三次exit0。UZ一条原无decision_id元数据单独排除并保留原offset/SHA，其余不伪造ID或重新编号。
动作端点QHK可连接305、UZ118、7BNC0；剩余分别441、287、152未知（区间reason=null为可连接观测，不等因果）。7BNC的sl_attempt=null即使sl_reloads=0也沿既有工具保留未知，没有修改门槛以凑覆盖。
三个输出270片段的actual_full_candidate_result/actual_rollout_best仍为null。全部只表示原工具能消费冻结输入，不等于完整执行认证、当前生产自然采用或收益证明。
资源消费者独立分出QHK 21窗口（15 observed_exit/6 restart）、UZ14（11/3）、7BNC6（6/0），缺完整入伤和因果时保持原限制；observed_net_hp_loss是观测净血差，不是敌攻击总量。

## silent-proposal-e8f4f7afefd92d5c

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-183609-experience-update/proposal-resources.md

账本：silent-0019, silent-0020, silent-0021, silent-0243, silent-0304。

本批处置：waiting。C48 A0 F19满血70→32及F33多试失败只证资源实际消耗；可可额外能量已有接线，不能推出能力实际到手并启动。缺完整同资源、同抽序的能力启动与后战资源消费对照，不能拟终态或存药常数，宽项waiting。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-7fa8ed575324c18e

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-184301-postmortem/resources-proposal.md

账本：silent-0019。

本批处置：waiting。QHK A10 F31事件赢战36→17、F32回血17→38已复核。F29所选回血分支预测57与实38差19，不足证明问号完全未建模；缺所选分支、原预测时点、实际战房及后继消费的完整一一绑定，保留既有房间统计与门槛。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-8560010ee25568e8

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-184301-postmortem/setup-potion-proposal.md

账本：silent-0079, silent-0305, silent-0306。

本批处置：waiting。QHK A10 F24两试同时改变无色药、毒雾、抽弃和自损，未形成单因素整战对照；祭品6血已有模型。彩虹F33T1触发1力1敏可核，但原遗物stack=null且无能力牌计数，不能把总牌数差直接当能力类型；缺可靠类型状态和完整候选兑现对照。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-4acea8e77e41164a

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-184301-postmortem/sl-terminal-proposal.md

账本：silent-0062, silent-0065, silent-0079。

本批处置：waiting。QHK A10 F33第3/6试T3两线均47输出，14/20血价差6未超现护栏8；原答与SL替换不同。24/24死亡是有限预测，第3试T5为截断判断；缺同输入后继、击杀阈值及独立验证，不能改全败排序、护栏或固定朝向。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-aff843ee1f214dc9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-191301-postmortem/proposal-combat-sl.md

账本：silent-0019, silent-0021, silent-0079, silent-0011, silent-0023, silent-0012, silent-0046。

本批处置：waiting。UZ A10 F25四试共享入口，末T3已建触媒/毒雾但敌零毒、6血13挡对34攻击；最少损失原文-15是余血。现有选择/动作审计与端点观测子项不认证整条候选，缺原答→SL→重问→实际完整轮的可验证归属及独立替代路径。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-fa0b9651ab477055

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-191301-postmortem/proposal-potion-resources.md

账本：silent-0019, silent-0020, silent-0023, silent-0239。

本批处置：waiting。UZ A10 F25四次迅捷请求、三次SL恢复及7BNC F14空药资源分开。已有离线药槽端点工具，但7BNC尝试号为空使动作区间未知，完整获药/留奖/饮用/丢弃/恢复因果链与整战留药对照仍缺，不能重标恢复为新药或改药价。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-59cda846fa8581cd

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-191301-postmortem/proposal-plan-conditions.md

账本：silent-0019, silent-0020, silent-0239, silent-0134, silent-0242, silent-0307。

本批处置：waiting。7BNC A10 F14T2原单牌1/8预测后又选择冲刺，原停止策略未执行；原帧14→27→0挡已核。152动作均因尝试边界未知等原因无已连接动作端点，现工具完整候选结果为null；缺原短线完整执行及当前休息投影与旧缓存的统一来源绑定。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-bbf4688a5bb6ed68

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-193934-experience-update/proposal-mechanisms.md

账本：silent-0012, silent-0005, silent-0013, silent-0011, silent-0027, silent-0023, silent-0071, silent-0077, silent-0010, silent-0046, silent-0242, silent-0134, silent-0253, silent-0276, silent-0278, silent-0305, silent-0306。

本批处置：waiting。QHK A10 F33T1彩虹三类触发、T4祭品/附魔撞击15→9→7已核，不能扩成每轮固定加层或全机制已校准。当前自损与若干力敏/毒机制已有模型，彩虹中途类型状态及重放/随机交互未齐；缺逐机制同输入消费者与完整执行验证，宽项不以局部实现关闭。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-2be07d7a101fb78a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-193934-experience-update/proposal-sl.md

账本：silent-0062, silent-0065, silent-0064, silent-0009, silent-0030, silent-0307, silent-0239。

本批处置：waiting。QHK A10 F33与UZ F25全败样本、7BNC F14续问不能认证同一完整候选或更优杀序。既有选择阶段、整轮/终局观测源码均为实际live祖先，但完整候选与实际rollout-best仍null；缺受控后继和独立验证，不改变SL/终局次级比较。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## silent-proposal-3341a78d1a591abd

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-193934-experience-update/proposal-resources.md

账本：silent-0019, silent-0020, silent-0021, silent-0243。

本批处置：waiting。QHK A10 F31净耗19及F32回21、UZ F25三次恢复与末次死亡、7BNC F14实际31血入口可核。已有资源窗口/药槽观测不认证候选终态到下一战的能力、已结毒与资源归属；缺跨模块完整消费链和同条件整战反事实，不能拟新终局价格。

预期与验证：仅在原提案要求的状态、动作、相位及后继均可核后补缺口；用固定原帧复现，保留原答/SL/重问分别记录及全部并列候选。若将来改源码，须撤源码红/恢复绿、原沙箱入口自测、实际live祖先与消费者读回；同局SL不拆独立验证局。本批没有拟合阈值或规则变更，回退不适用。

## 交付边界

十项均waiting；逐项具体缺口和来源账本在上文及proposal-results.json。没有源码、知识数据、规则或测试夹具改动，没有源码提交、live合入或eval版本；没有运行play、LLM、网络或模拟新对局。
不把原经验数据账本shipped冒充本批代码实现。只经根ledger.py update追加本批proposal/report追溯，不重复添加support/repeat，不改claim、first_run、prior、evidence、status、version或shipped记录；具体CLI输入/输出/保护核验另存本目录。
无源码修改，撤源码负对照、tsc、vitest与生产cases均不适用/null。10条原帧事实断言与离线消费者exit0另列，不伪报为源码测试成功。未发生新科学异议，未发新的实际上线通知；没有可以登记shipped的实现。

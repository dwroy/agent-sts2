import hashlib
import importlib.util
import json
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = HERE.parents[2]
PRIMARY = ['QHK1XQ928TTM', 'UZ1T7AH49WMB', '7BNC8QX746YP']


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args, cwd=TREE):
    return subprocess.check_output(['git', '-C', str(cwd), *args], text=True).strip()


def main():
    dispatch = json.loads((HERE / 'dispatch.json').read_text())
    proposals = json.loads((HERE / 'dispatched-proposals.json').read_text())
    runs = json.loads((HERE / 'verified-runs.json').read_text())
    selected_runs = set(dispatch['runs']) | set(PRIMARY)
    spec = importlib.util.spec_from_file_location('extract', TREE / 'learner/extract_evidence.py')
    extraction = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(extraction)
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    checks, data = [], {}
    for stream in manifest:
        name = stream['stream']
        path = HERE / 'evidence' / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = Counter()
        rows = defaultdict(list)
        with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source, path.open('rb') as handle:
            for encoded in handle:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['run_id'] in selected_runs
                assert extraction.run_identity(item['row']) == item['run_id']
                assert item['offset'] + item['bytes'] <= stream['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                counts[item['run_id']] += 1
                if item['run_id'] in PRIMARY or name in ['runs', 'run-plans', 'sl-attempts', 'run-config']:
                    rows[item['run_id']].append(item)
        assert digest.hexdigest() == stream['output_sha256']
        assert all(counts[run] == number for run, number in stream['counts'].items())
        checks.append({'stream': name, 'source_size': stream['source_size'], 'verified_lines': sum(counts.values()),
                       'counts': dict(counts), 'output_sha256': digest.hexdigest(), 'raw_bytes_verified': True})
        data[name] = rows
    save('evidence-readback.json', checks)

    proposal_checks = []
    for item in proposals:
        raw = Path(item['proposal']).read_bytes()
        copied = (HERE / ('original-' + item['id'] + '.md')).read_bytes()
        assert raw == copied
        assert hashlib.sha256(raw).hexdigest() == item['proposal_sha256']
        proposal_checks.append({'id': item['id'], 'path': item['proposal'], 'sha256': item['proposal_sha256'],
                                'ledger': item['ledger'], 'runs': item['runs']})
    save('proposal-readback.json', proposal_checks)

    preparations = []
    for run_id in PRIMARY:
        decisions, excluded = [], []
        for item in data['decisions'][run_id]:
            row = dict(item['row'])
            if not row.get('decision_id'):
                excluded.append({'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
                                 'sha256': item['sha256'], 'label': row.get('label'),
                                 'reason': '原记录无decision_id；单独保留，不伪造ID或重新编号'})
                continue
            row.update(_line=item['line'], _source_sha256=item['sha256'])
            decisions.append(row)
        states = [{**item['row'], '_line': item['line'], '_source_sha256': item['sha256']}
                  for item in data['states'][run_id]]
        save(run_id + '-selection-input.json', {'run': runs[run_id], 'decisions': decisions, 'states': states})
        save(run_id + '-selection-exclusions.json', excluded)
        preparations.append({'run_id': run_id, 'decisions': len(decisions), 'states': len(states),
                             'excluded': excluded, 'source_line_numbers_preserved': True})
    save('consumer-input-preparation.json', preparations)

    state_lines = set(range(303052, 303065)) | {303005, 303046, 303048, 303218, 303219, 303220, 303221,
                  303436, 303437, 303438, 303454, 303455, 303456, 303457, 303458,
                  303798, 303799, 303800, 303801}
    state_lines |= set(range(303634, 303649))
    selected, compact = [], []
    for run_id in PRIMARY:
        for item in data['states'][run_id]:
            if item['line'] not in state_lines:
                continue
            selected.append(item)
            state = item['row']['state']
            run = state.get('run', {})
            combat = state.get('combat') or {}
            player = combat.get('player') or {}
            compact.append({'line': item['line'], 'run_id': run_id, 'floor': run.get('floor'),
                            'turn': state.get('turn'), 'screen': state.get('screen'),
                            'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
                            'block': player.get('block'), 'energy': player.get('energy'),
                            'counters': {key: player.get(key) for key in ['cards_played_this_turn',
                                         'attacks_played_this_turn', 'skills_played_this_turn', 'powers_played_this_turn']},
                            'powers': player.get('powers'), 'potions': run.get('potions'),
                            'rainbow': [r for r in run.get('relics', []) if r.get('relic_id') == 'RAINBOW_RING'],
                            'enemies': [{key: enemy.get(key) for key in ['index', 'enemy_id', 'current_hp',
                                        'max_hp', 'powers', 'intents']} for enemy in combat.get('enemies', [])]})
    save('selected-state-envelopes.json', selected)
    save('selected-state-facts.json', compact)
    decision_lines = {295510, 295620, 295737, 295821, 296165, 296186, 296208, 296226, 296241, 296385, 296386}
    selected_decisions = [item for run_id in PRIMARY for item in data['decisions'][run_id]
                          if item['line'] in decision_lines]
    save('selected-decision-envelopes.json', selected_decisions)

    source_paths = [
        'agent/src/reflex/card-model.ts', 'agent/src/reflex/turn-solver.ts',
        'agent/src/reflex/combat-plan.ts', 'agent/src/reflex/silent-selection-audit.ts',
        'agent/src/reflex/silent-selection-dispatch.ts', 'agent/src/reflex/rollout.ts',
        'agent/src/sim/boss-start.ts', 'agent/src/sim/route-projection.ts',
        'agent/src/sim/route-map.ts', 'agent/src/sim/build-sim-facts.ts',
        'agent/src/sl/explore.ts', 'agent/src/sl/judge.ts',
        'learner/audit-selection.ts', 'learner/lib/selection-execution.ts',
        'learner/lib/selection-observation.ts', 'learner/lib/selection-terminal.ts',
        'learner/lib/selection-turn.ts', 'learner/resource_chain.py',
    ]
    base = git('rev-parse', 'HEAD')
    live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live')
    comparison = []
    for path in source_paths:
        current = (TREE / path).read_bytes()
        base_data = subprocess.check_output(['git', '-C', str(TREE), 'show', base + ':' + path])
        live_data = subprocess.check_output(['git', '-C', str(TREE), 'show', live + ':' + path])
        assert current == base_data
        comparison.append({'path': path, 'base_sha256': hashlib.sha256(current).hexdigest(),
                           'live_sha256': hashlib.sha256(live_data).hexdigest(), 'same_live': current == live_data})
    partial_commits = {
        'a32050fbce4c2863f640468c2dbf378fc9157074': '离线药槽观测子项；不认证完整药水来源或整战价值',
        'e75438488df159b2e8e9d3458cf219b39aadd933': '离线整轮窗口子项；不认证完整候选、因果或线上采用',
        '83512ddcd2c70fd9b983dc38524ff25c8970c1d3': '终态观测端点子项；不补造零血前完整入伤',
        'dc0e6080cb20c508d94c006648cc3edf0188d306': '离线能力与HP端点；不认证完整执行',
    }
    ancestors = []
    for commit, scope in partial_commits.items():
        ancestors.append({'commit': commit, 'scope': scope,
                          'base_ancestor': subprocess.run(['git', '-C', str(TREE), 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
                          'live_ancestor': subprocess.run(['git', '-C', str(TREE), 'merge-base', '--is-ancestor', commit, live]).returncode == 0})
    save('source-readback.json', {'base': base, 'live_readonly_snapshot': live,
                                 'files': comparison, 'partial_existing_sources': ancestors})
    print(json.dumps({'verified_lines': sum(x['verified_lines'] for x in checks),
                      'primary_preparations': preparations, 'sources': len(comparison)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
PRIMARY = ['QHK1XQ928TTM', 'UZ1T7AH49WMB', '7BNC8QX746YP']


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    spec = importlib.util.spec_from_file_location('resource', TREE / 'learner/resource_chain.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    attempts = defaultdict(list)
    for line in (HERE / 'evidence/sl-attempts.evidence.jsonl').open():
        item = json.loads(line)
        attempts[item['run_id']].append(item['row'])
    summary = []
    for run_id in PRIMARY:
        source = json.loads((HERE / (run_id + '-selection-input.json')).read_text())
        starts = defaultdict(list)
        for row in attempts[run_id]:
            if row.get('attempt', 1) > 1 and row.get('started_at'):
                starts[row.get('floor')].append(row['started_at'])
        report = module.resource_chain(source['states'], run_id, 'silent', starts)
        save(run_id + '-resources.json', report)
        summary.append({'run_id': run_id, 'combats': len(report['combats']),
                        'end_kinds': dict(Counter(x['end'] for x in report['combats'])),
                        'resources': [{key: x.get(key) for key in ['sequence', 'floor', 'entry', 'exit',
                                       'last', 'end', 'observed_net_hp_loss']} for x in report['combats']]})
    save('resource-consumer-summary.json', summary)

    facts = json.loads((HERE / 'selected-state-facts.json').read_text())
    by_line = {x['line']: x for x in facts}
    assertions = []

    def confirm(name, actual, expected):
        assert actual == expected, (name, actual, expected)
        assertions.append({'fact': name, 'actual': actual, 'expected': expected})

    def power(line, key):
        return next((x['amount'] for x in by_line[line]['powers'] if x['power_id'] == key), None)

    confirm('QHK F32休息17→38', [by_line[n]['hp'] for n in [303052, 303053]], [17, 38])
    confirm('QHK F33T1三类齐后力敏1/1', [power(303059, p) for p in ['STRENGTH_POWER', 'DEXTERITY_POWER']], [1, 1])
    confirm('QHK 第三类前未列力敏', [power(303058, p) for p in ['STRENGTH_POWER', 'DEXTERITY_POWER']], [None, None])
    confirm('QHK 后续同类不再增力敏', [power(303061, p) for p in ['STRENGTH_POWER', 'DEXTERITY_POWER']], [1, 1])
    confirm('QHK 彩虹遗物计数未提供', by_line[303058]['rainbow'][0]['stack'], None)
    confirm('QHK 未提供能力牌计数', by_line[303058]['counters']['powers_played_this_turn'], None)
    confirm('QHK F33T4祭品/附魔撞击直接生命支付', [by_line[n]['hp'] for n in [303218, 303219, 303220, 303221]], [15, 9, 9, 7])
    confirm('QHK 自损未扣已有格挡', [by_line[n]['block'] for n in [303218, 303219, 303220, 303221]], [16, 16, 22, 22])
    confirm('7BNC F14T2追加牌后本轮27挡', [by_line[n]['block'] for n in [303798, 303799, 303800, 303801]], [14, 14, 27, 0])
    confirm('7BNC 本轮追加期间31血未变', [by_line[n]['hp'] for n in [303798, 303799, 303800, 303801]], [31, 31, 31, 31])
    save('fact-readback.json', {'assertions': assertions, 'count': len(assertions),
                              'scope': '原帧事实复算；不是生产源码测试、策略收益或完整候选认证'})
    print(json.dumps({'fact_assertions': len(assertions), 'resource_runs': PRIMARY}, ensure_ascii=False))


if __name__ == '__main__':
    main()

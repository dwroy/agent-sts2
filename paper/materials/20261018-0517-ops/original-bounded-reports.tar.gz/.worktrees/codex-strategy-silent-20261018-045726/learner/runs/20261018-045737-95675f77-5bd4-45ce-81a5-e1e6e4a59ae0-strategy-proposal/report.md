# 静默A10策略提案逐项复核

批次：20261018-045726-strategy-proposal。记录时间：2026-10-18 05:11:08 +0800。

本批为普通消费队列，learn.json绑定10个proposal_ids，无research_request、implementation_request或proposal_repair。专题旧请求绑定另批，不承接。初始HEAD为738433d865d943e80b7726588fa2bbeb3a1980da，初始tracked clean；按任务合并main快进至完整base 93bc8e650bc84aac72a8dc0f7a3f76bb06d050d2，无冲突。只处理这10项，不领取其他队列。

六局均由runs.jsonl核实SILENT/A10。原10份Markdown逐SHA匹配并另存.original.md，25个关联经验条目从本工作树knowledge/characters/silent读回。未新增游戏结论、提案ID、源码、知识或行为参数；不改变铁甲及其他未观察分支。原经验已上线状态不等于代码提案已实现。

来源冻结与复核：evidence/evidence-manifest.json保存8流source_size/逐局计数/输出SHA；每条保存原行号、offset/bytes/SHA与显式归局。verification.json重新seek核验8274条原字节、JSON内容及身份。states4062、decisions3941、SL38、run-config6、run-plans33、brain188、runs6、fight-plans0。全源6条坏JSON没有进入归局证据，无法确认其所属；0残行。本截点fight-plans为0只说明未选到，不倒推历史日志缺失。无旧run-plans零行截点复核，本次33条不是把正文提及当run身份。

分析范围为state-windows.jsonl的1473帧、decision-windows.jsonl的1444条关键窗口，四组完整fingerprint配对另存paired-decisions-enriched.json与paired-round-facts.json。抽取全局原行不等于逐轮解释全部对局。旧101局/历史支持分母没有重做。

数值复算：observed-facts-check.json共36个材料断言通过，仅核原日志事实，不是生产源码测试、同随机配对模拟、完整候选消费者认证或后移验证。没有新源码，tsc/vitest/cases及撤源码失败/恢复通过均未运行、结果null；不编造测试、提交、合入或版本。

当前源码参照固定base，source-manifest.json记录15叶blob/SHA及真实live祖先。读回live=58eaab9e8062c466efff21cbc1cd18662d75896b。11叶blob相同，4叶差异另存live-source-diff.patch：注释署名以及与这六局窗口无关的有条件后续整战修正；不把当时+dirty运行树说成当前源码。所有15叶最后源码提交均为该live祖先，仍不能把窄模块存在当整项实现。source/仅保存所需源码原字节.txt，base-diff.patch为空；未复制整仓。

## 四组当轮实际配对

|来源|原/替线实损|原/替线本体扣血|替线减原线|限制|
|---|---:|---:|---|---|
|8JRE F33 T2|3/15|10/17|多12血、多7进度|0/24与5/24死亡比例不同，后续并非受控整战|
|YF F48 T1|0/9|45/38|多9血、少7进度|候选预测0/10与54/36不冒充实打|
|XP F33 T3|9/14|24/27|多5血、多3进度|B2零胜不等于风险相同|
|XP F33 T1|2/10|25/34|多8血、多9进度|替线另建1力量，后期抽牌/出牌变化|

这些结果支持资源分账，不能单独拟最优惩罚、禁止探索或固定先杀序。对已确认数值无需再等待胜局；要改长期策略，仍需明确假设、完整离线原/替线和后移独立局。

## 逐项处置

- `silent-proposal-c20b5139dd0dff71`：waiting。缺火花增长、污染清空、弱与迷雾毒/挡收益的同输入生产联合重放认证；未核出可独立新增的规则失配，不强制少打技能。
- `silent-proposal-ae9e692d680e3819`：waiting。缺逐实体抢夺来源的完整归属及遗忘退场返敏端点；现场负属性和失落返力片段不足以实现全套返还，也不支持固定击杀序。
- `silent-proposal-52f1e1bd2e7db0ed`：waiting。第一观测取当前进阶数据和房间五样本门槛已有实现；缺加压、弱、覆甲的联合生产重放及完整减层条件，不能把读取子项记成整项duplicate。
- `silent-proposal-6dd8bbff876be528`：waiting。逐实体高电压路径已有；缺可靠召唤代际身份、历史实际移动输入及另一目标顺序的完整后继，不能凭index变化增加继承或清零规则。
- `silent-proposal-578e415a259e6835`：waiting。缺跨抽弃牌、生成、用药和重规划的完整候选持续归属及沙坑/路线资源联合认证；当前同盘材料不支持修改探索、护栏或血价系数。
- `silent-proposal-c0767768bf6a7ab1`：waiting。当轮0/9与45/38已复核，预测比较已有窄实现；缺原/替线动作段完整执行归属、分源血价及受控整战后继，保留探索和惩罚参数。
- `silent-proposal-a46bdb7fe711d79a`：waiting。当前阶段/持有/已建快照已有live实现；缺逐候选施毒、毒结算、遗忘之魂额外扣血及敏捷取得顺序的完整执行比对，不能据零毒末态调整排序。
- `silent-proposal-1044224808015e5c`：waiting。当轮+5血/+3进度与+8血/+9进度已复核；缺同抽序/随机/预算的完整替线和成长后继，不把B2零差当作风险相同或拟新探索优先级。
- `silent-proposal-7cbc6005db712ba9`：waiting。朝向、弱、临时减力、轮初挡和后取得成长局部事实已有窄实现；缺完整候选联合执行及消费者认证，不把字段/公式存在记成整项duplicate或改持续价值权重。
- `silent-proposal-c59f592f1427a67e`：waiting。缺逐来源资源账、完整候选执行及路线/休息/药水时机的受控替线联合认证；本批未重做原101局历史审计，不能凭旧宽支持数关闭整项。

完整逐项证据、账本、反例、旧/新行为、验证和回退见proposal.md。没有新提交、fixes=[]、merged=null，无eval版本、无shipped；不进入live合入流程，不修改运维prompt或启动游戏。

30个原账本只经根ledger.py update追加本报告/提案链接与本批复核说明；不添加重复support/repeat，不改claim、首证、prior、原evidence、status、version、effect。实际CLI回执与前后保护核验在ledger-update.out/err及ledger-protected-readback.json。CLI实际退出0，30项链接已读回，受保护字段0变更。

保留一次直接取样初稿的TypeError：所取首帧非战斗，combat为null；改用combat or {}并只显示核实本角色战斗帧。没有因此修改策略、丢原日志或覆盖零行报告。第一次paired-decisions.json仅保原字段，完整顶层rollout/SL/原答另存-enriched.json，初稿保留。

最终结构化回报见result.json；源码测试三个字段为null。tracked clean、固定base、无生产/知识差异及产物清单由final-readback.json、artifact-manifest.json读回，不以临时材料检查冒称游戏收益。


## 追溯归属待运维核对

另有历史追溯不一致：原提案将silent-vajra-opening-strength（金刚杵）对应silent-0016，但该账本claim是护喉甲覆甲；本批只记录归属待核，不将其当同机制支持或改旧claim。 当前经验条目scope=relic:VAJRA，队列原Markdown和原账本均保留；这不是本局金刚杵数值的反证，而是经验→账本的映射问题。需由ops接续核原来源并经watcher向Roy说明；本批未发送外部消息，未代填已送达或ACK。


终核（2026-10-18 05:14:33 +0800）：HEAD仍为base且tracked clean；源码/知识差异为空，10原提案SHA和15源码快照SHA/blob匹配；根账本30项CLI链接及stdout所列30个ID均读回、受保护字段0变更。gitleaks dir扫描本批约224.13 MB、退出0且发现0（完整日志见gitleaks.out），不是生产测试。初次终核误把空格分隔的CLI ID回执当JSON而失败，原件finalization-initial-failure.txt保留；修正只读解析后通过，未重复更新根账本。最终无提交/合入/版本，tests三null。

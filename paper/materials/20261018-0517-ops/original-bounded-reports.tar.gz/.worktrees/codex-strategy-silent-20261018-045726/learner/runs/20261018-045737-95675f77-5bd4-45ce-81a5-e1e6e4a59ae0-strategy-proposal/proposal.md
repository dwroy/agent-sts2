# 静默A10策略提案逐项复核

批次：20261018-045726-strategy-proposal。记录时间：2026-10-18 05:11:08 +0800。

本批为普通消费队列，learn.json绑定10个proposal_ids，无research_request、implementation_request或proposal_repair。专题旧请求绑定另批，不承接。初始HEAD为738433d865d943e80b7726588fa2bbeb3a1980da，初始tracked clean；按任务合并main快进至完整base 93bc8e650bc84aac72a8dc0f7a3f76bb06d050d2，无冲突。只处理这10项，不领取其他队列。

六局均由runs.jsonl核实SILENT/A10。原10份Markdown逐SHA匹配并另存.original.md，25个关联经验条目从本工作树knowledge/characters/silent读回。未新增游戏结论、提案ID、源码、知识或行为参数；不改变铁甲及其他未观察分支。原经验已上线状态不等于代码提案已实现。

来源冻结与复核：evidence/evidence-manifest.json保存8流source_size/逐局计数/输出SHA；每条保存原行号、offset/bytes/SHA与显式归局。verification.json重新seek核验8274条原字节、JSON内容及身份。states4062、decisions3941、SL38、run-config6、run-plans33、brain188、runs6、fight-plans0。全源6条坏JSON没有进入归局证据，无法确认其所属；0残行。本截点fight-plans为0只说明未选到，不倒推历史日志缺失。无旧run-plans零行截点复核，本次33条不是把正文提及当run身份。

分析范围为state-windows.jsonl的1473帧、decision-windows.jsonl的1444条关键窗口，四组完整fingerprint配对另存paired-decisions-enriched.json与paired-round-facts.json。抽取全局原行不等于逐轮解释全部对局。旧101局/历史支持分母没有重做。

数值复算：observed-facts-check.json共36个材料断言通过，仅核原日志事实，不是生产源码测试、同随机配对模拟、完整候选消费者认证或后移验证。没有新源码，tsc/vitest/cases及撤源码失败/恢复通过均未运行、结果null；不编造测试、提交、合入或版本。

当前源码参照固定base，source-manifest.json记录15叶blob/SHA及真实live祖先。读回live=58eaab9e8062c466efff21cbc1cd18662d75896b。11叶blob相同，4叶差异另存live-source-diff.patch：注释署名以及与这六局窗口无关的有条件后续整战修正；不把当时+dirty运行树说成当前源码。所有15叶最后源码提交均为该live祖先，仍不能把窄模块存在当整项实现。source/仅保存所需源码原字节.txt，base-diff.patch为空；未复制整仓。

## 四组当轮实际配对

|来源|原/替线实损|原/替线本体扣血|替线减原线|限制|
|---|---:|---:|---|---|
|8JRE F33 T2|3/15|10/17|多12血、多7进度|0/24与5/24死亡比例不同，后续并非受控整战|
|YF F48 T1|0/9|45/38|多9血、少7进度|候选预测0/10与54/36不冒充实打|
|XP F33 T3|9/14|24/27|多5血、多3进度|B2零胜不等于风险相同|
|XP F33 T1|2/10|25/34|多8血、多9进度|替线另建1力量，后期抽牌/出牌变化|

这些结果支持资源分账，不能单独拟最优惩罚、禁止探索或固定先杀序。对已确认数值无需再等待胜局；要改长期策略，仍需明确假设、完整离线原/替线和后移独立局。

## 1. silent-proposal-c20b5139dd0dff71：感染棱柱：技能收益与污染血价

状态：waiting。账本：silent-0168。来源任务：experience-update；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md（SHA256 bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c）。

证据：DUZUBAJ3A8GP F27 T4–T6；states 274830–274839：火花3→6、T4两技能污染0→3→6，能力勒紧不加；T5污染0→6→12→18，实际损9并结算13毒伤，下一轮污染消失。账本silent-0168。

反例/范围：技能同时给挡、施毒或虚弱；不能仅按新增污染认定少打技能更优。旧复盘所报迷雾少6毒属于另一个卡牌模型问题，本批不领取该修复队列。

旧/当前行为：turn-solver.ts已有vitalSpark、技能累积污染及弱前污染换算；rollout.ts已有selfPowers的火花增长入口；SL资源比较已分列污染和轮末毒。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：缺火花增长、污染清空、弱与迷雾毒/挡收益的同输入生产联合重放认证；未核出可独立新增的规则失配，不强制少打技能。

继续验证：冻结本批状态、手牌、敌方移动表与动作前缀，逐步对照污染、逐击威胁、挡、毒及本体血；先核联合消费者，再评估另线，不拟全局技能惩罚。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 2. silent-proposal-ae9e692d680e3819：失落/遗忘：逐实体抢夺与返还

状态：waiting。账本：silent-0183, silent-0005。来源任务：experience-update；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md（SHA256 b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5）。

证据：5PM6JAQG6FNQ F39 T4–T6；states 274351–274366、274391–274397：两次抢夺后力敏各−4；首试两步法只恢复到0敏，失落毒死后力量归0；T6遗忘再夺2敏。末试单步法至−2敏仍死亡。账本silent-0183、silent-0005。

反例/范围：敌人的POSSESS_*层数为1时属性已有4，不能把该能力层数直接当归还量；本局没有遗忘死亡后返敏端点，未实打相反击杀序的完整胜局。

旧/当前行为：combat-plan.ts接受负属性和POSSESS_*现场；负属性伤挡计算不能证明已实现逐来源死亡返还。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：缺逐实体抢夺来源的完整归属及遗忘退场返敏端点；现场负属性和失落返力片段不足以实现全套返还，也不支持固定击杀序。

继续验证：后续同角色局逐次保留抢夺前后及退场端点；按来源累积被夺属性，不能由当前总属性反推来源；另杀序须独立记录完整后继。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 3. silent-proposal-52f1e1bd2e7db0ed：下水道蚌：当前进阶读取与成长

状态：waiting。账本：silent-0231。来源任务：experience-update；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md（SHA256 651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376）。

证据：CA5KE8GFJ9X2 F13 T1–T5；states 273239/273252/273263：力量0/4/8、未弱喷水11/15/19；273254/273268弱后11/14。末轮2HP+10挡对14，完整需损4、缺2；死亡后剩16敌血。账本silent-0231。

反例/范围：轮初覆甲9/9/8/7/6只说明这些现场，未隔离完整减层条件；实际荆棘反伤另记，不能拿死亡截断的2HP当完整攻击代价。

旧/当前行为：monster-db.ts的moveDamageAt/monsterHpAt在exact分支无五样本门槛；move-model.ts传入当前asc；room-costs.ts的MEASURED_ROOM_MIN_N仍为5。该读取子项已存在。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：第一观测取当前进阶数据和房间五样本门槛已有实现；缺加压、弱、覆甲的联合生产重放及完整减层条件，不能把读取子项记成整项duplicate。

继续验证：用固定A10输入验证已观察加压和弱的连续转换；未观察覆甲条件保留未知，不把战损样本直接改成固定房间成本。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 4. silent-proposal-6dd8bbff876be528：电击机器人：逐实体高电压成长

状态：waiting。账本：silent-0233, silent-0209。来源任务：experience-update；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md（SHA256 48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5）。

证据：5PM6JAQG6FNQ F38 T3–T4；states 274308–274317：同最大血23电击高电压均2、力量2→4、攻击17→19；T3仍攻击，T4群伤后才退场。账本silent-0233、silent-0209。

反例/范围：敌人退场后index发生重排，不当成新召唤代际ID；另线题面35伤/损3未实打，不能把预计少损27当成后场可赢。

旧/当前行为：rollout.ts的STRENGTH_GROWTH_POWERS含HIGH_VOLTAGE_POWER，存入各SimEnemy.growth并逐敌回合增加；新召唤走spawnedEnemy。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：逐实体高电压路径已有；缺可靠召唤代际身份、历史实际移动输入及另一目标顺序的完整后继，不能凭index变化增加继承或清零规则。

继续验证：冻结同实体连续状态并保留召唤/退场边界与移动输入，区分当前实体增长与新实体初值；不建立固定优先击杀规则。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 5. silent-proposal-578e415a259e6835：沙虫：选择阶段、护栏和真实资源兑现

状态：waiting。账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。来源任务：experience-update；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md（SHA256 e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a）。

证据：8JRE1C4H4Z2W F33 T2：decisions270216/270282完整指纹相同，states276208→276212及276274→276278复算原/替线损3/15、扣10/17。末试T11 states276429–276434：5HP、22挡对37，24毒实结后剩130。另复读原提案F17 T6、F33第二试T5护栏与前段资源。账本见本项继承的12个ID。

反例/范围：末试T2保血却少输出，仍失败；F17抽牌后重规划，候选差额不是实际整轮省血。原提案98局历史统计本批未重做，不增加支持分母。

旧/当前行为：silent-selection-audit.ts保存原答/护栏后/SL后预测；silent-selection-dispatch.ts只记单步回执，state_effect_verified=false、whole_plan_executed=null、actual_turn=null。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：缺跨抽弃牌、生成、用药和重规划的完整候选持续归属及沙坑/路线资源联合认证；当前同盘材料不支持修改探索、护栏或血价系数。

继续验证：先把候选身份贯穿实际动作段并核状态效果，分别验首/三试T2、第二试T5、F17 T6和末T11；已实现预测审计不冒称整线完成，未来策略比较按独立run留出。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 6. silent-proposal-c0767768bf6a7ab1：实验体SL：全败并列仍有当轮代价

状态：waiting。账本：silent-0079。来源任务：postmortem；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md（SHA256 28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb）。

证据：YF0LXT1QSTGG F48第二/第三试T1；decisions271309/271348同指纹，states277327→277337与277366→277373实际损0/9、扣45/38。原提案另记271354截断防御续步、第四试T5弃牌后未完成候选。账本silent-0079。

反例/范围：第六次恢复防御后T1零损仍T5败；F33第二试SL确实获胜，因此不能由F48全败否定所有探索。两候选24/24死不等于资源相同。

旧/当前行为：silent-sl-comparison.ts与silent-sl-resource-comparison.ts已有候选/当轮预测差额、未验证执行说明；保留actual_turn_result=null。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：当轮0/9与45/38已复核，预测比较已有窄实现；缺原/替线动作段完整执行归属、分源血价及受控整战后继，保留探索和惩罚参数。

继续验证：固定比较原答、SL替换、覆盖重放、弃牌重规划及实际结束；验证F33成功SL反例仍保留。事实审计可按确定输入补齐，不以缺胜线否定已确认数值。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 7. silent-proposal-a46bdb7fe711d79a：实验体：阶段、施毒与敏捷兑现时点

状态：waiting。账本：silent-0021, silent-0027, silent-0028, silent-0085。来源任务：postmortem；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md（SHA256 eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6）。

证据：YF0LXT1QSTGG F48末试T3–T5；states277512→277513旧毒4→0、新阶段212HP；277519触媒2而零毒；277523已有23挡/5敏，277526后得6敏挡仍23。末轮本体扣37，18血23挡对44。账本silent-0021、0027、0028、0085。

反例/范围：前五试曾建立毒雾/余像仍失败；持有升级毒爆发不等于本阶段施放，不据此强制能力先手、另弃牌或牌组上限。

旧/当前行为：silent-phase-current.ts已按本角色A10 F48的111/212HP现场分列持有、已建能力、当前毒、当前挡敏；poison_damage_already_dealt=null。rollout.ts已清上一阶段毒/力量。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：当前阶段/持有/已建快照已有live实现；缺逐候选施毒、毒结算、遗忘之魂额外扣血及敏捷取得顺序的完整执行比对，不能据零毒末态调整排序。

继续验证：固定阶段前后状态，分清牌伤、消耗伤、毒结算与后取得敏捷，补逐候选真实派发及重规划边界；不将当前快照宣称为候选整战校准。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 8. silent-proposal-1044224808015e5c：双蟹SL：零胜并列与成长取舍

状态：waiting。账本：silent-0079。来源任务：postmortem；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md（SHA256 4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5）。

证据：XP2SL33HT0D9 F33 T3：decisions271992/272040同指纹，states278028→278031与278076→278079损9/14、扣24/27。T1 decisions271982/272195同指纹，278018→278023及278231→278236损2/10、扣25/34，末线另建1力量。账本silent-0079。

反例/范围：末试T2零损，T3有面向/抽牌变化；成长贡献不能抹掉。两线B2零胜只描述有限样本，不等同风险相同，更不能用末试更早死亡单归因T1替换。

旧/当前行为：候选比较、资源差值和选择阶段审计已有；explore.ts保留B2/五轮有限样本门槛及已知失败后的未试线探索。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：当轮+5血/+3进度与+8血/+9进度已复核；缺同抽序/随机/预算的完整替线和成长后继，不把B2零差当作风险相同或拟新探索优先级。

继续验证：保存相同起点的原/替线完整动作和后继，独立列手里剑成长及资源，未来同角色A10新局留作验证；不填全局HP惩罚常数。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 9. silent-proposal-7cbc6005db712ba9：双蟹：朝向、临时减力和轮初格挡

状态：waiting。账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。来源任务：postmortem；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md（SHA256 f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291）。

证据：XP2SL33HT0D9 F33末试T2 states278236–278242：轮初14挡，镣铐爪0→−9力量，斗篷另6共20挡且零损，T3恢复0。T4 278249/278252/278253火箭57→38→28；T5 278260→278261已结毒10、余153/125。账本见本项7个ID。

反例/范围：普通镣铐及本局T2船夹板只代表本次条件；原提案引用的更早A1/A6两局不在本批派发清单，本批不重复抽取，不冒称重新核实其历史分母。

旧/当前行为：move-model.ts临时减力列表含DARK_SHACKLES_POWER，rollout.ts将临时减力加回后轮；passive-pieces.ts船夹板T2/14已有；当轮求解有朝向/弱及格挡路径。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：朝向、弱、临时减力、轮初挡和后取得成长局部事实已有窄实现；缺完整候选联合执行及消费者认证，不把字段/公式存在记成整项duplicate或改持续价值权重。

继续验证：按57→38→28、14+6→20、0→−9→0和终局11/6/17固定校验，并接实际动作段和消费者；额外触发条件及未观察分支保留现状。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。

## 10. silent-proposal-c59f592f1427a67e：综合经验：资源链、能力兑现与SL血价

状态：waiting。账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。来源任务：experience-update；目标任务strategy-proposal。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md（SHA256 81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2）。

证据：YF0LXT1QSTGG F48 T1/T4/T5与XP2SL33HT0D9 F33 T1–T5，复用本批四组同指纹配对及阶段/减力/朝向帧。复读原提案两局路线、休息和药水取得/恢复/使用分账。账本见本项继承的22个ID。

反例/范围：原提案101局/1499房、历史普通/升级镣铐22次和船夹板50帧是旧研究范围；本批只分析六派发局关键窗口，没有重新审计101局或把旧支持数变成本次消费者验证。

旧/当前行为：资源预测比较、阶段快照、选择阶段审计、单步派发回执等窄模块均可核真实live祖先；它们各自保留执行未证/actual_turn为空。

本次预期行为：保留现有选项、排序和规则；不把待定条件作为既定规则。具体未实现原因：缺逐来源资源账、完整候选执行及路线/休息/药水时机的受控替线联合认证；本批未重做原101局历史审计，不能凭旧宽支持数关闭整项。

继续验证：将每个资源来源接到本次动作/状态证据，SL恢复不计回血、不将库存恢复当新取得；后续按独立局验证规则，保留原经验及旧研究历史。

拟合/时间切分：本批仅A10发现样本及固定事实核验，同局SL不扩独立分母；新A10完局按run分组、结束时间后移。未观察角色/进阶不外推。回退：本次没有源码需要回退；未来实现用真实源码提交回退，日志/失败/账本保留。



## 追溯归属待运维核对

另有历史追溯不一致：原提案将silent-vajra-opening-strength（金刚杵）对应silent-0016，但该账本claim是护喉甲覆甲；本批只记录归属待核，不将其当同机制支持或改旧claim。 当前经验条目scope=relic:VAJRA，队列原Markdown和原账本均保留；这不是本局金刚杵数值的反证，而是经验→账本的映射问题。需由ops接续核原来源并经watcher向Roy说明；本批未发送外部消息，未代填已送达或ACK。

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
STATES = {s['line']: s for s in map(json.loads, (OUT / 'state-windows.jsonl').open())}
CHECKS = []


def check(name, lines, actual, expected):
    assert actual == expected, (name, actual, expected)
    CHECKS.append({'name': name, 'state_lines': lines, 'actual': actual, 'expected': expected})


def player(line, power):
    return STATES[line]['powers'].get(power, 0)


def enemy(line, power, index=0):
    return STATES[line]['enemies'][index]['powers'].get(power, 0)


def damage(line, index=0):
    return sum((i.get('total_damage') or 0) for i in STATES[line]['enemies'][index]['intents'])


for pair, expected in zip(json.loads((OUT / 'paired-round-facts.json').read_text()), [(12, 7), (9, -7), (5, 3), (8, 9)]):
    actual = pair['delta']
    check('同指纹当轮血价/本体进度差 ' + str(pair['pair']),
          [r['start_line'] for r in pair['rounds']] + [r['end_line'] for r in pair['rounds']],
          (actual['hp_loss'], actual['body_hp_removed']), expected)

check('棱柱T4火花3', [274830], enemy(274830, 'VITAL_SPARK_POWER'), 3)
check('棱柱T4能力不增加污染', [274831, 274832],
      [player(n, 'TAINTED_POWER') for n in [274831, 274832]], [3, 3])
check('棱柱T4两技能污染', [274830, 274831, 274833],
      [player(n, 'TAINTED_POWER') for n in [274830, 274831, 274833]], [0, 3, 6])
check('棱柱T5火花6', [274834], enemy(274834, 'VITAL_SPARK_POWER'), 6)
check('棱柱T5三技能污染', [274834, 274836, 274837, 274838],
      [player(n, 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]], [0, 6, 12, 18])
check('棱柱T5实际损9/结毒13', [274834, 274839],
      [STATES[274834]['hp'] - STATES[274839]['hp'], STATES[274834]['enemies'][0]['hp'] - STATES[274839]['enemies'][0]['hp']], [9, 13])
check('棱柱下一轮污染已消失', [274839], player(274839, 'TAINTED_POWER'), 0)
check('蚌喷水轮力量0/4/8', [273239, 273252, 273263],
      [enemy(n, 'STRENGTH_POWER') for n in [273239, 273252, 273263]], [0, 4, 8])
check('蚌未弱喷水11/15/19', [273239, 273252, 273263],
      [damage(n) for n in [273239, 273252, 273263]], [11, 15, 19])
check('蚌弱后11/14', [273254, 273268], [damage(n) for n in [273254, 273268]], [11, 14])
check('蚌末轮完整需损4/缺2', [273268],
      [damage(273268) - STATES[273268]['block'], damage(273268) - STATES[273268]['block'] - STATES[273268]['hp']], [4, 2])
check('蚌死亡帧剩16', [273269], [STATES[273269]['hp'], STATES[273269]['enemies'][0]['hp']], [0, 16])
check('电击T3/T4同最大血23', [274308, 274313],
      [STATES[274308]['enemies'][4]['max_hp'], STATES[274313]['enemies'][3]['max_hp']], [23, 23])
check('电击高电压2与力量2/4', [274308, 274313],
      [[enemy(274308, 'HIGH_VOLTAGE_POWER', 4), enemy(274308, 'STRENGTH_POWER', 4)],
       [enemy(274313, 'HIGH_VOLTAGE_POWER', 3), enemy(274313, 'STRENGTH_POWER', 3)]], [[2, 2], [2, 4]])
check('电击威胁17/19', [274308, 274313], [damage(274308, 4), damage(274313, 3)], [17, 19])
check('抢夺后力敏各负4', [274351], [player(274351, 'STRENGTH_POWER'), player(274351, 'DEXTERITY_POWER')], [-4, -4])
check('首试两步法只恢复至零敏', [274351, 274354],
      [player(274351, 'DEXTERITY_POWER'), player(274354, 'DEXTERITY_POWER')], [-4, 0])
check('失落退场后力量恢复零', [274357, 274358],
      [player(274357, 'STRENGTH_POWER'), player(274358, 'STRENGTH_POWER')], [-4, 0])
check('遗忘再次抢敏', [274362], player(274362, 'DEXTERITY_POWER'), -2)
check('实验体阶段旧毒4到零/新本体212', [277512, 277513],
      [enemy(277512, 'POISON_POWER'), enemy(277513, 'POISON_POWER'), STATES[277513]['enemies'][0]['hp']], [4, 0, 212])
check('实验体触媒2但零毒', [277519],
      [player(277519, 'ACCELERANT_POWER'), enemy(277519, 'POISON_POWER')], [2, 0])
check('实验体后得敏捷不倒补挡', [277523, 277526],
      [[player(n, 'DEXTERITY_POWER'), STATES[n]['block']] for n in [277523, 277526]], [[5, 23], [6, 23]])
check('实验体末轮扣37', [277519, 277527],
      STATES[277519]['enemies'][0]['hp'] - STATES[277527]['enemies'][0]['hp'], 37)
check('实验体末轮18血23挡对44', [277527],
      [STATES[277527]['hp'], STATES[277527]['block'], damage(277527)], [18, 23, 44])
check('沙虫末轮5血22挡对37', [276433],
      [STATES[276433]['hp'], STATES[276433]['block'], damage(276433)], [5, 22, 37])
check('沙虫末轮毒实扣24/仍余130', [276433, 276434],
      [STATES[276433]['enemies'][0]['hp'] - STATES[276434]['enemies'][0]['hp'], STATES[276434]['enemies'][0]['hp']], [24, 130])
check('双蟹T2轮初14挡', [278236], STATES[278236]['block'], 14)
check('镣铐当轮负9/次轮恢复', [278237, 278242],
      [enemy(278237, 'STRENGTH_POWER'), enemy(278242, 'STRENGTH_POWER')], [-9, 0])
check('双蟹14加6挡/实际零损', [278236, 278240, 278242],
      [STATES[278240]['block'], STATES[278236]['hp'] - STATES[278242]['hp']], [20, 0])
check('火箭朝向/弱分别57到38到28', [278249, 278252, 278253],
      [damage(n, 1) for n in [278249, 278252, 278253]], [57, 38, 28])
check('末蟹毒实扣10/本体余153及125', [278260, 278261],
      [sum(e['hp'] for e in STATES[278260]['enemies']) - sum(e['hp'] for e in STATES[278261]['enemies']),
       [e['hp'] for e in STATES[278261]['enemies']]], [10, [153, 125]])
check('末蟹11血6挡对17', [278260],
      [STATES[278260]['hp'], STATES[278260]['block'], damage(278260)], [11, 6, 17])

(OUT / 'observed-facts-check.json').write_text(json.dumps({
    'scope': '原始日志数值复算，不是生产源码测试或消费者认证',
    'checks': CHECKS, 'checks_passed': len(CHECKS),
}, ensure_ascii=False, indent=2) + '\n')
print('材料复算通过：', len(CHECKS), '；tsc/vitest/cases 均未运行。')

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = json.loads((OUT / 'dispatch.json').read_text())['binding']['runs']
WINDOWS = {
    'DUZUBAJ3A8GP': {27, 28, 29, 30},
    '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 29, 30, 31, 32, 33},
    'YF0LXT1QSTGG': {33, 45, 47, 48},
    'XP2SL33HT0D9': {22, 30, 31, 32, 33},
}


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = None
    values = [row.get('run_id'), state.get('run_id'), row.get('run')]
    if isinstance(fp, dict):
        values.append(fp.get('run'))
    ids = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(ids)) if len(ids) == 1 else None


def powers(holder):
    return {p['power_id']: p.get('amount') for p in holder.get('powers', [])}


def compact_state(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'], 'ts': row.get('observed_ts', row.get('ts')),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'in_combat': state.get('in_combat'), 'hp': player.get('current_hp', run.get('current_hp')),
        'block': player.get('block'), 'energy': player.get('energy'), 'powers': powers(player),
        'played': player.get('cards_played_this_turn'), 'attacks_played': player.get('attacks_played_this_turn'),
        'actions': state.get('available_actions'),
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'), 'upgraded': c.get('upgraded')} for c in combat.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'max_hp': e.get('max_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
                     'powers': powers(e), 'move': e.get('move_id'), 'intents': e.get('intents')} for e in combat.get('enemies', [])],
    }


def main():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    compact = []
    decisions = []
    verification = []
    selected = defaultdict(list)
    for stream in manifest:
        name = stream['stream']
        path = OUT / 'evidence' / (name + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
        counts = Counter()
        with path.open() as extracted, (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as raw:
            for line in extracted:
                item = json.loads(line)
                raw.seek(item['offset'])
                original = raw.read(item['bytes'])
                assert hashlib.sha256(original).hexdigest() == item['sha256']
                assert json.loads(original) == item['row']
                assert identity(item['row']) == item['run_id'] in RUNS
                counts[item['run_id']] += 1
                if name == 'states':
                    state = compact_state(item)
                    if state['floor'] in WINDOWS[state['run']]:
                        compact.append(state)
                        selected[state['run']].append(item)
                elif name == 'decisions':
                    row = item['row']
                    if row.get('floor') in WINDOWS[item['run_id']]:
                        decisions.append(item)
        assert all(counts[run] == expected for run, expected in stream['counts'].items())
        verification.append({'stream': name, 'verified': sum(counts.values()), 'counts': dict(counts),
                             'output_sha256': stream['output_sha256'], 'source_size': stream['source_size'],
                             'invalid_lines': stream['invalid_lines'], 'incomplete_lines': stream['incomplete_lines']})
    (OUT / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'state-windows.jsonl').write_text(''.join(json.dumps(s, ensure_ascii=False) + '\n' for s in compact))
    (OUT / 'decision-windows.jsonl').write_text(''.join(json.dumps(s, ensure_ascii=False) + '\n' for s in decisions))
    indexes = {}
    for run, items in selected.items():
        by_time = defaultdict(list)
        for item in items:
            row = item['row']
            for stamp in {row.get('ts'), row.get('observed_ts')} - {None}:
                by_time[stamp].append(item)
        indexes[run] = by_time
    by_line = {item['line']: item for item in decisions}
    pairs = []
    for left, right in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
        a, b = by_line[left], by_line[right]
        assert a['row']['fingerprint'] == b['row']['fingerprint']
        assert a['run_id'] == b['run_id']
        matches = []
        for item in [a, b]:
            row = item['row']
            states = indexes[item['run_id']].get(row.get('observed_ts'), [])
            matches.append({'decision_line': item['line'], 'observed_ts': row.get('observed_ts'),
                            'matching_state_lines': [s['line'] for s in states],
                            'chosen': row.get('chosen'), 'rationale': row.get('rationale'),
                            'answers': row.get('answers'), 'rollout': row.get('rollout'),
                            'sl_retry': row.get('sl_retry'), 'boss_sim': row.get('boss_sim'),
                            'sl_attempt': row.get('sl_attempt')})
        pairs.append({'run': a['run_id'], 'same_fingerprint': True, 'pair': [left, right], 'observations': matches})
    (OUT / 'paired-decisions.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'verified_rows': sum(x['verified'] for x in verification),
                      'state_windows': len(compact), 'decision_windows': len(decisions), 'fingerprint_pairs': len(pairs)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

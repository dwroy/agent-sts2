# H0/r3 女王力量与端点反证交付

新窄源/经验及实际消费者已交付；本阶段continue，六目标质量修复未完成。

请求roy-20261017-human-pace-h0，revision3，input SHA256 1e1c259a15f1824119d0009747a89a60f60171705cb051b6c627597804bceea7；原同codex3 owner/thread/WT接续。旧H0/r1、r3 blocked报告/锁忙/失败/未知/缓存和R386/R388/R392均保留，无新父项、模型/对局或自然验收。

新source e2b0ea2cfdccba26e917bb72728f65049158fe4a（parent 29ab3db709e6a38e78a9039e5612f117aed53747），仅2源码/1固定回归/经验JSON四叶。actual live merge a1ca997494b61d602964e882d1cf5c3a19d80d2a，publication a845988ecd052864f78141f12a11c7c47a44a3ba；当前观察live ee57b0c8aa773a7303d404eb98f8a1a03a5c66b8。发布专题S1.silent-h0-queen-ally-strength1，正式release_id/唯一精确树宿主/ledger0509、0510 shipped由ops核，不代填ACK。原R392/0507窄交付已核，原完整host1及原两失败题补验0分列，不借旧绿。

女王：原cut121个就绪且双方存活窗/29 A10局支持Queen419/Amalgam211/Minion1、Burn Bright令活盟友净增1力量，女王不增。旧full漏该路径；只修该签名/原strength0/full。角色/进阶/短rollout/未知签名及纸鹤A2保持。实际首命令后probe：186女王窗，121可比/65无解，修前73差、修后可比均相符。两杀序既有知识未改，未新增强制首杀/出牌/药水/SL/费用权重规则。

端点反证：原两Crab+6和两TestSubject换相差来自多推进下一玩家回合末的反事实毒结算；首命令后原状态与恰当后继相符，不新改Crab或换相。YZWV T14首帧ready/snapshot_stable仍早于Fumes/Tools/Mercury结算，选牌后首出牌前114HP/毒15与模拟相符，旧117对114差保留为端点问题。其他四目标145既有窗，纠正后102可比/10无解/33未就绪，六字段局部相符；不认证状态牌堆、策略或全资源。逐局/招式/阶段/实际选择及原日志offset/len/SHA见机制阶段原件和证据manifest。

冻结输入：295个六目标T1原SHA/embedded state已核，294与首实际动作同原字节，另1完整state相同且帧在命令前；不能把T14推广成冻结T1都取错。输入一致不认证未来抽牌/策略/资源。研究7508685dee23仅承接765690dcf638并叠2源码delta，239编译模块/全部冻结数据不变；当前H1/生产周边不灌入研究模型。原107 train/481 validation、整局隔离、训练-only Platt、200样本/588原行seed及四闸保持，只重算1训练/32验证66行、复用1110行。原6错误行完全保留，未删unknown/改净损标签/增独立n/改闸。机制发现看过验证时期帧，固定前后比较不是新未见机制验证。

| Boss | 起点 | n | Brier 修前→修后 | 预测/实际 | 穿透比 修前→修后 | 未过闸 |
|---|---|---:|---|---|---|---|
| TEST_SUBJECT | t1 | 29 | 0.1352→0.1352 | 0.404/0.207 | 2.394→2.394 | brier,gap,leak |
| TEST_SUBJECT | pre | 29 | 0.1306→0.1306 | 0.364/0.207 | 2.322→2.322 | gap,leak |
| AEONGLASS | t1 | 35 | 0.1794→0.1794 | 0.654/0.514 | 4.125→4.125 | brier,leak |
| AEONGLASS | pre | 35 | 0.1855→0.1855 | 0.668/0.514 | 4.252→4.252 | brier,gap,leak |
| QUEEN | t1 | 31 | 0.2186→0.1644 | 0.584/0.419 | 1.065→1.319 | brier,gap,leak |
| QUEEN | pre | 31 | 0.2204→0.1874 | 0.568/0.419 | 1.176→1.46 | brier,leak |
| KAISER_CRAB | t1 | 46 | 0.1556→0.1556 | 0.69/0.63 | 1.321→1.321 | brier,leak |
| KAISER_CRAB | pre | 46 | 0.1791→0.1791 | 0.71/0.63 | 1.345→1.345 | brier,leak |
| KNOWLEDGE_DEMON | t1 | 45 | 0.0735→0.0735 | 0.832/0.844 | 1.378→1.378 | leak |
| KNOWLEDGE_DEMON | pre | 45 | 0.0651→0.0651 | 0.854/0.844 | 1.414→1.414 | leak |
| THE_INSATIABLE | t1 | 46 | 0.1367→0.1367 | 0.729/0.674 | 1.32→1.32 | brier,leak |
| THE_INSATIABLE | pre | 46 | 0.1456→0.1456 | 0.73/0.674 | 1.364→1.364 | brier,leak |

逐Boss/已观察进阶/原楼层（含33、48、49）/原t1、pre的原阈值结果和unknown分母见calibration-slices.json；阶段无独立胜败标签处明确unknown，不造phase2/3校准标签。Brier≤全体1.25倍、胜率差≤0.15、穿透比0.7–1.3、最小10场全部原样。当前生产boss-trust未替换；失败者保持低可信，F49联合/自然效果/0332及宽父不关闭，H2 on/H3+未开展。

源官方sandbox488文件4447项0（含tsc）；确切生产前驱源码别名撤修回归1（2与期望3不符），当前源码单测/官方回归0。初次CLI参数/路径错误、冻结周边不一致guard、零impact选择误用QUEEN而非QUEEN+TORCH_HEAD_AMALGAM等失败保留；修正均在验证模拟前，不改原日志/断言/时限/排除表。实际新组合sandbox=0，实际消费者回执 /home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-followup/live-consumer-receipt.json，kind=fixed-consumer，status=passed；10条当前相符对象。固定读回不冒自然采用/胜率改善。真实输入/输出/guard和源hash逐文件核回；receipt覆盖边界与publication错误如有另列。

学习账本silent-0509/0510和CLI提案silent-proposal-7c52170cd50d3976；既有a6cf9f726a971b59/7b0badc658e4fb1b边界关联保留，旧7b/bb/宽项不冒关闭。经验去重核旧3个Queen条目，无现成Burn Bright盟友+1条目；原毒/SL/两杀序知识保留，8个原/新拥有对象更新，另外2个既有对象仅消费者读回。

异议与替代建议见questions.json，交根ops双收件→现有watcher→Roy；只报告实际追加/技术回执，不代ops/watcher/Roy确认。下一阶段应在原cut/owner下继续核Queen盟友死后阶段、其余Boss状态牌堆与实际抽牌/策略/资源轨迹，按实际影响冻结必要新源/输入并复用成功缓存；不能从高leak或局部相符推一个倍率或根资源已修。

/**
 * How much a card is worth adding to *this* deck, 0–100. Code's side of deck building:
 *
 *   base    — community tier (nat1gaming / sts2companion Ironclad lists, v0.111 era; see
 *             notes/research-2026-09-24.md), revised with knowledge/characters/ironclad/ironclad-guide.md (S/A/F
 *             grades); unknown cards default to 45
 *   needs   — what the deck lacks right now: early damage in Act 1, AoE, draw, scaling, block
 *   bloat   — every card dilutes the deck; mediocre cards get worse as it grows
 *   copies  — diminishing returns for duplicates
 *
 * `SKIP_BAR` is the value a card must beat to be worth taking at all. Tuned from run logs.
 */

import type { DeckEntry } from "../../memory/deck.js";
import { BOSSES, bossHp } from "../../sim/boss-clock.js";
import { characterName, knowledgeCharacter } from "../../knowledge/files.js";

const TIER: Record<string, number> = {
  // S
  OFFERING: 92, BREAK: 90, FEED: 86,
  // A
  POMMEL_STRIKE: 68, SHRUG_IT_OFF: 76, BATTLE_TRANCE: 78, BLOODLETTING: 68, CORRUPTION: 78, DEMON_FORM: 80,
  IMPERVIOUS: 74, UNMOVABLE: 76, HELLRAISER: 66, THRASH: 80, TEAR_ASUNDER: 68, STOMP: 64, FIEND_FIRE: 68,
  CRIMSON_MANTLE: 72, DOMINATE: 66, BRAND: 66, STOKE: 64, COLOSSUS: 66,
  // B
  // Inflame 68 -> 74: permanent Strength in 50% of Act 1 wins, 27% of losses.
  // 2026-09-30 knowledge check (outcome-stats.json A8, 161 runs to 86C3; taken vs offered and not taken, the act's
  // boss pass; changed only where both sides have n >= 15, the gap is >= 1.5 standard errors, the mean final floor
  // agrees and no n >= 15 comparison points the other way): Anger 50 -> 58 (Act 1 0.88, n=16, vs 0.67, n=57; floor
  // 34.5 vs 26.4), Feel No Pain 54 -> 46 (Act 1 0.65, n=17, vs 0.87, n=15; floor 28.0 vs 31.0; its exhaust-payoff
  // +10 still applies with 3+ exhausting cards), Sword Boomerang 46 -> 54 below.
  // 2026-10-03 experience update (outcome-stats A8 232 runs to LTKW, same rule; cards changed in the last two checks
  // left alone): Pommel Strike 76 -> 68 (Act 1 0.74, n=117, vs 1.00, n=18; floor 31.2 vs 37.8), Stomp 72 -> 64 (Act 2
  // 0.30, n=27, vs 0.73, n=15; floor 34.2 vs 41.7; Act 1 equal), Hemokinesis 64 -> 72 (Act 1 0.88, n=32, vs 0.67, n=18;
  // floor 34.9 vs 28.4), Headbutt 62 -> 54 (Act 1 0.71, n=83, vs 0.85, n=47; Act 2 0.23, n=35, vs 0.48, n=27; A9 Act 1
  // 0.33, n=18, vs 0.76, n=17). Spite (Act 1 0.95, n=19, vs 0.71, n=28) met the rule too but stays 52: the in-combat
  // exhaust score reads this table and 60 would let Toasty Mittens exhaust Bludgeon before Spite (XWPV F48 T4 test).
  // Twin Strike 58 -> 64 (2026-09-29 knowledge check, outcome-stats.json A8, 151 runs): taken, the act's boss was
  // passed more often than when offered and not taken, in both acts with n >= 15 each way: Act 1 0.71 (n=55) vs
  // 0.62 (n=26), Act 2 0.35 (n=31) vs 0.19 (n=16); mean final floor +1.8 / +1.8. Multi-hit (Vantom's Slippery).
  INFLAME: 74, UPPERCUT: 68, HEMOKINESIS: 72, FLAME_BARRIER: 66, BLUDGEON: 60, TWIN_STRIKE: 64, HEADBUTT: 54,
  SETUP_STRIKE: 62, BURNING_PACT: 64, FEEL_NO_PAIN: 46, DRUM_OF_BATTLE: 30, CONFLAGRATION: 62, BULLY: 56,
  DISMANTLE: 64, EXPECT_A_FIGHT: 56, MANGLE: 35, PYRE: 80, STONE_ARMOR: 60, UNRELENTING: 58, BLOOD_WALL: 54,
  ANGER: 58, PERFECTED_STRIKE: 50, RAMPAGE: 35, SPITE: 52, FORGOTTEN_RITUAL: 54, HOWL_FROM_BEYOND: 60,
  PILLAGE: 54, ONE_TWO_PUNCH: 54, INFERNAL_BLADE: 52, EVIL_EYE: 54, TRUE_GRIT: 54, ARMAMENTS: 48, // its upgrade effect is unmodelled: the solver never plays it for value (WX16, BG4W)
  // Molten Fist 54 -> 44 (2026-09-29 knowledge check): taken, the act's boss was passed less often than when
  // offered and not taken, every time n >= 14 each way: A8 Act 1 0.60 (n=47) vs 0.74 (n=42), Act 2 0.13 (n=23)
  // vs 0.25 (n=24); A9 Act 1 0.41 (n=17) vs 0.64 (n=14). Below SKIP_BAR: taken only for a need (Act 1 damage).
  MOLTEN_FIST: 44, OUTRAGE: 52, RUPTURE: 50, INFERNO: 66, JUGGERNAUT: 56, WHIRLWIND: 66,
  // Fight Me! 25 (F tier) -> 74, Inflame's: 5x2 and 3 permanent Strength (the enemy gains 1). Our A8 runs
  // (outcome-stats.json 2026-09-29, 147 runs): taken in Act 1, boss pass 0.91 (n=11) vs 0.59 offered and
  // not taken (n=27), the second-largest gap of the cards with n>=5 both ways (baseline 0.69); Act 2
  // 0.22 (n=9) vs 0.17 (n=6); mean final floor +5.9 / +6.0. It carried the damage of RBJ4 (a win) and
  // 6189 (T9 kill of the Giant, Strength 9), both times from code's rank last.
  FIGHT_ME: 74,
  // C
  BREAKTHROUGH: 62, // AoE 9 for 1 energy, 1 HP; 54 -> 62 (1K5G F14 passed it for Taunt, no AoE at the boss)
  // Sword Boomerang 46 -> 54 (2026-09-30, same rule): A8 Act 1 0.80 (n=45) vs 0.63 (n=43), mean final floor 30.9 vs
  // 25.5; Act 2 (n=8 taken) and A9 (n=10 not taken) too few. Multi-hit for Vantom's Slippery (experience
  // card-sword-boomerang); whether it counts as the crab's AoE (the AOE set below) is left to Dai.
  IRON_WAVE: 30, BODY_SLAM: 38, THUNDERCLAP: 40, CINDER: 30, DARK_EMBRACE: 42, TREMBLE: 30, SWORD_BOOMERANG: 54,
  // Taunt 62 -> 50 (2026-09-29 knowledge check; experience card-taunt): A8 outcome-stats, taken vs offered and not
  // taken: Act 1 boss pass 0.65 (n=51) vs 0.77 (n=35), mean final floor 26.0 vs 30.0; Act 2 0.22 (n=27) vs 0.32
  // (n=19). A9 (n=13/8, 9/5) too few to say. At SKIP_BAR: taken for thin block, not over damage/scaling.
  TAUNT: 50, SECOND_WIND: 44, RAGE: 42, VICIOUS: 42, CRUELTY: 44, AGGRESSION: 46, STAMPEDE: 44, JUGGLING: 25,
  PACTS_END: 40, BARRICADE: 44, ASHEN_STRIKE: 44, PRIMAL_FORCE: 36, CASCADE: 40, NOT_YET: 44, MIDNIGHT: 36,
  THE_BOMB: 48, // colorless: 40 to every enemy after 3 turns, good in long boss fights (1ZQJ never played it)
  // F
  HAVOC: 20, THE_GAMBIT: 0, BLAZE: 10, DEMONIC_SHIELD: 10, TANK: 5,
};

export const SKIP_BAR = 50;

const AOE = new Set(["INFERNO", "THUNDERCLAP", "BREAKTHROUGH", "STOMP", "CONFLAGRATION", "WHIRLWIND", "HOWL_FROM_BEYOND", "FIEND_FIRE", "SWORD_BOOMERANG"]);
const DRAW = new Set(["POMMEL_STRIKE", "SHRUG_IT_OFF", "BATTLE_TRANCE", "BURNING_PACT", "OFFERING", "DRUM_OF_BATTLE", "PILLAGE"]);
/** Lasting Strength/scaling. Not Setup Strike: its Strength is gone at the end of the turn. */
const SCALING = new Set(["DEMON_FORM", "INFLAME", "FIGHT_ME", "CORRUPTION", "FEEL_NO_PAIN", "CRIMSON_MANTLE", "PYRE", "RUPTURE", "BRAND", "DOMINATE", "FEED", "JUGGERNAUT", "HELLRAISER", "UNMOVABLE", "BARRICADE"]);
/** Single cards of 14+ damage (Aeonglass: few, big cards). */
const BIG_HITS = new Set(["BLUDGEON", "CARNAGE", "HEMOKINESIS", "TEAR_ASUNDER", "FIEND_FIRE", "WHIRLWIND", "CONFLAGRATION", "HOWL_FROM_BEYOND", "FEED", "MANGLE", "UPPERCUT", "RAMPAGE"]);
const FRONTLOAD = new Set(["BREAK", "BLUDGEON", "HEMOKINESIS", "UPPERCUT", "CARNAGE", "TWIN_STRIKE", "POMMEL_STRIKE", "THRASH", "HEADBUTT", "DISMANTLE", "MANGLE", "UNRELENTING", "STOMP", "CONFLAGRATION", "HOWL_FROM_BEYOND", "FEED", "SETUP_STRIKE", "TEAR_ASUNDER", "WHIRLWIND", "RAMPAGE", "MOLTEN_FIST", "CINDER", "FIEND_FIRE"]);
/**
 * Cards that exhaust something (another card, or themselves): what Dark Embrace and Feel No Pain
 * feed on. Z2H3 F12: Dark Embrace (62) over True Grit in a 19-card deck with one exhausting card; it
 * sat in hand four times in the boss fight and was never played. Payoffs (Pact's End, Ashen Strike,
 * Evil Eye) exhaust nothing and do not count.
 */
const EXHAUST = new Set([
  "TRUE_GRIT", "BURNING_PACT", "SECOND_WIND", "FIEND_FIRE", "CORRUPTION", "BRAND", "CINDER", "STOKE", "THRASH", "HAVOC",
  "FEED", "IMPERVIOUS", "DOMINATE", "OFFERING", "MOLTEN_FIST", "INFERNAL_BLADE", "TREMBLE", "NOT_YET", "FORGOTTEN_RITUAL",
]);
/** Exhaust payoffs and their bonus once the deck has at least 3 exhausting cards. */
const EXHAUST_PAYOFF: Record<string, number> = { DARK_EMBRACE: 20, FEEL_NO_PAIN: 10 };

// EXTERMINATE: 4 hits (6HRZ F33 T6).
const MULTI_HIT = new Set(["TWIN_STRIKE", "SWORD_BOOMERANG", "CONFLAGRATION", "WHIRLWIND", "THRASH", "FIGHT_ME", "DISMANTLE", "TEAR_ASUNDER", "ANGER", "PUMMEL", "EXTERMINATE"]);

/** Lasting Strength cards: damageRole's "scaling" (the boss clock's gap bonus). */
const STRENGTH = new Set(["DEMON_FORM", "INFLAME", "RUPTURE", "DOMINATE", "FEED", "PYRE", "HELLRAISER", "JUGGERNAUT", "FIGHT_ME"]);

/**
 * Whether the run's character has card values (2026-10-04, multi-character): every table in this module is the
 * Ironclad's, hand-written from its card lists and our Ironclad runs. Another character gets none of it (Dai: no
 * hand-written play for a new character, it learns its own): no tier, no roles, no boss bonuses. Its card values are
 * neutral instead (cardValue: SKIP_BAR for every card, so no offer falls under the skip bar and none is preferred), and
 * the choice goes to the brain (BUILD_DECIDER) or Jev, as any pick without a clear code answer.
 */
export function hasCardValues(character: string = knowledgeCharacter()): boolean {
  return character === "ironclad";
}

const NO_CARDS: ReadonlySet<string> = new Set();
/** The role sets for the run's character (empty without card values). */
function roles(): { aoe: ReadonlySet<string>; draw: ReadonlySet<string>; scaling: ReadonlySet<string>; frontload: ReadonlySet<string>; block: ReadonlySet<string>; exhaust: ReadonlySet<string>; bigHits: ReadonlySet<string>; strength: ReadonlySet<string> } {
  return hasCardValues()
    ? { aoe: AOE, draw: DRAW, scaling: SCALING, frontload: FRONTLOAD, block: BLOCK, exhaust: EXHAUST, bigHits: BIG_HITS, strength: STRENGTH }
    : { aoe: NO_CARDS, draw: NO_CARDS, scaling: NO_CARDS, frontload: NO_CARDS, block: NO_CARDS, exhaust: NO_CARDS, bigHits: NO_CARDS, strength: NO_CARDS };
}

/**
 * What each Act boss punishes (from logged boss fights): Vantom has 9 Slippery stacks and 183 HP (A8), so
 * multi-hit and scaling; The Kin is a priest plus followers, so AoE; Ceremonial Beast has 262 HP (A8);
 * Waterfall Giant explodes for its Steam Eruption stacks (15, +3 a turn), so block and a fast kill;
 * Knowledge Demon has 399 HP (A8) and heals, so Strength/scaling. `bossId` is the current act's boss.
 * Boss HP in the texts is the boss's own HP at the current ascension (bossHp: the monster DB, the
 * priest alone for the Kin, the Test Subject's phases summed; no mechanic's added HP), never a fixed
 * ascension's (RWWG: the crab said 408, it is 428 at A8; the Kin/Aeonglass/Test Subject/Matriarch texts
 * said their A0 190/512/600/222).
 */
function bossHpAtAsc(id: string, ascension: number): number {
  return BOSSES[id] ? bossHp({ ...BOSSES[id]!, id, addedHp: 0 }, ascension) : 0;
}

function bossBonus(cardId: string, bossId: string, ascension: number): { bonus: number; why: string | null } {
  const boss = bossId.toUpperCase();
  const hp = (id: string) => bossHpAtAsc(id, ascension);
  if (boss.includes("VANTOM")) {
    if (MULTI_HIT.has(cardId)) return { bonus: 10, why: "multi-hit strips Vantom's Slippery" };
    if (SCALING.has(cardId)) return { bonus: 8, why: `scaling for Vantom's ${hp("VANTOM")} HP` };
  }
  if (boss.includes("KIN")) {
    if (AOE.has(cardId)) return { bonus: 10, why: "AoE for the Kin followers" };
    // The priest phase decides it (P78Z, PPKT: priest left at 38 and 26 of 190, ~18 a turn alone).
    if (SCALING.has(cardId)) return { bonus: 8, why: `scaling for the Kin Priest's ${hp("THE_KIN")} HP` };
    if (FRONTLOAD.has(cardId)) return { bonus: 4, why: "damage for the Kin Priest" };
  }
  if (boss.includes("WATERFALL_GIANT")) {
    if (BLOCK.has(cardId)) return { bonus: 6, why: "block for the Waterfall Giant's explosion" };
    if (FRONTLOAD.has(cardId)) return { bonus: 6, why: "a fast kill before the Giant's eruption stacks" };
  }
  // Both act-2 bosses are damage races entered at full HP and lost short of damage (24HM: 24.9 a turn
  // of 33.5 needed into the demon; WLY1: 21.6 a turn into the crab's HP, Thunderclap skipped at 33).
  if (boss.includes("KNOWLEDGE_DEMON")) {
    if (SCALING.has(cardId)) return { bonus: 10, why: `Strength/scaling for the Knowledge Demon's ${hp("KNOWLEDGE_DEMON")} HP` };
    if (FRONTLOAD.has(cardId)) return { bonus: 4, why: "damage for the Knowledge Demon's heals" };
  }
  // Kaiser Crab: two claws (Rocket, Crusher) with 428 HP between them at A8: AoE hits both.
  if (boss.includes("KAISER_CRAB")) {
    if (AOE.has(cardId)) return { bonus: 12, why: "AoE hits both of the Kaiser Crab's claws" };
    if (SCALING.has(cardId)) return { bonus: 8, why: `scaling for the Kaiser Crab's ${hp("KAISER_CRAB")} HP` };
    if (FRONTLOAD.has(cardId)) return { bonus: 4, why: `damage for the Kaiser Crab's ${hp("KAISER_CRAB")} HP` };
  }
  if (boss.includes("CEREMONIAL") || boss.includes("BEAST")) {
    if (SCALING.has(cardId) || FRONTLOAD.has(cardId)) return { bonus: 6, why: `damage for the Beast's ${hp("CEREMONIAL_BEAST")} HP` };
  }
  // Soul Fysh shuffles Beckons into the deck (XPA4: 8 in the deck at death): exhaust clears them, damage
  // ends it before they pile up, and Battle Trance draws them (twice in that fight).
  if (boss.includes("SOUL_FYSH")) {
    const BECKON_CLEARERS = new Set(["BURNING_PACT", "PURITY", "FIEND_FIRE", "SECOND_WIND", "BRAND", "STOKE"]);
    if (cardId === "BATTLE_TRANCE") return { bonus: -10, why: "draws Soul Fysh's Beckons" };
    // Only cards that exhaust OTHER chosen cards clear Beckons (K8RK: +8 went to Not Yet, Forgotten
    // Ritual and plain True Grit, which exhaust themselves or at random; Purity went unbought).
    if (BECKON_CLEARERS.has(cardId)) return { bonus: 8, why: "exhausts chosen cards: clears Soul Fysh's Beckons" };
    if (FRONTLOAD.has(cardId)) return { bonus: 6, why: "damage before the Beckons pile up" };
  }
  // The Matriarch sleeps two turns (time to play powers), then it is a 222 HP damage race (1K5G, Z2H3).
  // The Queen: from her third turn on the Amalgam hits 12x3 / 22 under permanent Vulnerable, Weak and
  // Frail; block and early scaling decide it (WY41 F48: 3 block cards, dead on T4; 88HN).
  // Aeonglass: 512 HP with two 33-block turns by T9 and Withers every 6 cards: about 70 damage a turn,
  // few big cards, and a way to exhaust Withers (YVWA/TQX5/Y0KJ: left at 312, 33, 32 of 512).
  if (boss.includes("AEONGLASS")) {
    if (SCALING.has(cardId)) return { bonus: 8, why: `scaling for Aeonglass's ${hp("AEONGLASS")} HP` };
    // Cards that exhaust a CHOSEN card only, as for Soul Fysh's Beckons: plain True Grit exhausts at random and
    // cannot pick the Wither (experience card-true-grit, aeon-wither: True Grit+); no bonus for it here.
    if (cardId === "BURNING_PACT" || cardId === "FIEND_FIRE") return { bonus: 8, why: "exhausts Aeonglass's Withers" };
    // Only real big hits: Setup Strike and a third Pommel Strike got it too and the deck swelled to 31 (L34T).
    if (BIG_HITS.has(cardId)) return { bonus: 4, why: "big hits: few cards against Withering Presence" };
  }
  if (boss.includes("QUEEN")) {
    if (BLOCK.has(cardId)) return { bonus: 8, why: "block for the Queen's Amalgam hits under Frail" };
    if (SCALING.has(cardId)) return { bonus: 6, why: "early scaling for the Queen's first two turns" };
  }
  // Test Subject: 600 HP over three phases; the two wins had 28 and 40 Strength, the losses 16 or none
  // (7DFB, ZANM, 2WUM). Multi Claw grows every turn in phase 2: block too.
  if (boss.includes("TEST_SUBJECT")) {
    if (SCALING.has(cardId)) return { bonus: 10, why: `Strength scaling for Test Subject's ${hp("TEST_SUBJECT")} HP` };
    if (BLOCK.has(cardId)) return { bonus: 4, why: "block for Test Subject's Multi Claw" };
  }
  if (boss.includes("LAGAVULIN_MATRIARCH")) {
    if (SCALING.has(cardId)) return { bonus: 10, why: "scaling for the Matriarch's sleeping turns" };
    if (FRONTLOAD.has(cardId)) return { bonus: 6, why: `damage for the Matriarch's ${hp("LAGAVULIN_MATRIARCH")} HP` };
  }
  return { bonus: 0, why: null };
}

/** One of the 14+ damage single cards. */
export function isBigHit(cardId: string): boolean {
  return roles().bigHits.has(cardId);
}

/** Which kind of damage card this is (for the boss clock's gap bonus), or null. */
export function damageRole(cardId: string): "scaling" | "aoe" | "frontload" | null {
  const role = roles();
  if (role.strength.has(cardId)) return "scaling";
  if (role.aoe.has(cardId)) return "aoe";
  if (role.frontload.has(cardId)) return "frontload";
  return null;
}

/** Whether a card is one of the deck's block cards (Defends count too). */
export function isBlockCardId(cardId: string): boolean {
  return roles().block.has(cardId) || cardId.startsWith("DEFEND_");
}

const BLOCK = new Set(["SHRUG_IT_OFF", "FLAME_BARRIER", "IMPERVIOUS", "COLOSSUS", "BLOOD_WALL", "TRUE_GRIT", "EVIL_EYE", "EXPECT_A_FIGHT", "STONE_ARMOR", "CRIMSON_MANTLE", "FEEL_NO_PAIN", "TAUNT", "IRON_WAVE"]);

export interface CardValue {
  value: number;
  reasons: string[];
}

export interface DeckProfile {
  size: number;
  aoe: number;
  draw: number;
  scaling: number;
  frontload: number;
  block: number;
  /** Cards that exhaust something (EXHAUST). */
  exhaust: number;
  basics: number;
  copies: Map<string, number>;
}

export function deckProfile(deck: DeckEntry[]): DeckProfile {
  const copies = new Map<string, number>();
  let aoe = 0;
  let draw = 0;
  let scaling = 0;
  let frontload = 0;
  let block = 0;
  let exhaust = 0;
  let basics = 0;
  const role = roles();
  for (const card of deck) {
    copies.set(card.card_id, (copies.get(card.card_id) ?? 0) + 1);
    if (role.aoe.has(card.card_id)) aoe += 1;
    if (role.draw.has(card.card_id)) draw += 1;
    if (role.scaling.has(card.card_id) && card.card_id !== "SETUP_STRIKE") scaling += 1;
    if (role.frontload.has(card.card_id)) frontload += 1;
    if (role.block.has(card.card_id)) block += 1;
    if (role.exhaust.has(card.card_id)) exhaust += 1;
    if (card.rarity === "Basic") basics += 1;
  }
  return { size: deck.length, aoe, draw, scaling, frontload, block, exhaust, basics, copies };
}

export function cardValue(
  cardId: string,
  rarity: string,
  type: string,
  deck: DeckProfile,
  act: number,
  floor: number,
  bossId = "",
  relics: readonly string[] = [],
  /** The run's ascension: the boss HP the reasons name (8 when not given). */
  ascension = 8,
): CardValue {
  // No card values for the run's character (hasCardValues): neutral, the skip bar itself for every playable card.
  if (!hasCardValues()) {
    return type === "Curse" || type === "Status" ? { value: 0, reasons: [type] } : { value: SKIP_BAR, reasons: [`no card values for ${characterName(knowledgeCharacter(), "en")} yet`] };
  }
  const reasons: string[] = [];
  let value = TIER[cardId] ?? (type === "Curse" || type === "Status" ? 0 : rarity === "Rare" ? 55 : 45);
  if (!(cardId in TIER)) reasons.push("no tier data");

  // Early Act 1: the deck has to kill hallway fights and the first elite fast.
  if (act <= 1 && FRONTLOAD.has(cardId) && deck.frontload < 3) {
    value += 12;
    reasons.push("Act 1 needs damage");
  }
  // AoE: 81% of Act 1 wins had at least one by the boss, 47% of losses.
  if (AOE.has(cardId) && deck.aoe === 0) {
    value += 14;
    reasons.push("no AoE yet");
  }
  if (DRAW.has(cardId) && deck.draw < 2) {
    value += 5;
    reasons.push("little draw");
  }
  // From floor 4, not 8: Demon Form was in 6 Act 1 wins and 0 losses.
  if (SCALING.has(cardId) && deck.scaling === 0 && (act >= 2 || floor >= 4)) {
    value += 10;
    reasons.push("no scaling for bosses");
  }
  if (BLOCK.has(cardId) && deck.block < 2 && floor >= 5) {
    value += 5;
    reasons.push("thin on block");
  }
  const payoff = EXHAUST_PAYOFF[cardId];
  if (payoff !== undefined && (deck.exhaust >= 3 || relics.includes("TOASTY_MITTENS"))) {
    value += payoff;
    reasons.push(deck.exhaust >= 3 ? `${deck.exhaust} exhausting cards to feed it` : "Baking Gloves exhaust every turn");
  }
  // Relic synergies found on live runs: Baking Gloves (TOASTY_MITTENS) exhaust a card every turn, so
  // Howl from Beyond fires free each time it is drawn and exhausted, and Evil Eye always gets its bonus block.
  if (relics.includes("TOASTY_MITTENS") && (cardId === "HOWL_FROM_BEYOND" || cardId === "EVIL_EYE")) {
    value += 25;
    reasons.push("Baking Gloves synergy");
  }
  // Fiddle: no mid-turn draw, so cards valued for their draw lose that value.
  if (relics.includes("FIDDLE") && DRAW.has(cardId)) {
    value -= 15;
    reasons.push("Fiddle: no mid-turn draw");
  }
  const boss = bossBonus(cardId, bossId, ascension);
  if (boss.bonus !== 0) {
    value += boss.bonus;
    reasons.push(boss.why ?? "boss");
  }
  const copies = deck.copies.get(cardId) ?? 0;
  if (copies > 0) {
    // Strength powers stack, so a second copy is still good; other powers mostly do not.
    const stacks = cardId === "INFLAME" || cardId === "DEMON_FORM";
    const penalty = type === "Power" && !stacks ? 18 * copies : 6 * copies;
    value -= penalty;
    reasons.push(`already have ${copies}`);
  }
  // Bloat: past 22 cards a middling card makes the good ones rarer. (The guide targets 20–28 cards;
  // starting at 18 pushed every Act 2 offer under SKIP_BAR and 0NG took no card in Act 2.)
  if (deck.size > 22 && value < 70) {
    value -= Math.min(15, (deck.size - 22) * 1.5);
    reasons.push(`deck is ${deck.size} cards`);
  }
  return { value: Math.round(value), reasons };
}

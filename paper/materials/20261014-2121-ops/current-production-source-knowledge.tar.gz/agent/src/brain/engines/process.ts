/**
 * Running a CLI agent (claude, codex) for one brain call: a clean environment, an empty working directory,
 * the prompt on stdin, stdout/stderr collected, its process group killed (negative PID) when the call is aborted.
 */
import { spawn } from "node:child_process";
import { mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

/**
 * Variables a CLI agent may inherit: the basics a process needs (PATH, HOME for its login, locale, proxies,
 * CA bundles). Everything else is dropped: our keys (DEEPSEEK_*, TYPESAFE_*, JEV_*, BRAIN_*), any
 * *_API_KEY / *_TOKEN, and the variables of a Claude Code session this process may run under.
 */
const INHERITED = new Set([
  "PATH", "HOME", "USER", "LOGNAME", "SHELL", "LANG", "LANGUAGE", "TZ", "TMPDIR", "TERM",
  "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME", "XDG_RUNTIME_DIR",
  "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "no_proxy", "all_proxy",
  "NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE", "SSL_CERT_DIR",
  // Where the agents keep their own login and settings, when moved from the default.
  "CLAUDE_CONFIG_DIR", "CODEX_HOME",
]);

/** The child's environment: the inherited basics (LC_* too) plus `extra`. */
export function agentEnv(extra: Record<string, string> = {}, from: NodeJS.ProcessEnv = process.env): Record<string, string> {
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(from)) {
    if (value === undefined) continue;
    if (INHERITED.has(key) || key.startsWith("LC_")) env[key] = value;
  }
  return { ...env, ...extra };
}

export interface AgentRun {
  code: number | null;
  signal: NodeJS.Signals | null;
  stdout: string;
  stderr: string;
  ms: number;
}

/** The run was aborted (the caller's signal: a timeout, a stall): what the agent had written by then, for the evidence. */
export class AgentAbortedError extends Error {
  constructor(
    readonly bin: string,
    readonly ms: number,
    readonly stdout: string,
    readonly stderr: string,
  ) {
    super(`${bin} aborted after ${ms} ms`);
    this.name = "AgentAbortedError";
  }
}

/** The program could not be started at all (ENOENT: not found, EACCES: not executable, ...). */
export class AgentStartError extends Error {
  constructor(
    readonly bin: string,
    readonly code: string,
    detail: string,
  ) {
    super(`${bin} could not start: ${detail}`);
    this.name = "AgentStartError";
  }
}

/** A fresh empty directory for one call (removed by the caller with removeDir). */
export function makeWorkDir(prefix: string): string {
  return mkdtempSync(join(tmpdir(), prefix));
}

/** The stable per-process working directory in use (one call at a time uses it; others get a random one). */
const stableInUse = new Set<string>();

/**
 * An empty working directory for one call at a stable path per process and prefix (created empty, removed by
 * release). Claude Code writes its working directory into the model's context, so a random path per call
 * changes the prompt and defeats the prompt cache; a stable one keeps the prefix identical between calls. A call
 * that overlaps another gets a random directory.
 */
export function stableWorkDir(prefix: string): { dir: string; release(): void } {
  const dir = join(tmpdir(), `${prefix}${process.pid}`);
  if (stableInUse.has(dir)) {
    const random = makeWorkDir(prefix);
    return { dir: random, release: () => removeDir(random) };
  }
  stableInUse.add(dir);
  removeDir(dir);
  mkdirSync(dir, { recursive: true });
  return {
    dir,
    release: () => {
      removeDir(dir);
      stableInUse.delete(dir);
    },
  };
}

export function removeDir(dir: string): void {
  try {
    rmSync(dir, { recursive: true, force: true });
  } catch {
    // a temp dir left behind is harmless
  }
}

/** After SIGTERM to an aborted agent's process group, how long before SIGKILL. */
export const KILL_GRACE_MS = 3_000;
/**
 * After the agent itself exits, how long its output pipes may stay open before the call ends anyway: a process it
 * started (an MCP server, a tool) that inherited them would otherwise hold the call, and its working directory,
 * open until that process ends. The leftovers of its process group are killed then.
 */
export const EXIT_CLOSE_GRACE_MS = 2_000;

/**
 * Runs the agent to completion in its own process group (detached): an abort kills the whole group (SIGTERM, then
 * SIGKILL after KILL_GRACE_MS, by negative PID) and rejects, so the processes the agent started die with it. The
 * promise always settles: on 'close', or EXIT_CLOSE_GRACE_MS after 'exit' when something still holds the pipes.
 */
export function runAgent(
  bin: string,
  args: string[],
  opts: { cwd: string; env: Record<string, string>; stdin: string; signal?: AbortSignal; onStdoutLine?: (line: string) => void; onStderrLine?: (line: string) => void },
): Promise<AgentRun> {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    if (opts.signal?.aborted) {
      reject(new Error(`${bin} aborted before start`));
      return;
    }
    const child = spawn(bin, args, { cwd: opts.cwd, env: opts.env, stdio: ["pipe", "pipe", "pipe"], detached: true });
    let stdout = "";
    let stderr = "";
    /** stdout / stderr after their last newline (the line callbacks get whole lines). */
    let pending = "";
    let pendingErr = "";
    const lines = (buffer: string, text: string, each: ((line: string) => void) | undefined): string => {
      if (!each) return "";
      let rest = buffer + text;
      let newline: number;
      while ((newline = rest.indexOf("\n")) >= 0) {
        const line = rest.slice(0, newline);
        rest = rest.slice(newline + 1);
        try {
          each(line);
        } catch {
          // a watcher's error must not break the run
        }
      }
      return rest;
    };
    let killTimer: NodeJS.Timeout | undefined;
    let exitTimer: NodeJS.Timeout | undefined;
    let aborted = false;
    let settled = false;
    /** The agent's process group (its PID, negated), else the agent alone; gone already is fine. */
    const killGroup = (signal: NodeJS.Signals): void => {
      if (child.pid === undefined) return;
      try {
        process.kill(-child.pid, signal);
      } catch {
        try {
          child.kill(signal);
        } catch {
          // already gone
        }
      }
    };
    const onAbort = (): void => {
      aborted = true;
      killGroup("SIGTERM");
      killTimer = setTimeout(() => killGroup("SIGKILL"), KILL_GRACE_MS);
    };
    const settle = (): boolean => {
      if (settled) return false;
      settled = true;
      opts.signal?.removeEventListener("abort", onAbort);
      clearTimeout(killTimer);
      clearTimeout(exitTimer);
      return true;
    };
    const finish = (code: number | null, signal: NodeJS.Signals | null): void => {
      if (!settle()) return;
      if (aborted) reject(new AgentAbortedError(bin, Date.now() - started, stdout, stderr));
      else resolve({ code, signal, stdout, stderr, ms: Date.now() - started });
    };
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    child.stdout.on("data", (chunk: Buffer) => {
      const text = chunk.toString("utf8");
      stdout += text;
      pending = lines(pending, text, opts.onStdoutLine);
    });
    child.stderr.on("data", (chunk: Buffer) => {
      const text = chunk.toString("utf8");
      stderr += text;
      pendingErr = lines(pendingErr, text, opts.onStderrLine);
    });
    child.on("error", (error) => {
      if (!settle()) return;
      reject(new AgentStartError(bin, String((error as NodeJS.ErrnoException).code ?? "error"), error.message));
    });
    child.on("exit", (code, signal) => {
      // 'close' normally follows at once; if a leftover process holds the pipes, end the call without it.
      exitTimer = setTimeout(() => {
        killGroup("SIGKILL");
        child.stdout.destroy();
        child.stderr.destroy();
        finish(code, signal);
      }, EXIT_CLOSE_GRACE_MS);
    });
    child.on("close", (code, signal) => finish(code, signal));
    child.stdin.on("error", () => {
      // the agent exited before reading its prompt: reported through close
    });
    child.stdin.end(opts.stdin);
  });
}

/**
 * Run plan (RUN_PLAN=v1, migration step M3): DeepSeek sets the run's strategy at a few checkpoints —
 * the start of the run, the start of each act, after a heavy HP loss, and at most every
 * RUN_PLAN_REVIEW_FLOORS floors — and code turns it into weights on the build and route decisions.
 * It is strategy only: which cards to look for, avoid or remove, how many block cards the deck needs,
 * how hungry for elites to be, heal or smith at rest sites, what to prepare for the act boss. Card
 * play stays with the turn solver and Jev (Roy: "只是打法建议，出牌还是交给 jev 判断").
 *
 * Why: most losses since the fight plan came in were cross-fight decisions no single fight plan
 * sees (entering elites or bosses with empty potion slots, a 3-block-card deck at the Queen, the
 * card a boss needs never bought, rest sites all spent healing).
 *
 * Who asks for it (RUN_PLAN_MERGE, default on; strategy/run-plan-merge.ts, notes/run-plan-merge.md): the checkpoints stay
 * runPlanTrigger's, but a due plan rides on the next DeepSeek question (the act-start Ancient, a card reward, a rest site,
 * a shop...) instead of its own call at the map; its own call only when no question carried it within two floors or the
 * act boss is next. RUN_PLAN_MERGE=off: the call at the map, as before.
 */

import { appendFileSync, closeSync, existsSync, mkdirSync, openSync, readSync, statSync } from "node:fs";
import { dirname } from "node:path";

import type { Knowledge } from "../knowledge/index.js";
import type { GameState } from "../hand/mod/schema.js";
import { deckEntries } from "./deck.js";
import { deckProfileLine } from "./deck-profile.js";
import { bossClockJson } from "../sim/boss-clock.js";
import { bossIdForFacts, observedBossPhase } from "../knowledge/boss-phase.js";
import { asArray, asRecord, str, type JsonValue } from "../core/util/json.js";
import { loadConstructionData } from "../construction/data.js";
import { CONSTRUCTION_EVALUATION_NOTE, constructionEvaluationEnabled } from "../construction/consumer.js";

export type RunPlanTrigger = "start" | "act" | "hp_drop" | "review";
export type EliteAppetite = "seek" | "normal" | "avoid";
export type RestPolicy = "heal" | "smith" | "auto";

export interface RunPlan {
  runId: string;
  /** Act (1-based) and floor the plan was made on. */
  act: number;
  floor: number;
  /** HP fraction when the plan was made (the hp_drop trigger compares against it). */
  hpPct: number;
  trigger: RunPlanTrigger;
  archetype: string;
  /** card_id: pick these when offered (card rewards, shops). */
  want: string[];
  /** card_id: do not take these. */
  avoid: string[];
  /** card_id: remove these first (shop removal, events). */
  remove: string[];
  /** Block cards the deck should hold by the act boss. */
  blockTarget: number | null;
  elites: EliteAppetite;
  rest: RestPolicy;
  bossPrep: string;
  summary: string;
  construction?: { primary: string; alternatives: string[]; checkpoint: number; reason: string; pivot_if: string };
}

/** A plan older than this many floors is reviewed at the next map. */
export const RUN_PLAN_REVIEW_FLOORS = 8;
/** HP lost since the plan (fraction of max HP) that asks for a new one. */
export const RUN_PLAN_HP_DROP = 0.3;
/** Below this HP fraction a plan made above it is renewed. */
export const RUN_PLAN_LOW_HP = 0.4;

/** Card-value bonus for planned cards, malus for avoided ones. */
// 12 was too weak: 4UWK F15 Body Slam, the plan's first want, lost 86 to 73 to Thrash.
export const RUN_PLAN_WANT_BONUS = 20;
export const RUN_PLAN_AVOID_MALUS = 15;

export function actOf(state: GameState): number {
  const raw = str(asRecord(state.run?.raw)["act_id"]);
  return /^\d+$/.test(raw) ? Number(raw) + 1 : 1;
}

export function hpFraction(state: GameState): number {
  const hp = state.run?.current_hp ?? null;
  const maxHp = state.run?.max_hp ?? null;
  return hp !== null && maxHp !== null && maxHp > 0 ? hp / maxHp : 1;
}

/** Why a new plan is due at this map screen, or null. */
export function runPlanTrigger(plan: RunPlan | null | undefined, state: GameState): RunPlanTrigger | null {
  const runId = str(state.raw["run_id"]);
  if (!plan || plan.runId !== runId) return "start";
  const act = actOf(state);
  if (act !== plan.act) return "act";
  const hp = hpFraction(state);
  if (plan.hpPct - hp >= RUN_PLAN_HP_DROP || (hp < RUN_PLAN_LOW_HP && plan.hpPct >= RUN_PLAN_LOW_HP)) return "hp_drop";
  if (constructionEvaluationEnabled(str(asRecord(state.run?.raw)["character_id"]).toLowerCase()) && plan.construction
    && (state.run?.floor ?? 0) > plan.floor && (state.run?.floor ?? 0) >= plan.construction.checkpoint) return "review";
  if ((state.run?.floor ?? 0) - plan.floor >= RUN_PLAN_REVIEW_FLOORS) return "review";
  return null;
}

/** What the run plan is for and how to make it: the separate call's task and the merged question's note share it. */
export const RUN_PLAN_BRIEF = [
  "You set the STRATEGY for the rest of this act and run; code and a small model will apply it to card rewards, shops,",
  "removals, map routes and rest sites, and will play every card themselves. Look at the deck, relics, HP, gold, potions,",
  "the act boss and the map ahead (memory.lookahead). Name what this deck needs to beat the act boss and survive the act.",
  "act_boss_clock gives the boss's HP at this ascension (heals and wasted hits included), the turns you survive at its",
  "logged damage and so the turns the fight can last, the damage a turn that needs, and code's estimate of this deck's",
  "damage a turn in that fight (calibrated on logged A8 boss fights; Strength growth and the boss mechanic in harder_because",
  "counted). If gap_per_turn > 0, closing it comes first: want Strength/scaling and high-damage cards (AoE for two-part",
  "bosses), remove Strikes/Defends that dilute them, smith attacks; state the gap in the summary. A gap of 0 is not a reason",
  "to stop adding damage: the estimate's typical error is ~25%.",
].join(" ");

/** The run plan's JSON object. */
export const RUN_PLAN_FORMAT = [
  '{"archetype": "<the deck direction, max 12 words>",',
  '"want": [card ids to pick when offered, most important first, max 6],',
  '"avoid": [card ids not to take, max 6], "remove": [card ids in the deck to remove first, max 3],',
  '"block_target": <number of block cards the deck should hold by the act boss>,',
  '"elites": "seek" | "normal" | "avoid", "rest": "heal" | "smith" | "auto",',
  '"boss_prep": "<max 30 words: what to have ready for the act boss>",',
  '"summary": "<max 40 words: the plan in plain words>"}',
].join(" ");

/** The separate run-plan call's task (byte for byte what it was before RUN_PLAN_MERGE; tests/run-plan-merge.test.ts). */
export const RUN_PLAN_TASK = [
  "TASK: run plan (not an option choice; ignore the {choice, reason} reply format for this one).",
  RUN_PLAN_BRIEF,
  `Reply with JSON only: ${RUN_PLAN_FORMAT}`,
].join(" ");

/**
 * The state key of a run plan riding on a DeepSeek question (RUN_PLAN_MERGE, strategy/run-plan-merge.ts): the brain's
 * specs add the answer's `run_plan` field and the DeepSeek client its effort when a question's state carries it.
 */
export const RUN_PLAN_TASK_KEY = "run_plan_task";

/** Keep standalone and merged plan questions on the same role-scoped contract. */
export function constructionPlanContext(state: GameState): Record<string, JsonValue> | null {
  const character = str(asRecord(state.run?.raw)["character_id"]).toLowerCase();
  const templates = constructionEvaluationEnabled(character) ? loadConstructionData(character)?.templates.filter((c) => c.ascensions.includes(state.run?.ascension ?? 0)) : undefined;
  return templates?.length ? { character, floor: state.run?.floor ?? 0,
    coreCatalog: templates.map((c) => ({ id: c.id, name: c.name, candidate: c.status !== "validated" })),
    instruction: CONSTRUCTION_EVALUATION_NOTE, future_probability_status: "not supplied by this plan context" } : null;
}

/** What DeepSeek is shown: the deck grouped, relics, potions, HP/gold, act boss and the trigger. */
export function runPlanInput(state: GameState, knowledge: Knowledge, trigger: RunPlanTrigger, deckLines: string[], relics: string[], potions: string[]): Record<string, JsonValue> {
  const raw = asRecord(state.run?.raw);
  const phase = observedBossPhase(state);
  const construction = constructionPlanContext(state);
  return {
    ...(construction ? { construction_context: construction } : {}),
    trigger,
    act: actOf(state),
    floor: state.run?.floor ?? null,
    ascension: state.run?.ascension ?? 0,
    hp: `${state.run?.current_hp ?? "?"}/${state.run?.max_hp ?? "?"}`,
    gold: state.run?.gold ?? null,
    act_boss: phase ? bossIdForFacts(state) : str(raw["boss_id"]),
    ...(phase ? { boss_phase: phase } : {}),
    act_boss_clock: bossClockJson(state, knowledge),
    deck_size: deckEntries(state, knowledge).length,
    deck_profile: deckProfileLine(state, knowledge),
    deck: deckLines,
    relics,
    potions,
    potion_slots: `${potions.length}/${asArray(raw["potions"]).length} used`,
  };
}

/**
 * A reply that is a run plan: at least one of the plan's fields given (9GRPA F9 {"choice": "review", "reason":
 * "n/a"}, F25 {"choice": null, "reason": null}: echoes of the decision format, parsed into an all-empty plan
 * that replaced the valid one).
 */
export function isRunPlanReply(json: Record<string, unknown>): boolean {
  const text = (key: string) => typeof json[key] === "string" && (json[key] as string).trim() !== "";
  const list = (key: string) => Array.isArray(json[key]);
  return text("archetype") || text("summary") || text("boss_prep") || text("elites") || text("rest") || list("want") || list("avoid") || list("remove") || typeof json["block_target"] === "number";
}

export function parseRunPlan(json: Record<string, unknown>, state: GameState, knowledge: Knowledge, trigger: RunPlanTrigger): RunPlan {
  const deck = deckEntries(state, knowledge);
  const byName = new Map<string, string>();
  for (const card of deck) {
    byName.set(card.card_id.toUpperCase(), card.card_id);
    byName.set(card.name, card.card_id);
  }
  // Any real card id for want/avoid (not only the deck's); deck ids or names for remove.
  const known = (value: unknown): string | null => {
    if (typeof value !== "string") return null;
    const text = value.trim().replace(/\+$/, "");
    const id = byName.get(text.toUpperCase()) ?? byName.get(text) ?? text.toUpperCase().replace(/\s+/g, "_");
    return knowledge.card(id) ? id : null;
  };
  const inDeck = (value: unknown): string | null => {
    if (typeof value !== "string") return null;
    const text = value.trim().replace(/\+$/, "");
    return byName.get(text.toUpperCase()) ?? byName.get(text) ?? null;
  };
  const ids = (value: unknown, pick: (entry: unknown) => string | null, max: number) =>
    [...new Set(asArray(value as JsonValue).map(pick).filter((id): id is string => id !== null))].slice(0, max);
  const elites = typeof json["elites"] === "string" && ["seek", "normal", "avoid"].includes(json["elites"]) ? (json["elites"] as EliteAppetite) : "normal";
  const rest = typeof json["rest"] === "string" && ["heal", "smith", "auto"].includes(json["rest"]) ? (json["rest"] as RestPolicy) : "auto";
  const blockTarget = typeof json["block_target"] === "number" && Number.isFinite(json["block_target"]) ? Math.max(0, Math.min(20, Math.round(json["block_target"]))) : null;
  const construction = asRecord(json["construction"]);
  const allowedCores = str(asRecord(state.run?.raw)["character_id"]).toLowerCase() === "silent"
    ? new Set(loadConstructionData("silent")?.templates.map((c) => c.id) ?? []) : new Set<string>();
  const primary = str(construction["primary"]), checkpoint = construction["checkpoint"];
  const validConstruction = str(asRecord(state.run?.raw)["character_id"]).toLowerCase() === "silent"
    && (allowedCores.has(primary) || primary === "uncommitted") && typeof checkpoint === "number" && Number.isInteger(checkpoint)
    && checkpoint > (state.run?.floor ?? 0) && checkpoint <= 100 && str(construction["reason"]).length > 0 && str(construction["pivot_if"]).length > 0;
  return {
    runId: str(state.raw["run_id"]),
    act: actOf(state),
    floor: state.run?.floor ?? 0,
    hpPct: hpFraction(state),
    trigger,
    archetype: typeof json["archetype"] === "string" ? json["archetype"].trim() : "",
    want: ids(json["want"], known, 6),
    avoid: ids(json["avoid"], known, 6),
    remove: ids(json["remove"], inDeck, 3),
    blockTarget,
    elites,
    rest,
    bossPrep: typeof json["boss_prep"] === "string" ? json["boss_prep"].trim() : "",
    summary: typeof json["summary"] === "string" ? json["summary"].trim() : "",
    ...(validConstruction ? { construction: { primary, alternatives: [...new Set(asArray(construction["alternatives"]).map((v) => str(v)).filter((id) => id !== primary && allowedCores.has(id)))].slice(0, 3),
      checkpoint, reason: str(construction["reason"]).slice(0, 500), pivot_if: str(construction["pivot_if"]).slice(0, 500) } } : {}),
  };
}

/** One line for the run brief (Jev and DeepSeek see it on build and route questions). */
export function runPlanLine(plan: RunPlan | null | undefined): string | null {
  if (!plan) return null;
  const parts = [plan.archetype, plan.summary].filter(Boolean).join(" — ");
  const want = plan.want.length > 0 ? ` | want ${plan.want.join(", ")}` : "";
  const avoid = plan.avoid.length > 0 ? ` | avoid ${plan.avoid.join(", ")}` : "";
  // Whole: DeepSeek's own plan is part of its history (Roy 2026-09-28: compress the format, never cut).
  return `${parts}${want}${avoid}`.replace(/\s+/g, " ").trim();
}

/** Card-value adjustment from the plan (card rewards, shops). */
export function runPlanCardBonus(plan: RunPlan | null | undefined, cardId: string, blockCards: number, isBlock: boolean): { bonus: number; why: string | null } {
  if (!plan) return { bonus: 0, why: null };
  if (plan.avoid.includes(cardId)) return { bonus: -RUN_PLAN_AVOID_MALUS, why: "run plan: avoid" };
  let bonus = 0;
  const why: string[] = [];
  if (plan.want.includes(cardId)) {
    bonus += RUN_PLAN_WANT_BONUS;
    why.push("run plan: wanted");
  }
  if (isBlock && plan.blockTarget !== null && blockCards < plan.blockTarget) {
    bonus += 6;
    why.push(`run plan: block ${blockCards}/${plan.blockTarget}`);
  }
  return { bonus, why: why.length > 0 ? why.join("; ") : null };
}

/** Route weight change for an elite node. */
export function runPlanEliteShift(plan: RunPlan | null | undefined, hpPct: number): number {
  if (!plan) return 0;
  if (plan.elites === "avoid") return -3;
  if (plan.elites === "seek" && hpPct > 0.6) return 2;
  return 0;
}

/** Rest-site score change for HEAL / SMITH. */
export function runPlanRestShift(plan: RunPlan | null | undefined, option: string, hpPct: number, beforeBoss: boolean): number {
  if (!plan || plan.rest === "auto") return 0;
  if (plan.rest === "heal" && option === "HEAL") return 3;
  // Smithing never overrides a low-HP heal or the pre-boss heal.
  if (plan.rest === "smith" && option === "SMITH" && hpPct >= 0.5 && !beforeBoss) return 3;
  return 0;
}

export function logRunPlan(file: string, entry: Record<string, JsonValue>): void {
  if (!file) return;
  try {
    mkdirSync(dirname(file), { recursive: true });
    appendFileSync(file, `${JSON.stringify({ ts: new Date().toISOString(), ...entry })}\n`, "utf8");
  } catch {
    // logging must never break play
  }
}

/** The last logged plan of this run (a restart keeps it), else null. */
export function loadRunPlan(file: string, runId: string): RunPlan | null {
  if (!file || !existsSync(file)) return null;
  try {
    const size = statSync(file).size;
    const length = Math.min(size, 256 * 1024);
    const buffer = Buffer.alloc(length);
    const fd = openSync(file, "r");
    try {
      readSync(fd, buffer, 0, length, size - length);
    } finally {
      closeSync(fd);
    }
    for (const line of buffer.toString("utf8").split("\n").reverse()) {
      if (!line.includes(runId)) continue;
      try {
        const entry = JSON.parse(line) as { plan?: RunPlan };
        if (entry.plan && entry.plan.runId === runId) return entry.plan;
      } catch {
        // a torn first line
      }
    }
  } catch {
    return null;
  }
  return null;
}

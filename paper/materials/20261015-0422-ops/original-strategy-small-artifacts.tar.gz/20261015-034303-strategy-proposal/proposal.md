# 静默猎手本批十项策略提案核验

记录时间：2026-10-15T03:58:56+08:00。批次 `20261015-034303-strategy-proposal`。

本批是普通已领取提案队列，reason=proposal；没有research_request或implementation_request，未承接任何手动专题。初始工作树干净，`git merge --no-edit main` 返回 Already up to date，完整基线 `bfe25e743c58f9d76666fcd77621f04143075b02`。只处理dispatch.json的十个id。

本批十个派发锚点：KEN58SH9SLZ6、TXZ6RVMQA09D、WQZVENQ7DTRP、02HB4L0C3C67、4D4J8USKCPAV、F4QKG4J1AJJZ、JLN5SK17W4FQ、LS8035TB32P3、NB8KCF6HRGVF、S9UZAK0JP0C0。原提案专用补证：1913SE84AXQF、K3676LU8B0UH、NHA2KW0RB7VP、Q6M2Y34MWKRE、SADL3CGYTGSR，共15局，runs.jsonl角色均为SILENT；不同进阶分列，不混用其他角色知识。五个补证局只服务原派来提案，不扩展队列。

八流均由learner/extract_evidence.py抽取，source_size、逐行offset/bytes/SHA及计数见evidence/evidence-manifest.json；19,929原行已按原字节seek回读、SHA/正文/身份一致性复核，见raw-readback.json。run-plans按run归属选入77行；fight-plans在该源截点选入0行，只表示本范围未选到，不推断日志缺失。43项固定事实检查通过，见fact-checks.json和check_facts.py；这些是证据算术检查，不是生产tsc/vitest成功。

10份原Markdown共43,287字节均与原队列SHA一致；未改原提案、经验、知识或历史复盘。原文副本、原SHA与来源见proposal-input-manifest.json及各*.original.md。既有105/109局统计只保留原文来源，本批未重新验证全历史分母。

本批不拟合新权重/阈值；同局SL、多个状态和模型样本均不当独立局。原局作为固定复核集；未来调整应先用独立较早局拟合，再按开始时间留出之后本角色新局，固定模拟预算，覆盖支持和反例。不能把未记录的反事实改写成可赢。其他角色、未观察进阶与未知组合保持现行为。

源码核对切点live `28bec4afac5c6d51e5f1c30de277c1c6575c188b`。狡诈生成、普通紧勒、王室猛毒开场、连战接续及SL候选资源诊断已有实际live祖先；这只覆盖子范围，不能据此整体登记duplicate。源码路径/祖先/字节SHA见source-audit-initial.json、source-sections.json；card-model整文件与live只差两处旧署名注释，差分另存live-card-model-comment-diff.patch，不误报整blob相同。


## silent-proposal-08eaa60bcc449852

关联账本：silent-0019、silent-0020。来源任务：experience-update；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`。

证据：KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1共七次用药；F5 53→16；F12 26/76→53/81、F16 46/81→75/86。原始帧280206—280355、280336/338、280382/384；七条use_potion为d274131/156/185/235/237/267/272。

反例及限制：零损胜战仍可耗药；七个调用回执是4 completed、3 pending，不能将排队当完成，另由后继药栏和选择状态确认实际消耗。

处置：**waiting**。缺同一入口资源、后续牌序固定的不饮用、提前用或留至boss的整战配对，不能由七次实饮和两次回复拟合持药价格。

预期行为及验证：保留当前药价；将七次消耗、两次实际回复与SL恢复分别记账。新数据需提供不饮/留药完整后继，并按独立局和时间留出验证。


## silent-proposal-92920295a648b540

关联账本：silent-0228、silent-0255。来源任务：postmortem；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`。

证据：TXZ6RVMQA09D A10 F48第2/3试T6：s281479→281484为48→45血、460→424敌血；s281535→281539为48→48血、460→433敌血。第三试T10获胜4血，s281563—281566为F48 REWARD4、MAP4、F49 COMBAT4、GAME_OVER0。

反例及限制：少损3也少伤9，后续生成牌/抽序和行动亦改变；第一场赢不等于两场通关。当前完整截点sl-attempts:975确有F49 died/end_hp0/无judge或reload；旧选择包未纳入此行只说明旧包范围，不能推成全日志缺失。runs:587 death_fight仍留永世沙漏，实际F49为TEST_SUBJECT；不改原记录。

处置：**waiting**。缺固定后轮牌序、药栏、复活与入口资源的连续通关替线；现有连战模型和候选诊断不能认证完整执行归属及联合后继结果，不能校准SL资格或终局血量权重。

预期行为及验证：保留当前连战目标与严格判死；后续联合核每试首战胜负、退出HP/药栏/复活、次战开场及是否到可操作帧。无受控替线时不宣称提高通关率。


## silent-proposal-a327449c331efbc1

关联账本：silent-0079、silent-0018。来源任务：postmortem；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`。

证据：WQZVENQ7DTRP A10 F33第2/3试T9完整决策指纹d275894=d275960；s282075→282079原线损13/净扣24，s282144→282148替线损22/净扣39；第2/6试T7均净扣24、损0/4，下一轮沙坑3/4。

反例及限制：第6试T7付4血多留一轮沙坑是限制一律保血的反例；T9多输出也有额外9血实价。六试相关且都未形成完整胜线，不能作为六个独立样本。

处置：**waiting**。缺血量、毒和沙坑两条结束边界的完整受控后继、同预算成对比较及独立成功验证；不能从9血/15伤拟合统一换价。

预期行为及验证：保留候选即时血价、伤害、毒、沙坑和未知续步的诊断；完整候选必须连接重规划后的实际动作，再考虑改变饱和探索排序。


## silent-proposal-a099e89437e942bb

关联账本：silent-0030、silent-0257、silent-0258。来源任务：experience-update；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`。

证据：WQZVENQ7DTRP及原提案其余八个静默证据局共42次狡诈药水消耗，37次添3、2次添2、3次添0；WQ F33T11 s282292/294/295为2/0/0，s282352/354/356为3/2/0，两组三饮HP/能量不变。九局角色/进阶见verified-run-identities.json。

反例及限制：满手消耗不添刀、计划妥当保留容量和即时生成分账；求解器固定的穿插序列能计算更多刀，不是实盘整战胜利对照。

处置：**waiting**。生成/当前容量已有live实现；缺计划妥当保留选择、生成后重规划的完整候选派发，以及实际SL恢复联合消费者验证，不能整体登记duplicate。

预期行为及验证：保留已实现的升级刀及手位模型；下一项验证须冻结实际保留选择、当前手牌、药槽和恢复身份，贯穿饮用—出刀—再饮用与下一轮，不凭合成序列收益设置留药门槛。


## silent-proposal-47910f82a1fdd98f

关联账本：silent-0018、silent-0019、silent-0020、silent-0021、silent-0025、silent-0079、silent-0198、silent-0228、silent-0255。来源任务：experience-update；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`。

证据：TXZ6RVMQA09D A10 F43/45/46/48/49：s281312/313、281338/339、281367/368、281399/400、281565/566分别70→66、52→48、62→58、60→56、4→0，皆出牌前；另有WQ F33T7/T9双向血价。

反例及限制：王室猛毒无小血瓶分支的五次净4不能拆解未知组合的结算顺序；开场、药水、路线与SL恢复不能重复计算或预支。

处置：**waiting**。开场与次战接续已有live实现；缺留药/路线/SL受控完整后继，未知回血或复活组合的开场顺序仍未观察。局部开场修复不能关闭跨四领域原提案。

预期行为及验证：保留已观察组合的新战扣血，现场T1和SL恢复帧不再扣一次；其余组合未知，完整资源链与替线的终局价另等受控数据。


## silent-proposal-f1374df72d8e6a25

关联账本：silent-0019、silent-0020、silent-0050、silent-0253。来源任务：postmortem；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`。

证据：补证Q6M2Y34MWKRE A10 F7 s282869—871休息36→57，F8 s282872—912赢战57→2，F9 s282913—921以2血入场死亡；1913SE84AXQF F29 s282723—750为61→46，F31 s282755入口46。F2T1早喝敏捷的候选与T3实喝见原提案。

反例及限制：Q6已实际休息且两瓶已喝；F5/F6零损留药也是限制一律提前喝的反例。候选早用药未完整实打，且旧紧勒机制误差须与价值权重隔离。

处置：**waiting**。缺隔离机制误差后的同预算完整后继，以及未用、早用、留药的成对整战结果；现有临时/持续药效不支持直接改药价、护栏或终局曲线。

预期行为及验证：维持现值；以实际退出HP/药栏和后继入口为校验对象，先固定状态及时间预算，再按独立局向前验证候选资源价值。


## silent-proposal-38a49e6c97f31eea

关联账本：silent-0006、silent-0011、silent-0025、silent-0044、silent-0050、silent-0064、silent-0133、silent-0253、silent-0259、silent-0261、silent-0262。来源任务：experience-update；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`。

证据：Q6M2Y34MWKRE A10 F8T4 s282887—892敌HP103→95→85→85→83→80，普通紧勒后续两次失血共4，净扣23、玩家34→33，弃牌选择中途未触发、完成后触发、次轮清层。1913SE84AXQF F31T2弃磨蚀、T3/T4反伤及重接为原提案其余子项。

反例及限制：普通紧勒修复不等于升级/叠层/重放均已验证；普通磨蚀出牌预览不等于弃牌触发。反杀不能提前取消已经发动的敌攻击，旧失败不能充作单一机制的完整胜负因果。

处置：**waiting**。普通紧勒与磨蚀预览已有live实现；缺弃牌触发、增益分源、重接、反伤、再生跨回合的联合生产消费者验证，不能关闭整组机制提案。

预期行为及验证：保留已经验证的普通分支；用实际弃牌完成时点和敌逐段攻击/重接建立联合固定输入，未知触发/恢复分支仍明确未知，不新增数值规则。


## silent-proposal-ef0e38a5dbd3bc07

关联账本：silent-0019、silent-0020、silent-0021。来源任务：experience-update；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`。

证据：1913SE84AXQF A10 F24 s282706—709为锻造40→40，F28 s282720—722回复21到61，F29赢损15到46，F31以46入场死；Q6M2Y34MWKRE F7休息后57、F8赢后2、F9死亡。

反例及限制：计划中F24回复实际改锻造，原投影与实测条件不同；未到的未来营火、未取得能力或未触发下轮毒不能算当前可用资源。两条失败链没有另一条实际成功路线。

处置：**waiting**。缺另选营火/事件/路线、早用或留药的完整受控结果；不能由条件已改变的投影和两条败局拟合通用路线/资源权重。

预期行为及验证：资源审计保留实际休息、锻造、事件、幕间、战内回复和SL恢复的来源；以真实入口核对，未来路线选择的因果验证等待新数据。


## silent-proposal-7f820c02d39bfaea

关联账本：silent-0079。来源任务：postmortem；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`。

证据：补证NHA2KW0RB7VP A10 F33T1：第2试s283412→283418为30→29血、敌408→400；第5试s283478→283483和第6试s283502→283507均30→23血、敌408→384，实价多6血、多16净扣。原决策d277248/250/272/274保存于selected-decisions.json。

反例及限制：第一试最初帧仍未完成开场，用第2试可操作30血作对照；次轮自动伤包含在跨轮净扣中，不冒当全部卡牌伤。各试均无已证整场胜利。

处置：**waiting**。原答/替线预测比较已有live实现；缺成对完整后继、重规划后的完整派发归属和同预算饱和排序校准，不能给探索血价新门槛。

预期行为及验证：保留预测与实际结果区分，并联接chosen/result/gate与后续状态；只有候选推进和实际资源结转有独立校准后才调整notWorse筛选。


## silent-proposal-04b6b430759815ed

关联账本：silent-0005、silent-0006、silent-0021、silent-0011、silent-0065、silent-0264、silent-0079、silent-0133、silent-0169、silent-0189、silent-0013、silent-0053、silent-0162、silent-0265。来源任务：experience-update；本实现核验任务：strategy-proposal/20261015-034303-strategy-proposal。原提案SHA256：`188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`。

证据：补证NHA2KW0RB7VP A10 F33T1油灯首次X1萎靡与F17T1毒药、F33T2朝向；K3676LU8B0UH A1 F30T2 s217009/217010带毒刺击后建8毒，SADL3CGYTGSR A7 F45T1 s232562/232563毒药后建10毒。完整已核与未核范围保留在原提案和silent-0264/0265。

反例及限制：持有油灯不证明首次负面尚未消费；当前快照、后续重规划和SL恢复不能随意重置首次标志。局部多4伤或少1伤不证明改变终局胜负，未观察负面/零X/升级/叠层不外推。

处置：**waiting**。部分子公式已有live实现；油灯缺可靠首次消费来源与跨动作、新战、SL恢复联合验证，早建能力的完整后继未证，不能仅按持有遗物一律翻倍。

预期行为及验证：保留现有已证子公式；下一次需提供消费标志的可重建证据和动作/新战/SL隔离验证，再限定观察分支补模；不新增通用倍率规则。


## 实现、验证、回退和后继

本批没有源码或策略参数改动，不生成源码提交、行为版本、合入或shipped。`fixes=[]`、`merged=null`、`implementation_domains=[]`；code_proposals只列已领取十个既有id，不登记重复提案。源码撤除/恢复验证、tsc、vitest均不适用，结果为null，不借旧绿或本批证据检查冒称代码验证。未来任何实现应单项提交，撤源码固定测试失败、恢复通过，按原沙箱入口/live锁/版本/双通知流程验证；回退只撤实际实现范围，保留刷新知识、原证据及失败历史。

所有waiting理由仅指本批原文与15局冻结输入的验证缺口，不宣称整个不断增长日志中不存在别的证据。生产候选诊断仍是预测，不能由当轮数字宣称完整派发/实战通关收益。原提案父范围不因本次报告关闭；由原调度器收到后继续待新局重派，实际是否采用须另验消费者。

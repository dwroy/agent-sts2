# 本批策略学习报告

时间：2026-10-15 03:29:10 CST。task=strategy-proposal，character=silent，batch=20261015-031301-strategy-proposal。

**结果：十项原提案均waiting。** 六局原始证据支持局部成本与阶段事实，尚不能支持统一血价/探索门槛、跨战药水持有价值或新SL参考排序；既有诊断未覆盖宽提案全部范围。本批无源码/知识修改、无提交、无live合入、无发布号；无新的经验入库或自然消费者采用声明。

## 身份与范围

开工与最终基线均为完整40位 `7f67f7a9670cd2f9d81aea4b5d998a595babad24`。普通派发reason=proposal，十个proposal_ids逐项处理，未领取其他批次；dispatch.json只保存对应行。纯研究第1.2节条件不成立，未读取其他专题代替本批身份。首次git status --short为空，普通git merge --no-edit main无变化；不再次合入并行main。

来源局：751FN9QM9MHQ、KV0JHNJCKXLS、YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN、KEN58SH9SLZ6。六局runs均SILENT/A10且已结束；不据旧日志中的模型配置断言当前原生会话已核。本批没有读取其他角色知识，没有联网、调用LLM、play、推送或改运维prompt。

## 冻结与字节复核

| 流 | 字节截点 | 本批行数 | 提取SHA256 |
|---|---:|---:|---|
| runs | 329966 | 6 | 8a1992a135d83a19b3c566799bd5bc986e40bb00f9e82a5315988b1fac549623 |
| states | 12856841004 | 4167 | 1b74593cadfe044177b4c555480495c7cef63bb8d75976cd0fe53edea4281a94 |
| decisions | 1458193597 | 4071 | 4339d083eb9f60e16bac838a69ed8d511652e1aad60221e69fdaaaed6719cfaf |
| sl-attempts | 39515920 | 43 | d7f37542775ee826a026005f0c10246dccb32f7494197f7d6af10a6c788b30e0 |
| run-config | 1711099 | 6 | 160a9cc5bb8f6f2be607978ea43281624c647f55410eba98a96552b733ee1c0c |
| run-plans | 7854627 | 21 | 77090bb5042d72a73b1cba4c077656896f7f7f45a9013d21bcfd17d5a87a8bbd |
| brain | 534286844 | 130 | 7a47a8693d07c54103662c608bd1a03a85af0cdf8c06177f46f3fbb624c41c12 |
| fight-plans | 2233957 | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |

共8444行：states4167、decisions4071、sl-attempts43、runs6、run-config6、run-plans21、brain130、fight-plans0。每流独立在打开时冻结source_size，不宣称所有流具有同一个时间截点；随后逐选行pread复核offset/bytes/SHA和JSON正文、显式所属身份。run-plans读取run，其他流读取run_id/state.run_id/fingerprint.run，正文提及不算所属局，冲突身份由共用入口拒收。fight-plans的0仅表示此截点未选到本六局，不能断言原日志缺失。

完整源扫描的无效JSON行：states2、decisions2、brain1；这些未接收为本批证据，也未据此推定本角色缺帧。没有复核旧截点或覆盖任何历史/零行报告。全部原始日志只读。

## 已核局部事实与反证

- 751FN9QM9MHQ F17 T2，decisions 272434/272575：局部净损血13→18，同敌同阶段端点净扣血9→18。两条局部路径不是保持后继不变的整战反事实；complete_candidate_result=null。
- 751FN9QM9MHQ F17 T7，decisions 272531/272652：局部净损血13→23，同敌同阶段端点净扣血12→18。两条局部路径不是保持后继不变的整战反事实；complete_candidate_result=null。
- KEN58SH9SLZ6 F17 T10，decisions 274505/274568：局部净损血15→21，同敌同阶段端点净扣血2→4。两条局部路径不是保持后继不变的整战反事实；complete_candidate_result=null。
- KEN58SH9SLZ6 F17 T5，decisions 274484/274601：局部净损血7→5，同敌同阶段端点净扣血1→2。两条局部路径不是保持后继不变的整战反事实；complete_candidate_result=null。
- KV0JHNJCKXLS F33 T5，decisions 273400/273450：局部净损血0→0，同敌同阶段端点净扣血36→29。两条局部路径不是保持后继不变的整战反事实；complete_candidate_result=null。
- KV0JHNJCKXLS F33 T1，decisions 273242/273474：局部净损血0→0，同敌同阶段端点净扣血28→14。两条局部路径不是保持后继不变的整战反事实；complete_candidate_result=null。

751 F13 T3 decision272361：有药plan2与显式整战无药plan5模型即时损8，模型输出26/16；普通本轮无药plan3后续7/8样本仍喝。模型参考不等于实际无药/留药分支，也不把缺表的成本0认定为实测持有价值0。

KEN七次实际耗药的原decision与十四张原状态见evidence-audit.json。F3攻击药、F11攻击药、F15技能药的回执为pending，但随后药槽occupied true→false；据状态确认耗药，未把pending改写为completed。选牌及发光水续问后的完整候选兑现仍为空。F17 T1实75/86且空药槽。

YQL F17 T10 states280160/280161：占位体毒2→8，而HP26、挡13、DeathBlow41均不变；本体max_hp占位999999999且EXPLODE_MOVE。只证明这次实盘局部变化，不能推断提前喝、不喝或留药能赢。751/KEN/YQL各F17六次均未赢；PU F17存在实际won的反例，六次相关尝试不作为六个独立局。

少失血也有延迟能力建立的原反例（KEN T5）；局部多输出同时多失血（751 T7/KEN T10）。KV删毒或删输出在该轮均未获得净HP收益，不能凭全败模拟饱和给删输出贴保血收益。毛伤、毒、反伤、回血的完整逐源兑现未在本批认证；相关局后继动作/抽序不同，净HP端点不能替代完整候选实际收益。

## 当前源码与消费者边界

只读live核对提交：`7ccd6158140be85a2e75a66d18d2dd7fde697cfc`。十二条相关路径的磁盘字节均等于该live提交；十一个与本基线逐字节相同，explore.ts只差三处历史注释署名。以下每个实际live最后路径源码commit均已验证为该live祖先：

| 相关文件 | 实际live最后源码路径提交（已核祖先） | 对照 |
|---|---|---|
| agent/src/reflex/silent-sl-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 逐字节相同 |
| agent/src/reflex/silent-sl-resource-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 逐字节相同 |
| agent/src/reflex/silent-held-loss.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 逐字节相同 |
| agent/src/reflex/silent-potion-reference.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | 逐字节相同 |
| agent/src/reflex/silent-giant-potion.ts | d5e20aa4dd44168ce30944dfcce74f8322144953 | 逐字节相同 |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 逐字节相同 |
| agent/src/reflex/silent-selection-dispatch.ts | bade647f9fe4c9103b40e2f26b26296692ad24b7 | 逐字节相同 |
| agent/src/reflex/silent-hp-guard-audit.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 逐字节相同 |
| agent/src/reflex/combat-plan.ts | 412b1665e226da001be3a72e5b423f09d477c730 | 逐字节相同 |
| agent/src/sl/attempts.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 逐字节相同 |
| agent/src/sl/explore.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 仅三处Roy/Dai历史注释署名差异 |
| agent/src/hand/loop.ts | a9fcf33ca4c204d03cfc310c7f7ced61f196f964 | 逐字节相同 |

已有silentSlComparison/silentSlResourceComparison保存候选预测及差额，silentHeldLossFacts显示未决弃牌的保守持牌损血，silentPotionReference标持有价值未知与无药预测，silentSelectionAudit区分原答/护栏/SL阶段，silentSelectionDispatch仅证明单次动作回执；这些源码明确actual_turn=null或whole_plan_executed=null。本批不能把原历史局的原数据补写成这些后来字段已被自然消费。

巨兽phase与实际资源字段、药水观察已有独立诊断；anchorRank仍按原存活轮和原敌HP顺序。把占位体HP归零后直接排序可能改变平局参考，原提案已给出缺口较大路径的反例；本批没有验证新的排序收益，保留原规则。未降低模型可信度、未知机制或必死/SL门禁。

knowledge/characters/silent/experience.json版本2026-10-13.8中十二个关联经验id均存在；只保存本角色原链接及SHA，不刷新知识、不搬用其他角色统计、不重新认证其中额外历史局。十个原提案SHA全部一致。相关账本已经包含历史上线状态，trace-only CLI仅追加本批报告与原id链接，不把既有shipped条目降级或重新标shipped。

## 逐项处置与下次验证

- `silent-proposal-366288801d9150d9`：waiting；751 F17 T2/T7同盘局部血价已核，live已有候选成本审计；缺跨抽弃/续问的完整候选实果、保持后继受控的整战比较及独立后期校准，不能拟额外失血准入阈值。
- `silent-proposal-85929bdfc8a3fc1b`：waiting；751 F13 T3有药/无药即时预测均损8、明确整战无药仅属模型参考；本局只实际喝药，缺不喝及留药至boss的完整支线，持有价值与未决弃牌后实际收益仍未校准。
- `silent-proposal-efd9f83ee9e1a6dc`：waiting；751六次SL属于同一局且均未赢；已有血价与持牌预测审计不能代替原经验提案所需的完整候选归属、受控整战和独立验证。
- `silent-proposal-131042659448ae74`：waiting；751能力、毒、荆棘与未决持牌损血已有部分模型拆项；缺逐源实际兑现、抽弃续问后的完整执行，以及无药/留药的跨战联合验证，不能关闭全部经验关联。
- `silent-proposal-990f054036609447`：waiting；KV F33 T5同盘删毒净输出36→29且当轮均零损，T1删输出28→14；缺完整候选末端与固定后继整战、回血毛伤逐源核验、未执行路线/休息支线，不能拟SL或回血门槛。
- `silent-proposal-e18d3f18e6cac2a0`：waiting；三巨兽局已核占位血与自爆阶段、live已有展示；anchorRank仍沿原存活轮/原残血顺序。新参考排序缺受控完整后继、最终资源校准和独立验证，不能把局部阶段修复当整项duplicate。
- `silent-proposal-9733bb80f445aeae`：waiting；YQL末次本体结束后的毒药水使毒2→8但血26/挡13/来袭41不变；缺提前喝、不喝、留药与新SL排序的受控整战对照，跨战药值及策略收益未知。
- `silent-proposal-c51468c5e8ba6668`：waiting；KEN七次耗药及F17空栏75血入口已由原状态核实；三次pending回执由槽位状态补证。缺随机选牌/发光水续问后的完整候选收益、F15不喝或留药到boss的支线。
- `silent-proposal-86a7db08d1a31976`：waiting；KEN同盘T10多6失血仅多2净扣敌血、T5省2血但步法建立延后；缺完整伤源和能力兑现归属、受控整战后继及独立校准，不能改探索准入或HP护栏。
- `silent-proposal-e282a9131b99129a`：waiting；KEN六次尝试相关，T10血价及T5能力窗口反例已核；缺完整后继反事实和独立后期验证，不能拟统一血价、将当前预测审计当完整实果或关闭原经验提案。

每项账本、证据层/回合、旧/预期行为、反例、独立局时间切分、验证和回退详见proposal.md。新增完整支线前不拟合常数；不关闭任何学习入库父要求，不将候选框架完成等同量化学习完成。

## 校验、失败记录与交付

材料校验：最终audit_evidence.py退出0，46项断言通过，八流8444行原字节与身份核验、六组同指纹及七次药槽消费通过。audit_sources.py退出0，十二源码路径祖先/磁盘/基线范围核验通过。它们是scratch材料核验脚本，不是生产tsc/vitest测试。

失败原件保留：第一次提取误用combat/sl流名，被参数解析拒绝exit2，未写证据，已改为真实八流；若干shell/apply_patch在沙箱准备时因自动回收路径的glob扫描竞态未执行，重跑成功；首次源码审计猜错core/loop路径exit1，按rg找到hand/loop后成功。材料断言首版误预填751 T7敌净扣13/19而失败，逐帧核为12/18、差额仍6，修正仅这份scratch核验脚本并保留evidence-audit.first.err；第二次39断言通过，加入七次实际药槽核验后最终46断言通过。未改生产断言、未把这些错误冒称生产代码失败。

源码未改：撤源码失败/恢复通过不适用；未运行tsc、vitest或完整模拟，tests固定为{tsc:null,vitest:null,cases:null}，不能借用历史通过。没有源码commit、merged=null、release_id=null。工作树tracked diff与status保持零；scratch属于原忽略目录，原证据和失败不删。最终交付前完成本批记录读回及gitleaks扫描，结果单列validation.json。

运维交付路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-031301/learner/runs/20261015-031305-strategy-proposal/proposal.md`；报告：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-031301/learner/runs/20261015-031305-strategy-proposal/report.md`；最终机器结果：final.json。原队列waiting更新交原调度器按proposal_results处理，本任务不手改队列/learn.json、根请求或旧父done状态。

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261015-031301-strategy-proposal",
  "base": "7f67f7a9670cd2f9d81aea4b5d998a595babad24",
  "runs": [
    "751FN9QM9MHQ",
    "KV0JHNJCKXLS",
    "YQL8RZ8BWN1E",
    "L9SGRBB5R698",
    "PU80F84P6HPN",
    "KEN58SH9SLZ6"
  ],
  "fixes": [],
  "skipped": [
    "十项原提案所缺完整候选/受控后继或跨战反事实未补齐；保留waiting，不新增游戏参数。"
  ],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-366288801d9150d9",
    "silent-proposal-85929bdfc8a3fc1b",
    "silent-proposal-efd9f83ee9e1a6dc",
    "silent-proposal-131042659448ae74",
    "silent-proposal-990f054036609447",
    "silent-proposal-e18d3f18e6cac2a0",
    "silent-proposal-9733bb80f445aeae",
    "silent-proposal-c51468c5e8ba6668",
    "silent-proposal-86a7db08d1a31976",
    "silent-proposal-e282a9131b99129a"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-366288801d9150d9",
      "state": "waiting",
      "reason": "751 F17 T2/T7同盘局部血价已核，live已有候选成本审计；缺跨抽弃/续问的完整候选实果、保持后继受控的整战比较及独立后期校准，不能拟额外失血准入阈值。"
    },
    {
      "id": "silent-proposal-85929bdfc8a3fc1b",
      "state": "waiting",
      "reason": "751 F13 T3有药/无药即时预测均损8、明确整战无药仅属模型参考；本局只实际喝药，缺不喝及留药至boss的完整支线，持有价值与未决弃牌后实际收益仍未校准。"
    },
    {
      "id": "silent-proposal-efd9f83ee9e1a6dc",
      "state": "waiting",
      "reason": "751六次SL属于同一局且均未赢；已有血价与持牌预测审计不能代替原经验提案所需的完整候选归属、受控整战和独立验证。"
    },
    {
      "id": "silent-proposal-131042659448ae74",
      "state": "waiting",
      "reason": "751能力、毒、荆棘与未决持牌损血已有部分模型拆项；缺逐源实际兑现、抽弃续问后的完整执行，以及无药/留药的跨战联合验证，不能关闭全部经验关联。"
    },
    {
      "id": "silent-proposal-990f054036609447",
      "state": "waiting",
      "reason": "KV F33 T5同盘删毒净输出36→29且当轮均零损，T1删输出28→14；缺完整候选末端与固定后继整战、回血毛伤逐源核验、未执行路线/休息支线，不能拟SL或回血门槛。"
    },
    {
      "id": "silent-proposal-e18d3f18e6cac2a0",
      "state": "waiting",
      "reason": "三巨兽局已核占位血与自爆阶段、live已有展示；anchorRank仍沿原存活轮/原残血顺序。新参考排序缺受控完整后继、最终资源校准和独立验证，不能把局部阶段修复当整项duplicate。"
    },
    {
      "id": "silent-proposal-9733bb80f445aeae",
      "state": "waiting",
      "reason": "YQL末次本体结束后的毒药水使毒2→8但血26/挡13/来袭41不变；缺提前喝、不喝、留药与新SL排序的受控整战对照，跨战药值及策略收益未知。"
    },
    {
      "id": "silent-proposal-c51468c5e8ba6668",
      "state": "waiting",
      "reason": "KEN七次耗药及F17空栏75血入口已由原状态核实；三次pending回执由槽位状态补证。缺随机选牌/发光水续问后的完整候选收益、F15不喝或留药到boss的支线。"
    },
    {
      "id": "silent-proposal-86a7db08d1a31976",
      "state": "waiting",
      "reason": "KEN同盘T10多6失血仅多2净扣敌血、T5省2血但步法建立延后；缺完整伤源和能力兑现归属、受控整战后继及独立校准，不能改探索准入或HP护栏。"
    },
    {
      "id": "silent-proposal-e282a9131b99129a",
      "state": "waiting",
      "reason": "KEN六次尝试相关，T10血价及T5能力窗口反例已核；缺完整后继反事实和独立后期验证，不能拟统一血价、将当前预测审计当完整实果或关闭原经验提案。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-031301/learner/runs/20261015-031305-strategy-proposal/report.md"
}
```

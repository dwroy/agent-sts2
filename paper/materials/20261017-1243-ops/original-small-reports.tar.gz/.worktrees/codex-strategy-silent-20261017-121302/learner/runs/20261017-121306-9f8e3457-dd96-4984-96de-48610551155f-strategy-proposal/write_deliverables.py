import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = 'd05663b5ce6ef27475c84e3dfb0f3dcae55bee2c'
BATCH = '20261017-121302-strategy-proposal'
RUNS = ['751FN9QM9MHQ', 'KV0JHNJCKXLS', 'YQL8RZ8BWN1E', 'L9SGRBB5R698', 'PU80F84P6HPN', 'KEN58SH9SLZ6']


def main():
    stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    print(stamp)
    items = json.loads((OUT / 'queue-selected.json').read_text())
    reasons = [
        '751 F17 T2/T7/T13同题端点已核；现有SL原/替线预测及配对B2记录不等于抽弃重问后完整候选的实际归属。缺逐来源实结算、受控整战后继与独立验证，不拟5/10血准入门槛。',
        '751 F13 T3用药/整战无药模型均损8，持有价未知与未决弃牌提示已有；缺实际无药完整分支、留药后战对照及逐来源损血认证，不能从空药Boss败局定留药价或改弃牌。',
        '与366288共享751同一六试，不增加独立样本。现有资源预测不能认证完整执行、真实持牌成本或受控胜因，缺整战后继与留后新局验证。',
        '已核敏捷建立、持牌失血、毒/荆棘局部状态及未知药价；缺这些机制的联合逐来源实际校准、完整候选归属及跨战用药对照，不能用已有单项提示关闭整包。',
        'KV F33第4/5试T5均零净损，净扣敌36/29、次轮毒20/13；末试327→342含毒结算与回血。缺逐来源毛伤/回血归属、保持后轮条件的整战比较及路线/休息替代后继，删输出没有已证保血收益。',
        '三个巨兽局的占位血与YQL毒2→8而自爆41已核，现有阶段/残壳提示与旧排序并存；缺改排序、提前喝/不喝/留药的受控完整后继，PU胜线同时有其他变化，不能据占位血统一归零证明新排序更优。',
        '与e18d3f18共享巨兽三局；阶段及残壳用毒事实已有窄实现，缺阶段估值、参考路径排序与用药时点的受控整战比较，不能把PU过爆余2当本提案整包完成。',
        'KEN七次use_potion指令与逐槽耗药端点均核，三次回执pending须连选牌/续问核效果。缺随机选牌后完整候选收益归属、同题不饮用及留至Boss的完整对照，空药栏失败不能拟合持有价。',
        'KEN F17 T10多6血仅多2伤、T5省2血但步法延至T9均核；缺逐来源兑现、完整候选认证、保持后轮条件的整战对照和独立验证，不设6血/2伤通用门槛或关闭更差线探索。',
        '与86a7db08共享KEN同一六试，不能重复计样本。血价/无实体/能力窗口只有局部配对与已有预测，缺完整执行归属、受控整战后继和独立验证，保留现排序与护栏。',
    ]
    evidence = [
        '751 F17 T2/T7/T13；决策272434/272575、272531/272652、272483/272820',
        '751 F13 T3决策272361、F17 T7/T13/T17；状态278403—278407、278500—278505',
        '751 F17，同第1项；经验提案不是新增一局',
        '751 F13/F17，同第2项，联合校准仍缺',
        'KV F33 T5决策273400/273450/273451；状态279460/279465、279511/279515、279559/279560',
        'YQL F17 T10状态280160/280161；SL681/717/960—963；PU F17 T15状态252435/252436',
        'L9/PU/YQL F17，同第6项',
        'KEN F3T2/F4T1/F5T2/F11T1、T2/F15T1；决策274131/274156/274185/274235/274237/274267/274272',
        'KEN F17 T10决策274505/274568、T5决策274484/274601；状态280691—280723',
        'KEN F17，同第9项；经验提案不增独立分母',
    ]
    results = [{'id': item['id'], 'state': 'waiting', 'reason': reason} for item, reason in zip(items, reasons)]
    result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
              'runs': RUNS, 'fixes': [], 'skipped': [], 'merged': None,
              'tests': {'tsc': None, 'vitest': None, 'cases': None},
              'code_proposals': [p['id'] for p in items], 'implementation_domains': [],
              'proposal_results': results, 'report': str(OUT / 'report.md')}
    (OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    table = '\n'.join('| ' + ' | '.join([p['id'], '、'.join(p['ledger']), ev, reason]) + ' |'
                      for p, ev, reason in zip(items, evidence, reasons))
    proposal = f'''# 静默猎手：本批十项既有提案逐项核验

记录时间：{stamp}。批次 `{BATCH}`；来源与实现任务均依原项保留，当前消费者为 `strategy-proposal`。角色只限 silent，本批六局均A10。基线 `{BASE}`；初始工作树干净，`git merge --no-edit main` 返回 Already up to date。本批无 research_request / implementation_request，不承接其他批次专题、队列或旧父请求。

## 逐项处置

下表每项均 waiting；不新建重复提案、不改原文或经验。原 Markdown 十份副本、保存SHA及队列当前行在本目录 `*.original.md`、`queue-selected.json`、`queue-selected-physical.json`。每份SHA均与专用队列保存值相同。

| 提案 | 原账本 | 实际核验锚点 | 本轮结论及缺口 |
| --- | --- | --- | --- |
{table}

## 支持、反向取舍和未知

1. 751 F17：第1/3试T2两端净扣敌9/18、净损血13/18；第2/4试T7为12/18、13/23；第1/6试T13为17/11、8/2。三组题面指纹相同；只认证这些端点差额，不把同指纹称完整隐藏状态或随机种子相同。T7未决弃牌的模型保守多计与实际替线多付10血是不同口径。
2. KEN F17：第4/5试T10净扣敌2/4、净损15/21，原B2 .385/.127、差−.2583、SE .0132；第4/6试T5净扣敌1/2、净损7/5，但后者步法从T5延到T9，T8两防御实际合10挡。该反向取舍排除“少损血一律更好”的推断，不据早死轮数独归单次换线。
3. KV F33：第4/5试T5删致命毒药后同零净损，净扣敌36/29，次轮毒20/13。末试T4行动末327/15毒到T5的342/14毒，跨轮同时有毒与回血，不能把净HP差当毛伤或把删输出说成已保血。后轮动作不受控。
4. YQL F17末T10饮毒水，玩家26血13挡、残壳999999999血、自爆41均不变，只观察毒2→8。L9/PU/YQL旧SL锚点确有近十亿占位血。PU第5试T15真实24血20挡对42自爆后奖励帧余2，是胜线存在的反向证据；没有隔离改排序、提前用药或单一出牌的效果。
5. KEN七次药水指令与前后槽位消耗均核；F3、F11攻击药和F15技能药回执为 pending，后帧已进 CARD_SELECTION，不能据回执文字认作未饮用或收益完整兑现。六次Boss入口均75/86空药。751 F13同题用药与整战无药参考模型都损8，伤26/16；plan3当轮无药的后续仍会喝，plan5才明确整战无药。没有对应实际未饮用/留药分支，不能拟合跨战持有价。

## 已有源码与实际边界

`source-audit.json` 在 live `fd3f1a223d2515b5d458c9eb334f83b38045f4a3` 的限定快照核12源码叶：10叶字节相同，`explore.ts`、`combat.ts`仅Roy/Dai历史注释署名差；所有记录的last_commit均为该live实际祖先。`source-vs-live.patch`保存完整限定差异，8个小源码原字节另存 `.txt`。只核这些叶，不冒称全树/历史dirty运行环境等同。

- 持牌预测与弃牌未决：`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`，`silent-held-loss.ts`；`actual_held_hp_loss=null`，仍须实际续步后核对。
- 同题持有价未知及无药范围：`c4670f4f416c7d93e192e889c5080e7e4e0e733f`，`silent-potion-reference.ts`；未测跨战持有价值。
- SL候选预测与资源差：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac` / `1698adc96ba434a46942321e0237b70657e625b2`，`actual_turn_result=null`、`execution=unverified`；抽弃/药水后完整执行归属不是已证。
- 巨兽阶段与残壳提示：`40168f4a903ae1d8c48bd03006f8fea19fd3aa3c`、阶段记录叶last_commit `b01edf46b4b619f217d070a196e161df9fe716a0`；阶段不当胜利，`enemyHpLeft`和`anchorRank`仍保留旧残血排序。统一归零会改同轮平局，不能无验证称为纯指标等价修复。

以上只是已有子项的源码依据，本批不据此给整个宽提案登记duplicate/implemented，也不把早已shipped的单条知识降回proposed。

## 预期行为、验证和回退

保留当前选项、排序、HP护栏、药水及SL门槛，未观察进阶和其他角色无源码/知识变化。新增核验材料能复现局部端点及未知范围，不预报胜率收益。

后续最小验证输入为同角色候选原答→最终替线→实际选牌/抽牌/药水→重问→回合终点的完整身份链、按来源实际损血/伤害/敌回血及能力建立时点；未执行分支须单独标模型反事实。若拟合规则，旧独立局做公式核验/调参，同一局全部SL放同一分区，按真实开始时间保留新局验证；本批不拟合阈值、不新跑模拟/LLM。巨兽排序须保存旧新选中路径和完整过爆后继，不能借占位血归零或PU胜局作因果证明。数据仍缺则继续waiting。

没有源码提交、合入或行为发布；撤源码失败/恢复通过不适用，tsc/vitest/cases均null。当前没有需要回退的源码；未来只回退真实独立实现提交并保留原日志、原提案与失败史。账本只经根CLI追加本批报告/提案追溯，不追加support/repeat、不改claim/evidence/status/version。十项原id由宿主根据最终proposal_results保留等待新证据。
'''
    (OUT / 'proposal.md').write_text(proposal)
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    validation = json.loads((OUT / 'validation.json').read_text())
    stream_table = '\n'.join(f"| {s['stream']} | {s['source_size']} | {sum(s['counts'].values())} | {s['invalid_lines']} |" for s in manifest)
    ledger_path = OUT / 'ledger-link-readback.json'
    ledger_status = ('根CLI追溯已完成；机械读回：\n```json\n' + ledger_path.read_text().strip() + '\n```') if ledger_path.exists() else '根CLI追溯准备中；最终读回另存 ledger-link-readback.json。'
    report = f'''# 本批策略提案核验报告

{stamp}；`{BATCH}`；silent。

本轮十项均 waiting：局部事实得到复核，缺口仍是完整执行归属、逐来源校准及受控后继。未新增策略源码/知识、提交、合入、行为版本或shipped登记。`base={BASE}`，`fixes=[]`、`merged=null`、生产测试均null。

## 身份与范围

根learn.json对应batch的task/character/worktree/六个runs及十proposal_ids已核，reason=proposal；没有research_request、implementation_request、proposal_repair。普通专题文件仍绑定20261010另一批，本批不读取其work_spec或冒作研究完成。原派发冻结 `dispatch.json`；每项原文SHA均匹配，队列734条所属物理行的offset/bytes/SHA保存在 `queue-selected-physical.json`。未领取其他id，也未以普通批次完成专题父请求。

初始及合main后HEAD均为完整base，merge输出Already up to date，工作树干净。六局runs.jsonl均SILENT/A10，局号顺序见最终JSON；各历史code带dirty，不重建或冒认其完整运行树。只读本角色证据与本批关联账本；不搬其他角色知识。

当前工具没有此线程的原生模型/effort回执可读，现有本批out/err未提供可核字段；未将README默认配置冒称实际请求或会话已切换，也未改模型配置。没有派下级agent。

## 原始证据与截点

使用指定共用 `learner/extract_evidence.py`，一次提取六局八流。每流保存source_size、按局计数、每行原offset/bytes/SHA及输出摘要；源文件只读。摘要如下，完整每局计数见 `evidence/evidence-manifest.json`。

| 流 | source_size（字节） | 本批封套数 | 全流坏行数 |
| --- | --- | --- | --- |
{stream_table}

共{sum(sum(s['counts'].values()) for s in manifest)}条封套、4167状态帧、763个观察回合窗口；均为本批六个独立局中的相关SL与后继，不是763次独立策略实验。states/decisions/brain各2坏行不能可靠归属本批，不把其算缺失局证据；fight-plans在该截点0行只说明未选中，不断言源流不存在。没有覆盖旧零行报告；`projection-summary.initial.json`保留提取尚未结束时的范围说明，最终摘要已核manifest存在。

`state-projections.json`、`turn-windows.json`及`decision-projections.json`是有界字段投影，所有原字节封套仍保留。`validation.json`最终{validation['passed']}项材料/算术核验通过、{validation['failed']}失败，{len(validation['raw_references'])}条限定引用按原文件offset/bytes/SHA及显式run身份读回。八流输出摘要与封套数一致；这不是生产消费者执行、重放模拟或tsc/vitest通过。

首版材料脚本37过2败：错误地将下一回合已重新抽牌的手中呼唤数量预期为0，实际280692为2、280709为1。已按实际手牌更正，只用上一轮末帧认证持牌、下一轮入口认证净HP差；原脚本、validation.initial.json及stdout均保留，不改游戏原件、不把分析脚本误期望当机制反例。一次apply_patch因并行工作树`.codex`路径消失触发沙箱glob扫描失败；同范围相对路径重试成功，未扩权限，不作产品失败。一次只读rg使用不存在的agent/src/loop.ts，随后改按实际reflex入口核验；无代码修改。

## 结论、源码边界及逐项结果

完整证据、层/回合、既有账本id、反向取舍、已存在源码实际live祖先、等待条件、未来验证与回退在 [proposal.md](proposal.md)。尤其保留：751多输出付血与T13省血少输出；KEN省血却延迟敏捷；PU多因素胜线不能证明统一禁止付血探索；巨兽毒层不等于减自爆；KV净血差不等于毛伤；药水用掉/实际收益/留药价值分别核。没有足够证据确定新的游戏参数或通关因果，保留现行规则。

`source-audit.json`与`source-vs-live.patch`限定核12叶、10叶同字节/2叶仅历史注释署名差、12个last_commit均为该live祖先。只证明已有子项在该快照存在，不代表本批十个宽提案的全部职责已实现，不用诊断绿或旧宿主检查替代本批策略验证。

{ledger_status}

## 提交、测试、合入及后续

源码/知识提交：无。撤源码预期失败及恢复通过：不适用。tsc/vitest/cases：未运行，均null。没有代码提交，所以不制造沙箱测试或gitleaks“提交前通过”；没有live合入，未写上线decision-log、eval版本、规则双通知或shipped。已有live源码只作子项依据，merged仍null，不借用其提交或版本冒本批交付。

经验入库、大脑采用、自然收益均未由本批验证。没有科学结论改写、机制反证或新增冲突需要另造通知；已有同局复盘和提案保留，不重复追加历史复盘或独立样本。具体等待原因逐项如下；未来新证据沿原十id接续，由宿主消费最终结果，不关闭宽父要求。

```json
{json.dumps(result, ensure_ascii=False, indent=2)}
```
'''
    (OUT / 'report.md').write_text(report)
    print('report:', OUT / 'report.md')


if __name__ == '__main__':
    main()

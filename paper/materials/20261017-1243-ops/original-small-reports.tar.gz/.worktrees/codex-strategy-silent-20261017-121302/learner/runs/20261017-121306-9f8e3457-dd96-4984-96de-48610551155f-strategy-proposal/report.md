# 本批策略提案核验报告

2026-10-17 12:24:16 CST；`20261017-121302-strategy-proposal`；silent。

本轮十项均 waiting：局部事实得到复核，缺口仍是完整执行归属、逐来源校准及受控后继。未新增策略源码/知识、提交、合入、行为版本或shipped登记。`base=d05663b5ce6ef27475c84e3dfb0f3dcae55bee2c`，`fixes=[]`、`merged=null`、生产测试均null。

## 身份与范围

根learn.json对应batch的task/character/worktree/六个runs及十proposal_ids已核，reason=proposal；没有research_request、implementation_request、proposal_repair。普通专题文件仍绑定20261010另一批，本批不读取其work_spec或冒作研究完成。原派发冻结 `dispatch.json`；每项原文SHA均匹配，队列734条所属物理行的offset/bytes/SHA保存在 `queue-selected-physical.json`。未领取其他id，也未以普通批次完成专题父请求。

初始及合main后HEAD均为完整base，merge输出Already up to date，工作树干净。六局runs.jsonl均SILENT/A10，局号顺序见最终JSON；各历史code带dirty，不重建或冒认其完整运行树。只读本角色证据与本批关联账本；不搬其他角色知识。

当前工具没有此线程的原生模型/effort回执可读，现有本批out/err未提供可核字段；未将README默认配置冒称实际请求或会话已切换，也未改模型配置。没有派下级agent。

## 原始证据与截点

使用指定共用 `learner/extract_evidence.py`，一次提取六局八流。每流保存source_size、按局计数、每行原offset/bytes/SHA及输出摘要；源文件只读。摘要如下，完整每局计数见 `evidence/evidence-manifest.json`。

| 流 | source_size（字节） | 本批封套数 | 全流坏行数 |
| --- | --- | --- | --- |
| states | 13853951337 | 4167 | 2 |
| decisions | 2199663114 | 4071 | 2 |
| sl-attempts | 45087235 | 43 | 0 |
| run-config | 1933815 | 6 | 0 |
| run-plans | 8841929 | 21 | 0 |
| brain | 732394150 | 130 | 2 |
| runs | 355966 | 6 | 0 |
| fight-plans | 2233957 | 0 | 0 |

共8444条封套、4167状态帧、763个观察回合窗口；均为本批六个独立局中的相关SL与后继，不是763次独立策略实验。states/decisions/brain各2坏行不能可靠归属本批，不把其算缺失局证据；fight-plans在该截点0行只说明未选中，不断言源流不存在。没有覆盖旧零行报告；`projection-summary.initial.json`保留提取尚未结束时的范围说明，最终摘要已核manifest存在。

`state-projections.json`、`turn-windows.json`及`decision-projections.json`是有界字段投影，所有原字节封套仍保留。`validation.json`最终49项材料/算术核验通过、0失败，84条限定引用按原文件offset/bytes/SHA及显式run身份读回。八流输出摘要与封套数一致；这不是生产消费者执行、重放模拟或tsc/vitest通过。

首版材料脚本37过2败：错误地将下一回合已重新抽牌的手中呼唤数量预期为0，实际280692为2、280709为1。已按实际手牌更正，只用上一轮末帧认证持牌、下一轮入口认证净HP差；原脚本、validation.initial.json及stdout均保留，不改游戏原件、不把分析脚本误期望当机制反例。一次apply_patch因并行工作树`.codex`路径消失触发沙箱glob扫描失败；同范围相对路径重试成功，未扩权限，不作产品失败。一次只读rg使用不存在的agent/src/loop.ts，随后改按实际reflex入口核验；无代码修改。

## 结论、源码边界及逐项结果

完整证据、层/回合、既有账本id、反向取舍、已存在源码实际live祖先、等待条件、未来验证与回退在 [proposal.md](proposal.md)。尤其保留：751多输出付血与T13省血少输出；KEN省血却延迟敏捷；PU多因素胜线不能证明统一禁止付血探索；巨兽毒层不等于减自爆；KV净血差不等于毛伤；药水用掉/实际收益/留药价值分别核。没有足够证据确定新的游戏参数或通关因果，保留现行规则。

`source-audit.json`与`source-vs-live.patch`限定核12叶、10叶同字节/2叶仅历史注释署名差、12个last_commit均为该live祖先。只证明已有子项在该快照存在，不代表本批十个宽提案的全部职责已实现，不用诊断绿或旧宿主检查替代本批策略验证。

根CLI追溯已完成；机械读回：
```json
{
  "cli_exit_code": 0,
  "items": 16,
  "own_appended_rows": 16,
  "old_prefix_bytes": 22586619,
  "old_prefix_sha256": "b0d431ee1e2f199b2bb229146cc87a1b211a9f8677976f9850b6666b5e8688e7",
  "old_prefix_unchanged": true,
  "protected_fold_fields_unchanged": true,
  "only_where_note_and_history_added": true,
  "statuses_preserved": true,
  "no_evidence_support_repeat_added": true,
  "report_links_read_back": true
}
```

## 提交、测试、合入及后续

源码/知识提交：无。撤源码预期失败及恢复通过：不适用。tsc/vitest/cases：未运行，均null。没有代码提交，所以不制造沙箱测试或gitleaks“提交前通过”；没有live合入，未写上线decision-log、eval版本、规则双通知或shipped。已有live源码只作子项依据，merged仍null，不借用其提交或版本冒本批交付。

经验入库、大脑采用、自然收益均未由本批验证。没有科学结论改写、机制反证或新增冲突需要另造通知；已有同局复盘和提案保留，不重复追加历史复盘或独立样本。具体等待原因逐项如下；未来新证据沿原十id接续，由宿主消费最终结果，不关闭宽父要求。

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261017-121302-strategy-proposal",
  "base": "d05663b5ce6ef27475c84e3dfb0f3dcae55bee2c",
  "runs": [
    "751FN9QM9MHQ",
    "KV0JHNJCKXLS",
    "YQL8RZ8BWN1E",
    "L9SGRBB5R698",
    "PU80F84P6HPN",
    "KEN58SH9SLZ6"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-366288801d9150d9",
    "silent-proposal-85929bdfc8a3fc1b",
    "silent-proposal-efd9f83ee9e1a6dc",
    "silent-proposal-131042659448ae74",
    "silent-proposal-990f054036609447",
    "silent-proposal-e18d3f18e6cac2a0",
    "silent-proposal-9733bb80f445aeae",
    "silent-proposal-c51468c5e8ba6668",
    "silent-proposal-86a7db08d1a31976",
    "silent-proposal-e282a9131b99129a"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-366288801d9150d9",
      "state": "waiting",
      "reason": "751 F17 T2/T7/T13同题端点已核；现有SL原/替线预测及配对B2记录不等于抽弃重问后完整候选的实际归属。缺逐来源实结算、受控整战后继与独立验证，不拟5/10血准入门槛。"
    },
    {
      "id": "silent-proposal-85929bdfc8a3fc1b",
      "state": "waiting",
      "reason": "751 F13 T3用药/整战无药模型均损8，持有价未知与未决弃牌提示已有；缺实际无药完整分支、留药后战对照及逐来源损血认证，不能从空药Boss败局定留药价或改弃牌。"
    },
    {
      "id": "silent-proposal-efd9f83ee9e1a6dc",
      "state": "waiting",
      "reason": "与366288共享751同一六试，不增加独立样本。现有资源预测不能认证完整执行、真实持牌成本或受控胜因，缺整战后继与留后新局验证。"
    },
    {
      "id": "silent-proposal-131042659448ae74",
      "state": "waiting",
      "reason": "已核敏捷建立、持牌失血、毒/荆棘局部状态及未知药价；缺这些机制的联合逐来源实际校准、完整候选归属及跨战用药对照，不能用已有单项提示关闭整包。"
    },
    {
      "id": "silent-proposal-990f054036609447",
      "state": "waiting",
      "reason": "KV F33第4/5试T5均零净损，净扣敌36/29、次轮毒20/13；末试327→342含毒结算与回血。缺逐来源毛伤/回血归属、保持后轮条件的整战比较及路线/休息替代后继，删输出没有已证保血收益。"
    },
    {
      "id": "silent-proposal-e18d3f18e6cac2a0",
      "state": "waiting",
      "reason": "三个巨兽局的占位血与YQL毒2→8而自爆41已核，现有阶段/残壳提示与旧排序并存；缺改排序、提前喝/不喝/留药的受控完整后继，PU胜线同时有其他变化，不能据占位血统一归零证明新排序更优。"
    },
    {
      "id": "silent-proposal-9733bb80f445aeae",
      "state": "waiting",
      "reason": "与e18d3f18共享巨兽三局；阶段及残壳用毒事实已有窄实现，缺阶段估值、参考路径排序与用药时点的受控整战比较，不能把PU过爆余2当本提案整包完成。"
    },
    {
      "id": "silent-proposal-c51468c5e8ba6668",
      "state": "waiting",
      "reason": "KEN七次use_potion指令与逐槽耗药端点均核，三次回执pending须连选牌/续问核效果。缺随机选牌后完整候选收益归属、同题不饮用及留至Boss的完整对照，空药栏失败不能拟合持有价。"
    },
    {
      "id": "silent-proposal-86a7db08d1a31976",
      "state": "waiting",
      "reason": "KEN F17 T10多6血仅多2伤、T5省2血但步法延至T9均核；缺逐来源兑现、完整候选认证、保持后轮条件的整战对照和独立验证，不设6血/2伤通用门槛或关闭更差线探索。"
    },
    {
      "id": "silent-proposal-e282a9131b99129a",
      "state": "waiting",
      "reason": "与86a7db08共享KEN同一六试，不能重复计样本。血价/无实体/能力窗口只有局部配对与已有预测，缺完整执行归属、受控整战后继和独立验证，保留现排序与护栏。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-121302/learner/runs/20261017-121306-9f8e3457-dd96-4984-96de-48610551155f-strategy-proposal/report.md"
}
```

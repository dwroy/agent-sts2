import hashlib
import json
from collections import defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent


def powers(raw):
    return {p.get('power_id'): p.get('amount') for p in raw or []}


def reference(ev):
    return {k: ev[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def project(ev):
    row = ev['row']
    st = row.get('state', row)
    run = st.get('run') or {}
    combat = st.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **reference(ev), 'ts': row.get('ts'), 'floor': run.get('floor'),
        'turn': st.get('turn'), 'screen': st.get('screen'), 'in_combat': st.get('in_combat'),
        'hp': player.get('current_hp', run.get('current_hp')),
        'max_hp': player.get('max_hp', run.get('max_hp')),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player.get('powers')),
        'hand': [{'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                  'text': c.get('resolved_rules_text'),
                  'values': {v.get('name'): v.get('current_value') for v in c.get('dynamic_values', [])}}
                 for c in combat.get('hand', [])],
        'enemies': [{'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                     'alive': e.get('is_alive'), 'move': e.get('move_id'),
                     'intents': e.get('intents'), 'powers': powers(e.get('powers'))}
                    for e in combat.get('enemies', [])],
        'potions': [{'slot': p.get('index', i), 'id': p.get('potion_id'), 'occupied': p.get('occupied')}
                    for i, p in enumerate(run.get('potions', []))],
        'selection': st.get('selection'),
    }


def main():
    frames = []
    skipped_partial = 0
    with (OUT / 'evidence/states.evidence.jsonl').open() as handle:
        for raw in handle:
            try:
                ev = json.loads(raw)
            except ValueError:
                skipped_partial += 1
                continue
            frames.append(project(ev))
    (OUT / 'state-projections.json').write_text(json.dumps(frames, ensure_ascii=False, indent=2) + '\n')
    turns = {}
    latest = {}
    attempts = defaultdict(lambda: 1)
    for frame in frames:
        if not frame['in_combat'] or not frame['enemies'] or not isinstance(frame['turn'], int) or frame['turn'] <= 0:
            continue
        key = (frame['run_id'], frame['floor'])
        if key in latest and frame['turn'] < latest[key]:
            attempts[key] += 1
        latest[key] = frame['turn']
        turnkey = (*key, attempts[key], frame['turn'])
        if turnkey not in turns:
            turns[turnkey] = {'run': key[0], 'floor': key[1], 'attempt': attempts[key],
                             'turn': frame['turn'], 'entry': frame, 'last': frame, 'frames': []}
        turns[turnkey]['last'] = frame
        turns[turnkey]['frames'].append(frame['line'])
    windows = list(turns.values())
    (OUT / 'turn-windows.json').write_text(json.dumps(windows, ensure_ascii=False, indent=2) + '\n')
    summary = {'state_frames': len(frames), 'turn_windows': len(windows),
               'skipped_partial_envelopes': skipped_partial,
               'per_run': {r: sum(f['run_id'] == r for f in frames) for r in sorted({f['run_id'] for f in frames})},
               'complete_extraction_manifest_present': (OUT / 'evidence/evidence-manifest.json').is_file()}
    (OUT / 'projection-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()

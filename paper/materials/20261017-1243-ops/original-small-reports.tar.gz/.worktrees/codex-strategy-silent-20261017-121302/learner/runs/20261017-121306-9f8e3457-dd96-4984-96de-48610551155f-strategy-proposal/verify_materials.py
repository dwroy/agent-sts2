import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extractor', WORK / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
checks = []
refs = {}


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


def keep(frame):
    refs[(frame['source'], frame['offset'])] = {
        k: frame[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')
    }


def main():
    frames = {f['line']: f for f in json.loads((OUT / 'state-projections.json').read_text())}
    windows = {(w['run'], w['floor'], w['attempt'], w['turn']): w
               for w in json.loads((OUT / 'turn-windows.json').read_text())}
    decisions = {d['line']: d for d in json.loads((OUT / 'decision-projections.json').read_text())}
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    stream_checks = []
    for stream in manifest:
        path = OUT / 'evidence' / (stream['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        lines = 0
        with path.open('rb') as handle:
            for raw in handle:
                digest.update(raw)
                lines += 1
        stream_checks.append({'stream': stream['stream'], 'count': lines,
                              'sha256_matches': digest.hexdigest() == stream['output_sha256'],
                              'count_matches': lines == sum(stream['counts'].values())})
    check('八流封套计数与提取哈希', all(x['sha256_matches'] and x['count_matches'] for x in stream_checks), True)
    for a, b in [(272434, 272575), (272531, 272652), (272483, 272820),
                 (274505, 274568), (274484, 274601), (273400, 273450)]:
        keep(decisions[a]); keep(decisions[b])
        check(f'题面指纹相同 {a}/{b}', decisions[a]['fingerprint'] == decisions[b]['fingerprint'], True)
    for run, floor, turn, aa, bb, expected in [
        ('751FN9QM9MHQ', 17, 2, 1, 3, [[9, 13], [18, 18]]),
        ('751FN9QM9MHQ', 17, 7, 2, 4, [[12, 13], [18, 23]]),
        ('751FN9QM9MHQ', 17, 13, 1, 6, [[17, 8], [11, 2]]),
        ('KEN58SH9SLZ6', 17, 10, 4, 5, [[2, 15], [4, 21]]),
        ('KEN58SH9SLZ6', 17, 5, 4, 6, [[1, 7], [2, 5]]),
        ('KV0JHNJCKXLS', 33, 5, 4, 5, [[36, 0], [29, 0]]),
    ]:
        actual = []
        for attempt in (aa, bb):
            first = windows[(run, floor, attempt, turn)]['entry']
            following = windows[(run, floor, attempt, turn + 1)]['entry']
            keep(first); keep(following)
            actual.append([first['enemies'][0]['hp'] - following['enemies'][0]['hp'], first['hp'] - following['hp']])
        check(f'{run} F{floor} T{turn} 净扣敌血/玩家净损两端', actual, expected)
    for before, after, slot, potion, floor, turn in [
        (280206, 280207, 0, 'ATTACK_POTION', 3, 2),
        (280232, 280233, 0, 'STABLE_SERUM', 4, 1),
        (280262, 280263, 0, 'SPEED_POTION', 5, 2),
        (280313, 280314, 1, 'WEAK_POTION', 11, 1),
        (280315, 280316, 0, 'ATTACK_POTION', 11, 2),
        (280348, 280349, 1, 'GLOWWATER_POTION', 15, 1),
        (280354, 280355, 0, 'SKILL_POTION', 15, 1),
    ]:
        a, b = frames[before], frames[after]
        keep(a); keep(b)
        check(f'耗药槽位 {before}/{after}',
              [a['run_id'], a['floor'], a['turn'], a['potions'][slot]['id'],
               a['potions'][slot]['occupied'], b['potions'][slot]['occupied']],
              ['KEN58SH9SLZ6', floor, turn, potion, True, False])
    a, b = frames[280160], frames[280161]
    keep(a); keep(b)
    check('残壳饮毒水局部观测',
          [[v['hp'], v['block'], v['enemies'][0]['hp'], v['enemies'][0]['powers']['POISON_POWER'],
            v['enemies'][0]['intents'][0]['total_damage']] for v in (a, b)],
          [[26, 13, 999999999, 2, 41], [26, 13, 999999999, 8, 41]])
    # The next turn's hand already contains its new draw; it is not the previous end-turn hand.
    for line, expected in [(280691, [61, 0, 1]), (280692, [55, 0, 2]),
                           (280708, [33, 7, 1]), (280709, [19, 0, 1]),
                           (280717, [19, 7, 0]), (280718, [6, 0, 2])]:
        f = frames[line]; keep(f)
        check(f'持牌与血挡帧 {line}', [f['hp'], f['block'], sum(c['id'] == 'BECKON' for c in f['hand'])], expected)
    for line, expected in [(280700, [10, 0]), (280704, [0, 2])]:
        f = frames[line]; keep(f)
        check(f'步法兑现时点 {line}', [f['block'], f['powers'].get('DEXTERITY_POWER', 0)], expected)
    for line, expected in [(279559, 327), (279560, 342)]:
        f = frames[line]; keep(f)
        check(f'知识恶魔回血端点 {line}', f['enemies'][0]['hp'], expected)
    a, b = frames[252435], frames[252436]
    keep(a); keep(b)
    check('PU实际过爆端点', [a['hp'], a['block'], a['enemies'][0]['intents'][0]['total_damage'], b['hp'], b['screen']],
          [24, 20, 42, 2, 'REWARD'])
    for attempt in range(1, 7):
        f = windows[('KEN58SH9SLZ6', 17, attempt, 1)]['entry']; keep(f)
        check(f'KEN第{attempt}次Boss入口', [f['hp'], f['max_hp'], sum(p['occupied'] is True for p in f['potions'])], [75, 86, 0])
    selected = {ev['line']: ev for ev in json.loads((OUT / 'selected-decisions.json').read_text())}
    for line in (274131, 274156, 274185, 274235, 274237, 274267, 274272):
        keep(selected[line])
        check(f'实际饮药指令 {line}', selected[line]['row']['chosen']['action'], 'use_potion')
    d = decisions[272361]
    keep(d)
    check('F13同题用药与整战无药参考',
          [[d['options'][k]['hp_lost'], d['options'][k]['damage_dealt']] for k in ('plan2', 'plan5')],
          [[8, 26], [8, 16]])
    check('整战无药参考单列', 'no_potion_fight' in d['options']['plan5'], True)
    check('KEN T10配对B2日志值', decisions[274568]['sl_explore']['b2'],
          {'original': 0.385, 'replacement': 0.127, 'diff': -0.2583, 'se': 0.0132})
    attempts = []
    for raw in (OUT / 'evidence/sl-attempts.evidence.jsonl').open():
        ev = json.loads(raw)
        r = ev['row']
        if ev['line'] not in {681, 717, 960, 961, 962, 963}:
            continue
        keep(ev)
        anchor = ((r.get('explore') or {}).get('target') or {}).get('anchor')
        attempts.append({'line': ev['line'], 'run': ev['run_id'], 'attempt': r.get('attempt'),
                         'result': r.get('result'), 'turns': r.get('turns'), 'anchor': anchor})
    verified = []
    for ref in refs.values():
        with Path(ref['source']).open('rb') as handle:
            handle.seek(ref['offset'])
            raw = handle.read(ref['bytes'])
        good = len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256']
        good = good and extractor.run_identity(json.loads(raw)) == ref['run_id']
        verified.append({**ref, 'verified': good})
    check('限定引用原日志offset/bytes/SHA/所属局读回', all(r['verified'] for r in verified), True)
    result = {'kind': '材料与算术核验，未执行生产消费者或模拟，不是tsc/vitest',
              'checks': checks, 'passed': sum(c['passed'] for c in checks),
              'failed': sum(not c['passed'] for c in checks),
              'stream_checks': stream_checks, 'raw_references': verified, 'anchor_observations': attempts}
    (OUT / 'validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': result['passed'], 'failed': result['failed'], 'raw_references': len(verified)}, ensure_ascii=False))
    for c in checks:
        if not c['passed']:
            print(json.dumps(c, ensure_ascii=False))
    return 1 if result['failed'] else 0


if __name__ == '__main__':
    raise SystemExit(main())

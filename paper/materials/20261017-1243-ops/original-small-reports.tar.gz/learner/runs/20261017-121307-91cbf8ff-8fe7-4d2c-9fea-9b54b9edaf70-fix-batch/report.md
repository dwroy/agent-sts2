## 修 bug 回报

- 合并基线：main → d05663b5ce6ef27475c84e3dfb0f3dcae55bee2c
- 修复（每条一行）：无；本批未新增代码或提交。
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb
- 已被别人修掉的：核心通知失败日志 — 5c92f2aaf0
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb6
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7
- 已被别人修掉的：空产出补链误派 — 84366ad06e
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612b
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a8
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29
- 已被别人修掉的：纸鹤夹具 — befc39e5ca
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e
- 已被别人修掉的：共享main启动冲突 — 22efae5548
- 已被别人修掉的：根事件通知路径 — 577f0bc424
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe
- 已被别人修掉的：局间quiet误报 — 21a9c52484
- 已被别人修掉的：global-health异步测试 — d27df54f06
- 已被别人修掉的：target-options固定预算 — 83a7f796c2
- 已被别人修掉的：retention数字UUID — d91236326b
- 已被别人修掉的：retention旧根scratch — 0699b05c43
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d7
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ce
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a51
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57cea
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8ba
- 已被别人修掉的：eval校准遍历线上发布表 — d8748f2e70
- 已被别人修掉的：potions-jev-call固定forecast时钟 — c5fd30d8d3
- 已被别人修掉的：target-options默认EZ2L固定时钟 — c57105ca66
- 已被别人修掉的：rollout-ties固定夹具 — da08fcead2
- 已被别人修掉的：build-facts整场回执固定夹具 — e2c1d8a2d2
- 已被别人修掉的：h1-budget-completion-health-contract — c40e43fd25
- 没修的：selection-hidden-daggers-conditional-followup-readback（silent-0499/0205） — 原提案59b2e430bb7521d4明确交独立strategy-proposal；仍pending，未查到对应proposal_ids派发批次，本批未领取或实现。
- 没修的：出牌、药水、SL、终局、路线及角色机制条目 — 策略类，沿既有strategy-proposal链；含0256/0260/0263/0266/0271/0272/0279/0308/0311/0317/0319/0320/0322/0324/0329/0334/0338/0339/0344/0347/0349/0362/0365/0367/0461/0481/0487/0496等，未补游戏知识。
- 没修的：silent-0332实际资源契约异常根因 — 证据不足，原H0/0332专用owner持续接续；不以诊断接线当根修复，不改正HP与样本门槛。
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；当前已有严格错误分类、有限重试、租约屏障及retention窄修复，仍不能确定历史删除者、上游扫描或整体容量根因。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression、调度公平性及具名卡全入口宽项 — 独立架构、策略或归因任务，超出普通纯bug批次；已发布入口不重复实现。
- 没修的：core-build-notify-222802-rc2旧原生通知恢复 — 证据不足；旧失败缺stderr，无法确认未送达，本批未重发通知。
- 没修的：Codex缓存实测、DPR/B2性能及历史宿主超时根因 — 证据不足或独立性能任务；不调用真实模型，不将固定夹具修复或定向绿色当作产品性能根因闭环。
- 测试：tsc 退出码 0；定向 vitest 6 文件 / 82 用例 / 退出码 0；Python 9 项通过；均首轮通过。未改代码，未重跑全套。
- 合入：未合入（无新增提交；35 项既有修复均已在 main/live）。
- 需要 Roy 定的事：无

```json
{
  "task": "fix-batch",
  "base": "d05663b5ce6ef27475c84e3dfb0f3dcae55bee2c",
  "fixes": [],
  "skipped": [
    {
      "item": "selection-hidden-daggers-conditional-followup-readback（silent-0499/0205）",
      "reason": "原提案59b2e430bb7521d4明确交独立strategy-proposal；仍pending，未查到对应proposal_ids派发批次，本批未领取或实现。"
    },
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目",
      "reason": "策略类，沿既有strategy-proposal链；含0256/0260/0263/0266/0271/0272/0279/0308/0311/0317/0319/0320/0322/0324/0329/0334/0338/0339/0344/0347/0349/0362/0365/0367/0461/0481/0487/0496等，未补游戏知识。"
    },
    {
      "item": "silent-0332实际资源契约异常根因",
      "reason": "证据不足，原H0/0332专用owner持续接续；不以诊断接线当根修复，不改正HP与样本门槛。"
    },
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；当前已有严格错误分类、有限重试、租约屏障及retention窄修复，仍不能确定历史删除者、上游扫描或整体容量根因。"
    },
    {
      "item": "arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression、调度公平性及具名卡全入口宽项",
      "reason": "独立架构、策略或归因任务，超出普通纯bug批次；已发布入口不重复实现。"
    },
    {
      "item": "core-build-notify-222802-rc2旧原生通知恢复",
      "reason": "证据不足；旧失败缺stderr，无法确认未送达，本批未重发通知。"
    },
    {
      "item": "Codex缓存实测、DPR/B2性能及历史宿主超时根因",
      "reason": "证据不足或独立性能任务；不调用真实模型，不将固定夹具修复或定向绿色当作产品性能根因闭环。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 82
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261017-121307-91cbf8ff-8fe7-4d2c-9fea-9b54b9edaf70-fix-batch/report.md"
}
```

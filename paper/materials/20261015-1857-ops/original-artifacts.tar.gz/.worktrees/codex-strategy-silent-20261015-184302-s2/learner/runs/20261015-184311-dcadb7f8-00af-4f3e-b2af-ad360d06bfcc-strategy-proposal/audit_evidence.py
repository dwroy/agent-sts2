"""Read only the assigned Silent evidence and preserve bounded audit facts."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("extract", HERE.parents[1] / "extract_evidence.py")
EXTRACT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXTRACT)
IDENTITIES = json.loads((HERE / "run-identities.json").read_text())


def powers(value):
    return {p["power_id"]: p.get("amount") for p in value or []}


def compact(item):
    row = item["row"]
    state = row["state"]
    run = state["run"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": item["line"], "offset": item["offset"], "sha256": item["sha256"],
        "run_id": item["run_id"], "ts": row["ts"], "observed_ts": row.get("observed_ts"),
        "floor": run["floor"], "turn": state.get("turn"), "in_combat": state["in_combat"],
        "screen": state["screen"], "hp": run["current_hp"], "max_hp": run["max_hp"],
        "block": player.get("block"), "energy": player.get("energy"),
        "powers": powers(player.get("powers")), "readiness": combat.get("action_readiness"),
        "lethal": combat.get("end_turn_will_kill_player"),
        "hand": [{"id": c["card_id"], "index": c["index"], "upgraded": c.get("upgraded"),
                  "text": c.get("resolved_rules_text"), "cost": c.get("energy_cost")} for c in combat.get("hand", [])],
        "enemies": [{"id": e["enemy_id"], "index": e["index"], "hp": e["current_hp"],
                     "block": e.get("block"), "alive": e.get("is_alive"),
                     "powers": powers(e.get("powers")), "intents": e.get("intents")} for e in combat.get("enemies", [])],
        "potions": run.get("potions"),
    }


def main():
    manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
    results = []
    states = collections.defaultdict(list)
    decisions = []
    for stream in manifest:
        name = stream["stream"]
        counts = collections.Counter()
        digest = hashlib.sha256()
        with (HERE / "evidence" / (name + ".evidence.jsonl")).open("rb") as selected:
            source_path = Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")
            with source_path.open("rb") as source:
                for raw in selected:
                    digest.update(raw)
                    item = json.loads(raw)
                    source.seek(item["offset"])
                    original = source.read(item["bytes"])
                    assert hashlib.sha256(original).hexdigest() == item["sha256"]
                    assert json.loads(original) == item["row"]
                    assert EXTRACT.run_identity(item["row"]) == item["run_id"]
                    assert item["run_id"] in IDENTITIES
                    counts[item["run_id"]] += 1
                    if name == "states":
                        run = item["row"]["state"]["run"]
                        assert run["character_id"].upper() == "SILENT"
                        assert run["ascension"] == IDENTITIES[item["run_id"]]["ascension"]
                        states[item["run_id"]].append(compact(item))
                    elif name == "decisions":
                        decisions.append(item)
        assert digest.hexdigest() == stream["output_sha256"]
        assert all(counts[run] == count for run, count in stream["counts"].items())
        results.append({"stream": name, "count": sum(counts.values()), "by_run": dict(counts),
                        "source_size": stream["source_size"], "byte_identity_verified": True})

    transitions = []
    for run_id, frames in states.items():
        for before, after in zip(frames, frames[1:]):
            if (before["floor"], after["floor"]) in [(17, 18), (33, 34)]:
                if before["max_hp"] != after["max_hp"]:
                    continue
                expected = (after["max_hp"] - before["hp"]) * 4 // 5
                transitions.append({"run_id": run_id, "ascension": IDENTITIES[run_id]["ascension"],
                                    "before": before, "after": after,
                                    "actual": after["hp"] - before["hp"], "formula": expected,
                                    "matches": after["hp"] - before["hp"] == expected})

    windows = {
        "RC61MFQM63Y6": {17: {2, 11}, 23: {3, 4}, 29: {3, 4}, 33: {4}},
        "XTSV1U9JD34T": {48: {8}, 49: {1, 3, 4}},
        "BTSRF7JL1W1Y": {17: {5}, 30: None, 31: {2, 3}},
        "9Z9H2EXKLF3T": {35: None, 38: None, 39: None, 42: None, 45: None, 47: None, 48: {8, 10, 11}},
        "7X0W3U8TVA2A": {30: None, 31: {1, 13}},
        "MTQ0EUBJ3R6T": {19: None, 20: None, 23: {3, 5, 6}},
    }
    selected = {}
    for run_id, floors in windows.items():
        selected[run_id] = [s for s in states[run_id] if s["floor"] in floors and
                            (floors[s["floor"]] is None or s["turn"] in floors[s["floor"]])]
    endpoints = {}
    for run_id, frames in states.items():
        by_floor = collections.defaultdict(list)
        for frame in frames:
            by_floor[frame["floor"]].append(frame)
        endpoints[run_id] = {str(f): {"first": group[0], "last": group[-1]} for f, group in by_floor.items()}
    for name, value in [("evidence-audit.json", results), ("transition-pairs.json", transitions),
                        ("state-windows.json", selected), ("floor-endpoints.json", endpoints)]:
        (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    decision_lines = {279117, 279846, 280547, 280550, 280631, 280635, 280636, 280637,
                      280638, 280639, 281953, 282021, 282434}
    with (HERE / "decision-windows.jsonl").open("w") as handle:
        for item in decisions:
            if item["line"] in decision_lines:
                handle.write(json.dumps(item, ensure_ascii=False) + "\n")
    print(json.dumps({"streams": results, "transitions": len(transitions),
                      "transition_matches": sum(t["matches"] for t in transitions),
                      "state_windows": {k: len(v) for k, v in selected.items()}}, ensure_ascii=False))


if __name__ == "__main__":
    main()

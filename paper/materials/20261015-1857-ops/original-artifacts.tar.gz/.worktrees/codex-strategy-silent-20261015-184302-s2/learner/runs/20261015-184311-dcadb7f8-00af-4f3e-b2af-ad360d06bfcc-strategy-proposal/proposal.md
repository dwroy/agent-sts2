# 本批十项策略提案核验与处置

批次：20261015-184302-s2-strategy-proposal；角色：silent；完整基线：`cc29ccb63ffa1f36c0dd7c17316e8ef013fd8622`。

本批是普通专用队列消费。learn.json只有本批十个proposal_ids，未绑定research_request、implementation_request或proposal_repair；普通专题文件绑定另一批，因此不套用专题。git status初始干净，git merge --no-edit main返回Already up to date。未领取其他ID、未派下级agent。

所有十项均waiting。已有窄子项的实际live源码祖先如实列出，不把宽提案整体标duplicate/implemented。本批没有足够新增证据支持策略改动，源码、知识、规则与铁甲行为未改；没有新代码提案ID或shipped登记。

原提案十份Markdown已逐份核SHA并原字节复制到本scratch；见original-proposals-manifest.json。现有账本保留首证、prior、claim、证据、status和version，仅通过根ledger CLI追加本批追溯链接。

## 证据范围和方法

语义分析有界于十份原提案列出的关键窗口、关联资源节点及22对跨幕状态。22,424行是所属身份和原字节核验数量，不能作为逐行完整语义研究、候选完整执行认证或全历史校准的分母。

只使用十五个提案所属Silent局；其中三局A9（HMVJKM56S4Q8/F4QKG4J1AJJZ/G403VCZ3BH1B），其余十二局A10。批次runs仍只填十个派发锚点，额外五局只来自已领取提案的runs。历史runs含DeepSeek调用字段，不能把这组局冒称全部纯Codex，也不能当当前V5自然验收。所有旧code均带dirty，完整历史树未知。

共用extract_evidence.py提取八流，逐条身份解析包括run-plans.run和fingerprint.run，冲突身份拒收；原字节offset/bytes/SHA、source_size、计数和输出SHA均保存。已重读原文件逐条核JSON/字节/身份，states另核character/ascension。当前选中22,424行；2条states、2条decisions、1条brain原流无效JSON被抽取器跳过，不能据此判断其归属。fight-plans在本次2,233,957字节截点选中0行，只说明本截点没有选到所属记录。run-plans有97条，不将正文提及当所属局。

固定材料26项数字核验通过，包括逐牌挡量、临时属性、弃牌、幽灵一层、复制死亡前未兑现、7毒及8血换6伤。另有22对跨幕公式核对。此为材料核验，不是生产自测、完整候选校准、自然采用或收益。无自由参数拟合；不把本局同时作为训练与独立验证，同局SL不增加独立局数。

## 1. silent-proposal-03754e1265894000

牌挡敏捷/脆弱/柔嫩逐张核；折扇被动挡、触发时点与持有能力分源

- 来源：experience-update → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-mechanisms.md`；SHA256：`518c139723decc4238c7ea5641e671c8738ec240118ff5140ca503612295599f`。
- 账本：silent-0006, silent-0011, silent-0013, silent-0080, silent-0088, silent-0101, silent-0232, silent-0253。
- 证据：RC61MFQM63Y6 A10 F23T3/4、F29T3/4；states285222—285230、285280—285292。
- 现有实现/旧行为：当前card-model/turn-solver已有属性、折扇及九层幻影入口；升级预判来源d91f9600286a67480b5044e019dbb1041e2239af为base/live祖先。本批未产生新的确定错排复现。
- 处置：waiting。RC61MFQM63Y6 F23T3/4核得净敏1→6、斗篷12/防御9及末小刀0直伤+4挡；已有局部模型，但未定位当前消费者新的确定错排，缺组合逐项预测误差与改药时完整后继，不能整体duplicate或调排序/持有价。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。补齐同角色已观察组合的逐项预测/实际、完整候选执行链与独立留出；定位确定当前差异才做固定回归。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 2. silent-proposal-e5ea36df117ca9b7

核接管首轮与自主启动的事实边界；已有明确实现则duplicate，未记录自动过程保持未知，不由一败禁取遗物。

- 来源：postmortem → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-controlled-opening.md`；SHA256：`a305a121a184c84264ac5434fddaaeb75941c0a96a350abda85418824725c9ea`。
- 账本：silent-0164。
- 证据：XTSV1U9JD34T A10 F49T1；states286896—286899；原提案F34/F36/F49，接管过程缺帧。
- 现有实现/旧行为：combat-plan.ts:2874从当前combat.hand建模，不能重排已完成接管。仅代码入口存在不证明预战或构筑所有消费者都正确，不能据此整体duplicate。
- 处置：waiting。XTSV1U9JD34T F49T1首可行动帧仅进阶之灾、3能量/16挡；接管内部动作/抽序及同条件自主开局未记录。当前战斗入口读实际手牌，未核到误称自主启动的当前具体题面；不足以模拟接管、禁取遗物或整体duplicate。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。需要可记录的接管内部动作及抽序，或当前具体消费者错误事实的原题字节；不得推演未知自动顺序。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 3. silent-proposal-ab055ef7dfbb44e5

验证夜魇收益的存活兑现条件，并只建模本局已观察的幽灵一层无实体；延后饮用整场效果不足，保留旧时点与药价规则。

- 来源：postmortem → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-survival-and-ghost.md`；SHA256：`c5490a44836c3900e1d03b59370dea8c076a8b5435236f7a5e575e4c0b516b17`。
- 账本：silent-0140, silent-0069, silent-0005, silent-0206。
- 证据：XTSV1U9JD34T A10 F49T1/T3/T4；states286897—286899、286978—286987；decision280550。
- 现有实现/旧行为：96f17377a331e50ea5b6a3fe8d2b605932ed1bd4单层幽灵对比入口；当前Silent A10且无已有无实体层才传observedGhostInAJar，自动喝药分支排除此新增对比。不外推延后时点。
- 处置：waiting。单层幽灵窄实现96f17377a331e50ea5b6a3fe8d2b605932ed1bd4确为live祖先；XTSV1U9JD34T六试均T1饮，末试T4建3复制后仍死亡。缺延后饮用、既有层叠加、复制存活兑现的可比完整后继与独立持有价，不关闭整项。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。需要同条件延后用药、复制实际到手并可执行的后继，以及药水机会成本证据；固定夹具核边界，不能以模拟赢线代实战。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 4. silent-proposal-0129c465c6f5bd79

强制弃牌后候选重核、毒胜保血候选及夜魇/接管首轮兑现边界

- 来源：experience-update → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-replay.md`；SHA256：`bf425049a5868e3bec28ff845f0dcc2f5560594b3b85b4380a378ab2295bdcdc`。
- 账本：silent-0009, silent-0021, silent-0024, silent-0057, silent-0079, silent-0090, silent-0140, silent-0164, silent-0205, silent-0268, silent-0271。
- 证据：BTSRF7JL1W1Y A10 F31T2/3；states286158—286163、decision279846；XTSV1U9JD34T F48T8/F49T1，states286893—286896、decision280547。
- 现有实现/旧行为：bf423c173d3be348a4ad714e1d26516df619ff41（普通生存者无绷带单弃）；222445a9bb6bf56cb4f3ceea2cc8b20fba54128f（观察到的连王前毒胜保血扩展）；2e6fa2e5c68be70efb2ee87bee58f2cb3128bfb2（毒胜前持牌伤）。均为实际live祖先。
- 处置：waiting。生存者单弃bf423c173d3be348a4ad714e1d26516df619ff41与毒胜保血搜索222445a9bb6bf56cb4f3ceea2cc8b20fba54128f均为live祖先；B F31T2与X F48T8原失败帧核实。宽项的接管、复制、杀序及SL完整后继仍缺，不能据两个子修复整体duplicate或宣称转胜。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。保持已修子项；补齐复制/接管/SL/杀序完整链后按各子域验证，不把单动作完成当整候选执行。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 5. silent-proposal-abe9d5d0be109a9f

赢战血价、真实回复与存档恢复接续，连王剩血按实到资源

- 来源：experience-update → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-resources.md`；SHA256：`21263e5782fa17b030141cf5d79a9968115beeb1a99dc66f6309cbac9b51957b`。
- 账本：silent-0019, silent-0020。
- 证据：BTSRF7JL1W1Y A10 F30/F31（states286112、286146—286147）；XTSV1U9JD34T F47/F48/F49（states286839—286842、286894—286896）。房间资源节点的turn不适用。
- 现有实现/旧行为：当前连续Boss入口沿firstDoubleBoss/withDoubleBossStart及资源价值字段接续，路线模型说明未来火只是假设休息、死亡不能被之后的火复活。现有接口不是本批资源权重已校准。
- 处置：waiting。BTSRF7JL1W1Y F30胜后70→42，XTSV1U9JD34T F48胜后97→23并直接入F49已核；没有同资源替代路线、休息/锻造、留药的完整对照和时间留出，不能拟新安全血线、资源权重或关闭SL/终局资源宽项。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。补齐同资源路线/休息/锻造/留药对照与独立时间留出，先审资源节点错误，再拟合参数。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 6. silent-proposal-f16527e59b5cc1e0

敏捷/脆弱/覆甲分源、毒与临时减力时点及留挡上限按实帧核

- 来源：experience-update → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-mechanisms.md`；SHA256：`a71d6c87441d33115c5a8f4d3e0103673fd07798805978646f3a3961fb749079`。
- 账本：silent-0005, silent-0006, silent-0011, silent-0013, silent-0016, silent-0027, silent-0046, silent-0069, silent-0095, silent-0128, silent-0196, silent-0241。
- 证据：BTSRF7JL1W1Y A10 F31T2/3；XTSV1U9JD34T A10 F49T1/T2/T3/T4，states286158—286163、286897—286899、286978—286987。
- 现有实现/旧行为：当前模型已有临时属性、覆甲、钳子、无实体与单弃分支；单层幽灵窄源96f17377a331e50ea5b6a3fe8d2b605932ed1bd4不能关闭所有组合和用药时机。
- 处置：waiting。B F31T2临时减力/13牌挡与覆甲分源、X F49T3新增敏捷不补旧5挡与单层幽灵留10挡均已核；未定位当前新增确定模型差，缺未知组合独立误差和延后用药完整后继，不拟新时机/持有价或全组合规则。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。固定局面逐牌分源并保留回合边界；有当前预测错差再撤源码失败/恢复通过及沙箱自测。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 7. silent-proposal-7a8e9ccb7e646538

毒/倍率挡/持牌伤及荆棘按实结算，SL换线预测与整轮实差分账

- 来源：experience-update → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-combat.md`；SHA256：`e365da8858d06c845b8f83b662fad011721eeab59fd4e0dce4c46aa3925b640f`。
- 账本：silent-0005, silent-0006, silent-0011, silent-0021, silent-0024, silent-0027, silent-0034, silent-0077, silent-0079, silent-0123, silent-0129, silent-0180, silent-0221。
- 证据：9Z9H2EXKLF3T A10 F48末试T10/T11，states287998—288008；资源F35/F38/F39/F42/F45/F47；完整逐击事件缺口仍保留。
- 现有实现/旧行为：升级融入暗影来源2184caaab265ebf86c0627aaef39c2e7a170a990为base/live祖先；现有持牌伤/毒结算仍与事件毛伤/截断/整战反事实分别验收。
- 处置：waiting。9Z9H2EXKLF3T F48末试T10首挡18后9/10合37仍损15，T11毒39结后敌32且玩家死已核。缺逐击毛伤事件、零血截断后的未执行击及同条件SL/药时替代整战，不能用24/24模拟败率或局部净差校准血价、必死/SL阈值。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。补逐击毛伤事件、截断后的未知归属和同条件完整替代战；先做归因校准，再考虑SL或终局阈值。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 8. silent-proposal-cd9f76184de6e29a

跨幕缺血80%回复与营火/胜战消耗/SL资源接续按实到节点分账

- 来源：experience-update → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-resources.md`；SHA256：`54f562100db0a2dbc72c07a5b1411e42838e3370221a23ea4b769795196c66aa`。
- 账本：silent-0019, silent-0020, silent-0243。
- 证据：本批十锚点及原提案关联9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0，再按本批另两提案核7X0W3U8TVA2A/MTQ0EUBJ3R6T；十五局22对F17→18或F33→34、turn不适用；逐对原行在transition-pairs.json。
- 现有实现/旧行为：角色专属double-boss入口仅Silent A10/三幕/LEVEL_10范围；该连续Boss模型不等于所有跨幕或路线条件。22对回复是材料复核，不新增/替换原经验分母。
- 处置：waiting。十五个本角色关联局22对同上限跨幕均符合floor(缺血×80%)；这只复核A9/A10已观察回复。缺未知遗物/先古交互、同资源替代路线、当前消费者具体误算与后续资源兑现，不能把跨幕公式当资源/SL/终局整项已覆盖。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。复核新出现的同角色交互及当前明确误算消费者；保持A9/A10与同上限边界，未来路线不能预支未抵达节点。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 9. silent-proposal-292f6731bdb9b669

核对静默A10头骨组合毒药水实加7毒与现有窄范围上下文，未知持有价不当已校准零值，不拟合早喝规则

- 来源：postmortem → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-044302-postmortem/proposal-poison-potion.md`；SHA256：`2f943d1aee2e7ed6d1ddfa07b469a4488d27525bad4714cec58f6a94917a8c63`。
- 账本：silent-0087, silent-0020。
- 证据：7X0W3U8TVA2A A10 F31T13，states288470—288472、decision282021；T1未模拟选项decision281953。该关联局来自本批提案原runs，非另领队列。
- 现有实现/旧行为：combat-plan.ts:3232—3233仅把已有Demon或doubleBoss范围的observedPoison传入；本局F31不匹配doubleBoss层，Demon还要求另一个完整组合。modelPotion的observedPoison为共享标量作用于validTargets，不能用一次后段7毒证明所有目标/重附状态均相同。
- 处置：waiting。7X0W3U8TVA2A A10头骨组合F31T13只核后段0→7毒、HP不变、结后18且玩家死；当前observedPoison入口仍不覆盖该F31组合。单次后段观察不足以将标量7扩给前/中段或重附目标，亦缺早喝整战与持有价；保留未模拟边界和waiting。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。需前/中段和重附/阻挡条件的实际饮用证据，或经证据限定目标的接口；另验早喝/持有价，不重复加头骨增量。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 10. silent-proposal-0802f69b28d25079

静默A10同盘SL少一防御以8血换6即时伤；固定核对速度药/毒素/资源链，验证饱和探索血价并保留缺反事实限制

- 来源：postmortem → strategy-proposal；原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-sl.md`；SHA256：`79e1696de63d19810eb442ee3afa83dd5795f1693f4c9f4a48433fef014e3596`。
- 账本：silent-0079, silent-0019, silent-0044, silent-0080, silent-0253, silent-0011, silent-0214, silent-0189, silent-0046, silent-0222, silent-0243, silent-0262。
- 证据：MTQ0EUBJ3R6T A10 F23T3/T4，states288806—288812、288899—288905；decision282434；F19/F20/F21/F22资源端点。该关联局来自本批提案原runs。
- 现有实现/旧行为：当前sl/explore.ts:1564—1568按模拟死亡比例不更差筛选；1对1同为死亡率1时无法从比例推出血损相同。当前代码按原探索授权保留；没有本批受控整战/时间留出支持替代权重。
- 处置：waiting。MTQ0EUBJ3R6T F23T3原线29挡零损/净伤13、SL替线19挡损8/净伤19已核，两线题面均24/24死亡且无完整候选执行认证。四次SL属同局，缺同条件整战及独立时间留出，不拟SL血价、8点门槛或药水阈值。
- 反例和限制：局部效果成立不证明整场可赢；原文反例保留，未执行或缺帧不填零。保留四试为同局相关样本；补整候选执行认证、同条件整战与新的独立A10完局作时间留出，不能定8点门槛。
- 预期行为及验证：本批保留现状；后续满足上一项证据条件才做有界实现、固定夹具撤源码失败/恢复通过、非静默等价与原sandbox入口。收益未知。
- 回退：本批无行为差量可回退；后续如实现只逆向撤销该源码提交，保留原证据、账本和并行知识刷新。

## 代码、测试与上线边界

本批fixes=[]、merged=null、tests={tsc:null,vitest:null,cases:null}。没有源码提交，未运行生产tsc/vitest及撤源码试验；材料核验不能填作测试成功。未进行live合并、未分配版本、未改上线记录/运维prompt/根请求或原提案。实际live读回固定为`fe6462651b593b9831581c088deface9957a404f`，11叶SHA与6个窄源祖先证据见source-readback.json；三叶差异均为Roy/Dai历史注释，二进制diff见base-live-source-diff.patch。本批没有借用历史测试结果。

普通批次无新代码时按任务允许的报告完成口径交运维，由调度器保留waiting并在新证据出现后重派。父学习/量化要求不因本报告关闭，未声称经验已入库或消费者已采用。

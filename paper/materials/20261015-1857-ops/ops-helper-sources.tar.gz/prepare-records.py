from pathlib import Path
import subprocess, json, hashlib, re, os, tarfile, importlib.util
root = Path.cwd(); r = root
p = r / 'ops/codex-ops/record-staging/20261015-1857'
pub = r / 'paper/materials/20261015-1857-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-184302-s2-strategy-proposal'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions'] == report['proposal_results']
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and all(x is None for x in report['tests'].values())
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
final = json.loads((s / 'delivery-check.json').read_text())
assert final['base'] == report['base'] and final['worktree_clean'] and final['batch_binding_verified']
assert final['waiting_count'] == final['proposal_count'] == 10 and final['ledger_updates'] == 44 and final['protected_fields_unchanged']
assert final['new_commits'] == final['source_changes'] == final['knowledge_changes'] == [] and final['merged'] is None and final['release_id'] is None
for path,digest in final['files'].items(): assert sha((s/path).read_bytes()) == digest
material = json.loads((s / 'material-checks.json').read_text()); ev = json.loads((s / 'evidence-audit.json').read_text())
assert sum(x['count'] for x in ev) == 22424 and all(x['byte_identity_verified'] for x in ev)
assert material['count'] == len(material['checks']) == 26 and all(x['passed'] and x['actual'] == x['expected'] for x in material['checks'])
ids = json.loads((s / 'run-identities.json').read_text()); assert len(ids) == 15 and all(x['character'] == 'SILENT' for x in ids.values())
assert sum(x['ascension'] == 9 for x in ids.values()) == 3 and sum(x['ascension'] == 10 for x in ids.values()) == 12
source = json.loads((s / 'source-readback.json').read_text()); assert len(source['files']) == 11 and source['base'] == report['base']
for x in source['files']:
    a = git('show', report['base'] + ':' + x['path']); z = git('show', source['live'] + ':' + x['path'])
    assert sha(a) == x['base_sha256'] and sha(z) == x['live_sha256']
    assert a == z or a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
for x in source['ancestors']:
    assert x['base_ancestor'] and x['live_ancestor']
    for target in [report['base'],source['live']]: git('merge-base', '--is-ancestor', x['commit'], target)
for x in json.loads((s/'original-proposals-manifest.json').read_text()):
    assert sha(Path(x['copy']).read_bytes()) == x['sha256'] and Path(x['copy']).stat().st_size == x['bytes']
inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]; owned = []
for raw in (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 44
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
receipts = json.loads((s / 'ledger-own-receipts.json').read_text()); assert len(receipts) == 44
with (r / 'paper/materials/learning/ledger.jsonl').open('rb') as ledger:
    for ref in receipts:
        ledger.seek(ref['offset']); raw = ledger.read(ref['bytes']); assert sha(raw) == ref['sha256'] and json.loads(raw) == ref['row'] and raw in owned
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); seen = set(old.splitlines())
added = b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); before = fold(old); after = fold(old + added)
assert set(before) == set(after)
for ident in before:
    for k in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']: assert before[ident].get(k) == after[ident].get(k), (ident, k)
old_notice = r / 'ops/codex-ops/learning-notices/dc64dcaad18a9e041eacd5bd.json'
notice = json.loads(old_notice.read_text()); assert notice['request_id'] == 'silent-proposal-292f6731bdb9b669' and 'X06' in notice['message']
receipt = {'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'source11_sha_and_six_live_ancestors_verified':True,'source8_equal3_historical_comment_differences_preserved':True,'original_material_rows':22424,'original_material_assertions':26,'material_tests_reexecuted':False,'owned_ledger_rows':44,'protected_fold_preserved':True,'original_scope':'15 Silent runs; 3A9 and12A10 separate; byte/identity checks do not mean every row semantically audited or complete candidates certified; 22 transition pairs are old observed cases, not broad resource calibration.','original_native_scope':'Learner verified launcher only; ops now checked actual original native context/input/lease without changing model or sandbox. Task-text high vs actual xhigh retained.','original_failure_history':['First read-only sandbox command did not execute after directory lifecycle glob error; original retry preserved.','Wrong sim/card-model path and non-combat combat=None material probes preserved; corrected source/schema reads are not production fixes.','Original long-output truncation and bounded rereads retained; no missing-evidence claim based on truncated output.'],'prior_poison_notice_preserved':{'path':str(old_notice.relative_to(r)),'sha256':sha(old_notice.read_bytes()),'scope':'Current selected 7X single observation does not withdraw earlier X06 existing-poison observations or the conditional constant6/observed7 consumer difference. Existing notice/parent/owner and unknowns retained; no new notice, receipt or ACK claimed.'},'no_source_merge_version_checks_or_game_action':True}
(pub / 'batch-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 350000 and f.suffix in ['.json', '.jsonl', '.md', '.py', '.txt', '.patch'] and f.name not in ['ledger-snapshot.json', 'state-windows.jsonl', 'ledger-before.json', 'scan-input.txt', 'final-scan-input.txt']]
files += list((s / 'original-proposals').glob('*.md'))
files += [s / 'evidence/evidence-manifest.json']
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1857原184302-s2策略rc0/done、十项waiting/no-source门禁核，cc29干净WT无新提交，testsnull/mergednull，不重合/发号/补测或重复派单。15个Silent关联局22424行字节/身份及26材料断言为原学习者读回，不重跑或当全行语义审计/生产测试；3A9/12A10分列、22跨幕对不当独立资源校准或完整候选认证。11叶旧livefe646265逐SHA/六窄源main-live祖先核，8同/3历史Roy-Dai注释差保留，不据窄修关闭宽提案。44原CLI只where/note、逐offset/SHA及保护字段核；旧claim/首证/prior/evidence/status/version不变。ops补核真实native Sol6.1/xhigh/input/lease、workspace-write/no-network，原学习者只核launcher与任务high文字差异保持；原sandbox glob初读未执行、缺源码路径/combat空值及截断工具失败留史，不当产品bug。当前7X窄观察不撤回原dc64通知的X06既毒实证/条件6与7消费差，原通知/父项/owner及未知保持，未新通知或代ACK。无新经验/源码/复盘，不刷新论文、不改当前局/账号模型预算队列prompt，原P2/C2与宽父沿原链、不等待未来事件。证据paper/materials/20261015-1857-ops/。\n'
note = f'\n- {at} [ops 策略处置] 原184302-s2十项继续waiting，无新源码/合入/版本；44条原CLI仅追溯，原材料及运行身份已核并归档。旧窄实现不关宽项，当前7X子窗口不撤回此前X06毒药条件模型实证/未知；原通知与owner保持，不重复通知/派单/补测。回执paper/materials/20261015-1857-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note}; (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in [p / 'prepare-records.py', p / 'seal-records.py', r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'batch': bid, 'waiting': 10, 'own_ledger_rows': 44, 'no_source_tests_merge_release_or_dataset': True, 'protected_fields_preserved': True, 'native_model_and_original_sandbox_verified': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}; values['paper/materials/learning/ledger.jsonl'] = old + added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; rows = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'waiting': 10, 'ledger_rows': 44, 'native_verified': True, 'ledger_check': 0, 'paths': len(rows)}))

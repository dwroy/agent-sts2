import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-191302'
SCRATCH = ROOT / 'learner/runs/20261016-191312-d3309fa7-2091-4c1f-8fca-0086f48c407d-fix-batch'
READBACK = ROOT / 'paper/materials/20261016-1848-ops/fix-batch-readback.json'


def git(*args, tree=TREE):
    return subprocess.check_output(['git', '-C', str(tree), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
base = git('rev-parse', 'HEAD').decode().strip()
assert base == '6f73180eeabc9c071c29dc355a794dbd8ed4d1e8'
assert not git('status', '--porcelain=v1')
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live').decode().strip()
previous = json.loads(READBACK.read_text())
prior = previous['original_audit']
base_ancestors = set(git('rev-list', base).decode().splitlines())
live_ancestors = set(git('rev-list', live).decode().splitlines())
files = []
for old in prior['current_files']:
    path = old['path']
    assert Path(path).name != '.env' and not path.endswith('.env')
    raw = (TREE / path).read_bytes()
    row = {'path': path, 'sha256': sha(raw), 'prior_sha256': old['sha256']}
    row['same_as_prior'] = row['sha256'] == row['prior_sha256']
    assert row['same_as_prior'], row
    files.append(row)
fixed = []
for old in prior['existing_fixes']:
    row = {**old, 'ancestor_in_base': old['commit'] in base_ancestors,
           'ancestor_in_live': old['commit'] in live_ancestors}
    assert row['ancestor_in_base'] and row['ancestor_in_live'], row
    fixed.append(row)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
lines = queue.decode().splitlines()
unchecked = [(i + 1, line) for i, line in enumerate(lines) if line.startswith('- [ ]')]
assert unchecked == [(r['line'], r['item']) for r in prior['queue_dispositions']]
prefix = ('\n'.join(lines[:prior['queue_lines']]) + '\n').encode()
assert sha(prefix) == prior['queue_sha256']
added = queue[len(prefix):].decode()
assert 'silent-0461' in added and 'infra-stall-between-run-quiet' in added
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)
focused = []
for old in prior['focused_source_review']:
    data = (TREE / old['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(data) if old['anchor'] in line]
    assert found, old
    focused.append({**old, 'current_matching_lines': found})
for path, anchor in [
    ('ops/stall-check.sh', 'reporting_finished_run=1'),
    ('agent/src/hand/screens/selection.ts', 'if (selected >= min && canConfirm && !pickFirst)'),
    ('agent/src/reflex/card-model.ts', 'const cloakAndDagger = character.toLowerCase()'),
    ('agent/src/reflex/card-model.ts', 'const draw = escapePlan ? 1 : hiddenDaggers'),
]:
    found = [i + 1 for i, line in enumerate((TREE / path).read_text().splitlines()) if anchor in line]
    assert found, (path, anchor)
    focused.append({'path': path, 'anchor': anchor, 'current_matching_lines': found})
raw_refs = []
for row in previous['raw_original_references']:
    source = ROOT / row['source']
    assert source.is_relative_to(ROOT / 'logs')
    with source.open('rb') as handle:
        handle.seek(row['offset'])
        raw = handle.read(row['bytes'])
    assert sha(raw) == row['sha256'], row
    value = json.loads(raw)
    raw_refs.append({**row, 'json_parsed': True, 'sha256_verified': True,
                     'scope': '只读核既有0308/0332原件，不扩展机制或因果结论'})
change_paths = git('diff', '--name-only', prior['base'], base).decode().splitlines()
source_changes = [p for p in change_paths if p.startswith(('agent/src/', 'agent/tests/', 'agent/tools/',
    'knowledge/builders/', 'learner/', 'eval/', 'ops/')) and p != 'ops/inbox-dev.md']
assert not source_changes, source_changes
evidence_files = []
for relative in [
    'paper/materials/20261016-1848-ops/host-checks-closure.json',
    'paper/materials/20261016-1802-ops/postmortem-readback.json',
    'paper/materials/20261016-1834-ops/postmortem-readback.json',
]:
    raw = (ROOT / relative).read_bytes()
    value = json.loads(raw)
    evidence_files.append({'path': relative, 'sha256': sha(raw), 'bytes': len(raw),
                           'json_parsed': True, 'scope': '既有运维回执读回，不冒本批生产测试'})
audit = {
    'checked_at': checked_at, 'base': base, 'main_merge': 'Already up to date.',
    'live_read_only_snapshot': live, 'prior_readback': str(READBACK),
    'prior_readback_sha256': sha(READBACK.read_bytes()),
    'queue_sha256': sha(queue), 'queue_lines': len(lines), 'queue_append': added,
    'unchecked_entries': len(unchecked), 'queue_dispositions': prior['queue_dispositions'],
    'current_files': files, 'existing_fixes': fixed, 'focused_source_review': focused,
    'raw_original_references': raw_refs, 'evidence_readbacks': evidence_files,
    'code_changes_since_prior': source_changes,
    'scope': '本批无新增纯bug实现；不修改队列、账本、源码或live；未复跑未变源码测试',
}
save('audit.json', audit)
print(json.dumps({'base': base, 'live': live, 'unchanged_source_files': len(files),
    'verified_existing_fixes': len(fixed), 'unchecked_entries': len(unchecked),
    'raw_evidence_rows_verified': len(raw_refs), 'source_changes_since_prior': source_changes}, ensure_ascii=False))

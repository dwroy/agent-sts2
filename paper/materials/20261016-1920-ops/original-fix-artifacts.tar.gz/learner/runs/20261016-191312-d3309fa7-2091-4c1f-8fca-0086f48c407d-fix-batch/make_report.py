import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
SCRATCH = ROOT / 'learner/runs/20261016-191312-d3309fa7-2091-4c1f-8fca-0086f48c407d-fix-batch'
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-191302'
subprocess.run(['date', '--iso-8601=seconds'], check=True)
audit = json.loads((SCRATCH / 'audit.json').read_text())
skipped = [
    ('silent-0271：毒必胜提前返回遗漏保血候选', '策略类；沿原独立提案，不在纯bug批改排序。'),
    ('silent-0279：SL抽序升级改标', '策略类；沿原独立提案，缺完整中间帧。'),
    ('silent-0308：单动作沙坑截止题面', '策略类；当前漏接仍在，沿原0ff91bb5da98a252/3707a98930a03d83链，不重复派发。'),
    ('silent-0311：库存恢复血量预算', '策略类；沿原独立提案，保留已观察与未知恢复规则边界。'),
    ('silent-0320：同线新建UNMOVABLE', '策略类；沿原689c132e17b5c70f实现链。'),
    ('silent-0322：升级神化同线升级', '策略类；沿原53b3db220508b3d9实现链。'),
    ('silent-0329：饮药临时力量接线', '策略类；沿原角色证据及独立提案链。'),
    ('arch-funnel-guard', '太大；独立架构功能，不混入普通纯bug批。'),
    ('arch-learning-priority', '太大；独立架构功能，不混入普通纯bug批。'),
    ('arch-unified-resource-value', '太大；独立资源模型功能，不混入普通纯bug批。'),
    ('inv-f33-regression', '太大；独立归因调查，保留原owner。'),
    ('silent-0332：成功首战接续nonpositive-hp', '证据不足；核原错误字节与当前契约，完整resources/steps仍截断、根因未知；沿5aa2672bd7cd1bf4，不放宽正HP/300样本契约。'),
    ('silent-0334：升级隐秘匕首模型', '策略类；沿原6a5c67f606bd5af7实现链。'),
    ('silent-0339：尾巴误核销', '策略类；沿原独立提案，不凭近似血量补复活规则。'),
    ('silent-0344：坚韧之环延迟格挡', '策略类；沿原8e17a61707d2ca02实现链。'),
    ('silent-0347：组装师攻击召唤', '策略类；沿原43156dee9f23ae43实现链。'),
    ('silent-0349：已有虚弱后的减力', '策略类；沿原bb7597d8a1fe63ff实现链。'),
    ('core-build-notify-222802-rc2：历史发送事实', '证据不足；后续失败诊断已修，旧历史发送事实仍未知，不冒认成功或重复发送。'),
    ('silent-0362：背向攻击减力倍率', '策略类；沿原独立角色证据提案链。'),
    ('silent-0365：未建模药水目标可达性', '策略类；当前targets.slice(0, 2)仍在，原70c22e94eda8f8a9/3adbcaf2f490177f已登记独立实现链。'),
    ('框架外层时限与分段续验收尾', '太大；精确续验入口已实现，框架所有者收尾仍沿原链。'),
    ('调度公平性核查', '证据不足；原观察未证明永久饥饿，沿原框架核查。'),
    ('silent-0481：技能药水生命周期措辞', '策略类/题面知识；当前措辞仍在，沿686d4e759478eebb/c89465046641d6ed，不自行补生命周期规则。'),
    ('silent-0487：MAD_SCIENCE三段攻击模型', '策略类；沿原0a0b31e284e6793e实现链。'),
    ('codex大脑缓存命中偏低', '证据不足；缺当前同题受控请求对比，本任务不调用真实LLM或网络。'),
    ('sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因', '证据不足；注册保存屏障已上线，上游目录归属和完整生命周期仍未知。'),
    ('named-card-facts-transport：事件入口之外范围', '太大；事件入口已修，其余独立功能沿原owner。'),
    ('boss模拟样本性能及v5-dpr-health宽范围', '太大；独立专项，保留冻结输入、预算、样本及原验收链。'),
    ('rest-timeout-accepted-route-not-committed / silent-0446', '策略类/结构；沿原2d3aa8dfb27dbe3f，不提交未确认动作。'),
    ('silent-0469：纸鹤其他未知组合/整战收益', '策略类；已观察聚合体窄子项已修，更宽组合与整战收益未闭合。'),
    ('silent-0496：取牌页零选确认及Cards误作抽牌', '策略类；原0cd2f0dfbc4a0805/0496/0418已登记，当前入口仍在，不重复派普通fix。'),
    ('silent-0461：脆弱4挡斗篷生成条件', '策略类；普通6挡窄子项不覆盖本条件，沿f4eb0efba2594252/7338be2498f3ae60，不将未实际施放候选当机制实证。'),
]
result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [],
    'skipped': [{'item': item, 'reason': reason} for item, reason in skipped],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
    'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md'),
}
assert not subprocess.check_output(['git', '-C', str(TREE), 'status', '--porcelain=v1'])
assert subprocess.check_output(['git', '-C', str(TREE), 'rev-parse', 'HEAD'], text=True).strip() == audit['base']
lines = [
    '## 修 bug 回报', '',
    f"- 合并基线：main → {audit['base']}（开工工作区干净，先合main，Already up to date.）",
    '- 修复（每条一行）：无新增纯bug；42条未勾选原文逐项处置、389个相关源码/测试/脚本与前批逐SHA相同，81项既有修复均是当前base/live祖先。未改源码、未提交；去掉修复时失败验证不适用。',
]
for row in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['commit']}（本批核base/live祖先及当前相关源码SHA；仅已修子项，更宽父项保留）")
for item, reason in skipped:
    lines.append(f'- 没修的：{item} — {reason}')
lines.extend([
    '- 测试：tsc未运行，退出码null；vitest未运行，0文件 / 0用例 / 退出码null；无重跑。无新增代码提交或合入，不复跑未变源码；只读核验10条既有0308/0332原始日志的offset/bytes/SHA及JSON，记录在audit.json，不冒生产测试。',
    f"- 合入：未合入（本批无新增提交）；live只读核至{audit['live_read_only_snapshot']}。没有空合并、版本号、账本状态更改或规则通知；旧宿主full1与后续限定补验0均保留，不冒称原full0。",
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines))
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'fixes': 0, 'existing_fixes': len(audit['existing_fixes']),
    'skipped': len(skipped), 'merged': None, 'tests': result['tests'],
    'worktree_clean': True}, ensure_ascii=False))

抽取中间脚本曾两次把决策 latency_ms（对象）当作数值求和，第一次另包含非数值 usage 字段，均以 TypeError 终止。未写授权共享记录。现已按 Jev latency_ms.jev 与 brain 标量分别统计；analyze.py 和 analysis.txt 保留修正后的计算，原工具输出保留失败。

## 复盘回报
- 已追加：2Q6ZYZ6JHM0M（A10，第8层，旧日雕像 BYGONE_EFFIGY：T7以7血7挡对25攻击阵亡，敌余10血）。
- 新的纯 bug（file:line，每条一行；没有写「无」）：
  - 2Q6ZYZ6JHM0M：隐秘匕首双弃题未读取已保存的条件后继，错误显示无已选方案 — agent/src/hand/screens/selection.ts:394（新；fix-queue无既有项）。
- 写成「未记录」的项：2Q6ZYZ6JHM0M：完整dirty输入、尾刀中间帧及逐击毛伤、完整候选实际执行比例、旧boss时钟及实打比、不同弃牌／路线／休息／留药的整战对照、纯战斗墙钟、Jev缓存、实际费用。
- 学习账本：2Q6ZYZ6JHM0M：新增 silent-0499；更新 silent-0205、silent-0021、silent-0307（老错 silent-0205）；`ledger.py check` 退出码0。
- 代码提案（证据／账本／CLI id／实现任务，证据不足明确写限制）：
  - F8T1／T5、F5T1／silent-0499、silent-0205／silent-proposal-59b2e430bb7521d4／strategy-proposal：补条件后继事实；缺保牌后的整战对照，不保证改变胜负。
  - F8T1—T7／silent-0021、silent-0307／silent-proposal-c8eb787720634577／strategy-proposal：接续实际输出审计；缺受控后继与boss实战，保持原排序。两项均pending，未实现或上线。

```json
{"task":"postmortem","appended":["2Q6ZYZ6JHM0M"],"skipped":[],"bugs":[{"run":"2Q6ZYZ6JHM0M","where":"agent/src/hand/screens/selection.ts:394","what":"隐秘匕首双弃题未读取已保存的条件后继，错误显示无已选方案","new":true}],"ledger":{"added":["silent-0499"],"updated":["silent-0205","silent-0021","silent-0307"],"repeats":["silent-0205"],"check":0},"code_proposals":["silent-proposal-59b2e430bb7521d4","silent-proposal-c8eb787720634577"],"implementation_domains":["combat"],"report":"/home/dw/Projects/agent-sts2/learner/runs/20261017-101312-0503db53-7108-4416-9f48-d469b5fe5830-postmortem/report.md"}
```

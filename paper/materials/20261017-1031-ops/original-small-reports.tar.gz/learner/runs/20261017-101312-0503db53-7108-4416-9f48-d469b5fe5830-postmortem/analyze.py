import json,pathlib,collections,datetime,hashlib
p=pathlib.Path(__file__).parent
def rows(name):return [json.loads(l) for l in (p/(name+'-selected.jsonl')).open()]
ds,bs,ss=rows('decisions'),rows('brain'),rows('states')
jev=[e for e in ds if e['row']['decider']=='jev'];plans=[e for e in jev if e['row']['label'].startswith('combat/plan-choice')]
for typ,es in [('JEV',jev),('BRAIN',bs)]:
 totals=collections.Counter();missing=collections.Counter()
 for e in es:
  for k,v in (e['row'].get('usage') or {}).items():
   if isinstance(v,(int,float)):totals[k]+=v
   else:missing[k]+=1
 print(typ,'USAGE',dict(totals),'nonnumeric',dict(missing),'first usage',es[0]['row'].get('usage'),'latency',[e['row'].get('latency_ms',0) for e in es])
code=[e for e in ds if e['row']['decider']=='code' and not(e['row']['label']=='combat/plan-continue' and 'Jev-chosen' in e['row']['rationale'])]
codekeys={(e['row']['floor'],e['row']['turn']) for e in code if e['row']['label'].startswith('combat/')};jevkeys={(e['row']['floor'],e['row']['turn']) for e in plans}
print('DECIDER raw',dict(collections.Counter(e['row']['decider'] for e in ds)),'recategorized code',len(code),'jev-plan',sum(e['row']['label']=='combat/plan-continue' and 'Jev-chosen' in e['row']['rationale'] for e in ds))
print('code autonomous combat actions',sum(e['row']['label'].startswith('combat/') for e in code),'code turns with any',len(codekeys),'without Jev plan',len(codekeys-jevkeys),'only keys',sorted(codekeys-jevkeys))
print('total combat turns',len(codekeys|jevkeys),'jev plans',len(plans),'best',sum(e['row'].get('rollout_best_chosen') is True for e in plans),'low',[(e['line'],e['row']['confidence']) for e in jev if e['row'].get('confidence',1)<.35])
a,b=ds[0]['row']['ts'],ds[-1]['row']['ts'];elapsed=(datetime.datetime.fromisoformat(b)-datetime.datetime.fromisoformat(a)).total_seconds();print('ELAPSED',a,b,elapsed,elapsed/60)
for e in ds:
 r=e['row']
 guardkeys={k:v for k,v in r.items() if 'guard' in k.lower()};focuskeys={k:v for k,v in (r.get('questions') or {}).items() if 'focus' in k.lower()}
 if guardkeys or focuskeys:print('GUARD/FOCUS',e['line'],guardkeys,focuskeys)
print('sl_reload values',dict(collections.Counter(str(e['row'].get('sl_reloads')) for e in ds)),'fallback',sum(bool(e['row'].get('fallback')) for e in ds))
for floor in [2,3,4,5,8]:
 combat=[e for e in ss if e['row']['state']['run']['floor']==floor and e['row']['state'].get('in_combat')]
 turns=collections.OrderedDict()
 for e in combat:turns.setdefault(e['row']['state']['turn'],[]).append(e)
 result=[]
 for t,v in turns.items():
  start,end=v[0]['row']['state'],v[-1]['row']['state'];last=end['combat']['player'];en=end['combat']['enemies'];beginhp=sum(x['current_hp'] for x in start['combat']['enemies'] if x.get('is_alive'));endhp=sum(x['current_hp'] for x in en if x.get('is_alive'))
  nxt=next((e for e in ss if e['line']>v[-1]['line'] and e['row']['state']['run']['floor']==floor),None)
  isexit=bool(nxt and not nxt['row']['state'].get('in_combat'))
  posthp=nxt['row']['state']['run']['current_hp'] if nxt else None
  netdamage=beginhp-(0 if isexit and nxt['row']['state']['screen']=='REWARD' else endhp)
  result.append({'turn':t,'need':beginhp,'damage_net_to_defeat_if_reward':netdamage,'visible_damage':beginhp-endhp,'hp_before':start['run']['current_hp'],'hp_after':posthp,'hp_loss':start['run']['current_hp']-posthp if posthp is not None else None,'block':last['block'],'attack':sum(x.get('total_damage') or 0 for e in en for x in e.get('intents',[])),'start_line':v[0]['line'],'last_line':v[-1]['line'],'next_line':nxt['line'] if nxt else None,'exit':isexit})
 print('TURNS',floor,json.dumps(result,ensure_ascii=False))
 (p/('turns-F'+str(floor)+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
manifest=[]
for f in p.glob('*selected.jsonl'):
 data=f.read_bytes();manifest.append({'file':f.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(p/'extraction-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')

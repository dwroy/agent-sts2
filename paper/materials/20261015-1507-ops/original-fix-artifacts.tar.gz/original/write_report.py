import hashlib
import json
from pathlib import Path
import subprocess

SCRATCH = Path(__file__).parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-144302'
prior_path = ROOT / 'learner/runs/20261015-131306-b66a3644-32b0-4a91-bbab-6860bd4bbecd-fix-batch/result.json'
audit = json.loads((SCRATCH / 'audit.json').read_text())
prior = json.loads(prior_path.read_text())
assert all(row['ancestor_in_base'] and row['ancestor_in_live_snapshot'] for row in audit['existing_fixes'])
assert audit['worktree_status'] == '' and audit['source_diff'] == ''
assert audit['queue_identical_to_previous_audit']
assert (SCRATCH / 'tsc.exit').read_text().strip() == '0'
assert (SCRATCH / 'vitest.exit').read_text().strip() == '0'
test_log = (SCRATCH / 'targeted-tests.log').read_text()
assert 'Test Files  8 passed (8)' in test_log and 'Tests  16 passed (16)' in test_log
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK).decode().strip() == audit['base']
assert subprocess.check_output(['git', 'status', '--short'], cwd=WORK).decode() == ''

result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': prior['skipped'],
    'merged': None, 'tests': {'tsc': 0, 'vitest': 0, 'cases': 16},
    'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md'),
}
result['skipped'].append({
    'item': '框架外层总时限收尾',
    'reason': '太大/独立框架范围；精确分段续验入口24c2e3a75已修，原包装器和宿主收尾沿原owner；本批不重放通知或改历史失败回执。',
})

lines = [
    '## 修 bug 回报',
    f"- 合并基线：main → {audit['base']}（开工工作区干净；先 git merge --no-edit main，返回 Already up to date.）",
    '- 修复（每条一行）：无新增修复；未确认到仍存在且属于本普通纯 bug 批次的可实施条目，无新增代码或测试提交，撤源码红绿验证不适用。',
]
for row in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{row['item']} — 已修，提交 {row['source_commit']}；当前路径 `{row['path']}`，已核本基线/live祖先及源码SHA。窄子项不关闭宽父项。")
for row in result['skipped']:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines.extend([
    '- 测试：tsc 退出码 0；Vitest 定向 8 文件 / 16 用例 / 退出码 0，无重跑。固定输入、假引擎，无真实 LLM 或网络。无代码改动和提交，未运行完整 test-sandbox；定向结果不代表完整套件。',
    '- 合入：未合入；本批无新提交，merged=null。已有72项来源已在只读live快照 ' + audit['live_read_only_snapshot'] + '；未执行空批合并、提交知识刷新或添加行为版本。',
    '- 需要 Roy 定的事（没有写「无」）：无。',
    '',
    '核查原件：audit.json记录72项source/base/live祖先、当前源码SHA、原源码SHA及上一批审计的逐叶对照；queue-snapshot.md为本批只读队列快照（1324行，SHA256 ' + audit['queue_sha256'] + '）。它与上一批已核队列完全相同。',
    '',
    '与上一批基线相比的游戏源码增量只有已经进入main的be9577c81（限定Mirage重放Serpent触发）及其固定夹具；card-model.ts和turn-solver.ts的差异已读回，没有重复实现其中的机制修复。其余已核源码叶保持相同；source.diff为空。',
    '',
    'silent-0481当前两处误句仍在，但原proposal-selection-lifetime.md明确目标为独立strategy-proposal、domains=potion/structure。本批已核既有CLI登记silent-proposal-686d4e759478eebb及证据Y2K25VFDU95P/A10/F9T3、T5；没有把未知生命周期或收益补入提示，也没有重复登记或派发。rest-timeout对应原silent-proposal-2d3aa8dfb27dbe3f亦保留独立链。',
    '',
    '定向文件：agent/tests/learner-entry.test.ts、ledger-publication-baseline.test.ts、legacy-continuation-notice-ack.test.ts、ascension-observed.test.ts、extract-evidence.test.ts、subscription-usage.test.ts、report-plan-costs.test.ts、learner-strategy-scratch.test.ts。原命令输出在tsc.log和targeted-tests.log，各退出码单独保存。',
    '',
    '本批没有修复提交，因此未将账本重复降为proposed、未登记新提案或shipped；未改队列、运维prompt、main/live、原日志和其他批次记录。原失败及缺证范围保留。',
    '', '```json', json.dumps(result, ensure_ascii=False), '```',
])
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'report.md').write_text('\n'.join(lines) + '\n')
manifest = {}
for name in ['audit.json', 'source.diff', 'queue-snapshot.md', 'report.md', 'result.json',
             'tsc.log', 'tsc.exit', 'targeted-tests.log', 'vitest.exit', 'audit_current.py', 'write_report.py']:
    data = (SCRATCH / name).read_bytes()
    manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(SCRATCH / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'existing_sources': len(audit['existing_fixes']),
                  'new_fixes': 0, 'tests': result['tests'], 'merged': None}, ensure_ascii=False))

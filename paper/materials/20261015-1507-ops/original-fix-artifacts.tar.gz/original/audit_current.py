import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-144302'
SCRATCH = Path(__file__).parent
PRIOR = ROOT / 'learner/runs/20261015-131306-b66a3644-32b0-4a91-bbab-6860bd4bbecd-fix-batch/audit.json'


def git(*args, cwd=WORK):
    return subprocess.check_output(['git', *args], cwd=cwd)


def ancestor(source, target):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', source, target], cwd=WORK).returncode == 0


def sha(data):
    return hashlib.sha256(data).hexdigest()


prior_bytes = PRIOR.read_bytes()
prior = json.loads(prior_bytes)
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
rows = []
for previous in prior['existing_fixes']:
    source = previous['source_commit']
    path = previous['path']
    current = (WORK / path).read_bytes()
    original_path = previous.get('original_source_path', path)
    original = git('show', f'{source}:{original_path}')
    rows.append({
        'item': previous['item'], 'source_commit': source, 'path': path,
        'ancestor_in_base': ancestor(source, base),
        'ancestor_in_live_snapshot': ancestor(source, live),
        'current_source_sha256': sha(current),
        'same_as_previous_audit': sha(current) == previous['current_source_sha256'],
        'same_as_source_commit': current == original,
        'original_source_path': original_path, 'original_source_sha256': sha(original),
    })

result = {
    'base': base, 'live_read_only_snapshot': live,
    'queue_sha256': sha(queue), 'queue_lines': len(queue.splitlines()),
    'queue_identical_to_previous_audit': sha(queue) == prior['queue_sha256'],
    'prior_audit': str(PRIOR), 'prior_audit_sha256': sha(prior_bytes),
    'existing_fixes': rows, 'new_fixes': [],
    'source_diff': git('diff', '--binary', base).decode(),
    'worktree_status': git('status', '--short').decode(),
    'changed_code_since_prior': git('diff', '--name-status', prior['base'], base, '--',
                                   'agent', 'learner', 'ops', 'eval', 'knowledge/builders').decode().splitlines(),
}
(SCRATCH / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'queue-snapshot.md').write_bytes(queue)
(SCRATCH / 'source.diff').write_text(result['source_diff'])
print(json.dumps({
    'base': base, 'live_snapshot': live, 'sources': len(rows),
    'all_base_ancestors': all(row['ancestor_in_base'] for row in rows),
    'all_live_ancestors': all(row['ancestor_in_live_snapshot'] for row in rows),
    'changed_sources_since_prior': [row['path'] for row in rows if not row['same_as_previous_audit']],
    'queue_unchanged': result['queue_identical_to_previous_audit'],
    'clean': not result['worktree_status'],
    'changed_code_since_prior': result['changed_code_since_prior'],
}, ensure_ascii=False))

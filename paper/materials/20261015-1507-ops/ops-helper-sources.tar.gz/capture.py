from pathlib import Path
import json,hashlib,subprocess,os,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1507';pub=r/'paper/materials/20261015-1507-ops';sha=lambda b:hashlib.sha256(b).hexdigest();at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();m=json.loads((p/'supplement-manifest.json').read_text());h=(p/'manifest-sha.txt').read_text().strip();receipt=r/'ops/codex-ops/learner'/f'{m["batch"]}.supplement-{h}.json';inode=str((r/'ops/live-merge.lock').stat().st_ino);locks=[]
for line in Path('/proc/locks').read_text().splitlines():
 fields=line.split()
 for i,t in enumerate(fields):
  if t.count(':')==2 and t.split(':')[-1]==inode:
   pid=fields[i-1];row={'pid':int(pid),'waiting':'->' in fields,'raw_lock_record':line};proc=Path('/proc')/pid
   try:
    raw=(proc/'stat').read_text();row.update(comm=(proc/'comm').read_text().strip(),cwd=os.readlink(proc/'cwd'),birth=raw[raw.rfind(')')+2:].split()[19])
   except FileNotFoundError:row['exited_before_readback']=True
   locks.append(row)
state=json.loads(receipt.read_text()) if receipt.exists() else None;stage='registered broker continuation waiting on existing live lock; host command not started' if state is None and any(x['waiting'] for x in locks) else ('host receipt '+state['state'] if state else 'submitted; no host receipt yet')
readback={'at':at,'manifest_sha256':h,'pinned_live':m['live'],'stage':stage,'actual_live_mutex_readback':locks,'receipt_exists':state is not None,'receipt_path':str(receipt.relative_to(r)),'actual_receipt':state,'original_full_rc':1,'not_full_suite_pass':True,'no_interruption_or_lock_takeover':True};(pub/'host-supplement-readback.json').write_text(json.dumps(readback,ensure_ascii=False,indent=2)+'\n');(pub/'supplement-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
orig=Path(json.loads((pub/'host-failure-decision.json').read_text())['original_full']['log']);client=r/'paper/materials/20261015-1436-serpent-replay/serpent-host-client-exit.json';assert json.loads(client.read_text())['actual_client_exit']==1;(pub/'original-host-client-exit.json').write_bytes(client.read_bytes());scan=p/'archive-scan';dest=scan/'original-host'/orig.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(orig.read_bytes())
with tarfile.open(pub/'original-host-log.tar.gz','w:gz') as tf:tf.add(dest,arcname='original-host/'+orig.name)
(pub/'original-host-log-manifest.json').write_text(json.dumps({'path':str(orig.relative_to(r)),'bytes':orig.stat().st_size,'sha256':sha(orig.read_bytes()),'tsc_succeeded_before_vitest':True,'vitest_rc':1,'files':{'passed':481,'failed':1},'tests':{'passed':4870,'failed':1,'skipped':2},'failure':'tests/build-facts-audit.test.ts selection/remove fixed test 60000ms timeout','no_assertion_failure_reported':True,'no_posthoc_full_pass':True},ensure_ascii=False,indent=2)+'\n')
helpers=list(p.glob('*.py'))+[r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py'];rows=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tf:
 for f in helpers:
  name=f.name;b=f.read_bytes();d=p/'helper-scan'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);tf.add(f,arcname=name);rows.append({'path':str(f.relative_to(r)),'archive':name,'sha256':sha(b)})
(pub/'ops-helper-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'at':at,'stage':stage,'mutex_records':len(locks),'helper_count':len(rows)}))

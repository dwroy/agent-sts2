# 准备阶段记录

两条只读路径探针未命中：猜测的 agent/src/reflex/potion-values.ts 实际为 agent/src/knowledge/potion-values.ts；agent/tools/replay-combat-evidence.ts 不存在。随后用 rg --files 定位，只读核已有 learner/audit-selection.ts 链。退出码2不当产品或机制失败。未运行不存在的消费者，不造消费者成功。

本批复用旧材料核验脚本，适配 verified-runs 的封套字典形状；原脚本只读不改。旧消费者统计初稿把不存在的 observed 状态计0的历史勘误保持；只采用实际 observed_turn_endpoints / observed_endpoints。

另一次 rg 的 shell 通配符 silent-*facts*.ts 没有匹配文件，返回2；同调用返回的实际命中只用于定位，随后明确读取 silent-potion-reference.ts / silent-loss-reference.ts。未把缺路径视作产品缺陷。

额外计数首探针错误读取 segment.actions.observation / segment.turn_windows，得到 action_None1230，原稿 consumer-count-probe.json 保留；次探针正确到达顶层 observed_actions，但把动作状态误放顶层，KeyError:status/exit1 原失败摘要 consumer-count-probe-failure.txt 保留。随后按源码与真实输出的 observed_turns.status / observed_actions.observed_interval.status 重数，275轮窗144端点、1530动作1097端点，与旧输出统计一致；consumer-status-counts.json 为最终机械计数。没有修改/重跑消费者，不当游戏或产品失败。

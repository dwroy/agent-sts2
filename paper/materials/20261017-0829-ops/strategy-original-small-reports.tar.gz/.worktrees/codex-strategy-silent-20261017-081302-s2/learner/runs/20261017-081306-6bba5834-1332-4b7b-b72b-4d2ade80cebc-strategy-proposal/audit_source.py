import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-001301-s2/learner/runs/20261017-001307-0c34456a-5948-4d99-b8c9-142978505e2d-strategy-proposal')


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
prior = json.loads((OLD / 'source-audit.json').read_text())
files = []
for item in prior['files']:
    name = item['path']
    current = (ROOT / name).read_bytes()
    frozen_live = git('show', f'{live}:{name}')
    old = git('show', f'{prior["base"]}:{name}')
    files.append({'path': name, 'sha256': sha(current), 'live_sha256': sha(frozen_live),
                  'equal_live': current == frozen_live, 'equal_prior': current == old,
                  'prior_sha256': sha(old),
                  'live_source_commit': git('log', '-1', '--format=%H', live, '--', name).decode().strip()})

ancestors = []
for item in prior['ancestors'] + [
    {'commit': '3dbdc27b', 'kind': 'source_recent_narrow'},
    {'commit': '92fb9f15', 'kind': 'source_recent_narrow'},
    {'commit': 'c4d99c1b', 'kind': 'source_recent_narrow'},
    {'commit': '6c306a49', 'kind': 'source_recent_narrow'},
]:
    commit = git('rev-parse', item['commit']).decode().strip()
    value = {'commit': commit, 'kind': item['kind']}
    for label, head in [('base', base), ('live', live)]:
        result = subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', commit, head])
        assert result.returncode in (0, 1)
        value[label] = result.returncode == 0
    value['subject'] = git('show', '-s', '--format=%s', commit).decode().strip()
    value['changed_paths'] = git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()
    ancestors.append(value)

names = [item['path'] for item in files]
(OUT / 'source-vs-live.patch').write_bytes(git('diff', '--binary', base, live, '--', *names))
(OUT / 'source-since-prior.patch').write_bytes(git('diff', '--binary', prior['base'], base, '--', *names))
report = {'base': base, 'live_head': live, 'prior_base': prior['base'], 'files': files,
          'ancestors': ancestors,
          'scope': '只核列出的源码叶与实际祖先；不等于全树、旧dirty输入或完整消费者校准。经验数据提交不能充源码实现。'}
(OUT / 'source-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(files), 'equal_live': sum(x['equal_live'] for x in files),
                  'equal_prior': sum(x['equal_prior'] for x in files),
                  'base': base, 'live_head': live, 'ancestors': len(ancestors)}))

# 本批静默猎手策略提案逐项核验

时间：2026-10-17T08:27:29+08:00。批次：20261017-081302-s2-strategy-proposal。base：ac451784ffebed27097bf261bbfaa5ee69c5d4d5。

本批只消费根 learn.json 明确领取的十个 CLI id；task=strategy-proposal、character=silent、worktree 与本树一致，无 research_request / implementation_request / proposal_repair。普通专题文件绑定另一旧批次，因此未承接专题、未读取其他专题替代身份。开工 git status 干净，按要求 merge main 返回 Already up to date，HEAD 未变。十份原提案的 Markdown 原字节和 SHA 全匹配，保存在 originals/；原队列行、物理偏移及最新处置在 assigned-proposals.json。

十个派发锚点与原提案内五个补充局分列，共十五局均为 SILENT，A9 三局、A10 十二局。逐局身份与原 runs 字节位置在 verified-runs.json，不读取其他角色知识。八流共 22,424 个所属封套，保存逐流截点、每行 offset/bytes/SHA 与计数，并原位回读逐行核对 JSON 和显式局身份。八流选中封套与原 001301-s2 相同；本批没有新增独立局或新 SL 样本。各流截点分别冻结，不冒称同一时刻快照。fight-plans 零匹配只表示本次截点未选到，不能推断原日志不存在。旧 run-plans 的 8707455 字节截点另存 evidence-old-run-plans/，不覆盖本次或历史输出。

31 项固定材料断言核对实帧、净差与同上限跨幕回复；它们不是生产测试或新的机制支持分母。六个旧离线消费者输入按本次封套重建后 SHA 相同，递归六模块、原输出及 stderr 也逐 SHA 核；只复用原结果，没有重跑消费者、模型、模拟或在线 API。1627 状态、1530 带 ID 动作、447 候选段的完整候选结果仍为 null；275 轮窗中 144 个 observed_turn_endpoints、1530 动作中 1097 个 observed_endpoints。完整认证缺失不等于实际未执行。7X 的接续身份缺口与手工可核的一次 7 毒实帧分别记录。

以下逐项证据和限制沿原已核局号/层/回合重新核验，所有十项仍 waiting。既有 46 个账本的状态与提案的等待状态分开；41 个既有 shipped、5 个既有 proposed 均保留，不把已有经验数据上线当宽提案完成。只经根 ledger CLI 补本批 where/note，保留 claim、首证、prior、evidence、status、version、effect 与历史前缀，不重复 support/repeat，不新建重复代码提案。

## 逐项证据、限制及处置


### silent-proposal-03754e1265894000

关联账本：silent-0006、silent-0011、silent-0013、silent-0080、silent-0088、silent-0101、silent-0232、silent-0253。来源任务：experience-update。领域：combat、potion。

证据：RC61MFQM63Y6 F23T3/T4、F33T4；states 285222—285229、285414—285415。预判后净敏1，速度药到6；后续牌使敏捷5/4/3/2/1，挡12/21/25，末次+4为折扇被动挡，不能重复按牌挡或敏捷计算。

反例与未知：整战失败不反驳逐牌局部结算；未隔离柔嫩与脆弱/倍率/首刀等全部联合触发，持有能力不等于已经建立。

旧规则/预期行为：保留已观察逐牌分源；若补实现，应分别核初始牌面、新增敏捷、被动挡和首次攻击消耗，再检查下一轮临时量撤回。

处置：waiting。八组件仍缺柔嫩、脆弱、倍率、首刀与折扇组合的完整固定消费者校准；本批未取得新实帧或可复现的新源码差异，不能把局部已有模型登记为整包duplicate。

### silent-proposal-ab055ef7dfbb44e5

关联账本：silent-0140、silent-0069、silent-0005、silent-0206。来源任务：postmortem。领域：combat、potion。

证据：XTSV1U9JD34T F49T1/T2/T4；states 286897—286899、286986—286987。幽灵实建无实体1，攻击26→1；下一轮23HP/10挡。夜魇末T4标记3，之后即GAME_OVER，没有复制到手的后继。

反例与未知：六次同局早喝不是六个独立时点样本；旧夜魇成功经验不能证明本局绝境能活到复制回合，缺延后饮用的完整实线。

旧规则/预期行为：幽灵已有96f17377窄源码实现；继续区分当轮血价与次轮可合法兑现的复制，不拟早喝/留药参数。

处置：waiting。单层幽灵已有真实live祖先实现；夜魇合法复制、存活后继和延后饮药的受控整战结果仍缺，不能关闭整项存活/时点提案。

### silent-proposal-0129c465c6f5bd79

关联账本：silent-0009、silent-0021、silent-0024、silent-0057、silent-0079、silent-0090、silent-0140、silent-0164、silent-0205、silent-0268、silent-0271。来源任务：experience-update。领域：combat、sl、terminal。

证据：BTSRF7JL1W1Y F31T2 states 286161—286163：生存者后突然一拳不再在手，当轮35→21；XTSV1U9JD34T F48T8 states 286893—286896：毒胜仍32→23，F49继承23HP。

反例与未知：不能从原计划保留一张实际已被弃掉的牌；毒胜当轮持牌耗血与是否生成保血候选是两个问题。耳环接管内部动作和本局复制后继未记录。

旧规则/预期行为：普通单弃bf423c17、毒胜保血搜索222445a9已有live祖先源码；宽范围仍需把弃牌重问、目标、接管和复制的真实执行链逐项接续。

处置：waiting。已有单弃与毒胜保血窄实现；接管内部动作、夜魇后继及跨抽弃牌重问的完整联合候选归属仍缺，不能据两个子修复整项duplicate。

### silent-proposal-abe9d5d0be109a9f

关联账本：silent-0019、silent-0020。来源任务：experience-update。领域：sl、terminal。

证据：BTSRF7JL1W1Y F30 286112→286146：70→42，F31 286147仍42；XTSV1U9JD34T F47 286839→286841：73→97，F48 286842→286895：97→23，F49实入23。

反例与未知：这些是所选线路的实到端点；未到营火、SL恢复药瓶、另一条路线的未来资源不能预支。没有同条件改线、留药或锻造的整场对照。

旧规则/预期行为：按来源分别接续胜战损血、真实回复和SL恢复，下一战只使用实际资源；路线/休息消费者需用原完整输入校准后再谈参数。

处置：waiting。缺逐源路线/休息消费者校准及同条件改线、留药、锻造完整后继和独立留出，端点证据不足拟安全血线、药价或路线机会成本。

### silent-proposal-f16527e59b5cc1e0

关联账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0016、silent-0027、silent-0046、silent-0069、silent-0095、silent-0128、silent-0196、silent-0241。来源任务：experience-update。领域：combat、potion。

证据：BTSRF7JL1W1Y F31T2手牌/覆甲与实际损血窗口；XTSV1U9JD34T F49T1/T2幽灵和留挡、F49T4脆弱/临时减力窗口。相关原提案同时涉及毒触发、敌成长和临时属性撤回。

反例与未知：入场属性不能跨战预支；幽灵单层和钳子上限不等于以后每轮保底。净HP端点不提供每击毛伤或每个减层来源。

旧规则/预期行为：保持现有局部机制；验证时固定初始牌面和每步属性，按毒/持牌伤/攻击/覆甲/保留挡分别结算并核下一轮。

处置：waiting。覆甲、留挡、临时属性撤回、毒触发及敌成长仍缺共同输入下的逐源完整消费者回放；局部模型和端点不能认证整包实现或新药价。

### silent-proposal-7a8e9ccb7e646538

关联账本：silent-0005、silent-0006、silent-0011、silent-0021、silent-0024、silent-0027、silent-0034、silent-0077、silent-0079、silent-0123、silent-0129、silent-0180、silent-0221。来源任务：experience-update。领域：combat、potion、sl、terminal。

证据：9Z9H2EXKLF3T F48末试T8 states 287989—287991：32挡、11→0→20，复活不能写成净回血9；T10 states 287998、288000、288003—288005：挡18→27→37，HP18→3。

反例与未知：首张倍率预览不能沿用给全部后继牌；死亡后未执行击不预支反伤。多次重问和熔炉时点变化使T7局部预测/整轮差额不能作为单因整战收益。

旧规则/预期行为：固定每张倍率消耗与逐击/复活顺序，分别保存预测、实到端点和完整候选未知；不据有限全败推演改必死或SL规则。

处置：waiting。缺未截断逐击毛伤、完整候选执行归属和同条件整战后继；同盘局部净差不足校准联合模型或修改SL血价、持有价。

### silent-proposal-cd9f76184de6e29a

关联账本：silent-0019、silent-0020、silent-0243。来源任务：experience-update。领域：structure、sl、terminal。

证据：原提案十个Silent来源局，另仅用本批其他已派原提案内的同角色来源做交叉核验。15局中F17→18/F33→34同上限端点22对，A9五/A10十七，全符合floor(缺失HP×80%)；9Z F35 66/77→30/69，F42 11→31，F47 7→27。

反例与未知：当前血与最大HP损失分别记；22转换对不是22独立局。该边界不推广低进阶、未知遗物交互或未到节点，更不能重现原116局整套资源模型。

旧规则/预期行为：只沿已证A9/A10同上限转换边界和真实节点分源接续；路线、休息及SL消费者保留输入来源与未知项。

处置：waiting。22对只支持已有跨幕回复观察；原116局资源模型完整输入、路线/休息消费者校准和独立路线收益仍缺，不能把窄公式当整个资源/SL请求完成。

### silent-proposal-292f6731bdb9b669

关联账本：silent-0087、silent-0020。来源任务：postmortem。领域：potion、combat。

证据：7X0W3U8TVA2A F31T13 decisions 282021、states 288470—288472：后段零毒→7，本体25不变，再结算到18；玩家1→0，喝后仍败。F31T1原题将该药列未模拟。

反例与未知：这里只隔离该组合、该目标的一次总增量；无无头骨对照、其他目标、既有毒/重接或早喝整战实线，不能反推基础药效再加一次头骨。

旧规则/预期行为：当前PotionContext只有其他已证窄范围的observedPoison，不能扩大为所有持头骨局面。未知持有价已有holdHp=null/no_value或no_table，不能当校准为0。

处置：waiting。实加7只核该后段零毒单次；缺其他目标、既有毒、重接组合的共同推演校准及持有价/用药时点证据，不能全局扩为7毒或拟合早喝规则。

### silent-proposal-0802f69b28d25079

关联账本：silent-0079、silent-0019、silent-0044、silent-0080、silent-0253、silent-0011、silent-0214、silent-0189、silent-0046、silent-0222、silent-0243、silent-0262。来源任务：postmortem。领域：combat、potion、sl。

证据：MTQ0EUBJ3R6T F23四试T3，states 288806—288812与288899—288905；原三试10→10，末试10→2。速度临时5敏，两毒素各5与敌攻17合需27挡，29/19挡分别对应损0/8；末次同题预测为0损13伤与8损19伤。

反例与未知：四次SL合一个相关样本；原线也未形成已证整战胜利，换线还改变后继抽牌、毒雾和药时点，敌残血末值不等于即时单牌收益。

旧规则/预期行为：保留原饱和探索、必死和药价参数；若以后改排序，先用同条件整场比较即时HP缺口和后继，再用独立A10时间留出。

处置：waiting。局部多损8血/多伤6已核；缺独立A10留出及固定抽弃/药时点的受控完整后继，不能据一个相关局拟饱和探索HP门槛、权重或药价。

### silent-proposal-763a4b9d9f17b815

关联账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0044、silent-0046、silent-0053、silent-0080、silent-0087、silent-0189、silent-0214、silent-0222、silent-0235、silent-0253。来源任务：experience-update。领域：combat、potion。

证据：7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13与MTQ0EUBJ3R6T F11T1、F17T4—T8、F20T3、F23T2—T5为原十四机制提案范围。本批重点核7X F31T13施毒和MTQ F23T3速度5敏、两毒素及次轮临时层撤回。

反例与未知：前战建立的步法/毒雾不能继承，属性加层不能补旧挡；本批固定材料不能声称十四项从单项到所有组合均已完成模型校准，也没有原dirty全树。

旧规则/预期行为：各机制以已建立、已饮用和当前牌面为入口；永久/临时减力、持牌伤、能量增量与昏眩锁牌分开验收，模型未知继续显式保留。

处置：waiting。十四项机制仍缺从逐项到联合生产消费者的完整校准及部分后继；现有局部公式和材料夹具不足认证整包，保持waiting，不把经验入库当完整源码兑现。


## 当前源码、验证要求与回退

相关 21 个源码叶中 17 个与冻结 live 08e9a15b79882302eb7bfe38e7ddddc2e40b2dbd 完全相同，其余 4 个仅历史 Roy/Dai 注释差；只证明所列叶范围，不冒称全树等价或原 dirty 输入已冻结。原 19 叶较上次 001301-s2 基线有 4 叶变化：计算下注重抽接续、已观察升级投斧紧勒后续及沙坑当前结束作用域/钨棍窄项，逐差在 source-since-prior.patch。新增窄项的实际源码祖先核在 source-audit.json；它们不补齐本批联合消费者、接管内部动作、夜魇合法复制后继或受控整战。未知持有价的现有 silentPotionReference 明确 hold_hp=null 和限制，不能把旧成本记0当已校准零价值，也没有据此拟新药价。

普通单弃 bf423c173d3be348a4ad714e1d26516df619ff41、毒胜保血搜索 222445a9bb6bf56cb4f3ceea2cc8b20fba54128f、幽灵单层 96f17377a331e50ea5b6a3fe8d2b605932ed1bd4 均核为本基线和实际 live 祖先，仅覆盖相应子项。3da1a93c04efa46f73fc2522af56bb1e4aff726e 是经验数据提交，不能替代幽灵源码证明。当前有限源叶和旧基线均不能重建各局原 code+dirty 的全部源码/知识输入。

未定位可据本批实帧复现的新源码差异，不制造实现。后续若补机制传播，应固定原牌面、逐步属性、实际弃牌/目标/药槽和尝试身份，从 card-model 到 turn-solver/rollout/combat-plan 核消费者；仅函数存在或经验已入库不足验收。源码撤除应使固定回归失败、恢复后通过，再跑沙箱入口。本次没有生产源码修改，没有撤源码红绿或 tsc/vitest，也没有引用旧绿代替本次测试。tests 三项固定 null，fixes=[]，merged=null。

药价、探索血价、路线/休息与时机参数仍缺同条件完整后继和独立局时间留出；不把同局 SL 当独立样本，不把净差当逐击毛伤，不以有限全败推出必死。其他角色和未观察进阶没有改动。预期行为为保留已证范围和未知，不声称胜率收益；以后有实现时按其独立源码提交逆向回退，保护并行刷新与历史，不整库覆盖。

没有提交、live 合入、eval 行为号、shipped 或未提交源码补丁；未启动上线流程，无合入受阻补丁。无新科学反证或冲突，不重复通知既有异议、不代 ops/watcher/Roy 确认。根请求与宽父不因报告结束关闭。本批不派下级 agent、不联网、不运行 play、不推送、不安装依赖、不读凭据或游戏二进制，不修改账号、模型或 prompt；实际原生模型/推理强度未独立读回，不用任务文字或默认值冒认已切换。只读路径探针的失败和纠正在 diagnostic-notes.md 保留。

提案交运维：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-081302-s2/learner/runs/20261017-081306-6bba5834-1332-4b7b-b72b-4d2ade80cebc-strategy-proposal/proposal.md。完整回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-081302-s2/learner/runs/20261017-081306-6bba5834-1332-4b7b-b72b-4d2ade80cebc-strategy-proposal/report.md。实际入库、自然消费者采用和整战收益均未在本批完成，沿原完成事件交接。

import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PROJECT = Path('/home/dw/Projects/agent-sts2')
OLD = PROJECT / '.worktrees/codex-strategy-silent-20261017-001301-s2/learner/runs/20261017-001307-0c34456a-5948-4d99-b8c9-142978505e2d-strategy-proposal'
BATCH = '20261017-081302-s2-strategy-proposal'


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


stamp = subprocess.check_output(['date', '-Iseconds']).decode().strip()
print(stamp)
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
assert base == 'ac451784ffebed27097bf261bbfaa5ee69c5d4d5'
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
checks = json.loads((OUT / 'material-checks.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
reuse = json.loads((OUT / 'consumer-reuse.json').read_text())
compare = json.loads((OUT / 'prior-evidence-comparison.json').read_text())
assert all(x['same_selected_sha256'] for x in compare)
assert all(x['match'] for x in json.loads((OUT / 'original-manifest.json').read_text()))
results = []
for key, rows in assigned['proposals'].items():
    assert rows[0]['row']['character'] == 'silent'
    latest = rows[-1]['row']
    assert latest['state'] == 'waiting'
    results.append({'id': key, 'state': 'waiting', 'reason': latest['reason']})
save('proposal-results.json', results)

prior = (OLD / 'proposal.md').read_text()
sections = prior.split('## 逐项证据、限制及处置\n', 1)[1].split('## 验证、拟合与回退\n', 1)[0]
proposal = f'''# 本批静默猎手策略提案逐项核验

时间：{stamp}。批次：{BATCH}。base：{base}。

本批只消费根 learn.json 明确领取的十个 CLI id；task=strategy-proposal、character=silent、worktree 与本树一致，无 research_request / implementation_request / proposal_repair。普通专题文件绑定另一旧批次，因此未承接专题、未读取其他专题替代身份。开工 git status 干净，按要求 merge main 返回 Already up to date，HEAD 未变。十份原提案的 Markdown 原字节和 SHA 全匹配，保存在 originals/；原队列行、物理偏移及最新处置在 assigned-proposals.json。

十个派发锚点与原提案内五个补充局分列，共十五局均为 SILENT，A9 三局、A10 十二局。逐局身份与原 runs 字节位置在 verified-runs.json，不读取其他角色知识。八流共 {sum(sum(x['counts'].values()) for x in manifest):,} 个所属封套，保存逐流截点、每行 offset/bytes/SHA 与计数，并原位回读逐行核对 JSON 和显式局身份。八流选中封套与原 001301-s2 相同；本批没有新增独立局或新 SL 样本。各流截点分别冻结，不冒称同一时刻快照。fight-plans 零匹配只表示本次截点未选到，不能推断原日志不存在。旧 run-plans 的 8707455 字节截点另存 evidence-old-run-plans/，不覆盖本次或历史输出。

{checks['count']} 项固定材料断言核对实帧、净差与同上限跨幕回复；它们不是生产测试或新的机制支持分母。六个旧离线消费者输入按本次封套重建后 SHA 相同，递归六模块、原输出及 stderr 也逐 SHA 核；只复用原结果，没有重跑消费者、模型、模拟或在线 API。1627 状态、1530 带 ID 动作、447 候选段的完整候选结果仍为 null；275 轮窗中 144 个 observed_turn_endpoints、1530 动作中 1097 个 observed_endpoints。完整认证缺失不等于实际未执行。7X 的接续身份缺口与手工可核的一次 7 毒实帧分别记录。

以下逐项证据和限制沿原已核局号/层/回合重新核验，所有十项仍 waiting。既有 46 个账本的状态与提案的等待状态分开；41 个既有 shipped、5 个既有 proposed 均保留，不把已有经验数据上线当宽提案完成。只经根 ledger CLI 补本批 where/note，保留 claim、首证、prior、evidence、status、version、effect 与历史前缀，不重复 support/repeat，不新建重复代码提案。

## 逐项证据、限制及处置

{sections}
## 当前源码、验证要求与回退

相关 21 个源码叶中 17 个与冻结 live {source['live_head']} 完全相同，其余 4 个仅历史 Roy/Dai 注释差；只证明所列叶范围，不冒称全树等价或原 dirty 输入已冻结。原 19 叶较上次 001301-s2 基线有 4 叶变化：计算下注重抽接续、已观察升级投斧紧勒后续及沙坑当前结束作用域/钨棍窄项，逐差在 source-since-prior.patch。新增窄项的实际源码祖先核在 source-audit.json；它们不补齐本批联合消费者、接管内部动作、夜魇合法复制后继或受控整战。未知持有价的现有 silentPotionReference 明确 hold_hp=null 和限制，不能把旧成本记0当已校准零价值，也没有据此拟新药价。

普通单弃 bf423c173d3be348a4ad714e1d26516df619ff41、毒胜保血搜索 222445a9bb6bf56cb4f3ceea2cc8b20fba54128f、幽灵单层 96f17377a331e50ea5b6a3fe8d2b605932ed1bd4 均核为本基线和实际 live 祖先，仅覆盖相应子项。3da1a93c04efa46f73fc2522af56bb1e4aff726e 是经验数据提交，不能替代幽灵源码证明。当前有限源叶和旧基线均不能重建各局原 code+dirty 的全部源码/知识输入。

未定位可据本批实帧复现的新源码差异，不制造实现。后续若补机制传播，应固定原牌面、逐步属性、实际弃牌/目标/药槽和尝试身份，从 card-model 到 turn-solver/rollout/combat-plan 核消费者；仅函数存在或经验已入库不足验收。源码撤除应使固定回归失败、恢复后通过，再跑沙箱入口。本次没有生产源码修改，没有撤源码红绿或 tsc/vitest，也没有引用旧绿代替本次测试。tests 三项固定 null，fixes=[]，merged=null。

药价、探索血价、路线/休息与时机参数仍缺同条件完整后继和独立局时间留出；不把同局 SL 当独立样本，不把净差当逐击毛伤，不以有限全败推出必死。其他角色和未观察进阶没有改动。预期行为为保留已证范围和未知，不声称胜率收益；以后有实现时按其独立源码提交逆向回退，保护并行刷新与历史，不整库覆盖。

没有提交、live 合入、eval 行为号、shipped 或未提交源码补丁；未启动上线流程，无合入受阻补丁。无新科学反证或冲突，不重复通知既有异议、不代 ops/watcher/Roy 确认。根请求与宽父不因报告结束关闭。本批不派下级 agent、不联网、不运行 play、不推送、不安装依赖、不读凭据或游戏二进制，不修改账号、模型或 prompt；实际原生模型/推理强度未独立读回，不用任务文字或默认值冒认已切换。只读路径探针的失败和纠正在 diagnostic-notes.md 保留。

提案交运维：{OUT / 'proposal.md'}。完整回报：{OUT / 'report.md'}。实际入库、自然消费者采用和整战收益均未在本批完成，沿原完成事件交接。
'''
(OUT / 'proposal.md').write_text(proposal)

rows = '\n'.join(f"| {m['stream']} | {sum(m['counts'].values())} | {m['source_size']} |" for m in manifest)
report = f'''# 静默猎手策略批次回报

批次 {BATCH}；时间 {stamp}；base={base}。

十个已领取提案均 waiting，逐项局号/层/回合、46 个账本、反例、旧规则/预期行为、验证和回退见 proposal.md、proposal-results.json。没有源码/知识改动、提交、live 合入、版本或 shipped；没有可兜底的未提交源码。fixes=[]，merged=null，tests={{"tsc":null,"vitest":null,"cases":null}}。

## 身份和材料

普通队列批次，十原 id、角色与工作树匹配；无专题/实现请求。开工干净，merge main 无新变化。十份原 Markdown SHA 匹配，十五局角色均 SILENT（A9 三局/A10 十二局）；十派发锚点与五原提案补充局分列，未扩展至其他队列或角色。

八流 {sum(sum(m['counts'].values()) for m in manifest):,} 个原封套逐 offset/bytes/SHA/JSON/显式身份读回；{checks['count']} 项材料断言不是生产测试。选中封套 SHA 与旧 001301-s2 相同，新全源截点不增加独立证据。旧 run-plans 截点另提同 SHA，fight-plans 零匹配及 invalid/incomplete 计数保留。

| 流 | 所属行 | 源截点字节 |
|---|---:|---:|
{rows}

## 结论与限制

RC F23T3 逐牌柔嫩/临时敏捷/折扇分源成立，但八组件联合校准仍缺；X F49 幽灵26→1已有窄源码，末T4夜魇标记后即死亡，未有复制后继或延后饮药实线。B F31T2 强制弃牌和 X F48T8 毒胜后32→23已有窄修，不能关闭接管、抽弃重问与联合候选宽项。9Z F48T8 的11→0→20和T10的挡18→27→37可核，不补毛伤/未执行击。7X F31T13 零毒→7、HP25不变再到18只支持该单次组合目标，喝后仍死；MTQ F23T3 少防御多损8/即时伤多6不提供独立整战收益或新探索权重。22跨幕对仍限A9五/A10十七的同上限观察，不充原116局资源模型或低进阶规则。

六个旧离线消费者只经同输入/输出/stderr与六递归依赖 SHA 复用：1627帧/1530带ID动作/447段，144轮端点/1097动作端点；完整候选认证全null不等未执行，本批新消费者执行为0。21源码叶17同当前冻结live、4仅历史署名差；旧窄实现和新增限定修复均按实际祖先核，不认证原dirty全树或宽提案完成。

## 验证与交接

本批没有源码撤除失败/恢复通过、tsc/vitest 或提交前 gitleaks 成功声明，均未运行。源码/知识/index保持零差异，HEAD保持base，scratch仅在本批learner/runs中。根账本只经CLI追溯，不重support/repeat、不改claim/首证/prior/evidence/status/version/effect或shipped；实际CLI及字段保护结果见 ledger-preservation.json 和最终读回。

提案交运维：{OUT / 'proposal.md'}。报告：{OUT / 'report.md'}。机器回执 result.json；每个 id 的具体等待理由见 proposal-results.json。没有新代码、合入、版本或自然采用声明，原宽父继续开放。运行模型/推理强度未独立核原生请求；不冒默认配置已核。未派子agent，不运行play或网络，不改其他角色、账号、prompt或原记录。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
          'base': base, 'runs': assigned['batch']['runs'], 'fixes': [], 'skipped': [],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': list(assigned['proposals']), 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
save('result.json', result)
print(json.dumps({'proposal_results': len(results), 'report': str(OUT / 'report.md')}))

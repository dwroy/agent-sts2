import hashlib
import json
import re
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-004302-s2/learner/runs/20261016-004305-4f179d2a-7bdb-4cef-99d3-b42d91f39db7-strategy-proposal')
FLOORS = {'RC61MFQM63Y6': {17, 23, 29, 33}, 'BTSRF7JL1W1Y': {17, 30, 31},
          'XTSV1U9JD34T': {33, 48, 49}, '9Z9H2EXKLF3T': {35, 38, 39, 42, 45, 47, 48},
          '7X0W3U8TVA2A': {30, 31}, 'MTQ0EUBJ3R6T': {11, 17, 19, 20, 23}}
sha = lambda b: hashlib.sha256(b).hexdigest()
runs = {run: rows[0]['row'] for run, rows in json.loads((OUT / 'verified-runs.json').read_text()).items()}
inputs = {run: {'run': runs[run], 'states': [], 'decisions': []} for run in FLOORS}
excluded = []
for stream in ('states', 'decisions'):
    with (OUT / 'evidence' / (stream + '.evidence.jsonl')).open() as f:
        for line in f:
            item = json.loads(line)
            run, row = item['run_id'], item['row']
            if run not in inputs:
                continue
            floor = row.get('floor') if stream == 'decisions' else (row['state'].get('run') or {}).get('floor')
            if floor not in FLOORS[run]:
                continue
            if stream == 'decisions' and not row.get('decision_id'):
                excluded.append({k: item[k] for k in ('run_id', 'line', 'offset', 'bytes', 'sha256')})
                continue
            inputs[run][stream].append(dict(row, _line=item['line']))

old_base = json.loads((OLD / 'source-audit.json').read_text())['base']
pending = [ROOT / 'learner/audit-selection.ts']
modules = {}
while pending:
    path = pending.pop().resolve()
    name = str(path.relative_to(ROOT))
    if name in modules:
        continue
    raw = path.read_bytes()
    prior = subprocess.check_output(['git', 'show', old_base + ':' + name], cwd=ROOT)
    assert raw == prior, name
    modules[name] = sha(raw)
    for target in re.findall(r'(?:from\s+|import\s*)["\x27](\.[^"\x27]+)["\x27]', raw.decode()):
        dependency = (path.parent / target).with_suffix('.ts')
        assert dependency.is_file(), dependency
        pending.append(dependency)

receipts = json.loads((OLD / 'consumer/receipts.json').read_text())
summary = []
for receipt in receipts:
    run = receipt['run_id']
    current_input = (json.dumps(inputs[run], ensure_ascii=False) + '\n').encode()
    directory = OLD / 'consumer'
    input_path = directory / (run + '.input.json')
    output_path = directory / (run + '.audit.json')
    assert sha(current_input) == receipt['input_sha256'] == sha(input_path.read_bytes()), run
    assert sha(output_path.read_bytes()) == receipt['output_sha256'], run
    assert receipt['exit_code'] == 0
    value = json.loads(output_path.read_text())
    assert all(s['actual_full_candidate_result'] is None for s in value['segments'])
    summary.append({'run_id': run, 'old_receipt': receipt, 'input': str(input_path),
                    'output': str(output_path), 'same_input_sha256': sha(current_input),
                    'states': len(inputs[run]['states']), 'decisions': len(inputs[run]['decisions']),
                    'summary': value.get('summary'), 'segments': len(value['segments']),
                    'all_complete_candidate_results_null': True, 'rerun': False})

report = {'kind': 'verified_reuse_of_existing_offline_results_not_new_execution',
          'old_base': old_base, 'unchanged_consumer_modules': modules,
          'excluded_metadata': excluded, 'runs': summary}
(OUT / 'consumer-reuse.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'unchanged_modules': len(modules), 'reused_runs': len(summary),
                  'states': sum(s['states'] for s in summary), 'decisions': sum(s['decisions'] for s in summary),
                  'segments': sum(s['segments'] for s in summary), 'excluded': len(excluded),
                  'new_consumer_executions': 0}))

import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')


def load(name):
    return json.loads((HERE / name).read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=TREE)


report = load('report.json')
dispatch = load('dispatch.json')
head = git('rev-parse', 'HEAD').decode().strip()
status = git('status', '--short').decode()
diff = git('diff', '--binary', 'HEAD')
(HERE / 'tracked-diff.patch').write_bytes(diff)
assert head == report['base'] and len(head) == 40
assert status == '' and diff == b'' and git('diff', '--cached', '--binary') == b''
assert report['runs'] == dispatch['runs']
assert report['code_proposals'] == dispatch['proposal_ids']
assert {r['id'] for r in report['proposal_results']} == set(dispatch['proposal_ids'])
assert len(report['proposal_results']) == 10 and all(r['state'] == 'waiting' and r['reason'] for r in report['proposal_results'])
assert report['merged'] is None and report['fixes'] == [] and report['implementation_domains'] == []
assert report['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert str(HERE / 'report.md') == report['report']
assert '账本CLI追溯待执行' not in (HERE / 'report.md').read_text()
assert (HERE / 'proposal.md').is_file()
for p in load('assigned-proposals.json'):
    assert digest(HERE / (p['id'] + '.original.md')) == p['proposal_sha256']
for leaf in load('source-audit.json')['paths']:
    assert digest(TREE / leaf['path']) == leaf['base_sha256']
assert load('gitleaks-exit.json')['returncode'] == 0
assert load('gitleaks-report.json') == []
receipt = load('ledger-cli-receipt.json')
assert receipt['returncode'] == 0 and receipt['updates'] == 46 and receipt['protected_fields_unchanged']
with (ROOT / 'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    for event in load('ledger-owned-events.json'):
        handle.seek(event['offset'])
        raw = handle.read(event['bytes'])
        assert hashlib.sha256(raw).hexdigest() == event['sha256']
        assert json.loads(raw) == event['row']
verification = load('verification-summary.json')
assert verification['rows'] == 22424 and verification['material_checks'] == 60
assert all(c['matches'] for c in load('material-checks.json'))
final = {'head': head, 'base_matches': True, 'git_status': status, 'tracked_diff_bytes': len(diff),
         'proposals': 10, 'waiting': 10, 'ledger_updates': 46,
         'protected_ledger_fields_unchanged': True, 'ledger_physical_events_verified': 46,
         'raw_rows_verified': verification['rows'], 'material_checks': verification['material_checks'],
         'gitleaks': 0, 'gitleaks_findings': 0, 'source_tests': report['tests'],
         'commits': [], 'merged': None, 'release': None, 'consumer_rerun': False}
(HERE / 'completion-validation.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
artifacts = [{'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}
             for path in sorted(HERE.rglob('*')) if path.is_file() and path.name != 'artifact-sha256.json']
(HERE / 'artifact-sha256.json').write_text(json.dumps(artifacts, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(final, ensure_ascii=False))

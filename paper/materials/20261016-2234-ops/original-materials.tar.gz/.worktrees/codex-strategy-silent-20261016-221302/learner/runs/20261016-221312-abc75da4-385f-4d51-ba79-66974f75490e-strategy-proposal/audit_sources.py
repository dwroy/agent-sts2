import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261016-114302/learner/runs/20261016-114307-75d5ad4a-6d8e-424a-8062-367d968e85af-strategy-proposal'


def git(*args, cwd=TREE):
    return subprocess.check_output(['git', *args], cwd=cwd)


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


old = json.loads((PRIOR / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live_head = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
paths = [x['path'] for x in old['paths']]
paths += ['agent/src/reflex/passive-pieces.ts', 'agent/src/sim/route-projection.ts',
          'agent/src/knowledge/potion-values.ts']
rows = []
for path in paths:
    own = (TREE / path).read_bytes()
    actual = (LIVE / path).read_bytes()
    prior = (PRIOR.parents[2] / path).read_bytes()
    assert own == git('show', base + ':' + path)
    committed = git('show', live_head + ':' + path)
    rows.append({'path': path, 'base_sha256': hashlib.sha256(own).hexdigest(),
                 'live_sha256': hashlib.sha256(actual).hexdigest(),
                 'base_blob': git('rev-parse', base + ':' + path).decode().strip(),
                 'live_blob': git('rev-parse', live_head + ':' + path).decode().strip(),
                 'same_live': own == actual, 'live_dirty': actual != committed,
                 'same_prior_tree': own == prior})
commits = [x['commit'] for x in old['scoped_ancestors']]
commits += ['1698adc96ba434a46942321e0237b70657e625b2',
            '04921bd785ac6838066522f91ea0bb6ab95cb6a1',
            'd91f9600286a67480b5044e019dbb1041e2239af']
ancestors = []
for commit in commits:
    ancestors.append({'commit': commit,
                      'subject': git('show', '-s', '--format=%s', commit).decode().strip(),
                      'base_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, base], cwd=TREE).returncode == 0,
                      'live_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live_head], cwd=TREE).returncode == 0})
save('source-audit.json', {'base': base, 'live_head': live_head, 'paths': rows,
                           'scoped_ancestors': ancestors})
(HERE / 'source-since-prior.patch').write_bytes(git('diff', '--binary', old['base'], base, '--', *paths))
(HERE / 'live-source-differences.patch').write_bytes(git('diff', '--binary', base, live_head, '--', *paths))
consumer_receipts = json.loads((PRIOR / 'prior-consumer-artifacts-verified.json').read_text())
for row in consumer_receipts:
    p = Path(row['path'])
    assert p.stat().st_size == row['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
save('prior-consumer-artifacts-verified.json', consumer_receipts)
summary = json.loads((PRIOR / 'prior-consumer-summary-readback.json').read_text())
assert len(summary) == 12 and all(x['rc'] == 0 for x in summary)
save('prior-consumer-summary-readback.json', summary)
print(json.dumps({'source_paths': len(rows), 'same_live': sum(x['same_live'] for x in rows),
                  'same_prior_tree': sum(x['same_prior_tree'] for x in rows),
                  'dirty_live': sum(x['live_dirty'] for x in rows),
                  'ancestors': ancestors, 'prior_consumer_artifacts_verified': len(consumer_receipts),
                  'consumer_rerun': False}, ensure_ascii=False))

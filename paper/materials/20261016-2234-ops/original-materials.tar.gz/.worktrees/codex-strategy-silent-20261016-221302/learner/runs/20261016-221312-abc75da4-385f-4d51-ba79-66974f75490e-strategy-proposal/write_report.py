import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
BATCH = '20261016-221302-strategy-proposal'


def load(name):
    return json.loads((HERE / name).read_text())


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


items = load('assigned-proposals.json')
dispatch = load('dispatch.json')
source = load('source-audit.json')
verification = load('verification-summary.json')
raw = load('raw-verification.json')
assert verification['rows'] == sum(x['verified_rows'] for x in raw)
base = source['base']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TREE).decode().strip() == base
clock = (HERE / 'recorded-time.txt').read_text().strip()

details = [
    (
        'RC61MFQM63Y6，A10；F17 T2/T11、F23 T3/T4、F29 T3/T4、F33 T4。',
        'F23 T3敏捷1→6，已打牌的格挡12→21→25；T4敏捷归0。毒雾建立、幻影首刀和折扇被动挡分别核，不补进旧挡。',
        '只认已建立且实际触发的效果；预判、速度药、柔嫩逐牌下降和被动挡分源。当前基础模型存在，不能由此认证八组件联合消费者。',
        '原提案已观察范围内，柔嫩/脆弱/倍率/首刀触发的联合消费仍未完整校准；F33失败不能当基础机制反例，未建立能力无持续收益。',
        '固定重放对应前后帧、出牌/弃牌/用药时点及触发计数，逐项再联合校准；缺组合维持原行为。',
        '缺八组件逐项及联合消费者校准，尤其柔嫩、脆弱、翻倍与首刀/折扇触发组合；局部已有模型不足关闭整项。',
    ),
    (
        'XTSV1U9JD34T，A10；F49六次T1，末次T3/T4。',
        'T1饮幽灵后无实体0→1、16挡；T3仍损22。T4玩家1血、6挡，夜魇建立3复制标记，未进入次轮便死。',
        '一层幽灵保护已有实际live祖先96f17377；复制标记不能直接算已兑现复制。当前最小剩血预测不据原失败单独认定纯bug。',
        '六次均在T1喝，没有延后到T3的实战对照；所有已执行T4候选都死，去掉夜魇能否活仍未知。',
        '冻结T3/T4真实增益、手牌与钳子余挡，核复制后继的可执行性和存活条件；延后饮药须另有同入口整战对照。',
        '幽灵单层已有live子实现；仍缺夜魇可执行复制后继/存活条件消费者和延后饮药整战对照。',
    ),
    (
        'BTSRF7JL1W1Y，A10，F17四试、F30/F31 T2；XTSV1U9JD34T，A10，F48 T8/F49。',
        'B F31 T2生存者实际弃后继牌，原计划13伤/损4，实际净扣8/损14。X F48 T8先付9持牌伤，32→23再赢，23血接F49。',
        '普通单弃与绷带解耦已有bf423c17；毒胜后继续搜索保血已有222445a9。完整候选仍须跨抽弃牌重问题面核执行归属。',
        '修复两个子项不等于接管内部动作、夜魇复制及整战胜因全被解释；耳环接管中间动作未记录。',
        '固定重放真实弃牌并确认后继移除，核毒胜前可打防御；再对照重问后的动作、候选ID和下一轮到手。',
        '单弃和毒胜保血已有live子实现；接管内部动作、夜魇后继及抽弃牌重问后的完整联合候选执行归属仍缺。',
    ),
    (
        'BTSRF7JL1W1Y，A10，F30→F31；XTSV1U9JD34T，A10，F47→F48 T8→F49。',
        'B F30赢仍70→42，下一战42入场；X F47补满97，F48赢仍97→23，F49无恢复23入场。',
        '按实际到达节点传递资源，赢战血价、真实回复、药水消费与SL恢复单列，不能预支未到营火。',
        '没有同条件改线、留药或锻造完整后继；一个获胜战斗的净血差不能拟安全血线或药价。',
        '固定相邻节点入/出HP和药槽，逐源核消费者输入；新策略须另核相同条件完整后继并按独立局留出。',
        '缺逐源资源消费者校准及同条件改线、留药、锻造完整后继；端点证据不能拟安全血线或药价。',
    ),
    (
        'BTSRF7JL1W1Y，A10，F17胜试T5/F31 T2末轮；XTSV1U9JD34T，A10，F48 T8/F49 T1—T4。',
        '步法建立不补旧挡；X F49 T1幽灵16挡、次轮钳子留10，T2末余5到T3，实损22；末T4 1血+6挡仍不足16攻。',
        '敏捷、脆弱、覆甲、毒触发、临时减力撤回与留挡按各自时点消费，已有部分基础模型。',
        '完整临时撤回/敌成长/毒与留挡联合输入未齐；幽灵早喝有本轮兑现，缺延后喝药整战胜线。',
        '按固定实帧逐源复现实际牌挡、临时力量和下一轮留挡，不以若干单机制测试认证十二项组合。',
        '临时属性撤回、毒触发、留挡及敌成长的分源联合生产回放未齐，不能把已有局部机制整包判duplicate。',
    ),
    (
        '9Z9H2EXKLF3T，A10；F35、F48三试T7/T8/T10/T11。',
        '末T8首挡32仍复活20；T10新增18+9+10=37挡仍损15。T11敌112→32与39+38毒、3反伤一致；实际死亡后未执行击不预支反伤。',
        '模拟净差、实盘净差和整战终局分账；士兵只翻首张，已消费药水/复活按实记。',
        'T7预计与实际净差不同，后续熔炉时点也变；缺逐击未截断毛伤、完整受控替线，24/24败样本不证明必死。',
        '固定逐牌倍率、持牌伤、死亡/复活/反伤顺序，再核完整候选归属；不由局部差额拟SL或持有价。',
        '缺逐击未截断毛伤、完整候选执行归属和受控整战后继；同盘局部净差不足改变SL规则或持有价。',
    ),
    (
        '十锚点及原提案另列9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0；跨幕F17→18/F33→34，A9/A10分列。9Z局F35—F48。',
        '十五局中22对同上限跨幕转换：A9五对、A10十七对，均符合floor(缺HP×80%)。9Z局24/70→60/70、23/77→66/77。',
        '跨幕、营火、战斗内回复、复活和SL资源恢复分别计；不能将已观察公式外推未见交互或未到节点。',
        '本批不是原116局总体重算，A9胜局不当A10胜线。F34旧投影与后续实际牌组/上限/路线条件不同，不能当同条件因果误差。',
        '本批只重核22对边界；宽资源模型仍需其完整历史输入及路线/休息消费者校准，另核独立路线收益。',
        '22对跨幕公式已核；原116局资源模型的完整输入、路线/休息消费者校准和独立路线收益仍缺，宽请求保持waiting。',
    ),
    (
        '7X0W3U8TVA2A，A10，F31 T1—T12候选/T13实饮；账本0087、0020。',
        '后段0毒→7毒、HP25保持，随后结算25→18；前段既有8毒另算，中段重接25，玩家仍死。',
        '现有observedPoison已有双Boss及恶魔窄入口，后者修饰组合不覆盖本局。未知持有价已有独立标识，不以成本0声称留药无值。',
        '一个目标/完整修饰组合的总增量7，不能隔离基础药效或额外再加头骨；没有既有毒、其他目标及早喝/留药实打对照。',
        '只把0→7当该组合观测，核目标重接及结算顺序；扩大入口须补边界、共同推演及后续机会成本证据。',
        '仅核后段零毒实加7；缺其他目标、既有毒、重接组合共同推演及持有价/时点证据，不能全局扩成7毒。',
    ),
    (
        'MTQ0EUBJ3R6T，A10，F23四试T3；F19/F20资源链，T5/T6终点。',
        '四次T3同10HP/敌61和41HP；前三次29挡/损0/扣13，末次19挡/损8/扣19。末次少挡后仍留防御；原线T6判死、末线T5实死。',
        '既有SL资源审计1698adc9标明current_turn_prediction与execution=unverified，不能把饱和抽样描述为实盘更安全。',
        '四试只是一相关样本，改序也改变后续抽牌/能力建立；没有独立A10留出或相同条件完整后继，不拟8血门槛。',
        '固定两毒素10+敌攻17的27挡需求及实际29/19，分开实盘净差与模型预测；新排序须独立时间留出。',
        '实盘多损8血、多扣6伤已核；缺独立A10留出和受控完整后继，不能据此改饱和探索、必死或药价门槛。',
    ),
    (
        '7X0W3U8TVA2A，A10，F31 T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T，A10，F11 T1/F17 T4—T8/F20 T3/F23 T2—T5。',
        '7X步法+不追补旧7挡；MTQ F23速度5临时敏捷由后续牌兑现，29挡与19挡对应损0与8；磨蚀建立当步不直接补挡。',
        '逐牌敏捷、临时减力、持牌伤、施毒、反伤及昏眩单牌限制分别验收，已建立能力与仅持有能力分开。',
        '十四项存在基础模型及局部夹具，不代表全部已观察联合消费者完成；原dirty知识完整输入、毛伤账及受控后继仍有缺口。',
        '冻结实际手牌/药槽/增益和动作，逐项至联合校准；不从单组合基础毒药效、早建磨蚀或留药反事实拟参数。',
        '十四项机制仍缺逐项至联合生产消费者完整校准；局部模型和夹具不足认证整包，保持waiting。',
    ),
]
assert len(items) == len(details) == 10
results = [{'id': p['id'], 'state': 'waiting', 'reason': d[5]} for p, d in zip(items, details)]
save('dispositions.json', results)
report_json = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
    'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [p['id'] for p in items], 'implementation_domains': [],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
save('report.json', report_json)

proposal = [
    '# 静默猎手：本批十个原提案逐项处置',
    f'记录时间：{clock}。batch={BATCH}；base={base}。',
    '本批是普通proposal_ids消费，不绑定research_request或implementation_request。初始工作树干净，按要求合main返回Already up to date。只处理本批十ID，不另领取提案，不新增重复ID；未派下级agent。',
    '来源任务沿原postmortem/experience-update；本次实现任务strategy-proposal。授权Roy-2026-10-07-learning不提供游戏事实。十五局角色均SILENT，三A9/十二A10；只用本角色原日志、复盘/原提案、账本和角色经验，不借其他角色结论。',
    '每份原Markdown已按队列SHA核对并以<id>.original.md保留原字节。证据封套、原行offset/bytes/SHA与source_size见evidence*/及raw-verification.json。本批缺项分别列明，证据不足的策略保持现状；waiting不是原机制结论被推翻。',
]
for p, d in zip(items, details):
    proposal += [f"## {p['id']}", f"主题：{p['summary'].rstrip('。')}。原领域：{','.join(p['domains'])}。",
                 f"账本：{','.join(p['ledger'])}。来源任务：{p['source_task']} → strategy-proposal。",
                 f"原提案：{p['proposal']}；SHA256={p['proposal_sha256']}。",
                 '证据局/层/回合：' + d[0], '支持：' + d[1],
                 '旧行为与预期行为：' + d[2], '反例、未知与限制：' + d[3],
                 '验证方法：' + d[4], '处置：waiting。' + d[5],
                 '拟合与切分：本批不拟参数，不将SL重放拆成独立局；当前固定观察只作事实核验。未来独立同角色/同进阶完局作时间留出，不以本批同时训练和验证。',
                 '预期影响与回退：如后续证实缺口，预期改善已观察效果的兑现与资源透明性，胜率影响未知。当前无实现无需回退；后续仅逆向实际实现的差量，保留刷新数据和旧证据。其他角色及未观察边界保持等价。']
proposal += ['## 共同验收边界',
             '单弃bf423c17、毒胜保血222445a9、幽灵96f17377、恶魔入口8bb53d63、持有价未知04921bd7及SL资源比较1698adc9已核实际live祖先；这些是已有窄源码，不是本批新增实现或整项duplicate。完整40位提交见source-audit.json。',
             '当前与旧114302基线的二十个核查叶中十八叶相同，两叶只见故障目录/资源诊断透传差量；与本次live切点十六叶相同，四叶是历史Roy/Dai署名差，完整binary差量保留。不能以诊断上线当根资源修复。',
             '旧十二局离线消费者的三十七份输入/输出/错误流材料重新核SHA，原退出0单列；本批未重复运行消费者、模型或模拟。端点核对不认证完整候选执行或自然采用。',
             '没有新增支持/反证样本；同一封套行集合未变不当新局证据。账本只经CLI追加追溯，不重复support/repeat，不更改旧首证、claim、prior、evidence、status、version或shipped。',
             '没有源码/知识变化，没有提交、live合入或新版本；不制造撤源码失败/恢复通过、tsc/vitest成功。材料核验不是生产测试。']
(HERE / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')

counts = '\n'.join(f"| {x['stream']} | {x['verified_rows']} |" for x in raw)
table = '\n'.join(f"| {x['id']} | {x['reason']} |" for x in results)
ancestors = '\n'.join(f"| {x['commit']} | {x['subject']} |" for x in source['scoped_ancestors'])
ledger_file = HERE / 'ledger-cli-receipt.json'
ledger_note = '账本CLI追溯待执行。'
if ledger_file.exists():
    receipt = load('ledger-cli-receipt.json')
    assert receipt['returncode'] == 0 and receipt['protected_fields_unchanged']
    ledger_note = f"{receipt['updates']}个既有账本只经根learner/ledger.py update追加本批proposal/report路径与note，by=learner:strategy-proposal；CLI退出0、旧物理前缀及私有fold保护字段和历史前缀均核。未将旧shipped条目降为proposed，不增加重复证据，不标shipped。"
report = f'''# 静默猎手策略提案回报

本批十个原提案全部waiting。未修改源码或知识，没有提交、live合入、新版本或shipped；不把已有窄实现当整项完成。逐项证据、账本、反例、拟合边界、预期行为及验证/回退见[proposal.md](proposal.md)。

时间：{clock}。batch={BATCH}；完整base/HEAD=`{base}`。普通派发身份、十ID、锚点和工作树匹配；没有专题或implementation绑定。初始干净，合main为Already up to date。本批未派下级agent、未联网、未调用LLM或游戏、未运行play。

## 证据核验

十五局均为SILENT：A9三局，A10十二局；十派发锚点外五局仅来自原提案证据。共用extract_evidence入口提取八流，共{verification['rows']}条，每行重新读原日志offset/bytes并核SHA/JSON/显式身份；states逐帧核角色与进阶。每流截点、计数、无效/未完成行及产物SHA完整保留。

| 流 | 原行核验数 |
|---|---:|
{counts}

本批与旧冻结封套的选中原行集合相同，日志截点增长不算新增样本。fight-plans选中0行只说明该截点未选到，不能断言日志缺失。{verification['material_checks']}项端点/算式核验、22对跨幕转换均通过，属于材料检查。不是生产tsc/vitest，也不是实际候选完整执行认证。

关键结论：RC F23逐牌挡和临时敏捷可核；X F49早喝幽灵有本轮收益但未阻止后段死亡，夜魇3复制标记没有兑现到下一轮；B和X胜战仍耗血，连战按实到23血；9Z倍率挡、复活、毒与实际反伤分账；7X后段零毒实加7后结算到18，不能推广全局药效；MTQ四次T3为29/29/29/19挡、0/0/0/8损血及13/13/13/19净扣，同盘SL相关且整战均败。22对同上限跨幕转换A9五/A10十七，均符合floor(缺HP×80%)，不冒称重跑原116局资源模型。

16条历史run-config的源码commit对象均可定位，dirty记录保留；不能笼统声称全部源码不存在。完整当时知识字节、未记录接管动作、候选归属及受控整战后继仍未知；当前树不能代替历史全部运行输入。

## 当前源码与消费者边界

实际live切点`{source['live_head']}`。二十个核查叶：十八叶与旧114302树相同；本批与live十六叶相同、四叶保留历史署名差，live核查叶无未提交变化。旧基线至本批差量只有combat-plan/rollout的故障目录和资源诊断透传，不据此认为资源根问题已修。完整SHA/blob和binary差量见source-audit.json及两份patch。

以下八个已存在源码commit均核本base与实际live祖先，只说明对应窄子项：

| 实际源码commit | 已有范围 |
|---|---|
{ancestors}

observedPoison除双Boss外还有恶魔组合入口，不能沿用“只有双Boss”旧描述；恶魔组合不覆盖7X后段。未知持有价当前已与零值区分；SL资源比较明确标current_turn_prediction/execution=unverified。以上仍不能认证宽提案的全部联合机制、执行或整战效果。

旧十二局消费者三十七份输入/输出/错误流材料已按原SHA/字节读回，原退出0；消费相关源码未变，本批未重复运行。8622动作、1883片段、3109相邻端点、431可核整轮与974未知整轮是旧材料范围，不能升格完整候选执行、自然采用或生产联合校准；未认证也不证明实际从未执行。

## 十项处置

| 提案ID | waiting原因 |
|---|---|
{table}

没有新增科学反证，不强行支持原宽策略假设。本批保留旧提案、旧失败与限制，不另建重复ID；code_proposals沿用十个既有CLI ID，implementation_domains=[]表示本批没有实现。

## 记录、测试与交付

{ledger_note} 队列处置由宿主按proposal_results机械消费，本模型不手改队列、learn.json或根请求。

源码未改，撤源码失败/恢复通过不适用；sandbox/tsc/vitest未运行，三个tests字段均null。没有空合并、版本或规则上线通知。基线、干净状态、保护字段和secret扫描结果以completion-validation.json及最终产物SHA索引为准。本报告不关闭实际学习入库、量化或原宽父要求，不声称大脑采用或通关提升。不删除自身工作树或原始材料。

运维提案：{HERE / 'proposal.md'}

运维报告：{HERE / 'report.md'}

## 最终机器回报

```json
{json.dumps(report_json, ensure_ascii=False, indent=2)}
```
'''
(HERE / 'report.md').write_text(report)
print(json.dumps({'base': base, 'report': str(HERE / 'report.md'), 'waiting': len(results),
                  'rows': verification['rows'], 'ledger_linked': ledger_file.exists()}, ensure_ascii=False))

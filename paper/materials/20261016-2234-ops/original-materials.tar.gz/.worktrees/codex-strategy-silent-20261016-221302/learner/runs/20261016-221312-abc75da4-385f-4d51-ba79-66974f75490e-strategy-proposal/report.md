# 静默猎手策略提案回报

本批十个原提案全部waiting。未修改源码或知识，没有提交、live合入、新版本或shipped；不把已有窄实现当整项完成。逐项证据、账本、反例、拟合边界、预期行为及验证/回退见[proposal.md](proposal.md)。

时间：2026-10-16T22:24:14+08:00。batch=20261016-221302-strategy-proposal；完整base/HEAD=`59bab95ae7b62682793961bb4b7f643b7fbcc5d2`。普通派发身份、十ID、锚点和工作树匹配；没有专题或implementation绑定。初始干净，合main为Already up to date。本批未派下级agent、未联网、未调用LLM或游戏、未运行play。

## 证据核验

十五局均为SILENT：A9三局，A10十二局；十派发锚点外五局仅来自原提案证据。共用extract_evidence入口提取八流，共22424条，每行重新读原日志offset/bytes并核SHA/JSON/显式身份；states逐帧核角色与进阶。每流截点、计数、无效/未完成行及产物SHA完整保留。

| 流 | 原行核验数 |
|---|---:|
| states | 11008 |
| decisions | 10609 |
| sl-attempts | 109 |
| run-config | 16 |
| run-plans | 97 |
| brain | 570 |
| runs | 15 |
| fight-plans | 0 |

本批与旧冻结封套的选中原行集合相同，日志截点增长不算新增样本。fight-plans选中0行只说明该截点未选到，不能断言日志缺失。60项端点/算式核验、22对跨幕转换均通过，属于材料检查。不是生产tsc/vitest，也不是实际候选完整执行认证。

关键结论：RC F23逐牌挡和临时敏捷可核；X F49早喝幽灵有本轮收益但未阻止后段死亡，夜魇3复制标记没有兑现到下一轮；B和X胜战仍耗血，连战按实到23血；9Z倍率挡、复活、毒与实际反伤分账；7X后段零毒实加7后结算到18，不能推广全局药效；MTQ四次T3为29/29/29/19挡、0/0/0/8损血及13/13/13/19净扣，同盘SL相关且整战均败。22对同上限跨幕转换A9五/A10十七，均符合floor(缺HP×80%)，不冒称重跑原116局资源模型。

16条历史run-config的源码commit对象均可定位，dirty记录保留；不能笼统声称全部源码不存在。完整当时知识字节、未记录接管动作、候选归属及受控整战后继仍未知；当前树不能代替历史全部运行输入。

## 当前源码与消费者边界

实际live切点`a0dcde7e6eaf30b3b3edab996a2c7408ab072ea9`。二十个核查叶：十八叶与旧114302树相同；本批与live十六叶相同、四叶保留历史署名差，live核查叶无未提交变化。旧基线至本批差量只有combat-plan/rollout的故障目录和资源诊断透传，不据此认为资源根问题已修。完整SHA/blob和binary差量见source-audit.json及两份patch。

以下八个已存在源码commit均核本base与实际live祖先，只说明对应窄子项：

| 实际源码commit | 已有范围 |
|---|---|
| 96f17377a331e50ea5b6a3fe8d2b605932ed1bd4 | Model observed Silent Ghost in a Jar protection |
| a8b1f8be153fe4f3a34146117546c2178f2e446b | Integrate repaired legacy learning deltas and bounded continuation adapter |
| 8bb53d6342b7e9a2adf96de231b53c36eaa943de | Integrate observed Silent Demon inputs while retaining live fields |
| bf423c173d3be348a4ad714e1d26516df619ff41 | Consume observed Silent Survivor discards without Tough Bandages |
| 222445a9bb6bf56cb4f3ceea2cc8b20fba54128f | Preserve HP before observed Silent poison victories |
| 1698adc96ba434a46942321e0237b70657e625b2 | Complete Silent SL resource comparison audit |
| 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | ops: integrate terminal audit and potion-reference source increments |
| d91f9600286a67480b5044e019dbb1041e2239af | Fix upgraded Anticipate temporary Dexterity in plans |

observedPoison除双Boss外还有恶魔组合入口，不能沿用“只有双Boss”旧描述；恶魔组合不覆盖7X后段。未知持有价当前已与零值区分；SL资源比较明确标current_turn_prediction/execution=unverified。以上仍不能认证宽提案的全部联合机制、执行或整战效果。

旧十二局消费者三十七份输入/输出/错误流材料已按原SHA/字节读回，原退出0；消费相关源码未变，本批未重复运行。8622动作、1883片段、3109相邻端点、431可核整轮与974未知整轮是旧材料范围，不能升格完整候选执行、自然采用或生产联合校准；未认证也不证明实际从未执行。

## 十项处置

| 提案ID | waiting原因 |
|---|---|
| silent-proposal-03754e1265894000 | 缺八组件逐项及联合消费者校准，尤其柔嫩、脆弱、翻倍与首刀/折扇触发组合；局部已有模型不足关闭整项。 |
| silent-proposal-ab055ef7dfbb44e5 | 幽灵单层已有live子实现；仍缺夜魇可执行复制后继/存活条件消费者和延后饮药整战对照。 |
| silent-proposal-0129c465c6f5bd79 | 单弃和毒胜保血已有live子实现；接管内部动作、夜魇后继及抽弃牌重问后的完整联合候选执行归属仍缺。 |
| silent-proposal-abe9d5d0be109a9f | 缺逐源资源消费者校准及同条件改线、留药、锻造完整后继；端点证据不能拟安全血线或药价。 |
| silent-proposal-f16527e59b5cc1e0 | 临时属性撤回、毒触发、留挡及敌成长的分源联合生产回放未齐，不能把已有局部机制整包判duplicate。 |
| silent-proposal-7a8e9ccb7e646538 | 缺逐击未截断毛伤、完整候选执行归属和受控整战后继；同盘局部净差不足改变SL规则或持有价。 |
| silent-proposal-cd9f76184de6e29a | 22对跨幕公式已核；原116局资源模型的完整输入、路线/休息消费者校准和独立路线收益仍缺，宽请求保持waiting。 |
| silent-proposal-292f6731bdb9b669 | 仅核后段零毒实加7；缺其他目标、既有毒、重接组合共同推演及持有价/时点证据，不能全局扩成7毒。 |
| silent-proposal-0802f69b28d25079 | 实盘多损8血、多扣6伤已核；缺独立A10留出和受控完整后继，不能据此改饱和探索、必死或药价门槛。 |
| silent-proposal-763a4b9d9f17b815 | 十四项机制仍缺逐项至联合生产消费者完整校准；局部模型和夹具不足认证整包，保持waiting。 |

没有新增科学反证，不强行支持原宽策略假设。本批保留旧提案、旧失败与限制，不另建重复ID；code_proposals沿用十个既有CLI ID，implementation_domains=[]表示本批没有实现。

## 记录、测试与交付

46个既有账本只经根learner/ledger.py update追加本批proposal/report路径与note，by=learner:strategy-proposal；CLI退出0、旧物理前缀及私有fold保护字段和历史前缀均核。未将旧shipped条目降为proposed，不增加重复证据，不标shipped。 队列处置由宿主按proposal_results机械消费，本模型不手改队列、learn.json或根请求。

源码未改，撤源码失败/恢复通过不适用；sandbox/tsc/vitest未运行，三个tests字段均null。没有空合并、版本或规则上线通知。基线、干净状态、保护字段和secret扫描结果以completion-validation.json及最终产物SHA索引为准。本报告不关闭实际学习入库、量化或原宽父要求，不声称大脑采用或通关提升。不删除自身工作树或原始材料。

运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-221302/learner/runs/20261016-221312-abc75da4-385f-4d51-ba79-66974f75490e-strategy-proposal/proposal.md

运维报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-221302/learner/runs/20261016-221312-abc75da4-385f-4d51-ba79-66974f75490e-strategy-proposal/report.md

## 最终机器回报

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261016-221302-strategy-proposal",
  "base": "59bab95ae7b62682793961bb4b7f643b7fbcc5d2",
  "runs": [
    "RC61MFQM63Y6",
    "XTSV1U9JD34T",
    "BTSRF7JL1W1Y",
    "9Z9H2EXKLF3T",
    "HMVJKM56S4Q8",
    "F4QKG4J1AJJZ",
    "G403VCZ3BH1B",
    "25226ZFLNR1J",
    "JLN5SK17W4FQ",
    "JMH5C51RLN4E"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-03754e1265894000",
    "silent-proposal-ab055ef7dfbb44e5",
    "silent-proposal-0129c465c6f5bd79",
    "silent-proposal-abe9d5d0be109a9f",
    "silent-proposal-f16527e59b5cc1e0",
    "silent-proposal-7a8e9ccb7e646538",
    "silent-proposal-cd9f76184de6e29a",
    "silent-proposal-292f6731bdb9b669",
    "silent-proposal-0802f69b28d25079",
    "silent-proposal-763a4b9d9f17b815"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-03754e1265894000",
      "state": "waiting",
      "reason": "缺八组件逐项及联合消费者校准，尤其柔嫩、脆弱、翻倍与首刀/折扇触发组合；局部已有模型不足关闭整项。"
    },
    {
      "id": "silent-proposal-ab055ef7dfbb44e5",
      "state": "waiting",
      "reason": "幽灵单层已有live子实现；仍缺夜魇可执行复制后继/存活条件消费者和延后饮药整战对照。"
    },
    {
      "id": "silent-proposal-0129c465c6f5bd79",
      "state": "waiting",
      "reason": "单弃和毒胜保血已有live子实现；接管内部动作、夜魇后继及抽弃牌重问后的完整联合候选执行归属仍缺。"
    },
    {
      "id": "silent-proposal-abe9d5d0be109a9f",
      "state": "waiting",
      "reason": "缺逐源资源消费者校准及同条件改线、留药、锻造完整后继；端点证据不能拟安全血线或药价。"
    },
    {
      "id": "silent-proposal-f16527e59b5cc1e0",
      "state": "waiting",
      "reason": "临时属性撤回、毒触发、留挡及敌成长的分源联合生产回放未齐，不能把已有局部机制整包判duplicate。"
    },
    {
      "id": "silent-proposal-7a8e9ccb7e646538",
      "state": "waiting",
      "reason": "缺逐击未截断毛伤、完整候选执行归属和受控整战后继；同盘局部净差不足改变SL规则或持有价。"
    },
    {
      "id": "silent-proposal-cd9f76184de6e29a",
      "state": "waiting",
      "reason": "22对跨幕公式已核；原116局资源模型的完整输入、路线/休息消费者校准和独立路线收益仍缺，宽请求保持waiting。"
    },
    {
      "id": "silent-proposal-292f6731bdb9b669",
      "state": "waiting",
      "reason": "仅核后段零毒实加7；缺其他目标、既有毒、重接组合共同推演及持有价/时点证据，不能全局扩成7毒。"
    },
    {
      "id": "silent-proposal-0802f69b28d25079",
      "state": "waiting",
      "reason": "实盘多损8血、多扣6伤已核；缺独立A10留出和受控完整后继，不能据此改饱和探索、必死或药价门槛。"
    },
    {
      "id": "silent-proposal-763a4b9d9f17b815",
      "state": "waiting",
      "reason": "十四项机制仍缺逐项至联合生产消费者完整校准；局部模型和夹具不足认证整包，保持waiting。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-221302/learner/runs/20261016-221312-abc75da4-385f-4d51-ba79-66974f75490e-strategy-proposal/report.md"
}
```

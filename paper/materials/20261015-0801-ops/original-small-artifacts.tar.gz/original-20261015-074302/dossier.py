import json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2')
S=[json.loads(l) for l in (p/'states.jsonl').open()]
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]
R=json.loads((p/'REEBQHPHSWGK-resources.json').read_text())
names={e['enemy_id']:e['name'] for d in S for e in (d['state'].get('combat') or {}).get('enemies',[])}
short={'HEART_OF_IRON':'铁','BLOCK_POTION':'挡','SPEED_POTION':'速','FIRE_POTION':'火','WEAK_POTION':'弱','SKILL_POTION':'技','DUPLICATOR':'复','POWER_POTION':'能'}
def pots(x):return '、'.join(str(slot)+short[id] for slot,id in x) or '空'
rows=['| 战斗／尝试 | HP进→出（净变化） | 槽位药水进→出 | states证据、UTC入口→退出／末帧 | 结局 |','| --- | --- | --- | --- | --- | --- |']
turnrows=[]
for c in R['combats']:
 a=c['entry'];b=c['exit'] or c['last'];frames=[s for s in S if a['line']<=s['_line']<=b['line']]
 ids=list(dict.fromkeys(e['enemy_id'] for d in frames for e in (d['state'].get('combat') or {}).get('enemies',[])))
 title='F'+str(c['floor'])+' '+('首试' if c['sequence']==16 else '第2试' if c['sequence']==17 else '')+'／'.join(names[i]+' '+i for i in ids)
 out='退出未记录，末'+str(b['hp']) if not c['exit'] else str(b['hp'])
 loss='已见'+str(b['hp']-a['hp']) if not c['exit'] else str(b['hp']-a['hp'])
 result='T7判死，SL2158' if c['sequence']==16 else 'T6胜，SL2159' if c['sequence']==17 else 'T6实死，无本场SL' if c['floor']==45 else 'T'+str(c['last']['turn'])+'胜'+('，SL2157' if c['floor']==17 else '')
 rows.append(f"| {title} | {a['hp']}→{out}（{loss}） | {pots(a['potions'])}→{pots(b['potions'])} | s{a['line']}→{b['line']}；{a['ts'][11:19]}→{b['ts'][11:19]} | {result} |")
 turns=[]
 for d in frames:
  s=d['state'];t=s.get('turn')
  if not s.get('in_combat') or t is None or turns and turns[-1]['turn']==t:continue
  enemies=[e for e in (s.get('combat') or {}).get('enemies',[]) if e['is_alive']]
  turns.append({'turn':t,'hp':s['run']['current_hp'],'enemy_hp':sum(e['current_hp'] for e in enemies),'line':d['_line']})
 chain=[t['hp'] for t in turns]+[b['hp']];enemy=[t['enemy_hp'] for t in turns]
 turnrows.append({'sequence':c['sequence'],'floor':c['floor'],'hp':chain,'net_loss_each':[chain[i]-chain[i+1] for i in range(len(chain)-1)],'live_enemy_hp_at_turn_start':enemy,'turn_start_lines':[t['line'] for t in turns],'last_enemy_hp':sum(e['current_hp'] for e in (frames[-1]['state'].get('combat') or {}).get('enemies',[]) if e['is_alive'])})
(p/'resource-table.md').write_text('\n'.join(rows)+'\n')
(p/'turn-chains.json').write_text(json.dumps(turnrows,ensure_ascii=False,indent=2)+'\n')
proof=[]
for name in ['states','decisions','brain','run-plans','sl-attempts','run-config']:
 with (root/'logs'/f'{name}.jsonl').open('rb') as source:
  for l in (p/f'{name}.jsonl').open():
   d=json.loads(l);n=d.pop('_line');offset=d.pop('_offset');source.seek(offset);raw=source.readline();actual=json.loads(raw)
   assert actual==d,(name,n)
   proof.append({'file':f'logs/{name}.jsonl','line':n,'offset':offset,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(p/'evidence-manifest.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
identity=json.loads((p/'source-identity.json').read_text());head=identity['read_head']
for file in identity['files']:
 raw=subprocess.check_output(['git','-C',str(root/'.worktrees/live'),'show',f'{head}:{file}'])
 (p/('source-'+Path(file).name)).write_bytes(raw)
print('original-byte evidence verified',len(proof),'table rows',len(R['combats']))
print('potion evidence')
for d in D:
 if (d.get('chosen') or {}).get('action') not in ['use_potion','discard_potion','buy_potion']:continue
 a=max((s for s in S if s['ts']<=d['ts']),key=lambda s:s['ts']);b=next(s for s in S if s['ts']>d['ts'])
 print(d['_line'],d['floor'],d['turn'],d['chosen']['action'],a['_line'],b['_line'],b['ts'],[(x['index'],x['potion_id']) for x in b['state']['run']['potions'] if x['occupied']])

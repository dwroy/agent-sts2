import json,collections,re
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]
S=[json.loads(l) for l in (p/'states.jsonl').open()]
def candidate(d):
 q=d.get('questions') or {}; a=d.get('answers') or {};result=[]
 for k,v in q.items():
  c=(a.get(k) or {}).get('choice')
  if c in (v.get('criteria') or {}):
   raw=v['criteria'][c]
   try:raw=json.loads(raw)
   except (TypeError,ValueError):pass
   result.append((k,c,raw))
 return result
with (p/'decisions-summary.txt').open('w') as f:
 for d in D:
  if d['decider']=='codex' or d['floor'] in [17,33,39,43,44,45] and d['label'].startswith(('combat/','selection/')):
   o={'line':d['_line'],'ts':d['ts'],'floor':d['floor'],'turn':d['turn'],'reloads':d.get('sl_reloads',0),'decider':d['decider'],'label':d['label'],'action':d.get('chosen'),'expect':d.get('expect'),'rationale':d['rationale'],'journal':d.get('journal'),'boss_sim':d.get('boss_sim')}
   if d['decider']=='jev':
    o['candidate']=[(k,c,{kk:vv for kk,vv in v.items() if kk not in ['quantitative_turn','turn_model','boss_evaluation']}) for k,c,v in candidate(d) if isinstance(v,dict)]
    o['audit']=d.get('selection_audit')
   f.write(json.dumps(o,ensure_ascii=False)+'\n')
with (p/'states-summary.txt').open('w') as f:
 for d in S:
  s=d['state'];run=s.get('run') or {}
  if run.get('floor') in [33,39,43,44,45]:
   c=s.get('combat') or {}
   o={'line':d['_line'],'ts':d['ts'],'floor':run.get('floor'),'turn':s.get('turn'),'screen':s.get('screen'),'hp':run.get('current_hp'),'player':c.get('player'),'enemies':[{k:v for k,v in e.items() if k in ['index','enemy_id','name','current_hp','max_hp','block','powers','intents','is_alive']} for e in c.get('enemies',[])], 'hand':c.get('hand'),'selection':s.get('selection')}
   f.write(json.dumps(o,ensure_ascii=False)+'\n')
print('first state keys',list(S[0]['state']))
print('combat keys',list(next(s['state']['combat'] for s in S if s['state'].get('in_combat'))))
print('summaries written')

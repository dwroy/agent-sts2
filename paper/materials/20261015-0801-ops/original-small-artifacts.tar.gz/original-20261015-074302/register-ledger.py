import json,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2');run='REEBQHPHSWGK'
updates=[
 ('silent-0106',6,'support','F45以41/70及能力／速度两药进三骑士；初294，T1净推进86仍三敌活，T3连枷退、T6幽灵退。T5魔法40对23挡令22→5；末T6 5血6挡对11死、魔法41。仅补后段击杀／生存窗口观察，无不同focus整场对照，不将死亡强作同项选线错误repeat。'),
 ('silent-0418',6,'support','d395131原选投掷匕首→生存者，模型8挡／损3／余2、8/8五轮赢；d395132实际弃生存者且标移除计划后继，代码废弃旧线重算，s407719—407722改斗篷6挡、魔法11攻对5血而死。补候选不能冒记完整实线及已正确失效审计；未证该审计旧bug重犯。'),
 ('silent-0461',6,'repeat','d395131 plan2普通斗篷＋生存者报cards_drawn=1，d395133自主打斗篷理由drawing first；s407719→407720能量1→0、挡0→6，仅添SHIV一张、无牌堆抽牌。只读live52046a3 card-model.ts:1028、turn-solver.ts:2532/2564仍同生成误抽语义；fix-queue未列，旧observed缺口，不把整场死亡归单因。'),
 ('silent-0043',6,'support','F45六次轮初手套消耗进阶之灾／打击／致命毒药／打击／中和／计算下注，力量逐轮1→6；末小刀基础4＋6力量实直扣10，再群蛇4，魔法55→41。只补已观察力量／消耗兑现，不规定固定消耗目标。'),
 ('silent-0132',4,'support','F45T1群蛇实际建4；T3两防御各10挡并分别扣魔法75→71、幽灵75→71，T4萎靡后魔法71→67。只记后续已出牌的4伤，不计建立前或尚未活到的未来牌伤。'),
 ('silent-0253',3,'support','F45T3饮速度槽1，s407702→407703建5临时敏捷、旧挡0不变，后两防御各10共20、相对两基础5挡多10；余两敌23攻实损3，T4敏捷归0。未验证别的药水时点整战胜率。'),
 ('silent-0280',4,'support','F45T3已有DAMPEN_POWER1；T4现场萎靡普通X、run.deck仍upgraded=true。T5带华彩冲刺现场普通10挡、重放1，所持场外另有升级冲刺；只补战内／场外升级分账，不外推抑制与自动升级完整先后。'),
 ('silent-0401',1,'support','F45T1 s407688→407689第三次攻击打击使连枷65→55，魔法89→83另扣6；s407691→407692小刀第三张使连枷41→34而幽灵97→91另扣6。锁镰随机落点不恒跟最低血连枷；不估概率或杀序胜因。')]
receipts=[]
for ident,turn,role,note in updates:
 item={'id':ident,'by':'learner:postmortem','evidence':[{'run':run,'floor':45,'turn':turn,'role':role,'note':note}],'where':{'lessons':[run]},'note':'本次只追加该角色实证与复盘去处；保留原claim、首证、prior、状态和版本。来源任务20261015-074302-daf9c28c-d87a-4d3e-8723-e6ceba254cb1-postmortem。'}
 (p/f'{ident}-update.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n')
 subprocess.run(['date','+%Y-%m-%d %H:%M:%S %Z'],check=True)
 r=subprocess.run(['python3',str(root/'learner/ledger.py'),'update'],input=json.dumps(item,ensure_ascii=False),capture_output=True,text=True)
 receipts.append({'action':'update','id':ident,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 (p/'ledger-cli-results.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')
 print(ident,r.returncode,r.stdout.strip());assert r.returncode==0,r.stderr
item={'character':'silent','by':'learner:postmortem','kind':'mechanic','claim':'已观察静默A10持剃刀牙RAZOR_TOOTH与亮片GLITTER、玩家有抑制DAMPEN_POWER时，普通华彩冲刺DASH牌文10挡／重放1／2费，单个控制器施放后实际得23挡、能量3→1。10＋升级13与合计23相符，但缺两次自动结算间帧，只记该组合整体值，不推广升级先后或所有重放牌；当题两牌方案只报20挡，修正校准不等整场能赢。','first_run':run,'prior':'unknown','prior_runs':[],'prior_note':'检索silent账本与该角色更早复盘，只见silent-0478蛇咬施毒组合；没有华彩冲刺＋剃刀牙＋抑制同盘面23挡的明确记录，无可比较先验。','status':'observed','evidence':[{'run':run,'floor':45,'turn':5,'role':'support','note':'s407710→407711：普通冲刺文本虚无／10挡／15伤／重放1，实际玩家挡0→23、能量3→1，敌幽灵71→30；d395124参考报两牌20挡、损20，实际末23挡／损17。输出差额含群蛇与其他机制，不独立归因。'}],'where':{'lessons':[run]},'note':'来源任务postmortem，20261015-074302-daf9c28c-d87a-4d3e-8723-e6ceba254cb1-postmortem；只新增有限组合机制，通过独立strategy-proposal核验和实现，不冒称上线。'}
(p/'new-mechanic-add.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['date','+%Y-%m-%d %H:%M:%S %Z'],check=True)
r=subprocess.run(['python3',str(root/'learner/ledger.py'),'add'],input=json.dumps(item,ensure_ascii=False),capture_output=True,text=True)
receipts.append({'action':'add','returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
(p/'ledger-cli-results.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')
print('add',r.returncode,r.stdout.strip());assert r.returncode==0,r.stderr

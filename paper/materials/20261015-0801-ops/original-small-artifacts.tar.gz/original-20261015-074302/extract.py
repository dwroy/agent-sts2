import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261015-074302-daf9c28c-d87a-4d3e-8723-e6ceba254cb1-postmortem'
run=b'REEBQHPHSWGK'
for name in ['decisions','run-plans','sl-attempts','run-config']:
    path=root/'logs'/f'{name}.jsonl'
    if not path.exists(): continue
    count=0; offset=0
    with path.open('rb') as src,(out/f'{name}.jsonl').open('w') as dst:
        for n,line in enumerate(src,1):
            here=offset; offset+=len(line)
            if run not in line: continue
            obj=json.loads(line);obj['_line']=n;obj['_offset']=here
            dst.write(json.dumps(obj,ensure_ascii=False)+'\n');count+=1
    print(name,count)
dec=[json.loads(line) for line in (out/'decisions.jsonl').open()]
a=min(d['ts'] for d in dec);b=max(d['ts'] for d in dec)
count=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as src,(out/'reasoning.jsonl').open('w') as dst:
    offset=0
    for n,line in enumerate(src,1):
        here=offset;offset+=len(line)
        obj=json.loads(line)
        if a<=obj.get('ts','')<=b:
            obj['_line']=n;obj['_offset']=here;dst.write(json.dumps(obj,ensure_ascii=False)+'\n');count+=1
print('window',a,b,'reasoning',count)
print('sample keys',list(dec[0]))

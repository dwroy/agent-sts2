import json,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2')
items=[('cloak-generation',['silent-0461'],['combat'],'修正已观察普通斗篷生成小刀被当抽牌的既有缺口，保留未知组合与旧提案实现核验'),('continuation-resources',['silent-0418','silent-0106','silent-0253'],['combat','potion'],'核弃牌后实际防线及能力／速度药水消费接续，原候选胜率不冒记完整实线，缺反事实不设阈值'),('dash-replay',['silent-0483'],['combat'],'限定剃刀牙／华彩／抑制窗口下普通冲刺单动作23挡校准，缺中间帧不推广重放升级顺序')]
receipts=[]
for slug,ledger,domains,summary in items:
 item={'character':'silent','ledger':ledger,'runs':['REEBQHPHSWGK'],'source_task':'postmortem','target_task':'strategy-proposal','domains':domains,'summary':summary,'proposal':str((p/f'proposal-{slug}.md').resolve()),'rule_changes':True,'authorization':'Roy-2026-10-07-learning'}
 (p/f'proposal-{slug}.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n')
 subprocess.run(['date','+%Y-%m-%d %H:%M:%S %Z'],check=True)
 r=subprocess.run(['python3',str(root/'learner/code_proposals.py'),'add','--character','silent'],input=json.dumps(item,ensure_ascii=False),capture_output=True,text=True)
 receipts.append({'slug':slug,'item':item,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 (p/'proposal-cli-results.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')
 print(slug,r.returncode,r.stdout.strip());assert r.returncode==0,r.stderr

# 斗篷生成语义与抽序消费补证

来源任务：postmortem，20261015-074302-daf9c28c-d87a-4d3e-8723-e6ceba254cb1-postmortem。实现任务：独立strategy-proposal。角色／范围：Silent，已观察A10普通斗篷；升级版及A0沿silent-0461既有原证据另核。本任务只登记，不改代码。

账本：silent-0461。证据：REEBQHPHSWGK F45T6，d395131 plan2写cards_drawn=1，d395133称drawing first；s407719→407720普通CLOAK_AND_DAGGER文本6挡、Cards=1为生成一小刀，能量1→0、挡0→6，旧手牌除了已施放斗篷保持、仅新SHIV，没有抽牌。随后d395134小刀实打，不能把它当抽入牌。原记录／offset／SHA见evidence-manifest.json及states.jsonl。

旧行为：本任务只读live52046a3的agent/src/reflex/card-model.ts:1028通用Cards→draw未排除斗篷；turn-solver.ts:2532消费draw，:2564可消费已知牌顶，combat-plan.ts:3363据此给错误抽牌理由。新行为：在本角色已核普通文本／数值／费用下，把生成一刀与抽牌区分，补正确手位／小刀可用信息，生成不得移动已知抽序；未知升级、附魔、重放和满手边界先保持未知。不要把普通模板修复外推所有Cards字段。

反例／限制：d395131实际选的是投掷匕首＋生存者，随后生存者被弃；不能把未选斗篷候选当实打，不能归因死亡或承诺修后获胜。本局没有SL已知抽序实际被斗篷错误消费的独立现场，抽序后继风险来自0461旧证据；实现者须按旧证据核定。notes/fix-queue.md未列，账本已有observed，不是新纯bug。

拟合／切分：语义修复不拟阈值。早期LRN／T082与EEVP、2E4旧原证据作为开发数据，本局普通模板作为新增固定回归；同源同局帧不当独立样本。核角色／进阶／文本签名，保留容量和未知生成分支。

验证：撤去修复应重新出现cards_drawn=1及错误抽序移动；恢复后普通斗篷实添一SHIV、抽序不动、实际6挡输入不被改坏；保持真正抽牌的杂技／投掷匕首和无关角色等价。按仓库沙箱tsc＋vitest入口验，实际合入live及版本另由运维核。预期影响是减少虚构续牌与错误抽牌优先，不宣称胜率收益。回退：只撤该模板生成／抽序增量，不改历史知识证据。

先沿既有silent-proposal-f4eb0efba2594252／silent-proposal-d9cdfc3061265a87核是否已实现；实际live祖先源码commit才可登记implemented。本批不重写旧提案或冒称shipped。既有学习授权：Roy-2026-10-07-learning。

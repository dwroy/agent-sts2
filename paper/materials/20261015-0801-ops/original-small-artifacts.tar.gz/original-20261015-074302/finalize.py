import json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2')
ids=[x['stdout'].strip() for x in json.loads((p/'proposal-cli-results.json').read_text())]
rows=json.loads((p/'ledger-run-final.json').read_text())
added=['silent-0483'];updated=['silent-0106','silent-0418','silent-0461','silent-0043','silent-0132','silent-0253','silent-0280','silent-0401']
assert {x['id'] for x in rows}==set(added+updated)
for x in rows:assert x['character']=='silent' and 'REEBQHPHSWGK' in x['where']['lessons']
queue={}
with (root/'paper/materials/learning/code-proposals.jsonl').open() as f:
 for line in f:
  if not any(ident in line for ident in ids):continue
  d=json.loads(line)
  if d.get('op')=='add':queue[d['id']]=d
for ident in ids:
 d=queue[ident];assert d['character']=='silent' and d['target_task']=='strategy-proposal' and d['source_task']=='postmortem' and d['runs']==['REEBQHPHSWGK']
 assert d.get('state')=='pending' and 'implemented_commit' not in d
 print('提案读回',ident,'state',d['state'],'账本',','.join(d['ledger']))
# Repeat the required ledger integrity check and preserve its actual exit status.
r=subprocess.run(['python3',str(root/'learner/ledger.py'),'check'],capture_output=True,text=True)
(p/'ledger-check.txt').write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stderr
(p/'final-verification.json').write_text(json.dumps({'ledger_check':r.returncode,'ledger_entries':added+updated,'proposals':ids,'proposal_original_state':'pending','lessons_header_count':1,'errata_needed':False,'original_records_readback':1517},ensure_ascii=False,indent=2)+'\n')
report={'task':'postmortem','appended':['REEBQHPHSWGK'],'skipped':[],'bugs':[{'run':'REEBQHPHSWGK','where':'agent/src/reflex/card-model.ts:1028','what':'斗篷生成小刀仍被误作抽牌，复现已有silent-0461；fix-queue未列','new':False}],'ledger':{'added':added,'updated':updated,'repeats':['silent-0461'],'check':r.returncode},'code_proposals':ids,'implementation_domains':['combat','potion'],'report':str((p/'report.md').resolve())}
(p/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
body='''## 复盘回报
- 已追加：REEBQHPHSWGK（A10，第45层，三骑士战末5血6挡对魔法骑士11攻死亡，敌余41血）。
- 新的纯 bug：无。斗篷误抽牌为既有 silent-0461 复现，定位 agent/src/reflex/card-model.ts:1028，fix-queue未列。
- 写成「未记录」的项：REEBQHPHSWGK：完整dirty快照、沙虫首试退出、胜战末击及完整分源伤害、完整候选兑现率、反事实整战结果、重放中间帧、F46以后资源、校准boss时钟与同口径估值比、Jev缓存、真实账单、纯战斗用时。
- 学习账本：REEBQHPHSWGK：新增 silent-0483；更新 silent-0106、0418、0461、0043、0132、0253、0280、0401（均为silent前缀；老错 silent-0461）；ledger.py check退出码0。
- 代码提案（均关联 REEBQHPHSWGK／strategy-proposal，本任务未实施）：
  - F45T6／silent-0461／silent-proposal-78a5513e42f82f27：斗篷生成与抽序修复。
  - F45T3、T6／silent-0106、0418、0253／silent-proposal-243864a439e81a09：弃牌防线与药水消费接续；无反事实整战，不设阈值。
  - F45T5／silent-0483／silent-proposal-84395fbde2c9d57c：限定冲刺23挡组合校准；缺自动结算中间帧，不推广升级顺序。
'''
(p/'report.md').write_text(body+'\n```json\n'+json.dumps(report,ensure_ascii=False)+'\n```\n')
print(r.stdout.strip())
print('报告已保存',report['report'])

import json,re,collections,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]
S=[json.loads(l) for l in (p/'states.jsonl').open()]
B=[json.loads(l) for l in (p/'brain.jsonl').open()]
R=json.loads((p/'REEBQHPHSWGK-resources.json').read_text())
plan=[]
for d in D:
 if d['decider']!='jev' or not d['label'].startswith('combat/plan-choice'):continue
 c=(d['answers']['plan']).get('choice');raw=d['questions']['plan']['criteria'].get(c)
 v=json.loads(raw)
 plan.append({'line':d['_line'],'floor':d['floor'],'turn':d['turn'],'reloads':d.get('sl_reloads',0),'choice':c,'best':v.get('rollout_best',False),'tie':bool(v.get('rollout_tied')),'recorded_best':d.get('rollout_best_chosen'),'code_rank':(re.search(r'code rank (\d+)',d['rationale']) or [None,None])[1],'focus':v.get('focus')})
labels={'combat/plan','combat/lethal','combat/least-loss','combat/end_turn','combat/sandpit-guard'}
A=[d for d in D if d['decider']=='code' and d['label'] in labels]
metrics={'deciders':dict(collections.Counter(d['decider'] for d in D)), 'brain_calls':len(B),'brain_engines':dict(collections.Counter(d['engine'] for d in B)), 'brain_models':dict(collections.Counter(d['model']+'/'+d['effort'] for d in B)), 'first_ts':D[0]['ts'],'last_ts':D[-1]['ts'],'elapsed_seconds':(datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(D[0]['ts'])).total_seconds(),'jev_calls':sum(d['decider']=='jev' for d in D),'jev_low':sum(d['decider']=='jev' and d.get('confidence',1)<.35 for d in D),'jev_usage':{k:sum((d.get('usage') or {}).get(k,0) for d in D if d['decider']=='jev') for k in ['input_tokens','output_tokens']},'brain_usage':{k:sum((d.get('usage') or {}).get(k,0) for d in B) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']},'jev_plan_count':len(plan),'jev_best_only':sum(x['best'] for x in plan),'jev_tie_only':sum(x['tie'] and not x['best'] for x in plan),'jev_recorded_best_true':sum(x['recorded_best'] is True for x in plan),'jev_recorded_best_false':sum(x['recorded_best'] is False for x in plan),'rank_one':sum(x['code_rank']=='1' for x in plan),'rank_recorded':sum(x['code_rank'] is not None for x in plan),'code_primary':len(A),'code_primary_labels':dict(collections.Counter(d['label'] for d in A)),'code_primary_windows':len(set((d['floor'],d.get('sl_reloads',0),d['turn']) for d in A)),'hp_guard':[(d['_line'],d.get('hp_guard')) for d in D if d.get('hp_guard')],'jev_plan_rows':plan}
(p/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in metrics.items() if k!='jev_plan_rows'},ensure_ascii=False,indent=2))
print('FOCUS',[x for x in plan if x['focus']])
print('TURN CHAINS')
for c in R['combats']:
 start=c['entry']['line'];end=(c['exit'] or c['last'])['line'];frames=[d for d in S if start<=d['_line']<=end]
 turns=[]
 for d in frames:
  s=d['state'];t=s.get('turn')
  if not s.get('in_combat') or t is None or turns and turns[-1][0]==t:continue
  turns.append((t,s['run']['current_hp'],[(e['enemy_id'],e['current_hp']) for e in (s.get('combat') or {}).get('enemies',[]) if e['is_alive']]))
 print(c['sequence'],c['floor'],'starts',turns,'exit hp',(c['exit'] or c['last'])['hp'])

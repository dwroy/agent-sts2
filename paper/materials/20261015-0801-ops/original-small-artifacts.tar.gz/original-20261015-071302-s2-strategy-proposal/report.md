# 静默猎手策略学习回报：十项派发提案继续 waiting

本批完成全部十项处置：原五局已核为静默猎手A10，六流6,601条逐字节核证，41项日志端点及源码边界检查通过。已有窄修复无法覆盖原宽提案；本批未找到可由这些原帧隔离的新独立确定源码缺口，所需联合生产回放、完整执行归属或参数校准证据不足，保留现有策略。

基线：`4ffbcee235584d67f2d8c96ec678915c2e8579d1`。开工与结束均保持HEAD及工作树干净；普通流程合main返回Already up to date。没有源码/知识提交、没有合入live、没有新版本、没有新经验入库或消费者已采用宣称。`fixes=[]`、`merged=null`、源码测试均null。

本批learn.json为reason=proposal、十个proposal_ids，无research_request/implementation_request/proposal_repair。普通专题文件绑定另一批，未套用纯研究，也没有读取另一专题代替本批身份。原提案SHA全匹配；十份原文已按原字节保存。只读取静默角色知识与本角色原帧，没有下级agent、网络、LLM调用、play、推送或依赖安装。

详细旧/新行为建议、逐项账本、层/回合、反例、缺数据、预期影响、拟合边界、验证与回退见同目录[proposal.md](proposal.md)。未创建重复提案或修改原提案正文。

## 逐项处置

| 提案 id | 原账本 | 状态与具体缺口 |
|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | silent-0019, silent-0020, silent-0065, silent-0264, silent-0079 | waiting：同首手损1/7、敌净少8/24已核；缺跨重问整线归属、累计成长及同条件后轮/路线验证，不能据单轮差额改SL或终局HP门槛。 |
| silent-proposal-47be799a87af03be | silent-0205 | waiting：四个合法弃牌选项与实际弃精确切击死亡已核；现有live仅为手牌快照，缺动态精确切击、紧勒、毒及逐敌失衡联合的四分支生产回放。 |
| silent-proposal-3a5274da3c42672a | silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006 | waiting：滑溜下火焰净扣1、毒净扣2/23及寄生0→21已核；缺召唤复活、一次翻倍与连续用药联合回放，主怪最后归零内部帧不足，不能拟合药价或固定杀序。 |
| silent-proposal-bc4b92d590f2c4ce | silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266 | waiting：投斧首牌身份和普通单弃等窄修复已是live祖先；缺完整跨重问执行链、余像累计兑现与动态弃牌联合验收，不能把宽项登记duplicate。 |
| silent-proposal-f52fbbab4dccc3b4 | silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064 | waiting：胧光怪获胜53→9直入下战、女王末轮敌仍29/148已核；缺资源分源账和同条件路线/休息/SL/保药整战支线，保留HP价格。 |
| silent-proposal-10f37c0edd3d24a6 | silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069 | waiting：临减恢复成长、普通触媒与一次翻倍原帧已核，模型接线存在；缺冻结开场遗物、持续能力及回复联合生产重放与时间后置独立验证，未定位新确定数值缺口。 |
| silent-proposal-3f82387e2e179703 | silent-0079, silent-0027, silent-0065, silent-0080, silent-0088 | waiting：双蟹两实线损4/8、净少30/23已核；末题original不等于首试执行线，原题预算3轮2样本与5轮24样本不同，缺同抽序同预算整战控制及累计能力收益。 |
| silent-proposal-aee21084c991abd3 | silent-0128 | waiting：抽弃前后题目和plan2/plan4并列已核，力量2→4及14HP面对22攻与6总挡实死；缺原逐样本抽序/动作及完整回放，一次死亡不足校准3/4预测或权重。 |
| silent-proposal-df37594e9b12debf | silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268 | waiting：普通生存者单弃取消唯一打击已有live祖先窄修复；缺跨重规划整线、累计能力与呼唤自损联合消费者验收，没有新增独立纯bug，宽项继续waiting。 |
| silent-proposal-42e81c83b2e1e56b | silent-0019, silent-0020 | waiting：五次实际休息净回105及SL重复恢复同入口/药槽已核；缺回复/药槽/存档事件完整分源账与同条件后战反事实，不能拟合路线或终局HP参数。 |

## 本批核证与实际实现边界

原局身份：NHA F33、P74 F23、G33 F48、RC F33、BTS F31，全部为A10败局；其运行源码均+dirty。历史预测死亡中止和实际HP归零分账，不把同局SL当独立局或候选当完整执行。

| 流 | 冻结source_size | 本批记录数 |
|---|---:|---:|
| states | 12926981757 | 3238 |
| decisions | 1500591443 | 3138 |
| sl-attempts | 39881163 | 31 |
| run-config | 1721286 | 5 |
| run-plans | 7919387 | 26 |
| brain | 547520041 | 163 |

补充共用入口提取runs五行也逐字节核验；fight-plans在2,233,957字节截点选到零条本批身份记录，只说明该截点没有匹配，不宣称原日志或其他记录不存在。六流之外的补充材料单存evidence-extra，未覆盖原manifest或旧初稿。全局JSON无效行分别states2/decisions2/brain1，未倒推为本批缺失；run-plans实际选到26条。

NHA F33 T1两实线损1/7、敌净少8/24；RC F33两实线损4/8、净少30/23，但RC末题sl_explore.original朝火箭且无药，与首试实际朝碾碎爪并喝药不同，原题预算也为3轮2样本/5轮24样本。P74弃精确切击的四个合法选项、1HP/16挡与石16+卵8、毒后卵2及石眩晕同时核实；保留牌分支未实打。BTS抽弃前后分别279852/279854，plan2/plan4都保留并列3/4样本结果，实际死亡不证明数值模型有新bug。

额外独立核对RC F17 T11持呼唤8→2、敌2HP转奖励；G33原首牌两候选挡18/10、伤75/107；BTS两个候选rollout_tied均存在。净端点不是内部逐击轨迹，这些补充不补造整战反事实。

只读live切点 `19c9720b688ec7152fd1bbda554e9084e042077b`。以下仅是已存在的实际祖先源码，**不是本批提交或合入**：
- `bf423c173d3be348a4ad714e1d26516df619ff41`：普通生存者单弃；is-ancestor退出0。
- `e784dd9f043bf87c29109573f48975f9903280d3`：投斧首牌身份；is-ancestor退出0。
- `4b0823f519f1b724d6cff2b1cd50b74146dc4a9d`：保留手牌/费用快照；is-ancestor退出0。
- `fdaf787a372880b0438e73bcac7e6d2168b038ed`：单动作回执；is-ancestor退出0。

当前实际live的弃牌快照明确未推演伤害/格挡/剩血/胜负，selection audit的actual_turn=null，dispatch scope为single_action_receipt且whole_plan_executed=null。这就是不能把宽项标duplicate的边界。基线与live在三个核查源码整文件不同，差异与逐文件SHA保存；只核相关子实现仍存在，未冒称整树等价或合入后续源码。

## 账本、验证及交付

只经根目录learner/ledger.py update追加32条原账本的本批提案/报告链接，CLI退出0，已逐项读回账本链接。protected字段character/claim/first_run/asc/prior/prior_note/prior_runs/evidence/status/version/shipped_at/effect全部原值不变；没有追加游戏repeat、改首证或把旧shipped降回proposed。没有新学习条目需add，无新代码提案需code_proposals add；最终code_proposals沿用原CLI登记的十个id。

41项通过仅是固定日志算术与只读源码边界检查；未运行tsc/vitest/生产模拟器。撤源码失败与恢复通过不适用；未制造源码测试成功、部署编号、合入提交或shipped。本批没有游戏规则上线，故不触发Roy双通知、eval版本或live合入步骤。implementation_domains为空，表示本批无实际实现。

原材料与失败历史留在本批scratch；首次合main命令在执行前受沙箱并行glob缺路径阻断，原样重试成功，记录于本报告；其它只读查找的不存在路径不作为游戏证据或源码失败。没有冲突、没有回退、没有删除工作树。

核证文件：evidence-verification.json、facts-verification.json、supplemental-facts.json、extra-evidence-verification.json、source-readback.json、base-live-source-diff.patch、ledger-updates.jsonl、ledger-cli-output.txt、ledger-cli-errors.txt、ledger-own-rows.json、ledger-readback.json。最终工作树/HEAD及回报字段验收另存completion-verification.json；敏感信息扫描另存gitleaks-scan-receipt.json。

后续必须沿原十个id等待新本角色完局或各项明列缺失的回放数据；不扩大到队列其它批次或纯研究父要求。不把此次重复核对旧五局当成新实盘证据、量化任务完成或自然收益。

## 最终JSON

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261015-071302-s2-strategy-proposal",
  "base": "4ffbcee235584d67f2d8c96ec678915c2e8579d1",
  "runs": [
    "NHA2KW0RB7VP",
    "P74C04AEPL1F",
    "G33HU22H2543",
    "RC61MFQM63Y6",
    "BTSRF7JL1W1Y"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-9952ee8e8df9a0fe",
    "silent-proposal-47be799a87af03be",
    "silent-proposal-3a5274da3c42672a",
    "silent-proposal-bc4b92d590f2c4ce",
    "silent-proposal-f52fbbab4dccc3b4",
    "silent-proposal-10f37c0edd3d24a6",
    "silent-proposal-3f82387e2e179703",
    "silent-proposal-aee21084c991abd3",
    "silent-proposal-df37594e9b12debf",
    "silent-proposal-42e81c83b2e1e56b"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-9952ee8e8df9a0fe",
      "state": "waiting",
      "reason": "同首手损1/7、敌净少8/24已核；缺跨重问整线归属、累计成长及同条件后轮/路线验证，不能据单轮差额改SL或终局HP门槛。"
    },
    {
      "id": "silent-proposal-47be799a87af03be",
      "state": "waiting",
      "reason": "四个合法弃牌选项与实际弃精确切击死亡已核；现有live仅为手牌快照，缺动态精确切击、紧勒、毒及逐敌失衡联合的四分支生产回放。"
    },
    {
      "id": "silent-proposal-3a5274da3c42672a",
      "state": "waiting",
      "reason": "滑溜下火焰净扣1、毒净扣2/23及寄生0→21已核；缺召唤复活、一次翻倍与连续用药联合回放，主怪最后归零内部帧不足，不能拟合药价或固定杀序。"
    },
    {
      "id": "silent-proposal-bc4b92d590f2c4ce",
      "state": "waiting",
      "reason": "投斧首牌身份和普通单弃等窄修复已是live祖先；缺完整跨重问执行链、余像累计兑现与动态弃牌联合验收，不能把宽项登记duplicate。"
    },
    {
      "id": "silent-proposal-f52fbbab4dccc3b4",
      "state": "waiting",
      "reason": "胧光怪获胜53→9直入下战、女王末轮敌仍29/148已核；缺资源分源账和同条件路线/休息/SL/保药整战支线，保留HP价格。"
    },
    {
      "id": "silent-proposal-10f37c0edd3d24a6",
      "state": "waiting",
      "reason": "临减恢复成长、普通触媒与一次翻倍原帧已核，模型接线存在；缺冻结开场遗物、持续能力及回复联合生产重放与时间后置独立验证，未定位新确定数值缺口。"
    },
    {
      "id": "silent-proposal-3f82387e2e179703",
      "state": "waiting",
      "reason": "双蟹两实线损4/8、净少30/23已核；末题original不等于首试执行线，原题预算3轮2样本与5轮24样本不同，缺同抽序同预算整战控制及累计能力收益。"
    },
    {
      "id": "silent-proposal-aee21084c991abd3",
      "state": "waiting",
      "reason": "抽弃前后题目和plan2/plan4并列已核，力量2→4及14HP面对22攻与6总挡实死；缺原逐样本抽序/动作及完整回放，一次死亡不足校准3/4预测或权重。"
    },
    {
      "id": "silent-proposal-df37594e9b12debf",
      "state": "waiting",
      "reason": "普通生存者单弃取消唯一打击已有live祖先窄修复；缺跨重规划整线、累计能力与呼唤自损联合消费者验收，没有新增独立纯bug，宽项继续waiting。"
    },
    {
      "id": "silent-proposal-42e81c83b2e1e56b",
      "state": "waiting",
      "reason": "五次实际休息净回105及SL重复恢复同入口/药槽已核；缺回复/药槽/存档事件完整分源账与同条件后战反事实，不能拟合路线或终局HP参数。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-071302-s2/learner/runs/20261015-071314-913f8a9a-bd35-4426-94e5-bbfc6ff20c99-strategy-proposal/report.md"
}
```

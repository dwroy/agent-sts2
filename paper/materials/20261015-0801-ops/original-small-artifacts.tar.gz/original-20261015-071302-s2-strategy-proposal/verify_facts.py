import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
frames = {f['source_line']: f for f in json.loads((HERE / 'state-facts.json').read_text())}
checks = []


def check(key, actual, expected, references):
    checks.append({'key': key, 'actual': actual, 'expected': expected, 'passed': actual == expected,
                   'references': references})


def enemy(line, ident):
    return next(e for e in frames[line]['enemies'] if e['id'] == ident)


check('弃精确切击前后手牌', [[c['id'] for c in frames[n]['hand']] for n in [284817, 284818]],
      [['STRANGLE', 'NOXIOUS_FUMES', 'PRECISE_CUT', 'GREED'], ['STRANGLE', 'NOXIOUS_FUMES', 'GREED']], [284817, 284818])
check('弃牌时精确切击随手牌变化后的牌面', next(c for c in frames[284817]['hand'] if c['id'] == 'PRECISE_CUT')['dynamic']['CalculatedDamage'], 7, [284817])
check('末弃牌四合法候选', len(frames[284817]['selection']['cards']), 4, [284817])
check('末轮局部眩晕不消除另一敌攻击',
      [frames[284817]['hp'], frames[284817]['block'], enemy(284817, 'BOWLBUG_ROCK')['incoming'],
       enemy(284817, 'BOWLBUG_EGG')['incoming'], frames[284821]['hp'],
       enemy(284821, 'BOWLBUG_ROCK')['move'], enemy(284821, 'BOWLBUG_EGG')['hp']],
      [1, 16, 16, 8, 0, 'STUNNED', 2], [284817, 284821])
check('墨影火焰实扣与滑溜消费',
      [enemy(284630, 'VANTOM')['hp'] - enemy(284631, 'VANTOM')['hp'],
       enemy(284630, 'VANTOM')['powers']['SLIPPERY_POWER'] - enemy(284631, 'VANTOM')['powers']['SLIPPERY_POWER']],
      [1, 1], [284630, 284631])
check('普通触媒一层滑溜下合计毒实扣',
      [frames[284635]['powers']['ACCELERANT_POWER'], enemy(284635, 'VANTOM')['hp'] - enemy(284636, 'VANTOM')['hp'],
       enemy(284635, 'VANTOM')['powers']['SLIPPERY_POWER'], enemy(284636, 'VANTOM')['powers']['SLIPPERY_POWER'],
       enemy(284635, 'VANTOM')['powers']['POISON_POWER'], enemy(284636, 'VANTOM')['powers']['POISON_POWER']],
      [1, 2, 6, 4, 12, 10], [284635, 284636])
check('滑溜消失后12毒净扣23',
      [enemy(284658, 'VANTOM')['powers']['POISON_POWER'], enemy(284658, 'VANTOM')['hp'], enemy(284659, 'VANTOM')['hp']],
      [12, 44, 21], [284658, 284659])
check('尖啸当轮减力与次轮恢复',
      [enemy(284634, 'VANTOM')['powers']['STRENGTH_POWER'], enemy(284634, 'VANTOM')['incoming'],
       frames[284635]['hp'] - frames[284636]['hp'], enemy(284636, 'VANTOM')['powers'].get('STRENGTH_POWER', 0),
       enemy(284636, 'VANTOM')['incoming']], [-6, 2, 2, 0, 30], [284634, 284635, 284636])
check('胧光怪幻象复活', [enemy(284748, 'PARAFRIGHT')['hp'], enemy(284749, 'PARAFRIGHT')['hp']], [0, 21], [284748, 284749])
check('胧光怪两关键轮实损', [frames[284743]['hp'] - frames[284744]['hp'], frames[284753]['hp'] - frames[284754]['hp']],
      [20, 24], [284743, 284744, 284753, 284754])
check('胧光怪获胜接下战入口', [frames[284730]['hp'], frames[284761]['hp'], frames[284766]['hp']], [53, 9, 9], [284730, 284761, 284766])
check('胧光怪普通触媒10毒合计19', enemy(284753, 'THE_OBSCURA')['hp'] - enemy(284754, 'THE_OBSCURA')['hp'], 19, [284753, 284754])
check('第三试普通单弃取消末攻击和转向',
      [[c['id'] for c in frames[285414]['hand']], [c['id'] for c in frames[285415]['hand']],
       frames[285415]['hp'], frames[285415]['block'], enemy(285415, 'ROCKET')['incoming']],
      [['SURVIVOR', 'STRIKE_SILENT'], [], 45, 7, 57], [285414, 285415])
check('甲虫战普通单弃取消突然一拳',
      [[c['id'] for c in frames[286161]['hand']], [c['id'] for c in frames[286162]['hand']],
       frames[286162]['hp'] - frames[286163]['hp']], [['SURVIVOR', 'SUCKER_PUNCH'], [], 14], [286161, 286162, 286163])
check('醒虫已执行末轮成长和实际死亡',
      [enemy(286163, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'], enemy(286170, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'],
       enemy(286170, 'SLUMBERING_BEETLE')['incoming'], frames[286173]['hp'], frames[286173]['block'],
       frames[286173]['powers']['PLATING_POWER'], frames[286174]['hp'], enemy(286174, 'SLUMBERING_BEETLE')['hp']],
      [2, 4, 22, 14, 5, 1, 0, 13], [286163, 286170, 286173, 286174])
check('女王末轮临减恢复成长与真实挡',
      [enemy(284400, 'TORCH_HEAD_AMALGAM')['powers']['STRENGTH_POWER'], enemy(284404, 'TORCH_HEAD_AMALGAM')['powers']['STRENGTH_POWER'],
       frames[284403]['block'], frames[284407]['block'], enemy(284407, 'TORCH_HEAD_AMALGAM')['incoming']],
      [-4, 5, 17, 12, 31], [284400, 284403, 284404, 284407])
check('女王末轮毒与末出牌净HP减少',
      [enemy(284404, 'TORCH_HEAD_AMALGAM')['hp'] + enemy(284404, 'QUEEN')['hp']
       - enemy(284408, 'TORCH_HEAD_AMALGAM')['hp'] - enemy(284408, 'QUEEN')['hp'],
       enemy(284408, 'TORCH_HEAD_AMALGAM')['hp'], enemy(284408, 'QUEEN')['hp'], frames[284408]['hp']],
      [69, 29, 148, 0], [284404, 284408])

for ident, pairs, total in [
    ('NHA2KW0RB7VP', [(283072, 283073), (283138, 283139), (283284, 283285), (283322, 283323), (283387, 283388)], 120),
    ('RC61MFQM63Y6', [(284973, 284974), (285015, 285016), (285249, 285250), (285260, 285261), (285311, 285312)], 105),
    ('G33HU22H2543', [(283631, 283632), (283700, 283701), (283869, 283870), (283964, 283965), (284158, 284159)], 133),
]:
    check(ident + '已兑现休息净回复', sum(frames[b]['hp'] - frames[a]['hp'] for a, b in pairs), total, pairs)

sl = [json.loads(line) for line in (HERE / 'evidence/sl-attempts.evidence.jsonl').open()]
by = {r['line']: r['row'] for r in sl}
for line, loss, damage in [(987, 1, 8), (992, 7, 24), (1007, 4, 30), (1012, 8, 23)]:
    turns = by[line]['summary']['turns']
    check('SL原实线T1已兑现损血-' + str(line), turns[0]['hp'] - turns[1]['hp'], loss, [line])
    run = by[line]['run_id']
    # The original summaries expose enemy HP endpoints, not cumulative gross damage.
    values = [[int(x.split('/')[0].split()[-1]) for x in t['enemies'].split(', ')] for t in turns[:2]]
    check('SL原实线T1敌人净HP减少-' + str(line), sum(values[0]) - sum(values[1]), damage, [line])
for run, floor, ends in [('NHA2KW0RB7VP', 33, ['predicted_death'] * 5 + ['died']),
                         ('G33HU22H2543', 48, ['predicted_death'] * 5 + ['died'])]:
    chosen = [r for r in sl if r['run_id'] == run and r['row']['floor'] == floor]
    check(run + '预测中止与实际死亡分账', [r['row']['result'] for r in chosen], ends, [r['line'] for r in chosen])

decisions = {r['line']: r['row'] for r in map(json.loads, (HERE / 'evidence/decisions.evidence.jsonl').open())}
check('RC末题原SL候选不同于首试已执行线',
      ['火箭' in decisions[279197]['sl_explore']['original'], 'potion' in decisions[279197]['sl_explore']['original'],
       'potion 格挡药水' in by[1007]['summary']['turns'][0]['plays']], [True, False, True], [279197, 1007])
check('RC两实盘首题现场指纹一致', decisions[279021]['fingerprint'] == decisions[279197]['fingerprint'], True, [279021, 279197])
for line, horizon in [(279021, '3-turn rollout (2 samples)'), (279197, '5-turn rollout (24 samples)')]:
    check('RC原题抽样范围-' + str(line), all(horizon in json.loads(v)['rollout'] for v in decisions[line]['questions']['plan']['criteria'].values()), True, [line])
for line in [279852, 279854]:
    values = {k: json.loads(v) for k, v in decisions[line]['questions']['plan']['criteria'].items()}
    (HERE / ('decision-' + str(line) + '-criteria.json')).write_text(json.dumps(values, ensure_ascii=False, indent=2) + '\n')
check('BTS抽弃后原题已经重新规划', decisions[279852]['decision_id'] != decisions[279854]['decision_id'], True, [279852, 279854])
check('BTS末题两个并列候选仍保留', all(k in decisions[279854]['questions']['plan']['criteria'] for k in ['plan2', 'plan4']), True, [279854])

readback = json.loads((HERE / 'source-readback.json').read_text())
live = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
markers = {'agent/src/hand/screens/silent-discard-facts.ts': ['retained_cards:', 'snapshot', '伤害、格挡、剩血及胜负均未推演'],
           'agent/src/reflex/turn-solver.ts': ['else if (card.survivorDiscard)', 'const only = pool.length === 1'],
           'agent/src/sl/explore.ts': ['firstCardReplayScope', 'const first = firstCardReplay'],
           'agent/src/reflex/silent-selection-audit.ts': ['scope: "predicted_candidates"', 'actual_turn: null'],
           'agent/src/reflex/silent-selection-dispatch.ts': ['scope: "single_action_receipt"', 'whole_plan_executed: null']}
for path, texts in markers.items():
    source = subprocess.check_output(['git', '-C', str(live), 'show', readback['live_readonly_head'] + ':' + path], text=True)
    check('已核live子实现边界-' + path, all(x in source for x in texts), True, [readback['live_readonly_head'], path])

output = {'passed': all(x['passed'] for x in checks), 'checks': checks, 'check_count': len(checks),
          'scope': '原对局端点与源码边界只读核证；未运行生产模拟器或源码测试'}
(HERE / 'facts-verification.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': output['passed'], 'check_count': len(checks), 'failures': [x for x in checks if not x['passed']]}, ensure_ascii=False))
assert output['passed']

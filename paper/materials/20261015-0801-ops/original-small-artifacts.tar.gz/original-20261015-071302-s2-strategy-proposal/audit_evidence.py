import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE / 'evidence'
batch = json.loads((HERE / 'batch-input.json').read_text())
runs = set(batch['runs'])


def explicit_run(row):
    state = row.get('state') or {}
    fingerprint = row.get('fingerprint') or {}
    if isinstance(fingerprint, str):
        fingerprint = json.loads(fingerprint)
    values = {v for v in [row.get('run_id'), row.get('run'), state.get('run_id'), fingerprint.get('run')]
              if isinstance(v, str) and v and v != 'run_unknown'}
    assert len(values) == 1, values
    return next(iter(values))


def powers(entity):
    return {p['power_id']: p.get('amount') for p in entity.get('powers', [])}


def card(c):
    return {'index': c.get('index'), 'id': c.get('card_id'), 'upgrade': c.get('upgraded'),
            'energy': c.get('energy_cost'), 'dynamic': {x['name']: x.get('current_value') for x in c.get('dynamic_values', [])}}


def frame(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    selection = state.get('selection')
    return {'source_line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
            'run': item['run_id'], 'ts': item['row']['ts'], 'screen': state.get('screen'),
            'floor': run.get('floor'), 'turn': state.get('turn'), 'hp': player.get('current_hp', run.get('current_hp')),
            'max_hp': player.get('max_hp', run.get('max_hp')), 'block': player.get('block'),
            'energy': player.get('energy'), 'powers': powers(player),
            'relics': [x.get('relic_id') for x in run.get('relics', [])],
            'potions': run.get('potions'), 'hand': [card(c) for c in combat.get('hand', [])],
            'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                         'block': e.get('block'), 'alive': e.get('is_alive'), 'powers': powers(e),
                         'move': e.get('move_id'), 'incoming': sum(x.get('total_damage') or 0 for x in e.get('intents', []))}
                        for e in combat.get('enemies', [])],
            'selection': None if not selection else {'kind': selection.get('kind'), 'prompt': selection.get('prompt'),
                                                     'cards': [card(c) for c in selection.get('cards', [])]}}


checks = []
frames = []
rows = {}
for manifest in json.loads((EVIDENCE / 'evidence-manifest.json').read_text()):
    stream = manifest['stream']
    path = EVIDENCE / (stream + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
    counts = dict.fromkeys(batch['runs'], 0)
    rows[stream] = []
    with Path('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl').open('rb') as source:
        for raw in path.open():
            item = json.loads(raw)
            assert item['run_id'] in runs and explicit_run(item['row']) == item['run_id']
            source.seek(item['offset'])
            original = source.read(item['bytes'])
            assert hashlib.sha256(original).hexdigest() == item['sha256']
            assert json.loads(original) == item['row']
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            if stream == 'states':
                r = item['row']['state']['run']
                assert r['character_id'] == 'SILENT' and r['ascension'] == 10
                frames.append(frame(item))
            rows[stream].append(item)
            counts[item['run_id']] += 1
    assert counts == manifest['counts']
    checks.append({'stream': stream, 'source_size': manifest['source_size'], 'rows_verified': sum(counts.values()),
                   'counts': counts, 'output_sha256': manifest['output_sha256'], 'raw_sha_body_identity': True})

(HERE / 'evidence-verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
(HERE / 'state-facts.json').write_text(json.dumps(frames, ensure_ascii=False) + '\n')

anchors = [283391, 283397, 283398, 284817, 284818, 284821, 285411, 285412, 285413, 285414, 285415,
           286161, 286162, 286163, 286170, 286173, 286174]
for f in frames:
    if f['source_line'] in anchors:
        print(json.dumps({k: f[k] for k in ['source_line', 'run', 'floor', 'turn', 'hp', 'block', 'powers', 'hand', 'enemies']}, ensure_ascii=False))
for item in rows['sl-attempts']:
    r = item['row']
    if r['floor'] in [23, 31, 33, 48]:
        summary = (r.get('summary') or {}).get('turns') or []
        print(json.dumps({'sl_line': item['line'], 'run': r['run_id'], 'floor': r['floor'], 'attempt': r['attempt'],
                          'result': r['result'], 'end_hp': r['end_hp'], 'turns': r['turns'],
                          'first': summary[0] if summary else None, 'second': summary[1] if len(summary) > 1 else None}, ensure_ascii=False))
print(json.dumps({'verified_rows': sum(x['rows_verified'] for x in checks), 'streams': len(checks)}, ensure_ascii=False))

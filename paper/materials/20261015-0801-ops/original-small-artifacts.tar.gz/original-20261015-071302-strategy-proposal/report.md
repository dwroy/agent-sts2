# 静默策略学习回报

记录时间：2026-10-15T07:26:44+08:00。本批十项原提案均已核验并保留waiting，没有足够的新证据支持改生产策略。
真实完整base为 `4ffbcee235584d67f2d8c96ec678915c2e8579d1`，HEAD保持该提交；源码差异与工作树状态将在verification.json读回。
无源码提交、无合入、无行为版本；fixes=[]、merged=null。不将既有局部实现记成整项implemented/duplicate或shipped。

## 身份和范围

- 本批learn.json：task=strategy-proposal、character=silent、reason=proposal、state=running，工作树与任务路径相同，十个proposal_ids顺序一致。dispatch.json保存对应行。
- 本批不满足专题身份，无research_request/implementation_request；notes/strategy-research-silent.json属于20261010另一批，不作为本批研究身份。普通基线merge已执行且无冲突。
- 十个派发锚点：KEN58SH9SLZ6, TXZ6RVMQA09D, WQZVENQ7DTRP, 02HB4L0C3C67, 4D4J8USKCPAV, F4QKG4J1AJJZ, JLN5SK17W4FQ, LS8035TB32P3, NB8KCF6HRGVF, S9UZAK0JP0C0。F4QKG4J1AJJZ为A9，其余九个A10。
- 仅为核对已派原文，补读其明确引用的五局：1913SE84AXQF/Q6M2Y34MWKRE/NHA2KW0RB7VP为A10，K3676LU8B0UH为A1，SADL3CGYTGSR为A7。不把这些历史来源当新增独立验证局，也不扩展领取提案。
- 15局runs原行均SILENT；各state.run.character_id亦逐帧核过，显式run_id/state.run_id/fingerprint.run/run冲突身份不接受。未读取其他角色知识目录。
- 十份原提案指纹全部与专用队列保存SHA一致；31个原账本项只按明确链接读取。完整冻结原文在本scratch，原提案和旧复盘未修改。
- 本会话未更改模型/账号/服务配置、未降强度或派子agent；未独立获得原生请求模型读回，不能把历史run-config的模型字段当当前会话模型验收。

## 证据冻结和核验

共核19929条非重复原始所属记录，16个流切点分别保存source_size、output_sha256、逐行offset/bytes/SHA和计数。每条以seek重读源字节、核SHA、JSON正文与身份。
raw截点各流独立，不伪称全流原子快照。fight-plans在本次切点两组均0行，只表示该流/截点未选到，不能据此断言历史记录缺失。
原流全局invalid_lines由共用入口保存：states/decisions各2，brain1；不把被拒行算入所属证据。

| 证据组 | 流 | 核验所属行数 | source_size字节 |
|---|---|---:|---:|
| evidence | states | 6684 | 12926981757 |
| evidence | decisions | 6415 | 1500591443 |
| evidence | sl-attempts | 56 | 39881163 |
| evidence | run-config | 10 | 1721286 |
| evidence | run-plans | 51 | 7919387 |
| evidence | brain | 304 | 547520041 |
| evidence | runs | 10 | 330941 |
| evidence | fight-plans | 0 | 2233957 |
| original-evidence | states | 3131 | 12926981757 |
| original-evidence | decisions | 3033 | 1500709501 |
| original-evidence | sl-attempts | 22 | 39881163 |
| original-evidence | run-config | 5 | 1721286 |
| original-evidence | run-plans | 26 | 7919387 |
| original-evidence | brain | 177 | 547520041 |
| original-evidence | runs | 5 | 330941 |
| original-evidence | fight-plans | 0 | 2233957 |

早期early-decisions仅为提取期间先行查看，9448行逐SHA与最终规范decisions核对相同；不增加独立证据分母。
运行材料：provenance-verification.json、两个evidence-manifest.json、potion-transitions.json、actionable-turns.json、resource-endpoints.json、selected-decisions.json、mechanism-windows.json。

## 已核结论与限制

1. KEN七次真饮/零弃，六场赢战净损合46；F15零净损仍花两瓶药，F12/F16两次实际回复与SL恢复分账。没有不喝/留药的完整配对。
2. TXZ F48第2/3试T6局部损3/扣36对损0/扣27，省3血同时少扣9；首战奖励4HP，F49实验体111HP未被扣，4→0在可操作前。runs.death_fight旧字段仍列永世沙漏，原字段不改，以原state区分实际后战。
3. WQ同盘T9多9血换15敌净扣；末T7付4血延一沙坑轮、同扣24，限制“一律保血”与“一律多伤更安全”两种外推。整战均无已证替线胜因。
4. 九个狡诈来源局42次实饮与生成容量完全吻合：37×3、2×2、3×0，WQ满手分支耗瓶但HP/能量不变。模型中已具备确定小刀生成与逐步容量；保留选择和实际SL恢复联合消费者仍未闭合。
5. 1913/Q6真实后继入口分别46/2；锻造、事件、休息与赢战净损分开。Q6紧勒103→95→85→83→80证明局部2+2触发，当前普通紧勒已接线；弃磨蚀3费余额不变且建1敏/4荆棘是观测支持，但现有主动施放预览不等于自动弃牌路径完整验证。
6. NHA饱和换线实际多6损/多16敌净扣，初案精确切击实际被弃，重规划后才到端点；原预测不是整线实执行。油灯前后六窗stack均null，已观察首次放大不提供可靠跨动作消费状态或所有组合/恢复规则。朝向1→2与30→20只作该现场观察，不拟通用取整顺序。

不拟固定持药价、血价、SL阈值、终局曲线、留牌策略或胜率参数；同局多个SL和rollout样本不算独立对局。
本批54项事实断言通过（19+35），只证明冻结观测与算术，未运行boss模拟、LLM、网络或play；不称完整模拟校准、样本外玩法成功或自然消费者收益。

## 逐项处置

| 派发ID | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-08eaa60bcc449852 | waiting | 缺KEN同入口资源、同后续牌序的不饮用/留药至boss整战对照；已核资源结转不能校准药水持有价格。 |
| silent-proposal-92920295a648b540 | waiting | 缺固定后续抽牌和生成牌的连续通关替线；T6省3血同时少扣9，首boss赢且余4血不能证明SL或连战排序改善。 |
| silent-proposal-a327449c331efbc1 | waiting | 缺血量与沙坑双边界的完整受控后继及独立成功验证；同轮9血/15伤和4血/一沙坑不能拟成固定换线阈值。 |
| silent-proposal-a099e89437e942bb | waiting | 确定生成和当前容量已实现；缺计划妥当保留选择、完整候选派发与实际SL恢复的联合消费者验证，不能把局部容量实现当整项duplicate。 |
| silent-proposal-47910f82a1fdd98f | waiting | 开场扣4及连战接续已有实现；缺留药、路线、SL完整受控后继与未知回复/复活组合结算顺序，不能关闭整个资源价值提案。 |
| silent-proposal-f1374df72d8e6a25 | waiting | 缺隔离机制误差后的同预算完整后继，以及未用、早用、留药的成对整战结果；两条资源链不足拟合终局或药水权重。 |
| silent-proposal-38a49e6c97f31eea | waiting | 普通紧勒和磨蚀主动预览已有实现；缺弃牌自动触发、增益分源、重接、逐击反伤及再生的完整联合消费者校准，不能以一个子公式关闭整项。 |
| silent-proposal-ef0e38a5dbd3bc07 | waiting | 缺另选营火、事件、路线及用药时机的完整受控结果；现有资源端点与计划条件变化不能拟合资源权重或因果收益。 |
| silent-proposal-7f820c02d39bfaea | waiting | 预测比较已有实现；缺成对完整后继、整候选派发归属与同预算饱和排序校准；原计划被弃牌重规划，六次全败不能证明新门槛。 |
| silent-proposal-04b6b430759815ed | waiting | 油灯缺可靠首次消费来源及跨动作、新战、SL恢复联合验证；朝向取整仅局部观察，能力完整后继未证，不能把现场放大套到每次施用。 |

逐项证据局号/层/回合、账本ID、旧行为、预期、反例、验证和回退见 `/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-071302/learner/runs/20261015-071313-6c180231-bd29-4eb0-95a7-69400830c755-strategy-proposal/proposal.md`。
CLI代码提案ID沿用原十项，未另建重复ID。实际implementation_domains=[]，不把只读核验冒成combat/potion/sl/terminal实现。

## 现有live源码核对

只读live切点 `19c9720b688ec7152fd1bbda554e9084e042077b`；source-audit.json保存11叶Git内容SHA与真实祖先判定，source-blocks.json保存四个本提案相关代码块的base/live相同校验。
6叶字节完全相同；5叶整个文件不同，其中card-model/turn-solver/combat-plan/rollout-live包含live额外逃脱计划实现，另有Roy/Dai历史注释变化。未把整叶祖先存在当作文件相同或宽提案已实现，未覆盖live增量。
连战入口、剩余HP/已耗药水接续、普通紧勒和狡诈容量的既有局部逻辑已核；选择/派发审计保留actual_turn=null与execution未验证。现有测试文件只读定位，不借旧绿报告本次测试成功。

## 验证、记录与失败保留

源码未改，撤源码失败/恢复通过不适用；tsc、vitest、cases全部null。未运行完整/沙箱源码套件，未制造提交、合入、版本或上线通知。
学习账本仅经根目录ledger.py update追加这十项关联31原项的追溯位置和处置说明，未传status/version/evidence/claim，原shipped/proposed等状态与首证保留；ledger追加原字节回执单独保存。
gitleaks与最终HEAD/工作树读回保存到verification.json；本批不提交源码或材料，scratch由原调度器验收/回收，未删除自身工作树或原日志。

保留的过程限制：开工时部分只读命令因sandbox全局glob扫描瞬时缺路径被拒，重试成功；第一次证据检查脚本import路径错，audit-evidence.stderr.txt保留，修正后audit-evidence-2成功；若干只读源码猜测路径不存在，后用rg --files定位到真实模块，无源码改写。开工误输出旧fix-queue-v4一段跨角色历史队列，发现明确派发ID后停止使用，未复制该段到角色经验/结论，未据此补游戏知识。

ledger追加不代表入库或消费者采用；waiting保留待本角色新证据，不关闭Roy父要求，也不代填ops/watcher/Roy确认。final result.json与本报告为本批真实处置。

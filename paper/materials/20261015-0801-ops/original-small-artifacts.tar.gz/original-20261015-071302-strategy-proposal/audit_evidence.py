"""Verify frozen own-character records and preserve bounded resource observations."""
import bisect
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[1]))
from extract_evidence import run_identity


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(values):
    return {x["power_id"]: x["amount"] for x in values or []}


def compact(envelope):
    row = envelope["row"]
    s = row["state"]
    run = s.get("run") or {}
    c = s.get("combat") or {}
    player = c.get("player") or {}
    return {
        "line": envelope["line"], "run": s["run_id"], "ts": row["ts"],
        "observed_ts": row.get("observed_ts"), "fingerprint": row["fingerprint"],
        "floor": run.get("floor"), "turn": s.get("turn"), "screen": s["screen"],
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "energy": player.get("energy"), "block": player.get("block"),
        "actionable": (c.get("action_readiness") or {}).get("can_use_combat_actions"),
        "powers": powers(player.get("powers")),
        "hand": [{"id": x["card_id"], "upgraded": x.get("upgraded"),
                  "values": x.get("dynamic_values")} for x in c.get("hand", [])],
        "potions": [{"id": x.get("potion_id"), "occupied": x.get("occupied"),
                     "slot": x.get("index")} for x in run.get("potions", [])],
        "relics": [x["relic_id"] for x in run.get("relics", [])],
        "enemies": [{"id": x["enemy_id"], "hp": x["current_hp"],
                     "block": x.get("block"), "powers": powers(x.get("powers")),
                     "intents": x.get("intents"), "alive": x.get("is_alive")}
                    for x in c.get("enemies", [])],
    }


states = defaultdict(list)
decisions = []
provenance = []
run_rows = {}
for folder in ["evidence", "original-evidence"]:
    manifests = json.loads((OUT / folder / "evidence-manifest.json").read_text())
    for manifest in manifests:
        stream = manifest["stream"]
        path = OUT / folder / (stream + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        last_offset = -1
        with path.open("rb") as handle, (Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")).open("rb") as source:
            for raw in handle:
                digest.update(raw)
                e = json.loads(raw)
                assert e["offset"] > last_offset
                last_offset = e["offset"]
                assert e["offset"] + e["bytes"] <= manifest["source_size"]
                source.seek(e["offset"])
                original = source.read(e["bytes"])
                assert original.endswith(b"\n")
                assert hashlib.sha256(original).hexdigest() == e["sha256"]
                assert json.loads(original) == e["row"]
                assert run_identity(e["row"]) == e["run_id"]
                counts[e["run_id"]] += 1
                if stream == "states":
                    assert e["row"]["state"]["run"]["character_id"].lower() == "silent"
                    states[e["run_id"]].append(compact(e))
                elif stream == "decisions":
                    decisions.append(e)
                elif stream == "runs":
                    assert e["row"]["character"].lower() == "silent"
                    run_rows[e["run_id"]] = e["row"]
        assert digest.hexdigest() == manifest["output_sha256"]
        assert {k: counts[k] for k in manifest["counts"]} == manifest["counts"]
        provenance.append({"folder": folder, "stream": stream, "verified_rows": sum(counts.values()),
                           "source_size": manifest["source_size"], "output_sha256": digest.hexdigest(),
                           "counts": manifest["counts"], "byte_checks_passed": True})
save("provenance-verification.json", provenance)

by_fingerprint = defaultdict(list)
for rid, rows in states.items():
    for i, s in enumerate(rows):
        by_fingerprint[(rid, s["fingerprint"])].append((s["ts"], i))


def before_state(e):
    r = e["row"]
    choices = by_fingerprint[(e["run_id"], r["fingerprint"])]
    exact = [i for _, i in choices if states[e["run_id"]][i]["observed_ts"] == r.get("observed_ts")]
    if exact:
        return exact[-1]
    prior = [i for ts, i in choices if ts <= r["ts"]]
    return prior[-1] if prior else None


drinks = []
discarded = []
for e in decisions:
    r = e["row"]
    action = r.get("chosen") or {}
    if action.get("action") not in ["use_potion", "discard_potion"]:
        continue
    idx = before_state(e)
    assert idx is not None, (e["line"], "missing before board")
    rows = states[e["run_id"]]
    a = rows[idx]
    slot = action["option_index"]
    potion = a["potions"][slot]
    assert potion["occupied"]
    candidates = [s for s in rows[idx + 1:idx + 9] if s["floor"] == a["floor"] and
                  len(s["potions"]) > slot and not s["potions"][slot]["occupied"]]
    b = candidates[0] if candidates else None
    item = {"decision_line": e["line"], "run": e["run_id"], "floor": r["floor"],
            "turn": r["turn"], "attempt": r.get("sl_attempt"), "potion": potion["id"],
            "slot": slot, "result": r["result"], "before_line": a["line"],
            "after_line": b["line"] if b else None, "consumed_observed": b is not None}
    if b:
        item.update({"hand_before": len(a["hand"]), "hand_after": len(b["hand"]),
                     "hp_before": a["hp"], "hp_after": b["hp"],
                     "energy_before": a["energy"], "energy_after": b["energy"],
                     "powers_before": a["powers"], "powers_after": b["powers"]})
    if potion["id"] == "CUNNING_POTION" and b:
        before = Counter((x["id"], x["upgraded"]) for x in a["hand"])
        added = (Counter((x["id"], x["upgraded"]) for x in b["hand"]) - before)
        item["added_cards"] = [[*key, n] for key, n in added.items()]
        item["added_shivs"] = added[("SHIV", True)]
        item["expected_from_observed_capacity"] = min(3, max(0, 10 - len(a["hand"])))
        assert item["added_shivs"] == item["expected_from_observed_capacity"]
        assert all(key == ("SHIV", True) for key in added)
    (drinks if action["action"] == "use_potion" else discarded).append(item)
save("potion-transitions.json", {"drinks": drinks, "discards": discarded})

timeline = []
for rid, rows in states.items():
    previous_turn = None
    previous_floor = None
    attempt = 1
    seen = set()
    for s in rows:
        if s["screen"] != "COMBAT" or s["turn"] is None:
            continue
        if s["floor"] != previous_floor:
            attempt = 1
            previous_turn = None
        elif previous_turn is not None and s["turn"] < previous_turn:
            attempt += 1
        previous_floor, previous_turn = s["floor"], s["turn"]
        key = (s["floor"], attempt, s["turn"])
        if not s["actionable"] or key in seen:
            continue
        seen.add(key)
        timeline.append({k: v for k, v in s.items() if k not in ["fingerprint", "hand", "relics"]} |
                        {"attempt": attempt, "hand_ids": [x["id"] for x in s["hand"]]})
save("actionable-turns.json", timeline)

selected = []
for e in decisions:
    r = e["row"]
    if e["line"] not in {275383, 275384, 275385, 275894, 275960, 277248, 277250, 277272, 277274}:
        continue
    idx = before_state(e)
    selected.append({"decision_line": e["line"], "run": e["run_id"], "floor": r["floor"],
                     "turn": r["turn"], "attempt": r.get("sl_attempt"), "chosen": r["chosen"],
                     "result": r["result"], "exploration": r.get("sl_explore"),
                     "before": states[e["run_id"]][idx] if idx is not None else None})
save("selected-decisions.json", selected)

resource_floors = {"KEN58SH9SLZ6": {2, 3, 4, 5, 11, 12, 15, 16, 17},
                   "TXZ6RVMQA09D": {43, 45, 46, 48, 49},
                   "1913SE84AXQF": {17, 18, 19, 23, 24, 28, 29, 30, 31},
                   "Q6M2Y34MWKRE": {2, 3, 5, 6, 7, 8, 9}}
resources = []
for rid, floors in resource_floors.items():
    for floor in sorted(floors):
        rows = [s for s in states[rid] if s["floor"] == floor]
        if not rows:
            continue
        endpoints = [rows[0], rows[-1]]
        rewards = [s for s in rows if s["screen"] == "REWARD"]
        actions = [s for s in rows if s["actionable"]]
        if rewards:
            endpoints.append(rewards[0])
        if actions:
            endpoints.append(actions[0])
        resources.append({"run": rid, "floor": floor, "endpoints": endpoints})
save("resource-endpoints.json", resources)

checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected, "passed": True})


check("fifteen explicitly scoped runs", len(run_rows), 15)
check("all own-character runs", sorted(set(r["character"] for r in run_rows.values())), ["SILENT"])
check("Cunning observed drinks", sum(d["potion"] == "CUNNING_POTION" for d in drinks), 42)
check("Cunning capacity distribution", dict(Counter(d["added_shivs"] for d in drinks if d["potion"] == "CUNNING_POTION")), {3: 37, 2: 2, 0: 3})
check("KEN actual seven drinks", sum(d["run"] == "KEN58SH9SLZ6" for d in drinks), 7)
check("KEN no discards", sum(d["run"] == "KEN58SH9SLZ6" for d in discarded), 0)
check("Q6 actual two drinks", sum(d["run"] == "Q6M2Y34MWKRE" for d in drinks), 2)
check("1913 actual eight drinks", sum(d["run"] == "1913SE84AXQF" for d in drinks), 8)
sx = {s["line"]: s for rows in states.values() for s in rows}
check("TXZ first reward HP", sx[281563]["hp"], 4)
check("TXZ second opening HP", sx[281565]["hp"], 4)
check("TXZ next GAME_OVER HP", (sx[281566]["hp"], sx[281566]["screen"]), (0, "GAME_OVER"))
check("TXZ second enemy remained at 111", [x["hp"] for x in sx[281566]["enemies"]], [111])
check("WQZ same T9 fingerprint", sx[282075]["fingerprint"], sx[282144]["fingerprint"])
check("WQZ T9 input HP and enemy HP", (sx[282075]["hp"], sx[282075]["enemies"][0]["hp"]), (26, 184))
check("WQZ T7 Escape increases sandpit", (sx[282330]["enemies"][0]["powers"]["SANDPIT_POWER"], sx[282331]["enemies"][0]["powers"]["SANDPIT_POWER"]), (4, 5))
check("WQZ T7 Escape actual HP cost", sx[282330]["hp"] - sx[282336]["hp"], 4)
check("NHA poison opening observed", sx[283147]["enemies"][0]["powers"]["POISON_POWER"], 10)
check("NHA T1 block comparison", (sx[283395]["block"], sx[283506]["block"]), (14, 8))
check("NHA T1 lamp negative strength and weak", (sx[283506]["enemies"][0]["powers"]["STRENGTH_POWER"], sx[283506]["enemies"][0]["powers"]["WEAK_POWER"]), (-2, 2))
save("fact-checks.json", checks)
print(json.dumps({"provenance_rows": sum(p["verified_rows"] for p in provenance), "own_runs": len(run_rows),
                  "drinks": len(drinks), "cunning_drinks": 42, "checks": len(checks),
                  "all_checks_passed": True}, ensure_ascii=False))

"""Check paired local observations without manufacturing later counterfactuals."""
from collections import Counter
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
turns = json.loads((OUT / "actionable-turns.json").read_text())
resources = json.loads((OUT / "resource-endpoints.json").read_text())
drinks = json.loads((OUT / "potion-transitions.json").read_text())["drinks"]
checks = []


def check(name, actual, expected, lines):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected,
                   "source_state_lines": lines, "passed": True})


def turn(run, floor, attempt, number):
    matches = [r for r in turns if (r["run"], r["floor"], r["attempt"], r["turn"]) == (run, floor, attempt, number)]
    assert len(matches) == 1
    return matches[0]


for run, floor, before_turn, after_turn, pairs in [
    ("TXZ6RVMQA09D", 48, 6, 7, [(2, 3, 36), (3, 0, 27)]),
    ("WQZVENQ7DTRP", 33, 9, 10, [(2, 13, 24), (3, 22, 39)]),
    ("WQZVENQ7DTRP", 33, 7, 8, [(2, 0, 24), (3, 0, 24), (6, 4, 24)]),
    ("NHA2KW0RB7VP", 33, 1, 2, [(1, 1, 8), (5, 7, 24), (6, 7, 24)]),
]:
    for attempt, loss, damage in pairs:
        a, b = turn(run, floor, attempt, before_turn), turn(run, floor, attempt, after_turn)
        actual = (a["hp"] - b["hp"], sum(e["hp"] for e in a["enemies"]) - sum(e["hp"] for e in b["enemies"]))
        check(f"{run} F{floor} attempt{attempt} T{before_turn} local net HP endpoints", actual, (loss, damage), [a["line"], b["line"]])

for floor, loss in [(2, 0), (3, 3), (4, 0), (5, 37), (11, 6), (15, 0)]:
    row = next(r for r in resources if r["run"] == "KEN58SH9SLZ6" and r["floor"] == floor)
    a = row["endpoints"][0]
    reward = next(s for s in row["endpoints"] if s["screen"] == "REWARD")
    check(f"KEN F{floor} won-fight net loss", a["hp"] - reward["hp"], loss, [a["line"], reward["line"]])

for run, floor, before, after in [
    ("KEN58SH9SLZ6", 12, 26, 53), ("KEN58SH9SLZ6", 16, 46, 75),
    ("1913SE84AXQF", 24, 40, 40), ("1913SE84AXQF", 28, 40, 61),
    ("1913SE84AXQF", 29, 61, 46), ("1913SE84AXQF", 31, 46, 0),
    ("Q6M2Y34MWKRE", 3, 44, 36), ("Q6M2Y34MWKRE", 7, 36, 57),
    ("Q6M2Y34MWKRE", 8, 57, 2), ("Q6M2Y34MWKRE", 9, 2, 0),
]:
    row = next(r for r in resources if r["run"] == run and r["floor"] == floor)
    a, b = row["endpoints"][:2]
    check(f"{run} F{floor} recorded resources", (a["hp"], b["hp"]), (before, after), [a["line"], b["line"]])

for attempt, expected in [(5, [2, 0, 0]), (6, [3, 2, 0])]:
    selected = [r for r in drinks if r["run"] == "WQZVENQ7DTRP" and r["floor"] == 33 and r["turn"] == 11 and r["attempt"] == attempt and r["potion"] == "CUNNING_POTION"]
    check(f"WQZ attempt{attempt} drink generation", [r["added_shivs"] for r in selected], expected, [r["after_line"] for r in selected])
    check(f"WQZ attempt{attempt} HP and energy unchanged by each drink", [(r["hp_before"] == r["hp_after"], r["energy_before"] == r["energy_after"]) for r in selected], [(True, True)] * 3, [r["after_line"] for r in selected])

selected_lines = {217009, 217010, 282767, 282768, 282887, 282888, 282889, 282890, 282891, 282892,
                  283146, 283147, 283398, 283399, 283395, 283506}
windows = {}
for folder in ["evidence", "original-evidence"]:
    for raw in (OUT / folder / "states.evidence.jsonl").open():
        e = json.loads(raw)
        if e["line"] in selected_lines:
            windows[e["line"]] = e
assert set(windows) == selected_lines
(OUT / "mechanism-windows.json").write_text(json.dumps(windows, ensure_ascii=False, indent=2) + "\n")


def state(line):
    return windows[line]["row"]["state"]


def power(line, ident):
    return next((p["amount"] for p in state(line)["combat"]["player"]["powers"] if p["power_id"] == ident), 0)


check("Q6 plain Strangle sequential enemy HP", [state(i)["combat"]["enemies"][0]["current_hp"] for i in [282887, 282888, 282889, 282890, 282891, 282892]], [103, 95, 85, 85, 83, 80], [282887, 282888, 282889, 282890, 282891, 282892])
check("1913 Abrasive selected discard energy", [state(i)["combat"]["player"]["energy"] for i in [282767, 282768]], [3, 3], [282767, 282768])
check("1913 Abrasive selected discard powers", [(power(i, "DEXTERITY_POWER"), power(i, "THORNS_POWER")) for i in [282767, 282768]], [(0, 0), (1, 4)], [282767, 282768])
check("NHA displayed facing damage", [(state(i)["combat"]["enemies"][0]["intents"][0]["damage"], state(i)["combat"]["enemies"][1]["intents"][0]["damage"]) for i in [283398, 283399]], [(1, 30), (2, 20)], [283398, 283399])
lamp_lines = [217009, 217010, 283146, 283147, 283395, 283506]
check("Lamp snapshots expose no consumption stack", [next(x["stack"] for x in state(i)["run"]["relics"] if x["relic_id"] == "UNSETTLING_LAMP") for i in lamp_lines], [None] * len(lamp_lines), lamp_lines)

(OUT / "extended-fact-checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"checks": len(checks), "all_checks_passed": True}))

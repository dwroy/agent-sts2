"""Write dispositions only for the ten dispatched proposal identities."""
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / "dispatch.json").read_text())
proposals = json.loads((OUT / "proposals.json").read_text())
base = dispatch["base"]
stamp = (OUT / "report-time.txt").read_text().strip()
live = json.loads((OUT / "source-audit.json").read_text())["live_head"]
cases = [
    {
        "evidence": "KEN58SH9SLZ6 A10：F3 T2、F4 T1、F5 T2、F11 T1/T2、F15 T1，共七次饮用且零丢弃；六场赢战净损0/3/0/37/6/0。F12 HP26→53、F16 HP46→75是真实休息回复。",
        "refs": "potion-transitions.json；resource-endpoints.json；states280169—280384；decisions274131/274156/274185/274235/274237/274267/274272。",
        "partial": "七次消费、六场净损和两次回复已逐帧核实；F15零净损仍用了两瓶药，不能当作未用药也零损。",
        "reason": "缺KEN同入口资源、同后续牌序的不饮用/留药至boss整战对照；已核资源结转不能校准药水持有价格。",
        "expected": "继续分开实际饮用、丢弃、休息回复和SL恢复；保留现持药价，不按本局七药耗尽设置留药阈值。",
        "verify": "未来同角色独立局按开始时间留出；成对核完整战斗与后继入口HP/药栏，不能只核一次饮用或局部净损。",
    },
    {
        "evidence": "TXZ6RVMQA09D A10 F48第2/3试T6：48HP、敌460HP；原线跨到T7为45HP/敌424，替线48HP/敌433，即损3/扣36与损0/扣27。第三试F48 T10奖励4HP，F49实验体开场4→0。",
        "refs": "states281479/281484/281535/281539/281563—281566；decisions275383—275385；selected-decisions.json。",
        "partial": "连战资源接续和开场扣血已有源码；本批资源链审计完成。F49敌仍111HP，实际死亡不归给其未执行的攻击。",
        "reason": "缺固定后续抽牌和生成牌的连续通关替线；T6省3血同时少扣9，首boss赢且余4血不能证明SL或连战排序改善。",
        "expected": "保留F48→F49目标和严格必死/SL规则；预测、实际首胜及两战结局分列，不把未校准0%用于放宽资格。",
        "verify": "按局隔离三次尝试；完整核原答、替线、重规划和后战可操作性。只有相同后继条件或后移独立验证才调整排序。",
    },
    {
        "evidence": "WQZVENQ7DTRP A10 F33第2/3试T9指纹完全相同，26HP/敌184HP；原线到T10为13HP/敌160，替线4HP/敌145，多花9血多扣15。末试T7同扣24，付4血使沙坑结束值3→4。",
        "refs": "states282075/282079/282144/282148/282066/282072/282330—282336；decisions275894/275960。",
        "partial": "候选比较源码已分别展示HP、敌HP/毒、沙坑和未知，且actual_turn_result=null；本批补实端点核对。",
        "reason": "缺血量与沙坑双边界的完整受控后继及独立成功验证；同轮9血/15伤和4血/一沙坑不能拟成固定换线阈值。",
        "expected": "保留双边界和实际差额，不用全败模拟称两线同安全，也不把延沙坑的逃离一律禁止。",
        "verify": "固定局部配对保持run内分组；完整核毒结算、沙坑与承伤顺序及后续牌序，死亡率饱和时仍保留未知。",
    },
    {
        "evidence": "派发中的八局加原提案SADL3CGYTGSR共九个狡诈来源局（A7/A9/A10）：42次饮用，37添3刀、2添2刀、3添0；WQ F33第5试T11为2/0/0，第6试为3/2/0，满手仍耗瓶且当步HP/能量不变。",
        "refs": "potion-transitions.json；states282292—282296/282352—282357；fact-checks.json；extended-fact-checks.json。",
        "partial": "CUNNING_POTION生成升级小刀、现场力量/弱、每步容量及出刀腾位已有实现；四个相关源码块与实际live相同。已有固定测试原文含穿插路径，但本批未运行代码测试。",
        "reason": "确定生成和当前容量已实现；缺计划妥当保留选择、完整候选派发与实际SL恢复的联合消费者验证，不能把局部容量实现当整项duplicate。",
        "expected": "沿现确定生成模型保留所有合法选项；保留后续选择和恢复为未知，不宣称穿插用药能救该局。",
        "verify": "冻结保留选择→饮用→出刀→重规划→过轮→SL恢复的完整身份链；逐步核手位和瓶槽，后续实战收益另外验证。",
    },
    {
        "evidence": "TXZ A10 F43/45/46/48新战入口70→66、52→48、62→58、60→56；F49为4→0。WQ同盘T9多9血换15扣血，末T7付4血延沙坑，与统一只保血规则构成限制。",
        "refs": "resource-endpoints.json；actionable-turns.json；TXZ states281312/281313/281338/281339/281367/281368/281399/281401/281565/281566。",
        "partial": "observedRoyalPoisonOpeningLoss与continuationInput已有实际live祖先源码，只覆盖观察组合；未知回血/复活组合保留。",
        "reason": "开场扣4及连战接续已有实现；缺留药、路线、SL完整受控后继与未知回复/复活组合结算顺序，不能关闭整个资源价值提案。",
        "expected": "仅已观察组合扣入口血价，当前实帧不重复扣，存档恢复不算新药/路线回复；不改持药、路线或SL权重。",
        "verify": "独立核新战、同战SL与已结算T1三个入口；首场末资源逐样本接续，组合缺证据时保留未知并等待本角色证据。",
    },
    {
        "evidence": "原提案1913SE84AXQF A10 F29赢61→46后F31入口46死亡；Q6M2Y34MWKRE A10 F7休36→57，F8赢损55至2，F9 T2死亡。Q6敏捷药F2 T3建立常驻2，速度药F8 T1建立临时5。",
        "refs": "original-evidence；resource-endpoints.json；potion-transitions.json；states282723/282745/282755/282869/282871/282873/282907/282914/282921。",
        "partial": "实际赢战退出HP、药栏和临时/持续药效已核；原F2早喝候选未完整实打，不能当真实省血或整局获救。",
        "reason": "缺隔离机制误差后的同预算完整后继，以及未用、早用、留药的成对整战结果；两条资源链不足拟合终局或药水权重。",
        "expected": "区分净损、实际回复、未来未兑现能力与用药时点，保持現有终局/药价规则。",
        "verify": "先隔离历史dirty源码与机制误差；相同起点和预算比较完整后继，并用后移独立局验证数值权重。",
    },
    {
        "evidence": "原提案Q6 A10 F8 T4：敌103→95（紧勒8）→85（突然一拳8+2）→83（生存者弃牌完成后2）→80（毒3）。1913 A10 F31 T2弃磨蚀能量3→3，敏捷0→1、荆棘0→4；随后仍死。",
        "refs": "mechanism-windows.json；states282887—282892/282767—282768；账本silent-0261/silent-0044/silent-0064/silent-0259等原链接。",
        "partial": "普通紧勒已在模型/求解器接线，普通磨蚀主动施放预览已有实现。弃磨蚀1/4是已核实际观测，尚不能把主动施放预览冒称自动弃牌路径已实现。",
        "reason": "普通紧勒和磨蚀主动预览已有实现；缺弃牌自动触发、增益分源、重接、逐击反伤及再生的完整联合消费者校准，不能以一个子公式关闭整项。",
        "expected": "已证普通紧勒沿用；保留自动施放、未知触发顺序及整战价值为未知，不把反杀前已执行敌攻取消，不把净伤当毛伤。",
        "verify": "按原选择身份和后继动作固定核弃牌结算→能力建立→后续挡→逐击反伤/重接/回复；缺机制分支不套已证无挡紧勒分支。",
    },
    {
        "evidence": "1913 A10 F24实际锻造40→40、F28休40→61、F29赢后46、F31死亡；Q6 A10 F3事件44→36、F7休36→57、F8赢后2、F9死亡。未来营火未抵达。",
        "refs": "resource-endpoints.json；extended-fact-checks.json；原提案Markdown及所属run-plans原字节。",
        "partial": "真实资源端点已复核；F24改锻造改变原计划条件，不能把投影与实值差全部当相同条件模型错误。",
        "reason": "缺另选营火、事件、路线及用药时机的完整受控结果；现有资源端点与计划条件变化不能拟合资源权重或因果收益。",
        "expected": "只记已完成回复，精英获胜仍计血价，未取得能力与未来营火不当当前资源；保持现路线/休息规则。",
        "verify": "按实际路线动作重算节点并核精英后强制走廊；改变条件单列，训练与验证按独立局和时间划分。",
    },
    {
        "evidence": "原提案NHA2KW0RB7VP A10 F33首试T1→T2为30→29HP/敌总408→400，第5/6试30→23/408→384；原答14挡与替线8挡，多付6血、多净扣16。初案精确切击被实际弃掉后重新规划。",
        "refs": "selected-decisions.json；decisions277248/277250/277272/277274；states283391/283397/283478/283483/283502/283507。",
        "partial": "预测比较及单次派发审计已有源码，明确execution=unverified或actual_turn=null。第一派发pending不直接断言整计划完成。",
        "reason": "预测比较已有实现；缺成对完整后继、整候选派发归属与同预算饱和排序校准；原计划被弃牌重规划，六次全败不能证明新门槛。",
        "expected": "保留即时血价与输出，但不据全败强制保血/禁探索；不能用抽牌前计划的21伤当跨轮真实24。",
        "verify": "原答→护栏→SL替换→每次派发→弃牌/重规划→完整轮端点全链核验；后移独立局校准饱和排序。",
    },
    {
        "evidence": "NHA A10 F17 T1毒药牌面5实际建10；F33 T1 X1萎靡给−2力/2弱。K3676LU8B0UH A1 F30 T2牌面4毒实建8。NHA F33 T2同虚弱/力量下朝向变化，爪1→2、火箭30→20。",
        "refs": "mechanism-windows.json；states217009—217010/283146—283147/283395/283506/283398—283399。",
        "partial": "精确切击/萎靡/第三轮能量等有既有局部实现；六个油灯消费前后样本的relic.stack均为null，牌面仍5或4，没有可直接依赖的首次已消费标志。",
        "reason": "油灯缺可靠首次消费来源及跨动作、新战、SL恢复联合验证；朝向取整仅局部观察，能力完整后继未证，不能把现场放大套到每次施用。",
        "expected": "保留已证子公式和未知边界；不将显示1再乘1.5取整冒作实值2，不预支未触发能力，不默认油灯每次翻倍。",
        "verify": "需要可靠实际动作历史、选牌副本/敌人身份与恢复边界，核首次标记和多种负面；升级、零X、叠层及未知朝向组合另取本角色证据。",
    },
]
assert len(cases) == len(proposals) == 10
results = []
sections = []
for item, case in zip(proposals, cases):
    results.append({"id": item["id"], "state": "waiting", "reason": case["reason"]})
    sections.append(f"""## {item['id']}

原提案：{item['summary']}。来源任务 `{item['source_task']}` → `strategy-proposal`。
角色：silent；观测进阶以证据逐局单列。关联账本：{', '.join(item['ledger'])}。
原Markdown：`{item['proposal']}`；SHA256 `{item['proposal_sha256']}` 已核一致，原文保留。

证据：{case['evidence']}

定位：{case['refs']}

已核部分：{case['partial']}

处置：**waiting**。{case['reason']}

既有行为与预期：{case['expected']}本批未改源码、游戏知识数据或生产参数。

反例与限制：原观察只支持所列局部时点；不同路线、后续抽序、生成牌及相关SL尝试不当独立因果样本。完整因果和未知组合不由预训练知识补齐。

验证方法：{case['verify']}本批已完成原日志字节/身份、局部端点和算术核验；这些是证据检查，不能替代源码回归、整模拟校准或自然消费者验收。

切分与回退：不训练数值权重；同局SL归一个run，后续真正独立局作时间留出。不改必死资格或未观察进阶；未来实现须独立提交与固定验证，失败回退该实现，保留原日志/提案/账本。
""")

intro = f"""# 本批静默策略提案逐项核验

记录时间：{stamp}。批次：`20261015-071302-strategy-proposal`。
基线：`{base}`；`git merge --no-edit main` 返回Already up to date。

本批仅消费learn.json绑定的十个proposal_ids；没有research_request或implementation_request。
普通专题根请求绑定另一批次，未承接专题、未读取另一专题work_spec、未扩展领取队列。
以下是原提案的证据与处置记录，未登记新游戏规则或重复提案ID。

十项都保持waiting；部分机制/诊断已在live有实现，宽提案仍缺联合验证、可靠恢复身份或完整后继证据。
"""
(OUT / "proposal.md").write_text(intro + "\n".join(sections))
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261015-071302-strategy-proposal",
          "base": base, "runs": dispatch["batch"]["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": [x["id"] for x in proposals], "implementation_domains": [],
          "proposal_results": results, "report": str(OUT / "report.md")}
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
provenance = json.loads((OUT / "provenance-verification.json").read_text())
count = sum(r["verified_rows"] for r in provenance)
matrix = "\n".join(f"| {r['folder']} | {r['stream']} | {r['verified_rows']} | {r['source_size']} |" for r in provenance)
summary_rows = "\n".join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
report = f"""# 静默策略学习回报

记录时间：{stamp}。本批十项原提案均已核验并保留waiting，没有足够的新证据支持改生产策略。
真实完整base为 `{base}`，HEAD保持该提交；源码差异与工作树状态将在verification.json读回。
无源码提交、无合入、无行为版本；fixes=[]、merged=null。不将既有局部实现记成整项implemented/duplicate或shipped。

## 身份和范围

- 本批learn.json：task=strategy-proposal、character=silent、reason=proposal、state=running，工作树与任务路径相同，十个proposal_ids顺序一致。dispatch.json保存对应行。
- 本批不满足专题身份，无research_request/implementation_request；notes/strategy-research-silent.json属于20261010另一批，不作为本批研究身份。普通基线merge已执行且无冲突。
- 十个派发锚点：{', '.join(dispatch['batch']['runs'])}。F4QKG4J1AJJZ为A9，其余九个A10。
- 仅为核对已派原文，补读其明确引用的五局：1913SE84AXQF/Q6M2Y34MWKRE/NHA2KW0RB7VP为A10，K3676LU8B0UH为A1，SADL3CGYTGSR为A7。不把这些历史来源当新增独立验证局，也不扩展领取提案。
- 15局runs原行均SILENT；各state.run.character_id亦逐帧核过，显式run_id/state.run_id/fingerprint.run/run冲突身份不接受。未读取其他角色知识目录。
- 十份原提案指纹全部与专用队列保存SHA一致；31个原账本项只按明确链接读取。完整冻结原文在本scratch，原提案和旧复盘未修改。
- 本会话未更改模型/账号/服务配置、未降强度或派子agent；未独立获得原生请求模型读回，不能把历史run-config的模型字段当当前会话模型验收。

## 证据冻结和核验

共核{count}条非重复原始所属记录，16个流切点分别保存source_size、output_sha256、逐行offset/bytes/SHA和计数。每条以seek重读源字节、核SHA、JSON正文与身份。
raw截点各流独立，不伪称全流原子快照。fight-plans在本次切点两组均0行，只表示该流/截点未选到，不能据此断言历史记录缺失。
原流全局invalid_lines由共用入口保存：states/decisions各2，brain1；不把被拒行算入所属证据。

| 证据组 | 流 | 核验所属行数 | source_size字节 |
|---|---|---:|---:|
{matrix}

早期early-decisions仅为提取期间先行查看，9448行逐SHA与最终规范decisions核对相同；不增加独立证据分母。
运行材料：provenance-verification.json、两个evidence-manifest.json、potion-transitions.json、actionable-turns.json、resource-endpoints.json、selected-decisions.json、mechanism-windows.json。

## 已核结论与限制

1. KEN七次真饮/零弃，六场赢战净损合46；F15零净损仍花两瓶药，F12/F16两次实际回复与SL恢复分账。没有不喝/留药的完整配对。
2. TXZ F48第2/3试T6局部损3/扣36对损0/扣27，省3血同时少扣9；首战奖励4HP，F49实验体111HP未被扣，4→0在可操作前。runs.death_fight旧字段仍列永世沙漏，原字段不改，以原state区分实际后战。
3. WQ同盘T9多9血换15敌净扣；末T7付4血延一沙坑轮、同扣24，限制“一律保血”与“一律多伤更安全”两种外推。整战均无已证替线胜因。
4. 九个狡诈来源局42次实饮与生成容量完全吻合：37×3、2×2、3×0，WQ满手分支耗瓶但HP/能量不变。模型中已具备确定小刀生成与逐步容量；保留选择和实际SL恢复联合消费者仍未闭合。
5. 1913/Q6真实后继入口分别46/2；锻造、事件、休息与赢战净损分开。Q6紧勒103→95→85→83→80证明局部2+2触发，当前普通紧勒已接线；弃磨蚀3费余额不变且建1敏/4荆棘是观测支持，但现有主动施放预览不等于自动弃牌路径完整验证。
6. NHA饱和换线实际多6损/多16敌净扣，初案精确切击实际被弃，重规划后才到端点；原预测不是整线实执行。油灯前后六窗stack均null，已观察首次放大不提供可靠跨动作消费状态或所有组合/恢复规则。朝向1→2与30→20只作该现场观察，不拟通用取整顺序。

不拟固定持药价、血价、SL阈值、终局曲线、留牌策略或胜率参数；同局多个SL和rollout样本不算独立对局。
本批54项事实断言通过（19+35），只证明冻结观测与算术，未运行boss模拟、LLM、网络或play；不称完整模拟校准、样本外玩法成功或自然消费者收益。

## 逐项处置

| 派发ID | 状态 | 具体缺口 |
|---|---|---|
{summary_rows}

逐项证据局号/层/回合、账本ID、旧行为、预期、反例、验证和回退见 `{OUT / 'proposal.md'}`。
CLI代码提案ID沿用原十项，未另建重复ID。实际implementation_domains=[]，不把只读核验冒成combat/potion/sl/terminal实现。

## 现有live源码核对

只读live切点 `{live}`；source-audit.json保存11叶Git内容SHA与真实祖先判定，source-blocks.json保存四个本提案相关代码块的base/live相同校验。
6叶字节完全相同；5叶整个文件不同，其中card-model/turn-solver/combat-plan/rollout-live包含live额外逃脱计划实现，另有Roy/Dai历史注释变化。未把整叶祖先存在当作文件相同或宽提案已实现，未覆盖live增量。
连战入口、剩余HP/已耗药水接续、普通紧勒和狡诈容量的既有局部逻辑已核；选择/派发审计保留actual_turn=null与execution未验证。现有测试文件只读定位，不借旧绿报告本次测试成功。

## 验证、记录与失败保留

源码未改，撤源码失败/恢复通过不适用；tsc、vitest、cases全部null。未运行完整/沙箱源码套件，未制造提交、合入、版本或上线通知。
学习账本仅经根目录ledger.py update追加这十项关联31原项的追溯位置和处置说明，未传status/version/evidence/claim，原shipped/proposed等状态与首证保留；ledger追加原字节回执单独保存。
gitleaks与最终HEAD/工作树读回保存到verification.json；本批不提交源码或材料，scratch由原调度器验收/回收，未删除自身工作树或原日志。

保留的过程限制：开工时部分只读命令因sandbox全局glob扫描瞬时缺路径被拒，重试成功；第一次证据检查脚本import路径错，audit-evidence.stderr.txt保留，修正后audit-evidence-2成功；若干只读源码猜测路径不存在，后用rg --files定位到真实模块，无源码改写。开工误输出旧fix-queue-v4一段跨角色历史队列，发现明确派发ID后停止使用，未复制该段到角色经验/结论，未据此补游戏知识。

ledger追加不代表入库或消费者采用；waiting保留待本角色新证据，不关闭Roy父要求，也不代填ops/watcher/Roy确认。final result.json与本报告为本批真实处置。
"""
(OUT / "report.md").write_text(report)
print(json.dumps({"report": str(OUT / "report.md"), "proposal": str(OUT / "proposal.md"),
                  "proposal_results": len(results), "fixes": []}, ensure_ascii=False))

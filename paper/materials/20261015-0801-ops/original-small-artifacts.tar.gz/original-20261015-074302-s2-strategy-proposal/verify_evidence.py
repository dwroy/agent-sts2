import collections
import hashlib
import json
from pathlib import Path

SCRATCH = Path(__file__).parent
EVIDENCE = SCRATCH / 'evidence'
BINDING = json.loads((SCRATCH / 'binding.json').read_text())
RUNS = BINDING['dispatch']['runs']
CHECKS = []


def check(name, actual, expected):
    CHECKS.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


def identity(row):
    state = row.get('state') or {}
    fingerprint = row.get('fingerprint') or {}
    if isinstance(fingerprint, str):
        fingerprint = json.loads(fingerprint)
    values = [row.get('run_id'), row.get('run'), state.get('run_id'), fingerprint.get('run')]
    return {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}


def powers(entity):
    return {p['power_id']: p['amount'] for p in entity.get('powers', [])}


def threat(enemy):
    return sum(i.get('total_damage') or 0 for i in enemy.get('intents', []))


def compact(envelope):
    state = envelope['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': envelope['line'], 'run': envelope['run_id'],
        'ts': envelope['row'].get('observed_ts'), 'screen': state['screen'],
        'floor': state.get('run', {}).get('floor'), 'turn': state.get('turn'),
        'hp': player.get('current_hp'), 'block': player.get('block'),
        'played': player.get('cards_played_this_turn'), 'powers': powers(player),
        'enemies': [{'id': e['enemy_id'], 'index': e['index'], 'hp': e['current_hp'],
                     'max_hp': e['max_hp'], 'block': e['block'], 'alive': e['is_alive'],
                     'powers': powers(e), 'move': e.get('move_id'), 'attack': threat(e)}
                    for e in combat.get('enemies', [])],
    }


def main():
    streams = {}
    manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
    readback = []
    for stream in manifest:
        name = stream['stream']
        path = EVIDENCE / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = dict.fromkeys(RUNS, 0)
        rows = []
        source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
        with source.open('rb') as origin, path.open('rb') as extracted:
            for raw in extracted:
                digest.update(raw)
                item = json.loads(raw)
                assert item['source'] == str(source)
                assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= stream['source_size']
                origin.seek(item['offset'])
                original = origin.read(item['bytes'])
                assert original.endswith(b'\n')
                assert hashlib.sha256(original).hexdigest() == item['sha256']
                row = json.loads(original)
                assert row == item['row']
                assert identity(row) == {item['run_id']}
                assert item['run_id'] in counts
                if name == 'states':
                    assert row['state']['run']['character_id'] == 'SILENT'
                    assert row['state']['run']['ascension'] == 10
                counts[item['run_id']] += 1
                rows.append(item)
        assert counts == stream['counts']
        assert digest.hexdigest() == stream['output_sha256']
        streams[name] = rows
        readback.append({'stream': name, 'source_size': stream['source_size'],
                         'counts': counts, 'verified_lines': len(rows),
                         'output_sha256': digest.hexdigest()})
    (SCRATCH / 'raw-readback.json').write_text(json.dumps(readback, ensure_ascii=False, indent=2) + '\n')
    states = {e['line']: e for e in streams['states']}
    decisions = {e['line']: e for e in streams['decisions']}
    relevant_floors = {'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39},
                       'CA5KE8GFJ9X2': {13}, '8JRE1C4H4Z2W': {17, 33},
                       'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}
    frames = [compact(e) for e in streams['states']
              if e['row']['state']['run']['floor'] in relevant_floors[e['run_id']]]
    (SCRATCH / 'relevant-frames.jsonl').write_text(''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in frames))
    pairs = []
    for a, b in [(270216, 270282), (271309, 271348), (271982, 272195), (271992, 272040)]:
        x, y = decisions[a]['row'], decisions[b]['row']
        check(f'完整同指纹 {a}/{b}', x['fingerprint'], y['fingerprint'])
        start = next(e for e in streams['states'] if e['run_id'] == decisions[a]['run_id']
                     and e['row'].get('observed_ts') == x['observed_ts'])
        end_points = []
        for d in (x, y):
            begin = next(e for e in streams['states'] if e['run_id'] == decisions[a]['run_id']
                         and e['row'].get('observed_ts') == d['observed_ts'])
            after = next(e for e in streams['states'] if e['line'] > begin['line']
                         and e['run_id'] == begin['run_id']
                         and (e['row']['state'].get('turn') != d['turn']
                              or not e['row']['state'].get('in_combat')))
            before, later = compact(begin), compact(after)
            assert later['hp'] is not None and later['hp'] > 0
            assert [(e['id'], e['index'], e['max_hp']) for e in before['enemies']] == [
                (e['id'], e['index'], e['max_hp']) for e in later['enemies']]
            end_points.append({'start_line': begin['line'], 'next_turn_line': after['line'],
                               'hp_lost': before['hp'] - later['hp'],
                               'enemy_hp_net_drop': sum(e['hp'] for e in before['enemies']) - sum(e['hp'] for e in later['enemies']),
                               'powers_before': before['powers'], 'powers_after': later['powers'],
                               'start': before, 'next_turn': later})
        pairs.append({'decisions': [a, b], 'run': start['run_id'], 'floor': x['floor'],
                      'turn': x['turn'], 'same_fingerprint': True, 'endpoints': end_points})
    for pair, expected in zip(pairs, [(3, 15, 10, 17), (0, 9, 45, 38),
                                      (2, 10, 25, 34), (9, 14, 24, 27)]):
        a, b = pair['endpoints']
        check(f"配对实果 {pair['decisions']}",
              (a['hp_lost'], b['hp_lost'], a['enemy_hp_net_drop'], b['enemy_hp_net_drop']), expected)
    (SCRATCH / 'paired-turns.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
    c = {n: compact(e) for n, e in states.items()}
    check('实验体换阶段前血/毒/力', (c[277512]['enemies'][0]['hp'], c[277512]['enemies'][0]['powers']['POISON_POWER'], c[277512]['enemies'][0]['powers']['STRENGTH_POWER']), (4, 4, 15))
    check('实验体换阶段后血/毒/力', (c[277513]['enemies'][0]['hp'], c[277513]['enemies'][0]['powers'].get('POISON_POWER', 0), c[277513]['enemies'][0]['powers'].get('STRENGTH_POWER', 0)), (212, 0, 0))
    check('船夹板轮初挡', (c[278236]['block'], c[278236]['played']), (14, 0))
    check('黑暗镣铐当轮力/攻击', (c[278237]['enemies'][0]['powers']['STRENGTH_POWER'], c[278237]['enemies'][0]['attack']), (-9, 0))
    check('黑暗镣铐次轮恢复', c[278242]['enemies'][0]['powers'].get('STRENGTH_POWER', 0), 0)
    check('双蟹激光初值', c[278249]['enemies'][1]['attack'], 57)
    check('双蟹激光转向后', c[278252]['enemies'][1]['attack'], 38)
    check('双蟹激光虚弱后', c[278254]['enemies'][1]['attack'], 28)
    check('双蟹末轮可用HP/挡/攻击', (c[278260]['hp'], c[278260]['block'], c[278260]['enemies'][0]['attack']), (11, 6, 17))
    check('棱柱T4火花', c[274830]['enemies'][0]['powers']['VITAL_SPARK_POWER'], 3)
    check('棱柱T4技能污染', c[274831]['powers']['TAINTED_POWER'], 3)
    check('棱柱T4能力不增污染', c[274832]['powers']['TAINTED_POWER'], 3)
    check('棱柱T4第二技能污染', c[274833]['powers']['TAINTED_POWER'], 6)
    check('棱柱T5火花增长', c[274834]['enemies'][0]['powers']['VITAL_SPARK_POWER'], 6)
    check('棱柱T5污染已清', c[274834]['powers'].get('TAINTED_POWER', 0), 0)
    check('棱柱T5三技能污染', [c[n]['powers']['TAINTED_POWER'] for n in [274836, 274837, 274838]], [6, 12, 18])
    check('棱柱T5毒挡来袭', (c[274838]['enemies'][0]['powers']['POISON_POWER'], c[274838]['block'], c[274838]['enemies'][0]['attack']), (13, 17, 26))
    check('棱柱T5实际血价', c[274834]['hp'] - c[274839]['hp'], 9)
    check('棱柱T6污染已清', c[274839]['powers'].get('TAINTED_POWER', 0), 0)
    check('蚌T1/3/5力量', [c[n]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) for n in [273237, 273252, 273263]], [0, 4, 8])
    check('蚌T1/3/5攻击', [c[n]['enemies'][0]['attack'] for n in [273237, 273252, 273263]], [11, 15, 19])
    check('蚌两次虚弱后攻击', [c[n]['enemies'][0]['attack'] for n in [273254, 273268]], [11, 14])
    check('蚌覆甲观察序列', [c[n]['enemies'][0]['powers']['PLATING_POWER'] for n in [273237, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6])
    check('蚌末帧生存条件', (c[273268]['hp'], c[273268]['block'], c[273268]['enemies'][0]['attack']), (2, 10, 14))
    check('抢夺T2玩家力敏', (c[274341]['powers']['STRENGTH_POWER'], c[274341]['powers']['DEXTERITY_POWER']), (-2, -2))
    check('抢夺T4玩家力敏', (c[274351]['powers']['STRENGTH_POWER'], c[274351]['powers']['DEXTERITY_POWER']), (-4, -4))
    check('两步法之后敏捷恢复0', c[274354]['powers'].get('DEXTERITY_POWER', 0), 0)
    check('失落退场之后力量恢复0', (len(c[274358]['enemies']), c[274358]['powers'].get('STRENGTH_POWER', 0)), (1, 0))
    check('遗忘后轮再次抢敏', (c[274362]['powers']['DEXTERITY_POWER'], c[274362]['enemies'][0]['powers']['DEXTERITY_POWER']), (-2, 6))
    z3 = next(e for e in c[274308]['enemies'] if e['id'] == 'ZAPBOT')
    z4 = next(e for e in c[274313]['enemies'] if e['id'] == 'ZAPBOT')
    check('电击当前同模板上限', (z3['max_hp'], z4['max_hp']), (23, 23))
    check('电击跨轮力/攻击', (z3['powers']['STRENGTH_POWER'], z4['powers']['STRENGTH_POWER'], z3['attack'], z4['attack']), (2, 4, 17, 19))
    check('电击高电压层数', (z3['powers']['HIGH_VOLTAGE_POWER'], z4['powers']['HIGH_VOLTAGE_POWER']), (2, 2))
    check('电击index已重排', (z3['index'], z4['index']), (4, 3))
    check('实验体T4双尖啸来袭', c[277516]['enemies'][0]['attack'], 0)
    check('实验体T5暂减力恢复来袭', c[277519]['enemies'][0]['attack'], 44)
    check('实验体零毒触媒已建', (c[277519]['enemies'][0]['powers'].get('POISON_POWER', 0), c[277519]['powers']['ACCELERANT_POWER']), (0, 2))
    check('实验体挡先于苦无', (c[277523]['block'], c[277523]['powers']['DEXTERITY_POWER']), (23, 5))
    check('实验体苦无不倒补挡', (c[277526]['block'], c[277526]['powers']['DEXTERITY_POWER']), (23, 6))
    check('实验体末轮净扣与截断死亡', (c[277519]['enemies'][0]['hp'] - c[277527]['enemies'][0]['hp'], c[277528]['hp']), (37, 0))
    check('船夹板加斗篷挡', c[278240]['block'], 20)
    check('双蟹最后毒结算', [e['hp'] for e in c[278261]['enemies']], [153, 125])
    success = [e for e in streams['sl-attempts'] if e['run_id'] == 'YF0LXT1QSTGG'
               and e['row'].get('floor') == 33 and e['row'].get('attempt') == 2]
    check('YF同局SL成功反例', [(e['row']['result'], e['row']['end_hp']) for e in success], [('won', 20)])
    summaries = []
    for run in RUNS:
        own = [e for e in streams['states'] if e['run_id'] == run]
        summaries.append({'run': run, 'state_count': len(own),
                          'decision_count': sum(e['run_id'] == run for e in streams['decisions']),
                          'floor_max': max(e['row']['state']['run']['floor'] for e in own),
                          'game_over': [compact(e) for e in own if e['row']['state']['screen'] == 'GAME_OVER']})
    (SCRATCH / 'run-summary.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2) + '\n')
    (SCRATCH / 'evidence-checks.json').write_text(json.dumps(CHECKS, ensure_ascii=False, indent=2) + '\n')
    failed = [e['name'] for e in CHECKS if not e['passed']]
    print(json.dumps({'verified_raw_lines': sum(e['verified_lines'] for e in readback),
                      'relevant_frames': len(frames), 'checks': len(CHECKS), 'failed': failed}, ensure_ascii=False))
    assert not failed


if __name__ == '__main__':
    main()

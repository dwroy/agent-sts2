# 静默策略学习批次回报

记录时间：2026-10-15T07:52:02+08:00。本次已完成十个已领取提案的证据与当前实现复核；十项均waiting。没有足够证据支持新的选择规则，也没有证明当前存在可由本批修复的新源码错误。局部审计已有实现，不能据此关闭原宽提案。

## 身份、范围与基线

- task=strategy-proposal，character=silent，batch=20261015-074302-s2-strategy-proposal，reason=proposal。learn.json本行proposal_ids正好十项，无proposal_repair、research_request或implementation_request；普通专题请求文件绑定的是其他旧批次，未承接专题，未读取其研究正文。
- 初始git status为空；git merge --no-edit main返回Already up to date。实际base/HEAD为`72286332ec835ee9929793543e435686935320ff`，没有源码提交。
- 只分析派发六局的原日志、本角色原提案、账本及相关复盘。相邻本角色复盘曾被过宽的行段读取带出，未作为本批证据或扩展选题；其他角色知识未读取或使用。
- 六份run-config对应的六个完整源码提交对象均存在，dirty_files只列知识/记录，没有agent源码。因此不能把dirty笼统说成源码不可复原；未取得的是与当时数据指纹精确绑定的刷新数据原字节，以及若干整候选/实体归属和反事实后继。historical-input-identity.json保存实际边界，当前数据不冒充旧数据。

| 局号 | 角色进阶 | 结局 | states | decisions |
| --- | --- | --- | ---: | ---: |
| DUZUBAJ3A8GP | A10 | F30败 | 623 | 602 |
| 5PM6JAQG6FNQ | A10 | F39败 | 660 | 638 |
| CA5KE8GFJ9X2 | A10 | F13败 | 282 | 265 |
| 8JRE1C4H4Z2W | A10 | F33败 | 676 | 659 |
| YF0LXT1QSTGG | A10 | F48败 | 1091 | 1065 |
| XP2SL33HT0D9 | A10 | F33败 | 730 | 712 |

## 原始证据与验证

通过本树learner/extract_evidence.py共用入口提取states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流。各流独立冻结source_size；evidence/evidence-manifest.json记录截点、逐局计数、输出SHA，逐行封套保留source/line/offset/bytes/SHA/row。verify_evidence.py对8,274条选中原行重新seek读取，逐项核原字节SHA、JSON正文和显式唯一身份；全部状态帧均为Silent/A10，计数和输出SHA一致。source_size是各流读取时点，不冒称全流原子截点。

run-plans识别顶层run，其他流核run_id/state.run_id/fingerprint.run等显式字段，不用正文提及认领身份。六局run-plans均有原行。fight-plans在本次截点六局均0行，只表示此输入未选到，不声明原日志永久缺失。全文件invalid_lines属于提取器的全局扫描计数，不归因给这六局。

50项固定证据断言通过，涉及污染/毒/挡、抢夺与返力、当前增长、覆甲观察、阶段重置、临减恢复、船夹板和朝向等。它们是原始证据一致性验证，**不是生产模型重放、自测成功、自然消费者采用或胜率校准**。初次17项中有一项将转向后帧误指到已施虚弱的278253，实际38攻击在278252；已按原帧纠正行号，不改数值或游戏规则。首败日志、首版脚本/断言及配对材料均保留，最终50项日志为evidence-verification-final.log。另保留提前读取尚空输出时的StopIteration说明及只读路径定位错误；均未造成源码/知识修改。

## 可核实的策略取舍与反例

| 完整同指纹配对 | 实际HP净损 原/替 | 敌本体HP净扣 原/替 | 本批可得结论 |
| --- | ---: | ---: | --- |
| 8JRE1C4H4Z2W F33 T2，d270216/270282 | 3/15 | 10/17 | 多12血只多7本轮净扣；0/24与5/24死亡并非同死率 |
| YF0LXT1QSTGG F48 T1，d271309/271348 | 0/9 | 45/38 | 多9血且少7净扣；全败/封顶并不消除本轮差异 |
| XP2SL33HT0D9 F33 T1，d271982/272195 | 2/10 | 25/34 | 多8血、多9净扣，同时建立手里剑力量；不抹去成长 |
| XP2SL33HT0D9 F33 T3，d271992/272040 | 9/14 | 24/27 | B2两线0胜并列仍多5血、多3净扣 |

配对来自同局同存档，不扩成独立训练/验证局；同指纹只控制该起点，不控制完整后继。表中净扣只在这些无阶段更换、无增援端点间计算，保留敌模板/index/上限核对，不当未封顶伤害或跨复活进度。paired-turns.json保存起止原帧和已建能力。未完成原候选的抽弃牌续步不得归给整候选；decision-facts.json保存原答、SL替换、候选numbers、理由及首次派发。

保留反例：YF同局F33第二次SL真实won余20HP（sl-attempts第929行），不能因F48六败禁止SL；XP末试T2零损、T3损4，不能只按舍挡牌数量判坏；已建立能力仍可能不足生存——YF末T5零毒触媒2、先有23挡/5敏、苦无后6敏仍23挡，18HP面对44攻击需损21；XP末T5为11HP+6挡对17攻击，毒实际结算后仍两敌153/125；8JRE最后延至T11仍死亡。未给这些机制的独立整战胜因或统一优先级。

## 十项处置

| 原CLI id | 既有账本 | 结果与具体缺口 |
| --- | --- | --- |
| silent-proposal-c20b5139dd0dff71 | silent-0168 | waiting：已核F27 T4/T5污染、火花增长及毒挡血价；未取得与原局数据指纹精确绑定的移动表冻结原字节和同输入生产多步联合校准，不能据单轮损9改技能选择。 |
| silent-proposal-ae9e692d680e3819 | silent-0183, silent-0005 | waiting：已核F39两次抢夺和失落退场返力；缺混合临时/永久增益的逐来源借还账、遗忘非清场死亡返敏端点，不能把现帧负属性公式当完整返还实现。 |
| silent-proposal-52f1e1bd2e7db0ed | silent-0231 | waiting：已核F13两次加压各加4力、弱后喷水及覆甲序列；缺覆甲减层触发的隔离证据与原数据指纹绑定的生产多步重放，现有首样本读取不能关闭整项。 |
| silent-proposal-6dd8bbff876be528 | silent-0233, silent-0209 | waiting：已核F38电击力2到4、攻击17到19；原帧index从4变3，缺跨召唤持久实例标识、增长重置联合校准及另一杀序后继。 |
| silent-proposal-578e415a259e6835 | silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016 | waiting：候选审计与单动作派发回执已有live祖先实现；仍缺整候选完成状态、抽弃牌重规划后的执行归属和独立完整替代胜线，不能将局部实现登记整项duplicate。 |
| silent-proposal-c0767768bf6a7ab1 | silent-0079 | waiting：已核F48同指纹开局多损9且净扣少7，并保留F33第二次SL获胜反例；缺弃牌后续步归属与受控完整胜线，不拟SL惩罚系数或禁止探索。 |
| silent-proposal-a46bdb7fe711d79a | silent-0021, silent-0027, silent-0028, silent-0085 | waiting：当前阶段现场快照已有live祖先实现，末试阶段清毒及23挡不倒补已核；缺阶段/遗物/抽弃牌的逐候选联合归因及实际消费者校准。 |
| silent-proposal-1044224808015e5c | silent-0079 | waiting：已核双蟹两组同指纹额外5/8血价及B2零胜并列；缺完整候选执行归属、受控随机池和独立整战胜线，不能证明新的并列排序有效。 |
| silent-proposal-7cbc6005db712ba9 | silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242 | waiting：已核轮初14挡、临减恢复和激光57到38到28；缺这些条件与成长在整候选中的联合传播和实际消费者校准，不能把局部公式存在当整项实现。 |
| silent-proposal-c59f592f1427a67e | silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242 | waiting：两局的局部机制、血价和已实现审计已核；缺所有子域整候选实际归属、联合校准及受控路线/留药后继，综合提案保留waiting。 |

逐项原文SHA、证据局/层/回合、旧规则/预期行为、验证与回退均在[proposal.md](proposal.md)。没有新建代码提案id；result.json的code_proposals是本批消费的十个真实既有CLI id，implementation_domains=[]表示本次没有领域实现。

## 当前源码与实际live边界

核对时live为`94113a1eac8a5443f033ac06223f2970522dedf6`。source-readback.json记录12个相关源码叶的base blob/SHA、live已提交blob SHA、实际工作副本SHA、最后源码commit与live祖先关系；12叶live工作副本均匹配该提交的blob。source-diff.patch为空，表明本树没有修改这些文件。

可确认的局部接线：候选比较/护栏/selection_audit接线`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`；单动作派发回执及loop接线`fdaf787a372880b0438e73bcac7e6d2168b038ed`；实验体当前帧事实及接线`aad2700abed6dff1d66e87fb36aaa6fedb39adf3`，均已核为当时live祖先。它们分别标注predicted_candidates、single_action_receipt、observed_current_snapshot，并明确actual_turn/whole_plan为null或未核；没有证明整候选完成与联合因果。

不能把本树HEAD或任意main祖先自动当live实现：combat-plan.ts、hand/loop.ts的最新提交并非该live祖先，两文件相较live还含模拟等待/降级接线差异；explore.ts有三处历史人名注释差异。live-source-differences.patch及live-callsite-ancestry.json记录实际范围。本批未合入这些并行改动。怪物读取现有amountAt/moveDamageAt路径保留，ROOM_COST_MIN_N=5保留；没有添加游戏常数或修改其他角色行为。

## 账本、交付与测试

只经根目录learner/ledger.py update给十项关联的30个既有Silent账本追加本批proposal/report追溯和核验说明。不重复追加同一旧证据为新support，不改claim、first_run、prior、status、version、shipped_at，不把过去已shipped的机制降回proposed。没有新增学习条目或提案需要置proposed，更没有登记shipped。CLI输入/输出与前后受保护字段读回另存本目录；原队列由调用方依proposal_results接续，模型不手改learn.json或队列状态。

无生产源码/知识变更，fixes=[]，merged=null，tsc/vitest/cases均null；未运行撤源码红绿、沙箱源码测试、提交、live合入或创建eval版本。50项是证据断言，不填写成源码测试case通过。现有源码的历史检查不冒作本批成功。本树保持干净，原始日志只读；不运行play、不推送，不改运维prompt。没有新规则实际上线，因此没有旧新规则双通知或shipped。

报告路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-074302-s2/learner/runs/20261015-074307-7ecdf3b0-9b0d-4ed9-9a4f-bd5072d8020b-strategy-proposal/report.md`；提案路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-074302-s2/learner/runs/20261015-074307-7ecdf3b0-9b0d-4ed9-9a4f-bd5072d8020b-strategy-proposal/proposal.md`。最终result.json逐项保存waiting及缺数据原因，供运维按原调度批次消费。后续新证据仍须按本角色/进阶、独立run和结束时间分组，不能把六个尝试当六个独立胜率样本。

局限：没有整候选归属、未执行替线、随机池受控全战及原刷新数据的完整校准，故不能给新的策略系数或宣称整战改善；未核本轮原生会话模型/强度，不用六局历史运行设置代证当前模型。临时一次沙箱启动失败发生在命令执行前，原错误保留，不算代码或测试失败。

## 最终读回

根账本CLI实际exit0，30条本批精确追加均已在根账本读回；受保护字段前后差异为空，proposal/report链接均存在（ledger-append-readback.json）。最终git status为空，HEAD仍为完整base。gitleaks对本批约193.21 MB产物扫描exit0、no leaks found（gitleaks.log及gitleaks-report.json）；这不是源码测试。完成记录为completion-readback.json，逐项最终回报为result.json。

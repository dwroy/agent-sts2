"""Verify frozen source lines and prepare bounded own-character observations."""
import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
RUNS = DISPATCH['runs']


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = {}
    fp = fp if isinstance(fp, dict) else {}
    ids = {v for v in [row.get('run_id'), row.get('run'), state.get('run_id'), fp.get('run')]
           if isinstance(v, str) and v and v != 'run_unknown'}
    assert len(ids) == 1, ids
    return next(iter(ids))


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


streams = {}
checks = []
for entry in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
    name = entry['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = dict.fromkeys(RUNS, 0)
    items = []
    source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
    with source.open('rb') as original, path.open('rb') as frozen:
        for raw in frozen:
            digest.update(raw)
            item = json.loads(raw)
            assert item['source'] == str(source)
            assert item['offset'] + item['bytes'] <= entry['source_size']
            original.seek(item['offset'])
            data = original.read(item['bytes'])
            assert hashlib.sha256(data).hexdigest() == item['sha256']
            assert data.endswith(b'\n') and json.loads(data) == item['row']
            assert identity(item['row']) == item['run_id'] and item['run_id'] in RUNS
            if name == 'states':
                run = item['row']['state'].get('run') or {}
                assert run.get('character_id', 'SILENT') == 'SILENT'
                assert run.get('ascension', 10) == 10
            counts[item['run_id']] += 1
            items.append(item)
    assert counts == entry['counts']
    assert digest.hexdigest() == entry['output_sha256']
    checks.append({'stream': name, 'verified': sum(counts.values()), 'counts': counts,
                   'source_size': entry['source_size'], 'output_sha256': digest.hexdigest()})
    streams[name] = items

run_rows = {item['run_id']: item['row'] for item in streams['runs']}
assert set(run_rows) == set(RUNS)
for run in run_rows.values():
    assert run['character'] == 'SILENT' and run['ascension'] == 10
write('verified-evidence.json', {'streams': checks, 'total': sum(x['verified'] for x in checks),
                                  'runs': run_rows})

states = {item['line']: item for item in streams['states']}
decisions = {item['line']: item for item in streams['decisions']}


def power_list(entries):
    return {entry['power_id']: entry.get('amount') for entry in entries or []}


def snapshot(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
            'run_id': item['run_id'], 'floor': run.get('floor'), 'turn': state.get('turn'),
            'observed_ts': item['row'].get('observed_ts'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
            'block': player.get('block'), 'energy': player.get('energy'),
            'powers': power_list(player.get('powers')),
            'hand': [{'index': c.get('index'), 'id': c['card_id'], 'upgraded': c.get('upgraded'),
                      'cost': c.get('energy_cost'), 'values': {v['name']: v.get('current_value')
                                                             for v in c.get('dynamic_values') or []}}
                     for c in combat.get('hand') or []],
            'enemies': [{'index': e['index'], 'id': e['enemy_id'], 'hp': e['current_hp'],
                         'block': e.get('block'), 'move': e.get('move_id'),
                         'powers': power_list(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies') or []],
            'deck_upgrades': sum(bool(c.get('upgraded')) for c in run.get('deck') or [])}


selected = {'VLZ6CCT8AQ0A': {35, 43, 45}, '8JRE1C4H4Z2W': {17, 33},
            'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 39},
            '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}
observations = [snapshot(item) for item in streams['states']
                if (item['row']['state'].get('run') or {}).get('floor') in selected[item['run_id']]]
write('combat-observations.json', observations)

assertions = []


def check(label, condition, refs):
    assert condition, label
    assertions.append({'claim': label, 'verified': True, 'state_lines': refs})


a, b = snapshot(states[275564]), snapshot(states[275565])
check('VLZ F35 T1 神化能量7→5', (a['energy'], b['energy']) == (7, 5), [275564, 275565])
for card, field, pair in [('DEFEND_SILENT', 'Block', (5, 8)), ('STRIKE_SILENT', 'Damage', (7, 10)),
                           ('DAGGER_SPRAY', 'Damage', (5, 7))]:
    values = tuple(next(c['values'][field] for c in s['hand'] if c['id'] == card) for s in [a, b])
    check(card + ' 实见升级', values == pair, [275564, 275565])
tools = tuple(next(c['cost'] for c in s['hand'] if c['id'] == 'TOOLS_OF_THE_TRADE') for s in [a, b])
check('必备工具1→0费', tools == (1, 0), [275564, 275565])
a, b = snapshot(states[275679]), snapshot(states[275680])
for card, field, pair in [('FASTEN', 'ExtraBlock', (4, 6)), ('PIERCING_WAIL', 'StrengthLoss', (6, 8)),
                           ('SUCKER_PUNCH', 'Damage', (9, 11)), ('SUCKER_PUNCH', 'WeakPower', (1, 2))]:
    values = tuple(next(c['values'][field] for c in s['hand'] if c['id'] == card) for s in [a, b])
    check(card + '.' + field, values == pair, [275679, 275680])
check('F43战外deck升级数仍4', all(snapshot(states[n])['deck_upgrades'] == 4
                                 for n in [275679, 275680, 275687]), [275679, 275680, 275687])
check('8JRE首试与第三试F33T2指纹逐字一致',
      decisions[270216]['row']['fingerprint'] == decisions[270282]['row']['fingerprint'], [])

fixture = json.loads(Path('agent/tests/silent-apotheosis-evidence.json').read_text())
for key, line in fixture['source_lines'].items():
    raw = states[int(line)]['row']['state']['combat']
    for field, saved in fixture['frames'][key].items():
        assert raw[field] == saved, (key, field)
    assertions.append({'claim': '固定神化夹具与原帧相同: ' + key, 'verified': True,
                       'state_lines': [int(line)]})
write('assertions.json', assertions)

for run_id in RUNS:
    source = {'run': run_rows[run_id]}
    for stream in ['states', 'decisions']:
        source[stream] = [{**item['row'], '_line': item['line']} for item in streams[stream]
                          if item['run_id'] == run_id]
    write('selection-input-' + run_id + '.json', source)

print(json.dumps({'total_verified_rows': sum(x['verified'] for x in checks),
                  'assertions': len(assertions), 'selected_observations': len(observations),
                  'runs': {run: {'character': r['character'], 'ascension': r['ascension'],
                                 'floor': r['floor'], 'victory': r['victory'], 'code': r['code']}
                           for run, r in run_rows.items()}}, ensure_ascii=False, indent=2))

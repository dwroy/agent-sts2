"""Verify observations from the original proposals without fitting strategy constants."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
OBS = json.loads((OUT / 'combat-observations.json').read_text())
STATES = {row['line']: row for row in OBS}
checks = []


def check(claim, value, expected, lines):
    assert value == expected, (claim, value, expected)
    checks.append({'claim': claim, 'actual': value, 'expected': expected, 'source_lines': lines})


a, b = STATES[275679], STATES[275687]
check('F43T1 敌本体净扣51，玩家净损13',
      [a['enemies'][0]['hp'] - b['enemies'][0]['hp'], a['hp'] - b['hp']], [51, 13], [275679, 275687])
a, b, c = [STATES[n] for n in [275750, 275754, 275755]]
attack = lambda s: sum(i.get('total_damage') or 0 for e in s['enemies'] for i in e['intents'] or [])
check('F45T5 四段减力后的显示来袭83→59', [attack(a), attack(b)], [83, 59], [275750, 275754])
check('F45T5现场32HP、20挡、覆甲0', [b['hp'], b['block'], b['powers'].get('PLATING_POWER', 0)],
      [32, 20, 0], [275754])
check('显示来袭减挡为39，超当前HP7；不等于实付损血', [attack(b) - b['block'], attack(b) - b['block'] - b['hp']],
      [39, 7], [275754])
check('F45结局三敌仍存活，2毒在触媒下净扣3',
      [e['hp'] for e in c['enemies']], [21, 80, 77], [275754, 275755])

for lines, expected in [([273237, 273252, 273263], [11, 15, 19])]:
    check('蚌无弱意图11→15→19', [attack(STATES[n]) for n in lines], expected, lines)
check('蚌力量0→4→8', [STATES[n]['enemies'][0]['powers'].get('STRENGTH_POWER', 0)
                            for n in [273237, 273252, 273263]], [0, 4, 8], [273237, 273252, 273263])

a, b = STATES[273503], STATES[273504]
check('吸取后力2→0、敏0→−2，敌力0→2',
      [a['powers'].get('STRENGTH_POWER', 0), b['powers'].get('STRENGTH_POWER', 0),
       a['powers'].get('DEXTERITY_POWER', 0), b['powers'].get('DEXTERITY_POWER', 0),
       a['enemies'][0]['powers'].get('STRENGTH_POWER', 0), b['enemies'][0]['powers'].get('STRENGTH_POWER', 0)],
      [2, 0, 0, -2, 0, 2], [273503, 273504])
check('T6毒17及16仍结算净扣33', STATES[273504]['enemies'][0]['hp'] - STATES[273508]['enemies'][0]['hp'],
      33, [273504, 273508])
a, b = STATES[273593], STATES[273596]
check('胧光怪F23T4端点净损15、本体及幻象净扣47',
      [a['hp'] - b['hp'], sum(e['hp'] for e in a['enemies']) - sum(e['hp'] for e in b['enemies'])],
      [15, 47], [273593, 273596])
check('T5幻象仍2血、两实体力量均6', [b['enemies'][0]['hp']] + [e['powers']['STRENGTH_POWER'] for e in b['enemies']],
      [2, 6, 6], [273596])
a, b = STATES[275017], STATES[275018]
beetle = lambda s: next(e for e in s['enemies'] if e['id'] == 'SLUMBERING_BEETLE')
check('甲虫临时−4力恢复并成长至4，显示14→22',
      [beetle(a)['powers']['STRENGTH_POWER'], beetle(b)['powers']['STRENGTH_POWER'],
       beetle(a)['intents'][0]['total_damage'], beetle(b)['intents'][0]['total_damage']],
      [-4, 4, 14, 22], [275017, 275018])
check('甲虫末轮1HP、16挡对22显示攻击', [STATES[275022]['hp'], STATES[275022]['block'], attack(STATES[275022])],
      [1, 16, 22], [275022])

run = json.loads((OUT / 'selection-readback-8JRE1C4H4Z2W.json').read_text())
turn = lambda a, t: next(x for x in run['turns'] if x['floor'] == 33 and x['attempt'] == a and x['turn'] == t)
first, third = turn(1, 2), turn(3, 2)
check('同指纹首试和第三试T2净损3/15，净扣敌10/17',
      [-first['facts']['player_hp_delta'], -third['facts']['player_hp_delta'],
       -first['facts']['enemy_hp_changes'][0]['hp_delta'], -third['facts']['enemy_hp_changes'][0]['hp_delta']],
      [3, 15, 10, 17], first['source_lines'] + third['source_lines'])
terminal = run['terminal_endpoints'][0]['terminal_observation']['facts']
check('末试T11零血截断净损5，显示攻击减挡15',
      [-terminal['player_hp_delta'], terminal['displayed_attack_reference']['attack_minus_block'],
       terminal['actual_uncapped_damage']], [5, 15, None], [270441, 270442])

source = json.loads((OUT / 'selection-input-5PM6JAQG6FNQ.json').read_text())
index = {}
for row in source['states']:
    index.setdefault((row.get('observed_ts'), row.get('fingerprint')), []).append(row)
bubble = []
for i, decision in enumerate(source['decisions'][:-1]):
    if (decision.get('floor'), decision.get('turn')) != (39, 2):
        continue
    chosen = decision.get('chosen') or {}
    if chosen.get('action') != 'play_card':
        continue
    before = index.get((decision.get('observed_ts'), decision.get('fingerprint')), [])
    next_decision = source['decisions'][i + 1]
    after = index.get((next_decision.get('observed_ts'), next_decision.get('fingerprint')), [])
    if len(before) != 1 or len(after) != 1:
        continue
    a, b = before[0]['state']['combat'], after[0]['state']['combat']
    card = next((c for c in a['hand'] if c['index'] == chosen.get('card_index')), {})
    if card.get('card_id') != 'BUBBLE_BUBBLE':
        continue
    assert decision['_line'] + 1 == next_decision['_line']
    assert (decision['floor'], decision['sl_attempt'], decision['turn']) == (
        next_decision['floor'], next_decision['sl_attempt'], next_decision['turn'])
    value = [a['player']['current_hp'], b['player']['current_hp'],
             a['player']['energy'] - b['player']['energy'],
             sum(e['current_hp'] for e in a['enemies']) - sum(e['current_hp'] for e in b['enemies'])]
    check('无毒目标冒泡的相邻观察区间', value, [29, 29, 1, 0],
          [before[0]['_line'], after[0]['_line']])
    assert all(not any(p['power_id'] == 'POISON_POWER' for p in e['powers']) for e in a['enemies'] + b['enemies'])
    bubble.append({'decision_line': decision['_line'], 'attempt': decision['sl_attempt'], 'value': value})
assert bubble

(OUT / 'claim-checks.json').write_text(json.dumps({'checks': checks, 'bubble_observations': bubble},
                                                ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'bubble_observations': bubble}, ensure_ascii=False, indent=2))

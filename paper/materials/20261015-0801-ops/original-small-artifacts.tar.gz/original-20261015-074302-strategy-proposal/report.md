# 静默策略队列复核报告

生成切点：2026-10-15T07:52:21+08:00（写时间前已运行date）。
批次：20261015-074302-strategy-proposal；角色silent。

本批十项均为waiting。未发现可据本批证据独立校准的新策略参数，现有局部实现也未覆盖各原提案的全部职责。没有源码、知识或行为修改，没有提交、live合入、新版本或shipped；不将合法的证据不足冒报为实现成功。

## 身份和基线

- 初始git status干净，HEAD及main为完整40位`72286332ec835ee9929793543e435686935320ff`；按普通任务执行`git merge --no-edit main`，结果Already up to date。本批base保持该值。
- 根learn.json对应行task/character/worktree/runs与本任务一致，reason=proposal，proposal_ids恰为十项；没有research_request、implementation_request或proposal_repair。普通专题请求文件绑定的是另一历史批次，不转成本批专题，也不读取其他专题代替。
- 原生线程`01a13ccc-5cea-7a11-906c-cb5a9b2a7b9b`的session_meta/turn_context已按原行offset/bytes/SHA核实，cwd正确、实际model=gpt-6.1-sol、effort=xhigh、workspace-write、approval never、network false。宿主启动参数service_tier=default。任务文字的high与宿主实际xhigh不一致，本批如实保留，没有修改运行配置或声称切换。详见`runtime-metadata.json`。
- 独立完成；未派下级agent，未联网，未运行play，未读凭据或游戏二进制，未修改并行工作树。

## 冻结证据与实际读回

共用extract_evidence入口完整结束，exit0。八条流各自先冻结source_size，彼此不是同一原子时间快照；输出SHA、逐局计数在`evidence/evidence-manifest.json`。`verify_evidence.py`对全部6995条做显式身份、原行字节/SHA及正文读回，exit0。

| 流 | 本批核实原行数 |
| --- | ---: |
| states | 3432 |
| decisions | 3306 |
| sl-attempts | 29 |
| run-config | 6 |
| run-plans | 33 |
| brain | 183 |
| runs | 6 |
| fight-plans | 0 |

fight-plans的0只表示本次冻结截点未选到本批显式身份行，不据此断言原日志不存在。run-plans使用run字段选局，没有把正文提及当身份。六份runs记录均SILENT/A10且已结束，各自原code均带dirty；SL尝试不增独立局分母。

原提案10份Markdown均逐SHA匹配并保存原字节。17条升级/指纹/既有夹具断言及16条直接观察断言通过，原始结果见`verification.log`、`assertions.json`、`claim-checks.json`。它们不是生产源码自测或时间后移泛化结果。

对既有离线消费者的实际调用见`selection-readback-v3.log`：

| 局号 | 预测段 | 动作观察区间 | 整轮端点窗口 | 完整候选结果认证 |
| --- | ---: | ---: | ---: | ---: |
| VLZ6CCT8AQ0A | 99 | 77 | 10 | 0 |
| 8JRE1C4H4Z2W | 113 | 264 | 44 | 0 |
| 5PM6JAQG6FNQ | 83 | 202 | 25 | 0 |

另有8JRE和5PM各1个终局观察区间。这三局共79个整轮端点窗口只给净变化与重问边界，不给单候选因果或未封顶实伤。其他三局完整输入被原身份闸拒收：CA的decision267143、61的267517、DU的268789/268818/268864缺decision_id；未删原行、未补ID、未把拒收说成分析成功。三局直接状态事实及原行字节仍已核实。详见`audit-input-quality.json`。

关键核实包括VLZ F43T1净伤51/净损13，F45T5显示83→59攻击且只有20挡；8JRE同指纹T2净损3/15与净扣10/17，末试T11零血截断净损5、显示攻击减挡15；5PM无毒冒泡实耗1能且无毒/敌血变化；61吸取后的力/敏变化、毒仍结算及胧光怪幻象存活；DU甲虫临时减力恢复并成长。上述均只支持相应条件，未选线路、胜率与排序收益保持未知。

## 十项处置

完整证据局号/层/回合/账本、反例、旧/预期行为和验证方法均在同目录`proposal.md`的各原id章节；最终逐项结果保存在`result.json`。

| 原提案 | 处置 | 尚缺范围 |
| --- | --- | --- |
| silent-proposal-89354805ee4d7e77 | waiting | 神化实际施放持续身份与未覆盖交互校准 |
| silent-proposal-f2bfceddb1898dca | waiting | 校准模型下同总预算MC配对及稳定性曲线 |
| silent-proposal-283a164780d11e69 | waiting | 与神化原提案共享的完整交付；补链不等于实现 |
| silent-proposal-ebbfe3b97548756d | waiting | 15条原经验的组合、期限及跨消费者联合校准 |
| silent-proposal-e5b87be50f28f311 | waiting | 跨重规划持续候选身份与完整生产状态归属校准 |
| silent-proposal-49632bc4878fb597 | waiting | 本局未观察正敏捷，复合属性实际调用输入不足 |
| silent-proposal-66532328a585941f | waiting | 同资源/完整抽序的启动顺序整战配对和收益函数 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 同起点及完整抽序的SL线路比较 |
| silent-proposal-5264153a4a4b0e5c | waiting | 逐实体召唤/复现/成长/退场全链及另focus后继 |
| silent-proposal-bddfa690a84e03d0 | waiting | 伤害唤醒/眩晕期限全链与同抽不同排序后继 |

不要求纯审计先得到胜局；但也不把端点净扣补写成完整候选执行。需要策略效果的请求与只需记录差值的请求分别评估，等待原因不会把两者混为一谈。

## 源码、账本与交付

冻结live读回提交为`94113a1eac8a5443f033ac06223f2970522dedf6`。17个相关源码叶中14个与本base完全相同；card-model仅历史注释差异，combat-plan/loop还有并行的完整模拟等待/降级接线差异，因此不声称整树等价。神化窄传播、候选审计、派发回执和离线观察模块的实际live祖先与逐叶SHA保存在`source-readback.json`。已有实现的范围在提案中逐项注明，没有把任何局部祖先冒填为整个宽提案implemented/duplicate。

本批通过根`learner/ledger.py update`仅追加原有条目的本报告追溯，不新增经验或重复证据，不降级已有shipped条目。CLI输入、退出和保护字段读回见`ledger-updates.jsonl`、`ledger-update.log`、`ledger-readback.json`。code_proposals列表为这十个已经登记并派发的原CLI id，未重复add，implementation_domains为空。

源码修改：无；源码提交：无；撤源码失败/恢复通过：不适用；tsc/vitest/cases均null；merged=null；版本无。只读证据核验和离线审计不是沙箱整套测试。工作树源码及知识保持零差异，最终git status与diff读回见`final-verification.json`。

## 限制和过程记录

- 本批只有六局旧锚点，没有新增独立验证局；同局SL、同指纹和发现用夹具均不增加独立样本，不拟合预算、血价、目标、SL、留药或构筑常数。
- 实际cast/候选持续身份、跨重规划归属、完整随机抽序、未选线路及未封顶实伤不齐；保持null及等待，未观察进阶与其他角色不改。
- 纯研究请求不属于本批；不关闭量化父要求或宣称经验已入库/消费者已采纳策略。
- 最初一次误读fix-queue开头历史段及源diff中的旧跨角色注释，没有用于任何本批游戏结论；本批未读取其他角色知识目录，后续选题始终限定十个领取id。
- 只读预检曾猜错player-model.ts及一个CLI/参考文件路径；原工具错误留史，随后按实际文件发现修正，不把路径错误当缺证。
- 一次样本形状探查未处理非战斗combat=null而退出，未影响正式核验。正式核验只用已保存原字节，exit0。
- 离线消费初次脚本相对导入少一级，ERR_MODULE_NOT_FOUND原件在selection-readback.err；修正后的v2遇旧局空decision_id中止，原件在selection-readback-v2.err；v3逐局保留拒收并继续独立输入，exit0。没有改生产闸或补造旧字段。
- 初版输入质量统计把缺失的null身份算作重复；初版保留audit-input-quality.initial.json，纠正后非空ID重复与时间倒退均0，缺失身份仍逐行列出。

没有新的游戏反证或与既有已勘误结论冲突；不重复发通知，也不代填ops、watcher或Roy的确认。未完成项沿原队列等待新证据，原件、失败回执和本工作树保留。

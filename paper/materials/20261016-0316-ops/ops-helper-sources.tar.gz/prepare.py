from pathlib import Path
import collections, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile
sys.dont_write_bytecode=True
root=Path.cwd(); p=root/'ops/codex-ops/record-staging/20261016-0316'; pub=root/'paper/materials/20261016-0316-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-025902-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report==scratch
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert set(report['code_proposals'])==set(b['proposal_ids'])=={x['id'] for x in report['proposal_results']}
assert report['skipped']==[{k:v for k,v in x.items() if k!='state'} for x in report['proposal_results']]
assert report['fixes']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'completion-validation.json');assert final['base']==report['base'] and final['tracked_worktree_clean'] and final['source_knowledge_diff']=='zero'
assert final['proposal_results']=={'waiting':10} and final['new_commits']==[] and final['merged'] is None and final['production_tests']==report['tests']
assert final['ledger_own_rows']==final['ledger_protected_items']==32 and final['evidence_verified_lines']==6606
assert final['offline_invocations']==6 and final['offline_accepted_complete']==4 and final['offline_accepted_bounded']==final['offline_rejected_complete_retained']==1
assert final['gitleaks_directory_exit']==final['gitleaks_final_text_exit']==0 and load(s/'gitleaks.json')==load(s/'gitleaks-final-text.json')==[]
for name,digest in load(s/'delivery-sha256.json').items():assert sha((s/name).read_bytes())==digest
originals=load(s/'proposal-source-checks.json');assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:assert Path(x['path']).is_relative_to(root) and sha(Path(x['path']).read_bytes())==x['sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');runs=load(s/'run-identities.json')
assert len(runs)==5 and {x['run'] for x in runs}==set(report['runs']) and all(x['character']=='SILENT' and x['ascension']==10 for x in runs)
counts={};receipts=load(s/'evidence/evidence-manifest.json')
for x in receipts:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row']
            assert extract.run_identity(row)==e['run_id'] in report['runs'] and e['offset']+e['bytes']<=x['source_size']
            if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
            if x['stream']=='runs':assert row['character']=='SILENT' and row['ascension']==10 and not row['victory']
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and all(seen.get(run,0)==n for run,n in x['counts'].items());counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==6606
validation=load(s/'evidence-validation.json');assert validation['total_lines']==6606 and validation['proposals_sha_verified']==10
assert all(x['bytes_identity_sha_verified'] and counts[x['stream']]==x['lines'] for x in validation['streams'])
source=load(s/'source-readback.json');assert source['base']==report['base'] and len(source['files'])==14
assert git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_head']
for x in source['files']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_head_sha256'] and sha((root/'.worktrees/live'/x['path']).read_bytes())==x['live_worktree_sha256']==sha(z)
    assert (a==z)==x['base_equals_live_head']==x['base_equals_live_worktree'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['base_equals_live_head'] for x in source['files'])==12
for x in source['narrow_sources']:
    assert x['base_ancestor'] and x['live_ancestor']
    for head in [report['base'],source['live_head']]:git('merge-base','--is-ancestor',x['commit'],head)
consumers=load(s/'offline-audit-receipts.json');summaries=load(s/'offline-audit-summary.json');turn_statuses=load(s/'offline-turn-statuses.json')
assert len(consumers)==6 and collections.Counter((x['mode'],x['exit_code']) for x in consumers)=={('complete',0):4,('complete',1):1,('bounded',0):1}
totals=collections.Counter();excluded=[]
for x in consumers:
    stem=x['input'].removesuffix('.input.json')
    for suffix,key in [('.input.json','input_sha256'),('.output.json','output_sha256'),('.stderr.log','stderr_sha256')]:assert sha((s/(stem+suffix)).read_bytes())==x[key]
    if x['exit_code']:
        assert x['run']=='P74C04AEPL1F' and (s/(stem+'.output.json')).stat().st_size==0
        assert b'decision_id' in (s/(stem+'.stderr.log')).read_bytes();continue
    actual=load(s/x['input']);audit=load(s/(stem+'.output.json'));assert actual['run']['run_id']==x['run']
    if x['mode']=='bounded':
        complete=load(s/('audit-'+x['run']+'-complete.input.json'));missing=[d for d in complete['decisions'] if not d.get('decision_id')]
        assert len(missing)==1 and missing[0]['_line']==278271 and missing[0]['label']=='map/route-change' and not missing[0].get('chosen')
        assert actual['run']==complete['run'] and actual['states']==complete['states'] and actual['decisions']==[d for d in complete['decisions'] if d.get('decision_id')]
        excluded.append(dict(run=x['run'],line=278271,label='map/route-change',original_metadata_retained=True))
        del complete
    actual_counts=dict(segments=len(audit['segments']),actions=len(audit['observed_actions']),turns=len(audit['observed_turns']),full_candidate_results=sum(v['actual_full_candidate_result'] is not None for v in audit['segments']))
    recorded=next(v for v in summaries if v['run']==x['run']);assert all(recorded[k]==v for k,v in actual_counts.items())
    observed=collections.Counter(v['observed_interval']['status'] for v in audit['observed_actions']);assert dict(observed)==recorded['observation_statuses']
    statuses=collections.Counter(v['status'] for v in audit['observed_turns']);assert dict(statuses)==next(v['statuses'] for v in turn_statuses if v['run']==x['run'])
    actual_counts.update(interval_endpoints=observed['observed_endpoints'],turn_endpoints=statuses['observed_turn_endpoints'],turn_unknown=statuses['unknown']);totals.update(actual_counts)
    del actual,audit
assert totals==dict(segments=503,actions=3137,turns=512,full_candidate_results=0,interval_endpoints=1032,turn_endpoints=148,turn_unknown=364)
receipt=load(s/'ledger-readback.json');rows=load(s/'ledger-own-appended-rows.json');inputs=[json.loads(x) for x in (s/'ledger-update.input.jsonl').read_text().splitlines()]
assert receipt['cli_exit_code']==0 and receipt['prefix_unchanged'] and receipt['appended_own_rows']==32 and len(receipt['checks'])==32
assert all(x['prior_where_notes_history_prefix_preserved'] and x['new_links_present'] for x in receipt['checks'])
assert len(rows)==len(inputs)==32 and {x['id'] for x in inputs}==set((s/'ledger-update.stdout.txt').read_text().split());own=[]
prefix=load(s/'ledger-prefix-before.json')
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    frozen=handle.read(prefix['source_size']);assert sha(frozen)==prefix['sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'}
        assert row['op']=='update' and row['by']=='learner:strategy-proposal' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==32 and all(raw.rstrip(b'\n') not in set(old.splitlines()) for raw in own);added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
failure=load(s/'ledger-readback-v1-failure.json');assert failure['status']=='failed_local_material_comparison'
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_gate=b['no_change_proposals'],native=native,original_completion=final,source=source,stream_counts=counts,raw_receipts=receipts,original_rows_verified=6606,original_consumers=consumers,offline_totals=dict(totals),excluded_metadata=excluded,original_material_failure=failure,source_events_first_draft_not_original_snapshot=True,owned_trace_rows=rows,protected_fields_and_prefixes_preserved=True,consumers_not_reexecuted=True,limits=['Four complete and one bounded offline inputs do not certify whole-candidate execution or controlled whole-fight/resource successors.','Original P74 complete-input rejection and all local material-probe failures retained.','Same-run SL attempts are correlated; existing narrow implementations do not close broad proposals.','Historical dirty knowledge inputs and high brain effort are not rewritten; current learner native context independently verified.','No production tests, merge, release, paper refresh, dispatch or game action.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]+[Path(x['path']) for x in originals]
    for sourcefile in sorted(set(files)):
        raw=sourcefile.read_bytes();rel=str(sourcefile.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw)
        archive.add(sourcefile,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0316原025902-s2策略done0/no-source核收，e018基线干净WT/HEAD不变；十项waiting及具体缺口/testsnull/mergednull保持，无合入受阻。五Silent A10八流6606原行逐offset/bytes/SHA/JSON/身份核，十四源码叶12同2历史Roy/Dai注释差与五真实来源祖先核，不以窄实现关闭联合提案。六原离线input/output/stderr SHA核：四完整0、一P74完整1（278271无ID路线元数据）和另存一有界0；503段/3137动作/1032相邻端点/148轮端点/364未知，整候选认证0，不重跑或冒生产/整战验收。32所属CLI只where/note，原offset/SHA及追加前真实前缀SHA核；首次本地浅拷贝污染材料快照导致保护对照失败保留，不用初稿当原字节证据，私有fold旧claim/首证/prior/evidence/status/version和history/notes/where前缀保持，不重复CLI。原power键探针/路径猜测/截断原事件不当产品bug或新机制反证；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核，旧脑high与dirty消费未知保持。仅本人记录/32追溯提交，保并行记录；不合入/发号/补测/刷新论文/复派或关闭宽父。证据paper/materials/20261016-0316-ops/。\n'
note=f'\n- {at} [运维 codex] 原025902-s2十项继续waiting，无源码变更或合入受阻；五局6606原行、四完整/一有界离线读回及32所属追溯已核。P74完整输入拒收和账本材料首次失败保留，未宣称生产测试或整候选通过；不新增发布或补测。回执paper/materials/20261016-0316-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=32,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True)
(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=6606,owned_trace_rows=32,ledger_check=0,paths=len(entries))))

import collections
import hashlib
import json
from pathlib import Path


SCRATCH = Path(__file__).resolve().parent
RUNS = json.loads((SCRATCH / 'dispatch.json').read_text())['runs']


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def identity(row):
    values = [row.get('run_id'), (row.get('state') or {}).get('run_id'), row.get('run')]
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = None
    if isinstance(fp, dict):
        values.append(fp.get('run'))
    ids = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(ids)) if len(ids) == 1 else None


streams = {}
checks = []
for manifest in json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text()):
    stream = manifest['stream']
    path = SCRATCH / 'evidence' / (stream + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
    rows = [json.loads(line) for line in path.open()]
    counts = collections.Counter()
    if rows:
        with Path(rows[0]['source']).open('rb') as original:
            for item in rows:
                original.seek(item['offset'])
                raw = original.read(item['bytes'])
                assert len(raw) == item['bytes'] and raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert identity(item['row']) == item['run_id'] in RUNS
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                counts[item['run_id']] += 1
    assert all(counts[run] == manifest['counts'][run] for run in RUNS)
    streams[stream] = rows
    checks.append({'stream': stream, 'lines': len(rows), 'bytes_identity_sha_verified': True})

by_line = {item['line']: item['row']['state'] for item in streams['states']}


def player(line):
    state = by_line[line]
    return (state.get('combat') or {}).get('player') or {}


def hp(line):
    return player(line).get('current_hp', by_line[line]['run']['current_hp'])


def enemies(line):
    return (by_line[line].get('combat') or {}).get('enemies') or []


def power(entity, key):
    values = [p.get('amount') for p in entity.get('powers', []) if p.get('power_id') == key]
    return values[0] if len(values) == 1 else None


def snapshot(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    p = combat.get('player') or {}
    run = state.get('run') or {}
    return {'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
            'run': item['run_id'], 'floor': run.get('floor'), 'turn': state.get('turn'),
            'screen': state.get('screen'), 'hp': p.get('current_hp', run.get('current_hp')),
            'block': p.get('block'), 'energy': p.get('energy'), 'powers': p.get('powers'),
            'potions': run.get('potions'),
            'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'resolved_rules_text']}
                     for c in combat.get('hand', [])],
            'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'powers', 'intents']}
                        for e in combat.get('enemies', [])],
            'selection': state.get('selection')}


windows = {'NHA2KW0RB7VP': [24, 25, 27, 28, 30, 32, 33],
           'P74C04AEPL1F': [17, 22, 23], 'G33HU22H2543': [31, 32, 33, 47, 48],
           'RC61MFQM63Y6': [17, 24, 27, 29, 32, 33], 'BTSRF7JL1W1Y': [17, 30, 31]}
save('window-facts.json', [snapshot(item) for item in streams['states']
                          if item['row']['state']['run']['floor'] in windows[item['run_id']]])

assert hp(283390) == 28 and hp(283391) == 30
assert sum(e['current_hp'] for e in enemies(283390)) == 428
assert sum(e['current_hp'] for e in enemies(283391)) == 408
assert hp(284817) == 1 and player(284817)['block'] == 16
assert len(by_line[284817]['combat']['hand']) == 4
assert 'PRECISE_CUT' not in [c['card_id'] for c in by_line[284818]['combat']['hand']]
assert hp(284821) == 0 and next(e for e in enemies(284821) if e['enemy_id'] == 'BOWLBUG_EGG')['current_hp'] == 2
assert hp(285411) == 45 and hp(286170) == 14
assert player(286172)['block'] == 5 and power(player(286172), 'PLATING_POWER') == 1
assert hp(286174) == 0 and enemies(286174)[0]['current_hp'] == 13
assert power(player(286170), 'DEXTERITY_POWER') is None

metadata = []
inputs = []
run_summary = []
for run_id in RUNS:
    run_items = [r for r in streams['runs'] if r['run_id'] == run_id]
    assert len(run_items) == 1
    run = run_items[0]['row']
    assert run['character'].lower() == 'silent' and run['ascension'] == 10
    decisions = [{**item['row'], '_line': item['line']} for item in streams['decisions'] if item['run_id'] == run_id]
    states = [{**item['row'], '_line': item['line']} for item in streams['states'] if item['run_id'] == run_id]
    complete_path = 'audit-' + run_id + '-complete.input.json'
    save(complete_path, {'run': run, 'decisions': decisions, 'states': states})
    missing = [d for d in decisions if not d.get('decision_id')]
    for d in missing:
        metadata.append({'run': run_id, 'line': d['_line'], 'label': d.get('label'), 'keys': list(d),
                         'has_chosen': bool(d.get('chosen')),
                         'reason': '原决策流无decision_id；保留原行，不认证完整输入'})
        assert not d.get('chosen')
    if missing:
        accepted = [d for d in decisions if d.get('decision_id')]
        bounded_path = 'audit-' + run_id + '-bounded.input.json'
        save(bounded_path, {'run': run, 'decisions': accepted, 'states': states})
        inputs.append({'run': run_id, 'mode': 'bounded', 'input': bounded_path})
    else:
        inputs.append({'run': run_id, 'mode': 'complete', 'input': complete_path})
    config = next(r['row'] for r in streams['run-config'] if r['run_id'] == run_id)
    run_summary.append({'run': run_id, 'character': run['character'], 'ascension': run['ascension'],
                        'ended': run['ended'], 'victory': run['victory'], 'floor': run['floor'],
                        'code': config['code'], 'state_lines': len(states), 'decision_lines': len(decisions),
                        'metadata_without_id': len(missing), 'historical_brain': config['brain']})

events = json.loads((SCRATCH / 'proposal-events.json').read_text())
proposal_checks = []
for proposal_id, records in events.items():
    add = next(row for _, row in records if row.get('op') == 'add')
    path = Path(add['proposal'])
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == add['proposal_sha256'] and add['character'] == 'silent'
    proposal_checks.append({'id': proposal_id, 'path': str(path), 'sha256': digest, 'ledger': add['ledger'],
                            'runs': add['runs'], 'summary': add['summary']})

save('audit-inputs.json', inputs)
save('audit-excluded-metadata.json', metadata)
save('run-identities.json', run_summary)
save('proposal-source-checks.json', proposal_checks)
save('evidence-validation.json', {'streams': checks, 'total_lines': sum(v['lines'] for v in checks),
                                 'proposals_sha_verified': len(proposal_checks),
                                 'fixed_material_assertions': 'passed; 仅材料核验，不是生产测试或撤源码验证'})
print(json.dumps({'total_lines': sum(v['lines'] for v in checks), 'runs': len(RUNS),
                  'proposal_sha': len(proposal_checks), 'inputs': inputs,
                  'metadata': metadata}, ensure_ascii=False))

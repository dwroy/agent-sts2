# 策略学习报告：十项原提案均保留waiting

记录时间：2026-10-17 17:46:10 CST。角色silent，batch=20261017-172953-s2-strategy-proposal。

完整base：`2f73fc71786725ddab5562a6c52e957ef79c4236`。初始干净HEAD为`191459a386eea6f91623b5430a97593850774fec`；核本批为普通队列后按任务要求fast-forward main，无冲突。无research_request/implementation_request，普通研究请求与本批身份不匹配，未进入专题。

十份原提案逐SHA核同，31个关联账本及26条本角色经验只作来源/边界核对。本批不添加玩法阈值、经验或代码，不新增CLI proposal id，不修改旧复盘。十项分别的证据、层/回合、账本、反例、旧/新行为、预期、验证与回退见同目录[proposal.md](proposal.md)。

## 证据身份与冻结边界

| 局号 | 进阶 | 本批角色核验 |
|---|---:|---|
| 02HB4L0C3C67 | A10 | SILENT |
| 1913SE84AXQF | A10 | SILENT |
| 4D4J8USKCPAV | A10 | SILENT |
| F4QKG4J1AJJZ | A9 | SILENT |
| JLN5SK17W4FQ | A10 | SILENT |
| K3676LU8B0UH | A1 | SILENT |
| KEN58SH9SLZ6 | A10 | SILENT |
| LS8035TB32P3 | A10 | SILENT |
| NB8KCF6HRGVF | A10 | SILENT |
| NHA2KW0RB7VP | A10 | SILENT |
| Q6M2Y34MWKRE | A10 | SILENT |
| S9UZAK0JP0C0 | A10 | SILENT |
| SADL3CGYTGSR | A7 | SILENT |
| TXZ6RVMQA09D | A10 | SILENT |
| WQZVENQ7DTRP | A10 | SILENT |

派发锚点只填原十局；五个补充局因原提案来源纳入，未扩展到其他队列或其他角色。run-identities.json保留runs.jsonl原行号/offset/长度/SHA及原行。

使用任务指定的learner/extract_evidence.py，共7流、19914个封套：states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、fight-plans0。evidence/evidence-manifest.json保存各流独立source_size、计数、输出SHA；不是共同墙钟事务快照。states/decisions/brain各有2行原文件JSON无效，提取器拒收；其余完整性计数原样保存。fight-plans 0只说明该截点未选到，不断言原日志缺失。

envelope-validation.json对19914个封套全部seek只读原日志，逐offset/bytes/SHA/JSON/显式run身份核同，并逐流核输出SHA与计数；states全部SILENT。首次校验因脚本导入路径错误而未启动，原脚本verify-envelopes.initial.txt与失败说明envelope-validation.initial.log保留；修正导入后exit0，日志envelope-validation.log。这是材料脚本错误，不是产品源码红绿或游戏反证。

## 本批核实与无法推出的结论

evidence-checks.json有76项固定观测断言，exit0；其中42次狡诈动作的槽位/手位/HP/能量/敌血核验均吻合。cunning-preview-checks.json另逐原行核新增升级小刀基础6及现场力量/虚弱算术；opening-and-discard-checks.json核TXZ五个无血瓶开场与实际弃药动作计数。以上都是证据读回，不是生产消费者测试、求解、整战模拟、参数校准或实盘收益验收。

局部反例保留：WQ付4血多沙坑一轮，不能一律以少损血为准；TXZ少损3也少伤9、后轮牌序变，不能认定连战变好；NHA多扣16而多损6，仍未击杀一侧且六试全败；Q6 F2早药候选没有整战实打，不能声称已省12HP或可救整局；1913休息改锻造改变投影条件，不当同条件模型误差。

原提案的未控反事实、完整跨重问执行、恢复后消费者和未知组合仍未知。未复原历史运行配置标dirty的全部字节，当前base/live不当历史运行树；run-config原件完整保留。原105/109局统计与其他未纳入局未重跑、不新增样本、不声称已做全史或样本外量化学习。

## 现有实现与逐项处置

源码审计base=`2f73fc71786725ddab5562a6c52e957ef79c4236`；当时live快照=`6f2a20594536087c3453fa9076c5908cbec40e40`。source-audit.json保存12个现存叶的Git blob、SHA、last_path_commit与live祖先布尔；原候选路径agent/src/sim/rollout-start.ts和agent/src/memory/state.ts两边都不存在，已明确记missing，不算已核源码叶。

source/保留必要源码原字节.txt，无可执行.ts临时副本。source-base-live.patch保存4个叶的全部差异，均为Roy/Dai历史署名注释，未覆盖任何一边；其余8叶字节相同。此快照关系不代替运行中宿主加载或原历史dirty状态。

| 实际源码提交 | 现存窄范围实现 | base/live祖先 |
|---|---|---|
| `6403fdcdadc803a092beb5165a068e22bf51c412` | Model observed Silent Cunning Potion generation and hand capacity | true/true |
| `1698adc96ba434a46942321e0237b70657e625b2` | Complete Silent SL resource comparison audit | true/true |
| `e1a467e18a0dfa8d99046a24ff4c0e1af59278c8` | feat(silent): value resources and simulate continuous A10 bosses | true/true |
| `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8` | Extend observed Silent opening HP combinations | true/true |
| `5c7105ff0294466da8319f2934beda05c6040794` | Model observed ordinary Strangle losses for Silent | true/true |
| `f2c7cc1a7288893bceae0f0b20304a2b1fae5f57` | Replay tested Silent Crusher facing rounding on current live | true/true |
| `75a27fb2c230dc552761b2ad9da4be8a9a35dec3` | Model observed seven-card Precise Cut damage for Silent A10 | true/true |

上表只认证所列窄源码确在真实live历史中，不把其并集拼成全部宽提案完成；本批没有将任何整项登记implemented或duplicate。十项逐项waiting理由见proposal-results.json和report.json，全部保留待新局重派。

## 记录、测试和上线边界

仅经根目录learner/ledger.py update追加31条原账本的where.proposal/note追溯，输入ledger-update-input.jsonl、CLI输出ledger-update.log、原字节与字段保护核验ledger-append-validation.json。没有新增支持/反例/重复证据，不修改原claim/首证/prior/evidence/status/version/effect；原shipped状态保留，未降级成proposed，也未新记shipped。

没有源码改动，未做撤源码失败/恢复通过，未运行生产tsc/vitest或新消费者/模拟，没有新提交、live合入、eval版本或上线双通知。tests固定三个null；材料断言exit0不充作生产测试成功。其他角色行为等价。无需生产回退；后续若实现，按原沙箱验证及实际live流程自测上线，保留原失败与日志。

最终工作树tracked/index干净，HEAD等于完整base；final-validation.json记录核验。31条本批CLI行已按offset/bytes/SHA与输入逐项核同，旧账本前缀SHA保持；26条并行追加保留，未代替其作者的判断。账本CLI check实际exit0，505项、0问题，原输出在ledger-check.log。root账本CLI属于任务明示例外，由原调度器读取report.json逐项处置；本任务不手改learn.json/根研究请求或提案队列，不以报告结束关闭任何量化父要求。

没有新的科学异议或反证需要新增学习通知；已有不确定性已明确保留。最终machine-readable结果为同目录report.json。

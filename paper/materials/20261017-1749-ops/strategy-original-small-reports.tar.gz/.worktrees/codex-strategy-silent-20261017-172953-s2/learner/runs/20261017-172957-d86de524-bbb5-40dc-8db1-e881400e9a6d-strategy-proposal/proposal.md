# 本批十项原策略提案核验与处置

记录时间：2026-10-17 17:46:10 CST。角色silent；batch=20261017-172953-s2-strategy-proposal。

同步后base：`2f73fc71786725ddab5562a6c52e957ef79c4236`。本批无源码/知识修改，无提交、无合入、无新版本。

只消费派发的十个CLI id，不领取其他队列、不给原请求增加重复id、不覆盖原提案或历史复盘。已保存全部十份原文且SHA吻合。每项结论均有来源局/层/回合、原账本、反例与验证边界。

## silent-proposal-08eaa60bcc449852：赢战耗药与真实回复
原来源任务：experience-update；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0019、silent-0020。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md。
原文SHA256：`4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`；本批原字节副本在 original-proposals/silent-proposal-08eaa60bcc449852.md。

证据与边界：KEN58SH9SLZ6 A10：F3 T2攻击、F4 T1稳定、F5 T2速度、F11 T1虚弱/T2攻击、F15 T1发光/技能，原动作核7饮；六赢战净损0/3/0/37/6/0，共46。F12 26/76→53/81、F16 46/81→75/86；SL恢复不能当这两次真实回复。

旧/新行为及预期：现持有价值、饮用条件保持。先以实际槽位消耗、退出HP和下一节点入口传递；零净损不解释成没有用药。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：没有KEN F15不饮用、同入口留药至Boss的完整成对后继。7次饮用和赢战净损只认证资源消耗，不能定新的持药血价。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json 的 KEN_*；potion-actions.json；opening-and-discard-checks.json。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-92920295a648b540：SL首胜与连续通关
原来源任务：postmortem；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0228、silent-0255。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md。
原文SHA256：`f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`；本批原字节副本在 original-proposals/silent-proposal-92920295a648b540.md。

证据与边界：TXZ6RVMQA09D A10 F48第2/3次T6相同指纹，48HP/敌460：原线实际损3、扣36，替线损0、扣27。第3次T10首胜仅4HP；states 281565/281566 F49开场4→0、敌111不变，尚未可操作。decisions 275383—275385标明SL替换及实际动作。

旧/新行为及预期：现F48→F49同样本资源接续及未校准说明保持；不将首胜、低可信0%或少损3认作连战胜利。e1a467e已有窄实现，不重报本批implemented。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺保持后续抽序、生成牌、药栏与选择一致的两战替线。局部少损3同时少伤9，未提供连续通关对照，不能修改SL资格或终局权重。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json 的 TXZ_*；critical-decisions.json；source-audit.json。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-a327449c331efbc1：沙虫全败换线的双边界
原来源任务：postmortem；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0079、silent-0018。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md。
原文SHA256：`e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`；本批原字节副本在 original-proposals/silent-proposal-a327449c331efbc1.md。

证据与边界：WQZVENQ7DTRP A10 F33第2/3次T9相同指纹：26HP/敌184，原线13损/24伤，替线22损/39伤，多付9HP换15伤。第2/末次T7同24伤，原0损/末4损；结算前沙坑4/5。decisions 275894、275960、276139；states 282075/282144及各下一轮端点。

旧/新行为及预期：保留当前探索门槛；比较同时列当轮HP、实际输出、剩毒和沙坑，不把全败模拟当安全等价。已有1698adc资源差额审计不认证完整执行。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺约束抽序、后续动作、毒和沙坑的受控整战后继及独立验证局。9HP/15伤不能拟固定兑换率；付4HP续一轮是禁止一律保血的反例。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json 的 WQ_*；critical-decisions.json；source/silent-sl-resource-comparison 对应源码副本。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-a099e89437e942bb：狡诈生成、手位和保留容量
原来源任务：experience-update；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0030、silent-0257、silent-0258。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md。
原文SHA256：`e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`；本批原字节副本在 original-proposals/silent-proposal-a099e89437e942bb.md。

证据与边界：9个实际饮用支持局覆盖A7/A9/A10，42次狡诈：37次添3、2次添2、3次添0。新增刀均升级、Damage基础6；现场力/弱牌面算术逐次吻合。WQ F33第5次T11的8→10、10→10、10→10；末次5→8、8→10、10→10。第五试实建计划妥当后T9—11十手；三瓶满手分支不推广到其他生成牌。

旧/新行为及预期：6403fdc的modelPotion及turn-solver手位截断已是实际live祖先，支持A7/A9/A10。保留此窄模型和饮用后读回；不以现有子模型代替完整跨重问执行/SL恢复认证。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺计划妥当保留容量、跨抽牌/重问的完整候选派发归属、SL恢复的联合消费者校准；没有穿插用药整战受控胜线，整项不能duplicate。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json cunning_*（42动作及分布）；cunning-preview-checks.json；source-audit.json。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-47910f82a1fdd98f：连战开场血价与SL资源
原来源任务：experience-update；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0018、silent-0019、silent-0020、silent-0021、silent-0025、silent-0079、silent-0198、silent-0228、silent-0255。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md。
原文SHA256：`d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`；本批原字节副本在 original-proposals/silent-proposal-47910f82a1fdd98f.md。

证据与边界：TXZ6RVMQA09D A10 F43/45/46/48/49，无小血瓶，首次新战70→66、52→48、62→58、60→56、4→0均核原帧；末场敌未攻击。WQ同盘9HP换15伤和4HP换沙坑一轮同时保留，不拼接成已知获胜线。

旧/新行为及预期：e1a467e、ebf8c57已有受限开场及同样本接续；只在已观察遗物/药栏组合应用，不对实时T1或SL复原再扣4，不推断小血瓶或复活内部顺序。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺未知回血/复活组合结算、留药/路线/SL完整成对后继及两战生产联合校准；已有受限开场公式不代表整项资源策略已完成。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：opening-and-discard-checks.json（五个开场）；evidence-checks.json TXZ_*/WQ_*；source-audit.json。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-f1374df72d8e6a25：胜战退出资源和药水价值
原来源任务：postmortem；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0019、silent-0020、silent-0050、silent-0253。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md。
原文SHA256：`df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`；本批原字节副本在 original-proposals/silent-proposal-f1374df72d8e6a25.md。

证据与边界：Q6M2Y34MWKRE A10 F2 56→44、F3付8至36、F7回21至57、F8赢后2HP、F9死亡；F8 T1速度建5临时敏捷，T2撤，T7仍须付活力/易伤后的威胁。1913SE84AXQF A10 F17 58→14，F19 58→44、F24锻造40→40、F28回21、F29 61→46、F31入口46后死亡。

旧/新行为及预期：用实际退出HP、已用药与下一战入口核连续资源；临时敏捷不跨轮估值。保留现持药价格、终局权重和护栏；Q6 F2早饮候选未实打，不记为获得12HP。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺隔离机制误差后，同入口、同预算的不用/早用/留药整战及下一战成对结果。不能从0.29信心答选或局部候选标价反推新权重。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json 两局_resource_*；critical-states.json；原提案保留Q6 F2候选反例和限制。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-38a49e6c97f31eea：紧勒与增益分源
原来源任务：experience-update；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0006、silent-0011、silent-0025、silent-0044、silent-0050、silent-0064、silent-0133、silent-0253、silent-0259、silent-0261、silent-0262。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md。
原文SHA256：`6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`；本批原字节副本在 original-proposals/silent-proposal-38a49e6c97f31eea.md。

证据与边界：Q6M2Y34MWKRE A10 F8 T4敌HP103→95→85→85→83→80：紧勒8、随后一拳8+2、弃牌完成后2、毒3分源；states 282887—282892。1913SE84AXQF A10 F31 T2弃磨蚀能量3→3，实建1敏/4荆棘（282767/282768）；T3双防御12仍损5，T4从20HP死亡，不能提前拿反伤抵消已发生攻击。

旧/新行为及预期：5c7105f普通紧勒无挡已观察子式已在live；保留其普通/进阶/模板限制。已有速度、再生模型不重报新规则，能力持有、弃牌自动触发与实建分账。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺弃磨蚀、临时/常驻增益、再生/自动触发、SL恢复的联合消费者与受控整战后继。已观察普通紧勒和新升级子式不替代原提案全部机制。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json Q6_STRANGLE_HP_chain、1913_discard_ABRASIVE；critical-states.json；source-audit.json。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-ef0e38a5dbd3bc07：路线、休息与连续资源
原来源任务：experience-update；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0019、silent-0020、silent-0021。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md。
原文SHA256：`d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`；本批原字节副本在 original-proposals/silent-proposal-ef0e38a5dbd3bc07.md。

证据与边界：1913SE84AXQF A10 F24实际锻造不回血、F28实回21至61、F29胜后46、F31死亡，未来F32未兑现；Q6M2Y34MWKRE A10 F3事件付8、F7实回21、F8胜损55、F9只2HP进战后死。胜战资源消耗不能因胜利漏掉。

旧/新行为及预期：路线投影按实际发生的选择重算，锻造、休息、事件、战内回复、幕间和SL分账；现路线/终局权重不变。不得预支未来营火或未取得的能力。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺另一营火动作、事件/路线、用药时点的受控完整结果。两条观察性失败链有构筑/敌人/选择混杂，不能校准路线或终局权重。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json 两局_resource_*；state-summary.json；原提案记录的投影与条件变化，不冒称同条件预测误差。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-7f820c02d39bfaea：饱和SL换线与完整执行归属
原来源任务：postmortem；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0079。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md。
原文SHA256：`bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`；本批原字节副本在 original-proposals/silent-proposal-7f820c02d39bfaea.md。

证据与边界：NHA2KW0RB7VP A10 F33 T1第一试原线14挡/实损1/跨轮净扣8；第五、六试8挡/实损7/跨轮净扣24，均未击杀一侧，包含轮初自动群伤须另账。decisions 277248/277250、277272/277274明确跨弃牌重问与重放；计划中的精确切击被弃掉，不把第一题全步骤当已完成。

旧/新行为及预期：保留当前B2/rollout探索门槛。1698adc已提供当前轮预测差额及execution=unverified，完整候选实际执行仍须按重问与真实动作核验；不把诊断字段当阈值修订。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；一局六败不是六个独立验证局，不能据6HP/16伤设置新血价门槛。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json NHA_T1_*；critical-decisions.json；agent/src/reflex/silent-sl-resource-comparison.ts 的已存源码。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## silent-proposal-04b6b430759815ed：油灯、朝向、手数与能力兑现
原来源任务：experience-update；实现任务：strategy-proposal；本批：20261017-172953-s2-strategy-proposal。
原账本：silent-0005、silent-0006、silent-0021、silent-0011、silent-0065、silent-0264、silent-0079、silent-0133、silent-0169、silent-0189、silent-0013、silent-0053、silent-0162、silent-0265。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md。
原文SHA256：`188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`；本批原字节副本在 original-proposals/silent-proposal-04b6b430759815ed.md。

证据与边界：NHA2KW0RB7VP A10 F17 T1毒牌面5实建10，精确切击七/六/五手预览1/3/5；F33 T2同负2力/1弱，碾碎爪显示1→2、火箭30→20。普通X1萎靡六试实−2力/2弱；油灯原始遗物快照只有描述、stack=null，无本次首次使用状态字段。补充K367 A1、SADL A7只保留其原提案证据边界。

旧/新行为及预期：f2c7cc1蟹朝向受限取整、75a27fb七手精确切击为live祖先。保持已观察子式；油灯仅按已证首次窗口，不持续翻倍，不凭持有遗物推跨动作消费状态。 本批没有上线新行为，不宣称实际通关收益。

反例、缺数据与处置：缺油灯首次消费跨动作、新战/SL恢复的联合输入/消费者，以及未覆盖X值、升级/叠层和能力完整后继。现蟹取整、普通精确切击不能拼成整项duplicate。 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。

验证材料：evidence-checks.json NHA_lamp_first_poison、NHA_crab_facing_display、NHA_precise_cut_previews；source-audit.json。

拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。

后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。

## 共同限制

本批派发十局是调度锚点，不代表原提案的全部来源。额外五局只因原提案明确引用而核本角色身份：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。A1/A7/A9与A10分列，其他角色知识未使用。原提案的105/109局历史汇总本批未重算，不将其当本批新增样本或全历史校准。

本次未产生新的科学反证或与既有知识冲突的规则，也未将任何尚未确定项写成已验证规则。已有宽缺口保留。所有证据读回只认证其窗口；未记录完整反事实不等于整个历史从未存在该线。

import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
date = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(date)

DETAILS = [
    ('08eaa60bcc449852', '赢战耗药与真实回复',
     'KEN58SH9SLZ6 A10：F3 T2攻击、F4 T1稳定、F5 T2速度、F11 T1虚弱/T2攻击、F15 T1发光/技能，原动作核7饮；六赢战净损0/3/0/37/6/0，共46。F12 26/76→53/81、F16 46/81→75/86；SL恢复不能当这两次真实回复。',
     '现持有价值、饮用条件保持。先以实际槽位消耗、退出HP和下一节点入口传递；零净损不解释成没有用药。',
     '没有KEN F15不饮用、同入口留药至Boss的完整成对后继。7次饮用和赢战净损只认证资源消耗，不能定新的持药血价。',
     'evidence-checks.json 的 KEN_*；potion-actions.json；opening-and-discard-checks.json。'),
    ('92920295a648b540', 'SL首胜与连续通关',
     'TXZ6RVMQA09D A10 F48第2/3次T6相同指纹，48HP/敌460：原线实际损3、扣36，替线损0、扣27。第3次T10首胜仅4HP；states 281565/281566 F49开场4→0、敌111不变，尚未可操作。decisions 275383—275385标明SL替换及实际动作。',
     '现F48→F49同样本资源接续及未校准说明保持；不将首胜、低可信0%或少损3认作连战胜利。e1a467e已有窄实现，不重报本批implemented。',
     '缺保持后续抽序、生成牌、药栏与选择一致的两战替线。局部少损3同时少伤9，未提供连续通关对照，不能修改SL资格或终局权重。',
     'evidence-checks.json 的 TXZ_*；critical-decisions.json；source-audit.json。'),
    ('a327449c331efbc1', '沙虫全败换线的双边界',
     'WQZVENQ7DTRP A10 F33第2/3次T9相同指纹：26HP/敌184，原线13损/24伤，替线22损/39伤，多付9HP换15伤。第2/末次T7同24伤，原0损/末4损；结算前沙坑4/5。decisions 275894、275960、276139；states 282075/282144及各下一轮端点。',
     '保留当前探索门槛；比较同时列当轮HP、实际输出、剩毒和沙坑，不把全败模拟当安全等价。已有1698adc资源差额审计不认证完整执行。',
     '缺约束抽序、后续动作、毒和沙坑的受控整战后继及独立验证局。9HP/15伤不能拟固定兑换率；付4HP续一轮是禁止一律保血的反例。',
     'evidence-checks.json 的 WQ_*；critical-decisions.json；source/silent-sl-resource-comparison 对应源码副本。'),
    ('a099e89437e942bb', '狡诈生成、手位和保留容量',
     '9个实际饮用支持局覆盖A7/A9/A10，42次狡诈：37次添3、2次添2、3次添0。新增刀均升级、Damage基础6；现场力/弱牌面算术逐次吻合。WQ F33第5次T11的8→10、10→10、10→10；末次5→8、8→10、10→10。第五试实建计划妥当后T9—11十手；三瓶满手分支不推广到其他生成牌。',
     '6403fdc的modelPotion及turn-solver手位截断已是实际live祖先，支持A7/A9/A10。保留此窄模型和饮用后读回；不以现有子模型代替完整跨重问执行/SL恢复认证。',
     '缺计划妥当保留容量、跨抽牌/重问的完整候选派发归属、SL恢复的联合消费者校准；没有穿插用药整战受控胜线，整项不能duplicate。',
     'evidence-checks.json cunning_*（42动作及分布）；cunning-preview-checks.json；source-audit.json。'),
    ('47910f82a1fdd98f', '连战开场血价与SL资源',
     'TXZ6RVMQA09D A10 F43/45/46/48/49，无小血瓶，首次新战70→66、52→48、62→58、60→56、4→0均核原帧；末场敌未攻击。WQ同盘9HP换15伤和4HP换沙坑一轮同时保留，不拼接成已知获胜线。',
     'e1a467e、ebf8c57已有受限开场及同样本接续；只在已观察遗物/药栏组合应用，不对实时T1或SL复原再扣4，不推断小血瓶或复活内部顺序。',
     '缺未知回血/复活组合结算、留药/路线/SL完整成对后继及两战生产联合校准；已有受限开场公式不代表整项资源策略已完成。',
     'opening-and-discard-checks.json（五个开场）；evidence-checks.json TXZ_*/WQ_*；source-audit.json。'),
    ('f1374df72d8e6a25', '胜战退出资源和药水价值',
     'Q6M2Y34MWKRE A10 F2 56→44、F3付8至36、F7回21至57、F8赢后2HP、F9死亡；F8 T1速度建5临时敏捷，T2撤，T7仍须付活力/易伤后的威胁。1913SE84AXQF A10 F17 58→14，F19 58→44、F24锻造40→40、F28回21、F29 61→46、F31入口46后死亡。',
     '用实际退出HP、已用药与下一战入口核连续资源；临时敏捷不跨轮估值。保留现持药价格、终局权重和护栏；Q6 F2早饮候选未实打，不记为获得12HP。',
     '缺隔离机制误差后，同入口、同预算的不用/早用/留药整战及下一战成对结果。不能从0.29信心答选或局部候选标价反推新权重。',
     'evidence-checks.json 两局_resource_*；critical-states.json；原提案保留Q6 F2候选反例和限制。'),
    ('38a49e6c97f31eea', '紧勒与增益分源',
     'Q6M2Y34MWKRE A10 F8 T4敌HP103→95→85→85→83→80：紧勒8、随后一拳8+2、弃牌完成后2、毒3分源；states 282887—282892。1913SE84AXQF A10 F31 T2弃磨蚀能量3→3，实建1敏/4荆棘（282767/282768）；T3双防御12仍损5，T4从20HP死亡，不能提前拿反伤抵消已发生攻击。',
     '5c7105f普通紧勒无挡已观察子式已在live；保留其普通/进阶/模板限制。已有速度、再生模型不重报新规则，能力持有、弃牌自动触发与实建分账。',
     '缺弃磨蚀、临时/常驻增益、再生/自动触发、SL恢复的联合消费者与受控整战后继。已观察普通紧勒和新升级子式不替代原提案全部机制。',
     'evidence-checks.json Q6_STRANGLE_HP_chain、1913_discard_ABRASIVE；critical-states.json；source-audit.json。'),
    ('ef0e38a5dbd3bc07', '路线、休息与连续资源',
     '1913SE84AXQF A10 F24实际锻造不回血、F28实回21至61、F29胜后46、F31死亡，未来F32未兑现；Q6M2Y34MWKRE A10 F3事件付8、F7实回21、F8胜损55、F9只2HP进战后死。胜战资源消耗不能因胜利漏掉。',
     '路线投影按实际发生的选择重算，锻造、休息、事件、战内回复、幕间和SL分账；现路线/终局权重不变。不得预支未来营火或未取得的能力。',
     '缺另一营火动作、事件/路线、用药时点的受控完整结果。两条观察性失败链有构筑/敌人/选择混杂，不能校准路线或终局权重。',
     'evidence-checks.json 两局_resource_*；state-summary.json；原提案记录的投影与条件变化，不冒称同条件预测误差。'),
    ('7f820c02d39bfaea', '饱和SL换线与完整执行归属',
     'NHA2KW0RB7VP A10 F33 T1第一试原线14挡/实损1/跨轮净扣8；第五、六试8挡/实损7/跨轮净扣24，均未击杀一侧，包含轮初自动群伤须另账。decisions 277248/277250、277272/277274明确跨弃牌重问与重放；计划中的精确切击被弃掉，不把第一题全步骤当已完成。',
     '保留当前B2/rollout探索门槛。1698adc已提供当前轮预测差额及execution=unverified，完整候选实际执行仍须按重问与真实动作核验；不把诊断字段当阈值修订。',
     '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；一局六败不是六个独立验证局，不能据6HP/16伤设置新血价门槛。',
     'evidence-checks.json NHA_T1_*；critical-decisions.json；agent/src/reflex/silent-sl-resource-comparison.ts 的已存源码。'),
    ('04b6b430759815ed', '油灯、朝向、手数与能力兑现',
     'NHA2KW0RB7VP A10 F17 T1毒牌面5实建10，精确切击七/六/五手预览1/3/5；F33 T2同负2力/1弱，碾碎爪显示1→2、火箭30→20。普通X1萎靡六试实−2力/2弱；油灯原始遗物快照只有描述、stack=null，无本次首次使用状态字段。补充K367 A1、SADL A7只保留其原提案证据边界。',
     'f2c7cc1蟹朝向受限取整、75a27fb七手精确切击为live祖先。保持已观察子式；油灯仅按已证首次窗口，不持续翻倍，不凭持有遗物推跨动作消费状态。',
     '缺油灯首次消费跨动作、新战/SL恢复的联合输入/消费者，以及未覆盖X值、升级/叠层和能力完整后继。现蟹取整、普通精确切击不能拼成整项duplicate。',
     'evidence-checks.json NHA_lamp_first_poison、NHA_crab_facing_display、NHA_precise_cut_previews；source-audit.json。'),
]

results = []
sections = []
for suffix, title, evidence, behavior, missing, validation in DETAILS:
    ident = 'silent-proposal-' + suffix
    original = dispatch['proposals'][ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': missing})
    sections.append('\n'.join([
        f'## {ident}：{title}',
        f'原来源任务：{original["source_task"]}；实现任务：strategy-proposal；本批：{dispatch["batch"]}。',
        '原账本：' + '、'.join(original['ledger']) + '。原提案：' + original['proposal'] + '。',
        f'原文SHA256：`{original["proposal_sha256"]}`；本批原字节副本在 original-proposals/{ident}.md。',
        '\n证据与边界：' + evidence,
        '\n旧/新行为及预期：' + behavior + ' 本批没有上线新行为，不宣称实际通关收益。',
        '\n反例、缺数据与处置：' + missing + ' 处置为 waiting，保持待新局重派；未将窄子项登记为整个原请求的duplicate。',
        '\n验证材料：' + validation,
        '\n拟合/时间切分：本批只核既有本角色观测，不新增参数。SL尝试按原局分组；如后续拟合，用较早独立局训练、开始时间后移的新局验证，不随机拆同战帧或SL样本。',
        '\n后续验收与回退：取得上述缺数据后，先用固定局面和原消费者验证，再决定是否修改对应角色已观察分支。实际源码修改需撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；单项回退保留刷新知识、原日志、失败与台账。Roy-2026-10-07-learning只授权基于证据的规则修改，不提供游戏事实。',
    ]))

proposal = '\n\n'.join([
    '# 本批十项原策略提案核验与处置',
    f'记录时间：{date}。角色silent；batch={dispatch["batch"]}。',
    f'同步后base：`{dispatch["base"]}`。本批无源码/知识修改，无提交、无合入、无新版本。',
    '只消费派发的十个CLI id，不领取其他队列、不给原请求增加重复id、不覆盖原提案或历史复盘。已保存全部十份原文且SHA吻合。每项结论均有来源局/层/回合、原账本、反例与验证边界。',
    *sections,
    '## 共同限制',
    '本批派发十局是调度锚点，不代表原提案的全部来源。额外五局只因原提案明确引用而核本角色身份：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。A1/A7/A9与A10分列，其他角色知识未使用。原提案的105/109局历史汇总本批未重算，不将其当本批新增样本或全历史校准。',
    '本次未产生新的科学反证或与既有知识冲突的规则，也未将任何尚未确定项写成已验证规则。已有宽缺口保留。所有证据读回只认证其窗口；未记录完整反事实不等于整个历史从未存在该线。',
]) + '\n'
(OUT / 'proposal.md').write_text(proposal)
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

updates = []
for ident in sorted({i for p in dispatch['proposals'].values() for i in p['ledger']}):
    related = [p for p, value in dispatch['proposals'].items() if ident in value['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md')]},
                    'note': f'{dispatch["batch"]}：只追加原提案核验追溯，关联' + '、'.join(related) +
                    '；十项均waiting，具体原帧、已上线窄源码祖先与缺数据见本批proposal.md/report.md。没有新增support/repeat/contradict，不改claim、首证、prior、evidence、status、version或effect；不冒称本批源码实现/合入/shipped。'})
(OUT / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates))

report = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'],
    'base': dispatch['base'], 'runs': dispatch['dispatch']['runs'], 'fixes': [],
    'skipped': [],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': list(dispatch['proposals']), 'implementation_domains': [],
    'proposal_results': results, 'report': str(OUT / 'report.md'),
}
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

checks = json.loads((OUT / 'evidence-checks.json').read_text())
validation = json.loads((OUT / 'envelope-validation.json').read_text())
identities = json.loads((OUT / 'run-identities.json').read_text())
table = ['| 局号 | 进阶 | 本批角色核验 |', '|---|---:|---|']
for run, items in sorted(identities.items()):
    table.append(f'| {run} | A{items[0]["row"]["ascension"]} | SILENT |')
commits = ['| 实际源码提交 | 现存窄范围实现 | base/live祖先 |', '|---|---|---|']
for row in source['commits']:
    commits.append(f'| `{row["commit"]}` | {row["subject"]} | {str(row["base_ancestor"]).lower()}/{str(row["live_ancestor"]).lower()} |')
body = '\n\n'.join([
    '# 策略学习报告：十项原提案均保留waiting',
    f'记录时间：{date}。角色silent，batch={dispatch["batch"]}。',
    f'完整base：`{dispatch["base"]}`。初始干净HEAD为`{dispatch["initial_head"]}`；核本批为普通队列后按任务要求fast-forward main，无冲突。无research_request/implementation_request，普通研究请求与本批身份不匹配，未进入专题。',
    '十份原提案逐SHA核同，31个关联账本及26条本角色经验只作来源/边界核对。本批不添加玩法阈值、经验或代码，不新增CLI proposal id，不修改旧复盘。十项分别的证据、层/回合、账本、反例、旧/新行为、预期、验证与回退见同目录[proposal.md](proposal.md)。',
    '## 证据身份与冻结边界',
    '\n'.join(table),
    '派发锚点只填原十局；五个补充局因原提案来源纳入，未扩展到其他队列或其他角色。run-identities.json保留runs.jsonl原行号/offset/长度/SHA及原行。',
    '使用任务指定的learner/extract_evidence.py，共7流、19914个封套：states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、fight-plans0。evidence/evidence-manifest.json保存各流独立source_size、计数、输出SHA；不是共同墙钟事务快照。states/decisions/brain各有2行原文件JSON无效，提取器拒收；其余完整性计数原样保存。fight-plans 0只说明该截点未选到，不断言原日志缺失。',
    'envelope-validation.json对19914个封套全部seek只读原日志，逐offset/bytes/SHA/JSON/显式run身份核同，并逐流核输出SHA与计数；states全部SILENT。首次校验因脚本导入路径错误而未启动，原脚本verify-envelopes.initial.txt与失败说明envelope-validation.initial.log保留；修正导入后exit0，日志envelope-validation.log。这是材料脚本错误，不是产品源码红绿或游戏反证。',
    '## 本批核实与无法推出的结论',
    f'evidence-checks.json有{len(checks["checks"])}项固定观测断言，exit0；其中42次狡诈动作的槽位/手位/HP/能量/敌血核验均吻合。cunning-preview-checks.json另逐原行核新增升级小刀基础6及现场力量/虚弱算术；opening-and-discard-checks.json核TXZ五个无血瓶开场与实际弃药动作计数。以上都是证据读回，不是生产消费者测试、求解、整战模拟、参数校准或实盘收益验收。',
    '局部反例保留：WQ付4血多沙坑一轮，不能一律以少损血为准；TXZ少损3也少伤9、后轮牌序变，不能认定连战变好；NHA多扣16而多损6，仍未击杀一侧且六试全败；Q6 F2早药候选没有整战实打，不能声称已省12HP或可救整局；1913休息改锻造改变投影条件，不当同条件模型误差。',
    '原提案的未控反事实、完整跨重问执行、恢复后消费者和未知组合仍未知。未复原历史运行配置标dirty的全部字节，当前base/live不当历史运行树；run-config原件完整保留。原105/109局统计与其他未纳入局未重跑、不新增样本、不声称已做全史或样本外量化学习。',
    '## 现有实现与逐项处置',
    f'源码审计base=`{source["base"]}`；当时live快照=`{source["live"]}`。source-audit.json保存12个现存叶的Git blob、SHA、last_path_commit与live祖先布尔；原候选路径agent/src/sim/rollout-start.ts和agent/src/memory/state.ts两边都不存在，已明确记missing，不算已核源码叶。',
    'source/保留必要源码原字节.txt，无可执行.ts临时副本。source-base-live.patch保存4个叶的全部差异，均为Roy/Dai历史署名注释，未覆盖任何一边；其余8叶字节相同。此快照关系不代替运行中宿主加载或原历史dirty状态。',
    '\n'.join(commits),
    '上表只认证所列窄源码确在真实live历史中，不把其并集拼成全部宽提案完成；本批没有将任何整项登记implemented或duplicate。十项逐项waiting理由见proposal-results.json和report.json，全部保留待新局重派。',
    '## 记录、测试和上线边界',
    '仅经根目录learner/ledger.py update追加31条原账本的where.proposal/note追溯，输入ledger-update-input.jsonl、CLI输出ledger-update.log、原字节与字段保护核验ledger-append-validation.json。没有新增支持/反例/重复证据，不修改原claim/首证/prior/evidence/status/version/effect；原shipped状态保留，未降级成proposed，也未新记shipped。',
    '没有源码改动，未做撤源码失败/恢复通过，未运行生产tsc/vitest或新消费者/模拟，没有新提交、live合入、eval版本或上线双通知。tests固定三个null；材料断言exit0不充作生产测试成功。其他角色行为等价。无需生产回退；后续若实现，按原沙箱验证及实际live流程自测上线，保留原失败与日志。',
    '工作树tracked/index应保持干净，HEAD等于完整base；final-validation.json记录最终核验。root账本CLI属于任务明示例外，由原调度器读取report.json逐项处置；本任务不手改learn.json/根研究请求或提案队列，不以报告结束关闭任何量化父要求。',
    '没有新的科学异议或反证需要新增学习通知；已有不确定性已明确保留。最终machine-readable结果为同目录report.json。',
]) + '\n'
(OUT / 'report.md').write_text(body)
print(json.dumps({'proposal': str(OUT / 'proposal.md'), 'report': str(OUT / 'report.md'),
                  'results': len(results), 'ledger_trace_updates': len(updates)}, ensure_ascii=False))

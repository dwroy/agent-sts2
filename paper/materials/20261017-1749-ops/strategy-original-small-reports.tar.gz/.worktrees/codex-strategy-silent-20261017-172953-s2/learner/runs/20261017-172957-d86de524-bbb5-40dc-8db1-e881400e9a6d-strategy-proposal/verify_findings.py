import collections
import json
from pathlib import Path

from inspect_evidence import compact

OUT = Path(__file__).resolve().parent
states = collections.defaultdict(list)
by_line = {}
fingerprints = {}
with (OUT / 'evidence/states.evidence.jsonl').open() as handle:
    for raw in handle:
        item = json.loads(raw)
        value = compact(item)
        value['available_actions'] = item['row']['state'].get('available_actions')
        value['in_combat'] = item['row']['state'].get('in_combat')
        value['relic_ids'] = [r['relic_id'] for r in (item['row']['state'].get('run') or {}).get('relics', [])]
        fingerprints[item['line']] = item['row'].get('fingerprint')
        states[item['run_id']].append(value)
        by_line[item['line']] = value

checks = []


def check(name, value, expected, refs):
    assert value == expected, (name, value, expected)
    checks.append({'name': name, 'observed': value, 'expected': expected,
                   'refs': [v['ref'] for v in refs]})


def enemy_total(state):
    return sum(e['hp'] for e in state['enemies'])


def power(state, enemy, key):
    return next(e['powers'].get(key, 0) for e in state['enemies'] if e['id'] == enemy)


def turn(run, floor, attempt, number):
    values = []
    current = 0
    prior = None
    for state in states[run]:
        if state['floor'] != floor:
            continue
        t = state['turn']
        if state['in_combat'] and isinstance(t, int):
            if prior is None or t < prior:
                current += 1
            prior = t
        if current == attempt and t == number:
            values.append(state)
    return values


def ready(run, floor, attempt, number):
    return next(v for v in turn(run, floor, attempt, number) if v['hand'])


def floor_window(run, floor):
    xs = [v for v in states[run] if v['floor'] == floor]
    return xs[0], xs[-1]


for attempt, expected in [(2, [3, 36]), (3, [0, 27])]:
    before = ready('TXZ6RVMQA09D', 48, attempt, 6)
    after = ready('TXZ6RVMQA09D', 48, attempt, 7)
    check('TXZ_T6_attempt_' + str(attempt), [before['hp'] - after['hp'], enemy_total(before) - enemy_total(after)], expected, [before, after])
a = ready('TXZ6RVMQA09D', 48, 2, 6)
b = ready('TXZ6RVMQA09D', 48, 3, 6)
check('TXZ_T6_same_fingerprint', fingerprints[a['ref']['line']] == fingerprints[b['ref']['line']], True, [a, b])
check('TXZ_F49_opening', [by_line[281565]['hp'], by_line[281566]['hp'], enemy_total(by_line[281565]), enemy_total(by_line[281566])], [4, 0, 111, 111], [by_line[281565], by_line[281566]])
check('TXZ_F49_before_play', 'play_card' in by_line[281565]['available_actions'], False, [by_line[281565]])

for attempt, expected in [(2, [13, 24]), (3, [22, 39])]:
    before = ready('WQZVENQ7DTRP', 33, attempt, 9)
    after = ready('WQZVENQ7DTRP', 33, attempt, 10)
    check('WQ_T9_attempt_' + str(attempt), [before['hp'] - after['hp'], enemy_total(before) - enemy_total(after)], expected, [before, after])
a = ready('WQZVENQ7DTRP', 33, 2, 9)
b = ready('WQZVENQ7DTRP', 33, 3, 9)
check('WQ_T9_same_fingerprint', fingerprints[a['ref']['line']] == fingerprints[b['ref']['line']], True, [a, b])
for attempt, expected in [(2, [0, 24, 4]), (6, [4, 24, 5])]:
    before = ready('WQZVENQ7DTRP', 33, attempt, 7)
    after = ready('WQZVENQ7DTRP', 33, attempt, 8)
    end = turn('WQZVENQ7DTRP', 33, attempt, 7)[-1]
    check('WQ_T7_attempt_' + str(attempt), [before['hp'] - after['hp'], enemy_total(before) - enemy_total(after), power(end, 'THE_INSATIABLE', 'SANDPIT_POWER')], expected, [before, end, after])

for attempt, expected in [(1, [1, 8, 14]), (5, [7, 24, 8]), (6, [7, 24, 8])]:
    before = ready('NHA2KW0RB7VP', 33, attempt, 1)
    after = ready('NHA2KW0RB7VP', 33, attempt, 2)
    end = turn('NHA2KW0RB7VP', 33, attempt, 1)[-1]
    check('NHA_T1_attempt_' + str(attempt), [before['hp'] - after['hp'], enemy_total(before) - enemy_total(after), end['block']], expected, [before, end, after])

actions = json.loads((OUT / 'potion-actions.json').read_text())
cunning = []
ken = []
for action in actions:
    if action['chosen'].get('action') != 'use_potion' or not action['before']:
        continue
    b, a = action['before'], action['next_observation']
    slot = action['chosen'].get('option_index')
    potion = next((p['id'] for p in b['potions'] if p['index'] == slot), None)
    if potion == 'CUNNING_POTION':
        added = a['hand'][len(b['hand']):]
        delta = len(a['hand']) - len(b['hand'])
        check('cunning_' + str(action['ref']['line']),
              [delta, all(c['id'] == 'SHIV' and c['upgraded'] and c['values'].get('Damage') is not None for c in added),
               a['hp'] - b['hp'], a['energy'] - b['energy'], enemy_total(a) - enemy_total(b),
               any(p['index'] == slot for p in a['potions'])],
              [min(3, 10 - len(b['hand'])), True, 0, 0, 0, False], [b, a])
        cunning.append({'decision': action['ref'], 'before': b['ref'], 'after': a['ref'],
                        'floor': action['floor'], 'turn': action['turn'], 'before_hand': len(b['hand']), 'added': delta})
    if action['ref']['run_id'] == 'KEN58SH9SLZ6':
        ken.append({'potion': potion, 'decision': action['ref'], 'before': b['ref'], 'after': a['ref'],
                    'floor': action['floor'], 'turn': action['turn']})
check('cunning_42_distribution', dict(collections.Counter(x['added'] for x in cunning)), {3: 37, 2: 2, 0: 3}, [])
check('KEN_seven_drinks', len(ken), 7, [])
ken_losses = []
for floor in [2, 3, 4, 5, 11, 15]:
    b, a = floor_window('KEN58SH9SLZ6', floor)
    ken_losses.append(b['hp'] - a['hp'])
check('KEN_six_won_fight_losses', ken_losses, [0, 3, 0, 37, 6, 0], [v for floor in [2, 3, 4, 5, 11, 15] for v in floor_window('KEN58SH9SLZ6', floor)])
for floor, expected in [(12, [26, 53, 76, 81]), (16, [46, 75, 81, 86])]:
    b, a = floor_window('KEN58SH9SLZ6', floor)
    check('KEN_actual_heal_F' + str(floor), [b['hp'], a['hp'], b['max_hp'], a['max_hp']], expected, [b, a])

for run, floor, expected in [
    ('Q6M2Y34MWKRE', 2, [56, 44]), ('Q6M2Y34MWKRE', 3, [44, 36]),
    ('Q6M2Y34MWKRE', 7, [36, 57]), ('Q6M2Y34MWKRE', 8, [57, 2]),
    ('Q6M2Y34MWKRE', 9, [2, 0]), ('1913SE84AXQF', 17, [58, 14]),
    ('1913SE84AXQF', 19, [58, 44]), ('1913SE84AXQF', 24, [40, 40]),
    ('1913SE84AXQF', 28, [40, 61]), ('1913SE84AXQF', 29, [61, 46]),
    ('1913SE84AXQF', 31, [46, 0]),
]:
    b, a = floor_window(run, floor)
    check(run + '_resource_F' + str(floor), [b['hp'], a['hp']], expected, [b, a])

chain = [by_line[n] for n in [282887, 282888, 282889, 282890, 282891, 282892]]
check('Q6_STRANGLE_HP_chain', [enemy_total(x) for x in chain], [103, 95, 85, 85, 83, 80], chain)
a, b = by_line[282767], by_line[282768]
check('1913_discard_ABRASIVE', [a['energy'], b['energy'], b['powers'].get('DEXTERITY_POWER'), b['powers'].get('THORNS_POWER')], [3, 3, 1, 4], [a, b])
a, b = by_line[283146], by_line[283147]
check('NHA_lamp_first_poison', [power(a, 'CEREMONIAL_BEAST', 'POISON_POWER'), power(b, 'CEREMONIAL_BEAST', 'POISON_POWER')], [0, 10], [a, b])
a, b = by_line[283397], by_line[283399]
check('NHA_crab_facing_display', [[i['total_damage'] for e in x['enemies'] for i in e['intents']] for x in [a, b]], [[1, 30], [2, 20]], [a, b])
chain = [by_line[n] for n in [283142, 283143, 283144]]
check('NHA_precise_cut_previews', [next(c['values']['CalculatedDamage'] for c in x['hand'] if c['id'] == 'PRECISE_CUT') for x in chain], [1, 3, 5], chain)

(OUT / 'evidence-checks.json').write_text(json.dumps({'exit_code': 0, 'checks': checks, 'cunning_actions': cunning, 'ken_drinks': ken}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'cunning_actions': len(cunning), 'ken_drinks': len(ken),
                  'scope': 'observed evidence only; no production solver, simulation, threshold calibration or counterfactual execution'}, ensure_ascii=False))

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

out = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extractor', out.parents[1] / 'extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
reports = []
for entry in json.loads((out / 'evidence/evidence-manifest.json').read_text()):
    path = out / 'evidence' / (entry['stream'] + '.evidence.jsonl')
    source = Path('/home/dw/Projects/agent-sts2/logs') / (entry['stream'] + '.jsonl')
    digest = hashlib.sha256()
    counts = collections.Counter()
    with path.open('rb') as handle, source.open('rb') as original:
        for raw in handle:
            digest.update(raw)
            item = json.loads(raw)
            assert item['source'] == str(source)
            assert item['offset'] + item['bytes'] <= entry['source_size']
            original.seek(item['offset'])
            actual = original.read(item['bytes'])
            assert actual.endswith(b'\n')
            assert hashlib.sha256(actual).hexdigest() == item['sha256']
            assert json.loads(actual) == item['row']
            assert module.run_identity(item['row']) == item['run_id']
            if entry['stream'] == 'states':
                assert item['row']['state']['run']['character_id'].lower() == 'silent'
            counts[item['run_id']] += 1
    assert digest.hexdigest() == entry['output_sha256']
    assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
    reports.append({'stream': entry['stream'], 'source_size': entry['source_size'],
                    'verified_rows': sum(counts.values()), 'output_sha256': digest.hexdigest(),
                    'counts': entry['counts'], 'invalid_lines_in_source': entry['invalid_lines'],
                    'incomplete_lines_in_source': entry['incomplete_lines']})
(out / 'envelope-validation.json').write_text(json.dumps({'exit_code': 0, 'streams': reports}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in reports), 'streams': len(reports)}, ensure_ascii=False))

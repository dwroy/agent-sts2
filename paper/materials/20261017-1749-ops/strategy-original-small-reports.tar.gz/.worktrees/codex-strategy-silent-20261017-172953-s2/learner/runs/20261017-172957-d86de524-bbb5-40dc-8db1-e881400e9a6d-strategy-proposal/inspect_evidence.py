import bisect
import collections
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent


def reference(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def powers(items):
    return {p['power_id']: p.get('amount') for p in items or []}


def compact(item):
    row = item['row']
    s = row['state']
    run = s.get('run') or {}
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {
        'ref': reference(item), 'ts': row['ts'], 'attempt': item.get('attempt'),
        'floor': run.get('floor'), 'turn': s.get('turn'), 'screen': s.get('screen'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'energy': p.get('energy'), 'block': p.get('block'), 'powers': powers(p.get('powers')),
        'hand': [{'id': x.get('card_id'), 'index': x.get('index'), 'upgraded': x.get('upgraded'),
                  'values': {v.get('name'): v.get('current_value') for v in x.get('dynamic_values', [])}}
                 for x in c.get('hand', [])],
        'potions': [{'index': x.get('index'), 'id': x.get('potion_id')} for x in run.get('potions', []) if x.get('occupied')],
        'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                    for e in c.get('enemies', [])],
    }


def main():
    states = collections.defaultdict(list)
    last_turn, attempts = {}, collections.defaultdict(int)
    with (OUT / 'evidence/states.evidence.jsonl').open() as handle:
        for line in handle:
            x = json.loads(line)
            s = x['row']['state']
            r = s.get('run') or {}
            assert r.get('character_id', '').lower() == 'silent'
            key = (x['run_id'], r.get('floor'))
            turn = s.get('turn')
            if s.get('in_combat') and isinstance(turn, int):
                if key not in last_turn or turn < last_turn[key]:
                    attempts[key] += 1
                last_turn[key] = turn
            x['attempt'] = attempts[key]
            states[x['run_id']].append(x)
    decisions = collections.defaultdict(list)
    with (OUT / 'evidence/decisions.evidence.jsonl').open() as handle:
        for line in handle:
            x = json.loads(line)
            decisions[x['run_id']].append(x)
    summary = {}
    for run, values in states.items():
        first_by_floor = {}
        last_by_floor = {}
        for x in values:
            s = x['row']['state']
            floor = (s.get('run') or {}).get('floor')
            if s.get('in_combat'):
                first_by_floor.setdefault(floor, x)
                last_by_floor[floor] = x
        summary[run] = {
            'states': len(values), 'decisions': len(decisions[run]),
            'ascension': values[0]['row']['state']['run'].get('ascension'),
            'combat_floors': [{'floor': f, 'attempts': attempts[(run, f)],
                               'first': compact(x), 'last_combat': compact(last_by_floor[f])}
                              for f, x in first_by_floor.items()],
        }
    (OUT / 'state-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    windows = {
        'TXZ6RVMQA09D': {48: {6, 10}, 49: {1}},
        'WQZVENQ7DTRP': {33: {7, 9, 11}},
        'NHA2KW0RB7VP': {33: {1, 2, 4}, 17: {1}},
        'Q6M2Y34MWKRE': {2: {1, 3}, 8: {1, 2, 4, 5, 6, 7, 8}, 9: {1, 2}},
        '1913SE84AXQF': {17: {1, 2, 3, 4, 5, 6}, 31: {2, 3, 4}},
    }
    selected = []
    for run, floors in windows.items():
        for x in states[run]:
            s = x['row']['state']
            floor = (s.get('run') or {}).get('floor')
            if floor in floors and s.get('turn') in floors[floor]:
                selected.append(compact(x))
    (OUT / 'critical-states.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
    drinks = []
    important_decisions = []
    for run, values in decisions.items():
        ss = states[run]
        times = [x['row']['ts'] for x in ss]
        fp_index = collections.defaultdict(list)
        for n, x in enumerate(ss):
            fp_index[x['row'].get('fingerprint')].append(n)
        for x in values:
            r = x['row']
            if 'potion' in str(r.get('chosen', {})).lower() or 'potion' in str(r.get('label')):
                indices = fp_index.get(r.get('fingerprint'), [])
                valid = [i for i in indices if times[i] <= r['ts']]
                i = valid[-1] if valid else None
                drinks.append({'ref': reference(x), 'ts': r['ts'], 'floor': r.get('floor'), 'turn': r.get('turn'),
                               'label': r.get('label'), 'chosen': r.get('chosen'), 'result': r.get('result'),
                               'before': compact(ss[i]) if i is not None else None,
                               'next_observation': compact(ss[i + 1]) if i is not None and i + 1 < len(ss) else None})
            if x['line'] in {275383, 275384, 275385, 275894, 275960, 276139, 277248, 277250, 277272, 277274}:
                important_decisions.append(x)
    (OUT / 'potion-actions.json').write_text(json.dumps(drinks, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'critical-decisions.json').write_text(json.dumps(important_decisions, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({r: {'states': x['states'], 'decisions': x['decisions'], 'asc': x['ascension']}
                      for r, x in summary.items()}, ensure_ascii=False))
    print('potion_action_candidates', len(drinks), 'critical_decisions', len(important_decisions))


if __name__ == '__main__':
    main()

import pathlib,json,hashlib,re,datetime,collections
p=pathlib.Path(__file__).parent;root=p.parents[2]
report={};total=0
for file in sorted(p.glob('*-selected.jsonl')):
 name=file.name.removesuffix('-selected.jsonl');src=root/'logs'/f'{name}.jsonl'
 if name=='deepseek-window':continue
 checked=0
 with src.open('rb') as h:
  for raw in file.open():
   x=json.loads(raw);h.seek(x['offset']);data=h.read(x['bytes'])
   assert hashlib.sha256(data).hexdigest()==x['sha256'],(name,x['line'])
   assert json.loads(data)==x['row'],(name,x['line'])
   checked+=1
 report[name]=checked;total+=checked
s={x['line']:x['row']['state'] for x in map(json.loads,(p/'states-selected.jsonl').open())}
d={x['line']:x['row'] for x in map(json.loads,(p/'decisions-selected.jsonl').open())}
res=json.loads((p/'DGLWTQGRAT1T-resources.json').read_text())
assert [c['entry']['hp'] for c in res['combats']]==[56,54,48,48,43,59,59,53,59,47,44,6,6,6,6]
assert [c['exit']['hp'] if c['exit'] else None for c in res['combats']]==[54,48,48,43,17,59,32,18,47,44,6,None,None,None,0]
assert all(c['entry']['max_hp']==70 and c['entry_is_turn_one'] for c in res['combats'])
assert s[445291]['run']['current_hp']==6 and s[445291]['combat']['player']['block']==15
assert s[445291]['combat']['enemies'][0]['intents'][0]['damage']==23
assert s[445292]['run']['current_hp']==0 and s[445292]['combat']['enemies'][0]['current_hp']==104
assert [s[n]['combat']['player']['block'] for n in [445257,445258,445279,445280,445290,445291]]==[7,10,10,15,10,15]
assert s[445230]['run']['current_hp']==15 and s[445235]['run']['current_hp']==6
assert s[445233]['combat']['player']['block']==s[445234]['combat']['player']['block']==10
assert any(c['card_id']=='SUCKER_PUNCH' for c in s[445234]['combat']['hand'])
a=d[430498]['selection_audit']['after_sl']['turn'];assert a['block_gained']==15 and a['hp_loss']==4 and a['damage']==23
assert d[430555]['chosen']['action']=='confirm_selection'
assert len(s[444996]['combat']['hand'])==5 and len(s[444997]['combat']['hand'])==10
jev=[r for r in d.values() if r['decider']=='jev'];combat=[r for r in jev if r['label'].startswith('combat/')]
assert len(jev)==76 and len(combat)==67 and sum(r['rollout_best_chosen'] for r in combat)==66
assert sum(r.get('confidence',1)<.35 for r in jev)==4
for c in res['combats']:
 for e in [c['entry'],c['last'],c['exit']]:
  if e:
   st=s[e['line']];assert e['hp']==st['run']['current_hp'] and e['max_hp']==st['run']['max_hp']
report.update(total_rows_verified=total,resource_windows=15,key_assertions='通过',draft_sha256=hashlib.sha256((p/'lesson-draft.md').read_bytes()).hexdigest())
(p/'evidence-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))

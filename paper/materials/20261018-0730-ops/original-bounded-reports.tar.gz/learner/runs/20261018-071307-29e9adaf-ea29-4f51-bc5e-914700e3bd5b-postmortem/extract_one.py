import json, subprocess, pathlib, hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261018-071307-29e9adaf-ea29-4f51-bc5e-914700e3bd5b-postmortem'
run='DGLWTQGRAT1T'
streams=['runs','decisions','states','run-plans','sl-attempts','run-config','combat-metrics','fight-plans']
manifest={}
for name in streams:
    path=root/'logs'/f'{name}.jsonl'
    if not path.exists(): continue
    count=0
    proc=subprocess.Popen(['rg','-n','-b','-F',run,str(path)],stdout=subprocess.PIPE)
    with (out/f'{name}-selected.jsonl').open('w') as dst:
        for raw in proc.stdout:
            lineno,offset,data=raw.split(b':',2)
            try: row=json.loads(data)
            except ValueError: continue
            if row.get('run_id',row.get('run')) != run and (row.get('state') or {}).get('run_id') != run: continue
            dst.write(json.dumps({'line':int(lineno),'offset':int(offset),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'row':row},ensure_ascii=False)+'\n')
            count+=1
    rc=proc.wait()
    assert rc in [0,1], (name,rc)
    manifest[name]={'rows':count,'source_bytes_at_read':path.stat().st_size}
(out/'extraction-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False))

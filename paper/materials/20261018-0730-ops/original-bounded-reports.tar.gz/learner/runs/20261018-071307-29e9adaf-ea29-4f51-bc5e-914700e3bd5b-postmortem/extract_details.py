import json,pathlib,subprocess,hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2');p=pathlib.Path(__file__).parent;run='DGLWTQGRAT1T'
name='brain';path=root/'logs'/f'{name}.jsonl';count=0
proc=subprocess.Popen(['rg','-n','-b','-F',run,str(path)],stdout=subprocess.PIPE)
with (p/f'{name}-selected.jsonl').open('w') as o:
 for raw in proc.stdout:
  n,off,data=raw.split(b':',2);r=json.loads(data)
  if r.get('run_id',r.get('run'))!=run:continue
  o.write(json.dumps({'line':int(n),'offset':int(off),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'row':r},ensure_ascii=False)+'\n');count+=1
assert proc.wait() in [0,1]
print('brain选出',count)
# Freeze only cited source leaves, not a checkout.
live=root/'.worktrees/live';head=subprocess.check_output(['git','-C',str(live),'rev-parse','HEAD'],text=True).strip();m={'head':head,'run_start_commit':'0bfadd7aa3dd650ac9a1678d139607e6f095b224','files':{}}
for file in ['agent/src/hand/screens/selection.ts','agent/src/reflex/card-model.ts','agent/src/reflex/turn-solver.ts','agent/src/reflex/combat-plan.ts']:
 data=(live/file).read_bytes();dest=p/('source-'+pathlib.Path(file).name);dest.write_bytes(data)
 m['files'][file]={'snapshot':str(dest),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':subprocess.check_output(['git','-C',str(live),'rev-parse',head+':'+file],text=True).strip()}
 diff=subprocess.check_output(['git','-C',str(live),'diff','--binary',m['run_start_commit'],head,'--',file]);(p/('source-diff-'+pathlib.Path(file).name+'.patch')).write_bytes(diff)
(p/'source-pins.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
# Time-window query on the untagged reasoning stream; preserve zero matches.
reason=root/'logs/deepseek-reasoning.jsonl';matches=0
proc=subprocess.Popen(['rg','-n','-b','-e','2026-10-17T22:','-e','2026-10-17T23:',str(reason)],stdout=subprocess.PIPE)
with (p/'deepseek-window-selected.jsonl').open('w') as o:
 for raw in proc.stdout:
  n,off,data=raw.split(b':',2);r=json.loads(data)
  if '2026-10-17T22:29:40.529Z'<=r.get('ts','')<='2026-10-17T23:07:08.362Z':
   o.write(json.dumps({'line':int(n),'offset':int(off),'row':r},ensure_ascii=False)+'\n');matches+=1
assert proc.wait() in [0,1]
print('deepseek时间窗',matches,'源码',head)

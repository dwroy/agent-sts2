import json,pathlib,collections
p=pathlib.Path(__file__).parent
def rows(n):
    with (p/f'{n}-selected.jsonl').open() as f:
        return [json.loads(x) for x in f]
d=rows('decisions');s=rows('states');rs=json.loads((p/'DGLWTQGRAT1T-resources.json').read_text())
print('决策时间窗',d[0]['line'],d[0]['row']['ts'],d[-1]['line'],d[-1]['row']['ts'])
print('决策键',list(d[0]['row']))
print('决策统计',collections.Counter((x['row'].get('decider'),x['row'].get('label')) for x in d))
for x in d:
    r=x['row']
    if r.get('decider')=='codex' or r.get('label') in ['potion','combat/potion']:
        print('决策',x['line'],r.get('floor'),r.get('turn'),r.get('decider'),r.get('label'),'选择',json.dumps(r.get('chosen'),ensure_ascii=False),'理由',str(r.get('rationale'))[:1600])
print('运行配置',rows('run-config'))
for x in rs['combats']:
    print('战斗',x['sequence'],'F',x['floor'],x['enemies'],'T1',x['entry_is_turn_one'],'entry',x['entry'],'last',x['last'],'exit',x['exit'],'end',x['end'])
print('SL',rs['sl_events'])
for x in rows('sl-attempts'):
    r=x['row'];print('SL详情',x['line'],list(r),json.dumps({k:v for k,v in r.items() if k not in ['snapshots','turns','draw_order','search_trace']},ensure_ascii=False)[:4500])
print('状态键',list(s[0]['row']),list(s[0]['row']['state']))
print('末态',json.dumps(s[-1],ensure_ascii=False)[:14000])

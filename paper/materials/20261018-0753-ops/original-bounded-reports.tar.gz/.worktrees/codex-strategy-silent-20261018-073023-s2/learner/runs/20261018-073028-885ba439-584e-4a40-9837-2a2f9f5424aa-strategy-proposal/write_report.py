import json
from pathlib import Path

out = Path(__file__).resolve().parent
batch = '20261018-073023-s2-strategy-proposal'
dispatch = json.loads((out / 'dispatch.json').read_text())
adds = json.loads((out / 'assigned-proposals.json').read_text())['adds']
source = json.loads((out / 'source-manifest.json').read_text())
base = source['base']
cases = [
    ('silent-proposal-c20b5139dd0dff71', '感染棱柱的污染血价',
     'DUZUBAJ3A8GP F27 T4—5；states 274830—274838',
     '火花3时污染0→3→6；下轮污染先撤去、火花变6，后续污染6→12→18。T4同时获得毒与格挡，不能只保留污染成本。',
     'turn-solver已按技能累计vitalSpark/tainted，rollout已有VITAL_SPARK自增路径；本批未发现可独立新增的确定机制缺口。',
     '缺原运行实际移动表与技能毒、挡、虚弱、火花增长的联合生产重放认证；不能据单次净失血新增少打技能规则。',
     '冻结同盘手牌及历史实际A10移动输入，逐步比对污染撤去、增长、毒结算与逐击损血；先证明具体源码失配，再做撤源失败与恢复通过。'),
    ('silent-proposal-ae9e692d680e3819', '失落／遗忘的抢夺归属',
     '5PM6JAQG6FNQ F39 首试T4—6；states 274351—274362',
     'T4玩家力敏各−4，两步法只把敏捷恢复至0；失落退出附近力量恢复至0；T6遗忘再次使敏捷−2。末次单步法只恢复至−2敏，仍无胜线。',
     '当前模型读取现场负属性，不能由负属性公式存在推定逐实体抢夺及死亡返还已经完整接通。',
     '缺逐实体抢夺来源的完整归属及遗忘退场返敏端点；现有片段不足以实现全套返还或固定击杀序。',
     '补齐单一来源抢夺、恢复与退场的连续实体证据，隔离步法等敏捷来源；验证原实体退场后数值返还和重新抢夺，不按enemy index猜来源。'),
    ('silent-proposal-52f1e1bd2e7db0ed', '下水道蚌当前进阶与加压',
     'CA5KE8GFJ9X2 F13 T1—5；states 273237—273268',
     '力量0→4→8；同招11→15→19，弱后15→11、19→14。覆甲轮初9/9/8/7/6。末T5玩家2血、10挡对14攻击，缺2生存量。',
     'monster-db的当前进阶观测读取与roomHpCost五样本门槛、measuredRoom五样本门槛均已存在；不重复修改已有入口。',
     '当前进阶第一观测读取及房间五样本门槛已有；缺加压、虚弱、覆甲联合生产重放和完整减层条件。',
     '以本局固定实际移动输入核压力与弱的联合数值；对覆甲减层单独保留未知，新增本角色证据后再验，房间代价不能由这一场直接定值。'),
    ('silent-proposal-6dd8bbff876be528', '电击机器人逐实体成长',
     '5PM6JAQG6FNQ F38 T3—4；states 274308—274317',
     '同23血上限的兼容机器人端点力2→4、攻击17→19；index4→3是名单重排，不是新实体证明。T3它仍参与攻击，T4群伤后退出。另一杀序候选未实打。',
     'rollout已有HIGH_VOLTAGE_POWER逐敌growth路径；现有固定源码测试只证明一般增长公式，不认证本场召唤代际。',
     '逐实体增长路径已有；缺可靠召唤代际身份、历史实际移动输入及另一目标顺序的完整后继。',
     '先固定生成、退场和重排的实例身份及本场输入，区分既有与新召唤；不能从类型或index自造继承、重置规则。'),
    ('silent-proposal-578e415a259e6835', '沙虫SL、护栏与资源分账',
     '8JRE1C4H4Z2W F33 首／三试T2、二试T5及末试T11；decisions 270216/270282/270264',
     '首／三试T2完整指纹相同，端点净失血3→15、净扣敌10→17；两次T3均损19。末试T2防御后本轮零净损也未获得胜局，不能一概否认防御。二试T5护栏候选与实际须分开。',
     '已有选择阶段快照、SL候选比较、单动作回执和离线观测端点。单动作completed/pending均不等于整条候选完成。',
     '缺跨抽弃牌、生成、用药和重规划的完整候选持续归属及资源联合认证；另保留原提案将金刚杵误链至覆甲账本silent-0016的追溯异议。',
     '保存原答→护栏→SL→派发→重问各段的稳定候选身份，核沙坑和资源来源；事实审计不要求获胜，但不能把未确认归属改成已完成。策略参数另需独立后移整战对照。'),
    ('silent-proposal-c0767768bf6a7ab1', '实验体全败SL的当前血价',
     'YF0LXT1QSTGG F48 第二／三试T1；decisions 271309/271348/271354；states 277327/277366及后继',
     '两起点完整指纹相同，候选预测净损0/10、伤54/36，实盘观测净损0/9、净扣敌45/38。第六试恢复防御续步后T1零净损仍败；F33该局另有SL实际胜战，不否定全部SL。',
     'silentSlResourceComparison和silentSlComparison已保留原／替线预测差、抽牌与未确认执行；没有把预测10写成实际9。',
     '当轮0/9失血与45/38扣敌已复核，预测比较已有；缺动作段完整执行归属、分源血价及受控整战后继。',
     '连同抽弃牌、药水、重问核实际动作段；保持预测与端点净差两账。若改全败并列选择，再冻结规则及独立后移局，不从单局拟惩罚系数。'),
    ('silent-proposal-a46bdb7fe711d79a', '实验体阶段与毒能力兑现',
     'YF0LXT1QSTGG F48 末试T3—5；states 277512—277528；decisions 271495—271509',
     '4HP/4毒转下一阶段212HP时旧毒与力量撤去；T4建立触媒2、T5敌零毒。两牌先有23挡，第三小刀后敏捷5→6而挡仍23；44攻击减23挡尚需21血，只有18血，缺3。',
     'silentPhaseCurrentFacts已有当前阶段、持有组件与已建能力分列；只读当前帧，poison_damage_already_dealt保留null。rollout已有阶段处理。',
     '阶段、持有及已建快照已有；缺逐候选施毒、毒结算、消耗附伤及敏捷取得顺序的完整执行比对。',
     '固定逐步牌序与分阶段实体，分别核即时施毒、结算、消耗附伤和后取得敏捷；不能用拥有毒性爆发或零毒末态代替施放证据，不改强制能力顺序。'),
    ('silent-proposal-1044224808015e5c', '双蟹零胜并列的SL血价',
     'XP2SL33HT0D9 F33 首／二试T3、首／末试T1；decisions 271992/272040、271982/272195',
     '两组分别完整指纹相同：T3净损9→14、净扣敌24→27；T1净损2→10、净扣敌25→34。B2原／替线均0、差0、SE0只描述样本；末试T1另有手里剑成长，末试T2零净损为保留的反例。',
     '候选比较与成长字段已有，探索仍沿既有B2／rollout门槛；本批未发现固定系数可以由这两组端点直接识别。',
     '当轮多损5血多扣3血、多损8血多扣9血已复核；缺同抽序、随机及预算的完整替线和成长后继。',
     '按run_id分训练／后移验证，同存档六次只作一个发现局；比本轮血价时保留永久力量与随机毒落点，不把B2零差变成安全或禁止一切付血探索。'),
    ('silent-proposal-7cbc6005db712ba9', '双蟹朝向、临时减力与挡',
     'XP2SL33HT0D9 F33 末试T2—5；states 278236—278259',
     '普通镣铐使爪0→−9力、4攻→0，T3恢复；T2已有14挡，斗篷另6成20，实际零净损。火箭T4背向57→转向38→弱28；4敏脆弱下偏折只增6挡，仍损22。',
     '现场挡、临时减力、朝向与弱的局部模型已有；本批只重核当前派发XP局，未重新验证原提案另引的A1/A6局。',
     '朝向、虚弱、临时减力及轮初挡已有局部实现；缺完整候选联合执行及消费者认证。',
     '固定本局完整候选并核朝向、弱、减力恢复与实际挡增量的联合输出；保留普通／升级和早期局边界，不按字段存在登记整项duplicate或更改持续价值权重。'),
    ('silent-proposal-c59f592f1427a67e', '机制、资源与SL的综合审计',
     'YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1/T3/T4/T5；同上原始行与账本',
     '本批六局原始记录和三组SL观测净差已核，阶段、临时减力、轮初挡、后取得敏捷分别保留。恢复、药槽变化、净HP差都不能单独证明回血／喝药／候选因果。',
     '复用已有候选比较、当前阶段快照和离线观测／终局／整轮端点，不重复注册同主题实现；原提案101局机制统计未在本批重做。',
     '缺逐来源资源账、完整候选执行及路线、休息、药水时机的受控替线联合认证；本批未重做原101局历史审计。',
     '后续仅在实际新增证据中补资源来源及同输入后继；全史统计需独立限定任务重核，不凭旧支持数关闭本提案，不设必休血线或药水时机。'),
]
assert [c[0] for c in cases] == dispatch['proposal_ids']
results = [{'id': c[0], 'state': 'waiting', 'reason': c[5]} for c in cases]
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(out / 'report.md')}
(out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(out / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

head = f'''# 静默猎手本批十项既有提案核验

记录时间：2026-10-18T07:42:17+08:00（写入前已运行date）。
批次：{batch}。来源任务strategy-proposal，实现任务沿用同名独立任务。
基线：{base}；开工git status为空，依普通队列流程merge main返回Already up to date，HEAD未变。
取证时live：{source['observed_live']}。本批未改源码、知识或受跟踪文件，无提交、合入、发布编号或shipped登记。

本批根learn.json对应行为task=strategy-proposal、character=silent、reason=proposal，工作树匹配，实际包含且仅处理十个proposal_ids；没有research_request、implementation_request或proposal_repair。
普通专题请求文件绑定另一旧批次，故不承接专题，不读取其冻结专题正文，也不扩展到fix-queue其他项。十份原Markdown均按队列proposal_sha256逐字核验并原样保存为*.original.md；原提案与父请求不改。

证据仅限本批六局：{','.join(dispatch['runs'])}。runs.jsonl核实全部SILENT/A10；六局都是旧局复核，不新增独立支持N，同存档尝试不扩样本，其他角色知识未读取。原报告所引98/99/101局以及A1/A6等旧证据不冒称本批覆盖。

共用extract_evidence.py实际抽取八流8,274条：states 4,062、decisions 3,941、sl-attempts 38、run-config 6、run-plans 33、brain 188、runs 6、fight-plans 0。
evidence/evidence-manifest.json保留每流source_size、计数、输出SHA及原流坏行计数；每条证据保留原行号、offset/bytes/SHA、row。inspect_evidence.py已逐条seek原日志复核字节SHA、JSON、显式归局及截点；byte-verification.json有实果。
states/decisions/brain各2条原流坏行只属于全源计数，不能归因本批六局；fight-plans选中0只说明本截点没有匹配记录。未覆盖任何旧报告、旧截点或零行初稿。

固定关键状态窗1,062帧见state-windows.json，17条引用决策见cited-decisions.json，观测整轮端点见turn-endpoints.json。
fact-checks.json的17项是材料恒等与端点算术核验，不是生产代码测试、动作因果证明或策略胜率验证。

## 当前交付判断

十项均waiting。已存在的中立事实记录可以直接按固定数据验收，不要求先有获胜样本；本批核到它们是有限子实现，没有可独立新增且经过验证的源码失配。
尚缺的包括历史实际移动输入、无歧义实例／候选归属与重规划后继。改变探索、血价、能力顺序或药水／路线规则还缺受控整战与独立后移验证，保留现有行为。
本批不把同主题窄实现记成整项duplicate，也不把既有源码last commit冒作本批fix。

共同拟合边界：不拟新系数、血线、强制排序或跨角色规则。本六局只作发现材料／固定核验，后续新Silent A10完整局作时间后移验证；按独立run而不是SL次数分组。授权Roy-2026-10-07-learning只提供改规则权限，不提供机制事实。
共同预期：补足可追溯判断及后续验证条件，策略收益未知。共同回退：本批无源码需回退；后续若实现，按实际源码提交回退，保留失败、原日志及CLI历史。真正行为上线后再做版本和双通知，不预填成功。

'''
details = []
for n, case in enumerate(cases, 1):
    id, title, evidence, facts, existing, reason, validation = case
    entry = adds[id]['row']
    details.append(f'''## {n}. {id} — {title}

账本：{', '.join(entry['ledger'])}。原来源任务：{entry['source_task']}；目标：{entry['target_task']}；已观察范围仅本批Silent A10。
原文：{id}.original.md；原SHA：{entry['proposal_sha256']}。
证据：{evidence}。
支持与反例：{facts}
旧规则／已核子项：{existing}
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；{reason}
验证与补证：{validation}

''')
proofs = []
for r in source['files']:
    if r['path'].split('/')[-1] in ['silent-sl-resource-comparison.ts', 'silent-sl-comparison.ts',
                                  'silent-selection-audit.ts', 'silent-selection-dispatch.ts',
                                  'silent-phase-current.ts', 'selection-execution.ts', 'monster-db.ts', 'room-costs.ts']:
        proofs.append(f"| {r['path']} | {r['live']['last_source_commit']} | {'是' if r['live']['source_is_live_ancestor'] else '否'} |")
audit = json.loads((out / 'audit-summary.json').read_text())
tail = '''## 源码边界、离线消费者与验证

source-manifest.json固定23份精确base/live叶的Git blob、原字节SHA、last_source_commit和live祖先判断；源码副本均为.txt，不复制全仓，不将过程副本当可执行源码。
23叶中20叶逐字相等；rollout-live.ts、rollout.ts、sl/explore.ts有差异。已读差异分别包含既有署名注释，以及本批来源末战之外的Queen盟友增力路径；不能据此宣称两树整体等价，也不把后续live实现归给本批。原运行code均带dirty，当前任何源码都不能冒称重建原dirty运行树。

以下只是已存在的子项源码证明，不是十项整体implemented/duplicate登记：

| 源文件 | 实际live祖先源码提交 | 祖先核验 |
|---|---|---|
''' + '\n'.join(proofs) + '''

读取固定本批末战输入，真实调用learner/audit-selection.ts→auditSelectionExecution：

| 局号／窗口 | 候选段 | 可链接相邻观测区间 | 已核整轮端点／未知 | 完整候选认证 |
|---|---:|---:|---:|---:|
'''
for r in audit:
    tail += f"| {r['run']} | {r['candidate_segments']} | {r['observed_intervals']}/{r['intervals']} | {r['turn_status'].get('observed_turn_endpoints', 0)}/{r['turn_status'].get('unknown', 0)} | {r['full_candidate_certified']} |\n"
tail += '''
此消费者按设计将完整候选结果保留null；这些计数只是有界离线关联结果，不是生产完整执行证明、自然大脑消费或策略胜率结果。未知开场／结束端点分别保留，不补未来状态。
最初tsx CLI三次均因沙箱listen EPERM在执行分析前失败，原stderr和audit-receipts.json保留。改用node --import本机已有tsx loader调用同一入口，不开IPC监听，三次均退出0，原输入与分析源码未改；实际命令在audit-v2-receipts.json。

本批无生产源码修改：没有撤生产源码失败／恢复通过实验，tsc=null、vitest=null、cases=null。未运行完整测试、未调用LLM／网络／游戏／模拟对局，未进行live merge或分配行为版本。上述数据核验与离线审计的0不得填入生产测试成功栏。
初次源码固定命令误用不存在的agent/src/core/loop.ts，记录source-pin-initial-error.txt；按git ls-tree确定真实agent/src/hand/loop.ts后完成23叶固定。初次材料检查脚本有未闭合方括号，保留inspect_evidence.initial.py.txt与inspection.stderr.txt；更正后的inspection-v2.stderr.txt为空、退出0。这些是过程命令错误，不是产品回归。

## 追溯异议及运维交付

原578e提案的silent-vajra-opening-strength（金刚杵）→silent-0016与该账本护喉甲覆甲claim不一致，原文尾部可直接核实；本批不将此链接当同机制支持，不改写原提案或旧claim，不强行支持原假设。请ops沿既有ops→watcher→Roy链保留／转交该异议；本批不代填watcher或Roy确认，也不把排队当送达。
无新增经验、无新提案id。code_proposals沿用十个真实CLI已登记id，逐项proposal_results见result.json／proposal-results.json。只经根ledger.py update追加本批report/proposal链接与只读核验说明，不新增support/repeat，不改claim、首证、evidence、prior、status、version或effect，不标shipped；实际CLI回执与保护字段核验另存。
交运维：本目录proposal.md、report.md、result.json、证据manifest和byte-verification.json、source-manifest.json、audit-summary.json、ledger更新及最终核验回执。报告／批次结束不关闭父学习要求。本批没有源码交付，不登记工作树完成或删除自身工作树。
'''
(out / 'proposal.md').write_text(head + ''.join(details) + tail)
(out / 'report.md').write_text(head + ''.join(details) + tail + '\n最终机器回报：result.json（完整40位base，fixes=[]，merged=null，tests三null）。\n')
before = json.loads((out / 'ledger-before.json').read_text())
updates = []
for id in sorted(before):
    related = [c[0] for c in cases if id in adds[c[0]]['row']['ledger']]
    note = f'{batch}：仅复核派发六旧Silent A10局与既有提案，实际8,274条原字节核验；关联提案{",".join(related)}全部waiting。只补本批报告链接，不新增独立支持/重复，不改既有状态或经验结论。'
    if id == 'silent-0016':
        note += '原578e提案金刚杵经验误链至本条覆甲claim的追溯异议保留，未当同机制支持；ops→watcher→Roy确认不得代填。'
    updates.append({'id': id, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(out / 'proposal.md'), str(out / 'report.md')]}, 'note': note})
(out / 'ledger-updates.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in updates))
print('报告、十项waiting处置及CLI链接输入已保存；账本更新数', len(updates))

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(OUT.parents[1]))
from extract_evidence import run_identity

dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = set(dispatch['runs'])
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
verified = []
for item in manifest:
    stream = item['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item['output_sha256']
    rows = []
    counts = Counter()
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for text in path.open():
            ref = json.loads(text)
            assert ref['source'] == str(ROOT / 'logs' / (stream + '.jsonl'))
            assert ref['offset'] + ref['bytes'] <= item['source_size']
            source.seek(ref['offset'])
            raw = source.read(ref['bytes'])
            assert hashlib.sha256(raw).hexdigest() == ref['sha256']
            assert json.loads(raw) == ref['row']
            assert run_identity(ref['row']) == ref['run_id'] in runs
            counts[ref['run_id']] += 1
            rows.append(ref)
    assert dict(counts) == {r: n for r, n in item['counts'].items() if n}
    streams[stream] = rows
    verified.append({'stream': stream, 'rows': len(rows), 'source_size': item['source_size'],
                     'counts': dict(counts), 'output_sha256': item['output_sha256']})

assert all(row['row']['character'].lower() == 'silent' and row['row']['ascension'] == 10
           for row in streams['runs'])
assert {row['run_id'] for row in streams['runs']} == runs
(OUT / 'byte-verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')

def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}

def brief(ref):
    state = ref['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': ref['line'], 'run': ref['run_id'], 'floor': state['run']['floor'],
            'turn': state.get('turn'), 'screen': state['screen'],
            'hp': player.get('current_hp', state['run'].get('current_hp')),
            'block': player.get('block'), 'powers': powers(player.get('powers')),
            'potions': state['run'].get('potions'),
            'enemies': [{'index': e['index'], 'id': e['enemy_id'], 'hp': e['current_hp'],
                         'max_hp': e['max_hp'], 'alive': e.get('is_alive'),
                         'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies') or []]}

floors = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
          '8JRE1C4H4Z2W': [17, 33], 'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [33]}
selected = [r for r in streams['states'] if r['row']['state']['run']['floor'] in floors[r['run_id']]]
(OUT / 'state-windows.json').write_text(json.dumps([brief(r) for r in selected], ensure_ascii=False, indent=2) + '\n')
index = defaultdict(list)
for ref in streams['states']:
    row = ref['row']
    index[(ref['run_id'], row['observed_ts'], row['fingerprint'])].append(ref)

cited = [270216, 270282, 270264, 271309, 271348, 271354, 271495, 271498, 271499,
         271501, 271507, 271509, 271982, 272040, 271992, 272195, 272076]
decisions = []
groups = defaultdict(list)
for ref in streams['decisions']:
    row = ref['row']
    if row.get('floor') not in floors[ref['run_id']]:
        continue
    matches = index[(ref['run_id'], row['observed_ts'], row['fingerprint'])]
    if len(matches) != 1:
        match = None
    else:
        match = matches[0]
    key = (ref['run_id'], row.get('floor'), row.get('sl_attempt'), row.get('sl_reloads'), row.get('turn'))
    groups[key].append((ref, match))
    if ref['line'] in cited:
        decisions.append({'line': ref['line'], 'row': row, 'matched_state': brief(match) if match else None})
(OUT / 'cited-decisions.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')

turns = []
for key, members in groups.items():
    run, floor, attempt, reloads, turn = key
    if turn is None or attempt is None or members[0][1] is None:
        continue
    opening = members[0][1]
    later = [r for r in selected if r['run_id'] == run and r['line'] > opening['line']
             and r['row']['state']['run']['floor'] == floor and r['row']['state'].get('turn') == turn + 1
             and r['row']['state'].get('screen') == 'COMBAT']
    # A next-attempt boundary cannot close this attempt's observed turn.
    last_line = members[-1][1]['line'] if members[-1][1] else opening['line']
    next_decision = next((r for r in streams['decisions'] if r['run_id'] == run and r['line'] > members[-1][0]['line']), None)
    same_attempt = next_decision and next_decision['row'].get('sl_attempt') == attempt and next_decision['row'].get('sl_reloads') == reloads
    closing = next((r for r in later if r['line'] > last_line), None) if same_attempt else None
    a = brief(opening)
    b = brief(closing) if closing else None
    comparable = b is not None and len(a['enemies']) == len(b['enemies']) and all(
        e['id'] == f['id'] and e['max_hp'] == f['max_hp'] for e, f in zip(a['enemies'], b['enemies']))
    turns.append({'run': run, 'floor': floor, 'attempt': attempt, 'reloads': reloads, 'turn': turn,
                  'decisions': [r['line'] for r, _ in members], 'opening': a, 'next_turn_observation': b,
                  'net_hp_decrease': a['hp'] - b['hp'] if b else None,
                  'net_enemy_hp_decrease': sum(e['hp'] - f['hp'] for e, f in zip(a['enemies'], b['enemies'])) if comparable else None,
                  'limitation': '观测端点净差，非完整候选执行证明；同类型与血上限相同也不保证同实体。'})
(OUT / 'turn-endpoints.json').write_text(json.dumps(turns, ensure_ascii=False, indent=2) + '\n')
for row in turns:
    if row['floor'] in [13, 27, 38, 39] or (row['floor'] in [33, 48] and row['turn'] <= 5):
        print(row['run'], 'F'+str(row['floor']), 'A'+str(row['attempt']), 'T'+str(row['turn']),
              'states', row['opening']['line'], row['next_turn_observation']['line'] if row['next_turn_observation'] else None,
              '净损', row['net_hp_decrease'], '净扣敌', row['net_enemy_hp_decrease'])
print('逐字节核验', sum(x['rows'] for x in verified), '目标状态窗', len(selected), '引用决策', len(decisions))

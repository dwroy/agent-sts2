import json
from pathlib import Path

out = Path(__file__).resolve().parent
states = {r['line']: r for r in json.loads((out / 'state-windows.json').read_text())}
decisions = {r['line']: r for r in json.loads((out / 'cited-decisions.json').read_text())}
turns = {(r['run'], r['floor'], r['attempt'], r['turn']): r
         for r in json.loads((out / 'turn-endpoints.json').read_text())}
checks = []

def check(name, condition):
    assert condition, name
    checks.append({'核验': name, '通过': True})

def pair(run, floor, turn, a, b, expected):
    first, second = turns[(run, floor, a, turn)], turns[(run, floor, b, turn)]
    actual = [first['net_hp_decrease'], second['net_hp_decrease'],
              first['net_enemy_hp_decrease'], second['net_enemy_hp_decrease']]
    check(f'{run} F{floor} T{turn} 尝试{a}/{b}观测端点净差', actual == expected)

def enemy(line, name):
    return next(e for e in states[line]['enemies'] if e['id'] == name)

def threat(line, name):
    return sum(i['damage'] * i['hits'] for i in enemy(line, name)['intents'] if i.get('damage') is not None)

for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    check(f'决策{a}/{b}完整指纹逐字相同', decisions[a]['row']['fingerprint'] == decisions[b]['row']['fingerprint'])
pair('8JRE1C4H4Z2W', 33, 2, 1, 3, [3, 15, 10, 17])
pair('YF0LXT1QSTGG', 48, 1, 2, 3, [0, 9, 45, 38])
pair('XP2SL33HT0D9', 33, 3, 1, 2, [9, 14, 24, 27])
pair('XP2SL33HT0D9', 33, 1, 1, 6, [2, 10, 25, 34])
check('棱柱技能污染增量与下一轮撤去',
      [states[n]['powers'].get('TAINTED_POWER', 0) for n in [274830, 274831, 274833, 274834, 274836, 274837, 274838]]
      == [0, 3, 6, 0, 6, 12, 18])
check('下水道蚌力量与弱后当前意图分别核验',
      [enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0) for n in [273237, 273252, 273263]] == [0, 4, 8]
      and [threat(n, 'SEWER_CLAM') for n in [273252, 273254, 273263, 273268]] == [15, 11, 19, 14])
check('电击机器人兼容实体端点的成长与索引重排',
      [enemy(n, 'ZAPBOT')['max_hp'] for n in [274308, 274313]] == [23, 23]
      and [enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'] for n in [274308, 274313]] == [2, 4]
      and [threat(n, 'ZAPBOT') for n in [274308, 274313]] == [17, 19]
      and [enemy(n, 'ZAPBOT')['index'] for n in [274308, 274313]] == [4, 3])
check('失落退出附近的力量恢复与遗忘后续再抢只记端点',
      states[274357]['powers']['STRENGTH_POWER'] == -4
      and states[274358]['powers'].get('STRENGTH_POWER', 0) == 0
      and states[274362]['powers']['DEXTERITY_POWER'] == -2)
check('实验体阶段变化清旧毒与力量不视为击杀',
      enemy(277512, 'TEST_SUBJECT')['hp'] == 4
      and enemy(277513, 'TEST_SUBJECT')['hp'] == 212
      and enemy(277512, 'TEST_SUBJECT')['powers']['POISON_POWER'] == 4
      and enemy(277513, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0) == 0
      and enemy(277513, 'TEST_SUBJECT')['powers'].get('STRENGTH_POWER', 0) == 0)
check('后取得敏捷不回填现有23挡，终局显示攻击44',
      [states[n]['powers']['DEXTERITY_POWER'] for n in [277525, 277526]] == [5, 6]
      and [states[n]['block'] for n in [277525, 277526]] == [23, 23]
      and threat(277527, 'TEST_SUBJECT') == 44
      and 44 - 23 - states[277527]['hp'] == 3)
check('普通镣铐临时减力及下一轮恢复、轮初挡另计',
      enemy(278237, 'CRUSHER')['powers']['STRENGTH_POWER'] == -9
      and enemy(278242, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) == 0
      and [states[n]['block'] for n in [278236, 278240]] == [14, 20]
      and states[278236]['hp'] == states[278242]['hp'])
check('双蟹朝向与虚弱57到38到28分开，脆弱下6挡',
      [threat(n, 'ROCKET') for n in [278249, 278252, 278253]] == [57, 38, 28]
      and states[278255]['block'] == 6)
check('零胜并列的统计口径不变成安全证明',
      decisions[272040]['row']['sl_explore']['b2'] == {'original': 0, 'replacement': 0, 'diff': 0, 'se': 0})
(out / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(f'{len(checks)}项固定材料核验通过；这不是生产源码测试或完整候选执行认证。')

# 静默猎手本批十项既有提案核验

记录时间：2026-10-18T07:42:17+08:00（写入前已运行date）。
批次：20261018-073023-s2-strategy-proposal。来源任务strategy-proposal，实现任务沿用同名独立任务。
基线：9256bff0b0ce7ac826bb4dbf7d2a9fe7bcdde554；开工git status为空，依普通队列流程merge main返回Already up to date，HEAD未变。
取证时live：49bec5ed231e34eb4b63cd3519972ec6f72f8320。本批未改源码、知识或受跟踪文件，无提交、合入、发布编号或shipped登记。

本批根learn.json对应行为task=strategy-proposal、character=silent、reason=proposal，工作树匹配，实际包含且仅处理十个proposal_ids；没有research_request、implementation_request或proposal_repair。
普通专题请求文件绑定另一旧批次，故不承接专题，不读取其冻结专题正文，也不扩展到fix-queue其他项。十份原Markdown均按队列proposal_sha256逐字核验并原样保存为*.original.md；原提案与父请求不改。

证据仅限本批六局：DUZUBAJ3A8GP,5PM6JAQG6FNQ,CA5KE8GFJ9X2,8JRE1C4H4Z2W,YF0LXT1QSTGG,XP2SL33HT0D9。runs.jsonl核实全部SILENT/A10；六局都是旧局复核，不新增独立支持N，同存档尝试不扩样本，其他角色知识未读取。原报告所引98/99/101局以及A1/A6等旧证据不冒称本批覆盖。

共用extract_evidence.py实际抽取八流8,274条：states 4,062、decisions 3,941、sl-attempts 38、run-config 6、run-plans 33、brain 188、runs 6、fight-plans 0。
evidence/evidence-manifest.json保留每流source_size、计数、输出SHA及原流坏行计数；每条证据保留原行号、offset/bytes/SHA、row。inspect_evidence.py已逐条seek原日志复核字节SHA、JSON、显式归局及截点；byte-verification.json有实果。
states/decisions/brain各2条原流坏行只属于全源计数，不能归因本批六局；fight-plans选中0只说明本截点没有匹配记录。未覆盖任何旧报告、旧截点或零行初稿。

固定关键状态窗1,062帧见state-windows.json，17条引用决策见cited-decisions.json，观测整轮端点见turn-endpoints.json。
fact-checks.json的17项是材料恒等与端点算术核验，不是生产代码测试、动作因果证明或策略胜率验证。

## 当前交付判断

十项均waiting。已存在的中立事实记录可以直接按固定数据验收，不要求先有获胜样本；本批核到它们是有限子实现，没有可独立新增且经过验证的源码失配。
尚缺的包括历史实际移动输入、无歧义实例／候选归属与重规划后继。改变探索、血价、能力顺序或药水／路线规则还缺受控整战与独立后移验证，保留现有行为。
本批不把同主题窄实现记成整项duplicate，也不把既有源码last commit冒作本批fix。

共同拟合边界：不拟新系数、血线、强制排序或跨角色规则。本六局只作发现材料／固定核验，后续新Silent A10完整局作时间后移验证；按独立run而不是SL次数分组。授权Roy-2026-10-07-learning只提供改规则权限，不提供机制事实。
共同预期：补足可追溯判断及后续验证条件，策略收益未知。共同回退：本批无源码需回退；后续若实现，按实际源码提交回退，保留失败、原日志及CLI历史。真正行为上线后再做版本和双通知，不预填成功。

## 1. silent-proposal-c20b5139dd0dff71 — 感染棱柱的污染血价

账本：silent-0168。原来源任务：experience-update；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-c20b5139dd0dff71.original.md；原SHA：bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。
证据：DUZUBAJ3A8GP F27 T4—5；states 274830—274838。
支持与反例：火花3时污染0→3→6；下轮污染先撤去、火花变6，后续污染6→12→18。T4同时获得毒与格挡，不能只保留污染成本。
旧规则／已核子项：turn-solver已按技能累计vitalSpark/tainted，rollout已有VITAL_SPARK自增路径；本批未发现可独立新增的确定机制缺口。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；缺原运行实际移动表与技能毒、挡、虚弱、火花增长的联合生产重放认证；不能据单次净失血新增少打技能规则。
验证与补证：冻结同盘手牌及历史实际A10移动输入，逐步比对污染撤去、增长、毒结算与逐击损血；先证明具体源码失配，再做撤源失败与恢复通过。

## 2. silent-proposal-ae9e692d680e3819 — 失落／遗忘的抢夺归属

账本：silent-0183, silent-0005。原来源任务：experience-update；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-ae9e692d680e3819.original.md；原SHA：b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。
证据：5PM6JAQG6FNQ F39 首试T4—6；states 274351—274362。
支持与反例：T4玩家力敏各−4，两步法只把敏捷恢复至0；失落退出附近力量恢复至0；T6遗忘再次使敏捷−2。末次单步法只恢复至−2敏，仍无胜线。
旧规则／已核子项：当前模型读取现场负属性，不能由负属性公式存在推定逐实体抢夺及死亡返还已经完整接通。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；缺逐实体抢夺来源的完整归属及遗忘退场返敏端点；现有片段不足以实现全套返还或固定击杀序。
验证与补证：补齐单一来源抢夺、恢复与退场的连续实体证据，隔离步法等敏捷来源；验证原实体退场后数值返还和重新抢夺，不按enemy index猜来源。

## 3. silent-proposal-52f1e1bd2e7db0ed — 下水道蚌当前进阶与加压

账本：silent-0231。原来源任务：experience-update；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-52f1e1bd2e7db0ed.original.md；原SHA：651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。
证据：CA5KE8GFJ9X2 F13 T1—5；states 273237—273268。
支持与反例：力量0→4→8；同招11→15→19，弱后15→11、19→14。覆甲轮初9/9/8/7/6。末T5玩家2血、10挡对14攻击，缺2生存量。
旧规则／已核子项：monster-db的当前进阶观测读取与roomHpCost五样本门槛、measuredRoom五样本门槛均已存在；不重复修改已有入口。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；当前进阶第一观测读取及房间五样本门槛已有；缺加压、虚弱、覆甲联合生产重放和完整减层条件。
验证与补证：以本局固定实际移动输入核压力与弱的联合数值；对覆甲减层单独保留未知，新增本角色证据后再验，房间代价不能由这一场直接定值。

## 4. silent-proposal-6dd8bbff876be528 — 电击机器人逐实体成长

账本：silent-0233, silent-0209。原来源任务：experience-update；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-6dd8bbff876be528.original.md；原SHA：48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。
证据：5PM6JAQG6FNQ F38 T3—4；states 274308—274317。
支持与反例：同23血上限的兼容机器人端点力2→4、攻击17→19；index4→3是名单重排，不是新实体证明。T3它仍参与攻击，T4群伤后退出。另一杀序候选未实打。
旧规则／已核子项：rollout已有HIGH_VOLTAGE_POWER逐敌growth路径；现有固定源码测试只证明一般增长公式，不认证本场召唤代际。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；逐实体增长路径已有；缺可靠召唤代际身份、历史实际移动输入及另一目标顺序的完整后继。
验证与补证：先固定生成、退场和重排的实例身份及本场输入，区分既有与新召唤；不能从类型或index自造继承、重置规则。

## 5. silent-proposal-578e415a259e6835 — 沙虫SL、护栏与资源分账

账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。原来源任务：experience-update；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-578e415a259e6835.original.md；原SHA：e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。
证据：8JRE1C4H4Z2W F33 首／三试T2、二试T5及末试T11；decisions 270216/270282/270264。
支持与反例：首／三试T2完整指纹相同，端点净失血3→15、净扣敌10→17；两次T3均损19。末试T2防御后本轮零净损也未获得胜局，不能一概否认防御。二试T5护栏候选与实际须分开。
旧规则／已核子项：已有选择阶段快照、SL候选比较、单动作回执和离线观测端点。单动作completed/pending均不等于整条候选完成。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；缺跨抽弃牌、生成、用药和重规划的完整候选持续归属及资源联合认证；另保留原提案将金刚杵误链至覆甲账本silent-0016的追溯异议。
验证与补证：保存原答→护栏→SL→派发→重问各段的稳定候选身份，核沙坑和资源来源；事实审计不要求获胜，但不能把未确认归属改成已完成。策略参数另需独立后移整战对照。

## 6. silent-proposal-c0767768bf6a7ab1 — 实验体全败SL的当前血价

账本：silent-0079。原来源任务：postmortem；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-c0767768bf6a7ab1.original.md；原SHA：28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。
证据：YF0LXT1QSTGG F48 第二／三试T1；decisions 271309/271348/271354；states 277327/277366及后继。
支持与反例：两起点完整指纹相同，候选预测净损0/10、伤54/36，实盘观测净损0/9、净扣敌45/38。第六试恢复防御续步后T1零净损仍败；F33该局另有SL实际胜战，不否定全部SL。
旧规则／已核子项：silentSlResourceComparison和silentSlComparison已保留原／替线预测差、抽牌与未确认执行；没有把预测10写成实际9。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；当轮0/9失血与45/38扣敌已复核，预测比较已有；缺动作段完整执行归属、分源血价及受控整战后继。
验证与补证：连同抽弃牌、药水、重问核实际动作段；保持预测与端点净差两账。若改全败并列选择，再冻结规则及独立后移局，不从单局拟惩罚系数。

## 7. silent-proposal-a46bdb7fe711d79a — 实验体阶段与毒能力兑现

账本：silent-0021, silent-0027, silent-0028, silent-0085。原来源任务：postmortem；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-a46bdb7fe711d79a.original.md；原SHA：eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。
证据：YF0LXT1QSTGG F48 末试T3—5；states 277512—277528；decisions 271495—271509。
支持与反例：4HP/4毒转下一阶段212HP时旧毒与力量撤去；T4建立触媒2、T5敌零毒。两牌先有23挡，第三小刀后敏捷5→6而挡仍23；44攻击减23挡尚需21血，只有18血，缺3。
旧规则／已核子项：silentPhaseCurrentFacts已有当前阶段、持有组件与已建能力分列；只读当前帧，poison_damage_already_dealt保留null。rollout已有阶段处理。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；阶段、持有及已建快照已有；缺逐候选施毒、毒结算、消耗附伤及敏捷取得顺序的完整执行比对。
验证与补证：固定逐步牌序与分阶段实体，分别核即时施毒、结算、消耗附伤和后取得敏捷；不能用拥有毒性爆发或零毒末态代替施放证据，不改强制能力顺序。

## 8. silent-proposal-1044224808015e5c — 双蟹零胜并列的SL血价

账本：silent-0079。原来源任务：postmortem；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-1044224808015e5c.original.md；原SHA：4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。
证据：XP2SL33HT0D9 F33 首／二试T3、首／末试T1；decisions 271992/272040、271982/272195。
支持与反例：两组分别完整指纹相同：T3净损9→14、净扣敌24→27；T1净损2→10、净扣敌25→34。B2原／替线均0、差0、SE0只描述样本；末试T1另有手里剑成长，末试T2零净损为保留的反例。
旧规则／已核子项：候选比较与成长字段已有，探索仍沿既有B2／rollout门槛；本批未发现固定系数可以由这两组端点直接识别。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；当轮多损5血多扣3血、多损8血多扣9血已复核；缺同抽序、随机及预算的完整替线和成长后继。
验证与补证：按run_id分训练／后移验证，同存档六次只作一个发现局；比本轮血价时保留永久力量与随机毒落点，不把B2零差变成安全或禁止一切付血探索。

## 9. silent-proposal-7cbc6005db712ba9 — 双蟹朝向、临时减力与挡

账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。原来源任务：postmortem；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-7cbc6005db712ba9.original.md；原SHA：f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。
证据：XP2SL33HT0D9 F33 末试T2—5；states 278236—278259。
支持与反例：普通镣铐使爪0→−9力、4攻→0，T3恢复；T2已有14挡，斗篷另6成20，实际零净损。火箭T4背向57→转向38→弱28；4敏脆弱下偏折只增6挡，仍损22。
旧规则／已核子项：现场挡、临时减力、朝向与弱的局部模型已有；本批只重核当前派发XP局，未重新验证原提案另引的A1/A6局。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；朝向、虚弱、临时减力及轮初挡已有局部实现；缺完整候选联合执行及消费者认证。
验证与补证：固定本局完整候选并核朝向、弱、减力恢复与实际挡增量的联合输出；保留普通／升级和早期局边界，不按字段存在登记整项duplicate或更改持续价值权重。

## 10. silent-proposal-c59f592f1427a67e — 机制、资源与SL的综合审计

账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。原来源任务：experience-update；目标：strategy-proposal；已观察范围仅本批Silent A10。
原文：silent-proposal-c59f592f1427a67e.original.md；原SHA：81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。
证据：YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1/T3/T4/T5；同上原始行与账本。
支持与反例：本批六局原始记录和三组SL观测净差已核，阶段、临时减力、轮初挡、后取得敏捷分别保留。恢复、药槽变化、净HP差都不能单独证明回血／喝药／候选因果。
旧规则／已核子项：复用已有候选比较、当前阶段快照和离线观测／终局／整轮端点，不重复注册同主题实现；原提案101局机制统计未在本批重做。
预期行为：沿原提案保留完整候选与事实参考；缺条件时保持未知、全部选项与原排序，不把预测写成实际收益。
处置：waiting；缺逐来源资源账、完整候选执行及路线、休息、药水时机的受控替线联合认证；本批未重做原101局历史审计。
验证与补证：后续仅在实际新增证据中补资源来源及同输入后继；全史统计需独立限定任务重核，不凭旧支持数关闭本提案，不设必休血线或药水时机。

## 源码边界、离线消费者与验证

source-manifest.json固定23份精确base/live叶的Git blob、原字节SHA、last_source_commit和live祖先判断；源码副本均为.txt，不复制全仓，不将过程副本当可执行源码。
23叶中20叶逐字相等；rollout-live.ts、rollout.ts、sl/explore.ts有差异。已读差异分别包含既有署名注释，以及本批来源末战之外的Queen盟友增力路径；不能据此宣称两树整体等价，也不把后续live实现归给本批。原运行code均带dirty，当前任何源码都不能冒称重建原dirty运行树。

以下只是已存在的子项源码证明，不是十项整体implemented/duplicate登记：

| 源文件 | 实际live祖先源码提交 | 祖先核验 |
|---|---|---|
| agent/src/reflex/silent-sl-resource-comparison.ts | 0e4fe4df89a06682468e0e4716c12126e76369d5 | 是 |
| agent/src/reflex/silent-sl-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 是 |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 是 |
| agent/src/reflex/silent-selection-dispatch.ts | bade647f9fe4c9103b40e2f26b26296692ad24b7 | 是 |
| agent/src/reflex/silent-phase-current.ts | 8698c581dac6c7e957f50a381586960a6d0c9b57 | 是 |
| agent/src/knowledge/monster-db.ts | 4ed3c72df30f27b881da637aebf528b97440e0bb | 是 |
| agent/src/knowledge/room-costs.ts | 295a90aef9eb6f5b267490294f7733806419c45a | 是 |
| learner/lib/selection-execution.ts | cf72bd21148059f111f760cc98a727369e34a47e | 是 |

读取固定本批末战输入，真实调用learner/audit-selection.ts→auditSelectionExecution：

| 局号／窗口 | 候选段 | 可链接相邻观测区间 | 已核整轮端点／未知 | 完整候选认证 |
|---|---:|---:|---:|---:|
| 8JRE1C4H4Z2W | 58 | 225/232 | 39/11 | 0 |
| YF0LXT1QSTGG | 24 | 228/235 | 25/11 | 0 |
| XP2SL33HT0D9 | 58 | 237/244 | 28/17 | 0 |

此消费者按设计将完整候选结果保留null；这些计数只是有界离线关联结果，不是生产完整执行证明、自然大脑消费或策略胜率结果。未知开场／结束端点分别保留，不补未来状态。
最初tsx CLI三次均因沙箱listen EPERM在执行分析前失败，原stderr和audit-receipts.json保留。改用node --import本机已有tsx loader调用同一入口，不开IPC监听，三次均退出0，原输入与分析源码未改；实际命令在audit-v2-receipts.json。

本批无生产源码修改：没有撤生产源码失败／恢复通过实验，tsc=null、vitest=null、cases=null。未运行完整测试、未调用LLM／网络／游戏／模拟对局，未进行live merge或分配行为版本。上述数据核验与离线审计的0不得填入生产测试成功栏。
初次源码固定命令误用不存在的agent/src/core/loop.ts，记录source-pin-initial-error.txt；按git ls-tree确定真实agent/src/hand/loop.ts后完成23叶固定。初次材料检查脚本有未闭合方括号，保留inspect_evidence.initial.py.txt与inspection.stderr.txt；更正后的inspection-v2.stderr.txt为空、退出0。这些是过程命令错误，不是产品回归。

## 追溯异议及运维交付

原578e提案的silent-vajra-opening-strength（金刚杵）→silent-0016与该账本护喉甲覆甲claim不一致，原文尾部可直接核实；本批不将此链接当同机制支持，不改写原提案或旧claim，不强行支持原假设。请ops沿既有ops→watcher→Roy链保留／转交该异议；本批不代填watcher或Roy确认，也不把排队当送达。
无新增经验、无新提案id。code_proposals沿用十个真实CLI已登记id，逐项proposal_results见result.json／proposal-results.json。只经根ledger.py update追加本批report/proposal链接与只读核验说明，不新增support/repeat，不改claim、首证、evidence、prior、status、version或effect，不标shipped；实际CLI回执与保护字段核验另存。
交运维：本目录proposal.md、report.md、result.json、证据manifest和byte-verification.json、source-manifest.json、audit-summary.json、ledger更新及最终核验回执。报告／批次结束不关闭父学习要求。本批没有源码交付，不登记工作树完成或删除自身工作树。

收尾实果（2026-10-18T07:46:22+08:00，先date后写）：根ledger.py update实际退出0、30条仅链接更新；保护字段逐项相等。根ledger.py check实际513项、0问题。文稿gitleaks退出0。completion-check.json核HEAD=9256bff0b0ce7ac826bb4dbf7d2a9fe7bcdde554、tracked clean、git diff --binary为0字节、派发身份及十项结果完整。无源码撤改实验、tsc/vitest/cases均null，无源码提交或合入。全部材料逐文件SHA另存artifact-manifest.json。

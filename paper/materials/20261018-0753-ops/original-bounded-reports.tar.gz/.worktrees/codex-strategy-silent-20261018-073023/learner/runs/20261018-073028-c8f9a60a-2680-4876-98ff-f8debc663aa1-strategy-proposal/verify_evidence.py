import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']
TARGETS = {
    'VLZ6CCT8AQ0A': {35, 36, 37, 43, 44, 45},
    '8JRE1C4H4Z2W': {17, 33},
    'CA5KE8GFJ9X2': {7, 9, 13},
    '5PM6JAQG6FNQ': {33, 38, 39},
    '61E2QS63Y9WU': {17, 23, 28},
    'DUZUBAJ3A8GP': {30},
}


def powers(obj):
    return {p['power_id']: p['amount'] for p in obj.get('powers', [])}


def ref(e):
    return {k: e[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def compact(e):
    s = e['row']['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {
        **ref(e), 'ts': e['row']['ts'], 'observed_ts': e['row'].get('observed_ts'),
        'screen': s['screen'], 'floor': s['run']['floor'], 'turn': s['turn'],
        'player': {**{k: p.get(k) for k in ('current_hp', 'max_hp', 'energy', 'block')}, 'powers': powers(p)},
        'deck_upgraded': sum(bool(c.get('upgraded')) for c in s['run'].get('deck', [])),
        'potions': s['run'].get('potions'),
        'hand': [{**{k: c.get(k) for k in ('card_id', 'upgraded', 'energy_cost')},
                  'values': {v['name']: [v['base_value'], v['current_value']] for v in c.get('dynamic_values', [])}}
                 for c in c.get('hand', [])],
        'enemies': [{**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'move_id')},
                     'powers': powers(e), 'intents': e.get('intents')} for e in c.get('enemies', [])],
    }


def main():
    manifests = []
    rows = {}
    total = 0
    for directory in ('evidence', 'evidence-extra'):
        manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
        for m in manifest:
            stream = m['stream']
            path = OUT / directory / (stream + '.evidence.jsonl')
            data = path.read_bytes()
            assert hashlib.sha256(data).hexdigest() == m['output_sha256']
            counts = Counter()
            selected = []
            with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
                for line in data.splitlines():
                    e = json.loads(line)
                    source.seek(e['offset'])
                    raw = source.read(e['bytes'])
                    assert raw.endswith(b'\n') and e['offset'] + e['bytes'] <= m['source_size']
                    assert hashlib.sha256(raw).hexdigest() == e['sha256']
                    r = json.loads(raw)
                    assert r == e['row'] and extract.run_identity(r) == e['run_id']
                    assert e['run_id'] in RUNS
                    if stream == 'states':
                        assert r['state']['run']['character_id'] == 'SILENT'
                        assert r['state']['run']['ascension'] == 10
                    counts[e['run_id']] += 1
                    selected.append(e)
            assert {run: counts[run] for run in RUNS} == m['counts']
            rows[stream] = selected
            total += len(selected)
            manifests.append(m)

    facts = [compact(e) for e in rows['states']
             if e['row']['state'].get('run', {}).get('floor') in TARGETS[e['run_id']]]
    (OUT / 'bounded-state-facts.json').write_text(json.dumps(facts, ensure_ascii=False, indent=2) + '\n')
    state_index = {e['line']: e for e in rows['states']}
    checks = []

    def check(name, condition, lines):
        assert condition, name
        checks.append({'fact': name, 'verified': True, 'references': [ref(state_index[n]) for n in lines]})

    def state(n):
        return state_index[n]['row']['state']

    def hand(n, ident):
        return next(c for c in state(n)['combat']['hand'] if c['card_id'] == ident)

    def value(n, ident, name):
        return next(v['current_value'] for v in hand(n, ident)['dynamic_values'] if v['name'] == name)

    a, b = state(275564), state(275565)
    check('F35神化施放能量7→5', a['combat']['player']['energy'] == 7 and b['combat']['player']['energy'] == 5, [275564, 275565])
    for ident, name, before, after in [('DEFEND_SILENT', 'Block', 5, 8), ('STRIKE_SILENT', 'Damage', 7, 10), ('DAGGER_SPRAY', 'Damage', 5, 7)]:
        check('F35神化配对' + ident, value(275564, ident, name) == before and value(275565, ident, name) == after, [275564, 275565])
    check('F35必备工具费用1→0', hand(275564, 'TOOLS_OF_THE_TRADE')['energy_cost'] == 1 and hand(275565, 'TOOLS_OF_THE_TRADE')['energy_cost'] == 0, [275564, 275565])
    check('F43后抽毒雾已升级且场外升级数不变', hand(275687, 'NOXIOUS_FUMES')['upgraded'] and
          sum(bool(c.get('upgraded')) for c in state(275679)['run']['deck']) ==
          sum(bool(c.get('upgraded')) for c in state(275687)['run']['deck']) == 4, [275679, 275687])
    check('F45候选神化后来消失但未兑现升级', hand(275731, 'APOTHEOSIS')['upgraded'] is False and
          state(275732)['combat']['hand'] == [] and powers(state(275732)['combat']['player'])['FASTEN_POWER'] == 4,
          [275731, 275732])
    check('F45T3口红力量1→2和敏捷0→1', powers(state(275737)['combat']['player'])['STRENGTH_POWER'] == 1 and
          powers(state(275738)['combat']['player'])['STRENGTH_POWER'] == 2 and
          powers(state(275738)['combat']['player'])['DEXTERITY_POWER'] == 1, [275737, 275738])
    check('F36后抽致命毒药7毒一费、无直接扣血', hand(275604, 'DEADLY_POISON')['upgraded'] and
          value(275604, 'DEADLY_POISON', 'PoisonPower') == 7 and
          state(275604)['combat']['player']['energy'] - state(275605)['combat']['player']['energy'] == 1 and
          state(275604)['combat']['enemies'][0]['current_hp'] == state(275605)['combat']['enemies'][0]['current_hp'] and
          powers(state(275605)['combat']['enemies'][0])['POISON_POWER'] == 7, [275604, 275605])
    (OUT / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    chosen_lines = {269706, 269707, 269748, 269754, 269755, 269770, 270216, 270282, 270264}
    selected = [e for e in rows['decisions'] if e['line'] in chosen_lines]
    assert len(selected) == len(chosen_lines)
    (OUT / 'bounded-decision-facts.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
    summary = {'total_verified_references': total, 'streams': manifests, 'state_facts': len(facts),
               'fact_checks': len(checks), 'selected_decisions': len(selected),
               'scope': '原件/身份/确定性事实核验；未运行生产模拟、消费者或测试'}
    (OUT / 'evidence-verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k != 'streams'}, ensure_ascii=False))


if __name__ == '__main__':
    main()

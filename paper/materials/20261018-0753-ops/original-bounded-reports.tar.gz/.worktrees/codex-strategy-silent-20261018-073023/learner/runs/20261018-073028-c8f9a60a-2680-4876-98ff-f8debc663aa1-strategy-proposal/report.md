# 静默猎手策略批次回报

时间：2026-10-18T07:43:37+08:00。本批已逐项复核十个领取提案，全部waiting，保留具体缺证理由。无源码/知识/任务模板改动，无提交、合入、发布号或shipped；不关闭其他研究父要求。

任务：strategy-proposal；角色：silent；批次：20261018-073023-strategy-proposal。
base/最终HEAD：`9256bff0b0ce7ac826bb4dbf7d2a9fe7bcdde554`。
报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-073023/learner/runs/20261018-073028-c8f9a60a-2680-4876-98ff-f8debc663aa1-strategy-proposal/report.md
提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-073023/learner/runs/20261018-073028-c8f9a60a-2680-4876-98ff-f8debc663aa1-strategy-proposal/proposal.md

## 身份与范围

开工git status干净；git merge --no-edit main为Already up to date。dispatch.json为本次learn.json唯一对应行，十ID与工作树角色精确匹配。没有research_request或implementation_request；普通专题根请求绑定旧批，不适用于本批。没有合入后续main、改请求/learn.json、领取其他提案或派下级。六局runs.jsonl均SILENT A10；没有使用其他角色私有知识或预训练游戏结论。

## 原始证据与材料核验

按任务共用extract_evidence.py入口提取默认六流，并以独立evidence-extra目录提取runs/fight-plans，不覆盖旧报告。两份evidence-manifest.json保存各流source_size、每局计数、坏行计数与产物SHA；每条引用保存原行offset/bytes/SHA。verify_evidence.py对全部6995条逐字节seek核SHA、JSON一致性、显式归局身份；状态行另核SILENT/A10。验证日志verification.log退出0，属原件核验，未调用生产模拟或测试。

| 局号 | states | decisions | sl-attempts | run-config | run-plans | brain | runs | fight-plans |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 729 | 699 | 2 | 1 | 8 | 46 | 1 | 0 |
| 8JRE1C4H4Z2W | 676 | 659 | 7 | 1 | 6 | 31 | 1 | 0 |
| CA5KE8GFJ9X2 | 282 | 265 | 0 | 1 | 2 | 11 | 1 | 0 |
| 5PM6JAQG6FNQ | 660 | 638 | 7 | 1 | 7 | 39 | 1 | 0 |
| 61E2QS63Y9WU | 462 | 443 | 7 | 1 | 4 | 27 | 1 | 0 |
| DUZUBAJ3A8GP | 623 | 602 | 6 | 1 | 6 | 29 | 1 | 0 |

states/decisions/brain各2条坏行是各全源扫描计数，没有归因给本批；fight-plans在本次2233957字节截点选中0，仅说明该截点没有本批显式身份，不能称日志缺失。各流独立冻结，不冒称单一原子全日志截点。

有界事实934帧在bounded-state-facts.json；首末端点在turn-endpoints.json，首捕获帧不自动当作完成过回血后的进场，末帧也不自动等于完整敌回合结算。神化9项确定性事实断言、另4项蚌/族母/胧光/甲虫断言、沙虫同指纹实付差额分别保存在fact-checks.json、additional-fact-checks.json、sl-matched-fingerprint-proof.json。它们是材料核验，不是生产固定用例，不计cases。

关键结论：VLZ F43同后序列43伤/14损→51伤/13损，F45神化未兑现；8JRE F33首/三试T2同指纹，实损3/15且净扣10/17；61E F23T4净扣47仍留2血幻象，未选focus不能补成胜线；5PM F39末试T2冒泡耗1能而零效果，不能用异场F33胜拟启动权重；DUZU F30临时减力后甲虫恢复并成长。这些均旧局复核，不增加独立局数、support/repeat或经验支持分母。

## 十项处置

| ID | 原账本 | 本次waiting具体理由 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | silent-0237, silent-0238 | 已有神化同线和牌堆升级；缺跨抽牌、重规划、SL与换战的实际施放归属及完整消费者校准，原提案尚未闭环。 |
| silent-proposal-f2bfceddb1898dca | silent-0106, silent-0019, silent-0201 | 缺同起点、同随机池、同总预算的配对实验及稳定性曲线；707ms与第二问来自不同盘面，不能据此修改预算或留药规则。 |
| silent-proposal-283a164780d11e69 | silent-0237, silent-0238 | 与原神化提案共享实盘证据，但实际施放及后继消费链未闭环；不能凭同主题和局部实现登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019 | 十五子项尚缺按来源、期限、属性组合冻结的战斗/路线/休息联合生产校准；局部正确公式不能代替完整实现证明。 |
| silent-proposal-e5b87be50f28f311 | silent-0079, silent-0021, silent-0125, silent-0018 | 已有候选和单动作派发审计；缺跨抽牌、选择、用药、重规划与SL的整线执行及能力实际建立认证。 |
| silent-proposal-49632bc4878fb597 | silent-0005, silent-0231 | 本局未建立正敏捷；缺力量逐击、正负敏捷、虚弱及独立成长的联合生产校准，不能新增统一保血或输出权重。 |
| silent-proposal-66532328a585941f | silent-0021, silent-0009 | F33与F39起始资源、敌人和抽序不同；缺同起点同抽序的不同启动顺序整战对照及可复现收益函数。 |
| silent-proposal-43a76a31ba7bdcfa | silent-0030, silent-0027 | F17只有首试获胜；缺同起始HP、构筑及完整抽序的另一完整SL线路，不能修改SL范围或换线偏好。 |
| silent-proposal-5264153a4a4b0e5c | silent-0039, silent-0209 | 已有召唤子实现；缺A10召唤、航行双方成长、幻象复现与退场的生产全链校准及另一focus完整后继。 |
| silent-proposal-bddfa690a84e03d0 | silent-0128, silent-0079 | 四试均败；缺伤害唤醒、睡眠/眩晕接续与当前进阶成长的生产全链校准，以及同抽换序完整后继。 |

完整支持、反例、旧/预期行为、校准方法、回退及来源经验在proposal.md逐项列出。未新建重复ID或重写历史复盘。没有把宽项证据不充分强行解释成原机制反证；当前无新机制异议需要伪造通知或其他角色ACK。

## 实际源码边界

只读观测live：`49bec5ed231e34eb4b63cd3519972ec6f72f8320`。source-pins.json及source-pins/*.txt保存本基线/该live提交的固定Git源码字节、SHA和末次源码祖先；所有列出的祖先关系核真。此处仅证明源文件存在，不表示整提案已实现，更不代表自然消费者已采用。

| 文件 | 该live文件末次源码祖先 | 与本base字节相同 |
|---|---|---|
| agent/src/reflex/silent-apotheosis.ts | `ba23ca693151fa8c6f7fe035e640dc30f05ccd75` | True |
| agent/src/reflex/silent-apotheosis-reference.ts | `3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17` | True |
| agent/src/reflex/card-model.ts | `649f820249874f42d6035091ed8de2e709ebb8da` | False |
| agent/src/reflex/turn-solver.ts | `d959e176af7338ea2bca6f4ff9a39673b80e5fdf` | True |
| agent/src/reflex/rollout.ts | `e2b0ea2cfdccba26e917bb72728f65049158fe4a` | False |
| agent/src/reflex/combat-plan.ts | `d959e176af7338ea2bca6f4ff9a39673b80e5fdf` | True |
| agent/src/reflex/silent-selection-audit.ts | `05cd292c6f01bb31e406473d3a9843e659d62b93` | True |
| agent/src/reflex/silent-selection-dispatch.ts | `bade647f9fe4c9103b40e2f26b26296692ad24b7` | True |
| agent/src/reflex/silent-hp-guard-audit.ts | `a8b1f8be153fe4f3a34146117546c2178f2e446b` | True |
| agent/src/knowledge/monster-db.ts | `4ed3c72df30f27b881da637aebf528b97440e0bb` | True |
| agent/src/sl/judge.ts | `5af09cc39200e45a34e8cd5f73e4e5fa06546a82` | False |
| agent/src/sl/explore.ts | `0d092f6b928a6221eabf3516abad25c48ceaac9c` | False |
| agent/tests/silent-apotheosis.test.ts | `f516592fff557ef02c8ece43433706358c3f7fe6` | True |
| agent/tests/silent-selection-audit.test.ts | `3dab44240bb426b6e9452de4277a35d38bbfe83e` | True |
| agent/tests/silent-selection-dispatch.test.ts | `bade647f9fe4c9103b40e2f26b26296692ad24b7` | True |
| agent/tests/silent-obscura-summon.test.ts | `1e076b173c6874cef4bf90fd13cd3eb33355827a` | True |
| agent/tests/silent-sl-beetle.test.ts | `a8b1f8be153fe4f3a34146117546c2178f2e446b` | True |
| agent/src/hand/loop.ts | `ef092f1c9189bdbb549e46fd604eb342cb025bdf` | True |

神化配对源ba23ca693151fa8c6f7fe035e640dc30f05ccd75及reference源3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17已在上述live；reference仍actual_cast_this_fight=null。selection源05cd292c6f01bb31e406473d3a9843e659d62b93、派发源bade647f9fe4c9103b40e2f26b26296692ad24b7仅认证候选/单动作，actual_turn/whole_plan_executed仍null。召唤测试与甲虫窄SL测试只覆盖各自边界，未运行或冒称本批A10全链认证。

四文件与live字节有差：card-model、judge、explore含既有署名注释差，rollout另有本批范围以外的Queen成长后续补丁；不覆盖、不复制、不把差异当整仓等价。航行调查只读到实盘双方成长与enemyTable动态生成路径，未冻结当前完整表及生产后继，不凭没有SAIL_MOVE字面报新bug或加通用友方成长常量。

## 记录、验证和交付限制

账本只通过根learner/ledger.py update追加本批proposal/report链接与处置说明，by=learner:strategy-proposal，不改claim、首证、先验、evidence、status、version或effect，不标shipped。原提案CLI ID沿用；队列最终状态由本批proposal_results交原调度器处理，没有手改专用队列。根台账回执与前后投影检查另存ledger-update.*及ledger-preservation.json。

源码撤掉失败/恢复通过：不适用，无新源码。tsc/vitest/cases均null，未运行测试，不借旧绿或把原件核验退出0填为测试成功。未执行live锁、刷新知识提交、合并、eval登记、双通知或推送；无对局、LLM或网络调用。铁甲及其他角色行为无改动。

过程中的错误保留：初次源码探针误写agent/src/loop.ts，实际为agent/src/hand/loop.ts，已补固定；调查中曾按猜测路径读取不存在的power-gains.json/power-gains.ts，返回不存在，未读其他角色或据此判断证据缺失。初稿verify_evidence.py在运行前修正抽取模块相对路径；首次实际原件核验退出0。大输出显示截断仅为展示，原Markdown及原件仍完整保存。没有这些错误对应的产品代码失败/回滚或测试成功。

未实现原因来自上表逐项边界，所需数据包括固定生产输入/消费者全链、同盘预算配对、同抽完整后继或后移独立局；不能仅重读旧局或扩大统一阈值补齐。fixes=[]、merged=null，report.base为完整40位提交，tracked工作树保持干净，过程产物仅在本批learner/runs目录。

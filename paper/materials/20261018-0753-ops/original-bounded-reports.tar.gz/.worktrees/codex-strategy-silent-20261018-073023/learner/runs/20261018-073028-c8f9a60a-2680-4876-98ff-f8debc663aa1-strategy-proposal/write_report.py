import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '--iso-8601=seconds']).decode().strip()
print(stamp)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
items = json.loads((OUT / 'assigned-proposals.json').read_text())
pins = json.loads((OUT / 'source-pins.json').read_text())
verified = json.loads((OUT / 'evidence-verification.json').read_text())
ledger = json.loads((OUT / 'ledger-before.json').read_text())
base = pins['base']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == base
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()

reasons = [
    '已有神化同线和牌堆升级；缺跨抽牌、重规划、SL与换战的实际施放归属及完整消费者校准，原提案尚未闭环。',
    '缺同起点、同随机池、同总预算的配对实验及稳定性曲线；707ms与第二问来自不同盘面，不能据此修改预算或留药规则。',
    '与原神化提案共享实盘证据，但实际施放及后继消费链未闭环；不能凭同主题和局部实现登记duplicate。',
    '十五子项尚缺按来源、期限、属性组合冻结的战斗/路线/休息联合生产校准；局部正确公式不能代替完整实现证明。',
    '已有候选和单动作派发审计；缺跨抽牌、选择、用药、重规划与SL的整线执行及能力实际建立认证。',
    '本局未建立正敏捷；缺力量逐击、正负敏捷、虚弱及独立成长的联合生产校准，不能新增统一保血或输出权重。',
    'F33与F39起始资源、敌人和抽序不同；缺同起点同抽序的不同启动顺序整战对照及可复现收益函数。',
    'F17只有首试获胜；缺同起始HP、构筑及完整抽序的另一完整SL线路，不能修改SL范围或换线偏好。',
    '已有召唤子实现；缺A10召唤、航行双方成长、幻象复现与退场的生产全链校准及另一focus完整后继。',
    '四试均败；缺伤害唤醒、睡眠/眩晕接续与当前进阶成长的生产全链校准，以及同抽换序完整后继。',
]
findings = [
    ('VLZ6CCT8AQ0A，F35/T1、F36/T2、F43/T1—2、F45/T1',
     'states275564→275565核实7→5能、防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费；275604→275605核实后抽致命毒药7毒、1费且无直接扣血；275679/275687场外升级数均4。decisions269706/269707同后续牌序43伤/14损→51伤/13损。',
     'F45的275731→275732神化从剩余手牌消失，勒紧仍4、触媒仍1；不能把持有当施放。当前reference.actual_cast_this_fight仍null，未知后续抽牌仍保留缺口。',
     '先维持已有配对升级，不新设神化必打或固定分。复验实际施放、重复升级、未知牌和跨战重置；补连续执行身份后再验收原宽项。'),
    ('VLZ6CCT8AQ0A，F43/T1、F45/T1和T4—5',
     'decisions269748的mc_ms=707、rollout horizon1/samples1/best=null；269754的mc_ms=11、rollout horizon5/samples3。269770保存少损线13损/24伤与攻击候选31损/32伤。',
     '269748与269754之间已出牌、盘面指纹不同；并非同盘预算试验。F43较成熟推演也未建立整战胜率保证。',
     '保留原预算、护栏、药水持有和目标规则。下一步需冻结状态、知识、种子池、时限与宿主条件，配对比较分阶段MC和现有分配；不把best=null一律解释为并列或失败。'),
    ('VLZ6CCT8AQ0A，F35/T1、F43/T1—2、F45/T1',
     '与89354805ee4d7e77共用已核神化帧，经验链接silent-apotheosis-combat-upgrades；两份原Markdown字节指纹分别保存。',
     '经验链与代码链职责不同；同一组帧和同一窄升级实现不足证明整项已在实际消费者闭环。',
     '沿用同一实现方向并保留此原ID，不新建重复提案；实际施放和重规划链完整后再核是否可按live祖先登记duplicate。'),
    ('VLZ6CCT8AQ0A，F43/T1—5、F44、F45/T1—5',
     '已核F45T2→3口红力量1→2、敏捷0→1，普通勒紧4与升级6分列；原提案覆盖15条机制/资源经验，关联14个账本ID，完整清单沿原文。',
     '当前覆甲不是开场覆甲，单轮减力不是关闭成长，候选成长不是已建立成长。F43赢而损57、F44回血后仍败，不能拟合休息安全线。',
     '按每个来源、作用对象、持续期限逐步校准，再核Jev、路线及休息消费者；神化交其原提案，未证实新偏差前保持行为。'),
    ('8JRE1C4H4Z2W，F33首/三试T2、二试T5、末试T11，F17/T6',
     'decisions270216/270282指纹逐字相同；对应states276208→276212、276274→276278分别实损3/15、净扣10/17。270264保留Jev原答及HP护栏候选；末试与其他SL尝试均属于同一局。',
     '多12血仅多7伤没有整场胜线；末试防御换线省血并延后死亡，反对一律攻击或一律防守。单动作returned/stable不认证整候选执行。',
     '保留探索和HP护栏，补整线重规划边界及能力建立的证据认证，不预支未结毒。当前selection_audit.actual_turn与selection_dispatch.whole_plan_executed仍null。'),
    ('CA5KE8GFJ9X2，F13/T1、T3、T5',
     'states273252与273263敌力量4/8；原帧喷水11→15→19、虚弱后11/14。关键战未建立正敏捷，计划中的步法不能补为事实。',
     '弱未取消后续成长，末轮实损按剩余2血截断，完整需损4；不能将死亡截断当模型只需2伤。',
     '只检验现有属性路径；需要当前进阶敌表、每击力量、正负敏捷、虚弱及成长的完整固定生产输入，才可关闭复合经验。'),
    ('5PM6JAQG6FNQ，F33、F38/T3、F39末试T2',
     'states274379→274380冒泡后能量5→4，失落35HP、遗忘72HP均不变且均无毒；F33建立过毒雾/触媒后胜，F39末试未建立毒雾。',
     'F33与F39不是同敌同资源对照；冒泡零效果只说明现场条件，没有给出构筑或启动的收益函数。',
     '维持持有/计划/已建立分账，不新设启动阈值；若改权重，须同起始HP、构筑、资源和完整抽序对照不同启动顺序。'),
    ('61E2QS63Y9WU，F17/T5—7',
     'states273503→273504确认玩家力量2归零、敏捷−2、敌力量2；T6双防御共6与毒连续结算分列，F17首试获胜。',
     '首试胜利不提供另一SL线路；本局F28读档发生在另一战，不能挪作族母同盘胜线。',
     '保留SL范围和换线偏好；先复核吸取、负敏捷和毒的固定生产调用，再以完整同盘另一线路评价SL规则。'),
    ('61E2QS63Y9WU，F23/T1—5',
     'states273588→273589与273595→273596，两次航行后本体/幻象力量均0→3→6；本体maxHP129、幻象21。273593→273596本轮实损15、净扣47，幻象仍2HP；另一39伤/0损focus未实打。',
     '不能由未选线推出整战可胜，也不能仅因源码没有SAIL_MOVE字面就断言遗漏；enemyTable由角色数据生成，须联同冻结表、动作来源和复现/退场规则校准。',
     '保留全部目标及并列。现有summonsAt/boardRolloutInput与幻象SL窄实现不关闭A10全链；需精确冻结运行表并逐步检查双方成长及死亡/复现时点。'),
    ('DUZUBAJ3A8GP，F30四试，末试T4—6',
     'states275007甲虫已无覆甲；275017尖啸下力量−4，275018恢复并成长至4。末试T4本体同起点换线比首试多扣3而多损2，四试均败。',
     '只看到自然睡层/恢复成长不能补齐所有伤害唤醒与眩晕交互；其他静默窄SL判死测试不证明本项睡眠全链或固定杀序收益。',
     '保持现有判死与目标规则；先按A10冻结每步睡层/眩晕/攻击及成长，然后核同抽换序后继，不用全死候选拟合输出血价。'),
]
assert len(items) == len(reasons) == len(findings) == 10
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(items, reasons)]

header = f'''# 静默猎手十项已领取策略提案复核

记录时间：{stamp}。批次：20261018-073023-strategy-proposal。
基线及最终HEAD：`{base}`；实际merge main返回Already up to date。开工和报告生成前tracked工作树均干净。

本批为普通提案消费，不带research_request、implementation_request或proposal_repair；角色、工作树、六锚点与十个proposal_ids已核。根普通专题请求绑定20261010-150327，与本批不匹配，不承接、不读取另一专题正文、不扩展提案队列。没有承诺的代码变更或额外架构调整。

本轮全部十项保留waiting；没有发现足以安全新增规则的、经当前生产输入校准确认的新偏差。没有将旧窄实现冒记为宽项implemented/duplicate；也没有把未执行候选当胜线、把SL当新局或重读旧局当新增support。

各原提案原文、CLI ID、账本与SHA均保存；以下分别列出证据、反例、预期行为及验证方法。来源任务和经验链接沿assigned-proposals.json及各original.md保留，目标任务均为strategy-proposal。适用仅本次六局的silent A10，不外推其他角色/未观察进阶。
'''
sections = []
for p, reason, (where, support, limits, nextstep) in zip(items, reasons, findings):
    sections.append(f'''\n## {p['id']}

原提案：{p['summary']}
账本：{', '.join(p['ledger'])}；来源：{p['source_task']}。证据局号/层/回合：{where}。

支持：{support}

反例与未知：{limits}

旧/预期行为与验证：{nextstep}

处置：waiting。{reason} 本轮不拟合新参数；上述六旧局为发现/回归材料，不称独立时间后移验证。若以后实现，须固定输入、撤生产源码失败/恢复通过及原沙箱检查；回退对应独立源码提交，保留原始证据和失败史。
''')
(OUT / 'proposal.md').write_text(header + ''.join(sections))

counts = []
for run in dispatch['runs']:
    values = {m['stream']: m['counts'][run] for m in verified['streams']}
    counts.append('| ' + run + ' | ' + ' | '.join(str(values[s]) for s in ['states','decisions','sl-attempts','run-config','run-plans','brain','runs','fight-plans']) + ' |')
proof_rows = '\n'.join('| '+p['id']+' | '+', '.join(p['ledger'])+' | '+reason+' |' for p,reason in zip(items,reasons))
source_rows = '\n'.join('| '+r['path']+' | `'+r['last_live_source_commit']+'` | '+str(r['equal'])+' |' for r in pins['files'])
report = f'''# 静默猎手策略批次回报

时间：{stamp}。本批已逐项复核十个领取提案，全部waiting，保留具体缺证理由。无源码/知识/任务模板改动，无提交、合入、发布号或shipped；不关闭其他研究父要求。

任务：strategy-proposal；角色：silent；批次：20261018-073023-strategy-proposal。
base/最终HEAD：`{base}`。
报告：{OUT / 'report.md'}
提案：{OUT / 'proposal.md'}

## 身份与范围

开工git status干净；git merge --no-edit main为Already up to date。dispatch.json为本次learn.json唯一对应行，十ID与工作树角色精确匹配。没有research_request或implementation_request；普通专题根请求绑定旧批，不适用于本批。没有合入后续main、改请求/learn.json、领取其他提案或派下级。六局runs.jsonl均SILENT A10；没有使用其他角色私有知识或预训练游戏结论。

## 原始证据与材料核验

按任务共用extract_evidence.py入口提取默认六流，并以独立evidence-extra目录提取runs/fight-plans，不覆盖旧报告。两份evidence-manifest.json保存各流source_size、每局计数、坏行计数与产物SHA；每条引用保存原行offset/bytes/SHA。verify_evidence.py对全部6995条逐字节seek核SHA、JSON一致性、显式归局身份；状态行另核SILENT/A10。验证日志verification.log退出0，属原件核验，未调用生产模拟或测试。

| 局号 | states | decisions | sl-attempts | run-config | run-plans | brain | runs | fight-plans |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(counts)}

states/decisions/brain各2条坏行是各全源扫描计数，没有归因给本批；fight-plans在本次2233957字节截点选中0，仅说明该截点没有本批显式身份，不能称日志缺失。各流独立冻结，不冒称单一原子全日志截点。

有界事实934帧在bounded-state-facts.json；首末端点在turn-endpoints.json，首捕获帧不自动当作完成过回血后的进场，末帧也不自动等于完整敌回合结算。神化9项确定性事实断言、另4项蚌/族母/胧光/甲虫断言、沙虫同指纹实付差额分别保存在fact-checks.json、additional-fact-checks.json、sl-matched-fingerprint-proof.json。它们是材料核验，不是生产固定用例，不计cases。

关键结论：VLZ F43同后序列43伤/14损→51伤/13损，F45神化未兑现；8JRE F33首/三试T2同指纹，实损3/15且净扣10/17；61E F23T4净扣47仍留2血幻象，未选focus不能补成胜线；5PM F39末试T2冒泡耗1能而零效果，不能用异场F33胜拟启动权重；DUZU F30临时减力后甲虫恢复并成长。这些均旧局复核，不增加独立局数、support/repeat或经验支持分母。

## 十项处置

| ID | 原账本 | 本次waiting具体理由 |
|---|---|---|
{proof_rows}

完整支持、反例、旧/预期行为、校准方法、回退及来源经验在proposal.md逐项列出。未新建重复ID或重写历史复盘。没有把宽项证据不充分强行解释成原机制反证；当前无新机制异议需要伪造通知或其他角色ACK。

## 实际源码边界

只读观测live：`{pins['observed_live']}`。source-pins.json及source-pins/*.txt保存本基线/该live提交的固定Git源码字节、SHA和末次源码祖先；所有列出的祖先关系核真。此处仅证明源文件存在，不表示整提案已实现，更不代表自然消费者已采用。

| 文件 | 该live文件末次源码祖先 | 与本base字节相同 |
|---|---|---|
{source_rows}

神化配对源ba23ca693151fa8c6f7fe035e640dc30f05ccd75及reference源3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17已在上述live；reference仍actual_cast_this_fight=null。selection源05cd292c6f01bb31e406473d3a9843e659d62b93、派发源bade647f9fe4c9103b40e2f26b26296692ad24b7仅认证候选/单动作，actual_turn/whole_plan_executed仍null。召唤测试与甲虫窄SL测试只覆盖各自边界，未运行或冒称本批A10全链认证。

四文件与live字节有差：card-model、judge、explore含既有署名注释差，rollout另有本批范围以外的Queen成长后续补丁；不覆盖、不复制、不把差异当整仓等价。航行调查只读到实盘双方成长与enemyTable动态生成路径，未冻结当前完整表及生产后继，不凭没有SAIL_MOVE字面报新bug或加通用友方成长常量。

## 记录、验证和交付限制

账本只通过根learner/ledger.py update追加本批proposal/report链接与处置说明，by=learner:strategy-proposal，不改claim、首证、先验、evidence、status、version或effect，不标shipped。原提案CLI ID沿用；队列最终状态由本批proposal_results交原调度器处理，没有手改专用队列。根台账回执与前后投影检查另存ledger-update.*及ledger-preservation.json。

源码撤掉失败/恢复通过：不适用，无新源码。tsc/vitest/cases均null，未运行测试，不借旧绿或把原件核验退出0填为测试成功。未执行live锁、刷新知识提交、合并、eval登记、双通知或推送；无对局、LLM或网络调用。铁甲及其他角色行为无改动。

过程中的错误保留：初次源码探针误写agent/src/loop.ts，实际为agent/src/hand/loop.ts，已补固定；调查中曾按猜测路径读取不存在的power-gains.json/power-gains.ts，返回不存在，未读其他角色或据此判断证据缺失。初稿verify_evidence.py在运行前修正抽取模块相对路径；首次实际原件核验退出0。大输出显示截断仅为展示，原Markdown及原件仍完整保存。没有这些错误对应的产品代码失败/回滚或测试成功。

未实现原因来自上表逐项边界，所需数据包括固定生产输入/消费者全链、同盘预算配对、同抽完整后继或后移独立局；不能仅重读旧局或扩大统一阈值补齐。fixes=[]、merged=null，report.base为完整40位提交，tracked工作树保持干净，过程产物仅在本批learner/runs目录。
'''
(OUT / 'report.md').write_text(report)
result = {'task':'strategy-proposal','character':'silent','batch':'20261018-073023-strategy-proposal',
          'base':base,'runs':dispatch['runs'],'fixes':[],'skipped':[],'merged':None,
          'tests':{'tsc':None,'vitest':None,'cases':None},
          'code_proposals':[p['id'] for p in items],'implementation_domains':[],
          'proposal_results':results,'report':str(OUT/'report.md')}
(OUT / 'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
updates=[]
for ident in sorted(ledger):
    related=[r['id'] for p,r in zip(items,results) if ident in p['ledger']]
    updates.append({'id':ident,'by':'learner:strategy-proposal','where':{'proposal':[str(OUT/'proposal.md'),str(OUT/'report.md')]},
                    'note':'本批20261018-073023-strategy-proposal复核：'+', '.join(related)+'均waiting；6995原始引用核验，具体缺数据见本批report/proposal。无源码、合入、版本或测试；不新增支持/重犯/独立局，保留原条目状态及证据。'})
(OUT / 'ledger-update.jsonl').write_text(''.join(json.dumps(u,ensure_ascii=False)+'\n' for u in updates))
print(json.dumps({'report':str(OUT/'report.md'),'proposal':str(OUT/'proposal.md'),'waiting':len(results),'ledger_links':len(updates)},ensure_ascii=False))

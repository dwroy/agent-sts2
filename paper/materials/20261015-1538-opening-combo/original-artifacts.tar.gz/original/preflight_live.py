import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
WORKTREE = OUT.parents[2]
assert (OUT / 'sandbox-before-commit-retry.exit').read_text().strip() == '0'

def git(*args, cwd=LIVE):
    return subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True)

source = git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip()
assert source != '2427a8c58a64cd5ab1842dc0b339d2a50805f191'
result = {'source': source, 'state': 'checking', 'merged': None, 'refresh_commit': None}
result['status_before'] = git('status', '--short', '--untracked-files=no').stdout
staged = git('diff', '--cached', '--name-only').stdout.splitlines()
if staged:
    result.update(state='blocked_staged_changes', staged=staged)
else:
    added = git('add', 'notes/fight-value-backtest.md', 'knowledge')
    assert added.returncode == 0, added.stderr
    refreshed = git('diff', '--cached', '--name-only').stdout.splitlines()
    result['refresh_paths'] = refreshed
    if refreshed:
        with (OUT / 'gitleaks-refresh.log').open('w') as log:
            scan = subprocess.run(['nice', '-n', '10', 'gitleaks', 'git', '--staged', '--pre-commit', '--redact', '--no-banner', '--no-color'], cwd=LIVE, stdout=log, stderr=subprocess.STDOUT)
        assert scan.returncode == 0
        committed = git('commit', '-m', 'Refresh knowledge data', '-m', 'Co-Authored-By: Codex GPT-6.1-Sol <noreply@openai.com>')
        (OUT / 'live-refresh-commit.log').write_text(committed.stdout + committed.stderr)
        assert committed.returncode == 0
        result['refresh_commit'] = git('rev-parse', 'HEAD').stdout.strip()
    before = git('rev-parse', 'HEAD').stdout.strip()
    result['live_before'] = before
    common = git('merge-base', before, source).stdout.strip()
    branch_paths = git('diff', '--name-only', common, source).stdout.splitlines()
    live_paths = git('diff', '--name-only', common, before).stdout.splitlines()
    result['knowledge_overlap'] = sorted(p for p in set(branch_paths) & set(live_paths) if p.startswith('knowledge/') or p == 'notes/fight-value-backtest.md')
    check = git('merge-tree', '--write-tree', '--name-only', before, source)
    (OUT / 'live-merge-tree.log').write_text(check.stdout + check.stderr)
    result['preflight_exit'] = check.returncode
    result['state'] = 'ready' if check.returncode == 0 else 'conflict' if check.returncode == 1 else 'preflight_error'
    if check.returncode == 1:
        result['conflicts'] = check.stdout.split('\n\n', 1)[0].splitlines()[1:]
    result['live_after'] = git('rev-parse', 'HEAD').stdout.strip()
    assert result['live_after'] == before
    result['status_after'] = git('status', '--short', '--untracked-files=no').stdout
    result['actual_merge_attempted'] = False
(OUT / 'live-preflight.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

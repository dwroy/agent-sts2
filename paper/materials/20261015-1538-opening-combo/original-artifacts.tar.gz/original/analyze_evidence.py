import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('extract_evidence', OUT.parents[1] / 'extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
verification = []
for entry in manifest:
    path = OUT / 'evidence' / (entry['stream'] + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
    rows = [json.loads(line) for line in path.open()]
    counts = Counter()
    with (Path('/home/dw/Projects/agent-sts2/logs') / (entry['stream'] + '.jsonl')).open('rb') as source:
        for row in rows:
            source.seek(row['offset'])
            raw = source.read(row['bytes'])
            assert row['offset'] + row['bytes'] <= entry['source_size']
            assert hashlib.sha256(raw).hexdigest() == row['sha256']
            assert json.loads(raw) == row['row']
            assert extractor.run_identity(row['row']) == row['run_id']
            counts[row['run_id']] += 1
    assert {run: counts[run] for run in entry['counts']} == entry['counts']
    streams[entry['stream']] = rows
    verification.append({'stream': entry['stream'], 'rows': len(rows), 'source_size': entry['source_size'], 'verified': True})

state_rows = {x['line']: x for x in streams['states']}
states = {line: row['row']['state'] for line, row in state_rows.items()}
checks = []
def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})

def hp(line): return states[line]['run']['current_hp']
def player(line): return states[line]['combat']['player']
def enemy(line, index=0): return states[line]['combat']['enemies'][index]
def amount(obj, power): return next((p['amount'] for p in obj['powers'] if p['power_id'] == power), 0)
def enemy_hp(line): return enemy(line)['current_hp']

for row in streams['runs']:
    check(row['run_id'] + ':角色', row['row']['character'], 'SILENT')
    check(row['run_id'] + ':进阶', row['row']['ascension'], 10)
check('AD3结束层', next(x['row']['floor'] for x in streams['runs'] if x['run_id'] == 'AD3QSC3P41JU'), 49)
check('9DAS结束层', next(x['row']['floor'] for x in streams['runs'] if x['run_id'] == '9DAS5L8YM1CN'), 23)

openings = []
for before, after in [(299341,299342),(299374,299375),(299391,299392),(299449,299450),(299495,299496)]:
    check(f'开场{before}血价', hp(before) - hp(after), 4)
    check(f'开场{before}未出牌', [player(before)['cards_played_this_turn'], player(after)['cards_played_this_turn']], [0,0])
    check(f'开场{before}无小血瓶', any(r['relic_id'] == 'BLOOD_VIAL' for r in states[before]['run']['relics']), False)
    openings.append({'floor': states[before]['run']['floor'], 'turn': 1, 'before_hp': hp(before), 'after_hp': hp(after),
                     'evidence': [{k: state_rows[line][k] for k in ['line','offset','bytes','sha256']} for line in [before,after]]})

check('连续Boss实际出口入房可操作', [hp(299494),hp(299495),hp(299496)], [15,15,11])
check('F21紧勒逐牌血量', [enemy_hp(n) for n in [299864,299865,299866,299867,299868]], [84,60,60,58,56])
check('F21紧勒轮末撤', amount(enemy(299871), 'STRANGLE_POWER'), 0)
check('F22紧勒逐牌血量', [enemy_hp(n) for n in [299913,299914,299915,299916,299917]], [38,32,32,30,26])
check('F22紧勒轮末撤', amount(enemy(299918), 'STRANGLE_POWER'), 0)
check('狡诈手位', [len(states[n]['combat']['hand']) for n in [299905,299906]], [4,7])
check('狡诈能量HP', [(player(n)['energy'],hp(n)) for n in [299905,299906]], [(2,2),(2,2)])
check('狡诈生成升级刀', [(c['card_id'],c['upgraded']) for c in states[299906]['combat']['hand'] if c['card_id']=='SHIV'], [('SHIV',True)]*3)
check('三刀实际血量', [enemy_hp(n) for n in [299909,299910,299911,299912]], [31,25,19,13])
check('冒泡已毒目标', [amount(enemy(n),'POISON_POWER') for n in [299907,299908]], [6,15])
check('开信刀群伤', [[e['current_hp'] for e in states[n]['combat']['enemies']] for n in [299908,299909]], [[36,43],[31,38]])
check('实验体末轮技能激怒', [amount(enemy(n),'STRENGTH_POWER') for n in [299559,299560,299561,299562,299563]], [3,6,9,12,15])
check('实验体末轮未结毒不当伤', [(enemy_hp(n),amount(enemy(n),'POISON_POWER')) for n in [299558,299559]], [(72,3),(72,6)])
check('实验体末轮血挡来袭', [hp(299564),player(299564)['block'],enemy(299564)['intents'][0]['total_damage']], [3,18,23])
check('实验体实际致死后剩血', [hp(299565),enemy_hp(299565)], [0,58])
check('速度药未触发柔嫩', [amount(player(299959),'DEXTERITY_POWER'),amount(player(299959),'STRENGTH_POWER')], [5,0])
check('柔嫩末轮逐牌敏捷', [amount(player(n),'DEXTERITY_POWER') for n in [299960,299961,299962,299963]], [4,3,2,1])
check('猎人末轮血挡来袭', [hp(299963),player(299963)['block'],enemy(299963)['intents'][0]['total_damage']], [2,12,14])
check('猎人末轮实际死亡', [hp(299964),enemy_hp(299964)], [0,81])

brain = {}
for run in ['AD3QSC3P41JU','9DAS5L8YM1CN']:
    records = [x['row'] for x in streams['brain'] if x['run_id'] == run]
    brain[run] = {'count': len(records), 'engines': dict(Counter(x['engine'] for x in records)),
                  'accepted': sum(x.get('accepted') is True for x in records), 'models': dict(Counter(x['model'] for x in records))}
    check(run + ':实脑引擎', set(x['engine'] for x in records) == {'codex'}, True)

data = {'verification': verification, 'verified_rows': sum(x['rows'] for x in verification), 'checks': checks,
        'fact_checks': len(checks), 'openings': openings, 'brain': brain,
        'limitations': ['两局均为历史dirty执行树，完整运行源码及当时知识未恢复；当前源码不冒认历史dirty树。',
                        '本局多次SL共享局与房间，不当作独立局；判死截断不等实际死亡。',
                        'fight-plans在本次source_size截点选到0行，不能据此断言原日志缺失。',
                        '开场4血的局部核验不拟合药水持有价、SL或终局权重，不证明通关收益。']}
(OUT / 'evidence-validation.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verified_rows': data['verified_rows'], 'fact_checks': len(checks), 'brain': brain},ensure_ascii=False))

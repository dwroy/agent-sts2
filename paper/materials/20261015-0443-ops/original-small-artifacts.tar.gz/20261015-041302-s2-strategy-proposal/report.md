# 静默猎手策略提案批次报告

本批 20261015-041302-s2-strategy-proposal 已逐项处理十个领取ID，结论为十项 waiting。没有新的、证据充分且尚未实现的策略改动被定位；现有窄子实现不等于原宽提案完成。没有改源码、知识、任务模板、版本或共享记录；没有新提交、合入或上线声明。

核对时间 2026-10-15T04:26:24+08:00，记录前已 date。base/HEAD 为 d76045fd28e66c4fae3692ca09410b01e4028a06。开工工作树干净；本批没有研究/实现请求绑定；普通流程 git merge --no-edit main 返回 Already up to date。未读取另一专题正文或其他角色经验，未派下级 agent，未运行 play/联网/读凭据。

## 派发与原件

learn.json 本批 task=strategy-proposal、character=silent、reason=proposal、state=running，worktree 与任务路径一致；proposal_ids 为原十项，未领取其他项。根 notes/strategy-research-silent.json 绑定另一个旧批，不满足专题条件，本批保留原提案任务。

原十份提案的 Markdown SHA 均与专用队列 add 行相同；31个关联账本ID只读保存，没有新增重复ID或改旧状态。完整提案、局/层/回合、账本、反例、预期行为、缺口和验证方法见 [proposal.md](proposal.md)。

## 原始证据

四局 runs.jsonl 全部 character=SILENT、ascension=10，均非胜局：7X0止F31，MTQ0止F23，KFR止F33，GXN止F45。只按明确run/run_id/state.run_id/fingerprint.run识别归属，不凭正文提及收行；所选行均无冲突身份。

| 流 | MTQ0EUBJ3R6T | 7X0W3U8TVA2A | KFRDELW2TH2P | GXNKW8X1XYJP |
|---|---:|---:|---:|---:|
| states | 440 | 461 | 620 | 673 |
| decisions | 424 | 445 | 587 | 649 |
| sl-attempts | 5 | 1 | 8 | 7 |
| run-config | 1 | 1 | 1 | 1 |
| run-plans | 4 | 4 | 6 | 10 |
| brain | 23 | 31 | 35 | 48 |
| runs | 1 | 1 | 1 | 1 |
| fight-plans | 0 | 0 | 0 | 0 |

共4,489条，按offset/bytes/SHA逐字节复核原日志全部通过，accepted角色也逐行核。各流原字节截点和输出SHA见 evidence/evidence-manifest.json；原日志扫描开始时冻结截点，后续追加不混入。states/decisions全流各有2条无效JSON、brain全流1条；未归属这些无效行到四局，也不据此断言四局缺证。fight-plans零行仅为该截点选取结果，不断言历史日志不存在。

35项数字检查通过，保存 numeric-checks.json；14条关键决策保存 candidate-action-chain.json；24组层边界保存 resource-boundaries.json，另存七次敌段HP回添与GXN逐槽变化。

关键限定：MTQ0 F11T1 d282139弃了原护栏续步的连续反弹，d282140随后重新选择迷雾，d282141执行中和+。实际整轮净扣敌20/失血6不是完整原护栏16伤线的同输入实打，因此不能将“候选省8血”改写成受控实省8血，也不能由20对16新增模型bug。此限定与原提案要求的重问/执行分列一致。

KFR F33同T6两条实线入口15血/敌228/36毒/3覆甲，分别损6/12、扣83/93；六次毒药均当步加6且敌本体HP不变，末159→74与玩家归零并存。GXN同T2后实到3/13HP与0/7挡，末13+23+2仍不足40；没有新胜利反事实，不修改护栏、SL、药价或终局权重。

7X0 F31初始血池150，已观察七次回添25合175，GAME_OVER帧三段4/25/18合47，总净扣278；不能漏末次重接或把暂死段清零当整战结束。

## 现有源码与固定消费者

只读live切点 28bec4afac5c6d51e5f1c30de277c1c6575c188b。以下提交均核为这个切点的真实祖先，保存源码字节SHA/与本树对比于 live-source-readback.json：

| 已有子项 | 实际live源码提交 | 仍未完成 |
|---|---|---|
| 奇巧两名额/能量事实、恶魔特定组合6毒入口 | 8bb53d6342b7e9a2adf96de231b53c36eaa943de | 完整后继、收益兑现和早喝整战 |
| 候选阶段审计 | 05cd292c6f01bb31e406473d3a9843e659d62b93 | actual_turn仍null |
| 单动作派发回执 | bade647f9fe4c9103b40e2f26b26296692ad24b7 | whole_plan_executed仍null |
| 护栏候选差额审计 | a8b1f8be153fe4f3a34146117546c2178f2e446b | actual_outcome仍null |
| HP边界记录所在live源码 | 52d7f343f5f183670dc9d0c0d847bf6a15420aae | 来源未隔离、逐槽消费链未全验 |

前六个审计/窄入口文件与本树字节相同；run-journal.ts三处署名注释为live Dai / 本树 Roy，已查diff，仅此注释差，未冒称字节相同。这里没有把各提交作为整个提案implemented/duplicate提交。

固定验证命令：在agent/以nice运行 npx vitest run tests/silent-demon-input.test.ts tests/silent-hp-recovery.test.ts --pool=threads --maxWorkers=1，离线npm、TMPDIR指向本批scratch。实际两文件30项全部通过，exit0，日志 consumer-vitest.log / consumer-vitest.exit。这只证明现有生产选择/求解窄入口与HP历史消费者的固定读取；没有完整vitest、自然新局采用或胜率改善声明。

夹具原字节引用、保留字段与原帧投影105项校核通过，consumer-fixture-projection.json保留全对照。首轮误用完整状态相等比较未通过，consumer-fixture-readback.json保留原失败；原夹具按设计只保存字段投影，复核没有叶值、数组长度或顺序差，未改变生产代码或测试断言。

未改源码，不运行tsc或完整沙箱自测；撤源码失败/恢复通过不适用。tests.tsc=null，tests.vitest=0、cases=30仅对应上述两个固定文件。本批fixes=[]、merged=null，无源码提交或发布号，也未标任何账本shipped。

## 逐项处置

| 原ID | 处置 | 具体仍缺数据/验证 |
|---|---|---|
| silent-proposal-f54e8de2381c1250 | waiting | F11弃连续反弹后已重问；缺完整候选执行绑定与同窗口实线排名 |
| silent-proposal-763a4b9d9f17b815 | waiting | 十四机制的联合消费者、临时属性撤回与持牌伤/能力/药效多轮校准未完成 |
| silent-proposal-19a5cff2094e2d8f | waiting | 敌段生命周期到真实终局的联合校准与冻结知识同输入整战对照未完成 |
| silent-proposal-3540bf4360bf80af | waiting | HP边界已有，逐源资源/药槽到完整路线休息题面的固定读回未完成 |
| silent-proposal-0ea5c0b9c030fdd6 | waiting | 窄入口已有，完整合法后继/兑现及换对象/提前饮用整战结果缺失 |
| silent-proposal-f915ec544ab94b6e | waiting | 生成小刀重问与局部10伤/6血已核；完整执行归属与同输入整战校准仍缺 |
| silent-proposal-8fb51933639faf90 | waiting | 七项联合多轮校准及覆甲完整减层条件未核；不由6毒子项关闭 |
| silent-proposal-b3bc0eb09211af6c | waiting | 合法后继到实际终结全链未验证，换对象/提前饮毒整战反事实缺失 |
| silent-proposal-fdc3a505fe5e1a55 | waiting | 赢战血价/HP边界已有，分源到完整题面及替路线/锻造整战结果缺失 |
| silent-proposal-5a95725089f53cd8 | waiting | 复活逐击帧、完整候选归属及逐槽资源到消费者全链缺失 |

未扩大到其他提案、旧手动专题或父要求；没有将有限审计关闭宽项。保留原失败/原提案/原账本，沿十个既有CLI ID回报 proposal_results，后续由原调度器保留waiting等新局/补充固定验证。没有新增学习条目或源码，故不重复追加账本、注册新提案或制造合入记录。

运维交付路径为本工作树 learner/runs/20261015-041307-strategy-proposal/proposal.md 与本 report.md；绝对路径见 result.json。本批只写被git忽略的scratch产物，工作树HEAD与tracked文件保持原基线；保密扫描与最终基线验收回执另存 completion-checks.json。

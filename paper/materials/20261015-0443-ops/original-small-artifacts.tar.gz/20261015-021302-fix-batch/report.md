## 修 bug 回报

- 合并基线：main → 014e6dbd150d3323f61c8c00e52ea8174754ea38
- 修复：infra-learner-event-log-second-collision：同秒学习者事件流混写 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f — 测试 agent/tests/learner-strategy-scratch.test.ts:isolates concurrent same-second worker streams and repeated batch launches while preserving legacy logs — 去掉修复时失败：是
- 修复：infra-paper-krane-recorded-line-timeout：固定纸鹤重放夹具重复枚举 — befc39e5ca0105f8ff96d47f817df44f0b2760f1 — 测试 agent/tests/silent-paper-krane.test.ts:captures replay fixtures without enumeration and preserves the production solver input — 去掉修复时失败：是
- 已被别人修掉的：48 个具体子项，逐项提交及祖先核验见下表；不关闭未完成的宽父要求。
- 没修的：既有策略提案（含 silent-0481）— 策略类；上游启动竞态、0332、历史投递/公平性/超时调查 — 证据不足；DPR 性能及独立架构研究 — 太大；逐项理由见 JSON。
- 测试：两次提交前门禁均 tsc=0、vitest=408 文件/3934 用例/exit0。首轮2worker tsc0、407文件402过5败、3922项3915过7超时、exit1，paths未跑；单worker原时限整套复跑通过，7项名称见下文。
- 合入：未合入（7 处锁内预检冲突；刷新提交 无新增，并行记录保持）
- 需要 Roy 定的事：无。

```json
{"task": "fix-batch", "base": "014e6dbd150d3323f61c8c00e52ea8174754ea38", "fixes": [{"item": "infra-learner-event-log-second-collision：同秒学习者事件流混写", "commit": "b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f", "test": "agent/tests/learner-strategy-scratch.test.ts", "fails_without_fix": true}, {"item": "infra-paper-krane-recorded-line-timeout：固定纸鹤重放夹具重复枚举", "commit": "befc39e5ca0105f8ff96d47f817df44f0b2760f1", "test": "agent/tests/silent-paper-krane.test.ts", "fails_without_fix": true}], "skipped": [{"item": "silent-0481 技能药水题面生命周期误述", "reason": "策略类：已绑定 silent-proposal-686d4e759478eebb 原独立策略链；涉及已观察药水来源的题面知识，不重复派发或混入工具修复。"}, {"item": "silent-0308/0311/0319/0320/0322/0329/0334/0339/0344/0362/0365 等机制、出牌、药水、SL、终局、路线、休息未闭合提案", "reason": "策略类：原提案、证据范围及限制保留，沿既有 strategy-proposal 链；不补游戏机制或参数。"}, {"item": "silent-0332 双 Boss 接续正 HP 资源契约异常", "reason": "证据不足：缺具体触发样本、种子及首战末资源；原提案和诊断保留，不伪造正 HP 或吞掉异常。"}, {"item": "sandbox-glob-startup-race 上游目录生命周期和注册时序", "reason": "证据不足：有界恢复与租约 ID 子项已有源码；本轮壳层启动前 ENOENT 原件/转录保留并原样重试，未核具体删除者或更改权限。"}, {"item": "core-build-notify-222802-rc2 原生投递历史", "reason": "证据不足：诊断子项已修，未核原生未发送证明，不重复发送或代填他人 ACK。"}, {"item": "调度公平性和永久饥饿调查", "reason": "证据不足：队列位置不是永久饥饿证明，缺完整 dispatch/seen_runs/新完局时序，不改调度策略或状态。"}, {"item": "mod 超时自愈、缓存收益与旧手工 merge-live.py 历史收尾", "reason": "证据不足：历史子修复保留，未核当前根因或活动 owner，不运行模型/网络、不改旧失败回执或操作旧进程。"}, {"item": "v5-dpr-health 性能、全漏斗、统一资源价值、全历史构筑、量化 P1/P2/R3 及独立架构任务", "reason": "太大：已有独立原 owner；已部署的诊断、期限、取消和传输子项不关闭父范围，不混入普通批次。"}], "merged": null, "tests": {"tsc": 0, "vitest": 0, "cases": 3934}, "code_proposals": [], "implementation_domains": [], "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-021309-fix-batch/report.md"}
```

### 每项反向验证与证据

- 事件流：真实 20261014-231302 与 231302-s2 两批的同秒原文件，逐 offset/bytes/SHA/批号/线程见 event-original-evidence.json。新文件名与 scratch 共用启动 UUID；原任务、批号、线程、租约、权限和报告归属保持。仅撤 launcher/reader 源码，事件回归1败及新格式 reader Python1败；恢复后3文件31项通过。旧日志不改写，旧文件名仍读取。
- 纸鹤：EBVT8UZM6P12/SILENT/A10/F43/T1 两次尝试，冻结状态399969/399976和400002/400009；原完整六步、旧新失血10/19对8/16、伤害、药成本、describePlan及所有范围断言保留。只在建重放夹具时捕获真实生产输入，生产求解及消费者仍真跑。仅撤fixedInput优化、保持新增测试/计数器，回归因实际枚举1次失败；恢复全15过，两项合并定向4文件46过。
- 无新增游戏知识、经验数据、代码提案、实施领域或行为版本；不运行play、真实模型、网络、安装依赖或推送。
- 账本只读查询：事件/碰撞无对应bug-infra；纸鹤查询仅命中已shipped的底层机制0469，非本次夹具缺陷，不降级或新建该条目，不登记shipped。
- 原失败、源码变体、差异和初稿保留；paper-fixed-evidence.json的combat.turn提取错误由paper-fixed-evidence-verified.json从state.turn勘误，原稿保留。第二门禁预启动会话13717曾被glob竞态拒绝，未执行脚本；原命令40764实际RUN后完成，勘误与转录保留，未改模型/账号/权限/线程。

### 首轮超时的原用例（已按原时限在复跑中通过）

- tests/batch-k.test.ts > 4. Attack-counting relics count every play of an Attack: a replay (Soldier's Stew), a duplicate (Duplicator) and a Hellraiser autoplay, as the relics' own counters did in the logs (attacks_played_this_turn counts the card once and no autoplay) > the logged DHGT F33 T1 board with the Shuriken's counter at 2 (a Hellraiser Strike played at the turn's start, attacks_played_this_turn 0): the solver's count is the relic's
- tests/boss-lines-planner.test.ts > B2 off: the boss question as before > BOSS_SIM_LINES=off: every logged boss board's decision is the pre-B2 one, byte for byte
- tests/ops-herdr.test.ts > ops/herdr-host.sh (fake herdr) > new learner tabs follow the live ops pane when workspace labels are duplicated
- tests/ops-herdr.test.ts > ops/herdr-host.sh (fake herdr) > shows verified live learner 20261010-164301-strategy-proposal beside ops and closes its reused viewer on exit
- tests/silent-paper-krane.test.ts > state 400002: the complete recorded line matches the observed HP loss
- tests/target-options.test.ts > per-target options (EZ2L F48 T2: Queen + Torch Head Amalgam) > shows an Amalgam-focus line and a Queen-focus line, labelled, within the option cap
- tests/target-options.test.ts > per-target options (EZ2L F48 T2: Queen + Torch Head Amalgam) > is deterministic: the same board gives the same options and the same kill-order numbers

### 提交前检查记录

| 门禁 | tsc | Vitest 文件/项 | 退出码 | 日志 |
| --- | --- | --- | --- | --- |
| 修复1提交前组合工作树 | 0 | 408/3934 | 0 | /home/dw/Projects/agent-sts2/learner/runs/20261015-021309-fix-batch/fix1-sandbox-retry.log |
| 修复2提交前组合工作树 | 0 | 408/3934 | 0 | /home/dw/Projects/agent-sts2/learner/runs/20261015-021309-fix-batch/fix2-sandbox.log |

两次检查覆盖本批同一源码组合；第一项分拆提交时paper补丁尚未提交，最终两项提交共同构成已测源码。两项提交均扫描暂存差异；原固定排除名单/原超时时限/生产预算及样本不改。

### 已有源码逐项核验

队列冻结1300行，SHA256 1ce4508d9ddc45792f1535af99b88c86b47721c83c33461ab2dcfde9ba411ddf；基线014e6dbd150d3323f61c8c00e52ea8174754ea38、只读live切点eafecc850a8ad55d36e67644236a98d196b61161。完整未划条目、原账本与提案读回保存在queue-audit.json。

| 原条目或已修子项 | 已有源码/实际集成提交 | 基线/live核验 |
| --- | --- | --- |
| 无动作开场死亡的战斗归因 | 3b48088dec5fc6eafe576a1296bbdadde43432ee | 均为祖先 |
| 原生构筑通知失败诊断 | 5c92f2aaf0b758a1a5e7d591745694004664f83a | 均为祖先 |
| 额度恢复后的余额基线 | e5e2995d659d15af79ec8bba67a4a25c1cb7295f | 均为祖先 |
| 升阶通知使用实际进阶 | 8045d9fbf0a12523b1dbe39bbed8af06c7497b09 | 均为祖先 |
| 既有 main 推送入口注册 | c519952b31e3a0bb3acdd2115883ae8671b8a090 | 均为祖先 |
| Codex 退出测试模型契约 | 874ae603b3927173f805e0b2fe789330bab710c7 | 均为祖先 |
| 精确树宿主定向补验入口 | 24c2e3a75b5db6bac76d6c924f86b7fcd9438316 | 均为祖先 |
| 会话前临时 ENOENT 有界恢复 | bc2c40e313cc36682196277c53c50e30744b88c5 | 均为祖先 |
| 已注册派发的固定夹具 | 2b09c47d431a580e9955d157f4dfb0e576186206 | 均为祖先 |
| 空受阻经验批次不误派补链 | 84366ad06ee4f978394c1b9489a82c83ea12bd36 | 均为祖先 |
| 多角色药水前缀固定隔离 | 5ef3c4612bd2673c19968c5a2d24bf62af519ee1 | 均为祖先 |
| 事件具名卡资料入口 | 42c920f34d9dc1c783ce894659849ab37ed6fd1b | 均为祖先 |
| 模拟池缓存签名固定隔离 | 8fbb441eb61eef226eb7366f9612003480c83988 | 均为祖先 |
| rollout 最佳线路固定隔离 | bbc5b993a7524bbb8e80a975f204f8d193657b46 | 均为祖先 |
| 未派发原提案的机械处置绑定 | 3a98e213a826e94f9708af4b1a265e1892659f4e | 均为祖先 |
| 卡死检查异步固定执行器 | 95e7f050ef2abe5c85a0367555392652ad73fbfe | 均为祖先 |
| Jev 明确上下文错误无损重试 | fab7c90945bd4a899d411438a22952b252272aa4 | 均为祖先 |
| batch-c 固定时钟 | 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff | 均为祖先 |
| eval 固定版本夹具 | d9881ba593b0b8d701ebbe1c95626c0ebdd554c7 | 均为祖先 |
| 神化固定模拟时钟 | 9e8c93555131c3347f9e809d9722a848a75c2692 | 均为祖先 |
| 论文 Git refs 一致快照 | 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f | 均为祖先 |
| boss-sim 透传隔离 home | 5921f8cd045853182c867a6430e75c3fcde00a87 | 均为祖先 |
| runLoop 固定时间上限夹具 | b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa | 均为祖先 |
| 宿主补验拒绝原因 JSON | 63f656fb07a21a7496353234269901a832eae497 | 均为祖先 |
| broker 容量及回执失败隔离 | a136ddc4b5b0a8696f10b2fae3073322d57e724c | 均为祖先 |
| autoplay 无故障标记显式退出 | db072ddab47ba94efb46dce2913927f936ecb97e | 均为祖先 |
| JSONL 截断尾行追加边界 | 9b07240b18f862efdbe630889ade04e8976eaace | 均为祖先 |
| 普通通知 ACK 无父任务校验 | 672e198a4730012330f599068a0ef1efadb02002 | 均为祖先 |
| 失败且无复盘不误派补链 | 3fdcd77927f01b35c20c6c5c1fcfd790676032d2 | 均为祖先 |
| 通知前阶段回执重核 | 1594def2e1b65b665d3b345f31444194eb4d09e6 | 均为祖先 |
| 复盘时间戳租约 ID | d9983263ffecea1bed4e29d65e7f854a3d2e33d7 | 均为祖先 |
| 历史牌组约束消费者夹具 | c0999eaa251133454540e157b2d6fe641731ad65；main ec8c578b66bf5498372f1b779ae58a766dff8112；live 64cc53f99311364d6e3082e65d51a459d48260dc | 原源码非祖先，实际集成祖先/四叶等价已核 |
| 公共经验固定文件快照 | 8390c62d76fc8c7d7b6b7292121a621f4666d39c | 均为祖先 |
| 路径拒绝固定异步夹具 | df5f2e3fac5db56e3c92a241e2b4a170c6962212 | 均为祖先 |
| Codex 长思考固定时钟夹具 | a18376cce22eb9e47377d474a85fb864f7c636e2 | 均为祖先 |
| 宿主精确长题名承载 | f8896692b0d868b900ccffc8ed910321d0f3e765 | 均为祖先 |
| 升阶审计异步固定 Python 分组 | a11e32ae1a01ecf75cc57519be21f2d144c2cd18 | 均为祖先 |
| 策略研究固定分组 | cd1f5593430a2d13479368679b5d42994540f7c8 | 均为祖先 |
| 药水 MC 有界固定验收 | 519b63549f1c61276755066e5a76d0351cf09a7c | 均为祖先 |
| rollout 排序有界固定验收 | b68a650ab95c15a492cccac598906f32284229be | 均为祖先 |
| 注册 feature 的角色回执校验 | 38b2f572d90b3b97a23f9eae983f583287492f9a | 均为祖先 |
| tracked-source Python 缓存回收 | 1e8af775f6b90f100f20ff7c4a08dfddaba893a9 | 均为祖先 |
| 包装及参数化测试期限解析 | 56c256dad0d33b231b82b53113d3bdd84f9bfa20 | 均为祖先 |
| producer 到通知身份的绑定 | 1dd4d434aef67f1d065dbdba23a875ae82741a88 | 均为祖先 |
| run-plans 真实 run 身份提取 | 78e9b05929366d097a728761d693d790ff16ac87 | 均为祖先 |
| 策略报告的工作树 scratch 归属 | 5f04139cefe5c651dd5bf62f7e164014dbf5f23b | 均为祖先 |
| Jev 决策投影合同与上下文阻塞 | 75249befaad497b68ffbdbf242c9e1672beba850 | 均为祖先 |
| S 统计实际敌 HP 伤害归属 | e5d07f4a5a45ff3cf2cb44d09dfa89fa1ebf46ad | 均为祖先 |

### 锁内合并预检

刷新提交：None；合入前live：28bec4afac5c6d51e5f1c30de277c1c6575c188b；检查后live：28bec4afac5c6d51e5f1c30de277c1c6575c188b。
刷新/本分支知识重叠：[]；并行未提交记录SHA保持：True。
锁内合并预检冲突；未启动工作区合并，保留刷新数据及并行记录

未实际合入时不跑合后检查、不写上线记录、不冒标shipped。原分支、失败、刷新与并行字节保留，未擅解记录冲突。

- CONFLICT (file location): paper/materials/20261015-0118-ops/final-records-gitleaks.log added in codex-fix-silent-20261015-021302 inside a directory that was renamed in HEAD, suggesting it should perhaps be moved to experiments/boss-sim/silent/0d304543ffeb4173c12fad428eaee706a25d5b90b883b7795ab7c9d824dca639/final-records-gitleaks.log.
- CONFLICT (file location): paper/materials/20261015-0118-ops/raw-whitespace-exception-receipt.json added in codex-fix-silent-20261015-021302 inside a directory that was renamed in HEAD, suggesting it should perhaps be moved to experiments/boss-sim/silent/0d304543ffeb4173c12fad428eaee706a25d5b90b883b7795ab7c9d824dca639/raw-whitespace-exception-receipt.json.
- CONFLICT (file location): paper/materials/20261015-0118-ops/record-commit-readback.json added in codex-fix-silent-20261015-021302 inside a directory that was renamed in HEAD, suggesting it should perhaps be moved to experiments/boss-sim/silent/0d304543ffeb4173c12fad428eaee706a25d5b90b883b7795ab7c9d824dca639/record-commit-readback.json.
- CONFLICT (content): Merge conflict in notes/fix-queue-v4.md
- CONFLICT (content): Merge conflict in ops/inbox-dev.md
- CONFLICT (content): Merge conflict in paper/materials/decision-log.md
- CONFLICT (content): Merge conflict in paper/materials/learning/ledger.jsonl

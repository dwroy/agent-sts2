import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = Path.cwd()
SCRATCH = ROOT / 'learner/runs/20261017-224309-611c1265-c7e0-4f4f-aa27-cf84315f9bad-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261017-211309-108f9305-9c58-46ce-b592-fccf83549908-fix-batch'
BASE = '03e5a8f50b01203ece2518d0391d15936aa4dd50'
G2 = '0b1807b159a1e3d7fc09aad541ea6f97be627a91'

def git(*args, cwd=WORK):
    return subprocess.check_output(['git', '-C', str(cwd), *args])

def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def ancestor(commit, ref):
    result = subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, ref], capture_output=True)
    assert result.returncode in (0, 1)
    return result.returncode == 0

assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('status', '--porcelain')
previous = json.loads((PREVIOUS / 'source-audit.json').read_text())
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert queue == (PREVIOUS / 'fix-queue-snapshot.md').read_bytes()
assert hashlib.sha256(queue).hexdigest() == previous['queue_sha256']
(SCRATCH / 'fix-queue-snapshot.md').write_bytes(queue)
main = git('rev-parse', 'main').decode().strip()
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode().strip()
g2_paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', G2).decode().splitlines()
assert len(g2_paths) == 6 and all(p.startswith(('agent/src/sim/', 'agent/tests/global-build')) for p in g2_paths)
source_blobs = {}
changed = []
for path in sorted(set(previous['source_blobs']) | set(g2_paths)):
    assert path.startswith(('agent/', 'ops/', 'learner/', 'eval/', 'knowledge/builders/'))
    assert not Path(path).name.endswith('.env')
    blob = git('rev-parse', BASE + ':' + path).decode().strip()
    if path in previous['source_blobs'] and blob != previous['source_blobs'][path]['blob']:
        changed.append(path)
        assert path in g2_paths, path
    current = git('hash-object', '--', path).decode().strip()
    assert current == blob, path
    live_blob = git('rev-parse', live + ':' + path).decode().strip()
    live_current = git('hash-object', '--', path, cwd=ROOT / '.worktrees/live').decode().strip()
    assert live_current == live_blob, path
    source_blobs[path] = {'blob': blob, 'live_blob': live_blob, 'working_matches_head': True, 'live_working_matches_head': True}
    if path in g2_paths:
        assert blob == live_blob == git('rev-parse', G2 + ':' + path).decode().strip(), path
source_paths = ['agent/src', 'agent/tools', 'agent/tests', 'agent/package*.json', 'agent/tsconfig*.json',
                'agent/vitest*', 'learner/*.ts', 'learner/*.py', 'learner/lib', 'learner/tasks', 'ops/*.sh',
                'ops/*.py', 'ops/codex', 'ops/tests', 'eval/*.py', 'eval/*.ts', 'eval/cost-config.json', 'knowledge/builders']
changed_paths = git('diff', '--name-only', previous['base'], BASE, '--', *source_paths).decode().splitlines()
assert set(changed_paths) == set(g2_paths), changed_paths
(SCRATCH / 'source-since-previous.diff').write_bytes(git('diff', '--binary', previous['base'], BASE, '--', *source_paths))
fixed = []
for row in previous['already_fixed'] + [{'item': 'U5W7NUE925NK/H1/G2预算到期诊断及零样本前缀（已实际合入；原F15/F16完整根因仍未知）', 'commit': G2}]:
    item = {'item': row['item'], 'commit': row['commit']}
    for label, ref in [('base', BASE), ('main', main), ('live', live)]:
        item[label + '_ancestor'] = ancestor(item['commit'], ref)
        assert item[label + '_ancestor'], item
    fixed.append(item)
dispositions = json.loads((PREVIOUS / 'unchecked-items-disposition.json').read_text())
for row in dispositions:
    assert queue.decode().splitlines()[row['line'] - 1] == row['original']
    if row['line'] == 1433:
        row.update(disposition='已修G2预算诊断/缓存及严格零样本前缀边界；原F15/F16完整根因证据不足', commit=G2)
    if row.get('commit'):
        assert ancestor(row['commit'], BASE) and ancestor(row['commit'], live)
assert len(dispositions) == sum(line.startswith('- [ ]') for line in queue.decode().splitlines())
save('unchecked-items-disposition.json', dispositions)
host_path = ROOT / 'paper/materials/20261017-2220-ops/G2-exact-host-completion.json'
host = json.loads(host_path.read_text())
assert host['source'] == G2 and host['actual_live'] == live
assert host['tree'] == git('rev-parse', live + '^{tree}').decode().strip()
assert host['full_tsc_vitest_rc'] == 0
hasher = hashlib.sha256()
with Path(host['log']).open('rb') as stream:
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        hasher.update(chunk)
assert hasher.hexdigest() == host['log_sha256']
save('existing-G2-host-readback.json', {'source_receipt': str(host_path), 'source_sha256': hashlib.sha256(host_path.read_bytes()).hexdigest(),
     'receipt': host, 'actual_log_sha_verified': True, 'rerun_by_this_batch': False})
save('source-audit.json', {'base': BASE, 'main': main, 'live': live, 'previous_base': previous['base'],
     'previous_audit': str(PREVIOUS / 'source-audit.json'), 'queue_sha256': hashlib.sha256(queue).hexdigest(),
     'queue_identical_to_previous': True, 'source_blobs': source_blobs, 'source_paths_checked': len(source_blobs),
     'already_fixed': fixed, 'all_source_unchanged_since_previous': False, 'changed_source_paths': changed_paths,
     'changed_previously_audited_paths': changed, 'all_changes_are_already_live_G2_fix': True, 'unchecked_items': len(dispositions)})
native = Path('/home/dw/.codex1/sessions/2026/10/17/rollout-2026-10-17T22-43-17-01a14a51-2fee-73f3-8f44-d483930b523b.jsonl')
with native.open() as stream:
    for line in stream:
        event = json.loads(line)
        if event.get('type') == 'turn_context':
            context = event['payload']
            assert context['model'] == 'gpt-6.1-sol' and context['effort'] == 'xhigh'
            save('runtime-readback.json', {'native_session': str(native), 'thread_id': '01a14a51-2fee-73f3-8f44-d483930b523b',
                 'model': context['model'], 'effort': context['effort'], 'native_model_confirmed': True, 'native_effort_confirmed': True})
            break
    else:
        raise AssertionError('native turn_context missing')
prior_report = json.loads((PREVIOUS / 'report.json').read_text())
skipped = [row for row in prior_report['skipped'] if row['item'] != '本批G2诊断修复合入live']
report = {'task': 'fix-batch', 'base': BASE, 'fixes': [], 'skipped': skipped, 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
lines = ['## 修 bug 回报', '- 合并基线：main → ' + BASE,
         '- 修复（每条一行）：无新增纯 bug 修复。队列与上一批逐字一致，43个既有修复均已核为main/live祖先。']
for row in fixed:
    lines.append('- 已被别人修掉的：' + row['item'] + ' — ' + row['commit'])
for row in skipped:
    lines.append('- 没修的：' + row['item'] + ' — ' + row['reason'])
lines.extend(['- 测试：本批未改源码，tsc未跑（退出码null）；vitest 0文件 / 0用例 / 未跑（退出码null），未重跑。只读核查183个源码/测试叶、43个提交与49条未勾选项；已核既有G2宿主原日志SHA及531文件5222通过2跳过/退出码0，仅作历史证据，不计为本批测试。',
              '- 合入：未合入（本批无新提交；43项既有修复已在live ' + live + '）。未修改live刷新数据、队列、账本或发布记录。',
              '- 需要 Roy 定的事：无'])
(SCRATCH / 'report.md').write_text('\n'.join(lines) + '\n\n```json\n' + json.dumps(report, ensure_ascii=False, indent=2) + '\n```\n')
save('report.json', report)
assert not git('status', '--porcelain')
print(json.dumps({'base': BASE, 'live': live, 'already_fixed': len(fixed), 'source_paths_checked': len(source_blobs),
                  'unchecked_items': len(dispositions), 'new_fixes': 0, 'tests_run': False, 'worktree_clean': True, 'report': report['report']}, ensure_ascii=False, indent=2))

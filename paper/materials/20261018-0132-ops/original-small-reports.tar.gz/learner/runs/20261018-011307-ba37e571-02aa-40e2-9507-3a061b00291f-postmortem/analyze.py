import json,collections,datetime
from pathlib import Path
P=Path(__file__).parent

def rows(n):
    for l in (P/(n+'.raw')).open():
        a,b,c=l.rstrip().split(':',2)
        yield int(a),int(b),json.loads(c)

def frame(s):
    r=s.get('run',{});c=s.get('combat') or {};p=c.get('player') or {}
    return {'floor':r.get('floor'),'turn':s.get('turn'),'screen':s.get('screen'),'hp':r.get('current_hp'),'max':r.get('max_hp'),'energy':p.get('energy'),'block':p.get('block'),'powers':p.get('powers'), 'enemies':c.get('enemies'), 'hand':c.get('hand'), 'potions':r.get('potions')}

with (P/'frames.txt').open('w') as f:
    for n,off,d in rows('states'):
        s=d['state'];z=frame(s)
        if (z['floor'] or 0)>=19 or z['floor'] in [7,12,16]:
            f.write(f"s{n} {d['ts']} "+json.dumps(z,ensure_ascii=False)+'\n')
with (P/'turns.txt').open('w') as f:
    R=json.load((P/'J5E7A3MS9NSH-resources.json').open());ss={n:d for n,o,d in rows('states')}
    for w in R['combats']:
        turns=collections.OrderedDict()
        for n,o,d in rows('states'):
            s=d['state'];t=s.get('turn')
            if w['entry']['line']<=n<=w['last']['line'] and s.get('in_combat'):
                turns.setdefault(t,[]).append((n,d))
        f.write(f"WINDOW {w['sequence']} F{w['floor']}\n")
        for t,x in turns.items():
            n,d=x[0];s=d['state'];c=s['combat'];r=s['run']
            en=[(e.get('name'),e['enemy_id'],e['current_hp'],e.get('block'),e.get('powers'),e.get('intents')) for e in c.get('enemies',[])]
            f.write(f"T{t} s{n} HP{r['current_hp']} "+json.dumps(en,ensure_ascii=False)+'\n')
            nd=next((v[0][1] for tt,v in turns.items() if tt>t),None)
            if nd is None:nd=ss[w['exit']['line']] if w['exit'] else x[-1][1]
            def hp(q):return sum(e['current_hp'] for e in q['state'].get('combat',{}).get('enemies',[]) if e['is_alive'])
            f.write(f"end HP{nd['state']['run']['current_hp']} live_enemy_net={hp(d)-hp(nd)}\n")
with (P/'questions.txt').open('w') as f:
    for n,off,d in rows('decisions'):
        if d.get('floor') in [20,21,22,23] or d.get('label','').startswith(('map/route','rest/')):
            f.write(f"d{n} F{d.get('floor')} T{d.get('turn')} {d['label']} {d['decider']}\n")
            f.write(json.dumps({k:d.get(k) for k in ['chosen','rationale','confidence','journal','result','usage']},ensure_ascii=False)+'\n')
            if d.get('label','').startswith(('map/route','rest/')) or d.get('floor')==20:
                f.write(json.dumps(d.get('questions'),ensure_ascii=False)+'\n')
print('prepared')
print('journal sample')
for n,o,d in rows('decisions'):
    if d.get('decider')=='jev' and d.get('label','').startswith('combat'):
        print(n,json.dumps(d.get('journal'),ensure_ascii=False));break
print('state keys')
n,o,d=next(rows('states'));print(n,d['state'].keys());print(d['state'].get('combat',{}).keys());print(json.dumps(d['state'].get('run'),ensure_ascii=False)[:1500])
print('brain usage')
B=list(rows('brain'))
for n,o,b in B:print(n,b['label'],b.get('accepted'),b.get('usage'),b.get('problems'))

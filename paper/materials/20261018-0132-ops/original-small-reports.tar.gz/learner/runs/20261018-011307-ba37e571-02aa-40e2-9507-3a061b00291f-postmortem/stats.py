import json,collections,datetime
from pathlib import Path
P=Path(__file__).parent

def rows(n):
    for l in (P/(n+'.raw')).open():
        a,b,c=l.rstrip().split(':',2);yield int(a),json.loads(c)
D=list(rows('decisions'));S=list(rows('states'));B=list(rows('brain'))
J=[(n,d) for n,d in D if d['decider']=='jev'];C=[(n,d) for n,d in J if d['label'].startswith('combat/')]
print('JEv best',collections.Counter(str(d.get('rollout_best_chosen')) for n,d in C))
print('rank',collections.Counter(d.get('rationale','').split('code rank ')[-1].split(';')[0] for n,d in C))
print('Jev usage', {k:sum((d.get('usage') or {}).get(k,0) or 0 for n,d in J) for k in ['inputTokens','outputTokens','cacheHitTokens']})
print('Jev example usage',J[0][1]['usage'])
print('B sums', {k:sum((b.get('usage') or {}).get(k,0) for n,b in B) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']})
print('brain count',len(B),'accept',sum(b.get('accepted',False) for n,b in B),'engines',collections.Counter((b.get('engine'),b.get('model'),b.get('effort')) for n,b in B))
print('Guard',[(n,d['rationale'],d.get('hp_guard')) for n,d in D if d.get('hp_guard') or 'HP guard:' in d.get('rationale','') or 'over the HP guard bound' in d.get('rationale','')])
print('focus')
for n,d in C:
    if 'focus' in (d.get('questions') or {}):print(n,d['floor'],d['turn'], d['questions']['focus'].get('criteria'),d.get('answers'))
for n,d in C[:1]:print('choice example', d.get('answers'),'rollout keys',d.get('rollout',{}).keys())
A=[(n,d) for n,d in D if (d['decider']=='code' and d['label'] in ['combat/plan','combat/lethal','combat/least-loss']) or (d['decider']=='code-fallback' and d['label'].startswith('combat/'))]
def key(d):return (d['floor'],str(d.get('sl_attempt')),d['turn'])
K={key(d) for n,d in A};JK={key(d) for n,d in C}
print('autonomy',collections.Counter((d['decider'],d['label']) for n,d in A),'windows',len(K),'without Jev',len(K-JK),sorted(K-JK))
print('continues',collections.Counter('jev' if 'Jev-chosen' in d.get('rationale','') else 'code' for n,d in D if d['label']=='combat/plan-continue'))
print('turn table')
R=json.load((P/'J5E7A3MS9NSH-resources.json').open());SD=dict(S)
for w in R['combats']:
    chunks=collections.OrderedDict()
    for n,d in S:
        if w['entry']['line']<=n<=w['last']['line'] and d['state'].get('in_combat'):chunks.setdefault(d['state']['turn'],[]).append((n,d))
    hps=[];needs=[];net=[];added=[]
    for i,(t,x) in enumerate(chunks.items()):
        start=x[0][1];end=list(chunks.values())[i+1][0][1] if i+1<len(chunks) else SD[w['exit']['line']] if w['exit'] else x[-1][1]
        hp=lambda q:sum(e['current_hp'] for e in (q['state'].get('combat') or {}).get('enemies',[]) if e['is_alive'])
        hps.append(start['state']['run']['current_hp']-end['state']['run']['current_hp']);needs.append(hp(start));net.append(hp(start)-hp(end))
    print(w['sequence'],w['floor'],'need',needs,'net',net,'hp_loss',hps)
print('picked F22 and F23')
for n,d in D:
 if d['floor'] in [22,23] and (d['label']!='combat/plan-continue'):
    print(n,'F',d['floor'],'T',d['turn'],'A',d.get('sl_attempt'),d['label'],d['decider'],d.get('answers'),d['rationale'])
    a=d.get('answers') or {};v=a.get('plan');v=v.get('value') if isinstance(v,dict) else v
    if isinstance(v,str):
        cc=(d.get('questions') or {}).get('plan',{}).get('criteria',{}).get(v)
        if cc:
            q=json.loads(cc) if isinstance(cc,str) else cc
            print('selected facts',{k:q.get(k) for k in ['plays','hp_lost','damage_dealt','block_gained','scaling_gained','rollout','rollout_ranking','fight_rollout','lookahead','enemies_after'] if k in q})

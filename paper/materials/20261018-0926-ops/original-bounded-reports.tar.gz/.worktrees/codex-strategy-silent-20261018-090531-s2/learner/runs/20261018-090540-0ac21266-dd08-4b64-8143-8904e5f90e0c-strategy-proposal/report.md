# 静默策略提案批次报告

记录时间：2026-10-18T09:19:05+08:00。

本批十个原提案逐项核证，全部 waiting；没有新源码、经验或策略参数修改，没有提交、合入或版本。已实现子项保留真实live祖先证明，不关闭原复合提案。

## 身份与基线

- 批次：20261018-090531-s2-strategy-proposal；task=strategy-proposal；character=silent；reason=proposal。
- 启动时工作树干净，HEAD=ac8eca0c0fad135819157637ffb8b594edf7371f。按普通队列任务执行 git merge --no-edit main，仅快进两份记录文件23行；本批 base=34a42921086a92925dc55d1608e06760440e55d2。
- learn.json 只读本批记录；proposal_ids 精确10项，没有proposal_repair、research_request或implementation_request。普通专题请求文件绑定其他批次，不适用于本批；未读取其他专题正文、领取其他id或改根请求。
- 五个派发局在runs.jsonl均唯一归属SILENT/A10；NHA2KW0RB7VP F33败、P74C04AEPL1F F23败、G33HU22H2543 F48败、RC61MFQM63Y6 F33败、BTSRF7JL1W1Y F31败。同局SL不增加独立局数，重读不新增support/repeat。
- 10份原Markdown均逐字节SHA匹配队列add行，保留原路径和恢复副本出处于 original-proposal-manifest.json；原提案不改写。32个原账本及22个关联Silent经验保存只读快照，没有读取其他角色私有知识来形成结论。

## 原始证据与消费范围

共用入口 learner/extract_evidence.py 正常退出0，提取八流，逐行回读原日志验证身份、offset/bytes/SHA256、JSON与各流输出SHA、计数及source_size边界，合计6606条。核验脚本/结果为 audit_evidence.py、evidence-verification.json；原始抽取位于 evidence/，日志只读。

| 流 | 截点字节 | 本批归属行数 |
|---|---:|---:|
| states | 14244339824 | 3238 |
| decisions | 2480220172 | 3138 |
| sl-attempts | 47421270 | 31 |
| run-config | 2074501 | 5 |
| run-plans | 9253771 | 26 |
| brain | 803409771 | 163 |
| runs | 370870 | 5 |
| fight-plans | 2233957 | 0 |

states/decisions/brain全源各2条坏行仅为扫描器计数，不能归到本批。fight-plans在其2233957字节截点本批选中0，不表示原日志丢失。run-plans按显式run身份提取26条；正文提及不作为归局依据。没有重用旧截点或覆盖零行初稿。

限定窗口调用现有 learner/audit-selection.ts，使用 node --import tsx loader，不读刷新知识、不调模型/网络、不运行play。输入保留原_line与_source_sha256、真实时间/指纹，按已核单局构造，不重编号；范围如下。

| 局号 | 层 | 状态/决策 | 候选段 | 回合窗/可核端点 | 退出码 |
|---|---|---:|---:|---:|---:|
| NHA2KW0RB7VP | 33 | 137/136 | 41 | 24/13 | 0 |
| P74C04AEPL1F | 17,22,23 | 131/127 | 26 | 29/13 | 0 |
| G33HU22H2543 | 31,48 | 296/288 | 47 | 59/40 | 0 |
| RC61MFQM63Y6 | 17,33 | 258/256 | 68 | 43/29 | 0 |
| BTSRF7JL1W1Y | 31 | 28/27 | 6 | 4/0 | 0 |

五次离线审计共188候选段、159回合窗，其中95窗有观测端点；完整候选结果均null。工具本身不认证整条候选，null是消费者保留未知的设计，不能据此断言所有实际计划都未完成。BTS F31的4窗均缺其要求的已知尝试边界，原状态/动作仍完整保留，不称日志缺失。离线审计输出不是生产模拟重跑、自然大脑消费、独立胜率评估或tsc/vitest成功。输入/输出SHA与逐局范围见selection-audit/manifest.json，执行源码五叶pin见offline-audit-source-manifest.json。

## 核实的局部事实与反例

NHA F33同局T1：states283391→283397实30→29、敌HP总和408→400；第六试283502→283507实30→23、408→384。即净扣8/24、损1/7，不能把全败推演当相同血价，也不能由多伤多耗血单独决定胜率。

RC F33首/六试T1：285314→285321为52→48、敌总HP428→398；285491→285497为52→44、428→405，即实损4/8、净扣30/23。279197当题original是不同目标且不喝药的候选，预测损21；不能把它混为首试已执行原线的实损4。成对原始端点与SHA见same-board-observed-comparisons.json。

P74 F23末T3：284817真实弃牌选项有紧勒、毒雾+、精确切击、贪婪四项；精确被弃后284818离手，1血16挡对石16+卵8，284821卵毒后剩2且玩家0。原计划不等于实线；首试卵已死的反例不能和末试混作同盘。F17火焰182→181/滑溜8→7、T2两毒结180→178；F22 T2 53→33、T4 33→9，最终赢战9血接F23，不能因赢而抹掉44耗血。

BTS F31 T2生存者后唯一突然一拳消失的根因与原silent-0268同类；T3抽弃前后的候选不相同。T4 14血、5牌挡、覆甲1，对醒虫22，净需要16而实扣截断到0；不能把实扣14当完整来袭，也不能以一次3/4样本线死亡调整权重。

实际休息窗口按rest/plan动作与连续同层REST状态核对：NHA 5次120，P74 2次42，G33 5次133且上限+25，RC 5次105，BTS 2次42；详见rest-observed-summary.json和原状态SHA。没有把存档恢复/同瓶药栏重放当治疗或新得药；没有复算或声称新完成原提案所列全部历史样本统计。

## 当前源码与局部已实现

取证时live=9d9f5adb00766a6a3865c46b301bfd62c7ddd7da。12个直接源码叶的Git blob、SHA、base/live副本及真实live祖先见source-manifest.json，补充固定测试/工具/rollout见supporting-source-manifest.json。a8b1f8be153fe4f3a34146117546c2178f2e446b实际为该live祖先，投斧首牌身份、普通生存者唯一弃牌等子实现可见；部分源码后续提交及固定测试文件同样保留。未将64叶整合提交的祖先关系冒充每个宽提案已完整实现。

base/live的card-model.ts与sl/explore.ts差异仅为原归属注释，完整差量见base-live-source-differences.patch；rollout.ts确有live专用女王同伴力量处理的行为差异（fullFight且显式观测开关），已保存实际live副本及rollout-base-live-difference.patch。未将base完整推演视作当前live等价验证；本批只执行两边逐字节相同的离线审计消费者。

已有SL resource_comparison/candidate_comparison明确为候选预测，selection_dispatch为单动作回执，actual_turn保持未知；这些局部信息不满足宽提案的全部执行归属和策略校准。普通弃牌界面已有计划后继与保留手牌事实；未核实四合法分支完整数值及逐敌来袭完整消费。未定位出需要本批新修改的独立、可隔离确定数值错误。

## 十项处置

每项的来源任务、证据层/回合、原账本、支持、反例、未完成要求、预期行为、验证与回退均在proposal.md及逐份原Markdown；机器结果见proposal-results.json。

- silent-proposal-9952ee8e8df9a0fe：waiting。候选资源差额、离线药槽/回合观测已有；缺与这两条已执行前缀一致的完整候选归属、独立时间后置校准及替代路线/留药结局，不新增HP或SL阈值。 账本：silent-0019,silent-0020,silent-0065,silent-0264,silent-0079；证据：NHA2KW0RB7VP F33 T1首/六试；F24/27/32实休。

- silent-proposal-47be799a87af03be：waiting。当前已有后继牌事实、原预测条件及保留手牌快照；逐敌当前来袭的完整题面消费尚未核实，仍缺四个合法分支的手牌变化后数值重算/未知传播和保留精确分支的可核结果。不能用固定7伤或强制弃贪婪替代。 账本：silent-0205；证据：P74C04AEPL1F F23第4试T3，states284816–284821/decisions278542–278546。

- silent-proposal-3a5274da3c42672a：waiting。滑溜、额外毒结算、逐敌失衡和一次格挡消费已有相关源码；本批未定位新的可隔离差额。缺F22主怪最终死亡中间帧、召唤实体的完整结算归属及跨战/保药完整对照，不以净差拟合模型或整项duplicate。 账本：silent-0039,silent-0196,silent-0013,silent-0180,silent-0224,silent-0227,silent-0027,silent-0011,silent-0006；证据：P74C04AEPL1F F17 T1/2/8、F22 T2/4/6、F23末T3。

- silent-proposal-bc4b92d590f2c4ce：waiting。投斧首牌身份及普通生存者单弃已由实际live祖先a8b1f8be153fe4f3a34146117546c2178f2e446b覆盖子项；缺多选分支完整数值、能力实际兑现与整线归属，原复合提案不能整项duplicate。 账本：silent-0092,silent-0023,silent-0021,silent-0057,silent-0205,silent-0079,silent-0266；证据：G33HU22H2543 F48 T1/T8；P74C04AEPL1F F23末T3。

- silent-proposal-f52fbbab4dccc3b4：waiting。原始实入口与已完成回血可核，当前路线仍给条件预测。缺同条件另路线/休息/保药结局、重复召唤需伤的完整实体轨迹及独立校准；不从未来营火或败局拟合新路线禁令/终局权重。 账本：silent-0019,silent-0020,silent-0090,silent-0069,silent-0039,silent-0064；证据：G33HU22H2543 F31/33/47/48；P74C04AEPL1F F22/23。

- silent-proposal-10f37c0edd3d24a6：waiting。已有子机制模型和经验不能替代整个组合矩阵。本批未核实新确定失配；缺未知组合/恢复与复活内部顺序、独立完整伤害分解及新静默验证，不另设通用用药/持有参数。 账本：silent-0006,silent-0011,silent-0027,silent-0046,silent-0013,silent-0180,silent-0196,silent-0255,silent-0198,silent-0204,silent-0069；证据：G33HU22H2543 F48 T7/8；P74C04AEPL1F F17 T1/2/8、F23 T1/3。

- silent-proposal-3f82387e2e179703：waiting。候选差额/审计已有；普通单弃先决缺口已由实际live祖先a8b1f8be153fe4f3a34146117546c2178f2e446b处理。仍缺完整候选兑现和按原局分组的独立同盘/整战验证，不由一个全败局拟合血价权重或固定禁能力。 账本：silent-0079,silent-0027,silent-0065,silent-0080,silent-0088；证据：RC61MFQM63Y6 F33首/六试T1，第三试T4。

- silent-proposal-aee21084c991abd3：waiting。现有材料未隔离出实际末线上的确定数值模型错误；需固定已执行分支的逐步模型对照及新同角色完整战斗校准。本批离线审计此窗4轮端点均因原记录边界未知而未认证，不以3/4样本一次死亡调权或强制焦点。 账本：silent-0128；证据：BTSRF7JL1W1Y F31 T1–T4，decisions279852/279854。

- silent-proposal-df37594e9b12debf：waiting。强制单弃唯一后继已由实际live祖先a8b1f8be153fe4f3a34146117546c2178f2e446b覆盖；原提案还含未知多选、实际朝向/能力窗口、呼唤终局损失与SL选择评价。缺这些完整执行归属与独立验证，保留原id waiting。 账本：silent-0021,silent-0027,silent-0057,silent-0065,silent-0079,silent-0176,silent-0205,silent-0268；证据：RC61MFQM63Y6 F17 T11、F33第三试T4及首/六试T1。

- silent-proposal-42e81c83b2e1e56b：waiting。缺可归因的替代休息/路线/保药对照、该条件的预测误差分解及独立时间切分验证。现有中位/分位路线预测不能由一局到达差额改成固定禁令，保持终局与SL参数。 账本：silent-0019,silent-0020；证据：RC61MFQM63Y6 F24/27/32实休、F29赢战、F33六试。

## 记录与交付

只通过根 learner/ledger.py update 追加32条本角色where.proposal与复核note，by=learner:strategy-proposal；不新增证据或提案id，不改claim、首证、prior、原status、version、effect。原proposed保持，原shipped不降级；本批不登记任何shipped。CLI输入/返回和前后不变检查将在ledger-updates.jsonl、ledger-update.result.json、ledger-link-verification.json保存。

无源码/知识修改：fixes=[]、merged=null、tests={"tsc":null,"vitest":null,"cases":null}；没有新提交、发布号、撤源码红/恢复绿或合后测试，这些不适用，不能填0冒造成功。未持live合并锁、未刷新知识、未改main/live或运维prompt、不推送。

取证路径探测的几次exit2保留在原会话日志，后续经rg --files定位正确文件；它们不是产品测试失败。一度过宽的测试文件检索命中无关历史夹具，该输出没有用于任何结论，后续检索限定准确Silent叶；未加载其他角色知识库。audit_evidence.py的导入路径在首次运行前修正，实际执行只有一次exit0。

所有派发id仍等待新证据或尚未完成的确定性模型/消费者验证，不把缺数据直接等同于需要胜局才能修局部模型；若未来有可复现局部差额，可在现有授权内独立实现。无新游戏结论、异议或反证需另起重复id；原counterexamples/未知与旧记录保持。

供运维交付：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-090531-s2/learner/runs/20261018-090540-0ac21266-dd08-4b64-8143-8904e5f90e0c-strategy-proposal/proposal.md；报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-090531-s2/learner/runs/20261018-090540-0ac21266-dd08-4b64-8143-8904e5f90e0c-strategy-proposal/report.md。最终工作树与HEAD检查见final-worktree-verification.json。

最终验收：根账本CLI update退出0，32条本批链接各一次均逐物理行读回；32项除where/notes/history外逐字段与原快照相等，旧history及notes前缀完整，并行链接元数据保留。根ledger check在本批追加后退出0（516项、0问题）。HEAD=34a42921086a92925dc55d1608e06760440e55d2且git status --porcelain为空，tracked diff为空；无提交/合入。五次离线审计输入/输出SHA及十份原Markdown再次核回。最终核验两次exit1原件分别保存：首轮错误把CLI正常history追加也当成不变字段；第二轮错误假定共享账本只能多本批一条，实际另有09:21:10并行链接追加。修正为原前缀保留、本批物理行各一次、游戏事实字段不变后exit0；没有重写账本/历史，不冒产品测试通过。

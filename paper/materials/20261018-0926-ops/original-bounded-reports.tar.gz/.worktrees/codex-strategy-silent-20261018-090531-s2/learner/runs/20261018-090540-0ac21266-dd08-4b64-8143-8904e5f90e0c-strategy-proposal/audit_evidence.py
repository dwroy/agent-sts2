import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
EXTRACT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXTRACT)
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(rows):
    return {x.get('power_id'): x.get('amount') for x in rows or []}


def frame(item):
    raw = item['row'].get('state', {})
    combat = raw.get('combat') or {}
    player = combat.get('player') or {}
    run = raw.get('run') or {}
    selection = raw.get('selection') or {}
    return {
        'run': item['run_id'], 'line': item['line'], 'offset': item['offset'],
        'bytes': item['bytes'], 'sha256': item['sha256'],
        'floor': run.get('floor'), 'turn': raw.get('turn'), 'screen': raw.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')),
        'max_hp': player.get('max_hp', run.get('max_hp')),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player.get('powers')),
        'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'name', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id', 'intent', 'intents']} |
                    {'powers': powers(e.get('powers'))} for e in combat.get('enemies', [])],
        'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'playable', 'resolved_rules_text']} for c in combat.get('hand', [])],
        'selection': {k: selection.get(k) for k in ['kind', 'prompt', 'min_select', 'max_select', 'selected_count', 'cards']} if selection else None,
        'potions': run.get('potions'),
    }


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verification = []
state_items = []
decision_items = []
other_items = {}
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = collections.Counter()
    size = 0
    with path.open('rb') as handle, Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for encoded in handle:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['run_id'] in RUNS
            assert EXTRACT.run_identity(item['row']) == item['run_id']
            assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            counts[item['run_id']] += 1
            size += len(raw)
            if name == 'states':
                state_items.append(item)
            elif name == 'decisions':
                decision_items.append(item)
            else:
                other_items.setdefault(name, []).append(item)
    assert digest.hexdigest() == stream['output_sha256']
    assert dict(counts) == {r: n for r, n in stream['counts'].items() if n}
    verification.append({'stream': name, 'source_size': stream['source_size'], 'rows': sum(counts.values()),
                         'bytes_verified': size, 'counts': stream['counts'], 'verified': True,
                         'source_invalid_lines_unattributed': stream['invalid_lines'],
                         'source_incomplete_lines_unattributed': stream['incomplete_lines']})

frames = [frame(item) for item in state_items]
with (OUT / 'state-facts.jsonl').open('w') as handle:
    for value in frames:
        handle.write(json.dumps(value, ensure_ascii=False) + '\n')

endpoints = []
group = []
key = None
attempts = collections.Counter()
previous_turn = {}
for value in frames:
    pair = (value['run'], value['floor'])
    turn = value['turn']
    if isinstance(turn, int) and turn > 0:
        old = previous_turn.get(pair)
        if old is not None and turn < old:
            attempts[pair] += 1
        previous_turn[pair] = turn
    value['attempt_inferred_from_turn_reset'] = attempts[pair] + 1
    new = (value['run'], value['floor'], attempts[pair], value['turn'], value['screen'])
    if new != key and group:
        endpoints.append({'key': key, 'first': group[0], 'last': group[-1], 'frames': len(group)})
        group = []
    key = new
    group.append(value)
if group:
    endpoints.append({'key': key, 'first': group[0], 'last': group[-1], 'frames': len(group)})
write('turn-endpoints.json', endpoints)

decisions = []
for item in decision_items:
    row = item['row']
    decisions.append({'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
                      'run_id': item['run_id'], 'row': {k: v for k, v in row.items() if k not in ['state', 'options', 'questions', 'raw']}})
with (OUT / 'decision-facts.jsonl').open('w') as handle:
    for value in decisions:
        handle.write(json.dumps(value, ensure_ascii=False) + '\n')
write('evidence-verification.json', verification)
write('evidence-schema.json', {name: list(items[0]['row']) if items else [] for name, items in
                              {'states': state_items, 'decisions': decision_items, **other_items}.items()})
print(json.dumps({'streams': verification, 'state_frames': len(frames), 'turn_groups': len(endpoints)}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-204302'
SCRATCH = ROOT / 'learner/runs/20261016-204311-be49f09c-e819-4b99-ab6e-f807a25cb527-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261016-194027-2206e94f-eabf-4488-a294-e774aaf7adf9-fix-batch'
EXPECTED_BASE = 'b6831d57742f707c3970d197d30b856316cf0835'


def git(*args, tree=TREE):
    return subprocess.check_output(['git', '-C', str(tree), *args], text=True).strip()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


# Historical verdicts are reused only after verifying the corresponding current bytes.
checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
base = git('rev-parse', 'HEAD')
assert base == EXPECTED_BASE, base
assert not git('status', '--porcelain=v1')
prior_raw = (PREVIOUS / 'audit.json').read_bytes()
prior = json.loads(prior_raw)
prior_result = json.loads((PREVIOUS / 'result.json').read_text())
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live')
base_ancestors = set(git('rev-list', base).splitlines())
live_ancestors = set(git('rev-list', live).splitlines())
source_changes = [path for path in git('diff', '--name-only', prior['base'], base).splitlines()
                  if path.startswith(('agent/', 'learner/', 'ops/', 'eval/', 'knowledge/builders/'))
                  and path != 'ops/inbox-dev.md']
assert not source_changes, source_changes
files = []
for old in prior['current_files']:
    relative = Path(old['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    assert relative.name != '.env' and not relative.name.endswith('.env')
    assert relative.parts[0] in ('agent', 'ops', 'learner', 'knowledge', 'eval')
    current_sha = digest((TREE / relative).read_bytes())
    assert current_sha == old['sha256'], str(relative)
    files.append({'path': str(relative), 'sha256': current_sha, 'same_as_prior': True})
fixed = []
additional_fixed = [
    {'item': 'fix-batch任务模板：旧队列路径和v3合入说明', 'commit': '5805dd187b7913a53b9e2645f40db1657eb5213c'},
    {'item': '知识前缀：房间回血说明混入铁甲专属遗物', 'commit': '6d2de57ceae3def4caf073951ed9d2f9d1544cd7'},
]
for old in prior['existing_fixes'] + additional_fixed:
    commit = old['commit']
    assert commit in base_ancestors and commit in live_ancestors, old
    fixed.append({**old, 'ancestor_in_base': True, 'ancestor_in_live': True,
                  'subject': git('show', '-s', '--format=%s', commit)})
focused = []
for old in prior['focused_source_review']:
    lines = (TREE / old['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if old['anchor'] in line]
    assert found, old
    focused.append({'path': old['path'], 'anchor': old['anchor'], 'lines': found})
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
queue_lines = queue.decode().splitlines()
previous_queue = (PREVIOUS / 'queue-readonly-snapshot.md').read_bytes()
assert digest(previous_queue) == prior['queue_sha256']
assert queue.startswith(previous_queue)
added = queue[len(previous_queue):].decode()
assert 'silent-0332 原B2同题复现/诊断接线缺口' in added, added
assert all(not line.startswith('- ') or 'silent-0332' in line for line in added.splitlines()), added
unchecked = [(i + 1, line) for i, line in enumerate(queue_lines) if line.startswith('- [ ]')]
assert unchecked == [(row['line'], row['item']) for row in prior['queue_dispositions']]
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)
raw_refs = []
for old in prior['raw_original_references']:
    relative = Path(old['source'])
    assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'logs'
    with (ROOT / relative).open('rb') as handle:
        handle.seek(old['offset'])
        raw = handle.read(old['bytes'])
    assert digest(raw) == old['sha256'], old
    json.loads(raw)
    raw_refs.append({**old, 'sha256_verified': True, 'json_parsed': True})
receipt_path = ROOT / 'paper/materials/20261016-2029-ops/0332-r3-registration-receipt.json'
receipt_raw = receipt_path.read_bytes()
receipt = json.loads(receipt_raw)
assert receipt['request_id'] == 'silent-0332' and receipt['revision'] == 3
assert receipt['registration']['state'] == 'running'
assert receipt['actual_batch']['task'] == 'strategy-proposal'
assert receipt['actual_batch']['learning_request'] == 'silent-0332'
assert receipt['owner']['thread'] == '01a14446-c89c-7223-b9ff-4ad093ccc130'
assert receipt['same_parent_owner_thread_lease'] is True
input_path = ROOT / receipt['input']['path']
assert digest(input_path.read_bytes()) == receipt['input']['sha256']
health_path = ROOT / 'paper/materials/20261016-2029-ops/module-health-readback.json'
health_raw = health_path.read_bytes()
health = json.loads(health_raw)
assert health['run_id'] == 'YZWV37N2MU6N'
evidence = health['computation']['evidence']
selected = evidence[:3] + evidence[-3:]
new_refs = []
for row in selected:
    source = row['source']
    with (ROOT / 'logs/decisions.jsonl').open('rb') as handle:
        handle.seek(source['offset'])
        raw = handle.read(source['length'])
    assert digest(raw) == source['sha256'], source
    value = json.loads(raw)
    new_refs.append({'source': 'logs/decisions.jsonl', 'offset': source['offset'],
                     'bytes': source['length'], 'sha256': digest(raw), 'json_parsed': True,
                     'label': row['label'], 'floor': row['floor'],
                     'scope': '核原0332同链新证据；不推断根因或当前任务进度'})
assert not git('status', '--porcelain=v1')
audit = {
    'checked_at': checked_at, 'base': base, 'main_merge': 'Already up to date.',
    'prior_audit': str(PREVIOUS / 'audit.json'), 'prior_audit_sha256': digest(prior_raw),
    'live_read_only_snapshot': live, 'source_changes_since_prior': source_changes,
    'current_files': files, 'existing_fixes': fixed, 'focused_source_review': focused,
    'queue_sha256': digest(queue), 'queue_lines': len(queue_lines), 'queue_append': added,
    'unchecked_entries': len(unchecked), 'queue_dispositions': prior['queue_dispositions'],
    'raw_original_references': raw_refs, 'new_0332_original_references': new_refs,
    '0332_owner_registration': {'path': str(receipt_path.relative_to(ROOT)), 'sha256': digest(receipt_raw),
                               'revision': 3, 'batch': receipt['actual_batch'],
                               'native_first_reply_not_verified': True},
    '0332_health_source': {'path': str(health_path.relative_to(ROOT)), 'sha256': digest(health_raw)},
    'scope': '只读去重；无新增源码/测试/提交/账本状态/live改动；历史绿不冒本批测试结果',
}
save('audit.json', audit)
result = {**prior_result, 'base': base, 'fixes': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
for row in result['skipped']:
    if row['item'].startswith('silent-0332'):
        row['reason'] = ('证据不足；成功首战非正HP根因未明；最新YZWV37N2MU6N F48的B2截断已交原'
                         'revision3/203731/thread01a14446同一owner补诊断。原六提案保持，'
                         '不重复领取、放宽正HP/300或将诊断当根修复。')
save('result.json', result)
lines = [
    '## 修 bug 回报', '',
    f'- 合并基线：main → {base}（开工干净，先合main，无冲突，Already up to date.）',
    '- 修复（每条一行）：无新增纯bug；42条未勾选条目与前批原文一致，'
    f'{len(files)}个相关源码/测试/脚本SHA一致，{len(fixed)}项既有修复是当前base及所核live祖先。'
    '最新0332 B2诊断缺口已由原owner接续；未改源码、未提交，撤修复红绿验证不适用。',
]
for row in fixed:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['commit']}（仅既有窄子项，更宽父项保留）")
for row in result['skipped']:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines.extend([
    '- 测试：tsc未运行，退出码null；vitest未运行，0文件 / 0用例 / 退出码null；无重跑。'
    '无代码改动、提交或合入，不重复跑未变源。16条原日志只读SHA/JSON核验不当生产测试。',
    f'- 合入：未合入（无新增提交）；live只读快照 {live}。',
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'base': base, 'live_snapshot': live, 'unchanged_files': len(files),
                  'verified_existing_fixes': len(fixed), 'unchecked_entries': len(unchecked),
                  'raw_log_rows_verified': len(raw_refs) + len(new_refs), 'skipped': len(result['skipped']),
                  'source_changes_since_prior': source_changes, 'report': result['report']}, ensure_ascii=False))

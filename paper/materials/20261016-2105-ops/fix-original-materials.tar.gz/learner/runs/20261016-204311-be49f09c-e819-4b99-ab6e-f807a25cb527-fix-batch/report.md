## 修 bug 回报

- 合并基线：main → b6831d57742f707c3970d197d30b856316cf0835（开工干净，先合main，无冲突，Already up to date.）
- 修复（每条一行）：无新增纯bug；42条未勾选条目与前批原文一致，389个相关源码/测试/脚本SHA一致，83项既有修复是当前base及所核live祖先。最新0332 B2诊断缺口已由原owner接续；未改源码、未提交，撤修复红绿验证不适用。
- 已被别人修掉的：silent-0254：无动作死亡战斗归因 — 3b48088dec5fc6eafe576a1296bbdadde43432ee（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：codex-usage-credit-baseline-recovery：额度窗口恢复基线 — 5b56a452bb9be14d620b368ec46974c1b57901ca（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ascension-up：请求进阶误报为实际进阶 — 8045d9fbf0a12523b1dbe39bbed8af06c7497b09（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout — bae9c45ccffefb284a1c6634526c8768a9f5f7a8（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-ledger-status-prefix-git-divergence — dd478f0b3e5a0f234f082972d21b203dbf8229d7（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-legacy-continuation-notice-ack-identity — 368fccabd42eb72ffcea9a2fe6cbbb7c149326be（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-paper-krane-recorded-line-timeout — befc39e5ca0105f8ff96d47f817df44f0b2760f1（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-learner-event-log-second-collision — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：strategy-proposal：报告 scratch 归属 — 5f04139cefe5c651dd5bf62f7e164014dbf5f23b（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0459：独立 run-plan 请求成本漏计 — 799a5cd0caf9329b43c32376079218a9bd0c3e9e（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：run-plan 证据提取未识别 run 字段 — 78e9b05929366d097a728761d693d790ff16ac87（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：postmortem-capacity-failure-proposal-repair-20261013 — 3fdcd77927f01b35c20c6c5c1fcfd790676032d2（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：blocked-experience-proposal-repair-dispatch — 84366ad06ee4f978394c1b9489a82c83ea12bd36（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：普通 ACK — 672e198a4730012330f599068a0ef1efadb02002（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 — 1594def2e1b65b665d3b345f31444194eb4d09e6（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 — 15eb85e2934e428c5e299fc4a1aba456d92fd685（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：feature 通知来源身份校验 — 38b2f572d90b3b97a23f9eae983f583287492f9a（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：feature/B4 通知来源桥接 — 1dd4d434aef67f1d065dbdba23a875ae82741a88（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：batch-f：包装/参数化测试超时静态解析 — 56c256dad0d33b231b82b53113d3bdd84f9bfa20（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：unassigned-strategy-proposal-resolution — 3a98e213a826e94f9708af4b1a265e1892659f4e（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval 固定历史输入 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-fixed-test-timeouts-010547：Apotheosis 有界夹具 — 9e8c93555131c3347f9e809d9722a848a75c2692（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：compute-memo-worker-data-signature — 8fbb441eb61eef226eb7366f9612003480c83988（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：rollout-live-best-test-determinism — bbc5b993a7524bbb8e80a975f204f8d193657b46（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-targeted-check-continuation：已过覆盖的精确续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：sandbox-glob-startup-race：会话前有界恢复 — bc2c40e313cc36682196277c53c50e30744b88c5（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：sandbox-glob-startup-race：复盘租约绑定 — d9983263ffecea1bed4e29d65e7f854a3d2e33d7（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：core-cycle-implementation-binding-entry — fc95760d4ff8a9cbd45577efdd79b1215bd2cb92（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-20261012-quantitative-continuation — b408252f87a77ee5389c4d90e52a9831c0873348（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：named-card-facts-transport：已批准的事件入口子项 — 42c920f34d9dc1c783ce894659849ab37ed6fd1b（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：core-build-notify-222802-rc2：保留原生失败诊断子项 — 5c92f2aaf0b758a1a5e7d591745694004664f83a（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：paper-dataset-git-consistency-race — 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：boss-sim-codex-home-preflight — 5921f8cd045853182c867a6430e75c3fcde00a87（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：shared-experience-fixed-filesystem-snapshot-20261013 — 8390c62d76fc8c7d7b6b7292121a621f4666d39c（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） — ec8c578b66bf5498372f1b779ae58a766dff8112（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：首项异步夹具 — 95e7f050ef2abe5c85a0367555392652ad73fbfe（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：固定失败诊断 — 9b6459fd99f26b17689134e33aa85d6190e71d7d（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：batch-c-fixed-fixture-timeout — 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：晚写复盘误计为上线后重犯 — 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：学习账本 first_run/asc/prior_note 追加更正 — 87c89b7aea90c7275e0fbb04b1e4148a4209630c（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：subscription-usage：未设置 TMPDIR — 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：deepseek-prompt-dump：状态日志反向流式扫描 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：固定药水测试隔离 — e78352f784d39cf25671446348daaada6ef2060b（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：单次 mod 超时 stall 误报 — a4f4ec868d122dc92af510862c6240cf2eaff2b6（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：学习状态锁被完整检查阻塞 — 233ede56047274ba53a4e1191a245fac816c37a8（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：学习者受阻后兜底完整检查入口 — f670884a188a047bbd3f7f007c260ade62fae36a（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：策略任务及自动派发入口 — afd652a3f75df6e7403439f01c565220327884da（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：旧事件选项重复问大脑 — 25ce09bee5576b1adff8baf196fbe8b197a5ef11（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0153：普通隐秘匕首生成分支 — b7f081fcc26da4506cb775739bb118cb6cbe4ecc（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0256：已观察的狡诈药水容量子项（实际源码提交） — 6403fdcdadc803a092beb5165a068e22bf51c412（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0260：普通紧勒逐牌失血 — 5c7105ff0294466da8319f2934beda05c6040794（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0263：已观察的碾碎爪转向取整子项 — ec29ea34b919344b707e57ba472ea210f9c39d62（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0266：SL 首牌身份 — e784dd9f043bf87c29109573f48975f9903280d3（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0272：商店移除预览与真实选牌页核对 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0324：普通刀舞生成小刀 — 66c22ba7d87b8748690a4183fff838acd346bd3e（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0338：回合末防御事实来源注记 — c1d84804956bedbd29a7f0e81294114e18415b9d（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0367：已用蜥蜴尾巴事实接线 — 5baf663d7e6678efa3690e5a48329c4f8baee109（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-learner-launch-shared-main-config-race — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：固定时间夹具 — b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：续验拒绝诊断 — 63f656fb07a21a7496353234269901a832eae497（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-worktree-history-disk-pressure：broker容量/回执失败隔离 — a136ddc4b5b0a8696f10b2fae3073322d57e724c（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-worktree-history-disk-pressure：无终态标记退出 — db072ddab47ba94efb46dce2913927f936ecb97e（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-worktree-history-disk-pressure：JSONL追加边界 — 9b07240b18f862efdbe630889ade04e8976eaace（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：ops-worktree-history-disk-pressure：历史副本/按需恢复 — c7a6efb1e15ed6c5f31a35ae3ee9833863340393（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：tracked-source Python缓存回收认定 — 1e8af775f6b90f100f20ff7c4a08dfddaba893a9（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：完成报告裸JSON兼容 — 6f86ff6b6b971fb38b96308ebdd34dec574e5b13（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：autoplay安全热交接动作 — 71b835a3150704548fab2ad46e74bde240ccf1f9（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：历史测试入口漏传日志回调 — ccd8bb8e017da9c30b408138d04e6d2bc985836d（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：额度警告固定测试契约 — 1cf0490492bd8a430b85f95f3fdee91eba251191（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：有限结束报告与补验交接 — 2c4ce406c9ae598835f22292e52cfd936ac10b14（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-checks-broker-push-registration — c519952b31e3a0bb3acdd2115883ae8671b8a090（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：host-checks-session-exit-fixture — 874ae603b3927173f805e0b2fe789330bab710c7（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：v5-dpr-health：明确不支持的候选被误计为DPR交付失败（仅分类子项） — 9e6dd82a34fb8c14e012be68fd0b632544f1459f（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：sandbox-glob-startup-race：父注册事务保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0469：已观察聚合体纸鹤组合子项 — 8d386fc7668820c2fc387d966f9d94bdcab189fb（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0317：已观察A10升级计算下注子项 — b49112dbc106e315bd7156361d290fc4c73d29e2（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-0319：已观察A10两费十毒预览子项 — 5b56a452bb9be14d620b368ec46974c1b57901ca（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-feature-root-event-notice-path — 577f0bc424b7287910735cfdc86c253cc7ee8057（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：silent-route-projection-provenance 诊断子项 — 7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-global-build-fixed-loadavg-input — 5bc8f025fe043cb8738cce57870354fa23fa84a1（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：infra-stall-between-run-quiet：正常完局报告期间的静默误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：fix-batch任务模板：旧队列路径和v3合入说明 — 5805dd187b7913a53b9e2645f40db1657eb5213c（仅既有窄子项，更宽父项保留）
- 已被别人修掉的：知识前缀：房间回血说明混入铁甲专属遗物 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7（仅既有窄子项，更宽父项保留）
- 没修的：silent-0271：毒必胜提前返回遗漏保血候选 — 策略类；沿原独立提案，不在纯bug批改排序。
- 没修的：silent-0279：SL抽序升级改标 — 策略类；沿原独立提案，缺完整中间帧。
- 没修的：silent-0308：单动作沙坑截止题面 — 策略类；当前漏接仍在，沿原0ff91bb5da98a252/3707a98930a03d83链，不重复派发。
- 没修的：silent-0311：库存恢复血量预算 — 策略类；沿原独立提案，保留已观察与未知恢复规则边界。
- 没修的：silent-0320：同线新建UNMOVABLE — 策略类；沿原689c132e17b5c70f实现链。
- 没修的：silent-0322：升级神化同线升级 — 策略类；沿原53b3db220508b3d9实现链。
- 没修的：silent-0329：饮药临时力量接线 — 策略类；沿原角色证据及独立提案链。
- 没修的：arch-funnel-guard — 太大；独立架构功能，不混入普通纯bug批。
- 没修的：arch-learning-priority — 太大；独立架构功能，不混入普通纯bug批。
- 没修的：arch-unified-resource-value — 太大；独立资源模型功能，不混入普通纯bug批。
- 没修的：inv-f33-regression — 太大；独立归因调查，保留原owner。
- 没修的：silent-0332：成功首战接续nonpositive-hp — 证据不足；成功首战非正HP根因未明；最新YZWV37N2MU6N F48的B2截断已交原revision3/203731/thread01a14446同一owner补诊断。原六提案保持，不重复领取、放宽正HP/300或将诊断当根修复。
- 没修的：silent-0334：升级隐秘匕首模型 — 策略类；沿原6a5c67f606bd5af7实现链。
- 没修的：silent-0339：尾巴误核销 — 策略类；沿原独立提案，不凭近似血量补复活规则。
- 没修的：silent-0344：坚韧之环延迟格挡 — 策略类；沿原8e17a61707d2ca02实现链。
- 没修的：silent-0347：组装师攻击召唤 — 策略类；沿原43156dee9f23ae43实现链。
- 没修的：silent-0349：已有虚弱后的减力 — 策略类；沿原bb7597d8a1fe63ff实现链。
- 没修的：core-build-notify-222802-rc2：历史发送事实 — 证据不足；后续失败诊断已修，旧历史发送事实仍未知，不冒认成功或重复发送。
- 没修的：silent-0362：背向攻击减力倍率 — 策略类；沿原独立角色证据提案链。
- 没修的：silent-0365：未建模药水目标可达性 — 策略类；当前targets.slice(0, 2)仍在，原70c22e94eda8f8a9/3adbcaf2f490177f已登记独立实现链。
- 没修的：框架外层时限与分段续验收尾 — 太大；精确续验入口已实现，框架所有者收尾仍沿原链。
- 没修的：调度公平性核查 — 证据不足；原观察未证明永久饥饿，沿原框架核查。
- 没修的：silent-0481：技能药水生命周期措辞 — 策略类/题面知识；当前措辞仍在，沿686d4e759478eebb/c89465046641d6ed，不自行补生命周期规则。
- 没修的：silent-0487：MAD_SCIENCE三段攻击模型 — 策略类；沿原0a0b31e284e6793e实现链。
- 没修的：codex大脑缓存命中偏低 — 证据不足；缺当前同题受控请求对比，本任务不调用真实LLM或网络。
- 没修的：sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因 — 证据不足；注册保存屏障已上线，上游目录归属和完整生命周期仍未知。
- 没修的：named-card-facts-transport：事件入口之外范围 — 太大；事件入口已修，其余独立功能沿原owner。
- 没修的：boss模拟样本性能及v5-dpr-health宽范围 — 太大；独立专项，保留冻结输入、预算、样本及原验收链。
- 没修的：rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构；沿原2d3aa8dfb27dbe3f，不提交未确认动作。
- 没修的：silent-0469：纸鹤其他未知组合/整战收益 — 策略类；已观察聚合体窄子项已修，更宽组合与整战收益未闭合。
- 没修的：silent-0496：取牌页零选确认及Cards误作抽牌 — 策略类；原0cd2f0dfbc4a0805/0496/0418已登记，当前入口仍在，不重复派普通fix。
- 没修的：silent-0461：脆弱4挡斗篷生成条件 — 策略类；普通6挡窄子项不覆盖本条件，沿f4eb0efba2594252/7338be2498f3ae60，不将未实际施放候选当机制实证。
- 测试：tsc未运行，退出码null；vitest未运行，0文件 / 0用例 / 退出码null；无重跑。无代码改动、提交或合入，不重复跑未变源。16条原日志只读SHA/JSON核验不当生产测试。
- 合入：未合入（无新增提交）；live只读快照 e1abf7aa9cc69852ff1c954242a8fa36f127bc2f。
- 需要 Roy 定的事（没有写「无」）：无。

```json
{
  "task": "fix-batch",
  "base": "b6831d57742f707c3970d197d30b856316cf0835",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0271：毒必胜提前返回遗漏保血候选",
      "reason": "策略类；沿原独立提案，不在纯bug批改排序。"
    },
    {
      "item": "silent-0279：SL抽序升级改标",
      "reason": "策略类；沿原独立提案，缺完整中间帧。"
    },
    {
      "item": "silent-0308：单动作沙坑截止题面",
      "reason": "策略类；当前漏接仍在，沿原0ff91bb5da98a252/3707a98930a03d83链，不重复派发。"
    },
    {
      "item": "silent-0311：库存恢复血量预算",
      "reason": "策略类；沿原独立提案，保留已观察与未知恢复规则边界。"
    },
    {
      "item": "silent-0320：同线新建UNMOVABLE",
      "reason": "策略类；沿原689c132e17b5c70f实现链。"
    },
    {
      "item": "silent-0322：升级神化同线升级",
      "reason": "策略类；沿原53b3db220508b3d9实现链。"
    },
    {
      "item": "silent-0329：饮药临时力量接线",
      "reason": "策略类；沿原角色证据及独立提案链。"
    },
    {
      "item": "arch-funnel-guard",
      "reason": "太大；独立架构功能，不混入普通纯bug批。"
    },
    {
      "item": "arch-learning-priority",
      "reason": "太大；独立架构功能，不混入普通纯bug批。"
    },
    {
      "item": "arch-unified-resource-value",
      "reason": "太大；独立资源模型功能，不混入普通纯bug批。"
    },
    {
      "item": "inv-f33-regression",
      "reason": "太大；独立归因调查，保留原owner。"
    },
    {
      "item": "silent-0332：成功首战接续nonpositive-hp",
      "reason": "证据不足；成功首战非正HP根因未明；最新YZWV37N2MU6N F48的B2截断已交原revision3/203731/thread01a14446同一owner补诊断。原六提案保持，不重复领取、放宽正HP/300或将诊断当根修复。"
    },
    {
      "item": "silent-0334：升级隐秘匕首模型",
      "reason": "策略类；沿原6a5c67f606bd5af7实现链。"
    },
    {
      "item": "silent-0339：尾巴误核销",
      "reason": "策略类；沿原独立提案，不凭近似血量补复活规则。"
    },
    {
      "item": "silent-0344：坚韧之环延迟格挡",
      "reason": "策略类；沿原8e17a61707d2ca02实现链。"
    },
    {
      "item": "silent-0347：组装师攻击召唤",
      "reason": "策略类；沿原43156dee9f23ae43实现链。"
    },
    {
      "item": "silent-0349：已有虚弱后的减力",
      "reason": "策略类；沿原bb7597d8a1fe63ff实现链。"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足；后续失败诊断已修，旧历史发送事实仍未知，不冒认成功或重复发送。"
    },
    {
      "item": "silent-0362：背向攻击减力倍率",
      "reason": "策略类；沿原独立角色证据提案链。"
    },
    {
      "item": "silent-0365：未建模药水目标可达性",
      "reason": "策略类；当前targets.slice(0, 2)仍在，原70c22e94eda8f8a9/3adbcaf2f490177f已登记独立实现链。"
    },
    {
      "item": "框架外层时限与分段续验收尾",
      "reason": "太大；精确续验入口已实现，框架所有者收尾仍沿原链。"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足；原观察未证明永久饥饿，沿原框架核查。"
    },
    {
      "item": "silent-0481：技能药水生命周期措辞",
      "reason": "策略类/题面知识；当前措辞仍在，沿686d4e759478eebb/c89465046641d6ed，不自行补生命周期规则。"
    },
    {
      "item": "silent-0487：MAD_SCIENCE三段攻击模型",
      "reason": "策略类；沿原0a0b31e284e6793e实现链。"
    },
    {
      "item": "codex大脑缓存命中偏低",
      "reason": "证据不足；缺当前同题受控请求对比，本任务不调用真实LLM或网络。"
    },
    {
      "item": "sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因",
      "reason": "证据不足；注册保存屏障已上线，上游目录归属和完整生命周期仍未知。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外范围",
      "reason": "太大；事件入口已修，其余独立功能沿原owner。"
    },
    {
      "item": "boss模拟样本性能及v5-dpr-health宽范围",
      "reason": "太大；独立专项，保留冻结输入、预算、样本及原验收链。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构；沿原2d3aa8dfb27dbe3f，不提交未确认动作。"
    },
    {
      "item": "silent-0469：纸鹤其他未知组合/整战收益",
      "reason": "策略类；已观察聚合体窄子项已修，更宽组合与整战收益未闭合。"
    },
    {
      "item": "silent-0496：取牌页零选确认及Cards误作抽牌",
      "reason": "策略类；原0cd2f0dfbc4a0805/0496/0418已登记，当前入口仍在，不重复派普通fix。"
    },
    {
      "item": "silent-0461：脆弱4挡斗篷生成条件",
      "reason": "策略类；普通6挡窄子项不覆盖本条件，沿f4eb0efba2594252/7338be2498f3ae60，不将未实际施放候选当机制实证。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "files": 0,
    "cases": 0
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-204311-be49f09c-e819-4b99-ab6e-f807a25cb527-fix-batch/report.md"
}
```

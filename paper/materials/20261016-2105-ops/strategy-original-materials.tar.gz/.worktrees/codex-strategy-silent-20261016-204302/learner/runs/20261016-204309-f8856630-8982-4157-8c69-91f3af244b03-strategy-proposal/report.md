# 静默猎手十项策略提案复核

记录：2026-10-16 20:54:23 CST；batch=20261016-204302-strategy-proposal。

本批十项全部waiting。没有新增源码/知识修改、提交、live合入、行为版本或shipped；已有局部实现保留，未把子实现当整项完成。

## 身份与范围

开工git status干净，HEAD=b6831d57742f707c3970d197d30b856316cf0835。本批只读根learn.json对应行，task=strategy-proposal、character=silent、reason=proposal、worktree匹配，十个proposal_ids与本报告一致；无research_request、implementation_request、proposal_repair。普通匹配文件绑定其他批次，因此本批不承接专题。按要求git merge --no-edit main，Already up to date；report.base保持完整40位真实HEAD。

派发五局NHA2KW0RB7VP、P74C04AEPL1F、G33HU22H2543、RC61MFQM63Y6、BTSRF7JL1W1Y全部经runs.jsonl确认SILENT/A10，见run-identity.json及evidence-runs/。仅处理这十项，未领取其他队列、请求或其他角色知识。十份Markdown全部匹配注册SHA，另存原字节；32个关联账本均为silent。

## 原始证据与材料检查

复用前批共用extract_evidence.py生成的六流冻结封套，并对每行seek只读原日志，核offset/bytes/SHA/JSON与显式身份及source_size界限，共6601行：states3238、decisions3138、sl-attempts31、run-config5、run-plans26、brain163。逐流原路径/source_size/计数/封套SHA见evidence-reuse-audit.json，全部逐行索引保存raw-evidence-index.jsonl。本批未冒称重新全量扫描或从日志正文提及推断所属局。

run-plans另经本工作树共用CLI用原source-size8577226重提取，26行及输出SHA与旧封套一致，输出独立保存在evidence-plans/；另用共用CLI提取runs五行。旧报告、零行初稿及失败原件不覆盖。旧manifest中states/decisions各2无效行、brain1无效行未当本批证据，也不能据此归为本批产品问题。未检查fight-plans，不宣称有无该流证据。

review_materials.py最终16项材料事实检查、两组T1四个实际分支均通过，见material-checks.json和t1-comparisons.json；decisions原问题/答案及预算保存在decision-readback.json，局部原始封套observed-windows.json，状态投影bounded-state-projections.json。它们是材料核算，不是生产测试或样本外校准。

RC61的279021/279197同指纹，但预算为3轮2样本/5轮24样本。BTS的279852/279854抽弃前后预算为3轮/5轮各4样本且改了目标；一次3/4样本线死亡不能据此证明模型错误。原config给出完整源码commit/dirty_files和知识prefix SHA，但当时dirty知识/移动表原字节没有重建；本批现源码和知识不能冒充原运行输入。

本批材料脚本三次失败保留：r1误用毒结算前284820读取卵剩血，实际毒后2血在284821；r2把会收缩的敌数组位置当固定实体位置，后改按SLUMBERING_BEETLE身份取值；r3状态投影未容纳离战combat=null。最终r4成功。原脚本副本、各轮stdout/stderr全部保留；这些是本批离线读取器错误，不是新游戏机制反证或生产源码bug。只读路径探针未找到文件也未作为产品故障。

## 当前源码和实际live有限覆盖

源码核验时live=c783c6c83d09e669f49518a4536ae5bc3766c2a2。本批14个相关源码叶全部与前批base 60dc9008b5b7e256d7f50dbbe8aa36945a3dcc12 同字节；其中10叶与实际live物理文件相同，4叶仅历史Roy/Dai署名注释差，见source-audit.json及base-live-source.patch。previous-base-source.patch为空，未据这些叶推断全部运行知识或历史dirty输入一致。

- 1dab14da481fe7951d9020dba52ad0ebebb1029b：并列组即时损血参考，接入combat-plan，仍不是整战收益或SL新门槛。
- e784dd9f043bf87c29109573f48975f9903280d3：静默已观察投斧首牌身份。
- bf423c173d3be348a4ad714e1d26516df619ff41：普通生存者唯一单弃删除后继；多个候选仍未知。
- 97efc0618936c6d7783fbf36e79b056b90d65589：暂停计划后继和条件预测。
- 4b0823f519f1b724d6cff2b1cd50b74146dc4a9d：弃牌候选保留手牌/当前费用/独立能量事实，明确不解弃后动态结果。
- 1698adc96ba434a46942321e0237b70657e625b2：SL资源比较，标current_turn_prediction与execution=unverified；随机药中位/缺线不作数值差。

上述六项均由本批核为当前base和实际live祖先。2a62f327d508201d9982983ec2c930789065ece5同为祖先，仅说明局部事实通道存在。5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56及f34700874c9f48b614991f769532115a0f24f27b不是实际live祖先，不拿侧支登记实现。当前探索仍按B2/notWorse或rollout deathShare及原排名选择，资源字段没有把受控整战缺口补齐。

没有本批证据能独立定位的新源码差额；不重复实现已覆盖子功能，也不把完整校准缺口改成固定游戏规则。铁甲及其他角色行为没有变化。未修改知识构建脚本，不重建或消费刷新知识来充固定输入。

## 逐项处置

## silent-proposal-9952ee8e8df9a0fe

SL零胜率换线须显式核即时血价和击杀推进，路线/营火实际回复与存档恢复分账；证据不足保留门槛

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0019, silent-0020, silent-0065, silent-0264, silent-0079。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-resources.md；SHA256：4641badee4b0dfb956e91f12e20e20a5ecbc5c31905f8e0c84da1429de4d9800。本批另存同名.md.txt原字节。

证据：NHA2KW0RB7VP A10 F33第1/6试T1—T2：30血同首手，实损1/7、敌净扣8/24，见sl-attempts 987/992及t1-comparisons.json。即时差额为多损6、多扣敌16。

处置：waiting。即时损血参考已有live子实现；缺同抽序、同预算、同后继的整战对照及累计能力、路线和留药受控后继，不足改SL或终局权重。

反例与限制：替线增加输出同时增加损血；六次属于同一局，全部失败不能证明某线一般更差。原资源统计只按原提案引用，本批未重算历史营火统计。

预期行为：保持既有门槛；将当前血价与已结输出分别核验，未来能力、未到营火和存档恢复分账。

验证方法：固定同指纹两线，在相同预算下保存完整执行、抽弃和整战后继，再按独立局时间切分验证。

## silent-proposal-47be799a87af03be

静默已观察单张弃牌题核对正在执行计划、逐敌来袭和每个合法弃牌分支，保留未实打的反事实限制

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0205。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-011301-postmortem/proposal-discard-plan.md；SHA256：25870eb9a6d5482193ebe5f06d7071794e13bc8a43f293d8bcdfb7700377b6e1。本批另存同名.md.txt原字节。

证据：P74C04AEPL1F A10 F23第4试T3：states284817为1血16挡，284818精确切击离手，284821卵2血而玩家归零；decisions278542—278546保留原计划及重问。

处置：waiting。弃牌计划提示及手牌快照已有live子实现；缺动态牌面、弃牌触发、目标和续步剩血的完整合法分支验证，未隔离新数值失配。

反例与限制：首试卵已在早一轮结束，第三试原线不同；没有保留精确切击后的完整实打胜局，不能规定一律弃贪婪。

预期行为：保持全部合法候选，显示会删除的后继和未知项；弃后重新读取动态费用及牌面。

验证方法：逐候选核费用、手牌变化、触发、目标、来袭和剩血；未实打保留分支只能标模拟。

## silent-proposal-3a5274da3c42672a

核证多敌失衡与召唤复活、一次格挡翻倍、滑溜下火焰／毒与普通触媒兑现，保留获胜战到下一战的真实资源和缺帧限制

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-011301-postmortem/proposal-group-resource.md；SHA256：6ae654a5dabe769d49545bf1f10fb61e82539939c4cca5acfa20e518cf19cf05。本批另存同名.md.txt原字节。

证据：P74C04AEPL1F A10 F17T1火焰182→181且滑溜8→7（states284630/631），T2两次毒只扣2；F22T2/T4各损20/24、53→9并以9血进入F23；寄生0→21，F23石虫眩晕与卵仍击杀同时成立。

处置：waiting。已有局部模型；缺主怪最后死亡中间来源帧及药水、幻象复活、逐敌失衡和下战资源的联合消费者回放，未隔离新源码差额。

反例与限制：F22奖励后9血成立，主怪死亡最后来源仍缺；净本体减少不等于完整需伤，下一战失败不证明杀序错误。

预期行为：逐敌、逐来源、一次触发和战后入口分开核对，缺失来源保留未知。

验证方法：以F17火焰/毒、F22复活/损20和24、F23石全挡而卵存活的固定帧核联合消费者；补足执行归属后再认证整项。

## silent-proposal-bc4b92d590f2c4ce

保留投斧首牌顺序身份、弃牌后重核计划和能力实际兑现；候选与完整实线分账

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-014012-experience-update/proposal-replay.md；SHA256：d99922d67f03f38fdf7a3df2a604a1be63a3d0bf1b98f3f2f4d6d42e58f29725。本批另存同名.md.txt原字节。

证据：G33HU22H2543 A10 F48T1投斧首牌原候选见decisions277909/277954/278032；P74C04AEPL1F F23末T3弃精确后取消后继。G33末T8两敌毒实扣22/42，states284407/284408。

处置：waiting。投斧首牌身份、普通单弃及计划提示已有live窄实现；跨重规划执行归属、余像累计收益和动态弃牌联合验收仍缺，不能整项duplicate。

反例与限制：余像先候选未完整实打，药水补层不补回首牌机会；候选差异不能推出必须先铺能力或必胜。

预期行为：保留已观察的首牌身份，分开记录已执行前缀、重问后续线与能力建层和兑现。

验证方法：沿首牌未消费/已消费/缺前缀、药水、续步及宽松判重核同一身份，再将能力和弃牌真实后继配对。

## silent-proposal-f52fbbab4dccc3b4

按赢战资源消耗与下一场实入口核路线/SL/終局价值，存档恢复与真实回复分账

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-014012-experience-update/proposal-resources.md；SHA256：f6212ce1983f6d534fde0e56f7d3151fd4cb248a5413e4abdfdd9125421ed630。本批另存同名.md.txt原字节。

证据：P74C04AEPL1F A10 F22T1—T6由53到9且下战F23仍9血空药（states284730/284761/284766）；G33HU22H2543 F48末轮毒实扣22/42后仍死亡。其他营火统计仅引用原提案，不冒本批重算。

处置：waiting。缺逐来源连续资源消费者账，以及同条件路线、休息、SL或保药的受控后继；赢战消耗成立，不能拟合新HP价格或留药阈值。

反例与限制：F22获胜不表示消耗合理；原计划F24营火未抵达，未走路线与保药完整胜局未记录。

预期行为：保持现价和路线规则；实际治疗、事件付血、开场、饮药、复活及SL恢复分别记账。

验证方法：核连续两战实入口和资源传递，并补同入口同后继的路线/休息/用药对照，SL按原局分组。

## silent-proposal-10f37c0edd3d24a6

逐来源核临时减力、双重毒结算、牌挡/被动挡/翻倍、开场遗物及实际回复

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-014012-experience-update/proposal-mechanisms.md；SHA256：705dcdc07bf49426c7a645ce77875e8526cccca1e059eb1561472617611b8e52。本批另存同名.md.txt原字节。

证据：P74C04AEPL1F A10 F17T2尖啸敌力−6、T3恢复0，12毒在滑溜下两结仅扣2（states284634—284636）；F23T3生存者16挡未挡卵8；G33HU22H2543 F48T8两敌毒扣22/42。

处置：waiting。缺历史刷新知识/移动表原字节，以及临时减力、毒多结算、一次格挡、开场和回复的完整组合联合回放与独立校准；未发现新可隔离失配。

反例与限制：run-config给出真实完整源码commit和dirty_files，但没有还原当时dirty知识原字节；仅定位源码不能声称已还原运行输入。

预期行为：保留已实现局部模型和未知边界，不把临时负力、未来雾、一次触发或SL恢复重复/提前计入。

验证方法：冻结当时源码和知识/移动表输入，再逐来源对齐即时结算和后续轮；未观察组合不外推。

## silent-proposal-3f82387e2e179703

双蟹同盘SL用触媒替打击实少7伤、多损4HP，全败推演并列不当同安全；先核弃牌后可达朝向与能力兑现，缺整战控制及独立验证时保留旧排序、等待新证据。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0079, silent-0027, silent-0065, silent-0080, silent-0088。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-014304-postmortem/proposal-sl-power-cost.md；SHA256：8bdf5f3c4ef752be9a4d494397f8214fc58e524f6a8c682c1a3be41bb791eab3。本批另存同名.md.txt原字节。

证据：RC61MFQM63Y6 A10 F33首/末T1同指纹52血：sl-attempts1007/1012实损4/8、敌净扣30/23；decisions279021/279197实际预算为3轮2样本和5轮24样本。

处置：waiting。同盘即时少7净扣、多损4血可核；缺同预算整战、累计能力收益及受控后继，不足修改全败SL排序或增加固定HP惩罚。

反例与限制：普通触媒3+2毒确有兑现，不能因失败否定该收益；同一题内候选预算一致不等于首末题预算一致。后轮抽弃与动作不同。

预期行为：保持SL门槛；分别展示当前血价、输出、能力已建与剩余毒，不将死亡饱和当即时等价。

验证方法：固定同指纹、同预算、同后继两线并核完整执行；将先被生存者弃掉的后继攻击排除后再比较朝向。

## silent-proposal-aee21084c991abd3

核对醒虫力量、临时虚弱、覆甲及抽弃后实际执行线的长程推演；单局3/4样本线死亡不足校准权重或规定焦点，保留原行为并交独立任务验证。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0128。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-024302-postmortem/proposal-awake-beetle-validation.md；SHA256：b5cb54be4191c956c90c7604bd5180350c139bb8c2bab3e035f8104277186d78。本批另存同名.md.txt原字节。

证据：BTSRF7JL1W1Y A10 F31T3—T4：甲虫力量2→4（states286164/286170），末14血5挡+1覆甲对22，毒后甲虫13、玩家0（286173/286174）；抽弃前后decisions279852/279854为3轮/5轮各4样本，最终已改目标。

处置：waiting。缺逐样本轨迹与最终执行线的配对校准；抽弃前后题面及目标变化，一次3/4样本候选死亡不足证明模型错误或调整权重。

反例与限制：真实覆甲1不可漏，5牌挡不是全部防护；没有实际建立灵动步法。单个死亡不推定75%纯bug或固定先杀甲虫。

预期行为：保持现有成长及排序；将原候选、抽弃后候选、实际执行和醒后力量分别记录。

验证方法：按明确实体身份核睡层/醒后力量/虚弱恢复/覆甲/毒，再对最终执行线保存逐样本轨迹和独立局校准。

## silent-proposal-df37594e9b12debf

强制单弃后取消后继攻击/转向；SL能力换线同时核即时血价与实际结算窗口

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-replay.md；SHA256：cee2c39a9643248c6df74fbaade8613c2b9fb8fb57952fa060311b7edb98fc44。本批另存同名.md.txt原字节。

证据：RC61MFQM63Y6 A10 F33第3试T4：states285414只剩生存者和打击，285415手空，45血7挡对57；同局首/末T1血价差额另见t1-comparisons.json。F17T11呼唤自损沿原提案引用，本批未新增该窗口核算。

处置：waiting。普通生存者唯一后继取消已有live祖先覆盖；跨选择整线归属、累计能力与呼唤自损的联合消费者未验收，不能以窄修复关闭整项。

反例与限制：第三试T4判死后未执行末攻击，不能报成真实损50；没有唯一可保留牌时不虚构弃牌选择。

预期行为：保留唯一单弃消费和未知多选；模型持牌失血与真实结算、候选成长与实际成长分开。

验证方法：复核普通单弃删除攻击/朝向，然后核跨选择真实施放、呼唤持牌和毒终结的先后来源及完整线归属。

## silent-proposal-42e81c83b2e1e56b

路线/休息按已兑现回复与赢战耗血核血价；存档恢复不等真实回血

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0019, silent-0020。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-resources.md；SHA256：9c9880e7b14f3e685556000992e98c20627afc63b12e7b1a359a82367c6a0a01。本批另存同名.md.txt原字节。

证据：RC61MFQM63Y6 A10 F33首/末T1实际入口52血，states285314—285321/285491—285497及sl-attempts1007/1012；营火回复、餐券、幕间和SL恢复金额仅按原保存提案引用，不当本批重算。

处置：waiting。缺同条件路线、休息和后战对照及逐来源消费者验收；52血实入口和原回复账不足建立新安全血线或终局HP价格。

反例与限制：预测与实际入口有差异不自动证明营火或路线模型错误，构筑和途中条件会变化；SL恢复的同瓶药不能当新得药。

预期行为：保持现有路线、休息和HP价；只把已完成回复计作到账资源，未来营火及存档恢复另列。

验证方法：按相同构筑/敌/间隔/资源条件追溯逐来源入口，另取路线/休息/留药完整后继；不以观察分档拟因果阈值。


## 记录、验证与运维交付

只经根learner/ledger.py update对32个原id追加本批proposal.md/report.md的where.proposal和note，by=learner:strategy-proposal。无新发现可add为proposed，故不把原shipped/accepted等状态降回proposed；不重复历史support/repeat、不改claim、first_run、prior、evidence、status、version、effect或shipped_at。实际CLI和逐字节追加审计见ledger-cli.*、ledger-update-input.jsonl、ledger-append-audit.json。proposal_results交调度器保存waiting，不直接改专用队列、不建立重复CLI id。

无生产源码修改，撤源码失败/恢复通过、tsc、vitest均未运行；tests固定为{"tsc":null,"vitest":null,"cases":null}。16项材料检查不填生产cases。没有代码提交，提交前检查及live合前/合后测试不适用；不借旧测试结果报本批成功、不造合入或eval版本。工作树tracked/index保持干净，scratch按既有ignore保留，不删自身工作树。

未运行play、LLM、boss模拟池、网络或安装依赖；无下级agent，无模型/账号/prompt配置修改。现有可用只读材料无法独立核本原生会话模型、推理强度和服务档，不声称已切换运行设置。不写无实际上线的decision-log、版本、规则双通知或shipped，不关闭原父学习要求。未发现足以新建、推翻或强行支持旧游戏结论的本批科学反证。

回退：本批没有行为变更可回退；未来如有实现，只撤对应实际源码提交并保留原日志、失败、账本及并行数据。

运维交付路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-204302/learner/runs/20261016-204309-f8856630-8982-4157-8c69-91f3af244b03-strategy-proposal/proposal.md；完整报告/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-204302/learner/runs/20261016-204309-f8856630-8982-4157-8c69-91f3af244b03-strategy-proposal/report.md；机器回报/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-204302/learner/runs/20261016-204309-f8856630-8982-4157-8c69-91f3af244b03-strategy-proposal/result.json。每个原id的具体waiting理由如下列JSON，保留等待新证据重派。

最终验收（2026-10-16 20:56:15 CST）：根ledger CLI退出0，32条本批where/note追加已逐物理offset/bytes/SHA读回，旧字节前缀及32项原claim/首证/prior/evidence/status/version/effect/shipped_at保持；notes/history/where旧前缀保持。本批材料gitleaks dir --redact退出0、未检出泄漏；此扫描不是生产测试。最终HEAD等于base、tracked/index干净，source-worktree.patch为空，十个原CLI id及waiting逐项结果校验通过。

import hashlib
import importlib.util
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WORKTREE = HERE.parents[2]
LIVE = ROOT / '.worktrees/live'
PREVIOUS = ROOT / '.worktrees/codex-strategy-silent-20261016-171301-s2/learner/runs/20261016-171306-d2ec9d10-26e2-4784-9d27-a05f6dea65d1-strategy-proposal'


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORKTREE), *args])


assigned = json.loads((HERE / 'assigned-proposals.json').read_text())['original']
proposal_audit = []
for ident, proposal in assigned.items():
    path = Path(proposal['proposal'])
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == proposal['proposal_sha256']
    (HERE / f'{ident}.md.txt').write_bytes(data)
    proposal_audit.append({'id': ident, 'path': str(path), 'sha256': digest,
                           'bytes': len(data), 'character': proposal['character'],
                           'ledger': proposal['ledger'], 'runs': proposal['runs']})
write('proposal-audit.json', proposal_audit)

prior = json.loads((PREVIOUS / 'source-readback.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = subprocess.check_output(['git', '-C', str(LIVE), 'rev-parse', 'HEAD']).decode().strip()
leaves = [entry['path'] for entry in prior['leaves']] + [
    'agent/src/reflex/silent-sl-resource-comparison.ts',
    'agent/src/reflex/silent-held-loss.ts', 'agent/src/sim/silent-opening.ts',
    'agent/src/sim/boss-sim.ts', 'agent/src/sim/route-projection.ts',
]
source = {'base': base, 'live': live, 'previous_base': prior['base'], 'commits': [], 'leaves': []}
for entry in prior['commits'] + [{'commit': '1698adc96ba434a46942321e0237b70657e625b2'}]:
    commit = entry['commit']
    source['commits'].append({'commit': commit,
        'base_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
        'live_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live]).returncode == 0,
        'subject': git('show', '-s', '--format=%s', commit).decode().strip()})
for path in leaves:
    data = (WORKTREE / path).read_bytes()
    live_data = (LIVE / path).read_bytes()
    historical = git('show', f"{prior['base']}:{path}")
    source['leaves'].append({'path': path, 'base_sha256': hashlib.sha256(data).hexdigest(),
        'live_physical_sha256': hashlib.sha256(live_data).hexdigest(),
        'previous_base_sha256': hashlib.sha256(historical).hexdigest(),
        'equal_live': data == live_data, 'equal_previous_base': data == historical})
write('source-audit.json', source)
(HERE / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *leaves))
(HERE / 'previous-base-source.patch').write_bytes(git('diff', '--binary', prior['base'], base, '--', *leaves))

spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = {i for p in assigned.values() for i in p['ledger']}
selected = []
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
for n, line in enumerate(ledger_path.open(), 1):
    row = json.loads(line)
    if row.get('id') in ids:
        selected.append((n, row))
folded = ledger.fold(selected)
summary = {}
for ident in sorted(ids):
    entry = folded[ident]
    assert entry['character'] == 'silent'
    summary[ident] = {k: v for k, v in entry.items() if k not in ('notes', 'history', 'where')}
    summary[ident]['where'] = entry['where']
    summary[ident]['note_count'] = len(entry['notes'])
    summary[ident]['history_count'] = len(entry['history'])
    summary[ident]['notes_sha256'] = hashlib.sha256(json.dumps(entry['notes'], ensure_ascii=False).encode()).hexdigest()
write('ledger-before.json', summary)
print(json.dumps({'source_leaves': len(leaves), 'same_previous_base': sum(e['equal_previous_base'] for e in source['leaves']),
                  'same_live': sum(e['equal_live'] for e in source['leaves']), 'ledger_ids': len(ids)}, ensure_ascii=False))

envelopes = json.loads((HERE / 'observed-windows.json').read_text())
index = [json.loads(line) for line in (HERE / 'raw-evidence-index.jsonl').open()]
extra_refs = [ref for ref in index if Path(ref['source']).stem == 'states' and 284400 <= ref['line'] <= 284408]
with (ROOT / 'logs/states.jsonl').open('rb') as handle:
    for ref in extra_refs:
        handle.seek(ref['offset'])
        data = handle.read(ref['bytes'])
        assert hashlib.sha256(data).hexdigest() == ref['sha256']
        envelopes.append({**ref, 'row': json.loads(data)})
states = {e['line']: e for e in envelopes if Path(e['source']).stem == 'states'}
decisions = {e['line']: e for e in envelopes if Path(e['source']).stem == 'decisions'}


def state(line):
    return states[line]['row']['state']


def player(line):
    return state(line)['combat']['player']


def enemy(line, slot=0):
    return state(line)['combat']['enemies'][slot]


def power(obj, ident):
    return next((p['amount'] for p in obj.get('powers', []) if p['power_id'] == ident), 0)


def beetle(line):
    return next(e for e in state(line)['combat']['enemies'] if e['enemy_id'] == 'SLUMBERING_BEETLE')


checks = []


def check(label, actual, expected, lines):
    assert actual == expected, (label, actual, expected)
    checks.append({'结论': label, '实际值': actual, '引用': [
        {k: v for k, v in states[line].items() if k != 'row'} for line in lines]})


check('弃牌前1血16挡', [player(284817)['current_hp'], player(284817)['block']], [1, 16], [284817])
check('精确切击实际离手', ['PRECISE_CUT' in [c['card_id'] for c in state(n)['combat']['hand']] for n in [284817, 284818]], [True, False], [284817, 284818])
check('卵毒后剩2血、玩家归零', [enemy(284821, 2)['current_hp'], player(284821)['current_hp']], [2, 0], [284820, 284821])
check('石虫退出帧眩晕', enemy(284821)['intents'][0]['intent_type'], 'Stun', [284821])
check('火焰兑现1血、消耗1滑溜', [enemy(284630)['current_hp']-enemy(284631)['current_hp'], power(enemy(284630), 'SLIPPERY_POWER')-power(enemy(284631), 'SLIPPERY_POWER')], [1, 1], [284630, 284631])
check('12毒两结仅扣2血、毒层12到10、滑溜6到4', [enemy(284635)['current_hp']-enemy(284636)['current_hp'], power(enemy(284635), 'POISON_POWER'), power(enemy(284636), 'POISON_POWER'), power(enemy(284635), 'SLIPPERY_POWER'), power(enemy(284636), 'SLIPPERY_POWER')], [2, 12, 10, 6, 4], [284635, 284636])
check('尖啸临时负力次轮消失', [power(enemy(n), 'STRENGTH_POWER') for n in [284634, 284636]], [-6, 0], [284634, 284636])
check('赢战53到9、下战9血', [player(n)['current_hp'] for n in [284730, 284761, 284766]], [53, 9, 9], [284730, 284761, 284766])
check('F22两攻击轮实际损20和24', [player(a)['current_hp']-player(b)['current_hp'] for a,b in [(284743,284744),(284753,284754)]], [20, 24], [284743,284744,284753,284754])
check('幻象寄生归零后恢复21', [enemy(n)['current_hp'] for n in [284748,284749]], [0, 21], [284748,284749])
check('普通生存者后唯一打击被弃', [[c['card_id'] for c in state(n)['combat']['hand']] for n in [285414,285415]], [['SURVIVOR','STRIKE_SILENT'],[]], [285414,285415])
check('取消转向后45血7挡、来袭57', [player(285415)['current_hp'],player(285415)['block'],enemy(285415,1)['intents'][0]['total_damage']], [45,7,57], [285415])
check('末轮两敌毒兑现22和42', [enemy(284407,i)['current_hp']-enemy(284408,i)['current_hp'] for i in range(2)], [22,42], [284407,284408])
check('醒虫末段力量2到4', [power(beetle(n),'STRENGTH_POWER') for n in [286164,286170]], [2,4], [286164,286170])
check('末次14血5牌挡、1覆甲对22', [player(286173)['current_hp'],player(286173)['block'],power(player(286173),'PLATING_POWER'),beetle(286173)['intents'][0]['total_damage']], [14,5,1,22], [286173])
check('甲虫毒后13血、玩家死亡', [beetle(286174)['current_hp'],player(286174)['current_hp']], [13,0], [286174])
write('material-checks.json', checks)

comparisons = []
for e in envelopes:
    row = e['row']
    if Path(e['source']).stem != 'sl-attempts' or row['floor'] != 33 or row['attempt'] not in (1,6) or e['run_id'] not in ('NHA2KW0RB7VP','RC61MFQM63Y6'):
        continue
    t1,t2 = row['summary']['turns'][:2]
    hp_sum = lambda text: sum(int(x) for x in re.findall(r' (\d+)/\d+', text))
    comparisons.append({'run':e['run_id'],'attempt':row['attempt'],'hp_before':t1['hp'],'hp_next':t2['hp'],
        'hp_lost':t1['hp']-t2['hp'],'enemy_hp_net':hp_sum(t1['enemies'])-hp_sum(t2['enemies']),
        'plays':t1['plays'],'reference':{k:v for k,v in e.items() if k!='row'}})
assert sorted((x['run'],x['attempt'],x['hp_lost'],x['enemy_hp_net']) for x in comparisons) == sorted([
    ('NHA2KW0RB7VP',1,1,8),('NHA2KW0RB7VP',6,7,24),('RC61MFQM63Y6',1,4,30),('RC61MFQM63Y6',6,8,23)])
write('t1-comparisons.json', comparisons)
write('decision-readback.json', [{**{k:v for k,v in e.items() if k!='row'}, 'row':e['row']} for e in decisions.values()])
write('bounded-state-projections.json', [{
    **{k:v for k,v in e.items() if k!='row'}, 'floor':e['row']['state']['run']['floor'],
    'turn':e['row']['state'].get('turn'), 'player':(e['row']['state'].get('combat') or {}).get('player'),
    'hand':(e['row']['state'].get('combat') or {}).get('hand'), 'enemies':(e['row']['state'].get('combat') or {}).get('enemies'),
    'selection':e['row']['state'].get('selection'),
} for e in states.values()])
assert json.loads((HERE/'evidence-plans/evidence-manifest.json').read_text())[0]['output_sha256'] == json.loads((PREVIOUS/'evidence/evidence-manifest.json').read_text())[4]['output_sha256']
runs = [json.loads(x)['row'] for x in (HERE/'evidence-runs/runs.evidence.jsonl').open()]
assert len(runs)==5 and {r['run_id'] for r in runs}==set(json.loads((HERE/'dispatch.json').read_text())['runs'])
assert all(r['character']=='SILENT' and r['ascension']==10 for r in runs)
write('run-identity.json', runs)
print(json.dumps({'material_checks':len(checks), 't1_branches':len(comparisons), 'state_projections':len(states), 'runs_verified':len(runs)},ensure_ascii=False))

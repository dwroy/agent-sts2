import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PREVIOUS = ROOT / '.worktrees/codex-strategy-silent-20261016-171301-s2/learner/runs/20261016-171306-d2ec9d10-26e2-4784-9d27-a05f6dea65d1-strategy-proposal'
spec = importlib.util.spec_from_file_location('extract_evidence', HERE.parents[1] / 'extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest_path = PREVIOUS / 'evidence/evidence-manifest.json'
manifest = json.loads(manifest_path.read_text())
audit = []
windows = []
state_ranges = [(283390, 283409), (283653, 283671), (284626, 284660),
                (284730, 284821), (285314, 285321), (285411, 285415),
                (285491, 285497), (285544, 285562), (286148, 286180),
                (283850, 283873), (284175, 284208)]
decision_lines = {277248, 277250, 277272, 277274, 277909, 277954, 278032,
                  278542, 278543, 278544, 278545, 278546, 279021, 279117,
                  279197, 279852, 279854}
with (HERE / 'raw-evidence-index.jsonl').open('w') as index:
    for entry in manifest:
        stream = entry['stream']
        envelope_path = PREVIOUS / 'evidence' / f'{stream}.evidence.jsonl'
        digest = hashlib.sha256()
        counts = Counter()
        source = ROOT / 'logs' / f'{stream}.jsonl'
        assert source.stat().st_size >= entry['source_size']
        with envelope_path.open('rb') as envelopes, source.open('rb') as original:
            for encoded in envelopes:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['source'] == str(source)
                assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= entry['source_size']
                original.seek(item['offset'])
                raw = original.read(item['bytes'])
                assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
                row = json.loads(raw)
                assert row == item['row']
                assert extractor.run_identity(row) == item['run_id'] in runs
                counts[item['run_id']] += 1
                ref = {k: v for k, v in item.items() if k != 'row'}
                index.write(json.dumps(ref, ensure_ascii=False) + '\n')
                if (stream == 'states' and any(lo <= item['line'] <= hi for lo, hi in state_ranges)
                        or stream == 'decisions' and item['line'] in decision_lines
                        or stream in ('sl-attempts', 'run-config', 'run-plans')):
                    windows.append(item)
        assert digest.hexdigest() == entry['output_sha256']
        assert dict(counts) == entry['counts']
        audit.append({**entry, 'envelope': str(envelope_path),
                      'verified_lines': sum(counts.values()), 'raw_bytes_verified': True,
                      'envelope_sha_verified': True})
(HERE / 'evidence-reuse-audit.json').write_text(json.dumps({
    'previous_manifest': str(manifest_path),
    'previous_manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    'streams': audit, 'total': sum(x['verified_lines'] for x in audit),
    'scope': '复核既有共用入口冻结封套及原字节，不声称本批重新全量扫描。'
}, ensure_ascii=False, indent=2) + '\n')
(HERE / 'observed-windows.json').write_text(json.dumps(windows, ensure_ascii=False) + '\n')
print(json.dumps({'verified_lines': sum(x['verified_lines'] for x in audit),
                  'bounded_windows': len(windows)}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
path = ROOT/'paper/materials/learning/ledger.jsonl'
payload = (HERE/'ledger-update-input.jsonl').read_bytes()
requests = [json.loads(line) for line in payload.splitlines()]
ids = {row['id'] for row in requests}
assert len(ids) == len(requests) == 32
assert all(set(row) == {'id','by','where','note'} and row['by']=='learner:strategy-proposal' for row in requests)
prefix = path.read_bytes()
spec = importlib.util.spec_from_file_location('ledger', ROOT/'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)


def selected(raw):
    return [(n, row) for n,line in enumerate(raw.splitlines(),1)
            if (row := json.loads(line)).get('id') in ids]


before = ledger.fold(selected(prefix))
print(subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z']).decode().strip())
result = subprocess.run(['python3',str(ROOT/'learner/ledger.py'),'update'], input=payload, capture_output=True)
(HERE/'ledger-cli.stdout.txt').write_bytes(result.stdout)
(HERE/'ledger-cli.stderr.txt').write_bytes(result.stderr)
(HERE/'ledger-cli-exit.json').write_text(json.dumps({'exit_code':result.returncode})+'\n')
assert result.returncode == 0
after_raw = path.read_bytes()
assert after_raw[:len(prefix)] == prefix
appends=[]
offset = len(prefix)
for raw in after_raw[len(prefix):].splitlines(keepends=True):
    row=json.loads(raw)
    if row.get('id') in ids and row.get('by') == 'learner:strategy-proposal' and row.get('note','').startswith('20261016-204302-strategy-proposal：'):
        expected=next(r for r in requests if r['id']==row['id'])
        assert {k:v for k,v in row.items() if k not in ('op','ts')} == expected
        assert row['op']=='update'
        appends.append({'id':row['id'],'offset':offset,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    offset+=len(raw)
assert len(appends)==32 and {r['id'] for r in appends}==ids
after = ledger.fold(selected(after_raw))
preserved=[]
for ident in ids:
    a,b=before[ident],after[ident]
    for key in ('claim','first_run','prior','prior_note','evidence','status','version','effect','shipped_at'):
        assert a.get(key)==b.get(key), (ident,key)
    assert b['notes'][:len(a['notes'])]==a['notes']
    assert b['history'][:len(a['history'])]==a['history']
    for key,values in a['where'].items():
        assert b['where'][key][:len(values)]==values
    preserved.append({'id':ident,'status':b['status'],'claim_and_evidence_preserved':True,
                      'notes_history_where_prefix_preserved':True})
audit={'exit_code':result.returncode,'prefix_bytes':len(prefix),'prefix_sha256':hashlib.sha256(prefix).hexdigest(),
       'old_prefix_preserved':True,'own_rows':appends,'fold_checks':sorted(preserved,key=lambda r:r['id'])}
(HERE/'ledger-append-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':result.returncode,'own_rows':len(appends),'fold_checks':len(preserved)},ensure_ascii=False))

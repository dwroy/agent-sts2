import hashlib
import importlib.util
import json
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = SCRATCH.parents[2]


def write(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, cwd=TREE):
    return subprocess.check_output(['git', *args], cwd=cwd)


spec = importlib.util.spec_from_file_location('extractor', TREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((SCRATCH / 'dispatch-and-proposals.json').read_text())
runs = dispatch['batch']['runs']
originals = {}
for key in dispatch['batch']['proposal_ids']:
    row = dispatch['proposal_rows'][key][0][1]
    data = Path(row['proposal']).read_bytes()
    assert sha(data) == row['proposal_sha256'], key
    (SCRATCH / (key + '.original.md')).write_bytes(data)
    originals[key] = row
write('selected-proposals.json', originals)

verification = []
envelopes = defaultdict(list)
for folder in ['evidence', 'evidence-runs']:
    manifests = json.loads((SCRATCH / folder / 'evidence-manifest.json').read_text())
    for meta in manifests:
        path = SCRATCH / folder / (meta['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = Counter()
        source = ROOT / 'logs' / (meta['stream'] + '.jsonl')
        with source.open('rb') as original, path.open('rb') as selected:
            for raw in selected:
                digest.update(raw)
                item = json.loads(raw)
                original.seek(item['offset'])
                data = original.read(item['bytes'])
                assert sha(data) == item['sha256']
                assert json.loads(data) == item['row']
                assert extractor.run_identity(item['row']) == item['run_id'] in runs
                assert item['offset'] + item['bytes'] <= meta['source_size']
                assert Path(item['source']) == source
                counts[item['run_id']] += 1
                envelopes[meta['stream']].append(item)
        assert digest.hexdigest() == meta['output_sha256']
        assert dict(counts) == {k: v for k, v in meta['counts'].items() if v}
        verification.append({**meta, 'verified': sum(counts.values())})
write('envelope-verification.json', verification)
identities = {x['run_id']: x['row'] for x in envelopes['runs']}
assert set(identities) == set(runs)
assert all(x['character'].lower() == 'silent' and x['ascension'] == 10 for x in identities.values())
write('verified-runs.json', identities)

floors = {'VLZ6CCT8AQ0A': [17, 33, 35, 36, 37, 43, 44, 45], '8JRE1C4H4Z2W': [17, 33],
          'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [33, 39], '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [30]}
inputs = []
for run in runs:
    decision_items = [x for x in envelopes['decisions'] if x['run_id'] == run and x['row'].get('floor') in floors[run]]
    excluded = [x for x in decision_items if not x['row'].get('decision_id')]
    decisions = [{**x['row'], '_line': x['line'], '_source_sha256': x['sha256']} for x in decision_items if x['row'].get('decision_id')]
    decisions.sort(key=lambda x: x['observed_ts'])
    states = [{**x['row'], '_line': x['line'], '_source_sha256': x['sha256']}
              for x in envelopes['states'] if x['run_id'] == run and x['row'].get('state', {}).get('run', {}).get('floor') in floors[run]]
    write(run + '.consumer-input.json', {'run': identities[run], 'decisions': decisions, 'states': states})
    write(run + '.consumer-exclusions.json', excluded)
    inputs.append({'run': run, 'floors': floors[run], 'decisions': len(decisions), 'states': len(states), 'excluded': len(excluded)})
write('consumer-input-summary.json', inputs)

target_lines = {269706, 269707, 269748, 269754, 269755, 269770, 270216, 270282, 270264}
write('target-decisions.json', [x for x in envelopes['decisions'] if x['line'] in target_lines])

def state_summary(x):
    row = x['row']; state = row['state']; combat = state.get('combat') or {}; player = combat.get('player') or {}; info = state.get('run') or {}
    def card(c):
        return {k: c.get(k) for k in ['card_id', 'upgraded', 'energy_cost', 'resolved_rules_text', 'dynamic_values']}
    return {'line': x['line'], 'sha256': x['sha256'], 'observed_ts': row.get('observed_ts'), 'floor': info.get('floor'),
            'turn': state.get('turn'), 'hp': player.get('current_hp', info.get('current_hp')), 'block': player.get('block'),
            'energy': player.get('energy'), 'powers': player.get('powers'), 'enemies': combat.get('enemies'),
            'hand': [card(c) for c in combat.get('hand', [])], 'potions': info.get('potions'), 'screen': state.get('screen')}

for run in runs:
    write(run + '.state-summary.json', [state_summary(x) for x in envelopes['states'] if x['run_id'] == run and x['row'].get('state', {}).get('run', {}).get('floor') in floors[run]])

paths = ['agent/src/reflex/card-model.ts', 'agent/src/reflex/silent-apotheosis.ts', 'agent/src/reflex/turn-solver.ts',
         'agent/src/reflex/rollout.ts', 'agent/src/reflex/rollout-live.ts', 'agent/src/reflex/combat-plan.ts',
         'agent/src/reflex/silent-selection-audit.ts', 'agent/src/reflex/silent-hp-guard-audit.ts',
         'agent/src/reflex/silent-apotheosis-reference.ts', 'agent/src/reflex/silent-simulation-reference.ts',
         'agent/src/reflex/silent-potion-reference.ts',
         'agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/sl/explore.ts',
         'learner/audit-selection.ts', 'learner/lib/selection-execution.ts', 'learner/lib/selection-turn.ts',
         'learner/lib/selection-observation.ts', 'learner/lib/selection-terminal.ts']
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode().strip()
snapshot = []
for path in paths:
    data = (TREE / path).read_bytes(); base_data = git('show', base + ':' + path); live_data = git('show', live + ':' + path)
    last = git('log', '-1', '--format=%H', base, '--', path).decode().strip()
    ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', last, live], cwd=TREE).returncode == 0
    assert data == base_data
    snapshot.append({'path': path, 'base_sha256': sha(base_data), 'worktree_sha256': sha(data), 'live_sha256': sha(live_data),
                     'same_live_bytes': data == live_data, 'last_commit': last, 'last_commit_is_live_ancestor': ancestor})
write('source-snapshot.json', {'base': base, 'live': live, 'files': snapshot})
(SCRATCH / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
(SCRATCH / 'working-tree.patch').write_bytes(git('diff', '--binary'))
print(json.dumps({'verified_envelopes': sum(x['verified'] for x in verification), 'inputs': inputs, 'source_files': len(snapshot)}, ensure_ascii=False))

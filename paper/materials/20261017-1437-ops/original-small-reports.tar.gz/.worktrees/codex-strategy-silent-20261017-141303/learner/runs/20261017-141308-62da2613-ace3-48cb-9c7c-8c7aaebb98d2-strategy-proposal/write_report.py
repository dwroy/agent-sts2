import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
read = lambda name: json.loads((S / name).read_text())
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
dispatch = read('dispatch-and-proposals.json')['batch']
proposals = read('selected-proposals.json')
snapshot = read('source-snapshot.json')
base = snapshot['base']
assert dispatch['task'] == 'strategy-proposal' and dispatch['character'] == 'silent'
assert dispatch['worktree'] == str(S.parents[2])
assert not dispatch.get('research_request') and not dispatch.get('implementation_request')
matrix = [
    ('silent-proposal-89354805ee4d7e77', 'VLZ6CCT8AQ0A F35/F43 T1、F43 T2—T5、F45 T1',
     'F43神化7→5能，同后续候选43伤/14损改为51伤/13损；原帧净扣51、净损13。F45实际用药抽必备工具/生存者，神化未施放。',
     '缺神化跨抽牌、选牌、药水重问、SL及换战的实际施放持续身份及生产读回；现有actual_cast_this_fight=null，已观察配对转换与候选覆盖事实不能证明整个请求完成。',
     '沿已观察升级配对继续保持现行变换与unknown；先冻结跨中断的动作/战斗身份、未知升级交互和消费者实际读回，逐项验证，不加入必打神化或固定收益。'),
    ('silent-proposal-f2bfceddb1898dca', 'VLZ6CCT8AQ0A F43、F44；F45 T1/T4/T5',
     'F45首问原题707ms药水MC、1样本预算退化；后题12样本仍仅是药水局部抽样。T4候选13损/24伤对31损/32伤；T5原帧32血20挡对减力后59，完整需损39，三敌仍存活。',
     '缺模型覆盖充分时同起点、同随机池、同总预算的分阶段MC配对和成熟度曲线，以及另一focus、留药的完整后继；现有预算/并列诊断不证明新预算分配或药价有效。',
     '保留原预算、目标、留药和护栏；预登记固定状态/种子/预算实验，记录完成度与候选稳定性，缺比较不拟合新常量。'),
    ('silent-proposal-283a164780d11e69', 'VLZ6CCT8AQ0A F35/F43/F45，同89354805ee4d7e77的同源证据',
     '来源experience-update，关联silent-apotheosis-combat-upgrades；与postmortem共享同一局，不新增独立支持数。',
     '同源神化经验仍缺实际施放持续归属与未知组合校准；已有窄live源码不足覆盖整个原请求，不能将同源关系写成已有完整实现的duplicate。',
     '沿原ID与同源提案共同复核，不另建ID或重复实现；达到原请求的完整范围后才引用实际live祖先源码关闭。'),
    ('silent-proposal-ebbfe3b97548756d', 'VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5及休息资源链',
     'F43升级勒紧6、尖啸8；F45减力前后83→59、末挡20且无覆甲，毒后仍三敌存活。15条经验的逐来源属性、状态期限与路线资源必须分账。',
     '缺十五子项在当前冻结生产调用中的逐来源、升级组合、期限与战斗—路线—休息联合校准；本批只有原帧数值与窄源码边界核验，没有隔离出新的确定源码数值失配。',
     '保留已实现机制；将每个可复现失配限定到原帧、当前进阶数据库与生产路径后再实现，不用整体失败拟合统一输出/保血权重。'),
    ('silent-proposal-e5b87be50f28f311', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6',
     '270216/270282同指纹；T2原帧首试损3扣10、第三试损15扣17。第二试T5损4扣25；末试T11净损5至0，完整入伤仍unknown。',
     '缺抽牌、选择、用药、重问和SL后的完整候选持续归属与逐来源实际收益；本批该局66个审计片段actual_full_candidate_result全null。局部端点不能拟合探索/护栏门槛或证明整战换线因果。',
     '保留原答、护栏前后、SL替换与实际动作分账；继续核完整中断链，不将预测差当实付收益，独立后置局验证规则效果。'),
    ('silent-proposal-49632bc4878fb597', 'CA5KE8GFJ9X2 F13 T1—T5',
     '原帧两次成长后力量4/8，攻击15/19；虚弱后11/14且成长继续。末轮2血10挡对14，不能用净损2冒称完整需损2。',
     '缺力量、正负敏捷、虚弱与独立成长四路径的同一冻结生产联合校准；本局没有建立正敏捷的实测，本批未定位新的确定子公式失配。',
     '按当前属性、每击修正与独立成长分源核验；不补计划中未取得的步法，不增加统一保血或输出权重。'),
    ('silent-proposal-66532328a585941f', '5PM6JAQG6FNQ F33；F39第二试T2',
     '268455请求对无毒失落打冒泡；states274379→274380能5→4，敌35血不变、仍无毒，玩家无毒雾。整轮另有动作，不能把整轮净伤归冒泡。',
     '缺同起始HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照与收益函数；持有组件和已建立状态不同，空打端点不支持启动阈值或构筑权重。',
     '继续分列持有/计划/已建立；先冻结完整生产输入和受控启动后继，再讨论构筑/启动权重，不规定能力必打。'),
    ('silent-proposal-43a76a31ba7bdcfa', '61E2QS63Y9WU F17 T5/T6',
     '吸取后玩家力2→0、敏0→−2，敌力2；两防御挡0→3→6（273504/505/507）。17毒端点敌67→34，净扣33；该场首试胜不等于整局胜。',
     '缺同起始HP、构筑、完整抽序的生产整战配对及另一可核SL线路；负敏捷与17+16毒端点不足支持修改SL范围、换线偏好或阈值。',
     '保留吸取、负敏捷和毒的分项事实及现有SL规则；完整对照按局分组，不把同局尝试拆成独立样本。'),
    ('silent-proposal-5264153a4a4b0e5c', '61E2QS63Y9WU F23 T2—T5',
     '两次航行后敌力0→3→6；T4局部净扣47、损15，幻象余2仍攻击，T5才退场。当前严格整轮消费者对T4保持turn_opening_unverified。',
     '缺A10召唤、航行、复现和退场全链的冻结生产校准及另一focus完整后继；已有召唤源码/覆盖披露和T4局部端点不能证明目标排序整战收益。',
     '保留全部目标选项与原排序，相同推演值并列；先按实体、当前进阶和生命周期逐步校准，不规定固定首杀。'),
    ('silent-proposal-bddfa690a84e03d0', 'DUZUBAJ3A8GP F30四试T1—T6',
     '首试睡层3→2→1→0，T4攻击18，T5力2攻击20；尖啸降至−4力/14攻击后，T6恢复并成长4力/22。末试T4较首试多扣本体3、同时多损2血。',
     '缺伤害唤醒、眩晕接续与当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次失败来自一局，不能拟合血价、全败排序或固定杀序。',
     '保留现行睡眠/成长与目标选择；分别核期限、唤醒和各实体退出，完整后继及后置独立局才检验排序收益。'),
]
assert [x[0] for x in matrix] == dispatch['proposal_ids']
results = [{'id': key, 'state': 'waiting', 'reason': reason} for key, _, _, reason, _ in matrix]
(S / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
header = f'''# 静默猎手已领取策略提案复核

记录时间：{stamp}。批次：20261017-141303-strategy-proposal。角色：silent，六个派发局均已核为SILENT/A10。
开工git status干净；git merge --no-edit main返回Already up to date。完整base：`{base}`。
learn.json只读取本批行，无research_request/implementation_request/proposal_repair，只有本报告十个proposal_ids；普通专题文件绑定另一批，不接管专题。

结论：十项均waiting，详见逐项缺数据理由。没有足够的新证据支持进一步策略改动，也没有覆盖整个原请求的live源码证明可登记implemented/duplicate。
本批不改生产源码、知识、参数或规则，无提交、live合入、eval版本、shipped或新代码提案ID。原十提案Markdown逐字节核SHA并只读保存，不修改原文。
已有窄实现保留；没有源码变更，撤源码失败/恢复通过不适用，tsc/vitest/cases均null。材料检查及离线审计不冒称生产测试、模型校准或策略收益验证。

## 证据与样本边界

统一入口learner/extract_evidence.py按显式run_id/state.run_id/fingerprint.run与run-plans.run选取；正文提及不作所属局，冲突身份拒收。
各流独立冻结source_size；全部封套按原物理offset/bytes重新读回，核SHA256、JSON、所属局和截点范围。evidence-manifest.json与envelope-verification.json保留复现边界。
只提取本批六局，runs另存evidence-runs。没有覆盖全历史；不把SL次数当独立样本，不重复增加已有support/repeat。

|流|冻结source_size|逐字节核回数|
|---|---:|---:|
'''
for x in read('envelope-verification.json'):
    header += f"|{x['stream']}|{x['source_size']}|{x['verified']}|\n"
header += '''
合计6,995个封套；六局结束记录均为失败，局内胜场独立记资源消耗。历史run.code带dirty，未恢复当时全部dirty运行树；当前源码核对不能充当历史源码完全等同证明。

## 当前有界消费者与材料检查

使用当前基线learner/audit-selection.ts及其lib，对选定房间读取冻结JSON，不调游戏、LLM、网络或模拟器，不加载刷新知识JSON。
输入保留真实_line/_source_sha256，未重编号；六份输入均无缺decision_id排除。消费者只认证观测端点，不认证整条候选或因果。

|局号|层范围|决策/状态|片段|可核回合|退出码|
|---|---|---:|---:|---:|---:|
'''
for x in read('consumer-results.json'):
    header += f"|{x['run']}|{','.join(map(str, x['floors']))}|{x['decisions']}/{x['states']}|{x['segments']}|{x['observed_turns']}|{x['exit_code']}|\n"
header += '''
共168个片段、86个可核回合端点；全部actual_full_candidate_result为null，表示消费者未认证，不断言从未实际执行，也不认证完整执行。开场/尝试身份未知及其他拒绝连接条件原样保留。
verify_materials.py完成35项原帧/候选数值/祖先核验，退出0；具体引用见material-checks.json。未拟合权重、血价、药价、目标顺序、SL阈值或必打规则。

过程失败原件保留：初次tsx CLI因沙箱Unix pipe EPERM启动失败，未进入消费者；改用同一node/tsx loader后六次均0，没有修改沙箱或源码。
材料初稿误把273506尖啸后帧当第二张防御后帧，断言得到0/3/3而非0/3/6；逐动作读回后改引273507，保留attempt1脚本和失败日志，原帧未改。这不是生产源码红绿。
一次只读命令在执行前遇到并行目录消失导致sandbox glob扫描失败，重试成功；没有把环境失败写成产品缺陷。

## 已有源码范围与实际live祖先

'''
header += f"source-snapshot.json冻结18叶及当时live提交`{snapshot['live']}`。15叶字节相同，3叶差异仅原Roy/Dai英文注释署名，完整base-live-source.patch保留。\n"
header += 'rollout.ts与rollout-live.ts最近main整合提交不是该live祖先的false保持；同字节不能倒填假祖先。以下七个实际窄源码提交则逐一核为该live祖先，仅证明所列功能。\n\n|提交|已实现窄范围|\n|---|---|\n'
for x in read('known-source-commits.json'):
    header += f"|{x['commit']}|{x['scope']}|\n"
header += '\n这些窄功能不能合称原十项已完成；实际施放、完整候选和整战后继缺口继续保留，不据日志展示宣称提高胜率。\n\n## 逐项处置\n\n'
sections = ''
for key, refs, finding, reason, follow in matrix:
    p = proposals[key]
    sections += f'''### {key}

- 来源：{p['source_task']} → strategy-proposal；原件 `{p['proposal']}`，SHA256 `{p['proposal_sha256']}`。
- 账本：{', '.join(p['ledger'])}；原领域：{', '.join(p['domains'])}。
- 证据局/层/回合：{refs}。{finding}
- 本批处置：waiting。{reason}
- 预期行为与验证：{follow}
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

'''
footer = f'''## 交付与闭环

提案汇总：`{S / 'proposal.md'}`；报告：`{S / 'report.md'}`；逐项结果proposal-results.json/result.json。
只经根learner/ledger.py update给26个原账本追加本批where.proposal与note追溯，不另加已有证据、不改claim/首证/prior/状态/版本/效果；原shipped不降级。CLI输入/输出及物理行读回单独保留ledger-*材料。
原十ID已经有CLI登记，故本批不重复code_proposals add；最终code_proposals列原已处理ID，implementation_domains=[]表示本批没有源码实现。proposal_results逐IDwaiting，均不附虚构源码commit。
没有实际上线或新机制异议，不追加规则上线通知或代其他角色ACK；本报告不关闭Roy的量化学习父要求，不冒称经验已入live或大脑采用。
工作树HEAD保持完整base，tracked/index干净；scratch被忽略且保留，不自行删除工作树。后续由原调度器按实际回执处理，运维可从本报告/提案路径继续追溯。
'''
(S / 'report.md').write_text(header + sections + footer)
(S / 'proposal.md').write_text(f'# 本批十项策略提案的证据与处置\n\n记录时间：{stamp}。批次20261017-141303-strategy-proposal，角色silent/A10，基线`{base}`。\n\n没有新建提案ID或策略实现。原提案逐字节保存为各ID.original.md；本文件只记录本批复核。以下十项均waiting，保留原行为；材料方法、反例与共同范围见同目录report.md。\n\n' + sections)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-141303-strategy-proposal',
          'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'],
          'implementation_domains': [], 'proposal_results': results, 'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
by_ledger = {}
for key, _, _, _, _ in matrix:
    for ledger in proposals[key]['ledger']:
        by_ledger.setdefault(ledger, []).append(key)
updates = [{'id': ledger, 'by': 'learner:strategy-proposal', 'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
            'note': '20261017-141303-strategy-proposal：本批原帧与当前窄源码复核，关联' + ','.join(keys) + '均waiting；具体缺数据见报告。只追加追溯，不新增support/repeat、不修改既有claim/状态/版本或冒称完整实现。'}
           for ledger, keys in sorted(by_ledger.items())]
(S / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'report': str(S / 'report.md'), 'proposal_results': len(results), 'ledger_updates_prepared': len(updates)}, ensure_ascii=False))

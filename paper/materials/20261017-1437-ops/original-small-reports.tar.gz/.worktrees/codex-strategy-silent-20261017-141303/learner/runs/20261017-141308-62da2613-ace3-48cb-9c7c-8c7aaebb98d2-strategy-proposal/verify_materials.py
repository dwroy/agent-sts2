import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
checks = []


def check(name, actual, expected, refs):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'references': refs})


def load(name):
    return json.loads((S / name).read_text())


states = {run: {x['line']: x for x in load(run + '.state-summary.json')} for run in load('verified-runs.json')}
decisions = {x['line']: x['row'] for x in load('target-decisions.json')}


def pows(values):
    return {x['power_id']: x['amount'] for x in values or []}


def enemy(state, name):
    return next(x for x in state['enemies'] if x['enemy_id'] == name)


def power(state, name, key):
    return pows(enemy(state, name)['powers']).get(key, 0)


def attack(state, name):
    return sum(x.get('total_damage') or 0 for x in enemy(state, name)['intents'])


def criterion(line, key):
    value = decisions[line]['questions']['plan']['criteria'][key]
    return json.loads(value) if isinstance(value, str) else value


v = states['VLZ6CCT8AQ0A']
check('F43神化能量及升级发生', [v[275679]['energy'], v[275680]['energy'],
      [(x['card_id'], x['upgraded']) for x in v[275680]['hand']]],
      [7, 5, [('SUCKER_PUNCH', True), ('STRIKE_SILENT', True), ('FASTEN', True), ('STRIKE_SILENT', True),
              ('ASCENDERS_BANE', False), ('PIERCING_WAIL', True)]], [275679, 275680])
check('F43神化前后同后续候选预测', [[criterion(n, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']] for n in [269706, 269707]], [[43, 14], [51, 13]], [269706, 269707])
check('F43实际局部端点净伤净损', [254 - enemy(v[275686], 'SOUL_NEXUS')['current_hp'], 90 - v[275687]['hp']], [51, 13], [275679, 275686, 275687])
check('F45药水真实能量与血', [[v[n]['energy'], v[n]['hp']] for n in [275728, 275729]], [[1, 67], [2, 67]], [275728, 275729])
check('F45药水实抽牌', [x['card_id'] for x in v[275729]['hand']], ['APOTHEOSIS', 'TOOLS_OF_THE_TRADE', 'SURVIVOR'], [275729])
check('F45首问预算退化原文', '707 ms' in criterion(269748, 'plan1')['rollout'] and 'fallback, not a forecast' in criterion(269748, 'plan1')['rollout'], True, [269748])
check('F45T4候选代价差仍属预测', [[criterion(269770, k)[f] for f in ['hp_lost', 'damage_dealt']] for k in ['plan1', 'plan4']], [[13, 24], [31, 32]], [269770])
check('F45T5四段攻击减力前后', [sum(attack(v[n], e['enemy_id']) for e in v[n]['enemies']) for n in [275752, 275753]], [83, 59], [275752, 275753])
check('F45T5最终血挡与未截断缺口', [v[275754]['hp'], v[275754]['block'], 59 - v[275754]['block']], [32, 20, 39], [275754])
check('F45终页净血为零且三敌存活', [v[275755]['hp'], sorted(e['current_hp'] for e in v[275755]['enemies'])], [0, [21, 77, 80]], [275755])

check('8JRE首三试T2同指纹', decisions[270216]['fingerprint'], decisions[270282]['fingerprint'], [270216, 270282])
check('8JRE原答和SL替换分列', decisions[270282]['sl_explore']['replacement'], '狂乱逃离, 带毒刺击 -> 无厌沙虫, 打击 -> 无厌沙虫', [270282])
turns = load('8JRE1C4H4Z2W.turn-summary.json')
def turn(floor, number, attempt):
    return next(t for t in turns if t['floor'] == floor and t['turn'] == number and t['attempt'] == attempt)
check('8JRE同盘T2净血与敌净扣', [[turn(33, 2, a)['facts']['player_hp_delta'], turn(33, 2, a)['facts']['enemy_hp_changes'][0]['hp_delta']] for a in [1, 3]], [[-3, -10], [-15, -17]], [270216, 270282, 276208, 276212, 276274, 276278])
check('8JRE第二试T5实际端点', [turn(33, 5, 2)['facts']['player_hp_delta'], turn(33, 5, 2)['facts']['enemy_hp_changes'][0]['hp_delta']], [-4, -25], [270263, 270266])
check('8JRE末试T11零血端点不补满额损失', [turn(33, 11, 6)['facts']['player_hp_delta'], turn(33, 11, 6)['facts']['after']['hp'], turn(33, 11, 6)['facts']['actual_uncapped_hp_loss']], [-5, 0, None], [270437, 270441])

c = states['CA5KE8GFJ9X2']
check('蚌成长与虚弱分项', [[power(c[n], 'SEWER_CLAM', 'STRENGTH_POWER'), attack(c[n], 'SEWER_CLAM')] for n in [273252, 273257, 273263, 273268]], [[4, 15], [4, 11], [8, 19], [8, 14]], [273252, 273257, 273263, 273268])
check('蚌末轮2血10挡对14', [c[273268]['hp'], c[273268]['block'], attack(c[273268], 'SEWER_CLAM')], [2, 10, 14], [273268])

b = states['5PM6JAQG6FNQ']
check('冒泡实打能量消耗而目标无毒无净扣', [b[274379]['energy'], b[274380]['energy'], enemy(b[274379], 'THE_LOST')['current_hp'], enemy(b[274380], 'THE_LOST')['current_hp'], power(b[274380], 'THE_LOST', 'POISON_POWER')], [5, 4, 35, 35, 0], [274379, 274380])
check('冒泡前后玩家未建立毒雾', [pows(b[n]['powers']).get('NOXIOUS_FUMES_POWER', 0) for n in [274379, 274380]], [0, 0], [274379, 274380])

l = states['61E2QS63Y9WU']
check('吸取前后玩家力量与敏捷', [[pows(l[n]['powers']).get('STRENGTH_POWER', 0), pows(l[n]['powers']).get('DEXTERITY_POWER', 0)] for n in [273503, 273504]], [[2, 0], [0, -2]], [273503, 273504])
check('负敏捷下双防御实际格挡', [l[n]['block'] for n in [273504, 273505, 273507]], [0, 3, 6], [273504, 273505, 273507])
check('T6毒结算端点净扣', [power(l[273507], 'LAGAVULIN_MATRIARCH', 'POISON_POWER'), enemy(l[273507], 'LAGAVULIN_MATRIARCH')['current_hp'] - enemy(l[273508], 'LAGAVULIN_MATRIARCH')['current_hp']], [17, 33], [273507, 273508])
check('胧光T4净扣47同时损15且幻象仍在', [l[273593]['hp'] - l[273596]['hp'], sum(e['current_hp'] for e in l[273593]['enemies']) - sum(e['current_hp'] for e in l[273596]['enemies']), enemy(l[273596], 'PARAFRIGHT')['current_hp']], [15, 47, 2], [273593, 273596])
check('胧光两次航行增长', [power(l[n], 'THE_OBSCURA', 'STRENGTH_POWER') for n in [273583, 273589, 273596]], [0, 3, 6], [273583, 273589, 273596])

u = states['DUZUBAJ3A8GP']
check('熟睡甲虫倒计时', [power(u[n], 'SLUMBERING_BEETLE', 'SLUMBER_POWER') for n in [274906, 274914, 274919, 274923]], [3, 2, 1, 0], [274906, 274914, 274919, 274923])
check('熟睡甲虫醒后恢复与成长', [[power(u[n], 'SLUMBERING_BEETLE', 'STRENGTH_POWER'), attack(u[n], 'SLUMBERING_BEETLE')] for n in [274923, 274929, 274933, 274934]], [[0, 18], [2, 20], [-4, 14], [4, 22]], [274923, 274929, 274933, 274934])
check('首末试T4局部取舍反例', [[u[n]['hp'], enemy(u[n], 'SLUMBERING_BEETLE')['current_hp']] for n in [274929, 275013]], [[3, 74], [1, 71]], [274929, 275013])

consumer = load('consumer-results.json')
check('六个有界消费者通过且未认证完整候选', [[x['exit_code'], x['full_candidate_certified']] for x in consumer], [[0, 0]] * 6, ['consumer-results.json'])
live = load('source-snapshot.json')['live']
commits = {
    'f98a929f24901c20efed462b29591e25ebb85451': '神化持有、候选与模拟覆盖事实；实际施放仍unknown',
    'ba23ca693151fa8c6f7fe035e640dc30f05ccd75': '已观察致命毒药神化升级窄实现',
    'be69855995737d6f381adb10bf248964832da24b': '原答及SL前后候选预测审计',
    '1698adc96ba434a46942321e0237b70657e625b2': 'SL资源比较审计',
    'e75438488df159b2e8e9d3458cf219b39aadd933': '离线整轮观测端点',
    '45161a51c2c6b7e4a499b13cf749c4108193bbf5': '推演成熟度与随机药水预算事实',
    '0fa15f5e06d60a6caa95b8f49675ee6222b4b276': '召唤覆盖缺口披露',
}
sources = []
for commit, scope in commits.items():
    rc = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live]).returncode
    check('已有窄源码祖先核实:' + commit, rc, 0, [commit, live])
    sources.append({'commit': commit, 'scope': scope, 'live_ancestor': True})
(S / 'known-source-commits.json').write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n')
(S / 'material-checks.json').write_text(json.dumps({'count': len(checks), 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'result': 'passed', 'production_tests': None}, ensure_ascii=False))

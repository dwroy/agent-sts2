# 本批十项策略提案的证据与处置

记录时间：2026-10-17 14:24:30 CST。批次20261017-141303-strategy-proposal，角色silent/A10，基线`dbe7292a33ada10ec0bce609316d3e38e48f9e61`。

没有新建提案ID或策略实现。原提案逐字节保存为各ID.original.md；本文件只记录本批复核。以下十项均waiting，保留原行为；材料方法、反例与共同范围见同目录report.md。

### silent-proposal-89354805ee4d7e77

- 来源：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md`，SHA256 `ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d`。
- 账本：silent-0237, silent-0238；原领域：combat, structure。
- 证据局/层/回合：VLZ6CCT8AQ0A F35/F43 T1、F43 T2—T5、F45 T1。F43神化7→5能，同后续候选43伤/14损改为51伤/13损；原帧净扣51、净损13。F45实际用药抽必备工具/生存者，神化未施放。
- 本批处置：waiting。缺神化跨抽牌、选牌、药水重问、SL及换战的实际施放持续身份及生产读回；现有actual_cast_this_fight=null，已观察配对转换与候选覆盖事实不能证明整个请求完成。
- 预期行为与验证：沿已观察升级配对继续保持现行变换与unknown；先冻结跨中断的动作/战斗身份、未知升级交互和消费者实际读回，逐项验证，不加入必打神化或固定收益。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-f2bfceddb1898dca

- 来源：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md`，SHA256 `fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26`。
- 账本：silent-0106, silent-0019, silent-0201；原领域：combat, potion。
- 证据局/层/回合：VLZ6CCT8AQ0A F43、F44；F45 T1/T4/T5。F45首问原题707ms药水MC、1样本预算退化；后题12样本仍仅是药水局部抽样。T4候选13损/24伤对31损/32伤；T5原帧32血20挡对减力后59，完整需损39，三敌仍存活。
- 本批处置：waiting。缺模型覆盖充分时同起点、同随机池、同总预算的分阶段MC配对和成熟度曲线，以及另一focus、留药的完整后继；现有预算/并列诊断不证明新预算分配或药价有效。
- 预期行为与验证：保留原预算、目标、留药和护栏；预登记固定状态/种子/预算实验，记录完成度与候选稳定性，缺比较不拟合新常量。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-283a164780d11e69

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md`，SHA256 `78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637`。
- 账本：silent-0237, silent-0238；原领域：combat, structure。
- 证据局/层/回合：VLZ6CCT8AQ0A F35/F43/F45，同89354805ee4d7e77的同源证据。来源experience-update，关联silent-apotheosis-combat-upgrades；与postmortem共享同一局，不新增独立支持数。
- 本批处置：waiting。同源神化经验仍缺实际施放持续归属与未知组合校准；已有窄live源码不足覆盖整个原请求，不能将同源关系写成已有完整实现的duplicate。
- 预期行为与验证：沿原ID与同源提案共同复核，不另建ID或重复实现；达到原请求的完整范围后才引用实际live祖先源码关闭。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-ebbfe3b97548756d

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md`，SHA256 `08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2`。
- 账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019；原领域：combat, structure。
- 证据局/层/回合：VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5及休息资源链。F43升级勒紧6、尖啸8；F45减力前后83→59、末挡20且无覆甲，毒后仍三敌存活。15条经验的逐来源属性、状态期限与路线资源必须分账。
- 本批处置：waiting。缺十五子项在当前冻结生产调用中的逐来源、升级组合、期限与战斗—路线—休息联合校准；本批只有原帧数值与窄源码边界核验，没有隔离出新的确定源码数值失配。
- 预期行为与验证：保留已实现机制；将每个可复现失配限定到原帧、当前进阶数据库与生产路径后再实现，不用整体失败拟合统一输出/保血权重。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-e5b87be50f28f311

- 来源：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md`，SHA256 `5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709`。
- 账本：silent-0079, silent-0021, silent-0125, silent-0018；原领域：combat, sl。
- 证据局/层/回合：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6。270216/270282同指纹；T2原帧首试损3扣10、第三试损15扣17。第二试T5损4扣25；末试T11净损5至0，完整入伤仍unknown。
- 本批处置：waiting。缺抽牌、选择、用药、重问和SL后的完整候选持续归属与逐来源实际收益；本批该局66个审计片段actual_full_candidate_result全null。局部端点不能拟合探索/护栏门槛或证明整战换线因果。
- 预期行为与验证：保留原答、护栏前后、SL替换与实际动作分账；继续核完整中断链，不将预测差当实付收益，独立后置局验证规则效果。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-49632bc4878fb597

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md`，SHA256 `aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2`。
- 账本：silent-0005, silent-0231；原领域：combat。
- 证据局/层/回合：CA5KE8GFJ9X2 F13 T1—T5。原帧两次成长后力量4/8，攻击15/19；虚弱后11/14且成长继续。末轮2血10挡对14，不能用净损2冒称完整需损2。
- 本批处置：waiting。缺力量、正负敏捷、虚弱与独立成长四路径的同一冻结生产联合校准；本局没有建立正敏捷的实测，本批未定位新的确定子公式失配。
- 预期行为与验证：按当前属性、每击修正与独立成长分源核验；不补计划中未取得的步法，不增加统一保血或输出权重。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-66532328a585941f

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md`，SHA256 `56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831`。
- 账本：silent-0021, silent-0009；原领域：combat, structure。
- 证据局/层/回合：5PM6JAQG6FNQ F33；F39第二试T2。268455请求对无毒失落打冒泡；states274379→274380能5→4，敌35血不变、仍无毒，玩家无毒雾。整轮另有动作，不能把整轮净伤归冒泡。
- 本批处置：waiting。缺同起始HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照与收益函数；持有组件和已建立状态不同，空打端点不支持启动阈值或构筑权重。
- 预期行为与验证：继续分列持有/计划/已建立；先冻结完整生产输入和受控启动后继，再讨论构筑/启动权重，不规定能力必打。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-43a76a31ba7bdcfa

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md`，SHA256 `f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c`。
- 账本：silent-0030, silent-0027；原领域：combat, sl。
- 证据局/层/回合：61E2QS63Y9WU F17 T5/T6。吸取后玩家力2→0、敏0→−2，敌力2；两防御挡0→3→6（273504/505/507）。17毒端点敌67→34，净扣33；该场首试胜不等于整局胜。
- 本批处置：waiting。缺同起始HP、构筑、完整抽序的生产整战配对及另一可核SL线路；负敏捷与17+16毒端点不足支持修改SL范围、换线偏好或阈值。
- 预期行为与验证：保留吸取、负敏捷和毒的分项事实及现有SL规则；完整对照按局分组，不把同局尝试拆成独立样本。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-5264153a4a4b0e5c

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md`，SHA256 `b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02`。
- 账本：silent-0039, silent-0209；原领域：combat。
- 证据局/层/回合：61E2QS63Y9WU F23 T2—T5。两次航行后敌力0→3→6；T4局部净扣47、损15，幻象余2仍攻击，T5才退场。当前严格整轮消费者对T4保持turn_opening_unverified。
- 本批处置：waiting。缺A10召唤、航行、复现和退场全链的冻结生产校准及另一focus完整后继；已有召唤源码/覆盖披露和T4局部端点不能证明目标排序整战收益。
- 预期行为与验证：保留全部目标选项与原排序，相同推演值并列；先按实体、当前进阶和生命周期逐步校准，不规定固定首杀。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。

### silent-proposal-bddfa690a84e03d0

- 来源：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md`，SHA256 `b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780`。
- 账本：silent-0128, silent-0079；原领域：combat。
- 证据局/层/回合：DUZUBAJ3A8GP F30四试T1—T6。首试睡层3→2→1→0，T4攻击18，T5力2攻击20；尖啸降至−4力/14攻击后，T6恢复并成长4力/22。末试T4较首试多扣本体3、同时多损2血。
- 本批处置：waiting。缺伤害唤醒、眩晕接续与当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次失败来自一局，不能拟合血价、全败排序或固定杀序。
- 预期行为与验证：保留现行睡眠/成长与目标选择；分别核期限、唤醒和各实体退出，完整后继及后置独立局才检验排序收益。
- 反例/限制：只对上述局面成立；没有未选完整胜线或独立盲测，不从失败反推另一选择必胜。原经验及原提案的范围限制保留。
- 预期影响与回退：本批仅追溯与证据交付；没有生产代码或规则需要回退，保留原日志、失败初稿和未决项。


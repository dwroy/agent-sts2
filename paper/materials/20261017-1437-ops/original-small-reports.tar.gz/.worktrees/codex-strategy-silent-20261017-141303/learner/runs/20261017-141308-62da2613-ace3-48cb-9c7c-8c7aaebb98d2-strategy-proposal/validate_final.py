import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = S.parents[2]
read = lambda name: json.loads((S / name).read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
result = read('result.json')
dispatch = json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())['batches'][result['batch']]
assert dispatch['proposal_ids'] == result['code_proposals']
assert dispatch['character'] == 'silent' and dispatch['worktree'] == str(TREE)
assert dispatch['runs'] == result['runs']
assert not dispatch.get('research_request') and not dispatch.get('implementation_request')
assert [x['id'] for x in result['proposal_results']] == dispatch['proposal_ids']
assert all(x['state'] == 'waiting' and len(x['reason']) > 10 and 'commit' not in x for x in result['proposal_results'])
assert result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == []
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert Path(result['report']) == S / 'report.md' and (S / 'proposal.md').is_file()
for key, x in read('selected-proposals.json').items():
    assert sha(Path(x['proposal']).read_bytes()) == x['proposal_sha256']
    assert sha((S / (key + '.original.md')).read_bytes()) == x['proposal_sha256']
assert sum(x['verified'] for x in read('envelope-verification.json')) == 6995
consumers = read('consumer-results.json')
assert len(consumers) == 6 and all(x['exit_code'] == 0 for x in consumers)
assert sum(x['observed_turns'] for x in consumers) == 86
assert sum(x['segments'] for x in consumers) == 168
assert all(x['full_candidate_certified'] == 0 for x in consumers)
assert read('material-checks.json')['count'] == 35
assert read('gitleaks-result.json')['exit_code'] == 0

spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
prefix = read('ledger-prefix-before.json')
path = ROOT / 'paper/materials/learning/ledger.jsonl'
raw = path.read_bytes()
assert sha(raw[:prefix['source_size']]) == prefix['sha256']
expected = {x['id'] for x in (json.loads(line) for line in (S / 'ledger-update-input.jsonl').read_text().splitlines())}
rows = []; own = []; offset = 0
for n, line in enumerate(raw.splitlines(keepends=True), 1):
    x = json.loads(line)
    if x.get('id') in expected:
        rows.append((n, x))
    if offset >= prefix['source_size'] and x.get('by') == 'learner:strategy-proposal' and (x.get('note') or '').startswith(result['batch'] + '：'):
        assert set(x) == {'op', 'id', 'ts', 'by', 'where', 'note'}
        assert x['op'] == 'update' and x['id'] in expected
        assert x['where'] == {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]}
        own.append({'line': n, 'offset': offset, 'bytes': len(line), 'sha256': sha(line), 'row': x})
    offset += len(line)
assert len(own) == 26 and {x['row']['id'] for x in own} == expected
items = m.fold(rows)
(S / 'ledger-after.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')

def protected(item):
    return {k: v for k, v in item.items() if k not in {'where', 'notes', 'history'}}

pre = read('ledger-pre-update.json')
own_lines = {x['line'] for x in own}
replayed = {}
own_verified = 0
for n, row in rows:
    before = json.loads(json.dumps(protected(replayed[row['id']]))) if n in own_lines else None
    m.apply(replayed, row)
    if n in own_lines:
        assert before == protected(replayed[row['id']]), row['id']
        own_verified += 1
assert own_verified == 26 and replayed == items
parallel_changes = {key: [field for field in set(pre[key]) | set(items[key])
                          if field not in {'where', 'notes', 'history'} and pre[key].get(field) != items[key].get(field)]
                    for key in expected}
parallel_changes = {key: fields for key, fields in parallel_changes.items() if fields}
(S / 'ledger-readback.json').write_text(json.dumps({'prefix_unchanged': True, 'own_row_protected_fields_unchanged': True,
    'own_rows_replayed': own_verified, 'parallel_net_changes_preserved': parallel_changes, 'own_updates': own}, ensure_ascii=False, indent=2) + '\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TREE, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=TREE, text=True)
assert head == result['base'] and not status
assert subprocess.check_output(['git', 'diff', '--binary'], cwd=TREE) == b''
assert subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=TREE) == b''
for x in read('source-snapshot.json')['files']:
    assert sha((TREE / x['path']).read_bytes()) == x['worktree_sha256']
validation = {'base': head, 'worktree_clean': True, 'tracked_diff_bytes': 0, 'index_diff_bytes': 0,
              'proposal_results': 10, 'waiting': 10, 'ledger_updates': 26, 'material_checks': 35,
              'consumer_exits': [0] * 6, 'observed_turns': 86, 'segments': 168,
              'production_tests': result['tests'], 'merged': None, 'gitleaks': 0}
(S / 'final-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
artifacts = []
for p in sorted(S.rglob('*')):
    if not p.is_file() or p.name == 'artifact-sha256.json' or any(x.startswith('tsx-') for x in p.relative_to(S).parts):
        continue
    digest = hashlib.sha256()
    with p.open('rb') as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    artifacts.append({'path': str(p.relative_to(S)), 'bytes': p.stat().st_size, 'sha256': digest.hexdigest()})
(S / 'artifact-sha256.json').write_text(json.dumps(artifacts, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({**validation, 'artifacts': len(artifacts)}, ensure_ascii=False))

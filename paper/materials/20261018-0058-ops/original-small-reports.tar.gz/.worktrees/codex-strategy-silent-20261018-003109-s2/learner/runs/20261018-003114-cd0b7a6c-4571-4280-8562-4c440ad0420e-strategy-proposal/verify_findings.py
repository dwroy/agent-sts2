import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = {row['source_line']: row for row in json.loads((HERE / 'focus-state-summaries.json').read_text())}
findings = []

def check(name, lines, expected, actual):
    assert actual == expected, (name, expected, actual)
    findings.append({'claim': name, 'source_state_lines': lines, 'observed': actual,
                     'scope': '已记录帧的数值核对；不认证候选完整执行或策略因果'})

def enemy(line, name):
    return next(row for row in states[line]['enemies'] if row['id'] == name)

def attack(line, name):
    return sum(item.get('total_damage') or 0 for item in enemy(line, name)['intents'] or [])

check('棱柱火花3→6、污染清除', [274830, 274833, 274834], [3, 6, 6, None],
      [enemy(274830, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'],
       enemy(274834, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'],
       states[274833]['powers']['TAINTED_POWER'], states[274834]['powers'].get('TAINTED_POWER')])
check('棱柱T5污染6/12/18、实际净HP−9', [274836, 274837, 274838, 274839], [6, 12, 18, -9],
      [states[line]['powers']['TAINTED_POWER'] for line in [274836, 274837, 274838]] +
      [states[274839]['hp'] - states[274838]['hp']])
check('下水道蚌喷水11/15/19、力0/4/8', [273237, 273252, 273263], [[11, 0], [15, 4], [19, 8]],
      [[attack(line, 'SEWER_CLAM'), enemy(line, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0)]
       for line in [273237, 273252, 273263]])
check('蚌末轮弱后14攻、10挡、2血至0', [273268, 273269], [14, 10, 2, 0],
      [attack(273268, 'SEWER_CLAM'), states[273268]['block'], states[273268]['hp'], states[273269]['hp']])
check('电击同类型/23最大HP连续观测17→19、力2→4，不认证召唤代际', [274308, 274313], [[23, 2, 17], [23, 4, 19]],
      [[enemy(line, 'ZAPBOT')['max_hp'], enemy(line, 'ZAPBOT')['powers']['STRENGTH_POWER'], attack(line, 'ZAPBOT')]
       for line in [274308, 274313]])
check('失落退场前负4力量、退场后该力量不在列表，后轮遗忘再夺2敏', [274357, 274358, 274362], [-4, None, -2],
      [states[274357]['powers']['STRENGTH_POWER'], states[274358]['powers'].get('STRENGTH_POWER'),
       states[274362]['powers']['DEXTERITY_POWER']])
check('实验体换相4/111→212/212、原4毒不在新阶段列表', [277512, 277513], [[4, 111, 4], [212, 212, None]],
      [[enemy(line, 'TEST_SUBJECT')['hp'], enemy(line, 'TEST_SUBJECT')['max_hp'],
        enemy(line, 'TEST_SUBJECT')['powers'].get('POISON_POWER')] for line in [277512, 277513]])
check('触媒已建2、当前敌无毒；后来敏5→6不回填23挡', [277519, 277523, 277526], [2, None, 5, 6, 23, 23],
      [states[277519]['powers']['ACCELERANT_POWER'], enemy(277519, 'TEST_SUBJECT')['powers'].get('POISON_POWER'),
       states[277523]['powers']['DEXTERITY_POWER'], states[277526]['powers']['DEXTERITY_POWER'],
       states[277523]['block'], states[277526]['block']])
for start, end, expected in [(277327, 277337, [0, 45]), (277366, 277373, [9, 38]),
                             (278017, 278023, [2, 25]), (278231, 278236, [10, 34])]:
    a, b = states[start], states[end]
    check('同题T1至下一轮端点净差，不认证整条候选', [start, end], expected,
          [a['hp'] - b['hp'], sum(e['hp'] for e in a['enemies']) - sum(e['hp'] for e in b['enemies'])])
check('双蟹船夹板14、另加6成20、下一轮HP不减', [278236, 278240, 278242], [14, 20, 37, 37],
      [states[278236]['block'], states[278240]['block'], states[278236]['hp'], states[278242]['hp']])
check('双蟹镣铐−9与恢复、当轮4→0攻击', [278236, 278237, 278242], [4, -9, 0, None],
      [attack(278236, 'CRUSHER'), enemy(278237, 'CRUSHER')['powers']['STRENGTH_POWER'], attack(278237, 'CRUSHER'),
       enemy(278242, 'CRUSHER')['powers'].get('STRENGTH_POWER')])
check('双蟹朝向与弱分别改变57→38→28', [278249, 278252, 278253], [57, 38, 28],
      [attack(line, 'ROCKET') for line in [278249, 278252, 278253]])
check('沙虫末轮5→0实际截断、敌154→130；37−22不充作实损', [276433, 276434], [5, 0, 154, 130, 37, 22],
      [states[276433]['hp'], states[276434]['hp'], enemy(276433, 'THE_INSATIABLE')['hp'],
       enemy(276434, 'THE_INSATIABLE')['hp'], attack(276433, 'THE_INSATIABLE'), states[276433]['block']])
(HERE / 'verified-findings.json').write_text(json.dumps(findings, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks': len(findings), 'production_tests_run': False}, ensure_ascii=False))

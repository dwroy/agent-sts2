import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch.json').read_text())
props = json.loads((HERE / 'proposals-before.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == '9f3d5745be89496398555a5a1eeda2abb995a438'
consumers = json.loads((HERE / 'consumer-summary.json').read_text())
checks = json.loads((HERE / 'evidence-checks.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())

details = [
('c20b5139dd0dff71', '感染棱柱技能污染血价',
 'DUZUBAJ3A8GP F27 T4—T6，states 274830—274839：火花3→6，T5三技能污染6/12/18，当前弱后攻击17/21/26，17挡后46→37血。T4能力FASTEN不加污染。',
 '技能同时可能提供格挡或毒，不能因本轮损9就强制禁技能。',
 '冻结本轮污染、火花、弱、牌挡和已结毒；保留全部候选。',
 '缺旧dirty运行实际移动表和火花增长/污染清除/弱/毒/挡的联合生产重放认证；没有同抽序完整替线。现有污染与增长接线只证明窄功能存在。',
 '固定274830—274839及真实A10输入，逐步比较玩家HP、毒和敌本体HP；若改变技能选择，再补按独立局分组的后置验证。'),
('ae9e692d680e3819', '失落与遗忘的夺取返还',
 '5PM6JAQG6FNQ F39 T4—T6，states 274351—274362：玩家力/敏各−4，两个步法把敏捷恢复至列表不再列出；失落退场后力量不再列出，T6遗忘再使敏捷−2。末试274391—274397仅回到−2敏，仍死亡。',
 '杀失落避免其攻击不等于能承受遗忘；本批没有遗忘退场返敏端点。',
 '逐实体保留已观察夺取与返还、玩家负属性及其来源，不设固定杀序。',
 '缺逐来源累计夺取状态和遗忘退场返敏端点，也缺另一目标顺序整战后继；一次失落返力不能证明全部返还条件。',
 '冻结两轮抢夺前后和失落退场帧，按来源核属性、毒杀与后续再抢；未观察返敏继续未知。'),
('52f1e1bd2e7db0ed', '下水道蚌加压与当前进阶事实',
 'CA5KE8GFJ9X2 F13 T1/T3/T5，states 273237/273252/273263：喷水11/15/19、力量0/4/8；273254弱后11，273268弱后14，2血10挡至273269零血。',
 '覆甲9/9/8/7/6是现场观测，不能推出全部减层触发条件；这一败局不构成新房间血价。',
 '第一样本起读当前进阶HP/伤害，保留房间代价五样本门槛；加压、弱和覆甲分列。',
 '当前按进阶取数及五样本房间门槛已有源码。仍缺冻结旧运行输入下加压/覆甲/弱的联合生产重放与完整减层条件，不能将整项登记duplicate。',
 '以原A10移动表和273237—273269校对每步；新增条件须由本角色独立观测支持，不改房间门槛。'),
('6dd8bbff876be528', '电击机器人成长与召唤身份',
 '5PM6JAQG6FNQ F38 T3/T4，states 274308/274313：同类型且最大HP23的电击力2→4，攻击17→19；T3仍在场贡献17，274317才不在名单。',
 '类型与最大HP相同不是可靠跨召唤实例身份；未执行的先杀线不作整场胜因。',
 '核验既有HIGH_VOLTAGE逐实体增长；新增召唤者不继承旧实体状态，不强制杀序。',
 '缺可靠召唤代际身份、旧实际移动输入和另一杀序完整后继。现有growth及召唤路径不足以认证本提案完整重置。',
 '冻结召唤前后名单与移动表，逐实例重放增长/退场；无法区分代际时保留未知。'),
('578e415a259e6835', '沙虫选线与实际资源分账',
 '8JRE1C4H4Z2W F33首/三试T2，decisions 270216/270282指纹相同；现有消费者核回实际玩家−3/−15、敌−10/−17。末试T11 states 276433→276434为玩家5→0、敌154→130，显示37攻/22挡。另含F17护栏与路线资源原提案。',
 '37−22=15只是未截断攻击参考，实扣只能记5；省血候选也可能少输出/成长。首/三试五轮预测0/24与5/24不可称同死率。',
 '原答、护栏后、SL后、首次派发、重规划及实际HP/毒/能力/沙坑分账；保留旧选择。',
 '已有候选阶段、派发、端点及终局审计；仍缺完整续步归属、沙坑逐来源与路线链的联合执行认证，以及同抽序整战替线后继。未发现可确证的新预测冒充实值错误。',
 '固定首/三试T2、第二试T5、F17T6和末T11核前缀/重问/截断；单动作回执不认证全候选。'),
('c0767768bf6a7ab1', '实验体全败SL替换血价',
 'YF0LXT1QSTGG F48二/三试T1，decisions 271309/271348指纹相同；states 277327→277337和277366→277373，玩家损0/9、敌净扣45/38。',
 'T1端点可核，但既有审计器因缺前轮边界保留turn_opening_unverified；不能把整轮差归给一条完整候选。F33第二次SL实胜，反对全面禁SL。',
 '记录原线/替线当轮代价、预测样本和续步中断，保留探索规则。',
 '已有resource_comparison明确current_turn_prediction且execution=unverified。缺完整候选及逐来源血价认证、同抽序整战替线和独立胜线，不能拟惩罚系数或禁止探索。',
 '将候选0/10损与54/36伤、端点0/9损与45/38净扣分开验证；保留未完成候选和成功SL反例。'),
('a46bdb7fe711d79a', '实验体阶段与毒/敏捷兑现',
 'YF0LXT1QSTGG F48末试T3—T5，states 277512/277513为4/111含4毒→212/212且旧毒不在列表；277519触媒2已建而零毒，277523先有23挡/5敏，277526取第6敏后仍23挡。',
 '已建毒雾或触媒也有失败尝试，未施放的持牌不作已兑现收益；没有第三阶段或替代构筑完整结果。',
 '当前阶段、已建/仅持有组件、当前毒、已结毒伤及敏捷取得顺序分列，不倒补旧挡。',
 '已有silentPhaseCurrentFacts和离线相邻观测。缺逐候选施毒/已结毒伤/额外扣血/敏捷顺序的完整执行归属；当前快照及阶段修复不等于整项联合认证，不调整排序。',
 '按277512—277528核换相、零毒触媒和23挡；跨阶段不以敌净血差补毒伤，抽弃牌后重新界定候选。'),
('1044224808015e5c', '双蟹零胜并列探索血价',
 'XP2SL33HT0D9 F33首/二试T3，decisions 271992/272040同指纹，现有消费者核实损9/14、敌净扣24/27。首/末T1 decisions 271982/272195同指纹；states 278017→278023与278231→278236，损2/10、净扣25/34，末试多1力量。',
 '成长同时变化；后轮抽弃牌未受控，T1开场在消费者中仍为unknown，不能据单轮差证明整战最优。',
 '并列原因、当轮HP/输出/成长分列；仅在独立后继支持后研究更窄并列策略。',
 '当轮血价已核，缺同抽序完整替线、成长兑现后继及独立整战胜线；不据局部差额拟全局HP系数或新并列规则。',
 '固定两组同指纹端点并保留1力量；按run分训练/后置验证，六尝试计一个相关局。'),
('7cbc6005db712ba9', '双蟹朝向、临时减力与格挡',
 'XP2SL33HT0D9 F33末试T2—T5，states 278236/278240为14→20挡，278237镣铐爪−9力/0攻击，278242恢复；278249/278252/278253激光57→38→28；278255四敏脆弱下6挡，T5开场11血。',
 '朝向与弱分别贡献19/10，不能混归因；已建4敏不保证整战存活，船夹板14不是每轮收益。',
 '既有/新增挡、朝向、弱、临时属性、已结毒和可存活HP在同候选分源展示。',
 '现有被动挡、朝向计算与观察参考有窄实现，但缺逐候选完整联合执行认证。未由本批证据找到新源码失配，不重复新增已有字段，也不冒标整个提案duplicate。',
 '固定14+6=20、0→−9→恢复、57→38→28及脆弱6挡；末轮毒与零血截断另列。'),
('c59f592f1427a67e', '综合机制、SL与路线资源闭环',
 'YF0LXT1QSTGG F48二/三试T1及末T4/T5；XP2SL33HT0D9 F33首/二试T3、首/末T1及末T2—T5。以上数值逐帧核回，关联路线/休息/药栏变化保存在resource-timeline.json，不自动将重置计回血。',
 '同存档尝试相关；药栏恢复不等新获得药，净HP变化也不能自动归于治疗。另一留药/路线时机没有受控整战对照。',
 '分段保存原答/替线/实际端点，按能力/格挡/毒/药水/路线来源记资源，保留原规则。',
 '已有候选及观测审计不能替代逐来源资源账与完整候选执行的联合认证；缺路线/药水时机受控替线和独立整战后继，保持waiting。',
 '复用两局相同指纹组及阶段/临时减力帧，对全部胜战耗血、非战斗变化、SL恢复和药栏分别核来源；缺来源留null。'),
]

assert {f'silent-proposal-{item[0]}' for item in details} == set(dispatch['proposal_ids'])
results = [{'id': 'silent-proposal-' + suffix, 'state': 'waiting', 'reason': reason}
           for suffix, title, evidence, counter, expected, reason, method in details]
payload = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-003109-s2-strategy-proposal',
           'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
           'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'],
           'implementation_domains': [], 'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'report.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')

parts = ['# 静默猎手十项已派发策略提案复核\n',
         f'批次：20261018-003109-s2-strategy-proposal。基线：`{base}`。仅处理dispatch.json中的十个ID；普通队列reason=proposal，无research_request或implementation_request。根deck-size专题绑定另一批次，未承接该专题。`git merge --no-edit main` 返回Already up to date。\n',
         '六局经runs.jsonl核实均SILENT/A10，历史执行提交均带dirty，不能声称当前源码精确复原旧运行输入。原提案十份Markdown均以专用队列保存SHA核同，原件逐字保存在*.original.md；原账本用现有fold函数累计证据/链接读取，没有用最后一行覆盖历史。\n',
         '结论：十项均waiting；当前窄功能已经存在，本批没有发现证据充分的新源码失配，也没有足够数据启用新的选线/药水/SL/终局系数。缺口逐项列下，保留待有合适新局后重派。本报告不新增代码提案ID、不重复历史复盘、不改知识或生产源码。\n']
for suffix, title, evidence, counter, expected, reason, method in details:
    ident = 'silent-proposal-' + suffix
    item = props[ident]
    parts += [f'## {ident}：{title}\n',
              f'状态：waiting。账本：{", ".join(item["ledger"])}。原提案SHA256：`{item["proposal_sha256"]}`。\n',
              f'证据：{evidence}\n', f'反例与边界：{counter}\n',
              f'旧行为/现状：{item["summary"]}当前对应窄接线见source-readback.json；源码路径存在不当作整个提案实现证明。\n',
              f'预期行为：{expected}\n', f'本批未实现原因：{reason}\n',
              f'验证方法：{method}\n',
              '拟合与回退：本批不拟合参数；六局只作发现与固定回归，SL尝试不扩独立样本数。未来新局按run_id和开始时间切分，完整验证后才考虑策略改变；本批无生产改动，无源码回退对象，材料/原失败永久保留。\n']
(HERE / 'proposal.md').write_text('\n'.join(parts), encoding='utf8')

table = '\n'.join(f'| {row["stream"]} | {row["source_size"]} | {row["verified_rows"]} |'
                  for row in checks['streams'])
source_table = '\n'.join(f'| {row["path"]} | `{row["last_source_commit"]}` | {row["is_live_ancestor"]} |'
                         for row in source)
body = f'''# 本批策略提案处置报告

完成记录时间：{(HERE / 'report-time.txt').read_text().strip()}。

本批十个提案全部逐项核验并保留waiting，具体证据、账本、反例、预期行为及下一次验收见proposal.md。未修改生产源码/知识，未提交、未合入live、未创建eval版本或双通知，不登记implemented/shipped；fixes=[]、merged=null。无规则上线，不需要修改decision-log或通知运维已发布。

## 身份与基线

- 基线/最终HEAD：`{base}`；启动git status干净，合并main无新增提交。
- task=strategy-proposal、character=silent、batch=20261018-003109-s2-strategy-proposal；派发路径与本工作树相同，proposal_ids精确十项。未处理其他队列或其他角色知识。
- 六局来源：{', '.join(dispatch['runs'])}；均已核SILENT/A10，均以自己的原始所属局字段识别，正文提及不算所属局。
- 运行历史均为2026-10-07的dirty树。当前源码/知识的存在与静态读回不能替代旧实际输入认证；宽请求不因窄子项已存在而关闭。

## 原始证据与限制

共同入口extract_evidence.py提取八流，选中{checks['total_verified_rows']}行；本批逐行重新seek原源文件，核offset、bytes、SHA256及原JSON相等，且输出文件SHA与manifest一致。source_size逐流冻结，不将并行追加内容混入本批。manifest记录states/decisions/brain各2条源无效行，其余0，无不完整尾行；无效行无法分配角色，不宣称原日志全无问题。

| 流 | 冻结source_size（字节） | 已核所属局行数 |
|---|---:|---:|
{table}

fight-plans在该冻结截点选中0行只说明没有匹配，不能推断所有原日志缺失。run-plans明确匹配run字段，选中33行。没有覆盖旧0行或旧报告。

重点原帧摘要在focus-state-summaries.json，四组同指纹核验在paired-decisions.json，16项材料数值核验在verified-findings.json；它们不是生产测试。完整原字节追溯见evidence/各流及evidence-checks.json。

## 既有消费者实际读回

以当前learner/lib/selection-execution.ts消费六局限定楼层冻结输入，无LLM、网络、游戏或刷新知识读取。输入{sum(r['input_decisions'] for r in consumers)}个决策、{sum(r['input_states'] for r in consumers)}个状态；产生{sum(r['segments'] for r in consumers)}个候选段和{sum(r['observed_turns'] for r in consumers)}个回合窗，其中{sum(r['verified_turns'] for r in consumers)}个具备已核回合端点。全部完整候选结果仍为null，不认证整条候选完整执行。

重点：8JRE F33首/三试T2核回实损3/15、净扣10/17；XP2 F33首/二试T3核回实损9/14、净扣24/27。YF F48和XP2 F33的T1虽有原始数值端点，消费者因缺前轮开场证明仍保留turn_opening_unverified，未把手工端点核验包装为完整回合/候选认证。末局截断的5→0与显示37−22=15分别保存。

resource-timeline.json保留六局楼层、进出战斗、药栏和非战斗HP变更的原帧端点，来源未确证时为null；SL回合回退不算治疗。它不是逐击/路线完整归因，也不证明留药或改线会赢。没有获得独立整战反事实，不拟新权重。

## 既有源码范围

核对16个实际读取路径的SHA和最后源码提交，并检查均为当时live祖先。下列提交仅证明对应路径历史，不能代替整提案implemented/duplicate；本批proposal_results均waiting，不填这些窄提交冒充交付。

| 源码路径 | 最后源码提交 | live祖先 |
|---|---|---|
{source_table}

候选审计scope=predicted_candidates、SL血价scope=current_turn_prediction、派发scope=single_action_receipt，均保留实际全候选未知；阶段当前事实分开持牌、已建与当前毒，未倒补后取得敏捷。当前按进阶取数和房间ROOM_COST_MIN_N=5路径仍在。无新的确定失配，重复添加同样字段不构成实现。

## 核验失败历史与测试口径

材料初稿verify_findings.py把XP2首试T1的states278022误作T2，实际该帧仍T1选牌后，导致预期损2却读到0，退出1；原findings.stdout/stderr与verify_findings.initial.txt保留。核原帧后改用真正T2开场278023，findings-corrected.*退出0，16项材料数值核对完成。此为证据定位修正，不是撤生产源码失败/恢复通过。

若干源码定位命令查到不存在的候选文件名，随后通过rg确认实际路径；未据查找失败断言功能不存在。消费者首轮退出0。没有新增生产源码，所以没有执行撤源码红绿、tsc、vitest或test-sandbox；tests固定为{{"tsc":null,"vitest":null,"cases":null}}，不引用历史测试冒称本批通过。

## 账本及交接

全部十份原提案SHA核同；仅复用已登记ID，不另建重复提案。30个关联账本通过根learner/ledger.py update追加本批报告/提案路径和限定复核注记，不追加重复实盘证据，不把已有shipped状态改写为本批上线，原状态保留。CLI实际结果、gitleaks及最终工作树检查另见本目录回执与acceptance.json；只有其真实成功后才认为记录闭环完成。

运维交接提案：{HERE / 'proposal.md'}。
逐项处置和完整40位base：report.json；没有新提交、merged、版本或可登记shipped的交付。
'''
(HERE / 'report.md').write_text(body, encoding='utf8')

updates = []
for ident in sorted({i for p in props.values() for i in p['ledger']}):
    linked = [p for p in results if ident in props[p['id']]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261018-003109-s2-strategy-proposal：仅复核已派发ID：' +
                    ','.join(p['id'] for p in linked) + '；六局SILENT/A10原始八流8274行offset/bytes/SHA核同。限定端点及既有消费者读回不认证完整候选执行/整战因果，相关提案均waiting；缺口逐项见本批proposal.md。未修改源码/知识、未上线、不新增重复实盘证据；本次仅补追溯链接，原状态保留。'})
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'proposals': len(results), 'waiting': len(results), 'ledger_updates_prepared': len(updates),
                  'report': str(HERE / 'report.md')}, ensure_ascii=False))

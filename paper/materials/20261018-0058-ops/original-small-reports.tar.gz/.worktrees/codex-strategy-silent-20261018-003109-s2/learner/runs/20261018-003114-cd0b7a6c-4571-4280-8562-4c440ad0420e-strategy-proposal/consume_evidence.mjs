import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { auditSelectionExecution } from '../../lib/selection-execution.ts';

const here = fileURLToPath(new URL('.', import.meta.url));
const dispatch = JSON.parse(readFileSync(`${here}dispatch.json`, 'utf8'));
const results = [];
for (const run of dispatch.runs) {
  const input = JSON.parse(readFileSync(`${here}${run}.audit-input.json`, 'utf8'));
  const audit = auditSelectionExecution(input);
  const summary = {
    run_id: run,
    input_decisions: input.decisions.length,
    input_states: input.states.length,
    output_keys: Object.keys(audit),
    segments: audit.segments.map((segment) => ({
      source_line: segment.source_line,
      attempt: segment.attempt,
      boundary: segment.boundary,
      action_count: segment.actions.length,
      actual_full_candidate_result: segment.actual_full_candidate_result,
      actual_rollout_best: segment.actual_rollout_best,
    })),
    observed_turns: audit.observed_turns ?? null,
    terminal_endpoints: (audit.observed_actions ?? []).filter((action) => action.terminal_observation?.status === 'observed_terminal_endpoints'),
    scope: '既有离线消费者读回；没有运行求解器、LLM或游戏，不证明完整候选执行或策略改善',
  };
  writeFileSync(`${here}${run}.audit-readback.json`, JSON.stringify(summary, null, 2) + '\n');
  results.push({ run_id: run, input_decisions: input.decisions.length, input_states: input.states.length,
    segments: audit.segments.length,
    complete_candidate_results: audit.segments.filter((segment) => segment.actual_full_candidate_result != null).length,
    observed_turns: (audit.observed_turns ?? []).length,
    verified_turns: (audit.observed_turns ?? []).filter((turn) => turn.status === 'observed_turn_endpoints').length,
  });
}
writeFileSync(`${here}consumer-summary.json`, JSON.stringify(results, null, 2) + '\n');
process.stdout.write(JSON.stringify(results) + '\n');

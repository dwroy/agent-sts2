import collections
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'learner'))
from extract_evidence import run_identity

dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
rows = {}
checks = []
for stream in manifest:
    name = stream['stream']
    path = HERE / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    selected = []
    counts = collections.Counter()
    with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for encoded in path.open('rb'):
            digest.update(encoded)
            entry = json.loads(encoded)
            assert entry['run_id'] in runs
            assert run_identity(entry['row']) == entry['run_id']
            assert entry['offset'] + entry['bytes'] <= stream['source_size']
            source.seek(entry['offset'])
            raw = source.read(entry['bytes'])
            assert hashlib.sha256(raw).hexdigest() == entry['sha256']
            assert json.loads(raw) == entry['row']
            counts[entry['run_id']] += 1
            selected.append(entry)
    assert digest.hexdigest() == stream['output_sha256']
    assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
    rows[name] = selected
    checks.append({'stream': name, 'source_size': stream['source_size'], 'verified_rows': len(selected),
                   'offset_bytes_sha_verified': True, 'output_sha256': digest.hexdigest()})

run_rows = {entry['run_id']: entry['row'] for entry in rows['runs']}
assert set(run_rows) == set(runs)
assert all(row['character'] == 'SILENT' and row['ascension'] == 10 for row in run_rows.values())

def summary(entry):
    state = entry['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    powers = lambda data: {item['power_id']: item['amount'] for item in (data or [])}
    return {'source_line': entry['line'], 'run_id': entry['run_id'], 'floor': run.get('floor'),
            'turn': state.get('turn'), 'screen': state.get('screen'),
            'observed_ts': entry['row'].get('observed_ts'),
            'hp': player.get('current_hp', run.get('current_hp')), 'block': player.get('block'),
            'powers': powers(player.get('powers')), 'cards_played': combat.get('cards_played_this_turn'),
            'enemies': [{'id': e['enemy_id'], 'index': e.get('index'), 'hp': e.get('current_hp'),
                         'max_hp': e.get('max_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
                         'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies') or []]}

focus = {'DUZUBAJ3A8GP': [27, 30], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
         '8JRE1C4H4Z2W': [17, 33], 'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [29, 33]}
state_summaries = [summary(entry) for entry in rows['states']
                   if (entry['row']['state'].get('run') or {}).get('floor') in focus[entry['run_id']]]
(HERE / 'focus-state-summaries.json').write_text(json.dumps(state_summaries, ensure_ascii=False, indent=2) + '\n')

paired_lines = [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]
decisions = {entry['line']: entry for entry in rows['decisions']}
pairs = []
for a, b in paired_lines:
    before, after = decisions[a]['row'], decisions[b]['row']
    assert before['fingerprint'] == after['fingerprint']
    pairs.append({'source_lines': [a, b], 'run_id': before['run_id'], 'floor': before['floor'],
                  'turn': before['turn'], 'same_fingerprint': True,
                  'fingerprint_sha256': hashlib.sha256(before['fingerprint'].encode()).hexdigest(),
                  'attempts': [before.get('sl_attempt'), after.get('sl_attempt')],
                  'original_answers': [before.get('answers'), after.get('answers')],
                  'sl': [before.get('sl_explore'), after.get('sl_explore')]})
(HERE / 'paired-decisions.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')

exclusions = []
for run in runs:
    selected_decisions = []
    selected_states = []
    for entry in rows['decisions']:
        row = entry['row']
        if entry['run_id'] != run or row.get('floor') not in focus[run]:
            continue
        if not row.get('decision_id') or not row.get('observed_ts'):
            exclusions.append({'run_id': run, 'source_line': entry['line'], 'reason': '缺 decision_id 或 observed_ts 的元数据行'})
            continue
        selected_decisions.append({**row, '_line': entry['line'], '_source_sha256': entry['sha256']})
    for entry in rows['states']:
        row = entry['row']
        if entry['run_id'] != run or (row['state'].get('run') or {}).get('floor') not in focus[run]:
            continue
        # Keep the consumer's fields; the complete original bytes remain in evidence/.
        state = row['state']
        info = state.get('run') or {}
        projected = {k: state.get(k) for k in ['run_id', 'turn', 'screen', 'in_combat', 'combat']}
        projected['run'] = {k: info.get(k) for k in ['character_id', 'ascension', 'floor', 'current_hp', 'max_hp', 'potions']}
        selected_states.append({**{k: v for k, v in row.items() if k != 'state'}, 'state': projected,
                                '_line': entry['line'], '_source_sha256': entry['sha256']})
    selected_decisions.sort(key=lambda row: row['observed_ts'])
    frozen = {'run': run_rows[run], 'decisions': selected_decisions, 'states': selected_states}
    (HERE / (run + '.audit-input.json')).write_text(json.dumps(frozen, ensure_ascii=False) + '\n')

result = {'streams': checks, 'total_verified_rows': sum(item['verified_rows'] for item in checks),
          'run_identity_verified': True, 'all_silent_a10': True, 'audit_input_exclusions': exclusions,
          'focus_floors': focus, 'same_fingerprint_pairs': pairs,
          'scope': '原字节核对与有界离线材料审计，不是生产测试或完整候选执行认证'}
(HERE / 'evidence-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': result['total_verified_rows'], 'counts': checks,
                  'excluded_metadata': len(exclusions), 'same_fingerprint_pairs': len(pairs)}, ensure_ascii=False))

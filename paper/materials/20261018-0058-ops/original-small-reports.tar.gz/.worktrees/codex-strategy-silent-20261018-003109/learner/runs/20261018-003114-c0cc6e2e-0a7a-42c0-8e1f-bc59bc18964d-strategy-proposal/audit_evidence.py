import collections
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
DISPATCH = json.loads((HERE / 'dispatch.json').read_text())
RUNS = set(DISPATCH['runs'])


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def identity(row):
    state = row.get('state') or {}
    fingerprint = row.get('fingerprint')
    if isinstance(fingerprint, str):
        try:
            fingerprint = json.loads(fingerprint)
        except ValueError:
            fingerprint = None
    values = [row.get('run_id'), state.get('run_id'), row.get('run')]
    if isinstance(fingerprint, dict):
        values.append(fingerprint.get('run'))
    unique = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(unique)) if len(unique) == 1 else None


def powers(entity):
    return {p['power_id']: p['amount'] for p in entity.get('powers', [])}


def card(raw):
    return {k: raw.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'dynamic_values']}


manifests = []
for dirname in ['evidence', 'evidence-runs']:
    manifests.extend((dirname, r) for r in json.loads((HERE / dirname / 'evidence-manifest.json').read_text()))
states = {}
decisions = {}
attempts = []
configs = []
run_rows = []
readback = []
for dirname, manifest in manifests:
    stream = manifest['stream']
    path = HERE / dirname / f'{stream}.evidence.jsonl'
    counter = collections.Counter()
    seen = set()
    digest = hashlib.sha256()
    with path.open('rb') as handle, (Path('/home/dw/Projects/agent-sts2/logs') / f'{stream}.jsonl').open('rb') as source:
        for encoded in handle:
            digest.update(encoded)
            item = json.loads(encoded)
            row = item['row']
            assert item['run_id'] in RUNS and identity(row) == item['run_id']
            assert item['line'] not in seen
            seen.add(item['line'])
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == row
            counter[item['run_id']] += 1
            if stream == 'states':
                s = row['state']
                assert s['run']['character_id'] == 'SILENT' and s['run']['ascension'] == 10
                states[item['line']] = item
            elif stream == 'decisions':
                decisions[item['line']] = item
            elif stream == 'sl-attempts':
                attempts.append(item)
            elif stream == 'run-config':
                configs.append(item)
            elif stream == 'runs':
                assert row['character'] == 'SILENT' and row['ascension'] == 10
                run_rows.append(item)
    assert all(counter[r] == n for r, n in manifest['counts'].items())
    assert digest.hexdigest() == manifest['output_sha256']
    readback.append({**manifest, 'verified_lines': sum(counter.values()), 'raw_bytes_verified': True,
                     'identity_verified': True})
save('evidence-readback.json', readback)
save('runs-verified.json', run_rows)

floors = {'VLZ6CCT8AQ0A': {35, 36, 37, 43, 44, 45}, '8JRE1C4H4Z2W': {17, 33},
          'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 38, 39},
          '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}
facts = []
for number, item in states.items():
    s = item['row']['state']
    info = s['run']
    if info['floor'] not in floors[item['run_id']]:
        continue
    combat = s.get('combat') or {}
    player = combat.get('player') or {}
    facts.append({'line': number, 'offset': item['offset'], 'sha256': item['sha256'], 'run': item['run_id'],
                  'floor': info['floor'], 'turn': s['turn'], 'screen': s['screen'],
                  'observed_ts': item['row']['observed_ts'],
                  'hp': player.get('current_hp', info['current_hp']), 'max_hp': info['max_hp'],
                  'energy': player.get('energy'), 'block': player.get('block'),
                  'played': player.get('cards_played_this_turn'), 'powers': powers(player),
                  'deck_upgraded': sum(bool(c.get('upgraded')) for c in info['deck']),
                  'hand': [card(c) for c in combat.get('hand', [])],
                  'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block',
                                                     'is_alive', 'move_id', 'powers', 'intents']}
                              for e in combat.get('enemies', [])]})
save('selected-state-facts.json', facts)
selected_decisions = []
for number, item in decisions.items():
    row = item['row']
    if row.get('floor') not in floors[item['run_id']]:
        continue
    selected_decisions.append({'line': number, 'offset': item['offset'], 'sha256': item['sha256'],
                               'row': {k: row.get(k) for k in ['run_id', 'decision_id', 'observed_ts', 'floor',
                                   'turn', 'label', 'screen', 'sl_attempt', 'sl_reloads', 'chosen', 'result',
                                   'answers', 'questions', 'journal', 'hp_guard', 'sl_explore', 'selection_audit']}})
save('selected-decision-facts.json', selected_decisions)
save('sl-records.json', attempts)


def state(number):
    return states[number]['row']['state']


def player(number):
    return state(number)['combat']['player']


def hand(number, key):
    return next(c for c in state(number)['combat']['hand'] if c['card_id'] == key)


def value(number, key, field):
    return next(v['current_value'] for v in hand(number, key)['dynamic_values'] if v['name'] == field)


checks = []


def check(label, actual, expected, lines):
    checks.append({'label': label, 'actual': actual, 'expected': expected, 'source_lines': lines,
                   'pass': actual == expected})


check('六局角色与进阶', sorted({(r['row']['character'], r['row']['ascension']) for r in run_rows}),
      [('SILENT', 10)], [r['line'] for r in run_rows])
check('神化实付能量', [player(n)['energy'] for n in [275564, 275565]], [7, 5], [275564, 275565])
for key, field, expected in [('DEFEND_SILENT', 'Block', [5, 8]), ('STRIKE_SILENT', 'Damage', [7, 10]),
                              ('DAGGER_SPRAY', 'Damage', [5, 7])]:
    check('F35神化升级-' + key, [value(n, key, field) for n in [275564, 275565]], expected, [275564, 275565])
check('必备工具费用', [hand(n, 'TOOLS_OF_THE_TRADE')['energy_cost'] for n in [275564, 275565]],
      [1, 0], [275564, 275565])
check('F43同战后抽毒雾已升级', hand(275687, 'NOXIOUS_FUMES')['upgraded'], True, [275687])
check('F43场外升级数不变', [sum(bool(c.get('upgraded')) for c in state(n)['run']['deck'])
                              for n in [275679, 275680, 275687]], [4, 4, 4], [275679, 275680, 275687])
check('F45未升级能力实际层数', [powers(player(275732)).get(k, 0) for k in ['FASTEN_POWER', 'ACCELERANT_POWER']],
      [4, 1], [275732])
check('F45首轮结束手牌为空', len(state(275732)['combat']['hand']), 0, [275732])
check('8JRE首试与第三试T2同指纹', decisions[270216]['row']['fingerprint'] == decisions[270282]['row']['fingerprint'],
      True, [270216, 270282])
check('甲虫尖啸前后力量', [powers(state(n)['combat']['enemies'][1]).get('STRENGTH_POWER', 0)
                               for n in [274931, 274932]], [2, -4], [274931, 274932])
check('甲虫尖啸前后攻击', [sum(i.get('total_damage') or 0 for i in state(n)['combat']['enemies'][1]['intents'])
                               for n in [274931, 274932]], [20, 14], [274931, 274932])
save('fact-checks.json', checks)
summary = {'verified_lines': sum(r['verified_lines'] for r in readback),
           'selected_states': len(facts), 'selected_decisions': len(selected_decisions),
           'fact_checks': len(checks), 'fact_failures': sum(not c['pass'] for c in checks),
           'scope': '原始数据核验，非生产源码测试或完整候选执行认证'}
save('audit-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))
assert all(c['pass'] for c in checks)

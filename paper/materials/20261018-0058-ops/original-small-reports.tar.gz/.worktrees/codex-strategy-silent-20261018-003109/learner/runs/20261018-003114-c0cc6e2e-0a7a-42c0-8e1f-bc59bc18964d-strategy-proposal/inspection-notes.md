# 本批读取异常与限制

- 只读旧报告本身可访问，随后查旧selected-state-facts.json过程路径时FileNotFoundError；未据此断言原证据丢失，改用本批共用抽取重新核证，未展开旧副本。
- 首条抽到的状态在F1且combat=null，初次交互检查调用get时报AttributeError；正式audit_evidence.py用空对象分支处理，6995行核验退出0。
- combat-decision-audit.ts、core/loop.ts、monster-script.ts是初次猜测路径，rg报不存在；改由真实silent-selection-audit.ts、silent-selection-dispatch.ts、silent-hp-guard-audit.ts与生产接线检索核现状。
- 上述均为读取/定位错误，没有改生产源码，也不是红绿测试或游戏机制反证。完整工具输出由原启动器转录保留；本目录保留正式脚本、原数据封套和核验log。

# 静默猎手本批策略提案处置

记录时间：2026-10-18T00:43:56+08:00。batch=20261018-003109-strategy-proposal，task=strategy-proposal，character=silent。
基线：9f3d5745be89496398555a5a1eeda2abb995a438。本批无research_request/implementation_request/proposal_repair，仅处理派来的十个原id。

本批十项均waiting。逐项读回原Markdown及SHA、原账本、相关静默经验和本角色六局证据；未发现可据本批证据新增的确定源码失配。已有窄实现不能关闭跨中断归属、复合校准或受控整战的宽请求。没有新源码、知识改动、提交、live合入、版本或shipped。

样本边界：六局均runs.jsonl核为SILENT/A10；SL尝试不扩分母。这六局及关键帧已经用于历史发现，不是后置独立验证。不用预训练游戏事实补结论，不读取其他角色私有知识。下面的旧行为是本批读到的现状，未改变规则。

## silent-proposal-89354805ee4d7e77：神化升级传播与实际施放归属

来源：postmortem → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。
账本：silent-0237、silent-0238。已观察范围：本条所列静默A10局面。

证据：VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1；states275564/275565、275679/275680/275687、275722/275732；decisions269706/269707。

本次核实：神化实付2能：7→5；防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费。F43同序题面43伤/14损→51伤/13损，下一轮77HP、敌203HP与90HP/254HP起点相符；场外升级数始终4。

反例及未知：F45已持有神化却未兑现升级，实际勒紧4/触媒1；F43施放仍有整战损血，不能把不同敌人与资源下的胜负当因果。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：保留已证普通/升级配对，按本战真实施放传播已覆盖效果，未知组合保留unknown，持有/候选/施放分账。

验证方法：冻结F35/F43/F45状态与动作身份，逐项核升级、费用、后抽、已升级不重复及场外deck不变，再核跨中断归属；新增源码必须撤修失败/恢复通过。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整消费者核验；现有升级配对只覆盖限定子项。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-f2bfceddb1898dca：随机药水MC与推演预算成熟度

来源：postmortem → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。
账本：silent-0106、silent-0019、silent-0201。已观察范围：本条所列静默A10局面。

证据：VLZ6CCT8AQ0A A10 F45 T1/T4；decisions269748、269754、269770；F43/F44资源链仅作本局前置条件。

本次核实：269748药水仅1/12样本，原题明写707ms被MC占用、rollout预算退化；269754药水12/12但中位线后继仅3样本，牌堆状态已变。痊愈药水原文是+1能、抽2牌。

反例及未知：两问不是同盘预算实验；后一问样本完成也不代表整战模拟成熟或另一focus必胜。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：保留预算、护栏及留药规则，继续分列随机药水样本、真实抽牌后重问、后继推演样本与未知；相同值列并列。

验证方法：先冻结原始dirty输入、随机池及模型覆盖，再同总预算比较原策略与分阶段策略，按局号分组、后置独立局验证；不可用707ms单点拟合常量。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺同起点、同随机池、同总预算的MC策略配对及候选稳定性/成熟度曲线；两次不同盘面不能确定新预算、留药或目标规则。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-283a164780d11e69：神化经验链补链提案

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。
账本：silent-0237、silent-0238。已观察范围：本条所列静默A10局面。

证据：VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1；与89354805ee4d7e77共用上述原帧。

本次核实：原经验silent-apotheosis-combat-upgrades与原postmortem提案同源，SHA及silent-0237/0238链接核同；本批只有该局普通神化帧，不借经验中另一局升级版本当本批实测。

反例及未知：同题同源不增加独立样本；存在窄升级源码不能证明整个宽提案已经实现。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：复用原神化实现链与真实证据，不新增重复id、不重复实现；完成后才引用实际live祖先源码提交。

验证方法：与89354805ee4d7e77联合核固定帧及跨中断消费者；二者各保留独立来源链接，不将一个原提案号冒充另一个已实现号。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。同源神化经验链仍缺实际施放持续归属和完整消费核验，不能仅凭题意重复或局部源码登记duplicate。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-ebbfe3b97548756d：十五项机制与资源的联合验证

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。
账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。已观察范围：本条所列静默A10局面。

证据：VLZ6CCT8AQ0A A10 F35 T1、F43 T1—T5、F44、F45 T1—T5；原提案列15经验及14账本id。

本次核实：已读15经验对应原提案与本批账本，神化前后费用/属性、F43后抽升级及F45普通能力层数可以逐帧核；不把持有能力预支成实际持续收益。

反例及未知：F43施放升级与F45未施放，场地、牌序和资源不同；单轮临减、现场覆甲、休息增上限各有期限及来源。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：按当前属性、逐击力量、逐牌敏捷、毒触发、临减恢复、覆甲和真实回复分源；准确子实现保持，未知不补固定加分。

验证方法：逐子机制冻结原卡、属性、进阶敌人数据库和消费者输入，联合回放状态期限及资源链；房间统计继续保留5样本门槛。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺十五机制逐来源、持续期限、升级属性组合与战斗—路线—休息消费者的固定联合校准；局部原帧和已有子实现不足关闭整项。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-e5b87be50f28f311：HP护栏、SL换线与实际执行审计

来源：postmortem → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。
账本：silent-0079、silent-0021、silent-0125、silent-0018。已观察范围：本条所列静默A10局面。

证据：8JRE1C4H4Z2W A10 F33 首/第三试T2、第二试T5，兼原提案F17 T6及末试T11；decisions270216/270282/270264。

本次核实：270216与270282指纹完全一致；270282原线预测3损/10伤、替换15损/17伤，原/替换五轮推演死亡0/24、5/24不同，future loss同为47。270264原答预测16损/43伤，journal已是护栏后的另一线。

反例及未知：候选多12血/7伤的预测差不自动等于所有后续实付；单动作completed回执不能认证整线，末试延长仍失败也不能推出一律少防御。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：保持原选择规则，将Jev原答、护栏后、SL后、实际派发和重规划分账，能力建立须由状态确认。

验证方法：冻结同盘T2、第二试T5、F17抽牌重问与末试T11，校验实际前缀及中断；不得把候选差、整轮净扣和未选反事实混算。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。已有候选阶段与单动作派发审计，仍缺跨抽牌、选牌、重问和SL的持续执行归属及实际整线收益认证。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-49632bc4878fb597：力量、敏捷、虚弱与蚌独立成长

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。
账本：silent-0005、silent-0231。已观察范围：本条所列静默A10局面。

证据：CA5KE8GFJ9X2 A10 F13 T1/T3/T5；states273237、273252、273263—273268。

本次核实：三次喷水前力量0/4/8、威胁11/15/19；末轮弱后14，2HP/10挡完整需损4。原本计划步法没有取得，不能补正敏捷。

反例及未知：弱并未停止下一次成长；本局没有正敏捷样本，不能由一个既有步法源码证明复合路径。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：继续分项核当前属性、逐击修正及成长；不增加统一保血/输出权重。

验证方法：用本局固定喷水帧核弱及成长，正负敏捷另需本角色可核输入；同一联合调用的状态/牌挡/敌招式逐步比对后才判断完整覆盖。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺力量逐击、正负敏捷、虚弱与独立成长的生产调用联合校准；CA5未取得步法，不能补齐正敏捷路径。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-66532328a585941f：持有组件与实际启动分账

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。
账本：silent-0021、silent-0009。已观察范围：本条所列静默A10局面。

证据：5PM6JAQG6FNQ A10 F39 末试T2，兼F33建立组件的反例；states274379/274380。

本次核实：对无毒THE_LOST施放冒泡前后5→4能，敌35HP不变且毒仍0；这证实该动作当时未兑现伤害，不能据此推定另一整场线路获胜。

反例及未知：同局F33建立雾/触媒/群蛇并胜时敌人与资源不同；末战SL不是独立局，组件持有不证明已建立。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：持有/计划/到手/实付/建立/后继分账；不凭该单点拟合统一启动阈值或构筑权重。

验证方法：冻结F33与F39事实但不直接当因果配对，待同起点可复现整战输入比较不同启动顺序，并用独立后置静默局校准。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺相同起始资源与完整抽序下不同启动顺序的受控整战比较和可复现收益函数。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-43a76a31ba7bdcfa：族母吸取、负敏捷与SL范围

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。
账本：silent-0030、silent-0027。已观察范围：本条所列静默A10局面。

证据：61E2QS63Y9WU A10 F17 T5—T7；states273502、273504—273508。

本次核实：T5→T6玩家力量2→0、敏捷0→−2，T6两防御各3挡；T6至T7敌HP67→34，已建毒持续推进，不能把所有敌净扣误作直伤。

反例及未知：本局首试获胜，不是另一同抽失败局的受控SL配对；负敏捷牌挡事实不提供SL阈值。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：冻结吸取、负敏捷、毒的分项事实，保持当前SL范围与换线偏好。

验证方法：固定本局吸取前后实帧与实际前缀，再需另一同条件完整SL线路；按局而非尝试划分后置验证。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺同起始HP、构筑和完整抽序的另一可核SL全战线路及生产配对。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-5264153a4a4b0e5c：胧光怪召唤、航行及退场

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。
账本：silent-0039、silent-0209。已观察范围：本条所列静默A10局面。

证据：61E2QS63Y9WU A10 F23 T3—T5；states273589、273593、273596。

本次核实：两次航行后本体力量3→6；T4起玩家25HP、幻象14/本体76，下一轮10HP、幻象2/本体41，敌净扣47且损15，幻象仍存活。

反例及未知：另一focus幻象的39伤/零损仅为未实打候选，不能把主体扣血当全体退出或宣称另线必胜。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：复验已有召唤，保留全部目标选项；等值列并列，不强制统一首杀顺序。

验证方法：冻结A10原招式、各实体HP/力量和召唤输入，核出现/复现/退场全链；旧A0/A9召唤夹具不冒称本次A10联合验收。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺A10召唤、航行、复现与退场全链生产校准，以及另一focus的完整后继。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

## silent-proposal-bddfa690a84e03d0：熟睡甲虫唤醒与成长

来源：experience-update → strategy-proposal；原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。
账本：silent-0128、silent-0079。已观察范围：本条所列静默A10局面。

证据：DUZUBAJ3A8GP A10 F30 T1—T6；states274906/274914/274919/274923、274929/274931/274932/274934。

本次核实：首试睡层3/2/1后T4为0；T5甲虫力2/攻20，尖啸后力−4/攻14，T6恢复并成长到4/攻22。已见临减不停止成长。

反例及未知：四次相关尝试均失败，前三次预测死亡截断与末次实际死亡应分开；多扣少量敌血不能单独证明更优。

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：按当前进阶分别核睡眠、眩晕、临时减力及成长，不加入固定杀序、血价或再试必胜规则。

验证方法：冻结原帧及完整动作/抽序，核睡层与尖啸恢复，再补伤害唤醒、眩晕接续的可核全链输入；未知换线结果继续null。
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。缺伤害唤醒、眩晕接续和A10成长的全链校准，以及同抽换序的完整后继；四次相关失败不足拟合新规则。
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。


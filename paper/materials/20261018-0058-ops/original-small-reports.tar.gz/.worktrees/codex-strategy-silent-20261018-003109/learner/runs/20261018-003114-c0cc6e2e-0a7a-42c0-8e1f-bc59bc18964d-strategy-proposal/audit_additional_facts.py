import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = {r['line']: r for r in json.loads((HERE / 'selected-state-facts.json').read_text())}
decisions = {r['line']: r['row'] for r in json.loads((HERE / 'selected-decision-facts.json').read_text())}
checks = []


def power(entity, key):
    return next((p['amount'] for p in entity['powers'] if p['power_id'] == key), 0)


def enemy(number, key):
    return next(e for e in states[number]['enemies'] if e['enemy_id'] == key)


def attack(number, key):
    return sum(i.get('total_damage') or 0 for i in enemy(number, key)['intents'])


def check(label, actual, expected, lines):
    checks.append({'label': label, 'actual': actual, 'expected': expected,
                   'source_lines': lines, 'pass': actual == expected})


clam = [273237, 273252, 273263]
check('蚌三次喷水前力量', [power(enemy(n, 'SEWER_CLAM'), 'STRENGTH_POWER') for n in clam], [0, 4, 8], clam)
check('蚌三次喷水原始威胁', [attack(n, 'SEWER_CLAM') for n in clam], [11, 15, 19], clam)
check('族母吸取前后力量', [states[n]['powers'].get('STRENGTH_POWER', 0) for n in [273502, 273504]],
      [2, 0], [273502, 273504])
check('族母吸取后敏捷', states[273504]['powers'].get('DEXTERITY_POWER', 0), -2, [273504])
check('负敏捷两防御各三挡', [v['current_value'] for c in states[273504]['hand'] if c['card_id'] == 'DEFEND_SILENT'
                               for v in c['dynamic_values'] if v['name'] == 'Block'], [3, 3], [273504])
check('族母T6到T7敌血端点', [enemy(n, 'LAGAVULIN_MATRIARCH')['current_hp'] for n in [273504, 273508]],
      [67, 34], [273504, 273508])
check('胧光怪两次航行后力量', [power(enemy(n, 'THE_OBSCURA'), 'STRENGTH_POWER') for n in [273593, 273596]],
      [3, 6], [273593, 273596])
check('T4后幻象未退出', [enemy(273596, 'PARAFRIGHT')['current_hp'], enemy(273596, 'PARAFRIGHT')['is_alive']],
      [2, True], [273596])
check('无毒冒泡消耗一能', [states[n]['energy'] for n in [274379, 274380]], [5, 4], [274379, 274380])
check('无毒冒泡敌血未变', [enemy(n, 'THE_LOST')['current_hp'] for n in [274379, 274380]],
      [35, 35], [274379, 274380])
check('无毒冒泡目标毒为零', [power(enemy(n, 'THE_LOST'), 'POISON_POWER') for n in [274379, 274380]],
      [0, 0], [274379, 274380])
check('甲虫睡层与醒来', [power(enemy(n, 'SLUMBERING_BEETLE'), 'SLUMBER_POWER')
                            for n in [274906, 274914, 274919, 274923]], [3, 2, 1, 0],
      [274906, 274914, 274919, 274923])
check('甲虫醒后仍成长', [power(enemy(n, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER')
                            for n in [274929, 274932, 274934]], [2, -4, 4], [274929, 274932, 274934])
sl = decisions[270282]['sl_explore']['numbers']
check('SL原线与替换死亡数并非相同', ['dead 0/24' in sl['original'], 'dead 5/24' in sl['replacement']],
      [True, True], [270282])
check('SL当轮候选12血换7伤', ['hp -3, dmg 10' in sl['original'], 'hp -15, dmg 17' in sl['replacement']],
      [True, True], [270282])
(HERE / 'additional-fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'failures': sum(not x['pass'] for x in checks),
                  'scope': '局部原帧与同题预测核验，不认证整战因果或实际候选完整执行'}, ensure_ascii=False))
assert all(x['pass'] for x in checks)

import datetime
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261018-003109-strategy-proposal'
dispatch = json.loads((HERE / 'dispatch.json').read_text())
queue = json.loads((HERE / 'queue-effective.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
audit = json.loads((HERE / 'audit-summary.json').read_text())
checks = json.loads((HERE / 'additional-fact-checks.json').read_text())
assert all(c['pass'] for c in checks)
timestamp = datetime.datetime.now().astimezone().isoformat(timespec='seconds')


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


specs = [
    ('silent-proposal-89354805ee4d7e77', '神化升级传播与实际施放归属',
     'VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1；states275564/275565、275679/275680/275687、275722/275732；decisions269706/269707。',
     '神化实付2能：7→5；防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费。F43同序题面43伤/14损→51伤/13损，下一轮77HP、敌203HP与90HP/254HP起点相符；场外升级数始终4。',
     'F45已持有神化却未兑现升级，实际勒紧4/触媒1；F43施放仍有整战损血，不能把不同敌人与资源下的胜负当因果。',
     '缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整消费者核验；现有升级配对只覆盖限定子项。',
     '保留已证普通/升级配对，按本战真实施放传播已覆盖效果，未知组合保留unknown，持有/候选/施放分账。',
     '冻结F35/F43/F45状态与动作身份，逐项核升级、费用、后抽、已升级不重复及场外deck不变，再核跨中断归属；新增源码必须撤修失败/恢复通过。'),
    ('silent-proposal-f2bfceddb1898dca', '随机药水MC与推演预算成熟度',
     'VLZ6CCT8AQ0A A10 F45 T1/T4；decisions269748、269754、269770；F43/F44资源链仅作本局前置条件。',
     '269748药水仅1/12样本，原题明写707ms被MC占用、rollout预算退化；269754药水12/12但中位线后继仅3样本，牌堆状态已变。痊愈药水原文是+1能、抽2牌。',
     '两问不是同盘预算实验；后一问样本完成也不代表整战模拟成熟或另一focus必胜。',
     '缺同起点、同随机池、同总预算的MC策略配对及候选稳定性/成熟度曲线；两次不同盘面不能确定新预算、留药或目标规则。',
     '保留预算、护栏及留药规则，继续分列随机药水样本、真实抽牌后重问、后继推演样本与未知；相同值列并列。',
     '先冻结原始dirty输入、随机池及模型覆盖，再同总预算比较原策略与分阶段策略，按局号分组、后置独立局验证；不可用707ms单点拟合常量。'),
    ('silent-proposal-283a164780d11e69', '神化经验链补链提案',
     'VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1；与89354805ee4d7e77共用上述原帧。',
     '原经验silent-apotheosis-combat-upgrades与原postmortem提案同源，SHA及silent-0237/0238链接核同；本批只有该局普通神化帧，不借经验中另一局升级版本当本批实测。',
     '同题同源不增加独立样本；存在窄升级源码不能证明整个宽提案已经实现。',
     '同源神化经验链仍缺实际施放持续归属和完整消费核验，不能仅凭题意重复或局部源码登记duplicate。',
     '复用原神化实现链与真实证据，不新增重复id、不重复实现；完成后才引用实际live祖先源码提交。',
     '与89354805ee4d7e77联合核固定帧及跨中断消费者；二者各保留独立来源链接，不将一个原提案号冒充另一个已实现号。'),
    ('silent-proposal-ebbfe3b97548756d', '十五项机制与资源的联合验证',
     'VLZ6CCT8AQ0A A10 F35 T1、F43 T1—T5、F44、F45 T1—T5；原提案列15经验及14账本id。',
     '已读15经验对应原提案与本批账本，神化前后费用/属性、F43后抽升级及F45普通能力层数可以逐帧核；不把持有能力预支成实际持续收益。',
     'F43施放升级与F45未施放，场地、牌序和资源不同；单轮临减、现场覆甲、休息增上限各有期限及来源。',
     '缺十五机制逐来源、持续期限、升级属性组合与战斗—路线—休息消费者的固定联合校准；局部原帧和已有子实现不足关闭整项。',
     '按当前属性、逐击力量、逐牌敏捷、毒触发、临减恢复、覆甲和真实回复分源；准确子实现保持，未知不补固定加分。',
     '逐子机制冻结原卡、属性、进阶敌人数据库和消费者输入，联合回放状态期限及资源链；房间统计继续保留5样本门槛。'),
    ('silent-proposal-e5b87be50f28f311', 'HP护栏、SL换线与实际执行审计',
     '8JRE1C4H4Z2W A10 F33 首/第三试T2、第二试T5，兼原提案F17 T6及末试T11；decisions270216/270282/270264。',
     '270216与270282指纹完全一致；270282原线预测3损/10伤、替换15损/17伤，原/替换五轮推演死亡0/24、5/24不同，future loss同为47。270264原答预测16损/43伤，journal已是护栏后的另一线。',
     '候选多12血/7伤的预测差不自动等于所有后续实付；单动作completed回执不能认证整线，末试延长仍失败也不能推出一律少防御。',
     '已有候选阶段与单动作派发审计，仍缺跨抽牌、选牌、重问和SL的持续执行归属及实际整线收益认证。',
     '保持原选择规则，将Jev原答、护栏后、SL后、实际派发和重规划分账，能力建立须由状态确认。',
     '冻结同盘T2、第二试T5、F17抽牌重问与末试T11，校验实际前缀及中断；不得把候选差、整轮净扣和未选反事实混算。'),
    ('silent-proposal-49632bc4878fb597', '力量、敏捷、虚弱与蚌独立成长',
     'CA5KE8GFJ9X2 A10 F13 T1/T3/T5；states273237、273252、273263—273268。',
     '三次喷水前力量0/4/8、威胁11/15/19；末轮弱后14，2HP/10挡完整需损4。原本计划步法没有取得，不能补正敏捷。',
     '弱并未停止下一次成长；本局没有正敏捷样本，不能由一个既有步法源码证明复合路径。',
     '缺力量逐击、正负敏捷、虚弱与独立成长的生产调用联合校准；CA5未取得步法，不能补齐正敏捷路径。',
     '继续分项核当前属性、逐击修正及成长；不增加统一保血/输出权重。',
     '用本局固定喷水帧核弱及成长，正负敏捷另需本角色可核输入；同一联合调用的状态/牌挡/敌招式逐步比对后才判断完整覆盖。'),
    ('silent-proposal-66532328a585941f', '持有组件与实际启动分账',
     '5PM6JAQG6FNQ A10 F39 末试T2，兼F33建立组件的反例；states274379/274380。',
     '对无毒THE_LOST施放冒泡前后5→4能，敌35HP不变且毒仍0；这证实该动作当时未兑现伤害，不能据此推定另一整场线路获胜。',
     '同局F33建立雾/触媒/群蛇并胜时敌人与资源不同；末战SL不是独立局，组件持有不证明已建立。',
     '缺相同起始资源与完整抽序下不同启动顺序的受控整战比较和可复现收益函数。',
     '持有/计划/到手/实付/建立/后继分账；不凭该单点拟合统一启动阈值或构筑权重。',
     '冻结F33与F39事实但不直接当因果配对，待同起点可复现整战输入比较不同启动顺序，并用独立后置静默局校准。'),
    ('silent-proposal-43a76a31ba7bdcfa', '族母吸取、负敏捷与SL范围',
     '61E2QS63Y9WU A10 F17 T5—T7；states273502、273504—273508。',
     'T5→T6玩家力量2→0、敏捷0→−2，T6两防御各3挡；T6至T7敌HP67→34，已建毒持续推进，不能把所有敌净扣误作直伤。',
     '本局首试获胜，不是另一同抽失败局的受控SL配对；负敏捷牌挡事实不提供SL阈值。',
     '缺同起始HP、构筑和完整抽序的另一可核SL全战线路及生产配对。',
     '冻结吸取、负敏捷、毒的分项事实，保持当前SL范围与换线偏好。',
     '固定本局吸取前后实帧与实际前缀，再需另一同条件完整SL线路；按局而非尝试划分后置验证。'),
    ('silent-proposal-5264153a4a4b0e5c', '胧光怪召唤、航行及退场',
     '61E2QS63Y9WU A10 F23 T3—T5；states273589、273593、273596。',
     '两次航行后本体力量3→6；T4起玩家25HP、幻象14/本体76，下一轮10HP、幻象2/本体41，敌净扣47且损15，幻象仍存活。',
     '另一focus幻象的39伤/零损仅为未实打候选，不能把主体扣血当全体退出或宣称另线必胜。',
     '缺A10召唤、航行、复现与退场全链生产校准，以及另一focus的完整后继。',
     '复验已有召唤，保留全部目标选项；等值列并列，不强制统一首杀顺序。',
     '冻结A10原招式、各实体HP/力量和召唤输入，核出现/复现/退场全链；旧A0/A9召唤夹具不冒称本次A10联合验收。'),
    ('silent-proposal-bddfa690a84e03d0', '熟睡甲虫唤醒与成长',
     'DUZUBAJ3A8GP A10 F30 T1—T6；states274906/274914/274919/274923、274929/274931/274932/274934。',
     '首试睡层3/2/1后T4为0；T5甲虫力2/攻20，尖啸后力−4/攻14，T6恢复并成长到4/攻22。已见临减不停止成长。',
     '四次相关尝试均失败，前三次预测死亡截断与末次实际死亡应分开；多扣少量敌血不能单独证明更优。',
     '缺伤害唤醒、眩晕接续和A10成长的全链校准，以及同抽换序的完整后继；四次相关失败不足拟合新规则。',
     '按当前进阶分别核睡眠、眩晕、临时减力及成长，不加入固定杀序、血价或再试必胜规则。',
     '冻结原帧及完整动作/抽序，核睡层与尖啸恢复，再补伤害唤醒、眩晕接续的可核全链输入；未知换线结果继续null。'),
]
assert [s[0] for s in specs] == dispatch['proposal_ids']
items = []
proposal_sources = []
for identifier, title, evidence, finding, counterexample, reason, expected, validation in specs:
    old = queue[identifier]
    assert old['character'] == 'silent' and set(old['runs']) <= set(dispatch['runs'])
    path = Path(old['proposal'])
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == old['proposal_sha256']
    proposal_sources.append({'id': identifier, 'path': str(path), 'sha256': digest, 'matches_queue': True})
    items.append({'id': identifier, 'title': title, 'state': 'waiting', 'ledger': old['ledger'],
                  'evidence': evidence, 'finding': finding, 'counterexample': counterexample,
                  'reason': reason, 'expected_behavior': expected, 'validation': validation})
save('proposal-source-readback.json', proposal_sources)
save('dispositions.json', items)

intro = f'''# 静默猎手本批策略提案处置

记录时间：{timestamp}。batch={BATCH}，task=strategy-proposal，character=silent。
基线：{source['base']}。本批无research_request/implementation_request/proposal_repair，仅处理派来的十个原id。

本批十项均waiting。逐项读回原Markdown及SHA、原账本、相关静默经验和本角色六局证据；未发现可据本批证据新增的确定源码失配。已有窄实现不能关闭跨中断归属、复合校准或受控整战的宽请求。没有新源码、知识改动、提交、live合入、版本或shipped。

样本边界：六局均runs.jsonl核为SILENT/A10；SL尝试不扩分母。这六局及关键帧已经用于历史发现，不是后置独立验证。不用预训练游戏事实补结论，不读取其他角色私有知识。下面的旧行为是本批读到的现状，未改变规则。

'''
body = []
for item in items:
    old = queue[item['id']]
    body.append(f'''## {item['id']}：{item['title']}

来源：{old['source_task']} → strategy-proposal；原Markdown：{old['proposal']}；SHA={old['proposal_sha256']}。
账本：{'、'.join(item['ledger'])}。已观察范围：本条所列静默A10局面。

证据：{item['evidence']}

本次核实：{item['finding']}

反例及未知：{item['counterexample']}

旧规则/现状：现有子模型及原预算、护栏、SL和终局规则保留；候选预测与实际执行分账，现有审计中的actual_cast_this_fight、actual_turn或actual_full_candidate_result未认证时继续为null。
预期行为：{item['expected_behavior']}

验证方法：{item['validation']}
拟合及切分：本次不拟合收益常量、血价、启动权重或门槛；各局独立计数，同局多帧/SL不增加独立分母。未来验证应后移到独立静默完局并分进阶、资源与模型覆盖；未具备冻结完整输入不造受控实验成功。

处置：waiting。{item['reason']}
预期影响：若将来补齐，只声明对应模型/审计改进；本次没有行为影响，无关角色保持等价。回退：本次无生产源码可回退；后续实现须用其实际源码提交回退，保留本证据及失败历史。

''')
(HERE / 'proposal.md').write_text(intro + ''.join(body))

manifest = json.loads((HERE / 'evidence-readback.json').read_text())
table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {m['verified_lines']} |" for m in manifest)
result_table = '\n'.join(f"| {item['id']} | waiting | {item['reason']} |" for item in items)
narrow = '\n'.join(f"- {r['commit']}：{r['subject']}；实际live祖先={r['is_live_ancestor']}。" for r in source['narrow_commits'])
report = f'''# 静默猎手策略学习报告

记录时间：{timestamp}。task=strategy-proposal，character=silent，batch={BATCH}。

## 结果

十项均waiting；缺口逐项如下，没有新增确定源码失配或足够证据支持新策略参数。fixes=[]，merged=null；未提交源码、未改知识或规则、未加eval版本，不宣称implemented/duplicate/shipped。提案路径：{HERE / 'proposal.md'}。

## 身份与基线

开工git status干净，HEAD={source['base']}；已读README、STATE-2026-10-18、decision-log末尾、learning-protocol、learning-code-proposals及本树AGENTS。只读根learn.json本批对应行：strategy-proposal/silent、reason=proposal、running、工作树匹配、十proposal_ids，无research_request/implementation_request/proposal_repair。普通专题根请求绑定另一个旧batch，不承接、不读取其他专题替代身份。依普通流程git merge --no-edit main返回Already up to date；完整base保持{source['base']}。未派下级agent。

六个派发局：{','.join(dispatch['runs'])}。每局均runs.jsonl核实SILENT/A10，原行及SHA见runs-verified.json。独立局数6，不把SL、同局多帧或历史经验支持数当新增独立样本。本批没有宣称验证或切换实际运行模型设置。

## 证据及材料核验

按共用learner/extract_evidence.py抽取八流，单独runs先核角色，其余流按各自source_size冻结。逐行原offset/bytes/SHA256和JSON对象读回，身份只取run_id/state.run_id/run/fingerprint.run，冲突身份拒收，不以正文提及认领。本次共6995条，逐流及逐局计数/output_sha256见evidence/evidence-manifest.json、evidence-runs/evidence-manifest.json及evidence-readback.json。

| 流 | source_size字节 | 读回核验行数 |
|---|---:|---:|
{table}

states、decisions、brain在全源扫描各有2条无效JSON行；不据全源计数断言属于本六局。fight-plans在本截点六局均0行，仅说明截点未选到，不断言源日志不存在。本次未复核旧截点、不覆盖旧报告或零行初稿。

十份原Markdown全部SHA匹配专用队列；来源、原账本和经验链接保存在proposal-source-readback.json、queue-effective.json、ledger-before.json、experience-selected.json。本批未登记重复id，code_proposals沿用原十个CLI id。

审计投影含825个相关状态及797个相关决策，见selected-state-facts.json、selected-decision-facts.json；29条SL日志另存sl-records.json。原帧检查13项、补充15项均通过（fact-checks.json、additional-fact-checks.json及对应log），这28项是数据核验，不是生产测试、红绿验证、整线认证或策略效果实验。

关键读回：VLZ F35神化付2能及已见卡升级、F43同序51伤/13损端点和场外deck不变；F45普通能力实际4/1。8JRE同盘T2原/替换候选3损10伤与15损17伤，五轮推演死亡0/24与5/24不同。CA5蚌力量0/4/8、喷水11/15/19，末轮弱后14对10挡2HP仍缺2血。5PM无毒冒泡实际5→4能、敌35HP/毒0不变。61E吸取后负2敏使两防御各3挡；F23 T4后幻象仍2HP。DUZU睡层3/2/1后醒，尖啸力2→−4、下轮4，攻击20→14→22。它们支持局部事实，不补未选整场反事实。

## 源码现状与实际live祖先

只读live快照={source['live_snapshot']}。核13个精确路径，11个base/live blob相同，card-model.ts、rollout-live.ts两路径不同；各SHA/blob/最近源码提交和祖先布尔见source-readback.json。差异不当作本批可复现失配或发布，不用main提交替代实际live祖先证明。

silent-apotheosis-reference.ts明确actual_cast_this_fight=null；turn-solver仅在已验证组合传播升级，未知后抽保留unknown。silent-selection-audit.ts是候选阶段快照；silent-selection-dispatch.ts只记录单动作回执且whole_plan_executed/actual_turn仍null；learner/lib/selection-execution.ts也明确actual_full_candidate_result=null。现有字段和局部正确数值不能补齐持续执行归属。silent-simulation-reference.ts分列预算退化/样本，不提供同盘新预算收益；旧召唤夹具不代表本次A10全链联合校准。本批只读这些消费者源码，未声称重新执行整场消费者验收。

已核live祖先的窄项来源（均为已有提交，不是本批提交，也不关闭宽提案）：

{narrow}

## 逐项处置

| 原id | 处置 | 具体缺口 |
|---|---|---|
{result_table}

每项来源任务、证据局/层/回合、原账本、反例、旧/预期行为、样本/时间切分、验证及回退详见proposal.md。十项全部处理，没有领取其他批次或新建重复id。implementation_domains=[]，因为本批没有实际实现。

## 登记、验证口径与限制

只经根learner/ledger.py update追加本批追溯链接，by=learner:strategy-proposal；不新增支持/重犯计数、不改claim、首证、进阶、status、version或shipped历史。输入、CLI输出和追加后保护字段核验留本目录；waiting由最终proposal_results交原调度器消费，不手改learn.json或队列。

无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；未运行生产测试，不借用历史成功。未进入live合入流程、未刷新live知识、未造合入/发布号/decision-log上线记录或规则双通知。工作树最终要求git status干净、HEAD等于完整base。

原运行提交带dirty，未恢复当时全部执行源码/知识/随机池；不能由当前代码复现字节不全的历史整战。样本已用于发现，非独立盲测。没有胜线反事实不妨碍确认局部机制，但不足拟合宽策略；已观察正确子实现按边界保留，不把不确定记成零收益或必败。

失败与初稿保留：一次读取旧报告过程材料路径不存在；一次检查首条状态误以为combat非空而报AttributeError；几次源码定位使用猜测路径，rg报告不存在，均已按真实路径纠正，非游戏反证或生产测试失败。原日志和旧报告未改，相关检查异常说明见inspection-notes.md。两次本批数据核验脚本均退出0，没有撤生产源码负控或生产测试记录可冒报。

报告及追溯输入在登记后做gitleaks脱敏扫描，结果与最后工作树/账本读回另存final-verification.json。本报告和批次完成不代表经验已新入库、大脑已采用、学习父要求关闭或Roy已确认。
'''
(HERE / 'report.md').write_text(report)
(HERE / 'inspection-notes.md').write_text('''# 本批读取异常与限制

- 只读旧报告本身可访问，随后查旧selected-state-facts.json过程路径时FileNotFoundError；未据此断言原证据丢失，改用本批共用抽取重新核证，未展开旧副本。
- 首条抽到的状态在F1且combat=null，初次交互检查调用get时报AttributeError；正式audit_evidence.py用空对象分支处理，6995行核验退出0。
- combat-decision-audit.ts、core/loop.ts、monster-script.ts是初次猜测路径，rg报不存在；改由真实silent-selection-audit.ts、silent-selection-dispatch.ts、silent-hp-guard-audit.ts与生产接线检索核现状。
- 上述均为读取/定位错误，没有改生产源码，也不是红绿测试或游戏机制反证。完整工具输出由原启动器转录保留；本目录保留正式脚本、原数据封套和核验log。
''')

ledger_items = json.loads((HERE / 'ledger-before.json').read_text())
updates = []
for identifier in sorted({i for item in items for i in item['ledger']}):
    assert ledger_items[identifier]['character'] == 'silent'
    linked = [i['id'] for i in items if identifier in i['ledger']]
    updates.append({'id': identifier, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': f'{BATCH}：复核原提案' + '、'.join(linked) +
                    '，仍waiting；六局6995原行逐offset/bytes/SHA及身份读回，28项局部数据检查通过，非生产测试/整线认证。逐项缺口见本批报告；仅补追溯，不增support/repeat或改原claim/status/version，不冒称实现、合入或shipped。'})
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': source['base'],
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{'id': i['id'], 'state': 'waiting', 'reason': i['reason']} for i in items],
          'report': str(HERE / 'report.md')}
save('result.json', result)
print(json.dumps({'proposals': len(items), 'ledger_links': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

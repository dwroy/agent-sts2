# 静默猎手策略学习报告

记录时间：2026-10-18T00:43:56+08:00。task=strategy-proposal，character=silent，batch=20261018-003109-strategy-proposal。

## 结果

十项均waiting；缺口逐项如下，没有新增确定源码失配或足够证据支持新策略参数。fixes=[]，merged=null；未提交源码、未改知识或规则、未加eval版本，不宣称implemented/duplicate/shipped。提案路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-003109/learner/runs/20261018-003114-c0cc6e2e-0a7a-42c0-8e1f-bc59bc18964d-strategy-proposal/proposal.md。

## 身份与基线

开工git status干净，HEAD=9f3d5745be89496398555a5a1eeda2abb995a438；已读README、STATE-2026-10-18、decision-log末尾、learning-protocol、learning-code-proposals及本树AGENTS。只读根learn.json本批对应行：strategy-proposal/silent、reason=proposal、running、工作树匹配、十proposal_ids，无research_request/implementation_request/proposal_repair。普通专题根请求绑定另一个旧batch，不承接、不读取其他专题替代身份。依普通流程git merge --no-edit main返回Already up to date；完整base保持9f3d5745be89496398555a5a1eeda2abb995a438。未派下级agent。

六个派发局：VLZ6CCT8AQ0A,8JRE1C4H4Z2W,CA5KE8GFJ9X2,5PM6JAQG6FNQ,61E2QS63Y9WU,DUZUBAJ3A8GP。每局均runs.jsonl核实SILENT/A10，原行及SHA见runs-verified.json。独立局数6，不把SL、同局多帧或历史经验支持数当新增独立样本。本批没有宣称验证或切换实际运行模型设置。

## 证据及材料核验

按共用learner/extract_evidence.py抽取八流，单独runs先核角色，其余流按各自source_size冻结。逐行原offset/bytes/SHA256和JSON对象读回，身份只取run_id/state.run_id/run/fingerprint.run，冲突身份拒收，不以正文提及认领。本次共6995条，逐流及逐局计数/output_sha256见evidence/evidence-manifest.json、evidence-runs/evidence-manifest.json及evidence-readback.json。

| 流 | source_size字节 | 读回核验行数 |
|---|---:|---:|
| states | 14103784991 | 3432 |
| decisions | 2379171813 | 3306 |
| sl-attempts | 46413181 | 29 |
| run-config | 2010209 | 6 |
| run-plans | 9094821 | 33 |
| brain | 779652784 | 183 |
| fight-plans | 2233957 | 0 |
| runs | 364976 | 6 |

states、decisions、brain在全源扫描各有2条无效JSON行；不据全源计数断言属于本六局。fight-plans在本截点六局均0行，仅说明截点未选到，不断言源日志不存在。本次未复核旧截点、不覆盖旧报告或零行初稿。

十份原Markdown全部SHA匹配专用队列；来源、原账本和经验链接保存在proposal-source-readback.json、queue-effective.json、ledger-before.json、experience-selected.json。本批未登记重复id，code_proposals沿用原十个CLI id。

审计投影含825个相关状态及797个相关决策，见selected-state-facts.json、selected-decision-facts.json；29条SL日志另存sl-records.json。原帧检查13项、补充15项均通过（fact-checks.json、additional-fact-checks.json及对应log），这28项是数据核验，不是生产测试、红绿验证、整线认证或策略效果实验。

关键读回：VLZ F35神化付2能及已见卡升级、F43同序51伤/13损端点和场外deck不变；F45普通能力实际4/1。8JRE同盘T2原/替换候选3损10伤与15损17伤，五轮推演死亡0/24与5/24不同。CA5蚌力量0/4/8、喷水11/15/19，末轮弱后14对10挡2HP仍缺2血。5PM无毒冒泡实际5→4能、敌35HP/毒0不变。61E吸取后负2敏使两防御各3挡；F23 T4后幻象仍2HP。DUZU睡层3/2/1后醒，尖啸力2→−4、下轮4，攻击20→14→22。它们支持局部事实，不补未选整场反事实。

## 源码现状与实际live祖先

只读live快照=bc59c5a027a7fc28b8aa717a96c8081b2afd3c42。核13个精确路径，11个base/live blob相同，card-model.ts、rollout-live.ts两路径不同；各SHA/blob/最近源码提交和祖先布尔见source-readback.json。差异不当作本批可复现失配或发布，不用main提交替代实际live祖先证明。

silent-apotheosis-reference.ts明确actual_cast_this_fight=null；turn-solver仅在已验证组合传播升级，未知后抽保留unknown。silent-selection-audit.ts是候选阶段快照；silent-selection-dispatch.ts只记录单动作回执且whole_plan_executed/actual_turn仍null；learner/lib/selection-execution.ts也明确actual_full_candidate_result=null。现有字段和局部正确数值不能补齐持续执行归属。silent-simulation-reference.ts分列预算退化/样本，不提供同盘新预算收益；旧召唤夹具不代表本次A10全链联合校准。本批只读这些消费者源码，未声称重新执行整场消费者验收。

已核live祖先的窄项来源（均为已有提交，不是本批提交，也不关闭宽提案）：

- 772b839f8ada31664cb764ea9ad3bdb03da27f64：Model observed Silent Apotheosis upgrades；实际live祖先=True。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：Propagate observed Silent Deadly Poison upgrade；实际live祖先=True。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：Propagate observed Silent Apotheosis Malaise upgrade；实际live祖先=True。
- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：ops: replay checked Silent Apotheosis candidate facts；实际live祖先=True。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：Replay tested held-loss candidate facts on current live；实际live祖先=True。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：Integrate repaired legacy learning deltas and bounded continuation adapter；实际live祖先=True。
- fdaf787a372880b0438e73bcac7e6d2168b038ed：Record Silent candidate dispatch receipts separately from forecasts；实际live祖先=True。
- cf72bd21148059f111f760cc98a727369e34a47e：Integrate checked offline Silent potion observation tool；实际live祖先=True。

## 逐项处置

| 原id | 处置 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整消费者核验；现有升级配对只覆盖限定子项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺同起点、同随机池、同总预算的MC策略配对及候选稳定性/成熟度曲线；两次不同盘面不能确定新预算、留药或目标规则。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化经验链仍缺实际施放持续归属和完整消费核验，不能仅凭题意重复或局部源码登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五机制逐来源、持续期限、升级属性组合与战斗—路线—休息消费者的固定联合校准；局部原帧和已有子实现不足关闭整项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有候选阶段与单动作派发审计，仍缺跨抽牌、选牌、重问和SL的持续执行归属及实际整线收益认证。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺力量逐击、正负敏捷、虚弱与独立成长的生产调用联合校准；CA5未取得步法，不能补齐正敏捷路径。 |
| silent-proposal-66532328a585941f | waiting | 缺相同起始资源与完整抽序下不同启动顺序的受控整战比较和可复现收益函数。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP、构筑和完整抽序的另一可核SL全战线路及生产配对。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行、复现与退场全链生产校准，以及另一focus的完整后继。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续和A10成长的全链校准，以及同抽换序的完整后继；四次相关失败不足拟合新规则。 |

每项来源任务、证据局/层/回合、原账本、反例、旧/预期行为、样本/时间切分、验证及回退详见proposal.md。十项全部处理，没有领取其他批次或新建重复id。implementation_domains=[]，因为本批没有实际实现。

## 登记、验证口径与限制

只经根learner/ledger.py update追加本批追溯链接，by=learner:strategy-proposal；不新增支持/重犯计数、不改claim、首证、进阶、status、version或shipped历史。输入、CLI输出和追加后保护字段核验留本目录；waiting由最终proposal_results交原调度器消费，不手改learn.json或队列。

无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；未运行生产测试，不借用历史成功。未进入live合入流程、未刷新live知识、未造合入/发布号/decision-log上线记录或规则双通知。工作树最终要求git status干净、HEAD等于完整base。

原运行提交带dirty，未恢复当时全部执行源码/知识/随机池；不能由当前代码复现字节不全的历史整战。样本已用于发现，非独立盲测。没有胜线反事实不妨碍确认局部机制，但不足拟合宽策略；已观察正确子实现按边界保留，不把不确定记成零收益或必败。

失败与初稿保留：一次读取旧报告过程材料路径不存在；一次检查首条状态误以为combat非空而报AttributeError；几次源码定位使用猜测路径，rg报告不存在，均已按真实路径纠正，非游戏反证或生产测试失败。原日志和旧报告未改，相关检查异常说明见inspection-notes.md。两次本批数据核验脚本均退出0，没有撤生产源码负控或生产测试记录可冒报。

报告及追溯输入在登记后做gitleaks脱敏扫描，结果与最后工作树/账本读回另存final-verification.json。本报告和批次完成不代表经验已新入库、大脑已采用、学习父要求关闭或Roy已确认。

import json,pathlib,collections
P=pathlib.Path(__file__).parent

def rows(n):
 with (P/(n+'-lines.jsonl')).open() as h:
  for l in h:
   num,s=l.split(':',1);r=json.loads(s);r['_line']=int(num);yield r
D=list(rows('decisions'));S=list(rows('states'))
print('STATE_COUNT',len(S),'FIRST_KEYS',list(S[0]),'STATE_KEYS',list(S[0]['state']))
R=json.loads((P/'W9610N90MMCT-resources.json').read_text())
for c in R['combats']:
 print('COMBAT',c['sequence'],c['floor'],c['enemies'],'entry',c['entry'],'last',c['last'],'exit',c['exit'],'end',c['end'])
 print('TURN_AUDIT',[(x['turn'],x['live_enemy_hp_start'],x.get('net_live_enemy_hp_loss'),x['gaps']) for x in c.get('enemy_hp_audit',{}).get('turns',[])])
for e in R['resource_changes']:
 a,b=e['from'],e['to']
 if a['potions']!=b['potions'] or e['combat_sequence'] is None:print('CHANGE',e)
print('JEV',sum(d['decider']=='jev' for d in D),'low',[(d['_line'],d['floor'],d['turn'],d['confidence']) for d in D if d['decider']=='jev' and d.get('confidence',1)<.35])
J=[d for d in D if d['decider']=='jev' and d['label'].startswith('combat/')]
print('JEV_COMBAT',len(J),'keys',collections.Counter(k for d in J for k in d),'journal_keys',collections.Counter(k for d in J for k in d.get('journal',{})))
for d in D:
 if any(t in d.get('rationale','').lower() for t in ['guard','mismatch','focus','hp护','保血']): print('SPECIAL',d['_line'],d['floor'],d['turn'],d['rationale'],d.get('journal'),{k:v for k,v in d.items() if 'guard' in k or 'rollout' in k})
print('EXAMPLE_JEV', {k:v for k,v in J[0].items() if k not in ['questions','fingerprint','time_budget']})
print('EXAMPLE_STATE',S[-2])

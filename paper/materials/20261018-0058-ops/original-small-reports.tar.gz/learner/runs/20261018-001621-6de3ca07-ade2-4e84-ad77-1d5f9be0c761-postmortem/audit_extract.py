import json,pathlib,collections
P=pathlib.Path(__file__).parent

def rows(n):
 with (P/(n+'-lines.jsonl')).open() as h:
  for l in h:
   num,s=l.split(':',1);r=json.loads(s);r['_line']=int(num);yield r
D=list(rows('decisions'))
for r in D:
 if r['decider'] in ['codex','code-fallback'] or r.get('chosen',{}).get('action') in ['use_potion','discard_potion']:
  q=r.get('questions') or {}; facts=q.get('facts',{})
  print('D',r['_line'],r['ts'],'F',r['floor'],'T',r['turn'],r['label'],r['decider'],'chosen',r.get('chosen',{}),'rationale',r.get('rationale','')[:1700])
  if r.get('journal'):print('journal',r['journal'])
  print('facts keys',list(facts))
for r in rows('plans'):print('PLAN',r['_line'],r['ts'],r.get('floor'),r.get('plan'),r.get('question'))
for r in rows('sl'):print('SL',r['_line'],r['attempt'],r['started_at'],r['ended_at'],r['result'],r.get('incoming'),r.get('judge'),r.get('explore',{}).get('target'),r['summary'])
print('DECISION keys',list(D[30]));print('question keys',list(D[30].get('questions',{})))

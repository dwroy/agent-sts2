import json,pathlib,collections,datetime
P=pathlib.Path(__file__).parent
def rows(n):
 for l in (P/(n+'-lines.jsonl')).open():
  num,s=l.split(':',1);r=json.loads(s);r['_line']=int(num);yield r
D=list(rows('decisions'));S=list(rows('states'));B=list(rows('brain'));R=json.loads((P/'W9610N90MMCT-resources.json').read_text())
for c in R['combats']:
 F=[r for r in S if c['entry']['line']<=r['_line']<=(c['exit']or c['last'])['line']]
 T=collections.OrderedDict()
 for r in F:
  if r['state'].get('in_combat'):T.setdefault(r['state']['turn'],[]).append(r)
 vals=[]
 for i,(t,v) in enumerate(T.items()):
  after=list(T.values())[i+1][0] if i+1<len(T) else F[-1]
  a=v[0]['state'];b=after['state'];need=sum(e['current_hp'] for e in a['combat']['enemies'] if e['is_alive']);remaining=sum(e['current_hp'] for e in (b.get('combat')or{}).get('enemies',[]) if e['is_alive'])
  vals.append({'t':t,'need':need,'net_enemy_hp_drop':need-remaining,'hp_loss':a['run']['current_hp']-b['run']['current_hp'],'start':v[0]['_line'],'end':after['_line'],'incomplete':i+1==len(T) and c['exit']is None})
 print('TURNS',c['sequence'],c['floor'],vals)
for r in D:
 if (r['floor'],r['turn']) in [(5,3),(15,1),(15,4),(17,2),(17,3),(17,4),(17,7)] and (r.get('sl_attempt')or 1) in [1,5,6] and r.get('selection_audit'):
  a=r['selection_audit'];print('PICK',r['_line'],r['floor'],r['turn'],r.get('sl_attempt'),r['rationale'],{k:{'line':v.get('line'),'turn':v.get('turn'),'rollout':v.get('rollout')} for k,v in a.items() if k in ['answer','before_sl','after_sl'] and isinstance(v,dict)})
  if r['floor']==17 and r['turn']in[2,4]:
   for key,x in r.get('questions',{}).get('plan',{}).get('criteria',{}).items():
    try:x=json.loads(x)
    except:continue
    print('OPTION',key,{k:x.get(k) for k in ['plays','hp_lost','damage_dealt','hp_after','boss_sim','fight_to_end','chance_to_win','survival']},'KEYS',list(x))
for r in B:
 if r['label'] in ['run-plan','rest/plan']:
  def search(o,path=''):
   if isinstance(o,dict):
    for k,v in o.items():
     q=path+'/'+k
     if k in ['act_boss_clock','act_boss_sim']: print('FACT',r['_line'],q,str(v)[:2400])
     elif k in ['boss_sim','quantitative_fight'] and path.count('/')<6:print('SIMFACT',r['_line'],q,str(v)[:1500])
     else:search(v,q)
   elif isinstance(o,list):
    for i,v in enumerate(o):search(v,path+'/'+str(i))
   elif isinstance(o,str) and ('act_boss_clock' in o or 'deck_damage_per_turn_estimate' in o):
    at=o.find('act_boss_clock');print('TEXT_CLOCK',r['_line'],path,o[max(0,at-20):at+1600])
  search(r.get('payload',{}))
for g in ['jev','codex']:
 ds=[r for r in D if r['decider']==g];print('USAGE',g,[(k,sum(r.get('usage',{}).get(k,0)or 0 for r in ds)) for k in ['input_tokens','output_tokens','cache_hit_tokens']])
print('BR_COUNT',len(B),'accepted',sum(bool(r.get('accepted'))for r in B),'errors',sum(bool(r.get('error'))for r in B))
print('TIME',(datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'))).total_seconds())

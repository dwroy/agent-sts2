import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261018-003109'
SCRATCH = ROOT / 'learner/runs/20261018-003115-8ad70407-50a9-47b0-8119-46886f8d36c0-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261017-224309-611c1265-c7e0-4f4f-aa27-cf84315f9bad-fix-batch'
LIVE = ROOT / '.worktrees/live'
BASE = '9f3d5745be89496398555a5a1eeda2abb995a438'


def git(*args, cwd=WORK, input=None):
    return subprocess.check_output(['git', '-C', str(cwd), *args], input=input)


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('status', '--porcelain')
previous_bytes = (PREVIOUS / 'source-audit.json').read_bytes()
previous = json.loads(previous_bytes)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert queue == (PREVIOUS / 'fix-queue-snapshot.md').read_bytes()
assert hashlib.sha256(queue).hexdigest() == previous['queue_sha256']
(SCRATCH / 'fix-queue-snapshot.md').write_bytes(queue)
main = git('rev-parse', 'main').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
source_paths = ['agent/src', 'agent/tools', 'agent/tests', 'agent/package*.json', 'agent/tsconfig*.json',
                'agent/vitest*', 'learner/*.ts', 'learner/*.py', 'learner/lib', 'learner/tasks', 'ops/*.sh',
                'ops/*.py', 'ops/codex', 'ops/tests', 'eval/*.py', 'eval/*.ts', 'eval/cost-config.json', 'knowledge/builders']
changed = git('diff', '--name-only', previous['base'], BASE, '--', *source_paths).decode().splitlines()
live_changed = git('diff', '--name-only', previous['live'], live, '--', *source_paths).decode().splitlines()
assert not set(changed) & set(previous['source_blobs'])
changed_audited_live = sorted(set(live_changed) & set(previous['source_blobs']))
assert set(changed_audited_live) <= {'ops/learning_requests.py'}
paths = sorted(set(previous['source_blobs']) | set(changed) | set(live_changed))
assert all(p.startswith(('agent/', 'ops/', 'learner/', 'eval/', 'knowledge/builders/')) for p in paths)
assert not any(Path(p).name.endswith('.env') for p in paths)


def blobs(ref, cwd):
    result = git('ls-tree', '-r', ref, '--', *paths, cwd=cwd).decode().splitlines()
    return {row.split('\t', 1)[1]: row.split('\t', 1)[0].split()[2] for row in result}


base_blobs = blobs(BASE, WORK)
live_blobs = blobs(live, LIVE)
source_blobs = {}
for cwd, committed, label in [(WORK, base_blobs, 'base'), (LIVE, live_blobs, 'live')]:
    selected = sorted(committed)
    hashes = git('hash-object', '--stdin-paths', cwd=cwd, input=('\n'.join(selected) + '\n').encode()).decode().splitlines()
    assert len(hashes) == len(selected)
    for path, current in zip(selected, hashes):
        assert current == committed[path], (label, path)
        source_blobs.setdefault(path, {})['blob' if label == 'base' else 'live_blob'] = current
        source_blobs[path]['working_matches_head' if label == 'base' else 'live_working_matches_head'] = True
for path, row in previous['source_blobs'].items():
    assert base_blobs[path] == row['blob'], path
    if path != 'ops/learning_requests.py':
        assert live_blobs[path] == row['live_blob'], path
allowed_recovery_blobs = {
    previous['source_blobs']['ops/learning_requests.py']['live_blob'],
    git('rev-parse', 'ff58938f8b86cd4975bde47f8ac5088758ce8b78:ops/learning_requests.py').decode().strip(),
}
assert live_blobs['ops/learning_requests.py'] in allowed_recovery_blobs
(SCRATCH / 'source-since-previous.diff').write_bytes(git('diff', '--binary', previous['base'], BASE, '--', *source_paths))
(SCRATCH / 'live-source-since-previous.diff').write_bytes(git('diff', '--binary', previous['live'], live, '--', *source_paths))

ancestry = {label: set(git('rev-list', ref).decode().splitlines()) for label, ref in [('base', BASE), ('main', main), ('live', live)]}
fixed = []
extra_fixed = [
    {'item': 'host-fixed-test-timeouts-010547：eval固定历史发布表夹具', 'commit': 'd9881ba593b0b8d701ebbe1c95626c0ebdd554c7'},
    {'item': 'host-fixed-test-timeouts-010547：F45固定工作时钟与采样夹具', 'commit': '9e8c93555131c3347f9e809d9722a848a75c2692'},
]
for old in previous['already_fixed'] + extra_fixed:
    row = {'item': old['item'], 'commit': old['commit']}
    for label, commits in ancestry.items():
        row[label + '_ancestor'] = row['commit'] in commits
        assert row[label + '_ancestor'], row
    fixed.append(row)

dispositions = json.loads((PREVIOUS / 'unchecked-items-disposition.json').read_text())
queue_lines = queue.decode().splitlines()
assert len(dispositions) == sum(line.startswith('- [ ]') for line in queue_lines) == 49
for row in dispositions:
    assert row['original'] == queue_lines[row['line'] - 1]
    if row.get('commit'):
        assert all(row['commit'] in commits for commits in ancestry.values())
save('unchecked-items-disposition.json', dispositions)
save('source-audit.json', {
    'base': BASE, 'main': main, 'live': live, 'previous_base': previous['base'], 'previous_live': previous['live'],
    'previous_audit': str(PREVIOUS / 'source-audit.json'),
    'previous_audit_sha256': hashlib.sha256(previous_bytes).hexdigest(),
    'queue_sha256': hashlib.sha256(queue).hexdigest(), 'queue_identical_to_previous': True,
    'previous_source_paths_checked': len(previous['source_blobs']),
    'source_paths_checked': len(source_blobs), 'source_blobs': source_blobs,
    'previous_base_source_blobs_unchanged': True, 'changed_source_paths': changed,
    'changed_live_source_paths': live_changed,
    'changed_previously_audited_live_paths': changed_audited_live,
    'live_change_scope': '核验期间其他会话回退bc59c5a02账号接续合入至a5b863142；按新live重新校验，未修改其源码或操作',
    'initial_successful_audit_live': 'bc59c5a027a7fc28b8aa717a96c8081b2afd3c42',
    'retry_guard_failure': str(SCRATCH / 'audit-retry-failure.txt'),
    'already_fixed': fixed, 'unchecked_items': len(dispositions), 'new_fixes': 0,
    'tests_run_by_this_batch': False,
})

prior_report = json.loads((PREVIOUS / 'report.json').read_text())
skipped = prior_report['skipped']
skipped[0]['item'] = '出牌、药水、SL、终局、路线及角色机制条目（0256/0260/0263/0266/0308/0311/0317/0319/0320/0322/0324/0329/0334/0339/0344/0347/0349/0362/0365/0481/0487，另含XTSV1U9JD34T终局与GXNKW8X1XYJP抽牌身份）'
report = {'task': 'fix-batch', 'base': BASE, 'fixes': [], 'skipped': skipped, 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
save('report.json', report)
lines = ['## 修 bug 回报', '', '- 合并基线：main → ' + BASE,
         '- 修复（每条一行）：无新增纯 bug 修复；49条未勾选项已逐项核对，队列与上一批逐字一致。']
for row in fixed:
    lines.append('- 已被别人修掉的：' + row['item'] + ' — ' + row['commit'])
for row in skipped:
    lines.append('- 没修的：' + row['item'] + ' — ' + row['reason'])
lines.extend([
    '- 测试：本批未改代码，tsc未跑（退出码null）；vitest 0文件 / 0用例 / 未跑（退出码null），未重跑。只读核验' + str(len(source_blobs)) + '个源码/测试文件、45个既有修复提交在基线/main/live中的祖先关系；前批测试结果不计作本批测试。',
    '- 合入：未合入（本批无新提交；45个既有修复已在live ' + live + '）。未写live、队列、账本、提案或发布记录；无需刷新/测试/发布无改动分支。',
    '- 需要 Roy 定的事：无',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines) + '\n\n```json\n' + json.dumps(report, ensure_ascii=False, indent=2) + '\n```\n')
assert not git('status', '--porcelain')
assert git('rev-parse', 'HEAD', cwd=LIVE).decode().strip() == live
assert (ROOT / 'notes/fix-queue-v4.md').read_bytes() == queue
print(json.dumps({'base': BASE, 'live': live, 'already_fixed': len(fixed), 'source_paths_checked': len(source_blobs),
                  'unchecked_items': len(dispositions), 'new_fixes': 0, 'tests_run': False, 'worktree_clean': True,
                  'report': report['report']}, ensure_ascii=False, indent=2))

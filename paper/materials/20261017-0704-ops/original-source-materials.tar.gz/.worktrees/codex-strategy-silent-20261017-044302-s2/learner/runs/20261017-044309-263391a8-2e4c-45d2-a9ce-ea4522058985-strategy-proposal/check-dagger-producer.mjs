import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { parseGameState } from '../../../agent/src/hand/mod/schema.ts';
import { createScreenMemory } from '../../../agent/src/memory/types.ts';
import { noteCardSource } from '../../../agent/src/hand/screens/selection.ts';
import { facingFightOf } from '../../../agent/src/reflex/combat-plan.ts';
import { sandpitDiscardFacts } from '../../../agent/src/hand/screens/silent-sandpit-discard.ts';
const here = dirname(fileURLToPath(import.meta.url));
const fixture = JSON.parse(readFileSync(join(here, '../../../agent/tests/silent-dagger-sandpit-evidence.json'), 'utf8'));
const decisions = JSON.parse(readFileSync(join(here, 'target-decisions.json'), 'utf8'));
const before = parseGameState(fixture.states['306208']);
const selecting = parseGameState(fixture.states['306209']);
const memory = createScreenMemory(before.screen);
noteCardSource(memory, before, decisions['298726'].row.chosen);
assert.equal(memory.cardSource.id, 'DAGGER_THROW');
assert.equal(memory.cardSource.turn, selecting.turn);
assert.equal(memory.cardSource.fight, facingFightOf(selecting));
const facts = sandpitDiscardFacts(selecting, false, false, true);
assert.equal(facts.context.energy_now, 2);
assert.equal(facts.context.sandpit_now, 2);
assert.equal(facts.options.get(3).removes_last_energy_payable_escape, true);
writeFileSync(join(here, 'dagger-producer-readback.json'), JSON.stringify({ original_decision_id: decisions['298726'].row.decision_id,
  original_result: decisions['298726'].row.result, source: memory.cardSource, context: facts.context,
  all_candidate_slots: [...facts.options.keys()], escape_discard: facts.options.get(3) }, null, 2) + '\n');
console.log('Original pending dispatch -> existing producer -> observed discard facts: passed');

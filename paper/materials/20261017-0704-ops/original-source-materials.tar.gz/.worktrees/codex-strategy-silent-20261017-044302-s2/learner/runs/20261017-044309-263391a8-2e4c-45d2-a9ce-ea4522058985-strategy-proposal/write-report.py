import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
BASE = 'edff4b9a3f6a9a8061c077a5ce731781fc7d4c79'
assert (OUT/'sandbox-check.exit').read_text().strip() == '1'
assert (OUT/'sandbox-check-r2.exit').read_text().strip() == '1'
assert (OUT/'sandbox-check-r3.exit').read_text().strip() == '0'
assert (OUT/'global-build-health-python-r2.exit').read_text().strip() == '0'
assert (OUT/'gitleaks-staged.exit').read_text().strip() == '0'
source = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source != BASE
assert subprocess.check_output(['git','rev-parse',source+'^'],text=True).strip() == BASE
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
for entry in json.loads((OUT/'source-leaves.json').read_text()):
    assert hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest() == entry['sha256']
preflight = json.loads((OUT/'live-preflight-final.json').read_text())
assert preflight['merge_tree_exit'] == 1 and preflight['source_apply_check_exit'] == 0
assert preflight['duplicate_source_is_live_ancestor']
ps = json.loads((OUT/'assigned-proposals.json').read_text())
results = json.loads((OUT/'proposal-results.draft.json').read_text())
for r in results:
    if r['id'] in ('silent-proposal-e4263c03267cf4cf','silent-proposal-267864aef9c1f322'):
        r['reason'] += ' 窄子项本地源码提交'+source+'；尚未live，不登记implemented。'
(OUT/'proposal-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
dispatch = json.loads((OUT/'dispatch.json').read_text())
report = {
 'task':'strategy-proposal','character':'silent','batch':'20261017-044302-s2-strategy-proposal',
 'base':BASE,'runs':dispatch['runs'],
 'fixes':[{'id':'silent-dagger-throw-sandpit-context','commit':source,
           'description':'Silent A10沙坑2的投掷匕首单弃牌窗口展示弃后逃离与当前费用；保留全部候选。',
           'runs':['R3AJCGQGGMR4'],'floor':33,'turn':5,'ledger':['silent-0018','silent-0117'],
           'proposal_ids':['silent-proposal-e4263c03267cf4cf','silent-proposal-267864aef9c1f322']}],
 'skipped':[],'merged':None,'version':None,'tests':{'tsc':0,'vitest':0,'cases':30},
 'validation':{'initial_sandbox_exit':1,'initial_files_passed':456,'initial_cases_passed':4234,
   'initial_failed_file':'tests/global-build-health.test.ts','initial_failure':'spawnSync /usr/bin/python3 EPERM',
   'parallel_recheck_exit':1,'parallel_recheck_workers':4,'parallel_recheck_timeout_cases':6,
   'parallel_recheck_files_passed':453,'parallel_recheck_cases_passed':4228,
   'sandbox_recheck_exit':0,'sandbox_recheck_workers':1,
   'sandbox_recheck_main_files':456,'sandbox_recheck_main_cases':4234,'sandbox_recheck_paths_cases':11,
   'sandbox_recheck_extra_exclusions':['tests/global-build-health.test.ts'],
   'unchanged_python_test_exit':0,'unchanged_python_cases':4},
 'code_proposals':[p['id'] for p in ps],'implementation_domains':['combat'],
 'proposal_results':results,'report':str(OUT/'report.md'),
 'merge_blocked':{'reason':'live整支合并预检存在六份共享记录内容冲突；按任务停止，四文件净补丁apply --check为0。',
                  'source_patch':str(OUT/'source.patch'),'details':str(OUT/'live-preflight-final.stdout.txt'),'live_head':preflight['live'],'lock_confirmed':True}
}
(OUT/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# 静默猎手策略实现与本批处置','',
 '本批20261017-044302-s2-strategy-proposal。普通队列十原ID；未绑定专题或冻结实现请求。基线`'+BASE+'`，开工工作树干净，合main返回Already up to date。', '',
 '## 实现与边界','',
 '已提交四文件窄修复：`'+source+'`。R3AJCGQGGMR4 A10 F33 T5，states s306208/209/210、decisions d298726/727/728，账本silent-0018、silent-0117。代码提案沿原silent-proposal-e4263c03267cf4cf和silent-proposal-267864aef9c1f322，不造新ID，不把窄子项当整个combat/sl提案完成。', '',
 '旧：独立沙坑弃牌事实只接Prepared/Survivor。新：在来源同战同回合、Silent A10、唯一活体沙虫/沙坑2、单弃牌且槽位/费用一致时，Dagger Throw也接现有事实。原帧2能量、唯一1费逃离，逐候选展示弃后还剩多少可支付逃离。五候选均可选，不改排名/SL探索/药水权重，不承诺保留逃离会赢。未观察角色、进阶及不匹配窗口保持旧输出。', '',
 '既有noteCardSource生产者用原pending派发动作及真实前后帧读回，见dagger-producer-readback.json。pending回执本身不当成完整执行；后续选择窗口及逃离离手有独立原帧。原始三个完整state字段进入固定夹具，没有以省略字段的投影冒充全state。', '',
 '完整提案、证据、反例、切分和回退：'+str(OUT/'proposal.md')+'。预期减少事实遗漏，不预估胜率收益；回退只逆转本提交四叶，保留后续知识/并行记录和全部证据。', '',
 '## 验证','',
 '固定新测试9项。仅撤去两生产源码后1失败/8通过，恢复后三文件30项通过；source-ablation.json及两日志保留。原仓库入口SANDBOX_WORKERS=1完整跑3205.97秒，tsc0；456文件/4234项过，唯一失败为旧global-build-health的execFileSync Python包装器EPERM，其内部四项已输出OK。原full1保留，不冒称原整套0。原Python文件按包装器真实路径直跑四项0；首次手工误写路径的exit2日志亦保留。之后仍用原test-sandbox.sh，仅经参数显式排除该包装器。四worker复验1250.54秒，453文件/4228项过，药水1项、目标选项4项、缩小1项均为原时限超时；r2 full1保留。这51项所在三文件首轮单worker均过，未从这些兼容固定题添加游戏规则。按任务对高负载超时单worker重跑一次，r3原入口主套456文件4234项通过（2312.67秒）、paths11项通过，最终退出0（sandbox-check-r3.log）；源码、测试断言及时限均未改。最终0覆盖该明确沙箱范围，包装器由原Python四项补验，不等于宿主完整套件0，也不将两份原full1改写为0。gitleaks暂存扫描0，git diff --cached --check通过；四叶SHA见source-leaves.json，检查期间未改源码或断言。', '',
 '## 证据覆盖与限制','',
 '10个派发锚点加4个原提案支持局，共14个已结束Silent身份。A0三、A2一、A3一、A6二、A7二、A10五；不混阶拟参数、不计算纯Codex爬塔战绩。原八流27610行全部逐原offset/bytes/SHA、显式局号/冲突身份和输出SHA复核。每流source_size见原manifest；8份提取输出无损压缩、解压原字节SHA复核，见evidence-compression.json。fight-plans在该截点0行，仅表示未选到，不断言源流缺失。', '',
 '13个库存遭遇逐阶段与旧保存材料一致，A10库存仅4局，M0墨影不充库存样本。R3的77→90→99与两次清旧毒、末9HP/12挡对26及敌余87已核；266是事后完整本体预算，不是事前已知未来恢复分布。其他进阶仅分列旁证。旧完整dirty运行树未知，当前基线不能代表原运行源码。', '',
 'R3石头F29取得后F30/31/33/35/37/39/43/45八房首帧均1敏，未将之前11房计入；99房来自原纠错的131断言材料，本批没有冒称重新全量分析另外十支持局。其既有源码71af970600794f87a993df428cdde14dd7809dd7已核实际live祖先，计数勘误标duplicate。', '',
 'R3 SL T3同可见盘面，敌294→252/262对应全轮净清42/32、均损25；M0第2/3/4试T9同19血/敌97，净清19/19/25且损0/0/9。原帧算术见facts-checked.json，均不升格完整候选因果或受控胜线。资源链见两局resource-chain.json：R3 F37/39/43三胜净耗20/24/45，M0 F13/14/15三胜净耗21/20/3，SL恢复与回血分账。', '',
 '两局现有执行消费者各排除1条无动作map/route-change元记录后退出0：R3 134段/667动作/107轮窗，M0 115段/525动作/101轮窗。其余1192条真实decision_id、原顺序及source行号保留。两条原件及首次CLI listen EPERM、原封套因缺编号的拒绝均保留；未填造id或补接缺口。所有actual_full_candidate_result仍null是工具契约，不能倒推没执行，也不能证明完整候选收益。', '',
 '## 未合入与上线状态','',
 'merged=null，无本批行为版本，无shipped或实际上线双通知。live整支merge-tree预检在notes/fix-queue-v4.md、notes/for-roy.md、notes/ops-handoff.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl六份共享记录冲突，按任务停止且未执行真实merge。最终在原ops/live-merge.lock内只读核验实际live 51511b28e8fa085adbd30f232e625ebee058fe59，六冲突仍在；未执行实际merge，live现有card-upgrades刷新与两份后台笔记均未覆盖。四文件净补丁的live apply --check --index为0；精确源码、patch、四SHA交原ops兜底，须由ops核真正live祖先再分配统一编号。', '',
 '本批仅经根ledger.py update追加23个既有本角色账本的where/note；两关联账本补源码链接。原claim/首证/prior/evidence/status/version及历史shipped不改，不重复support/repeat，不把旧数据shipped当本源码shipped。CLI输入/输出与物理前缀保护见ledger-update-proof.json。专用提案队列只读，状态由原调度器消费本回报。', '',
 '## 十项处置','']
for r,p in zip(results,ps):
 lines += ['### '+r['id'],'','账本：'+','.join(p['ledger'])+'；原证据局：'+','.join(p['runs'])+'。','',r['state']+'：'+r['reason'],'']
lines += ['## 运行与保留','',
 '全程单agent、本地固定数据，无LLM/网络/新对局。实际启动命令为gpt-6.1-sol/xhigh/default；只将此记作启动命令证据，未把默认配置或缺失的原生请求头当切换证明。原任务/工作树/基线身份保持。未修改其他角色知识、运维prompt、凭据或依赖。', '',
 '所有失败日志、零选帧初稿、原Markdown和压缩提取字节均保留。未清理自身工作树，不关闭旧量化或研究父要求。自然消费者采用与收益须待实际live发布后的本角色对局核证。', '']
(OUT/'report.md').write_text('\n'.join(lines))
print(json.dumps({'source':source,'report':str(OUT/'report.md'),'dispositions':len(results)},ensure_ascii=False))

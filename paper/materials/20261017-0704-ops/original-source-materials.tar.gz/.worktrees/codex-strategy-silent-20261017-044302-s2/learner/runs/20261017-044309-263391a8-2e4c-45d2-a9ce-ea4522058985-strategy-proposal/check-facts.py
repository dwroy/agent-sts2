import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
frames=json.loads((OUT/'target-frames.json').read_text())
def state(line):return frames[str(line)]['row']['state']
def power(obj,id):return sum(p['amount'] for p in obj.get('powers',[]) if p['power_id']==id)
checks=[]
for before,after,old,new,poison in [(306415,306416,77,90,5),(306438,306439,90,99,27)]:
 a,b=state(before),state(after);ea,eb=a['combat']['enemies'][0],b['combat']['enemies'][0]
 assert ea['max_hp']==old and eb['max_hp']==new and eb['current_hp']==new
 assert power(ea,'POISON_POWER')==poison and power(eb,'POISON_POWER')==0
 assert a['turn']==b['turn']
 checks.append({'kind':'stock_observed_reset','from':before,'to':after,'old_max_hp':old,'new_max_hp':new,'old_poison':poison,'new_poison':0})
a,b=state(306440),state(306444);p=a['combat']['player'];end=b['combat']['player'];enemy=b['combat']['enemies'][0]
assert p['current_hp']==9 and end['current_hp']==0 and enemy['current_hp']==87
assert state(306443)['combat']['player']['block']==12
assert power(state(306443)['combat']['player'],'DEXTERITY_POWER')==3
checks.append({'kind':'stock_final','hp_before':9,'block':12,'incoming':26,'complete_hp_cost':14,'minimum_extra_hp_to_survive':6,'enemy_final_hp':87})
for run in ['R3AJCGQGGMR4','M0GY0A4M2F7H']:
 data=json.loads((OUT/(run+'.selection-input.json')).read_text());floor=33 if run.startswith('R3') else 17; groups=[];active=[];previous=0
 for row in data['states']:
  s=row['state'];t=s.get('turn');info=s.get('run') or {}
  if info.get('floor')!=floor or not s.get('in_combat') or not isinstance(t,int):continue
  if t<previous and t==1:
   if active:groups.append(active)
   active=[]
  active.append(row);previous=t
 if active:groups.append(active)
 for index,rows in enumerate(groups,1):
  turn=3 if floor==33 else 9
  start=next((r for r in rows if r['state']['turn']==turn),None)
  end=next((r for r in rows if r['state']['turn']==turn+1),None)
  if not start or not end:continue
  a,b=start['state'],end['state'];hp=a['combat']['player']['current_hp'];ehp=a['combat']['enemies'][0]['current_hp'];hp2=b['combat']['player']['current_hp'];ehp2=b['combat']['enemies'][0]['current_hp']
  checks.append({'kind':'visible_turn_endpoints','run_id':run,'floor':floor,'attempt_index_from_turn_reset':index,'turn':turn,'from_line':start['_line'],'to_line':end['_line'],'hp_before':hp,'hp_after':hp2,'enemy_hp_before':ehp,'enemy_hp_after':ehp2,'net_hp_loss':hp-hp2,'net_enemy_hp_loss':ehp-ehp2,'limitation':'仅同次观测端点，未分源净扣，不认证完整候选或受控反事实'})
(OUT/'facts-checked.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False))

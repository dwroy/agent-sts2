import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
os.environ['LEDGER_FILE'] = str(ROOT / 'paper/materials/learning/ledger.jsonl')
os.environ['LEDGER_RUNS'] = str(ROOT / 'logs/runs.jsonl')
os.environ['LEDGER_VERSIONS'] = str(ROOT / 'eval/versions.json')
source = sys.argv[1]
assert len(source) == 40
assert subprocess.check_output(['git', 'cat-file', '-t', source], text=True).strip() == 'commit'
ps = json.loads((OUT / 'assigned-proposals.json').read_text())
ids = sorted({ident for p in ps for ident in p['ledger']})
requests = []
for ident in ids:
    assigned = [p['id'] for p in ps if ident in p['ledger']]
    where = {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]}
    note = ('20261017-044302-s2-strategy-proposal：原派发' + ','.join(assigned) +
            '；八流27610原行逐offset/bytes/SHA/身份核，13库存局分阶及R3石头8房核。'
            '仅追溯，不重复support/repeat，不改原claim/首证/prior/evidence/status/version/shipped；'
            '九宽项waiting、一计数勘误duplicate，细项见本批proposal-results.json。')
    if ident in ('silent-0018', 'silent-0117'):
        where['commits'] = [source]
        note += ('本批窄子项source=' + source +
                 '，仅Silent A10投掷匕首弃牌沙坑事实，定向30项0、撤源1败8过；'
                 '源码提交不等已live，保留原数据shipped历史，原combat/sl宽项不关闭。')
    requests.append({'id': ident, 'by': 'learner:strategy-proposal', 'where': where, 'note': note})
request_bytes = ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in requests).encode()
(OUT / 'ledger-update-input.jsonl').write_bytes(request_bytes)
ledger = ROOT / 'paper/materials/learning/ledger.jsonl'
limit = ledger.stat().st_size
with ledger.open('rb') as handle:
    prefix_sha = hashlib.sha256(handle.read(limit)).hexdigest()
with (OUT / 'ledger-update.stdout.txt').open('wb') as stdout, (OUT / 'ledger-update.stderr.txt').open('wb') as stderr:
    result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'], input=request_bytes,
                            stdout=stdout, stderr=stderr)
assert result.returncode == 0, 'ledger CLI rejected update; inspect the preserved stderr'
with ledger.open('rb') as handle:
    assert hashlib.sha256(handle.read(limit)).hexdigest() == prefix_sha
    offset = limit
    rows = []
    for line in handle:
        try:
            r = json.loads(line)
        except ValueError:
            offset += len(line)
            continue
        if r.get('by') == 'learner:strategy-proposal' and r.get('note', '').startswith('20261017-044302-s2-strategy-proposal：'):
            rows.append({'id': r['id'], 'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest()})
            assert set(r) <= {'op','id','ts','by','where','note'}
        offset += len(line)
assert sorted(r['id'] for r in rows) == ids
(OUT / 'ledger-update-proof.json').write_text(json.dumps({'source': source, 'cli_exit': 0,
    'prefix_bytes': limit, 'prefix_sha256': prefix_sha, 'prefix_unchanged': True,
    'owned_updates': rows, 'protected_claim_evidence_status_fields_not_written': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source': source, 'owned_updates': len(rows), 'cli_exit': 0}))

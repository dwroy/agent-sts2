# 本批策略提案与逐项核证

本批：20261017-044302-s2-strategy-proposal；角色：silent；基线：edff4b9a3f6a9a8061c077a5ce731781fc7d4c79。普通队列十原ID，无research_request或implementation_request；main合并结果为Already up to date。

## 可实施的窄子项：投掷匕首弃牌沙坑事实

来源原提案：silent-proposal-e4263c03267cf4cf、silent-proposal-267864aef9c1f322。账本：silent-0018、silent-0117。授权：Roy-2026-10-07-learning。来源任务postmortem/experience-update，实现任务为本批strategy-proposal。

已核原帧：R3AJCGQGGMR4 A10 F33 T5，states s306208/306209/306210、decisions d298726/298727/298728。原字节offset/bytes/SHA见target-decisions.json及测试夹具source_frames；所有原决策有真实decision_id。d298726选择投掷匕首→匕首雨→逃离，d298727实际弃index3唯一逃离，随后按真实手牌重算。

旧行为：通用discard_plan已能说明续计划，独立沙坑事实仅在PREPARED和SURVIVOR的已观察窗口提供，DAGGER_THROW没有该事实。新行为：在Silent A10、唯一活体沙虫、沙坑2、同战同回合的已核DAGGER_THROW单弃牌窗口，按真实剩余手牌/费用展示候选弃后逃离数、是否删掉最后可支付副本。当前帧2能量、唯一1费逃离、五合法候选均保留；无续计划也能显示独立截止。

条件与未知：沿用现有辅助函数的动作类型、槽位一致、费用/星费及沙坑检查；不模拟弃牌触发、下轮抽牌、后续可支付性或完整胜负。其他角色、进阶、不同沙坑及来源不明窗口保持原输出。只比较此刻剩费，保留逃离不等于能活。

反例：R3第2试T3撤投掷匕首，兑现伤42→32但同损25；后续药时点T6→T4、防御/弱化/逃离均改变。T7三血赢不能归因仅保留逃离。不改SL探索或药水阈值。

拟合与切分：不拟合任何分数、概率、药价、倍率或HP阈值。R3固定帧验证单个窗口，现有Prepared/Survivor固定题作兼容核验；后续独立本角色局才可验证自然采用/收益，SL尝试不增独立样本。

验证：新固定测试9项；撤去两处生产源码后1失败/8通过，恢复后三组30项通过。完整沙箱入口正在执行，终局另记report.md；本文件不提前声称提交或合入。预期仅减少事实遗漏，不承诺本局转胜。回退为恢复本次源提交的父版两个生产文件，保留夹具、原证据、账本和失败回执。

## 十项处置（宽项与子项分开）

### silent-proposal-d04933cbd408d85b

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-221302-postmortem/proposal-stock.md

账本：silent-0311,silent-0312,silent-0005,silent-0027,silent-0011,silent-0046；证据局：R3AJCGQGGMR4。

waiting：已核R3 F45T2/T6的77→90→99及清旧毒；13局的恢复序列不构成同阶恢复分布。当前rollout库存分支仍沿用旧maxHp，需未来机体HP的不确定性契约及跨台清除路径的固定消费者核证；不能将事后266写成事前确定需求。

### silent-proposal-e4263c03267cf4cf

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-221302-postmortem/proposal-escape-context.md

账本：silent-0117,silent-0018；证据局：R3AJCGQGGMR4。

waiting：本批实现投掷匕首单弃牌窗口的沙坑/当前费用/最后可支付逃离事实；原提案还含SL同盘取舍。T3撤刀少10伤仍损25，胜试同时提前药水并改变防御、弱化及逃离，缺受控完整后继，宽项继续等待。

### silent-proposal-574d0359cc102419

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-224303-experience-update/proposal-mechanisms.md

账本：silent-0005,silent-0012,silent-0021,silent-0011,silent-0027,silent-0046,silent-0084,silent-0158,silent-0047,silent-0063,silent-0009；证据局：R3AJCGQGGMR4。

waiting：局部力敏、脆弱、触媒、涂毒和旧毒清除事实已核；末T7的9血12挡对26与新5毒实际12分账。库存未来血量、药水持有/施放时点及跨阶段联合资源尚无完整候选执行与整战校准，不用败局推出所有局部机制有bug。

### silent-proposal-8e5765c4bfbaba5b

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-224303-experience-update/proposal-resources.md

账本：silent-0019,silent-0020,silent-0142,silent-0243；证据局：R3AJCGQGGMR4。

waiting：R3 F37/39/43三胜的净耗20/24/45及F44羽毛6→30、HEAL至52已核；F40条件35/p75 23与实际6并非同一已兑现资源。缺未走路线/回血或锻造的受控整场结果及逐来源资源到原题面完整投影，保留5样本房间代价门槛。

### silent-proposal-267864aef9c1f322

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-224303-experience-update/proposal-replay.md

账本：silent-0018,silent-0117；证据局：R3AJCGQGGMR4。

waiting：与e426共享本批投掷匕首弃牌事实子项；保留全部候选，不将保留逃离当胜线。SL少10伤同损25与后续药序/牌序混杂尚未给出独立探索阈值，完整combat/sl宽项未关闭。

### silent-proposal-bc357cb8bcee3b22

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-224303-experience-update/proposal-stock.md

账本：silent-0312；证据局：LRN0HPZ0FZS1,T082DRCUHRRD,R0HEV5E3QT6G,ZZMYZ5UBCG72,10GPK5XGHCK3,UACFSW4VDDLD,53FLQ68CETW0,SADL3CGYTGSR,VLV17NUSFS61,UMVLWER4CD98,9R916WW0V65N,BJLTVSYXCSGS,R3AJCGQGGMR4。

waiting：13局各有库存2/1/0的不同上限，分A0/A2/A3/A6/A7/A10核对；A10仅4局库存遭遇。尚无同阶恢复概率分布与跨台受控模拟，已见新上限读入不等未来上限已知，与d049共享缺口，不新造父项。

### silent-proposal-0337be0b6a07fbdc

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-224303-experience-update/proposal-stone-correction.md

账本：silent-0158；证据局：R3AJCGQGGMR4。

duplicate：原提案仅纠正110→99持有后房数，规则不变；本批R3 F29取得后8房首帧均1敏原字节核实，原131项断言/99房材料保留，未把其余10支持局冒成本批全量重算。现有生产源码已读现场DEXTERITY_POWER/FRAIL_POWER，源码71af970600794f87a993df428cdde14dd7809dd7为实际live祖先，无新增规则可实施。

### silent-proposal-40167a3d9d4a7110

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-234302-experience-update/proposal-mechanisms.md

账本：silent-0005,silent-0012,silent-0021,silent-0224,silent-0227,silent-0170；证据局：M0GY0A4M2F7H。

waiting：M0 F17六试未赢；滑溜逐击及毒结算限伤、末T7两敏三挡20对32仍死已核。缺药生成牌实际施放、增益建立与跨轮资源联合后继的完整核证；不把拥有闪亮/步法或5毒当已兑现胜果。

### silent-proposal-78fce763f2bc9f73

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-234302-experience-update/proposal-resources.md

账本：silent-0019,silent-0020；证据局：M0GY0A4M2F7H。

waiting：M0八胜净耗83、三次回血63及事件自损7，与F12条件boss64/实到29分账；缺未走精英或锻造路线整场反事实及题面完整资源来源映射，单次35差值不能拟为统一模型偏差或路线权重。

### silent-proposal-0277e542bf135198

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-234302-experience-update/proposal-replay.md

账本：silent-0079；证据局：M0GY0A4M2F7H。

waiting：M0 F17同盘T9的19血/敌97下，换防御+为打击使全轮净清19→25、损0→9；六试0胜，后继也变。缺完整保血线胜果及稳定候选执行/后继控制，不据饱和24/24死亡拟统一禁攻或SL阈值。

## 原始证据与限制

14个相关局均经runs.jsonl核为Silent；10派发锚点不等全部支持局。八流27610行全部复核原source_size、offset、bytes、SHA和冲突身份判定；fight-plans为0只表示本截点未选到，不断言原流缺失。每流已无损压缩并解压SHA复核，清单保留原输出SHA。

库存13局：A0三、A2一、A3一、A6二、A7二、A10四，逐阶段及原帧见stock-transitions.json。不同进阶只作机制/限制旁证，不混拟A10血量分布。M0为另一个A10墨影局，未冒作库存样本。完整历史dirty运行源码未知，当前基线不能代替原运行树。

石头99房来自原纠错材料；本批独立复核仅R3持有后8房，未以当前18支持条目倒改旧11局分母。来源原Markdown的历史for-dai路径保持原件；如实际上线，通知使用现行notes/for-roy.md与ops/inbox-dev.md。


## 最终交付追加

本地源码提交：`6c306a49710731da372989ae03ec09eb0a425bb1`。原沙箱full1仅Python包装器EPERM，四worker复验full1为六项原题超时；单worker按任务重跑一次，主456文件4234项与paths11项均通过，最终沙箱入口0。原Python四项直跑0；源码、断言、时限均未改。所有原失败与误写手工路径日志保留。

在ops/live-merge.lock内核最新live `51511b28e8fa085adbd30f232e625ebee058fe59`：六份共享记录仍有整支合并内容冲突，四文件净补丁apply --check --index为0；未执行真实merge，未注册行为版本或标新shipped。两原combat/sl宽提案只完成窄子项，十派发ID最终9 waiting/1 duplicate。已由根ledger.py update追加23条where/note追溯并保护旧物理前缀及状态字段；实际回执见ledger-update-proof.json。完整最终结果见report.md与result.json。

import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract_evidence', Path.cwd() / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
runs = json.loads((OUT / 'run-identities.json').read_text())
analyses = collections.defaultdict(lambda: {'states': [], 'decisions': []})
stock = {}
previous = {}
selected = {}
stone = {}
verification = []
targets = {306198,306208,306209,306210,306213,306223,306233,306256,306257,306258,306259,306260,306415,306416,306438,306439,306440,306441,306442,306443,306444}

def powers(enemy):
    return {p['power_id']: p['amount'] for p in enemy.get('powers', [])}

def point(e, state, enemy):
    return {'line': e['line'], 'offset': e['offset'], 'bytes': e['bytes'], 'sha256': e['sha256'],
            'turn': state.get('turn'), 'hp': enemy.get('current_hp'), 'max_hp': enemy.get('max_hp'),
            'powers': powers(enemy)}

for stream in manifest:
    name = stream['stream']
    counts = collections.Counter()
    digest = hashlib.sha256()
    with open('/home/dw/Projects/agent-sts2/logs/' + name + '.jsonl', 'rb') as source, gzip.open(OUT / 'evidence' / (name + '.evidence.jsonl.gz'), 'rb') as handle:
        for encoded in handle:
            digest.update(encoded)
            e = json.loads(encoded)
            assert e['offset'] + e['bytes'] <= stream['source_size']
            source.seek(e['offset'])
            raw = source.read(e['bytes'])
            assert hashlib.sha256(raw).hexdigest() == e['sha256']
            row = json.loads(raw)
            assert row == e['row']
            assert extractor.run_identity(row) == e['run_id']
            assert str(runs[e['run_id']][-1]['character']).lower() == 'silent'
            counts[e['run_id']] += 1
            run = e['run_id']
            if run in ('R3AJCGQGGMR4', 'M0GY0A4M2F7H') and name in ('states', 'decisions'):
                analyses[run][name].append({**row, '_line': e['line']})
            if name != 'states':
                continue
            s = row['state']
            c = s.get('combat') or {}
            info = s.get('run') or {}
            assert s.get('run_id') == run
            assert str(info.get('character_id')).lower() == 'silent'
            if run == 'R3AJCGQGGMR4' and e['line'] in targets:
                selected[str(e['line'])] = e
            if run == 'M0GY0A4M2F7H' and info.get('floor') == 17:
                player = c.get('player') or {}
                if s.get('turn') in (1, 7, 9, 10) and player.get('current_hp') in (29, 19, 8, 0):
                    selected[str(e['line'])] = e
            relics = info.get('relics') or []
            if run == 'R3AJCGQGGMR4' and s.get('in_combat') and any(r.get('relic_id') == 'ODDLY_SMOOTH_STONE' for r in relics):
                stone.setdefault(info['floor'], {'line': e['line'], 'turn': s.get('turn'), 'dexterity': powers(c.get('player') or {}).get('DEXTERITY_POWER', 0)})
            for enemy in c.get('enemies') or []:
                if enemy.get('enemy_id') != 'AXEBOT':
                    continue
                key = (run, info['floor'])
                entry = stock.setdefault(key, {'run_id': run, 'ascension': info.get('ascension'), 'floor': info['floor'], 'stages': {}, 'transitions': []})
                current = point(e, s, enemy)
                amount = current['powers'].get('STOCK_POWER', 0)
                entry['stages'].setdefault(str(amount), set()).add(current['max_hp'])
                old = previous.get(key)
                if old and amount < old['powers'].get('STOCK_POWER', 0):
                    entry['transitions'].append({'before': old, 'after': current})
                previous[key] = current
    assert digest.hexdigest() == stream['output_sha256']
    assert dict(counts) == {k:v for k,v in stream['counts'].items() if v}
    verification.append({'stream': name, 'verified_rows': sum(counts.values()), 'source_size': stream['source_size'], 'counts': stream['counts'], 'output_sha256': digest.hexdigest(), 'all_offsets_bytes_hashes_identities_verified': True})

for entry in stock.values():
    entry['stages'] = {k:sorted(v) for k,v in entry['stages'].items()}
assert len(stock) == 13
assert all(set(e['stages']) == {'0','1','2'} for e in stock.values())
r3 = next(e for e in stock.values() if e['run_id'] == 'R3AJCGQGGMR4')
assert r3['stages'] == {'2': [77], '1': [90], '0': [99]}
assert sorted(stone) == [30,31,33,35,37,39,43,45]
assert all(e['dexterity'] == 1 for e in stone.values())
for line in (306416,306439):
    assert powers(selected[str(line)]['row']['state']['combat']['enemies'][0]).get('POISON_POWER',0) == 0
assert selected['306438']['row']['state']['combat']['enemies'][0]['current_hp'] == 2

for run, rows in analyses.items():
    payload = {'run': runs[run][-1], **rows}
    (OUT / (run + '.selection-input.json')).write_text(json.dumps(payload, ensure_ascii=False) + '\n')
(OUT / 'evidence-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
(OUT / 'stock-transitions.json').write_text(json.dumps(list(stock.values()), ensure_ascii=False, indent=2) + '\n')
(OUT / 'target-frames.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
(OUT / 'stone-eight-rooms.json').write_text(json.dumps(stone, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows':sum(e['verified_rows'] for e in verification), 'stock_runs':len(stock), 'stone_rooms':len(stone), 'target_frames':len(selected)}, ensure_ascii=False))

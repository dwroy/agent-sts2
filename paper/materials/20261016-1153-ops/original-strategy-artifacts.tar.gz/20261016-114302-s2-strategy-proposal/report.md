# 静默猎手十项策略提案复核

记录时间：2026-10-16T11:51:57+08:00（写入前已date）。任务strategy-proposal，角色silent，批次20261016-114302-s2-strategy-proposal。
基线/本批HEAD：`3fed9139bea876f283d8cf2241fe8f90871a6782`。本批10项均waiting，无源码、知识、提交、合入或行为版本。

本批结论：五局八流重新选中的6060行与原061302-s2批逐字节一致，派发范围内没有新增实盘证据。十项所需的完整执行归属、逐源资源链、复活逐击、合法后继或整战受控比较仍有明确缺口；保持现有策略，不造源码改动或重复提案。

## 身份与范围

开工git status为空。learn.json只读本批行：task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配，10个proposal_ids，无proposal_repair/research_request/implementation_request。普通专题文件绑定另一批次，本批不承接专题。核对后git merge --no-edit main返回Already up to date；HEAD完整基线不变。

已读README、最新STATE-2026-10-15、decision-log末尾、学习协议、代码提案闭环和学习要求闭环。独立完成，不派子agent。只读本角色五局、所属原提案与账本和相关源码；未扩展其他队列、专题、角色知识或全历史统计。原日志只读，无网络、模型、模拟或游戏调用，不运行play、不读凭据/二进制、不改运维prompt。

当前原生模型/推理参数没有独立读取核验；未切换模型或模式，不凭历史游戏run-config冒称当前会话配置已核，交原宿主核实。

## 原证据与可复核范围

共用extract_evidence.py执行完成，原stdout保存extraction.log；每流source_size独立冻结，每条保存source/line/offset/bytes/SHA/row。verify-evidence.py逐行seek原源，重新核SHA、JSON、边界及显式所属身份，支持run-plans.run、run_id/state.run_id/fingerprint.run，冲突身份拒收。完整结果见integrity.json。

| 流 | 本次source_size | 选中行数 |
|---|---:|---:|
| states | 13469894819 | 2965 |
| decisions | 1885008027 | 2846 |
| sl-attempts | 42957953 | 26 |
| run-config | 1850737 | 5 |
| run-plans | 8493918 | 30 |
| brain | 665572951 | 183 |
| runs | 346458 | 5 |
| fight-plans | 2233957 | 0 |

八流选中封套SHA全部等于原061302-s2。原run-plans截点8380258另经共用入口、--streams run-plans --source-size复核，保存prior-run-plans-cutoff/，与本次30行选中SHA相同；没有覆盖旧产物。流增长不等于本批新增证据。fight-plans本截点0行只说明未选到，不断言日志不存在。整条流非法行计数不能归属本批，也不能由此补写内容。

| 局号 | 角色/进阶 | 结束 | 原源码提交 |
|---|---|---|---|
| 7X0W3U8TVA2A | SILENT/A10 | F31 败 | `047c809e625da861e34469791370f620866dee6f` |
| MTQ0EUBJ3R6T | SILENT/A10 | F23 败 | `ceb74207f90ed2e2f94f96570e70d00d84290081` |
| KFRDELW2TH2P | SILENT/A10 | F33 败 | `a73ce7ccbcfd09a9f9679dc4bddaf3dacb56b253` |
| GXNKW8X1XYJP | SILENT/A10 | F45 败 | `b1714285e60ce5a02798bea8cd5d4aa3118a2512` |
| ZE8F192FKX24 | SILENT/A5 | F48 胜 | `452f7bc7ac23bd1464fe04b951272236f471de8d` |

ZE8 A5仅作现场抑制版本观察，四局A10审计与之分列，相关SL不当独立局。五局run-config均记录可定位的完整源码提交，dirty_files为知识JSON；历史刷新知识原字节及完整联合输入未复原，不能用当前树代历史实际运行输入。未重核原提案118/119/120局全史分母或药水历史准确率。

## 本批材料核验与原消费者读回

本批31项材料断言通过，逐项见evidence-checks.json。复核20份原消费者输入/输出/stderr/退出码及资源链材料的已登记SHA。四份原离线输入由本次原帧重新构造后逐字相等，相关learner消费者源码SHA未变；没有重跑消费者或模拟。原rc0仅为历史离线工具执行结果，不冒报本批生产测试、自然采用或联合校准。

| A10局号 | 原候选段 | 原动作 | 回合端点 | 未知回合 | 完整候选认证 |
|---|---:|---:|---:|---:|---:|
| 7X0W3U8TVA2A | 119 | 445 | 7 | 64 | 0 |
| MTQ0EUBJ3R6T | 68 | 424 | 25 | 50 | 0 |
| KFRDELW2TH2P | 180 | 586 | 18 | 85 | 0 |
| GXNKW8X1XYJP | 116 | 646 | 20 | 83 | 0 |

合计483候选段、2101动作，352回合窗中70已核端点/282未知，完整候选认证0。KFR一条、GX三条无decision_id原元数据仍保留，原消费者未重编号或跨这些行认证连续性。实际动作completed只证明接口回执，不能复制整条预测收益。原资源链84窗口包含重试和缺口，不当84独立战斗或完整损伤账。

关键原帧：

- KFR F33T6同盘15血/228敌/36毒/3覆甲，原线净扣83损6，SL替线净扣93损12；两线都未赢，不据局部10伤/6血差拟统一价格。F12原护栏完整候选在生成小刀后重问，原0损候选未完整执行，不把实际6损当预测误差。
- KFR F33末T7，手上技法7挡、防御后12挡，三手动名额满后奇巧爆发虽余1能量仍锁；毒药37→43且敌159当步不变，之后43+42=85，敌74未死。它支持已观察时点事实，不能证明另一目标、先后顺序或提前喝药能赢。
- GX F45T2同盘后3/13血、0/7带挡，保血线敌多8血；末13血/23挡/2覆甲对40需损15，-2与原least-loss和实死一致。净HP含复活，不能当未截断入伤；缺复活瞬时逐击和前三退出。
- GX F33已建触媒2才有29+28+27=84毒伤，末F45未打触媒不预支收益。四次SL摘要确有四普通键inserted和旧升级键离堆，但T2→T3同时有抽牌，纯改标瞬间/唯一物理身份/事件次序未见，不能据基ID守恒延长已知前缀。ZE8 A5现场普通牌与场外升级分账。
- MTQ跨幕19→59，KFR跨幕22→60，与休息、开场和SL恢复分别记录；未到节点与未取得牌不填可用资源。连续赢战仍消耗后战缓冲，不从观察路线推替路线必胜。

这些是限定或未知边界的再次核验，没有新反经验结论，不重复增加support/repeat。

## 当前源码覆盖

source-audit.json冻结只读live引用`0e7998bfa8df267dcf8835a57949bdb982c9feb0`，不是本批merged。相关19叶中14叶逐字相同，5叶仅Roy/Dai历史注释归属词不同；保存source-live-differences.patch，未为比对改叶。8个既有源码提交均核base/live祖先。相对原061302-s2的15叶相同，另4叶为既有1698adc96的资源诊断补充，差分见prior-source-differences.patch。

奇巧事实仍continuation_verified=false；在线selection_audit仍actual_turn=null；新增SL资源比较提供rollout_saturated和预测资源差，但execution=unverified，不能补完整执行、瞬时帧或整战校准。限定毒药入口、HP净增边界、逐槽与回合离线工具均属已发布子项，不能将任一子项冒记整项duplicate/implemented。本批不复用旧生产检查绿、没有生产测试或新自然消费者声明。

## 十项处置

| 原CLI ID | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-19a5cff2094e2d8f | waiting | MTQ同盘换线与7X复活血池仅有局部观测；缺未截断入伤、持续实体归属和同输入整战校准，不能由死亡率饱和拟新SL/终局规则。 |
| silent-proposal-3540bf4360bf80af | waiting | 已有HP增加边界和离线资源链；尚缺完整回血来源/逐槽归因及原路线、休息消费者的联合读回，不能以净变化代已到资源或整项实现。 |
| silent-proposal-0ea5c0b9c030fdd6 | waiting | 懒惰奇巧提示及限定恶魔6毒入口已存在；完整合法后继仍标continuation_verified=false，缺自动重放/后继收益及多轮消费者校准，不能把局部覆盖当整项重复。 |
| silent-proposal-f915ec544ab94b6e | waiting | 既有离线工具可关联原答、SL替换和重问，但完整候选收益仍null；KFR T6整轮开端未核、F12原护栏线中断，缺可归属的完整实线及排序对照。 |
| silent-proposal-8fb51933639faf90 | waiting | 限定毒药及力敏/覆甲局部模型已有；覆甲完整减层条件未隔离，叠加药效、能力、能量的多入口联合校准和完整时点收益仍不足。 |
| silent-proposal-b3bc0eb09211af6c | waiting | 奇巧资源提示已有，完整后继与未建立收益仍未知；六次T7和局部SL均未证明替顺序可存活，缺整战兑现与终局价值校准。 |
| silent-proposal-fdc3a505fe5e1a55 | waiting | KFR实际休息、幕间、开场和SL恢复可分列，现有观测器已覆盖部分；完整路线/休息消费链、逐源归因及替路线对照仍缺，不能关闭整项。 |
| silent-proposal-5a95725089f53cd8 | waiting | GX局部复活后3/13血、0/7挡及药槽变化已有审计；缺复活瞬时逐击、未截断入伤、前三出口和完整候选归属，不能据10血/8伤差改规则。 |
| silent-proposal-51fa8bc34774f72d | waiting | 四次假inserted与升级键作差路径可复现；缺仅改标瞬时帧、稳定物理副本身份和并发抽牌/插入次序，不能仅按基ID守恒延长SL已知前缀。 |
| silent-proposal-29b7b36dffbcb017 | waiting | GX已建触媒两层的84毒伤和末战未建立能力可核，既有局部模型不缺；头骨/毒雾/覆甲/力敏联合多轮校准及完整时点对照仍不足。 |

逐项证据局/层/回合、账本、反例、既有源码、预期行为、验证与回退见本批proposal.md，十份原文原字节另存。无新完整源码差额或足够证据的规则参数；全部waiting保留待新局，不关闭宽提案、量化父要求或学习入库要求。

## 交付和未执行项

源码撤除失败/恢复通过不适用；没有源码改动，不制造失败或通过。生产tests={tsc:null,vitest:null,cases:null}，未运行完整套件。本批只有材料核验，无源码提交，gitleaks提交前扫描不适用；merged=null、无发布号、无知识重建、无规则变更双通知。

账本仅经根ledger.py update追加24个所属条目的本批proposal/report路径及note；不新增claim/evidence，不改status/version/shipped，不把旧shipped改回proposed，不手改账本/提案队列/根请求。实际CLI结果与逐offset/bytes/SHA及fold读回另存ledger-receipt.json；未有回执前不宣称写入成功。最终工作树与HEAD另见final-validation.json。

过程边界：只读探针曾将silent-sl-resource-comparison.ts误写为silent-sl-resources.ts，sed报路径不存在后已按真实import修正；不当产品缺陷。初次显示截断不作缺证判断。所有提取/核验子进程nice19、无子agent、无后台生产测试或模拟。旧失败与未知保留，scratch不删除。

交付：本目录proposal.md、report.md和result.json。经验库沉淀和实际消费者采用未在本批完成，不宣称已入库、shipped或关闭父要求。

最终读回：2026-10-16T11:53:03+08:00（前已date）。根ledger.py update实际rc0，24条所属where/note追加逐offset/bytes/SHA读回；旧物理前缀、完整evidence、claim/首证/进阶/prior/status/version/shipped/effect及where/history/notes前缀保持。只追加本批追溯，不增加支持或重犯。当前派发工作树/五局/十ID再次核对一致，git status为空、git diff --binary HEAD为空、HEAD仍为完整base。

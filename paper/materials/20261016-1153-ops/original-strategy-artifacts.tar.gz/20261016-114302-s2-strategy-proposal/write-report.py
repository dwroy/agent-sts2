import datetime
import hashlib
import json
from pathlib import Path
import subprocess

s = Path(__file__).resolve().parent
prior = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-061302-s2/learner/runs/20261016-061312-75aa99f7-7591-4dc3-92bb-76a83a3b598b-strategy-proposal')
stamp = subprocess.check_output(['date','-Is'],text=True).strip()
dispatch = json.loads((s/'dispatch.json').read_text())
ids = dispatch['dispatch']['proposal_ids']
dispositions = json.loads((prior/'dispositions.json').read_text())
assert [x['id'] for x in dispositions] == ids
for d in dispositions:
    if d['id'] in ('silent-proposal-19a5cff2094e2d8f','silent-proposal-f915ec544ab94b6e','silent-proposal-b3bc0eb09211af6c','silent-proposal-5a95725089f53cd8'):
        d['existing'] += ' 当前还核到1698adc96ba434a46942321e0237b70657e625b2已为base/live祖先：新增rollout_saturated、模型毒量及其他资源差审计，scope仍current_turn_prediction、execution仍unverified；不补历史完整实线或受控后继。'
    d['review_basis'] = '本批重新提取且逐行核验的五局八流，与原061302-s2选中封套逐字节一致；原离线消费者只复核输入/输出SHA，不重跑。'
(s/'dispositions.json').write_text(json.dumps(dispositions,ensure_ascii=False,indent=2)+'\n')
manifest = json.loads((s/'evidence/evidence-manifest.json').read_text())
integrity = json.loads((s/'integrity.json').read_text())
checks = json.loads((s/'evidence-checks.json').read_text())
sources = json.loads((s/'source-audit.json').read_text())
consumer = json.loads((s/'prior-consumer-receipt.json').read_text())
history = json.loads((s/'historical-source-limits.json').read_text())
old_plan = json.loads((s/'prior-run-plans-cutoff/evidence-manifest.json').read_text())[0]
new_plan = next(x for x in manifest if x['stream']=='run-plans')
assert old_plan['output_sha256'] == new_plan['output_sha256']
(s/'run-plan-cutoff-readback.json').write_text(json.dumps({'old_source_size':old_plan['source_size'],
    'new_source_size':new_plan['source_size'],'same_selected_sha256':True,'counts':new_plan['counts']},ensure_ascii=False,indent=2)+'\n')
heading = f'''# 静默猎手十项策略提案复核

记录时间：{stamp}（写入前已date）。任务strategy-proposal，角色silent，批次{dispatch['batch']}。
基线/本批HEAD：`{dispatch['base']}`。本批10项均waiting，无源码、知识、提交、合入或行为版本。

'''
parts=[heading,'只处理派发的10个原CLI ID。以下每项保存原证据、账本、已覆盖子项、反例、缺口、未来验证与回退，不新建重复ID，不把部分功能标成整项duplicate/implemented。\n\n']
for n,d in enumerate(dispositions,1):
    original=dispatch['proposals'][d['id']]
    parts.append(f"## {n}. {d['id']}\n\n原提案：{original['summary']}\n\n")
    parts.append(f"来源任务：{original['source_task']}；目标实现任务：strategy-proposal；原领域：{','.join(original['domains'])}。本批implementation_domains=[]。\n\n")
    parts.append(f"原Markdown：`{original['proposal']}`；SHA256=`{original['proposal_sha256']}`。已核指纹并保留原字节于`original-proposals/{d['id']}.md`。\n\n")
    parts.append(f"账本：{','.join(original['ledger'])}。状态：waiting。\n\n")
    for title,key in [('证据局/进阶/层/回合','evidence'),('核实事实','finding'),('既有源码及其覆盖边界','existing'),('反例与未知','counterexample'),('未实现原因','reason'),('保持的行为与证据补齐后的目标','expected'),('验证方法','validation')]:
        parts.append(f'- {title}：{d[key]}\n')
    parts.append('\n本批重新提取的原证据与原061302-s2选中封套一致；相关SL按同局处理，不增加独立样本数。本批不拟合参数，不拿败局反事实、候选预测或已有文字替代实证。将来实现按独立源码提交撤回，保留刷新数据、原日志、失败样本和账本；其他角色及未观察条件保持等价。\n\n')
(s/'proposal.md').write_text(''.join(parts))

report=[heading,'''本批结论：五局八流重新选中的6060行与原061302-s2批逐字节一致，派发范围内没有新增实盘证据。十项所需的完整执行归属、逐源资源链、复活逐击、合法后继或整战受控比较仍有明确缺口；保持现有策略，不造源码改动或重复提案。

## 身份与范围

开工git status为空。learn.json只读本批行：task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配，10个proposal_ids，无proposal_repair/research_request/implementation_request。普通专题文件绑定另一批次，本批不承接专题。核对后git merge --no-edit main返回Already up to date；HEAD完整基线不变。

已读README、最新STATE-2026-10-15、decision-log末尾、学习协议、代码提案闭环和学习要求闭环。独立完成，不派子agent。只读本角色五局、所属原提案与账本和相关源码；未扩展其他队列、专题、角色知识或全历史统计。原日志只读，无网络、模型、模拟或游戏调用，不运行play、不读凭据/二进制、不改运维prompt。

当前原生模型/推理参数没有独立读取核验；未切换模型或模式，不凭历史游戏run-config冒称当前会话配置已核，交原宿主核实。

## 原证据与可复核范围

共用extract_evidence.py执行完成，原stdout保存extraction.log；每流source_size独立冻结，每条保存source/line/offset/bytes/SHA/row。verify-evidence.py逐行seek原源，重新核SHA、JSON、边界及显式所属身份，支持run-plans.run、run_id/state.run_id/fingerprint.run，冲突身份拒收。完整结果见integrity.json。

''']
report.append('| 流 | 本次source_size | 选中行数 |\n|---|---:|---:|\n')
for x in manifest:report.append(f"| {x['stream']} | {x['source_size']} | {sum(x['counts'].values())} |\n")
report.append('\n八流选中封套SHA全部等于原061302-s2。原run-plans截点8380258另经共用入口、--streams run-plans --source-size复核，保存prior-run-plans-cutoff/，与本次30行选中SHA相同；没有覆盖旧产物。流增长不等于本批新增证据。fight-plans本截点0行只说明未选到，不断言日志不存在。整条流非法行计数不能归属本批，也不能由此补写内容。\n\n')
report.append('| 局号 | 角色/进阶 | 结束 | 原源码提交 |\n|---|---|---|---|\n')
identities=json.loads((s/'run-identities.json').read_text())
for run in dispatch['dispatch']['runs']:
    info=identities[run];old=next(x for x in history if x['run_id']==run)
    report.append(f"| {run} | SILENT/A{info['ascension']} | F{info['floor']} {'胜' if info['victory'] else '败'} | `{old['code']['commit']}` |\n")
report.append('''
ZE8 A5仅作现场抑制版本观察，四局A10审计与之分列，相关SL不当独立局。五局run-config均记录可定位的完整源码提交，dirty_files为知识JSON；历史刷新知识原字节及完整联合输入未复原，不能用当前树代历史实际运行输入。未重核原提案118/119/120局全史分母或药水历史准确率。

## 本批材料核验与原消费者读回

''')
report.append(f"本批{checks['passed']}项材料断言通过，逐项见evidence-checks.json。复核{len(consumer['artifacts'])}份原消费者输入/输出/stderr/退出码及资源链材料的已登记SHA。四份原离线输入由本次原帧重新构造后逐字相等，相关learner消费者源码SHA未变；没有重跑消费者或模拟。原rc0仅为历史离线工具执行结果，不冒报本批生产测试、自然采用或联合校准。\n\n")
report.append('| A10局号 | 原候选段 | 原动作 | 回合端点 | 未知回合 | 完整候选认证 |\n|---|---:|---:|---:|---:|---:|\n')
for x in consumer['summary']:
    report.append(f"| {x['run']} | {x['segments']} | {x['actions']} | {x['turns'].get('observed_turn_endpoints',0)} | {x['turns'].get('unknown',0)} | 0 |\n")
report.append('''
合计483候选段、2101动作，352回合窗中70已核端点/282未知，完整候选认证0。KFR一条、GX三条无decision_id原元数据仍保留，原消费者未重编号或跨这些行认证连续性。实际动作completed只证明接口回执，不能复制整条预测收益。原资源链84窗口包含重试和缺口，不当84独立战斗或完整损伤账。

关键原帧：

- KFR F33T6同盘15血/228敌/36毒/3覆甲，原线净扣83损6，SL替线净扣93损12；两线都未赢，不据局部10伤/6血差拟统一价格。F12原护栏完整候选在生成小刀后重问，原0损候选未完整执行，不把实际6损当预测误差。
- KFR F33末T7，手上技法7挡、防御后12挡，三手动名额满后奇巧爆发虽余1能量仍锁；毒药37→43且敌159当步不变，之后43+42=85，敌74未死。它支持已观察时点事实，不能证明另一目标、先后顺序或提前喝药能赢。
- GX F45T2同盘后3/13血、0/7带挡，保血线敌多8血；末13血/23挡/2覆甲对40需损15，-2与原least-loss和实死一致。净HP含复活，不能当未截断入伤；缺复活瞬时逐击和前三退出。
- GX F33已建触媒2才有29+28+27=84毒伤，末F45未打触媒不预支收益。四次SL摘要确有四普通键inserted和旧升级键离堆，但T2→T3同时有抽牌，纯改标瞬间/唯一物理身份/事件次序未见，不能据基ID守恒延长已知前缀。ZE8 A5现场普通牌与场外升级分账。
- MTQ跨幕19→59，KFR跨幕22→60，与休息、开场和SL恢复分别记录；未到节点与未取得牌不填可用资源。连续赢战仍消耗后战缓冲，不从观察路线推替路线必胜。

这些是限定或未知边界的再次核验，没有新反经验结论，不重复增加support/repeat。

## 当前源码覆盖

''')
report.append(f"source-audit.json冻结只读live引用`{sources['live_read_only']}`，不是本批merged。相关19叶中14叶逐字相同，5叶仅Roy/Dai历史注释归属词不同；保存source-live-differences.patch，未为比对改叶。8个既有源码提交均核base/live祖先。相对原061302-s2的15叶相同，另4叶为既有1698adc96的资源诊断补充，差分见prior-source-differences.patch。\n\n")
report.append('''奇巧事实仍continuation_verified=false；在线selection_audit仍actual_turn=null；新增SL资源比较提供rollout_saturated和预测资源差，但execution=unverified，不能补完整执行、瞬时帧或整战校准。限定毒药入口、HP净增边界、逐槽与回合离线工具均属已发布子项，不能将任一子项冒记整项duplicate/implemented。本批不复用旧生产检查绿、没有生产测试或新自然消费者声明。

## 十项处置

| 原CLI ID | 状态 | 具体缺口 |
|---|---|---|
''')
for d in dispositions:report.append(f"| {d['id']} | waiting | {d['reason']} |\n")
report.append('''
逐项证据局/层/回合、账本、反例、既有源码、预期行为、验证与回退见本批proposal.md，十份原文原字节另存。无新完整源码差额或足够证据的规则参数；全部waiting保留待新局，不关闭宽提案、量化父要求或学习入库要求。

## 交付和未执行项

源码撤除失败/恢复通过不适用；没有源码改动，不制造失败或通过。生产tests={tsc:null,vitest:null,cases:null}，未运行完整套件。本批只有材料核验，无源码提交，gitleaks提交前扫描不适用；merged=null、无发布号、无知识重建、无规则变更双通知。

账本仅经根ledger.py update追加24个所属条目的本批proposal/report路径及note；不新增claim/evidence，不改status/version/shipped，不把旧shipped改回proposed，不手改账本/提案队列/根请求。实际CLI结果与逐offset/bytes/SHA及fold读回另存ledger-receipt.json；未有回执前不宣称写入成功。最终工作树与HEAD另见final-validation.json。

过程边界：只读探针曾将silent-sl-resource-comparison.ts误写为silent-sl-resources.ts，sed报路径不存在后已按真实import修正；不当产品缺陷。初次显示截断不作缺证判断。所有提取/核验子进程nice19、无子agent、无后台生产测试或模拟。旧失败与未知保留，scratch不删除。

交付：本目录proposal.md、report.md和result.json。经验库沉淀和实际消费者采用未在本批完成，不宣称已入库、shipped或关闭父要求。
''')
(s/'report.md').write_text(''.join(report))
result={'task':'strategy-proposal','character':'silent','batch':dispatch['batch'],'base':dispatch['base'],
    'runs':dispatch['dispatch']['runs'],'fixes':[],
    'skipped':[{'id':d['id'],'reason':d['reason']} for d in dispositions],
    'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':ids,
    'implementation_domains':[],'proposal_results':[{'id':d['id'],'state':'waiting','reason':d['reason']} for d in dispositions],
    'report':str(s/'report.md')}
(s/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
ledger_ids=sorted({i for x in dispatch['proposals'].values() for i in x['ledger']})
updates=[]
for ident in ledger_ids:
    linked=[d['id'] for d in dispositions if ident in dispatch['proposals'][d['id']]['ledger']]
    updates.append({'id':ident,'by':'learner:strategy-proposal','where':{'proposal':[str(s/'proposal.md'),str(s/'report.md')]},
       'note':dispatch['batch']+'：本批6060原行逐字节/身份回核、31材料检查与原20份离线材料SHA读回；十项均waiting，无源码/知识/提交/合入/版本，生产tests=null。仅追加'+','.join(linked)+'追溯，不新增support/repeat，不改旧claim/首证/prior/evidence/status/version或关闭宽父；具体缺口见本批报告。'})
(s/'ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
print(json.dumps({'time':stamp,'proposals':len(ids),'waiting':len(dispositions),'ledger_links_prepared':len(updates),'report':str(s/'report.md')},ensure_ascii=False))

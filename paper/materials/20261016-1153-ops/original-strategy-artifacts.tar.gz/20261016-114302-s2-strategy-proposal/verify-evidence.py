import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
prior = root / '.worktrees/codex-strategy-silent-20261016-061302-s2/learner/runs/20261016-061312-75aa99f7-7591-4dc3-92bb-76a83a3b598b-strategy-proposal'
dispatch = json.loads((scratch / 'dispatch.json').read_text())
runs = dispatch['dispatch']['runs']
spec = importlib.util.spec_from_file_location('extract', workspace / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((scratch / 'evidence/evidence-manifest.json').read_text())
prior_manifest = {x['stream']: x for x in json.loads((prior / 'evidence/evidence-manifest.json').read_text())}
stream_rows = {}
integrity = []
for stream in manifest:
    name = stream['stream']
    path = scratch / 'evidence' / (name + '.evidence.jsonl')
    counts = collections.Counter()
    rows = []
    with (root / 'logs' / (name + '.jsonl')).open('rb') as source:
        for raw in path.open('rb'):
            item = json.loads(raw)
            source.seek(item['offset'])
            original = source.read(item['bytes'])
            assert hashlib.sha256(original).hexdigest() == item['sha256']
            assert json.loads(original) == item['row']
            assert item['offset'] + item['bytes'] <= stream['source_size']
            assert extract.run_identity(item['row']) == item['run_id'] in runs
            counts[item['run_id']] += 1
            rows.append(item)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == stream['output_sha256']
    assert all(counts[r] == stream['counts'][r] for r in runs)
    same = digest == prior_manifest[name]['output_sha256']
    integrity.append({'stream': name, 'verified_rows': len(rows), 'source_size': stream['source_size'],
                      'counts': dict(counts), 'sha256': digest, 'same_selected_bytes_as_prior': same,
                      'prior_source_size': prior_manifest[name]['source_size']})
    stream_rows[name] = rows
assert all(x['same_selected_bytes_as_prior'] for x in integrity)
(scratch / 'integrity.json').write_text(json.dumps(integrity, ensure_ascii=False, indent=2) + '\n')

states = {x['line']: x for x in stream_rows['states']}
decisions = {x['line']: x for x in stream_rows['decisions']}
sl = {x['line']: x for x in stream_rows['sl-attempts']}
run_info = {x['run_id']: x['row'] for x in stream_rows['runs']}
assert set(run_info) == set(runs)
assert all(x['character'].lower() == 'silent' for x in run_info.values())
assert run_info['ZE8F192FKX24']['ascension'] == 5
assert all(run_info[r]['ascension'] == 10 for r in runs if r != 'ZE8F192FKX24')
(scratch / 'run-identities.json').write_text(json.dumps(run_info, ensure_ascii=False, indent=2) + '\n')

checks = []
def check(name, passed, evidence):
    checks.append({'name': name, 'passed': bool(passed), 'evidence': evidence})
    assert passed, name
def st(line): return states[line]['row']['state']
def hp(line): return st(line)['run']['current_hp']
def pl(line): return st(line)['combat']['player']
def en(line, i=0): return st(line)['combat']['enemies'][i]
def power(holder, ident): return next((x['amount'] for x in holder.get('powers', []) if x['power_id'] == ident), 0)

for line in (289339, 289414):
    check('KFR T6同盘15血/228敌/36毒/3覆甲',
          (hp(line), en(line)['current_hp'], power(en(line), 'POISON_POWER'), power(pl(line), 'PLATING_POWER')) == (15,228,36,3), [line])
check('KFR原线净扣83/损6', hp(289339)-hp(289345) == 6 and en(289339)['current_hp']-en(289345)['current_hp'] == 83, [289339,289345])
check('KFR替线净扣93/损12', hp(289414)-hp(289420) == 12 and en(289414)['current_hp']-en(289420)['current_hp'] == 93, [289414,289420])
check('奇巧选择时7挡/已出1牌', pl(289533)['block'] == 7 and pl(289533)['cards_played_this_turn'] == 1, [289533])
check('防御后12挡/已出2牌', pl(289535)['block'] == 12 and pl(289535)['cards_played_this_turn'] == 2, [289535])
check('三牌额度已满且1能量爆发被懒惰锁住', pl(289536)['energy'] == 1 and pl(289536)['cards_played_this_turn'] == 3 and
      st(289536)['combat']['hand'][0]['unplayable_preventer_id'] == 'SLOTH_POWER', [289536])
check('毒药37到43/当步敌HP159不变', power(en(289536),'POISON_POWER') == 37 and power(en(289537),'POISON_POWER') == 43 and
      en(289536)['current_hp'] == en(289537)['current_hp'] == 159, [289536,289537])
check('触媒两结85后敌74未死', en(289537)['current_hp']-en(289538)['current_hp'] == 43+42 and en(289538)['current_hp'] == 74, [289537,289538])
check('KFR末扣血以0截断', (hp(289537),hp(289538)) == (9,0), [289537,289538])
for line in (290160,290201):
    check('GX T2同盘2血/敌84,84,77', hp(line) == 2 and [en(line,i)['current_hp'] for i in range(3)] == [84,84,77], [line])
check('GX复活后3/13HP和0/7挡', (hp(290165),pl(290165)['block'],hp(290206),pl(290206)['block']) == (3,0,13,7), [290165,290206])
check('GX保血线敌多8HP', en(290206)['current_hp']-en(290165)['current_hp'] == 8, [290165,290206])
check('GX末13HP/23挡/2覆甲', (hp(290213),pl(290213)['block'],power(pl(290213),'PLATING_POWER')) == (13,23,2), [290213])
check('GX末HP0且未建立触媒', hp(290214) == 0 and power(pl(290213),'ACCELERANT_POWER') == 0, [290213,290214])
check('GX已建触媒2才结29+28+27', power(pl(289986),'ACCELERANT_POWER') == 2 and
      en(289986)['current_hp']-en(289987)['current_hp'] == 84 and power(en(289987),'POISON_POWER') == 26, [289986,289987])
for line in (223268,223272,290165,290206):
    check('抑制现场已建立', power(pl(line),'DAMPEN_POWER') == 1, [line])
for line in (1053,1054,1055,1056):
    draws = sl[line]['row']['draws']
    check('SL四普通键inserted且clean仍18或19', set(draws['inserted'][0]['cards']) ==
          {'BLADE_DANCE','OUTBREAK','SUCKER_PUNCH','ACCELERANT'} and draws['clean'] in (18,19), ['sl-attempts:'+str(line)])
check('MTQ跨幕19到59', (hp(288726),hp(288727)) == (19,59), [288726,288727])
check('KFR跨幕22到60', (hp(289149),hp(289150)) == (22,60), [289149,289150])

old_artifacts = {x['path']:x for x in json.loads((prior/'artifact-manifest.json').read_text())}
reused = []
def verify_prior(name):
    data = (prior/name).read_bytes()
    expected = old_artifacts[name]
    assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    reused.append({'path':str(prior/name),'bytes':len(data),'sha256':expected['sha256']})
    return data
verify_prior('audit-exit-codes.txt')
consumer_summary = []
for run in runs:
    if run_info[run]['ascension'] != 10: continue
    ds = [{**x['row'],'_line':x['line'],'_source_sha256':x['sha256']} for x in stream_rows['decisions']
          if x['run_id']==run and x['row'].get('decision_id')]
    ss = [{**x['row'],'_line':x['line'],'_source_sha256':x['sha256']} for x in stream_rows['states'] if x['run_id']==run]
    payload = (json.dumps({'run':run_info[run],'decisions':ds,'states':ss},ensure_ascii=False)+'\n').encode()
    old_input = verify_prior('audit-input-'+run+'.json')
    assert payload == old_input
    report = json.loads(verify_prior('audit-output-'+run+'.json'))
    verify_prior('audit-stderr-'+run+'.txt')
    check('旧离线消费者未认证完整候选 '+run, all(x['actual_full_candidate_result'] is None for x in report['segments']), ['prior/audit-output-'+run+'.json'])
    consumer_summary.append({'run':run,'input_matches_current_raw':True,'segments':len(report['segments']),
        'actions':len(report['observed_actions']),'certified_full_candidates':0,
        'turns':dict(collections.Counter(x['status'] for x in report['observed_turns'])),
        'replayed_this_batch':False})
for run in runs:
    verify_prior('resource-chain-'+run+'.json')
verify_prior('resource-summary.json')
verify_prior('audit-summary.json')
(scratch/'prior-consumer-receipt.json').write_text(json.dumps({'scope':'原离线输入输出SHA复核，本批未重跑消费者或模拟',
    'source_modules_unchanged':[x['path'] for x in json.loads((scratch/'source-audit.json').read_text())['files']
                                if x['path'].startswith('learner/') and x['same_as_prior_base']],
    'artifacts':reused,'summary':consumer_summary,'exit_codes':(prior/'audit-exit-codes.txt').read_text()},ensure_ascii=False,indent=2)+'\n')
(scratch/'evidence-checks.json').write_text(json.dumps({'scope':'材料一致性检查，非生产测试或收益证明',
    'passed':len(checks),'failed':0,'checks':checks},ensure_ascii=False,indent=2)+'\n')
anchors = sorted({x for c in checks for x in c['evidence'] if isinstance(x,int)})
(scratch/'selected-states.json').write_text(json.dumps({str(n):states[n] for n in anchors},ensure_ascii=False,indent=2)+'\n')
selected_decisions = [x for n,x in decisions.items() if n in {218927,218928,282434,282578,282579,282864,282899,282929,282933,282968,283001,283035,283641,283680,283690,283691}]
(scratch/'selected-decisions.json').write_text(json.dumps(selected_decisions,ensure_ascii=False,indent=2)+'\n')
historical = []
for x in stream_rows['run-config']:
    code=x['row']['code']
    commit=subprocess.check_output(['git','rev-parse',code['commit']+'^{commit}'],text=True).strip()
    assert commit==code['commit']
    historical.append({'run_id':x['run_id'],'code':code,'source_line':x['line'],
                       'only_knowledge_dirty':all(p.startswith('knowledge/') and p.endswith('.json') for p in code.get('dirty_files',[]))})
(scratch/'historical-source-limits.json').write_text(json.dumps(historical,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verified_rows':sum(x['verified_rows'] for x in integrity),'same_eight_selected_streams_as_prior':True,
    'material_checks':len(checks),'prior_consumer_artifacts_verified':len(reused),'consumer_summary':consumer_summary},ensure_ascii=False))

import copy
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
s = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
path = root / 'paper/materials/learning/ledger.jsonl'
updates = [json.loads(raw) for raw in (s / 'ledger-updates.jsonl').read_text().splitlines()]
ids = {row['id'] for row in updates}
assert len(ids) == len(updates) == 24
assert all(set(row) == {'id','by','where','note'} and row['by'] == 'learner:strategy-proposal' for row in updates)
spec = importlib.util.spec_from_file_location('ledger', root / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)

def snapshot():
    items = {}
    with path.open('rb') as handle:
        fcntl.flock(handle, fcntl.LOCK_SH)
        raw = handle.read()
    for line in raw.splitlines():
        row = json.loads(line)
        if row.get('id') in ids:
            ledger.apply(items, row)
    assert set(items) == ids
    return raw, items

before, before_fold = snapshot()
(s / 'ledger-before-fold.json').write_text(json.dumps(before_fold,ensure_ascii=False,indent=2)+'\n')
baseline = {'source':str(path),'source_size':len(before),'sha256':hashlib.sha256(before).hexdigest()}
(s / 'ledger-before-source.json').write_text(json.dumps(baseline,indent=2)+'\n')
process = subprocess.run([sys.executable,str(root/'learner/ledger.py'),'update'],
    input=(s/'ledger-updates.jsonl').read_bytes(),capture_output=True,
    env={**os.environ,'TMPDIR':str(s),'PYTHONDONTWRITEBYTECODE':'1'})
(s/'ledger-cli.stdout.txt').write_bytes(process.stdout)
(s/'ledger-cli.stderr.txt').write_bytes(process.stderr)
(s/'ledger-cli.rc.txt').write_text(str(process.returncode)+'\n')
assert process.returncode == 0, 'ledger CLI failed; preserve original failure and do not claim links'
assert set(process.stdout.decode().split()) == ids
after, after_fold = snapshot()
assert after.startswith(before)
appended = []
offset = len(before)
for raw in after[len(before):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('id') in ids and row.get('by')=='learner:strategy-proposal' and row.get('note','').startswith('20261016-114302-s2-strategy-proposal：'):
        expected = next(x for x in updates if x['id'] == row['id'])
        assert {k:row[k] for k in expected} == expected
        assert set(row) == set(expected) | {'op','ts'} and row['op']=='update'
        appended.append({'id':row['id'],'offset':offset,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                         'ts':row['ts'],'by':row['by'],'only_where_note':True})
    offset += len(raw)
assert len(appended)==24 and {x['id'] for x in appended}==ids
governance = ['claim','first_run','prior','status','version','shipped_at']
comparisons = {i:{'governance_unchanged':all(before_fold[i].get(k)==after_fold[i].get(k) for k in governance),
    'old_evidence_prefix':after_fold[i]['evidence'][:len(before_fold[i]['evidence'])]==before_fold[i]['evidence'],
    'old_history_prefix':after_fold[i]['history'][:len(before_fold[i]['history'])]==before_fold[i]['history'],
    'old_notes_prefix':after_fold[i]['notes'][:len(before_fold[i]['notes'])]==before_fold[i]['notes'],
    'proposal_and_report_linked':all(link in after_fold[i]['where']['proposal'] for link in updates[0]['where']['proposal'])}
    for i in ids}
assert all(all(v.values()) for v in comparisons.values())
(s/'ledger-after-fold.json').write_text(json.dumps(after_fold,ensure_ascii=False,indent=2)+'\n')
receipt = {'cli':str(root/'learner/ledger.py'),'rc':process.returncode,'before':baseline,
    'after_source_size':len(after),'physical_prefix_preserved':True,'owned_updates':appended,
    'fold_readback':comparisons,'new_claims':0,'new_evidence':0,'status_changes':0,'shipped_changes':0}
(s/'ledger-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'rc':0,'owned_updates':len(appended),'old_fields_and_prefixes_preserved':True},ensure_ascii=False))

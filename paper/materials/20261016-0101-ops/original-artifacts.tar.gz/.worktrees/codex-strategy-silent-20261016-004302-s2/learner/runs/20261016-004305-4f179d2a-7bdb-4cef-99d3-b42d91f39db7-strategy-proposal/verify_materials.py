import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('evidence_extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verified = []
for stream in manifest:
    name = stream['stream']
    counts = Counter()
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    with path.open('rb') as handle, (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
        for encoded in handle:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert raw.endswith(b'\n') and json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id']
            counts[item['run_id']] += 1
    assert digest.hexdigest() == stream['output_sha256']
    assert all(counts[run] == count for run, count in stream['counts'].items())
    verified.append({'stream': name, 'verified_rows': sum(counts.values()), 'output_sha256': digest.hexdigest()})
(OUT / 'evidence-byte-verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')

states = {}
with (OUT / 'states-compact.jsonl').open() as handle:
    for raw in handle:
        value = json.loads(raw)
        states[value['line']] = value
checks = []


def equal(label, actual, expected, lines=()):
    assert actual == expected, (label, actual, expected)
    checks.append({'label': label, 'actual': actual, 'expected': expected,
                   'state_refs': [{k: states[line][k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}
                                  for line in lines]})


equal('RC F23 T3 temporary dexterity after Anticipate', states[285223]['powers']['DEXTERITY_POWER'], 1, [285222, 285223])
equal('RC F23 T3 Speed adds five', states[285224]['powers']['DEXTERITY_POWER'], 6, [285223, 285224])
equal('RC F23 T3 card blocks and passive block stay separate', [states[n]['block'] for n in (285225, 285227, 285229)], [12, 21, 25], [285224, 285225, 285227, 285229])
equal('RC F23 T3 Tender changes dexterity after each card', [states[n]['powers']['DEXTERITY_POWER'] for n in (285225, 285226, 285227, 285228, 285229)], [5, 4, 3, 2, 1], [285225, 285226, 285227, 285228, 285229])
equal('RC F33 T4 only remaining Strike leaves after Survivor', [c['id'] for c in states[285414]['hand']], ['SURVIVOR', 'STRIKE_SILENT'], [285414])
equal('RC F33 T4 no subsequent Strike remains', states[285415]['hand'], [], [285415])
equal('B F31 T2 forced discard removes Sucker Punch', [c['id'] for c in states[286161]['hand']], ['SURVIVOR', 'SUCKER_PUNCH'], [286161])
equal('B F31 T2 hand is empty after Survivor', states[286162]['hand'], [], [286162])
equal('B F31 T2 actual HP loss', states[286158]['hp'] - states[286163]['hp'], 14, [286158, 286163])
equal('X F48 T8 poison victory still pays nine HP', [states[286893]['hp'], states[286894]['hp']], [32, 23], [286893, 286894])
equal('X F49 entry inherits actual HP', states[286896]['hp'], 23, [286894, 286896])
equal('X F49 T1 ghost adds one layer', states[286898]['powers']['INTANGIBLE_POWER'], 1, [286897, 286898])
equal('X F49 T1 attack reference changes on drink', [states[n]['enemies'][0]['intents'][0]['total_damage'] for n in (286897, 286898)], [26, 1], [286897, 286898])
equal('X F49 T2 retains ten block and all HP', [states[286899]['hp'], states[286899]['block']], [23, 10], [286899])
equal('X F49 T4 copies exist before fatal turn', states[286986]['powers']['NIGHTMARE_POWER'], 3, [286986])
equal('X F49 T4 still has one HP and six block into sixteen', [states[286986]['hp'], states[286986]['block'], states[286986]['enemies'][0]['intents'][0]['total_damage']], [1, 6, 16], [286986])
equal('X F49 no next-turn copied hand is observed', [states[286987]['screen'], states[286987]['hp']], ['GAME_OVER', 0], [286987])
equal('9Z F48 T8 block is thirty-two before HP hits zero', states[287989]['block'], 32, [287989])
equal('9Z F48 T8 zero HP and revival cannot be replaced with net healing', [states[n]['hp'] for n in (287989, 287990, 287991)], [11, 0, 20], [287989, 287990, 287991])
equal('9Z F48 T10 only first card gets doubled preview', [states[n]['block'] for n in (288000, 288003, 288004)], [18, 27, 37], [288000, 288003, 288004])
equal('9Z F48 T10 actual net loss remains fifteen', [states[287998]['hp'], states[288005]['hp']], [18, 3], [287998, 288005])
equal('7X F31 T13 poison potion adds observed total seven', [states[n]['enemies'][2]['powers'].get('POISON_POWER', 0) for n in (288470, 288471)], [0, 7], [288470, 288471])
equal('7X F31 drink does not cause immediate HP damage', [states[n]['enemies'][2]['hp'] for n in (288470, 288471)], [25, 25], [288470, 288471])
equal('7X F31 terminal back HP is eighteen', states[288472]['enemies'][2]['hp'], 18, [288472])
equal('7X F31 player still dies after drink', [states[288471]['hp'], states[288472]['hp']], [1, 0], [288471, 288472])
equal('MTQ F23 baseline T3 five temporary dexterity', states[288808]['powers']['DEXTERITY_POWER'], 5, [288808])
equal('MTQ F23 original T3 net loss zero', [states[288806]['hp'], states[288812]['hp']], [10, 10], [288806, 288812])
equal('MTQ F23 changed T3 net loss eight', [states[288899]['hp'], states[288905]['hp']], [10, 2], [288899, 288905])
equal('MTQ F23 T5 terminal is capped HP rather than raw incoming', [states[288914]['hp'], states[288915]['hp']], [2, 0], [288914, 288915])
transitions = json.loads((OUT / 'act-transitions.json').read_text())
equal('all twenty-two observed same-max act transitions match the existing observation', [len(transitions), sum(t['matches'] for t in transitions)], [22, 22])
equal('A9 and A10 transition pairs remain separated', dict(Counter(t['ascension'] for t in transitions)), {9: 5, 10: 17})

mtq = json.loads((OUT / 'consumer/MTQ0EUBJ3R6T.audit.json').read_text())
guard = next(s for s in mtq['segments'] if s['source_line'] == 282138)
sl = next(s for s in mtq['segments'] if s['source_line'] == 282434)
for label, segment, expected in (
    ('MTQ F11 original and guarded forecasts', guard, ['plan6', 14, 14, 'plan1', 6, 16]),
    ('MTQ F23 original and SL forecasts', sl, ['plan1', 0, 13, 'plan4', 8, 19]),
):
    p = segment['predictions']; a, b = p['answer'], p['final_candidate']
    equal(label, [a['key'], a['facts']['hp_lost'], a['facts']['damage_dealt'], b['key'], b['facts']['hp_lost'], b['facts']['damage_dealt']], expected)
    equal(label + ' is comparable only within its logged question', [p['comparison_reason'], p['predicted_final_rollout_best']], ['same_question_unique_candidate', False])
    equal(label + ' does not certify the full candidate', segment['actual_full_candidate_result'], None)
equal('MTQ F11 discard and re-question supersede the guarded forecast', guard['boundary']['kind'], 'superseded_by_question')
equal('MTQ F23 SL is fourth related attempt', sl['attempt'], 4)
for path in sorted((OUT / 'consumer').glob('*.audit.json')):
    value = json.loads(path.read_text())
    equal(path.stem + ' keeps actual candidate attribution unknown', all(s['actual_full_candidate_result'] is None for s in value['segments']), True)

(OUT / 'material-checks.json').write_text(json.dumps({'kind': 'fixed_evidence_assertions_not_production_tests', 'count': len(checks), 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source_rows_verified': sum(r['verified_rows'] for r in verified), 'material_checks': len(checks), 'production_tests_run': False}, ensure_ascii=False))

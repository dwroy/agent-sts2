import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = '81275beb0c0a003d276bbda527280caee48291e8'
BATCH = '20261016-004302-s2-strategy-proposal'
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'proposals-current.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
timestamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
print(timestamp)

details = [
    {
        'title': '牌挡、柔嫩、临时敏捷和被动挡的联合兑现',
        'evidence': 'RC61MFQM63Y6 A10 F23T3，states 285222—285229：预判后净敏1，速度后6；斗篷实12挡、刺击后敏4、防御实9挡，第三次攻击后的被动4挡另计，总25。F33T4第三试生存者后手空；该局末轮脆弱两防御只有6挡。账本 silent-0006/0011/0013/0080/0088/0101/0232/0253。',
        'existing': 'card-model、turn-solver、rollout 已分别有 survivorDiscard、phantomBlades、tender、ornamentalFan 等窄模型；源码存在不等于这些来源及组合全部正确。',
        'reason': '局部敏捷、柔嫩和折扇实帧成立；仍缺柔嫩与脆弱/倍率等联合修正的逐牌完整消费者校准，以及幻影/持续毒的后轮兑现对照，不能把多个窄模型合称八条提案全部实现。',
        'counterexample': '首刀14伤仅限已建立9层幻影的观察窗口；末蟹未建立幻影/毒雾。伤害或挡的局部成立没有阻止末战失败，不支持统一启动优先级。',
        'next': '冻结实际修正项及逐牌状态，分源核每一张牌和后轮收益；未知联合条件继续标未知，不添加新顺序/权重。',
    },
    {
        'title': '夜魇的存活条件与罐装幽灵',
        'evidence': 'XTSV1U9JD34T A10 F49：decisions 280550、280631、280635—280639；states 286897—286899、286986—286987。幽灵新增无实体1，攻击26→1，16挡覆盖并保留23HP；次轮钳子留10。末T4只1HP/6挡对16，夜魇3层后立即GAME_OVER，未到三张复制手牌。账本 silent-0140/0069/0005/0206。',
        'existing': 'combat-plan 提供 Silent A10 无既存无实体层时 observedGhostInAJar，card-model 建模一层；该分支保留药水选项且不以此自动喝药。',
        'reason': '单层幽灵已有窄实现；夜魇次轮复制的到手、合法费用和实际施放尚缺该绝境完整替代线校准，六次同局早喝也没有延后饮用的受控后继，不能关闭整个存活/时点提案。',
        'counterexample': '所有已执行T4路径仍死；去掉夜魇未证可活。幽灵T1确已兑现零损，不能由败局推出早喝无价值或必须晚喝。',
        'next': '分别检验一层效果、复制到手和后继合法动作；得到延后饮用完整实线前保留原时点、药价与规则。',
    },
    {
        'title': '弃牌重核、毒胜保血与接管首轮',
        'evidence': 'BTSRF7JL1W1Y A10 F31T2，decision 279846 预计损4；states 286161→286162 生存者弃唯一突然一拳，286158→286163实际35→21。XTSV1U9JD34T F48T8，decision 280547 空斩杀结束；286893→286894为32→23，286896带23入F49。涉及 silent-0205/0268/0271/0164/0140 等原11账本。',
        'existing': 'turn-solver 独立消费普通 survivorDiscard；preservePoisonWinHp 在观察的连王第一战继续搜索有HP可保的毒胜候选，combat-plan 按 continuation 接线。耳环的首轮接管事实也已有窄接线。',
        'reason': '普通生存者弃牌与毒胜搜索已有窄修复；整项还包含实际弃牌重问、复制后继、同族/女王目标及耳环首轮兑现，缺原接管动作序列和联合完整候选认证，不能用两个窄修复关闭原整项。',
        'counterexample': 'B同族第四试胜但抽序/后轮同时改变，不能归为固定击杀序。X首王保血差额不证明第二王可赢；耳环接管后的手牌不证明主动启动顺序。',
        'next': '对实际选择后手牌重新取题；连王只用实到HP；接管与自主动作分别核验，缺完整后继时不改目标优先或SL门槛。',
    },
    {
        'title': '胜战血药成本与连王实到资源',
        'evidence': 'BTSRF7JL1W1Y A10 F30赢战70→42并用明晰，F31以42及液态记忆进入，F32未到。XTSV1U9JD34T F48赢战97→23，F49原帧286896实到23；F48T8凋萎另耗9。账本 silent-0019/0020；原复盘及本批跨幕表/消费者输入均保留。',
        'existing': '路线投影、连王 continuation 与实际状态输入已存在；它们是条件估计，不是未来营火已兑现的记账。',
        'reason': '赢战消耗、真实回复与SL恢复可区分；缺相同条件的改线/留药/锻造完整后继和独立时间留出校准，不能由两局相关资源链拟合新的安全血线或机会成本。',
        'counterexample': 'F48是获胜但净耗74HP，反驳只记败战成本；未抵达F32不能记回血。未来路线预测条件随牌/药变化，不能当同条件算法误差。',
        'next': '按实到节点与实际槽位接续；拟合另需独立对局及样本条件，不更改当前房间代价的五样本门槛。',
    },
    {
        'title': '临时减力、覆甲、留挡与持续毒的分源',
        'evidence': 'BTSRF7JL1W1Y F31T2/T4：实际覆甲与13牌挡共同抵扣多敌威胁；XTSV1U9JD34T F49T1幽灵后留10挡、T2结束仅留5，末T3仍损22；末T4尖啸后现场16攻对6挡仍死。账本为原12项，含 silent-0005/0016/0046/0069/0095/0128/0196/0241。',
        'existing': '临时减力、留挡、无实体与毒已分别建模；普通生存者与幽灵窄修复不能替代完整时序验收。',
        'reason': '已有局部效果和窄实现，但缺覆甲/留挡/临时属性撤回/毒触发/敌成长共同存在时的逐源完整回放与可比后继，不能从端点净差推出统一联合模型或新药价。',
        'counterexample': '钳子是最多留10而非每轮保底10；末女王未继承前战能力。中毒尚存不是已结伤害，临减到期不能当冻结成长。',
        'next': '逐源核结束时点、临时撤回及下一轮实际挡；无法归属的毛伤保留未知，不倒补固定挡或停攻收益。',
    },
    {
        'title': '倍率挡、复活与SL预测/实差',
        'evidence': '9Z9H2EXKLF3T A10 F48：末T8 states 287989—287991为32挡、HP11→0→20；T10 states 288000/288003/288004挡18→27→37，288005只余3HP。T7第二/三试完整轮端点经既有消费者分别20→9、20→11，敌393→344、393→322。账本为原13项，含 silent-0077/0123/0180/0129/0221。',
        'existing': '士兵首次消费、暗影、持牌伤与荆棘已有局部模型；selection-turn 保留复活状态路径及重问，不把净回复当零成本。',
        'reason': 'T7预测多损7/多伤16，与实际整轮省2血/多扣22不同且包含多次重问；缺逐击毛伤、各候选实际兑现和同条件整战后继，不能据此调整SL血价或宣称全组合已校准。',
        'counterexample': 'T8经历0HP与复活，净HP增加不是没有受伤；T10三张挡37仍损15。死亡后未执行攻击不能预支反伤，三次失败不能证明必死。',
        'next': '保留原/替预测与实际轮窗三份材料，毛伤及候选因果继续未知；规则变更要有独立留出支持。',
    },
    {
        'title': '跨幕回复与其他资源来源',
        'evidence': '本批15局角色核验后，得到A9五对、A10十七对共22个同最大HP跨幕转换，22/22符合已有⌊缺失HP×80%⌋观察。9Z9H2EXKLF3T F17→18为24/70→60/70，F33→34为23/77→66/77；F35最大HP77→69与当前HP66→30另记。账本 silent-0019/0020/0243。',
        'existing': 'silent-act-transition-missing-hp-heal 知识条目与现有路线/结构输入存在；本批没有重建历史116局统计，也没有重新发布知识。',
        'reason': '22个端点支持已有A9/A10回复观察，但不提供原116局完整资源模型重校准、低阶或未知遗物交互、改线/营火选择的受控收益，不能关闭包含整条路线/SL资源接续的宽提案。',
        'counterexample': '9Z末战前两次火实际只到7和27HP，F49未到；原F34投影使用77上限，后续上限变化，不能作为同条件残差。SL复药不是新获得。',
        'next': '继续保持A9/A10与各回复来源分账；有新独立完整资源链再重校准，不用本批22对冒称全部历史已验。',
    },
    {
        'title': '头骨组合毒药水的局部总增量',
        'evidence': '7X0W3U8TVA2A A10 F31T13，decision 282021用槽0朝后段index2；states 288470→288471后段毒0→7、HP25不变，288472后段HP18、玩家0。前段同时结旧8毒，中段发生重接回复；不能把所有敌HP变化当7毒效果。账本 silent-0087/0020。',
        'existing': 'observedDemonPoison 严格限制另一完整修正组合并返回6；doubleBoss 的 observedPoison 仅48/49上下文，均不覆盖本局千足虫头骨组合。未知持有值和实零值原有来源字段可区分。',
        'reason': '单次已饮证据确证该后段目标加7总毒；仍缺同完整修正组合下各目标、既有毒/重接及药牌共同推演的可比校准，也无早喝/留药后继与持有价样本，不能把7推广到所有持头骨输入或拟合用药阈值。',
        'counterexample': '实加7仍死亡；不能额外再加一次头骨，也不能把另一上下文的6搬来当本局已覆盖。其他目标/已有毒/制品等组合未由这次饮用验证。',
        'next': '保留该目标的7总量作为冻结校准材料，扩范围前补逐目标同条件后继；未知组合继续原未模拟选项，不删选项、不新设早喝/药价规则。',
    },
    {
        'title': '死亡率饱和时的SL血价',
        'evidence': 'MTQ0EUBJ3R6T A10 F23T3，decision 282434：原plan1预测损0/伤13，SL plan4预测损8/伤19；states 288806→288812原试10→10，288899→288905末试10→2，敌同61/41起盘仅后段差6。T5末288914→288915为2→0，-11是预计剩HP而非损血11，按原追加勘误。账本 silent-0079/0019/0044/0080/0253/0011/0214/0189/0046/0222/0243/0262。',
        'existing': 'silentSlComparison、selection-audit 和离线轮窗分别保存候选预测及真实端点；原SL探索排序和必死判官独立。',
        'reason': '同盘局部血价可核，但四次SL是一个相关样本，原线亦无已证整战胜利且改线改变后轮抽牌/能力；缺独立A10留出和完整反事实，不能拟合饱和探索的新HP门槛或权重。',
        'counterexample': '原线首试也到T6判死；末试T5死不能单归打击收益。两异螨同类型跨帧身份不自动认证，摘要block4与已落盘block0差异仍保留。',
        'next': '等待独立同角色A10数据，以实到资源和完整后继比较探索；继续记录预测/端点，不把24/24败样本当实盘必死。',
    },
    {
        'title': 'Jev原选、护栏/SL实线与可比推演记录',
        'state': 'duplicate',
        'commit': 'cf72bd21148059f111f760cc98a727369e34a47e',
        'evidence': 'MTQ0EUBJ3R6T A10 F11T1 decision 282138，原plan6损14/伤14、护栏plan1损6/伤16；当前离线消费者从原字节恢复同题唯一匹配与 predicted_final_rollout_best=false。F23T3 282434同时恢复原plan1与SL plan4的0/13和8/19。账本 silent-0125。',
        'existing': '实际live祖先源码cf72bd21148059f111f760cc98a727369e34a47e包含与当前逐字节相同的guard、SL comparison、selection-audit、dispatch及离线selection-execution/observation六叶。生产combat-plan按Silent A10记录answer/before_sl/after_sl，hand/loop记录单动作回执；原rollout_best_chosen含义保留。',
        'reason': '原提案限定的记录功能已有live实现：原选/最终候选及HP、伤害、毒/持续效果候选资料分列，同题唯一且有排名才填可比结果，其他情况null并附原因；原始MTQ两窗口读回符合。登记duplicate仅指记录范围，未宣称护栏/SL参数或完整候选因果已经验证。',
        'counterexample': 'F11第一次动作是pending回执，实际进入弃牌并重问；离线工具以superseded_by_question截断，actual_full_candidate_result仍null。整轮实损6/净扣20不能倒灌到原plan1伤16预测。',
        'next': '复用既有记录链，不重复改代码；实际完整候选收益及其他宽父继续等待证据。若记录实现未来退回，仅逆向记录字段与消费者，不撤护栏或改游戏规则。',
    },
]
assert len(details) == len(proposals) == 10
results = []
sections = []
for p, d in zip(proposals, details):
    state = d.get('state', 'waiting')
    result = {'id': p['id'], 'state': state, 'reason': d['reason']}
    if d.get('commit'):
        result['commit'] = d['commit']
    results.append(result)
    sections.append('\n'.join([
        '## ' + p['id'] + ' — ' + d['title'], '',
        '处置：' + state + ('；实际live祖先源码 `' + d['commit'] + '`。' if d.get('commit') else '。'), '',
        '原提案：`' + p['proposal'] + '`；SHA256 `' + p['proposal_sha256'] + '`。',
        '关联账本：' + '、'.join(p['ledger']) + '。', '',
        '证据：' + d['evidence'], '',
        '现有行为：' + d['existing'], '',
        '结论与缺口：' + d['reason'], '',
        '反例与限制：' + d['counterexample'], '',
        '预期行为与验证：' + d['next'], '',
        '本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。'
    ]))

proposal_text = '\n'.join([
    '# 静默猎手本批十项派发提案核验', '',
    '时间：' + timestamp + '；批次：' + BATCH + '。',
    '基线：`' + BASE + '`；普通提案队列，未绑定research_request或implementation_request。',
    '只处理dispatch.json中十个原id，不领取其他提案，不新建重复id。完整角色核验、逐行原字节和现有实现追溯见report.md及其列出的材料。', '',
    '本批结果为9项waiting、1项记录功能duplicate；未改源码或知识，未新增上线、版本或测试成功。'
]) + '\n\n' + '\n\n'.join(sections) + '\n'
(OUT / 'proposal.md').write_text(proposal_text)
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
consumer = json.loads((OUT / 'consumer/summary.json').read_text())
stream_table = ['| 流 | 本批所属行 | 冻结source_size（字节） |', '|---|---:|---:|']
stream_table.extend('| ' + r['stream'] + ' | ' + str(sum(r['counts'].values())) + ' | ' + str(r['source_size']) + ' |' for r in manifest)
consumer_table = ['| 局号 | 候选段 | 轮窗 | 已观察轮端点 | 已观察动作区间 | 未知动作区间 |', '|---|---:|---:|---:|---:|---:|']
consumer_table.extend('| {run_id} | {segments} | {turn_windows} | {observed_turns} | {observed_actions} | {unknown_action_intervals} |'.format(**r) for r in consumer)
dispatch_runs = ','.join(dispatch['runs'])
report = '\n'.join([
    '# 静默猎手策略提案核验报告', '',
    '时间：' + timestamp + '；批次：' + BATCH + '。', '',
    '结果：九项waiting，一项原选/护栏/SL记录提案duplicate。未改源码、知识、规则或阈值；没有本批提交、live合入或版本。详细逐项证据、反例与验证边界见同目录proposal.md。', '',
    '## 派发与基线', '',
    '- `git status --short`开工为空；按第1.2节核本批根learn.json，task=strategy-proposal、character=silent、worktree精确匹配，reason=proposal，十个proposal_ids均已领取；无research_request、implementation_request或proposal_repair。普通研究请求文件属于另一批，不承接该专题。',
    '- `git merge --no-edit main`返回Already up to date；report.base与实际HEAD均为完整`' + BASE + '`。不修改请求、旧父要求或原提案。',
    '- 本批锚点：' + dispatch_runs + '。原提案范围另含9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T，共15局；runs.jsonl均核为Silent，A9三局/A10十二局，15局均带历史+dirty源码标记，不能用当前源码重建旧运行树。',
    '- 运行不派子agent、不联网、不调LLM/API、不运行play。任务正文要求high，原项目统一说明写xhigh；本批不改模型/配置/权限，没有独立读回当前原生请求的model/effort，不能声称已切换运行会话。', '',
    '## 证据与适用范围', '',
    '通过本工作树learner/extract_evidence.py的共用入口冻结八流；身份仅取显式run、run_id、state.run_id或fingerprint.run，多身份冲突拒收。保存source_size、逐行offset/bytes/SHA与计数。`verify_materials.py`又按偏移读原只读日志，22,424行逐一核原字节、JSON、身份及输出SHA。全流另有五条不可解码JSON，不能确定所属局，不据此断言本批日志不存在。fight-plans在该截点0行，仅表示本次身份筛选未选到。', '',
    *stream_table, '',
    '对15局做角色、进阶和跨幕端点核验；重点语义分析覆盖RC61、BTSR、XTS、9Z9H、7X、MTQ的限定楼层及回合。未把当前经验库33个关联条目的全历史计数当本批重算，也未冒称原113/115/116局已重新校准。', '',
    '固定材料断言45项全部成立：含RC F23逐牌柔嫩/药敏/折扇分源、B强制弃牌、X毒胜实际HP/一层幽灵/未到夜魇复制、9Z复活0HP路径与倍率消费、7X实加7毒、MTQ同盘SL净差及22对跨幕HP。断言是证据算术/材料核验，不是生产tsc/vitest或新模型校准；没有源码改动，所以撤源码失败/恢复通过不适用。', '',
    '## 现有消费者实际读回', '',
    '从共用抽取物生成六个单局限定楼层输入（1,627帧状态、1,530条有decision_id决策；该范围无缺id元数据需排除）。以本地Node和已有tsx loader逐个运行现有learner/audit-selection.ts，六次exit0，输入/输出/错误文件SHA及命令存consumer/receipts.json。运行不调用模型、不读刷新的知识JSON。', '',
    *consumer_table, '',
    '合计447个候选段、275个轮窗，其中144个轮窗具有所需观察端点、1,097个动作区间有端点、433个区间仍未知；447个完整候选结果全部null。特别是7X因原sl_attempt缺失等接续约束不能认证区间；原帧手工可核的7毒不是工具已认证完整候选。相邻观察/单步回执与整个候选执行严格区分。', '',
    'f54e8de2381c1250所要求的是这套区分记录：MTQ F11原plan6（损14/伤14）和护栏plan1（损6/伤16）同题唯一匹配，预计最终最优=false，保留原rollout_best_chosen定义；F23原plan1与SL plan4的0/13、8/19同样读回。F11弃牌后重问使候选段superseded_by_question；未把整轮实损6/净扣20归给plan1完整兑现。这个null行为正是原提案要求，不能因为没有完整反事实而重复实现记录功能。该duplicate不关闭SL血价、护栏阈值或收益宽父。', '',
    '## 实际live源码追溯', '',
    '冻结live为`cfa1c0be88147b4eac65c13d8c550b23ed4eef17`。核15个相关源码叶，14个与本基线逐字节相同；card-model仅两条Roy/Dai历史注释不同，差量原件base-live-card-model-comments.patch保留，不覆盖live。每叶live_source_commit均核实际live祖先，详source-audit.json。', '',
    '记录提案duplicate使用真实源码commit `cf72bd21148059f111f760cc98a727369e34a47e`：该提交为冻结live祖先，guard、SL comparison、selection-audit、dispatch、selection-execution、selection-observation六个相关叶与当前逐字节相同；见guard-proposal-existing-coverage.json。其他窄实现只是证据，不把它们拼为九个宽提案implemented/duplicate。', '',
    '## 反证、未知与账本', '',
    '- 原ledger silent-0005已有一条RC61MFQM63Y6/F45的support注记，却同时提及另外两局；RC61实际结束F33，该层定位越界，不能用作RC F45支持。本批只追加溯源提示，不改原claim、首证、证据角色或状态；它不是基础机制反例，也不添加其他局的结论。',
    '- 7毒、末轮血价和一层幽灵均有局部实证；缺独立整战反事实、目标/修正组合校准及时间留出，不学习新的统一阈值。22跨幕对按A9/A10分开，不推广更低进阶或未知遗物交互。',
    '- 原dirty运行树/知识字节、逐击毛伤、被截断SL出口、耳环内部动作、夜魇合法复制后继和未到未来节点保持未知。没有新机制主张、重复历史复盘或新经验库发布。',
    '- 45个原账本仅经根learner/ledger.py update追加本批proposal/report追溯与具体处置说明；不传status，不把旧shipped降为proposed，不标新shipped、不写新version/claim/evidence。执行输入/回执与前后保护字段核验另存ledger-updates.jsonl、ledger-update.stdout.txt、ledger-preservation.json。十个code_proposals沿用原CLI id，没有重复add。', '',
    '## 提交、验证和交接', '',
    'fixes=[]；merged=null；tests={"tsc":null,"vitest":null,"cases":null}。没有源码提交，故不制造gitleaks提交成功、撤源码红绿、sandbox/full检查或eval版本。工作树无跟踪改动；材料都在本批忽略的learner/runs目录内。根账本属于任务明确授权的CLI记录例外，由运维收取本批回执；不修改live、不启动合并流程、不停对局、不清理仍运行的自身工作树。', '',
    '运维入口：`' + str(OUT / 'proposal.md') + '`与本report；最终机器回执为result.json。九项具体waiting缺口与一项真实source duplicate详proposal-results.json。本批没有实际上线，不发送规则变更双通知、不申请版本或冒称经验已被大脑采用。', '',
    '材料索引：dispatch.json、proposals-current.json、proposal-queue-selected.json、十份*.original.md、verified-runs.json、lessons-selected.json、experience-selected.json、ledger-before.json；evidence/*及evidence-byte-verification.json；states-compact.jsonl、selected-raw-states.json、selected-decisions.json、historical-configs.json、act-transitions.json、material-checks.json；consumer/*.input.json、*.audit.json、receipts.json、summary.json；source-audit.json与guard-proposal-existing-coverage.json。', ''
])
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
          'base': BASE, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in proposals], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('proposal_results', {state: sum(r['state'] == state for r in results) for state in ('waiting', 'duplicate')})

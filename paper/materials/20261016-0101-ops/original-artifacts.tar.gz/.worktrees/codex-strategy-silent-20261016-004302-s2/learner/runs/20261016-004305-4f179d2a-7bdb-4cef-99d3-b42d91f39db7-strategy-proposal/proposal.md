# 静默猎手本批十项派发提案核验

时间：2026-10-16T00:58:23+08:00；批次：20261016-004302-s2-strategy-proposal。
基线：`81275beb0c0a003d276bbda527280caee48291e8`；普通提案队列，未绑定research_request或implementation_request。
只处理dispatch.json中十个原id，不领取其他提案，不新建重复id。完整角色核验、逐行原字节和现有实现追溯见report.md及其列出的材料。

本批结果为9项waiting、1项记录功能duplicate；未改源码或知识，未新增上线、版本或测试成功。

## silent-proposal-03754e1265894000 — 牌挡、柔嫩、临时敏捷和被动挡的联合兑现

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-mechanisms.md`；SHA256 `518c139723decc4238c7ea5641e671c8738ec240118ff5140ca503612295599f`。
关联账本：silent-0006、silent-0011、silent-0013、silent-0080、silent-0088、silent-0101、silent-0232、silent-0253。

证据：RC61MFQM63Y6 A10 F23T3，states 285222—285229：预判后净敏1，速度后6；斗篷实12挡、刺击后敏4、防御实9挡，第三次攻击后的被动4挡另计，总25。F33T4第三试生存者后手空；该局末轮脆弱两防御只有6挡。账本 silent-0006/0011/0013/0080/0088/0101/0232/0253。

现有行为：card-model、turn-solver、rollout 已分别有 survivorDiscard、phantomBlades、tender、ornamentalFan 等窄模型；源码存在不等于这些来源及组合全部正确。

结论与缺口：局部敏捷、柔嫩和折扇实帧成立；仍缺柔嫩与脆弱/倍率等联合修正的逐牌完整消费者校准，以及幻影/持续毒的后轮兑现对照，不能把多个窄模型合称八条提案全部实现。

反例与限制：首刀14伤仅限已建立9层幻影的观察窗口；末蟹未建立幻影/毒雾。伤害或挡的局部成立没有阻止末战失败，不支持统一启动优先级。

预期行为与验证：冻结实际修正项及逐牌状态，分源核每一张牌和后轮收益；未知联合条件继续标未知，不添加新顺序/权重。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-ab055ef7dfbb44e5 — 夜魇的存活条件与罐装幽灵

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-survival-and-ghost.md`；SHA256 `c5490a44836c3900e1d03b59370dea8c076a8b5435236f7a5e575e4c0b516b17`。
关联账本：silent-0140、silent-0069、silent-0005、silent-0206。

证据：XTSV1U9JD34T A10 F49：decisions 280550、280631、280635—280639；states 286897—286899、286986—286987。幽灵新增无实体1，攻击26→1，16挡覆盖并保留23HP；次轮钳子留10。末T4只1HP/6挡对16，夜魇3层后立即GAME_OVER，未到三张复制手牌。账本 silent-0140/0069/0005/0206。

现有行为：combat-plan 提供 Silent A10 无既存无实体层时 observedGhostInAJar，card-model 建模一层；该分支保留药水选项且不以此自动喝药。

结论与缺口：单层幽灵已有窄实现；夜魇次轮复制的到手、合法费用和实际施放尚缺该绝境完整替代线校准，六次同局早喝也没有延后饮用的受控后继，不能关闭整个存活/时点提案。

反例与限制：所有已执行T4路径仍死；去掉夜魇未证可活。幽灵T1确已兑现零损，不能由败局推出早喝无价值或必须晚喝。

预期行为与验证：分别检验一层效果、复制到手和后继合法动作；得到延后饮用完整实线前保留原时点、药价与规则。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-0129c465c6f5bd79 — 弃牌重核、毒胜保血与接管首轮

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-replay.md`；SHA256 `bf425049a5868e3bec28ff845f0dcc2f5560594b3b85b4380a378ab2295bdcdc`。
关联账本：silent-0009、silent-0021、silent-0024、silent-0057、silent-0079、silent-0090、silent-0140、silent-0164、silent-0205、silent-0268、silent-0271。

证据：BTSRF7JL1W1Y A10 F31T2，decision 279846 预计损4；states 286161→286162 生存者弃唯一突然一拳，286158→286163实际35→21。XTSV1U9JD34T F48T8，decision 280547 空斩杀结束；286893→286894为32→23，286896带23入F49。涉及 silent-0205/0268/0271/0164/0140 等原11账本。

现有行为：turn-solver 独立消费普通 survivorDiscard；preservePoisonWinHp 在观察的连王第一战继续搜索有HP可保的毒胜候选，combat-plan 按 continuation 接线。耳环的首轮接管事实也已有窄接线。

结论与缺口：普通生存者弃牌与毒胜搜索已有窄修复；整项还包含实际弃牌重问、复制后继、同族/女王目标及耳环首轮兑现，缺原接管动作序列和联合完整候选认证，不能用两个窄修复关闭原整项。

反例与限制：B同族第四试胜但抽序/后轮同时改变，不能归为固定击杀序。X首王保血差额不证明第二王可赢；耳环接管后的手牌不证明主动启动顺序。

预期行为与验证：对实际选择后手牌重新取题；连王只用实到HP；接管与自主动作分别核验，缺完整后继时不改目标优先或SL门槛。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-abe9d5d0be109a9f — 胜战血药成本与连王实到资源

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-resources.md`；SHA256 `21263e5782fa17b030141cf5d79a9968115beeb1a99dc66f6309cbac9b51957b`。
关联账本：silent-0019、silent-0020。

证据：BTSRF7JL1W1Y A10 F30赢战70→42并用明晰，F31以42及液态记忆进入，F32未到。XTSV1U9JD34T F48赢战97→23，F49原帧286896实到23；F48T8凋萎另耗9。账本 silent-0019/0020；原复盘及本批跨幕表/消费者输入均保留。

现有行为：路线投影、连王 continuation 与实际状态输入已存在；它们是条件估计，不是未来营火已兑现的记账。

结论与缺口：赢战消耗、真实回复与SL恢复可区分；缺相同条件的改线/留药/锻造完整后继和独立时间留出校准，不能由两局相关资源链拟合新的安全血线或机会成本。

反例与限制：F48是获胜但净耗74HP，反驳只记败战成本；未抵达F32不能记回血。未来路线预测条件随牌/药变化，不能当同条件算法误差。

预期行为与验证：按实到节点与实际槽位接续；拟合另需独立对局及样本条件，不更改当前房间代价的五样本门槛。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-f16527e59b5cc1e0 — 临时减力、覆甲、留挡与持续毒的分源

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-mechanisms.md`；SHA256 `a71d6c87441d33115c5a8f4d3e0103673fd07798805978646f3a3961fb749079`。
关联账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0016、silent-0027、silent-0046、silent-0069、silent-0095、silent-0128、silent-0196、silent-0241。

证据：BTSRF7JL1W1Y F31T2/T4：实际覆甲与13牌挡共同抵扣多敌威胁；XTSV1U9JD34T F49T1幽灵后留10挡、T2结束仅留5，末T3仍损22；末T4尖啸后现场16攻对6挡仍死。账本为原12项，含 silent-0005/0016/0046/0069/0095/0128/0196/0241。

现有行为：临时减力、留挡、无实体与毒已分别建模；普通生存者与幽灵窄修复不能替代完整时序验收。

结论与缺口：已有局部效果和窄实现，但缺覆甲/留挡/临时属性撤回/毒触发/敌成长共同存在时的逐源完整回放与可比后继，不能从端点净差推出统一联合模型或新药价。

反例与限制：钳子是最多留10而非每轮保底10；末女王未继承前战能力。中毒尚存不是已结伤害，临减到期不能当冻结成长。

预期行为与验证：逐源核结束时点、临时撤回及下一轮实际挡；无法归属的毛伤保留未知，不倒补固定挡或停攻收益。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-7a8e9ccb7e646538 — 倍率挡、复活与SL预测/实差

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-combat.md`；SHA256 `e365da8858d06c845b8f83b662fad011721eeab59fd4e0dce4c46aa3925b640f`。
关联账本：silent-0005、silent-0006、silent-0011、silent-0021、silent-0024、silent-0027、silent-0034、silent-0077、silent-0079、silent-0123、silent-0129、silent-0180、silent-0221。

证据：9Z9H2EXKLF3T A10 F48：末T8 states 287989—287991为32挡、HP11→0→20；T10 states 288000/288003/288004挡18→27→37，288005只余3HP。T7第二/三试完整轮端点经既有消费者分别20→9、20→11，敌393→344、393→322。账本为原13项，含 silent-0077/0123/0180/0129/0221。

现有行为：士兵首次消费、暗影、持牌伤与荆棘已有局部模型；selection-turn 保留复活状态路径及重问，不把净回复当零成本。

结论与缺口：T7预测多损7/多伤16，与实际整轮省2血/多扣22不同且包含多次重问；缺逐击毛伤、各候选实际兑现和同条件整战后继，不能据此调整SL血价或宣称全组合已校准。

反例与限制：T8经历0HP与复活，净HP增加不是没有受伤；T10三张挡37仍损15。死亡后未执行攻击不能预支反伤，三次失败不能证明必死。

预期行为与验证：保留原/替预测与实际轮窗三份材料，毛伤及候选因果继续未知；规则变更要有独立留出支持。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-cd9f76184de6e29a — 跨幕回复与其他资源来源

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-resources.md`；SHA256 `54f562100db0a2dbc72c07a5b1411e42838e3370221a23ea4b769795196c66aa`。
关联账本：silent-0019、silent-0020、silent-0243。

证据：本批15局角色核验后，得到A9五对、A10十七对共22个同最大HP跨幕转换，22/22符合已有⌊缺失HP×80%⌋观察。9Z9H2EXKLF3T F17→18为24/70→60/70，F33→34为23/77→66/77；F35最大HP77→69与当前HP66→30另记。账本 silent-0019/0020/0243。

现有行为：silent-act-transition-missing-hp-heal 知识条目与现有路线/结构输入存在；本批没有重建历史116局统计，也没有重新发布知识。

结论与缺口：22个端点支持已有A9/A10回复观察，但不提供原116局完整资源模型重校准、低阶或未知遗物交互、改线/营火选择的受控收益，不能关闭包含整条路线/SL资源接续的宽提案。

反例与限制：9Z末战前两次火实际只到7和27HP，F49未到；原F34投影使用77上限，后续上限变化，不能作为同条件残差。SL复药不是新获得。

预期行为与验证：继续保持A9/A10与各回复来源分账；有新独立完整资源链再重校准，不用本批22对冒称全部历史已验。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-292f6731bdb9b669 — 头骨组合毒药水的局部总增量

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-044302-postmortem/proposal-poison-potion.md`；SHA256 `2f943d1aee2e7ed6d1ddfa07b469a4488d27525bad4714cec58f6a94917a8c63`。
关联账本：silent-0087、silent-0020。

证据：7X0W3U8TVA2A A10 F31T13，decision 282021用槽0朝后段index2；states 288470→288471后段毒0→7、HP25不变，288472后段HP18、玩家0。前段同时结旧8毒，中段发生重接回复；不能把所有敌HP变化当7毒效果。账本 silent-0087/0020。

现有行为：observedDemonPoison 严格限制另一完整修正组合并返回6；doubleBoss 的 observedPoison 仅48/49上下文，均不覆盖本局千足虫头骨组合。未知持有值和实零值原有来源字段可区分。

结论与缺口：单次已饮证据确证该后段目标加7总毒；仍缺同完整修正组合下各目标、既有毒/重接及药牌共同推演的可比校准，也无早喝/留药后继与持有价样本，不能把7推广到所有持头骨输入或拟合用药阈值。

反例与限制：实加7仍死亡；不能额外再加一次头骨，也不能把另一上下文的6搬来当本局已覆盖。其他目标/已有毒/制品等组合未由这次饮用验证。

预期行为与验证：保留该目标的7总量作为冻结校准材料，扩范围前补逐目标同条件后继；未知组合继续原未模拟选项，不删选项、不新设早喝/药价规则。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-0802f69b28d25079 — 死亡率饱和时的SL血价

处置：waiting。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-sl.md`；SHA256 `79e1696de63d19810eb442ee3afa83dd5795f1693f4c9f4a48433fef014e3596`。
关联账本：silent-0079、silent-0019、silent-0044、silent-0080、silent-0253、silent-0011、silent-0214、silent-0189、silent-0046、silent-0222、silent-0243、silent-0262。

证据：MTQ0EUBJ3R6T A10 F23T3，decision 282434：原plan1预测损0/伤13，SL plan4预测损8/伤19；states 288806→288812原试10→10，288899→288905末试10→2，敌同61/41起盘仅后段差6。T5末288914→288915为2→0，-11是预计剩HP而非损血11，按原追加勘误。账本 silent-0079/0019/0044/0080/0253/0011/0214/0189/0046/0222/0243/0262。

现有行为：silentSlComparison、selection-audit 和离线轮窗分别保存候选预测及真实端点；原SL探索排序和必死判官独立。

结论与缺口：同盘局部血价可核，但四次SL是一个相关样本，原线亦无已证整战胜利且改线改变后轮抽牌/能力；缺独立A10留出和完整反事实，不能拟合饱和探索的新HP门槛或权重。

反例与限制：原线首试也到T6判死；末试T5死不能单归打击收益。两异螨同类型跨帧身份不自动认证，摘要block4与已落盘block0差异仍保留。

预期行为与验证：等待独立同角色A10数据，以实到资源和完整后继比较探索；继续记录预测/端点，不把24/24败样本当实盘必死。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

## silent-proposal-f54e8de2381c1250 — Jev原选、护栏/SL实线与可比推演记录

处置：duplicate；实际live祖先源码 `cf72bd21148059f111f760cc98a727369e34a47e`。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-guard.md`；SHA256 `db780eb4b443cc8fdfb17237293f186588b1b010347160b24d1d22291ae8c5ce`。
关联账本：silent-0125。

证据：MTQ0EUBJ3R6T A10 F11T1 decision 282138，原plan6损14/伤14、护栏plan1损6/伤16；当前离线消费者从原字节恢复同题唯一匹配与 predicted_final_rollout_best=false。F23T3 282434同时恢复原plan1与SL plan4的0/13和8/19。账本 silent-0125。

现有行为：实际live祖先源码cf72bd21148059f111f760cc98a727369e34a47e包含与当前逐字节相同的guard、SL comparison、selection-audit、dispatch及离线selection-execution/observation六叶。生产combat-plan按Silent A10记录answer/before_sl/after_sl，hand/loop记录单动作回执；原rollout_best_chosen含义保留。

结论与缺口：原提案限定的记录功能已有live实现：原选/最终候选及HP、伤害、毒/持续效果候选资料分列，同题唯一且有排名才填可比结果，其他情况null并附原因；原始MTQ两窗口读回符合。登记duplicate仅指记录范围，未宣称护栏/SL参数或完整候选因果已经验证。

反例与限制：F11第一次动作是pending回执，实际进入弃牌并重问；离线工具以superseded_by_question截断，actual_full_candidate_result仍null。整轮实损6/净扣20不能倒灌到原plan1伤16预测。

预期行为与验证：复用既有记录链，不重复改代码；实际完整候选收益及其他宽父继续等待证据。若记录实现未来退回，仅逆向记录字段与消费者，不撤护栏或改游戏规则。

本批旧/新规则：没有新增规则，保留上述现有行为；没有参数拟合。未来修改仅限本角色已观察条件，其他角色保持等价。

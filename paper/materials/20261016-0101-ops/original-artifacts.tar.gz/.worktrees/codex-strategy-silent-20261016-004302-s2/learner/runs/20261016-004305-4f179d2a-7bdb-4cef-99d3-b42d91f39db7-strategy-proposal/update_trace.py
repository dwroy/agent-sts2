import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROJECT = Path('/home/dw/Projects/agent-sts2')
LEDGER = PROJECT / 'paper/materials/learning/ledger.jsonl'
BATCH = '20261016-004302-s2-strategy-proposal'
spec = importlib.util.spec_from_file_location('root_ledger', PROJECT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
proposals = json.loads((OUT / 'proposals-current.json').read_text())
results = {r['id']: r for r in json.loads((OUT / 'proposal-results.json').read_text())}
ids = sorted({ident for p in proposals for ident in p['ledger']})


def selected_fold():
    rows = []
    with LEDGER.open() as handle:
        for number, raw in enumerate(handle, 1):
            try:
                row = json.loads(raw)
            except ValueError:
                continue
            if row.get('id') in ids:
                rows.append((number, row))
    return module.fold(rows)


before = selected_fold()
assert set(before) == set(ids)
(OUT / 'ledger-write-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in ids:
    related = [p['id'] for p in proposals if ident in p['ledger']]
    parts = [BATCH + ' 本批仅追加策略核验追溯；角色silent；base81275beb0c0a003d276bbda527280caee48291e8。']
    for proposal in related:
        result = results[proposal]
        parts.append(proposal + '=' + result['state'] + '：' + result['reason'])
        if result.get('commit'):
            parts.append('实际live祖先源码=' + result['commit'] + '；仅记录功能重复覆盖，非本批上线。')
    if ident == 'silent-0005':
        parts.append('原既有RC61MFQM63Y6/F45 support定位越界：runs实止F33，该注记还提及其他局，不能作为RC/F45机制实证；本批不修改原claim/首证/证据/status，仅保留定位限制，见report。')
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': ' '.join(parts)})
request = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates)
(OUT / 'ledger-updates.jsonl').write_text(request)
print(subprocess.check_output(['date', '-Iseconds'], text=True).strip())
offset_before = LEDGER.stat().st_size
with (OUT / 'ledger-update.stdout.txt').open('w') as stdout, (OUT / 'ledger-update.stderr.txt').open('w') as stderr:
    result = subprocess.run(['python3', str(PROJECT / 'learner/ledger.py'), 'update'], input=request,
                            text=True, stdout=stdout, stderr=stderr)
(OUT / 'ledger-cli-receipt.json').write_text(json.dumps({'command': ['python3', str(PROJECT / 'learner/ledger.py'), 'update'],
                                                       'exit_code': result.returncode, 'requested_updates': len(updates),
                                                       'source_offset_before': offset_before,
                                                       'request_sha256': hashlib.sha256(request.encode()).hexdigest()},
                                                      ensure_ascii=False, indent=2) + '\n')
assert result.returncode == 0
assert (OUT / 'ledger-update.stdout.txt').read_text().split() == ids
after = selected_fold()
protected = []
for ident in ids:
    a, b = before[ident], after[ident]
    assert {k: v for k, v in a.items() if k not in ('where', 'history', 'notes')} == {
        k: v for k, v in b.items() if k not in ('where', 'history', 'notes')}, ident
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values, (ident, key)
    assert b['history'][:len(a['history'])] == a['history']
    assert b['notes'][:len(a['notes'])] == a['notes']
    assert str(OUT / 'report.md') in b['where']['proposal']
    protected.append({'id': ident, 'status_before': a['status'], 'status_after': b['status'],
                      'all_non_trace_fields_equal': True, 'old_where_notes_history_preserved': True})
(OUT / 'ledger-preservation.json').write_text(json.dumps(protected, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
appends = []
with LEDGER.open('rb') as handle:
    handle.seek(offset_before)
    while True:
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        try:
            row = json.loads(raw)
        except ValueError:
            continue
        if row.get('id') in ids and row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith(BATCH + ' 本批仅追加策略核验追溯'):
            appends.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
assert len(appends) == len(ids) and {r['row']['id'] for r in appends} == set(ids)
(OUT / 'ledger-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
print('CLI追溯追加', len(appends), '；所有非追溯字段及原历史保护核验通过。')

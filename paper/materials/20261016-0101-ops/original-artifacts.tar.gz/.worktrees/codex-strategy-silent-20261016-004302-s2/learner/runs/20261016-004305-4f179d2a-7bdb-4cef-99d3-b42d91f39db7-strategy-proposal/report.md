# 静默猎手策略提案核验报告

时间：2026-10-16T00:58:23+08:00；批次：20261016-004302-s2-strategy-proposal。

结果：九项waiting，一项原选/护栏/SL记录提案duplicate。未改源码、知识、规则或阈值；没有本批提交、live合入或版本。详细逐项证据、反例与验证边界见同目录proposal.md。

## 派发与基线

- `git status --short`开工为空；按第1.2节核本批根learn.json，task=strategy-proposal、character=silent、worktree精确匹配，reason=proposal，十个proposal_ids均已领取；无research_request、implementation_request或proposal_repair。普通研究请求文件属于另一批，不承接该专题。
- `git merge --no-edit main`返回Already up to date；report.base与实际HEAD均为完整`81275beb0c0a003d276bbda527280caee48291e8`。不修改请求、旧父要求或原提案。
- 本批锚点：RC61MFQM63Y6,XTSV1U9JD34T,BTSRF7JL1W1Y,9Z9H2EXKLF3T,HMVJKM56S4Q8,F4QKG4J1AJJZ,G403VCZ3BH1B,25226ZFLNR1J,JLN5SK17W4FQ,JMH5C51RLN4E。原提案范围另含9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T，共15局；runs.jsonl均核为Silent，A9三局/A10十二局，15局均带历史+dirty源码标记，不能用当前源码重建旧运行树。
- 运行不派子agent、不联网、不调LLM/API、不运行play。任务正文要求high，原项目统一说明写xhigh；本批不改模型/配置/权限，没有独立读回当前原生请求的model/effort，不能声称已切换运行会话。

## 证据与适用范围

通过本工作树learner/extract_evidence.py的共用入口冻结八流；身份仅取显式run、run_id、state.run_id或fingerprint.run，多身份冲突拒收。保存source_size、逐行offset/bytes/SHA与计数。`verify_materials.py`又按偏移读原只读日志，22,424行逐一核原字节、JSON、身份及输出SHA。全流另有五条不可解码JSON，不能确定所属局，不据此断言本批日志不存在。fight-plans在该截点0行，仅表示本次身份筛选未选到。

| 流 | 本批所属行 | 冻结source_size（字节） |
|---|---:|---:|
| states | 11008 | 13212599192 |
| decisions | 10609 | 1713225092 |
| sl-attempts | 109 | 41622540 |
| run-config | 16 | 1796239 |
| run-plans | 97 | 8243169 |
| brain | 570 | 613988835 |
| runs | 15 | 339600 |
| fight-plans | 0 | 2233957 |

对15局做角色、进阶和跨幕端点核验；重点语义分析覆盖RC61、BTSR、XTS、9Z9H、7X、MTQ的限定楼层及回合。未把当前经验库33个关联条目的全历史计数当本批重算，也未冒称原113/115/116局已重新校准。

固定材料断言45项全部成立：含RC F23逐牌柔嫩/药敏/折扇分源、B强制弃牌、X毒胜实际HP/一层幽灵/未到夜魇复制、9Z复活0HP路径与倍率消费、7X实加7毒、MTQ同盘SL净差及22对跨幕HP。断言是证据算术/材料核验，不是生产tsc/vitest或新模型校准；没有源码改动，所以撤源码失败/恢复通过不适用。

## 现有消费者实际读回

从共用抽取物生成六个单局限定楼层输入（1,627帧状态、1,530条有decision_id决策；该范围无缺id元数据需排除）。以本地Node和已有tsx loader逐个运行现有learner/audit-selection.ts，六次exit0，输入/输出/错误文件SHA及命令存consumer/receipts.json。运行不调用模型、不读刷新的知识JSON。

| 局号 | 候选段 | 轮窗 | 已观察轮端点 | 已观察动作区间 | 未知动作区间 |
|---|---:|---:|---:|---:|---:|
| 7X0W3U8TVA2A | 42 | 18 | 0 | 0 | 99 |
| 9Z9H2EXKLF3T | 131 | 50 | 33 | 272 | 60 |
| BTSRF7JL1W1Y | 62 | 53 | 36 | 238 | 69 |
| MTQ0EUBJ3R6T | 49 | 50 | 25 | 156 | 93 |
| RC61MFQM63Y6 | 94 | 55 | 29 | 242 | 90 |
| XTSV1U9JD34T | 69 | 49 | 21 | 189 | 22 |

合计447个候选段、275个轮窗，其中144个轮窗具有所需观察端点、1,097个动作区间有端点、433个区间仍未知；447个完整候选结果全部null。特别是7X因原sl_attempt缺失等接续约束不能认证区间；原帧手工可核的7毒不是工具已认证完整候选。相邻观察/单步回执与整个候选执行严格区分。

f54e8de2381c1250所要求的是这套区分记录：MTQ F11原plan6（损14/伤14）和护栏plan1（损6/伤16）同题唯一匹配，预计最终最优=false，保留原rollout_best_chosen定义；F23原plan1与SL plan4的0/13、8/19同样读回。F11弃牌后重问使候选段superseded_by_question；未把整轮实损6/净扣20归给plan1完整兑现。这个null行为正是原提案要求，不能因为没有完整反事实而重复实现记录功能。该duplicate不关闭SL血价、护栏阈值或收益宽父。

## 实际live源码追溯

冻结live为`cfa1c0be88147b4eac65c13d8c550b23ed4eef17`。核15个相关源码叶，14个与本基线逐字节相同；card-model仅两条Roy/Dai历史注释不同，差量原件base-live-card-model-comments.patch保留，不覆盖live。每叶live_source_commit均核实际live祖先，详source-audit.json。

记录提案duplicate使用真实源码commit `cf72bd21148059f111f760cc98a727369e34a47e`：该提交为冻结live祖先，guard、SL comparison、selection-audit、dispatch、selection-execution、selection-observation六个相关叶与当前逐字节相同；见guard-proposal-existing-coverage.json。其他窄实现只是证据，不把它们拼为九个宽提案implemented/duplicate。

## 反证、未知与账本

- 原ledger silent-0005已有一条RC61MFQM63Y6/F45的support注记，却同时提及另外两局；RC61实际结束F33，该层定位越界，不能用作RC F45支持。本批只追加溯源提示，不改原claim、首证、证据角色或状态；它不是基础机制反例，也不添加其他局的结论。
- 7毒、末轮血价和一层幽灵均有局部实证；缺独立整战反事实、目标/修正组合校准及时间留出，不学习新的统一阈值。22跨幕对按A9/A10分开，不推广更低进阶或未知遗物交互。
- 原dirty运行树/知识字节、逐击毛伤、被截断SL出口、耳环内部动作、夜魇合法复制后继和未到未来节点保持未知。没有新机制主张、重复历史复盘或新经验库发布。
- 45个原账本仅经根learner/ledger.py update追加本批proposal/report追溯与具体处置说明；不传status，不把旧shipped降为proposed，不标新shipped、不写新version/claim/evidence。执行输入/回执与前后保护字段核验另存ledger-updates.jsonl、ledger-update.stdout.txt、ledger-preservation.json。十个code_proposals沿用原CLI id，没有重复add。

## 提交、验证和交接

fixes=[]；merged=null；tests={"tsc":null,"vitest":null,"cases":null}。没有源码提交，故不制造gitleaks提交成功、撤源码红绿、sandbox/full检查或eval版本。工作树无跟踪改动；材料都在本批忽略的learner/runs目录内。根账本属于任务明确授权的CLI记录例外，由运维收取本批回执；不修改live、不启动合并流程、不停对局、不清理仍运行的自身工作树。

运维入口：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-004302-s2/learner/runs/20261016-004305-4f179d2a-7bdb-4cef-99d3-b42d91f39db7-strategy-proposal/proposal.md`与本report；最终机器回执为result.json。九项具体waiting缺口与一项真实source duplicate详proposal-results.json。本批没有实际上线，不发送规则变更双通知、不申请版本或冒称经验已被大脑采用。

材料索引：dispatch.json、proposals-current.json、proposal-queue-selected.json、十份*.original.md、verified-runs.json、lessons-selected.json、experience-selected.json、ledger-before.json；evidence/*及evidence-byte-verification.json；states-compact.jsonl、selected-raw-states.json、selected-decisions.json、historical-configs.json、act-transitions.json、material-checks.json；consumer/*.input.json、*.audit.json、receipts.json、summary.json；source-audit.json与guard-proposal-existing-coverage.json。

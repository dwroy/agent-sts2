import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
FLOORS = {
    'RC61MFQM63Y6': {17, 23, 29, 33},
    'BTSRF7JL1W1Y': {17, 30, 31},
    'XTSV1U9JD34T': {33, 48, 49},
    '9Z9H2EXKLF3T': {35, 38, 39, 42, 45, 47, 48},
    '7X0W3U8TVA2A': {30, 31},
    'MTQ0EUBJ3R6T': {11, 17, 19, 20, 23},
}
runs = {r['run_id']: r for r in json.loads((OUT / 'verified-runs.json').read_text())}
inputs = {run: {'run': runs[run], 'states': [], 'decisions': []} for run in FLOORS}
exclusions = []
for stream in ('states', 'decisions'):
    with (OUT / 'evidence' / (stream + '.evidence.jsonl')).open() as handle:
        for raw in handle:
            item = json.loads(raw)
            run = item['run_id']
            if run not in inputs:
                continue
            row = item['row']
            floor = row.get('floor') if stream == 'decisions' else (row['state'].get('run') or {}).get('floor')
            if floor not in FLOORS[run]:
                continue
            if stream == 'decisions' and not row.get('decision_id'):
                exclusions.append({k: item[k] for k in ('run_id', 'line', 'offset', 'bytes', 'sha256')})
                continue
            inputs[run][stream].append(dict(row, _line=item['line']))
directory = OUT / 'consumer'
directory.mkdir(exist_ok=True)
for run, value in inputs.items():
    (directory / (run + '.input.json')).write_text(json.dumps(value, ensure_ascii=False) + '\n')
    print(run, len(value['states']), len(value['decisions']))
(directory / 'metadata-exclusions.json').write_text(json.dumps(exclusions, ensure_ascii=False, indent=2) + '\n')
print('excluded_metadata', len(exclusions))

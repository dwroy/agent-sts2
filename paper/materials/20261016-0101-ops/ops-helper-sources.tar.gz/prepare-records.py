from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile

root=Path.cwd(); p=root/'ops/codex-ops/record-staging/20261016-0101'; pub=root/'paper/materials/20261016-0101-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda f:json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-004302-s2-strategy-proposal'; b=load(root/'ops/codex-ops/learn.json')['batches'][bid]; report=b['report']; s=Path(report['report']).parent
out=root/'ops/codex-ops/learner'/(bid+'.out'); output=out.read_text(); supplied=json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert supplied==report
scratch=load(s/'result.json'); assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state'],x.get('commit')) for x in scratch['proposal_results']]==[(x['id'],x['state'],x.get('commit')) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert sum(x['state']=='waiting' for x in report['proposal_results'])==9 and sum(x['state']=='duplicate' for x in report['proposal_results'])==1
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((p/'readonly-runtime.py').read_text()); native=runtime(bid,report,output,b['worktree'])
artifacts=load(s/'artifact-sha256.json')
for row in artifacts:
    f=(s/row['path']).resolve(); assert f.is_relative_to(root)
    raw=f.read_bytes(); assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
proposals=load(s/'proposals-current.json'); assert {x['id'] for x in proposals}==set(report['code_proposals'])
for x in proposals:
    assert sha(Path(x['proposal']).read_bytes())==x['proposal_sha256']==sha((s/(x['id']+'.original.md')).read_bytes())
verification=load(s/'evidence-byte-verification.json'); assert sum(x['verified_rows'] for x in verification)==22424
for x in verification:assert sha((s/'evidence'/(x['stream']+'.evidence.jsonl')).read_bytes())==x['output_sha256']
material=load(s/'material-checks.json'); assert material['count']==len(material['checks'])==45 and all(x['actual']==x['expected'] for x in material['checks'])
source=load(s/'source-audit.json'); assert source['base']==report['base'] and len(source['files'])==15
for row in source['files']:
    a=git('show',report['base']+':'+row['path']); z=git('show',source['live_head']+':'+row['path'])
    assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256'] and (a==z)==row['equal']
    assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
    git('merge-base','--is-ancestor',row['live_source_commit'],source['live_head'])
assert sum(x['equal'] for x in source['files'])==14
coverage=load(s/'guard-proposal-existing-coverage.json'); assert coverage['commit']=='cf72bd21148059f111f760cc98a727369e34a47e' and coverage['ancestor'] and len(coverage['files'])==6
git('merge-base','--is-ancestor',coverage['commit'],coverage['live_head'])
for row in coverage['files']:
    a=git('show',coverage['commit']+':'+row['path']); z=git('show',coverage['live_head']+':'+row['path']); assert a==z and sha(a)==row['sha256'] and row['equals_current']
consumers=load(s/'consumer/receipts.json')
for x in consumers:
    assert x['exit_code']==0
    for suffix,key in [('input.json','input_sha256'),('audit.json','output_sha256'),('audit.stderr.txt','error_sha256')]:assert sha((s/'consumer'/(x['run_id']+'.'+suffix)).read_bytes())==x[key]
summary=load(s/'consumer/summary.json'); assert len(consumers)==len(summary)==6
totals={k:sum(x[k] for x in summary) for k in ['segments','turn_windows','observed_turns','observed_actions','unknown_action_intervals','complete_candidate_results']}
assert totals==dict(segments=447,turn_windows=275,observed_turns=144,observed_actions=1097,unknown_action_intervals=433,complete_candidate_results=0)
receipt=load(s/'ledger-cli-receipt.json'); assert receipt['exit_code']==0 and receipt['requested_updates']==45 and sha((s/'ledger-updates.jsonl').read_bytes())==receipt['request_sha256']
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()]; rows=load(s/'ledger-appends.json'); assert len(inputs)==len(rows)==45
assert set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs}
assert all(x['all_non_trace_fields_equal'] and x['old_where_notes_history_preserved'] and x['status_before']==x['status_after'] for x in load(s/'ledger-preservation.json'))
ledger=root/'paper/materials/learning/ledger.jsonl'; own=[]
for entry in rows:
    with ledger.open('rb') as handle:handle.seek(entry['offset']); raw=handle.read(entry['bytes'])
    row=json.loads(raw); assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update'
    assert any(all(row.get(k)==v for k,v in x.items()) for x in inputs)
    own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl'); existing=set(old.splitlines()); assert len(set(own))==45 and all(raw.rstrip(b'\n') not in existing for raw in own); added=b''.join(own)
spec=importlib.util.spec_from_file_location('owned_ledger',root/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a,z=fold(old),fold(old+added); assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']: assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
transport=load(pub/'notice-transport-readback.json'); assert transport['ack_cli_exit']==0 and transport['notice']['ops_forwarded'] and not transport['watcher_received'] and not transport['roy_notified']
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],unchanged_clean_worktree=True,native=native,original_artifact_hashes_verified=len(artifacts),original_rows=22424,original_material_assertions=45,source=source,existing_record_function_coverage=coverage,original_consumer_receipts=consumers,consumer_totals=totals,consumer_not_reexecuted=True,owned_trace_rows=45,protected_fields_preserved=True,notification_id=transport['notice']['id'],limits=['Duplicate applies only to the existing original/guard/SL recording function. Complete candidate outcomes remain null; HP/SL calibration and the nine wide proposals remain open.','Historical dirty consumed trees/knowledge, per-hit gross damage, censored exits, copy successors, potion/route counterfactuals and independent holdout remain unknown.','RC61 F45 support location is contradicted by its F33 terminal run. Old support row and mechanism claims are preserved; notice forwarded to existing watcher inbox, actual watcher/Roy delivery remains pending.','Current native Sol6.1/xhigh is independently verified and separate from producer statement that it did not inspect native context.']))
files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',s/'consumer/receipts.json',s/'consumer/summary.json',out,out.with_suffix('.err')]
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted(files):
        raw=f.read_bytes(); rel=str(f.relative_to(root)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); manifest.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',manifest)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'forward-location.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0101原004302-s2策略done0/no-source处置核，81275干净WT/HEAD不变、9waiting及1记录功能duplicate/原cf72bd真实live祖先六叶全等；只闭合原选/护栏/SL区分记录，不闭整线兑现或SL血价宽父。15叶14同1历史Roy-Dai注释差/真实祖先核，原22424材料行产物/77原件SHA及45限定断言核；六原离线输入/输出SHA核，447段275窗144观察端点、1097动作端点/433未知、全候选结果0认证，不重跑/不当生产测试。45所属CLI纯where/note原输入/输出ID/offset/bytes/SHA核，私有fold旧claim/首证/prior/证据/状态/版本及history/notes/where保，不重复CLI或降级shipped。旧silent-0005 RC61/F45支持定位与实际F33终局矛盾亲核，非机制反例，保原行；普通原f165提案来源通知{transport["notice"]["id"]}经现有收件箱双写并CLI仅ops_forwarded，watcher本人读取/告知Roy回执pending，不代ACK/新造父项或实验。原current native Sol6.1/xhigh/input/lease/workspace-write/no-network核，与学习者未独立核原生说明分列保留；历史dirty消费/逐源毛伤/药价反事实和独立留出未知保持。仅本人记录/45追溯提交，保并行记录；无新源码/知识/版本/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作。证据paper/materials/20261016-0101-ops/。\n'
note=f'\n- {at} [运维 codex] 原004302-s2九waiting，一项原选/护栏/SL记录功能由既有cf72bd源码覆盖，无本批上线。45所属追溯已核；RC61/F45旧证据定位勘误已依原提案通知{transport["notice"]["id"]}实际转入现有watcher收件箱，watcher读取及Roy告知仍pending。回执paper/materials/20261016-0101-ops/。\n'
appends=load(p/'notice-appends.json')
for path,text in {'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}.items():
    appends[path]=appends.get(path,'')+text
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(p/'own-appends.json',appends)
write(pub/'completion.json',dict(at=at,batch=bid,waiting=9,existing_record_function_duplicate=1,owned_trace_rows=45,protected_fields_preserved=True,notice_id=transport['notice']['id'],ops_forwarded=True,watcher_received=False,roy_notified=False,no_new_source_tests_merge_or_release=True,wide_parents='remain open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
    copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0
print(json.dumps(dict(waiting=9,duplicate=1,owned_trace_rows=45,ledger_check=0,paths=len(entries))))

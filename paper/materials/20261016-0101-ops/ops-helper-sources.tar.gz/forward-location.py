from pathlib import Path
import hashlib, json, subprocess, sys

root=Path.cwd(); p=root/'ops/codex-ops/record-staging/20261016-0101'; pub=root/'paper/materials/20261016-0101-ops'
sys.path.insert(0,str(root/'ops'))
import learning_requests as flow
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def write(f,d): f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
bid='20261016-004302-s2-strategy-proposal'
batch=json.loads((root/'ops/codex-ops/learn.json').read_text())['batches'][bid]
s=Path(batch['report']['report']).parent
proposal=next(x for x in json.loads((s/'proposals-current.json').read_text()) if x['id']=='silent-proposal-f16527e59b5cc1e0')
assert sha(Path(proposal['proposal']).read_bytes())==proposal['proposal_sha256']
before=json.loads((s/'ledger-before.json').read_text())['silent-0005']
wrong=[e for e in before['evidence'] if e.get('run')=='RC61MFQM63Y6' and e.get('floor')==45]
assert len(wrong)==1
ledger=root/'paper/materials/learning/ledger.jsonl'; matches=[]
with ledger.open('rb') as handle:
    while True:
        offset=handle.tell(); raw=handle.readline()
        if not raw: break
        row=json.loads(raw)
        if row.get('id')=='silent-0005' and any(all(e.get(k)==v for k,v in wrong[0].items() if k!='added') for e in row.get('evidence',[])):
            matches.append(dict(source=str(ledger.relative_to(root)),offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert matches
run_refs=[json.loads(line) for line in (s/'evidence/runs.evidence.jsonl').read_text().splitlines() if json.loads(line)['run_id']=='RC61MFQM63Y6']
assert len(run_refs)==1
run=run_refs[0]
with Path(run['source']).open('rb') as handle: handle.seek(run['offset']); raw=handle.read(run['bytes'])
assert sha(raw)==run['sha256'] and json.loads(raw)==run['row'] and run['row']['floor']==33 and run['row']['character']=='SILENT'
report_quote=next(line for line in (s/'report.md').read_text().splitlines() if 'RC61MFQM63Y6/F45' in line)
evidence=pub/'ledger-location-evidence.json'
write(evidence,dict(original_support=wrong[0],original_ledger_rows=matches,original_terminal_run=run,learner_exact_report_quote=report_quote,original_report=dict(path=str((s/'report.md').relative_to(root)),sha256=sha((s/'report.md').read_bytes())),scope='Evidence location only. Original claim, evidence, support role, status and all historical records retained. No gameplay mechanism change.'))
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
source=pub/'ordinary-proposal-source.json'
payload=dict(at=at,proposal_id=proposal['id'],character='silent',batch=bid,original_proposal=proposal['proposal'],original_proposal_sha256=proposal['proposal_sha256'],learner_exact_report_quote=report_quote,original_view=wrong[0],different_conclusion='旧silent-0005的RC61/F45定位超出该局F33终局，不能作为RC61 F45支持；注记提到的另外两局不因此变成RC61证据，基础机制没有被本次反驳。',evidence=dict(path=str(evidence.relative_to(root)),sha256=sha(evidence.read_bytes())),affected_ledger_ids=['silent-0005'],affected_experience_ids=['silent-footwork-block','silent-frail-card-block'],next_step='请现有watcher本人读原支持行、原run终局及学习者报告后明确告知Roy定位勘误和边界；保持旧行/claim/首证/先验/状态/版本及原提案，原owner按已有链核后续来源，不另造研究父项、重复实验或代其他角色ACK。',new_learning_parent=False,prepared_ops_source_only=True,no_other_role_ACK=True)
write(source,payload)
message=source.read_text().rstrip('\n')
state_dir=root/'ops/codex-ops'
with flow.locked(state_dir) as state:
    ident=flow.notify(root,state_dir,dict(id=proposal['id'],request_sha256=proposal['proposal_sha256']),'disagreement',message)
    notice_path=state_dir/'learning-notices'/(ident+'.json')
    notice=json.loads(notice_path.read_text())
    notice.update(notification_only=True,registered_learning_request=False,character='silent',source_batch=bid,source_evidence=dict(path=str(source.relative_to(root)),sha256=sha(source.read_bytes())))
    flow.atomic(notice_path,notice)
receipt=state_dir/'learning-notices/receipts'/(ident+'.ops-forwarded.json')
result=subprocess.run(['nice','-n','19','python3','ops/learning_requests.py','ack','--notice',ident,'--stage','ops_forwarded','--receipt',str(receipt)],capture_output=True)
(pub/'ops-forwarded-cli.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0
notice=json.loads(notice_path.read_text()); assert notice['ops_forwarded'] and not notice['watcher_received'] and not notice['roy_notified']
delivery=json.loads((state_dir/'learning-notices/receipts'/(ident+'.inbox.json')).read_text())
for rel in delivery['destinations']: assert delivery['text'] in (root/rel).read_text()
write(p/'notice-appends.json',{rel:delivery['text'] for rel in delivery['destinations']})
write(pub/'notice-transport-readback.json',dict(notice=notice,actual_ops_forwarded_receipt=json.loads(receipt.read_text()),actual_inbox_delivery=delivery,ack_cli_exit=0,watcher_received=False,roy_notified=False,channel='existing-watcher-inbox',no_new_parent_or_model_session=True))
print(json.dumps(dict(notice_id=ident,ops_forwarded=True,watcher_received=False,roy_notified=False)))

from pathlib import Path
import hashlib, importlib.util, json, statistics, subprocess, sys

sys.dont_write_bytecode = True
r = Path.cwd()
p = r / 'ops/codex-ops/record-staging/20261016-0647'
pub = r / 'paper/materials/20261016-0647-ops'
pub.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def write(f, value): f.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
run = 'DHYFWEN40SJ7'
alert_path = r / ('ops/codex-ops/module-health/' + run + '-alert.json')
alert_raw = alert_path.read_bytes()
alert = json.loads(alert_raw)
sys.path.insert(0, str(r / 'ops'))
spec = importlib.util.spec_from_file_location('health_readback', r / 'ops/module_health.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
selected = {}
raws = {}
window_receipts = {}
for lane in ['decisions', 'brain', 'plans', 'config']:
    window = alert['coverage'][lane]
    file = Path(window['path'])
    rows, raw_rows = [], []
    digest = hashlib.sha256()
    with file.open('rb') as handle:
        assert file.stat().st_size >= window['end']
        handle.seek(window['start'])
        while handle.tell() < window['end']:
            offset = handle.tell()
            raw = handle.readline(window['end'] - offset)
            digest.update(raw)
            if not raw.endswith(b'\n'): continue
            row = json.loads(raw)
            belongs = m.run_of(row) == run or (lane == 'plans' and m.obj(row.get('plan')).get('runId') == run)
            if not belongs: continue
            row['_source'] = dict(offset=offset, length=len(raw), sha256=sha(raw))
            rows.append(row)
            raw_rows.append(raw)
    selected[lane], raws[lane] = rows, raw_rows
    window_receipts[lane] = dict(source=str(file.relative_to(r)), start=window['start'], end=window['end'], frozen_window_sha256=digest.hexdigest(), matched_rows=len(rows), original_complete=window['complete'], malformed=window.get('malformed', 0))
    (p / (lane + '-selected.jsonl')).write_bytes(b''.join(raw_rows))
assert len(selected['config']) == 1
config = selected['config'][0]
recomputed = m.summarize(config, selected['decisions'], selected['brain'], alert['coverage'], selected['plans'])
write(p / 'recomputed-summary.json', recomputed)
different = [k for k in recomputed if k != 'at' and recomputed[k] != alert.get(k)]
print('different summary keys', different, flush=True)
assert {k: v for k, v in recomputed.items() if k != 'at'} == {k: v for k, v in alert.items() if k not in ['at', 'queue_name']}
failure_rows = []
for item in alert['computation']['evidence']:
    source = item['source']
    row = next(x for x in selected['decisions'] if x['_source'] == source)
    assert row['boss_sim']['completion'] == item['completion']
    failure_rows.append(row)
assert len(failure_rows) == 3
completions = [x['boss_sim']['completion'] for x in failure_rows]
assert [x['attempts'] for x in completions] == [1, 2, 3]
assert [x['status'] for x in completions] == ['pending', 'pending', 'degraded']
assert len({x['key'] for x in completions}) == 1
assert all(x['samples'] == 0 and x['requested'] == 600 and x['failure'] for x in completions)
assert all('nonpositive-hp' in str(x['reasons']) and '3510836362' in str(x['reasons']) for x in completions)
with (pub / 'original-failure-decisions.jsonl').open('wb') as out:
    with (r / 'logs/decisions.jsonl').open('rb') as source:
        for row in failure_rows:
            ref = row['_source']
            source.seek(ref['offset'])
            raw = source.read(ref['length'])
            assert sha(raw) == ref['sha256']
            out.write(raw)
print('failure row keys', list(failure_rows[-1]), flush=True)
print('degraded question', {k: failure_rows[-1].get(k) for k in ['ts', 'decision_id', 'question_id', 'label', 'floor', 'action', 'result', 'response']}, flush=True)
near_brains = [x for x in selected['brain'] if x.get('ts', '') >= failure_rows[0]['ts']]
print('near brains', [{k: x.get(k) for k in ['ts', 'question_id', 'decision_id', 'accepted', 'label', 'model']} for x in near_brains], flush=True)
phases = alert['diagnostics']
times = [x['simMs'] for x in phases if isinstance(x.get('simMs'), (int, float))]
assert len(phases) == 43 and len(times) == 43
times.sort()
percentile = lambda q: times[int((len(times) - 1) * q)] + (times[min(int((len(times) - 1) * q) + 1, len(times) - 1)] - times[int((len(times) - 1) * q)]) * (((len(times) - 1) * q) % 1)
(pub / 'original-alert.json').write_bytes(alert_raw)
(pub / 'original-run-config.jsonl').write_bytes(b''.join(raws['config']))
write(pub / 'module-health-byte-readback.json', dict(run_id=run, original_alert_binding=dict(path=str(alert_path.relative_to(r)), bytes=len(alert_raw), sha256=sha(alert_raw)), source_windows=window_receipts, exact_same_summary_recomputed=True, original_alert=alert, module_health_source_sha256=sha((r / 'ops/module_health.py').read_bytes()), decision_failure_rows=[dict(source=x['_source'], ts=x['ts'], completion=x['boss_sim']['completion']) for x in failure_rows], failure_chain='existing silent-0332 / silent-proposal-5aa2672bd7cd1bf4; new seed3510836362, original positive-HP resource contract unchanged', b3_timing=dict(attempts=43, p50_ms=percentile(.5), p90_ms=percentile(.9), max_ms=max(times), note='Observed B3 computation time only; no causal CPU claim or sample-work-to-time saving inference'), on_agreement=None, no_raw_rewrite_or_reexecution=True, no_game_action=True))
print(json.dumps(dict(run_id=run, summary_exact=True, raw_rows={k: len(v) for k, v in selected.items()}, failures=3, degraded=1, adaptive=93, b3_applicable=38, b3_with_DPR=38, p50_ms=percentile(.5), p90_ms=percentile(.9), max_ms=max(times))), flush=True)

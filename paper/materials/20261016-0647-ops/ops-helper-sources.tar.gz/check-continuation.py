from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
r = Path.cwd()
p = r / 'ops/codex-ops/record-staging/20261016-0647'
pub = r / 'paper/materials/20261016-0647-ops'
sys.path.insert(0, str(r / 'ops'))
spec = importlib.util.spec_from_file_location('read_only_health', r / 'ops/module_health.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
rows = [json.loads(x) for x in (p / 'decisions-selected.jsonl').read_text().splitlines()]
failures = [x for x in rows if x.get('boss_sim', {}).get('completion', {}).get('failure')]
last = failures[-1]
original_binding = json.loads((pub / 'module-health-byte-readback.json').read_text())['decision_failure_rows'][-1]
assert original_binding['completion'] == last['boss_sim']['completion']
last['_source'] = original_binding['source']
assert all(x.get('chosen') is None and not x.get('request_ids') and x['result'] == 'not dispatched: required boss evaluation pending' for x in failures[:2])
assert last['result'] == 'completed: Action completed.' and last['selection_dispatch']['returned_status'] == 'completed'
criteria = last['questions']['plan']['criteria']
assert m.dpr_count(criteria) == 0 and last['boss_sim']['available'] is False
allowed = {'plays', 'result', 'hp_lost', 'damage_dealt', 'enemies_after', 'block_gained', 'hp_after', 'hp_after_pct', 'dmg', 'lethal_now', 'enemy_threat_next', 'setup_turn', 'scaling_gained', 'block_wasted', 'potions_used', 'quantitative_turn', 'rollout', 'rollout_turns', 'history_estimate', 'rollout_best'}
assert len(criteria) == 3 and all(set(json.loads(v)) <= allowed for v in criteria.values())
b3 = [x for x in rows if x.get('mode') == 'play' and x.get('label') in m.LABELS and m.obj(m.obj(x.get('questions')).get('pick')).get('type') == 'choice' and not m.obj(x.get('boss_sim')).get('skipped')]
values = sorted(x['boss_sim']['ms'] for x in b3)
assert len(values) == 43 and max(values) == 60090
def percentile(q):
    index = (len(values) - 1) * q
    return values[int(index)] + (values[min(int(index) + 1, len(values) - 1)] - values[int(index)]) * (index % 1)
proof = dict(run_id='DHYFWEN40SJ7', pending_no_dispatch=2, degraded_zero_samples=True, requested=600, minimum_unchanged=300, no_whole_fight_numbers_attached=True, local_turn_rollout_history_fields_preserved=True, criteria_keys={k: list(json.loads(v)) for k, v in criteria.items()}, chosen=last['chosen'], result=last['result'], selection_dispatch=last['selection_dispatch'], request_ids=last['request_ids'], decision_source=last['_source'], bounded_brain_log_does_not_include_this_combat_request=True, brain_acceptance_not_independently_claimed=True, full_resources_steps_and_root_cause='unknown; original error suffix truncated', B3_full_computation_timing=dict(n=43, p50_ms=percentile(.5), p90_ms=percentile(.9), max_ms=max(values)), phase_simMs_separate='See module-health-byte-readback.json; neither timing is a causal saving claim.', no_game_or_threshold_change=True)
(pub / 'C1-degraded-action-readback.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(pending_not_dispatched=2, zero_sample_degraded_completed=True, whole_fight_numbers_absent=True, B3_full_ms=proof['B3_full_computation_timing'])))

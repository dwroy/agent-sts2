from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, tarfile

sys.dont_write_bytecode = True
r = Path.cwd()
p = r / 'ops/codex-ops/record-staging/20261016-0647'
pub = r / 'paper/materials/20261016-0647-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda f: json.loads(f.read_text())
def write(f, value): f.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def git(*a): return subprocess.check_output(['git', *a], stderr=subprocess.PIPE)
assert not (p / 'own-appends.json').exists()
health = load(pub / 'module-health-byte-readback.json')
continuation = load(pub / 'C1-degraded-action-readback.json')
rejected = load(pub / 'B4-rejection-readback.json')
base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(at, flush=True)
canonical = load(r / 'ops/codex-ops/learn.json')
owner = canonical['batches']['20261016-064301-fix-batch']
proc = Path('/proc') / str(owner['pid'])
owner_state = dict(batch='20261016-064301-fix-batch', state=owner['state'], task=owner['task'], reason=owner['reason'], pid=owner['pid'], worktree=owner['worktree'], input_unchanged=True, no_message_or_new_dispatch=True)
if proc.exists():
    raw_stat = (proc / 'stat').read_text()
    owner_state.update(observed_birth=raw_stat[raw_stat.rfind(')') + 2:].split()[19], launcher_cwd=str((proc / 'cwd').resolve()))
write(pub / 'existing-owner-readback.json', dict(at=at, existing_issue='silent-0332', proposal='silent-proposal-5aa2672bd7cd1bf4', current_normal_fix_owner=owner_state, action='Append this reproduction to the existing issue for normal queue consumption; no hot input replacement or duplicate assignment.'))
timing = continuation['B3_full_computation_timing']
note = f'\n- {at} [ops 0647 两事件] THE_INSATIABLE B4原061302-fix/evidence446327db6b216a9890bd98beec82bc07113bc140bfa107ee870c45b42b666167维持rejected/rc0/mergednull；无源码候选、before/after同e138控制，当前重放62/1138且val0，原验收因overall validation coverage mismatch拒绝。tsc0/Vitest主动中止130与首次探针/夹具失败均保，不补造全量绿/源码修复或版本；0492原fight/rejected/首证A0行精确纳入，独立于校准20 V5-R366。DHYFWEN40SJ7原完整告警按冻结窗口逐offset/bytes/SHA复算全等：710决策/51脑/12计划/1配置；F48同seed3510836362资源nonpositive-hp三失败，前两pending不派发、第三degraded n0/600不带整战数字，原本地回合/rollout/历史字段保持，play_card实际returned completed（仅首动作，不证整轮/整战；有界brain原窗不含本B2请求，不另冒脑accepted/模型验收）。101必需尝试3失败1降级，C2 on93/93/errors0/unknown0、一致率null；B3原43题38适用均DPR、5明确不支持/2skip分列，最低配对300；43次完整计算p50={timing["p50_ms"]:.1f}/p90={timing["p90_ms"]:.1f}/max60090ms，与diagnostics.simMs/样本工作分列、不作因果节时结论。construction49/49送达且accepted、10结构计划保存/46读回/8checkpoint，概率校准pending非服务故障；P1 43/43、P3 55/55、P2 43/43/38脑accepted/8理由均无缺，低可信和符号拒收不放宽。仅向原0332/5aa2672旧链追加证据，现原064301普通fix owner输入不改，不另派学习或重启/降门槛；根因及宽父保持。按要求无常规watcher/Roy转达。证据paper/materials/20261016-0647-ops/。\n'
decision = f'\n- {at} 运维codex：0647原B4拒收与DHY模块异常分别核完，拒收不是上线或已修。原061302-fix THE_INSATIABLE immutable evidence446327db/base e138，分支ecf8d687c仅24报告/数据叶、agent树逐blob不变；原生Sol6.1/xhigh/原沙箱/输入/lease实核，原九场76帧材料检查不当完整Vitest，tsc0/vitest130/重放62/1138/val0/验收coverage mismatch及全部初稿失败保留；不重跑/兜底合入/分号，0492原CLI add/rejected完整来源纳入，原十新战斗+新校准自动冷却保持，校准20/R366不受此无候选批回滚。DHY原alert冻结四流完整窗口复算计数全等，三F48失败原字节同seed3510836362、won=true/died=false/14turns后成功资源nonpositive-hp，完整resources/steps截断/机制根因未知；两pending无请求派发→第三degraded零样本不带整场数/首动作completed，不能称修复资源契约或整战兑现。原0332/5aa2672 pending/旧资源链去重补证，既有064301普通fix原输入保持，不热替/新父/研究/实现或发重复通知。P1/P2/P3/C2与construction无接线缺口，B3 38/38适用DPR/5unsupported分列、原300最低不动，43完整B3耗时max60090ms与阶段simMs和样本工作节省分账，脑原窗不含本B2请求的边界如实保留。只记录及既有队列补证，不改源码/live/账号home模型prompt/预算/当前局，按模块健康要求不常规回报watcher/Roy、不关闭宽父。私有读回脚本初次重复关键字、计划runId层级及boss launch batch身份过严断言失败保留、按原字段修正后计数全等，不算产品故障；回执paper/materials/20261016-0647-ops/。\n'
queue = f'\n- {at} [原 **silent-0332 / silent-proposal-5aa2672bd7cd1bf4** 复现补证，不新增缺陷/重复派修] DHYFWEN40SJ7 Silent原e716bd2+12知识/笔记dirty进程F48，seed3510836362三次同key：成功首战won=true/died=false/14turns后nonpositive-hp资源接续错误，原尾部截断，完整resources/steps/机制根因仍未知。前两pending无动作/无request，第三C1 degraded n0/600，保300最低不出整战数字，现有回合/rollout字段保持，cf6e816b-cbb0-497a-b359-ac3d12b2cf87首play_card实际completed；不是当前卡死/资源契约已修，有界脑窗未含此B2请求不冒称独立脑accepted。原101必需尝试3fail1degraded，其余C2 93/93与38/38适用B3、P1/P2/P3和construction接线完好；43次B3完整耗时p50={timing["p50_ms"]:.1f}/p90={timing["p90_ms"]:.1f}/max60090ms，阶段simMs和on样本工作分别保留，不以负载推因果。现20261016-064301-fix-batch原普通owner/PID{owner["pid"]}输入与线程不动，本新证据沿原队列后续消费；不热注入/另派学习研究/变300门槛/改预算或重启。原RQ三组、旧0332/5aa2672及宽父保持pending。证据paper/materials/20261016-0647-ops/module-health-byte-readback.json、original-failure-decisions.jsonl、C1-degraded-action-readback.json。\n'
handoff = f'\n- {at} 0647两事件已记录：061302 THE_INSATIABLE B4维持rejected/no source/no live/no version，0492原add/rejected与原tsc0/Vitest130/62of1138/val0保留；无补验或新派。DHY模块原三次F48 seed3510836362 nonpositive-hp沿原0332/5aa2672补队列，前两pending不派发→第三n0 degraded首动作completed，仅保护出口，完整resources/steps与根因未修。全部告警计数按原窗口重算一致，P1/P2/P3/C2/construction无缺口，B3 38of38适用/5不支持分列、最低300不改；当前064301普通fix原owner输入不动，不热改或重复派学习。无需常规watcher/Roy通知，不把B4失败与已发布校准20/R366混回滚；回执paper/materials/20261016-0647-ops/。\n'
appends = {'ops/inbox-dev.md': note, 'paper/materials/decision-log.md': decision, 'notes/fix-queue-v4.md': queue, 'notes/ops-handoff.md': handoff}
write(p / 'own-appends.json', appends)
values = {}
for path, text in appends.items():
    with (r / path).open('ab') as f: f.write(text.encode())
    values[path] = git('show', base + ':' + path) + text.encode()
old = git('show', base + ':paper/materials/learning/ledger.jsonl')
row = (p / 'owned-rejection-ledger.jsonl').read_bytes()
assert row.rstrip(b'\n') not in set(old.splitlines())
values['paper/materials/learning/ledger.jsonl'] = old + row
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x])
a, z = fold(old), fold(old + row)
assert set(z) == set(a) | {'silent-0492'} and all(a[k] == z[k] for k in a)
assert z['silent-0492']['status'] == 'rejected' and not z['silent-0492']['version']
write(pub / 'record-registration.json', dict(at=at, base=base, original_rejected_ledger_rows=1, source_edits=0, live_edits=0, tests_rerun=0, behavior_versions=0, game_actions=0, new_task_dispatches=0, original_issue='silent-0332', existing_owner=owner_state, health_recomputed_equal=True, no_routine_watcher_or_Roy_notification=True, wide_parents='remain open'))
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    helpers = []
    for f in sorted(p.glob('*.py')):
        raw = f.read_bytes()
        archive.add(f, arcname=f.name, recursive=False)
        helpers.append(dict(path=str(f.relative_to(r)), bytes=len(raw), sha256=sha(raw)))
write(pub / 'ops-helper-manifest.json', helpers)
with tarfile.open(pub / 'ops-attempt-logs.tar.gz', 'w:gz') as archive:
    for f in sorted(p.iterdir()):
        if f.is_file() and f.suffix in ['.stdout', '.stderr']: archive.add(f, arcname=f.name, recursive=False)
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'
entries = []
for path, raw in values.items():
    f = dest / path
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(p / 'record-manifest.json', dict(base=base, paths=entries))
check = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
print(json.dumps(dict(paths=len(entries), ledger_rows=1, rejected=True, original_issue='silent-0332', ledger_check=0, no_source_or_live_mutation=True)))

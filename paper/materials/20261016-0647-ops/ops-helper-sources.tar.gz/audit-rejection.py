from pathlib import Path
import hashlib, json, re, subprocess, tarfile

root = Path.cwd()
p = root / 'ops/codex-ops/record-staging/20261016-0647'
pub = root / 'paper/materials/20261016-0647-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda f: json.loads(f.read_text())
def write(f, value): f.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
bid = '20261016-061302-fix-batch'
canonical = load(root / 'ops/codex-ops/learn.json')
batch = canonical['batches'][bid]
scratch = root / 'learner/runs/20261016-061312-e713e995-d386-4486-a57a-ded73eada8ca-boss-sim-batch'
report = load(scratch / 'report.json')
report['report'] = str(scratch / 'report.md')
checks = load(scratch / 'checks.json')
acceptance = load(scratch / 'acceptance.json')
assert batch['state'] == 'rejected' and batch['rc'] == 0 and batch['merged'] is None
assert batch['rejection'] == ['overall validation coverage mismatch']
assert checks['vitest'] == 130 and checks['full_replay'] == 130 and checks['tsc'] == 0
assert acceptance['accepted'] is False and acceptance['improved'] == []
assert acceptance['inputs']['before']['sha256'] == acceptance['inputs']['after']['sha256']
assert sha(Path(acceptance['inputs']['before']['path']).read_bytes()) == acceptance['inputs']['before']['sha256']
assert Path(acceptance['inputs']['before']['path']).read_bytes() == Path(acceptance['inputs']['after']['path']).read_bytes()
for key in ['base', 'head']:
    assert acceptance['isolation'][key] == batch['base']
assert acceptance['isolation']['passed'] and acceptance['isolation']['shared_changes'] == []
wt = Path(batch['worktree'])
git = lambda *a: subprocess.check_output(['git', '-C', str(wt), *a], stderr=subprocess.PIPE)
head = git('rev-parse', 'HEAD').decode().strip()
records = load(scratch / 'records-commit.json')
assert head == records['commit'] and not git('status', '--porcelain', '--untracked-files=no').strip()
changed = git('diff', '--name-only', batch['base'], head).decode().splitlines()
assert len(changed) == 24 and all(path.startswith('paper/materials/') for path in changed)
assert git('rev-parse', batch['base'] + ':agent').strip() == git('rev-parse', head + ':agent').strip()
helper = (root / 'ops/codex-ops/record-staging/20261016-0625/readonly-runtime.py').read_text().replace('launch["task"] == "silent-boss-calibration"', 'launch["task"] == "boss-sim-batch"')
helper = helper.replace('assert registered_batch is None and launch["task"] == "boss-sim-batch"', 'assert registered_batch == bid and launch["task"] == "boss-sim-batch"')
exec(helper)
out = root / ('ops/codex-ops/learner/' + bid + '.out')
native = runtime(bid, report, out.read_text(), worktree=wt)
ledger = root / 'paper/materials/learning/ledger.jsonl'
rows = []
with ledger.open('rb') as f:
    while True:
        offset = f.tell()
        raw = f.readline()
        if not raw: break
        row = json.loads(raw)
        if row.get('id') == 'silent-0492':
            assert row['op'] == 'add' and row['status'] == 'rejected' and row['kind'] == 'fight'
            assert row['first_run'] == 'C48LLXBGKXQ9' and row['character'] == 'silent'
            assert row.get('version') is None and batch['key'] in row['note']
            rows.append(dict(offset=offset, bytes=len(raw), sha256=sha(raw), raw=raw))
assert len(rows) == 1
(p / 'owned-rejection-ledger.jsonl').write_bytes(rows[0]['raw'])
manifest = []
with tarfile.open(pub / 'original-B4-rejection-artifacts.tar.gz', 'w:gz') as archive:
    files = [scratch / n for n in ['report.md', 'report.json', 'checks.json', 'acceptance.json', 'completion-precheck.json', 'records-commit.json', 'ledger-receipt.json', 'split-audit.json', 'raw-target-summary.json', 'raw-turn-coverage.json', 'same-source-reuse.json', 'compiled-original-comparison.json', 'mechanic-fixtures-results.json', 'mechanic-fixtures-first-failed.log', 'draft-failures.txt', 'gitleaks-first.log', 'gitleaks-final.log', 'gitleaks-final.json', 'artifact-manifest.json', 'coverage.json', 'sandbox.log', 'acceptance.log', 'split.json', 'before-provenance.json', 'after-provenance.json']]
    files += [out, out.with_suffix('.err')]
    for f in files:
        if not f.exists(): continue
        raw = f.read_bytes()
        archive.add(f, arcname=f.name, recursive=False)
        manifest.append(dict(path=str(f.relative_to(root)), member=f.name, bytes=len(raw), sha256=sha(raw)))
write(pub / 'original-B4-artifact-manifest.json', manifest)
write(pub / 'B4-rejection-readback.json', dict(batch=bid, evidence_key=batch['key'], canonical_state='rejected', canonical_rc=0, merged=None, reason=batch['rejection'], acceptance=acceptance, checks=checks, native=native, source_base=batch['base'], records_commit=head, record_only_paths=changed, production_agent_tree_unchanged=True, ledger=[{k: v for k, v in row.items() if k != 'raw'} for row in rows], raw_scope=load(scratch / 'raw-target-summary.json'), fixed_split=load(scratch / 'split-audit.json'), replay_completed=62, replay_requested=1138, current_validation_coverage=0, fixture_fights=9, fixture_turn_frames=76, disposition='Original rejected/cooldown/bounded-retry state retained; no candidate, fallback merge, release, full rerun or new model dispatch.', not_equivalent_to='No claim of complete validation, mechanism correctness or actual A11 coverage; old fixed-model trigger is not current-source validation. No new contradictory mechanism or role notification inferred.', calibration20='Published independently as V5-R366; not rolled back by this no-candidate rejected B4 batch.'))
print(json.dumps(dict(batch=bid, state='rejected', source_changed=False, ledger_rows=1, records_only=24, original_tests=dict(tsc=0, vitest=130), native_model_verified=True)))

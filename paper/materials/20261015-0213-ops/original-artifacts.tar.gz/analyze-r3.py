"""Separate observed facts, conditional replay, missing attribution and source/tool failures."""
from pathlib import Path
import collections,gzip,hashlib,json,statistics
ROOT=Path('/home/dw/Projects/agent-sts2');HERE=Path(__file__).resolve().parent

def load(n):return json.loads((HERE/n).read_text())
def lines(n):return [json.loads(l) for l in (HERE/n).read_text().splitlines() if l.strip()]
def write(n,d):(HERE/n).write_text(json.dumps(d,ensure_ascii=False,indent=1)+'\n')
def digest(b):return hashlib.sha256(b).hexdigest()
def stats(values):
 if not values:return {'n':0,'mean':None,'mae':None,'median':None,'p10':None,'p90':None,'min':None,'max':None,'exact':0}
 s=sorted(values);return {'n':len(s),'mean':sum(s)/len(s),'mae':sum(abs(x) for x in s)/len(s),'median':statistics.median(s),'p10':s[int(.1*(len(s)-1))],'p90':s[int(.9*(len(s)-1))],'min':s[0],'max':s[-1],'exact':sum(x==0 for x in s)}
plan=load('holdout-preregistration.json');attempts=load('attempts.json');ex=lines('executions.jsonl');rs=lines('replay-results.jsonl');turns=lines('whole-turn-results.jsonl');selections=load('selection-boundaries.json');jev=load('jev-overlap.json')
states={}
with gzip.open(HERE/'states.raw.jsonl.gz','rb') as f:
 for b in f:states[digest(b)]=json.loads(b)['state']
with gzip.open(HERE/'selection-states.raw.jsonl.gz','rb') as f:
 for b in f:states[digest(b)]=json.loads(b)['state']
byid={r['id']:r for r in rs};exe={r['id']:r for r in ex}
additional=[r for r in selections['actions'] if not r['existing_execution_row']]
all_actions=ex+additional
hand_mismatch=set();identity_shift=set();initial_mismatch=set();annotations=[];residuals=collections.defaultdict(list)
for r in rs:
 if r['status']!='replayed_observed_step':continue
 actual=r['actual'];before=actual['before'];after=actual['after'];initial=r['replay']['initial'];last=r['replay']['transitions'][-1]['after'] if r['replay']['transitions'] else initial
 oldids={e['index']:e['id'] for e in before['enemies']};newids={e['index']:e['id'] for e in after['enemies']};shift=any(i in newids and newids[i]!=eid for i,eid in oldids.items());missing=any(i not in newids for i in oldids)
 if shift or missing:identity_shift.add(r['id'])
 initial_diff={k:{'model':initial.get(k),'actual':before.get(k)} for k in ['hp','energy','block'] if initial.get(k)!=before.get(k)}
 if initial_diff:initial_mismatch.add(r['id'])
 hand_diff=False
 if r['action']['action']!='end_turn':
  hand_diff=sorted(last['hand'])!=sorted(c['id'] for c in after['hand'])
  if hand_diff:hand_mismatch.add(r['id'])
 pool={}
 if r['action']['action']!='end_turn':
  model_hp=collections.defaultdict(float);actual_hp=collections.defaultdict(float)
  for e in last['enemies']:
   if e['index'] in oldids:model_hp[oldids[e['index']]]+=e['hp']
  for e in after['enemies']:actual_hp[e['id']]+=e['hp']
  # Compare named observed active pools only; absent actual entities stay unknown, never filled with zero.
  for eid,value in model_hp.items():
   pool[eid]={'model_active_pool_hp':value,'actual_observed_active_pool_hp':actual_hp[eid] if eid in actual_hp else None,'residual':value-actual_hp[eid] if eid in actual_hp else None,'actual_effective_damage':None}
   if pool[eid]['residual'] is not None:residuals[r['split'],'named_enemy_active_pool_hp'].append(pool[eid]['residual'])
 for metric,value in r.get('errors',{}).items():
  if value is not None:residuals[r['split'],metric].append(value['residual'])
 annotations.append({'id':r['id'],'split':r['split'],'attempt_key':r['attempt_key'],'enemy_index_changed_or_absent':shift or missing,'initial_input_representation_difference':initial_diff,'observed_hand_differs_from_replay':hand_diff,'model_unknown_hand':last['unknownHand'],'model_reported_unknown':r['unknown'],'named_enemy_active_pool':pool,'actual_raw_enemy_damage':None,'actual_S':None})
write('replay-endpoint-audit.json',{'annotations':annotations,'hand_mismatch_ids':sorted(hand_mismatch),'enemy_identity_shift_ids':sorted(identity_shift),'initial_representation_mismatch_ids':sorted(initial_mismatch),'scope':'Slotwise differences remain original diagnostics; named active-pool observations do not fabricate missing target HP or raw damage.'})
selection_turns={key for r in selections['actions'] for key in r['turn_keys']}
qualified=[];turn_limits=[]
for r in turns:
 if r['status']!='forced_observed_turn_replayed':continue
 reasons=[]
 if r['key'] in selection_turns:reasons.append('additional actual selection boundary')
 if any(a['id'] in hand_mismatch for a in r['source_actions']):reasons.append('actual hand change not fully reproduced; hidden draw or generated identity unresolved')
 if any(a['id'] in initial_mismatch for a in r['source_actions']):reasons.append('initial representation difference')
 if reasons:turn_limits.append({'key':r['key'],'split':r['split'],'reason':reasons})
 else:qualified.append(r)
write('whole-turn-window-audit.json',{'forced_results_retained':len([r for r in turns if r['status']=='forced_observed_turn_replayed']),'strict_same_observed_hand_window':len(qualified),'posthoc_window_limitations':turn_limits,'qualified_keys':[r['key'] for r in qualified],'not_a_new_model_fit':True,'whole_fight_replays':0})
resource_rows=[]
for a in attempts:
 actions=[r for r in ex if r['attempt_key']==a['key']];confirmed=[r for r in actions if r['confirmed_execution']];first_play={};drinks=[];heal_observations=[];revival_changes=[]
 for r in confirmed:
  pre=states[r['pre']['sha256']];post=states[r['post']['sha256']];intent=r['action'];player=pre.get('combat',{}).get('player',{});after_player=post.get('combat',{}).get('player',{});hp0=player.get('current_hp');hp1=after_player.get('current_hp',post.get('run',{}).get('current_hp'))
  if intent['action']=='play_card':
   card=next((c for c in pre.get('combat',{}).get('hand',[]) if c.get('index')==intent.get('card_index')),None)
   if card:first_play.setdefault(card['card_id'],{'turn':r['turn'],'id':r['id'],'source':r['source'],'upgraded':card.get('upgraded')})
  if intent['action']=='use_potion':
   slot=intent.get('potion_index',intent.get('option_index',intent.get('slot')));pots=pre.get('run',{}).get('potions');selected=None
   if isinstance(pots,list):selected=next((x for i,x in enumerate(pots) if x.get('slot',x.get('index',i))==slot),None)
   drinks.append({'id':r['id'],'turn':r['turn'],'slot':slot,'observed_potion':selected,'before':pots,'after':post.get('run',{}).get('potions'),'source':r['source'],'effective_hp_gain':hp1-hp0 if isinstance(hp0,(int,float)) and isinstance(hp1,(int,float)) else None,'healing_attribution':'explicit drink with observed net HP; other simultaneous changes not fabricated'})
  if isinstance(hp0,(int,float)) and isinstance(hp1,(int,float)) and hp1>hp0:heal_observations.append({'id':r['id'],'action':intent,'before':hp0,'after':hp1,'net':hp1-hp0,'source':r['source'],'attribution':'observed net gain; separate from raw incoming damage'})
  if pre.get('run',{}).get('relics')!=post.get('run',{}).get('relics'):revival_changes.append({'id':r['id'],'source':r['source'],'before':pre.get('run',{}).get('relics'),'after':post.get('run',{}).get('relics'),'revival_confirmed':None})
 resource_rows.append({'attempt_key':a['key'],'run':a['run'],'ascension':a['ascension'],'floor':a['floor'],'turns_observed':a['turns_observed'],'attempt':a['attempt'],'first_attempt':a['first_attempt'],'split':a['split'],'actual_outcome':a['actual_outcome'],'entry_hp':a['entry_my_hp'],'entry_enemy_hp':a['entry_enemy_hp'],'sl':a['sl'],'source_config':a['execution_source_config'],'confirmed_actions':len(confirmed),'first_actual_manual_play_by_card':first_play,'drinks':drinks,'observed_hp_gains':heal_observations,'relic_resource_changes':revival_changes,'revival_count':None,'whole_core_qualification':None,'raw_enemy_received_damage':None,'effective_boss_damage_whole_window':None,'actual_whole_window_S':None,'unknown':['uncapped incoming enemy attribution not explicitly logged','manual actions do not establish automatic effect resolution count','all four core combinations not certified by per-card counts','hidden initial pile order and missing selections retained']})
sequences=[]
byrun=collections.defaultdict(list)
for a in attempts:byrun[a['run']].append(a)
for rid,aa in byrun.items():
 aa.sort(key=lambda a:a['first_ts'])
 for i,a in enumerate(aa):
  if a['floor']!=49:continue
  previous=next((b for b in reversed(aa[:i]) if b['floor']==48),None)
  sequences.append({'run':rid,'first_boss_attempt':previous['key'] if previous else None,'second_boss_attempt':a['key'],'second_entry_hp':a['entry_my_hp'],'first_terminal_state_ref':previous['last_frame'] if previous else None,'second_entry_state_offset':a['frame_offsets'][0],'first_entry_resources':previous['entry_resources'] if previous else None,'second_entry_resources':a['entry_resources'],'SL_second_boss':a['sl'],'joint_victory_probability':None,'between_boss_heal_or_potion_attribution':None,'scope':'separate observed resource boundaries, not continuous victory simulation'})
write('resource-window-ledger.json',{'attempts':resource_rows,'continuous_boss_boundaries':sequences,'actual_damage_attribution_complete_attempts':0,'whole_core_qualified_attempts':None})
# Preserve independently verifiable stable endpoints; do not assert a new generalized mechanic.
counter_ids=['ff00975b-3f5b-4bb1-b1ad-760c61bdef71','5ec6f66e-de71-4135-aec7-1df809454599'];counter=[]
for rid in counter_ids:
 r=byid[rid];pre=states[r['pre']['sha256']];post=states[r['post']['sha256']];card=next(c for c in pre['combat']['hand'] if c['index']==r['action']['card_index']);readiness=post['combat'].get('action_readiness',{})
 counter.append({'id':rid,'run':r['run'],'floor':r['floor'],'turn':r['turn'],'attempt':r['attempt'],'split':r['split'],'source':r['source'],'pre':r['pre'],'post':r['post'],'actual_card':card,'actual_before':r['actual']['before'],'actual_after':r['actual']['after'],'stable_post_readiness':readiness,'actual_selection':post.get('selection'),'model_initial':r['replay']['initial'],'model_transition':r['replay']['transitions'],'original_errors':r['errors'],'initial_model_declared_unknown':r['unknown'],'actual_full_S':None,'proposal_status':'scratch evidence and successor suggestion only; no production registration or implementation'})
write('counterexamples.json',{'cases':counter,'prior_view':'Existing frozen model exposes known/no-unknown transition fields; this flag is not evidence that physical card/resource outcomes are correct.','different_finding':'ESCAPE_PLAN endpoint has an actual new NEUTRALIZE and block2→3 while replay omits the draw and predicts block6; POISONED_STAB energy1→1 versus replay0 needs payment/refund source accounting. Conditions and original bytes are retained, no universal new card rule asserted.','affected':['roy-20261011-silent-core-cycle-quantitative-learning','v5-dpr-health-20261013','original R3/P1/P2 model reliability consumers'],'unchanged_ledger':['silent-0463'],'S_sign_hypothesis':'not independently tested: actual uncapped same-window enemy damage remains unknown','next_steps':['Original implementation owner should bind the explicit observed draw/resource fields or keep affected computations unknown; no patch is implemented in this phase.','If these holdout findings inform a new model, do not reuse these6 runs as unseen validation; preserve this split and separately freeze a later independent window.']})
summary={'population':{'runs':16,'diagnostic_train_runs':10,'holdout_runs':6,'attempts':len(attempts),'first_attempts':sum(a['first_attempt'] for a in resource_rows),'SL_retry_attempts':sum(not a['first_attempt'] for a in resource_rows),'actual_outcome_events':dict(collections.Counter(a['actual_outcome'] for a in resource_rows)),'original_frames':3494,'combat_selection_frames':len(selections['frames']),'execution_requests_including_selection':len(all_actions),'confirmed_primary_action_chains':sum(r['confirmed_execution'] for r in ex),'additional_selection_requests':len(additional)},
 'atomic_replay':load('replay-coverage-summary.json'),'whole_turn':load('whole-turn-coverage-summary.json'),'strict_complete_turn_windows':len(qualified),
 'raw_slotwise_and_named_pool_residuals':{side:{metric:stats(vals) for (s,metric),vals in residuals.items() if s==side} for side in ['train','holdout']},
 'forced_turn_hp_residuals':{side:stats([r['player_hp_residual'] for r in qualified if r['split']==side and r['player_hp_residual'] is not None]) for side in ['train','holdout']},
 'limitations':{'unreproduced_hand_change_steps':len(hand_mismatch),'enemy_index_identity_changed_steps':len(identity_shift),'input_initial_scalar_difference_steps':len(initial_mismatch),'actual_raw_enemy_attribution_attempts':0,'actual_S_valid_attempts':0,'independent_whole_fight_forward_replays':0,'new_probability_fit':False,'new_group_trust':False,'natural_two_game_acceptance':False,'retrospective_holdout_not_guaranteed_model_unseen':True},
 'Jev':{k:jev[k] for k in ['returns','followup_cases','selected_run_cases','boss_overlap_cases','choice_difference_boss_cases','API_calls_this_stage']},
 'preserved_prior':{'B2_old_withdrawn_leak':1.325,'B3_old_low_leak':1.347,'Queen_duplicate_plus2':'prior contradiction retained; no claim of repair; zero structurally complete QueenT1 forced windows in this panel','latest_frozen_historical_trust':load('frozen-model/knowledge/characters/silent/boss-trust.json')['bosses']['KNOWLEDGE_DEMON']},
 'code_changes':False,'policy_changes':False,'ledger_writes':False,'production_tests':{'tsc':None,'vitest':None,'python':None}}
write('analysis-summary.json',summary)
write('ops-forwarding-request.json',{'supplement_id':'v5-boss-revalidation-20261014-approved-supplement','parent_batch':'20261014-061302-fix-batch','thread':'01a13753-c032-73f0-aa3f-ddc0e14809cd','route':['ops','watcher','Roy'],'necessary':'new stable-frame model/observed mismatch with known flag and missing draw/resource attribution; prior B2/B3/Queen counterevidence remains','evidence':{'path':str(HERE/'counterexamples.json'),'sha256':digest((HERE/'counterexamples.json').read_bytes())},'scope':'limited R3 data validation; P0/S-sign/ranking/request/calculation-adapter owner remains exclusive','prepared_only':True,'ops_received':False,'watcher_received':False,'Roy_acknowledged':False,'reason_not_direct_written':'current task only permits own scratch writes; completion artifacts hand off the necessary notice through original ops path'})
print(json.dumps({'population':summary['population'],'atomic':summary['atomic_replay']['status'],'strict_turn_windows':len(qualified),'limits':summary['limitations'],'Jev':summary['Jev']},ensure_ascii=False))

"""Retain combat selection/choice boundaries omitted by the legacy COMBAT-only extractor."""
from pathlib import Path
import collections,datetime as dt,gzip,hashlib,json,sys
ROOT=Path('/home/dw/Projects/agent-sts2');WT=ROOT/'.worktrees/silent-boss-calibration';HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(WT/'agent/tools/logdb'));import query,sync
plan=json.loads((HERE/'holdout-preregistration.json').read_text());attempts=json.loads((HERE/'attempts.json').read_text());cutoff=dt.datetime.fromisoformat(plan['cutoff_utc']).replace(tzinfo=None)
def table(cur):return [dict(zip([d[0] for d in cur.description],r)) for r in cur.fetchall()]
def clock(v):return dt.datetime.fromisoformat(v.replace('Z','+00:00')).replace(tzinfo=None)
with sync.read_lock(str(ROOT/'data/logdb'),shared=True):
 c=query.connect(str(ROOT/'data/logdb'),threads=1)
 ds=table(c.execute("SELECT off,len,run_id,floor,turn,ts,observed_ts,action,label,result FROM decisions WHERE run_id IN (SELECT unnest(?::VARCHAR[])) AND ts<=? AND action NOT IN ('play_card','end_turn','use_potion','discard_potion') ORDER BY off",[plan['run_ids'],cutoff]))
 fs=table(c.execute("SELECT * FROM frames WHERE run_id IN (SELECT unnest(?::VARCHAR[])) AND ts<=? AND in_combat AND screen<>'COMBAT' ORDER BY off",[plan['run_ids'],cutoff]))
old={r['source']['offset'] for r in map(json.loads,(HERE/'executions.jsonl').read_text().splitlines())};rows=[];frames=[]
with (ROOT/'logs/decisions.jsonl').open('rb') as dec,(ROOT/'logs/states.jsonl').open('rb') as state,gzip.open(HERE/'selection-decisions.raw.jsonl.gz','wb') as dout,gzip.open(HERE/'selection-states.raw.jsonl.gz','wb') as sout:
 for f in fs:
  scopes=[a for a in attempts if a['run']==f['run_id'] and a['floor']==f['floor'] and clock(a['first_ts'])<=f['ts']<=clock(a['last_ts'])]
  if not scopes:continue
  state.seek(f['off']);b=state.read(f['len']);d=json.loads(b);assert d['state'].get('in_combat') is True
  ref={'path':str(ROOT/'logs/states.jsonl'),'offset':f['off'],'bytes':f['len'],'sha256':hashlib.sha256(b).hexdigest()};sout.write(b)
  frames.append({'source':ref,'attempt_keys':[a['key'] for a in scopes],'ts':f['ts'].isoformat(),'observed_ts':f.get('observed_ts').isoformat() if f.get('observed_ts') else None,'turn':f['turn'],'screen':f['screen'],'fingerprint':f['fingerprint'],'selection':d['state'].get('selection')})
 for d in ds:
  scopes=[a for a in attempts if a['run']==d['run_id'] and a['floor']==d['floor'] and clock(a['first_ts'])<=d['ts']<=clock(a['last_ts'])]
  if not scopes:continue
  dec.seek(d['off']);b=dec.read(d['len']);raw=json.loads(b);ref={'path':str(ROOT/'logs/decisions.jsonl'),'offset':d['off'],'bytes':d['len'],'sha256':hashlib.sha256(b).hexdigest()};dout.write(b)
  nearby=[f for f in frames if any(a['key'] in f['attempt_keys'] for a in scopes) and f['fingerprint']==raw.get('fingerprint')]
  observed=d.get('observed_ts') or d['ts'];nearby.sort(key=lambda f:abs((clock(f['observed_ts'] or f['ts'])-observed).total_seconds()))
  pre=nearby[0] if nearby else None
  if pre:
   state.seek(pre['source']['offset']);bstate=state.read(pre['source']['bytes']);assert hashlib.sha256(bstate).hexdigest()==pre['source']['sha256'];ps=json.loads(bstate)['state']
  else:ps=None
  keys=[]
  for a in scopes:
   if d['turn'] is not None:keys.append(a['key']+':T'+str(d['turn']))
  rows.append({'id':raw.get('decision_id'),'source':ref,'run':d['run_id'],'floor':d['floor'],'turn':d['turn'],'attempt_keys':[a['key'] for a in scopes],'turn_keys':keys,'action':raw.get('chosen'),'label':raw.get('label'),'receipt':raw.get('result'),'existing_execution_row':d['off'] in old,'original_prediction':{k:raw.get(k) for k in ['answers','rationale','expect','reasked','sl_attempt','sl_reloads']},'pre_frame':pre,'actual_selection':ps.get('selection') if ps else None,'boundary_ambiguity':None if pre else 'exact selection frame not found; action retained without completed-mechanics claim'})
(HERE/'selection-boundaries.json').write_text(json.dumps({'frames':frames,'actions':rows,'scope':'Observed in-combat selections; no selection decision is treated as an unobserved zero or omitted core component.','missing_from_legacy_action_scope':sum(not r['existing_execution_row'] for r in rows)},ensure_ascii=False,indent=1)+'\n')
print(json.dumps({'in_combat_selection_frames':len(frames),'selection_actions':len(rows),'added_actions':sum(not r['existing_execution_row'] for r in rows),'action_types':dict(collections.Counter(r['action']['action'] for r in rows))}))

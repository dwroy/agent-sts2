/** Offline evidence harness: reuse frozen input assembly and exact transition replay. */
import { appendFileSync, readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeKnowledge } from './frozen-model/agent/src/knowledge/index.js';
import { parseGameState } from './frozen-model/agent/src/hand/mod/schema.js';
import { setKnowledgeCharacter } from './frozen-model/agent/src/knowledge/files.js';
import { boardOf } from './frozen-model/agent/tools/boss-sim/backtest-board.js';
import { traceSteps, type Step } from './frozen-model/agent/src/reflex/turn-solver.js';
import { rolloutLiveOptions } from './frozen-model/agent/src/reflex/rollout-live.js';
import { bossLinesOptions } from './frozen-model/agent/src/sim/boss-lines.js';
const here=dirname(fileURLToPath(import.meta.url));
const digest=(b:string|Buffer)=>createHash('sha256').update(b).digest('hex');
const model=join(here,'frozen-model');
setKnowledgeCharacter('silent');
// These process-local observations suppress autonomous forecasts; no production setting is touched.
rolloutLiveOptions.enabled=false;
bossLinesOptions.enabled=false;
const metadata=JSON.parse(readFileSync(join(model,'data/game-data.json'),'utf8'));
const knowledge=makeKnowledge(metadata.collections,'cache');
const db=JSON.parse(readFileSync(join(model,'knowledge/common/monster-db.json'),'utf8')).monsters;
const mm=JSON.parse(readFileSync(join(model,'knowledge/common/move-model.json'),'utf8'));
const states=new Map<string,any>();
const bytes=gunzipSync(readFileSync(join(here,'states.raw.jsonl.gz')));
let offset=0;
while(offset<bytes.length){let end=bytes.indexOf(10,offset); if(end<0)end=bytes.length-1;const b=bytes.subarray(offset,end+1);states.set(digest(b),JSON.parse(b.toString('utf8')));offset=end+1;}
const rows=readFileSync(join(here,'executions.jsonl'),'utf8').trim().split('\n').map(l=>JSON.parse(l));
const out=join(here,'replay-results.jsonl');writeFileSync(out,'');
const limitAt=process.argv.indexOf('--limit');const limit=limitAt>=0?Number(process.argv[limitAt+1]):0;
const inputOut=join(here,'replay-inputs.jsonl.gz');writeFileSync(inputOut,'');
let attempted=0,complete=0,failed=0;
const snapshot=(raw:any)=>{
 const c=raw.combat??{},p=c.player??{};
 return {hp:p.current_hp??raw.run?.current_hp??null,block:p.block??null,energy:p.energy??null,turn:raw.turn??null,
  playerPowers:p.powers??null,cardsPlayed:p.cards_played_this_turn??null,
  enemies:(c.enemies??[]).map((e:any)=>({index:e.index,id:e.enemy_id,hp:e.current_hp,block:e.block,alive:e.is_alive,powers:e.powers??null})),
  potions:raw.run?.potions??null,relics:raw.run?.relics??null,hand:(c.hand??[]).map((c:any)=>({index:c.index,id:c.card_id,upgraded:c.upgraded,cost:c.energy_cost})),
  inCombat:raw.in_combat??null,screen:raw.screen??null,rawEnemyHpDamage:null,effectiveBossDamage:null,S:null};
};
for(const row of rows){
 if(!row.confirmed_execution){appendFileSync(out,JSON.stringify({id:row.id,attempt_key:row.attempt_key,split:row.split,status:'execution_binding_unknown',unknown:row.unknown,source:row.source})+'\n');continue;}
 if(limit&&attempted>=limit)break;
 attempted++;
 const base={id:row.id,attempt_key:row.attempt_key,run:row.run,floor:row.floor,turn:row.turn,attempt:row.attempt,split:row.split,action:row.action,source:row.source,pre:row.pre,post:row.post};
 try{
  const before=states.get(row.pre.sha256),after=states.get(row.post.sha256);
  if(!before||!after)throw new Error('frozen frame byte hash absent');
  const pre=before.state,post=after.state;
  const actual={before:snapshot(pre),after:snapshot(post),resourceScope:'observed snapshot changes; raw incoming attribution unknown'};
  if(!['play_card','use_potion','end_turn'].includes(row.action.action)){
   appendFileSync(out,JSON.stringify({...base,status:'unsupported_action',actual,unknown:['independent transition API does not execute this selection action']})+'\n');continue;
  }
  const parsed=parseGameState(pre);
  const board=boardOf(parsed,knowledge,row.encounter,db,mm);
  const solver=board.solver;
  const encoded=JSON.stringify(solver);appendFileSync(inputOut,gzipSync(Buffer.from(JSON.stringify({id:row.id,sha256:digest(encoded),solver})+'\n')));
  const steps:Step[]=[];
  if(row.action.action!=='end_turn'){
   let card:any;
   if(row.action.action==='play_card')card=solver.hand.find(c=>c.index===row.action.card_index&&c.type!=='Potion');
   else {const slot=row.action.potion_index??row.action.slot;card=solver.hand.find(c=>c.type==='Potion'&&(c.index===100+slot||c.index===200+slot));}
   if(!card)throw new Error('actually selected card/potion has no model mapping');
   const expected=row.historical_prediction?.expect?.card;
   if(expected&&(expected.id!==card.cardId||Boolean(expected.upgraded)!==card.upgraded))throw new Error('recorded expected identity differs from frozen model mapping');
   steps.push({cardIndex:card.index,cardId:card.cardId,upgraded:card.upgraded,cost:card.cost,name:card.name,target:row.action.target_index??null,targetName:null});
  }
  const replay=traceSteps(solver,steps);
  if(!replay.complete||!replay.plan){appendFileSync(out,JSON.stringify({...base,status:'replay_incomplete',actual,steps,replay,unknown:['existing independent replay could not legally complete observed step']})+'\n');failed++;continue;}
  const last=replay.transitions.at(-1)?.after??replay.initial;
  const outcome=replay.plan.outcome;
  const errors:any={};
  const compare=(key:string,pred:any,observed:any)=>{errors[key]=typeof pred==='number'&&typeof observed==='number'?{predicted:pred,actual:observed,residual:pred-observed}:null;};
  if(row.action.action==='end_turn')compare('player_hp',outcome.revived?.hp??outcome.hpAfter,actual.after.hp);
  else {
   compare('player_hp',last.hp,actual.after.hp);compare('block',last.block,actual.after.block);compare('energy',last.energy,actual.after.energy);
   for(const e of last.enemies){const a=actual.after.enemies.find((x:any)=>x.index===e.index);compare('enemy_hp_'+e.index,e.hp,a?.hp);const poison=a?.powers?.find((x:any)=>x.power_id==='POISON_POWER')?.amount??(Array.isArray(a?.powers)?0:null);compare('enemy_poison_'+e.index,e.poison,poison);}
  }
  complete++;
  const uncertainty=[...new Set(last.unknown??[])];
  if(last.unknownHand>0)uncertainty.push('draw identities unresolved; later real actions require observation rebasing');
  if(last.pendingSelection)uncertainty.push('pending selection not independently replayed');
  if(row.action.action==='end_turn')uncertainty.push('model end-of-enemy-turn versus observed next-start window; phase-specific healing attribution may be missing');
  appendFileSync(out,JSON.stringify({...base,status:'replayed_observed_step',steps,actual,input_sha256:digest(encoded),replay:{initial:replay.initial,transitions:replay.transitions,outcome,complete:true},errors,unknown:uncertainty,whole_fight_reproduced:false,actual_raw_enemy_damage:null,actual_S:null,prediction_layer:'historical prediction retained in executions.jsonl; not actual label'})+'\n');
 }catch(error){failed++;appendFileSync(out,JSON.stringify({...base,status:'replay_error',error:String(error),unknown:['model/input/replay limitation retained; no zero result substituted']})+'\n');}
 if(attempted%50===0)console.error(JSON.stringify({attempted,complete,failed}));
}
const summary={attempted,complete,failed,all_execution_rows:rows.length,model:'R346 frozen current source',seeds:[7],autonomous_reference_reruns:0,api_calls:0,scope:'per-action existing transition replay conditional on exact observed input, not full hidden-order trajectory or real S/win probability calibration'};
writeFileSync(join(here,'replay-execution-summary.json'),JSON.stringify(summary,null,2)+'\n');console.error(JSON.stringify(summary));

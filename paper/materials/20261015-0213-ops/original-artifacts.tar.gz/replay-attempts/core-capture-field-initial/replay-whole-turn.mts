/** Force structurally reconstructable observed turns through existing frozen mechanics. */
import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {traceSteps,type Step} from './frozen-model/agent/src/reflex/turn-solver.js';
import {simulateFight} from './frozen-model/agent/src/reflex/rollout.js';
import {makeKnowledge} from './frozen-model/agent/src/knowledge/index.js';
import {parseGameState} from './frozen-model/agent/src/hand/mod/schema.js';
import {setKnowledgeCharacter} from './frozen-model/agent/src/knowledge/files.js';
import {rolloutLiveOptions} from './frozen-model/agent/src/reflex/rollout-live.js';
import {bossLinesOptions} from './frozen-model/agent/src/sim/boss-lines.js';
import {boardOf} from './frozen-model/agent/tools/boss-sim/backtest-board.js';
const here=dirname(fileURLToPath(import.meta.url)),model=join(here,'frozen-model');
const hash=(v:string|Buffer)=>createHash('sha256').update(v).digest('hex');
const executions=readFileSync(join(here,'executions.jsonl'),'utf8').trim().split('\n').map(x=>JSON.parse(x));
const results=new Map(readFileSync(join(here,'replay-results.jsonl'),'utf8').trim().split('\n').map(x=>{const r=JSON.parse(x);return [r.id,r];}));
const inputs=new Map(gunzipSync(readFileSync(join(here,'replay-inputs.jsonl.gz'))).toString('utf8').trim().split('\n').map(x=>{const r=JSON.parse(x);return [r.id,r];}));
const states=new Map<string,any>();const raw=gunzipSync(readFileSync(join(here,'states.raw.jsonl.gz')));let at=0;
while(at<raw.length){let end=raw.indexOf(10,at);if(end<0)end=raw.length-1;const b=raw.subarray(at,end+1);states.set(hash(b),JSON.parse(b.toString()).state);at=end+1;}
setKnowledgeCharacter('silent');rolloutLiveOptions.enabled=false;bossLinesOptions.enabled=false;
const knowledge=makeKnowledge(JSON.parse(readFileSync(join(model,'data/game-data.json'),'utf8')).collections,'cache');
const db=JSON.parse(readFileSync(join(model,'knowledge/common/monster-db.json'),'utf8')).monsters;
const mm=JSON.parse(readFileSync(join(model,'knowledge/common/move-model.json'),'utf8'));
const groups=new Map<string,any[]>();for(const e of executions){const key=e.attempt_key+':T'+e.turn;const g=groups.get(key)??[];g.push(e);groups.set(key,g);}
const idsAt=process.argv.indexOf('--keys-file');const selected=idsAt>=0?new Set<string>(JSON.parse(readFileSync(process.argv[idsAt+1]!, 'utf8'))):null;
const suffix=selected?'whole-turn-correction':'whole-turn';
const path=join(here,suffix+'-results.jsonl');writeFileSync(path,'');let complete=0,unknown=0,errors=0;
for(const [key,rows] of groups){
 if(selected&&!selected.has(key))continue;
 const first=rows[0];const base={key,attempt_key:first.attempt_key,run:first.run,floor:first.floor,turn:first.turn,attempt:first.attempt,split:first.split,encounter:first.encounter,source_actions:rows.map(r=>({id:r.id,action:r.action,source:r.source,pre:r.pre,post:r.post}))};
 const reasons:string[]=[];
 if(rows.some(r=>!r.confirmed_execution))reasons.push('incomplete execution receipt/frame chain');
 if(rows.filter(r=>r.action.action==='end_turn').length!==1||rows.at(-1).action.action!=='end_turn')reasons.push('one final end-turn receipt absent');
 if(rows.some(r=>!['play_card','use_potion','end_turn'].includes(r.action.action)))reasons.push('selection/other action unsupported');
 if(rows.some(r=>results.get(r.id)?.status!=='replayed_observed_step'))reasons.push('independent transition input or legal replay unavailable');
 if(rows.some(r=>results.get(r.id)?.replay?.transitions?.some((t:any)=>t.after.unknownHand>0||t.after.pendingSelection||t.after.unknown?.length)))reasons.push('draw/selection/mechanics cannot be reconstructed from original initial state');
 if(reasons.length){unknown++;appendFileSync(path,JSON.stringify({...base,status:'unknown',unknown:reasons,actual_S:null})+'\n');continue;}
 try{
  const initial=inputs.get(first.id)?.solver;if(!initial)throw Error('initial frozen solver input missing');
  const consumed=new Set<number>();const steps:Step[]=[];
  for(const e of rows){
   if(e.action.action==='end_turn')continue;
   const step=results.get(e.id).steps[0];
   const candidates=initial.hand.filter((c:any)=>!consumed.has(c.index)&&c.cardId===step.cardId&&c.upgraded===step.upgraded&&(e.action.action==='use_potion'?c.index===step.cardIndex:true));
   if(candidates.length!==1)throw Error('initial-card identity is missing or nonunique; no arbitrary instance substitution');
   const c=candidates[0];consumed.add(c.index);steps.push({...step,cardIndex:c.index});
  }
  const replay=traceSteps(initial,steps);
  if(!replay.complete||!replay.plan)throw Error('complete observed line rejected by independent replay');
  if(replay.transitions.some(t=>t.after.unknownHand>0||t.after.pendingSelection||t.after.unknown.length))throw Error('whole-turn replay reveals unresolved mechanics');
  const before=states.get(first.pre.sha256);const last=results.get(rows.at(-1).id);const actual=last.actual.after;
  const board=boardOf(parseGameState(before),knowledge,first.encounter,db,mm);
  const input={...board.input,captureResources:true,captureCoreWindow:true,captureBossMargin:true};
  const trajectory=simulateFight(input,replay.plan,1,7);
  const record=trajectory.records[0];if(!record)throw Error('forced first-turn trajectory absent');
  const incomingNominal=replay.plan.outcome.hpAfter;
  const received=record.receivedHpDamage??null;
  const residual=typeof actual.hp==='number'&&record.resources?record.resources.hp-actual.hp:null;
  complete++;
  appendFileSync(path,JSON.stringify({...base,status:'forced_observed_turn_replayed',steps,initial_input_sha256:inputs.get(first.id).sha256,
   actual:{entry_hp:before.combat?.player?.current_hp,after:actual,raw_enemy_hp_damage:null,effective_boss_damage:null,S:null},
   replay:{transitions:replay.transitions,planOutcome:replay.plan.outcome,trajectory,receivedHpDamage:received,incomingNominalHp:incomingNominal},
   player_hp_residual:residual,enemy_phase_vs_next_start_window:'existing simulateFight includes next-start/resource telemetry; end-turn snapshot and resource endpoint remain separate',
   whole_fight_reproduced:false,calibrated_real_win_probability:null,actual_S:null})+'\n');
 }catch(error){errors++;appendFileSync(path,JSON.stringify({...base,status:'unknown',error:String(error),unknown:['bounded initial identity/window/model limitation retained'],actual_S:null})+'\n');}
}
const summary={turn_groups:groups.size,forced_observed_turns:complete,structurally_unknown:unknown,replay_limitations:errors,whole_fight_forward_replays:0,seed:7,API_calls:0,old_reference_reruns:0};
writeFileSync(join(here,suffix+'-summary.json'),JSON.stringify(summary,null,2)+'\n');console.error(JSON.stringify(summary));

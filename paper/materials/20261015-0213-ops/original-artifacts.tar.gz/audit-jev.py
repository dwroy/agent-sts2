"""Reuse all completed Jev returns; bind only overlap with preregistered boss executions."""
from pathlib import Path
import collections,gzip,hashlib,json
ROOT=Path('/home/dw/Projects/agent-sts2'); HERE=Path(__file__).resolve().parent
PREFIX='paper/materials/20261014-v5-jev-ablation/pilot-r2/'
manifest=json.loads((HERE/'inputs/paper/materials/20261014-v5-jev-ablation/artifact-manifest.json').read_text())
def digest(x):return hashlib.sha256(x).hexdigest()
def existing(suffix):
 item=next(x for x in manifest['files'] if x['path']==PREFIX+suffix); path=ROOT/item['path'];b=path.read_bytes();assert len(b)==item['bytes'] and digest(b)==item['sha256'];return item,b
result_ref,b=existing('results.jsonl'); results=[json.loads(l) for l in b.splitlines()]
request_ref,b=existing('requests.jsonl.gz');requests=[json.loads(l) for l in gzip.decompress(b).splitlines()]
start_ref,b=existing('starts.jsonl');starts=[json.loads(l) for l in b.splitlines()]
assert len(results)==len(requests)==len(starts)==144
rmap={r['id']:r for r in results};qmap={r['id']:r for r in requests};smap={r['id']:r for r in starts};assert len(rmap)==144 and rmap.keys()==qmap.keys()==smap.keys()
for key,r in rmap.items():assert r['status']=='ok' and r['request_sha256']==qmap[key]['request_sha256']==smap[key]['request_sha256']
follow=[json.loads(l) for l in (HERE/'inputs'/PREFIX/'learner-followup.jsonl').read_text().splitlines()]
executions=[json.loads(l) for l in (HERE/'executions.jsonl').read_text().splitlines()];byid={r['id']:r for r in executions}; byoffset={r['source']['offset']:r for r in executions}
attempts=json.loads((HERE/'attempts.json').read_text());runs=set(json.loads((HERE/'holdout-preregistration.json').read_text())['run_ids'])
rows=[]
with (ROOT/'logs/decisions.jsonl').open('rb') as inp:
 for f in follow:
  ref=f['source'];inp.seek(ref['offset']);b=inp.read(ref['length']);assert digest(b)==ref['sha256'];raw=json.loads(b);assert raw['run_id']==f['run'] and raw['floor']==f['floor'] and raw['turn']==f['turn']
  matched=byid.get(f['case_id']) or byoffset.get(ref['offset']);answers=[r for r in results if r['case_id']==f['case_id']]
  assert answers
  original_question_answer=raw.get('answers',{}).get('plan');actual_guard=raw.get('guard')
  boundaries=[a for a in attempts if a['run']==f['run'] and a['floor']==f['floor']]
  next_rows=[]
  if matched:
   same=[e for e in executions if e['attempt_key']==matched['attempt_key'] and e['source']['offset']>=matched['source']['offset']]
   next_rows=[{'id':e['id'],'action':e['action'],'receipt':e['receipt'],'confirmed':e['confirmed_execution'],'pre':e['pre'],'post':e['post'],'source':e['source'],'unknown':e['unknown']} for e in same]
  rows.append({'case_id':f['case_id'],'run':f['run'],'floor':f['floor'],'turn':f['turn'],'source':ref,
   'in_selected_run':f['run'] in runs,'in_boss_execution_scope':bool(matched),
   'fresh_choices':f['fresh_choices'],'historical_choice':f['historical_choice'],'original_answer':original_question_answer,
   'original_chosen_action':raw.get('chosen'),'original_receipt':raw.get('result'),'original_guard':actual_guard,
   'guard_before_sl_after_sl':f['guard_sl_audit'],'reasked':raw.get('reasked'),'reused_answer':raw.get('reused_answer'),
   'ablation_returns':answers,'matched_execution_id':matched['id'] if matched else None,'matched_confirmed_execution':matched['confirmed_execution'] if matched else None,
   'actual_following_steps':next_rows,'attempt_and_sl_boundaries':[{'key':a['key'],'attempt':a['attempt'],'split':a['split'],'outcome':a['actual_outcome'],'sl':a['sl']} for a in boundaries],
   'unchosen_lines_real_benefit':None,'actual_counterfactual_quality':None,
   'not_execution_claim':'Fresh offline returned choices and guard audit predictions are not observed real execution.'})
(HERE/'jev-overlap.json').write_text(json.dumps({'returns':144,'all_return_hash_links_verified':True,'source_files':[result_ref,request_ref,start_ref],
 'followup_cases':32,'selected_run_cases':sum(r['in_selected_run'] for r in rows),'boss_overlap_cases':sum(r['in_boss_execution_scope'] for r in rows),
 'choice_difference_boss_cases':sum(r['in_boss_execution_scope'] and len(set(r['fresh_choices'].values()))>1 for r in rows),
 'API_calls_this_stage':0,'rows':rows,'scope':'Readback and observed execution binding only; P0/Jev localization/ranking/request owner excluded.'},ensure_ascii=False,indent=1)+'\n')
print(json.dumps({'returns_verified':144,'followups':32,'selected_run_cases':sum(r['in_selected_run'] for r in rows),'boss_overlap':sum(r['in_boss_execution_scope'] for r in rows),'new_API_calls':0}))

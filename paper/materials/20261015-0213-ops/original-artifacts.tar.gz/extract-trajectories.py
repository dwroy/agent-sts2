"""Freeze only preregistered ended-run boss evidence and exact execution chains."""
import bisect,collections,datetime as dt,gzip,hashlib,importlib.util,json,os,sys
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2'); WT=Path('/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration'); HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(WT/'agent/tools/boss-sim')); import character_extract as old
sys.path.insert(0,str(WT/'agent/tools/logdb')); import query,sync
plan=json.loads((HERE/'holdout-preregistration.json').read_text()); runs=json.loads((HERE/'selected-runs.json').read_text()); ids=plan['run_ids']; cutoff=dt.datetime.fromisoformat(plan['cutoff_utc']).replace(tzinfo=None)
def plain(x):return query.plain(x)
def write(name,x):(HERE/name).write_text(json.dumps(x,ensure_ascii=False,indent=1)+'\n')
def table(cursor):return [dict(zip([d[0] for d in cursor.description],row)) for row in cursor.fetchall()]
with sync.read_lock(str(ROOT/'data/logdb'),shared=True):
 c=query.connect(str(ROOT/'data/logdb'),threads=1)
 frames=table(c.execute('SELECT * FROM frames WHERE run_id IN (SELECT unnest(?::VARCHAR[])) AND ts<=? ORDER BY run_id,off',[ids,cutoff]))
 decisions=table(c.execute('SELECT off,len,run_id,floor,turn,ts,observed_ts,action,result,label,sl_attempt,reasked FROM decisions WHERE run_id IN (SELECT unnest(?::VARCHAR[])) AND ts<=? ORDER BY off',[ids,cutoff]))
 configs=table(c.execute('SELECT off,len,ts,run_id,character,code,commit,dirty,dirty_files,restart FROM run_config WHERE run_id IN (SELECT unnest(?::VARCHAR[])) AND ts<=? ORDER BY off',[ids,cutoff]))
events=[json.loads(l) for l in (HERE/'sl-attempts.jsonl').read_text().splitlines() if l.strip() and json.loads(l).get('fight_kind')=='boss']
groups=old.attempt_frames(frames,events); kept=[]; no_frame=[]
for fs,event in groups:
 if not fs:
  no_frame.append({'event':event,'reason':'no indexed boss frames'});continue
 enc=old.boss_encounter(fs[0])
 if enc is None and event is None:continue
 kept.append((fs,event,enc))
used_offsets=set(); raw_states={}; frame_by_run=collections.defaultdict(list)
for f in frames:frame_by_run[f['run_id']].append(f)
state_file=ROOT/'logs/states.jsonl'; decision_file=ROOT/'logs/decisions.jsonl'
with state_file.open('rb') as inp,gzip.open(HERE/'states.raw.jsonl.gz','wb',compresslevel=6) as out:
 for fs,event,enc in kept:
  for f in fs:
   if f['off'] in used_offsets:continue
   inp.seek(f['off']); b=inp.read(f['len']); d=json.loads(b); assert d['state'].get('run_id')==f['run_id']
   assert d['state'].get('run',{}).get('character_id')=='SILENT'
   f['sha256']=hashlib.sha256(b).hexdigest(); raw_states[f['off']]=d; used_offsets.add(f['off']);out.write(b)
 # Preserve the first explicit post-combat state and first later floor entrance as resource boundaries.
 for fs,event,enc in kept:
  later=[f for f in frame_by_run[fs[0]['run_id']] if f['off']>fs[-1]['off']]
  extra=[]
  post=next((f for f in later if not f.get('in_combat')),None)
  if post:extra.append(post)
  for f in extra:
   if f['off'] in used_offsets:continue
   inp.seek(f['off']); b=inp.read(f['len']);d=json.loads(b);f['sha256']=hashlib.sha256(b).hexdigest();raw_states[f['off']]=d;used_offsets.add(f['off']);out.write(b)
frame_refs={f['off']:f for f in frames if f['off'] in used_offsets}
by_scope=collections.defaultdict(list)
for d in decisions:by_scope[d['run_id'],d['floor']].append(d)
exec_rows=[]; attempt_rows=[]; source_decisions=[]; scope_counts=collections.Counter()
with decision_file.open('rb') as inp,gzip.open(HERE/'decisions.raw.jsonl.gz','wb',compresslevel=6) as out:
 for fs,event,enc in kept:
  first,last=fs[0],fs[-1]; scope=first['run_id'],first['floor'];scope_counts[scope]+=1
  attempt=event.get('attempt') if event else scope_counts[scope]; key=f'{first["run_id"]}:{first["floor"]}:{attempt}:{first["off"]}'
  side='holdout' if first['run_id'] in plan['holdout_run_ids'] else 'train'
  mine=[d for d in by_scope[scope] if first['ts']<=d['ts']<= (old.timestamp(event['ended_at']) if event else last['ts']+dt.timedelta(seconds=5)) and (not event or d['ts']>old.timestamp(event.get('_previous_end','0001-01-01')))]
  # Fingerprints plus the observed timestamp select the exact pre-action state; no cross-attempt linkage.
  for k,d in enumerate(mine):
   inp.seek(d['off']); b=inp.read(d['len']); raw=json.loads(b); intent=raw.get('chosen') or {}
   if not isinstance(intent,dict) or not intent.get('action'):continue
   if d['label'] not in ['combat/plan-choice','combat/plan-continue'] and not d['label'].startswith('combat/') and intent.get('action') not in ['play_card','end_turn','use_potion','discard_potion','select_card','confirm_selection']:continue
   source={'path':str(decision_file),'offset':d['off'],'bytes':d['len'],'sha256':hashlib.sha256(b).hexdigest()}; out.write(b);source_decisions.append(source)
   exact=[f for f in fs if f.get('fingerprint')==raw.get('fingerprint') and f['ts']<=d['ts'] and (f.get('turn')==raw.get('turn') or f.get('turn') is None)]
   exact.sort(key=lambda f:(abs(((f.get('observed_ts') or f['ts'])-(d.get('observed_ts') or d['ts'])).total_seconds()),-f['off']))
   pre=exact[0] if exact else None
   next_obs=mine[k+1].get('observed_ts') or mine[k+1]['ts'] if k+1<len(mine) else None
   after=[f for f in fs if pre and f['off']>pre['off'] and f.get('fingerprint')!=pre.get('fingerprint') and (f.get('observed_ts') or f['ts'])<=d['ts']+dt.timedelta(seconds=10)]
   if next_obs:after=[f for f in after if (f.get('observed_ts') or f['ts'])<=next_obs]
   after.sort(key=lambda f:f['off']); post=after[0] if after else None
   if not post and pre and intent.get('action')=='end_turn':
    later=[f for f in frame_by_run[first['run_id']] if f['off']>pre['off'] and f['off'] in raw_states and f.get('fingerprint')!=pre.get('fingerprint') and (f.get('observed_ts') or f['ts'])<=d['ts']+dt.timedelta(seconds=10)]
    post=next((f for f in later if not f.get('in_combat')),None)
   completed=str(raw.get('result','')).startswith('completed:')
   issues=[]
   if not pre:issues.append('exact pre-action fingerprint not found within attempt')
   if pre and d.get('observed_ts') and (pre.get('observed_ts') or pre['ts'])!=d['observed_ts']:issues.append('pre-action observation timestamp not exact')
   if raw.get('sl_attempt') is not None and raw['sl_attempt']!=attempt:issues.append('explicit SL attempt mismatch')
   if not post:issues.append('unique changed post-action state not found before next request')
   if not completed:issues.append('receipt is pending/failed/unknown, not asserted executed')
   if pre and post and post['run_id']!=pre['run_id']:issues.append('run boundary')
   if pre and post and intent['action']!='end_turn' and post.get('turn')!=pre.get('turn'):issues.append('turn boundary before matching post-action state')
   if pre and raw.get('expect',{}).get('turn') is not None and raw['expect']['turn']!=pre.get('turn'):issues.append('requested turn differs')
   exec_rows.append({'id':raw.get('decision_id') or str(d['off']),'attempt_key':key,'run':first['run_id'],'ascension':runs[first['run_id']]['ascension'],'floor':first['floor'],'turn':d.get('turn'),'attempt':attempt,'split':side,'encounter':enc,'action':intent,'receipt':raw.get('result'),'confirmed_execution':completed and pre is not None and post is not None and not issues,'unknown':issues,'source':source,
      'pre':({'offset':pre['off'],'bytes':pre['len'],'sha256':pre.get('sha256')} if pre else None),'post':({'offset':post['off'],'bytes':post['len'],'sha256':post.get('sha256')} if post else None),
      'historical_prediction':{'expect':raw.get('expect'),'rationale':raw.get('rationale'),'questions':raw.get('questions'),'answers':raw.get('answers'),'rollout':raw.get('rollout'),'boss_evaluation':raw.get('boss_evaluation'),'guard':raw.get('guard'),'sl_attempt':raw.get('sl_attempt'),'sl_reloads':raw.get('sl_reloads'),'reasked':raw.get('reasked'),'journal':raw.get('journal')},'unselected_lines_actual_outcome':None})
  pre_state=raw_states[first['off']]['state']; player=pre_state.get('combat',{}).get('player',{}); entry_enemies=pre_state.get('combat',{}).get('enemies',[])
  after=next((f for f in frame_by_run[first['run_id']] if f['off']>last['off'] and not f.get('in_combat')),None)
  source_config=[x for x in configs if x['run_id']==first['run_id'] and x['ts']<=first['ts']]
  attempt_rows.append({'key':key,'run':first['run_id'],'floor':first['floor'],'ascension':runs[first['run_id']]['ascension'],'attempt':attempt,'first_attempt':attempt==1,'split':side,'encounter':enc,'first_ts':first['ts'].isoformat(),'last_ts':last['ts'].isoformat(),'turns_observed':max(f.get('turn') or 0 for f in fs),'frames':len(fs),'frame_offsets':[f['off'] for f in fs],
      'sl':event,'actual_outcome':event.get('result') if event else None,'entry_my_hp':player.get('current_hp'),'entry_enemy_hp':[{k:e.get(k) for k in ['index','enemy_id','current_hp','max_hp','is_alive','powers']} for e in entry_enemies],
      'entry_resources':{k:pre_state.get('run',{}).get(k) for k in ['current_hp','max_hp','relics','potions','deck']},'last_frame':{'offset':last['off'],'bytes':last['len'],'sha256':last['sha256']},'post_combat_frame':{'offset':after['off'],'bytes':after['len'],'sha256':after.get('sha256')} if after and after['off'] in raw_states else None,'execution_source_config':plain(source_config[-1]) if source_config else None,
      'unknown':['raw enemy HP damage attribution not directly emitted by state snapshots','hidden draw order not established by displayed pile order','whole-fight replay not implied by per-action rebasing']})
with (HERE/'frames-index.jsonl').open('w') as out:
 for off in sorted(frame_refs):out.write(json.dumps(plain(frame_refs[off]),ensure_ascii=False)+'\n')
with (HERE/'executions.jsonl').open('w') as out:
 for row in exec_rows:out.write(json.dumps(plain(row),ensure_ascii=False)+'\n')
write('attempts.json',plain(attempt_rows));write('missing-attempts.json',plain(no_frame));write('execution-source-configs.json',plain(configs))
for name in ['states.raw.jsonl.gz','decisions.raw.jsonl.gz','frames-index.jsonl','executions.jsonl','attempts.json','missing-attempts.json','execution-source-configs.json']:
 print(name,(HERE/name).stat().st_size)
write('trajectory-input-manifest.json',{'preregistered':{'path':str(HERE/'holdout-preregistration.json'),'sha256':hashlib.sha256((HERE/'holdout-preregistration.json').read_bytes()).hexdigest()},
 'runs':len(ids),'attempts':len(attempt_rows),'missing_attempts':len(no_frame),'frames':len(frame_refs),'decisions':len(exec_rows),'confirmed_execution_chains':sum(r['confirmed_execution'] for r in exec_rows),
 'files':[{'path':str(HERE/name),'sha256':hashlib.sha256((HERE/name).read_bytes()).hexdigest(),'bytes':(HERE/name).stat().st_size} for name in ['states.raw.jsonl.gz','decisions.raw.jsonl.gz','frames-index.jsonl','executions.jsonl','attempts.json','missing-attempts.json','execution-source-configs.json']],
 'source_byte_ranges':source_decisions,'scope':'Every selected boss attempt retained; execution ambiguity is unknown, not dropped or zero-filled.'})
print(json.dumps({'attempts':len(attempt_rows),'frames':len(frame_refs),'decisions':len(exec_rows),'confirmed_chains':sum(r['confirmed_execution'] for r in exec_rows)}))

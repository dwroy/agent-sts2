"""Verify existing immutable convergence artifacts without recomputing any reference."""
import hashlib,json
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2')
HERE=Path(__file__).resolve().parent
PREFIX=ROOT/'paper/materials/20261014-2121-ops/R2-originals'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,data):(HERE/name).write_text(json.dumps(data,ensure_ascii=False,indent=1)+'\n')
index=json.loads((PREFIX/'completed-reference-index.json').read_text())
coverage=json.loads((PREFIX/'question-coverage.json').read_text())
accept=json.loads((ROOT/'paper/materials/20261014-2121-ops/R2-completion-acceptance.json').read_text())
assert len(index['groups'])==54 and coverage['full_denominator']==30 and coverage['supported']==27 and coverage['unsupported']==3
verified=[]
for g in index['groups']:
 path=Path(g['result']['path']); assert path.exists(),path
 data=path.read_bytes(); assert hashlib.sha256(data).hexdigest()==g['result']['sha256'],path
 d=json.loads(data); q=d['full_quantitative']; ids=q['complete_ids']; assert len(ids)==len(set(ids))==1000
 assert d['reference_complete'] and d['actual_completed_pairs']==1000 and q['samples']==1000
 options=q['options']; options=options.items() if isinstance(options,dict) else ((str(i),v) for i,v in enumerate(options))
 metrics={'current':q['base'],**dict(options)}
 conditional={}
 for key,m in metrics.items():
  if isinstance(m,dict):
   conditional[key]={'samples':m.get('samples'),'effective_dpr_n':m.get('effective_damage_per_turn',{}).get('n'),
    'paired_dpr_n':m.get('paired_effective_damage_per_turn',{}).get('difference',{}).get('n'),
    'core_valid':m.get('core_window',{}).get('valid'),'core_missing':m.get('core_window',{}).get('missing'),
    'explicit_enemy_uncapped_damage_present':any(k in m for k in ['raw_enemy_damage','enemy_damage','enemy_raw_damage']),
    'actual_trajectory_accuracy':None,'real_win_probability':None}
 verified.append({'id':g['id'],'seed':g['seed'],'source':g['source'],'path':str(path),'sha256':g['result']['sha256'],
     'bytes':len(data),'common_ids':1000,'common_ids_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest(),
     'conditional_denominators':conditional,'scope':'convergence; no 1000-valid-terminal-DPR or real accuracy inference'})
paired=json.loads((PREFIX/'paired-analysis-index.json').read_text()); paired_checks=[]
for item in paired['cases']:
 source=Path(item['artifact']['path']); assert sha(source)==item['artifact']['sha256'],source
 d=json.loads(source.read_text()); paired_checks.append({'id':item['id'],'seed':item['seed'],'path':str(source),'sha256':item['artifact']['sha256'],
      'shared_ids':item.get('shared_ids'),'numerical_mismatches':item.get('numerical_mismatches'),'point_top_equal':item.get('point_top_equal'),
      'same_kill_order':item.get('same_kill_order'),'actual_game_accuracy':None})
materials=[]
for name in ['category-summary.json','representation-diagnosis.json','profiling-summary.json','question-coverage.json','paired-analysis-index.json','completed-reference-index.json','failure-manifest.json','result.json']:
 source=PREFIX/name; materials.append({'path':str(source),'sha256':sha(source),'bytes':source.stat().st_size})
result={'scope':'Read/verify only; no recomputation, fit, simulation or API invocation','questions':30,'supported':27,'unsupported':3,'groups_verified':54,
 'groups':verified,'paired':paired_checks,'materials':materials,'category':json.loads((PREFIX/'category-summary.json').read_text()),
 'representation':json.loads((PREFIX/'representation-diagnosis.json').read_text()),'profiling':{k:v for k,v in json.loads((PREFIX/'profiling-summary.json').read_text()).items() if k not in ['main_gc','phases']},
 'old_budget_ms':11000,'production_workers':24,'offline_profile_workers':4,'production_throughput_inferred':False,'real_accuracy_inferred':False,
 'old_generic_failure_preserved':accept['original_canonical_failed_rc0_null_and_report_kept'],'unknowns':['raw enemy damage attribution where absent','terminal/core denominators where incomplete','current R346 source transfer','real benefits of unselected candidates']}
write('r2-readback-audit.json',result)
print(json.dumps({'groups':len(verified),'paired':len(paired_checks),'questions':30,'unsupported':3,'hashes_verified':True,'recomputations':0}))

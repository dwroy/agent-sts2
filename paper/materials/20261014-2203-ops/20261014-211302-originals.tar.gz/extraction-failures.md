# 抽取失败与重试保留

本文件转录本任务工具已返回的错误，不作为游戏bug。

- detail.py初版读取不含chosen字段的派生Codex记录，原输出为`KeyError: 'chosen'`；detail.txt保留已完成输出，detail-retry.txt采用get后成功。
- audit.py初版假定questions.pick，但F45为questions.plan，原输出为`KeyError: 'pick'`；audit-failed.py、audit.txt保留原稿与已输出结果，audit-retry.txt／stderr保留修正重试。
- 一次只读交互查询假定每条续步也含questions，原输出为`KeyError: 'questions'`；后续facts.py／metrics.py按get读取并保留结果。
- 一次rg同时指定不存在的turn-rollout.ts，原输出为`No such file or directory`；随后按实际card-model／turn-solver／combat-plan路径核查。未更改源码或删失败输入。
- metrics.txt的下划线脑用量查询是错误字段口径的中间结果，facts.txt按原brain的camelCase字段重新核算；初稿中敌人击杀顺序、F33T7损血归因及示例、总token的错误均在首次追加前核正，原稿保留，不是已追加后的勘误。

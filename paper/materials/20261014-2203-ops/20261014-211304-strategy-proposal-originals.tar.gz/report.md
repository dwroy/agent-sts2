# 静默策略学习：本批十项处置报告

记录时间：2026-10-14T21:33:43+08:00。task=strategy-proposal；character=silent；batch=20261014-211304-strategy-proposal。

## 结论与身份

本批十项均保留waiting。现有窄实现和原日志足以核部分机制/资源端点，但未填齐原提案的持续身份、联合生产校准或受控整战比较；没有发现本批可据实直接制定的新预算、血价、SL阈值或固定启动/目标顺序。没有源码/知识改动、源码提交、live合入、版本或新shipped。

开工git status干净，HEAD=3fdd55c5120efd2fa88e342b7e74304ce62bba4b。先读README、STATE-2026-10-14、decision-log末尾、learning-protocol及learning-code-proposals。只读learn.json本批：task=strategy-proposal、character=silent、reason=proposal、running、worktree匹配，十proposal_ids；无research_request/implementation_request/proposal_repair。普通专题根请求绑定另一旧batch，按1.2不承接、不读其他专题替代身份。普通队列执行git merge --no-edit main，结果Already up to date，实际base仍为上述完整40位。没有下级agent。

六个runs原行全部SILENT/A10：VLZ6CCT8AQ0A、8JRE1C4H4Z2W、CA5KE8GFJ9X2、5PM6JAQG6FNQ、61E2QS63Y9WU、DUZUBAJ3A8GP。独立局数6；SL尝试不扩分母。不读取其他角色私有知识，不用预训练事实补结论，不把静默历史experience广范围/支持数当成本批样本。

## 原始证据读回

原日志经共用extract_evidence.py提取8流，按每流source_size冻结边界；所有所属行原offset/bytes/SHA256及解码对象逐项读回，一共6995行。保存完整source_size、逐局计数与output_sha256于evidence/evidence-manifest.json；身份取run_id/state.run_id/run/fingerprint.run，不取正文提及。提取全源发现states/decisions各2个无效JSON行、brain1行；未据这些全源计数断言属于本六局。fight-plans在该截点六局均0行，只说明本次未选到。

| 流 | source_size字节 | 核验所属行 |
|---|---:|---:|
| states | 12783141127 | 3432 |
| decisions | 1401397620 | 3306 |
| sl-attempts | 39278188 | 29 |
| run-config | 1695570 | 6 |
| run-plans | 7754565 | 33 |
| brain | 513314184 | 183 |
| runs | 328404 | 6 |
| fight-plans | 2233957 | 0 |

718个相关状态、696个相关决策的只读事实投影保存selected-state-facts.json、selected-decision-facts.json；29条SL原记录另存attempt-facts.json。37项固定原帧事实断言最终通过，保存fact-checks.json及最终log；这属于数据核验，不是生产代码测试或新增红绿验证。

## 实际离线消费者读回

从已核原行构造单局输入，保留原decision_id、observed_ts、fingerprint与物理_line；输入为gzip JSON且保存原SHA/字节，不造ID、不依赖刷新知识JSON、不调用LLM/网络。使用当前基线learner/lib/selection-execution.ts，经node --import tsx离线调用。

VLZ、8JRE、5PM完整输入被接受。CA5第267143行、61E第267517行、DUZU第268789/268818/268864行缺decision_id，完整输入真实拒收结果保留；仅剔除这5个无ID行得到有界子集，原行仍在证据/输入中，物理行号缺口由消费者保留，不把有界结果当完整局输入成功。

| 局 | 有ID动作 | 候选片段 | 相邻动作端点 | 终页端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |

合计3301个有ID动作、476候选片段、859相邻动作观测端点、4终页端点、121整轮端点、413未知轮窗口。所有actual_full_candidate_result保持null：这是现有消费者刻意保留的认证边界，不表示没有执行过候选或没有任何观测收益，也不能单凭null推断游戏策略失败。

8JRE F33首/第三试T2同fingerprint：原SL预测0/24与5/24并非同死率，进一步损失饱和值均47。实际整轮分别玩家-3/-15、唯一敌血-10/-17，确认同盘多12血/多7敌净扣；依然不认证未选整场反事实。第二试T5整轮-4/-25含后续重问，不能把全部端点直接归护栏候选。270264原护栏只在rationale中，结构hp_guard计数0不等没有护栏。

5PM末试F39 T2无毒冒泡前后5→4能、目标35血不变、毒0；该轮实际净损21另账。61E F17 T6负敏捷两防御各3、敌毒端点67→34；F23 T4幻象仍2血并攻击，不能把本体净扣视为全员退场。DUZU前三次F30在predicted_death结束、末试实际died，不把前三预测截断说成已执行死亡。

## 现有源码与live祖先

只读live快照=4437492bb1498181430a5f51ddbafd9d54571aa6。15精确路径中13个base/live blob相同、2个不同：card-model.ts与rollout-live.ts。完整blob/SHA/last_base_path_commit及祖先核验保存在source-verification.json；同blob不等某个main最近提交已为live祖先。没有将main-only提交写进implemented/duplicate。

已核的live源码祖先例：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化参考字段）、b2805be4ba44b7375c7908d873889372cc3cfe6c（已观察萎靡升级）、05cd292c6f01bb31e406473d3a9843e659d62b93（三阶段选择快照）、a8b1f8be153fe4f3a34146117546c2178f2e446b（护栏/SL局部审计）、cf72bd21148059f111f760cc98a727369e34a47e（离线消费者）。这些是窄项来源，不是本批合入commit，也不关闭宽提案。existing-fixture-readback.json核六个神化原夹具的原字节SHA/角色/进阶/状态完全相符；未重跑或借用历史测试成功。

## 逐项结果

| 原id | 处置 | 具体未实现原因 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水、SL与换战的实际施放持续身份和生产读回；虚弱/脆弱/缩小/暗影等组合仍明确未验证，现有窄升级传播不覆盖整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的分阶段MC配对，以及候选稳定性/样本成熟度曲线；不能由单题707ms制定新预算、留药或集火规则。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化提案仍缺实际施放持续身份及未覆盖升级交互校准；没有完整live实现证明，不能仅凭题意重复登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五条机制的全部属性组合、升级联动、状态期限及战斗/路线/休息资源消费者联合固定校准；原帧端点与局部源码不证明完整覆盖。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有三阶段预测审计和观测端点工具，但缺跨抽牌/选牌/重问/药水/SL的实际候选持续归属与本局全过程生产校准；113片段不能认证完整执行或成长收益。 |
| silent-proposal-49632bc4878fb597 | waiting | 本局无正敏捷实测；缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长四路径联合校准，不增加统一血价权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水与完整抽序下不同启动顺序的受控整场对照及可复现收益函数；无毒冒泡局部无效不证明统一启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP/构筑/抽序的完整生产整战配对及另一可核SL线；首试胜利和毒端点不足以改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行、复现、退场全链的冻结生产校准及另一focus完整后继；已有召唤源码和T4端点不能认证目标排序整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续与当前进阶成长的完整生产全链校准及同抽换序后继；四次相关失败不能拟合新的血价或杀序。 |

每项证据局/层/回合、原账本、反例、旧/预期行为、验证与回退详见同目录proposal.md。没有忽略派发id，不新增重复id、不改原提案Markdown。code_proposals为这十个已存在CLI id；implementation_domains为空，因为本批没有新的实际实现。

## 记录与检查口径

只通过根learner/ledger.py update为本批相关静默条目追加by=learner:strategy-proposal、proposal/report链接与核验说明，原claim/status/version/evidence/first_run/asc/prior和shipped历史保持；不重复添加既有证据。ledger更新输入、CLI输出和核验另存本目录。队列状态由最终proposal_results交既有调度器消费，不手改learn.json或专用队列。

没有源码提交，所以撤源码失败/恢复通过不适用，tsc/vitest/cases均null；未跑生产测试、不报告0。合入流程未启动，merged=null；没有live刷新提交、eval版本、规则双通知或decision-log上线记录，不冒称已发布。工作树保持干净，HEAD=base；根账本CLI追加不属于本工作树源码变化。

失败现场保留：一次检查测试夹具frames时误按列表处理dict产生KeyError；两次shell启动被沙箱glob扫描的并行回收路径消失阻断，重试后读取正常，均不是源码测试失败；一次猜测旧报告根路径不存在，不据此断言证据丢失。check-facts初稿将甲虫尖啸前274931行当成之后，实际[2,2,4]使断言失败；逐原帧定位正确274932行，最终[2,-4,4]与20/14/22匹配，初稿/原失败log完整保留，非撤生产源码负控。没有把纠正选帧说成新的游戏反证。

证据限制：旧运行代码带dirty，不能凭Git提交重构全部当时源码/知识/随机池；本批六局已有历史用途，不是后置盲测；端点/显示牌面/推演排名、真实执行与整战因果分开。暂不确定保持未知，不把报告/排队/局部源码当完整经验入库、大脑采用或父要求关闭。

交运维路径：/home/dw/Projects/agent-sts2/learner/runs/20261014-211320-strategy-proposal/proposal.md。report=/home/dw/Projects/agent-sts2/learner/runs/20261014-211320-strategy-proposal/report.md。

最终读回：26条本角色CLI追溯追加已按实际账本读回，原claim/status/version/evidence/first_run/asc/prior均保持，十个原id与最终proposal_results集合完全相同。工作树git status/diff为空、HEAD保持完整base。报告/提案/最终JSON/本批账本更新输入的gitleaks stdin红acted扫描退出0，无泄漏；其log和JSON保留，本批没有提交。

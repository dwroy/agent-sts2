import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-174303'
SCRATCH = ROOT / 'learner/runs/20261016-174314-32e7f6b9-0c15-4c43-89b3-9c843eb5e8e8-fix-batch'
source = sys.argv[1]
branch = 'codex-fix-silent-20261016-174303'
result = {'source': source, 'branch': branch, 'merged': None, 'tests_exit': None}

def save():
    (SCRATCH / 'merge-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

def git(*args, cwd=LIVE):
    return subprocess.check_output(['git', '-C', str(cwd), *args], text=True).strip()

def run(*args, cwd=LIVE, **kwargs):
    return subprocess.run(args, cwd=cwd, check=True, **kwargs)

def scan(name):
    with (SCRATCH / f'gitleaks-{name}.log').open('w') as handle:
        run('nice', '-n', '19', 'gitleaks', 'git', '--pre-commit', '--staged', '--redact', '--no-banner',
            '--report-format', 'json', '--report-path', str(SCRATCH / f'gitleaks-{name}.json'),
            stdout=handle, stderr=subprocess.STDOUT)

assert git('rev-parse', 'HEAD', cwd=TREE) == source
assert git('branch', '--show-current') == 'live'
print('等待 live 合入锁', flush=True)
with (ROOT / 'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    print('已取得 live 合入锁；等待知识刷新结束', flush=True)
    while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
        time.sleep(10)
    assert not git('diff', '--cached', '--name-only'), 'live 已有暂存内容，停止以保留其他所有者工作'
    assert not (Path(git('rev-parse', '--absolute-git-dir')) / 'MERGE_HEAD').exists()
    result['live_initial'] = git('rev-parse', 'HEAD')
    common = git('merge-base', source, 'HEAD')
    source_paths = set(git('diff', '--name-only', common, source).splitlines())
    dirty = git('diff', '--name-only').splitlines()
    result['dirty_before_refresh'] = dirty
    overlap = sorted(source_paths.intersection(dirty))
    result['overlap'] = overlap
    if overlap:
        result['error'] = '刷新/并行文件与本分支改动重叠；未合入，不覆盖'
        save()
        raise SystemExit(2)
    run('git', 'add', 'notes/fight-value-backtest.md', 'knowledge')
    refresh_paths = git('diff', '--cached', '--name-only').splitlines()
    result['refresh_paths'] = refresh_paths
    if refresh_paths:
        scan('live-refresh')
        run('git', 'commit', '-m', 'Refresh knowledge data', '-m',
            'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    before = git('rev-parse', 'HEAD')
    result['pre_merge_after_refresh'] = before
    save()
    print(f'刷新已保留于 {before}；合入 {source}', flush=True)
    run('git', 'merge', '--no-edit', branch, '-m', f"Merge branch '{branch}' into live", '-m',
        'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    result['merge_commit'] = git('rev-parse', 'HEAD')
    save()
    env = dict(os.environ, TMPDIR=str(SCRATCH), SANDBOX_WORKERS='4')
    env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + env['PATH']
    print('运行 live 固定沙箱检查', flush=True)
    with (SCRATCH / 'live-sandbox.log').open('w') as handle:
        checked = subprocess.run(['bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', env=env,
                                 stdout=handle, stderr=subprocess.STDOUT)
    result['tests_exit'] = checked.returncode
    if checked.returncode:
        run('git', 'reset', '--merge', before)
        result['rollback'] = git('rev-parse', 'HEAD')
        result['error'] = 'live 沙箱检查失败，已回到保留刷新数据的合前提交'
        save()
        raise SystemExit(checked.returncode)
    stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    result['published_at'] = stamp
    entry = (f'\n- {stamp} 离线修复学习者 fix-batch 将 infra-stall-between-run-quiet 合入 live：'
        f'源码 {source}，合入 {result["merge_commit"]}；来源 notes/fix-queue-v4.md 2026-10-16 17:34 条目，'
        '证据 7X58G3LSHZ3U / SILENT A10 F24 正常 finalize（非战斗回合），'
        'paper/materials/20261016-1732-ops/stall-disposition.json。仅在控制器退出、控制台正常完局且所属 report 仍在时抑制 420 秒静默误报；'
        '保留 900 秒无决策、不可达、卡循环及 brain/sim 等待守卫。固定测试撤源码 2 失败/4 通过、恢复 6 通过；'
        '源与合后沙箱入口均 exit0，gitleaks0；无对应 bug-infra 账本，不新建或冒记 shipped。'
        '纯监测工具修复，对局/铁甲战士/游戏知识规则等价，不增 eval 版本、不热改当前对局或根运行入口；'
        '实际根监测消费者随原运维集成链核验。报告 learner/runs/20261016-174314-32e7f6b9-0c15-4c43-89b3-9c843eb5e8e8-fix-batch/report.md。\n')
    with (LIVE / 'paper/materials/decision-log.md').open('a') as handle:
        handle.write(entry)
    run('git', 'add', 'paper/materials/decision-log.md')
    assert git('diff', '--cached', '--name-only') == 'paper/materials/decision-log.md'
    scan('live-record')
    run('git', 'commit', '-m', 'Record between-run stall monitor fix deployment', '-m',
        'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    result['merged'] = git('rev-parse', 'HEAD')
    result['source_is_live_ancestor'] = subprocess.run(['git', 'merge-base', '--is-ancestor', source, result['merged']], cwd=LIVE).returncode == 0
    result['live_status'] = git('status', '--short')
    result['behavior_release_added'] = False
    save()
    print(json.dumps(result, ensure_ascii=False), flush=True)

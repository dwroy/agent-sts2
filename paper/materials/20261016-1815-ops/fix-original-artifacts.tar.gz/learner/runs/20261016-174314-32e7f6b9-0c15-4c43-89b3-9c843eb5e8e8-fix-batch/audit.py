import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-174303'
SCRATCH = ROOT / 'learner/runs/20261016-174314-32e7f6b9-0c15-4c43-89b3-9c843eb5e8e8-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-171307-33b35135-cfb8-46da-8ee2-a78e6a86c25e-fix-batch'

def git(*args, tree=TREE):
    return subprocess.check_output(['git', '-C', str(tree), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    (SCRATCH / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
prior = json.loads((PRIOR / 'audit.json').read_text())
base = 'c75756fe60168c410f1eb4e611433176ed7ec194'
assert git('rev-parse', 'HEAD').decode().strip() == base
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live').decode().strip()
ancestors = set(git('rev-list', base).decode().splitlines())
live_ancestors = set(git('rev-list', live).decode().splitlines())
files = []
for old in prior['current_files']:
    path = old['path']
    assert Path(path).name != '.env'
    data = git('show', f'{base}:{path}')
    row = {'path': path, 'sha256': sha(data), 'prior_sha256': old['sha256']}
    row['same_as_prior'] = row['sha256'] == row['prior_sha256']
    files.append(row)
assert all(r['same_as_prior'] for r in files)
fixed = []
for old in prior['existing_fixes']:
    row = {**old, 'ancestor_in_base': old['commit'] in ancestors,
           'ancestor_in_live': old['commit'] in live_ancestors}
    assert row['ancestor_in_base'] and row['ancestor_in_live'], row
    fixed.append(row)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
old_queue = (PRIOR / 'queue-readonly-snapshot.md').read_bytes()
assert queue.startswith(old_queue)
added = queue[len(old_queue):].decode()
assert 'infra-stall-between-run-quiet' in added
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)
unchecked = [(i + 1, s) for i, s in enumerate(queue.decode().splitlines()) if s.startswith('- [ ]')]
assert unchecked == [(r['line'], r['item']) for r in prior['queue_dispositions']]
focused = []
for old in prior['focused_source_review']:
    data = (TREE / old['path']).read_text().splitlines()
    found = [i + 1 for i, s in enumerate(data) if old['anchor'] in s]
    assert found, old
    focused.append({**old, 'current_matching_lines': found})
evidence_path = ROOT / 'paper/materials/20261016-1732-ops/stall-disposition.json'
evidence = json.loads(evidence_path.read_text())
terminal = evidence['original_terminal_console']
raw = (ROOT / terminal['path']).read_bytes()
assert len(raw) == terminal['bytes'] and sha(raw) == terminal['sha256']
assert 'stopped: run 1 ended (defeat); stopping as requested' in raw.decode()
row = evidence['terminal_run']
with (ROOT / row['source']).open('rb') as handle:
    handle.seek(row['offset'])
    raw = handle.read(row['bytes'])
assert sha(raw) == row['sha256'] and json.loads(raw) == row['value']
assert row['value']['run_id'] == '7X58G3LSHZ3U' and row['value']['floor'] == 24
save('stall-evidence-readback.json', {'source': str(evidence_path), 'sha256': sha(evidence_path.read_bytes()),
    'console': terminal, 'run': row, 'run_record_and_console_sha256_verified': True,
    'scope': '只读核正常完局/报告期间监测误报；不执行游戏API或推断游戏机制。'})
for name in ['evidence-0332-readback.json', 'evidence-0308-readback.json']:
    old = json.loads((PRIOR / name).read_text())
    for row in old['rows']:
        path = Path(old['path']) if 'path' in old else ROOT / 'logs' / (row['stream'] + '.jsonl')
        with path.open('rb') as handle:
            handle.seek(row['offset'])
            raw = handle.read(row['bytes'])
        assert sha(raw) == row['sha256'], (name, row)
    save(name, {**old, 'this_batch_sha256_verified': True,
                'limitation_this_batch': '仅核既有证据原字节，不修改游戏模型；原策略提案及证据不足边界保持。'})
changed = git('diff', '--name-only', prior['base'], base).decode().splitlines()
source_changed = [p for p in changed if p.startswith(('agent/src/', 'agent/tests/', 'agent/tools/',
    'knowledge/builders/', 'learner/', 'eval/', 'ops/')) and p != 'ops/inbox-dev.md']
assert not source_changed, source_changed
save('audit.json', {'checked_at': checked_at, 'base': base, 'live_read_only_snapshot': live,
    'prior_audit': str(PRIOR / 'audit.json'), 'prior_audit_sha256': sha((PRIOR / 'audit.json').read_bytes()),
    'queue_sha256': sha(queue), 'queue_lines': len(queue.decode().splitlines()),
    'queue_append': added, 'unchecked_entries': len(unchecked),
    'queue_dispositions': prior['queue_dispositions'], 'current_files': files,
    'existing_fixes': fixed, 'focused_source_review': focused,
    'code_changes_since_prior': source_changed,
    'new_fix': 'infra-stall-between-run-quiet', 'new_fix_evidence': '7X58G3LSHZ3U F24 finalization (turn not applicable)',
    'scope': '纯监测工具修复；对局/铁甲战士/游戏知识与规则保持等价；不新登记策略提案。'})
print(json.dumps({'unchanged_baseline_files': len(files), 'existing_fixes_verified_in_base_and_live': len(fixed),
    'unchecked_entries_reviewed': len(unchecked), 'new_pure_bug': 'infra-stall-between-run-quiet',
    'old_evidence_rows_verified': 10, 'source_changes_since_prior': source_changed}, ensure_ascii=False))

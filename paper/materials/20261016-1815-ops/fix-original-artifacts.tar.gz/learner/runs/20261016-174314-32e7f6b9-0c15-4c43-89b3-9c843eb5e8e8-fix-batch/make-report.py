import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-174303'
SCRATCH = ROOT / 'learner/runs/20261016-174314-32e7f6b9-0c15-4c43-89b3-9c843eb5e8e8-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-171307-33b35135-cfb8-46da-8ee2-a78e6a86c25e-fix-batch'
subprocess.run(['date'], check=True)
audit = json.loads((SCRATCH / 'audit.json').read_text())
prior = json.loads((PRIOR / 'result.json').read_text())
merge = json.loads((SCRATCH / 'merge-result.json').read_text())
source = merge['source']
assert json.loads((SCRATCH / 'source-sandbox-exit.json').read_text())['exit_code'] == 0
assert merge['tests_exit'] == 0 and merge['merged']
def counts(name):
    text = (SCRATCH / name).read_text()
    files = [int(n) for n in re.findall(r'Test Files\s+(\d+) passed', text)]
    cases = [int(n) for n in re.findall(r'\n\s*Tests\s+(\d+) passed', text)]
    assert len(files) == len(cases) == 2, (name, files, cases)
    assert not re.search(r'(?:Test Files|Tests)\s+\d+ failed', text), name
    return {'tsc': 0, 'vitest': 0, 'files': sum(files), 'cases': sum(cases), 'blocks': list(zip(files, cases))}
source_tests = counts('source-sandbox.log')
live_tests = counts('live-sandbox.log')
fix = {'item': 'infra-stall-between-run-quiet：正常完局报告期间的静默误报', 'commit': source,
       'test': 'agent/tests/ops-stall-between-runs.test.ts', 'fails_without_fix': True}
result = {'task': 'fix-batch', 'base': audit['base'], 'fixes': [fix], 'skipped': prior['skipped'],
    'merged': merge['merged'], 'tests': source_tests, 'code_proposals': [], 'implementation_domains': [],
    'report': str(SCRATCH / 'report.md')}
lines = ['## 修 bug 回报', '', f'- 合并基线：main → {audit["base"]}（初始工作区干净，先 merge main，Already up to date）',
    f'- 修复（每条一行）：{fix["item"]} — {source} — 测试 {fix["test"]}:accepts the 7X58 F24 finalized console while its report runs at 439 seconds — 去掉修复时失败：是（撤源码 exit1，2失败/4通过；恢复 exit0，6通过，另含旧守卫定向13项全过）']
for row in audit['existing_fixes']:
    lines.append(f'- 已被别人修掉的：{row["item"]} — {row["commit"]}（本轮核 base/live 祖先与相关388叶基线SHA，已观察窄子项不关闭宽父）')
for row in result['skipped']:
    lines.append(f'- 没修的：{row["item"]} — {row["reason"]}')
lines += [f'- 测试：源 tsc 退出码0；vitest {source_tests["files"]}文件 / {source_tests["cases"]}用例 / 退出码0；合后 tsc退出码0，vitest {live_tests["files"]}文件 / {live_tests["cases"]}用例 / 退出码0。无失败重跑；源沙箱 SANDBOX_WORKERS=1，合后沙箱沿入口默认4；均使用规定 TMPDIR，完整宿主套件仍由原调度器补跑。',
    f'- 合入：live {merge["merged"]}（合入提交 {merge["merge_commit"]}；刷新保留提交 {merge["pre_merge_after_refresh"]}，未与本分支重叠；源为live祖先。纯监测修复不增eval号；根main实际监测消费者待原运维集成核验，未热改当前对局/根入口。）',
    '- 需要 Roy 定的事（没有写「无」）：无。', '', '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '']
(SCRATCH / 'report.md').write_text('\n'.join(lines))
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'test-summary.json').write_text(json.dumps({'source': source_tests, 'live': live_tests,
    'without_fix': {'exit': 1, 'failed': 2, 'passed': 4}, 'restored': {'exit': 0, 'passed': 6},
    'targeted': {'exit': 0, 'files': 2, 'passed': 13}, 'retries': []}, ensure_ascii=False, indent=2) + '\n')
assert subprocess.check_output(['git','-C',str(TREE),'status','--porcelain']).strip() == b''
print(json.dumps({'source':source, 'merged':merge['merged'], 'source_tests':source_tests,
                  'live_tests':live_tests, 'report':result['report']},ensure_ascii=False))

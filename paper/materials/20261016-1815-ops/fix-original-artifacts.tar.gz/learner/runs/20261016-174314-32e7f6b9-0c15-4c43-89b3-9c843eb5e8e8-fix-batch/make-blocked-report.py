import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-174303'
SCRATCH = ROOT / 'learner/runs/20261016-174314-32e7f6b9-0c15-4c43-89b3-9c843eb5e8e8-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-171307-33b35135-cfb8-46da-8ee2-a78e6a86c25e-fix-batch'
stamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
audit = json.loads((SCRATCH / 'audit.json').read_text())
prior = json.loads((PRIOR / 'result.json').read_text())
assert json.loads((SCRATCH / 'source-sandbox-exit.json').read_text())['exit_code'] == 1
assert 'spawnSync /usr/bin/python3 EPERM' in (SCRATCH / 'source-sandbox.log').read_text()
assert '4158 passed' in (SCRATCH / 'source-sandbox.log').read_text()
assert '11 passed' in (SCRATCH / 'paths-followup.log').read_text()
assert (SCRATCH / 'global-health-python.stdout').read_bytes() == b''
assert 'Ran 4 tests' in (SCRATCH / 'global-health-python.stderr').read_text()
assert (ROOT / 'notes/fix-queue-v4.md').read_bytes() == (SCRATCH / 'queue-readonly-snapshot.md').read_bytes()
patch = SCRATCH / 'worktree.diff'
item = 'infra-stall-between-run-quiet：正常完局报告期间的静默误报'
reason = ('纯工具修复与固定测试已写好，未提交/未合入：规定沙箱入口exit1，唯一失败为既有'
    'global-build-health.test.ts:6同步封装spawnSync /usr/bin/python3 EPERM；Python内4项通过。'
    '遵守提交前入口必须exit0的要求，保留补丁与现场交原运维沙箱外复验后提交/合入；不增排除、不改无关测试或断言。')
uncommitted = {'item': item, 'commit': None, 'test': 'agent/tests/ops-stall-between-runs.test.ts',
    'fails_without_fix': True, 'patch': str(patch), 'patch_sha256': hashlib.sha256(patch.read_bytes()).hexdigest(),
    'files': ['ops/stall-check.sh', 'agent/tests/ops-stall-between-runs.test.ts'],
    'evidence': {'run': '7X58G3LSHZ3U', 'floor': 24, 'turn': None, 'phase': 'normal run finalization/report'}}
result = {'task': 'fix-batch', 'base': audit['base'], 'fixes': [],
    'skipped': [{'item': item, 'reason': reason}] + prior['skipped'], 'merged': None,
    'tests': {'tsc': 0, 'vitest': 1, 'files': 448, 'cases': 4170, 'passed': 4169, 'failed': 1},
    'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md'),
    'uncommitted_fixes': [uncommitted]}
lines = ['## 修 bug 回报', '', f'- 合并基线：main → {audit["base"]}（开工工作区干净，先 git merge --no-edit main，Already up to date）',
    f'- 修复（每条一行）：{item} — 未提交（规定完整入口被沙箱EPERM阻挡） — 测试 agent/tests/ops-stall-between-runs.test.ts:accepts the 7X58 F24 finalized console while its report runs at 439 seconds — 去掉修复时失败：是（仅stash源码，exit1，2失败/4通过；恢复exit0，6通过；与原守卫组合13项全过）。',
    '- 修复边界：仅在无play控制器、所属report仍在且控制台正常完局时抑制439秒静默误报；保留900秒无决策、不可达、卡循环及原brain/sim等待守卫。只改监测工具与固定测试，铁甲战士和对局规则保持等价；无新增游戏知识/策略提案。']
for row in audit['existing_fixes']:
    lines.append(f'- 已被别人修掉的：{row["item"]} — {row["commit"]}（本轮核base/live祖先及相关388叶基线SHA；窄子项不关闭宽父）')
for row in result['skipped']:
    lines.append(f'- 没修的：{row["item"]} — {row["reason"]}')
lines += ['- 测试：tsc退出码0；规定沙箱入口exit1，主段447文件（446通过/1失败）、4159用例（4158通过/1失败）；随后补跑原入口独立paths段exit0，1文件11用例通过。合计448文件（447通过/1失败）、4170用例（4169通过/1失败），vitest退出码1。唯一失败global-build-health.test.ts:6是spawnSync /usr/bin/python3 EPERM，非本补丁断言或超时失败；定向诊断重现一次exit1，直接原Python4项exit0且stdout为空。未改固定排除/断言/时限；没有额外整套重跑。新回归13项/恢复6项均exit0；bash -n、diff --check、gitleaks均0。源检查SANDBOX_WORKERS=1、所有临时文件使用规定TMPDIR。',
    '- 合入：未合入；无新提交、没有取得live锁或执行刷新提交/合并/上线记录/版本登记。live只读核至a9e687d9f0acccccddbfa92895d7966b58900658；其刷新知识与本分支无路径重叠，原数据和并行记录保持。未执行scratch中的预备合入/成功回报脚本。根main实际监测消费者也未变；原运维应先在沙箱外核完整入口，再提交本补丁并按live流程接续。',
    '- 需要 Roy 定的事（没有写「无」）：无；阻挡是沙箱验证条件，按既有运维提交/合入兜底处理。',
    f'- 留存：报告生成于{stamp}。补丁{patch}，SHA256 {uncommitted["patch_sha256"]}；所有红/绿/完整失败/定向诊断/独立补验原日志与audit.json均留在本scratch。仅2个文件暂存，HEAD保持base；修复队列只读且与开工快照同字节。按关键词及证据局号查bug-infra均0项，不新建或写shipped；未改学习账本/经验/提案/运维prompt/对局。', '', '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '']
(SCRATCH / 'report.md').write_text('\n'.join(lines))
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'test-summary.json').write_text(json.dumps({'tsc': 0, 'sandbox_entry': 1,
    'main': {'files': 447, 'files_passed': 446, 'cases': 4159, 'passed': 4158, 'failed': 1},
    'paths_followup': {'exit': 0, 'files': 1, 'cases': 11}, 'global_health_python': {'exit': 0, 'cases': 4, 'stdout_bytes': 0},
    'global_health_diagnostic_rerun': {'exit': 1, 'failure': 'spawnSync /usr/bin/python3 EPERM'},
    'without_fix': {'exit': 1, 'failed': 2, 'passed': 4}, 'restored': {'exit': 0, 'passed': 6},
    'targeted': {'exit': 0, 'files': 2, 'passed': 13}, 'full_reruns': 0}, ensure_ascii=False, indent=2) + '\n')
assert subprocess.check_output(['git', '-C', str(TREE), 'rev-parse', 'HEAD'], text=True).strip() == audit['base']
paths = subprocess.check_output(['git', '-C', str(TREE), 'diff', '--name-only', 'HEAD'], text=True).splitlines()
assert set(paths) == set(uncommitted['files'])
print(json.dumps({'base': audit['base'], 'source_committed': False, 'merged': None, 'tests': result['tests'],
                  'uncommitted_patch_sha256': uncommitted['patch_sha256'], 'report': result['report']}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-174303-s2/learner/runs/20261016-174312-212b6946-9ec0-4807-b28d-c170ed5d0209-strategy-proposal')


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)


old = json.loads((PRIOR / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
records = []
for entry in old['files']:
    path = entry['path']
    raw = (ROOT / path).read_bytes()
    live_raw = git('show', live + ':' + path)
    ancestors = {}
    for commit in entry['commits_actual_live_ancestor']:
        ancestors[commit] = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live], cwd=ROOT).returncode == 0
    records.append({
        'path': path, 'sha256': hashlib.sha256(raw).hexdigest(),
        'same_as_prior': hashlib.sha256(raw).hexdigest() == entry['sha256'],
        'live_sha256': hashlib.sha256(live_raw).hexdigest(), 'same_as_live': raw == live_raw,
        'commits_actual_live_ancestor': ancestors,
    })
for path in ['agent/src/sl/explore.ts', 'agent/src/hand/loop.ts', 'agent/src/reflex/silent-held-loss.ts']:
    raw = (ROOT / path).read_bytes()
    records.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(),
                    'same_as_prior': raw == git('show', old['base'] + ':' + path),
                    'same_as_live': raw == git('show', live + ':' + path)})
(OUT / 'source-audit.json').write_text(json.dumps({'base': base, 'live_head': live, 'files': records}, ensure_ascii=False, indent=2) + '\n')
paths = [r['path'] for r in records]
(OUT / 'source-live.diff.txt').write_bytes(git('diff', '--binary', live, base, '--', *paths))
(OUT / 'source.diff.patch').write_bytes(git('diff', '--binary', 'HEAD', '--', 'agent', 'learner', 'eval', 'ops', 'knowledge'))
print(json.dumps({'files': len(records), 'unchanged_from_prior': sum(r['same_as_prior'] for r in records),
                  'same_as_live': sum(r['same_as_live'] for r in records),
                  'all_commits_live_ancestors': all(v for r in records for v in r.get('commits_actual_live_ancestor', {}).values())}, ensure_ascii=False))

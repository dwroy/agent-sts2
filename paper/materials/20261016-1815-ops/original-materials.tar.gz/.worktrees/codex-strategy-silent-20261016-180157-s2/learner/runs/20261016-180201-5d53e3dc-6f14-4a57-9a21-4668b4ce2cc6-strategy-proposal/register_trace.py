import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
queue = json.loads((OUT / 'queue-snapshot.json').read_text())
dispositions = {r['id']: r for r in json.loads((OUT / 'dispositions.json').read_text())}
before = json.loads((OUT / 'ledger-before-selected.json').read_text())
prefix = json.loads((OUT / 'ledger-before-prefix.json').read_text())
path = ROOT / 'paper/materials/learning/ledger.jsonl'
assert hashlib.sha256(path.read_bytes()[:prefix['size']]).hexdigest() == prefix['sha256']
updates = []
for ident in sorted(before):
    related = [p for p, r in queue.items() if ident in r['original']['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
        'note': '20261016-180157-s2-strategy-proposal核验：' + '；'.join(p + ' waiting：' + dispositions[p]['reason'] for p in related)
                + '。仅追加本批追溯，不重复support/repeat，不改原学习结论或上线状态；证据与逐项边界见本批report。'})
payload = ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in updates)
(OUT / 'ledger-updates.jsonl').write_text(payload)
process = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'], input=payload,
                         text=True, capture_output=True, env=None)
(OUT / 'ledger-cli.stdout').write_text(process.stdout)
(OUT / 'ledger-cli.stderr').write_text(process.stderr)
(OUT / 'ledger-cli-exit.json').write_text(json.dumps({'exit_code': process.returncode, 'rows': len(updates)}) + '\n')
assert process.returncode == 0, process.returncode
raw = path.read_bytes()
assert hashlib.sha256(raw[:prefix['size']]).hexdigest() == prefix['sha256']
rows, receipts = [], []
offset = 0
for number, line in enumerate(raw.splitlines(keepends=True), 1):
    row = json.loads(line)
    if row.get('id') in before:
        rows.append((number, row))
    if offset >= prefix['size'] and row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith('20261016-180157-s2-strategy-proposal核验：'):
        receipts.append({'line': number, 'offset': offset, 'bytes': len(line),
                         'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert len(receipts) == len(updates)
for receipt, expected in zip(receipts, updates):
    observed = receipt['row']
    assert {k: observed[k] for k in expected} == expected
    assert set(observed) == set(expected) | {'op', 'ts'} and observed['op'] == 'update'
spec = importlib.util.spec_from_file_location('local_ledger', OUT.parents[2] / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
after = ledger.fold(rows)
protected = ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_runs', 'prior_note', 'evidence', 'status', 'version', 'shipped_at', 'effect']
for ident, old in before.items():
    new = after[ident]
    for key in protected:
        assert old.get(key) == new.get(key), (ident, key)
    assert new['notes'][:len(old['notes'])] == old['notes']
    assert new['history'][:len(old['history'])] == old['history']
    for key, values in old['where'].items():
        assert new['where'][key][:len(values)] == values
(OUT / 'ledger-physical-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-integrity.json').write_text(json.dumps({'cli_exit': process.returncode, 'appended_rows': len(receipts),
    'selected_items': len(before), 'prior_physical_prefix_preserved': True, 'protected_fields_preserved': protected,
    'old_notes_history_where_prefixes_preserved': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit': process.returncode, '追溯项': len(receipts), '旧前缀和受保护字段保留': True}, ensure_ascii=False))

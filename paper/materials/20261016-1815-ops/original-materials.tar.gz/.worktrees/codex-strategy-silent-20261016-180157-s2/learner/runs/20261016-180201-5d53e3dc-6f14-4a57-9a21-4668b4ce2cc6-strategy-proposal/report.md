# 本批策略核验报告

批次：20261016-180157-s2-strategy-proposal；角色：silent；base：57e2d6ef443d92d5705098a81526d7c4e936b524。

结论：十个已领取提案均waiting。没有新增源码或知识修改、代码提交、live合入或发布；已实现部分保持原有覆盖，不把局部实现冒标整项duplicate/implemented。

本批已核工作树开工干净，git merge --no-edit main返回Already up to date。根learn.json仅读取本批对应行，task/character/worktree/runs/proposal_ids均匹配，没有research_request、implementation_request或proposal_repair。普通专题请求绑定另一旧批，不进入该专题，不扩领队列。十份原Markdown均与队列登记SHA一致，原字节保存在original-proposals/。

按共用extract_evidence.py本次新提取六个默认流，runs/fight-plans另存evidence-extra/，未覆盖旧报告或旧截点。六局均在runs.jsonl核为SILENT/A10。八流8,274条逐条回原日志验证显式身份、offset/bytes/SHA/JSON和source_size边界：states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0。每流source_size/count/outputSHA保存两个evidence-manifest.json；逐行索引见verified-evidence-index.jsonl，复核见evidence-verification.json。零条fight-plans仅说明本截点未选到，不断言原日志缺失。各流分别固定截点，不声称原子同刻快照。全源扫描有states2、decisions2、brain1行无效JSON，无法赋予本批身份，不从这些行推游戏事实。

构造1,014个限定房间快照与13个关键决策，27项原帧/同指纹端点断言及6项候选/成功SL反例断言通过。33项均为材料核验，不是生产测试或受控整战反事实。反例见success-sl-counterexample.json。原局均dirty运行，实际运行源码/知识/移动表未完整复原；当前代码存在不证明旧运行预测准确。

17个相关源码叶与上一批基线逐字同，13叶与实际live逐字同、4叶仅历史Roy/Dai署名注释差；相关原源码commit全部是本次只读所核实际live祖先。source-audit.json与source-live.diff.txt保留SHA/实际live HEAD/祖先核验/完整diff。不读取其他角色私有知识，不从预训练事实补机制。
## silent-proposal-c20b5139dd0dff71：感染棱柱：污染与技能收益

账本：silent-0168。

证据局/层/回合：DUZUBAJ3A8GP F27 T4—T6；states 274830—274839。

本批核实：T4污染0/3/3/6，能力勒紧未新增污染；火花3→6后T5污染0/6/12/18，次轮清空。两轮玩家实损3/9、敌本体净扣8/13。

旧规则与已有覆盖：turn-solver技能叠污染、rollout增长及资源比较已有接线；1698adc96ba434a46942321e0237b70657e625b2为实际live祖先。

处置：waiting。缺原dirty运行知识、实际移动表与火花增长/污染撤除/虚弱/毒/挡的同次冻结联合生产校准；未定位新的可归责计算差额。

反例/限制：技能同时产生毒或挡收益，9实损不支持强制少打技能；没有另一线整场获胜的实证。

预期行为与验证：保留所有选项，分列逐击污染血价与毒/挡收益；固定同一生产源码、知识、移动表和出牌前缀后对账，出现确定差额才修计算。

## silent-proposal-ae9e692d680e3819：失落/遗忘：抢夺归源与返还

账本：silent-0183、silent-0005。

证据局/层/回合：5PM6JAQG6FNQ F39 T2、T4—T6；states 274341/274351/274352/274354/274358/274362。

本批核实：玩家力敏−2/−2到−4/−4，两步法使敏捷−4→−2→0；失落退场后力量0，遗忘再抢后敏捷−2。

旧规则与已有覆盖：现场负力量、负敏捷已被现有求解/推演消费；当前值本身不认证累计来源、实体代际或退场返还。

处置：waiting。缺稳定实体身份、逐来源累计抢夺及毒杀返还后再抢的完整输入对账；缺另一杀序的受控整战后继。

反例/限制：原提案末试单步法仅回到−2敏，毒杀失落后仍死亡；返还端点不足规定固定击杀序。

预期行为与验证：按来源和实体代际保存抢夺/退场/返还，不按重排index猜身份；固定完整输入核累计和返还，杀序价值另用受控后继验证。

## silent-proposal-52f1e1bd2e7db0ed：下水道蚌：首样本事实与加压

账本：silent-0231。

证据局/层/回合：CA5KE8GFJ9X2 F13 T1—T5；states 273238/273247/273252/273254/273258/273263/273268。

本批核实：力量0/4/8，无弱攻击11/15/19，弱后15→11、19→14；轮初覆甲9/9/8/7/6。

旧规则与已有覆盖：monster-db.moveDamageAt/monsterHpAt直接用当前进阶已有事实；roomHpCost仍有ROOM_COST_MIN_N=5。4ed3c72df30f27b881da637aebf528b97440e0bb为实际live祖先。

处置：waiting。首样本接口已有实现；缺原局实际调用移动表及加压/覆甲/虚弱联合生产校准，完整覆甲减层条件未证。

反例/限制：覆甲层数序列不独立证明所有减层条件；死亡截断实损不能代替完整需损。

预期行为与验证：保持首样本HP/攻击事实和房间代价五样本边界；冻结实际移动表逐步对账，不补未经观察的减层条件或固定房间成本。

## silent-proposal-6dd8bbff876be528：电击：高电压与召唤代际

账本：silent-0233、silent-0209。

证据局/层/回合：5PM6JAQG6FNQ F38 T3/T4；states 274308/274312/274313。

本批核实：23上限电击索引4→3，力量2→4、攻击17→19；T3仍贡献17攻击，不能把候选计划击杀预记为退场。

旧规则与已有覆盖：rollout有HIGH_VOLTAGE_POWER增长，新召唤者初始化growth=0；f3dea91880600bc2e7228268a110a644531738f7为实际live祖先。

处置：waiting。缺稳定召唤代际身份、原A10移动表与跨代重置的冻结生产校准；未执行先杀爪牙线没有完整后继。

反例/限制：同类型/同上限/索引重排不足证明实体连续；原35伤/损3候选未实打，不能承诺救后场。

预期行为与验证：维持当前增长与新实体初始化；固定召唤/退场/再召唤身份及实际移动表后逐步核验，不迁移旧index计数。

## silent-proposal-578e415a259e6835：沙虫：SL血价、护栏与能力兑现

账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。

证据局/层/回合：8JRE1C4H4Z2W F33 首/第三试T2、第二试T5和末试T11；decisions 270216/270282/270264，关键端点276208/276212/276274/276278。

本批核实：T2完整指纹相同，实损3→15、净扣10→17，多12血价换7伤；原候选死亡0/24，替线5/24，均封顶47后损不代表同死率。

旧规则与已有覆盖：66283dd9982bdd7f480da7a4d9bfefea0572a9ac提供候选/护栏审计，1698adc扩资源；bade647f9fe4c9103b40e2f26b26296692ad24b7和fdaf787a372880b0438e73bcac7e6d2168b038ed提供单动作回执，均为实际live祖先。

处置：waiting。缺抽弃/生成/用药/重问后整候选连续归属、逐来源能力兑现及路线/药水/SL恢复的联合消费者；单动作回执不证明整候选完成。

反例/限制：原提案更防御的末线延至T11仍败；抽牌重规划后不能将候选省血直接记为实际收益。

预期行为与验证：保持原答/护栏/SL替换/派发/结算分列；跨重规划先结束旧候选完成认证，再用固定前缀与状态核执行归属，不设新的探索系数。

## silent-proposal-c0767768bf6a7ab1：实验体：全败SL与续步截断

账本：silent-0079。

证据局/层/回合：YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348/271354；states 277327—277373。

本批核实：两题完整指纹相同，实损0→9、净扣45→38；两候选24/24死，预测损0/10、伤54/36独立保留。271354实际选择end_turn。

旧规则与已有覆盖：资源比较scope=current_turn_prediction、execution=unverified；单动作回执whole_plan_executed=null，准确保留未完成认证。

处置：waiting。缺截断续步的完整候选归属、同抽序后轮及独立受控获胜后继；全败并列不足拟血价惩罚或禁止探索。

反例/限制：同局F33重打后到REWARD且20血，已核states277086—277090；F48失败不否定全部SL。原第四次候选未完整执行的限制保留。

预期行为与验证：保存同题候选差、实际端点、覆盖重放与完成状态未知；固定续步归属后验证事实，不将有限样本同败称安全。

## silent-proposal-a46bdb7fe711d79a：实验体：阶段、毒与敏捷时点

账本：silent-0021、silent-0027、silent-0028、silent-0085。

证据局/层/回合：YF0LXT1QSTGG F48 末试T3—T5；states277512/277513/277519/277524/277526/277527。

本批核实：4血4毒、111上限阶段转到212上限且毒0；触媒2而当前毒0；敏捷5→6时现有挡仍23。末轮本体净扣37，18血对44−23需21、差3。

旧规则与已有覆盖：silent-phase-current列本帧已建能力/持有组件/当前毒；8698c581dac6c7e957f50a381586960a6d0c9b57和aad2700abed6dff1d66e87fb36aaa6fedb39adf3为实际live祖先。

处置：waiting。缺逐候选跨阶段完整执行、逐来源施毒/结算与格挡前后敏捷顺序的联合生产校准；当前快照不认证后继收益。

反例/限制：原前五试建立过毒雾或余像仍败；已建能力不保证获胜，不以零毒作为唯一死因。

预期行为与验证：当前阶段重新读取毒和能力；不预支零毒触媒收益，不倒补后得敏捷的旧挡；固定建立时点与结算后校准，不强制能力先手。

## silent-proposal-1044224808015e5c：双蟹：B2零胜并列的实际血价

账本：silent-0079。

证据局/层/回合：XP2SL33HT0D9 F33 首/末T1、首/第二T3、第三T4；decisions271982/272195/271992/272040/272076。

本批核实：T1完整指纹同、实损2→10/净扣25→34；T3完整指纹同、实损9→14/净扣24→27。272076 B2均0但五轮死亡21/24→23/24，仅为未完成候选事实。

旧规则与已有覆盖：候选审计、SL资源比较与派发回执有局部覆盖；完整40位live祖先来源见source-audit.json，未认证跨重规划整候选。

处置：waiting。缺同抽序、药瓶随机落点后继、成长兑现与受控整战比较；零胜并列和单轮血价不足拟探索门槛。

反例/限制：付血伴随手里剑成长；末试T2零损、T3保挡反例保留，不能只按少挡牌数断错。

预期行为与验证：成对列HP代价、输出、成长与采样未知，保留原探索规则；按独立run和时间后移验证，不把六次SL当六局。

## silent-proposal-7cbc6005db712ba9：双蟹：朝向、临减和轮初挡

账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。

证据局/层/回合：XP2SL33HT0D9 F33 末试T2/T4/T5；states278236/278237/278240/278242/278249/278252/278253/278255/278260/278261。

本批核实：轮初14挡加斗篷到20，普通镣铐使力0→−9→0；激光57→转向38→虚弱28；四敏脆弱下6挡。末轮毒实扣3+7，玩家0血。

旧规则与已有覆盖：passive-pieces有HORN_CLEAT_BLOCK=14/T2，card-model/solver/rollout有临减、恢复及朝向/弱路径；源码和实际祖先见source-audit.json。

处置：waiting。缺全部修饰组合的同次冻结生产回放、抽弃后整候选执行及未选后继；现有窄覆盖不等同全部组合校准。

反例/限制：临减次轮恢复，能力已建立仍无减员；现场观察不外推未见叠层，后得敏捷不倒补旧挡。

预期行为与验证：朝向、弱、临减、轮初挡分别对账，冻结同一输入核组合与先后；维持原排名、HP护栏和能力权重。

## silent-proposal-c59f592f1427a67e：综合机制与联合资源消费者

账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。

证据局/层/回合：YF0LXT1QSTGG F48、XP2SL33HT0D9 F33，以及本批另外四局上述锚点。

本批核实：本批核六局A10及四组完整fingerprint相同的当轮对照；原101局/1499房为原提案历史范围，六锚点不等于重建101局。

旧规则与已有覆盖：候选、护栏、阶段事实和单动作派发模块局部已有；这不证明逐来源联合资源消费者已交付。

处置：waiting。本批六局不能替代原101局联合资源重建；完整候选、路线、休息、实际用药和SL恢复的逐来源联合消费未闭合。

反例/限制：同局SL尝试相关；SL恢复不算回血，候选省血不等实际保血，持有组件不等已施放。历史更早角色内证据保留原文，不充本批复核。

预期行为与验证：按原范围逐run对账资源及候选归属，分别验观察事实和受控后继；原量化/联合消费者/学习入库父要求继续开放。

## 验证、账本与交付边界

确定性计算修正无需先有获胜局，但必须用冻结生产输入定位实际差额。本批未定位新差额；长期排名、血价系数、强制出牌、药水价值或SL门槛也没有受控后继支持。因此保留现状，未因“人定规则”另设审批，也未将缺证包装成已实现。未来实现只用固定日志输入，须撤生产源码失败/恢复通过，再按沙箱入口、自测、gitleaks和live流程发布。角色外及未观察条件保持等价。

本批没有源码变更：撤源码红/恢复绿不适用，tsc/vitest/cases均null，未运行或借用旧生产测试。fixes=[]、merged=null，无commit、eval版本、shipped或规则双通知；未进入live知识刷新/合入流程。没有新提案id、没有代码消费者交付或经验入库声明，不关闭原量化/学习入库父要求。

账本只经根learner/ledger.py update追加本批proposal/report的where/note，by=learner:strategy-proposal；同一旧证据不重复support/repeat，不改claim、first_run、prior、evidence、status、version或shipped，不把旧shipped降为proposed。输入/退出结果与前后完整性单独保存。队列由最终proposal_results交调度器处置，不自行写learn.json或专用队列。

原有支持、反例和未知仍保留；本批没有新机制反证或与旧知识的新冲突。探测silent-candidate-facts.ts、reflex/jev.ts及hand/silent-selection-dispatch.ts时路径不存在，后经rg定位实际reflex/silent-selection-dispatch.ts；只读探测失败不当产品故障，保留read-probes.txt说明。模型/推理/服务档未独立核实际原生会话，不以任务文字或默认配置冒称切换成功；本批没有改模型、账号、权限或prompt。

交运维：proposal.md、report.md、result.json、dispositions.json和全部原CLI id。没有待合入源码或可回退的生产变更；保留本批材料、原提案和旧失败历史。工作树/索引/HEAD完整性及材料脱敏扫描结果见final-integrity.json和gitleaks.log。

最终验收：HEAD保持base，tracked工作树与索引干净，本批派发身份未变；gitleaks退出0、扫描约189.77 MB、无发现。账本CLI退出0，30条仅where/note，原物理前缀和受保护字段及旧notes/history/where前缀保持。完整结果见result.json，完整性见final-integrity.json。

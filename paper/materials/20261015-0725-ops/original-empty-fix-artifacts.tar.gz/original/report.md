## 修 bug 回报
- 合并基线：main → 4ffbcee235584d67f2d8c96ec678915c2e8579d1（初始工作区干净；merge Already up to date）
- 修复（每条一行）：无新增修复，无源码提交；无需新增撤码红/恢复绿验证。
- 已被别人修掉的：账本发布前缀分叉 — dd478f0b3；EZ2L固定夹具超时 — bae9c45c；legacy通知身份桥 — 368fccab；独立计划成本 — 799a5cd0；事件日志同秒碰撞 — b6ee3f8c2；纸鹤固定夹具超时 — befc39e5c；其余逐项见下表。
- 没修的：机制/打法/题面项（含silent-0481）— 策略类，已有独立提案；silent-0332、core-build-notify-222802-rc2、调度公平性和扫描上游根因 — 证据不足；独立架构/缓存/DPR/校准功能 — 太大且有原任务。
- 测试：tsc 退出码0；定向vitest 7文件/48用例/退出码0，EZ2L其余22项未选；Python死亡战统计3项/退出码0；无重跑。无源码变更，未跑完整沙箱或宿主全套。
- 合入：未合入（无新增源码；现有24项实际交付提交均已是live祖先）。当前live=19c9720b688ec7152fd1bbda554e9084e042077b。现有verify_empty_fix返回None：main/live存在158个既有SOURCE_PATHS差异；未合并无关源码、未改完成状态或冒称验收通过。
- 需要 Roy 定的事（没有写「无」）：无

本批只在指定scratch写审计和回报。工作树、修复队列、学习账本、live、版本表及通知均未修改，不生成空提交。策略父要求、原failed/rc0/mergednull、历史全套失败和未来消费者待验全部保留。没有新学习结论、提案、规则或行为版本。

只读队列冻结SHA256：8b7df31c562d4758c17848e26c2a712a530a6776ea0c51580b2090e6932788bb，共1316行、40个未勾选checkbox条目；逐条分流见queue-audit.json。其余历史条目的后续修复与当前源码核对见下表。未将旧记录未划线等同于当前bug仍存在。

| 已有纯工具/夹具子项 | 实际交付提交 | 当前基线祖先 | live祖先 |
| --- | --- | --- | --- |
| infra-ledger-status-prefix-git-divergence | `dd478f0b3e5a0f234f082972d21b203dbf8229d7` | 是 | 是 |
| infra-target-options-fixed-fixture-timeout | `bae9c45ccffefb284a1c6634526c8768a9f5f7a8` | 是 | 是 |
| infra-legacy-continuation-notice-ack-identity | `368fccabd42eb72ffcea9a2fe6cbbb7c149326be` | 是 | 是 |
| silent-0459 独立计划成本 | `799a5cd0caf9329b43c32376079218a9bd0c3e9e` | 是 | 是 |
| infra-learner-event-log-second-collision | `b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f` | 是 | 是 |
| infra-paper-krane-recorded-line-timeout | `befc39e5ca0105f8ff96d47f817df44f0b2760f1` | 是 | 是 |
| strategy-proposal scratch归属 | `5f04139cefe5c651dd5bf62f7e164014dbf5f23b` | 是 | 是 |
| run-plans显式run证据提取 | `78e9b05929366d097a728761d693d790ff16ac87` | 是 | 是 |
| batch-f参数化/包装超时扫描 | `56c256dad0d33b231b82b53113d3bdd84f9bfa20` | 是 | 是 |
| 已注册feature通知身份 | `1dd4d434aef67f1d065dbdba23a875ae82741a88` | 是 | 是 |
| feature通知回执校验 | `38b2f572d90b3b97a23f9eae983f583287492f9a` | 是 | 是 |
| tracked-source Python缓存回收 | `1e8af775f6b90f100f20ff7c4a08dfddaba893a9` | 是 | 是 |
| ordinary通知ACK注册 | `672e198a4730012330f599068a0ef1efadb02002` | 是 | 是 |
| ordinary通知前阶段校验 | `1594def2e1b65b665d3b345f31444194eb4d09e6` | 是 | 是 |
| 失败复盘空提案误审 | `3fdcd77927f01b35c20c6c5c1fcfd790676032d2` | 是 | 是 |
| 共享经验固定FS夹具 | `8390c62d76fc8c7d7b6b7292121a621f4666d39c` | 是 | 是 |
| deck-cap消费者固定夹具 | `ec8c578b66bf5498372f1b779ae58a766dff8112` | 是 | 是 |
| 论文Git一致快照 | `16bfe0bd6ecaa91d04a91c01edc94cecc781f71f` | 是 | 是 |
| boss-sim Codex home preflight | `5921f8cd045853182c867a6430e75c3fcde00a87` | 是 | 是 |
| compute-memo worker固定知识 | `8fbb441eb61eef226eb7366f9612003480c83988` | 是 | 是 |
| rollout best测试确定性 | `bbc5b993a7524bbb8e80a975f204f8d193657b46` | 是 | 是 |
| 升阶通知/额度恢复基线 | `5b56a452bb9be14d620b368ec46974c1b57901ca` | 是 | 是 |
| 无出牌死亡战统计 | `3b48088dec5fc6eafe576a1296bbdadde43432ee` | 是 | 是 |
| 复盘启动租约ID | `223b2121ae6d9b92169df6b6eeeada66d89c553d` | 是 | 是 |

c0999eaa2原source不是当前祖先；该历史夹具实际集成ec8c578b6是双分支祖先，已独立注明。后续移除cap的架构决定保持，不借旧夹具恢复cap。

当前代码读回：learner/ledger.py committed_status_snapshot/append保留物理/Git分叉状态闸；target-options.test.ts标注题使用withTargetOptionFixture；learning_requests.py有legacy continuation身份链；report.py同时保留独立run-plan question_id去重和state-only死亡战窗口；run_ascension只读实际ascension；CodexUsageGuard两次新鲜稳定读数后才退役旧epoch。所选固定回归全部通过，不将祖先关系单独当效果/自然消费证明。

silent-0481在selection.ts:311/:333仍存在，原silent-proposal-686d4e759478eebb真实pending/target_task=strategy-proposal；silent-0365仍见targets.slice(0, 2)，原70c22e94eda8f8a9 pending；silent-0367原196013f88a9d7c1c pending。这些题面/药水/资源条件已有本角色独立实现链，未在普通工具批次混入，也未另派agent或改变提案状态。

原core通知回执SHA256=567a6d7801be73a43b6825448cccccc34c9bffef2fb2a12c2f80a8b77df36fb5，只读failed/rc2、stdout/stderr 0字节；未调用发送入口。扫描ENOENT在本轮工具启动前也出现，指向另一项目的.aws/.codex临时路径，不是本仓库删除者归因证据；仅保留失败，不改全局配置或触碰另一项目。

本轮遇到缺失旧scratch路径时仅核旧批canonical报告及当前Git；未将缺失解释为证据不存在，未恢复/清理其他工作树。原模型/账号/运行会话未操作，未宣称已切换运行模型。所有测试LLM/启动器使用固定fixture或mock，无真实网络/模型请求。

日志：tsc.log、vitest-infra.log（6文件47项）、vitest-target-options.log（1文件1项，22未选）、python-report-death-fight.log（3项）。completion-precheck.json保存真实空改动验收返回值及158个既有差异路径；不把这项框架限制当代码测试失败，也不为通过验收而合入无关main差异。

```json
{"task": "fix-batch", "base": "4ffbcee235584d67f2d8c96ec678915c2e8579d1", "fixes": [], "skipped": [{"item": "infra-ledger-status-prefix-git-divergence", "reason": "已修，提交 dd478f0b3e5a0f234f082972d21b203dbf8229d7"}, {"item": "infra-target-options-fixed-fixture-timeout", "reason": "已修，提交 bae9c45ccffefb284a1c6634526c8768a9f5f7a8"}, {"item": "infra-legacy-continuation-notice-ack-identity", "reason": "已修，提交 368fccabd42eb72ffcea9a2fe6cbbb7c149326be"}, {"item": "silent-0459 独立计划成本", "reason": "已修，提交 799a5cd0caf9329b43c32376079218a9bd0c3e9e"}, {"item": "infra-learner-event-log-second-collision", "reason": "已修，提交 b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f"}, {"item": "infra-paper-krane-recorded-line-timeout", "reason": "已修，提交 befc39e5ca0105f8ff96d47f817df44f0b2760f1"}, {"item": "其余既有纯工具修复", "reason": "已核24项当前基线和live祖先；逐项提交见ancestry-audit.json；历史deck-cap采用实际集成ec8c578b6，不冒称c099原source祖先。"}, {"item": "未结机制/打法/题面项（含silent-0481、silent-0365、silent-0367）", "reason": "策略类，保持原行为及既有独立strategy-proposal，不重复注册或派发。"}, {"item": "silent-0332 双boss接续资源契约", "reason": "证据不足：仍缺原触发样本与缺资源/非正HP分支隔离；保留已有提案。"}, {"item": "core-build-notify-222802-rc2", "reason": "证据不足：原回执failed/rc2、stdout/stderr均为空，无法确认实际投递，不重发。"}, {"item": "调度公平性及sandbox-glob-startup-race上游根因", "reason": "证据不足：未证明永久饥饿或本仓库删除者；已有有界启动恢复，不改外部沙箱/deny/其他项目。"}, {"item": "独立架构、缓存及DPR/校准任务", "reason": "太大且已有独立原任务/拥有者，不混入普通修复批次。"}], "merged": null, "tests": {"tsc": 0, "vitest": 0, "files": 7, "cases": 48, "python_cases": 3, "python": 0, "scope": "定向固定回归；EZ2L文件其余22项未选；未跑完整沙箱套件，无重跑"}, "code_proposals": [], "implementation_domains": [], "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-071314-9f94258e-ff6c-46ae-9dc0-408ef6fb14a3-fix-batch/report.md"}
```

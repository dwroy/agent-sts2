import json,subprocess,hashlib,os
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261016-024304-2171fa54-e23c-48e3-8585-bbe357639c29-postmortem'; rid='TKAN594T9SKS'; summary={}
for name in ['runs','decisions','run-plans','states','sl-attempts','run-config','brain']:
    src=root/'logs'/f'{name}.jsonl'; dest=out/f'{name}.jsonl'; count=0; first=None; last=None
    proc=subprocess.Popen(['rg','-n','-b','-F',rid,str(src)],stdout=subprocess.PIPE)
    with dest.open('wb') as w:
        for line in proc.stdout:
            ln,offset,raw=line.split(b':',2); obj=json.loads(raw); obj['_line']=int(ln);obj['_offset']=int(offset);obj['_bytes']=len(raw);obj['_sha256']=hashlib.sha256(raw).hexdigest()
            w.write((json.dumps(obj,ensure_ascii=False)+'\n').encode());count+=1;first=first or obj.get('ts');last=obj.get('ts')
    rc=proc.wait();summary[name]={'count':count,'first_ts':first,'last_ts':last,'rg_exit':rc,'output_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
    print(name,summary[name],flush=True)
dec=[json.loads(s) for s in (out/'decisions.jsonl').open()]; lo=dec[0]['ts'];hi=dec[-1]['ts'];src=root/'logs/deepseek-reasoning.jsonl';size=src.stat().st_size
with src.open('rb') as f:
    left,right=0,size
    while left<right:
        mid=(left+right)//2;f.seek(mid)
        if mid:f.readline()
        pos=f.tell();line=f.readline()
        if not line:right=mid;continue
        ts=json.loads(line).get('ts','')
        if ts<lo:left=f.tell()
        else:right=mid
    f.seek(left)
    if left:
        f.seek(left-1)
        if f.read(1)!=b'\n':f.readline()
    start=f.tell();count=0
    with (out/'deepseek-reasoning.jsonl').open('wb') as w:
        for line in f:
            obj=json.loads(line);ts=obj.get('ts','')
            if ts>hi:break
            if ts>=lo:w.write(line);count+=1
    summary['deepseek-reasoning']={'count':count,'start_offset':start,'file_bytes':size,'window':[lo,hi]}
(out/'extraction-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('reasoning',summary['deepseek-reasoning'])

import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(s) for s in (p/'decisions.jsonl').open()];S=[json.loads(s) for s in (p/'states.jsonl').open()];B=[json.loads(s) for s in (p/'brain.jsonl').open()];R=json.load((p/'TKAN594T9SKS-resources.json').open())
with (p/'overview.txt').open('w') as w:
 def pr(*a):print(*a,file=w)
 for name in ['decisions','states','brain','run-plans','sl-attempts']:
  a=[json.loads(s) for s in (p/f'{name}.jsonl').open()];pr(name,len(a),'lines',a[0]['_line'],a[-1]['_line'])
 for c in R['combats']:
  e=c['entry'];x=c['exit'];last=c['last'];pr('COMBAT',c['sequence'],'F'+str(c['floor']),','.join(c['enemies']),'entry',e['hp'],e['max_hp'],e['potions'],'exit',None if not x else [x['hp'],x['max_hp'],x['potions']],'last',last['hp'],last['turn'],'lines',e['line'],None if not x else x['line'],'times',e['ts'],None if not x else x['ts'],'end',c['end'])
 pr('NONCOMBAT RESOURCE CHANGES')
 for c in R['resource_changes']:
  if c['combat_sequence'] is None:pr(c)
 pr('CODEX')
 for d in D:
  if d['decider']=='codex':pr('d'+str(d['_line']),d['floor'],d.get('turn'),d['label'],d['rationale'])
 pr('GUARDS')
 for d in D:
  if 'HP guard' in d.get('rationale',''):pr('d'+str(d['_line']),d['floor'],d['turn'],d['rationale'])
 pr('JEV example keys',[(k,type(v).__name__) for k,v in next(d for d in D if d['decider']=='jev').items()])
 pr('JEV example questions',json.dumps(next(d for d in D if d['decider']=='jev')['questions'],ensure_ascii=False)[:5000])
 pr('BRACKET STATS',collections.Counter(d['decider'] for d in D),collections.Counter(d['label'] for d in D if d['decider']=='code'))
 pr('BRAIN',collections.Counter((b['engine'],b['model'],b['effort'],b['accepted']) for b in B));pr('usage examples',D[2]['usage'],B[0]['usage'])
with (p/'key-states.txt').open('w') as w:
 for r in S:
  s=r['state'];f=s.get('run',{}).get('floor');t=s.get('turn')
  if f not in [30,31]:continue
  print('s'+str(r['_line']),r['ts'],'F',f,'T',t,s['screen'],'HP',s['run']['current_hp'],'E',s.get('combat',{}).get('energy'),'block',s.get('combat',{}).get('block'),file=w)
  print('combat',json.dumps(s.get('combat'),ensure_ascii=False),file=w)
  if s.get('hand'):print('hand',json.dumps(s['hand'],ensure_ascii=False),file=w)

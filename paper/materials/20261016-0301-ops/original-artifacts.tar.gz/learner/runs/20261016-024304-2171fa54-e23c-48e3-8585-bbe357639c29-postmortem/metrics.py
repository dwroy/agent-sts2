import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent;D=[json.loads(s) for s in (p/'decisions.jsonl').open()];S=[json.loads(s) for s in (p/'states.jsonl').open()];B=[json.loads(s) for s in (p/'brain.jsonl').open()];R=json.load((p/'TKAN594T9SKS-resources.json').open())
byfp={r['fingerprint']:r for r in S};J=[d for d in D if d['decider']=='jev'];C=[d for d in D if d['decider']=='code' and d['label'].startswith('combat/') and d['label']!='combat/plan-continue'];P=[d for d in J if 'plan' in (d.get('answers') or {})]
summary={'jev_calls':len(J),'jev_low':sum(d['confidence']<.35 for d in J),'jev_low_combat':sum(d['confidence']<.35 for d in P),'plan_questions':len(P),'best':dict(collections.Counter(d.get('rollout_best_chosen') for d in P)),'code_principal':len(C),'code_turns':len(set((d['floor'],d.get('sl_reloads'),d['turn']) for d in C)),'code_results':dict(collections.Counter(d['result'] for d in C)),'combat_turns':len(set((d['floor'],d.get('sl_reloads'),d['turn']) for d in D if d['label'].startswith('combat/'))),'jevreuse':sum('Jev-chosen' in d['rationale'] and d['label']=='combat/plan-continue' for d in D),'codereuse':sum('code-chosen' in d['rationale'] and d['label']=='combat/plan-continue' for d in D),'guards':sum('HP guard' in d['rationale'] for d in D),'fallback':sum(d['fallback'] for d in D),'jev_usage':{k:sum((d.get('usage') or {}).get(k,0) for d in J) for k in ['input_tokens','output_tokens']},'brain_usage':{k:sum((b.get('usage') or {}).get(k,0) for b in B) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']},'brain_latency_ms':sum(b.get('latency_ms',0) for b in B),'duration_seconds':(datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'))).total_seconds()}
executed=[d for d in C if d['result'].startswith(('completed','pending'))];summary['code_executed_principal']=len(executed);summary['code_executed_turns']=len(set((d['floor'],d.get('sl_reloads'),d['turn']) for d in executed))
print(json.dumps(summary,ensure_ascii=False,indent=2));(p/'metrics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('POTIONS')
for d in D:
 if d['chosen']['action'] in ['use_potion','discard_potion']:print(d['_line'],d['floor'],d['turn'],d['chosen'],d['expect'],d['result'])
print('FOCUS')
fc=0;allfc=0
for d in P:
 crit=d['questions']['plan']['criteria'];a=d['answers']['plan']['choice'];focus={k:json.loads(v).get('focus') for k,v in crit.items() if json.loads(v).get('focus')}
 if focus:fc+=1;allfc+=len(focus);print(d['_line'],d['floor'],d['turn'],'chosen',a,'focus',focus)
print('focus questions',fc,'focus options',allfc)
print('FIGHTS')
for c in R['combats']:
 turns=c['enemy_hp_audit']['turns'];obs=c['enemy_hp_audit']['observations'];ids={e['enemy_id'] for o in obs for e in o.get('enemies') or []};print(c['sequence'],c['floor'],'ids',ids,'turn hp need/lower',[(t['turn'],t['live_enemy_hp_start'],t['visible_enemy_hp_loss_lower_bound'],t['gaps']) for t in turns])
 print('HP',[(r['state'].get('turn'),r['state']['run']['current_hp'],r['_line']) for r in S if r['_line']>=c['entry']['line'] and r['_line']<=(c['exit'] or c['last'])['line'] and (r['state']['screen']=='CARD_SELECTION' or not r['state'].get('in_combat'))])

import json,re,hashlib
from pathlib import Path
p=Path(__file__).parent;rid='TKAN594T9SKS'
D=[json.loads(s) for s in (p/'decisions.jsonl').open()];S=[json.loads(s) for s in (p/'states.jsonl').open()];B=[json.loads(s) for s in (p/'brain.jsonl').open()];R=json.load((p/(rid+'-resources.json')).open());T=(p/'lesson-draft.md').read_text();checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
check('原始局身份',json.loads((p/'runs.jsonl').read_text())['character'].lower()=='silent')
check('窗口总数',len(R['combats'])==18)
for c in R['combats']:
 check('T1入口'+str(c['sequence']),c['entry_is_turn_one'])
 check('最大生命'+str(c['sequence']),c['entry']['max_hp']==70 and c['last']['max_hp']==70)
for c in R['combats'][:14]:
 e,x=c['entry'],c['exit'];check('获胜资源表'+str(c['floor']),f"{e['hp']}→{x['hp']}" in T and f"{e['line']}→{x['line']}" in T)
check('终局缺口',S[-2]['state']['run']['current_hp']==4 and S[-2]['state']['combat']['player']['block']==12 and sum(i.get('total_damage') or 0 for e in S[-2]['state']['combat']['enemies'] for i in e['intents'])==17)
check('终局归零',S[-1]['state']['screen']=='GAME_OVER' and S[-1]['state']['run']['current_hp']==0)
check('低信心',sum(d['decider']=='jev' and d['confidence']<.35 for d in D)==10)
check('最优原回答',sum(d.get('rollout_best_chosen') is True for d in D)==74 and sum(d.get('rollout_best_chosen') is False for d in D)==3)
check('护栏1次',sum('HP guard' in d['rationale'] for d in D)==1)
check('实际大脑',len(B)==33 and all((b['engine'],b['model'],b['effort'],b['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for b in B))
for n in [404093,404105,404117]:check('手套实际消耗'+str(n),'肾上腺素 scores 50 vs 中和 48' in next(d['rationale'] for d in D if d['_line']==n))
for quote in ['手套精简杂牌并叠力量；走商店、三火单精英。','单精英配四营火，末段商店补强并准备自爆防御。']:
 check('原话'+quote,any(quote in d['rationale'] for d in D))
check('三经验',len(re.findall(r'^- \[(?!记录)',T,re.M))==3)
check('单标题',T.count('## '+rid)==1)
(p/'verification.json').write_text(json.dumps({'checks':checks,'count':len(checks)},ensure_ascii=False,indent=2)+'\n');print('事实校验通过',len(checks))

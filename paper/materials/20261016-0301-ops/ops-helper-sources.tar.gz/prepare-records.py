from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, tarfile
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0301'; pub=r/'paper/materials/20261016-0301-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1; log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut; runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected=[x for x in runs if x['run_id']=='TKAN594T9SKS']; assert len(selected)==1; row=selected[0]
assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max='31',n_decisions='537',has_postmortem='1',performance_included='1').items()); brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':33} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],run={k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r))); write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==14; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==14
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(z)==set(a)|{'silent-0490'}
for ident in a:
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert a[ident].get(key)==z[ident].get(key),(ident,key)
 previous=a[ident].get('evidence',[]); later=z[ident].get('evidence',[]); assert later[:len(previous)]==previous; assert all(x['run']=='TKAN594T9SKS' and x['role']=='support' for x in later[len(previous):])
assert z['silent-0490']['character']=='silent' and z['silent-0490']['kind']=='fight' and z['silent-0490']['first_run']=='TKAN594T9SKS' and z['silent-0490']['asc']==10 and z['silent-0490']['prior']=='unknown' and z['silent-0490']['status']=='observed' and z['silent-0490']['version'] is None
assert all(x['run']=='TKAN594T9SKS' and x['role']=='support' for x in z['silent-0490']['evidence'])
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==19834 and b'## TKAN594T9SKS' not in oldlesson and lesson in (r/'notes/lessons.md').read_bytes(); readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged14_rows']=True; readback['parallel_physical_rows_preserved']='Only own chapter and14 original CLI rows staged; other root records and pre-existing whitespace differences remain physical/uncommitted.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0301原024301复盘TKAN594T9SKS done0闭环，无新增纯bug/老错重犯，不补派修复或追加重复队列。七流1141原行逐offset/bytes/SHA/JSON/显式身份核，Silent A10/F31负局、537决策/557状态/33原accepted Codex Sol6.1/xhigh；18战斗窗含14胜及4终战尝试，前三SL结算截断、最终4HP12挡对17攻完整需损5/实扣4分列，不封顶替换完整需求。正式19834字节单次追加章与旧物理前缀/原SHA核，65原材料检查非生产测试；14所属CLI为1新fight0490 observed/priorunknown、6旧项support及7提案追溯，旧claim/首证/prior/evidence前缀/status/version保、不记repeat或重复CLI。两原d070d42f/3072c09b提案文件SHA核沿原策略链pending，未实打保留肾上腺素同抽后继，不以静态分差或当步增力证明替换能活/纯bug，不由运维修游戏模型。当前selection.ts引用SHA不复原原dirty知识，原run-config cfa1启动先于R365，不能当其自然消费者；逐击/过量/重名实体/前三SL/未选后继/完整候选/dirty知识/校准时钟与未访Boss/纯战斗时长/缓存/实付账单未知保持。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0，cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性/keyscan CLEAN，本局has_postmortem1/537决策/33成功Codex入表；原计数告警与成本独立cut估计非账单保留。仅所属复盘/14CLI/生成表和证据提交，保并行物理记录/旧空白差，无代码/知识/版本/测试/派发/对局重启/账号home模型额度权限队列prompt操作，不关闭宽父。证据paper/materials/20261016-0301-ops/。\n'
note=f'\n- {at} [ops 学习闭环] TKAN594T9SKS复盘及14所属CLI已核，无新增纯bug；新增0490与六旧项补证、两原提案沿策略链pending，不补造保留牌后的胜负。论文唯一刷新exit0、{len(runs)}局、五一致性/keyscan通过；TKAN早于R365，不作其自然消费者。回执paper/materials/20261016-0301-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in p.glob('*.py'):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortem='TKAN594T9SKS',original_rows_checked=1141,original_lesson_bytes=19834,new_bug=False,owned_ledger_rows=14,evidence_updates=7,proposal_links=7,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=14,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

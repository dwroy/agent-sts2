from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0301';pub=r/'paper/materials/20261016-0301-ops';pub.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
bid='20261016-024301';run='TKAN594T9SKS';s=r/'learner/runs/20261016-024304-2171fa54-e23c-48e3-8585-bbe357639c29-postmortem';report=load(s/'report.json');b=load(r/'ops/codex-ops/learn.json')['batches'][bid]
assert report['appended']==[run] and report['bugs']==[] and report['ledger']['added']==['silent-0490'] and report['ledger']['repeats']==[] and len(report['ledger']['updated'])==6 and report['ledger']['check']==0
assert b['state']=='done' and b['rc']==0 and b['done']==[run] and b['missing']==[] and b['proposal_audit_errors']==[]
out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output)
spec=importlib.util.spec_from_file_location('raw_identity',r/'learner/extract_evidence.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
summary=load(s/'extraction-summary.json');refs=[];counts={};runrow=None;config=None;brains=[]
for stream in ['runs','decisions','run-plans','states','sl-attempts','run-config','brain']:
    frozen=(s/(stream+'.jsonl')).read_bytes();assert sha(frozen)==summary[stream]['output_sha256'];count=0
    with (r/'logs'/(stream+'.jsonl')).open('rb') as original:
        for line in frozen.splitlines():
            selected=json.loads(line);original.seek(selected['_offset']);raw=original.read(selected['_bytes']);row=json.loads(raw)
            assert sha(raw)==selected['_sha256'] and extract.run_identity(row)==run
            assert row=={k:v for k,v in selected.items() if k not in ['_line','_offset','_bytes','_sha256']}
            if stream=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
            if stream=='runs':assert row['character']=='SILENT' and row['ascension']==10 and row['floor']==31 and row['victory'] is False;runrow=row
            if stream=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains.append(row)
            if stream=='run-config':config=row
            refs.append(dict(stream=stream,line=selected['_line'],offset=selected['_offset'],bytes=len(raw),sha256=sha(raw)));count+=1
    assert count==summary[stream]['count'];counts[stream]=count
assert len(refs)==1141 and counts['decisions']==537 and counts['states']==557 and len(brains)==33
assert summary['deepseek-reasoning']['count']==0 and (s/'deepseek-reasoning.jsonl').read_bytes()==b''
verification=load(s/'verification.json');assert verification['count']==len(verification['checks'])==65
post=load(s/'post-append-audit.json');assert post['old_prefix_unchanged'] and post['appended_bytes']==19834 and post['raw_rows_reverified']==1141
prior=load(s/'lessons-before.json');physical=(r/'notes/lessons.md').read_bytes();assert sha(physical[:prior['bytes']])==prior['sha256']
lesson=(s/'lesson-draft.md').read_bytes();assert len(lesson)==19834 and sha(lesson)==post['appended_sha256'] and physical[prior['bytes']:prior['bytes']+len(lesson)]==lesson and physical.count(b'## TKAN594T9SKS')==1;(p/'owned-lessons.md').write_bytes(lesson)
source=load(s/'source-provenance.json');copy=(s/'live-selection.ts').read_bytes();sourcepath=source['path'].removeprefix('.worktrees/live/');assert sha(copy)==source['sha256'] and copy==subprocess.check_output(['git','show',source['live_head']+':'+sourcepath]) and (s/'live-selection-diff.patch').read_bytes()==b''
ids=set(report['ledger']['added']+report['ledger']['updated']);owned=[];ledgerrefs=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('by')=='learner:postmortem' and row.get('id') in ids and (any(e.get('run')==run for e in row.get('evidence',[])) or str(s) in raw.decode() or run in row.get('where',{}).get('lessons',[])):
            if row['op']=='add':assert row['id']=='silent-0490' and row['first_run']==run and row['status']=='observed'
            else:assert row['op']=='update' and set(row)<={'op','id','ts','by','evidence','where','note'}
            assert all(e['run']==run and e['role']=='support' for e in row.get('evidence',[]));owned.append(raw);ledgerrefs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==14 and sum(json.loads(raw)['op']=='add' for raw in owned)==1 and sum('evidence' in json.loads(raw) for raw in owned)==7
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'owned-ledger-references.json',ledgerrefs)
spec=importlib.util.spec_from_file_location('original_proposals',r/'learner/code_proposals.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);queue=m.fold(r/'paper/materials/learning/code-proposals.jsonl');proposals=[]
for ident in report['code_proposals']:
    item=queue[ident];f=Path(item['proposal']);assert item['character']=='silent' and item['runs']==[run] and item['source_task']=='postmortem' and item['target_task']=='strategy-proposal' and sha(f.read_bytes())==item['proposal_sha256'];proposals.append({k:item.get(k) for k in ['id','state','proposal','proposal_sha256','ledger','implemented_commit']})
write(pub/'postmortem-original-references.json',refs);write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,native=native,original_rows_checked=1141,stream_counts=counts,actual_accepted_codex=33,original_run_row=runrow,actual_run_config=config,source_reference=source,source_reference_does_not_reconstruct_run_dirty_knowledge=True,verification=verification,post_append=post,original_lesson_bytes=19834,old_lesson_prefix_preserved=True,original_ledger_rows=14,new_ledger_ids=['silent-0490'],old_support_ids=report['ledger']['updated'],repeats=[],original_proposals=proposals,new_bug=False,limits='Full per-hit/overkill and exit tails, same-name entity attribution, first three SL settlements, unchosen outcomes, whole-candidate realization, consumed dirty knowledge, calibrated clocks/unvisited Boss, pure combat time, cache and paid invoices remain unknown. TKAN started on cfa1, before R365; not its natural consumer.'))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);print(json.dumps(dict(rows=1141,ledger_rows=14,lesson_bytes=19834,new_bug=False)))

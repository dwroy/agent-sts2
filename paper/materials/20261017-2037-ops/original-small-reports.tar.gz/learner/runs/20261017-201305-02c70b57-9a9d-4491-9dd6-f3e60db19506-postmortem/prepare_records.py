import json,pathlib
p=pathlib.Path(__file__).parent.resolve();run='BXU0CKWKH2RU'
draft=(p/'lesson-draft.md').read_text().replace('完整需损11、差1血；结15毒','完整需损11、实扣剩10；结15毒')
(p/'lesson-draft.md').write_text(draft)
(p/'proposal-tail.md').write_text('''# 静默A10：毒杀战胜与芝士增血不能核销蜥蜴尾巴

来源任务：postmortem，20261017-201305-02c70b57-9a9d-4491-9dd6-f3e60db19506-postmortem。目标实现任务：独立strategy-proposal（具体派发批次尚未分配）。角色silent，仅本次已观察A10；既有授权Roy-2026-10-07-learning。账本silent-0339（repeat）、silent-0340（support）。

证据：BXU0CKWKH2RU F28 T4，s438434—438436：玩家14/79、0挡，猎人杀手HUNTER_KILLER 7血；蛇咬SNAKEBITE施毒5→12，之后敌清空、玩家15/80。F29与F32脑题明确资源used/available=false，source原话“HP rose 14 -> 15 after a lethal read (less 0 healed at the fight's end)”。F33第2/3/5试T10被判死读档；第6试T10在6血8挡对22攻击后实际40/81（s438785—438790），第12轮获胜7血。未实际发生攻击与战后当前/最大血各加1不能当复活证据。这是已有0339的新触发样本，notes/fix-queue-v4.md:980已有同类待修。

旧行为定位（只读live 3d691cff96dedd19855b00f4e9d448c43fe1d219）：agent/src/reflex/combat-plan.ts:5160的战后回复表、:5261任意HP上升分支、:5313—5314战胜核销、:5175后续排除复活。运行源码为6f2a20594536087c3453fa9076c5908cbec40e40+dirty，相关函数未变，窄diff在本目录。

拟改：先由实现学习者沿原0339提案查重；限定silent已观察A10，在战胜判据中核可见终战毒杀、当前/最大HP同步增长及其他回复来源，不把“曾有致命意图”直接当攻击已执行。证据不足保持复活资源unknown而非核销；支持明确真实复活的既有信号，不能简单禁用整个战胜分支。是否将CHOSEN_CHEESE战后增血纳入消歧，应由同局逐场+1与旧本角色材料进一步固定验证；不借其他角色数据补机制。不改SL_RELOAD_ON_REVIVE或增加重试次数。

验证：使用本任务原字节抽取及offset索引，冻结F28毒杀+1、F33实际复活40和首证833ZM0MJGWHC的旧假阳性；保留既有真实复活正例与SL恢复状态测试。需要固定输入的工程测试和原仓库沙箱入口。旧首证未重新展开不冒称已完成回放；当前任务没有运行模拟或改代码。

拟合：这是有限状态消费/证据消歧修复，不拟合新药水价格或伤害倍率；若需要扩大规则，按旧局调参、本局保留为后续验证，另核时间切分。样本是本局一个假阳性来源和一个后战真实复活，不算多次SL为独立局。未保留完整dirty知识、内部归零帧和反事实整战，不能宣称本修复使其通关。

预期影响：减少因复活误核销而不必要截断的可能；回退只撤本角色尾巴证据消歧补丁，保留日志/账本/旧规则。不变更铁甲战士、其他进阶或未知复活组合。当前pending，未implemented/shipped；实际上线由实现者/ops核真实源码祖先及通知Roy。
''')
(p/'proposal-continuation.md').write_text('''# 静默A10：跨抽弃、预算兜底和HP护栏之后的实线兑现审计

来源任务：postmortem，20261017-201305-02c70b57-9a9d-4491-9dd6-f3e60db19506-postmortem。目标任务：独立strategy-proposal（实际调度批次尚未分配）。账本silent-0418、silent-0125均support；角色silent，已观察A10。涉及combat/sl，既有授权Roy-2026-10-07-learning；没有本次代码实施。

证据：BXU0CKWKH2RU F48第6试T4，d1205/1206/1207，s439317—439322。原选PREPARED→MAD_SCIENCE→STRIKE_SILENT→ECHOING_SLASH→SURVIVOR条件预测损7、伤32、余57；实际只打PREPARED，预算兜底弃SURVIVOR，再结束，HP64→44、敌466→460，MAD_SCIENCE未建。弃牌候选removes_planned_continuation均null，不能把长方案当完成；尚未证明这是旧审计的源码回归或新的纯bug。

F48首试T4 d997一次护栏，将损20/伤65换损9/伤20，同有2力量；候选省11、少45伤，3回合7样本均0当窗死亡。实际MAD_SCIENCE、打击、生存者弃WITHER后又打SKEWER+，最终实损1、敌466→416；候选不能冒记实盘兑现。F48末试T5 d1210，SL用NOXIOUS_FUMES+替Jev原选PIERCING_WAIL；两候选当轮损16/4、5轮死亡23/24与14/24。实际只打3刀后结束、12挡对24攻击加6凋萎，损18，与完成4刀的候选不同。

旧/新行为边界：先查实际live是否已具S1.exp182的decision_id/状态/选择后继审计和既有HP guard审计，复用已有设施；若已有足够实现，用真实live祖先commit登记duplicate，不另造修复。若缺字段，限定silent A10记录原模型合法前缀、抽弃/超时中断原因、实际余牌与能量、后继是否仍可执行、护栏/SL换线前后预测及实际状态。审计只陈述条件和实线；若拟改超时后是否续打，须单独冻结合法候选验证。不能因这局就禁止弃生存者、强制毒雾/尖啸、取消HP护栏或改终局权重。

验证/拟合：固定本局T4与T5断点及d997护栏后续，对照原0418首证MTQ0EUBJ3R6T和现有测试；同一decision_id连到真实请求与states后继，按attempt分段，不能只比journal文字。当前仅观察，无参数拟合；策略实验必须按局和时间拆分，SL重复样本非独立胜率。缺完整另一弃牌后继、原攻线/尖啸线最终胜负，证据不足先保留原规则并等待独立实现者审计。

预期：消费者能区分“选择整条条件预测”和“实际执行前缀”；并不承诺胜率改善。回退仅撤新增审计或有独立证据的窄续打补丁；不改其他角色、未知进阶、药水持有价或运维prompt。当前pending，未implemented/shipped。
''')
updates=[]
def add(id,floor,turn,note,role='support'):
 updates.append({'id':id,'by':'learner:postmortem','evidence':[{'run':run,'floor':floor,'turn':turn,'role':role,'note':note}],'where':{'lessons':[run]}})
add('silent-0339',28,4,'猎人杀手7血12毒后清空，玩家14/79→15/80；F29/F32明确以HP rose 14->15来源误核销尾巴。F33末试T10实际6血8挡对22后复活40/81，第12轮7血胜；第2/3/5试T10先被判死截断。旧bug追加芝士战后+1触发证据，不证明修后通关。','repeat')
add('silent-0418',48,4,'末试原长方案PREPARED/MAD_SCIENCE/打击/回响/生存者预测损7伤32，实际只打PREPARED，超时弃生存者后结束，损20、仅结6毒；T5 SL换毒雾后的4刀候选只实打3刀。预测与实线补证，不认新纯bug或旧修复回归。')
add('silent-0125',48,4,'首试1次HP护栏：损20伤65改损9伤20，候选省11少45且同2力量；实际生存者弃凋萎后继续串刺，损1、本体466→416。3轮7样本均0当窗死亡，不能把候选血价当实际或全败。')
add('silent-0023',48,8,'末试余像2层，回响/偏折/防御/尖啸依次挡0→2→9→17→19；四次余像共8，与牌面挡和1敏捷分账。10血仍死于尖啸后30攻击。')
add('silent-0024',48,5,'末试12挡对24攻击另持6伤凋萎，实损18；T7弃凋萎不再计其9伤，T8无凋萎仍因攻击完整需损11而10血死，终态敌321。')
add('silent-0025',48,3,'末试T2蛇咬消耗人工制品2→1未施毒，T3迷雾+耗最后制品后蛇咬建7毒；增强后敌4→9力量，末T8尖啸9→3使21×2降15×2，但仍缺生存量。')
add('silent-0142',47,0,'到火53→74回21由永恒羽毛，实际动作升级毒雾，立即回血0；F40到火69→83后升级余像，F29/F32到火回复15与另选休息24分账。')
add('silent-0249',48,2,'六试均T2饮同槽0明耀；末试当步加1能量并建RADIANCE3，T3/T4/T5为2/1/消失。SL五次恢复不是新得药。爬行动物饰品临时3力另计，未得整场胜利。')
add('silent-0340',33,10,'F28敌7血12毒战后14→15/80非实际消耗尾巴；F33末试6血8挡对22后实际40/81，内部归零帧缺失。毒杀不能据假设攻击核销复活的既有观察补证。')
(p/'ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
for name,ledger,domains,summary in [
 ('tail',['silent-0339','silent-0340'],['combat','sl'],'复核既有0339：静默A10毒杀战后芝士+1使尾巴误核销，后战实际复活40反证；保留真实复活信号'),
 ('continuation',['silent-0418','silent-0125'],['combat','sl'],'静默A10跨抽弃/预算/SL中断与HP护栏候选血价的实线兑现审计；先查已live设施，不冒称新bug或强制新打法')]:
 v={'character':'silent','ledger':ledger,'runs':[run],'source_task':'postmortem','target_task':'strategy-proposal','domains':domains,'summary':summary,'proposal':str(p/f'proposal-{name}.md'),'rule_changes':True,'authorization':'Roy-2026-10-07-learning'}
 (p/f'proposal-{name}.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(p/'append-lesson.sh').write_text("#!/usr/bin/env bash\nset -euo pipefail\nexec 9>>/home/dw/Projects/agent-sts2/notes/lessons.md\nflock 9\nif rg -q '^## BXU0CKWKH2RU' /home/dw/Projects/agent-sts2/notes/lessons.md; then exit 22; fi\ncat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+draft+"EOF\n")
print('已备复盘、9条账本更新、2份待实施提案；尚未追加正式记录。')

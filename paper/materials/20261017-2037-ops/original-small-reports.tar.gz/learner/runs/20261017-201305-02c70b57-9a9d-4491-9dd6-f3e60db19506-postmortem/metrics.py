import json,pathlib,collections,re,datetime
p=pathlib.Path(__file__).parent;D=[json.loads(l) for l in (p/'decisions.jsonl').open()];B=[json.loads(l) for l in (p/'brain.jsonl').open()]
J=[d for d in D if d['decider']=='jev'];P=[d for d in J if d['label'].startswith('combat/plan-choice')];print('jev',len(J),'low',sum(isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35 for d in J),'plan',len(P))
ranks=collections.Counter(re.search(r'code rank (\d+|-)',d['rationale']).group(1) if re.search(r'code rank (\d+|-)',d['rationale']) else '?' for d in P);print('code rank',ranks)
roll=collections.Counter()
for d in P:
 qs=d['questions'].get('plan',{});ins=qs.get('instructions','')
 for token in ['best','最优','rollout']: 
  if token in ins:roll[token]+=1
print('plan instructions',P[0]['questions']['plan']['instructions'][:5500])
root=[d for d in D if d['decider']=='code' and d['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']];print('code root',len(root),'turns',len({(d['floor'],d.get('sl_attempt'),d['turn']) for d in root}),'select root',len([d for d in root if d['label']!='combat/end_turn']),'select turns',len({(d['floor'],d.get('sl_attempt'),d['turn']) for d in root if d['label']!='combat/end_turn'}))
print('guards',[(i,d['floor'],d['turn'],d['rationale']) for i,d in enumerate(D,1) if 'HP guard:' in d['rationale']])
print('sl overrides',sum('SL explore' in d['rationale'] for d in D),'fallback',collections.Counter(d['label'] for d in D if d['decider']=='code-fallback'))
for source,rows in [('brain all',B),('brain accepted',[b for b in B if b['accepted']]),('brain decisions',[b for b in B if b['label']!='run-plan']),('brain plans',[b for b in B if b['label']=='run-plan'])]:
 print(source,len(rows),{k:sum((r.get('usage') or {}).get(k,0) or 0 for r in rows) for k in ['inputTokens','outputTokens','cacheHitTokens']},'latency',sum(r.get('latency_ms',0) or 0 for r in rows))
print('dec usage', {k:sum((d.get('usage') or {}).get(k,0) or 0 for d in J) for k in ['inputTokens','outputTokens','cacheHitTokens']},J[0].get('usage'))
print('interval seconds',(datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'))).total_seconds())
print('route fields')
def walk(v,path=''):
 if isinstance(v,dict):
  for k,x in v.items():
   here=path+'.'+k
   if re.search('project|clock|hp_arriv|hp_at|boss_hp|damage_per_turn',k,re.I): print(here,str(x)[:1500])
   if len(path.split('.'))<5:walk(x,here)
 elif isinstance(v,list):
  for i,x in enumerate(v[:3]):walk(x,path+f'[{i}]')
for i in [1,2,19,37,48,50]:
 b=B[i-1];print('b',i,b['label'],'payload',list(b['payload']));walk(b['payload'])

import json, pathlib, hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261017-201305-02c70b57-9a9d-4491-9dd6-f3e60db19506-postmortem'; run=b'BXU0CKWKH2RU'
for name in ['runs','decisions','run-plans','sl-attempts','run-config','brain','fight-plans']:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists(): continue
 count=0; offset=0
 with p.open('rb') as f, (out/f'{name}.jsonl').open('wb') as dest, (out/f'{name}-index.jsonl').open('w') as idx:
  cutoff=p.stat().st_size
  for num,line in enumerate(f,1):
   start=offset; offset+=len(line)
   if offset>cutoff: break
   if run not in line: continue
   try: row=json.loads(line)
   except ValueError: continue
   if row.get('run_id',row.get('run'))!='BXU0CKWKH2RU': continue
   dest.write(line);idx.write(json.dumps({'line':num,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()})+'\n');count+=1
 print(name,count,flush=True)
ds=[json.loads(s) for s in (out/'decisions.jsonl').open()]; lo=min(d['ts'] for d in ds);hi=max(d['ts'] for d in ds)
count=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-window.jsonl').open('wb') as dest:
 for line in f:
  try: row=json.loads(line)
  except ValueError: continue
  if lo<=row.get('ts','')<=hi: dest.write(line);count+=1
print('window',lo,hi,'reasoning',count)

import json,pathlib,re,collections
p=pathlib.Path(__file__).parent;D=[json.loads(l) for l in (p/'decisions.jsonl').open()];P=[json.loads(l) for l in (p/'jev-prompts.jsonl').open()];idx=collections.defaultdict(list)
for row in P:idx[row['decision_id']].append(row)
counts=collections.Counter();audit=[]
for i,d in enumerate(D,1):
 if d['decider']!='jev' or not d['label'].startswith('combat/plan-choice'):continue
 m=re.search(r'Jev chose plan (\d+)/',d['rationale']);key='plan'+m.group(1) if m else ('p'+str(d['chosen']['option_index']) if d['chosen'].get('action')=='use_potion' else None)
 rs=[r for r in idx[d['decision_id']] if r.get('answers',{}).get('plan',{}).get('choice')==key] if key else []
 refs=[r.get('request',{}).get('state',{}).get('simulation_reference',{}).get('rollout',{}) for r in rs]
 refs=[r for r in refs if r.get('available') and (r.get('best') or r.get('tied'))]
 signatures={(r.get('best'),tuple(r.get('tied',[]))) for r in refs}
 if len(signatures)==1:
  best,tied=next(iter(signatures));counts['denom']+=1;counts['best']+=key==best;counts['best_or_tied']+=key in (best,*tied);counts['unique_best_questions']+=best is not None;counts['tied_questions']+=bool(tied)
  audit.append({'d':i,'decision_id':d['decision_id'],'choice':key,'best':best,'tied':list(tied),'matches_best':key==best,'matches_best_or_tied':key in (best,*tied)})
 else:counts['unresolved']+=1;audit.append({'d':i,'choice':key,'refs':len(refs),'signatures':len(signatures)})
print(counts)
(p/'jev-ranking-audit.json').write_text(json.dumps({'counts':dict(counts),'decisions':audit},ensure_ascii=False,indent=2)+'\n')

import json,pathlib,hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2');out=root/'learner/runs/20261017-201305-02c70b57-9a9d-4491-9dd6-f3e60db19506-postmortem';offset=0;n=0
with (root/'logs/states.jsonl').open('rb') as f,(out/'states.jsonl').open('wb') as dst,(out/'states-index.jsonl').open('w') as idx:
 limit=(root/'logs/states.jsonl').stat().st_size
 for num,line in enumerate(f,1):
  start=offset;offset+=len(line)
  if offset>limit: break
  if b'BXU0CKWKH2RU' not in line: continue
  row=json.loads(line)
  if (row.get('state') or {}).get('run_id',row.get('run_id'))!='BXU0CKWKH2RU':continue
  dst.write(line);idx.write(json.dumps({'line':num,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()})+'\n');n+=1
print('states',n)

# 静默A10：跨抽弃、预算兜底和HP护栏之后的实线兑现审计

来源任务：postmortem，20261017-201305-02c70b57-9a9d-4491-9dd6-f3e60db19506-postmortem。目标任务：独立strategy-proposal（实际调度批次尚未分配）。账本silent-0418、silent-0125均support；角色silent，已观察A10。涉及combat/sl，既有授权Roy-2026-10-07-learning；没有本次代码实施。

证据：BXU0CKWKH2RU F48第6试T4，d1205/1206/1207，s439317—439322。原选PREPARED→MAD_SCIENCE→STRIKE_SILENT→ECHOING_SLASH→SURVIVOR条件预测损7、伤32、余57；实际只打PREPARED，预算兜底弃SURVIVOR，再结束，HP64→44、敌466→460，MAD_SCIENCE未建。弃牌候选removes_planned_continuation均null，不能把长方案当完成；尚未证明这是旧审计的源码回归或新的纯bug。

F48首试T4 d997一次护栏，将损20/伤65换损9/伤20，同有2力量；候选省11、少45伤，3回合7样本均0当窗死亡。实际MAD_SCIENCE、打击、生存者弃WITHER后又打SKEWER+，最终实损1、敌466→416；候选不能冒记实盘兑现。F48末试T5 d1210，SL用NOXIOUS_FUMES+替Jev原选PIERCING_WAIL；两候选当轮损16/4、5轮死亡23/24与14/24。实际只打3刀后结束、12挡对24攻击加6凋萎，损18，与完成4刀的候选不同。

旧/新行为边界：先查实际live是否已具S1.exp182的decision_id/状态/选择后继审计和既有HP guard审计，复用已有设施；若已有足够实现，用真实live祖先commit登记duplicate，不另造修复。若缺字段，限定silent A10记录原模型合法前缀、抽弃/超时中断原因、实际余牌与能量、后继是否仍可执行、护栏/SL换线前后预测及实际状态。审计只陈述条件和实线；若拟改超时后是否续打，须单独冻结合法候选验证。不能因这局就禁止弃生存者、强制毒雾/尖啸、取消HP护栏或改终局权重。

验证/拟合：固定本局T4与T5断点及d997护栏后续，对照原0418首证MTQ0EUBJ3R6T和现有测试；同一decision_id连到真实请求与states后继，按attempt分段，不能只比journal文字。当前仅观察，无参数拟合；策略实验必须按局和时间拆分，SL重复样本非独立胜率。缺完整另一弃牌后继、原攻线/尖啸线最终胜负，证据不足先保留原规则并等待独立实现者审计。

预期：消费者能区分“选择整条条件预测”和“实际执行前缀”；并不承诺胜率改善。回退仅撤新增审计或有独立证据的窄续打补丁；不改其他角色、未知进阶、药水持有价或运维prompt。当前pending，未implemented/shipped。

import json,pathlib,collections
p=pathlib.Path(__file__).parent
D=[json.loads(s) for s in (p/'decisions.jsonl').open()]
with (p/'decision-summary.txt').open('w') as f:
 for i,d in enumerate(D):
  base=f"d{i+1} {d['ts']} F{d.get('floor')} T{d.get('turn')} a{d.get('sl_attempt')} {d['decider']} {d['label']}"
  f.write(base+' '+json.dumps({k:d.get(k) for k in ['chosen','rationale','confidence','fallback','journal','result']},ensure_ascii=False)+'\n')
with (p/'brain-summary.txt').open('w') as f:
 for i,l in enumerate((p/'brain.jsonl').open(),1):
  b=json.loads(l)
  f.write(f"b{i} "+json.dumps({k:v for k,v in b.items() if k not in ['prompt','question','facts','messages','knowledge','system','input','schema','codex','request','response','audit']},ensure_ascii=False)+'\n')
S=[json.loads(l) for l in (p/'sl-attempts.jsonl').open()]
for s in S:
 print({k:s.get(k) for k in ['floor','attempt','started_at','ended_at','result','turns','end_hp','enemy_hp','reason','hp','max_hp']},'keys',list(s))
print('decision labels',collections.Counter((d['decider'],d['label']) for d in D))
print('question sample',[(k,type(v).__name__,list(v)[:20] if isinstance(v,dict) else '') for k,v in next(d for d in D if d['label']=='combat/plan-choice')['questions'].items()])
print('journal sample',json.dumps(next(d for d in D if d['label']=='combat/plan-choice')['journal'],ensure_ascii=False)[:5000])
print('brain keys',list(json.loads((p/'brain.jsonl').open().readline())))
print('runplan keys',list(json.loads((p/'run-plans.jsonl').open().readline())))

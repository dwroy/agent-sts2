import json,pathlib,collections
p=pathlib.Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()];S=[json.loads(l) for l in (p/'states.jsonl').open()];I=[json.loads(l) for l in (p/'states-index.jsonl').open()]
R=json.loads((p/'BXU0CKWKH2RU-resources.json').read_text())
def powers(v):return {x['power_id']:x['amount'] for x in v.get('powers',[])}
def simple(row,idx):
 s=row['state'];r=s['run'];c=s.get('combat') or {};pl=c.get('player') or {}
 return {'s':idx['line'],'ts':row['ts'],'F':r['floor'],'T':s.get('turn'),'hp':r['current_hp'],'max':r['max_hp'],'block':pl.get('block'),'energy':pl.get('energy'),'powers':powers(pl),'played':pl.get('cards_played_this_turn'),'hand':[(x['card_id']+('+' if x['upgraded'] else ''),x['energy_cost'],x.get('resolved_rules_text')) for x in c.get('hand',[])],'enemies':[(e['enemy_id'],e['current_hp'],e['block'],powers(e),e.get('move_id'),[(t.get('damage'),t.get('hits')) for t in e.get('intents',[])]) for e in c.get('enemies',[])]}
with (p/'boss-frames.txt').open('w') as f:
 for c in R['combats']:
  if c['floor'] not in [17,33,46,48]:continue
  f.write(f"\nF{c['floor']} sequence{c['sequence']}\n")
  grouped=collections.OrderedDict()
  for row,idx in zip(S,I):
   if c['entry']['line']<=idx['line']<=c['last']['line']:grouped.setdefault(row['state']['turn'],[]).append((row,idx))
  for turn,frames in grouped.items():
   for row,idx in [frames[0],frames[-1]]:f.write(json.dumps(simple(row,idx),ensure_ascii=False)+'\n')
with (p/'build.txt').open('w') as f:
 for i,d in enumerate(D,1):
  if d['decider']=='codex' or d['label'].startswith(('rest/','event/')):
   f.write(f"d{i} F{d['floor']} {d['label']} "+json.dumps({k:d.get(k) for k in ['chosen','expect','rationale','journal','result']},ensure_ascii=False)+'\n')
 for i,l in enumerate((p/'run-plans.jsonl').open(),1):
  r=json.loads(l);f.write(f"plan{i} F{r['floor']} "+json.dumps({k:r.get(k) for k in ['ts','trigger','plan','raw']},ensure_ascii=False)+'\n')
with (p/'potion-changes.txt').open('w') as f:
 for ch in R['resource_changes']:
  a,b=ch['from'],ch['to'];pd=a['potions']!=b['potions'];hp=a['hp']!=b['hp']
  if pd or (hp and ch['combat_sequence'] is None):f.write(json.dumps(ch,ensure_ascii=False)+'\n')
with (p/'criteria-small.txt').open('w') as f:
 for n in [997,1205,1206,1208,1210,1214,1215]:
  d=D[n-1];f.write(f"\nd{n} T{d['turn']} "+d['rationale']+'\n')
  for q in (d.get('questions') or {}).values():
   if not isinstance(q,dict):continue
   for k,v in q.get('criteria',{}).items():
    try:v=json.loads(v)
    except (ValueError,TypeError):pass
    if isinstance(v,dict):
     v={k2:v2 for k2,v2 in v.items() if k2 not in ['quantitative_turn','boss_relative_margin']}
    f.write(k+' '+json.dumps(v,ensure_ascii=False)+'\n')
print('detail ready')

# 静默猎手策略提案批次报告

记录时间：2026-10-15T01:28:32+08:00。

十个派发id均保留waiting。本批完成原提案/账本/原字节证据/消费者边界复核，没有生产源码或知识数据修改，没有提交或合入live。现有子项实现不能代替宽提案整项验收；旧队列的“18冲突”没有作为本批新验出的阻塞理由，本批未尝试live合并。

基线为完整40位 `07a91f5871d84076f0663276879a040e55800fb5`。开工工作树干净，普通任务执行`git merge --no-edit main`返回Already up to date，HEAD保持该基线。本批learn.json绑定task=strategy-proposal、character=silent、worktree相符，reason=proposal，恰有十个proposal_ids；无proposal_repair、research_request、implementation_request。普通专题根请求属于20261010-150327，与本批不匹配，没有领取该专题或读其冻结正文。

## 范围与证据

派发十局：ZTRGYYMLR8SC, 1LMBFGSMCWKU, 9YT51CK8RC39, 25226ZFLNR1J, TCFAHJ9K19VY, ULP4TN1GNHMK, 61E2QS63Y9WU, K2JAGKVJAWZJ, 79UCJ0K6R9C1, 10GPK5XGHCK3。原提案ff1d168227e369e0另自有UJ0K3G10609Y；只为其既有证据复核追加该局，不扩展其它队列项或全历史。

十一局runs.jsonl及原状态均核为SILENT；A3一局、A4一局、A7一局、A10八局，机制与行为范围不混用。十个原提案SHA全部匹配；19个本角色账本原字段在ledger-before.json保留，当前相关经验只从knowledge/characters/silent/experience.json筛选，未把未核其它局的文本当本批验证。

统一入口`learner/extract_evidence.py`选中14636原行：states 7230、decisions 6936、SL 58、run-config 11、run-plans 52、brain 338、runs 11。每流source_size、各局计数、逐行offset/bytes/SHA与正文保存于evidence/。全部选中行已seek原日志逐字节读回，显式身份与角色/进阶复核、输出SHA及计数通过。run-plans按实际run字段选择，没有将正文提及算所属局。

冻结截点：states 12826978112；decisions 1438436724；SL 39392340；run-config 1705790；run-plans 7812558；brain 526969381；runs 329447字节。整流扫描中states/decisions各有2条无效JSON、brain有1条，保存原计数；这不是所选局缺失证据数量。没有用0行断言日志缺失。

187个资源战斗窗口、819次HP/药栏变化已由既有resource_chain从抽取原行读回；34个缺出口窗口保留，不把净HP差当敌方总伤害或胜率因果。资源摘要、完整窗口与敌血身份限制保存resources/，未重复追加历史复盘。

## 本批直接核到的边界

- K2JAGKVJAWZJ F33T10：毒42→48，CRUSHER本体54/挡78不变，玩家10血7挡不变；79UCJ0K6R9C1 F14T11：毒4→10，本体8血及玩家2血7挡不变，随后玩家0血时敌仍8血10毒。两次当步施毒不是整轮毒杀或时点胜因。
- K2 F46T1升级蜃景花1能，挡16→16；普通蜃景在T6的8毒/2敏条件实际加10挡。感染T6/T10的原帧实损分别32/11，T11死亡先于毒结算。本批9个原帧数值断言通过，仅作数据复核。
- ZTRG F17末试T2覆甲7、旧牌挡7；下一轮覆甲6、实际损4；末T14实死、神官仍58血。六试共享起点，缺退出帧不补零血或精确击杀回合。
- ZTRG三个同题原/替候选局部差合省10血/少24伤，完整原线与另一整场胜负没有实际对照；79 F14T3空过的约76%来自尾端估计，样本内实赢0/8，不能写8死或实战胜率。
- 药水请求与回执另存三局potion-actions.json。ZTRG有17饮用请求（15 completed、2 pending）、K2有14（13 completed、1 pending）及1弃药、79有4（2 completed、2 pending）。这些计数是请求/接口口径；实际生效仍需后帧，不能因pending补成完成，也不据此否定原复盘已用原帧核到的施毒。

## 当前源码与消费者核对

固定源码live参照 `473b9c0e1563e88d174cc24d6007eda5c5a9a9f9`；10个相关路径逐blob核对，source-live.diff.patch保存必要binary diff。八路径base/live字节相同，card-model.ts和rollout-live.ts只在所列注释中Roy/Dai文字不同；没有把当前树当十一局各自+dirty完整执行源码，旧dirty快照缺失仍为限制。

以下来源提交已核为该live祖先，仅证明对应子项源码已存在，不登记十个整包duplicate：

- `d1713559f2d237a04b681ec6497ce0c8798ae0f0`：同族当前快照/当前候选进度，不认证跨帧信徒身份或精确击杀时点。
- `be69855995737d6f381adb10bf248964832da24b`：选择阶段预测审计；单动作dispatch的whole_plan_executed与actual_turn仍未知。
- `5e0f884586521220d451b717c29b99e7876d6244`：升级蜃景零毒已观察范围，不当升级正毒或混合倍率全覆盖。
- `8043b289e8065a31799cfd1d331e0c6c933bc1d6`：特定Demon毒药组合；`154c9542711a4daf17bfa0b97eaa1ca81dc3d385`：另一套Crab的施毒当步事实。均不能冒称匹配本批K2/79两套完整条件。

四个原帧通过当前生产helper读回：ZTRG 292343血池269/神官182/信徒87；K2 293158升级零毒标记true；K2 292940与79 293463在当前Demon/Crab闸分别null/空对象，尚无这两套条件的覆盖。探针固定输入、不调模型/网络，输出在consumer-probes.json；不当自然游戏已消费或胜率改善。

八个A10单局运行既有audit-selection：六局完整输入返回0，K2/61两局因缺decision_id原始元数据返回1，stderr和零输出原件保留。精确缺行：K2 285853/285888，61 267517。原行未修改；在三个断点切开为五个独立连续段，原_line保持并禁止跨缺口，五段均返回0。

共11个成功审计输出，4726动作、920候选片段、1731相邻观测端点/2995未知区间、263整轮端点/549未知轮。完整候选收益字段均未认证，这是消费者的保守边界，不等于证明候选物理上没有执行。79全235区间未知，其中234因尝试身份字段缺失、1输入结束；原帧仍存在，不从零可连区间断言日志缺失。失败与排除元数据、各输出SHA在consumer-summary.json/consumer-excluded-rows.json保存。以上是历史固定消费者材料验证，不是新的tsc/vitest或实际live采用回执。

## 逐项处置

| 提案 | 账本 | 本批处置与缺口 |
|---|---|---|
| silent-proposal-43fe170707574455 | silent-0021, silent-0012, silent-0046 | waiting：当前同族快照已有；仍缺跨帧实体身份、缺退场帧的实际击杀时点和构筑组件兑现链，不能用当前血池字段认证整项追踪完成。 |
| silent-proposal-3f5a665dca133a8c | silent-0125 | waiting：三次局部候选省10血少24伤不能计整场实得；缺原候选完整执行、抽牌重问后的归属及受控整战反事实，现有阶段审计和端点只覆盖子项。 |
| silent-proposal-0b8ef30de463f317 | silent-0013, silent-0277 | waiting：缺新获/饮用/SL恢复与药水决策消费者的完整联合核验、晚喝或留药整战对照；现有覆甲分源和缺表标记不能覆盖全部资源来源追踪或拟持有价。 |
| silent-proposal-5367449b857450a7 | silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284 | waiting：缺临时减力/脆弱/覆甲/铜钹随机与滑溜/刀扇容量完整组合的生产调用校核；固定附伤3或未来固定覆甲7没有本批条件化证据，不能整包duplicate。 |
| silent-proposal-9b8890c2649a2734 | silent-0012, silent-0019, silent-0020, silent-0021, silent-0125 | waiting：缺护栏原线、晚喝铁心和未走路线同条件整场结果，以及SL/休息/药栏连续来源到消费者的贯通；既有快照和端点不覆盖宽资源父项。 |
| silent-proposal-645ff7b72e0b9991 | silent-0010, silent-0106, silent-0021, silent-0286 | waiting：升级蜃景零毒和感染结算顺序已有窄实现；仍缺尾端估计对完整候选实际收益的校准与替代整战胜线，0/8实赢和约76%尾估不能用于拟新排名权重。 |
| silent-proposal-68ef2857229d1287 | silent-0278, silent-0286 | waiting：两套完整修饰组合仅核到施毒当步加6、HP不变；缺范围与整轮后继的独立联合校准。当前Demon/Crab事实闸均不匹配，不能由当步观察认证完整数值推演覆盖。 |
| silent-proposal-9edfef7a6b2873c2 | silent-0020, silent-0019, silent-0021 | waiting：旧计划缺逐节点绝对HP/maxHP及成本、休息假设和同节点独立回放；当前比例字段不足以还原全部来源，不能用当前上限重解释旧投影或拟统一偏置。 |
| silent-proposal-ff1d168227e369e0 | silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178 | waiting：升级零毒子项已有；本批升级正毒、爆发重放与暗影混合条件缺隔离调用证据，三骑士T7额外2损完整伤源仍缺帧，不能整包认证或拟统一修正。 |
| silent-proposal-c64bdd50a949d16f | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | waiting：当步覆甲7、毒非即时伤害和SL恢复可核；仍缺提前建立能力、换瓶、早晚喝的整战反事实及持续资源消费者贯通，不能推广终局或持有价阈值。 |

每项原/拟行为、证据局/层/回合、反例、验证和回退见本批proposal.md。此次没有新代码提案id，只沿十个原CLI id。没有以框架/快照/局部机制完成关闭宽父项。下一步需要相应条件的新增实盘/隔离后继与连续来源；不能用报告次数补齐证据。

## 验证、记录与限制

源码撤除失败/恢复通过：不适用（没有新增源码）。tsc/vitest/cases均null，没有运行或借用旧批绿。没有git commit、合入、eval发布号、规则上线双通知或shipped；铁甲与所有其它角色行为保持现状。所有临时材料仅在本批scratch，logs只读；原请求/learn.json/原提案/知识文件未改。

开工期间三次独立只读命令在bubblewrap启动前因宿主并行回收的路径扫描ENOENT被拒；后续重试完成。它们不是源码/测试失败，原工具回执在本会话保留，摘要另存sandbox-startup-failures.md。完整消费者两次拒收也保留，不修改验证器以使其通过。

本批仅通过根ledger CLI为19个既有条目追加本批提案/报告链接及waiting说明，不改claim/status/evidence/first_run/prior/version，不直接写账本或代码提案队列。对应实际CLI与追加字节核验保存本批材料。报告及ledger链接不是经验库入库、消费者自然采用或用户指定父要求完成。

提案交运维路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-011303/learner/runs/20261015-011311-strategy-proposal/proposal.md。最终无源码回报：report.json。正式发布/测试/合入均未发生，不需要制造编号。

最终核验：19条根ledger CLI追加均按实际offset/bytes/SHA读回相符；gitleaks对本批712.36 MB材料扫描exit0、0发现。最终git status为空、HEAD仍为上述base；十个原Markdown SHA未变，report.json恰有十个waiting。没有生产源码提交/合入或测试成功声明。

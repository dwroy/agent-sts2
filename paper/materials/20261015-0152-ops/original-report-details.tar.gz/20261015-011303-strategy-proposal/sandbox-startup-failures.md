# 启动前沙箱错误原件定位

三次只读shell命令没有执行：bubblewrap初始化的仓库路径扫描返回`Fatal error: ripgrep unreadable glob scan failed`，宿主同时回收工作树的paper/materials目录，产生`No such file or directory (os error 2)`。

涉及工作树：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261011-012719。
原始完整错误在本批原生工具回执（结果0/1/2）保留；包括silent/20261007-1201-codex-only-exp70、20261006-1811-experience46-blocked、20261008-0917-events等并行消失路径。
没有读取这些材料、扩大权限或修改路径；重试完成本批既定读取。它不是源码失败或测试失败。

# 本批策略提案核验报告

记录时间：2026-10-15T01:09:49+08:00。批次：20261015-004301-s2-strategy-proposal；角色：silent。

结论：逐项核实全部十个派发ID，全部waiting。已有窄实现与原提案未完成范围分别列出；未获足够数据支持新策略规则，也未证明整项已实现。无源码/经验库改动、提交、合入、发布号或shipped登记。修复列表为空，merged=null。工作树HEAD仍是完整基线`07a91f5871d84076f0663276879a040e55800fb5`，开工干净，普通任务合main返回Already up to date。

## 派发及边界

对应learn.json行的task、character、worktree和十proposal_ids已核；没有proposal_repair/research_request/implementation_request。普通专题根请求绑定的是另一旧批次，因此没有读取另一专题work_spec、冒用纯研究身份或扩展普通队列。独立注册只用于已绑定专题，本批不适用。dispatch.json和proposal-records.json保存本批对应数据及原提案历史；原Markdown十个SHA均与专用队列相符，保留original.md副本。

来源仅为静默猎手原局/自有提案/相应账本及共用生产源码。10个派发锚点加原提案自带11个关联局，共21个已结束SILENT局，全部由runs.jsonl的原offset/bytes/SHA核身份；进阶分布为{1: 1, 5: 1, 6: 4, 7: 1, 8: 1, 10: 13}，未混成同等级统计。此21局不是全历史覆盖；额外局只用于本批原提案自带的机制核验，不领取它们关联的其他队列ID。全部原局code带dirty，固定当前源码不是当时完整运行树。

运行元数据：已核实际learner_launch的cwd/任务、command参数gpt-6.1-sol / xhigh / default和原生thread.started（01a13b4c-08e4-7000-b763-93585cf7ba8c），见launcher-settings-readback.json、native-launch-readback.json。正文high与宿主实际xhigh不同，本批不改启动配置/重启线程；原生turn_context请求模型读回仍未取得，不能只凭默认配置报告已验证请求模型。初次读取launcher PID的进程白名单为空，原件保留，未冒称PID设置已核。

## 冻结与原字节核验

共同入口extract_evidence.py提取八流，37,531原行；每流保存source_size、逐行offset/bytes/SHA、身份、正文和计数。prepare_evidence.py逐条seek原日志，复核SHA、JSON正文、显式身份无冲突及状态角色/进阶，再核输出总SHA/逐局计数，全部通过；证据与复核文件位于evidence/、evidence-verification.json。

| 流 | 冻结source_size | 本批原行 |
|---|---:|---:|
| states | 12819940247 | 18429 |
| decisions | 1432244522 | 17804 |
| sl-attempts | 39353804 | 155 |
| run-config | 1705790 | 21 |
| run-plans | 7803951 | 151 |
| brain | 525145690 | 950 |
| runs | 329447 | 21 |
| fight-plans | 2233957 | 0 |

run-plans按同一7803951字节截点调用共用入口另存evidence-recheck-run-plans/，151原行与第一次输出cmp完全一致。fight-plans在此冻结截点选到0行，仅说明这一截点未选到本批所属记录，不据此断言日志不存在。源流各自有invalid_lines统计，所有接收行均单独复核；不把正文提及当局身份。

八局抑制窗口独立提取11对（GXN四对，其余七局各一对），基础ID各牌区合计全部守恒；分组*数量按原文本展开，没有将同ID多副本合成唯一实体。详见dampen-window-observations.json。守恒和战内版本观察仍不证明物理身份、纯改标瞬时帧或抽序，因此两条抑制提案保持waiting。

## 源码与消费者

固定live读回提交：`473b9c0e1563e88d174cc24d6007eda5c5a9a9f9`。18个源码/消费者路径保存base/live Git blob、SHA和.txt原字节；15路径完全相同，draws.ts/judge.ts/card-model.ts三个路径全部差异仅注释Roy→Dai（15处），逐diff及归一化核过。没有以当前源码冒认历史dirty树，也不只凭Git祖先认定宽提案完成。

普通生存者窄修复`bf423c173d3be348a4ad714e1d26516df619ff41`确为该live祖先：无绷带单弃已解耦；但新增凋萎仍为终局计数，多选选择未知，尚不能贯通PD9原T10的新实体、选择完成及32挡/24持伤/23攻击。因此d7b8整项不记duplicate。

现有audit-selection.ts及resource_chain.py只消费本批四个冻结A10输入，均nice19、串行、无网络/LLM/游戏动作；四个audit退出码均0。准备时原decision_id缺失的六个map/route-change元数据行另列排除，保留原行号而不跨接。consumer-summary.json保存汇总。

| 局 | 动作/片段 | 已核动作端点/未知 | 已核整轮/未知 |
|---|---:|---:|---:|
| GXNKW8X1XYJP | 646/116 | 178/468 | 20/83 |
| L2TSFU62Z57Z | 441/93 | 278/163 | 51/32 |
| PD9AYQVMLQW6 | 1015/149 | 457/558 | 69/99 |
| YF0LXT1QSTGG | 1065/204 | 424/641 | 54/106 |

合计3167动作/562片段，1337相邻动作端点/1830未知，194整轮端点/320未知。562片段的完整候选结果与actual_rollout_best全部null：这是消费者明确保留未知，不能当没有实际执行动作，也不能认证完整候选/卡牌因果/胜率收益。资源链实际包含84个战斗窗口与373个血药变化（以consumers/preparation.json为准），胜战、SL重启、缺出口分别保留。

## 逐项处置

完整原提案的证据局/层/回合、账本ID、反例、预期行为、验证与回退见proposal.md；十项的结构化处置见proposal-review.json与result.json。每一项继续waiting的具体缺数已写入，没有遗漏派发ID；普通单弃、预测、回执或局部观测的子范围不关闭其父范围。code_proposals沿用原十ID，不重复登记新ID或把专题request_id当提案。

重点核实：GXN F35/38/40胜战仍净耗56、F44净耗66；PD9 F48以58赢后仅10空药进入F49六次；L2 F14赢战44→24且两药空。PD9末T10实际弃一张后仍需损15且3HP归零，不能报实际额外多损11或修后转胜。L2末T6三线各1200零胜并列、7伤线五轮死亡14/24而结束11/24且侧步未建模，不能以即时7伤强推新终局规则。九护栏中四个被SL覆盖，不能累计候选省血为实省。这些均是原提案已有的限制/反例，本次独立核实，没有发现需要强行支持的新假设或另建异议通知。

## 检查、失败原件及交付

固定材料断言最终51项通过，见fact-checks.json。这不是新源码回归或实际独立新局验证。首轮资料断言把原unplayable_reason误写为BlockedByHook，实际原值blocked_by_hook；只修scratch断言后51项通过。check-facts.attempt1.err/log与check_facts.attempt1.py.txt原字节保留，第二轮日志另存，没有改原状态。l2-hp-guards.json的0行仅为旧帧缺结构化hp_guard的初稿，随后独立用原rationale核九次，原件保留。

本次无生产源码改动，撤源码失败/恢复验证不适用；tsc/vitest/cases均null，没有跑或虚报绿色。没有源码提交、不推送、未操作live合入锁/知识刷新/eval版本或对局。提案追溯只经根ledger.py update追加where.proposal和note，不改已存在claim/status/version/first_run/prior/evidence，不标shipped；CLI输入与追加回执另存。本批不关闭学习父请求，不改原提案/队列状态、请求注册、ops prompt或任何通知ACK。

交付路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-004301-s2/learner/runs/20261015-004307-strategy-proposal/proposal.md；/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-004301-s2/learner/runs/20261015-004307-strategy-proposal/report.md；/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-004301-s2/learner/runs/20261015-004307-strategy-proposal/result.json。安全扫描与最终Git/账本读回见completion-checks.json；未取得的验收结果不写成功。

最终读回：31条CLI追加的字段仅op/ts/id/by/where/note，绝对proposal链接已从fold读回；受保护的claim/status/version/first_run/prior/evidence没有变更。首轮相对/绝对路径断言失败及随后apply_patch新文件写入失败均保留说明；授权shell写入后读回通过，没有重复写账本或扩大权限。gitleaks小文件扫描exit0、无发现；大型原日志及gzip输入不在扫描声明内。HEAD仍为完整base且git status/diff干净，见completion-checks.json。

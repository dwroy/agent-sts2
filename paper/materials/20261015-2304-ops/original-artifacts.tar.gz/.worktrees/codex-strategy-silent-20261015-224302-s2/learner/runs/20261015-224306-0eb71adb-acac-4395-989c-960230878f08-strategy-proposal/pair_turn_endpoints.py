import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = [json.loads(line) for line in (HERE / 'evidence/states.evidence.jsonl').open()]
decisions = [json.loads(line) for line in (HERE / 'evidence/decisions.evidence.jsonl').open()]
by_line = {item['line']: item for item in decisions}
state_index = {}
for item in states:
    row = item['row']
    state_index.setdefault((row.get('observed_ts'), row.get('fingerprint')), []).append(item)


def match(row):
    found = state_index.get((row.get('observed_ts'), row.get('fingerprint')), [])
    if len(found) != 1:
        return None
    return found[0]


def endpoint(line):
    original = by_line[line]
    start = original['row']
    context = [start.get(k) for k in ['run_id', 'floor', 'sl_attempt', 'sl_reloads']]
    index = decisions.index(original)
    end = None
    after = None
    for i in range(index, len(decisions) - 1):
        current, following = decisions[i], decisions[i + 1]
        row, next_row = current['row'], following['row']
        if [row.get(k) for k in ['run_id', 'floor', 'sl_attempt', 'sl_reloads']] != context or row.get('turn') != start.get('turn'):
            break
        if (row.get('chosen') or {}).get('action') == 'end_turn' and next_row.get('turn') == start.get('turn') + 1:
            if [next_row.get(k) for k in ['run_id', 'floor', 'sl_attempt', 'sl_reloads']] == context:
                end, after = current, following
            break
    if not after:
        return {'question_line': line, 'endpoint': None, 'reason': '没有唯一完整下一轮端点'}
    first, last, next_state = match(start), match(end['row']), match(after['row'])
    if not first or not last or not next_state:
        return {'question_line': line, 'endpoint': None, 'reason': '状态时戳和指纹不能唯一匹配'}
    before = first['row']['state']['combat']
    after_combat = next_state['row']['state']['combat']
    enemy_ids_before = [e['enemy_id'] for e in before['enemies']]
    enemy_ids_after = [e['enemy_id'] for e in after_combat['enemies']]
    known = enemy_ids_before == enemy_ids_after and [e['max_hp'] for e in before['enemies']] == [e['max_hp'] for e in after_combat['enemies']]
    rows = decisions[index:decisions.index(after) + 1]
    return {
        'question_line': line, 'attempt': start.get('sl_attempt'),
        'turn': start.get('turn'), 'end_request_line': end['line'], 'next_decision_line': after['line'],
        'state_lines': [first['line'], last['line'], next_state['line']],
        'source_decisions_contiguous': all(b['line'] == a['line'] + 1 for a, b in zip(rows, rows[1:])),
        'net_hp_loss': before['player']['current_hp'] - after_combat['player']['current_hp'],
        'net_enemy_hp_decrease': sum(e['current_hp'] for e in before['enemies']) - sum(e['current_hp'] for e in after_combat['enemies']) if known else None,
        'scope': '相同问题起点到下一轮的观察净差，非逐来源伤害或整个候选执行证明',
    }


rows = [endpoint(n) for n in [270216, 270282, 271309, 271348, 271992, 272040, 271982, 272195]]
(HERE / 'paired-turn-endpoints.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
for row in rows:
    print(json.dumps(row, ensure_ascii=False))

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
assigned = json.loads((HERE / 'assigned-proposals.json').read_text())
dispatch = json.loads((HERE / 'dispatch.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
verified = json.loads((HERE / 'evidence-verification.json').read_text())
details = [
    {
        'title': '感染棱柱技能污染的联合血价',
        'evidence': 'DUZUBAJ3A8GP，F27 T4—5；states 274830—274838：火花3时技能污染3/6，T5火花6且旧污染消失，新技能污染6/12/18；毒层7→13与17挡同时存在。',
        'known': 'turn-solver.ts 已按技能累积 vitalSpark、逐段在虚弱前计算 tainted；rollout.ts 读取招式 selfPowers 的火花增量。',
        'counter': '技能同时提供毒或挡，能力不等同技能；局部多付血不能推出一律少打技能。',
        'reason': '缺历史dirty运行实际消费的A10移动表，以及毒、挡、污染跨轮的完整候选联合回放；本批未定位新确定性公式差异。',
        'validate': '冻结本局实际消费的招式表、手牌与状态，逐步核技能/能力、火花增长、污染撤销、毒和挡，再用独立后置局验证；不能以当前刷新表代替旧输入。',
        'behavior': '保留当前选线；补足输入后只在观察范围提供联合毒/挡/血价参考，不强制过滤技能。',
    },
    {
        'title': '抢夺与死亡返还的逐来源归属',
        'evidence': '5PM6JAQG6FNQ，F39 T2—6；states 274341/274351/274352/274354：玩家力敏−2→−4，两次步法把敏捷−4→−2→0，力量仍−4。',
        'known': '当前现场负力量/负敏捷可进入卡牌模型；combat-plan.ts 将 POSSESS_* 标为现场事实，不能据此证明逐来源死亡返还模型完整。',
        'counter': '建立步法不表示已有正敏捷；末次即使失落退出，遗忘仍可造成致命攻击。没有固定击杀序的完整受控胜线。',
        'reason': '缺逐实体累计被夺量、非抢夺属性来源及死亡返还的完整冻结输入；当前总负属性不能替代应返还量，另一杀序后继未知。',
        'validate': '逐来源固定抢夺、增加自身属性、死亡/退场和返还事件；覆盖同轮毒杀、后续重抢与索引重排，未知累计量保持未知。',
        'behavior': '保留现有动作与现场负属性；有完整来源证据后再验证返还，不设置固定先杀序。',
    },
    {
        'title': '下水道蚌加压与当前进阶事实',
        'evidence': 'CA5KE8GFJ9X2，F13 T1/3/5；states 273237/273252/273263：力量0/4/8，喷水11/15/19；273254/273268弱后11/14，末玩家2→0。',
        'known': 'monster-db.ts 对当前进阶已见HP/移动伤害直接选取，不套五样本门槛；room-costs.ts 与怪物房间成本仍各有5样本门槛。',
        'counter': '覆甲轮初9/9/8/7/6只约束这些帧；不能由该序列补完整减层条件或改成固定房间成本。',
        'reason': '缺原dirty运行实际消费的A10移动表快照和覆甲完整减层条件的独立输入；当前首样本读取路径已存在，未定位新的当轮缺陷。',
        'validate': '冻结本局招式表/调用输入，验加压、弱与覆甲；事实首样本可读、房间成本不足5不借该事实替代统计。',
        'behavior': '保留当前进阶数据库读取与原选线，不降低房间代价五样本门槛。',
    },
    {
        'title': '高电压增长与新召唤者的身份边界',
        'evidence': '5PM6JAQG6FNQ，F38 T2—4；states 274307/274308/274313：23上限电击力量0/2/4、攻击0/17/19；盘面index从4变3。',
        'known': 'rollout.ts 的 STRENGTH_GROWTH_POWERS 包含 HIGH_VOLTAGE_POWER，敌轮将 e.growth 加入力量；已存在不等于验证了所有替换实体。',
        'counter': '本局只有该连续存活窗口；盘面索引变化不证明出现新的召唤代际，未执行先杀爪牙候选也不证明后场得救。',
        'reason': '缺稳定召唤代际、新同类替换及累计量归属的冻结输入；一个连续存活窗口不能验证新实体不继承旧计数。',
        'validate': '保留实际实体/召唤代际映射，固定连续增长、旧实体退场、新同类进入及索引重排，确认计数隔离后再论杀序。',
        'behavior': '保留现有增长与候选；只由可核实的实例输入继承累计量，不用名字/索引猜代际。',
    },
    {
        'title': '沙虫SL、护栏与已建能力的兑现分账',
        'evidence': '8JRE1C4H4Z2W，F33首/第三试T2，decisions 270216/270282同指纹；状态端点276208→276212与276274→276278，净损3/15、敌本体净减10/17。原题推演死亡0/24与5/24，不能称同死亡率。另原提案F17 T6、F33第二试T5、末试T11仍为待校准窗口。',
        'known': 'silent-selection-audit、silent-sl-resource-comparison、silent-hp-guard-audit 分别保存预测阶段、替换差值和护栏差值，明确实际结果未认证。',
        'counter': '防御替换有当轮省血反例；抽牌重问之后原候选未必完整执行，末轮死亡截断不能补未来毒伤。',
        'reason': '缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准；预测/观察端点已有不等于整项完成。',
        'validate': '绑定原答、护栏、SL、首次回执及每次重规划；分别核当前HP、整轮端点、逐来源毒/挡、能力建立和未执行续步。',
        'behavior': '保留现有探索、护栏和持续价值权重；补齐执行归属后再评估策略，不能把审计上线当收益。',
    },
    {
        'title': '全败SL替线的未执行续步与资源代价',
        'evidence': 'YF0LXT1QSTGG，F48第二/第三试T1，decisions 271309/271348同指纹；states 277327→277337与277366→277373净损0/9、敌净减45/38。预测0/10、54/36另列。',
        'known': 'silent-sl-resource-comparison 保存预测差值，silent-selection-audit 的 actual_turn=null，不能将 pending_dispatch 解释为整候选已执行。',
        'counter': '同局F33第二试SL实胜余20血（sl-attempts 929）；F48有弃牌后候选未完成的反例。不能据该局禁止探索。',
        'reason': '缺未执行续步、完整替代线的资源/胜负对照及跨重问归属；同轮多9血少7伤不足以校准SL惩罚或禁止探索。',
        'validate': '固定预测/实净差与截断点，记录抽弃牌后的新候选；保留F33胜利反例，按独立局后移验证新规则。',
        'behavior': '保留SL允许探索的规则；已知劣化作为有条件观察，不拟全局血价系数。',
    },
    {
        'title': '实验体分阶段、零毒触媒与敏捷时序',
        'evidence': 'YF0LXT1QSTGG，F48末试T3—5；states 277512/277513由111上限且4毒切到212上限零毒；277519触媒2而毒0；277520/277523挡13→23，277526敏5→6但挡仍23；277527敌160、玩家18、攻击44。',
        'known': 'silent-phase-current.ts 限Silent A10 F48的111/212当前帧，区分组件持有/已建能力/现毒/现挡；rollout.ts 已在换相清毒/力量。',
        'counter': '前试建毒雾/余像仍败；当前持有或建立组件不证明之后能兑现，不把末帧死亡后的55意图倒当致死攻击44。',
        'reason': '缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；当前快照及零毒说明只覆盖局部。',
        'validate': '冻结各阶段状态，分列即时毒、已结毒、触媒额外结算、敏捷取得与挡牌顺序；独立后置局包含已建仍败的反例。',
        'behavior': '保留当前阶段事实和候选排序；不预支后续毒、下一阶段收益或后取得敏捷。',
    },
    {
        'title': '双蟹B2零胜并列的探索排序',
        'evidence': 'XP2SL33HT0D9，F33首/第二试T3，decisions 271992/272040同指纹：净损9/14、敌净减24/27；首/末试T1，271982/272195同指纹：净损2/10、敌净减25/34。',
        'known': '现有SL比较已经分列本轮预测血价，B2零差仅是该题有限样本并列，不等于安全；本批复核了实际轮端点。',
        'counter': '替换同时有手里剑成长、抽牌和随机药瓶；后续抽序与动作变化。末试T2实际零损，不能用少挡牌数判所有舍挡有害。',
        'reason': '缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列证明低当轮损失优先的新排序更好。',
        'validate': '同预算冻结整战池、相同随机/抽序，单列当轮血价、输出与成长；本局作发现集，新独立A10双蟹作后置验证。',
        'behavior': '保留现有并列集合和选线；低损失优先仅保留为待验证候选，不引入惩罚常数。',
    },
    {
        'title': '双蟹朝向、临时减力和能力兑现窗口',
        'evidence': 'XP2SL33HT0D9，F33末试T2—5；states 278236轮初14挡，278237爪负9力/攻击0，278242恢复；278249/278252/278253激光57→38→28；278261敌153/125而玩家0。',
        'known': '现有模型有朝向、临时减力恢复和船夹板T2 14挡；本批只核此A10来源局，原稿引用A1/A6的独立早证未重新抽取。',
        'counter': '减力到期恢复、朝向与弱贡献不同；脆弱下挡与攻击计数成长需按实际时点，不能把已建能力当恒定保命值。',
        'reason': '缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不能将整个提案登记duplicate。',
        'validate': '逐候选分现挡/新增挡、朝向/弱/临减、已结/未结毒和成长时点；原稿早证与未观察升级条件另行按角色核实。',
        'behavior': '保留原权重、护栏和出牌规则；仅在证据条件内补事实参考，不外推未见组合。',
    },
    {
        'title': '机制、SL及路线资源的历史联合校准',
        'evidence': '原提案锚点YF0LXT1QSTGG F48 T1/T4—5、XP2SL33HT0D9 F33 T1—5；本批复核这些帧和其余四派发局，没有重新完成原101局分母。',
        'known': '现有候选/护栏/SL审计与阶段快照各覆盖部分；六锚点的8268原行不能等同101局的全历史核验。',
        'counter': '有SL实胜，也有能力已建仍败；SL血重置、实际回血、资源持有和实际消耗不能混账，未选路线/留药无受控后继。',
        'reason': '六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。',
        'validate': '沿原提案保留101局范围的逐子项分母；按独立局/时间分组，分别验证资源来源、候选实际执行及替线后继。',
        'behavior': '保留原游戏规则和历史知识；不从有限锚点拟必休血线、留药价值、牌组上限或固定目标顺序。',
    },
]

assert len(details) == len(assigned) == 10
for detail, proposal in zip(details, assigned):
    detail.update({'id': proposal['id'], 'ledger': proposal['ledger'], 'runs': proposal['runs'],
                   'original_proposal': proposal['proposal'], 'original_sha256': proposal['proposal_sha256'],
                   'state': 'waiting'})
(HERE / 'proposal-dispositions.json').write_text(json.dumps(details, ensure_ascii=False, indent=2) + '\n')

paragraphs = [
    '# 本批十项原提案的逐项核验与处置',
    '',
    '批次：20261015-224302-s2-strategy-proposal。角色silent，仅本批六局A10。基线：' + source['base'] + '。',
    '本批为普通proposal领取，learn.json没有research_request、implementation_request或proposal_repair；根专题请求属于另批，不承接。启动工作树干净，git merge --no-edit main返回Already up to date。未派下级agent。',
    '本文件是原十ID的处置附件，不替换原提案、不新建重复ID、不改原请求/经验/源码。十份原Markdown逐SHA相同，保存在original-proposals/，来源与指纹见original-proposal-manifest.json。',
    '本批没有发现足以提出新确定性修复或新策略权重的缺陷。全部waiting，不将部分已存在源码冒记整个提案duplicate/implemented。候选预测、实际动作回执、整轮观察端点、逐来源归属与完整反事实分别验收。',
    '共同验证边界：这些局仅作原发现/固定证据复核；同局SL不是独立样本，不把未执行续步补成胜局。源码和经验不改，无需代码回退；后续真正实现须固定夹具撤源码失败/恢复通过、原沙箱检查、实际live与运维登记。',
]
for d in details:
    paragraphs.extend(['', '## ' + d['id'] + '：' + d['title'], '',
        '账本：' + '、'.join(d['ledger']) + '。处置：waiting。',
        '证据：' + d['evidence'], '当前实现范围：' + d['known'],
        '反例与限制：' + d['counter'], '缺数据及未实现原因：' + d['reason'],
        '旧规则与预期行为：' + d['behavior'], '验证方法：' + d['validate'],
        '预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。',
        '原提案：' + d['original_proposal'] + '；SHA256=' + d['original_sha256'] + '。'])
(HERE / 'proposal.md').write_text('\n\n'.join(paragraphs) + '\n')

table = ['|原提案ID|账本|处置|具体缺口|', '|---|---|---|---|']
for d in details:
    table.append('|' + d['id'] + '|' + '、'.join(d['ledger']) + '|waiting|' + d['reason'] + '|')
pair_table = ['|局/层/轮|同指纹决策行|观察净损血（原/替）|敌本体观察净减（原/替）|', '|---|---|---|---|',
    '|8JRE1C4H4Z2W F33 T2|270216/270282|3/15|10/17|',
    '|YF0LXT1QSTGG F48 T1|271309/271348|0/9|45/38|',
    '|XP2SL33HT0D9 F33 T3|271992/272040|9/14|24/27|',
    '|XP2SL33HT0D9 F33 T1|271982/272195|2/10|25/34|']
report = [
    '# 静默猎手策略提案批次报告', '',
    '结果：十项全部waiting，无源码/知识修改、无提交、无合入、无新版本、无shipped。每项证据、层/回合、原账本、反例、预期行为和验证见[proposal.md](proposal.md)。',
    '本批task=strategy-proposal、character=silent、reason=proposal；没有专题或冻结实现绑定。原工作树与派发六局集合精确匹配。base=' + source['base'] + '；main合并返回Already up to date，HEAD保持该基线。',
    '## 证据与结论边界',
    'runs.jsonl已核六局均SILENT/A10，结束时间2026-10-07，皆有dirty运行标记。runs.jsonl的旧deepseek_calls与deciders字段分列保留，不据载荷字段称纯Codex大脑；本批未独立核学习者原生会话模型/推理设置，也未更改运行配置。',
    '使用本树learner/extract_evidence.py默认六流。共8268行：states 4062、decisions 3941、sl-attempts 38、run-config 6、run-plans 33、brain 188。每流source_size、计数和输出SHA在evidence/evidence-manifest.json；每行保留source/line/offset/bytes/SHA。audit_evidence.py逐行从只读原日志seek读回核字节SHA、JSON、显式身份与截点。原流外部invalid行数2/2/0/0/0/1，未作为本批证据。CA5的SL流0行仅表示该截点未选中，不据此声称日志缺失。',
    'run-plans按run字段确立所属，不把正文提及归入本局；其他流检查run_id/state.run_id/fingerprint.run，冲突身份不接收。所选战斗帧另核角色和进阶。共45项材料断言（evidence-verification.json的26项与mechanism-checks.json的19项）通过；这是材料核验，不是tsc/vitest或策略效果测试。',
    '重点窗口保存1060状态帧摘要、1043决策摘要。四组原问题均完整指纹相同；端点按observed_ts+fingerprint唯一回连，end_turn及下一轮决策同局/层/尝试、原行连续。端点净差仍不证明逐来源伤害、整候选完整执行或整战因果。',
    '\n'.join(pair_table),
    '具体端点及来源状态行见paired-turn-endpoints.json。8JRE五轮死亡0/24与5/24不能称相等；YF预测0/10、54/36不能替代观察0/9、45/38。YF F33第二次SL实胜余20血是反对一律禁探索的反例（sl-attempts 929）。原始胜/败尝试保存在attempt-outcomes.json。',
    '当前原样本可确认污染增长、喷水随力/弱变化、负属性、临时减力恢复、朝向与阶段当前帧；不能从这些有限观察拟最优技能频率、杀序、SL惩罚、留药价值或路线阈值。完整冻结输入、跨重问执行归属、逐来源累计量与受控整战后继仍缺，故保持原行为。未发现需要另通知Roy的新反证或旧知识冲突。',
    '## 现有源码与live范围',
    '读回live=' + source['observed_live'] + '，source-readback.json记录12叶物理SHA、最后源码提交与live祖先核验；10叶字节相同，rollout-live.ts与passive-pieces.ts仅保留Roy/Dai历史注释差，逐差保存在对应-live-diff.patch。本批未做转译等价测试，不据此声称整树生产验证通过。',
    '已核候选阶段审计9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、SL资源/护栏审计66283dd9982bdd7f480da7a4d9bfefea0572a9ac、实验体快照aad2700abed6dff1d66e87fb36aaa6fedb39adf3均实际live祖先。这些只作已有子范围定位，不将宽提案标duplicate/implemented。',
    '所有六局run-config均列knowledge/common/move-model.json及monster-db.json等为dirty；本批未找到运行当时消费的完整冻结字节，不用今天刷新JSON冒充旧输入。source-diff.patch为空。没有新源码，未进入live锁、未刷新知识、未改变当前对局。',
    '## 十项处置',
    '\n'.join(table),
    '本批只给原ID补本次报告/提案追溯，不重新登记已观察机制、不重复写复盘、不改claim/证据/首证/prior/status/版本。只经根learner/ledger.py update追加where/note，by=learner:strategy-proposal；既有shipped不降级，waiting是代码提案处置而非学习账本状态。输入/回执与读回另保存ledger-update-input.jsonl、ledger-update-output.txt、ledger-readback.json。队列状态交原调度器消费proposal_results。',
    '## 验证、提交及限制',
    '撤源码失败/恢复通过：未执行，无新增源码。tsc=null、vitest=null、cases=null；不借用旧批测试成功。提交=null，merged=null，release_id=null。未运行LLM/网络/play，未安装依赖、未推送、未修改其他角色知识/代码或运维prompt。',
    '早期临时摘要对combat=null使用list()发生TypeError，未生成结论或修改输入；改为只读战斗对象后完成，diagnostic-note.txt保留失败说明。首次账本只读核验把CLI一行空格分隔ID误当逐行裸ID而断言失败，修正解析后读回30行通过；CLI只执行一次，未重复追加，原失败说明在ledger-readback-initial-failure.txt。两次git diff --no-index的exit1表示历史注释差异，不是产品测试失败。初稿report-initial.md保留。',
    '材料泄漏扫描：gitleaks dir --redact 本批scratch，退出0、报告无泄漏；原日志与报告保存在gitleaks.log/gitleaks-report.json。该扫描不构成代码测试或发布验收。最终批次身份、十ID覆盖、干净工作树、原提案SHA和源码零差异另见completion-validation.json。',
    '原提案历史98/99/101局、A1/A6早证不在本批新全量核验范围；只核六派发锚点，不冒充全历史覆盖。所有SL尝试仍按所属局相关处理。对局dirty知识输入未复原；缺独立时间后移整战、候选完整绑定和未选方案实际后继，不能宣称新策略收益或父要求完成。',
    '交运维的提案路径：' + str(HERE / 'proposal.md') + '。最终机器回报另保存result.json；工作树应保持干净，HEAD仍为上述完整base。',
]
(HERE / 'report.md').write_text('\n\n'.join(report) + '\n')

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-224302-s2-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in assigned], 'implementation_domains': [],
          'proposal_results': [{'id': d['id'], 'state': 'waiting', 'reason': d['reason']} for d in details],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(HERE / 'report.md'), 'proposal': str(HERE / 'proposal.md'),
                  'proposal_count': len(details), 'waiting': len(details)}, ensure_ascii=False))

import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
before = json.loads((HERE / 'ledger-immediate-before.json').read_text())
fold = ledger.fold(ledger.read_rows(str(ROOT / 'paper/materials/learning/ledger.jsonl')))
prefix = json.loads((HERE / 'ledger-prefix-before.json').read_text())
raw = Path(prefix['source']).read_bytes()
assert hashlib.sha256(raw[:prefix['bytes']]).hexdigest() == prefix['sha256'], '原账本字节前缀变化'
updates = [json.loads(line) for line in (HERE / 'ledger-update-input.jsonl').read_text().splitlines()]
output = (HERE / 'ledger-update-output.txt').read_text().split()
assert output == [u['id'] for u in updates], 'CLI输出ID与输入不符'
checks = []
for update in updates:
    ident = update['id']
    original, after = before[ident], fold[ident]
    trace = ['where', 'history', 'notes']
    assert {k: v for k, v in after.items() if k not in trace} == {k: v for k, v in original.items() if k not in trace}, ident
    assert after['history'][:len(original['history'])] == original['history'], ident
    assert after['notes'][:len(original['notes'])] == original['notes'], ident
    assert update['note'] in after['notes'], ident
    for key, values in original['where'].items():
        assert set(values) <= set(after['where'][key]), ident
    assert set(update['where']['proposal']) <= set(after['where']['proposal']), ident
    checks.append({'id': ident, 'all_non_trace_fields_preserved': True,
                   'history_and_notes_prefix_preserved': True, 'old_where_preserved': True,
                   'new_links_and_note_read_back': True})
added = []
offset = prefix['bytes']
for line in raw[prefix['bytes']:].splitlines(keepends=True):
    row = json.loads(line)
    if row.get('id') in before and row.get('note', '').startswith('20261015-224302-s2-strategy-proposal：'):
        assert set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'}
        added.append({'id': row['id'], 'offset': offset, 'bytes': len(line),
                      'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert len(added) == 30 and {x['id'] for x in added} == set(before)
(HERE / 'ledger-readback.json').write_text(json.dumps({
    'prefix_bytes': prefix['bytes'], 'prefix_sha256_unchanged': True,
    'updates': checks, 'appended_rows': added,
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ledger_rows': len(checks), 'non_trace_fields_preserved': True,
                  'prefix_preserved': True}, ensure_ascii=False))

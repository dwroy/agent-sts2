import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = dispatch['runs']
manifests = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
checks = []


def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)


def powers(entity):
    return {p['power_id']: p['amount'] for p in entity.get('powers', [])}


def describe(item):
    row = item['row']
    state = row.get('state') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
        'run_id': item['run_id'], 'observed_ts': row.get('observed_ts'),
        'floor': (state.get('run') or {}).get('floor'), 'turn': state.get('turn'),
        'screen': state.get('screen'), 'hp': player.get('current_hp'),
        'block': player.get('block'), 'powers': powers(player),
        'enemies': [{
            'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
            'max_hp': e.get('max_hp'), 'alive': e.get('is_alive'),
            'block': e.get('block'), 'move': e.get('move_id'), 'powers': powers(e),
            'attack': sum((i.get('damage') or 0) * (i.get('hits') or 0)
                          for i in e.get('intents', []) if i.get('intent_type') == 'Attack'),
        } for e in combat.get('enemies', [])],
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'),
                  'upgraded': c.get('upgraded')} for c in combat.get('hand', [])],
    }


streams = {}
verified = {}
for manifest in manifests:
    stream = manifest['stream']
    file = HERE / 'evidence' / (stream + '.evidence.jsonl')
    check(stream + ':output_sha256', hashlib.sha256(file.read_bytes()).hexdigest() == manifest['output_sha256'])
    items = [json.loads(line) for line in file.open()]
    counts = collections.Counter(item['run_id'] for item in items)
    check(stream + ':counts', all(counts[r] == manifest['counts'][r] for r in runs))
    with Path(items[0]['source']).open('rb') if items else Path('/dev/null').open('rb') as source:
        for item in items:
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            if hashlib.sha256(raw).hexdigest() != item['sha256'] or json.loads(raw) != item['row']:
                raise AssertionError((stream, item['line'], '原字节不一致'))
            if extract.run_identity(item['row']) != item['run_id']:
                raise AssertionError((stream, item['line'], '身份不一致'))
            if item['offset'] + item['bytes'] > manifest['source_size']:
                raise AssertionError((stream, item['line'], '越过截点'))
    check(stream + ':all_offsets_bytes_sha_identity', True)
    streams[stream] = items
    verified[stream] = {'count': len(items), 'source_size': manifest['source_size'], 'counts': dict(counts)}

states = {x['line']: x for x in streams['states']}
decisions = {x['line']: x for x in streams['decisions']}
windows = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
           '8JRE1C4H4Z2W': [17, 33], 'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [33]}
compact_states = []
for item in streams['states']:
    state = item['row'].get('state') or {}
    if state.get('combat'):
        check_identity = (state.get('run') or {}).get('character_id') == 'SILENT' and (state.get('run') or {}).get('ascension') == 10
        if not check_identity:
            raise AssertionError(('角色/进阶', item['line']))
    if (state.get('run') or {}).get('floor') in windows[item['run_id']] and state.get('combat'):
        compact_states.append(describe(item))
(HERE / 'selected-state-windows.json').write_text(json.dumps(compact_states, ensure_ascii=False, indent=2) + '\n')

selected_decisions = []
for item in streams['decisions']:
    row = item['row']
    if row.get('floor') not in windows[item['run_id']]:
        continue
    selected_decisions.append({'line': item['line'], 'run_id': item['run_id'], **{k: row.get(k) for k in
        ['observed_ts', 'decision_id', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label', 'chosen',
         'result', 'answers', 'journal', 'sl_explore', 'hp_guard', 'selection_audit']}})
(HERE / 'selected-decision-windows.json').write_text(json.dumps(selected_decisions, ensure_ascii=False, indent=2) + '\n')

pairs = [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]
paired = []
for a, b in pairs:
    first, second = decisions[a]['row'], decisions[b]['row']
    check(f'decisions:{a}/{b}:same_fingerprint', first['fingerprint'] == second['fingerprint'])
    paired.append({'lines': [a, b], 'same_fingerprint': True,
                   'first': {k: first.get(k) for k in ['floor', 'turn', 'sl_attempt', 'sl_reloads', 'answers', 'sl_explore', 'hp_guard']},
                   'second': {k: second.get(k) for k in ['floor', 'turn', 'sl_attempt', 'sl_reloads', 'answers', 'sl_explore', 'hp_guard']}})

anchors = [277512, 277513, 277528, 278236, 278237, 278242, 278249, 278250, 278251, 278252, 278253, 278254, 278261]
anchor_states = [describe(states[n]) for n in anchors]
by_line = {x['line']: x for x in anchor_states}
check('YF:阶段212且旧毒清空', by_line[277513]['enemies'][0]['max_hp'] == 212 and by_line[277513]['enemies'][0]['powers'].get('POISON_POWER', 0) == 0)
check('XP:T2轮初14挡', by_line[278236]['block'] == 14)
check('XP:镣铐后爪力量负9', by_line[278237]['enemies'][0]['powers'].get('STRENGTH_POWER') == -9)
check('XP:末帧敌血153/125且玩家0', [e['hp'] for e in by_line[278261]['enemies']] == [153, 125] and by_line[278261]['hp'] == 0)

examples = {}
for run, floors in windows.items():
    selected = [x for x in compact_states if x['run_id'] == run]
    by_turn = collections.defaultdict(list)
    for x in selected:
        key = (x['floor'], x['turn'])
        by_turn[key].append(x)
    examples[run] = [{'floor': key[0], 'turn': key[1], 'frames': len(xs),
                      'first': xs[0], 'last': xs[-1]} for key, xs in by_turn.items()]

summary = {'streams': verified, 'total_rows': sum(x['count'] for x in verified.values()),
           'material_checks': checks, 'same_fingerprint_pairs': paired,
           'anchors': anchor_states, 'window_frame_count': len(compact_states),
           'window_decision_count': len(selected_decisions),
           'scope': '仅材料身份/原字节及所列帧核验，不是生产自测或新策略收益验证'}
(HERE / 'evidence-verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
(HERE / 'turn-examples.json').write_text(json.dumps(examples, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'total_rows': summary['total_rows'], 'checks': len(checks), 'streams': verified,
                  'selected_state_frames': len(compact_states), 'selected_decisions': len(selected_decisions)}, ensure_ascii=False))

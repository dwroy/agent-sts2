# 静默猎手策略提案批次报告



结果：十项全部waiting，无源码/知识修改、无提交、无合入、无新版本、无shipped。每项证据、层/回合、原账本、反例、预期行为和验证见[proposal.md](proposal.md)。

本批task=strategy-proposal、character=silent、reason=proposal；没有专题或冻结实现绑定。原工作树与派发六局集合精确匹配。base=7f6646a68cf8be641e0abfe93d4987e8ef610f98；main合并返回Already up to date，HEAD保持该基线。

## 证据与结论边界

runs.jsonl已核六局均SILENT/A10，结束时间2026-10-07，皆有dirty运行标记。runs.jsonl的旧deepseek_calls与deciders字段分列保留，不据载荷字段称纯Codex大脑；本批未独立核学习者原生会话模型/推理设置，也未更改运行配置。

使用本树learner/extract_evidence.py默认六流。共8268行：states 4062、decisions 3941、sl-attempts 38、run-config 6、run-plans 33、brain 188。每流source_size、计数和输出SHA在evidence/evidence-manifest.json；每行保留source/line/offset/bytes/SHA。audit_evidence.py逐行从只读原日志seek读回核字节SHA、JSON、显式身份与截点。原流外部invalid行数2/2/0/0/0/1，未作为本批证据。CA5的SL流0行仅表示该截点未选中，不据此声称日志缺失。

run-plans按run字段确立所属，不把正文提及归入本局；其他流检查run_id/state.run_id/fingerprint.run，冲突身份不接收。所选战斗帧另核角色和进阶。共45项材料断言（evidence-verification.json的26项与mechanism-checks.json的19项）通过；这是材料核验，不是tsc/vitest或策略效果测试。

重点窗口保存1060状态帧摘要、1043决策摘要。四组原问题均完整指纹相同；端点按observed_ts+fingerprint唯一回连，end_turn及下一轮决策同局/层/尝试、原行连续。端点净差仍不证明逐来源伤害、整候选完整执行或整战因果。

|局/层/轮|同指纹决策行|观察净损血（原/替）|敌本体观察净减（原/替）|
|---|---|---|---|
|8JRE1C4H4Z2W F33 T2|270216/270282|3/15|10/17|
|YF0LXT1QSTGG F48 T1|271309/271348|0/9|45/38|
|XP2SL33HT0D9 F33 T3|271992/272040|9/14|24/27|
|XP2SL33HT0D9 F33 T1|271982/272195|2/10|25/34|

具体端点及来源状态行见paired-turn-endpoints.json。8JRE五轮死亡0/24与5/24不能称相等；YF预测0/10、54/36不能替代观察0/9、45/38。YF F33第二次SL实胜余20血是反对一律禁探索的反例（sl-attempts 929）。原始胜/败尝试保存在attempt-outcomes.json。

当前原样本可确认污染增长、喷水随力/弱变化、负属性、临时减力恢复、朝向与阶段当前帧；不能从这些有限观察拟最优技能频率、杀序、SL惩罚、留药价值或路线阈值。完整冻结输入、跨重问执行归属、逐来源累计量与受控整战后继仍缺，故保持原行为。未发现需要另通知Roy的新反证或旧知识冲突。

## 现有源码与live范围

读回live=f92636aec0e099e656eb18d14ef73c7dc266ff55，source-readback.json记录12叶物理SHA、最后源码提交与live祖先核验；10叶字节相同，rollout-live.ts与passive-pieces.ts仅保留Roy/Dai历史注释差，逐差保存在对应-live-diff.patch。本批未做转译等价测试，不据此声称整树生产验证通过。

已核候选阶段审计9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、SL资源/护栏审计66283dd9982bdd7f480da7a4d9bfefea0572a9ac、实验体快照aad2700abed6dff1d66e87fb36aaa6fedb39adf3均实际live祖先。这些只作已有子范围定位，不将宽提案标duplicate/implemented。

所有六局run-config均列knowledge/common/move-model.json及monster-db.json等为dirty；本批未找到运行当时消费的完整冻结字节，不用今天刷新JSON冒充旧输入。source-diff.patch为空。没有新源码，未进入live锁、未刷新知识、未改变当前对局。

## 十项处置

|原提案ID|账本|处置|具体缺口|
|---|---|---|---|
|silent-proposal-c20b5139dd0dff71|silent-0168|waiting|缺历史dirty运行实际消费的A10移动表，以及毒、挡、污染跨轮的完整候选联合回放；本批未定位新确定性公式差异。|
|silent-proposal-ae9e692d680e3819|silent-0183、silent-0005|waiting|缺逐实体累计被夺量、非抢夺属性来源及死亡返还的完整冻结输入；当前总负属性不能替代应返还量，另一杀序后继未知。|
|silent-proposal-52f1e1bd2e7db0ed|silent-0231|waiting|缺原dirty运行实际消费的A10移动表快照和覆甲完整减层条件的独立输入；当前首样本读取路径已存在，未定位新的当轮缺陷。|
|silent-proposal-6dd8bbff876be528|silent-0233、silent-0209|waiting|缺稳定召唤代际、新同类替换及累计量归属的冻结输入；一个连续存活窗口不能验证新实体不继承旧计数。|
|silent-proposal-578e415a259e6835|silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016|waiting|缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准；预测/观察端点已有不等于整项完成。|
|silent-proposal-c0767768bf6a7ab1|silent-0079|waiting|缺未执行续步、完整替代线的资源/胜负对照及跨重问归属；同轮多9血少7伤不足以校准SL惩罚或禁止探索。|
|silent-proposal-a46bdb7fe711d79a|silent-0021、silent-0027、silent-0028、silent-0085|waiting|缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；当前快照及零毒说明只覆盖局部。|
|silent-proposal-1044224808015e5c|silent-0079|waiting|缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列证明低当轮损失优先的新排序更好。|
|silent-proposal-7cbc6005db712ba9|silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242|waiting|缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不能将整个提案登记duplicate。|
|silent-proposal-c59f592f1427a67e|silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242|waiting|六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。|

本批只给原ID补本次报告/提案追溯，不重新登记已观察机制、不重复写复盘、不改claim/证据/首证/prior/status/版本。只经根learner/ledger.py update追加where/note，by=learner:strategy-proposal；既有shipped不降级，waiting是代码提案处置而非学习账本状态。输入/回执与读回另保存ledger-update-input.jsonl、ledger-update-output.txt、ledger-readback.json。队列状态交原调度器消费proposal_results。

## 验证、提交及限制

撤源码失败/恢复通过：未执行，无新增源码。tsc=null、vitest=null、cases=null；不借用旧批测试成功。提交=null，merged=null，release_id=null。未运行LLM/网络/play，未安装依赖、未推送、未修改其他角色知识/代码或运维prompt。

早期临时摘要对combat=null使用list()发生TypeError，未生成结论或修改输入；改为只读战斗对象后完成，diagnostic-note.txt保留失败说明。两次git diff --no-index的exit1表示历史注释差异，不是产品测试失败。

原提案历史98/99/101局、A1/A6早证不在本批新全量核验范围；只核六派发锚点，不冒充全历史覆盖。所有SL尝试仍按所属局相关处理。对局dirty知识输入未复原；缺独立时间后移整战、候选完整绑定和未选方案实际后继，不能宣称新策略收益或父要求完成。

交运维的提案路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-224302-s2/learner/runs/20261015-224306-0eb71adb-acac-4395-989c-960230878f08-strategy-proposal/proposal.md。最终机器回报另保存result.json；工作树应保持干净，HEAD仍为上述完整base。

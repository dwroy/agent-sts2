# 本批十项原提案的逐项核验与处置



批次：20261015-224302-s2-strategy-proposal。角色silent，仅本批六局A10。基线：7f6646a68cf8be641e0abfe93d4987e8ef610f98。

本批为普通proposal领取，learn.json没有research_request、implementation_request或proposal_repair；根专题请求属于另批，不承接。启动工作树干净，git merge --no-edit main返回Already up to date。未派下级agent。

本文件是原十ID的处置附件，不替换原提案、不新建重复ID、不改原请求/经验/源码。十份原Markdown逐SHA相同，保存在original-proposals/，来源与指纹见original-proposal-manifest.json。

本批没有发现足以提出新确定性修复或新策略权重的缺陷。全部waiting，不将部分已存在源码冒记整个提案duplicate/implemented。候选预测、实际动作回执、整轮观察端点、逐来源归属与完整反事实分别验收。

共同验证边界：这些局仅作原发现/固定证据复核；同局SL不是独立样本，不把未执行续步补成胜局。源码和经验不改，无需代码回退；后续真正实现须固定夹具撤源码失败/恢复通过、原沙箱检查、实际live与运维登记。



## silent-proposal-c20b5139dd0dff71：感染棱柱技能污染的联合血价



账本：silent-0168。处置：waiting。

证据：DUZUBAJ3A8GP，F27 T4—5；states 274830—274838：火花3时技能污染3/6，T5火花6且旧污染消失，新技能污染6/12/18；毒层7→13与17挡同时存在。

当前实现范围：turn-solver.ts 已按技能累积 vitalSpark、逐段在虚弱前计算 tainted；rollout.ts 读取招式 selfPowers 的火花增量。

反例与限制：技能同时提供毒或挡，能力不等同技能；局部多付血不能推出一律少打技能。

缺数据及未实现原因：缺历史dirty运行实际消费的A10移动表，以及毒、挡、污染跨轮的完整候选联合回放；本批未定位新确定性公式差异。

旧规则与预期行为：保留当前选线；补足输入后只在观察范围提供联合毒/挡/血价参考，不强制过滤技能。

验证方法：冻结本局实际消费的招式表、手牌与状态，逐步核技能/能力、火花增长、污染撤销、毒和挡，再用独立后置局验证；不能以当前刷新表代替旧输入。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；SHA256=bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。



## silent-proposal-ae9e692d680e3819：抢夺与死亡返还的逐来源归属



账本：silent-0183、silent-0005。处置：waiting。

证据：5PM6JAQG6FNQ，F39 T2—6；states 274341/274351/274352/274354：玩家力敏−2→−4，两次步法把敏捷−4→−2→0，力量仍−4。

当前实现范围：当前现场负力量/负敏捷可进入卡牌模型；combat-plan.ts 将 POSSESS_* 标为现场事实，不能据此证明逐来源死亡返还模型完整。

反例与限制：建立步法不表示已有正敏捷；末次即使失落退出，遗忘仍可造成致命攻击。没有固定击杀序的完整受控胜线。

缺数据及未实现原因：缺逐实体累计被夺量、非抢夺属性来源及死亡返还的完整冻结输入；当前总负属性不能替代应返还量，另一杀序后继未知。

旧规则与预期行为：保留现有动作与现场负属性；有完整来源证据后再验证返还，不设置固定先杀序。

验证方法：逐来源固定抢夺、增加自身属性、死亡/退场和返还事件；覆盖同轮毒杀、后续重抢与索引重排，未知累计量保持未知。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；SHA256=b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。



## silent-proposal-52f1e1bd2e7db0ed：下水道蚌加压与当前进阶事实



账本：silent-0231。处置：waiting。

证据：CA5KE8GFJ9X2，F13 T1/3/5；states 273237/273252/273263：力量0/4/8，喷水11/15/19；273254/273268弱后11/14，末玩家2→0。

当前实现范围：monster-db.ts 对当前进阶已见HP/移动伤害直接选取，不套五样本门槛；room-costs.ts 与怪物房间成本仍各有5样本门槛。

反例与限制：覆甲轮初9/9/8/7/6只约束这些帧；不能由该序列补完整减层条件或改成固定房间成本。

缺数据及未实现原因：缺原dirty运行实际消费的A10移动表快照和覆甲完整减层条件的独立输入；当前首样本读取路径已存在，未定位新的当轮缺陷。

旧规则与预期行为：保留当前进阶数据库读取与原选线，不降低房间代价五样本门槛。

验证方法：冻结本局招式表/调用输入，验加压、弱与覆甲；事实首样本可读、房间成本不足5不借该事实替代统计。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；SHA256=651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。



## silent-proposal-6dd8bbff876be528：高电压增长与新召唤者的身份边界



账本：silent-0233、silent-0209。处置：waiting。

证据：5PM6JAQG6FNQ，F38 T2—4；states 274307/274308/274313：23上限电击力量0/2/4、攻击0/17/19；盘面index从4变3。

当前实现范围：rollout.ts 的 STRENGTH_GROWTH_POWERS 包含 HIGH_VOLTAGE_POWER，敌轮将 e.growth 加入力量；已存在不等于验证了所有替换实体。

反例与限制：本局只有该连续存活窗口；盘面索引变化不证明出现新的召唤代际，未执行先杀爪牙候选也不证明后场得救。

缺数据及未实现原因：缺稳定召唤代际、新同类替换及累计量归属的冻结输入；一个连续存活窗口不能验证新实体不继承旧计数。

旧规则与预期行为：保留现有增长与候选；只由可核实的实例输入继承累计量，不用名字/索引猜代际。

验证方法：保留实际实体/召唤代际映射，固定连续增长、旧实体退场、新同类进入及索引重排，确认计数隔离后再论杀序。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；SHA256=48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。



## silent-proposal-578e415a259e6835：沙虫SL、护栏与已建能力的兑现分账



账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。处置：waiting。

证据：8JRE1C4H4Z2W，F33首/第三试T2，decisions 270216/270282同指纹；状态端点276208→276212与276274→276278，净损3/15、敌本体净减10/17。原题推演死亡0/24与5/24，不能称同死亡率。另原提案F17 T6、F33第二试T5、末试T11仍为待校准窗口。

当前实现范围：silent-selection-audit、silent-sl-resource-comparison、silent-hp-guard-audit 分别保存预测阶段、替换差值和护栏差值，明确实际结果未认证。

反例与限制：防御替换有当轮省血反例；抽牌重问之后原候选未必完整执行，末轮死亡截断不能补未来毒伤。

缺数据及未实现原因：缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准；预测/观察端点已有不等于整项完成。

旧规则与预期行为：保留现有探索、护栏和持续价值权重；补齐执行归属后再评估策略，不能把审计上线当收益。

验证方法：绑定原答、护栏、SL、首次回执及每次重规划；分别核当前HP、整轮端点、逐来源毒/挡、能力建立和未执行续步。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；SHA256=e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。



## silent-proposal-c0767768bf6a7ab1：全败SL替线的未执行续步与资源代价



账本：silent-0079。处置：waiting。

证据：YF0LXT1QSTGG，F48第二/第三试T1，decisions 271309/271348同指纹；states 277327→277337与277366→277373净损0/9、敌净减45/38。预测0/10、54/36另列。

当前实现范围：silent-sl-resource-comparison 保存预测差值，silent-selection-audit 的 actual_turn=null，不能将 pending_dispatch 解释为整候选已执行。

反例与限制：同局F33第二试SL实胜余20血（sl-attempts 929）；F48有弃牌后候选未完成的反例。不能据该局禁止探索。

缺数据及未实现原因：缺未执行续步、完整替代线的资源/胜负对照及跨重问归属；同轮多9血少7伤不足以校准SL惩罚或禁止探索。

旧规则与预期行为：保留SL允许探索的规则；已知劣化作为有条件观察，不拟全局血价系数。

验证方法：固定预测/实净差与截断点，记录抽弃牌后的新候选；保留F33胜利反例，按独立局后移验证新规则。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；SHA256=28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。



## silent-proposal-a46bdb7fe711d79a：实验体分阶段、零毒触媒与敏捷时序



账本：silent-0021、silent-0027、silent-0028、silent-0085。处置：waiting。

证据：YF0LXT1QSTGG，F48末试T3—5；states 277512/277513由111上限且4毒切到212上限零毒；277519触媒2而毒0；277520/277523挡13→23，277526敏5→6但挡仍23；277527敌160、玩家18、攻击44。

当前实现范围：silent-phase-current.ts 限Silent A10 F48的111/212当前帧，区分组件持有/已建能力/现毒/现挡；rollout.ts 已在换相清毒/力量。

反例与限制：前试建毒雾/余像仍败；当前持有或建立组件不证明之后能兑现，不把末帧死亡后的55意图倒当致死攻击44。

缺数据及未实现原因：缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；当前快照及零毒说明只覆盖局部。

旧规则与预期行为：保留当前阶段事实和候选排序；不预支后续毒、下一阶段收益或后取得敏捷。

验证方法：冻结各阶段状态，分列即时毒、已结毒、触媒额外结算、敏捷取得与挡牌顺序；独立后置局包含已建仍败的反例。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；SHA256=eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。



## silent-proposal-1044224808015e5c：双蟹B2零胜并列的探索排序



账本：silent-0079。处置：waiting。

证据：XP2SL33HT0D9，F33首/第二试T3，decisions 271992/272040同指纹：净损9/14、敌净减24/27；首/末试T1，271982/272195同指纹：净损2/10、敌净减25/34。

当前实现范围：现有SL比较已经分列本轮预测血价，B2零差仅是该题有限样本并列，不等于安全；本批复核了实际轮端点。

反例与限制：替换同时有手里剑成长、抽牌和随机药瓶；后续抽序与动作变化。末试T2实际零损，不能用少挡牌数判所有舍挡有害。

缺数据及未实现原因：缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列证明低当轮损失优先的新排序更好。

旧规则与预期行为：保留现有并列集合和选线；低损失优先仅保留为待验证候选，不引入惩罚常数。

验证方法：同预算冻结整战池、相同随机/抽序，单列当轮血价、输出与成长；本局作发现集，新独立A10双蟹作后置验证。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；SHA256=4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。



## silent-proposal-7cbc6005db712ba9：双蟹朝向、临时减力和能力兑现窗口



账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。处置：waiting。

证据：XP2SL33HT0D9，F33末试T2—5；states 278236轮初14挡，278237爪负9力/攻击0，278242恢复；278249/278252/278253激光57→38→28；278261敌153/125而玩家0。

当前实现范围：现有模型有朝向、临时减力恢复和船夹板T2 14挡；本批只核此A10来源局，原稿引用A1/A6的独立早证未重新抽取。

反例与限制：减力到期恢复、朝向与弱贡献不同；脆弱下挡与攻击计数成长需按实际时点，不能把已建能力当恒定保命值。

缺数据及未实现原因：缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不能将整个提案登记duplicate。

旧规则与预期行为：保留原权重、护栏和出牌规则；仅在证据条件内补事实参考，不外推未见组合。

验证方法：逐候选分现挡/新增挡、朝向/弱/临减、已结/未结毒和成长时点；原稿早证与未观察升级条件另行按角色核实。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；SHA256=f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。



## silent-proposal-c59f592f1427a67e：机制、SL及路线资源的历史联合校准



账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。处置：waiting。

证据：原提案锚点YF0LXT1QSTGG F48 T1/T4—5、XP2SL33HT0D9 F33 T1—5；本批复核这些帧和其余四派发局，没有重新完成原101局分母。

当前实现范围：现有候选/护栏/SL审计与阶段快照各覆盖部分；六锚点的8268原行不能等同101局的全历史核验。

反例与限制：有SL实胜，也有能力已建仍败；SL血重置、实际回血、资源持有和实际消耗不能混账，未选路线/留药无受控后继。

缺数据及未实现原因：六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。

旧规则与预期行为：保留原游戏规则和历史知识；不从有限锚点拟必休血线、留药价值、牌组上限或固定目标顺序。

验证方法：沿原提案保留101局范围的逐子项分母；按独立局/时间分组，分别验证资源来源、候选实际执行及替线后继。

预期影响：先使该项事实和执行可核验，策略收益仍未知。回退：本批无源码改动；后继实现按自己的源码提交回退。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；SHA256=81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。

from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile

root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2304'; pub=r/'paper/materials/20261015-2304-ops'; pub.mkdir(exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,cwd=r): return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def load(path): return json.loads(path.read_text())
def write(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
state=load(r/'ops/codex-ops/learn.json'); bid='20261015-224302-s2-strategy-proposal'; b=state['batches'][bid]; report=b['report']; s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[]
assert b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
manifest=load(s/'artifact-manifest.json'); assert manifest['base']==report['base']
for row in manifest['files']:
 f=s/row['path']; assert f.is_relative_to(s); raw=f.read_bytes(); assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
completion=load(s/'completion-validation.json'); assert completion['base']==report['base'] and completion['git_status_clean'] and completion['all_tracked_diff_empty'] and completion['source_diff_bytes']==0
assert completion['proposal_ids_exactly_covered'] and completion['all_ten_waiting'] and completion['production_tests_not_run'] and completion['ledger_trace_rows_read_back']==30 and completion['evidence_material_checks']==45
evidence=load(s/'evidence-verification.json'); checks=evidence['material_checks']+load(s/'mechanism-checks.json'); assert len(checks)==45 and all(x['passed'] for x in checks)
assert evidence['total_rows']==sum(x['count'] for x in evidence['streams'].values())==8268
identities=load(s/'run-identities.json'); assert len(identities)==6 and all(x['character']=='SILENT' and x['ascension']==10 for x in identities)
assert {x['run_id'] for x in identities}==set(report['runs'])
for x in load(s/'original-proposal-manifest.json'):
 for key in ['source','copy']:
  f=Path(x[key]); assert f.resolve().is_relative_to(r); raw=f.read_bytes(); assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
source=load(s/'source-readback.json'); equal=0; assert len(source['files'])==12
for x in source['files']:
 raw=git('show',source['base']+':'+x['path']); old=git('show',source['observed_live']+':'+x['path']); assert sha(raw)==x['sha256'] and sha(old)==x['live_sha256']
 assert (raw==old)==x['equal']; assert raw.replace(b'Roy',b'Dai')==old.replace(b'Roy',b'Dai'); equal+=raw==old
 assert x['source_is_live_ancestor']; git('merge-base','--is-ancestor',x['last_source_commit'],source['observed_live'])
assert equal==10
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()]; assert len(inputs)==30
ledger=r/'paper/materials/learning/ledger.jsonl'; owned=[]
for raw in ledger.read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs): owned.append(raw)
assert len(owned)==30 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned)
readback=load(s/'ledger-readback.json'); assert readback['prefix_sha256_unchanged'] and len(readback['updates'])==len(readback['appended_rows'])==30
assert all(all(x[k] for k in ['all_non_trace_fields_preserved','history_and_notes_prefix_preserved','old_where_preserved','new_links_and_note_read_back']) for x in readback['updates'])
for x in readback['appended_rows']:
 with ledger.open('rb') as f: f.seek(x['offset']); raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and json.loads(raw)==x['row'] and raw in owned
assert set((s/'ledger-update-output.txt').read_text().split())=={x['id'] for x in inputs}
old=git('show',base+':paper/materials/learning/ledger.jsonl'); existing=set(old.splitlines()); added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==30
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(a)==set(z)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
 assert z[ident]['history'][:len(a[ident]['history'])]==a[ident]['history']
 for key,items in a[ident]['where'].items(): assert all(x in z[ident]['where'][key] for x in items)
for name in ['gitleaks-report.json','gitleaks-final-report.json']: assert load(s/name)==[]
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_no_change_gate=b['no_change_proposals'],native=native,original_completion=completion,artifact_manifest_sha_verified=True,original_material_checks=45,original_evidence_rows=8268,selected_state_and_decision_summaries=[1060,1043],original_paired_turn_endpoints=load(s/'paired-turn-endpoints.json'),source12_leaves_sha_and_ancestor_flags_verified=True,equal10_historical_comment_only2=True,learner_cli_trace_rows=30,protected_fold_and_old_history_where_preserved=True,original_failure_and_initial_draft_preserved=True,no_source_or_production_test_or_material_rerun=True,limits=['Six dirty Silent A10 anchors do not reconstruct historical consumed move-model/monster-db bytes or cover original98/99/101-run denominators.', 'Four same-fingerprint pairs and eight observed net endpoints do not certify full candidate execution, per-source damage, alternate outcomes or game benefit.', 'Original8J five-turn0/24 versus5/24 is unequal; YF predictions0/10,54/36 remain distinct from actual0/9,45/38. Original victorious second SL is retained.', 'Original combat-null TypeError and ledger whitespace-ID readback error are retained; CLI appended once; no new counterevidence or other-role ACK claimed.']))

publication=load(r/'paper/materials/20261015-2249-ops/publication.json'); cbid='20261015-214302-fix-batch'; cb=state['batches'][cbid]; matches=[x for x in cb['fallback_checks'] if x['tree']==publication['tree']]; assert len(matches)==1; check=matches[0]; assert check['rc']==0 and check['merged']==publication['actual_live']
log=Path(check['log']); raw=log.read_bytes(); text=re.sub(r'\x1b\[[0-9;]*m','',raw.decode()); assert '486 passed' in text and '4905 passed' in text and '2 skipped' in text and '714.53s' in text
assert git('rev-parse','HEAD','HEAD^{tree}',cwd=r/'.worktrees/live').decode().splitlines()==[publication['actual_live'],publication['tree']]
for commit in [publication['ops_source'],publication['source']]: git('merge-base','--is-ancestor',commit,check['merged'])
versions=load(r/'eval/versions.json'); numbered=[x for x in versions['release_numbering']['releases'] if x['release_id']==publication['release_id']]; assert len(numbered)==1 and numbered[0]['commit']==publication['behavior_commit']
assert cb['state']=='failed' and cb['rc']==0 and cb['report']['merged'] is None
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
closure=dict(at=at,original_batch=cbid,release_id=publication['release_id'],actual_live=check['merged'],exact_tree=check['tree'],original_canonical_check=check,full_tsc_exit=0,full_vitest_exit=0,files=486,passed=4905,skipped=2,duration_seconds=714.53,log=dict(path=str(log.relative_to(r)),bytes=len(raw),sha256=sha(raw)),covers_actual_combined_sources=[publication['ops_source'],publication['source']],original_failed_rc0_mergednull_preserved=True,prior_pending_receipts_unmodified=True,new_merge_release_test_request_or_ledger_cli=False,natural_consumers='pending saved registration/lease and Silent A10 held/buy payload; no forced game or model request',wide_parents='remain open')
write(pub/'host-closure.json',closure); (pub/'host-full.log').write_bytes(raw)
pending=load(r/'ops/codex-ops/pending-integrations/20261015-214302-fix-batch.json'); pending.update(at=at,host_result='passed precise94a022 combined tree',host_closure='paper/materials/20261015-2304-ops/host-closure.json',natural_consumers='pending next natural saved registration/lease and Silent A10 held/buy payload; no forced requests or restart')
write(pub/'publication-acceptance.json',pending)
for key in pending['batches']: write(r/'ops/codex-ops/pending-integrations'/(key+'.json'),pending)
decision=f'\n- {at} 运维codex：2304两事件结案：原214302-fix唯一94a022bc树/livee1e7ee85宿主tsc0/vitest0、486文件4905过2跳/714.53秒及完整日志SHA核，覆盖同树798af注册屏障+a78bb耳环V5-R363两增量；原failed/rc0/mergednull与源冲突/旧pending/红绿原件保留，不重复合入/发号/请求检查/CLI。只关闭本组合宿主检查，下一自然注册保存租约及Silent A10持有/买入消费者、其他宽父仍pending。原224302-s2 done0/no-source十项waiting，7f664干净WT/HEAD保持、testsnull/域空；原六Silent A10六流8268行/45材料检查、四同指纹八净差端点与dirty运行边界核，不重跑材料/当完整候选或收益；12叶旧livef926 SHA/祖先核10同2历史注释差，原dirty移动表冻结缺失、98/99/101全史与逐来源/受控后继缺口保持。30原CLI仅where/note逐输入、原offset/bytes/SHA与非追溯fold/旧history及where前缀核，私有索引只纳所属行、不重复CLI或降级shipped；原combat-null临时TypeError、ID空格解析误断言/初稿保持，不当产品失败。实际native Sol6.1/xhigh/input/lease/workspace-write/no-network核，原未独立读native说明保留。仅本人记录/数据提交，不新知识/版本/生产测试/论文刷新/派发，不改对局/账号home模型权限prompt。证据paper/materials/20261015-2304-ops/。\n'
note=f'\n- {at} [ops 宿主验收] V5-R363及注册保存屏障最终livee1e7ee85/tree94a022bc完整宿主tsc/vitest退出0，486文件4905过2跳；原唯一检查回执已收尾，未重复检查或发布。自然注册/租约与Silent A10持有/买入消费者继续pending；本批224302-s2十项waiting，无源码修改，30所属CLI仅追溯。回执paper/materials/20261015-2304-ops/host-closure.json。\n'
handoff=f'\n- {at} 2249原两源发布的精确宿主检查已通过：214302-fix fallback tree94a022bc/livee1e7ee85，486文件4905过2跳、tsc0/vitest0；V5-R363号与两source实际祖先核。宿主pending关闭，不再重复原请求或重跑不变树；原failed/mergednull及旧阻塞回执不改。原自然注册保存/租约和Silent A10持有/买入payload消费者仍pending，按后继自然事件核，不启动对局/模型，不把新策略224302-s2旧冻结输入当屏障消费者；源码WT继续原retention门禁，不强删。回执paper/materials/20261015-2304-ops/host-closure.json。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note,'notes/ops-handoff.md':handoff}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,own_ledger_rows=30,host_exact_tree_passed=publication['tree'],release_unchanged='V5-R363',no_new_source_or_test_request=True,natural_consumers='pending'))
archive_manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<900000]+[s/'evidence/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); archive_manifest.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',archive_manifest)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added; dest=p/'final-files'; lp=dest/'paper/materials/learning/ledger.jsonl'; lp.parent.mkdir(parents=True,exist_ok=True); lp.write_bytes(old+added)
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(lp)},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); print(json.dumps(dict(waiting=10,own_ledger_rows=30,exact_host_pass=True,paths=len(entries))))

import collections
import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261016-091304-s2/learner/runs/20261016-091314-3038fabf-057d-4ffa-8440-ced1808388f5-strategy-proposal'
sys.path.insert(0, str(HERE.parents[1]))
from extract_evidence import run_identity


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for part in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def main():
    verified_runs = json.loads((HERE / 'verified-runs.json').read_text())
    prior_manifest = {m['stream']: m for m in json.loads((PRIOR / 'evidence/evidence-manifest.json').read_text())}
    manifests = []
    states = {}
    decisions = []
    configs = []
    for folder in ['evidence', 'evidence-extra']:
        for entry in json.loads((HERE / folder / 'evidence-manifest.json').read_text()):
            stream = entry['stream']
            output = HERE / folder / (stream + '.evidence.jsonl')
            assert digest(output) == entry['output_sha256']
            counts = collections.Counter()
            source = ROOT / 'logs' / (stream + '.jsonl')
            with source.open('rb') as original, output.open() as selected:
                for encoded in selected:
                    item = json.loads(encoded)
                    assert Path(item['source']) == source
                    assert item['offset'] + item['bytes'] <= entry['source_size']
                    original.seek(item['offset'])
                    raw = original.read(item['bytes'])
                    assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
                    assert json.loads(raw) == item['row']
                    assert run_identity(item['row']) == item['run_id']
                    assert item['run_id'] in verified_runs
                    counts[item['run_id']] += 1
                    if stream == 'states':
                        info = item['row']['state'].get('run') or {}
                        assert str(info.get('character_id', 'silent')).lower() == 'silent'
                        states[item['line']] = item
                    elif stream == 'decisions':
                        decisions.append(item)
                    elif stream == 'run-config':
                        configs.append(item)
            assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
            old = prior_manifest[stream]
            assert entry['counts'] == old['counts']
            assert entry['output_sha256'] == old['output_sha256']
            assert digest(PRIOR / 'evidence' / output.name) == old['output_sha256']
            manifests.append({**entry, 'verified_lines': sum(counts.values()), 'same_as_prior': True})

    def state(line):
        return states[line]['row']['state']

    def hp(line):
        return state(line)['run']['current_hp']

    def enemy_hp(line):
        return sum(e['current_hp'] for e in state(line)['combat']['enemies'] if e['is_alive'])

    checks = []

    def check(label, actual, expected):
        assert actual == expected, (label, actual, expected)
        checks.append({'label': label, 'actual': actual, 'expected': expected})

    by_observation = collections.defaultdict(list)
    for item in states.values():
        row = item['row']
        by_observation[(row.get('observed_ts'), row.get('fingerprint'))].append(item)
    cunning = []
    ken = []
    for item in decisions:
        row = item['row']
        if (row.get('chosen') or {}).get('action') != 'use_potion':
            continue
        potion = ((row.get('expect') or {}).get('potion') or {}).get('id')
        if item['run_id'] == 'KEN58SH9SLZ6':
            ken.append([row['floor'], row['turn'], potion, item['line']])
        if potion != 'CUNNING_POTION':
            continue
        matches = by_observation[(row.get('observed_ts'), row.get('fingerprint'))]
        check('狡诈原帧唯一:' + str(item['line']), len(matches), 1)
        a = matches[0]
        b = states[a['line'] + 1]
        sa, sb = a['row']['state'], b['row']['state']
        check('狡诈后帧身份:' + str(item['line']),
              [b['run_id'], sb['run']['floor'], sb['turn']],
              [a['run_id'], sa['run']['floor'], sa['turn']])
        hand_a, hand_b = sa['combat']['hand'], sb['combat']['hand']
        added = len(hand_b) - len(hand_a)
        check('狡诈手位:' + str(item['line']), added, min(3, max(0, 10 - len(hand_a))))
        shivs = lambda hand: sum(c['card_id'] == 'SHIV' and c['upgraded'] for c in hand)
        check('狡诈新增升级小刀:' + str(item['line']), shivs(hand_b) - shivs(hand_a), added)
        cunning.append({'run': item['run_id'], 'decision_line': item['line'], 'before': a['line'], 'after': b['line'], 'added': added})
    check('狡诈饮用/独立局', [len(cunning), len({x['run'] for x in cunning})], [42, 9])
    check('狡诈容量分布', dict(collections.Counter(x['added'] for x in cunning)), {3: 37, 2: 2, 0: 3})
    check('KEN饮用层轮', [x[:2] for x in ken], [[3, 2], [4, 1], [5, 2], [11, 1], [11, 2], [15, 1], [15, 1]])
    check('TXZ首胜后开场', [hp(n) for n in [281563, 281565, 281566]], [4, 4, 0])
    check('TXZ第二Boss未受到攻击', [enemy_hp(n) for n in [281565, 281566]], [111, 111])
    check('普通紧勒逐动作端点', [enemy_hp(n) for n in [282887, 282888, 282889, 282890, 282891]], [103, 95, 85, 85, 83])
    for attempt, a, b, expected in [(1, 283391, 283397, [1, 8]), (5, 283478, 283483, [7, 24]), (6, 283502, 283507, [7, 24])]:
        check('NHA第%d试跨轮净端点' % attempt, [hp(a) - hp(b), enemy_hp(a) - enemy_hp(b)], expected)

    receipts = json.loads((PRIOR / 'selection/receipts.json').read_text())
    references = []
    for receipt in receipts:
        run = receipt['run']
        assert run in verified_runs and receipt['exit_code'] == 0
        for suffix, key in [('input.json', 'input_sha256'), ('output.json', 'output_sha256')]:
            path = PRIOR / 'selection' / (run + '.' + suffix)
            assert digest(path) == receipt[key]
            references.append({'path': str(path), 'sha256': receipt[key], 'role': '旧批真实消费者材料，本批未重跑'})
    old_facts = json.loads((PRIOR / 'facts-audit.json').read_text())
    assert old_facts['checks_passed'] == len(old_facts['checks']) == 205
    assert all(c['actual'] == c['expected'] for c in old_facts['checks'])
    for pair in old_facts['sl_pairs']:
        first, second = pair['pair']
        check('SL同盘:' + pair['run'] + '/T' + str(pair['turn']),
              states[first['before_line']]['row']['fingerprint'], states[second['before_line']]['row']['fingerprint'])
        for endpoint in pair['pair']:
            a, b = endpoint['before_line'], endpoint['after_line']
            check('SL局部端点:' + str(a), [hp(a) - hp(b), enemy_hp(a) - enemy_hp(b)],
                  [endpoint['hp_loss_net'], endpoint['enemy_hp_decrease_net']])
    for name in ['facts-audit.json', 'lamp-nine-observations.json', 'run-source-boundaries.json', 'source-provenance.json', 'report.md']:
        path = PRIOR / name
        references.append({'path': str(path), 'sha256': digest(path), 'role': '旧批材料读回，不冒作本批新执行'})
    output = {'verified_lines': sum(m['verified_lines'] for m in manifests), 'streams': manifests,
              'material_checks': len(checks), 'checks': checks, 'cunning': cunning, 'ken_drinks': ken,
              'prior_consumers_rerun': False, 'references': references,
              'limitations': ['原日志所属行与旧批逐字节相同，不充作新独立样本。', '局部端点含轮间自动伤等来源，不认证完整候选执行或整战因果。', '未复原历史刷新知识字节，未运行LLM/模拟或生产测试。']}
    (HERE / 'evidence-verification.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
    (HERE / 'run-config-records.json').write_text(json.dumps(configs, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'verified_lines': output['verified_lines'], 'checks': len(checks), 'counts': {m['stream']: m['verified_lines'] for m in manifests}, 'all_same_prior': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()

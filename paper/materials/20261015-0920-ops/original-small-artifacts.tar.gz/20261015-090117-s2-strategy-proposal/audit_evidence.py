import hashlib
import json
import runpy
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
identity = runpy.run_path(str(WORK / 'learner/extract_evidence.py'))['run_identity']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
runs = {x['row']['run_id']: x['row'] for x in json.loads((OUT / 'verified-runs.json').read_text())}


def powers(raw):
    return {p['power_id']: p.get('amount') for p in (raw.get('powers') or [])}


def card(raw):
    return {'index': raw.get('index'), 'id': raw.get('card_id'), 'up': raw.get('upgraded'),
            'energy': raw.get('energy_cost'), 'text': raw.get('resolved_rules_text'),
            'dyn': {v.get('name'): [v.get('base_value'), v.get('current_value')]
                    for v in (raw.get('dynamic_values') or [])}}


summary = []
with (OUT / 'states.compact.jsonl').open('w') as states_out:
    for stream in manifest:
        name = stream['stream']
        p = OUT / 'evidence' / (name + '.evidence.jsonl')
        counts = Counter()
        digest = hashlib.sha256()
        with p.open('rb') as f, Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as src:
            for encoded in f:
                digest.update(encoded)
                item = json.loads(encoded)
                src.seek(item['offset'])
                raw = src.read(item['bytes'])
                assert len(raw) == item['bytes']
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                row = item['row']
                run = identity(row)
                assert run == item['run_id'] and run in runs
                counts[run] += 1
                if name != 'states':
                    continue
                s = row.get('state') or {}
                r = s.get('run') or {}
                if r.get('character_id') is not None:
                    assert str(r['character_id']).lower() == 'silent'
                if r.get('ascension') is not None:
                    assert r['ascension'] == runs[run]['ascension']
                c = s.get('combat') or {}
                player = c.get('player') or {}
                enemies = []
                for e in c.get('enemies') or []:
                    enemies.append({'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                                    'alive': e.get('is_alive'), 'block': e.get('block'), 'powers': powers(e),
                                    'move': e.get('move_id'), 'intents': e.get('intents')})
                x = {'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
                     'run': run, 'ts': row.get('ts'), 'floor': r.get('floor'), 'screen': s.get('screen'),
                     'turn': s.get('turn'), 'hp': r.get('current_hp'), 'max_hp': r.get('max_hp'),
                     'combat_hp': player.get('current_hp'), 'energy': player.get('energy'),
                     'block': player.get('block'), 'powers': powers(player), 'enemies': enemies,
                     'hand': [card(v) for v in c.get('hand') or []],
                     'potions': r.get('potions'), 'relics': [v.get('relic_id') for v in r.get('relics') or []],
                     'played': player.get('cards_played_this_turn'), 'actions': s.get('available_actions'),
                     'selection': s.get('selection'), 'ready': c.get('action_readiness')}
                states_out.write(json.dumps(x, ensure_ascii=False) + '\n')
        assert digest.hexdigest() == stream['output_sha256']
        assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
        summary.append({'stream': name, 'rows': sum(counts.values()), 'counts': dict(counts),
                        'source_size': stream['source_size'], 'all_bytes_sha_identity_verified': True,
                        'invalid_source_lines': stream['invalid_lines'],
                        'incomplete_source_lines': stream['incomplete_lines']})
        print(name, sum(counts.values()), flush=True)
(OUT / 'evidence-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')

import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = [json.loads(l) for l in (OUT / 'states.compact.jsonl').open()]
byline = {r['line']: r for r in states}
facts = json.loads((OUT / 'facts.json').read_text())
windows = {w['start']['line']: w for w in facts['windows']}
transitions = json.loads((OUT / 'potion-slot-transitions.json').read_text())
checks = []


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'label': label, 'actual': actual, 'expected': expected})


for line, hp, damage in [(281479, 3, 36), (281535, 0, 27), (282075, 13, 24),
                         (282144, 22, 39), (282135, 0, 24), (282330, 4, 24),
                         (283412, 1, 8), (283434, 1, 8), (283456, 1, 8),
                         (283478, 7, 24), (283502, 7, 24)]:
    w = windows[line]
    check(str(line) + '下一轮连续性', [w['next']['floor'], w['next']['turn']],
          [w['start']['floor'], w['start']['turn'] + 1])
    check(str(line) + '净血量变化', w['hp_loss'], hp)
    check(str(line) + '敌人净血量变化', w['enemy_net_reduction'], damage)

for line in [283412, 283434, 283456, 283478, 283502]:
    check(str(line) + '可比较入口HP', byline[line]['hp'], 30)
for line, sand in [(282140, 4), (282335, 5)]:
    check(str(line) + '轮末沙坑', byline[line]['enemies'][0]['powers'].get('SANDPIT_POWER'), sand)
check('TX首胜退出到次战开场', [byline[n]['hp'] for n in range(281563, 281567)], [4, 4, 4, 0])
check('TX次战新入口', [byline[281565]['floor'], byline[281565]['turn'], byline[281565]['played']], [49, 1, 0])
check('紧勒逐步实际敌HP', [byline[n]['enemies'][0]['hp'] for n in range(282887, 282893)],
      [103, 95, 85, 85, 83, 80])

cs = [p for p in transitions if p['potion'] == 'CUNNING_POTION']
check('狡诈饮用窗口数', len(cs), 42)
check('狡诈独立局数', len({p['run'] for p in cs}), 9)
check('狡诈新增3/2/0分布', dict(Counter(p['hand'][1] - p['hand'][0] for p in cs)), {3: 37, 2: 2, 0: 3})
check('狡诈动作与物理槽位窗口一致', Counter((p['run'], p['floor'], p['turn']) for p in cs),
      Counter((p['run'], p['floor'], p['turn']) for p in facts['potions']
              if (p['potion'] or {}).get('potion_id') == 'CUNNING_POTION'))
for p in cs:
    key = str(p['before_line'])
    check(key + '容量', p['hand'][1] - p['hand'][0], min(3, 10 - p['hand'][0]))
    check(key + 'HP与能量不变', [p['hp'][0], p['energy'][0]], [p['hp'][1], p['energy'][1]])
    check(key + '新增刀数量', len(p['added_shivs']), p['hand'][1] - p['hand'][0])
    for c in p['added_shivs']:
        check(key + ':' + str(c['index']) + '升级与基础伤', [c['up'], c['dyn']['Damage'][0]], [True, 6])

royal = []
for a, b in zip(states, states[1:]):
    if a['run'] != 'TXZ6RVMQA09D' or (a['run'], a['floor'], a['turn']) != (b['run'], b['floor'], b['turn']):
        continue
    if a['turn'] == 1 and a['played'] == 0 and b['played'] == 0 and a['hp'] - b['hp'] == 4:
        royal.append({'floor': a['floor'], 'lines': [a['line'], b['line']], 'hp': [a['hp'], b['hp']]})
check('王室猛毒未出牌开场五窗', [(r['floor'], r['hp']) for r in royal],
      [(43, [70, 66]), (45, [52, 48]), (46, [62, 58]), (48, [60, 56]), (49, [4, 0])])
check('KEN七饮', len([p for p in transitions if p['run'] == 'KEN58SH9SLZ6']), 7)
for run, floor, first, last in [('1913SE84AXQF', 19, 58, 44), ('1913SE84AXQF', 23, 44, 40),
                                ('1913SE84AXQF', 29, 61, 46), ('Q6M2Y34MWKRE', 8, 57, 2)]:
    r = next(r for r in facts['resources'] if r['run'] == run and r['floor'] == floor)
    check(run + ':' + str(floor) + '已完成战斗端点', [r['first']['hp'], r['last']['hp']], [first, last])
for run, floor in [('1913SE84AXQF', 31), ('Q6M2Y34MWKRE', 9)]:
    r = [s for s in states if s['run'] == run and s['floor'] == floor][-1]
    check(run + '死亡退出帧', [r['screen'], r['hp']], ['GAME_OVER', 0])

fingerprints = {}
for raw in (OUT / 'evidence/states.evidence.jsonl').open():
    x = json.loads(raw)
    if x['line'] in {282075, 282144, 281479, 281535}:
        fingerprints[x['line']] = x['row'].get('fingerprint')
check('WQ第二三次T9同指纹', fingerprints[282075], fingerprints[282144])
check('TX第二三次T6同指纹', fingerprints[281479], fingerprints[281535])

serial_checks = []
for row in checks:
    row = dict(row)
    for k in ['actual', 'expected']:
        if isinstance(row[k], Counter):
            row[k] = sorted([[list(key), value] for key, value in row[k].items()])
    serial_checks.append(row)
result = {'assertions': len(checks), 'all_passed': True, 'checks': serial_checks,
          'windows': [windows[n] for n in [281479, 281535, 282075, 282144, 282135, 282330, 283412, 283478, 283502]],
          'royal_openings': royal, 'cunning_transitions': cs,
          'limits': ['这些是日志事实断言，不是生产代码测试或胜率验证。',
                     '敌净扣仅用于无重接或召唤的所列窗口，不能当多阶段毛伤。',
                     'facts.json为初步分析；其中跨SL窗口、初次28血后补血窗口和按决策时戳配药的手牌差不能作结论。']}
(OUT / 'validated-facts.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('日志事实断言通过', len(checks))

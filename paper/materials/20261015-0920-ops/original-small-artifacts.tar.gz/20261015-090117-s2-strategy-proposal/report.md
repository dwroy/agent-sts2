# 本批策略提案报告

时间：2026-10-15T09:15:43+08:00

本批十项全部waiting；源码、知识、版本与工作树跟踪文件均未改动，HEAD保持`17e235df4df5fb6c00dbb832fb3ce35c868858db`，fixes=[]、merged=null。未创建源码提交，未合入live，未登记implemented、duplicate或shipped。详细逐项原规则、证据、限制及验证见[proposal.md](proposal.md)。

## 身份与输入

只处理dispatch.json中的十个ID。十个派发锚点保持原顺序：KEN58SH9SLZ6, TXZ6RVMQA09D, WQZVENQ7DTRP, 02HB4L0C3C67, 4D4J8USKCPAV, F4QKG4J1AJJZ, JLN5SK17W4FQ, LS8035TB32P3, NB8KCF6HRGVF, S9UZAK0JP0C0。原提案还明确引用1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR，因此仅补核这五个所属证据局，不扩展全历史或新领取任务。15局runs.jsonl原行与SHA保存在verified-runs.json，均为SILENT；K367为A1、SADL为A7、F4Q为A9，其余A10，不混合拟合。十份原提案按原SHA256保存并核一致。

## 原日志与方法

统一入口learner/extract_evidence.py按15个已核局号提取八流。evidence/evidence-manifest.json冻结每流source_size和计数，逐行保存offset/bytes/SHA及原始解析内容。evidence-audit.json逐条重新seek原源文件，核字节长度、SHA、JSON正文及显式所属局；19,929条全部通过：states 9815、decisions 9448、sl-attempts 78、run-config 15、run-plans 77、brain 481、runs 15、fight-plans 0。源扫描另有states/decisions/brain无法解析行2/2/1，不能归属本批，不加入证据。fight-plans的0仅指本次冻结截点未选到，不能据此断言原日志不存在。未覆盖旧提取稿或旧字节截点。

298项固定日志事实断言通过，见validated-facts.json、fact-validation.log；这不是tsc/vitest或生产源码测试。关键证据：

- KEN七饮、六胜46净损；零净损不能当零药价。
- TX第二/三次F48T6同指纹，损3/扣36对损0/扣27；首胜4血到F49未出牌4→0。
- WQ第二/三次F33T9同指纹，损13/扣24对损22/扣39；T7另一窗口付4血并把轮末沙坑4延至5，同扣24，约束“总保血”的简单结论。
- 狡诈药水9局42物理饮用窗口：37次添3、2次添2、3次添0，共115张新增升级小刀，基础伤6；HP/能量均不变。只确认已观察容量分支，不从此推出留药价值或整战获益。
- Q6紧勒实际103→95→85→85→83→80，逐源23净扣；1913 F29 61→46，Q6 F8 57→2，下一战实际死亡退出帧与COMBAT末帧分开。
- NHA第二至四次F33T1为30血、14挡、损1/净扣8，第五六次为30血、8挡、损7/净扣24；六败不能证原线必胜或新排序安全。

brain冻结记录是历史输入与回答，只作来源审计，不能当游戏真值；481条均engine=codex，48条xhigh、433条high。该统计不代表本学习者原生会话的模型/强度验收。原历史code均带dirty，未还原历史运行树，不拿当前源码冒充当时执行版本。

## 已有源码的范围

source-audit.json核live=`52046a3deaa359adbafdd9e6d3e96c2527017f49`。6403fdcd（狡诈）、e8b4bb32（开场4血）、5c7105ff（普通紧勒）、ec29ea34/f2c7cc1a（朝向）、c769739b/5604982e（SL比较）均是该live真实祖先。15ea09ad及fc7042d1原提交不是live祖先，不能拿它们冒称已部署。八个相关源码路径做字节对照，六个完全一致，card-model.ts与sl/explore.ts的差异为旧Roy/Dai注释，完整限定差异保存在base-live-relevant.patch；不因此声称整个main/live等价。

已有SL比较明确scope=candidate_forecast/current_turn_prediction、actual_turn_result=null、execution=unverified；没有因此实现新的排序门槛。狡诈容量、开场扣4、普通紧勒与朝向是窄子项，不足以把所派宽项登记成整项duplicate或implemented。STATE中现有owner/架构边界保持。

## 分析纠正与反例

初步facts.json保留探索过程，不作最终结论。第一次按决策observed_ts选状态，饮用前后错一帧，出现手牌负差；改以相邻同房同回合的实际药槽occupied true→false配对，42个狡诈窗口与动作计数核一致，再验生成牌。跨SL重置窗口及NHA初次28血后回复窗口不作同入口血价样本；NHA采用二至六次共同30血入口。死亡结果取GAME_OVER，不能以最后COMBAT仍20或2血当活着退出。startup-parser-failure.txt、inspection-errors.txt及初稿均保留；这些是本批只读分析问题，没有作为生产bug或游戏反证写入知识。最终只采用validated-facts.json列明窗口。

已观察的局部反例限制新规则：WQ沙坑延长有代价也有时间收益；TX少损血同时少输出；KEN零损亦耗药；Q6已休息、已饮药仍失败不证明另一选择可赢。没有新增推翻现有知识的独立事实，也未新建通知或重复父请求。

## 逐项结果

- `silent-proposal-08eaa60bcc449852`：waiting；局部资源已能追溯；没有同入口资源、同后续抽牌下的不饮用/留药到Boss的整战对照。F15零净损同时已花两药，不能推出不喝也零损，或拟合新的持有价格。
- `silent-proposal-92920295a648b540`：waiting；开场扣血与连战已有局部实现e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a；缺固定后续抽牌、生成牌和药栏的连续通关替线。不能把省3血、首胜或低可信模拟0%改成新的SL门槛。
- `silent-proposal-a327449c331efbc1`：waiting；现有候选比较已列血价/敌剩血/沙坑等预测；缺双边界完整受控后继与独立成功验证。多9血换15伤和4血换一沙坑回合均是局部取舍，不能拟成固定换线阈值或笼统禁逃离。
- `silent-proposal-a099e89437e942bb`：waiting；6403fdcdadc803a092beb5165a068e22bf51c412已在live实现已观察进阶的确定生成与手位约束；原15ea09ad75a421d4bd65a820c187c8ee188186c8不是live祖先。整项仍缺计划妥当保留选择、穿插出刀的完整候选派发和SL恢复联合消费者验收，不能将容量子项当整个duplicate。
- `silent-proposal-47910f82a1fdd98f`：waiting；e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a确为live祖先；原fc7042d1df0626e9e726f4bc912d9c6f626d908f不是。缺留药、路线、SL全后继对照及未知回复/复活组合的结算次序，不能重复实现或关闭整个资源价值要求。
- `silent-proposal-f1374df72d8e6a25`：waiting；缺隔离机制误差后同预算、同后续的未用/早用/留药成对整战结果。现有两条实际资源链能说明结转，不能独立校准药水持有价或终局权重；候选预测不当未执行线的真实收益。
- `silent-proposal-38a49e6c97f31eea`：waiting；5c7105ff0294466da8319f2934beda05c6040794已实现普通紧勒受限分支；当前主动磨蚀模型已有。缺弃牌自动触发、增益分源、重接、逐击反伤及再生的完整联合消费者校准；普通无挡分支不能代表整项，也不外推升级/叠层/重放。
- `silent-proposal-ef0e38a5dbd3bc07`：waiting；缺另一营火、事件、路线和用药时机的完整受控结果；路线条件改变与同条件模型误差须分开。两败不能拟出资源权重，也不能证明未抵达营火本可保证通关。
- `silent-proposal-7f820c02d39bfaea`：waiting；c769739b97389fdc978b6515b83a38e3cd900f67及5604982e13890e0e2bc8bf8246272e8267321c0b已在live记录候选预测，且明确actual_turn_result=null/execution=unverified。缺同预算饱和排序校准、成对完整后继和整候选派发归属；弃牌重规划后不能把原题候选当整线执行。
- `silent-proposal-04b6b430759815ed`：waiting；ec29ea34b919344b707e57ba472ea210f9c39d62和其重放f2c7cc1a7288893bceae0f0b20304a2b1fae5f57为live祖先，取整窄分支已存在。油灯仍缺可靠首次消费来源及跨动作/新战/SL恢复联合验证；现场放大不能套到每次施用，其他X值/升级/负面组合及能力整战后继仍未知。

## 记录、验证与上线

本批仅经根learner/ledger.py update追加31个既有静默账本的where.proposal及note追溯，by=learner:strategy-proposal；不重复写历史复盘，不新增support/claim/first_run/prior，不把旧shipped降成proposed，不改version、证据或其他角色。实际CLI结果与前后保护核对见ledger-cli.log和ledger-readback.json；登记失败如有须按真实回执保留，不伪报。

无新增代码提案ID；code_proposals使用十个已有CLI ID。没有实际修改的implementation_domains，故为空数组；不把提案讨论范围误报成本批实现。未运行tsc/vitest、生产固定案例或撤源码测试，三字段均null，未造测试成功、提交、合入或行为版本。自有报告文件的密钥扫描另记secret-scan.json；扫描范围不冒称全部原日志。

后续仍沿原ID等待具体缺口所需的新局或消费者联合证据，本次报告不关闭任何宽量化学习/入库父要求，也不声称大脑已经采用新经验。

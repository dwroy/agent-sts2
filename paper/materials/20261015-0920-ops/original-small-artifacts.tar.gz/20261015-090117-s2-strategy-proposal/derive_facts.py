import bisect
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = [json.loads(raw) for raw in (OUT / 'states.compact.jsonl').open()]
byrun = defaultdict(list)
for state in states:
    byrun[state['run']].append(state)


def brief(s):
    if s is None:
        return None
    return {k: s.get(k) for k in ['line', 'run', 'ts', 'floor', 'turn', 'screen', 'hp', 'max_hp',
                                 'energy', 'block', 'played', 'powers', 'enemies', 'potions']}


windows = []
targets = {('TXZ6RVMQA09D', 48, 6), ('WQZVENQ7DTRP', 33, 9),
           ('WQZVENQ7DTRP', 33, 7), ('NHA2KW0RB7VP', 33, 1)}
for run, rows in byrun.items():
    groups = []
    for s in rows:
        key = (s['floor'], s['turn'])
        if not groups or (groups[-1][-1]['floor'], groups[-1][-1]['turn']) != key:
            groups.append([])
        groups[-1].append(s)
    for n, group in enumerate(groups):
        s = group[0]
        if (run, s['floor'], s['turn']) not in targets:
            continue
        end = groups[n + 1][0] if n + 1 < len(groups) else None
        start = next((x for x in group if x['enemies'] and x['combat_hp'] is not None), None)
        if start is None:
            continue
        def total(x):
            return sum(e['hp'] for e in x['enemies'] if e.get('hp') is not None)
        windows.append({'start': brief(start), 'last': brief(group[-1]), 'next': brief(end),
                        'hp_loss': start['hp'] - end['hp'] if end and end['floor'] == start['floor'] else None,
                        'enemy_net_reduction': total(start) - total(end) if end and end['floor'] == start['floor'] else None,
                        'same_fingerprint_claim': False})

potions = []
decisions = []
for raw in (OUT / 'evidence/decisions.evidence.jsonl').open():
    x = json.loads(raw)
    r = x['row']
    if (r.get('chosen') or {}).get('action') != 'use_potion':
        continue
    rows = byrun[x['run_id']]
    stamps = [s['ts'] for s in rows]
    loc = bisect.bisect_right(stamps, r.get('observed_ts') or r['ts']) - 1
    before = rows[loc] if loc >= 0 else None
    after = rows[loc + 1] if loc + 1 < len(rows) else None
    if before is None or after is None:
        continue
    slot = (r.get('chosen') or {}).get('option_index')
    p = next((p for p in before['potions'] or [] if p.get('slot_index', p.get('index')) == slot), None)
    if p is None and isinstance(slot, int) and slot < len(before['potions'] or []):
        p = before['potions'][slot]
    item = {'decision_line': x['line'], 'run': x['run_id'], 'floor': r.get('floor'), 'turn': r.get('turn'),
            'chosen': r.get('chosen'), 'result': r.get('result'), 'before': brief(before), 'after': brief(after),
            'potion': p, 'hand_before': len(before['hand']), 'hand_after': len(after['hand']),
            'after_shivs': [c for c in after['hand'] if c['id'] == 'SHIV']}
    potions.append(item)

resources = []
for run in ['KEN58SH9SLZ6', '1913SE84AXQF', 'Q6M2Y34MWKRE', 'TXZ6RVMQA09D']:
    floors = defaultdict(list)
    for s in byrun[run]:
        if s['screen'] == 'COMBAT' and s['combat_hp'] is not None:
            floors[s['floor']].append(s)
    for floor, rows in floors.items():
        resources.append({'run': run, 'floor': floor, 'first': brief(rows[0]), 'last': brief(rows[-1]),
                          'endpoint_net_loss': rows[0]['hp'] - rows[-1]['hp'],
                          'includes_sl': any(b['turn'] < a['turn'] for a, b in zip(rows, rows[1:])
                                             if a['turn'] is not None and b['turn'] is not None)})

sl = []
for raw in (OUT / 'evidence/sl-attempts.evidence.jsonl').open():
    x = json.loads(raw)
    r = x['row']
    if x['run_id'] not in {'KEN58SH9SLZ6', 'TXZ6RVMQA09D', 'WQZVENQ7DTRP', 'NHA2KW0RB7VP'}:
        continue
    sl.append({'line': x['line'], 'run': x['run_id'], **{k: r.get(k) for k in
               ['floor', 'attempt', 'result', 'end_hp', 'turns', 'reload', 'give_up_reason']}})

brain = Counter()
for raw in (OUT / 'evidence/brain.evidence.jsonl').open():
    r = json.loads(raw)['row']
    brain[(r.get('engine'), r.get('model'), r.get('effort'))] += 1
result = {'windows': windows, 'potions': potions, 'resources': resources, 'sl': sl,
          'brain_observed': [{'engine': k[0], 'model': k[1], 'effort': k[2], 'rows': v} for k, v in brain.items()]}
(OUT / 'facts.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
for w in windows:
    a = w['start']
    print('WINDOW', a['run'], a['floor'], a['turn'], a['line'], w['hp_loss'], w['enemy_net_reduction'])
print('POTIONS', len(potions), Counter((x.get('potion') or {}).get('potion_id') for x in potions))
for r in resources:
    if (r['run'], r['floor']) in {('1913SE84AXQF', 17), ('1913SE84AXQF', 19), ('1913SE84AXQF', 23),
                                ('1913SE84AXQF', 29), ('1913SE84AXQF', 31), ('Q6M2Y34MWKRE', 8),
                                ('Q6M2Y34MWKRE', 9)} or r['run'] == 'KEN58SH9SLZ6':
        print('RESOURCE', r['run'], r['floor'], r['first']['hp'], r['last']['hp'], r['endpoint_net_loss'], r['includes_sl'])

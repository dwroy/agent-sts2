import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
queue = json.loads((out / 'queue-input.json').read_text())['original']
dispatch = json.loads((out / 'dispatch.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == '2be88e7c612a29b5d67cbc0905fb8163bcb33976'
assert json.loads((out / 'evidence-audit.json').read_text())['verification']['passed']
assert json.loads((out / 'additional-facts.json').read_text())['passed']

reasons = {
    'silent-proposal-366288801d9150d9': '751 F17 T2/T7/T13同指纹血价已核；缺抽弃续问后的完整候选实果归属、受控整战后继和独立验证，不能拟额外失血准入阈值。',
    'silent-proposal-85929bdfc8a3fc1b': '持牌保守项及持有价值未知已有展示；751 F13 T3只实际喝药，缺无药、留到boss的完整分支及弃牌续问后的整线归属。',
    'silent-proposal-efd9f83ee9e1a6dc': 'SL局部成本预测和单动作回执已有，完整回合实果仍未知；751六次同局未胜，缺受控整战比较和独立校准。',
    'silent-proposal-131042659448ae74': '已有预测拆项不能覆盖全部经验的实际兑现；缺逐源伤害与能力兑现、抽弃重规划后的完整执行，以及跨战无药或留药对照。',
    'silent-proposal-990f054036609447': 'KV F33 T5同盘删毒净扣36→29且均零损已核；缺完整候选后继、独立敌回血毛伤核验和路线休息反事实，不能制定新排序或资源价。',
    'silent-proposal-e18d3f18e6cac2a0': '巨兽本体/自爆及末态资源展示已有，anchorRank仍用原存活轮与原残血排序；缺新排序的受控完整后继、资源校准及结局比较。',
    'silent-proposal-9733bb80f445aeae': 'YQL F17 T10残壳毒2→8而血26/挡13/来袭41不变已核；缺提前喝、不喝、留药及新SL排序的受控整战分支。',
    'silent-proposal-c51468c5e8ba6668': 'KEN七次耗药与六次75血空栏boss入口已核；缺随机选牌/发光水续问后的完整候选收益归属，以及F15不喝或留药分支。',
    'silent-proposal-86a7db08d1a31976': 'KEN F17 T10多损6仅多净扣2、T5省2却延迟步法已核；缺完整逐源兑现、受控整战后继和独立验证，不能调整探索准入或HP护栏。',
    'silent-proposal-e282a9131b99129a': 'KEN双向成本已核；预测及单动作回执不能充作完整实果，缺跨续问的候选归属、受控反事实与新局验证，不能拟统一血价。',
}
evidence = {
    'silent-proposal-366288801d9150d9': '751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820；sl-attempts 945—950。',
    'silent-proposal-85929bdfc8a3fc1b': '751FN9QM9MHQ F13 T3、F17 T7/T13；decisions 272361/272362；states 278402及后续；实打分支为喝药。',
    'silent-proposal-efd9f83ee9e1a6dc': '751FN9QM9MHQ F17 T2/T7/T13，同上三个配对窗口；六次相关尝试不是六局。',
    'silent-proposal-131042659448ae74': '751FN9QM9MHQ F13 T3、F17 T7/T13/T17；持牌、毒、荆棘和能力的来源须分别核对。',
    'silent-proposal-990f054036609447': 'KV0JHNJCKXLS F33 第4/5试T5；decisions 273400/273450/273451；sl-attempts 955/956；F17首试赢余9（951）为保留胜例。',
    'silent-proposal-e18d3f18e6cac2a0': 'L9SGRBB5R698 F17 T14（679/682）；PU80F84P6HPN F17 T17及第5试T15赢余2（715—719）；YQL8RZ8BWN1E F17 六试（958—963）。',
    'silent-proposal-9733bb80f445aeae': 'YQL8RZ8BWN1E F17末试T10；states 280160/280161/280162；decision 274087。L9/PU占位血仅作阶段口径的同角色证据。',
    'silent-proposal-c51468c5e8ba6668': 'KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1及T2/F15T1；七次动作和相邻槽位见evidence-audit.json。F17六次入口见964—969及全部T1状态。',
    'silent-proposal-86a7db08d1a31976': 'KEN58SH9SLZ6 F17 第4/5试T10（274505/274568）、第4/6试T5（274484/274601）、第2试T2护栏（274354）。',
    'silent-proposal-e282a9131b99129a': 'KEN58SH9SLZ6 F17 T10/T5同盘双向成本；sl-attempts 967/968/969；完整后轮未受控。',
}
expected = {
    'silent-proposal-366288801d9150d9': '保留原答/最终候选、损血拆项、配对B2与完整续问执行的可追溯对照；证据足够后再评估探索准入。',
    'silent-proposal-85929bdfc8a3fc1b': '显示未决弃牌的保守来源与缺失持有价值，不把null改成已证0，不强制喝药/留药。',
    'silent-proposal-efd9f83ee9e1a6dc': '把SL恢复、预测代价、实际回合结算分开；不由更差B2或单次血价直接定门槛。',
    'silent-proposal-131042659448ae74': '毒/反伤/持牌自损/能力兑现分别追溯，不将长期分数当当前收益。',
    'silent-proposal-990f054036609447': '净扣敌血、回血毛伤与路线实际回复分账；不把未执行节点或删输出称为已得到保血收益。',
    'silent-proposal-e18d3f18e6cac2a0': '区分本体0血与自爆未结束，保留原始占位数；参考排序的变化须另有完整固定比较。',
    'silent-proposal-9733bb80f445aeae': '显示残壳毒层和当前自爆事实，不把新增6毒当减伤6或提前喝药必胜。',
    'silent-proposal-c51468c5e8ba6668': '核实槽位消耗、随机选择与重规划后的实际收益，未执行无药分支保持未知。',
    'silent-proposal-86a7db08d1a31976': '并列失血、无实体下输出和能力建立窗口，保留护栏前原答及SL后的选择。',
    'silent-proposal-e282a9131b99129a': '先完成跨续问的实果归属，再用独立局验证血价/能力窗口的排序候选。',
}

results = [{'id': i, 'state': 'waiting', 'reason': reasons[i]} for i in dispatch['proposal_ids']]
payload = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-090117-strategy-proposal',
           'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
           'tests': {'tsc': None, 'vitest': None, 'cases': None},
           'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
           'proposal_results': results, 'report': str(out / 'report.md')}
(out / 'result.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')

parts = ['# 本批十项静默猎手提案逐项复核\n',
         '来源任务和实现任务均为 strategy-proposal，本批 20261015-090117-strategy-proposal。只处理派发的十个既有CLI id，没有新建或扩领提案。适用范围为本批六局已观察的 Silent A10。\n']
for result in results:
    i = result['id']
    parts.append(f"## {i}\n\n原摘要：{queue[i]['summary']}\n\n账本：{', '.join(queue[i]['ledger'])}。\n\n证据：{evidence[i]}\n\n预期行为：{expected[i]}\n\n处置：waiting。{reasons[i]}\n")
parts.append('''## 反例、验证与回退

751 T2多5损血多9净扣敌血，T7多10损血多6净扣，T13省6血少6净扣；KEN T10多6损血只多2净扣，但T5省2血同时把步法建立由T5延到T9。它们同时限制“只保血”和“未试线更好”的泛化，不能拟固定5/6/10血门槛。PU巨兽第5次确实赢余2血，KV异鱼首试赢余9；不抹去胜线，也不据此给新排序归因。

本批只核原始固定事实和现有源码能力。后续若改变排序/持有价值/探索准入，先冻结原答、护栏后线、SL后线与真实续问，跨抽牌/弃牌/用药按状态串联；相同底板配对比较完整后继并记录资源分项。训练与验证按独立局及真实时间切分，不把同局SL拆成独立样本。新局需提供尚缺的执行归属、用药/不用药或排序比较，模拟不能冒充实盘反事实。

已有局部实现不等于十项原提案全部实现，故没有以已有源码commit登记整项duplicate。原始Markdown副本与原SHA均保留。没有新的源码或游戏规则可回退；现行行为保持，未来实现只回退其独立提交并保留本次证据、失败原件和waiting理由。
''')
(out / 'proposal.md').write_text('\n'.join(parts))

report = f'''# 静默猎手策略提案批次报告

本批十项提案均为 waiting。局部事实成立且部分展示/审计已在live实现，剩余完整执行归属、受控后继和独立校准不足，本批不修改策略、不登记整项implemented/duplicate。没有源码提交、合入或版本；测试与撤源码验证不适用。

## 身份、基线与范围

- batch：20261015-090117-strategy-proposal；角色silent；工作树为本报告父级的指定策略工作树。
- 初始HEAD：17e235df4df5fb6c00dbb832fb3ce35c868858db，初始git status干净。普通批次按要求合main，仅快进记录；完整base为 `{base}`。此后不继续追main。
- 根learn.json本批task/character/worktree/runs及十个proposal_ids匹配，没有research_request或implementation_request。根notes/strategy-research-silent.json绑定另一旧批次，故未承接该专题。只处理本批十个id。
- 六局均由runs.jsonl核实为SILENT/A10：{', '.join(dispatch['runs'])}。所有历史运行code均带dirty；未恢复当时dirty源码，不用当前实现冒充历史执行树。L9日志中的脑来源混合，不能将该局算为纯Codex表现评估。
- 十份原Markdown逐SHA一致，副本按既有id保存在本目录；原队列、原经验及历史复盘未改写。唯一分组研究依据是本批提案及六局实盘，没有读取其他角色知识或使用预训练游戏结论。

## 原日志与核验

共用extract_evidence.py按显式run_id/state.run_id/fingerprint.run及run-plans.run抽取，主六流见evidence/，runs及fight-plans见evidence-additional/。source_size、每行offset/bytes/SHA及各局计数均保留。evidence-small/为主扫描期间先取得的小流；其三流的内容SHA与主扫描相同，不覆盖任何旧材料。

选中 states 4167、decisions 4071、sl-attempts 43、run-config 6、run-plans 21、brain 130、runs 6、fight-plans 0，共8444行。逐行回读原日志offset/bytes，核SHA、JSON原文和无冲突显式身份。扫描中states/decisions/brain各有2/2/1坏行，未归到任何本批局；没有把它们当本批缺帧的证据。fight-plans的0只说明本次截点未选到，不断言日志不存在。

evidence-audit.json中41项事实断言通过，additional-facts.json另7项通过（另两组同指纹、药水模型限制、能力时点、空栏帧及固定live源码祖先核验）。这些是材料核验，不是tsc/vitest，也不是策略胜率测试。脚本首稿把751 T7敌净血差期望误写17/23；原摘要121→109/103证实应为12/18，损血13/23和多6净输出不变。错误首稿audit_evidence.initial.txt、失败evidence-audit.log与修正后evidence-audit-verified.log全部保留，未放宽断言或改原日志。

## 关键实盘窗口与限制

| 局/层/回合 | 尝试 | 实际损血 | 敌净血差 | 判断边界 |
|---|---|---:|---:|---|
| 751 F17 T2 | 1→3 | 13→18 | 9→18 | 多5血换多9净扣，不是整战收益 |
| 751 F17 T7 | 2→4 | 13→23 | 12→18 | 两线均有未决弃牌保守项，实际差10仍存在 |
| 751 F17 T13 | 1→6 | 8→2 | 17→11 | 省6血少6净扣，后轮不同 |
| KV F33 T5 | 4→5 | 0→0 | 36→29 | 删毒未得到当轮保血；回血毛伤另核 |
| KEN F17 T10 | 4→5 | 15→21 | 2→4 | B2 .385→.127属模型配对，非实盘胜率 |
| KEN F17 T5 | 4→6 | 7→5 | 1→2 | 续问追加小刀，步法由T5延至T9 |

YQL F17末试T10，states280160→280161显示毒2→8、血26/挡13/来袭41均不变，280162为死亡帧0；该帧26＋13小于41的数值缺口为2，与死亡帧截断0分列；这不证明只补2血即可存活，也不在此建立新的终局公式。没有提前喝、不喝或保留的受控整战。L9/PU/YQL的近十亿占位血不代表本体进度；PU第5试实际赢余2（sl719）仍保留。751/YQL/KEN各六次未胜只算各一局；KV F17首试赢余9（sl951）也保留，不由失败抹去能力或胜线。

KEN七次耗药逐动作与相邻状态槽位均核真，详见evidence-audit.json的potion_uses。三个pending回执由状态变化补证；随机选牌、发光水换手与后续重问不能凭一次派发当整候选执行。六次boss入口75血、所有本局F17T1状态药栏为空；缺无药或留药支线，不能给瓶价、留药规则或跨战预算赋新参数。

## 现有live实现与逐项处置

固定live提交见current-source-readback.json（逐13源码叶SHA及源码提交祖先）。持牌事实、药水未知价值、SL预测对照、候选审计、单动作回执、HP护栏审计及巨兽阶段展示均已有实现；actual_turn/actual_turn_result/whole_plan_executed仍留未知。anchorRank仍用原存活轮/原残血顺序，本批没有改写它。base-live-source.patch保留实际差异：explore.ts与controller.ts仅有Roy/Dai历史注释差异；未覆盖差异。已有能力与剩余范围分别核查，不能据这些局部叶把原十个宽项整体标duplicate。

详细证据、账本、旧/预期行为、反例、验证与回退逐项见proposal.md。以下为本批最终处置：
'''
for r in results:
    report += f"\n- `{r['id']}`；账本 {', '.join(queue[r['id']]['ledger'])}；waiting：{r['reason']}\n"
report += '''
## 记录、验证与交付

仅经根learner/ledger.py update为16个既有账本追加本批proposal.md/report.md追溯与缺证说明；不增加support样本、不改claim/首证/prior/status/version，不将原shipped降成proposed或冒称新shipped。输入、CLI回执和读回在本目录保存；队列最终状态由本批proposal_results交原调度器处理，没有直接写根队列或learn.json。

没有新源码/知识/任务模板修改，没有新CLI提案id，未执行tsc、vitest、撤源码失败/恢复通过或live合入，tests固定null。本批不造eval版本、不发规则已上线通知；已有反例和限制在本批报告保留，未发现需要另建的新经验冲突。未关闭任何宽量化、经验交付或研究父要求。

report.md、proposal.md、result.json及证据均在本批忽略目录；最终HEAD保持base，工作树保持干净。最终本地完整性和安全扫描见completion-readback.json及security-scan.log；实际退出码以该回执为准。原日志只读，没有运行play、联网、安装依赖、派下级agent或推送。
'''
(out / 'report.md').write_text(report)

ledger_to_proposals = {}
for i in dispatch['proposal_ids']:
    for ledger in queue[i]['ledger']:
        ledger_to_proposals.setdefault(ledger, []).append(i)
updates = []
for i, proposal_ids in sorted(ledger_to_proposals.items()):
    updates.append({'id': i, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(out / 'proposal.md'), str(out / 'report.md')]},
                    'note': '20261015-090117-strategy-proposal本批仅追溯复核：' + ','.join(proposal_ids) +
                    '均waiting；六局8444原行按offset/bytes/SHA及显式身份核真，41+7项材料核验；完整执行归属/受控后继/独立校准仍缺。证据与逐项理由见' + str(out / 'report.md') +
                    '。不增加支持样本，不改旧claim/首证/prior/status/version，无新源码/经验/合入/游戏版本。'})
(out / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'report': str(out / 'report.md'), 'proposal_count': len(results), 'ledger_trace_updates': len(updates)}, ensure_ascii=False))

import hashlib
import importlib.util
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
run_ids = dispatch['runs']
streams = {}
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected})
    assert actual == expected, (name, actual, expected)


for directory in ('evidence', 'evidence-additional'):
    for manifest in json.loads((OUT / directory / 'evidence-manifest.json').read_text()):
        name = manifest['stream']
        path = OUT / directory / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = dict.fromkeys(run_ids, 0)
        selected = []
        with (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
            with path.open('rb') as evidence:
                for raw in evidence:
                    digest.update(raw)
                    item = json.loads(raw)
                    source.seek(item['offset'])
                    original = source.read(item['bytes'])
                    assert hashlib.sha256(original).hexdigest() == item['sha256']
                    row = json.loads(original)
                    assert row == item['row']
                    identity = extract.run_identity(row)
                    assert identity == item['run_id'] and identity in counts
                    assert item['offset'] + item['bytes'] <= manifest['source_size']
                    if name == 'states':
                        state_run = row['state'].get('run') or {}
                        if state_run:
                            assert state_run['character_id'] == 'SILENT'
                            assert state_run['ascension'] == 10
                    counts[identity] += 1
                    selected.append(item)
        assert digest.hexdigest() == manifest['output_sha256']
        assert counts == manifest['counts']
        streams[name] = selected

check('选中行数', sum(len(v) for v in streams.values()), 8444)
check('角色与进阶', [(e['row']['character'], e['row']['ascension']) for e in streams['runs']], [('SILENT', 10)] * 6)
check('冻结运行身份', sorted(e['run_id'] for e in streams['runs']), sorted(run_ids))

sl = {(e['run_id'], e['row']['floor'], e['row']['attempt']): e for e in streams['sl-attempts']}
decisions = {e['line']: e for e in streams['decisions']}
states = {e['line']: e for e in streams['states']}


def enemy_hp(turn):
    return sum(int(x) for x in re.findall(r' (\d+)/\d+(?:, |$)', turn['enemies']))


def window(run, floor, attempt, turn):
    entry = sl[(run, floor, attempt)]
    turns = {x['turn']: x for x in entry['row']['summary']['turns']}
    before, after = turns[turn], turns[turn + 1]
    return {'sl_line': entry['line'], 'run': run, 'floor': floor, 'attempt': attempt,
            'turn': turn, 'hp_loss': before['hp'] - after['hp'],
            'net_enemy_hp_reduction': enemy_hp(before) - enemy_hp(after),
            'before': before, 'next_turn': after}


windows = []
for run, floor, attempts, turn, expected in [
    ('751FN9QM9MHQ', 17, [1, 3], 2, [[13, 9], [18, 18]]),
    ('751FN9QM9MHQ', 17, [2, 4], 7, [[13, 12], [23, 18]]),
    ('751FN9QM9MHQ', 17, [1, 6], 13, [[8, 17], [2, 11]]),
    ('KV0JHNJCKXLS', 33, [4, 5], 5, [[0, 36], [0, 29]]),
    ('KEN58SH9SLZ6', 17, [4, 5], 10, [[15, 2], [21, 4]]),
    ('KEN58SH9SLZ6', 17, [4, 6], 5, [[7, 1], [5, 2]]),
]:
    pair = [window(run, floor, attempt, turn) for attempt in attempts]
    check(f'{run} F{floor} T{turn}实盘窗口',
          [[x['hp_loss'], x['net_enemy_hp_reduction']] for x in pair], expected)
    windows.extend(pair)

for a, b in [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601)]:
    check(f'题面指纹{a}/{b}', decisions[a]['row']['fingerprint'] == decisions[b]['row']['fingerprint'], True)

for run in ['751FN9QM9MHQ', 'YQL8RZ8BWN1E', 'KEN58SH9SLZ6']:
    results = [e['row']['result'] for (r, f, _), e in sl.items() if r == run and f == 17]
    check(run + '六次未胜', [len(results), results.count('won')], [6, 0])
check('PU巨兽第五次胜线', [sl[('PU80F84P6HPN', 17, 5)]['row'][k] for k in ['result', 'end_hp']], ['won', 2])
check('KV异鱼首试胜线', [sl[('KV0JHNJCKXLS', 17, 1)]['row'][k] for k in ['result', 'end_hp']], ['won', 9])


def snapshot(line):
    state = states[line]['row']['state']
    player = state['combat']['player']
    enemy = state['combat']['enemies'][0]
    poison = next((x['amount'] for x in enemy['powers'] if x['power_id'] == 'POISON_POWER'), 0)
    return [poison, player['current_hp'], player['block'], enemy['intents'][0]['damage']]


check('YQL喝毒前', snapshot(280160), [2, 26, 13, 41])
check('YQL喝毒后', snapshot(280161), [8, 26, 13, 41])
check('YQL死亡帧', states[280162]['row']['state']['run']['current_hp'], 0)

potions = []
for before, after, decision, slot, potion in [
    (280206, 280207, 274131, 0, 'ATTACK_POTION'),
    (280232, 280233, 274156, 0, 'STABLE_SERUM'),
    (280262, 280263, 274185, 0, 'SPEED_POTION'),
    (280313, 280314, 274235, 1, 'WEAK_POTION'),
    (280315, 280316, 274237, 0, 'ATTACK_POTION'),
    (280348, 280349, 274267, 1, 'GLOWWATER_POTION'),
    (280354, 280355, 274272, 0, 'SKILL_POTION'),
]:
    a, b = (states[n]['row']['state'] for n in [before, after])
    chosen = decisions[decision]['row']['chosen']
    check(f'耗药{decision}动作', [chosen['action'], chosen['option_index']], ['use_potion', slot])
    check(f'耗药{decision}槽位', [a['run']['potions'][slot]['potion_id'], b['run']['potions'][slot]['occupied']], [potion, False])
    potions.append({'decision_line': decision, 'before_state_line': before, 'after_state_line': after,
                    'floor': a['run']['floor'], 'turn': a['turn'], 'slot': slot, 'potion': potion,
                    'response': decisions[decision]['row']['result'], 'next_screen': b['screen']})

for attempt in range(1, 7):
    start = sl[('KEN58SH9SLZ6', 17, attempt)]['row']['summary']['turns'][0]
    check(f'KEN第{attempt}次入口HP', start['hp'], 75)

data = {'verification': {'selected_lines': 8444, 'byte_hash_row_identity_verified': True,
                        'checks': len(checks), 'passed': True},
        'stream_counts': {k: len(v) for k, v in streams.items()},
        'checks': checks, 'actual_windows': windows, 'potion_uses': potions,
        'limitations': ['窗口为同指纹或摘要的相邻回合净变化，未声称完整候选逐源归属。',
                        '敌净血差不是含回血的毛伤害；抽牌与后轮动作变化未隔离。',
                        '同局SL不独立，模拟胜率不是实盘未执行分支。',
                        '全部历史运行带dirty，未恢复当时源码字节。']}
(OUT / 'evidence-audit.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(data['verification'], ensure_ascii=False))

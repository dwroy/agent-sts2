# 静默猎手：本批十个原提案复核

记录时间：2026-10-17T07:23:58+08:00；batch=20261017-071302-strategy-proposal；完整base=6c3a776b741276285beb422d2f9be98c6112851a。

来源局均已核SILENT/A10；仅消费本批十个原id。没有新源码改动，十项waiting；已有局部实现继续使用。新提案id为空，保留原CLI id及来源链。

共通方法：只从本角色原始帧及原提案核事实；6995行逐offset/bytes/SHA回读。37项既有材料断言在本批提取字节重新核验，属于发现样本内复核。六局、各局SL尝试及相关帧不扩成独立样本。没有拟合新权重或把重复日志称作盲测。

共通预期：原提案要求的缺口补齐后，才能关闭相应整项；当前保留全部合法选项及模型选择权，不加入固定必打、目标顺序、药价或SL门槛。后续新增源码须固定输入撤源码失败/恢复通过、原沙箱入口自测和实际live祖先核验；本批没有这种源码红绿。

共通回退：本批只有报告与CLI追溯，无生产行为可回退；旧日志、原提案、账本和失败记录保留。后续独立实现以对应源码提交回退。没有新行为发布、版本或shipped。

## silent-proposal-89354805ee4d7e77

按静默已观测帧补齐神化在同线及后续抽牌中的升级传播，并区分持有、施放与模型覆盖；无整场转胜保证。

- 来源任务：postmortem；独立实现任务：strategy-proposal。
- 原账本：silent-0237、silent-0238。
- 局号/层/回合：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1。
- 已核事实：states275564/275565与275679/275680均为7→5能；防御5→8、打击7→10；F43后续毒雾升级，原同序列51伤/13损兑现。
- 反例/限制：F43施放后仍整战损57；F45持有但未施放；不支持必打或必胜。
- 当前实现/旧规则：已见普通升级对、同线及抽牌模拟已有窄实现；actual_cast_this_fight仍为null，重放/自动出牌/未验证属性组合保留unknown。
- 本次处置：waiting。缺跨抽牌、选牌、用药、重问、SL和换战的实际施放持续身份核验，以及未覆盖升级属性交互的生产校准；本批未隔离新数值失配。
- 预期行为与验证：保留已见升级传播；后续以真实动作与各堆实例核持续身份，再校准未见交互；不能用固定加分或候选planned_plays代替实打。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-89354805ee4d7e77.original.md；SHA见proposal-provenance.json。

## silent-proposal-f2bfceddb1898dca

核验三骑士全败候选的即时血价、击杀缺口与药水MC预算成熟度；先做同盘预算实验，缺对照时保留原护栏、留药与目标规则。

- 来源任务：postmortem；独立实现任务：strategy-proposal。
- 原账本：silent-0106、silent-0019、silent-0201。
- 局号/层/回合：VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5。
- 已核事实：decisions269748药水仅1/12样本占707ms，rollout为horizon1/samples1/best=null；states275728/275729药水能1→2、HP67不变；末轮32血20挡对59来袭。
- 反例/限制：后续药水样本完成不等于整场胜率成熟；未实打的高伤线不能当作本可获胜。
- 当前实现/旧规则：simulation_reference已有范围、样本、并列与未比较区分；不从耗时或全败样本指定预算或focus。
- 本次处置：waiting。缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性/样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。
- 预期行为与验证：保存同一总预算和随机池的两策略原输入与输出，先核覆盖再比较；继续分开真实喝药和药水中位抽样，不改护栏或留药权重。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-f2bfceddb1898dca.original.md；SHA见proposal-provenance.json。

## silent-proposal-283a164780d11e69

神化已观察升级进入同方案与后续抽牌，保留未知边界，不定必打规则

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0237、silent-0238。
- 局号/层/回合：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1。
- 已核事实：与89354805ee4d7e77同一局的神化升级事实，独立experience-update来源链；原Markdown和经验关联已核。
- 反例/限制：同一局与同一个缺口不能计为两份独立支持，也不能仅因提案相似就判源码duplicate。
- 当前实现/旧规则：普通神化与已观察升级的窄功能已有实际live祖先；持有/预测/实际施放仍须分开。
- 本次处置：waiting。同源神化宽项仍缺实际施放持续身份及跨中断验证；已有窄源码未覆盖该经验来源链的全部验收条件，保留waiting。
- 预期行为与验证：沿原两条账本和两个提案id共享同一实现证据，不另建重复id；缺口补齐后逐来源登记。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-283a164780d11e69.original.md；SHA见proposal-provenance.json。

## silent-proposal-ebbfe3b97548756d

逐源验证当前攻防、毒触发与持续资源，不从持有或单轮减力预支整场收益

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。
- 局号/层/回合：VLZ6CCT8AQ0A F43 T1—T5、F45 T1—T5及F44休息。
- 已核事实：升级勒紧/尖啸、负力期限、当前覆甲、毒触发与实际回复分源；F45末轮无覆甲，32血20挡对59需损39；牌组持有不能当能力建立。
- 反例/限制：F43获胜仍损57，F44回复到67仍未过F45；不同节点血档不支持统一安全血线。
- 当前实现/旧规则：已有攻防/毒/当轮资源的局部模型与事实提示，不等于十五子项联合消费者校准。
- 本次处置：waiting。缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息资源接续；未发现新的可隔离失配。
- 预期行为与验证：逐源重放已发生数值并核资源接续，不将单轮减力预支为永久收益；神化沿原专属id推进，不拟新路线、休息或血价常数。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-ebbfe3b97548756d.original.md；SHA见proposal-provenance.json。

## silent-proposal-e5b87be50f28f311

静默A10同盘SL以12血换7伤重犯：补齐Jev原答、HP护栏、SL换线及重规划的候选代价与实际成长兑现审计；单局不足以改阈值，保留现行为并独立验证。

- 来源任务：postmortem；独立实现任务：strategy-proposal。
- 原账本：silent-0079、silent-0021、silent-0125、silent-0018。
- 局号/层/回合：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6。
- 已核事实：decisions270216/270282指纹逐字相同，原答与SL替换死亡预测0/24和5/24；实际本轮分别损3/15、敌净扣10/17，即多12血换7伤。
- 反例/限制：另一次防御替换延长到T11仍死；0/24与5/24不等同，全未来损血封顶也不是相同死率。
- 当前实现/旧规则：selection_audit记录预测阶段，selection_dispatch只认证单次派发；whole_plan_executed和actual_turn仍null；离线端点工具不认证完整候选。
- 本次处置：waiting。缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；未选线缺受控整战后继，不能据12换7更改护栏或SL阈值。
- 预期行为与验证：保留同指纹两次真实端点和原问阶段；持续候选身份须覆盖全部重问/中断并回连实际状态，不能用文本相似或首动作回执认证整条线。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-e5b87be50f28f311.original.md；SHA见proposal-provenance.json。

## silent-proposal-49632bc4878fb597

把当前属性、每击修正、弱与成长分项验证，不增加统一保血或输出权重。

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0005、silent-0231。
- 局号/层/回合：CA5KE8GFJ9X2 F13 T1/T3/T5。
- 已核事实：states273237/273252/273263敌力0/4/8，同招11/15/19；弱后273257/273268为11/14，成长未停止。
- 反例/限制：计划步法没有取得，本局不能提供正敏捷路径样本；末轮2血10挡仍不足。
- 当前实现/旧规则：当前逐击力量、弱、敏捷与独立成长有局部路径；本批没有隔离新的算式差额。
- 本次处置：waiting。缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。
- 预期行为与验证：按A10当前怪物数据和实际牌面逐击核对；正敏捷需本角色真实样本补齐，不从别的角色或未取得牌补值。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-49632bc4878fb597.original.md；SHA见proposal-provenance.json。

## silent-proposal-66532328a585941f

持有/计划/已建立分账；如提构筑或启动权重，先做实盘兑现与受控整场验证。

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0021、silent-0009。
- 局号/层/回合：5PM6JAQG6FNQ F39末试T2；F33为同局不同战对照。
- 已核事实：decisions268455及states274379/274380：向无毒失落打冒泡能5→4，目标35血/0毒均未变；玩家未建立雾。
- 反例/限制：同局F33已建立组件且赢，但敌人、资源与牌序不同，不是启动顺序受控对照。
- 当前实现/旧规则：保留持有、计划和实际建立分账；局部无毒空打不能推出构筑或启动固定权重。
- 本次处置：waiting。缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部零效果不足拟合启动权重。
- 预期行为与验证：以run_id划分后续开发/验证样本，先冻结同局面条件和实际兑现；缺对照继续原行为。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-66532328a585941f.original.md；SHA见proposal-provenance.json。

## silent-proposal-43a76a31ba7bdcfa

冻结吸取、负敏捷与毒的分项事实；任何SL范围或换线偏好需完整同盘验证。

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0030、silent-0027。
- 局号/层/回合：61E2QS63Y9WU F17 T5/T6/T7。
- 已核事实：states273504双防御各3、敏捷−2；族母67→34，17+16毒继续结算；属性变化与毒分开记录。
- 反例/限制：本场首试获胜不支持别局SL换线必能救活；没有未选路线的受控胜负。
- 当前实现/旧规则：负敏捷挡与毒结算局部机制已存在；SL范围、阈值或偏好不由这一个端点决定。
- 本次处置：waiting。缺A10同起始HP、构筑、完整抽序的SL整战配对及另一条已核完整后继；首试胜利与负敏捷/毒端点不足改变SL范围或阈值。
- 预期行为与验证：冻结吸取前后属性、两次防御和17+16毒；策略变更须另存同起点完整后继，不把SL恢复当回血。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-43a76a31ba7bdcfa.original.md；SHA见proposal-provenance.json。

## silent-proposal-5264153a4a4b0e5c

复验已有召唤和各实体成长；保留所有目标选项，相同推演值并列，不强制首杀。

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0039、silent-0209。
- 局号/层/回合：61E2QS63Y9WU F23 T3/T4/T5。
- 已核事实：states273593→273596：本体76→41、幻象14→2，合计净扣47＝本体35＋幻象12，玩家25→10；两实体力量3→6。
- 反例/限制：幻象余2仍攻击；focus幻象39伤/零损候选未实打，不能作为另一条整战胜线。
- 当前实现/旧规则：已有召唤/复现和逐实体成长的局部源码；净伤不等于退场进度或完整目标顺序收益。
- 本次处置：waiting。缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码和T4端点不足认证目标顺序的整战收益。
- 预期行为与验证：按实体当前HP和成长逐阶段核召唤/退场/复现，保留全部目标选项及相同推演值并列，不规定首杀。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-5264153a4a4b0e5c.original.md；SHA见proposal-provenance.json。

## silent-proposal-bddfa690a84e03d0

按当前进阶、睡眠/眩晕/成长分别验证；不把未知换线胜率或固定杀序写成规则。

- 来源任务：experience-update；独立实现任务：strategy-proposal。
- 原账本：silent-0128、silent-0079。
- 局号/层/回合：DUZUBAJ3A8GP F30 T1—T6、相关四次尝试。
- 已核事实：states274929/274932/274934甲虫力量2→−4→4、来袭20→14→22，临时减力之后恢复并成长；睡眠/眩晕另列。
- 反例/限制：末试T4多扣敌3血却多损玩家2血；四次失败不支持单按输出或一律保血的排序。
- 当前实现/旧规则：已有睡眠与成长的局部模拟；当轮减力不等于取消下一轮成长。
- 本次处置：waiting。缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新输出血价或固定杀序。
- 预期行为与验证：逐阶段核睡眠倒数、唤醒/眩晕和减力期限，冻结完整抽序后再比较换序；不扩SL样本分母。
- 原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/silent-proposal-bddfa690a84e03d0.original.md；SHA见proposal-provenance.json。


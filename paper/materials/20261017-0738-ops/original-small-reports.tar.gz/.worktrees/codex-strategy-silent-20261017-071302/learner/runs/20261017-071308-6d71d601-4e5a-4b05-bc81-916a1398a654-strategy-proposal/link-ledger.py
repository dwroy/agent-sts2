import gzip
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PATH = ROOT / 'paper/materials/learning/ledger.jsonl'
selected = json.loads((HERE / 'selected-proposals.json').read_text())
links = {}
for ident, item in selected.items():
    for ledger in item['original']['ledger']:
        links.setdefault(ledger, []).append(ident)
ids = set(links)
spec = importlib.util.spec_from_file_location('task_ledger', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def read_selected():
    rows = []
    with PATH.open('rb') as handle:
        for n, raw in enumerate(handle, 1):
            row = json.loads(raw)
            if row.get('id') in ids:
                rows.append((n, row))
    return module.fold(rows)

def prefix_sha(size):
    digest = hashlib.sha256()
    with PATH.open('rb') as handle:
        left = size
        while left:
            data = handle.read(min(left, 1024 * 1024))
            if not data:
                raise ValueError('ledger truncated')
            digest.update(data)
            left -= len(data)
    return digest.hexdigest()

subprocess.run(['date', '-Is'], check=True)
before = read_selected()
assert len(before) == 26 and all(x['character'] == 'silent' for x in before.values())
old_size = PATH.stat().st_size
old_sha = prefix_sha(old_size)
changes = []
for ident in sorted(ids):
    changes.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261017-071302-strategy-proposal：仅本批原派发' + ','.join(links[ident]) +
                    '复核，均waiting；六Silent/A10局八流6995行逐offset/bytes/SHA回读、37项既有材料断言复核；'
                    '八流与上批同字节，六消费者输入/四源码同SHA后复用旧输出、未重跑。'
                    '无新可隔离数值失配，具体缺口见本批proposal.md/report.md；无源码/合入/版本/生产测试。'
                    '仅追溯，不重复support/repeat，不改claim/首证/prior/evidence/status/version/shipped，不关闭宽父。'})
payload = ''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in changes)
(HERE / 'ledger-update.jsonl').write_text(payload)
(HERE / 'ledger-before.json.gz').write_bytes(gzip.compress(json.dumps(before, ensure_ascii=False).encode(), mtime=0))
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                        input=payload, text=True, capture_output=True)
(HERE / 'ledger-update.stdout').write_text(result.stdout)
(HERE / 'ledger-update.stderr').write_text(result.stderr)
(HERE / 'ledger-cli-receipt.json').write_text(json.dumps({'returncode': result.returncode,
                                                        'rows_requested': len(changes)}, indent=2))
if result.returncode:
    raise SystemExit(result.returncode)
assert prefix_sha(old_size) == old_sha
after = read_selected()
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence',
             'status', 'version', 'shipped_at', 'effect']
for ident in ids:
    a, b = before[ident], after[ident]
    assert all(a.get(k) == b.get(k) for k in protected), ident
    assert b['notes'][:len(a['notes'])] == a['notes'], ident
    assert b['history'][:len(a['history'])] == a['history'], ident
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values, (ident, key)
    assert str(HERE / 'report.md') in b['where']['proposal']

expected = {x['id']: x for x in changes}
actual = []
with PATH.open('rb') as handle:
    handle.seek(old_size)
    while True:
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        row = json.loads(raw)
        change = expected.get(row.get('id'))
        if not change or row.get('note') != change['note']:
            continue
        assert {k: row[k] for k in change} == change
        actual.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                       'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
assert len(actual) == len(changes)
(HERE / 'ledger-after.json.gz').write_bytes(gzip.compress(json.dumps(after, ensure_ascii=False).encode(), mtime=0))
(HERE / 'ledger-readback.json').write_text(json.dumps({'verified': True, 'updates': len(actual),
    'source': str(PATH), 'prefix_bytes': old_size, 'prefix_sha256': old_sha,
    'protected_fields_unchanged': protected, 'old_history_notes_where_prefixes_unchanged': True,
    'appends': actual}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'CLI退出码': 0, '追加并回读': len(actual), '原保护字段及历史保持': True}, ensure_ascii=False))

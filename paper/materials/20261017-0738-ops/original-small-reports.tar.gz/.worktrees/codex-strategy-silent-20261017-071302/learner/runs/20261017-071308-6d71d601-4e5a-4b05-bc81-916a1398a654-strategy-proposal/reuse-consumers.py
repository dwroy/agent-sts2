import gzip
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-234303/learner/runs/20261016-234320-e14c6ab3-7310-4d71-a96a-f0c7f89a197f-strategy-proposal')
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
old = json.loads((PRIOR / 'consumer-reuse.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
sources = []
for entry in old['source_modules']:
    path = entry['path']
    current = Path(path).read_bytes()
    physical_live = (LIVE / path).read_bytes()
    assert sha(current) == entry['base_sha256'] == sha(physical_live), path
    sources.append({'path': path, 'current_sha256': sha(current),
                    'prior_sha256': entry['base_sha256'], 'live_sha256': sha(physical_live)})

manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
manifest += json.loads((HERE / 'evidence-extra/evidence-manifest.json').read_text())
old_manifest = json.loads((PRIOR / 'evidence/evidence-manifest.json').read_text())
streams = []
for meta in manifest:
    previous = next(x for x in old_manifest if x['stream'] == meta['stream'])
    assert meta['counts'] == previous['counts'], meta['stream']
    assert meta['output_sha256'] == previous['output_sha256'], meta['stream']
    streams.append({'stream': meta['stream'], 'counts': meta['counts'],
                    'same_selected_bytes': True, 'source_size': meta['source_size'],
                    'prior_source_size': previous['source_size'], 'sha256': meta['output_sha256']})

consumers = []
for item in json.loads((HERE / 'consumer-input-manifest.json').read_text()):
    run = item['run_id']
    data = gzip.decompress((HERE / (run + '.consumer-input.json.gz')).read_bytes())
    previous = gzip.decompress((PRIOR / (run + '.consumer-input.json.gz')).read_bytes())
    assert data == previous
    output_path = PRIOR / (run + '.consumer-output.json.gz')
    packed = output_path.read_bytes()
    raw = gzip.decompress(packed)
    recorded = next(x for x in old['consumers'] if x['run_id'] == run)
    assert sha(packed) == recorded['output_packed_sha256']
    assert sha(raw) == recorded['output_raw_sha256']
    (HERE / output_path.name).write_bytes(packed)
    output = json.loads(raw)
    consumers.append({'run_id': run, 'source': str(output_path), 'input_sha256': sha(data),
                      'output_packed_sha256': sha(packed), 'output_raw_sha256': sha(raw),
                      'reexecuted': False, 'output_keys': list(output)})

result = {'prior': str(PRIOR), 'all_inputs_and_sources_match': True,
          'streams': streams, 'source_modules': sources, 'consumers': consumers,
          'note': '仅在输入及四模块逐字节匹配后复用原输出，未重跑消费者或生产测试。'}
(HERE / 'consumer-reuse.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'相同输入复用': len(consumers), '相同源码模块': len(sources),
                  '八流行数': sum(sum(x['counts'].values()) for x in streams)}, ensure_ascii=False))

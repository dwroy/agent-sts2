import collections
import gzip
import hashlib
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
EVIDENCE = SCRATCH / 'evidence'
RUNS = 'VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP'.split()
TARGETS = {'VLZ6CCT8AQ0A': {35, 43, 44, 45}, '8JRE1C4H4Z2W': {17, 33},
           'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 39},
           '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}

def write(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def power(values):
    return {x['power_id']: x['amount'] for x in values or []}

def snapshot(item):
    row = item['row']; state = row['state']; combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
            'sha256': item['sha256'], 'run_id': state['run_id'], 'floor': state['run']['floor'],
            'turn': state.get('turn'), 'screen': state['screen'], 'observed_ts': row.get('observed_ts'),
            'hp': player.get('current_hp', state['run'].get('current_hp')),
            'max_hp': player.get('max_hp', state['run'].get('max_hp')), 'block': player.get('block'),
            'energy': player.get('energy'), 'powers': power(player.get('powers')),
            'hand': [{'index': c.get('index'), 'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                      'cost': c.get('energy_cost'), 'values': {v['name']: v['current_value'] for v in c.get('dynamic_values', [])}}
                     for c in combat.get('hand', [])],
            'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                         'block': e.get('block'), 'powers': power(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies', [])]}

manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text()) + json.loads((SCRATCH / 'evidence-extra/evidence-manifest.json').read_text())
by_stream = {}; verification = []
for meta in manifest:
    path = (SCRATCH / 'evidence-extra' if meta['stream'] in ['runs', 'fight-plans'] else EVIDENCE) / (meta['stream'] + '.evidence.jsonl')
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == meta['output_sha256']
    rows = [json.loads(line) for line in data.splitlines()]
    counts = collections.Counter(x['run_id'] for x in rows)
    assert all(counts[r] == meta['counts'][r] for r in RUNS)
    source = Path('/home/dw/Projects/agent-sts2/logs') / (meta['stream'] + '.jsonl')
    with source.open('rb') as handle:
        for item in rows:
            assert item['source'] == str(source)
            assert item['offset'] + item['bytes'] <= meta['source_size']
            handle.seek(item['offset']); raw = handle.read(item['bytes'])
            assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
    by_stream[meta['stream']] = rows
    verification.append({'stream': meta['stream'], 'source_size': meta['source_size'],
                         'verified_rows': len(rows), 'counts': meta['counts'], 'output_sha256': meta['output_sha256']})
write('raw-readback-verification.json', {'verified': True, 'total_rows': sum(x['verified_rows'] for x in verification), 'streams': verification})

selected = []; decision_summaries = []; identities = []; consumer_inputs = []
for run in RUNS:
    run_rows = [x for x in by_stream['runs'] if x['run_id'] == run]
    assert len(run_rows) == 1
    identity = run_rows[0]['row']
    assert identity['character'] == 'SILENT' and identity['ascension'] == 10
    states = [x for x in by_stream['states'] if x['run_id'] == run]
    decisions = [x for x in by_stream['decisions'] if x['run_id'] == run]
    for item in states:
        state = item['row']['state']
        assert state['run_id'] == run and state['run']['character_id'] == 'SILENT' and state['run']['ascension'] == 10
        if state['run']['floor'] in TARGETS[run]: selected.append(snapshot(item))
    for item in decisions:
        row = item['row']
        if row.get('floor') in TARGETS[run]:
            decision_summaries.append({k: row.get(k) for k in ['run_id', 'floor', 'turn', 'observed_ts', 'decision_id', 'label', 'sl_attempt', 'sl_reloads', 'chosen', 'expect', 'journal', 'result', 'answers', 'sl_explore', 'hp_guard', 'rationale']} | {'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'], 'sha256': item['sha256']})
    normalized = {'run': identity,
                  'states': [x['row'] | {'_line': x['line'], '_source_sha256': x['sha256']} for x in states],
                  'decisions': [x['row'] | {'_line': x['line'], '_source_sha256': x['sha256']} for x in decisions]}
    raw = (json.dumps(normalized, ensure_ascii=False) + '\n').encode()
    name = run + '.consumer-input.json.gz'
    (SCRATCH / name).write_bytes(gzip.compress(raw, mtime=0))
    consumer_inputs.append({'run_id': run, 'path': str(SCRATCH / name), 'raw_sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw),
                            'states': len(states), 'decisions': len(decisions),
                            'missing_decision_id_lines': [x['line'] for x in decisions if not x['row'].get('decision_id')]})
    identities.append(identity)
write('run-identities.json', identities)
write('consumer-input-manifest.json', consumer_inputs)
write('selected-state-facts.json', selected)
write('selected-decision-facts.json', decision_summaries)
write('attempt-facts.json', [{'line': x['line'], 'offset': x['offset'], 'sha256': x['sha256'],
                             'run_id': x['run_id'], 'floor': x['row'].get('floor'), 'attempt': x['row'].get('attempt'),
                             'result': x['row'].get('result'), 'turns': x['row'].get('turns'), 'summary': x['row'].get('summary')}
                            for x in by_stream['sl-attempts']])
print(json.dumps({'核验原行': sum(x['verified_rows'] for x in verification), '选取状态': len(selected),
                  '选取决策': len(decision_summaries), '消费者输入': consumer_inputs}, ensure_ascii=False))

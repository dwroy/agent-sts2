# 静默猎手策略提案批次报告

记录时间：2026-10-17T07:23:58+08:00；batch=20261017-071302-strategy-proposal。

本批十项均waiting。已有神化、攻防和候选审计的局部功能已经在live；原提案仍需持续执行身份、逐源组合校准或受控整战后继。本批未发现新的可隔离数值失配，没有源码或知识修改、提交、live合入、版本及新增shipped。

## 身份与范围

开工HEAD=91f7cb955fe19ebd8e33ab705df688e5227bf900，git status为空。普通批git merge --no-edit main无冲突快进到完整base=6c3a776b741276285beb422d2f9be98c6112851a，此后HEAD保持该base。learn本批task/character/worktree/六runs及十proposal_ids匹配，无research_request、implementation_request或proposal_repair。普通专题文件绑定20261010-150327，未承接该专题或读取其他专题输入，没有下级agent。

六个派发局：VLZ6CCT8AQ0A、8JRE1C4H4Z2W、CA5KE8GFJ9X2、5PM6JAQG6FNQ、61E2QS63Y9WU、DUZUBAJ3A8GP。runs和每个state的角色/进阶均核SILENT/A10。仅本六局作为证据；没有读取其他角色知识，原dirty运行源码和知识不能由一个Git哈希完全复原。不将旧deepseek_calls等字段倒推脑来源，也不作本轮爬塔统计。

## 原日志与材料核验

共用extract_evidence.py独立提取六流，再用同入口提取runs/fight-plans；原输出均保存。逐流冻结source_size，逐行记录source/line/offset/bytes/SHA与显式身份；6995行全部从原日志回读JSON及哈希通过。run-plans认run字段，其他流认run_id/state.run_id/fingerprint.run；冲突不收，不按正文提及收局。

| 流 | 冻结source_size（字节） | 所属行数 |
|---|---:|---:|
| states | 13740071750 | 3432 |
| decisions | 2117999471 | 3306 |
| sl-attempts | 44527833 | 29 |
| run-config | 1916880 | 6 |
| run-plans | 8736659 | 33 |
| brain | 711325962 | 183 |
| runs | 354231 | 6 |
| fight-plans | 2233957 | 0 |

states/decisions/brain全源各有2行无效JSON，不能据此断言属于本六局。fight-plans零匹配只说明该冻结截点未选中，不倒推原日志缺失或动作未执行。八流所属封套SHA和上批20261016-234303完全相同；全源变大没有增加本批独立样本。没有覆盖旧报告或零行初稿。

原十Markdown的bytes/SHA与对应队列add行一致，原字节已保存。718个目标状态和696个目标决策摘录见selected-state-facts.json/selected-decision-facts.json；37项既有材料断言在本批新提取并回读的字节上再次通过。这是材料核验，不是生产回归或撤源码负控。

关键事实：VLZ F43神化后续51伤/13损，F45痊愈药水真实+1能而HP67不变；8JRE同指纹T2实际多12血换7伤，但死亡预测0/24与5/24不同；CA5虚弱后蚌继续成长；5PM无毒冒泡耗1能而目标35血/0毒未变；61E负敏捷挡与17+16毒分列；61E F23净扣47为本体35加幻象12，并非本体47或敌全退场；DUZU减力后恢复并成长。这些均来自本角色原帧，不推广未观察交互。

## 既有消费者及源码边界

六个重新生成的消费者输入与上批解码字节相同；selection-execution/observation/turn/terminal四个模块本树、上批、当前live逐SHA相同。原六输出压缩及解码SHA再核后原样复用，未重跑消费者、模型或模拟。consumer-reuse.json保存完整来源及哈希。原输出的端点只在其认证范围内可用，actual_full_candidate_result=null不能解释为实际未执行。CA5、61E、DUZU共有五条无decision_id的原决策仍保留在原输入，旧有ID子集边界不变。

只读live观察提交=c7eadf02a06985d9120b1a1c9a60847cccc1adaa。13个生产叶中11个字节相同，card-model.ts和sl/explore.ts差异仅历史Roy/Dai注释文字，patch原件已存。六个既有窄源码提交均为本base和实际live祖先；它们不是本批实现，也不能关闭本批宽项：

- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：ops: replay checked Silent Apotheosis candidate facts。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：Propagate observed Silent Apotheosis Malaise upgrade。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：Replay tested held-loss candidate facts on current live。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：Integrate repaired legacy learning deltas and bounded continuation adapter。
- cf72bd21148059f111f760cc98a727369e34a47e：Integrate checked offline Silent potion observation tool。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：Propagate observed Silent Deadly Poison upgrade。

当前silent-apotheosis-reference的actual_cast_this_fight仍null；turn-solver在重放/自动出牌/未验证属性组合保留unknown；silent-selection-audit与single_action_receipt不认证完整候选。日志端点、局部模拟和长期因果收益分别留边界；本批不新增预算、药价、HP/SL阈值、启动权重或固定focus。

## 逐项处置

| 原id | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、用药、重问、SL和换战的实际施放持续身份核验，以及未覆盖升级属性交互的生产校准；本批未隔离新数值失配。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性/样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化宽项仍缺实际施放持续身份及跨中断验证；已有窄源码未覆盖该经验来源链的全部验收条件，保留waiting。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息资源接续；未发现新的可隔离失配。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；未选线缺受控整战后继，不能据12换7更改护栏或SL阈值。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部零效果不足拟合启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP、构筑、完整抽序的SL整战配对及另一条已核完整后继；首试胜利与负敏捷/毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码和T4端点不足认证目标顺序的整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新输出血价或固定杀序。 |

逐项证据局号/层/回合、全部原账本、反例、当前行为、预期和验证方法见proposal.md；原十CLI id沿用，不另建重复id。code_proposals为十个原id，implementation_domains=[]。未关闭量化、策略或学习入库父要求，报告完成不等于经验入库或大脑采用。

## 记录、验证与限制

仅经根learner/ledger.py update为原26条本角色账本追加proposal/report追溯，by=learner:strategy-proposal；不重复追加support/repeat，不改claim/首证/prior/evidence，不降既有shipped状态或改版本。CLI实际回执与读回另存；队列处置交最终proposal_results，不手改learn.json或提案队列。

无源码改动，撤源码失败/恢复通过不适用；本批未运行tsc/vitest，tests={"tsc":null,"vitest":null,"cases":null}。没有提交、merge或新eval版本；不造上线decision-log、规则双通知或shipped。源码行为和其他角色保持原状。

限制：六局为已用于发现的相关样本；SL尝试不扩大分母。旧dirty完整执行输入、未选线完整后继、同随机池/预算配对与持续候选归属尚未核齐；局部数值与源码不能替代整场因果校准。宿主PID在工具进程命名空间不可见，本批未独立核实原生模型/effort/service tier，不把默认配置或旧批回执当作本批实际切换证明。

本批只读查询失败和一次非战斗combat=null结构探查TypeError见execution-notes.md；随后正式脚本以空combat处理并完成回读。这些不计生产测试失败或游戏反证。未联网、未运行play、不读凭据/.env或游戏二进制、不改运维prompt、不推送。

提案交运维：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/proposal.md。
完整报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal/report.md。

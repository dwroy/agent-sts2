import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
identity = json.loads((HERE / 'identity.json').read_text())
proposals = json.loads((HERE / 'selected-proposals.json').read_text())
base = identity['base']
timestamp = subprocess.check_output(['date', '-Is'], text=True).strip()
items = [
    ('89354805ee4d7e77', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1',
     'states275564/275565与275679/275680均为7→5能；防御5→8、打击7→10；F43后续毒雾升级，原同序列51伤/13损兑现。',
     'F43施放后仍整战损57；F45持有但未施放；不支持必打或必胜。',
     '已见普通升级对、同线及抽牌模拟已有窄实现；actual_cast_this_fight仍为null，重放/自动出牌/未验证属性组合保留unknown。',
     '缺跨抽牌、选牌、用药、重问、SL和换战的实际施放持续身份核验，以及未覆盖升级属性交互的生产校准；本批未隔离新数值失配。',
     '保留已见升级传播；后续以真实动作与各堆实例核持续身份，再校准未见交互；不能用固定加分或候选planned_plays代替实打。'),
    ('f2bfceddb1898dca', 'VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5',
     'decisions269748药水仅1/12样本占707ms，rollout为horizon1/samples1/best=null；states275728/275729药水能1→2、HP67不变；末轮32血20挡对59来袭。',
     '后续药水样本完成不等于整场胜率成熟；未实打的高伤线不能当作本可获胜。',
     'simulation_reference已有范围、样本、并列与未比较区分；不从耗时或全败样本指定预算或focus。',
     '缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性/样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。',
     '保存同一总预算和随机池的两策略原输入与输出，先核覆盖再比较；继续分开真实喝药和药水中位抽样，不改护栏或留药权重。'),
    ('283a164780d11e69', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1',
     '与89354805ee4d7e77同一局的神化升级事实，独立experience-update来源链；原Markdown和经验关联已核。',
     '同一局与同一个缺口不能计为两份独立支持，也不能仅因提案相似就判源码duplicate。',
     '普通神化与已观察升级的窄功能已有实际live祖先；持有/预测/实际施放仍须分开。',
     '同源神化宽项仍缺实际施放持续身份及跨中断验证；已有窄源码未覆盖该经验来源链的全部验收条件，保留waiting。',
     '沿原两条账本和两个提案id共享同一实现证据，不另建重复id；缺口补齐后逐来源登记。'),
    ('ebbfe3b97548756d', 'VLZ6CCT8AQ0A F43 T1—T5、F45 T1—T5及F44休息',
     '升级勒紧/尖啸、负力期限、当前覆甲、毒触发与实际回复分源；F45末轮无覆甲，32血20挡对59需损39；牌组持有不能当能力建立。',
     'F43获胜仍损57，F44回复到67仍未过F45；不同节点血档不支持统一安全血线。',
     '已有攻防/毒/当轮资源的局部模型与事实提示，不等于十五子项联合消费者校准。',
     '缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息资源接续；未发现新的可隔离失配。',
     '逐源重放已发生数值并核资源接续，不将单轮减力预支为永久收益；神化沿原专属id推进，不拟新路线、休息或血价常数。'),
    ('e5b87be50f28f311', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6',
     'decisions270216/270282指纹逐字相同，原答与SL替换死亡预测0/24和5/24；实际本轮分别损3/15、敌净扣10/17，即多12血换7伤。',
     '另一次防御替换延长到T11仍死；0/24与5/24不等同，全未来损血封顶也不是相同死率。',
     'selection_audit记录预测阶段，selection_dispatch只认证单次派发；whole_plan_executed和actual_turn仍null；离线端点工具不认证完整候选。',
     '缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；未选线缺受控整战后继，不能据12换7更改护栏或SL阈值。',
     '保留同指纹两次真实端点和原问阶段；持续候选身份须覆盖全部重问/中断并回连实际状态，不能用文本相似或首动作回执认证整条线。'),
    ('49632bc4878fb597', 'CA5KE8GFJ9X2 F13 T1/T3/T5',
     'states273237/273252/273263敌力0/4/8，同招11/15/19；弱后273257/273268为11/14，成长未停止。',
     '计划步法没有取得，本局不能提供正敏捷路径样本；末轮2血10挡仍不足。',
     '当前逐击力量、弱、敏捷与独立成长有局部路径；本批没有隔离新的算式差额。',
     '缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。',
     '按A10当前怪物数据和实际牌面逐击核对；正敏捷需本角色真实样本补齐，不从别的角色或未取得牌补值。'),
    ('66532328a585941f', '5PM6JAQG6FNQ F39末试T2；F33为同局不同战对照',
     'decisions268455及states274379/274380：向无毒失落打冒泡能5→4，目标35血/0毒均未变；玩家未建立雾。',
     '同局F33已建立组件且赢，但敌人、资源与牌序不同，不是启动顺序受控对照。',
     '保留持有、计划和实际建立分账；局部无毒空打不能推出构筑或启动固定权重。',
     '缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部零效果不足拟合启动权重。',
     '以run_id划分后续开发/验证样本，先冻结同局面条件和实际兑现；缺对照继续原行为。'),
    ('43a76a31ba7bdcfa', '61E2QS63Y9WU F17 T5/T6/T7',
     'states273504双防御各3、敏捷−2；族母67→34，17+16毒继续结算；属性变化与毒分开记录。',
     '本场首试获胜不支持别局SL换线必能救活；没有未选路线的受控胜负。',
     '负敏捷挡与毒结算局部机制已存在；SL范围、阈值或偏好不由这一个端点决定。',
     '缺A10同起始HP、构筑、完整抽序的SL整战配对及另一条已核完整后继；首试胜利与负敏捷/毒端点不足改变SL范围或阈值。',
     '冻结吸取前后属性、两次防御和17+16毒；策略变更须另存同起点完整后继，不把SL恢复当回血。'),
    ('5264153a4a4b0e5c', '61E2QS63Y9WU F23 T3/T4/T5',
     'states273593→273596：本体76→41、幻象14→2，合计净扣47＝本体35＋幻象12，玩家25→10；两实体力量3→6。',
     '幻象余2仍攻击；focus幻象39伤/零损候选未实打，不能作为另一条整战胜线。',
     '已有召唤/复现和逐实体成长的局部源码；净伤不等于退场进度或完整目标顺序收益。',
     '缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码和T4端点不足认证目标顺序的整战收益。',
     '按实体当前HP和成长逐阶段核召唤/退场/复现，保留全部目标选项及相同推演值并列，不规定首杀。'),
    ('bddfa690a84e03d0', 'DUZUBAJ3A8GP F30 T1—T6、相关四次尝试',
     'states274929/274932/274934甲虫力量2→−4→4、来袭20→14→22，临时减力之后恢复并成长；睡眠/眩晕另列。',
     '末试T4多扣敌3血却多损玩家2血；四次失败不支持单按输出或一律保血的排序。',
     '已有睡眠与成长的局部模拟；当轮减力不等于取消下一轮成长。',
     '缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新输出血价或固定杀序。',
     '逐阶段核睡眠倒数、唤醒/眩晕和减力期限，冻结完整抽序后再比较换序；不扩SL样本分母。'),
]
assert {'silent-proposal-' + x[0] for x in items} == set(identity['batch']['proposal_ids'])
results = [{'id': 'silent-proposal-' + x[0], 'state': 'waiting', 'reason': x[5]} for x in items]
(HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
lines = ['# 静默猎手：本批十个原提案复核', '',
         f'记录时间：{timestamp}；batch=20261017-071302-strategy-proposal；完整base={base}。', '',
         '来源局均已核SILENT/A10；仅消费本批十个原id。没有新源码改动，十项waiting；已有局部实现继续使用。新提案id为空，保留原CLI id及来源链。', '',
         '共通方法：只从本角色原始帧及原提案核事实；6995行逐offset/bytes/SHA回读。37项既有材料断言在本批提取字节重新核验，属于发现样本内复核。六局、各局SL尝试及相关帧不扩成独立样本。没有拟合新权重或把重复日志称作盲测。', '',
         '共通预期：原提案要求的缺口补齐后，才能关闭相应整项；当前保留全部合法选项及模型选择权，不加入固定必打、目标顺序、药价或SL门槛。后续新增源码须固定输入撤源码失败/恢复通过、原沙箱入口自测和实际live祖先核验；本批没有这种源码红绿。', '',
         '共通回退：本批只有报告与CLI追溯，无生产行为可回退；旧日志、原提案、账本和失败记录保留。后续独立实现以对应源码提交回退。没有新行为发布、版本或shipped。', '']
for short, evidence, fact, counter, current, reason, validation in items:
    ident = 'silent-proposal-' + short
    original = proposals[ident]['original']
    lines += ['## ' + ident, '', original['summary'], '',
              '- 来源任务：' + original['source_task'] + '；独立实现任务：strategy-proposal。',
              '- 原账本：' + '、'.join(original['ledger']) + '。',
              '- 局号/层/回合：' + evidence + '。',
              '- 已核事实：' + fact,
              '- 反例/限制：' + counter,
              '- 当前实现/旧规则：' + current,
              '- 本次处置：waiting。' + reason,
              '- 预期行为与验证：' + validation,
              '- 原提案：' + str(HERE / (ident + '.original.md')) + '；SHA见proposal-provenance.json。', '']
(HERE / 'proposal.md').write_text('\n'.join(lines) + '\n')

manifest = json.loads((HERE / 'raw-readback-verification.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
ancestors = json.loads((HERE / 'narrow-ancestor-readback.json').read_text())
checks = json.loads((HERE / 'fact-checks.json').read_text())
assert len(checks) == 37 and all(x['passed'] for x in checks)
report = ['# 静默猎手策略提案批次报告', '', f'记录时间：{timestamp}；batch=20261017-071302-strategy-proposal。', '',
          '本批十项均waiting。已有神化、攻防和候选审计的局部功能已经在live；原提案仍需持续执行身份、逐源组合校准或受控整战后继。本批未发现新的可隔离数值失配，没有源码或知识修改、提交、live合入、版本及新增shipped。', '',
          '## 身份与范围', '',
          f'开工HEAD=91f7cb955fe19ebd8e33ab705df688e5227bf900，git status为空。普通批git merge --no-edit main无冲突快进到完整base={base}，此后HEAD保持该base。learn本批task/character/worktree/六runs及十proposal_ids匹配，无research_request、implementation_request或proposal_repair。普通专题文件绑定20261010-150327，未承接该专题或读取其他专题输入，没有下级agent。', '',
          '六个派发局：' + '、'.join(identity['batch']['runs']) + '。runs和每个state的角色/进阶均核SILENT/A10。仅本六局作为证据；没有读取其他角色知识，原dirty运行源码和知识不能由一个Git哈希完全复原。不将旧deepseek_calls等字段倒推脑来源，也不作本轮爬塔统计。', '',
          '## 原日志与材料核验', '',
          '共用extract_evidence.py独立提取六流，再用同入口提取runs/fight-plans；原输出均保存。逐流冻结source_size，逐行记录source/line/offset/bytes/SHA与显式身份；6995行全部从原日志回读JSON及哈希通过。run-plans认run字段，其他流认run_id/state.run_id/fingerprint.run；冲突不收，不按正文提及收局。', '',
          '| 流 | 冻结source_size（字节） | 所属行数 |', '|---|---:|---:|']
for stream in manifest['streams']:
    report.append(f"| {stream['stream']} | {stream['source_size']} | {stream['verified_rows']} |")
report += ['', 'states/decisions/brain全源各有2行无效JSON，不能据此断言属于本六局。fight-plans零匹配只说明该冻结截点未选中，不倒推原日志缺失或动作未执行。八流所属封套SHA和上批20261016-234303完全相同；全源变大没有增加本批独立样本。没有覆盖旧报告或零行初稿。', '',
           '原十Markdown的bytes/SHA与对应队列add行一致，原字节已保存。718个目标状态和696个目标决策摘录见selected-state-facts.json/selected-decision-facts.json；37项既有材料断言在本批新提取并回读的字节上再次通过。这是材料核验，不是生产回归或撤源码负控。', '',
           '关键事实：VLZ F43神化后续51伤/13损，F45痊愈药水真实+1能而HP67不变；8JRE同指纹T2实际多12血换7伤，但死亡预测0/24与5/24不同；CA5虚弱后蚌继续成长；5PM无毒冒泡耗1能而目标35血/0毒未变；61E负敏捷挡与17+16毒分列；61E F23净扣47为本体35加幻象12，并非本体47或敌全退场；DUZU减力后恢复并成长。这些均来自本角色原帧，不推广未观察交互。', '',
           '## 既有消费者及源码边界', '',
           '六个重新生成的消费者输入与上批解码字节相同；selection-execution/observation/turn/terminal四个模块本树、上批、当前live逐SHA相同。原六输出压缩及解码SHA再核后原样复用，未重跑消费者、模型或模拟。consumer-reuse.json保存完整来源及哈希。原输出的端点只在其认证范围内可用，actual_full_candidate_result=null不能解释为实际未执行。CA5、61E、DUZU共有五条无decision_id的原决策仍保留在原输入，旧有ID子集边界不变。', '',
           f"只读live观察提交={source['live_observed']}。13个生产叶中11个字节相同，card-model.ts和sl/explore.ts差异仅历史Roy/Dai注释文字，patch原件已存。六个既有窄源码提交均为本base和实际live祖先；它们不是本批实现，也不能关闭本批宽项：", '']
for entry in ancestors:
    report.append('- ' + entry['commit'] + '：' + entry['subject'] + '。')
report += ['', '当前silent-apotheosis-reference的actual_cast_this_fight仍null；turn-solver在重放/自动出牌/未验证属性组合保留unknown；silent-selection-audit与single_action_receipt不认证完整候选。日志端点、局部模拟和长期因果收益分别留边界；本批不新增预算、药价、HP/SL阈值、启动权重或固定focus。', '',
           '## 逐项处置', '', '| 原id | 状态 | 具体缺口 |', '|---|---|---|']
for entry in results:
    report.append('| ' + entry['id'] + ' | waiting | ' + entry['reason'] + ' |')
report += ['', '逐项证据局号/层/回合、全部原账本、反例、当前行为、预期和验证方法见proposal.md；原十CLI id沿用，不另建重复id。code_proposals为十个原id，implementation_domains=[]。未关闭量化、策略或学习入库父要求，报告完成不等于经验入库或大脑采用。', '',
           '## 记录、验证与限制', '',
           '仅经根learner/ledger.py update为原26条本角色账本追加proposal/report追溯，by=learner:strategy-proposal；不重复追加support/repeat，不改claim/首证/prior/evidence，不降既有shipped状态或改版本。CLI实际回执与读回另存；队列处置交最终proposal_results，不手改learn.json或提案队列。', '',
           '无源码改动，撤源码失败/恢复通过不适用；本批未运行tsc/vitest，tests={"tsc":null,"vitest":null,"cases":null}。没有提交、merge或新eval版本；不造上线decision-log、规则双通知或shipped。源码行为和其他角色保持原状。', '',
           '限制：六局为已用于发现的相关样本；SL尝试不扩大分母。旧dirty完整执行输入、未选线完整后继、同随机池/预算配对与持续候选归属尚未核齐；局部数值与源码不能替代整场因果校准。宿主PID在工具进程命名空间不可见，本批未独立核实原生模型/effort/service tier，不把默认配置或旧批回执当作本批实际切换证明。', '',
           '本批只读查询失败和一次非战斗combat=null结构探查TypeError见execution-notes.md；随后正式脚本以空combat处理并完成回读。这些不计生产测试失败或游戏反证。未联网、未运行play、不读凭据/.env或游戏二进制、不改运维prompt、不推送。', '',
           '提案交运维：' + str(HERE / 'proposal.md') + '。', '完整报告：' + str(HERE / 'report.md') + '。']
(HERE / 'report.md').write_text('\n'.join(report) + '\n')
final = {'task': 'strategy-proposal', 'character': 'silent',
         'batch': '20261017-071302-strategy-proposal', 'base': base,
         'runs': identity['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': identity['batch']['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'proposal_results': len(results), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

# 静默猎手本批十项提案核验

记录时间（先date）：2026-10-17 07:26:05 CST。批次：20261017-071302-s2-strategy-proposal。角色：silent。
开工dispatch HEAD=91f7cb955fe19ebd8e33ab705df688e5227bf900，工作树干净；按普通队列要求git merge --no-edit main快进到完整base=6c3a776b741276285beb422d2f9be98c6112851a，无冲突。
根learn.json只读取本批，十个proposal_ids与工作树一致，reason=proposal，无proposal_repair/research_request/implementation_request。普通专题请求属于20261010另一批，未匹配，不借其work_spec或冻结数据替代本次身份。

结论：本批十项均waiting；没有新源码、知识数据、测试或行为规则改动，没有新提交、live合入或版本。已存在的窄实现仅作范围说明，不能关闭包含完整实际执行和后继验证的宽项。
以下证据、反例及限制只来自本角色派发局、原提案/账本和Silent经验；没有读取其他角色知识或以预训练事实补机制。原始Markdown十份按队列SHA逐一核验，完整原字节保存在*.original.md。

## 证据范围与验证

六局runs.jsonl均为SILENT/A10，终局层依次DUZ=30、5PM=39、CA5=13、8JRE=33、YF=48、XP=33。全部旧code带+dirty；本批没有重建当时源码/知识完整输入，当前实现的存在不证明当时预测已经正确。
共用extract_evidence.py提取八流；每流独立冻结source_size，每行保留source/line/offset/bytes/SHA和明确run身份，冲突身份不接收。总8274行：states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0。
verify_evidence.py逐行重新读取原日志物理字节，8274行SHA及JSON/身份全部核验，25项资料检查通过；这不是tsc/vitest、源码撤回红绿或新策略测试。八流选中输出SHA均与20261016-234303-s2同范围报告一致；截点增长没有增加本批支持样本。每局SL尝试不能按独立局计。
fight-plans零行只表示本次截点未选中，不表示原日志缺失。states/decisions/brain各2条无效全源原行由提取器报告，不将它们登记成本批坏帧或补造证据。没有重做旧run-plans截点；旧报告与零行初稿不覆盖。

## 1. silent-proposal-c20b5139dd0dff71

原提案：冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。
来源任务：experience-update → 本批strategy-proposal；证据：DUZUBAJ3A8GP / F27 / T4—T5；账本：silent-0168。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；SHA256=bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。

支持：states 274830—274833污染0→3→3→6，能力没有增加污染；274834火花6且污染清零，274836—274838技能逐次增加6污染。

现有代码/旧行为：combat-plan读取现场vitalSpark，turn-solver按技能增加污染并逐攻击段计价，rollout包含VITAL_SPARK_POWER增长；1698adc96的资源比较只输出模型预测。

反例及未知：技能也会提供格挡或毒；污染增加不等于所有技能都应少打。未执行替线没有完整胜负。

本批处置：waiting。火花3→6及污染增量已核；缺该局成长、技能挡/毒收益和完整候选的联合消费者回放。现有逐击模型只覆盖子项，不能把整项记为duplicate。

预期后续行为：保持当前选线；后续逐步分列技能收益、污染逐击血价及实际派发，不设置禁技能规则。 本批未实现该后续增量。

验证方法：冻结现场火花3/6、弱、挡、毒及完整候选，比较当前turn-solver→rollout→候选展示→实际动作的逐步结果，覆盖技能与能力的差别。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 2. silent-proposal-ae9e692d680e3819

原提案：提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。
来源任务：experience-update → 本批strategy-proposal；证据：5PM6JAQG6FNQ / F39 / T4—T6；账本：silent-0183, silent-0005。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；SHA256=b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。

支持：states 274351/274352/274354敏捷−4→−2→0；274357→274358失落退场，力量−4→0；274362遗忘又夺2敏。

现有代码/旧行为：现场负力量、负敏捷进入牌值；combat-plan将POSSESS_STRENGTH_POWER/POSSESS_SPEED_POWER识别为已知能力，但这不是逐来源返还账。

反例及未知：仅一次步法仍为负敏；原稿末试毒杀失落后仍不足以承受遗忘19攻击，不能推出固定优先杀谁。

本批处置：waiting。返4力及再次夺2敏已核；缺逐敌来源被夺量真值、退场返还与重抢的完整消费者校准，不能由当前总属性推出每个来源返还量。

预期后续行为：保持原候选与目标选择；后续按来源分账抢夺/返还，来源不明时保留未知。 本批未实现该后续增量。

验证方法：固定两敌身份、初始力敏、每次抢夺与毒杀/退场时点，核多来源和再次抢夺；需当前消费者与实帧的连续对照。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 3. silent-proposal-52f1e1bd2e7db0ed

原提案：第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。
来源任务：experience-update → 本批strategy-proposal；证据：CA5KE8GFJ9X2 / F13 / T1—T5；账本：silent-0231。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；SHA256=651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。

支持：states 273237/273252/273263力量0→4→8；原提案喷水11/15/19、弱后11/14，覆甲9/9/8/7/6只作现场记录。

现有代码/旧行为：monster-db.nearestAscension优先精确进阶；房间成本仍为独立ROOM_COST_MIN_N=5，没有把五样本门槛加到怪物HP/攻击。

反例及未知：覆甲层数递减的现场序列不能单独确定触发条件；一次低血死亡不能拟固定房间成本。

本批处置：waiting。两次加压各加4力已核；缺原运行实际移动表的冻结输入、完整覆甲减层条件及联合消费者校准。当前数据库入口存在不等于复原旧dirty运行输入。

预期后续行为：保持当前进阶事实读取与房间五样本门槛；后续核实完整逐步模型，不写死新的房间成本或减层规律。 本批未实现该后续增量。

验证方法：冻结A10移动表及每步攻击/弱/覆甲状态，先校准同招成长与减层，再验证读取路径；未观察分支必须保留未知。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 4. silent-proposal-6dd8bbff876be528

原提案：复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。
来源任务：experience-update → 本批strategy-proposal；证据：5PM6JAQG6FNQ / F38 / T3—T4；账本：silent-0233, silent-0209。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；SHA256=48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。

支持：states 274308/274313同上限23的ZAPBOT力量2→4、意图17→19，274317才退场。这里不把相同enemy_id当跨召唤永久实体ID。

现有代码/旧行为：rollout.STRENGTH_GROWTH_POWERS包含HIGH_VOLTAGE_POWER，combat-plan读取现场力量及能力；通用成长路径已有。

反例及未知：先杀爪牙候选35伤/损3没有完整实打；主怪中毒不代表爪牙已经退场，不能承诺保住后场HP。

本批处置：waiting。电击跨轮力量2→4、攻击17→19已核；召唤/实体替换后的完整消费者与另一击杀顺序的后继未验证，不从同名或同上限推继承计数。

预期后续行为：保持当前候选；后续核逐实体成长和召唤替换，不给新实体继承旧计数，不设固定杀序。 本批未实现该后续增量。

验证方法：冻结实际召唤身份、当前进阶移动表和连续状态，分别核老实体增长、新实体入场及同名替换；另一杀序整战结果另作验证。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 5. silent-proposal-578e415a259e6835

原提案：核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则
来源任务：experience-update → 本批strategy-proposal；证据：8JRE1C4H4Z2W / F33 / 首试与第三试T2；原稿另含F17 T6、F33 T5/T11；账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。
原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；SHA256=e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。

支持：decisions 270216/270282完整指纹相同；原稿同轮实损3/15、本体扣10/17，多12血只多7伤。其逐轮材料仍为同一局内相关尝试。

现有代码/旧行为：silent-selection-audit保留答选/SL前后候选，silent-selection-dispatch只记单动作回执，hp-guard-audit保留候选预测；实际整轮字段保持null。

反例及未知：末试防御替换省3血少10伤并延长到T11但仍败；候选差值不自动等于实际保血。金刚杵经验不以0016作支持，0016实际记录护喉甲。

本批处置：waiting。同盘换线血价已核且原答/护栏/SL预测与单动作回执已有窄实现；仍缺完整实际执行分段及受控整战后继。原稿金刚杵→silent-0016另有旧账本归属错配。

预期后续行为：保持探索和HP护栏；后续只在可核动作与状态上认证执行片段，抽弃牌/重规划切断原候选归属。 本批未实现该后续增量。

验证方法：按同指纹连接原答→护栏→SL→实际派发→后继状态，区分完整候选与前缀；原稿T5及F17重规划反例必须保留。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 6. silent-proposal-c0767768bf6a7ab1

原提案：全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。
来源任务：postmortem → 本批strategy-proposal；证据：YF0LXT1QSTGG / F48 / 第二与第三试T1；F33 SL成功为边界；账本：silent-0079。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；SHA256=28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。

支持：decisions 271309/271348同指纹；states 277327→277337与277366→277373分别实损0/9、敌本体扣45/38。271354提前结束候选后续，不能把预测续步登记已执行。

现有代码/旧行为：1698adc96资源比较及silent-sl-comparison已有current_turn_prediction/candidate_forecast，execution=unverified、actual_turn_result=null明确保留。

反例及未知：同局F33重打成功；F48第六次恢复挡续步后仍败，第四次T5又在弃牌后重规划。不能把所有SL或所有防御替换一概否定。

本批处置：waiting。实验体同盘实际多损9且少扣7已核；整线执行、抽弃牌后继与受控整战反事实不足，不能据全败封顶拟HP惩罚或禁止探索。

预期后续行为：保持原SL规则，继续分列当前候选预测与真实派发；未来没有受控胜线不调探索系数。 本批未实现该后续增量。

验证方法：固定T1成对状态和候选、271354结束动作，核0/9与45/38；另核抽弃牌边界及F33成功反例，不把有限样本24/24判死当零信息。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 7. silent-proposal-a46bdb7fe711d79a

原提案：实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。
来源任务：postmortem → 本批strategy-proposal；证据：YF0LXT1QSTGG / F48 / 末试T3—T5；账本：silent-0021, silent-0027, silent-0028, silent-0085。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；SHA256=eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。

支持：states 277512→277513：111阶段4HP/4毒/15力→212阶段212HP/0毒/0力；277519已建触媒2但零毒；277524/277526敏捷5→6、已有挡均23。

现有代码/旧行为：aad2700ab的silent-phase-current区分持有组件/已建能力/当前毒；1d57f9d0另列阶段参考；f3dea918传播苦无后续敏捷，不倒补先前格挡。

反例及未知：前试已建毒雾或余像仍败，持有/升级毒性爆发不表示当前阶段已施放；不能以未启动毒作唯一死因或强制先铺能力。

本批处置：waiting。阶段清毒、零毒触媒及敏捷取得时点已有窄实现；完整候选施毒、增段攻击、消耗额外扣血与重规划后继的联合消费者仍缺。

预期后续行为：保持排序；后续当前阶段毒/即时施毒/已结算伤害分列，缺少动作或后继时保持未知。 本批未实现该后续增量。

验证方法：核阶段重置、零毒额外伤害0、23挡不倒补，并对原候选至重规划和消耗扣血做完整联合校准；局部快照不作完整候选认证。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 8. silent-proposal-1044224808015e5c

原提案：核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。
来源任务：postmortem → 本批strategy-proposal；证据：XP2SL33HT0D9 / F33 / 首与第二试T3、首与末试T1；账本：silent-0079。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；SHA256=4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。

支持：decisions 271992/272040、271982/272195分别同指纹；sl-attempts 939/940的T3→T4血45→36/31，敌总387→363/360；states首末T1损2/10、扣25/34。

现有代码/旧行为：原B2/rollout门槛与未试线排名保留，已有资源比较只描述同题候选预测，未把零胜并列称为安全。

反例及未知：T1另有手里剑力量收益；末试T2零损、T3损4涉及减力、朝向和重规划，不是单一挡牌数的效果。

本批处置：waiting。双蟹T3多损5多伤3及T1多损8多伤9已核；缺同抽序完整替线与独立获胜验证，不能拟血价、禁止全部付血探索或用零胜并列证明安全。

预期后续行为：保持原探索；保留即时血价、输出、成长的事实分账，规则调整仍待独立完整后继证据。 本批未实现该后续增量。

验证方法：先核两组同指纹当轮差值，再按run_id与结束时间留出后续独立双蟹局；同档六试不能跨训练/验证或扩大分母。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 9. silent-proposal-7cbc6005db712ba9

原提案：用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。
来源任务：postmortem → 本批strategy-proposal；证据：XP2SL33HT0D9 / F33 / 末试T2、T4—T5；账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；SHA256=f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。

支持：states 278236轮初14挡，278237爪力0→−9；278249/278252/278254火箭攻击57→38→28；278255四敏脆弱仅6挡。

现有代码/旧行为：passive-pieces含船夹板T2=14，现有模型含临减、朝向、虚弱/脆弱和敏捷；68711002只覆盖特定爪取整，不能扩作全部组合。

反例及未知：已有4敏捷、手里剑成长仍未减员并死亡；更早Silent局只作为原提案来源，本批未重读其日志，不把旧摘要冒称新核实。

本批处置：waiting。轮初挡、临时减力和朝向变化已核；整套条件组合及完整候选实际兑现的联合消费者未认证，单项模型存在不能关闭宽项。

预期后续行为：保持牌序和价值权重；后续明确已有挡/新增挡、临减有效回合、朝向/弱的分别贡献与尚未结算毒。 本批未实现该后续增量。

验证方法：固定14+6=20、0→−9→0、57→38→28、四敏脆弱6挡等逐步原帧，接完整候选及实际派发；未观察叠层保留未知。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 10. silent-proposal-c59f592f1427a67e

原提案：核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证
来源任务：experience-update → 本批strategy-proposal；证据：YF0LXT1QSTGG / F48、XP2SL33HT0D9 / F33 / 上述各轮；账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。
原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；SHA256=81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。

支持：复用本批两局四组指纹/血价、实验体阶段与双蟹格挡/临减原帧；相同来源不另计支持。原稿101局、22次镣铐及50帧船夹板是原研究范围，非本批新复核范围。

现有代码/旧行为：资源对比、阶段事实、苦无传播、候选选择审计与单动作回执的源码均为当前base及live祖先，实际整候选认证仍未提供。

反例及未知：本局六败不否定组件价值或其他场次SL成功；路线、营火、药水无受控未选后继，不能设置避战、必休或留药阈值。

本批处置：waiting。两局同盘血价和阶段/临减事实已核；分段实际执行、逐来源资源与完整后继联合校准仍缺，局部入口不能合并冒称整项实现。

预期后续行为：保持原行为；后续补齐实派分段与已结算资源的联合证据，历史重复支持不重记。 本批未实现该后续增量。

验证方法：将前述两局当发现/固定回归样本，完成候选→派发→效果→回合/阶段出口链；独立后移验证后才考虑规则参数。 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

## 切分、拟合、影响与回退

本批仅六个独立来源局作已观察A10发现/固定帧核验；重复SL、重派和相同物理行不扩样本。不拟合HP血价、药水价格、能力优先级、固定杀序、必休血线或SL禁止条件。动作策略的独立验证须按run_id和结束时间后移，记录换线获胜等反例，未选整战后继保留未知。
Roy-2026-10-07-learning授权允许有证据时直接修改既有人定规则；本批保留现状来自上述具体数据/联合校准缺口，不是因为原规则不可改或要求另行审批。无关角色/进阶行为没有改动。
本批影响只有可追溯材料；没有行为补丁可回退。后续源码增量按独立commit回退并保留失败原件，实合live后才编号、双通知Roy和由ops登记shipped。本批不触发live锁、知识刷新、生产自测、发布或上线通知。

## 账本归属历史问题

原578e提案把金刚杵条目指向silent-0016；当前账本0016实际为护喉甲覆甲，原稿与原ID保留，不能把它登记为金刚杵机制支持。本问题已在旧同范围报告存在，本批只再次核对归属，不声称新机制反证。交运维沿ops→watcher→Roy核转达状态，本批不代填送达/已读ACK、不改写旧claim/首证/prior/status/version/shipped或提案原文。
只经根ledger.py update给原关联条目追加本批where.proposal和note，不追加support/repeat，不新建重复账本/提案ID；已shipped条目不降为proposed。code_proposals沿用原十个CLI ID，implementation_domains=[]表示本批没有新增实现。

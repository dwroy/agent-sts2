import collections
import hashlib
import importlib.util
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-234303-s2/learner/runs/20261016-234319-2db85410-d9a3-45b0-8796-3b09f6a459ab-strategy-proposal')
spec = importlib.util.spec_from_file_location('extract', TREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
old_manifest = {x['stream']: x for x in json.loads((OLD / 'evidence/evidence-manifest.json').read_text())}
states_wanted = {
    273237, 273247, 273252, 273258, 273263,
    274308, 274313, 274317, 274351, 274352, 274354, 274357, 274358, 274362,
    274830, 274831, 274832, 274833, 274834, 274836, 274837, 274838,
    277327, 277337, 277366, 277373, 277512, 277513, 277518, 277519, 277524, 277526,
    278017, 278021, 278023, 278231, 278236, 278237, 278242,
    278249, 278252, 278253, 278254, 278255,
}
decisions_wanted = {270216, 270282, 271309, 271348, 271354, 271982, 272195, 271992, 272040}
states, decisions, attempts = {}, {}, {}
streams, proofs = [], []
for entry in manifest:
    name = entry['stream']
    counts = collections.Counter()
    digest = hashlib.sha256()
    with (OUT / f'evidence/{name}.evidence.jsonl').open('rb') as handle, Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for raw in handle:
            digest.update(raw)
            item = json.loads(raw)
            assert extract.run_identity(item['row']) == item['run_id']
            assert item['offset'] + item['bytes'] <= entry['source_size']
            counts[item['run_id']] += 1
            source.seek(item['offset'])
            physical = source.read(item['bytes'])
            assert hashlib.sha256(physical).hexdigest() == item['sha256']
            assert json.loads(physical) == item['row']
            if (name == 'states' and item['line'] in states_wanted) or (name == 'decisions' and item['line'] in decisions_wanted) or name in ('runs', 'run-config', 'run-plans', 'sl-attempts'):
                proofs.append({k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')})
            if name == 'states' and item['line'] in states_wanted:
                states[item['line']] = item['row']['state']
            if name == 'decisions' and item['line'] in decisions_wanted:
                decisions[item['line']] = item['row']
            if name == 'sl-attempts':
                attempts[item['line']] = item['row']
    assert digest.hexdigest() == entry['output_sha256']
    assert all(counts[k] == v for k, v in entry['counts'].items())
    streams.append({**entry, 'all_physical_rows_verified': sum(counts.values()),
                    'same_selected_bytes_as_prior': entry['output_sha256'] == old_manifest[name]['output_sha256'],
                    'prior_source_size': old_manifest[name]['source_size']})
assert set(states) == states_wanted
assert set(decisions) == decisions_wanted

def powers(items):
    return {x['power_id']: x['amount'] for x in items}

def player(line):
    return states[line]['combat']['player']

def pp(line, power):
    return powers(player(line)['powers']).get(power, 0)

def enemies(line):
    return states[line]['combat']['enemies']

def enemy(line, id=None):
    return next(e for e in enemies(line) if id is None or e['enemy_id'] == id)

def ep(line, power, id=None):
    return powers(enemy(line, id)['powers']).get(power, 0)

def hp(line):
    return player(line)['current_hp']

def total_enemy_hp(line):
    return sum(e['current_hp'] for e in enemies(line))

def attack(line, id=None):
    return [i['damage'] for i in enemy(line, id)['intents'] if i.get('damage') is not None]

checks = []

def check(name, actual, expected, lines, stream='states'):
    checks.append({'name': name, 'actual': actual, 'expected': expected,
                   'passed': actual == expected, 'stream': stream, 'lines': lines})

for a, b in [(270216, 270282), (271309, 271348), (271982, 272195), (271992, 272040)]:
    check('成对决策完整指纹相同', decisions[a]['fingerprint'] == decisions[b]['fingerprint'], True, [a, b], 'decisions')
check('污染按技能增加且能力不加', [pp(n, 'TAINTED_POWER') for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6], [274830, 274831, 274832, 274833])
check('次轮火花六且污染清零', [ep(274834, 'VITAL_SPARK_POWER'), pp(274834, 'TAINTED_POWER')], [6, 0], [274834])
check('三个技能各增六污染', [pp(n, 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]], [0, 6, 12, 18], [274834, 274836, 274837, 274838])
check('蚌两次加压各加四力量', [ep(n, 'STRENGTH_POWER') for n in [273237, 273252, 273263]], [0, 4, 8], [273237, 273252, 273263])
check('电击上限血量和跨轮力量意图', [[enemy(n, 'ZAPBOT')['max_hp'], ep(n, 'STRENGTH_POWER', 'ZAPBOT'), attack(n, 'ZAPBOT')] for n in [274308, 274313]], [[23, 2, [17]], [23, 4, [19]]], [274308, 274313])
check('下一轮电击已退场', any(e['enemy_id'] == 'ZAPBOT' and e.get('is_alive') for e in enemies(274317)), False, [274317])
check('负敏两次步法后恢复', [pp(n, 'DEXTERITY_POWER') for n in [274351, 274352, 274354]], [-4, -2, 0], [274351, 274352, 274354])
check('失落退场与力量返还', [pp(274357, 'STRENGTH_POWER'), pp(274358, 'STRENGTH_POWER'), any(e['enemy_id'] == 'THE_LOST' for e in enemies(274358))], [-4, 0, False], [274357, 274358])
check('遗忘再次抢夺二敏', pp(274362, 'DEXTERITY_POWER'), -2, [274362])
check('实验体同盘实际血价与扣血', [[hp(a)-hp(b), total_enemy_hp(a)-total_enemy_hp(b)] for a,b in [(277327,277337),(277366,277373)]], [[0,45],[9,38]], [277327,277337,277366,277373])
check('双蟹首末同盘开场血价与扣血', [[hp(a)-hp(b), total_enemy_hp(a)-total_enemy_hp(b)] for a,b in [(278017,278023),(278231,278236)]], [[2,25],[10,34]], [278017,278023,278231,278236])
paired_turns=[]
for n in [939, 940]:
    turns={x['turn']: x for x in attempts[n]['summary']['turns']}
    paired_turns.append([turns[3]['hp']-turns[4]['hp'], turns[3]['enemies'], turns[4]['enemies']])
check('双蟹同盘第三轮实际血价', [x[0] for x in paired_turns], [9,14], [939,940], 'sl-attempts')
summary_hp = lambda text: sum(map(int, re.findall(r'(\d+)/\d+', text)))
check('双蟹同盘第三轮本体扣血', [summary_hp(x[1])-summary_hp(x[2]) for x in paired_turns], [24,27], [939,940], 'sl-attempts')
sandworm = []
for n in [921,923]:
    turns = {x['turn']: x for x in attempts[n]['summary']['turns']}
    sandworm.append([turns[2]['hp']-turns[3]['hp'], summary_hp(turns[2]['enemies'])-summary_hp(turns[3]['enemies'])])
check('沙虫同盘T2实际血价与扣血', sandworm, [[3,10],[15,17]], [921,923], 'sl-attempts')
check('实验体所在局前场SL成功反例', [attempts[929]['run_id'],attempts[929]['floor'],attempts[929]['result'],attempts[929]['end_hp']], ['YF0LXT1QSTGG',33,'won',20], [929], 'sl-attempts')
check('阶段变化清毒和旧力量', [[enemy(n)['max_hp'], enemy(n)['current_hp'], ep(n,'POISON_POWER'), ep(n,'STRENGTH_POWER')] for n in [277512,277513]], [[111,4,4,15],[212,212,0,0]], [277512,277513])
check('已建触媒二而当前零毒', [pp(277519,'ACCELERANT_POWER'), ep(277519,'POISON_POWER')], [2,0], [277519])
check('后得敏捷不倒补已有二十三挡', [[pp(n,'DEXTERITY_POWER'), player(n)['block']] for n in [277524,277526]], [[5,23],[6,23]], [277524,277526])
check('轮初十四挡与普通镣铐负九力', [player(278236)['block'], ep(278236,'STRENGTH_POWER','CRUSHER'), ep(278237,'STRENGTH_POWER','CRUSHER')], [14,0,-9], [278236,278237])
check('火箭背向转向及虚弱分列', [attack(n,'ROCKET') for n in [278249,278252,278254]], [[57],[38],[28]], [278249,278252,278254])
check('四敏脆弱偏折仅六挡', [pp(278255,'DEXTERITY_POWER'), player(278255)['block']], [4,6], [278255])

summary = {'streams': streams, 'physical_row_count': sum(sum(x['counts'].values()) for x in manifest),
           'selected_proofs': proofs, 'checks': checks,
           'paired_crab_t3_summary': paired_turns,
           'all_checks_passed': all(x['passed'] for x in checks),
           'scope': '仅本角色原始材料一致性核验；不是生产测试、撤源码红绿或策略收益验收'}
(OUT / 'material-verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(OUT / 'selected-states.json').write_text(json.dumps({str(n):s for n,s in states.items()},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'rows':summary['physical_row_count'], 'checks':checks, 'same_prior':all(x['same_selected_bytes_as_prior'] for x in streams)},ensure_ascii=False))
raise SystemExit(0 if summary['all_checks_passed'] else 1)

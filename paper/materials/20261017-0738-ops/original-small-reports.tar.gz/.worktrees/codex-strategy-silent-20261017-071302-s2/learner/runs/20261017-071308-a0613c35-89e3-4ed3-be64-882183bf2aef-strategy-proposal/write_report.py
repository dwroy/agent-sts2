import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]
BATCH = '20261017-071302-s2-strategy-proposal'
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)
dispatch = json.loads((OUT / 'dispatch-and-proposals.json').read_text())
verification = json.loads((OUT / 'material-verification.json').read_text())
audit = json.loads((OUT / 'source-audit.json').read_text())
assert verification['all_checks_passed']
assert all(x['same_selected_bytes_as_prior'] for x in verification['streams'])
base = audit['base']

details = [
    {
        'id': 'silent-proposal-c20b5139dd0dff71',
        'location': 'DUZUBAJ3A8GP / F27 / T4—T5',
        'evidence': 'states 274830—274833污染0→3→3→6，能力没有增加污染；274834火花6且污染清零，274836—274838技能逐次增加6污染。',
        'existing': 'combat-plan读取现场vitalSpark，turn-solver按技能增加污染并逐攻击段计价，rollout包含VITAL_SPARK_POWER增长；1698adc96的资源比较只输出模型预测。',
        'reason': '火花3→6及污染增量已核；缺该局成长、技能挡/毒收益和完整候选的联合消费者回放。现有逐击模型只覆盖子项，不能把整项记为duplicate。',
        'counterexample': '技能也会提供格挡或毒；污染增加不等于所有技能都应少打。未执行替线没有完整胜负。',
        'behavior': '保持当前选线；后续逐步分列技能收益、污染逐击血价及实际派发，不设置禁技能规则。',
        'validation': '冻结现场火花3/6、弱、挡、毒及完整候选，比较当前turn-solver→rollout→候选展示→实际动作的逐步结果，覆盖技能与能力的差别。',
    },
    {
        'id': 'silent-proposal-ae9e692d680e3819',
        'location': '5PM6JAQG6FNQ / F39 / T4—T6',
        'evidence': 'states 274351/274352/274354敏捷−4→−2→0；274357→274358失落退场，力量−4→0；274362遗忘又夺2敏。',
        'existing': '现场负力量、负敏捷进入牌值；combat-plan将POSSESS_STRENGTH_POWER/POSSESS_SPEED_POWER识别为已知能力，但这不是逐来源返还账。',
        'reason': '返4力及再次夺2敏已核；缺逐敌来源被夺量真值、退场返还与重抢的完整消费者校准，不能由当前总属性推出每个来源返还量。',
        'counterexample': '仅一次步法仍为负敏；原稿末试毒杀失落后仍不足以承受遗忘19攻击，不能推出固定优先杀谁。',
        'behavior': '保持原候选与目标选择；后续按来源分账抢夺/返还，来源不明时保留未知。',
        'validation': '固定两敌身份、初始力敏、每次抢夺与毒杀/退场时点，核多来源和再次抢夺；需当前消费者与实帧的连续对照。',
    },
    {
        'id': 'silent-proposal-52f1e1bd2e7db0ed',
        'location': 'CA5KE8GFJ9X2 / F13 / T1—T5',
        'evidence': 'states 273237/273252/273263力量0→4→8；原提案喷水11/15/19、弱后11/14，覆甲9/9/8/7/6只作现场记录。',
        'existing': 'monster-db.nearestAscension优先精确进阶；房间成本仍为独立ROOM_COST_MIN_N=5，没有把五样本门槛加到怪物HP/攻击。',
        'reason': '两次加压各加4力已核；缺原运行实际移动表的冻结输入、完整覆甲减层条件及联合消费者校准。当前数据库入口存在不等于复原旧dirty运行输入。',
        'counterexample': '覆甲层数递减的现场序列不能单独确定触发条件；一次低血死亡不能拟固定房间成本。',
        'behavior': '保持当前进阶事实读取与房间五样本门槛；后续核实完整逐步模型，不写死新的房间成本或减层规律。',
        'validation': '冻结A10移动表及每步攻击/弱/覆甲状态，先校准同招成长与减层，再验证读取路径；未观察分支必须保留未知。',
    },
    {
        'id': 'silent-proposal-6dd8bbff876be528',
        'location': '5PM6JAQG6FNQ / F38 / T3—T4',
        'evidence': 'states 274308/274313同上限23的ZAPBOT力量2→4、意图17→19，274317才退场。这里不把相同enemy_id当跨召唤永久实体ID。',
        'existing': 'rollout.STRENGTH_GROWTH_POWERS包含HIGH_VOLTAGE_POWER，combat-plan读取现场力量及能力；通用成长路径已有。',
        'reason': '电击跨轮力量2→4、攻击17→19已核；召唤/实体替换后的完整消费者与另一击杀顺序的后继未验证，不从同名或同上限推继承计数。',
        'counterexample': '先杀爪牙候选35伤/损3没有完整实打；主怪中毒不代表爪牙已经退场，不能承诺保住后场HP。',
        'behavior': '保持当前候选；后续核逐实体成长和召唤替换，不给新实体继承旧计数，不设固定杀序。',
        'validation': '冻结实际召唤身份、当前进阶移动表和连续状态，分别核老实体增长、新实体入场及同名替换；另一杀序整战结果另作验证。',
    },
    {
        'id': 'silent-proposal-578e415a259e6835',
        'location': '8JRE1C4H4Z2W / F33 / 首试与第三试T2；原稿另含F17 T6、F33 T5/T11',
        'evidence': 'decisions 270216/270282完整指纹相同；原稿同轮实损3/15、本体扣10/17，多12血只多7伤。其逐轮材料仍为同一局内相关尝试。',
        'existing': 'silent-selection-audit保留答选/SL前后候选，silent-selection-dispatch只记单动作回执，hp-guard-audit保留候选预测；实际整轮字段保持null。',
        'reason': '同盘换线血价已核且原答/护栏/SL预测与单动作回执已有窄实现；仍缺完整实际执行分段及受控整战后继。原稿金刚杵→silent-0016另有旧账本归属错配。',
        'counterexample': '末试防御替换省3血少10伤并延长到T11但仍败；候选差值不自动等于实际保血。金刚杵经验不以0016作支持，0016实际记录护喉甲。',
        'behavior': '保持探索和HP护栏；后续只在可核动作与状态上认证执行片段，抽弃牌/重规划切断原候选归属。',
        'validation': '按同指纹连接原答→护栏→SL→实际派发→后继状态，区分完整候选与前缀；原稿T5及F17重规划反例必须保留。',
    },
    {
        'id': 'silent-proposal-c0767768bf6a7ab1',
        'location': 'YF0LXT1QSTGG / F48 / 第二与第三试T1；F33 SL成功为边界',
        'evidence': 'decisions 271309/271348同指纹；states 277327→277337与277366→277373分别实损0/9、敌本体扣45/38。271354提前结束候选后续，不能把预测续步登记已执行。',
        'existing': '1698adc96资源比较及silent-sl-comparison已有current_turn_prediction/candidate_forecast，execution=unverified、actual_turn_result=null明确保留。',
        'reason': '实验体同盘实际多损9且少扣7已核；整线执行、抽弃牌后继与受控整战反事实不足，不能据全败封顶拟HP惩罚或禁止探索。',
        'counterexample': '同局F33重打成功；F48第六次恢复挡续步后仍败，第四次T5又在弃牌后重规划。不能把所有SL或所有防御替换一概否定。',
        'behavior': '保持原SL规则，继续分列当前候选预测与真实派发；未来没有受控胜线不调探索系数。',
        'validation': '固定T1成对状态和候选、271354结束动作，核0/9与45/38；另核抽弃牌边界及F33成功反例，不把有限样本24/24判死当零信息。',
    },
    {
        'id': 'silent-proposal-a46bdb7fe711d79a',
        'location': 'YF0LXT1QSTGG / F48 / 末试T3—T5',
        'evidence': 'states 277512→277513：111阶段4HP/4毒/15力→212阶段212HP/0毒/0力；277519已建触媒2但零毒；277524/277526敏捷5→6、已有挡均23。',
        'existing': 'aad2700ab的silent-phase-current区分持有组件/已建能力/当前毒；1d57f9d0另列阶段参考；f3dea918传播苦无后续敏捷，不倒补先前格挡。',
        'reason': '阶段清毒、零毒触媒及敏捷取得时点已有窄实现；完整候选施毒、增段攻击、消耗额外扣血与重规划后继的联合消费者仍缺。',
        'counterexample': '前试已建毒雾或余像仍败，持有/升级毒性爆发不表示当前阶段已施放；不能以未启动毒作唯一死因或强制先铺能力。',
        'behavior': '保持排序；后续当前阶段毒/即时施毒/已结算伤害分列，缺少动作或后继时保持未知。',
        'validation': '核阶段重置、零毒额外伤害0、23挡不倒补，并对原候选至重规划和消耗扣血做完整联合校准；局部快照不作完整候选认证。',
    },
    {
        'id': 'silent-proposal-1044224808015e5c',
        'location': 'XP2SL33HT0D9 / F33 / 首与第二试T3、首与末试T1',
        'evidence': 'decisions 271992/272040、271982/272195分别同指纹；sl-attempts 939/940的T3→T4血45→36/31，敌总387→363/360；states首末T1损2/10、扣25/34。',
        'existing': '原B2/rollout门槛与未试线排名保留，已有资源比较只描述同题候选预测，未把零胜并列称为安全。',
        'reason': '双蟹T3多损5多伤3及T1多损8多伤9已核；缺同抽序完整替线与独立获胜验证，不能拟血价、禁止全部付血探索或用零胜并列证明安全。',
        'counterexample': 'T1另有手里剑力量收益；末试T2零损、T3损4涉及减力、朝向和重规划，不是单一挡牌数的效果。',
        'behavior': '保持原探索；保留即时血价、输出、成长的事实分账，规则调整仍待独立完整后继证据。',
        'validation': '先核两组同指纹当轮差值，再按run_id与结束时间留出后续独立双蟹局；同档六试不能跨训练/验证或扩大分母。',
    },
    {
        'id': 'silent-proposal-7cbc6005db712ba9',
        'location': 'XP2SL33HT0D9 / F33 / 末试T2、T4—T5',
        'evidence': 'states 278236轮初14挡，278237爪力0→−9；278249/278252/278254火箭攻击57→38→28；278255四敏脆弱仅6挡。',
        'existing': 'passive-pieces含船夹板T2=14，现有模型含临减、朝向、虚弱/脆弱和敏捷；68711002只覆盖特定爪取整，不能扩作全部组合。',
        'reason': '轮初挡、临时减力和朝向变化已核；整套条件组合及完整候选实际兑现的联合消费者未认证，单项模型存在不能关闭宽项。',
        'counterexample': '已有4敏捷、手里剑成长仍未减员并死亡；更早Silent局只作为原提案来源，本批未重读其日志，不把旧摘要冒称新核实。',
        'behavior': '保持牌序和价值权重；后续明确已有挡/新增挡、临减有效回合、朝向/弱的分别贡献与尚未结算毒。',
        'validation': '固定14+6=20、0→−9→0、57→38→28、四敏脆弱6挡等逐步原帧，接完整候选及实际派发；未观察叠层保留未知。',
    },
    {
        'id': 'silent-proposal-c59f592f1427a67e',
        'location': 'YF0LXT1QSTGG / F48、XP2SL33HT0D9 / F33 / 上述各轮',
        'evidence': '复用本批两局四组指纹/血价、实验体阶段与双蟹格挡/临减原帧；相同来源不另计支持。原稿101局、22次镣铐及50帧船夹板是原研究范围，非本批新复核范围。',
        'existing': '资源对比、阶段事实、苦无传播、候选选择审计与单动作回执的源码均为当前base及live祖先，实际整候选认证仍未提供。',
        'reason': '两局同盘血价和阶段/临减事实已核；分段实际执行、逐来源资源与完整后继联合校准仍缺，局部入口不能合并冒称整项实现。',
        'counterexample': '本局六败不否定组件价值或其他场次SL成功；路线、营火、药水无受控未选后继，不能设置避战、必休或留药阈值。',
        'behavior': '保持原行为；后续补齐实派分段与已结算资源的联合证据，历史重复支持不重记。',
        'validation': '将前述两局当发现/固定回归样本，完成候选→派发→效果→回合/阶段出口链；独立后移验证后才考虑规则参数。',
    },
]
assert [x['id'] for x in details] == dispatch['dispatch']['proposal_ids']
results = [{'id': x['id'], 'state': 'waiting', 'reason': x['reason']} for x in details]
(OUT / 'proposal-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
(OUT / 'analysis-details.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n')

intro = f'''# 静默猎手本批十项提案核验

记录时间（先date）：{stamp}。批次：{BATCH}。角色：silent。
开工dispatch HEAD=91f7cb955fe19ebd8e33ab705df688e5227bf900，工作树干净；按普通队列要求git merge --no-edit main快进到完整base={base}，无冲突。
根learn.json只读取本批，十个proposal_ids与工作树一致，reason=proposal，无proposal_repair/research_request/implementation_request。普通专题请求属于20261010另一批，未匹配，不借其work_spec或冻结数据替代本次身份。

结论：本批十项均waiting；没有新源码、知识数据、测试或行为规则改动，没有新提交、live合入或版本。已存在的窄实现仅作范围说明，不能关闭包含完整实际执行和后继验证的宽项。
以下证据、反例及限制只来自本角色派发局、原提案/账本和Silent经验；没有读取其他角色知识或以预训练事实补机制。原始Markdown十份按队列SHA逐一核验，完整原字节保存在*.original.md。

## 证据范围与验证

六局runs.jsonl均为SILENT/A10，终局层依次DUZ=30、5PM=39、CA5=13、8JRE=33、YF=48、XP=33。全部旧code带+dirty；本批没有重建当时源码/知识完整输入，当前实现的存在不证明当时预测已经正确。
共用extract_evidence.py提取八流；每流独立冻结source_size，每行保留source/line/offset/bytes/SHA和明确run身份，冲突身份不接收。总8274行：states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0。
verify_evidence.py逐行重新读取原日志物理字节，8274行SHA及JSON/身份全部核验，25项资料检查通过；这不是tsc/vitest、源码撤回红绿或新策略测试。八流选中输出SHA均与20261016-234303-s2同范围报告一致；截点增长没有增加本批支持样本。每局SL尝试不能按独立局计。
fight-plans零行只表示本次截点未选中，不表示原日志缺失。states/decisions/brain各2条无效全源原行由提取器报告，不将它们登记成本批坏帧或补造证据。没有重做旧run-plans截点；旧报告与零行初稿不覆盖。

'''
parts = [intro]
for n,x in enumerate(details,1):
    original=dispatch['originals'][x['id']]
    parts.append(f'''## {n}. {x['id']}

原提案：{original['summary']}
来源任务：{original['source_task']} → 本批strategy-proposal；证据：{x['location']}；账本：{', '.join(original['ledger'])}。
原稿：{original['proposal']}；SHA256={original['proposal_sha256']}。

支持：{x['evidence']}

现有代码/旧行为：{x['existing']}

反例及未知：{x['counterexample']}

本批处置：waiting。{x['reason']}

预期后续行为：{x['behavior']} 本批未实现该后续增量。

验证方法：{x['validation']} 未来若改源码，应保存固定输入、撤源码失败/恢复通过，再执行原沙箱完整入口。现阶段没有生产代码变更或相关红绿结果。

''')
parts.append('''## 切分、拟合、影响与回退

本批仅六个独立来源局作已观察A10发现/固定帧核验；重复SL、重派和相同物理行不扩样本。不拟合HP血价、药水价格、能力优先级、固定杀序、必休血线或SL禁止条件。动作策略的独立验证须按run_id和结束时间后移，记录换线获胜等反例，未选整战后继保留未知。
Roy-2026-10-07-learning授权允许有证据时直接修改既有人定规则；本批保留现状来自上述具体数据/联合校准缺口，不是因为原规则不可改或要求另行审批。无关角色/进阶行为没有改动。
本批影响只有可追溯材料；没有行为补丁可回退。后续源码增量按独立commit回退并保留失败原件，实合live后才编号、双通知Roy和由ops登记shipped。本批不触发live锁、知识刷新、生产自测、发布或上线通知。

## 账本归属历史问题

原578e提案把金刚杵条目指向silent-0016；当前账本0016实际为护喉甲覆甲，原稿与原ID保留，不能把它登记为金刚杵机制支持。本问题已在旧同范围报告存在，本批只再次核对归属，不声称新机制反证。交运维沿ops→watcher→Roy核转达状态，本批不代填送达/已读ACK、不改写旧claim/首证/prior/status/version/shipped或提案原文。
只经根ledger.py update给原关联条目追加本批where.proposal和note，不追加support/repeat，不新建重复账本/提案ID；已shipped条目不降为proposed。code_proposals沿用原十个CLI ID，implementation_domains=[]表示本批没有新增实现。
''')
(OUT / 'proposal.md').write_text(''.join(parts))

report = f'''# 本批回报

时间（先date）：{stamp}。十个派发提案均已逐项核验，全部waiting，无新源码或知识变更，无提交、live合入或版本。本批完成的是处置与追溯，未关闭这些提案。

完整40位base：{base}。初始干净树91f7cb955fe19ebd8e33ab705df688e5227bf900按普通批要求快进main后得到此base；本批HEAD保持base。没有需要运维兜底合入的本批补丁。

## 逐项处置

| 提案ID | 证据局/层/回合 | 状态与原因 |
|---|---|---|
'''
for x in details:
    report += f"| {x['id']} | {x['location']} | waiting：{x['reason']} |\n"
report += f'''
各原账本ID、原稿SHA、支持/反例、预期行为及验证方法完整保存在proposal.md及dispatch-and-proposals.json；逐项机器结果为proposal-results.json。code_proposals保留原十ID，不新建重复提案，implementation_domains=[]。

## 核验与限制

六局均SILENT/A10。共用入口冻结八流8274行，所有原行按offset/bytes/SHA重新读取一致，25项资料检查通过；与旧20261016-234303-s2同范围八流选中内容SHA全部相同，不新增独立支持或SL分母。fight-plans零选中只描述本截点。完整源截点、计数和原行封套在evidence/，检查详情在material-verification.json。没有从其他角色或预训练知识引入结论。

现有16个相关源码叶13个与live逐字相同，三叶差异仅旧Roy/Dai署名注释，完整diff保存source-audit.json；8个所核旧源码commit都为本base和实际live {audit['live']} 的祖先。资源比较、当前阶段事实、苦无传播、预测选择审计和单动作回执各自存在，但不提供完整候选实际执行及受控整战反事实，不把窄实现拼作宽提案implemented/duplicate。历史+dirty运行没有复原，当前live消费者不能倒证旧运行无误。

无源码改动：tests={{"tsc":null,"vitest":null,"cases":null}}；没有执行源码撤回失败/恢复通过，不冒报已有或其他树的绿。材料检查不是生产测试。未启动LLM、网络、新模拟或play，未推送、安装依赖、改运维prompt或读key/.env/游戏二进制。

只经根ledger.py update追加本批报告追溯，by=learner:strategy-proposal；不追加旧样本支持、不改已发布状态，实际结果见ledger-update.*与ledger-receipt.json。根learn/队列/请求未修改，其他并行记录保持。

旧578e金刚杵→0016归属错配已再次注明；0016实际覆甲，不是金刚杵证据。请运维沿原ops→watcher→Roy核通知交付，本批不代填ACK，不称新发现或机制反证。原稿、旧失败与历史状态保留。

一次只读schema检查把非战斗combat=null当字典而TypeError退出，随后按可空结构修正读取；未写产品或证据，原异常记录在inspection-error.txt。资料核验先完成21项，补查沙虫实际血价、双蟹第三轮扣血、SL成功反例和电击退场四项后共25项通过，原21项输出另存.r1；没有把检查异常当生产失败或覆盖旧报告。

最终工作树、材料保密扫描与产物SHA记录分别见final-worktree.json、gitleaks.*和artifact-manifest.json；未作提交前测试/扫描的虚假声明。回收交原调度器，本批不清理自身或未完成研究。

交运维提案路径：{OUT / 'proposal.md'}
报告路径：{OUT / 'report.md'}
最终结构化结果：report.json。
'''
(OUT / 'report.md').write_text(report)
final = {'task':'strategy-proposal','character':'silent','batch':BATCH,'base':base,
         'runs':dispatch['dispatch']['runs'],'fixes':[],'skipped':[],'merged':None,
         'tests':{'tsc':None,'vitest':None,'cases':None},
         'code_proposals':dispatch['dispatch']['proposal_ids'],'implementation_domains':[],
         'proposal_results':results,'report':str(OUT/'report.md')}
(OUT/'report.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
(OUT/'inspection-error.txt').write_text('只读schema检查原输出：STATE_KEYS已输出；初始非战斗state.combat=null。\nTraceback (most recent call last):\n  File "<stdin>", line 4, in <module>\nTypeError: \'NoneType\' object is not iterable\n后续只读检查以if state.get("combat")过滤后成功。未修改原日志、产品源码或旧报告。\n')
print(json.dumps({'proposal':str(OUT/'proposal.md'),'report':str(OUT/'report.md'),'results':len(results),'base':base},ensure_ascii=False))

import pathlib,json,hashlib,subprocess
P=pathlib.Path(__file__).resolve().parent;ROOT=P.parents[2]
checks=[]
def check(name,condition):
 checks.append({'check':name,'ok':bool(condition)})
 if not condition:raise AssertionError(name)
prefix=json.loads((P/'lesson-prefix-before.json').read_text());h=hashlib.sha256()
with (ROOT/'notes/lessons.md').open('rb')as f:
 remaining=prefix['bytes']
 while remaining:
  b=f.read(min(1048576,remaining));h.update(b);remaining-=len(b)
 check('旧复盘前缀字节未改动',h.hexdigest()==prefix['sha256'])
 tail=f.read()
draft=(P/'lesson-draft.md').read_bytes()
check('新局小节完整单次追加',tail.count(b'## CVJ4MLQF4CSY')==1 and draft in tail)
# Read cited numeric evidence back from original streams by byte offsets.
S=[json.loads(x)for x in(P/'states.jsonl').open()];SI=[json.loads(x)for x in(P/'states-index.jsonl').open()]
D=[json.loads(x)for x in(P/'decisions.jsonl').open()];DI=json.loads((P/'decisions-index.json').read_text())
R=json.loads((P/'CVJ4MLQF4CSY-resources.json').read_text())
selected={z['line']for c in R['combats']for z in [c['entry'],c['last'],c['exit']]if z}
selected.update(range(431120,431126));selected.update([430848,430905,431030,431036,431099,431104,431037,431041,431105,431109])
original={};manifest=[]
with (ROOT/'logs/states.jsonl').open('rb')as f:
 for row,ix in zip(S,SI):
  if ix['line']not in selected:continue
  f.seek(ix['offset']);raw=f.readline();actual=json.loads(raw)
  check('原状态字节回读s'+str(ix['line']),actual==row)
  original[ix['line']]=actual['state'];manifest.append({'source':'states.jsonl','line':ix['line'],'offset':ix['offset'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
chosen=[416715,416996,417147,417162,417165,417166]
with (ROOT/'logs/decisions.jsonl').open('rb')as f:
 for row,ix in zip(D,DI):
  if ix['line']not in chosen:continue
  f.seek(ix['offset']);raw=f.readline();check('原决策字节回读d'+str(ix['line']),json.loads(raw)==row)
  manifest.append({'source':'decisions.jsonl','line':ix['line'],'offset':ix['offset'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
check('死亡回合与入口血量',original[431077]['run']['current_hp']==67 and original[431125]['turn']==7 and original[431125]['run']['current_hp']==0)
check('末态现有挡与敌血',original[431124]['combat']['player']['block']==13 and [e['current_hp']for e in original[431125]['combat']['enemies']]==[50,262])
check('第3试首轮实际多损9',original[430848]['run']['current_hp']==58 and original[430905]['run']['current_hp']==49)
check('末次改线实损20而前次15',original[431036]['run']['current_hp']==21 and original[431104]['run']['current_hp']==16)
# Independently recompute summary numbers used in the appended section.
J=[d for d in D if d['decider']=='jev'];Q=[d for d in J if d['label'].startswith('combat/plan-choice')]
check('Jev次数与低信心',len(J)==214 and sum(d.get('confidence') is not None and d['confidence']<.35 for d in J)==26)
check('推演最佳分母',len(Q)==193 and sum(d.get('rollout_best_chosen')is True for d in Q)==170 and sum(d.get('rollout_best_chosen')is False for d in Q)==16)
check('药水饮用次数',sum((d.get('chosen')or{}).get('action')=='use_potion'for d in D)==24)
check('药水新获得次数',sum(len({tuple(x)for x in e['to']['potions']}-{tuple(x)for x in e['from']['potions']})for e in R['resource_changes']if not e['restart_boundary'])==14)
(P/'source-readback-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(P/'postwrite-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print('原日志回读与追加校验通过：',len(checks),'项；原始证据行',len(manifest),'；无数字勘误。')

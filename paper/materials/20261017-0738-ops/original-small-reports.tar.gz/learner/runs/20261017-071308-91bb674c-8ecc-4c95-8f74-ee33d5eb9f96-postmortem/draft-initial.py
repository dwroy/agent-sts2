import pathlib,json,collections,datetime
P=pathlib.Path(__file__).resolve().parent
D=[json.loads(x)for x in(P/'decisions.jsonl').open()]
S=[json.loads(x)for x in(P/'states.jsonl').open()]
R=json.loads((P/'CVJ4MLQF4CSY-resources.json').read_text())
A=json.loads((P/'analysis.json').read_text())
names={e['enemy_id']:e['name'] for r in S for e in(r['state'].get('combat')or{}).get('enemies',[])}
pnames={p['potion_id']:p['name']for r in S for p in r['state']['run'].get('potions',[])if p.get('occupied')}
def belt(b):return '、'.join(str(slot)+':'+pid for slot,pid in b)or'空'
def hms(t):return t.split('T')[1].rstrip('Z')
def vec(xs):return '、'.join(map(str,xs))
text='''\n## CVJ4MLQF4CSY（A10，静默猎手，第48层，死于三幕首boss女王 QUEEN／火炬头聚合体 TORCH_HEAD_AMALGAM：六试均67/68血、槽0毒药水与槽2马萨雷斯的赠礼进场；前五试T8／T8／T8／T10／T10判死读档，末试T7以1血13挡及回合末6挡对21攻击归零，完整需损2、维持该末态存活至少差2血，两敌仍262／50血，未到F49）
- [构筑主轴必须在可活窗口内实际兑现；打法（DeepSeek构筑，实际为Codex；Jev出牌／代码末轮选择）] F33取群蛇形态 SERPENT_FORM，F34计划把它与音乐盒 MUSIC_BOX的零费攻击配合，F36买灵动步法 FOOTWORK、F46又取灵动步法+；但女王 QUEEN／火炬头聚合体 TORCH_HEAD_AMALGAM末试两张步法均未建立，敏捷只有闪亮口红 SPARKLING_ROUGE的1。群蛇T1已在手却直到T7才由代码least-loss打出，只剩1血；永冻冰晶 PERMAFROST补7挡，随后生存者 SURVIVOR补6挡、触发4点群蛇伤却只使女王格挡20→16，没有扣本体HP，仍死亡。这是“主轴未在生存窗口兑现”的重复，不由此规定能力一律先打或声称早建即可获胜。证据d416761、p3918／3921、d417131／417162—417165及s431077／431120—431125。（之前学过：silent-0057，S1.exp188／V4-R301）
- [死亡样本相同的SL换线仍须支付格挡与成长的血价；打法（代码SL，Jev原答另列）] 女王 QUEEN／火炬头聚合体 TORCH_HEAD_AMALGAM第3试T1，SL把第2试带究极防御 ULTIMATE_DEFEND的原线改为省掉它；两试首轮已见扣敌均43，玩家67→58与67→49，实际多损9、没有多扣血。末试T4又把Jev以0.89选择的灵动步法+ FOOTWORK改成匕首雨 DAGGER_SPRAY、打击 STRIKE_SILENT、回响斩击 ECHOING_SLASH及计划中的音乐盒复制：同题两线五轮均8/8死亡，预测损11→20、伤27→84、持久价值8→0，不能称为已证更安全。真实只执行三张攻击，整轮扣敌60而非84；相同起点的第5试T4先建步法再接攻击，扣敌55、损15，末试扣敌60、损20，实际多5伤也多损5，之后T7死亡，而第5试到T10才判死。两个后继并非单变量整战对照，不能说保留步法就能赢。证据sl2360／2363、d417147及s431030—431036／431099—431104。（之前学过：silent-0079，S1.exp203／V4-R322）
- [先结束聚合体仍不等于已经完成女王本体；打法（Jev出牌／代码SL目标与终局核对，支持旧观察）] 第4／5试均在T9末至T10开场先让火炬头聚合体 TORCH_HEAD_AMALGAM退场，女王 QUEEN在T10首帧仍162／110血、末可见128／95血，玩家仅3／4血，随后判死；第5试T1背刺+ BACKSTAB及致命毒药+ DEADLY_POISON改打聚合体，第2轮毒药水 POISON_POTION再给女王，并没有只打一个目标。末试沿该参考路径到T4才偏离，T7结毒后仍女王262、聚合体50，均未结束。focus候选、SL参考目标和实际击杀分别记录；这局没有胜利顺序对照，不从先退场的爪牙或模型排序制定统一首杀目标。证据sl2361—2363、s431003—431004／431072—431073／431125，承接silent-0090的条件化观察，记support而非重犯。（之前学过：silent-0090，S1.exp187／V4-R299）
- [记录] runs.jsonl:812明确SILENT、A10、victory=false、floor=48，code字段原值为current，不能据此倒推源码。run-config两段实际启动代码分别5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922+dirty（15:25:44.698Z）与f1a334a372c9ea63fdfda78378a83f36b317d42b+dirty（20:13:45.626Z）；当前只读live核为c7eadf02a06985d9120b1a1c9a60847cccc1adaa。启动dirty知识全量历史输入未记录。唯一run笔记notes/run-1017-0649-CVJ4MLQF4CSY.md已读；逐局抽取918条决策d416249—417166、1056帧状态s430070—431125、13条计划p3909—3921、8条SL记录sl2356—2363及48条brain。deepseek-reasoning在首末决策时间窗内0条，文件末条早于本局；实际48次大脑请求均accepted的Codex／gpt-6.1-sol／xhigh，DeepSeek实际调用0。下文沿任务的“DeepSeek”栏目记实际Codex决定，不凭旧ds_*字段制造DeepSeek引文。

  实盘资源链如下，时间全部为2026-10-16 UTC；s为logs/states.jsonl物理行。HP净变包含所有已见自伤、回血及敌伤，不能称敌人总伤害。药槽按实际index，空槽不挪号；“末见”不等于实际离场。战序1—19均由奖励／后继状态核实获胜，20—26是同一F48战斗的六次尝试与一个重启片段，不是七场独立战斗。

|战序／层／敌人ID|进场→退出或末见HP；max HP|净HP变化|进场→退出或末见药槽|状态行及时间|
|---|---|---|---|---|
'''
for c in R['combats']:
 e=c['entry'];z=c['exit']or c['last'];ex=c['exit'] is not None
 union=set(c['enemies'])
 for ob in c['enemy_hp_audit']['observations']:
  union.update(x['enemy_id']for x in(ob.get('enemies')or[]))
 if c['sequence']==23:net='未记录（重启断片）'
 elif ex:net=f"{z['hp']-e['hp']:+d}"
 else:net='未记录（SL截断）'
 text+=f"|{c['sequence']}／F{c['floor']}／{'、'.join(sorted(union))}|{e['hp']}→{z['hp']}{''if ex else'（末见）'}；{e['max_hp']}→{z['max_hp']}|{net}|{belt(e['potions'])}→{belt(z['potions'])}|s{e['line']}→{z['line']}；{hms(e['ts'])}→{hms(z['ts'])}|\n"
text+='''
  上表敌人中文名来自本局状态：'''
text+='；'.join(names[k]+' '+k for k in sorted(names))+'。\n'
text+='''
  第4试的重启边界必须单列：s430947是该次T1，s430964仍T3、56血；重启后第一帧s430965已经T3、56血空药，女王349→340的9点变化缺对应动作帧，不补归任何牌。resource_chain按SL元数据的started_at切成战序23／24；sl2361只保留重启后的T3—T10摘要，不能把“重启后首帧不是T1”说成又一次SL或新进场回血。其他战段首帧均T1，但重打首帧两敌已202／410，早于该帧的开场伤害动作未逐次记录。F48前五试都没有实际离场／死亡结算帧；SL恢复依次3／3／6／3／4→67血，并恢复原槽0毒药水、槽2赠礼，属于五次恢复，不记回血或十瓶新药。

  关键进场资源追溯：F2—5四场赢战56→56→54→49→47，F6事件回复47→57（s430177→430178）；F9升级咕嘟冒泡不回血，F11／12赢后57→54→50，F13升级中和也不回血，F16休息50→70才进瀑布巨兽 WATERFALL_GIANT。F17赢70→36，F18先古入口36→63（s430327→430328）；F19赢63→59，F21／22／25三场赢59→44→38→24。F24升级带毒刺击没有补血，F27休息24→45、F29休息45→66（s430478→430479、430485→430486）；F30与F31两场赢均66→66，F32升级斗篷与匕首，故F33知识恶魔 KNOWLEDGE_DEMON入口仍66。F33赢66→31，F34先古入口31→62（s430615→430616）；F35赢62→62，F37赢62→61并最大HP70→68，F39挑战战赢61→61。F40升级步法、F42升级药瓶均不回血；F44问号开出构装体赢61→47并喝掉槽1缚魂，F46咬人卷轴赢47→47、原两药保留，F47休息47→67（s430778→430779），才以67/68和两药进F48。赢的F44／46不能省掉；没有F49实盘入口，也没有“前场留药／少掉血即可过女王”的受控证据。

  关键战斗逐轮账：数组按实际回合顺序。“需清本体HP”只指该轮首帧活体HP，不含格挡、未来回血、增援或超额伤害；“已见扣血下界”由逐体状态比较，包含毒和自动效果，不是卡牌伤害总和。净血损为本轮首帧至下一轮首帧／真实退出的HP差；SL末轮未知。状态帧归属的自动伤在边界前后可能不同，不用不同列相减冒充逐牌兑现。

|战序／层／回合范围|每轮需清本体HP|每轮已见扣血下界|每轮净血损|
|---|---|---|---|
'''
byseq={x['sequence']:x for x in A['combats']}
for c in R['combats']:
 if c['floor']not in [17,33,44,48]:continue
 ts=c['enemy_hp_audit']['turns'];need=[t['live_enemy_hp_start']if t['live_enemy_hp_start']!=999999999 else'阶段哨兵'for t in ts];loss=[t['visible_enemy_hp_loss_lower_bound']for t in ts]
 tr=byseq[c['sequence']]['turns'];hp=[]
 for j,t in enumerate(tr):
  if j+1<len(tr):hp.append(t['start']['hp']-tr[j+1]['start']['hp'])
  elif c['exit']:hp.append(t['start']['hp']-c['exit']['hp'])
  else:hp.append('未记录')
 text+=f"|{c['sequence']}／F{c['floor']}／T{ts[0]['turn']}—T{ts[-1]['turn']}|{vec(need)}|{vec(loss)}|{vec(hp)}|\n"
text+='''
  边界核验：瀑布巨兽T4出现3血回升，T10→T11转入999999999血的阶段哨兵，不能把该数当需打十亿伤；T11为55血、25现有挡对44攻击，实际损19至36并胜（sl2356）。知识恶魔T4／T8分别观察回升22／30；初始399之外额外52已见回血，末轮73中只见扣18后移除，余55缺归零帧，完整逐击总伤未记录。F44两个方柱构装体同ID，逐体对齐存在歧义，T1下界29不代表整轮只造成29，实际活体合计200→89；T3／T5最后本体归零帧缺失。F48第4／5试聚合体退场均缺独立归零帧，不能把消失前的31／2血补成可见伤害。末试两敌无回血或移除，首帧612→末312，七轮可见扣37＋24＋47＋60＋43＋56＋33＝300；630为两敌最大HP合计，不能把缺本次开场动作帧的18点也算作已逐步核到的手打伤害。按七轮清本次首帧612的回溯裸HP平均需87.4286／轮，实际可见42.8571／轮，尚差312；这不是事前boss时钟，未包含女王反复建立的格挡。

  末轮死亡核：s431120为1血、聚合体21攻击、女王增益／格挡动作；群蛇得7挡，生存者再得6挡，丢弃咕嘟冒泡后留两张魂缚牌。sl2363的原规则判断明确“21 incoming vs 1 HP + 13 block + 6 end-of-turn block”，故完整需损21−13−6＝2，维持此末态存活需至少3血、比现场多2。实际归零只扣剩余1，不能报敌实打2；死亡帧显示聚合体14攻击，玩家减益已清空，不用事后14回填死前21。代码least-loss的预计剩HP−2与规则末态缺口分列，不拿差值单独定纯bug。F48首五试SL结果predicted_death，末试died；不将五次拦截当五次实死。

  Jev与代码：Jev214次，信心<0.35共26次，其中F48有16次。193道combat/plan-choice类题中rollout_best_chosen真170、假16、无值7；有值分母170/186＝91.40%，总题分母170/193＝88.08%。代码初排rank1仅70/193＝36.27%，不是推演最优比例。HP护栏、SL、抽弃／生成重问之后，完整最优候选实际执行比例未记录。原decider=code有638条，内含277条“继续Jev所选方案”；拆开后code自主361、jev-plan277、jev214、codex66，与局报一致。代码自主战斗动作204条，至少含一次自主决定的（层／SL标记／回合）键123个，不是123个完整回合均由代码独打。

  HP护栏共替换2次：F33T2 d416715原刀刃之舞 BLADE_DANCE、蛇咬 SNAKEBITE与三刀线预测损13／伤28，替为究极防御加蛇咬预测损0／伤10，预计省13但少18伤；实际该轮HP66不变、毒扣10，可核这条替线的局部结果。F48第2试T8 d416996原线预测损2／伤77，替线预测损0／伤101，预计省2且多24伤；实际先妙计 FINESSE、再打击、步法、刀刃之舞，重问后判死，三刀及复制打击未完整执行，末见只扣12、HP仍3，不能登记101伤或已实省2。两次候选预测合计省15、伤害差净+6仅是审计算术，不是实盘收益。当前live combat-plan.ts:4490为护栏替换入口，本局不由规则依既定条件工作就指为bug。

  focus共100道题有具名映射，按F22／25／31／35／44／48分别3／7／4／1／6／79；原答选中映射35次，分别2／2／2／1／4／24。它是候选属性，不是100次独立集火指令。F22先石、再丝、后甲虫；F31蜜／石同次匕首雨后均退场、内部先后未知，卵最后；F35活体盾先、高塔炮手后。F44先一方柱、再拳击、最后另一方柱，同ID个体只按已见退场段记。F25先处理卵与幼虫再收产卵虫，全部重复个体的严格杀序未记录。终战第4／5试聚合体先退，其余尝试末可见两敌都在，不把focus或未来推演顺序当实际击杀。

  药水：实拿14瓶，跨尝试实际饮用24次，丢弃0次；五次SL恢复的十瓶外观不记新获得。下表获得、饮用分别由槽位变化及chosen.action=use_potion核对，时间为UTC；表内同ID的两瓶火焰／缚魂按先后来源分别记。

|获得层／槽位／中文名与ID／状态证据|实际饮用层回合、决策行与时间|
|---|---|
'''
acqs=[]
for e in R['resource_changes']:
 if e['restart_boundary']:continue
 old={tuple(x)for x in e['from']['potions']}
 for slot,pid in e['to']['potions']:
  if(slot,pid)not in old:acqs.append((e,slot,pid))
for j,(e,slot,pid)in enumerate(acqs):
 until=next((x['to']['ts'] for x,sl,pp in acqs[j+1:]if pp==pid),None)
 uses=[(416249+i,d)for i,d in enumerate(D) if(d.get('chosen')or{}).get('action')=='use_potion'and(d.get('expect')or{}).get('potion',{}).get('id')==pid and d['ts']>=e['to']['ts'] and(until is None or d['ts']<until)]
 rhs='；'.join(f"F{d['floor']}第{d.get('sl_attempt')or1}试T{d['turn']} d{ln}（{hms(d['ts'])}）"for ln,d in uses)or'未记录'
 text+=f"|F{e['to']['floor']}／槽{slot}／{pnames.get(pid,'中文名未记录')} {pid}；s{e['from']['line']}→{e['to']['line']}，{hms(e['to']['ts'])}|{rhs}|\n"
text+='''
  初始两瓶由药瓶皮套 PHIAL_HOLSTER获得；异鱼之油FYSH_OIL为F15商店购买，毒药水为F36商店购买，澄澈CLARITY为F28事件选普通不明药补充，赠礼MAZALETHS_GIFT为F39挑战获胜后事件补充，其余为奖励。缚魂POTION_OF_BINDING第2瓶确实F44T2喝掉；F46没有饮用或补药，F47也未补药，F48仅带槽0毒药水及槽2赠礼。毒药水前四试T1给女王、后两试T2给女王；赠礼六试均T1喝。只是实盘资源账，不由此提出换药价、强制喝药时点或留药反事实。

  大脑构筑／路线／休息：F2取带毒刺击 POISONED_STAB、F3取咕嘟冒泡 BUBBLE_BUBBLE、F4取斗篷与匕首 CLOAK_AND_DAGGER，F11取匕首雨、F12取尖啸 PIERCING_WAIL，F14选回响斩击，F15买后空翻 BACKFLIP并删打击；F17取萎靡 MALAISE，F20融合两防御，F23选蛇咬与刀刃之舞，F25取暴露 EXPOSE；F33取群蛇，F34选音乐盒；F36买步法、弹跳药瓶 BOUNCING_FLASK及妙计，F37取致命毒药+，F46取第2张步法+。10次营火，F16／27／29／47四次休息，F9／13／24／32／40／42六次锻造，升级对象依次咕嘟冒泡、中和、带毒刺击、斗篷与匕首、步法、药瓶。F1路线原话“前期战斗补输出，三火兼顾血量升级，单精英加商店补强。”；F18“持续增能支撑抽牌与萎靡，四火路线保血补强。”；F34“音乐盒复制零费攻击，双店三火补强避精英。”，均在d416251／416498／416764可查。F37改线避开钱不足的商店，保留三火、无精英目标；F40／42都只缺7血而选升级；F47才选回复67/68。p3921要求安全建立步法、萎靡聚合体并把毒集中女王，实际晚建、目标及SL偏离见前三条，不改写为大脑曾承诺一定获胜。

  路线预测与boss时钟：F9题面中位投影F12入口36、F17入口70，实际54／70；原远端休息假设和F13实际锻造不同，不能把差值全归战斗成本。F24投影F25入口38、F33入口70，实38／66；其后F27／29实际回复各21、F30／31零净损，F32实际锻造不补最后4血。F42投影F47入口49、F48入口68，实47／67；中间问号F44确实多打一场并净损14，F46净损0，不能省掉这场赢战。F47所选休息候选明确67血投影、实67，而act_boss_sim的基线entry_hp=47是未休息参考，不能混作所选预测。该候选连续通关显示4%、400样本、赢局损血中位59、约28回合，明确低可信且未校准两战；本局没有第二战，不能拿末试7轮直接校准这个仅赢样本回合数。旧boss时钟数值需伤／估伤及实打／估值比未记录；p3917／3921也明说伤害缺口未知，不能补零。所有裸HP回溯平均与事前模拟分列。

  机制：均为既有机制的本局条件观察，无新增机制条目。末试力量T3—T7实际3／4／5／6／7，仪式RITUAL_POWER为1、口红在T3另加1力量1敏捷；有虚弱时T6小刀SHIV牌面7，不能把力量层数直接当整轮输出。两张步法末试未建立，敏捷始终1；第5试T4首张步法建后1→4、T8第二张后4→7，在脆弱下后段挡牌效果要按实际文本。第5试与末试T5的生存者实得8／6挡，差2可见，但其他行动也变，不能把后续血差全归敏捷。末试T7群蛇建立4层，本身不打4伤；永冻独立给7挡，随后生存者得到6挡，群蛇触发只削女王4格挡，未扣HP（既有silent-0132／0173）。女王的99虚弱／易伤／脆弱在T3已在场，魂缚CHAINS_OF_BINDING_POWER使末轮剩余中和与回响斩击在生存者后被blocked_by_hook，不能把0费等同仍可执行（既有silent-0069）。聚合体T6受尖啸临时减力到−4、光束4×3＝12，下一轮减力恢复并有增益后力量3、单击显示21；不能把当轮减力沿用到下轮。律动残余BEATING_REMNANT的20单回合失血上限在T3／T4都实损20，仍把末次67血耗至1，末轮需损2时不构成免死（既有silent-0031）。末战未取得或建立触媒ACCELERANT，毒按本局实际单次结算；末轮女王26、聚合体7毒实扣26／7，不能预支额外结毒。

  用时／token／缓存：首末决策15:26:50.261Z—22:49:02.884Z，26532.623秒＝442.2104分钟；从首run-config启动到结局26598.186秒，包含中途重启和等待，纯战斗／模型等待各自墙钟未记录。Jev214次输入2335760、输出13410，合2349170＝runs.tokens，累计Jev延迟126857毫秒；Jev缓存命中未记录，缺字段不填0。48次Codex输入9155412、输出60284（推理53585）、缓存5025536，输入缓存率54.89%，累计请求延迟1861626毫秒；其中独立run-plan两次输入300612／输出4449／缓存139648已在合计里，不重复加。局报Jev约$0.0987为估算，实际账单未记录。

  未记录的限制还包括：完整dirty知识输入快照；前五次F48实际离场与死亡结算；重启片段的9点扣血来源；重复敌人ID与部分退场尾刀的完整逐击毛伤／格挡伤及来源归属；完整最优线实际执行比例；原护栏／SL／更早建能力、不同击杀顺序／药水时点／休息路线的受控整战结果；旧boss时钟需伤／估伤、实打／估值比及F49真实资源与结果；Jev缓存和实付费用。三条分别向silent-0057追加repeat、silent-0079追加repeat、silent-0090追加support，保留原claim、first_run、prior、status、version；经独立strategy-proposal接续，不声称新规则已实现或shipped。
'''
(P/'lesson-draft.md').write_text(text)
(P/'append-lesson.sh').write_text("#!/bin/bash\nset -eu\nif rg -q '^## CVJ4MLQF4CSY' /home/dw/Projects/agent-sts2/notes/lessons.md; then exit 3; fi\ndate\ncat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+text+"EOF\n")
print('draft bytes',len(text.encode()),'acquisitions',len(acqs),'section headings',text.count('\n## '))

import json,pathlib,collections,datetime
P=pathlib.Path(__file__).resolve().parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
S=[json.loads(x) for x in (P/'states.jsonl').open()]
I=[json.loads(x) for x in (P/'states-index.jsonl').open()]
R=json.loads((P/'CVJ4MLQF4CSY-resources.json').read_text())
byline={i['line']:s for i,s in zip(I,S)}
def powers(p):return {x['power_id']:x['amount'] for x in p.get('powers',[])}
def slim(row):
 s=row['state'];c=s.get('combat')or{};return {'hp':s['run']['current_hp'],'max':s['run']['max_hp'],'t':s.get('turn'),'p':powers(c.get('player')or{}),'block':c.get('player',{}).get('block'),'enemies':[(e['enemy_id'],e['current_hp'],e['block'],powers(e),e.get('move_id'))for e in c.get('enemies',[])]}
O={}
O['combats']=[]
for c in R['combats']:
 rows=[(i['line'],s)for i,s in zip(I,S) if c['entry']['line']<=i['line']<=(c['exit']or c['last'])['line']]
 turns=[]
 for ln,r in rows:
  t=r['state'].get('turn')
  if not turns or turns[-1]['turn']!=t:turns.append({'turn':t,'first':ln,'last':ln,'start':slim(r),'end':slim(r)})
  else:turns[-1].update(last=ln,end=slim(r))
 O['combats'].append({'sequence':c['sequence'],'floor':c['floor'],'turns':turns})
O['potions']=[]
for event in R['resource_changes']:
 if event['from']['potions']==event['to']['potions']:continue
 t=event['to']['ts'];prior=[(416249+i,d)for i,d in enumerate(D) if d['ts']<=t]
 near=prior[-2:]
 O['potions'].append({'from':event['from'],'to':event['to'],'restart':event['restart_boundary'],'decisions':[(ln,d['label'],d.get('chosen'),d.get('expect'),d['ts'])for ln,d in near]})
O['resource_noncombat']=[e for e in R['resource_changes'] if e['combat_sequence'] is None and e['from']['hp']!=e['to']['hp']]
O['stats']={'low':sum(d['decider']=='jev' and d.get('confidence')is not None and d['confidence']<.35 for d in D),'jev_combat':sum(d['decider']=='jev' and d['label'].startswith('combat/plan-choice')for d in D),'rollout':dict(collections.Counter(str(d.get('rollout_best_chosen'))for d in D if d['decider']=='jev' and d['label'].startswith('combat/plan-choice'))),'latency':{k:sum(d.get('latency_ms',{}).get(k,0) for d in D) for k in ['jev','deepseek']}}
code=[d for d in D if d['decider']=='code' and not d['rationale'].startswith('continuing the Jev-chosen plan')]
O['stats']['code']=len(code);O['stats']['code_combat']=sum(d['screen']=='COMBAT'for d in code);O['stats']['code_turns']=len({(d['floor'],d.get('sl_reloads'),d.get('sl_attempt'),d['turn'])for d in code if d['screen']=='COMBAT'})
O['stats']['jev_plan']=sum(d['rationale'].startswith('continuing the Jev-chosen plan')for d in D)
O['stats']['jev_f48_low']=sum(d['decider']=='jev' and d['floor']==48 and d.get('confidence')is not None and d['confidence']<.35 for d in D)
O['stats']['usage']={who:{k:sum(d.get('usage',{}).get(k,0)for d in D if d['decider']==who)for k in ['input_tokens','output_tokens','cache_hit_tokens']} for who in ['jev','codex']}
O['stats']['focus']=[{'line':416249+i,'floor':d['floor'],'t':d['turn'],'focus':d['focus'],'answers':d.get('answers'),'chosen':d.get('chosen')}for i,d in enumerate(D)if d.get('focus')]
(P/'analysis.json').write_text(json.dumps(O,ensure_ascii=False,indent=2))
print('STATS',json.dumps({k:v for k,v in O['stats'].items() if k!='focus'},ensure_ascii=False))
print('FOCUS counts',collections.Counter(x['floor']for x in O['stats']['focus']))
for c in O['combats']:
 if c['floor']not in [17,33,44,48]:continue
 print('BATTLE',c['sequence'],c['floor'])
 for t in c['turns']:
  a=t['start'];b=t['end'];print(' T',t['turn'],t['first'],t['last'],'hp',a['hp'],b['hp'],'powers',a['p'],'enemies',[(e[0],e[1])for e in a['enemies']],'end',[(e[0],e[1])for e in b['enemies']])
print('POTIONS')
for e in O['potions']:print(e['from']['line'],e['to']['line'],'F',e['to']['floor'],'T',e['to']['turn'],e['from']['potions'],'->',e['to']['potions'],'restart',e['restart'],'D',e['decisions'][-1])
print('NONCOMBAT')
for e in O['resource_noncombat']:print(e['from']['line'],e['to']['line'],'F',e['to']['floor'],e['from']['hp'],'->',e['to']['hp'],'restart',e['restart_boundary'])

本批材料准备保留：最初在 knowledge/characters/silent 下探测 code-proposals 路径不存在，随后按文档使用根专用队列；一次 stdout 将 3da1a93 经验数据祖先也称作窄源码祖先，source-audit 已逐项标 kind 并另核真正幽灵源码 96f17377；读取旧审计产物时探针假定 turn_windows 键，实际 schema 为 observed_turns，KeyError 后按真实字段读取，未修改旧产物或消费者。以上均不作为游戏反例或产品缺陷。
旧消费者计数首探针把状态名假定为observed，所得0仅属探针误标；真实状态observed_turn_endpoints/observed_endpoints的读回为144/1097。首版计数与更正分文件保留，原产物不变，未据此修改任何游戏结论。

import hashlib
import json
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
import ledger

assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
results = {v['id']: v for v in json.loads((OUT / 'proposal-results.json').read_text())}
ids = sorted({i for p in assigned.values() for i in p['original']['ledger']})
path = ROOT / 'paper/materials/learning/ledger.jsonl'

def digest_prefix(size):
    digest = hashlib.sha256()
    with path.open('rb') as f:
        while size:
            raw = f.read(min(size, 8 * 1024 * 1024))
            assert raw
            size -= len(raw)
            digest.update(raw)
    return digest.hexdigest()

def selected():
    return ledger.fold([(n, row) for n, row in ledger.read_rows() if row and row.get('id') in ids])

before_size = path.stat().st_size
before_hash = digest_prefix(before_size)
before = selected()
(OUT / 'ledger-write-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for item in ids:
    links = [p for p, value in assigned.items() if item in value['original']['ledger']]
    updates.append({'id': item, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261017-001301-s2-strategy-proposal复核：' + '、'.join(links) +
                            '均waiting；逐项缺口见本批proposal-results.json。八流选中证据与旧同范围批次相同；本次仅补追溯，不增加支持样本，不改旧claim/证据/status/version/shipped，不冒源码实现或自然采用。'})
encoded = ''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates).encode()
(OUT / 'ledger-updates.jsonl').write_bytes(encoded)
with (OUT / 'ledger-cli.stdout.txt').open('wb') as stdout, (OUT / 'ledger-cli.stderr.txt').open('wb') as stderr:
    result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                            input=encoded, stdout=stdout, stderr=stderr, cwd=ROOT)
assert result.returncode == 0, result.returncode
assert digest_prefix(before_size) == before_hash
after = selected()
(OUT / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
protected = []
for item in ids:
    a, b = before[item], after[item]
    for field in set(a) | set(b):
        if field not in ('where', 'notes', 'history'):
            assert a.get(field) == b.get(field), (item, field)
    for field in ('notes', 'history'):
        assert b[field][:len(a[field])] == a[field], (item, field)
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values, (item, key)
    assert str(OUT / 'proposal.md') in b['where']['proposal']
    assert str(OUT / 'report.md') in b['where']['proposal']
    protected.append(item)
physical = []
with path.open('rb') as f:
    f.seek(before_size)
    offset = before_size
    for raw in f:
        row = json.loads(raw)
        if row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith('20261017-001301-s2-strategy-proposal复核：'):
            physical.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                             'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        offset += len(raw)
assert len(physical) == len(ids) == len({v['id'] for v in physical})
receipt = {'command': ['python3', str(ROOT / 'learner/ledger.py'), 'update'],
           'exit_code': result.returncode, 'updates': len(updates),
           'before_source_size': before_size, 'before_prefix_sha256': before_hash,
           'prefix_preserved': True, 'protected_ids': protected, 'physical_appends': physical,
           'protected_fields': 'all fields except appended where/notes/history; old prefixes also preserved'}
(OUT / 'ledger-preservation.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit_code': result.returncode, 'updates': len(updates),
                  'prefix_preserved': True, 'protected_items': len(protected)}))

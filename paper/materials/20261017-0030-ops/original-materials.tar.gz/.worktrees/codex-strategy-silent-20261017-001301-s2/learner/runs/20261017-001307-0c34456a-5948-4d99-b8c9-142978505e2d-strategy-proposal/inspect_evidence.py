import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
RUNS = {r['run_id']: r for r in json.loads((OUT / 'verified-runs.json').read_text())}


def records(stream):
    with (OUT / 'evidence' / (stream + '.evidence.jsonl')).open() as handle:
        for raw in handle:
            yield json.loads(raw)


def ref(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def powers(items):
    return {p['power_id']: p['amount'] for p in (items or [])}


states = []
selected = {}
state_lines = set(range(285098, 285119)) | set(range(286158, 286165))
state_lines |= set(range(286890, 286901)) | set(range(286977, 286988))
state_lines |= set(range(288465, 288474)) | set(range(288591, 288598))
state_lines |= set(range(288806, 288814)) | set(range(288899, 288907))
state_lines |= set(range(288910, 288916)) | set(range(287998, 288008))
state_lines |= set(range(287976, 287986))
with (OUT / 'states-compact.jsonl').open('w') as compact:
    for item in records('states'):
        row = item['row']
        state = row['state']
        run = state.get('run') or {}
        combat = state.get('combat') or {}
        player = combat.get('player') or {}
        assert run.get('character_id', '').lower() == 'silent'
        assert run['ascension'] == RUNS[item['run_id']]['ascension']
        value = dict(ref(item), ts=row.get('observed_ts'), floor=run.get('floor'),
                     turn=state.get('turn'), screen=state.get('screen'),
                     hp=player.get('current_hp', run.get('current_hp')),
                     max_hp=player.get('max_hp', run.get('max_hp')),
                     block=player.get('block'), energy=player.get('energy'),
                     powers=powers(player.get('powers')),
                     potions=[{'index': p.get('index'), 'id': p.get('potion_id'),
                               'occupied': p.get('occupied')} for p in run.get('potions', [])],
                     enemies=[{'index': e.get('index'), 'id': e.get('enemy_id'),
                               'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                               'block': e.get('block'), 'alive': e.get('is_alive'),
                               'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                              for e in combat.get('enemies', [])],
                     hand=[{'index': c.get('index'), 'id': c.get('card_id'),
                            'cost': c.get('energy_cost'), 'playable': c.get('can_play'),
                            'upgraded': c.get('upgraded'), 'text': c.get('resolved_rules_text'),
                            'dynamic': c.get('dynamic_values')}
                           for c in combat.get('hand', [])])
        states.append(value)
        compact.write(json.dumps(value, ensure_ascii=False) + '\n')
        if item['line'] in state_lines:
            selected[str(item['line'])] = item
(OUT / 'selected-raw-states.json').write_text(json.dumps(selected, ensure_ascii=False) + '\n')

transitions = []
previous = {}
for state in states:
    before = previous.get(state['run_id'])
    if before and (before['floor'], state['floor']) in ((17, 18), (33, 34)):
        same_max = before['max_hp'] == state['max_hp']
        delta = state['hp'] - before['hp']
        prediction = (before['max_hp'] - before['hp']) * 80 // 100
        transitions.append({'run_id': state['run_id'], 'ascension': RUNS[state['run_id']]['ascension'],
                            'before': before, 'after': state, 'same_max_hp': same_max,
                            'hp_delta': delta, 'observed_missing_80pct': prediction,
                            'matches': same_max and delta == prediction})
    previous[state['run_id']] = state
(OUT / 'act-transitions.json').write_text(json.dumps(transitions, ensure_ascii=False, indent=2) + '\n')

decision_lines = {279117, 279846, 280547, 280550, 280631, 280635, 280636, 280637, 280638,
                  280639, 281953, 282021, 282138, 282434, 282436, 282449}
decisions = [item for item in records('decisions') if item['line'] in decision_lines]
(OUT / 'selected-decisions.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')
configs = []
for item in records('run-config'):
    row = item['row']
    configs.append(dict(ref(item), code=row.get('code'), restart=row.get('restart'),
                        brain=row.get('brain'), character=row.get('character'), ascension=row.get('ascension')))
(OUT / 'historical-configs.json').write_text(json.dumps(configs, ensure_ascii=False, indent=2) + '\n')

print('state_count', len(states), 'selected_raw_states', len(selected))
print('transitions', len(transitions), 'matches', sum(t['matches'] for t in transitions),
      'ascensions', dict(Counter(t['ascension'] for t in transitions)))
for item in decisions:
    row = item['row']
    print(item['line'], item['run_id'], row.get('floor'), row.get('turn'), row.get('label'),
          row.get('chosen'), (row.get('rationale') or '')[:180])

import datetime
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
BATCH = '20261017-001301-s2-strategy-proposal'
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
material = json.loads((OUT / 'material-checks.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
details = [
('03754e1265894000',
 'RC61MFQM63Y6 F23T3/T4、F33T4；states 285222—285229、285414—285415。预判后净敏1，速度药到6；后续牌使敏捷5/4/3/2/1，挡12/21/25，末次+4为折扇被动挡，不能重复按牌挡或敏捷计算。',
 '整战失败不反驳逐牌局部结算；未隔离柔嫩与脆弱/倍率/首刀等全部联合触发，持有能力不等于已经建立。',
 '保留已观察逐牌分源；若补实现，应分别核初始牌面、新增敏捷、被动挡和首次攻击消耗，再检查下一轮临时量撤回。',
 '八组件仍缺柔嫩、脆弱、倍率、首刀与折扇组合的完整固定消费者校准；本批未取得新实帧或可复现的新源码差异，不能把局部已有模型登记为整包duplicate。'),
('ab055ef7dfbb44e5',
 'XTSV1U9JD34T F49T1/T2/T4；states 286897—286899、286986—286987。幽灵实建无实体1，攻击26→1；下一轮23HP/10挡。夜魇末T4标记3，之后即GAME_OVER，没有复制到手的后继。',
 '六次同局早喝不是六个独立时点样本；旧夜魇成功经验不能证明本局绝境能活到复制回合，缺延后饮用的完整实线。',
 '幽灵已有96f17377窄源码实现；继续区分当轮血价与次轮可合法兑现的复制，不拟早喝/留药参数。',
 '单层幽灵已有真实live祖先实现；夜魇合法复制、存活后继和延后饮药的受控整战结果仍缺，不能关闭整项存活/时点提案。'),
('0129c465c6f5bd79',
 'BTSRF7JL1W1Y F31T2 states 286161—286163：生存者后突然一拳不再在手，当轮35→21；XTSV1U9JD34T F48T8 states 286893—286896：毒胜仍32→23，F49继承23HP。',
 '不能从原计划保留一张实际已被弃掉的牌；毒胜当轮持牌耗血与是否生成保血候选是两个问题。耳环接管内部动作和本局复制后继未记录。',
 '普通单弃bf423c17、毒胜保血搜索222445a9已有live祖先源码；宽范围仍需把弃牌重问、目标、接管和复制的真实执行链逐项接续。',
 '已有单弃与毒胜保血窄实现；接管内部动作、夜魇后继及跨抽弃牌重问的完整联合候选归属仍缺，不能据两个子修复整项duplicate。'),
('abe9d5d0be109a9f',
 'BTSRF7JL1W1Y F30 286112→286146：70→42，F31 286147仍42；XTSV1U9JD34T F47 286839→286841：73→97，F48 286842→286895：97→23，F49实入23。',
 '这些是所选线路的实到端点；未到营火、SL恢复药瓶、另一条路线的未来资源不能预支。没有同条件改线、留药或锻造的整场对照。',
 '按来源分别接续胜战损血、真实回复和SL恢复，下一战只使用实际资源；路线/休息消费者需用原完整输入校准后再谈参数。',
 '缺逐源路线/休息消费者校准及同条件改线、留药、锻造完整后继和独立留出，端点证据不足拟安全血线、药价或路线机会成本。'),
('f16527e59b5cc1e0',
 'BTSRF7JL1W1Y F31T2手牌/覆甲与实际损血窗口；XTSV1U9JD34T F49T1/T2幽灵和留挡、F49T4脆弱/临时减力窗口。相关原提案同时涉及毒触发、敌成长和临时属性撤回。',
 '入场属性不能跨战预支；幽灵单层和钳子上限不等于以后每轮保底。净HP端点不提供每击毛伤或每个减层来源。',
 '保持现有局部机制；验证时固定初始牌面和每步属性，按毒/持牌伤/攻击/覆甲/保留挡分别结算并核下一轮。',
 '覆甲、留挡、临时属性撤回、毒触发及敌成长仍缺共同输入下的逐源完整消费者回放；局部模型和端点不能认证整包实现或新药价。'),
('7a8e9ccb7e646538',
 '9Z9H2EXKLF3T F48末试T8 states 287989—287991：32挡、11→0→20，复活不能写成净回血9；T10 states 287998、288000、288003—288005：挡18→27→37，HP18→3。',
 '首张倍率预览不能沿用给全部后继牌；死亡后未执行击不预支反伤。多次重问和熔炉时点变化使T7局部预测/整轮差额不能作为单因整战收益。',
 '固定每张倍率消耗与逐击/复活顺序，分别保存预测、实到端点和完整候选未知；不据有限全败推演改必死或SL规则。',
 '缺未截断逐击毛伤、完整候选执行归属和同条件整战后继；同盘局部净差不足校准联合模型或修改SL血价、持有价。'),
('cd9f76184de6e29a',
 '原提案十个Silent来源局，另仅用本批其他已派原提案内的同角色来源做交叉核验。15局中F17→18/F33→34同上限端点22对，A9五/A10十七，全符合floor(缺失HP×80%)；9Z F35 66/77→30/69，F42 11→31，F47 7→27。',
 '当前血与最大HP损失分别记；22转换对不是22独立局。该边界不推广低进阶、未知遗物交互或未到节点，更不能重现原116局整套资源模型。',
 '只沿已证A9/A10同上限转换边界和真实节点分源接续；路线、休息及SL消费者保留输入来源与未知项。',
 '22对只支持已有跨幕回复观察；原116局资源模型完整输入、路线/休息消费者校准和独立路线收益仍缺，不能把窄公式当整个资源/SL请求完成。'),
('292f6731bdb9b669',
 '7X0W3U8TVA2A F31T13 decisions 282021、states 288470—288472：后段零毒→7，本体25不变，再结算到18；玩家1→0，喝后仍败。F31T1原题将该药列未模拟。',
 '这里只隔离该组合、该目标的一次总增量；无无头骨对照、其他目标、既有毒/重接或早喝整战实线，不能反推基础药效再加一次头骨。',
 '当前PotionContext只有其他已证窄范围的observedPoison，不能扩大为所有持头骨局面。未知持有价已有holdHp=null/no_value或no_table，不能当校准为0。',
 '实加7只核该后段零毒单次；缺其他目标、既有毒、重接组合的共同推演校准及持有价/用药时点证据，不能全局扩为7毒或拟合早喝规则。'),
('0802f69b28d25079',
 'MTQ0EUBJ3R6T F23四试T3，states 288806—288812与288899—288905；原三试10→10，末试10→2。速度临时5敏，两毒素各5与敌攻17合需27挡，29/19挡分别对应损0/8；末次同题预测为0损13伤与8损19伤。',
 '四次SL合一个相关样本；原线也未形成已证整战胜利，换线还改变后继抽牌、毒雾和药时点，敌残血末值不等于即时单牌收益。',
 '保留原饱和探索、必死和药价参数；若以后改排序，先用同条件整场比较即时HP缺口和后继，再用独立A10时间留出。',
 '局部多损8血/多伤6已核；缺独立A10留出及固定抽弃/药时点的受控完整后继，不能据一个相关局拟饱和探索HP门槛、权重或药价。'),
('763a4b9d9f17b815',
 '7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13与MTQ0EUBJ3R6T F11T1、F17T4—T8、F20T3、F23T2—T5为原十四机制提案范围。本批重点核7X F31T13施毒和MTQ F23T3速度5敏、两毒素及次轮临时层撤回。',
 '前战建立的步法/毒雾不能继承，属性加层不能补旧挡；本批固定材料不能声称十四项从单项到所有组合均已完成模型校准，也没有原dirty全树。',
 '各机制以已建立、已饮用和当前牌面为入口；永久/临时减力、持牌伤、能量增量与昏眩锁牌分开验收，模型未知继续显式保留。',
 '十四项机制仍缺从逐项到联合生产消费者的完整校准及部分后继；现有局部公式和材料夹具不足认证整包，保持waiting，不把经验入库当完整源码兑现。'),
]
results = [{'id': 'silent-proposal-' + short, 'state': 'waiting', 'reason': reason}
           for short, evidence, limits, behavior, reason in details]
assert set(r['id'] for r in results) == set(dispatch['proposal_ids'])
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

text = f'''# 本批十项静默策略提案复核

记录时间：{now}。批次：{BATCH}。base：{BASE}。

本批是普通代码提案消费；根learn.json的task/character/worktree及十个proposal_ids已核，无research_request、implementation_request或proposal_repair。根普通专题文件绑定另一旧批次，不承接该专题、不读取其他请求替代本批身份。开工clean，merge main返回Already up to date。只处理十个原CLI id，十份原Markdown摘要均一致；原件在本目录同名*.md，不改原文、不新增重复id。

本次没有足以依据新增实帧修改策略的结论，十项均waiting。已有窄实现与未校准的宽范围分开说明，未将提案整包登记duplicate。工作树源码、知识和记录不改，原父学习要求继续开放。

## 证据范围与方法

派发十个锚点加本批原提案内五个额外局，共15个Silent身份：A9三局、A10十二局。只读本角色原日志、提案、账本及knowledge/characters/silent。共用extract_evidence入口提取八流22,424行；逐行复核source_size边界、offset/bytes/SHA、JSON与显式run身份。冲突身份不收，正文提及不作身份。各流分别冻结，不能冒称同时快照。fight-plans在本次截点0行仅表示筛选未选中，不断言原日志缺失。

这八流的选中封套SHA与20261016-004302-s2相同；本批15局没有新增所属行，不能算新增独立样本或扩大支持分母。31项材料断言通过，只核原帧与算术，不是生产测试。六个旧离线消费者的输入重建SHA、旧输出/错误SHA及递归六个当前依赖源码均核相同，复用原结果，不重跑消费者/模型/模拟。1627状态、1530带ID决策、447候选段；447个完整候选结果仍全部null。这个null是归属认证边界，不倒推实际未执行。

当前经验仅截取41个原提案关联条目，不重算其全历史统计。46个既有账本补本批追溯时只用根ledger CLI，保护原claim、首证、prior、evidence、status、version、shipped、effect及旧history/notes/where前缀；不追加重复support/repeat、不把shipped降为proposed。来源任务沿各原提案，当前实现任务为strategy-proposal；既有Roy授权不提供游戏事实。

## 逐项证据、限制及处置
'''
for short, evidence, limits, behavior, reason in details:
    item = assigned['silent-proposal-' + short]['original']
    text += '\n### ' + item['id'] + '\n\n'
    text += '关联账本：' + '、'.join(item['ledger']) + '。来源任务：' + item['source_task'] + '。领域：' + '、'.join(item['domains']) + '。\n\n'
    text += '证据：' + evidence + '\n\n反例与未知：' + limits + '\n\n旧规则/预期行为：' + behavior + '\n\n处置：waiting。' + reason + '\n'

text += '''
## 验证、拟合与回退

若后续补机制传播，固定原状态、可执行牌、目标、属性、药槽、SL尝试与回合身份，逐步核已显示牌面、新增修正、消耗与跨轮撤回，并从card-model到turn-solver/rollout/combat-plan核消费者；不能只验证一个函数存在。源码撤除须使固定回归失败、恢复后通过，再跑仓库沙箱检查。本批没有新实现或生产红绿实验，不借旧测试结果。

时机/血线/药价/探索权重要求同条件完整后继及独立局时间留出；当前SL尝试按局分组、局部净差不当毛伤或整场因果。本批不拟参数、不补未知抽牌，不以有限全败推出必死。铁甲及未观察进阶没有修改。预期仅保留已证边界、避免过早关闭宽提案，获胜影响未知；若后续实现上线，按其独立源码提交回退，保留历史证据与原账本，不整库覆盖并行刷新。

## 现有源码与交付边界

相关19个源码叶与冻结live比较15个相同，另外4个差异是历史Roy/Dai注释，见source-vs-live.patch；不由少数叶推完整dirty树或所有知识输入等价。普通单弃bf423c173d3be348a4ad714e1d26516df619ff41与毒胜保血222445a9bb6bf56cb4f3ceea2cc8b20fba54128f只覆盖子范围；幽灵单层原源码96f17377a331e50ea5b6a3fe8d2b605932ed1bd4另核实际live祖先。3da1a93是经验数据提交，不能当幽灵源码提交。原历史运行的完整dirty源码/知识没有冻结，不用当前源码冒认原运行树。

没有新科学冲突或机制反例；旧来源越界/未隔离交互不追加为新支持。不派下级agent、不联网、不运行play、不修改模型、账号或prompt。用户要求普通/high；本批不拿模板/默认配置冒认已经独立核实实际原生模型或推理强度。

没有源码修改、提交、撤源码红绿、tsc/vitest、live合入、行为版本或shipped登记。tests三字段均null，fixes=[]，merged=null；没有未提交代码补丁或合入阻塞，也未启动部署流程。不需要提交前扫描或规则上线双通知。实际入库、消费者自然采用和收益均未在本批发生，父要求不因报告结束关闭。

材料准备探针错误及更正保留diagnostic-notes.md，不算产品缺陷。提案原件/dispatch/assigned-proposals、八流manifest与字节复核、31材料检查、compact状态/选择帧/资源端点/22幕转换、六旧消费者复用回执、源码祖先与差异、账本CLI输入/回执/保护结果均在本目录。提案交运维的路径为本proposal.md，report.md是本批独立回报；由原完成事件递交，不代ops/watcher/Roy确认。
'''
(OUT / 'proposal.md').write_text(text)
counts = '\n'.join(f"| {r['stream']} | {sum(r['counts'].values())} | {r['source_size']} |" for r in manifest)
report = f'''# 静默猎手策略批次回报

批次{BATCH}；时间{now}；base={BASE}。

十项原提案全部waiting，具体局号/层/回合/46既有账本、反例、旧规则/预期行为、验证和回退见proposal.md及proposal-results.json。没有源码或知识改动、提交、live合入、版本、shipped或未提交补丁；fixes=[]，merged=null，tests={{"tsc":null,"vitest":null,"cases":null}}。未定位新的已证源码修复，不把缺校准的宽提案当已有局部实现的duplicate。

## 身份与证据

普通提案批次，十原CLI id/角色/工作树绑定正确，无专题/实现请求。开工干净，merge main无新变化。十Markdown SHA匹配。十五局均Silent，A9三/A10十二；本批十个派发锚点与五个原提案内补充局分列，不混其他角色或未观察进阶。

八流22,424封套逐offset/bytes/SHA/JSON/显式局身份复核，31项固定材料检查通过。这些是材料核验，不是生产测试或新胜率证据。源截点分别保存，0行不用于断言原流不存在。

| 流 | 所属行 | 截点字节 |
|---|---:|---:|
{counts}

八流选中封套与20261016-004302-s2逐SHA相同，本批没有新增独立样本。22跨幕转换对仅核已有A9五/A10十七的同上限回复观察，不外推原116局资源模型或更低进阶。

## 判断与消费者边界

RC柔嫩/敏捷/折扇逐牌窗口成立，但八组件联合校准仍缺；X幽灵26→1已有窄源码，夜魇标记后即死亡，缺次轮合法兑现和延后饮药实线；B强制弃牌与X毒胜保血已有窄修复，接管/抽弃重问/复制整链仍不全。9Z的11→0→20复活和首张倍率消费可核，不能从端点推毛伤/完整候选。7X一次后段零毒→7、HP25不变再到18只支持该组合目标，喝后仍死；MTQ同盘少防御损0→8、即时伤13→19不提供独立整战收益或新探索权重。十四机制宽项和路线/SL资源项同样保留具体后继/校准缺口，不修改药价、血线、必死、SL或终局参数。

六个旧离线消费者输入重建SHA、原输出/错误SHA与六个递归消费者源码依赖均同，故只复用旧结果：1627帧、1530带ID动作、447段，完整候选认证仍0；旧275轮窗中的144端点和1097动作端点不当原候选完整兑现。本批没有重新执行消费者、模型或模拟。7X工具缺接续身份而区间未知，与原帧手工可核7毒分开，不能补造ID。

19相关源叶15同冻结live {source['live_head']}、4个仅历史署名注释差；六旧窄源码祖先与经验数据祖先的类别分别记录，后补幽灵真实源码祖先单列。普通单弃/毒胜搜索/幽灵窄范围不关闭整个提案。未取得历史完整dirty树，不声称重现原运行输入。

## 验证与交接

没有本批源码撤除失败/恢复通过、生产tsc/vitest或提交前gitleaks成功声明；它们均未运行。代码/知识/index保持干净、HEAD等于base；scratch全在本批learner/runs内。根账本只经CLI追加追溯note/where，不新增support/repeat、不改claim/首证/prior/evidence/status/version/shipped/effect。实际CLI及保护核验在本报告末尾补读回，不代其他角色确认。

交运维提案：{OUT / 'proposal.md'}。完整报告：{OUT / 'report.md'}。最终机器回执result.json，逐项处置proposal-results.json。无新游戏机制冲突；材料准备探针错误单列diagnostic-notes.md，历史与失败保留。未派子agent、不运行play、不推送、不安装依赖、不读凭据/其他角色知识/游戏二进制。实际原生模型/推理强度未独立读回，不以默认模板冒称已切换。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': BASE, 'proposals': len(results), 'all_waiting': True,
                  'material_checks': material['count'], 'report': result['report']}, ensure_ascii=False))

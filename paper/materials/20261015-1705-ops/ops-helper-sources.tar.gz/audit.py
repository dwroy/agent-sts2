from pathlib import Path
import json,hashlib,subprocess,re,tarfile,sys
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-1705';pub=r/'paper/materials/20261015-1705-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text());batches=json.loads((r/'ops/codex-ops/learn.json').read_text())['batches'];ledger=(r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True);archives=[];owned=[]
bid='20261015-164301';run='DUB5VQQ6D6D1';b=batches[bid];out=(r/'ops/codex-ops/learner'/f'{bid}.out').read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);s=Path(report['report']).parent;assert b['state']=='done' and b['rc']==0 and report['appended']==[run] and not report['bugs'] and not report['ledger']['repeats'];native=runtime(bid,report,out);refs=[];counts={};brain=[];configs=[]
for name in ['runs','decisions','states','run-plans','sl-attempts','brain','run-config']:
 n=0
 with (r/'logs'/f'{name}.jsonl').open('rb') as original,(s/f'{name}.jsonl').open() as frozen:
  for line in frozen:
   e=json.loads(line);size=e.get('bytes',e.get('length'));v=e.get('row',e.get('data'));original.seek(e['offset']);raw=original.read(size);row=json.loads(raw);assert row==v;fp=row.get('fingerprint') or {};fp=json.loads(fp) if isinstance(fp,str) else fp;ids=[v for v in [row.get('run_id'),row.get('run') if isinstance(row.get('run'),str) else None,(row.get('state') or {}).get('run_id'),((row.get('state') or {}).get('run') or {}).get('run_id'),fp.get('run')] if v is not None];assert ids and all(x==run for x in ids),(name,ids)
   if name=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
   if name=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brain.append(row)
   if name=='run-config':configs.append(row)
   refs.append({'stream':name,'line':e['line'],'offset':e['offset'],'bytes':size,'sha256':sha(raw)});n+=1
 counts[name]=n
assert sum(counts.values())==1017 and len(brain)==23 and len(configs)==1 and configs[0]['code']['commit']=='534c3140f2e3a98fcd6380ce4447b00592cba026';assert configs[0]['brain']['codex']['service_tier']=='default';verify=json.loads((s/'verification.json').read_text());assert verify['ok'] and verify['checks']==1086 and verify['source_rows']==1017;before=json.loads((s/'lessons-before.json').read_text());physical=(r/'notes/lessons.md').read_bytes();part=(s/'lesson-draft.md').read_bytes();assert len(part)==19487 and sha(part)==verify['draft_sha256'] and sha(physical[:before['size']])==before['sha256'] and physical.count(part)==1 and part.count(b'## DUB5VQQ6D6D1')==1;(p/'owned-lessons.md').write_bytes(part)
postrows=[]
for raw in ledger:
 row=json.loads(raw)
 if row.get('by')=='learner:postmortem' and (run in json.dumps(row,ensure_ascii=False) or str(s) in json.dumps(row,ensure_ascii=False)):
  assert row['op']=='update' and row['id'] in report['ledger']['updated'];assert all(x['run']==run and x['role']=='support' for x in row.get('evidence',[]));postrows.append(raw)
assert len(postrows)==14 and sum('evidence' in json.loads(x) for x in postrows)==7;owned+=postrows
sys.path.insert(0,str(r/'learner'));import code_proposals
queue=code_proposals.fold(r/'paper/materials/learning/code-proposals.jsonl');proposals=[]
for ident in report['code_proposals']:
 q=queue[ident];assert q['character']=='silent' and q['runs']==[run] and sha(Path(q['proposal']).read_bytes())==q['proposal_sha256'];proposals.append({k:q.get(k) for k in ['id','state','proposal','proposal_sha256']})
post={'batch':bid,'run':run,'report':report,'native':native,'original_rows_byte_JSON_identity_verified':1017,'stream_counts':counts,'learner_material_assertions':1086,'material_checks_not_reexecuted':True,'original_lesson_bytes':19487,'prefix_preserved':True,'ledger_rows':14,'support_updates':7,'repeats':0,'source_run_code':configs[0]['code'],'actual_accepted_brain':23,'brain':'recorded gpt-6.1-sol/xhigh/default; account cohort separately accepted by original watcher','no_new_pure_bug_or_queue':True,'proposals':proposals,'limits':'original full alternative outcomes, gross damage/last-hit order, first3SL exits, complete dirty knowledge/boss clock/pure game time/Jev cache/invoices remain unrecorded; do not add ops strategy knowledge','temporary_learner_script_failures':'original nullable-regex sum and inspect.py stdlib shadow errors retained; not production game bugs'};(pub/'postmortem-readback.json').write_text(json.dumps(post,ensure_ascii=False,indent=2)+'\n');(pub/'postmortem-original-references.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
for f in s.iterdir():
 if f.is_file() and f.stat().st_size<300000 and f.suffix in ['.json','.md','.py','.txt','.log','.patch'] and not f.name.startswith(('ledger-','prior-silent-lessons')):archives.append((f,'postmortem/'+f.name))
for ext in ['out','err']:archives.append((r/'ops/codex-ops/learner'/f'{bid}.{ext}','outputs/'+bid+'.'+ext))
for bid in ['20261015-164301-s2-strategy-proposal','20261015-164301-strategy-proposal']:
 b=batches[bid];report=b['report'];s=Path(report['report']).parent;out=(r/'ops/codex-ops/learner'/f'{bid}.out').read_text();assert b['state']=='done' and b['rc']==0 and not report['fixes'] and report['merged'] is None and all(v is None for v in report['tests'].values()) and len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results']);assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip();native=runtime(bid,report,out,b['worktree']);inputs=[]
 for name in ['ledger-updates.jsonl','ledger-corrections.jsonl']:
  f=s/name
  if f.exists():inputs += [json.loads(x) for x in f.read_text().splitlines()]
 rows=[]
 for raw in ledger:
  row=json.loads(raw)
  if row.get('op')=='update' and any(all(row.get(k)==x.get(k) for k in x) for x in inputs):rows.append(raw)
 assert len(rows)==len(inputs);assert all(set(json.loads(x))<=set(['op','id','ts','by','where','note']) for x in rows);owned+=rows
 result={'batch':bid,'original_report':report,'native':native,'original10waiting':True,'no_source_no_commit_no_merge_no_test_or_version':True,'worktree_clean':True,'owned_ledger_rows':len(rows),'source_evidence_checks':'original learner material checks read as reported; no redundant evidence/source tests','reported_original_rows':8274 if '-s2-' in bid else 6995,'correction_rows_kept':26 if '-s2-' not in bid else 0,'wide_proposals_not_closed':True,'subsequent_R361_release':'original ordinary report predates actual fallback; original append-only ledger corrections retain new source provenance without claiming broad completion'};(pub/(bid+'-readback.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 for f in s.iterdir():
  if f.is_file() and f.stat().st_size<300000 and f.suffix in ['.json','.md','.py','.txt','.log','.patch','.mjs'] and not f.name.startswith(('ledger-before','selected-experience','selection-input')):archives.append((f,bid+'/'+f.name))
 for ext in ['out','err']:archives.append((r/'ops/codex-ops/learner'/f'{bid}.{ext}','outputs/'+bid+'.'+ext))
selected=set(owned);ordered=[x for x in ledger if x in selected];assert len(ordered)==len(owned)==96;(p/'owned-ledger.jsonl').write_bytes(b''.join(ordered));manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f,name in archives:
  raw=f.read_bytes();dest=p/'archive-scan'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=name);manifest.append({'source':str(f.relative_to(r)),'archive':name,'bytes':len(raw),'sha256':sha(raw)})
(pub/'original-artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'postmortem_rows':1017,'lesson_bytes':19487,'owned_ledger_rows':96,'purebugs':0,'strategy_waiting':20,'small_originals':len(manifest)}))

import subprocess,json,pathlib
root=pathlib.Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261015-164301-4e63b776-3db5-4bbd-9e9b-54ae2aa36b80-postmortem'
run='DUB5VQQ6D6D1'
for name in ['runs','decisions','states','run-plans','sl-attempts','run-config','brain']:
 p=subprocess.Popen(['rg','-n','-b','-F',run,str(root/'logs'/f'{name}.jsonl')],stdout=subprocess.PIPE)
 n=0
 with (out/f'{name}.jsonl').open('w') as f:
  for raw in p.stdout:
   line,offset,data=raw.split(b':',2)
   obj=json.loads(data)
   f.write(json.dumps({'line':int(line),'offset':int(offset),'length':len(data),'data':obj},ensure_ascii=False)+'\n');n+=1
 p.wait();print(name,n)
d=[json.loads(x)['data'] for x in (out/'decisions.jsonl').open()]
start,end=d[0]['ts'],d[-1]['ts']
# The source has no run id. Seek its bounded tail first, then stream the timestamp window.
source=root/'logs/deepseek-reasoning.jsonl'
count=0
with source.open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as dst:
 f.seek(max(0,source.stat().st_size-65536))
 if f.tell():f.readline()
 while True:
  offset=f.tell();raw=f.readline()
  if not raw:break
  try: obj=json.loads(raw)
  except ValueError:continue
  if start<=obj.get('ts','')<=end:
   dst.write(json.dumps({'offset':offset,'data':obj},ensure_ascii=False)+'\n');count+=1
  last_ts=obj.get('ts')
print('window',start,end,'deepseek-tail-last',last_ts,'matched',count)

import json,pathlib,collections,re,hashlib,subprocess,datetime
P=pathlib.Path(__file__).parent
S=[json.loads(x) for x in (P/'states.jsonl').open()];D=[json.loads(x) for x in (P/'decisions.jsonl').open()];B=[json.loads(x) for x in (P/'brain.jsonl').open()];R=json.load((P/'DUB5VQQ6D6D1-resources.json').open())
# Freeze only source leaves used for the audit, with the source diff already preserved.
version='fad271855a515e229c7022f5049cc870f95a8d69'
meta={'run':'DUB5VQQ6D6D1','run_code':'current','run_config_commit':'534c3140f2e3a98fcd6380ce4447b00592cba026','live_reference':version,'files':{}}
for name in ['agent/src/reflex/combat-plan.ts','agent/src/hand/screens/selection.ts','agent/src/sl/explore.ts']:
 raw=subprocess.check_output(['git','-C','.worktrees/live','show',version+':'+name]);dest=P/('source-'+pathlib.Path(name).name);dest.write_bytes(raw);meta['files'][name]={'saved':dest.name,'sha256':hashlib.sha256(raw).hexdigest()}
(P/'source-reference.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
# Record exact compact route facts from actual brain payloads.
route=[]
for e in B:
 d=e['data'];payload=d.get('payload') or {};r=payload.get('route_review') or {}
 if r:
  z=r.get('plan_facts') or {};route.append({'brain_line':e['line'],'label':d['label'],'boss':z.get('boss'),'next_elite':z.get('next_elite'),'rest_sites':z.get('rest_sites'),'next_rest':r.get('next_rest'),'vs_plan':r.get('vs_plan')})
(P/'route-facts.json').write_text(json.dumps(route,ensure_ascii=False,indent=2)+'\n')
for a in route:
 if a['brain_line'] in [14579,14581,14589,14590,14592,14593,14594]:print('ROUTE',a['brain_line'],'boss',a['boss'],'elite',a['next_elite'],'rests',a['rest_sites'])
# Normalize printed turn progress into an artifact; preserve first-frame timing and unobserved exits.
turns=[]
for c in R['combats']:
 groups=collections.OrderedDict()
 for e in S:
  if c['entry']['ts']<=e['data']['ts']<=c['last']['ts'] and e['data']['state'].get('combat'):groups.setdefault(e['data']['state']['turn'],[]).append(e)
 starts=[v[0] for v in groups.values()]
 one=[]
 for i,e in enumerate(starts):
  s=e['data']['state'];co=s['combat'];need=sum(x['current_hp'] for x in co['enemies'] if x['is_alive'])
  nxt=starts[i+1] if i+1<len(starts) else next((x for x in S if c.get('exit') and x['line']==c['exit']['line']),None)
  end=nxt['data']['state'] if nxt else None;remaining=sum(x['current_hp'] for x in (end.get('combat') or {}).get('enemies',[]) if x['is_alive']) if end else None
  one.append({'turn':s['turn'],'first_state_line':e['line'],'need_hp':need,'next_first_state_line':nxt['line'] if nxt else None,'body_progress':need-remaining if remaining is not None else None,'hp_lost':s['run']['current_hp']-end['run']['current_hp'] if end else None})
 turns.append({'sequence':c['sequence'],'floor':c['floor'],'turns':one})
(P/'turn-metrics.json').write_text(json.dumps(turns,ensure_ascii=False,indent=2)+'\n')
# Show exactly the current hand identity and discard options at the disputed F8 decision.
for n in [398243,398244,398245]:
 d=next(x['data'] for x in D if x['line']==n);print('DISCARD',n,'expect',d.get('expect'),'chosen',d.get('chosen'),'reason',d['rationale'])
 if n==398244:
  for q in d['questions'].values():
   for key,v in q.get('criteria',{}).items():
    try:a=json.loads(v)
    except (ValueError,TypeError):continue
    print('OPTION',key,{k:v for k,v in a.items() if k in ['card','name','energy_cost','cost','discard_plan','discard_plan_step','plan_effect','effect']})
for n in [411295,411322,411343,411346]:
 e=next(x for x in S if x['line']==n);s=e['data']['state'];print('HAND',n,[(x['card_id'],x.get('playable'),x.get('unplayable_reason')) for x in s['combat']['hand']])
start=datetime.datetime.fromisoformat(D[0]['data']['ts'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(D[-1]['data']['ts'].replace('Z','+00:00'));print('SECONDS',(end-start).total_seconds(),'cache%',2188032/4086359*100)

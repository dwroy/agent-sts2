import json,pathlib,collections
P=pathlib.Path(__file__).parent
D={n:[json.loads(x) for x in (P/f'{n}.jsonl').open()] for n in ['states','decisions','run-plans','sl-attempts','brain']}
print('SCHEMA state',D['states'][0]['data'].keys())
s=D['states'][0]['data']['state'];print('state sub',s.keys()); print('run fields',s['run'].keys())
for n in ['decisions','brain','run-plans','sl-attempts']:
 print(n,'schema',D[n][0]['data'].keys())
for e in D['sl-attempts']:
 d=e['data'];print('SL',e['line'],d.get('ts'),{k:v for k,v in d.items() if k not in ['known','trace','replay','draws','memo','evidence','judge','candidate','observations','knownDraws','start','exploration','plan'] and not isinstance(v,(dict,list))});print('nested',{k:(list(v.keys()) if isinstance(v,dict) else len(v)) for k,v in d.items() if isinstance(v,(dict,list))})
for e in D['run-plans']:print('PLAN',e['line'],json.dumps(e['data'],ensure_ascii=False)[:1800])
for e in D['decisions']:
 d=e['data']
 if d['decider']=='codex' or 'HP guard' in d.get('rationale','') or d.get('chosen',{}).get('type') in ['use_potion','discard_potion']:
  print('DEC',e['line'],d['floor'],d.get('turn'),d['label'],str(d.get('chosen')),d.get('rationale',''))
print('sample chosen',D['decisions'][1]['data'].get('chosen'))
combat=next(e for e in D['states'] if e['data']['state'].get('in_combat'))
print('combat schema',combat['data']['state']['combat'].keys())
print('combat player',combat['data']['state']['combat'].get('player'))
print('enemy',combat['data']['state']['combat']['enemies'])

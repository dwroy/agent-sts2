import json,pathlib,collections
P=pathlib.Path(__file__).parent
S=[json.loads(x) for x in (P/'states.jsonl').open()];D=[json.loads(x) for x in (P/'decisions.jsonl').open()];R=json.load((P/'DUB5VQQ6D6D1-resources.json').open())
def pw(xs):return ','.join(str(x.get('power_id'))+':'+str(x.get('amount')) for x in xs)
def en(xs):return ';'.join(f"{x['enemy_id']}={x['current_hp']}/{x['max_hp']}挡{x['block']}[{pw(x['powers'])}] {x.get('move_id')}:{[(i.get('damage'),i.get('hits'),i.get('total_damage')) for i in x.get('intents',[])]}" for x in xs)
for c in R['combats']:
 if c['floor'] not in [5,8,17,21,22,23,24]:continue
 print('\nFIGHT',c['sequence'],'F',c['floor'])
 g=collections.OrderedDict()
 for e in S:
  d=e['data'];s=d['state']
  if c['entry']['ts']<=d['ts']<=c['last']['ts'] and s.get('combat'):g.setdefault(s['turn'],[]).append(e)
 for t,group in g.items():
  for lab,e in [('first',group[0]),('last',group[-1])]:
   s=e['data']['state'];co=s['combat'];p=co['player']
   print('T',t,lab,'s'+str(e['line']),'HP',s['run']['current_hp'],'B',p['block'],'E',p['energy'],'P',pw(p['powers']),'EN',en(co['enemies']))
  ds=[e for e in D if e['data']['floor']==c['floor'] and e['data']['turn']==t and c['entry']['ts']<=e['data']['ts']<=((c['exit'] or c['last'])['ts'])]
  for e in ds:
   d=e['data']; print('d'+str(e['line']),d['decider'],d['label'],d['rationale'])
print('\nPOTION ACTIONS')
for e in D:
 d=e['data'];a=(d.get('chosen') or {}).get('action','')
 if 'potion' in a:print('d'+str(e['line']),d['floor'],d['turn'],d['chosen'],d['rationale'])
print('\nRESOURCE CHANGES OUTSIDE COMBAT')
for x in R['resource_changes']:
 a,b=x['from'],x['to']
 if a['screen']!='COMBAT' or b['screen']!='COMBAT' or a['potions']!=b['potions']:
  print('s',a['line'],b['line'],'F',b['floor'],'T',b['turn'],a['screen'],b['screen'],'HP',a['hp'],b['hp'],'max',a['max_hp'],b['max_hp'],'pot',a['potions'],b['potions'])
print('\nRELICS/DECK FINAL')
s=S[-1]['data']['state'];print(json.dumps(s['run']['relics'],ensure_ascii=False));print(json.dumps(s['run']['deck'],ensure_ascii=False))

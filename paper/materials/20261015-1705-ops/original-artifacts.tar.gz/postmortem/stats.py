import json,pathlib,collections,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
B=[json.loads(x) for x in (P/'brain.jsonl').open()]
print('labels',collections.Counter((x['data']['decider'],x['data']['label']) for x in D))
print('usage keys',next(x['data']['usage'] for x in D if x['data'].get('usage')))
print('low',[(x['line'],x['data']['floor'],x['data']['turn'],x['data']['label'],x['data']['confidence']) for x in D if x['data']['decider']=='jev' and x['data'].get('confidence') is not None and x['data']['confidence']<0.35])
print('JOURNAL_EXAMPLE')
for n in [398203,398337,398478,398540,398594,398595,398596]:
 e=next(x for x in D if x['line']==n);d=e['data']
 print('d',n,'journal',json.dumps(d.get('journal'),ensure_ascii=False)[:10000])
 print('questions keys', {k:list(v.keys()) for k,v in (d.get('questions') or {}).items()})
 print('expect',str(d.get('expect')),'chosen',d['chosen'],'sl',d.get('sl_attempt'),d.get('sl_reloads'))
 print('result',str(d.get('result'))[:600])
print('BRAIN_META')
for e in B:
 d=e['data'];print('b'+str(e['line']),d['label'],d['engine'],d['model'],d['effort'],d.get('accepted'),d.get('question_id'),'usage',d['usage'])
print('BRAIN_FIRST_OPTIONS',str(B[0]['data'].get('options'))[:500]);print('BRAIN_FIRST_Q',str(B[0]['data'].get('question'))[:500])

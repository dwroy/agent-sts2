import json,pathlib,collections,re,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()];S=[json.loads(x) for x in (P/'states.jsonl').open()];R=json.load((P/'DUB5VQQ6D6D1-resources.json').open())
print('rollout_best_chosen',collections.Counter(str(e['data'].get('rollout_best_chosen')) for e in D if e['data']['label']=='combat/plan-choice'))
for n in [398203,398478,398548,398560,398594]:
 d=next(e['data'] for e in D if e['line']==n);print('AUDIT d',n,'hpguard',json.dumps(d.get('hp_guard'),ensure_ascii=False),'selection_audit keys',list((d.get('selection_audit') or {}).keys()),'rollout', {k:v for k,v in (d.get('rollout') or {}).items() if k in ['best','samples','horizon']})
print('BOSS CLOCK/Facts')
for n in [398118,398229,398334,398382]:
 d=next(e['data'] for e in D if e['line']==n)
 for q in (d.get('questions') or {}).values():
  for k,v in (q.get('criteria') or {}).items():
   if k in ['facts','state']:
    try:x=json.loads(v) if isinstance(v,str) else v
    except ValueError:continue
    print('d',n,'facts keys',list(x) if isinstance(x,dict) else type(x))
    if isinstance(x,dict):
     print('clock',x.get('act_boss_clock')); print('boss_sim',str(x.get('act_boss_sim'))[:1000])
print('TURN TOTALS')
for c in R['combats']:
 if c['floor'] not in [8,17,19,21,22,23,24]:continue
 rows=[e for e in S if c['entry']['ts']<=e['data']['ts']<=c['last']['ts']]
 turns=collections.OrderedDict()
 for e in rows:
  s=e['data']['state']
  if s.get('combat'):turns.setdefault(s['turn'],[]).append(e)
 starts=[v[0] for v in turns.values()]
 vals=[]
 for i,e in enumerate(starts):
  s=e['data']['state'];co=s['combat'];need=sum(x['current_hp'] for x in co['enemies'] if x['is_alive']);end=starts[i+1]['data']['state'] if i+1<len(starts) else (next((e['data']['state'] for e in S if c.get('exit') and e['line']==c['exit']['line']),None))
  hpnext=end['run']['current_hp'] if end else None
  neednext=sum(x['current_hp'] for x in (end.get('combat') or {}).get('enemies',[]) if x['is_alive']) if end else None
  vals.append({'turn':s['turn'],'need':need,'progress':need-neednext if neednext is not None else None,'hp_loss':s['run']['current_hp']-hpnext if hpnext is not None else None,'line':e['line']})
 print('F',c['floor'],'seq',c['sequence'],json.dumps(vals,ensure_ascii=False))
print('terminal',json.dumps(S[-1]['data']['state']['combat'],ensure_ascii=False)[:2400])

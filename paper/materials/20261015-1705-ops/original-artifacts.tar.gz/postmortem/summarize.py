import json,pathlib,re,collections,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()];B=[json.loads(x) for x in (P/'brain.jsonl').open()]
# Original replies are in the question projection audit if available; avoid conflating overrides.
counts=collections.Counter();ranks=collections.Counter();focus=[]
for e in D:
 d=e['data']
 if d['label']!='combat/plan-choice':continue
 crit={k:json.loads(v) for k,v in d['questions']['plan']['criteria'].items()}
 m=re.search(r'Jev chose plan (\d+)/',d['rationale']);selected='plan'+m.group(1) if m else None
 best=[k for k,v in crit.items() if v.get('rollout_best')]
 counts['questions']+=1;counts['explicit_best']+=bool(best)
 if best:counts['selected_best']+=selected in best
 m=re.search(r'code rank (\d+)',d['rationale'])
 if m:ranks[int(m.group(1))]+=1
 if any('focus' in a for a in crit.values()):focus.append((e['line'],d['floor'],d['turn'],selected,[k for k,v in crit.items() if 'focus' in v]))
print('JEV best',counts,'rank',ranks,'focus',focus)
code=[e for e in D if e['data']['decider']=='code' and e['data']['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]
print('CODE autonomous decisions',len(code),'turns',len({(e['data']['floor'],e['data'].get('sl_reloads',0),e['data']['turn']) for e in code}),'bylabel',collections.Counter(e['data']['label'] for e in code))
for group,rows in [('jev',[e for e in D if e['data']['decider']=='jev']),('brain',B),('codex_decision',[e for e in D if e['data']['decider']=='codex'])]:
 sums=collections.Counter()
 for e in rows:
  for k,v in (e['data'].get('usage') or {}).items():
   if isinstance(v,(float,int)):sums[k]+=v
 print('USAGE',group,len(rows),dict(sums))
print('brain labels',collections.Counter(e['data']['label'] for e in B))
for e in B: print('BRAIN',e['line'],e['data']['label'],e['data']['engine'],e['data']['model'],e['data']['effort'],e['data']['accepted'])
print('FOCUS_NESTED_EXAMPLE')
for e in D:
 d=e['data']
 if d['label']=='combat/plan-choice':
  q=d['questions']['plan'];f=[(k,v) for k,v in q['criteria'].items() if 'focus' in v]
  if f:print(e['line'],[(k,repr(v)[-650:]) for k,v in f][:2])
print('BOSS_SIM_STRUCT')
for n in [398229,398259,398306,398334,398413]:
 d=next(e['data'] for e in D if e['line']==n);print('d',n,'boss-sim keys',list((d.get('boss_sim') or {}).keys()))
 b=d.get('boss_sim') or {};print(str(b)[:1000])
 for k,v in d.get('questions',{}).items():
  for key,val in v.get('criteria',{}).items():
   a=json.loads(val) if isinstance(val,str) else val
   if key=='o0' or (n==398334 and a.get('card')=='滚石'):
    print(key,{k:v for k,v in a.items() if k not in ['quantitative_fight','construction_realization','card_outcome_stats','outcome_stats','card_references']})
    z=a.get('quantitative_fight') or {};print('quantitative', {k:v for k,v in z.items() if k in ['samples','simulated_turns','effective_damage_per_turn','hp_loss','raw_win_mc_interval95']})

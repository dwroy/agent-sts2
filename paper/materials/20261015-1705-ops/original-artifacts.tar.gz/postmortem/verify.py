import json,pathlib,collections,hashlib,datetime,re,sys
P=pathlib.Path(__file__).parent;root=P.parents[2];checks=0

def check(ok,note):
 global checks
 if not ok:raise AssertionError(note)
 checks+=1

allrows={}
for name in ['runs','decisions','states','run-plans','sl-attempts','run-config','brain']:
 rows=[json.loads(x) for x in (P/f'{name}.jsonl').open()];allrows[name]=rows
 with (root/'logs'/f'{name}.jsonl').open('rb') as handle:
  for row in rows:
   handle.seek(row['offset']);raw=handle.read(row['length']);check(json.loads(raw)==row['data'],f'{name}:{row["line"]} source equality')
check([len(allrows[n]) for n in allrows]==[1,485,497,5,5,1,23],'all source counts')
run=allrows['runs'][0]['data'];check(run['character'].lower()=='silent' and run['ended'] and run['floor']==24 and run['ascension']==10 and not run['victory'],'run identity')
D=allrows['decisions'];ds={e['line']:e['data'] for e in D};S={e['line']:e['data']['state'] for e in allrows['states']};R=json.load((P/'DUB5VQQ6D6D1-resources.json').open())
expected=[(2,56,46,70),(3,46,46,70),(4,46,39,70),(5,39,22,70),(8,57,27,82),(12,56,32,87),(15,63,60,92),(17,92,44,97),(19,86,85,97),(21,85,78,97),(22,78,64,97),(23,64,47,97)]
for c,x in zip(R['combats'],expected):
 check((c['floor'],c['entry']['hp'],c['exit']['hp'],c['entry']['max_hp'])==x,f'resource F{x[0]}')
 check(c['entry_is_turn_one'] and c['exit']['screen']=='REWARD','entry T1 and victory evidence')
for c,hp,turn in zip(R['combats'][12:],[1,5,1,1],[7,5,7,7]):
 check(c['entry']['hp']==47 and c['entry']['max_hp']==97 and not c['entry']['potions'] and c['last']['hp']==hp and c['last']['turn']==turn,'SL resources')
check(all(c['exit'] is None for c in R['combats'][12:15]),'SL exits missing explicit')
check(R['combats'][-1]['exit']['hp']==0 and S[411347]['combat']['enemies'][0]['current_hp']==114,'death')
check(S[411346]['combat']['player']['block']==17 and S[411346]['run']['current_hp']==1,'last board')
check(S[411343]['combat']['enemies'][0]['intents'][0]['total_damage']==40,'last attack')
jev=[e['data'] for e in D if e['data']['decider']=='jev'];plans=[d for d in jev if d['label']=='combat/plan-choice'];low=[d for d in jev if d['confidence']<0.35]
check(len(jev)==111 and len(plans)==84 and len(low)==10 and sum(d['label']=='combat/plan-choice' for d in low)==3,'Jev calls/confidence')
check(sum(d.get('rollout_best_chosen') is True for d in plans)==77 and sum(d.get('rollout_best_chosen') is False for d in plans)==7,'Jev rollout')
ranked=[re.search(r'code rank (\d+)',d['rationale']) for d in plans];check(sum(bool(m) for m in ranked)==61 and sum(bool(m and m.group(1)=='1') for m in ranked)==29,'ranked count')
focusq=0;focuspick=0;bestq=0;bestpick=0
for d in plans:
 c={k:json.loads(v) for k,v in d['questions']['plan']['criteria'].items()};m=re.search(r'Jev chose plan (\d+)/',d['rationale']);pick='plan'+m.group(1)
 focusq+=any('focus' in v for v in c.values());focuspick+='focus' in c[pick];best=[k for k,v in c.items() if v.get('rollout_best')];bestq+=bool(best);bestpick+=pick in best
check((focusq,focuspick,bestq,bestpick)==(21,6,78,71),'focus and explicit best')
code=[e['data'] for e in D if e['data']['decider']=='code' and e['data']['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]
check(len(code)==98 and len({(d['floor'],d['sl_reloads'],d['turn']) for d in code})==71,'code autonomy')
check(sum(e['data'].get('hp_guard') is not None for e in D)==1,'HP guard count')
h=ds[398203]['hp_guard'];check(h['predicted_hp_saved']==10 and h['predicted_damage_change']==-12 and h['before_guard']['rollout']['wins']==7 and h['after_guard']['rollout']['wins']==4,'HP guard cost')
check(S[410982]['run']['current_hp']==46 and S[410984]['combat']['player']['block']==0 and S[410985]['run']['current_hp']==28,'discard actual')
check(ds[398244]['expect']['option']['id']=='DEFEND_SILENT' and '原整条预测失效' in ds[398244]['rationale'],'discard audit')
for n in [398594,398595]:check(ds[n]['selection_audit']['sl_delta']['damage']==-10 and ds[n]['selection_audit']['sl_delta']['hp_loss']==0,'SL delete poison')
check(S[411268]['combat']['enemies'][0]['current_hp']==S[411341]['combat']['enemies'][0]['current_hp']==131,'same T6 board hp')
check(S[411271]['combat']['enemies'][0]['current_hp']==104 and S[411343]['combat']['enemies'][0]['current_hp']==114,'T7 poison difference')
uses=[d for d in (e['data'] for e in D) if (d.get('chosen') or {}).get('action')=='use_potion'];check(len(uses)==6,'six drinks')
check(not any((e['data'].get('chosen') or {}).get('action')=='discard_potion' for e in D),'no discard')
check(S[411059]['combat']['player']['block']==10,'copied defense')
check(S[411228]['combat']['player']['powers'][-1]['amount']==-1 and S[411230]['combat']['player']['powers'][-2]['amount']==9,'speed values')
check(S[411231]['combat']['player']['block']==14,'speed defense block')
B=[e['data'] for e in allrows['brain']];check(len(B)==23 and all((d['engine'],d['model'],d['effort'],d['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for d in B),'native brain logs')
check(sum(d['usage']['inputTokens'] for d in B)==4086359 and sum(d['usage']['cacheHitTokens'] for d in B)==2188032 and sum(d['usage']['outputTokens'] for d in B)==23789,'brain usage')
check(sum(d['usage']['input_tokens']+d['usage']['output_tokens'] for d in jev)==733022,'Jev usage')
clock=next(e['data']['payload']['facts']['act_boss_clock'] for e in allrows['brain'] if e['line']==14589);check(all(clock[k] is None for k in ['deck_damage_per_turn_estimate','hp_loss_per_turn','survivable_turns','gap_per_turn']),'unknown clock')
start=datetime.datetime.fromisoformat(D[0]['data']['ts'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(D[-1]['data']['ts'].replace('Z','+00:00'));check((end-start).total_seconds()==3336.193,'elapsed')
config=datetime.datetime.fromisoformat(allrows['run-config'][0]['data']['ts'].replace('Z','+00:00'));check((end-config).total_seconds()==3415.191,'config elapsed')
text=(P/'lesson-draft.md').read_text();check(len(re.findall(r'^- \[(?!记录)',text,re.M))==3 and text.count('## DUB5VQQ6D6D1')==1,'lesson structure')
# Re-seek key original frames after draft completion; do not trust only the derived resource table.
with (root/'logs/states.jsonl').open('rb') as f:
 for n,hp in [(410854,56),(410971,57),(411076,92),(411219,64),(411248,47),(411275,47),(411295,47),(411322,47),(411343,1),(411347,0)]:
  e=next(x for x in allrows['states'] if x['line']==n);f.seek(e['offset']);raw=f.readline();check(json.loads(raw)['state']['run']['current_hp']==hp,'original numeric recheck '+str(n))
result={'ok':True,'checks':checks,'source_rows':sum(map(len,allrows.values())),'resource_windows':len(R['combats']),'observed_victories':12,'missing_SL_exits':3,'draft_sha256':hashlib.sha256(text.encode()).hexdigest()}
(P/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

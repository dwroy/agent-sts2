import json,pathlib
P=pathlib.Path(__file__).parent
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
for n in [398203,398233,398334,398478,398548,398560,398594,398595]:
 d=next(x['data'] for x in D if x['line']==n)
 print('\nd',n,'boss keys',list((d.get('boss_sim') or {}).keys()),'deepseek',str(d.get('deepseek'))[:250])
 for qkey,q in (d.get('questions') or {}).items():
  print('q',qkey,'criteria keys',list(q.get('criteria',{})))
  for key,val in q.get('criteria',{}).items():
   try:a=json.loads(val) if isinstance(val,str) else val
   except ValueError:a=val
   if key in ['facts','state']:
    print(key, str(a)[:1000]);continue
   print(key, json.dumps(a,ensure_ascii=False)[:3400])
  print('instructions tail',q.get('instructions','')[-1600:])
for x in [json.loads(l) for l in (P/'sl-attempts.jsonl').open()]:
 d=x['data'];print('\nSL',x['line'],'judge',d.get('judge'),'reload',d.get('reload'),'summary',json.dumps(d['summary'],ensure_ascii=False)[:2000],'explore',json.dumps({k:v for k,v in d['explore'].items() if k not in ['points','turns']},ensure_ascii=False)[:2000])

import json,pathlib,collections
P=pathlib.Path(__file__).parent
R=json.load((P/'DUB5VQQ6D6D1-resources.json').open())
print('resource keys',list(R))
for c in R['combats']:
 print('FIGHT',c['sequence'],'F'+str(c['floor']),c['enemies'],'entry',c['entry'],'last',c['last'],'exit',c['exit'],'end',c['end'])
S=[json.loads(x) for x in (P/'states.jsonl').open()]
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
with (P/'fight-details.txt').open('w') as f:
 for c in R['combats']:
  if c['floor'] not in [5,8,17,21,22,23,24]:continue
  f.write('\nCOMBAT '+str(c['sequence'])+' F'+str(c['floor'])+'\n')
  rows=[e for e in S if c['entry']['ts']<=e['data']['ts']<=c['last']['ts']]
  turns=collections.OrderedDict()
  for e in rows:
   d=e['data'];s=d['state'];co=s.get('combat')
   if not co:continue
   turns.setdefault(s['turn'],[]).append(e)
  for t,group in turns.items():
   for label,e in [('first',group[0]),('last',group[-1])]:
    s=e['data']['state'];co=s['combat'];p=co['player']
    f.write(json.dumps({'T':t,'at':label,'s':e['line'],'ts':e['data']['ts'],'hp':s['run']['current_hp'],'block':p['block'],'energy':p['energy'],'powers':p['powers'],'hand':[{k:x.get(k) for k in ['index','card_id','name','cost','description','is_playable','blocked_by_hook']} for x in co['hand']],'enemies':co['enemies']},ensure_ascii=False)+'\n')
   ds=[e for e in D if e['data']['floor']==c['floor'] and e['data']['turn']==t and c['entry']['ts']<=e['data']['ts']<=((c['exit'] or c['last'])['ts'])]
   for e in ds:
    d=e['data'];j=d.get('journal') or {}
    f.write('d'+str(e['line'])+' '+d['decider']+' '+d['label']+' '+d['rationale']+' | chosen='+str(d['chosen'])+' | journal='+json.dumps(j,ensure_ascii=False)[:700]+'\n')
with (P/'resources-summary.txt').open('w') as f:
 for c in R['resource_changes']:
  a,b=c['from'],c['to'];f.write(json.dumps({'from':a,'to':b,'restart':c['restart_boundary']},ensure_ascii=False)+'\n')

import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}


def projection(item):
    row = item['row']
    s = row['state']
    run, combat = s.get('run') or {}, s.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'],
        'observed_ts': row.get('observed_ts'), 'ts': row.get('ts'),
        'screen': s.get('screen'), 'floor': run.get('floor'), 'turn': s.get('turn'),
        'hp': player.get('current_hp', run.get('current_hp')),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player.get('powers')),
        'hand': [{'id': c['card_id'], 'index': c['index']} for c in combat.get('hand') or []],
        'enemies': [{
            'index': e.get('index'), 'id': e.get('enemy_id'),
            'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
            'block': e.get('block'), 'alive': e.get('is_alive'),
            'move': e.get('move_id'), 'powers': powers(e.get('powers')),
            'intents': e.get('intents'),
            'identity_keys': [k for k in e if any(word in k.lower() for word in ('uuid', 'instance', 'entity', 'generation'))],
        } for e in combat.get('enemies') or []],
    }


def main():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    report = []
    for entry in manifest:
        path = OUT / 'evidence' / (entry['stream'] + '.evidence.jsonl')
        counts = collections.Counter()
        digest = hashlib.sha256()
        projected = OUT / (entry['stream'] + '-projection.jsonl')
        with open(entry.get('source', '/home/dw/Projects/agent-sts2/logs/' + entry['stream'] + '.jsonl'), 'rb') as source, path.open('rb') as f, projected.open('w') as dst:
            for encoded in f:
                digest.update(encoded)
                item = json.loads(encoded)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert item['offset'] + item['bytes'] <= entry['source_size']
                counts[item['run_id']] += 1
                if entry['stream'] == 'states':
                    s = item['row']['state']
                    assert (s.get('run') or {}).get('character_id', 'SILENT') == 'SILENT'
                    dst.write(json.dumps(projection(item), ensure_ascii=False) + '\n')
                elif entry['stream'] == 'decisions':
                    r = item['row']
                    dst.write(json.dumps({'line': item['line'], 'run': item['run_id'], 'ts': r.get('ts'), 'floor': r.get('floor'), 'keys': list(r), 'fingerprint': r.get('fingerprint')}, ensure_ascii=False) + '\n')
                else:
                    dst.write(encoded.decode())
        assert digest.hexdigest() == entry['output_sha256']
        assert all(counts[r] == n for r, n in entry['counts'].items())
        report.append({'stream': entry['stream'], 'source_size': entry['source_size'], 'verified_rows': sum(counts.values()), 'counts': dict(counts), 'sha256': digest.hexdigest()})
    (OUT / 'evidence-readback.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()

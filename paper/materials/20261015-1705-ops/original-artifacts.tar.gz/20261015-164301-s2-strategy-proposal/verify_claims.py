import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
STATES = {x['line']: x for x in map(json.loads, (OUT / 'states-projection.jsonl').open())}
DECISIONS = {x['line']: x for x in map(json.loads, (OUT / 'evidence/decisions.evidence.jsonl').open())}
checks = []


def check(name, actual, expected, lines):
    checks.append({'claim': name, 'actual': actual, 'expected': expected, 'state_lines': lines, 'passed': actual == expected})


def power(line, name, enemy=None):
    row = STATES[line]
    return (row['powers'] if enemy is None else next(e['powers'] for e in row['enemies'] if e['id'] == enemy)).get(name, 0)


def incoming(line, enemy):
    return sum((a.get('damage') or 0) * (a.get('hits') or 0) for e in STATES[line]['enemies'] if e['id'] == enemy for a in e['intents'])


pairs = []
for a, b, expected in [(270216, 270282, [[3, 10], [15, 17]]), (271309, 271348, [[0, 45], [9, 38]]),
                        (271992, 272040, [[9, 24], [14, 27]]), (271982, 272195, [[2, 25], [10, 34]])]:
    check(f'同指纹决策{a}/{b}', DECISIONS[a]['row']['fingerprint'], DECISIONS[b]['row']['fingerprint'], [])
    windows = []
    for n in [a, b]:
        d = DECISIONS[n]
        matches = [x for x in STATES.values() if x['run'] == d['run_id'] and x['observed_ts'] == d['row']['observed_ts']]
        assert len(matches) == 1
        start = matches[0]
        end = next(x for x in STATES.values() if x['line'] > start['line'] and x['run'] == start['run'] and x['floor'] == start['floor'] and x['turn'] == start['turn'] + 1)
        between = [x for x in STATES.values() if start['line'] <= x['line'] < end['line'] and x['run'] == start['run']]
        assert all(x['floor'] == start['floor'] and x['turn'] == start['turn'] for x in between)
        loss = start['hp'] - end['hp']
        net = sum(e['hp'] for e in start['enemies']) - sum(e['hp'] for e in end['enemies'])
        windows.append({'decision_line': n, 'start': start['line'], 'end': end['line'], 'hp_loss': loss, 'enemy_net_hp_decrease': net})
    check(f'同盘端点{a}/{b}', [[w['hp_loss'], w['enemy_net_hp_decrease']] for w in windows], expected, [w['start'] for w in windows] + [w['end'] for w in windows])
    pairs.append({'decisions': [a, b], 'windows': windows, 'scope': '原始观测的当轮端点；不认证候选整线执行或未选线后继'})

check('火花3变6', [power(n, 'VITAL_SPARK_POWER', 'INFESTED_PRISM') for n in [274830, 274834]], [3, 6], [274830, 274834])
check('T4污染0/3/3/6', [power(n, 'TAINTED_POWER') for n in range(274830, 274834)], [0, 3, 3, 6], list(range(274830, 274834)))
check('T5污染0/0/6/12/18', [power(n, 'TAINTED_POWER') for n in range(274834, 274839)], [0, 0, 6, 12, 18], list(range(274834, 274839)))
check('污染下轮清除', power(274839, 'TAINTED_POWER'), 0, [274839])
check('棱柱两轮净损3/9', [STATES[274830]['hp'] - STATES[274834]['hp'], STATES[274834]['hp'] - STATES[274839]['hp']], [3, 9], [274830, 274834, 274839])
check('蚌力量0/4/8', [power(n, 'STRENGTH_POWER', 'SEWER_CLAM') for n in [273238, 273252, 273264]], [0, 4, 8], [273238, 273252, 273264])
check('蚌喷水11/15/19及弱后11/14', [incoming(n, 'SEWER_CLAM') for n in [273238, 273252, 273264, 273254, 273268]], [11, 15, 19, 11, 14], [273238, 273252, 273264, 273254, 273268])
check('蚌轮初覆甲9/9/8/7/6', [power(n, 'PLATING_POWER', 'SEWER_CLAM') for n in [273238, 273247, 273252, 273258, 273264]], [9, 9, 8, 7, 6], [273238, 273247, 273252, 273258, 273264])
check('电击力量2/4', [power(n, 'STRENGTH_POWER', 'ZAPBOT') for n in [274308, 274313]], [2, 4], [274308, 274313])
check('电击威胁17/19', [incoming(n, 'ZAPBOT') for n in [274308, 274313]], [17, 19], [274308, 274313])
check('电击index随其他实体退场重排', [next(e['index'] for e in STATES[n]['enemies'] if e['id'] == 'ZAPBOT') for n in [274308, 274312]], [4, 3], [274308, 274312])
check('失落返力前后', [power(n, 'STRENGTH_POWER') for n in [274357, 274358]], [-4, 0], [274357, 274358])
check('步法敏捷-4/-2/0', [power(n, 'DEXTERITY_POWER') for n in [274351, 274352, 274354]], [-4, -2, 0], [274351, 274352, 274354])
check('遗忘再夺敏捷', [power(n, 'DEXTERITY_POWER') for n in [274358, 274362]], [0, -2], [274358, 274362])
check('POSSESS显示1不等于返还4', power(274357, 'POSSESS_STRENGTH_POWER', 'THE_LOST'), 1, [274357])
check('实验体换阶段清毒和力', [power(277512, 'POISON_POWER', 'TEST_SUBJECT'), power(277513, 'POISON_POWER', 'TEST_SUBJECT'), power(277512, 'STRENGTH_POWER', 'TEST_SUBJECT'), power(277513, 'STRENGTH_POWER', 'TEST_SUBJECT')], [4, 0, 15, 0], [277512, 277513])
check('零毒触媒2', [power(277519, 'POISON_POWER', 'TEST_SUBJECT'), power(277519, 'ACCELERANT_POWER')], [0, 2], [277519])
check('后加敏捷不倒补23挡', [[STATES[n]['block'], power(n, 'DEXTERITY_POWER')] for n in [277523, 277526]], [[23, 5], [23, 6]], [277523, 277526])
check('实验体末轮本体净扣37', STATES[277519]['enemies'][0]['hp'] - STATES[277527]['enemies'][0]['hp'], 37, [277519, 277527])
check('船夹板14加斗篷6', [STATES[n]['block'] for n in [278236, 278240]], [14, 20], [278236, 278240])
check('镣铐临减恢复', [power(n, 'STRENGTH_POWER', 'CRUSHER') for n in [278236, 278237, 278242]], [0, -9, 0], [278236, 278237, 278242])
check('火箭朝向和弱分步57/38/28', [incoming(n, 'ROCKET') for n in [278249, 278252, 278253]], [57, 38, 28], [278249, 278252, 278253])
check('四敏脆弱实际6挡', [power(278255, 'DEXTERITY_POWER'), power(278255, 'FRAIL_POWER'), STATES[278255]['block']], [4, 2, 6], [278255])
sl = [x for x in map(json.loads, (OUT / 'evidence/sl-attempts.evidence.jsonl').open()) if x['run_id'] == 'YF0LXT1QSTGG' and x['row']['floor'] == 33 and x['row']['attempt'] == 2]
check('同局SL成功反例保留', [sl[0]['row']['result'], sl[0]['row']['end_hp']], ['won', 20], [])
result = {'checks': checks, 'pairs': pairs, 'passed': sum(x['passed'] for x in checks), 'failed': sum(not x['passed'] for x in checks), 'scope': '固定原日志材料核对；不是生产tsc/vitest或撤源码测试'}
(OUT / 'verified-claims.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ['checks', 'pairs']}, ensure_ascii=False))
assert result['failed'] == 0

# 本批静默策略提案核对

记录时间：2026-10-15T16:54:22+08:00。batch：20261015-164301-s2-strategy-proposal。
完整base：`8a450aa06e05fd7b115b2e89736f889ecc4366ad`。开工工作树干净，`git merge --no-edit main`返回Already up to date。
本批learn.json为reason=proposal，准确领取10个原id；没有research_request/implementation_request/proposal_repair。普通专题请求仍绑定别批，因此不转专题、不领取其他队列项。

结论：10项均waiting。本批未找到足以支撑新策略、参数或新增确定性模型修复的证据；不以已存在的局部源码覆盖整项。无新源码、知识、提交、合入或发布版本，铁甲及其他角色行为未变。

## 证据与验证口径

六局runs.jsonl均明确SILENT/A10。共用extract_evidence.py按显式run/run_id/state.run_id/fingerprint.run筛选，六流冻结8268行：states4062、decisions3941、SL38、run-config6、run-plans33、brain188；另存runs身份6行，合计8274行。每流source_size和逐行offset/bytes/SHA见evidence/与evidence-runs/；evidence-readback.json逐行回读原字节并核计数与输出SHA。原全流2条states、2条decisions、1条brain无效JSON由抽取器原样计数，不说原日志全部合法；run-plans已按run字段取得33行，没有将零行或正文提及当所属局。

verified-claims.json及verify-claims.log：32个固定原日志材料断言通过。四组对照均先比完整fingerprint，再以observed_ts唯一绑定起始状态，取本回合到下一回合的实际连续端点；只证明端点变化，敌本体净HP变化不冒作毛伤害或完整候选执行。SL尝试不扩成独立样本。本批未做全历史重统计、反事实模拟、LLM或网络请求。

run-config均标dirty，包含当时更新的知识数据；当时运行的源码commit和knowledge prefix指纹不等于完整历史文件快照。当前知识不冒作历史实际移动表。历史brain配置gpt-6.1-sol/high仅作原记录，未把旧记录改成xhigh或当作当前原生会话证明。

source-audit.json冻结实际live `fad271855a515e229c7022f5049cc870f95a8d69`；11个相关源码叶与工作树逐SHA相同，列出的last-source-commit均真实live祖先。以下祖先只证明子项：候选/护栏/资源比较a8b1f8be153fe4f3a34146117546c2178f2e446b；选择审计05cd292c6f01bb31e406473d3a9843e659d62b93；单动作回执bade647f9fe4c9103b40e2f26b26296692ad24b7；阶段当前快照8698c581dac6c7e957f50a381586960a6d0c9b57；怪物库读取4ed3c72df30f27b881da637aebf528b97440e0bb。actual_turn_result/actual_outcome/whole_plan_executed仍留空，execution仍unverified，不能登记整项duplicate/implemented。当前moveDamageAt与monsterHpAt不加五样本门槛；roomHpCost保留ROOM_COST_MIN_N=5。本批未更改这些规则。

未产生新机制反证；原稿反例和未知逐项保留，不为支持原假设改变结论。此批不新增support/repeat，不重写历史复盘。

## silent-proposal-c20b5139dd0dff71

原摘要：冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。

角色/范围：silent，策略仅本批已观察A10。证据：DUZUBAJ3A8GP，F27 T4—6；states 274830—274839；silent-0168。
账本：silent-0168。来源任务：experience-update；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-c20b5139dd0dff71.md；均与队列SHA一致。

本批支持：火花3→6；T4污染0→3→3→6，勒紧能力未增加污染；T5三技能累计6/12/18，下一轮清除；两轮实损3/9。

反例/现状限制：技能同时改变毒、挡和敌方意图，不能仅按技能张数规定少打。当前turn-solver已有逐技能污染、Weak前加算，rollout已有火花成长。

处置：waiting。缺原dirty运行实际消费的A10移动表快照、跨轮联合校准输入和未选线后继；本次未定位新的确定性模型差异。

预期行为与下一步验证：冻结现场火花、污染、迷雾收益与相同起点输入逐轮重放；发现可重复数值差异后才能做窄修复。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-ae9e692d680e3819

原摘要：提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。

角色/范围：silent，策略仅本批已观察A10。证据：5PM6JAQG6FNQ，F39 T4—6；states 274351—274362、274391—274397；silent-0183/0005。
账本：silent-0183, silent-0005。来源任务：experience-update；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-ae9e692d680e3819.md；均与队列SHA一致。

本批支持：两步法敏捷−4→−2→0；失落毒杀后力量−4→0；遗忘随后再夺2敏。POSSESS_STRENGTH_POWER显示amount=1，不能替代累计返还4。

反例/现状限制：末试单步法只回−2敏且死亡；毒杀并不保证后场生存。现有负属性公式不能证明已实现逐来源死亡返还。

处置：waiting。缺逐来源已夺累计数、所有权及跨死亡/退场的完整生产输入；另一杀序的完整后继未记录。

预期行为与下一步验证：保存每次夺取的来源、累计量与返还时点，再核所有权传播；不能由当前净负属性猜分配或固定击杀序。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-52f1e1bd2e7db0ed

原摘要：第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。

角色/范围：silent，策略仅本批已观察A10。证据：CA5KE8GFJ9X2，F13 T1—5；states 273238—273269；silent-0231。
账本：silent-0231。来源任务：experience-update；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-52f1e1bd2e7db0ed.md；均与队列SHA一致。

本批支持：力量0/4/8，喷水11/15/19，弱后11/14；轮初覆甲9/9/8/7/6。末轮2血、10挡面对14，死亡实际扣血被剩余HP截断。

反例/现状限制：覆甲下降帧不独立证明完整减层条件；末轮净扣2不代表完整所需损血2。源码moveDamageAt/monsterHpAt从首个当前进阶观测取值，roomHpCost仍要求5样本。

处置：waiting。缺原dirty运行实际消费的A10移动表和覆甲减层条件的独立冻结输入；未发现可新增的确定性当轮差异。

预期行为与下一步验证：保留现场数值，独立隔离覆甲触发并绑定历史实际输入；不把当前刷新数据库当旧运行快照。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-6dd8bbff876be528

原摘要：复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。

角色/范围：silent，策略仅本批已观察A10。证据：5PM6JAQG6FNQ，F38 T3—4；states 274308—274317；silent-0233/0209。
账本：silent-0233, silent-0209。来源任务：experience-update；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-6dd8bbff876be528.md；均与队列SHA一致。

本批支持：23最大HP的电击机器人力量2→4、同招17→19；其他实体退场后索引4→3，T3仍活着贡献攻击，T4才退场。

反例/现状限制：索引重排不是新召唤，最大HP相同也不是持久身份；另一杀序35伤/损3只是原候选预测。rollout已有HIGH_VOLTAGE_POWER成长读取。

处置：waiting。缺稳定实体/召唤代际和新同类连续出现的冻结输入，不能验证新实体不继承旧计数；替代杀序后继未知。

预期行为与下一步验证：取得带代际的连续同类召唤及退场记录，重放每个实体的计数初始化/增长；保留其他选项。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-578e415a259e6835

原摘要：核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则

角色/范围：silent，策略仅本批已观察A10。证据：8JRE1C4H4Z2W，F33 T2/T5；decisions 270216/270282/270264；states 276208—276212、276274—276278；原提案12个账本id见下。
账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。来源任务：experience-update；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-578e415a259e6835.md；均与队列SHA一致。

本批支持：同完整指纹两次T2实际损3/15、本体净扣10/17；多12血价只多7净扣。T5原日志明确HP护栏更换方案。

反例/现状限制：同局六次SL非独立样本；抽弃牌后续会重规划，首次派发完成不能证明整候选执行。现有候选/护栏/派发审计均为局部范围。

处置：waiting。缺跨抽弃牌/护栏/SL后的整候选执行绑定、逐来源兑现与独立后继校准；原线完整胜负反事实未知。

预期行为与下一步验证：先取得原答到最终派发及重规划的完整链路与可核算后继，再校准能力/资源分账；当前不拟血价权重。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-c0767768bf6a7ab1

原摘要：全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。

角色/范围：silent，策略仅本批已观察A10。证据：YF0LXT1QSTGG，F48 T1；F33第2试；decisions 271309/271348/271354；states 277327—277337、277366—277373；sl-attempts 929；silent-0079。
账本：silent-0079。来源任务：postmortem；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-c0767768bf6a7ab1.md；均与队列SHA一致。

本批支持：同完整指纹T1实损0/9、本体净扣45/38。271354确实end_turn；同局F33第二试实胜、余20血。

反例/现状限制：F48全败不能推全部SL无价值；当前候选比较execution仍unverified，不能把候选续步全部记成已完成。

处置：waiting。缺未执行续步与完整替代线的资源/胜负对照，以及同一候选跨重规划的执行归属；不能校准SL惩罚或禁止探索。

预期行为与下一步验证：分列当轮端点、候选预测和整战结果，取得独立后继线后再比较探索规则。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-a46bdb7fe711d79a

原摘要：实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。

角色/范围：silent，策略仅本批已观察A10。证据：YF0LXT1QSTGG，F48末试T3—5；states 277512—277528；silent-0021/0027/0028/0085。
账本：silent-0021, silent-0027, silent-0028, silent-0085。来源任务：postmortem；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-a46bdb7fe711d79a.md；均与队列SHA一致。

本批支持：换相212血时旧毒4与旧力15清除；T5触媒2但当前零毒。先有5敏形成23挡，第三小刀后6敏仍23挡；末轮本体净扣37。

反例/现状限制：前几次建立毒能力仍败；持有/已建/当前毒/已结算不同。当前silentPhaseCurrentFacts仅当前快照，poison_damage_already_dealt明确null。

处置：waiting。缺下一轮增段、逐阶段/逐来源收益与完整候选执行的联合校准；阶段快照不能关闭候选条件传播的宽项。

预期行为与下一步验证：冻结阶段切换、攻击段数与实际施放链，核每个候选的条件收益；不预支未来毒或后得敏捷。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-1044224808015e5c

原摘要：核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。

角色/范围：silent，策略仅本批已观察A10。证据：XP2SL33HT0D9，F33 T1/T3；decisions 271982/272195、271992/272040；states 278018—278023、278231—278236、278028—278031、278076—278079；silent-0079。
账本：silent-0079。来源任务：postmortem；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-1044224808015e5c.md；均与队列SHA一致。

本批支持：两组完整指纹相同。T3实损9/14、净扣24/27；T1实损2/10、净扣25/34；手里剑成长不能抹掉。

反例/现状限制：各SL尝试仍同局，后续抽序/施放不同；B2零胜并列不是低损新策略的受控胜负验证。

处置：waiting。缺原线继续与换线的独立完整后继、受控随机池和整战结果，不能确定低当轮损失优先的新排序。

预期行为与下一步验证：保留血价/输出/成长并列事实，按独立局后移验证；不拟全局HP惩罚常数。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-7cbc6005db712ba9

原摘要：用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。

角色/范围：silent，策略仅本批已观察A10。证据：XP2SL33HT0D9，F33末试T2—4；states 278236—278255；silent-0021/0005/0007/0063/0065/0241/0242。
账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。来源任务：postmortem；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-7cbc6005db712ba9.md；均与队列SHA一致。

本批支持：轮初14挡加6至20；镣铐爪力0→−9→0。火箭背向57→转向38→虚弱28；4敏脆弱下实际6挡。

反例/现状限制：先前其他角色数据未读取作证；原稿早期静默对照局不在本批六局分析分母，未据此重新计支持。当前公式/事实接线不等于完整候选收益。

处置：waiting。缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式已有不构成整提案duplicate。

预期行为与下一步验证：按实际前后帧分别校准临减、朝向、虚弱、毒、能力和挡；维持原权重与未观察条件。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## silent-proposal-c59f592f1427a67e

原摘要：核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证

角色/范围：silent，策略仅本批已观察A10。证据：YF0LXT1QSTGG/XP2SL33HT0D9，F48/F33上述回合；关联原提案22个账本id见下；三组同指纹对照及阶段/朝向原帧。
账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。来源任务：experience-update；实现任务：strategy-proposal。原文SHA及保存副本见original-manifest.json、originals/silent-proposal-c59f592f1427a67e.md；均与队列SHA一致。

本批支持：本批可复核三组血价差+9/−7、+5/+3、+8/+9及当前能力兑现；是两局相关尝试和六个派发锚点。

反例/现状限制：原提案101局1499房历史分母未在本批重新全量分析，原统计只保留为来源描述。SL恢复不算新回血，现场快照不能认证整线执行。

处置：waiting。六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。

预期行为与下一步验证：沿原id按子域补足完整执行和后移验证，不重复建提案，不以报告结束关闭宽父要求。
拟合/时间切分：不拟新系数；本批只作发现样本内的原帧复核，后续同角色新完整局按局号及结束时间留出，同存档尝试不得跨训练/验证集。
回退：本批没有生产改动；以后窄实现须撤源码失败、恢复通过和原沙箱测试，再以实际live源码提交登记；只保留本批追溯记录不需要回滚行为。

## 提交、测试及交付

源码撤除失败/恢复通过：未执行，没有新源码。tsc/vitest/cases均null；32个材料断言不算生产测试通过。不制造fixes、合入提交、版本或shipped。原策略和全部选项保持，因无行为发布不追加发布decision-log/eval或双通知。

30个原有静默账本条目仅经根目录learner/ledger.py update追加本批proposal路径及waiting说明，by=learner:strategy-proposal；不新建经验、不改原claim、first_run、prior、status、version、evidence或支持计数。新提案才使用proposed；本批已有shipped条目不降级。输入/原CLI回执及追加核验见ledger-updates.jsonl、ledger-update-receipt.log、ledger-append-readback.json。代码提案沿用本批10个CLI原id，不另建重复id，不改根请求、原提案或调度状态。

本批proposal.md和report.md均在本任务scratch，最终逐项proposal_results交原调度器继续保留waiting；没有实际入库/消费者采用或量化父要求完成声明。gitleaks结果与最终工作树核验见final-validation.json。

最终核验：HEAD保持完整base，git status为空、git diff --binary为空；gitleaks退出0/发现0。8268行六流加6行runs身份，共8274行；32项材料断言通过，30条CLI追加已核原前缀未改、没有写任何受保护历史字段。没有生产测试、新提交、合入或版本。

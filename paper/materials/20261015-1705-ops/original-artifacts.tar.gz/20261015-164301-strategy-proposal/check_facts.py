import collections
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {e['line']: e['row']['state'] for line in (OUT / 'evidence/states.evidence.jsonl').open()
          if (e := json.loads(line))}
checks = []

def check(name, ok):
    assert ok, name
    checks.append(name)

def powers(entity):
    return {p['power_id']: p['amount'] for p in entity['powers']}

def player(line):
    return states[line]['combat']['player']

def enemy(line, ident):
    return next(e for e in states[line]['combat']['enemies'] if e['enemy_id'] == ident)

check('蚌T3力量4、攻击15', powers(enemy(273252, 'SEWER_CLAM'))['STRENGTH_POWER'] == 4 and enemy(273252, 'SEWER_CLAM')['intents'][0]['total_damage'] == 15)
check('蚌T5力量8、攻击19', powers(enemy(273263, 'SEWER_CLAM'))['STRENGTH_POWER'] == 8 and enemy(273263, 'SEWER_CLAM')['intents'][0]['total_damage'] == 19)
check('虚弱后攻击11及14而力量仍4及8', enemy(273257, 'SEWER_CLAM')['intents'][0]['total_damage'] == 11 and enemy(273269, 'SEWER_CLAM')['intents'][0]['total_damage'] == 14)
check('吸取前力量2、后敏捷负2', powers(player(273503))['STRENGTH_POWER'] == 2 and powers(player(273504))['DEXTERITY_POWER'] == -2)
check('负敏捷两张防御合6挡', player(273507)['block'] == 6)
check('T6结算毒17加16合33', enemy(273507, 'LAGAVULIN_MATRIARCH')['current_hp'] - enemy(273508, 'LAGAVULIN_MATRIARCH')['current_hp'] == 33)
check('T6结算玩家损8', player(273507)['current_hp'] - player(273508)['current_hp'] == 8)
check('胧光T4幻象14到2仍存活', enemy(273593, 'PARAFRIGHT')['current_hp'] == 14 and enemy(273595, 'PARAFRIGHT')['current_hp'] == 2)
check('胧光T4结束后损15', player(273595)['current_hp'] - player(273596)['current_hp'] == 15)
check('两实体T5均力量6', all(powers(enemy(273596, ident))['STRENGTH_POWER'] == 6 for ident in ['PARAFRIGHT', 'THE_OBSCURA']))
check('空冒泡实际玩家血29不变', player(274379)['current_hp'] == player(274380)['current_hp'] == 29)
check('空冒泡实际能量5到4', player(274379)['energy'] == 5 and player(274380)['energy'] == 4)
check('空冒泡敌血35及72不变且无毒', all(enemy(274379, ident)['current_hp'] == enemy(274380, ident)['current_hp'] == hp and 'POISON_POWER' not in powers(enemy(274380, ident)) for ident, hp in [('THE_LOST', 35), ('THE_FORGOTTEN', 72)]))
check('甲虫睡眠3到2到1', [powers(enemy(n, 'SLUMBERING_BEETLE'))['SLUMBER_POWER'] for n in [274906, 274914, 274919]] == [3, 2, 1])
check('甲虫T4醒来攻击18', enemy(274923, 'SLUMBERING_BEETLE')['move_id'] == 'ROLL_OUT_MOVE' and enemy(274923, 'SLUMBERING_BEETLE')['intents'][0]['total_damage'] == 18)
check('甲虫T5力2、T6力4攻22', powers(enemy(274929, 'SLUMBERING_BEETLE'))['STRENGTH_POWER'] == 2 and powers(enemy(274934, 'SLUMBERING_BEETLE'))['STRENGTH_POWER'] == 4 and enemy(274934, 'SLUMBERING_BEETLE')['intents'][0]['total_damage'] == 22)
check('骑士末轮32血和20挡', player(275754)['current_hp'] == 32 and player(275754)['block'] == 20)
check('骑士末轮攻击59差7', sum(i['total_damage'] or 0 for e in states[275754]['combat']['enemies'] for i in e['intents']) == 59 and 59 - 20 - 32 == 7)
check('骑士终态三敌21/80/77均存活', [e['current_hp'] for e in states[275755]['combat']['enemies']] == [21, 80, 77])

audit = json.loads((OUT / 'selection-audit.json').read_text())
check('113候选段均无完整执行归属', len(audit['segments']) == 113 and all(s['actual_full_candidate_result'] is None for s in audit['segments']))
counts = collections.Counter(t['status'] for t in audit['observed_turns'])
check('44个整轮端点及67个未知窗口', counts == {'observed_turn_endpoints': 44, 'unknown': 67})
terminal = next(a for a in audit['observed_actions'] if a['source_line'] == 270441)['terminal_observation']
check('末轮实扣5不冒充完整入伤15', terminal['facts']['player_hp_delta'] == -5 and terminal['facts']['displayed_attack_reference']['attack_minus_block'] == 15 and terminal['facts']['actual_uncapped_damage'] is None)
summary = {'checks_passed': len(checks), 'checks': checks, 'selection_segments': len(audit['segments']),
           'selection_turn_statuses': dict(counts), 'candidate_results_unknown': True,
           'terminal_uncapped_damage': None}
(OUT / 'facts-checks.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))

# 本批十个原提案的证据复核与处置

批次20261015-164301-strategy-proposal；独立完成，未派下级。只处理dispatch.json列出的十个原id，不新领队列、不创建重复代码提案。游戏结论仅采用本批六个已核Silent A10局；同局多帧和SL不增加独立局数。

## silent-proposal-89354805ee4d7e77

来源：postmortem → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256：ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。
账本：silent-0237, silent-0238。
原请求：按静默已观测帧补齐神化在同线及后续抽牌中的升级传播，并区分持有、施放与模型覆盖；无整场转胜保证。

证据：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；states275564→275565、275679→275687、275722→275732。神化7→5能量；防御5→8、打击基础6→9、勒紧4→6、尖啸6→8，场外升级数仍4。

反例与边界：F43施放后仍损57；F45持有而未施放。没有同盘施放/不施放整战对照，不能设必打规则。

既有实现：772b839f8ada31664cb764ea9ad3bdb03da27f64、f516592fff557ef02c8ece43433706358c3f7fe6、b2805be4ba44b7375c7908d873889372cc3cfe6c均为实际live祖先；已有手牌/已知后抽传播及候选参考。actual_cast_this_fight仍为null。

处置：waiting。缺跨抽牌、选择、药水及SL重规划的实际施放持续身份和未覆盖属性组合校准；已有窄升级传播不足关闭原完整提案。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：用原帧核实同线数值、后抽传播与场外牌组不变；实际施放身份须贯穿每个重规划边界，未知交互继续显式未知。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-f2bfceddb1898dca

来源：postmortem → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256：fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。
账本：silent-0106, silent-0019, silent-0201。
原请求：核验三骑士全败候选的即时血价、击杀缺口与药水MC预算成熟度；先做同盘预算实验，缺对照时保留原护栏、留药与目标规则。

证据：VLZ6CCT8AQ0A F43/F44/F45；F45 T1 decisions269748原题明确707ms随机药水MC占用、退化推演；F45 T4为候选差，T5 states275754为32血20挡对59。

反例与边界：第二问样本改善不等于整战改善；T4少损线与攻击线没有同盘后继实打对照。末轮完整缺7血，不能据此改固定留药价或目标顺序。

既有实现：当前已有rollout成熟度/候选/用药后重规划参考；不把诊断展示或P2/C2发布当本项配对预算实验。

处置：waiting。缺完整模型下同起点、同随机池、同总预算的分阶段MC配对和候选稳定性曲线；707ms单次观察不足选择新预算常量或留药规则。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：先冻结完整盘面和覆盖，再比较原分配与分阶段MC的相同总预算结果；保留best=null和明确并列的差别，报告实际用时、样本和未覆盖项。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-283a164780d11e69

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256：78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。
账本：silent-0237, silent-0238。
原请求：神化已观察升级进入同方案与后续抽牌，保留未知边界，不定必打规则

证据：同源VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；经验silent-apotheosis-combat-upgrades，账本silent-0237/0238。

反例与边界：与89354805共享同一局及同一机制，不增加独立样本。不同战斗的胜败不构成神化收益对照。

既有实现：同89354805的实际live窄实现；经验链接已经存在。本批沿原id复核，不另建重复提案。

处置：waiting。与神化原主项同源：仍缺实际施放持续身份和未覆盖升级交互校准；经验链接及局部源码不构成整个请求的live实现。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：与原神化主项共同验收模型覆盖和生产消费者，不以另一个提案id或经验链接代替缺失校准。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-ebbfe3b97548756d

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256：08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。
账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。
原请求：逐源验证当前攻防、毒触发与持续资源，不从持有或单轮减力预支整场收益

证据：VLZ6CCT8AQ0A F43 T1/T3/T4/T5、F45 T3/T5；末轮32血20挡、四攻击段合59，毒后敌HP21/80/77均存活。原提案十五个经验及全部账本链接保持。

反例与边界：当前敏捷、覆甲、临时减力、毒触发和休息回复分源；机制生效但仍死亡不构成机制反例。单局多个帧不增加独立分母。

既有实现：已有神化、属性、毒、召唤与休息相关路径；本批16叶源码/live读回未证明十五经验全部完成联合消费者校准。

处置：waiting。缺十五经验的属性组合、升级联动、持续期限及战斗/路线/休息消费者联合校准；几组数值吻合不能认证整个复合提案。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：逐经验冻结自身支持帧及消费者，分别验当前力量/敏捷、覆甲期限、普通/升级毒触发和实际休息；路线代价仍须满足原5样本门槛，不拟合新安全血线。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-e5b87be50f28f311

来源：postmortem → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256：5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。
账本：silent-0079, silent-0021, silent-0125, silent-0018。
原请求：静默A10同盘SL以12血换7伤重犯：补齐Jev原答、HP护栏、SL换线及重规划的候选代价与实际成长兑现审计；单局不足以改阈值，保留现行为并独立验证。

证据：8JRE1C4H4Z2W F33首/第三试T2 decisions270216/270282指纹相同；末试T11 decisions270441→270442、states276433→276434，玩家5→0、敌154→130。

反例与边界：首/三试多12血换7本轮伤；末次防御替换省血但仍败，不能禁止所有防御替换。末轮显示37−22=15与实扣5严格分开。

既有实现：9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、66283dd9982bdd7f480da7a4d9bfefea0572a9ac及83512ddcd2c70fd9b983dc38524ff25c8970c1d3均是实际live祖先；离线实际读回113候选段、44整轮端点、67未知窗口；完整候选结果全部null。

处置：waiting。缺跨重规划持续候选身份和全过程生产归属校准；候选快照、单动作回执与44个整轮端点仍不能认证完整候选。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：按原问题保留Jev/护栏/SL各阶段、已派前缀、抽牌/选择/药水截断；完整归属不能用整轮净扣代替。独立新局验证归属后再考虑阈值变化。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-49632bc4878fb597

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256：aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。
账本：silent-0005, silent-0231。
原请求：把当前属性、每击修正、弱与成长分项验证，不增加统一保血或输出权重。

证据：CA5KE8GFJ9X2 F13 T3/T5：states273252/273263力量4/8、喷水15/19；虚弱后273257/273269为11/14。

反例与边界：本局没有正敏捷实测；虚弱未取消下一次加压。不能用单一步法提交或死局证明攻防权重。

既有实现：原属性/伤害路径继续使用；现有源码不等于力量、正负敏捷、虚弱与独立成长四路径的联合生产校准证明。

处置：waiting。本局缺正敏捷实测，且缺力量、正负敏捷、虚弱及独立成长四路径的联合生产校准和独立验证；不能凭单一步法实现关闭复合项。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：冻结自身实际调用状态，分项比对伤害、逐牌格挡、属性变化与成长时点，保持未观察组合未知。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-66532328a585941f

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256：56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。
账本：silent-0021, silent-0009。
原请求：持有/计划/已建立分账；如提构筑或启动权重，先做实盘兑现与受控整场验证。

证据：5PM6JAQG6FNQ F39第二试T2，decisions268455→268456、states274379→274380；向无毒失落打冒泡，玩家29血不变、能5→4、敌35/72血不变且无毒。

反例与边界：原提案引用的35是敌血，玩家实际29；原账本已有更正，本批不重复写复盘。F33建立组件并赢，但资源/敌人与F39不同，不能当受控收益对照。

既有实现：当前候选和离线端点能分开持有及建立；原要求还包括实盘兑现与受控整场验证。

处置：waiting。缺同HP、构筑、药水与完整抽序下不同启动顺序的整战配对及可复现收益函数；空打的1能量代价不足拟合启动权重。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：冻结持有/计划/实际建立时点，按同起点比较完整后继，按run_id切分独立后置验证，不按SL次数增分母。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-43a76a31ba7bdcfa

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256：f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。
账本：silent-0030, silent-0027。
原请求：冻结吸取、负敏捷与毒的分项事实；任何SL范围或换线偏好需完整同盘验证。

证据：61E2QS63Y9WU F17 T5→T6 states273503→273504：力2变未列、敏−2、敌力2；T6双防御合6，273507→273508毒17+16扣33、玩家损8。

反例与边界：F17首试60血入场七轮赢；这是原实打成功，不证明另一个SL顺序可救其他局。未列力量不伪装额外实测0层字段。

既有实现：当前属性/毒路径及SL实现保留；没有完整另一线路的因果验证。

处置：waiting。缺同起始HP、构筑和完整抽序下的SL整战比较及另一可核完整线路；负敏捷和毒端点不足改变SL范围或阈值。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：固定起点和抽序重放各路径，分开毒结算、当前格挡、恢复及SL还原；没有受控整战比较就保留SL规则。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-5264153a4a4b0e5c

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256：b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。
账本：silent-0039, silent-0209。
原请求：复验已有召唤和各实体成长；保留所有目标选项，相同推演值并列，不强制首杀。

证据：61E2QS63Y9WU F23 T4 states273593→273596：幻象14→2仍攻击，玩家25→10；本体76→41，净扣合47；T5两实体力量均6。

反例与边界：另一focus幻象的39伤零损候选没有实打，不能当胜线或收益。目标index与enemy_id均不等于跨召唤稳定实例身份。

既有实现：当前summonsAt及rollout召唤路径存在，monster-db叶与实际live逐字相同；旧召唤子项并未证明本次完整A10成长及目标排序收益。

处置：waiting。缺A10逐实体召唤、复现、退场和成长的完整生产校准及另一focus的整战后继；旧召唤子项不能证明目标排序收益。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：以逐实体完整输入核召唤/复现/成长和退场时点，保留全部focus选项及推演并列；缺另一完整后继时不改固定杀序。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## silent-proposal-bddfa690a84e03d0

来源：experience-update → strategy-proposal；角色silent，观察范围A10。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256：b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。
账本：silent-0128, silent-0079。
原请求：按当前进阶、睡眠/眩晕/成长分别验证；不把未知换线胜率或固定杀序写成规则。

证据：DUZUBAJ3A8GP F30 T1/T2/T3 states274906/274914/274919睡3/2/1；T4 274923醒来攻18；T5 274929力2、T6 274934力4攻22；sl-attempts914—917为四次尝试。

反例与边界：前三次predicted_death、末次died，均六轮失败；是同一局而非四独立样本。末试早段多扣敌血伴随多损玩家血，不能单按敌血改排序。

既有实现：当前睡眠/成长及SL的已有窄路径不能替代原提案要求的全链校准；没有新实际live完整实现证据。

处置：waiting。缺伤害唤醒、眩晕期限及恢复成长全链的生产校准与同抽换序完整后继；四次失败不足拟合血价或固定杀序。

旧/新行为：保留当前生产行为，不增加固定优先级、阈值或收益常数。预期只有验证充分后才进入实现；本批没有实际策略效果结论。
验证方法：按当前进阶逐状态校准睡眠/唤醒/眩晕/恢复成长，再比较受控同抽顺序；未知胜率和缺失后继继续未知。
回退：本批无生产改动可回退；后续实现按独立源码提交回退，保留原日志、账本、提案和失败材料。

## 两个神化项的收尾live读回更正

首次冻结live中ba23非祖先；收尾实际live7f74c828ff66e4542de0c91eecece50c36a2b080已纳入ba23，正式V5-R361/行为bc920133d586404cb08b47ffdf11f49e8d1f2b9f。此为原154303批的致命毒药5→7窄子项；89354805与283a1647仍按各自缺口waiting，不算本批实现，不增加样本或发布号。前述等待该子项合入的阶段已由外部运维推进，完整提案缺口和消费者限制保持。详见report收尾更正和external-release-readback.json。

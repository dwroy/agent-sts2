import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
RUNS = set(json.loads((OUT / 'dispatch.json').read_text())['runs'])
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifests = []
rows = {}
verified = 0
for directory in ('evidence', 'evidence-extra'):
    for item in json.loads((OUT / directory / 'evidence-manifest.json').read_text()):
        stream = item['stream']
        path = OUT / directory / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['output_sha256']
        counts = collections.Counter()
        selected = []
        with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
            for line in path.open():
                entry = json.loads(line)
                source.seek(entry['offset'])
                raw = source.read(entry['bytes'])
                assert raw.endswith(b'\n')
                assert entry['offset'] + entry['bytes'] <= item['source_size']
                assert hashlib.sha256(raw).hexdigest() == entry['sha256']
                assert json.loads(raw) == entry['row']
                assert extract.run_identity(entry['row']) == entry['run_id'] in RUNS
                counts[entry['run_id']] += 1
                selected.append(entry)
                verified += 1
        assert {r: counts[r] for r in RUNS} == item['counts']
        rows[stream] = selected
        manifests.append(item)

def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

identities = {r['run_id']: r['row'] for r in rows['runs']}
assert set(identities) == RUNS
assert all(r['character'].lower() == 'silent' and r['ascension'] == 10 for r in identities.values())
assert all(r['row']['character'].lower() == 'silent' and r['row']['ascension'] == 10 for r in rows['run-config'])
states = {r['line']: r for r in rows['states']}
decisions = {r['line']: r for r in rows['decisions']}
checks = []

def check(name, condition):
    assert condition, name
    checks.append(name)

def state(line):
    return states[line]['row']['state']

def player(line):
    return state(line)['combat']['player']

def card(line, ident):
    return next(c for c in state(line)['combat']['hand'] if c['card_id'] == ident)

def base(c, name):
    return next(v['base_value'] for v in c['dynamic_values'] if v['name'] == name)

check('F35神化能量7到5', player(275564)['energy'] == 7 and player(275565)['energy'] == 5)
check('F35防御基础5到8', base(card(275564, 'DEFEND_SILENT'), 'Block') == 5 and base(card(275565, 'DEFEND_SILENT'), 'Block') == 8)
check('F35打击基础6到9', base(card(275564, 'STRIKE_SILENT'), 'Damage') == 6 and base(card(275565, 'STRIKE_SILENT'), 'Damage') == 9)
check('F35匕首雨逐击基础4到6', base(card(275564, 'DAGGER_SPRAY'), 'Damage') == 4 and base(card(275565, 'DAGGER_SPRAY'), 'Damage') == 6)
check('F35必备工具费用1到0', card(275564, 'TOOLS_OF_THE_TRADE')['energy_cost'] == 1 and card(275565, 'TOOLS_OF_THE_TRADE')['energy_cost'] == 0)
check('F43勒紧4到6', base(card(275679, 'FASTEN'), 'ExtraBlock') == 4 and base(card(275680, 'FASTEN'), 'ExtraBlock') == 6)
check('F43尖啸6到8', base(card(275679, 'PIERCING_WAIL'), 'StrengthLoss') == 6 and base(card(275680, 'PIERCING_WAIL'), 'StrengthLoss') == 8)
check('F43场外升级数保持4', all(sum(c['upgraded'] for c in state(n)['run']['deck']) == 4 for n in (275679, 275680, 275687)))
check('8JRE首试第三试T2相同指纹', decisions[270216]['row']['fingerprint'] == decisions[270282]['row']['fingerprint'])
check('8JRE末试终局5到0', player(276433)['current_hp'] == 5 and player(276434)['current_hp'] == 0)
check('8JRE末试终局22挡', player(276433)['block'] == 22)
check('8JRE末试敌血154到130', state(276433)['combat']['enemies'][0]['current_hp'] == 154 and state(276434)['combat']['enemies'][0]['current_hp'] == 130)

interesting = {'VLZ6CCT8AQ0A': {35, 36, 37, 43, 45}, '8JRE1C4H4Z2W': {17, 33},
               'CA5KE8GFJ9X2': {13}, '61E2QS63Y9WU': {17, 23},
               '5PM6JAQG6FNQ': {33, 38, 39}, 'DUZUBAJ3A8GP': {30}}
facts = []
for entry in rows['states']:
    raw = entry['row']['state']
    combat = raw.get('combat')
    floor = (raw.get('run') or {}).get('floor')
    if not combat or floor not in interesting[entry['run_id']]:
        continue
    facts.append({'run_id': entry['run_id'], 'source_line': entry['line'], 'offset': entry['offset'],
                  'bytes': entry['bytes'], 'sha256': entry['sha256'], 'observed_ts': entry['row'].get('observed_ts'),
                  'floor': floor, 'turn': raw.get('turn'), 'screen': raw.get('screen'),
                  'player': combat['player'], 'enemies': combat['enemies'],
                  'hand': combat['hand'], 'potions': raw['run'].get('potions')})
save('selected-state-facts.json', facts)

excluded = []
own = []
for entry in rows['decisions']:
    if entry['run_id'] != '8JRE1C4H4Z2W':
        continue
    if not entry['row'].get('decision_id'):
        excluded.append({'line': entry['line'], 'reason': '元数据行没有decision_id；不制造动作身份'})
        continue
    own.append({**entry['row'], '_line': entry['line'], '_source_sha256': entry['sha256']})
save('selection-input.json', {'run': identities['8JRE1C4H4Z2W'],
                            'decisions': sorted(own, key=lambda r: r['observed_ts']),
                            'states': [{**e['row'], '_line': e['line'], '_source_sha256': e['sha256']}
                                       for e in rows['states'] if e['run_id'] == '8JRE1C4H4Z2W']})
save('selection-input-exclusions.json', excluded)
save('evidence-verification.json', {'verified_rows': verified, 'manifests': manifests,
                                  'checks': checks, 'checks_passed': len(checks),
                                  'run_identities': identities, 'selected_state_frames': len(facts)})
print(json.dumps({'verified_rows': verified, 'checks_passed': len(checks), 'selected_state_frames': len(facts),
                  'selection_decisions': len(own), 'selection_exclusions': excluded}, ensure_ascii=False))

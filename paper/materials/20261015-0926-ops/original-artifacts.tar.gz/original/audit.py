import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-091302'
OUT = ROOT / 'learner/runs/20261015-091313-35dac6bc-1ec3-4ea9-a922-5e33024df31a-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-081305-8a32fd8d-ffb6-4d82-969b-f00f47272604-fix-batch/queue-audit.json'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args], text=True).strip()


def ancestor(commit, target):
    return subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, target]).returncode == 0


base = git('rev-parse', 'HEAD')
assert base == '2be88e7c612a29b5d67cbc0905fb8163bcb33976'
assert not git('status', '--porcelain')
live = git('rev-parse', 'live')
prior_bytes = PRIOR.read_bytes()
prior = json.loads(prior_bytes)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
prefix = b''.join(queue.splitlines(keepends=True)[:prior['queue']['lines']])
assert hashlib.sha256(prefix).hexdigest() == prior['queue']['sha256']
tail = queue[len(prefix):].decode()
assert 'silent-0295' in tail and '不另列新纯bug' in tail
assert not git('diff', '--name-only', prior['base'], base, '--', 'agent', 'learner', 'knowledge/builders', 'eval')
ops_changes = git('diff', '--name-only', prior['base'], base, '--', 'ops').splitlines()
assert ops_changes == ['ops/inbox-dev.md'], ops_changes

existing = []
blobs = {}
for old in prior['existing_fixes']:
    commit = old['commit']
    assert ancestor(commit, base), commit
    assert ancestor(commit, live), commit
    source = old['inspected_source']
    current = git('rev-parse', base + ':' + source)
    previous = git('rev-parse', prior['base'] + ':' + source)
    assert current == previous, source
    blobs[source] = {'current': current, 'previous': previous, 'unchanged': True}
    existing.append({'item': old['item'], 'commit': commit, 'in_base': True, 'in_live': True,
                     'inspected_source': source, 'unchanged_since_previous_audit': True})

skipped = prior['skipped'] + [{
    'item': 'silent-0295：随机毒分配安全（X7REGM0RUNSA 新重复证据）',
    'reason': '策略类：A10 F3T3 的重复证据已登记 silent-proposal-08f72e2f585118a7，沿原 d971 策略提案链；本批不改随机分配、排序或玩法。',
}]
audit = {'base': base, 'branch': git('branch', '--show-current'), 'initial_merge': 'Already up to date.',
         'prior_audit': {'path': str(PRIOR), 'sha256': hashlib.sha256(prior_bytes).hexdigest(), 'base': prior['base']},
         'queue': {'path': str(ROOT / 'notes/fix-queue-v4.md'), 'sha256': hashlib.sha256(queue).hexdigest(),
                   'lines': len(queue.splitlines()), 'previous_prefix_verified': True, 'new_tail': tail},
         'existing_fixes': existing, 'source_blobs': blobs, 'ops_changed_paths': ops_changes,
         'unchecked_items': prior['unchecked_items'], 'skipped': skipped,
         'live_observed': live, 'merged': None, 'source_changes': [], 'new_commits': [],
         'ledger_writes': [], 'code_proposals_added': [],
         'negative_controls': '本批没有新修复；没有执行撤源码红绿，不冒称重验既有提交的负对照。'}
(OUT / 'queue-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(OUT / 'queue-snapshot.md').write_bytes(queue)
(OUT / 'source-diff.patch').write_bytes(subprocess.check_output(['git', '-C', str(WORK), 'diff', '--binary', base]))
print(json.dumps({'existing_fixes': len(existing), 'inspected_source_blobs': len(blobs),
                  'previous_queue_prefix_verified': True, 'source_changes': 0, 'base': base, 'live_observed': live}, ensure_ascii=False))

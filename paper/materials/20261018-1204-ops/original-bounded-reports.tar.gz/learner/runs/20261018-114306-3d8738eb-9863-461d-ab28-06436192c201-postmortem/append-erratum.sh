cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'

### 勘误（2026-10-18 11:59:37 +0800，learner）

“F9T4原寄生虫8血后换见三只扭动虫共81”改为“F9T4末原寄生虫8血后，T5实见四只扭动虫 WRIGGLER，HP为20／22／18／21，合81”。states.jsonl:447535逐体可核；活敌HP净推进−73及其余血量、回合、药水数字不变。
EOF

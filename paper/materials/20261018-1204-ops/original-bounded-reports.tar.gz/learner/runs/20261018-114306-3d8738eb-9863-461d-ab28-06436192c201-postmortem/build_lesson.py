import json,pathlib,collections
p=pathlib.Path(__file__).parent
ss=[json.loads(x) for x in (p/'states.jsonl').open()]
rc=json.load((p/'ET1QAZCV8GUP-resources.json').open())
ta=json.load((p/'turn-audit.json').open())
text='''
## ET1QAZCV8GUP（A10，静默猎手，第33层，死于二幕boss知识恶魔 KNOWLEDGE_DEMON：六试均31/62血、槽0火焰药水进场；前五试T7判死读档，末试T7以1血0挡对虚弱后9×3＝27攻击阵亡，完整需损27、维持该末态存活至少差27血，结算后敌仍246/399血）

- [三次二幕回血必须接上赢战消耗；打法（DeepSeek路线／构筑／休息职责，实际Codex）] F17同族神官 KIN_PRIEST及同族信徒 KIN_FOLLOWER赢后34/62，换幕首帧已56/62；F19盛碗虫（卵）BOWLBUG_EGG／盛碗虫（石）BOWLBUG_ROCK赢后32，F20外骨骼虫 EXOSKELETON零净耗，F22胧光怪 THE_OBSCURA／寄生惧魔 PARAFRIGHT喝再生药水 REGEN_POTION仍净耗30到2。F24／F28各实回18至20／38，F29事件再付3，F31感染棱柱 INFESTED_PRISM赢后35→13、两药耗尽，F32再回18至31，奖励火焰药水 FIRE_POTION才是进王存瓶。二幕三次休息合回54，三场赢战净耗24＋30＋22＝76、事件另耗3；没有另一路线／前战留药的受控胜线，不能把31血全归最后一次休息，也不称回血选择错误。（之前学过：silent-0020，S1.exp203；本次support）
- [启动晚和回血共同增加清场缺口，已持有毒牌不等于已兑现成长；打法（Jev出牌／DeepSeek构筑职责，实际Codex）] 知识恶魔 KNOWLEDGE_DEMON末试T4直伤28、毒9、铜质鳞片 BRONZE_SCALES反伤3合40，但敌实回30，325→315只净推进10；回血由297−9−3＋30＝315反算，独立回血帧未记录。到T7已发生回血30，清场至少需399＋30＝429伤；实际累计敌HP下降183、净推进153，末余246。毒雾+ NOXIOUS_FUMES虽F8已锻造，末试直到T5才建立3层；T6／T7才见它各补3毒，不能从牌组持有三张致命毒药 DEADLY_POISON推成开场已完成毒核心。T2／T3／T4实损8／13／9已把31血压到1；没有同入口提前建能力或换构筑的完整胜局，不声称这套构筑必输或改一张牌即可赢。（之前学过：silent-0102，S1.exp200；本次support）
- [末张格挡后喝速度药，只增加敏捷而未兑现新增挡；打法（代码药水兜底）] F31T7感染棱柱 INFESTED_PRISM战，先防御+ DEFEND_SILENT得10挡，再打小刀 SHIV后敌17血、14毒，代码因mod判死而求解器报安全自行饮用速度药水 SPEED_POTION（d432961）。s447822→447823敏捷2→7，现有挡10→10；随后直接退出奖励、HP13→13，没有后续挡牌。只确认耗一瓶、该实线新增挡为0；敏捷药水 DEXTERITY_POTION已在T1建立2敏捷，和此临时5敏捷分账。这不是新纯bug结论：分歧触发的保守兜底还缺无药执行的成对结果，不能宣称它导致最终败局；提案只审查零新增防护时的自主耗药与分歧证据。（之前学过：silent-0253，S1.exp198；本次support，不以相邻机制已学冒称相同错误repeat）

- [记录] 写入前已运行date。runs.jsonl:839确认为SILENT、A10、F33败，code字面值为current；run-config另记启动源码b155d00a36080418149e63d2f21b491d34d7f40a／b155d00+dirty，九项dirty为知识与生成检查材料，完整开局脏输入未记录。本次只读live源码核对HEAD为e713f211362f23e21102c63cd9a5e0195833021c，源码片段、SHA及所读文件git diff --binary保存在本任务目录，不冒充当局冻结输入。已读唯一局报notes/run-1018-1119-ET1QAZCV8GUP.md。按局号流式抽587决策、621状态、9计划、7条SL记录、1份配置；另抽32条brain，实际均codex／gpt-6.1-sol／xhigh。DeepSeek是兼容栏目，本局实际DeepSeek为0；决策窗2026-10-18T02:25:35.815Z—03:18:52.051Z内deepseek-reasoning为0条，不编其原话。下文d／s／b分别指decisions／states／brain原行号，抽取和人工审计在learner/runs/20261018-114306-3d8738eb-9863-461d-ab28-06436192c201-postmortem/。所有战斗窗口首帧均T1；前五次F33只有截断末帧，没有退出帧。表中净变化含回血／自损，不能当敌人总伤害；胜负另经奖励、推进、GAME_OVER和SL原记录核实。药槽为槽号:ID，时间均UTC。

|战序／层／敌中文名及ID|入口→出口或截断HP／上限；净变化|药槽入口→出口或截断|状态行；UTC时间|
|---|---|---|---|
'''
for i,c in enumerate(rc['combats']):
 es={}
 for r in ss:
  if c['entry']['line']<=r['_source_line']<=(c['exit'] or c['last'])['line']:
   for e in (r['state'].get('combat') or {}).get('enemies',[]):es[e['enemy_id']]=e['name']
 a=c['entry'];b=c['exit'] or c['last'];pots=lambda x:'、'.join(f'{slot}:{name}' for slot,name in x['potions']) or '空'
 status='赢' if i<11 else '败' if c['exit'] else 'SL截断，非离场'
 delta=b['hp']-a['hp'];label=f'{delta:+d}' if c['exit'] else f'已见变化{delta:+d}，净战损未记录'
 text+=f"|{i+1}／F{c['floor']}／"+'、'.join(name+' '+ident for ident,name in es.items())+f"|{a['hp']}/{a['max_hp']}→{b['hp']}/{b['max_hp']}；{label}（{status}）|{pots(a)}→{pots(b)}|s{a['line']}→s{b['line']}；{a['ts']}→{b['ts']}|\n"
text+='''
  入口资源追溯：F2／F4赢后50／49，F6无休之处事件使49/70→49/62并取得铜质鳞片；F7赢后46，F8锻造毒雾、不回血；F9赢后39，F12赢后27，F13实回18至45，F15赢后43，F16再回18至61。F17胜后34→F18首帧56为换幕已见净补22，恢复过程未记录，不归给佩尔之肉 PAELS_FLESH的选择效果。二幕F19→F20→F22→F24→F28→F29→F31→F32→F33的每段见第一条；F25／F26／F27及F30没有额外回血。全局六处营火为五次回血各18、合90，一次锻造；不要按初始70上限套每次21。五次SL分别14／1／1／4／1→31，各恢复17／30／30／27／30及同槽火焰药水，总恢复134不是真实回血，也不是新获得五瓶。F33六次都T7结束，前五次在出牌前判死；末次实际只扣剩余1血，不能把完整27攻击当实际已掉27。

  每轮实盘：下表“需”为本轮首个持牌帧的存活敌HP合计，“净推进”为该帧到下一回合首帧／退出的活体HP净差，“玩家净损”负数表示回血。净推进包括毒、反伤、回血、换体及未拍到归零的退场，不能当卡牌毛伤；逐击毛伤未记录。F9T4原寄生虫8血后换见三只扭动虫共81，净推进−73不是负伤害；F22T5幻象再次出现导致净池回升，也不称主怪回血。前五次F33的T7只有行动前帧，“0”是已观察前缀，不是已结算零伤／零损。

|层／尝试／回合|需伤的活敌HP序列|活敌HP净推进序列|玩家净损序列|
|---|---|---|---|
'''
for i,c in enumerate(ta):
 label=f"F{c['floor']}／{1 if i<11 else i-10} T1—T{len(c['turns'])}"
 if 11<=i<16:label+='（末轮截断）'
 vals=lambda key:'／'.join(str(t[key]) for t in c['turns'])
 text+=f"|{label}|{vals('need')}|{vals('enemy_net')}|{vals('hp_loss')}|\n"
text+='''
  末试恶魔T1—T7实际敌HP下降（把T4的30回血加回）为39／16／19／40／16／13／40，合183；其中T7两打击各7、回响斩击 ECHOING_SLASH为11，286→261，再结12毒及与一次3荆棘相符的下降，终局246。尚余11毒未再结算，不能补成输出。T4回血30由已见端点反算，其他死亡逐击顺序未记录；完整需损27、least-loss预计末HP−26与1−27一致。T6斗篷与匕首 CLOAK_AND_DAGGER得6挡，两尖啸 PIERCING_WAIL使力量3→−3→−9、虚弱下攻击15→11→6，实零损；T7力量已恢复3，不能沿用前轮6攻击。

  构筑、路线、休息：F1卷轴箱 SCROLL_BOXES选尖啸／致命毒药／逃脱计划 ESCAPE_PLAN组合，路线原话“双商店补强，火后挑战精英，兼顾保血与升级”（d432590）。F2取毒雾，F3接受藏宝地图 SPOILS_MAP，F4取第二尖啸，F5花89买闪亮登场 DRAMATIC_ENTRANCE，F7取手上技法 HAND_TRICK、F8锻造毒雾，F9取第三尖啸，F12取回响斩击，F15取第二致命毒药，F17取融入暗影 SHADOWMELD。F18选佩尔之肉并定“三火一精英保血线”，原话“第三轮起增能，走三火一精英保血线”（d432813）；计划想要触媒 ACCELERANT、灵动步法 FOOTWORK等，但本局并未获得，不能把want清单算入能力。F19跳牌，F20取投掷匕首+ DAGGER_THROW，F21买再生药水73金及计算下注 CALCULATED_GAMBLE 76金。F22取扫腿+ LEG_SWEEP；F23在2血时交还钥匙取100金而不打额外战；F27依计划实付176＋49＋100＋51＋51＋24＝451金买金刚杵 VAJRA、敏捷药水、删打击 STRIKE_SILENT、买第三致命毒药、斗篷与匕首、翻越撑击 FLICK_FLACK。F29为保扫腿先付3血重摇、继而删防御；F30取骨茶 BONE_TEA，F31跳牌。终局场外牌组28张，包括4打击／4防御、3尖啸／3致命毒药，永久已升级毒雾、投掷匕首、扫腿；战内临时升级不另算永久锻造。

  休息理由均来自实际Codex：F8依据当前46血及复制药水 DUPLICATOR锻造毒雾；F13用确定回血应付同族持续压力；F16明确只有11个模拟样本，不能以表面锻造优势否定回血。F24／F28为下一强制精英增加缓冲，F32实回13→31，理由是保证启动时间优于单张升级，同时0胜样本不能证明必死（d432970）。这都是日志决定，不是复盘认可任意固定选项。F14买爆炸安瓿 EXPLOSIVE_AMPOULE的理由包含帮助同族，但它实际在F15T1已经喝掉；不要当F17仍有该药。

  Jev／代码／推演：106次Jev原决策含90道战斗选线／药水题与16道选牌题，低信心<0.35共5次（F12T1选深谋远虑 THINKING_AHEAD 0.34、F22T1弃毒雾+ 0.34、F33第四试T2弃融入暗影0.20、同试T6两道选线0.08／0.22）。90道中42道题面有短程rollout best／tied，原答42/42＝100%选该集合，其余48道无此标记；不把代码rank1或整场模拟排名混进去。HP护栏、SL探索、抽弃重问改变后继，完整实线执行最优比例未记录。原始decision.decider的code435含135条续Jev，局报重列为code300＋jev-plan135；128条非续步代码战斗决定为86 plan、19 end_turn、16 lethal、6 least-loss、1 mod-lethal，涉及87个层／尝试／回合窗口，其中35个窗口没有Jev战斗决定。另46条续代码、135条续Jev；23条代码诅咒动作含确认，共12个尝试／回合选择窗口，不是23次独立诅咒。

  唯一HP护栏替换在F9T2（d432678、s447523）：原两打击＋毒雾+＋中和 NEUTRALIZE预测损12／伤15，换尖啸＋一打击＋毒雾+＋中和预测损0／伤9，条件预测省12血、少6伤。实打敌43→34兑现9直伤，下一轮22、玩家46不变；额外12敌HP下降与铜鳞四击各3反伤一致，不能混成“模型9伤却实伤21”的同口径误差。原线未执行，预测省12不是实盘反事实收益；此项给silent-0125补support，不改8点护栏。末试F33T5扫腿＋翻越撑击＋毒雾+原预测损0、总伤16，实扣翻越8再结8毒，315→299；T6最终结束前预测损0／伤10，实际299→286还含铜鳞反伤3，与10毒分账。

  focus与实际退场：21道题提供带focus字段的候选，Jev原答12次选这类候选。F12T1先退刺客 ASSASSIN_RUBY_RAIDER，T3再退弩手 CROSSBOW_RUBY_RAIDER，斧手 AXE_RUBY_RAIDER最后；F15先见贾克斯果退场、飞蝇菌子最后。F17T6／T8先后见两信徒退场，神官T9最后；同ID重排不追认两信徒原身份。F19卵先退、石最后。F22幻象可退后重返，T4原答选胧光怪、T5又选寄生惧魔、T6选胧光怪，不能把focus当单一固定击杀顺序；完整逐击身份链未记录。F33只有一个本体且未杀死。focus候选字段与玩家focus资源不是同一含义。

  药水实链：独立取得10瓶、十瓶各至少饮一次；use_potion动作15次，其中火焰药水因五次SL恢复共喝六次，不能算多拿五瓶。discard_potion为0，战内新补瓶0，最终空栏。以下“获得行／饮用后状态行”都可由原状态和对应动作回核，完整时间存resources.json与抽取件：

|药水中文名／ID（槽）|实际获得|实际饮用；证据行及UTC时间|
|---|---|---|
'''
acquisitions=[];drinks=[]
for e in rc['resource_changes']:
 if e['restart_boundary']:continue
 old,new=e['from'],e['to'];a=set(map(tuple,old['potions']));b=set(map(tuple,new['potions']))
 for item in b-a:acquisitions.append((item,new))
 for item in a-b:drinks.append((item,new))
names={'DUPLICATOR':'复制药水','ENERGY_POTION':'能量药水','COLORLESS_POTION':'无色药水','EXPLOSIVE_AMPOULE':'爆炸安瓿','FORTIFIER':'固化药水','LUCKY_TONIC':'幸运补剂','REGEN_POTION':'再生药水','SPEED_POTION':'速度药水','DEXTERITY_POTION':'敏捷药水','FIRE_POTION':'火焰药水'}
for (slot,ident),e in acquisitions:
 ds=[x for k,x in drinks if k==(slot,ident)]
 got=f"F{e['floor']}，s{e['line']}，{e['ts']}"
 drank='；'.join(f"F{x['floor']}T{x['turn']}，s{x['line']}，{x['ts']}" for x in ds)
 text+=f'|{names[ident]} {ident}（{slot}）|{got}|{drank}|\n'
text+='''
  再生药水F22的5／4／3／2／1回复逐帧可核，实回15与战斗净耗30分账。F31两瓶敏捷类分别在T1与T7饮用，末轮速度药没有后续挡牌，无法从这次实际退出反推不喝一定安全；跨战留瓶的价值与替代饮用时点胜率未记录。自主兜底见当前只读live agent/src/reflex/combat-plan.ts:3484、:3496：mod报死、求解器认为结束安全时从非空存活线选最保血动作；记录此规则交互，不列新纯bug、不取消原保护。提案交独立strategy-proposal，缺证据前保留实际行为，不拟固定药水价格／留药血线。

  路线预测／boss时钟：F8已选锻造的if_option投影下一精英46、boss54，实到F9为46、F17为61；F13已选回血的boss模拟入口60、F16为61，实到61。F24／F28已选回血均投影F31入口38、F33约27（原精确投影26.5、模拟取27），实到35／31；F29实际付3及F31实际22净耗分别列，不把事后改牌／事件全部归算法。F32所选回血投影31、实到31；不能把动作前基线“精英耗尽”当回血后预测。旧式时钟的需要／估计DPR、可活回合及同窗实打／估值比未记录。另列整场模拟：F16回血候选11样本、校准胜率82%、赢样本损血中位30、约10轮，实盘9轮赢、净耗27；F32回血候选100样本0胜、约7轮、平均敌剩244，末试实际T7死、敌246。整场有效DPR均值22.62±0.44是模拟逐场统计；末试本局已发生HP下降183/7＝26.14／轮，包含反伤，均值口径和未执行未来不同，不造校准比。若仅按已发生回血且要求七轮清完，429/7＝61.29／轮只是事后算术，不是还可安全存活七轮的预测；0胜有限样本也不是穷尽必死证明。

  机制：无新增基本机制，给已有机制补本局条件证据。金刚杵使末战已有力量1，普通打击基础6、现场实7；普通中和的升级战内实5，回响斩击基础10实11，不能当可持续加力。末战玩家无敏捷，融入暗影使T2一张防御基础5实得10，仍对18攻击损8；F31T1敏捷药建2敏，扫腿+牌文14→16、防御+8→10，敏捷当步不追补旧挡，速度药晚饮另列。末试毒雾+T5建3层，T6轮初毒7→10，结10剩9，T7再补到12，结12剩11；没有触媒，不预支多重毒触发。铜鳞开场3荆棘，全挡攻击也有反伤：T6毒10与一次3反伤使299→286，不能把13都算毒。恶魔T4后力量0→3；尖啸只是当轮暂减，T6两次减到−9后，下轮回3，9×3威胁重新出现。T1选心灵腐化 MIND_ROT_POWER 1后常见轮初四张原手牌，T5选懒惰 SLOTH_POWER 3后T6三牌用完，1能量尚在而手上技法／小刀未出；T7三攻击后剩1能量、致命毒药未出。这里只记已见名额与动作，不比较未选瓦解 DISINTEGRATION的胜负，也不推额外叠层规则。上述为silent-0011／0129／0276／0253等已见机制补证，不新增mechanic条目。

  用时／token／缓存：首末决策3196.236秒＝53分16.236秒，局报圆整53.3分钟；纯战斗墙钟未记录。Jev输入973691、输出5404、合979095，与runs.tokens一致，Jev缓存未记录。32条Codex脑请求输入5839583、输出36624（推理31933为输出子集），缓存输入148992，命中率2.55%；与兼容ds字段核回，不重复加run-plan合并调用。局报Jev约$0.0411仅估价，实际账单未记录。

  新旧与去向：三条主经验分别给silent-0020／0102／0253追加support；第三条的新规则交互没有无药实线，不按已证明错误repeat计数，原prior／first_run／status／version保留。护栏、毒雾、铜鳞和敏捷只补已有机制／取舍支持，repeats为空。已以敌中文名／ID、毒雾、尖啸、懒惰／SLOTH、速度药水／SPEED_POTION及mod-lethal检索本角色账本，并核对更早静默C48LLXBGKXQ9、UACFSW4VDDLD、JKDUL0AL0TW6、U5W7NUE925NK相关复盘，不借铁甲打法。未记录项为完整开局dirty输入、前五次F33真正退出与未执行T7后继、部分换体／幻象稳定身份及死亡／回血逐击毛伤、完整候选实际执行最优比例、无药／早饮／改路线／改构筑／早建能力的受控整战后继、旧boss时钟比值、Jev缓存、纯战斗用时及实际账单。无新纯bug；只通过CLI登记combat／potion／terminal代码提案供独立strategy-proposal实现与验证，本任务无源码、策略、发布或提交改动。
'''
(p/'lesson-draft.md').write_text(text)
print('草稿字节',len(text.encode()),'资源行',len(rc['combats']),'药水种类',len(acquisitions),'饮用动作',len(drinks))

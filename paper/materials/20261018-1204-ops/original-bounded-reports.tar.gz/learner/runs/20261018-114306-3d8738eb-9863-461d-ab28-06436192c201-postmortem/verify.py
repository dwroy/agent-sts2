import json,pathlib,collections,hashlib
p=pathlib.Path(__file__).parent
ss=[json.loads(x) for x in (p/'states.jsonl').open()];s={r['_source_line']:r['state'] for r in ss};ds=[json.loads(x) for x in (p/'decisions.jsonl').open()];d={r['_source_line']:r for r in ds};cs=json.load((p/'ET1QAZCV8GUP-resources.json').open())['combats'];ts=json.load((p/'turn-audit.json').open());bs=[json.loads(x) for x in (p/'brain.jsonl').open()]
power=lambda n,k:next((x['amount'] for x in s[n]['combat']['player']['powers'] if x['power_id']==k),0)
checks={}
def check(k,v):
 assert v,k
 checks[k]=True
check('已结束静默A10F33',json.loads((p/'runs.jsonl').read_text())['character'].lower()=='silent' and json.loads((p/'runs.jsonl').read_text())['floor']==33 and json.loads((p/'runs.jsonl').read_text())['ascension']==10)
check('抽取计数',(len(ss),len(ds),len(cs),len(bs))==(621,587,17,32))
check('全原生脑身份',all((r['engine'],r['model'],r['effort'])==('codex','gpt-6.1-sol','xhigh') for r in bs))
check('六试入口及SL',all(c['entry']['hp']==31 and c['entry']['max_hp']==62 and c['entry']['potions']==[[0,'FIRE_POTION']] for c in cs[11:]) and len(cs[11:])==6)
check('末轮玩家1血0挡',s[448046]['run']['current_hp']==1 and s[448046]['combat']['player']['block']==0)
e=s[448046]['combat']['enemies'][0];check('末轮9乘3且敌261',e['current_hp']==261 and e['intents'][0]['damage']==9 and e['intents'][0]['hits']==3)
check('实际死亡敌246',s[448047]['run']['current_hp']==0 and s[448047]['combat']['enemies'][0]['current_hp']==246)
check('二幕三赢耗76',sum(cs[i]['observed_net_hp_loss'] for i in [7,9,10])==76)
check('末试玩家逐轮净损',[t['hp_loss'] for t in ts[-1]['turns']]==[0,8,13,9,0,0,1])
check('末试净进度153',sum(t['enemy_net'] for t in ts[-1]['turns'])==153)
check('T4回血端点',s[448030]['combat']['enemies'][0]['current_hp']==297 and s[448031]['combat']['enemies'][0]['current_hp']==315 and s[448030]['combat']['enemies'][0]['powers'][1]['amount']==9)
check('速度药无即时挡',power(447822,'DEXTERITY_POWER')==2 and power(447823,'DEXTERITY_POWER')==7 and s[447822]['combat']['player']['block']==s[447823]['combat']['player']['block']==10)
check('药后直接退出HP不变',s[447824]['screen']=='REWARD' and s[447824]['run']['current_hp']==13)
check('自主耗药对应原动作',d[432961]['chosen']['action']=='use_potion' and d[432961]['expect']['potion']['id']=='SPEED_POTION')
check('护栏一次',sum('HP guard' in r['rationale'] for r in ds)==1)
check('低信心五次',sum(isinstance(r.get('confidence'),(int,float)) and r['confidence']<.35 for r in ds if r['decider']=='jev')==5)
check('药水饮用15丢弃0',sum(r['chosen']['action']=='use_potion' for r in ds)==15 and sum(r['chosen']['action']=='discard_potion' for r in ds)==0)
check('token核回',sum(r.get('usage',{}).get('inputTokens',0) for r in bs)==5839583 and sum(r.get('usage',{}).get('cacheHitTokens',0) for r in bs)==148992)
(p/'numeric-verification.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');print('关键核验',len(checks),'通过')

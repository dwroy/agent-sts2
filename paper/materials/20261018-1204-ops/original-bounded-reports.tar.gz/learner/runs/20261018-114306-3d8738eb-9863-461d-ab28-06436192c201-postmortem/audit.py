import json,pathlib,collections,datetime
p=pathlib.Path(__file__).parent
d=[json.loads(x) for x in (p/'decisions.jsonl').open()]
c=json.load((p/'ET1QAZCV8GUP-resources.json').open())
print('决策计数',collections.Counter(r['decider'] for r in d));j=[r for r in d if r['decider']=='jev'];low=[r for r in j if isinstance(r.get('confidence'),(int,float)) and r['confidence']<.35];print('低信心',len(low),[(r['_source_line'],r['floor'],r['turn'],r['label'],r['confidence']) for r in low])
js=[r for r in j if r['label'].startswith('combat/plan-choice')];ranked=[r for r in js if (r.get('rollout') or {}).get('best')];print('Jev选线',len(js),'有best',len(ranked),'选best',sum(r.get('rollout_best_chosen') is True for r in ranked))
parse=lambda v:json.loads(v) if isinstance(v,str) and v.startswith('{') else v
rb=[];focus=[]
for r in js:
 criteria=(r.get('questions',{}).get('plan') or {}).get('criteria',{});opts={k:parse(v) for k,v in criteria.items()};best=[k for k,v in opts.items() if isinstance(v,dict) and (v.get('rollout_best') or v.get('rollout_tied_best'))];choice=(r.get('answers',{}).get('plan') or {}).get('choice')
 if best:rb.append((r['_source_line'],choice,best,choice in best))
 if any(isinstance(v,dict) and 'focus' in v for v in opts.values()):focus.append((r['_source_line'],choice,opts.get(choice,{}).get('focus'),{k:v.get('focus') for k,v in opts.items() if isinstance(v,dict) and 'focus' in v}))
print('题面best/tied',len(rb),sum(x[3] for x in rb));print('focus',len(focus),sum(x[2] is not None for x in focus),focus)
code=[r for r in d if r['decider']=='code' and r['label'].startswith('combat/') and r['label']!='combat/plan-continue'];keys=lambda r:(r['floor'],r.get('sl_attempt') or 1,r['turn']);cs=set(map(keys,code));jk=set(map(keys,[r for r in j if r['label'].startswith('combat/')]));print('代码自主',len(code),collections.Counter(r['label'] for r in code),'回合窗口',len(cs),'无Jev',len(cs-jk))
print('tokens',[(who,sum(r.get('usage',{}).get('input_tokens',0) for r in d if r['decider']==who),sum(r.get('usage',{}).get('output_tokens',0) for r in d if r['decider']==who)) for who in ['jev','codex']]);print('用时', (datetime.datetime.fromisoformat(d[-1]['ts'])-datetime.datetime.fromisoformat(d[0]['ts'])).total_seconds())
for r in d:
 if r['chosen'].get('action') in ['use_potion','discard_potion'] or 'HP guard' in r['rationale']:
  print('药/护栏',r['_source_line'],r['floor'],r['turn'],r.get('sl_attempt'),r['chosen'],r.get('expect'),r['rationale']);
  if 'HP guard' in r['rationale']:print('审计',r.get('selection_audit'))
print('资源非战斗')
for r in c['resource_changes']:
 if r['combat_sequence'] is None:print(r)
print('每战每轮 可见活体HP净降/所需清池')
for a in c['combats']:
 print(a['sequence'],a['floor'],[(t['turn'],t['live_enemy_hp_start'],t['net_live_enemy_hp_loss'],t['visible_enemy_hp_loss_lower_bound'],t['observed_hp_added'],t['gaps']) for t in a['enemy_hp_audit']['turns']])
print('休息路线投影与时钟')
for r in d:
 if r['label']=='rest/plan':
  q=r.get('questions',{}).get('pick',{});facts=q.get('facts',{});print('休息',r['_source_line'],r['floor'],r['rationale'],'chosen',r.get('answers'), 'factkeys',list(facts) if isinstance(facts,dict) else None)
  for k,v in (facts.items() if isinstance(facts,dict) else []):
   if any(x in k.lower() for x in ['clock','route','hp','path']):print(k,json.dumps(v,ensure_ascii=False)[:7000])

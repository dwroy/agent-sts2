import json
from collections import defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
frames = json.loads((OUT / "target-frames.json").read_text())
index = {f["line"]: f for f in frames}
by_observed = defaultdict(list)
for raw in (OUT / "evidence/states.evidence.jsonl").open():
    item = json.loads(raw)
    if item["line"] in index:
        row = item["row"]
        by_observed[(row.get("observed_ts"), row.get("fingerprint"))].append(index[item["line"]])

decisions = {}
groups = defaultdict(list)
for raw in (OUT / "evidence/decisions.evidence.jsonl").open():
    item = json.loads(raw)
    row = item["row"]
    decisions[item["line"]] = item
    if row.get("screen") not in {"COMBAT", "CARD_SELECTION"}:
        continue
    match = by_observed.get((row.get("observed_ts"), row.get("fingerprint")), [])
    if len(match) == 1:
        groups[(item["run_id"], row["floor"], row.get("sl_attempt") or 1, row["turn"])].append({
            "decision_line": item["line"], "frame": match[0],
            "chosen": row.get("chosen"), "expect": row.get("expect"),
            "label": row.get("label"),
        })
turns = []
for (run, floor, attempt, turn), rows in groups.items():
    turns.append({"run_id": run, "floor": floor, "attempt": attempt, "turn": turn,
                  "first": rows[0], "last": rows[-1], "decision_count": len(rows)})
(OUT / "observed-turns.v2.json").write_text(json.dumps(turns, ensure_ascii=False, indent=2) + "\n")

checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({"核验": name, "实值": actual, "对照": expected})


check("F43神化实付能量", index[275679]["energy"] - index[275680]["energy"], 2)
check("F43 T1实损", index[275679]["hp"] - index[275687]["hp"], 13)
check("F43 T1敌本体净扣", index[275679]["enemies"][0]["current_hp"] - index[275687]["enemies"][0]["current_hp"], 51)
check("8JRE首试/第三试T2原观测指纹相同", decisions[270216]["row"]["fingerprint"] == decisions[270282]["row"]["fingerprint"], True)
for attempt, expected in [(1, (3, 10)), (3, (15, 17))]:
    a = groups[("8JRE1C4H4Z2W", 33, attempt, 2)][0]["frame"]
    b = groups[("8JRE1C4H4Z2W", 33, attempt, 3)][0]["frame"]
    actual = (a["hp"] - b["hp"], a["enemies"][0]["current_hp"] - b["enemies"][0]["current_hp"])
    check(f"8JRE第{attempt}试T2当轮实损/净扣", list(actual), list(expected))
check("POUNCE后FREE_SKILL_POWER实见", index[275702]["powers"].get("FREE_SKILL_POWER"), 1)
check("生存者后FREE_SKILL_POWER消失", index[275703]["powers"].get("FREE_SKILL_POWER", 0), 0)
check("该次生存者未耗能", index[275702]["energy"] - index[275703]["energy"], 0)
snake_cost = lambda line: next(c["energy_cost"] for c in index[line]["hand"] if c["card_id"] == "SNAKEBITE")
check("该次蛇咬预览费用恢复", [snake_cost(275702), snake_cost(275703)], [0, 2])
(OUT / "observation-checks.v2.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
print("原帧/算术核验", len(checks), "项；这不是生产消费者重放或源码测试")
for row in turns:
    if (row["run_id"], row["floor"], row["turn"]) in {
        ("CA5KE8GFJ9X2", 13, 1), ("CA5KE8GFJ9X2", 13, 3), ("CA5KE8GFJ9X2", 13, 5),
        ("5PM6JAQG6FNQ", 39, 2), ("61E2QS63Y9WU", 17, 6),
        ("61E2QS63Y9WU", 23, 4), ("DUZUBAJ3A8GP", 30, 6),
    }:
        a, b = row["first"]["frame"], row["last"]["frame"]
        print(row["run_id"], row["floor"], row["attempt"], row["turn"],
              "source", a["line"], b["line"], "hp", a["hp"], b["hp"],
              "power", a["powers"], "enemies", [(e["enemy_id"], e["current_hp"], e["powers"]) for e in a["enemies"]])

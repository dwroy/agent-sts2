import datetime as dt
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = "214f73468f471d26aebbc16cd31c485633476b0c"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == BASE
dispatch = json.loads((OUT / "dispatch.json").read_text())
proposals = json.loads((OUT / "dispatched-proposals.json").read_text())
sources = json.loads((OUT / "source-manifest.json").read_text())
streams = json.loads((OUT / "evidence-verification.json").read_text())
reasons = [
    "普通神化及17种已观察升级已有局部实现；突袭免费技能、反射等剩余效果、实际施放记录及后继消费尚未闭环，不能认定整项完成。",
    "缺同起点、同随机池、同总预算的配对实验；F45不同题的1/12与12/12药水样本不能校准预算、持有价或目标顺序。",
    "与原神化提案共享证据和局部源码；实际施放及完整后继消费未闭环，同主题不足以登记整项duplicate。",
    "15个机制及资源子项尚缺逐源的生产调用联合校准；局部公式、观察性血药链与知识文字不证明整项完成。",
    "已具候选、首动作回执及离线区间子实现；完整候选执行归属和全部中断后的实际效果仍未验证，单局不足以改SL或护栏规则。",
    "缺力量、敏捷、虚弱、独立成长四路径的完整冻结生产输入与联合校准；蚌的覆甲完整减层条件也未隔离。",
    "缺同起始HP、构筑和抽序下不同启动顺序的完整对照；末试空打冒泡与F33建立能力后的胜利不能单独拟合启动阈值。",
    "缺相同起点与已知抽序下可救活的另一完整SL线路；族母首试获胜及吸取/负敏捷/毒事实不足以修改SL门槛。",
    "召唤/成长局部模型已有，仍缺A10召唤代际和航行的完整冻结生产校准及另一目标顺序的完整后继。",
    "缺睡眠、醒来、眩晕、成长的完整生产链校准及同抽另一顺序的完整获胜线路；四次失败不能拟合排序血价。",
]
evidence = [
    "VLZ6CCT8AQ0A F35/F43 T1、F36 T2、F37 T5、F45 T1",
    "VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5",
    "VLZ6CCT8AQ0A F35/F43 T1、F45 T1",
    "VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5及实际营火链",
    "8JRE1C4H4Z2W F33首/三试T2、第二试T5、F17 T6、末试T11",
    "CA5KE8GFJ9X2 F13 T1/T3/T5",
    "5PM6JAQG6FNQ F33、F39末试T2",
    "61E2QS63Y9WU F17 T5/T6",
    "61E2QS63Y9WU F23 T1—T6，重点T4/T5",
    "DUZUBAJ3A8GP F30 T1—T6，四试分列",
]
expected = [
    "仅传播本角色实见升级；未知卡保留缺口；持有、计划、模拟与实际施放分账，禁止必打神化规则。",
    "诊断保留不可比较/并列和药水样本成熟度；未有配对结果前保留原预算、持有价与目标选择。",
    "沿两原ID共用证据去重实现；保留experience来源链接，不新造重复提案。",
    "按现场属性、逐攻击段、逐挡牌、毒触发和实际剩余资源计算，不预支持有能力或投影资源。",
    "审计原答→护栏→SL→实际派发→重规划，不把候选差额当已实现收益。",
    "现场力量、敏捷、弱与后续成长分别验证，不能用虚弱冻结成长或新增统一权重。",
    "持有/计划/已建立分账；无毒目标的冒泡实际零效果不补成启动收益。",
    "吸取后的当前属性与实际毒结算分别保留，不据首试赢局改换线偏好。",
    "召唤实体与当前主体分账，保留所有目标；相同推演值并列，不指定首杀。",
    "睡层、醒来、眩晕和增长分别读取，不凭四败设固定排序或改血价权重。",
]
results = [{"id": ident, "state": "waiting", "reason": reasons[i]}
           for i, ident in enumerate(dispatch["proposal_ids"])]
(OUT / "proposal-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
table = ["| 原提案 | 证据局/层/回合 | 既有账本 | 本批处置 |", "|---|---|---|---|"]
sections = []
for i, ident in enumerate(dispatch["proposal_ids"]):
    p = proposals[ident]
    table.append(f"| `{ident}` | {evidence[i]} | {', '.join(p['ledger'])} | waiting |")
    sections.append(f"""## {i + 1}. {ident}

原提案：`{p['proposal']}`；保存副本 `original-{i + 1:02}.md`，SHA256 `{p['proposal_sha256']}` 已复核。
来源任务 `{p['source_task']}` → `strategy-proposal`；账本：{', '.join(p['ledger'])}。
证据：{evidence[i]}。本批仅本角色A10六局；同局SL或相邻帧不增加独立局数。

旧行为/已有实现与未实现原因：{reasons[i]}

预期行为：{expected[i]}

验证方法：使用保存的原字节状态、决策和对应固定知识输入逐步核验；涉及模型修复必须撤生产源码失败、恢复通过，随后执行原沙箱检查。不得依赖刷新知识、在线模型或未实打候选来补结果。本批没有源码修复，未执行上述生产验证。

反例/限制：参见下述分组核验和原文。机制成立后的败局不当机制反例；原线未知后继不当替线胜利。没有拟合新权重或阈值；六局为发现/回归证据，不冒称时间后置盲测。

回退：本批无生产代码可回退；后续实现按自己的源码提交回退，保留证据与本ID历史。
""")
proposal_text = """# 本批静默猎手十项策略提案复核

本批为普通消费队列任务，不承接手动专题。十项均 waiting；无新增提案ID、源码、知识或策略参数修改。依据原提案和本批实际证据保留缺口，不能用已上线的局部子实现关闭宽提案。

角色 silent；已观察范围 A10。授权 Roy-2026-10-07-learning 仅提供权限，不提供游戏事实。

""" + "\n".join(table) + "\n\n" + "\n".join(sections)
(OUT / "proposal.md").write_text(proposal_text)

stream_table = ["| 流 | 源字节截点 | 选中行数 | 原始坏行数 |", "|---|---:|---:|---:|"]
for r in streams:
    stream_table.append(f"| {r['stream']} | {r['source_size']} | {r['verified_rows']} | {r['invalid_lines']} |")
source_table = ["| 基线文件 | 该路径最后变更提交 | 基线/live HEAD字节相同 |", "|---|---|---|"]
for r in sources:
    source_table.append(f"| `{r['path']}` | `{r['last_path_commit']}` | {'是' if r['base_equals_live_head'] else '否'} |")
report = f"""# 20261018-114302 静默策略提案批次报告

记录时间：{dt.datetime.now().astimezone().isoformat(timespec='seconds')}。

## 交付与身份

十个派发ID逐项复核，全部 waiting。没有新增源码、知识、规则参数或经验条目，没有源码提交、live合入、eval版本或shipped登记。`fixes=[]`、`merged=null`，`tests={{"tsc":null,"vitest":null,"cases":null}}`。原字节/算术检查不能当作源码测试。

初始HEAD `a41c2bd8305c310fa0396a7f49e5c6d2e8ecc934`，初始tracked/index干净。普通批次按要求 `git merge --no-edit main` 快进到完整基线 `{BASE}`，无冲突。之后本批未再合main；交付HEAD保持此base。

根learn.json仅取本批：task=strategy-proposal、character=silent、reason=proposal、worktree匹配，带本批十个proposal_ids；没有research_request、implementation_request或proposal_repair。根 `notes/strategy-research-silent.json` 绑定的是20261010-150327旧批次，故不接专题、不读取其work_spec/manifest、不关闭其父请求。保存身份见 `dispatch.json`。

六局与派发集合完全一致，runs.jsonl逐项核为SILENT/A10：{', '.join(dispatch['runs'])}。只使用这些局作为本批实证；没有把账本/经验的全历史支持数当成本批已分析局数。未增派agent。

模型运行参数限制：沙箱 `/proc` 仅见隔离工具进程；按派发PID和当前祖先读取均未取得可认证的Codex原生模型/effort参数。见 `runtime-arguments.json`、`runtime-ancestors.json`。不由任务文字或默认配置宣称已核实或已切换运行模型；本批未改模型、强度、服务档或权限。

## 证据完整性

共用extract_evidence.py抽取六个默认流；另用同入口抽取runs/fight-plans。两份原始manifest在 `evidence/`、`evidence-extra/`。每流独立冻结source_size，并非原子全流快照。八流合计6995行，全部逐offset/bytes/SHA256回读原日志、JSON等值、显式归局和输出SHA核验通过，见 `evidence-verification.json`、`verify-evidence.log`。

{chr(10).join(stream_table)}

states/decisions/brain各2条全源坏行是抽取器的扫描计数，不能据此推定属于六局。所有流incomplete_lines=0。fight-plans选中0仅描述该2233957字节截点，不推断目标对局原日志缺失。run-plans以顶层run显式归局，共33行，不将正文提及当身份。没有覆盖任何旧截点报告或零行原稿。

十份原提案Markdown逐份SHA与专用队列一致，保存 `original-01.md` 至 `original-10.md` 和 `dispatched-proposals.json`。本角色原复盘的六个段落保存 `prior-lessons-six-runs.md`；原历史未改写。关联经验仅从 `knowledge/characters/silent/experience.json` 按原ID选择，保存 `linked-experience.json`，不引入新规则或搬用其他角色经验。

## 已核实事实及边界

1. **神化与未知效果**：VLZ F43 s275679→275680实付2能；s275679→275687从90HP到77HP、敌254到203，本轮实损13/净扣51。d269706的43伤/损14与施放后d269707的51伤/损13分列。普通神化局部传播已存在：源码PAIRS含17种卡（含文字型萎靡），致命毒药5→7源`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`已是实际live祖先；不把它登记成本批新实现。
2. **突袭缺口具体化**：VLZ F35T2/F37T3/F43T5三次实付2能后有FREE_SKILL_POWER=1。s275702→275703生存者零耗能，免费状态消失，同手蛇咬费用0→2；并非全部技能永久免费。当前源码对相应突袭+保留known=false。此处能证明有限状态/预览变化，尚未交付在生产求解入口跨重规划保存原费、消费和恢复费用的验证；X费、额外生成/抽牌、重放和叠加未知。原神化报告要求未知效果仍显式保留，不能只补伤害升级即宣称全覆盖。未据本次观察造新ID、固定优先级或胜率。
3. **预算/三骑士**：VLZ d269748记录随机药水MC707ms、退化horizon1/best=null；d269754是不同局面下的后续药水问答，不能把1/12与12/12当同盘配对实验。F45T4候选31损/32伤与实选13损/24伤只是可见取舍；未执行高伤线。T5玩家32HP/20挡对减力后59攻击需损39，差7血，三敌仍活。不改预算、留药、护栏或固定focus。
4. **SL原答/替换**：8JRE d270216/d270282的原观测fingerprint完全相同。对应首试/第三试T2至下一轮入口实际分别损3/15、敌净扣10/17，多12血换7本轮伤。第三试原题明确为0/24与5/24死亡样本，不能因预期损血同封顶47而说相同死亡率。首试题本身是8样本，不能挪用第三试24样本。d270264原答plan4的16损/43伤与护栏替线分列；完整执行与全场因果未认证。
5. **蚌属性和成长**：CA5 F13可操作T1/T3/T5的源s273239/273253/273264分别见力0/4/8；原帧记录攻击11/15/19，弱后11/14不停止后续加压。末轮s273268的2HP/10挡与弱后14攻击，完整未挡4，最终s273269才为GAME_OVER。未取得计划步法，不能补正敏捷；未隔离完整覆甲减层条件。
6. **启动分账**：5PM F39末试T2 s274379—274383无NOXIOUS_FUMES_POWER；原决策及后继状态核验冒泡指向无毒失落、能量消耗而未建立毒。F33已建立毒雾/触媒/群蛇并赢，构筑、资源和敌人同时变化，不能据此拟合启动阈值或断言提前建立即可赢F39。
7. **吸取与毒**：61E F17T6 s273504见玩家敏捷−2、敌力2/毒17；两防御各3，已建触媒下结算17+16。该场首试60HP进、七轮获胜，不是另一SL路径的受控对照，不改SL门槛。
8. **召唤与成长**：61E F23T4 s273593起主体及幻象力量各3，后续航行升至6；原本体线47伤/损15兑现，幻象余2仍攻击，T5才退。另一focus候选39伤/零损未实打；不设统一先杀。实体index可能重排，不据索引独自认证召唤代际。
9. **睡眠/成长**：DUZ F30四试均失败；末试T6 s275018见甲虫59HP、8毒、4力，后续s275022玩家1HP/16挡，对22攻击；s275023为最终GAME_OVER。前三次是在必死检查后截断，不能把最终死亡帧归给首试或为其补敌方结算。原末试T4多3敌伤/多2玩家损也不是胜线验证，不拟合全死排序权重。

以上事实索引见 `target-frames.json`、`selected-decisions.json`、`observed-turns.v2.json`；10项同帧/算术断言见 `observation-checks.v2.json`。这些检查未调用生产消费者、求解器或游戏模拟，未调模型/网络，不证明新行为收益。六局均是旧发现/回归样本；同局重打不扩独立分母。

## 十项处置

{chr(10).join(table)}

每项具体waiting理由、预期行为、验证和回退在本目录 `proposal.md`，机器结果在 `proposal-results.json`。已有局部源码不是宽提案整项implemented/duplicate；没有将request_id伪装为代码提案ID，也没有另建重复ID。

## 源码定位与实际live边界

冻结核对时live HEAD为 `{sources[0]['live_head']}`。16份所读基线源码按Git blob/字节数/SHA保存 `source/*.txt`；元数据见 `source-manifest.json`，精确差异见 `source-base-live.patch`。所列最后路径变更提交均已核为该live HEAD祖先；这只认证这些提交及所读叶文件，不能据此称对应宽机制或整树已完全验证。

{chr(10).join(source_table)}

11叶基线/live HEAD同字节，5叶不同；16叶live工作字节均等于其当时HEAD。不同项包含署名注释与其他已有行为补丁，不由本批覆盖。历史对局为+dirty，未复原当时完整执行树/知识快照，不拿当前源码冒充当时源码。怪物数据库入口按当前进阶读取，房间代价现有MEASURED_ROOM_MIN_N=5保留；本批没有新增规则或调整两者门槛。

## 初稿、更正和未执行项

首次字段探查遇到非战斗帧combat=null产生TypeError，随后按combat为对象过滤；一个只读路径探查core/controller.ts不存在，实际接线在hand/loop.ts，未据探查失败判产品bug。初版observed-turns将GAME_OVER中null sl_attempt并到首试；最终版先排除非COMBAT/CARD_SELECTION，四次DUZ分别核回。初版JSON/log和v2全部保留，最终结论只用v2；没有覆盖失败历史或把此更正当源码红绿。

无新增生产源码/知识修改，故不运行tsc/vitest、不撤源码、不制造失败/恢复结果、不提交、不扫提交或合入live，不创建版本或发送上线双通知。根账本只经既有CLI追加本批报告/提案追溯及waiting说明；不新增support/repeat、不改claim、首证、prior、evidence、原状态、版本或effect，不将已有shipped机制降级。逐条处置仍由原调度器消费，实际入库、消费者采用和Roy学习父要求均未在本批关闭。

最终文件：本报告 `{OUT / 'report.md'}`；提案 `{OUT / 'proposal.md'}`；完成JSON `{OUT / 'result.json'}`。工作树最终清洁核对另存 `final-worktree-check.json`。
"""
(OUT / "report.md").write_text(report)
result = {
    "task": "strategy-proposal", "character": "silent", "batch": "20261018-114302-strategy-proposal",
    "base": BASE, "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
    "tests": {"tsc": None, "vitest": None, "cases": None},
    "code_proposals": dispatch["proposal_ids"], "implementation_domains": [],
    "proposal_results": results, "report": str(OUT / "report.md"),
}
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print("报告与逐项处置已保存，等待账本追加和最终工作树核验")

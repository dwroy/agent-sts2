import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
FLOORS = {
    "VLZ6CCT8AQ0A": {35, 36, 37, 43, 45},
    "8JRE1C4H4Z2W": {17, 33},
    "CA5KE8GFJ9X2": {13},
    "5PM6JAQG6FNQ": {33, 39},
    "61E2QS63Y9WU": {17, 23},
    "DUZUBAJ3A8GP": {30},
}


def powers(values):
    return {p["power_id"]: p["amount"] for p in (values or [])}


def card(raw):
    return {key: raw.get(key) for key in (
        "card_id", "index", "upgraded", "energy_cost", "rules_text",
        "resolved_rules_text", "dynamic_values", "enchantment", "costs_x",
    )}


frames = []
upgraded = defaultdict(dict)
counts = Counter()
selected = OUT / "evidence/states.evidence.jsonl"
for line in selected.open():
    entry = json.loads(line)
    raw = entry["row"]["state"]
    run = entry["run_id"]
    counts[run] += 1
    assert str(raw["run"]["character_id"]).lower() == "silent"
    assert raw["run"]["ascension"] == 10
    if raw["run"]["floor"] not in FLOORS[run]:
        continue
    combat = raw.get("combat")
    if not isinstance(combat, dict):
        continue
    player = combat.get("player") or {}
    item = {key: entry[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}
    item.update({
        "observed_ts": entry["row"].get("observed_ts"),
        "floor": raw["run"]["floor"], "turn": raw.get("turn"),
        "screen": raw.get("screen"),
        "hp": player.get("current_hp"), "max_hp": player.get("max_hp"),
        "energy": player.get("energy"), "block": player.get("block"),
        "powers": powers(player.get("powers")),
        "hand": [card(c) for c in combat.get("hand", [])],
        "enemies": [{
            **{key: e.get(key) for key in (
                "index", "enemy_id", "current_hp", "max_hp", "block",
                "is_alive", "move_id", "intents",
            )}, "powers": powers(e.get("powers")),
        } for e in combat.get("enemies", [])],
    })
    frames.append(item)
    if run == "VLZ6CCT8AQ0A" and item["floor"] in {35, 36, 37, 43}:
        for c in combat.get("hand", []):
            if c.get("upgraded"):
                signature = json.dumps(card(c), ensure_ascii=False, sort_keys=True)
                upgraded[c["card_id"]].setdefault(signature, {"line": entry["line"], "card": card(c)})

(OUT / "target-frames.json").write_text(json.dumps(frames, ensure_ascii=False, indent=2) + "\n")
(OUT / "observed-upgraded-hand.json").write_text(json.dumps({k: list(v.values()) for k, v in upgraded.items()}, ensure_ascii=False, indent=2) + "\n")
print("各局状态行数", dict(counts))
print("目标帧数", len(frames))
print("神化战内实见升级牌", sorted(upgraded))

if not (OUT / "evidence/evidence-manifest.json").exists():
    print("抽取尚未完成；当前结果仅供探查，不作验收计数")

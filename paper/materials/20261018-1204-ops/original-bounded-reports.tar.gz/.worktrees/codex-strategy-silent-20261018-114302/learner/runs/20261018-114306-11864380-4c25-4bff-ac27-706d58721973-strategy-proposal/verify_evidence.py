import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extractor", ROOT / "learner/extract_evidence.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
reports = []
for folder in ("evidence", "evidence-extra"):
    manifest = json.loads((OUT / folder / "evidence-manifest.json").read_text())
    for stream in manifest:
        target = OUT / folder / (stream["stream"] + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        with (Path("/home/dw/Projects/agent-sts2/logs") / (stream["stream"] + ".jsonl")).open("rb") as source:
            previous = -1
            for line in target.open("rb"):
                digest.update(line)
                item = json.loads(line)
                assert previous < item["offset"]
                previous = item["offset"]
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert len(raw) == item["bytes"] and raw.endswith(b"\n")
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                row = json.loads(raw)
                assert row == item["row"]
                assert module.run_identity(row) == item["run_id"]
                counts[item["run_id"]] += 1
        assert digest.hexdigest() == stream["output_sha256"]
        assert {k: counts[k] for k in stream["counts"]} == stream["counts"]
        reports.append({**stream, "verified_rows": sum(counts.values()),
                        "raw_bytes_sha_identity_verified": True})
(OUT / "evidence-verification.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n")
print("八流原字节/JSON/显式身份与输出哈希核验通过；共", sum(r["verified_rows"] for r in reports), "行")
for r in reports:
    print(r["stream"], r["verified_rows"], "源截点", r["source_size"], "原坏行", r["invalid_lines"])

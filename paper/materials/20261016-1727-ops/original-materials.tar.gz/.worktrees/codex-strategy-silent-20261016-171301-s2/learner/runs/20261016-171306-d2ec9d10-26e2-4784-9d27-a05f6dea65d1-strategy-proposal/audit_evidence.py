import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location("evidence_extractor", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((SCRATCH / "dispatch.json").read_text())
runs = set(dispatch["runs"])
states = {}
decisions = {}
attempts = []
verified = []
handles = {}

for entry in json.loads((SCRATCH / "evidence/evidence-manifest.json").read_text()):
    stream = entry["stream"]
    path = SCRATCH / "evidence" / (stream + ".evidence.jsonl")
    counts = Counter()
    digest = hashlib.sha256()
    for raw in path.open("rb"):
        digest.update(raw)
        envelope = json.loads(raw)
        row = envelope["row"]
        run = envelope["run_id"]
        assert run in runs and extractor.run_identity(row) == run
        source = envelope["source"]
        if source not in handles:
            handles[source] = Path(source).open("rb")
        handle = handles[source]
        handle.seek(envelope["offset"])
        original = handle.read(envelope["bytes"])
        assert envelope["offset"] + envelope["bytes"] <= entry["source_size"]
        assert original.endswith(b"\n")
        assert hashlib.sha256(original).hexdigest() == envelope["sha256"]
        assert json.loads(original) == row
        counts[run] += 1
        if stream == "states":
            state = row["state"]
            if state.get("run"):
                assert state["run"]["character_id"] == "SILENT"
                assert state["run"]["ascension"] == 10
            states[envelope["line"]] = envelope
        elif stream == "decisions":
            decisions[envelope["line"]] = envelope
        elif stream == "sl-attempts":
            attempts.append(envelope)
    assert digest.hexdigest() == entry["output_sha256"]
    assert {run: counts[run] for run in dispatch["runs"]} == entry["counts"]
    verified.append({"stream": stream, "rows": sum(counts.values()), "source_size": entry["source_size"],
                     "output_sha256": digest.hexdigest(), "verified_bytes_and_identity": True,
                     "invalid_source_lines": entry["invalid_lines"]})
for handle in handles.values():
    handle.close()


def state(line):
    return states[line]["row"]["state"]


def hp(line):
    s = state(line)
    return (s.get("combat") or {}).get("player", {}).get("current_hp", s["run"]["current_hp"])


def enemy(line, enemy_id):
    return next(e for e in state(line)["combat"]["enemies"] if e["enemy_id"] == enemy_id)


def power(line, enemy_id, power_id):
    return next((p["amount"] for p in enemy(line, enemy_id)["powers"] if p["power_id"] == power_id), 0)


checks = []


def check(label, actual, expected, lines):
    assert actual == expected, (label, actual, expected)
    checks.append({"结论": label, "实际值": actual, "引用": [
        {key: states[line][key] for key in ["run_id", "source", "line", "offset", "bytes", "sha256"]}
        for line in lines]})


def summary(run, floor, attempt, turn):
    envelope = next(e for e in attempts if e["run_id"] == run and e["row"]["floor"] == floor
                    and e["row"]["attempt"] == attempt)
    row = next(t for t in envelope["row"]["summary"]["turns"] if t["turn"] == turn)
    return row, {key: envelope[key] for key in ["run_id", "source", "line", "offset", "bytes", "sha256"]}


comparisons = []
for run, first, last in [("NHA2KW0RB7VP", 1, 6), ("RC61MFQM63Y6", 1, 6)]:
    branches = []
    for attempt in [first, last]:
        t1, reference = summary(run, 33, attempt, 1)
        t2, _ = summary(run, 33, attempt, 2)
        branches.append({"尝试": attempt, "T1起血": t1["hp"], "T2起血": t2["hp"],
                         "T1实损": t1["hp"] - t2["hp"], "T1行动": t1["plays"],
                         "T1敌血": t1["enemies"], "T2敌血": t2["enemies"], "引用": reference})
    assert [b["T1实损"] for b in branches] == ([1, 7] if run.startswith("NHA") else [4, 8])
    comparisons.append({"局号": run, "分支": branches, "限制": "同局T1差额；后续抽弃和预算未控制，不能归因整战收益。"})

check("弃牌边界1血16挡", [hp(284817), state(284817)["combat"]["player"]["block"]], [1, 16], [284817])
check("精确切击离手", ["PRECISE_CUT" in [c["card_id"] for c in state(n)["combat"]["hand"]]
                      for n in [284817, 284818]], [True, False], [284817, 284818])
check("卵毒后仍剩2血且玩家死亡", [enemy(284821, "BOWLBUG_EGG")["current_hp"], hp(284821)], [2, 0], [284820, 284821])
check("石虫全挡后眩晕与卵伤害并存", enemy(284821, "BOWLBUG_ROCK")["intents"][0]["intent_type"], "Stun", [284820, 284821])
check("火焰药水实际扣1血并消费1滑溜", [enemy(284630, "VANTOM")["current_hp"] - enemy(284631, "VANTOM")["current_hp"],
      power(284630, "VANTOM", "SLIPPERY_POWER") - power(284631, "VANTOM", "SLIPPERY_POWER")], [1, 1], [284630, 284631])
check("12毒在滑溜下两结仅扣2", [enemy(284635, "VANTOM")["current_hp"] - enemy(284636, "VANTOM")["current_hp"],
      power(284635, "VANTOM", "POISON_POWER"), power(284636, "VANTOM", "POISON_POWER"),
      power(284635, "VANTOM", "SLIPPERY_POWER"), power(284636, "VANTOM", "SLIPPERY_POWER")],
      [2, 12, 10, 6, 4], [284635, 284636])
check("尖啸当轮14到2、次轮负力消失", [enemy(284633, "VANTOM")["intents"][0]["total_damage"],
      enemy(284634, "VANTOM")["intents"][0]["total_damage"], power(284634, "VANTOM", "STRENGTH_POWER"),
      power(284636, "VANTOM", "STRENGTH_POWER")], [14, 2, -6, 0], [284633, 284634, 284636])
check("F22赢战消耗53到9、下战仍9", [hp(284730), hp(284761), hp(284766)], [53, 9, 9], [284730, 284761, 284766])
check("F22两次攻击轮实损20和24", [hp(284743) - hp(284744), hp(284753) - hp(284754)], [20, 24], [284743, 284744, 284753, 284754])
check("寄生实体归零后次轮恢复21", [enemy(284748, "PARAFRIGHT")["current_hp"], enemy(284749, "PARAFRIGHT")["current_hp"]], [0, 21], [284748, 284749])
check("主怪10毒结算19后下轮11毒", [enemy(284753, "THE_OBSCURA")["current_hp"] - enemy(284754, "THE_OBSCURA")["current_hp"],
      power(284753, "THE_OBSCURA", "POISON_POWER"), power(284754, "THE_OBSCURA", "POISON_POWER")], [19, 10, 11], [284753, 284754])
check("普通生存者取消唯一剩余打击", [[c["card_id"] for c in state(n)["combat"]["hand"]] for n in [285414, 285415]],
      [["SURVIVOR", "STRIKE_SILENT"], []], [285414, 285415])
check("取消转向后45血7挡对57", [hp(285415), state(285415)["combat"]["player"]["block"],
      enemy(285415, "ROCKET")["intents"][0]["total_damage"]], [45, 7, 57], [285415])
check("女王末轮两敌毒扣22和42", [enemy(284407, eid)["current_hp"] - enemy(284408, eid)["current_hp"]
      for eid in ["TORCH_HEAD_AMALGAM", "QUEEN"]], [22, 42], [284407, 284408])
check("女王末轮12血12挡对31后死亡", [hp(284407), state(284407)["combat"]["player"]["block"],
      enemy(284407, "TORCH_HEAD_AMALGAM")["intents"][0]["total_damage"], hp(284408)], [12, 12, 31, 0], [284407, 284408])
check("醒虫末段力量2到4", [[p["amount"] for p in enemy(n, "SLUMBERING_BEETLE")["powers"]
                        if p["power_id"] == "STRENGTH_POWER"] for n in [286164, 286170]], [[2], [4]], [286164, 286170])
check("末次甲虫22来袭、玩家14血5挡", [hp(286173), state(286173)["combat"]["player"]["block"],
                                  enemy(286173, "SLUMBERING_BEETLE")["intents"][0]["total_damage"]],
      [14, 5, 22], [286173])
check("末次毒后甲虫13血玩家死亡", [enemy(286174, "SLUMBERING_BEETLE")["current_hp"], hp(286174)], [13, 0], [286174])

selected = []
windows = {"P74C04AEPL1F": {17, 22, 23}, "NHA2KW0RB7VP": {33},
           "G33HU22H2543": {31, 33, 47, 48}, "RC61MFQM63Y6": {17, 29, 32, 33}, "BTSRF7JL1W1Y": {30, 31}}
for envelope in states.values():
    st = envelope["row"]["state"]
    run = envelope["run_id"]
    run_state = st.get("run") or {}
    if run_state.get("floor") not in windows[run]:
        continue
    combat = st.get("combat") or {}
    player = combat.get("player") or {}
    selected.append({"run": run, "line": envelope["line"], "floor": run_state.get("floor"),
                     "turn": st.get("turn"), "screen": st.get("screen"),
                     "hp": player.get("current_hp", run_state.get("current_hp")), "block": player.get("block"),
                     "powers": player.get("powers"), "potions": run_state.get("potions"),
                     "hand": [{k: c.get(k) for k in ["index", "card_id", "upgraded", "energy_cost", "resolved_rules_text"]}
                              for c in combat.get("hand", [])],
                     "enemies": [{k: e.get(k) for k in ["enemy_id", "current_hp", "block", "powers", "intents"]}
                                 for e in combat.get("enemies", [])]})

for name, data in [("evidence-byte-verification.json", verified), ("fixed-facts.json", checks),
                   ("t1-comparisons.json", comparisons), ("state-projections.json", selected)]:
    (SCRATCH / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"已核原行": sum(e["rows"] for e in verified), "事实核对": len(checks),
                  "T1同局比较": len(comparisons), "投影帧": len(selected)}, ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
batch = '20261016-171301-s2-strategy-proposal'
dispatch = json.loads((S / 'dispatch.json').read_text())
proposals = json.loads((S / 'dispatched-proposals.json').read_text())
sources = json.loads((S / 'source-readback.json').read_text())
base = sources['base']
checked_at = subprocess.check_output(['date', '-Is'], text=True).strip()

details = [
    ('NHA2KW0RB7VP F33 六试T1—T4；states/SL原字节见 t1-comparisons.json。首/末T1实损1/7，敌净扣8/24。',
     '即时损血参考已有实际live子实现，但没有同抽序、同预算、同后继的整战对照及能力累计兑现、路线或留药受控后继；不足改SL和终局权重。',
     '替线多损6血同时多扣敌16，六试未赢不能证明所有替线更差。',
     '将即时血价与已结输出共同展示；整战收益未知时保留既有选择和门槛。',
     '未来固定同指纹两线及同预算完整后继，分别验HP、净扣、击杀、能力兑现与结局。'),
    ('P74C04AEPL1F F23 第4试T3；states 284816—284821，decisions 278542—278546；1血16挡，精确切击离手，卵毒后2血，玩家归零。',
     '暂停计划提示及弃后手牌快照已有live子实现；缺动态牌面、弃牌触发、目标和续步剩血的完整合法分支验证，未隔离新的数值失配。',
     '首试弃同牌时卵已于较早回合结束，第三试原线也不同；没有保留精确后的完整实打胜局。',
     '合法候选全部保留，说明删除的后继及未知项；动态牌面在弃后重新读取。',
     '固定末次选择帧分别核每一合法弃牌的费用、动态牌面、触发、目标、来袭与当前剩血，不把保留分支模拟称为实胜。'),
    ('P74C04AEPL1F F17 T1/2、F22 T1—T6、F23 T1/T3；火焰扣1、滑溜下两次毒共扣2；F22 53→9，下战9血空药。',
     '已有局部模型；仍缺主怪最后死亡的中间来源帧，以及药水、幻象复活、逐敌失衡和下一战资源的联合消费者回放，未隔离新的源码差额。',
     '石虫被完整格挡后眩晕与卵仍杀玩家同时成立；赢战不能证明资源消费合理，也不能由缺帧补最后伤害来源。',
     '逐敌、逐伤害来源、一次触发与战后入口分别核对，未知死亡来源保留。',
     '固定F17火焰/毒、F22寄生0→21、损20/24、F23石眩晕但卵存活的组合；补连续执行归属后才做端到端认证。'),
    ('G33HU22H2543 F48 T1/T8，P74C04AEPL1F F23 T3；投斧余像先/闪亮先候选18/10挡、75/107伤；末轮已建两余像三牌触发6挡。',
     '投斧首牌身份、普通单弃和计划提示均有live祖先窄实现；跨重规划执行归属、余像累计收益及动态弃牌的联合验收未完成，不能整项duplicate。',
     '余像先的候选未完整实打；末轮已兑现被动挡不能代替其他回合累计收益或证明更早铺能力可赢。',
     '保留首个实际卡牌身份，分开候选、支付、能力建层和实际触发。',
     '固定投斧首牌/药水/重规划身份及余像触发链，再核从选择到实线的持续归属；保留未执行首牌顺序的未知结局。'),
    ('G33HU22H2543 F31/F33/F47—F48；P74C04AEPL1F F22—F23。P局F22实53→9，F23仍9；G局F33实76→17。',
     '缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的受控后继；赢战消耗成立，仍不足拟合新的HP价格、留药阈值或路线禁令。',
     '未来营火未抵达，不能预支；G局F33虽赢仍掉59血，不能只用胜负忽略消耗，也没有替代路线胜局。',
     '真实回复、战内饮药、事件付血、开场变化与SL恢复分账，下一战入口按实帧。',
     '从固定连续原帧建立逐来源账，并核消费者实际读回；后续按独立局时间切分受控比较，不把SL当独立局。'),
    ('G33HU22H2543 F48 末试T7—T8；P74C04AEPL1F F17 T2/T8、F22 T4—T5、F23 T1/T3。尖啸临时减力、毒19及逐敌石眩晕均有实帧。',
     '已能定位历史源码和局部模型，但未还原历史刷新知识/移动表原字节；缺临时减力、毒多结算、一次格挡、开场及回复的完整组合联合回放与独立校准。',
     'G局末轮能力毒实际扣22+42仍死亡；机制有效不保证整战胜利，士兵/臂甲也不是每牌每轮恒定乘四。',
     '明确已建能力、未来轮初、当前一次消费及已结伤害，避免提前或重复计入。',
     '以固定原帧核当前数值，另外冻结运行时全部输入，再做联合回放和时间后置校准；未观察组合保留未知。'),
    ('RC61MFQM63Y6 F33 首/末试T1、末试T3—T4；decisions 279021/279197、states 285314—285321/285491—285497。同盘实损4/8，净扣30/23。',
     '即时差额可核，但首题3轮2样本、末题5轮24样本，缺同预算整战和累计能力收益受控对照；不足修改全败SL排序或加固定HP惩罚。',
     '触媒确实使3毒结算为3+2，不能由净扣少7否定能力一般价值；后续动作与抽序不同。',
     '记录实际换线前缀、朝向、药槽、当前血价和已兑现成长；未证明整战收益前保留排序。',
     '先固定同指纹T1差额及强制弃牌后的可达性，再做同预算完整后继、独立新局验证。'),
    ('BTSRF7JL1W1Y F31 T1—T4；decisions 279852/279854；states 286164—286174。力量2→4，末22攻击对14HP、5牌面挡与1覆甲。',
     '缺逐样本轨迹与最终执行线的配对校准；抽弃前后为不同题面，预算分别3轮/5轮各4样本，一次3/4样本候选线死亡不足证明模型错误或调权。',
     '抽弃后两小刀改打石，原长程最优没有完整执行；本局F17已施放步法的敏捷不能跨战带到F31。',
     '按最终执行线核睡层、力量、虚弱、覆甲、毒和重规划边界；无具体失配则保留权重。',
     '冻结末段实际执行全链与逐样本预测，分离取消线路与实际线路，再按独立局分组做概率校准。'),
    ('RC61MFQM63Y6 F33 第3试T4及首/末T1；states 285414—285415生存者后手空，45血7挡面对57；F17 T11呼唤自损另列原提案。',
     '普通生存者取消唯一后继已有实际live祖先覆盖；跨选择整线归属、累计能力和呼唤自损联合消费者尚未验收，不能把窄修复当整项duplicate。',
     '第三试不存在可供Jev保留的打击分支；不能增加依赖该虚构后继的SL安全规则。',
     '取消不能执行的后继攻击/转向，持牌自损与敌伤分开；未确定弃牌保留未知。',
     '核唯一单弃和多选未知的固定帧，再对选择、重算、持牌自损、毒终结的整线消费者做连续验证。'),
    ('RC61MFQM63Y6 F18路线计划、F27回复投影、F29赢战、F32休息与F33 T1；F33实52/70，读档药水重复不当新获得。',
     '缺同条件路线、休息和后战对照及逐来源消费者验收；52血实入口与已有回复账不足支持新安全血线、终局HP价格或留药规则。',
     'F29后更新的52入口与实到一致；不能把更早条件不同的预测误差当稳定模型偏差，五次SL也不是五瓶新增药水。',
     '只用已兑现回复和实际入口审计，SL恢复与真实治疗分账。',
     '冻结每次回复/赢战/SL与消费者读回，收集同条件后继再估参数；当前不由单败局拟合阈值。'),
]
assert len(details) == len(proposals) == len(dispatch['proposal_ids']) == 10

results = []
sections = []
originals = S / 'original-proposals'
originals.mkdir(exist_ok=True)
for item, detail in zip(proposals, details):
    p = item['add']
    evidence, reason, counter, behavior, validation = detail
    results.append({'id': p['id'], 'state': 'waiting', 'reason': reason})
    raw = Path(p['proposal']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == p['proposal_sha256']
    (originals / (p['id'] + '.md')).write_bytes(raw)
    sections.append('\n'.join([
        f"## {p['id']}", '', p['summary'], '',
        f"账本：{', '.join(p['ledger'])}。来源任务：{p['source_task']}；实现任务：strategy-proposal。",
        f"原提案：{p['proposal']}；SHA256：{p['proposal_sha256']}。", '',
        f'证据：{evidence}', '', f'处置：waiting。{reason}', '',
        f'反例与边界：{counter}', '', f'预期行为（待证）：{behavior}', '', f'验证方法：{validation}', '',
    ]))

prefix = f'''# 静默猎手本批十提案复核

日期：{checked_at}。batch：{batch}；角色：silent；直接证据均为A10。

本批十项全部waiting。没有新源码或知识改动，没有提交、live合入、版本或shipped；旧经验与已有局部实现保持。

初始HEAD为bd4749568d4de1f7236b52757a453bdc5d344168，初始git status干净。本批是普通proposal消费任务，reason=proposal且有十个proposal_ids；没有research_request、implementation_request或proposal_repair。普通专题文件绑定其他批次，不适用于本批。按要求git merge --no-edit main无冲突快进，base为{base}，本批不领取其他提案。

学习结论仅来自本批五局原帧及本角色原提案/账本；未读取其他角色知识，不使用预训练游戏知识。原提案逐份SHA一致，原字节另存original-proposals/。账本前态见ledger-before.json；仅用根ledger.py update补本批where/note，不重复support/repeat，不降低既有shipped状态，不改claim、first_run、prior、evidence、version或effect。

共用extract_evidence.py冻结六流6,601条：states 3,238、decisions 3,138、SL 31、run-config 5、run-plans 26、brain 163。每条显式身份、source_size边界、offset/bytes/SHA和原JSON均已读回核对，见evidence-byte-verification.json。另用同入口抽取runs五行，确认全为SILENT/A10，见evidence-runs/。states/decisions源各两条、brain源一条不可解析记录由抽取器排除，不将其归因本批五局或生产缺陷。当前run-plans实际选中26条，不把旧截点零行当缺日志。

18项固定材料事实核对、两组T1同局比较及976帧投影保存在fixed-facts.json、t1-comparisons.json、state-projections.json；它们不是生产测试或概率/胜率验证。原始分支可见，不把未执行候选当实胜，不将SL拆成独立局。没有拟合自由参数、刷模拟池、调用LLM/网络或运行play。历史完整dirty运行输入未还原，当前源码和知识不能冒作当时执行输入。

## 已有源码的有限覆盖

source-readback.json逐项核实际live祖先及九个消费者叶SHA。读回live为{sources['live']}。

| 实际live祖先源码 | 已有覆盖 | 仍不能证明 |
| --- | --- | --- |
| 1dab14da481fe7951d9020dba52ad0ebebb1029b | 并列组即时损血参考，接入combat-plan | SL选择、完整后继、累计能力收益或HP价格已校准 |
| e784dd9f043bf87c29109573f48975f9903280d3 | 投斧首牌身份 | 另一首牌顺序能赢或跨重规划实线已完整验收 |
| bf423c173d3be348a4ad714e1d26516df619ff41 | 普通生存者唯一单弃消费；多选保留未知 | 完整动态弃牌分支或收益验证 |
| 97efc0618936c6d7783fbf36e79b056b90d65589 | 暂停计划后继和条件预测 | 逐个合法弃牌的完整伤害、目标、触发和剩血推演 |
| 4b0823f519f1b724d6cff2b1cd50b74146dc4a9d | 各弃牌候选保留手牌、当前费用与独立能量事实 | 弃牌触发、动态牌面或胜负已求解 |

九叶中五叶与live逐字相同，四叶差异仅历史Roy/Dai署名注释，完整差异见base-live-comments.patch。5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56与f34700874c9f48b614991f769532115a0f24f27b均非实际live祖先，不拿它们登记implemented。另核2a62f327d508201d9982983ec2c930789065ece5为实际祖先，只说明其局部事实通道已存在，不验收本批宽项。

原即时血价/手牌快照明确保留未知；原单弃模型也不虚构多选的Jev选择。没有找到本批证据可独立定位的新源码差额，不另写镜像测试、重复实现或以子功能关闭宽提案。铁甲及其他角色行为没有改动。

## 样本、反例和回退

本次范围固定为五个来源局，未重新计算原提案的全历史统计或借原统计冒充本次校准。RC61同盘T1两个实际提问预算分别3轮2样本、5轮24样本；末题内部候选同预算，不等于跨尝试预算相同。BTS抽弃前后为3轮/5轮各4样本，实际最终执行也已换目标，三胜一死不能据一次死亡判定概率错误。详细候选及预算原文见decision-budget-readback.json。

不因缺完整后继否定已经实证的局部机制，也不把整战失败当新机制反证；没有新机制异议或新游戏规则。未来取得缺失材料后沿十个原id重派，不新建重复提案。若未来修改生产代码，须分别提交、撤接线失败/恢复通过、运行固定沙箱入口并走实际live流程；本次无代码可撤回，回退不适用，所有历史及失败原件保留。

## 本批运行与验证边界

本次实际启动命令记录为gpt-6.1-sol、model_reasoning_effort=xhigh、service_tier=default，原thread为01a143fc-9554-72f0-b63e-5c20a034b8d7；未修改会话/账号/配置，不宣称已切换成任务文字中的high。没有子agent。

tsc=null，vitest=null，cases=null；未运行生产测试、未作撤源码失败/恢复通过实验，也不借历史测试绿充本批成功。git tracked/index保持干净，source-worktree.patch为空；无代码提交所以无提交前测试。扫描本批材料的gitleaks结果另存gitleaks.log/gitleaks-report.json，不能替代任何生产验证。初查误猜三个源码文件路径及一个通配路径失败，随后通过rg定位实际源码；这些探针不是生产故障或机制反例。

运维交付：proposal.md和report.md在本批scratch；十个proposal_results通过最终result.json回报。无实际新规则上线，不写上线记录或双通知、不关闭学习父要求，不代ops/watcher/Roy确认。
'''

proposal_text = prefix + '\n' + '\n'.join(sections)
(S / 'proposal.md').write_text(proposal_text)
(S / 'report.md').write_text(proposal_text + '\n逐项机器处置见同目录result.json；账本CLI输入/回执见ledger-input.jsonl、ledger-cli.log与ledger-readback.json。\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
by_ledger = {}
for p, result_item in zip(proposals, results):
    for ledger in p['add']['ledger']:
        by_ledger.setdefault(ledger, []).append(result_item)
payload = []
for ledger, linked in sorted(by_ledger.items()):
    payload.append({'id': ledger, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(S / 'proposal.md') + '#' + x['id'] for x in linked]},
                    'note': batch + '：仅补本批复核追溯，未新增证据、规则、实现或版本；' +
                            '；'.join(x['id'] + ' waiting：' + x['reason'] for x in linked)})
(S / 'ledger-input.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in payload))
print(json.dumps({'base': base, '提案数': len(results), '账本追溯数': len(payload), 'report': str(S / 'report.md')}, ensure_ascii=False))

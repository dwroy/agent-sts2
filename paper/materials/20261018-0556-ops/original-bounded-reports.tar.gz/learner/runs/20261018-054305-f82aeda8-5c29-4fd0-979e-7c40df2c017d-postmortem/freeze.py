import json,hashlib,re,subprocess,shutil
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2')
d=[json.loads(l) for l in (p/'decisions.jsonl').open()];lo=d[0]['row']['ts'];hi=d[-1]['row']['ts'];path=root/'logs/deepseek-reasoning.jsonl';count=0;matches=0;first=None;last=None;max_ts=None;offset=0
with path.open('rb') as f,(p/'deepseek-window.jsonl').open('w') as w:
 f.seek(0)
 for n,line in enumerate(f,1):
  m=re.search(rb'"ts"\s*:\s*"([^\"]+)"',line)
  if m:
   ts=m.group(1).decode();first=first or ts;last=ts;max_ts=max(max_ts or ts,ts);count+=1
   if lo<=ts<=hi:
    w.write(json.dumps({'line':n,'offset':offset,'row':json.loads(line)},ensure_ascii=False)+'\n');matches+=1
  offset+=len(line)
proof={'start':lo,'end':hi,'records':count,'matches':matches,'first':first,'last':last,'max_ts':max_ts,'bytes':offset}
(p/'deepseek-window.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('DEEPSEEK',proof)
live=root/'.worktrees/live';files=['agent/src/reflex/combat-plan.ts','agent/src/reflex/silent-selection-audit.ts','agent/src/reflex/silent-selection-dispatch.ts','agent/src/reflex/silent-sl-comparison.ts','agent/src/sl/judge.ts','agent/src/sl/explore.ts']
commit=subprocess.check_output(['git','-C',str(live),'rev-parse','HEAD'],text=True).strip();manifest={'live_commit':commit,'files':[]}
for rel in files:
 dst=p/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(live/rel,dst);blob=subprocess.check_output(['git','-C',str(live),'rev-parse','HEAD:'+rel],text=True).strip();manifest['files'].append({'path':rel,'blob':blob,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
(p/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(p/'source.diff').write_bytes(subprocess.check_output(['git','-C',str(live),'diff','--binary','HEAD','--',*files]));print('SOURCE',commit,'diff_bytes',(p/'source.diff').stat().st_size)

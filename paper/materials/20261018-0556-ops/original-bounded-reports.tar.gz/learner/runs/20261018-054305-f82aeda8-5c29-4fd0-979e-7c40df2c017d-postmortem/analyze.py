import json,collections
from pathlib import Path
p=Path(__file__).parent
rows=lambda name:[json.loads(l) for l in (p/(name+'.jsonl')).open()]
d=rows('decisions');ss=rows('states');res=json.load((p/'NRZAYVRMM7M0-resources.json').open())
print('COUNTS',collections.Counter(x['row']['decider'] for x in d));print('LABELS',collections.Counter((x['row']['label'],x['row']['decider']) for x in d))
j=[x for x in d if x['row']['decider']=='jev'];q=[x for x in j if x['row']['label'].startswith('combat/plan-choice')]
print('JEV',len(j),'low',sum((x['row'].get('confidence') or 0)<.35 for x in j),'combat',len(q),'rollout',collections.Counter(x['row'].get('rollout_best_chosen') for x in q))
for c in res['combats']:
 frames=[x for x in ss if c['entry']['line']<=x['line']<=(c['exit'] or c['last'])['line']]
 byturn={}
 for x in frames:
  s=x['row']['state'];t=s['turn']
  if t not in byturn:byturn[t]=[x,x]
  byturn[t][1]=x
 print('TURNS',c['sequence'],c['floor'])
 for t,(first,last) in byturn.items():
  a=first['row']['state'];z=last['row']['state'];hp=lambda s:sum(e['current_hp'] for e in s['combat']['enemies'] if e['is_alive'])
  nxt=next((x for x in frames if x['line']>last['line']),None)
  end=nxt['row']['state'] if nxt else z
  print(t,'s',first['line'],last['line'],'hp',a['run']['current_hp'],end['run']['current_hp'],'need',hp(a),'net',hp(a)-hp(end),'endhp',[(e['enemy_id'],e['current_hp']) for e in end['combat']['enemies']],'block',z['combat']['player'].get('block') if 'player' in z['combat'] else list(z['combat']))
print('RESOURCE CHANGES')
for e in res['resource_changes']:
 a,b=e['from'],e['to'];print(a['line'],b['line'],'F',b['floor'],'T',b['turn'],b['screen'],a['hp'],b['hp'],a['max_hp'],b['max_hp'],a['potions'],b['potions'],'restart',e['restart_boundary'])
print('BOSS DECISIONS')
for x in d:
 r=x['row']
 if r['floor']==17 and (r['decider'] in ('jev','code-fallback') or r['label'] in ['combat/plan','combat/least-loss']):
  au=r.get('selection_audit') or {};print(x['line'],r.get('sl_attempt'),r['turn'],r['decider'],r['label'],r['rationale'],json.dumps({k:au.get(k) for k in ['answer','sl_delta']},ensure_ascii=False))

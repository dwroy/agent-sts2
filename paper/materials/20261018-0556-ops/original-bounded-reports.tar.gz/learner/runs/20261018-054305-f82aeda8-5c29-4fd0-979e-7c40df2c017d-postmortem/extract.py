import json,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261018-054305-f82aeda8-5c29-4fd0-979e-7c40df2c017d-postmortem'; run=b'NRZAYVRMM7M0'
for name in ['decisions','states','run-plans','sl-attempts','brain','run-config','fight-plans','hand-dispatch']:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists(): continue
 count=0; offset=0
 with p.open('rb') as f,(out/f'{name}.jsonl').open('w') as w:
  for n,line in enumerate(f,1):
   if run in line:
    try:r=json.loads(line)
    except ValueError:offset+=len(line);continue
    w.write(json.dumps({'line':n,'offset':offset,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'row':r},ensure_ascii=False)+'\n');count+=1
   offset+=len(line)
 print(name,count)

"""Preserve the ten dispatched dispositions and their bounded evidence."""
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WORKTREE = HERE.parents[2]
dispatch = json.loads((HERE / 'dispatch-and-proposals.json').read_text())
base = json.loads((HERE / 'source-audit.json').read_text())['base']
stamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(stamp)
details = [
    {
        'evidence': 'KEN58SH9SLZ6 A10：F3 T2、F4 T1、F5 T2、F11 T1/T2、F15 T1共7次实饮；F5胜战53→16、F15两药后46→46，F17最终归零。决策274131/274156/274185/274235/274237/274267/274272；状态280255—280285、280347—280381。',
        'existing': '现有连战接口和终局余血接口不等于已校准这局的七药持有价格。',
        'counter': 'F15零净损但耗两药，不能推成不喝也零损；SL恢复不能计作路线回血或新药。',
        'reason': '缺KEN F15不饮用及同入口、同后继下留药至Boss的完整成对结果；7次实饮与零净损窗口只核资源结转，不足校准持药价格。',
        'next': '保持药水价值；未来核同入口早用/不用/留药的完整战斗与下一战资源，按run及开始时间隔离训练和后移验证。',
    },
    {
        'evidence': 'TXZ6RVMQA09D A10 F48第二/三试T6：状态281479→281484为损3/扣36，281535→281539为损0/扣27；决策275383明确原答带毒刺击而SL换羽化。281563—281566为首胜4血、下一房4→0且敌仍111。',
        'existing': 'e1a467e18a0dfa8d99046a24ff4c0e1af59278c8已接连续两战；5b56a452bb9be14d620b368ec46974c1b57901ca含观察开场失血接续。均为实际live祖先，非本批新实现。',
        'counter': '少损3同时少扣9，后续抽牌/生成牌和选择也改变；首战胜仍全局败。1200模拟不能当独立实盘或严格SL证明。',
        'reason': '缺保持抽序、生成牌、药栏及后续选择一致的两战替线和联合资源校准；少损3同时少伤9不能证明连续通关改善。',
        'next': '保持连战目标和严格SL规则；将首战出口、后战开场、是否到可操作帧分列，完整后继未核前不改SL排序。',
    },
    {
        'evidence': 'WQZVENQ7DTRP A10 F33第二/三试T9，同26HP/敌184/4敏：状态282075→282079损13扣24；282144→282148损22扣39；决策275894/275960保留原答与换线理由。第二/末试T7同扣24，282066→282072损0、282330→282336损4，卡后沙坑4/5。',
        'existing': 'sl/explore.ts replacementAmong仍在B2 notWorse或rollout死亡率候选池内取未试线，并记录理由；这个既有探索语义不等于两线实血价相同。',
        'counter': 'T7的4血换一沙坑回合约束“永远最少损血”；T9多15伤付9血约束“全死就是同安全”。六试同属一局。',
        'reason': '缺同时约束攻击、格挡、毒与沙坑两条截止线的受控整战后继和独立验证，不能把9血换15伤拟成固定交换率或修改SL准入。',
        'next': '保持探索门槛；保存两种边界，后续在完整候选与实际执行可对应时核完整资源差和结局，不把失败模拟并列解释成无代价。',
    },
    {
        'evidence': '本次9个已核身份静默局共42次狡诈饮用：37次添3、2次八手添2、3次满手添0；新增均升级、基础6，饮用当步HP/能量不变。WQ A10 F33第五试T11状态282292—282296为2/0/0，末试282351—282357相关窗口为3/2/0；历史另含A7/A9，分别保留进阶。',
        'existing': '5b56a452bb9be14d620b368ec46974c1b57901ca实际live祖先；card-model.ts按角色/已见阶生成三刀，turn-solver.ts按每步手位截断并可穿插出刀，combat-plan.ts给生成事实。原固定测试有穿插与未用小刀后轮覆盖；本批只读，不借其历史绿为新测试。',
        'counter': '牌面当前4/7/8/9/10不反驳基础6，需分现场力量/弱；容量截断只在WQ见到。模拟穿插多刀不等于实打可救全战。',
        'reason': '狡诈生成、手位截断和穿插子模型已有实际live源码祖先；原请求的计划妥当保留容量、跨重问完整派发及SL恢复联合消费者仍未核齐。',
        'next': '保持已上线确定子模型；保留满手耗瓶选项和全部选择，不新增统一留药阈值。补真实保留/重问/恢复链后再关闭原宽项。',
    },
    {
        'evidence': 'TXZ A10 F43/45/46/48/49新战首动作前70→66、52→48、62→58、60→56、4→0；F49没有实际攻击。WQ A10 F33的T9攻防和T7沙坑反例见上；恢复与真实消耗分列。',
        'existing': '5b56a452bb9be14d620b368ec46974c1b57901ca的受限4HP开场与接续已live；ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8后续仅扩已观察遗物集合。未知回血/自动复活组合仍走原未建模路径。',
        'counter': '旧王室猛毒+小血瓶净2只说明组合净值，不能指定单件或内部顺序；未知组合不能一律套净4，当前实盘T1/SL恢复不应再次扣开场。',
        'reason': '王室猛毒受限开场和同样本连战传递已有实际live祖先；缺未知回血/复活组合顺序及留药、路线、SL整战后继的联合校准。',
        'next': '保持受限组合和一次开场扣费；不扩大组合或改终局权重，后战实际可操作入口与完整后继另验。',
    },
    {
        'evidence': '1913SE84AXQF A10 F29胜61→46，F31以46入千足虫后死；Q6M2Y34MWKRE A10 F8 T1速度药临时5敏、F8赢57→2，F9以2HP入场T2死。Q6 F2原线实损12，早敏捷药候选未完整实打；原提案的0.29低信心仅为原答信息。',
        'existing': 'continuation-value.ts及现行连战资源接续已存在；不能把其有接口写成当前两条非Boss资源链已校准。普通紧勒窄公式已有66283dd9982bdd7f480da7a4d9bfefea0572a9ac实际live祖先。',
        'counter': 'Q6敏捷药T3实际喝了，F5/F6零损并未丢药；F8紧勒的局部机制误差不能拟作药水价。1913营火改锻造是条件变化。',
        'reason': '缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果；低信心答选和局部候选不能校准新药价或终局权重。',
        'next': '保持权重及饮用规则，先核实际药效期限和退出资源，再做按独立局及时间留出的完整后继验证。',
    },
    {
        'evidence': 'Q6 A10 F8 T4：状态282887—282892敌血103→95→85→85→83→80，弃牌选择未完成时还未触发2失血，完成后触发；1913 A10 F31 T2状态282767→282768弃磨蚀，能量3不变、建1敏/4荆棘。T3两防御合12，T4已建毒雾但未活到下一轮。',
        'existing': '66283dd9982bdd7f480da7a4d9bfefea0572a9ac的普通紧勒受限实现已live；solver对未完成弃牌、未知叠层/自动触发保留未知。card-model.ts已见普通磨蚀模型也不等于其弃牌到跨轮联合链完成。',
        'counter': '伤害23吻合但弃牌仍未确定的候选不是完整执行证书；荆棘逐击和敌剩血截断不能预支成玩家存活，已建毒雾不等于已结毒。',
        'reason': '普通紧勒已观察子公式已有实际live祖先；缺弃磨蚀、增益分源、再生/自动触发及SL恢复的联合消费者校准与受控整战后继。',
        'next': '不重复紧勒补丁，不从机制集合推统一时点；逐条保留能力建立、弃牌完成、跨轮兑现及死亡截断证据。',
    },
    {
        'evidence': '1913 A10 F24锻造不回血，F28实际回21至61，F29赢后46入F31而死，F32未来火未到；Q6 A10 F7回21至57，F8赢后2入F9死。原计划/实际条件分账，状态282723—282783、282872—282921核资源端点。',
        'existing': '本批核实际节点及血链，未发现能仅由这两局确定的新路线安全阈值。现有路线/休息统计不充未走路线的反事实。',
        'counter': '两条失败链不是“休息无效”或“应更激进”的证据；未来营火未到也不能预支HP。另一选择的完整结果未知。',
        'reason': '缺另一营火动作、事件、路线和用药时机的受控完整结果；两条观察性失败链不足校准路线或终局权重。',
        'next': '保持路线与休息规则，只认实际动作的资源变化；后续按真实路径条件和独立局比较，不重新全量汇总原109局为新增支持。',
    },
    {
        'evidence': 'NHA2KW0RB7VP A10 F33第一至四试T1卡后14挡、实际损1/跨轮扣8；第五/六试卡后8挡、实际损7/跨轮扣24，无击杀且T4仍死。状态283412→283418、283478→283483、283502→283507；决策277248/277250/277272/277274区分原答、SL覆盖、弃精确切击后重问。',
        'existing': 'explore.ts的B2/rollout候选池及重放语义仍在；原答是整候选，chosen只派一步，pending/重问不构成原完整候选认证。本批保存762条焦点动作与22条SL记录，不编造完整执行证书。',
        'counter': '第五/六次不是两个独立胜样本；两轮均没击杀。抱抱先生次轮自动两侧各2不能全部归为卡牌伤。',
        'reason': '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；同一局六败不能作为六个独立验证局或新血价门槛。',
        'next': '保持探索；同时保存即时付血、实际推进和未知后继，补完整执行归属与后移独立验证后再改排名。',
    },
    {
        'evidence': 'NHA A10 F33 T1普通X1萎靡实际−2力/2弱，状态283482；F33 T2同招同−2力/弱1时转向，爪1→2、火箭30→20，15/16挡实际损7/6，283397—283422。K367 A1、SAD A7的毒量仅各自原观察范围。',
        'existing': '68711002f15b298b8863d2258ee5da236da151d2实际live祖先，限定Silent A10现场组合，从本阶数据库取未取整基础后变朝向。当前源码未见油灯已消费位接线；所核遗物对象只有index/id/name/description/stack/is_melted，不能仅凭持有反复翻倍。',
        'counter': '同一局六窗口不是六局；旧运行带dirty，不能由当前源码重建旧运行。未建立/未触发能力不预支，油灯其他负面类型/零X/升级/叠层没有在本批补齐。',
        'reason': '蟹朝向受限取整已有实际live祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入，以及未覆盖X值/升级组合与能力整战后继。',
        'next': '保留已证朝向子模型；首次消费须有战斗身份和已接受动作链可核，不把遗物持有当未消费，也不扩大未见机制。',
    },
]

proposals = dispatch['proposals']
assert len(proposals) == len(details) == 10
results = [{'id': x['id'], 'state': 'waiting', 'reason': d['reason']} for x, d in zip(proposals, details)]
result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-073111-s2-strategy-proposal',
    'base': base, 'runs': dispatch['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [x['id'] for x in proposals],
    'implementation_domains': ['combat', 'potion', 'sl', 'terminal'],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 本批静默策略复核与逐项处置

时间：{stamp}。批次：20261017-073111-s2-strategy-proposal。来源任务与实现任务均按10个既有CLI提案链接保留；本批不新建重复ID。

## 身份与范围

工作树为{WORKTREE}，开工干净；普通派发，task=strategy-proposal、character=silent、reason=proposal，领取下列10项。没有research_request、implementation_request或proposal_repair；根deck-size请求绑定另一旧批，不适用本批。按要求merge main得到Already up to date，base/HEAD={base}。

本批10个派发锚点之外，仅补读这10份原提案已经引用的5个本角色局，共15局：A1一局K3676LU8B0UH、A7一局SADL3CGYTGSR、A9一局F4QKG4J1AJJZ、A10十二局。runs.jsonl身份均核为SILENT，冻结结束记录与具体角色/进阶见run-identities.json。没有把旧历史统计或同局SL拆作本批独立样本。

已读README、最新STATE-2026-10-16、decision-log末尾、学习协议、代码提案闭环，以及本批全部原提案。10份保存Markdown逐SHA匹配队列，原字节另存original-proposals/*.txt。scoped-experience.json仅保存关联的26条silent现有经验；这些已存文本不代替原始证据。

## 证据与验证口径

用共用extract_evidence.py按显式所属身份提取8流，source_size为各流开启时字节截点；原日志持续增长不改变截点。逐行校验offset/bytes/SHA及解码原行相等，全部19,929行通过：states 9815、decisions 9448、sl-attempts 78、run-config 15、run-plans 77、brain 481、runs 15、fight-plans 0。run-plans用run，其他流同时核run_id/state.run_id/fingerprint.run；冲突身份由共用入口拒收。fight-plans的0只表示该完整截点未选到，不宣称日志缺失。

evidence/evidence-manifest.json与raw-integrity.json保存每流截点、逐局数和输出SHA；封套逐行保存原源位置与SHA。8个*.evidence.jsonl无损压缩为同名.gz，compression-manifest.json记录压缩前后SHA及逐字节还原核验，原408,419,898字节压为30,411,208字节，原logs不动。两个核验脚本支持.gz回读。

audit_evidence.py完成原字节完整性/角色校验；check_fixed_observations.py的150项固定实盘观察断言exit0。它们属于材料复算，不是生产tsc/vitest，也不是新策略撤源码失败/恢复通过试验。未改源码、知识或测试，生产tests全部null；未运行LLM、网络、play或模拟池。state-projections/floor-resources记录过渡首帧，因此HP开场与实际可操作帧另核；不能把暂态首帧当已结算入口。focused-action-stream保存762条焦点动作，focused-sl-records保存22条SL记录；完整候选实际执行认证保持null。

## 逐项提案
'''
parts = [intro]
for x, d in zip(proposals, details):
    parts.append(f'''### {x['id']}

原提案：{x['proposal']}；SHA256={x['proposal_sha256']}。账本：{', '.join(x['ledger'])}。领域：{', '.join(x['domains'])}。

证据：{d['evidence']}

现行实现核验：{d['existing']}

反例与限制：{d['counter']}

处置：waiting。{d['reason']}

预期行为及验证：{d['next']} 本批不拟合新阈值，不宣称局部数值吻合证明胜率改善；回退无需操作，原策略保留，原提案及失败历史保留。
''')
parts.append('''## 祖先、记录和交付边界

existing-implementation-ancestry.json保存五项受限实现的完整40位源码提交，并核为本base和实际live祖先；source-audit.json保存12份当前源码的SHA，source-diff.patch为空。当前源码仅定位已实现和缺口，不倒写带dirty旧运行来源，也不借历史测试成功作为本批验证。

10项全部处理为waiting，原因逐项不同；已实现窄项不冒称整个宽项duplicate。没有源码提交、没有合入、没有发布编号、没有shipped或行为通知。本批领域数组表示处理的原提案范围，不表示已实现。需要的新完整后继和联合消费者验证保留给后续本角色证据，不扩领其他队列。

仅经根learner/ledger.py update给31个既有账本ID追加本批proposal链接及复核note，不重复support/repeat、不改变旧claim/首证/prior/evidence/status/version。没有新发现需add/proposed，也不将既有shipped条目倒退为proposed；waiting由最终proposal_results交调度器登记，不手改队列。CLI输入/回执和保护字段复核另存ledger-updates.json、ledger-cli.stdout.txt、ledger-cli.stderr.txt、ledger-link-verification.json。

没有本批新增反证推翻原经验；限制与原提案一致，保留所有旧失败。原启动器曾有失败重试，本批不改原运行事件。launcher命令可核请求gpt-6.1-sol/xhigh/default；不把请求参数当实际原生模型核验或声称已切到high，本任务未改模型/权限/账号配置。

最终验收见completion-verification.json；HEAD应仍为base、git status应干净，源码/knowledge/eval无差异。回报JSON保存在result.json，运维交付入口为本目录proposal.md与report.md。无生产变更，merge=live流程不触发，不创建空合并或占用live发布锁。
''')
proposal = '\n'.join(parts)
(HERE / 'proposal.md').write_text(proposal)
table = '\n'.join('| ' + x['id'] + ' | waiting | ' + d['reason'] + ' |' for x, d in zip(proposals, details))
report = f'''# 本批策略处理报告

{stamp}。结论：10项已领取原提案均完成本批证据复核，全部waiting；没有足够的新受控后继或联合消费者证据支持调整宽项策略。既有确定子模型已核实际live祖先，未重复实现。没有新源码、知识修改、提交、合入或游戏版本。

base/HEAD：{base}。工作树：{WORKTREE}。

逐项证据局号/层/回合、31个账本ID、原提案SHA、反例、旧行为、预期及验证方法均见[proposal.md](proposal.md)。15局身份、8流19,929行原字节校验通过，42次狡诈饮用及150项固定实盘观察断言通过；未执行生产tsc/vitest，撤源码失败与恢复通过不适用。762焦点动作/22条SL记录不升格为完整候选执行认证。

| 原提案ID | 处置 | 具体缺口 |
|---|---|---|
{table}

原局带dirty标记的来源保持；当前源码和历史绿不替代旧运行输入冻结。没有新阈值或胜率提升结论，没有将SL多试当多局，没有改其他角色。证据冻结manifest、原行offset/bytes/SHA、gzip无损回读、固定观察检查、既有live祖先、账本CLI及最终无改动检查均存本目录。未关闭任何学习父要求；由调度器按逐项结果保留待新局重派。

提案路径：{HERE / 'proposal.md'}。
报告路径：{HERE / 'report.md'}。
结构化回报：result.json。完整材料及边界以proposal.md和各JSON原件为准。
'''
(HERE / 'report.md').write_text(report)

updates = []
ids = sorted({ident for x in proposals for ident in x['ledger']})
for ident in ids:
    linked = [x['id'] for x in proposals if ident in x['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(HERE / 'proposal.md')]},
        'note': '20261017-073111-s2策略复核：关联' + ','.join(linked) +
                '；15个本角色原局/8流19929行字节核验、150项固定观察通过，原窄实现live祖先见本批材料。各原宽项仍waiting，具体缺完整后继/联合消费者见proposal.md。本次仅追溯链接，不追加独立support/repeat，不改原claim/首证/prior/evidence/status/version。'})
(HERE / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'results': len(results), 'waiting': len(results), 'ledger_links': len(updates),
                  'report': str(HERE / 'report.md')}, ensure_ascii=False))

"""Check source observations, separate from production regression tests."""
import collections
import gzip
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = json.loads((HERE / 'state-projections.json').read_text())
lines = {x['line']: x for rows in states.values() for x in rows}
checks = []


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'observation': label, 'actual': actual, 'expected': expected})


def hp(n):
    return lines[n]['hp']


def enemy_hp(n):
    return sum(e['hp'] for e in lines[n]['enemies'])


def powers(n, index=0):
    return lines[n]['enemies'][index]['powers']


def delta(start, end):
    return [hp(start) - hp(end), enemy_hp(start) - enemy_hp(end)]


check('TXZ F48 attempt2 T6 through next turn: HP cost and enemy loss', delta(281479, 281484), [3, 36])
check('TXZ F48 attempt3 T6 through next turn: HP cost and enemy loss', delta(281535, 281539), [0, 27])
check('TXZ first-boss reward HP then second-fight pre-action death',
      [hp(n) for n in [281563, 281564, 281565, 281566]], [4, 4, 4, 0])
check('TXZ second enemy never took damage at this opening', [enemy_hp(n) for n in [281565, 281566]], [111, 111])
check('WQ F33 attempt2 T9', delta(282075, 282079), [13, 24])
check('WQ F33 attempt3 T9', delta(282144, 282148), [22, 39])
check('WQ F33 attempt2 T7', delta(282066, 282072), [0, 24])
check('WQ F33 attempt6 T7', delta(282330, 282336), [4, 24])
check('WQ F33 T7 sandpit after cards, before decrement',
      [powers(n)['SANDPIT_POWER'] for n in [282071, 282335]], [4, 5])
check('NHA F33 attempt2 T1 through next turn', delta(283412, 283418), [1, 8])
check('NHA F33 attempt5 T1 through next turn', delta(283478, 283483), [7, 24])
check('NHA F33 attempt6 T1 replay', delta(283502, 283507), [7, 24])
check('NHA original versus replacement block', [lines[n]['block'] for n in [283417, 283482]], [14, 8])
check('NHA first X1 Malaise observed debuffs',
      [powers(283482)['STRENGTH_POWER'], powers(283482)['WEAK_POWER']], [-2, 2])
check('Q6 ordinary Strangle establishment followed by attack, pending discard and completion',
      [enemy_hp(n) for n in [282887, 282888, 282889, 282890, 282891, 282892]], [103, 95, 85, 85, 83, 80])
check('Q6 completed discard readiness', [lines[n]['ready'] for n in [282890, 282891]], [False, True])
check('1913 Abrasive discard energy and gained powers',
      [lines[282767]['energy'], lines[282768]['energy'],
       lines[282768]['powers']['DEXTERITY_POWER'], lines[282768]['powers']['THORNS_POWER']], [3, 3, 1, 4])

drinks = json.loads((HERE / 'cunning-transitions.json').read_text())
check('all observed Cunning drinks', len(drinks), 42)
for row in drinks:
    label = row['run'] + ':' + str(row['after_line'])
    check(label + ': capacity', row['shivs_added'], min(3, 10 - row['before_hand']))
    check(label + ': HP and energy unchanged', [row['hp'][0] == row['hp'][1], row['energy'][0] == row['energy'][1]], [True, True])
    added = lines[row['after_line']]['hand'][row['before_hand']:]
    check(label + ': appended upgraded six-base Shivs',
          [[c['id'], c['upgraded'], c['vars']['Damage'][0]] for c in added],
          [['SHIV', True, 6]] * row['shivs_added'])
check('Cunning distinct runs', len({x['run'] for x in drinks}), 9)
check('Cunning capacity counts', collections.Counter(x['shivs_added'] for x in drinks), {3: 37, 2: 2, 0: 3})

decisions = []
ken_drinks = []
sl = []
decision_path = HERE / 'evidence/decisions.evidence.jsonl'
decision_input = decision_path.open() if decision_path.exists() else gzip.open(str(decision_path) + '.gz', 'rt')
for raw in decision_input:
    x = json.loads(raw)
    r = x['row']
    if r['run_id'] == 'KEN58SH9SLZ6' and (r.get('chosen') or {}).get('action') == 'use_potion':
        ken_drinks.append([r['floor'], r['turn'], r['expect']['potion']['id']])
    if (r['run_id'], r['floor']) not in [('KEN58SH9SLZ6', 15), ('TXZ6RVMQA09D', 48),
            ('WQZVENQ7DTRP', 33), ('1913SE84AXQF', 31), ('Q6M2Y34MWKRE', 2),
            ('Q6M2Y34MWKRE', 8), ('NHA2KW0RB7VP', 33)]:
        continue
    decisions.append({**{k: x[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']},
                      **{k: r.get(k) for k in ['ts', 'floor', 'turn', 'label', 'decision_id', 'decider',
                          'chosen', 'expect', 'rationale', 'confidence', 'journal', 'result', 'sl_attempt']}})
check('KEN actual seven drinks', ken_drinks,
      [[3, 2, 'ATTACK_POTION'], [4, 1, 'STABLE_SERUM'], [5, 2, 'SPEED_POTION'],
       [11, 1, 'WEAK_POTION'], [11, 2, 'ATTACK_POTION'],
       [15, 1, 'GLOWWATER_POTION'], [15, 1, 'SKILL_POTION']])
sl_path = HERE / 'evidence/sl-attempts.evidence.jsonl'
sl_input = sl_path.open() if sl_path.exists() else gzip.open(str(sl_path) + '.gz', 'rt')
for raw in sl_input:
    x = json.loads(raw)
    if x['run_id'] in ['TXZ6RVMQA09D', 'WQZVENQ7DTRP', 'NHA2KW0RB7VP']:
        sl.append(x)

floors = json.loads((HERE / 'floor-resources.json').read_text())
by_floor = {(x['run'], x['floor']): x for x in floors}
check('KEN F15 net loss despite two drinks',
      [by_floor['KEN58SH9SLZ6', 15][k] for k in ['entry_hp', 'exit_hp']], [46, 46])
check('Q6 elite exit two then next-fight death',
      [by_floor['Q6M2Y34MWKRE', 8]['exit_hp'], by_floor['Q6M2Y34MWKRE', 9]['entry_hp'],
       by_floor['Q6M2Y34MWKRE', 9]['exit_hp']], [2, 2, 0])
check('1913 F29 win carries 46 into F31, which ends dead',
      [by_floor['1913SE84AXQF', 29]['exit_hp'], by_floor['1913SE84AXQF', 31]['entry_hp'],
       by_floor['1913SE84AXQF', 31]['exit_hp']], [46, 46, 0])
for name, data in [('fixed-observation-checks.json', {'checks': checks, 'count': len(checks), 'exit_code': 0,
                    'production_tests': None, 'complete_candidate_execution_certification': None}),
                   ('focused-action-stream.json', decisions), ('focused-sl-records.json', sl)]:
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'focused_decisions': len(decisions), 'sl_records': len(sl), 'exit_code': 0}))

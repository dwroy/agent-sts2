"""Project this batch's fixed evidence without inventing missing outcomes."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(raw):
    return {p['power_id']: p.get('amount') for p in raw.get('powers', [])}


def main():
    states = collections.defaultdict(list)
    checked = {}
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    for stream in manifest:
        name = stream['stream']
        counts = collections.Counter()
        digest = hashlib.sha256()
        path = HERE / 'evidence' / (name + '.evidence.jsonl')
        selected_input = path.open('rb') if path.exists() else gzip.open(str(path) + '.gz', 'rb')
        with selected_input as selected, Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as original:
            for raw in selected:
                digest.update(raw)
                x = json.loads(raw)
                original.seek(x['offset'])
                source = original.read(x['bytes'])
                assert source.endswith(b'\n')
                assert hashlib.sha256(source).hexdigest() == x['sha256']
                assert json.loads(source) == x['row']
                assert x['offset'] + x['bytes'] <= stream['source_size']
                counts[x['run_id']] += 1
                if name != 'states':
                    continue
                row = x['row']
                s = row['state']
                run = s.get('run') or {}
                assert run.get('character_id', '').lower() == 'silent'
                combat = s.get('combat') or {}
                player = combat.get('player') or {}
                hand = combat.get('hand') or []
                states[x['run_id']].append({
                    'line': x['line'], 'offset': x['offset'], 'sha256': x['sha256'],
                    'ts': row['ts'], 'floor': run.get('floor'), 'turn': s.get('turn'),
                    'screen': s.get('screen'), 'hp': run.get('current_hp'),
                    'max_hp': run.get('max_hp'), 'block': player.get('block'),
                    'energy': player.get('energy'), 'cards_played': player.get('cards_played_this_turn'),
                    'ready': combat.get('action_readiness', {}).get('can_use_combat_actions'),
                    'powers': powers(player),
                    'relics': run.get('relics', []),
                    'potions': [{'slot': p.get('slot_index', p.get('index', i)), 'id': p.get('potion_id'),
                                 'occupied': p.get('occupied')} for i, p in enumerate(run.get('potions', []))],
                    'hand': [{'id': c.get('card_id'), 'index': c.get('index'), 'upgraded': c.get('upgraded'),
                              'vars': {v['name']: [v.get('base_value'), v.get('current_value')] for v in c.get('dynamic_values', [])}}
                             for c in hand],
                    'enemies': [{'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'block': e.get('block'),
                                 'powers': powers(e), 'intents': e.get('intents'), 'alive': e.get('is_alive')}
                                for e in combat.get('enemies', [])],
                })
        assert digest.hexdigest() == stream['output_sha256']
        assert all(counts[r] == n for r, n in stream['counts'].items())
        checked[name] = {'source_size': stream['source_size'], 'rows': sum(counts.values()),
                         'counts': dict(counts), 'sha256': digest.hexdigest()}
    save('raw-integrity.json', checked)
    save('state-projections.json', states)

    windows = []
    floors = []
    for run, rows in states.items():
        by_floor = collections.defaultdict(list)
        for row in rows:
            by_floor[row['floor']].append(row)
        for floor, group in by_floor.items():
            active = [r for r in group if r['screen'] == 'COMBAT' and r['enemies']]
            if not active:
                continue
            floors.append({'run': run, 'floor': floor, 'first': active[0]['line'],
                           'last': group[-1]['line'], 'entry_hp': active[0]['hp'],
                           'exit_hp': group[-1]['hp'], 'last_screen': group[-1]['screen'],
                           'enemies': [e['id'] for e in active[0]['enemies']]})
            attempt = 1
            previous_turn = None
            segments = []
            segment = []
            for row in active:
                if previous_turn is not None and row['turn'] < previous_turn:
                    if segment:
                        segments.append(segment)
                    segment = []
                    attempt += 1
                row['attempt'] = attempt
                segment.append(row)
                previous_turn = row['turn']
            if segment:
                segments.append(segment)
            if (run, floor) in [('WQZVENQ7DTRP', 33), ('TXZ6RVMQA09D', 48),
                                ('NHA2KW0RB7VP', 33), ('Q6M2Y34MWKRE', 8), ('1913SE84AXQF', 31)]:
                for i, segment in enumerate(segments, 1):
                    turns = collections.defaultdict(list)
                    for row in segment:
                        turns[row['turn']].append(row)
                    windows.append({'run': run, 'floor': floor, 'attempt': i,
                                    'turns': [{'turn': t, 'first': group[0], 'last': group[-1]}
                                              for t, group in turns.items()]})
    save('combat-windows.json', windows)
    save('floor-resources.json', floors)

    observed = []
    for run, rows in states.items():
        for before, after in zip(rows, rows[1:]):
            if before['floor'] != after['floor'] or before['turn'] != after['turn']:
                continue
            old = {p['slot']: p['id'] for p in before['potions'] if p['occupied']}
            new = {p['slot']: p['id'] for p in after['potions'] if p['occupied']}
            lost = [slot for slot, value in old.items() if value == 'CUNNING_POTION' and new.get(slot) != value]
            if not lost:
                continue
            old_shivs = sum(c['id'] == 'SHIV' for c in before['hand'])
            new_shivs = sum(c['id'] == 'SHIV' for c in after['hand'])
            observed.append({'run': run, 'floor': before['floor'], 'turn': before['turn'],
                             'before_line': before['line'], 'after_line': after['line'], 'slots': lost,
                             'before_hand': len(before['hand']), 'after_hand': len(after['hand']),
                             'shivs_added': new_shivs - old_shivs,
                             'hp': [before['hp'], after['hp']], 'energy': [before['energy'], after['energy']],
                             'new_shivs': [c for c in after['hand'] if c['id'] == 'SHIV'],
                             'before_powers': before['powers'], 'after_powers': after['powers']})
    save('cunning-transitions.json', observed)
    print(json.dumps({'verified_streams': checked, 'cunning_transitions': len(observed),
                      'combat_windows': len(windows)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location('extractor', WORKTREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)

STATE_LINES = {
    278383, 278403, 278404, 278405, 278406, 278407,
    278500, 278501, 278502, 278503, 278504, 278505,
    279460, 279461, 279462, 279463, 279464, 279465,
    279511, 279512, 279513, 279514, 279515, 279559, 279560,
    280160, 280161, 252435, 252436,
    280206, 280207, 280232, 280233, 280262, 280263,
    280313, 280314, 280315, 280316, 280348, 280349, 280354, 280355,
}
DECISION_LINES = {
    272361, 272362, 272434, 272575, 272531, 272652, 272483, 272820,
    274087, 274131, 274156, 274185, 274235, 274237, 274267, 274272,
    274505, 274568, 274484, 274601, 274354,
}

def power_list(raw):
    return [{k: p.get(k) for k in ['power_id', 'amount']} for p in raw or []]

def state_projection(envelope):
    row = envelope['row']
    state = row.get('state') or {}
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'run_id': envelope['run_id'], 'line': envelope['line'],
        'offset': envelope['offset'], 'bytes': envelope['bytes'], 'sha256': envelope['sha256'],
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'powers': power_list(player.get('powers')),
        'potions': run.get('potions'),
        'hand': [{k: c.get(k) for k in ['index', 'card_id', 'name', 'upgrade_level']} for c in combat.get('hand') or []],
        'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'is_alive', 'move_id', 'intents']}
                    | {'powers': power_list(e.get('powers'))} for e in combat.get('enemies') or []],
    }

manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
runs = set(json.loads((SCRATCH / 'dispatch.json').read_text())['runs'])
verified = []
anchors = {'states': [], 'decisions': [], 'sl': []}
turns = {}
handles = {}
try:
    for stream in manifest:
        name = stream['stream']
        output = SCRATCH / 'evidence' / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = dict.fromkeys(runs, 0)
        for line in output.open('rb'):
            digest.update(line)
            item = json.loads(line)
            assert item['run_id'] in runs
            assert extractor.run_identity(item['row']) == item['run_id']
            source = item['source']
            if source not in handles:
                handles[source] = open(source, 'rb')
            handle = handles[source]
            assert item['offset'] + item['bytes'] <= stream['source_size']
            handle.seek(item['offset'])
            raw = handle.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            counts[item['run_id']] += 1
            if name == 'states':
                if item['line'] in STATE_LINES:
                    anchors['states'].append(state_projection(item))
                state = item['row'].get('state') or {}
                run = state.get('run') or {}
                floor, turn = run.get('floor'), state.get('turn')
                if floor in [17, 33] and state.get('in_combat') and type(turn) is int:
                    key = (item['run_id'], floor)
                    group = turns.setdefault(key, {'attempt': 0, 'last_turn': None, 'rows': {}})
                    if group['last_turn'] is None or turn < group['last_turn']:
                        group['attempt'] += 1
                    group['last_turn'] = turn
                    slot = (group['attempt'], turn)
                    snapshot = state_projection(item)
                    if slot not in group['rows']:
                        group['rows'][slot] = {'first': snapshot, 'last': snapshot}
                    else:
                        group['rows'][slot]['last'] = snapshot
            elif name == 'decisions' and item['line'] in DECISION_LINES:
                anchors['decisions'].append(item)
            elif name == 'sl-attempts' and item['line'] in [681, 717, 960, 961, 962, 963]:
                anchors['sl'].append(item)
        assert digest.hexdigest() == stream['output_sha256']
        assert counts == stream['counts']
        verified.append({'stream': name, 'rows': sum(counts.values()), 'counts': counts,
                         'source_size': stream['source_size'], 'output_sha256': digest.hexdigest(),
                         'all_raw_offsets_sha_json_identity_verified': True})
finally:
    for handle in handles.values():
        handle.close()

assert {v['line'] for v in anchors['states']} == STATE_LINES
assert {v['line'] for v in anchors['decisions']} == DECISION_LINES
for filename, value in [
    ('evidence-verification.json', {'streams': verified, 'total_rows': sum(v['rows'] for v in verified)}),
    ('state-anchors.json', anchors['states']),
    ('decision-anchors.json', anchors['decisions']),
    ('sl-anchors.json', anchors['sl']),
    ('turn-endpoints.json', [dict(run_id=k[0], floor=k[1], attempts=v['attempt'],
                                turns=[dict(attempt=key[0], turn=key[1], **row) for key, row in v['rows'].items()])
                              for k, v in turns.items()]),
]:
    (SCRATCH / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(v['rows'] for v in verified),
                  'streams': len(verified), 'state_anchors': len(STATE_LINES),
                  'decision_anchors': len(DECISION_LINES)}, ensure_ascii=False))

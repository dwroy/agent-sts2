import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
states = {row['line']: row for row in json.loads((scratch / 'state-anchors.json').read_text())}
decisions = {row['line']: row['row'] for row in json.loads((scratch / 'decision-anchors.json').read_text())}
turns = {(group['run_id'], group['floor'], row['attempt'], row['turn']): row
         for group in json.loads((scratch / 'turn-endpoints.json').read_text()) for row in group['turns']}
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


for a, b in [(272434, 272575), (272531, 272652), (272483, 272820),
             (274505, 274568), (274484, 274601)]:
    check(f'同指纹d{a}/{b}', decisions[a]['fingerprint'], decisions[b]['fingerprint'])

for run, floor, attempt, turn, expected in [
    ('751FN9QM9MHQ', 17, 1, 2, [13, 9]), ('751FN9QM9MHQ', 17, 3, 2, [18, 18]),
    ('751FN9QM9MHQ', 17, 2, 7, [13, 12]), ('751FN9QM9MHQ', 17, 4, 7, [23, 18]),
    ('751FN9QM9MHQ', 17, 1, 13, [8, 17]), ('751FN9QM9MHQ', 17, 6, 13, [2, 11]),
    ('KV0JHNJCKXLS', 33, 4, 5, [0, 36]), ('KV0JHNJCKXLS', 33, 5, 5, [0, 29]),
    ('KEN58SH9SLZ6', 17, 4, 10, [15, 2]), ('KEN58SH9SLZ6', 17, 5, 10, [21, 4]),
    ('KEN58SH9SLZ6', 17, 4, 5, [7, 1]), ('KEN58SH9SLZ6', 17, 6, 5, [5, 2]),
]:
    first = turns[(run, floor, attempt, turn)]['first']
    after = turns[(run, floor, attempt, turn + 1)]['first']
    # Endpoint differences are not a decomposition of causal damage sources.
    actual = [first['hp'] - after['hp'], first['enemies'][0]['current_hp'] - after['enemies'][0]['current_hp']]
    check(f'{run} F{floor} 第{attempt}试T{turn}已观测净差', actual, expected)

for line, poison in [(280160, 2), (280161, 8)]:
    state = states[line]
    enemy = state['enemies'][0]
    amount = next(power['amount'] for power in enemy['powers'] if power['power_id'] == 'POISON_POWER')
    incoming = sum(intent.get('damage', 0) * intent.get('hits', 1) for intent in enemy['intents'] if intent.get('damage') is not None)
    check(f'巨兽s{line}', [state['hp'], state['block'], enemy['max_hp'], amount, incoming],
          [26, 13, 999999999, poison, 41])
check('PU过自爆后的实际HP', states[252436]['hp'], 2)

for before, after, slot, potion in [
    (280206, 280207, 0, 'ATTACK_POTION'), (280232, 280233, 0, 'STABLE_SERUM'),
    (280262, 280263, 0, 'SPEED_POTION'), (280313, 280314, 1, 'WEAK_POTION'),
    (280315, 280316, 0, 'ATTACK_POTION'), (280348, 280349, 1, 'GLOWWATER_POTION'),
    (280354, 280355, 0, 'SKILL_POTION'),
]:
    a = next(item for item in states[before]['potions'] if item['index'] == slot)
    b = next(item for item in states[after]['potions'] if item['index'] == slot)
    check(f'KEN药栏s{before}/{after}', [a['potion_id'], a['occupied'], b['occupied']], [potion, True, False])

requests = [decisions[line] for line in [274131, 274156, 274185, 274235, 274237, 274267, 274272]]
check('七次已记录用药请求', [row['chosen']['action'] for row in requests], ['use_potion'] * 7)
check('七次用药请求pending数', sum(str(row.get('result', '')).startswith('pending') for row in requests), 3)

output = {'scope': '原始证据与算术核验；不认证完整候选执行、逐来源因果或生产策略收益',
          'checks': checks, 'passed': sum(row['passed'] for row in checks), 'total': len(checks)}
(scratch / 'material-checks.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
assert all(row['passed'] for row in checks), [row for row in checks if not row['passed']]
print(json.dumps({'material_checks': len(checks), 'passed': output['passed']}, ensure_ascii=False))

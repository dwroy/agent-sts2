import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
dispatch = json.loads((scratch / 'dispatch.json').read_text())
items = json.loads((scratch / 'assigned-proposals.json').read_text())['items']
manifest = json.loads((scratch / 'evidence/evidence-manifest.json').read_text())
verification = json.loads((scratch / 'evidence-verification.json').read_text())
checks = json.loads((scratch / 'material-checks.json').read_text())
comparison = json.loads((scratch / 'prior-evidence-comparison.json').read_text())
sources = json.loads((scratch / 'source-audit.json').read_text())
assert verification['total_rows'] == 8444
assert checks['passed'] == checks['total'] == 29
assert all(row['same_output_sha'] and row['same_counts'] for row in comparison['streams'])
assert all(row['live_ancestor'] for row in sources['paths'])

evidence = {
    '366288801d9150d9': '751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820',
    '85929bdfc8a3fc1b': '751FN9QM9MHQ F13 T3 d272361/272362；F17 T7/T13/T17',
    'efd9f83ee9e1a6dc': '751FN9QM9MHQ F17 T2/T7/T13；与366288为同一局六次尝试',
    '131042659448ae74': '751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17',
    '990f054036609447': 'KV0JHNJCKXLS F33 第4/5试T5 s279460—279465/279511—279515；末试T4 s279559/279560',
    'e18d3f18e6cac2a0': 'YQL8RZ8BWN1E F17 T10 s280160/280161；L9SGRBB5R698 F17 T14 sl681；PU80F84P6HPN F17 T17 sl717',
    '9733bb80f445aeae': 'YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 s252435/252436',
    'c51468c5e8ba6668': 'KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；d274131/274156/274185/274235/274237/274267/274272',
    '86a7db08d1a31976': 'KEN58SH9SLZ6 F17 第4/5试T10 d274505/274568；第4/6试T5 d274484/274601',
    'e282a9131b99129a': 'KEN58SH9SLZ6 F17 T2/T5/T10；d274354/274484/274601/274505/274568',
}
reasons = {
    '366288801d9150d9': '已有SL当轮预测拆项；缺抽弃及续问后的完整候选归属、逐来源实结算和受控整战后继，局部5/10血差不足设探索门槛。',
    '85929bdfc8a3fc1b': '已有未决持牌失血和持药未知提示；缺F13同题不饮药的实际完整分支及留药后战对照，不能拟合持有价。',
    'efd9f83ee9e1a6dc': '与366288共享751一局六试；已有预测不认证完整执行，缺独立整战验证，不能把相关SL当独立校准样本。',
    '131042659448ae74': '分项预测已有实现；缺攻击、毒、荆棘、持牌失血及敏捷的联合实结算校准和跨战用药对照。',
    '990f054036609447': '同盘零净损及敌净扣36/29可核；缺毛伤与回血逐来源归属、保持后轮条件的整战对照及路线休息替代后继。',
    'e18d3f18e6cac2a0': '巨兽阶段和残壳用毒事实已有提示；缺参考路径改序与提前喝、不喝、留药的受控完整后继，不能据占位血归零证明改序更优。',
    '9733bb80f445aeae': '残壳毒2至8未改41自爆、PU过爆余2血已核；缺阶段估值、排序及用药时点的整战对照，已有子功能不能关闭整项。',
    'c51468c5e8ba6668': '七次用药请求均有药栏消耗端点，三次回执pending；缺随机选牌、重问后的完整收益和留至Boss的受控对照。',
    '86a7db08d1a31976': 'T10多2净伤付6血、T5省2血但延后能力均可核；缺逐来源兑现、保持后轮条件的对照及独立验证。',
    'e282a9131b99129a': '持牌、无实体与能力窗口仅有局部取舍；缺完整候选认证和受控整战后继，不设统一6血换2伤阈值。',
}
results = [{'id': ident, 'state': 'waiting', 'reason': reasons[ident.removeprefix('silent-proposal-')]}
           for ident in dispatch['proposal_ids']]
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == '6c3a776b741276285beb422d2f9be98c6112851a'
result = {
    'task': 'strategy-proposal', 'character': 'silent',
    'batch': '20261017-073111-strategy-proposal',
    'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': results, 'report': str(scratch / 'report.md'),
}
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
rows = []
for ident in dispatch['proposal_ids']:
    short = ident.removeprefix('silent-proposal-')
    rows.append(f"| {ident} | {evidence[short]} | {'、'.join(items[ident]['ledger'])} | waiting：{reasons[short]} |")
table = '\n'.join(['| 原CLI id | 证据局／层／回合 | 既有账本 | 逐项处置 |',
                   '|---|---|---|---|', *rows])
run_table = ['| 局号 | states | decisions | SL行 | run-plans |', '|---|---:|---:|---:|---:|']
by_stream = {row['stream']: row for row in manifest}
for run in dispatch['runs']:
    run_table.append('| ' + run + ' | ' + ' | '.join(str(by_stream[name]['counts'][run])
                     for name in ['states', 'decisions', 'sl-attempts', 'run-plans']) + ' |')

proposal = f'''# 静默猎手十项策略提案的本批处置

批次：20261017-073111-strategy-proposal。来源与实现任务均为strategy-proposal；只消费本批十个原CLI id，不另建重复提案。
角色：silent；本批六局均为A10。Roy-2026-10-07-learning是修改规则的既有授权，不是任何游戏事实的证据。

{table}

## 既有行为与预期行为

当前SL资源比较与选择审计只给模型预测，execution为unverified，单动作回执的whole_plan_executed仍为null；持牌损血保留未决弃牌边界，未知药水持有价为null；巨兽本体结束、自爆待结算与残壳用毒已有事实说明。已有实现的真实live祖先见source-audit.json，不把这些子功能记为十项完整实现。

预期待验证行为为：原答、护栏／SL替线、抽弃／随机选牌／用药／重问的实际续步有完整归属；攻击、毒、荆棘、持牌失血、敌回血与能力建立分别核实。缺数据时保留现有排序、HP护栏、探索和用药规则，不拟合统一血价、留药价或阶段权重。

## 支持、反例与未知

751同盘T2净损13→18、敌净扣9→18；T7净损13→23、敌净扣12→18；T13净损8→2、敌净扣17→11。KEN同盘T10净损15→21、敌净扣2→4；反向T5净损7→5、敌净扣1→2，但能力从T5延后到T9。局部少掉血与多输出均有取舍，不支持单一方向的固定策略。相关SL属于同一局，不独立计样本。

巨兽s280160/280161残壳毒2→8，玩家26血、13挡、来袭41均未变；PU s252436实际奖励页余2血。不能由此推出提前喝必胜，或本体结束已获胜。KV同盘T5净损均0、敌净扣36／29，不能把删输出称为已观测保血收益；后续动作变化仍是混杂。KEN七次用药请求及消耗端点可核，但三个pending回执、随机选择与重问不能升格为完整方案收益。

## 验证、样本切分、预期影响与回退

固定验证以八流原字节封套、指纹、SL身份和动作边界为输入，已复核8444条原offset／bytes／SHA／JSON／局身份及29项材料算术。生产测试没有运行，这些材料核验不能替代tsc／vitest、完整候选认证或胜率检验。完整后继与独立留出局不足，本批不调参；未来若拟合，须按独立局和开始时间划分早期调参与后期验证，相关SL不拆入训练和留出集。

预期影响仅为保存可审计缺口，不能承诺胜率提高。无源码或知识变化，无本批回退提交；未来实现撤回其独立源码提交并保留原日志、失败、反例和原提案。铁甲战士及其他未观察角色、进阶均未改变。
'''
(scratch / 'proposal.md').write_text(proposal)

source_table = ['| 已有子功能／工具 | 已核实际live祖先源码提交 |', '|---|---|']
for row in sources['paths']:
    source_table.append(f"| {row['path']} | {row['live_last_touch_commit']} |")
report = f'''# 策略提案消费报告

十项原提案全部waiting；没有源码／知识修改、提交、合入、版本或shipped登记。fixes=[]、merged=null，生产tests全为null。每项保留明确缺数据理由，不因已有局部诊断关闭完整要求。

## 派发身份与基线

task=strategy-proposal、character=silent、batch=20261017-073111-strategy-proposal、reason=proposal；本批worktree和六个runs精确匹配。十项proposal_ids无重复；无research_request、implementation_request、proposal_repair。普通专题文件绑定另一个旧批次，不符合本批身份，未读取其他专题代替本批范围，也未扩展到其他排队项。

开工git status干净；git merge --no-edit main返回Already up to date。完整report.base={base}，HEAD没有通过研究提交自造新基线。scratch已被Git忽略，最终另核tracked/index/HEAD。

已读README、最新STATE-2026-10-16、decision-log末尾、学习协议及代码提案协议。只分析本角色对局、十二个相关silent经验和十六个既有silent账本；没有读取其他角色知识。独立完成，无下级agent、联网、模型请求、游戏API、play或模拟池。

本批启动器记录核到gpt-6.1-sol / xhigh / default。任务旧文字high与实际启动参数xhigh分列；没有修改运行配置、强度、线程或账号。未独立核原生模型请求／服务回执，不能以启动器配置代替原生实际请求证明，见runtime-launch-audit.json。历史对局的大脑来源与+dirty标识保持，不声称复原完整历史运行树或将混合来源改记纯Codex。

## 冻结证据与增量边界

先经共用extract_evidence.py的runs、run-config流核六局均为SILENT A10，再以共用入口提取八流。各流source_size、逐行offset／bytes／SHA和计数在evidence/中；身份只认run_id、state.run_id、run-plans.run与fingerprint.run，冲突身份拒收，不把正文提及当所属局。提取实际退出0。

{chr(10).join(run_table)}

八流8444封套逐一seek原日志核对截点、SHA、JSON和显式身份，43个状态锚点与21个决策锚点另存；29项材料核验全部通过。verification.stdout.txt和material-checks.stdout.txt分别为实际输出。SL共43行含其他楼层尝试，不能当43个独立局。

与上一同十项批次20261017-000038逐流比较，八个所选输出SHA及counts完全相同；全源增长没有给本批六个旧局增加证据或新独立验证样本。旧run-plans source_size=8701716的21行另用--streams run-plans --source-size重提至prior-run-plans-cutoff/，输出SHA也相同。没有覆盖旧报告或零行初稿。fight-plans在此截点零匹配，只说明未选中，不说明原日志缺失或未执行。全源invalid和incomplete照manifest原值保存，不将全源坏行计数归为本批局缺帧。

## 逐项结果

{table}

## 从局部观察能得出的结论

751 F17 T2／T7／T13配对指纹与净差均核：T2净损13／18、敌净扣9／18；T7净损13／23、敌净扣12／18；T13净损8／2、敌净扣17／11。多输出有实际血价，省血也可能少输出。T7两条线都有未决弃牌导致的保守上界，不能把绝对上界误差当成两条实线的10血差，更不能猜已弃掉哪张呼唤。六次尝试仍只是一局。

751 F13 T3原题保留有药／无药候选，即时损血同8、记录五轮均8/8胜；用药牌伤26、无药16属于原模型参考。没有实际执行无药完整战斗或留到Boss的受控结果，成本0与持有价未知须分开。当前已有silent-potion-reference，不能重复实现相同提示或据败局补一个固定药价。

KV F33第4/5试T5原盘一致，净损均0、敌净扣36／29；原提案的下一轮毒20／13及末试T4敌327／毒15→下一轮敌342／毒14，均限于所列帧与复盘来源。净差不等于毛伤与回血已逐来源隔离；后轮动作亦变，不能从一次删毒推断整战胜因，路线／休息替代支线也没有实际后继。

YQL s280160→280161残壳毒2→8，26血、13挡、41自爆来袭不变；PU s252435→252436为24血20挡对42、随后奖励页余2。结束本体、观察到残壳施毒、整场胜利分别记录。提前喝、不喝或留药的完整收益没有得到验证。原提案明确指出：简单把占位体残血统一成0，沿旧同轮平局顺序可能选到资源缺口更大的路径；本批没有受控依据更改参考排序。

KEN F17第4/5试T10同指纹，净损15／21、敌净扣2／4；第4/6试T5同指纹，净损7／5、敌净扣1／2，但末试步法延至T9建立。这反对只看当轮最少失血的推断，也不证明旧线整战能赢。七次use_potion均有前后槽位消耗，d274131／274237／274272回执pending；不把空槽、单步completed或零净损当作随机选牌、追加小刀和重问后完整收益认证。

本批未得到新的机制反证或与旧知识冲突，不新增support/repeat、机制、权重或通关收益结论。原始失败、旧提案和本轮输出过量／不存在路径查询的过程记录均保留，未据查询失误推断证据不存在。

## 当前源码和未完成要求

只读live截点={sources['live']}。19个相关源码叶逐SHA／祖先核；16叶与本树相同，potion-cost、sl/explore、sl/controller三叶仅历史Roy/Dai注释署名差，精确差分见base-live-source.patch。与前批base比较17叶相同；turn-solver与combat-plan另有既有紧勒和重抽接线变化，见prior-base-source.patch，不把前批源码绿冒作当前整库验证。

silent-sl-resource-comparison标current_turn_prediction且execution=unverified；silent-selection-audit是predicted_candidates，silent-selection-dispatch只给single_action_receipt、whole_plan_executed=null。held-loss保留actual_held_hp_loss=null与未决弃牌说明，potion-reference保留hold_hp=null／成本0差异及同题无药参考。giant阶段、残壳施毒提示存在；anchorRank仍按存活回合及原始enemyHpLeft等排序。

离线消费者selection-execution／observation／terminal／turn提供端点、重问与整轮窗口，但actual_full_candidate_result、causal_candidate_result等仍为未知。只读核源码，没有重复运行这些消费者或任何模型／模拟；消费者未认证不能倒推实际未执行。完整候选归属、逐来源联合结算与受控后继仍未完成，因此不将任何一项回报duplicate或implemented。

{chr(10).join(source_table)}

上表只证明已有子功能实际live祖先，不是本批源码提交或十项整体验收。源文件内引用的其他silent局仅作为已有实现来源，未新增为本批支持样本。

## 预期行为、验证和回退

待有完整证据时，将原答、HP护栏／SL替线与抽弃、生成、用药、重问后续步关联，分别校准攻击／毒／荆棘、持牌失血、敌回血与能力兑现窗口。可依据既有授权直接修改本角色规则，但授权不提供任何游戏结论。先固定原帧及动作边界，再取得同条件完整后继；模型样本与实盘反事实分列。需拟合时按独立局、真实开始时间切分早期调参与后期留出，不将相关SL拆成独立训练／验证。本批不调参，不承诺胜率提升。

无源码变化，未做撤源码失败／恢复通过，未跑tsc或vitest，未复用历史测试冒称当前成功；tests={{"tsc":null,"vitest":null,"cases":null}}。材料29项通过只核指纹、局部净差和药槽等事实。没有live合入、刷新知识提交、eval版本、实际上线双通知或行为回退；未来实现按其独立提交回退并保留全部历史。铁甲和未观察范围行为没有改变。

## 账本与交付

只经根learner/ledger.py update为16个既有silent账本追加本批proposal/report去处及逐项waiting理由，by=learner:strategy-proposal。旧条目已有shipped状态和历史版本，保留其claim、首证、prior、evidence、status、version、effect及旧history／notes／where前缀；本批不倒退为proposed，不新建相同条目或重算支持次数。CLI输入、退出、物理字节读回与保护字段核验将保存在ledger-updates.jsonl、ledger-readback.json等文件，最终实际结果另追加。专用队列由最终proposal_results交调度器，不手写队列状态，不新建重复代码提案id，不代运维登记shipped。

正式提案：{scratch / 'proposal.md'}。
正式报告：{scratch / 'report.md'}。
结构化结果：{scratch / 'result.json'}。
code_proposals为本批十个既有真实CLI id，implementation_domains=[]。没有源码提交或合入受阻补丁；其余waiting缺口保留待本角色新局或完整可核后继再派。
'''
(scratch / 'report.md').write_text(report)
print(json.dumps({'report': str(scratch / 'report.md'), 'proposals': len(results),
                  'ledger_ids': len({i for p in items.values() for i in p['ledger']})}, ensure_ascii=False))

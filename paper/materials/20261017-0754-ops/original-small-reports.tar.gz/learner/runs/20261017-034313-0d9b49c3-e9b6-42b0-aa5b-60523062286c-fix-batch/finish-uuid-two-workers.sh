#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
export SANDBOX_WORKERS=2
cd /home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261017-034302
date
while ! test -f "$TMPDIR/uuid-sandbox-r3.exit"; do sleep 10; done
test "$(cat "$TMPDIR/uuid-sandbox-r3.exit")" != 0
test ! -f "$TMPDIR/uuid.commit"
test "$(git rev-parse HEAD)" = "$(cat "$TMPDIR/target-fixture.commit")"
cd agent
npx vitest run tests/target-options.test.ts tests/potions-jev-call.test.ts --pool=threads --maxWorkers=2 > "$TMPDIR/uuid-r3-failed-cases-rerun.log" 2>&1
date
if bash tools/test-sandbox.sh > "$TMPDIR/uuid-sandbox-r4.log" 2>&1; then
  printf '0\n' > "$TMPDIR/uuid-sandbox-r4.exit"
else
  check_code=$?
  printf '%s\n' "$check_code" > "$TMPDIR/uuid-sandbox-r4.exit"
  tail -n 65 "$TMPDIR/uuid-sandbox-r4.log"
  exit "$check_code"
fi
cd ..
git add -- ops/learner_retention.py ops/tests/test_learner_retention.py agent/tests/learner-retention-uuid.test.ts
gitleaks git --staged --redact --no-banner > "$TMPDIR/uuid-gitleaks.log" 2>&1
date
git commit -F "$TMPDIR/uuid-commit.txt"
git rev-parse HEAD > "$TMPDIR/uuid.commit"
printf 'UUID_COMMITTED\n'
tail -n 17 "$TMPDIR/uuid-sandbox-r4.log"
git status --short

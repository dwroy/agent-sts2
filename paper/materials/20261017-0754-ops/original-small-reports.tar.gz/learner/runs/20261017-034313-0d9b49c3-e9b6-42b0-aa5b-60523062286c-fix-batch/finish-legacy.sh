#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
export SANDBOX_WORKERS=1
cd /home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261017-034302
date
printf '%s\n' "$$" > "$TMPDIR/legacy-runner.pid"
printf 'WAITING_FOR_UUID_COMMIT\n'
retention_wait_count=0
while ! test -f "$TMPDIR/uuid.commit"; do
  for retention_check in wrapper-sandbox.exit uuid-sandbox-r2.exit; do
    if test -f "$TMPDIR/$retention_check" && test "$(cat "$TMPDIR/$retention_check")" != 0; then
      printf 'UPSTREAM_CHECK_FAILED %s\n' "$retention_check"
      exit 2
    fi
  done
  retention_wait_count=$((retention_wait_count + 1))
  if test "$retention_wait_count" -gt 720; then
    printf 'UPSTREAM_COMMIT_NOT_AVAILABLE\n'
    exit 2
  fi
  sleep 10
done
if test -n "$(git status --porcelain --untracked-files=all)"; then
  git status --short
  exit 2
fi
date
printf 'APPLYING_LEGACY_FIX\n'
git apply --check "$TMPDIR/legacy-implementation.patch"
git apply "$TMPDIR/legacy-implementation.patch"
cp "$TMPDIR/legacy-tests-final-draft.py" ops/tests/test_legacy_learner_retention.py
cp "$TMPDIR/legacy-wrapper-draft.ts" agent/tests/learner-retention-legacy.test.ts
cd agent
npx vitest run tests/learner-retention-legacy.test.ts --pool=threads --maxWorkers=1 > "$TMPDIR/legacy-fixed.log" 2>&1
cd ..
git diff --binary -- ops/learner_retention.py > "$TMPDIR/legacy-source.patch"
git restore --source=HEAD -- ops/learner_retention.py
cd agent
if npx vitest run tests/learner-retention-legacy.test.ts --pool=threads --maxWorkers=1 > "$TMPDIR/legacy-without-fix.log" 2>&1; then
  retention_red_code=0
else
  retention_red_code=$?
fi
cd ..
git apply "$TMPDIR/legacy-source.patch"
printf 'without_fix_exit=%s restore_exit=0\n' "$retention_red_code" > "$TMPDIR/legacy-regression-summary.txt"
if test "$retention_red_code" = 0; then
  printf 'REGRESSION_DID_NOT_FAIL\n'
  exit 2
fi
rg -q 'scratch ownership not bound to original report' "$TMPDIR/legacy-without-fix.log"
cd agent
npx vitest run tests/learner-retention-legacy.test.ts --pool=threads --maxWorkers=1 > "$TMPDIR/legacy-restored.log" 2>&1
date
if bash tools/test-sandbox.sh --reporter=dot > "$TMPDIR/legacy-sandbox.log" 2>&1; then
  printf '0\n' > "$TMPDIR/legacy-sandbox.exit"
else
  retention_check_code=$?
  printf '%s\n' "$retention_check_code" > "$TMPDIR/legacy-sandbox.exit"
  tail -n 45 "$TMPDIR/legacy-sandbox.log"
  exit "$retention_check_code"
fi
cd ..
git add -- ops/learner_retention.py ops/tests/test_legacy_learner_retention.py agent/tests/learner-retention-legacy.test.ts
gitleaks git --staged --redact --no-banner > "$TMPDIR/legacy-gitleaks.log" 2>&1
date
git commit -F "$TMPDIR/legacy-commit.txt"
git rev-parse HEAD > "$TMPDIR/legacy.commit"
printf 'LEGACY_COMMITTED\n'
tail -n 17 "$TMPDIR/legacy-sandbox.log"
git status --short

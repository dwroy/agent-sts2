from pathlib import Path
import ast
import difflib
import hashlib
import re

scratch = Path(__file__).parent
source = Path('ops/learner_retention.py').read_text()
helper = (scratch / 'legacy-helper-draft.py').read_text()
new = source.replace('def admission(root, state_dir, state, batch_id, check_ignored=True):',
                     helper + '\n\ndef admission(root, state_dir, state, batch_id, check_ignored=True):')
old = '''    scratch = safe_path(root, report.get("report", ""))
    scratch = scratch.parent
    if scratch.parent != tree / "learner/runs" or not SCRATCH.fullmatch(scratch.name) or not scratch.is_dir():
        raise ValueError("scratch ownership not bound to original report")'''
replacement = '''    binding = {}
    if task == "experience-update" and not report.get("report"):
        scratch, binding = legacy_experience_scratch(root, state_dir, tree, batch_id, batch, report)
    else:
        scratch = safe_path(root, report.get("report", "")).parent
        if scratch.parent != tree / "learner/runs" or not SCRATCH.fullmatch(scratch.name) or not scratch.is_dir():
            raise ValueError("scratch ownership not bound to original report")'''
assert new.count(old) == 1
new = new.replace(old, replacement).replace(
    'proof = {"task": task, "character": character, "original_batch_state": batch["state"]}',
    'proof = {"task": task, "character": character, "original_batch_state": batch["state"], **binding}')
old = 'if active_cwd(target):\n        raise ValueError("active process cwd retained")'
assert new.count(old) == 1
new = new.replace(old, 'if active_cwd(target) or (proof.get("legacy_binding") and active_cwd(tree)):\n        raise ValueError("active process cwd retained")')
pattern = r'(?m)^([ ]*)if current_proof != proof or active_cwd\(target\):$'
assert len(re.findall(pattern, new)) == 2
new = re.sub(pattern, lambda m: m[1] + 'if (current_proof != proof or active_cwd(target)\n' +
             m[1] + '        or (proof.get("legacy_binding") and active_cwd(tree))):', new)
ast.parse(new)
patch = ''.join(difflib.unified_diff(source.splitlines(keepends=True), new.splitlines(keepends=True),
                                  fromfile='a/ops/learner_retention.py', tofile='b/ops/learner_retention.py'))
(scratch / 'legacy-implementation.patch').write_text(patch)
print('legacy patch', len(patch), hashlib.sha256(patch.encode()).hexdigest())

from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path('/home/dw/Projects/agent-sts2')
worktree = root / '.worktrees/codex-fix-silent-20261017-034302'
live = root / '.worktrees/live'
scratch = Path(__file__).parent
base = 'cb03ffed4d53f75c6d88be341fb8550933ad85de'

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

source = git(worktree, 'rev-parse', 'HEAD')
partial = '--pending-legacy' in sys.argv
assert source == (scratch / ('uuid.commit' if partial else 'legacy.commit')).read_text().strip()
source_status = subprocess.check_output(['git', '-C', str(worktree), 'status', '--porcelain', '--untracked-files=all'], text=True).rstrip('\n')
if partial:
    assert {line[3:] for line in source_status.splitlines()} == {
        'ops/learner_retention.py', 'ops/tests/test_legacy_learner_retention.py',
        'agent/tests/learner-retention-legacy.test.ts'}
else:
    assert not source_status
prefix = 'live-partial-locked-' if partial else 'live-locked-'
before = git(live, 'rev-parse', 'HEAD')
index = Path(git(live, 'rev-parse', '--git-path', 'index'))
if not index.is_absolute():
    index = live / index
index_before = digest(index)
status_before = git(live, 'status', '--porcelain', '--untracked-files=all')
changed = git(worktree, 'diff', '--name-only', base, source).splitlines()
knowledge_dirty = git(live, 'diff', '--name-only', 'HEAD', '--', 'knowledge').splitlines()
knowledge_overlap = sorted(set(changed) & set(knowledge_dirty))
common = git(worktree, 'merge-base', before, source)
branch_knowledge = git(worktree, 'diff', '--name-only', common, source, '--', 'knowledge').splitlines()
live_knowledge = git(worktree, 'diff', '--name-only', common, before, '--', 'knowledge').splitlines()
historical_overlap = sorted(set(branch_knowledge) & set(live_knowledge))
result = subprocess.run(['git', '-C', str(worktree), 'merge-tree', '--write-tree', before, source],
                        capture_output=True, text=True)
(scratch / (prefix + 'merge-preflight.log')).write_text(result.stdout + result.stderr)
conflicts = sorted({line.split('\t', 1)[1] for line in result.stdout.splitlines()
                    if '\t' in line and line.startswith(('100644 ', '100755 ', '120000 '))})
after = git(live, 'rev-parse', 'HEAD')
index_after = digest(index)
now = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
proof = {'at': now, 'source': source, 'live_before': before, 'live_after': after,
         'index_before': index_before, 'index_after': index_after,
         'status_before': status_before, 'status_after': git(live, 'status', '--porcelain', '--untracked-files=all'),
         'source_paths': changed, 'knowledge_dirty': knowledge_dirty, 'knowledge_overlap': knowledge_overlap,
         'merge_base': common, 'branch_knowledge_since_common': branch_knowledge,
         'live_knowledge_since_common': live_knowledge, 'historical_knowledge_overlap': historical_overlap,
         'merge_tree_exit': result.returncode, 'conflicts': conflicts, 'actual_merge': False,
         'pending_legacy_excluded': partial}
(scratch / (prefix + 'preflight.json')).write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(proof, ensure_ascii=False))
assert before == after and index_before == index_after
raise SystemExit(result.returncode)

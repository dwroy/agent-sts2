from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

scratch = Path(__file__).parent
worktree = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261017-034302')
base = 'cb03ffed4d53f75c6d88be341fb8550933ad85de'
pending = '--pending-legacy' in sys.argv

def git(*args):
    return subprocess.check_output(['git', '-C', str(worktree), *args], text=True).strip()

def stats(name):
    assert (scratch / (name + '.exit')).read_text().strip() == '0'
    text = re.sub(r'\x1b\[[0-9;]*m', '', (scratch / (name + '.log')).read_text())
    files = re.findall(r'(?m)^\s*Test Files\s+(\d+) passed', text)
    cases = re.findall(r'(?m)^\s*Tests\s+(\d+) passed', text)
    assert len(files) >= 2 and len(cases) >= 2, name
    return {'tsc': 0, 'vitest': 0, 'files': sum(map(int, files[-2:])), 'cases': sum(map(int, cases[-2:]))}

specs = [
    ('沙箱自测入口：global-build-health 同步 Python 调用误报 EPERM', 'wrapper', 'global-health',
     'agent/tests/global-build-health.test.ts',
     'checks G2 shadow coverage, retained unknowns and real observation timing on fixed inputs', 'wrapper-sandbox-r2', 'spawnSync'),
    ('infra-target-options 后续：EZ2L选线及方案文本题仍使用无限测试预算', 'target-fixture', 'target-fixture',
     'agent/tests/target-options.test.ts',
     "Jev's picking an Amalgam-focus line plays it (no swap to a Queen line with more damage)", 'target-fixture-sandbox', 'expected 1000000000 to be 1500'),
    ('retention 合法数字 UUID scratch 归属误拒收', 'uuid', 'uuid',
     'agent/tests/learner-retention-uuid.test.ts',
     'accepts numeric UUID scratch identities with publication and ownership guards', 'uuid-sandbox-r4', 'scratch ownership not bound'),
    ('retention 旧 experience-update 根目录产物归属误拒收', 'legacy', 'legacy',
     'agent/tests/learner-retention-legacy.test.ts',
     'binds legacy root experience artifacts to the original launch, thread and checked publication', 'legacy-sandbox-r3', 'scratch ownership not bound'),
]
if pending:
    specs = specs[:3]
fixes, validation = [], []
for item, marker, red, test, case, suite, expected in specs:
    commit = (scratch / (marker + '.commit')).read_text().strip()
    assert re.fullmatch('[0-9a-f]{40}', commit)
    subprocess.run(['git', '-C', str(worktree), 'merge-base', '--is-ancestor', commit, 'HEAD'], check=True)
    assert expected in (scratch / (red + '-without-fix.log')).read_text()
    result = stats(suite)
    fixes.append({'item': item, 'commit': commit, 'test': test, 'fails_without_fix': True})
    validation.append({'item': item, 'commit': commit, 'case': case, 'suite': suite, **result})
if not pending:
    assert not git('status', '--porcelain', '--untracked-files=all')
head = git('rev-parse', 'HEAD')
assert head == fixes[-1]['commit']
changed = git('diff', '--name-only', base, head).splitlines()
assert all(p.startswith(('agent/tests/', 'ops/tests/')) or p == 'ops/learner_retention.py' for p in changed)
patch = subprocess.check_output(['git', '-C', str(worktree), 'diff', '--binary', base, head])
(scratch / 'source-all.patch').write_bytes(patch)
proof_path = scratch / ('live-partial-locked-preflight.json' if pending else 'live-locked-preflight.json')
proof = json.loads(proof_path.read_bytes()) if proof_path.exists() else None
deployment_path = scratch / 'live-merge-result.json'
deployment = json.loads(deployment_path.read_bytes()) if deployment_path.exists() else None
merged = deployment.get('deployed') if deployment and deployment.get('state') == 'passed' else None
if proof:
    assert proof['source'] == head and not proof['actual_merge']
    assert proof['live_before'] == proof['live_after'] and proof['index_before'] == proof['index_after']
    assert proof['merge_tree_exit'] in (0, 1)
    merge_reason = ('锁内合并预检冲突：' + '、'.join(proof['conflicts'])) if proof['conflicts'] else '最终锁内预检无冲突；live合并及合后检查仍待完成'
else:
    assert (scratch / ('live-partial-lock-attempt.exit' if pending else 'live-lock-attempt.exit')).read_text().strip() == '75'
    merge_reason = 'live 合并锁忙；此前只读预检有六项历史记录冲突，现场保留'

skipped = json.loads((scratch / 'reviewed-skip-dispositions.json').read_bytes())
skipped += [
    {'item': 'ops-worktree-history-disk-pressure-20261013其余宽范围',
     'reason': '证据不足；本批仅修合法UUID及旧experience产物归属两个窄子项。实际磁盘容量波动、其他保留现场和未归属材料仍沿原运维链，未运行生产回收、未关闭宽父。'},
    {'item': 'infra-test-build-facts-selection-remove-latency（开工后队列新增）',
     'reason': '证据不足；原014302-s2固定四样本题仅首次60秒超时，原断言/时限补验47.187秒通过，未定位产品因果。保原输入及现有普通槽，不削样本或加时限。'},
    {'item': '021302宿主超时与磁盘压力补证（开工后队列新增两条）',
     'reason': '证据不足；Herdr原题补验已过；eval校准与logged boards仍仅超时，原04:52条目明确由下一普通槽接续，不热改本034302批输入。保留原full1/supplement1及原磁盘守卫，不重复派发。'},
]
if pending:
    skipped.append({'item': 'retention旧experience-update根目录产物归属误拒收',
        'reason': '提交前完整检查未通过：首套磁盘不足原1GiB预留，容量恢复后第二套的XC4T缩小及boss-damage-attempts两既有题15秒超时；tsc0、455文件4211项过。缩小题原阈值补验通过，正在按原阈值重跑完整检查。修复已完成撤码失败/恢复通过，未提交；原工作区、legacy-pending-all.patch和全部失败日志保留。'})
result = {'task': 'fix-batch', 'base': base, 'fixes': fixes, 'skipped': skipped, 'merged': merged,
          'tests': {'tsc': 0, 'vitest': 1 if pending else 0, 'cases': 4211 if pending else validation[-1]['cases']},
          'code_proposals': [], 'implementation_domains': [], 'report': str(scratch / 'report.md')}
if deployment:
    merge_reason = deployment.get('reason', merge_reason)
    if merged:
        result['tests'] = {k: v for k, v in stats('live-sandbox').items() if k != 'files'}
    elif deployment.get('state') == 'failed':
        live_log = (scratch / 'live-sandbox.log').read_text()
        passed = re.findall(r'(?m)^\s*Tests\s+.*?(\d+) passed', live_log)
        result['tests'] = {'tsc': 0 if 'RUN ' in live_log else deployment['rc'],
                           'vitest': deployment['rc'], 'cases': int(passed[-1]) if passed else 0}
old = json.loads((scratch / 'queue-audit.json').read_bytes())
lines = ['## 修 bug 回报', '', '- 合并基线：main → ' + base]
for fix, entry in zip(fixes, validation):
    lines.append('- 修复（每条一行）：' + fix['item'] + ' — ' + fix['commit'] + ' — 测试 ' +
                 fix['test'] + ':' + entry['case'] + ' — 去掉修复时失败：是')
for row in old['existing_fixes']:
    lines.append('- 已被别人修掉的：' + row['item'] + ' — ' + row['commit'] + '（仅核已实现窄范围，宽父保持）')
for row in skipped:
    lines.append('- 没修的：' + row['item'] + ' — ' + row['reason'])
for row in validation:
    lines.append(f"- 测试：{row['suite']}：tsc 0；vitest {row['files']} 文件 / {row['cases']} 用例 / 退出码 0。")
if merged:
    live_stats = stats('live-sandbox')
    lines.append(f"- 测试：live合后完整沙箱：tsc0；vitest {live_stats['files']} 文件 / {live_stats['cases']} 用例 / 退出码0；保原阈值和样本，--retry=1。")
lines += [
    '- 测试：首套 tsc0/vitest1（454文件4210项过，global-health同步入口EPERM、XC4T F9T3旧夹具超时）；XC4T原时限重跑1过13未选，7.74秒。',
    '- 测试：单worker/dot完整轮 tsc0/vitest1（452文件4207项过，3文件4项失败）：paper-dataset-git与strategy-concurrency遇真实容量reserve不足，target-options的EZ2L标注及Jev选线题30s/20s超时。三文件原配置重跑26/26过，140.27秒；原失败及当时约798MB可用空间记录保留，后续恢复4GiB以上不归功于本补丁。',
    '- 测试：UUID修复的旧r2整套再次复现EZ2L Jev选线题20秒超时；既有bae9c45c仅包住标注题。本次后续测试修复仅包住两个传输调用，保留新增预算断言做撤码回归，原8样本量化题、生产预算和全部原断言/时限不变。',
    '- 测试：UUID-r3完整轮的XC4T缩小、EZ2L标注、八样本、重复性及整批药水约束五题超时；无断言值不符。后续保持全部原断言、样本数和时限，仅用脚本允许的2worker重跑及完整检查。原失败与重跑日志保留。',
    '- 测试：UUID-r3的target-options与potions-jev-call两个原文件两并发重跑37/37通过，94.21秒（uuid-r3-failed-cases-rerun.log）；不把局部通过代替完整检查。',
    '- 测试：legacy首套tsc0/vitest1：455文件4211项通过，paper-dataset-git与strategy-concurrency两项被真实磁盘不足触发；原1GiB预留守卫不变。两个原文件补验仍失败，补验时容量约826MiB。未删除其他任务材料、未伪造可用容量；等待实际容量恢复后才再次执行完整检查。原失败保留legacy-sandbox.log与legacy-capacity-rerun.log。',
    '- 测试：随后实际可用空间恢复到约5GiB，才启动legacy-sandbox-r2完整检查；容量实测保存在capacity-monitor.jsonl。恢复不归功于本补丁；未清理其他任务材料、未修改生产容量守卫。',
    '- 测试：legacy-r2的原XC4T F9T3缩小题与boss-damage-attempts两题均15秒超时，455文件4211项通过；没有断言值不符。源码未改，缩小题原阈值补验1过13未选、11.50秒（用例8.98秒）。下一轮完整检查使用脚本原有参数转发--retry=1，允许各题原断言/阈值内重跑一次，不延时、不减样本。补验及整套重跑记录分别保存在legacy-shrink-rerun.log与legacy-sandbox-r3.log。',
    '- 测试：第一次UUID撤码命令cwd错误，uuid-without-fix-wrong-cwd.log保留但不计回归证明；正确cwd的源码撤回失败及恢复通过另存。正式源码各红绿日志保留；内存原型检查不充正式测试。',
    '- 合入：' + (merged if merged else '待完成/未验收') + ' — ' + merge_reason + '。纯工具无行为发布号；不登记shipped。',
    '- 需要 Roy 定的事（没有写「无」）：无',
    '',
    '证据与边界：冻结Git基线403原输入中400同前批，三处既有变化属于R375；83既有修复源核base/live祖先。4个真实数字UUID旧拒新接、8个旧experience批严格来源绑定通过，只读证据另存。只在固定临时仓库中执行回收/恢复测试，没有在生产回收任何材料或工作树。无对应本批工具项的bug-infra条目，未新建账本或登记shipped；原0332等游戏根因及磁盘压力等宽父保持。',
    '',
    '精确源码：source-all.patch；原基线/队列核验：baseline-source-audit.json、queue-audit.json；来源：uuid-original-name-probe.json、legacy-original-binding-probe-r2.json；原型/正式红绿/完整测试及gitleaks日志均在本目录。',
    '',
    '队列增量：初读1385行；再次只读核验1391行，新增三条原文及SHA保存在queue-latest-delta.json。04:52条目明确“原034302-fix仍running，下一普通槽接续”，按原槽保留，不将宿主时限补证认作游戏产品缺陷。',
    '', '```json', json.dumps(result, ensure_ascii=False), '```',
]
if pending:
    lines.insert(-3, '当前未提交源码：旧布局兼容修复及两个固定测试仍在原工作区；legacy-pending-all.patch含全部三文件并通过反向应用检查。三项已提交修复各自完整检查均0；JSON vitest1表示包含待提交修复的最后整套检查失败，不冒称本批全部完成。容量已恢复，完整检查仍在重跑；只有实际通过后才提交第四项并重写此报告。')
now = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
(scratch / 'validation.json').write_text(json.dumps({'at': now, 'head': head, 'changed': changed,
    'source_patch_sha256': hashlib.sha256(patch).hexdigest(), 'checks': validation, 'live_preflight': proof,
    'deployment': deployment}, ensure_ascii=False, indent=2) + '\n')
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(scratch / 'report.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'head': head, 'checks': validation, 'merged': merged, 'report': result['report']}, ensure_ascii=False))

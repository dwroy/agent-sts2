## 修 bug 回报（进行中）

- 合并基线：main → cb03ffed4d53f75c6d88be341fb8550933ad85de
- 队列逐项去重：83个既有提交重新核实为base/live祖先；403个文件399个与前批相同；42条未勾选原文保持。
- 新增纯运维缺口：合法数字UUID scratch误拒收；原启动器绑定的旧根目录经验产物布局误拒收。
- 固定证据：queue-audit.json、legacy-original-binding-probe.json；8个原批只读绑定通过。
- live只读merge-tree预检exit1：notes/fix-queue-v4.md、notes/for-roy.md、notes/ops-handoff.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl；未修改live。
- 第一次UUID撤码调用cwd错误保留uuid-without-fix-wrong-cwd.log，正确cwd撤源码1、恢复后定向0。
- 提交前沙箱套件仍在运行，global-build-health原execFileSync沙箱EPERM已单题重现：内部Python4过；未视为游戏或回收源码失败。
- 保存进度的首次shell尚未启动即bubblewrap/ripgrep因临时目录tmpyhqhmf64消失而退出1；本次原命令重试，未改启动器或权限。

- 2026-10-17T04:23:53+08:00：首轮完整沙箱tsc0/首次vitest1，456文件中454过2失败，4212项中4210过2失败，840.68秒；paths阶段因set -e尚未执行。旧XC4T F9T3原题原时限重跑1过13未选，7.74秒；global-health同步入口单题两次EPERM，异步入口定向0且撤补丁1/恢复0。
- 冻结Git基线校正：baseline-source-audit.json核403个原输入，400个与前批相同，3个差异为已上线R375的combat-plan、版本及通知。旧queue-audit的399相同是已含本任务UUID草稿的工作树快照，二者范围分开保留。
- 4个真实数字UUID旧拒/新接；8个原旧批在严格launcher/原生thread/footer/源report绑定下均通过只读核查；最终内存草稿五固定题通过。原型不充正式生产源回归；正式源须单独撤码红绿及完整检查。
- 当前原批20261017-034302-fix-batch/角色silent/原PID1997625仍running；未真实回收任何生产scratch/工作树，未合live。

- 单worker/dot完整检查：3039.66秒，455文件中452过3失败、4211项中4207过4失败，tsc0/vitest1；两个运维夹具遇实际容量reserve不足（约798MB空闲），EZ2L目标候选两题30s/20s超时。未视为新游戏模型回归。
- 原配置重跑三文件：26/26通过、140.27秒；磁盘已自然恢复4GiB以上，不归功于本补丁。保留原拒绝与超时，生产容量守卫、测试断言、预算/时限均不改。现恢复默认4worker/默认报告器依次做三项完整自测和单独提交。

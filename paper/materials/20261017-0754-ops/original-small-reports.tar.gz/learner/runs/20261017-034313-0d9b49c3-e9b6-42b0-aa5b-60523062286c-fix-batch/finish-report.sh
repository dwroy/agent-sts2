#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
date
while ! test -f "$TMPDIR/legacy.commit"; do
  for retention_check in uuid-sandbox-r4.exit legacy-capacity-wait.exit legacy-sandbox-r3.exit; do
    if test -f "$TMPDIR/$retention_check" && test "$(cat "$TMPDIR/$retention_check")" != 0; then
      printf 'UPSTREAM_CHECK_FAILED %s\n' "$retention_check"
      exit 2
    fi
  done
  sleep 10
done
date
if flock -w 50 -E 75 /home/dw/Projects/agent-sts2/ops/live-merge.lock sh -c '
  while pgrep -f "knowledge/builders/buil[d]-" >/dev/null; do sleep 10; done
  exec nice -n 19 python3 "$1"
' sh "$TMPDIR/live-preflight.py" > "$TMPDIR/live-lock-attempt.log" 2>&1; then
  retention_merge_code=0
else
  retention_merge_code=$?
fi
printf '%s\n' "$retention_merge_code" > "$TMPDIR/live-lock-attempt.exit"
if test "$retention_merge_code" != 1 && test "$retention_merge_code" != 75; then
  cat "$TMPDIR/live-lock-attempt.log"
  printf 'MERGE_REQUIRES_FOLLOWUP %s\n' "$retention_merge_code"
  exit 2
fi
date
nice -n 19 python3 "$TMPDIR/write-report.py"

#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
export SANDBOX_WORKERS=2
cd /home/dw/Projects/agent-sts2/.worktrees/live
date
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git diff --cached --quiet
git add -- notes/fight-value-backtest.md knowledge
if ! git diff --cached --quiet; then
  gitleaks git --staged --redact --no-banner > "$TMPDIR/live-refresh-gitleaks.log" 2>&1
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
git rev-parse HEAD > "$TMPDIR/live.before"
source_branch=codex-fix-silent-20261017-034302
git merge-tree --write-tree HEAD "$source_branch" > "$TMPDIR/live-immediate-preflight.log"
git merge --no-edit "$source_branch" > "$TMPDIR/live-merge.log" 2>&1
git rev-parse HEAD > "$TMPDIR/live.merged"
date
python3 -B - <<'PY'
from pathlib import Path
import json,subprocess
p=Path('/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch')
row={'state':'checking','source':(p/'legacy.commit').read_text().strip(),'before':(p/'live.before').read_text().strip(),'merge':(p/'live.merged').read_text().strip(),'at':subprocess.check_output(['date','--iso-8601=seconds'],text=True).strip(),'reason':'已实际合入live，正在持锁执行合后完整沙箱检查，未验收；失败回退本次合并并保留刷新数据'}
(p/'live-merge-result.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
PY
python3 -B "$TMPDIR/write-report.py"
cd agent
if bash tools/test-sandbox.sh --retry=1 > "$TMPDIR/live-sandbox.log" 2>&1; then
  printf '0\n' > "$TMPDIR/live-sandbox.exit"
else
  printf '%s\n' "$?" > "$TMPDIR/live-sandbox.exit"
fi
cd ..
exec nice -n 19 python3 -B "$TMPDIR/live-finish.py"

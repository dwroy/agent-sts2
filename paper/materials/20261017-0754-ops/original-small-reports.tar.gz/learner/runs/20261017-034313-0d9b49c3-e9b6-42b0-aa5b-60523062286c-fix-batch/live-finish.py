from pathlib import Path
import json, subprocess, sys
p=Path(__file__).parent
live=Path('/home/dw/Projects/agent-sts2/.worktrees/live')
def git(*args): return subprocess.check_output(['git','-C',str(live),*args],text=True).strip()
source=(p/'legacy.commit').read_text().strip()
before=(p/'live.before').read_text().strip()
merge=(p/'live.merged').read_text().strip()
rc=int((p/'live-sandbox.exit').read_text())
now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
if rc:
    assert git('rev-parse','HEAD') == merge, 'live HEAD changed; refuse rollback across another owner'
    subprocess.run(['git','-C',str(live),'reset','--merge',before],check=True)
    row={'state':'failed','source':source,'before':before,'merge':merge,'after':git('rev-parse','HEAD'),'rc':rc,'reason':'live完整沙箱检查失败，已回退本次合并到刷新后提交，保留其他脏记录；详见live-sandbox.log'}
else:
    assert git('rev-parse','HEAD') == merge
    assert not git('diff','--name-only','--','paper/materials/decision-log.md')
    commits=[(p/(name+'.commit')).read_text().strip() for name in ['wrapper','target-fixture','uuid','legacy']]
    subprocess.run(['git','-C',str(live),'merge-base','--is-ancestor',source,'HEAD'],check=True)
    line='\n- '+now+' Codex离线fix-batch / 20261017-034302：纯工具四项实际合入live '+merge+'；源'+','.join(commits)+'。来源fix-queue-v4：global-build-health异步Python入口、infra-target-options两处冻结传输预算、ops-worktree-history-disk-pressure-20261013之合法UUID与旧experience归属两个窄子项。证据EZ2LP1P5VRPT F48T2（仅测试传输），四个UUID及八个20261006—07旧experience原批绑定；运维项游戏层/回合不适用、无对应bug-infra账本id。每项撤码失败/恢复通过、各自完整沙箱0；合后完整沙箱0，原阈值/样本及重跑日志保留。无游戏行为/知识前缀变化，不增eval版本，不登记shipped，不关闭磁盘压力等宽父；完整宿主检查交原调度器。报告'+str(p/'report.md')+'。\n'
    with (live/'paper/materials/decision-log.md').open('a') as f:f.write(line)
    subprocess.run(['git','-C',str(live),'add','--','paper/materials/decision-log.md'],check=True)
    with (p/'live-record-gitleaks.log').open('w') as f:subprocess.run(['gitleaks','git','--staged','--redact','--no-banner'],cwd=live,stdout=f,stderr=subprocess.STDOUT,check=True)
    subprocess.check_call(['date'])
    subprocess.run(['git','-C',str(live),'commit','-m','Record deployment of four offline infrastructure fixes','-m','Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'],check=True)
    row={'state':'passed','source':source,'before':before,'merge':merge,'deployed':git('rev-parse','HEAD'),'rc':0,'reason':'实际合入live并通过合后完整沙箱检查；决策日志已追加，纯工具无行为版本；账本shipped由运维登记'}
row['at']=now
(p/'live-merge-result.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['python3','-B',str(p/'write-report.py')],check=True)
print(json.dumps(row,ensure_ascii=False))

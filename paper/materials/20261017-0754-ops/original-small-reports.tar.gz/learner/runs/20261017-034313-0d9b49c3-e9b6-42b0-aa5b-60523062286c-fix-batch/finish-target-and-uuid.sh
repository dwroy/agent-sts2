#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
unset SANDBOX_WORKERS
cd /home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261017-034302
date
while ! test -f "$TMPDIR/uuid-sandbox-r2.exit"; do sleep 10; done
test "$(cat "$TMPDIR/uuid-sandbox-r2.exit")" != 0
test ! -f "$TMPDIR/uuid.commit"
test "$(git rev-parse HEAD)" = "$(cat "$TMPDIR/wrapper.commit")"
git stash push --include-untracked -m 'Hold UUID retention patch while bounding remaining target transport fixtures' -- ops/learner_retention.py ops/tests/test_learner_retention.py agent/tests/learner-retention-uuid.test.ts
git rev-parse stash > "$TMPDIR/target-held-uuid.stash"
test -z "$(git status --porcelain --untracked-files=all)"
git apply "$TMPDIR/target-fixture.patch"
cp agent/tests/target-options.test.ts "$TMPDIR/target-options-fixed.txt"
cd agent
npx vitest run tests/target-options.test.ts -t "Jev's picking|gives Jev DeepSeek" --pool=threads --maxWorkers=1 > "$TMPDIR/target-fixture-fixed.log" 2>&1
cd ..
python3 -B - <<'PY'
from pathlib import Path
p=Path('agent/tests/target-options.test.ts');text=p.read_text()
start=text.index('  it("Jev\'s picking an Amalgam-focus line')
end=text.index('  it("rolls every shown line out',start)
part=text[start:end]
call='withTargetOptionFixture((budgetMs) => ez2l({ budgetMs }))'
assert part.count(call)==2
p.write_text(text[:start]+part.replace(call,'ez2l()')+text[end:])
PY
cd agent
if npx vitest run tests/target-options.test.ts -t "Jev's picking" --pool=threads --maxWorkers=1 > "$TMPDIR/target-fixture-without-fix.log" 2>&1; then
  target_red_code=0
else
  target_red_code=$?
fi
cd ..
cp "$TMPDIR/target-options-fixed.txt" agent/tests/target-options.test.ts
printf 'without_fix_exit=%s restore_exit=0\n' "$target_red_code" > "$TMPDIR/target-fixture-regression-summary.txt"
test "$target_red_code" != 0
cd agent
npx vitest run tests/target-options.test.ts -t "Jev's picking|gives Jev DeepSeek" --pool=threads --maxWorkers=1 > "$TMPDIR/target-fixture-restored.log" 2>&1
date
if bash tools/test-sandbox.sh > "$TMPDIR/target-fixture-sandbox.log" 2>&1; then
  printf '0\n' > "$TMPDIR/target-fixture-sandbox.exit"
else
  target_check_code=$?
  printf '%s\n' "$target_check_code" > "$TMPDIR/target-fixture-sandbox.exit"
  tail -n 60 "$TMPDIR/target-fixture-sandbox.log"
  exit "$target_check_code"
fi
cd ..
git add -- agent/tests/target-options.test.ts
gitleaks git --staged --redact --no-banner > "$TMPDIR/target-fixture-gitleaks.log" 2>&1
date
git commit -F "$TMPDIR/target-fixture-commit.txt"
git rev-parse HEAD > "$TMPDIR/target-fixture.commit"
printf 'TARGET_FIXTURE_COMMITTED\n'
tail -n 17 "$TMPDIR/target-fixture-sandbox.log"
git stash apply 948745195a4224b2a562826a3c72a07a81285c25
cd agent
npx vitest run tests/learner-retention-uuid.test.ts --pool=threads --maxWorkers=1 > "$TMPDIR/uuid-restored-r3.log" 2>&1
date
if bash tools/test-sandbox.sh > "$TMPDIR/uuid-sandbox-r3.log" 2>&1; then
  printf '0\n' > "$TMPDIR/uuid-sandbox-r3.exit"
else
  target_check_code=$?
  printf '%s\n' "$target_check_code" > "$TMPDIR/uuid-sandbox-r3.exit"
  tail -n 60 "$TMPDIR/uuid-sandbox-r3.log"
  exit "$target_check_code"
fi
cd ..
git add -- ops/learner_retention.py ops/tests/test_learner_retention.py agent/tests/learner-retention-uuid.test.ts
gitleaks git --staged --redact --no-banner > "$TMPDIR/uuid-gitleaks.log" 2>&1
date
git commit -F "$TMPDIR/uuid-commit.txt"
git rev-parse HEAD > "$TMPDIR/uuid.commit"
printf 'UUID_COMMITTED\n'
tail -n 17 "$TMPDIR/uuid-sandbox-r3.log"
git status --short

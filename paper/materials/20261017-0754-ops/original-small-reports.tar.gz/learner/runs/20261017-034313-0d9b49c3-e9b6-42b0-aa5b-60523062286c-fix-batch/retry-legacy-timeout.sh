#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
export SANDBOX_WORKERS=2
cd /home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261017-034302
date
while ! test -f "$TMPDIR/legacy-sandbox-r2.exit"; do sleep 10; done
test "$(cat "$TMPDIR/legacy-sandbox-r2.exit")" != 0
test ! -f "$TMPDIR/legacy.commit"
cd agent
if nice -n 19 npx vitest run tests/fix-queue-v4-shrink.test.ts -t 'XC4T F9 T3' --pool=threads --maxWorkers=2 > "$TMPDIR/legacy-shrink-rerun.log" 2>&1; then
  printf '0\n' > "$TMPDIR/legacy-shrink-rerun.exit"
else
  printf '%s\n' "$?" > "$TMPDIR/legacy-shrink-rerun.exit"
fi
date
if bash tools/test-sandbox.sh --retry=1 > "$TMPDIR/legacy-sandbox-r3.log" 2>&1; then
  printf '0\n' > "$TMPDIR/legacy-sandbox-r3.exit"
else
  retention_check_code=$?
  printf '%s\n' "$retention_check_code" > "$TMPDIR/legacy-sandbox-r3.exit"
  tail -n 65 "$TMPDIR/legacy-sandbox-r3.log"
  exit "$retention_check_code"
fi
cd ..
git add -- ops/learner_retention.py ops/tests/test_legacy_learner_retention.py agent/tests/learner-retention-legacy.test.ts
gitleaks git --staged --redact --no-banner > "$TMPDIR/legacy-gitleaks.log" 2>&1
date
git commit -F "$TMPDIR/legacy-commit.txt"
git rev-parse HEAD > "$TMPDIR/legacy.commit"
printf 'LEGACY_COMMITTED\n'
tail -n 20 "$TMPDIR/legacy-sandbox-r3.log"

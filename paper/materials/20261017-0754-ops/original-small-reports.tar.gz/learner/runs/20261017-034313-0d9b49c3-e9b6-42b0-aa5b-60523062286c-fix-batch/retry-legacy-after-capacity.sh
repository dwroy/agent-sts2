#!/bin/sh
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261017-034313-0d9b49c3-e9b6-42b0-aa5b-60523062286c-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
export SANDBOX_WORKERS=2
cd /home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261017-034302
date
retention_wait_count=0
while ! nice -n 19 python3 -B -c 'import shutil,sys; free=shutil.disk_usage(".").free; print("capacity_free_bytes="+str(free), flush=True); sys.exit(0 if free >= 2 * 1024**3 else 1)'; do
  retention_wait_count=$((retention_wait_count + 1))
  if test "$retention_wait_count" -ge 30; then
    printf 'CAPACITY_STILL_BLOCKED\n'
    printf '4\n' > "$TMPDIR/legacy-capacity-wait.exit"
    exit 4
  fi
  sleep 30
done
printf '0\n' > "$TMPDIR/legacy-capacity-wait.exit"
date
cd agent
if bash tools/test-sandbox.sh > "$TMPDIR/legacy-sandbox-r2.log" 2>&1; then
  printf '0\n' > "$TMPDIR/legacy-sandbox-r2.exit"
else
  retention_check_code=$?
  printf '%s\n' "$retention_check_code" > "$TMPDIR/legacy-sandbox-r2.exit"
  tail -n 55 "$TMPDIR/legacy-sandbox-r2.log"
  exit "$retention_check_code"
fi
cd ..
git add -- ops/learner_retention.py ops/tests/test_legacy_learner_retention.py agent/tests/learner-retention-legacy.test.ts
gitleaks git --staged --redact --no-banner > "$TMPDIR/legacy-gitleaks.log" 2>&1
date
git commit -F "$TMPDIR/legacy-commit.txt"
git rev-parse HEAD > "$TMPDIR/legacy.commit"
printf 'LEGACY_COMMITTED\n'
tail -n 20 "$TMPDIR/legacy-sandbox-r2.log"

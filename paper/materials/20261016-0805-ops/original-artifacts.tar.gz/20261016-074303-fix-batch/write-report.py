import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-074303'
OUT = ROOT / 'learner/runs/20261016-074307-e41865db-a16f-441f-955e-991b67dd9964-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-071305-e225ab76-3c86-43d0-b1ce-41f73a44fd6b-fix-batch'

audit = json.loads((OUT / 'audit.json').read_text())
old_result = json.loads((PRIOR / 'result.json').read_text())
base = audit['base']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TREE).decode().strip() == base
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=TREE).strip()
assert all(row['same_as_prior'] for row in audit['current_files'])
assert all(row['ancestor_in_base'] and row['ancestor_in_live'] for row in audit['existing_fixes'])
assert (OUT / 'tsc.exit').read_text().strip() == '0'
assert (OUT / 'targeted.exit').read_text().strip() == '0'
test_log = (OUT / 'targeted.log').read_text()
assert '10 passed (10)' in test_log and '38 passed (38)' in test_log

route_source = '7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a'
for ref in [base, audit['live_read_only_snapshot']]:
    subprocess.run(['git', 'merge-base', '--is-ancestor', route_source, ref], cwd=TREE, check=True)

queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
snapshot = (OUT / 'queue-snapshot.md').read_bytes()
(OUT / 'queue-final-readback.md').write_bytes(queue)
audit['final_queue_readback'] = {
    'lines': len(queue.splitlines()), 'sha256': hashlib.sha256(queue).hexdigest(),
    'unchanged_since_snapshot': queue == snapshot,
}
audit['tests'] = {
    'tsc': 0, 'vitest': 0, 'files': 10, 'cases': 38, 'scope': 'targeted',
    'full_sandbox_run': False, 'reruns': [],
    'logs': ['tsc.log', 'tsc.exit', 'targeted.log', 'targeted.exit'],
}
audit['no_new_commit'] = '本批未改源码、未新建修复或提交；不重复撤掉已上线修复，不空合live。'
audit['ledger_and_proposals'] = '无新修复或新游戏发现，不重复CLI、改shipped或登记已有提案；原策略提案沿既有调度链。'
audit['latest_route_source'] = {'source': route_source, 'ancestor_in_base': True,
    'ancestor_in_live': True, 'scope': '仅新增Silent A10 route projection诊断，不关闭真实路线资源接续宽父。'}
audit['final_status_clean'] = True
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')

result = {
    'task': 'fix-batch', 'base': base, 'fixes': [], 'skipped': old_result['skipped'],
    'merged': None, 'tests': {'tsc': 0, 'vitest': 0, 'cases': 38, 'files': 10, 'scope': 'targeted'},
    'code_proposals': [], 'implementation_domains': [], 'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
lines = [
    '## 修 bug 回报', '',
    f'- 合并基线：main → {base}（开工工作区干净；git merge --no-edit main 已是最新，无冲突）',
    '- 修复（每条一行）：无新增；队列纯bug均已有实现或当前缺乏安全修复所需证据，本批未重复修改。',
]
for row in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['source_commit']}（已修或已覆盖所列窄子项，实际main/live祖先）")
lines.append(f'- 已被别人修掉的：silent-route-projection-provenance 诊断子项 — {route_source}（已核实际main/live祖先；非本批上线）')
for row in result['skipped']:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines.extend([
    '- 测试：tsc 退出码0；定向vitest 10文件/38用例/退出码0，无重跑；无代码变更或提交，未运行完整沙箱，不宣称全套通过。无新增修复，撤修复红绿不适用。',
    f"- 合入：未合入（本批无新增提交；只读live快照 {audit['live_read_only_snapshot']}，已有来源均为其祖先，未操作live工作区、锁、知识刷新、发布号或上线记录）。",
    '- 需要 Roy 定的事（没有写「无」）：无。',
    '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
    '核查证据：audit.json保存42个未勾选原文及逐项处置、381个当前源码/固定测试SHA与前批对比、78个既有来源在base/live中的真实祖先；均重新核对，未以旧测试结果代替本轮测试。队列1354行，前批1350行前缀逐字保持，新增仅两条已有部署回执。最新route诊断三叶差异另存changes-since-prior.diff，不改变已审计381叶。',
    '',
    'silent-0332：当前boss-sim.ts continuationInput仍拒成功首战非正HP；只读核原DHYFWEN40SJ7/F48 seed3510836362证据，won=true/died=false/14turns，资源/steps尾部仍截断。build-sim-facts.ts仅保留错误前160字符，缺完整触发样本和机制根因；不填造HP、改正HP契约、降低300样本门槛或绕过C1保护。原silent-proposal-5aa2672bd7cd1bf4及其后继仍沿原策略链，不重复登记或派发。',
    '',
    '当前仍见0481措辞、0487 ViolenceHits漏读取、0311 stock按旧maxHp预算等原策略范围；原独立提案保持，不将窄子项或诊断上线当宽父完成。无新游戏事实/新提案/学习账本修改，不改队列；未调用真实模型或网络、未运行play、推送或清理工作树。',
    '',
])
(OUT / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'report': result['report'], 'fixes': 0, 'existing_sources': 79,
                  'skipped': len(result['skipped']), 'tests': result['tests'],
                  'queue_unchanged': queue == snapshot, 'status_clean': True}, ensure_ascii=False, indent=2))

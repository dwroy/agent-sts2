import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-074303'
OUT = ROOT / 'learner/runs/20261016-074307-e41865db-a16f-441f-955e-991b67dd9964-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-071305-e225ab76-3c86-43d0-b1ce-41f73a44fd6b-fix-batch'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=TREE).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


prior = json.loads((PRIOR / 'audit.json').read_text())
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
previous_queue = (PRIOR / 'queue-final-readback.md').read_bytes()
(OUT / 'queue-snapshot.md').write_bytes(queue)
base = git('rev-parse', 'HEAD')
live = git('rev-parse', 'refs/heads/live')
files = []
for entry in prior['current_files']:
    path = TREE / entry['path']
    actual = sha(path.read_bytes()) if path.is_file() else None
    files.append({'path': entry['path'], 'sha256': actual,
                  'prior_sha256': entry['sha256'], 'same_as_prior': actual == entry['sha256']})
fixes = []
for entry in prior['existing_fixes']:
    source = entry['source_commit']
    row = {'item': entry['item'], 'source_commit': source}
    for label, ref in [('base', base), ('live', live)]:
        row['ancestor_in_' + label] = subprocess.run(
            ['git', 'merge-base', '--is-ancestor', source, ref], cwd=TREE).returncode == 0
    fixes.append(row)
dispositions = []
lines = queue.decode().splitlines()
for old in prior['queue_dispositions']:
    row = dict(old)
    assert lines[row['line'] - 1] == row['item'], row['line']
    row['verification'] = '本批重新核当前源码SHA、原实现提交的base/live祖先；原窄范围不扩为宽父完成。'
    dispositions.append(row)
changes = git('diff', '--name-only', prior['base'], base).splitlines()
binary = subprocess.check_output(['git', 'diff', '--binary', prior['base'], base, '--',
    'agent/src/hand/screens/route-plan.ts', 'agent/tests/silent-route-projection.test.ts',
    'agent/tests/silent-route-projection-evidence.json', 'ops/learning_requests.py'], cwd=TREE)
(OUT / 'changes-since-prior.diff').write_bytes(binary)
result = {
    'base': base, 'live_read_only_snapshot': live,
    'prior_audit': str(PRIOR / 'audit.json'), 'queue_sha256': sha(queue),
    'queue_lines': len(lines), 'unchecked_entries': sum(s.startswith('- [ ]') for s in lines),
    'prior_queue_unchanged_prefix': queue.startswith(previous_queue),
    'queue_addition': queue[len(previous_queue):].decode() if queue.startswith(previous_queue) else None,
    'current_files': files, 'existing_fixes': fixes, 'queue_dispositions': dispositions,
    'changed_paths_since_prior_base': changes,
    'new_source_commits': [], 'actual_merge_performed_by_this_task': False,
}
(OUT / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({
    'base': base, 'live': live, 'queue_lines': len(lines),
    'unchecked_entries': result['unchecked_entries'],
    'queue_prefix_unchanged': result['prior_queue_unchanged_prefix'],
    'checked_paths': len(files), 'changed_paths': [r['path'] for r in files if not r['same_as_prior']],
    'source_commits': len(fixes), 'missing_ancestors': [r for r in fixes if not r['ancestor_in_base'] or not r['ancestor_in_live']],
}, ensure_ascii=False, indent=2))

#!/usr/bin/env bash
set -eu
task_scratch="/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-071301/learner/runs/20261016-071305-63db5e45-b531-4c32-a443-7e893e9961bd-strategy-proposal"
export TMPDIR="$task_scratch"
export PATH="$HOME/.local/node/bin:$PATH"
export SANDBOX_WORKERS=1
exec 9>/home/dw/Projects/agent-sts2/ops/live-merge.lock
if ! flock -w 45 9; then
  printf '%s\n' 'live lock unavailable after 45 seconds' >&2
  exit 75
fi
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
nice -n 19 python3 "$task_scratch/merge_live.py"

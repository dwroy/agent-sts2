"""在宿主共用live锁内运行；仅发布本批已测试审计补丁。"""
import hashlib
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
SOURCE = (S / 'source-commit.txt').read_text().strip()
receipt = {'source': SOURCE, 'merged': None, 'version': None, 'behavior_change': False}


def save():
    (S / 'live-merge-result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')


def git(*args, check=True):
    r = subprocess.run(['git', '-C', str(LIVE), *args], capture_output=True, text=True)
    if check and r.returncode:
        raise RuntimeError('git ' + ' '.join(args) + ': ' + r.stderr.strip())
    return r


def scan(label):
    with (S / (label + '.gitleaks.log')).open('w') as handle:
        r = subprocess.run(['gitleaks', 'git', '--staged', '--redact', '--no-banner', '--report-format', 'json',
                            '--report-path', str(S / (label + '.gitleaks.json')), str(LIVE)], stdout=handle, stderr=subprocess.STDOUT)
    receipt[label + '_gitleaks'] = r.returncode
    if r.returncode:
        raise RuntimeError(label + ' gitleaks did not pass')


try:
    assert len(SOURCE) == 40 and all(c in '0123456789abcdef' for c in SOURCE)
    assert (S / 'sandbox-tests.exit').read_text().strip() == '0'
    receipt['live_before_refresh'] = git('rev-parse', 'HEAD').stdout.strip()
    receipt['status_before'] = git('status', '--short').stdout
    if git('rev-parse', '--verify', '--quiet', 'MERGE_HEAD', check=False).returncode == 0:
        raise RuntimeError('live already has an unrelated merge in progress')
    staged = git('diff', '--cached', '--name-only').stdout.splitlines()
    if any(not (p.startswith('knowledge/') or p == 'notes/fight-value-backtest.md') for p in staged):
        raise RuntimeError('live has unrelated staged paths; preserving their owner')
    own = subprocess.check_output(['git', '-C', str(S.parents[2]), 'diff-tree', '--no-commit-id', '--name-only', '-r', SOURCE], text=True).splitlines()
    fresh = git('diff', 'HEAD', '--name-only', '--', 'knowledge', 'notes/fight-value-backtest.md').stdout.splitlines()
    receipt['source_paths'] = own
    receipt['refreshed_paths'] = fresh
    if set(own) & set(fresh):
        raise RuntimeError('source patch overlaps refreshed knowledge; preserving both')
    git('add', 'notes/fight-value-backtest.md', 'knowledge')
    if git('diff', '--cached', '--quiet', check=False).returncode != 0:
        scan('knowledge-refresh')
        r = git('commit', '-m', 'Refresh knowledge data', '-m', 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
        (S / 'knowledge-refresh.commit.log').write_text(r.stdout + r.stderr)
    receipt['pre_merge'] = git('rev-parse', 'HEAD').stdout.strip()
    save()
    result = git('merge', '--no-edit', SOURCE, check=False)
    (S / 'live-merge.log').write_text(result.stdout + result.stderr)
    receipt['merge_exit'] = result.returncode
    if result.returncode:
        receipt['conflicts'] = git('diff', '--name-only', '--diff-filter=U').stdout.splitlines()
        if git('rev-parse', '--verify', '--quiet', 'MERGE_HEAD', check=False).returncode == 0:
            abort = git('merge', '--abort', check=False)
            receipt['abort_exit'] = abort.returncode
        receipt['live_after_failed_merge'] = git('rev-parse', 'HEAD').stdout.strip()
        save()
        raise RuntimeError('live merge failed; original conflict/refusal kept in live-merge.log')
    receipt['merged'] = git('rev-parse', 'HEAD').stdout.strip()
    save()
    with (S / 'live-sandbox-tests.log').open('w') as handle:
        result = subprocess.run(['nice', '-n', '19', 'bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', stdout=handle, stderr=subprocess.STDOUT)
    receipt['live_test_exit'] = result.returncode
    if result.returncode:
        # Preserve unrelated working changes and the committed knowledge refresh during the authorized rollback.
        rollback = git('reset', '--merge', receipt['pre_merge'], check=False)
        receipt['rollback_exit'] = rollback.returncode
        receipt['merged'] = None if rollback.returncode == 0 else receipt['merged']
        save()
        raise RuntimeError('live sandbox checks failed; see rollback receipt')
    date = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    record = LIVE / 'paper/materials/decision-log.md'
    clean_record = git('diff', '--quiet', '--', 'paper/materials/decision-log.md', check=False).returncode == 0
    line = ('\n- ' + date + ' 策略学习codex：原silent-proposal-aff5ac3bb7cdb81b的Silent A10 SL资源审计补齐，'
            '证据NEWRFAYKTQHR F31T2/账本silent-0079、0135、0167、0168、0010；源码' + SOURCE +
            '、实际live合入' + receipt['merged'] + '。同盘3/8损血、30/23伤、11/4挡、6/3污染及10/3结算后毒差额入结构日志；'
            '原答/SL替线/预测/实际分列，随机中位线及缺值保持未知；只加审计注记，不改排名、出牌、用药、SL或终局权重，'
            '既有药水等价比较排除注记。源撤码3败恢复9过、148定向通过、源与合后沙箱入口均0；'
            '无新行为版本，不标shipped；自然消费者/整战收益及其余九宽项保持待证。报告' + str(S / 'report.md') + '。\n')
    with record.open('a') as handle:
        handle.write(line)
    (S / 'live-decision-log-addition.txt').write_text(line)
    if clean_record:
        git('add', 'paper/materials/decision-log.md')
        scan('publication-record')
        git('commit', '-m', 'Record Silent SL resource audit deployment', '-m', 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    else:
        receipt['parallel_decision_log_preserved'] = True
    receipt['publication'] = git('rev-parse', 'HEAD').stdout.strip()
    receipt['source_is_live_ancestor'] = git('merge-base', '--is-ancestor', SOURCE, 'HEAD', check=False).returncode == 0
    assert receipt['source_is_live_ancestor']
    receipt['state'] = 'merged'
    save()
except Exception as error:
    receipt['error'] = str(error)
    receipt['state'] = 'blocked'
    save()
    print(json.dumps(receipt, ensure_ascii=False))
    raise SystemExit(1)
print(json.dumps(receipt, ensure_ascii=False))

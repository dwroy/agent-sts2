"""核验本批原字节，输出有界观察；不校准游戏参数或认证完整候选执行。"""
import bisect
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location("extractor", ROOT / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(entity):
    return {p.get("power_id"): p.get("amount") for p in (entity or {}).get("powers", [])}


def compact(item):
    row = item["row"]
    state = row["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": item["line"], "run": item["run_id"], "ts": row.get("observed_ts", row.get("ts")),
        "fingerprint": row.get("fingerprint"), "floor": run.get("floor"), "turn": state.get("turn"),
        "screen": state.get("screen"), "selection": state.get("selection"),
        "hp": player.get("current_hp", run.get("current_hp")), "max_hp": run.get("max_hp"),
        "energy": player.get("energy"), "block": player.get("block"), "powers": powers(player),
        "hand": [{k: c.get(k) for k in ("index", "card_id", "upgraded", "energy_cost", "name")} for c in combat.get("hand", [])],
        "potions": run.get("potions"),
        "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"), "hp": e.get("current_hp"),
                     "max_hp": e.get("max_hp"), "block": e.get("block"), "powers": powers(e),
                     "intents": e.get("intents")} for e in combat.get("enemies", [])],
    }


manifest = json.loads((SCRATCH / "evidence/evidence-manifest.json").read_text())
verified_runs = set(json.loads((SCRATCH / "run-identities.json").read_text()))
receipts = []
frames = collections.defaultdict(list)
frame_keys = {}
decisions = []
configs = []
brain_counts = collections.Counter()
brain_engines = collections.defaultdict(collections.Counter)
attempts = []
run_plans = collections.Counter()
for entry in manifest:
    name = entry["stream"]
    path = SCRATCH / "evidence" / (name + ".evidence.jsonl")
    digest = hashlib.sha256()
    counts = collections.Counter()
    with path.open("rb") as handle, (Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")).open("rb") as source:
        for raw in handle:
            digest.update(raw)
            item = json.loads(raw)
            assert item["run_id"] in verified_runs
            assert extractor.run_identity(item["row"]) == item["run_id"]
            assert item["offset"] + item["bytes"] <= entry["source_size"]
            source.seek(item["offset"])
            original = source.read(item["bytes"])
            assert hashlib.sha256(original).hexdigest() == item["sha256"]
            assert json.loads(original) == item["row"]
            counts[item["run_id"]] += 1
            row = item["row"]
            if name == "states":
                state = row["state"]
                character = (state.get("run") or {}).get("character_id")
                assert character is None or character.lower() == "silent"
                frame = compact(item)
                frames[item["run_id"]].append(frame)
                frame_keys[(frame["run"], frame["fingerprint"], frame["ts"])] = frame
            elif name == "decisions":
                decisions.append(item)
            elif name == "run-config":
                configs.append({"run": item["run_id"], "line": item["line"], "code": row.get("code"),
                                "knowledge": row.get("knowledge"), "brain": row.get("brain")})
            elif name == "brain":
                brain_counts[item["run_id"]] += 1
                brain_engines[item["run_id"]][str(row.get("engine"))] += 1
            elif name == "run-plans":
                run_plans[item["run_id"]] += 1
            elif name == "sl-attempts":
                attempts.append({"line": item["line"], **{k: row.get(k) for k in (
                    "run_id", "floor", "encounter", "attempt", "result", "turns", "end_hp", "give_up_reason")}})
    assert digest.hexdigest() == entry["output_sha256"]
    assert all(counts[r] == entry["counts"][r] for r in verified_runs)
    receipts.append({"stream": name, "verified_lines": sum(counts.values()), "output_sha256": digest.hexdigest(),
                     "source_size": entry["source_size"], "counts": dict(counts)})

for group in frames.values():
    group.sort(key=lambda f: f["ts"])
times = {r: [f["ts"] for f in group] for r, group in frames.items()}
actions = []
codex_decisions = collections.Counter()
labels = collections.defaultdict(collections.Counter)
for item in decisions:
    row = item["row"]
    run = item["run_id"]
    label = row.get("label")
    labels[run][str(label)] += 1
    if str(row.get("decider", "")).lower() == "codex":
        codex_decisions[run] += 1
    timestamp = row.get("observed_ts", row.get("ts"))
    before = frame_keys.get((run, row.get("fingerprint"), timestamp))
    if before is None:
        continue
    chosen = row.get("chosen") or {}
    if not chosen:
        continue
    group = frames[run]
    index = bisect.bisect_right(times[run], timestamp)
    after = next((f for f in group[index:] if f["fingerprint"] != before["fingerprint"]), None)
    card = next((c for c in before["hand"] if c["index"] == chosen.get("card_index")), None)
    actions.append({"decision_line": item["line"], "id": row.get("decision_id"), "run": run,
                    "floor": before["floor"], "turn": before["turn"], "sl_attempt": row.get("sl_attempt"),
                    "label": label, "result": row.get("result"), "chosen": chosen, "card": card,
                    "before": before, "after_first_changed": after})

targets = {"K2JAGKVJAWZJ": {27, 33, 46}, "NEWRFAYKTQHR": {17, 23, 28, 31},
           "79UCJ0K6R9C1": {8, 14}, "9R916WW0V65N": set(range(42, 50)),
           "ZVYUL2YP3518": {33}, "9YBKCNBFP0X5": {48}}
target_actions = [a for a in actions if a["floor"] in targets.get(a["run"], set())]
with (SCRATCH / "target-actions.jsonl").open("w") as handle:
    for action in target_actions:
        handle.write(json.dumps(action, ensure_ascii=False) + "\n")
ring = [a for a in actions if a["card"] and a["card"]["card_id"] == "TORIC_TOUGHNESS"]
save("toric-casts.json", ring)
save("configs-summary.json", configs)
save("attempts-summary.json", attempts)
save("provenance-verification.json", {"streams": receipts, "all_raw_bytes_verified": True,
    "counts": {r: {"brain": brain_counts[r], "brain_engines": dict(brain_engines[r]),
                   "codex_decider_decisions": codex_decisions[r], "run_plans": run_plans[r], "labels": dict(labels[r])}
               for r in sorted(verified_runs)},
    "limits": "动作后首个变化帧仅为观察端点，尚未核下一动作边界/选择完成/同试执行，不自动认证完整候选或生产校准。"})
print(json.dumps({"verified_lines": sum(r["verified_lines"] for r in receipts),
    "runs": len(verified_runs), "target_actions": len(target_actions), "toric_casts": len(ring),
    "counts": [{"stream": r["stream"], "lines": r["verified_lines"]} for r in receipts]}, ensure_ascii=False))

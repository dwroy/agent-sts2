# 静默猎手策略提案逐项处置

本批：20261016-071301-strategy-proposal；基线7da6f7693325878a4b59113d630d219316a7f64a。普通消费批次，仅处理绑定的十个id，无research_request/implementation_request；不是专题纯报告。原Markdown逐项原字节与登记SHA相符，已保存 *.original.md；不改原提案或领取其他id。

## 可实现项：SL换线即时资源审计

原id silent-proposal-aff5ac3bb7cdb81b，来源postmortem/20261008-104302，目标本策略批次。账本silent-0079、0135、0167、0168、0010；角色静默猎手，策略/日志投影限A10。授权Roy-2026-10-07-learning；本改动不改出牌、用药、SL准入/排序或权重。

NEWRFAYKTQHR F31T2，第1/3/4试原帧s294063—68、294106—111、294131—135及d287298/287341/287366：同28血、151敌血/4毒、2力和同手。原线切割→打击→致命毒药+→蜃景，实损3、净伤30、11挡、6污染；替线蜃景→切割→打击，实损8、净伤23、4挡、3污染。原/替线结算后毒10/3；差额为替减原：+5损血、−7伤、−7挡、−3污染、−7毒。d287366原Jev答plan1/置信0.76，实际首牌蜃景来自SL替换；两线均五轮24/24死，rollout.saturated=true。

旧行为：决策顶层已有饱和标志、SL原/替线文字与血伤数字，后来的resource_comparison已有血伤挡比较；没有在该结构内同时记录饱和、污染增量和结算后毒差额。新行为：仅将既有求解器累计污染作为可选审计字段，连同观测入口污染、毒快照/差额及饱和标志写入Silent A10的SL重放/换线/避重日志。既有原答、guard后原线、替线与实际动作继续分列；预测标execution=unverified。未知量与随机药中位线差额保留null，不把入口污染当新获得污染。

反例：第2试有29血、涂毒且敌165血，不能和上述三试直接配对。T3更多污染会放大多段来袭，不能推出技能或施毒固定优先；两条原线完整尝试均失败，后轮抽弃/出牌不同，没有固定整战胜利反事实。代码只改善审计，不声称胜率、保血或用时收益。

实现文件：turn-solver.ts只增加已累计污染的Outcome审计注记；silent-sl-resource-comparison.ts投影新增字段；combat-plan.ts传递已有饱和标志；rollout-live.ts在既有无效药等价比较中排除该注记。未改伤害/血量/权重/样本门槛/候选/选择函数。其他角色没有新增日志，原等价比较不受注记影响。

拟合与切分：独立局n=1，同局SL归一组，不拟任何参数。固定s294131原盘复算原/替线，与实盘端点核对；下一自然匹配消费者和整局收益另验，不用本次离线测试代替。验证要求：新源码撤回时三个新增回归失败，恢复后通过；原沙箱入口、gitleaks与live流程按实际结果登记。回退只逆向本项净源码补丁，保留刷新知识、日志、原提案及其他并行改动。

## 全部十项

### silent-proposal-650ea306e8627f9e

更正第94批脑来源口径：48调用/71含计划复用的脑决策，旧机制边界保持

证据局：K2JAGKVJAWZJ,10GPK5XGHCK3,UJ0K3G10609Y。账本：silent-0010,silent-0012,silent-0013,silent-0019,silent-0020,silent-0021,silent-0046,silent-0065,silent-0077,silent-0106,silent-0115,silent-0178,silent-0243,silent-0276,silent-0277,silent-0278。

本批处置：已复核K2的48次Codex脑调用、71次含复用决策；本项是四条原宽提案的来源勘误。关联机制/资源组合及当时dirty知识输入未完整还原，来源更正不能冒称四项源码全部实现。

### silent-proposal-aff5ac3bb7cdb81b

记录静默A10饱和死亡率SL换线的原答/实线与即时资源差额，不凭单局改变探索准入

证据局：NEWRFAYKTQHR。账本：silent-0079,silent-0135,silent-0167,silent-0168,silent-0010。

本批处置：已完成窄审计源码与固定证据测试；等待沙箱检查及实际live合入，尚不登记implemented。

### silent-proposal-60e68d681e861d1c

核感染持牌伤先于毒结算和毒药非即时伤覆盖

证据局：79UCJ0K6R9C1,9YBKCNBFP0X5,UACFSW4VDDLD,4Y94N8RDPGPM,TCFAHJ9K19VY,UMVLWER4CD98,TXZ6RVMQA09D,1913SE84AXQF,BTSRF7JL1W1Y,9Z9H2EXKLF3T,NEWRFAYKTQHR。账本：silent-0286,silent-0278。

本批处置：感染先付持牌伤再结毒已有窄源码及固定原帧覆盖；毒药水的不同入口、头骨/制品组合和后继消费尚缺同条件验证，不能整项标duplicate。实际领域沿e6f9勘误为combat/potion。

### silent-proposal-9aa48a84227bcdb5

核静默实际资源与预测分账，未执行路线/药水反事实保持未知

证据局：79UCJ0K6R9C1,NEWRFAYKTQHR。账本：silent-0019,silent-0020,silent-0243,silent-0021,silent-0276,silent-0277,silent-0259。

本批处置：已核实际血药、再生及SL恢复分账；未取得固定同资源/种子的替代路线、饮药时点整战配对和独立留出，不能拟留药/路线/终局权重。

### silent-proposal-7cfd0f9b6b0fbbda

核蜃景/污染即时血价与坚韧之环施放快照及增益分源

证据局：79UCJ0K6R9C1,NEWRFAYKTQHR,LLYSRQQ35AVW,ZVYUL2YP3518,HSX4HYATB4E2,TDLBRNA0R05B,1913SE84AXQF。账本：silent-0012,silent-0005,silent-0016,silent-0080,silent-0046,silent-0084,silent-0011,silent-0023,silent-0010,silent-0123,silent-0168,silent-0079,silent-0135,silent-0133,silent-0289。

本批处置：六局24次均为普通坚韧之环，已见施放额度快照及后续11挡；入口只显剩余次数，缺恢复/跨SL的施放额度状态与升级/重放/叠层组合证据，不能以当前敏捷重建旧额度或把所有机制整体标duplicate。

### silent-proposal-e6f9cb57c1204036

更正60e68d681e861d1c领域为combat/potion：核感染持牌伤与毒药结算，不涉及终局价值

证据局：79UCJ0K6R9C1,9YBKCNBFP0X5,UACFSW4VDDLD,4Y94N8RDPGPM,TCFAHJ9K19VY,UMVLWER4CD98,TXZ6RVMQA09D,1913SE84AXQF,BTSRF7JL1W1Y,9Z9H2EXKLF3T,NEWRFAYKTQHR。账本：silent-0286,silent-0278。

本批处置：本项保留对60e68的combat/potion领域更正，不重复登记或实现；关联毒水入口及头骨/制品组合仍未完成同条件消费者验证。

### silent-proposal-6353ffbadaaac619

补F42至F49实盘HP/逐槽药水/SL来源审计；先校正缺机制，未有受控胜线前不改留药和终局权重。

证据局：9R916WW0V65N。账本：silent-0228,silent-0290,silent-0291。

本批处置：9R的F48出口12/74空药到F49已核；F42可能复活的独立充能未可观测，缺固定资源/种子的两战配对及按局留出校准，现有联合模型不能当该宽项全部验收。

### silent-proposal-9e5d50fdd7bf1fbd

旧/新行为：保留已有连续Boss联合模型，核实际HP/药水/复活可观测状态与战斗增益清空。缺复活充能明确未知。当前留药/终局权重/路线评分保持；只先完善审计及固定两战配对验证，证据足够时独立提出参数候选，否则waiting，不因8局全败拟合阈值。

证据局：9R916WW0V65N,JMH5C51RLN4E,9TG1RP5LFAAK,ZVYUL2YP3518,TDLBRNA0R05B,TXZ6RVMQA09D,XTSV1U9JD34T,PD9AYQVMLQW6。账本：silent-0228,silent-0020,silent-0019,silent-0021,silent-0243,silent-0259,silent-0276。

本批处置：现有连续Boss同样本资源传递保留；缺原八局完整复活状态、固定两战血药配对和独立留出，首战胜后后场败的观察不能拟合留药/终局参数。

### silent-proposal-20b9df170d51b280

旧/新行为：独立核余像逐牌、滚石轮初、精准小刀、冰晶一次收益、实验体技能激怒/换阶段和女王减益/魂缚。只补当前源码缺少的已观察传播，不固定杀序。实验体首两试截断、末试胜且后续手牌/出牌同变，不能声称哪项单因转胜；女王没有赢次，不归失败于运气或尚未做过的替代线。

证据局：9R916WW0V65N。账本：silent-0023,silent-0094,silent-0054,silent-0173,silent-0028,silent-0069,silent-0079。

本批处置：余像/滚石/精准/冰晶/阶段等已有窄模型，苦无与专注另有实际live祖先；缺原六类范围的联合同盘消费者核验。实验体首两试出口截断、末试后续牌序同变，女王无替线整战胜局，不能整体标duplicate或拟新杀序。

### silent-proposal-91cc7fd647077569

更正实验体尝试数字的证据范围：13支持局55试5赢，真正重打12场54试4赢；不混用全角色该Boss其他局数字。

证据局：9R916WW0V65N。账本：silent-0023,silent-0094,silent-0054,silent-0173,silent-0028,silent-0069,silent-0079。

本批处置：原冻结13支持局55试5赢、真正重打12场54试4赢已逐原件复算；缺消耗旧错误分母的具体生产源码位置。本项历史勘误不能拿当前27支持局经验数据提交冒称源码duplicate。

## 证据及未知边界

primary evidence为23个已核Silent局的八流40855行，逐条源截点、offset/bytes/SHA、JSON和显式身份核验；fight-plans在本冻结截点选中0行，只说明本次未选到。另从原changes.json读取冻结13局清单，通过同一入口补提runs/sl-attempts并核原字节；13局55试5赢、真正重打12场54试4赢，不迁移当前扩大的经验分母。

79UCJ0K6R9C1 F14T10/T11：13挡先付两感染6，再付敌攻18，13血到2；下轮7挡/2血面对三感染9，先死而8血/10毒目标不结算。现有turn-solver已有窄覆盖，不另造全面漏算。六局24次普通坚韧之环均观测建立2次；ZVY F33T6以6敏捷建11挡，T7/8敏捷回2仍11挡。未知升级/重放/叠层不外推。

9R916WW0V65N F48T15→F49T1的s295422—424直接12/74空药接续，前场能力不继承；F49末T1冰晶7+后空翻8+生存者11=26，末T2十二血零挡对16死，敌余568。苦无/专注已由实际live祖先92db362a8141478ffa72ceb9b08cd6f90784c786 / 6db27908cc3d39e4567eeb589f5541adfd9eb0ea窄实现；不能据此关闭整个资源/六机制提案。

原始运行dirty知识和所有历史消费者输入未重建；源码祖先、当前窄实现、固定测试、自然采用及整战效果分开。详细回执见provenance-verification.json、material-checks.json、denominator-verification.json、source-coverage.json和report.md。

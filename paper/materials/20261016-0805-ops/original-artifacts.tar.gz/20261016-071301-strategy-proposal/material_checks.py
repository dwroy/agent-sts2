"""固定原件的材料断言；不是生产 tsc/vitest 或策略收益测试。"""
import collections
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
checks = []


def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})


proposals = json.loads((S / "assigned-proposals.json").read_text())
dispatch = json.loads((S / "dispatch.json").read_text())
check("派发十项精确覆盖", [p["id"] for p in proposals] == dispatch["proposal_ids"] and len(proposals) == 10)
for p in proposals:
    check(p["id"] + " 原Markdown SHA", hashlib.sha256((S / (p["id"] + ".original.md")).read_bytes()).hexdigest() == p["proposal_sha256"])
v = json.loads((S / "provenance-verification.json").read_text())
check("八流40855原字节逐行核验", v["all_raw_bytes_verified"] and sum(x["verified_lines"] for x in v["streams"]) == 40855)
check("K2脑48调用与71决策分账", v["counts"]["K2JAGKVJAWZJ"]["brain"] == 48 and
      v["counts"]["K2JAGKVJAWZJ"]["codex_decider_decisions"] == 71 and v["counts"]["K2JAGKVJAWZJ"]["run_plans"] == 7)
check("23局均Silent", all(x["character"].lower() == "silent" for x in json.loads((S / "run-identities.json").read_text()).values()))
actions = [json.loads(line) for line in (S / "target-actions.jsonl").open()]
frames = {}
for a in actions:
    for f in (a["before"], a["after_first_changed"]):
        if f:
            frames[f["line"]] = f
groups = {}
for attempt, hp_loss, damage, block, tainted in [(1, 3, 30, 11, 6), (3, 3, 30, 11, 6), (4, 8, 23, 4, 3)]:
    group = sorted([a for a in actions if a["run"] == "NEWRFAYKTQHR" and a["floor"] == 31 and a["turn"] == 2 and a["sl_attempt"] == attempt], key=lambda a: a["before"]["ts"])
    groups[attempt] = group
    first, last = group[0]["before"], group[-1]["after_first_changed"]
    end = group[-1]["before"]
    check(f"棱柱第{attempt}试T2实际损血/净伤/挡/污染", first["hp"] - last["hp"] == hp_loss and
          first["enemies"][0]["hp"] - last["enemies"][0]["hp"] == damage and end["block"] == block and end["powers"]["TAINTED_POWER"] == tainted)
    check(f"棱柱第{attempt}试T2所有动作完成且端点不越下一动作", all(a["result"].startswith("completed:") for a in group) and
          all(a["after_first_changed"]["ts"] <= b["before"]["ts"] for a, b in zip(group, group[1:])) and last["turn"] == 3)
    check(f"棱柱第{attempt}试T2同盘底板", first["hp"] == 28 and first["enemies"][0]["hp"] == 151 and
          first["enemies"][0]["powers"]["POISON_POWER"] == 4 and first["powers"] == {"STRENGTH_POWER": 2})
check("三次T2同手", all(groups[a][0]["before"]["hand"] == groups[1][0]["before"]["hand"] for a in (3, 4)))
d = next(x["row"] for x in json.loads((S / "selected-decisions.json").read_text()) if x["line"] == 287366)
check("d287366原答与实际首牌分开", d["answers"]["plan"]["choice"] == "plan1" and d["answers"]["plan"]["confidence"] == .76 and
      next(c for c in groups[4][0]["before"]["hand"] if c["index"] == d["chosen"]["card_index"])["card_id"] == "MIRAGE")
check("d287366饱和且两案均24/24死亡", d["rollout"]["saturated"] is True and all("24/24" in x for x in d["sl_explore"]["numbers"].values()))
check("T10感染先耗挡后敌攻", frames[293460]["hp"] == 13 and frames[293460]["block"] == 13 and
      frames[293461]["hp"] == 2 and frames[293461]["block"] == 7 and len(frames[293460]["hand"]) == 2)
check("T11感染致死不结毒", frames[293464]["hp"] == 2 and frames[293464]["block"] == 7 and
      frames[293465]["hp"] == 0 and frames[293465]["enemies"][0]["hp"] == 8 and frames[293465]["enemies"][0]["powers"]["POISON_POWER"] == 10)
check("铁心0即时挡/覆甲7", frames[292788]["block"] == frames[292789]["block"] == 0 and frames[292789]["powers"]["PLATING_POWER"] == 7)
ring = json.loads((S / "toric-casts.json").read_text())
check("坚韧普通牌六局24施放", len(ring) == 24 and len({a["run"] for a in ring}) == 6 and all(a["card"]["upgraded"] is False for a in ring))
check("普通坚韧施放后剩两次", all(a["after_first_changed"]["powers"].get("TORIC_TOUGHNESS_POWER") == 2 for a in ring))
for turn in (7, 8):
    f = min((f for f in frames.values() if f["run"] == "ZVYUL2YP3518" and f["floor"] == 33 and f["turn"] == turn), key=lambda f: f["ts"])
    check(f"ZVY F33T{turn}敏捷回2仍11轮初挡", f["powers"]["DEXTERITY_POWER"] == 2 and f["block"] == 11)
check("连续Boss实盘12血空药接续", all(frames[n]["hp"] == 12 and frames[n]["max_hp"] == 74 and not any(p["occupied"] for p in frames[n]["potions"]) for n in (295422, 295423, 295424)))
check("第二Boss无前场余像/滚石", not frames[295424]["powers"])
check("末试苦无先增敏不倒补挡", frames[295535]["powers"]["DEXTERITY_POWER"] == 1 and frames[295535]["block"] == 0)
check("末试冰晶/后空翻/生存者分源", [frames[n]["block"] for n in (295536, 295537, 295538)] == [7, 15, 26])
check("女王末12血0挡死亡且敌余568", frames[295550]["hp"] == 12 and frames[295550]["block"] == 0 and frames[295551]["hp"] == 0 and sum(e["hp"] for e in frames[295550]["enemies"]) == 568)
denom = json.loads((S / "denominator-verification.json").read_text())
check("冻结13局55试5赢", denom["total"] == {"fights": 13, "attempts": 55, "won": 5})
check("真正重打12场54试4赢", denom["actually_retried"] == {"fights": 12, "attempts": 54, "won": 4})
sources = json.loads((S / "source-coverage.json").read_text())
check("四项窄源码均实际live祖先", all(x["live_ancestor"] and x["base_ancestor"] for x in sources["narrow_sources"]))
result = {"kind": "material_assertions_only", "passed": sum(c["passed"] for c in checks), "total": len(checks), "checks": checks,
          "limits": "不作tsc/vitest成功、候选完整执行、旧dirty模型校准或整战收益声称。"}
(S / "material-checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if all(c["passed"] for c in checks) else 1)

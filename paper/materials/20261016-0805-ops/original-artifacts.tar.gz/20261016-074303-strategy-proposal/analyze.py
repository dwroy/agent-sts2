import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
EVIDENCE = HERE / 'evidence'


def read(name):
    with (EVIDENCE / (name + '.evidence.jsonl')).open() as handle:
        return [json.loads(line) for line in handle]


def dump(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(values):
    return {x['power_id']: x['amount'] for x in values or []}


def state_view(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    return {
        'line': item['line'], 'sha256': item['sha256'], 'offset': item['offset'],
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player.get('powers')), 'potions': run.get('potions'),
        'deck_upgrades': sum(c.get('upgraded') is True for c in run.get('deck', [])),
        'hand': [{'id': c.get('card_id'), 'i': c.get('index'), 'u': c.get('upgraded'),
                  'cost': c.get('energy_cost'),
                  'vars': {v['name']: [v.get('base_value'), v.get('current_value')]
                           for v in c.get('dynamic_values', [])}}
                 for c in combat.get('hand', [])],
        'enemies': [{'id': e.get('enemy_id'), 'i': e.get('index'), 'hp': e.get('current_hp'),
                     'max_hp': e.get('max_hp'), 'block': e.get('block'),
                     'powers': powers(e.get('powers')), 'move': e.get('move_id'),
                     'intents': e.get('intents')} for e in combat.get('enemies', [])],
    }


def main():
    dispatch = json.loads((HERE / 'dispatch.json').read_text())
    wanted = dispatch['runs']
    stream_rows = {name: read(name) for name in
                   ('runs', 'states', 'decisions', 'sl-attempts', 'run-config', 'run-plans', 'brain', 'fight-plans')}
    checks = []
    manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
    for entry in manifest:
        name = entry['stream']
        path = EVIDENCE / (name + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
        with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
            for item in stream_rows[name]:
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                row = item['row']
                fp = row.get('fingerprint')
                if isinstance(fp, str):
                    try:
                        fp = json.loads(fp)
                    except ValueError:
                        fp = None
                ids = {x for x in [row.get('run_id'), row.get('run'),
                                   (row.get('state') or {}).get('run_id'),
                                   fp.get('run') if isinstance(fp, dict) else None]
                       if isinstance(x, str) and x and x != 'run_unknown'}
                assert ids == {item['run_id']} and item['run_id'] in wanted
        checks.append({'stream': name, 'rows': len(stream_rows[name]), 'sha_verified': True,
                       'source_bytes_verified': True, 'explicit_identity_verified': True,
                       'counts': dict(Counter(x['run_id'] for x in stream_rows[name]))})
    dump('evidence-verification.json', checks)
    targets = {'VLZ6CCT8AQ0A': [35, 43, 45], '8JRE1C4H4Z2W': [17, 33],
               'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [33, 39],
               '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [30]}
    all_meta = []
    for run_id in wanted:
        runs = [x for x in stream_rows['runs'] if x['run_id'] == run_id]
        assert len(runs) == 1
        run = runs[0]['row']
        assert run['character'] == 'SILENT' and run['ascension'] == 10
        floors = targets[run_id]
        states = [x for x in stream_rows['states'] if x['run_id'] == run_id]
        selected_states = [x for x in states if (x['row']['state'].get('run') or {}).get('floor') in floors]
        decisions = [x for x in stream_rows['decisions'] if x['run_id'] == run_id]
        bounded = [x for x in decisions if x['row'].get('floor') in floors]
        accepted, excluded = [], []
        for item in bounded:
            row = item['row']
            if not row.get('decision_id'):
                excluded.append({'line': item['line'], 'sha256': item['sha256'],
                                 'reason': '原流元数据无 decision_id；保留原件，不生成动作身份。',
                                 'row': row})
            else:
                accepted.append(dict(row, _line=item['line'], _source_sha256=item['sha256']))
        accepted.sort(key=lambda x: (x.get('observed_ts', ''), x['_line']))
        audit_input = {'run': run, 'decisions': accepted,
                       'states': [dict(x['row'], _line=x['line'], _source_sha256=x['sha256'])
                                  for x in selected_states]}
        dump(run_id + '.audit-input.json', audit_input)
        dump(run_id + '.excluded-metadata.json', excluded)
        dump(run_id + '.states-compact.json', [state_view(x) for x in selected_states])
        compact = []
        for item in bounded:
            row = item['row']
            compact.append({key: row.get(key) for key in
                            ('observed_ts', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label',
                             'decider', 'chosen', 'result', 'rationale', 'hp_guard', 'sl_explore',
                             'answers', 'rollout', 'potions', 'timing')} |
                           {'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256']})
        dump(run_id + '.decisions-compact.json', compact)
        all_meta.append({'run_id': run_id, 'run': run, 'floors': floors,
                         'input_decisions': len(accepted), 'excluded_metadata': len(excluded),
                         'states': len(selected_states),
                         'streams': {name: sum(x['run_id'] == run_id for x in rows)
                                     for name, rows in stream_rows.items()}})
    dump('analysis-input-summary.json', all_meta)
    print(json.dumps({'verified_rows': sum(x['rows'] for x in checks), 'runs': all_meta}, ensure_ascii=False))


if __name__ == '__main__':
    main()

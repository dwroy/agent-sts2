import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
checks = []
refs = []


def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    assert condition, name


def read(name):
    return json.loads((S / name).read_text())


states = {run: {x['line']: x for x in read(run + '.states-compact.json')}
          for run in read('dispatch.json')['runs']}
raw_d = {x['line']: x for x in (json.loads(line) for line in
         (S / 'evidence/decisions.evidence.jsonl').open())}


def frame(run, line):
    item = states[run][line]
    refs.append({'run_id': run, 'stream': 'states', 'line': line,
                 'offset': item['offset'], 'sha256': item['sha256']})
    return item


def enemy(state, ident):
    return next(x for x in state['enemies'] if x['id'] == ident)


def card(state, ident):
    return next(x for x in state['hand'] if x['id'] == ident)


v = 'VLZ6CCT8AQ0A'
a, b = frame(v, 275564), frame(v, 275565)
check('F35 神化能量7→5', (a['energy'], b['energy']) == (7, 5))
check('F35 防御基础5→8', (card(a, 'DEFEND_SILENT')['vars']['Block'][0], card(b, 'DEFEND_SILENT')['vars']['Block'][0]) == (5, 8))
check('F35 打击现场7→10', (card(a, 'STRIKE_SILENT')['vars']['Damage'][1], card(b, 'STRIKE_SILENT')['vars']['Damage'][1]) == (7, 10))
check('F35 匕首雨现场5→7', (card(a, 'DAGGER_SPRAY')['vars']['Damage'][1], card(b, 'DAGGER_SPRAY')['vars']['Damage'][1]) == (5, 7))
check('F35 工具费用1→0', (card(a, 'TOOLS_OF_THE_TRADE')['cost'], card(b, 'TOOLS_OF_THE_TRADE')['cost']) == (1, 0))
check('F35 场外升级数未变', a['deck_upgrades'] == b['deck_upgrades'] == 1)
a, b, c = frame(v, 275679), frame(v, 275680), frame(v, 275687)
check('F43 勒紧4→6', (card(a, 'FASTEN')['vars']['ExtraBlock'][0], card(b, 'FASTEN')['vars']['ExtraBlock'][0]) == (4, 6))
check('F43 尖啸6→8', (card(a, 'PIERCING_WAIL')['vars']['StrengthLoss'][0], card(b, 'PIERCING_WAIL')['vars']['StrengthLoss'][0]) == (6, 8))
check('F43 下一轮毒雾已升级', card(c, 'NOXIOUS_FUMES')['u'] is True)
check('F43 观测轮端点扣敌51/玩家损13', enemy(a, 'SOUL_NEXUS')['hp'] - enemy(c, 'SOUL_NEXUS')['hp'] == 51 and a['hp'] - c['hp'] == 13)
check('F43 场外升级数未变', a['deck_upgrades'] == b['deck_upgrades'] == c['deck_upgrades'] == 4)
a, b = frame(v, 275728), frame(v, 275729)
check('F45 药后血量67不变', a['hp'] == b['hp'] == 67)
check('F45 药后能量加1/两张新牌', b['energy'] - a['energy'] == 1 and len(b['hand']) - len(a['hand']) == 2)
check('F45 两次MC问题指纹不同', raw_d[269748]['row']['fingerprint'] != raw_d[269754]['row']['fingerprint'])
check('F45 MC两次分别1/12和12/12', [(raw_d[i]['row']['potions']['random'][0]['samples'], raw_d[i]['row']['potions']['random'][0]['requested']) for i in [269748, 269754]] == [(1, 12), (12, 12)])
check('F45 初问1轮退化/best空', raw_d[269748]['row']['rollout']['horizon'] == 1 and raw_d[269748]['row']['rollout']['best'] is None)

run = '8JRE1C4H4Z2W'
audit = read(run + '.audit-output.json')


def turn(attempt, number):
    return next(x['facts'] for x in audit['observed_turns'] if x['floor'] == 33 and x['attempt'] == attempt and x['turn'] == number)


check('8JRE 首/三试T2同指纹', raw_d[270216]['row']['fingerprint'] == raw_d[270282]['row']['fingerprint'])
check('8JRE 首试T2端点损3扣10', turn(1, 2)['player_hp_delta'] == -3 and turn(1, 2)['enemy_hp_changes'][0]['hp_delta'] == -10)
check('8JRE 三试T2端点损15扣17', turn(3, 2)['player_hp_delta'] == -15 and turn(3, 2)['enemy_hp_changes'][0]['hp_delta'] == -17)
check('8JRE 第二试T5端点损4扣25', turn(2, 5)['player_hp_delta'] == -4 and turn(2, 5)['enemy_hp_changes'][0]['hp_delta'] == -25)
terminal = next(x['terminal_observation'] for x in audit['observed_actions'] if x['source_line'] == 270441)
check('8JRE 末轮终局观测存在', terminal['facts'] is not None)
check('8JRE 末轮实际轮端点损5不填完整入伤', turn(6, 11)['player_hp_delta'] == -5 and turn(6, 11)['actual_uncapped_hp_loss'] is None)

run = 'CA5KE8GFJ9X2'
a, b = frame(run, 273257), frame(run, 273268)
check('CA5 力量4→8但仍有虚弱', enemy(a, 'SEWER_CLAM')['powers']['STRENGTH_POWER'] == 4 and enemy(b, 'SEWER_CLAM')['powers']['STRENGTH_POWER'] == 8 and enemy(b, 'SEWER_CLAM')['powers']['WEAK_POWER'] == 1)
check('CA5 末轮血2挡10意图14', (b['hp'], b['block'], enemy(b, 'SEWER_CLAM')['intents'][0]['damage']) == (2, 10, 14))
check('CA5 本战无正敏捷观察', all(x['powers'].get('DEXTERITY_POWER', 0) <= 0 for x in states[run].values()))

run = '5PM6JAQG6FNQ'
a, b = frame(run, 274379), frame(run, 274380)
check('5PM 冒泡端点实耗1能', a['energy'] - b['energy'] == 1)
check('5PM 冒泡端点敌方未变', a['enemies'] == b['enemies'])
check('5PM 无毒目标且未建立雾', 'POISON_POWER' not in enemy(a, 'THE_LOST')['powers'] and 'NOXIOUS_FUMES_POWER' not in a['powers'])
check('5PM F33确有雾3/触媒1/群蛇4', any(x['powers'].get('NOXIOUS_FUMES_POWER') == 3 and x['powers'].get('ACCELERANT_POWER') == 1 and x['powers'].get('SERPENT_FORM_POWER') == 4 for x in states[run].values()))

run = '61E2QS63Y9WU'
a, b, c = frame(run, 273503), frame(run, 273504), frame(run, 273507)
check('61E 吸取后负敏捷2及敌力2', b['powers']['DEXTERITY_POWER'] == -2 and enemy(b, 'LAGAVULIN_MATRIARCH')['powers']['STRENGTH_POWER'] == 2)
check('61E 两防御合6挡', c['block'] == 6 and states[run][273506]['block'] == 3)
check('61E 毒17结束后敌67→34', enemy(c, 'LAGAVULIN_MATRIARCH')['powers']['POISON_POWER'] == 17 and enemy(c, 'LAGAVULIN_MATRIARCH')['hp'] - enemy(states[run][273508], 'LAGAVULIN_MATRIARCH')['hp'] == 33)
a, b = frame(run, 273595), frame(run, 273596)
check('61E 幻象余2且T4实际玩家损15', enemy(a, 'PARAFRIGHT')['hp'] == 2 and enemy(b, 'PARAFRIGHT')['hp'] == 2 and a['hp'] - b['hp'] == 15)
check('61E 两实体力量3→6', all(enemy(a, e)['powers']['STRENGTH_POWER'] == 3 and enemy(b, e)['powers']['STRENGTH_POWER'] == 6 for e in ['PARAFRIGHT', 'THE_OBSCURA']))

run = 'DUZUBAJ3A8GP'
a, b, c = frame(run, 274997), frame(run, 275017), frame(run, 275018)
check('DUZ 末试睡3/2/1可见', [enemy(states[run][i], 'SLUMBERING_BEETLE')['powers']['SLUMBER_POWER'] for i in [274997, 275002, 275006]] == [3, 2, 1])
check('DUZ 临时减力后恢复/成长至4', enemy(b, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'] == -4 and enemy(c, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'] == 4 and enemy(c, 'SLUMBERING_BEETLE')['intents'][0]['damage'] == 22)
check('DUZ 同伴退场后甲虫仍在', [e['id'] for e in c['enemies']] == ['SLUMBERING_BEETLE'])
summary = read('audit-summary.json')
check('六输入693动作/139段', sum(x['observed_actions'] for x in summary) == 693 and sum(x['segments'] for x in summary) == 139)
check('76已观测轮端点/55未知', sum(x['turn_status'].get('observed_turn_endpoints', 0) for x in summary) == 76 and sum(x['turn_status'].get('unknown', 0) for x in summary) == 55)
check('未认证整候选', all(x['full_candidate'] == 0 for x in summary))
check('原始6995行已核', sum(x['rows'] for x in read('evidence-verification.json')) == 6995)
check('当前线上实际施放仍未知', 'actual_cast_this_fight: null' in (S.parents[2] / 'agent/src/reflex/silent-apotheosis-reference.ts').read_text())

(S / 'material-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
(S / 'critical-source-refs.json').write_text(json.dumps(refs, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(checks), 'kind': '冻结材料断言，非生产测试或完整候选认证'}, ensure_ascii=False))

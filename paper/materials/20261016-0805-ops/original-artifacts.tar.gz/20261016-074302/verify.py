import json,pathlib,hashlib,collections
p=pathlib.Path(__file__).parent
before=json.loads((p/'append-before.json').read_text());data=pathlib.Path('notes/lessons.md').read_bytes();draft=(p/'lesson-draft.md').read_bytes()
assert hashlib.sha256(data[:before['bytes']]).hexdigest()==before['sha256']
assert data[before['bytes']:before['bytes']+len(draft)]==draft
assert sum(x.startswith(b'## DHYFWEN40SJ7') for x in data.splitlines())==1
L=json.loads((p/'ledger-find-final.json').read_text());S={r['_line']:r for r in map(json.loads,(p/'states.jsonl').open())};D={r['_line']:r for r in map(json.loads,(p/'decisions.jsonl').open())};R=json.loads((p/'DHYFWEN40SJ7-resources.json').read_text())
for c in R['combats']:
 for v in [c['entry'],c['exit'] or c['last']]:
  s=S[v['line']]['state'];assert s['run_id']=='DHYFWEN40SJ7';assert s['run']['character_id'].lower()=='silent';assert s['run']['current_hp']==v['hp'];assert s['run']['max_hp']==v['max_hp'];assert s['turn']==v['turn']
assert len(R['combats'])==24
assert [c['entry']['hp'] for c in R['combats'][-6:]]==[88,85,85,85,85,85]
assert [((c['exit'] or c['last'])['turn'],(c['exit'] or c['last'])['hp']) for c in R['combats'][-6:]]==[(14,8),(13,1),(14,7),(13,11),(14,7),(14,0)]
c=S[420959]['state']['combat'];assert(c['player']['current_hp'],c['player']['block'],c['enemies'][0]['intents'][0]['total_damage'])==(7,17,36)
c=S[420960]['state']['combat'];assert c['player']['current_hp']==0;assert c['enemies'][0]['current_hp']==207
assert 36-17-1==18 and 18+1-7==12
assert sum(r.get('decider')=='jev' and (r.get('confidence')or 1)<.35 for r in D.values())==31
assert sum(bool(r.get('hp_guard')) for r in D.values())==3
assert sum(r.get('chosen',{}).get('action')=='use_potion' for r in D.values())==15
assert sum(r.get('chosen',{}).get('action')=='discard_potion' for r in D.values())==2
counts=collections.Counter(r.get('rollout_best_chosen') for r in D.values() if r['decider']=='jev' and r['label'].startswith('combat/'))
assert counts=={True:257,False:8,None:4}
keys=['combat/plan','combat/lethal','combat/mod-lethal','combat/least-loss','combat/end_turn','combat/potion-now']
a=[r for r in D.values() if r['decider']=='code' and r['label'] in keys and r.get('chosen')]
assert len(a)==212;assert len({(r['floor'],r.get('sl_attempt'),r['turn']) for r in a})==123
assert sum(c['last']['turn'] for c in R['combats'])==179
acq=[]
for v in R['resource_changes']:
 if v['restart_boundary']:continue
 old={tuple(x) for x in v['from']['potions']};acq.extend(x for x in v['to']['potions'] if tuple(x) not in old)
assert len(acq)==12
assert set(x['id'] for x in L)>={'silent-0023','silent-0027','silent-0028','silent-0046','silent-0332'}
receipt={'old_lessons_prefix_preserved':True,'appended_section_byte_equal':True,'combat_windows_verified':24,'entry_hp_f48':[88,85,85,85,85,85],'final_turn':14,'final_hp':0,'pre_death_hp':7,'pre_death_block':17,'incoming':36,'full_unblocked_hp_loss_after_rod':18,'minimum_extra_hp_to_survive':12,'final_enemy_hp':207,'low_confidence':31,'hp_guards':3,'acquired_potions':12,'drink_actions':15,'discard_actions':2,'code_actions':212,'code_turn_windows':123,'all_turn_windows':179,'ledger_ids':[x['id'] for x in L],'ledger_check':0}
(p/'verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))

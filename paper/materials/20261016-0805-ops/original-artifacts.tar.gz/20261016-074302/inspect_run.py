import json,collections,pathlib
p=pathlib.Path(__file__).parent
d=[json.loads(x) for x in (p/'decisions.jsonl').open()]
def brief(r): return {k:r.get(k) for k in ['_line','ts','floor','turn','label','decider','chosen','rationale','confidence','sl_attempt','sl_reloads']}
print('WINDOW',d[0]['ts'],d[-1]['ts'])
print('LABELS',collections.Counter((r['label'],r['decider']) for r in d))
print('JEVLOW',sum(r['decider']=='jev' and isinstance(r.get('confidence'),(int,float)) and r['confidence']<.35 for r in d))
print('ROLLOUT',collections.Counter((r['label'],(r.get('journal') or {}).get('rollout_best_chosen')) for r in d if r['decider']=='jev'))
print('NONCOMBAT')
for r in d:
 if r['decider']=='codex': print(json.dumps(brief(r),ensure_ascii=False))
print('GUARDS')
for r in d:
 if any(s in str(r.get('journal',{})).lower() for s in ['hp_guard','hp-guard','guardrail']):print(json.dumps(r,ensure_ascii=False)[:6000])
print('SL')
for l in (p/'sl-attempts.jsonl').open():
 r=json.loads(l);print(json.dumps(r,ensure_ascii=False)[:3500])
print('CONFIG')
r=json.loads((p/'run-config.jsonl').read_text());print({k:v for k,v in r.items() if k in ['ts','run_id','code','git','git_sha','git_commit','brain','model','character','ascension']});print('config keys',list(r))
print('PLANS')
for l in (p/'run-plans.jsonl').open():
 r=json.loads(l);print('keys',r.keys()); print(json.dumps(r,ensure_ascii=False)[:2200])

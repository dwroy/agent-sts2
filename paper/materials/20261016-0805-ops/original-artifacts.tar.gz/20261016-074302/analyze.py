import pathlib,json,collections,datetime
p=pathlib.Path(__file__).parent
S=[json.loads(l) for l in (p/'states.jsonl').open()];D=[json.loads(l) for l in (p/'decisions.jsonl').open()];R=json.loads((p/'DHYFWEN40SJ7-resources.json').read_text())
print('RESOURCE CHAIN')
for c in R['combats']:
 e=c['entry'];z=c['exit'] or c['last'];print(c['sequence'],c['floor'],','.join(c['enemies']),e['hp'],e['max_hp'],e['potions'],'->',z['hp'],z['max_hp'],z['potions'],c['end'],'T'+str(z['turn']),'s'+str(e['line'])+'-'+str(z['line']),e['ts'],z['ts'])
 print('turns',[(t['turn'],t['live_enemy_hp_start'],t['visible_enemy_hp_loss_lower_bound'],t['observed_hp_added'],t['gaps']) for t in c['enemy_hp_audit']['turns']])
print('RESOURCE CHANGES NONCOMBAT OR BELT')
for v in R['resource_changes']:
 a,b=v['from'],v['to']
 if v['combat_sequence'] and a['potions']==b['potions']:continue
 ds=[r for r in D if a['ts']<=r.get('observed_ts',r['ts'])<=b['ts']]
 print('s',a['line'],b['line'],'F',a['floor'],b['floor'],'T',b['turn'],a['hp'],a['max_hp'],a['potions'],'->',b['hp'],b['max_hp'],b['potions'],'restart',v['restart_boundary'],'decision',[(r['_line'],r['label'],r['chosen']) for r in ds])
print('FINAL STATES')
for r in S[-13:]:print(json.dumps(r,ensure_ascii=False))
print('JEV',len([r for r in D if r['decider']=='jev']),collections.Counter((r['label'],r.get('rollout_best_chosen')) for r in D if r['decider']=='jev'))
print('GUARDS')
for r in D:
 if 'guard' in str(r.get('selection_audit',{})).lower() or 'hp_guard' in r or 'hp-guard' in r.get('rationale','').lower():print(json.dumps(r,ensure_ascii=False)[:6500])
print('AUTO COUNTS')
keys=['combat/plan','combat/lethal','combat/mod-lethal','combat/least-loss','combat/end_turn','combat/potion-now']
a=[r for r in D if r['decider']=='code' and r['label'] in keys]
print(len(a),collections.Counter(r['label'] for r in a),len({(r['floor'],r.get('sl_attempt'),r['turn']) for r in a}), 'all',len({(r['floor'],r.get('sl_attempt'),r['turn']) for r in D if r['label'].startswith('combat/')}))
print('POTION ACTIONS')
for r in D:
 if r.get('chosen',{}).get('action') in ['use_potion','drink_potion','discard_potion','claim_potion','buy_potion']:print(r['_line'],r['floor'],r['turn'],r.get('sl_attempt'),r['chosen'],r['result'],r['rationale'])
print('USAGE')
u=collections.defaultdict(collections.Counter)
for r in D:
 if r.get('usage'):
  for k,v in r['usage'].items():
   if isinstance(v,(int,float)):u[r['decider']][k]+=v
print(u)

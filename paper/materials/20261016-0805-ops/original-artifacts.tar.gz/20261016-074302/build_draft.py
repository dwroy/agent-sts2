import json,pathlib,collections
p=pathlib.Path(__file__).parent
S=[json.loads(l) for l in (p/'states.jsonl').open()];D=[json.loads(l) for l in (p/'decisions.jsonl').open()];R=json.loads((p/'DHYFWEN40SJ7-resources.json').read_text())
names={}
for r in S:
 for e in (r['state'].get('combat')or{}).get('enemies',[]):names.setdefault(e['enemy_id'],e['name'])
base='''
## DHYFWEN40SJ7（A10，静默猎手，第48层，死于三幕首boss实验体 #C87 TEST_SUBJECT：首试88/88、后五试首帧85/88，均槽0毒药水；前五试T14／T13／T14／T13／T14判死读档，末试T14以7血17挡对36攻击，钨棍后完整需损18、存活至少差12血；第三阶段终帧仍207/313血，显示名 #C89）

- [第一阶段每张技能的激怒代价要和减力、格挡一起核；打法（Jev出牌）] 实验体 TEST_SUBJECT 的激怒 ENRAGE_POWER 在本局A10为3；末试T1毒雾 NOXIOUS_FUMES 能力不加敌力，扫腿＋ LEG_SWEEP 技能使0→3力，虚弱后22攻变18，14挡配钨合金棍 TUNGSTEN_ROD 实损3。T3尖啸 PIERCING_WAIL 同时触发加3与临时减6，敌3→0力、玩家易伤下28→24攻；疯狂科学 MAD_SCIENCE、防御＋ DEFEND_SILENT、坚毅 TRUE_GRIT 再逐张加3，末9力34攻、29挡，实损4；次轮尖啸返还临时6力，敌到15力。不能将“减6”误作净减6或后续永久防守，也不能由此禁用所有技能：本局这些牌确有挡血收益，未执行少打技能的整战胜线（s420877—420900，d407591—407597）。这是旧机制的A10补证，不将已有动作说成同一打法错误重犯。（之前学过：silent-0028，S1.exp189）
- [高毒与纸面攻击不等于无实体轮已兑现伤害；打法（Jev出牌）] 两张毒雾共建 NOXIOUS_FUMES_POWER 5；实验体 TEST_SUBJECT 换阶段后新段初毒均5，旧段15／24毒不能累加到新段。末试T14第三阶段有无实体 INTANGIBLE_POWER 1，敌212/313、21毒；亮剑 FLASH_OF_STEEL 与精确切击 PRECISE_CUT 两次动作各只实扣1，结束边界210→207，整轮仅可见扣5。这个边界同时含中毒、铜质鳞片 BRONZE_SCALES 荆棘和招架盾 PARRYING_SHIELD，缺逐效果帧，不能把净扣3全写成毒或把21毒计为21实伤。本局未持有／施放触媒 ACCELERANT，不借旧局额外结毒次数。已到第三阶段仍未过首boss，不等于接续第二boss成功（s420899—420900、420928—420929、420954—420960）。本次为既有阶段／无实体事实补证，未证明另一出牌顺序能赢。（之前学过：silent-0027，S1.exp203）
- [成功首战样本的非正HP仍令连续boss评估降级；bug（代码，旧项）] F48六组评估均先两次pending不派动作，再第三次degraded、0有效样本；首组T6种子3510836362报won=true／died=false／14轮，却因nonpositive-hp无法接续，次试T5种子3067835433为15轮，后三至六试T5种子599473647为14轮。当前只读live的 agent/src/sim/boss-sim.ts:328 检查正HP资源，:338抛错，:369调用；定位的是资源契约失败及传播，完整resources／steps被错误文本截断，不能认定是哪张牌／死亡时序的根因。notes/fix-queue.md未列，但 notes/fix-queue-v4.md:1336、:1348 与silent-0332已有，属于旧bug；不是本任务新发现或已修。C1明确隐藏不可用整场数字后继续首动作，不把“出口能继续”写成修好了资源契约（d407218—407220、407287—407289、407361—407363、407444—407446、407521—407523、407605—407607）。（之前见过：silent-0332）

- [记录] runs.jsonl:798确认SILENT、A10、victory=false、F48、code字段原值current；run-config原生记录为e716bd28fd8eca9e4d76d066680304fd11935e37／e716bd2+dirty，脏项为12份知识／报告，未复原当时全部脏字节。file:line按本次只读live 098fbea4b753b9786d4da84072dac574d0975a37取号。唯一局报notes/run-1016-0724-DHYFWEN40SJ7.md已全文读；按局号流式抽1152决策、1188状态、12计划、8条SL记录；另核51条brain原生请求，均Codex／gpt-6.1-sol／xhigh／accepted=true。兼容字段deepseek_calls=51、ds_*不代表实际DeepSeek；本次决策窗2026-10-15T21:40:17.029Z—23:23:50.719Z的deepseek-reasoning为0条，因此下述“DeepSeek路线／构筑／休息”实际由Codex决定，不伪造DeepSeek原话。

  实盘资源链：先运行resource_chain.py，再按states／decisions／sl-attempts核对。以下包含全部18场胜战和F48六试；HP是当前／上限，药栏数字为实际槽位，空为∅。净HP变化是离场减进场，包含自损、回血、上限增长，绝不当作敌人总伤害。首试T1捕获开场未就绪88→85，其余五试首个T1帧已85，开场扣血过程未记录；都不是缺T1。前五试没有战后退出帧，表内末态不是离场。s／d分别为原states.jsonl／decisions.jsonl行号，时间均为2026-10-15 UTC。

  药栏缩写：蛇油＝异蛇之油 SNECKO_OIL；挡＝格挡药水 BLOCK_POTION；技＝技能药水 SKILL_POTION；果＝果汁 FRUIT_JUICE；攻＝攻击药水 ATTACK_POTION；肌＝肌肉药水 FLEX_POTION；缚＝缚魂药水 POTION_OF_BINDING；毒＝毒药水 POISON_POTION；无色＝无色药水 COLORLESS_POTION；鱼油＝异鱼之油 FYSH_OIL；弱＝虚弱药水 WEAK_POTION。

  | 战斗／实盘结果 | 入口→退出或最后观察HP；净变化 | 入口→末药栏 | 原状态证据；UTC时间 |
  | --- | --- | --- | --- |
'''
def belt(x):return '、'.join(str(a)+':'+b for a,b in x) or '∅'
short={'SNECKO_OIL':'蛇油','BLOCK_POTION':'挡','SKILL_POTION':'技','FRUIT_JUICE':'果','ATTACK_POTION':'攻','FLEX_POTION':'肌','POTION_OF_BINDING':'缚','POISON_POTION':'毒','COLORLESS_POTION':'无色','FYSH_OIL':'鱼油','WEAK_POTION':'弱'}
def bshort(x):return '、'.join(str(a)+':'+short[b] for a,b in x) or '∅'
for c in R['combats']:
 e=c['entry'];z=c['exit'] or c['last'];fl=c['floor'];seq=c['sequence'];label='／'.join(names[x]+' '+x for x in c['enemies'])
 if fl==15:label+='（后援卑鄙地精 SNEAKY_GREMLIN／胖地精 FAT_GREMLIN）'
 outcome='胜' if fl<48 else '试'+str(seq-18)+('，死亡' if seq==24 else '，判死重载，缺退出帧')
 delta=z['hp']-e['hp'];dt=f'{delta:+d}' if c['exit'] else f'至末态{delta:+d}，净离场未记录'
 base+=f"  | F{fl} {label}；{outcome} | {e['hp']}/{e['max_hp']}→{z['hp']}/{z['max_hp']}；{dt} | {bshort(e['potions'])}→{bshort(z['potions'])} | s{e['line']}—{z['line']}；{e['ts'][11:23]}—{z['ts'][11:23]} |\n"
base+='''
  关键资源从哪里来：F2损6后50血进F3店，F4零损仍50；F5事件实回10到60，F6零损，F8锻药瓶不回血，F9损4至56。F11休息实际56→70，F12“再撑一会”题面付3HP、钨棍后实70→68（s419886→419887）；F13胜战零损，F14胜战损6至62并奖果汁；F15T1饮果汁62/70→67/75、随后损4，胜后63/75；F16休息补12到75，F17本体T10结束、T11实际挡自爆后40/75胜。转幕40→68不是战斗回血；F19损8到60、F22损2到58，F24草莓 STRAWBERRY 使58/75→65/82，F27锻毒雾；F28胜战损12到53，F29锻扫腿，F30胜战零损，F31胜战损23至30，F32休息实加24到54，F33胜战净损44只余10。转幕10→67单列；F35胜战67/82→50/74，上限何一原子效果下降未记录；F36茶事件实回24到74并取得王室猛毒 ROYAL_POISON。F37胜战损8至66，F38弃无色、买鱼油；F39赢足三段仍损31至35并喝鱼油、奖肌肉。F42锻余像 AFTERIMAGE没有回血；F43芒果 MANGO使35/74→49/88，弃肌买弱；F44休息加26到75，F45胜战含开场自损净损12、喝弱，留下63/88与槽0毒；F46镜事件改升级、HP仍63，F47实际休息补25至88/88，F48首帧承接88与同一槽0毒。没有省略F39／F45这些胜战，也没有“留前场药必胜”的反事实证据。

  每回合需伤／实打：下表“需”是本轮首帧活敌HP合计，敌挡、后援、复起及新阶段另记；“扣”是相邻帧唯一ID能对齐的可见HP减少下界，含毒／荆棘等，非单卡直伤或完整毛伤。重名多体不强配身份；缺死亡归零帧不补尾击。HP扣减列按实际HP减少逐轮累计，净增长另注；均从T1起。

  | 战斗 | 逐轮需；逐轮可见扣血下界 | 我方逐轮实见HP扣减 |
  | --- | --- | --- |
'''
for c in R['combats']:
 ts=c['enemy_hp_audit']['turns'];req='／'.join(str(x['live_enemy_hp_start']) for x in ts);loss=[]
 for t in ts:
  v=str(t['visible_enemy_hp_loss_lower_bound'])
  if 'ambiguous_enemy_identity' in t['gaps']:v='未记录'
  if any(x in t['gaps'] for x in ['body_removed_without_death_frame','changed_max_hp_identity_unknown']):v+='＊'
  loss.append(v)
 h=collections.defaultdict(lambda:[0,0])
 for v in c['changes']:
  a,b=v['from'],v['to'];d=b['hp']-a['hp'];h[a['turn']][0]+=max(0,-d);h[a['turn']][1]+=max(0,d)
 hp='／'.join(str(h[t['turn']][0]) for t in ts)
 if c['floor']==15:hp+='；T1果汁实加5HP及5上限'
 if c['floor']==48 and c['sequence']==19:hp+='；T1含开场自损3'
 label=f"F{c['floor']}"+(f"试{c['sequence']-18}" if c['floor']==48 else '')
 base+=f"  | {label} | 需{req}；扣{'／'.join(loss)} | {hp} |\n"
base+='''
  ＊表示末尾余血退场／改变上限，缺中间归零或身份确认，不能将数值当完整伤害。F15T5新后援总HP27；F33T4边界敌325→338出现净回13，逐击／回血先后缺帧。F17T11的999999999是巨兽蒸汽自爆占位体，不是本体伤害需求；T11实65血18挡对44攻击，钨棍后损25、剩40胜（s420020—420023）。F39巨斧三段上限86／91／102分别推进到后段，阶段尾击不补造。F48末试第一段T4末余5后T5转212，第二段T9确见0后T10转313，分别重置敌毒到5；第三段未结束。末轮7血17挡对36单击，钨棍把未挡19减为18，保持该末态至少需19血，即还差12；实帧只扣剩余7到0，不能把7当完整威胁或把18当还差18。敌最后207/313，日志显示名由 #C87 变 #C89，但ID始终TEST_SUBJECT。

  路线／构筑／休息：d406515原话“古钱币早进店，补战斗牌奖，三火支撑后段精英。”；F1巨大扭蛋 LARGE_CAPSULE实得古钱币 OLD_COIN与地精之角 GREMLIN_HORN；F3买扫腿、匕首雨 DAGGER_SPRAY、灯笼 LANTERN、删防御、买挡药。F2取带毒刺击 POISONED_STAB、F4／9取精确切击、F6取药瓶，F8升级药瓶；F13尖啸、F14后空翻 BACKFLIP、F15毒雾、F17萎靡 MALAISE。F18选择佩尔之肉 PAELS_FLESH，d406758“取肉补能，早店补防，单精英配三火。”；F20买铜质鳞片，F21事件跨色只按本局可见牌取坚毅，不调用铁甲战士经验；F19后空翻、F22第二尖啸、F27锻毒雾、F29锻扫腿。F32休息理由明确“Heal to 54/82. Modeled boss survival is 86%, versus at most 47% from smithing; poison setup needs the buffer.”；F33奖余像。F34计划“金币支持两店补强，避精英保留三火备连王。”；F35取早有准备＋ PREPARED；F37取冲刺 DASH，F38买打击木偶 STRIKE_DUMMY、亮剑、第二毒雾、拳刃 PUNCH_DAGGER并删防御、换鱼油；亮剑附魔动量的具体数值未披露，不能冒称已量化其整场收益。F40制疯狂科学、F41微型大炮 MINIATURE_CANNON，F42锻余像，F43买芒果和第二冲刺、换虚弱药水，F44及47回血，F45取第三尖啸。12条run-plans从早期灵活选牌转P毒方向，末p3803明说伤害缺口未知，并要求核激怒、阶段清毒与连续boss无中途回血；触媒／灵动步法 FOOTWORK未拿到，不能把“想要”当完整毒防核心兑现。

  Jev及代码：319次Jev，信心＜0.35共31次（F14=2、F17=1、F19=1、F22=3、F39=2、F45=1、F48=21）。150道combat/plan-choice中144为rollout_best_chosen=true、5为false、1未标；119道含药题113为true、3为false、3未标；有标记的257/265＝96.9811%，全部269道中有4道不具该标记，不补零。此标记是原Jev答案相对推演的排名，HP护栏、SL探索、抽弃重问后的动作不能沿用原答案“全线最优”身份；未完整逐条核验全部269候选兑现比例，写未记录。372条code计划续步中301沿Jev、71沿代码，与局报jev-plan重分账一致。代码自主战斗主动作212条＝plan120、lethal27、mod-lethal9、least-loss21、end_turn34、potion-now1，覆盖123/179个实际（层、SL尝试、回合）窗口，同轮可同时有Jev；另12条code combat/plan只是必需模拟pending、chosen为空且未派动作，不能计作12次自主出牌。focus题面共12个显式候选（F15=2、F37=10），答案实际选中4次：F15T5卑鄙地精；F37T1高塔炮手，T3两题“活体盾，高塔炮手”。F15地精佣兵先退场后招两后援，卑鄙地精T5退、胖地精T6最后退；F37高塔炮手T3先退、活体盾T4最后退（s419959／419964、420325／420329）。重名的蝌蚪／蛞蝓／外骨骼虫／异螨／卷轴完整逐体击杀顺序未记录；实验体各段不是不同focus敌人。

  HP护栏恰3次：F17T5 d406726原打击＋药瓶＋预计损22／伤38，换打击＋防御＋生存者 SURVIVOR预计损9／伤26，候选省13血、少12伤；五轮8样本续损估计53.75→43.125、模拟赢8→0，但实战后续重算后仍胜，不能把局部模拟赢0说成实败。换入三步和弃打击确已发生，75→66损9、敌166→140扣26（其中直伤6与结毒20）。F39T1 d407054原带毒刺击＋毒雾＋＋打击预计损17／伤18，换后空翻＋毒雾＋＋生存者预计损4／伤6，候选省13血、少12伤；抽牌后重问改接毒雾＋／坚毅，实际从可行动63→58损5、敌86→77扣9，另有入口66→63的开场自损，不能记完整换入线已落实或实省13。F48首试T3 d407197原两打击＋疯狂科学预计损16／伤35，护栏插尖啸预计损10／伤35，候选省6、输出差0；随后疯狂科学由代码重算，再选防御＋／坚毅，整轮实际73→69只损4、敌68→30扣38，不把整轮收益全归原候选。三条hp_guard.actual_outcome均空，以上来自独立状态核对；总候选省32血、少24伤仅为预测差相加，不是实省或反事实胜负。

  药水：非SL实际取得11瓶＝F2奖槽0蛇油、F3买槽1挡、F9奖槽0技、F14奖槽0果、F19奖槽0攻、F22奖槽0肌、F23事件槽1缚、F28奖槽0毒、F35奖槽1无色、F38买槽1鱼油、F39奖槽1肌、F43买槽1弱中的实际条目共12瓶；此处以逐项清单计12，见后面的核验值。饮用15动作＝F48前9瓶各饮一次、毒药水在六试各一次；主动丢弃2瓶＝F38槽1无色与F43槽1肌；末空栏。补充／奖励／购买与饮用、SL恢复分开，毒只实际获得1瓶，重载恢复5次不算又拿5瓶。饮用证据：F6T1蛇油d406567／s419830→419831；F13T1挡d406629／s419895→419896；F14T1技d406644／s419911→419912；F15T1果d406672／s419940→419941；F22T3攻d406808／s420081→420082；F28T1肌及缚d406851—406852／s420125→420127；F39T2鱼油d407061／s420355→420356；F45T1弱d407152／s420447→420448；F48六试T1毒d407189／407266／407339／407422／407499／407583，对应s420485→420486、420562→420563、420635→420636、420718→420719、420795→420796、420879→420880。技能药水和攻击药水原回执pending(unstable)，后续选牌和清槽证实效果，保留原回执，不重写completed。毒饮用当步敌111血不变、添6毒；药瓶是卡牌不是药水。没有提前喝／强制保留某瓶的受控整战证据，不新增此类规则。

  SL：sl-attempts:2263／2264分别记F17T11和F33T12首试赢；2265—2270记F48六试。前五试判死末态依次为T14 8血21挡对36、T13 1血22挡对30、T14 7血17挡对36、T13 11血15挡对42、T14 7血17挡对36，各次reload.ok=true且回T1。SL恢复边界HP为8→85、1→85、7→85、11→85、7→85，药栏均空→槽0毒；这些不是回血或奖励。重载首帧间的加载／开场扣血过程未记录，不能把85当每次完整入场档案HP。六试初始已知抽序前34张相同，draws在T5洗牌处截断；末试T3有SL replaying attempt 3的动作替换（d407591），T10—T14没有可控全牌序证明。六试不是六份独立胜率样本，也不说“换个选择必能赢”。

  路线投影与boss时钟：F1保存路线按当时70上限，F2／3／4／6／8／9／11／14／15／16／17预测56／53／53／50／47／68／65／70／48／45／66，实际入口56／50／50／60／60／60／56／68／62／63／75；事件回血、F8实锻及果汁改上限改变条件，不把全差额当同一路线模型残差。二幕初投F19=68实68，末F33按75上限投75，实际54/82，后续锻造／上限增长已不同；三幕初投F35=67实67/82，末F48按当时82投82，实际88/88，芒果及后续动作另记。选中营火的boss入口条件投影F8=66→实际75、F11=66→75、F16=75→75、F32=54→54、F42=67→实际88、F44=88→88、F47=88→88；早火默认未来回血，F42后还买芒果，F47的88是开场被王室猛毒扣血之前。旧boss-clock“需要／估计DPR、可活回合”字段未记录，不能用计划blockTarget代替。新量化题：F16回血选项300样本、均回合11.1000、有效DPR24.9248，实际F17 T10结束本体、T11挡自爆获胜；F32回血300样本、均13.1267轮、DPR32.6577，实际F33 T12胜。F47回血300样本、全部未联合通关、均6.5067轮、DPR24.1881、readiness.valid=0／missing=300；这些是低可信F48→F49联合终止窗口，不和实际首boss末试14轮直接相除。阶段归零／回血／尾击缺帧及联合口径不同，完整毛伤实打／估值比未记录，不用636−207再除14冒充模型校准。

  机制：本段只补同角色既有机制，不新增跨角色规则。除上述激怒3／减力恢复、阶段清毒、无实体外，末试T2实打余像 AFTERIMAGE建立1层后，精确切击、中和 NEUTRALIZE、匕首雨、毒雾＋四张各补1挡，从0到4；余像自身不补自己的首次挡。T13疯狂科学实加9挡、防御＋再9、冲刺＋再14，末32挡抵30攻而零损；T14只有17挡，能力已经建立不等于挡够。末战玩家未建立力量／敏捷增益，鱼油上场的增益未跨战继承。T5尖啸在无激怒的第二段把力量0→−6、11×3变5×3，21挡全挡；次轮负力量已消失，11×4的威胁恢复。两毒雾2＋3＝5层，T1饮毒加6，T2初毒7、T3初11；这些是实际时点，不当尚存毒已造成伤害。铜质鳞片现场3荆棘在正常第二段三击配毒与招架盾共同推进伤害，第三段无实体时不按每击3预付。分别为silent-0028／0027／0023／0046补support；不从本局推未经观察的机制常数或药水时机。

  用量及边界：首末决策6213.690秒＝103分33.690秒；run-config启动21:39:05.857Z至终局6284.862秒，纯战斗耗时未记录。Jev输入2909170、输出19054，合2928224＝runs.tokens；51次实际Codex脑输入9637448、输出65208（含推理57943），缓存5474688／9637448＝56.8064%，累计脑延迟1764874毫秒。两个独立run-plan输入293473／输出3917／缓存136832已经包含在51次内，不重复加；73条codex决策包含计划续步，不能当73次脑请求。fallback 1152条均false。Jev缓存、实付账单、纯战斗耗时、当时dirty完整字节、部分胜战尾击／重名逐体伤害与完整击杀顺序、F35上限下降的原子归因、末轮毒／反伤／招架盾逐项中间帧、异常样本完整resources／steps及机制根因、全部269候选实际完整兑现比例、未知抽牌／未选药时点及整战反事实、旧boss时钟和同口径实打／估值比均未记录。第一、二条补旧知识support，第三条旧bug记repeat，不将已知机制在失败局出现一概计作学后重犯；代码提案只登记给独立strategy-proposal，未改代码或实现／上线，不提交、不推送。
'''
# Count actual acquisitions independently from belt transitions, excluding SL restores.
acq=[]
for v in R['resource_changes']:
 if v['restart_boundary']:continue
 old={tuple(x) for x in v['from']['potions']}
 acq.extend((v['to']['floor'],v['to']['line'],x) for x in v['to']['potions'] if tuple(x) not in old)
assert len(acq)==12,acq
base=base.replace('非SL实际取得11瓶＝','非SL实际取得12瓶＝').replace('中的实际条目共12瓶；此处以逐项清单计12，见后面的核验值。','，共12瓶。')
(p/'lesson-draft.md').write_text(base)
print('草稿字符',len(base),'资源窗口',len(R['combats']),'实际取得药水',len(acq))

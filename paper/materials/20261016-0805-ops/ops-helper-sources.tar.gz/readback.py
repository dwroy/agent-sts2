from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,sys
r=root=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0805';pub=r/'paper/materials/20261016-0805-ops';sha=lambda b:hashlib.sha256(b).hexdigest();sys.path.insert(0,str(r/'ops'));from learner_checks import read_report
load=lambda f:json.loads(f.read_text())
def write(f,x):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True);state=load(r/'ops/codex-ops/learn.json')['batches'];exec((r/'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text().replace('assert registered_batch is None and launch[\"task\"] == \"postmortem\"','assert registered_batch is None and launch[\"task\"] == \"postmortem\"; registered_batch = bid'))
bids=['20261016-074303-fix-batch','20261016-074303-strategy-proposal','20261016-071301-strategy-proposal','20261016-074302'];folders={};readbacks=[]
for bid in bids:
 b=state[bid];out=r/('ops/codex-ops/learner/'+bid+'.out');report=b.get('report') or read_report(str(out));assert report and b['rc']==0;folder=Path(report['report']).parent;folders[bid]=folder;wt=Path(b['worktree']) if b.get('worktree') else r
 native=runtime(bid,report,out.read_text(),worktree=wt)
 rec=dict(batch=bid,canonical_state=b['state'],rc=b['rc'],merged=b.get('merged'),original_report=report,native=native,report=ref(folder/'report.md'))
 if bid=='20261016-074303-fix-batch':
  assert b['state']=='failed' and report['fixes']==[] and report['merged'] is None and report['tests']==dict(tsc=0,vitest=0,cases=38,files=10,scope='targeted')
  assert (folder/'tsc.exit').read_text().strip()==(folder/'targeted.exit').read_text().strip()=='0'
  assert git('rev-parse','HEAD',cwd=wt).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=wt).strip();audit=load(folder/'audit.json');assert audit['no_new_commit'] and not audit['actual_merge_performed_by_this_task'];rec['audit']=ref(folder/'audit.json');rec['scope']='No source, no merge or new release. Ten files38 targeted checks only, not a full suite.'
 elif bid=='20261016-074303-strategy-proposal':
  assert b['state']=='done' and report['fixes']==[] and report['tests']==dict(tsc=None,vitest=None,cases=None) and all(x['state']=='waiting' for x in report['proposal_results'])
  assert git('rev-parse','HEAD',cwd=wt).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=wt).strip();checks=load(folder/'material-checks.json');assert len(checks)==42 and all(x['passed'] for x in checks);rec['scope']='Six own-character runs6995 rows, six bounded offline audit consumers/42 material checks only; ten waiting, full-candidate certification0; no production tests/source/merge/version.'
 elif bid=='20261016-071301-strategy-proposal':
  assert b['state']=='failed' and len(report['fixes'])==1 and all(x['state']=='waiting' for x in report['proposal_results']);rec['scope']='Source1698 six audit leaves now narrowly integrated, original failed/rc0/mergednull, six conflicts and all ten waiting preserved; new exact-tree host pending.'
 else:
  assert b['state']=='done' and report['appended']==['DHYFWEN40SJ7'] and not report['ledger']['added'] and all(not x.get('new') for x in report['bugs']);rec['scope']='Five existing evidence entries, one existing0332 repeat, five proposal trace links; no new pure bug, no behavior/experience implementation claim.'
 readbacks.append(rec)
write(pub/'batch-readbacks.json',readbacks)
# Source artifacts and all failed initial probes remain immutable, bounded here; raw gameplay remains at original paths/SHA.
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for bid,folder in folders.items():
  for f in sorted(folder.iterdir()):
   if f.is_file() and f.stat().st_size<250_000 and f.suffix in ['.json','.jsonl','.log','.md','.txt','.exit','.err','.patch','.diff','.py','.sh']:
    tar.add(f,arcname=bid+'/'+f.name,recursive=False);manifest.append(ref(f))
  for f in [r/('ops/codex-ops/learner/'+bid+'.out'),r/('ops/codex-ops/learner/'+bid+'.err')]:tar.add(f,arcname=bid+'/'+f.name,recursive=False);manifest.append(ref(f))
write(pub/'original-artifact-manifest.json',manifest)
# Close the old route publication's exact-tree host only. Its successful result does not cover source1698's new tree.
old='20261016-064301-s2-strategy-proposal';h=state[old]['fallback_checks'];assert len(h)==1;h=h[0];assert h['rc']==0 and h['merged']=='098fbea4b753b9786d4da84072dac574d0975a37' and h['tree']=='a850673f6d41fbeb7ebded9b5fa379ff28cafb67' and h['commits']==['7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a']
f=Path(h['log']);text=re.sub(r'\x1b\[[0-9;]*m','',f.read_text());assert re.search(r'Test Files\s+490 passed',text) and re.search(r'Tests\s+4921 passed\s*\|\s*2 skipped',text)
with tarfile.open(pub/'route-host-original.tar.gz','w:gz') as tar:tar.add(f,arcname=f.name,recursive=False)
write(pub/'route-host-closure.json',dict(at=at,batch=old,source=h['commits'][0],live=h['merged'],tree=h['tree'],tsc_exit=0,vitest_full_exit=0,files=490,passed=4921,skipped=2,duration_seconds=726.57,original_log=ref(f),original_report_state_preserved=True,repeated_checks=0,new_source1698_full='not covered; its own original request remains pending',natural_projection_consumer='pending next natural matched journal readback'))
f=r/'ops/codex-ops/pending-integrations/20261016-064301-route-provenance.json';v=load(f);v.update(at=at,host_result='complete exacta850673f tsc0/vitest0,490files4921pass2skip',host_receipt='paper/materials/20261016-0805-ops/route-host-closure.json',state='narrow three-leaf deployment and exact-tree host complete; next natural projection consumer pending');write(f,v)
# Exact original ledger rows only: source44, no-source strategy26 and DHY10. Exclude active new G1a/G4 writes.
ledger=r/'paper/materials/learning/ledger.jsonl';rows=[];raws=[]
for bid,name,key in [('20261016-071301-strategy-proposal','ledger-all-readback.json','rows'),('20261016-074303-strategy-proposal','ledger-append-receipt.json','appended_rows')]:
 for entry in load(folders[bid]/name)[key]:
  with ledger.open('rb') as f:f.seek(entry['offset']);raw=f.read(entry['bytes'])
  assert sha(raw)==entry['sha256'];val=json.loads(raw);assert val['op']=='update' and set(val)<=set(['op','id','ts','by','where','note']);rows.append(dict(batch=bid,id=val['id'],offset=entry['offset'],bytes=len(raw),sha256=sha(raw)));raws.append((entry['offset'],raw))
assert len(rows)==70
folder=folders['20261016-074302'];offset=0;count=0;allowed={'silent-0023','silent-0027','silent-0028','silent-0046','silent-0332'}
with ledger.open('rb') as f:
 for raw in f:
  val=json.loads(raw);where=val.get('where',{});post=val.get('by')=='learner:postmortem' and val.get('id') in allowed and (where.get('lessons')==['DHYFWEN40SJ7'] or any(str(folder) in x for x in where.get('proposal',[])))
  if post:
   assert val['op']=='update' and not any(k in val for k in ['claim','status','version','first_run','prior','asc']);count+=1;rows.append(dict(batch='20261016-074302',id=val['id'],offset=offset,bytes=len(raw),sha256=sha(raw)));raws.append((offset,raw))
  offset+=len(raw)
assert count==10 and len(rows)==80 and len(set(x['offset'] for x in rows))==80
raws.sort();(p/'ledger-original-rows.jsonl').write_bytes(b''.join(raw for _,raw in raws));write(pub/'ledger-original-row-readback.json',dict(rows=sorted(rows,key=lambda x:x['offset']),source_provenance_rows=44,other_strategy_provenance_rows=26,postmortem_rows=10,postmortem_support=4,postmortem_existing_bug_repeat=1,proposal_trace_rows=5,new_add_rows=0,old_claim_status_first_prior_version_unchanged=True,active_G1a_G4_rows_excluded=True))
# Postmortem original bytes, fixed extraction SHA, and bounded exact resource endpoints. Do not rewrite the lesson or infer missing mechanisms.
manifest=load(folder/'inputs-manifest.json');assert manifest['run']=='DHYFWEN40SJ7'
for entry in manifest['files']:
 f=Path(entry['path']);assert f.stat().st_size==entry['bytes'] and sha(f.read_bytes())==entry['sha256']
before=load(folder/'append-before.json');lesson=(r/'notes/lessons.md').read_bytes();draft=(folder/'lesson-draft.md').read_bytes();assert sha(lesson[:before['bytes']])==before['sha256'] and lesson[before['bytes']:before['bytes']+len(draft)]==draft and lesson.count(b'\n## DHYFWEN40SJ7')==1
(p/'lesson-original-section.md').write_bytes(draft);resources=load(folder/'DHYFWEN40SJ7-resources.json');wanted={420959,420960}
for c in resources['combats']:
 for v in [c['entry'],c['exit'] or c['last']]:wanted.add(v['line'])
selected={}
with (folder/'states.jsonl').open() as f:
 for line in f:
  v=json.loads(line)
  if v['_line'] in wanted:selected[v['_line']]=v['state']
assert len(resources['combats'])==24
for c in resources['combats']:
 for v in [c['entry'],c['exit'] or c['last']]:
  st=selected[v['line']];assert st['run_id']=='DHYFWEN40SJ7' and st['run']['character_id'].lower()=='silent' and st['run']['current_hp']==v['hp'] and st['run']['max_hp']==v['max_hp'] and st['turn']==v['turn']
assert selected[420959]['combat']['player']['current_hp']==7 and selected[420960]['combat']['player']['current_hp']==0
write(pub/'postmortem-ownership-readback.json',dict(at=at,run='DHYFWEN40SJ7',original_section_offset=before['bytes'],original_section_bytes=len(draft),original_section_sha256=sha(draft),old_prefix_sha256=before['sha256'],single_section=True,extraction_manifest=ref(folder/'inputs-manifest.json'),all_manifest_files_size_sha_verified=True,bounded_combat_entry_exit_checks=24,new_pure_bug=False,existing_bug='silent-0332 / original5aa2672 chain, six groups corroborate previous module alert; resources/steps and root cause remain unknown',proposals=['silent-proposal-95d54f401bd95836','silent-proposal-b02a70a29a4ff6b1'],automatic_proposal_chain_only=True,additional_dispatches=0,active_G1a_G4_inputs_untouched=True))
# Personally read the watcher-origin limited objection. No learner notice/parent/ACK is fabricated and no S switch is changed.
g=r/'paper/materials/20261016-global-build-g1b';report=g/'report.md';notice=g/'objection-dual-notice.txt';assert sha(report.read_bytes())=='117edc6fa118a42863c136afc8a5959709bc32bae6c4b0369478b4b3947a1a36'
assert notice.read_bytes() in (r/'notes/for-roy.md').read_bytes() and notice.read_bytes() in (r/'ops/inbox-dev.md').read_bytes();send=load(g/'ops-objection-send.json');assert send['rc']==0 and send['report_sha256']==sha(report.read_bytes())
for f in ['analysis.json','analysis-initial.json','terminal-sensitivity.json','numerical-check.json','preregistration.md','inputs/manifest.json']:assert (g/f).is_file()
receipt=dict(at=at,parent='roy-20261016-global-build',stage='G1b-limited-objection',actor='ops',status='received',watcher_owner='01a13dcd-83d4-7c63-b233-f93cf878ecf4',evidence=[ref(report),ref(notice),ref(g/'ops-objection-send.json'),ref(g/'inputs/manifest.json'),ref(g/'terminal-sensitivity.json'),ref(g/'numerical-check.json')],interpretation='No incremental S predictive power demonstrated in this fixed/censored small sample; not proof S is ineffective. B2 has6actual won/5predicted-death SL stops, not five actual deaths. B3 secondary observational outcomes do not identify counterfactual benefit.',recommendation_received='Only P2/P3 S ranking key to shadow; retain probability/P1/C2. Roy decision required before any behavior change.',Roy_decision='pending',rollback_performed=False,new_models_experiments_or_full_checks=0,other_actor_ACK_calls=0,phase_or_parent_closed=False)
write(g/'ops-received.json',receipt);write(pub/'g1b-ops-received.json',receipt)
with tarfile.open(pub/'g1b-original-report-reference.tar.gz','w:gz') as tar:
 for f in [report,notice,g/'ops-objection-send.json',g/'terminal-sensitivity.json',g/'numerical-check.json',g/'preregistration.md',g/'inputs/manifest.json']:tar.add(f,arcname=str(f.relative_to(g)),recursive=False)
print(json.dumps(dict(batch_readbacks=4,route_host='exacta850 full0,4921pass2skip',ledger_owned_rows=80,postmortem_original_section=len(draft),source1698='published, new host pending',g1b_objection='personally received; S unchanged pending Roy')))

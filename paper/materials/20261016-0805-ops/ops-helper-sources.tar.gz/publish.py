from pathlib import Path
import fcntl, hashlib, json, os, re, subprocess, tarfile

r = root = Path.cwd()
live = r / '.worktrees/live'
p = r / 'ops/codex-ops/record-staging/20261016-0805'
pub = r / 'paper/materials/20261016-0805-ops'
pub.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = '1698adc96ba434a46942321e0237b70657e625b2'
base = '7da6f7693325878a4b59113d630d219316a7f64a'
template = (r / 'ops/codex-ops/record-staging/20261016-0240/publish.py').read_text()
exec(template[template.index('def git('):template.index('assert not (pub/')].replace('.ops-poison.tmp', '.ops-feature-root.tmp'))
def write(file, value): file.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
bid = '20261016-071301-strategy-proposal'
batch = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = batch['report']; scratch = Path(report['report']).parent; wt = Path(batch['worktree'])
checks = json.loads((scratch / 'tests-summary.json').read_text())
assert checks['tsc'] == checks['vitest'] == checks['script_exit'] == checks['gitleaks'] == 0
assert checks['cases'] == 4113 and checks['files'] == 438
assert checks['source_removed'] == dict(exit=1,failed=3,passed=6) and checks['source_restored'] == dict(exit=0,passed=9)
assert sha((scratch / 'sandbox-tests.log').read_bytes()) == checks['sandbox_log_sha256']
assert json.loads((scratch / 'material-checks.json').read_text())['passed'] == 41
assert report['tests'] == dict(tsc=0,vitest=0,cases=4113)
assert git('rev-parse', 'HEAD', cwd=wt).decode().strip() == source and not git('status', '--porcelain', '--untracked-files=no', cwd=wt).strip()
assert batch['rc'] == 0 and batch['merged'] is None and batch['state'] == 'failed'
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
exec((r / 'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text())
out = r / ('ops/codex-ops/learner/' + bid + '.out')
native = runtime(bid, report, out.read_text(), worktree=wt)
paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', source).decode().splitlines()
assert set(paths) == {'agent/src/reflex/combat-plan.ts','agent/src/reflex/rollout-live.ts','agent/src/reflex/silent-sl-resource-comparison.ts','agent/src/reflex/turn-solver.ts','agent/tests/silent-sl-prism-resource-evidence.json','agent/tests/silent-sl-resource-comparison.test.ts'}
conflicts = json.loads((scratch / 'live-merge-result.json').read_text())
assert conflicts['abort_exit']==0 and len(conflicts['conflicts'])==6 and conflicts['merged'] is None and conflicts['live_after_failed_merge']==conflicts['pre_merge']
write(pub / 'source-readback.json', dict(batch=bid, source=source, source_parent=base, source_checks=checks, native=native, original_failed_state_preserved=True, original_merge_result=conflicts, original_report=report, source_paths=paths, classification='Silent A10 SL resource comparison audit metadata only: saturation, play-time Tainted and modeled post-turn poison; keep unknowns and potion-median boundaries. Existing choice, ranking and dispatch unchanged; noEffectTwin excludes the added audit metadata. All ten wider proposals remain waiting; no new game behavior release.'))
assert not (pub / 'publication.json').exists()
with (r / 'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    print(at, flush=True)
    mh = git('rev-parse', 'HEAD').decode().strip()
    lh = git('rev-parse', 'HEAD', cwd=live).decode().strip()
    assert lh == '098fbea4b753b9786d4da84072dac574d0975a37'
    assert not git('diff','--name-only','HEAD','--','knowledge',cwd=live).strip()
    active = subprocess.run(['pgrep', '-f', '/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'], capture_output=True)
    assert active.returncode == 1
    for cwd in [r, live]: assert not git('diff', '--cached', '--name-only', cwd=cwd).strip() and not git('ls-files', '-u', cwd=cwd).strip()
    before = {}
    for cwd in [r, live]:
        before[str(cwd)] = {x: sha((cwd / x).read_bytes()) for x in git('diff', '--name-only', 'HEAD', cwd=cwd).decode().splitlines() if x not in paths}
    values = {}
    livevalues = {}
    preserved_difference = None
    for path in paths:
        old = blob(base, path)
        raw = blob(source, path)
        oldlive = blob(lh, path, live)
        assert blob(mh, path) == old, path
        for cwd, prior in [(r, old), (live, oldlive)]: assert ((cwd / path).read_bytes() if (cwd / path).exists() else None) == prior, path
        values[path] = raw
        if oldlive == old:
            livevalues[path] = raw
        else:
            assert path == 'agent/src/reflex/rollout-live.ts' and oldlive.replace(b'Dai',b'Roy') == old.replace(b'Dai',b'Roy')
            merge = p / 'merge-input'; merge.mkdir(exist_ok=True)
            for name,content in [('live',oldlive),('base',old),('source',raw)]: (merge/name).write_bytes(content)
            result = subprocess.run(['git','merge-file','--stdout',str(merge/'live'),str(merge/'base'),str(merge/'source')],capture_output=True)
            assert result.returncode == 0 and result.stdout.replace(b'Dai',b'Roy') == raw.replace(b'Dai',b'Roy')
            livevalues[path] = result.stdout
            preserved_difference = dict(path=path,classification='Preserve the existing five Dai/Roy historical comment differences; all non-comment source bytes equal.',old_main_sha256=sha(old),old_live_sha256=sha(oldlive),source_sha256=sha(raw),live_sha256=sha(result.stdout),three_way_merge_clean=True)
        for lane, content in [('main', raw), ('live', livevalues[path])]:
            scan = p / 'source-scan' / lane / path
            scan.parent.mkdir(parents=True, exist_ok=True)
            scan.write_bytes(content)
    with (pub / 'source-composition-gitleaks.log').open('wb') as outscan:
        scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', str(p / 'source-scan'), '--redact', '--no-banner', '--report-format', 'json', '--report-path', str(p / 'source-gitleaks.json')], stdout=outscan, stderr=subprocess.STDOUT, env={**os.environ, 'GOMAXPROCS': '1'})
    assert scan.returncode == 0 and json.loads((p / 'source-gitleaks.json').read_text()) == []
    staged = []
    for cwd, head, label in [(r, mh, 'main'), (live, lh, 'live')]:
        env = {**os.environ, 'GIT_INDEX_FILE': str(p / (label + '.index'))}
        git('read-tree', head, env=env, cwd=cwd)
        for path, raw in (values if cwd == r else livevalues).items(): stage(path, raw, env, cwd)
        tree = git('write-tree', env=env, cwd=cwd).decode().strip()
        assert set(git('diff', '--name-only', head, tree, cwd=cwd).decode().splitlines()) == set(paths)
        new = commit(tree, [head, source], 'Integrate Silent SL resource audit metadata', cwd)
        staged.append((cwd, head, env, new, tree))
    locks = locks_for([(x[0], x[2]) for x in staged])
    try:
        for cwd, head, env, new, tree in staged:
            assert git('rev-parse', 'HEAD', cwd=cwd).decode().strip() == head
            assert all(sha((cwd / path).read_bytes()) == value for path, value in before[str(cwd)].items())
        for cwd, head, env, new, tree in staged:
            git('update-ref', '-m', 'ops: exact six-leaf SL-resource audit fallback', 'HEAD', new, head, cwd=cwd)
            for path, raw in (values if cwd == r else livevalues).items(): install(cwd, path, raw)
        for index, lp in locks: os.replace(lp, index)
    finally:
        for _, lp in locks:
            if lp.exists(): lp.unlink()
    for cwd, head, env, new, tree in staged:
        assert not git('diff', '--cached', '--name-only', cwd=cwd).strip()
        git('merge-base', '--is-ancestor', source, 'HEAD', cwd=cwd)
        assert blob(head, 'eval/versions.json', cwd) == blob(new, 'eval/versions.json', cwd)
        assert all(sha((cwd / path).read_bytes()) == value for path, value in before[str(cwd)].items())
    rec = dict(at=at, batch=bid, source=source, source_parent=base, old_main=mh, main=staged[0][3], old_live=lh, live=staged[1][3], tree=staged[1][4], source_paths=[dict(path=path, source_sha256=sha(raw), live_sha256=sha(livevalues[path])) for path, raw in values.items()], preserved_existing_script_difference=preserved_difference, source_actual_main_live_ancestor=True, unrelated_dirty_preserved=before, source_checks=checks, original_merge_conflicts_preserved=conflicts, release_id=None, release_increment=False, existing_behavior_release='V5-R366 unchanged', game_decision_behavior_or_account_home_model_prompt_changed=False, host='pending single original071301-strategy-proposal request')
    write(pub / 'publication.json', rec)
    print(json.dumps({k: rec[k] for k in ['main', 'live', 'tree', 'release_id', 'source_actual_main_live_ancestor']}), flush=True)

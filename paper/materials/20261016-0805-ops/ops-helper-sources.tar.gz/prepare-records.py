from pathlib import Path
import hashlib,json,subprocess,tarfile,sys
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0805';pub=r/'paper/materials/20261016-0805-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
assert (p/'paper-dataset.exit').read_text().strip()=='0'
assert not (p/'own-appends.json').exists();x=load(pub/'publication.json');base=git('rev-parse','HEAD').decode().strip();git('merge-base','--is-ancestor',x['main'],base);assert not git('diff','--cached','--name-only').strip();assert not git('diff','--name-only',x['main'],base,'--','agent','knowledge','eval/versions.json').strip()
assert load(pub/'route-host-closure.json')['passed']==4921
paperlog=(pub/'paper-dataset.log').read_text();summary=load(r/'paper/data/summary.json');assert summary['source_checks_passed'] is True and 'key scan: CLEAN' in paperlog
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
hlog=r/('ops/codex-ops/learner/'+x['batch']+'.fallback-'+x['tree']+'.checks.log');assert hlog.exists();raw=hlog.read_bytes();(pub/'host-start-log-prefix.txt').write_bytes(raw)
host=dict(at=at,batch=x['batch'],source=x['source'],live=x['live'],tree=x['tree'],requested_once=True,command='bash ops/codex-ops-do.sh learner-recheck '+x['batch'],original_log=str(hlog.relative_to(r)),start_prefix=ref(pub/'host-start-log-prefix.txt'),vitest_RUN_observed=b'RUN' in raw,full_exit=None,stage='running original unique new-tree host, await learner-checks event; no borrowed a850 pass',source_full_not_repeated=True)
write(pub/'host-start-receipt.json',host)
write(r/'ops/codex-ops/pending-integrations/20261016-071301-sl-resource-audit.json',dict(at=at,batch=x['batch'],source=x['source'],main=x['main'],live=x['live'],tree=x['tree'],source_paths=6,merge='complete narrow diagnostic leaves; historical rollout-live comments preserved',release='V5-R366 unchanged, no new game decision behavior',host='single original exact-tree check running',host_receipt='paper/materials/20261016-0805-ops/host-start-receipt.json',natural_consumer='pending next naturally matching Silent A10 SL audit journal; do not restart current game',wide_proposals='all ten source-batch proposals waiting; no wide-parent closure',publication_receipt='paper/materials/20261016-0805-ops/publication.json'))
# Only the outputs of this one successful no-raw invocation, saved before any future producer changes them.
values={};data_entries=[];before=load(p/'paper-before-manifest.json')
for entry in before:
 path=entry['path'];f=r/path;raw=f.read_bytes()
 if sha(raw)!=entry['sha256']:
  values[path]=raw;data_entries.append(ref(f))
assert any(e['path']=='paper/data/summary.json' for e in data_entries)
write(pub/'paper-refresh-snapshot.json',dict(at=at,command='nice -n19 python3 ops/paper_dataset.py --no-raw',exit=0,once_only=True,original_log=ref(pub/'paper-dataset.log'),summary_source_checks_passed=True,summary_fields={k:summary.get(k) for k in ['generated_at','source_cut_bytes','runs_total','runs_finished','runs_in_runs_jsonl','source_checks_passed','decisions']},outputs=data_entries,before=before,before_bytes_preserved_under='ops/codex-ops/record-staging/20261016-0805/paper-before',no_raw_snapshot=True,verification=load(r/'paper/data/verification.json'),decision_count_mismatch='KF9HMZKTFC3V logged879 versus dataset880; original reported discrepancy retained, not silently normalized'))
# Original 80 CLI rows are already physically present; stage them without adding active G1a/G4 writes.
ledger='paper/materials/learning/ledger.jsonl';old=git('show',base+':'+ledger);rows=(p/'ledger-original-rows.jsonl').read_bytes().splitlines(keepends=True);assert len(rows)==80 and all(old.count(row)==0 for row in rows);new=old+b''.join(rows);values[ledger]=new
sys.path.insert(0,str(r));from learner.ledger import fold
parse=lambda raw:[(i,json.loads(line)) for i,line in enumerate(raw.splitlines(),1) if line.strip()]
a=fold(parse(old));b=fold(parse(new));assert set(a)==set(b)
protected=lambda item:{k:v for k,v in item.items() if k not in ['where','notes','history','evidence']};assert all(protected(a[k])==protected(b[k]) for k in a)
additions=[e for row in rows for e in json.loads(row).get('evidence',[])];assert len(additions)==5 and sum(e['role']=='support' for e in additions)==4 and sum(e['role']=='repeat' for e in additions)==1 and all(e['run']=='DHYFWEN40SJ7' for e in additions)
write(pub/'ledger-final-check.json',dict(original_rows_staged=80,trace_only_rows=75,postmortem_new_evidence=5,support4_repeat1=True,all_ids_and_protected_fields_equal=True,no_CLI_repeats_or_status_shipped_changes=True,other_active_learning_rows_excluded=True,physical_ledger_not_rewritten=True))
lesson='notes/lessons.md';draft=(p/'lesson-original-section.md').read_bytes();oldlesson=git('show',base+':'+lesson);assert b'\n## DHYFWEN40SJ7' not in oldlesson and draft in (r/lesson).read_bytes();values[lesson]=oldlesson+draft
note=f'\n- {at} [ops 0805五事件与G1b接收] 原route source7c43/live098fbea4/treea850673f完整宿主tsc0/vitest0、490文件4921过2跳/726.57s实核，关闭其host pending、自然projection读回仍pending，不重复旧树检查。原074303-fix无新增源码、WT fcdbf6c3干净、10文件38定向/tsc0，只核已修窄子项和30原未修/宽项，canonical failed/rc0/mergednull保持，不当full或新合入。原074303策略六局6995行、六有界消费者/42材料检查、26原where-note行，十项waiting/无源码/tests null，不冒整候选认证。原071301 source1698adc96ba434a46942321e0237b70657e625b2已6叶窄差main{x["main"]}/live{x["live"]}/tree{x["tree"]}，SL资源比较只加饱和/污染新增与轮末毒层日志，原选择/排序/派发不变，rollout-live五处Dai/Roy历史注释和并行记录/知识精确保留；438文件4113源全0/撤3红恢复9绿/148相关绿实核不重跑，原两次锁拒绝/六记录冲突/abort0及failed/rc0/mergednull保持，十宽提案仍waiting、44原trace行只来源。未加行为号，V5-R366不变；原071301唯一新树宿主已启动/结果pending，不能借a850绿。DHY复盘原24342字节追加/旧前缀及24战斗端点核，10所属CLI原行（4support/0332一repeat/5提案关联）精确纳入，0332六组异常只沿原5aa2672及b02a70补证，完整resources/steps与根因仍未知、不新bug/重派或热改在跑G1a/G4输入；95d54与b02a70两原CLI pending提案沿自动链。论文仅一次--no-raw exit0、固定截点/校验/成本与keyscan CLEAN，KF9HMZKTFC3V原记录879/表880一项差异保持不归零，输出SHA留盘。G1b本人已读report117edc6f/dual notice与删失限制：未证明S增量不等于已证无效，B2六真实won加五预测停止不能叫真实败；仅S键shadow是建议，Roy决定pending，P2/P3/P1/C2/胜率及当前配置未改。已落G1b ops-received，向原watcher回传被Herdr agent_blocked/requires interactive input拒绝，原失败/actual pending留盘，不绕交互、不代watcher或Roy ACK、不另模型/实验/重跑G1c full。只提交所属记录/生成表/复盘/80原台账行，当前局/home账号模型权限prompt预算不动，资料paper/materials/20261016-0805-ops/。\n'
decision=f'\n- {at} 运维codex：0805五事件分别核实：route精确a850/source7c43完整host490文件4921过2跳、tsc/vitest0结案，不重复检查；新source1698 SL资源诊断6叶窄差main{x["main"]}/live{x["live"]}/tree{x["tree"]}保五处历史注释、所有知识及并行记录，原438/4113/红3绿9/148相关/扫描0实核不重跑，原两次锁75/六记录冲突/abort0/failed-rc0-mergednull不改。纯审计元数据不改选择排序/SL规则、无新行为号，V5-R366保持；其唯一原071301新树host RUN待事件，不借旧a850绿，匹配自然日志消费者pending。074303-fix无源码、38定向绿不冒full；074303策略6995原行/六限定离线/42材料检查、十waiting无源码，071301另十waiting继续。DHY原复盘24342字节/24战斗端点/旧前缀实核，既有0332六组只补原根链、根因与完整资源未知；2新提案只走自动链，4support+1旧bug repeat+5提案trace和两策略70trace共80原CLI行精确纳入、不重CLI/改旧claim/status/首证/prior/version，排除在跑G1a/G4新条目。原论文--no-raw仅一次退出0并冻结输出/原截点，五源校验及cost/keyscan通过；KF9HMZKTFC3V原记录879/数据表880的1条计数差异原样保留，不称差异为空。额外本人接收G1b限定异议report117edc6f：未证明增量不等S无效，原删失/小样本/反事实限制保持；S建议仅排序键退shadow仍待Roy决定，没有配置/回滚或实验动作。原watcher等待交互，Herdr回传agent_blocked原错误与pending保留，未强送/伪ACK；G1c原full与当前局、模型home账号权限prompt预算、0332等宽父不动。回执paper/materials/20261016-0805-ops/，G1b ops本人received在原阶段目录；私有postmortem启动batch字段旧假设失败和stderr渠道解析失败保原件，按真实lease/header及stderr事实修正，非产品失败。\n'
queue=f'\n- {at} [原0332/5aa2672 DHY复盘补证；诊断窄接线] DHYFWEN40SJ7复盘正式完成，旧0332六组F48 nonpositive-hp只补原链及新b02a70a29a4ff6b1来源，完整异常resources/steps、截断和机制根因仍未知；已有0647 alert三组不重复造修复/学习父，不热改G1a/G4或其他在跑输入。原071301 aff5ac source1698adc96六SL资源审计叶现实际live{x["live"]}/tree{x["tree"]}，只日志、V5-R366不变；源438/4113绿，原六冲突/旧失败保留，新树唯一host pending、自然消费者pending。旧route source7c43精确a850完整4921过2跳已核0，十宽提案与资源契约不因此关闭。原074303-fix无新纯bug/源码，30未修/宽项保持；论文/80原台账行及DHY原文详paper/materials/20261016-0805-ops/。\n'
handoff=f'\n- {at} 0805后继：route source7c43/live098fbea4/treea850完整host0（490文件4921过2跳）已关host pending，自然projection仍待。source1698adc96仅6审计叶已main{x["main"]}/live{x["live"]}/tree{x["tree"]}，历史rollout-live五处Dai/Roy及知识/脏记录保持、V5-R366同；原唯一071301 learner-recheck已RUN，后继只接精确d570b257结果，不重复源438/4113或旧a850，不借绿/重启。两原策略20waiting保持，074303-fix无源码仅38定向绿；DHY原24342字节与10CLI/2提案、两策略70trace共80行及一次论文exit0收尾，无新纯bug，0332六组沿原根仍未知。G1b本人已读report117edc6f并落原阶段ops-received/ops-transfer-record；原watcher原生回传agent_blocked需交互、留pending-deliveries/global-build-g1b-ops-readback.json，不强绕/另建会话或代ACK。S去留仍Roy决定，未改P2/P3的S键/P1/C2/胜率/当前对局账号home模型权限prompt预算；G1c原full不重派。G1a/G4原运行输入与宽父保持，所有回执paper/materials/20261016-0805-ops/。\n'
appends={'ops/inbox-dev.md':note,'notes/for-roy.md':note,'paper/materials/decision-log.md':decision,'notes/fix-queue-v4.md':queue,'notes/ops-handoff.md':handoff};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
 values[path]=git('show',base+':'+path)+text.encode()
for path in ['paper/materials/20261016-0738-ops/host-recheck-request.log','paper/materials/20261016-global-build-g1b/ops-received.json','paper/materials/20261016-global-build-g1b/ops-transfer-record.json']:values[path]=(r/path).read_bytes()
write(pub/'record-registration.json',dict(at=at,base=base,source1698_actual_live=x['live'],tree=x['tree'],source_paths=6,behavior_release_increment=False,existing_release='V5-R366',route_host='exacta850 full0',new_host='running original071301; no result inferred',postmortem='original DHY section plus ten original CLI rows',total_original_CLI_rows=80,paper='single no-raw exit0',G1b='ops personally received; original watcher transfer blocked, Roy decision pending; no S change',new_learning_or_model_dispatches=0,other_actor_ACK_calls=0,wide_parents='remain open'))
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 helpers=[]
 for f in sorted(p.glob('*.py')):tar.add(f,arcname=f.name,recursive=False);helpers.append(ref(f))
write(pub/'ops-helper-manifest.json',helpers)
with tarfile.open(pub/'ops-attempt-logs.tar.gz','w:gz') as tar:
 for name in ['publish.log','readback-first-postmortem-batch-assertion.log','readback.log','notify-g1b.log']:
  f=p/name;tar.add(f,arcname=name,recursive=False)
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
values={path:raw for path,raw in values.items() if subprocess.run(['git','show',base+':'+path],capture_output=True).stdout!=raw or subprocess.run(['git','cat-file','-e',base+':'+path],capture_output=True).returncode!=0}
dest=p/'final-files';entries=[]
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
scan=p/'archive-scan';scan.mkdir(exist_ok=True)
for f in pub.glob('*.tar.gz'):
 out=scan/f.stem;out.mkdir(exist_ok=True)
 with tarfile.open(f) as tar:
  assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in tar.getmembers());tar.extractall(out,filter='data')
print(json.dumps(dict(record_paths=len(entries),original_ledger_rows=80,data_outputs=len(data_entries),host='new tree pending',G1b='received, return transport blocked, S unchanged')))

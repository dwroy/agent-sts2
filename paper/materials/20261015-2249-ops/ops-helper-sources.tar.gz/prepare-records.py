from pathlib import Path
import fcntl, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile

root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2249'; pub=r/'paper/materials/20261015-2249-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(path): return json.loads(path.read_text())
def write(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=r): return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
assert not (p/'own-appends.json').exists()
base=git('rev-parse','HEAD').decode().strip(); d=load(pub/'publication.json')
assert base==d['main'] and not git('diff','--cached','--name-only').strip()
bid='20261015-224302-fix-batch'; b=load(r/'ops/codex-ops/learn.json')['batches'][bid]; report=b['report']; s=Path(report['report']).parent
assert b['state']=='failed' and b['rc']==0 and report['merged'] is None
assert report['fixes']==report['code_proposals']==report['implementation_domains']==[]
assert report['tests']=={'tsc':0,'vitest':0,'cases':55}
manifest=load(s/'artifact-manifest.json')
for name,row in manifest.items():
 raw=(s/name).read_bytes(); assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert (s/'source.diff').stat().st_size==(s/'final-status.txt').stat().st_size==0
assert (s/'tsc.exit').read_text().strip()==(s/'targeted.exit').read_text().strip()=='0'
assert '8 passed (8)' in (s/'targeted.log').read_text() and '55 passed (55)' in (s/'targeted.log').read_text()
a=load(s/'audit.json'); assert a['base']==report['base'] and a['unchecked_entries']==41 and a['unchecked_entries_unchanged'] and a['queue_only_appended']
assert len(a['existing_fixes'])==73 and not a['changed_source_paths_from_prior_audit']
assert sha(Path(a['prior_audit']).read_bytes())==a['prior_audit_sha256']
for x in a['existing_fixes']:
 assert x['same_as_prior_audit'] and x['same_as_committed_base'] and x['ancestor_in_base'] and x['ancestor_in_live']
 assert sha(git('show',report['base']+':'+x['path']))==x['current_source_sha256']
 for target in [report['base'],a['live_read_only_snapshot']]: git('merge-base','--is-ancestor',x['source_commit'],target)
 present=subprocess.run(['git','cat-file','-e',a['live_read_only_snapshot']+':'+x['path']],capture_output=True).returncode==0
 assert present==x['live_leaf_present']
 if present: assert (sha(git('show',a['live_read_only_snapshot']+':'+x['path']))==x['current_source_sha256'])==x['same_source_in_live']
reg=a['registration_barrier']; assert reg['ancestor_in_base'] and not reg['ancestor_in_live']
for x in reg['files']:
 assert x['same_as_source'] and x['same_as_committed_base']
 for target in [reg['source_commit'],report['base'],d['actual_live']]: assert sha(git('show',target+':'+x['path']))==x['sha256']
git('merge-base','--is-ancestor',reg['source_commit'],d['actual_live'])
assert len(load(s/'queue-dispositions.json'))==41
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,canonical_state=b['state'],canonical_rc=b['rc'],native=native,artifact_manifest_verified=manifest,original_audit=a,original_tests_scope='tsc0 and eight selected Vitest files /55 cases0, no full-suite invocation or rerun',new_code_or_merge_blocker=False,old73_sources_pinned_sha_and_ancestry_verified=True,registration_old_main_only_snapshot_preserved=True,registration_now_actual_live_source=d['ops_live_commit'],wide_items_and_original_failures_preserved=True,original_source_lookup_failure='Initial ops lookup in worktree scratch failed; original report identifies root learner/runs scratch; original artifacts were read there without alteration.'))

at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
update={'id':'silent-0164','by':'ops:codex','where':{'commits':[d['source'],d['behavior_commit'],d['actual_live']]},'note':f'{at} {d["release_id"]}/{d["name"]}原e5ea36df结构披露窄子项已main/live真实祖先；仅Silent A10持有/买入耳环候选披露首轮接管未建模，能量数值照旧，内部动作顺序未知。XTSV1U9JD34T F47/F49T1固定帧23HP/16挡/3能/只余诅咒为接管后状态，不能推出耗尽能量/禁选或整战胜负。原红3绿7、源4088+paths11/tsc0与实际组合2文件8项0；新树一次原宿主已请求，结果及下一自然持有/买入消费者pending。仅补where/note，不改原claim/证据/状态/经验version或关闭宽父。回执paper/materials/20261015-2249-ops/。'}
ledger=r/'paper/materials/learning/ledger.jsonl'; before=ledger.stat().st_size; write(pub/'ledger-input.json',update)
result=subprocess.run(['python3','learner/ledger.py','update','--character','silent'],input=json.dumps(update,ensure_ascii=False)+'\n',capture_output=True,text=True)
(pub/'ledger-update.log').write_text(result.stdout+result.stderr); assert result.returncode==0
rows=[raw for raw in ledger.read_bytes()[before:].splitlines(keepends=True) if all(json.loads(raw).get(k)==v for k,v in update.items())]
assert len(rows)==1 and set(json.loads(rows[0]))<={'op','id','ts','by','where','note'}; (p/'owned-ops-ledger.jsonl').write_bytes(rows[0])
old=git('show',base+':paper/materials/learning/ledger.jsonl'); assert rows[0].rstrip(b'\n') not in old.splitlines()
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
fold=lambda raw:module.fold([(i,json.loads(line)) for i,line in enumerate(raw.splitlines(),1) if line]); oldfold=fold(old); newfold=fold(old+rows[0]); assert set(oldfold)==set(newfold)
for ident in oldfold:
 assert {k:v for k,v in oldfold[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in newfold[ident].items() if k not in ['where','history','notes']}
 assert newfold[ident]['history'][:len(oldfold[ident]['history'])]==oldfold[ident]['history']

sbid='20261015-214302-s2-strategy-proposal'; original=load(pub/'strategy-readback.json')['original_report']; follow=json.loads(json.dumps(original)); follow['merged']=d['actual_live']; follow['version']=d['release_id']; follow['ops_actual_publication']='paper/materials/20261015-2249-ops/publication.json'
for x in follow['proposal_results']:
 if x['id']=='silent-proposal-e5ea36df117ca9b7': x.update(state='implemented',commit=d['source'],reason=f'仅原结构披露子项实际live源祖先，登记{d["release_id"]}；内部接管动作顺序/整战校准未声称已知。源4099、实际组合8定向0；新树单次宿主及下一自然消费者pending。原冲突/failed/rc0/mergednull保留，其他九项waiting、宽父不关闭。')
write(pub/'ops-publication-followup.json',follow); sys.path.insert(0,str(r/'ops')); import proposal_dispatch
with (r/'ops/codex-ops/learn.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); state=load(r/'ops/codex-ops/learn.json'); batch=state['batches'][sbid]; ids=set(batch.get('proposal_ids',[])); assert ids
 owners=[key for key,v in state['batches'].items() if key!=sbid and v.get('state')=='running' and ids & set(v.get('proposal_ids',[]))]
 core={k:batch.get(k) for k in ['state','rc','merged','report','finished','pid']}
 if owners: status='mechanical resolution pending existing overlapping owner; no frozen input replaced'
 else:
  errors=proposal_dispatch.links(follow,batch,str(r),str(r/'ops')); assert errors==[],errors
  proposal_dispatch.resolve(follow,batch,str(r),str(r/'ops')); status='original proposal registry resolved through existing CLI module; one implemented / nine waiting'
 actual=load(r/'ops/codex-ops/learn.json')['batches'][sbid]; assert {k:actual.get(k) for k in core}==core
write(pub/'registration-followup.json',dict(at=at,ledger_cli_rows=1,only_where_note=True,old_status_experience_version_and_history_prefix_preserved=True,original_batch_completion_preserved=core,queue_stage=status,overlapping_running_owners=owners,new_learning_parent=False,other9proposals='waiting',natural_consumer='pending'))
pending=dict(at=at,bundle='20261015-2226-original-two-source-continuation',batches=['20261015-214302-fix-batch',sbid],sources=[d['ops_source'],d['source']],live_published=True,release_id=d['release_id'],main=d['main'],actual_live=d['actual_live'],tree=d['tree'],infrastructure_commit=d['ops_live_commit'],behavior_commit=d['behavior_commit'],knowledge_refresh=d['knowledge_refresh'],original_blockers_retained='original conflict and prior busy-builder/retention receipts unmodified',source_workspaces='retained until original check/retention gates; no cleanup model',host=load(pub/'new-host-request.json'),targeted=load(pub/'combined-targeted.json'),natural_consumers='pending next natural saved registration/lease and Silent A10 held/buy payload; no forced requests or restart',wide_parents='remain open')
write(pub/'pending-live-handoff.json',pending)
for key in pending['batches']: write(r/'ops/codex-ops/pending-integrations'/(key+'.json'),pending)
notice=f'\n- {at}｜规则实际上线 {d["release_id"]} / {d["name"]}：旧：静默A10耳环在B3只算能量，持有/买入题面未披露首轮自动接管未模拟。新：仅上述已观察角色/进阶的持有和买入候选明确能量已算、首轮接管及内部顺序未知；不新增游戏判断/禁选，不改模拟数值、合法候选、样本、排序、HP/SL/药价或其他角色。证据/账本：XTSV1U9JD34T F47及F49T1接管后稳定帧23HP/16挡/3能/只余诅咒，silent-0164/e5ea36df；不能由接管后帧反推内部顺序、耗尽能量或整战收益。source{d["source"]}，原撤码3失败4过、恢复7过，源完整434文件4088+paths11/tsc0；预期提高未建模边界可见性，不承诺胜率。实际behavior{d["behavior_commit"]}→live{d["actual_live"]}/tree{d["tree"]}，保10刷新知识、历史Dai/Roy文字及其他修复/并行记录。回退仅四源叶当前上下文逆补丁，保知识/其余发布。注册保存屏障source798af209三叶另以基础设施合入{d["ops_live_commit"]}，不另发行为号；不把历史ENOENT/null租约一律归因此竞态。新组合2文件8固定项0，原214302-fix单次宿主全检已请求、结果及自然注册/持有/买入消费者pending；原failed/rc0/mergednull、冲突/失败与九项waiting保留，不改当前局/账号home/模型/权限/prompt。回执paper/materials/20261015-2249-ops/。\n'
decision=f'\n- {at} 运维codex：2249原224302空fix核：failed/rc0/mergednull与fixes/proposals/domains空原样保持，无新增源码或合入阻塞；73既有源逐SHA/祖先核，旧live缺ops/worktree_storage.py叶的已知边界不冒同叶，41队列原处置沿原owner，0332完整resources/steps与根因未知/0481/0311/0469/0446宽父保持；原tsc0/8文件55定向0未跑full/无重跑，native Sol6.1/xhigh/input/lease/workspace-write/no-network核。接原2216/2226授权待办，锁内确认刷新已结束，保10知识原字节，注册3叶source798af实际live{d["ops_live_commit"]}、耳环4叶sourcea78bb实际发布{d["release_id"]}/behavior{d["behavior_commit"]}/live{d["actual_live"]}/tree{d["tree"]}，两source均main/live祖先、现有配置/战斗源保持；根双规则通知、0164 CLI仅追溯一行，其他九提案waiting。实际新组合2文件8固定项0，原214302单通道一次宿主full请求，不借源full或旧树绿；结果和自然消费者pending，不重跑源full/新派模型/重启对局/改账号权限prompt，不刷新论文。回执paper/materials/20261015-2249-ops/。\n'
handoff=f'\n- {at} 原两源live待办已实际兜底：798af注册3叶→{d["ops_live_commit"]}；a78bb耳环4叶→{d["release_id"]}/live{d["actual_live"]}/tree{d["tree"]}，10知识刷新独立保留，旧builder/retention/三方冲突失败回执不改。main/live真实源祖先，2文件8定向0；仅一次原214302-fix宿主请求，后继learner-checks核精确94a022树，不新请求或借旧树。下一自然注册保存/租约及Silent A10持有/买入题面消费者pending，保持当前局/所有账号模型/宽父，不人为开局或调用模型；两源WT沿原检查/retention门槛保留。当前224302无源码fix只归档，不空合/补测/再发号。回执paper/materials/20261015-2249-ops/。\n'
appends={'notes/for-roy.md':notice,'ops/inbox-dev.md':notice,'paper/materials/decision-log.md':decision,'notes/ops-handoff.md':handoff}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as handle: handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,new_fixes=0,original_empty_fix_state_preserved=True,continued_original_sources=[d['ops_source'],d['source']],actual_release=d['release_id'],actual_live=d['actual_live'],exact_tree=d['tree'],combined_targeted=dict(files=2,cases=8,exit=0),host_full='one original request; result pending',natural_consumers='pending',current_game_or_account_model_permissions_changed=False))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 for path in sorted([x for x in s.iterdir() if x.is_file()]+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]):
  raw=path.read_bytes(); rel=str(path.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(path,arcname=rel); artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for path in [p/'prepare-records.py',p/'seal-records.py',p/'publish.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=path.read_bytes(); copy=p/'helper-scan'/path.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(path,arcname=path.name); helpers.append(dict(path=str(path.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+rows[0]; dest=p/'final-files'
lp=dest/'paper/materials/learning/ledger.jsonl'; lp.parent.mkdir(parents=True,exist_ok=True); lp.write_bytes(values['paper/materials/learning/ledger.jsonl'])
check=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(lp)},capture_output=True); (pub/'final-ledger-check.log').write_bytes(check.stdout+check.stderr); assert check.returncode==0
for path in pub.iterdir():
 if path.is_file(): values[str(path.relative_to(r))]=path.read_bytes()
entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); print(json.dumps(dict(empty_fix_verified=True,source_publication=d['release_id'],ledger_rows=1,queue=status,paths=len(entries))))

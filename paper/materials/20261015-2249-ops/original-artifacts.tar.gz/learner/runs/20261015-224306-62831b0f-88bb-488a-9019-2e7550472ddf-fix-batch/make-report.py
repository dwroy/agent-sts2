import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WT = ROOT / '.worktrees/codex-fix-silent-20261015-224302'
OUT = ROOT / 'learner/runs/20261015-224306-62831b0f-88bb-488a-9019-2e7550472ddf-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-214306-c1fbbfac-f9e0-42d8-a5ef-51eedcffc4f9-fix-batch'
audit = json.loads((OUT / 'audit.json').read_text())
skipped = json.loads((PRIOR / 'skipped.json').read_text())
for row in skipped:
    if row['item'].startswith('sandbox-glob-startup-race'):
        row['reason'] = ('证据不足：父注册保存屏障已由上一批798af209b修复并进入本次main基线；'
                         '目录删除者、历史注册时序及其他租约拒绝原因仍未知，沿原链核实。'
                         '不将历史ENOENT/null租约全部归因于已修窄竞态，不越租约重放。')
result = dict(task='fix-batch', base=audit['base'], fixes=[], skipped=skipped,
              merged=None, tests=dict(tsc=0, vitest=0, cases=55),
              code_proposals=[], implementation_domains=[], report=str(OUT / 'report.md'))
assert (OUT / 'tsc.exit').read_text().strip() == '0'
assert (OUT / 'targeted.exit').read_text().strip() == '0'
assert 'Test Files  8 passed (8)' in (OUT / 'targeted.log').read_text()
assert 'Tests  55 passed (55)' in (OUT / 'targeted.log').read_text()
status = subprocess.check_output(['git', '-C', str(WT), 'status', '--porcelain'])
assert not status
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert hashlib.sha256(queue).hexdigest() == audit['queue_sha256']
lines = ['## 修 bug 回报', '',
         f"- 合并基线：main → {audit['base']}（开工工作区干净；git merge --no-edit main 返回 Already up to date）。",
         '- 修复（每条一行）：无新增修复；未改源码、测试、队列或账本，未提交。撤码失败/恢复通过验证不适用；本批未把旧修复计为新产出。']
for row in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['source_commit']}（本批重核当前源码SHA与上批相同、源为main/live祖先；只认原窄范围）。")
barrier = audit['registration_barrier']
lines.append(f"- 已被别人修掉的：{barrier['item']} — {barrier['source_commit']}（三个源码/测试叶与源提交相同，已是本次main祖先；尚非观察到的live祖先，沿原manual接续，未冒称已上线）。")
for row in skipped:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines += ['- 测试：tsc退出码0；Vitest定向8文件/55用例/退出码0，无重跑。命令为npx tsc -p tsconfig.json --noEmit及npx vitest run --pool=threads --maxWorkers=1，均nice -n 19、离线；固定输入测试，无真实LLM/网络。本批无代码变更或提交，未跑完整test-sandbox.sh，也未声称完整套件通过。具体八个测试文件见targeted.log；输出分别保存在tsc.log和targeted.log。',
          '- 合入：未合入（本批无新增源码，不空合或新增版本；观察到的live为'
          + audit['live_read_only_snapshot']
          + '，注册屏障798af209b及a78bb40e原发布接续继续由原owner处理，未改原失败或待验状态）。',
          '- 需要 Roy 定的事（没有写「无」）：无。', '',
          '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '']
(OUT / 'report.md').write_text('\n'.join(lines))
(OUT / 'report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'skipped.json').write_text(json.dumps(skipped, ensure_ascii=False, indent=2) + '\n')
(OUT / 'final-status.txt').write_bytes(status)
manifest = {}
for file in sorted(OUT.iterdir()):
    if file.is_file() and file.name != 'artifact-manifest.json':
        data = file.read_bytes()
        manifest[file.name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
(OUT / 'artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(report=result['report'], existing_fixes=len(audit['existing_fixes']) + 1,
                      unchecked_entries=audit['unchecked_entries'], tests=result['tests'],
                      source_diff_bytes=(OUT / 'source.diff').stat().st_size,
                      queue_unchanged=True, status_clean=not status), ensure_ascii=False, indent=2))

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WT = ROOT / '.worktrees/codex-fix-silent-20261015-224302'
OUT = ROOT / 'learner/runs/20261015-224306-62831b0f-88bb-488a-9019-2e7550472ddf-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-214306-c1fbbfac-f9e0-42d8-a5ef-51eedcffc4f9-fix-batch'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, head):
    return subprocess.run(['git', '-C', str(WT), 'merge-base', '--is-ancestor', commit, head]).returncode == 0


prior_bytes = (PRIOR / 'audit.json').read_bytes()
prior = json.loads(prior_bytes)
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'refs/heads/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
previous_queue = (PRIOR / 'queue-snapshot.md').read_bytes()
(OUT / 'queue-snapshot.md').write_bytes(queue)
existing = []
for old in prior['existing_fixes']:
    path = old['path']
    current = (WT / path).read_bytes()
    row = {k: old[k] for k in ('item', 'source_commit', 'path')}
    row.update(current_source_sha256=sha(current),
               same_as_prior_audit=sha(current) == old['current_source_sha256'],
               same_as_committed_base=current == git('show', f'{base}:{path}'),
               ancestor_in_base=ancestor(old['source_commit'], base),
               ancestor_in_live=ancestor(old['source_commit'], live))
    leaf = subprocess.run(['git', '-C', str(WT), 'show', f'{live}:{path}'], capture_output=True)
    row['live_leaf_present'] = leaf.returncode == 0
    row['same_source_in_live'] = leaf.returncode == 0 and current == leaf.stdout
    existing.append(row)

barrier = '798af209b9a268b7dafab1440150f1b39cd5595d'
barrier_paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', barrier).decode().splitlines()
barrier_readback = []
for path in barrier_paths:
    current = (WT / path).read_bytes()
    barrier_readback.append(dict(path=path, sha256=sha(current),
                                 same_as_source=current == git('show', f'{barrier}:{path}'),
                                 same_as_committed_base=current == git('show', f'{base}:{path}')))

dispositions = json.loads((PRIOR / 'queue-dispositions.json').read_bytes())
lines = queue.decode().splitlines()
unchecked = [(n, s) for n, s in enumerate(lines, 1) if s.startswith('- [ ]')]
assert len(unchecked) == len(dispositions)
assert all(n == d['line'] and s == d['item'] for (n, s), d in zip(unchecked, dispositions))
assert all(r['same_as_committed_base'] and r['ancestor_in_base'] for r in existing)
assert all(r['same_as_source'] and r['same_as_committed_base'] for r in barrier_readback)
changed = [r['path'] for r in existing if not r['same_as_prior_audit']]
audit = dict(base=base, live_read_only_snapshot=live,
             prior_audit=str(PRIOR / 'audit.json'), prior_audit_sha256=sha(prior_bytes),
             existing_fixes=existing, queue_sha256=sha(queue), queue_lines=len(lines),
             prior_queue_sha256=sha(previous_queue), queue_only_appended=queue.startswith(previous_queue),
             queue_added_lines=queue[len(previous_queue):].decode() if queue.startswith(previous_queue) else None,
             unchecked_entries=len(unchecked), unchecked_entries_unchanged=True,
             changed_source_paths_from_prior_audit=sorted(set(changed)),
             registration_barrier=dict(item='sandbox-glob-startup-race：父注册事务尚未保存即捕获启动租约',
                                       source_commit=barrier, ancestor_in_base=ancestor(barrier, base),
                                       ancestor_in_live=ancestor(barrier, live), files=barrier_readback),
             limitations=['祖先关系与当前叶核验不是本批新增实现或自然消费证据。',
                          '旧已修记录中的窄子项不关闭更宽父项。',
                          '原目录删除者、历史null租约与0332资源接续根因仍未证实。'])
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(OUT / 'queue-dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source.diff').write_bytes(git('diff', '--binary', 'HEAD'))
source_paths = sorted(set(r['path'] for r in existing))
(OUT / 'changes-since-prior-base.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--', *source_paths))
print(json.dumps(dict(base=base, live=live, existing=len(existing), unchecked=len(unchecked),
                      changed=sorted(set(changed)), barrier=audit['registration_barrier'],
                      added_lines=audit['queue_added_lines']), ensure_ascii=False, indent=2))

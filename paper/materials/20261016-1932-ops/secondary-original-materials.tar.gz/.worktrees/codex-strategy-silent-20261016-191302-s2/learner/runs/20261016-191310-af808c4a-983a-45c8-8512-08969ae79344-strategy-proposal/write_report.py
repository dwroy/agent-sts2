import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
batch = '20261016-191302-s2-strategy-proposal'
dispatch = json.loads((OUT / 'dispatch-and-proposals.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
verification = json.loads((OUT / 'evidence-verification.json').read_text())
checks = json.loads((OUT / 'facts-verification.json').read_text())
extra = json.loads((OUT / 'additional-facts-verification.json').read_text())
assert len(checks) == 27 and len(extra) == 6
assert all(s['raw_bytes_identity_verified'] for s in verification)
recorded_at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z']).decode().strip()
print(recorded_at)

details = [
    ('感染棱柱：技能收益与污染血价', 'DUZUBAJ3A8GP F27 T4—T6；states 274830—274839',
     'T4污染0/3/3/6；火花3→6后T5污染0/6/12/18，次轮清空。两轮实损3/9，敌本体净扣8/13。',
     '求解器技能叠污染、推演增长及SL资源差已有路径；1698adc96ba434a46942321e0237b70657e625b2为实际live祖先。',
     '缺原dirty运行知识、实际移动表及火花增长/污染撤除/虚弱/毒/格挡的冻结联合生产校准；未定位新的可归责计算差额。',
     '技能同时有毒或挡收益，实损9不支持强制少打技能；未执行另一线不当获胜反事实。',
     '保留选项，逐击血价与毒/挡分列；固定同一生产源码、知识、移动表与实际前缀后，定位差额再修。'),
    ('失落与遗忘：抢夺来源与返还', '5PM6JAQG6FNQ F39 T2、T4—T6；states 274341/274351/274352/274354/274358/274362',
     '玩家力敏−2/−2→−4/−4；两步法使敏捷−4→−2→0。失落退场后力量0，随后遗忘再抢到敏捷−2。',
     '当前负力量/负敏捷已被求解和推演读取；当前值不等于逐来源累计及退场返还认证。',
     '缺稳定实体身份、逐来源抢夺/毒杀返还/再次抢夺的完整对账，另一杀序缺受控整战后继。',
     '原末试只建立一次步法，返还后仍死亡；不能从端点规定固定击杀序。',
     '按实体及代际记来源，不能把重排index当持续身份；固定累计和返还输入，杀序价值另验。'),
    ('下水道蚌：当前进阶事实与加压', 'CA5KE8GFJ9X2 F13 T1—T5；states 273238/273247/273252/273254/273258/273263/273268',
     '力量0/4/8，无弱攻击11/15/19，弱后15→11、19→14；轮初覆甲9/9/8/7/6。',
     'monsterHpAt/moveDamageAt直接使用当前进阶已有记录，无五样本限制；room-costs.MEASURED_ROOM_MIN_N仍为5。4ed3c72df30f27b881da637aebf528b97440e0bb是实际live祖先。',
     '首样本接口已有实现；缺原实际移动表及加压、覆甲、虚弱的联合生产校准，未完整隔离覆甲减层条件。',
     '现场覆甲序列不能证明全部减层条件；死亡截断实损不代替完整需损。',
     '维持当前进阶首样本事实及房间代价五样本门槛，冻结原输入后逐步校准，不补未观察规则。'),
    ('电击机器人：高电压与召唤身份', '5PM6JAQG6FNQ F38 T3/T4；states 274308/274312/274313',
     '23上限电击的索引4→3，力量2→4、意图17→19；T3仍贡献17攻击。',
     'HIGH_VOLTAGE_POWER在增长路径中，新实体有初始化路径；f3dea91880600bc2e7228268a110a644531738f7为实际live祖先。',
     '缺稳定召唤代际身份、原A10移动表及跨代重置联合校准；先杀爪牙的未执行线缺完整后继。',
     '同类型、同血量上限和index重排不能独立证明实体连续；35伤/损3候选未实打。',
     '固定召唤、退场、再召唤身份与移动表后核增长/重置，不据候选击杀预记实际退场。'),
    ('沙虫：SL血价、HP护栏与能力兑现', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；decisions 270216/270282/270264',
     '首/第三试T2完整指纹相同：实损3→15，净扣10→17；候选死亡0/24与5/24，预计后损都47，不能称同死率。',
     '66283dd9982bdd7f480da7a4d9bfefea0572a9ac有候选/护栏审计；1698adc扩资源差；bade647f9fe4c9103b40e2f26b26296692ad24b7及fdaf787a372880b0438e73bcac7e6d2168b038ed有单动作回执，均已核实际live祖先。',
     '缺跨抽弃、生成、用药与重问的整候选连续归属、逐来源能力兑现及联合资源消费者；单动作回执不足证明整候选完成。',
     '原末次更防御线延至T11仍败；候选省血与重规划后实际省血不同。',
     '分列原答、护栏、SL替换、单步派发与结算；先核连续归属和真实资源链，不设新探索系数。'),
    ('实验体：全败SL及续步截断', 'YF0LXT1QSTGG F48第二/第三试T1；decisions 271309/271348/271354，states 277327—277373',
     '两题完整指纹相同，实损0→9、净扣45→38；候选均24/24死。271354实际end_turn，原候选数字损0/10、伤54/36单列。',
     'SL资源差明确是current_turn_prediction、execution=unverified；单动作回执whole_plan_executed=null。',
     '缺截断续步的完整执行归属、同抽序后轮及受控获胜后继；全败并列不足拟血价惩罚或禁止探索。',
     '同局F33成功SL后奖励帧20血已核；F48失败不否定全部SL。原第四试弃牌后未完成候选的反例保留。',
     '核同题预测与实际端点、覆盖重放和未完成续步；不把有限样本同败称安全，不改探索门槛。'),
    ('实验体：阶段、毒与敏捷取得时点', 'YF0LXT1QSTGG F48末试T3—T5；states 277512/277513/277519/277524/277526/277527',
     '阶段4血4毒/111上限→212血212上限/零毒；触媒2而毒0；敏捷5→6时现有挡仍23。末轮净扣37，18血对44−23需21，差3。',
     'silent-phase-current分列当前能力、持有组件和毒；8698c581dac6c7e957f50a381586960a6d0c9b57及aad2700abed6dff1d66e87fb36aaa6fedb39adf3为实际live祖先。',
     '缺跨阶段整候选执行、逐来源施毒/结算及敏捷取得顺序的联合生产校准；当前快照不足认证后继收益。',
     '前五试建过毒雾或余像仍败；不能将零毒作为唯一死因或强制能力先手。',
     '阶段变化重读现场，不预支未建能力或零毒触媒收益，不把后得敏捷倒补既有挡；冻结建立和结算时点验证。'),
    ('双蟹：B2零胜并列与实付血价', 'XP2SL33HT0D9 F33首/末T1、首/第二T3及第三T4；decisions 271982/272195/271992/272040/272076',
     'T1同指纹实损2→10、净扣25→34；T3同指纹实损9→14、净扣24→27。272076两线B2均0，五轮死亡21/24→23/24为候选事实。',
     '已有候选审计、当轮资源差及单动作回执；窄源实际live祖先见source-audit.json。',
     '缺同抽序、药瓶随机落点后继、成长兑现及受控整战比较；零胜并列和当轮血价不足拟新探索门槛。',
     '付血伴随手里剑成长；末试T2零损及T3保挡构成限制，不能仅按挡牌数量判错。',
     '成对报告HP、输出、成长与采样；按独立run/时间后移验证，相同存档六试不充六局，不拟全局血伤常数。'),
    ('双蟹：朝向、临时减力与轮初格挡', 'XP2SL33HT0D9 F33末试T2/T4/T5；states 278236/278237/278240/278242/278249/278252/278253/278255/278260/278261',
     '14挡加斗篷到20；镣铐力0→−9→0；激光57→转向38→弱28；四敏脆弱时6挡；末轮毒扣3+7且玩家归零。',
     'passive-pieces有HORN_CLEAT_BLOCK=14、T2；临减/恢复/朝向/弱已有求解与推演路径，实际源码与祖先范围见source-audit.json。',
     '缺全部修饰组合的冻结生产回放、抽弃后的整候选执行及未选后继；已有窄覆盖不等于全部组合校准。',
     '临减次轮恢复；已建能力仍无减员，不外推未见叠层或固定目标顺序。',
     '朝向、弱、临减、轮初挡按来源及先后分别对账，冻结组合输入；保留排名、HP护栏与能力权重。'),
    ('综合机制：联合资源消费者', 'YF0LXT1QSTGG F48、XP2SL33HT0D9 F33及本批另四局上述锚点',
     '六局A10身份和四组同指纹当轮配对已核；六锚点不等于原101局/1499房历史全量重建。',
     '候选、护栏、阶段快照和单动作回执已有局部覆盖，未证明逐来源联合资源消费全部闭合。',
     '六局不能替代原101局联合资源重建；完整候选、路线、休息、实际用药及SL恢复的逐来源联合消费仍缺。',
     'SL恢复不是回血；候选省血不是实际收益；持有组件不是已施放。原历史分母保留，不充本批重算。',
     '按原范围逐run核资源与归属，分别验证观察事实和受控后继；不关闭量化、联合消费者和学习入库父要求。'),
]
assert len(details) == len(dispatch['proposals']) == 10
sections = []
results = []
for p, data in zip(dispatch['proposals'], details):
    title, evidence, observed, existing, reason, counterexample, future = data
    results.append({'id': p['id'], 'state': 'waiting', 'reason': reason})
    sections.append(f"## {p['id']}：{title}\n\n"
                    f"原提案：{p['proposal']}；原Markdown SHA256：{p['actual_sha256']}。\n\n"
                    f"账本：{'、'.join(p['ledger'])}。证据局/层/回合：{evidence}。\n\n"
                    f"本批核实：{observed}\n\n旧规则及已有实现：{existing}\n\n"
                    f"处置：waiting。{reason}\n\n反例与限制：{counterexample}\n\n"
                    f"预期行为与验证：{future}\n\n"
                    "样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。"
                    "确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。"
                    "本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。\n")

body = '\n'.join(sections)
counts = {s['stream']: sum(s['counts'].values()) for s in verification}
intro = (f"批次：{batch}；角色：silent；记录时间：{recorded_at}。\n"
         f"完整base：{source['base']}。\n\n"
         "结论：十项均waiting。未发现可由本批冻结实盘输入定位的新计算差额，"
         "也没有足以改探索、目标顺序、能力优先级或长期价值的受控后继。"
         "已有局部实现不冒标整项duplicate/implemented。无源码/知识改动、提交、合入、行为版本或shipped。\n\n")
scope = ("本批根learn.json只读对应行，task/character/worktree/runs及十proposal_ids均匹配；"
         "无research_request、implementation_request或proposal_repair。普通专题请求绑定另一旧批，本批不承接。"
         "开工git status干净，git merge --no-edit main返回Already up to date。"
         "只处理所派十ID，原Markdown指纹全部匹配并保留.original.txt。\n\n"
         "六局均由runs.jsonl核为SILENT/A10，运行版本均带dirty；"
         "本批没有完整复原旧运行知识、移动表和全部源码。当前源码存在不证明旧运行预测正确。"
         "没有读取其他角色私有知识，也不以预训练知识补机制。\n\n")
material = (f"共用extract_evidence.py本次提取八流，逐行按source/offset/bytes/SHA256/JSON及显式身份回原日志核验，"
            f"合计{sum(counts.values())}行，计数：{json.dumps(counts, ensure_ascii=False)}。"
            "各流source_size、逐局计数及输出SHA在evidence/evidence-manifest.json，逐行索引在verified-evidence-index.jsonl。"
            "各流分别冻结截点，不称原子快照；fight-plans零行只说明本截点未选到，不断言原流缺失。\n\n"
            f"27项原帧/同指纹端点和6项候选/成功SL反例检查本次通过，共33项，仅为材料核验，"
            "不是生产测试、模型模拟、整候选执行认证或受控整战反事实。"
            "沿用旧批固定检查脚本并适配本批输入路径，原字节及SHA、改动保留于material-helper-provenance.json和对应.original.txt；"
            "未直接沿用旧检查成功作为本批结果。\n\n"
            f"相关源码19叶中，17叶与同十提案前批源码相同；{source['same_as_live_count']}叶与本次实际live逐字节同，"
            "其余5叶仅历史Roy/Dai注释署名差。实际live快照为"
            f"{source['live_head']}，所有引用窄源码commit已重新核为此live祖先。"
            "完整SHA、祖先和差异见source-audit.json、base-live-source.patch；不由少数源码叶推全知识一致。\n\n")
tail = ("## 验证与交付边界\n\n"
        "本批没有源码改动，未运行撤源码/恢复检查或生产tsc/vitest，三项测试值均null，fixes=[]、merged=null。"
        "没有执行live知识刷新、合入、生成eval版本或规则双通知；没有新建提案ID，沿用十原CLI ID。"
        "implementation_domains=[]表示本批没有实际代码实现，不改变原提案声明的领域。"
        "不把原经验shipped状态当成本批策略实现完成。\n\n"
        "账本仅经根learner/ledger.py update追加本批proposal/report的where和处置note，by=learner:strategy-proposal；"
        "不重复support/repeat，不改claim、first_run、prior、evidence、status或版本，不把既有shipped降为proposed。"
        "CLI输入/输出、物理追加回执及前后受保护字段核验另存。队列处置由proposal_results交调度器消费，"
        "不手写learn.json、请求或队列，不关闭父要求。\n\n"
        "本批没有发现新的机制反证或与旧知识冲突；原反例和缺数据保持。"
        "首次在提取完成前探读states选中首行得到StopIteration，保留该探读事实；它不是零行结论。"
        "少数只读路径探测不存在（core/loop.ts、knowledge/fight-value.ts、strategy/、sim/hp-forecast.ts），"
        "随后用rg定位hand/loop.ts、reflex/fight-value.ts及knowledge/room-costs.ts，不当产品故障。"
        "未独立核实际原生模型/推理强度或服务档，不以任务文字冒称运行切换成功；未改模型、账号、权限或prompt。\n\n"
        f"交运维：{OUT / 'proposal.md'}、{OUT / 'report.md'}、result.json及十项proposal_results。"
        "无待兜底提交或合入受阻。本批材料保留，工作树及索引应保持干净，生产完整性与扫描见final-integrity.json和gitleaks.log。\n")
(OUT / 'proposal.md').write_text('# 本批十项策略提案处置\n\n' + intro + scope + body + tail)
(OUT / 'report.md').write_text('# 本批静默策略核验报告\n\n' + intro + scope + '## 证据与源码核验\n\n' + material + body + tail)
(OUT / 'dispositions.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch,
          'base': source['base'], 'runs': dispatch['dispatch']['runs'], 'fixes': [],
          'skipped': [],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in dispatch['proposals']], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal_count': len(results), 'waiting': len(results)}, ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-180157-s2/learner/runs/20261016-180201-5d53e3dc-6f14-4a57-9a21-4668b4ce2cc6-strategy-proposal')


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


base = git('rev-parse', 'HEAD').decode().strip()
live_head = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
prior = json.loads((PRIOR / 'source-audit.json').read_text())
files = []
diffs = []
for old in prior['files']:
    path = old['path']
    raw = (ROOT / path).read_bytes()
    live = git('show', live_head + ':' + path, cwd=LIVE)
    commits = old.get('commits_actual_live_ancestor', {})
    ancestors = {commit: subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', commit, live_head]).returncode == 0 for commit in commits}
    files.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(),
                  'same_as_prior': hashlib.sha256(raw).hexdigest() == old['sha256'],
                  'live_sha256': hashlib.sha256(live).hexdigest(), 'same_as_live': raw == live,
                  'actual_live_ancestors': ancestors})
    diffs.append(git('diff', '--binary', base, live_head, '--', path))
for path in ['agent/src/knowledge/room-costs.ts', 'agent/src/knowledge/move-model.ts']:
    raw = (ROOT / path).read_bytes()
    live = git('show', live_head + ':' + path, cwd=LIVE)
    files.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(),
                  'live_sha256': hashlib.sha256(live).hexdigest(), 'same_as_live': raw == live})
    diffs.append(git('diff', '--binary', base, live_head, '--', path))
result = {'base': base, 'live_head': live_head, 'prior_report': str(PRIOR / 'report.md'),
          'prior_report_sha256': hashlib.sha256((PRIOR / 'report.md').read_bytes()).hexdigest(),
          'files': files, 'same_as_prior_count': sum(f.get('same_as_prior', False) for f in files),
          'same_as_live_count': sum(f['same_as_live'] for f in files)}
(OUT / 'source-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'base-live-source.patch').write_bytes(b''.join(diffs))
assert all(all(f.get('actual_live_ancestors', {}).values()) for f in files)
print(json.dumps({k: v for k, v in result.items() if k != 'files'}, ensure_ascii=False))

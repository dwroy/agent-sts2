import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PATH = ROOT / 'paper/materials/learning/ledger.jsonl'
dispatch = json.loads((OUT / 'dispatch-and-proposals.json').read_text())
dispositions = json.loads((OUT / 'dispositions.json').read_text())
assert len(dispositions) == len(dispatch['proposals']) == 10
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
before = PATH.read_bytes()
assert before.endswith(b'\n')
before_items = ledger.fold([(i + 1, json.loads(raw)) for i, raw in enumerate(before.splitlines()) if raw.strip()])
ids = sorted({i for p in dispatch['proposals'] for i in p['ledger']})
assert all(before_items[i]['character'] == 'silent' for i in ids)
(OUT / 'ledger-before-at-cli.json').write_text(json.dumps({i: before_items[i] for i in ids}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-prefix-before.json').write_text(json.dumps({'bytes': len(before), 'sha256': hashlib.sha256(before).hexdigest()}, indent=2) + '\n')
updates = []
for ident in ids:
    linked = [r for p, r in zip(dispatch['proposals'], dispositions) if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261016-191302-s2-strategy-proposal：本批核六局A10及8274原行，关联原提案' +
                            '、'.join(r['id'] for r in linked) +
                            '均waiting；具体缺口见report.md。仅补本批追溯，不新增或重复support/repeat，不改原claim、首证、prior、evidence、status、version或shipped；没有源码实现、合入或版本。'})
encoded = ''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates).encode()
(OUT / 'ledger-updates.jsonl').write_bytes(encoded)
print(subprocess.check_output(['date']).decode().strip(), flush=True)
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], input=encoded, capture_output=True)
(OUT / 'ledger-cli.stdout').write_bytes(result.stdout)
(OUT / 'ledger-cli.stderr').write_bytes(result.stderr)
(OUT / 'ledger-cli-exit.json').write_text(json.dumps({'exit_code': result.returncode, 'input_sha256': hashlib.sha256(encoded).hexdigest(), 'row_count': len(updates)}, indent=2) + '\n')
assert result.returncode == 0, '账本CLI未成功；保留输入及失败回执，不重写历史'
after = PATH.read_bytes()
assert after[:len(before)] == before
offset = len(before)
receipts = []
for raw in after[len(before):].splitlines(keepends=True):
    row = json.loads(raw)
    match = next((u for u in updates if all(row.get(k) == v for k, v in u.items())), None)
    if match:
        assert set(row) == set(match) | {'op', 'ts'} and row['op'] == 'update'
        receipts.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(receipts) == len(updates) and {r['row']['id'] for r in receipts} == set(ids)
private = ledger.fold([(i + 1, json.loads(raw)) for i, raw in enumerate(before.splitlines()) if raw.strip()] +
                      [(len(before.splitlines()) + i + 1, r['row']) for i, r in enumerate(receipts)])
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']
for ident in ids:
    a, b = before_items[ident], private[ident]
    assert all(a.get(k) == b.get(k) for k in protected)
    for key in ['notes', 'history']:
        assert b.get(key, [])[:len(a.get(key, []))] == a.get(key, [])
    for key, values in a.get('where', {}).items():
        assert b['where'][key][:len(values)] == values
(OUT / 'ledger-physical-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-integrity.json').write_text(json.dumps({'rows': len(receipts), 'physical_prefix_preserved': True,
    'before_bytes': len(before), 'before_sha256': hashlib.sha256(before).hexdigest(),
    'own_updates_protected_fields_preserved': protected, 'old_where_notes_history_prefixes_preserved': True,
    'private_fold_only_own_delta': True, 'shipped_or_proposed_status_not_changed': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ledger_cli_exit': result.returncode, 'rows': len(receipts), 'protected_fields_preserved': True}, ensure_ascii=False))

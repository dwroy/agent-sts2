import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extractor', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / 'dispatch-and-proposals.json').read_text())['dispatch']
runs = set(dispatch['runs'])
windows = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
           '8JRE1C4H4Z2W': [33], 'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [33]}
decision_lines = {270216, 270282, 270264, 271309, 271348, 271354, 271495, 271509,
                  271982, 272195, 271992, 272040, 272076}
verified, frames, decisions, run_rows, configs, index = [], [], {}, [], [], []


def powers(row):
    return {p['power_id']: p.get('amount') for p in row.get('powers', [])}


for folder in ['evidence']:
    manifest = json.loads((OUT / folder / 'evidence-manifest.json').read_text())
    for stream in manifest:
        name = stream['stream']
        source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
        archive = OUT / folder / (name + '.evidence.jsonl')
        counts = dict.fromkeys(dispatch['runs'], 0)
        digest = hashlib.sha256()
        with archive.open('rb') as selected, source.open('rb') as raw_source:
            for encoded in selected:
                digest.update(encoded)
                e = json.loads(encoded)
                assert e['run_id'] in runs and e['source'] == str(source)
                assert e['offset'] >= 0 and e['offset'] + e['bytes'] <= stream['source_size']
                raw_source.seek(e['offset'])
                raw = raw_source.read(e['bytes'])
                assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == e['sha256']
                assert json.loads(raw) == e['row']
                assert extractor.run_identity(e['row']) == e['run_id']
                counts[e['run_id']] += 1
                index.append({'stream': name, **{k: e[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']}})
                if name == 'runs':
                    assert str(e['row']['character']).lower() == 'silent' and e['row']['ascension'] == 10
                    run_rows.append(e)
                elif name == 'run-config':
                    configs.append(e)
                elif name == 'decisions' and e['line'] in decision_lines:
                    decisions[str(e['line'])] = e['row']
                elif name == 'states':
                    state = e['row']['state']
                    combat = state.get('combat') or {}
                    floor = state.get('run', {}).get('floor')
                    if not combat or floor not in windows[e['run_id']]:
                        continue
                    player = combat.get('player') or {}
                    frames.append({'line': e['line'], 'run': e['run_id'], 'floor': floor,
                        'turn': state.get('turn'), 'observed_ts': e['row'].get('observed_ts'),
                        'screen': state.get('screen'),
                        'player': {'hp': player.get('current_hp'), 'block': player.get('block'), 'powers': powers(player)},
                        'hand': [c.get('card_id') for c in combat.get('hand', [])],
                        'enemies': [{'index': m.get('index'), 'id': m.get('enemy_id'), 'hp': m.get('current_hp'),
                            'max_hp': m.get('max_hp'), 'block': m.get('block'), 'alive': m.get('is_alive'),
                            'powers': powers(m), 'move': m.get('move_id'),
                            'attack': [(a.get('damage'), a.get('hits')) for a in m.get('intents', []) if a.get('damage') is not None]}
                            for m in combat.get('enemies', [])]})
        assert counts == stream['counts'] and digest.hexdigest() == stream['output_sha256']
        verified.append({**stream, 'archive': str(archive), 'raw_bytes_identity_verified': True})

assert set(decisions) == {str(n) for n in decision_lines}
assert {e['run_id'] for e in run_rows} == runs and len(run_rows) == len(runs)
for name, value in [('evidence-verification.json', verified), ('window-states.json', frames),
                    ('fixed-decisions.json', decisions), ('verified-runs.json', run_rows), ('verified-configs.json', configs)]:
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'verified-evidence-index.jsonl').open('w') as f:
    for e in index:
        f.write(json.dumps(e, ensure_ascii=False) + '\n')
print(json.dumps({'verified_lines': len(index), 'streams': {s['stream']: sum(s['counts'].values()) for s in verified},
                  'window_states': len(frames), 'fixed_decisions': len(decisions), 'runs': len(run_rows)}, ensure_ascii=False))

"""Run the existing offline consumer once per frozen input, retaining explicit exclusions."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
OUT = HERE / "consumer"
OUT.mkdir(exist_ok=True)
runs = json.loads((HERE / "verified-runs.json").read_text())
data = {run: {"run": row, "states": [], "decisions": []} for run, row in runs.items()}
for stream in ["states", "decisions"]:
    with (HERE / "evidence" / (stream + ".evidence.jsonl")).open() as handle:
        for line in handle:
            envelope = json.loads(line)
            data[envelope["run_id"]][stream].append(envelope["row"] | {
                "_line": envelope["line"], "_source_sha256": envelope["sha256"]})
results = []
for run, value in data.items():
    value["decisions"].sort(key=lambda row: row.get("observed_ts") or "")
    source = OUT / (run + ".full.input.json")
    source.write_text(json.dumps(value, ensure_ascii=False) + "\n")
    excluded = [{"line": r["_line"], "source_sha256": r["_source_sha256"], "reason": "原行缺decision_id，不补造身份", "row": r}
                for r in value["decisions"] if not r.get("decision_id")]

    def invoke(path, tag):
        target = OUT / (run + "." + tag + ".output.json")
        error = OUT / (run + "." + tag + ".stderr.txt")
        command = ["node", "--import", "./agent/node_modules/tsx/dist/loader.mjs", "learner/audit-selection.ts", str(path)]
        with target.open("w") as stdout, error.open("w") as stderr:
            result = subprocess.run(command, cwd=WORKTREE, stdout=stdout, stderr=stderr)
        return {"input": str(path), "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "command": command, "rc": result.returncode, "output": str(target),
                "output_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "stderr": str(error)}

    full = invoke(source, "full")
    record = {"run_id": run, "input_scope": "full_run", "full": full, "exclusions": excluded}
    if excluded:
        assert full["rc"] != 0
        assert "decision_id" in Path(full["stderr"]).read_text()
        subset = value | {"decisions": [r for r in value["decisions"] if r.get("decision_id")]}
        bounded = OUT / (run + ".bounded.input.json")
        bounded.write_text(json.dumps(subset, ensure_ascii=False) + "\n")
        accepted = invoke(bounded, "bounded")
        record["bounded"] = accepted
        record["input_scope"] = "explicit_subset_preserving_original_line_gaps"
    else:
        accepted = full
    assert accepted["rc"] == 0, accepted
    output = json.loads(Path(accepted["output"]).read_text())
    segments, actions, turns = output["segments"], output["observed_actions"], output["observed_turns"]
    assert all(s["actual_full_candidate_result"] is None and s["actual_rollout_best"] is None for s in segments)
    summary = {"actions": len(actions), "segments": len(segments),
               "observed_action_endpoints": sum((a.get("observed_interval") or {}).get("status") == "observed_endpoints" for a in actions),
               "terminal_endpoints": sum((a.get("terminal_observation") or {}).get("status") == "observed_terminal_endpoints" for a in actions),
               "observed_turn_endpoints": sum(t["status"] == "observed_turn_endpoints" for t in turns),
               "unknown_turn_windows": sum(t["status"] == "unknown" for t in turns),
               "certified_full_candidates": sum(s["actual_full_candidate_result"] is not None for s in segments)}
    record["summary"] = summary
    results.append(record)
    (HERE / "consumer-readback.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"run_id": run, "scope": record["input_scope"], "full_rc": full["rc"], "accepted_rc": accepted["rc"], "excluded": len(excluded), **summary}, ensure_ascii=False), flush=True)

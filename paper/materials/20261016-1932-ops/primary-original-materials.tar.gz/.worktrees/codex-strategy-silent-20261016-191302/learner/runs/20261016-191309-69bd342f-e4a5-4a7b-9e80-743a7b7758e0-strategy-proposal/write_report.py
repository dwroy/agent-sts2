"""Render this batch's bounded dispositions and append-only ledger input."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
timestamp = "2026-10-16T19:25:02+08:00"
dispatch = json.loads((HERE / "dispatch.json").read_text())
assigned = json.loads((HERE / "assigned-proposals.json").read_text())["items"]
source = json.loads((HERE / "source-verification.json").read_text())
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
consumers = json.loads((HERE / "consumer-readback.json").read_text())
checks = json.loads((HERE / "fact-checks.json").read_text())
assert len(checks) == 37 and all(c["passed"] for c in checks)
assert len(consumers) == 6
details = [
    ("89354805ee4d7e77", "VLZ6CCT8AQ0A F35 T1、F36 T1–2、F43 T1–2、F45 T1",
     "神化实付2能；F35普通防御5→8、打击7→10、匕首雨每击5→7、工具1→0费；F43同后续牌序的两次预测43伤/14损与51伤/13损分列。s275564/275565、275594/275595、275679/275680/275687，d269706/269707。",
     "已核live祖先772b839f、f516592f、b2805be4、ba23ca69覆盖有限升级配对；3aa6c03a加入持有/候选/模拟升级参考。现有参考actual_cast_this_fight仍为null，未知属性组合保留unknown，不能由牌组持有或一段升级模型认证全战施放历史。",
     "缺跨抽牌、选牌、药水、重问、SL及换战的实际施放持续身份核验；现有有限升级配对和参考字段不足关闭整项。未知属性交互仍须按实见范围验证。",
     "F45未施放神化不是施放机制反例；已施放场的胜负也无同盘整战因果。",
     "沿原实现补可追溯施放状态与各中断边界，未知仍显式未知；用本批固定帧校验后续升级、已升级不重复、场外deck不变，新增源码撤掉应失败、恢复后通过。这里不要求把未知牌一律建模才允许窄修，但不能据窄修关闭整项。"),
    ("f2bfceddb1898dca", "VLZ6CCT8AQ0A F43 T1、F44、F45 T1/T4/T5",
     "d269748随机药水1/12样本、707ms，rollout=horizon1/samples1/best=null；d269754改为12/12只代表该题药水局部样本。s275728/275729能量1→2、HP67不变；末轮s275754为32血20挡/显示59来袭，非只缺7伤。",
     "silent-simulation-reference.ts已列模拟范围、退化、样本、时间、未知与并列；这是诊断覆盖，未证明预算分配策略收益。神化当前覆盖也仅限已核配对。",
     "缺完整模型及冻结随机池下同起点、同总预算的配对实验、候选稳定性/样本成熟度曲线和留药完整后继；707ms单题不足修改预算、药价或focus。",
     "T4高伤候选未实打，少损线不能倒记为败因；同局F17/F33首试胜不支持一律废弃推演。",
     "保留预算、持药与目标规则。未来实验同时冻结源码/知识/移动表/随机池，在同总预算比较原MC顺序与分阶段预算，按独立run_id和时间后移切分，另验成熟度与实盘后继。"),
    ("283a164780d11e69", "VLZ6CCT8AQ0A F35 T1、F43 T1–2、F45 T1",
     "与89354805同一神化证据，保留experience-update→silent-apotheosis-combat-upgrades的独立来源链；s275679/275680的减力6→8和勒紧4→6属于已观察升级变化。",
     "沿同一live窄实现复核，不新建神化提案id；经验条目存在不等于原宽代码请求全部实现。",
     "同源神化项仍缺实际施放持续身份和跨中断验证；仅同题、同证据或已有窄源码不足把独立经验来源链登记duplicate。",
     "F45持有但未施放，不是普通神化升级效果的反例；不能以四次施放胜场推出必打。",
     "和89354805共用后续实现与固定夹具，但分别保留原来源、账本、经验链接；覆盖验证完成后才沿实际live祖先登记处置。"),
    ("ebbfe3b97548756d", "VLZ6CCT8AQ0A F43 T1–5、F45 T1/T3/T5及F44资源链",
     "本批复核神化后勒紧6/尖啸8、末轮覆甲0、32血20挡与59来袭；已链接15条经验及14个账本。原提案还包括逐击力量、敏捷、金刚杵、口红、毒、永久/临时减力、加湿器、路线/休息等，不能把本次35余项端点算成15项全链校准。",
     "现有card-model/turn-solver/rollout及题面参考实现部分机制；本批19源码叶与live17叶相同，另两叶仅历史署名注释差。相同源码不证明当时dirty知识、移动表及消费者调用均已复原。",
     "缺15个子项在同一冻结生产输入下的逐源联合验证，尤其属性/升级组合、状态期限与战斗/路线/休息资源接续；局部端点不足关闭复合项。",
     "F45所有敌人仍存活，残毒不可预支整场伤害；回血能增加当下HP，不由相同下限boss输入推出无价值。",
     "按子项冻结实盘帧与现有调用，分别核状态变换、到期、敌退场和已胜场资源消耗；对实际不符的窄缺口独立补代码，保持其他角色等价，不拟合固定休息或focus规则。"),
    ("e5b87be50f28f311", "8JRE1C4H4Z2W F33首/三试T2、第二试T5、末试T11；F17 T6",
     "d270216/270282指纹完全相同；原题分别0/24、5/24死亡样本，封顶后续损47不能写成同死率。实际至下轮HP差−3/−15、敌HP差−10/−17，局部多12血换7伤。d270264护栏省血是候选差，不能搬给抽牌重问后的实际整轮。",
     "05cd292c、a8b1f8be、cf72bd21及83512ddc等live祖先已有三阶段预测、护栏/SL差值、单动作回执、观测/终页/回合端点。当前在线actual_turn和离线actual_full_candidate_result仍null；已有审计不是完整候选兑现认证。",
     "缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；本批离线端点仍只能确认有界观测，原审计增量未完整覆盖。改变护栏/SL偏好还另缺受控未选线后继。",
     "末试延至T11仍败；防御换线并非一概更差。六次尝试只是一局，不能增加独立样本分母。",
     "优先复用现有审计字段，补可证明的执行边界及已建能力时点，不改选择结果。完成审计不以取得赢局为前提；受控整战比较仅用于将来改变规则，不能反过来当额外审计阻塞条件。"),
    ("49632bc4878fb597", "CA5KE8GFJ9X2 F13 T1/T3/T5",
     "s273237/273252/273263敌力0/4/8、同招显示11/15/19；s273257/273268虚弱后11/14。虚弱没取消成长，现场没有正敏捷实测。",
     "逐击力量、属性、弱及数据驱动敌招已有路径；本批不以单个步法或成长源码提交替代四路径同调用验证。",
     "缺同一冻结调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血/输出权重。",
     "计划步法没有实际取得；末轮2血10挡对14来袭，零血实扣截断不能写成只需2伤。",
     "冻结实际属性与A10数据库输入逐击/逐牌比较，未观测路径保留未知；不从本局失败拟合输出或保血权重。"),
    ("66532328a585941f", "5PM6JAQG6FNQ F39末试T2（对照同局F33）",
     "d268455、s274379/274380：无毒目标THE_LOST 35血不变、无POISON_POWER、冒泡5→4能量；仅证明该次启动前提未兑现。",
     "当前持有/候选/已建分账及若干机制模型已存在；本批不把这些参考当完整构筑或启动收益函数。",
     "缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；无毒冒泡的局部无效不足制定构筑或启动权重。",
     "同局F33已建立毒雾/触媒/群蛇且赢，敌人与资源也不同，不能当只改启动的对照。",
     "保留持有/入手/施放/已建分账；未来以同起点整战后继验启动规则，本批不拟合阈值。"),
    ("43a76a31ba7bdcfa", "61E2QS63Y9WU F17 T5–6",
     "s273504负敏捷−2，双防御各3；s273504→273508敌HP67→34，与原17+16毒结算观察相容，端点不独自认证逐击因果。",
     "已有负敏捷、毒及SL机制路径，未核到足以覆盖整条SL偏好请求的live实现。",
     "缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利与负敏捷/毒端点不足改变SL范围或阈值。",
     "本局族母首试获胜，不证明其他局同抽换序能救活，也不证明应缩小SL范围。",
     "先固定吸取后的力量/敏捷/毒分项调用，再将任何SL范围或换线偏好作为独立同盘验证；不迁用其他角色结果。"),
    ("5264153a4a4b0e5c", "61E2QS63Y9WU F23 T3–5",
     "s273589/273596双方敌力3→6；s273593/273596按THE_OBSCURA/PARAFRIGHT分别76/14→41/2，玩家25→10。原数组顺序是幻象/本体，不能按index把两者交换。",
     "现有召唤相关路径与未覆盖提示不等于A10本体/幻象全链校准；同敌类型也不是跨召唤实例身份。",
     "缺A10召唤、航行成长、退场与复现全链的冻结生产校准，以及另一focus完整后继；已有源码和T4端点不能认证目标排序整战收益。",
     "focus幻象39伤零损候选未实打；本体47伤线的幻象余2仍攻击，不能预支退场收益。",
     "按真实实体与代际核召唤/退出、当前进阶数据库、永久成长与临时减力；保留所有focus选项，相同推演值并列，不强制首杀。"),
    ("bddfa690a84e03d0", "DUZUBAJ3A8GP F30末试T4–6",
     "s274929/274932/274934甲虫力量2→−4→4、来袭20→14→22；临时减力后恢复且继续成长。睡眠/伤害唤醒/眩晕接续仍需分别核。",
     "现有动作/成长模型与本批端点仅覆盖部分路径，不能凭已见自然醒来断言伤害唤醒全链均正确。",
     "缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新输出血价或固定杀序。",
     "末试T4较首试多扣3敌血也多损2玩家血；全败样本不抹掉即时血价，且没有整场胜线。",
     "冻结睡层/覆甲/伤害唤醒/眩晕后继与移动表，逐状态比较；策略排序须另有同抽后继，当前保留原行为。"),
]
assert ["silent-proposal-" + d[0] for d in details] == dispatch["row"]["proposal_ids"]
results = [{"id": "silent-proposal-" + d[0], "state": "waiting", "reason": d[4]} for d in details]
proposal = ["# 本批静默猎手十项策略提案核验", "", f"记录时间：{timestamp}", "",
            f"批次：{dispatch['batch']}；角色：silent；仅观察A10；base：`{dispatch['base']}`。",
            "本批是已领取队列消费，没有research_request或implementation_request；未扩展到其他提案、其他角色或其他专题。原十份Markdown已逐SHA核验并原字节保存在*.original.md。", "",
            "证据来自本批六局，经共用extract_evidence.py冻结各流source_size；逐行offset/bytes/SHA、显式所属身份及JSON读回见evidence/与envelope-verification.json。原队列、账本与经验分别见assigned-proposals.json、ledger-before.json、linked-experience.json。授权Roy-2026-10-07-learning提供修改权限，不提供游戏事实。", "",
            "37项检查仅是原帧材料核验；同局帧与SL尝试不作独立样本。六局都是既有发现/回归材料，无新盲测、无权重拟合。所有项当前waiting，保留现有行为；不预设必须赢局才能修确定性模型/审计缺口，也不把局部源码存在等同复合提案全部实现。", ""]
for short, where, evidence, current, reason, counter, validation in details:
    ident = "silent-proposal-" + short
    item = assigned[ident]
    proposal += [f"## {ident}", "", item["summary"], "",
                 f"来源任务：{item['source_task']} → strategy-proposal；账本：{', '.join(item['ledger'])}；经验：{', '.join(item.get('experience', [])) or '无独立经验链接'}。", "",
                 f"证据局号/层/回合：{where}。{evidence}", "",
                 "现有行为与live覆盖：" + current, "",
                 "处置：waiting。" + reason, "", "反例/限制：" + counter, "",
                 "预期行为及验证方法：" + validation, "",
                 "预期影响仅限消除已证明的模型/审计缺口，不承诺胜率。未来新增代码按固定输入做撤源码失败/恢复通过及原沙箱检查；行为发布依原live流程、版本和双通知。本批无生产源码可回退；保留原提案、账本与所有失败材料。", ""]
(HERE / "proposal.md").write_text("\n".join(proposal))

totals = {k: sum(c["summary"][k] for c in consumers) for k in consumers[0]["summary"]}
report = ["# 静默猎手策略队列：本批十项处置报告", "", f"记录时间：{timestamp}", "",
          "本批十项均waiting：没有核到可关闭整个原提案的新实现证据，也没有足够数据制定新的预算、血价、SL阈值、构筑启动或固定目标顺序。完成了原提案/账本/自身经验/六局原日志/现有live窄源码及离线消费者核验，具体缺口逐项保留。没有生产源码或知识变更、源码提交、合入、eval版本或shipped声明。", "",
          f"base：`{dispatch['base']}`；本树git merge --no-edit main返回Already up to date。worktree：{HERE.parents[2]}。",
          f"本批batch={dispatch['batch']}、task=strategy-proposal、character=silent、reason=proposal；proposal_ids精确十项，无研究或实现绑定。根notes/strategy-research-silent.json属于旧批，不符合本批专题条件，仅保留普通领取范围。派发行及原队列快照见dispatch.json和assigned-proposals.json。", "",
          "## 原始证据", "", "六局runs.jsonl均SILENT/A10，原运行代码均带dirty；见verified-runs.json。只从六局和本角色已链接经验学习，没有把其他角色的知识、预训练规则或当前源码当原局事实。", "",
          "共用入口提取8流，逐行复核原offset/bytes/SHA、JSON和显式run_id/state.run_id/run/fingerprint.run，一共6995行。未按正文提及认领。全源无效JSON计数不代表属于本六局；fight-plans零行只说明本截点未选到，不证明原流不存在。", "",
          "| 流 | source_size（字节） | 本批所属行 |", "|---|---:|---:|"]
for item in manifest:
    report.append(f"| {item['stream']} | {item['source_size']} | {sum(item['counts'].values())} |")
report += ["", "37项原帧检查最终通过，见fact-checks.json、checked-state-projections.json和verify-evidence.final.log；它们是材料验证，不是tsc/Vitest或新增源码红绿。覆盖神化已见升级、药水真实能量/HP、蚌/负敏捷/毒/召唤成长/甲虫临减力及无毒冒泡端点、SL同盘实际HP差。", "",
           "核验脚本r1把胧光本体/幻象按数组位置列成期望顺序，原帧实际顺序相反，断言真实失败。已改为THE_OBSCURA/PARAFRIGHT按类型定位，仅用于名单不变且类型唯一的端点；r1源码、log和失败事实保存*.r1.txt，r2及最终日志保留。该材料脚本修正不是游戏机制反证或生产源码红绿。另有只读探测将空combat/空手牌当非空、猜测文件路径不存在，以及一次沙箱glob扫描遇并行回收路径消失的失败，均已保留原生工具记录；未据此断言证据丢失或产品故障。", "",
           "## 当前离线消费者实际读回", "",
           "在本树使用既有learner/audit-selection.ts，输入仅为本次已验原帧和已核runs，保留真实_line与_source_sha256。node/tsx离线运行，不调LLM、网络、模拟或游戏API，也不读取刷新知识JSON。consumer/保留全部输入、stdout/stderr及SHA，consumer-readback.json保存命令、退出码、明确排除与汇总。", "",
           "VLZ、8JRE、5PM完整输入rc0。CA5第267143行、61E第267517行、DUZU第268789/268818/268864行缺decision_id，完整输入真实rc1拒收；只排除这5行后另存有界输入rc0，保留原行和物理缺口，不补造ID，不称完整局输入成功。", "",
           "| 局号 | 带ID动作 | 候选片段 | 相邻动作端点 | 终局端点 | 整轮端点 | 未知轮窗口 |", "|---|---:|---:|---:|---:|---:|---:|"]
for c in consumers:
    s = c["summary"]
    report.append(f"| {c['run_id']} | {s['actions']} | {s['segments']} | {s['observed_action_endpoints']} | {s['terminal_endpoints']} | {s['observed_turn_endpoints']} | {s['unknown_turn_windows']} |")
report += ["", f"合计{totals['actions']}个带ID动作、{totals['segments']}个片段、{totals['observed_action_endpoints']}个相邻动作端点、{totals['terminal_endpoints']}个终页端点、{totals['observed_turn_endpoints']}个整轮端点、{totals['unknown_turn_windows']}个未知轮窗口。完整候选认证为0，因为现有消费者明确将actual_full_candidate_result保留为null；这不是观测到没有候选被执行，也不能据此推断策略失败。", "",
           "## 已有源码与live祖先", "",
           f"只读live快照：`{source['live_snapshot']}`。19精确源码叶中17叶base/live同字节，card-model.ts与sl/explore.ts仅历史Roy/Dai署名注释不同，未覆盖这些差异。全部本树源码仍与base一致。source-verification.json保存逐叶SHA及真实祖先判断，baseline-worktree.patch为空；不据19叶相同推断旧dirty知识或全生产输入已经冻结。", ""]
for c in source["commits"]:
    report.append(f"- {c['topic']}：`{c['commit']}`；base祖先={str(c['base_ancestor']).lower()}、live祖先={str(c['live_ancestor']).lower()}。")
report += ["", "这些都是已有窄实现，不能当本批提交/合入，不能据此把宽提案登记implemented/duplicate。神化实际施放字段仍null；三阶段预测与动作回执不证明整候选执行；未来阈值/预算/目标收益的受控验证另行保留，不拿这类未知阻止有充分证据的窄审计或纯模型修复。", "",
           "## 逐项处置", "", "完整证据、账本、反例、当前覆盖、预期行为与验证见proposal.md及十份*.original.md。", "",
           "| 原提案 | 状态 | 本批具体未完成原因 |", "|---|---|---|"]
for row in results:
    report.append(f"| {row['id']} | waiting | {row['reason']} |")
report += ["", "## 记录、检查与限制", "",
           "26个原账本只经根learner/ledger.py update追加本批where.proposal和note追溯；输入ledger-updates.jsonl、执行日志ledger-update.stdout.txt/ledger-update.stderr.txt及append核验单独保留。没有新增支持/重复/反例计数，不改旧claim、first_run、prior、evidence、status、version或shipped，不新建重复提案id；原队列状态由调度器消费proposal_results。", "",
           "本批无生产源码提交，因此撤生产源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行或借用生产测试成功。没有启动live合入流程，不造空合并/版本/上线decision-log或规则双通知。全部生产代码与知识不变，铁甲及其他角色行为等价。", "",
           "六局为已用历史发现/回归证据，不是时间后置盲测；SL尝试不能扩成独立局；当前源码/有限固定帧不复原旧dirty源码、知识、随机池和移动表。没有未选线的受控整战结果，整战收益和新权重保持未知。未读取key/.env、游戏二进制或其他角色知识；未运行play、停止对局、推送、联网、改运维prompt或启动下级agent。", "",
           "本工具接口未给出本原生模型请求的可独立核验model/reasoning/service回执；不凭任务文字冒称已完成运行强度切换，本次未修改模型/账号/权限配置。", "",
           "report.base保持上述完整40位HEAD，fixes=[]、merged=null；最终工作树/账本追加核验见final-verification.json及ledger-append-verification.json。本次报告不关闭任何学习入库父要求，不宣称经验库发布或大脑自然采用。", ""]
(HERE / "report.md").write_text("\n".join(report))

updates = []
for ledger_id in sorted({i for p in assigned.values() for i in p["ledger"]}):
    related = [r["id"] for r in results if ledger_id in assigned[r["id"]]["ledger"]]
    updates.append({"id": ledger_id, "by": "learner:strategy-proposal", "where": {"proposal": [str(HERE / "proposal.md"), str(HERE / "report.md")]},
                    "note": dispatch["batch"] + "已核原帧/已有live窄实现/离线消费者；关联" + ",".join(related) + "继续waiting，具体缺口见本批report.md；仅追溯链接，不新增support/repeat或改变历史状态。"})
(HERE / "ledger-updates.jsonl").write_text("".join(json.dumps(u, ensure_ascii=False) + "\n" for u in updates))
result = {"task": "strategy-proposal", "character": "silent", "batch": dispatch["batch"], "base": dispatch["base"],
          "runs": dispatch["row"]["runs"], "fixes": [], "skipped": [{"id": r["id"], "reason": r["reason"]} for r in results],
          "merged": None, "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": dispatch["row"]["proposal_ids"], "implementation_domains": [],
          "proposal_results": results, "report": str(HERE / "report.md")}
(HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"proposal_results": len(results), "ledger_links": len(updates), "report": result["report"]}, ensure_ascii=False))

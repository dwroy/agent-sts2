# 静默猎手策略队列：本批十项处置报告

记录时间：2026-10-16T19:25:02+08:00

本批十项均waiting：没有核到可关闭整个原提案的新实现证据，也没有足够数据制定新的预算、血价、SL阈值、构筑启动或固定目标顺序。完成了原提案/账本/自身经验/六局原日志/现有live窄源码及离线消费者核验，具体缺口逐项保留。没有生产源码或知识变更、源码提交、合入、eval版本或shipped声明。

base：`6f73180eeabc9c071c29dc355a794dbd8ed4d1e8`；本树git merge --no-edit main返回Already up to date。worktree：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-191302。
本批batch=20261016-191302-strategy-proposal、task=strategy-proposal、character=silent、reason=proposal；proposal_ids精确十项，无研究或实现绑定。根notes/strategy-research-silent.json属于旧批，不符合本批专题条件，仅保留普通领取范围。派发行及原队列快照见dispatch.json和assigned-proposals.json。

## 原始证据

六局runs.jsonl均SILENT/A10，原运行代码均带dirty；见verified-runs.json。只从六局和本角色已链接经验学习，没有把其他角色的知识、预训练规则或当前源码当原局事实。

共用入口提取8流，逐行复核原offset/bytes/SHA、JSON和显式run_id/state.run_id/run/fingerprint.run，一共6995行。未按正文提及认领。全源无效JSON计数不代表属于本六局；fight-plans零行只说明本截点未选到，不证明原流不存在。

| 流 | source_size（字节） | 本批所属行 |
|---|---:|---:|
| states | 13615328878 | 3432 |
| decisions | 2026157101 | 3306 |
| sl-attempts | 43865613 | 29 |
| run-config | 1895188 | 6 |
| run-plans | 8621197 | 33 |
| brain | 686334717 | 183 |
| runs | 351918 | 6 |
| fight-plans | 2233957 | 0 |

37项原帧检查最终通过，见fact-checks.json、checked-state-projections.json和verify-evidence.final.log；它们是材料验证，不是tsc/Vitest或新增源码红绿。覆盖神化已见升级、药水真实能量/HP、蚌/负敏捷/毒/召唤成长/甲虫临减力及无毒冒泡端点、SL同盘实际HP差。

核验脚本r1把胧光本体/幻象按数组位置列成期望顺序，原帧实际顺序相反，断言真实失败。已改为THE_OBSCURA/PARAFRIGHT按类型定位，仅用于名单不变且类型唯一的端点；r1源码、log和失败事实保存*.r1.txt，r2及最终日志保留。该材料脚本修正不是游戏机制反证或生产源码红绿。另有只读探测将空combat/空手牌当非空、猜测文件路径不存在，以及一次沙箱glob扫描遇并行回收路径消失的失败，均已保留原生工具记录；未据此断言证据丢失或产品故障。

## 当前离线消费者实际读回

在本树使用既有learner/audit-selection.ts，输入仅为本次已验原帧和已核runs，保留真实_line与_source_sha256。node/tsx离线运行，不调LLM、网络、模拟或游戏API，也不读取刷新知识JSON。consumer/保留全部输入、stdout/stderr及SHA，consumer-readback.json保存命令、退出码、明确排除与汇总。

VLZ、8JRE、5PM完整输入rc0。CA5第267143行、61E第267517行、DUZU第268789/268818/268864行缺decision_id，完整输入真实rc1拒收；只排除这5行后另存有界输入rc0，保留原行和物理缺口，不补造ID，不称完整局输入成功。

| 局号 | 带ID动作 | 候选片段 | 相邻动作端点 | 终局端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |

合计3301个带ID动作、476个片段、859个相邻动作端点、4个终页端点、121个整轮端点、413个未知轮窗口。完整候选认证为0，因为现有消费者明确将actual_full_candidate_result保留为null；这不是观测到没有候选被执行，也不能据此推断策略失败。

## 已有源码与live祖先

只读live快照：`a14ebd0592f0cba9f7d3053eb5809754dd78ee2d`。19精确源码叶中17叶base/live同字节，card-model.ts与sl/explore.ts仅历史Roy/Dai署名注释不同，未覆盖这些差异。全部本树源码仍与base一致。source-verification.json保存逐叶SHA及真实祖先判断，baseline-worktree.patch为空；不据19叶相同推断旧dirty知识或全生产输入已经冻结。

- ordinary_upgrade：`772b839f8ada31664cb764ea9ad3bdb03da27f64`；base祖先=true、live祖先=true。
- accelerant_upgrade：`f516592fff557ef02c8ece43433706358c3f7fe6`；base祖先=true、live祖先=true。
- apotheosis_reference：`3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17`；base祖先=true、live祖先=true。
- malaise_upgrade：`b2805be4ba44b7375c7908d873889372cc3cfe6c`；base祖先=true、live祖先=true。
- deadly_poison_upgrade：`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`；base祖先=true、live祖先=true。
- selection_snapshots：`05cd292c6f01bb31e406473d3a9843e659d62b93`；base祖先=true、live祖先=true。
- guard_sl_audit：`a8b1f8be153fe4f3a34146117546c2178f2e446b`；base祖先=true、live祖先=true。
- offline_consumer：`cf72bd21148059f111f760cc98a727369e34a47e`；base祖先=true、live祖先=true。
- offline_terminal：`83512ddcd2c70fd9b983dc38524ff25c8970c1d3`；base祖先=true、live祖先=true。

这些都是已有窄实现，不能当本批提交/合入，不能据此把宽提案登记implemented/duplicate。神化实际施放字段仍null；三阶段预测与动作回执不证明整候选执行；未来阈值/预算/目标收益的受控验证另行保留，不拿这类未知阻止有充分证据的窄审计或纯模型修复。

## 逐项处置

完整证据、账本、反例、当前覆盖、预期行为与验证见proposal.md及十份*.original.md。

| 原提案 | 状态 | 本批具体未完成原因 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水、重问、SL及换战的实际施放持续身份核验；现有有限升级配对和参考字段不足关闭整项。未知属性交互仍须按实见范围验证。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型及冻结随机池下同起点、同总预算的配对实验、候选稳定性/样本成熟度曲线和留药完整后继；707ms单题不足修改预算、药价或focus。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化项仍缺实际施放持续身份和跨中断验证；仅同题、同证据或已有窄源码不足把独立经验来源链登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺15个子项在同一冻结生产输入下的逐源联合验证，尤其属性/升级组合、状态期限与战斗/路线/休息资源接续；局部端点不足关闭复合项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；本批离线端点仍只能确认有界观测，原审计增量未完整覆盖。改变护栏/SL偏好还另缺受控未选线后继。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺同一冻结调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血/输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；无毒冒泡的局部无效不足制定构筑或启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利与负敏捷/毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行成长、退场与复现全链的冻结生产校准，以及另一focus完整后继；已有源码和T4端点不能认证目标排序整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新输出血价或固定杀序。 |

## 记录、检查与限制

26个原账本只经根learner/ledger.py update追加本批where.proposal和note追溯；输入ledger-updates.jsonl、执行日志ledger-update.stdout.txt/ledger-update.stderr.txt及append核验单独保留。没有新增支持/重复/反例计数，不改旧claim、first_run、prior、evidence、status、version或shipped，不新建重复提案id；原队列状态由调度器消费proposal_results。

本批无生产源码提交，因此撤生产源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行或借用生产测试成功。没有启动live合入流程，不造空合并/版本/上线decision-log或规则双通知。全部生产代码与知识不变，铁甲及其他角色行为等价。

六局为已用历史发现/回归证据，不是时间后置盲测；SL尝试不能扩成独立局；当前源码/有限固定帧不复原旧dirty源码、知识、随机池和移动表。没有未选线的受控整战结果，整战收益和新权重保持未知。未读取key/.env、游戏二进制或其他角色知识；未运行play、停止对局、推送、联网、改运维prompt或启动下级agent。

本工具接口未给出本原生模型请求的可独立核验model/reasoning/service回执；不凭任务文字冒称已完成运行强度切换，本次未修改模型/账号/权限配置。

report.base保持上述完整40位HEAD，fixes=[]、merged=null；最终工作树/账本追加核验见final-verification.json及ledger-append-verification.json。本次报告不关闭任何学习入库父要求，不宣称经验库发布或大脑自然采用。

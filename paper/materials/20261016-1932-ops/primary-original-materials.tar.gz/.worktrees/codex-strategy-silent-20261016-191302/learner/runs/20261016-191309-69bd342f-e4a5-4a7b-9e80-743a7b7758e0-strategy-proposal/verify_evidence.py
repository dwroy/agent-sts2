"""Verify preserved envelopes and bounded observations; never simulate a counterfactual."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
spec = importlib.util.spec_from_file_location("batch_extractor", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((HERE / "dispatch.json").read_text())
runs = dispatch["row"]["runs"]
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
streams = {}
verification = []
for item in manifest:
    name = item["stream"]
    path = HERE / "evidence" / (name + ".evidence.jsonl")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item["output_sha256"]
    counts = dict.fromkeys(runs, 0)
    rows = []
    with path.open() as envelopes, Path("/home/dw/Projects/agent-sts2/logs", name + ".jsonl").open("rb") as source:
        for raw in envelopes:
            envelope = json.loads(raw)
            assert envelope["offset"] + envelope["bytes"] <= item["source_size"]
            source.seek(envelope["offset"])
            original = source.read(envelope["bytes"])
            assert len(original) == envelope["bytes"] and original.endswith(b"\n")
            assert hashlib.sha256(original).hexdigest() == envelope["sha256"]
            assert json.loads(original) == envelope["row"]
            assert extractor.run_identity(envelope["row"]) == envelope["run_id"] in runs
            counts[envelope["run_id"]] += 1
            rows.append(envelope)
    assert counts == item["counts"]
    streams[name] = rows
    verification.append({"stream": name, "source_size": item["source_size"], "verified": len(rows), "counts": counts})

run_rows = {r["run_id"]: r["row"] for r in streams["runs"]}
assert set(run_rows) == set(runs)
assert all(r["character"].lower() == "silent" and r["ascension"] == 10 for r in run_rows.values())
(HERE / "envelope-verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2) + "\n")
(HERE / "verified-runs.json").write_text(json.dumps(run_rows, ensure_ascii=False, indent=2) + "\n")
states = {r["line"]: r["row"] for r in streams["states"]}
decisions = {r["line"]: r["row"] for r in streams["decisions"]}
checks = []


def check(statement, actual, expected, lines):
    result = {"statement": statement, "actual": actual, "expected": expected, "source_lines": lines, "passed": actual == expected}
    checks.append(result)
    (HERE / "fact-checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
    assert result["passed"], result


def combat(line):
    return states[line]["state"]["combat"]


def player(line, key):
    return combat(line)["player"][key]


def power(entity, ident):
    return next((p["amount"] for p in entity["powers"] if p["power_id"] == ident), 0)


def enemy(line, ident=None):
    return next(e for e in combat(line)["enemies"] if ident is None or e["enemy_id"] == ident)


def threat(e):
    return sum(i.get("total_damage") or 0 for i in e["intents"])


def card_value(line, ident, name):
    return [v["current_value"] for c in combat(line)["hand"] if c["card_id"] == ident
            for v in c["dynamic_values"] if v["name"] == name]


for before, after in [(275564, 275565), (275679, 275680), (275594, 275595)]:
    check("神化实付2能量", player(before, "energy") - player(after, "energy"), 2, [before, after])
for ident, name, before, after in [("DEFEND_SILENT", "Block", [5], [8]),
                                  ("STRIKE_SILENT", "Damage", [7], [10]),
                                  ("DAGGER_SPRAY", "Damage", [5], [7])]:
    check("F35神化后" + ident, [card_value(n, ident, name) for n in [275564, 275565]], [before, after], [275564, 275565])
check("F35必备工具费用", [[c["energy_cost"] for c in combat(n)["hand"] if c["card_id"] == "TOOLS_OF_THE_TRADE"] for n in [275564, 275565]], [[1], [0]], [275564, 275565])
for ident, name, before, after in [("SUCKER_PUNCH", "Damage", [9], [11]),
                                  ("SUCKER_PUNCH", "WeakPower", [1], [2]),
                                  ("FASTEN", "ExtraBlock", [4], [6]),
                                  ("PIERCING_WAIL", "StrengthLoss", [6], [8])]:
    check("F43神化后" + ident + "/" + name, [card_value(n, ident, name) for n in [275679, 275680]], [before, after], [275679, 275680])
check("F43后续毒雾升级", [(c["upgraded"], card_value(275687, "NOXIOUS_FUMES", "PoisonPerTurn")) for c in combat(275687)["hand"] if c["card_id"] == "NOXIOUS_FUMES"], [(True, [3])], [275687])
check("F45药水能量与血量", [[player(n, "energy"), player(n, "current_hp")] for n in [275728, 275729]], [[1, 67], [2, 67]], [275728, 275729])
check("F45药水后实际手牌", [c["card_id"] for c in combat(275729)["hand"]], ["APOTHEOSIS", "TOOLS_OF_THE_TRADE", "SURVIVOR"], [275729])
check("F45末轮血量格挡与显示来袭", [player(275754, "current_hp"), player(275754, "block"), sum(threat(e) for e in combat(275754)["enemies"])], [32, 20, 59], [275754])
check("F45末轮覆甲已耗尽", power(combat(275754)["player"], "PLATING_POWER"), 0, [275754])
check("蚌成长力量", [power(enemy(n), "STRENGTH_POWER") for n in [273237, 273252, 273263]], [0, 4, 8], [273237, 273252, 273263])
check("蚌同招来袭", [threat(enemy(n)) for n in [273237, 273252, 273263]], [11, 15, 19], [273237, 273252, 273263])
check("虚弱没有取消蚌成长", [threat(enemy(n)) for n in [273257, 273268]], [11, 14], [273257, 273268])
check("族母后负敏捷", power(combat(273504)["player"], "DEXTERITY_POWER"), -2, [273504])
check("负敏捷防御牌面", card_value(273504, "DEFEND_SILENT", "Block"), [3, 3], [273504])
check("族母当轮净扣33端点", [enemy(n)["current_hp"] for n in [273504, 273508]], [67, 34], [273504, 273508])
check("胧光T4本体/幻象端点（按敌人类型，非数组位置）", [[enemy(n, ident)["current_hp"] for ident in ["THE_OBSCURA", "PARAFRIGHT"]] for n in [273593, 273596]], [[76, 14], [41, 2]], [273593, 273596])
check("胧光T4玩家端点", [player(n, "current_hp") for n in [273593, 273596]], [25, 10], [273593, 273596])
check("胧光两次航行力量", [[power(e, "STRENGTH_POWER") for e in combat(n)["enemies"]] for n in [273589, 273596]], [[3, 3], [6, 6]], [273589, 273596])
check("甲虫临减力后恢复成长", [power(enemy(n, "SLUMBERING_BEETLE"), "STRENGTH_POWER") for n in [274929, 274932, 274934]], [2, -4, 4], [274929, 274932, 274934])
check("甲虫临减力与后轮来袭", [threat(enemy(n, "SLUMBERING_BEETLE")) for n in [274929, 274932, 274934]], [20, 14, 22], [274929, 274932, 274934])
check("无毒冒泡实付1能", [player(n, "energy") for n in [274379, 274380]], [5, 4], [274379, 274380, 268455])
check("无毒冒泡目标未掉血", [enemy(n, "THE_LOST")["current_hp"] for n in [274379, 274380]], [35, 35], [274379, 274380])
check("无毒冒泡未建立毒", [power(enemy(n, "THE_LOST"), "POISON_POWER") for n in [274379, 274380]], [0, 0], [274379, 274380])
check("8JRE两次T2同指纹", decisions[270216]["fingerprint"] == decisions[270282]["fingerprint"], True, [270216, 270282])
numbers = decisions[270282]["sl_explore"]["numbers"]
check("SL原线与换线死亡样本不同", ["dead 0/24" in numbers["original"], "dead 5/24" in numbers["replacement"]], [True, True], [270282])
rollout = decisions[269748]["rollout"]
check("VLZ首题退化而非明确并列", [rollout["horizon"], rollout["samples"], rollout["best"]], [1, 1, None], [269748])
mc = decisions[269748]["potions"]["random"][0]
check("VLZ药水抽样成熟度与预算", [mc["samples"], mc["requested"], mc["ms"]], [1, 12, 707], [269748])
forecast = []
for n in [269706, 269707]:
    row = decisions[n]
    value = row["questions"]["plan"]["criteria"][row["answers"]["plan"]["choice"]]
    value = json.loads(value) if isinstance(value, str) else value
    forecast.append([value["damage_dealt"], value["hp_lost"]])
check("F43神化前后同后续序列的两次预测", forecast, [[43, 14], [51, 13]], [269706, 269707])

# Match observed endpoints through the exact timestamp and fingerprint, without attributing a whole candidate.
state_index = {}
for n, row in states.items():
    key = (row.get("observed_ts"), row.get("fingerprint"))
    state_index.setdefault(key, []).append((n, row))


def matched(row):
    candidates = state_index[(row["observed_ts"], row["fingerprint"])]
    assert len(candidates) == 1
    n, frame = candidates[0]
    assert frame["state"]["run_id"] == row["run_id"]
    return n


for n, expected in [(270216, [-3, -10]), (270282, [-15, -17])]:
    d = decisions[n]
    successors = [(m, r) for m, r in decisions.items() if m > n and r.get("run_id") == d["run_id"]
                  and r.get("floor") == d["floor"] and r.get("turn") == d["turn"] + 1
                  and r.get("sl_attempt") == d.get("sl_attempt") and r.get("sl_reloads") == d.get("sl_reloads")]
    m, successor = min(successors)
    a, b = matched(d), matched(successor)
    check("8JRE T2实际玩家与敌人HP端点差", [player(b, "current_hp") - player(a, "current_hp"), enemy(b)["current_hp"] - enemy(a)["current_hp"]], expected, [n, m, a, b])

selected_lines = {n for c in checks for n in c["source_lines"]}
projections = []
for item in streams["states"]:
    if item["line"] not in selected_lines:
        continue
    row, s = item["row"], item["row"]["state"]
    c = s.get("combat") or {}
    projections.append({k: v for k, v in item.items() if k != "row"} | {
        "floor": (s.get("run") or {}).get("floor"), "turn": s.get("turn"), "screen": s.get("screen"),
        "observed_ts": row.get("observed_ts"), "player": c.get("player"), "hand": c.get("hand"), "enemies": c.get("enemies")})
(HERE / "checked-state-projections.json").write_text(json.dumps(projections, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_envelopes": sum(v["verified"] for v in verification), "fact_checks": len(checks), "all_passed": all(c["passed"] for c in checks)}, ensure_ascii=False))

# 静默猎手策略学习报告

记录时间：2026-10-16T11:10:52+08:00。本批十个原提案全部核对，均waiting；没有源码/知识修改、提交、live合入、发布编号或shipped。本报告不关闭学习入库或量化学习宽父要求。逐项原账本、层/回合、反例、预期行为与验证在proposal.md，机器结果在result.json。

## 身份与基线

batch=20261016-105929-strategy-proposal，task=strategy-proposal，character=silent，reason=proposal；根learn.json仅对应行保存在dispatch.json。角色、六局集合、工作树及十个proposal_ids匹配；没有proposal_repair、research_request或implementation_request。普通专题根请求绑定旧batch，不符合本批条件；未承接其他专题，没有使用纯研究完成口径。没有下级agent。

开工git status空；普通任务执行git merge --no-edit main返回Already up to date。完整base与目标最终HEAD为`ff866b99467d3763aea0d3011c348783e05feb42`。原提案十份均按专用队列原SHA核对并保存，未改原文、不新建ID、不直接写队列或调度状态。六局runs.jsonl显式身份均SILENT/A10，完整结束均负局；PU F17的SL实胜属于其中一战，不与整局胜负混用。

## 原证据和可重现边界

共用extract_evidence.py提取八流，冻结source_size并保留原行号、offset/bytes/SHA和原JSON。analyze.py逐行回读原日志，身份/字节/SHA/JSON/顺序/计数全部通过，共8444条。run-plans使用run，其他流使用显式run_id/state.run_id/fingerprint.run；冲突身份拒收，不按正文提及归属。fight-plans零行仅表示本次截点未选到，不声称历史缺失。全源跳过的无效JSON没有认定属于本六局。没有复核或覆盖旧零行初稿。

| 流 | source_size字节 | 已核本批所属行 |
|---|---:|---:|
| states | 13457660603 | 4167 |
| decisions | 1875918229 | 4071 |
| sl-attempts | 42895269 | 43 |
| run-config | 1850737 | 6 |
| run-plans | 8482239 | 21 |
| brain | 662973171 | 130 |
| runs | 346458 | 6 |
| fight-plans | 2233957 | 0 |

提取一次完成；分析第一轮保存analysis.stdout/stderr，加入KV两组和有界消费者输入后的r2单独保存。未删除初稿。材料算术和槽位边界40/40通过，见material-checks.json；这些是材料校验，不是生产测试或模型校准。

## 支持、反例和结论

| 同指纹配对 | 原/替净损血 | 原/替敌净扣 | 限制 |
|---|---:|---:|---|
| 751 F17 T2，272434/272575 | 13/18 | 9/18 | 多5血换9净扣，后轮不同 |
| 751 F17 T7，272531/272652 | 13/23 | 12/18 | 多10血换6净扣，未决弃牌保守值不冒作实际失血 |
| KEN F17 T10，274505/274568 | 15/21 | 2/4 | 多6血换2净扣，非整战胜率证据 |
| KEN F17 T5，274484/274601 | 7/5 | 1/2 | 存在后续追加动作和能力建立窗口变化 |
| KV F33 T5，273400/273450 | 0/0 | 36/29 | 删输出未有当轮保血收益 |
| KV F33 T1，273242/273474 | 0/0 | 28/14 | 后续重问/replay另列，不是整线因果 |

配对起点由observed_ts和fingerprint唯一关联，终点取同层下一轮原状态；本表只描述净端点，不能命名为逐来源毛伤、单卡因果或完整候选结果。paired-observations.json保存底板、后帧、sl_explore及journal。相关六次SL按一个局，不拆训练/验证，不拟通用血价或关闭更差线探索。

YQL F17 T10 states280160/280161直接核：本体结束后的占位血max999999999、EXPLODE_MOVE/DeathBlow41，饮毒药后毒2→8而26血/13挡/41来袭保持。加6毒不作减6自爆或本体进度；提前喝、不喝与留药的完整结果未知。L9/YQL六试均未胜；PU F17第5试T15实胜余2血（sl-attempts719）是反例，不因占位血或短存活排序简单否定。原anchor 681/717/960–963确有近十亿占位残血排序，现源码仍保留旧tie-break。阶段提示/指标已有实现，不把更改排序当已证收益。

KEN七次饮药请求及对应前后槽位全部核实，三次仍pending接口回执；槽位后帧为空与完整随机选牌/重问收益不同。F13肌肉药水的有药、当轮无药与整战无药参考分开，成本0/缺表不能改称持有价值0。KV F17首试实胜余9血（sl-attempts951）保留，不从后续失败反推升级或休息错误。

## 现有实现与消费者

只读live锚点`0e7998bfa8df267dcf8835a57949bdb982c9feb0`。16个相关源码叶最后提交均核为实际live祖先；14叶与本base相同，potion-cost.ts和sl/explore.ts差异仅既有Roy/Dai注释文字，source-live-diff.patch保留原差异，未合入或改写。具体路径/SHA/40位提交在source-audit.json，不声称两完整树相等。

已实现窄子项包括持牌失血预测（9d8278702dbc581b5015ba7ec9a70dc0fb94cccb）、持药未知/无药参考（c4670f4f416c7d93e192e889c5080e7e4e0e733f）、巨兽残壳药水事实（40168f4a903ae1d8c48bd03006f8fea19fd3aa3c）、候选SL比较（66283dd9982bdd7f480da7a4d9bfefea0572a9ac）、单动作派发回执（fdaf787a372880b0438e73bcac7e6d2168b038ed）、SL阶段记录/原排序（b01edf46b4b619f217d070a196e161df9fe716a0）。它们不等于本批新实现，不能用一个窄字段把宽提案置implemented/duplicate。

consumer.mjs以当前现有auditSelectionExecution对六份冻结单局输入作有界读回，进程exit0：共566个题段、2328个动作、2103个相邻观测端点、379个可核整轮窗口及116个unknown窗口；完整候选认证0。KEN line274207缺decision_id排除，未补造ID，全部输入/输出gzip及SHA可核。状态只投影消费者实际读取字段、保留原行/SHA，决策仅去agent_view；输入转换在analyze.py。没有调用LLM/网络/游戏、读取刷新知识JSON或跑整场模拟；这些结果是固定离线读回，不冒作自然采用、历史全输入复原、策略收益或联合生产校准。

六份run-config完整源码commit都可在Git定位，dirty_files只列knowledge/notes；缺的是当时刷新知识/移动表具体字节与完整联合输入，不笼统写源码丢失，也不用今天的数据替代。historical-config.json保留原提交和脏路径。当前消费者明确actual_turn/actual_full_candidate_result/whole_plan_executed未知，预测拆项不当实际完整收益。

## 逐项处置

| 派发ID | 结果 | 具体缺数据原因 |
|---|---|---|
| silent-proposal-366288801d9150d9 | waiting | 三组SL成本审计的原要求保留。现有候选/SL预测、持牌失血及动作回执已有实际live祖先；缺抽弃重问后的完整候选身份、逐来源结算及受控整战后继，不能拟固定SL血价。 |
| silent-proposal-85929bdfc8a3fc1b | waiting | 持牌保守损血、持有价值未知和无药参考已有窄实现；缺真实无药整战、留药后战及抽弃续问后的完整执行收益，不能由缺表成本0改成留药价值0。 |
| silent-proposal-efd9f83ee9e1a6dc | waiting | 现有预测拆项不覆盖实际整线执行；751六试没有完整胜线，缺保持后轮条件的受控对照及独立局验证，不能由局部血价收窄或关闭更差线探索。 |
| silent-proposal-131042659448ae74 | waiting | 敏捷、毒、荆棘和呼唤有分项观测及现有提示；缺联合逐来源实际累计、完整候选执行和跨战留药对照，不能将分项机制成立当组合收益已验收。 |
| silent-proposal-990f054036609447 | waiting | 同指纹T5净扣36→29、T1净扣28→14且均零损已核；严格轮窗仍有unknown，缺敌回血毛伤逐来源、完整候选和路线休息替代后继。 |
| silent-proposal-e18d3f18e6cac2a0 | waiting | 巨兽本体/残壳提示、末态资源已有实际live实现；旧同轮参考排序仍使用占位HP，缺改序后的受控完整后继，不能以窄阶段字段关闭完整策略提案。 |
| silent-proposal-9733bb80f445aeae | waiting | 残壳施毒只观察2→8而血挡/41自爆保持；缺提前喝、不喝、留药及新排序的完整分支，不能将加6毒视为减6自爆或整战无效。 |
| silent-proposal-c51468c5e8ba6668 | waiting | 七次用药请求及所点槽后帧为空已核，其中三次接口回执仍pending；缺随机选牌、发光水重问后的完整收益及留药后战对照。 |
| silent-proposal-86a7db08d1a31976 | waiting | 同指纹T10多失6血仅多2敌净扣、T5省2血但能力窗口改变已核；缺逐来源完整兑现、相同后轮对照与独立验证，不能拟固定SL血价。 |
| silent-proposal-e282a9131b99129a | waiting | 同指纹血价与能力窗口只支持局部取舍；已有预测拆项，缺完整候选认证及受控后继，不拟统一6血/2伤阈值或声称改线必胜。 |

没有新反证推翻既有机制，没有新增游戏经验或拟合门槛；沿原ID保留waiting待新证据。原提案历史总体分母不充作本次覆盖，不扩展到其他队列或角色。

## 记录、验证与交付

仅经根learner/ledger.py update为16个已有silent账本追加本批proposal/report追溯与说明，by=learner:strategy-proposal；不重复support/repeat，不改claim、首证、prior、evidence、status、version或shipped。旧项已shipped时不降级proposed；本批没有需要新增proposed条目的新知识。实际CLI输入/退出码及保护字段读回另存。

本批无生产源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases全部null；未运行生产套件，不伪造成功。fixes=[]、merged=null，无源码提交、合入提交、eval版本、上线decision记录或规则变更双通知；其他角色行为没有变化。工作树最终保持干净、HEAD不变，最终回执见final-verification.json；材料扫描另存。日志只读，不运行play、不联网、不推送、不改ops prompt、不写根请求或通知ACK。

交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-105929/learner/runs/20261016-105932-c8e1ec51-4d1f-46f5-87d2-28dbc70cc69e-strategy-proposal/proposal.md。

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-105929/learner/runs/20261016-105932-c8e1ec51-4d1f-46f5-87d2-28dbc70cc69e-strategy-proposal/report.md。

最终读回（2026-10-16T11:12:44+08:00）：根账本CLI实际exit0，16条追加逐原行offset/bytes/SHA核验通过，旧物理前缀和保护字段保持；六份消费者输出gzip/解码SHA再核一致。材料gitleaks实际exit0、0命中；HEAD仍等于完整base，git status和git diff --binary均空。

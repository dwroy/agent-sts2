import hashlib
import json
import subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
TREE=HERE.parents[2]
def read(name): return json.loads((HERE/name).read_text())
def write(name,value): (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
stamp=subprocess.check_output(['date','-Is']).decode().strip()
(HERE/'recorded-at.txt').write_text(stamp+'\n')
dispatch=read('dispatch.json'); assigned=read('assigned-proposals.json'); base=(HERE/'base.txt').read_text().strip()
assert len(base)==40
details=[
('751 F17 T2/T7/T13；本批重核 decisions 272434/272575、272531/272652。',
 '三组SL成本审计的原要求保留。现有候选/SL预测、持牌失血及动作回执已有实际live祖先；缺抽弃重问后的完整候选身份、逐来源结算及受控整战后继，不能拟固定SL血价。',
 'T2净损13→18、敌净扣9→18；T7净损13→23、敌净扣12→18。六试同属一局且全败，后轮不同；T13既有6血/6攻取舍只作原证据链接。',
 '先固定T2/T7/T13底板核原答、护栏后与SL后线；保留B2配对差及误差、notWorseOnly/回退来源；完整抽弃序和后轮一致后再比较，不直接关闭更差线探索。'),
('751 F13 T3、F17 T7/T13/T17；decisions 272361/272362。',
 '持牌保守损血、持有价值未知和无药参考已有窄实现；缺真实无药整战、留药后战及抽弃续问后的完整执行收益，不能由缺表成本0改成留药价值0。',
 'F13有药/无药预测都可零额外死亡并同损8；原无药当轮候选后轮仍可能喝，专门无药参考另列。一次已饮用与空药boss失败不证明饮药错误。',
 '固定同题有药、当轮无药、整战无药参考，核后续饮药计数及来源；随机/弃牌重问后重新对账，保留合法选项和原HP护栏。'),
('751 F17 T2/T7/T13；六试 sl-attempts 945–950。',
 '现有预测拆项不覆盖实际整线执行；751六试没有完整胜线，缺保持后轮条件的受控对照及独立局验证，不能由局部血价收窄或关闭更差线探索。',
 'T2多5血换9净扣，T7多10血换6净扣，不存在统一的已证血价；同局六次不能拆训练/验证。',
 '先复用原配对事实和模型审计，按独立局、真实时间留后期验证；不得以六次失败拟通用额外失血门槛。'),
('751 F13 T3、F17 T3/T5/T7/T13/T17；原机制账本及同题原帧。',
 '敏捷、毒、荆棘和呼唤有分项观测及现有提示；缺联合逐来源实际累计、完整候选执行和跨战留药对照，不能将分项机制成立当组合收益已验收。',
 '能力已建立不保证以后有挡牌；无实体下各来源有局部端点，末轮存毒不等于已兑现毒伤。原机制沿既有账本保留，本批不扩统计分母。',
 '逐张挡/攻击/毒/反伤/持牌自损与实际重问动作分账，覆盖原T5/T7/T17，随后核联合消费者；保持未观察组合未知。'),
('KV F33 T5/T1；decisions 273400/273450、273242/273474；另含F16/F28/F29/F32资源窗口。',
 '同指纹T5净扣36→29、T1净扣28→14且均零损已核；严格轮窗仍有unknown，缺敌回血毛伤逐来源、完整候选和路线休息替代后继。',
 '两组删输出都没有当轮保血收益，后续动作变化；F17首试实胜余9血是保留边界，不能把前面升级/资源消耗判错。',
 '保留实际净端点、下一轮毒和敌回血分账，SL恢复不算治疗；同抽序的完整后继与实际路线/休息消费者到齐后再评估规则。'),
('YQL F17 T9/T10/T12/T13；states 280160/280161；L9 F17 T14，PU F17 T17及第5试T15。',
 '巨兽本体/残壳提示、末态资源已有实际live实现；旧同轮参考排序仍使用占位HP，缺改序后的受控完整后继，不能以窄阶段字段关闭完整策略提案。',
 '毒2→8但26血/13挡/41来袭均不变；L9与YQL各六试未胜，而PU第5试实胜剩2血。统一把占位HP置0会改变同轮平局选择，不是已证收益。',
 '保留raw HP与本体0/自爆阶段分列；固定旧新anchor选择及自爆血挡缺口，按L9/PU历史发现、YQL后期复核；未获整战后继前保留排序。'),
('YQL F17 T10；states 280160→280161，decisions 274087；L9/PU F17原阶段边界。',
 '残壳施毒只观察2→8而血挡/41自爆保持；缺提前喝、不喝、留药及新排序的完整分支，不能将加6毒视为减6自爆或整战无效。',
 '当前局部无减伤不推导早喝必胜；毒层不是已结伤害，PU成功反例保留。',
 '用原始两帧核阶段、槽位、HP/挡/来袭；与完整提前饮用和留药支线分开，保持全部药水选项，不拟饮用时点。'),
('KEN F3T2/F4T1/F5T2/F11T1–2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272。',
 '七次用药请求及所点槽后帧为空已核，其中三次接口回执仍pending；缺随机选牌、发光水重问后的完整收益及留药后战对照。',
 '槽位变空支持耗药观测，completed也不证明整方案全部执行；赢战零损不能代无药零损，boss空药不能证明固定留药可胜。',
 '逐槽冻结前后帧和随机选牌/重问，核血量与增益兑现、来源和后战资源； pending不写已确认整线执行，不设留药门槛。'),
('KEN F17 第4/5试T10、第4/6试T5；decisions 274505/274568、274484/274601。',
 '同指纹T10多失6血仅多2敌净扣、T5省2血但能力窗口改变已核；缺逐来源完整兑现、相同后轮对照与独立验证，不能拟固定SL血价。',
 'T5原净损7/扣1、替净损5/扣2，但替线有后续追加动作且步法延迟；少失血不能当能力收益不变，T10多输出不能当更安全。',
 '逐来源核呼唤失血、无实体实际输出及步法建立时点，保留B2差和误差；后轮抽序受控并有独立时间后置验证才评估排序。'),
('KEN F17 T2/T5/T6/T10/T12/T13；本批重点核第4/5试T10与第4/6试T5。',
 '同指纹血价与能力窗口只支持局部取舍；已有预测拆项，缺完整候选认证及受控后继，不拟统一6血/2伤阈值或声称改线必胜。',
 'T10净损15→21、净扣2→4；T5净损7→5同时改变步法建立窗口。六相关尝试不是六个独立样本，原线同样未获完整胜局。',
 '复用原提案的固定局面核验，区分原答、HP护栏、SL与后续重问；保持候选并列、选项和既有探索，等待完整执行与后期独立局。')
]
assert len(details)==len(assigned)==10
results=[]; sections=[]; manifest=[]
for item,detail in zip(assigned,details):
    a=item['add']; window,reason,counter,validation=detail; i=a['id']
    raw=(HERE/(i+'.md')).read_bytes(); sha=hashlib.sha256(raw).hexdigest(); assert sha==a['proposal_sha256']
    manifest.append({'id':i,'source':a['proposal'],'copy':str(HERE/(i+'.md')),'bytes':len(raw),'sha256':sha})
    results.append({'id':i,'state':'waiting','reason':reason})
    sections.append(f"## {i}\n\n角色 silent，已观察 A10；来源 {a['source_task']} → strategy-proposal；授权 Roy-2026-10-07-learning。\n\n证据窗口：{window}\n\n既有账本：{', '.join(a['ledger'])}。来源局：{', '.join(a['runs'])}。\n\n原文：{a['proposal']}，SHA256 `{sha}`；本目录同ID副本保留原字节。\n\n处置：waiting。{reason}\n\n支持、反例与未知：{counter}\n\n预期行为与验证：{validation}\n\n拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。\n\n回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。\n")
proposal=f"# 静默猎手十项原提案逐项处置\n\n记录时间：{stamp}。batch=20261016-105929-strategy-proposal；base={base}。\n\n本批只消费已派发十个ID，没有research_request/implementation_request/proposal_repair；不领取其他题、不新建重复ID。逐份原文SHA核对通过。全部waiting，不改源码、知识或策略；已有诊断子项不能代整项完整验证。\n\n"+'\n'.join(sections)
(HERE/'proposal.md').write_text(proposal)
write('original-proposals-manifest.json',manifest)
result={'task':'strategy-proposal','character':'silent','batch':'20261016-105929-strategy-proposal','base':base,'runs':dispatch['runs'],'fixes':[],
        'skipped':[],'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},
        'code_proposals':dispatch['proposal_ids'],'implementation_domains':[],'proposal_results':results,'report':str(HERE/'report.md')}
write('result.json',result)
raw=read('raw-verification.json'); sources=read('source-audit.json'); consumers=read('consumer-summary.json'); materials=read('material-checks.json')
stream_table='\n'.join(f"| {x['stream']} | {x['source_size']} | {x['verified_rows']} |" for x in raw['streams'])
disposition='\n'.join(f"| {x['id']} | waiting | {x['reason']} |" for x in results)
counts={'segments':sum(x['segments'] for x in consumers),'actions':sum(x['actions'] for x in consumers),
        'observed_turns':sum(x['turns'].get('observed_turn_endpoints',0) for x in consumers),
        'unknown_turns':sum(x['turns'].get('unknown',0) for x in consumers),
        'intervals':sum(x['intervals'].get('observed_endpoints',0) for x in consumers)}
report=f"""# 静默猎手策略学习报告

记录时间：{stamp}。本批十个原提案全部核对，均waiting；没有源码/知识修改、提交、live合入、发布编号或shipped。本报告不关闭学习入库或量化学习宽父要求。逐项原账本、层/回合、反例、预期行为与验证在proposal.md，机器结果在result.json。

## 身份与基线

batch=20261016-105929-strategy-proposal，task=strategy-proposal，character=silent，reason=proposal；根learn.json仅对应行保存在dispatch.json。角色、六局集合、工作树及十个proposal_ids匹配；没有proposal_repair、research_request或implementation_request。普通专题根请求绑定旧batch，不符合本批条件；未承接其他专题，没有使用纯研究完成口径。没有下级agent。

开工git status空；普通任务执行git merge --no-edit main返回Already up to date。完整base与目标最终HEAD为`{base}`。原提案十份均按专用队列原SHA核对并保存，未改原文、不新建ID、不直接写队列或调度状态。六局runs.jsonl显式身份均SILENT/A10，完整结束均负局；PU F17的SL实胜属于其中一战，不与整局胜负混用。

## 原证据和可重现边界

共用extract_evidence.py提取八流，冻结source_size并保留原行号、offset/bytes/SHA和原JSON。analyze.py逐行回读原日志，身份/字节/SHA/JSON/顺序/计数全部通过，共{raw['total_verified']}条。run-plans使用run，其他流使用显式run_id/state.run_id/fingerprint.run；冲突身份拒收，不按正文提及归属。fight-plans零行仅表示本次截点未选到，不声称历史缺失。全源跳过的无效JSON没有认定属于本六局。没有复核或覆盖旧零行初稿。

| 流 | source_size字节 | 已核本批所属行 |
|---|---:|---:|
{stream_table}

提取一次完成；分析第一轮保存analysis.stdout/stderr，加入KV两组和有界消费者输入后的r2单独保存。未删除初稿。材料算术和槽位边界{materials['passed']}/{materials['total']}通过，见material-checks.json；这些是材料校验，不是生产测试或模型校准。

## 支持、反例和结论

| 同指纹配对 | 原/替净损血 | 原/替敌净扣 | 限制 |
|---|---:|---:|---|
| 751 F17 T2，272434/272575 | 13/18 | 9/18 | 多5血换9净扣，后轮不同 |
| 751 F17 T7，272531/272652 | 13/23 | 12/18 | 多10血换6净扣，未决弃牌保守值不冒作实际失血 |
| KEN F17 T10，274505/274568 | 15/21 | 2/4 | 多6血换2净扣，非整战胜率证据 |
| KEN F17 T5，274484/274601 | 7/5 | 1/2 | 存在后续追加动作和能力建立窗口变化 |
| KV F33 T5，273400/273450 | 0/0 | 36/29 | 删输出未有当轮保血收益 |
| KV F33 T1，273242/273474 | 0/0 | 28/14 | 后续重问/replay另列，不是整线因果 |

配对起点由observed_ts和fingerprint唯一关联，终点取同层下一轮原状态；本表只描述净端点，不能命名为逐来源毛伤、单卡因果或完整候选结果。paired-observations.json保存底板、后帧、sl_explore及journal。相关六次SL按一个局，不拆训练/验证，不拟通用血价或关闭更差线探索。

YQL F17 T10 states280160/280161直接核：本体结束后的占位血max999999999、EXPLODE_MOVE/DeathBlow41，饮毒药后毒2→8而26血/13挡/41来袭保持。加6毒不作减6自爆或本体进度；提前喝、不喝与留药的完整结果未知。L9/YQL六试均未胜；PU F17第5试T15实胜余2血（sl-attempts719）是反例，不因占位血或短存活排序简单否定。原anchor 681/717/960–963确有近十亿占位残血排序，现源码仍保留旧tie-break。阶段提示/指标已有实现，不把更改排序当已证收益。

KEN七次饮药请求及对应前后槽位全部核实，三次仍pending接口回执；槽位后帧为空与完整随机选牌/重问收益不同。F13肌肉药水的有药、当轮无药与整战无药参考分开，成本0/缺表不能改称持有价值0。KV F17首试实胜余9血（sl-attempts951）保留，不从后续失败反推升级或休息错误。

## 现有实现与消费者

只读live锚点`{sources['live_snapshot']}`。16个相关源码叶最后提交均核为实际live祖先；14叶与本base相同，potion-cost.ts和sl/explore.ts差异仅既有Roy/Dai注释文字，source-live-diff.patch保留原差异，未合入或改写。具体路径/SHA/40位提交在source-audit.json，不声称两完整树相等。

已实现窄子项包括持牌失血预测（9d8278702dbc581b5015ba7ec9a70dc0fb94cccb）、持药未知/无药参考（c4670f4f416c7d93e192e889c5080e7e4e0e733f）、巨兽残壳药水事实（40168f4a903ae1d8c48bd03006f8fea19fd3aa3c）、候选SL比较（66283dd9982bdd7f480da7a4d9bfefea0572a9ac）、单动作派发回执（fdaf787a372880b0438e73bcac7e6d2168b038ed）、SL阶段记录/原排序（b01edf46b4b619f217d070a196e161df9fe716a0）。它们不等于本批新实现，不能用一个窄字段把宽提案置implemented/duplicate。

consumer.mjs以当前现有auditSelectionExecution对六份冻结单局输入作有界读回，进程exit0：共{counts['segments']}个题段、{counts['actions']}个动作、{counts['intervals']}个相邻观测端点、{counts['observed_turns']}个可核整轮窗口及{counts['unknown_turns']}个unknown窗口；完整候选认证0。KEN line274207缺decision_id排除，未补造ID，全部输入/输出gzip及SHA可核。状态只投影消费者实际读取字段、保留原行/SHA，决策仅去agent_view；输入转换在analyze.py。没有调用LLM/网络/游戏、读取刷新知识JSON或跑整场模拟；这些结果是固定离线读回，不冒作自然采用、历史全输入复原、策略收益或联合生产校准。

六份run-config完整源码commit都可在Git定位，dirty_files只列knowledge/notes；缺的是当时刷新知识/移动表具体字节与完整联合输入，不笼统写源码丢失，也不用今天的数据替代。historical-config.json保留原提交和脏路径。当前消费者明确actual_turn/actual_full_candidate_result/whole_plan_executed未知，预测拆项不当实际完整收益。

## 逐项处置

| 派发ID | 结果 | 具体缺数据原因 |
|---|---|---|
{disposition}

没有新反证推翻既有机制，没有新增游戏经验或拟合门槛；沿原ID保留waiting待新证据。原提案历史总体分母不充作本次覆盖，不扩展到其他队列或角色。

## 记录、验证与交付

仅经根learner/ledger.py update为16个已有silent账本追加本批proposal/report追溯与说明，by=learner:strategy-proposal；不重复support/repeat，不改claim、首证、prior、evidence、status、version或shipped。旧项已shipped时不降级proposed；本批没有需要新增proposed条目的新知识。实际CLI输入/退出码及保护字段读回另存。

本批无生产源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases全部null；未运行生产套件，不伪造成功。fixes=[]、merged=null，无源码提交、合入提交、eval版本、上线decision记录或规则变更双通知；其他角色行为没有变化。工作树最终保持干净、HEAD不变，最终回执见final-verification.json；材料扫描另存。日志只读，不运行play、不联网、不推送、不改ops prompt、不写根请求或通知ACK。

交运维提案：{HERE/'proposal.md'}。

报告：{HERE/'report.md'}。
"""
(HERE/'report.md').write_text(report)
print(json.dumps({'report':str(HERE/'report.md'),'proposals':len(results),'consumer_counts':counts},ensure_ascii=False))

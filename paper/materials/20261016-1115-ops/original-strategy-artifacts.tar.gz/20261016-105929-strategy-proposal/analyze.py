import hashlib
import importlib.util
import json
import subprocess
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')

def write(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def git(*args, cwd=TREE):
    return subprocess.check_output(['git', *args], cwd=cwd).decode().strip()

dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = dispatch['runs']
spec = importlib.util.spec_from_file_location('extract', TREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
streams = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
data = {}
verification = []
for stream in streams:
    name = stream['stream']
    counts = Counter()
    digest = hashlib.sha256()
    previous = 0
    selected = []
    with (HERE / 'evidence' / (name + '.evidence.jsonl')).open('rb') as f, (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
        for line in f:
            digest.update(line)
            e = json.loads(line)
            assert e['offset'] >= previous
            previous = e['offset'] + e['bytes']
            assert previous <= stream['source_size']
            source.seek(e['offset'])
            raw = source.read(e['bytes'])
            assert hashlib.sha256(raw).hexdigest() == e['sha256']
            assert json.loads(raw) == e['row']
            assert extract.run_identity(e['row']) == e['run_id'] and e['run_id'] in runs
            counts[e['run_id']] += 1
            if name == 'states':
                r = e['row']['state'].get('run') or {}
                assert str(r.get('character_id')).lower() == 'silent' and r.get('ascension') == 10
            selected.append(e)
    assert digest.hexdigest() == stream['output_sha256']
    assert dict(counts) == {k:v for k,v in stream['counts'].items() if v}
    data[name] = selected
    verification.append({**stream, 'verified_rows':sum(counts.values())})
write('raw-verification.json', {'streams':verification,'total_verified':sum(x['verified_rows'] for x in verification)})
identities = [e for e in data['runs']]
assert len(identities) == len(runs)
assert all(e['row']['character'].lower() == 'silent' and e['row']['ascension'] == 10 for e in identities)
write('run-identities.json', identities)

def compact(e):
    s = e['row']['state']; r = s.get('run') or {}; c = s.get('combat') or {}; p = c.get('player') or {}
    return {'line':e['line'],'run_id':e['run_id'],'ts':e['row']['observed_ts'],
            'floor':r.get('floor'),'turn':s.get('turn'),'screen':s.get('screen'),
            'hp':p.get('current_hp',r.get('current_hp')),'block':p.get('block'),'energy':p.get('energy'),
            'powers':p.get('powers'),'enemies':c.get('enemies'),'potions':r.get('potions'),
            'hand':[{k:card.get(k) for k in ['index','card_id','upgraded','energy_cost','dynamic_values']} for card in c.get('hand',[])]}

states = data['states']
index = {}
for e in states:
    key = (e['row']['observed_ts'],e['row']['fingerprint'])
    index.setdefault(key,[]).append(e)
decisions = {e['line']:e for e in data['decisions']}
pairs = [(272434,272575),(272531,272652),(274505,274568),(274484,274601),(273400,273450),(273242,273474)]
paired = []
for a,b in pairs:
    first,second = decisions[a],decisions[b]
    assert first['run_id'] == second['run_id']
    assert first['row']['fingerprint'] == second['row']['fingerprint']
    items = []
    for e in [first,second]:
        row=e['row']; matches=index[(row['observed_ts'],row['fingerprint'])]; assert len(matches)==1
        before=matches[0]; s=before['row']['state']; floor=s['run']['floor']; turn=s['turn']
        later=[x for x in states if x['run_id']==e['run_id'] and x['line']>before['line']]
        after=next((x for x in later if x['row']['state'].get('run',{}).get('floor')==floor and x['row']['state'].get('turn')==turn+1),None)
        assert after is not None
        lo,hi=compact(before),compact(after)
        enemy_before={x['enemy_id']:x['current_hp'] for x in lo['enemies']}
        enemy_after={x['enemy_id']:x['current_hp'] for x in hi['enemies']}
        items.append({'decision_line':e['line'],'before':lo,'after':hi,
                      'player_net_hp_loss':lo['hp']-hi['hp'],
                      'enemy_net_hp_drop':{k:v-enemy_after[k] for k,v in enemy_before.items() if k in enemy_after},
                      'sl_explore':row.get('sl_explore'),'journal':row.get('journal')})
    paired.append({'lines':[a,b],'same_fingerprint':True,'items':items})
write('paired-observations.json',paired)
lines={280160,280161,280206,280207,280232,280233,280262,280263,280313,280314,280315,280316,280348,280349,280354,280355}
write('selected-state-facts.json',[compact(e) for e in states if e['line'] in lines])
potion_lines={274131,274156,274185,274235,274237,274267,274272}
write('potion-decisions.json',[e for e in data['decisions'] if e['line'] in potion_lines])
write('sl-summary.json',[{'line':e['line'],'run_id':e['run_id'],**{k:e['row'].get(k) for k in ['floor','attempt','turns','end_hp','end_block','incoming','result']}} for e in data['sl-attempts']])
write('historical-config.json',[{'line':e['line'],'run_id':e['run_id'], 'keys':list(e['row']), **{k:e['row'].get(k) for k in ['code','git','commit','dirty_files']}} for e in data['run-config']])
floors = {'751FN9QM9MHQ':{13,17},'KV0JHNJCKXLS':{33},'YQL8RZ8BWN1E':{17},'L9SGRBB5R698':{17},'PU80F84P6HPN':{17},'KEN58SH9SLZ6':{3,4,5,11,15,17}}
inputs=[]
for run in runs:
    identity=next(e['row'] for e in identities if e['run_id']==run)
    ds=[]; ss=[]; excluded=[]
    for e in data['decisions']:
        row=e['row']
        if e['run_id']!=run or row.get('floor') not in floors[run]: continue
        if not row.get('decision_id'):
            excluded.append({'line':e['line'],'reason':'missing_decision_id'}); continue
        ds.append({k:v for k,v in row.items() if k!='agent_view'}|{'run_id':run,'_line':e['line'],'_source_sha256':e['sha256']})
    for e in states:
        row=e['row']; state=row['state']; r=state.get('run') or {}; c=state.get('combat') or {}
        if e['run_id']!=run or r.get('floor') not in floors[run]: continue
        ss.append({'_line':e['line'],'_source_sha256':e['sha256'],'observed_ts':row['observed_ts'],'fingerprint':row['fingerprint'],
                   'state':{k:state.get(k) for k in ['run_id','screen','turn']}|{'run':{k:r.get(k) for k in ['character_id','ascension','floor','current_hp','max_hp','potions']},
                   'combat':{k:c.get(k) for k in ['player','enemies']}|{'hand':[{k:card.get(k) for k in ['index','card_id','upgraded']} for card in c.get('hand',[])]}}})
    file=HERE/(run+'.consumer-input.json')
    file.write_text(json.dumps({'run':identity,'decisions':ds,'states':ss},ensure_ascii=False)+'\n')
    inputs.append({'run_id':run,'path':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'floors':sorted(floors[run]),'decisions':len(ds),'states':len(ss),'excluded':excluded})
write('consumer-inputs.json',inputs)
print(json.dumps({'verified':sum(x['verified_rows'] for x in verification),'pairs':[{'lines':p['lines'],'net':[(x['player_net_hp_loss'],x['enemy_net_hp_drop']) for x in p['items']]} for p in paired]},ensure_ascii=False))

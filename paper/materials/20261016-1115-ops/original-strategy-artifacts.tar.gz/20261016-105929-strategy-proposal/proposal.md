# 静默猎手十项原提案逐项处置

记录时间：2026-10-16T11:10:52+08:00。batch=20261016-105929-strategy-proposal；base=ff866b99467d3763aea0d3011c348783e05feb42。

本批只消费已派发十个ID，没有research_request/implementation_request/proposal_repair；不领取其他题、不新建重复ID。逐份原文SHA核对通过。全部waiting，不改源码、知识或策略；已有诊断子项不能代整项完整验证。

## silent-proposal-366288801d9150d9

角色 silent，已观察 A10；来源 postmortem → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：751 F17 T2/T7/T13；本批重核 decisions 272434/272575、272531/272652。

既有账本：silent-0079, silent-0176。来源局：751FN9QM9MHQ。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md，SHA256 `0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`；本目录同ID副本保留原字节。

处置：waiting。三组SL成本审计的原要求保留。现有候选/SL预测、持牌失血及动作回执已有实际live祖先；缺抽弃重问后的完整候选身份、逐来源结算及受控整战后继，不能拟固定SL血价。

支持、反例与未知：T2净损13→18、敌净扣9→18；T7净损13→23、敌净扣12→18。六试同属一局且全败，后轮不同；T13既有6血/6攻取舍只作原证据链接。

预期行为与验证：先固定T2/T7/T13底板核原答、护栏后与SL后线；保留B2配对差及误差、notWorseOnly/回退来源；完整抽弃序和后轮一致后再比较，不直接关闭更差线探索。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-85929bdfc8a3fc1b

角色 silent，已观察 A10；来源 postmortem → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：751 F13 T3、F17 T7/T13/T17；decisions 272361/272362。

既有账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。来源局：751FN9QM9MHQ。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md，SHA256 `d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`；本目录同ID副本保留原字节。

处置：waiting。持牌保守损血、持有价值未知和无药参考已有窄实现；缺真实无药整战、留药后战及抽弃续问后的完整执行收益，不能由缺表成本0改成留药价值0。

支持、反例与未知：F13有药/无药预测都可零额外死亡并同损8；原无药当轮候选后轮仍可能喝，专门无药参考另列。一次已饮用与空药boss失败不证明饮药错误。

预期行为与验证：固定同题有药、当轮无药、整战无药参考，核后续饮药计数及来源；随机/弃牌重问后重新对账，保留合法选项和原HP护栏。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-efd9f83ee9e1a6dc

角色 silent，已观察 A10；来源 experience-update → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：751 F17 T2/T7/T13；六试 sl-attempts 945–950。

既有账本：silent-0079, silent-0176。来源局：751FN9QM9MHQ。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md，SHA256 `0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`；本目录同ID副本保留原字节。

处置：waiting。现有预测拆项不覆盖实际整线执行；751六试没有完整胜线，缺保持后轮条件的受控对照及独立局验证，不能由局部血价收窄或关闭更差线探索。

支持、反例与未知：T2多5血换9净扣，T7多10血换6净扣，不存在统一的已证血价；同局六次不能拆训练/验证。

预期行为与验证：先复用原配对事实和模型审计，按独立局、真实时间留后期验证；不得以六次失败拟通用额外失血门槛。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-131042659448ae74

角色 silent，已观察 A10；来源 experience-update → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：751 F13 T3、F17 T3/T5/T7/T13/T17；原机制账本及同题原帧。

既有账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。来源局：751FN9QM9MHQ。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md，SHA256 `b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`；本目录同ID副本保留原字节。

处置：waiting。敏捷、毒、荆棘和呼唤有分项观测及现有提示；缺联合逐来源实际累计、完整候选执行和跨战留药对照，不能将分项机制成立当组合收益已验收。

支持、反例与未知：能力已建立不保证以后有挡牌；无实体下各来源有局部端点，末轮存毒不等于已兑现毒伤。原机制沿既有账本保留，本批不扩统计分母。

预期行为与验证：逐张挡/攻击/毒/反伤/持牌自损与实际重问动作分账，覆盖原T5/T7/T17，随后核联合消费者；保持未观察组合未知。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-990f054036609447

角色 silent，已观察 A10；来源 experience-update → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：KV F33 T5/T1；decisions 273400/273450、273242/273474；另含F16/F28/F29/F32资源窗口。

既有账本：silent-0102, silent-0019, silent-0020。来源局：KV0JHNJCKXLS。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md，SHA256 `c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`；本目录同ID副本保留原字节。

处置：waiting。同指纹T5净扣36→29、T1净扣28→14且均零损已核；严格轮窗仍有unknown，缺敌回血毛伤逐来源、完整候选和路线休息替代后继。

支持、反例与未知：两组删输出都没有当轮保血收益，后续动作变化；F17首试实胜余9血是保留边界，不能把前面升级/资源消耗判错。

预期行为与验证：保留实际净端点、下一轮毒和敌回血分账，SL恢复不算治疗；同抽序的完整后继与实际路线/休息消费者到齐后再评估规则。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-e18d3f18e6cac2a0

角色 silent，已观察 A10；来源 postmortem → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：YQL F17 T9/T10/T12/T13；states 280160/280161；L9 F17 T14，PU F17 T17及第5试T15。

既有账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。来源局：YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md，SHA256 `3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`；本目录同ID副本保留原字节。

处置：waiting。巨兽本体/残壳提示、末态资源已有实际live实现；旧同轮参考排序仍使用占位HP，缺改序后的受控完整后继，不能以窄阶段字段关闭完整策略提案。

支持、反例与未知：毒2→8但26血/13挡/41来袭均不变；L9与YQL各六试未胜，而PU第5试实胜剩2血。统一把占位HP置0会改变同轮平局选择，不是已证收益。

预期行为与验证：保留raw HP与本体0/自爆阶段分列；固定旧新anchor选择及自爆血挡缺口，按L9/PU历史发现、YQL后期复核；未获整战后继前保留排序。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-9733bb80f445aeae

角色 silent，已观察 A10；来源 experience-update → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：YQL F17 T10；states 280160→280161，decisions 274087；L9/PU F17原阶段边界。

既有账本：silent-0017, silent-0019, silent-0020, silent-0250。来源局：YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md，SHA256 `c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`；本目录同ID副本保留原字节。

处置：waiting。残壳施毒只观察2→8而血挡/41自爆保持；缺提前喝、不喝、留药及新排序的完整分支，不能将加6毒视为减6自爆或整战无效。

支持、反例与未知：当前局部无减伤不推导早喝必胜；毒层不是已结伤害，PU成功反例保留。

预期行为与验证：用原始两帧核阶段、槽位、HP/挡/来袭；与完整提前饮用和留药支线分开，保持全部药水选项，不拟饮用时点。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-c51468c5e8ba6668

角色 silent，已观察 A10；来源 postmortem → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：KEN F3T2/F4T1/F5T2/F11T1–2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272。

既有账本：silent-0019。来源局：KEN58SH9SLZ6。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md，SHA256 `168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`；本目录同ID副本保留原字节。

处置：waiting。七次用药请求及所点槽后帧为空已核，其中三次接口回执仍pending；缺随机选牌、发光水重问后的完整收益及留药后战对照。

支持、反例与未知：槽位变空支持耗药观测，completed也不证明整方案全部执行；赢战零损不能代无药零损，boss空药不能证明固定留药可胜。

预期行为与验证：逐槽冻结前后帧和随机选牌/重问，核血量与增益兑现、来源和后战资源； pending不写已确认整线执行，不设留药门槛。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-86a7db08d1a31976

角色 silent，已观察 A10；来源 postmortem → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：KEN F17 第4/5试T10、第4/6试T5；decisions 274505/274568、274484/274601。

既有账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。来源局：KEN58SH9SLZ6。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md，SHA256 `10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`；本目录同ID副本保留原字节。

处置：waiting。同指纹T10多失6血仅多2敌净扣、T5省2血但能力窗口改变已核；缺逐来源完整兑现、相同后轮对照与独立验证，不能拟固定SL血价。

支持、反例与未知：T5原净损7/扣1、替净损5/扣2，但替线有后续追加动作且步法延迟；少失血不能当能力收益不变，T10多输出不能当更安全。

预期行为与验证：逐来源核呼唤失血、无实体实际输出及步法建立时点，保留B2差和误差；后轮抽序受控并有独立时间后置验证才评估排序。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

## silent-proposal-e282a9131b99129a

角色 silent，已观察 A10；来源 experience-update → strategy-proposal；授权 Roy-2026-10-07-learning。

证据窗口：KEN F17 T2/T5/T6/T10/T12/T13；本批重点核第4/5试T10与第4/6试T5。

既有账本：silent-0021, silent-0079, silent-0125, silent-0176。来源局：KEN58SH9SLZ6。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md，SHA256 `a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`；本目录同ID副本保留原字节。

处置：waiting。同指纹血价与能力窗口只支持局部取舍；已有预测拆项，缺完整候选认证及受控后继，不拟统一6血/2伤阈值或声称改线必胜。

支持、反例与未知：T10净损15→21、净扣2→4；T5净损7→5同时改变步法建立窗口。六相关尝试不是六个独立样本，原线同样未获完整胜局。

预期行为与验证：复用原提案的固定局面核验，区分原答、HP护栏、SL与后续重问；保持候选并列、选项和既有探索，等待完整执行与后期独立局。

拟合：本批不拟合参数；相关SL按一个局分组，不混入其他角色或未观察进阶。只核已有子项，不用当前刷新知识替代历史输入。

回退：本批没有策略变更，无需回退代码；保留旧规则、原证据及失败。未来若证据支持实现，每项独立固定红绿和沙箱自测，通过后合live并按实际提交通知。

import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { auditSelectionExecution } from '../../lib/selection-execution.ts';

const here = dirname(fileURLToPath(import.meta.url));
const entries = JSON.parse(readFileSync(join(here, 'consumer-inputs.json'), 'utf8'));
const hash = data => createHash('sha256').update(data).digest('hex');
const count = (rows, key) => rows.reduce((out, row) => {
  const value = String(row[key]); out[value] = (out[value] ?? 0) + 1; return out;
}, {});
const summaries = [];
for (const entry of entries) {
  const raw = readFileSync(entry.path);
  if (hash(raw) !== entry.sha256) throw new Error('frozen input SHA mismatch');
  const output = auditSelectionExecution(JSON.parse(raw));
  const bytes = Buffer.from(JSON.stringify(output) + '\n');
  const zipped = gzipSync(bytes);
  const filename = join(here, entry.run_id + '.consumer-output.json.gz');
  writeFileSync(filename, zipped);
  summaries.push({ run_id: entry.run_id, input_sha256: hash(raw), output_sha256: hash(bytes),
    gzip_sha256: hash(zipped), output_path: filename, segments: output.segments.length,
    full_candidate_results: output.segments.filter(row => row.actual_full_candidate_result !== null).length,
    actions: output.observed_actions.length, intervals: count(output.observed_actions.map(row => row.observed_interval), 'status'),
    turns: count(output.observed_turns, 'status'), unknown_turn_reasons: count(output.observed_turns.filter(row => row.reason), 'reason'),
    excluded: entry.excluded, scope: 'frozen_offline_observations_only' });
}
writeFileSync(join(here, 'consumer-summary.json'), JSON.stringify(summaries, null, 2) + '\n');
process.stdout.write(JSON.stringify(summaries) + '\n');

import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
checks=[]
def check(name, actual, expected):
    checks.append({'name':name,'actual':actual,'expected':expected,'passed':actual==expected})

pairs=json.loads((HERE/'paired-observations.json').read_text())
expected=[[(13,9),(18,18)],[(13,12),(23,18)],[(15,2),(21,4)],[(7,1),(5,2)],[(0,36),(0,29)],[(0,28),(0,14)]]
for pair,want in zip(pairs,expected):
    check(str(pair['lines'])+' fingerprint',pair['same_fingerprint'],True)
    got=[(x['player_net_hp_loss'],next(iter(x['enemy_net_hp_drop'].values()))) for x in pair['items']]
    check(str(pair['lines'])+' net endpoints',got,want)
states={x['line']:x for x in json.loads((HERE/'selected-state-facts.json').read_text())}
for line,poison in [(280160,2),(280161,8)]:
    s=states[line]; e=s['enemies'][0]
    check(str(line)+' hp/block',(s['hp'],s['block']),(26,13))
    check(str(line)+' blast',(e['enemy_id'],e['max_hp'],e['move_id'],e['intents'][0]['damage']),('WATERFALL_GIANT',999999999,'EXPLODE_MOVE',41))
    check(str(line)+' poison',next(p['amount'] for p in e['powers'] if p['power_id']=='POISON_POWER'),poison)
for before,after,slot,potion in [(280206,280207,0,'ATTACK_POTION'),(280232,280233,0,'STABLE_SERUM'),(280262,280263,0,'SPEED_POTION'),(280313,280314,1,'WEAK_POTION'),(280315,280316,0,'ATTACK_POTION'),(280348,280349,1,'GLOWWATER_POTION'),(280354,280355,0,'SKILL_POTION')]:
    a=next(p for p in states[before]['potions'] if p['index']==slot)
    b=next(p for p in states[after]['potions'] if p['index']==slot)
    check(str(before)+' potion before',(a['potion_id'],a['occupied']),(potion,True))
    check(str(after)+' potion after',(b['potion_id'],b['occupied']),(None,False))
ds=json.loads((HERE/'potion-decisions.json').read_text())
check('KEN seven use requests',len(ds),7)
check('KEN pending receipts',sum(x['row']['result'].startswith('pending') for x in ds),3)
sl=json.loads((HERE/'sl-summary.json').read_text())
for run in ['751FN9QM9MHQ','YQL8RZ8BWN1E','KEN58SH9SLZ6','L9SGRBB5R698']:
    rows=[x for x in sl if x['run_id']==run and x['floor']==17]
    check(run+' attempts and wins',(len(rows),sum(x['result']=='won' for x in rows)),(6,0))
pu=next(x for x in sl if x['run_id']=='PU80F84P6HPN' and x['floor']==17 and x['result']=='won')
check('PU successful counterexample',(pu['attempt'],pu['end_hp']),(5,2))
check('KV F17 first attempt won',[(x['attempt'],x['end_hp']) for x in sl if x['run_id']=='KV0JHNJCKXLS' and x['floor']==17 and x['result']=='won'],[(1,9)])
result={'total':len(checks),'passed':sum(x['passed'] for x in checks),'checks':checks,'scope':'materials_not_production_tests'}
(HERE/'material-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert all(x['passed'] for x in checks),json.dumps([x for x in checks if not x['passed']],ensure_ascii=False)
print(json.dumps({'total':len(checks),'passed':result['passed']}))

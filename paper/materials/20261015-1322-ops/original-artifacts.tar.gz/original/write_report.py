import hashlib
import json
from pathlib import Path
import re

scratch = Path(__file__).parent
audit = json.loads((scratch / 'audit.json').read_text())
infra = (scratch / 'vitest-infra.log').read_text()
fixtures = (scratch / 'vitest-fixtures.log').read_text()
assert re.search(r'Test Files\s+10 passed', infra)
assert re.search(r'Tests\s+81 passed', infra)
assert re.search(r'Test Files\s+2 passed', fixtures)
assert re.search(r'Tests\s+5 passed \| 33 skipped', fixtures)
assert (scratch / 'tsc.log').read_text() == ''
assert audit['queue_identical_to_previous_audit']
assert all(row['ancestor_in_base'] and row['ancestor_in_live_snapshot'] for row in audit['existing_fixes'])
assert not audit['source_diff'] and not audit['worktree_status']

audit['tests'] = {
    'tsc': 0, 'vitest': 0, 'files': 12, 'cases': 86,
    'filtered_not_run': 33, 'full_suite_run': False, 'reruns': [],
    'logs': {name: hashlib.sha256((scratch / name).read_bytes()).hexdigest()
             for name in ['tsc.log', 'vitest-infra.log', 'vitest-fixtures.log']},
}
audit['scope_notes'] = [
    '本批没有源码/测试/经验变更，没有新提交；撤源码红绿验证不适用。',
    '只读核实既有来源在本基线/live快照的祖先关系及当前路径，不将祖先关系等同于宽父要求关闭。',
    '相比上一核验仅codex-usage.ts/codex.ts有后继变化；逐diff核实为main已合入的限定额度授权及读额度期限，原默认限制及JSONL追加修复仍在。',
    '剩余游戏知识/结构项继续已有独立strategy-proposal，不重复登记、不派下级agent、不修改账本状态。',
    '工作树没有新增源码，无需合并空批到live，不占live锁、不提交知识刷新/上线记录、不分配行为版本。',
    '定向测试是本批实际执行，未声称执行完整test-sandbox；原宿主检查失败与历史回执保持。',
    '工具首次执行遇并行工作树目录消失造成bubblewrap glob ENOENT；原工具输出保留，同命令入口后续成功，不把上游具体归因冒称已证。',
]
(scratch / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [],
    'skipped': audit['skipped'], 'merged': None,
    'tests': {'tsc': 0, 'vitest': 0, 'cases': 86},
    'code_proposals': [], 'implementation_domains': [],
    'report': str(scratch / 'report.md'),
}
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

lines = [
    '## 修 bug 回报', '',
    f"- 合并基线：main → {audit['base']}（工作区干净；git merge --no-edit main 返回 Already up to date.）",
    '- 修复（每条一行）：无新增修复；无代码和测试改动，不重复提交既有修复，撤源码红绿验证不适用。',
    '- 已被别人修掉的：以下72项来源均为本基线与live只读快照的祖先，当前源码路径已核；窄子项不关闭父范围。',
]
for row in audit['existing_fixes']:
    lines.append(f"  - {row['item']} — {row['source_commit']} — `{row['path']}`")
lines.append('- 没修的：')
for row in audit['skipped']:
    lines.append(f"  - {row['item']} — {row['reason']}")
lines += [
    '- 测试：tsc退出码0；Vitest定向12文件/86用例通过/退出码0，另33项因名称筛选未运行；无重跑。没有新代码提交，未运行完整test-sandbox，不将定向覆盖记成完整套件。固定夹具，无真实LLM/网络。',
    '- 合入：未合入（本批没有新提交；merged=null）；既有来源已在live，未执行空批合并、知识刷新提交或版本登记。',
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
    '只读live快照：' + audit['live_read_only_snapshot'] + '。队列SHA256：' + audit['queue_sha256'] + '，1324行与前批完全相同。',
    '当前源码及来源SHA、72项祖先关系和测试日志SHA见audit.json；前批输入留在prior-audit.json/prior-report.md，仅复用来源清单，本批重新核实。',
    'silent-0481的原提案silent-proposal-686d4e759478eebb与silent-0446的silent-proposal-2d3aa8dfb27dbe3f仍在原独立链；本批未新增提案或更改状态。',
    '纸鹤两条完整六步线及零枚举等价用例共3项、目标标注及有界时钟共2项通过，保留原15000/30000ms期限和断言。',
]
(scratch / 'report.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'report': str(scratch / 'report.md'), 'existing_sources': 72,
                  'fixes': 0, 'tests': result['tests']}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).parent
root = Path('/home/dw/Projects/agent-sts2')
work = root / '.worktrees/codex-fix-silent-20261015-131302'


def git(*args, cwd=work):
    return subprocess.check_output(['git', *args], cwd=cwd)


def ancestor(source, target):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', source, target], cwd=work).returncode == 0


prior = json.loads((scratch / 'prior-audit.json').read_text())
extras = [
    ('完成报告裸JSON兼容', '6f86ff6b6', 'ops/learner_checks.py'),
    ('autoplay安全热交接动作', '71b835a31', 'ops/autoplay-reload.py'),
    ('历史测试入口漏传日志回调', 'ccd8bb8e0', 'agent/tests/legacy-brain.ts'),
    ('额度警告固定测试契约', '1cf049049', 'agent/tests/brain-codex-usage.test.ts'),
    ('有限结束报告与补验交接', '2c4ce406c', 'ops/learner_checks.py'),
    ('host-checks-broker-push-registration', 'c519952b3', 'ops/codex-ops-actions.sh'),
    ('host-checks-session-exit-fixture', '874ae603b', 'agent/tests/brain-codex-session.test.ts'),
]
for item, source, path in extras:
    prior['existing_fixes'].append({
        'item': item, 'source_commit': git('rev-parse', source).decode().strip(),
        'path': path, 'current_source_sha256': None,
    })
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=root / '.worktrees/live').decode().strip()
queue = (root / 'notes/fix-queue-v4.md').read_bytes()
rows = []
for old in prior['existing_fixes']:
    source, path = old['source_commit'], old['path']
    contents = (work / path).read_bytes()
    source_path = old.get('original_source_path', path)
    source_contents = git('show', f'{source}:{source_path}')
    rows.append({
        'item': old['item'], 'source_commit': source, 'path': path,
        'ancestor_in_base': ancestor(source, base),
        'ancestor_in_live_snapshot': ancestor(source, live),
        'current_source_sha256': hashlib.sha256(contents).hexdigest(),
        'same_as_previous_audit': (hashlib.sha256(contents).hexdigest() == old['current_source_sha256']
                                   if old['current_source_sha256'] is not None else None),
        'same_as_source_commit': contents == source_contents,
        'original_source_path': source_path,
        'original_source_sha256': hashlib.sha256(source_contents).hexdigest(),
    })

report = {
    'base': base, 'live_read_only_snapshot': live,
    'queue_sha256': hashlib.sha256(queue).hexdigest(),
    'queue_lines': len(queue.splitlines()),
    'queue_identical_to_previous_audit': hashlib.sha256(queue).hexdigest() == prior['queue_sha256'],
    'prior_source': 'a936191941:paper/materials/20261015-1151-ops/source-evidence.tar.gz',
    'existing_fixes': rows, 'new_fixes': [],
    'skipped': prior['skipped_prior_scopes'],
    'source_diff': git('diff', '--binary', base, '--', 'agent', 'learner', 'ops', 'eval', 'knowledge/builders').decode(),
    'worktree_status': git('status', '--short').decode(),
    'new_baseline_paths': git('diff', '--name-status', prior['base'], base, '--', 'agent', 'learner', 'ops', 'eval', 'knowledge/builders').decode().splitlines(),
}
(scratch / 'audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({
    'base': base, 'live': live, 'queue_identical': report['queue_identical_to_previous_audit'],
    'sources': len(rows), 'all_base_ancestors': all(row['ancestor_in_base'] for row in rows),
    'all_live_ancestors': all(row['ancestor_in_live_snapshot'] for row in rows),
    'changed_since_prior': [row['path'] for row in rows if row['same_as_previous_audit'] is False],
    'worktree_clean': not report['worktree_status'],
}, ensure_ascii=False))

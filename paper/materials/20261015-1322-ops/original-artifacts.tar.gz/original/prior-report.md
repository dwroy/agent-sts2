## 修 bug 回报
- 合并基线：main → c0c0adb397e51644ca6251e86c16ffabcb28ae5f（开工工作区干净；git merge --no-edit main 返回 Already up to date.）
- 修复（每条一行）：无新增修复；当前可确认的纯工具缺陷已有实现，不重复提交。
- 已被别人修掉的：下表 65 个来源修复/窄子项，已重新核验每个来源提交都是本基线及只读 live 快照的祖先，且当前对应源码存在。表中窄子项不代表其父任务、未观察机制或自然消费者已完成。
- 没修的：下列独立策略、缺证和宽架构范围保留原行为及原提案链；没有新派下级 agent 或重复登记提案。
- 测试：tsc 退出码 0；Vitest 定向 20 文件 / 83 用例通过 / 退出码 0，另 33 项因名称筛选未运行；独立 Python 固定归因测试 3 项通过。没有重跑、真实 LLM 或联网调用。本批未改代码、无提交，未运行完整 test-sandbox，不把定向覆盖冒充完整套件。
- 合入：未合入（本批没有源码变更或新提交；merged=null）。没有占用 live-merge.lock、提交知识刷新、写上线记录或分配版本。
- 需要 Roy 定的事（没有写「无」）：无。

## 已有修复逐项读回

| 条目/已交付子项 | 已修来源提交 | 当前源码 |
|---|---|---|
| silent-0254：无动作死亡战斗归因 | `3b48088dec5fc6eafe576a1296bbdadde43432ee` | `ops/report.py` |
| codex-usage-credit-baseline-recovery：额度窗口恢复基线 | `5b56a452bb9be14d620b368ec46974c1b57901ca` | `agent/src/brain/engines/codex-usage.ts` |
| ascension-up：请求进阶误报为实际进阶 | `8045d9fbf0a12523b1dbe39bbed8af06c7497b09` | `ops/codex-ops-learn.py` |
| infra-target-options-fixed-fixture-timeout | `bae9c45ccffefb284a1c6634526c8768a9f5f7a8` | `agent/tests/target-option-fixture.ts` |
| infra-ledger-status-prefix-git-divergence | `dd478f0b3e5a0f234f082972d21b203dbf8229d7` | `learner/ledger.py` |
| infra-legacy-continuation-notice-ack-identity | `368fccabd42eb72ffcea9a2fe6cbbb7c149326be` | `ops/learning_requests.py` |
| infra-paper-krane-recorded-line-timeout | `befc39e5ca0105f8ff96d47f817df44f0b2760f1` | `agent/tests/silent-paper-krane.test.ts` |
| infra-learner-event-log-second-collision | `b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f` | `learner/lib/launcher.ts` |
| strategy-proposal：报告 scratch 归属 | `5f04139cefe5c651dd5bf62f7e164014dbf5f23b` | `learner/lib/launcher.ts` |
| silent-0459：独立 run-plan 请求成本漏计 | `799a5cd0caf9329b43c32376079218a9bd0c3e9e` | `ops/report.py` |
| run-plan 证据提取未识别 run 字段 | `78e9b05929366d097a728761d693d790ff16ac87` | `learner/extract_evidence.py` |
| postmortem-capacity-failure-proposal-repair-20261013 | `3fdcd77927f01b35c20c6c5c1fcfd790676032d2` | `ops/codex-ops-learn.py` |
| blocked-experience-proposal-repair-dispatch | `84366ad06ee4f978394c1b9489a82c83ea12bd36` | `ops/proposal_dispatch.py` |
| learning-notice-ordinary-ack-registry-20261013：普通 ACK | `672e198a4730012330f599068a0ef1efadb02002` | `ops/learning_requests.py` |
| learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 | `1594def2e1b65b665d3b345f31444194eb4d09e6` | `ops/learning_requests.py` |
| learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 | `15eb85e2934e428c5e299fc4a1aba456d92fd685` | `ops/learning_requests.py` |
| feature 通知来源身份校验 | `38b2f572d90b3b97a23f9eae983f583287492f9a` | `ops/learning_requests.py` |
| feature/B4 通知来源桥接 | `1dd4d434aef67f1d065dbdba23a875ae82741a88` | `ops/learning_requests.py` |
| batch-f：包装/参数化测试超时静态解析 | `56c256dad0d33b231b82b53113d3bdd84f9bfa20` | `agent/tests/batch-f.test.ts` |
| unassigned-strategy-proposal-resolution | `3a98e213a826e94f9708af4b1a265e1892659f4e` | `ops/proposal_dispatch.py` |
| host-fixed-test-timeouts-010547：eval 固定历史输入 | `d9881ba593b0b8d701ebbe1c95626c0ebdd554c7` | `agent/tests/eval.test.ts` |
| host-fixed-test-timeouts-010547：Apotheosis 有界夹具 | `9e8c93555131c3347f9e809d9722a848a75c2692` | `agent/tests/silent-apotheosis-reference.test.ts` |
| compute-memo-worker-data-signature | `8fbb441eb61eef226eb7366f9612003480c83988` | `agent/tests/compute-memo.test.ts` |
| rollout-live-best-test-determinism | `bbc5b993a7524bbb8e80a975f204f8d193657b46` | `agent/tests/rollout-live.test.ts` |
| host-targeted-check-continuation：已过覆盖的精确续验入口 | `24c2e3a75b5db6bac76d6c924f86b7fcd9438316` | `ops/learner_check_continuation.py` |
| sandbox-glob-startup-race：会话前有界恢复 | `bc2c40e313cc36682196277c53c50e30744b88c5` | `learner/lib/startup-recovery.ts` |
| sandbox-glob-startup-race：复盘租约绑定 | `d9983263ffecea1bed4e29d65e7f854a3d2e33d7` | `learner/lib/startup-recovery.ts` |
| core-cycle-implementation-binding-entry | `fc95760d4ff8a9cbd45577efdd79b1215bd2cb92` | `ops/strategy_implementation_jobs.py` |
| ops-20261012-quantitative-continuation | `b408252f87a77ee5389c4d90e52a9831c0873348` | `ops/strategy_implementation_continuation.py` |
| named-card-facts-transport：已批准的事件入口子项 | `42c920f34d9dc1c783ce894659849ab37ed6fd1b` | `agent/src/hand/screens/event.ts` |
| core-build-notify-222802-rc2：保留原生失败诊断子项 | `5c92f2aaf0b758a1a5e7d591745694004664f83a` | `ops/core_build_jobs.py` |
| paper-dataset-git-consistency-race | `16bfe0bd6ecaa91d04a91c01edc94cecc781f71f` | `ops/paper_dataset.py` |
| boss-sim-codex-home-preflight | `5921f8cd045853182c867a6430e75c3fcde00a87` | `ops/report.py` |
| shared-experience-fixed-filesystem-snapshot-20261013 | `8390c62d76fc8c7d7b6b7292121a621f4666d39c` | `agent/tests/historical-knowledge-fs.ts` |
| silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） | `ec8c578b66bf5498372f1b779ae58a766dff8112` | `agent/tests/silent-tail-resource.test.ts` |
| ops-stall-recovery-test-subprocess-timeout：首项异步夹具 | `95e7f050ef2abe5c85a0367555392652ad73fbfe` | `agent/tests/ops-stall-recovery.test.ts` |
| ops-stall-recovery-test-subprocess-timeout：固定失败诊断 | `9b6459fd99f26b17689134e33aa85d6190e71d7d` | `agent/tests/ops-stall-recovery.test.ts` |
| batch-c-fixed-fixture-timeout | `5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff` | `agent/tests/batch-c.test.ts` |
| 晚写复盘误计为上线后重犯 | `2610945b6a2f9ea02cf3a7cd4b5980d24814ac39` | `learner/ledger.py` |
| 学习账本 first_run/asc/prior_note 追加更正 | `87c89b7aea90c7275e0fbb04b1e4148a4209630c` | `learner/ledger.py` |
| subscription-usage：未设置 TMPDIR | `6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a` | `agent/tests/subscription-usage.test.ts` |
| deepseek-prompt-dump：状态日志反向流式扫描 | `6ee8e2a2c1edc31492962137b96af8c6e1d12093` | `agent/tools/deepseek-prompt-dump.ts` |
| 固定药水测试隔离 | `e78352f784d39cf25671446348daaada6ef2060b` | `agent/tests/potion-cost.test.ts` |
| 单次 mod 超时 stall 误报 | `a4f4ec868d122dc92af510862c6240cf2eaff2b6` | `ops/stall-check.sh` |
| 学习状态锁被完整检查阻塞 | `233ede56047274ba53a4e1191a245fac816c37a8` | `ops/codex-ops-learn.py` |
| 学习者受阻后兜底完整检查入口 | `f670884a188a047bbd3f7f007c260ade62fae36a` | `ops/learner_checks.py` |
| 策略任务及自动派发入口 | `afd652a3f75df6e7403439f01c565220327884da` | `ops/proposal_dispatch.py` |
| 旧事件选项重复问大脑 | `25ce09bee5576b1adff8baf196fbe8b197a5ef11` | `agent/src/hand/loop.ts` |
| silent-0153：普通隐秘匕首生成分支 | `b7f081fcc26da4506cb775739bb118cb6cbe4ecc` | `agent/src/reflex/card-model.ts` |
| silent-0256：已观察的狡诈药水容量子项（实际源码提交） | `6403fdcdadc803a092beb5165a068e22bf51c412` | `agent/src/reflex/card-model.ts` |
| silent-0260：普通紧勒逐牌失血 | `5c7105ff0294466da8319f2934beda05c6040794` | `agent/src/reflex/card-model.ts` |
| silent-0263：已观察的碾碎爪转向取整子项 | `ec29ea34b919344b707e57ba472ea210f9c39d62` | `agent/src/reflex/silent-crusher-facing.ts` |
| silent-0266：SL 首牌身份 | `e784dd9f043bf87c29109573f48975f9903280d3` | `agent/src/sl/explore.ts` |
| silent-0272：商店移除预览与真实选牌页核对 | `db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26` | `agent/src/hand/screens/shop.ts` |
| silent-0324：普通刀舞生成小刀 | `66c22ba7d87b8748690a4183fff838acd346bd3e` | `agent/src/reflex/card-model.ts` |
| silent-0338：回合末防御事实来源注记 | `c1d84804956bedbd29a7f0e81294114e18415b9d` | `agent/src/reflex/turn-solver.ts` |
| silent-0367：已用蜥蜴尾巴事实接线 | `5baf663d7e6678efa3690e5a48329c4f8baee109` | `agent/src/brain/build-facts.ts` |
| infra-learner-launch-shared-main-config-race | `22efae55484bc2bdcc54e847a8dc40bb4888c4e2` | `ops/learner_entry.py` |
| host-loop-time-cap-wall-clock-061301：固定时间夹具 | `b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa` | `agent/tests/loop.test.ts` |
| host-loop-time-cap-wall-clock-061301：续验拒绝诊断 | `63f656fb07a21a7496353234269901a832eae497` | `ops/codex-ops-learn.py` |
| ops-worktree-history-disk-pressure：broker容量/回执失败隔离 | `a136ddc4b5b0a8696f10b2fae3073322d57e724c` | `ops/codex/main.ts` |
| ops-worktree-history-disk-pressure：无终态标记退出 | `db072ddab47ba94efb46dce2913927f936ecb97e` | `ops/autoplay.sh` |
| ops-worktree-history-disk-pressure：JSONL追加边界 | `9b07240b18f862efdbe630889ade04e8976eaace` | `agent/src/brain/engines/codex.ts` |
| ops-worktree-history-disk-pressure：历史副本/按需恢复 | `c7a6efb1e15ed6c5f31a35ae3ee9833863340393` | `ops/worktree_storage.py` |
| tracked-source Python缓存回收认定 | `1e8af775f6b90f100f20ff7c4a08dfddaba893a9` | `ops/learner_retention.py` |

## 保留范围

- silent-0481：技能药水选牌生命周期措辞 — 策略类/题面游戏知识：当前 selection.ts:311/:333 仍有旧措辞；原 silent-proposal-686d4e759478eebb 已登记 strategy-proposal，本普通工具批不重复实现或新增提案。
- rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/structure：当前 hand/loop.ts 仍只在 dispatch 成功后 applyResolved；已有 silent-proposal-2d3aa8dfb27dbe3f，超时后的实际动作确认/路线提交须按原独立提案验证，不无条件提交未确认动作。
- 其余未闭合的出牌、机制、药水、SL、终局、路线与休息条目 — 策略类：沿队列已有 strategy-proposal 和原账本处理；游戏知识不能由本批工具审计补入。账本有已发布项，也有 observed/proposed 或只完成窄子项，未把经验发布当作整条代码修复。
- codex 大脑缓存命中偏低 — 证据不足：队列为旧命中率观察，缺当前原生调用的可控同题对比，离线且禁止真实 LLM 请求；不把命中率变化认定为缓存源码 bug。
- 调度公平性核查 — 证据不足：原条目明确尚非永久饥饿证明；保留原 dispatch/seen_runs 核查与已获准框架迭代边界，不更改并发或队列状态。
- 启动竞态的上游生命周期根因（含 shared-main 暂态冲突） — 证据不足：ENOENT 有界恢复、复盘租约和 shared-main 精确导入错误的有界恢复均已在当前基线/live；原目录移除者、完整失败时字节与自然恢复仍需原 owner 核实，不扩大权限或重复派发。
- core-build-notify-222802-rc2：原失败通知的发送/恢复事实 — 证据不足：诊断保存源码 5c92f2aaf 已部署；旧 rc2 无 stderr 不能事后重建原发送事实，不重发通知或改旧回执。
- named-card-facts-transport：事件入口之外的宽范围 — 策略类/独立功能：事件入口 42c920f34 已实现；其他入口/跨局及 P1/P2 仍属原独立架构任务，不扩大普通 bug 批次。
- boss 模拟样本/性能与 v5-dpr-health 的宽范围 — 太大/独立功能：原冻结输入与学习 owner 的专项仍开放，不混入本批或以低样本、扩预算、删候选掩盖问题。
- arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression — 策略类/独立架构及归因研究：已有获准独立任务；不在纯 bug 批次改变玩法、资源价格或派发优先级。

`silent-0481` 仍见 selection.ts:311/:333 的旧措辞，原 `silent-proposal-686d4e759478eebb` 在共享队列为 pending；`silent-0446` 的原 `silent-proposal-2d3aa8dfb27dbe3f` 同样 pending。两者均已在独立策略链中，本批不补游戏知识、不新增相同提案或改写原状态。

## 验证与记录边界

- 本批实际原生 turn_context 为 gpt-6.1-sol / xhigh，线程 01a13da8-32ed-7561-a99c-a5b1c3e65d3c；不是仅由默认配置推断。
- 具体命令、固定用例输出保存在 tsc.log、vitest-targeted.log、vitest-fixtures.log 和 report-death-fight.log；audit.json 保存其 SHA256、源码哈希、来源祖先读回及只读 live 快照。
- 纸鹤两条原六步完整线和零枚举夹具共 3 项、目标标注及有界时钟 2 项均通过；未提升时限、删断言或改生产预算。
- 首轮来源路径核验发现 afd652a3 当时在 ops/learner_jobs.py 实现派发，ops/proposal_dispatch.py 是后续拆分路径；audit.json 已保留此说明及原源码 SHA，未把文件拆分误判为缺修。
- 当前基线与 live 存在既有历史源码差异；来源祖先核验不声称两棵树逐叶相等。只读 live 快照为 fba193dfe31844e1dbde9f2ad7174427fcd446dc，它不是本批合入提交。
- source.diff 是当前基线上的 git diff --binary，长度为 0；工作树保持干净。未提交、推送或更新队列/账本/提案/双收件箱；旧失败、旧通知与共享状态保持。
- 无本批新增修复，因此无“撤掉本批修复”红绿实验；不把别人的历史负对照记成本批执行结果。

```json
{
  "task": "fix-batch",
  "base": "c0c0adb397e51644ca6251e86c16ffabcb28ae5f",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0481、silent-0446及其余未闭合游戏机制/规则项",
      "reason": "策略类，保留原行为，沿已有独立策略提案链处理"
    },
    {
      "item": "缓存命中、调度公平性、启动竞态上游根因及旧通知恢复",
      "reason": "证据不足，保留原失败及现有保护"
    },
    {
      "item": "全漏斗、统一资源价值、其他事实入口与模拟性能的宽范围",
      "reason": "太大/独立功能，沿原授权专项处理"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 83
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-114308-b22cb602-428f-4760-ae3b-4c91ca751c00-fix-batch/report.md"
}
```

# 20261017-211302 静默策略提案报告

结论：十项均证据不足，维持 waiting；无新源码提交及live合入。

本批为十项原提案的消费复核，无 research_request、implementation_request 或 proposal_repair。不领取其他队列项。初始工作树干净，git merge --no-edit main 返回 Already up to date；base/HEAD 为 ee90797b418e628fcda95dd759e692ccfbac9145。没有新策略源码、知识或执行框架改动；十项均 waiting，不能用部分实现关闭整项。

只核静默十五局：本批十个派发锚点，加原提案直接引用的 SADL3CGYTGSR、1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH。逐项核 runs.jsonl 角色；不搬用其他角色知识。F4Q为A9，K367为A1，SADL为A7，其余十二局A10，进阶不混合拟合。原十份Markdown逐SHA吻合，副本与指纹在 original-proposals/ 和 original-proposals-manifest.json；31条既有账本保存 assigned-ledger.json。

使用共用 extract_evidence.py 另存 evidence-retry/；八流 source_size、逐行offset/bytes/SHA及各局计数均保存。55个固定状态窗口核算支持下述局部结论；audit_evidence.py 逐一seek回原日志核19929条原行的身份、JSON、字节数和SHA，输出 evidence-verification.json 与 fixed-observations.json。八流计数：states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、runs15、fight-plans0。run-plans按run归属，不以正文提及选局；fight-plans该截点0仅表示未选中。states/decisions/brain各有2条原流无效JSON，未收为证据；不是这些局日志缺失。第一次抽取未取得可验收完成清单，保留原 evidence/ 零行初稿与 extract.log，不据此判缺失；完整第二次退出0。

固定事实：TXZ F48T6同入口48HP/敌460，原线损3/伤36，替线损0/伤27；F48首胜4HP，F49开场4→0，敌111不变、出牌0。WQ F33T9两入口原fingerprint相同，原线损13/伤24，替线损22/伤39；T7逃离线损4、伤24，沙坑5→轮后4，不能把延时当免伤。WQ T11手8→10→10→10、小刀0→2→2→2，另一组手5→8→10→10、小刀0→3→5→5；满手饮用仍耗瓶。NHA F33T1原线实损1、末试替线实损7，跨轮总敌HP差包含轮初遗物伤，不能全当卡牌伤。KEN七次use_potion请求与七次槽位消耗对应（KEN-potion-removals.json）；pending返回本身不等完成，原状态转移单独核验。

源码核查：source-readback.json 保存14叶基线/live blob、SHA、实际live祖先；live快照 b23506b242de724d2ab9c066927ddb0d70d3f706。9叶字节相同，另外5叶差异仅Roy/Dai注释署名，完整 base-live-source.patch 已保存，不称14叶同SHA。沙坑差额日志源码 0e4fe4df89a06682468e0e4716c12126e76369d5 已是live祖先，修正专队列旧理由的“未live”描述；该日志仅预测，execution仍unverified。其他窄子项的实际live祖先见 partial-live-implementations.json：狡诈5b56a452bb9be14d620b368ec46974c1b57901ca、紧勒66283dd9982bdd7f480da7a4d9bfefea0572a9ac、普通磨蚀46d5fb8397edb84d9495ff61a21bed22b6bed7f1、精确切击8b9bacbebb20eaaa1133a9945da6c7abfcda745d。限定开场资源 ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 和蟹朝向68711002f15b298b8863d2258ee5da236da151d2亦核live祖先。这里是既有部分源码读回，不登记本批implemented/duplicate。

当前本树静默boss-trust的六Boss及F49仍low，读回与SHA保存在trust-readback.json。新校准发布不是本批十五局、完整候选执行或两战联合校准的证明。历史运行code带dirty，当前源码只用于缺口核对，不还原当时运行树。

## silent-proposal-08eaa60bcc449852

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md

证据：KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1、T2/F15T1；F5 53→16。

既有账本：silent-0019, silent-0020。

处置：waiting。KEN七次实际用药已核；缺同入口、牌组、后续动作及预算下不用、早用或留药到Boss的成对整战结果，不能据实耗和回复拟合持药价。

反例与限制：KEN F15胜且零净损仍消耗两瓶，F5胜仍损37；这些事实既不证明该留药，也不证明早喝普遍更好。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-92920295a648b540

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md

证据：TXZ6RVMQA09D A10 F48T6、T10及F49T1；states 281479→281484、281535→281539、281563/281565/281566。

既有账本：silent-0228, silent-0255。

处置：waiting。TXZ F48T6替线少损3血也少伤9，首胜4血后F49开场归零；缺保持后续抽序、生成、选择和药栏的两战替线，不能由首胜或低可信模拟调整SL。

反例与限制：T6少损3同时少伤9；首Boss胜利仍接开场死亡，首胜不是连续通关验证。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-a327449c331efbc1

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md

证据：WQZVENQ7DTRP A10 F33T9与T7；states 282075→282079、282144→282148、282330→282336。

既有账本：silent-0079, silent-0018。

处置：waiting。沙坑差额日志0e4fe4df89a06682468e0e4716c12126e76369d5已核为live祖先，旧未live理由已过时；仍缺血量、毒、沙坑双边界的受控整战后继和独立验证，9血换15伤不能拟合排序阈值。

反例与限制：WQ T7付4血可换沙坑余量，反驳一律禁止付血延时；T9多伤也不能证明后继更好。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-a099e89437e942bb

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md

证据：WQZVENQ7DTRP A10 F33T11；states 282292→282295与282352/282353/282355/282357；其余八锚点只核自身实际动作。

既有账本：silent-0030, silent-0257, silent-0258。

处置：waiting。狡诈生成与容量已有实现；WQ两组实添2/0/0和3/2/0已核。缺计划妥当保留、跨抽牌重问、SL恢复及穿插用药完整候选到执行的联合验证，不能整项duplicate。

反例与限制：有空位与满手的生成量不同；六次SL同局不是六个独立容量或穿插胜率样本。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-47910f82a1fdd98f

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md

证据：TXZ6RVMQA09D A10 F43/F45/F46/F48/F49T1；WQZVENQ7DTRP A10 F33T7/T9/T11。

既有账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。

处置：waiting。限定组合开场失血与连战资源传递已有实现；缺未知回血/复活组合时序、留药和SL成对后继及两战联合校准，窄公式不能关闭整体资源策略。

反例与限制：首战4血仍会在下一场可行动前归零；SL恢复到已扣过开场成本的盘面，不能再当新开战重复扣费。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-f1374df72d8e6a25

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md

证据：1913SE84AXQF A10 F17/F29/F31；Q6M2Y34MWKRE A10 F2T1/T3、F8及F9。

既有账本：silent-0019, silent-0020, silent-0050, silent-0253。

处置：waiting。1913与Q6的赢战退出资源可追溯；缺隔离机制误差后同入口同预算的不用/早用/留药整战及下一战成对结果，不能由局部候选或低信心答选推导药价和终局权重。

反例与限制：Q6药水最终确实饮用且选过休息，不能归因为拒绝用药/回血；未执行的早用候选不构成整局获胜反事实。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-38a49e6c97f31eea

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md

证据：Q6M2Y34MWKRE A10 F2T3、F8T4；1913SE84AXQF A10 F31T2—T4。

既有账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。

处置：waiting。普通紧勒、普通磨蚀出牌属性等已有子实现；缺弃磨蚀、常驻/临时增益、再生/自动触发与SL恢复的联合消费者和受控完整后继，不能拼接为整项实现。

反例与限制：Q6 F2T3敏捷后双防御确实挡满14，但后来仍死亡，不能把整局败认作该局部公式反例。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-ef0e38a5dbd3bc07

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md

证据：1913SE84AXQF A10 F24/F28/F29/F31；Q6M2Y34MWKRE A10 F3/F7/F8/F9；路线反事实未实走。

既有账本：silent-0019, silent-0020, silent-0021。

处置：waiting。Q6 F8赢后2血接F9、1913 F29赢后46血均可核；缺另一营火动作、事件/路线和用药时点的受控完整结果，条件变化及敌人构筑混杂不能拟合路线或终局参数。

反例与限制：1913 F24实际锻造改变原回血条件；Q6已休息仍在赢精英后以2血接下一战，不能由未走路线推因果。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-7f820c02d39bfaea

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md

证据：NHA2KW0RB7VP A10 F33T1；states 283391/283396/283397、283502/283506/283507，原决策277248/277250/277272/277274。

既有账本：silent-0079。

处置：waiting。NHA F33T1两线实损1/7已核，同局六败并非六独立局；缺同预算饱和排序校准、跨弃牌完整候选执行归属和成对整战后继，不能由6血换16伤确定SL门槛。

反例与限制：NHA输出推进增加仍六试皆败；重放同一替线不是独立验证，不证明少损或多伤任一单指标足够。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## silent-proposal-04b6b430759815ed

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md

证据：NHA2KW0RB7VP A10 F17T1、F33T1/T2；K3676LU8B0UH A1 F30T2、SADL3CGYTGSR A7 F45；油灯首用/后续与朝向分别核，未覆盖分支保留未知。

既有账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。

处置：waiting。蟹朝向取整和普通精确切击已有受限实现；油灯已核窗口stack均为null，缺首次消费跨动作、新战/SL恢复的完整联合输入及消费者；未覆盖X值/升级/叠层与能力完整后继，不能整项duplicate。

反例与限制：油灯首用前后stack均null，持有不能标定尚未消费；蟹显示1与后方2只支持已见条件，不提供通用取整顺序。

预期行为：保留当前生产规则与已实现子项；缺证分支保持未知，不把本项标为整体实现。

验证：先按所列原行与固定窗口验证局部数值及资源时点，再按本项缺口补受控完整后继；未来新局按run和时间隔离验证。

回退：无本批新源码提交，无新规则需要回退；保留原提案、失败与账本。

## 预期行为、验证与限制

保留生产药价、HP护栏、SL准入/饱和排序及终局权重；预测并列不等实际资源相同。缺完整执行证据的字段继续未知，不补候选ID/尝试身份，不把局部观察记成完整消费者认证。没有对既有机制公式的新反例，也没有支持新阈值的独立整战胜因；沙坑旧未live理由属于部署事实过时，非新游戏结论。

固定窗口只作已知数值和来源核验，不拟合自由参数、不计算胜率提升。同一局SL合并为一个独立样本；当前十五局为发现/回放集，不能再称样本外策略验证。后续需要按run与时间隔离的本角色新局，保持入口、牌组、预算、抽序/生成/选择等受控，并保留完整后继；未知开场组合还需各结算中间帧。证据充分后才比较新规则与原规则的完整资源和生存结果。当前没有可回退的新源码提交，原数据与失败均保留。

本次未改生产/任务/构建源码或知识。tsc、vitest、生产固定案例和撤源码失败/恢复通过均未运行、不适用，tests三项null；机械证据核查退出0不冒作生产测试。未commit、未merge、未分配eval版本、未登记shipped；不运行play、不请求模型/网络、不推送。implementation_domains为空，仅复用十个原代码提案id，不新建重复id。31条原账本仅经根CLI追加本批proposal/report追溯，保留原claim、status、evidence、首证、版本与effect，不增support/repeat或降级已shipped。

交运维：本目录 proposal.md、proposal-dispositions.json、report.json 与逐流证据清单。父提案及学习要求继续保留，完成本报告不等于量化学习、经验入库或消费者采用完成。

交付检查：根ledger CLI退出0、31条仅追溯字段，旧账本字节前缀SHA保持；交付文本gitleaks扫描退出0。工作树tracked/index干净，HEAD仍为报告base。机械证据核验不是生产tsc/vitest。

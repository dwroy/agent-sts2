import collections
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
EVIDENCE = BASE / 'evidence-retry'
spec = importlib.util.spec_from_file_location('extract_evidence', BASE.parents[1] / 'extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def save(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def compact(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    hand = combat.get('hand') or []
    return {
        'run_id': item['run_id'], 'line': item['line'], 'offset': item['offset'],
        'bytes': item['bytes'], 'sha256': item['sha256'], 'ts': item['row']['ts'],
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'cards_played': player.get('cards_played_this_turn'),
        'hand': [[x.get('card_id'), x.get('upgraded')] for x in hand],
        'potions': [[x['index'], x['potion_id']] for x in run.get('potions', []) if x.get('occupied')],
        'lamp': [x for x in run.get('relics', []) if x.get('relic_id') == 'UNSETTLING_LAMP'],
        'enemies': [{
            'id': x.get('enemy_id'), 'hp': x.get('current_hp'), 'block': x.get('block'),
            'powers': {p['power_id']: p['amount'] for p in x.get('powers', [])},
            'intents': [[p.get('damage'), p.get('hits')] for p in x.get('intents', [])],
        } for x in combat.get('enemies', [])],
    }


selected_lines = set([
    281312, 281313, 281338, 281339, 281367, 281368, 281399, 281400,
    281479, 281484, 281535, 281539, 281563, 281565, 281566,
    282075, 282079, 282144, 282148, 282292, 282293, 282294, 282295,
    282330, 282334, 282336, 282352, 282353, 282355, 282357,
    283146, 283147, 283391, 283394, 283395, 283396, 283397, 283398, 283399,
    283400, 283502, 283505, 283506, 283507,
    282804, 282806, 282807, 282808, 282809,
    282887, 282888, 282889, 282890, 282891, 282892,
])
states = {}
fixed_raw = {}
verification = []
drinks = []
decision_rows = []
fight_endpoints = {}
target_floors = {'KEN58SH9SLZ6': [5, 17], 'TXZ6RVMQA09D': [48, 49],
                 'WQZVENQ7DTRP': [33], '1913SE84AXQF': [17, 29, 31],
                 'Q6M2Y34MWKRE': [2, 8, 9]}

for entry in json.loads((EVIDENCE / 'evidence-manifest.json').read_text()):
    stream = entry['stream']
    output = EVIDENCE / (stream + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = dict.fromkeys(entry['counts'], 0)
    source = Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')
    with output.open('rb') as records, source.open('rb') as original:
        for encoded in records:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['run_id'] == module.run_identity(item['row'])
            assert item['offset'] + item['bytes'] <= entry['source_size']
            original.seek(item['offset'])
            raw = original.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            counts[item['run_id']] += 1
            if stream == 'states':
                state = item['row']['state']
                assert (state.get('run') or {}).get('character_id') == 'SILENT'
                if item['line'] in selected_lines:
                    states[item['line']] = compact(item)
                    fixed_raw[item['line']] = item['row']
                run = state.get('run') or {}
                if run.get('floor') in target_floors.get(item['run_id'], []) and state.get('in_combat'):
                    key = item['run_id'] + ':' + str(run['floor'])
                    point = compact(item)
                    if key not in fight_endpoints:
                        fight_endpoints[key] = {'first': point, 'last': point}
                    else:
                        fight_endpoints[key]['last'] = point
            if stream == 'decisions':
                row = item['row']
                chosen = row.get('chosen') or {}
                if chosen.get('action') == 'use_potion':
                    drinks.append({k: item[k] for k in ['run_id', 'line', 'offset', 'bytes', 'sha256']} |
                                  {k: row.get(k) for k in ['floor', 'turn', 'chosen', 'result', 'ts']})
                if row.get('decision_id') in [275383, 275384, 275385, 275894, 275960, 276139, 277248, 277250, 277272, 277274]:
                    decision_rows.append(item)
    assert counts == entry['counts']
    assert digest.hexdigest() == entry['output_sha256']
    verification.append({'stream': stream, 'source_size': entry['source_size'], 'rows': sum(counts.values()),
                         'counts': counts, 'offset_bytes_sha_identity_verified': True,
                         'invalid_source_lines': entry['invalid_lines'],
                         'incomplete_source_lines': entry['incomplete_lines']})

assert set(states) == selected_lines
assert fixed_raw[282075]['fingerprint'] == fixed_raw[282144]['fingerprint']
def hp(line):
    return states[line]['hp']

def enemy_hp(line):
    return sum(x['hp'] for x in states[line]['enemies'])

checks = {
    'TXZ_T6_original': {'hp_loss': hp(281479) - hp(281484), 'damage': enemy_hp(281479) - enemy_hp(281484)},
    'TXZ_T6_replacement': {'hp_loss': hp(281535) - hp(281539), 'damage': enemy_hp(281535) - enemy_hp(281539)},
    'WQZ_T9_original': {'hp_loss': hp(282075) - hp(282079), 'damage': enemy_hp(282075) - enemy_hp(282079)},
    'WQZ_T9_replacement': {'hp_loss': hp(282144) - hp(282148), 'damage': enemy_hp(282144) - enemy_hp(282148)},
    'TXZ_F49': [hp(281565), hp(281566)],
    'WQZ_hand_first_sequence': [len(states[n]['hand']) for n in [282292, 282293, 282294, 282295]],
    'WQZ_shivs_first_sequence': [sum(c[0] == 'SHIV' for c in states[n]['hand']) for n in [282292, 282293, 282294, 282295]],
    'WQZ_hand_second_sequence': [len(states[n]['hand']) for n in [282352, 282353, 282355, 282357]],
    'WQZ_shivs_second_sequence': [sum(c[0] == 'SHIV' for c in states[n]['hand']) for n in [282352, 282353, 282355, 282357]],
    'NHA_T1_original_hp_loss': hp(283391) - hp(283397),
    'NHA_T1_replacement_hp_loss': hp(283502) - hp(283507),
}
assert checks['TXZ_T6_original'] == {'hp_loss': 3, 'damage': 36}
assert checks['TXZ_T6_replacement'] == {'hp_loss': 0, 'damage': 27}
assert checks['WQZ_T9_original'] == {'hp_loss': 13, 'damage': 24}
assert checks['WQZ_T9_replacement'] == {'hp_loss': 22, 'damage': 39}
assert checks['TXZ_F49'] == [4, 0]
assert checks['WQZ_shivs_first_sequence'] == [0, 2, 2, 2]
assert checks['WQZ_shivs_second_sequence'] == [0, 3, 5, 5]
assert checks['NHA_T1_original_hp_loss'] == 1
assert checks['NHA_T1_replacement_hp_loss'] == 7
save('evidence-verification.json', verification)
save('fixed-states.json', list(states.values()))
save('fixed-decisions.json', decision_rows)
save('fixed-observations.json', checks)
save('potion-actions.json', drinks)
save('fight-endpoints.json', fight_endpoints)
print(json.dumps({'streams': len(verification), 'verified_rows': sum(x['rows'] for x in verification),
                  'fixed_states': len(states), 'observations': checks,
                  'potion_actions': dict(collections.Counter(x['run_id'] for x in drinks))}, ensure_ascii=False))

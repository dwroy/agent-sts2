import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-183355'
SCRATCH = ROOT / 'learner/runs/20261016-183403-64766a9a-6fde-4c7f-b500-daf047c80fd1-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-174314-32e7f6b9-0c15-4c43-89b3-9c843eb5e8e8-fix-batch'
BASE = 'a73af7b4ee4839cfd2f54677b86ff5d610e29936'
STALL = '21a9c52484f04d510bd397959c958ec9767f1d2d'


def git(*args, tree=TREE):
    return subprocess.check_output(['git', '-C', str(tree), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, obj):
    (SCRATCH / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert not git('status', '--porcelain')
prior = json.loads((PRIOR / 'audit.json').read_text())
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live').decode().strip()
base_ancestors = set(git('rev-list', BASE).decode().splitlines())
live_ancestors = set(git('rev-list', live).decode().splitlines())
files = []
for old in prior['current_files']:
    path = old['path']
    assert Path(path).name != '.env' and not path.endswith('.env')
    raw = git('show', f'{BASE}:{path}')
    assert (TREE / path).read_bytes() == raw, path
    row = {'path': path, 'sha256': sha(raw), 'prior_sha256': old['sha256'],
           'same_as_prior': sha(raw) == old['sha256']}
    if not row['same_as_prior']:
        assert path == 'ops/stall-check.sh', row
        assert git('show', f'{STALL}:{path}') == raw
        row['changed_by_existing_fix'] = STALL
    files.append(row)
assert sum(not row['same_as_prior'] for row in files) == 1
new_test = 'agent/tests/ops-stall-between-runs.test.ts'
assert (TREE / new_test).read_bytes() == git('show', f'{STALL}:{new_test}')
files.append({'path': new_test, 'sha256': sha((TREE / new_test).read_bytes()),
              'new_since_prior': True, 'changed_by_existing_fix': STALL})

fixed = []
for old in prior['existing_fixes'] + [{'item': 'infra-stall-between-run-quiet：正常完局报告期间的静默误报', 'commit': STALL}]:
    row = {**old, 'ancestor_in_base': old['commit'] in base_ancestors,
           'ancestor_in_live': old['commit'] in live_ancestors}
    assert row['ancestor_in_base'] and row['ancestor_in_live'], row
    fixed.append(row)

queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
old_queue = (PRIOR / 'queue-readonly-snapshot.md').read_bytes()
assert queue.startswith(old_queue)
append = queue[len(old_queue):].decode()
assert 'silent-0496' in append and STALL in append
assert len([line for line in append.splitlines() if line.startswith('- ')]) == 2
unchecked = [(i + 1, line) for i, line in enumerate(queue.decode().splitlines()) if line.startswith('- [ ]')]
assert unchecked == [(row['line'], row['item']) for row in prior['queue_dispositions']]
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)

focused = []
for old in prior['focused_source_review']:
    found = [i + 1 for i, line in enumerate((TREE / old['path']).read_text().splitlines()) if old['anchor'] in line]
    assert found, old
    focused.append({**old, 'current_matching_lines': found})
for path, anchor in [
    ('ops/stall-check.sh', 'reporting_finished_run=1'),
    ('ops/stall-check.sh', '[ "$reporting_finished_run" -eq 0 ]'),
    ('agent/src/hand/screens/selection.ts', 'kind === "combat_hand_select" && min === 0'),
    ('agent/src/hand/screens/selection.ts', 'selected >= min && canConfirm && !pickFirst'),
    ('agent/src/reflex/card-model.ts', 'const draw = escapePlan ? 1'),
]:
    found = [i + 1 for i, line in enumerate((TREE / path).read_text().splitlines()) if anchor in line]
    assert found, (path, anchor)
    focused.append({'path': path, 'anchor': anchor, 'current_matching_lines': found})

for name in ['evidence-0332-readback.json', 'evidence-0308-readback.json']:
    record = json.loads((PRIOR / name).read_text())
    for row in record['rows']:
        source = Path(record['path']) if 'path' in record else ROOT / 'logs' / (row['stream'] + '.jsonl')
        with source.open('rb') as handle:
            handle.seek(row['offset'])
            raw = handle.read(row['bytes'])
        assert sha(raw) == row['sha256'], (name, row)
        value = json.loads(raw)
        if row.get('run_id'):
            assert value['run_id'] == row['run_id']
        if row.get('run'):
            assert value['run_id'] == row['run']
    save(name, {**record, 'verified_in_this_batch': True,
                'this_batch_scope': '只核原始字节和身份；沿原策略链，未新增游戏规则或重跑模拟。'})

publication_path = ROOT / 'paper/materials/20261016-1815-ops/publication.json'
publication = json.loads(publication_path.read_text())
assert publication['source'] == STALL
for leaf in publication['leaves']:
    assert sha((TREE / leaf['path']).read_bytes()) == leaf['sha256']
    assert sha(git('show', f'{live}:{leaf["path"]}')) == leaf['sha256']
save('stall-publication-readback.json', {'source': str(publication_path), 'sha256': sha(publication_path.read_bytes()),
     'source_commit': STALL, 'ancestor_in_base_and_live': True,
     'source_and_deployed_leaves_verified': publication['leaves'],
     'prior_host_full_pending_at_publication': True,
     'limitation': '未轮询原宿主检查、未把历史定向通过当本批新测试或完整套件通过。'})

proposal_path = ROOT / 'learner/runs/20261016-174312-65dcdb44-5883-4a71-9a00-b4180ade1b67-postmortem/proposal-retrieval.md'
proposal = proposal_path.read_text()
assert 'silent-0496' in proposal and 'deck_card_select' in proposal
assert '零选本身是合法游戏动作' in proposal
proposal_id = 'silent-proposal-0cd2f0dfbc4a0805'
registry = ROOT / 'paper/materials/learning/code-proposals.jsonl'
registry_matches = []
with registry.open('rb') as handle:
    offset = 0
    for raw in handle:
        if proposal_id.encode() in raw:
            value = json.loads(raw)
            registry_matches.append({'offset': offset, 'bytes': len(raw), 'sha256': sha(raw), 'value': value})
        offset += len(raw)
assert registry_matches
save('0496-proposal-readback.json', {'proposal': str(proposal_path), 'sha256': sha(proposal_path.read_bytes()),
     'registry': str(registry), 'rows': registry_matches,
     'disposition': '策略类：原0cd2f0df独立strategy-proposal已有登记；本批不强制取牌、不重派、不标implemented/shipped。'})

changed = git('diff', '--name-only', prior['base'], BASE).decode().splitlines()
source_changes = [path for path in changed if path.startswith(('agent/src/', 'agent/tests/', 'agent/tools/', 'knowledge/builders/', 'learner/', 'eval/', 'ops/')) and path != 'ops/inbox-dev.md']
assert sorted(source_changes) == sorted(['ops/stall-check.sh', new_test]), source_changes
audit = {'checked_at': checked_at, 'base': BASE, 'live_read_only_snapshot': live,
         'prior_audit': str(PRIOR / 'audit.json'), 'prior_audit_sha256': sha((PRIOR / 'audit.json').read_bytes()),
         'queue_sha256': sha(queue), 'queue_lines': len(queue.decode().splitlines()), 'queue_append': append,
         'unchecked_entries': len(unchecked), 'queue_dispositions': prior['queue_dispositions'],
         'current_files': files, 'existing_fixes': fixed, 'focused_source_review': focused,
         'code_changes_since_prior': source_changes, 'new_source_changes': [],
         'no_new_pure_bug': True, 'no_tests_run_this_batch': True,
         'scope': '无新增源码、提交或合入；已修窄子项不关闭宽父，未改修复队列/账本/策略或游戏知识。'}
save('audit.json', audit)
print(json.dumps({'checked_at': checked_at, 'base': BASE, 'live': live,
      'prior_files_unchanged': sum(row.get('same_as_prior', False) for row in files),
      'prior_files_changed_by_existing_stall_fix': 1, 'new_fixed_test_leaf': 1,
      'existing_fixes_verified': len(fixed), 'unchecked_entries_reviewed': len(unchecked),
      'evidence_rows_verified': 10, '0496_existing_proposal': proposal_id,
      'new_source_changes': [], 'tests_this_batch': None}, ensure_ascii=False))

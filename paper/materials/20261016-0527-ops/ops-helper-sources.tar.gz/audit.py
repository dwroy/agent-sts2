from pathlib import Path
import collections,hashlib,importlib.util,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0527';pub=r/'paper/materials/20261016-0527-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
bid='20261016-051301';run='LTQ083RTNZJQ';s=r/'learner/runs/20261016-051304-c9749e90-8b0f-4ef1-af9c-221108d479e1-postmortem';report=load(s/'report.json');b=load(r/'ops/codex-ops/learn.json')['batches'][bid]
assert report['appended']==[run] and report['bugs']==report['ledger']['added']==report['ledger']['repeats']==[] and len(report['ledger']['updated'])==8 and report['ledger']['check']==0
assert b['state']=='done' and b['rc']==0 and b['done']==[run] and b['missing']==[] and b['proposal_audit_errors']==[]
out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output)
spec=importlib.util.spec_from_file_location('raw_identity',r/'learner/extract_evidence.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
verification=load(s/'verification.json');refs=[];counts={};runrow=None;config=None;brains=[];decisions=[];frames={}
for stream in ['states','decisions','sl-attempts','run-config','run-plans','runs','brain','jev-prompts','deepseek-reasoning']:
    count=0;selectedfile=s/(stream+'.jsonl');assert sha(selectedfile.read_bytes())==verification['sources'][stream]['sha256']
    with selectedfile.open('rb') as selected,(r/'logs'/(stream+'.jsonl')).open('rb') as original:
        for encoded in selected:
            frozen=json.loads(encoded);original.seek(frozen['_offset']);raw=original.read(frozen['_bytes']);row=json.loads(raw)
            assert len(raw)==frozen['_bytes'] and raw.endswith(b'\n') and sha(raw)==frozen['_sha256'] and extract.run_identity(row)==run and row=={k:v for k,v in frozen.items() if k not in ['_line','_offset','_bytes','_sha256']}
            if stream=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10);frames[frozen['_line']]=row
            if stream=='runs':assert (row['character'],row['ascension'],row['floor'],row['victory'])==('SILENT',10,25,False);runrow=row
            if stream=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains.append(row)
            if stream=='run-config':config=row
            if stream=='decisions':decisions.append(row)
            refs.append(dict(stream=stream,learner_reported_source_line=frozen['_line'],offset=frozen['_offset'],bytes=len(raw),sha256=sha(raw)));count+=1
    counts[stream]=count;assert count==verification['sources'][stream]['rows']
assert counts==dict(states=578,decisions=544,**{'sl-attempts':5,'run-config':1,'run-plans':6,'jev-prompts':138,'deepseek-reasoning':0},runs=1,brain=26) and len(refs)==1299
post=load(s/'post-verification.json');before=load(s/'lessons-before.json');physical=(r/'notes/lessons.md').read_bytes();section=(s/'appended-section.md').read_bytes();lesson=b'\n'+section
assert sha(physical[:before['bytes']])==before['sha256'] and sha(section)==post['section_sha256'] and len(section)==post['section_bytes']==22911
assert physical[before['bytes']:before['bytes']+len(lesson)]==lesson and sum(x.startswith(b'## LTQ083RTNZJQ') for x in physical.splitlines())==1 and lesson.count('### 勘误（2026-10-16 05:23:43 CST，learner）'.encode())==1
assert post['all_support'] and post['old_fields_preserved'] and (s/'source.diff').read_bytes()==b'' and load(s/'gitleaks.json')==[]
(p/'owned-lessons.md').write_bytes(lesson)
source=config['code']['commit'];assert source=='e716bd28fd8eca9e4d76d066680304fd11935e37' and config['brain']['engines']['codex']['model']=='gpt-6.1-sol' and config['brain']['engines']['codex']['effort']=='xhigh' and config['brain']['codex']['service_tier']=='default'
assert not any(d.get('fallback') for d in decisions)
usage={key:sum(row['usage'][key] for row in brains) for key in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}
assert usage==dict(inputTokens=4541094,outputTokens=33288,cacheHitTokens=1778944,reasoningTokens=29627) and sum(row['latency_ms'] for row in brains)==1011469
assert sum(bool(d.get('hp_guard')) for d in decisions)==2 and collections.Counter(str(d.get('rollout_best_chosen')) for d in decisions if d['decider']=='jev' and d['label'].startswith('combat/'))=={'True':110,'False':1}
ids=set(report['ledger']['updated']);owned=[];ledgerrefs=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('by')=='learner:postmortem' and row.get('id') in ids and (any(e.get('run')==run for e in row.get('evidence',[])) or str(s) in raw.decode() or run in row.get('where',{}).get('lessons',[])):
            assert row['op']=='update' and set(row)<={'op','id','ts','by','evidence','where','note'} and all(e['run']==run and e['role']=='support' for e in row.get('evidence',[]))
            owned.append(raw);ledgerrefs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==16 and sum('evidence' in json.loads(raw) for raw in owned)==8
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'owned-ledger-references.json',ledgerrefs)
item=load(s/'proposal-item.json');ident=(s/'proposal-cli.out').read_text().strip();assert report['code_proposals']==[ident] and ident=='silent-proposal-bbda5ece5c61191b'
matches=[]
with (r/'paper/materials/learning/code-proposals.jsonl').open('rb') as f:
    while True:
        offset=f.tell();raw=f.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('op')=='add' and row.get('id')==ident:matches.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(matches)==1;original_proposal=matches[0]['row'];assert original_proposal['state']=='pending' and all(original_proposal.get(k)==v for k,v in item.items()) and sha(Path(item['proposal']).read_bytes())==original_proposal['proposal_sha256']
spec=importlib.util.spec_from_file_location('original_proposals',r/'learner/code_proposals.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);current=m.fold(r/'paper/materials/learning/code-proposals.jsonl')[ident]
write(pub/'postmortem-original-references.json',refs)
write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,native=native,original_rows_checked=1299,stream_counts=counts,raw_binding='Frozen original offset/bytes/SHA, original JSON and explicit run identity independently verified; source lines remain learner-reported.',actual_accepted_codex=26,original_run_row=runrow,actual_run_config=config,source_reference=source,source_reference_does_not_reconstruct_dirty_knowledge=True,post_append=post,original_lesson_bytes=22912,original_section_bytes=22911,leading_newline_bytes=1,old_lesson_prefix_preserved=True,original_ledger_rows=16,new_ledger_ids=[],old_support_ids=report['ledger']['updated'],repeats=[],original_proposals=matches,current_proposal_state=current['state'],new_bug=False,actual_brain_usage=usage,original_verification=verification,limits='Three SL exits remain censored, net HP is not uncapped damage, and full candidate outcomes, unchosen routes/potion retention/other target orders, entity generations and missing intermediate frames remain unknown. Historical dirty knowledge snapshots, calibrated clocks/unvisited rest andact2 Boss, pure combat time, Jev cache and paid invoices remain unknown. R365 startup code is not a matched Paper Krane/beam consumer.',material_corrections_retained=['Original PINPOINT ID error and attribution of14/10 block to replay kept; append-only erratum attributes the observed multipliers to PAELS_LEGION and does not infer stable card UID.','Original before-Boss wording corrected to before-final-normal-fight; potion counts unchanged. No model/source or previous knowledge claim rewritten.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);print(json.dumps(dict(rows=1299,ledger_rows=16,lesson_bytes=22912,new_bug=False)))

from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile
sys.dont_write_bytecode=True
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0527'; pub=r/'paper/materials/20261016-0527-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1; log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut; runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected=[x for x in runs if x['run_id']=='LTQ083RTNZJQ']; assert len(selected)==1; row=selected[0]
assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max='25',n_decisions='544',has_postmortem='1',performance_included='1').items()); brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':26} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],run={k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r))); write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==16; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==16
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(z)==set(a)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['evidence','where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['evidence','where','history','notes']}
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert a[ident].get(key)==z[ident].get(key),(ident,key)
 previous=a[ident].get('evidence',[]); later=z[ident].get('evidence',[]); assert later[:len(previous)]==previous; assert all(x['run']=='LTQ083RTNZJQ' and x['role']=='support' for x in later[len(previous):])
 for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
 for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==22912 and b'## LTQ083RTNZJQ' not in oldlesson and lesson in (r/'notes/lessons.md').read_bytes(); readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged16_rows']=True; readback['parallel_physical_rows_preserved']='Only own chapter and16 original CLI rows staged; other root records and pre-existing whitespace differences remain physical/uncommitted.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0527原051301复盘LTQ083RTNZJQ done0闭环，无新增纯bug，不重复队列/复派。九流1299所属原行按冻结offset/bytes/SHA/原JSON/显式身份核，deepseek推理窗口0保持，原行号记为学习者报告值；Silent A10/F25普通战负局、544决策/578状态/138Jev/26原accepted Codex Sol6.1/xhigh。13此前战斗与末战四试分列，前三SL退出截断，末次2HP0挡对主怪12攻完整需损12/缺至少11，实扣剩2，不将封顶净损当毛伤；幻象复起/同ID代际及逐击中间帧缺失保持，净扣6不补造逐击荆棘全计数。22911字节正式节及前置换行1字节/旧物理前缀SHA核，原ID/重放归因/王前措辞与追加勘误均保：PINPOINT、首张防御由PAELS_LEGION实翻倍不推稳定UID、末战前非Boss前；当轮2敏实增8/31对32缺1血及药数不变，不回写旧句或新增机制。16所属CLI含八旧项support及八原提案追溯，私有fold旧claim/首证/prior/status/version和证据/history/notes/where前缀保，不重复CLI或造新shipped；bbda5ece5c61191b原注册/SHA/pending沿自动独立策略链，无整线/留药反事实不改规则。两护栏及Jev110/111、12低信心/12饮0弃/无fallback为观察，不作策略收益；实际脑4541094入/33288出/1778944缓存/29627推理及1011469ms核，不叠加已含run-plan或编Jev缓存/实付。启动e716/R365源码及dirty知识快照边界保持，不仅凭版本当纸鹤光束匹配消费者；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0、cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策，五一致性/keyscan CLEAN，本局has_postmortem1/544决策/26成功Codex入表；原计数告警、各组件独立cut估计非账单保留。仅所属复盘/16CLI/生成表及证据提交，保并行物理记录，无代码/知识/版本/补测/派发/对局重启/账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261016-0527-ops/。\n'
note=f'\n- {at} [ops 学习闭环] LTQ083RTNZJQ复盘及16所属CLI已核，无新增纯bug；八项support与八提案追溯、bbda5ece原策略提案沿自动链，前三SL及完整替线/留药后继未知保持。原章与ID/格挡来源/末战措辞追加勘误均保留；论文唯一刷新exit0、{len(runs)}局、五一致性/keyscan通过，无新发布或对局操作。回执paper/materials/20261016-0527-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in p.glob('*.py'):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortem='LTQ083RTNZJQ',original_rows_checked=1299,original_lesson_bytes=22912,original_section_bytes=22911,leading_newline_bytes=1,new_bug=False,owned_ledger_rows=16,evidence_updates=8,repeat_evidence=0,support_evidence=8,proposal_links=8,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=16,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

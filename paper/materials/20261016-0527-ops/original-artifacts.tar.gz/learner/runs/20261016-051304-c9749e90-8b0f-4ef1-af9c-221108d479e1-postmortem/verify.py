import json,hashlib,collections
from pathlib import Path
P=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2');sources={}
for f in P.glob('*.jsonl'):
 name=f.stem;src=root/'logs'/f.name
 if not src.exists():continue
 count=0
 with f.open() as selected,src.open('rb') as original:
  for line in selected:
   r=json.loads(line);original.seek(r['_offset']);raw=original.read(r['_bytes'])
   assert hashlib.sha256(raw).hexdigest()==r['_sha256'],(name,r['_line']);count+=1
   if name=='deepseek-reasoning':continue
   a=json.loads(raw)
   assert a.get('run_id',a.get('run',(a.get('state') or {}).get('run_id')))=='LTQ083RTNZJQ',(name,r['_line'])
 sources[name]={'rows':count,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
D=[json.loads(x) for x in (P/'decisions.jsonl').open()];S=[json.loads(x) for x in (P/'states.jsonl').open()];J=[json.loads(x) for x in (P/'jev-prompts.jsonl').open()];B=[json.loads(x) for x in (P/'brain.jsonl').open()];R=json.loads((P/'LTQ083RTNZJQ-resources.json').read_text())
assert len(D)==544 and len(S)==578 and len(J)==138 and len(B)==26
assert len(R['combats'])==17 and all(x['entry_is_turn_one'] for x in R['combats'])
assert [(x['entry']['hp'],x['exit']['hp']) for x in R['combats'][:13]]==[(56,56),(56,53),(53,53),(53,50),(50,44),(65,45),(66,46),(46,42),(63,34),(62,58),(58,45),(45,45),(45,13)]
assert [x['end'] for x in R['combats'][13:]]==['restart_observed']*3+['observed_exit']
end=S[-2]['state'];assert end['run']['current_hp']==2 and end['combat']['player']['block']==0
assert [(e['enemy_id'],e['current_hp']) for e in S[-1]['state']['combat']['enemies']]==[('PARAFRIGHT',21),('THE_OBSCURA',71)]
assert len([x for x in D if 'hp_guard' in x])==2
assert collections.Counter(str(x.get('rollout_best_chosen')) for x in D if x['decider']=='jev' and x['label'].startswith('combat/'))=={'True':110,'False':1}
assert len([x for x in D if x['decider']=='jev' and x['confidence']<.35])==12
assert len([x for x in D if x['chosen']['action']=='use_potion'])==12
assert not any(x['chosen']['action']=='discard_potion' for x in D)
assert all(x['engine']=='codex' and x['model']=='gpt-6.1-sol' and x['effort']=='xhigh' and x['accepted'] for x in B)
assert sum(x['usage']['inputTokens'] for x in B)==4541094
assert sum(x['usage']['outputTokens'] for x in B)==33288
assert sum(x['usage']['cacheHitTokens'] for x in B)==1778944
checks=['原始offset/bytes/SHA和局号逐条一致','544决策/578状态/138Jev/26Codex','17窗口均T1入口且前三SL无退出','13胜战进退HP','末态2血0挡及敌21/71血','两护栏/110比111/12低信心/12饮0弃','实际模型与token合计']
(P/'verification.json').write_text(json.dumps({'sources':sources,'checks':checks,'result':'通过'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sources':{k:v['rows'] for k,v in sources.items()},'checks':len(checks),'result':'通过'},ensure_ascii=False))
for name in ['states','decisions','jev-prompts','brain','run-plans']:
 rows=[json.loads(x) for x in (P/(name+'.jsonl')).open()];print(name,rows[0]['_line'],rows[-1]['_line'])

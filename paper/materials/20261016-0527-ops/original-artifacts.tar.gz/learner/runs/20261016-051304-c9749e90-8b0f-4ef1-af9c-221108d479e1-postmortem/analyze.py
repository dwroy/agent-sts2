import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()]
with (p/'decisions-summary.txt').open('w') as o:
 for d in D:
  keys=['_line','ts','observed_ts','floor','turn','sl_attempt','label','decider','chosen','rationale','confidence','journal','result']
  if d['floor']>=24 or d['decider']=='codex' or 'hp' in d.get('rationale','').lower() or (d.get('chosen') or {}).get('action') in ['use_potion','discard_potion']:
   o.write(json.dumps({k:d.get(k) for k in keys},ensure_ascii=False)+'\n')
with (p/'turns.txt').open('w') as o:
 groups=[]
 for r in S:
  s=r['state'];c=s.get('combat') or {}
  if not s.get('in_combat') or not c.get('enemies'): continue
  key=(s['run']['floor'],s.get('turn'))
  if not groups or groups[-1][0]!=key:groups.append((key,[]))
  groups[-1][1].append(r)
 def show(r):
  s=r['state'];c=s.get('combat') or {};pl=c.get('player') or {}; rr=s['run']
  return {'line':r['_line'],'ts':r['ts'],'obs':r.get('observed_ts'),'hp':rr['current_hp'],'player':{k:v for k,v in pl.items() if k not in ['hand','draw_pile','discard_pile','exhaust_pile']},'enemies':c.get('enemies'),'hand':[{k:a.get(k) for k in ['index','card_id','name','energy_cost','resolved_rules_text']} for a in c.get('hand',[]) ]}
 for key,rows in groups:
  o.write(json.dumps({'floor_turn':key,'first':show(rows[0]),'last':show(rows[-1])},ensure_ascii=False)+'\n')
print('D',len(D),'S',len(S),'range',D[0]['ts'],D[-1]['ts'])
print('keys',list(D[-50]))
print('label counts',dict(collections.Counter((x['decider'],x['label']) for x in D)))
print('state combat keys',list(next(r['state']['combat'] for r in S if r['state'].get('in_combat'))))
print('plans')
for r in map(json.loads,(p/'run-plans.jsonl').open()):print(r['_line'],r['floor'],r.get('trigger'),json.dumps(r['plan'],ensure_ascii=False))
print('resource changes noncombat')
R=json.loads((p/'LTQ083RTNZJQ-resources.json').read_text())
for x in R['resource_changes']:
 if x['combat_sequence'] is None:print(json.dumps(x,ensure_ascii=False))
print('brain')
for r in map(json.loads,(p/'brain.jsonl').open()):print(r['_line'],r['ts'],r['label'],r['engine'],r['model'],r.get('effort'),r.get('accepted'),r.get('usage'))
print('rollout-ish fields',collections.Counter(k for x in D for k in x if any(t in k for t in ['roll','guard','plan','sl'])))
print('low',sum(x['decider']=='jev' and isinstance(x.get('confidence'),(int,float)) and x['confidence']<.35 for x in D))

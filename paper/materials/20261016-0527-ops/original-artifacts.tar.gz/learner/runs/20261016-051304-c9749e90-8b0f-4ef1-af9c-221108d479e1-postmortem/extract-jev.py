import json,re,hashlib
from pathlib import Path
p=Path(__file__).parent; d=[json.loads(x) for x in (p/'decisions.jsonl').open()]; ids=set()
for r in d:
 for ident in r.get('request_ids') or []:
  if isinstance(ident,str):ids.add(ident)
pattern=re.compile(b'|'.join(re.escape(x.encode()) for x in ids)) if ids else None
src=Path('/home/dw/Projects/agent-sts2/logs/jev-prompts.jsonl');cut=src.stat().st_size;offset=0;n=0
with src.open('rb') as f,(p/'jev-prompts.jsonl').open('w') as o:
 for num,line in enumerate(f,1):
  start=offset;offset+=len(line)
  if offset>cut:break
  if b'LTQ083RTNZJQ' not in line and not (pattern and pattern.search(line)):continue
  try:r=json.loads(line)
  except ValueError:continue
  r.update(_line=num,_offset=start,_bytes=len(line),_sha256=hashlib.sha256(line).hexdigest());o.write(json.dumps(r,ensure_ascii=False)+'\n');n+=1
print('requests',len(ids),'rows',n)

import json,hashlib,subprocess,re
from pathlib import Path
P=Path(__file__).parent;before=json.loads((P/'lessons-before.json').read_text());f=Path('notes/lessons.md');h=hashlib.sha256();remaining=before['bytes']
with f.open('rb') as r:
 while remaining:
  chunk=r.read(min(1048576,remaining));assert chunk;h.update(chunk);remaining-=len(chunk)
 suffix=r.read()
assert h.hexdigest()==before['sha256'],'原物理前缀变化'
needle='## LTQ083RTNZJQ'.encode();assert suffix.count(needle)==1
start=suffix.index(needle);stop=suffix.find(b'\n## ',start+1);own=suffix[start:stop if stop>=0 else None].decode()
assert sum(line.startswith('- [') and not line.startswith('- [记录]') for line in own.splitlines())==3
assert own.count('### 勘误（2026-10-16 05:23:43 CST，learner）')==1
(P/'appended-section.md').write_text(own)
ids=['silent-0019','silent-0039','silent-0418','silent-0232','silent-0011','silent-0027','silent-0282','silent-0080']
# Read the ledger only through its CLI; preserve all original fields and add only this run's support.
result=subprocess.run(['python3','learner/ledger.py','find','--run','LTQ083RTNZJQ','--json'],capture_output=True,text=True);assert result.returncode==0
(P/'ledger-find-run.json').write_text(result.stdout);rows=json.loads(result.stdout);byid={x['id']:x for x in rows}
assert set(byid)==set(ids)
for ident in ids:
 a=byid[ident];e=[x for x in a['evidence'] if x['run']=='LTQ083RTNZJQ'];assert len(e)==1 and e[0]['role']=='support'
 assert 'LTQ083RTNZJQ' in a.get('where',{}).get('lessons',[])
 if (P/(ident+'.json')).exists():
  old=json.loads((P/(ident+'.json')).read_text())
  for k in ['claim','first_run','prior','prior_runs','prior_note','status','version']:assert old.get(k)==a.get(k),(ident,k)
proposal=(P/'proposal-cli.out').read_text().strip();assert re.fullmatch(r'silent-proposal-[a-f0-9]{16}',proposal)
print('物理前缀未改；一个标题、三条经验、一段记录、一处只追加勘误；八条support及旧字段保持。')
D=[json.loads(x) for x in (P/'decisions.jsonl').open()];S=[json.loads(x) for x in (P/'states.jsonl').open()]
for no in [419336,419362,419370,419463,419489,419490,419494,419495]:
 s=next(x for x in S if x['_line']==no);c=s['state'].get('combat') or {};print('原states',no,s['ts'],'F',s['state']['run']['floor'],'T',s['state']['turn'],'HP',s['state']['run']['current_hp'],'挡',(c.get('player') or {}).get('block'),'敌',[(e['enemy_id'],e['current_hp']) for e in c.get('enemies',[])])
for no in [406117,406201,406224,406245]:
 d=next(x for x in D if x['_line']==no);print('原decisions',no,d['rationale'])
(P/'post-verification.json').write_text(json.dumps({'old_prefix_unchanged':True,'section_sha256':hashlib.sha256(own.encode()).hexdigest(),'section_bytes':len(own.encode()),'primary_ledger':ids[:3],'mechanic_ledger':ids[3:],'all_support':True,'old_fields_preserved':True,'code_proposals':[proposal],'corrections':['PINPOINT','防御翻倍来自佩尔的士兵，非涡旋重放','末战前8次饮药，非王前']},ensure_ascii=False,indent=2)+'\n')

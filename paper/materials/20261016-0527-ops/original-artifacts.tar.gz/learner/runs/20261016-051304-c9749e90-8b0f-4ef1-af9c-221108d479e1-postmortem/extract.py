import json,re,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261016-051304-c9749e90-8b0f-4ef1-af9c-221108d479e1-postmortem'; run='LTQ083RTNZJQ'
for name in ['runs','decisions','run-plans','states','sl-attempts','brain','run-config','jev']:
    path=root/'logs'/f'{name}.jsonl'
    if not path.exists(): continue
    count=0; cutoff=path.stat().st_size; offset=0
    with path.open('rb') as f,(out/f'{name}.jsonl').open('w') as dest:
        for line_no,line in enumerate(f,1):
            start=offset; offset+=len(line)
            if offset>cutoff: break
            if run.encode() not in line: continue
            try: row=json.loads(line)
            except ValueError: continue
            if name=='states' and (row.get('state') or {}).get('run_id',row.get('run_id'))!=run:continue
            row['_line']=line_no;row['_offset']=start;row['_bytes']=len(line);row['_sha256']=hashlib.sha256(line).hexdigest()
            dest.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
    print(name,count,flush=True)
decisions=[json.loads(x) for x in (out/'decisions.jsonl').open()]; times=[r['ts'] for r in decisions]; lo,hi=min(times),max(times)
path=root/'logs/deepseek-reasoning.jsonl'; count=0; offset=0
if path.exists():
    cutoff=path.stat().st_size
    with path.open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as dest:
        for num,line in enumerate(f,1):
            start=offset;offset+=len(line)
            if offset>cutoff: break
            m=re.search(rb'"ts"\s*:\s*"([^"]+)"',line)
            if not m or not lo<=m[1].decode()<=hi:continue
            row=json.loads(line);row.update(_line=num,_offset=start,_bytes=len(line),_sha256=hashlib.sha256(line).hexdigest());dest.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
print('deepseek-window',lo,hi,count,flush=True)

import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract', HERE.parents[2] / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = set(dispatch['runs'])
windows = {json.loads(l)['ref']['offset']: json.loads(l)['ref']
           for l in (HERE / 'bounded-windows.jsonl').read_text().splitlines()}
window_matches = set()
results = []
selected_decisions = []
decision_lines = {270216, 270264, 270282, 271309, 271348, 271354,
                  271982, 271992, 272040, 272076, 272195, 272204, 272209}
for folder in ('evidence', 'evidence-extra'):
    manifest = json.loads((HERE / folder / 'evidence-manifest.json').read_text())
    for stream in manifest:
        path = HERE / folder / (stream['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = Counter()
        with path.open('rb') as data, (Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')).open('rb') as source:
            for line in data:
                digest.update(line)
                item = json.loads(line)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert len(raw) == item['bytes']
                assert item['offset'] + item['bytes'] <= stream['source_size']
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                row = json.loads(raw)
                assert row == item['row']
                assert extract.run_identity(row) == item['run_id'] and item['run_id'] in runs
                counts[item['run_id']] += 1
                if stream['stream'] == 'states' and item['offset'] in windows:
                    ref = windows[item['offset']]
                    assert all(item[k] == ref[k] for k in ('source', 'offset', 'bytes', 'sha256'))
                    window_matches.add(item['offset'])
                if stream['stream'] == 'decisions' and item['line'] in decision_lines:
                    selected_decisions.append(item)
        assert digest.hexdigest() == stream['output_sha256']
        assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
        results.append({'stream': stream['stream'], 'rows_verified': sum(counts.values()),
                        'counts': stream['counts'], 'output_sha256_verified': True,
                        'source_size': stream['source_size'],
                        'invalid_source_lines': stream['invalid_lines']})
assert window_matches == set(windows)
assert {i['line'] for i in selected_decisions} == decision_lines
(HERE / 'selected-decisions.json').write_text(json.dumps(selected_decisions, ensure_ascii=False, indent=2) + '\n')
result = {'ok': True, 'streams': results, 'rows_verified': sum(r['rows_verified'] for r in results),
          'bounded_window_refs_verified': len(window_matches),
          'scope': '材料完整性与归局核验，不是tsc/vitest、生产重放或完整候选执行认证。'}
(HERE / 'evidence-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

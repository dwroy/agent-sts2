# 本批策略提案核验报告

本批10项均为waiting；没有足够证据新增可验证的策略实现。局部已有实现不记整项duplicate，未产生源码提交、合入或新发布号。

- task=strategy-proposal；character=silent；batch=20261018-064303-s2-strategy-proposal。
- report.base=d7e908c260678770d2878362b2ae295e2d0839f3。开工git status干净；普通批次按要求git merge --no-edit main，返回Already up to date；HEAD未变化。
- learn.json对应行task/character/worktree与本批六局一致，reason=proposal，确有10个proposal_ids；没有research_request、implementation_request或proposal_repair。根strategy-research-silent.json绑定旧批20261010-150327，故本批不承接专题、不读取其他专题或扩领队列。
- 六局runs.jsonl及原状态均确认Silent A10。runs只用本批六个锚点：DUZUBAJ3A8GP, 5PM6JAQG6FNQ, CA5KE8GFJ9X2, 8JRE1C4H4Z2W, YF0LXT1QSTGG, XP2SL33HT0D9。同存档重打不增加独立局数。
- 十份原提案SHA均与队列保存值相同；本批只读取对应队列行、30个关联Silent账本、25个关联Silent经验条目及本角色原日志。
- 源码只读定位基线d7e908c260678770d2878362b2ae295e2d0839f3，实际live观察点0bfadd7aa3dd650ac9a1678d139607e6f095b224；14叶完整字节/SHA和实际live祖先核验见source-pins.json。rollout有另一个已发布子项差异，explore/passive-pieces另有注释差异，完整保存base-vs-live-relevant.patch和三个live叶副本，不将两树称完全相同。源码快照不是六局历史+dirty树复原。

## 证据、验证及边界

共用learner/extract_evidence.py实际完成六流抽取，另同入口补runs/fight-plans，manifest分别在evidence/与evidence-extra/。本次逐行回读原源offset/bytes/SHA、JSON等值及显式归局，共8274条；run-plans按run归局，其他流也核run_id/state.run_id/fingerprint.run，不按正文提及计数。各流保留独立source_size；没有将仍增长的日志称同一全局原子截点。

| 流 | 本批选中原行 | 源截点字节 |
|---|---:|---:|
| states | 4062 | 14202151936 |
| decisions | 3941 | 2450328250 |
| sl-attempts | 38 | 47152113 |
| run-config | 6 | 2056866 |
| run-plans | 33 | 9204127 |
| brain | 188 | 796445413 |
| runs | 6 | 369365 |
| fight-plans | 0 | 2233957 |

states/decisions/brain源各有2条非JSON行，按抽取器报告保留，未计入选中证据。fight-plans的0行仅表示该源截点按显式身份未选到，不宣称不存在原材料。未复核任何旧截点，不覆盖旧报告或零行初稿。

另从明确旧字节锚点有界读回1,062帧重点状态，每帧引用均与共用完整抽取交叉核同；bounded-windows-manifest.json保留有界起止。turn-summaries.json保留首末与下一轮：原始HP净差不是卡牌本体伤害，召唤/换相种群变化时净扣指标置空，开场回血、死亡截断和未派发结算另核，初稿原始净差仍单列可审计。

finding-checks.json的37项断言仅核原帧/原题和同指纹差值，**没有调用生产求解器或做整战消费者认证，不是tsc/vitest或撤源码红/恢复绿**。全败、零胜率和同盘差值不提供独立整战最优策略因果。

## 本次行为、验证及记录

未修改生产源码、任务模板、知识JSON、出牌/药水/SL/终局价值或其他角色行为。本次不拟合血价/成长系数，不改变并列、HP护栏、探索触发或房间样本门槛。新代码测试不适用：tests={"tsc":null,"vitest":null,"cases":null}；未运行撤源码红/恢复绿，未借历史测试冒报本次成功；没有提交，无提交前测试或live测试。

不新增或重建原提案ID，不直接改队列/旧提案/历史复盘；本批proposal_results逐项交调度器机械接续。只通过根learner/ledger.py update追加where.proposal与处置note；30个原账本的claim/first_run/asc/prior/evidence/status/version/effect保持，旧shipped不降级、不新增shipped。旧局重复核验不增加支持N。silent-0016的错误对应仅追加异议与出处，不改旧claim或冒称金刚杵经验已纠正。

没有新增游戏知识待发布；经验入库、消费者采用、效果和宽父要求均未由本报告关闭。运维应按逐项具体缺口等新局重派；本批没有可执行代码要回退，后续如实施需按独立源码commit回退。

过程异常保留：一次只读组合命令在sandbox构建时因并行回收的其他任务临时路径消失返回1，未执行目标读取，后续同范围只读命令成功；一次猜测文件路径silent-combat-facts.ts不存在已改用实际phase-current等路径。原提案曾引用的verified-evidence.jsonl本次未在原目录找到，未据此断言原证据缺失，直接以本批共用抽取和原行回读核验。没有把环境错误当代码失败或补跑源码套件。

## silent-proposal-c20b5139dd0dff71：感染棱柱技能污染与火花增长

证据与账本：DUZUBAJ3A8GP，F27 T4—T6；账本 silent-0168。T4污染0→3→6，T5火花3→6、污染0→6→12→18，T6轮初污染撤去。T5最终17挡对26攻击实损9，同时敌毒13结算；不能只算技能增加的攻击。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0168。

当前已有子项：turn-solver.ts逐技能累加vitalSpark并逐段计污染，rollout.ts读取移动selfPowers增长火花；silent-sl-resource-comparison.ts区分行动期污染与轮末余毒。以上仅证明子路径存在。

本次处置：**waiting**。缺本局火花增长、污染撤去、已有虚弱和迷雾毒/挡收益在同一冻结输入中的生产联合重放；本批未核出可独立新增的规则失配，不强制少打技能。

预期行为与验证：固定本局T4/T5入口、A10实际移动表及派发前缀，逐步比较火花、污染、每段意图、挡、毒和HP；若定位失配，新增实现须撤源码红/恢复绿及原沙箱验证。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：T6两技能已有18挡完全覆盖18攻击，技能并非一律亏；本局没有替线整战胜利因果。

## silent-proposal-ae9e692d680e3819：失落与遗忘的逐来源抢夺和返还

证据与账本：5PM6JAQG6FNQ，F39首试T4—T6及末试T4；账本 silent-0183、silent-0005。首试T4力敏各−4，两步法只将敏捷恢复0；失落退场后T5力量恢复0，T6遗忘再次令敏捷−2。末试一步法只回−2敏，毒杀失落仍以8血0挡对19攻击死亡。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0183, silent-0005。

当前已有子项：当前现场负力量/负敏捷及普通伤挡计算已有读取；combat-plan.ts识别POSSESS_*并不等于已实现逐实体累计和死亡返还。

本次处置：**waiting**。缺逐实体抢夺来源的完整归属及遗忘退场返敏端点；已见负属性与失落返力片段不足以实现全套返还，亦不支持固定击杀序。

预期行为与验证：补同一实体从抢夺、重复抢夺、退场到返还的完整端点，分开其他力量/敏捷来源；再用固定输入验证模型及所有候选，保留选项。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：首试有两步法而末试仅一步；没有另一目标顺序的完整胜负对照，不能把返力观察扩成统一返还公式。

## silent-proposal-52f1e1bd2e7db0ed：下水道蚌加压、虚弱及覆甲

证据与账本：CA5KE8GFJ9X2，F13 T1—T5；账本 silent-0231。攻击轮力量0/4/8、喷水11/15/19，T3/T5弱后11/14；五轮初覆甲9/9/8/7/6。T5玩家2血、10挡对14完整需损4，差2血，不能用实际截断失血2代替需求。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0231。

当前已有子项：monster-db.ts的moveDamageAt与monsterHpAt优先使用当前进阶已观测值，无五样本限制；room-costs.ts仍MEASURED_ROOM_MIN_N=5。rollout有移动增力和覆甲路径。

本次处置：**waiting**。当前进阶第一观测读取及房间五样本门槛已有；缺加压、弱、覆甲的同输入联合生产重放和完整减层条件，不把读取子项登记为整项duplicate。

预期行为与验证：固定该局实际入口与移动表，逐轮核加压、弱到期、覆甲/敌挡/本体血及末轮完整需求；不将未隔离的覆甲序列硬编码为通用规则。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：现场序列本身不提供完整覆甲减层原因，弱后仍增长不表示所有技能或防御无价值；未观察等级不外推。

## silent-proposal-6dd8bbff876be528：电击机器人逐实体高电压

证据与账本：5PM6JAQG6FNQ，F38 T2—T4；账本 silent-0233、silent-0209。T2末新增23上限电击/高电压2，T3观测力量2、攻击17，T4力量4、攻击19；T3仍活着贡献攻击，T4才退场。

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0233, silent-0209。

当前已有子项：rollout.ts的STRENGTH_GROWTH_POWERS包含HIGH_VOLTAGE_POWER，敌对象独立持有growth；调用处也读取现场高电压。

本次处置：**waiting**。逐实体增长路径已有；缺可靠召唤代际身份、历史实际移动输入和另一目标顺序的完整后继，不能凭index或血量上限增加继承/清零规则。

预期行为与验证：补固定召唤模板、代际身份与移动输入，重放新增者首轮及连续增长；另一杀序必须分开未派发候选和完整执行，不承诺后场能救。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：同类型、同上限和index变化均不是跨召唤稳定身份；原未执行先杀爪牙线不能冒称已保血。

## silent-proposal-578e415a259e6835：沙虫选线审计、实付血价和能力兑现

证据与账本：8JRE1C4H4Z2W，F33首/三试T2、第二试T5、末试T11，另F17 T6；原提案所列账本全部保留。270216/270282完整指纹相同，实际失血3→15、扣敌10→17；三试换线日志是0/24→5/24死亡样本，并非相同死亡比例。第二试T5实损4/扣25，末试T11既有5血22挡对37攻击，完整需损15。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。

当前已有子项：silent-selection-audit.ts记录原答/SL前后和requested_action，明确scope=predicted_candidates、execution_status=pending_dispatch、actual_turn=null；silent-hp-guard-audit.ts也将actual_outcome留空。

本次处置：**waiting**。缺跨抽弃牌、生成、用药和重规划的完整候选持续归属及沙坑/路线资源联合认证；已有预测审计不能证明整轮执行。原提案金刚杵链接silent-0016，但该账本claim是护喉甲覆甲，保留追溯异议、不当同机制支持。

预期行为与验证：建立完整候选到派发结果的持续归属，并在抽牌/选择/生成/药水/重规划边界显式截断，逐来源核HP和能力建立；先证明同输入生产消费者闭环，不改护栏/探索系数。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：末试保血延至T11仍败，不能证明一律保血或一律付血正确；F17候选差值未完整执行不能冒作实际收益。旧99局审计本批未重做。

## silent-proposal-c0767768bf6a7ab1：实验体全败SL候选的资源代价

证据与账本：YF0LXT1QSTGG，F48第二/三试T1；账本 silent-0079。271309/271348完整指纹一致，原答均plan5，第三试271354实际结束本仍有续步的回合；本轮实际失血0→9、敌HP净扣45→38。原题预测0/10失血、54/36伤害与实际分开，不能混作同一个完成候选。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0079。

当前已有子项：silent-sl-resource-comparison.ts已有原/替线本轮hp_loss、damage_dealt、挡、成长和未知，scope=current_turn_prediction、execution=unverified；不调用实际整轮归因。

本次处置：**waiting**。当轮0/9与45/38已复核、预测比较已有窄实现；缺原/替线动作段完整执行归属、分源血价及受控整战后继，保留探索和惩罚参数。

预期行为与验证：将同指纹原答、SL剪线、赠礼生成/重规划、实际结束分段接续，区分未执行续步；新A10独立局后移验证，不能在同存档尝试之间切训练/验证。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：同局F33第二次SL实际获胜，末次F48恢复T1挡续步仍T5败；不能否定全部SL或以候选预测偏差直接判模型bug。

## silent-proposal-a46bdb7fe711d79a：实验体阶段、实毒和后取得敏捷

证据与账本：YF0LXT1QSTGG，F48末试T3—T5；账本 silent-0021、silent-0027、silent-0028、silent-0085。新相212血清旧力/毒；T5触媒2但现毒0。先建13+10=23挡，第三小刀后才到6敏捷且旧挡仍23；末18血对44攻击完整需损21，差3。敌197→160含消耗步骤额外扣血，不全归小刀本体。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0021, silent-0027, silent-0028, silent-0085。

当前已有子项：silent-phase-current.ts已有现阶段HP/毒、持有组件、实建能力、当前挡/敏捷，poison_damage_already_dealt=null；silent-phase-reference.ts提供阶段结束参考，未宣称整战胜负。

本次处置：**waiting**。当前阶段/持有/已建快照已有live实现；缺逐候选施毒、毒结算、遗忘之魂额外扣血及敏捷取得顺序的完整执行比对，不能据零毒末态调整排序。

预期行为与验证：固定T3换相和T5实际动作，分列牌伤、消耗附伤、毒结算、旧挡与后继挡；补每条候选的生产消费者读取及实际执行归属再决定是否新增。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：前五次T4建立毒雾或余像仍失败；未建毒不能作为唯一死因，未观察第三阶段/另一构筑不补结论。

## silent-proposal-1044224808015e5c：双蟹B2零胜率并列的SL血价

证据与账本：XP2SL33HT0D9，F33首/二试T3及首/末试T1；账本 silent-0079。271992/272040同指纹，实损9→14、扣24→27；271982/272195同指纹，实损2→10、扣25→34，后者另建1力量。272076只是候选21/24→23/24死亡、8/16失血及11/23伤害，不能当成原线实际多损8。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0079。

当前已有子项：当前SL保留B2/rollout及未试线排名；资源比较已分列当轮HP、输出与成长。B2 diff=0/se=0只是有限样本比较，不等于实际风险相同。

本次处置：**waiting**。当轮+5血/+3进度和+8血/+9进度已复核；缺同抽序、随机与预算的完整替线及成长后继，不把B2零差当风险相同或拟新探索优先级。

预期行为与验证：保存原/替线完整抽序、药瓶落点、成长与共同预算；本局只作发现/回归，独立后续A10局按run分组后移验证，再决定是否启用窄策略。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：末试T2减力与朝向使零损、T3保挡实损4；全部六试失败不能给出统一血价系数，也不能抹掉力量收益。

## silent-proposal-7cbc6005db712ba9：双蟹朝向、临时减力和轮初格挡

证据与账本：XP2SL33HT0D9，F33末试T2—T5；账本 silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。T2轮初14挡，斗篷后20，镣铐爪0→−9、攻击4→0，T3恢复；T4火箭57→转向38→弱后28，4敏脆弱下偏折6挡；T5防御6挡、11血对17攻击恰死，末毒扣3+7=10。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。

当前已有子项：turn-solver.ts已有朝向/弱/临时减力、后加敏不倒补的路径，passive-pieces有轮初遗物参考；这些局部路径与只读字段不能替代完整候选联合执行验证。

本次处置：**waiting**。朝向、弱、临时减力、轮初挡和后取得成长局部已有窄实现；缺完整候选联合执行及消费者认证，不把字段/公式存在记成整项duplicate或改持续价值权重。

预期行为与验证：固定57→38→28、14+6=20、减力恢复和6挡死亡端点，用原生产入口核候选到执行；普通/升级/额外来源分开，铁甲及未观察条件保持等价。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：本批仅复核这局A10，未重新扩查原提案早期A1/A6局；原普通参考不自行扩成未验证升级或额外触发公式。

## silent-proposal-c59f592f1427a67e：两局的能力兑现、SL及路线资源综合审计

证据与账本：YF0LXT1QSTGG F48第二/三试T1、末试T4/T5；XP2SL33HT0D9 F33首/二试T3、首/末试T1及末T2—T5；账本沿原提案22项，见本节关联。三组血价+9/−7、+5/+3、+8/+9已逐原帧核回，临时减力/恢复、轮初挡和能力取得顺序与原记录一致。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md（原SHA核回；本目录保留原字节副本）。完整关联账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。

当前已有子项：选线、护栏、SL资源、现阶段快照各有只读子项；完整候选预测/实际、逐来源路线/休息/用药及后继胜负没有因此自动成为一条完成记录。

本次处置：**waiting**。缺逐来源资源账、完整候选执行及路线/休息/药水时机的受控替线联合认证；本批未重做原101局历史审计，不以旧宽支持数或六局锚点关闭整项。

预期行为与验证：按原子问题补真实消费者和完整动作归属，再做本角色独立新局的时间后移核验；不增加重复提案ID，不把相同SL盘面累加为独立支持数。 本次保持原行为和全部选项；若后续新增实现，须独立提交、固定反事实红/绿、自测和实际live祖先核验后记录。

反例/限制：本批未重做历史22次镣铐/50帧船夹板或101局路线审计；旧报告结论与旧支持数仅保留出处，不冒称本次全面复验。

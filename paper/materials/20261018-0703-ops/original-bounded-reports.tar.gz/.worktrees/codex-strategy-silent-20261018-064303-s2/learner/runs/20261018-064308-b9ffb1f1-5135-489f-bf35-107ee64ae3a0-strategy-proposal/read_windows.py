import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
targets = {
    'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {38, 39},
    'DUZUBAJ3A8GP': {27}, '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33},
}
source = Path('/home/dw/Projects/agent-sts2/logs/states.jsonl')
start = 8403755994
counts = {r: 0 for r in targets}
attempts = {}
last_turn = {}

def powers(values):
    return {p['power_id']: p.get('amount') for p in values or []}

with source.open('rb') as handle, (HERE / 'bounded-windows.jsonl').open('w') as out:
    handle.seek(start)
    size = source.stat().st_size
    while True:
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        row = json.loads(raw)
        if row.get('ts', '') > '2026-10-07T10:10:38.000Z':
            break
        run = extract.run_identity(row)
        if run not in targets:
            continue
        state = row.get('state', {})
        run_state = state.get('run') or {}
        floor = run_state.get('floor')
        if floor not in targets[run]:
            continue
        assert run_state['character_id'] == 'SILENT' and run_state['ascension'] == 10
        combat = state.get('combat') or {}
        turn = state.get('turn')
        key = (run, floor)
        if isinstance(turn, int) and combat:
            if key not in attempts:
                attempts[key] = 1
            elif turn < last_turn.get(key, turn):
                attempts[key] += 1
            last_turn[key] = turn
        player = combat.get('player') or {}
        compact = {
            'run': run, 'floor': floor, 'attempt': attempts.get(key), 'turn': turn,
            'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'), 'screen': state.get('screen'),
            'hp': run_state.get('current_hp'), 'block': player.get('block'),
            'powers': powers(player.get('powers')), 'energy': player.get('energy'),
            'played': player.get('cards_played_this_turn'),
            'hand': [{'index': c.get('index'), 'id': c.get('card_id'), 'upgraded': c.get('upgraded')}
                     for c in combat.get('hand', [])],
            'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id']}
                        | {'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies', [])],
            'ref': {'source': str(source), 'offset': offset, 'bytes': len(raw),
                    'sha256': hashlib.sha256(raw).hexdigest()},
        }
        out.write(json.dumps(compact, ensure_ascii=False) + '\n')
        counts[run] += 1
    end = handle.tell()
(HERE / 'bounded-windows-manifest.json').write_text(json.dumps({
    'source': str(source), 'source_size': size, 'start': start, 'end': end,
    'stop_after_ts': '2026-10-07T10:10:38.000Z', 'counts': counts,
    'scope': '独立有界原帧读回；完整共用抽取另存evidence，不以本窗口宣称全部历史。',
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'counts': counts, 'attempts': {str(k): v for k, v in attempts.items()}}, ensure_ascii=False))

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
frames = [json.loads(l) for l in (HERE / 'bounded-windows.jsonl').read_text().splitlines()]
turns = {(r['run'], r['floor'], r['attempt'], r['turn']): r
         for r in json.loads((HERE / 'turn-summaries.json').read_text())}
decisions = {r['line']: r['row'] for r in json.loads((HERE / 'selected-decisions.json').read_text())}
checks = []

def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'ok': True})

def rows(run, floor, attempt, turn):
    return [r for r in frames if (r['run'], r['floor'], r['attempt'], r['turn']) == (run, floor, attempt, turn)]

def unique(values):
    return [v for i, v in enumerate(values) if not i or v != values[i - 1]]

def enemy(row, ident):
    return next(e for e in row['enemies'] if e['enemy_id'] == ident)

def incoming(row, ident):
    return sum(i.get('total_damage') or 0 for i in enemy(row, ident)['intents'])

pairs = [
    ('沙虫T2', '8JRE1C4H4Z2W', 33, 2, 1, 3, 270216, 270282, [3, 15], [10, 17]),
    ('实验体T1', 'YF0LXT1QSTGG', 48, 1, 2, 3, 271309, 271348, [0, 9], [45, 38]),
    ('双蟹T3', 'XP2SL33HT0D9', 33, 3, 1, 2, 271992, 272040, [9, 14], [24, 27]),
    ('双蟹T1', 'XP2SL33HT0D9', 33, 1, 1, 6, 271982, 272195, [2, 10], [25, 34]),
]
for name, run, floor, turn, a, b, da, db, hp, damage in pairs:
    check(name + '同指纹', decisions[da]['fingerprint'] == decisions[db]['fingerprint'], True)
    selected = [turns[(run, floor, at, turn)] for at in (a, b)]
    check(name + '实际玩家净失血', [r['hp_loss'] for r in selected], hp)
    check(name + '同体敌HP净扣含已结毒', [r['enemy_net_decrease'] for r in selected], damage)

du4 = rows('DUZUBAJ3A8GP', 27, 1, 4)
du5 = rows('DUZUBAJ3A8GP', 27, 1, 5)
check('棱柱T4污染', unique([r['powers'].get('TAINTED_POWER', 0) for r in du4]), [0, 3, 6])
check('棱柱T5污染', unique([r['powers'].get('TAINTED_POWER', 0) for r in du5]), [0, 6, 12, 18])
check('棱柱火花T4到T5', [enemy(r[0], 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'] for r in (du4, du5)], [3, 6])
check('棱柱T6污染撤去', rows('DUZUBAJ3A8GP', 27, 1, 6)[0]['powers'].get('TAINTED_POWER', 0), 0)

clam = [turns[('CA5KE8GFJ9X2', 13, 1, t)]['first'] for t in range(1, 6)]
check('蚌轮初覆甲', [enemy(r, 'SEWER_CLAM')['powers']['PLATING_POWER'] for r in clam], [9, 9, 8, 7, 6])
check('蚌T1T3T5力量', [enemy(clam[t-1], 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0) for t in (1, 3, 5)], [0, 4, 8])
check('蚌T1T3T5喷水', [incoming(clam[t-1], 'SEWER_CLAM') for t in (1, 3, 5)], [11, 15, 19])
for t, expected in ((3, 11), (5, 14)):
    check('蚌虚弱后T' + str(t), min(incoming(r, 'SEWER_CLAM') for r in rows('CA5KE8GFJ9X2', 13, 1, t)), expected)

zap = [turns[('5PM6JAQG6FNQ', 38, 1, t)]['first'] for t in (3, 4)]
check('电击同23上限观测力量', [enemy(r, 'ZAPBOT')['powers']['STRENGTH_POWER'] for r in zap], [2, 4])
check('电击同23上限观测攻击', [incoming(r, 'ZAPBOT') for r in zap], [17, 19])
pos = rows('5PM6JAQG6FNQ', 39, 1, 4)
check('两次抢夺后力敏', [pos[0]['powers'].get(k, 0) for k in ('STRENGTH_POWER', 'DEXTERITY_POWER')], [-4, -4])
check('两步法后敏捷', pos[-1]['powers'].get('DEXTERITY_POWER', 0), 0)
check('失落退场后力量', rows('5PM6JAQG6FNQ', 39, 1, 5)[0]['powers'].get('STRENGTH_POWER', 0), 0)

y4 = rows('YF0LXT1QSTGG', 48, 6, 4)
y5 = rows('YF0LXT1QSTGG', 48, 6, 5)
check('实验体新相HP', enemy(y4[0], 'TEST_SUBJECT')['current_hp'], 212)
check('实验体新相旧力毒清除', [enemy(y4[0], 'TEST_SUBJECT')['powers'].get(k, 0) for k in ('STRENGTH_POWER', 'POISON_POWER')], [0, 0])
check('实验体末T5触媒和现毒', [y5[0]['powers']['ACCELERANT_POWER'], enemy(y5[0], 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)], [2, 0])
alive_y5 = [r for r in y5 if r['hp'] > 0]
check('实验体后加敏不倒补挡', [(r['powers'].get('DEXTERITY_POWER', 0), r['block']) for r in alive_y5 if r['powers'].get('DEXTERITY_POWER') == 6], [(6, 23), (6, 23)])
check('实验体末轮完整生存缺口', incoming(alive_y5[-1], 'TEST_SUBJECT') - alive_y5[-1]['block'] - alive_y5[-1]['hp'], 3)

x2 = rows('XP2SL33HT0D9', 33, 6, 2)
x3 = rows('XP2SL33HT0D9', 33, 6, 3)
x4 = rows('XP2SL33HT0D9', 33, 6, 4)
x5 = rows('XP2SL33HT0D9', 33, 6, 5)
check('双蟹轮初挡与结束前挡', [x2[0]['block'], x2[-1]['block']], [14, 20])
check('双蟹临时减力与恢复', [enemy(x2[-1], 'CRUSHER')['powers']['STRENGTH_POWER'], enemy(x3[0], 'CRUSHER')['powers'].get('STRENGTH_POWER', 0)], [-9, 0])
check('双蟹T4朝向再弱', unique([incoming(r, 'ROCKET') for r in x4]), [57, 38, 28])
alive_x5 = [r for r in x5 if r['hp'] > 0]
check('双蟹末轮完整生存缺口', incoming(alive_x5[-1], 'CRUSHER') - alive_x5[-1]['block'] - alive_x5[-1]['hp'], 0)
check('双蟹末轮结毒净扣', sum(e['current_hp'] for e in alive_x5[-1]['enemies']) - sum(e['current_hp'] for e in x5[-1]['enemies']), 10)
check('沙虫并非相同死亡比例', [decisions[270282]['sl_explore']['numbers'][k].split(',')[0] for k in ('original', 'replacement')], ['rollout dead 0/24', 'rollout dead 5/24'])

result = {'ok': True, 'checks': checks, 'count': len(checks),
          'scope': '原帧/原题材料断言，不调用生产求解器，不是固定回放或代码测试；不支持独立胜率因果。'}
(HERE / 'finding-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ok': True, 'count': len(checks), 'scope': result['scope']}, ensure_ascii=False))

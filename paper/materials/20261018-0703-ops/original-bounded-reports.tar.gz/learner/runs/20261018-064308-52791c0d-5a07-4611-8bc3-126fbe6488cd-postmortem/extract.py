import json,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261018-064308-52791c0d-5a07-4611-8bc3-126fbe6488cd-postmortem'; run='KCA04Q3SEYTF'
counts={}; times=[]
for name in ['runs','decisions','run-plans','brain','run-config','sl-attempts','states']:
    src=root/'logs'/f'{name}.jsonl'; cutoff=src.stat().st_size; offset=0; n=0
    with src.open('rb') as f,(out/f'{name}.jsonl').open('w') as g:
        for ln,raw in enumerate(f,1):
            begin=offset; offset+=len(raw)
            if offset>cutoff: break
            if run.encode() not in raw: continue
            try: r=json.loads(raw)
            except ValueError: continue
            actual=r.get('run_id',r.get('run',(r.get('state') or {}).get('run_id')))
            if isinstance(actual,dict): actual=actual.get('run_id')
            if actual!=run: continue
            rec={'line':ln,'offset':begin,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'data':r}
            g.write(json.dumps(rec,ensure_ascii=False)+'\n');n+=1
            if name=='decisions':times.append(r['ts'])
    counts[name]=n
    print(name,n,flush=True)
start,end=min(times),max(times);n=0;mx='';offset=0
src=root/'logs/deepseek-reasoning.jsonl'
with src.open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as g:
    for ln,raw in enumerate(f,1):
        begin=offset;offset+=len(raw)
        try:r=json.loads(raw)
        except ValueError:continue
        ts=r.get('ts','');mx=max(mx,ts)
        if start<=ts<=end:
            g.write(json.dumps({'line':ln,'offset':begin,'bytes':len(raw),'data':r},ensure_ascii=False)+'\n');n+=1
counts['reasoning']=n;counts['time_window']=[start,end];counts['reasoning_max_ts']=mx
(out/'extraction-summary.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(counts,ensure_ascii=False),flush=True)

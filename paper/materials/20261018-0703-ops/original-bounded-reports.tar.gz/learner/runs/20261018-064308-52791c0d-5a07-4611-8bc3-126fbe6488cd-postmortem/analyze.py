import json,collections
from pathlib import Path
p=Path(__file__).parent
def rows(name):return [json.loads(s) for s in (p/(name+'.jsonl')).open()]
def dump(name,x):(p/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
ds=rows('decisions');ss=rows('states');bs=rows('brain');rc=rows('run-config')[0]['data']
# Summaries retain raw references, detailed inputs stay in extracted rows.
meta={k:v for k,v in rc.items() if k in ['ts','run_id','code','git','brain','observed_ts','dirty','version','source']};meta['keys']=list(rc)
dump('config-summary.json',meta)
dump('decision-summary.json',[{'line':x['line'],**{k:x['data'].get(k) for k in ['ts','floor','turn','label','decider','chosen','rationale','confidence','fallback','usage']},'journal_keys':list((x['data'].get('journal') or {}).keys()) if isinstance(x['data'].get('journal'),dict) else None} for x in ds])
dump('brain-summary.json',[{'line':x['line'],**{k:v for k,v in x['data'].items() if k not in ['state','system','user','prompt','facts','options','memory']}} for x in bs])
r=json.loads((p/'KCA04Q3SEYTF-resources.json').read_text())
summary=[];turns=[]
for w in r['combats']:
 en=w['entry'];la=w['last'];ex=w.get('exit');a=w.get('enemy_hp_audit') or {}
 summary.append({k:w.get(k) for k in ['sequence','floor','enemies','entry','last','exit','end','entry_is_turn_one','observed_net_hp_loss']})
 # Turn boundary HP and live enemy pool, no inferred unobserved turns.
 low,hi=en['line'],(ex or la)['line'];obs=[x for x in ss if low<=x['line']<=hi]
 by={}
 for x in obs:
  st=x['data']['state'];t=st.get('turn')
  if st.get('in_combat') and t is not None:by.setdefault(t,[]).append(x)
 for t,xs in by.items():
  first=xs[0];last=xs[-1];ft=first['data']['state'];lt=last['data']['state']; nexts=[x for x in obs if x['line']>last['line']]
  tail=nexts[0] if nexts else last;nt=tail['data']['state']
  def hp(st):return (st.get('run')or{}).get('current_hp')
  def pool(st):return sum(e.get('current_hp',0) for e in (st.get('combat')or{}).get('enemies',[]) if e.get('is_alive',True))
  turns.append({'seq':w['sequence'],'floor':w['floor'],'turn':t,'first':first['line'],'last':last['line'],'after':tail['line'],'hp':hp(ft),'after_hp':hp(nt),'need':pool(ft),'end_enemy_hp':pool(nt),'net_pool_loss':pool(ft)-pool(nt),'final':t==max(by),'end_block':(lt.get('combat')or{}).get('block'), 'enemy_end':(lt.get('combat')or{}).get('enemies')})
dump('combat-summary.json',summary);dump('turn-summary.json',turns)
print('written summaries',len(ds),len(ss),len(bs),len(summary),len(turns))
print('config',meta)
print('brain keys',list(bs[0]['data']))
print('decision keys',list(ds[0]['data']))
print('journal example',str(next((x['data'].get('journal') for x in ds if x['data'].get('journal')),None))[:2200])
print('state example',str(ss[0]['data'])[:1800])

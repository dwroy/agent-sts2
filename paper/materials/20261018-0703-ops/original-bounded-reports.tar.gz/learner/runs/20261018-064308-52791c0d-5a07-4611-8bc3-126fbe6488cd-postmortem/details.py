import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()];S=[json.loads(l) for l in (p/'states.jsonl').open()];B=[json.loads(l) for l in (p/'brain.jsonl').open()]
# Print only compact projection.
for r in D:
 d=r['data'];j=d.get('journal')or{}
 if d.get('decider')=='jev' and d.get('label','').startswith('combat/'):
  print('FIRST_JEV_AUDIT',r['line'],json.dumps(j,ensure_ascii=False)[:400],list(d.get('boss_sim')or{}));break
stats={'deciders':dict(collections.Counter(x['data'].get('decider') for x in D)), 'labels':dict(collections.Counter(x['data'].get('label') for x in D))}
J=[x for x in D if x['data'].get('decider')=='jev'];JC=[x for x in J if x['data'].get('label','').startswith('combat/')]
stats['jev_low']=len([x for x in J if isinstance(x['data'].get('confidence'),(int,float)) and x['data']['confidence']<.35]);stats['jev_n']=len(J);stats['jev_combat']=len(JC)
for k in ['rollout_best_chosen','hp_guard']:
 hits=[]
 def walk(v,path=''):
  if isinstance(v,dict):
   for a,b in v.items():
    if k in a:hits.append((path+'.'+a,b))
    walk(b,path+'.'+a)
  elif isinstance(v,list):
   for b in v:walk(b,path+'[]')
 for x in JC:walk(x['data'].get('boss_sim')or{});walk(x['data'].get('journal')or{})
 stats[k]=dict(collections.Counter(str(v) for path,v in hits));print(k,'paths',list(dict.fromkeys(a for a,b in hits))[:12])
stats['brain_usage']={k:sum((x['data'].get('usage')or{}).get(k,0) for x in B) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}
stats['jev_usage']={k:sum((x['data'].get('usage')or{}).get(k,0) for x in J) for k in ['input_tokens','output_tokens','cache_hit_tokens']}
(p/'stats.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n');print('STATS',stats)
print('POTIONS')
for x in D:
 d=x['data'];ch=d.get('chosen')or{}
 if ch.get('action') in ['use_potion','discard_potion','claim_reward'] and (ch.get('action')!='claim_reward' or 'potion' in str(d.get('expect'))):print(x['line'],d['floor'],d.get('turn'),d.get('sl_attempt'),ch,d.get('rationale','')[:350])
print('STATE_RESOURCE_CHANGES')
last=None
for x in S:
 st=x['data']['state'];ru=st.get('run')or{};v=(ru.get('current_hp'),ru.get('max_hp'),[(z.get('index'),z.get('potion_id')) for z in ru.get('potions',[]) if z.get('occupied')])
 if last and v!=last:
  if not st.get('in_combat') or v[2]!=last[2]:print(x['line'],x['data']['ts'],ru.get('floor'),st.get('turn'),last,'=>',v)
 last=v
print('BOSS_TURN_FIRST_LAST')
T=json.loads((p/'turn-summary.json').read_text())
for r in [x for x in T if x['seq']==13]:
 for ln in dict.fromkeys([r['first'],r['last']]):
  x=next(x for x in S if x['line']==ln);st=x['data']['state'];c=st.get('combat')or{};pl=c.get('player')or{}
  print(ln,st['turn'],'hp',pl.get('current_hp'),'block',pl.get('block'),'powers',[(v['power_id'],v['amount']) for v in pl.get('powers',[])],'enemy',[(v['current_hp'],v.get('block'),[(z['power_id'],z['amount']) for z in v.get('powers',[])],v.get('move_id'),v.get('intents')) for v in c.get('enemies',[])])

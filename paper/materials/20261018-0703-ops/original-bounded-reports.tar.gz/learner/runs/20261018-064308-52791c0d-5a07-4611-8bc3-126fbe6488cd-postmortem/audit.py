import json,collections,re
from pathlib import Path
p=Path(__file__).parent;D=[json.loads(l) for l in (p/'decisions.jsonl').open()];S=[json.loads(l) for l in (p/'states.jsonl').open()];B=[json.loads(l) for l in (p/'brain.jsonl').open()]
print('KEY SEARCH')
found=[]
def walk(v,path='',line=0):
 if isinstance(v,dict):
  for k,b in v.items():
   if re.search('rollout_best_chosen|hp_guard|focus',k): found.append((line,path+'.'+k,b if not isinstance(b,(dict,list)) else str(b)[:200]))
   walk(b,path+'.'+k,line)
 elif isinstance(v,list):
  for b in v:walk(b,path+'[]',line)
for x in D:walk(x['data'],line=x['line'])
print('paths',collections.Counter(a for l,a,b in found));print('values',collections.Counter((a,str(b)) for l,a,b in found if 'rollout_best_chosen' in a or 'hp_guard' in a))
print('POTIONS BEFORE AFTER')
for x in D:
 d=x['data'];ch=d.get('chosen')or{}
 if ch.get('action')=='use_potion':
  bef=max((s for s in S if s['data']['ts']<=d['ts']),key=lambda s:s['line']);i=S.index(bef);after=S[i+1] if i+1<len(S) else bef
  def short(s):
   st=s['data']['state'];c=st.get('combat')or{};pl=c.get('player')or{}
   return {'s':s['line'],'ts':s['data']['ts'],'hp':(st.get('run')or{}).get('current_hp'),'block':pl.get('block'),'energy':pl.get('energy'),'hand':len(c.get('hand')or[]),'potions':[(v.get('index'),v.get('potion_id')) for v in st['run'].get('potions',[]) if v.get('occupied')]}
  print(x['line'],d['floor'],d.get('turn'),d.get('sl_attempt'),short(bef),'->',short(after))
print('CODE AUTONOMY')
cs=[x for x in D if x['data'].get('decider')=='code' and x['data'].get('label','').startswith('combat/') and x['data']['label']!='combat/plan-continue'];key=lambda x:(x['data'].get('floor'),x['data'].get('sl_attempt')or 1,x['data'].get('turn'))
js=[x for x in D if x['data'].get('decider')=='jev' and x['data'].get('label','').startswith('combat/')];print(len(cs),len(set(map(key,cs))),len(set(map(key,cs))-set(map(key,js))),collections.Counter(x['data']['label'] for x in cs))
print('PLAN FOCUS / SELECTOR')
for x in D:
 d=x['data']
 if d.get('decider')=='jev' and d.get('label','').startswith('combat/'):
  if 'rollout' in str(d):
   print(x['line'],[(k,str(v)[:600]) for k,v in d.items() if k not in ['questions','fingerprint','expect'] and 'rollout' in str(v)]);break
print('BRAIN ROUTE / REST')
for x in B:
 b=x['data'];pay=b.get('payload')or{}
 if b['label'].startswith(('rest/','map/')):
  print('brain',x['line'],b['label'],'answer',str(b.get('answer'))[:800]);print('payload keys',list(pay),'options',str(b.get('options'))[:800]);
  for k,v in pay.items():
   if k in ['plan_facts','facts']:print(k,str(v)[:3300])
print('DECK RELICS')
st=next(x['data']['state'] for x in S if x['line']==444811);ru=st['run'];print('run keys',list(ru));print('deck',[(x.get('name'),x.get('card_id'),x.get('upgraded')) for x in ru.get('deck',[])]);print('relics',ru.get('relics'))

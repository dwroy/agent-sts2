import json,hashlib,collections,datetime
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2');p=Path(__file__).parent
counts={};rows={}
for name in ['runs','decisions','run-plans','brain','run-config','sl-attempts','states']:
 rows[name]=[json.loads(l) for l in (p/(name+'.jsonl')).open()];counts[name]=len(rows[name])
 with (root/'logs'/(name+'.jsonl')).open('rb') as f:
  for r in rows[name]:
   f.seek(r['offset']);raw=f.read(r['bytes']);assert hashlib.sha256(raw).hexdigest()==r['sha256'],(name,r['line']);assert json.loads(raw)==r['data']
assert counts=={'runs':1,'decisions':562,'run-plans':5,'brain':23,'run-config':1,'sl-attempts':6,'states':581}
D=[x['data'] for x in rows['decisions']];S={x['line']:x['data']['state'] for x in rows['states']};B=[x['data'] for x in rows['brain']]
run=rows['runs'][0]['data'];assert run['character'].lower()=='silent' and run['floor']==17 and run['ascension']==10 and run['victory'] is False
assert S[444514]['run']['current_hp']==63 and S[444811]['run']['current_hp']==63
last=S[444882]['combat'];assert last['player']['current_hp']==1 and last['player']['block']==5
assert last['enemies'][0]['intents'][0]['total_damage']==20 and S[444883]['run']['current_hp']==0 and S[444883]['combat']['enemies'][0]['current_hp']==57
assert [(x['data']['turns'],x['data']['end_hp']) for x in rows['sl-attempts']]==[(12,19),(13,3),(13,2),(13,3),(12,11),(13,0)]
J=[d for d in D if d.get('decider')=='jev'];JC=[d for d in J if d.get('label','').startswith('combat/')]
assert len(J)==134 and len(JC)==102 and sum(d.get('confidence',1)<.35 for d in J)==21
assert collections.Counter(d.get('rollout_best_chosen') for d in JC)=={True:99,False:1,None:2}
assert sum(d.get('chosen',{}).get('action')=='use_potion' for d in D)==15
assert not any(d.get('chosen',{}).get('action')=='discard_potion' for d in D)
assert all(b['engine']=='codex' and b['model']=='gpt-6.1-sol' and b['effort']=='xhigh' for b in B)
assert sum(b['usage']['inputTokens'] for b in B)==4184334 and sum(b['usage']['outputTokens'] for b in B)==27316
assert sum(b['usage']['cacheHitTokens'] for b in B)==0
assert sum(d['usage']['input_tokens']+d['usage']['output_tokens'] for d in J)==1279291==run['tokens']
assert all(set(d.get('usage',{}))=={'input_tokens','output_tokens'} for d in J)
assert (datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(D[0]['ts'])).total_seconds()==2775.189
assert (datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(rows['run-config'][0]['data']['ts'])).total_seconds()==2825.434
R=json.loads((p/'KCA04Q3SEYTF-resources.json').read_text());assert len(R['combats'])==13
assert sum(w['entry']['hp']-w['exit']['hp'] for w in R['combats'][:7])==74
assert all(w['entry_is_turn_one'] for w in R['combats'])
assert 56-15+96-74==63
for before,after,b,a in [(444539,444540,5,15),(444608,444609,6,18),(444678,444679,6,18),(444711,444712,10,30),(444801,444802,6,18),(444862,444863,3,9)]:
 assert S[before]['combat']['player']['block']==b and S[after]['combat']['player']['block']==a
assert all(not w['exit'] for w in R['combats'][7:12])
sel=next(x['data'] for x in rows['decisions'] if x['line']==429681);print('无色药生成选择',sel.get('expect'),sel.get('chosen'))
for ln in [444386,444387,444388]:print('生成牌帧',ln,[(x['name'],x['card_id']) for x in S[ln]['combat']['hand']])
text=(p/'section.md').read_text();assert text.count('\n- [')==4 and text.count('\n## ')==1
print('原日志逐字节核验通过',counts)
(p/'verification.json').write_text(json.dumps({'raw_rows_verified':sum(counts.values()),'counts':counts,'numeric_checks':'通过','section_sha256':hashlib.sha256(text.encode()).hexdigest()},ensure_ascii=False,indent=2)+'\n')

import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()];B=[json.loads(l) for l in (p/'brain.jsonl').open()];S=[json.loads(l) for l in (p/'states.jsonl').open()]
J=[x for x in D if x['data'].get('decider')=='jev' and x['data'].get('label','').startswith('combat/')]
print('Jev rollout',collections.Counter(str(x['data'].get('rollout_best_chosen')) for x in J))
print('focus')
focus=[];sel_focus=[]
for x in J:
 d=x['data'];q=d.get('questions')or{};txt=str(q)
 if 'focus' in txt.lower():focus.append(x['line'])
 a=d.get('selection_audit')or{}
 if 'focus' in str(a.get('answer')).lower():sel_focus.append(x['line'])
print('questions with focus',len(focus),'selected focus',len(sel_focus),focus[:20],sel_focus[:20])
print('non-best')
for x in J:
 d=x['data']
 if d.get('rollout_best_chosen') is False:print(x['line'],d['floor'],d['turn'],d.get('sl_attempt'),d.get('rationale'),str(d.get('selection_audit'))[:2200])
print('selection audit sample')
for x in D:
 d=x['data']
 if d.get('floor')==11 and d.get('label','').startswith('combat/') and d.get('label')!='combat/plan-continue':
  a=d.get('selection_audit')or{};print(x['line'],d.get('turn'),d.get('label'),d.get('rationale'),json.dumps(a,ensure_ascii=False)[:1800])
print('last turn d')
for x in D:
 d=x['data']
 if d.get('sl_attempt')==6 and d.get('turn') in [10,12,13] and d.get('label')!='combat/plan-continue':
  a=d.get('selection_audit')or{};print(x['line'],d.get('turn'),d.get('label'),d.get('rationale'),json.dumps(a,ensure_ascii=False)[:1900])
print('route selected projections')
for x in B:
 b=x['data'];pay=b.get('payload')or{};rr=pay.get('route_review')or{};facts=pay.get('facts')or{};ans=b.get('answer')or{}
 if rr:print(x['line'],b['label'],'plan_facts',json.dumps(rr.get('plan_facts'),ensure_ascii=False)[:3500])
 if b['label']=='rest/plan':
  for key,raw in (b.get('options')or{}).items():
   if key!=ans.get('choice'):continue
   try:o=json.loads(raw)
   except Exception:continue
   print(x['line'],'SELECTED',key,'keys',list(o),'hp refs',o.get('boss_sim_hp_reference'),'boss_sim',str(o.get('boss_sim'))[:1900],'quantitative_fight',str(o.get('quantitative_fight'))[:950])
print('run plans')
for raw in (p/'run-plans.jsonl').open():
 x=json.loads(raw);r=x['data'];print(x['line'],r['floor'],str(r['plan'])[:1700])
print('enemy names',[(x['data']['state']['run'].get('floor'),[(e['name'],e['enemy_id']) for e in (x['data']['state'].get('combat')or{}).get('enemies',[])]) for x in S if x['data']['state'].get('turn')==1 and x['line'] in [444308,444330,444356,444377,444423,444456,444489]])

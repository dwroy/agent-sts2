import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


audits = {path.stem: json.loads(path.read_text()) for path in (OUT / 'consumer-outputs').glob('*.json')}
decisions = {}
for line in (OUT / 'evidence/decisions.evidence.jsonl').open():
    envelope = json.loads(line)
    decisions[envelope['line']] = envelope

pairs = []
for run, floor, turn, a, b, expected_hp, expected_enemy in [
    ('751FN9QM9MHQ', 17, 2, 272434, 272575, [-13, -18], [-9, -18]),
    ('751FN9QM9MHQ', 17, 7, 272531, 272652, [-13, -23], [-12, -18]),
    ('751FN9QM9MHQ', 17, 13, 272483, 272820, [-8, -2], [-17, -11]),
    ('KEN58SH9SLZ6', 17, 10, 274505, 274568, [-15, -21], [-2, -4]),
    ('KEN58SH9SLZ6', 17, 5, 274484, 274601, [-7, -5], [-1, -2]),
]:
    left, right = decisions[a], decisions[b]
    assert left['run_id'] == right['run_id'] == run
    assert left['row']['fingerprint'] == right['row']['fingerprint']
    members = []
    for envelope in (left, right):
        matches = [item for item in audits[run]['observed_turns']
                   if item['floor'] == floor and item['turn'] == turn
                   and item['attempt'] == envelope['row']['sl_attempt']]
        assert len(matches) == 1 and matches[0]['status'] == 'observed_turn_endpoints'
        item = matches[0]
        facts = item['facts']
        members.append({'decision_reference': {key: envelope[key] for key in ('line', 'offset', 'bytes', 'sha256')},
                        'attempt': item['attempt'], 'player_hp_delta': facts['player_hp_delta'],
                        'enemy_hp_delta': facts['enemy_hp_changes'][0]['hp_delta'],
                        'replanning_decisions': facts['replanning_decisions'],
                        'before': facts['before'], 'after': facts['after'],
                        'candidate_result': facts['actual_full_candidate_result']})
    assert [item['player_hp_delta'] for item in members] == expected_hp
    assert [item['enemy_hp_delta'] for item in members] == expected_enemy
    pairs.append({'run_id': run, 'floor': floor, 'turn': turn, 'same_fingerprint': True,
                  'members': members, 'scope': '同盘两轮观测净变化，包含续步和重问，不认证完整候选因果或整战效果。'})
dump('paired-observations.json', pairs)

summary = []
for run, audit in sorted(audits.items()):
    summary.append({'run_id': run, 'segments': len(audit['segments']),
                    'observed_turns': len(audit['observed_turns']),
                    'turn_status': dict(Counter(item['status'] for item in audit['observed_turns'])),
                    'unknown_reasons': dict(Counter(item['reason'] for item in audit['observed_turns'] if item['reason'])),
                    'certified_candidates': sum(item['actual_full_candidate_result'] is not None for item in audit['segments']),
                    'scope': '有界离线证据消费者；null 是未认证，不断言实际没有执行。'})
dump('consumer-summary.json', summary)

cited_states = {item['line']: item for item in json.loads((OUT / 'cited-states.json').read_text())}
slot_cases = []
for decision_line, before_line, after_line, slot, ident in [
    (274131, 280206, 280207, 0, 'ATTACK_POTION'),
    (274156, 280232, 280233, 0, 'STABLE_SERUM'),
    (274185, 280262, 280263, 0, 'SPEED_POTION'),
    (274235, 280313, 280314, 1, 'WEAK_POTION'),
    (274237, 280315, 280316, 0, 'ATTACK_POTION'),
    (274267, 280348, 280349, 1, 'GLOWWATER_POTION'),
    (274272, 280354, 280355, 0, 'SKILL_POTION'),
]:
    decision = decisions[decision_line]
    before, after = cited_states[before_line], cited_states[after_line]
    def potion(envelope):
        return next(item for item in envelope['row']['state']['run']['potions'] if item['index'] == slot)
    assert potion(before)['potion_id'] == ident and potion(before)['occupied'] is True
    assert potion(after)['potion_id'] is None and potion(after)['occupied'] is False
    assert decision['row']['chosen']['action'] == 'use_potion'
    slot_cases.append({'decision_line': decision_line, 'state_lines': [before_line, after_line],
                       'floor': decision['row']['floor'], 'turn': decision['row']['turn'],
                       'potion_id': ident, 'slot': slot, 'result': decision['row']['result'],
                       'observed_slot': [ident, None], 'full_candidate_result': None})
dump('potion-slot-observations.json', slot_cases)

attempts = []
for line in (OUT / 'evidence/sl-attempts.evidence.jsonl').open():
    envelope = json.loads(line)
    row = envelope['row']
    if row['floor'] != 17:
        continue
    attempts.append({'run_id': row['run_id'], 'source_line': envelope['line'], 'sha256': envelope['sha256'],
                     'encounter': row['encounter'], 'attempt': row['attempt'], 'result': row['result'],
                     'turns': row['turns'], 'end_hp': row['end_hp'],
                     'last_summary': row['summary']['turns'][-1],
                     'anchor': row.get('explore', {}).get('anchor')})
dump('floor17-attempts.json', attempts)

print(json.dumps({'同盘配对': len(pairs), '七次用药槽变化': len(slot_cases),
                  '消费者片段': sum(item['segments'] for item in summary),
                  '可核整轮端点': sum(item['turn_status'].get('observed_turn_endpoints', 0) for item in summary),
                  '完整候选认证': sum(item['certified_candidates'] for item in summary)}, ensure_ascii=False))

静默猎手策略提案核验；记录时间 2026-10-17T17:12:39+08:00。

本批为普通队列任务，十项全部 waiting；没有发现需要重复实现的诊断，也没有取得足以修改策略的新完整对照。未改生产源码、任务模板、知识、规则、live或版本；没有源码提交与合入，fixes=[]、merged=null。原提案、原失败与已上线子项全部保留。

批次：20261017-170116-s2-strategy-proposal。派发工作树与角色、六局集合已核对；没有 research_request、implementation_request、proposal_repair；reason=proposal，不满足手动专题身份。只处理 dispatch.json 中十个 proposal_ids，没有领取其他队列。开工 git status 干净，git merge --no-edit main 返回 Already up to date；基线始终为 e2f8df47dc5a09cfee0386880d937b3e8cecf984。

README、最新STATE、decision-log末尾、学习协议与代码提案闭环已阅读；普通专题条件不匹配，未读取其他专题输入。未派子agent、未联网、未运行play或游戏API、未读其他角色知识或游戏二进制。

六局身份、原件与证据范围：

|局号|角色/进阶|原决策/状态|离线输入决策/状态|
|---|---|---|---|
|751FN9QM9MHQ|silent/A10|615/624|270/271|
|KV0JHNJCKXLS|silent/A10|669/686|144/144|
|YQL8RZ8BWN1E|silent/A10|571/582|107/107|
|L9SGRBB5R698|silent/A10|635/653|52/52|
|PU80F84P6HPN|silent/A10|1033/1064|84/84|
|KEN58SH9SLZ6|silent/A10|548/558|393/401|

原日志仅经共用extract_evidence.py选取，八流共8444条封套；evidence/evidence-manifest.json保留各流冻结source_size、逐局计数和输出SHA，每条封套保留原始行号、offset、bytes、SHA。prepare_audit.py逐条seek原日志，全部核对原字节SHA、JSON、所属局及截点上界，结果见evidence-verification.json。states/decisions/brain全源各有2条无效JSON，原共用抽取报告保留；这不是所选局缺帧的证明。fight-plans在2233957字节截点选中0，不能据此断言原日志缺失。

离线消费者只读有界冻结输入：751为F13 T2—4及F17 T1—3/6—8/12—14/16+；KV为F33 T4—6/8+；YQL为F17 T9+；L9为F17 T12+；PU为F17 T14+；KEN为F3/4/5/11/15 T1—3及F17 T1—6/8+。真实原行号全部保留，跳过的轮次不补成连续，所选范围无缺ID或时间元数据排除。全量抽取不等于全量消费者覆盖。

六次执行现有learner/audit-selection.ts，退出码均0，见consumer-exits.json。1050决策、1059状态形成204片段、241个轮窗口，其中98个可核整轮端点。完整候选认证为0，是消费者明确保留null的能力边界，不能由此声称实际未执行，也不能将98个净变化归给原始候选。数据处理成功不等于生产tsc/vitest、自测红绿、胜率验证或大脑自然采用。

已直接核实的局部证据及反例：

|局号/层/回合|同指纹原/换决策行|整轮净损血 原→换|敌净扣血 原→换|限制|
|---|---|---|---|---|
|751 F17 T2 第1/3试|272434/272575|13→18|9→18|多9扣血付5血；不是整战获益|
|751 F17 T7 第2/4试|272531/272652|13→23|12→18|多6扣血付10血；弃牌后端点不是保守上界|
|751 F17 T13 第1/6试|272483/272820|8→2|17→11|省6血也少6扣血，反驳只保血恒优|
|KEN F17 T10 第4/5试|274505/274568|15→21|2→4|B2 .385→.127、差-.2583/SE .0132；后续动作也变|
|KEN F17 T5 第4/6试|274484/274601|7→5|1→2|末试追加重问保留；步法建立延迟，不能把省血当保留能力收益|

以上五组指纹精确相同，paired-observations.json保留决策offset/SHA、前后原状态行与重问，summarize_audit.py核对预期净变化。敌净扣包含原帧间全部已观察变化，不改称卡牌伤或毛伤。751 T7首试45→39、敌121→117是另一个6损/4扣案例，不与第二试13损/12扣混用。所有同局重打只算一个独立局，未拿这些配对拟合参数并再次冒称独立验证。

751 F13 T3原决策272361的plan2与真正整战无药plan5均即时损8，五轮8/8胜，牌伤26/16、存活样本预计结束约2.3/2.9轮；plan3本轮无药但后续7/8样本喝药，不能代替plan5。272362实际喝肌肉药。原文成本0明确因表未加载，不能推导留药价值0；没有无药实打及留药Boss支线。相关账本0019/0021/0005/0007/0129/0176及131提案的其余条目保留。

KV F33 T5原决策273400/273450指纹一致，第五试273451又重问并避免补毒；消费者保留全部原问与续问。两试整轮严格结果均turn_end_unverified，原题0损、36→29输出预测及复盘净扣观察不能冒认完整候选实际毛伤或删除毒药的受控收益。敌回血逐来源、SL截断和路线/休息替代后继仍缺，账本0102/0019/0020。

YQL F17 T10决策274087、states280160→280161：槽0毒药有→空，毒2→8，HP26、挡13、EXPLODE_MOVE的41来袭不变；当前血挡差式26+13−41=−2只为该末态参考，不预测另一时点用药胜负。L9 sl-attempts681、PU717和YQL960—963保留原近十亿占位血与参考排序。PU的F17胜试不证明改排序有效，末线还改变后续动作与资源；完整整局记录PU也不是通关。账本0017/0250及0011/0027/0046、0019/0020。

KEN七次用药：F3T2/槽0攻击、F4T1/槽0稳定、F5T2/槽0速度、F11T1/槽1虚弱、F11T2/槽0攻击、F15T1/槽1发光水及槽0技能。决策274131/274156/274185/274235/274237/274267/274272与各自前后状态逐槽核对；三条随机选牌药请求为pending，之后空槽是观测，不能改写回执为已完成整条候选。potion-slot-observations.json保留明细。没有同题不喝、保留到Boss完整支线；账本0019。

源码核对以base=e2f8df47dc5a09cfee0386880d937b3e8cecf984和实际live快照=3910f41b9c3784a70362f63aad5f0994794c68b7为准；15个相关源码叶的blob、字节及SHA保存在source-reference.json，14叶相同，sl/explore.ts三处差异只为注释人名，完整补丁在base-live-source.patch。source/保存.txt原字节，未将副本命名为可执行.ts。历史六局各自code带dirty，没有恢复当时完整脏树，不能用当前源码冒充当时运行版本。

已存在的实现子项及真实祖先提交：

|实现子项|base与live均为祖先的源码提交|能力边界|
|---|---|---|
|持牌失血与候选阶段预测|9d8278702dbc581b5015ba7ec9a70dc0fb94cccb|actual_held_hp_loss/actual_turn仍null|
|未知药水持有价与同题无药参考|c4670f4f416c7d93e192e889c5080e7e4e0e733f|模型抽样；不是留药实盘价值|
|候选动作派发回执|fdaf787a372880b0438e73bcac7e6d2168b038ed|单动作，whole_plan_executed仍null|
|巨兽残壳阶段与药水观察|40168f4a903ae1d8c48bd03006f8fea19fd3aa3c|body_hp=0提示不修改旧anchorRank|
|SL预测资源对比|1698adc96ba434a46942321e0237b70657e625b2|差分为预测，execution=unverified|
|离线整轮端点消费者|e75438488df159b2e8e9d3458cf219b39aadd933|净变化，完整候选及逐来源因果仍null|

narrow-implementation-ancestry.json保存逐提交祖先布尔。没有把子项祖先拼成十条宽提案的duplicate/implemented，也没有更改原0250等账本shipped状态。当前enemyHpLeft仍从末轮字符串加总原HP，anchorRank仍先存活轮、再原HP；这是明确保留的排序缺口，阶段提示不是排序修复。本批没有证据证明新旧参考选择与完整后继胜负，未凭占位血异常自行指定排序权重。

逐项处置（完整原提案及其保存SHA已核，副本为各ID.original.md）：

|派发ID|证据/账本|处置与下一次所需数据|
|---|---|---|
|silent-proposal-366288801d9150d9|751FN9QM9MHQ；silent-0079, silent-0176|waiting：751 F17 T2/T7/T13五、十、负六血的换线差已由同指纹及整轮端点复核；现有候选预测不认证完整执行，缺逐来源实际结算、保持其他后轮不变的整战对照和独立验证，不能拟合探索门槛。|
|silent-proposal-85929bdfc8a3fc1b|751FN9QM9MHQ；silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176|waiting：751 F13 T3用药plan2与整战无药plan5均预测损8、8/8胜；plan3后续7/8样本仍喝药。持有价未知和弃牌未决已有诊断，缺实际无药整战、留药后战及逐来源兑现，不能拟合留药价值或改弃牌排序。|
|silent-proposal-efd9f83ee9e1a6dc|751FN9QM9MHQ；silent-0079, silent-0176|waiting：与366288801d9150d9使用同一751局三组配对，不增加独立分母。缺完整候选归属、实际来源成本和受控整战后继，已有SL预测/动作回执只能覆盖诊断子项。|
|silent-proposal-131042659448ae74|751FN9QM9MHQ；silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176|waiting：751敏捷、毒、荆棘及呼唤有局部观测和现有模型诊断；缺各来源联合实际校准、完整候选归属及无药/留药跨战对照，不能用单机制实现关闭联合提案。|
|silent-proposal-990f054036609447|KV0JHNJCKXLS；silent-0102, silent-0019, silent-0020|waiting：KV F33第4/5试T5含第五试续问；严格消费者两轮均turn_end_unverified。原题删毒药预测36→29、同零损，不等于已认证毛伤；缺敌回血/输出逐来源归属及整战、路线和休息替代后继。|
|silent-proposal-e18d3f18e6cac2a0|YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN；silent-0017, silent-0250, silent-0011, silent-0027, silent-0046|waiting：YQL F17 T10残壳毒2→8而26血/13挡/41来袭不变；巨兽阶段提示已有live实现，enemyHpLeft/anchorRank仍保留占位血作旧平局输入。缺新旧排序及提前喝/不喝/留药的受控整战后继。|
|silent-proposal-9733bb80f445aeae|YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN；silent-0017, silent-0019, silent-0020, silent-0250|waiting：L9/PU/YQL阶段证据及现有body_hp=0提示不等于分阶段排序效果验证。原占位血平局输入仍在；PU胜线同时改变后续动作，缺参考路径新旧对照及用药时点独立分支，保留宽提案等待。|
|silent-proposal-c51468c5e8ba6668|KEN58SH9SLZ6；silent-0019|waiting：KEN七次用药请求与逐槽有药→空均复核，其中两攻击药和技能药共三条pending。缺随机选牌/发光水重问后的完整收益归属、同题不喝和留至Boss的完整分支，75/86空栏入口不能拟合持有价。|
|silent-proposal-86a7db08d1a31976|KEN58SH9SLZ6；silent-0079, silent-0021, silent-0125, silent-0005, silent-0176|waiting：KEN F17 T10同盘净损15→21、敌净扣2→4；T5净损7→5、净扣1→2但步法延后且有追加重问。缺完整候选和能力收益归属、受控整战及独立验证，保留排序和HP护栏。|
|silent-proposal-e282a9131b99129a|KEN58SH9SLZ6；silent-0021, silent-0079, silent-0125, silent-0176|waiting：与86a7db08d1a31976使用同一KEN局两组局部对照，六次SL不当六局。现有预测与观测端点不认证完整执行，缺受控整战和后期独立验证，不能拟合统一6血/2伤门槛或关闭探索。|

每项未来验证都应使用本角色固定原帧，明确原/新候选、重问边界、实际持牌、各来源结算、整战后继与时间切分；新拟合需早期独立局训练和后期独立局留验，不拆同局SL为独立训练/验证，也不把模拟充作实盘反事实。只要缺数据，保留旧排序、护栏、药水、SL和终局规则。若后续改源码，再按原任务做撤源码失败/恢复通过、沙箱tsc/vitest、gitleaks及live流程；本批不借用历史绿色。

账本只经根learner/ledger.py update为16个既有silent条目追加本批proposal/report追溯链接及等待说明，不新增support/反例，不改claim、first_run、prior、evidence、status、version或effect，不降级已有shipped。没有新科学异议或与旧知识冲突；已知排序宽缺口和各原提案相同，未另造重复提案ID。原根账本字节前缀与本批CLI追溯另存核验。

提交/上线/版本：均无；merged=null。不需要启动live合入锁、知识刷新提交、生产测试或规则上线双通知。生产tsc、vitest、cases均null；撤源码失败与恢复通过均未执行、不适用。上述Python数据断言及六个离线消费者的exit0只作证据核验，不填入生产测试结果。铁甲与未观察进阶行为没有源码变动。

运维交接提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-170116-s2/learner/runs/20261017-170120-fc5d8e41-c91e-40aa-9b70-ea6086830996-strategy-proposal/proposal.md。最终机器回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-170116-s2/learner/runs/20261017-170120-fc5d8e41-c91e-40aa-9b70-ea6086830996-strategy-proposal/final-report.json。工作树tracked/index保持干净，HEAD保持base；所有报告、原件、初始快照、数据处理日志、源.txt及.patch留在本批scratch，不提交、不清理自身工作树。调度器读取逐项waiting，保留待新局重派；父学习要求不因本报告结束而关闭。

结束核验：completion-verification.json确认HEAD等于base、tracked/index干净、十项处置齐全；ledger-verification.json确认16条CLI追溯实际追加且旧字节前缀及保护字段不变。gitleaks对本批scratch退出0、发现列表为空，原输出见gitleaks.log/json。artifacts-manifest.json保存产物逐文件字节数及SHA，不含它自身。

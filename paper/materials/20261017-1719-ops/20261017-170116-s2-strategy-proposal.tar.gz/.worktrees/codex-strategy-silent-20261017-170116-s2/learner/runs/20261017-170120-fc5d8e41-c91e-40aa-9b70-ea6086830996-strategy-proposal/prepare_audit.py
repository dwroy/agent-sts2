import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
RUNS = json.loads((OUT / 'run-identities.json').read_text())


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


spec = importlib.util.spec_from_file_location('extractor', Path.cwd() / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
verification = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = Counter()
    envelopes = []
    with path.open('rb') as handle, (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
        for raw in handle:
            digest.update(raw)
            envelope = json.loads(raw)
            source.seek(envelope['offset'])
            original = source.read(envelope['bytes'])
            assert hashlib.sha256(original).hexdigest() == envelope['sha256']
            assert json.loads(original) == envelope['row']
            assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
            assert extractor.run_identity(envelope['row']) == envelope['run_id']
            assert envelope['run_id'] in RUNS
            counts[envelope['run_id']] += 1
            envelopes.append(envelope)
    assert digest.hexdigest() == stream['output_sha256']
    assert {run: counts[run] for run in RUNS} == stream['counts']
    streams[name] = envelopes
    verification.append({'stream': name, 'source_size': stream['source_size'],
                         'verified_lines': len(envelopes), 'output_sha256': digest.hexdigest(),
                         'counts': stream['counts'], 'offset_bytes_sha_and_identity_verified': True})
dump(OUT / 'evidence-verification.json', verification)


def in_scope(run, floor, turn):
    if not isinstance(turn, int):
        return False
    if run == '751FN9QM9MHQ':
        return floor == 13 and 2 <= turn <= 4 or floor == 17 and (turn <= 3 or 6 <= turn <= 8 or 12 <= turn <= 14 or turn >= 16)
    if run == 'KV0JHNJCKXLS':
        return floor == 33 and (4 <= turn <= 6 or turn >= 8)
    if run == 'YQL8RZ8BWN1E':
        return floor == 17 and turn >= 9
    if run == 'L9SGRBB5R698':
        return floor == 17 and turn >= 12
    if run == 'PU80F84P6HPN':
        return floor == 17 and turn >= 14
    if run == 'KEN58SH9SLZ6':
        return floor in (3, 4, 5, 11, 15) and turn <= 3 or floor == 17 and (turn <= 6 or turn >= 8)
    return False


def provenance(envelope):
    return {key: envelope[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


inputs = OUT / 'consumer-inputs'
inputs.mkdir(exist_ok=True)
coverage = []
for run, identity in RUNS.items():
    decisions, states, exclusions, selected_refs = [], [], [], []
    for envelope in streams['decisions']:
        row = envelope['row']
        if envelope['run_id'] != run or not in_scope(run, row.get('floor'), row.get('turn')):
            continue
        if not row.get('decision_id') or not row.get('observed_ts'):
            exclusions.append({**provenance(envelope), 'reason': '缺少 decision_id 或 observed_ts，未伪造身份和时间。'})
            continue
        decisions.append({**row, '_line': envelope['line'], '_source_sha256': envelope['sha256']})
        selected_refs.append(provenance(envelope))
    for envelope in streams['states']:
        row = envelope['row']
        state = row.get('state', {})
        if envelope['run_id'] != run or not in_scope(run, state.get('run', {}).get('floor'), state.get('turn')):
            continue
        states.append({**row, '_line': envelope['line'], '_source_sha256': envelope['sha256']})
        selected_refs.append(provenance(envelope))
    decisions.sort(key=lambda row: row['observed_ts'])
    assert len({row['decision_id'] for row in decisions}) == len(decisions)
    dump(inputs / (run + '.json'), {'run': identity, 'decisions': decisions, 'states': states})
    coverage.append({'run_id': run, 'decisions': len(decisions), 'states': len(states),
                     'excluded_metadata': exclusions, 'references': selected_refs})
dump(OUT / 'consumer-input-coverage.json', coverage)

cited_lines = {
    'states': [278479, 278483, 278500, 278505, 278620, 278623,
               280160, 280161, 280206, 280207, 280232, 280233,
               280262, 280263, 280313, 280314, 280315, 280316,
               280348, 280349, 280354, 280355],
    'decisions': [272361, 272362, 272434, 272575, 272531, 272652,
                  272483, 272820, 274087, 274131, 274156, 274185,
                  274235, 274237, 274267, 274272, 274505, 274568,
                  274484, 274601, 274354],
    'sl-attempts': [681, 717, 960, 961, 962, 963],
}
for stream, lines in cited_lines.items():
    found = [envelope for envelope in streams[stream] if envelope['line'] in lines]
    assert set(lines) == {envelope['line'] for envelope in found}, (stream, set(lines) - {e['line'] for e in found})
    dump(OUT / ('cited-' + stream + '.json'), found)
print(json.dumps({'已核原行': sum(item['verified_lines'] for item in verification),
                  '消费者有界输入': [{key: item[key] for key in ('run_id', 'decisions', 'states')} for item in coverage]}, ensure_ascii=False))

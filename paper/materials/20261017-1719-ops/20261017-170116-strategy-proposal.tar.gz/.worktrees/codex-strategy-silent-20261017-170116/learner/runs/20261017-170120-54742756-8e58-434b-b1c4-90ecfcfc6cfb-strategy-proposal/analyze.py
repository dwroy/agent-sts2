"""本批冻结证据的只读整理；不运行游戏或策略模拟。"""
import collections
import hashlib
import json
from pathlib import Path
import runpy

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']
FLOORS = {
    'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39],
    'CA5KE8GFJ9X2': [13], '8JRE1C4H4Z2W': [17, 33],
    'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [31, 33],
}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def reference(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def summarize(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **reference(item), 'observed_ts': item['row'].get('observed_ts'),
        'floor': state.get('run', {}).get('floor'), 'turn': state.get('turn'),
        'screen': state.get('screen'),
        'hp': player.get('current_hp', state.get('run', {}).get('current_hp')),
        'block': player.get('block'), 'powers': player.get('powers'),
        'cards_played': player.get('cards_played_this_turn'),
        'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'resolved_rules_text')}
                 for c in combat.get('hand', [])],
        'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp',
                                            'block', 'is_alive', 'powers', 'move_id', 'intents')}
                    for e in combat.get('enemies', [])],
    }


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
identity = runpy.run_path(str(Path.cwd() / 'learner/extract_evidence.py'))['run_identity']
streams = {}
checks = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    rows = []
    counts = collections.Counter()
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source, path.open('rb') as handle:
        for raw in handle:
            digest.update(raw)
            item = json.loads(raw)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            original = source.read(item['bytes'])
            assert hashlib.sha256(original).hexdigest() == item['sha256']
            assert json.loads(original) == item['row']
            assert identity(item['row']) == item['run_id'] in RUNS
            rows.append(item)
            counts[item['run_id']] += 1
    assert digest.hexdigest() == stream['output_sha256']
    assert all(counts[r] == stream['counts'][r] for r in RUNS)
    streams[name] = rows
    checks.append({'stream': name, 'source_size': stream['source_size'],
                   'rows': len(rows), 'counts': dict(counts), 'verified': True})
save('provenance-validation.json', {'streams': checks, 'rows': sum(c['rows'] for c in checks)})

verified_runs = {r['run_id']: r for r in streams['runs']}
assert set(verified_runs) == set(RUNS)
assert all(r['row']['character'].lower() == 'silent' and r['row']['ascension'] == 10
           for r in verified_runs.values())
save('run-identities.json', list(verified_runs.values()))
state_index = collections.defaultdict(list)
for item in streams['states']:
    state_index[(item['run_id'], item['row'].get('observed_ts'), item['row'].get('fingerprint'))].append(item)

inputs = OUT / 'consumer-inputs'
inputs.mkdir(exist_ok=True)
input_summary = []
observations = []
exclusions = []
for run in RUNS:
    selected = [item for item in streams['states']
                if item['run_id'] == run and item['row']['state'].get('run', {}).get('floor') in FLOORS[run]]
    states = [{**s['row'], '_line': s['line'], '_source_sha256': s['sha256']} for s in selected]
    candidates = [item for item in streams['decisions']
                  if item['run_id'] == run and item['row'].get('floor') in FLOORS[run]]
    decisions = []
    for item in candidates:
        row = item['row']
        if not isinstance(row.get('decision_id'), str) or not row['decision_id'] or not row.get('observed_ts'):
            exclusions.append({**reference(item), 'reason': '缺原始 decision_id 或 observed_ts；不补造'})
            continue
        decisions.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    decisions.sort(key=lambda row: (row['observed_ts'], row['_line']))
    assert len({d['decision_id'] for d in decisions}) == len(decisions)
    value = {'run': verified_runs[run]['row'], 'decisions': decisions, 'states': states}
    path = inputs / (run + '.json')
    path.write_text(json.dumps(value, ensure_ascii=False) + '\n')
    input_summary.append({'run_id': run, 'floors': FLOORS[run], 'decisions': len(decisions), 'states': len(states),
                          'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    observations.extend(summarize(item) for item in selected)
save('consumer-input-manifest.json', input_summary)
save('consumer-exclusions.json', exclusions)
with (OUT / 'observations.jsonl').open('w') as handle:
    for row in observations:
        handle.write(json.dumps(row, ensure_ascii=False) + '\n')

decision_by_line = {item['line']: item for item in streams['decisions']}
pair_checks = []
for run, left, right in [('8JRE1C4H4Z2W', 270216, 270282),
                          ('YF0LXT1QSTGG', 271309, 271348),
                          ('XP2SL33HT0D9', 271992, 272040),
                          ('XP2SL33HT0D9', 271982, 272195)]:
    endpoints = []
    for line in (left, right):
        item = decision_by_line[line]
        row = item['row']
        assert item['run_id'] == run
        start = state_index[(run, row['observed_ts'], row['fingerprint'])]
        assert len(start) == 1
        next_decisions = [i for i in streams['decisions'] if i['run_id'] == run
                          and i['line'] > line and i['row'].get('floor') == row['floor']
                          and i['row'].get('turn') == row['turn'] + 1
                          and i['row'].get('sl_attempt') == row.get('sl_attempt')
                          and i['row'].get('sl_reloads') == row.get('sl_reloads')]
        next_item = next_decisions[0]
        end_row = next_item['row']
        end = state_index[(run, end_row['observed_ts'], end_row['fingerprint'])]
        assert len(end) == 1
        a, b = summarize(start[0]), summarize(end[0])
        ids = lambda s: sorted((e['enemy_id'], e['max_hp']) for e in s['enemies'])
        assert ids(a) == ids(b)
        endpoints.append({'decision': reference(item), 'attempt': row.get('sl_attempt'),
                           'before': a, 'next_turn': b,
                           'hp_net_loss': a['hp'] - b['hp'],
                           'enemy_hp_net_decrease': sum(e['current_hp'] for e in a['enemies'])
                                                    - sum(e['current_hp'] for e in b['enemies']),
                           'actual_full_candidate_result': None, 'causal_result': None})
    assert decision_by_line[left]['row']['fingerprint'] == decision_by_line[right]['row']['fingerprint']
    pair_checks.append({'run_id': run, 'decision_lines': [left, right], 'fingerprints_equal': True,
                        'scope': '同指纹至下一轮观测端点；非候选完整执行或整战因果', 'endpoints': endpoints})
save('paired-endpoints.json', pair_checks)
print(json.dumps({'provenance': sum(c['rows'] for c in checks), 'consumer_inputs': input_summary,
                  'excluded': len(exclusions), 'pairs': [
                      {'run': p['run_id'], 'lines': p['decision_lines'],
                       'hp_loss': [e['hp_net_loss'] for e in p['endpoints']],
                       'enemy_hp_decrease': [e['enemy_hp_net_decrease'] for e in p['endpoints']]}
                      for p in pair_checks]}, ensure_ascii=False))

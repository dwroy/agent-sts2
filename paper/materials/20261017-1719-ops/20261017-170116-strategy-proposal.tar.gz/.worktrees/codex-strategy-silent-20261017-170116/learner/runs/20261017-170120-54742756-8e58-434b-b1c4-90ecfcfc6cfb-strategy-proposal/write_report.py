"""保存本批逐项处置；不写队列、经验或源码。"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
props = json.loads((OUT / 'proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
base = (OUT / 'base.txt').read_text().strip()
details = [
    ('DUZUBAJ3A8GP F27 T4—T6',
     'states 274830—274839：T4 火花3，迷雾后污染3、勒紧后仍3、防御后6；T5 火花6，完成生存者选择后污染6、再防御12、迷雾18，26攻击、17挡，49→46→37血；T6污染已不在能力列表。选择中间帧274835尚未显示污染，不能据此认定技能不加污染。',
     '技能同时施毒、施弱或加挡，T5损9本身不证明应禁技能。',
     '缺原运行实际读取的A10移动表冻结字节及火花增长、污染清除、毒/弱/挡连续后继的生产联合校准；现有累积接口和观测读回只覆盖局部，不能据9损新增禁技能规则。'),
    ('5PM6JAQG6FNQ F39 T4—T6',
     'states 274351—274358：玩家−4力量/−4敏捷，两步法先后恢复敏捷至−2/列表无敏捷；失落退场后力量也不在列表。274362遗忘仍在、玩家敏捷−2、遗忘敏捷6。末试只有一步法，8血0挡未存活。',
     '敌方总属性并非显式累计抢夺量；列表中没有某能力也不是日志额外提供了该来源的零值。现有帧未包含遗忘退场返敏及再次抢夺的完整链。',
     '缺逐实体抢夺累计的显式真值、可靠连续实例身份、遗忘退场返敏和再次抢夺的完整固定链；不能用敌方总属性代填被抢数或规定固定击杀序。'),
    ('CA5KE8GFJ9X2 F13 T1—T5',
     'states 273237—273269：T1启动早帧0挡，随后覆甲9/敌挡9；T3力4/喷水15，T5力8/喷水19，中和后14，2血/10挡最终归零。轮初覆甲见9/9/8/7/6，早帧与首次可操作帧分开保留。',
     '覆甲数字只约束这些帧，未穷尽减层触发。没有已知SL尝试号的记录不能补成attempt=1。',
     '缺原调用A10移动表字节和加压/覆甲全过程的生产联合校准；本局SL尝试元数据未知，严格消费者未认证完整轮，不能以现场攻击或末轮死亡拟固定房间成本。'),
    ('5PM6JAQG6FNQ F38 T3—T4',
     'states 274308/274313：同类电击最大血23，力2→4、意图17→19、高电压均2；index4→3，期间戳刺退场。T3玩家61→31，电击仍贡献17；T4才清掉电击。',
     '最大血与类型只能支持所见连续性，不能替代稳定实例ID或召唤代际。另一候选35伤/损3未整线实打，不是救后场27血的证据。',
     '缺原移动表、可靠召唤代际身份和连续增长后继的冻结生产校准；现有HIGH_VOLTAGE_POWER增长路径不认证跨代重置或统一集火收益。'),
    ('8JRE1C4H4Z2W F17 T6；F33 首/三试T2、第二试T5、末试T11',
     'decisions 270216/270282同指纹，下一轮端点实损3/15、敌血净减10/17；五轮死亡0/24与5/24仍不同。末试T11终局端点有5→0血、敌154→130，显示37攻击减22挡=15仅是未截断需求参考。F17抽牌后的重问及F33原答/换线均保留。',
     '末试偏防御后延至T11仍败；第二试T5的护栏候选差不能全部当实际保血。终局实际扣5不能当完整入伤15，候选预测不能归给重问后的全部动作。',
     '缺全部重规划后的逐候选续步身份、沙坑/能力逐来源结算及路线资源归属；现有审计消费者保留完整候选为null，不能拼接窄子项关闭原宽请求。'),
    ('YF0LXT1QSTGG F48 第二/三试T1、第四试T5；F33成功SL',
     'decisions 271309/271348同指纹，下一轮端点实损0/9、敌血净减45/38；两个题面候选24/24死亡、封顶27，但其预测损0/10、伤54/36不等于实值。第四试T5的弃牌重问仍在消费者输入。',
     '第六试恢复挡续步后T1零损仍T5败；同局F33的SL实际过关，不能由F48全败否定全部探索。未对未选候选补造执行。',
     '缺完整候选实际续步及血价来源归属、同抽序完整替线和独立整战验证；有限全败样本并列不足以拟HP惩罚常数或禁止探索。'),
    ('YF0LXT1QSTGG F48 末试T3—T5',
     'states 277512/277513为4/111血、4毒切到212/212血且旧毒/力量不在列表；277520—277527触媒2、敌零毒，既有23挡在敏捷5→6后保持23，敌197→160。18血/23挡对44的21需求差3，死亡实扣18另列。',
     '前五次曾建毒雾或余像仍败，持有升级毒性爆发不等于第二阶段施放；不能推出强制能力先手或后抽毒牌必达。',
     '缺逐候选即时施毒/已结算毒、额外扣血和敏捷取得顺序的来源归属及完整派发的联合认证；当前阶段事实与live阶段能力窄修均不等于原提案全部校准。'),
    ('XP2SL33HT0D9 F33 首/二试T3、首/末试T1、第三试T4',
     'decisions 271992/272040同指纹，实损9/14、敌血净减24/27；271982/272195同指纹，实损2/10、敌血净减25/34，末试另建立力量。272076所列两候选五轮21/24与23/24不是相同死亡比例，原候选无完整实打。',
     '末试T2零损、T3实损4；两组六次尝试均未得独立整战胜线，后期抽序和出牌不同，不以失败回合数识别单牌因果。',
     '缺同抽序完整替线、成长兑现的受控后继和独立整战胜线；不能据当轮端点拟低血优先门槛、全局HP常数或禁止付血探索。'),
    ('XP2SL33HT0D9 F33 末试T2—T5',
     'states 278236/278237/278240/278242：轮初14挡，镣铐使爪力0→−9、意图4→0，斗篷后20挡，次轮37血不变且减力消失。278249/278252/278253火箭57→38→28，朝向/弱分别19/10；两步法最终4敏，脆弱下6挡，末轮毒3+7另结。',
     '现场已有14挡不等于本候选新建14；后来4敏不倒补既有挡，末轮11血截断不能反推出所有伤害来源。两敌均未减员，不能外推单边死亡机制。',
     '缺逐候选拆分原有/新增挡、朝向/弱、已结算毒和存活HP的统一来源校准；现有局部公式、现场参考和离线端点不认证完整候选执行模型。'),
    ('YF0LXT1QSTGG F48；XP2SL33HT0D9 F31/F33',
     '本批重新核四组同指纹端点和两局已建能力、临时减力/轮初挡；XP F31复活时最大血重复及缺中间帧的历史勘误保留，敌方活血净差不改称实际攻击总伤。路线/休息及药水仍按原复盘保留来源限制。',
     '构筑持有、能力建立、候选预测、单步请求、观测净变化和完整派发是不同证据；未执行的留药/换路线/抽序没有受控整战后继，不能从若干成立公式合成收益。',
     '缺逐来源资源账、所有重规划后完整候选归属、路线/药水时机和受控整战后继；多个窄事实不替代原宽请求交付。'),
]
assert len(props) == len(details) == 10
results = []
sections = []
for p, (scope, evidence, counter, missing) in zip(props, details):
    results.append({'id': p['id'], 'state': 'waiting', 'reason': missing})
    sections.append(f"""## {p['id']}

原摘要：{p['summary']}

证据范围：{scope}。账本：{', '.join(p['ledger'])}。原文及SHA见 original-proposals-manifest.json；没有修改或重登记原提案。

本次原行核验：{evidence}

反例与未知：{counter}

旧规则与预期行为：沿原提案要求，区分可观察事实、预测与已执行结果；保留现有出牌、药水、SL及终局选择，全部选项仍可用。没有由本批拟合阈值、权重、血价比例或强制击杀序。

处置：**waiting**。{missing}

验证与后移输入：本批固定证据及现有离线消费者只核上述端点；补齐所列原始输入/来源链后，才做针对确定源码失配的固定生产重放与撤源码红/恢复绿。若要改选择，按run_id分组，用独立后续静默A10整场作时间后移验证；SL尝试不扩独立分母。

预期影响和回退：本次只保存追溯和未完成原因，不声称自然采用或胜率收益。没有源码回退、live合入或行为版本；后续实现只回退其自身补丁并保留日志历史。
""")

prefix = f"""# 本批十项静默策略提案核验

task=strategy-proposal；character=silent；batch=20261017-170116-strategy-proposal。

结论：10项均waiting；本次没有新增源码/知识、提交、live合入、eval版本或shipped登记。事实审计不以获胜为前提；本次可核事实已有局部读回路径，尚未发现由这些固定帧唯一确定且本批可以新增实现的剩余源码失配。缺完整策略效果或机制来源时保留原规则。

基线：{base}。开工git status干净；本批既无research_request也无implementation_request，只处理已派proposal_ids；普通专题文件绑定其他batch，没有套用专题。git merge --no-edit main返回Already up to date；未再取后续main。本批runs只取派发六局，原runs均SILENT/A10。未读取其他角色知识，不使用预训练游戏结论。

原始日志通过learner/extract_evidence.py抽取8流，8,274条可解析且明确归属记录逐行重读offset/bytes/SHA及row一致，source_size在evidence-manifest.json。states与decisions/brain各有2条全源坏行，无法由坏行确定归属，不冒完整无损日志。fight-plans在本次截点选中0，仅表示该截点未选到；run-plans有33条，不从正文提及认领身份，不覆盖旧抽取。

6份原复盘（含原勘误）以原字节保存，postmortem-manifest.json记录位置/SHA；原10提案SHA全部相等。30个关联账本只作旧记录引用；历史支持数、宽进阶与first_run不当本批验证分母，本次不重复加support/repeat或反例。

20源码叶已保存必要.txt副本、Git blob/字节SHA、base/live对照及祖先布尔，见source-manifest.json及base-live-source.patch。读取时live为3910f41b9c3784a70362f63aad5f0994794c68b7；17叶字节相同，rollout.ts/rollout-live.ts已有live窄阶段能力修正29f146292892704f618cda8f4db733f21f9cdb1f，explore.ts差异为注释署名；没有将base冒称完整live树，也没有复制或重新发布该窄修。历史六局run-config都带dirty知识数据，当前源码/数据库与历史实际输入不能等同；config前缀SHA也不能还原当时移动表全部字节。

现有局部实现的实际live祖先包括：候选比较66283dd9982bdd7f480da7a4d9bfefea0572a9ac、资源比较1698adc96ba434a46942321e0237b70657e625b2、选线审计9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed、当前阶段事实aad2700abed6dff1d66e87fb36aaa6fedb39adf3、动作区间a32050fbce4c2863f640468c2dbf378fc9157074、终局端点83512ddcd2c70fd9b983dc38524ff25c8970c1d3、回合窗口e75438488df159b2e8e9d3458cf219b39aadd933。它们的限定功能不拼成整项duplicate；本批proposal_results无implemented/duplicate。

当前monsterHpAt/moveBaseDamages读取精确进阶已有观测，不加五样本门槛；roomHpCost的ROOM_COST_MIN_N仍5。这是源码现状，不宣称已恢复历史数据库或完成联合校准。其他角色/未观察进阶的行为没有改动。

来源任务见各原提案；目标实现任务均为本strategy-proposal。既有Roy-2026-10-07-learning授权保留；waiting来自所列数据与识别限制，不因规则曾由人指定而待审批。
"""
(OUT / 'proposal.md').write_text(prefix + '\n'.join(sections))
consumers = json.loads((OUT / 'consumer-summary.json').read_text())
inputs = json.loads((OUT / 'consumer-input-manifest.json').read_text())
table = '\n'.join(f"| {r['run_id']} | {','.join(map(str, i['floors']))} | {i['decisions']} | {i['states']} | {r['segments']} | {r['turns'].get('observed_turn_endpoints',0)} | {r['returncode']} |"
                  for r, i in zip(consumers, inputs))
report = prefix + f"""
## 本批消费者读回及验证口径

只运行已有learner/audit-selection.ts，输入/输出固定落在本scratch，不调用LLM/网络/游戏API或策略模拟，不读取刷新知识JSON。消费者使用本树基线版本；它与读取时live对应工具字节相同。全部原decision_id、_line、observed_ts、SL元数据和状态fingerprint原样保留，未补造未知身份。本次选定楼层输入无缺decision_id/observed_ts的排除行，详consumer-exclusions.json。

| 局号 | 输入层 | 决策 | 状态 | 片段 | 可核回合端点 | 消费者退出码 |
|---|---|---:|---:|---:|---:|---:|
{table}

共1084决策、1105状态、213片段、119可核回合端点。完整候选认证0；所有actual_full_candidate_result保持null，不由null推出“没有实际执行”。DUZ F27及CA F13缺已知尝试元数据，严格消费者保持unknown；不放松守卫来制造完成。其原状态中的火花/污染、加压/覆甲数字仍可逐帧阅读。

paired-endpoints.json保存4组成对端点和完整来源引用：8JRE F33 T2损3/15、敌血净减10/17；YF F48 T1损0/9、敌血净减45/38；XP F33 T3损9/14、敌血净减24/27，T1损2/10、敌血净减25/34。它们不是完整候选因果或独立整战验证。key-observations.json及机制子表保留逐步能力、毒、格挡和死亡截断。

生产源码没有改变，所以撤源码失败/恢复通过不适用，tsc/vitest/cases均null；6次消费者0和证据SHA校验是离线读回，不计本批生产自测或策略收益，不借旧测试作为本批成功。

一次临时只读查看命令在已输出run-config摘要后，误按JSONL读取美化JSON数组，JSONDecodeError、退出1；随后改用json.load读取，14条完整记录读取成功。原工具失败不是产品代码测试，未更改任何证据或生产文件；说明保存在process-notes.md。不以shell最后命令掩盖失败。

本批只经根learner/ledger.py update追加30个既有账本的where.proposal和learner:strategy-proposal说明；没有新增游戏claim/证据/计数，也没有重设status/version/first_run/prior/asc/shipped_at或effect。原proposed保持proposed，原shipped保持shipped。CLI输入、退出和读回在ledger-*材料中；未直接编辑账本/队列，不另建重复id。

源码、经验、在线规则不变，无合入及上线通知动作，merged=null；本批未创建eval版本，不标shipped。后续实际实现按固定自测/红绿/live流程，由ops核实上线。所有派发id都在下面结果中，waiting保留待新局或所列缺数据补齐。

gitleaks和最终工作树/产物完整性核验另见final-validation.json、gitleaks.log及artifact-manifest.json。报告和过程文件位于被忽略的本批learner/runs，不提交，不删除自身工作树。
""" + '\n'.join(sections)
(OUT / 'report.md').write_text(report)
(OUT / 'process-notes.md').write_text('一次只读检查在run-config摘要之后误用逐行json.loads读取已美化的机制JSON数组，出现JSONDecodeError: Expecting value: line 2 column 1 (char 2)，工具退出1。后续使用json.load读取同文件得到14条记录，退出0。没有生产源码改动、证据覆盖或产品测试失败。\n')
value = {'task':'strategy-proposal', 'character':'silent', 'batch':'20261017-170116-strategy-proposal',
         'base':base, 'runs':dispatch['runs'], 'fixes':[],
         'skipped':[{'id':r['id'],'reason':r['reason']} for r in results],
         'merged':None, 'tests':{'tsc':None,'vitest':None,'cases':None},
         'code_proposals':dispatch['proposal_ids'], 'implementation_domains':[],
         'proposal_results':results, 'report':str(OUT / 'report.md')}
(OUT / 'report.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'results':len(results),'report':str(OUT/'report.md'),'proposal':str(OUT/'proposal.md')},ensure_ascii=False))

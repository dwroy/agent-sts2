一次只读检查在run-config摘要之后误用逐行json.loads读取已美化的机制JSON数组，出现JSONDecodeError: Expecting value: line 2 column 1 (char 2)，工具退出1。后续使用json.load读取同文件得到14条记录，退出0。没有生产源码改动、证据覆盖或产品测试失败。

# 本批策略提案处置与普通逃脱计划实现

基线：`0052edea183041950e5d16356a0040925f1b39cc`。批次：`20261015-051302-s2-strategy-proposal`。角色：silent。只处理派发的十项；没有 research_request / implementation_request。main 合并已是最新，专题请求的batch与本批不符，不读取其work_spec。

## 本批已实现并经合后自测的源码范围

源码提交 `8e196be494ada9a33dac3d897a0671a5b14e0e5b`，实际live合入 `ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15`；原提案 `silent-proposal-0337a5f076c49d02`，账本 `silent-0296`。来源局与锚点：LRN0HPZ0FZS1 A0 F48T3；T082DRCUHRRD A0 F17T12与F19T1；LYBHQ1X230ZB A10 F30四试T1。四试计同一独立局。

固定证据：s211753遗漏零能量抽牌；s212038→212039抽呼唤、挡4→4；s212055→212056抽防御、挡0→3；s297869/297878/297887/297896普通逃脱计划0费可打，d290779/290787/290795/290803却结束。全部原行offset/bytes/SHA见 evidence 与 fixed-frames.json / fixed-decisions.json。

旧行为为只读Cards变量得到draw=0，并把条件Block当无条件挡。新行为仅在silent A0/A10、已观察未升级0费Self且普通模板与Block基础3/显示3、5、12一致时接线固定抽1；已知/样本抽入技能才兑现显示挡，抽入已知非技能不获条件挡。未知类型不预支挡，写清未知并由实际抽牌后原流程重规划。

不强制永远出逃脱计划；保留原候选比较。其他角色、升级、未观察进阶/模板保留旧接线。重放/自动/未实际抽入组合仅标未验证，不新增它们的游戏结论；现有一回合/整场抽牌适配器继续复用原逻辑。

## 反例、拟合与验证

抽到呼唤的实际4→4反证无条件加挡。A0两次已执行转移校验机制，A0遗漏与A10遗漏核候选；三独立局，不把四次SL扩为四个样本，不拟合胜率、卡牌价值、SL阈值或终局权重。未知抽序、升级、重放、封抽、满手/空堆以及部分修正组合缺乏本批受控实证，整场改善未知。

8个固定测试涵盖实际帧、已知与样本抽牌、未知不预支格挡、零能量候选、首次格挡标记不被非技能条件消费、其他角色/未观察边界，以及真实planCombatTurn传入solver的消费，以及未知抽牌不得虚拟后续首挡或认证必勝。最终稿撤掉四份源码：6失败/2通过、exit1；恢复：8通过、exit0。沙箱全套结果另见report.md与source-sandbox.log，不能把定向测试写成全套成功。

预期影响是纠正抽牌候选及条件格挡预测；不承诺LYB或其他局获胜。回退仅逆向本项独立源码提交，保留原日志、账本、知识刷新与并行记录。

## 十项逐项处置

### silent-proposal-982c99080350f43e

证据局：G8NHLL09DLBX；账本：silent-0295；来源：postmortem → strategy-proposal。

G8 F24末试T5的三份毒各给幼虫已证明旧最高HP分配是假保证；当前randomVictim仍复用。缺当前完整候选在全部合法毒分配、爪牙退场/制品/重放组合下的固定校准与消费对照，不能用本次修正逃脱计划代替施毒修复。

### silent-proposal-aaefd918a706de14

证据局：G8NHLL09DLBX；账本：silent-0019,silent-0017,silent-0005,silent-0046,silent-0253,silent-0007,silent-0021；来源：postmortem → strategy-proposal。

G8 F23T2速度后9挡/全轮损21、F17末试T15自爆56弱至42/净损33及SL恢复均已核实。原运行dirty源码缺失；尚无本批固定整场回放把临时属性撤回、自爆阶段、SL资源恢复全部接到当前消费者，亦无保药替代整场结果，维持原规则。

### silent-proposal-eb6e17529c0f8cde

证据局：G8NHLL09DLBX；账本：silent-0007,silent-0295；来源：experience-update → strategy-proposal。

与982c99080350f43e共用silent-0295反例，但当前随机毒分配缺口仍在，未提供所有可达分配的安全保证或不确定候选在rollout/SL/自动执行的完整消费验证；不能把经验发布或逃脱计划代码称为该项实现。

### silent-proposal-10c5c87568dcded1

证据局：G8NHLL09DLBX；账本：silent-0012,silent-0005,silent-0046,silent-0253；来源：experience-update → strategy-proposal。

步法/尖啸/速度/弱化自爆/荆棘已有局部模型，原帧证实数值；缺同一冻结输入对五机制组合及速度/尖啸次轮撤回的当前整线消费回放，无法为整项绑定已验证live源码；不据败局拟合饮药/留药门槛。

### silent-proposal-72e211c844b4564e

证据局：G8NHLL09DLBX；账本：silent-0017；来源：experience-update → strategy-proposal。

G8 F17末试本体T14结束、T15仍须自爆，已核实；旧dirty树和前三试被判死截断后的结算缺失，换线、抽牌、药时点同变。缺当前完整阶段/判官/SL恢复的配对验证，不从13条探索拟合新读档权重。

### silent-proposal-1481fe327a22ddeb

证据局：G8NHLL09DLBX；账本：silent-0243,silent-0020,silent-0019,silent-0021；来源：experience-update → strategy-proposal。

G8 F23实际52→22、两药用完后F24以22空药进场已核实；SL恢复与回血分账。缺不喝药、另一候选/路线的完整执行结果，F25及之后未抵达；无法标定持有价值、路线血线或证明替代可活。

### silent-proposal-0337a5f076c49d02

证据局：LRN0HPZ0FZS1,T082DRCUHRRD,LYBHQ1X230ZB；账本：silent-0296；来源：postmortem → strategy-proposal。

已实现：普通逃脱计划固定抽1/条件格挡及未知抽牌处停下重规划并不认证必胜。实际live祖先源码8e196be494ada9a33dac3d897a0671a5b14e0e5b，行为合入ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15，源3950/live3951沙箱固定項通过；旧预检冲突保留，之后live并行整合历史而消失；登记implemented，shipped/正式号由ops核。

### silent-proposal-8e9beeee55eac364

证据局：LYBHQ1X230ZB；账本：silent-0019,silent-0039,silent-0005,silent-0013,silent-0077,silent-0196,silent-0128,silent-0049,silent-0232,silent-0115,silent-0007,silent-0142；来源：postmortem → strategy-proposal。

LYB F29T6两候选原题已核：损18/伤31/8样本全赢对损12/伤22/7样本赢；只有前者实打。缺后者接续F30的实盘结局及独立按局/时间切分数据，不能从6血差拟合终局权重或断言能赢F30。逃脱计划修正不关闭本项资源/药水/terminal合同。

### silent-proposal-ce75cb821e8f2610

证据局：LYBHQ1X230ZB；账本：silent-0012,silent-0005,silent-0013,silent-0077,silent-0049,silent-0232；来源：experience-update → strategy-proposal。

LYB F29T3步法+、暗影后两防御共32，F30首次防御16对20仍死、柔嫩逐牌属性变化均核实；尚缺当前完整组合与次轮复原/首挡消费的同帧回放以及未观察叠加/自动出牌的条件数据，局部代码存在不替代整项消费者验收。

### silent-proposal-6ba977a3f01df016

证据局：LYBHQ1X230ZB；账本：silent-0039,silent-0115,silent-0007；来源：experience-update → strategy-proposal。

LYB F23T1爆发重放迷雾两次各6毒、F30召21血幻象及末次结15毒已核实；四次同序重打0赢，前三被截断不计已毒伤。缺替代抽序/目标序的完整执行和当前召唤/重放/SL整线对照，未知复活与航行未在本局观察，不改SL触发。

## 保留边界

原十份提案字节副本及其SHA已核，无新代码提案id，无重写历史复盘/经验库，无 shipped 登记。随机施毒已核实旧伪斩杀反例，未将最高HP、平均分配或忽略全部毒包装成保证。对存活/留药/路线/terminal的未走反事实均保留未知。

开工按任务读取fix-queue前段时遇到非本角色历史文本；这些片段未用于本批游戏结论、参数、夹具或提案，后续证据按四个显式局号筛选并核SILENT角色。

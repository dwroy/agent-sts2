# 静默猎手策略批次报告

本批完成一项源码实现并实际合入live，其他九项逐项waiting。正式release_id和账本shipped由primary ops核实登记；本报告不声明自然对局收益或大脑自然采用。

## 身份与提交

- 批次：20261015-051302-s2-strategy-proposal；角色silent；普通队列的十proposal_ids，无research_request/implementation_request。
- 完整基线：`0052edea183041950e5d16356a0040925f1b39cc`；开工干净，merge main已最新；最终本树HEAD=`8e196be494ada9a33dac3d897a0671a5b14e0e5b`且干净。
- 源码：`8e196be494ada9a33dac3d897a0671a5b14e0e5b`；实际行为合入：`ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15`；上线记录：`e61c5667859e0ca236eea031818976fabfad02bf`；刷新数据提交8fc8978a7310df4aeec8ef1b9ac015cef189169c及后续并行刷新保留。
- eval内部登记：`V5.silent-escape-plan1`；release_status=awaiting-primary-ops-numbering，未由学习者占用R号。21个原账本仅经root ledger CLI追加追溯，silent-0296状态proposed；其他原状态/claim/首证/prior/证据与独立样本数保留。

## 实现、实盘与反例

原silent-proposal-0337a5f076c49d02/silent-0296：LRN0HPZ0FZS1 A0 F48T3以及LYBHQ1X230ZB A10 F30四试T1都有0费可打却结束的逃脱计划。T082DRCUHRRD A0 F17T12的s212038→212039抽入呼唤，挡4→4；F19T1的s212055→212056抽入防御，挡0→3。两种条件转移同属一局；另两局支持候选遗漏，不能称它们已实际施放获益。四次SL不扩为四独立局。

旧模型只读Cards变量而漏固定抽1，并把Block当无条件。现在仅silent A0/A10已观察的普通未升级0费Self/原模板、Block基础3及显示3/5/12接线抽1；已知或样本抽入技能才兑现显示挡，已知非技能不获条件挡。未知抽入牌不预支挡、停止虚拟后继牌并不认证必胜；实际抽牌后再规划，题面标条件参考。不强制永远出该牌，不改药水价值、SL门槛/次数或终局权重。

升级、其他进阶/模板、满手/空堆/封抽/自动与重放及部分修正组合缺本批受控实证，保留未知边界；其他角色保持原路径。回退仅由ops在live锁内git revert本源码提交并验证，保留刷新知识、原日志、账本与并行记录。

## 验证与失败历史

- 最终8项固定测试：实际帧两种抽牌、已知/样本类型、未知不预支条件挡、0能量候选、非技能不消费首次挡标记、未知不得虚拟后继/认证毒胜、其他角色/未观察边界、真实planCombatTurn到solver的消费。
- 最终四源码撤掉：exit1，6失败/2通过；恢复：exit0，8通过。原日志escape-v2-withdrawn.log、escape-v2-restored.log完整保留；初稿的5失败/恢复7通过原件也保留。
- 源bash tools/test-sandbox.sh：tsc0，409文件3939项加paths1文件11项，共410文件3950项全通过。
- 合后同入口：tsc0，410文件3940项加paths1文件11项，共411文件3951项全通过。这是固定排除名单的沙箱检查，调度器的host完整检查另验。
- 初稿单worker超过20分钟无汇总被定向中断exit130；重跑旧中间稿因发现未知后继边界需补修而中断130。两次都不是被冒报为断言失败或成功，原log/control保留。最终稿/合后入口均0。
- staged最终源码patch及上线记录patch的gitleaks均0；git diff/check及实际live源码/行为/记录祖先核均通过。

## 证据与不足

共用extract_evidence.py按四个显式局号抽取7流，6342行；四runs记录全部SILENT，LRN/T082 A0、G8/LYB A10。每流source_size、逐行offset/bytes/SHA、计数与产物SHA保存，各原行seek复算及显式身份全部通过；run-plans按run选到24行，没有正文命中或零行缺失推断。states/decisions各2条及brain1条不可解析行计数保留，不伪造它们的所属局或后继帧。

G8 F24末试T5随机三份毒各给幼虫，母体29/20毒不变，结算余9血而玩家死；当前机制隔离仍给winsFight=true，见random-poison-current.json。此旧缺口未由逃脱计划修复，不把最高HP或平均分配当保证，也不称有替代获胜。G8 F23实际52→22用尽两药后F24以22空药进入；巨兽本体T14结束后T15仍有56弱至42自爆，9挡/34→1；SL恢复与治疗/新药分账。LYB F29T6两候选损18/伤31/8样本全赢对损12/伤22/7样本赢，只前者实打；另一候选接续F30及6额外血能否过关未知。完整原dirty树、被截断结算、未走路线/留药/休息或目标序反事实未补造，不拟合新权重。

## 十项处置

### silent-proposal-982c99080350f43e

来源postmortem → strategy-proposal；证据局G8NHLL09DLBX；账本silent-0295。

waiting：G8 F24末试T5的三份毒各给幼虫已证明旧最高HP分配是假保证；当前randomVictim仍复用。缺当前完整候选在全部合法毒分配、爪牙退场/制品/重放组合下的固定校准与消费对照，不能用本次修正逃脱计划代替施毒修复。

### silent-proposal-aaefd918a706de14

来源postmortem → strategy-proposal；证据局G8NHLL09DLBX；账本silent-0019,silent-0017,silent-0005,silent-0046,silent-0253,silent-0007,silent-0021。

waiting：G8 F23T2速度后9挡/全轮损21、F17末试T15自爆56弱至42/净损33及SL恢复均已核实。原运行dirty源码缺失；尚无本批固定整场回放把临时属性撤回、自爆阶段、SL资源恢复全部接到当前消费者，亦无保药替代整场结果，维持原规则。

### silent-proposal-eb6e17529c0f8cde

来源experience-update → strategy-proposal；证据局G8NHLL09DLBX；账本silent-0007,silent-0295。

waiting：与982c99080350f43e共用silent-0295反例，但当前随机毒分配缺口仍在，未提供所有可达分配的安全保证或不确定候选在rollout/SL/自动执行的完整消费验证；不能把经验发布或逃脱计划代码称为该项实现。

### silent-proposal-10c5c87568dcded1

来源experience-update → strategy-proposal；证据局G8NHLL09DLBX；账本silent-0012,silent-0005,silent-0046,silent-0253。

waiting：步法/尖啸/速度/弱化自爆/荆棘已有局部模型，原帧证实数值；缺同一冻结输入对五机制组合及速度/尖啸次轮撤回的当前整线消费回放，无法为整项绑定已验证live源码；不据败局拟合饮药/留药门槛。

### silent-proposal-72e211c844b4564e

来源experience-update → strategy-proposal；证据局G8NHLL09DLBX；账本silent-0017。

waiting：G8 F17末试本体T14结束、T15仍须自爆，已核实；旧dirty树和前三试被判死截断后的结算缺失，换线、抽牌、药时点同变。缺当前完整阶段/判官/SL恢复的配对验证，不从13条探索拟合新读档权重。

### silent-proposal-1481fe327a22ddeb

来源experience-update → strategy-proposal；证据局G8NHLL09DLBX；账本silent-0243,silent-0020,silent-0019,silent-0021。

waiting：G8 F23实际52→22、两药用完后F24以22空药进场已核实；SL恢复与回血分账。缺不喝药、另一候选/路线的完整执行结果，F25及之后未抵达；无法标定持有价值、路线血线或证明替代可活。

### silent-proposal-0337a5f076c49d02

来源postmortem → strategy-proposal；证据局LRN0HPZ0FZS1,T082DRCUHRRD,LYBHQ1X230ZB；账本silent-0296。

implemented：普通A0/A10固定抽1、抽入技能条件挡、未知抽牌停止后续与不认证必胜已实作；实际live祖先源码核实，源3950/live3951沙箱固定项通过。未观察升级/进阶/模板不扩展，不称本局实际转胜。

### silent-proposal-8e9beeee55eac364

来源postmortem → strategy-proposal；证据局LYBHQ1X230ZB；账本silent-0019,silent-0039,silent-0005,silent-0013,silent-0077,silent-0196,silent-0128,silent-0049,silent-0232,silent-0115,silent-0007,silent-0142。

waiting：LYB F29T6两候选原题已核：损18/伤31/8样本全赢对损12/伤22/7样本赢；只有前者实打。缺后者接续F30的实盘结局及独立按局/时间切分数据，不能从6血差拟合终局权重或断言能赢F30。逃脱计划修正不关闭本项资源/药水/terminal合同。

### silent-proposal-ce75cb821e8f2610

来源experience-update → strategy-proposal；证据局LYBHQ1X230ZB；账本silent-0012,silent-0005,silent-0013,silent-0077,silent-0049,silent-0232。

waiting：LYB F29T3步法+、暗影后两防御共32，F30首次防御16对20仍死、柔嫩逐牌属性变化均核实；尚缺当前完整组合与次轮复原/首挡消费的同帧回放以及未观察叠加/自动出牌的条件数据，局部代码存在不替代整项消费者验收。

### silent-proposal-6ba977a3f01df016

来源experience-update → strategy-proposal；证据局LYBHQ1X230ZB；账本silent-0039,silent-0115,silent-0007。

waiting：LYB F23T1爆发重放迷雾两次各6毒、F30召21血幻象及末次结15毒已核实；四次同序重打0赢，前三被截断不计已毒伤。缺替代抽序/目标序的完整执行和当前召唤/重放/SL整线对照，未知复活与航行未在本局观察，不改SL触发。

## 上线与通知读回

最初main/live记录预检冲突exit1完整保留；后来live并行整合既有历史，精确源码/live预检exit0，锁内保留知识刷新再实际合并，无覆盖并行记录。合后全绿，decision-log/eval记录已提交；登记脚本在06:12:48启动、等待并行live锁后写入，记录提交的Git时间为06:22:03，未将等待归为代码失败。

root notes/for-roy.md和ops/inbox-dev.md各追加2249原字节，同payload SHA已读回复核；旧/新规则、证据/账本/任务、预期影响、回退均具备。仅表示双通知落盘；ops/watcher/Roy实际读回/确认不代填，正式R号与shipped仍交primary ops。报告/批次不关闭经验入库、量化或自然消费者父要求。

源库未写新经验、未重复历史复盘、未新增重复代码提案id，未改其他角色知识/运维prompt/权限/模型、未推送/运行play或读取游戏二进制。首读fix-queue前段时遇到非本角色历史文本，该部分未用于本批结论、参数或夹具；之后均按四个角色核实的显式局号取证。

刷新提交8fc8978a7310df4aeec8ef1b9ac015cef189169c漏做单独前置gitleaks，提交后补扫130497字节diff退出0；原日志refresh-commit-gitleaks.log保留，不冒称其为前置扫描。源码和上线记录的前置扫描均为0。

## 交付JSON

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261015-051302-s2-strategy-proposal",
  "base": "0052edea183041950e5d16356a0040925f1b39cc",
  "runs": [
    "G8NHLL09DLBX",
    "LRN0HPZ0FZS1",
    "T082DRCUHRRD",
    "LYBHQ1X230ZB"
  ],
  "fixes": [
    {
      "proposal_id": "silent-proposal-0337a5f076c49d02",
      "ledger": [
        "silent-0296"
      ],
      "commit": "8e196be494ada9a33dac3d897a0671a5b14e0e5b",
      "source_parent": "0052edea183041950e5d16356a0040925f1b39cc",
      "summary": "普通逃脱计划固定抽1、技能条件格挡；未知抽牌后重规划，后续与必胜不预支。",
      "evidence": [
        {
          "run": "LRN0HPZ0FZS1",
          "floor": 48,
          "turn": 3
        },
        {
          "run": "T082DRCUHRRD",
          "floor": 17,
          "turn": 12
        },
        {
          "run": "T082DRCUHRRD",
          "floor": 19,
          "turn": 1
        },
        {
          "run": "LYBHQ1X230ZB",
          "floor": 30,
          "turn": 1
        }
      ],
      "withdrawn": {
        "exit": 1,
        "failed": 6,
        "passed": 2
      },
      "restored": {
        "exit": 0,
        "passed": 8
      }
    }
  ],
  "skipped": [
    {
      "id": "silent-proposal-982c99080350f43e",
      "reason": "G8 F24末试T5的三份毒各给幼虫已证明旧最高HP分配是假保证；当前randomVictim仍复用。缺当前完整候选在全部合法毒分配、爪牙退场/制品/重放组合下的固定校准与消费对照，不能用本次修正逃脱计划代替施毒修复。"
    },
    {
      "id": "silent-proposal-aaefd918a706de14",
      "reason": "G8 F23T2速度后9挡/全轮损21、F17末试T15自爆56弱至42/净损33及SL恢复均已核实。原运行dirty源码缺失；尚无本批固定整场回放把临时属性撤回、自爆阶段、SL资源恢复全部接到当前消费者，亦无保药替代整场结果，维持原规则。"
    },
    {
      "id": "silent-proposal-eb6e17529c0f8cde",
      "reason": "与982c99080350f43e共用silent-0295反例，但当前随机毒分配缺口仍在，未提供所有可达分配的安全保证或不确定候选在rollout/SL/自动执行的完整消费验证；不能把经验发布或逃脱计划代码称为该项实现。"
    },
    {
      "id": "silent-proposal-10c5c87568dcded1",
      "reason": "步法/尖啸/速度/弱化自爆/荆棘已有局部模型，原帧证实数值；缺同一冻结输入对五机制组合及速度/尖啸次轮撤回的当前整线消费回放，无法为整项绑定已验证live源码；不据败局拟合饮药/留药门槛。"
    },
    {
      "id": "silent-proposal-72e211c844b4564e",
      "reason": "G8 F17末试本体T14结束、T15仍须自爆，已核实；旧dirty树和前三试被判死截断后的结算缺失，换线、抽牌、药时点同变。缺当前完整阶段/判官/SL恢复的配对验证，不从13条探索拟合新读档权重。"
    },
    {
      "id": "silent-proposal-1481fe327a22ddeb",
      "reason": "G8 F23实际52→22、两药用完后F24以22空药进场已核实；SL恢复与回血分账。缺不喝药、另一候选/路线的完整执行结果，F25及之后未抵达；无法标定持有价值、路线血线或证明替代可活。"
    },
    {
      "id": "silent-proposal-8e9beeee55eac364",
      "reason": "LYB F29T6两候选原题已核：损18/伤31/8样本全赢对损12/伤22/7样本赢；只有前者实打。缺后者接续F30的实盘结局及独立按局/时间切分数据，不能从6血差拟合终局权重或断言能赢F30。逃脱计划修正不关闭本项资源/药水/terminal合同。"
    },
    {
      "id": "silent-proposal-ce75cb821e8f2610",
      "reason": "LYB F29T3步法+、暗影后两防御共32，F30首次防御16对20仍死、柔嫩逐牌属性变化均核实；尚缺当前完整组合与次轮复原/首挡消费的同帧回放以及未观察叠加/自动出牌的条件数据，局部代码存在不替代整项消费者验收。"
    },
    {
      "id": "silent-proposal-6ba977a3f01df016",
      "reason": "LYB F23T1爆发重放迷雾两次各6毒、F30召21血幻象及末次结15毒已核实；四次同序重打0赢，前三被截断不计已毒伤。缺替代抽序/目标序的完整执行和当前召唤/重放/SL整线对照，未知复活与航行未在本局观察，不改SL触发。"
    }
  ],
  "merged": "ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15",
  "publication_commit": "e61c5667859e0ca236eea031818976fabfad02bf",
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 3951
  },
  "source_tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 3950
  },
  "code_proposals": [
    "silent-proposal-982c99080350f43e",
    "silent-proposal-aaefd918a706de14",
    "silent-proposal-eb6e17529c0f8cde",
    "silent-proposal-10c5c87568dcded1",
    "silent-proposal-72e211c844b4564e",
    "silent-proposal-1481fe327a22ddeb",
    "silent-proposal-0337a5f076c49d02",
    "silent-proposal-8e9beeee55eac364",
    "silent-proposal-ce75cb821e8f2610",
    "silent-proposal-6ba977a3f01df016"
  ],
  "implementation_domains": [
    "combat",
    "sl"
  ],
  "proposal_results": [
    {
      "id": "silent-proposal-982c99080350f43e",
      "state": "waiting",
      "reason": "G8 F24末试T5的三份毒各给幼虫已证明旧最高HP分配是假保证；当前randomVictim仍复用。缺当前完整候选在全部合法毒分配、爪牙退场/制品/重放组合下的固定校准与消费对照，不能用本次修正逃脱计划代替施毒修复。"
    },
    {
      "id": "silent-proposal-aaefd918a706de14",
      "state": "waiting",
      "reason": "G8 F23T2速度后9挡/全轮损21、F17末试T15自爆56弱至42/净损33及SL恢复均已核实。原运行dirty源码缺失；尚无本批固定整场回放把临时属性撤回、自爆阶段、SL资源恢复全部接到当前消费者，亦无保药替代整场结果，维持原规则。"
    },
    {
      "id": "silent-proposal-eb6e17529c0f8cde",
      "state": "waiting",
      "reason": "与982c99080350f43e共用silent-0295反例，但当前随机毒分配缺口仍在，未提供所有可达分配的安全保证或不确定候选在rollout/SL/自动执行的完整消费验证；不能把经验发布或逃脱计划代码称为该项实现。"
    },
    {
      "id": "silent-proposal-10c5c87568dcded1",
      "state": "waiting",
      "reason": "步法/尖啸/速度/弱化自爆/荆棘已有局部模型，原帧证实数值；缺同一冻结输入对五机制组合及速度/尖啸次轮撤回的当前整线消费回放，无法为整项绑定已验证live源码；不据败局拟合饮药/留药门槛。"
    },
    {
      "id": "silent-proposal-72e211c844b4564e",
      "state": "waiting",
      "reason": "G8 F17末试本体T14结束、T15仍须自爆，已核实；旧dirty树和前三试被判死截断后的结算缺失，换线、抽牌、药时点同变。缺当前完整阶段/判官/SL恢复的配对验证，不从13条探索拟合新读档权重。"
    },
    {
      "id": "silent-proposal-1481fe327a22ddeb",
      "state": "waiting",
      "reason": "G8 F23实际52→22、两药用完后F24以22空药进场已核实；SL恢复与回血分账。缺不喝药、另一候选/路线的完整执行结果，F25及之后未抵达；无法标定持有价值、路线血线或证明替代可活。"
    },
    {
      "id": "silent-proposal-0337a5f076c49d02",
      "state": "implemented",
      "reason": "普通A0/A10固定抽1、抽入技能条件挡、未知抽牌停止后续与不认证必胜已实作；实际live祖先源码核实，源3950/live3951沙箱固定项通过。未观察升级/进阶/模板不扩展，不称本局实际转胜。",
      "commit": "8e196be494ada9a33dac3d897a0671a5b14e0e5b"
    },
    {
      "id": "silent-proposal-8e9beeee55eac364",
      "state": "waiting",
      "reason": "LYB F29T6两候选原题已核：损18/伤31/8样本全赢对损12/伤22/7样本赢；只有前者实打。缺后者接续F30的实盘结局及独立按局/时间切分数据，不能从6血差拟合终局权重或断言能赢F30。逃脱计划修正不关闭本项资源/药水/terminal合同。"
    },
    {
      "id": "silent-proposal-ce75cb821e8f2610",
      "state": "waiting",
      "reason": "LYB F29T3步法+、暗影后两防御共32，F30首次防御16对20仍死、柔嫩逐牌属性变化均核实；尚缺当前完整组合与次轮复原/首挡消费的同帧回放以及未观察叠加/自动出牌的条件数据，局部代码存在不替代整项消费者验收。"
    },
    {
      "id": "silent-proposal-6ba977a3f01df016",
      "state": "waiting",
      "reason": "LYB F23T1爆发重放迷雾两次各6毒、F30召21血幻象及末次结15毒已核实；四次同序重打0赢，前三被截断不计已毒伤。缺替代抽序/目标序的完整执行和当前召唤/重放/SL整线对照，未知复活与航行未在本局观察，不改SL触发。"
    }
  ],
  "release_id": null,
  "release_status": "awaiting-primary-ops-numbering",
  "version_name": "V5.silent-escape-plan1",
  "proposal": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-051302-s2/learner/runs/20261015-051308-01e4191f-d865-4ede-96cc-6135ca85542b-strategy-proposal/proposal.md",
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-051302-s2/learner/runs/20261015-051308-01e4191f-d865-4ede-96cc-6135ca85542b-strategy-proposal/report.md",
  "security": {
    "source_precommit": 0,
    "publication_precommit": 0,
    "refresh_postcommit": 0
  }
}
```

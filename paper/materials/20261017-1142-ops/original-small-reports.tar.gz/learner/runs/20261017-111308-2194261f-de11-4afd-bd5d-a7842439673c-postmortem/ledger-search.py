import subprocess,json,sys
for text in sys.argv[1:]:
 p=subprocess.run(['python3','learner/ledger.py','find','--character','silent','--text',text,'--json'],text=True,capture_output=True,check=True)
 rows=json.loads(p.stdout)
 print('\n关键词',text)
 for x in rows: print(x['id'],x['status'],x.get('version',''),x['claim'], '首证',x.get('first_run'))

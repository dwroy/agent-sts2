import json, pathlib
root=pathlib.Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261017-111308-2194261f-de11-4afd-bd5d-a7842439673c-postmortem'
runs=['DC32RW0A80V1','JKDUL0AL0TW6']
for name in ['decisions','run-plans','states','sl-attempts','brain','run-config']:
    src=root/'logs'/f'{name}.jsonl'
    if not src.exists(): continue
    dest={r:(out/f'{r}-{name}.jsonl').open('w') for r in runs}
    offsets=0; counts={r:0 for r in runs}
    with src.open('rb') as f:
        for num,line in enumerate(f,1):
            pos=offsets; offsets+=len(line)
            for r in runs:
                if r.encode() not in line: continue
                try: row=json.loads(line)
                except ValueError: continue
                actual=row.get('run_id',row.get('run'))
                if isinstance(actual,dict): actual=actual.get('run_id')
                if actual is None: actual=(row.get('state') or {}).get('run_id')
                if actual!=r: continue
                row['_source']={'file':name+'.jsonl','line':num,'offset':pos,'bytes':len(line)}
                dest[r].write(json.dumps(row,ensure_ascii=False)+'\n');counts[r]+=1
    for f in dest.values(): f.close()
    print(name,counts,flush=True)
# deepseek-reasoning has no run id; stream exact decision time windows.
windows={}
for r in runs:
    times=[]
    with (out/f'{r}-decisions.jsonl').open() as f:
        for ln in f: times.append(json.loads(ln)['ts'])
    windows[r]=(min(times),max(times))
dest={r:(out/f'{r}-deepseek-reasoning.jsonl').open('w') for r in runs}
counts={r:0 for r in runs}
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as f:
    offset=0
    for n,line in enumerate(f,1):
        pos=offset;offset+=len(line)
        # Only parse timestamp envelope; old dates outside both windows are skipped.
        if not any(a[:10].encode() in line[:200] for a,b in windows.values()): continue
        try: row=json.loads(line)
        except ValueError: continue
        ts=row.get('ts','')
        for r,(a,b) in windows.items():
            if a<=ts<=b:
                row['_source']={'file':'deepseek-reasoning.jsonl','line':n,'offset':pos,'bytes':len(line)}
                dest[r].write(json.dumps(row,ensure_ascii=False)+'\n');counts[r]+=1
for f in dest.values():f.close()
print('deepseek-reasoning',counts,'windows',windows,flush=True)

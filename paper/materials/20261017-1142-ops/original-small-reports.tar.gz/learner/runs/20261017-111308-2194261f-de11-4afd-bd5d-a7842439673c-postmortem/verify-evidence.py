import json,pathlib,hashlib,collections
p=pathlib.Path(__file__).parent
checks=[]
def check(name,actual,expected):
 if actual!=expected:raise AssertionError((name,actual,expected))
 checks.append({'核验':name,'实值':actual,'预期':expected})
for rid,expected in [('DC32RW0A80V1',(1216,1340,31,49,31,282,10,1,17,11,6,4)),('JKDUL0AL0TW6',(750,782,21,34,22,129,8,3,26,17,7,0))]:
 ds=[json.loads(l) for l in (p/f'{rid}-decisions.jsonl').open()];ss=[json.loads(l) for l in (p/f'{rid}-states.jsonl').open()];bs=[json.loads(l) for l in (p/f'{rid}-brain.jsonl').open()];rc=json.loads((p/f'{rid}-resources.json').read_text());gains=json.loads((p/f'{rid}-potion-gains.json').read_text())
 cs=[d for d in ds if d['decider']=='jev' and d['label'].startswith('combat/plan-choice')];counts=collections.Counter(d.get('rollout_best_chosen') for d in cs)
 actual=(len(ds),len(ss),len(rc['combats']),len(bs),sum(d['decider']=='jev' and d.get('confidence',1)<.35 for d in ds),counts[True],counts[False],counts[None],sum((d.get('chosen') or {}).get('action')=='use_potion' for d in ds),len(gains),sum(c['restart_boundary'] for c in rc['resource_changes']),sum(bool(d.get('hp_guard')) for d in ds))
 check(rid+'计数',list(actual),list(expected))
 check(rid+'角色帧',[str(s['state']['run']['character_id']).lower() for s in ss[:1]],['silent'])
 check(rid+'全部窗口T1',all(c['entry_is_turn_one'] for c in rc['combats']),True)
 end=rc['combats'][-1];byline={s['_source']['line']:s for s in ss};entry=end['entry'];last=byline[end['exit']['line']];co=last['state']['combat'];pre=byline[end['last']['line']]['state']['combat'];pl=pre['player'];enemy=pre['enemies'][0]
 held=sum(next((v.get('current_value',0) for v in c.get('dynamic_values',[]) if v.get('name')=='Damage'),0) for c in pre['hand'] if c['card_id']=='WITHER')
 incoming=sum(i.get('total_damage') or 0 for e in pre['enemies'] for i in e['intents']);loss=incoming+held-pl['block']
 check(rid+'末轮入口HP/挡/攻击/持牌/完整需损/敌余',[pl['current_hp'],pl['block'],incoming,held,loss,co['enemies'][0]['current_hp']],[3,49,41,36,28,246] if rid.startswith('DC') else [1,19,21,0,2,272])
 check(rid+'实际死亡HP',last['state']['run']['current_hp'],0)
 if rid.startswith('DC'):
  guard=[d['hp_guard'] for d in ds if d.get('hp_guard')];check('DC护栏候选省血',[a['predicted_hp_saved'] for a in guard],[5,12,9,9]);check('DC护栏候选伤差',[a['predicted_damage_change'] for a in guard],[-6,-9,-6,-2])
  poison=[]
  for n in [432435,432442,432449,432459,432467]:poison.append(next(q['amount'] for q in byline[n]['state']['combat']['enemies'][0]['powers'] if q['power_id']=='POISON_POWER'))
  check('DC末试已结毒',poison,[2,3,11,12,13])
 else:
  dd={d['_source']['line']:d for d in ds};check('JK第四/六试T5同指纹',dd[419230]['fingerprint']==dd[419291]['fingerprint'],True)
  check('JK中和原/替线T5净进度',[333-byline[433350]['state']['combat']['enemies'][0]['current_hp'],333-byline[433414]['state']['combat']['enemies'][0]['current_hp']],[38,34])
  check('JK末轮三牌懒惰锁',[(c['card_id'],c.get('unplayable_preventer_id')) for c in pre['hand']],[('POISONED_STAB','SLOTH_POWER'),('SHIV','SLOTH_POWER'),('SHIV','SLOTH_POWER')])
print('关键数字逐原帧核验通过，共',len(checks),'项')
(p/'evidence-validation.json').write_text(json.dumps({'结果':'通过','核验':checks},ensure_ascii=False,indent=2)+'\n')

import pathlib,json,hashlib
p=pathlib.Path(__file__).parent;root=pathlib.Path('/home/dw/Projects/agent-sts2')
old=json.loads((p/'lessons-before.json').read_text());h=hashlib.sha256();remaining=old['size']
with (root/'notes/lessons.md').open('rb') as f:
 while remaining:
  chunk=f.read(min(1048576,remaining));assert chunk;h.update(chunk);remaining-=len(chunk)
 tail=f.read()
assert h.hexdigest()==old['sha256'],'旧复盘前缀被改变'
for r in ['DC32RW0A80V1','JKDUL0AL0TW6']:
 draft=(p/f'{r}-draft.md').read_bytes();assert draft in tail,r+'实际追加与初稿不一致'
 assert tail.count(('## '+r).encode())==1,r+'标题重复'
 entries=json.loads((p/f'{r}-ledger-find.json').read_text());assert len(entries)>=3
 print(r,'复盘逐字一致，账本',[(e['id'],e['status'],e.get('version')) for e in entries])
counts={};binding_path=p/'input-bindings.jsonl'
with binding_path.open('w') as out:
 for r in ['DC32RW0A80V1','JKDUL0AL0TW6']:
  for name in ['decisions','states','run-plans','sl-attempts','brain','run-config']:
   n=0
   with (root/'logs'/f'{name}.jsonl').open('rb') as orig,(p/f'{r}-{name}.jsonl').open() as selected:
    for line in selected:
     row=json.loads(line);source=row.pop('_source');orig.seek(source['offset']);raw=orig.read(source['bytes']);assert len(raw)==source['bytes'] and json.loads(raw)==row,(r,name,source)
     out.write(json.dumps({'run':r,**source,'sha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False)+'\n');n+=1
   counts[r+':'+name]=n
summary={'旧前缀字节数':old['size'],'旧前缀SHA256':h.hexdigest(),'旧前缀未改':True,'两节逐字追加核验':True,'原日志逐行字节读回计数':counts,'原日志SHA绑定文件':str(binding_path),'勘误':'无；草稿毒伤与饮用次数在追加前已修正，不修改既有复盘。','账本首次CLI错误':'六次update仅给位置参数，缺JSON.id，CLI exit2且未写；随后带JSON.id一次校验追加六项成功。'}
(p/'written-validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (p/'early-analysis-failures.txt').open('a') as f:f.write('ledger.py update首轮6次：仅给位置id、stdin未含id，全部exit2 / id None has no add row before it，CLI明确nothing written。已保留原失败记录，修正JSON.id后六项一次验证追加成功。\n')
print('旧复盘前缀未改；抽取原日志共',sum(counts.values()),'行按offset/bytes/SHA读回一致。')

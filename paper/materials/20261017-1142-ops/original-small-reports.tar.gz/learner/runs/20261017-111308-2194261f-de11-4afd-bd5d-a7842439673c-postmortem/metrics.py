import json,pathlib,collections,re
p=pathlib.Path(__file__).parent
for rid in ['DC32RW0A80V1','JKDUL0AL0TW6']:
 ds=[json.loads(l) for l in (p/f'{rid}-decisions.jsonl').open()];ss=[json.loads(l) for l in (p/f'{rid}-states.jsonl').open()];bs=[json.loads(l) for l in (p/f'{rid}-brain.jsonl').open()]
 rc=json.loads((p/f'{rid}-resources.json').read_text());idx=collections.defaultdict(list)
 for s in ss:idx[s['fingerprint']].append(s)
 def before(d):
  candidates=[s for s in idx[d['fingerprint']] if s['ts']<=d['ts']]
  return max(candidates,key=lambda s:s['_source']['line']) if candidates else None
 with (p/f'{rid}-metrics.txt').open('w') as f:
  def w(*v):print(*v,file=f)
  w('CALLS',len(bs),collections.Counter((b.get('engine'),b.get('model'),b.get('effort')) for b in bs))
  w('BRAIN_USAGE',{k:sum(b.get('usage',{}).get(k,0) for b in bs) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']})
  w('JEV_USAGE',{k:sum(d.get('usage',{}).get(k,0) for d in ds if d['decider']=='jev') for k in ['input_tokens','output_tokens','cache_hit_tokens']})
  w('DECIDERS',collections.Counter('jev-plan' if d.get('rationale','').startswith('continuing the Jev-chosen plan:') else d['decider'] for d in ds))
  choices=[d for d in ds if d['decider']=='jev' and d['label'].startswith('combat/plan-choice')]
  w('CHOICES',len(choices),'rank1',sum('code rank 1' in d['rationale'] for d in choices),'ROLLOUT_FIELD',sum('rollout_best_chosen' in d for d in choices),'focus_questions',sum('focus' in d.get('questions',{}) for d in ds),'fallback',sum(bool(d.get('fallback')) for d in ds))
  w('POTIONS')
  for d in ds:
   if (d.get('chosen') or {}).get('action') in ['use_potion','discard_potion','buy_potion']:
    s=before(d);co=(s or {}).get('state',{}).get('combat') or {};slot=d['chosen'].get('option_index');pot=next((q for q in (s or {}).get('state',{}).get('run',{}).get('potions',[]) if q.get('index')==slot),{})
    w('d'+str(d['_source']['line']),d['floor'],'attempt',d.get('sl_attempt'),'T',d['turn'],d['chosen'],pot.get('name'),pot.get('potion_id'),d.get('result'))
  w('GAINS')
  for c in rc['resource_changes']:
   old,new=c['from'],c['to'];added=[q for q in new['potions'] if q not in old['potions']]
   if added:w('s'+str(new['line']),'F',new['floor'],'T',new['turn'],'gains',added,'restart',c['restart_boundary'],'ts',new['ts'])
  w('NONCOMBAT_HP')
  for c in rc['resource_changes']:
   a,b=c['from'],c['to']
   if c['combat_sequence'] is None and a['hp']!=b['hp']:w('s'+str(b['line']),'F',b['floor'],a['hp'],b['hp'],a['max_hp'],b['max_hp'],'restart',c['restart_boundary'],'ts',b['ts'])
  w('FINAL_TURNS_PRE_END')
  c=rc['combats'][-1]
  for d in ds:
   if d['ts']<c['entry']['ts'] or (d.get('chosen') or {}).get('action')!='end_turn':continue
   s=before(d);st=s['state'];co=st['combat'];en=co['enemies'][0]
   w('d'+str(d['_source']['line']),'s'+str(s['_source']['line']),'T',d['turn'],'hp',st['run']['current_hp'],'block',co['player']['block'],'inc',sum(i.get('total_damage') or 0 for e in co['enemies'] for i in e['intents']),'enemy',en['current_hp'],'held',[(q['card_id'],q.get('resolved_rules_text')) for q in co['hand'] if q['card_id']=='WITHER'])
 print(rid,'metrics written')

import json,pathlib,collections,datetime
p=pathlib.Path(__file__).parent
for rid in ['DC32RW0A80V1','JKDUL0AL0TW6']:
 def load(name):
  with (p/f'{rid}-{name}.jsonl').open() as f:return [json.loads(l) for l in f]
 ds=load('decisions');ss=load('states');bs=load('brain');sl=load('sl-attempts');ps=load('run-plans');cfg=load('run-config')
 rc=json.loads((p/f'{rid}-resources.json').read_text())
 with (p/f'{rid}-overview.txt').open('w') as f:
  def w(*v):print(*v,file=f)
  w('run',rid,'config',[(c['ts'],c['code']) for c in cfg])
  w('deciders',collections.Counter(d['decider'] for d in ds),'low',sum(d['decider']=='jev' and d.get('confidence',1)<.35 for d in ds))
  combat=[d for d in ds if d['screen']=='COMBAT'];turns={(d['floor'],d.get('sl_attempt'),d['turn']) for d in combat}
  w('combat action turns',len(turns),'code-containing',len({(d['floor'],d.get('sl_attempt'),d['turn']) for d in combat if d['decider']=='code'}),'code-only',sum(not any(d['decider'] in ['jev','jev-plan'] and (d['floor'],d.get('sl_attempt'),d['turn'])==t for d in combat) for t in turns))
  choices=[d for d in ds if d['decider']=='jev' and d['label'].startswith('combat/plan-choice')]
  w('choices',len(choices),'journalkeys',collections.Counter(k for d in choices for k in (d.get('journal') or {})))
  w('firstjournal',json.dumps(choices[0].get('journal'),ensure_ascii=False)[:5000])
  for d in ds:
   if d['decider']=='codex' or 'guard' in d.get('rationale','').lower() or d['label']=='selection/curse':
    w('d'+str(d['_source']['line']),d['floor'],d['turn'],d.get('sl_attempt'),d['label'],json.dumps(d.get('chosen'),ensure_ascii=False),d['rationale'])
  w('plans')
  for q in ps:w('p'+str(q['_source']['line']),q['floor'],q['trigger'],json.dumps(q['plan'],ensure_ascii=False))
  w('SL')
  for x in sl:w('sl'+str(x['_source']['line']),x['floor'],x['attempt'],x['result'],'T',x.get('turns'),'hp',x.get('end_hp'),'block',x.get('end_block'),'inc',x.get('incoming'),'start',x['started_at'],'end',x['ended_at'])
  w('TIMING',(datetime.datetime.fromisoformat(ds[-1]['ts'])-datetime.datetime.fromisoformat(ds[0]['ts'])).total_seconds())
  for key in ['usage','latency_ms']:w('brain'+key,([b.get(key) for b in bs][:2] if key=='usage' else sum(b.get(key,0) for b in bs)))
 with (p/f'{rid}-chain.txt').open('w') as f:
  for c in rc['combats']:
   ent=c['entry'];ext=c.get('exit') or c['last'];print('seq',c['sequence'],'F',c['floor'],','.join(c['enemies']),'T1',c['entry_is_turn_one'],'HP',f"{ent['hp']}/{ent['max_hp']}->{ext['hp']}/{ext['max_hp']}",'pot',ent['potions'],'->',ext['potions'],'end',c['end'],'s',ent['line'],ext['line'],'ts',ent['ts'],ext['ts'],file=f)
  print('CHANGES',file=f)
  for c in rc['resource_changes']:
   a,b=c['from'],c['to'];print('s',a['line'],b['line'],'F',a['floor'],b['floor'],'T',a['turn'],b['turn'],'seq',c['combat_sequence'],'restart',c['restart_boundary'],'hp',a['hp'],b['hp'],'max',a['max_hp'],b['max_hp'],'pot',a['potions'],'->',b['potions'],'ts',b['ts'],file=f)
 with (p/f'{rid}-combat.txt').open('w') as f:
  for c in rc['combats']:
   if c['floor'] not in ([17,33,39,44,45,46,48] if rid.startswith('DC') else [9,15,17,21,22,23,30,31,33]):continue
   print('\nSEQ',c['sequence'],'F',c['floor'],file=f)
   frames=[s for s in ss if c['entry']['line']<=s['_source']['line']<=(c.get('exit') or c['last'])['line']]
   groups={}
   for s in frames:
    if s['state'].get('in_combat'):groups.setdefault(s['state']['turn'],[]).append(s)
   for t,rows in groups.items():
    a,b=rows[0],rows[-1];r=a['state']['run'];state=b['state'];co=state.get('combat') or {};pl=co.get('player') or {}
    def enemies(s):return [(e.get('name'),e.get('enemy_id'),e.get('current_hp'),e.get('block'),e.get('intent'),e.get('powers')) for e in (s['state'].get('combat') or {}).get('enemies',[])]
    print('T',t,'s',a['_source']['line'],b['_source']['line'],'hp',r.get('current_hp'),'->',state['run'].get('current_hp'),'player',json.dumps(pl,ensure_ascii=False),'enemies_start',json.dumps(enemies(a),ensure_ascii=False),'enemies_end',json.dumps(enemies(b),ensure_ascii=False),file=f)
   for d in ds:
    if d['floor']==c['floor'] and c['entry']['ts']<=d['ts']<=(c.get('exit') or c['last'])['ts']:
     print('d'+str(d['_source']['line']),'T',d['turn'],d['decider'],d['label'],json.dumps(d.get('chosen'),ensure_ascii=False),'expect',json.dumps(d.get('expect'),ensure_ascii=False),'why',d['rationale'],'journal',json.dumps(d.get('journal'),ensure_ascii=False)[:1200],file=f)
 print(rid, 'written')

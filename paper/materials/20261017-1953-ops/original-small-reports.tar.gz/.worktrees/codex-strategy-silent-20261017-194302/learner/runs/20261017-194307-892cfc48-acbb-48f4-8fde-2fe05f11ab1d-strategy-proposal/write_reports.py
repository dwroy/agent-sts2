import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
SNAPSHOT = json.loads((OUT / 'dispatch-and-proposals.json').read_text())
IDS = SNAPSHOT['dispatch']['proposal_ids']

DETAILS = [
    {
        'reason': '八组件的联合生产消费者校准仍缺；RC61局部敏捷、柔嫩和折扇帧不足覆盖脆弱、倍率及首刀全部组合，不能整包duplicate。',
        'location': 'RC61MFQM63Y6 A10 F17 T2/T11、F23 T3/T4、F29 T3/T4、F33六试T1/T4',
        'finding': 'F23 T3预判后净敏1，速度药后6；斗篷12挡、防御9挡；第三次攻击零直伤仍得到折扇4挡。次轮临时属性归零。',
        'counter': '缺脆弱、倍率、首刀与上述逐牌减属性的共同输入校准；战败不能反推局部机制错误。',
        'verification': '未来实现须将同一手牌的每次出牌、目标、临时属性、第一张触发消费及被动挡逐源送入生产候选和后继模型；未见组合保持未知。',
    },
    {
        'reason': '单层幽灵已有实际live祖先源码，但夜魇合法复制后的存活兑现和延后饮药的受控整战后继仍缺，不能关闭整项存活与时点提案。',
        'location': 'XTSV1U9JD34T A10 F49 T1、末试T3/T4及第2/4次SL',
        'finding': 'T1幽灵新增无实体1，16挡下保23血，次轮留10挡；末T3实损22，T4只1血、6挡，夜魇标记3而未到次轮便死亡。',
        'counter': '早喝有本轮实际价值；替换T3攻击或T4多挡的已执行尝试也未存活，无晚喝胜线，不能规定延后饮用或禁用夜魇。',
        'verification': '复制必须追到合法选牌、次轮到手和实际存活；药水时点需固定抽序和后继动作的对照，不由一局六次相关SL拟药价。',
    },
    {
        'reason': '普通单弃和限定毒胜保血已有实际live源码；接管内部动作、夜魇后继及跨抽弃牌的完整候选执行归属仍未齐，整项继续waiting。',
        'location': 'BTSRF7JL1W1Y A10 F17四试、F30/F31 T2；XTSV1U9JD34T A10 F33、F48 T8、F49六试',
        'finding': 'B F31 T2生存者后唯一后继被强制弃掉；X F48 T8毒胜仍先付9持牌伤，32→23后无恢复入F49。',
        'counter': '已有单弃子修复和保血搜索子修复不能覆盖接管未记录的内部动作；多打一张合法防御的模型改善不证明下一Boss可胜。',
        'verification': '联合固定回放应把每次弃牌、抽牌、生成和重问后的真实手牌映射到实际已执行候选；不预支接管或复制收益。',
    },
    {
        'reason': '赢战血价和SL分段可追溯，但缺逐来源路线/休息消费者校准及同条件改线、留药、锻造完整后继与独立留出，不拟安全血线或药价。',
        'location': 'BTSRF7JL1W1Y A10 F17四试、F30/F31；XTSV1U9JD34T A10 F47、F48 T8→F49',
        'finding': 'B F30胜战70→42，F31实到42；X F47到97，F48胜后23、直接23入连战，不能把赢战算零血价。',
        'counter': 'SL恢复不是实际回血或新增药水；没有改线、留药、锻造的受控后继，实际资源链不能独立确定安全门槛。',
        'verification': '未来实现按来源对齐进战HP、到火回复、休息动作回复、赢战消耗与SL恢复，再读回路线/休息题面；因果结论须额外对照。',
    },
    {
        'reason': '局部覆甲、留挡和临时减力可核；毒触发、属性撤回、留挡上限及敌成长仍缺共同输入下的逐源联合消费者回放，不能认证整包或新药价。',
        'location': 'BTSRF7JL1W1Y A10 F17 T5、F31 T2/末轮；XTSV1U9JD34T A10 F48 T8、F49 T1—T4',
        'finding': 'X F49末T3已建敏捷不补旧挡，T4脆弱防御6，尖啸后威胁16，1血仍致死；幽灵后富余挡由钳子最多留10，后续只留5。',
        'counter': '开场层数不能作整场固定挡；临时减力没有关闭后续成长；截断的毒结算不能当未截断伤害账。',
        'verification': '按牌/被动/留挡/临时属性分别核每步和下一玩家轮，再将同一输入送入完整生产消费者，不以经验文本已加载代替源码验证。',
    },
    {
        'reason': '倍率挡、复活及毒结算局部帧可核；未截断逐击毛伤、完整候选执行归属和同条件整战后继仍缺，不用局部净差校准联合模型或修改SL血价。',
        'location': '9Z9H2EXKLF3T A10 F35；F48三试，重点末试T7/T8/T10/T11',
        'finding': '末T8首挡32仍死亡后复活20；T10挡37仍损15；T11敌112→32、毒39→37。实际净血差不能全归毒或逐击毛伤。',
        'counter': 'T7预测替线多损7/多伤16，实际后继还改变了重规划与药水时点；同盘局部净差不能单因归给替线或认整战胜因。',
        'verification': '逐击事件、状态伤、复活消费、被截断结算、SL恢复和持有药分账；替线比较必须固定后续条件，缺毛伤原件保持未知。',
    },
    {
        'reason': '跨幕限定公式有实帧支持；原116局完整资源模型输入、路线/休息生产消费者校准及独立路线收益仍未交齐，窄公式不关闭资源/SL宽提案。',
        'location': '原十局HMVJKM56S4Q8、F4QKG4J1AJJZ、G403VCZ3BH1B、25226ZFLNR1J、JLN5SK17W4FQ、JMH5C51RLN4E、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、9Z9H2EXKLF3T的F17→18/F33→34；9Z F35/F38/F39/F42/F45/F47/F48',
        'finding': '只在上限相同的已观察跨幕端点检验floor(缺血×80%)；9Z的生命上限下降、营火实际到达及两次SL恢复分别核对。',
        'counter': '路线预测条件、上限和实际后续动作不全相同；原116局不是本批15局，不能冒称全史资源模型或独立路线收益已验证。',
        'verification': '跨幕对按角色/进阶/同上限核对；整项还需原冻结资源输入、路线/休息实际消费者读回和时间留出，不调未知交互或新阈值。',
    },
    {
        'reason': '7X0后段零毒单次实加7；observedPoison仍为各候选目标共用标量，本盘前段另有8毒，其他目标、叠毒、重接组合及持有价/用药时点证据不足，不能统一赋7。',
        'location': '7X0W3U8TVA2A A10 F31 T1—T13，尤其T13 states288470→288471→288472、decisions282021',
        'finding': '毒药水给零毒后段加7，施放当步敌25血、玩家1血不变；结算后段18、玩家0；同时前段已有8毒。',
        'counter': '已喝仍败，反驳该轮有7毒足够救场；只有后段一次实饮，不能拆出基础药效或将7应用所有候选目标，更不能拟早喝收益。',
        'verification': '未来入口必须保留目标、遗物、已有毒和增益条件；固定后段25→18、未知目标回原未模拟分支，持有价未知与真实零区分。',
    },
    {
        'reason': '同盘多损8血/多伤6已核，SL差值审计已有实际live源码；缺独立A10留出与固定抽弃/药时点的完整后继，不能拟饱和探索HP门槛、权重或药价。',
        'location': 'MTQ0EUBJ3R6T A10 F23四次T3、末次T5；F19/F20→F23资源链',
        'finding': '原线29挡零损，替线19挡损8、即时多伤6；速度已在当轮兑现，下一轮药层撤回；末T5两毒素已逐张付能离手。',
        'counter': '四次是同一相关局；原线和替线均无整战胜线，后继抽牌、毒雾建立与时点同时变化，不能把末轮敌残差单独归一张打击。',
        'verification': '固定原问题、实际执行线与完整后继；即时HP缺口、预测与实扣分别列，未来独立同阶局作留出，不把24/24有限败样本认实盘必死。',
    },
    {
        'reason': '十四项已有局部观察和若干源码组件，仍缺完整联合生产消费者校准及部分能力、昏眩、临时属性后继，经验入库不等于整包源码兑现。',
        'location': '7X0W3U8TVA2A A10 F31 T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T A10 F11 T1、F17 T4—T8、F20 T3、F23四试T2—T5',
        'finding': 'MTQ F23速度临时敏捷经后继牌兑现；7X0 F31步法不补旧挡，头骨组合施毒与即时本体伤分账，未建立能力不计收益。',
        'counter': '能力未出不能认其整战收益或无价值；没有完整毛伤和受控替代后继，不从机制局部观察推出固定出牌/留药规则。',
        'verification': '逐项固定状态后，核它们在同一真实题面的共同消费、抽弃/昏眩合法性和下一轮撤回；未知交互保持原行为，独立对照另验收益。',
    },
]


def write():
    stamp = (OUT / 'report-time.txt').read_text().strip()
    validation = json.loads((OUT / 'material-validation.json').read_text())
    source = json.loads((OUT / 'source-audit.json').read_text())
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    pairs = json.loads((OUT / 'act-transition-pairs.json').read_text())
    audit = json.loads((OUT / 'ledger-readback-audit.json').read_text())
    assert len(DETAILS) == len(IDS) == 10
    assert not validation['failed_cases'] and not validation['physical_failures']
    assert audit['passed']
    results = [{'id': ident, 'state': 'waiting', 'reason': d['reason']} for ident, d in zip(IDS, DETAILS)]
    result = {
        'task': 'strategy-proposal', 'character': 'silent', 'batch': SNAPSHOT['batch'],
        'base': SNAPSHOT['base'], 'runs': SNAPSHOT['dispatch']['runs'], 'fixes': [], 'skipped': [],
        'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
        'code_proposals': IDS, 'implementation_domains': [], 'proposal_results': results,
        'report': str(OUT / 'report.md'),
    }
    p = [f'# 静默猎手策略提案逐项核验\n\n时间：{stamp}；批次：{SNAPSHOT["batch"]}。\n',
         '本批10项均waiting；未发现由本批证据充分支持且尚未实现的新策略差量。旧行为保持，未实现、不整项duplicate、不上线，不关闭学习父要求。\n',
         f'基线：`{SNAPSHOT["base"]}`。首次状态干净，普通批按要求合main返回Already up to date；只处理派发10个id。普通专题请求绑定另一批，不读取其冻结专题正文；无research_request、implementation_request或proposal_repair。\n',
         '证据来自本批10个派发锚点及原提案明确引用的另5局；runs.jsonl逐局角色核对为SILENT，3局A9、12局A10。15个运行code均带dirty，不用当前源码冒充原局完整树。每项原提案副本保留原字节并匹配登记SHA；账本首证、历史、状态及版本保留。\n']
    for ident, d in zip(IDS, DETAILS):
        old = SNAPSHOT['adds'][ident]
        p += [f'## {ident}\n\n{old["summary"]}\n',
              f'证据：{d["location"]}。账本：{",".join(old["ledger"])}。\n',
              f'支持：{d["finding"]}\n\n反例/未知：{d["counter"]}\n',
              '旧规则/拟议行为：以原提案保存的旧行为和有界实现候选为准，本批不增加机制、时点规则或参数；保留现有生产行为。原文见同目录对应`*.original.md`。\n',
              f'验证：{d["verification"]}\n',
              '样本/切分：本局SL按一个相关局处理，当前核验是回溯验证而非独立留出，不拟新参数；未来同角色同阶独立完局再作时间留出。预期仅为证据和消费者范围可追溯；没有已证胜率提升。未改源码，无本批回退补丁。\n',
              f'处置：**waiting**。{d["reason"]}\n']
    p += ['## 现有窄实现\n\n以下源码均已核为实际live祖先，只认证所列子功能，不能代替任一宽提案整项完成。\n']
    for a in source['narrow_anchors']:
        p.append(f'- {a["scope"]}：`{a["commit"]}`。\n')
    p += ['\n来源任务和实现任务沿原10提案保留；未登记重复新id。所有待定项的具体补证条件见各项验证与waiting理由。\n']
    (OUT / 'proposal.md').write_text('\n'.join(p))
    rows = '\n'.join(f'|{m["stream"]}|{m["source_size"]}|{sum(m["counts"].values())}|{m["invalid_lines"]}|{m["incomplete_lines"]}|' for m in manifest)
    transitions = {a: sum(x['ascension'] == a for x in pairs) for a in (9, 10)}
    r = f'''# 静默策略提案批次报告

时间：{stamp}；批次：{SNAPSHOT['batch']}。

10项均waiting。没有由本批已核证据支持的新增策略源码差量；保持现有行为，fixes=[]、merged=null，无源码提交、游戏版本或上线。逐项证据、层/回合、账本、反例、预期行为及补证要求见[proposal.md](proposal.md)，机械结果见[result.json](result.json)。

## 身份与基线

首次git status --short为空；HEAD及report.base为`{SNAPSHOT['base']}`，git merge --no-edit main返回Already up to date。对应learn.json行task=strategy-proposal、character=silent、reason=proposal、工作树及10个proposal_ids匹配；无research_request/implementation_request/proposal_repair。本批不是已授权专题，普通专题请求绑定另一旧批，未借用其work_spec/manifest、未改请求/learn.json。dispatch-and-proposals.json保留本批派发行、10原提案及其最新处置；只处理本批ID。

十份原Markdown全部匹配登记SHA，副本完整保留。关联46条既有本角色账本和41条本角色经验，经验只读，不从知识文本存在推断生产消费完成。额外5局7X0W3U8TVA2A、MTQ0EUBJ3R6T、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0都在原提案的明确证据内；没有扩展其他提案、角色或专题。

## 原始日志与核验

按指定共用extract_evidence.py一次抽取15局8流，使用run/run_id/state.run_id/fingerprint.run显式归属，冲突不收；不按正文提及取局。runs记录全为SILENT：A9三局，A10十二局。所有记录的code带dirty，不能恢复历史完整源码或把当前V5-R387当历史局版本。

|流|冻结source_size字节|本批入选行|坏JSON行|不完整行|
|---|---:|---:|---:|---:|
{rows}

每条封套含source、line、offset、bytes、SHA256及所属局；evidence-manifest.json另含逐局计数、冻结截点和输出SHA。坏JSON行归属未知；fight-plans该截点选中0行不代表原日志缺失。未复核旧source-size截点，不覆盖旧报告或零行初稿。

复用本角色原124302-s2批的两个只读材料分析脚本（逐SHA记录），对本批新抽取输入重新执行；没有借用旧分析结果或旧测试绿。分析覆盖11008状态。跨幕共有{len(pairs)}对同上限端点，A9 {transitions[9]}对、A10 {transitions[10]}对，逐对匹配原限定floor(缺血×80%)；不是原116局完整资源模型或其他条件公式证明。resource-chains按重打保留各片段，不称独立样本；净HP差不当毛伤，药栏变化不单凭状态判饮用。

verify_material.py退出0：{validation['case_count']}项材料断言、{validation['physical_count']}条原始引用按offset/bytes/SHA与显式身份独立读回通过。覆盖RC61柔嫩/临时敏捷/折扇，BTS单弃，XTS幽灵/毒胜连战/夜魇未兑现，7X0后段加7毒仍败，MTQ同盘29挡零损对19挡损8及末轮毒素离手，9Z倍率/复活/毒结算和跨幕端点。这是材料一致性核验，不是生产消费者、策略收益、tsc或vitest认证。

## 当前源码边界与结论

实际live只读快照为`{source['live_snapshot']}`。source-audit.json对16个相关叶保存base/live blob和SHA；11个字节相同，5个只有历史Roy/Dai署名注释不同；差异保存在base-to-live-audited-leaves.patch。5个窄实现源码commit均为base和实际live祖先，分别是幽灵、限定毒胜保血、普通单弃、SL差值审计、未知持有价可见性。不是全live树等价、原dirty树或完整生产联合校准。

现有observedPoison仍是候选目标共用标量，原7X0末轮仅验证后段零毒实加7，前段另有8毒；不能将7无条件送入全场目标、叠毒、重接或持有价规则。幽灵T1有实兑现，延后整战收益未知；夜魇末T4未活到复制不能单独推出禁用或可避死。MTQ多损8/多伤6只是一局相关SL比较，不能据24/24有限败样本拟新血线。共同缺口是完整共同输入消费、执行归属、后继与受控/独立留出，而不是缺少预训练补充的游戏规则。

本批没有发现新的机制反证或与原限定知识冲突，未产生重复科学异议通知，不代其他角色ACK；全部宽父和待证条件保留。

## 记录与验证范围

根账本仅经ledger.py update追加{audit['update_count']}条where/note追溯，by=learner:strategy-proposal；旧物理前缀及46条记录保护字段读回保持，见ledger-readback-audit.json。未写新claim/evidence、未新增支持计数、未改status/version/effect/首证/prior或shipped；已shipped的窄经验不降为proposed。既有10提案ID直接交回，不另建重复id、不手改专用队列；调度器按proposal_results登记本批waiting。

无生产源码修改，不做撤源码红/恢复绿，不运行生产tsc/vitest/沙箱整套；tests三项null，不借旧批绿色。未提交、不合live、不分配版本、不声称shipped或已消费者采用；回退不适用。未运行play、网络、LLM、游戏接口或其他角色知识。

探索历史保留：首次runs角色严格与小写silent比较触发断言，随后规范化原日志大写SILENT，15局全部通过；没有改原数据。两条rg曾使用旧提案所述已不存在的路径，后经rg --files定位当前reflex文件；一次队列输出过长被截断，随后仅保存本批原add与最新状态，不以截断输出作结论。这些不是生产测试失败。原124302-s2脚本及其失败历史未覆盖，本批脚本只对当前新输入重跑材料核验。

运维交接：本目录proposal.md、report.md、result.json及material-validation.json。等待逐项指定的真实缺失输入/新局补齐后重派；完成报告不关闭父要求。工作树tracked/index干净、HEAD等于上述base，原日志/账本/提案/产物保留，回收由原调度器处理，不删除自身工作树。
'''
    (OUT / 'report.md').write_text(r)
    (OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return result


if __name__ == '__main__':
    result = write()
    print(json.dumps({'waiting': len(result['proposal_results']), 'report': result['report']}, ensure_ascii=False))

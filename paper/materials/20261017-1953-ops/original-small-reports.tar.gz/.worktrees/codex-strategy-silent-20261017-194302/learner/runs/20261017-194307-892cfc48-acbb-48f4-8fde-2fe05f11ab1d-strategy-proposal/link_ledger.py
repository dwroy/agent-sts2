import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
SNAPSHOT = json.loads((OUT / 'dispatch-and-proposals.json').read_text())
IDS = sorted({i for p in SNAPSHOT['adds'].values() for i in p['ledger']})
PATH = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger_exact', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)


def selected(raw):
    result = {}
    for line in raw.splitlines():
        row = json.loads(line)
        if row.get('id') in IDS and row.get('op') in ('add', 'update'):
            ledger.apply(result, row)
    assert set(result) == set(IDS)
    assert all(i['character'] == 'silent' for i in result.values())
    return result


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    validation = json.loads((OUT / 'material-validation.json').read_text())
    assert not validation['failed_cases'] and not validation['physical_failures']
    assert not (OUT / 'ledger-cli.exit.txt').exists(), 'Do not repeat an already attempted append'
    before_raw = PATH.read_bytes()
    before = selected(before_raw)
    save('ledger-immediate-before.json', before)
    updates = []
    for ident in IDS:
        links = [i for i, p in SNAPSHOT['adds'].items() if ident in p['ledger']]
        updates.append({
            'id': ident, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': SNAPSHOT['batch'] + '：本角色原提案逐项核验；关联' + ','.join(links) +
                    '。本批仍waiting，材料核验非生产消费者校准；仅补审计追溯，不新增证据、claim、参数、status、version或shipped，具体缺口见报告。',
        })
    payload = ''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates)
    (OUT / 'ledger-updates.jsonl').write_text(payload)
    result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'],
                            input=payload, text=True, capture_output=True)
    (OUT / 'ledger-cli.stdout.txt').write_text(result.stdout)
    (OUT / 'ledger-cli.stderr.txt').write_text(result.stderr)
    (OUT / 'ledger-cli.exit.txt').write_text(str(result.returncode) + '\n')
    if result.returncode:
        raise RuntimeError('ledger CLI failed; preserve receipt and do not repeat automatically')
    after_raw = PATH.read_bytes()
    after = selected(after_raw)
    save('ledger-after.json', after)
    assert after_raw[:len(before_raw)] == before_raw
    expected = copy.deepcopy(before)
    refs = []
    start = len(before_raw)
    for raw in after_raw[start:].splitlines(keepends=True):
        row = json.loads(raw)
        if row.get('id') in IDS and row.get('op') == 'update':
            ledger.apply(expected, row)
        if row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith(SNAPSHOT['batch'] + '：'):
            refs.append({'id': row['id'], 'offset': start, 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest()})
        start += len(raw)
    assert expected == after
    assert len(refs) == len(IDS) and {x['id'] for x in refs} == set(IDS)
    protected = []
    for ident in IDS:
        a = {k: v for k, v in before[ident].items() if k not in ('history', 'notes', 'where')}
        b = {k: v for k, v in after[ident].items() if k not in ('history', 'notes', 'where')}
        assert a == b
        assert after[ident]['history'][:len(before[ident]['history'])] == before[ident]['history']
        assert after[ident]['notes'][:len(before[ident]['notes'])] == before[ident]['notes']
        for k, values in before[ident]['where'].items():
            assert after[ident]['where'][k][:len(values)] == values
        protected.append(ident)
    receipt = {
        'passed': True, 'cli_exit': result.returncode, 'update_count': len(refs),
        'prefix_size': len(before_raw), 'prefix_sha256': hashlib.sha256(before_raw).hexdigest(),
        'prefix_unchanged': True, 'after_size': len(after_raw),
        'protected_ids': protected, 'own_rows': refs, 'exact_fold_readback': True,
        'scope': '仅补既有账本where/note；未新增游戏知识、支持计数或状态。',
    }
    save('ledger-readback-audit.json', receipt)
    print(json.dumps({'passed': True, 'update_count': len(refs), 'prefix_unchanged': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()

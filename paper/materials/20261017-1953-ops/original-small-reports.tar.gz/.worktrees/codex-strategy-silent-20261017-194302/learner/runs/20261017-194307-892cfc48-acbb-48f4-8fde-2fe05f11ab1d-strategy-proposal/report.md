# 静默策略提案批次报告

时间：2026-10-17T19:52:05+08:00；批次：20261017-194302-strategy-proposal。

10项均waiting。没有由本批已核证据支持的新增策略源码差量；保持现有行为，fixes=[]、merged=null，无源码提交、游戏版本或上线。逐项证据、层/回合、账本、反例、预期行为及补证要求见[proposal.md](proposal.md)，机械结果见[result.json](result.json)。

## 身份与基线

首次git status --short为空；HEAD及report.base为`f8a724899be11fa19c4b835b7d391a5560866a79`，git merge --no-edit main返回Already up to date。对应learn.json行task=strategy-proposal、character=silent、reason=proposal、工作树及10个proposal_ids匹配；无research_request/implementation_request/proposal_repair。本批不是已授权专题，普通专题请求绑定另一旧批，未借用其work_spec/manifest、未改请求/learn.json。dispatch-and-proposals.json保留本批派发行、10原提案及其最新处置；只处理本批ID。

十份原Markdown全部匹配登记SHA，副本完整保留。关联46条既有本角色账本和41条本角色经验，经验只读，不从知识文本存在推断生产消费完成。额外5局7X0W3U8TVA2A、MTQ0EUBJ3R6T、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0都在原提案的明确证据内；没有扩展其他提案、角色或专题。

## 原始日志与核验

按指定共用extract_evidence.py一次抽取15局8流，使用run/run_id/state.run_id/fingerprint.run显式归属，冲突不收；不按正文提及取局。runs记录全为SILENT：A9三局，A10十二局。所有记录的code带dirty，不能恢复历史完整源码或把当前V5-R387当历史局版本。

|流|冻结source_size字节|本批入选行|坏JSON行|不完整行|
|---|---:|---:|---:|---:|
|states|14012143211|11008|2|0|
|decisions|2318681577|10609|2|0|
|sl-attempts|45887921|109|0|0|
|run-config|1980450|16|0|0|
|run-plans|9028544|97|0|0|
|brain|765121267|570|2|0|
|runs|361313|15|0|0|
|fight-plans|2233957|0|0|0|

每条封套含source、line、offset、bytes、SHA256及所属局；evidence-manifest.json另含逐局计数、冻结截点和输出SHA。坏JSON行归属未知；fight-plans该截点选中0行不代表原日志缺失。未复核旧source-size截点，不覆盖旧报告或零行初稿。

复用本角色原124302-s2批的两个只读材料分析脚本（逐SHA记录），对本批新抽取输入重新执行；没有借用旧分析结果或旧测试绿。分析覆盖11008状态。跨幕共有22对同上限端点，A9 5对、A10 17对，逐对匹配原限定floor(缺血×80%)；不是原116局完整资源模型或其他条件公式证明。resource-chains按重打保留各片段，不称独立样本；净HP差不当毛伤，药栏变化不单凭状态判饮用。

verify_material.py退出0：48项材料断言、124条原始引用按offset/bytes/SHA与显式身份独立读回通过。覆盖RC61柔嫩/临时敏捷/折扇，BTS单弃，XTS幽灵/毒胜连战/夜魇未兑现，7X0后段加7毒仍败，MTQ同盘29挡零损对19挡损8及末轮毒素离手，9Z倍率/复活/毒结算和跨幕端点。这是材料一致性核验，不是生产消费者、策略收益、tsc或vitest认证。

## 当前源码边界与结论

实际live只读快照为`31db98183b162f9e2213884f6b8ab518fe6ff89b`。source-audit.json对16个相关叶保存base/live blob和SHA；11个字节相同，5个只有历史Roy/Dai署名注释不同；差异保存在base-to-live-audited-leaves.patch。5个窄实现源码commit均为base和实际live祖先，分别是幽灵、限定毒胜保血、普通单弃、SL差值审计、未知持有价可见性。不是全live树等价、原dirty树或完整生产联合校准。

现有observedPoison仍是候选目标共用标量，原7X0末轮仅验证后段零毒实加7，前段另有8毒；不能将7无条件送入全场目标、叠毒、重接或持有价规则。幽灵T1有实兑现，延后整战收益未知；夜魇末T4未活到复制不能单独推出禁用或可避死。MTQ多损8/多伤6只是一局相关SL比较，不能据24/24有限败样本拟新血线。共同缺口是完整共同输入消费、执行归属、后继与受控/独立留出，而不是缺少预训练补充的游戏规则。

本批没有发现新的机制反证或与原限定知识冲突，未产生重复科学异议通知，不代其他角色ACK；全部宽父和待证条件保留。

## 记录与验证范围

根账本仅经ledger.py update追加46条where/note追溯，by=learner:strategy-proposal；旧物理前缀及46条记录保护字段读回保持，见ledger-readback-audit.json。未写新claim/evidence、未新增支持计数、未改status/version/effect/首证/prior或shipped；已shipped的窄经验不降为proposed。既有10提案ID直接交回，不另建重复id、不手改专用队列；调度器按proposal_results登记本批waiting。

无生产源码修改，不做撤源码红/恢复绿，不运行生产tsc/vitest/沙箱整套；tests三项null，不借旧批绿色。未提交、不合live、不分配版本、不声称shipped或已消费者采用；回退不适用。未运行play、网络、LLM、游戏接口或其他角色知识。

探索历史保留：首次runs角色严格与小写silent比较触发断言，随后规范化原日志大写SILENT，15局全部通过；没有改原数据。两条rg曾使用旧提案所述已不存在的路径，后经rg --files定位当前reflex文件；一次队列输出过长被截断，随后仅保存本批原add与最新状态，不以截断输出作结论。这些不是生产测试失败。原124302-s2脚本及其失败历史未覆盖，本批脚本只对当前新输入重跑材料核验。

运维交接：本目录proposal.md、report.md、result.json及material-validation.json。等待逐项指定的真实缺失输入/新局补齐后重派；完成报告不关闭父要求。工作树tracked/index干净、HEAD等于上述base，原日志/账本/提案/产物保留，回收由原调度器处理，不删除自身工作树。

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
SCRATCH = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
DISPATCH = json.loads((SCRATCH / 'dispatch.json').read_text())
RUNS = DISPATCH['runs']


def reference(item):
    return {key: item[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def compact(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **reference(item), 'ts': item['row'].get('ts'), 'screen': state.get('screen'),
        'floor': run.get('floor'), 'turn': state.get('turn'),
        'ascension': run.get('ascension'), 'character': run.get('character_id'),
        'in_combat': state.get('in_combat'), 'can_use': (combat.get('action_readiness') or {}).get('can_use_combat_actions'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'player_hp': player.get('current_hp'), 'block': player.get('block'),
        'energy': player.get('energy'), 'powers': player.get('powers'),
        'cards_played': player.get('cards_played_this_turn'),
        'hand': [{key: card.get(key) for key in ('index', 'card_id', 'upgraded', 'energy_cost', 'resolved_rules_text')}
                 for card in (combat.get('hand') or [])],
        'enemies': [{key: enemy.get(key) for key in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'move_id', 'powers', 'intents')}
                    for enemy in (combat.get('enemies') or [])],
        'potions': [{key: potion.get(key) for key in ('index', 'potion_id', 'occupied', 'can_use', 'description')}
                    for potion in (run.get('potions') or [])],
        'relics': [{key: relic.get(key) for key in ('relic_id', 'stack', 'is_melted')}
                   for relic in (run.get('relics') or [])],
    }


manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
assert {row['stream'] for row in manifest} == {
    'states', 'decisions', 'sl-attempts', 'run-config', 'run-plans', 'brain', 'runs', 'fight-plans'}
verified = {}
identity = {}
for stream in manifest:
    name = stream['stream']
    count = 0
    digest = hashlib.sha256()
    with (SCRATCH / 'evidence' / (name + '.evidence.jsonl')).open('rb') as evidence:
        with Path(ROOT / 'logs' / (name + '.jsonl')).open('rb') as original:
            for raw in evidence:
                digest.update(raw)
                item = json.loads(raw)
                assert item['run_id'] in RUNS
                original.seek(item['offset'])
                source = original.read(item['bytes'])
                assert hashlib.sha256(source).hexdigest() == item['sha256']
                assert json.loads(source) == item['row']
                count += 1
                if name == 'runs':
                    row = item['row']
                    assert row['character'].lower() == 'silent'
                    identity[item['run_id']] = row
    assert digest.hexdigest() == stream['output_sha256']
    assert count == sum(stream['counts'].values())
    verified[name] = {'rows': count, 'source_size': stream['source_size'], 'sha256': digest.hexdigest()}
assert set(identity) == set(RUNS)
(SCRATCH / 'identity.json').write_text(json.dumps(identity, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'evidence-verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')

last48, first49, actionable49 = {}, {}, {}
selected_lines = set(range(296629, 296667)) | {296521, 296610, 296611, 296612}
mechanism_rows = []
(SCRATCH / 'fixed-state-frames.jsonl').write_text('')
with (SCRATCH / 'evidence/states.evidence.jsonl').open() as evidence:
    for raw in evidence:
        item = json.loads(raw)
        state = item['row']['state']
        run = state.get('run') or {}
        assert run.get('character_id', '').lower() == 'silent'
        assert run.get('ascension') == identity[item['run_id']]['ascension']
        rid = item['run_id']
        floor = run.get('floor')
        if floor == 48:
            last48[rid] = compact(item)
        if floor == 49:
            first49.setdefault(rid, compact(item))
            if state.get('in_combat') and ((state.get('combat') or {}).get('action_readiness') or {}).get('can_use_combat_actions'):
                actionable49.setdefault(rid, compact(item))
        if rid == 'T0DGVABPV60U' and floor == 48:
            mechanism_rows.append(compact(item))
        if rid == '9R916WW0V65N' and floor in (48, 49):
            mechanism_rows.append(compact(item))
        if rid == 'T0DGVABPV60U' and item['line'] in selected_lines:
            target = SCRATCH / 'fixed-state-frames.jsonl'
            with target.open('a') as output:
                output.write(raw)

handoffs = []
for rid in RUNS:
    if rid not in first49:
        continue
    previous, following = last48[rid], first49[rid]
    assert previous['hp'] == following['hp']
    handoffs.append({'run_id': rid, 'exit48': previous, 'entry49': following,
                     'actionable49': actionable49.get(rid),
                     'same_hp': previous['hp'] == following['hp'],
                     'same_potions': previous['potions'] == following['potions']})
(SCRATCH / 'handoffs.json').write_text(json.dumps(handoffs, ensure_ascii=False, indent=2) + '\n')
with (SCRATCH / 'mechanism-frames.jsonl').open('w') as output:
    for row in mechanism_rows:
        output.write(json.dumps(row, ensure_ascii=False) + '\n')

wanted_decisions = {289584, 289585, 289605, 289475, 289479, 289562, 289563}
decisions = []
with (SCRATCH / 'evidence/decisions.evidence.jsonl').open() as evidence:
    for raw in evidence:
        item = json.loads(raw)
        if item['run_id'] == 'T0DGVABPV60U' and item['line'] in wanted_decisions:
            decisions.append(item)
(SCRATCH / 'fixed-decisions.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
assigned = json.loads((SCRATCH / 'assigned-proposals.json').read_text())['adds']
ids = {item_id for proposal in assigned.values() for item_id in proposal['ledger']}
items = {}
with (ROOT / 'paper/materials/learning/ledger.jsonl').open() as history:
    for raw in history:
        row = json.loads(raw)
        if row.get('id') in ids:
            ledger.apply(items, row)
assert set(items) == ids
assert all(item['character'] == 'silent' for item in items.values())
(SCRATCH / 'ledger-folded-before.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified': verified, 'runs': {rid: {'ascension': r['ascension'], 'floor': r['floor']} for rid, r in identity.items()},
                  'handoffs': [{'run_id': h['run_id'], 'hp': h['exit48']['hp'], 'same_hp': h['same_hp']} for h in handoffs],
                  'fixed_decisions': len(decisions), 'ledger_ids': len(items)}, ensure_ascii=False, indent=2))

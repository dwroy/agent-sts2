from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile

root=Path.cwd(); p=root/'ops/codex-ops/record-staging/20261016-0058'; pub=root/'paper/materials/20261016-0058-ops'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda f:json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root): return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip()
assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-004302-strategy-proposal'; batches=load(root/'ops/codex-ops/learn.json')['batches']; b=batches[bid]; report=b['report']; s=Path(report['report']).parent
out=root/'ops/codex-ops/learner'/(bid+'.out'); output=out.read_text()
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch_result=load(s/'result.json')
assert {k:v for k,v in scratch_result.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch_result['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(v is None for v in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base']
assert not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
assert (s/'source.diff.patch').read_bytes()==b''
completion=load(s/'completion-check.json'); assert completion['head']==report['base'] and completion['git_status']=='' and completion['dispatch_binding_unchanged'] and completion['source_diff_empty'] and completion['ledger_count']==32
exec((p/'readonly-runtime.py').read_text()); native=runtime(bid,report,output,b['worktree'])
producer_native=load(s/'runtime-readback.json'); assert producer_native['thread_id']==native['thread']
assert any(x['type']=='turn_context' and x['sha256']==native['native_context']['sha256'] for x in producer_native['records'])
selected=load(s/'dispatched-proposals.json'); assert set(selected)==set(report['code_proposals'])
for ident,data in selected.items():
    proposal=data['original']; f=Path(proposal['proposal']); assert f.resolve().is_relative_to(root)
    assert sha(f.read_bytes())==proposal['proposal_sha256']
material=load(s/'material-checks.json'); assert material['count']==material['passed']==len(material['checks'])==74 and material['production_tests'] is None
verification=load(s/'byte-verification.json'); assert sum(x['rows'] for x in verification)==6606
streams=load(s/'evidence/evidence-manifest.json')
for row in streams:
    assert sha((s/'evidence'/(row['stream']+'.evidence.jsonl')).read_bytes())==row['output_sha256']
assert sum(sum(x['counts'].values()) for x in streams)==6606
source=load(s/'source-readback.json'); assert source['base']==report['base'] and len(source['files'])==16
for row in source['files']:
    a=git('show',report['base']+':'+row['path']); z=git('show',source['live']+':'+row['path'])
    assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256'] and (a==z)==row['equal']
    assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
    git('merge-base','--is-ancestor',row['live_leaf_source'],source['live'])
assert sum(x['equal'] for x in source['files'])==13
prior=Path(batches['20261015-214302-strategy-proposal']['report']['report'])
prior_raw=prior.read_bytes(); assert b'279021' in prior_raw and b'279197' in prior_raw and '3轮/2样本'.encode() in prior_raw and '5轮/24样本'.encode() in prior_raw
boundary=load(s/'ledger-before-boundary.json'); ledger=root/'paper/materials/learning/ledger.jsonl'
with ledger.open('rb') as handle: prefix=handle.read(boundary['source_size'])
assert sha(prefix)==boundary['sha256']
inputs=[json.loads(line) for line in (s/'ledger-updates.jsonl').read_text().splitlines()]
assert len(inputs)==32 and set((s/'ledger-update.log').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.rc').read_text().strip()=='0'
preservation=load(s/'ledger-preservation.json'); assert preservation['prefix_preserved'] and preservation['own_update_count']==32
assert all(x['non_trace_fields_preserved'] and x['old_history_notes_where_preserved'] for x in preservation['checks'])
own=[]; refs=[]
with ledger.open('rb') as handle:
    handle.seek(boundary['source_size'])
    while True:
        offset=handle.tell(); raw=handle.readline()
        if not raw: break
        row=json.loads(raw)
        if row.get('op')=='update' and any(all(row.get(k)==v for k,v in entry.items()) for entry in inputs):
            assert set(row)<={'op','id','ts','by','where','note'}
            own.append(raw); refs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(own)==len(set(own))==32
old=git('show',base+':paper/materials/learning/ledger.jsonl'); existing=set(old.splitlines()); assert all(raw.rstrip(b'\n') not in existing for raw in own)
added=b''.join(own)
spec=importlib.util.spec_from_file_location('owned_ledger',root/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a,z=fold(old),fold(old+added); assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']: assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items(): assert all(x in z[ident]['where'][key] for x in items)
assert load(s/'gitleaks.json')==[] and (s/'gitleaks.rc').read_text().strip()=='0'
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch_result,stdout_waiting_reasons_abbreviated=True,original_state=b['state'],original_gate=b['no_change_proposals'],native=native,original_native_readback=producer_native,completion=completion,source=source,evidence_output_shas_verified=True,original_row_count=6606,original_material_checks=74,material_not_reexecuted=True,owned_cli_rows=32,protected_fields_and_old_history_where_notes_preserved=True,known_budget_limitation=dict(path=str(prior.relative_to(root)),sha256=sha(prior_raw),already_explicit=True),limits=['Five historical dirty Silent A10 runs; the original consumed source/knowledge bytes and whole-candidate execution remain unknown.','RC first/last budgets differ; original answer, guard/SL selection and completed action remain separate. No controlled whole-fight or HP/potion-price calibration.','Old scoped implementations and source ancestry do not close wide proposal, consumer or learning parents. No new contradiction notice or another-role ACK is claimed.','Producer initial transition/operable frame display and schema/path probes are retained; these are not new product defects.']))
write(pub/'owned-ledger-references.json',refs)
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err'),prior]
    for f in sorted(files):
        raw=f.read_bytes(); rel=str(f.relative_to(root)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0058原004302策略done0/no-source处置核，81275干净WT/HEAD不变、十waiting具体缺口/testsnull/域空/mergednull保持，无合入阻塞，不空合/发号/补测。五Silent A10八流6606材料产物SHA及74限定断言核，不重跑或当生产测试/整线认证；16源码叶13同3历史Roy-Dai注释差及live真实祖先核。RC279021首3轮2样本、279197末5轮24样本差已在原214302报告明确，本批重申不造新反证/已告知或ACK；原答/护栏/SL/实际线、同局相关性、历史dirty树和整战反事实未知保持，不拟血价/药价/SL阈值或关闭宽父。32所属CLI纯where/note按输入/输出ID及原offset/bytes/SHA核，私有fold旧claim/首证/prior/证据/状态/版本及history/notes/where保，不重复CLI或降级shipped。原生实际Sol6.1/xhigh/input/lease/workspace-write/no-network与正文high分列保留，原开场过渡/可操作帧显示更正及schema/路径探针失败保，不当新产品bug。仅本人记录/追溯提交，保并行脏记录；无新源码/知识/版本/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作。证据paper/materials/20261016-0058-ops/。\n'
note=f'\n- {at} [运维 codex] 原004302策略10项继续waiting，无源码变更或合入受阻；74项为材料检查、生产tests仍null，32所属追溯已核。首末预算差沿原报告边界保留，不当新实现或完整校准。回执paper/materials/20261016-0058-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle: handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=32,protected_fields_preserved=True,no_new_source_tests_merge_or_release=True,wide_parents='remain open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
    copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0
print(json.dumps(dict(waiting=10,owned_trace_rows=32,ledger_check=0,paths=len(entries))))

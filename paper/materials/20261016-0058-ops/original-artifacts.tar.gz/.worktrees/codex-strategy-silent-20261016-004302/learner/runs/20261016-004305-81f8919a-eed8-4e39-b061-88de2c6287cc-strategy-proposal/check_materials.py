import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {s['line']: s for s in map(json.loads, (OUT / 'state-index.jsonl').open())}
decisions = {x['line']: x['row'] for x in json.loads((OUT / 'selected-decisions.json').read_text())}
checks = []


def check(label, value, expected):
    checks.append({'label': label, 'actual': value, 'expected': expected, 'pass': value == expected})


def enemy(line, name):
    return next(e for e in states[line]['enemies'] if e['id'] == name)


def total_hp(line):
    return sum(e['hp'] for e in states[line]['enemies'])


def plan(line, key):
    return json.loads(decisions[line]['questions']['plan']['criteria'][key])


props = json.loads((OUT / 'dispatched-proposals.json').read_text())
for key, value in props.items():
    p = value['original']
    check(key + ' 原提案SHA', hashlib.sha256(Path(p['proposal']).read_bytes()).hexdigest(), p['proposal_sha256'])
    check(key + ' 角色', p['character'], 'silent')

for line in [283391, 283502]:
    check(f'NHA可操作入口{line}', [states[line]['hp'], total_hp(line)], [30, 408])
check('NHA两次入口同手牌', states[283391]['hand'], states[283502]['hand'])
check('NHA首试T1实际血价', states[283391]['hp'] - states[283397]['hp'], 1)
check('NHA末试T1实际血价', states[283502]['hp'] - states[283507]['hp'], 7)
check('NHA首试T1敌净扣', total_hp(283391) - total_hp(283397), 8)
check('NHA末试T1敌净扣', total_hp(283502) - total_hp(283507), 24)
check('NHA首末挡差', states[283396]['block'] - states[283506]['block'], 6)

check('P74弃牌前四个合法选项', [c['card_id'] for c in states[284817]['selection']['cards']],
      ['STRANGLE', 'NOXIOUS_FUMES', 'PRECISE_CUT', 'GREED'])
check('P74精确切击当帧费用', states[284817]['hand'][2]['energy_cost'], 0)
check('P74实际弃精确', any(c['card_id'] == 'PRECISE_CUT' for c in states[284818]['hand']), False)
check('P74末轮HP和挡', [states[284820]['hp'], states[284820]['block']], [1, 16])
check('P74末轮逐敌来袭', [e['incoming'] for e in states[284820]['enemies']], [16, 0, 8])
check('P74石虫实际眩晕', enemy(284821, 'BOWLBUG_ROCK')['move'], 'STUNNED')
check('P74卵毒后仍活', enemy(284821, 'BOWLBUG_EGG')['hp'], 2)
check('P74实际死亡', states[284821]['hp'], 0)
check('P74胧光T2实际损血', states[284743]['hp'] - states[284744]['hp'], 20)
check('P74胧光T4实际损血', states[284753]['hp'] - states[284754]['hp'], 24)
check('P74寄生先死亡', enemy(284748, 'PARAFRIGHT')['hp'], 0)
check('P74寄生再次出现', enemy(284749, 'PARAFRIGHT')['hp'], 21)
check('P74赢战实际9HP进下战', [states[284761]['hp'], states[284766]['hp']], [9, 9])
check('P74火焰相邻帧实际扣血', enemy(284630, 'VANTOM')['hp'] - enemy(284631, 'VANTOM')['hp'], 1)
check('P74火焰相邻帧滑溜减层', enemy(284630, 'VANTOM')['powers']['SLIPPERY_POWER'] - enemy(284631, 'VANTOM')['powers']['SLIPPERY_POWER'], 1)
check('P74尖啸当轮来袭', [enemy(284633, 'VANTOM')['incoming'], enemy(284634, 'VANTOM')['incoming']], [14, 2])
check('P74无滑溜T8毒实扣', enemy(284658, 'VANTOM')['hp'] - enemy(284659, 'VANTOM')['hp'], 23)

check('RC两次入口同手牌', states[285315]['hand'], states[285491]['hand'])
check('RC两次入口同52HP', [states[285315]['hp'], states[285491]['hp']], [52, 52])
check('RC首末T1血价', [52 - states[285321]['hp'], 52 - states[285497]['hp']], [4, 8])
check('RC首末T1实扣', [428 - total_hp(285321), 428 - total_hp(285497)], [30, 23])
check('RC首末T1挡', [states[285320]['block'], states[285496]['block']], [16, 12])
check('RC末试能力建立', states[285496]['powers']['ACCELERANT_POWER'], 1)
check('RC原题真实为三轮两样本', '3-turn rollout (2 samples)' in plan(279021, 'plan1')['rollout'], True)
check('RC末题为五轮24样本', '5-turn rollout (24 samples)' in plan(279197, 'plan1')['rollout'], True)
check('RC强制弃牌前手牌', [c['card_id'] for c in states[285414]['hand']], ['SURVIVOR', 'STRIKE_SILENT'])
check('RC强制弃牌后手空', states[285415]['hand'], [])
check('RC强制弃牌后57激光', enemy(285415, 'ROCKET')['incoming'], 57)
check('RC呼唤末持6失血且胜出', states[285095]['hp'] - states[285096]['hp'], 6)
check('RC三个二幕营火实回63', sum(states[b]['hp'] - states[a]['hp'] for a, b in [(285249, 285250), (285260, 285261), (285311, 285312)]), 63)
check('RC二幕胜战耗31', states[285266]['hp'] - states[285298]['hp'], 31)
check('RC最后休息实52HP', states[285312]['hp'], 52)

check('G33千足虫胜战实际耗37', states[283916]['hp'] - states[283958]['hp'], 37)
check('G33恶魔胜战实际耗59', states[283967]['hp'] - states[284007]['hp'], 59)
check('G33女王末轮余像2层', states[284407]['powers']['AFTERIMAGE_POWER'], 2)
check('G33女王末轮挡12', states[284407]['block'], 12)
check('G33女王末轮实际毒扣', [enemy(284407, e)['hp'] - enemy(284408, e)['hp'] for e in ['QUEEN', 'TORCH_HEAD_AMALGAM']], [42, 22])
check('G33女王末轮依然死亡', states[284408]['hp'], 0)
check('G33两首牌候选不同即时输出', [plan(277909, p)['damage_dealt'] for p in ['plan1', 'plan2']], [75, 107])

check('BTS醒后T2/T3/T4攻击', [enemy(n, 'SLUMBERING_BEETLE')['incoming'] for n in [286158, 286163, 286170]], [18, 20, 22])
check('BTS中和后攻击13', enemy(286160, 'SLUMBERING_BEETLE')['incoming'], 13)
check('BTST2单弃后手空', states[286162]['hand'], [])
check('BTST2实际血价14', states[286158]['hp'] - states[286163]['hp'], 14)
check('BTS末轮5牌挡加1覆甲', [states[286173]['block'], states[286173]['powers']['PLATING_POWER']], [5, 1])
check('BTS实际死亡且甲虫剩13', [states[286174]['hp'], enemy(286174, 'SLUMBERING_BEETLE')['hp']], [0, 13])
check('BTS最终被选择线3胜1死', 'fight over within 5 turns in 3/4' in plan(279854, 'plan2')['rollout'] and 'dead within 5 turns in 1/4' in plan(279854, 'plan2')['rollout'], True)

(OUT / 'material-checks.json').write_text(json.dumps({'kind': 'evidence_material_assertions_only', 'production_tests': None,
    'count': len(checks), 'passed': sum(x['pass'] for x in checks), 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'count': len(checks), 'passed': sum(x['pass'] for x in checks), 'failed': [x for x in checks if not x['pass']]}, ensure_ascii=False))
raise SystemExit(0 if all(x['pass'] for x in checks) else 1)

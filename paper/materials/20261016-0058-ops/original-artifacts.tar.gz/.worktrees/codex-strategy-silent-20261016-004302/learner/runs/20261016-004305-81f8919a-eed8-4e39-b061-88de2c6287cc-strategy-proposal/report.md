# 静默策略队列核证报告

批次：20261016-004302-strategy-proposal。基线：`81275beb0c0a003d276bbda527280caee48291e8`；开工干净，普通批次合并main返回Already up to date，HEAD不变。调度reason=proposal，有十个proposal_ids、无research_request/implementation_request，不承接另一专题。原请求不写入。

十项完整提案均waiting；没有源码、知识或游戏规则修改。`fixes=[]`、`merged=null`；无提交、合入、版本分配或shipped声明。完整逐项证据、账本、反例、预期行为、验证及回退在[proposal.md](proposal.md)。所有十份原Markdown与队列SHA匹配。实际原生线程`01a14072-2f4f-78e0-92ae-95961d857efb`的turn_context核为gpt-6.1-sol/xhigh、workspace-write、network_access=false、approval_policy=never；普通服务档来自启动命令。正文high与原生xhigh不一致保留，未改设置/线程。详见runtime-readback.json。

## 冻结证据与范围

| 流 | NHA2KW0RB7VP | P74C04AEPL1F | G33HU22H2543 | RC61MFQM63Y6 | BTSRF7JL1W1Y |
|---|---:|---:|---:|---:|---:|
| states | 602 | 410 | 879 | 694 | 653 |
| decisions | 584 | 395 | 850 | 674 | 635 |
| sl-attempts | 7 | 5 | 8 | 7 | 4 |
| run-config | 1 | 1 | 1 | 1 | 1 |
| run-plans | 5 | 3 | 6 | 7 | 5 |
| brain | 34 | 23 | 45 | 33 | 28 |
| runs | 1 | 1 | 1 | 1 | 1 |
| fight-plans | 0 | 0 | 0 | 0 | 0 |

共6606行，逐行读回原日志指定字节验证JSON及SHA，显式身份与角色一致；byte-verification.json保留结果，evidence/evidence-manifest.json保留各流source_size、计数和输出SHA，逐条材料保留offset/bytes/SHA。扫描源范围内states有2个非法JSON行、decisions有2个、brain有1个；这是入口全扫描的计数，不归给本批选中行。本批选中行均解析/身份/字节相符，不能由全流非法行判当前产品缺陷。

fight-plans在2233957字节截点选中0行，只表示该截点未选到显式所属本批的行，不能推断历史日志/计划不存在。没有复核旧run-plans截点或覆盖旧零行初稿。抽取原件与extraction.log保留。

语义分析以十项提案涉及的窗口为界，保存105精选状态、12精选决策及完整本批状态索引；74材料断言全部通过，不声称6606行逐项全语义审计、全候选认证、完整整战模拟或全历史量化完成。

## 主要核证与限制

- NHA F33同首手按可操作30血/敌408比较，28血/敌428是更早过渡帧。原T1实损1/敌净扣8，替线实损7/净扣24；即时多16伤多损6血成立，缺同条件整战与能力累计收益。
- RC F33同52血、同手牌，T1原线挡16/实损4/扣30；替触媒挡12/实损8/扣23。原题279021为3轮2样本、末题279197为5轮24样本，不把首题冒成24/24。原提案字节保留，沿已有修正边界向ops报告该可比性限制。
- P74 F23末次弃精确后，1血16挡面对石16+卵8，石虫眩晕与玩家被卵杀死同时成立，卵毒后余2。当前费用/手牌快照不是四个动态分支的完整重算；保留精确后的整战未知，不以当帧7伤替代变化后的牌面。
- P74 F22赢战53→9、T2/T4实际损20/24，寄生归零再21；9血空药接F23。G33千足虫83→46、恶魔76→17均胜；RC二幕三火实回63、F29赢战耗31、末火至52。均是实际资源链，不推出改路线或留药必胜。
- BTS F31醒虫攻击18→20→22，末轮14血/5牌挡+1覆甲对22，毒后甲虫剩13而玩家死。最终新选线3/4样本胜本就包含1/4死亡；没有逐样本动作/抽序与实际线配对，不因一次死调概率权重或强制杀序。

这些是对原观察的复核，不新增游戏假设或另一角色知识。没有新的反机制实帧；未控的因果与原反例仍保留。旧亲历预算差/dirty源码/完整归属缺口不因本报告关闭，亦不关闭学习入库或量化父要求。

## 已有源码边界

只读live核对点：`cfa1c0be88147b4eac65c13d8c550b23ed4eef17`。16个相关源码叶13个字节相同，card-model.ts、sl/explore.ts、sl/judge.ts的历史Roy/Dai注释差保留，未覆盖。source-readback.json记每叶SHA与真实live祖先来源；source.diff.patch为本分支相对base的空源码差量。当前树读回不代表复原五局原dirty树。

投斧首牌键、普通生存者唯一单弃、弃牌后继失效提示、弃后手牌/单卡费用快照、SL模型资源比较及选择/派发审计等窄实现，可核到真实main/live祖先源码`a8b1f8be153fe4f3a34146117546c2178f2e446b`。持牌损血事实后续窄来源`05cd292c6f01bb31e406473d3a9843e659d62b93`亦为live祖先。报告不把整个宽提案登记duplicate或implemented：当前快照明确不推演弃牌后伤挡/胜负；selection_dispatch只证单动作回执，state_effect_verified=false、whole_plan_executed=null。仍缺跨重规划完整归属、完整联合消费者和同条件后续校准。

## 验证、登记与交接

无生产改动，tsc/vitest/cases均null；未运行沙箱生产套件，未做撤源码失败/恢复通过，不伪造测试或部署。74/74是固定证据材料检查（material-checks.json、material-checks.log），不计入生产tests。byte-verification-final.log是修正开场“过渡帧/可操作帧”显示区分后的材料再读回；首次opening-turns.initial.json保留，原证据不变。

路径定位失败、首轮摘要误将combat=null视作对象、个别历史决策无questions键，以及工具输出截断均属本次材料探针；随后按实际路径/schema纠正，原工具转录保留，不登记新产品bug。没有网络、LLM模拟、play、推送、依赖安装或下级agent。

经根目录ledger.py update，仅为32个既有本角色关联账本追加本批proposal/report链接及waiting说明，不追加重复证据、不改claim/首证/prior/原状态/版本，不把既有shipped降回proposed。CLI输入、回执及前后保护验证保存在ledger-updates.jsonl、ledger-update.log、ledger-preservation.json。没有新代码提案id；最终code_proposals沿用十个真实CLI原id，implementation_domains为空。

请运维逐项读回proposal-results.json；保持原十项等待新证据，沿原ops→watcher→Roy链保留已知预算可比性及未知限制，不把队列登记当已告知/已确认。无需源码合入、发号或补造测试；本批工作树HEAD与base一致且git status干净，scratch为忽略材料。报告结束不关闭原宽项或父要求。

最后读回：ledger CLI退出0，32项原非追溯字段及旧history/notes/where均保留，原账本字节前缀SHA不变；ledger-preservation.json已保存。三叶差异另按Roy→Dai文本替换相等核实，source-comment-differences.json保留，不改历史注释。派发身份/十个id未变，HEAD不变、工作树干净，completion-check.json已落盘。gitleaks对本批scratch扫描约147.62 MB，退出0、无泄露（gitleaks.rc/log/json）；这不代替生产测试。

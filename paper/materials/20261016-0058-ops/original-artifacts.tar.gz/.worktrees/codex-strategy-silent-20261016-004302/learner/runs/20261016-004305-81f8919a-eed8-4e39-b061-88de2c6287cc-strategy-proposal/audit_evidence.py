import hashlib
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']


def write(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def identity(row):
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        fp = json.loads(fp)
    values = [row.get('run_id'), row.get('run'), (row.get('state') or {}).get('run_id'),
              (fp or {}).get('run')]
    ids = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
    assert len(ids) == 1, ids
    return next(iter(ids))


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw.get('powers') or []}


def state_summary(item):
    s = item['row']['state']
    c, r = s.get('combat') or {}, s.get('run') or {}
    player = c.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'], 'floor': r.get('floor'),
        'turn': s.get('turn'), 'screen': s.get('screen'),
        'hp': player.get('current_hp', r.get('current_hp')), 'max_hp': r.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player), 'relics': [p['relic_id'] for p in r.get('relics') or []],
        'potions': [{k: p.get(k) for k in ['index', 'potion_id', 'occupied']}
                    for p in r.get('potions') or []],
        'hand': [{k: card.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'resolved_rules_text']}
                 for card in c.get('hand') or []],
        'selection': s.get('selection'),
        'enemies': [dict(id=e['enemy_id'], hp=e['current_hp'], block=e.get('block'),
                         alive=e['is_alive'], powers=powers(e), move=e.get('move_id'),
                         incoming=sum(i.get('total_damage') or 0 for i in e.get('intents') or []))
                    for e in c.get('enemies') or []],
    }


def main():
    all_rows, verification = {}, []
    for manifest in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
        name = manifest['stream']
        path = OUT / 'evidence' / (name + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
        rows, counts = [], Counter()
        source = None
        try:
            for line in path.open():
                item = json.loads(line)
                if source is None:
                    source = Path(item['source']).open('rb')
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                assert identity(item['row']) == item['run_id'] in RUNS
                counts[item['run_id']] += 1
                rows.append(item)
        finally:
            if source:
                source.close()
        assert {r: counts[r] for r in RUNS} == manifest['counts']
        all_rows[name] = rows
        verification.append({'stream': name, 'rows': len(rows), 'source_bytes_verified': sum(r['bytes'] for r in rows)})
    write('byte-verification.json', verification)
    states = [state_summary(x) for x in all_rows['states']]
    with (OUT / 'state-index.jsonl').open('w') as f:
        for s in states:
            f.write(json.dumps(s, ensure_ascii=False) + '\n')
    selected = set(range(284816, 284822)) | set(range(285314, 285322)) | set(range(285491, 285498))
    selected |= set(range(286148, 286153)) | set(range(286158, 286174)) | set(range(285411, 285416))
    selected |= set(range(284626, 284636)) | set(range(284651, 284661)) | set(range(284730, 284762))
    selected |= set(range(284403, 284409))
    write('selected-states.json', [s for s in states if s['line'] in selected])
    selected_decisions = {278542, 278543, 278544, 278545, 278546, 279021, 279197,
                          279117, 279846, 279852, 279854, 277909}
    write('selected-decisions.json', [x for x in all_rows['decisions'] if x['line'] in selected_decisions])
    turns = []
    for run, floor in [('NHA2KW0RB7VP', 33), ('RC61MFQM63Y6', 33), ('G33HU22H2543', 48)]:
        for attempt in all_rows['sl-attempts']:
            a = attempt['row']
            if attempt['run_id'] != run or a['floor'] != floor:
                continue
            frames = [x for x in all_rows['states'] if x['run_id'] == run and
                      x['row']['state'].get('run', {}).get('floor') == floor and
                      a['started_at'] <= x['row']['ts'] <= a['ended_at']]
            t1 = [state_summary(x) for x in frames if x['row']['state'].get('turn') == 1]
            t2 = [state_summary(x) for x in frames if x['row']['state'].get('turn') == 2]
            operable = [s for s in t1 if s['hand'] and (s['energy'] or 0) > 0]
            turns.append({'run': run, 'attempt': a['attempt'], 'result': a['result'],
                          'first_t1': t1[0] if t1 else None, 'last_t1': t1[-1] if t1 else None,
                          'first_operable_t1': operable[0] if operable else None,
                          'first_t2': t2[0] if t2 else None})
    write('opening-turns.json', turns)
    print(json.dumps({'rows': sum(len(x) for x in all_rows.values()), 'verification': verification,
                      'selected_states': sum(s['line'] in selected for s in states)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

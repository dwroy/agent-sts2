import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
dispatch = json.loads((OUT / 'dispatch.json').read_text())
props = json.loads((OUT / 'dispatched-proposals.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
old_source = 'a8b1f8be153fe4f3a34146117546c2178f2e446b'
assert subprocess.run(['git', 'merge-base', '--is-ancestor', old_source, source['live']]).returncode == 0
assert subprocess.run(['git', 'merge-base', '--is-ancestor', old_source, base]).returncode == 0

details = [
    ('NHA2KW0RB7VP F33 T1—T4',
     'states 283391/283396/283397 对 283502/283506/283507：可操作入口均30血、敌总408；原线14挡、实损1、敌净扣8，末线8挡、实损7、敌净扣24。283390为尚无手牌的28血/敌428过渡帧，不作同首手基线。',
     '即时多16伤、多损6血成立；尚无同抽序、同预算的完整实线及路线/保药反事实，现有预测资源差不能证明累计能力收益或新的SL、终局HP门槛。',
     '原提案明确六试未胜；多轮出牌与抽弃不同，不能把整战归因于T1，也不能把零胜样本当即时等价。',
     '保留当前选择规则。后续使用同一输入、随机流与预算保存各轮可执行前缀、真实资源、能力建层、敌HP及终结；缺项继续未知，不拟合固定血价。'),
    ('P74C04AEPL1F F23 第4次T3',
     'decisions 278542—278546；states 284817有紧勒/毒雾+/精确切击/贪婪四选，精确0费但伤害依赖手牌；284818确认精确离手，284820为1血16挡对石16+卵8，284821石眩晕、卵毒后2血且玩家死亡。',
     '当前已有弃后手牌/单卡费用快照和移除后继提示；缺四个合法分支的动态牌面、目标、弃牌触发与续步生存结果的联合回放，不能把快照当完整候选认证。',
     '首试弃同牌仍活到T4，第三次原线不含精确；本批不补保留精确的实打胜局，也不新增固定弃贪婪规则。',
     '全部合法选项继续保留。将四分支送同一固定消费者，核手牌依赖伤害与逐敌攻击；当前快照明确未推演伤挡、HP或胜负。'),
    ('P74C04AEPL1F F17 T1/T2/T8、F22 T2—T6、F23 T1/T3',
     '284630→284631火焰相邻帧仅扣1且滑溜少1；284633→284634来袭14→2；284658→284659毒扣23。284743→284744实损20、284753→284754实损24；寄生284748归零、284749再21，赢战284761为9血并接284766的F23入口。',
     '逐敌失衡、召唤复活、一次翻倍及滑溜/毒有直接实帧；主怪最后归零中间来源仍缺，且未完成这些组合与连续用药、来源/代际的一体消费者验证，未定位新的可隔离模型差额。',
     '挡住石虫仍可被卵虫击杀；某轮寄生归零不是整战永久退场；赢下F22不代表无资源代价。没有另一杀序/保药的受控整战结果。',
     '按来源、代际和实际触发窗口验证现有模型；未知内部帧、未观察药水和复活组合保持未知，不推统一目标次序或喝药阈值。'),
    ('G33HU22H2543 F48 T1/T8；P74C04AEPL1F F23 T3',
     'sl-attempts 995的同一T1候选中，闪亮先与余像先的旧canon相同；decision 277909两候选伤75/107。G33末轮284405/284407余像实建2层，挡5→12；P74弃牌链见278542—278546。',
     '投斧首牌身份及普通单弃已有实际live祖先源码；宽提案仍需跨重规划完整执行归属、余像累计兑现及动态弃牌分支的联合验证，不能以两个窄修复将整项判duplicate。',
     '余像先候选未被完整执行；实建两层不等于计划中的重放必然兑现。死亡不证明能力无效，也不能证明改首牌就赢。',
     '沿现有首牌键与选择重算入口核实际前缀、后继取消及各轮能力兑现；新证据未定位未修的确定身份差额，保留原实现。'),
    ('G33HU22H2543 F31/F32/F33/F47/F48；P74C04AEPL1F F22/F23',
     'G33 states 283916→283958为83→46胜、空药，283964→283965实休46→76，283967→284007为76→17胜；284158→284159休49→81。P74 F22胜53→9，F23实入口9且空药。',
     '赢战耗血和实际后战入口成立；缺逐来源资源消费者账与同条件路线/休息/SL/保药整战分支，不能用净血差拟合因果HP价格。',
     '到达后才兑现营火；SL恢复和幕间回血不是当局新获得药水/战斗治疗。未走路线和留药反事实不补成胜利。',
     '固定资源链分别核休息、遗物、药水、事件、幕间与SL；必须配对可执行后继后再比较路线或保药收益。本批不重算旧110/112局统计。'),
    ('G33HU22H2543 F48 T7/T8；P74C04AEPL1F F17/F22/F23',
     'G33 284407为余像2、脆弱94、雾3、挡12，末结毒女王42/聚合22，284408玩家归零。P74普通触媒与滑溜、临时减力、逐敌挡/眩晕的直接帧另见上项。',
     '已读取当前遗物与能力现场；仍缺这些完整组合在模型、求解、药水与终局链中的联合生产回放及独立校准，不能将局部数值吻合扩成全组合认证。',
     '持续能力只认已建立的层数；牌挡与被动挡不共用倍率。原dirty运行树内容未知，当前源码相同或某窄项上线不复原旧运行状态。',
     '按完整输入组合分别重放临时力恢复、毒额外结算、翻倍消费及开场边界；未找到新的、可隔离且未修的数值失配，不改一般药水/终局参数。'),
    ('RC61MFQM63Y6 F33 首试/末试T1及第三次T4',
     'states 285315/285320/285321与285491/285496/285497：同52血、同手牌；原实损4/扣30/挡16，替线实损8/扣23/挡12，末线触媒实建1。279021首题为3轮2样本，279197末题为5轮24样本。285414→285415唯一打击被强制弃掉。',
     '同首手的少7伤、多损4血成立；首末推演预算不同，且缺同抽序、同预算整战与累计能力收益，不能调整保血/铺能力排序或新的SL阈值。',
     '原提案“两候选五轮24/24”不能描述首题实际预算；保留原提案字节，以本报告说明可比性限制。普通单弃旧根因已有窄修复，不把错误旧后继当安全承诺。',
     '即时账可作为固定观察；后续比较须同预算并逐轮核执行，保留不同后继和未知毒雾启动，不推出一律先能力/保血/固定杀序。'),
    ('BTSRF7JL1W1Y F31 T1—T4；F17胜试作为原提案反例',
     'states 286158/286163/286170醒虫攻击18/20/22，中和后286160为13；286161→286162生存者弃唯一突然一拳，T2实损14。decision 279852抽弃前原线与279854重算线不同；后者5轮4样本3胜1死。286173为14血、5牌挡+1覆甲对22，286174死且甲虫13血。',
     '成长、临时弱与当前覆甲已核；缺逐样本抽序/动作与最终实线配对，一次死亡不足确认模型偏差或校准保血/目标权重。',
     '3/4预测本身包含死亡可能；原选线被抽弃中断，不能称原最优完整执行后失败。F17实建敏捷不代表F31也已经建立。',
     '先对同一最终执行输入验证力量恢复/成长、覆甲和毒；未定位新数值差额，不修改焦点、出牌权重或概率。后移留出须按原局分组，不能按SL拆独立样本。'),
    ('RC61MFQM63Y6 F17 T11、F33 第三次T4及首末T1',
     '285414只剩生存者与打击，285415手空、45HP/7挡而火箭57；旧候选279117却计划后继打击。285095手持呼唤、8HP、敌2HP/31毒/0攻，285096胜后2HP，实失6。',
     '普通单弃取消唯一后继已有live源码；宽项仍缺跨重规划完整执行归属、累计能力及呼唤自损的联合消费者验收，不能将单动作回执当整线完成。',
     '毒杀不抵消先发生的持牌失血；可选弃牌尚未确定时也不能先扣除一张呼唤。缺全流程反事实，不拟新SL血价或统一出牌顺序。',
     '审计选择前后计划、实际派发及后续状态；当前selection_dispatch明确state_effect_verified=false、whole_plan_executed=null，保留该边界。'),
    ('RC61MFQM63Y6 F24/F27/F29/F32/F33',
     'states 285249→285250为20→41、285260→285261为41→62、285311→285312为31→52，三火实回63；F29 states 285266→285298胜战62→31、耗31。F33入口52。',
     '实回63、赢战耗31及boss入口52成立；缺回复/药槽/存档事件的完整分源消费者账和同条件后战反事实，不能据此确定路线或终局HP价格。',
     '原F27预测boss70不等于实际52，差额不直接归因于休息；五次重载同瓶药不是五次新获药。别线/锻造/留药结局未知。',
     '沿真实事件核分源资源账及下一房入口，SL恢复另列；没有证据支持新固定禁令/血价，保留现行行为。'),
]

results = []
sections = []
for (key, item), (scope, evidence, reason, limits, validation) in zip(props.items(), details, strict=True):
    original = item['original']
    results.append({'id': key, 'state': 'waiting', 'reason': reason})
    sections.append(f'''## {key}

范围：静默A10；{scope}。来源任务：{original['source_task']}；实现任务：strategy-proposal / 20261016-004302-strategy-proposal。

账本：{', '.join(original['ledger'])}。

原提案：{original['proposal']}；SHA256 `{original['proposal_sha256']}`，已读回相符，原文不改。

已有目标/预期行为：{original['summary']}。本批实际处置：waiting。

本批证据：{evidence}

未实现原因：{reason}

反例与限制：{limits}

验证方法与后续触发：{validation}
''')

proposal = '''# 静默猎手本批十项提案核证与处置

批次：20261016-004302-strategy-proposal。仅处理派发的十个原id，不领取其他项，不新增重复提案。五局均由runs.jsonl核为SILENT/A10。

结论：十项宽提案继续waiting。已实现窄子项与宽项的证据/消费者缺口分别记录；本批未找到证据足够且尚未实现的可隔离源码差额，不以败局或少量推演样本新增策略权重。

通用方法：共用入口提取八流，按显式身份核6606行原字节、offset/bytes/SHA；保存105个精选状态与12个精选决策，另有全部本批状态索引。74项材料断言全部通过，仅核记录和算术，不是生产tsc/vitest或完整候选回放。只核本批五局及其原提案/账本，不重做原提案的全历史分母。各局+dirty历史不能用当前树复原。

拟合与切分：没有拟合参数。五个原局仅作固定回归观察；同局SL不当独立样本，不用同局拆分冒充时间后置验证。新阈值/校准须先取得相同输入、可达动作、同预算及后置独立局；没有实打替线便不称转胜。纯确定性缺陷无需实胜才可修，但本批已定位的旧确定性缺陷有live祖先源码，未验证的新差额不冒称bug。

共同回退边界：本批没有源码/知识增量或行为发布，不需生产回退。未来实际实现须按真实commit逆向恢复对应增量，保留原日志、反证、经验与并行刷新；测试和实际live合入后才可登记implemented，shipped交运维核实。

'''+ '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal)
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
table = '\n'.join('| ' + m['stream'] + ' | ' + ' | '.join(str(m['counts'][r]) for r in dispatch['runs']) + ' |' for m in manifest)
report = f'''# 静默策略队列核证报告

批次：20261016-004302-strategy-proposal。基线：`{base}`；开工干净，普通批次合并main返回Already up to date，HEAD不变。调度reason=proposal，有十个proposal_ids、无research_request/implementation_request，不承接另一专题。原请求不写入。

十项完整提案均waiting；没有源码、知识或游戏规则修改。`fixes=[]`、`merged=null`；无提交、合入、版本分配或shipped声明。完整逐项证据、账本、反例、预期行为、验证及回退在[proposal.md](proposal.md)。所有十份原Markdown与队列SHA匹配。实际原生线程`01a14072-2f4f-78e0-92ae-95961d857efb`的turn_context核为gpt-6.1-sol/xhigh、workspace-write、network_access=false、approval_policy=never；普通服务档来自启动命令。正文high与原生xhigh不一致保留，未改设置/线程。详见runtime-readback.json。

## 冻结证据与范围

| 流 | NHA2KW0RB7VP | P74C04AEPL1F | G33HU22H2543 | RC61MFQM63Y6 | BTSRF7JL1W1Y |
|---|---:|---:|---:|---:|---:|
{table}

共6606行，逐行读回原日志指定字节验证JSON及SHA，显式身份与角色一致；byte-verification.json保留结果，evidence/evidence-manifest.json保留各流source_size、计数和输出SHA，逐条材料保留offset/bytes/SHA。扫描源范围内states有2个非法JSON行、decisions有2个、brain有1个；这是入口全扫描的计数，不归给本批选中行。本批选中行均解析/身份/字节相符，不能由全流非法行判当前产品缺陷。

fight-plans在2233957字节截点选中0行，只表示该截点未选到显式所属本批的行，不能推断历史日志/计划不存在。没有复核旧run-plans截点或覆盖旧零行初稿。抽取原件与extraction.log保留。

语义分析以十项提案涉及的窗口为界，保存105精选状态、12精选决策及完整本批状态索引；74材料断言全部通过，不声称6606行逐项全语义审计、全候选认证、完整整战模拟或全历史量化完成。

## 主要核证与限制

- NHA F33同首手按可操作30血/敌408比较，28血/敌428是更早过渡帧。原T1实损1/敌净扣8，替线实损7/净扣24；即时多16伤多损6血成立，缺同条件整战与能力累计收益。
- RC F33同52血、同手牌，T1原线挡16/实损4/扣30；替触媒挡12/实损8/扣23。原题279021为3轮2样本、末题279197为5轮24样本，不把首题冒成24/24。原提案字节保留，沿已有修正边界向ops报告该可比性限制。
- P74 F23末次弃精确后，1血16挡面对石16+卵8，石虫眩晕与玩家被卵杀死同时成立，卵毒后余2。当前费用/手牌快照不是四个动态分支的完整重算；保留精确后的整战未知，不以当帧7伤替代变化后的牌面。
- P74 F22赢战53→9、T2/T4实际损20/24，寄生归零再21；9血空药接F23。G33千足虫83→46、恶魔76→17均胜；RC二幕三火实回63、F29赢战耗31、末火至52。均是实际资源链，不推出改路线或留药必胜。
- BTS F31醒虫攻击18→20→22，末轮14血/5牌挡+1覆甲对22，毒后甲虫剩13而玩家死。最终新选线3/4样本胜本就包含1/4死亡；没有逐样本动作/抽序与实际线配对，不因一次死调概率权重或强制杀序。

这些是对原观察的复核，不新增游戏假设或另一角色知识。没有新的反机制实帧；未控的因果与原反例仍保留。旧亲历预算差/dirty源码/完整归属缺口不因本报告关闭，亦不关闭学习入库或量化父要求。

## 已有源码边界

只读live核对点：`{source['live']}`。16个相关源码叶13个字节相同，card-model.ts、sl/explore.ts、sl/judge.ts的历史Roy/Dai注释差保留，未覆盖。source-readback.json记每叶SHA与真实live祖先来源；source.diff.patch为本分支相对base的空源码差量。当前树读回不代表复原五局原dirty树。

投斧首牌键、普通生存者唯一单弃、弃牌后继失效提示、弃后手牌/单卡费用快照、SL模型资源比较及选择/派发审计等窄实现，可核到真实main/live祖先源码`{old_source}`。持牌损血事实后续窄来源`05cd292c6f01bb31e406473d3a9843e659d62b93`亦为live祖先。报告不把整个宽提案登记duplicate或implemented：当前快照明确不推演弃牌后伤挡/胜负；selection_dispatch只证单动作回执，state_effect_verified=false、whole_plan_executed=null。仍缺跨重规划完整归属、完整联合消费者和同条件后续校准。

## 验证、登记与交接

无生产改动，tsc/vitest/cases均null；未运行沙箱生产套件，未做撤源码失败/恢复通过，不伪造测试或部署。74/74是固定证据材料检查（material-checks.json、material-checks.log），不计入生产tests。byte-verification-final.log是修正开场“过渡帧/可操作帧”显示区分后的材料再读回；首次opening-turns.initial.json保留，原证据不变。

路径定位失败、首轮摘要误将combat=null视作对象、个别历史决策无questions键，以及工具输出截断均属本次材料探针；随后按实际路径/schema纠正，原工具转录保留，不登记新产品bug。没有网络、LLM模拟、play、推送、依赖安装或下级agent。

经根目录ledger.py update，仅为32个既有本角色关联账本追加本批proposal/report链接及waiting说明，不追加重复证据、不改claim/首证/prior/原状态/版本，不把既有shipped降回proposed。CLI输入、回执及前后保护验证保存在ledger-updates.jsonl、ledger-update.log、ledger-preservation.json。没有新代码提案id；最终code_proposals沿用十个真实CLI原id，implementation_domains为空。

请运维逐项读回proposal-results.json；保持原十项等待新证据，沿原ops→watcher→Roy链保留已知预算可比性及未知限制，不把队列登记当已告知/已确认。无需源码合入、发号或补造测试；本批工作树HEAD与base一致且git status干净，scratch为忽略材料。报告结束不关闭原宽项或父要求。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-004302-strategy-proposal',
          'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': list(props),
          'implementation_domains': [], 'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
updates = []
for ledger in sorted({i for x in props.values() for i in x['original']['ledger']}):
    linked = [r for r in results if ledger in props[r['id']]['original']['ledger']]
    updates.append({'id': ledger, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261016-004302-strategy-proposal：仅核本批五个Silent A10原局，6606行字节身份读回及74材料断言；无新源码/经验/证据计数，不改原claim/首证/prior/status/version。' +
                            '；'.join(r['id'] + ' waiting：' + r['reason'] for r in linked)})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'proposals': len(results), 'ledger_updates': len(updates), 'report': result['report']}, ensure_ascii=False))

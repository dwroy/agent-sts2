import itertools
import json
from pathlib import Path

out = Path(__file__).resolve().parent
ready = {}
for line in (out / 'evidence/states.evidence.jsonl').open():
    e = json.loads(line)
    c = e['row']['state'].get('combat') or {}
    ready[e['line']] = (c.get('action_readiness') or {}).get('can_use_combat_actions') is True
states = [json.loads(line) for line in (out / 'state-index.jsonl').open()]
groups = [list(v) for _, v in itertools.groupby(states, key=lambda s: (s['run_id'], s['floor'], s['turn'], s['in_combat']))]
results = []
for ga, gb in zip(groups, groups[1:]):
    aa, bb = [s for s in ga if ready[s['line']]], [s for s in gb if ready[s['line']]]
    if not aa or not bb:
        continue
    a, b, last = aa[0], bb[0], aa[-1]
    if (a['run_id'], a['floor']) != (b['run_id'], b['floor']) or b['turn'] <= a['turn']:
        continue
    run = a['run_id']
    wanted = ((run == 'TXZ6RVMQA09D' and a['floor'] == 48 and a['turn'] == 6)
              or (run == 'WQZVENQ7DTRP' and a['floor'] == 33 and a['turn'] in [7, 9])
              or (run == 'NHA2KW0RB7VP' and a['floor'] == 33 and a['turn'] == 1))
    if wanted:
        results.append({'before': a, 'last_ready': last, 'next_ready': b,
                        'net_hp_loss': a['hp'] - b['hp'],
                        'enemy_net_loss_including_next_start': sum(e['hp'] or 0 for e in a['enemies']) - sum(e['hp'] or 0 for e in b['enemies'])})
(out / 'ready-turn-boundaries.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
for v in results:
    a, b = v['before'], v['next_ready']
    print(a['run_id'], a['turn'], a['line'], b['line'], 'hp_loss', v['net_hp_loss'],
          'enemy_net', v['enemy_net_loss_including_next_start'], 'last_block', v['last_ready']['block'])

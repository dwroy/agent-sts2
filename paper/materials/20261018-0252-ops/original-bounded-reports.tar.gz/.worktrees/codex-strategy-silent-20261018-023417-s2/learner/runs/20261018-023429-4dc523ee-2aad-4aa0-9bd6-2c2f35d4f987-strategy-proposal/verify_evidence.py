import collections
import hashlib
import importlib.util
import json
from pathlib import Path

out = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extractor', out.parents[1] / 'extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((out / 'evidence/evidence-manifest.json').read_text())
verified = []
for item in manifest:
    path = out / 'evidence' / (item['stream'] + '.evidence.jsonl')
    counts = collections.Counter()
    digest = hashlib.sha256()
    total_bytes = 0
    with path.open('rb') as selected, (Path('/home/dw/Projects/agent-sts2/logs') / (item['stream'] + '.jsonl')).open('rb') as source:
        for raw in selected:
            digest.update(raw)
            e = json.loads(raw)
            assert e['offset'] + e['bytes'] <= item['source_size']
            source.seek(e['offset'])
            original = source.read(e['bytes'])
            assert hashlib.sha256(original).hexdigest() == e['sha256']
            row = json.loads(original)
            assert row == e['row']
            assert extractor.run_identity(row) == e['run_id']
            counts[e['run_id']] += 1
            total_bytes += e['bytes']
    assert digest.hexdigest() == item['output_sha256']
    assert {k: counts[k] for k in item['counts']} == item['counts']
    verified.append({'stream': item['stream'], 'source_size': item['source_size'], 'lines': sum(counts.values()),
                     'raw_bytes': total_bytes, 'hashes_verified': True, 'identities_verified': True})
(out / 'evidence-verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_lines': sum(x['lines'] for x in verified), 'streams': len(verified)}, ensure_ascii=False))

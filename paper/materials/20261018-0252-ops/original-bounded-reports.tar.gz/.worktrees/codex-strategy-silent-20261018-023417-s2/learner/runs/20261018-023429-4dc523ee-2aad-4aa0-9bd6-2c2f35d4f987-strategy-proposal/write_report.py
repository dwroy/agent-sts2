import datetime
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
batch = '20261018-023417-s2-strategy-proposal'
base = 'd8d25fcc6542ad703a7aa183ef5bdd95d5dc0563'
dispatch = json.loads((out / 'dispatch.json').read_text())
events = json.loads((out / 'queue-events.json').read_text())
sources = json.loads((out / 'proposal-source-manifest.json').read_text())
audit = json.loads((out / 'source-audit.json').read_text())
manifest = json.loads((out / 'evidence/evidence-manifest.json').read_text())
verified = json.loads((out / 'evidence-verification.json').read_text())
cases = [
    ('08eaa60bcc449852', '胜战用药与真实回复',
     'KEN58SH9SLZ6 A10：F3 T2、F4 T1、F5 T2、F11 T1/T2、F15 T1共7次实饮；states 280206→280207等七对与逐项动作联接见 drink-action-linkage.json。F12 states 280336→280337为26/76→53/81，F16 280382→280383为46/81→75/86，实回27/29。',
     'F15零净损同时饮两药，不能据零损认定不用也零损；SL复原不当路线回复。',
     '缺同入口、同牌组及后续动作下不用、早用或留药到Boss的成对整战结果；七次实饮与两次真实回复不足校准持药价。',
     '保持持药及饮用阈值；后续先隔离机制误差，以独立局时间留出验证不用/早用/留药后的退出HP、药栏与下一战。'),
    ('92920295a648b540', 'SL首战与两战资源',
     'TXZ6RVMQA09D A10 F48：第二/三试T6 states 281479→281484、281535→281539同为48HP起，实损3/0、敌净扣36/27；decisions 275383—275385记录换线和执行。F48 T10 states 281563/281564剩4，F49 states 281565→281566为4→0。',
     '少损3同时少伤9，后续抽序/生成亦变；首战胜不等于两战通关，低可信模拟不替代严格必死证据。',
     '缺保持后续抽牌、生成、选择、药栏及复活资源的两战成对结果；现有首战资源接续实现不能证明SL新线更优。',
     '保留两战目标和严格SL规则；固定三尝试只作一个局的资源链审计，未来用独立静默A10后移样本验证。'),
    ('a327449c331efbc1', '沙虫输出、血价与截止',
     'WQZVENQ7DTRP A10 F33第二/三试T9：states 282075→282079、282144→282148同26HP/敌184，损13→22、敌净扣24→39；decisions 275894/275960。末试T7 282330→282336损4、净扣24；对照第二试282066→282072损0、净扣24，原提案对应沙坑延一轮。',
     'T9多15伤付9血，T7支付4血有延时；不据全败认同安全，也不一律禁止付血延沙坑。',
     '已有当轮损血、伤害、毒及沙坑差额诊断；仍缺固定后继、同预算整战胜负和独立胜局，不能拟合血伤或延时排序阈值。',
     '保留生产探索门槛与并列信息；诊断列原线/替线的预测差额和未知，须完整执行归属与同预算后继后才评估排序更改。'),
    ('a099e89437e942bb', '狡诈容量、保留与穿插',
     '九局42次CUNNING_POTION实饮均经动作联接：37次添3、2次添2、3次添0，新增牌均为SHIV升级。WQZVENQ7DTRP A10 F33第5/6试T11八手三饮添2/0/0、五手添3/2/0；其余八局按原各自A7/A9/A10分列。',
     '满手续喝仍耗瓶且不添牌；固定模型能枚举穿插不代表自然完整执行或整战得救。',
     '生成、手位截断和固定穿插枚举已有实现；缺计划妥当保留、跨抽牌重问、SL恢复以及候选到实际完整穿插序列的联合验证。',
     '保留已有3/2/0生成模型，不另定留药阈值；补齐保留/选择/饮用/重读的完整日志与消费者，再按同局分组验收后继。'),
    ('47910f82a1fdd98f', '开场失血与连战联合边界',
     'TXZ6RVMQA09D A10 F49 T1 states 281565→281566为4→0、敌TEST_SUBJECT仍111；同局F43/45/46/48原提案记录出牌前净失4。WQZ F33 T9/T7的血价、毒和沙坑对照见上述固定端点。',
     '持血瓶的旧组合净2不拆为单件；未知回血/复活与SL恢复不套净4，不能重复扣现场已发生开场成本。',
     '受限王室猛毒开场与同样本HP/药水/复活接续已有实现；缺未知回血或复活组合时序、留药与SL后继及两战联合校准。',
     '仅沿已有观测组合计算新战入口，现场与SL不重复扣；未知组合不扩白名单、不放宽SL。'),
    ('f1374df72d8e6a25', '胜战退出资源与药效期限',
     '1913SE84AXQF A10 F29胜后46接F31；Q6M2Y34MWKRE A10 F8 T7 states 282900—282903为33血、5挡和6活力现场，后F8赢剩2接F9 T2死亡；F2早喝双挡仅候选，F8 T1速度当轮建立临时敏捷，次轮消失。',
     '候选未完整实打；Q6两药已实饮、F5/F6零损，1913路线F24改锻造使投影条件变化；不从这些局拟新药价。',
     '缺隔离紧勒等机制误差后、同入口同预算的不用/早用/留药整战及下一战成对结果；局部候选不足支持药价或终局权重更改。',
     '保留现药价与终局权重，区分实建永久能力、临时层和未到营火；后继资源必须同一样本接续。'),
    ('38a49e6c97f31eea', '紧勒、磨蚀与增益分源',
     'Q6M2Y34MWKRE A10 F8 T4 states 282887—282892普通紧勒链：敌103→95→85，弃牌选择完成后83、毒后80。1913SE84AXQF A10 F31 T2 states 282767→282768弃磨蚀、能量3不变、建1敏/4荆棘；F12 T3另有282552→282553同局窗口。',
     '两次磨蚀窗口仍只是一局；普通紧勒无挡分支不扩升级、叠层、自动触发或有挡交互。建立增益不回填旧挡或尚未发生的毒。',
     '普通紧勒及普通磨蚀出牌属性已有子实现；弃磨蚀、常驻/临时增益、再生/自动触发与SL恢复的联合输入、消费者及完整后继未齐。',
     '保留已验证子公式；先冻结明确弃牌身份与完成时点、重读后状态及后继输入，不能把出牌模型当弃牌模型或自动建立能力。'),
    ('ef0e38a5dbd3bc07', '路线营火与未兑现能力',
     '1913SE84AXQF A10 F24锻造不回血、F28回21、F29赢61→46、F31死，F32未来营火未抵达；Q6M2Y34MWKRE A10 F7休36→57、F8赢损55剩2、F9死。证据各流按run精确抽取，原路线与限制见已校SHA原Markdown。',
     '敌人、构筑、事件和实际营火动作不同；未到火不计到账，计划未取得能力不计已建立；相关性不当改线因果。',
     '缺另一营火动作、事件/路线及用药时点的受控完整结果；路线条件变化和敌人、构筑混杂不足支持路线或终局参数拟合。',
     '保持原规则；按实际节点和独立局时间切分审计，要求替代整条资源链，不能以两个失败反推路线阈值。'),
    ('7f820c02d39bfaea', 'SL饱和与完整执行归属',
     'NHA2KW0RB7VP A10 F33 T1：前四试就绪端点283391→283397、283412→283418、283434→283440、283456→283462均30→29；第五/六试283478→283483、283502→283507为30→23，末挡14/8，跨轮敌净扣8/24。decisions 277248/277250及277272/277274记录替换/重放。',
     '最初候选含精确切击，但它被生存者弃掉后重问；题面伤害不等完整轮，跨轮净扣含抱抱先生自动伤。六试同局均败。',
     '当轮诊断已有实现；缺同预算饱和排序校准、跨弃牌完整执行归属和成对整战后继，不能由六次失败确定新SL门槛。',
     '保留B2/rollout门槛，分别记录原答、覆盖、选择完成和真实执行；独立局验证前不声称换线改善或原答必胜。'),
    ('04b6b430759815ed', '油灯首次消费与动态公式',
     'NHA2KW0RB7VP A10 F33 T1普通X1萎靡建−2力/2弱，F17 T1毒药5→10；K3676LU8B0UH A1 F30 T2带毒刺击4→8，SADL3CGYTGSR A7 F45毒药5→10。NHA F33 T2爪正面显示1、背面2，F17 T1精确切击七/六/五手1/3/5，均按本角色本进阶现场。',
     '已取整显示1再乘1.5不等实际2；拥有能力不等已兑现；旧运行树dirty不可完整重建，不外推零X、升级、叠层或所有负面状态。',
     '蟹朝向和普通精确切击已有受限实现；油灯首次消费跨动作、新战/SL恢复缺联合状态与消费者，X值、升级、叠层及能力完整后继仍未覆盖。',
     '保留已验证动态公式；先获得可追溯首次消费标记及跨动作/新战/SL状态再评估，不按单帧存在油灯就持续翻倍。'),
]
assert len(cases) == len(dispatch['proposal_ids']) == 10
assert {f'silent-proposal-{c[0]}' for c in cases} == set(dispatch['proposal_ids'])
assert all(s['sha256'] == s['registered_sha256'] for s in sources)
assert sum(x['lines'] for x in verified) == 19929
results = [{'id': f'silent-proposal-{c[0]}', 'state': 'waiting', 'reason': c[4]} for c in cases]
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch,
          'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': ['combat', 'potion', 'sl', 'terminal'],
          'proposal_results': results, 'report': str(out / 'report.md')}
(out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
intro = f'''# 静默猎手本批十提案复核

时间：{now}。批次：{batch}。角色：silent。来源任务：原 postmortem / experience-update；实现任务：本 strategy-proposal。

结论：十项各自保持 waiting。本批没有新增可上线的完整策略依据或源码实现；不重复创建提案 id，不把已有子实现核销成父提案整体 implemented/duplicate。

基线及最终 HEAD：`{base}`。开工 git status 干净，普通任务执行 `git merge --no-edit main` 返回 Already up to date。根 learn.json 对应行 task/character/worktree/十个 proposal_ids 均匹配，reason=proposal，没有 research_request/implementation_request/proposal_repair；普通专题条件不匹配，不承接旧专题。十份保存Markdown的SHA全部与原队列一致。

只使用已分配十项提案所链接的十五个本角色局：派发十锚点，加原提案内 SADL3CGYTGSR、1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH。runs.jsonl 均有且角色 SILENT；十二局A10、F4QKG4J1AJJZ为A9、SADL3CGYTGSR为A7、K3676LU8B0UH为A1。没有把多次SL、相邻帧或模拟样本当独立局，亦未扩展到其他队列或角色知识。

## 原始证据与校验

通过本工作树共用 learner/extract_evidence.py 一次抽取八流，各流独立冻结 source_size，逐行存原流 line/offset/bytes/SHA256/身份/正文。随后从只读原日志按字节 seek 回查全部19929行、原JSON、无冲突身份和抽取文件摘要，全部相同；不是tsc/vitest或生产策略测试。完整参数及源截点在 evidence/evidence-manifest.json，复查在 evidence-verification.json、verify-evidence.stdout.txt。fight-plans本截点选到0行，只表示这一截点没有这些身份的所选记录，不声称原日志缺失。

| 流 | 原字节截点 | 本批相关行 |
|---|---:|---:|
'''
for m in manifest:
    intro += f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} |\n"
intro += '''
全部166次战内药瓶消耗已用相同run/ts联接唯一use_potion实际动作；42次狡诈饮用与37×3、2×2、3×0新增数一致，不把弃药计入。详见drink-action-linkage.json。状态算术使用就绪帧与连续回合分段，见ready-turn-boundaries.json。初轮检查的StopIteration、校验脚本相对路径错误及NHA初轮端点误混已记录在inspection-limitations.txt；原三个turn-boundaries.json初稿保留，正式以ready版本为准。NHA未就绪28HP帧不作30HP实际可操作入口，开场自动扣血不归单张牌。

## 实际 live 子实现范围

'''
intro += f"本次只读冻结 live=`{audit['live']}`，不表示本批合入。source-audit.json保存八份相关源码与live的SHA、main-live-scope-diff.patch及祖先核验；三文件差异均为旧称谓注释，未据此改文件。\n\n"
components = [
    ('0e4fe4df89a06682468e0e4716c12126e76369d5', 'SL当轮沙坑差额诊断，保留execution=unverified；不改变探索门槛。'),
    ('1698adc96ba434a46942321e0237b70657e625b2', 'SL原线/替线资源差额及未知边界；不认证完整自然执行。'),
    ('5b56a452bb9be14d620b368ec46974c1b57901ca', '已集成狡诈生成、受限开场及连战资源相关实现；不等于本批父提案整体已验证。'),
    ('66283dd9982bdd7f480da7a4d9bfefea0572a9ac', '已集成普通紧勒与连战适配相关源码；未证明跨选择完整后继。'),
    ('8b9bacbebb20eaaa1133a9945da6c7abfcda745d', '普通精确切击既有动态手数子公式。'),
    ('a5f588dfdb3fd254fded2d6cacb646672b90cc14', '普通磨蚀出牌属性；不当成弃牌属性已接线。'),
    ('ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8', '观测组合范围内王室猛毒新战开场；不是任意回血/复活组合顺序。'),
]
assert all(x['is_live_ancestor'] for x in audit['ancestor_checks'])
for commit, text in components:
    intro += f'- `{commit}`：{text}\n'
intro += '''
上述七个40位提交均核为冻结实际live祖先。读取现有silent-cunning、silent-strangle、silent-abrasive、silent-precise-cut-seven、silent-sl-resource-comparison测试源码只帮助界定已有实现范围，没有运行这些测试、没有借历史绿灯报本批成功。对应既有经验26条只读选择存experience-selection.json，不新增/改写经验内容、不声称大脑自然采用。

## 逐项处置

'''
proposal = intro
table = '| 原提案 | 账本 | 处置与具体缺口 |\n|---|---|---|\n'
for suffix, title, evidence, counter, reason, expected in cases:
    id = f'silent-proposal-{suffix}'
    original = next(e for e in events[id] if e['op'] == 'add')
    ledger = '、'.join(original['ledger'])
    table += f'| {id} | {ledger} | waiting：{reason} |\n'
    proposal += f'''### {id}：{title}

关联账本：{ledger}。原文：original-proposals/{id}.md（SHA见proposal-source-manifest.json）。

证据局/层/回合及支持：{evidence}

反例、混杂与未知：{counter}

旧行为/本批新行为：保留现有生产规则与已上线子公式，本批没有新增行为。当前处置waiting：{reason}

预期行为及验证方法：{expected} 不在发现局内拟合再冒称样本外；用独立局按时间划分，先冻结输入、对原线/替线完整执行与资源后继校验，不使用刷新知识JSON或在线LLM补结果。

回退及影响：没有新源码可撤、没有已验证胜率影响；未来实际实现须独立提交，固定消融失败/恢复通过及沙箱入口验证后才合live，并按授权记版本和双通知。其他角色及未观察进阶保持等价。

'''
(out / 'proposal.md').write_text(proposal)
report = intro + table + '''
## 交付与限制

逐项支持、反例、预期行为、验证和回退完整保存在同目录proposal.md，原十份Markdown、源SHA、queue-events.json、31账本原事件、只读源码和全部原始抽取均保留。本批未修改生产源码或知识数据，没有运行生产检查，tsc/vitest/cases统一null，未撤源码/恢复测试，未git commit、未live merge、未分配新版本或标shipped。没有改学习任务模板、知识、源日志、运维prompt、配置或当前对局。

现证据只支持有条件的局部机制与资源观察；没有同入口、同后继的整战因果或新策略独立验证。未观察的组合、首次消费状态以及跨抽弃选择/SL恢复消费者保持未知，不能由框架或诊断已上线推定量化学习完成。父提案保留待后续新局重派，不关闭任何父要求。本批不重复写历史复盘、不新增重复提案/账本发现。

账本仅通过根learner/ledger.py update追加本批提案/报告追溯链接和审计说明，不追加旧证据为新support，不变claim、first_run、asc、prior、effect、version或status（特别不降级已shipped条目）。输入与CLI回执存ledger-updates.jsonl/ledger-update.stdout.txt，完成后进行只读保护字段回查。没有源码提交，gitleaks只扫描本批产物；报告与检查原始结果分别保留，不把产物扫描当生产测试。

运维应读取本报告、proposal.md及result.json逐项保存waiting；本次merged=null，没有需要登记shipped的新增实现。

'''
report += '提案绝对路径：' + str(out / 'proposal.md') + '\n\n'
report += '```json\n' + json.dumps(result, ensure_ascii=False, indent=2) + '\n```\n'
(out / 'report.md').write_text(report)
links = {}
for id, es in events.items():
    for ledger in next(e for e in es if e['op'] == 'add')['ledger']:
        links.setdefault(ledger, []).append(id)
with (out / 'ledger-updates.jsonl').open('w') as f:
    for ledger, ids in sorted(links.items()):
        row = {'id': ledger, 'by': 'learner:strategy-proposal',
               'where': {'proposal': [str(out / 'proposal.md'), str(out / 'report.md')]},
               'note': f'{batch}只读复核：关联' + '、'.join(ids) + '。原提案SHA/本角色原日志字节及实际live子实现祖先已核，具体剩余缺口见本批proposal.md；父提案waiting，未新增源码/合入/版本/生产测试或shipped，不重记旧证据support，原状态与知识结论保持。'}
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
print(json.dumps({'proposals': len(results), 'ledger_links': len(links), 'base': base, 'report': str(out / 'report.md')}, ensure_ascii=False))

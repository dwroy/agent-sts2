import collections
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent


def powers(raw):
    return {p['power_id']: p.get('amount') for p in (raw or [])}


def compact(e):
    row = e['row']
    s = row['state']
    run = s.get('run') or {}
    c = s.get('combat') or {}
    player = c.get('player') or {}
    return {
        **{k: e[k] for k in ['line', 'offset', 'bytes', 'sha256', 'run_id']},
        'ts': row.get('ts'), 'floor': run.get('floor'), 'turn': s.get('turn'),
        'screen': s.get('screen'), 'in_combat': s.get('in_combat'),
        'ascension': run.get('ascension'), 'character': run.get('character_id'),
        'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
        'energy': player.get('energy'), 'block': player.get('block'),
        'powers': powers(player.get('powers')),
        'potions': [(p.get('slot', p.get('index')), p.get('potion_id')) for p in run.get('potions', []) if p.get('occupied')],
        'hand': [(c.get('index'), c.get('card_id'), c.get('upgraded')) for c in c.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'powers': powers(e.get('powers'))} for e in c.get('enemies', [])],
    }


states = []
with (OUT / 'evidence/states.evidence.jsonl').open() as f, (OUT / 'state-index.jsonl').open('w') as dest:
    for line in f:
        item = compact(json.loads(line))
        assert item['character'] == 'SILENT'
        states.append(item)
        dest.write(json.dumps(item, ensure_ascii=False) + '\n')

drinks = []
abrasive = []
heals = []
for a, b in zip(states, states[1:]):
    if (a['run_id'], a['floor']) != (b['run_id'], b['floor']):
        continue
    if a['hp'] is not None and b['hp'] is not None and b['hp'] > a['hp']:
        heals.append({'before': a, 'after': b, 'delta_hp': b['hp'] - a['hp']})
    if not (a['in_combat'] and b['in_combat'] and a['turn'] == b['turn']):
        continue
    pa, pb = collections.Counter(map(tuple, a['potions'])), collections.Counter(map(tuple, b['potions']))
    removed, added = list((pa - pb).elements()), list((pb - pa).elements())
    if len(removed) == 1 and not added:
        drinks.append({'potion': removed[0][1], 'before': a, 'after': b,
                       'new_hand_cards': list((collections.Counter(map(tuple, b['hand'])) - collections.Counter(map(tuple, a['hand']))).elements())})
    if (any(c[1] == 'ABRASIVE' for c in a['hand']) and not any(c[1] == 'ABRASIVE' for c in b['hand'])
            and a['powers'] != b['powers']):
        abrasive.append({'before': a, 'after': b})

specific = set(range(281563, 281568)) | {282075, 282144} | set(range(282330, 282337)) | set(range(282887, 282894))
windows = [s for s in states if s['line'] in specific]
for run, floor, turn in [('NHA2KW0RB7VP', 33, 1), ('NHA2KW0RB7VP', 33, 2),
                         ('NHA2KW0RB7VP', 17, 1), ('KEN58SH9SLZ6', 12, None),
                         ('KEN58SH9SLZ6', 16, None), ('Q6M2Y34MWKRE', 8, 7),
                         ('Q6M2Y34MWKRE', 8, 8), ('Q6M2Y34MWKRE', 9, 2),
                         ('1913SE84AXQF', 31, 2), ('TXZ6RVMQA09D', 48, 6),
                         ('TXZ6RVMQA09D', 49, None)]:
    windows.extend(s for s in states if (s['run_id'], s['floor']) == (run, floor) and (turn is None or s['turn'] == turn))
windows = sorted({s['line']: s for s in windows}.values(), key=lambda s: s['line'])
summary = {
    'states': len(states), 'runs': dict(collections.Counter(s['run_id'] for s in states)),
    'drinks': drinks, 'abrasive_transitions': abrasive, 'hp_increases': heals, 'windows': windows,
}
(OUT / 'state-analysis.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'states': len(states), 'windows': len(windows), 'drinks': len(drinks),
                  'cunning': len([d for d in drinks if d['potion'] == 'CUNNING_POTION']),
                  'abrasive_transitions': len(abrasive)}, ensure_ascii=False))

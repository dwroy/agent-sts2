# 静默猎手策略提案复核：保留十项等待

本批为 20261018-023417-strategy-proposal。只处理 dispatch.json 的十个 proposal_ids；reason=proposal，无 research_request、implementation_request、proposal_repair，普通专题绑定不成立。未领取其他项。初始 git status 干净，git merge --no-edit main 返回 Already up to date，基线为 d8d25fcc6542ad703a7aa183ef5bdd95d5dc0563。六局身份由 runs.jsonl 核为 SILENT/A10；大小写归一仅用于身份核验。

结论：本次无足够新增证据支持策略源码变化，十项均 waiting。诊断子项已有实际 live 祖先实现，但整项要求还包含完整候选执行归属、实际结算或策略验证，不能登记整项 duplicate/implemented。无新提案 id、源码提交、合入、eval 版本或 shipped；铁甲及其他角色未改变。未拟合权重、血量门槛或留药价，未将模型输出当实盘反事实。

## 本批证据及限制

- 原提案十份 Markdown 已按队列 proposal_sha256 全部核同，原字节副本见各 silent-proposal-*.md，原 add 与最近处置见 queue-input.json；来源角色和每项账本链接均核对。
- 共用 extract_evidence.py 提取八流，保存逐流 source_size、每行 offset/bytes/SHA 与身份。总计 8,444 个唯一原始行：states 4,167、decisions 4,071、sl-attempts 43、run-config 6、run-plans 21、brain 130、runs 6、fight-plans 0。另一次小流预提取 evidence-fast 与正式结果逐流同截点、同SHA，不重复计样本。
- 所有入选行重新按原偏移读取并核 bytes/SHA、正文及明确所属局，输出文件SHA和计数均通过；见 evidence-verification.json。该校验是材料完整性校验，不是生产测试。states、decisions、brain 的全源扫描各有2条无效JSON，不能归给指定六局或据此称六局不存在；fight-plans 的0仅表示该截点未选到。
- 六局全部分析；跨进阶、其他角色、未派发的新局未纳入。七组回合边界差值见 paired-turns.json，七组同指纹决策见 paired-decision-fingerprints.json。原始SL summary和真实状态共同保留，净血差不冒充分源毛伤害，判死截断不算已结算敌伤。

## 核实的局部取舍与反例

| 局号 / 层 / 回合 | 原试→替试 | 己方净损血 | 敌方净扣血 | 限制 |
|---|---|---|---|---|
| 751FN9QM9MHQ F17 T2 | 1→3 | 13→18 | 9→18 | 多9输出付5血；B2 .195/.193为配对误差内，不是实胜率 |
| 751FN9QM9MHQ F17 T7 | 2→4 | 13→23 | 12→18 | 多6输出付10血；题面19/29含未决弃牌保守项，实际两线各少6 |
| 751FN9QM9MHQ F17 T13 | 1→6 | 8→2 | 17→11 | 省6血少6输出；不能只凭最低损血定优劣 |
| KV0JHNJCKXLS F33 T5 | 4→5 | 0→0 | 36→29 | 删毒药输出下降，没有已记录的当轮保血收益 |
| KV0JHNJCKXLS F33 T1 | 1→6 | 0→0 | 28→14 | 净输出下降；后轮不同，不能单步归因整战 |
| KEN58SH9SLZ6 F17 T10 | 4→5 | 15→21 | 2→4 | 无实体下多6血仅多2净扣；B2 .385→.127为模型配对 |
| KEN58SH9SLZ6 F17 T5 | 4→6 | 7→5 | 1→2 | 省2血却把步法从T5推迟至T9，追加小刀计在整轮净扣中 |

751和KEN各六试均未胜，六试不是六个独立局。KEN T5反例排除“只取最少当轮损血恒优”；其他后轮动作及抽序变化排除把整战成败归于单个换线。历史经验来源和本批复盘/经验重复提案不增加独立样本数。

751 F13 T3 decisions272361：plan2用肌肉药水、plan3本轮不喝但后轮7/8样本仍喝、plan5全程无药须分开。plan2/plan5均五轮8/8胜、预测损8，伤26/16，预计终结约2.3/2.9轮。实际只走用药线，states278403→278404槽0消失并建5力量，下一轮58→50。该事实不证明留药值0，也不证明当时喝药错误。

YQL8RZ8BWN1E F17末试T10 states280160→280161：毒水后残壳毒2→8，血26、挡13、自爆41均未变，不能称为减伤6或本体进度。本体虽已结束，整战未胜；26+13−41为−2预算，死亡帧截断0另列。L9SGRBB5R698旧anchor记近十亿占位血，PU80F84P6HPN第5试F17确有胜局（末血2），但多处动作和后继变化，不能作为改序的受控收益证明。阶段规则、排序和最后行动后资源分别核，不用轮初快照冒充最终缺口。

KEN58SH9SLZ6七次耗药：F3T2槽0攻击药、F4T1槽0稳定血清、F5T2槽0速度药、F11T1槽1虚弱药/T2槽0攻击药、F15T1槽1发光水/槽0技能药。selected-states.json保留七组槽位前后、HP、手牌/增益及选牌状态，selected-decisions.json保留请求；F17六次75/86空药入口。随机生成、抽牌后重问与整条候选兑现不同；没有不喝/留到Boss的实盘分支，不能将全部未来收益填成已实现。

## 现有代码的实际范围

观察 live 提交 523fbcd34667a531e40e58aae877062fc3d9b99e；source-audit.json 固定该提交并核12个路径的SHA和各自源码提交祖先。十个文件与本树字节一致，potion-cost.ts / explore.ts 的差异仅注释 Roy/Dai 署名，完整差异见 live-source-differences.patch。

- 资源预测：0e4fe4df89a06682468e0e4716c12126e76369d5，silent-sl-resource-comparison.ts。scope=current_turn_prediction、execution=unverified；不是实际资源归属。
- 候选预测：a8b1f8be153fe4f3a34146117546c2178f2e446b，silent-sl-comparison.ts。actual_turn_result=null。
- 选择及持牌拆项：05cd292c6f01bb31e406473d3a9843e659d62b93，silent-selection-audit.ts / silent-held-loss.ts。未决弃牌仍保守，actual_turn=null、actual_held_hp_loss=null，不预扣呼唤。
- 首次派发：bade647f9fe4c9103b40e2f26b26296692ad24b7，silent-selection-dispatch.ts。scope=single_action_receipt、state_effect_verified=false、whole_plan_executed=null。
- 留药未知及无药参考：04921bd785ac6838066522f91ea0bb6ab95cb6a1，silent-potion-reference.ts。区分本轮无药/抽样整战无药，hold_hp=null不填0。
- 巨兽阶段和毒水局部事实：d5e20aa4dd44168ce30944dfcce74f8322144953，silent-giant-potion.ts；0d092f6b928a6221eabf3516abad25c48ceaac9c，sl/attempts.ts。范围受角色/进阶/状态限制；giantFinalResources仅窄已观察修饰符集，不能冒称覆盖YQL全场景。
- live explore.ts的enemyHpLeft/anchorRank仍将原始占位血保作旧排序平局项，同时另列giantPhase.body_hp=0，未把原始占位血归零。缺改序后继验证，保持原规则；不称指标与排序整项已修复。

## 逐项处置

### silent-proposal-366288801d9150d9

来源任务：postmortem → strategy-proposal；证据局：751FN9QM9MHQ；账本：silent-0079, silent-0176。

原目标：异鱼SL同盘换线多9伤付5血、多6伤付10血；补配对B2差与手持惩罚的成本审计，缺完整胜线不拟固定门槛。

处置：waiting。751 F17 T2/T7/T13局部血价已复核，已有候选预测、持牌拆项和单动作回执；缺弃牌/续问后的逐来源实际结算及完整候选归属、固定后继整战对照，不拟探索失血阈值。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-85929bdfc8a3fc1b

来源任务：postmortem → strategy-proposal；证据局：751FN9QM9MHQ；账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。

原目标：分列未决弃呼唤的保守损血来源及肌肉药水持有价值未知，保留同题无药整战对照；本局不足制定留药或改变弃牌的固定规则。

处置：waiting。751 F13 T3实际仅执行用药支线；未知持有价和整战无药参考已有，缺未决弃牌后的完整实际分账、不喝或留到后战的实果，不能定留药价值。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-efd9f83ee9e1a6dc

来源任务：experience-update → strategy-proposal；证据局：751FN9QM9MHQ；账本：silent-0079, silent-0176。

原目标：静默A10异鱼SL配对血价与真实输出审计，保留未知整战胜因

处置：waiting。与366288801d9150d9共享751同局三组配对；已有预测与回执不认证整轮执行，缺完整实际成本归属、受控整战及独立验证，不把重复来源算新样本。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-131042659448ae74

来源任务：experience-update → strategy-proposal；证据局：751FN9QM9MHQ；账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。

原目标：静默A10逐张敏捷、毒/荆棘限伤、呼唤失血及药水持有价值未知的结构分账

处置：waiting。已实现持牌预测、未知留药价与无药参考子项；仍缺敏捷、毒、荆棘及未决弃牌的完整实际收益归属、跨战留药对照，不将子项当整项完成。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-990f054036609447

来源任务：experience-update → strategy-proposal；证据局：KV0JHNJCKXLS；账本：silent-0102, silent-0019, silent-0020。

原目标：SL同盘输出血价、敌回血毛/净伤害与路线休息实际资源分账；缺整战对照不设门槛

处置：waiting。KV F33 T5同盘净扣敌36→29且两线零净损；预测资源对照已有，缺敌回血/能力的完整实际结算归属、固定后继胜线及独立验证，不改SL或路线门槛。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-e18d3f18e6cac2a0

来源任务：postmortem → strategy-proposal；证据局：YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN；账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。

原目标：瀑布巨兽本体／自爆分阶段，纠正SL残血包含不可击杀占位血的指标，并展示自爆阶段毒药水的已观察收益限制；排序改动缺受控后续时保留原行为。

处置：waiting。YQL F17 T10残壳毒2→8而血26/挡13/来袭41不变；阶段事实已有，原始占位HP仍作旧平局项，缺保持后继的改序验证、完整最终资源及提前用药受控结果，不能直接归零改序。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-9733bb80f445aeae

来源任务：experience-update → strategy-proposal；证据局：YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN；账本：silent-0017, silent-0019, silent-0020, silent-0250。

原目标：巨兽本体与自爆分阶段估值；残壳施毒和SL残血不当本体进度。

处置：waiting。与e18d3f18e6cac2a0共享YQL/L9/PU阶段证据；PU第5试胜而多处后继同变，缺改序、提前用药及路线的受控验证，阶段诊断不等于策略完成。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-c51468c5e8ba6668

来源任务：postmortem → strategy-proposal；证据局：KEN58SH9SLZ6；账本：silent-0019。

原目标：核对本局七次实际耗药及75/86空栏boss入口；冻结逐槽位收益验证，缺少未饮用/留药整场对照，保留现行药水规则。

处置：waiting。KEN七次用药请求与槽位消耗已复核；缺随机选牌、发光水重问后的完整候选收益归属，以及不喝或留至Boss的支线，不拟持有价。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-86a7db08d1a31976

来源任务：postmortem → strategy-proposal；证据局：KEN58SH9SLZ6；账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。

原目标：验证SL无实体上留呼唤多损6仅增2伤与步法延迟的兑现成本；冻结同指纹对照，补血价/能力拆项，完整后续与新局证据不足时保留现行排序及护栏。

处置：waiting。KEN F17 T10实损15→21/净扣敌2→4，T5省2血却延后步法；缺完整候选与能力后继归属、固定其余后轮的整战对照及独立验证，不拟统一6血/2伤门槛。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

### silent-proposal-e282a9131b99129a

来源任务：experience-update → strategy-proposal；证据局：KEN58SH9SLZ6；账本：silent-0021, silent-0079, silent-0125, silent-0176。

原目标：异鱼同指纹SL并核持牌血价、无实体实伤与步法建立窗口；完整反事实不足保留探索规则

处置：waiting。与86a7db08d1a31976共享KEN同局两组对照；六试只是一局，缺完整执行归属、受控整战和时间靠后独立验证，不重复实现诊断或关闭探索。

预期行为：保留当前排序、护栏及所有合法选项，仅认可已核实的预测/阶段子项。验证要求：从上述固定帧核完整候选、抽弃/随机选牌/续问和最后行动后的结算，保持其余后轮与随机输入进行成对整战，保留时间靠后的独立静默局验证；不以相关SL同时调参与验收。无足够新证据则继续等待。

## 交付、验证与后续

本批没有改变生产源码、知识JSON、测试或任务模板，HEAD保持基线，baseline.diff.patch为空。未运行tsc/vitest、未作源码消融；tests固定为null，材料校验0不冒充测试成功。没有代码提交，因此无提交前gitleaks记录，不造成功回执。没有合入live或修改eval，不触发上线记录或规则双通知，也不登记shipped。

只经根learner/ledger.py update给原16个本角色条目追加本报告/提案链接和等待说明，不增加重复evidence，不改原claim/首证/进阶/prior/status/version/effect。保留十个原提案id，不调用add创建重复提案；本批proposal_results交原调度器机械登记waiting，未直接修改队列或learn.json。

后续需要的不是固定阈值猜测：补完整候选实际结算与归属、同盘未执行分支及其受控后继；药水需不喝/留后战证据，巨兽需原/新参考排序完整路径与最终行动后资源。新局必须角色匹配且以真实时间留出验证，重复来源和SL重试不能扩大样本量。此报告未关闭任何父请求，未冒称经验已新增入库、大脑已采纳或胜率改善。

回退：本批无运行行为变化；保留本报告、原始证据、历史失败和旧提案即可。需要回退既有实现时按其独立源码/版本执行，不在本批撤销旧代码。

终检：根账本CLI追加16条链接返回0，ledger-link-verification.json读回16项保护字段均未改变；根ledger check返回0。HEAD仍为原40位base、git status --porcelain为空。预检探针的大小写/非战斗空值/旧路径更正见preflight-notes.md，不计生产测试。

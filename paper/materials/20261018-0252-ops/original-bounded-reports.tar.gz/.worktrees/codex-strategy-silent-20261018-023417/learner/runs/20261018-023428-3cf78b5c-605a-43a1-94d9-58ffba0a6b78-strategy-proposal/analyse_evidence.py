"""Summarize this batch's frozen evidence without running the game or a model."""
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = set(json.loads((OUT / "dispatch.json").read_text())["runs"])


def read(stream, folder="evidence"):
    with (OUT / folder / (stream + ".evidence.jsonl")).open() as handle:
        for line in handle:
            if line.endswith("\n"):
                item = json.loads(line)
                assert item["run_id"] in RUNS
                yield item


def ref(item):
    return {key: item[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}


def powers(entries):
    return {entry["power_id"]: entry.get("amount") for entry in entries or []}


def state_summary(item):
    state = item["row"]["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "ref": ref(item), "ts": item["row"].get("ts"),
        "floor": run.get("floor"), "turn": state.get("turn"), "screen": state.get("screen"),
        "in_combat": state.get("in_combat"),
        "hp": player.get("current_hp", run.get("current_hp")),
        "block": player.get("block"), "energy": player.get("energy"),
        "powers": powers(player.get("powers")),
        "potions": [{k: potion.get(k) for k in ("index", "potion_id", "occupied")} for potion in run.get("potions", [])],
        "hand": [{"id": card.get("card_id"), "index": card.get("index"),
                  "upgraded": card.get("upgraded"), "text": card.get("resolved_rules_text")}
                 for card in combat.get("hand", [])],
        "enemies": [{"id": enemy.get("enemy_id"), "hp": enemy.get("current_hp"),
                     "max_hp": enemy.get("max_hp"), "alive": enemy.get("is_alive"),
                     "move": enemy.get("move_id"), "powers": powers(enemy.get("powers")),
                     "intents": enemy.get("intents")} for enemy in combat.get("enemies", [])],
        "selection": state.get("selection"),
    }


def hp_from_summary(turn):
    matches = re.findall(r" (\d+)/(\d+)(?:,|$)", turn["enemies"])
    return sum(int(hp) for hp, _ in matches) if matches else None


if __name__ == "__main__":
    all_states = list(read("states"))
    summaries = [state_summary(item) for item in all_states]
    with (OUT / "state-timeline.jsonl").open("w") as handle:
        for item in summaries:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
    wanted_states = {278383, 278403, 278404, 278405, 278406, 278407, 280160, 280161,
                     280206, 280207, 280232, 280233, 280262, 280263, 280313, 280314,
                     280315, 280316, 280348, 280349, 280354, 280355}
    selected_states = [item for item in summaries if item["ref"]["line"] in wanted_states]
    (OUT / "selected-states.json").write_text(json.dumps(selected_states, ensure_ascii=False, indent=2) + "\n")
    sl = {}
    for item in read("sl-attempts", "evidence-fast"):
        row = item["row"]
        key = (item["run_id"], row.get("floor"), row.get("attempt"))
        prior = sl.get(key)
        if prior is None or row.get("result") != "unfinished":
            sl[key] = item
    sl_brief = []
    for key, item in sl.items():
        row = item["row"]
        sl_brief.append({"ref": ref(item), **{k: row.get(k) for k in
                        ("floor", "attempt", "result", "turns", "end_hp", "end_block", "incoming", "encounter")},
                         "last": (row.get("summary", {}).get("turns") or [None])[-1]})
    (OUT / "attempts-summary.json").write_text(json.dumps(sl_brief, ensure_ascii=False, indent=2) + "\n")
    pair_specs = [("751FN9QM9MHQ", 17, 2, 1, 3), ("751FN9QM9MHQ", 17, 7, 2, 4),
                  ("751FN9QM9MHQ", 17, 13, 1, 6), ("KV0JHNJCKXLS", 33, 5, 4, 5),
                  ("KV0JHNJCKXLS", 33, 1, 1, 6), ("KEN58SH9SLZ6", 17, 10, 4, 5),
                  ("KEN58SH9SLZ6", 17, 5, 4, 6)]
    pairs = []
    for run_id, floor, turn, original, replacement in pair_specs:
        pair = {"run_id": run_id, "floor": floor, "turn": turn, "lines": []}
        for attempt in (original, replacement):
            item = sl[(run_id, floor, attempt)]
            turns = item["row"]["summary"]["turns"]
            start = next(t for t in turns if t["turn"] == turn)
            end = next((t for t in turns if t["turn"] == turn + 1), None)
            pair["lines"].append({"attempt": attempt, "ref": ref(item), "start": start, "next_turn": end,
                                  "net_hp_loss": start["hp"] - end["hp"] if end else None,
                                  "net_enemy_hp_removed": hp_from_summary(start) - hp_from_summary(end) if end else None,
                                  "scope": "observed_turn_boundary_net_changes"})
        pairs.append(pair)
    (OUT / "paired-turns.json").write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"states": len(all_states), "selected_states": len(selected_states),
                      "attempts": len(sl), "pairs": [{"run": p["run_id"], "turn": p["turn"],
                      "values": [[x["attempt"], x["net_hp_loss"], x["net_enemy_hp_removed"]] for x in p["lines"]]}
                      for p in pairs]}, ensure_ascii=False))

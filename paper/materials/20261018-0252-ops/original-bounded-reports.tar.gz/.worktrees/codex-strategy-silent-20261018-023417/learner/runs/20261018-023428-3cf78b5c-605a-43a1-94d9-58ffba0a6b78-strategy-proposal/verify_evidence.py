"""Verify frozen rows and keep focused decision provenance for the report."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
verified = []
for stream in manifest:
    name = stream["stream"]
    path = OUT / "evidence" / (name + ".evidence.jsonl")
    digest = hashlib.sha256()
    counts = Counter()
    with (Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")).open("rb") as source:
        for raw in path.open("rb"):
            digest.update(raw)
            item = json.loads(raw)
            assert item["offset"] + item["bytes"] <= stream["source_size"]
            source.seek(item["offset"])
            original = source.read(item["bytes"])
            assert hashlib.sha256(original).hexdigest() == item["sha256"]
            row = json.loads(original)
            assert row == item["row"]
            assert extractor.run_identity(row) == item["run_id"]
            counts[item["run_id"]] += 1
    assert digest.hexdigest() == stream["output_sha256"]
    assert all(counts[run] == count for run, count in stream["counts"].items())
    verified.append({"stream": name, "source_size": stream["source_size"], "verified_rows": sum(counts.values()),
                     "output_sha256": digest.hexdigest(), "offset_bytes_sha_and_identity": True})
fast = json.loads((OUT / "evidence-fast/evidence-manifest.json").read_text())
for record in fast:
    full = next(item for item in manifest if item["stream"] == record["stream"])
    assert full == record
    p = OUT / "evidence-fast" / (record["stream"] + ".evidence.jsonl")
    assert hashlib.sha256(p.read_bytes()).hexdigest() == record["output_sha256"]

wanted_lines = {272361, 272362, 272434, 272575, 272531, 272652, 274505, 274568, 274484, 274601,
                274131, 274156, 274185, 274235, 274237, 274267, 274272, 274087}
decisions = []
all_decisions = []
for raw in (OUT / "evidence/decisions.evidence.jsonl").open():
    item = json.loads(raw)
    all_decisions.append(item)
    if item["line"] in wanted_lines:
        decisions.append(item)
(OUT / "selected-decisions.json").write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + "\n")
fingerprint_pairs = []
for a, b in [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601)]:
    before = next(item for item in decisions if item["line"] == a)
    after = next(item for item in decisions if item["line"] == b)
    same = before["row"]["fingerprint"] == after["row"]["fingerprint"]
    assert same
    fingerprint_pairs.append({"decision_lines": [a, b], "same_fingerprint": same})

audit = {"streams": verified, "total_unique_rows": sum(r["verified_rows"] for r in verified),
         "fast_overlap_same_bytes": True, "fingerprint_pairs": fingerprint_pairs,
         "production_tests_run": False}
(OUT / "evidence-verification.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(audit, ensure_ascii=False))

for item in decisions:
    row = item["row"]
    if item["line"] in {272361, 272575, 272652, 274568, 274601}:
        print(json.dumps({"line": item["line"], "run": item["run_id"], "attempt": row.get("sl_attempt"),
                          "answers": row.get("answers"), "chosen": row.get("chosen"),
                          "sl_explore": row.get("sl_explore")}, ensure_ascii=False))

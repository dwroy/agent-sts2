import pathlib,json,collections,re
p=pathlib.Path(__file__).parent;ds=json.loads((p/'decisions.json').read_text());ss=json.loads((p/'states.json').read_text())
for d in ds:
 if d['label']=='rest/plan':
  v=json.loads(d['questions']['pick']['criteria']['o0']);print('RESTSELECTED',d['_line'],'keys',list(v),'hpref',v.get('boss_sim_hp_reference'),'sim',v.get('boss_sim'))
  for k,x in v.items():
   if isinstance(x,dict) and any(t in k for t in ['stats','quant','margin']):print('RESTSTAT',d['_line'],k,{f:x.get(f) for f in ['n','samples','damage_per_turn','damage_hp','damage_per_turn_died','turns','boss_relative_margin','damage_per_turn_won']})
for raw in (p/'brain.indexed').open():
 n,b,x=raw.split(':',2);r=json.loads(x)
 if r['label'] in ['rest/plan','map/route-plan']:
  memory=r.get('memory');payload=r.get('payload');print('BRAINMEMKEYS',n,type(memory).__name__,list(memory) if isinstance(memory,dict) else str(memory)[:100], 'payloadkeys',list(payload) if isinstance(payload,dict) else str(payload)[:100]);
  if isinstance(payload,dict):
   for k,v in payload.items():
    if isinstance(v,dict):print('PAYLOADKEYS',n,k,list(v))
combat=[d for d in ds if d['decider']=='jev' and d['label'].startswith('combat/')];offer=selected=0
for d in combat:
 cs={}
 for k,v in d['questions'].get('plan',{}).get('criteria',{}).items():
  try:cs[k]=json.loads(v) if isinstance(v,str) else v
  except ValueError:continue
 if any(isinstance(v,dict) and 'focus' in v for v in cs.values()):offer+=1
 ans=d.get('answers',{}).get('plan',{}).get('choice');v=cs.get(ans,{})
 if isinstance(v,dict) and 'focus' in v:selected+=1;print('FOCUSCHOICE',d['_line'],d['floor'],d['turn'],d.get('sl_attempt'),v['focus'])
print('FOCUSCOUNTS',offer,selected,len(combat))
for seq in [9,10,11,12,13,14]:
 res=json.loads((p/'KRLPMR0FWVZE-resources.json').read_text());c=res['combats'][seq-1];fr=[s for s in ss if c['entry']['ts']<=s['ts']<=c['last']['ts']]
 prev=None
 for s in fr:
  st=s['state'];pl=st.get('combat',{}).get('player',{});pw={v['power_id']:v['amount'] for v in pl.get('powers',[])}
  old=prev[1] if prev else {}
  if prev and pw.get('STRENGTH_POWER',0)!=old.get('STRENGTH_POWER',0):print('STATCHANGE',seq,s['_line'],'T',st['turn'],'str',old.get('STRENGTH_POWER',0),pw.get('STRENGTH_POWER',0),'dex',old.get('DEXTERITY_POWER',0),pw.get('DEXTERITY_POWER',0),'block',pl.get('block'))
  prev=(s,pw)
# Stat effects of ability potion and Kunai on observed same-step transitions.
for s in ss:
 if s['state']['run']['floor']==14 and s['_line']<=445554:
  st=s['state'];c=st.get('combat') or {};print('F14STEP',s['_line'],st.get('turn'),c.get('player'),[(x['card_id'],x.get('resolved_rules_text')) for x in c.get('hand',[]) if x['card_id'] in ['INFINITE_BLADES','POWERS','DEFEND_SILENT']],st.get('selection'))

import json,pathlib
p=pathlib.Path(__file__).parent;run='KRLPMR0FWVZE';by='learner:postmortem'
items=[
('silent-0020',13,None,'八胜战净损103；事件补33、三火补63，56+33+63-103=49。F13所选回血分支投影boss63，实际49；F16所选49与实际一致。仅补资源分账支持，没有锻造或换线的受控整场对照。'),
('silent-0030',17,15,'末试三次吸取在T6/T10/T14执行，玩家力敏各减2、敌力各加2。复制普通非凡先建2力2敏，苦无六次各加1敏，末轮-4力/2敏，两防御共14，对20攻、4血死亡、敌68。只支持既有吸取机制，不把未胜当旧错误repeat。'),
('silent-0079',17,7,'d431164末试SL将尖啸换第二打击，预测损4/伤7→损10/伤13；第五试T7实30→26、敌150→143，第六试实30→20、敌150→137，实际多损6/多伤6。前者T13判死，后者T15死亡；没有胜利对照，不据晚死断言安全改善。'),
('silent-0276',8,4,'d430719、s445457→445458：敏捷药水使0→2敏，已有10挡保持10，后继按现场敏捷；本场43→6获胜。不推提前喝药必胜或持有价。'),
('silent-0333',14,1,'d430802/430803，s445543→445548：能力药水实际取无尽刀刃，T1建立INFINITE_BLADES_POWER1，后轮小刀按实际状态与出牌计；该临时能力不在F17永久22张牌组。仅补已建与持有/生成分账，不改变旧claim或判repeat。')]
updates=[]
for ident,floor,turn,note in items:
 e={'run':run,'floor':floor,'note':note,'role':'support'}
 if turn is not None:e['turn']=turn
 updates.append({'id':ident,'by':by,'evidence':[e],'where':{'lessons':[run]},'note':'来源20261018-081306-ac103f15-31b9-4ba3-a1d1-94ce218ad9b7-postmortem；只补本角色实证与复盘去处，保留旧claim/first_run/prior/status/version/effect。'})
(p/'ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
new={'by':by,'character':'silent','kind':'mechanic','claim':'KRLPMR0FWVZE A10族母战：普通非凡技艺PROWESS现场牌面各给1力量/敏捷；先饮复制药水建立DUPLICATION_POWER1后，施放实使力敏各0→2、复制消失，已有格挡仍0。后续实际投掷匕首扣11、突然一拳扣10；格挡药水另加12挡。这是普通能力与药水的实测组合，不能搬用升级牌2点作为单次值，也不代表已经形成格挡或整场胜率提高。五次复现来自同一局的SL尝试，n=1。','evidence':[{'run':run,'floor':17,'turn':3,'role':'support','note':'首试d430874—430879、s445616—445622；末试d431142—431147、s445884—445890。复制1→消失、力敏各0→2、已有挡0不变；原物理行/偏移/字节数/SHA见任务evidence-manifest.json。第二试T3先单放能力、T7才喝复制，为不同牌序边界，非胜负对照。'}],'first_run':run,'prior':'unknown','prior_runs':[],'prior_note':'ledger.py按PROWESS/非凡技艺/DUPLICATOR/复制药水检索；旧silent-0036是升级牌各2，silent-0118是爆发+与药瓶的另一组合。本角色较早复盘未检出普通非凡技艺配复制的同场组合，未据此声称所有旧状态从未出现。','status':'observed','where':{'lessons':[run]}}
(p/'ledger-add.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n')

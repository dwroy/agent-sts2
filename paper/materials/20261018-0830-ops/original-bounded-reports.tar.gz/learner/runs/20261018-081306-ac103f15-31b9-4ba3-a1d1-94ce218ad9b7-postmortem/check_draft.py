import pathlib,json,re,collections,hashlib
p=pathlib.Path(__file__).parent;ds=json.loads((p/'decisions.json').read_text());ss=json.loads((p/'states.json').read_text());res=json.loads((p/'KRLPMR0FWVZE-resources.json').read_text());draft=(p/'lesson-draft.md').read_text()
print('DRINK_TIMES')
for d in ds:
 if d.get('chosen') and d['chosen'].get('action')=='use_potion':
  i=next(i for i,s in enumerate(ss) if s['ts']==d['ts']);a=ss[i];b=ss[i+1];print(d['_line'],b['_line'],b['ts'],b['state'].get('turn'),b['state'].get('combat',{}).get('player',{}).get('block'))
print('ABILITY',[(d['_line'],d['chosen'],d.get('expect'),d['rationale']) for d in ds if d['_line']==430803])
print('KUNAIGROWTH')
fr=[s for s in ss if 445880<=s['_line']<=445951];last=0
for s in fr:
 st=s['state'];pl=st['combat']['player'];dex=next((x['amount'] for x in pl['powers'] if x['power_id']=='DEXTERITY_POWER'),0)
 if dex>last:print(s['_line'],st['turn'],last,dex,'attacks',pl['attacks_played_this_turn'])
 last=dex
# Verify every physical state reference against the tool's independently counted lines.
ref={}
for c in res['combats']:
 for a in [c['entry'],c['last'],c.get('exit')]:
  if a:ref[a['ts']]=a['line']
for e in res['resource_changes']:
 for a in [e['from'],e['to']]:ref[a['ts']]=a['line']
assert all(ref.get(s['ts'],s['_line'])==s['_line'] for s in ss)
# Verify all 42 numeric arrays in the final draft.
table=[l for l in draft.split('逐轮核对表')[1].split('击杀顺序')[0].splitlines() if l.startswith('  | F') and len(l.split('|'))==6]
assert len(table)==14,len(table)
for c,line in zip(res['combats'],table):
 fr=[s for s in ss if c['entry']['ts']<=s['ts']<=(c.get('exit') or c['last'])['ts']];groups=[]
 for s in fr:
  st=s['state']
  if not st.get('in_combat'):continue
  if not groups or groups[-1][0]!=st['turn']:groups.append([st['turn'],[]])
  groups[-1][1].append(s)
 actual=[[],[],[]];hp=lambda st:sum(e['current_hp'] for e in (st.get('combat') or {}).get('enemies',[]) if e['is_alive'])
 for j,(t,g) in enumerate(groups):
  a=g[0]['state'];b=(groups[j+1][1][0] if j+1<len(groups) else fr[-1])['state'];actual[0].append(hp(a));actual[1].append(hp(a)-hp(b));actual[2].append(a['run']['current_hp']-b['run']['current_hp'])
 values=[[int(x.strip().replace('−','-')) for x in v.strip().split('／')] for v in line.split('|')[2:5]]
 assert actual==values,(c['sequence'],actual,values)
print('TABLES_OK',len(table),'arrays',len(table)*3)
for i in [430962,431016,431074,431142]:assert next(d for d in ds if d['_line']==i).get('hp_guard')
print('KEY_METRICS',len(ds),len(ss),'hpchain',56+33+63-103,'dpr',165/15,'cache',149376/2970233*100,'best',126/131*100,126/129*100)
print('CONTROL_FALLBACK')
key=lambda d:(d['floor'],d.get('sl_attempt'),d['turn']);own={key(d) for d in ds if d['decider']=='code' and d['label'].startswith('combat/') and d['label']!='combat/plan-continue'};fb={key(d) for d in ds if d['decider']=='code-fallback' and d['label'].startswith('combat/')};print(len(own),len(own|fb),sorted(fb-own))
# Independently re-read selected source records at byte offsets and preserve exact hashes.
manifest=[]
for name in ['decisions','run-plans','sl-attempts','brain','run-config']:
 with open('logs/'+name+'.jsonl','rb') as f:
  for l in (p/(name+'.indexed')).open():
   n,b,x=l.split(':',2);b=int(b);f.seek(b);raw=f.readline();r=json.loads(raw);assert 'KRLPMR0FWVZE' in raw.decode();assert json.loads(x)==r;manifest.append({'file':name+'.jsonl','line':int(n),'offset':b,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for s in ss:
 with open('logs/states.jsonl','rb') as f:f.seek(s['_offset']);raw=f.readline()
 r=json.loads(raw);assert r['state']['run_id']=='KRLPMR0FWVZE';assert r['ts']==s['ts'];manifest.append({'file':'states.jsonl','line':s['_line'],'offset':s['_offset'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(p/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2));print('REFERENCES_VERIFIED',len(manifest))

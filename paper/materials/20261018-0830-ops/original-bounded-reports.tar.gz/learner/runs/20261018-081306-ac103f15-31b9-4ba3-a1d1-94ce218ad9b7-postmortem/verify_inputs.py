import pathlib,json,hashlib,collections,subprocess,datetime
p=pathlib.Path(__file__).parent;ds=json.loads((p/'decisions.json').read_text());ss=json.loads((p/'states.json').read_text());res=json.loads((p/'KRLPMR0FWVZE-resources.json').read_text())
lo,hi=ds[0]['ts'],ds[-1]['ts'];hits=[];maxts=None
with open('logs/deepseek-reasoning.jsonl','rb') as f:
 while True:
  offset=f.tell();l=f.readline()
  if not l:break
  try:r=json.loads(l)
  except ValueError:continue
  t=r.get('ts','');maxts=max(maxts or t,t)
  if lo<=t<=hi:hits.append({'offset':offset,'row':r})
(p/'deepseek-window.json').write_text(json.dumps({'start':lo,'end':hi,'maximum_ts':maxts,'matches':hits},ensure_ascii=False,indent=2))
print('DEEPSEEK',lo,hi,maxts,'matches',len(hits))
for c in res['combats']:
 if c['floor']==17:
  s=next(s for s in ss if s['ts']==c['entry']['ts']);r=s['state']['run']
  print('BOSSDECK',len(r['deck']),collections.Counter(x['card_id']+('+' if x['upgraded'] else '') for x in r['deck']), 'RELICS',r.get('relics'));break
for s in ss:
 st=s['state'];c=st.get('combat') or {};pl=c.get('player') or {}
 if st['run']['floor']==17 and st.get('in_combat'):
  powers=[(x['power_id'],x['amount']) for x in pl.get('powers',[])];ep=[(x['power_id'],x['amount']) for x in c['enemies'][0].get('powers',[])];key=(st['turn'],powers,ep)
  if s['_line']>=445880 and (s['_line'] in [445880,445951] or powers!=globals().get('prevpow')):print('LASTPOW',s['_line'],st['turn'],st['run']['current_hp'],pl.get('block'),powers,ep)
  prevpow=powers
for d in ds:
 a=d.get('selection_audit') or {};an=a.get('answer') or {};bef=a.get('before_sl') or {};aft=a.get('after_sl') or {}
 if an.get('line')!=bef.get('line') or bef.get('line')!=aft.get('line'):
  print('SELCHANGE',d['_line'],d['floor'],d['turn'],'ans',an.get('line'),an.get('turn'),'before',bef.get('line'),bef.get('turn'),'after',aft.get('line'),aft.get('turn'),'keys',a.keys())
 if d['decider']=='jev' and d['label'].startswith('combat/') and d.get('rollout_best_chosen') is False:print('NOTBEST',d['_line'],d['floor'],d['turn'],d['rationale'],a.get('answer'))
 if d['label']=='rest/plan':
  print('RESTKEYS',d['_line'],d.keys());print('RESTFACTS',json.dumps(d['questions'],ensure_ascii=False)[:600]);print('RESTSIM',json.dumps(d.get('boss_sim'),ensure_ascii=False)[:700])
print('TIME', (datetime.datetime.fromisoformat(hi.replace('Z','+00:00'))-datetime.datetime.fromisoformat(lo.replace('Z','+00:00'))).total_seconds())
print('USAGE JEV', {k:sum(d.get('usage',{}).get(k,0) or 0 for d in ds if d['decider']=='jev') for k in ['input_tokens','output_tokens','cache_hit_tokens']})
print('USAGE CODEX', {k:sum(d.get('usage',{}).get(k,0) or 0 for d in ds if d['decider']=='codex') for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens']})
# Fixed source identity and leaf snapshots, excluding sensitive files.
live=pathlib.Path('.worktrees/live');files=['agent/src/reflex/card-model.ts','agent/src/reflex/turn-solver.ts','agent/src/reflex/combat-plan.ts','agent/src/sl/explore.ts']
m={'commit':subprocess.check_output(['git','-C',str(live),'rev-parse','HEAD'],text=True).strip(),'files':[]}
for name in files:
 b=(live/name).read_bytes();dest=p/('source-'+pathlib.Path(name).name);dest.write_bytes(b)
 m['files'].append({'path':name,'sha256':hashlib.sha256(b).hexdigest(),'blob':subprocess.check_output(['git','-C',str(live),'rev-parse','HEAD:'+name],text=True).strip()})
(p/'source-manifest.json').write_text(json.dumps(m,indent=2))
(p/'source.diff').write_bytes(subprocess.check_output(['git','-C',str(live),'diff','--binary','HEAD','--',*files]))

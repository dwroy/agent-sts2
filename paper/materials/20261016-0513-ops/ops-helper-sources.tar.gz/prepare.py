from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0513';pub=root/'paper/materials/20261016-0513-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-050119-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-verification.json');assert final['base']==report['base'] and final['head_unchanged'] and final['git_status_porcelain']=='' and final['git_diff_bytes']==0 and final['assigned_proposals']==final['waiting']==10
assert final['source_changes'] is False and final['knowledge_changes'] is False and final['merged'] is None and final['new_release'] is None and (s/'source.diff.patch').read_bytes()==b''
originals=load(s/'original-proposal-manifest.json');assigned=load(s/'assigned-proposals.json');assert len(originals)==len(assigned)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    original=Path(x['source']);copy=Path(x['saved']);queued=next(y for y in assigned if y['id']==x['id']);assert original.is_relative_to(root) and copy.is_relative_to(s)
    assert sha(copy.read_bytes())==x['sha256']==queued['proposal_sha256'] and len(copy.read_bytes())==x['bytes']
    if original.exists():assert sha(original.read_bytes())==x['sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');receipts=load(s/'consumer-summary.json');assert len(receipts)==6 and all(x['exit_code']==0 for x in receipts)
needed={stream:set() for stream in ['states','decisions']}
for x in receipts:
    data=load(s/'consumer'/(x['run']+'.input.json'))
    for stream in needed:needed[stream].update(row['_line'] for row in data[stream])
pairs=load(s/'paired-boards.json');assert len(pairs)==7
needed['decisions'].update(x[k] for x in pairs for k in ['original_line','replacement_line'])
counts={};runs={};input_rows={stream:{} for stream in needed};manifest=load(s/'evidence/evidence-manifest.json');verification=load(s/'provenance-check.json')
for x in manifest:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in report['runs']
            if x['stream']=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10)
            if x['stream']=='runs':assert (row['character'],row['ascension'],row['victory'])==('SILENT',10,False);runs[e['run_id']]=row
            if x['stream'] in needed and e['line'] in needed[x['stream']]:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==verification['verified_rows']==8444 and len(runs)==6
for x in verification['streams']:assert counts[x['stream']]==x['verified_rows'] and x['output_sha256']==next(y['output_sha256'] for y in manifest if y['stream']==x['stream'])
for pair in pairs:
    assert pair['fingerprint_equal'] and input_rows['decisions'][pair['original_line']]['row']['fingerprint']==input_rows['decisions'][pair['replacement_line']]['row']['fingerprint']
potions=load(s/'ken-potion-observations.json');assert len(potions)==7 and sum(x['request_result'].startswith('pending') for x in potions)==3 and all(x['observed_slot_became_empty'] and x['full_candidate_result'] is None and x['counterfactual'] is None for x in potions)
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['leaves'])==15 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_head_observed']
for x in source['leaves']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head_observed']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (root/'.worktrees/live'/x['path']).read_bytes()==z
    assert (a==z)==x['same_bytes'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai');git('merge-base','--is-ancestor',x['actual_live_ancestor_last_touch'],source['live_head_observed'])
assert sum(x['same_bytes'] for x in source['leaves'])==13
for x in source['ancestry']:
    commit=x.get('commit',x.get('source_commit'));assert commit
    for head in [report['base'],source['live_head_observed']]:git('merge-base','--is-ancestor',commit,head)
totals=collections.Counter();consumer_summaries=[];exclusions=[]
for x in receipts:
    run=x['run'];ip=s/'consumer'/(run+'.input.json');op=s/'consumer'/(run+'.output.json');err=s/'consumer'/(run+'.stderr.txt')
    assert sha(ip.read_bytes())==x['input_sha256'] and sha(op.read_bytes())==x['output_sha256'] and sha(err.read_bytes())==x['stderr_sha256']
    data=load(ip);audit=load(op);assert data['run']==runs[run] and len(data['decisions'])==x['decisions'] and len(data['states'])==x['states']
    for stream in needed:
        for row in data[stream]:
            reference=input_rows[stream][row['_line']];assert reference['run']==run and row['_source_sha256']==reference['sha256']
            expected={**reference['row'],'_line':row['_line'],'_source_sha256':reference['sha256']}
            if stream=='decisions':expected.pop('agent_view',None);assert row.get('decision_id')
            assert row==expected
    status=collections.Counter(row['status'] for row in audit['observed_turns']);assert all(row['actual_full_candidate_result'] is None and row['actual_rollout_best'] is None for row in audit['segments'])
    c=dict(decisions=len(data['decisions']),states=len(data['states']),segments=len(audit['segments']),turns=len(audit['observed_turns']),known=status['observed_turn_endpoints'],unknown=status['unknown'])
    assert c['segments']==x['segments'] and c['turns']==x['turn_windows'] and c['known']==x['known_turn_windows'] and c['unknown']==sum(x['unknown_turn_reasons'].values())
    totals.update(c);consumer_summaries.append(dict(run=run,**c));exclusions.extend(x['excluded_metadata'])
assert totals==dict(decisions=2328,states=2354,segments=566,turns=495,known=379,unknown=116)
assert len(exclusions)==1 and exclusions[0]['line']==274207 and exclusions[0]['label']=='map/route-change'
check=load(s/'ledger-update-check.json');prefix=load(s/'ledger-prefix-before.json');reported_rows=load(s/'ledger-appended-receipts.json');inputs=[json.loads(line) for line in (s/'ledger-update.jsonl').read_text().splitlines()]
assert check['cli_exit_code']==0 and len(reported_rows)==len(inputs)==check['rows']==16 and check['old_physical_prefix_preserved'] and check['all_non_trace_fields_preserved'] and check['history_notes_where_prefixes_preserved'] and check['new_evidence']==check['status_changes']==check['shipped_updates']==0
assert set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.stderr.txt').read_bytes()==b''
own=[];owned_receipts=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(prefix['bytes']))==prefix['sha256']
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row not in reported_rows:continue
        assert set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        matched=[v for v in inputs if (v['id'],v['note'])==(row['id'],row['note'])];assert len(matched)==1 and all(row.get(k)==v for k,v in matched[0].items());own.append(raw);owned_receipts.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(own)==len(set(own))==16 and not set(raw.rstrip(b'\n') for raw in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,original_completion=final,original_proposals=originals,stream_counts=counts,original_rows_verified=8444,ascension_cohorts={10:6},paired_boards=7,original_potion_slots=potions,source=source,original_consumers=receipts,consumer_counts=dict(totals),consumer_summaries=consumer_summaries,excluded_metadata=exclusions,owned_trace_rows=owned_receipts,protected_fields_and_prefixes_preserved=True,no_checks_reexecuted=True,limits=['Seven equal-fingerprint boards are local observations; same-run SL attempts are correlated and not independent holdout runs.','Pending three potion receipts stay pending despite observed empty slots; manual KV endpoints do not change the tool unknown status or certify uncapped damage.','PU F17 observed SL win at2HP remains counterevidence against blanket exploration denial; no new threshold, target order or route value invented.','Six bounded windows and379 known/116 unknown turns do not certify complete candidates, historical101/102/103/104-run studies or full future branches.','Original unknown/pending/timeouts and scratch-cache relocation remain; no new gameplay conflict reported. No source, merge, release, production tests, paper refresh, new dispatch or game action; wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0513原050119策略done0/no-source核收，b09c基线干净WT/HEAD不变，十waiting逐项缺口/testsnull/mergednull保持，无合入受阻。六Silent A10八流8444原行逐offset/bytes/SHA/JSON/显式身份核，七同指纹配对核；六有界离线input/output/stderr与原行去decisions.agent_view/加真实_line及_source_sha256投影绑定核，2328动作/2354状态/566题段/495轮窗（379可核116未知）、完整候选全null。KEN274207无decision_id的map元数据单列排除、不补号或拼连续性；KV手工净端点不改工具unknown、不认证毛伤，KEN七次饮药请求/空槽与三pending分列；PU F17余2血胜战与751/KEN同局多次失败相关性保，不拟血价阈值或原101/102/103/104局重新验证。15源码叶13同2历史Roy/Dai注释差及原实际base/live来源核，窄诊断/actual空值不关闭宽父。16所属CLI只where/note，原物理前缀/offset/SHA及私有fold核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI或增support/repeat。原python模块缓存移到scratch的回执保，无新相反游戏结论或通知ACK；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核。仅本人记录/16追溯提交，保并行记录，无源码/合入/发号/补测/论文刷新/复派/重启对局或账号home模型额度权限prompt变更。证据paper/materials/20261016-0513-ops/。\n'
note=f'\n- {at} [运维 codex] 原050119十项继续waiting，无源码修改或合入阻塞；8444原行、七配对、六有界离线及16条所属追溯已核。三pending、KV工具unknown及未选后继保持，无新发布、补测或论文刷新。回执paper/materials/20261016-0513-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=16,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=8444,owned_trace_rows=16,ledger_check=0,paths=len(entries))))

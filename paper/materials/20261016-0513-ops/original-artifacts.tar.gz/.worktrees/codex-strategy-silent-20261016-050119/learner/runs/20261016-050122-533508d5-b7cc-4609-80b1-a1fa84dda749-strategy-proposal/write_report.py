import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
assigned = json.loads((OUT / "assigned-proposals.json").read_text())
dispatch = json.loads((OUT / "dispatch.json").read_text())
base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORK, text=True).strip()
stamp = subprocess.check_output(["date", "-Is"], text=True).strip()
print(stamp)

reasons = [
    "751 F17 T2/T7/T13同盘血价已核；现有字段只记录候选预测，缺抽弃重问后的逐来源兑现、原答与最终执行线的完整认证及受控整战后继，不能定SL血价门槛。",
    "751 F13 T3未知持药值和整战无药参考、F17未决弃呼唤提示已有窄实现；缺原答改线后的完整实际收益归属、实际无药整战及留药后战对照，不能把这些诊断关闭为完整提案。",
    "751六试均败且属于同一局；已核局部端点和配对B2，仍缺完整候选兑现、同随机条件的后续比较及独立留出局，不能限制全部更差线探索或拟合固定血价。",
    "751敏捷、毒、荆棘、呼唤只有分项观察与候选预测；缺联合逐来源收益、抽弃后完整执行认证和跨战持药对照，不能用已有提示或旧101局声明代替整项验证。",
    "KV F33 T5同盘净扣36/29、均零损已核；诅咒选牌/超时后的端点仍为手工读回，缺逐来源回血毛伤认证、完整候选执行及路线/休息替代后继。",
    "YQL/L9/PU巨兽阶段提示已有窄实现；原始占位HP仍用于同轮SL参考排序，缺改变排序后的受控后继与结局校准，且PU F17已有末试剩2血胜线反例，不能直接归零改序。",
    "YQL F17 T10毒药使残壳毒2→8而血26/挡13/自爆41不变已核；缺提前饮用、不饮用、留药及新排序的完整分支，不把局部无减伤外推为统一药水规则。",
    "KEN七次用药请求及同槽变空已核，其中三条原回执仍pending；缺随机选牌/发光水重问后的完整收益认证和任一药物保留到后战的受控对照。",
    "KEN F17 T10同盘损15/21、扣2/4及T5省2血却延迟步法的反例均已核；缺逐来源兑现、保持后轮条件的完整对照与独立新局，不改SL排序或护栏。",
    "KEN同盘血价与能力建立窗口仅支持局部取舍；现有预测/端点工具不能认证完整候选，仍缺同后轮反事实及时间靠后的独立验证，不拟合统一6血/2伤准入阈值。",
]
evidence = [
    "751FN9QM9MHQ A10 F17 T2：decisions 272434/272575；T7：272531/272652；T13：272483/272820。三组指纹分别相同；整轮端点净扣敌9/18、12/18、17/11，净失血13/18、13/23、8/2。",
    "751FN9QM9MHQ F13 T3 decisions 272361/272362；F17 T7/T13/T17。272361同时保存有药和无药候选，plan5有整战不饮用参考；原饮用分支不提供未饮用实盘。",
    "同366288801d9150d9的751三组同指纹；sl-attempts 945—950六试无胜。此处只分析派发751，不重建原经验所称101局统计或调用其他局作新样本。",
    "751 F17 T3/T5/T7/T13/T17；states 278500/278505、278884/278888及原提案引用帧。能力建立、剩余毒、荆棘与手持呼唤是分项事实，不能共享一个整战有效分母。",
    "KV0JHNJCKXLS A10 F33第4/5试T5 decisions 273400/273450，后继273405/273454；states 279460/279465、279511/279515。T1首/末273242/273474亦同指纹，手工端点净扣28/14，均零净失血。",
    "YQL8RZ8BWN1E F17 T10 states 280160/280161，sl-attempts 960—963；L9SGRBB5R698 F17 sl-attempts 681；PU80F84P6HPN F17 sl-attempts 717/719。719实际won、end_hp=2。",
    "YQL8RZ8BWN1E A10 F17第6试T10 decision 274087及states 280160→280161：POISON_POWER 2→8，玩家HP26/格挡13/敌显示自爆意图均不变。L9、PU只作原提案同角色阶段交叉复核。",
    "KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1：decisions 274131/274156/274185/274235/274237/274267/274272；对应原状态280206—280355见ken-potion-observations.json。",
    "KEN58SH9SLZ6 A10 F17第4/5试T10 decisions 274505/274568同指纹；第4/6试T5为274484/274601同指纹；第6试T6/T10/T12端点分别净损6/14/13。",
    "同86a7db08d1a31976的KEN两组同指纹和能力建立窗口；sl-attempts 964—969为同一局六次相关尝试，不能拆成独立训练与验证局。",
]
counterexamples = [
    "751 T13省6血同时少6净扣敌；不能由T7额外失血推出只保血恒优。六试全败不能推出原线必胜。",
    "F13有药/无药均为模型8/8胜；无药方案未实际打完整场，不能判饮用错误或留药到boss必胜。",
    "同局SL改变后续抽序和动作；未知后继不能充作同随机受控反事实。",
    "751末T17即使已建立敏捷仍缺可用格挡牌；剩余毒层或能力分数不能预支成当前伤害/格挡。",
    "KV删除输出没有本轮保血收益，但原线同样没有胜线；T5选牌超时与后续动作变化保留，不作单步导致整场失败的因果。",
    "YQL前三次自爆血挡缺口不同；抹平占位HP可能改变平局顺序。PU巨兽末试已胜，不能泛化为原排序必败。",
    "本体阶段提前喝毒药、其他构筑或其他阶段的收益未知；一次残壳毒增加而无减伤不等于药水普遍无价值。",
    "F15零净失血同时耗两瓶，不能当不喝也零损；同槽变空不把pending自动升级completed。",
    "KEN T5少损2但步法从T5推迟到T9，T8两防御仍各5；与T10多6血只多2净扣敌的取舍同时保留。",
    "KEN省血和输出/能力建立都存在机会成本；本批不重算原文另两局或把三场16次当16独立样本。",
]

results = [{"id": p["id"], "state": "waiting", "reason": r} for p, r in zip(assigned, reasons)]
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261016-050119-strategy-proposal",
          "base": base, "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": [p["id"] for p in assigned], "implementation_domains": [],
          "proposal_results": results, "report": str(OUT / "report.md")}
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

proposal = ["# Silent A10 本批十项策略提案复核", "", f"生成：{stamp}。批次：20261016-050119-strategy-proposal。基线：`{base}`。",
            "", "仅消费dispatch.json中的十个已领取id；不领取其他队列，不另建重复提案，不绑定旧专题。原Markdown字节及SHA见original-proposal-manifest.json。所有处置均为waiting；已有窄实现的祖先只作子项依据，未将宽要求登记duplicate/implemented。", ""]
for p, r, ev, counter in zip(assigned, reasons, evidence, counterexamples):
    proposal += [f"## {p['id']}", "", f"来源任务：{p['source_task']}；实现任务：strategy-proposal；角色silent、已核A10；领域：{', '.join(p['domains'])}。",
                 f"账本：{', '.join(p['ledger'])}。原提案：`{p['proposal']}`。", "", f"证据：{ev}", "", f"反例与限制：{counter}", "",
                 "旧行为／当前覆盖：保留原SL探索、HP护栏、药水持有价和阶段排序；现有预测、持牌损血、未知持药价及阶段说明只作事实。source-audit.json保存实际live祖先及15个相关源码叶，consumer-summary.json保存本次离线读回。",
                 "", f"处置：waiting。{r}", "",
                 "预期行为：先补齐本项缺失的执行及后继证据，再决定是否修改策略；当前保持原行为。未知不填0，不将当轮净差、单动作completed或相关SL尝试当整条候选/整战收益。",
                 "", "验证方法与拟合：固定原盘面、指纹、题面原答、护栏/SL替线、实际选择与重问；逐来源核收益并分开模型预测和观察净差。若拟合门槛，按独立局及真实开始时间切分，早期局调参、后期新局留出；本批六个既定锚点只作复核，不同时用于拟合和宣称泛化。已有离线工具读回不替代受控完整后续。",
                 "", "影响与回退：本批无源码/知识/规则变化，无新行为版本或回退提交；保留原日志、失败回执、提案和未知。证据充分后沿Roy-2026-10-07-learning授权实现、自测、合live与通知，无须因原规则由人制定而另设审批。", ""]
(OUT / "proposal.md").write_text("\n".join(proposal))

manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
consumer = json.loads((OUT / "consumer-summary.json").read_text())
source = json.loads((OUT / "source-audit.json").read_text())
report = ["# Silent 策略提案消费报告", "", f"记录时间：{stamp}", "",
          "本批十个派发id均已逐项复核，全部waiting。已有窄诊断覆盖不能代替完整执行归属、跨战药水价值或SL规则的受控后继；本批没有足够依据新增策略门槛，也没有需重复实现的窄功能。源码和知识零修改，未提交、未合入live、未分配版本，未登记implemented或shipped。", "",
          "## 身份与基线", "", f"- task=strategy-proposal，character=silent，batch=20261016-050119-strategy-proposal。工作树：`{WORK}`。",
          f"- 初始git status干净，HEAD=`{base}`；普通批按要求执行git merge --no-edit main，返回Already up to date；没有合并冲突或阻塞。最终仍须保持该HEAD及干净工作树。",
          "- 根learn.json对应行reason=proposal，含十个proposal_ids，不含research_request/implementation_request。普通专题文件绑定20261010-150327，非本批；未读取其冻结研究正文、改绑或冒报research_complete。",
          "- 六局runs.jsonl显式角色均SILENT、进阶均10，已结束且最终victory=false；不将最终败局误写为每场战斗均败。PU F17有实际SL后胜战。",
          "- 独立完成，无下级agent；不联网，不运行play，不读其他角色私有知识或游戏二进制。未修改账号、模型配置或运维prompt。当前原生模型/推理参数未在本任务中独立读回，不根据默认配置声称已经切换。", "",
          "## 原始证据与冻结边界", "", "共用extract_evidence.py一次抽取八流，保存source_size、逐行原始line/offset/bytes/SHA以及显式身份。provenance-check.json再次逐条seek原日志核原字节、JSON、身份和输出SHA，共8444行；原提案十份逐字节SHA全部匹配。", "",
          "| 流 | 抽取行 | source_size | 各局计数（按本批runs顺序） |", "|---|---:|---:|---|"]
for m in manifest:
    report.append(f"| {m['stream']} | {sum(m['counts'].values())} | {m['source_size']} | {' / '.join(str(m['counts'][r]) for r in dispatch['runs'])} |")
report += ["", "全部截点、输出SHA见evidence/evidence-manifest.json。全源扫描另有states/decisions各2条、brain 1条无效JSON；这些行未作为本批证据纳入，不能据此归因给任一来源局。接收的8444行身份均一致。fight-plans在所列截点未选到这六局，仅表示该截点选择结果为0，不断言原始日志或其他位置不存在。run-plans本次选到21行，未用正文提及充当所属局。", "",
          "## 本次限定复核与反例", "",
          "- 751 F17三组同盘：T2净扣敌9→18而失血13→18；T7扣12→18而失血13→23；T13扣17→11而失血8→2。对应decisions 272434/272575、272531/272652、272483/272820。配对B2预测保留在paired-boards.json；这些是整轮端点净变化，不能归成单张牌毛伤或替线完整兑现。六试全败，不拟5/10血固定门槛。",
          "- 751 F13 T3原题272361保留有药、无药及整战无药模型参考；实际走用药线，原无药整战和留药boss均未实际执行。不因药水缺表的0成本认定持有价值0，不据空药boss失败判前面饮用错误。F17弃牌未决保守多计的呼唤来源与最终手牌分开。",
          "- KV F33第4/5试T5指纹相同：手工核states 279460→279465、279511→279515，30血均不变，敌334→298/305，后帧毒20/13。首/末T1净扣28/14也均无净失血。T5结束回合之后发生诅咒选牌及超时重试，既有整轮工具因此保持turn_end_unverified；T1缺工具要求的前轮结束边界。manual-kv-endpoints.json只保存手工原帧读回，不改工具unknown，不冒称完整候选或毛伤。",
          "- YQL F17第6试T10 decision274087、states280160→280161：残壳毒2→8，血26/挡13/自爆显示41不变。新增毒层不能当减伤或本体进度。L9和PU的历史占位血排名保存于sl-attempts原行；PU F17第5试sl-attempts719实际胜、余2血，保留为不能由相关败局或单轮血价否定探索的反例。早喝/不喝/留药及改序后结局未知。",
          "- KEN七次use_potion请求和对应槽由指定药物变空全部核实；274131/274237/274272三条原回执仍pending，其余四条completed。ken-potion-observations.json分列请求与后帧槽变化，不把pending升级完成，不认证随机选牌后整条方案。",
          "- KEN F17第4/5试T10（274505/274568）同指纹：37血/敌82起，后帧22/16血、敌80/78，净失15/21和净扣2/4；B2 .385/.127、差-.2583、SE .0132保留。第4/6试T5（274484/274601）省2血却延迟步法建立，能力收益不能预支；末试T6/T10/T12净损6/14/13逐窗保留，不能统一只保血或只抢伤。", "",
          "各原提案引用及账本逐项见proposal.md；本批未复算原经验所述101/102/103/104局统计，也未把原文提及的其他局新增为本批支持。无新的相反游戏结论、repeat或反证追加；沿用原有限观察与限制，不强行支持待定假设。", "",
          "## 现有实现及离线消费者读回", "",
          f"只读live HEAD为`{source['live_head_observed']}`。15个相关源码叶中13个与本基线逐字节相同；explore.ts/controller.ts只有原Roy/Dai注释差异，diff保存在live-source-differences.patch。未改写差异，未以祖先核验冒称全部历史dirty运行树等价。source-audit.json保存逐叶SHA和实际live祖先。", "",
          "- 05cd292c6f01bb31e406473d3a9843e659d62b93：已部署呼唤保守持牌损血/未决弃牌预测事实。actual_held_hp_loss仍null，不减去未决弃牌猜确定损血。",
          "- 04921bd785ac6838066522f91ea0bb6ab95cb6a1：药水持有值未知与同题无药模型参考等既有增量。未执行的支线不是实盘反事实。",
          "- a8b1f8be153fe4f3a34146117546c2178f2e446b：SL候选比较/资源预测已有实现，actual_turn/actual_turn_result保持null；配对B2不证明完整候选已经执行。",
          "- d5e20aa4dd44168ce30944dfcce74f8322144953：巨兽当前阶段、原观测毒药水效果提示已有实现；anchorRank仍使用原始enemyHp作同轮参考排序。",
          "- e75438488df159b2e8e9d3458cf219b39aadd933及a32050fbce4c2863f640468c2dbf378fc9157074：已有离线整轮/药槽观察子项，不认证整候选收益。以上六commit均分别核为本基线及所读live祖先；不是本批提交。", "",
          "使用本工作树既有learner/audit-selection.ts，固定本次抽取输入，显式TMPDIR指向本批scratch、nice19、单次顺序运行六局，无模型或网络调用。输入只去decisions.agent_view，加入真实_line/_source_sha256；保留原行号，不重编号。KEN274207无decision_id的map/route-change元数据另列排除，未跨缺口补连续性。", "",
          "| 局号 | 有界层 | 输入决策/状态 | 题段 | 轮窗 | 可核/未知 | exit |", "|---|---|---:|---:|---:|---:|---:|"]
for c in consumer:
    report.append(f"| {c['run']} | {','.join(map(str,c['floors']))} | {c['decisions']}/{c['states']} | {c['segments']} | {c['turn_windows']} | {c['known_turn_windows']}/{c['turn_windows']-c['known_turn_windows']} | {c['exit_code']} |")
report += ["", "合计2328决策、2354状态、566题段、495轮窗，其中379可核、116未知；完整候选认证0。六份原输入、输出、stderr及SHA见consumer/及consumer-summary.json。这是限定证据消费者的实际离线读回，不是生产回归测试、自然live采用或策略收益。字段null来自工具的保守认证边界，不能据此声称原日志里所有动作都不存在；本次具体缺口按逐项理由判断。", "",
          "## 十项最终处置", "", "以下全部waiting；每项均保留旧行为、具体反例及后续验证入口。已有窄实现只作子项覆盖，不将宽提案登记duplicate或implemented。", ""]
for p, r in zip(assigned, reasons):
    report += [f"- `{p['id']}`（账本{', '.join(p['ledger'])}）：{r}"]
report += ["", "## 账本、验证与交付边界", "",
          "proposal.md覆盖每项的原证据局/层/回合、原账本、反例、旧行为、预期行为及验证。十id已由既有CLI建立，不另建重复id或覆盖原提案；code_proposals沿用十个真实id。仅经根learner/ledger.py update追加本批proposal/report的where及note，16个已有Silent账本不改claim、first_run、prior、evidence、status或version，不将原shipped降为proposed，不自行登记shipped。输入、CLI回执及保持性检查留本目录，最终以ledger-update-check.json为准。", "",
          "没有源码/知识修改，不运行tsc/vitest、撤源码红绿或完整宿主测试；这些均为不适用，tests={tsc:null,vitest:null,cases:null}。review_evidence.py的原字节校验及六个既有离线工具exit0只列证据验证，不冒充测试成功。未创建提交，所以无提交前gitleaks/Co-Authored-By或合入步骤；source.diff.patch为空且HEAD不变。", "",
          "没有实际规则上线，未写eval版本、根Roy双通知、运维prompt或上线decision-log，不空合live。无需要回滚的本批源码提交；原日志、原提案、模型失败/超时/pending历史和本批材料全部保留。工作树清洁和HEAD结果见final-verification.json。", "",
          "本批产物是可审计的逐项waiting处置；未声称经验新入库、大脑已采用、量化父要求完成或游戏胜率提升。", "",
          "## 机器回报", "", "```json", json.dumps(result, ensure_ascii=False, indent=2), "```", ""]
(OUT / "report.md").write_text("\n".join(report))

ids = sorted({i for p in assigned for i in p["ledger"]})
updates = []
for ident in ids:
    linked = [p["id"] for p in assigned if ident in p["ledger"]]
    updates.append({"id": ident, "by": "learner:strategy-proposal",
                    "where": {"proposal": [str(OUT / "proposal.md"), str(OUT / "report.md")]},
                    "note": "20261016-050119策略消费复核；仅追溯补链，" + ",".join(linked)
                            + "均waiting；六Silent A10原始8444行身份/字节SHA及七配对核验，已有窄诊断不关闭完整候选/受控后继缺口；不新增证据、不改变规则或旧发布状态。"})
(OUT / "ledger-update.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in updates))
print(json.dumps({"report": str(OUT / "report.md"), "proposal": str(OUT / "proposal.md"),
                  "results": len(results), "ledger_updates": len(updates)}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
RUNS = json.loads((OUT / "dispatch.json").read_text())["runs"]
spec = importlib.util.spec_from_file_location("extract", WORK / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


streams = {}
checks = []
for manifest in json.loads((OUT / "evidence/evidence-manifest.json").read_text()):
    name = manifest["stream"]
    path = OUT / "evidence" / (name + ".evidence.jsonl")
    assert digest(path) == manifest["output_sha256"]
    rows = []
    counts = Counter()
    handles = {}
    try:
        for line in path.open():
            item = json.loads(line)
            source = item["source"]
            if source not in handles:
                handles[source] = open(source, "rb")
            handle = handles[source]
            handle.seek(item["offset"])
            raw = handle.read(item["bytes"])
            assert item["offset"] + len(raw) <= manifest["source_size"]
            assert raw.endswith(b"\n")
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            assert json.loads(raw) == item["row"]
            assert extract.run_identity(item["row"]) == item["run_id"] in RUNS
            counts[item["run_id"]] += 1
            rows.append(item)
    finally:
        for handle in handles.values():
            handle.close()
    assert dict(counts) == {r: n for r, n in manifest["counts"].items() if n}
    streams[name] = rows
    checks.append({"stream": name, "source_size": manifest["source_size"],
                   "verified_rows": len(rows), "output_sha256": digest(path)})
save("provenance-check.json", {"streams": checks, "verified_rows": sum(x["verified_rows"] for x in checks),
                                "scope": "抽取行的原字节、偏移、SHA、JSON及显式所属局校验；不是游戏策略测试"})

run_rows = {e["run_id"]: e["row"] for e in streams["runs"]}
assert set(run_rows) == set(RUNS)
assert all(r["character"].lower() == "silent" and r["ascension"] == 10 for r in run_rows.values())
decisions = {e["line"]: e["row"] for e in streams["decisions"]}
states = {e["line"]: e["row"] for e in streams["states"]}
attempts = {e["line"]: e["row"] for e in streams["sl-attempts"]}

pairs = []
for a, b in [(272434, 272575), (272531, 272652), (272483, 272820),
             (274505, 274568), (274484, 274601), (273400, 273450), (273242, 273474)]:
    left, right = decisions[a], decisions[b]
    assert left["fingerprint"] == right["fingerprint"]
    pairs.append({"run": left["run_id"], "floor": left["floor"], "turn": left["turn"],
                  "original_line": a, "replacement_line": b,
                  "original_attempt": left.get("sl_attempt"), "replacement_attempt": right.get("sl_attempt"),
                  "fingerprint_equal": True, "replacement_log": right.get("sl_explore")})
save("paired-boards.json", pairs)


def snapshot(line):
    frame = states[line]["state"]
    combat = frame.get("combat") or {}
    player = combat.get("player") or {}
    return {"line": line, "run": frame["run_id"], "floor": frame["run"]["floor"],
            "turn": frame.get("turn"), "screen": frame["screen"],
            "hp": player.get("current_hp", frame["run"].get("current_hp")),
            "block": player.get("block"), "powers": player.get("powers"),
            "hand": [{k: c.get(k) for k in ["index", "card_id", "upgraded"]} for c in combat.get("hand", [])],
            "potions": frame["run"].get("potions"),
            "enemies": [{k: e.get(k) for k in ["index", "enemy_id", "current_hp", "max_hp", "is_alive", "powers", "intents", "move_id"]}
                        for e in combat.get("enemies", [])]}


selected = [278479, 278483, 278620, 278623, 278500, 278505, 278884, 278888,
            280160, 280161, 280206, 280207, 280232, 280233, 280262, 280263,
            280313, 280314, 280315, 280316, 280348, 280349, 280354, 280355,
            280564, 280684, 280691, 280692, 280705, 280709, 280713, 280723]
save("state-snapshots.json", [snapshot(n) for n in selected])
before, after = snapshot(280160), snapshot(280161)
assert (before["hp"], before["block"], after["hp"], after["block"]) == (26, 13, 26, 13)
poison = lambda frame: next(p["amount"] for p in frame["enemies"][0]["powers"] if p["power_id"] == "POISON_POWER")
assert (poison(before), poison(after)) == (2, 8)
assert before["enemies"][0]["intents"] == after["enemies"][0]["intents"]
assert attempts[719]["result"] == "won" and attempts[719]["end_hp"] == 2
assert attempts[719]["run_id"] == "PU80F84P6HPN" and attempts[719]["floor"] == 17
assert all(a["result"] != "won" for a in attempts.values() if a["run_id"] in ["751FN9QM9MHQ", "KEN58SH9SLZ6"])

potions = []
for line, a, b, potion, slot in [
    (274131, 280206, 280207, "ATTACK_POTION", 0),
    (274156, 280232, 280233, "STABLE_SERUM", 0),
    (274185, 280262, 280263, "SPEED_POTION", 0),
    (274235, 280313, 280314, "WEAK_POTION", 1),
    (274237, 280315, 280316, "ATTACK_POTION", 0),
    (274267, 280348, 280349, "GLOWWATER_POTION", 1),
    (274272, 280354, 280355, "SKILL_POTION", 0),
]:
    first, last = snapshot(a), snapshot(b)
    get = lambda frame: next(p for p in frame["potions"] if p["index"] == slot)
    assert get(first)["potion_id"] == potion and get(last)["occupied"] is False
    assert decisions[line]["chosen"]["action"] == "use_potion"
    potions.append({"decision_line": line, "floor": decisions[line]["floor"], "turn": decisions[line]["turn"],
                    "potion": potion, "slot": slot, "before_state_line": a, "after_state_line": b,
                    "request_result": decisions[line]["result"], "observed_slot_became_empty": True,
                    "full_candidate_result": None, "counterfactual": None})
assert sum(p["request_result"].startswith("pending") for p in potions) == 3
save("ken-potion-observations.json", potions)

audit_dir = OUT / "consumer"
audit_dir.mkdir(exist_ok=True)
floors = {r: {17} for r in RUNS}
floors["751FN9QM9MHQ"] |= {13}
floors["KV0JHNJCKXLS"] = {33}
floors["KEN58SH9SLZ6"] |= {3, 4, 5, 11, 15}
summary = []
for run in RUNS:
    def selected_row(item, state=False):
        row = item["row"]
        floor = row.get("state", {}).get("run", {}).get("floor") if state else row.get("floor")
        return item["run_id"] == run and floor in floors[run]
    selected_decisions = [x for x in streams["decisions"] if selected_row(x)]
    excluded = [{"line": x["line"], "reason": "无decision_id的元数据行", "label": x["row"].get("label")}
                for x in selected_decisions if not x["row"].get("decision_id")]
    ds = [{**{k: v for k, v in x["row"].items() if k != "agent_view"},
           "_line": x["line"], "_source_sha256": x["sha256"]}
          for x in selected_decisions if x["row"].get("decision_id")]
    ss = [{**x["row"], "_line": x["line"], "_source_sha256": x["sha256"]}
          for x in streams["states"] if selected_row(x, True)]
    payload = {"run": run_rows[run], "decisions": ds, "states": ss}
    input_path = audit_dir / (run + ".input.json")
    output_path = audit_dir / (run + ".output.json")
    error_path = audit_dir / (run + ".stderr.txt")
    input_path.write_text(json.dumps(payload, ensure_ascii=False) + "\n")
    with output_path.open("w") as stdout, error_path.open("w") as stderr:
        result = subprocess.run(["nice", "-n", "19", "node", "--import",
                                 str(WORK / "agent/node_modules/tsx/dist/loader.mjs"),
                                 str(WORK / "learner/audit-selection.ts"), str(input_path)],
                                cwd=WORK, stdout=stdout, stderr=stderr)
    assert result.returncode == 0, str(error_path)
    audit = json.loads(output_path.read_text())
    assert all(s["actual_full_candidate_result"] is None and s["actual_rollout_best"] is None for s in audit["segments"])
    turns = audit["observed_turns"]
    summary.append({"run": run, "floors": sorted(floors[run]), "exit_code": result.returncode,
                    "input_sha256": digest(input_path), "output_sha256": digest(output_path),
                    "stderr_sha256": digest(error_path), "decisions": len(ds), "states": len(ss),
                    "excluded_metadata": excluded, "segments": len(audit["segments"]),
                    "observed_actions": len(audit["observed_actions"]),
                    "turn_windows": len(turns), "known_turn_windows": sum(t["status"] == "observed_turn_endpoints" for t in turns),
                    "unknown_turn_reasons": dict(Counter(t["reason"] for t in turns if t["status"] == "unknown")),
                    "full_candidate_results_certified": 0})
    save("consumer-summary.json", summary)
print(json.dumps({"provenance_rows": sum(x["verified_rows"] for x in checks), "paired_boards": len(pairs),
                  "potion_slots": len(potions), "pending_potion_receipts": 3, "consumer": summary}, ensure_ascii=False, indent=2))

import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];R=json.load((p/'25MFNPAE37R2-resources.json').open());B=[json.loads(x) for x in (p/'brain.jsonl').open()]
J=[d for d in D if d['decider']=='jev'];P=[d for d in J if d['label'].startswith('combat/plan-choice')]
print('STATS','Jev',len(J),'low<.35',sum(d.get('confidence',1)<.35 for d in J),'F48low',sum(d.get('confidence',1)<.35 for d in J if d['floor']==48),'plans',len(P),'best',collections.Counter(str(d.get('rollout_best_chosen')) for d in P),'rank1',sum('code rank 1' in d['rationale'] for d in P))
print('USAGE',json.dumps(J[0].get('usage')), 'brain keys',list(B[0]),'brain usage',B[0].get('usage'))
for k in ['input_tokens','output_tokens','cache_read_input_tokens','cache_hit_tokens','prompt_tokens','completion_tokens','reasoning_tokens']:
 print('JUSAGE',k,sum((d.get('usage') or {}).get(k,0) or 0 for d in J),'BUSAGE',sum((d.get('usage') or {}).get(k,0) or 0 for d in B))
print('BRAIN types',collections.Counter(str(x.get('engine'))+'/'+str(x.get('kind')) for x in B))
print('BRAIN0',json.dumps({k:v for k,v in B[0].items() if k not in ('prompt','answer','request','response','system','user','messages')},ensure_ascii=False)[:2200])
print('FOCUS')
for d in P:
 crit=(d.get('questions',{}).get('plan') or {}).get('criteria',{})
 foc=[k for k in crit if 'focus' in k]
 if foc:print(d['_source_line'],d['floor'],d['turn'],foc,d.get('answers'))
print('GUARDS')
for d in D:
 if 'HP guard:' in d.get('rationale',''):
  crit=d['questions']['plan']['criteria'];print('d',d['_source_line'],d['floor'],d['turn'],d.get('selection_audit'))
  for k,v in crit.items():
   try:v=json.loads(v)
   except:continue
   print(k,{a:v.get(a) for a in ('plays','hp_lost','damage_dealt','block_gained','scaling_gained','rollout_best')})
print('POTIONS ACTIONS')
for d in D:
 if (d.get('chosen') or {}).get('action') in ('use_potion','discard_potion'):print(d['_source_line'],d['ts'],d['floor'],d['turn'],d['chosen'],d['rationale'][:140])
print('CHANGES NONCOMBAT OR POTION')
for x in R['resource_changes']:
 if x['combat_sequence'] is None or x['from']['potions']!=x['to']['potions']: print(json.dumps(x,ensure_ascii=False))
print('KEY COMBATS TURNS')
for c in R['combats']:
 if c['floor'] not in [8,12,17,28,33,43,44,45,46,48]:continue
 rows=[s for s in S if c['entry']['line']<=s['_source_line']<=(c.get('exit') or c['last'])['line']];turns=[]
 for s in rows:
  z=s['state'];co=z.get('combat') or {};e=co.get('enemies') or []
  if not z.get('in_combat') or not e:continue
  if not turns or turns[-1][0]!=z.get('turn'):
   turns.append([z['turn'],s['_source_line'],z['run']['current_hp'],[(a['name'],a['enemy_id'],a['current_hp'],a.get('block'),a.get('powers'),a.get('intents')) for a in e]])
 print('WINDOW',c['sequence'],c['floor'],json.dumps(turns,ensure_ascii=False))
 if c['floor']==48 and c['sequence']==30:
  for s in rows:
   z=s['state'];co=z.get('combat') or {}
   print('DEATHFRAME',s['_source_line'],z['turn'],z['run']['current_hp'],json.dumps(co,ensure_ascii=False)[:750] if 'player' not in co else json.dumps({k:v for k,v in co.items() if k not in ('hand','draw_pile','discard_pile','exhaust_pile')},ensure_ascii=False)[:1800])

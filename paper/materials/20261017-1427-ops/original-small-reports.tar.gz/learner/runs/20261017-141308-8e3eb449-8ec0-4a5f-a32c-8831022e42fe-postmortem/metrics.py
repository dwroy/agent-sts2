import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent;D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()];R=json.load((p/'25MFNPAE37R2-resources.json').open())
focus_offered=0;focus_chosen=collections.Counter()
for d in D:
 if d['decider']!='jev' or 'plan' not in d.get('questions',{}):continue
 opts={k:json.loads(v) for k,v in d['questions']['plan']['criteria'].items()};foc={k:v['plays'] for k,v in opts.items() if str(v.get('plays','')).startswith('focus:')}
 if foc:
  focus_offered+=1;a=d.get('answers',{});ans=a.get('plan',{}).get('choice');
  if ans in foc:focus_chosen[foc[ans].split(' — ')[0]]+=1
print('FOCUS',focus_offered,dict(focus_chosen))
rounds={};autonomous=[]
for c in R['combats']:
 end=(c.get('exit') or c['last'])['line'];tss=[s for s in S if c['entry']['line']<=s['_source_line']<=end];start=c['entry']['ts'];stop=(c.get('exit') or c['last'])['ts'];ds=[d for d in D if start<=d['ts']<=stop and d['floor']==c['floor'] and d['label'].startswith('combat/')]
 for d in ds:
  key=(c['sequence'],d['turn']);rounds.setdefault(key,[]).append(d)
 own=[d for d in ds if d['decider']=='code' and not d['label'].endswith('plan-continue')]
 autonomous+=own
print('ROUNDS',len(rounds),'withOwnCode',sum(any(d['decider']=='code' and d['label']!='combat/plan-continue' for d in ds) for ds in rounds.values()),'noJev',sum(not any(d['decider']=='jev' or 'continuing the Jev-chosen' in d['rationale'] for d in ds) for ds in rounds.values()),'ownActions',len(autonomous))
print('FALLBACKS',len([d for d in D if d['decider']=='code-fallback']),'budgetmarked',sum(d.get('time_budget',{}).get('timed_out') is True for d in D if d['decider']=='code-fallback'))
for c in R['combats']:
 if c['floor']==48:
  ss=[s for s in S if c['entry']['line']<=s['_source_line']<=(c.get('exit') or c['last'])['line']];by={}
  for s in ss:
   if s['state']['in_combat']:by.setdefault(s['state']['turn'],s)
  print('QUEEN',c['sequence']-24,'hp',[s['state']['run']['current_hp'] for s in by.values()],'enemy',[sum(e['current_hp'] for e in s['state']['combat']['enemies'] if e['is_alive']) for s in by.values()])
  print('lastlines',[(s['_source_line'],s['state']['turn'],s['state']['run']['current_hp'],[(e['enemy_id'],e['current_hp']) for e in (s['state'].get('combat') or {}).get('enemies',[])]) for s in ss[-2:]])
for b in B:
 if b['label']=='rest/plan' and b.get('payload',{}).get('run_brief',{}).get('floor')==47:
  print('PAYLOAD KEYS',list(b['payload']))
  def walk(x,path=''):
   if isinstance(x,dict):
    for k,v in x.items():
     if k in ['act_boss_clock','act_boss_sim','route_plan','boss_sim_results']:print(path+'.'+k,str(v)[:2600])
     else:walk(v,path+'.'+k)
   elif isinstance(x,list):
    for i,v in enumerate(x):walk(v,path+f'[{i}]')
  walk(b['payload'])

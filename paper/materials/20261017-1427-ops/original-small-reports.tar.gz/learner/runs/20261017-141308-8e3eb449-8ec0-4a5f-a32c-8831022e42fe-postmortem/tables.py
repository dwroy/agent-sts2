import json
from pathlib import Path
p=Path(__file__).parent;R=json.load((p/'25MFNPAE37R2-resources.json').open());S=[json.loads(x) for x in (p/'states.jsonl').open()]
name={e['enemy_id']:e.get('name',e['enemy_id']) for s in S for e in (s['state'].get('combat') or {}).get('enemies',[])}
def belt(x):return '、'.join(str(i)+':'+k for i,k in x['potions']) or '空'
with (p/'tables.md').open('w') as f:
 f.write('|战斗／尝试|入场→离场或SL前末见HP／max HP；净变化|药槽入→出|states证据行；UTC时间|\n|---|---|---|---|\n')
 for c in R['combats']:
  a=c['entry'];b=c.get('exit') or c['last'];lab=f"F{c['floor']}"+(f"第{c['sequence']-24}试" if c['floor']==48 else '')
  enemies='、'.join(name[k]+' '+k for k in c['enemies']);outcome='赢' if c['floor']!=48 else '阵亡' if c.get('exit') else 'SL截断，离场帧未记录'
  f.write(f"|{lab}／{enemies}|{a['hp']}/{a['max_hp']}→{b['hp']}/{b['max_hp']}；{b['hp']-a['hp']:+d}（{outcome}）|{belt(a)}→{belt(b)}|s{a['line']}→s{b['line']}；{a['ts']}→{b['ts']}|\n")
 f.write('\n|关键赢战／T1起|轮首玩家HP|轮首活体敌HP／尚需清除|至下一轮首敌HP净推进；末项仅清场最低需求|\n|---|---|---|---|\n')
 for c in R['combats']:
  if c['floor'] not in [8,12,17,28,33,44,45,46]:continue
  by={}
  for s in S:
   if c['entry']['line']<=s['_source_line']<=(c.get('exit') or c['last'])['line'] and s['state']['in_combat']:by.setdefault(s['state']['turn'],s)
  hp=[s['state']['run']['current_hp'] for s in by.values()];ep=[sum(e['current_hp'] for e in s['state']['combat']['enemies'] if e['is_alive']) for s in by.values()];dp=[a-b for a,b in zip(ep,ep[1:])]+[ep[-1]]
  f.write(f"|F{c['floor']}，T1—T{len(by)}|{'／'.join(map(str,hp))}|{'／'.join(map(str,ep))}|{'／'.join(map(str,dp))}|\n")
print((p/'tables.md').read_text())

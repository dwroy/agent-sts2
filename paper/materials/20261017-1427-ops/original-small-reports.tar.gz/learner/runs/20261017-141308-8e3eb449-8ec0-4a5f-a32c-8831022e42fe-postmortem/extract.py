import json
from pathlib import Path
out=Path(__file__).parent
run='25MFNPAE37R2'
for name in ['decisions','states','run-plans','sl-attempts','run-config','brain']:
    path=Path('logs')/(name+'.jsonl')
    count=0;offset=0
    with path.open('rb') as source,(out/(name+'.jsonl')).open('w') as target:
        cutoff=path.stat().st_size
        for n,line in enumerate(source,1):
            start=offset;offset+=len(line)
            if offset>cutoff:break
            if run.encode() not in line:continue
            row=json.loads(line)
            row['_source_line']=n;row['_source_offset']=start
            target.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
    print(name,count)
dec=[json.loads(x) for x in (out/'decisions.jsonl').open()]
start,end=dec[0]['ts'],dec[-1]['ts']
with Path('logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as target:
    count=0
    for n,line in enumerate(f,1):
        try:r=json.loads(line)
        except ValueError:continue
        if start<=r.get('ts','')<=end:
            r['_source_line']=n;target.write(json.dumps(r,ensure_ascii=False)+'\n');count+=1
print('deepseek-reasoning',count,'window',start,end)

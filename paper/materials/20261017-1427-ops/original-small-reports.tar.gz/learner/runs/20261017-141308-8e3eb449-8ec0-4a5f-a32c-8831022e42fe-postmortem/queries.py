import subprocess,json
from pathlib import Path
p=Path(__file__).parent
for word in ['灵动步法','进场','预算','前缀','护栏','女王','花园幽灵鳗']:
 r=subprocess.run(['python3','learner/ledger.py','find','--character','silent','--text',word,'--json'],capture_output=True,text=True)
 (p/('ledger-query-'+word+'.json')).write_text(r.stdout)
 rows=json.loads(r.stdout)
 print('\n查询',word,'数量',len(rows))
 for e in rows:
  if word=='女王' and e['id'] not in ['silent-0068','silent-0069','silent-0079','silent-0090','silent-0270','silent-0346']:continue
  print(e['id'],e['status'],e.get('version'),e['claim'][:500])

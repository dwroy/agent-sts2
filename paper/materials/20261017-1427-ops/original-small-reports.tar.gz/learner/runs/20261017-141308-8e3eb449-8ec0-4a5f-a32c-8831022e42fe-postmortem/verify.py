import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()];R=json.load((p/'25MFNPAE37R2-resources.json').open());ds={d['_source_line']:d for d in D};ss={s['_source_line']:s['state'] for s in S}
assert len(D)==1006 and len(S)==1056 and len(B)==58 and len(R['combats'])==30
assert [c['entry']['hp'] for c in R['combats'][-6:]]==[26]*6
assert [(c.get('exit') or c['last'])['hp'] for c in R['combats'][-6:]]==[10,8,9,7,3,0]
assert all(c['entry_is_turn_one'] for c in R['combats'])
assert all(c['exit']['screen']=='REWARD' for c in R['combats'][:24])
assert [c['entry']['hp'] for c in R['combats'][20:24]]==[55,53,40,12]
assert [c['exit']['hp'] for c in R['combats'][20:24]]==[53,40,12,5]
assert ss[435373]['run']['current_hp']==7 and ss[435373]['combat']['player']['block']==0
assert ss[435373]['combat']['enemies'][0]['intents'][0]['total_damage']==19
assert [e['current_hp'] for e in ss[435374]['combat']['enemies']]==[156,285]
assert sum(e['current_hp'] for e in ss[435351]['combat']['enemies'])==612
assert '4 end-of-turn block' in json.loads((p/'sl-attempts.jsonl').read_text().splitlines()[-1])['judge']['reason']
assert ds[421134]['chosen']['action']=='select_deck_card' and '尖啸' in ds[421134]['rationale']
assert ds[420606]['chosen']['action']=='play_card' and '致命毒药' in ds[420606]['rationale']
assert ss[434812]['run']['current_hp']-ss[434818]['run']['current_hp']==12
assert ss[435179]['run']['current_hp']==ss[435182]['run']['current_hp']==12
assert sum(x.get('usage',{}).get('inputTokens',0) for x in B)==10720937
assert sum(x.get('usage',{}).get('cacheHitTokens',0) for x in B)==6407936
assert len([d for d in D if d['decider']=='jev' and d.get('confidence',1)<.35])==17
assert len([d for d in D if d['decider']=='jev' and re.search(r'code rank 1\b',d['rationale'])])==119
rests=[x for x in R['resource_changes'] if x['to']['floor'] in [7,9,11,16,25,29,32,40,42,47] and x['to']['screen']=='REST' and x['to']['hp']>x['from']['hp']]
assert len(rests)==10 and sum(x['to']['hp']-x['from']['hp'] for x in rests)==210
old=json.load((p/'lessons-before.json').open());h=hashlib.sha256()
with Path('notes/lessons.md').open('rb') as f:
 remaining=old['bytes']
 while remaining:
  b=f.read(min(1024*1024,remaining));assert b;h.update(b);remaining-=len(b)
assert h.hexdigest()==old['sha256']
print('关键入口、逐轮、死亡、护栏、药水/SL来源、计数与旧复盘前缀：校验通过')

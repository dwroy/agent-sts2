import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()]
print('DECIDERS',collections.Counter(d['decider'] for d in D));print('LABELS',collections.Counter(d['label'] for d in D))
print('D first',json.dumps(D[0],ensure_ascii=False)[:4500]);print('D jev',json.dumps(next(d for d in D if d['decider']=='jev'),ensure_ascii=False)[:6500]);print('S first',json.dumps(S[0],ensure_ascii=False)[:4500])
for x in (p/'sl-attempts.jsonl').open():
 r=json.loads(x);print('SL',json.dumps({k:v for k,v in r.items() if k not in ['trace','retry_memo','memo','exploration']},ensure_ascii=False)[:2500], 'keys',list(r))
print('NONCOMBAT')
for d in D:
 if d['decider']=='codex':print(d['_source_line'],d['floor'],d.get('turn'),d['label'],json.dumps(d.get('chosen'),ensure_ascii=False),d.get('rationale',''))
print('RESOURCE COMBATS')
r=json.load((p/'25MFNPAE37R2-resources.json').open())
for c in r['combats']:
 print(c['sequence'],c['floor'],c['enemies'],c['entry'],c['exit'] or c['last'],c['end'])

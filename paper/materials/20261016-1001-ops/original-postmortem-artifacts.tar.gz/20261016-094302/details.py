exec(open(__file__.replace('details.py','audit.py')).read().split("mode=sys.argv[1]")[0])
mode=sys.argv[1]
if mode=='stats':
 jev=[x for x in d if x['decider']=='jev'];pc=[x for x in jev if x['label']=='combat/plan-choice'];cc=[x for x in d if x['label'].startswith('combat/')]
 print('deciders',collections.Counter(x['decider'] for x in d),'labels',collections.Counter(x['label'] for x in cc))
 print('low',len([x for x in jev if x.get('confidence',1)<.35]),'pc',len(pc),'best',collections.Counter(x.get('rollout_best_chosen') for x in pc),'fallback',collections.Counter(x.get('fallback') for x in d))
 print('jevusage',{k:sum(x.get('usage',{}).get(k,0) or 0 for x in jev) for k in ['input_tokens','output_tokens','cache_hit_tokens']})
 brain=[x for x in d if x['decider']=='codex' and (x.get('usage') or {}).get('input_tokens',0)>0]
 print('braincalls',len(brain),'usage',{k:sum(x.get('usage',{}).get(k,0) or 0 for x in brain) for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens']},'latency',sum((x.get('deepseek') or {}).get('latency_ms',0) or 0 for x in brain))
 for x in pc:
  if 'HP guard' in x['rationale']:print('GUARD',x['_line'],x['floor'],x['turn'],x['rationale'],json.dumps(x.get('hp_guard'),ensure_ascii=False),list(x.get('selection_audit',{})))
 for x in pc[:1]:
  print('rolloutkeys',list(x.get('rollout',{})),'selectionaudit',json.dumps(x.get('selection_audit'),ensure_ascii=False)[:3500]); print('criteria',json.dumps(x['questions'],ensure_ascii=False)[:600])
 keys=collections.Counter()
 for x in pc:
  for k in x:keys[k]+=1
 print('pckeys',keys)
 for x in d:
  if x['floor']>=25 and not x['label'].startswith(('combat','selection')):print('TAIL',x['_line'],x['floor'],x['label'],x.get('chosen'),x['rationale'])
elif mode=='potions':
 for x in d:
  if (x.get('chosen') or {}).get('action') in ('use_potion','discard_potion') or (x.get('expect') or {}).get('card',{}).get('id')=='ALCHEMIZE':print('D',x['_line'],'F',x['floor'],'T',x['turn'],'attempt',x.get('sl_attempt'),'chosen',x.get('chosen'),'expect',x.get('expect'),'result',x.get('result'),x['rationale'][:230])
 for ch in r['resource_changes']:
  if ch['from']['potions']!=ch['to']['potions']:print('S',ch['from']['line'],'->',ch['to']['line'],'F',ch['to']['floor'],'T',ch['to']['turn'],ch['from']['potions'],'->',ch['to']['potions'],'SL',ch['restart_boundary'])
 for x in [s[0],s[-1]]:
  print('RELICS',x['_line'],[(z['relic_id'],z['name'],z.get('description')) for z in x['state']['run']['relics']])
 print('FINAL',json.dumps(s[-1]['state'].get('combat'),ensure_ascii=False)[:1800])
elif mode=='plans':
 for x in map(json.loads,(p/'run-plans.jsonl').open()):print('PLAN',x['_line'],list(x),json.dumps(x,ensure_ascii=False)[:3600])
elif mode=='boss':
 for x in d:
  if x['label'] in ('rest/plan','map/route-change','event/act-plan'):
   print('D',x['_line'],'F',x['floor'],x['label'],x['rationale'])
   print('keys',list(x))
   q=next(iter((x.get('questions') or {}).values()),{}); f=q.get('facts',{})
   print('qkeys',list(q),'factkeys',list(f))
   for k,v in f.items():
    if any(t in k for t in ['boss','route','hp','clock']):print(k,json.dumps(v,ensure_ascii=False)[:2500])
   print('boss_sim',json.dumps(x.get('boss_sim'),ensure_ascii=False)[:3000])

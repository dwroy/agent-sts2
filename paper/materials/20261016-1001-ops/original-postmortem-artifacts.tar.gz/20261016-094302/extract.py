import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261016-094307-58c77163-4611-4d9e-891a-e97f11b26e1f-postmortem'
needle=b'FGKZALWSTQQ1'
for name in ('runs','decisions','states','run-plans','sl-attempts','run-config'):
    source=root/'logs'/f'{name}.jsonl'
    if not source.exists():
        print(name,'不存在'); continue
    count=0;offset=0;cut=source.stat().st_size
    with source.open('rb') as inp,(out/f'{name}.jsonl').open('w') as dst:
        for line_no,line in enumerate(inp,1):
            start=offset;offset+=len(line)
            if offset>cut:break
            if needle not in line: continue
            r=json.loads(line);r['_line']=line_no;r['_offset']=start
            dst.write(json.dumps(r,ensure_ascii=False)+'\n');count+=1
    print(name,count)
dec=[json.loads(x) for x in (out/'decisions.jsonl').open()]
lo=min(x['ts'] for x in dec);hi=max(x['ts'] for x in dec)
count=0;source=root/'logs/deepseek-reasoning.jsonl'
with source.open('rb') as inp,(out/'deepseek-reasoning.jsonl').open('w') as dst:
    for line_no,line in enumerate(inp,1):
        r=json.loads(line)
        if lo<=r.get('ts','')<=hi:
            r['_line']=line_no;dst.write(json.dumps(r,ensure_ascii=False)+'\n');count+=1
print('决策时间窗',lo,hi,'reasoning',count)
print('决策首条',json.dumps(dec[0],ensure_ascii=False)[:3500])

## 复盘回报
- 已追加：FGKZALWSTQQ1（A10，第30层，猎人杀手HUNTER_KILLER；末次T3以15血8挡对24攻击阵亡，敌剩56血）。
- 新的纯 bug（file:line，每条一行；没有写「无」）：
  - 无。
- 写成「未记录」的项：FGKZALWSTQQ1：前三试退出帧、重载原子开场、部分胜战归零帧及按来源毛伤、重名个体完整击杀顺序、F22回血原子来源、完整候选实际执行比例、未选路线／休息／留药／牌序的整战反事实、旧boss时钟需伤／估伤及实打／估值比、赠礼不可饮用根因、纯战斗耗时、Jev缓存、实付账单、开局dirty完整字节。
- 学习账本：FGKZALWSTQQ1：新增无；更新silent-0019、silent-0125、silent-0232、silent-0253、silent-0005、silent-0011、silent-0027、silent-0294；均为support，老错重犯无；`ledger.py check`退出码0。
- 代码提案（证据／账本／CLI id／实现任务，证据不足明确写限制）：
  - F25—F30资源链／silent-0019／silent-proposal-ac0e2ad8d92a8540／strategy-proposal：核对改线撤回营火后的资源依据，缺替代路线实战，保留排序。
  - F14T3—T4、F29T1—T4／silent-0125、silent-0253、silent-0011／silent-proposal-c66d0a84748e3b0b／strategy-proposal：核对护栏省血与施毒代价，缺原线完整反事实，保留阈值；源码行号补注见proposal-guard-readback.md。
  - F29T5、F30四试／silent-0232、silent-0005、silent-0027、silent-0294／silent-proposal-f0b32cbaabab1fc4／strategy-proposal：核对柔嫩、炼制、SL与终局资源，缺可获胜后继和药水不可用根因，保留行为。三项均pending，未冒称实现或上线。

```json
{"task": "postmortem", "appended": ["FGKZALWSTQQ1"], "skipped": [], "bugs": [], "ledger": {"added": [], "updated": ["silent-0019", "silent-0125", "silent-0232", "silent-0253", "silent-0005", "silent-0011", "silent-0027", "silent-0294"], "repeats": [], "check": 0}, "code_proposals": ["silent-proposal-ac0e2ad8d92a8540", "silent-proposal-c66d0a84748e3b0b", "silent-proposal-f0b32cbaabab1fc4"], "implementation_domains": ["combat", "potion", "sl", "terminal", "structure"], "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-094307-58c77163-4611-4d9e-891a-e97f11b26e1f-postmortem/report.md"}
```

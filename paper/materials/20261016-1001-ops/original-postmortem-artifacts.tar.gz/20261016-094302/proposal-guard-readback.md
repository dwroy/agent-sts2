# 护栏提案源码行号读回补注

保留已登记proposal-guard.md原字节与CLI指纹，补注其源码引用：当前live 0e7998bfa8df267dcf8835a57949bdb982c9feb0下，agent/src/reflex/silent-hp-guard-audit.ts的actual_outcome:null在第36行，第37行是返回对象结束。combat-plan.ts:4477为可信boss胜率约束的注释，具体keepsPick表达式在4479。提案的行为陈述不变；本补注不是新提案，不重复登记或派发，不新增纯bug。正式报告保留此勘误入口。

import collections,hashlib,json,subprocess
from datetime import datetime
from pathlib import Path
p=Path(__file__).parent
root=p.parents[2]
D={x['_line']:x for x in map(json.loads,(p/'decisions.jsonl').open())}
S={x['_line']:x for x in map(json.loads,(p/'states.jsonl').open())}
B=list(map(json.loads,(p/'brain.jsonl').open()))
R=json.loads((p/'FGKZALWSTQQ1-resources.json').read_text())
checks=[]
def check(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
check('局号结束且角色silent',json.loads((p/'runs.jsonl').read_text())['character'].lower()=='silent' and json.loads((p/'runs.jsonl').read_text())['ended'])
check('决策与状态行数',len(D)==461 and len(S)==482)
check('全部脑请求为已接受Sol6.1/xhigh',len(B)==27 and all((x['engine'],x['model'],x['effort'],x['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for x in B))
source_hashes={}
for name in ['runs','decisions','states','brain','run-plans','sl-attempts','run-config']:
 count=0;dig=hashlib.sha256()
 with (root/'logs'/f'{name}.jsonl').open('rb') as f:
  for row in map(json.loads,(p/f'{name}.jsonl').open()):
   f.seek(row['_offset']);raw=f.readline();decoded=json.loads(raw)
   expected={k:v for k,v in row.items() if k not in ['_line','_offset']}
   check(f'{name}原行{row["_line"]}按偏移读回',decoded==expected)
   dig.update(raw);count+=1
 source_hashes[name]={'rows':count,'selected_raw_sha256':dig.hexdigest()}
expected=[(2,56,52),(4,63,51),(8,76,47),(13,76,76),(14,76,36),(15,41,39),(17,51,31),(19,67,46),(23,61,34),(29,76,15),(30,15,15),(30,15,14),(30,15,11),(30,15,0)]
check('十四战斗窗口HP',[(c['floor'],c['entry']['hp'],(c['exit'] or c['last'])['hp']) for c in R['combats']]==expected)
check('首帧T1且前三试退出缺失',all(c['entry_is_turn_one'] for c in R['combats']) and all(c['exit'] is None for c in R['combats'][10:13]))
check('末态15血8挡24攻',S[422331]['state']['run']['current_hp']==15 and S[422331]['state']['combat']['player']['block']==8 and S[422331]['state']['combat']['enemies'][0]['intents'][0]['total_damage']==24)
check('死亡0血敌56/126且残毒3',S[422332]['state']['run']['current_hp']==0 and S[422332]['state']['combat']['enemies'][0]['current_hp']==56 and S[422332]['state']['combat']['enemies'][0]['max_hp']==126 and S[422332]['state']['combat']['enemies'][0]['powers'][0]['amount']==3)
guards=[x for x in D.values() if x.get('hp_guard')]
check('护栏4次省33少伤8',len(guards)==4 and sum(x['hp_guard']['predicted_hp_saved'] for x in guards)==33 and sum(x['hp_guard']['predicted_damage_change'] for x in guards)==-8)
check('四护栏预测原替线',[tuple(x['hp_guard'][z][k] for z in ['before_guard','after_guard'] for k in ['hp_lost','damage_dealt']) for x in guards]==[(18,18,6,11),(12,17,6,16),(22,13,13,13),(17,26,11,26)])
check('原始Jev续步112',sum(x['rationale'].startswith('continuing the Jev-chosen plan') for x in D.values())==112)
jev=[x for x in D.values() if x['decider']=='jev'];pc=[x for x in jev if x['label']=='combat/plan-choice']
check('Jev107/低信心12/战斗89',len(jev)==107 and sum(x['confidence']<.35 for x in jev)==12 and len(pc)==89)
check('原选择最优84真3假2空',collections.Counter(x.get('rollout_best_chosen') for x in pc)==collections.Counter({True:84,False:3,None:2}))
check('饮10弃0炼制5',sum((x.get('chosen') or {}).get('action')=='use_potion' for x in D.values())==10 and sum((x.get('chosen') or {}).get('action')=='discard_potion' for x in D.values())==0 and sum((x.get('expect') or {}).get('card',{}).get('id')=='ALCHEMIZE' for x in D.values())==5)
check('F30赠礼不可用',all(next(z for z in S[n]['state']['run']['potions'] if z['index']==0)['can_use'] is False for n in [422263,422286,422308,422330]))
check('三次SL未派发结束',all(D[n]['result'].startswith('not dispatched: SL') for n in [408931,408952,408972]))
for first,last,cost in [(421995,422026,40),(422062,422108,20),(422205,422235,61)]:
 check(f'关键战{first}净损',S[first]['state']['run']['current_hp']-S[last]['state']['run']['current_hp']==cost)
check('Jev token',sum(x['usage']['input_tokens'] for x in jev)==831817 and sum(x['usage']['output_tokens'] for x in jev)==6403)
check('大脑用量',sum(x['usage']['inputTokens'] for x in B)==4921986 and sum(x['usage']['outputTokens'] for x in B)==35872 and sum(x['usage']['cacheHitTokens'] for x in B)==2219776 and sum(x['usage']['reasoningTokens'] for x in B)==31761 and sum(x['latency_ms'] for x in B)==1112219)
check('决策时长',(datetime.fromisoformat(D[408993]['ts'])-datetime.fromisoformat(D[408533]['ts'])).total_seconds()==2301.015)
config=json.loads((p/'run-config.jsonl').read_text());check('配置原行446',config['_line']==446)
check('主经验恰三条',sum(x.startswith('- [') and not x.startswith('- [记录]') for x in (p/'lesson.md').read_text().splitlines())==3)
if (root/'notes/lessons.md').exists():
 text=(root/'notes/lessons.md').read_text()
 if '\n## FGKZALWSTQQ1（' in text:
  appended=text.split('\n## FGKZALWSTQQ1（',1)[1].split('\n## ',1)[0]
  expected=(p/'lesson.md').read_text().split('\n## FGKZALWSTQQ1（',1)[1].rstrip('\n')
  check('已追加小节逐字等草稿',appended.rstrip('\n')==expected)
result={'checks':len(checks),'passed':True,'source_hashes':source_hashes,'live_reference':subprocess.check_output(['git','-C',str(root/'.worktrees/live'),'rev-parse','HEAD'],text=True).strip()}
(p/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

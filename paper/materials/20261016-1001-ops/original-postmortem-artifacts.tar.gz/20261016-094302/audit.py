import json,sys,collections
from pathlib import Path
p=Path(__file__).parent
d=[json.loads(x) for x in (p/'decisions.jsonl').open()]
s=[json.loads(x) for x in (p/'states.jsonl').open()]
r=json.loads((p/'FGKZALWSTQQ1-resources.json').read_text())
mode=sys.argv[1]
def short(x,n=260):return json.dumps(x,ensure_ascii=False)[:n]
if mode=='resources':
 for c in r['combats']:
  print('战斗',c['sequence'],'F',c['floor'],c['enemies'],'入口',c['entry'],'出口',c['exit'],'末态',c['last'],'边界',c['end'])
 print('非战斗变化')
 for x in r['resource_changes']:
  if x['combat_sequence'] is None:print(short(x,1600))
elif mode=='brain':
 for x in d:
  if x['decider']=='codex':
   print('d',x['_line'],'F',x['floor'],x['label'],'chosen',short(x.get('chosen'),320),'reason',x['rationale'],'usage',x.get('usage'),'deepseek',short(x.get('deepseek'),500))
elif mode=='turns':
 for c in r['combats']:
  if c['floor']<int(sys.argv[2]):continue
  print('战斗',c['sequence'],'F',c['floor'])
  group=collections.defaultdict(list)
  for x in s:
   if c['entry']['line']<=x['_line']<=c['last']['line']:group[x['state']['turn']].append(x)
  for t,ss in group.items():
   def pack(x):
    st=x['state'];co=st.get('combat') or {};pl=co.get('player') or {}
    return {'s':x['_line'],'hp':st['run']['current_hp'],'block':pl.get('block'),'energy':pl.get('energy'),'powers':[(z['power_id'],z['amount']) for z in pl.get('powers',[])],'enemies':[(e['index'],e['enemy_id'],e['current_hp'],e['block'],[(z['power_id'],z['amount']) for z in e.get('powers',[])],e.get('intents')) for e in co.get('enemies',[])]}
   print('T',t,'首',short(pack(ss[0]),1400),'末',short(pack(ss[-1]),1400))
  for x in d:
   if c['entry']['ts']<=x['ts']<=c['last']['ts'] and x['label'].startswith('combat/'):
    print('d',x['_line'],'T',x['turn'],x['decider'],x['label'],short(x.get('chosen'),200),x['rationale'][:650])
elif mode=='shape':
 for label in ['combat/plan-choice','combat/least-loss','rest/plan','map/route-change']:
  x=next(x for x in d if x['label']==label)
  print(label,'keys',list(x),'chosen',x.get('chosen'),'expect',x.get('expect'),'journal',short(x.get('journal'),2500),'result',short(x.get('result'),1700),'usage',x.get('usage'),'questionskeys',list(x.get('questions',{})))
  q=next(iter(x.get('questions',{}).values()),{});print('questionkeys',list(q),'optionsfirst',short(q.get('options',[None])[0],2200),'factkeys',list(q.get('facts',{})))
 print('plans')
 for x in map(json.loads,(p/'run-plans.jsonl').open()):print(short(x,2200))

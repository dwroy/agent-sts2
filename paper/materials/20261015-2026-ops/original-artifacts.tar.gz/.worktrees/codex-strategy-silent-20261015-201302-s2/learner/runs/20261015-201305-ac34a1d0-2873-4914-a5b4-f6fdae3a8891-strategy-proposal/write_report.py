"""Write this batch's evidence-qualified dispositions without changing strategy or queue."""
import datetime
import json
import subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
BATCH='20261015-201302-s2-strategy-proposal'
dispatch=json.loads((BASE/'dispatch.json').read_text())
queue=json.loads((BASE/'queue-snapshot.json').read_text())['original']
source=json.loads((BASE/'source-readback.json').read_text())
verification=json.loads((BASE/'evidence-verification.json').read_text())
checks=json.loads((BASE/'material-checks.json').read_text())
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base==source['base'] and subprocess.check_output(['git','status','--porcelain'],text=True)==''
assert verification['all_verified'] and checks['passed']
entries=[
('03754e1265894000','RC61MFQM63Y6 F23 T3/T4，states:285222—285230。速度药净敏1→6；斗篷12挡，防御另9挡；末小刀零直伤仍增4挡。',
 '现模型已有逐牌敏捷、柔嫩及折扇入口；原提案要求核组合和未建能力收益，不能由文字知识存在推定全覆盖。',
 '逐牌按现场属性及实际触发重核；若核出确定预测误差，再作固定源码负控及修复。',
 '当前未定位这组条件新的确定错排；缺逐组件候选误差、改药时机的完整后继及独立留出。保留既有局部模型，不调整排序或持有价。',
 '零直伤仍加挡反驳只按直伤记收益；没有改时机实胜对照，不能从本局失败推药无用。',[285222,285223,285224,285225,285226,285227,285228,285229,285230]),
('e5ea36df117ca9b7','XTSV1U9JD34T F49 T1，states:286896—286897；首稳定可行动帧只有进阶之灾、3能量、16挡。',
 '当前战斗入口读实际手牌；尚未核到把本题已接管动作写成自主启动的具体当前题面。',
 '保留接管过程未知，区分首稳定帧与未记录的内部自动行动；出现可复现的错误消费者再补。',
 '接管内部顺序/抽序没有记录，也没有同资源自主开场对照；不足以实现自动过程推演、禁取遗物或整体duplicate。',
 '本帧仍有3能量，不能把接管一律写成耗尽能量；该局持遗物后其他战斗胜利不支持统一禁取。',[286896,286897]),
('ab055ef7dfbb44e5','XTSV1U9JD34T F49 T1/T4，states:286897—286899、286986—286987；幽灵新建无实体1，26攻→1，本轮零损且次轮留10挡；末T4建夜魇3后仍当轮死。',
 '单层幽灵窄模型已有live祖先96f17377a331e50ea5b6a3fe8d2b605932ed1bd4；只限Silent A10无既有层，不是饮用时机/复制整战模型。',
 '只认已建且存活兑现的后继；多层、延后饮用和独立持有价需补可比证据。',
 '六次同局均T1饮幽灵，没有延后饮用或既有层叠加的完整对照；末T4复制未到手，不能由此断言去掉夜魇可救场。局部已实现不关闭整项。',
 '早喝实际兑现零损，反驳早喝完全浪费；复制后死也不证明复制牌无价值。',[286897,286898,286899,286986,286987]),
('0129c465c6f5bd79','BTSRF7JL1W1Y F31 T2，states:286158—286163；生存者后唯一后继突然一拳离手。XTSV1U9JD34T F48 T8，286892—286897：毒胜32→23，无恢复入F49。',
 '普通单弃bf423c173d3be348a4ad714e1d26516df619ff41与毒胜保血搜索222445a9bb6bf56cb4f3ceea2cc8b20fba54128f均为实际live祖先；有范围护栏。',
 '宽项仍需核弃牌后实际重规划、接管、复制、目标顺序与SL完整后继，不把两个局部源码等同全项。',
 '已实现单弃/保血子项，不足以覆盖接管/复制/杀序及SL整战；缺完整可执行候选认证和同条件替代后继。保留waiting而不重复实现或整体duplicate。',
 '少当轮损血不自动证明F49转胜；多选弃牌仍需真实选择后重算，不能擅定必留牌或统一杀序。',[286158,286159,286160,286161,286162,286163,286892,286893,286894,286897]),
('abe9d5d0be109a9f','BTSRF7JL1W1Y F30，states:286113→286141实70→42；XTSV1U9JD34T F48，286843→286894实97→23，再286897的23入F49。',
 '终局/路线已有资源成本模型，但胜战耗血、未来火、SL恢复不可混记为可用收益。',
 '只按实到资源比较，待同条件路线/休息/留药后继再校准权重或安全血线。',
 '无同资源替代路线、休息对锻造、留药的完整实盘对照和独立时间留出；不能据两场净血差拟新资源权重、安全血线或SL/终局阈值。',
 '赢战本身仍可耗大量HP；计划中未来节点不等于抵达，恢复旧存档药不等新获得。',[286113,286141,286843,286894,286897]),
('f16527e59b5cc1e0','BTSRF7JL1W1Y F31 T2，states:286159—286163，牌挡13与覆甲3分列；XTSV1U9JD34T F49 T1新无实体1及留挡10，286897—286899。',
 '已有临时降力、敏捷、脆弱及留挡上限入口；组合是否准确须逐项核实。',
 '分开卡牌挡/覆甲/旧挡、临时降力与成长；缺失组合先保未知。',
 '这些已观察局部帧未定位当前新增确定模型差；缺未知组合逐项误差、延后用药完整后继与独立持有价，不能拟全组合时机或新权重。',
 '留10是上限而非每轮保底；新增敏捷不能倒补旧挡，整战失败不是局部公式反例。',[286159,286160,286161,286162,286163,286897,286898,286899]),
('7a8e9ccb7e646538','9Z9H2EXKLF3T F48末试T10/T11，states:287999—288008：首挡18，后续9和10合37；18→3实损15；39毒后敌余32，玩家0血。',
 '已有毒、持牌伤、被动反伤及一次倍率消费的模型入口；24/24失败只是有限推演结果。',
 '将毛伤、实际净损、毒与反伤及死亡截断分账；核出模型差再改，SL阈值须独立后继支持。',
 '缺逐击毛伤事件、零血截断后未执行击及同条件改药/SL整战；不能用局部净差或有限全败率校准血价和必死阈值。',
 '37挡仍损15表明必须算持牌代价；死后第二击未执行不能预支反伤，三次SL非三局。',[287999,288000,288003,288004,288005,288006,288007,288008]),
('cd9f76184de6e29a','15个所引Silent关联局共22对F17→18/F33→34同上限相邻帧；逐对见act-transitions.json，A9三局/A10十二局，全部实回floor(缺血×80%)。',
 '当前经验已载跨幕公式，路线资源/SL/终局宽项还含营火、事件、遗物、实际抵达与未来资源。',
 '限定已观察等级/条件，先核消费者具体误算；原公式与资源分源保持，不外推未知交互。',
 '22对只复核已观察跨幕回复；缺未知遗物/先古交互、同资源替代路线、具体当前消费者误算及后继资源兑现，不能把公式作为整个资源/SL/终局项已完成。',
 '最大HP变化需另计；未来营火未到不算恢复，SL恢复不当新治疗或独立样本。',[]),
('292f6731bdb9b669','7X0W3U8TVA2A F31 T13，decisions:282021 target_index=2；states:288470→288471后段0→7毒、HP25不变；288472后段18、玩家死。',
 'observedPoison仍由知识恶魔严格组合或连王F48/F49提供；该F31头骨组合不在当前入口。未知持有价有no_table/no_value与holdHp=null来源。',
 '7仅作为本次头骨组合后段实测总增量，不反推基础药效、不再叠头骨；可比组合/目标与早用后继够后再接入口。',
 '只有一次后段零毒实饮，缺前/中段、重附目标或其他增益组合及早喝整战和独立持有价；不能把7无条件传给所有目标/时机或据此拟药价。继续保留未模拟边界。',
 '已喝仍死亡，反驳有7毒即足够救场；不反驳早用可能有益，但也没有其收益证据。',[288470,288471,288472]),
('0802f69b28d25079','MTQ0EUBJ3R6T F23 T3，states:288806—288812与288899—288905；原29挡损0/净伤13，SL替19挡损8/净伤19。decisions:282434的plan1/plan4均24/24死亡。',
 'SL在全败池仍探索未试线，当前明确写推演未见更常死；不是实盘更安全认证，原必死判官独立。',
 '分别保留即时HP代价、伤害、存活回合和余敌；同条件完整后继/留出足够后再评估排序。',
 '四次SL属同局；原线也失败，没有同条件完整胜线与独立时间留出，缺早药/留药和其他路线受控结果。不能据8血换6伤建立8点门槛、改SL血价或药水阈值。',
 '原线更省本轮血却也败；改变出牌后抽序/能力建立同变，末轮敌残不能全归单张攻击或当独立胜率收益。',[288806,288811,288812,288899,288904,288905])]
results=[];details=[]
for suffix,evidence,old,new,reason,counter,lines in entries:
    ident='silent-proposal-'+suffix;p=queue[ident]
    result={'id':ident,'state':'waiting','reason':reason};results.append(result)
    details.append({**result,'character':'silent','ascension_scope':'A9/A10仅已观察窗口；各新行为候选不外推其他角色','ledger':p['ledger'],'runs':p['runs'],'evidence':evidence,'old_behavior':old,'expected_behavior':new,'counterexamples_and_unknowns':counter,'state_lines':lines})
(BASE/'dispositions.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n')
report_path=str(BASE/'report.md');proposal_path=str(BASE/'proposal.md')
now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
intro=f'''# 静默猎手指定提案逐项审查\n\n批次：{BATCH}。记录时间：{now}。基线：`{base}`。\n\n身份：普通队列批次，reason=proposal，10个proposal_ids全部处理；无research_request/implementation_request/补链字段。根deck-size请求属于另一批，不承接专题、不读其work_spec或扩展领取。工作树开工与结束均干净；`git merge --no-edit main` 返回Already up to date。\n\n结论：10项均waiting，未形成新源码提案或新策略参数。三个已实现局部子项有实际live祖先，但不足以把相关宽提案全部duplicate。保留旧规则、原提案SHA和现有台账状态。没有新增证据局、独立反事实胜线或新机制反证，不重复历史复盘，不关闭宽父要求。\n\n## 证据范围与来源\n\n派发锚点：{','.join(dispatch['runs'])}。\n为处理指定提案再核其直接关联5局：9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T。合计15局；runs.jsonl确认全部SILENT，A9为HMVJKM56S4Q8/F4QKG4J1AJJZ/G403VCZ3BH1B，余12局A10。无其他角色知识或样本。SL仍按同一局的相关尝试，不加独立分母。\n\n共用extract_evidence.py抽取8流。states11008、decisions10609、sl-attempts109、run-config16、run-plans97、brain570、runs15、fight-plans0，合计22424所属原行；每行原offset/bytes/SHA/JSON/显式身份已重读核实。run-plans按run，其他流按run_id/state.run_id/fingerprint.run；正文提及不算所属局。各source_size与计数在evidence/evidence-manifest.json，独立核验在evidence-verification.json。states/decisions各2条、brain1条源流无效JSON只登记抽取限制；本次截点fight-plans0只表示未选到，不声称日志从未存在。\n\n570条所属brain行实际engine=codex、model=gpt-6.1-sol、effort=high。这是历史证据属性，不是本学习者原生会话模型核验；本次未取得本学习者原生模型/推理档回执，不声称已切换。原runs的兼容deepseek_calls不当真实DeepSeek答题数，dirty历史源码不能由当前树冒认。\n\n## 当前源码与已实现子项\n\n只读live观察提交：`{source['live']}`。source-readback.json记录13叶逐SHA，10叶相同、3叶仅所见历史Roy/Dai注释差，完整差异保留base-vs-live.patch；没有编译/全源码等价声明。\n\n- `96f17377a331e50ea5b6a3fe8d2b605932ed1bd4`：Silent A10无既有层时单层幽灵模型；不覆盖既有层/延后饮药收益/复制兑现。\n- `bf423c173d3be348a4ad714e1d26516df619ff41`：普通生存者单弃与绷带补挡解耦；未知多选待实际选择重算。\n- `222445a9bb6bf56cb4f3ceea2cc8b20fba54128f`：已观察连王首王的存活毒胜继续寻找保血候选；不证明下一场可赢。\n\n上述三个commit均核是base/live实际祖先，仅作为局部实现证据，本批没有新提交。combat-plan.ts:3223/3232/3233与silent-demon-potion.ts核得知识恶魔严格组合和连王范围，不能据observedPoison接口存在就说F31头骨组合已覆盖。potion-cost.ts持有价缺表使用holdHp=null、zero=no_table并给来源；未知不是学得零值，不凭空重设价格。\n\n'''
body=[]
for d in details:
    body.append(f'''## {d['id']} — waiting\n\n原提案：{queue[d['id']]['proposal']}；SHA256：{queue[d['id']]['proposal_sha256']}。\n账本：{','.join(d['ledger'])}。来源任务：{queue[d['id']]['source_task']}；实现任务：strategy-proposal。领域：{','.join(queue[d['id']]['domains'])}。仅本角色已观察范围。\n\n证据：{d['evidence']}\n\n既有行为：{d['old_behavior']}\n\n待验证行为：{d['expected_behavior']}\n\n反例与边界：{d['counterexamples_and_unknowns']}\n\n本次处置/缺数据：{d['reason']}\n\n验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。\n\n''')
footer=f'''## 校验、登记与交付限制\n\nmaterial-checks.json共57条固定材料断言通过，覆盖关键敏捷/格挡/弃牌/毒药/复制死亡/SL差额与22对跨幕回复；不是tsc、vitest、撤源码负控、全候选认证或策略收益验收。未改源码，撤源码失败/恢复通过不适用；tests={{"tsc":null,"vitest":null,"cases":null}}。未提交、未合live、未分配eval版本，fixes=[]，merged=null。不把sandbox或未运行测试写成成功。\n\n只经根ledger.py update给44个原关联账本追加本报告/提案路径和本批处置追溯，by=learner:strategy-proposal；没有新claim/新证据样本，不新增重复id，不降级原shipped，不标shipped。CLI输入、stdout、退出码及保护字段读回保存在ledger-updates.jsonl、ledger-update.stdout、ledger-receipt.json。已有10个code_proposals保持原ID，本批implementation_domains=[]表示无实际实现；原领域保留在dispositions.json。最终队列状态由宿主消费result.json中的proposal_results，未手改learn.json或专用队列。\n\n所有失败材料保留：read-attempts.txt列首次路径/空combat与输出截断；verify_evidence-v1.txt及evidence-verification.stderr保留首次相对父目录算错的失败，v2按实际learner/extract_evidence.py路径重读全部22424行通过。此错误不算生产缺陷。\n\n提案交付：{proposal_path}\n报告交付：{report_path}\n\n运维应保留10项waiting，按每项具体缺数据条件待新局再审；本批没有新增必要反证/异议，不关闭原资源、SL、量化或学习入库父要求。没有源码或规则实际上线，因此无新发布、双通知或shipped登记。\n'''
text=intro+''.join(body)+footer
(BASE/'proposal.md').write_text(text)
(BASE/'report.md').write_text(text)
result={'task':'strategy-proposal','character':'silent','batch':BATCH,'base':base,'runs':dispatch['runs'],'fixes':[],'skipped':[],'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':list(queue),'implementation_domains':[],'proposal_results':results,'report':report_path}
(BASE/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
ledger=json.loads((BASE/'ledger-before.json').read_text());updates=[]
for id in ledger:
    linked=[d for d in details if id in d['ledger']]
    note=f'{BATCH}：仅审查本批原提案；原始所属22424行逐offset/bytes/SHA/身份核，固定材料57断言通过（非生产测试）。关联'+','.join(d['id'] for d in linked)+'均waiting；详见本批report.md/dispositions.json。'+''.join(d['reason'] for d in linked)
    updates.append({'id':id,'by':'learner:strategy-proposal','where':{'proposal':[proposal_path,report_path]},'note':note})
(BASE/'ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
print(json.dumps({'report':report_path,'proposals':len(results),'ledger_updates':len(updates),'base':base},ensure_ascii=False))

"""Check the recorded material values, without exercising production strategy."""
import json
from collections import Counter
from pathlib import Path
BASE=Path(__file__).resolve().parent
states={r['line']:r for r in map(json.loads,(BASE/'state-summaries.jsonl').open())}
checks=[]
def check(label,value,expected,lines):
    checks.append({'label':label,'actual':value,'expected':expected,'state_lines':lines,'passed':value==expected})
    assert value==expected,(label,value,expected)
def power(n,id):return states[n]['powers'].get(id,0)
def enemy(n,i=0):return states[n]['enemies'][i]
def hp(n):return states[n]['hp']
check('RC速度药净敏1到6',[power(n,'DEXTERITY_POWER') for n in (285223,285224)],[1,6],[285223,285224])
check('RC药不补旧挡',[states[n]['block'] for n in (285223,285224)],[0,0],[285223,285224])
check('RC斗篷实挡12',states[285225]['block'],12,[285224,285225])
check('RC防御增挡9',states[285227]['block']-states[285226]['block'],9,[285226,285227])
check('RC小刀零直伤',enemy(285228)['hp']-enemy(285229)['hp'],0,[285228,285229])
check('RC小刀被动4挡',states[285229]['block']-states[285228]['block'],4,[285228,285229])
check('RC次轮敏与临时层撤回',[power(285230,p) for p in ('DEXTERITY_POWER','ANTICIPATE_POWER','SPEED_POTION_POWER')],[0,0,0],[285230])
check('X首稳定手牌',[v['id'] for v in states[286897]['hand']],['ASCENDERS_BANE'],[286897])
check('X首稳定资源',[hp(286897),states[286897]['block'],states[286897]['energy']],[23,16,3],[286897])
check('X幽灵1层',power(286898,'INTANGIBLE_POWER'),1,[286897,286898])
check('X幽灵攻击26到1',[enemy(n)['intents'][0]['total_damage'] for n in (286897,286898)],[26,1],[286897,286898])
check('X幽灵本轮零损',hp(286899),23,[286897,286899])
check('X次轮留10挡',states[286899]['block'],10,[286899])
check('X复制建立仍当轮死',[power(286986,'NIGHTMARE_POWER'),hp(286986),hp(286987)],[3,1,0],[286986,286987])
check('B生存者弃唯一后继牌',[v['id'] for v in states[286162]['hand']],[],[286161,286162])
check('B牌挡13覆甲3分列',[states[286162]['block'],power(286162,'PLATING_POWER')],[13,3],[286162])
check('X毒胜前32胜后23',[hp(286893),hp(286894)],[32,23],[286893,286894])
check('X下一战实23',[hp(286894),hp(286897)],[23,23],[286894,286897])
check('B赢战仍70到42',[hp(286113),hp(286141)],[70,42],[286113,286141])
check('X赢战仍97到23',[hp(286843),hp(286894)],[97,23],[286843,286894])
check('9Z首挡18后续9和10',[states[n]['block'] for n in (287999,288000,288003,288004)],[0,18,27,37],[287999,288000,288003,288004])
check('9ZT10实损15',hp(288004)-hp(288005),15,[288004,288005])
check('9Z毒39和余敌32',[enemy(288006)['powers']['POISON_POWER'],enemy(288008)['hp']],[39,32],[288006,288008])
check('9Z结算死',hp(288008),0,[288008])
check('毒药前后后段0到7',[enemy(288470,2)['powers'].get('POISON_POWER',0),enemy(288471,2)['powers'].get('POISON_POWER',0)],[0,7],[288470,288471])
check('毒药施加不即时扣HP',[enemy(288470,2)['hp'],enemy(288471,2)['hp']],[25,25],[288470,288471])
check('毒药结算后18',enemy(288472,2)['hp'],18,[288472])
check('毒药仍死',hp(288472),0,[288472])
check('MT原29和替19挡',[states[n]['block'] for n in (288811,288904)],[29,19],[288811,288904])
check('MT原零损和替损8',[hp(288806)-hp(288812),hp(288899)-hp(288905)],[0,8],[288806,288812,288899,288905])
check('MT原净伤13与替19',[102-sum(e['hp'] for e in states[n]['enemies']) for n in (288812,288905)],[13,19],[288812,288905])
trans=json.loads((BASE/'act-transitions.json').read_text())
check('跨幕数量',len(trans),22,[])
for t in trans:check('跨幕'+t['run']+str(t['floor']),t['actual'],t['expected_heal'],[t['before_line'],t['after_line']])
decisions={x['line']:x for x in map(json.loads,(BASE/'evidence/decisions.evidence.jsonl').open())}
ghost=[x for x in decisions.values() if x['row'].get('run_id')=='XTSV1U9JD34T' and x['row'].get('floor')==49 and x['row'].get('chosen',{}).get('action')=='use_potion' and x['row'].get('expect',{}).get('potion',{}).get('id')=='GHOST_IN_A_JAR']
check('X六次同局幽灵饮用均T1',[x['row']['turn'] for x in ghost],[1]*6,[])
mt=decisions[282434]['row'];options=[]
for key,value in mt['questions']['plan']['criteria'].items():
    try:o=json.loads(value)
    except (ValueError,TypeError):continue
    if o.get('plays') in ('迷雾+, then potion 速度药水, then 防御, then 妙计, then 防御','打击 -> 异螨 #2, then 迷雾+, then potion 速度药水, then 防御, then 妙计'):
        options.append({'key':key,**o})
check('MT原SL明确改线','SL explore' in mt['rationale'],True,[])
check('MT已选原候选24全死','24/24' in options[0]['rollout'],True,[])
engine_counts=Counter()
for x in map(json.loads,(BASE/'evidence/brain.evidence.jsonl').open()):
    r=x['row'];engine_counts[(r.get('engine'),r.get('model'),r.get('effort'))]+=1
refs={n:{k:states[n][k] for k in ('run_id','line','offset','bytes','sha256','floor','turn')} for c in checks for n in c['state_lines']}
(BASE/'material-checks.json').write_text(json.dumps({'kind':'材料断言，不是生产测试或撤源码负控','checks':checks,'count':len(checks),'passed':all(c['passed'] for c in checks),'source_refs':refs,'ghost_decisions':[{'line':x['line'],'offset':x['offset'],'sha256':x['sha256'],'attempt':x['row']['sl_attempt'],'turn':x['row']['turn']} for x in ghost],'mt_options':options,'brain_groups':[{'engine':k[0],'model':k[1],'effort':k[2],'count':v} for k,v in engine_counts.items()]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'count':len(checks),'passed':True,'brain_groups':dict((str(k),v) for k,v in engine_counts.items())},ensure_ascii=False))

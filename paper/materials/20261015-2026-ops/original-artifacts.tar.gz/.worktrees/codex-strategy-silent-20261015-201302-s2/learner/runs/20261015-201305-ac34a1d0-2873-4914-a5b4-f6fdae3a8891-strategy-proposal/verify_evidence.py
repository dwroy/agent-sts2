"""Re-read every extracted original line at its recorded byte offset."""
import hashlib
import importlib.util
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extract',BASE.parents[1]/'extract_evidence.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifest=json.loads((BASE/'evidence/evidence-manifest.json').read_text())
identities=json.loads((BASE/'run-identities.json').read_text())
checks=[]
for m in manifest:
    path=BASE/'evidence'/(m['stream']+'.evidence.jsonl');counts={r:0 for r in identities};digest=hashlib.sha256()
    with Path('/home/dw/Projects/agent-sts2/logs',m['stream']+'.jsonl').open('rb') as original, path.open('rb') as selected:
        for encoded in selected:
            digest.update(encoded);x=json.loads(encoded);original.seek(x['offset']);raw=original.read(x['bytes'])
            assert x['offset']+x['bytes']<=m['source_size']
            assert hashlib.sha256(raw).hexdigest()==x['sha256']
            assert json.loads(raw)==x['row']
            assert module.run_identity(x['row'])==x['run_id']
            assert x['run_id'] in identities and identities[x['run_id']]['character']=='SILENT'
            counts[x['run_id']]+=1
    assert counts==m['counts'] and digest.hexdigest()==m['output_sha256']
    checks.append({'stream':m['stream'],'rows':sum(counts.values()),'source_size':m['source_size'],'verified':True,'sha256':digest.hexdigest(),'counts':counts})
(BASE/'evidence-verification.json').write_text(json.dumps({'checks':checks,'total':sum(c['rows'] for c in checks),'all_verified':True},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'total':sum(c['rows'] for c in checks),'all_verified':True}))

"""Summarize only the explicitly extracted Silent evidence; retain source references."""
import json
from pathlib import Path
from collections import Counter
BASE = Path(__file__).resolve().parent

def powers(xs):
    return {p['power_id']:p.get('amount') for p in (xs or [])}

def compact(x):
    r=x['row'];s=r['state'];run=s.get('run') or {};c=s.get('combat') or {};p=c.get('player') or {}
    return {**{k:x[k] for k in ('run_id','line','offset','bytes','sha256')},'ts':r.get('ts'),'observed_ts':r.get('observed_ts'),
      'floor':run.get('floor'),'act':run.get('act_id'),'screen':s.get('screen'),'turn':s.get('turn'),'in_combat':s.get('in_combat'),
      'run_hp':run.get('current_hp'),'run_max':run.get('max_hp'),'hp':p.get('current_hp'),'max_hp':p.get('max_hp'),
      'block':p.get('block'),'energy':p.get('energy'),'powers':powers(p.get('powers')),
      'relics':[{'id':v.get('relic_id'),'counter':v.get('counter')} for v in run.get('relics',[])],
      'potions':[{'slot':v.get('index'),'id':v.get('potion_id')} for v in run.get('potions',[]) if v.get('occupied')],
      'hand':[{'index':v.get('index'),'id':v.get('card_id'),'playable':v.get('playable'),'cost':v.get('energy_cost'),
        'dynamic':{i.get('name'):i.get('current_value') for i in v.get('dynamic_values',[])},'text':v.get('resolved_rules_text')} for v in c.get('hand',[])],
      'enemies':[{'index':e.get('index'),'id':e.get('enemy_id'),'hp':e.get('current_hp'),'block':e.get('block'),'alive':e.get('is_alive'),
        'powers':powers(e.get('powers')),'intents':e.get('intents')} for e in c.get('enemies',[])],
      'actions':s.get('available_actions'),'readiness':c.get('action_readiness')}

def main():
    counts=Counter()
    with (BASE/'state-summaries.jsonl').open('w') as dest:
      for line in (BASE/'evidence/states.evidence.jsonl').open():
        x=json.loads(line);s=x['row']['state'];assert s['run']['character_id']=='SILENT'
        row=compact(x);counts[x['run_id']]+=1;dest.write(json.dumps(row,ensure_ascii=False)+'\n')
    print(json.dumps(counts))

if __name__=='__main__':main()

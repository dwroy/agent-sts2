# 静默猎手指定提案逐项审查

批次：20261015-201302-s2-strategy-proposal。记录时间：2026-10-15T20:23:57+08:00。基线：`ff0a2c35f7bf0d92ffca1d048de14fbd5fce3943`。

身份：普通队列批次，reason=proposal，10个proposal_ids全部处理；无research_request/implementation_request/补链字段。根deck-size请求属于另一批，不承接专题、不读其work_spec或扩展领取。工作树开工与结束均干净；`git merge --no-edit main` 返回Already up to date。

结论：10项均waiting，未形成新源码提案或新策略参数。三个已实现局部子项有实际live祖先，但不足以把相关宽提案全部duplicate。保留旧规则、原提案SHA和现有台账状态。没有新增证据局、独立反事实胜线或新机制反证，不重复历史复盘，不关闭宽父要求。

## 证据范围与来源

派发锚点：RC61MFQM63Y6,XTSV1U9JD34T,BTSRF7JL1W1Y,9Z9H2EXKLF3T,HMVJKM56S4Q8,F4QKG4J1AJJZ,G403VCZ3BH1B,25226ZFLNR1J,JLN5SK17W4FQ,JMH5C51RLN4E。
为处理指定提案再核其直接关联5局：9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T。合计15局；runs.jsonl确认全部SILENT，A9为HMVJKM56S4Q8/F4QKG4J1AJJZ/G403VCZ3BH1B，余12局A10。无其他角色知识或样本。SL仍按同一局的相关尝试，不加独立分母。

共用extract_evidence.py抽取8流。states11008、decisions10609、sl-attempts109、run-config16、run-plans97、brain570、runs15、fight-plans0，合计22424所属原行；每行原offset/bytes/SHA/JSON/显式身份已重读核实。run-plans按run，其他流按run_id/state.run_id/fingerprint.run；正文提及不算所属局。各source_size与计数在evidence/evidence-manifest.json，独立核验在evidence-verification.json。states/decisions各2条、brain1条源流无效JSON只登记抽取限制；本次截点fight-plans0只表示未选到，不声称日志从未存在。

570条所属brain行实际engine=codex、model=gpt-6.1-sol、effort=high。这是历史证据属性，不是本学习者原生会话模型核验；本次未取得本学习者原生模型/推理档回执，不声称已切换。原runs的兼容deepseek_calls不当真实DeepSeek答题数，dirty历史源码不能由当前树冒认。

## 当前源码与已实现子项

只读live观察提交：`fe6462651b593b9831581c088deface9957a404f`。source-readback.json记录13叶逐SHA，10叶相同、3叶仅所见历史Roy/Dai注释差，完整差异保留base-vs-live.patch；没有编译/全源码等价声明。

- `96f17377a331e50ea5b6a3fe8d2b605932ed1bd4`：Silent A10无既有层时单层幽灵模型；不覆盖既有层/延后饮药收益/复制兑现。
- `bf423c173d3be348a4ad714e1d26516df619ff41`：普通生存者单弃与绷带补挡解耦；未知多选待实际选择重算。
- `222445a9bb6bf56cb4f3ceea2cc8b20fba54128f`：已观察连王首王的存活毒胜继续寻找保血候选；不证明下一场可赢。

上述三个commit均核是base/live实际祖先，仅作为局部实现证据，本批没有新提交。combat-plan.ts:3223/3232/3233与silent-demon-potion.ts核得知识恶魔严格组合和连王范围，不能据observedPoison接口存在就说F31头骨组合已覆盖。potion-cost.ts持有价缺表使用holdHp=null、zero=no_table并给来源；未知不是学得零值，不凭空重设价格。

## silent-proposal-03754e1265894000 — waiting

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-mechanisms.md；SHA256：518c139723decc4238c7ea5641e671c8738ec240118ff5140ca503612295599f。
账本：silent-0006,silent-0011,silent-0013,silent-0080,silent-0088,silent-0101,silent-0232,silent-0253。来源任务：experience-update；实现任务：strategy-proposal。领域：combat,potion。仅本角色已观察范围。

证据：RC61MFQM63Y6 F23 T3/T4，states:285222—285230。速度药净敏1→6；斗篷12挡，防御另9挡；末小刀零直伤仍增4挡。

既有行为：现模型已有逐牌敏捷、柔嫩及折扇入口；原提案要求核组合和未建能力收益，不能由文字知识存在推定全覆盖。

待验证行为：逐牌按现场属性及实际触发重核；若核出确定预测误差，再作固定源码负控及修复。

反例与边界：零直伤仍加挡反驳只按直伤记收益；没有改时机实胜对照，不能从本局失败推药无用。

本次处置/缺数据：当前未定位这组条件新的确定错排；缺逐组件候选误差、改药时机的完整后继及独立留出。保留既有局部模型，不调整排序或持有价。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-e5ea36df117ca9b7 — waiting

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-controlled-opening.md；SHA256：a305a121a184c84264ac5434fddaaeb75941c0a96a350abda85418824725c9ea。
账本：silent-0164。来源任务：postmortem；实现任务：strategy-proposal。领域：combat,structure。仅本角色已观察范围。

证据：XTSV1U9JD34T F49 T1，states:286896—286897；首稳定可行动帧只有进阶之灾、3能量、16挡。

既有行为：当前战斗入口读实际手牌；尚未核到把本题已接管动作写成自主启动的具体当前题面。

待验证行为：保留接管过程未知，区分首稳定帧与未记录的内部自动行动；出现可复现的错误消费者再补。

反例与边界：本帧仍有3能量，不能把接管一律写成耗尽能量；该局持遗物后其他战斗胜利不支持统一禁取。

本次处置/缺数据：接管内部顺序/抽序没有记录，也没有同资源自主开场对照；不足以实现自动过程推演、禁取遗物或整体duplicate。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-ab055ef7dfbb44e5 — waiting

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-survival-and-ghost.md；SHA256：c5490a44836c3900e1d03b59370dea8c076a8b5435236f7a5e575e4c0b516b17。
账本：silent-0140,silent-0069,silent-0005,silent-0206。来源任务：postmortem；实现任务：strategy-proposal。领域：combat,potion。仅本角色已观察范围。

证据：XTSV1U9JD34T F49 T1/T4，states:286897—286899、286986—286987；幽灵新建无实体1，26攻→1，本轮零损且次轮留10挡；末T4建夜魇3后仍当轮死。

既有行为：单层幽灵窄模型已有live祖先96f17377a331e50ea5b6a3fe8d2b605932ed1bd4；只限Silent A10无既有层，不是饮用时机/复制整战模型。

待验证行为：只认已建且存活兑现的后继；多层、延后饮用和独立持有价需补可比证据。

反例与边界：早喝实际兑现零损，反驳早喝完全浪费；复制后死也不证明复制牌无价值。

本次处置/缺数据：六次同局均T1饮幽灵，没有延后饮用或既有层叠加的完整对照；末T4复制未到手，不能由此断言去掉夜魇可救场。局部已实现不关闭整项。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-0129c465c6f5bd79 — waiting

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-replay.md；SHA256：bf425049a5868e3bec28ff845f0dcc2f5560594b3b85b4380a378ab2295bdcdc。
账本：silent-0009,silent-0021,silent-0024,silent-0057,silent-0079,silent-0090,silent-0140,silent-0164,silent-0205,silent-0268,silent-0271。来源任务：experience-update；实现任务：strategy-proposal。领域：combat,sl,terminal。仅本角色已观察范围。

证据：BTSRF7JL1W1Y F31 T2，states:286158—286163；生存者后唯一后继突然一拳离手。XTSV1U9JD34T F48 T8，286892—286897：毒胜32→23，无恢复入F49。

既有行为：普通单弃bf423c173d3be348a4ad714e1d26516df619ff41与毒胜保血搜索222445a9bb6bf56cb4f3ceea2cc8b20fba54128f均为实际live祖先；有范围护栏。

待验证行为：宽项仍需核弃牌后实际重规划、接管、复制、目标顺序与SL完整后继，不把两个局部源码等同全项。

反例与边界：少当轮损血不自动证明F49转胜；多选弃牌仍需真实选择后重算，不能擅定必留牌或统一杀序。

本次处置/缺数据：已实现单弃/保血子项，不足以覆盖接管/复制/杀序及SL整战；缺完整可执行候选认证和同条件替代后继。保留waiting而不重复实现或整体duplicate。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-abe9d5d0be109a9f — waiting

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-resources.md；SHA256：21263e5782fa17b030141cf5d79a9968115beeb1a99dc66f6309cbac9b51957b。
账本：silent-0019,silent-0020。来源任务：experience-update；实现任务：strategy-proposal。领域：sl,terminal。仅本角色已观察范围。

证据：BTSRF7JL1W1Y F30，states:286113→286141实70→42；XTSV1U9JD34T F48，286843→286894实97→23，再286897的23入F49。

既有行为：终局/路线已有资源成本模型，但胜战耗血、未来火、SL恢复不可混记为可用收益。

待验证行为：只按实到资源比较，待同条件路线/休息/留药后继再校准权重或安全血线。

反例与边界：赢战本身仍可耗大量HP；计划中未来节点不等于抵达，恢复旧存档药不等新获得。

本次处置/缺数据：无同资源替代路线、休息对锻造、留药的完整实盘对照和独立时间留出；不能据两场净血差拟新资源权重、安全血线或SL/终局阈值。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-f16527e59b5cc1e0 — waiting

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-mechanisms.md；SHA256：a71d6c87441d33115c5a8f4d3e0103673fd07798805978646f3a3961fb749079。
账本：silent-0005,silent-0006,silent-0011,silent-0013,silent-0016,silent-0027,silent-0046,silent-0069,silent-0095,silent-0128,silent-0196,silent-0241。来源任务：experience-update；实现任务：strategy-proposal。领域：combat,potion。仅本角色已观察范围。

证据：BTSRF7JL1W1Y F31 T2，states:286159—286163，牌挡13与覆甲3分列；XTSV1U9JD34T F49 T1新无实体1及留挡10，286897—286899。

既有行为：已有临时降力、敏捷、脆弱及留挡上限入口；组合是否准确须逐项核实。

待验证行为：分开卡牌挡/覆甲/旧挡、临时降力与成长；缺失组合先保未知。

反例与边界：留10是上限而非每轮保底；新增敏捷不能倒补旧挡，整战失败不是局部公式反例。

本次处置/缺数据：这些已观察局部帧未定位当前新增确定模型差；缺未知组合逐项误差、延后用药完整后继与独立持有价，不能拟全组合时机或新权重。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-7a8e9ccb7e646538 — waiting

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-combat.md；SHA256：e365da8858d06c845b8f83b662fad011721eeab59fd4e0dce4c46aa3925b640f。
账本：silent-0005,silent-0006,silent-0011,silent-0021,silent-0024,silent-0027,silent-0034,silent-0077,silent-0079,silent-0123,silent-0129,silent-0180,silent-0221。来源任务：experience-update；实现任务：strategy-proposal。领域：combat,potion,sl,terminal。仅本角色已观察范围。

证据：9Z9H2EXKLF3T F48末试T10/T11，states:287999—288008：首挡18，后续9和10合37；18→3实损15；39毒后敌余32，玩家0血。

既有行为：已有毒、持牌伤、被动反伤及一次倍率消费的模型入口；24/24失败只是有限推演结果。

待验证行为：将毛伤、实际净损、毒与反伤及死亡截断分账；核出模型差再改，SL阈值须独立后继支持。

反例与边界：37挡仍损15表明必须算持牌代价；死后第二击未执行不能预支反伤，三次SL非三局。

本次处置/缺数据：缺逐击毛伤事件、零血截断后未执行击及同条件改药/SL整战；不能用局部净差或有限全败率校准血价和必死阈值。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-cd9f76184de6e29a — waiting

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-resources.md；SHA256：54f562100db0a2dbc72c07a5b1411e42838e3370221a23ea4b769795196c66aa。
账本：silent-0019,silent-0020,silent-0243。来源任务：experience-update；实现任务：strategy-proposal。领域：structure,sl,terminal。仅本角色已观察范围。

证据：15个所引Silent关联局共22对F17→18/F33→34同上限相邻帧；逐对见act-transitions.json，A9三局/A10十二局，全部实回floor(缺血×80%)。

既有行为：当前经验已载跨幕公式，路线资源/SL/终局宽项还含营火、事件、遗物、实际抵达与未来资源。

待验证行为：限定已观察等级/条件，先核消费者具体误算；原公式与资源分源保持，不外推未知交互。

反例与边界：最大HP变化需另计；未来营火未到不算恢复，SL恢复不当新治疗或独立样本。

本次处置/缺数据：22对只复核已观察跨幕回复；缺未知遗物/先古交互、同资源替代路线、具体当前消费者误算及后继资源兑现，不能把公式作为整个资源/SL/终局项已完成。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-292f6731bdb9b669 — waiting

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-044302-postmortem/proposal-poison-potion.md；SHA256：2f943d1aee2e7ed6d1ddfa07b469a4488d27525bad4714cec58f6a94917a8c63。
账本：silent-0087,silent-0020。来源任务：postmortem；实现任务：strategy-proposal。领域：potion,combat。仅本角色已观察范围。

证据：7X0W3U8TVA2A F31 T13，decisions:282021 target_index=2；states:288470→288471后段0→7毒、HP25不变；288472后段18、玩家死。

既有行为：observedPoison仍由知识恶魔严格组合或连王F48/F49提供；该F31头骨组合不在当前入口。未知持有价有no_table/no_value与holdHp=null来源。

待验证行为：7仅作为本次头骨组合后段实测总增量，不反推基础药效、不再叠头骨；可比组合/目标与早用后继够后再接入口。

反例与边界：已喝仍死亡，反驳有7毒即足够救场；不反驳早用可能有益，但也没有其收益证据。

本次处置/缺数据：只有一次后段零毒实饮，缺前/中段、重附目标或其他增益组合及早喝整战和独立持有价；不能把7无条件传给所有目标/时机或据此拟药价。继续保留未模拟边界。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## silent-proposal-0802f69b28d25079 — waiting

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-sl.md；SHA256：79e1696de63d19810eb442ee3afa83dd5795f1693f4c9f4a48433fef014e3596。
账本：silent-0079,silent-0019,silent-0044,silent-0080,silent-0253,silent-0011,silent-0214,silent-0189,silent-0046,silent-0222,silent-0243,silent-0262。来源任务：postmortem；实现任务：strategy-proposal。领域：combat,potion,sl。仅本角色已观察范围。

证据：MTQ0EUBJ3R6T F23 T3，states:288806—288812与288899—288905；原29挡损0/净伤13，SL替19挡损8/净伤19。decisions:282434的plan1/plan4均24/24死亡。

既有行为：SL在全败池仍探索未试线，当前明确写推演未见更常死；不是实盘更安全认证，原必死判官独立。

待验证行为：分别保留即时HP代价、伤害、存活回合和余敌；同条件完整后继/留出足够后再评估排序。

反例与边界：原线更省本轮血却也败；改变出牌后抽序/能力建立同变，末轮敌残不能全归单张攻击或当独立胜率收益。

本次处置/缺数据：四次SL属同局；原线也失败，没有同条件完整胜线与独立时间留出，缺早药/留药和其他路线受控结果。不能据8血换6伤建立8点门槛、改SL血价或药水阈值。

验证方法：冻结所引原帧、药槽、目标、属性、持牌和实际抽弃结果；逐项对照预测/实帧，建立可执行的完整候选与同条件后继；新局按时间留出。出现新源码时必须先撤源码失败/恢复通过，并跑原沙箱入口；本次只做材料断言，未运行生产测试。回退：本次无源码差量可回退；未来实现仅回退独立条件分支，保留现有并行数据、原提案与历史证据。

## 校验、登记与交付限制

material-checks.json共57条固定材料断言通过，覆盖关键敏捷/格挡/弃牌/毒药/复制死亡/SL差额与22对跨幕回复；不是tsc、vitest、撤源码负控、全候选认证或策略收益验收。未改源码，撤源码失败/恢复通过不适用；tests={"tsc":null,"vitest":null,"cases":null}。未提交、未合live、未分配eval版本，fixes=[]，merged=null。不把sandbox或未运行测试写成成功。

只经根ledger.py update给44个原关联账本追加本报告/提案路径和本批处置追溯，by=learner:strategy-proposal；没有新claim/新证据样本，不新增重复id，不降级原shipped，不标shipped。CLI输入、stdout、退出码及保护字段读回保存在ledger-updates.jsonl、ledger-update.stdout、ledger-receipt.json。已有10个code_proposals保持原ID，本批implementation_domains=[]表示无实际实现；原领域保留在dispositions.json。最终队列状态由宿主消费result.json中的proposal_results，未手改learn.json或专用队列。

所有失败材料保留：read-attempts.txt列首次路径/空combat与输出截断；verify_evidence-v1.txt及evidence-verification.stderr保留首次相对父目录算错的失败，v2按实际learner/extract_evidence.py路径重读全部22424行通过。此错误不算生产缺陷。

提案交付：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-201302-s2/learner/runs/20261015-201305-ac34a1d0-2873-4914-a5b4-f6fdae3a8891-strategy-proposal/proposal.md
报告交付：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-201302-s2/learner/runs/20261015-201305-ac34a1d0-2873-4914-a5b4-f6fdae3a8891-strategy-proposal/report.md

运维应保留10项waiting，按每项具体缺数据条件待新局再审；本批没有新增必要反证/异议，不关闭原资源、SL、量化或学习入库父要求。没有源码或规则实际上线，因此无新发布、双通知或shipped登记。

最终读回：44个账本CLI追加全部成功且本报告链接已读回；claim/evidence/first_run/prior/status/asc/version/shipped_at/effect等保护字段与开工快照相同。gitleaks退出0，扫描516540257字节，无泄漏。最终HEAD仍为ff0a2c35f7bf0d92ffca1d048de14fbd5fce3943，git status --porcelain为空，worktree-final.patch为空。无新源码/合入/发布，未运行tsc/vitest。

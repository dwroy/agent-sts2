from pathlib import Path
import json,hashlib,subprocess,tarfile,re,os,importlib.util,collections
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-2026';pub=r/'paper/materials/20261015-2026-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
bid='20261015-201302-s2-strategy-proposal';b=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert report['fixes']==report['implementation_domains']==report['skipped']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
final=load(s/'final-verification.json');assert final['base']==report['base'] and final['git_status_clean'] and final['source_diff_empty'] and final['waiting']==10 and final['ledger_updates']==44 and final['production_tests'] is None
assert (s/'worktree-final.patch').read_bytes()==b''
manifest=load(s/'artifact-manifest.json')
for x in manifest:
 raw=(s/x['path']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],x['path']
markdown=load(s/'proposal-source-manifest.json');assert len(markdown)==10
for x in markdown:assert sha((s/(x['id']+'.md')).read_bytes())==x['sha256']
evidence=load(s/'evidence-verification.json');assert evidence['total']==22424 and evidence['all_verified'] and sum(x['rows'] for x in evidence['checks'])==22424 and all(x['verified'] and sum(x['counts'].values())==x['rows'] for x in evidence['checks'])
identities=load(s/'run-identities.json');assert len(identities)==15 and all(x['character']=='SILENT' for x in identities.values());assert collections.Counter(x['ascension'] for x in identities.values())=={9:3,10:12}
materials=load(s/'material-checks.json');assert materials['count']==57 and materials['passed'] and len(materials['checks'])==57 and all(x['passed'] and x['actual']==x['expected'] for x in materials['checks'])
source=load(s/'source-readback.json');assert source['base']==report['base'] and len(source['files'])==13;equal=0
for x in source['files']:
 a=git('show',report['base']+':'+x['path']);z=git('show',source['live']+':'+x['path']);assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256']
 if a==z:equal+=1
 else:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert equal==10
for x in source['ancestors']:
 assert x['live_ancestor'] and x['base_ancestor']
 for target in [report['base'],source['live']]:git('merge-base','--is-ancestor',x['commit'],target)
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];owned=[];owned_refs=[];offset=0
for number,raw in enumerate((r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True),1):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs):owned.append(raw);owned_refs.append({'id':row['id'],'line':number,'offset':offset,'bytes':len(raw),'sha256':sha(raw)})
 offset+=len(raw)
assert len(inputs)==len(owned)==44 and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
receipt=load(s/'ledger-receipt.json');assert receipt['count']==44 and receipt['exit_code']==0 and receipt['all_protected_unchanged'] and receipt['all_report_links_read_back']
ids=(s/'ledger-update.stdout').read_text().split();assert len(ids)==44 and set(ids)==set(receipt['ids'])=={json.loads(x)['id'] for x in owned} and sha((s/'ledger-update.stdout').read_bytes())==receipt['stdout_sha256']
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 for k in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','evidence','status','version','shipped_at','effect']:assert before[ident].get(k)==after[ident].get(k),(ident,k)
assert load(s/'gitleaks.json')==[] and (s/'gitleaks.exit').read_text().strip()=='0'
write(pub/'batch-readback.json',{'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_final_verification':final,'original_manifest_entries_verified':len(manifest),'ten_original_proposal_sha_verified':True,'source13_base_and_old_live_sha_and_three_narrow_ancestors_verified':True,'source10_equal3_historical_name_comments_preserved':True,'original_evidence_rows':22424,'original_material_assertions':57,'material_probes_reexecuted':False,'original_cohort':{'Silent_A9':3,'Silent_A10':12},'owned_trace_only_ledger_rows':44,'owned_ledger_byte_refs':owned_refs,'protected_fold_preserved':True,'original_preparation_failures':'Missing source path, noncombat null inspection, truncated reads and v1 wrong relative extraction module path retained; v2 read original 22424 rows. No product test claim.','native_gap':'Original learner lacked native session readback; ops verified original Sol6.1/xhigh/input/lease/workspace-write/no-network. Original 570 historical brain rows effort=high remains historical, not relabelled xhigh.','old_notice_boundary':'Original dc64dcaad18a9e041eacd5bd X06 previously-poisoned-target observations and conditional6/7 consumer difference remain separately scoped; this batch7X limited observation does not withdraw them or alter notice/ACK.','limits':['15 original runs and22 observed inter-act pairs are not controlled resource calibration, independent counterfactuals or full candidate certification.','Original invalid JSON, fight-plans0 at frozen cut and dirty execution tree limitations retained.','No new mechanism counterevidence, independent model accuracy, strategy benefit or wide-parent completion claimed.'],'no_source_tests_merge_release_dataset_or_game_actions':True})
files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<350000 and f.suffix in ['.json','.jsonl','.md','.py','.patch','.txt','.stdout','.stderr','.exit']];files+=[s/'evidence/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']];refs=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted(files):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);refs.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',refs)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
line=f'\n- {at} 运维codex：2026原201302-s2策略rc0/done/no-source门禁核，十项waiting；ff0a干净WT无新源码提交、testsnull/mergednull/域空，不重合/发号/补测或重复派单。15Silent关联局22424行原字节/身份与57材料断言为原学习者读回，3A9/12A10分列、22跨幕对不当受控资源校准或完整候选/独立收益；无效JSON/截点fight-plans0与dirty历史树边界保持。13叶旧livefe646265逐SHA与3窄源码main-live祖先核，10同/3历史Roy-Dai注释差不覆盖，不据窄修关闭宽提案。44原CLI仅where/note/逐输入、原字节offset/SHA与保护字段核，旧claim/首证/prior/evidence/status/version等不变、不重复CLI。ops补核实际native Sol6.1/xhigh/input/lease、workspace-write/no-network；原570历史brain effort=high及本学习者原未核native边界分列，不改旧记录或权限。原缺路径/combat空值/输出截断及v1相对抽取模块路径错误保原件，v2字节核验不当生产检查；无源码/测试重跑。当前7X单次窄窗口不撤回原dc64通知的X06既毒目标实证/条件6与7消费差，原通知/父项/owner及未知保持，未新通知或代ACK。无新知识/反证/源码/复盘，不刷新论文、不改当前局/账号home模型预算队列prompt，原宽父继续原链、不等待未来事件。证据paper/materials/20261015-2026-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原201302-s2十项继续waiting，无新源码/合入/版本；44条CLI仅追溯，旧知识/状态保护同验。原22424行/57材料及路径准备失败与修正已归档，旧dc64条件差异通知不因本批窄窗口撤回；未重派或补测。回执paper/materials/20261015-2026-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers);write(pub/'completion.json',{'at':at,'batch':bid,'waiting':10,'own_ledger_rows':44,'new_to_HEAD_rows':len(added.splitlines()),'protected_ledger_fields_preserved':True,'no_source_tests_merge_release_or_dataset':True,'native_model_and_original_sandbox_verified':True,'parallel_records_preserved':True})
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
entries=[];dest=p/'final-files'
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':entries})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
print(json.dumps({'waiting':10,'owned_ledger_rows':44,'native_verified':True,'ledger_check':0,'paths':len(entries)}))

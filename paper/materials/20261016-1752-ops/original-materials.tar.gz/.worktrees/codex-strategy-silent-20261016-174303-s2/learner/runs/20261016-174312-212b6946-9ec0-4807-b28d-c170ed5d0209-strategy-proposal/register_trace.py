import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
updates = [json.loads(s) for s in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
ids = [row['id'] for row in updates]
assert len(ids) == len(set(ids)) == 30
before_bytes = LEDGER.read_bytes()
before = {i: row for i, row in ledger.fold().items() if i in ids}
assert set(before) == set(ids) and all(row['character'] == 'silent' for row in before.values())
protected = ['id', 'character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_runs', 'prior_note',
             'evidence', 'status', 'version', 'shipped_at', 'effect']
snapshot = {i: {**{k: r.get(k) for k in protected},
    'old_notes_count': len(r['notes']), 'old_history_count': len(r['history']),
    'old_notes_sha256': hashlib.sha256(json.dumps(r['notes'], ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
    'old_history_sha256': hashlib.sha256(json.dumps(r['history'], ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
    'where': r['where']} for i, r in before.items()}
(OUT / 'ledger-before-protected.json').write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + '\n')
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
    input=(OUT / 'ledger-updates.jsonl').read_bytes(), capture_output=True, cwd=ROOT)
(OUT / 'ledger-cli.stdout').write_bytes(result.stdout)
(OUT / 'ledger-cli.stderr').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode()
after_bytes = LEDGER.read_bytes()
assert after_bytes.startswith(before_bytes)
suffix = after_bytes[len(before_bytes):]
(OUT / 'ledger-after-suffix.jsonl').write_bytes(suffix)
after = {i: row for i, row in ledger.fold().items() if i in ids}
for ident in ids:
    a, b = before[ident], after[ident]
    assert all(a.get(k) == b.get(k) for k in protected), ident
    assert b['notes'][:len(a['notes'])] == a['notes'], ident
    assert b['history'][:len(a['history'])] == a['history'], ident
    assert all(b['where'][k][:len(v)] == v for k, v in a['where'].items()), ident
    update = next(r for r in updates if r['id'] == ident)
    assert update['note'] in b['notes']
    assert all(v in b['where']['proposal'] for v in update['where']['proposal'])
physical = []
offset = len(before_bytes)
for raw in suffix.splitlines(keepends=True):
    row = json.loads(raw)
    physical.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
own = [r for r in physical if r['row'].get('id') in ids and r['row'].get('note', '').startswith('20261016-174303-s2-strategy-proposal：')]
assert len(own) == 30
for r, update in zip(own, updates):
    assert all(r['row'].get(k) == v for k, v in update.items())
    assert set(r['row']) == set(update) | {'op', 'ts'} and r['row']['op'] == 'update'
(OUT / 'ledger-physical-receipts.json').write_text(json.dumps(own, ensure_ascii=False, indent=2) + '\n')
integrity = {'cli_exit': result.returncode, 'own_updates': len(own), 'prefix_bytes': len(before_bytes),
    'prefix_sha256': hashlib.sha256(before_bytes).hexdigest(), 'prefix_preserved': True,
    'protected_fields_preserved': True, 'old_notes_history_where_prefix_preserved': True,
    'only_metadata_updates': True, 'concurrent_other_rows': len(physical) - len(own)}
(OUT / 'ledger-integrity.json').write_text(json.dumps(integrity, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(integrity, ensure_ascii=False))

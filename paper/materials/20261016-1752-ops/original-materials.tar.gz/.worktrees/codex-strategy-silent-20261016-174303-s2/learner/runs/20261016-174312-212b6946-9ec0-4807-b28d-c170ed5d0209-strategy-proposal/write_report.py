import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'queue-selected.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
audit = json.loads((OUT / 'source-audit.json').read_text())
details = [
    ('感染棱柱：污染与技能收益', 'DUZUBAJ3A8GP F27 T4—T6；states 274830—274839',
     '污染T4为0/3/3/6（能力勒紧没有新增污染）；火花3→6后T5为0/6/12/18、次轮0。两轮玩家实损3/9、敌本体净扣8/13。',
     'turn-solver技能叠污染和rollout火花增长已有接线；1698adc96ba434a46942321e0237b70657e625b2是实际live祖先。',
     '缺原dirty运行知识及实际移动表、火花增长/污染撤除/虚弱/毒/挡的同次冻结生产联合校准；本批未定位新的可归责计算差额。',
     '技能也提供毒或挡，不能从9实损推出少打技能一定更好。',
     '保留所有候选，逐击分列污染血价与毒/挡收益。冻结同一套手牌、移动表和前缀同时核solver/rollout，找到确定差额再修改。'),
    ('失落/遗忘：逐来源抢夺与返还', '5PM6JAQG6FNQ F39 T2/T4—T6；states 274341/274351/274352/274354/274358/274362',
     '玩家力敏−2/−2到−4/−4；两步法使敏捷−4→−2→0；失落退场后力量0，遗忘再抢后敏捷−2。',
     '现场负力量/负敏捷已被当前求解和推演消费；这没有认证逐来源累计、返还或之后重抢的完整模型。',
     '缺稳定实体身份、逐来源累计抢夺与毒杀返还后再抢的完整输入对账；没有另一杀序的受控整战后继。',
     '原提案记录末试只打一张步法仅回到−2敏，毒杀失落仍死亡；不能据返还端点固定杀序。',
     '按来源和实体代际对账抢夺、退场与返还，不按当前index猜身份；用同一冻结生产输入逐步验证，杀序收益另等受控后继。'),
    ('下水道蚌：首样本事实与加压', 'CA5KE8GFJ9X2 F13 T1—T5；states 273238/273247/273252/273254/273258/273263/273268',
     '力量0/4/8，对应无弱意图11/15/19；虚弱后15→11、19→14。覆甲轮初9/9/8/7/6。',
     'monster-db.moveDamageAt/monsterHpAt直接用已有当前进阶事实，不设五样本门槛；roomHpCost仍保留ROOM_COST_MIN_N=5。4ed3c72df30f27b881da637aebf528b97440e0bb是实际live祖先。',
     '首样本接口已有实现；缺旧局实际调用移动表与加压/覆甲/虚弱联合生产校准，完整覆甲减层条件未证。',
     '覆甲层数序列不能独立证明减层条件，死亡时截断血量也不能替完整需损。',
     '维持首样本HP/攻击事实和房间代价五样本边界；先固定原移动表和状态序列校准，不新增减层条件或固定房间成本。'),
    ('电击：高电压与召唤代际', '5PM6JAQG6FNQ F38 T3/T4；states 274308/274312/274313',
     '23上限电击索引4→3，力2→4、攻击17→19；T3仍攻击，不能把计划击杀提前记为退场。',
     'rollout有HIGH_VOLTAGE_POWER增长，spawnedEnemy初始化growth=0；f3dea91880600bc2e7228268a110a644531738f7是实际live祖先。',
     '缺稳定召唤代际身份、原A10移动表与跨代重置的冻结生产校准；未执行先杀爪牙线没有完整后继。',
     '索引重排、同类型和同上限均不足单独证明全局实体身份；35伤/损3候选未实打，不能承诺救后场。',
     '保留现有增长与新实体初始化；有代际证据后固定召唤/退场/再召唤逐步验证，不将旧计数搬到重排索引。'),
    ('沙虫：护栏、SL与能力兑现', '8JRE1C4H4Z2W F33 首/第三试T2、第二试T5及末试T11；decisions 270216/270282/270264',
     'T2两题完整指纹相同；实损3→15、净扣10→17，多12血换7伤。270282预测死亡0/24→5/24，均封顶47后损不代表相同死亡率。',
     '66283dd9982bdd7f480da7a4d9bfefea0572a9ac提供候选/护栏审计；1698adc扩展资源分账；bade647f9fe4c9103b40e2f26b26296692ad24b7及fdaf787a372880b0438e73bcac7e6d2168b038ed提供单动作回执，均是实际live祖先。',
     '缺抽弃/生成/用药/重问后整候选连续归属、逐来源能力兑现及路线/药水/SL恢复的联合消费者；单动作返回不能证明整候选完成。',
     '原提案中更防御的末线延至T11仍败；候选省血不能移用于抽牌后未完成线。',
     '原答、护栏、SL替换、派发与实际结算分列；跨重规划结束旧候选完成认证，补完整归属后验证原请求，不改护栏或探索系数。'),
    ('实验体：全败SL与续步截断', 'YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348/271354；states 277327—277373',
     '两题完整指纹相同，实损0→9、净扣45→38；候选预测损0/10、伤54/36单列。271354选择end_turn。',
     '现有SL资源比较标execution=unverified，单动作回执标whole_plan_executed=null；这些边界是准确的，尚非整轮实际收益。',
     '缺被截断续步的完整候选归属、相同后轮及独立受控获胜后继；全败并列不足拟惩罚系数或禁止探索。',
     '同局F33重打后REWARD且20血，已回原帧277086—277090核实；不能因F48失败否认全部SL。',
     '保留同题预测和实际端点差、覆盖重放原因与未知完成状态；固定续步归属再验证，不由有限样本全败声称安全。'),
    ('实验体：阶段、毒与敏捷时点', 'YF0LXT1QSTGG F48 末试T3—T5；states 277512/277513/277519/277524/277526/277527',
     '4血4毒的111上限阶段转212上限、毒0；触媒2而当前毒0；敏捷5→6时既有挡仍23。末轮本体净扣37，18血对44−23需21、差3。',
     'silent-phase-current提供本帧阶段、已建能力/持有组件和零毒区别；8698c581dac6c7e957f50a381586960a6d0c9b57及aad2700abed6dff1d66e87fb36aaa6fedb39adf3均是实际live祖先。',
     '缺逐候选跨阶段完整执行、逐来源施毒/结算与格挡前后敏捷顺序的联合生产校准；当前快照不能认证后继收益。',
     '原提案前五试曾建立毒雾或余像仍败；已建能力不保证获胜，不用零毒单一归因。',
     '继续按本帧事实读取，不预支零毒触媒收益、不倒补既有挡；固定前缀、建立时点和毒结算后校准，不强制毒能力先手。'),
    ('双蟹：B2零胜并列的实付血价', 'XP2SL33HT0D9 F33 首/末T1、首/第二T3；decisions 271982/272195/271992/272040/272076',
     'T1同指纹实损2→10、净扣25→34；T3同指纹实损9→14、净扣24→27。272076 B2都0而五轮21/24→23/24死亡，仅是候选事实。',
     '既有候选/SL资源/派发审计局部覆盖；66283dd及1698adc的完整40位commit见source-audit.json及上述来源。',
     '缺同抽序、药瓶随机落点后继、成长兑现与受控整战比较；零胜并列及单轮血价不足拟探索门槛。',
     '付血同时有手里剑成长；原提案末试T2/T3也有零损/保挡反例，不能仅据少挡牌数判断错误。',
     '分列HP代价、输出、永久成长和采样未知；不设全局血价常数，未来按独立run/时间验证，SL尝试不拆分母。'),
    ('双蟹：朝向、临减与轮初挡', 'XP2SL33HT0D9 F33 末试T2/T4/T5；states 278236/278237/278240/278242/278249/278252/278253/278255/278260/278261',
     '轮初14挡加斗篷到20；普通镣铐力0→−9→0；激光57→转向38→虚弱28；四敏脆弱下6挡。末轮毒净扣3+7、玩家0血。',
     'passive-pieces有HORN_CLEAT_BLOCK=14/T2，card-model消费StrengthLoss，solver/rollout有临减恢复和朝向/弱路径；相关源码祖先已核。',
     '缺全部修饰组合的同次冻结生产回放、抽弃后整候选执行及未选后继；窄覆盖不等同全部组合校准。',
     '减力下一轮恢复；成长已建立仍无减员。后得敏捷不倒补现有格挡，不把现场观察套全部未见组合。',
     '按朝向/虚弱/临减/轮初挡分别对账，固定同一输入验证组合和结算先后；保持现有排名、护栏和能力权重。'),
    ('综合机制与联合资源消费者', 'YF0LXT1QSTGG F48、XP2SL33HT0D9 F33，及本批其他四局上述锚点',
     '本批确认六局A10和四组同指纹当轮对照；原综合提案的101局/1499房是历史范围，本批不将六锚点当全历史重建。',
     '候选、护栏、阶段事实与单动作派发模块均有局部实现；源码存在不证明联合资源消费者交付。',
     '本批六局不能替代原101局联合资源重建；完整候选、路线、休息、实际用药、SL恢复的逐来源联合消费未闭合。',
     '同存档尝试相关；SL恢复不是回血，候选损血差不是实际保血，持有组件也不等于已施放。',
     '按原范围逐run重建资源和候选归属，已观察事实与受控后继分层验收；本批不关闭学习入库或量化父要求。'),
]
assert len(proposals) == len(details) == 10
dispositions = []
sections = []
for p, detail in zip(proposals, details):
    title, evidence, facts, current, reason, counter, validation = detail
    saved = OUT / (p['id'] + '.original.md')
    assert hashlib.sha256(saved.read_bytes()).hexdigest() == p['proposal_sha256']
    dispositions.append({'id': p['id'], 'state': 'waiting', 'reason': reason, 'ledger': p['ledger'],
        'evidence': evidence, 'facts': facts, 'current_partial': current, 'counterexamples': counter,
        'validation': validation, 'original_proposal': p['proposal'], 'proposal_sha256': p['proposal_sha256']})
    sections.append(f"## {p['id']}：{title}\n\n账本：{', '.join(p['ledger'])}。\n\n证据局号/层/回合：{evidence}。\n\n已核事实：{facts}\n\n旧规则与实际覆盖：{current}\n\n处置：waiting。{reason}\n\n反例/限制：{counter}\n\n预期行为及验证：{validation}\n")

header = f'''# 本批十项静默策略提案处置

批次：20261016-174303-s2-strategy-proposal；角色silent；完整base：{base}。

工作树开工干净，已执行git merge --no-edit main，结果Already up to date；HEAD保持该base。根learn.json仅本批对应行已核task/character/worktree/runs和十个proposal_ids，没有research_request、implementation_request或proposal_repair；普通专题请求属于另一旧批，不作为本批身份。本批只处理十个已领取id，无新提案/领取/源码/知识改动或合入。

结论：十项均waiting，已实现部分保留，各原提案未满足的联合校准或消费者范围不冒标duplicate/implemented。本批没有新的可复现计算差额，也没有支持新策略参数的受控完整后继；原行为保持。没有代码提交、发布版本或shipped。

只核派发六局：{', '.join(dispatch['runs'])}，runs.jsonl六行均为SILENT/A10。复用原共用extract_evidence.py产物，逐条回只读logs核offset/bytes/SHA/JSON和显式身份：8,274条（states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0）。原manifest路径与SHA保留evidence-source.json，逐流source_size/count/outputSHA和本批字节核验见evidence-verification.json，逐行索引见verified-evidence-index.jsonl；没有新建或覆盖旧提取报告。零条fight-plans仅是该截点未选到，不断言日志缺失。各流截点独立，未声称同一时刻冻结。

由已核原行构造1,014个限定房间快照、13个关键决策；27项材料断言通过，含四组完整fingerprint相同及实际当轮端点。它们只验证原帧，不是生产测试或受控整战模拟。YF F33成功SL反例另保存success-sl-counterexample.json。十份原Markdown均与登记SHA相同，以*.original.md逐字保留。

14个相关源码叶与上一批逐字相同；与实际live（{audit['live_head']}）11叶相同、3叶仅历史Roy/Dai署名注释差，完整diff见source-live.diff.txt。source-audit.json保存SHA、真实源码commit及实际live祖先核验，关联commit均为祖先。另核sl/explore.ts、hand/loop.ts与上一基线零差并读取当前接线。没有将旧dirty运行树、刷新知识或实际移动表冒称完整复原。

原提案的更早进阶/历史支持数只保留原文，不充本批验证。本次结论只来自这六个silent A10局与原提案，未读取其他角色知识、不用预训练事实填缺口。

'''
tail = '''
## 验证边界、后续与回退

确定性事实修正不要求先赢一局；它要求从冻结生产输入定位实际差额。本批尚未定位新差额，不能以证据缺口自行造规则。拟修改长期排名、药水价值、探索门槛时，需对应受控后继及按独立run/时间后移验证；本批SL尝试不能拆成独立局。

现有单动作回执明示state_effect_verified=false、whole_plan_executed=null；资源比较为current_turn_prediction且execution=unverified；阶段事实为observed_current_snapshot。以上模块只完成相应局部功能，不能认证跨抽弃、用药、重问与SL的整候选或资源消费者。未来先固定同次生产源码/知识/移动表、动作身份和状态前后，再按来源验证能力、毒、格挡、力敏、退场、回复及SL恢复。

本批无源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产套件、未借旧绿色测试。fixes=[]、merged=null，无提交、eval版本、上线或规则双通知；没有进入live合入/知识刷新流程。其他角色行为保持等价。后续若实现，依原流程做固定数据红绿、自测、gitleaks、实际live合入及规则双通知；本批无生产变更可回退。

账本仅经根ledger.py update追加本批proposal/report追溯where/note，by=learner:strategy-proposal；无新增学习结论、不重复support/repeat、不改原claim/first_run/prior/evidence/status/version/shipped，不将旧shipped条目倒退proposed。队列处置由最终proposal_results交调度器，不自行改根learn.json或队列，不新建重复提案id。账本CLI输入/输出和前缀/字段完整性另存本目录。

交运维：本目录proposal.md、report.md、result.json、dispositions.json及原十个CLI id。报告不代表经验入库或大脑采用，不关闭原量化、联合消费者或学习入库父要求。过程材料全部位于本批忽略目录；工作树与HEAD最终完整性另存final-integrity.json。原报告及历史失败保留。
'''
body = header + '\n'.join(sections) + tail
(OUT / 'proposal.md').write_text(body)
(OUT / 'report.md').write_text(body.replace('# 本批十项静默策略提案处置', '# 本批策略核验报告', 1))
(OUT / 'dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-174303-s2-strategy-proposal',
    'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'],
    'implementation_domains': [], 'proposal_results': [{k: d[k] for k in ['id', 'state', 'reason']} for d in dispositions],
    'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in sorted({i for p in proposals for i in p['ledger']}):
    relevant = [d for d in dispositions if ident in d['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md') + '#' + d['id'] for d in relevant] + [str(OUT / 'report.md')]},
        'note': '20261016-174303-s2-strategy-proposal：8274原记录逐offset/bytes/SHA/JSON/身份复核，27项材料检查及14源码叶/实际live祖先核；' +
            '；'.join(d['id'] + ' waiting：' + d['reason'] for d in relevant) +
            ' 本批仅追加追溯，无新源码/知识/合入/版本；不重复support/repeat、不改原claim/首证/prior/evidence/status/version/shipped。'})
with (OUT / 'ledger-updates.jsonl').open('w') as f:
    for row in updates:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
print(json.dumps({'proposal_count': len(dispositions), 'ledger_metadata_updates': len(updates),
                  'base': base, 'report': str(OUT / 'report.md')}, ensure_ascii=False))

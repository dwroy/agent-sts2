import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
ROOT = Path('/home/dw/Projects/agent-sts2')
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
ANCHORS = DISPATCH['runs']
PRIMARY = ['ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1']


def read(stream):
    for raw in (OUT / 'evidence' / (stream + '.evidence.jsonl')).open():
        yield json.loads(raw)


def compact(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
            'sha256': item['sha256'], 'run': item['run_id'], 'floor': run.get('floor'),
            'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
            'block': player.get('block'), 'energy': player.get('energy'),
            'powers': player.get('powers'), 'potions': run.get('potions'),
            'relics': run.get('relics'),
            'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost', 'rules_text',
                      'resolved_rules_text', 'dynamic_values')} for c in combat.get('hand', [])],
            'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp',
                         'is_alive', 'is_hittable', 'powers', 'intents')} for e in combat.get('enemies', [])]}


manifest = json.loads((OUT / 'evidence' / 'evidence-manifest.json').read_text())
verified = []
for stream in manifest:
    name = stream['stream']
    counts = collections.Counter()
    digest = hashlib.sha256()
    source = ROOT / 'logs' / (name + '.jsonl')
    with source.open('rb') as handle:
        for raw in (OUT / 'evidence' / (name + '.evidence.jsonl')).open('rb'):
            digest.update(raw)
            item = json.loads(raw)
            handle.seek(item['offset'])
            original = handle.read(item['bytes'])
            assert hashlib.sha256(original).hexdigest() == item['sha256']
            assert json.loads(original) == item['row']
            row = item['row']
            state = row.get('state') or {}
            fp = row.get('fingerprint')
            if isinstance(fp, str):
                fp = json.loads(fp)
            identities = {x for x in (row.get('run_id'), row.get('run'), state.get('run_id'),
                                     (fp or {}).get('run')) if x and x != 'run_unknown'}
            assert identities == {item['run_id']}
            assert item['run_id'] in ANCHORS
            assert item['offset'] + item['bytes'] <= stream['source_size']
            if name == 'states':
                assert str((state.get('run') or {}).get('character_id')).lower() == 'silent'
            if name == 'runs':
                assert str(row['character']).lower() == 'silent'
            counts[item['run_id']] += 1
    assert digest.hexdigest() == stream['output_sha256']
    assert all(counts[k] == n for k, n in stream['counts'].items())
    verified.append({'stream': name, 'source_size': stream['source_size'],
                     'accepted_rows': sum(counts.values()), 'counts': stream['counts'],
                     'invalid_lines': stream['invalid_lines'], 'incomplete_lines': stream['incomplete_lines'],
                     'offset_bytes_sha_json_identity_verified': True})
(OUT / 'evidence-verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')

runs = {x['run_id']: x['row'] for x in read('runs')}
assert set(runs) == set(ANCHORS)
summaries = []
primary_states = {r: [] for r in PRIMARY}
primary_decisions = {r: [] for r in PRIMARY}
for run_id in ANCHORS:
    info = runs[run_id]
    summaries.append({'run': run_id, 'character': info['character'], 'ascension': info['ascension'],
                      'victory': info['victory'], 'floor': info['floor'], 'code': info['code']})

by_key = {}
state_by_line = {}
all_compact = {}
for item in read('states'):
    row = item['row']
    key = (item['run_id'], row.get('observed_ts'), row.get('fingerprint'))
    by_key.setdefault(key, []).append(item['line'])
    state_by_line[item['line']] = item
    all_compact[item['line']] = compact(item)
    if item['run_id'] in PRIMARY:
        primary_states[item['run_id']].append({**row, '_line': item['line']})

actions = []
guard = []
for item in read('decisions'):
    row = item['row']
    if item['run_id'] in PRIMARY:
        primary_decisions[item['run_id']].append({**row, '_line': item['line']})
    chosen = row.get('chosen') or {}
    expected = row.get('expect') or {}
    card = expected.get('card') or {}
    if chosen.get('action') in ('use_potion', 'discard_potion') or card.get('id') in (
            'MIRAGE', 'PIERCING_WAIL', 'BURST', 'SHADOWMELD', 'FAN_OF_KNIVES'):
        key = (item['run_id'], row.get('observed_ts'), row.get('fingerprint'))
        matches = by_key.get(key, [])
        before = matches[0] if len(matches) == 1 else None
        after = before + 1 if before is not None and before + 1 in state_by_line else None
        if after is not None and state_by_line[after]['run_id'] != item['run_id']:
            after = None
        actions.append({'run': item['run_id'], 'decision_line': item['line'], 'floor': row.get('floor'),
                        'turn': row.get('turn'), 'chosen': chosen, 'expect': expected, 'result': row.get('result'),
                        'before': all_compact.get(before), 'next_observation': all_compact.get(after),
                        'limitation': '仅相邻原始状态观测；不认证整条候选、完整后继或整战因果。'})
    if row.get('hp_guard') or ('hp' in str(row.get('rationale', '')).lower() and 'guard' in str(row.get('rationale', '')).lower()):
        guard.append({'line': item['line'], 'row': row})

selected_lines = [292332, 292343, 292402, 292788, 292789, 292940, 292941, 292942,
                  293158, 293159, 293195, 293196, 293197, 293198,
                  293431, 293437, 293440, 293443, 293460, 293461, 293463, 293464, 293465]
(OUT / 'selected-frames.json').write_text(json.dumps([all_compact[k] for k in selected_lines], ensure_ascii=False, indent=2) + '\n')
(OUT / 'observed-actions.json').write_text(json.dumps(actions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'guard-decisions.json').write_text(json.dumps(guard, ensure_ascii=False, indent=2) + '\n')
(OUT / 'run-summary.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('resource_chain', Path.cwd() / 'learner/resource_chain.py')
resource = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resource)
resource_summaries = []
for run_id in PRIMARY:
    inputs = {'run': runs[run_id], 'states': primary_states[run_id], 'decisions': primary_decisions[run_id]}
    (OUT / (run_id + '.selection-input.json')).write_text(json.dumps(inputs, ensure_ascii=False) + '\n')
    starts = {}
    events = [x['row'] for x in read('sl-attempts') if x['run_id'] == run_id]
    for event in events:
        if event.get('attempt', 1) > 1 and event.get('started_at'):
            starts.setdefault(event.get('floor'), []).append(event['started_at'])
    report = resource.resource_chain(primary_states[run_id], run_id, 'silent', starts)
    report['sl_events'] = events
    (OUT / (run_id + '.resources.json')).write_text(json.dumps(report, ensure_ascii=False) + '\n')
    resource_summaries.append({'run': run_id, 'combats': len(report['combats']),
                               'end_kinds': dict(collections.Counter(c['end'] for c in report['combats']))})
(OUT / 'resource-summary.json').write_text(json.dumps(resource_summaries, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['accepted_rows'] for x in verified), 'streams': verified,
                  'resource_summaries': resource_summaries, 'actions': len(actions), 'guard_decisions': len(guard)}, ensure_ascii=False))

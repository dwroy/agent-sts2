# 静默猎手策略提案逐项处置

时间：2026-10-15T13:21:21+08:00。本批：20261015-131302-s2-strategy-proposal。基线：`a936191941240393bf578b8824141c5b4c01f52e`。

本批是reason=proposal的普通队列，精确领取10个原id，无research_request/implementation_request。根deck-size研究绑定其他批次，本批不承接专题；开工git status干净，按普通任务merge main得到Already up to date。未领取其他id、未新建重复提案、未派下级agent。

结论：十项均waiting，无新增源码/知识/提交/合入/发布。已有局部实现不能关闭整条宽提案。只经原ledger CLI补充原条目的本批报告/提案追溯，不改变claim、first_run、prior、证据前缀、状态或版本。

## silent-proposal-43fe170707574455：同族群伤与构筑兑现

账本：silent-0021, silent-0012, silent-0046。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-combat-progress.md；SHA256：6998cd559e0899056005231af7bbadd3d271513733f6ca28a5f65638e9a9f122。

证据：ZTRGYYMLR8SC A10 F17 末试T1/T14；s292332三敌62/63/199合324，s292402余神官58。F7/F16计划仍将群伤描述为可处理群体。

已有实现与验证：learner/resource_chain.py 保留同型敌身份歧义、缺死亡帧及净血差限制；3f69541b5d3259dac94d3395bfe3da47936b4de9 为实际live祖先窄实现。

反例、缺数据与处置：waiting。已有逐敌观测和同族快照；两个KIN_FOLLOWER同型，索引/类型不构成跨帧稳定实例身份；缺组件取得→支付→建立→后继的联合归属，不能标整项已实现。

预期行为：继续分列当前存活敌血、已建立能力和计划want，不新增固定击杀序或安全输出阈值。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-3f5a665dca133a8c：护栏、SL与完整候选执行

账本：silent-0125。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-guard-sl-trace.md；SHA256：223f0fdd623ff185e4b476a528e5a70a3ce5e99d5733ae5354139ffcd9ac5523。

证据：ZTRGYYMLR8SC F11T3 d285301、F17首试T10 d285405、末试T13 d285745；原/替预测损25/20、15/12、2/0，局部伤害26/18、12/3、7/0。

已有实现与验证：silent-hp-guard-audit.ts 与 silent-selection-audit.ts 的 actual_outcome/actual_turn 为空；66283dd9982bdd7f480da7a4d9bfefea0572a9ac、9d8278702dbc581b5015ba7ec9a70dc0fb94cccb 均为实际live祖先，非整项闭合。

反例、缺数据与处置：waiting。护栏与选择阶段已有审计，但实际整条候选结果为空；本批ZTRG消费者虽有69个整轮端点，完整候选归属仍0。缺原线完整执行与整战受控后继，不拟合8/24/0阈值。

预期行为：保留原护栏、SL条件及参考排名；候选省血10/少伤24只作预测差，不累计成已获血量或胜因。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-0b8ef30de463f317：铁心药水与资源来源

账本：silent-0013, silent-0277。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-potion-plating.md；SHA256：ac20c158f9134f0c139a7a3886d3c26fbb542517b3ebf2e1c2c8078e228cbeb8。

证据：ZTRGYYMLR8SC F6T3 d285252，F11T1 d285282/285285，F17末试T2 d285694/s292342→292343；旧牌挡7不变、覆甲建7。全局实饮动作17。

已有实现与验证：potion-cost.ts 明列 no_table/no_value/holdHp=null；资源工具保留重开边界，但未自动完成取得/消耗/恢复来源及终局归属。

反例、缺数据与处置：waiting。已有药水未加载/无换算值标记及覆甲分源；SL五次恢复原两瓶，不能将17次动作视为17新瓶。缺晚喝、留药及跨战持有价值的完整可比结果。

预期行为：继续按现场牌挡和覆甲剩层分账，不改持有价回退或饮用时点阈值。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-5367449b857450a7：机制组合与伤挡分源

账本：silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-mechanisms.md；SHA256：2bbe2e854ce6bdb95609f800eb8434cdb05b6be963cfc8ec1870d81d65aee062。

证据：ZTRGYYMLR8SC F17末试T5 d285707/s292355→292356，力量6/3/3→0/-3/-3；末T14铜钹额外扣3及脆弱牌挡分列。原提案另关联本批A3/A4/A7/A10七局。

已有实现与验证：原提案SHA匹配；八流原行全部复核。动作观测保留在 observed-actions.json；本批未对原提案的全历史汇总重做全量统计。

反例、缺数据与处置：waiting。现有代码已有临时减力、脆弱与覆甲局部覆盖。刀扇本批关键窗为单敌，铜钹多弃与随机多目标、混合修饰后继仍缺可隔离校准；单张已知事实不能推整组通用公式。

预期行为：保留已有机制覆盖；未知组合维持未知，不将单敌/单弃外推多目标或多弃。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-9b8890c2649a2734：路线、护栏与重打资源链

账本：silent-0012, silent-0019, silent-0020, silent-0021, silent-0125。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-trace.md；SHA256：ddafc2fed623f77ca9c28eff1309aedb8f1f746e3714756f5b71ee5eb1d97f57。

证据：ZTRGYYMLR8SC 六个胜房净损51，三休原实回63，56-51+63=68入F17；六试均68进场、前五重开、末T14真实死亡。

已有实现与验证：本批资源消费者重放为12个战斗尝试窗口（7 observed_exit、5 restart_observed），其中终局死亡出口不当胜房。

反例、缺数据与处置：waiting。已能记录资源窗口和端点，但未获候选、完整执行及资源来源的联合归属；原线、未走路线、晚喝铁心的整战反事实未执行。六次SL共享同局初始资源，不能视为六个独立样本。

预期行为：保持现有路线/休息/药水/SL规则，赢战血价继续记录；不从六次全败推断所有策略必死。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-645ff7b72e0b9991：零毒升级蜃景与尾端估计

账本：silent-0010, silent-0106, silent-0021, silent-0286。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-combat-observed-payoff.md；SHA256：55cd7445ba3ac32ef6bff153a908a5b729ea6dc7939b84be7ba6712080cd5ace。

证据：K2JAGKVJAWZJ F46T1 d286431/s293158→293159：全敌零毒、能1→0、挡16→16；F46T6普通版8毒+2敏，挡10→20，随后实损26。79UCJ0K6R9C1 F14T3 d286684短推演实赢0/8，尾端约76%。

已有实现与验证：5dbb47bfb48d652adfcda2e62c166a804098b6c3 为实际live祖先源码，card-model/turn-solver 在出牌时重核零毒/敏捷/修饰边界；该提交未关闭本提案尾端校准部分。

反例、缺数据与处置：waiting。零毒升级蜃景已有窄实现；当前任务无可校准尾端胜率或替代整战胜负的独立证据。0/8实赢不能写成8死，普通版实际加10挡反对整类蜃景归零。

预期行为：保留零毒窄模型、普通版已知正毒模型及感染先结算；不重设lasting权重或禁止空过。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-68ef2857229d1287：毒药水条件范围

账本：silent-0278, silent-0286。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-potion-observed-scope.md；SHA256：f30a8d0b9964ccf0009478cb80065bb5fafc8d6cce81b760bafc7aace1848d6f。

证据：K2JAGKVJAWZJ F33首试T10 d286255/s292940→292941毒42→48、敌HP54不变；s292942 SL恢复62血及原瓶。79UCJ0K6R9C1 F14T11 d286715/s293463→293464毒4→10、敌HP8不变，s293465玩家先死。

已有实现与验证：154c9542711a4daf17bfa0b97eaa1ca81dc3d385 为实际live祖先，只发布限定组合的当步事实，明确whole_turn_simulated=false；不是本宽项duplicate。

反例、缺数据与处置：waiting。只核实两次当步加6且非即时伤害；当前crabPoisonFacts的完整遗物/能力条件来自另一已观察局，不匹配K2组合，也不覆盖79多只同型虫。缺这些联合修饰与完整后继校准，不把当步事实扩成所有非双boss整轮施毒模型。

预期行为：保留饮用后重读及未核组合未知标记；不强制早喝、不把毒层预支成先于感染的击杀。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-9edfef7a6b2873c2：路线HP投影来源

账本：silent-0020, silent-0019, silent-0021。原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-resource-projection-provenance.md；SHA256：d920109bd6d754df32fa941dc4404e979dbcfaaf48db906b85cbc9d77a45cc96。

证据：K2JAGKVJAWZJ F34后原投影以75上限表示末战75，F46实际86/91；79UCJ0K6R9C1 F14原投影70、实入51。K2 F33首试10→62为SL恢复。

已有实现与验证：route-plan.ts与实际live同叶；makeRoutePlan使用projection.maxArrival归一化。resource_chain已有资源窗，不等于原投影全来源已恢复。

反例、缺数据与处置：waiting。RoutePlan仍保存归一化hpOnArrival及计划时hpPct，旧记录未保存逐节点绝对HP/maxHP、房间成本与休息假设。现有资料不能唯一还原两个旧投影的来源，K2完整消费者还因两条无decision_id路线变更拒收。

预期行为：保留原路线消费，不按当前上限重解释旧比例、不拟统一加11/减19；未来来源记录与旧数据补齐分别验收。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-ff1d168227e369e0：蜃景、重放与逐击减损

账本：silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-mechanisms.md；SHA256：b69ab5987f7e058572c2e42190046ab1f4806712d9939f55db969342df3a34e1。

证据：K2JAGKVJAWZJ F46T1零毒升级蜃景挡16不增，T6普通蜃景加10；T9爆发、生存者、钨合金棍及末击死亡截断为原提案证据。10GPK5XGHCK3为本批A3历史机制背景。

已有实现与验证：5dbb47bfb48d652adfcda2e62c166a804098b6c3仅零毒子项。未由窄实现标记整个机制组合implemented/duplicate。

反例、缺数据与处置：waiting。零毒升级子项已覆盖；本批未有升级正毒、暗影/爆发联合模型的独立控制样本，三骑士T7额外2损伤源仍不完整。原提案UJ0K3G10609Y不是本批锚点，其旧汇总未冒充本批重新核实。

预期行为：保留普通正毒/零毒窄模型，不预支未建暗影或重放收益；死亡截断不补完整入伤。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

## silent-proposal-c64bdd50a949d16f：实际能力与药水终局来源

账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-resources.md；SHA256：979e5eb65499c91eed763906c40aa0b50a42b598925021c83c220bef3e7bc658。

证据：K2JAGKVJAWZJ F27T2 d286123/s292788→292789：HP57→57、挡0→0、覆甲0→7；F33毒药+6后SL恢复原瓶；F45 d286424真实弃毒瓶，末战仍败。

已有实现与验证：既有通知d486caef57aeb0c096a29a75的ops_forwarded、watcher_received、roy_notified三份原角色回执SHA均核实。本批不重复发送、不代ACK。

反例、缺数据与处置：waiting。原文“已有16挡”与实帧冲突，明确保持勘误；缺持续能力/取得/实饮/SL恢复到终局消费者的联合归属，也无早喝/换瓶完整反事实。

预期行为：保留原文及失败现场，追加勘误引用；不改药水时点、跨幕回血、终局权重，不将前战能力带入末战。

验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。

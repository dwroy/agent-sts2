import datetime
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
ASSIGNED = json.loads((OUT / 'assigned-proposals.json').read_text())
SOURCE = json.loads((OUT / 'source-audit.json').read_text())
NOW = datetime.datetime.now().astimezone().isoformat(timespec='seconds')

DETAILS = [
    ('43fe170707574455', '同族群伤与构筑兑现',
     'ZTRGYYMLR8SC A10 F17 末试T1/T14；s292332三敌62/63/199合324，s292402余神官58。F7/F16计划仍将群伤描述为可处理群体。',
     '已有逐敌观测和同族快照；两个KIN_FOLLOWER同型，索引/类型不构成跨帧稳定实例身份；缺组件取得→支付→建立→后继的联合归属，不能标整项已实现。',
     '继续分列当前存活敌血、已建立能力和计划want，不新增固定击杀序或安全输出阈值。',
     'learner/resource_chain.py 保留同型敌身份歧义、缺死亡帧及净血差限制；3f69541b5d3259dac94d3395bfe3da47936b4de9 为实际live祖先窄实现。'),
    ('3f5a665dca133a8c', '护栏、SL与完整候选执行',
     'ZTRGYYMLR8SC F11T3 d285301、F17首试T10 d285405、末试T13 d285745；原/替预测损25/20、15/12、2/0，局部伤害26/18、12/3、7/0。',
     '护栏与选择阶段已有审计，但实际整条候选结果为空；本批ZTRG消费者虽有69个整轮端点，完整候选归属仍0。缺原线完整执行与整战受控后继，不拟合8/24/0阈值。',
     '保留原护栏、SL条件及参考排名；候选省血10/少伤24只作预测差，不累计成已获血量或胜因。',
     'silent-hp-guard-audit.ts 与 silent-selection-audit.ts 的 actual_outcome/actual_turn 为空；66283dd9982bdd7f480da7a4d9bfefea0572a9ac、9d8278702dbc581b5015ba7ec9a70dc0fb94cccb 均为实际live祖先，非整项闭合。'),
    ('0b8ef30de463f317', '铁心药水与资源来源',
     'ZTRGYYMLR8SC F6T3 d285252，F11T1 d285282/285285，F17末试T2 d285694/s292342→292343；旧牌挡7不变、覆甲建7。全局实饮动作17。',
     '已有药水未加载/无换算值标记及覆甲分源；SL五次恢复原两瓶，不能将17次动作视为17新瓶。缺晚喝、留药及跨战持有价值的完整可比结果。',
     '继续按现场牌挡和覆甲剩层分账，不改持有价回退或饮用时点阈值。',
     'potion-cost.ts 明列 no_table/no_value/holdHp=null；资源工具保留重开边界，但未自动完成取得/消耗/恢复来源及终局归属。'),
    ('5367449b857450a7', '机制组合与伤挡分源',
     'ZTRGYYMLR8SC F17末试T5 d285707/s292355→292356，力量6/3/3→0/-3/-3；末T14铜钹额外扣3及脆弱牌挡分列。原提案另关联本批A3/A4/A7/A10七局。',
     '现有代码已有临时减力、脆弱与覆甲局部覆盖。刀扇本批关键窗为单敌，铜钹多弃与随机多目标、混合修饰后继仍缺可隔离校准；单张已知事实不能推整组通用公式。',
     '保留已有机制覆盖；未知组合维持未知，不将单敌/单弃外推多目标或多弃。',
     '原提案SHA匹配；八流原行全部复核。动作观测保留在 observed-actions.json；本批未对原提案的全历史汇总重做全量统计。'),
    ('9b8890c2649a2734', '路线、护栏与重打资源链',
     'ZTRGYYMLR8SC 六个胜房净损51，三休原实回63，56-51+63=68入F17；六试均68进场、前五重开、末T14真实死亡。',
     '已能记录资源窗口和端点，但未获候选、完整执行及资源来源的联合归属；原线、未走路线、晚喝铁心的整战反事实未执行。六次SL共享同局初始资源，不能视为六个独立样本。',
     '保持现有路线/休息/药水/SL规则，赢战血价继续记录；不从六次全败推断所有策略必死。',
     '本批资源消费者重放为12个战斗尝试窗口（7 observed_exit、5 restart_observed），其中终局死亡出口不当胜房。'),
    ('645ff7b72e0b9991', '零毒升级蜃景与尾端估计',
     'K2JAGKVJAWZJ F46T1 d286431/s293158→293159：全敌零毒、能1→0、挡16→16；F46T6普通版8毒+2敏，挡10→20，随后实损26。79UCJ0K6R9C1 F14T3 d286684短推演实赢0/8，尾端约76%。',
     '零毒升级蜃景已有窄实现；当前任务无可校准尾端胜率或替代整战胜负的独立证据。0/8实赢不能写成8死，普通版实际加10挡反对整类蜃景归零。',
     '保留零毒窄模型、普通版已知正毒模型及感染先结算；不重设lasting权重或禁止空过。',
     '5dbb47bfb48d652adfcda2e62c166a804098b6c3 为实际live祖先源码，card-model/turn-solver 在出牌时重核零毒/敏捷/修饰边界；该提交未关闭本提案尾端校准部分。'),
    ('68ef2857229d1287', '毒药水条件范围',
     'K2JAGKVJAWZJ F33首试T10 d286255/s292940→292941毒42→48、敌HP54不变；s292942 SL恢复62血及原瓶。79UCJ0K6R9C1 F14T11 d286715/s293463→293464毒4→10、敌HP8不变，s293465玩家先死。',
     '只核实两次当步加6且非即时伤害；当前crabPoisonFacts的完整遗物/能力条件来自另一已观察局，不匹配K2组合，也不覆盖79多只同型虫。缺这些联合修饰与完整后继校准，不把当步事实扩成所有非双boss整轮施毒模型。',
     '保留饮用后重读及未核组合未知标记；不强制早喝、不把毒层预支成先于感染的击杀。',
     '154c9542711a4daf17bfa0b97eaa1ca81dc3d385 为实际live祖先，只发布限定组合的当步事实，明确whole_turn_simulated=false；不是本宽项duplicate。'),
    ('9edfef7a6b2873c2', '路线HP投影来源',
     'K2JAGKVJAWZJ F34后原投影以75上限表示末战75，F46实际86/91；79UCJ0K6R9C1 F14原投影70、实入51。K2 F33首试10→62为SL恢复。',
     'RoutePlan仍保存归一化hpOnArrival及计划时hpPct，旧记录未保存逐节点绝对HP/maxHP、房间成本与休息假设。现有资料不能唯一还原两个旧投影的来源，K2完整消费者还因两条无decision_id路线变更拒收。',
     '保留原路线消费，不按当前上限重解释旧比例、不拟统一加11/减19；未来来源记录与旧数据补齐分别验收。',
     'route-plan.ts与实际live同叶；makeRoutePlan使用projection.maxArrival归一化。resource_chain已有资源窗，不等于原投影全来源已恢复。'),
    ('ff1d168227e369e0', '蜃景、重放与逐击减损',
     'K2JAGKVJAWZJ F46T1零毒升级蜃景挡16不增，T6普通蜃景加10；T9爆发、生存者、钨合金棍及末击死亡截断为原提案证据。10GPK5XGHCK3为本批A3历史机制背景。',
     '零毒升级子项已覆盖；本批未有升级正毒、暗影/爆发联合模型的独立控制样本，三骑士T7额外2损伤源仍不完整。原提案UJ0K3G10609Y不是本批锚点，其旧汇总未冒充本批重新核实。',
     '保留普通正毒/零毒窄模型，不预支未建暗影或重放收益；死亡截断不补完整入伤。',
     '5dbb47bfb48d652adfcda2e62c166a804098b6c3仅零毒子项。未由窄实现标记整个机制组合implemented/duplicate。'),
    ('c64bdd50a949d16f', '实际能力与药水终局来源',
     'K2JAGKVJAWZJ F27T2 d286123/s292788→292789：HP57→57、挡0→0、覆甲0→7；F33毒药+6后SL恢复原瓶；F45 d286424真实弃毒瓶，末战仍败。',
     '原文“已有16挡”与实帧冲突，明确保持勘误；缺持续能力/取得/实饮/SL恢复到终局消费者的联合归属，也无早喝/换瓶完整反事实。',
     '保留原文及失败现场，追加勘误引用；不改药水时点、跨幕回血、终局权重，不将前战能力带入末战。',
     '既有通知d486caef57aeb0c096a29a75的ops_forwarded、watcher_received、roy_notified三份原角色回执SHA均核实。本批不重复发送、不代ACK。'),
]

by_id = {x['id']: x['original'] for x in ASSIGNED}
results = []
sections = []
for suffix, title, evidence, reason, expected, existing in DETAILS:
    proposal_id = 'silent-proposal-' + suffix
    original = by_id[proposal_id]
    results.append({'id': proposal_id, 'state': 'waiting', 'reason': reason})
    sections.append(f'## {proposal_id}：{title}\n\n'
                    f'账本：{", ".join(original["ledger"])}。原提案：{original["proposal"]}；SHA256：{original["proposal_sha256"]}。\n\n'
                    f'证据：{evidence}\n\n已有实现与验证：{existing}\n\n'
                    f'反例、缺数据与处置：waiting。{reason}\n\n预期行为：{expected}\n\n'
                    '验证边界：本批原始字节、动作前后帧及端点只验证已观察事实；缺失后继不补零，不以固定回放推实胜率。'
                    '后续须按同局SL整体分组，用新完结同角色局作时间留出；完整比较前保留现有参数。\n')

assert [x['id'] for x in results] == DISPATCH['proposal_ids']
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-131302-s2-strategy-proposal',
          'base': BASE, 'runs': DISPATCH['runs'], 'fixes': [],
          'skipped': ['十项宽提案均保留waiting；局部已实现、完整执行归属或联合校准不足，具体见proposal_results。'],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': DISPATCH['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
intro = (f'# 静默猎手策略提案逐项处置\n\n时间：{NOW}。本批：20261015-131302-s2-strategy-proposal。'
         f'基线：`{BASE}`。\n\n本批是reason=proposal的普通队列，精确领取10个原id，无research_request/implementation_request。'
         '根deck-size研究绑定其他批次，本批不承接专题；开工git status干净，按普通任务merge main得到Already up to date。'
         '未领取其他id、未新建重复提案、未派下级agent。\n\n'
         '结论：十项均waiting，无新增源码/知识/提交/合入/发布。已有局部实现不能关闭整条宽提案。'
         '只经原ledger CLI补充原条目的本批报告/提案追溯，不改变claim、first_run、prior、证据前缀、状态或版本。\n\n')
(OUT / 'proposal.md').write_text(intro + '\n'.join(sections))

verification = json.loads((OUT / 'evidence-verification.json').read_text())
table = '\n'.join(f'| {x["stream"]} | {x["source_size"]} | {x["accepted_rows"]} | {x["invalid_lines"]} |' for x in verification)
runs = json.loads((OUT / 'run-summary.json').read_text())
run_table = '\n'.join(f'| {x["run"]} | A{x["ascension"]} | F{x["floor"]} | {"胜" if x["victory"] else "败"} | {x["code"]} |' for x in runs)
body = ('## 证据冻结与身份\n\n'
        '八流共12702条所属原行，source_size、逐行offset/bytes/SHA、JSON正文和显式局身份全部复核。'
        'states与runs角色均为Silent；身份冲突不接纳。扫描全源遇到的坏JSON仅计数，未归属任何局。\n\n'
        '| 流 | 冻结原字节截点 | 本批原行 | 全源坏行数 |\n| --- | ---: | ---: | ---: |\n' + table + '\n\n'
        'fight-plans在此截点选到0行，只陈述该截点未选中，不推断原日志不存在；本批没有覆盖旧报告或零行初稿。\n\n'
        '| 局号 | 进阶 | 结束层 | 结果 | 历史运行标记 |\n| --- | --- | --- | --- | --- |\n' + run_table + '\n\n'
        '实际brain的293条均为engine=codex，121条accepted=true，172条旧行缺accepted。'
        'runs.deepseek_calls是历史字段，不当成实际混合引擎证据；本批初步口头判断已由原日志校正。'
        'run-config记录有dirty知识等差异，未复原旧dirty知识完整字节；当前源码/当前知识不能冒认历史完整执行树。'
        '仅本批十局为重新提取分析；原账本/当前Silent知识中的其他同角色局只读既有追溯，不计本批新样本。\n\n'
        '## 固定材料验证与消费者读回\n\n'
        'audit_evidence.py exit0，八流12702条逐字节核验通过；check_facts.py exit0，42项材料断言通过。'
        '这些属于证据校验，不是生产tsc/vitest，也不证明实战策略收益。\n\n'
        'resource_chain原消费者对ZTRG/K2/79得到12/18/7个尝试窗口：ZTRG七出口加五重开、K2十七出口加一重开、79七出口。'
        '出口包括真实死亡，不能统称胜战。ZTRG六胜房净损51；F17六试均68血进入，前五无死亡出口，末试实死。'
        'K2毒瓶首试实饮后SL恢复与末试未饮胜分列；79 F8胜后47→7的净损40不能丢。\n\n'
        '首次tsx CLI三个原输入均在建立本地IPC时EPERM，未执行消费者逻辑；原空输出及.err完整保留。'
        '随后用node --import原tsx loader读取同一份完整冻结输入，不修改沙箱权限、生产源码或消费者断言：\n\n'
        '| 输入 | 退出码 | 选线片段 | 已核整轮端点 | 完整候选结果 |\n| --- | ---: | ---: | ---: | --- |\n'
        '| ZTRGYYMLR8SC完整输入 | 0 | 130 | 69（另39未知） | 全部null |\n'
        '| K2JAGKVJAWZJ完整输入 | 1 | 未生成 | 未生成 | 拒收 |\n'
        '| 79UCJ0K6R9C1完整输入 | 0 | 78 | 0（42未知） | 全部null |\n\n'
        'K2真实拒收源于d285853/F7及d285888/F11两条map/route-change缺decision_id；原722条输入完整保留，'
        '未删行伪造整局通过。79没有可靠尝试身份使235动作的区间全未知，未伪填0损/0伤。'
        'ZTRG594动作里388个可核观测区间也不认证整候选因果。\n\n'
        '没有源码变更，撤源码失败/恢复通过不适用；未运行生产tsc/vitest，tests三个字段均null。'
        '没有提交，不造Co-Authored-By、合入提交、eval版本、shipped或新消费者收益。\n\n'
        '## 原反证与源码边界\n\n'
        'F27T2旧提案“已有16挡”实际是0→0，覆甲0→7；原文本SHA保持。'
        '既有普通提案反证通知d486caef57aeb0c096a29a75三阶段回执SHA均匹配，'
        '沿原ops→watcher→Roy链处理，本批只读核验，不重复发送或代填角色ACK。\n\n'
        f'源码审计以live `{SOURCE["live"]}` 为读取截点，12个所读源码路径的最近源码提交均是该live祖先；'
        '11路径同叶，card-model仅两处历史Roy/Dai注释署名差，原diff保留，不修改或混报完全同叶。'
        '零毒子项的5dbb47bfb48d652adfcda2e62c166a804098b6c3与蟹毒当步事实154c9542711a4daf17bfa0b97eaa1ca81dc3d385'
        '分别是已有窄源码，不标记本批整宽项implemented/duplicate。\n\n'
        '只读诊断中的不存在路径agent/src/hand/execute.ts、提取结束前manifest未就绪、'
        '误以工作树目录当merge-base对象均已按实际路径/-C及提取完成后核正。它们不是生产测试失败；原会话工具回执保留。\n\n'
        '## 交接与限制\n\n'
        f'运维入口：`{OUT / "proposal.md"}`；机器处置：`{OUT / "proposal-results.json"}`；最终JSON：`{OUT / "result.json"}`。'
        'code_proposals返回十个原CLI id，implementation_domains=[]表示本批无实际实现；保留原提案各自domains。'
        '后续仅凭新增本角色完局、完整来源和可核后继再审；本批报告完成不关闭量化/经验父要求。\n\n'
        '缺数据包括：完整候选执行归属、未选线整战结果、药水持有/晚喝对照、联合修饰校准、'
        '旧投影逐节点来源与部分完整伤源。SL不作独立局；A3/A4/A7不混进A10策略拟合。'
        '知识库已有更宽同角色文字不是本批重新验证的新证据。未调用LLM/API、未联网、未运行play、未操作对局或修改其他角色。\n\n'
        '逐项证据、账本、反例、旧行为/预期行为、验证方法和实际等待原因如下。\n\n')
(OUT / 'report.md').write_text(intro + body + '\n'.join(sections))
print(json.dumps({'base': BASE, 'report': str(OUT / 'report.md'), 'proposal_results': results}, ensure_ascii=False))

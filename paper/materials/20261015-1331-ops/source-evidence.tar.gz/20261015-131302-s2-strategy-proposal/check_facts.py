import collections
import json
from pathlib import Path

OUT = Path(__file__).parent
frames = {x['line']: x for x in json.loads((OUT / 'selected-frames.json').read_text())}
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': True})


def power(items, name):
    return sum(x['amount'] for x in items or [] if x['power_id'] == name)


check('F27T2铁心原挡与药后挡', [frames[n]['block'] for n in (292788, 292789)], [0, 0])
check('F27T2铁心覆甲', [power(frames[n]['powers'], 'PLATING_POWER') for n in (292788, 292789)], [0, 7])
check('F27T2铁心HP', [frames[n]['hp'] for n in (292788, 292789)], [57, 57])
check('K2毒药当步敌HP', [frames[n]['enemies'][0]['current_hp'] for n in (292940, 292941)], [54, 54])
check('K2毒药当步毒层', [power(frames[n]['enemies'][0]['powers'], 'POISON_POWER') for n in (292940, 292941)], [42, 48])
check('K2毒药当步玩家HP', [frames[n]['hp'] for n in (292940, 292941)], [10, 10])
check('K2读档恢复血量', frames[292942]['hp'] - frames[292941]['hp'], 52)
check('K2读档回到首轮', frames[292942]['turn'], 1)
check('K2读档恢复毒药瓶', [p['potion_id'] for p in frames[292942]['potions'] if p.get('occupied')], ['POISON_POTION'])
check('升级蜃景零毒', sum(power(e['powers'], 'POISON_POWER') for e in frames[293158]['enemies']), 0)
check('升级蜃景格挡不增', [frames[n]['block'] for n in (293158, 293159)], [16, 16])
check('升级蜃景花费1能', [frames[n]['energy'] for n in (293158, 293159)], [1, 0])
check('普通蜃景现场毒8', sum(power(e['powers'], 'POISON_POWER') for e in frames[293196]['enemies']), 8)
check('普通蜃景现场敏2', power(frames[293196]['powers'], 'DEXTERITY_POWER'), 2)
check('普通蜃景实增10挡', frames[293197]['block'] - frames[293196]['block'], 10)
check('普通蜃景所在轮实损26', frames[293197]['hp'] - frames[293198]['hp'], 26)
check('79毒药当步敌HP', [frames[n]['enemies'][0]['current_hp'] for n in (293463, 293464)], [8, 8])
check('79毒药当步毒层', [power(frames[n]['enemies'][0]['powers'], 'POISON_POWER') for n in (293463, 293464)], [4, 10])
check('79饮毒后仍先死亡', frames[293465]['hp'], 0)
check('79死亡时敌HP未减', frames[293465]['enemies'][0]['current_hp'], 8)
check('79死亡时10毒未结算', power(frames[293465]['enemies'][0]['powers'], 'POISON_POWER'), 10)
check('79T6观测净失血32', frames[293440]['hp'] - frames[293443]['hp'], 32)
check('79T10观测净失血11', frames[293460]['hp'] - frames[293461]['hp'], 11)
check('ZTRG末试三敌初血总量324', sum(e['current_hp'] for e in frames[292332]['enemies']), 324)
check('ZTRG末试末页神官余58', frames[292402]['enemies'][0]['current_hp'], 58)
check('ZTRG末试末页HP0', frames[292402]['hp'], 0)
resource = json.loads((OUT / 'ZTRGYYMLR8SC.resources.json').read_text())
check('ZTRG前六胜房净损51', sum(c['observed_net_hp_loss'] for c in resource['combats'][:6]), 51)
check('ZTRG同族六次68血进场', [c['entry']['hp'] for c in resource['combats'][6:]], [68] * 6)
check('ZTRG前五次为重开非已见死亡出口', [c['end'] for c in resource['combats'][6:11]], ['restart_observed'] * 5)
actions = json.loads((OUT / 'observed-actions.json').read_text())
check('ZTRG实际17条饮用动作', sum(a['run'] == 'ZTRGYYMLR8SC' and a['chosen']['action'] == 'use_potion' for a in actions), 17)
brain = [json.loads(l)['row'] for l in (OUT / 'evidence/brain.evidence.jsonl').open()]
check('本批293条brain均Codex', dict(collections.Counter(r.get('engine') for r in brain)), {'codex': 293})
check('旧brain缺accepted字段172条', sum('accepted' not in r for r in brain), 172)
check('已显式accepted的brain121条', sum(r.get('accepted') is True for r in brain), 121)
verification = json.loads((OUT / 'evidence-verification.json').read_text())
check('八流共12702条所属原行', sum(x['accepted_rows'] for x in verification), 12702)
check('提取流数8', len(verification), 8)
summary = json.loads((OUT / 'selection-node-import-summary.json').read_text())
check('ZTRG完整消费者读回成功', summary[0]['exit_code'], 0)
check('ZTRG已核69个整轮端点', summary[0]['turns']['observed_turn_endpoints'], 69)
check('ZTRG完整候选归属仍空', summary[0]['full_candidate_results'], 0)
check('K2完整消费者真实拒收', summary[1]['exit_code'], 1)
refusals = json.loads((OUT / 'K2JAGKVJAWZJ.consumer-refusals.json').read_text())
check('K2两条路线变更缺决策ID', [(r['line'], r['reasons']) for r in refusals], [(285853, ['missing_decision_id']), (285888, ['missing_decision_id'])])
check('79完整消费者读回成功', summary[2]['exit_code'], 0)
check('79整轮42项保持未知', summary[2]['turns'], {'unknown': 42})
(OUT / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(checks), 'production_tests': False}, ensure_ascii=False))

import collections
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent

def power(state):
    return next((x.get('amount') for x in ((state.get('combat') or {}).get('player') or {}).get('powers', [])
                 if x['power_id'] == 'DAMPEN_POWER'), None)

def zones(state):
    combat = state.get('combat') or {}
    view = (state.get('agent_view') or {}).get('combat') or {}
    result = {'hand': collections.Counter((x['card_id'], x.get('upgraded')) for x in combat.get('hand', []))}
    for pile in ['draw', 'discard', 'exhaust']:
        if not isinstance(view.get(pile), list):
            return None
        result[pile] = collections.Counter()
        for entry in view[pile]:
            if len(entry.get('card_ids', [])) != 1:
                return None
            line = entry.get('line', '')
            count = int((re.search(r'^[^\[：:]*?\*(\d+)\s*\[', line) or [None, '1'])[1])
            upgraded = bool(re.search(r'^[^\[*：:]*?\+\s*(?:\*\d+\s*)?\[', line))
            result[pile][(entry['card_ids'][0], upgraded)] += count
    return result

def base(piles):
    if piles is None:
        return None
    result = collections.Counter()
    for pile in piles.values():
        for (card_id, _), count in pile.items():
            result[card_id] += count
    return result

previous = {}
windows = []
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    entry = json.loads(line)
    state, run = entry['row']['state'], entry['run_id']
    before_entry = previous.get(run)
    if before_entry:
        before = before_entry['row']['state']
        if (state.get('run') or {}).get('floor') == (before.get('run') or {}).get('floor') and not power(before) and power(state):
            before_counts, after_counts = base(zones(before)), base(zones(state))
            windows.append({'run': run, 'before': before_entry['line'], 'after': entry['line'],
                            'floor': (state.get('run') or {}).get('floor'), 'turns': [before.get('turn'), state.get('turn')],
                            'all_base_counts_equal': before_counts == after_counts if before_counts is not None and after_counts is not None else None,
                            'base_delta': dict(after_counts - before_counts) if before_counts is not None and after_counts is not None else None,
                            'pure_instantaneous_frame': False,
                            'reason': '跨轮或含抽牌/结算的观测窗口，仅守恒不认证物理副本或抽序'})
    previous[run] = entry
assert len(windows) == 11
assert len({w['run'] for w in windows}) == 8
assert all(w['all_base_counts_equal'] and w['turns'] == [2, 3] for w in windows)
(OUT / 'dampen-windows.json').write_text(json.dumps(windows, ensure_ascii=False, indent=2) + '\n')

audits = {run: json.loads((OUT / ('consumer-audit-' + run + '.json')).read_text())
          for run in ['GXNKW8X1XYJP', 'PD9AYQVMLQW6', 'L2TSFU62Z57Z', 'YF0LXT1QSTGG']}
summary = []
for run, audit in audits.items():
    assert all(s['actual_full_candidate_result'] is None for s in audit['segments'])
    summary.append({'run': run, 'segments': len(audit['segments']), 'actions': len(audit['observed_actions']),
                    'linked_intervals': sum(x.get('after') is not None for x in audit['observed_intervals']),
                    'turns': len(audit['observed_turns']),
                    'observed_turns': sum(t['status'] == 'observed_turn_endpoints' for t in audit['observed_turns']),
                    'unknown_all_full_candidates': True})
assert sum(x['segments'] for x in summary) == 562
assert sum(x['linked_intervals'] for x in summary) == 1337
(OUT / 'consumer-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')

source = json.loads((OUT / 'consumer-input-L2TSFU62Z57Z.json').read_text())
guard_rows = [d for d in source['decisions'] if d.get('floor') == 17 and 'HP guard:' in d.get('rationale', '')]
assert len(guard_rows) == 9
assert sum('SL explore' in d['rationale'] for d in guard_rows) == 4
turns = [t for t in audits['L2TSFU62Z57Z']['observed_turns']
         if t['floor'] == 17 and t['attempt'] in [2, 3, 4, 5, 6] and t['turn'] in [2, 3]]
observations = []
for turn in turns:
    facts = turn['facts']
    before, after = facts['before'], facts['after']
    row = {'attempt': turn['attempt'], 'turn': turn['turn'],
           'before_line': before['source_line'], 'after_line': after['source_line'],
           'hp_before': before['hp'], 'hp_after': after['hp'],
           'player_hp_net_loss': before['hp'] - after['hp'],
           'enemy_hp_net_loss': sum(x['hp'] for x in before['enemies']) - sum(x['hp'] for x in after['enemies']),
           'complete_candidate_result': facts['actual_full_candidate_result']}
    if turn['turn'] == 2:
        expected = [5, 30] if turn['attempt'] == 2 else [15, 44]
        assert [row['player_hp_net_loss'], row['enemy_hp_net_loss']] == expected
    elif turn['attempt'] >= 3:
        assert [row['player_hp_net_loss'], row['enemy_hp_net_loss']] == [7, 16]
    observations.append(row)
control = {'guards': [{'line': d['_line'], 'attempt': d['sl_attempt'], 'turn': d['turn'],
                       'rationale': d['rationale']} for d in guard_rows],
           'observed_turn_windows': observations,
           'limits': '候选被后续SL或重问替换；净变化不是完整候选归属或未选方案的整战因果。'}
(OUT / 'control-observations.json').write_text(json.dumps(control, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'dampen_windows': len(windows), 'dampen_runs': 8, 'guards': len(guard_rows),
                  'overridden_guards': 4, 'control_turns': len(observations), 'consumer_summary': summary},
                 ensure_ascii=False, indent=2))

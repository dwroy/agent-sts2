# 静默猎手策略批次报告

2026-10-15 13:23:52 CST；批次20261015-131302-strategy-proposal。结论：10项全部waiting，没有新增源码、知识修改、提交、live合入或发布。完整逐项证据、账本、反例、预期行为和验证方法见[proposal.md](proposal.md)；机器处置见[result.json](result.json)。

## 身份、基线与原件

- base/HEAD：`a936191941240393bf578b8824141c5b4c01f52e`；开工干净，main已核且无需合并。
- learn.json对应行的task/character/worktree/runs及10个proposal_ids匹配；reason=proposal，没有research_request、implementation_request或proposal_repair。不领取其他批次，不用旧专题代替本批。
- 10份原提案Markdown均与队列保存SHA256相等。读取各关联账本与silent经验子集，31个账本保留既有claim/首证/prior/status/version/证据；仅CLI记录本批追溯，不新增support或重复经验，也不降级已shipped历史。
- 十局角色全部Silent：ZE8F192FKX24 A5、VN7RQJMJEFMX A6、2PVLGRBGUX9S A7，其余七局A10。旧字段deepseek_calls不是实际脑引擎证明；GX/PD9/L2脑原流分别48/55/17条accepted Codex/gpt-6.1-sol。本报告不以启动配置或README默认值冒称本学习者原生会话模型/强度已经独立核验。

## 原日志与材料核验

通过本树共用extract_evidence.py入口冻结8流，保存source_size、每行原offset/bytes/SHA256及计数。逐行seek回原日志，复算SHA、JSON正文、显式局身份与角色/进阶，18295行全部一致。具体流：states9019、decisions8670、SL71、run-config10、run-plans70、brain445、runs10、fight-plans0。fight-plans为本截点未选到0行，不推断原日志不存在；run-plans按run身份提取70行。

全流扫描原坏行states2、decisions2、brain1保留计数；不是所选有效证据，不从正文提及认局，不将冲突身份接收。全部所选状态角色/进阶与runs一致，没有缺角色帧。原件与复核在evidence/和evidence-verification.json。

固定数字检查21项通过。初次材料脚本把PD9弃牌帧误选为291339/291340，实际分别19/31挡，断言失败原日志与脚本副本保留；核原帧后改为291340/291341的31/32挡、3/2张凋萎，独立目标数字未放松，第二次通过。这是材料定位错误，不是生产测试失败。另首次交互查看非战斗state时对None取keys报错，随后按首个实际combat帧查看；未动原日志或源码。

## 支持、反例与未确定项

1. 抑制：八局11个进入抑制的观测窗，全部T2→T3，四区基础ID总数均守恒；GX四次SL仍出现四张普通键inserted，clean19/18/19/18。基础ID守恒不证明物理副本和抽序，缺纯改标瞬时帧/歧义反例，不安全延长前缀。战内普通版本读取和场外升级分账已证，不等于SL记录修复。
2. 普通生存者：PD9 F49末T10开场3血8挡两张凋萎；防御后18挡三张、打击后19挡，生存者选择中31挡三张，完成后32挡两张，每张12持伤；判官23攻击，完整需求24+23−32=15，算术余血−12，实际0血截断只损3。旧模型−1保留；不是多受11或修后能赢。普通单弃source `bf423c173d3be348a4ad714e1d26516df619ff41`已核为live祖先；当前新增凋萎仍是终局标量计数，多选待实盘重读，不能关闭原完整要求。
3. 护栏/SL：L2九护栏四被SL撤回。第2试T2实窗65→60、敌249→219；第3—6试同轮65→50、敌249→205；后四次T3重问整轮损7/扣16。只五条护栏保留改变执行，90候选省血不能记作90实省。完整替线、候选持续身份及药水恢复归因仍未知。
4. 末T6：L2 plan1打击/侧步列7伤但侧步未建模，5轮死14/24；结束死11/24，三条整战各1200样本均0胜，Jev以0.94选结束。T8实际只打一张16伤后敌113，17血对17来攻实死。有限零胜不是必死证明，不据7点即时伤害改排序或放宽SL。
5. 资源接续：PD9 F48 58→10，下一F49原样10血空药；GX F35/38/40赢战净耗13+18+25=56，F44 71→5净耗66；L2 F14 44→24并在胜后另获血清，F17以65血接续。奖励/SL恢复/主动喝药/自动精灵分别保留，赢战不等于低耗，未来营火不是已得资源。替路线/提前用药的整场结果未执行，不能拟血价或药水持有因果。

## 现有实现及消费者读回

source-audit.json记录本树20个相关源码/消费者叶与live快照`efed9b0a105c2f2c0d59089c8e938121f5ea8fc1`。16叶逐字节相等，4叶仅Roy/Dai历史注释不同，原binary diff与各SHA保留；20个最近来源提交均为该live祖先。候选阶段审计、单动作dispatch回执、首动作量化抽取、普通单弃、现场能力模型和离线端点均属已有子项，本批没有实现它们，不登记整项duplicate。

使用现有learner/audit-selection.ts读取GX/PD9/L2/YF0L四局冻结投影，四次均exit0：3167个有ID动作、562个选线片段、1337个可连接相邻观测区间；514个整轮窗口中194个有端点、320个unknown。四局状态分别673/1125/447/1091帧。原GX3、PD9 2、L2 1条map/route-change无decision_id元数据明确排除并保留原行号，不伪造全量消费者通过。其余原字段值/原行/SHA保持；投影省去重复agent_view和无关屏幕对象，完整抽取原件仍保留。

消费者完整候选实果仍全部null；端点、整轮净变化与单动作完成回执不认证线上候选全线执行。模型/能力缺口、实际路线/休息消费者、复活逐击未截断入伤和未选整场反事实依旧开放。c288原18局清单保留，本批只重核十锚点及四局执行消费者，不冒认重做全部历史药水统计。

## 交付与限制

十项处置在proposal.md和result.json逐项列明。31个既有账本只经根ledger.py update追加where.proposal及note，CLI输入/回执及读回保存ledger-trace-*；无状态、首证、prior、旧证据、claim或version变更。沿用10个真实CLI代码提案ID，不创建重复ID，不标shipped。原机制/候选差异是已知限制，本批没有新反证，不发重复必要反证通知。

无新增源码，未运行撤源码失败/恢复通过、tsc或vitest，tests三个字段均null。固定材料检查与四次消费者exit0不是生产自测。没有提交、不推送、不合live、不造eval版本；工作树tracked保持干净，HEAD保持base。经验库入库、live采用及收益均未声明完成；等待各项具体缺失数据后沿原ID续派。

安全扫描结果与最终工作树复核另见final-verification.json；不读取key/.env、其他角色知识或游戏二进制，不联网、不运行play，不派子agent。

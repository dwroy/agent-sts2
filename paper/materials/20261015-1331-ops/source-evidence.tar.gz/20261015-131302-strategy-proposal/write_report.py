import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261015-131302-strategy-proposal'
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
NOW = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
originals = [e['row'] for e in json.loads((OUT / 'original-proposals.json').read_text())]
reasons = [
    '八局11个抑制窗口均跨T2→T3，仅证基础ID总数守恒；缺纯改标瞬时帧、唯一物理副本及并发抽牌/插入/洗牌的顺序证据，不能安全延长SL前缀。',
    '毒雾、触媒及现场普通版本已有局部模型；覆甲完整减层、阻毒/加量组合和未建能力的联合固定消费者回放未齐，缺提前喝药/先能力的同输入整战对照。',
    '战内普通文本与场外升级分账成立；11个跨轮守恒窗口仍缺物理身份、抽序与恢复全链，普通版本读取不能代替SL身份修复。',
    '赢战耗血和药栏端点可核；仍缺复活逐击未截断入伤、原候选完整执行归属、替路线及提前用药整战结果，不能从净HP差拟血价或放宽SL。',
    '普通单弃修复bf423c173d3be348a4ad714e1d26516df619ff41已是live祖先；新增凋萎仍仅在终局计数，多选身份保持未知，缺原开场贯通生成实体/选择完成/32挡24持伤23攻击的生产固定回放，整项不能duplicate。',
    '九条护栏中四条被SL撤回已核；已有阶段候选审计、单动作回执和离线端点，仍缺在线持续候选ID、真实前缀/重问父子链及饮药/恢复全链认证。',
    '7伤线五轮死亡14/24高于结束11/24，侧步未建模且三条整场均0/1200胜；缺同抽序完整替线、侧步兑现和独立后期验证，不据即时伤害改排序。',
    '现场力敏、余像、仪式、药水等局部证据与源码入口保留；十五账本全入口尚缺覆甲完整减层、力量/滚石与换战未结算组合的生产固定消费者回放，不能以子模型关闭整项。',
    'PD9首Boss58→10且下Boss以10血空药接续已核；缺真实血药/复活链到路线/休息消费者的联合校准及未选整场路线/用药对照，现有双Boss接口不是整项交付。',
    '四局562片段仍全部保持完整候选实果未知；缺在线持续候选身份、重问后全线执行和原线整场反事实，有限全死不足以放宽SL必死边界。',
]
evidence = [
    'GXNKW8X1XYJP A10 F45T2→T3，states290205→290206，SL1053—1056；ZE8F192FKX24 A5 F42T2→T3，states223267→223268；其余六局及11窗口见dampen-windows.json。',
    'GXNKW8X1XYJP A10 F33T3/5/6、F45T1—3；F45普通刀刃/触媒现场见states290206；完整原件保存在evidence，各旧机制提案原SHA保留。',
    '八局抑制11窗口与GX F45升级牌改标，场外牌组/出口见states290201、290206、290214，ZE8 F42T3/4为历史首证。',
    'GX F35/38/40分别97→84、84→66、66→41；F44 71→5；F45第二/末次T2→T3与精灵槽变动由消费者观测端点分列。',
    'PD9AYQVMLQW6 A10 F49第6试T10；states291336—291342、decisions284707—284711、SL1067；账本首证仍为53FLQ68CETW0，不重写。',
    'L2TSFU62Z57Z A10 F17第2—6试T2/T3；九条decisions284918/284967/284971/285020/285024/285073/285077/285126/285130；control-observations.json。',
    'L2TSFU62Z57Z A10 F17末试T6/T8，decision285148、states291780—291783及291790—291792；原三条whole_fight_sim和未建模侧步完整保留。',
    'PD9 A10 F49末T10力量/敏捷/余像/凋萎现场及F48→49能力分账；L2 A10 F6速度药、F14敏捷/铜液、F17T6/T8；原18局清单仅按提案保留，不冒称本批重算全历史药水统计。',
    'PD9 A10 F48首帧290969为58血，出口291020为10血，F49首帧291021仍10血空药；L2 F14 44→24、F17 65血，见battle-endpoints.json。',
    'L2 F17护栏/SL/重问与末T6/T8；PD9 F48/F49及末T10；GX/YF0L补充有限执行窗口，四局消费者输出均不认证完整候选。',
]
validation = [
    '须有纯改标且留堆不动的正例、真实插入/同ID多副本/洗回的反例，核无假inserted、歧义继续断序；不改变判死。',
    '按实际角色和进阶冻结每一能力/药水入口，联测制品、头骨、覆甲和未结算能力；未采用方案不填实果。',
    '战内版本/出口恢复与场外deck分别核，真实抽序身份不因同基ID配对被冒认。',
    '必须分列主动饮用、自动精灵、SL恢复、奖励与弃药，逐击入伤和整场替线缺失保持未知。',
    '从PD9原T10输入出发验证生成凋萎实体、弃一张、余像选择时点、24持伤后23攻击；3血仍死，不宣称转胜。',
    '第2试T2应观测损5/扣30，3—6试T2各损15/扣44，后四次T3重问整轮损7/扣16；预测与实线分开。',
    '同输入整场对照须保留样本分母、未知牌和一牌上限；当前反例排除固定优先补7伤。',
    '十五条账本分别覆盖，不用力量解释未经观察的滚石增幅，不将未建立能力或未来层数算为已兑现。',
    '首战出口资源与次战入口同样本衔接，验证实际路线/休息消费者读回；四局旧拟合不是新量化校准。',
    '在线候选→执行前缀→选择/重问→下一候选→战斗出口需稳定归属；仅完整观测窗净变化不能证明原候选收益。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(originals, reasons)]
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
         'runs': json.loads((OUT / 'batch-identity.json').read_text())['row']['runs'],
         'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': [p['id'] for p in originals], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

header = f'''# 本批策略提案处置

生成时间：{NOW}。批次{BATCH}；角色silent；来源strategy-proposal；实现目标原10个CLI提案ID。本批没有新增代码提案，也没有修改旧提案原文。

基线/HEAD：`{BASE}`。开工tracked clean，普通队列身份已核，`git merge --no-edit main`返回Already up to date；没有research_request或implementation_request。旧牌量专题另批绑定，不承接、不扩大范围。

## 共同判断与边界

十项均waiting。已有局部实现只作范围说明，不将它登记为整项implemented/duplicate。已核原提案10份Markdown SHA均匹配；31个账本的原claim、首证、prior、status、version与证据保留，仅经根ledger CLI追加本批追溯链接与note。

旧行为保留；不改变出牌排序、药水价、护栏8点、SL准入或终局权重。下述拟验证行为来自原提案与本角色原帧，不把Roy授权当游戏事实。其他角色和未观察进阶保持等价。

样本/切分：十个锚点均由runs.jsonl核角色；A5、A6、A7和A10分列。同局SL是相关尝试；当前提案没有新的独立留出局，不能把模拟样本或重打当独立实盘。原运行code均含dirty，未还原原执行树，不用当前源码替代历史执行源码。

拟合：本批不拟合牌值、血价、药水、SL或终局阈值。期望只按以下有界证据继续验收；缺数据时保留原行为。无新增策略提交，因此撤源码失败/恢复通过、tsc/vitest、live合入、版本、shipped均不适用。将来实现须按原提案固定正反例、撤源码失败/恢复通过与沙箱入口验证，再走live流程；回退仅撤该独立补丁，保留证据及并行知识刷新。

'''
sections = []
for i, (p, reason, ev, method) in enumerate(zip(originals, reasons, evidence, validation), 1):
    sections.append(f'''## {i}. {p['id']} — {p['summary']}

- 账本：{', '.join(p['ledger'])}。原提案SHA：`{p['proposal_sha256']}`，原文副本：`{p['id']}.md`。
- 证据：{ev}
- 处置/缺口：waiting；{reason}
- 反例/预期行为与验证：{method}
- 预期影响与限制：只在证据覆盖范围提高事实或身份可核性；当前未证明胜率改善，不声称本局可获救。后续新局应按时间留出，旧SL仍只作复现。

''')
(OUT / 'proposal.md').write_text(header + ''.join(sections), encoding='utf8')

report = f'''# 静默猎手策略批次报告

{NOW}；批次{BATCH}。结论：10项全部waiting，没有新增源码、知识修改、提交、live合入或发布。完整逐项证据、账本、反例、预期行为和验证方法见[proposal.md](proposal.md)；机器处置见[result.json](result.json)。

## 身份、基线与原件

- base/HEAD：`{BASE}`；开工干净，main已核且无需合并。
- learn.json对应行的task/character/worktree/runs及10个proposal_ids匹配；reason=proposal，没有research_request、implementation_request或proposal_repair。不领取其他批次，不用旧专题代替本批。
- 10份原提案Markdown均与队列保存SHA256相等。读取各关联账本与silent经验子集，31个账本保留既有claim/首证/prior/status/version/证据；仅CLI记录本批追溯，不新增support或重复经验，也不降级已shipped历史。
- 十局角色全部Silent：ZE8F192FKX24 A5、VN7RQJMJEFMX A6、2PVLGRBGUX9S A7，其余七局A10。旧字段deepseek_calls不是实际脑引擎证明；GX/PD9/L2脑原流分别48/55/17条accepted Codex/gpt-6.1-sol。本报告不以启动配置或README默认值冒称本学习者原生会话模型/强度已经独立核验。

## 原日志与材料核验

通过本树共用extract_evidence.py入口冻结8流，保存source_size、每行原offset/bytes/SHA256及计数。逐行seek回原日志，复算SHA、JSON正文、显式局身份与角色/进阶，18295行全部一致。具体流：states9019、decisions8670、SL71、run-config10、run-plans70、brain445、runs10、fight-plans0。fight-plans为本截点未选到0行，不推断原日志不存在；run-plans按run身份提取70行。

全流扫描原坏行states2、decisions2、brain1保留计数；不是所选有效证据，不从正文提及认局，不将冲突身份接收。全部所选状态角色/进阶与runs一致，没有缺角色帧。原件与复核在evidence/和evidence-verification.json。

固定数字检查21项通过。初次材料脚本把PD9弃牌帧误选为291339/291340，实际分别19/31挡，断言失败原日志与脚本副本保留；核原帧后改为291340/291341的31/32挡、3/2张凋萎，独立目标数字未放松，第二次通过。这是材料定位错误，不是生产测试失败。另首次交互查看非战斗state时对None取keys报错，随后按首个实际combat帧查看；未动原日志或源码。

## 支持、反例与未确定项

1. 抑制：八局11个进入抑制的观测窗，全部T2→T3，四区基础ID总数均守恒；GX四次SL仍出现四张普通键inserted，clean19/18/19/18。基础ID守恒不证明物理副本和抽序，缺纯改标瞬时帧/歧义反例，不安全延长前缀。战内普通版本读取和场外升级分账已证，不等于SL记录修复。
2. 普通生存者：PD9 F49末T10开场3血8挡两张凋萎；防御后18挡三张、打击后19挡，生存者选择中31挡三张，完成后32挡两张，每张12持伤；判官23攻击，完整需求24+23−32=15，算术余血−12，实际0血截断只损3。旧模型−1保留；不是多受11或修后能赢。普通单弃source `bf423c173d3be348a4ad714e1d26516df619ff41`已核为live祖先；当前新增凋萎仍是终局标量计数，多选待实盘重读，不能关闭原完整要求。
3. 护栏/SL：L2九护栏四被SL撤回。第2试T2实窗65→60、敌249→219；第3—6试同轮65→50、敌249→205；后四次T3重问整轮损7/扣16。只五条护栏保留改变执行，90候选省血不能记作90实省。完整替线、候选持续身份及药水恢复归因仍未知。
4. 末T6：L2 plan1打击/侧步列7伤但侧步未建模，5轮死14/24；结束死11/24，三条整战各1200样本均0胜，Jev以0.94选结束。T8实际只打一张16伤后敌113，17血对17来攻实死。有限零胜不是必死证明，不据7点即时伤害改排序或放宽SL。
5. 资源接续：PD9 F48 58→10，下一F49原样10血空药；GX F35/38/40赢战净耗13+18+25=56，F44 71→5净耗66；L2 F14 44→24并在胜后另获血清，F17以65血接续。奖励/SL恢复/主动喝药/自动精灵分别保留，赢战不等于低耗，未来营火不是已得资源。替路线/提前用药的整场结果未执行，不能拟血价或药水持有因果。

## 现有实现及消费者读回

source-audit.json记录本树20个相关源码/消费者叶与live快照`efed9b0a105c2f2c0d59089c8e938121f5ea8fc1`。16叶逐字节相等，4叶仅Roy/Dai历史注释不同，原binary diff与各SHA保留；20个最近来源提交均为该live祖先。候选阶段审计、单动作dispatch回执、首动作量化抽取、普通单弃、现场能力模型和离线端点均属已有子项，本批没有实现它们，不登记整项duplicate。

使用现有learner/audit-selection.ts读取GX/PD9/L2/YF0L四局冻结投影，四次均exit0：3167个有ID动作、562个选线片段、1337个可连接相邻观测区间；514个整轮窗口中194个有端点、320个unknown。四局状态分别673/1125/447/1091帧。原GX3、PD9 2、L2 1条map/route-change无decision_id元数据明确排除并保留原行号，不伪造全量消费者通过。其余原字段值/原行/SHA保持；投影省去重复agent_view和无关屏幕对象，完整抽取原件仍保留。

消费者完整候选实果仍全部null；端点、整轮净变化与单动作完成回执不认证线上候选全线执行。模型/能力缺口、实际路线/休息消费者、复活逐击未截断入伤和未选整场反事实依旧开放。c288原18局清单保留，本批只重核十锚点及四局执行消费者，不冒认重做全部历史药水统计。

## 交付与限制

十项处置在proposal.md和result.json逐项列明。31个既有账本只经根ledger.py update追加where.proposal及note，CLI输入/回执及读回保存ledger-trace-*；无状态、首证、prior、旧证据、claim或version变更。沿用10个真实CLI代码提案ID，不创建重复ID，不标shipped。原机制/候选差异是已知限制，本批没有新反证，不发重复必要反证通知。

无新增源码，未运行撤源码失败/恢复通过、tsc或vitest，tests三个字段均null。固定材料检查与四次消费者exit0不是生产自测。没有提交、不推送、不合live、不造eval版本；工作树tracked保持干净，HEAD保持base。经验库入库、live采用及收益均未声明完成；等待各项具体缺失数据后沿原ID续派。

安全扫描结果与最终工作树复核另见final-verification.json；不读取key/.env、其他角色知识或游戏二进制，不联网、不运行play，不派子agent。
'''
(OUT / 'report.md').write_text(report, encoding='utf8')

spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = {i for p in originals for i in p['ledger']}
items = {}
for line in (ROOT / 'paper/materials/learning/ledger.jsonl').open():
    row = json.loads(line)
    if row.get('id') in ids:
        ledger.apply(items, row)
(OUT / 'ledger-trace-before.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
updates = []
for item_id in sorted(ids):
    links = [p['id'] for p in originals if item_id in p['ledger']]
    updates.append({'id': item_id, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': BATCH + '：沿原提案' + ','.join(links) + '核查；本批waiting，具体缺项见报告。原证据重复读回只作追溯，不新增support/claim/首证/prior/status/version，不把局部live实现或消费者端点当整项交付。'})
(OUT / 'ledger-trace-input.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': BASE, 'proposal_results': len(results), 'ledger_trace_rows': len(updates),
                  'report': str(OUT / 'report.md')}, ensure_ascii=False))

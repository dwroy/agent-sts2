import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
verification = []
for item in manifest:
    stream = item['stream']
    rows = []
    counts = collections.Counter()
    digest = hashlib.sha256()
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for raw in path.open('rb'):
            digest.update(raw)
            entry = json.loads(raw)
            source.seek(entry['offset'])
            original = source.read(entry['bytes'])
            assert hashlib.sha256(original).hexdigest() == entry['sha256']
            assert json.loads(original) == entry['row']
            assert extract.run_identity(entry['row']) == entry['run_id']
            assert entry['offset'] + entry['bytes'] <= item['source_size']
            counts[entry['run_id']] += 1
            rows.append(entry)
    assert all(counts[r] == c for r, c in item['counts'].items())
    assert digest.hexdigest() == item['output_sha256']
    verification.append({'stream': stream, 'rows': len(rows), 'source_size': item['source_size'],
                         'invalid_lines': item['invalid_lines'], 'incomplete_lines': item['incomplete_lines'],
                         'raw_bytes_sha_identity_verified': True})
    streams[stream] = rows
runs = {e['run_id']: e['row'] for e in streams['runs']}
assert len(runs) == 10
assert all(r['character'].lower() == 'silent' for r in runs.values())
missing_character = []
for e in streams['states']:
    info = e['row']['state'].get('run') or {}
    if not info.get('character_id'):
        missing_character.append(e['line'])
    else:
        assert info['character_id'].lower() == 'silent'
        assert info['ascension'] == runs[e['run_id']]['ascension']

def powers(player):
    return {p['power_id']: p.get('amount') for p in player.get('powers', [])}

def project(e):
    s = e['row']['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    info = s.get('run') or {}
    return {'line': e['line'], 'sha256': e['sha256'], 'run': e['run_id'],
            'ts': e['row'].get('observed_ts'), 'floor': info.get('floor'), 'turn': s.get('turn'),
            'screen': s.get('screen'), 'hp': p.get('current_hp', info.get('current_hp')),
            'block': p.get('block'), 'energy': p.get('energy'), 'powers': powers(p),
            'hand': [{k: card.get(k) for k in ['index', 'card_id', 'upgraded', 'resolved_rules_text', 'can_play', 'unplayable_reason']}
                     for card in c.get('hand', [])], 'enemies': c.get('enemies'),
            'potions': info.get('potions'), 'selection': s.get('selection'),
            'piles': ((s.get('agent_view') or {}).get('run') or {}).get('piles'),
            'deck': info.get('deck')}

fixed_lines = set([223268, 223272, 290160, 290165, 290201, 290206, 290214,
                   *range(291336, 291343), *range(291780, 291784), *range(291790, 291793)])
fixed = {e['line']: project(e) for e in streams['states'] if e['line'] in fixed_lines}
decisions = {e['line']: e for e in streams['decisions']}
sl = {e['line']: e for e in streams['sl-attempts']}

checks = []
def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})

check('PD9末T10开场HP/挡', [fixed[291336]['hp'], fixed[291336]['block']], [3, 8])
check('PD9开场凋萎数', sum(c['card_id'] == 'WITHER' for c in fixed[291336]['hand']), 2)
check('PD9弃牌前后挡', [fixed[n]['block'] for n in [291340, 291341]], [31, 32])
check('PD9弃牌前后凋萎', [sum(c['card_id'] == 'WITHER' for c in fixed[n]['hand']) for n in [291340, 291341]], [3, 2])
check('PD9终态HP', fixed[291342]['hp'], 0)
check('PD9末判官来攻', sl[1067]['row']['incoming'], 23)
check('PD9原模型余血', '-1' in decisions[284707]['row']['rationale'], True)
check('GX改标前后抑制', [fixed[n]['powers'].get('DAMPEN_POWER') for n in [290201, 290206]], [None, 1])
for card_id in ['BLADE_DANCE', 'ACCELERANT']:
    check('GX普通现场牌:' + card_id,
          [c['upgraded'] for c in fixed[290206]['hand'] if c['card_id'] == card_id], [False])
check('GX四SL clean', [sl[n]['row']['draws']['clean'] for n in range(1053, 1057)], [19, 18, 19, 18])
for n in range(1053, 1057):
    check('GX假插入四基础ID:' + str(n), sorted(next(i['cards'] for i in sl[n]['row']['draws']['inserted'] if i['turn'] == 2)),
          sorted(['BLADE_DANCE', 'ACCELERANT', 'OUTBREAK', 'SUCKER_PUNCH']))
q = decisions[285148]['row']
facts = {k: json.loads(v) for k, v in q['questions']['plan']['criteria'].items()}
check('L2末T6选择', q['answers']['plan']['choice'], 'plan3')
check('L2末T6候选直伤', [facts[k]['damage_dealt'] for k in ['plan1', 'plan3']], [7, 0])
check('L2侧步未建模', facts['plan1']['unmodelled_cards'], '侧步')
check('L2末T8死亡HP', fixed[291792]['hp'], 0)
check('L2末T8结束前HP', fixed[291791]['hp'], 17)
check('L2末T8敌末血', fixed[291792]['enemies'][0]['current_hp'], 113)

focus = ['GXNKW8X1XYJP', 'PD9AYQVMLQW6', 'L2TSFU62Z57Z', 'YF0LXT1QSTGG']
inputs = []
for run in focus:
    selected_decisions = [dict(e['row'], _line=e['line'], _source_sha256=e['sha256'])
                          for e in streams['decisions'] if e['run_id'] == run]
    excluded_decisions = [d for d in selected_decisions if not d.get('decision_id')]
    valid_decisions = sorted([d for d in selected_decisions if d.get('decision_id')], key=lambda d: d.get('observed_ts') or '')
    selected_states = []
    excluded_states = []
    for e in streams['states']:
        if e['run_id'] != run:
            continue
        state = e['row']['state']
        if not (state.get('run') or {}).get('character_id'):
            excluded_states.append({'line': e['line'], 'reason': 'run角色字段缺失，保留原证据但不送消费者'})
            continue
        selected_states.append({k: v for k, v in dict(e['row'], _line=e['line'], _source_sha256=e['sha256']).items() if k != 'state'} |
                               {'state': {k: state.get(k) for k in ['run_id', 'screen', 'turn', 'combat', 'run', 'selection']}})
    data = {'run': runs[run], 'decisions': valid_decisions, 'states': selected_states}
    target = OUT / ('consumer-input-' + run + '.json')
    target.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n')
    inputs.append({'run': run, 'path': str(target), 'decisions': len(valid_decisions), 'states': len(selected_states),
                   'excluded_decisions': [{'line': d['_line'], 'label': d.get('label'), 'reason': '缺decision_id的元数据行'} for d in excluded_decisions],
                   'excluded_states': excluded_states, 'projection': '保留原字段值、原行号和SHA；状态省去agent_view重复投影及无关屏幕对象'})

summary = {'streams': verification, 'total_rows': sum(x['rows'] for x in verification),
           'runs': [{k: r.get(k) for k in ['run_id', 'character', 'ascension', 'victory', 'floor', 'code']} for r in runs.values()],
           'state_missing_character_lines': missing_character, 'checks': checks, 'consumer_inputs': inputs,
           'limitations': ['原dirty执行树未还原；源码审计仅代表本批HEAD/live快照。',
                           '同局SL不作为独立局数，固定数字验证不证明胜率或未选线效果。']}
(OUT / 'evidence-verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
(OUT / 'fixed-frames.json').write_text(json.dumps(fixed, ensure_ascii=False, indent=2) + '\n')
(OUT / 'fixed-decision-285148.json').write_text(json.dumps(decisions[285148], ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'total_rows': summary['total_rows'], 'checks': len(checks), 'streams': verification,
                  'consumer_inputs': [{k: x[k] for k in ['run', 'decisions', 'states', 'excluded_decisions', 'excluded_states']} for x in inputs]}, ensure_ascii=False, indent=2))

from pathlib import Path
p=Path('ops/codex-ops/record-staging/20261015-2028')
old=Path('ops/codex-ops/record-staging/20261015-2026/prepare-records.py').read_text().replace('20261015-2026','20261015-2028').replace('20261015-201302-s2-strategy-proposal','20261015-201302-strategy-proposal')
old=old.replace("report['fixes']==report['implementation_domains']==report['skipped']==[]", "report['fixes']==report['implementation_domains']==[] and set(report['skipped'])==set(report['code_proposals'])")
a=old.index('final=');z=old.index('inputs=')
old=old[:a]+'''final=load(s/'final-verification.json');assert final['base']==report['base'] and final['worktree_clean'] and final['dispatch_identity_preserved'] and final['proposal_results']=={'waiting':10,'implemented':0,'duplicate':0} and final['ledger_updates']==32 and final['ledger_prefix_and_protected_fields_preserved']
assert (s/'base-worktree.diff.patch').read_bytes()==b''
manifest=load(s/'artifact-manifest.json')
for x in manifest:
 raw=(s/x['path']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],x['path']
markdown=load(s/'folded-proposals.json');assert len(markdown)==10
for x in markdown:assert x['character']=='silent' and sha((s/'originals'/(x['id']+'.md')).read_bytes())==x['proposal_sha256']
evidence=load(s/'raw-verification.json');assert len(evidence)==8 and sum(x['checked_rows'] for x in evidence)==6606 and all(x['offset_bytes_sha_json_equal'] and sum(x['counts'].values())==x['checked_rows'] for x in evidence)
identities=load(s/'verified-runs.json');assert len(identities)==5 and all(x['character']=='SILENT' and x['ascension']==10 for x in identities)
materials=load(s/'material-checks.json');assert materials['count']==38 and len(materials['checks'])==38 and all(x['actual']==x['expected'] for x in materials['checks'])
source=load(s/'source-readback.json');assert source['base']==report['base'] and len(source['leaves'])==18;equal=0
for x in source['leaves']:
 a=git('show',report['base']+':'+x['path']);z=git('show',source['live']+':'+x['path']);assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256']
 if a==z:equal+=1
 else:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert equal==14
for commit,x in source['commits'].items():
 assert x['live_ancestor'] and x['base_ancestor']
 for target in [report['base'],source['live']]:git('merge-base','--is-ancestor',commit,target)
''' +old[z:]
a=old.index('inputs=');z=old.index("(p/'owned-ledger.jsonl')")
old=old[:a]+'''inputs=[json.loads(x) for x in (s/'ledger-input.jsonl').read_text().splitlines()];owned=[];owned_refs=[];offset=0
for number,raw in enumerate((r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True),1):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs):owned.append(raw);owned_refs.append({'id':row['id'],'line':number,'offset':offset,'bytes':len(raw),'sha256':sha(raw)})
 offset+=len(raw)
assert len(inputs)==len(owned)==32 and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
receipt=load(s/'ledger-appends.json');assert len(receipt)==32
for x in receipt:
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as f:f.seek(x['offset']);raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and raw in owned
ids=(s/'ledger-receipt.log').read_text().split();assert len(ids)==32 and set(ids)=={json.loads(x)['id'] for x in owned}
''' +old[z:]
old=old.replace("assert load(s/'gitleaks.json')==[] and (s/'gitleaks.exit').read_text().strip()=='0'", "assert load(s/'gitleaks.json')==[] and final['gitleaks']['exit_code']==0 and final['gitleaks']['findings']==0")
a=old.index("write(pub/'batch-readback.json'");z=old.index('files=',a)
old=old[:a]+'''write(pub/'batch-readback.json',{'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_final_verification':final,'original_manifest_entries_verified':len(manifest),'ten_original_proposal_sha_verified':True,'source18_base_and_old_live_sha_and_three_narrow_ancestors_verified':True,'source14_equal4_historical_name_comments_preserved':True,'original_evidence_rows':6606,'original_material_assertions':38,'material_probes_reexecuted':False,'original_cohort':'Five Silent A10 runs only; repeated SL is not independent data.','owned_trace_only_ledger_rows':32,'owned_ledger_byte_refs':owned_refs,'protected_fold_preserved':True,'original_preparation_failures':'Initial last-event proposal lookup lacked character; original dispatched event snapshots retained, full add/update fold read separately. Wrong reflex/selection path and truncated reads retained, no product failure.','native_gap':'Ops verified original Sol6.1/xhigh/input/lease/workspace-write/no-network. Original163 historical brain rows effort=high remains historical, not relabelled xhigh.','limits':['38 material checks are original fixed arithmetic/identity readbacks, not product tests, controlled calibration, full candidates or strategy benefit.','First NHA empty28HP/428enemy frame is distinct from operative30HP/408enemy frame; late P74 stun/egg state and outcome cannot certify unexecuted discard branches.','BTS original3/4 forecast versus one death is not an isolated probability error; original draw/action/sample pairing missing.','HP loss, net damage, death-capped observations and full incoming loss remain distinct; no threshold or wide parent closed.'],'no_source_tests_merge_release_dataset_or_game_actions':True})
''' +old[z:]
old=old.replace("files+=[s/'evidence/evidence-manifest.json']", "files+=list((s/'originals').glob('*.md'))+[s/'evidence/evidence-manifest.json']")
a=old.index('line=f');z=old.index("appends={'paper",a)
old=old[:a]+'''line=f'\\n- {at} 运维codex：2028原201302策略rc0/done/no-source门禁核，十项waiting与原skipped保留；ff0a干净WT无新源码提交、testsnull/mergednull/域空，不重合/发号/补测或新派。五Silent A10原6606行字节/身份、38材料断言为原学习者读回，不重跑或当生产测试/完整候选/整战收益；NHA最初空手28血/428敌与可操作30血/408敌基线分开，P74末态死亡不冒未执行弃牌分支胜负，BTS三胜一死预测与一次实死不当独立概率反证。18叶旧livefe646265逐SHA及3窄源码main-live祖先核，14同/4历史Roy-Dai注释差保持，投斧首牌/普通单弃/计划失效快照不冒宽候选归属或累计能力已闭合。32原CLI仅where/note/输入和原offset/bytes/SHA同验，claim/首证/prior/evidence/status/version等保护字段不变、不重复CLI。ops补核实际native Sol6.1/xhigh/input/lease与workspace-write/no-network；原163历史brain effort=high和任务旧文字不重写。原最后一条队列事件缺character的KeyError与后add/update折叠、错误源码路径和输出截断留史，不当产品bug。毛伤/净血差/死亡截顶及多次同局SL边界保持，无新知识/反证/源码/复盘，不刷新论文、不改当前局/账号home模型预算队列prompt，原宽父与owner继续原链、不等待未来事件。证据paper/materials/20261015-2028-ops/。\\n'
note=f'\\n- {at} [ops 策略处置] 原201302十项继续waiting，无新源码/合入/版本；32条CLI仅追溯且保护旧知识/状态。原6606行/38材料及准备错误和修正读回均归档，不冒完整候选、生产测试或策略收益，未重派或补测。回执paper/materials/20261015-2028-ops/。\\n'
''' +old[z:]
old=old.replace("'own_ledger_rows':44", "'own_ledger_rows':32").replace("'owned_ledger_rows':44", "'owned_ledger_rows':32")
old=old.replace("p/'prepare-records.py',p/'seal-records.py',", "p/'prepare-records.py',p/'make-helper.py',p/'seal-records.py',")
(p/'prepare-records.py').write_text(old)
seal=Path('ops/codex-ops/record-staging/20261015-2026/seal-records.py').read_text().replace('20261015-2026','20261015-2028').replace('forty-four trace-only ledger updates','thirty-two trace-only ledger updates').replace('ops: record unchanged 201302-s2 strategy dispositions','ops: record unchanged 201302 strategy dispositions')
(p/'seal-records.py').write_text(seal)

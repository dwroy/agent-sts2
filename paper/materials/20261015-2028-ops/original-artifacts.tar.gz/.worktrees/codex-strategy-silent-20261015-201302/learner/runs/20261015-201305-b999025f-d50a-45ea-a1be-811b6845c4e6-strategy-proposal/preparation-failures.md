# 材料准备中的失败与修正

- 初次读取派发队列时，错误地把每个 id 的最后一条事件当作完整提案，访问 `character` 时得到 `KeyError: 'character'`。已保留该次 `dispatched-proposals.json`，另按 add/update 顺序折叠到 `folded-proposals.json`，并逐项校验静默身份、原 Markdown SHA。没有因此修改队列或生成新 id。
- 初次源码检索使用了不存在的 `agent/src/reflex/selection.ts`，rg 返回 IO error。随后用 `rg --files` 定位实际文件 `agent/src/hand/screens/selection.ts`。这属于材料定位错误，没有生产测试失败或产品修复。

import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def power_map(entity):
    return {p.get('power_id'): p.get('amount') for p in entity.get('powers', [])}


def state_view(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'],
        'ts': row.get('observed_ts', row.get('ts')), 'floor': run.get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')),
        'max_hp': player.get('max_hp', run.get('max_hp')),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': power_map(player),
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'),
                  'upgraded': c.get('upgraded'), 'cost': c.get('energy_cost'),
                  'text': c.get('resolved_rules_text')} for c in combat.get('hand', [])],
        'enemies': [{k: e.get(k) for k in ['index', 'monster_id', 'name', 'current_hp',
                                         'max_hp', 'block', 'intents', 'move', 'is_alive']}
                    | {'powers': power_map(e)} for e in combat.get('enemies', [])],
        'potions': [p for p in run.get('potions', []) if p.get('occupied')],
        'selection': state.get('selection'),
    }


def main():
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    report = []
    for entry in manifest:
        path = HERE / 'evidence' / (entry['stream'] + '.evidence.jsonl')
        counts = collections.Counter()
        digest = hashlib.sha256()
        handles = {}
        try:
            with path.open('rb') as inp:
                for encoded in inp:
                    digest.update(encoded)
                    item = json.loads(encoded)
                    source = item['source']
                    if source not in handles:
                        handles[source] = open(source, 'rb')
                    handle = handles[source]
                    handle.seek(item['offset'])
                    raw = handle.read(item['bytes'])
                    assert hashlib.sha256(raw).hexdigest() == item['sha256']
                    assert json.loads(raw) == item['row']
                    assert item['offset'] + item['bytes'] <= entry['source_size']
                    counts[item['run_id']] += 1
        finally:
            for handle in handles.values():
                handle.close()
        assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
        assert digest.hexdigest() == entry['output_sha256']
        report.append({'stream': entry['stream'], 'checked_rows': sum(counts.values()),
                       'source_size': entry['source_size'], 'counts': dict(counts),
                       'offset_bytes_sha_json_equal': True})
    (HERE / 'raw-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    views = []
    with (HERE / 'evidence/states.evidence.jsonl').open() as inp:
        for line in inp:
            views.append(state_view(json.loads(line)))
    (HERE / 'state-views.jsonl').write_text(''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in views))
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()

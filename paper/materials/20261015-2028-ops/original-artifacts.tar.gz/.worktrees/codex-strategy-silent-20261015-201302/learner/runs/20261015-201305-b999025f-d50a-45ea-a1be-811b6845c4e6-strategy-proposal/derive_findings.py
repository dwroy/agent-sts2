import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract', 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def load(stream):
    return {r['line']: r for line in (HERE / 'evidence' / (stream + '.evidence.jsonl')).open()
            if (r := json.loads(line))}


states = {r['line']: r for line in (HERE / 'state-views.jsonl').open() if (r := json.loads(line))}
decisions = load('decisions')
sl = load('sl-attempts')
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})


def enemy(line, name):
    return next(e for e in states[line]['enemies'] if e['name'] == name)


def damage(start, end):
    return sum(e['current_hp'] for e in states[start]['enemies']) - sum(e['current_hp'] for e in states[end]['enemies'])


def option(line, key, question='plan'):
    return json.loads(decisions[line]['row']['questions'][question]['criteria'][key])


for stream in json.loads((HERE / 'evidence/evidence-manifest.json').read_text()):
    for item in load(stream['stream']).values():
        assert extract.run_identity(item['row']) == item['run_id']
        if stream['stream'] == 'states':
            run = item['row']['state']['run']
            assert run['character_id'].lower() == 'silent' and run['ascension'] == 10

check('NHA首试T1实损', states[283391]['hp'] - states[283397]['hp'], 1)
check('NHA末试T1实损', states[283502]['hp'] - states[283507]['hp'], 7)
check('NHA首试T1已结净伤', damage(283391, 283397), 8)
check('NHA末试T1已结净伤', damage(283502, 283507), 24)
check('RC首试T1实损', states[285315]['hp'] - states[285321]['hp'], 4)
check('RC末试T1实损', states[285491]['hp'] - states[285497]['hp'], 8)
check('RC首试T1已结净伤', damage(285315, 285321), 30)
check('RC末试T1已结净伤', damage(285491, 285497), 23)
check('RC首末T1同指纹', decisions[279021]['row']['fingerprint'] == decisions[279197]['row']['fingerprint'], True)
check('RC两候选均24/24失败', all('dead within 5 turns in 24/24' in option(279197, k)['rollout'] for k in ['plan1', 'plan4']), True)
check('RC普通生存者施放前手牌', [c['id'] for c in states[285414]['hand']], ['SURVIVOR', 'STRIKE_SILENT'])
check('RC普通生存者施放后空手', states[285415]['hand'], [])
check('RC真实激光对格挡', [sum(i.get('total_damage') or 0 for i in enemy(285415, '火箭')['intents']), states[285415]['block']], [57, 7])
check('P74弃牌前当前资源', [states[284817]['hp'], states[284817]['block']], [1, 16])
check('P74合法弃牌四项', list(decisions[278543]['row']['questions']['pick']['criteria']), ['card0', 'card1', 'card2', 'card3'])
check('P74精确切击当前伤害受手牌影响', '每有一张牌' in option(278543, 'card2', 'pick')['text'], True)
check('P74真实弃掉精确切击', 'PRECISE_CUT' not in [c['id'] for c in states[284818]['hand']], True)
check('P74实际终态', [states[284821]['hp'], enemy(284821, '盛碗虫（卵）')['current_hp']], [0, 2])
check('P74石眩晕与卵攻击同时成立', [enemy(284821, '盛碗虫（石）')['intents'][0]['intent_type'], enemy(284821, '盛碗虫（卵）')['intents'][0]['total_damage']], ['Stun', 8])
check('P74火焰真实扣血及滑溜', [enemy(284630, '墨影幻灵')['current_hp'] - enemy(284631, '墨影幻灵')['current_hp'], enemy(284631, '墨影幻灵')['powers']['SLIPPERY_POWER']], [1, 7])
check('P74触媒与滑溜两次毒结算', [enemy(284635, '墨影幻灵')['current_hp'] - enemy(284636, '墨影幻灵')['current_hp'], enemy(284636, '墨影幻灵')['powers']['SLIPPERY_POWER'], enemy(284636, '墨影幻灵')['powers']['POISON_POWER']], [2, 4, 10])
check('P74无滑溜12毒实际扣23', enemy(284658, '墨影幻灵')['current_hp'] - enemy(284659, '墨影幻灵')['current_hp'], 23)
check('P74赢战仍耗44血', states[284730]['hp'] - states[284765]['hp'], 44)
check('P74下一战实入口9血', states[284766]['hp'], 9)
check('P74召唤复活21血', [enemy(284748, '寄生惧魔')['current_hp'], enemy(284749, '寄生惧魔')['current_hp']], [0, 21])
check('P74T2及T4损血', [states[284739]['hp'] - states[284744]['hp'], states[284749]['hp'] - states[284754]['hp']], [20, 24])
check('G33两候选挡与伤确有差额', [[option(277909, k)[v] for v in ['block_gained', 'damage_dealt']] for k in ['plan1', 'plan2']], [[18, 75], [10, 107]])
point = sl[995]['row']['explore']['points'][0]
keys = [v for k, v in point['canon'].items() if k.startswith(('余像+, 闪亮', '闪亮登场+, 余像+, 防御, 打击 -> 女王'))]
check('G33旧排序键冲突', len(keys) == 2 and keys[0] == keys[1], True)
g_attempts = [r['row'] for r in sl.values() if r['run_id'] == 'G33HU22H2543' and r['row']['floor'] == 48]
check('G33六试未先打余像', [next(p for p in x['explore']['turns'][0]['plays'] if not p.startswith('potion:')) for x in g_attempts], ['DRAMATIC_ENTRANCE+'] * 6)
check('G33末T8三牌格挡', [states[n]['block'] for n in [284404, 284405, 284406, 284407]], [0, 5, 10, 12])
check('G33末T8余像实际层数', states[284407]['powers']['AFTERIMAGE_POWER'], 2)
check('G33末T8完整需损及存活差', [31 - states[284407]['block'], 31 - states[284407]['block'] - states[284407]['hp'] + 1], [19, 8])
check('BTS醒虫睡层按实帧变化', [enemy(n, '熟睡甲虫')['powers'].get('SLUMBER_POWER', 0) for n in [286148, 286149, 286150, 286152]], [3, 2, 1, 0])
check('BTS甲虫末T4完整需损及存活差', [22 - states[286173]['block'] - states[286173]['powers']['PLATING_POWER'], 22 - states[286173]['block'] - states[286173]['powers']['PLATING_POWER'] - states[286173]['hp'] + 1], [16, 3])
check('BTS甲虫力量按实帧成长', [enemy(n, '熟睡甲虫')['powers']['STRENGTH_POWER'] for n in [286163, 286170]], [2, 4])
check('BTS换线3/4预测保留其失败样本', 'dead within 5 turns in 1/4' in option(279854, 'plan2')['rollout'], True)
check('BTS原计划与重规划不同', decisions[279852]['row']['chosen'] != decisions[279854]['row']['chosen'], True)
check('RC呼唤自损与毒杀分账', [states[285095]['hp'] - states[285096]['hp'], [c['id'] for c in states[285095]['hand']].count('BECKON'), len(states[285096]['enemies'])], [6, 1, 0])

resource_pairs = [(283284, 283286), (283322, 283324), (283387, 283389), (283916, 283963),
                  (283964, 283966), (283967, 284012), (284158, 284160),
                  (285249, 285251), (285260, 285262), (285266, 285304), (285311, 285313)]
resource_changes = [{'run': states[a]['run'], 'floor': states[a]['floor'], 'lines': [a, b],
                     'before': states[a]['hp'], 'after': states[b]['hp'],
                     'net': states[b]['hp'] - states[a]['hp']} for a, b in resource_pairs]
(HERE / 'material-checks.json').write_text(json.dumps({'checks': checks, 'count': len(checks), 'resource_changes': resource_changes,
    'scope': '仅核原始材料、局部算术和记录身份；没有运行生产求解器、tsc、vitest、模拟池或模型请求。'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks': len(checks), 'resource_changes': resource_changes}, ensure_ascii=False))

# 静默猎手策略提案批次报告

记录时间：2026-10-15T20:25:57+08:00。

本批已完成十项派发提案的独立核证，全部 waiting；没有新增源码、策略参数或知识库修改。可隔离的投斧首牌身份、普通生存者单弃消费等窄问题已有实际 live 源码，宽项缺失的联合回放、累计收益或受控整战数据仍未补齐，不将子项实现当父项完成。没有本批提交、合入、行为版本或 shipped 登记。

## 身份与基线

- task=strategy-proposal，character=silent，batch=20261015-201302-strategy-proposal。
- 完整 base：`ff0a2c35f7bf0d92ffca1d048de14fbd5fce3943`。开工 git status 干净；对应批次角色、工作树、十个 proposal_ids 均匹配，无 proposal_repair、research_request 或 implementation_request。普通专题条件不匹配，因此不读取专题 work_spec 或其他请求。
- 已执行 `git merge --no-edit main`，结果 Already up to date。HEAD 保持 base。运行结束时再核工作树/HEAD，不将其后的 main 变化混入证据。
- runs：NHA2KW0RB7VP,P74C04AEPL1F,G33HU22H2543,RC61MFQM63Y6,BTSRF7JL1W1Y。runs.jsonl 原行591–595均明确 SILENT/A10、五局败局。每局的旧 code 带 dirty，完整当时源码未冻结，不把当前源码冒作旧运行树。
- 163条 brain 记录均为 engine=codex/model=gpt-6.1-sol/effort=high；五条 run-config 对应相同历史设置。runs 汇总仍有旧 deepseek_calls 字段，不据汇总字段改写逐请求身份，也没有审计本次学习者原生会话或给五局新增纯引擎战绩结论。
- 本人独立完成，没有派下级 agent，没有运行 play 或访问网络。

## 原始证据与验证范围

提取入口为本树 learner/extract_evidence.py，显式读取 run_id/state.run_id/fingerprint.run/run；冲突身份拒收，正文提及不当所属局。原件与冻结边界见 evidence/evidence-manifest.json；逐字节读回见 raw-verification.json。各流独立抓取时日志可继续追加，因此 source_size 是逐流截点，不宣称全流同一时刻快照。

| 流 | 本批行数 | 冻结 source_size |
|---|---:|---:|
| states | 3238 | 13128332825 |
| decisions | 3138 | 1653033281 |
| sl-attempts | 31 | 40852910 |
| run-config | 5 | 1774491 |
| run-plans | 26 | 8152112 |
| brain | 163 | 598667529 |
| runs | 5 | 336816 |
| fight-plans | 0 | 2233957 |

共6606行全部按原 offset/bytes/SHA/JSON读回相等并复核显式局身份；3238条状态均核本角色A10。源文件 states/decisions各有2条全流无效JSON，brain有1条，保留计数；不拿无效行猜其所属局。fight-plans 在本次2233957字节截点对这五局选中0行，只说明此截点未选到，不推断原日志绝对缺失。run-plans正确按顶层run提取，选中26行。

材料检查共38项全部通过，见 material-checks.json、derive_findings.py、material-checks.log；这是原帧算术/身份检查，不是生产测试、自测、撤源码负控、整战模拟或胜率证明。

## 直接复核结论与反例

1. NHA F33首/末T1同30血：s283391→283397实损1、净扣敌8；s283502→283507实损7、净扣敌24，挡14→8。换线多16伤同时多损6血。六试同属一局，后续目标/抽弃不同且无替代胜局，不足确定SL/终局新门槛。F24/F27/F32实际各回24，之后仍低血进战；未来火与存档恢复分账。
2. P74 F23第4试T3：d278542原计划生存者/紧勒打卵/毒雾+/精确切击预测零损；d278543四个合法选项都在，精确切击当前0费7伤且文本明确随手牌变动。s284817为1血16挡，弃后精确切击离手；d278544重算−7。s284821石虫已眩晕、卵毒后剩2仍8攻、玩家0。首试弃同卡但卵已在T2退出是原反例，不能宣布保留分支实盘获胜。
3. P74 F22：53→9获胜后以9血接F23；T2/T4实损20/24，寄生T3为0、T4回21。主怪最终消失的中间来源缺帧。F17火焰只扣1且滑溜8→7；T2毒12在滑溜6与普通触媒1下仅扣2、余10毒/4滑溜；T8无滑溜12毒扣23。局部兑现支持逐来源核证，不支持新药价或统一杀序。
4. G33 F48 T1：d277909的余像先/闪亮先候选分别18/10挡、75/107伤，sl995/996保存的旧canon相同；六试实际首张卡均闪亮登场。候选不是执行，未见余像先打完整整战。末T8实际两层余像，三牌挡0→5→10→12；31攻对12挡与12血完整需损19，存活差8，不能把上限截断的12实扣当完整需损。F31赢战83→46、F32回30、F33赢战76→17，后战资源影响存在，替代路线因果未知。
5. RC F33首/末T1同指纹、52血与同瓶格挡药：实挡16/12、损4/8、扣敌30/23，d279197两候选均24/24失败。触媒增加毒结算确有兑现，但后轮没有控制，不能推出固定能力优先或保血优先。第3试T4 s285414仅生存者与打击，下一帧手空、7挡、57激光，不沿用虚构最后攻击的朝向。F17 T11手持呼唤8→2后毒杀敌人，6自损不能归敌攻击或删除。
6. BTS F31睡层3→2→1→0，醒后T2/3/4攻击18/20/22、力量0/2/4；末T4的14血、5牌挡和1覆甲对22，完整需损16、至少差3血。d279852抽前计划与d279854重规划不同，后者原本就是3/4胜、1/4死且plan2/4并列。一次真实死亡不证明该概率失配；缺原逐样本抽序和动作配对，不能重拟权重。

这些局部结论与旧提案的限制一致，没有新增应替代旧经验的游戏规则。本批不重跑旧全历史109/110/112/113局统计，不搬用其他角色知识，不将同局多次SL扩充为独立训练或留出样本。

## 当前源码与实际live祖先

冻结读取的live为 `fe6462651b593b9831581c088deface9957a404f`，与base核18个源码/固定测试叶，14个逐字节相同。其余card-model.ts、passive-pieces.ts、sl/explore.ts、sl/controller.ts只保留Roy/Dai历史注释差，精确patch见 live-base-comment-diff.patch。没有为对齐而改写叶，也没有运行转译或宣称生产全检通过。

- `e784dd9f043bf87c29109573f48975f9903280d3`：投斧首牌身份的真实源码，已核为base/live祖先；当前explore.ts保留首牌字段、unknown边界、药水不消费首卡及canon/cards/loose处理。只覆盖bc4b92项的窄子项。
- `bf423c173d3be348a4ad714e1d26516df619ff41`：普通生存者无绷带时的强制单弃消费源码，已核base/live祖先；当前turn-solver.ts移除唯一后继、多选保持未知。只覆盖3f823/df375等项的窄子项。
- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：已有真实live祖先源码同步；当前selection.ts与silent-discard-facts.ts提供条件性计划失效/保留手牌快照，silent-sl-resource-comparison.ts提供当轮原线/替线预测对照，标execution=unverified。快照明确不承诺动态后继伤害、格挡、HP与胜负，资源比较也没有累计成长和完整执行消费者链。
- 当前paelsLegionPreview、vambraceArmed及silent-opening.ts均有限定条件，不能因局部函数存在把未验证组合标成完成；本批也未证明新的可隔离确定数值bug。

以上是已有实现证明，十项原范围均未整体满足，因此本批不报duplicate或implemented，不把既有经验shipped当源码验收。

## 逐项处置

| 原 id | 状态 | 本次未实现原因 |
|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | waiting | NHA同首手换线已核多16伤、多损6血；缺跨重规划完整实线、能力累计兑现及同条件后轮/路线分支，不能确定新SL或终局HP门槛。 |
| silent-proposal-47be799a87af03be | waiting | P74四个合法弃牌选项和精确切击离手后的死亡已核；当前计划失效提示/手牌快照只覆盖子项，缺四分支动态伤害、目标、后继与生存结果的联合生产回放。 |
| silent-proposal-3a5274da3c42672a | waiting | 召唤复活21血、赢战耗44血、滑溜下火焰仅1伤及毒扣2/23已核；缺召唤/复活、一次格挡翻倍与连续用药联合回放，主怪末次归零中间来源仍缺帧。 |
| silent-proposal-bc4b92d590f2c4ce | waiting | 投斧首牌身份和普通单弃消费已有真实live源码；宽项仍缺跨重规划完整归属、余像累计兑现与动态弃牌分支的联合消费者验证。 |
| silent-proposal-f52fbbab4dccc3b4 | waiting | G33的F31耗37/F33耗59及P74的F22耗44后9血接战已核；缺分源消费者账及同条件路线、休息、SL和保药整战分支，不能从净血差拟合因果HP价格。 |
| silent-proposal-10f37c0edd3d24a6 | waiting | 尖啸临时减力、触媒/滑溜、余像与卡牌挡及开场净扣血有局部实帧；缺完整遗物集合、持续能力、牌挡/被动挡/翻倍及回复的联合生产回放和独立校准。 |
| silent-proposal-3f82387e2e179703 | waiting | RC同指纹T1替线实少7伤、多损4血且两候选24/24失败已核；缺同抽序、同预算整战对照和累计能力收益，不足调整保血/铺能力排序。 |
| silent-proposal-aee21084c991abd3 | waiting | BTS醒虫睡层、力量成长和T4需损16/至少差3HP已核；原逐样本抽序/动作及实际线路配对回放未记录，一次死亡与3/4预测并存不足证明模型偏差或校准新权重。 |
| silent-proposal-df37594e9b12debf | waiting | 普通单弃取消唯一后继已有live源码；宽项仍缺跨重规划完整执行归属、能力累计与呼唤自损的联合消费者验收。 |
| silent-proposal-42e81c83b2e1e56b | waiting | RC实际三火回63及F29赢战耗31、F32到52血已核；缺回复/药槽/存档事件完整分源消费者账和同条件后战反事实，不能确定路线或终局HP价格。 |

每项证据局号/层/回合、原Markdown指纹、全部既有账本id、反例、预期和后续验证均见本批proposal.md。保留待新证据重派；没有领取第十一项或创建重复代码提案id。

## 账本、测试与交付边界

只经根目录 learner/ledger.py update 给32个既有静默条目追加本批proposal/report去处与waiting理由，by=learner:strategy-proposal；命令输入、stdout和原始追加offset/bytes/SHA保存在本目录。没有新游戏结论可add，因此不造新proposed条目，也不把已shipped旧条目降级；claim/证据/first_run/prior/status/version等保护字段保持原样。原专用提案id沿CLI既有登记使用，不重复add或手改队列。

tsc=null、vitest=null、cases=null；没有源码改动，所以没有撤源码失败/恢复通过、提交、合入提交或新版本，不启动live合并锁流程或双上线通知。未向Roy/ops发送消息；本报告与最终JSON供原调度完成事件交运维核实。没有宣称自然消费者验收、经验本批入库或父要求关闭。

准备过程的KeyError和错路径rg原件/修正见preparation-failures.md；初始队列最后事件快照保留在dispatched-proposals.json，折叠结果另存folded-proposals.json。所有原失败、旧报告、原Markdown和本批材料保留。

最终机械读回、账本追加核验与gitleaks扫描回执见final-verification.json（生成后读回）。实际结果以该文件及result.json为准。

proposal绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-201302/learner/runs/20261015-201305-b999025f-d50a-45ea-a1be-811b6845c4e6-strategy-proposal/proposal.md

report绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-201302/learner/runs/20261015-201305-b999025f-d50a-45ea-a1be-811b6845c4e6-strategy-proposal/report.md

# 策略提案批次完成报告

记录时间：2026-10-18T13:20:02+08:00。
批次：20261018-130525-s2-strategy-proposal；角色：silent；任务：strategy-proposal。
base/HEAD：`9d907456dc4af1014aa7896a980fe4a15d79c715`。
取证时live：`acfd63aaa8f664ca6f81a025cf8ebf25883531a9`。

十项已领取提案均完成核证并保留waiting；无新源码、知识、经验参数或生产规则修改，未提交、未合入、未分配版本。缺失证据逐项保留，等待新局重派；未把已有子实现登记成整项duplicate/implemented，未登记shipped。

## 派发与范围

开工git status干净；普通批次git merge --no-edit main返回Already up to date，HEAD未变。本批reason=proposal，有十个proposal_ids，无proposal_repair/research_request/implementation_request；普通专题请求的batch不同，故不承接其work_spec、不扩题。保存dispatch.json、assigned-current.json及原队列行offset/bytes/SHA。

只分析派发的五个Silent A10旧局。run-identities.json逐条核runs.jsonl角色、进阶、结束时间和完整原行指纹。启动源码均有dirty知识记录，未复原当时全部移动表/知识字节，不把当前源码冒作旧dirty树；旧引擎统计保持来源，未改写成当前模型对局。SL不是独立局，旧记录重读不新增support/repeat或样本数。

## 逐项处置

| 提案 | 关联账本 | 处置及缺数据 |
|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | silent-0019, silent-0020, silent-0065, silent-0264, silent-0079 | waiting：缺完整候选执行归属和独立SL校准；同局即时损血1/7与净扣8/24不能拟合新门槛。 |
| silent-proposal-47be799a87af03be | silent-0205 | waiting：四个合法弃牌分支的动态牌面、触发、目标及续步剩血未联合核证；保留精确切击后的整战未实打。 |
| silent-proposal-3a5274da3c42672a | silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006 | waiting：已有逐敌与滑溜等子模型；缺F22主体归零完整帧、召唤结算及跨战保药的联合验证，未定位新确定失配。 |
| silent-proposal-bc4b92d590f2c4ce | silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266 | waiting：投斧首牌身份及普通生存者唯一弃牌已有live子实现；跨重规划整线、余像累计兑现和全分支弃牌仍缺验证。 |
| silent-proposal-f52fbbab4dccc3b4 | silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064 | waiting：实际回复和胜战消耗可分账；缺同条件替代路线、休息或保药后继及完整召唤实体轨迹。 |
| silent-proposal-10f37c0edd3d24a6 | silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069 | waiting：子机制已有模型且无新确定差额；未知组合、恢复复活顺序及求解到终局的联合回放与独立校准未完成。 |
| silent-proposal-3f82387e2e179703 | silent-0079, silent-0027, silent-0065, silent-0080, silent-0088 | waiting：实损4/8和净扣30/23成立，但首末题面分别3轮2样本与5轮24样本；缺同预算完整替线和独立SL校准。 |
| silent-proposal-aee21084c991abd3 | silent-0128 | waiting：抽弃前后已换线且推演范围不同；缺最终执行线逐样本后继和独立校准，单次3/4预测下死亡不足改权重。 |
| silent-proposal-df37594e9b12debf | silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268 | waiting：唯一强制弃牌已有live子实现；多选可达性、实际朝向和跨重问累计能力/呼唤终局价值尚未联合验证。 |
| silent-proposal-42e81c83b2e1e56b | silent-0019, silent-0020 | waiting：五次实休105、二幕三次63及52HP入口已核；缺同条件路线、休息、保药后继和逐来源消费者验收。 |

每项的证据局/层/回合、旧规则、预期行为、反例、验证与回退见同目录 [proposal.md](proposal.md)。原十份Markdown逐SHA核对，保存在original-proposals/，没有覆盖原件或重复创建id。

## 原始证据与数值核对

| 流 | 选中原行 | source_size | 全源坏行 |
|---|---:|---:|---:|
| states | 3238 | 14336435517 | 2 |
| decisions | 3138 | 2543433050 | 2 |
| sl-attempts | 31 | 47936687 | 0 |
| run-config | 5 | 2092326 | 0 |
| run-plans | 26 | 9343420 | 0 |
| brain | 163 | 819427187 | 2 |
| runs | 5 | 372665 | 0 |
| fight-plans | 0 | 2233957 | 0 |

八流总计6606行，逐原source偏移重新读取并核bytes、SHA、JSON、显式归局和输出SHA，见evidence-verification.json。各流是独立截点，不冒原子快照。states/decisions/brain各2条全源坏行未猜所属局；fight-plans零选中只解释该截点，不断言源缺失。

NHA F33首末同首手实损1/7、端点敌HP净扣8/24；RC F33首末实损4/8、净扣30/23；P74 F23末T3为1血16挡对石16加卵8，弃精确后卵毒后剩2而实死。精确牌面随手牌从5变7，不当固定后继伤害。BTS F31抽弃后实际候选已改变，醒虫后轮20/22攻击、力量2/4与覆甲分源。case-verification.json的12项断言仅核固定日志字段/算术，不是tsc、vitest或模拟测试。

实际HEAL合计：NHA120、P7442、G33133、RC105、BTS42，逐次来源见rest-summary.json。RC二幕三火63与52HP入口已兑现；G33五休与四锻造分开。SL恢复、事件、幕间、战内药与未来营火没有混算，未用这些观察拟新路线或留药价格。

原提案口径限定：RC首试279021为3轮2样本、该候选0/2死亡，B2 87/600受时限；末试279197为5轮24样本。末试同题original/replacement均24/24不表示首末实线均5轮24/24；末题original还是朝火箭不喝药的另一候选。既有该id历史waiting也已有预算不同限定，原文不改。本报告需随处置交运维读回此限定，不将局部比对宣传为受控整战结论。

## 源码与消费者边界

source-pins.json、feature-source-provenance.json保存实际Git blob、逐叶SHA/原字节、末改/逐行源码commit及live祖先验证。已存在的投斧首牌身份、普通生存者唯一弃牌消费、弃牌计划/保留手牌提示、候选审计、单动作回执均只证明对应子项。base/live既有rollout功能差和署名文字差保留在base-live-source.patch；不冒整棵当前live或历史dirty开局等价。首次不存在sim/fight.ts路径探针记exists=false，非产品bug。

离线窗口审计首次命令从根解析tsx失败（五局退出1）；原空输出、stderr及空初稿summary保留在selection-audits/和selection-audit-summary.json。修正为现有agent/node_modules/tsx/dist/loader.mjs入口后，同一冻结输入五局分别退出0，见selection-audits-v2/与selection-audit-summary-v2.json。没有安装依赖或改源码。

| 局 | 候选片段 | 重问替代 | 结束回合请求 | 跨回合/房间/尝试 |
|---|---:|---:|---:|---:|
| NHA2KW0RB7VP | 41 | 23 | 18 | 0 |
| P74C04AEPL1F | 26 | 6 | 20 | 0 |
| G33HU22H2543 | 55 | 10 | 45 | 0 |
| RC61MFQM63Y6 | 68 | 35 | 28 | 5 |
| BTSRF7JL1W1Y | 52 | 13 | 37 | 2 |

合计242候选片段（87重问、148结束请求、7边界变化）和212个工具观测轮窗口，均不是新增独立样本。完整候选结果和实际rollout最优认证按工具设计为null；0认证不代表242次新增失败，也不由固定null占位反推模型缺陷。离线关联/材料读回不当自然消费者采用、机制联合校准或胜率收益。

## 记录、检查与上线

无源码改动，tsc/vitest/cases均null；没有撤源码失败/恢复通过实验，不制造成功测试。没有执行live锁、刷新提交、合入、版本、部署双通知或shipped；其他角色行为未变。首轮审计入口失败保留，随后离线读回成功不冒生产测试。

账本已只经根learner/ledger.py update追加32个关联条目的本批proposal/report链接与限制备注，科学字段和既有状态/版本/effect保留；不重复写历史复盘、add、support或repeat，不把旧shipped退成proposed。队列最终处置交proposal_results，不手改根请求或队列。CLI update实际退出0、唯一追加32条；原字节prefix、科学字段及非proposal去处保持，根ledger check退出0。原输入、追加行offset/bytes/SHA及结果保存在ledger-update.log、ledger-append-receipt.json和ledger-check.log。

无生产修改，无生产回退动作；后续若获得可隔离差额，沿原id的固定回归、撤修复对照、自测/live及通知流程实施，不以本报告关闭父要求。

最终机器回报见result.json。报告和提案均在本批learner/runs目录，工作树维持tracked/index干净。

## 完成核验

2026-10-18T13:21:22+08:00：32条CLI追加与根账本检查均退出0，未改旧科学字段。gitleaks 8.30.1对当时已生成的本批材料扫描退出0、报告[]，原输出保留于gitleaks.log/gitleaks-report.json。最终HEAD等于base、tracked/index与未跟踪状态均干净，base.diff.patch为空；最终机器结果见result.json。无源码提交/合入/版本或测试成功声明。

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOMS = {'CA5KE8GFJ9X2': {13}, '61E2QS63Y9WU': {17, 23},
         '5PM6JAQG6FNQ': {33, 39}, 'DUZUBAJ3A8GP': {30},
         'VLZ6CCT8AQ0A': {35, 43, 45}, '8JRE1C4H4Z2W': {33}}


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}


def card(raw):
    return {'id': raw.get('card_id'), 'upgraded': raw.get('upgraded'), 'cost': raw.get('energy_cost'),
            'vars': {v.get('name'): [v.get('base_value'), v.get('current_value')] for v in raw.get('dynamic_values', [])}}


rows = []
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    item = json.loads(line)
    raw = item['row']
    s = raw['state']
    run = item['run_id']
    info = s.get('run') or {}
    c = s.get('combat') or {}
    if info.get('floor') not in ROOMS[run] or not c:
        continue
    p = c['player']
    rows.append({'run': run, 'source_line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
                 'sha256': item['sha256'], 'ts': raw.get('ts'), 'observed_ts': raw.get('observed_ts'),
                 'floor': info['floor'], 'turn': s.get('turn'), 'screen': s['screen'],
                 'hp': p['current_hp'], 'block': p['block'], 'energy': p['energy'], 'powers': powers(p.get('powers')),
                 'deck_upgraded': sum(bool(c.get('upgraded')) for c in info.get('deck', [])),
                 'hand': [card(c) for c in c.get('hand', [])],
                 'enemies': [{'id': e['enemy_id'], 'hp': e['current_hp'], 'block': e['block'],
                              'powers': powers(e.get('powers')), 'move': e.get('move_id'),
                              'attacks': [[a.get('damage'), a.get('hits')] for a in e.get('intents', []) if a.get('damage') is not None]}
                             for e in c.get('enemies', [])]})
(OUT / 'state-windows.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
groups = []
for r in rows:
    key = [r['run'], r['floor'], r['turn']]
    if not groups or groups[-1]['key'] != key:
        groups.append({'key': key, 'first': r, 'last': r, 'frames': 1})
    else:
        groups[-1]['last'] = r
        groups[-1]['frames'] += 1
(OUT / 'turn-endpoints.json').write_text(json.dumps(groups, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'window_frames': len(rows), 'turn_groups': len(groups)}, ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


base = git('rev-parse', 'HEAD').decode().strip()
prior = OUT / 'source-pins.json'
live = json.loads(prior.read_text())['observed_live'] if prior.exists() else subprocess.check_output(['git', '-C', str(LIVE), 'rev-parse', 'HEAD']).decode().strip()
paths = [
    'agent/src/reflex/silent-apotheosis.ts',
    'agent/src/reflex/silent-apotheosis-reference.ts',
    'agent/src/reflex/card-model.ts',
    'agent/src/reflex/turn-solver.ts',
    'agent/src/reflex/rollout.ts',
    'agent/src/reflex/rollout-live.ts',
    'agent/src/reflex/combat-plan.ts',
    'agent/src/reflex/silent-selection-audit.ts',
    'agent/src/reflex/silent-selection-dispatch.ts',
    'agent/src/reflex/silent-hp-guard-audit.ts',
    'agent/src/reflex/jev/decision-projection.ts',
    'agent/src/hand/loop.ts',
    'agent/src/sl/explore.ts',
    'learner/lib/selection-execution.ts',
    'learner/lib/selection-turn.ts',
    'learner/lib/selection-terminal.ts',
    'learner/lib/selection-observation.ts',
    'agent/src/reflex/potion-mc.ts',
    'agent/src/core/decision-budget.ts',
    'agent/src/sim/route-projection.ts',
    'agent/src/hand/screens/rest.ts',
    'agent/tests/silent-apotheosis.test.ts',
    'agent/tests/silent-apotheosis-reference.test.ts',
    'agent/tests/silent-selection-audit.test.ts',
    'agent/tests/silent-selection-execution.test.ts',
    'agent/tests/silent-hp-guard-audit.test.ts',
    'agent/tests/silent-obscura-summon.test.ts',
    'agent/tests/silent-footwork.test.ts',
]
dest = OUT / 'source-pins'
dest.mkdir(exist_ok=True)
rows = []
for path in paths:
    raw = git('show', f'{live}:{path}')
    (dest / (path.replace('/', '__') + '.txt')).write_bytes(raw)
    current = ROOT / path
    last = git('log', '-1', '--format=%H', live, '--', path).decode().strip()
    row = {'path': path, 'live_commit': live, 'sha256': hashlib.sha256(raw).hexdigest(),
           'git_blob': git('rev-parse', f'{live}:{path}').decode().strip(), 'bytes': len(raw),
           'base_equal': git('show', f'{base}:{path}') == raw,
           'worktree_equal': current.read_bytes() == raw, 'last_modifying_commit': last,
           'last_commit_is_live_ancestor': subprocess.run(
               ['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', last, live]).returncode == 0}
    rows.append(row)
(OUT / 'source-pins.json').write_text(json.dumps({'base': base, 'observed_live': live, 'files': rows}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source-base-live.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
print(json.dumps({'base': base, 'live': live, 'files': len(rows), 'different': [r['path'] for r in rows if not r['base_equal']]}, ensure_ascii=False))

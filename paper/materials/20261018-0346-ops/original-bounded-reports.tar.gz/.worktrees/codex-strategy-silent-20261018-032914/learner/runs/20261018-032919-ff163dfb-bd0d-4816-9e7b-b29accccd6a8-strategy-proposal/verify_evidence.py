import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
results = []
for entry in manifest:
    output = OUT / 'evidence' / (entry['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    count = Counter()
    seen = set()
    source = Path('/home/dw/Projects/agent-sts2/logs') / (entry['stream'] + '.jsonl')
    with source.open('rb') as raw_source, output.open('rb') as evidence:
        for line in evidence:
            digest.update(line)
            item = json.loads(line)
            assert item['source'] == str(source)
            assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= entry['source_size']
            assert item['offset'] not in seen
            seen.add(item['offset'])
            raw_source.seek(item['offset'])
            raw = raw_source.read(item['bytes'])
            assert len(raw) == item['bytes'] and raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id'] in dispatch['runs']
            state = item['row'].get('state') or {}
            info = state.get('run') or {}
            if info:
                assert str(info['character_id']).lower() == 'silent'
                assert info['ascension'] == 10
            count[item['run_id']] += 1
    assert digest.hexdigest() == entry['output_sha256']
    assert {run: count[run] for run in dispatch['runs']} == entry['counts']
    results.append({'stream': entry['stream'], 'references_verified': sum(count.values()),
                    'source_size': entry['source_size'], 'counts': entry['counts'],
                    'output_sha256': digest.hexdigest(), 'offset_bytes_sha_json_identity': True})
result = {'kind': '材料一致性复核，非生产测试', 'total': sum(r['references_verified'] for r in results),
          'streams': results, 'global_invalid_lines': sum(m['invalid_lines'] for m in manifest),
          'invalid_lines_assigned_to_runs': False}
(OUT / 'evidence-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_references': result['total'], 'streams': len(results)}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
pins = json.loads((OUT / 'source-pins.json').read_text())
timestamp = (OUT / 'report-time.txt').read_text().strip()

dispositions = [
    ('89354805ee4d7e77', 'VLZ6CCT8AQ0A F35/T1、F43/T1–T5、F45/T1',
     '神化升级传播及施放归属',
     '已有普通神化和已观察升级配对子实现；仍缺跨重问、选牌、药水、SL与换战边界的实际施放持续归属及完整消费者校准，actual_cast_this_fight仍为null。',
     '普通神化与16种动态字段配对、特殊萎靡文本配对保留，未知组合不补值；另需可靠的实际施放/终止事件链，不能用持有、候选或升级手牌倒推完整施放归属。'),
    ('f2bfceddb1898dca', 'VLZ6CCT8AQ0A F45/T1、T4–T5；F43资源前置',
     '药水MC与非药候选共享预算',
     '缺同起点、同随机池、同总预算的MC先行与预留非药预算配对，以及候选稳定性随预算的曲线；d269748与d269754指纹不同，不能拿两问样本1→12当受控收益。',
     '保留MC/rollout成熟度、真实药效与逐敌缺口；先冻结求解输入、池、种子和原运行知识字节，再比较两种预算分配。不从707ms拟合新常量或药水持有价。'),
    ('283a164780d11e69', 'VLZ6CCT8AQ0A F35/T1、F43/T1–T5、F45/T1',
     '神化经验消费者补链',
     '与89354805ee4d7e77共享原神化证据，但原经验要求的实际施放归属和后继消费仍未闭环；已有局部源码不足将整项记duplicate，且不能只因同主题就关闭。',
     '沿两原id保留来源任务/经验链接，不另建重复提案；实际施放、后抽和模型覆盖须分账。复用已实现配对后，仍验证未知卡、属性组合与各重规划边界。'),
    ('ebbfe3b97548756d', 'VLZ6CCT8AQ0A F43/T2–T5、F45/T3–T5、F44；原15子项',
     '15种攻防、持续资源与路线休息联合校准',
     '本批可核局部敏捷/勒紧/毒/临时减力及资源事实，但缺15子项逐来源、持续期限、升级属性组合与战斗/路线/休息生产调用的联合校准，不能以若干窄修复覆盖全项。',
     '保持逐击力量、逐牌敏捷、专属挡、当前覆甲和毒结算分源；对15子项逐个固定实际调用输入，现有准确机制不重写，只有与自证帧不符的缺口才补代码。房间代价仍保留原样本门槛。'),
    ('e5b87be50f28f311', '8JRE1C4H4Z2W F33第1/3试T2、第2试T5、第6试T11',
     'SL、HP护栏与重规划执行审计',
     '已有候选、护栏、单动作回执、相邻观测和终局/整轮端点；本批离线读回58段候选均无完整执行归属。缺跨选牌、抽牌、重问和SL的持续候选执行认证及整线兑现，不据同盘局部差改探索阈值。',
     '复用已有三阶段候选、单动作回执与端点，不重复开发。后续认证须保留原指纹/尝试/完整动作和中断事件，零血实扣、显示入伤与因果收益分别列账；先保持选择不变。'),
    ('49632bc4878fb597', 'CA5KE8GFJ9X2 F13/T1–T5',
     '力量、敏捷、虚弱与独立成长',
     '加压0→4→8力与喷水11→15→19、弱后11/14可重核；但本批无正敏捷建立，缺力量逐击、正负敏捷、虚弱和独立成长的生产联合固定校准，单步法提交不能关闭复合请求。',
     '按本角色来源分项验证当前属性、每击修正、取整和后继成长；未取得的步法不补效果，不新增统一保血/输出权重。等待四路径同时可核的调用夹具。'),
    ('66532328a585941f', '5PM6JAQG6FNQ F33/T1–后继、F39第2试T2',
     '构筑组件持有与实际启动',
     '末试无毒冒泡实付1能零施毒可核，既有组件事实已分账；缺同起始HP/资源/构筑和完整抽序下不同启动顺序的受控整战比较及收益函数，不能从另一场建立组件后获胜拟合启动权重。',
     '持有、到手、支付、实际建立和后继结算分别记录。现有零毒条件和观测输出保留；若改变构筑/启动优先级，先比较完整同盘线路，并按局号而非SL次数分样本。'),
    ('43a76a31ba7bdcfa', '61E2QS63Y9WU F17/T5–T7',
     '吸取、负敏捷、毒与SL范围',
     '本局首试胜利及吸取后负2敏双防各3、毒17+16可核；缺同起始HP/构筑/完整抽序下另一条完整SL线路及生产配对，本局没有该场SL，不能验证换线偏好或扩大SL范围。',
     '保持吸取的玩家力敏/敌力、临时减力恢复和毒独立结算；SL规则变化须有同盘完整替代后继，不用首试胜利代替反事实。'),
    ('5264153a4a4b0e5c', '61E2QS63Y9WU F23/T1–T5，重点T4–T5',
     '召唤、航行成长与focus',
     '已有召唤子实现；A10本局航行后各实体力3→6、T4本体线47伤/15损和幻象余2可核，但缺召唤/航行/复现/退场全链生产校准及另一focus完整后继，不能据未选39伤/零损候选强制首杀。',
     '沿当前进阶读取数据库首个HP/伤害样本，保持全部目标选项、相同推演值并列。验证每实体成长及退出再归属，不从毛伤合计冒出击杀。'),
    ('bddfa690a84e03d0', 'DUZUBAJ3A8GP F30四试T1–T6，重点末试T4–T6',
     '睡层、醒来、眩晕与成长',
     '四试均败，睡3/2/1后T4醒、T5临减后T6回4力/22攻可核；缺伤害唤醒、眩晕接续和当前进阶成长的完整生产校准，以及同抽换序完整后继，不能拟合固定杀序或输出血价。',
     '按当前进阶和各实体睡层/覆甲/眩晕/临时恢复/成长分项冻结；22攻对1HP16挡只证此局面不足，四次相关失败不作四局独立训练或再试必胜证据。'),
]

results = [{'id': 'silent-proposal-' + suffix, 'state': 'waiting', 'reason': reason}
           for suffix, _, _, reason, _ in dispositions]
assert {r['id'] for r in results} == set(dispatch['proposal_ids'])
report = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-032914-strategy-proposal',
          'base': pins['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

table = ['| 原提案 | 证据局/层/回合 | 既有账本 | 处置及未完成原因 |', '|---|---|---|---|']
for suffix, evidence, title, reason, expected in dispositions:
    ident = 'silent-proposal-' + suffix
    table.append(f"| `{ident}`：{title} | {evidence} | {', '.join(assigned[ident]['ledger'])} | waiting：{reason} |")
matrix = '\n'.join(table)
proposal = f'''# 静默猎手本批十项原提案复核

时间：{timestamp}。来源任务/实现任务均沿原队列的 source_task → strategy-proposal；本批为20261018-032914-strategy-proposal。原始提案10份均按登记SHA256核同并保存为 `silent-proposal-*.original.md`。原id保留，无新CLI提案id。

本批结论：六局均是silent A10；10项均waiting。没有从本批得到足以改变新策略常量或认证整个复合请求已实现的证据。不创建源码提交、合入或版本。既有局部实现和旧经验保持；此处的等待不撤销旧机制事实，也不把其他原请求关闭。

{matrix}

## 各项预期行为与验证入口

'''
for suffix, evidence, title, reason, expected in dispositions:
    proposal += f"### {suffix}：{title}\n\n{expected}\n\n证据定位：{evidence}；账本：{', '.join(assigned['silent-proposal-'+suffix]['ledger'])}。未完成原因：{reason}\n\n"
proposal += '''## 反例、未知和拟合限制

- 神化在F35/F43实放，F45持有未放；不同敌人和资源不能拟合必打规则。F43同序帧只校准当轮8伤/1损差，未给整战胜负反事实。
- 8JRE末试T2保血换线延至T11仍死，反对把所有防御替换都判错；第1/3试T2同盘多12损换7伤也不证明原线能赢。0/24与5/24死亡不同，不因预计损失都封顶47而当并列。
- 5PM F33组件已建立并获胜，F39末试未建毒雾且向无毒目标冒泡；不同房间/资源/抽序不是可识别的启动因果对照。玩家HP采用已在旧账本更正的29，敌失落HP35，不能把两者混淆。
- 61E F17首试胜利不提供另一条SL胜线。F23未实打另一focus，不能将未选候选39伤/零损当成后续胜利。
- DUZU末试T4比首试多扣敌3但多损玩家2；四次同局失败不能拟合输出血价。末帧零HP后的能力清理不推定完整到期条件。
- 六局的原run-config均声明知识数据dirty，只列路径而不保存其完整字节；不从当前知识库复原原运行参数/随机池并冒称精确重放。读取当前源码只说明当前覆盖，不把新源码输出改写成原预测。
- 原始实盘已经用于发现/复核，不能称盲测。每个局号计一个独立样本；同局房间、回合和SL相关。未来验证应按局号及结束时间后移，进阶/敌人/模型覆盖分层，不用其他角色知识。

## 验证与回退

本批仅原材料复核和既有离线消费者读回：6,995原引用逐offset/bytes/SHA/JSON/run身份核同；17项材料算术复核；8JRE F33既有audit-selection入口读取232决策/233状态，58候选段、39可核整轮端点、1终局端点，但完整候选归属均null。它们不是生产tsc/vitest、不是源码消融、不是自然大脑采用或胜率验证。没有源码变更，所以不运行生产测试或撤源测试，结果均null。

后续发现有证据的新缺口，才按原提案固定输入、撤源码失败/恢复通过、原沙箱入口和live流程实现。无关角色维持原行为；回退对应新增源码提交，保留原证据、失败、账本和提案。当前无新代码可回退。既有Roy-2026-10-07-learning只授权修改，不提供游戏事实。
'''
(OUT / 'proposal.md').write_text(proposal)

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
stream_table = ['| 流 | 字节截点 | 本批所属记录 | 全源坏行 |', '|---|---:|---:|---:|']
for m in manifest:
    stream_table.append(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} | {m['invalid_lines']} |")

text = f'''# 本批策略提案处置报告

时间：{timestamp}。结论：10项全部waiting；无新源码/知识变更、提交、合入、版本或shipped。工作树HEAD/base保持 `{pins['base']}`，git merge --no-edit main返回Already up to date，git status --short为空。

## 身份与范围

根learn.json只取本批行并存 `dispatch.json`：task=strategy-proposal、character=silent、reason=proposal、worktree与题面一致，领取10个proposal_ids，没有proposal_repair、research_request或implementation_request。普通专题文件绑定的是20261010-150327，未匹配本批，因此未读取其他专题输入、不退换选题。根任务状态未改。

`run-identities.json`保存六局runs.jsonl的原字节定位：六局均silent/A10，分别结束于2026-10-07，未引入本批之外的对局、其他角色知识或预训练游戏结论。没有下级agent、模型/游戏调用或网络。当前观察live为 `{pins['observed_live']}`，后续若live推进不倒写本次固定源码身份。

## 原始证据与材料检查

{'\n'.join(stream_table)}

八流共6,995条所属原记录；`evidence/evidence-manifest.json`保存逐流截点、每局计数和输出SHA，逐行文件保存offset/bytes/SHA。`evidence-verification.json`已回读全部6,995原字节并核JSON/身份/计数/输出SHA。抽取使用共用extract_evidence.py，识别run-plans.run及各流run_id/state.run_id/fingerprint.run，不按正文提及归局，不接纳冲突身份。全源6坏行仅为全源扫描统计，未归到六局。fight-plans在本次2,233,957字节截点为0，仅说明此截点未选到所属记录，不能据此断言原日志缺失；本批未覆盖/改写旧报告或旧截点。

`state-windows.json`保存666个有界关键帧，`turn-endpoints.json`保存124个连续观测回合分组（只是观测分组，不冒称SL身份认证）。`decision-windows.json`保留8个原题。`fact-checks.json`的17项一致只是材料复算，未运行生产测试。

可复查的关键事实：

- VLZ F35/T1 s275564→275565：7→5能，防御5→8、打击当前7→10、匕首雨每击5→7、必备工具1→0；场外升级数1不变。F43/T1 s275679→275680同样实付2能、场外升级数4不变。d269706→269707同后序预测43伤/14损→51伤/13损，s275679→275687实敌254→203、玩家90→77。
- VLZ F45/T1 d269748：mc707ms、药样本1/12、rollout1轮1样本/best=null；d269754为药样本12/12、rollout5轮3样本，两问指纹不同。s275728→275729实能1→2、HP67不变；s275731只有普通神化/生存者，s275732手空，普通勒紧4/触媒1保持。F45未建立毒雾。T5 s275752→275754：8挡→20挡，83来袭经四段临减成59，32HP完整算术需损39；不是实扣39的观测，死亡HP被零截断。
- 8JRE F33第1/3试T2 d270216/d270282指纹逐字相同；s276208→276212玩家47→44、敌326→316，第3试s276274→276278玩家47→32、敌326→309，即多12损/多7当轮伤。d270282原/替换0/24与5/24死亡不同。第2试T5 d270264护栏候选16损43伤→4损25伤为预测差。末试s276433→276434实5→0、敌154→130，37攻/22挡的15差仅算术参考，不改记完整实损。
- CA5 F13/T1–T5 s273237–273269：喷水11/15/19，力量0/4/8，弱后11/14；未取得的步法不补正敏捷。终局2HP/10挡面对14，完整需损4，零血实际只扣2。
- 5PM F39第2试T2 s274379→274380：玩家29HP/0挡，能5→4，两敌HP35/72和能力均不变，尚无毒；与原账本silent-0009的玩家血29更正一致。F33建立组件后胜的事实只作不同场景限制，不能作F39的同盘对照。
- 61E F17/T5–T7 s273503→273508：吸取后力2→0、敏0→−2，双防各3；尖啸另使敌力2→−4、23攻→17，6牌挡+3覆甲后损8；毒17+16使敌67→34。F23/T4→T5 s273593→273596：本体76→41、幻象14→2，合47净扣、玩家25→10损15，幻象仍存，敌力3→6。
- DUZU F30末试 s274991–275023：睡3/2/1后T4醒；T5临减2→−4，T6恢复并成长至4力22攻。s275022为1HP16挡，完整算术需损6；本局四试失败，不是4个独立局号。

## 当前源码和消费者边界

`source-pins.json`固定28个相关源码/固定测试文件的Git blob、SHA256、字节数、最后修改提交及live祖先布尔，原字节以.txt保存于source-pins/，未保存整个仓库或可执行源码副本。`source-base-live.patch`保留base/live四叶差异，仅Roy/Dai归属注释差；不覆盖它们。`existing-source-ancestry.json`核以下8个旧源码提交均为所观察实际live祖先，但这些是已有子项，不是本批新fixes或整项duplicate：

- `772b839f8ada31664cb764ea9ad3bdb03da27f64`：普通神化已观察升级传播。
- `ba23ca693151fa8c6f7fe035e640dc30f05ccd75`：已观察致命毒药5→7的窄配对；当前神化配对最后修改。
- `3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17`：持有/候选/模拟升级参考；actual_cast_this_fight明确null。
- `bade647f9fe4c9103b40e2f26b26296692ad24b7`：单动作派发回执；state_effect_verified=false、whole_plan_executed/actual_turn=null。
- `a8b1f8be153fe4f3a34146117546c2178f2e446b`：HP护栏候选审计，actual_outcome=null，不认证实际省血。
- `cf72bd21148059f111f760cc98a727369e34a47e`：既有离线执行审计消费者及端点；完整候选结果保持null。
- `d8a2b0090ba8145c0b6d20bcae700006f01e2c79`：步法敏捷传播子实现，不覆盖全部力量/弱/成长组合。
- `1e076b173c6874cef4bf90fd13cd3eb33355827a`：胧光召唤子实现，不代表本批A10全链或另一focus已验证。

现有turn-solver会将神化传播到已知剩余牌/后抽，rollout会传播到draw/discard/retained；未知卡与未验证属性组合仍保留未知。不是完全没有神化模型，也不是所有传播已认证。现有MC样本及耗时诊断、战斗候选成熟度、实际资源和条件投影已有展示，本批不重复添加诊断，不用代码存在替代原运行输入/配对曲线。

通过既有命令 `node --import ./agent/node_modules/tsx/dist/loader.mjs learner/audit-selection.ts`，冻结本批8JRE/F33的232决策、233状态，无元数据排除，离线出口0；输入/输出和stderr保存在本目录。输出58段候选，整轮端点39/unknown11，终局端点1；所有候选完整执行结果均null。末轮d270441→270442保留第6试、5次重载、净HP−5、敌HP−24，显示37−22=15，但uncapped/causal/full_candidate都null。`offline-consumer-summary.json`保存计数。此读回仅证明既有离线消费者能读取本批材料，不是在线自然大脑采用、生产测试、策略改善或完整实现证明。

## 逐项处置

{matrix}

提案正文、各项预期行为/验证、反例、拟合与回退见本目录 `proposal.md`。原source_task、原经验和26个既有账本id保留。不创建重复id、不重复写历史复盘、不把原id间同主题当已上线duplicate。

## 记录、验证与交付口径

仅通过根learner/ledger.py update为26个既有silent条目追加本报告/提案链接与note；不新增support/repeat/反例，不改claim、first_run、prior、evidence、status、version或effect，不将既有shipped降回proposed，也不新增shipped。具体输入/CLI回执/前后保护字段复核另存本目录。

未改生产源码/知识，未提交或合入、未增eval版本、未发规则上线通知。tsc=null、vitest=null、cases=null；撤源码失败/恢复通过均未执行、不适用，不引用旧绿代替本批检查。17材料复算和离线工具exit0单列。初期数次只读源码定位用了不存在路径，已按rg --files更正，未改代码或将其当测试失败；原输出保留于会话，不冒称全程无失败。日志全源坏行6保留原计数。

运维交接：本批proposal.md为 `{OUT / 'proposal.md'}`；report.md为 `{OUT / 'report.md'}`。请沿原完成事件登记10个waiting及各自缺数据理由，保留新局后重派，不将报告、入队或局部祖先当implemented/shipped。无需live合并或生产补测。

最终机器回报另存 `report.json`。
'''
(OUT / 'report.md').write_text(text)

ledger = json.loads((OUT / 'ledger-before.json').read_text())
updates = []
for ident in sorted(ledger):
    pids = [p for p in dispatch['proposal_ids'] if ident in assigned[p]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261018-032914-strategy-proposal：原id ' + ','.join(pids) +
                            ' 本批复核waiting；仅补处置/原证据追溯链接，无新增support/repeat、源码、合入或shipped。具体缺数据见报告；既有窄实现不关闭整项。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in updates))
print(json.dumps({'proposal_results': len(results), 'ledger_links': len(updates), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

# 本批十个静默猎手原提案逐项核验

批次 20261017-014302-strategy-proposal；base a0e2fff7b979314585252a095ae0e20c8045a6ba。只消费本批十ID，不扩展其他队列或专题。原证据材料正在完成审计；以下是有待最终核验的初稿，最终以proposal.md/report.md为准。

### silent-proposal-34209e8b9f982e49

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：H1T1F8ML9FUE F47、F48 T1—T4。账本：silent-0243,silent-0020,silent-0019,silent-0021。

已核事实及反例：F47休息33→52；F48六试未胜、F49未到。F33已胜28HP，不能把有限推演直接写成必败。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-144110-experience-update/proposal-resources.md；SHA256：`f5b3ac55faa17184117fd0a9c5fdd0608c6b0587e44e26e888574873b78024e4`。本批逐字节副本为同目录 silent-proposal-34209e8b9f982e49.md。

处置：waiting。缺同盘替路线、留药和后场完整结局及时间留出，不能由末战败局拟药水持有价、终局权重或SL门槛。

预期行为及验证：保留既有权重；分别记录实饮、主动弃药、事件交换、SL恢复、实到回复，冻结完整候选与后场资源后再比较。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-015f25123c45671c

原任务：postmortem → strategy-proposal；角色 silent，已核进阶 A10。
证据：AD3QSC3P41JU F48 T11、F49 T1。账本：silent-0228,silent-0255,silent-0030,silent-0069。

已核事实及反例：F48退出15/空药→F49入房15→首手11；已见组合开场扣4，不能再扣一次。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261008-151301-postmortem/proposal-resources.md；SHA256：`a9826cae824dc9bc7b3df59449e00980bfa05ef01c326233624cdc2c6966e13c`。本批逐字节副本为同目录 silent-proposal-015f25123c45671c.md。

处置：waiting。开场完整组合窄项已有live源码ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8；缺从F48起的受控留药比较和独立联合校准，宽项继续等待。

预期行为及验证：沿现有同样本接续；后续冻结首战输入和随机种子，比较实饮收益、出口资源和次战可操作入口。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-01d7495835a3eb19

原任务：postmortem → strategy-proposal；角色 silent，已核进阶 A10。
证据：AD3QSC3P41JU F49 T1—T3。账本：silent-0079,silent-0028,silent-0011,silent-0048。

已核事实及反例：一线30直伤/损8，SL保血线21直伤/零损，多活到T3仍未胜。末轮rationale中的-2为预计剩血，3−(23−18)=−2。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261008-151301-postmortem/proposal-combat.md；SHA256：`9282fefa7c494597de6d0ddd65d725fb5e8f07abf9b538b9f46b001e78e3d93e`。本批逐字节副本为同目录 silent-proposal-01d7495835a3eb19.md。

处置：waiting。缺T1之后同抽序完整后继及抽牌重问至派发的完整归属；既有HP护栏8不能据本局重新拟定，预计剩血-2也不是预计损2。

预期行为及验证：保留护栏和SL；固定原答、SL替线、抽后重问及最终派发，分别验证本轮血价与完整后继。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-cb23be067a5f04c1

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：AD3QSC3P41JU F48 T6/T9/T10、F49 T2。账本：silent-0012,silent-0010,silent-0011,silent-0013,silent-0030,silent-0046,silent-0115,silent-0048,silent-0069,silent-0276。

已核事实及反例：F49四技能敌力3→15、来袭19→31，弱后23；18挡/3HP仍死。F48局部毒防兑现不等两场通关。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-153440-experience-update/proposal-modifiers.md；SHA256：`0c335abd90d0afe5853ed127053296ca9208c3cb81d66d7d193ea44100e8ac82`。本批逐字节副本为同目录 silent-proposal-cb23be067a5f04c1.md。

处置：waiting。毒雾、蜃景、臂甲、爆发尖啸和水盆已有局部接线；缺整组实际修饰条件的完整候选归属与受控后继，不能宣称联合校准或拟敏捷药留药时点。

预期行为及验证：保持模型已知边界；分开核实建层、实结毒、牌挡、末被动挡和临时力量；未知交互不外推。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-53ed69feeb9898fe

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：AD3QSC3P41JU F49末试 T2。账本：silent-0028,silent-0079。

已核事实及反例：额外起始毒3→6时敌仍72；四技能逐次加3敌力，末结6毒后仍58HP。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-153440-experience-update/proposal-enrage.md；SHA256：`f8c860cbaf5ba93b27d98d536fd220b254e6514dd9c19033f7604484b23aa395`。本批逐字节副本为同目录 silent-proposal-53ed69feeb9898fe.md。

处置：waiting。逐技能现场激怒已有live路径；缺抽牌后各候选到最终派发及完整后继的受控比较，原损2/损5差额是剩血字段误读，不据此修改数值。

预期行为及验证：保留现场激怒量；先关联重问前缀和实际执行，再讨论选线策略；不预支未结毒。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-1f34e9d37b21ba71

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：AD3QSC3P41JU F47、F48 T11、F49 T1—T2。账本：silent-0255,silent-0228,silent-0243,silent-0020,silent-0019,silent-0021。

已核事实及反例：末火实回36至62，女王退出15空药，次场首手11；脑已规划连Boss，不归为忘记连战。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-153440-experience-update/proposal-resources.md；SHA256：`79a49cd2ef7238a3dcf33ed556d5cde7071efe83b7b22efb77dd7539c2e65c27`。本批逐字节副本为同目录 silent-proposal-1f34e9d37b21ba71.md。

处置：waiting。开场扣血窄项已由ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8实际live；仍缺留药、休息、路线和联合通关的受控完整结果，不能关闭宽项。

预期行为及验证：沿既有资源交接，分开首场收益与次场血价；按整局时间留出，不由同入口六试拟参数。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-fc6618e0844f2007

原任务：postmortem → strategy-proposal；角色 silent，已核进阶 A10。
证据：9DAS5L8YM1CN F19、F21、F22 T2—T6、F23 T2。账本：silent-0019,silent-0232,silent-0044。

已核事实及反例：路线投影F21/22/23入口38/28/18，实38/25/2；F22蛇咬线实13伤/损22，防御候选未执行。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261008-154302-postmortem/proposal-resource-terminal.md；SHA256：`1be9084ad8cd9df4b9140743b90102ff5c87f414d52eb1d728dcdc660e078217`。本批逐字节副本为同目录 silent-proposal-fc6618e0844f2007.md。

处置：waiting。未执行的防御候选缺到下一必经房及F24营火的完整配对后继，缺独立校准；不能从实胜余2血推出新的终局权重或替线能救。

预期行为及验证：保留参数；冻结资源链、预定营火和候选，需完整同样本后继后评估普通战末血药。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-a86e7753ca2a347c

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：9DAS5L8YM1CN F3、F17 T5、F22 T5—T6、F23 T2。账本：silent-0012,silent-0044,silent-0046,silent-0232,silent-0253,silent-0286,silent-0133。

已核事实及反例：磨蚀实付3能建1敏/4荆棘；下一战撤。速度药先建5敏不补旧挡，手上技法给12挡后柔嫩减属性，对14攻仍死。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-160331-experience-update/proposal-modifiers.md；SHA256：`eed41f373dd51a48a103b2efed092fed9ba083d1214664101fd318f0b99b0b31`。本批逐字节副本为同目录 silent-proposal-a86e7753ca2a347c.md。

处置：waiting。缺磨蚀毒/反伤末击中间帧、整组修饰条件回放和异线完整结果；四次同线不构成四独立局或新的SL胜线。

预期行为及验证：保持局部模型与未知边界；不预支未执行弃磨蚀，不把多1HP能活本轮写成通关差额。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-438a0eb4516e7975

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：9DAS5L8YM1CN F21 T1、F22 T3/T4。账本：silent-0261,silent-0055,silent-0009,silent-0220,silent-0260。

已核事实及反例：F21敌84→60→58→56，紧勒后两牌各2；F22开信刀、施毒和实结毒有不同来源。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-160331-experience-update/proposal-card-triggers.md；SHA256：`b2a3fa0b559c5c533dc70fc6ea803e99b61a146d9621257d7aa24a44ceb8d84e`。本批逐字节副本为同目录 silent-proposal-438a0eb4516e7975.md。

处置：waiting。普通紧勒已由5c7105ff0294466da8319f2934beda05c6040794实际live；整组开信刀/冒泡/蛇咬与确定弃牌后的完整配对结果仍未闭合，不能整体duplicate。

预期行为及验证：沿现有普通单层边界，核弃牌完成时点、第三技能、施毒与结毒；未知升级/叠加/重放不扩展。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

### silent-proposal-588eefdf87e34f32

原任务：experience-update → strategy-proposal；角色 silent，已核进阶 A10。
证据：9DAS5L8YM1CN F17→F18、F19、F21—F23。账本：silent-0243,silent-0020,silent-0019,silent-0021。

已核事实及反例：F17胜28/70→跨幕61，回复33；连续战实38→25→2，F24枕头营火未抵达，末战四次同线未胜。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-160331-experience-update/proposal-resources.md；SHA256：`16997732346d551fece7ffa0c6113e6b44aa736182c7159415e525c67e0be42a`。本批逐字节副本为同目录 silent-proposal-588eefdf87e34f32.md。

处置：waiting。本批首次消费该原ID；只有一条实际资源路线，缺到下一营火的替路线/留药受控后继和时间留出，不能预支未来回复、未建磨蚀或拟血药/SL/终局新权重。

预期行为及验证：分账真实连续战出口血药与跨战能力重建，只计已到达回复；未来按整局切分做完整候选接续校验。

拟合/时间切分：本批不拟参数。同局全部SL尝试作为同一组；未来开发和较晚验证按整局分离。若后续证据充分并上线，只回退对应源码提交，保留原日志、账本和知识刷新。

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
spec = importlib.util.spec_from_file_location("resources", workspace / "learner/resource_chain.py")
resources = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resources)
manifest = json.loads((scratch / "evidence/evidence-manifest.json").read_text())
runs = json.loads((scratch / "dispatch.json").read_text())["runs"]
streams = {}
for stream in manifest:
    grouped = {run: [] for run in runs}
    for line in (scratch / "evidence" / (stream["stream"] + ".evidence.jsonl")).open():
        item = json.loads(line)
        row = dict(item["row"], _line=item["line"], _source_sha256=item["sha256"])
        grouped[item["run_id"]].append(row)
    streams[stream["stream"]] = grouped

summary = []
exclusions = []
for run in runs:
    states = streams["states"][run]
    starts = {}
    for row in streams["sl-attempts"][run]:
        if row.get("attempt", 1) > 1 and row.get("started_at"):
            starts.setdefault(row.get("floor"), []).append(row["started_at"])
    chain = resources.resource_chain(states, run, "silent", starts)
    (scratch / (run + "-resources.json")).write_text(json.dumps(chain, ensure_ascii=False, indent=2) + "\n")
    decisions = []
    for row in streams["decisions"][run]:
        if not row.get("decision_id"):
            exclusions.append({"run_id": run, "line": row["_line"], "sha256": row["_source_sha256"],
                               "reason": "原行无decision_id，保留元数据，不传入要求唯一动作身份的消费者", "row": row})
        else:
            decisions.append(row)
    entry = {"run": streams["runs"][run][0], "decisions": decisions, "states": states}
    path = scratch / (run + "-selection-input.json")
    path.write_text(json.dumps(entry, ensure_ascii=False) + "\n")
    summary.append({"run_id": run, "states": len(states), "decisions": len(decisions),
                    "combat_windows": len(chain["combats"]), "combat_endings": dict(collections.Counter(c["end"] for c in chain["combats"])),
                    "input": str(path), "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "floors": [{"floor": c["floor"], "entry_hp": c["entry"]["hp"], "last_hp": c["last"]["hp"],
                                "exit_hp": c["exit"]["hp"] if c.get("exit") else None, "end": c["end"]} for c in chain["combats"]]})
(scratch / "material-input-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
(scratch / "decision-exclusions.json").write_text(json.dumps(exclusions, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"inputs": [{k: v for k, v in row.items() if k != "floors"} for row in summary], "excluded_metadata": len(exclusions)}, ensure_ascii=False))

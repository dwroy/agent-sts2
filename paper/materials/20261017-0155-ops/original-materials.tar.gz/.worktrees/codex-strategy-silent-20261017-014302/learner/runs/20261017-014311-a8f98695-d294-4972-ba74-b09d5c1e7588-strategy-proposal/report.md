# 本批静默猎手策略提案回报

十个派发原提案均已逐项核验，最终全部 waiting。没有发现能够据本批三局新增并独立验证的源码修复；已有窄实现均核到实际 live 祖先，不能据此关闭更宽的整战、资源及策略验证项。本批无源码/知识改动、提交、合入、新版本或 shipped。

批次：20261017-014302-strategy-proposal；角色 silent；base/HEAD：`a0e2fff7b979314585252a095ae0e20c8045a6ba`。开工 git status 干净，普通批次 git merge --no-edit main 返回 Already up to date。根 learn.json 本行 task/character/worktree 与本题一致，十个 proposal_ids 已全部消费，无 proposal_repair/research_request/implementation_request。普通匹配用的 deck-size 请求绑定其他旧批次，故本批不进入专题，也未读其他专题替代身份。dispatch.json、assigned-proposals.json 保存本行和十原提案的物理位置、原行 SHA、历史及最新状态；十份原 Markdown 保存逐字节副本，SHA 全与原队列相符。

## 证据边界

三局均从 runs.jsonl 的原始字节核为 SILENT/A10/victory=false：H1T1F8ML9FUE F48，AD3QSC3P41JU F49，9DAS5L8YM1CN F23。旧执行分别 1a0adbaa+dirty、a340c1ec+dirty、7f0c04dd+dirty；当时完整 dirty 源码和知识输入未保存，当前树不冒认历史执行树。SL 尝试按同局同房分组，不增加独立样本。旧 deepseek_calls 兼容计数字段不用于判定历史实际脑引擎。

严格使用共用 extract_evidence.py 冻结八流，4161 条选中原行逐 offset/bytes/SHA/JSON/显式 run 身份读回通过。run-plans 的 run 字段已纳入；正文提及不作所属局，冲突身份拒收。各流独立截点和逐行封套保存在 evidence/；源流坏 JSON 数量为整流计数，所有本截点 incomplete_lines=0。顺序为 H1/AD/9D：

|流|source_size 字节|三局选中行数|全源坏JSON行|
|---|---:|---|---:|
|states|13723516177|930/728/396|2|
|decisions|2105528038|844/708/387|2|
|sl-attempts|44370924|9/9/6|0|
|run-config|1906230|1/1/1|0|
|run-plans|8723742|9/9/6|0|
|brain|709741394|49/43/22|2|
|runs|353455|1/1/1|0|
|fight-plans|2233957|0/0/0|0|

fight-plans 仅在该截点选中0，不据此声称原日志缺失。另按旧8498804字节截点重提 run-plans，9/9/6行及 SHA 与本次8723742截点相同。与旧131302-s2的八流选中封套全部逐 SHA、计数一致；截点增长没有新增本三局独立证据。旧报告与旧截点目录保持原样；没有将提取过程中的0字节缓冲当作日志缺失证据。cutoff-comparison.json 和 evidence-old-run-plans/ 保存对照。

复用原材料核验脚本并只适配本批目录，保留原字节 previous-audit-source.txt，20 项事实断言/34 个状态投影全部通过（evidence-audit.json、state-projections.json）；这些是材料核验，不计生产测试 cases。

- H1 F47实休息33→52，F48六试未赢，F49未到；F33实胜28HP是有限推演不等必败的反方向。F48末34HP、30攻击加6持牌伤与实死相符，未结毒不预支。
- AD 首场退出15空药→次场入房15→首手11。保血线21伤/零损与另一线30伤/损8不同；第二试多活到T3仍无胜局。末次四技能使敌力3→15，弱后23攻，18挡/3HP完整需损5；毒6已结后敌仍58。
- 9D 实入口38/25/2，下一营火F24未到；F22防御候选没有完整执行后继。F23四试同线，三次读档，末2HP/12挡对14攻实死、敌81HP。多1HP只是本轮严格存活下限，不能写成整场获胜差额。F22磨蚀实际付3能建立1敏/4荆棘，不预支未执行的弃牌联动。

## 资源及动作消费者

现有 learner/resource_chain.py 在冻结封套上得到 H1/AD/9D 的28/23/14战斗窗口（含同房重试），分别22/18/11个可观察出口，其余6/5/3是重启边界。资源净变化不等敌人毛伤；主动实饮、丢弃、交换、SL恢复仍须依据动作分别判定，不由空槽自行补因果。新9D资源项另存97个原帧投影及完整资源链，不复写历史复盘。

现有 learner/audit-selection.ts 用 node --import 本地tsx loader离线执行，三局均 exit0；不联网、不调模型/游戏或战斗模拟。输入保留真实 _line、原行SHA、观测时间和指纹。AD两行、9D四行缺 decision_id 元数据在 decision-exclusions.json 逐项保留并排除出要求唯一动作身份的消费者，未重新编号；原八流证据没有删行。

|局|带ID动作|题目片段|轮窗口|已观察整轮端点|
|---|---:|---:|---:|---:|
|H1T1F8ML9FUE|844|122|137|35|
|AD3QSC3P41JU|706|91|124|28|
|9DAS5L8YM1CN|383|106|72|14|

共1933动作、319片段、333轮窗；510动作有 observed_endpoints，1423未知；77轮有 observed_turn_endpoints，256未知。完整候选认证字段全 null 是现有工具的契约限制，不证明实际没有完整执行；也不能把整轮净HP变化归给某条中途被重问替换的候选。输入/输出/stderr SHA、命令与真实exit保存在 consumer-results.json，汇总在 consumer-summary.json。工具与全部本地递归依赖均核SHA，工具未改；本次是材料消费者验证，不是线上自然采用或策略收益。

## 既有实现与源码边界

只读核到 live HEAD `5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922`。23个相关源码/固定输入/消费者文件中18个与live逐字节相同；另外5个仅历史 Roy/Dai 注释署名差，source-live-differences.patch保留。与旧ca9f61f7相比，三个生产文件新增故障封套/诊断字段而非本批已证根修复；完整diff在source-from-previous.patch，不据有限叶SHA宣称历史dirty源码完整或联合生产校准。

以下均已实核为base和实际live祖先；本批未新增这些实现：

- AD两套完整组合开场扣4：`ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`，只新战扣一次，不重扣已可操作或SL入口。
- 普通单层紧勒后续逐牌2：`5c7105ff0294466da8319f2934beda05c6040794`，未知升级/叠加/重放不扩展。
- 群蛇蜃景重放：`be9577c81a003aff0e69968c928e264f5173da7c`。
- 可见凋萎伤害：`9b65f1bee0f26ced606ec256fc3d173db48caa3e`。
- `295a90aef9eb6f5b267490294f7733806419c45a` 含既有激怒和开信刀路径，仅作为含该路径的祖先，不冒称原始首提交或本角色本批新学习。

原部分提案的“预计损2对实际需损5”已在旧报告勘误。本批再核 d292362/d292364 原rationale为 keeps the most HP (-2)；旧a340c1ec和本base模板均插入 outcome.hpAfter，3−(23−18)=−2相符。没有由此文字证明的3伤模型差额，也不据此认定完整旧模型正确。hp-field-readback.json保存原行及模板。原四份Markdown/复盘不改写；这是已记录的旧勘误，不新增不同意见通知或代填ops/watcher/Roy确认。

## 十项最终处置

每项局号/层/回合、全部既有账本id、原文SHA、事实与反例、预期行为、验证和回退见 proposal.md；本批不新增重复提案id。

|原ID|状态|具体缺口|
|---|---|---|
|silent-proposal-34209e8b9f982e49|waiting|缺同盘替路线、留药和后场完整结局及时间留出，不能由末战败局拟药水持有价、终局权重或SL门槛。|
|silent-proposal-015f25123c45671c|waiting|开场完整组合窄项已有live源码ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8；缺从F48起的受控留药比较和独立联合校准，宽项继续等待。|
|silent-proposal-01d7495835a3eb19|waiting|缺T1之后同抽序完整后继及抽牌重问至派发的完整归属；既有HP护栏8不能据本局重新拟定，预计剩血-2也不是预计损2。|
|silent-proposal-cb23be067a5f04c1|waiting|毒雾、蜃景、臂甲、爆发尖啸和水盆已有局部接线；缺整组实际修饰条件的完整候选归属与受控后继，不能宣称联合校准或拟敏捷药留药时点。|
|silent-proposal-53ed69feeb9898fe|waiting|逐技能现场激怒已有live路径；缺抽牌后各候选到最终派发及完整后继的受控比较，原损2/损5差额是剩血字段误读，不据此修改数值。|
|silent-proposal-1f34e9d37b21ba71|waiting|开场扣血窄项已由ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8实际live；仍缺留药、休息、路线和联合通关的受控完整结果，不能关闭宽项。|
|silent-proposal-fc6618e0844f2007|waiting|未执行的防御候选缺到下一必经房及F24营火的完整配对后继，缺独立校准；不能从实胜余2血推出新的终局权重或替线能救。|
|silent-proposal-a86e7753ca2a347c|waiting|缺磨蚀毒/反伤末击中间帧、整组修饰条件回放和异线完整结果；四次同线不构成四独立局或新的SL胜线。|
|silent-proposal-438a0eb4516e7975|waiting|普通紧勒已由5c7105ff0294466da8319f2934beda05c6040794实际live；整组开信刀/冒泡/蛇咬与确定弃牌后的完整配对结果仍未闭合，不能整体duplicate。|
|silent-proposal-588eefdf87e34f32|waiting|本批首次消费该原ID；只有一条实际资源路线，缺到下一营火的替路线/留药受控后继和时间留出，不能预支未来回复、未建磨蚀或拟血药/SL/终局新权重。|

## 测试、交付与限制

无源码修改，未运行生产tsc/vitest，撤源码负控/恢复测试不适用，tests固定为{"tsc":null,"vitest":null,"cases":null}。没有源码提交，故无提交前gitleaks/提交/live合后测试或新release_id可报告。未运行play、安装依赖、推送或修改prompt/凭据/其他角色数据，未派下级agent；本会话未独立读取原生model/effort元数据，不将文档默认或启动要求冒作实际运行核验。

本批没有待兜底的源码提交或合入阻塞，merge=live流程因无新补丁不执行；不把证据不足伪造成合入或测试成功。没有新增策略条目需要proposed，不把既有shipped经验退回proposed；本批仅追加where/note追溯，具体CLI读回另附于下文。未关闭任何宽父或宣称留药、换线可救本局，全部waiting保留待新局或可复现完整候选证据重派。

交运维：本目录proposal.md、report.md与result.json；全为真实本批绝对路径，最终JSON带十原ID逐项proposal_results。原日志/历史/失败与初稿均保留，不自行回收。

## 最终账本与工作树读回

根 learner/ledger.py update 实际 exit0，仅追加28条本角色where/note追溯；输入及stdout/stderr SHA、每条物理offset/bytes/SHA、旧前缀SHA及fold保护核验已保存于ledger-cli-result.json、ledger-readback.json。所有原claim、首证、prior、evidence、status、version、shipped、effect以及history/notes/where前缀均保持，不重复support/repeat、不新造提案id、不代登记shipped。

最终原派发行与十ID仍一致，HEAD等于base，git status/index及生产源码/全部knowledge差分为空，见final-worktree-check.json。读取时曾探测旧路径/不存在的说明文件而返回2，均未作游戏证据或生产测试失败；后续用实际文件与共用入口完成。本批没有新的科学冲突或待Roy审批事项。result.json是最终机器回报；artifact-index.json保存相邻材料文件SHA。本批结束不等于经验已入库、自然消费者已采用或宽父要求关闭。

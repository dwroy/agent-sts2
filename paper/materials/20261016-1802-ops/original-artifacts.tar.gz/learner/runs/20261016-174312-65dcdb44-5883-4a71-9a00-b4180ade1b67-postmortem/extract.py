import json,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out= root/'learner/runs/20261016-174312-65dcdb44-5883-4a71-9a00-b4180ade1b67-postmortem'; run=b'7X58G3LSHZ3U'
manifest={}; times=[]
for name in ['decisions','states','runs','run-plans','sl-attempts','brain','run-config']:
 p=root/'logs'/f'{name}.jsonl'; refs=[]; offset=0; limit=p.stat().st_size
 with p.open('rb') as src,(out/f'{name}.jsonl').open('w') as dst:
  for n,line in enumerate(src,1):
   start=offset;offset+=len(line)
   if offset>limit:break
   if run not in line:continue
   row=json.loads(line)
   match=(row.get('run_id')==run.decode() or row.get('run')==run.decode() or (row.get('state') or {}).get('run_id')==run.decode())
   if not match:continue
   refs.append({'line':n,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()})
   row['_line']=n;dst.write(json.dumps(row,ensure_ascii=False)+'\n')
   if name=='decisions':times.append(row['ts'])
 manifest[name]={'cutoff':limit,'count':len(refs),'refs':refs}
 print(name,len(refs),flush=True)
a,b=min(times),max(times); count=0;offset=0;p=root/'logs/deepseek-reasoning.jsonl'
with p.open('rb') as src,(out/'deepseek-reasoning.jsonl').open('w') as dst:
 for n,line in enumerate(src,1):
  start=offset;offset+=len(line)
  row=json.loads(line);ts=row.get('ts','')
  if a<=ts<=b:row['_line']=n;dst.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
manifest['reasoning']={'start':a,'end':b,'count':count}
(out/'extraction-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('window',a,b,'reasoning',count)

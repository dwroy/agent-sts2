import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent;load=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()];d=load('decisions');s=load('states');b=load('brain');r=json.load((p/'7X58G3LSHZ3U-resources.json').open())
with (p/'metrics.txt').open('w') as f:
 def say(*v):print(*v,file=f)
 for c in r['combats']:
  a=c['entry'];end=c['exit'] or c['last'];ss=[x for x in s if a['line']<=x['_line']<=end['line']];turns=[]
  for x in ss:
   st=x['state'];t=st.get('turn')
   if st.get('in_combat') and (not turns or t!=turns[-1][0]):turns.append((t,x))
  say('COMBAT',c['sequence'],c['floor'],'turns',[(t,x['_line'],x['state']['run']['current_hp'],sum(e['current_hp'] for e in x['state']['combat']['enemies'] if e['is_alive'])) for t,x in turns])
  endpoints=turns[1:]+[(None,ss[-1])]
  say('HP_DELTA',[x['state']['run']['current_hp']-y['state']['run']['current_hp'] for (_,x),(_,y) in zip(turns,endpoints)])
 jev=[x for x in d if x['decider']=='jev'];plan=[x for x in jev if x['label'].startswith('combat/')]
 say('low',[(x['_line'],x['floor'],x['turn'],x['confidence']) for x in jev if x['confidence']<.35]);say('rollout',collections.Counter(str(x.get('rollout_best_chosen')) for x in plan))
 for x in d:
  if x.get('hp_guard') or 'guard' in x.get('rationale','').lower():say('GUARD',x['_line'],x['floor'],x['turn'],json.dumps(x.get('hp_guard'),ensure_ascii=False),x.get('rationale'))
  if x.get('focus'):say('FOCUS',x['_line'],x['floor'],x['turn'],x.get('answers'),x['focus'])
  if (x.get('chosen') or {}).get('action') in ['use_potion','discard_potion']:say('POTION',x['_line'],x['floor'],x['turn'],x['chosen'],x['rationale'])
 auto=[x for x in d if x['decider']=='code' and x['label'].startswith('combat/') and x['label']!='combat/plan-continue']
 done=[x for x in auto if str(x.get('result')).startswith('completed')];key=lambda x:(x['floor'],x.get('sl_attempt') or 1,x['turn'])
 say('AUTOCODE',len(auto),len(done),len(set(map(key,auto))),len(set(map(key,done))),'only',len(set(map(key,done))-set(map(key,plan))))
 say('notdone',[(x['_line'],x.get('result')) for x in auto if x not in done]);say('fallback',collections.Counter(x.get('fallback') for x in d));say('brain identities',collections.Counter((x['engine'],x['model'],x['effort'],x['accepted']) for x in b))
 say('BRAIN_USAGE',dict(collections.Counter({k:sum((x.get('usage') or {}).get(k,0) or 0 for x in b) for k in set().union(*(set((x.get('usage') or {})) for x in b))})))
 say('brain_latency',sum(x.get('latency_ms',0) or 0 for x in b));say('JEV_USAGE',{k:sum((x.get('usage') or {}).get(k,0) or 0 for x in jev) for k in ['input_tokens','output_tokens','cache_hit_tokens']})
 parse=lambda z:datetime.datetime.fromisoformat(z.replace('Z','+00:00'))
 say('wall',(parse(d[-1]['ts'])-parse(d[0]['ts'])).total_seconds(),(parse(d[-1]['ts'])-parse(load('run-config')[0]['ts'])).total_seconds())
 for x in d:
  if x['floor']==24 and x['decider']=='jev':
   au=x.get('selection_audit') or {};say('F24Q',x['_line'],x.get('sl_attempt'),x['turn'],x.get('answers',{}).get('plan',{}).get('choice'),'best',x.get('rollout_best_chosen'),'rollout',x.get('rollout'),'answer',au.get('answer'),'after_sl',au.get('after_sl',{}).get('line'))
print(p/'metrics.txt')

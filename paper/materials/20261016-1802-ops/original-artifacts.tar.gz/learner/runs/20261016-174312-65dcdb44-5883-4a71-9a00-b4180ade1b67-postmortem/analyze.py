import json,collections
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=load('decisions');s=load('states')
with (p/'decision-summary.txt').open('w') as f:
 for x in d:
  if x['decider']=='codex' or x['floor']>=21:
   j=x.get('journal') or {}
   f.write(f"d{x['_line']} {x['ts']} F{x['floor']}T{x['turn']} {x['decider']} {x['label']} A{x.get('sl_attempt')} {x.get('chosen')} conf={x.get('confidence')}\n{x.get('rationale')}\njkeys={list(j)}\n")
   for k,v in j.items():
    if k in ['hp_guard','rollout_best_chosen','chosen_order','chosen_plan','focus','selected_plan','plan']:f.write(k+'='+json.dumps(v,ensure_ascii=False)+'\n')
with (p/'state-summary.txt').open('w') as f:
 for x in s:
  st=x['state'];run=st['run'];c=st.get('combat') or {};pl=c.get('player') or st.get('player') or {}
  if run['floor']<21:continue
  f.write(f"s{x['_line']} {x['ts']} F{run['floor']}T{st.get('turn')} {st['screen']} combat={st.get('in_combat')} hp={run['current_hp']}/{run['max_hp']} pl={pl}\n")
  f.write('enemies='+json.dumps(c.get('enemies'),ensure_ascii=False)+'\n')
  f.write('hand='+json.dumps(c.get('hand'),ensure_ascii=False)+'\n')
  f.write('potions='+json.dumps(run.get('potions'),ensure_ascii=False)+'\n')
with (p/'structure.txt').open('w') as f:
 f.write(str(s[-2]['state'].keys())+'\n'+str(s[-2]['state'].get('combat',{}).keys())+'\n')
 f.write(json.dumps(s[-2],ensure_ascii=False,indent=2))
print('ranges',d[0]['_line'],d[-1]['_line'],s[0]['_line'],s[-1]['_line'])
print('deciders',collections.Counter(x['decider'] for x in d));print('labels',collections.Counter((x['decider'],x['label']) for x in d))
for x in load('sl-attempts'):
 print('SL',x['_line'],{k:v for k,v in x.items() if k in ['floor','attempt','started_at','ended_at','result','reload','judge']})
print('state combat keys',s[-2]['state']['combat'].keys())
print('jev example journal',next(x['journal'] for x in d if x['decider']=='jev').keys())

import json,hashlib,collections
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2');passed=[]
def check(name,test):
 assert test,name
 passed.append(name)
load=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=load('decisions');s=load('states');b=load('brain');di={x['_line']:x for x in d};si={x['_line']:x for x in s};r=json.load((p/'7X58G3LSHZ3U-resources.json').open());run=load('runs')[0]
check('已结束silent-A10-F24',run['character'].lower()=='silent' and run['ascension']==10 and run['floor']==24 and not run['victory'])
check('抽取数量',len(d)==441 and len(s)==455 and len(b)==27 and len(load('run-plans'))==6)
manifest=json.load((p/'extraction-manifest.json').open())
for name,part in manifest.items():
 if name=='reasoning':continue
 rows=load(name)
 with (root/'logs'/f'{name}.jsonl').open('rb') as src:
  for row,ref in zip(rows,part['refs']):
   src.seek(ref['offset']);raw=src.read(ref['bytes']);assert hashlib.sha256(raw).hexdigest()==ref['sha256'],(name,ref['line']);obj=dict(row);obj.pop('_line');assert json.loads(raw)==obj,(name,ref['line'])
 check('原始指纹及JSON:'+name,len(rows)==len(part['refs']))
check('resource16窗口13战',len(r['combats'])==16 and len(set(x['floor'] for x in r['combats']))==13)
check('入口T1及max70',all(x['entry_is_turn_one'] and x['entry']['max_hp']==70 and (x['exit'] or x['last'])['max_hp']==70 for x in r['combats']))
expected=[(2,56,52),(3,52,52),(5,52,52),(6,52,39),(8,60,44),(12,44,44),(14,44,44),(15,44,44),(17,44,18),(19,59,54),(21,54,40),(22,40,24),(24,24,2),(24,24,11),(24,24,2),(24,24,0)]
check('逐战入口出口HP',[(x['floor'],x['entry']['hp'],(x['exit'] or x['last'])['hp']) for x in r['combats']]==expected)
check('前三试无退出',all(r['combats'][i]['exit'] is None for i in [12,13,14]))
last=si[426589]['state'];e=last['combat']['enemies'][0];pl=last['combat']['player'];damage=sum(z['total_damage'] or 0 for z in e['intents']);check('末态2血8挡11攻击',pl['current_hp']==2 and pl['block']==8 and damage==11)
check('终局35血2毒结算',si[426590]['state']['run']['current_hp']==0 and si[426590]['state']['combat']['enemies'][0]['current_hp']==35 and e['current_hp']==37)
pages=[x for x in s if (x['state'].get('selection') or {}).get('kind')=='deck_card_select' and '手牌' in (x['state'].get('selection') or {}).get('prompt','')]
check('11个取牌页',len(pages)==11)
for x in pages:
 st=x['state'];sel=st['selection'];n=x['_line'];assert sel['min_select']==0 and sel['max_select']==2 and sel['selected_count']==0
 after=si[n+1]['state'];assert [z['card_id'] for z in st['combat']['hand']]==[z['card_id'] for z in after['combat']['hand']]
check('11次确认不添牌',sum(x['label']=='selection/confirm' and (x.get('chosen') or {}).get('action')=='confirm_selection' for x in d)==11)
check('末试幽灵后继不在真实名单',not {'SLICE','MALAISE'} & {z['card_id'] for z in si[426581]['state']['selection']['cards']})
check('原候选损3改线损12',di[412928]['selection_audit']['answer']['turn']['hp_loss']==3 and di[412931]['selection_audit']['answer']['turn']['hp_loss']==12 and si[426585]['state']['run']['current_hp']-si[426586]['state']['run']['current_hp']==12)
check('取牌预测21胜0死', '21/24' in di[412928]['questions']['plan']['criteria']['plan3'] and di[412928]['selection_audit']['answer']['rollout']['deaths']==0)
check('零HP护栏',not any(x.get('hp_guard') for x in d) and not any('HP guard' in x.get('rationale','') for x in d))
j=[x for x in d if x['decider']=='jev'];jp=[x for x in j if x['label'].startswith('combat/')]
check('Jev低信心5',len(j)==79 and sum(x['confidence']<.35 for x in j)==5)
check('推演71真4假1未知',len(jp)==76 and collections.Counter(str(x.get('rollout_best_chosen')) for x in jp)=={'True':71,'False':4,'None':1})
check('5饮0弃',sum((x.get('chosen') or {}).get('action')=='use_potion' for x in d)==5 and not any((x.get('chosen') or {}).get('action')=='discard_potion' for x in d))
check('5次新药入栏',sum(not x['restart_boundary'] and len(x['to']['potions'])>len(x['from']['potions']) for x in r['resource_changes'])==5)
check('三次读档',[x['reload']['ok'] for x in load('sl-attempts') if x.get('reload')]==[True]*3)
check('全部实际Codex',all((x['engine'],x['model'],x['effort'],x['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for x in b))
check('Codex用量',sum(x['usage']['inputTokens'] for x in b)==4569950 and sum(x['usage']['outputTokens'] for x in b)==35400 and sum(x['usage']['cacheHitTokens'] for x in b)==2496000)
check('Jev用量',sum(x['usage']['input_tokens'] for x in j)==564286 and sum(x['usage']['output_tokens'] for x in j)==4138)
check('事件中文勘误',si[426489]['state']['event']['title']=='色彩哲学家')
check('卵体T1退',si[426406]['state']['turn']==1 and [z['enemy_id'] for z in si[426406]['state']['combat']['enemies']]==['BOWLBUG_ROCK'])
check('群蛇只建立一次',sum((x.get('expect') or {}).get('card',{}).get('id')=='SERPENT_FORM' for x in d)==1 and (di[412831]['floor'],di[412831]['turn'])==(22,8))
check('末战未建群蛇',not any(any(z['power_id']=='SERPENT_FORM_POWER' for z in ((x['state'].get('combat') or {}).get('player') or {}).get('powers',[])) for x in s if x['state']['run']['floor']==24))
for name in ['decisions','states','runs']:
 refs=json.load((p/f'prior-NQKV-{name}-refs.json').open())
 with (root/'logs'/f'{name}.jsonl').open('rb') as src:
  for ref in refs:
   src.seek(ref['offset']);raw=src.read(ref['bytes']);assert hashlib.sha256(raw).hexdigest()==ref['sha256']
 check('旧局原帧指纹:'+name,bool(refs))
before=json.load((p/'lessons-before.json').open());h=hashlib.sha256()
with (root/'notes/lessons.md').open('rb') as f:
 remain=before['bytes']
 while remain:
  part=f.read(min(remain,1048576));h.update(part);remain-=len(part)
 tail=f.read().decode()
check('lessons旧前缀保持',h.hexdigest()==before['sha256']);check('一节主标题',tail.count('## 7X58G3LSHZ3U')==1)
check('勘误均保留','色彩哲学家' in tail and '原#3在T3' in tail and '之前见过：silent-0496' in tail)
(p/'appended-final.md').write_text(tail)
fold={x['id']:x for x in json.load((p/'ledger-readback.json').open())}
for ident in ['silent-0418','silent-0019','silent-0057','silent-0232','silent-0005','silent-0053','silent-0132','silent-0451']:
 old=json.load((p/(ident+'-before.json')).open());new=fold[ident]
 check('旧账本核心不变:'+ident,all(old.get(k)==new.get(k) for k in ['claim','first_run','prior','prior_runs','prior_note','status','version']))
check('新故障首证与重复',fold['silent-0496']['first_run']=='NQKVQ9RD9T2N' and fold['silent-0496']['status']=='observed' and any(x['run']=='7X58G3LSHZ3U' and x.get('role')=='repeat' for x in fold['silent-0496']['evidence']))
result={'passed':len(passed),'checks':passed};(p/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))

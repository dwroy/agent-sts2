#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.local/node/bin:$PATH"
export TMPDIR="/home/dw/Projects/agent-sts2/learner/runs/20261018-031307-81166ee3-073a-48f2-971c-48933da4aa72-fix-batch"
source_branch=codex-fix-silent-20261018-031302
live_tree=/home/dw/Projects/agent-sts2/.worktrees/live
exec 9>/home/dw/Projects/agent-sts2/ops/live-merge.lock
flock -n 9 || { echo 'live lock busy; no live mutation'; exit 75; }
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
cd "$live_tree"
git status --short --untracked-files=no > "$TMPDIR/live-status-before.txt"
if ! git diff --cached --quiet; then
  echo 'live index already staged; preserve existing owner changes'
  exit 75
fi
git rev-parse HEAD > "$TMPDIR/live-before-refresh.txt"
git diff --name-only -- knowledge notes/fight-value-backtest.md > "$TMPDIR/refreshed-knowledge-paths.txt"
git diff --name-only 3e7f8d904a167541f07e15472572a23208fb7720 "$source_branch" -- knowledge notes/fight-value-backtest.md > "$TMPDIR/branch-knowledge-paths.txt"
if comm -12 <(sort "$TMPDIR/refreshed-knowledge-paths.txt") <(sort "$TMPDIR/branch-knowledge-paths.txt") | rg .; then
  echo 'overlapping knowledge changes; stopped without overwriting refresh'
  exit 1
fi
git add notes/fight-value-backtest.md knowledge
if ! git diff --cached --quiet; then
  nice -n 19 gitleaks git --staged --no-banner --redact --log-level error > "$TMPDIR/refresh-gitleaks.log" 2>&1
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
before=$(git rev-parse HEAD)
printf '%s\n' "$before" > "$TMPDIR/live-before-merge.txt"
if git merge-tree --write-tree HEAD "$source_branch" > "$TMPDIR/live-merge-preflight.log" 2>&1; then
  echo 'merge preflight clean'
else
  result=$?
  printf '%s\n' "$result" > "$TMPDIR/live-merge-preflight.exit"
  echo 'merge preflight conflict; live source/index preserved'
  exit "$result"
fi
git merge --no-edit "$source_branch"
git rev-parse HEAD > "$TMPDIR/live-source-merge.txt"
cd agent
if bash tools/test-sandbox.sh > "$TMPDIR/live-sandbox.log" 2>&1; then
  printf '0\n' > "$TMPDIR/live-sandbox.exit"
else
  result=$?
  printf '%s\n' "$result" > "$TMPDIR/live-sandbox.exit"
  cd ..
  git reset --merge "$before"
  echo 'live checks failed; restored pre-merge commit with refresh and local records retained'
  exit "$result"
fi
cd ..
date > "$TMPDIR/live-publication-date.txt"
echo 'live source merge and sandbox checks succeeded; append publication record next'

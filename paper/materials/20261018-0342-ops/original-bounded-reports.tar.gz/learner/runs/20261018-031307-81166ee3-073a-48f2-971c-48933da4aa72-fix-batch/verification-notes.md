# 验证说明

首项为测试基础设施修复；不改变生产代码、模型、游戏规则或原集成测试时限。

Codex 原集成用例在沙箱内尝试一次，伪进程受限制，fake.calls() 为 0，尚未到时间断言。baseline-codex.log 保留该失败，不视为产品失败或通过。

固定回归 codex-stall-fixture.test.ts 使用 1120ms 首 token、1090ms 末事件，精确匹配 1 秒诊断。另保留零秒对照，错误首 token、末事件、事件类型和 timeout 均应拒绝。

负控保留抽取的断言接口和固定回归，仅将两个动态时间值恢复为原断言的 0 秒假设（不是删去模块导致导入失败）；退出 1，断言实际 1 秒/预期 0 秒。恢复后退出 0。codex-negative.log 和 codex-restored.log 为原始记录。

前批 45 个旧修复的当前 main/live 祖先已逐条核对；203 个关注源码叶比较中仅 rollout-live.ts、rollout.ts、learner_checks.py 与前批基线变化，分别对应既有 H0 与报告格式源码。queue-snapshot.md 为本批切点输入，队列原文件不修改。

## rollout 完整事实夹具

原格式测试所有断言与 30000ms 时限保留；新 full-rollout-facts-fixture.ts 只给该格式消费者提供合成 5 回合/8 样本回执，真实当回合求解、题面/事实渲染、选择和日志仍运行。模拟器精度由既有其他用例覆盖，不声称该合成回执是实盘预测。

新回归冻结全部 knowledge JSON 读取到 tests 下既有 pinned-knowledge，缺项 ENOENT；把未来回合模拟器改成抛错。仅撤掉源码 mockImplementation(fullFacts) 时，测试因实际调用两次模拟器失败（rollout-negative.log，退出1），恢复后新回归与原格式题2文件2项通过（rollout-restored.log，退出0）。原138其他用例未在定向阶段重复执行。

首次 npx 定向命令误从仓库根目录运行，未找到本地 Vitest，DNS 被限制后以 EAI_AGAIN/1 退出；未安装依赖。原 rollout-initial.log 保留，不计为 Vitest 失败/通过。已在 agent/ 和 npm_config_offline=true 下按正确本地入口重跑，通过（rollout-correct-cwd.log）。

第一项完整沙箱 tsc0，487线程文件4434用例加paths1文件11例，共488文件4445例，退出0；原Codex进程集成仍由宿主补验。本批从未运行play、LLM或游戏动作。

最终第二项沙箱 tsc0，488线程文件4435例加paths1文件11例，共489文件4446例，退出0。第二源码提交2ca4eb3aad3c9c0f33027e4e217c4820a210c2a2。

实际已获得live锁、builder守卫结束、指定知识路径零待提交且与本次六测试叶零重叠。merge-tree预检返回1，20处均历史记录/账本/论文数据冲突；live HEAD前后f7abb0e13d3ee0943637be2146ca52ee25486289，未产生冲突index或修改工作文件，原两条未暂存notes修改保留。按任务要求停止，不擅自处理历史冲突或改用窄cherry-pick。

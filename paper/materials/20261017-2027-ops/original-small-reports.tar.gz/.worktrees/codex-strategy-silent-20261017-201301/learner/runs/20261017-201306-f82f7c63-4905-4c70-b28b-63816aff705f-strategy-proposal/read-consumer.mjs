import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { auditSelectionExecution } from '../../lib/selection-execution.ts';

const out = dirname(fileURLToPath(import.meta.url));
const inputs = JSON.parse(readFileSync(join(out, 'consumer-input-manifest.json'), 'utf8'));
const summaries = [];
for (const entry of inputs) {
  const original = gunzipSync(readFileSync(join(out, `${entry.run_id}.consumer-input.json.gz`)));
  if (createHash('sha256').update(original).digest('hex') !== entry.input_sha256) throw new Error('input SHA differs');
  const input = JSON.parse(original);
  const before = JSON.stringify(input);
  let rejection = null;
  let result;
  try {
    result = auditSelectionExecution(input);
  } catch (error) {
    rejection = String(error);
    if (!entry.missing_decision_id_lines.length) throw error;
    input.decisions = input.decisions.filter((row) => row.decision_id);
    result = auditSelectionExecution(input);
  }
  if (!rejection && JSON.stringify(input) !== before) throw new Error('consumer changed input');
  const raw = Buffer.from(JSON.stringify(result));
  writeFileSync(join(out, `${entry.run_id}.consumer-output.json.gz`), gzipSync(raw));
  const summary = {
    run_id: entry.run_id,
    scope_floors: entry.scope_floors,
    original_input_rejection: rejection,
    excluded_missing_id_lines: rejection ? entry.missing_decision_id_lines : [],
    decisions: input.decisions.length,
    states: input.states.length,
    candidate_segments: result.segments.length,
    observed_action_endpoints: result.observed_actions.filter((x) => x.observed_interval.status === 'observed_endpoints').length,
    observed_terminal_endpoints: result.observed_actions.filter((x) => x.terminal_observation?.status === 'observed_terminal_endpoints').length,
    observed_turn_endpoints: result.observed_turns.filter((x) => x.status === 'observed_turn_endpoints').length,
    unknown_turn_windows: result.observed_turns.filter((x) => x.status !== 'observed_turn_endpoints').length,
    certified_complete_candidates: result.segments.filter((x) => x.actual_full_candidate_result !== null).length,
    output_bytes: raw.length,
    output_sha256: createHash('sha256').update(raw).digest('hex'),
  };
  summaries.push(summary);
  console.log(JSON.stringify(summary));
}
writeFileSync(join(out, 'consumer-readback.json'), JSON.stringify(summaries, null, 2) + '\n');

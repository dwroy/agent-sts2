import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
WT = OUT.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
timestamp = subprocess.check_output(['date', '+%Y-%m-%dT%H:%M:%S%:z']).decode().strip()
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())
sources = json.loads((OUT / 'source-verification.json').read_text())
raw_checks = json.loads((OUT / 'raw-readback-verification.json').read_text())
facts = json.loads((OUT / 'fact-checks.json').read_text())
consumers = json.loads((OUT / 'consumer-readback.json').read_text())
assert all(f['ok'] for f in facts)
assert all(e['certified_complete_candidates'] == 0 for e in consumers)

# These are scoped dispositions of the original IDs, not newly registered proposals.
details = [
('神化同线与后抽升级传播', 'VLZ6CCT8AQ0A F35T1、F36T2、F43T1—T5、F45T1',
 'F35/F43神化实付2能；F43同后续牌序预测43伤/14损变51伤/13损，端点实际51伤/13损。',
 'F45持有神化但未施放；F43施放且获胜仍损57血。不同场不能证明神化导致胜负。',
 '已有Silent A10普通签名的状态升级、后抽传播及17种观察配对；actual_cast_this_fight仍为null。',
 '缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整生产消费认证；已有窄升级传播不足将整项认定实现。',
 '固定F35/F43/F45帧逐卡核验升级、能量、消耗及场外deck不变；补持续身份后，独立验证抽牌/重问/换战与未知签名隔离。'),
('三骑士血价与药水预算', 'VLZ6CCT8AQ0A F43、F44、F45T1/T4/T5',
 'F45首题随机药水MC 707ms仅1/12样本；T5尖啸使四段威胁83→59，32血20挡仍差7血。',
 'F45T4少损线24伤/13损实打，32伤/31损线未执行；无另一focus或留药的受控整战。',
 '保留现有护栏、药水分配与全部候选；全败、并列、退化分别记录。',
 '缺模型充分覆盖下同起点、同随机池、同总预算的MC策略配对与样本成熟度曲线；707ms单题不能确定新预算或留药常量。',
 '先冻结模型、种子及总预算，对原MC先行与分阶段MC作样本/耗时/候选稳定性配对；按后续独立局分组验证，不按SL尝试扩分母。'),
('神化经验补链同源请求', 'VLZ6CCT8AQ0A F35T1、F43T1—T5、F45T1',
 '与89354805ee4d7e77同一局和同一模型缺口；经验silent-apotheosis-combat-upgrades已关联。',
 '题意重复不等于实际live已完成原要求；F45未施放不能当升级规则反例。',
 '沿用原id及原账本，和神化主提案共用核验，不新增重复id。',
 '与89354805ee4d7e77同源，仍缺实际施放持续身份及后续生产消费认证；同源和窄实现均不足登记duplicate。',
 '沿主提案逐项核验；只有全部范围均有实际live祖先源码证明后才可登记duplicate。'),
('十五机制与资源分账', 'VLZ6CCT8AQ0A F43T1—T5、F44、F45T3/T5',
 'F45末轮勒紧4/敏捷3/覆甲0/触媒1，实际20挡；威胁83→59。F43升级触媒与F45普通触媒分开。',
 'F43胜局净损57、F44回血后仍败；能力持有与计划不等于已经建立，胜局不等于各组件的因果收益。',
 '已有逐牌属性、临时减力和资源事实接口；只保留现场已知值与条件投影。',
 '缺十五机制逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者的联合固定校准；本批未核出可单独实现的新确定失配。',
 '逐机制建立带角色/进阶/原帧/生产输入的校准矩阵；所有机制和三个消费者都满足后再认整体交付，不能以局部源码或历史绿替代。'),
('SL与护栏预测、派发和执行审计', '8JRE1C4H4Z2W F17T6、F33首/三试T2、第二试T5、末试T11',
 '首/三试T2原指纹相同，原推演0/24与替线5/24死亡不同；整轮实际损3/15、扣10/17。',
 '末试T2改防御省3血少10伤、延到T11仍败；不能一律认防御替换错误。末轮实际截断损5不等于完整需损15。',
 '已有answer/before_sl/after_sl、护栏预测差与派发回执，离线消费者能记部分观测端点；完整候选归属仍为空。',
 '缺跨抽牌、选牌、生成、药水重问与SL的实际候选持续归属及完整生产校准；可核整轮端点不能认证某条候选完整收益。',
 '冻结首/三试T2、第二试T5、F17T6、末试T11，逐阶段和回执核验；补齐持续归属后再验被打断的续步，不改探索/护栏阈值。'),
('力量、敏捷、虚弱与蚌成长', 'CA5KE8GFJ9X2 F13T1/T3/T5',
 '蚌力量0→4→8，喷水11→15→19；虚弱后11/14仍继续成长，末轮2血10挡未覆盖14来袭。',
 '本局没有正敏捷实测；没有取得计划中的步法，不能补成四路径联合校准。',
 '逐击力量、当前虚弱与独立成长分别核对，不新增统一保血或输出权重。',
 '本局无正敏捷实测；缺力量逐击、正负敏捷、虚弱和蚌独立成长在冻结生产调用中的联合对照。',
 '使用已观察属性组合和当前A10数据库冻结输入分别验算；未知属性组合保持unknown，等待可核正敏捷与完整路径对照。'),
('构筑持有、计划与启动兑现', '5PM6JAQG6FNQ F33、F39末试T2',
 'F39末试无毒目标上冒泡实际能量5→4，目标35血/0毒不变、玩家HP29不变。',
 'F33曾建立毒雾3/触媒1/群蛇4并赢；敌人、资源和生存条件不同，不能定统一启动顺序。',
 '持有/计划/已建立分列；局部无效与整轮、整战收益分开。',
 '缺同起始HP、构筑、药水与完整抽序下不同启动顺序的受控整战比较及可复现收益函数；一步无效不足拟合启动优先级或血价。',
 '先冻结施放时点与能力/毒端点，再按独立局和时间划分验证完整顺序；未建立能力不预支未来收益。'),
('族母吸取、负敏捷、毒与SL', '61E2QS63Y9WU F17T5—T7',
 '吸取前后玩家力量2→0、敏捷0→−2，敌力量0→2；负敏捷阶段敌HP67→34与毒结算分账。',
 '本局首试60血七轮获胜，不能据此改变SL范围，也不能将另一局重打失败归于固定顺序。',
 '保留分项机制与原SL适用范围；没有另一完整实打线路的胜率结论。',
 '缺A10同HP、构筑、完整抽序下另一可核SL全战线路及生产配对；首试胜局和毒端点不足改变SL门槛。',
 '冻结负属性与毒逐次减层，独立核验完整SL线路；未知抽序、缺帧和未结算毒不能补全。'),
('胧光怪召唤、成长和退场', '61E2QS63Y9WU F23T4/T5',
 'T4本体线47伤/15损兑现，幻象14→2仍在场、力量3→6；T5才结束幻象。',
 '39伤/零损的另一focus候选未实打，不能宣称整战更优或强制首杀。',
 '已有召唤与当前进阶数据接口；全部目标保留，相同推演值并列。',
 '缺A10召唤、航行、复现与退场全链的冻结生产联合校准及另一focus完整后继；局部召唤实现不足证明目标排序整战收益。',
 '逐实体核召唤、成长、再召唤和退场，不按重排index补实体身份；比较完整后继后才能提目标规则。'),
('熟睡甲虫醒来、临减与成长', 'DUZUBAJ3A8GP F30末试T1—T6及首试T4',
 '末试睡3/2/1后T4醒；T5力量2/攻击20，尖啸后−4/14，T6恢复并成长4/22。',
 '末试T4比首试多扣3敌血、多损2玩家血；四个相关失败尝试不是四个独立局，也不提供胜线。',
 '按当前进阶及睡眠/眩晕/成长分别验证，保留全部选项。',
 '缺伤害唤醒、眩晕接续和A10成长全链的生产校准及同抽换序完整后继；四个失败尝试不足拟合杀序、胜率或输出血价。',
 '冻结睡层和实际受击/自然醒两条来源，各自核眩晕及成长后续；另需同抽换序完整线路，不以自然醒补全伤害醒分支。'),
]
assert len(details) == len(proposals) == 10
results, proposal_lines = [], ['# 静默十项原提案逐项核验与处置', '', f'记录时间：{timestamp}。本批20261017-201301-strategy-proposal；角色silent，证据六局均A10。',
 '本文件补充原提案的本批处置，不覆盖原Markdown、不新建重复提案id。原字节和SHA见original-proposals/及original-markdown-checks.json。']
for (ident, item), d in zip(proposals.items(), details):
    title, evidence, support, counter, behavior, missing, validation = d
    original = item['original']
    results.append({'id': ident, 'state': 'waiting', 'reason': missing})
    proposal_lines += ['', '## ' + ident + '：' + title, '',
       '来源任务：' + original['source_task'] + '；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。',
       '账本：' + '、'.join(original['ledger']) + '。证据局/层/回合：' + evidence + '。',
       '本次核实：' + support, '反例与边界：' + counter,
       '旧规则/现状及预期行为：' + behavior,
       '本次处置：waiting。' + missing,
       '验证方法：' + validation,
       '拟合与时间切分：本次仅为已用发现样本的确定性复核，不拟合阈值；后续独立静默局按结束时间后移验证，同局SL不扩分母。',
       '预期影响与回退：待证据补齐后再评估对应实现，不承诺整战转胜。本批无源码/知识改动，无生产回退操作；后续若实现，须撤源码失败/恢复通过、自测、实际live合入及版本通知，保留历史材料。']
(OUT / 'proposal.md').write_text('\n'.join(proposal_lines) + '\n')
report = ['# 静默策略批次核验报告', '', f'记录时间：{timestamp}。batch=20261017-201301-strategy-proposal；character=silent。',
 '', '本批10项均waiting。六局原证据及现有部分实现仍缺各原提案指定的持续执行归属、联合生产校准或同盘整战对照；未定位本批可实施的新确定源码失配。不新增源码/知识、源码提交、live合入、版本或shipped。',
 '', '## 身份与边界', '', f'完整base={sources["base"]}。开工status干净；必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol及learning-code-proposals已读。普通批合并main结果Already up to date。',
 'learn.json仅本批对应行保存dispatch.json：task/character/worktree/runs与十proposal_ids一致，reason=proposal；没有research_request/implementation_request/proposal_repair。普通专题根请求绑定其他旧batch，不承接该专题。未领取其他队列id、不派下级agent。',
 '六局runs.jsonl均SILENT/A10，实际运行code均带dirty；当前Git不能恢复当时全部脏源码、知识、随机池。只读本角色证据及关联静默经验。没有将其他角色私有知识或预训练游戏事实作为依据。',
 '', '## 原始证据与固定核验', '', '共用extract_evidence.py按显式run_id/state.run_id/run/fingerprint.run提取；身份冲突拒收，正文提及不算所属。逐流冻结source_size，逐所属行offset/bytes/SHA及JSON重新读取原日志核同。旧报告不覆盖，无需复核旧截点。',
 '', '| 流 | 冻结字节数 | 逐原行核同 |', '|---|---:|---:|']
report += [f'| {s["stream"]} | {s["source_size"]} | {s["verified_lines"]} |' for s in raw_checks]
report += ['', f'合计{sum(s["verified_lines"] for s in raw_checks)}条；详见evidence/evidence-manifest.json及raw-readback-verification.json。全源无效/未完整行不能归为本批六局损坏。',
 f'本次固定原帧事实检查{len(facts)}项全部核同，包括六个神化夹具原帧；fact-checks.json保留实际值与证据行。这是数据核验，不是生产tsc/vitest或源码撤改负控。复用的检查脚本保存原路径/SHA，本次重新运行结果独立保存。',
 '', '## 现有消费者的限定读回', '', '由本批原始行构造固定有界输入，保留真实decision_id/observed_ts/fingerprint/_line及SL身份，不补空身份。调用本基线learner/lib/selection-execution.ts；只做离线审计，不调LLM、网络、求解器或游戏。',
 '', '| 局 | 层 | 决策/状态 | 候选片段 | 整轮端点 | 完整候选认证 |', '|---|---|---:|---:|---:|---:|']
report += [f'| {c["run_id"]} | {",".join(map(str,c["scope_floors"]))} | {c["decisions"]}/{c["states"]} | {c["candidate_segments"]} | {c["observed_turn_endpoints"]} | {c["certified_complete_candidates"]} |' for c in consumers]
report += ['', '逐输入与输出SHA、拒收或排除原因见consumer-input-manifest.json及consumer-readback.json。端点和整轮净变化不能归因于单条候选；完整候选认证为0不表示没有实打或收益。输入只覆盖上表楼层，不能冒称全部六局全链已校准。',
 '', '## 源码及实际live边界', '', f'只读live快照={sources["live_snapshot"]}。18条精确源码路径的base/live blob及SHA保存在source-verification.json；base.diff.patch为空。没有整仓归档或额外源码检出。',
 '已观察普通神化的17种窄配对与手牌/后抽传播不等于完整施放持续归属；silent-apotheosis-reference.ts明确actual_cast_this_fight=null。选择审计的actual_turn=null，离线端点也不认证完整候选。',
 '以下既有窄项只作为祖先源码证明，不是本批实现或新合入：']
report += [f'- {c["commit"]}：base祖先={c["base_ancestor"]}，live快照祖先={c["live_ancestor"]}。' for c in sources['narrow_sources']]
report += ['', '## 每项处置', '', '| id | 状态 | 具体缺口 |', '|---|---|---|']
report += [f'| {r["id"]} | waiting | {r["reason"]} |' for r in results]
report += ['', f'逐项证据局/层/回合、账本id、反例、旧/预期行为及验证方法：{OUT / "proposal.md"}。',
 '', '## 记录、测试和限制', '',
 '仅经根learner/ledger.py update追加本角色既有账本的proposal/report追溯及by=learner:strategy-proposal说明；不添加重复support、不改claim/首证/prior/进阶/经验/版本，不降级既有shipped状态。没有新游戏知识或新代码提案，沿用十个实际CLI id；队列处置由最终proposal_results交调度器，不手改learn.json或队列。实际CLI输入、回执、原前缀SHA及追加行读回另存ledger-*材料。',
 '无生产源码改动，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；没有提交，故没有提交前测试或gitleaks成功可报告。不运行合入live、知识刷新、版本分配、play或游戏API。其他角色行为保持等价。',
 '六局均是旧发现样本，不是时间后移独立验证。相关SL不扩独立局数。dirty运行树、缺随机池、未选候选完整后继及未知属性组合不补齐。不将持有/计划当施放，不将抽样中位当实抽，不将预测并列当同死率，不将零血截断当完整伤害。',
 '本批未得到与旧知识冲突的新结论，无新增异议或代角色确认。经验入库、生产大脑采用、科学效果与父要求完成均不能从本报告、排队或局部源码推断。',
 f'交运维提案：{OUT / "proposal.md"}。最终报告：{OUT / "report.md"}。']
(OUT / 'report.md').write_text('\n'.join(report) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-201301-strategy-proposal',
          'base': sources['base'], 'runs': dispatch['runs'], 'fixes': [],
          'skipped': list(proposals), 'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': list(proposals), 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'waiting': len(results), 'report': result['report'], 'base': result['base']}, ensure_ascii=False))

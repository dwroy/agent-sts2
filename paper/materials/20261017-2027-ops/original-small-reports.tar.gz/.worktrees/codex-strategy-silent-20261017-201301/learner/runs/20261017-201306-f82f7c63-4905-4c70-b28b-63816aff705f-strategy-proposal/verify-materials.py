import collections
import gzip
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
WT = OUT.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
OLD = ROOT / '.worktrees/codex-strategy-silent-20261017-181302/learner/runs/20261017-181305-01d7e739-9cd2-4b00-82a9-cb6fc60bcc76-strategy-proposal'


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WT).decode().strip()


def ancestor(commit, head):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', commit, head], cwd=WT).returncode == 0


base, live = git('rev-parse', 'HEAD'), git('rev-parse', 'live')
prior = json.loads((OLD / 'source-verification.json').read_text())
source = []
for entry in prior['files']:
    path = entry['path']
    raw = (WT / path).read_bytes()
    live_raw = subprocess.check_output(['git', 'show', live + ':' + path], cwd=WT)
    source.append({'path': path, 'base_blob': git('rev-parse', base + ':' + path),
                   'live_blob': git('rev-parse', live + ':' + path),
                   'sha256': hashlib.sha256(raw).hexdigest(),
                   'live_sha256': hashlib.sha256(live_raw).hexdigest(),
                   'same_base_live': raw == live_raw,
                   'same_previous_report_source': hashlib.sha256(raw).hexdigest() == entry['sha256']})
narrow = [{'commit': e['commit'], 'base_ancestor': ancestor(e['commit'], base),
           'live_ancestor': ancestor(e['commit'], live)} for e in prior['narrow_sources']]
save('source-verification.json', {'base': base, 'live_snapshot': live, 'files': source, 'narrow_sources': narrow})
(OUT / 'base.diff.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', base], cwd=WT))
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())
(OUT / 'original-proposals').mkdir(exist_ok=True)
for ident, item in proposals.items():
    original = item['original']
    raw = Path(original['proposal']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == original['proposal_sha256']
    (OUT / 'original-proposals' / (ident + '.md')).write_bytes(raw)
ids = {i for item in proposals.values() for i in item['original'].get('experience', [])}
experience = json.loads((WT / 'knowledge/characters/silent/experience.json').read_text())
def walk(value):
    if isinstance(value, dict):
        if value.get('id') in ids:
            yield value
        else:
            for child in value.values():
                yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)
save('linked-silent-experience.json', list(walk(experience)))

spec = importlib.util.spec_from_file_location('extract', WT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
runs = [r['run_id'] for r in json.loads((OUT / 'verified-runs.json').read_text())]
selected, checks = {}, []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    counts, entries = collections.Counter(), []
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as handle:
        for line in path.open():
            e = json.loads(line)
            assert e['source'] == str(ROOT / 'logs' / (name + '.jsonl'))
            assert e['offset'] + e['bytes'] <= stream['source_size']
            handle.seek(e['offset'])
            raw = handle.read(e['bytes'])
            assert len(raw) == e['bytes'] and raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == e['sha256']
            assert json.loads(raw) == e['row']
            assert extract.run_identity(e['row']) == e['run_id'] in runs
            counts[e['run_id']] += 1
            entries.append(e)
    assert {r: counts[r] for r in runs} == stream['counts']
    checks.append({'stream': name, 'source_size': stream['source_size'], 'verified_lines': sum(counts.values()), 'counts': dict(counts), 'ok': True})
    selected[name] = entries
save('raw-readback-verification.json', checks)
scope = {'VLZ6CCT8AQ0A': [35, 36, 37, 43, 44, 45], '8JRE1C4H4Z2W': [17, 33],
         'CA5KE8GFJ9X2': [5, 9, 13], '5PM6JAQG6FNQ': [33, 38, 39],
         '61E2QS63Y9WU': [17, 23, 28], 'DUZUBAJ3A8GP': [27, 28, 29, 30]}
inputs = []
for run, floors in scope.items():
    ss = [e for e in selected['states'] if e['run_id'] == run and e['row'].get('state', {}).get('run', {}).get('floor') in floors]
    dd = [e for e in selected['decisions'] if e['run_id'] == run and e['row'].get('floor') in floors]
    data = {'run': next(e['row'] for e in selected['runs'] if e['run_id'] == run),
            'decisions': [dict(e['row'], _line=e['line']) for e in dd],
            'states': [dict(e['row'], _line=e['line']) for e in ss]}
    raw = json.dumps(data, ensure_ascii=False).encode()
    (OUT / (run + '.consumer-input.json.gz')).write_bytes(gzip.compress(raw, mtime=0))
    inputs.append({'run_id': run, 'scope_floors': floors, 'decisions': len(dd), 'states': len(ss),
                   'missing_decision_id_lines': [e['line'] for e in dd if not e['row'].get('decision_id')],
                   'input_bytes': len(raw), 'input_sha256': hashlib.sha256(raw).hexdigest()})
save('consumer-input-manifest.json', inputs)
print(json.dumps({'verified_lines': sum(e['verified_lines'] for e in checks), 'streams': checks,
                  'source_files': len(source), 'consumer_inputs': inputs}, ensure_ascii=False))

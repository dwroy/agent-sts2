import gzip
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
ss = {e['line']: e['row'] for e in map(json.loads, (OUT / 'evidence/states.evidence.jsonl').open())}
dd = {e['line']: e['row'] for e in map(json.loads, (OUT / 'evidence/decisions.evidence.jsonl').open())}
checks = []

def check(name, actual, expected, refs):
    entry = {'name': name, 'actual': actual, 'expected': expected, 'source_refs': refs, 'ok': actual == expected}
    checks.append(entry)

def state(line):
    return ss[line]['state']

def player(line):
    return state(line)['combat']['player']

def enemy(line, ident=None):
    entries = state(line)['combat']['enemies']
    return entries[0] if ident is None else next(e for e in entries if e['enemy_id'] == ident)

def power(item, ident):
    assert isinstance(item['powers'], list)
    return next((p['amount'] for p in item['powers'] if p['power_id'] == ident), 0)

def attack(item):
    return sum(i.get('total_damage') or 0 for i in item['intents'])

fixture = json.loads((WORKTREE / 'agent/tests/silent-apotheosis-evidence.json').read_text())
for name, ref in fixture['source_lines'].items():
    combat = state(int(ref))['combat']
    check('神化固定夹具原帧一致：' + name, {k: combat[k] for k in fixture['frames'][name]}, fixture['frames'][name], ['states:' + ref])
check('F35神化实付能量', player(275565)['energy'] - player(275564)['energy'], -2, ['states:275564', 'states:275565'])
check('F43神化实付能量', player(275680)['energy'] - player(275679)['energy'], -2, ['states:275679', 'states:275680'])
check('F43T1整轮玩家与敌血端点', [player(275687)['current_hp'] - player(275679)['current_hp'], enemy(275687)['current_hp'] - enemy(275679)['current_hp']], [-13, -51], ['states:275679', 'states:275687'])
for line, expected in [(269706, [43, 14]), (269707, [51, 13])]:
    row = dd[line]
    selected = json.loads(row['questions']['plan']['criteria'][row['answers']['plan']['choice']])
    check('F43候选预测：' + str(line), [selected['damage_dealt'], selected['hp_lost']], expected, ['decisions:' + str(line)])
mc = dd[269748]['potions']['random'][0]
check('F45首题MC未成熟', [mc['ms'], mc['samples'], mc['requested'], mc['degraded']], [707, 1, 12, True], ['decisions:269748'])
check('F45末轮属性分源', [power(player(275754), p) for p in ['FASTEN_POWER', 'DEXTERITY_POWER', 'PLATING_POWER', 'ACCELERANT_POWER']], [4, 3, 0, 1], ['states:275754'])
check('F45末轮来袭与玩家资源', [sum(attack(e) for e in state(275754)['combat']['enemies']), player(275754)['block'], player(275754)['current_hp']], [59, 20, 32], ['states:275754'])
check('F45尖啸逐段威胁变化', [sum(attack(e) for e in state(n)['combat']['enemies']) for n in [275752, 275754]], [83, 59], ['states:275752', 'states:275754'])
check('F33首与第三试T2同指纹', dd[270216]['fingerprint'] == dd[270282]['fingerprint'], True, ['decisions:270216', 'decisions:270282'])
check('F33原答与SL替线预测保留不同死率', [dd[270282]['sl_explore']['numbers']['original'].startswith('rollout dead 0/24'), dd[270282]['sl_explore']['numbers']['replacement'].startswith('rollout dead 5/24')], [True, True], ['decisions:270282'])
audit = json.loads(gzip.decompress((OUT / '8JRE1C4H4Z2W.consumer-output.json.gz').read_bytes()))
for attempt, expected in [(1, [-3, -10]), (3, [-15, -17])]:
    t = next(t for t in audit['observed_turns'] if t['floor'] == 33 and t['turn'] == 2 and t['attempt'] == attempt)
    f = t['facts']
    check('F33T2整轮观测端点：尝试' + str(attempt), [f['player_hp_delta'], f['enemy_hp_changes'][0]['hp_delta']], expected, [a['source_line'] for a in t['decisions']])
check('F33旧护栏在理由而非结构字段', ['HP guard:' in dd[270264]['rationale'], dd[270264].get('hp_guard')], [True, None], ['decisions:270264'])
check('蚌T1/3/5力量与喷水', [[power(enemy(n), 'STRENGTH_POWER'), attack(enemy(n))] for n in [273237, 273252, 273263]], [[0, 11], [4, 15], [8, 19]], ['states:273237', 'states:273252', 'states:273263'])
check('蚌虚弱后仍有成长', [attack(enemy(n)) for n in [273254, 273268]], [11, 14], ['states:273254', 'states:273268'])
check('F39无毒冒泡局部资源端点', [[player(n)['current_hp'], player(n)['energy'], enemy(n)['current_hp'], power(enemy(n), 'POISON_POWER')] for n in [274379, 274380]], [[29, 5, 35, 0], [29, 4, 35, 0]], ['states:274379', 'states:274380'])
check('族母吸取前后属性', [[power(player(n), 'STRENGTH_POWER'), power(player(n), 'DEXTERITY_POWER'), power(enemy(n), 'STRENGTH_POWER')] for n in [273502, 273504]], [[2, 0, 0], [0, -2, 2]], ['states:273502', 'states:273504'])
check('族母负敏捷阶段敌血端点', [enemy(n)['current_hp'] for n in [273504, 273508]], [67, 34], ['states:273504', 'states:273508'])
check('胧光怪幻象仍存活且成长', [[enemy(n, 'PARAFRIGHT')['current_hp'], power(enemy(n, 'PARAFRIGHT'), 'STRENGTH_POWER')] for n in [273593, 273596]], [[14, 3], [2, 6]], ['states:273593', 'states:273596'])
check('甲虫末试自然睡层', [power(enemy(n, 'SLUMBERING_BEETLE'), 'SLUMBER_POWER') for n in [274991, 274998, 275003, 275007]], [3, 2, 1, 0], ['states:274991', 'states:274998', 'states:275003', 'states:275007'])
check('甲虫末试临减与恢复成长', [[power(enemy(n, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER'), attack(enemy(n, 'SLUMBERING_BEETLE'))] for n in [275013, 275016, 275018]], [[2, 20], [-4, 14], [4, 22]], ['states:275013', 'states:275016', 'states:275018'])
for c in checks:
    if c['name'].startswith('神化固定夹具原帧一致'):
        for k in ['actual', 'expected']:
            c[k + '_sha256'] = hashlib.sha256(json.dumps(c[k], ensure_ascii=False, sort_keys=True).encode()).hexdigest()
            del c[k]
(OUT / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'passed': sum(c['ok'] for c in checks), 'failed': [c for c in checks if not c['ok']]}, ensure_ascii=False))
assert all(c['ok'] for c in checks)

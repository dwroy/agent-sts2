# 静默策略批次核验报告

记录时间：2026-10-17T20:24:42+08:00。batch=20261017-201301-strategy-proposal；character=silent。

本批10项均waiting。六局原证据及现有部分实现仍缺各原提案指定的持续执行归属、联合生产校准或同盘整战对照；未定位本批可实施的新确定源码失配。不新增源码/知识、源码提交、live合入、版本或shipped。

## 身份与边界

完整base=c0a1108ed51fbf6e8c7fc5a2aa238d57cdd0366a。开工status干净；必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol及learning-code-proposals已读。普通批合并main结果Already up to date。
learn.json仅本批对应行保存dispatch.json：task/character/worktree/runs与十proposal_ids一致，reason=proposal；没有research_request/implementation_request/proposal_repair。普通专题根请求绑定其他旧batch，不承接该专题。未领取其他队列id、不派下级agent。
六局runs.jsonl均SILENT/A10，实际运行code均带dirty；当前Git不能恢复当时全部脏源码、知识、随机池。只读本角色证据及关联静默经验。没有将其他角色私有知识或预训练游戏事实作为依据。

## 原始证据与固定核验

共用extract_evidence.py按显式run_id/state.run_id/run/fingerprint.run提取；身份冲突拒收，正文提及不算所属。逐流冻结source_size，逐所属行offset/bytes/SHA及JSON重新读取原日志核同。旧报告不覆盖，无需复核旧截点。

| 流 | 冻结字节数 | 逐原行核同 |
|---|---:|---:|
| runs | 362114 | 6 |
| states | 14032996508 | 3432 |
| decisions | 2326618889 | 3306 |
| sl-attempts | 46033678 | 29 |
| run-config | 1986443 | 6 |
| run-plans | 9036137 | 33 |
| brain | 766513811 | 183 |

合计6995条；详见evidence/evidence-manifest.json及raw-readback-verification.json。全源无效/未完整行不能归为本批六局损坏。
本次固定原帧事实检查28项全部核同，包括六个神化夹具原帧；fact-checks.json保留实际值与证据行。这是数据核验，不是生产tsc/vitest或源码撤改负控。复用的检查脚本保存原路径/SHA，本次重新运行结果独立保存。

## 现有消费者的限定读回

由本批原始行构造固定有界输入，保留真实decision_id/observed_ts/fingerprint/_line及SL身份，不补空身份。调用本基线learner/lib/selection-execution.ts；只做离线审计，不调LLM、网络、求解器或游戏。

| 局 | 层 | 决策/状态 | 候选片段 | 整轮端点 | 完整候选认证 |
|---|---|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 35,36,37,43,44,45 | 165/174 | 27 | 0 | 0 |
| 8JRE1C4H4Z2W | 17,33 | 277/280 | 66 | 44 | 0 |
| CA5KE8GFJ9X2 | 5,9,13 | 106/115 | 22 | 0 | 0 |
| 5PM6JAQG6FNQ | 33,38,39 | 152/157 | 26 | 10 | 0 |
| 61E2QS63Y9WU | 17,23,28 | 125/129 | 22 | 10 | 0 |
| DUZUBAJ3A8GP | 27,28,29,30 | 208/213 | 38 | 17 | 0 |

逐输入与输出SHA、拒收或排除原因见consumer-input-manifest.json及consumer-readback.json。端点和整轮净变化不能归因于单条候选；完整候选认证为0不表示没有实打或收益。输入只覆盖上表楼层，不能冒称全部六局全链已校准。

## 源码及实际live边界

只读live快照=3d691cff96dedd19855b00f4e9d448c43fe1d219。18条精确源码路径的base/live blob及SHA保存在source-verification.json；base.diff.patch为空。没有整仓归档或额外源码检出。
已观察普通神化的17种窄配对与手牌/后抽传播不等于完整施放持续归属；silent-apotheosis-reference.ts明确actual_cast_this_fight=null。选择审计的actual_turn=null，离线端点也不认证完整候选。
以下既有窄项只作为祖先源码证明，不是本批实现或新合入：
- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：base祖先=True，live快照祖先=True。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：base祖先=True，live快照祖先=True。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：base祖先=True，live快照祖先=True。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：base祖先=True，live快照祖先=True。
- cf72bd21148059f111f760cc98a727369e34a47e：base祖先=True，live快照祖先=True。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：base祖先=True，live快照祖先=True。

## 每项处置

| id | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整生产消费认证；已有窄升级传播不足将整项认定实现。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺模型充分覆盖下同起点、同随机池、同总预算的MC策略配对与样本成熟度曲线；707ms单题不能确定新预算或留药常量。 |
| silent-proposal-283a164780d11e69 | waiting | 与89354805ee4d7e77同源，仍缺实际施放持续身份及后续生产消费认证；同源和窄实现均不足登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五机制逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者的联合固定校准；本批未核出可单独实现的新确定失配。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨抽牌、选牌、生成、药水重问与SL的实际候选持续归属及完整生产校准；可核整轮端点不能认证某条候选完整收益。 |
| silent-proposal-49632bc4878fb597 | waiting | 本局无正敏捷实测；缺力量逐击、正负敏捷、虚弱和蚌独立成长在冻结生产调用中的联合对照。 |
| silent-proposal-66532328a585941f | waiting | 缺同起始HP、构筑、药水与完整抽序下不同启动顺序的受控整战比较及可复现收益函数；一步无效不足拟合启动优先级或血价。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同HP、构筑、完整抽序下另一可核SL全战线路及生产配对；首试胜局和毒端点不足改变SL门槛。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行、复现与退场全链的冻结生产联合校准及另一focus完整后继；局部召唤实现不足证明目标排序整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续和A10成长全链的生产校准及同抽换序完整后继；四个失败尝试不足拟合杀序、胜率或输出血价。 |

逐项证据局/层/回合、账本id、反例、旧/预期行为及验证方法：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-201301/learner/runs/20261017-201306-f82f7c63-4905-4c70-b28b-63816aff705f-strategy-proposal/proposal.md。

## 记录、测试和限制

仅经根learner/ledger.py update追加本角色既有账本的proposal/report追溯及by=learner:strategy-proposal说明；不添加重复support、不改claim/首证/prior/进阶/经验/版本，不降级既有shipped状态。没有新游戏知识或新代码提案，沿用十个实际CLI id；队列处置由最终proposal_results交调度器，不手改learn.json或队列。实际CLI输入、回执、原前缀SHA及追加行读回另存ledger-*材料。
无生产源码改动，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；没有提交，故没有提交前测试或gitleaks成功可报告。不运行合入live、知识刷新、版本分配、play或游戏API。其他角色行为保持等价。
六局均是旧发现样本，不是时间后移独立验证。相关SL不扩独立局数。dirty运行树、缺随机池、未选候选完整后继及未知属性组合不补齐。不将持有/计划当施放，不将抽样中位当实抽，不将预测并列当同死率，不将零血截断当完整伤害。
本批未得到与旧知识冲突的新结论，无新增异议或代角色确认。经验入库、生产大脑采用、科学效果与父要求完成均不能从本报告、排队或局部源码推断。
交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-201301/learner/runs/20261017-201306-f82f7c63-4905-4c70-b28b-63816aff705f-strategy-proposal/proposal.md。最终报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-201301/learner/runs/20261017-201306-f82f7c63-4905-4c70-b28b-63816aff705f-strategy-proposal/report.md。

最终账本读回：根CLI实际追加26条追溯；逐offset/bytes/SHA读回一致，原23182757字节前缀SHA保持。此次实际行只含op/id/ts/by/where/note，未改claim/evidence/status/version等保护字段；并行原行保留。见ledger-readback.json。

import fcntl
import hashlib
import json
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
ledger = ROOT / 'paper/materials/learning/ledger.jsonl'
batch = '20261017-201301-strategy-proposal'
subprocess.run(['date', '+%Y-%m-%dT%H:%M:%S%:z'], check=True)
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())
results = json.loads((OUT / 'result.json').read_text())
assert set(proposals) == {r['id'] for r in results['proposal_results']}
assert all(r['state'] == 'waiting' for r in results['proposal_results'])
assert (OUT / 'proposal.md').is_file() and (OUT / 'report.md').is_file()
linked = {}
for ident, item in proposals.items():
    for lid in item['original']['ledger']:
        linked.setdefault(lid, []).append(ident)
changes = [{'id': lid, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': batch + '：核对本角色原提案' + '、'.join(ids) + '；本批仍waiting，具体缺口见报告。仅补追溯，不加重复support，不改变原断言、首证、计数或上线状态。'}
           for lid, ids in sorted(linked.items())]
raw_input = ''.join(json.dumps(c, ensure_ascii=False) + '\n' for c in changes).encode()
(OUT / 'ledger-update-input.jsonl').write_bytes(raw_input)
with ledger.open('rb') as handle:
    fcntl.flock(handle, fcntl.LOCK_SH)
    prefix = handle.read()
before = {'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest()}
(OUT / 'ledger-prefix-before.json').write_text(json.dumps(before, indent=2) + '\n')
result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'], input=raw_input, capture_output=True)
(OUT / 'ledger-update.stdout.txt').write_bytes(result.stdout)
(OUT / 'ledger-update.stderr.txt').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode()
with ledger.open('rb') as handle:
    fcntl.flock(handle, fcntl.LOCK_SH)
    assert hashlib.sha256(handle.read(before['bytes'])).hexdigest() == before['sha256']
    tail = handle.read()
offset = before['bytes']
own = []
for raw in tail.splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith(batch + '：'):
        assert set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'}
        expected = next(c for c in changes if c['id'] == row['id'])
        for k, value in expected.items():
            assert row[k] == value
        own.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                    'sha256': hashlib.sha256(raw).hexdigest()})
    offset += len(raw)
assert {x['id'] for x in own} == set(linked) and len(own) == len(linked)
verification = {'prefix_unchanged': True, 'prefix': before, 'cli_exit_code': result.returncode,
                'updates': len(own), 'rows': own,
                'own_rows_changed_only_trace_fields': True,
                'concurrent_rows_preserved': len(tail.splitlines()) - len(own)}
(OUT / 'ledger-readback.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'report.md').open('a') as handle:
    handle.write('\n最终账本读回：根CLI实际追加' + str(len(own)) + '条追溯；逐offset/bytes/SHA读回一致，原'
                 + str(before['bytes']) + '字节前缀SHA保持。此次实际行只含op/id/ts/by/where/note，未改claim/evidence/status/version等保护字段；并行原行保留。见ledger-readback.json。\n')
print(json.dumps({'updates': len(own), 'prefix_unchanged': True, 'cli_exit_code': result.returncode}, ensure_ascii=False))

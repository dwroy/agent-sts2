import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()]
with (p/'details.txt').open('w') as out:
 def pr(*a):print(*a,file=out)
 for r in B:
  if r['label'] in ['map/route-plan','rest/plan','event/act-plan']:
   pay=r['payload'];facts=pay.get('facts',{})
   pr('B',r['_source_line'],r['label'],'factkeys',list(facts))
   for k,v in facts.items():
    if any(x in k for x in ['route','clock','projection']):pr(k,v)
 for r in D:
  if r['_source_line']==412451:
   pr('F32BASE',r['boss_sim']['base']);pr('F32UPGRADE',r['boss_sim']['options'].get('o1:c25'));pr('F32HEAL',r['boss_sim']['options'].get('o0'))
 fc=[];pc=[]
 for r in D:
  if 'plan-choice' not in r['label']:continue
  opt={k:json.loads(v) for k,v in r['questions']['plan']['criteria'].items() if k.startswith('plan')}
  foc={k:v['focus'] for k,v in opt.items() if 'focus' in v}
  if foc:
   fc.append(r['_source_line']);key=r.get('answers',{}).get('plan',{}).get('choice')
   if key in foc:pc.append((r['_source_line'],r['floor'],r['turn'],foc[key]))
 pr('FOCUS-COUNTS',len(fc),len(pc),pc)
 auto=[r for r in D if r['decider']=='code' and r['label'].startswith('combat/') and not r.get('rationale','').startswith('continuing the Jev-chosen plan:')]
 at={(r['floor'],r['turn']) for r in auto};jt={(r['floor'],r['turn']) for r in D if r['decider']=='jev' and r['label'].startswith('combat/')};jpt={(r['floor'],r['turn']) for r in D if r['decider']=='jev' and 'plan-choice' in r['label']}
 pr('CODE-ALL',len(auto),'turns',len(at),'withoutjevcombat',len(at-jt),'withoutjevplan',len(at-jpt))
 for r in S:
  st=r['state'];f=st.get('run',{}).get('floor')
  if f in [8,18,19,20,25,30] and not st.get('in_combat') and st['screen'] in ['EVENT','REWARD']:
   rr=st['run'];pr('NONCOMBAT',r['_source_line'],f,rr['current_hp'],'deck',len(rr.get('deck',[])),'event',st.get('event'),'relics',[(x['name'],x['relic_id']) for x in rr.get('relics',[])])

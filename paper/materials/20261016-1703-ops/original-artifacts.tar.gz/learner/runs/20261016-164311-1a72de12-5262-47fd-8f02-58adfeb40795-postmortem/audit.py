import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()]
R=json.load((p/'0YQJ9D1MC4NK-resources.json').open())
def load(s):
 try:return json.loads(s)
 except:return s
def pr(*a):print(*a)
with (p/'audit.txt').open('w') as out:
 import contextlib
 with contextlib.redirect_stdout(out):
  jev=[r for r in D if r['decider']=='jev'];plans=[r for r in jev if 'plan-choice' in r['label']]
  pr('LOW',[(r['_source_line'],r['floor'],r['turn'],r['label'],r['confidence']) for r in jev if (r.get('confidence') or 0)<.35])
  pr('ROLL',len(plans),collections.Counter(r.get('rollout_best_chosen') for r in plans))
  cont=[r for r in D if r['decider']=='code' and r.get('rationale','').startswith('continuing the Jev-chosen plan:')]
  auto=[r for r in D if r['decider']=='code' and r not in cont and r['label'].startswith('combat/') and (r.get('result') or '').startswith('completed')]
  pr('CODE',len(cont),'autocombat',len(auto),'turns',len({(r['floor'],r.get('sl_attempt'),r['turn']) for r in auto}),collections.Counter(r['label'] for r in auto))
  pr('GUARDS')
  for r in D:
   if 'hp_guard' in r:pr(r['_source_line'],r['floor'],r['turn'],r['hp_guard'])
  pr('FOCUS')
  for r in plans:
   criteria=(r['questions'].get('plan') or {}).get('criteria') or {}
   opts={k:load(v) for k,v in criteria.items()};foc={k:v for k,v in opts.items() if isinstance(v,dict) and ('focus' in str(v).lower())}
   if foc:pr(r['_source_line'],r['floor'],r['turn'],'chosen',r.get('answers',{}).get('plan',{}).get('choice'),'focus', {k:{kk:vv for kk,vv in v.items() if 'focus' in kk.lower()} for k,v in foc.items()})
  pr('USAGE JEV',dict(sumcounter:=collections.Counter()))
  for k in ['input_tokens','output_tokens','cache_hit_tokens']:
   pr(k,sum((r.get('usage') or {}).get(k,0) or 0 for r in jev))
  pr('BRAIN',len(B),collections.Counter((r['engine'],r['model'],r['effort'],r.get('accepted')) for r in B))
  for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens']:pr(k,sum((r.get('usage') or {}).get(k,0) or 0 for r in B))
  dt=lambda t:datetime.datetime.fromisoformat(t.replace('Z','+00:00'))
  pr('TIMING',(dt(D[-1]['ts'])-dt(D[0]['ts'])).total_seconds(),'config',(dt(D[-1]['ts'])-dt(json.loads((p/'run-config.jsonl').read_text())['ts'])).total_seconds())
  pr('COMBAT-TURNS')
  for c in R['combats']:
   ss=[r for r in S if c['entry']['line']<=r['_source_line']<=c['exit']['line']]
   groups=collections.OrderedDict()
   for r in ss:groups.setdefault(r['state'].get('turn'),[]).append(r)
   records=[]
   for t,rs in groups.items():
    a,b=rs[0],rs[-1];nexts=next((r for r in ss if r['_source_line']>b['_source_line']),None)
    z=nexts or b
    ast=a['state'];zst=z['state']
    aa=(ast.get('combat') or {}).get('enemies') or [];zz=(zst.get('combat') or {}).get('enemies') or []
    ah=sum(e['current_hp'] for e in aa if e['is_alive']);zh=sum(e['current_hp'] for e in zz if e['is_alive'])
    records.append({'t':t,'lines':[a['_source_line'],z['_source_line']],'hp':[ast['run']['current_hp'],zst['run']['current_hp']],'enemy_live_hp':[ah,zh],'net_progress':ah-zh})
   pr('F',c['floor'],records)
  pr('POTION TRANSITIONS')
  for ev in R['resource_changes']:
   if ev['from']['potions']!=ev['to']['potions']:pr(ev)
  pr('F33 PLAN PRED')
  for r in plans:
   if r['floor']!=33:continue
   key=r.get('answers',{}).get('plan',{}).get('choice');val=load(r['questions']['plan']['criteria'].get(key,'{}'))
   pr(r['_source_line'],r['turn'],key,{k:val.get(k) for k in ['plays','damage_dealt','hp_lost','hp_after','sandpit_after_enemy_turn','potions_used']},'best',r.get('rollout_best_chosen'))
  pr('F32 rest option')
  r=next(r for r in D if r['_source_line']==412451)
  for k,v in r['questions']['pick']['criteria'].items():
   if k in ['o0','o1:c25']:
    z=load(v);pr(k,{kk:vv for kk,vv in z.items() if kk not in ['quantitative_fight']})
  pr('STATE33 RELICS AND DECK')
  st=next(r['state'] for r in S if r['_source_line']==426092)
  pr('relics',st['run']['relics']);pr('deck',[(c['card_id'],c['name'],c.get('upgraded')) for c in st['run']['deck']])

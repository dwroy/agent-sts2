import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()]
def powers(o):return {x['power_id']:x['amount'] for x in o.get('powers',[])}
with (p/'summary.txt').open('w') as w:
 def pr(*a):print(*a,file=w)
 pr('CONFIG',json.loads((p/'run-config.jsonl').read_text())['code'])
 pr('deciders',collections.Counter(r['decider'] for r in D))
 for r in D:
  if r['decider']=='codex':pr('BRAIN',r['_source_line'],r['floor'],r['label'],r['chosen'],r.get('rationale'))
  if r.get('journal',{}).get('hp_guard'):pr('GUARD',r['_source_line'],r['floor'],r['turn'],json.dumps(r['journal'],ensure_ascii=False))
 pr('JOURNAL sample',[(r['_source_line'],list(r.get('journal',{}))) for r in D if 'plan-choice' in r['label']][:3])
 for r in S:
  st=r['state'];c=st.get('combat') or {};f=st.get('run',{}).get('floor')
  if f==33:
   pr('STATE33',r['_source_line'],r['ts'],st.get('screen'),'T',st.get('turn'),'HP',st['run']['current_hp'],'PLAYER', {k:c.get('player',{}).get(k) for k in ['energy','block']},powers(c.get('player',{})),'HAND',[(x['index'],x['card_id'],x['upgraded']) for x in c.get('hand',[])],'ENEMY',[(e['current_hp'],e.get('block'),e.get('move_id'),powers(e),e.get('intents')) for e in c.get('enemies',[])])
 for r in D:
  if r['floor']==33:pr('D33',r['_source_line'],r['turn'],r['label'],r['chosen'],r.get('rationale'),json.dumps(r.get('journal'),ensure_ascii=False))
 for r in [json.loads(x) for x in (p/'run-plans.jsonl').open()]:pr('PLAN',r['_source_line'],r['floor'],r.get('trigger'),r.get('plan'))
 pr('POTIONS')
 for r in D:
  if 'potion' in str(r['chosen']) or ('reward/claim'==r['label']):pr('RESOURCE D',r['_source_line'],r['floor'],r['turn'],r['chosen'],r.get('rationale'))
for r in D:
 if r['floor']==33 and r['label']=='combat/play':
  print('SINGLE33',r['_source_line'],r['turn'],r['chosen'],r.get('rationale'),'journal',r.get('journal'),'result',r.get('result'))
print('saved summary',p/'summary.txt')

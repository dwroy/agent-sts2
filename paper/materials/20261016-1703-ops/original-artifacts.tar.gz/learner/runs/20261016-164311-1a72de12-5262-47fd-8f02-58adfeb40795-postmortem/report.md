## 复盘回报
- 已追加：0YQJ9D1MC4NK（A10，第33层，无厌沙虫沙坑归零；T7结束前50血11挡，敌结毒后仍147血）。
- 新的纯 bug（file:line）：
  - 无新增；0YQJ9D1MC4NK复现单动作题面漏报沙坑截止 — agent/src/reflex/combat.ts:100（只读live；fix-queue已有，silent-0308）。
- 写成「未记录」的项：0YQJ9D1MC4NK：完整dirty知识输入、部分多体退场及毛伤归因、完整逐体杀序、完整最优线兑现率、替线/留逃离/用药/改构筑休息的受控整战结果、未饮毒药水层数、旧boss时钟、纯战斗耗时、Jev真实缓存命中和实付费用。
- 学习账本：0YQJ9D1MC4NK：新增无；更新silent-0308、silent-0117、silent-0125、silent-0005、silent-0011、silent-0018、silent-0046（老错silent-0308）；ledger.py check退出码0。
- 代码提案（均关联独立strategy-proposal，未实现）：
  - F33T7／silent-0308、0018／silent-proposal-3707a98930a03d83：接入沙坑终局风险；不强制用药或SL。
  - F33T2／silent-0117、0018／silent-proposal-a4af65d94c109b89：核对弃逃离后的资源与方案后继；保留后的整战收益未知。
  - F33T5／silent-0125、0018／silent-proposal-e0784c4fc708da8e：审计护栏省11血、少6推进的取舍；证据不足，保留现规则。

```json
{
  "task": "postmortem",
  "appended": [
    "0YQJ9D1MC4NK"
  ],
  "skipped": [],
  "bugs": [
    {
      "run": "0YQJ9D1MC4NK",
      "where": "agent/src/reflex/combat.ts:100",
      "what": "单动作结束题面漏接沙坑截止，旧silent-0308复现；fix-queue-v4.md:912已有。",
      "new": false
    }
  ],
  "ledger": {
    "added": [],
    "updated": [
      "silent-0308",
      "silent-0117",
      "silent-0125",
      "silent-0005",
      "silent-0011",
      "silent-0018",
      "silent-0046"
    ],
    "repeats": [
      "silent-0308"
    ],
    "check": 0
  },
  "code_proposals": [
    "silent-proposal-3707a98930a03d83",
    "silent-proposal-a4af65d94c109b89",
    "silent-proposal-e0784c4fc708da8e"
  ],
  "implementation_domains": [
    "combat",
    "terminal"
  ],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-164311-1a72de12-5262-47fd-8f02-58adfeb40795-postmortem/report.md"
}
```

import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261016-164311-1a72de12-5262-47fd-8f02-58adfeb40795-postmortem'
run='0YQJ9D1MC4NK'
window=[]
for name in ['decisions','run-plans','states','sl-attempts','run-config','brain']:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists():continue
 n=0
 with p.open('rb') as f,(out/f'{name}.jsonl').open('w') as w:
  cutoff=p.stat().st_size;offset=0
  for ln,line in enumerate(f,1):
   start=offset;offset+=len(line)
   if offset>cutoff:break
   if run.encode() not in line:continue
   try:r=json.loads(line)
   except ValueError:continue
   if r.get('run_id',r.get('run'))!=run and r.get('state',{}).get('run_id')!=run:continue
   r['_source_line']=ln;r['_source_offset']=start
   w.write(json.dumps(r,ensure_ascii=False)+'\n');n+=1
   if name=='decisions':window.append(r['ts'])
 print(name,n,flush=True)
if window:
 lo,hi=min(window),max(window)
 p=root/'logs/deepseek-reasoning.jsonl';n=0
 if p.exists():
  with p.open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as w:
   cutoff=p.stat().st_size;off=0
   for ln,line in enumerate(f,1):
    start=off;off+=len(line)
    if off>cutoff:break
    try:r=json.loads(line)
    except ValueError:continue
    if lo<=str(r.get('ts',''))<=hi:
     r['_source_line']=ln;r['_source_offset']=start;w.write(json.dumps(r,ensure_ascii=False)+'\n');n+=1
 print('reasoning',n,'window',lo,hi,flush=True)

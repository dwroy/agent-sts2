import json,hashlib
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()]
d={r['_source_line']:r for r in D};s={r['_source_line']:r['state'] for r in S}
checks={}
checks['run_identity']=len(D)==516 and len(S)==533 and len(B)==35 and all(r.get('run_id')=='0YQJ9D1MC4NK' for r in D)
checks['entry_hp']=s[426091]['run']['current_hp']==63 and s[426091]['run']['max_hp']==70
checks['death']=s[426131]['run']['current_hp']==50 and s[426131]['combat']['player']['block']==11 and s[426132]['run']['current_hp']==0 and s[426132]['combat']['enemies'][0]['current_hp']==147
checks['five_false']=all(json.loads(d[n]['questions']['play']['criteria']['end_turn'])['lethal'] is False for n in range(412490,412495))
checks['predicted_40']=json.loads(d[412494]['questions']['play']['criteria']['end_turn'])['hp_after_enemy_turn']==40
checks['discard_escape']=d[412461]['expect']['option']['id']=='FRANTIC_ESCAPE' and d[412461]['confidence']==.36
checks['guard']=d[412479]['hp_guard']['predicted_hp_saved']==11 and d[412479]['hp_guard']['predicted_damage_change']==-6
checks['potion_actions']=len([r for r in D if r.get('chosen',{}).get('action')=='use_potion'])==5 and not any(r.get('chosen',{}).get('action')=='discard_potion' for r in D)
checks['rollout']=sum(r.get('rollout_best_chosen') is True for r in D)==134 and sum(r.get('rollout_best_chosen') is False for r in D)==3
checks['lowconfidence']=len([r for r in D if r['decider']=='jev' and r.get('confidence') is not None and r['confidence']<.35])==12
checks['brainusage']={k:sum(r['usage'].get(k,0) for r in B) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}=={'inputTokens':6540932,'outputTokens':42801,'cacheHitTokens':3328640,'reasoningTokens':37848}
R=json.load((p/'0YQJ9D1MC4NK-resources.json').open())
checks['resources']=len(R['combats'])==15 and all(c['entry_is_turn_one'] and c['exit'] is not None for c in R['combats'])
checks['hp_chain']=[(c['floor'],c['entry']['hp'],c['exit']['hp']) for c in R['combats']]==[(2,56,48),(5,48,47),(6,47,45),(7,45,42),(13,52,45),(15,45,30),(17,51,23),(19,60,23),(21,38,24),(25,45,9),(27,29,29),(28,29,24),(30,45,45),(31,65,63),(33,63,0)]
checks['no_sl_reload']=all(r['attempt']==1 and r.get('reload') is None for r in map(json.loads,(p/'sl-attempts.jsonl').open()))
first={}
for r in S:
 st=r['state']
 if st['run']['floor']==33 and st['in_combat']:first.setdefault(st['turn'],st)
ends=[first[t+1]['combat']['enemies'][0]['current_hp'] for t in range(1,7)]+[147]
checks['boss_progress']=[first[t]['combat']['enemies'][0]['current_hp']-ends[t-1] for t in range(1,8)]==[12,9,12,37,26,38,60]
checks['deck_37']=len(s[426092]['run']['deck'])==37
before=json.load((p/'lessons-before.json').open());cur=Path('/home/dw/Projects/agent-sts2/notes/lessons.md').read_bytes()
checks['old_lessons_unchanged']=hashlib.sha256(cur[:before['bytes']]).hexdigest()==before['sha256']
checks['one_section']=cur.count('## 0YQJ9D1MC4NK（'.encode())==1
section=cur[cur.index('## 0YQJ9D1MC4NK（'.encode()):].decode()
checks['written_key_numbers']=all(x in section for x in ['63/70','50血11挡','147/341','45毒','32伤、损12','26伤、损1','134/137','50.8894%','2851.407秒'])
(p/'verification.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False));assert all(checks.values())

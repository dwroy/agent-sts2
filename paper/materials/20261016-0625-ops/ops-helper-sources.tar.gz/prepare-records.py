from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,tarfile
sys.dont_write_bytecode=True
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0625';pub=r/'paper/materials/20261016-0625-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f):return json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'own-appends.json').exists();d=load(pub/'calibration-readback.json');pending=load(pub/'pending-publication-handoff.json');base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
rows=(p/'owned-learner-ledger.jsonl').read_bytes().splitlines(keepends=True);assert len(rows)==5;old=git('show',base+':paper/materials/learning/ledger.jsonl');existing=set(old.splitlines());added=b''.join(x for x in rows if x.rstrip(b'\n') not in existing)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added)
assert set(z)==set(a)|{'silent-0491'} and z['silent-0491']['status']=='proposed'
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['evidence','where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['evidence','where','history','notes']}
    for key in ['evidence','history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
assert z['silent-0484']['status']==a['silent-0484']['status'] and z['silent-0484']['version']==a['silent-0484']['version']
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
native=d['native_notice'];token=native['notice_id'];host=d['host'];rootpath=r/'notes/fix-queue-v4.md';marker='infra-feature-root-event-notice-path';assert marker not in rootpath.read_text()
notice=f'\n- {at} [ops原校准20实际接收/必要反证转交] source89b6391845eb28b774c23db6f4466160c25876ba→actual e138b036a79709f6217272e631324fd3e77e2bff→publication4dfac2702bf1ce63199d4579c7d5cda136f13d3d/tree6f1f2cb003239b798ee345c9137f4867acd96162，专题S1.boss-calibration20实际live；原87叶/source/live逐SHA核，生产源码delta0。旧THE_INSATIABLE B2 n43/打穿比1.296可信→新n44/1.316超过原1.3撤可信，B3继续低；证据VNSXWCWXR3VW A10 F33试1 T1—7实际胜，旧0484claim/43场发布/首证/先验/status/version保持并追加contradict，0491新项仍proposed。新增22实际结局16胜6死、固定107调参/460验证，模型/切点/Platt/门槛不改；发布树70模型输入SHA与冻结7e1193不同，不称当前生产重新校准/自然采用/收益。现有watcher wJ:pJT/01a13dcd原生收到ops文本+Enter，transport0/agent_prompted，token{token}；发送不等于本人已读或Roy已知，不代ACK。register-feature实际exit2/feature original log outside registered worktree：合法原校准root scratch/event布局未被当前路径守卫支持，原文/真实运输/分角色ops回执及拒绝保留；程序注册与后两角色仍pending，无伪造父项或普通提案。原唯一050119-fix宿主full已开检并持live锁PID{host["worker_pid"]}/start{host["birth"]}，不再learner-recheck、不等锁或预占正式号；main窄同步87叶/实际统一编号/0491shipped及下一自然消费者沿原checks事件接续，保现局/知识刷新/旧失败/宽父。回退仅持原锁逆回本次boss-trust数据、保归档/其他刷新并另记回退版本。回执paper/materials/20261016-0625-ops/。\n'
decision=f'\n- {at} 运维codex：0625原050119-fix实际为Roy授权silent-boss-calibration定期刷新，canonical done0/merged e138、source89b639及publication4dfa/tree6f1f2cb0实际live祖先；87源数据/报告/归档叶精确一致，metadata另含versions和原decision-log，生产源码delta0，不另审核或重合live。原源tsc0/438文件4110项、合后tsc0/437文件4108项、Python12/57及候选/live各28消费回执0按原日志/SHA核；初导入历史副本误扫失败、1096原件SHA/恢复、原提取/检查点130中断/两分片重用/白空格与夹具探针保，不重跑源full/模拟/API。固定107调参/22新实际结局16胜6死/验证438→460，THE_INSATIABLE B2因n43→44/打穿比1.296→1.316超过1.3移出可信，F49n29仍低可信，A0-9两组验证0各缺10；F48胜非联合通关，70当前发布输入差未重新校准。原5CLI含0491新增/proposed/源与实际live追溯、0484旧claim/status/version保持且contradict精确纳入；因原唯一宿主full持锁，正式号/main窄同步/shipped保pending，不预占号、不重复host请求，后继原learner-checks按唯一handoff接续。原2230字节双通知读回并只纳所属段；新反证实际经Herdr送原watcher会话/窗格，transport0与ops-forwarded真实回执独立，token{token}，不把发送当已读/Roy已知。支持的register-feature实际exit2拒原root event布局，新增一条非阻塞路径兼容bug到旧队列，保持严格身份/原文/分角色校验与所有真实接收待办，不造feature/学习父/普通提案或代ACK。当前native实际Sol6.1/xhigh/input/lease/原沙箱/no-network核。仅所属记录/5原CLI与必要转交通知提交，保并行记录，不触live锁内数据/源码/版本、不改对局/账号home模型额度预算队列prompt或关闭宽父；原元数据路径过严assert失败保留，不当产品故障。回执paper/materials/20261016-0625-ops/。\n'
handoff=f'\n- {at} 原050119校准20已actual live e138b036/publication4dfa/tree6f1f2cb0/source89b639，87源叶及源/合后自测绿已核；原宿主full PID{host["worker_pid"]}/start{host["birth"]}正持live锁，非阻塞探针busy，未分统一号/main集成/shipped。唯一接续ops/codex-ops/pending-integrations/20261016-050119-calibration-numbering.json及paper/materials/20261016-0625-ops/pending-publication-handoff.json：原learner-checks后核精确结果/current HEAD/index/刷新，按当时registry正式分号（不预猜），main只87原数据/报告/档案叶并绑定source祖先，不重合live/重跑不变树；0491再CLI shipped，0484原历史/contradict保持，自然低可信payload消费者pending。必要反证THE_INSATIABLE B2由1.296→1.316撤可信已原生送现有watcher，token{token}；合法root事件/scratch被feature桥路径拒绝，原CLI拒绝/ops真实发送回执/pending-deliveries及唯一非阻塞修复项已留，不代watcher/Roy ACK、不造父项/提案或新派研究。源WT与证据保留，原70生产输入差/失败/中断及宽父保持，不改现局或账号home模型预算。\n'
bug=f'\n- {at} **{marker}**（非运行阻塞纯通知协议bug，沿既有普通fix链，不另派校准/学习父）：ops/learning_requests.py:203—208的ack_feature只允许worktree/learner/runs内scratch/log；原合法feature silent-calibration-92f552eada491fed1ca5c9f0、batch20261016-050119-fix-batch、thread01a1415e-a511-7131-be7c-a2dc691c847f在launcher明确使用根learner/runs/20261016-050122-21c48aea-19f1-459a-b67e-e18af997b998-silent-boss-calibration及同名.jsonl，cwd为原silent-boss-calibration WT，故register-feature实exit2“feature original log outside registered worktree”。需要按原已注册batch/feature/character/worktree/launch.task/cwd/params.scratch/实际事件与thread/SHA允许该合法原布局，保留工作树范围和原文/传输/角色防伪及重复/越界/错源负控；不得改真实报告路径、伪造父项/普通提案/ACK或弱化普通proposal守卫。原native反证已真实投原watcher，token{token}，ops receipt可读；程序注册及watcher/Roy分角色仍pending。证据paper/materials/20261016-0625-ops/counterevidence-source.json、notice-registration-result.json及counterevidence-native-send.json；不热改运行中任务/原冻结输入或另派模型。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':notice,'notes/for-roy.md':notice,'notes/ops-handoff.md':handoff,'notes/fix-queue-v4.md':bug};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (r/path).open('ab') as f:f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for item in d['original_notifications']['receipts']:
    path=str(Path(item['path']).relative_to(r))
    with Path(item['path']).open('rb') as f:f.seek(item['offset']);raw=f.read(item['length'])
    assert sha(raw)==item['sha256'];oldbody=git('show',base+':'+path);values[path]=oldbody+(raw if raw not in oldbody else b'')+appends[path].encode()
values['paper/materials/learning/ledger.jsonl']=old+added
write(pub/'record-registration.json',dict(at=at,original_learner_rows=5,staged_learner_rows=len(added.splitlines()),new_0491='proposed pending locked unified registration',old_0484_core_status_version_preserved=True,ops_shipped_rows=0,release_id=None,original_notifications_preserved=True,native_ops_sent=True,program_notice_registration='blocked root scratch/event support',watcher_received='pending actual watcher receipt',roy_notified='pending actual native proof',host='running original pinned6f1f2cb0full; no new request',next_wake=pending))
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));check=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(check.stdout+check.stderr);assert check.returncode==0
print(json.dumps(dict(paths=len(entries),staged_learner_rows=len(added.splitlines()),ledger_check=0,release_id=None,native_sent=True)))

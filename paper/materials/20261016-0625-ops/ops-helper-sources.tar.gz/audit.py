from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0625';pub=root/'paper/materials/20261016-0625-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
bid='20261016-050119-fix-batch';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['learner_task']=='silent-boss-calibration' and b['feature_request']=='silent-calibration-92f552eada491fed1ca5c9f0' and b['merged']==report['merged'] and not b['proposal_audit_errors']
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
publication=load(s/'publication.json');source=report['fixes'][0]['commit'];merge=report['merged'];published=report['publication'];tree=report['fixed_release_tree'];current=git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()
assert (source,merge,published,tree)==(publication['source'],publication['merged'],publication['publication'],publication['publication_tree'])
for commit in [source,merge,published]:git('merge-base','--is-ancestor',commit,current)
assert git('rev-parse',published+'^{tree}').decode().strip()==tree
paths=publication['paths'];assert len(paths)==87 and set(paths)==set(git('diff-tree','--no-commit-id','--name-only','-r',source).decode().splitlines())
leaves=[]
for path in paths:
    a=git('show',source+':'+path);z=git('show',published+':'+path);assert a==z;leaves.append(dict(path=path,bytes=len(a),sha256=sha(a)))
assert not git('diff-tree','--no-commit-id','--name-only','-r',source,'--','agent/src','agent/tests','learner','ops','knowledge/builders').strip()
assert set(git('diff','--name-only',merge,published).decode().splitlines())=={'eval/versions.json','paper/materials/decision-log.md'} and publication['all_other_blobs_preserved'] and publication['sandbox_exit']==0
tests=load(s/'tests-summary.json');assert tests['tsc']==tests['vitest']==0 and tests['cases']==4110 and tests['files']==438 and sha((s/'source-sandbox.log').read_bytes())==tests['source_sandbox_sha256']
for name in ['source-sandbox','live-sandbox','python-fixtures','python-automation','candidate-consumer','live-consumer','fixed-consumer-fixtures','source-gitleaks','refresh-gitleaks','merge-gitleaks','publication-gitleaks']:
    assert (s/(name+'.exit')).read_text().strip()=='0'
assert (s/'source-sandbox-first-failed.exit').read_text().strip()=='1' and report['tests']['live']==dict(tsc=0,vitest=0,files=437,cases=4108)
notification=load(s/'notification.json');notices=[]
for item in notification['receipts']:
    with Path(item['path']).open('rb') as f:f.seek(item['offset']);raw=f.read(item['length'])
    assert sha(raw)==item['sha256'];notices.append(dict(**item,raw_text=raw.decode()))
assert len(notices)==2 and notices[0]['raw_text']==notices[1]['raw_text']
owned=[];refs=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as f:
    while True:
        offset=f.tell();raw=f.readline()
        if not raw:break
        row=json.loads(raw);ident=row.get('id');by=row.get('by','')
        own=ident=='silent-0491' and by=='learner:fix-batch'
        own=own or ident=='silent-0484' and by=='learner:fix-batch' and (any(e.get('run')=='VNSXWCWXR3VW' and e.get('role')=='contradict' for e in row.get('evidence',[])) or source in row.get('where',{}).get('commits',[]))
        if own:owned.append(raw);refs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)>=5 and sum(json.loads(x).get('op')=='add' for x in owned)==1
(p/'owned-learner-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'original-ledger-cli-row-bindings.json',refs)
hostlog=root/f'ops/codex-ops/learner/{bid}.fallback-{tree}.checks.log';host_raw=hostlog.read_bytes();stat=Path('/proc/727863/stat').read_text();fields=stat[stat.rfind(')')+2:].split()
lockrows=subprocess.check_output(['lslocks','--noheadings','--output','PID,COMMAND,PATH'],text=True).splitlines();assert any(x.split()[0]=='727863' and x.endswith(str(root/'ops/live-merge.lock')) for x in lockrows)
assert b' RUN ' in host_raw
host=dict(batch=bid,worker_pid=727863,birth=fields[19],actual_live_lock_held=True,tree=tree,log=str(hostlog.relative_to(root)),observed_log_bytes=len(host_raw),observed_log_sha256=sha(host_raw),vitest_started=True,full_result='pending original scheduler event',new_request_sent=False)
write(pub/'host-start-readback.json',host)
transport=load(pub/'counterevidence-native-send.json');assert transport['transport_exit']==0 and transport['transport_response']['result']['type']=='agent_prompted'
write(pub/'calibration-readback.json',dict(batch=bid,original_report=report,full_original_report=load(s/'report.json'),native=native,source=source,actual_merge=merge,original_publication=published,fixed_publication_tree=tree,current_live=current,source_actual_live_ancestor=True,original_source_paths=leaves,production_source_delta=False,source_tests=tests,original_publication_receipt=publication,publication_metadata_paths=['eval/versions.json','paper/materials/decision-log.md'],ops_initial_assertion='Publication metadata also includes its original decision-log line; initial one-path assumption failed and is retained, no product failure.',original_notifications=notification,owned_learner_rows=len(owned),host=host,release_id=None,shipped_registration='pending original host-held release lock; original0491 proposed retained',main_integration='pending narrow87leaf sync and source ancestry binding; no live remerge',notice=load(pub/'notice-registration-result.json'),native_notice=transport,limits=['Frozen7e1193model/107tune/split/Platt retained;22new actual outcomes16won6died/460validation. Frozen-model evidence is not current-production recalibration:70published input hashes differ.','THE_INSATIABLE B2 n43to44/leak1.296to1.316 crosses original1.3; remove trust while preserving old0484claim/status/version and contradiction evidence.','F49n29 has no count shortage but remains low trust; A0-4/A5-9 independent validation absent. F48 win is not joint run victory.','Original extract/replay130, source first full import failure, fixture/import/whitespace failures,1096historical-file SHA preservation/restoration and all reports kept; no reruns or threshold changes.','Actual native ops submission is not watcher receipt/Roy knowledge. CLI registration rejected legitimate root event/scratch layout; no fabricated parent/proposal/ACK.','No duplicate host request, release number reservation, lock wait, game/model/account/home/prompt changes or wide-parent closure.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000 and not f.name.startswith('jev-sts2-settle-')]+[out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
pending=dict(at=at,batch=bid,feature_request=b['feature_request'],source=source,actual_merge=merge,original_publication=published,fixed_tree=tree,name='S1.boss-calibration20',release_id=None,metadata_writes=0,original_source_paths=leaves,main_integration='pending',shipped_registration=f'silent-0491 proposed preserved; original{len(owned)}CLI retained',host=host,notice_id=transport['notice_id'],notice_registration='pending root event/scratch guard support; true native ops receipt available',next_step='At the original learner-checks wake after its live lock releases: read exact host result/current live/refresh/index/registry once; preserve refresh; sync only these87source leaves into main and bind source ancestor without remerging live; allocate current next unified V5release for actuale138 behavior (4dfa metadata same release); register0491shipped via ledger CLI, leave0484oldclaim/version intact; retain failures/wideparents/natural consumer pending. Do not request unchanged-tree full again. No preallocated number.')
write(pub/'pending-publication-handoff.json',pending);f=root/'ops/codex-ops/pending-integrations/20261016-050119-calibration-numbering.json';f.parent.mkdir(parents=True,exist_ok=True);write(f,pending)
print(json.dumps(dict(paths=len(paths),learner_rows=len(owned),lock='busy original host worker',release_id=None,native_sent=True,registration='blocked legitimate root scratch/event')))

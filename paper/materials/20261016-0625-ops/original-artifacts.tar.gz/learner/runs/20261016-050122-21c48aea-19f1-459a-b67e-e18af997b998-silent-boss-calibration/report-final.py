"""Report only observed checks, source commits, and actual publication receipts."""
import json
import re
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration')
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
def read(name):
    return json.loads((HERE/name).read_text())
summary, tests, table = read('summary.json'), read('tests-summary.json'), read('boss-trust-table.json')
state = read('publication.json') if (HERE/'publication.json').exists() else {'merged':None,'blocked':'publication not run'}
source = (HERE/'source-commit.txt').read_text().strip()
deployment = read('deployment-readback.json')
scans = {n:int((HERE/(n+'-gitleaks.exit')).read_text().strip()) for n in ('source','refresh','merge','publication')}
assert all(v == 0 for v in scans.values())
ledger = (HERE/'ledger-id.txt').read_text().strip()
merged = state.get('merged') if not state.get('rolled_back') else None
live_log = (HERE/'live-sandbox.log').read_text() if (HERE/'live-sandbox.log').exists() else ''
live_checks = {'tsc':0 if state.get('sandbox_exit') == 0 else None,'vitest':state.get('sandbox_exit'),
               'files':sum(int(x) for x in re.findall(r'Test Files\s+(\d+) passed',live_log)),
               'cases':sum(int(x) for x in re.findall(r'Tests\s+(\d+) passed',live_log))}
if merged:
    assert subprocess.run(['git','-C',str(LIVE),'merge-base','--is-ancestor',source,merged]).returncode == 0
lines = [f'# {HERE.name}', '', '任务性质：Roy已授权新功能静默boss模拟校准的定期刷新；fix-batch仅是调度通道。', '',
         f'来源提交：`{source}`；实际合入：`{merged}`；发布提交：`{state.get("publication")}`；固定发布树：`{state.get("publication_tree")}`。',
         f'专题版本：`{state.get("version")}`；统一release_id由ops核实际提交分配，不提前冒填。账本 `{ledger}` 只proposed。', '',
         f'冻结模型：`7e1193cef9467416bc10c8e344a49f4fd98390c7`；210输入SHA核同，原107调参keys、切点、Platt与进阶项选择保持。',
         f'提取{summary["finished_runs"]}完局/{summary["attempts"]}次尝试/{summary["usable"]}可用，新增{summary["new"]}实际结局/{summary["new_runs"]}局；验证438→{summary["val"]}。',
         f'B2/B3 Brier：{summary["b2"]["brier"]}/{summary["b3"]["brier"]}；A10残差：{summary["a10"]["t1"]["gap"]}/{summary["a10"]["pre"]["gap"]}。',
         'A0–4、A5–9独立验证均0，各缺10场；F49独立四指标/数量缺口见下表数据与正式报告。F48胜不等于整局胜，不评估两场联合通关率。',
         f'可信变化：`{summary["changes"]}`。当前源码与冻结模型101个输入不同；实际固定发布树有{deployment["pinned_model_inputs_different_in_publication"]}输入SHA不同，不能把本结果当当前生产模型已重新验证。',
         f'发布树逐叶核验：{deployment["source_paths_exact"]}源文件精确一致、其他既有blob保持；gitleaks {scans}。', '',
         '| boss | B2 n/缺/失败指标 | B3 n/缺/失败指标 | B2/B3可信 |', '|---|---|---|---|']
for boss,entry in sorted(table.items()):
    a,b=entry['b2'],entry['b3']
    lines.append(f'| {boss} | {a["n"]}/{a["missing"]}/{",".join(a["failed"]) or "无"} | {b["n"]}/{b["missing"]}/{",".join(b["failed"]) or "无"} | {a["trusted"]}/{b["trusted"]} |')
lines += ['', '完整逐boss指标：`boss-trust-table.json`。F49验证n29、数量缺0，B2/B3 Brier0.1862/0.1663、胜率差+30.0/+25.6个百分点、打穿比2.681/2.774，保持低可信。', '',
          f'源自测：tsc/vitest=0，{tests["files"]}文件/{tests["cases"]}例；Python校准12、调度/刷新57及实际候选消费28通过。',
          f'合后检查：{live_checks}；真实live数据消费者见live-consumer-read.json；完整外部检查交调度器。',
          '首次完整源沙箱退出1（436文件4098项过），唯一check-imports误扫历史不完整副本；1096项SHA保全后临时点目录复验并恢复原路径，源码/断言/时限/排除名单未改，首次失败日志保留。',
          '原默认入口提取中断130、15起点检查点中断130均保留；两片按原行号种子续算，历史对照及重复行除耗时完全相同。',
          f'定期入口：agent/tools/boss-sim/refresh-silent.py；每小时:13/:43及完成事件，升阶或20个新实际结局触发；内容指纹 `{summary["artifact"]}`。',
          '完整复现参数见refresh-command.json；重复档案和不足阈值均不派子进程、输出字节保持。',
          '报告：paper/materials/silent/boss-sim-calibration.md；归档：experiments/boss-sim/silent/'+summary['artifact']+'。',
          'Roy提供隔离/整体Platt/固定切分/原准入/刷新架构；数据和结论仅来自结束SILENT局。未修改费用/药水/保血/目标/SL等策略阈值，无新游戏机制或铁甲私有样本。',
          f'发布阻塞/回退：{state.get("blocked") or state.get("rolled_back") or "无"}。',
          '已按授权追加根目录notes/for-roy.md与ops/inbox-dev.md并逐字节读回；回执见notification.json，watcher/Roy接收或ACK未代填。',
          '提交预检首次将原始diff上下文空格报为白空格问题，原件及失败输出保留；正文检查和全量gitleaks通过，未改原始证据。',
          'code_proposals=[]；implementation_domains=[]。正式统一编号、shipped及完整外部检查交ops/原调度器；本批完成不关闭宽父要求、自然消费者或收益验收。', '']
(HERE/'report.md').write_text('\n'.join(lines))
out={'task':'fix-batch','base':(HERE/'base.txt').read_text().strip(),
     'fixes':[{'item':'Roy 已授权新功能：静默 boss 模拟校准','commit':source,
               'test':'bash agent/tools/test-sandbox.sh；Python固定夹具；B2/B3实际数据消费者',
               'fails_without_fix':False,'nature':'定期校准数据刷新，未冒造bug', 'ledger':[ledger]}],
     'skipped':[], 'merged':merged,'publication':state.get('publication'),'fixed_release_tree':state.get('publication_tree'),'tested_live_tree':state.get('tested_tree'),
     'version':state.get('version'),'release_id':None,'release_id_status':'ops按实际live提交统一核号',
     'tests':{**tests,'live_sandbox':state.get('sandbox_exit'),'live':live_checks,'external_full':'交原调度器'},
     'code_proposals':[],'implementation_domains':[], 'boss_trust':table,'a10_residuals':summary['a10'],
     'f49':summary['f49'], 'ascension_shortage':{'A0–4':10,'A5–9':10},'artifact':summary['artifact'],
     'refresh':{'entry':'agent/tools/boss-sim/refresh-silent.py','trigger':'升阶或20个新实际结局；:13/:43及完成事件','validation_only_new_fights':22},
     'commits':{'source':source,**{k:state.get(k) for k in ('initial_live','refresh_commit','before_code','merged','publication')}},
     'deployment_readback':deployment,'gitleaks':scans,
     'blocked':state.get('blocked') or state.get('rolled_back'),
     'counterevidence':{'previous_ledger':'silent-0484','new_ledger':ledger,'boss':'THE_INSATIABLE','change':'B2可信移出；n43→44，打穿比1.296→1.316','evidence':'VNSXWCWXR3VW F33 attempt1 T1–7','notification':read('notification.json') if (HERE/'notification.json').exists() else None},
     'calibration_report':'paper/materials/silent/boss-sim-calibration.md','calibration_method_commit':'7e1193cef9467416bc10c8e344a49f4fd98390c7','current_production_model_recalibrated':False,'report':str(HERE/'report.md')}
(HERE/'report.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':source,'merged':merged,'publication':state.get('publication'),'report':str(HERE/'report.md')}))

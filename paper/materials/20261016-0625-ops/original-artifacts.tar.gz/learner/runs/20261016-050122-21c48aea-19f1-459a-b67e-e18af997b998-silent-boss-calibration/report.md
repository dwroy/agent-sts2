# 20261016-050122-21c48aea-19f1-459a-b67e-e18af997b998-silent-boss-calibration

任务性质：Roy已授权新功能静默boss模拟校准的定期刷新；fix-batch仅是调度通道。

来源提交：`89b6391845eb28b774c23db6f4466160c25876ba`；实际合入：`e138b036a79709f6217272e631324fd3e77e2bff`；发布提交：`4dfac2702bf1ce63199d4579c7d5cda136f13d3d`；固定发布树：`6f1f2cb003239b798ee345c9137f4867acd96162`。
专题版本：`S1.boss-calibration20`；统一release_id由ops核实际提交分配，不提前冒填。账本 `silent-0491` 只proposed。

冻结模型：`7e1193cef9467416bc10c8e344a49f4fd98390c7`；210输入SHA核同，原107调参keys、切点、Platt与进阶项选择保持。
提取314完局/1372次尝试/567可用，新增22实际结局/10局；验证438→460。
B2/B3 Brier：0.1108/0.1131；A10残差：0.03500000000000003/0.039000000000000035。
A0–4、A5–9独立验证均0，各缺10场；F49独立四指标/数量缺口见下表数据与正式报告。F48胜不等于整局胜，不评估两场联合通关率。
可信变化：`{'b2': {'added': [], 'removed': ['THE_INSATIABLE']}, 'b3': {'added': [], 'removed': []}}`。当前源码与冻结模型101个输入不同；实际固定发布树有70输入SHA不同，不能把本结果当当前生产模型已重新验证。
发布树逐叶核验：87源文件精确一致、其他既有blob保持；gitleaks {'source': 0, 'refresh': 0, 'merge': 0, 'publication': 0}。

| boss | B2 n/缺/失败指标 | B3 n/缺/失败指标 | B2/B3可信 |
|---|---|---|---|
| AEONGLASS | 34/0/brier,gap,leak | 34/0/brier,gap,leak | False/False |
| CEREMONIAL_BEAST | 38/0/无 | 38/0/无 | True/True |
| KAISER_CRAB | 45/0/brier,leak | 45/0/brier,leak | False/False |
| KNOWLEDGE_DEMON | 44/0/leak | 44/0/leak | False/False |
| LAGAVULIN_MATRIARCH | 39/0/无 | 39/0/无 | True/True |
| QUEEN | 29/0/brier,gap | 29/0/brier,gap | False/False |
| SOUL_FYSH | 33/0/无 | 33/0/无 | True/True |
| TEST_SUBJECT | 27/0/brier,gap,leak | 27/0/brier,leak | False/False |
| THE_INSATIABLE | 44/0/leak | 44/0/brier,leak | False/False |
| THE_KIN | 42/0/无 | 42/0/无 | True/True |
| VANTOM | 46/0/无 | 46/0/无 | True/True |
| WATERFALL_GIANT | 37/0/无 | 37/0/无 | True/True |

完整逐boss指标：`boss-trust-table.json`。F49验证n29、数量缺0，B2/B3 Brier0.1862/0.1663、胜率差+30.0/+25.6个百分点、打穿比2.681/2.774，保持低可信。

源自测：tsc/vitest=0，438文件/4110例；Python校准12、调度/刷新57及实际候选消费28通过。
合后检查：{'tsc': 0, 'vitest': 0, 'files': 437, 'cases': 4108}；真实live数据消费者见live-consumer-read.json；完整外部检查交调度器。
首次完整源沙箱退出1（436文件4098项过），唯一check-imports误扫历史不完整副本；1096项SHA保全后临时点目录复验并恢复原路径，源码/断言/时限/排除名单未改，首次失败日志保留。
原默认入口提取中断130、15起点检查点中断130均保留；两片按原行号种子续算，历史对照及重复行除耗时完全相同。
定期入口：agent/tools/boss-sim/refresh-silent.py；每小时:13/:43及完成事件，升阶或20个新实际结局触发；内容指纹 `ae0da4720d7ec28643a6cb9367bc6c2bc30cc8ee4c476f2e05d6f7bbc84f17c6`。
完整复现参数见refresh-command.json；重复档案和不足阈值均不派子进程、输出字节保持。
报告：paper/materials/silent/boss-sim-calibration.md；归档：experiments/boss-sim/silent/ae0da4720d7ec28643a6cb9367bc6c2bc30cc8ee4c476f2e05d6f7bbc84f17c6。
Roy提供隔离/整体Platt/固定切分/原准入/刷新架构；数据和结论仅来自结束SILENT局。未修改费用/药水/保血/目标/SL等策略阈值，无新游戏机制或铁甲私有样本。
发布阻塞/回退：无。
已按授权追加根目录notes/for-roy.md与ops/inbox-dev.md并逐字节读回；回执见notification.json，watcher/Roy接收或ACK未代填。
提交预检首次将原始diff上下文空格报为白空格问题，原件及失败输出保留；正文检查和全量gitleaks通过，未改原始证据。
code_proposals=[]；implementation_domains=[]。正式统一编号、shipped及完整外部检查交ops/原调度器；本批完成不关闭宽父要求、自然消费者或收益验收。

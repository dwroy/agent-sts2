"""Commit only the completed, tested Silent calibration delta using the global identity."""
import json
import hashlib
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration')

def run(args):
    return subprocess.run(args,cwd=ROOT,capture_output=True,text=True,check=True)

assert (HERE/'source-sandbox.exit').read_text().strip() == '0'
assert json.loads((HERE/'historical-copy-restored.json').read_text())['restored']
identity = (HERE/'artifact.txt').read_text().strip()
archive = ROOT/'experiments/boss-sim/silent'/identity
if not archive.exists():
    packaged = run([sys.executable,str(HERE/'package.py')])
    (HERE/'package.log').write_text(packaged.stdout+packaged.stderr)
else:
    completed = json.loads((archive/'completed.json').read_text())
    assert all(hashlib.sha256((archive/n).read_bytes()).hexdigest()==h for n,h in completed['files_sha256'].items())
paths = ['knowledge/characters/silent/boss-trust.json','paper/materials/silent/boss-sim-calibration.md',
         'experiments/boss-sim/silent/'+identity]
run(['git','add','--sparse','--',*paths[:2]])
run(['git','add','--sparse','--force','--',paths[2]])
style = run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check','--',*paths[:2]])
(HERE/'source-whitespace.log').write_text(style.stdout+style.stderr)
(HERE/'source-whitespace.exit').write_text('0\n')
scan = subprocess.run(['nice','-n','19','gitleaks','git','--pre-commit','--staged','--redact','--no-banner',
                       '--report-format','json','--report-path',str(HERE/'source-gitleaks.json')],
                      cwd=ROOT,capture_output=True,text=True)
(HERE/'source-gitleaks.log').write_text(scan.stdout+scan.stderr)
(HERE/'source-gitleaks.exit').write_text(str(scan.returncode)+'\n')
assert scan.returncode == 0,'gitleaks failed; scan retained'
(HERE/'source-commit-date.log').write_text(run(['date','+%Y-%m-%d %H:%M:%S %Z']).stdout)
commit = run(['git','-c','core.hooksPath=/dev/null','commit','-m',
              'Refresh Silent boss calibration with 22 additional actual outcomes\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'])
(HERE/'source-commit.log').write_text(commit.stdout+commit.stderr)
source = run(['git','rev-parse','HEAD']).stdout.strip()
(HERE/'source-commit.txt').write_text(source+'\n')
base = (HERE/'base.txt').read_text().strip()
delta = subprocess.check_output(['git','diff','--binary',base,source,'--','agent/src','agent/tools','learner','eval','ops','knowledge/builders'],cwd=ROOT)
assert not delta,'this periodic batch must not alter executable source'
(HERE/'source-code-diff.patch').write_bytes(delta)
print(json.dumps({'source':source,'artifact':identity,'executable_source_delta_bytes':len(delta)}))

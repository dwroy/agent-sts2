import json,pathlib,collections,re,datetime,hashlib
P=pathlib.Path(__file__).parent;ROOT=P.parents[2]
load=lambda n:[json.loads(l) for l in (P/(n+'.jsonl')).open()]
D=load('decisions');S=load('states');B=load('brain');R=json.load((P/'J2VR2DFJG8K4-resources.json').open())
def powers(p):return [(x['power_id'],x['amount']) for x in p.get('powers',[])]
def enemy(s):return [(x['enemy_id'],x['current_hp'],x['max_hp'],x['block'],powers(x),sum(i.get('total_damage') or 0 for i in x.get('intents',[]))) for x in ((s['state'].get('combat') or {}).get('enemies') or [])]
print('【各战轮初与末态】')
for c in R['combats']:
 frames=[s for s in S if c['entry']['line']<=s['_line']<=c['last']['line']]; seen=set();start=[]
 for s in frames:
  st=s['state'];t=st['turn']
  if t not in seen:
   seen.add(t);start.append(s)
 print('战',c['sequence'],'F',c['floor'])
 for i,s in enumerate(start):
  es=enemy(s); hp=sum(e[1] for e in es if e[1]>0);nxt=sum(e[1] for e in enemy(start[i+1]) if e[1]>0) if i+1<len(start) else None
  print('轮',s['_line'],s['state']['turn'],s['state']['run']['current_hp'],'活敌',hp,'下轮净推进',None if nxt is None else hp-nxt,'敌',es)
 print('末',frames[-1]['_line'],enemy(frames[-1]),'玩家', {k:(frames[-1]['state'].get('combat') or {}).get('player',{}).get(k) for k in ['current_hp','block','energy','powers']})
print('【药水动作】')
for d in D:
 if d['chosen'].get('action') not in ['use_potion','discard_potion']:continue
 s=next((s for s in S if s.get('fingerprint')==d.get('fingerprint') and s['_line']<=436681),None)
 print(d['_line'],d['ts'],d['floor'],d['turn'],d.get('sl_attempt'),d['chosen'],d.get('expect'),d['rationale'])
print('【统计】')
J=[d for d in D if d['decider']=='jev'];PS=[d for d in J if d['label'].startswith('combat/plan-choice')]
print('Jev',len(J),'低信心',collections.Counter(d['floor'] for d in J if isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35))
print('选线',len(PS),'rollout',collections.Counter(str(d.get('rollout_best_chosen')) for d in PS),'rank1',sum('code rank 1' in d['rationale'] for d in PS))
turns=collections.defaultdict(list)
for d in D:
 if not isinstance(d.get('turn'),int) or d['screen'] not in ['COMBAT','CARD_SELECTION'] or not (d['label'].startswith('combat/') or d['label'].startswith('selection/')):continue
 turns[(d['floor'],d.get('sl_attempt') or 1,d['turn'])].append(d)
autonomous=[];solo=[];actions=0
for k,dd in turns.items():
 auto=[d for d in dd if d['decider']=='code' and not d['rationale'].startswith('continuing the Jev-chosen plan')]
 if auto:autonomous.append(k);actions+=len(auto)
 if auto and not any(d['decider']=='jev' or d['rationale'].startswith('continuing the Jev-chosen plan') for d in dd):solo.append(k)
print('turns',len(turns),'含代码自主',len(autonomous),'动作',actions,'完全代码无Jev',len(solo),'keys',solo)
print('jev-plan',sum(d['rationale'].startswith('continuing the Jev-chosen plan') for d in D))
print('代码替线',[(d['_line'],d['rationale']) for d in D if 'HP guard:' in d['rationale'] or 'SL explore' in d['rationale']])
print('fallback',[(d['_line'],d['floor'],d['label'],d['rationale']) for d in D if d['decider']=='code-fallback'])
print('用量Jev',{k:sum((d.get('usage') or {}).get(k,0) or 0 for d in J) for k in ['input_tokens','output_tokens','cache_hit_tokens']})
print('Brain请求',len(B),'成功',sum(not b.get('error') for b in B),'预算失败',sum(bool(b.get('error')) for b in B),'模型',collections.Counter((b.get('engine'),b.get('model'),b.get('effort')) for b in B))
print('用量Brain',{k:sum((b.get('usage') or {}).get(k,0) or 0 for b in B) for k in ['inputTokens','outputTokens','cacheHitTokens']},'延时',sum(b.get('latency_ms',0) or 0 for b in B))
print('时间',D[0]['ts'],D[-1]['ts'],(datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(D[0]['ts'])).total_seconds())
print('【focus】')
for d in PS:
 opts={k:json.loads(v) for k,v in d.get('questions',{}).get('plan',{}).get('criteria',{}).items()}
 opts={k:v for k,v in opts.items() if isinstance(v,dict)}
 if not any('focus' in v for v in opts.values()):continue
 m=re.search('chose plan (\d+)/',d['rationale']);v=opts.get('plan'+m[1],{}) if m else {}
 print(d['_line'],'选',v.get('focus'),'候选',[(k,v.get('focus')) for k,v in opts.items() if 'focus' in v])
print('【关键选线量】')
for n in [422280,422287,422314,422345,422361,422375,422389]:
 d=next(d for d in D if d['_line']==n)
 print('题',n)
 for k,v in d.get('questions',{}).get('plan',{}).get('criteria',{}).items():
  v=json.loads(v)
  if isinstance(v,dict):print(k,{a:b for a,b in v.items() if a in ['plays','hp_lost','damage_dealt','hp_after','block_gained','focus','rollout_best']})
print('【路线与时钟字段】')
for d in D:
 if d['decider']!='codex' and not d['label'].startswith('rest/'):continue
 for q in d.get('questions',{}).values():
  for k,v in q.get('criteria',{}).items():
   try:ob=json.loads(v)
   except:continue
   if not isinstance(ob,dict):continue
   refs={a:b for a,b in ob.items() if any(x in a for x in ['boss_sim_hp','route','clock'])}
   if refs: print(d['_line'],d['floor'],d['label'],k,refs)
 print('boss_sim',d['_line'],d['floor'],json.dumps(d.get('boss_sim'),ensure_ascii=False)[:1500])

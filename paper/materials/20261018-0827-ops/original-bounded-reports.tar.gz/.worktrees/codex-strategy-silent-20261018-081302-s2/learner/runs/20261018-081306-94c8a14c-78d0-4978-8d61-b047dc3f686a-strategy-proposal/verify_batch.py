import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract_evidence', HERE.parents[2] / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def main():
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    streams, selected_states, decisions, runs = [], {}, {}, []
    for m in manifest:
        counts = {r: 0 for r in m['counts']}
        digest = hashlib.sha256()
        path = HERE / 'evidence' / (m['stream'] + '.evidence.jsonl')
        with Path('/home/dw/Projects/agent-sts2/logs', m['stream'] + '.jsonl').open('rb') as source, path.open('rb') as handle:
            for encoded in handle:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['offset'] + item['bytes'] <= m['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert extractor.run_identity(item['row']) == item['run_id']
                counts[item['run_id']] += 1
                if m['stream'] == 'states':
                    selected_states[item['line']] = item['row']['state']
                elif m['stream'] == 'decisions':
                    decisions[item['line']] = item['row']
                elif m['stream'] == 'runs':
                    runs.append(item['row'])
        assert counts == m['counts']
        assert digest.hexdigest() == m['output_sha256']
        streams.append({'stream': m['stream'], 'verified_rows': sum(counts.values()), 'output_sha256': digest.hexdigest()})
    assert len(runs) == 6 and all(r['character'] == 'SILENT' and r['ascension'] == 10 and r['victory'] is False for r in runs)
    windows = {w['key']: w for w in json.loads((HERE / 'state-windows.json').read_text())}
    pairs = []
    for run, floor, turn, a, b, expected in [
        ('8JRE1C4H4Z2W', 33, 2, 270216, 270282, (3, 15, 10, 17)),
        ('YF0LXT1QSTGG', 48, 1, 271309, 271348, (0, 9, 45, 38)),
        ('XP2SL33HT0D9', 33, 3, 271992, 272040, (9, 14, 24, 27)),
        ('XP2SL33HT0D9', 33, 1, 271982, 272195, (2, 10, 25, 34)),
    ]:
        x, y = decisions[a], decisions[b]
        assert x['run_id'] == y['run_id'] == run and x['floor'] == y['floor'] == floor and x['turn'] == y['turn'] == turn
        assert x['fingerprint'] == y['fingerprint']
        start = f'{run}/F{floor}/A'
        wx, wy = windows[f'{start}{x["sl_attempt"]}/T{turn}'], windows[f'{start}{y["sl_attempt"]}/T{turn}']
        values = (wx['hp_loss_to_next'], wy['hp_loss_to_next'], wx['enemy_net_hp_to_next'], wy['enemy_net_hp_to_next'])
        assert values == expected, (a, b, values)
        pairs.append({'run': run, 'floor': floor, 'turn': turn, 'decision_lines': [a, b],
                      'fingerprint_sha256': hashlib.sha256(x['fingerprint'].encode()).hexdigest(),
                      'attempts': [x['sl_attempt'], y['sl_attempt']], 'observed_hp_loss': values[:2],
                      'observed_enemy_net_hp': values[2:], 'delta_hp_loss': values[1] - values[0],
                      'delta_enemy_net_hp': values[3] - values[2],
                      'state_lines': [[w['first']['line'], w['last']['line'], w['next_turn']['line']] for w in [wx, wy]]})
    def amount(raw, name):
        return next((p['amount'] for p in raw.get('powers', []) if p['power_id'] == name), 0)
    def player(line):
        return selected_states[line]['combat']['player']
    def enemy(line, name=None):
        return next(e for e in selected_states[line]['combat']['enemies'] if name is None or e['enemy_id'] == name)
    def damage(e):
        return sum(i.get('total_damage') or 0 for i in e['intents'])
    assert [amount(player(n), 'TAINTED_POWER') for n in [274830, 274831, 274833]] == [0, 3, 6]
    assert [amount(player(n), 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]] == [0, 6, 12, 18]
    assert [amount(enemy(n), 'VITAL_SPARK_POWER') for n in [274830, 274834]] == [3, 6]
    assert [amount(enemy(n), 'STRENGTH_POWER') for n in [273237, 273252, 273263]] == [0, 4, 8]
    assert [damage(enemy(n)) for n in [273237, 273252, 273263]] == [11, 15, 19]
    assert [amount(enemy(n, 'ZAPBOT'), 'STRENGTH_POWER') for n in [274308, 274313]] == [2, 4]
    assert [damage(enemy(n, 'ZAPBOT')) for n in [274308, 274313]] == [17, 19]
    assert [enemy(n, 'ZAPBOT')['index'] for n in [274308, 274313]] == [4, 3]
    assert [enemy(n)['max_hp'] for n in [277512, 277513]] == [111, 212]
    assert [amount(enemy(n), 'POISON_POWER') for n in [277512, 277513, 277519]] == [4, 0, 0]
    assert amount(player(277519), 'ACCELERANT_POWER') == 2
    assert [player(n)['block'] for n in [277524, 277526]] == [23, 23]
    assert [amount(player(n), 'DEXTERITY_POWER') for n in [277524, 277526]] == [5, 6]
    result = {'kind': '原始字节与局面事实核验，不是生产源码测试', 'streams': streams,
              'verified_rows': sum(s['verified_rows'] for s in streams), 'runs': runs, 'pairs': pairs,
              'mechanisms': {'prism': {'lines': [274830, 274831, 274833, 274834, 274836, 274837, 274838]},
                             'clam': {'lines': [273237, 273252, 273263]},
                             'zapbot': {'lines': [274308, 274313], 'index_changed': True, 'generation_identity': None},
                             'phase': {'lines': [277512, 277513, 277519, 277524, 277526]}}}
    (HERE / 'evidence-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'verified_rows': result['verified_rows'], 'streams': len(streams), 'same_fingerprint_pairs': len(pairs), 'mechanism_groups': 4}, ensure_ascii=False))


if __name__ == '__main__':
    main()

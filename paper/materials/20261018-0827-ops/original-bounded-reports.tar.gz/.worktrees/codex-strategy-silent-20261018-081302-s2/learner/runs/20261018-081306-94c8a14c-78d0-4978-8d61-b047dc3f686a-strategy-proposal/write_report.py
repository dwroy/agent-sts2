import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
BATCH = '20261018-081302-s2-strategy-proposal'


def main():
    verified = json.loads((HERE / 'evidence-verification.json').read_text())
    pins = json.loads((HERE / 'source-pin-manifest.json').read_text())
    queue = json.loads((HERE / 'queue-records.json').read_text())
    dispatch = json.loads((HERE / 'dispatch-identity.json').read_text())['row']
    assert set(queue) == set(dispatch['proposal_ids'])
    reasons = [
        'DUZ F27 T4/T5污染0→3→6及0→6→12→18已核；缺原dirty运行实际移动表与技能施毒、格挡、虚弱、火花增长的联合生产重放，不能据净失血新增少打技能规则。',
        '5PM F39 T4负力/敏及失落退场后力量恢复已核；缺抢夺逐实体累计来源的完整归属、遗忘退场返敏端点及完整固定重放，不设固定击杀顺序。',
        'CA5 F13加压0→4→8力、喷水11/15/19和五样本门槛已核；当前进阶事实读取已有，缺原运行移动表及加压/虚弱/覆甲联合生产重放与完整减层条件。',
        '5PM F38 T3/T4电击力2→4、攻击17→19已核且index由4变3；增长路径已有，缺可认证的召唤代际身份、原移动输入及完整另一目标顺序后继。',
        '8JRE F33首/三试T2同指纹多损12血多扣7血已核；原答/护栏/SL预测及首动作回执已有，缺跨抽弃牌、生成、用药、重规划的完整执行归属与分源资源认证；原金刚杵误链0016异议保留。',
        'YF F48第二/三试T1同指纹实际0/9失血、45/38扣敌已核；预测对照已有，缺动作段完整执行归属、逐来源血价和受控整战后继，不从24/24全败拟惩罚系数或禁探索。',
        'YF F48末试T3→T4换111/212阶段清毒及T5零毒触媒2、敏5→6而挡23不倒补已核；现有快照已覆盖子项，缺逐候选施毒、结算、消耗附伤与敏捷顺序的联合执行认证。',
        'XP F33首/二试T3及首/末试T1四指纹已配对，实付血价+5/+8与扣敌+3/+9已核；缺同抽序、随机落点、预算的完整替线及成长后继，不启用新SL选线门槛。',
        'XP F33末试T2船夹板14挡、镣铐临时减力与T4朝向/弱变化可核；局部机制已有，缺完整候选在抽弃牌后的联合执行及消费者认证，不将局部实现登记整项duplicate。',
        'YF/XP各配对端点与阶段/能力快照已复核；缺逐来源资源账、完整候选执行及路线/休息/药水时机的受控替线联合认证，本批未重做原101局历史审计。',
    ]
    anchors = [
        'DUZUBAJ3A8GP，F27 T4—5；states 274830—274838。',
        '5PM6JAQG6FNQ，F39首试T4—6；states 274351—274366。',
        'CA5KE8GFJ9X2，F13 T1—5；states 273237—273269。',
        '5PM6JAQG6FNQ，F38 T3—4；states 274308—274317。',
        '8JRE1C4H4Z2W，F33首/三试T2；decisions 270216/270282，states 276208—276212与276274—276278；原提案另要求F17 T6、F33第二试T5与末试T11。',
        'YF0LXT1QSTGG，F48第二/三试T1；decisions 271309/271348，states 277327—277337与277366—277373。',
        'YF0LXT1QSTGG，F48末试T3—5；states 277512/277513/277519/277524/277526，decisions 271495/271509。',
        'XP2SL33HT0D9，F33首/二试T3、首/末试T1；decisions 271992/272040及271982/272195，states 278028—278031/278076—278079及278017—278023/278231—278236。',
        'XP2SL33HT0D9，F33末试T2—5；states 278236—278259；原文另引的A1/A6旧局本批未重新抽取，不作本批新增验证。',
        'YF0LXT1QSTGG F48 T1/3—5；XP2SL33HT0D9 F33 T1—5；采用以上本批字节核验端点，原101局历史计数仅作为原文背景。',
    ]
    results = [{'id': pid, 'state': 'waiting', 'reason': reason} for pid, reason in zip(queue, reasons)]
    result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': pins['base'],
              'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
              'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': list(queue),
              'implementation_domains': [], 'proposal_results': results, 'report': str(HERE / 'report.md')}
    (HERE / 'final-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    timestamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
    print(timestamp)
    common = f'''角色silent，仅本批六个A10来源局；批次{BATCH}。核对时间：{timestamp}。
基线：`{pins['base']}`；`git merge --no-edit main`返回Already up to date。
实际观察live：`{pins['live']}`，tree `{pins['live_tree']}`。
本批为十项普通领取任务，未绑定research_request或implementation_request，不转成专题，不领取其他队列。

原提案十份逐字节复制并与登记SHA256一致，见original-manifest.json及各original.md。
按共用extract_evidence.py冻结八流，各流source_size、每行offset/bytes/SHA、显式run身份和输出SHA全部保留。
verify_batch.py从原日志回读核对{verified['verified_rows']}行，并核对四组完整指纹配对；不是生产源码或消费者测试。
states/decisions/brain各有2条全源坏行，仅保留抽取器计数，不归因本批；fight-plans在其保存截点选中0条，只说明该截点无所选记录。
run-plans本次实际选中33条，以run字段及其余显式身份判定，不把正文提及当所属局。

样本与验证边界：六个局号均为SILENT/A10失败局。每局SL尝试是相关观察，不扩大独立样本数。
四组同指纹只控制当时观测，不控制后续抽序、生成、随机药水、预算和整战动作。
本批不拟合HP惩罚、必休血线、成长权重或SL禁止规则；拟改规则应先冻结可执行输入和完整替线，按独立run分组，后续新A10局作时间后移验证。
原运行均有dirty标签，当前main/live与原运行不能互代；缺原实际移动表不以刷新数据库冒充。

预期行为与验证方式：已有局部事实保持，待补齐的联合执行/模型认证按每项证据局面固定输入重放；不得把候选预测或单动作返回当整轮执行。
新实现需撤生产源码失败、恢复通过，并走原沙箱入口和live合入流程。当前没有新增源码，未做消融、tsc、vitest或消费者运行，三项测试为null。
所有选项、现有排序、出牌/药水/SL/终局规则保持；铁甲及未观察条件无代码变更。
回退：本批无生产代码可回退；报告及CLI链接保留历史。后续实现须有实际live祖先源码commit、独立版本及已授权双通知；此处不填implemented或shipped。
'''
    sections = []
    for (pid, rows), reason, anchor in zip(queue.items(), reasons, anchors):
        original = rows[0]
        sections.append(f'''## {pid}

来源任务：{original['source_task']}；目标实现任务：strategy-proposal；原领域：{', '.join(original['domains'])}。
账本：{', '.join(original['ledger'])}。
原提案：{original['proposal']}；原SHA256：{original['proposal_sha256']}。
证据：{anchor}
原请求／待实现行为：{original['summary']}
本批处置：waiting。{reason}
反例与限制：单步/快照的既有实现不证明组合完成；原文记录的全败与未完成续步保留，不用未执行方案声称获胜。具体原反例见本目录{pid}.original.md，本批不改写它。
验证下一步：按上述固定局面补足对应缺口，保留全部候选与未知；若声称已有整项实现，须进一步提供实际live祖先源码和完整执行/消费者证明，不能只凭函数同名去重。
''')
    (HERE / 'proposal.md').write_text('# 本批十项提案逐项核验与处置\n\n' + common + '\n' + '\n'.join(sections))
    pairs_text = '\n'.join(f"- {p['run']} F{p['floor']} T{p['turn']}，尝试{p['attempts']}，实际失血{p['observed_hp_loss']}、本体净扣{p['observed_enemy_net_hp']}；替线差{p['delta_hp_loss']:+}血价/{p['delta_enemy_net_hp']:+}扣敌。" for p in verified['pairs'])
    proofs = '\n'.join(f"- `{e['path']}`：live last-touch祖先 `{e['live']['last_touch_commit']}`。" for e in pins['entries'] if e['path'].split('/')[-1] in ['silent-selection-audit.ts', 'silent-selection-dispatch.ts', 'silent-sl-comparison.ts', 'silent-sl-resource-comparison.ts', 'silent-phase-current.ts'])
    table = '\n'.join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
    (HERE / 'report.md').write_text('# 静默猎手策略提案核验报告\n\n' + common + f'''
## 当轮配对与机制核验

{pairs_text}

以上净扣是下一玩家轮端点，不拆分未记录来源，不外推胜率。状态分窗覆盖指定层185个回合窗；原始抽取4062条states与3941条decisions均核回。
感染棱柱T4火花3、污染0/3/6；T5火花6、污染0/6/12/18，同时施毒/弱/挡有收益，不能一律少打技能。
下水道蚌T1/T3/T5力量0/4/8、无弱喷水11/15/19；当前进阶读取与房间5样本门槛已有，完整减层条件不从层数序列推断。
电击机器人T3/T4上限23、力量2/4、攻击17/19，同时index由4变3；索引不是可靠的召唤代际ID。
实验体111→212阶段清旧毒；末T5触媒2、毒0，敏捷5→6而既有23挡不回补；这些是现场事实，未补未来毒或倒推施放顺序。

## 已有源码范围

{proofs}

上述均核为观察live的真实祖先，不是本批提交。selection_audit.actual_turn、candidate_comparison.actual_turn_result仍为null；dispatch只认单动作回执，whole_plan_executed为null且state_effect_verified=false。
phase_current只列本帧，poison_damage_already_dealt为null。它们覆盖原提案子项，不能把整项记duplicate。
17个选定源码/测试叶中14个base/live字节相同；rollout.ts、rollout-live.ts、sl/explore.ts有差异，binary diff与两侧原字节.txt均保存。差异含既有Queen限定实现及归属注释，不能笼统说只有注释，也不从这些不同源码借用本批未运行测试。

## 逐项处置

| 提案 | 状态 | 具体原因 |
| --- | --- | --- |
{table}

## 追溯异议及交付

578e原文将silent-vajra-opening-strength关联silent-0016，但该账本claim是护喉甲覆甲；不能把力量帧记为它的support。本批保留原文/claim及已有异议通知b07c96b10b1facb9f887a710，副本见existing-disagreement-notice.json；通知原件已有各角色回执字段，字段存在不替代本批重新核原回执或代填ACK。本批没有新增异议，不重复排队或另造提案id。
只经根ledger.py update给既有相关账本追加本批proposal/report链接与waiting备注，不加support/repeat，不改claim、first_run、asc、prior、status、version、effect或旧evidence；实际CLI回执与前后保护字段见ledger-link-receipt.json。
消费队列由最终proposal_results逐项交原调度器；没有直接编辑learn.json、专用队列、根请求或任何通知ACK。
无源码/知识变更，无提交、合入、eval版本或shipped登记；工作树保持干净、HEAD保持完整base。未运行生产测试，无“撤源码红/恢复绿”结果。
proposal.md绝对路径：{HERE / 'proposal.md'}。
最终机器回报：final-result.json。原大证据文件保留，不删工作树或原日志。

## 保留的过程限制

第一次状态分窗在抽取仍进行时执行，原结果和日志已另存*.early.*，最终按完整抽取重算并由逐字节验证通过后出具本报告；没有将零行或半成品当最终结果。
一次源码定位查询用了不存在的agent/src/step.ts，rg报该路径缺失；随后定位真实消费者agent/src/hand/loop.ts，原命令结果在本任务运行日志中保留，不作为产品失败或测试失败。
本批未重做原提案引用的101局全历史机制/路线审计，也未重提其派发范围外旧局；旧支持数、宽asc字段和既有测试结果不充当本批新增样本或成功测试。
''')
    ledger_ids = sorted({i for rows in queue.values() for i in rows[0]['ledger']})
    with (HERE / 'ledger-updates.jsonl').open('w') as handle:
        for ledger_id in ledger_ids:
            related = [pid for pid, rows in queue.items() if ledger_id in rows[0]['ledger']]
            update = {'id': ledger_id, 'by': 'learner:strategy-proposal',
                      'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                      'note': f'{BATCH}核验关联提案{",".join(related)}：十项均waiting；8274原字节引用及四同指纹配对已核，已有子项不冒整项duplicate，缺口详报告；不新增support/repeat或更改原claim/状态/版本。0016保持覆甲claim，原金刚杵误链异议沿既有b07c96b10b1facb9f887a710保留。'}
            handle.write(json.dumps(update, ensure_ascii=False) + '\n')
    print(json.dumps({'proposal_results': len(results), 'ledger_links_prepared': len(ledger_ids), 'base': pins['base']}, ensure_ascii=False))


if __name__ == '__main__':
    main()

import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract_evidence', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
TARGETS = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
           '8JRE1C4H4Z2W': [17, 33], 'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [33]}


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}


def compact(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
            'ts': row.get('observed_ts', row.get('ts')), 'turn': state.get('turn'),
            'screen': state.get('screen'), 'hp': player.get('current_hp'), 'block': player.get('block'),
            'cards_played': player.get('cards_played_this_turn'), 'player_powers': powers(player.get('powers')),
            'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                         'max_hp': e.get('max_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
                         'move': e.get('move_id'), 'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies', [])]}


def main():
    states = []
    source = Path('/home/dw/Projects/agent-sts2/logs/states.jsonl')
    verified = 0
    with source.open('rb') as raw_source, (HERE / 'evidence/states.evidence.jsonl').open() as handle:
        for line in handle:
            if not line.endswith('\n'):
                continue
            item = json.loads(line)
            raw_source.seek(item['offset'])
            raw = raw_source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert extractor.run_identity(json.loads(raw)) == item['run_id']
            verified += 1
            state = item['row']['state']
            run = state.get('run') or {}
            if run.get('floor') in TARGETS[item['run_id']] and state.get('combat'):
                states.append((item['run_id'], run['floor'], compact(item)))
    grouped = {}
    previous = {}
    for run, floor, frame in states:
        key = f'{run}/F{floor}'
        if not isinstance(frame['turn'], int) or frame['turn'] < 1:
            continue
        attempt, old_turn = previous.get(key, (1, frame['turn']))
        if frame['turn'] < old_turn:
            attempt += 1
        previous[key] = (attempt, frame['turn'])
        grouped.setdefault(f'{key}/A{attempt}/T{frame["turn"]}', []).append(frame)
    windows = []
    keys = list(grouped)
    for i, key in enumerate(keys):
        frames = grouped[key]
        first, last = frames[0], frames[-1]
        successor = grouped[keys[i + 1]][0] if i + 1 < len(keys) and keys[i + 1].rsplit('/T', 1)[0] == key.rsplit('/T', 1)[0] else None
        enemy_hp = lambda f: sum(e['hp'] for e in f['enemies'] if e['alive'] is not False and isinstance(e['hp'], (int, float)))
        windows.append({'key': key, 'first': first, 'last': last, 'next_turn': successor,
                        'hp_loss_to_next': first['hp'] - successor['hp'] if successor else None,
                        'enemy_net_hp_to_next': enemy_hp(first) - enemy_hp(successor) if successor else None,
                        'note': '只作端点净差；换阶段、召唤、复活与未结算回合不作行动伤害归因。'})
    (HERE / 'state-windows.json').write_text(json.dumps(windows, ensure_ascii=False, indent=2) + '\n')
    (HERE / 'selected-state-frames.json').write_text(json.dumps(states, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'verified_state_rows': verified, 'selected_frames': len(states), 'turn_windows': len(windows)}, ensure_ascii=False))
    for w in windows:
        if '/F33/' in w['key'] and w['key'].split('/')[0] in ['8JRE1C4H4Z2W', 'XP2SL33HT0D9'] or w['key'].startswith('YF0LXT1QSTGG/F48/'):
            print(json.dumps({'key': w['key'], 'first_line': w['first']['line'], 'last_line': w['last']['line'],
                              'next_line': w['next_turn']['line'] if w['next_turn'] else None,
                              'hp': w['first']['hp'], 'loss': w['hp_loss_to_next'], 'net_enemy_hp': w['enemy_net_hp_to_next']}, ensure_ascii=False))


if __name__ == '__main__':
    main()

import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { parseGameState } from '../../../agent/src/hand/mod/schema.ts';
import { silentPhaseCurrentFacts } from '../../../agent/src/reflex/silent-phase-current.ts';
import { monsterHpAt, moveDamageAt } from '../../../agent/src/knowledge/monster-db.ts';
import { measuredRoom, setRoomCostsForTests } from '../../../agent/src/knowledge/room-costs.ts';

const inputBytes = readFileSync(new URL('./consumer-input.json', import.meta.url));
const input = JSON.parse(inputBytes);
const results = [];
const check = (label, actual, expected) => {
  results.push({ label, actual, expected, pass: JSON.stringify(actual) === JSON.stringify(expected) });
};
for (const { line, state: raw } of input.phase_frames) {
  const before = JSON.stringify(raw);
  const facts = silentPhaseCurrentFacts(parseGameState(raw)).test_subject_current;
  const enemy = raw.combat.enemies[0];
  const amount = (powers, id) => powers.find(p => p.power_id === id)?.amount ?? 0;
  check('阶段本帧 ' + line, [facts.enemy_hp_now, facts.enemy_max_hp_now, facts.poison_now,
    facts.accelerant_established_now, facts.dexterity_now, facts.block_now, facts.poison_damage_already_dealt],
    [enemy.current_hp, enemy.max_hp, amount(enemy.powers, 'POISON_POWER'),
      amount(raw.combat.player.powers, 'ACCELERANT_POWER'), amount(raw.combat.player.powers, 'DEXTERITY_POWER'), raw.combat.player.block, null]);
  check('原帧未被改写 ' + line, JSON.stringify(raw), before);
}
const hp = monsterHpAt(input.monster_fixture, 'SEWER_CLAM', 10);
check('A10首个HP样本直接读取', [hp.hp, hp.n, hp.from, hp.estimated], [58, 1, 10, false]);
const damage = moveDamageAt(input.monster_fixture, 'SEWER_CLAM', 'JET_MOVE', 10);
check('A10首个伤害样本直接读取', [damage.perHit, damage.hits, damage.from, damage.estimated], [11, 1, 10, false]);
for (const n of [4, 5]) {
  setRoomCostsForTests({ 10: { 1: { Monster: { n, median: 0, p75: 0, mean: 0 } } } });
  check('房间五样本门槛 n=' + n, measuredRoom(1, 10, 'Monster')?.n ?? null, n === 5 ? 5 : null);
}
setRoomCostsForTests(null);
const output = { scope: '显式固定输入的函数探针，不是历史刷新输入复原或生产联合校准',
  input_sha256: createHash('sha256').update(inputBytes).digest('hex'),
  passed: results.filter(r => r.pass).length, failed: results.filter(r => !r.pass).length, results };
writeFileSync(new URL('./consumer-output.json', import.meta.url), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ passed: output.passed, failed: output.failed, input_sha256: output.input_sha256 }));
process.exitCode = output.failed ? 1 : 0;

"""Check bounded claims against the independently extracted Silent observations."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = json.load(open(OUT / 'states-compact.json'))
S = {s['line']: s for s in states}
D = {d['line']: d for d in json.load(open(OUT / 'decisions-compact.json'))}
checks = []

def check(label, actual, expected, citations):
    checks.append({'label': label, 'actual': actual, 'expected': expected,
                   'pass': actual == expected, 'citations': citations})

def pp(line, power):
    return S[line]['player_powers'].get(power, 0)

def enemy(line, ident):
    found = [e for e in S[line]['enemies'] if e['id'] == ident]
    assert len(found) == 1, (line, ident)
    return found[0]

check('T4污染逐步与能力不加污染', [pp(n, 'TAINTED_POWER') for n in range(274830, 274834)], [0, 3, 3, 6], ['states:274830-274833'])
check('T5污染逐技能增长', [pp(n, 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]], [0, 6, 12, 18], ['states:274834-274838'])
check('火花3至6', [enemy(n, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'] for n in [274830, 274834]], [3, 6], ['states:274830', 'states:274834'])
check('污染次轮移除', pp(274839, 'TAINTED_POWER'), 0, ['states:274839'])
check('T4/T5实付净HP', [S[274830]['hp']-S[274834]['hp'], S[274834]['hp']-S[274839]['hp']], [3, 9], ['states:274830/274834/274839'])
check('迷雾实际施毒而非只增污染', [enemy(n, 'INFESTED_PRISM')['powers']['POISON_POWER'] for n in [274830, 274831, 274837, 274838]], [2, 8, 7, 13], ['states:274830/274831/274837/274838'])
check('失落/遗忘第二次抢夺现场', [pp(274351, 'STRENGTH_POWER'), pp(274351, 'DEXTERITY_POWER')], [-4, -4], ['states:274351'])
check('两步法后敏捷恢复0', pp(274357, 'DEXTERITY_POWER'), 0, ['states:274357'])
check('失落退场后力量恢复0', [pp(274358, 'STRENGTH_POWER'), [e['id'] for e in S[274358]['enemies']]], [0, ['THE_FORGOTTEN']], ['states:274357-274358'])
check('遗忘再次抢夺敏捷', [pp(274362, 'DEXTERITY_POWER'), enemy(274362, 'THE_FORGOTTEN')['powers']['DEXTERITY_POWER']], [-2, 6], ['states:274362'])
check('末试单步法后敏捷仍负', pp(274392, 'DEXTERITY_POWER'), -2, ['states:274391-274392'])
check('末试仍死亡的反例', [S[274396]['hp'], S[274396]['block'], S[274397]['hp']], [8, 0, 0], ['states:274396-274397'])
check('高电压现场连续增长', [[enemy(n, 'ZAPBOT')['max_hp'], enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'], enemy(n, 'ZAPBOT')['attacks']] for n in [274308, 274313]], [[23, 2, [[17, 1]]], [23, 4, [[19, 1]]]], ['states:274308/274313'])
check('高电压T3未退场且索引重排', [enemy(274312, 'ZAPBOT')['index'], enemy(274308, 'ZAPBOT')['index'], S[274308]['hp']-S[274313]['hp']], [3, 4, 30], ['states:274308-274313'])
check('高电压T4才清除', [e['id'] for e in S[274317]['enemies']], ['FABRICATOR'], ['states:274317'])
check('蚌力量与喷水现场', [[enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0), enemy(n, 'SEWER_CLAM')['attacks']] for n in [273237, 273252, 273263]], [[0, [[11, 1]]], [4, [[15, 1]]], [8, [[19, 1]]]], ['states:273237/273252/273263'])
check('蚌弱后11与14', [enemy(n, 'SEWER_CLAM')['attacks'] for n in [273257, 273268]], [[[11, 1]], [[14, 1]]], ['states:273257/273268'])
check('蚌覆甲是观察序列', [enemy(n, 'SEWER_CLAM')['powers']['PLATING_POWER'] for n in [273237, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], ['states:273237/273247/273252/273258/273263'])
check('蚌末态差2血', [S[273268]['hp'], S[273268]['block'], 14-10-2, S[273269]['hp']], [2, 10, 2, 0], ['states:273268-273269'])

pairs = []
for a, b, expected in [(270216, 270282, [3, 15, 10, 17]), (271309, 271348, [0, 9, 45, 38]), (271982, 272195, [2, 10, 25, 34]), (271992, 272040, [9, 14, 24, 27])]:
    check('完整观测指纹相同 '+str(a)+'/'+str(b), D[a]['fingerprint'] == D[b]['fingerprint'], True, ['decisions:'+str(a), 'decisions:'+str(b)])
    endpoints = []
    for n in [a, b]:
        d = D[n]
        starts = [(i, s) for i, s in enumerate(states) if s['run_id'] == d['run_id'] and s['observed_ts'] == d['observed_ts'] and s['floor'] == d['floor'] and s['turn'] == d['turn'] and s['enemies']]
        assert len(starts) == 1
        i, before = starts[0]
        after = next(s for s in states[i+1:] if s['run_id'] == before['run_id'] and s['enemies'] and (s['floor'] != before['floor'] or s['turn'] != before['turn']))
        assert after['floor'] == before['floor'] and after['turn'] == before['turn'] + 1
        endpoints.append({'decision': n, 'start': before['line'], 'end': after['line'],
                          'hp_loss': before['hp']-after['hp'],
                          'enemy_net_hp': sum(e['hp'] for e in before['enemies'])-sum(e['hp'] for e in after['enemies']),
                          'strength_after': after['player_powers'].get('STRENGTH_POWER', 0)})
    check('同轮实付与本体净扣 '+str(a)+'/'+str(b), [endpoints[0]['hp_loss'], endpoints[1]['hp_loss'], endpoints[0]['enemy_net_hp'], endpoints[1]['enemy_net_hp']], expected, endpoints)
    pairs.append({'decisions': [a, b], 'endpoints': endpoints,
                  'delta_hp_loss': endpoints[1]['hp_loss']-endpoints[0]['hp_loss'],
                  'delta_enemy_net_hp': endpoints[1]['enemy_net_hp']-endpoints[0]['enemy_net_hp'],
                  'whole_fight_counterfactual_verified': False})
check('沙虫0/24与5/24并非死亡比例相同', [D[270282]['sl_explore']['numbers'][k].split(',')[0] for k in ['original', 'replacement']], ['rollout dead 0/24', 'rollout dead 5/24'], ['decisions:270282'])
check('实验体预测与实盘不同', [D[271348]['sl_explore']['numbers'][k].split(';')[-1].strip() for k in ['original', 'replacement']], ['this turn hp -0, dmg 54', 'this turn hp -10, dmg 36'], ['decisions:271348'])
check('实验体覆盖重放确实结束本轮', D[271354]['chosen']['action'], 'end_turn', ['decisions:271354'])
check('双蟹0胜并不表示五轮死亡样本数相同', [D[272076]['sl_explore']['numbers'][k].split(',')[0] for k in ['original', 'replacement']], ['rollout dead 21/24', 'rollout dead 23/24'], ['decisions:272076'])
check('实验体阶段重置现场', [[enemy(n, 'TEST_SUBJECT')['hp'], enemy(n, 'TEST_SUBJECT')['max_hp'], enemy(n, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0), enemy(n, 'TEST_SUBJECT')['powers'].get('STRENGTH_POWER', 0)] for n in [277512, 277513]], [[4, 111, 4, 15], [212, 212, 0, 0]], ['states:277512-277513'])
check('零毒且触媒已建', [pp(277519, 'ACCELERANT_POWER'), enemy(277519, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)], [2, 0], ['states:277519'])
check('后得敏捷不倒补既有挡', [[pp(n, 'DEXTERITY_POWER'), S[n]['block']] for n in [277524, 277526]], [[5, 23], [6, 23]], ['states:277524/277526'])
check('实验体末轮净扣37与死亡', [enemy(277519, 'TEST_SUBJECT')['hp']-enemy(277528, 'TEST_SUBJECT')['hp'], S[277528]['hp']], [37, 0], ['states:277519-277528'])
check('船夹板六尝试T2轮初14', [s['block'] for s in states if s['run_id'] == 'XP2SL33HT0D9' and s['floor'] == 33 and s['turn'] == 2 and s['played'] == 0 and s['enemies']], [14]*6, ['states:278023/278071/278104/278152/278196/278236'])
check('普通镣铐临时减力与恢复', [enemy(n, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) for n in [278236, 278237, 278242]], [0, -9, 0], ['states:278236/278237/278242'])
check('现场挡14加6且当轮零损', [S[278236]['block'], S[278240]['block'], S[278236]['hp']-S[278242]['hp']], [14, 20, 0], ['states:278236/278240/278242'])
check('朝向和弱的现场分账', [enemy(n, 'ROCKET')['attacks'] for n in [278249, 278252, 278253]], [[[57, 1]], [[38, 1]], [[28, 1]]], ['states:278249/278252/278253'])
check('4敏脆弱6挡及末轮仍死', [pp(278255, 'DEXTERITY_POWER'), S[278255]['block'], S[278249]['hp']-S[278257]['hp'], S[278261]['hp']], [4, 6, 22, 0], ['states:278249/278255/278257/278261'])
sl = json.load(open(OUT / 'sl-summaries.json'))
check('保留成功SL反例', [(x['attempt'], x['result'], x['end_hp']) for x in sl if x['run_id'] == 'YF0LXT1QSTGG' and x['floor'] == 33], [(1, 'predicted_death', 4), (2, 'won', 20)], ['sl-attempts:928-929'])
check('历史六局并无新审计字段', sum(d['selection_audit'] is not None or d['selection_dispatch'] is not None for d in D.values()), 0, ['decisions.evidence.jsonl:3941所属行'])
result = {'checks': checks, 'passed': sum(c['pass'] for c in checks), 'failed': sum(not c['pass'] for c in checks), 'pairs': pairs,
          'scope': '固定历史材料核验，不是tsc/vitest、生产联合校准或策略收益测试'}
(OUT / 'findings-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'passed': result['passed'], 'failed': result['failed']}, ensure_ascii=False))
raise SystemExit(bool(result['failed']))

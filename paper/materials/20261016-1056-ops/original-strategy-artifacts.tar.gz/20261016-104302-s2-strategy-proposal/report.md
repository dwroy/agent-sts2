# Silent策略学习批次报告

完成范围：本批领取的十个原提案全部逐项核对，均 waiting；没有源码或知识修改，没有提交、live合入、版本或规则通知。详细处置见 [proposal.md](proposal.md) 与 [result.json](result.json)。

## 身份与基线

- 批次：`20261016-104302-s2-strategy-proposal`；任务 strategy-proposal；角色 silent；reason=proposal。learn.json本批没有 research_request、implementation_request 或 proposal_repair；proposal_ids恰为十个派发id。普通专题条件不成立，未承接另一批专题或扩展选题。
- 起始 git status 空，按任务 git merge --no-edit main 返回 Already up to date；完整 base/最终目标HEAD：`15aa330a851086c77b40492228813fd756f6904a`。无新提交。
- 六局均由 runs.jsonl显式身份核为SILENT A10；日志原始结束结局都是负局，SL尝试按同局处理。实际run清单：DUZUBAJ3A8GP, 5PM6JAQG6FNQ, CA5KE8GFJ9X2, 8JRE1C4H4Z2W, YF0LXT1QSTGG, XP2SL33HT0D9。
- 完整冻结输入与队列/原文/账本材料：dispatch.json、run-identities.json、queue-events.json、queue-current.json、original-proposals-manifest.json、ledger-before.json。原提案十份SHA完全匹配，原文不改写。

## 原始证据与可重现边界

共用 extract_evidence.py一次提取八流，逐流source_size和各行offset/bytes/SHA保存在 evidence/。随后 analyze.py对每条输出回读原日志原字节，逐项校验SHA、JSON相等、显式run身份、截点和逐局计数，**8274/8274通过**：states4062、decisions3941、SL38、run-config6、run-plans33、brain188、runs6、fight-plans0。

run-plans使用run字段，其余按显式run_id/state.run_id/fingerprint.run核身份，不以正文提及归属。fight-plans零行仅表示本次2233957字节截点未选到所属身份；没有宣称历史不存在。全源states/decisions各2条、brain1条无效JSON由入口跳过，未补造其身份。本批不复核旧零行截点，也未覆盖旧报告。

固定材料语义核验42项全部通过（findings-verification.json/.log）；这不是生产tsc/vitest或校准成功。核心结果：

|同指纹决策配对|原/替实际净HP损失|原/替敌本体净扣|边界|
|---|---:|---:|---|
|8JRE F33 T2，270216/270282|3/15|10/17|同题五轮死亡0/24与5/24，不能叫同死率；均未获完整胜线|
|YF F48 T1，271309/271348|0/9|45/38|题面候选则损0/10、伤54/36；271354覆盖重放结束本轮|
|XP F33 T1，271982/272195|2/10|25/34|替线额外建1力量，后继抽序与打法不同|
|XP F33 T3，271992/272040|9/14|24/27|两线原有限样本均全败，原线无整战胜局|

这些数字只描述同轮净端点，不冒充逐源攻击总量或整候选认证。配对起点由原decision observed_ts精确连到唯一状态，终点是同floor下一turn；物理行号见findings-verification.json。不能据此拟血价常数。YF F33第二次SL确实实胜余20（sl-attempts929），反例完整保留。

机制方面：DUZ F27火花3→6、技能污染0→3→6与0→6→12→18、迷雾施毒及次轮撤污染；5PM F39负力敏−4/−4、步法/失落退场后恢复及遗忘再夺；5PM F38高电压17→19、索引4→3与T4退场；CA5 F13力0/4/8及喷水11/15/19、弱后11/14均由原帧核实。它们不补充未观察的叠加/减层/实例继承规则。

YF F48末试4血4毒旧阶段→212血零毒新阶段；T5触媒2且零毒；敏捷5→6而既有23挡不变。XP六次T2轮初14挡、普通镣铐0→−9→0力、14+6→20且零损、背向/转向/弱57→38→28、4敏脆弱6挡及终局仍死均核实。没有从持有能力或未来毒预支已经兑现收益。

## 已有源码与消费者边界

审计live锚点：`0e7998bfa8df267dcf8835a57949bdb982c9feb0`。16个相关源码叶的最后提交均为该live祖先；13叶字节相同，card-model/rollout-live/passive-pieces三叶仅历史Roy/Dai注释文字差异，完整git diff --binary存source-live-diff.patch。live agent/src工作区状态为空（live-source-status.txt）。本批不合入或改写这三处历史文字。

窄功能来源和base/live祖先已实核（feature-source-ancestors.json）：

- 候选比较、HP护栏和SL资源审计：66283dd9982bdd7f480da7a4d9bfefea0572a9ac；selection-audit后续叶最后提交9d8278702dbc581b5015ba7ec9a70dc0fb94cccb。
- 单动作派发回执：fdaf787a372880b0438e73bcac7e6d2168b038ed。
- 实验体当前阶段现场值：aad2700abed6dff1d66e87fb36aaa6fedb39adf3。
- 既有污染/高电压/船夹板模型所在祖先：295a90aef9eb6f5b267490294f7733806419c45a。它是既有源码来源，不是本批新实现。

当前 combat-plan.ts接入上述字段，hand/loop.ts接入单动作回执；actual_turn、whole_plan_executed和poison_damage_already_dealt等仍明确未知，不能当全执行消费者。历史3941条决策没有后来新增的selection_audit/selection_dispatch，不能把当前功能倒填为当时自然日志已有。

六局run-config的40位源码提交全部存在，dirty_files均限知识/notes，未列生产可执行文件（historical-source-availability.json）。所以不能笼统称源码无法定位；缺的是当时刷新知识/移动表的具体字节及完整联合输入，不用今天JSON替代它。

额外运行16项有界函数读回，全部通过：六张原始实验体帧直接调用现有silentPhaseCurrentFacts，逐项核现场和输入不变；从CA5 F13 T1观察构造显式n=1夹具核HP58与喷水11直读；纯接口哨兵夹具核房间n4拒/n5纳。输入SHA：`229d3ccd8cd65a35503dd2b5b9560e0422fde67d49a65522e0b0c7f6403182cd`。文件consumer-input.json、consumer_probe.mjs、consumer-output.json与stdout/stderr均保存，进程exit0。只调这些确定性函数，不调LLM/网络/游戏，不读取刷新的知识JSON；不重跑整场模拟。这些读回只说明现有窄接口行为，不是历史dirty输入复原、自然消费或联合校准。

## 十项处置与后续输入

1. `silent-proposal-c20b5139dd0dff71`：waiting。污染逐技能血价、HAZE施毒与火花接线已有窄实现；本批仅重核DUZ F27 T4—6，缺实际刷新移动表与火花增长/污染撤除/弱毒挡的联合校准，未观察可唯一归责的新模型差额，不能另定技能或终局权重。

2. `silent-proposal-ae9e692d680e3819`：waiting。5PM F39可核负力敏、两步法、失落退场归还及遗忘再夺；原帧没有稳定实例/抢夺来源累计账，也无受控后继，现帧属性公式不证明逐来源返还消费者已覆盖，不能定击杀序。

3. `silent-proposal-52f1e1bd2e7db0ed`：waiting。A10首样本HP/攻击API及房间五样本门槛已有实现并经显式固定输入读回；CA5 F13只支持0/4/8力量和11/15/19及弱后端点，缺历史移动表字节与加压/覆甲/弱联合重放，不补覆甲减层规则。

4. `silent-proposal-6dd8bbff876be528`：waiting。高电压逐轮增长已有源码；5PM F38的23上限电击可核2→4力和17→19攻且索引4→3，未给稳定实例/新召唤代际，不足以核跨代重置及实际A10输入的联合校准。

5. `silent-proposal-578e415a259e6835`：waiting。原答/护栏/SL候选及单动作回执已有窄审计；8J两线同轮血价与能力建立可核，仍缺抽弃牌后整候选身份、逐源兑现及路线/药水/SL恢复联合消费者，候选省血不能当实际收益。

6. `silent-proposal-c0767768bf6a7ab1`：waiting。YF F48第二/第三试T1实损0/9、净扣45/38已核；覆盖重放后续步被截断，缺整线执行归属、未派发续步和独立获胜后继，F33成功SL反例保留，不拟惩罚系数或禁探索。

7. `silent-proposal-a46bdb7fe711d79a`：waiting。实验体当前阶段/零毒与已建能力现场字段已有实际live祖先；YF末试阶段重置及5→6敏捷不倒补23挡已核，缺逐候选施毒、已结毒伤、取得顺序及跨阶段完整执行对账，不能改排名。

8. `silent-proposal-1044224808015e5c`：waiting。XP同指纹T1多8血换9净扣并建1力、T3多5血换3净扣已核；缺受控抽序、随机落点后继和独立完整胜线，B2零胜并列不证明安全，不拟全局HP/成长系数。

9. `silent-proposal-7cbc6005db712ba9`：waiting。船夹板14挡、普通镣铐临减恢复和朝向/弱已有窄实现；XP末试57→38→28、14+6→20与4敏脆弱6挡已核，缺逐候选联合作用、抽弃牌重规划后完整执行与未选后继，不能关闭宽提案。

10. `silent-proposal-c59f592f1427a67e`：waiting。六锚点支持本批机制与四组当轮配对，不能替原101局的联合资源重建；完整候选、路线/休息/用药/SL恢复消费者及独立替线后继仍缺，不关闭经验入库或量化学习父要求。

逐项证据局号、层/回合、全部原账本、反例、旧/新行为、后移验证与回退已在proposal.md保存。保留原已实现子项，不拿窄字段关闭宽提案；本批无新增/反对原机制的结论，不重复登记support/repeat。不能用六锚点冒称覆盖原101局或关闭学习入库/量化父要求；没有发布经验库或消费者已采用的新声明。

## 验证、记录与现场

- 生产源码撤除失败/恢复通过：不适用，没有源码修改；未伪造红绿结果。
- tsc/vitest/cases均为null，未运行本批生产套件；材料42项、函数探针16项另列，不能填成生产测试0。
- fixes=[]，merged=null，无源提交、无eval版本、无上线、无shipped；没有需要双通知的实际规则变更。
- 只通过根目录ledger.py update为30个既有silent账本追加本批proposal/report追溯；不传status，不降级既有shipped、不重复证据、不改claim/首证/prior/version。真实CLI和后核回执另存。
- 开工未触专题/实现注册、队列状态或请求文件；不写复盘、不另领id、不修改ops prompt、不运行play、不联网、不推送、不启动下级agent。
- 早期只读探针误猜agent/src/loop.ts及fight-costs路径报FileNotFound/rg2，改为rg --files找到hand/loop.ts和room-costs.ts；原工具转录保留，说明见probe-errors.md，不当产品故障。本轮无测试/源码修复失败。

最终核收：根ledger CLI实际exit0，30条物理追加逐行offset/bytes/SHA与字段已读回；30条旧claim、首证、asc、prior、完整evidence、status、version/shipped_at均不变，history/notes前缀与原where保留。最终HEAD仍等于上述base，git status空、git diff --binary为空；见ledger-readback.json和final-closure.json。

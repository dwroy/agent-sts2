"""Verify frozen source bytes and preserve compact, run-scoped observations."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extractor', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def powers(values):
    return {p['power_id']: p['amount'] for p in values or []}

def compact(item):
    r = item['row']
    s = r['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {'line': item['line'], 'run_id': item['run_id'], 'ts': r.get('ts'),
            'observed_ts': r.get('observed_ts'), 'floor': (s.get('run') or {}).get('floor'),
            'turn': s.get('turn'), 'screen': s.get('screen'),
            'hp': p.get('current_hp', (s.get('run') or {}).get('current_hp')),
            'block': p.get('block'), 'player_powers': powers(p.get('powers')),
            'played': p.get('cards_played_this_turn'),
            'hand': [x.get('card_id') for x in c.get('hand', [])],
            'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'),
                         'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                         'block': e.get('block'), 'alive': e.get('is_alive'),
                         'move': e.get('move_id'), 'powers': powers(e.get('powers')),
                         'attacks': [[i.get('damage'), i.get('hits')] for i in e.get('intents', []) if i.get('damage') is not None],
                         'identity_fields': {k: v for k, v in e.items() if 'instance' in k or 'uuid' in k or 'generation' in k}}
                        for e in c.get('enemies', [])]}

states, decisions, anchors, summaries, configs = [], [], {}, [], []
anchor_lines = set(range(277327, 277338)) | set(range(277366, 277374)) | set(range(277512, 277529)) | set(range(278017, 278022)) | set(range(278231, 278256))
verified = {}
for meta in json.load(open(OUT / 'evidence/evidence-manifest.json')):
    stream = meta['stream']
    counts = Counter()
    digest = hashlib.sha256()
    with open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as source:
        for line in open(OUT / 'evidence' / (stream + '.evidence.jsonl'), 'rb'):
            digest.update(line)
            a = json.loads(line)
            source.seek(a['offset'])
            raw = source.read(a['bytes'])
            assert hashlib.sha256(raw).hexdigest() == a['sha256']
            assert json.loads(raw) == a['row']
            assert a['offset'] + a['bytes'] <= meta['source_size']
            assert extractor.run_identity(a['row']) == a['run_id']
            counts[a['run_id']] += 1
            r = a['row']
            if stream == 'states':
                states.append(compact(a))
                if a['line'] in anchor_lines:
                    anchors[str(a['line'])] = r['state']
            elif stream == 'decisions':
                decisions.append({'line': a['line'], **{k: r.get(k) for k in
                    ['run_id', 'ts', 'observed_ts', 'floor', 'turn', 'sl_attempt', 'fingerprint', 'decision_id',
                     'chosen', 'result', 'answers', 'sl_explore', 'rollout', 'rationale', 'sl_retry', 'reused_answer']},
                    'selection_audit': r.get('selection_audit'), 'selection_dispatch': r.get('selection_dispatch')})
            elif stream == 'sl-attempts':
                summaries.append({'line': a['line'], **r})
            elif stream == 'run-config':
                configs.append({'line': a['line'], 'run_id': a['run_id'], 'code': r['code'],
                                'character': r['character'], 'ascension': r['ascension']})
    assert dict(counts) == {k: v for k, v in meta['counts'].items() if v}
    assert digest.hexdigest() == meta['output_sha256']
    verified[stream] = {'count': sum(counts.values()), 'source_size': meta['source_size'],
                        'counts': meta['counts'], 'output_sha256': digest.hexdigest(),
                        'offset_bytes_sha_json_identity_verified': True}
save('verified-evidence.json', verified)
save('states-compact.json', states)
save('decisions-compact.json', decisions)
save('raw-anchors.json', anchors)
save('sl-summaries.json', summaries)
save('run-source-configs.json', configs)
print(json.dumps({'verified_rows': sum(m['count'] for m in verified.values()),
                  'streams': {k: v['count'] for k, v in verified.items()},
                  'states': len(states), 'decisions': len(decisions), 'anchor_states': len(anchors)}, ensure_ascii=False))

# 只读定位失败记录

1. 首次源码审计尝试读取agent/src/loop.ts，Python抛FileNotFoundError，exit1；当时尚未写source-audit.json。按rg --files定位为agent/src/hand/loop.ts，后续16叶审计保存独立完整结果。
2. rg首次猜测agent/src/knowledge/fight-costs.ts及fight*.ts不存在，exit2；后按rg --files定位room-costs.ts，实际源码门槛MEASURED_ROOM_MIN_N=5。
3. 若干早期工具输出超过显示上限被截断；所有所需原提案在截断前已按原字节复制并保存SHA，后续按有界文件区段/字段读取。没有用截断输出作完整核验。

原失败发生在本轮只读工具探针，原转录未更改；没有执行源码修复、改变断言、重装依赖、切换模型或改游戏规则。

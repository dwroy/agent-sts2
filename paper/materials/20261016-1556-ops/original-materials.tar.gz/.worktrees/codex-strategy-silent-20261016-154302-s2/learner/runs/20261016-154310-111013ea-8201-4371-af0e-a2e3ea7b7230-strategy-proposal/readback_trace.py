import copy
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
inputs = [json.loads(line) for line in (HERE / 'ledger-updates.jsonl').read_text().splitlines()]
assert (HERE / 'ledger-cli.stdout.txt').read_text().split() == [row['id'] for row in inputs]
assert not (HERE / 'ledger-cli.stderr.txt').read_bytes()
expected = {row['id']: row for row in inputs}
before_fold = json.loads((HERE / 'ledger-before.json').read_text())
private_fold = copy.deepcopy(before_fold)
spec = importlib.util.spec_from_file_location('trace_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
raw_ledger = (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()
own = []
offset = 0
for raw in raw_ledger.splitlines(keepends=True):
    row = json.loads(raw)
    item = expected.get(row.get('id'))
    if item and row.get('note') == item['note']:
        assert set(row) == set(item) | {'op', 'ts'}
        assert row['op'] == 'update' and all(row[key] == value for key, value in item.items())
        ledger.apply(private_fold, row)
        own.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                    'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert [row['id'] for row in own] == list(expected)
protected = ['character', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'shipped_at', 'effect']
assert all(before_fold[ident].get(key) == private_fold[ident].get(key)
           for ident in expected for key in protected)
base = json.loads((HERE / 'source-audit.json').read_text())['base']
committed = subprocess.check_output(['git', 'show', base + ':paper/materials/learning/ledger.jsonl'])
physical_prefix = raw_ledger[:own[0]['offset']]
physical_before = ledger.fold([(i, json.loads(line)) for i, line in enumerate(physical_prefix.splitlines(), 1) if line.strip()])
physical_private = copy.deepcopy(physical_before)
for row in own:
    ledger.apply(physical_private, row['row'])
assert all(physical_before[ident].get(key) == physical_private[ident].get(key)
           for ident in expected for key in protected)
audit = {'cli_exit_code': 0, 'cli_repeated': False,
         'initial_reader_failure': 'CLI成功后把空格分隔ID误按splitlines核验，断言失败；原脚本与失败保留，仅改为split读回。',
         'committed_prefix_base': base, 'committed_prefix_bytes': len(committed),
         'committed_prefix_sha256': hashlib.sha256(committed).hexdigest(),
         'committed_prefix_matches_physical': raw_ledger.startswith(committed),
         'committed_prefix_boundary': '基线提交与根物理账本不是相同前缀；该比较不能代替实际起点。原失败保留，不重写或调查其他记录。',
         'physical_prefix_before_own_rows_bytes': len(physical_prefix),
         'physical_prefix_before_own_rows_sha256': hashlib.sha256(physical_prefix).hexdigest(),
         'physical_prefix_hash_captured_before_cli': False,
         'initial_full_physical_prefix_hash': None,
         'initial_full_physical_prefix_hash_limitation': '首次脚本失败前未持久化内存中的原物理前缀，不冒称保存了该截点SHA。',
         'protected_fields_unchanged_in_private_fold': protected, 'own_rows': own,
         'scope': '本批30行仅where/note；物理逐字节读回并与输入相同，其他并行记录不代确认。'}
(HERE / 'ledger-update-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_own_rows': len(own), 'cli_repeated': False,
                  'committed_prefix_matches_physical': raw_ledger.startswith(committed),
                  'protected_fields_unchanged': True}, ensure_ascii=False))

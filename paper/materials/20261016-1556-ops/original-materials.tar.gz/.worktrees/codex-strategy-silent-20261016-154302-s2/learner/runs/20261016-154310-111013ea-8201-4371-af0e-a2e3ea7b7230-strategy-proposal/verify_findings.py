import json
from pathlib import Path

here = Path(__file__).resolve().parent
rows = {x['line']: x for x in json.loads((here / 'state-projections.json').read_text())}
checks = []

def check(name, lines, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'finding': name, 'state_lines': lines, 'actual': actual, 'expected': expected})

def pp(line, power):
    return rows[line]['powers'].get(power, 0)

def enemy(line, ident):
    matches = [x for x in rows[line]['enemies'] if x['id'] == ident]
    assert len(matches) == 1
    return matches[0]

check('DUZ T4技能污染与能力分开', [274830, 274831, 274832, 274833],
      [pp(n, 'TAINTED_POWER') for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6])
check('DUZ火花增长及下一轮污染清除', [274833, 274834, 274839],
      [[enemy(n, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'], pp(n, 'TAINTED_POWER')] for n in [274833, 274834, 274839]],
      [[3, 6], [6, 0], [6, 0]])
check('DUZ T5污染阶梯与实损', [274834, 274836, 274837, 274838, 274839],
      [[pp(n, 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]], rows[274834]['hp'] - rows[274839]['hp']], [[0, 6, 12, 18], 9])
check('CA5 A10喷水与力量', [273238, 273252, 273263],
      [[enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0), enemy(n, 'SEWER_CLAM')['attack']] for n in [273238, 273252, 273263]],
      [[0, 11], [4, 15], [8, 19]])
check('CA5弱后现场意图', [273254, 273268], [enemy(n, 'SEWER_CLAM')['attack'] for n in [273254, 273268]], [11, 14])
check('CA5零血截断与算术差额分列', [273268, 273269],
      [rows[273268]['hp'], rows[273268]['block'], enemy(273268, 'SEWER_CLAM')['attack'], rows[273269]['hp']], [2, 10, 14, 0])
check('5PM电击类型端点与索引重排', [274308, 274313],
      [[enemy(n, 'ZAPBOT')['index'], enemy(n, 'ZAPBOT')['max_hp'], enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'], enemy(n, 'ZAPBOT')['attack']] for n in [274308, 274313]],
      [[4, 23, 2, 17], [3, 23, 4, 19]])
check('5PM两步法与负敏捷', [274351, 274352, 274354], [pp(n, 'DEXTERITY_POWER') for n in [274351, 274352, 274354]], [-4, -2, 0])
check('5PM失落退场后力量归还端点', [274354, 274358], [pp(n, 'STRENGTH_POWER') for n in [274354, 274358]], [-4, 0])
check('5PM后续再次抢敏', [274358, 274362], [pp(n, 'DEXTERITY_POWER') for n in [274358, 274362]], [0, -2])
check('8J末轮攻击参考与实际截断分开', [276433, 276434],
      [rows[276433]['hp'], rows[276433]['block'], enemy(276433, 'THE_INSATIABLE')['attack'], rows[276434]['hp'], enemy(276434, 'THE_INSATIABLE')['hp']], [5, 22, 37, 0, 130])
check('YF阶段清毒', [277512, 277513], [[enemy(n, 'TEST_SUBJECT')['max_hp'], enemy(n, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)] for n in [277512, 277513]], [[111, 4], [212, 0]])
check('YF持有能力不预支毒收益', [277519], [pp(277519, 'ACCELERANT_POWER'), enemy(277519, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)], [2, 0])
check('YF后得敏捷不倒补既有格挡', [277524, 277526], [[pp(n, 'DEXTERITY_POWER'), rows[n]['block']] for n in [277524, 277526]], [[5, 23], [6, 23]])
check('YF末轮净本体变化', [277519, 277528], enemy(277519, 'TEST_SUBJECT')['hp'] - enemy(277528, 'TEST_SUBJECT')['hp'], 37)
check('XP轮初船夹板与另加格挡分开', [278236, 278240], [rows[n]['block'] for n in [278236, 278240]], [14, 20])
check('XP普通镣铐当轮与恢复', [278236, 278237, 278242], [enemy(n, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) for n in [278236, 278237, 278242]], [0, -9, 0])
check('XP朝向与弱分开', [278249, 278252, 278253], [enemy(n, 'ROCKET')['attack'] for n in [278249, 278252, 278253]], [57, 38, 28])
check('XP四敏脆弱现场挡值', [278254, 278255, 278258], [[pp(n, 'DEXTERITY_POWER'), rows[n]['block']] for n in [278254, 278255, 278258]], [[4, 0], [4, 6], [4, 6]])
pairs = json.loads((here / 'paired-turn-endpoints.json').read_text())
check('四组同指纹端点差额', [], [[x['delta_hp_loss'], x['delta_enemy_body_hp_net_removed']] for x in pairs], [[12, 7], [9, -7], [5, 3], [8, 9]])
(here / 'findings-verification.json').write_text(json.dumps({'checks': checks, 'count': len(checks), 'scope': '冻结原帧事实断言；不是生产测试或完整候选校准'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': 0, 'findings': len(checks)}, ensure_ascii=False))

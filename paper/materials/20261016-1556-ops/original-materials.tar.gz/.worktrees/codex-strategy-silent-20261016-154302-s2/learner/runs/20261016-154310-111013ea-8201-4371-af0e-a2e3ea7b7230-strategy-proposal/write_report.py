import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch.json').read_text())
assigned = json.loads((HERE / 'assigned-proposals.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
audit = json.loads((HERE / 'evidence-audit.json').read_text())
consumer = json.loads((HERE / 'prior-consumer-readback.json').read_text())
findings = json.loads((HERE / 'findings-verification.json').read_text())
recorded = (HERE / 'recorded-time.txt').read_text().strip()
details = [
    ('silent-proposal-c20b5139dd0dff71', 'DUZUBAJ3A8GP F27 T4—T6',
     '火花3时技能污染0→3→6，能力不加；T5火花6、三技能0→6→12→18，实损9，次轮污染0。',
     'fa9e33062aef3aa04e82c5413dd91d4f710a942f：已有技能累积污染及逐段入伤；rollout也读取火花变化。',
     '缺火花增长、污染撤除、虚弱/毒/挡组合的同次冻结生产重放校准；当前未确认可唯一归责的新差额。',
     '技能同时有毒/挡收益，未执行替线不能证明少打技能更好。',
     '在原帧及实际移动表固定后，逐步比较污染、毒、挡、当前HP；保留全部候选，不设技能血价常数。'),
    ('silent-proposal-ae9e692d680e3819', '5PM6JAQG6FNQ F39 T2/T4—T6',
     '玩家力/敏两次抢夺至−4/−4；两步法敏捷−4→−2→0，失落退场后力量−4→0，之后敏捷0→−2。',
     '已有负属性计算；本次只核端点，不能由现帧负属性证明完整逐源返还模型。',
     '缺稳定实体与逐来源抢夺累计、毒杀退场返还及随后重抢的完整对账；没有另一杀序的受控整战后继。',
     '末试单步法只至−2敏，毒杀失落后仍8HP/0挡对19攻死亡，不能定固定击杀序。',
     '保留负力/负敏现场值；后续按来源身份固定抢夺/返还链，跨退场不复用索引身份，不从端点拟目标权重。'),
    ('silent-proposal-52f1e1bd2e7db0ed', 'CA5KE8GFJ9X2 F13 T1/T3/T5',
     '同喷水力量0/4/8对应11/15/19；弱后11/14，末2HP/10挡对14攻归零。覆甲只记现场。',
     'move-model.ts按当前进阶调用moveDamageAt；monster-db和room-costs保留五样本房间代价门槛。',
     '缺实际调用移动表与加压、覆甲、虚弱的联合生产重放校准，未证完整覆甲减层条件。',
     '零血截断实际净损2与14−10=4的攻击参考分列，不能把差2血替成固定房间成本。',
     '固定进阶、移动表和原动作前缀逐帧核11/15/19与弱后11/14；首样本事实和房间五样本成本分开。'),
    ('silent-proposal-6dd8bbff876be528', '5PM6JAQG6FNQ F38 T3/T4',
     '电击机器人23上限、力量2→4、攻击17→19，索引4→3；T3仍攻击，T4才退场。',
     '7a1a8f1f4dd8dbf46a9de6b1127cb869fea24065：已有HIGH_VOLTAGE_POWER逐轮成长。',
     '缺稳定召唤代际身份与跨代重置的冻结校准；类型/上限相同和索引重排不足以证明实体连续性。',
     '先清爪牙35伤/损3的候选未实打，不能宣称必省27血或救后场。',
     '核已观察增长，缺身份处标未知；未来固定召唤、存活、退场、再召唤链，不给新实体继承旧计数。'),
    ('silent-proposal-578e415a259e6835', '8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11；F17 T6',
     '同指纹T2原/替实际损3/15、扣敌10/17；末轮5HP/22挡对37，实际归零且敌余130。候选差不等于实省血。',
     '1698adc96ba434a46942321e0237b70657e625b2资源差值、fdaf787a372880b0438e73bcac7e6d2168b038ed单动作回执及e75438488df159b2e8e9d3458cf219b39aadd933轮端点审计已live。',
     '缺抽弃/重问后的完整候选身份、逐源能力兑现与联合资源消费者；单动作回执和轮端点不能认证整候选。',
     '0/24与5/24死亡率不同；末试多活至T11仍败，不能由回合数确定保血或成长优先级。',
     '保留原答/护栏/SL/派发分段及毒/能力/实损分账；未来固定完整续步与实际建立时点，再比较后移独立局。'),
    ('silent-proposal-c0767768bf6a7ab1', 'YF0LXT1QSTGG F48 第二/三试T1、第四试T5；F33第二试',
     '同指纹T1实际损0/9、扣敌45/38；两候选24/24死，候选损0/10与伤54/36不冒充实际。',
     '1698adc96ba434a46942321e0237b70657e625b2及既有选择/派发/轮端点审计已覆盖预测差与部分实际观测。',
     '缺未派发续步的完整执行归属和独立受控获胜后继；不能由全败并列拟探索惩罚或禁止换线。',
     '第四试T5换线未完整执行；F33第二次SL实胜，不能否定所有SL。',
     '逐候选保留封顶/死亡比例和当轮代价，重规划处中止完整执行认证；等待相同抽序的完整对照。'),
    ('silent-proposal-a46bdb7fe711d79a', 'YF0LXT1QSTGG F48 末试T3—T5',
     '阶段111/4毒→212/0毒；触媒2但零毒；敏捷5→6时既有挡仍23；末轮本体净扣37。',
     'aad2700abed6dff1d66e87fb36aaa6fedb39adf3：当前阶段、组件持有、已建能力、零毒与现场挡事实已有live实现。',
     '缺逐候选跨阶段完整执行、施毒/毒结算及格挡前后敏捷顺序的联合生产校准；当前帧事实不能认证后继收益。',
     '前几试已建毒雾或余像仍败；不能把未启动毒当唯一死因或强制能力先手。',
     '阶段后重新读现场；持有/建立/施毒/结算分列，未来按实际完整动作链核收益，不倒补敏捷或旧阶段毒。'),
    ('silent-proposal-1044224808015e5c', 'XP2SL33HT0D9 F33 首/二试T3、首/末试T1、第三试T4',
     '同指纹T3实际损9/14、扣敌24/27；T1实际损2/10、扣敌25/34并加力量，不能抹掉成长。',
     '1698adc96ba434a46942321e0237b70657e625b2已有资源比较，fdaf787a372880b0438e73bcac7e6d2168b038ed有单动作回执。',
     '缺同抽序完整后继和成长兑现的受控比较；零胜并列与单轮血价不足以拟探索门槛。',
     '末试T2零损、T3只损4，朝向/减力/抽弃影响不同；不能一律拒绝付血探索。',
     '保留当轮损失、输出、力量成长及B2样本分账；等待独立完整胜线，不加全局HP惩罚常数。'),
    ('silent-proposal-7cbc6005db712ba9', 'XP2SL33HT0D9 F33 末试T2—T5',
     'T2轮初14挡再加6成20；镣铐力量0→−9→0；T4背向57→转向38→虚弱28；4敏脆弱时挡牌6。',
     '5603f519ae6d08464e78cc66cb7eba1cd2c11aab临减恢复及已有朝向/虚弱/被动挡路径；本批只核已观察端点。',
     '缺全部修饰组合的冻结生产回放、完整执行和未选后继；现有窄覆盖不能代表全部条件校准。',
     '能力已建仍无减员；末轮毒3+7已结算10，而前五次SL末轮未结算毒不预支。早期局本批未重新分析。',
     '朝向与虚弱分列、轮初挡与新增挡分列；固定57→38→28、14+6及临减恢复，未知组合维持原行为。'),
    ('silent-proposal-c59f592f1427a67e', 'YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5',
     '两局的三组血价、阶段/临减/船夹板/能力时序与前述原帧相符；SL重置、回血、实际饮药和库存恢复须分账。',
     '上述资源比较、阶段、选择派发和离线轮端点审计属于已上线窄实现。',
     '本批六局不能替代原101局联合资源重建；完整候选、路线、休息、用药与SL恢复的逐源联合消费未闭合。',
     '六次同存档尝试不是六独立局；缺完整随机输入、未选后继及旧dirty源码/知识，不把当前源码当历史复原。',
     '沿原提案保留宽父，待同次冻结生产输入与各资源消费者逐源校准；不扩本批证据范围或新建重复提案。'),
]
assert [item[0] for item in details] == dispatch['proposal_ids']
proposal_results = [{'id': ident, 'state': 'waiting', 'reason': missing}
                    for ident, _, _, _, missing, _, _ in details]
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-154302-s2-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [],
          'skipped': proposal_results, 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': proposal_results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

proposal = [f'# 本批十项策略提案处置\n\n记录时间：{recorded}。批次20261016-154302-s2-strategy-proposal，silent、已观察A10。',
            f'基线{source["base"]}；来源/目标任务与授权保留各原提案，不扩展领取。全部waiting，不新建ID，不把局部源码当整体完成。',
            '仅重新核六个派发局；旧提案引用的其他本角色历史统计保留原文，本批不冒称重新覆盖。以下事实是发现/回归输入；相关SL不扩独立样本分母。',
            '本批保留现有候选、选择/并列、HP护栏、药价、SL及终局价值。没有足够可归责新差额或受控后继来拟合新参数。无生产变更可回退；后续实现只在原提案下窄接，须固定数据撤源码红/恢复绿、自测和实际live后再记版本/通知。']
for ident, location, facts, existing, missing, counter, validation in details:
    p = next(p for p in assigned if p['id'] == ident)
    proposal.extend([f'## {ident}',
                     f'原提案：{HERE / (ident + ".md")}；原路径：{p["proposal"]}；保存SHA256={p["proposal_sha256"]}。',
                     f'来源任务：{p["source_task"]}；实现任务：strategy-proposal；账本：{", ".join(p["ledger"])}。',
                     f'证据：{location}。{facts}', f'已有实现/旧行为：{existing}',
                     f'反例及限制：{counter}', f'处置：waiting。{missing}',
                     f'拟验证行为及方法：{validation}',
                     '切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。'])
(HERE / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')

stream_table = '\n'.join(f'| {row["stream"]} | {row["source_size"]} | {sum(row["counts"].values())} |'
                         for row in audit['streams'])
rows_table = '\n'.join(f'| {r["id"]} | waiting | {r["reason"]} |' for r in proposal_results)
commits = '\n'.join(f'- {row["commit"]}：{row["subject"]}。' for row in source['commits'])
report = f'''# 静默猎手指定十项策略处置报告

记录时间：{recorded}。task=strategy-proposal，character=silent，batch=20261016-154302-s2-strategy-proposal。

十项全部waiting。原始数据支持若干当轮事实，相关窄功能已有live实现；本批没有确认新的可唯一归责差额，也没有足够完整执行/联合校准/受控整战后继支持改策略。无源码或知识修改、新提案ID、源码提交、live合入、发布号或shipped；fixes=[]，merged=null。不关闭学习入库或量化父要求。

## 身份与范围

开工git status干净。已读README、最新STATE-2026-10-16、decision-log末尾、learning-protocol、learning-code-proposals；普通批次读取的strategy-research-silent.json绑定另一个旧批次，本批不承接它。根learn.json只取本批行，task/character/worktree/十proposal_ids与六局相符，reason=proposal，没有research_request、implementation_request或proposal_repair。原Markdown逐份SHA256一致，副本及队列字段保存在assigned-proposals.json和各ID.md。没有领取其他项或派下级agent。

git merge --no-edit main为Already up to date。完整base={source['base']}，HEAD保持该提交。六局均从runs.jsonl核为SILENT/A10：{','.join(dispatch['runs'])}；全部旧运行code带+dirty，不把当前源码/知识当已复原当时输入。未读其他角色私有知识，不联网、不调LLM/游戏API、不运行play或模拟、不改账号/模型/推理配置/运维prompt。原生模型及推理参数未由本批工具独立核验，不冒称已切换。

## 证据与材料核验

按指定共用extract_evidence.py提取八流并真实exit0。每流冻结source_size；8274条选中封套均逐offset/bytes/SHA256/JSON及显式所属身份读回通过，正文提及不当所属局，冲突身份拒收。run-plans按run核到33行。全流states与decisions各2条、brain1条无效JSON未归入本批证据，未见截断行。

| 流 | source_size字节 | 选中/复核行数 |
|---|---:|---:|
{stream_table}

fight-plans的0仅说明该截点未选中明确所属本六局的行，不证明原日志缺失。八流封套SHA与原134302-s2批完全相同，日志增长没有给这六个旧局带来新选中证据；未覆盖旧报告、旧截点或零行初稿。详情见evidence/evidence-manifest.json、evidence-audit.json。

重算四组同指纹轮端点：8J F33 T2损3/15、扣10/17；YF F48 T1损0/9、扣45/38；XP F33 T3损9/14、扣24/27；XP F33 T1损2/10、扣25/34。paired-turn-endpoints.json保留决策与状态原行定位。只称同轮端点差，不把净扣归给完整候选或当作整战胜因。YF预测损0/10、伤54/36不替换成实际；8J的0/24与5/24死亡不同。零血截断与显示攻击减挡的算术参考分列。

20项原帧事实断言真实通过，覆盖污染、加压/弱、负敏/返还端点、电击索引重排、末轮截断、阶段清毒、零毒触媒、后得敏捷不倒补、船夹板/临减/朝向等；findings-verification.json及原脚本/适配脚本保留。它们是材料核验，不是生产tsc/vitest或新模型校准。

复核已有六份离线消费者输入输出：各输入从本次原行重新构造，与旧gzip解码字节相同；输入/输出压缩与解码SHA、候选和动作数一致。3937动作、641候选段、186可核轮端点、450未知轮窗；各actual_full_candidate_result仍null，0为现有审计未认证，不能推成所有线都没完整执行。DUZ三条及CA5一条无decision_id元数据仍拒收，不补号。此次未重跑消费者、生产测试或长程模拟，不能借旧exit0称本批新测试通过。原件路径/SHA与逐局统计在prior-consumer-readback.json。

## 当前源码与已有live范围

只读live={source['live_checked']}。22个相关源码文件与原134302-s2基线全部逐字相同；17个与该live逐字同，5个差异均为既有Roy/Dai注释文字，精确diff已保留。没有把缺旧dirty输入归因成当前纯bug。八个窄实现源码commit均核为本base与上述实际live的真实祖先：

{commits}

monster-db当前进阶HP/攻击读取与move-model接线、房间五样本门槛保持；本批没有读取刷新DB来冒充旧生产输入。selection_audit仍是predicted_candidates，dispatch仍是single_action_receipt/whole_plan_executed=null，资源比较仍为current_turn_prediction/execution=unverified，阶段栏的已结算毒伤仍null。因此局部功能存在与既有消费者产物均不能将宽提案整体登记implemented/duplicate。逐项证据、层/回合、全部账本ID、反例、预期行为、验证与回退见proposal.md。

## 逐项处置

| id | 状态 | 具体剩余缺口 |
|---|---|---|
{rows_table}

## 记录、验证与交付

仅经根learner/ledger.py update追加本批proposal/report追溯，by=learner:strategy-proposal；保留旧claim、首证、prior、证据、status、version及shipped，不重复support/repeat或新建提案ID。CLI输入、返回、物理追加offset/bytes/SHA和私有fold保护核验保存ledger-update-audit.json。本批没有新增学习条目，已有shipped状态不降回proposed。最终由宿主消费proposal_results，不手改专用队列、learn.json、根请求、原提案或旧复盘。

无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；没有运行或声称通过生产套件，不造空合并/新版本或规则上线通知。没有新的机制反证或与旧claim冲突的新结论，不重复学习通知或代其他角色ACK。曾输出过宽的已选账本追溯字段、探测过一个不存在的源码路径；随后改用限定字段与rg文件定位，未把工具探测当产品故障，未修改原材料。

所有本批临时材料只放本任务learner/runs目录。最终HEAD、工作树、源码/knowledge/index零差异与gitleaks材料扫描的实际结果保存final-verification.json；仅为材料扫描，不称源码提交前/完整历史扫描。提案交运维：{HERE / 'proposal.md'}。报告：{HERE / 'report.md'}。机器回报：result.json。
'''
(HERE / 'report.md').write_text(report)

ledgers = sorted({ident for p in assigned for ident in p['ledger']})
updates = []
for ledger in ledgers:
    linked = [r for r in proposal_results if ledger in next(p for p in assigned if p['id'] == r['id'])['ledger']]
    updates.append({'id': ledger, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261016-154302-s2-strategy-proposal：仅追加追溯；' + '；'.join(r['id'] + ' waiting：' + r['reason'] for r in linked)
                            + '。本批不新增机制支持/复现、源码/知识/版本/合入或shipped；现有状态保留。'})
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'results': len(proposal_results), 'ledger_updates': len(updates), 'base': source['base'],
                  'report': str(HERE / 'report.md')}, ensure_ascii=False))

import copy
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
path = ROOT / 'paper/materials/learning/ledger.jsonl'
before = path.read_bytes()
spec = importlib.util.spec_from_file_location('trace_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
before_fold = ledger.fold([(i, json.loads(line)) for i, line in enumerate(before.splitlines(), 1) if line.strip()])
inputs = [json.loads(line) for line in (HERE / 'ledger-updates.jsonl').read_text().splitlines()]
assert all(set(row) == {'id', 'by', 'where', 'note'} for row in inputs)
assert len({row['id'] for row in inputs}) == len(inputs) == 30
assert all(before_fold[row['id']]['character'] == 'silent' for row in inputs)
completed = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                           input=(HERE / 'ledger-updates.jsonl').read_bytes(), capture_output=True)
(HERE / 'ledger-cli.stdout.txt').write_bytes(completed.stdout)
(HERE / 'ledger-cli.stderr.txt').write_bytes(completed.stderr)
assert completed.returncode == 0, completed.returncode
assert completed.stdout.decode().splitlines() == [row['id'] for row in inputs]
after = path.read_bytes()
assert after.startswith(before), '账本历史前缀变化'
ours = []
offset = len(before)
inputs_by_id = {row['id']: row for row in inputs}
private_fold = copy.deepcopy(before_fold)
for raw in after[len(before):].splitlines(keepends=True):
    row = json.loads(raw)
    expected = inputs_by_id.get(row.get('id'))
    if expected and row.get('note') == expected['note'] and row.get('by') == expected['by']:
        assert set(row) == set(expected) | {'op', 'ts'}
        assert row['op'] == 'update' and all(row[key] == value for key, value in expected.items())
        ledger.apply(private_fold, row)
        ours.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                     'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(ours) == 30 and len({row['id'] for row in ours}) == 30
protected = ['character', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'shipped_at', 'effect']
for row in inputs:
    ident = row['id']
    assert all(before_fold[ident].get(key) == private_fold[ident].get(key) for key in protected), ident
audit = {'cli_exit_code': completed.returncode, 'before_size': len(before),
         'before_prefix_sha256': hashlib.sha256(before).hexdigest(),
         'after_observed_size': len(after), 'historical_prefix_unchanged': True,
         'protected_fields_unchanged_in_private_fold': protected,
         'own_rows': ours, 'scope': '仅核本批CLI追加；其他角色或并行追加原样保留，不代其确认'}
(HERE / 'ledger-update-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit_code': completed.returncode, 'verified_own_rows': len(ours),
                  'historical_prefix_unchanged': True, 'protected_fields_unchanged': True}, ensure_ascii=False))

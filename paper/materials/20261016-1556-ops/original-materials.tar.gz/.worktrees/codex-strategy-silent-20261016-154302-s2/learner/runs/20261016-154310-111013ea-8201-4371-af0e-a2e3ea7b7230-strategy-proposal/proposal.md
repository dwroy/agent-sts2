# 本批十项策略提案处置

记录时间：2026-10-16 15:51:30 CST。批次20261016-154302-s2-strategy-proposal，silent、已观察A10。

基线fd5c6845272371d8f488ae4195c18d9a6dadca99；来源/目标任务与授权保留各原提案，不扩展领取。全部waiting，不新建ID，不把局部源码当整体完成。

仅重新核六个派发局；旧提案引用的其他本角色历史统计保留原文，本批不冒称重新覆盖。以下事实是发现/回归输入；相关SL不扩独立样本分母。

本批保留现有候选、选择/并列、HP护栏、药价、SL及终局价值。没有足够可归责新差额或受控后继来拟合新参数。无生产变更可回退；后续实现只在原提案下窄接，须固定数据撤源码红/恢复绿、自测和实际live后再记版本/通知。

## silent-proposal-c20b5139dd0dff71

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-c20b5139dd0dff71.md；原路径：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；保存SHA256=bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0168。

证据：DUZUBAJ3A8GP F27 T4—T6。火花3时技能污染0→3→6，能力不加；T5火花6、三技能0→6→12→18，实损9，次轮污染0。

已有实现/旧行为：fa9e33062aef3aa04e82c5413dd91d4f710a942f：已有技能累积污染及逐段入伤；rollout也读取火花变化。

反例及限制：技能同时有毒/挡收益，未执行替线不能证明少打技能更好。

处置：waiting。缺火花增长、污染撤除、虚弱/毒/挡组合的同次冻结生产重放校准；当前未确认可唯一归责的新差额。

拟验证行为及方法：在原帧及实际移动表固定后，逐步比较污染、毒、挡、当前HP；保留全部候选，不设技能血价常数。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-ae9e692d680e3819

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-ae9e692d680e3819.md；原路径：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；保存SHA256=b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0183, silent-0005。

证据：5PM6JAQG6FNQ F39 T2/T4—T6。玩家力/敏两次抢夺至−4/−4；两步法敏捷−4→−2→0，失落退场后力量−4→0，之后敏捷0→−2。

已有实现/旧行为：已有负属性计算；本次只核端点，不能由现帧负属性证明完整逐源返还模型。

反例及限制：末试单步法只至−2敏，毒杀失落后仍8HP/0挡对19攻死亡，不能定固定击杀序。

处置：waiting。缺稳定实体与逐来源抢夺累计、毒杀退场返还及随后重抢的完整对账；没有另一杀序的受控整战后继。

拟验证行为及方法：保留负力/负敏现场值；后续按来源身份固定抢夺/返还链，跨退场不复用索引身份，不从端点拟目标权重。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-52f1e1bd2e7db0ed

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-52f1e1bd2e7db0ed.md；原路径：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；保存SHA256=651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0231。

证据：CA5KE8GFJ9X2 F13 T1/T3/T5。同喷水力量0/4/8对应11/15/19；弱后11/14，末2HP/10挡对14攻归零。覆甲只记现场。

已有实现/旧行为：move-model.ts按当前进阶调用moveDamageAt；monster-db和room-costs保留五样本房间代价门槛。

反例及限制：零血截断实际净损2与14−10=4的攻击参考分列，不能把差2血替成固定房间成本。

处置：waiting。缺实际调用移动表与加压、覆甲、虚弱的联合生产重放校准，未证完整覆甲减层条件。

拟验证行为及方法：固定进阶、移动表和原动作前缀逐帧核11/15/19与弱后11/14；首样本事实和房间五样本成本分开。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-6dd8bbff876be528

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-6dd8bbff876be528.md；原路径：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；保存SHA256=48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0233, silent-0209。

证据：5PM6JAQG6FNQ F38 T3/T4。电击机器人23上限、力量2→4、攻击17→19，索引4→3；T3仍攻击，T4才退场。

已有实现/旧行为：7a1a8f1f4dd8dbf46a9de6b1127cb869fea24065：已有HIGH_VOLTAGE_POWER逐轮成长。

反例及限制：先清爪牙35伤/损3的候选未实打，不能宣称必省27血或救后场。

处置：waiting。缺稳定召唤代际身份与跨代重置的冻结校准；类型/上限相同和索引重排不足以证明实体连续性。

拟验证行为及方法：核已观察增长，缺身份处标未知；未来固定召唤、存活、退场、再召唤链，不给新实体继承旧计数。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-578e415a259e6835

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-578e415a259e6835.md；原路径：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；保存SHA256=e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。

证据：8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11；F17 T6。同指纹T2原/替实际损3/15、扣敌10/17；末轮5HP/22挡对37，实际归零且敌余130。候选差不等于实省血。

已有实现/旧行为：1698adc96ba434a46942321e0237b70657e625b2资源差值、fdaf787a372880b0438e73bcac7e6d2168b038ed单动作回执及e75438488df159b2e8e9d3458cf219b39aadd933轮端点审计已live。

反例及限制：0/24与5/24死亡率不同；末试多活至T11仍败，不能由回合数确定保血或成长优先级。

处置：waiting。缺抽弃/重问后的完整候选身份、逐源能力兑现与联合资源消费者；单动作回执和轮端点不能认证整候选。

拟验证行为及方法：保留原答/护栏/SL/派发分段及毒/能力/实损分账；未来固定完整续步与实际建立时点，再比较后移独立局。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-c0767768bf6a7ab1

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-c0767768bf6a7ab1.md；原路径：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；保存SHA256=28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0079。

证据：YF0LXT1QSTGG F48 第二/三试T1、第四试T5；F33第二试。同指纹T1实际损0/9、扣敌45/38；两候选24/24死，候选损0/10与伤54/36不冒充实际。

已有实现/旧行为：1698adc96ba434a46942321e0237b70657e625b2及既有选择/派发/轮端点审计已覆盖预测差与部分实际观测。

反例及限制：第四试T5换线未完整执行；F33第二次SL实胜，不能否定所有SL。

处置：waiting。缺未派发续步的完整执行归属和独立受控获胜后继；不能由全败并列拟探索惩罚或禁止换线。

拟验证行为及方法：逐候选保留封顶/死亡比例和当轮代价，重规划处中止完整执行认证；等待相同抽序的完整对照。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-a46bdb7fe711d79a

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-a46bdb7fe711d79a.md；原路径：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；保存SHA256=eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0021, silent-0027, silent-0028, silent-0085。

证据：YF0LXT1QSTGG F48 末试T3—T5。阶段111/4毒→212/0毒；触媒2但零毒；敏捷5→6时既有挡仍23；末轮本体净扣37。

已有实现/旧行为：aad2700abed6dff1d66e87fb36aaa6fedb39adf3：当前阶段、组件持有、已建能力、零毒与现场挡事实已有live实现。

反例及限制：前几试已建毒雾或余像仍败；不能把未启动毒当唯一死因或强制能力先手。

处置：waiting。缺逐候选跨阶段完整执行、施毒/毒结算及格挡前后敏捷顺序的联合生产校准；当前帧事实不能认证后继收益。

拟验证行为及方法：阶段后重新读现场；持有/建立/施毒/结算分列，未来按实际完整动作链核收益，不倒补敏捷或旧阶段毒。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-1044224808015e5c

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-1044224808015e5c.md；原路径：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；保存SHA256=4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0079。

证据：XP2SL33HT0D9 F33 首/二试T3、首/末试T1、第三试T4。同指纹T3实际损9/14、扣敌24/27；T1实际损2/10、扣敌25/34并加力量，不能抹掉成长。

已有实现/旧行为：1698adc96ba434a46942321e0237b70657e625b2已有资源比较，fdaf787a372880b0438e73bcac7e6d2168b038ed有单动作回执。

反例及限制：末试T2零损、T3只损4，朝向/减力/抽弃影响不同；不能一律拒绝付血探索。

处置：waiting。缺同抽序完整后继和成长兑现的受控比较；零胜并列与单轮血价不足以拟探索门槛。

拟验证行为及方法：保留当轮损失、输出、力量成长及B2样本分账；等待独立完整胜线，不加全局HP惩罚常数。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-7cbc6005db712ba9

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-7cbc6005db712ba9.md；原路径：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；保存SHA256=f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。

证据：XP2SL33HT0D9 F33 末试T2—T5。T2轮初14挡再加6成20；镣铐力量0→−9→0；T4背向57→转向38→虚弱28；4敏脆弱时挡牌6。

已有实现/旧行为：5603f519ae6d08464e78cc66cb7eba1cd2c11aab临减恢复及已有朝向/虚弱/被动挡路径；本批只核已观察端点。

反例及限制：能力已建仍无减员；末轮毒3+7已结算10，而前五次SL末轮未结算毒不预支。早期局本批未重新分析。

处置：waiting。缺全部修饰组合的冻结生产回放、完整执行和未选后继；现有窄覆盖不能代表全部条件校准。

拟验证行为及方法：朝向与虚弱分列、轮初挡与新增挡分列；固定57→38→28、14+6及临减恢复，未知组合维持原行为。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

## silent-proposal-c59f592f1427a67e

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-154302-s2/learner/runs/20261016-154310-111013ea-8201-4371-af0e-a2e3ea7b7230-strategy-proposal/silent-proposal-c59f592f1427a67e.md；原路径：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；保存SHA256=81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。

证据：YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5。两局的三组血价、阶段/临减/船夹板/能力时序与前述原帧相符；SL重置、回血、实际饮药和库存恢复须分账。

已有实现/旧行为：上述资源比较、阶段、选择派发和离线轮端点审计属于已上线窄实现。

反例及限制：六次同存档尝试不是六独立局；缺完整随机输入、未选后继及旧dirty源码/知识，不把当前源码当历史复原。

处置：waiting。本批六局不能替代原101局联合资源重建；完整候选、路线、休息、用药与SL恢复的逐源联合消费未闭合。

拟验证行为及方法：沿原提案保留宽父，待同次冻结生产输入与各资源消费者逐源校准；不扩本批证据范围或新建重复提案。

切分：本批仅发现/固定原帧核验，不称后移独立验证；新参数须另有完整受控同角色后继。预期只补可审计事实，不承诺胜率；本批无新代码、无红绿结果、无实现commit或shipped。

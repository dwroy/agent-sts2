import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract', REPO / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
assigned = {p['id']: p for p in json.loads((HERE / 'assigned-proposals.json').read_text())}
runs = set(run for item in assigned.values() for run in item['runs'])
streams = {}
audit = []
for directory in ('evidence',):
    for manifest in json.loads((HERE / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        path = HERE / directory / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
        counts = collections.Counter()
        rows = []
        with (Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')).open('rb') as source:
            for line in path.open():
                envelope = json.loads(line)
                source.seek(envelope['offset'])
                raw = source.read(envelope['bytes'])
                assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
                assert json.loads(raw) == envelope['row']
                assert envelope['offset'] + envelope['bytes'] <= manifest['source_size']
                assert extract.run_identity(envelope['row']) == envelope['run_id'] in runs
                counts[envelope['run_id']] += 1
                rows.append(envelope)
        assert dict(counts) == {k: v for k, v in manifest['counts'].items() if v}
        audit.append({**manifest, 'verified_rows': len(rows)})
        streams[stream] = rows

def ref(e):
    return {key: e[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}

def powers(holder):
    return {p['power_id']: p['amount'] for p in holder.get('powers', [])}

def compact(e):
    row = e['row']; s = row['state']; c = s.get('combat') or {}; p = c.get('player') or {}
    return {**ref(e), 'ts': row.get('observed_ts', row['ts']), 'screen': s['screen'],
            'floor': (s.get('run') or {}).get('floor'), 'turn': s.get('turn'),
            'hp': p.get('current_hp'), 'block': p.get('block'), 'powers': powers(p),
            'cards_played': p.get('cards_played_this_turn'),
            'hand': [x.get('card_id') for x in c.get('hand', [])],
            'enemies': [{'index': x['index'], 'id': x['enemy_id'], 'hp': x['current_hp'],
                         'max_hp': x['max_hp'], 'block': x['block'], 'alive': x['is_alive'],
                         'powers': powers(x), 'move': x.get('move_id'),
                         'attack': sum(i.get('total_damage') or 0 for i in x.get('intents', []))}
                        for x in c.get('enemies', [])]}

states = streams['states']
state_by_line = {e['line']: e for e in states}
decision_by_line = {e['line']: e for e in streams['decisions']}
target_floors = {'DUZUBAJ3A8GP': {27}, 'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {38, 39},
                 '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}
projected = [compact(e) for e in states if (e['row']['state'].get('run') or {}).get('floor') in target_floors[e['run_id']]]
(HERE / 'state-projections.json').write_text(json.dumps(projected, ensure_ascii=False, indent=2) + '\n')

def endpoint(decision_line):
    d = decision_by_line[decision_line]; row = d['row']
    frames = [e for e in states if e['run_id'] == d['run_id']]
    match = [e for e in frames if e['row']['fingerprint'] == row['fingerprint'] and
             e['row'].get('observed_ts', e['row']['ts']) == row.get('observed_ts', row['ts'])]
    assert len(match) == 1, (decision_line, len(match))
    before = match[0]; a = compact(before)
    later = [e for e in frames if e['line'] > before['line'] and
             (e['row']['state'].get('run') or {}).get('floor') == a['floor'] and
             e['row']['state'].get('turn') != a['turn']]
    assert later, decision_line
    after = later[0]; b = compact(after)
    assert b['turn'] == a['turn'] + 1 and b['screen'] == 'COMBAT', (decision_line, b)
    assert [(x['id'], x['max_hp']) for x in a['enemies']] == [(x['id'], x['max_hp']) for x in b['enemies']]
    return {'decision': ref(d), 'before': a, 'next_turn': b,
            'actual_hp_net_loss': a['hp'] - b['hp'],
            'enemy_body_hp_net_removed': sum(x['hp'] for x in a['enemies']) - sum(x['hp'] for x in b['enemies']),
            'scope': 'observed_turn_endpoints_not_whole_candidate_execution',
            'sl_attempt': row.get('sl_attempt'), 'label': row.get('label'),
            'rationale': row.get('rationale'), 'sl_explore': row.get('sl_explore'),
            'fingerprint': row['fingerprint']}

pairs = []
for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    left, right = endpoint(a), endpoint(b)
    assert left['fingerprint'] == right['fingerprint']
    pairs.append({'original': left, 'replacement': right,
                  'delta_hp_loss': right['actual_hp_net_loss'] - left['actual_hp_net_loss'],
                  'delta_enemy_body_hp_net_removed': right['enemy_body_hp_net_removed'] - left['enemy_body_hp_net_removed']})
(HERE / 'paired-turn-endpoints.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')

selected = [276433, 277512, 277513, 277518, 277519, 277524, 277526, 277528,
            278236, 278237, 278240, 278242, 278249, 278250, 278251, 278252, 278253, 278254]
(HERE / 'consumer-input.json').write_text(json.dumps({'frames': [state_by_line[n] for n in selected]}, ensure_ascii=False) + '\n')
for e in streams['runs']:
    assert e['row']['character'].lower() == 'silent' and e['row']['ascension'] == 10
counts = {run: {'states': sum(e['run_id'] == run for e in states),
                'decisions': sum(e['run_id'] == run for e in streams['decisions']),
                'candidate_questions': sum(e['run_id'] == run and 'plan' in (e['row'].get('questions') or {}) for e in streams['decisions']),
                'dirty': next(e['row']['code'] for e in streams['runs'] if e['run_id'] == run)} for run in sorted(runs)}
summary = {'streams': audit, 'verified_rows': sum(x['verified_rows'] for x in audit), 'runs': counts,
           'pair_results': [{'decisions': [x['original']['decision']['line'], x['replacement']['decision']['line']],
                             'hp_loss': [x['original']['actual_hp_net_loss'], x['replacement']['actual_hp_net_loss']],
                             'enemy_body_hp_net_removed': [x['original']['enemy_body_hp_net_removed'], x['replacement']['enemy_body_hp_net_removed']],
                             'delta_hp_loss': x['delta_hp_loss'],
                             'delta_enemy_body_hp_net_removed': x['delta_enemy_body_hp_net_removed']} for x in pairs]}
(HERE / 'evidence-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': summary['verified_rows'], 'runs': counts, 'pairs': summary['pair_results']}, ensure_ascii=False, indent=2))

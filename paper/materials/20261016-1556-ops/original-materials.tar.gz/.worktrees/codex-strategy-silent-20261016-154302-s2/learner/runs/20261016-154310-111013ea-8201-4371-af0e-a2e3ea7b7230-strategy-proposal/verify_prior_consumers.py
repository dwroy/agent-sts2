import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-134302-s2/learner/runs/20261016-134308-0346acf7-d806-47ca-830a-8987c047693a-strategy-proposal')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


sources = json.loads((HERE / 'source-audit.json').read_text())
assert all(row['equal_prior_base'] for row in sources['paths'])
prior_artifacts = json.loads((PRIOR / 'artifact-manifest.json').read_text())
manifests = {}
for directory in ('evidence', 'evidence-additional'):
    for row in json.loads((PRIOR / directory / 'evidence-manifest.json').read_text()):
        manifests[row['stream']] = row
current = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
same = []
for row in current:
    assert row['output_sha256'] == manifests[row['stream']]['output_sha256']
    assert row['counts'] == manifests[row['stream']]['counts']
    same.append(row['stream'])

streams = {name: [json.loads(line) for line in (HERE / 'evidence' / (name + '.evidence.jsonl')).open()]
           for name in ('states', 'decisions', 'runs')}
inputs = json.loads((PRIOR / 'consumers/input-manifest.json').read_text())
results = json.loads((PRIOR / 'consumers/results.json').read_text())
verified = []
for record in inputs:
    run = record['run']
    selected = {'run': next(e['row'] for e in streams['runs'] if e['run_id'] == run), 'decisions': [], 'states': []}
    excluded = []
    for stream in ('decisions', 'states'):
        for e in streams[stream]:
            if e['run_id'] != run:
                continue
            row = {**e['row'], '_line': e['line'], '_source_sha256': e['sha256']}
            if stream == 'decisions' and not row.get('decision_id'):
                excluded.append({'line': e['line'], 'sha256': e['sha256'], 'reason': '原元数据行没有decision_id；不补号'})
                continue
            selected[stream].append(row)
    selected['decisions'].sort(key=lambda row: row['observed_ts'])
    raw = json.dumps(selected, ensure_ascii=False, separators=(',', ':')).encode()
    prior_input = Path(record['path']).read_bytes()
    assert sha(prior_input) == record['gzip_sha256']
    assert raw == gzip.decompress(prior_input)
    assert sha(raw) == record['input_json_sha256']
    assert excluded == record['excluded']
    result = next(item for item in results if item['run'] == run)
    prior_output = Path(result['output']).read_bytes()
    assert sha(prior_output) == result['output_gzip_sha256']
    output_raw = gzip.decompress(prior_output)
    assert sha(output_raw) == result['output_json_sha256']
    output = json.loads(output_raw)
    assert output['run_id'] == run
    assert len(output['segments']) == result['segments']
    assert len(output['observed_actions']) == result['actions']
    assert all(segment['actual_full_candidate_result'] is None for segment in output['segments'])
    verified.append({**result, 'input_gzip_sha256': record['gzip_sha256'],
                     'input_reconstructed_from_current_raw_evidence': True, 'excluded': excluded,
                     'consumer_rerun_this_batch': False})

summary = {'scope': '复核同源码、同原行的既有离线消费者产物；未重跑消费者或生产测试',
           'prior_directory': str(PRIOR), 'identical_evidence_streams': same,
           'prior_result_manifest_sha256': sha((PRIOR / 'consumers/results.json').read_bytes()),
           'prior_artifact_manifest_sha256': sha((PRIOR / 'artifact-manifest.json').read_bytes()),
           'verified': verified,
           'totals': {'segments': sum(r['segments'] for r in verified), 'actions': sum(r['actions'] for r in verified),
                      'observed_turn_endpoints': sum(r['turns'].get('observed_turn_endpoints', 0) for r in verified),
                      'unknown_turns': sum(r['turns'].get('unknown', 0) for r in verified),
                      'fully_executed_candidates_certified': 0}}
(HERE / 'prior-consumer-readback.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'identical_streams': len(same), 'runs': len(verified), **summary['totals']}, ensure_ascii=False))

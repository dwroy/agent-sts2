import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-224302'
SCRATCH = ROOT / 'learner/runs/20261016-224310-7015efea-6469-47aa-8e8c-e3327c0db331-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261016-211308-ec457cbf-29ac-45c7-adb5-67d9f654ce3b-fix-batch'
EXPECTED_BASE = 'c1b9aa1fd377f18b41e479eb90cb7cd55f503786'


def git(*args, tree=TREE, binary=False):
    raw = subprocess.check_output(['git', '-C', str(tree), *args])
    return raw if binary else raw.decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


# Reuse historical conclusions only after checking the current queue and source bytes.
checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
base = git('rev-parse', 'HEAD')
assert base == EXPECTED_BASE, base
assert not git('status', '--porcelain=v1')
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live')
base_ancestors = set(git('rev-list', base).splitlines())
live_ancestors = set(git('rev-list', live).splitlines())
prior_raw = (PREVIOUS / 'audit.json').read_bytes()
prior = json.loads(prior_raw)
prior_result = json.loads((PREVIOUS / 'result.json').read_text())
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert queue == (PREVIOUS / 'queue-readonly-snapshot.md').read_bytes()
assert sha(queue) == prior['queue_sha256']
unchecked = [(n, line) for n, line in enumerate(queue.decode().splitlines(), 1) if line.startswith('- [ ]')]
assert unchecked == [(r['line'], r['item']) for r in prior['queue_dispositions']]
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)

r2 = git('rev-parse', 'a8b202e34')
r3 = git('rev-parse', '8f02483ab')
assert r2 in base_ancestors and r2 in live_ancestors
assert r3 in base_ancestors and r3 in live_ancestors
changed_source = git('diff', '--name-only', prior['base'], base, '--', 'agent/src', 'agent/tests').splitlines()
published_source = git('diff', '--name-only', f'{r2}^', r3, '--', 'agent/src', 'agent/tests').splitlines()
assert changed_source == published_source
published_files = []
for name in changed_source:
    raw = (TREE / name).read_bytes()
    assert raw == git('show', f'{r3}:{name}', binary=True), name
    assert raw == git('show', f'{base}:{name}', binary=True), name
    published_files.append({'path': name, 'sha256': sha(raw), 'same_as_published_r3': True})
(SCRATCH / 'published-0332-source.diff').write_bytes(git(
    'diff', '--binary', prior['base'], base, '--', 'agent/src', 'agent/tests', binary=True))

files = []
for row in prior['current_files']:
    path = Path(row['path'])
    assert not path.is_absolute() and '..' not in path.parts and '.env' not in path.name
    assert not str(path).startswith('knowledge/characters/') or str(path).startswith('knowledge/characters/silent/')
    raw = (TREE / path).read_bytes()
    same = sha(raw) == row['sha256']
    assert same or str(path) in changed_source + ['eval/versions.json'], str(path)
    files.append({'path': str(path), 'sha256': sha(raw), 'same_as_prior': same})

fixed = list(prior['existing_fixes']) + [
    {'item': 'silent-0332：B3完整失败诊断封套（根因未修）', 'commit': r2},
    {'item': 'silent-0332：B2 worker失败诊断封套传递（根因未修）', 'commit': r3},
]
for row in fixed:
    assert row['commit'] in base_ancestors and row['commit'] in live_ancestors, row
    row['ancestor_in_base'] = row['ancestor_in_live'] = True

focused = []
for row in prior['focused_source_review']:
    lines = (TREE / row['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if row['anchor'] in line]
    assert found, row
    focused.append({'path': row['path'], 'anchor': row['anchor'], 'lines': found})

originals = []
for row in prior['raw_original_references']:
    relative = Path(row['source'])
    assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'logs'
    with (ROOT / relative).open('rb') as source:
        source.seek(row['offset'])
        raw = source.read(row['bytes'])
    assert sha(raw) == row['sha256'], row
    json.loads(raw)
    originals.append({**row, 'sha256_verified': True, 'json_parsed': True})

material_names = [
    'paper/materials/20261016-2153-ops/host-closure.json',
    'paper/materials/20261016-2125-ops/consumer-receipt.json',
    'paper/materials/20261016-2125-ops/source-commit-received.json',
]
materials = []
for name in material_names:
    raw = (TREE / name).read_bytes()
    assert raw == git('show', f'{base}:{name}', binary=True)
    materials.append({'path': name, 'sha256': sha(raw), 'blob': git('rev-parse', f'{base}:{name}')})
host, consumer, received = [json.loads((TREE / name).read_text()) for name in material_names]
assert host['root_repair'] is False and host['real_complete_failure_and_first_divergence_missing'] is True
assert host['source'] == r3 and host['r2_source'] == r2
assert host['live'] in live_ancestors
assert git('rev-parse', f'{host["live"]}^{{tree}}') == host['tree']
assert host['host_rc'] == host['tsc_rc'] == host['vitest_rc'] == 0
assert host['source_r2_full_rc'] == host['source_r3_full_rc'] == 1
assert consumer['live_commit'] == host['live'] and consumer['live_tree'] == host['tree']
assert consumer['passed'] is True and consumer['root_repair'] == 'not established'
assert received['source'] == r3 and received['root_fix'] is False
for row in received['source_files']:
    assert sha((TREE / row['path']).read_bytes()) == row['sha256']
log_path = Path(host['registered_check']['log'])
log_path.relative_to(ROOT / 'ops/codex-ops/learner')
log_raw = log_path.read_bytes()
assert sha(log_raw) == host['original_log_sha256']

timeout = prior['new_timeout_review']
assert sha((TREE / 'agent/tests/rollout-ties.test.ts').read_bytes()) == timeout['test_sha256']
for row in timeout['original_logs']:
    path = Path(row['path'])
    assert str(path).startswith('ops/codex-ops/learner/')
    assert sha((ROOT / path).read_bytes()) == row['sha256']

result = {**prior_result, 'base': base, 'fixes': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
for row in result['skipped']:
    if row['item'].startswith('silent-0332'):
        row['reason'] = ('证据不足；a8b202e34及8f02483ab的B3/B2完整诊断封套已实际上线R373，'
                         '原精确247acab宿主0和固定经验消费者0仅验证诊断/限定经验；'
                         '真实完整失败输入与首处分歧仍缺，根因未修。沿原r3/01a14446链，不重复派发、不降正HP/300。')

dispositions = []
for old in prior['queue_dispositions']:
    row = {**old, 'verification': '本批核原文、相关当前文件SHA、既有源码差异及base/live祖先；不冒报生产测试。'}
    if row['line'] == 959:
        row['disposition'] = '证据不足：诊断封套已实际上线，根修复仍缺真实完整输入和首处分歧'
    dispositions.append(row)
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain=v1')
assert (ROOT / 'notes/fix-queue-v4.md').read_bytes() == queue
(SCRATCH / 'this-batch.diff').write_bytes(git('diff', '--binary', base, binary=True))
audit = {
    'checked_at': checked_at, 'base': base, 'main_merge': 'Already up to date.',
    'prior_audit': str(PREVIOUS / 'audit.json'), 'prior_audit_sha256': sha(prior_raw),
    'live_read_only_snapshot': live, 'queue_sha256': sha(queue), 'queue_lines': len(queue.splitlines()),
    'unchecked_entries': len(unchecked), 'queue_dispositions': dispositions,
    'current_files': files, 'existing_fixes': fixed, 'focused_source_review': focused,
    'published_0332_files': published_files, 'published_0332_source': r3,
    'raw_original_references': originals, 'materialized_inputs': materials,
    'historical_host_log': {'path': str(log_path), 'sha256': sha(log_raw), 'historical_rc': 0,
                            'files': host['files_passed'], 'cases': host['cases_passed'],
                            'ancestor_in_base': host['live'] in base_ancestors,
                            'ancestor_in_live': host['live'] in live_ancestors},
    'root_0332_repair': False, 'new_timeout_review': timeout,
    'analysis_corrections': [
        '首轮审计比较了r3整树与上一基线，包含r3旧分支未继承的四叶P1/P2发布，断言失败原件保留。改用r2父至r3的实际16叶补丁范围，逐叶核当前字节；非产品失败。',
        '第二轮假设历史live宿主提交也是main祖先，断言失败原件保留。源码r2/r3均为两树祖先，宿主live提交只核live祖先及精确tree，不外推本基线全树已测。',
    ],
    'scope': '只读核验；未新增源码、测试、提交、提案、账本状态或live写入；材料检查不算生产测试。',
}
save('audit.json', audit)
save('result.json', result)
lines = ['## 修 bug 回报', '',
         f'- 合并基线：main → {base}（开工干净，先合main，无冲突。）',
         f'- 修复（每条一行）：无新增纯bug修复；42条未勾选原文不变，{len(fixed)}项既有窄修复/诊断提交均为本基线及所核live祖先。'
         f'复核389个既有文件，其中{sum(r["same_as_prior"] for r in files)}个SHA不变；变化已核为原R373诊断及版本登记。'
         '无新增源码或测试，去掉修复的红绿验证不适用。']
for row in fixed:
    lines.append(f'- 已被别人修掉的：{row["item"]} — {row["commit"]}（限已核子项，不关闭更宽父项）')
for row in result['skipped']:
    lines.append(f'- 没修的：{row["item"]} — {row["reason"]}')
lines += ['- 测试：tsc未运行，退出码null；vitest未运行，0文件 / 0用例 / 退出码null；无重跑。'
          '本批未改源码、未提交或合入；历史宿主503文件4991过2跳只作旧证据，不记本批测试。',
          f'- 合入：未合入（无新增提交）；live只读快照{live}。',
          '- 需要 Roy 定的事（没有写「无」）：无。', '', '```json',
          json.dumps(result, ensure_ascii=False, indent=2), '```', '']
(SCRATCH / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'base': base, 'live_snapshot': live, 'queue_entries': len(unchecked),
                  'verified_existing_commits': len(fixed), 'unchanged_files': sum(r['same_as_prior'] for r in files),
                  'published_0332_files': len(published_files), 'raw_rows': len(originals),
                  'skipped': len(result['skipped']), 'fixes': [], 'report': result['report']}, ensure_ascii=False))

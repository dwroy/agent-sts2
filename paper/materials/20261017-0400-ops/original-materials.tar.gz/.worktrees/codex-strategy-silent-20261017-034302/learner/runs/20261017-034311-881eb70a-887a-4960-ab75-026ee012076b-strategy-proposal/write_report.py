import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
proposals = json.loads((OUT / 'original-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
verified = json.loads((OUT / 'evidence-verification.json').read_text())
checks = json.loads((OUT / 'observation-checks.json').read_text())
by_id = {p['id']: p for p in proposals}
specs = [
    ('ca596a0c614d90c6', 'waiting', 'SY0WMJNNVRLM A10 F30/F31 T1、F33 T1—9',
     'FIGHT_ME+先伤12再给玩家4/目标1力量的两组原帧已核；当前模型已有StrengthPower/EnemyStrength传播。缺取得→抽到→可支付→实际建立→兑现的完整消费者追踪及同资源启动/不启动后继，不能从boss未建力量拟固定启动奖励或强制T3。',
     'F33六试均未建该力量；原T3力量线还增加目标力量，未实打的替线不能认作可赢。'),
    ('2ea03873248ad65f', 'duplicate', 'SY0WMJNNVRLM A10 F33 T4→5；XTSV1U9JD34T A10 F49 T1；另三局分阶核验',
     '实际live祖先96f17377a331e50ea5b6a3fe8d2b605932ed1bd4已接入Silent A10、无既有无实体时的幽灵药当轮模型，保留不喝线和Jev选择，不预支后轮保护。20次实饮/次轮撤层原帧复核；只确认已实现的A10单层范围，不扩展A4/A9、叠层、持有价或固定时点。',
     'SY0六次T4无攻击时饮用而T5均无旧层；这不证明推迟喝药可整战获胜。'),
    ('4c28c13316c0d88e', 'waiting', 'SY0WMJNNVRLM A10 F30/F31 T1、F33 T1/T4/T5/T6/T9',
     '力敏、毒、重放、一次遗物挡与再生已有局部模型/原帧支持；缺这些来源联合时逐步传播、结算中间帧与完整消费者配对，不能以单个幽灵/毒模型祖先认证全部十一经验的联合模型，也未定位新可复现源码算错。',
     '再生与受击之间的中间帧不全，净HP不能充作毛治疗；能力持有不等于已施放或重复触发首次能力挡。'),
    ('51d8fe5060c677e8', 'waiting', 'SY0WMJNNVRLM A10 F21 T4→5、F33末试T3→9',
     '异螨第2/3试T4完整combat相同，胜线下一轮3HP/敌12HP已核；目标与多步动作共同改变。缺原候选全线执行绑定、后继抽牌的匹配控制和未选整战结果，不能制定固定目标优先或改SL判死/探索权重。',
     '末试沙虫延至T9仍败；有限模拟全败既不能证明最优，也不能证明不存在其他可活路径。'),
    ('4114571d6f0866e1', 'waiting', 'SY0WMJNNVRLM A10 F19—21、F30/F31/F32→F33',
     '资源与未启动能力必须分账的结论保留；缺原投影版本→实际路线/营火动作→战间血药→下一场消费者的完整绑定及替代路线/留药后继。现有预测/资源审计不能支持新增终局阈值、持药价格或强制铺能力。',
     '赢战仍耗血；SL恢复不是新药或治疗，未到营火不是已回血，未执行方案不是实际省血。'),
    ('edaea6fac5a803c1', 'waiting', 'SY0WMJNNVRLM A10 F21 T1—5；原勘误SHA已核',
     '本批已采用原勘误的22张共同记录前缀/后两试26张及胜试下一轮敌12血，保留四份错误初稿。勘误本身没有独立已证源码缺陷或参数；关联SL策略仍缺完整执行/受控后继，不能据文稿修正登记源码implemented。',
     '原“24张/敌15血”是已登记的旧错误，不再用于本次结论；序号重排不能证明跨帧同一实体。'),
    ('f226dea0cac1e550', 'waiting', '4XLZURXMD872 A10 F31首/重试T1—2、T6',
     '现有题面已有energy_unused、known_draws、抽后重问与有限样本范围，当前又有已live的普通计算下注窄修；它不等于本项完整SL比较。缺跨T1/T2多处偏离与完整后继动作的稳定身份核验，不能以0/24参考或本场重试胜利新增强制换手/判死规则。',
     '两试T2敌血111/103不同；换手三抽6伤、11挡及次轮2/13HP可核，只是局部即时差而非整战单因。'),
    ('04f65d65595dabd6', 'waiting', '4XLZURXMD872 A10 F28—33、F31 T1/T2、F33 T1/T3',
     'F28后57血到F32仅2血、休后23血入boss及能力在boss未建立的原记录保留；缺投影高22的逐版本/动作消费者绑定、跨战清零/药栏恢复的联合消费者验收与替代路线/留药完整结果，不能由单局重拟血线或药价。',
     '上一场已有速行者/谋划专家而boss六试首手均未见这些能力；首轮7能量不保证组件已抽到并启动。'),
    ('387ea7c2d92d3856', 'waiting', '4XLZURXMD872 A10 F17 T3/T6/T7、F30 T5、F31 T2/T5、F33 T3；T0DGVABPV60U A10 F28 T7',
     '两来源局的毒药实饮、负属性、减力恢复、重放、抽牌伤与持牌伤有局部原帧；已有毒模型仅限定观察组合。仍缺全部九经验联合修正、随机/制品/附加来源的完整回放与消费者对应，不能把药水当步+6外推为通用药价、时点或完整联合校准。',
     '同瓶六次SL不是六个独立校准局；当步施毒未扣本体，不等于截断前的未来毒伤已经结算。'),
    ('2b97abc88c159cb9', 'waiting', '4XLZURXMD872 A10 F31 T1/T2→T6、F33六试T3',
     '蟾蜍T2保留1能、换手后103→97、究极防御11挡和13HP进入下一轮均已核；原首轮多打匕首雨且后继时点同变。缺相同完整起点下只改换手的整战线与原候选连续执行核验，不改SL必死门槛、HP护栏或固定换手策略。',
     '沙虫六试0胜且末试实际死亡并不证明有限搜索覆盖所有打法；存活差9血不等于整战只差9。'),
]
results = []
sections = []
for suffix, state, evidence, reason, counter in specs:
    ident = 'silent-proposal-' + suffix
    original = by_id[ident]
    result = {'id': ident, 'state': state, 'reason': reason}
    if state == 'duplicate':
        result['commit'] = '96f17377a331e50ea5b6a3fe8d2b605932ed1bd4'
    results.append(result)
    sections.append(f"## {ident}\n\n处置：{state}。证据：{evidence}。账本：{', '.join(original['ledger'])}。\n\n{reason}\n\n反例与限制：{counter}\n\n预期行为：保留当前已核源码与Jev选择；不引入证据以外的固定权重、删选项或确定性判死。验证范围为原稿SHA、原行字节/身份及现有源码/live祖先；需要后继数据的具体内容以上述缺口为准。若以后实现，须固定局面撤源码红/恢复绿并完成沙箱自测与live流程；本批无源码可回退，全部原始资料保留。\n")
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-034302-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [r['id'] for r in results if r['state'] == 'waiting'],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [], 'proposal_results': results,
          'report': str(OUT / 'report.md')}
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
header = f"""# 静默猎手十项原提案核验

批次20261017-034302-strategy-proposal；base `{source['base']}`。本批为普通消费队列，research_request/implementation_request均未绑定；根deck-size请求属于另一批，未代入。开工工作树干净，按任务合main返回Already up to date，HEAD未变。只处理派来的十个原ID，不新增重复提案或游戏知识，不读取其他角色私有知识，不派agent。

结论：1项duplicate，9项waiting；无新源码或知识变更、提交、合入、版本。下文waiting保留具体未完成范围，局部已有实现或原帧支持不关闭宽项；不把缺完整整战因果当作局部算术未观察。

七局由runs.jsonl及全部选中状态核为Silent：9YBKCNBFP0X5 A4、G403VCZ3BH1B A9，其余五局A10。局数、尝试与进阶不混算；旧runs兼容deepseek_calls字段不认证实际大脑来源，本批不报告胜率/策略收益。

共用extract_evidence入口冻结八流，选中11486行，逐行从只读logs按offset/bytes重读、核SHA/JSON/显式局身份；source_size与分流计数见evidence/及evidence-extra/manifest，复核见evidence-verification.json。fight-plans本截点选中0行，仅说明该截点没有所选记录。全源states/decisions/brain各有2条无法解析行，提取器原计数保留，不能将这些未知身份行归属本批或补写内容。

十份原Markdown存在且逐SHA相符，路径/原文指纹/账本在original-proposals.json；只使用已有提案ID。28个关联账本的原claim/首证/prior/evidence/status/version/shipped保护摘要在ledger-before.json。原勘误edaea保留旧初稿并明确采用22/26抽序记录、下一轮敌12血；不再使用24/15。

## 局部证据与当前源码

- 20次幽灵实饮都核到实际use_potion/completed和1层，到下一玩家轮均0；SY0六次F33T4为无攻击SALIVATE，不能预支T5。分母为五个本角色局，非20个独立局。已有祖先源码96f17377只在Silent A10/无既有层启用，保留不喝与Jev选择，其他进阶/叠层不扩展。
- SY0 F30T1 states301520→301521与F31T1 301547→301548都先扣目标12、玩家力+4/目标+1；F31后续突然一拳12、中和7，当前generic动态字段已接线。未观察普通版、重放或强制启动整战收益。
- SY0 F21 states301449与301472完整combat逐值相同，胜线301477为3血/敌12血；这是多动作/目标共同变的路径，不拟固定目标规则。22/26抽序数量来自原已登记勘误，本次未重新全历史恢复抽序；端点与同盘部分已自行原字节核。
- 4XL F31 states302309/302332均余1能，302333换手后敌103→97，302334零能11挡，302310/302335下一轮HP为2/13；首轮敌血111/103不同。新live普通Gamble补丁66b057是另外的least-loss入口窄修，不冒本项全部实现。
- 选中十个毒药实饮相邻帧中4XL七次、T0一次、XTS两次；本次只核这些局部施毒/当步血量，不重复认领原34/132历史统计。全部原帧及已完成饮药关联见observations.json、observation-checks.json。
- 13个源码/既有固定测试叶中12个与live逐字相同，card-model仅两处旧Roy/Dai注释差；六个相关既有源码提交都是实际live祖先。source-audit.json记录完整SHA与提交，source-card-model.diff.txt保留精确差异。实际核验live为`{source['live']}`，不冒原局dirty运行源码完整已冻结。

材料检查初版错误要求既有幽灵测试夹具等于完整原state，因夹具省略19个顶层字段而失败。原脚本/失败stderr保留；r2明确核全部保留字段（含完整run/combat）逐值相同，记录19个省略项，未修改生产源、旧夹具或任何生产测试断言。这是材料检查的范围修正，不是游戏故障或产品回归。

"""
(OUT / 'proposal.md').write_text(header + '\n'.join(sections))
report = f"""# 本批策略回报

十个派发ID均已逐项处置：幽灵药一项已有实际live源码实现，另九项按具体缺口waiting。没有足以支持新增策略补丁的可复现源码缺口或受控参数证据；保留当前行为，不制造实现、合入、版本或成功测试。

- base/HEAD：`{source['base']}`；开工与最终工作树均干净；main合并返回Already up to date。
- 派发角色silent，来源七局：{', '.join(dispatch['runs'])}。A4一局、A9一局、A10五局分列。
- 六默认日志流加runs/fight-plans共11486行均已核原offset/bytes/SHA/JSON/显式身份，十原稿SHA全部匹配，28个关联账本仅补追溯；不是生产测试或新独立支持样本。
- 无源码/知识修改，fixes=[]、merged=null、release_id=null；没有提交，不需提交前gitleaks。tsc/vitest/cases均null；未执行撤源码失败/恢复通过验证，也不借历史测试作本批绿色结果。
- 现有幽灵源码commit=`96f17377a331e50ea5b6a3fe8d2b605932ed1bd4`已核为实际live祖先；实际核验live=`{source['live']}`。仅duplicate，不声称本批implemented/shipped；不新增eval版本或实际上线双通知。

## 原帧结论及限制

SY0 F30/F31升级力量牌两次给玩家4、目标1并先伤12；boss未施放不证明应强制启动。20次幽灵实饮都建1层/下一轮撤，本批不拟延后用药的胜率。4XL F31换手后余1能、三抽额外6伤、实得11挡；下一轮13HP对首试2HP是局部差，T2敌111/103和其他动作不同，不能归整战单因。SY0异螨同T4完整盘面与胜试敌12血已原帧核；原22/26抽序勘误明确引用而未冒重新全量重建。更多逐项证据局/层/回合/账本、反例、预期及验证均在proposal.md。

原始dirty运行树、缺失结算中间帧、未选候选完整连续执行、同资源受控后继以及多机制联合模型覆盖仍未知；局部算术、已有源码和经验文字发布不能替代这些验收。本批不新增强制启动、换手/目标优先、药价、HP护栏或SL必死参数，不关闭学习父请求。

既有幽灵夹具省略19顶层字段导致材料检查r1全state比较失败，原失败/脚本保留；r2只按夹具实际保留字段逐值核并列出省略项，原run/combat全部相同。其余20实饮/两次加力/蟾蜍与异螨原帧检查通过；这些只是材料一致性验证，生产tests仍null。

## 逐项结果

"""
for r in results:
    report += f"- {r['id']}：{r['state']}。{r['reason']}\n"
report += f"\n账本CLI实回exit0、28项where/note补链；旧物理前缀SHA与折叠claim/首证/prior/evidence/status/version/shipped及where/notes/history前缀均核保。未新增证据或回退已有shipped到proposed，未写shipped。原输入/stdout/stderr及保护回执在ledger-update.*、ledger-protection-check.json。\n\n运维交付：`{OUT / 'proposal.md'}`；逐项机器结果proposal-results.json，最终JSON为result.json。原报告/复盘不重复写，原提案原文及全部失败保留；无新源码合入阻塞。本批未改其他角色行为、运行模型/权限、运维prompt或live，不运行play/LLM/网络。\n"
(OUT / 'report.md').write_text(report)
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal': str(OUT / 'proposal.md'), 'results': len(results), 'duplicate': 1, 'waiting': 9}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BATCH = '20261017-034302-strategy-proposal'
RUNS = 'SY0WMJNNVRLM,9YBKCNBFP0X5,G403VCZ3BH1B,YLYLZWHA0GKU,XTSV1U9JD34T,4XLZURXMD872,T0DGVABPV60U'.split(',')
IDS = ['silent-proposal-' + s for s in ['ca596a0c614d90c6', '2ea03873248ad65f', '4c28c13316c0d88e', '51d8fe5060c677e8', '4114571d6f0866e1', 'edaea6fac5a803c1', 'f226dea0cac1e550', '04f65d65595dabd6', '387ea7c2d92d3856', '2b97abc88c159cb9']]


def sha(value):
    return hashlib.sha256(value).hexdigest()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def git(*args, cwd=WORK):
    return subprocess.check_output(['git', '-C', str(cwd), *args]).decode().strip()


def find_batch(data):
    if isinstance(data, dict):
        if BATCH in data:
            return data[BATCH]
        if data.get('batch') == BATCH or data.get('id') == BATCH:
            return data
        for value in data.values():
            found = find_batch(value)
            if found is not None:
                return found
    elif isinstance(data, list):
        for value in data:
            found = find_batch(value)
            if found is not None:
                return found
    return None


batch = find_batch(json.loads((ROOT / 'ops/codex-ops/learn.json').read_text()))
assert batch['task'] == 'strategy-proposal' and batch['character'] == 'silent'
assert batch['worktree'] == str(WORK) and batch['proposal_ids'] == IDS
assert set(batch['runs']) == set(RUNS)
assert not batch.get('research_request') and not batch.get('implementation_request')
save('dispatch.json', batch)
proposals = []
for line in (ROOT / 'paper/materials/learning/code-proposals.jsonl').open():
    row = json.loads(line)
    if row.get('id') in IDS and row['op'] == 'add':
        path = Path(row['proposal'])
        actual = sha(path.read_bytes())
        assert row['character'] == 'silent' and actual == row['proposal_sha256']
        proposals.append({**row, 'actual_sha256': actual, 'actual_bytes': path.stat().st_size})
assert len(proposals) == len(IDS)
save('original-proposals.json', proposals)

spec = importlib.util.spec_from_file_location('ledger_audit', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
ledger_ids = sorted({i for p in proposals for i in p['ledger']})
rows = [(n, row) for n, row in module.read_rows() if row and row.get('id') in ledger_ids]
folded = module.fold(rows)
protected = {}
for ident in ledger_ids:
    item = folded[ident]
    assert item['character'] == 'silent'
    protected[ident] = {key: item.get(key) for key in ['character', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'status', 'version', 'shipped_at', 'effect']}
    for key in ['evidence', 'history', 'notes', 'where']:
        protected[ident][key + '_sha256'] = sha(json.dumps(item.get(key), ensure_ascii=False, sort_keys=True).encode())
    protected[ident]['evidence_count'] = len(item['evidence'])
save('ledger-before.json', protected)

source_paths = ['agent/src/reflex/' + name + '.ts' for name in ['card-model', 'combat-plan', 'turn-solver', 'rollout', 'silent-simulation-reference', 'silent-sl-comparison', 'silent-sl-resource-comparison', 'silent-selection-audit', 'silent-hp-guard-audit', 'silent-demon-potion', 'silent-potion-reference']]
source_paths += ['agent/tests/silent-ghost-potion.test.ts', 'agent/tests/silent-ghost-potion-evidence.json']
live = ROOT / '.worktrees/live'
sources = []
for name in source_paths:
    original = (WORK / name).read_bytes()
    running = (live / name).read_bytes()
    sources.append({'path': name, 'base_sha256': sha(original), 'live_sha256': sha(running), 'same': original == running})
commits = ['96f17377a331e50ea5b6a3fe8d2b605932ed1bd4', 'f6c5504a73b2ee3702812a5217dfcda8b14e18aa', '45161a51c2c6b7e4a499b13cf749c4108193bbf5', '1698adc96ba434a46942321e0237b70657e625b2', '66283dd9982bdd7f480da7a4d9bfefea0572a9ac', '66b05734c8ee8e632345fb5c1c3a672296ab7ad5']
ancestors = []
for commit in commits:
    ancestors.append({'commit': commit, 'live_ancestor': subprocess.run(['git', '-C', str(live), 'merge-base', '--is-ancestor', commit, 'HEAD']).returncode == 0, 'subject': git('show', '-s', '--format=%s', commit)})
save('source-audit.json', {'base': git('rev-parse', 'HEAD'), 'live': git('rev-parse', 'HEAD', cwd=live), 'files': sources, 'commits': ancestors})

extract_spec = importlib.util.spec_from_file_location('extract_audit', WORK / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(extract_spec)
extract_spec.loader.exec_module(extractor)
states = defaultdict(list)
decisions = defaultdict(list)
verification = []
for folder in ['evidence', 'evidence-extra']:
    manifests = json.loads((OUT / folder / 'evidence-manifest.json').read_text())
    for entry in manifests:
        stream = entry['stream']
        path = OUT / folder / (stream + '.evidence.jsonl')
        assert sha(path.read_bytes()) == entry['output_sha256']
        counts = Counter()
        source = ROOT / 'logs' / (stream + '.jsonl')
        with source.open('rb') as raw:
            for line in path.open():
                envelope = json.loads(line)
                row = envelope['row']
                ident = extractor.run_identity(row)
                assert ident == envelope['run_id'] and ident in RUNS
                raw.seek(envelope['offset'])
                data = raw.read(envelope['bytes'])
                assert sha(data) == envelope['sha256'] and json.loads(data) == row
                assert envelope['offset'] + envelope['bytes'] <= entry['source_size']
                counts[ident] += 1
                if stream == 'states':
                    assert row['state']['run']['character_id'] == 'SILENT'
                    states[ident].append(envelope)
                elif stream == 'decisions':
                    decisions[ident].append(envelope)
        assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
        verification.append({**entry, 'verified_rows': sum(counts.values())})
save('evidence-verification.json', verification)


def compact(envelope):
    state = envelope['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {**{k: envelope[k] for k in ['line', 'offset', 'bytes', 'sha256', 'run_id']},
            'floor': state['run']['floor'], 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', state['run']['current_hp']), 'energy': player.get('energy'), 'block': player.get('block'),
            'powers': player.get('powers'), 'potions': state['run'].get('potions'),
            'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost']} for c in combat.get('hand', [])],
            'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'block', 'move_id', 'powers', 'intents']} for e in combat.get('enemies', [])]}


observations = {'ghost': [], 'poison': [], 'strength': [], 'myte': [], 'referenced_states': [], 'referenced_decisions': []}
state_lines = set(range(301520, 301523)) | set(range(301547, 301555)) | set(range(302307, 302312)) | set(range(302330, 302337)) | set(range(302445, 302455))
decision_lines = {294939, 294940, 294941, 294962, 294963, 294964, 294965, 294966, 294858, 294983}
for run_id in RUNS:
    items = states[run_id]
    for envelope in items:
        if envelope['line'] in state_lines:
            observations['referenced_states'].append(compact(envelope))
        state = envelope['row']['state']
        if run_id == 'SY0WMJNNVRLM' and state['run']['floor'] == 21 and state.get('turn') in (4, 5):
            observations['myte'].append(compact(envelope))
    for envelope in decisions[run_id]:
        if envelope['line'] in decision_lines:
            observations['referenced_decisions'].append(envelope)
    for before, after in zip(items, items[1:]):
        a, b = before['row']['state'], after['row']['state']
        if not a.get('combat') or not b.get('combat') or (a['run']['floor'], a.get('turn')) != (b['run']['floor'], b.get('turn')):
            continue
        pa = {p['power_id']: p['amount'] for p in a['combat']['player'].get('powers', [])}
        pb = {p['power_id']: p['amount'] for p in b['combat']['player'].get('powers', [])}
        pots_a = a['run'].get('potions', [])
        pots_b = b['run'].get('potions', [])
        used = [p for p in pots_a if p.get('potion_id') and not any(q.get('index') == p.get('index') and q.get('potion_id') == p['potion_id'] for q in pots_b)]
        for potion in used:
            target = 'ghost' if potion['potion_id'] == 'GHOST_IN_A_JAR' else 'poison' if potion['potion_id'] == 'POISON_POTION' else None
            if target:
                observations[target].append({'before': compact(before), 'after': compact(after), 'potion': potion})
        if any(c['card_id'] == 'FIGHT_ME' for c in a['combat'].get('hand', [])) and pb.get('STRENGTH_POWER', 0) - pa.get('STRENGTH_POWER', 0) == 4:
            observations['strength'].append({'before': compact(before), 'after': compact(after)})
save('observations.json', observations)
save('run-identities.json', [{'run_id': run, 'ascensions': sorted({e['row']['state']['run']['ascension'] for e in states[run]}), 'state_count': len(states[run]), 'decision_count': len(decisions[run])} for run in RUNS])
print(json.dumps({'verified_rows': sum(e['verified_rows'] for e in verification), 'proposals': len(proposals), 'ledger_ids': len(ledger_ids), 'observations': {k: len(v) for k, v in observations.items()}, 'base': git('rev-parse', 'HEAD')}, ensure_ascii=False))

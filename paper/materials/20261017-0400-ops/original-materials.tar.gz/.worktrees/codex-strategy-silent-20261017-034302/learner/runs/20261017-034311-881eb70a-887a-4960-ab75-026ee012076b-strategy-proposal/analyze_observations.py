import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
observations = json.loads((OUT / 'observations.json').read_text())
states = {}
by_run = defaultdict(list)
decisions = defaultdict(list)
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    envelope = json.loads(line)
    states[envelope['line']] = envelope
    by_run[envelope['run_id']].append(envelope)
for line in (OUT / 'evidence/decisions.evidence.jsonl').open():
    envelope = json.loads(line)
    decisions[(envelope['run_id'], envelope['row']['fingerprint'])].append(envelope)


def powers(row):
    return {p['power_id']: p['amount'] for p in row.get('powers', [])}


def state(line):
    return states[line]['row']['state']


results = {'ghost': [], 'poison': [], 'strength': []}
for kind in ('ghost', 'poison'):
    for pair in observations[kind]:
        a, b = pair['before'], pair['after']
        source = states[a['line']]
        fp = source['row']['fingerprint']
        matches = [e for e in decisions[(a['run_id'], fp)] if e['row'].get('chosen', {}).get('action') == 'use_potion'
                   and e['row'].get('expect', {}).get('potion', {}).get('id') == pair['potion']['potion_id']]
        assert matches
        ts = datetime.fromisoformat(source['row']['observed_ts'].replace('Z', '+00:00'))
        match = min(matches, key=lambda e: abs((datetime.fromisoformat(e['row']['observed_ts'].replace('Z', '+00:00')) - ts).total_seconds()))
        assert match['row']['result'].startswith('completed:')
        item = {'run_id': a['run_id'], 'floor': a['floor'], 'turn': a['turn'], 'before_line': a['line'], 'after_line': b['line'],
                'decision_line': match['line'], 'decision_sha256': match['sha256'], 'hp_change': b['hp'] - a['hp']}
        if kind == 'ghost':
            assert powers(b)['INTANGIBLE_POWER'] == 1
            later = next(e for e in by_run[a['run_id']] if e['line'] > b['line'] and e['row']['state']['run']['floor'] == a['floor']
                         and (e['row']['state'].get('turn') or 0) > a['turn'])
            later_player = later['row']['state']['combat']['player']
            assert powers(later_player).get('INTANGIBLE_POWER', 0) == 0
            item.update({'layer_after': 1, 'next_turn_line': later['line'], 'next_turn_sha256': later['sha256'],
                         'next_turn_layer': 0, 'before_intents': [e['intents'] for e in a['enemies']], 'after_intents': [e['intents'] for e in b['enemies']]})
        else:
            changes = []
            for before in a['enemies']:
                after = next(e for e in b['enemies'] if e['index'] == before['index'] and e['enemy_id'] == before['enemy_id'])
                delta = powers(after).get('POISON_POWER', 0) - powers(before).get('POISON_POWER', 0)
                if delta:
                    changes.append({'index': before['index'], 'poison_added': delta, 'hp_change': after['current_hp'] - before['current_hp']})
            item['changes'] = changes
        results[kind].append(item)

for pair in observations['strength']:
    a, b = pair['before'], pair['after']
    card = next(c for c in state(a['line'])['combat']['hand'] if c['card_id'] == 'FIGHT_ME')
    assert card['upgraded']
    assert powers(b)['STRENGTH_POWER'] - powers(a).get('STRENGTH_POWER', 0) == 4
    changed = []
    for before in a['enemies']:
        after = next(e for e in b['enemies'] if e['index'] == before['index'])
        if powers(after).get('STRENGTH_POWER', 0) != powers(before).get('STRENGTH_POWER', 0):
            changed.append({'index': before['index'], 'hp_loss': before['current_hp'] - after['current_hp'],
                            'enemy_strength_added': powers(after).get('STRENGTH_POWER', 0) - powers(before).get('STRENGTH_POWER', 0)})
    assert changed == [{'index': changed[0]['index'], 'hp_loss': 12, 'enemy_strength_added': 1}]
    results['strength'].append({'run_id': a['run_id'], 'floor': a['floor'], 'turn': a['turn'], 'before_line': a['line'],
                                'after_line': b['line'], 'player_strength_added': 4, 'enemy_changes': changed})

assert state(301449)['combat'] == state(301472)['combat']
assert state(301477)['combat']['enemies'][0]['current_hp'] == 12
assert state(302309)['combat']['player']['energy'] == 1
assert state(302333)['combat']['player']['energy'] == 1
assert state(302333)['combat']['enemies'][0]['current_hp'] == 97
assert state(302334)['combat']['player']['block'] == 11
assert state(302310)['combat']['player']['current_hp'] == 2
assert state(302335)['combat']['player']['current_hp'] == 13
results['bounded_checks'] = {'myte_equal_t4_combat_lines': [301449, 301472], 'myte_next_enemy_hp': 12,
                             'toad_energy_after_redraw': 1, 'toad_redraw_trigger_damage': 6, 'toad_new_block': 11,
                             'toad_next_turn_hp': [2, 13], 'toad_starting_enemy_hp': [111, 103],
                             'scope': '原帧一致性与实饮核验，不是生产测试或整战单因收益验证'}
fixture = json.loads((OUT.parents[2] / 'agent/tests/silent-ghost-potion-evidence.json').read_text())
before = next(e for e in states.values() if e['offset'] == fixture['provenance']['before']['offset'])
assert before['sha256'] == fixture['provenance']['before']['sha256']
assert {key: before['row']['state'][key] for key in fixture['state']} == fixture['state']
omitted = sorted(set(before['row']['state']) - set(fixture['state']))
assert len(omitted) == 19
results['existing_ghost_fixture'] = {'matches_all_retained_fields': True, 'omitted_top_level_fields': omitted,
                                    'scope': '既有夹具省略19个顶层字段，保留字段含完整combat/run逐值相同；不称完整原state字节相同'}
(OUT / 'observation-checks.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ghost': len(results['ghost']), 'poison': len(results['poison']), 'strength': len(results['strength']),
                  'ghost_by_run': dict(Counter(e['run_id'] for e in results['ghost'])), 'bounded_checks': results['bounded_checks']}, ensure_ascii=False))

# 本批策略提案回报

本批十项原提案全部 waiting。已核原文、原账本、Silent 当前关联经验、六局原始字节和实际 live 的窄实现；没有足够新数据改变排序、药水持有价值、SL准入或终局参数。逐项证据、反例、旧/拟议行为、验证、时间切分和回退见 [proposal.md](proposal.md)。

- 批次：20261016-160244-strategy-proposal；角色 silent；六局均A10。
- 完整 base：90e3b267f8a9d724aeee9167d4e41c82089546a7。初始 git status 干净；普通批次合并 main 无冲突且 Already up to date。
- 实核 live 快照：a9e687d9f0acccccddbfa92895d7966b58900658。本批没有源码 commit、合入 commit、eval版本或shipped。
- 派发身份是十原 proposal_ids；没有专题/implementation绑定，不领取队列外任务。

## 证据与消费者读回

共用入口提取 states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、runs6，共8444行。逐行原日志offset/bytes/SHA、JSON、显式身份、角色/进阶、计数和各流source_size全部复核；30项事实检查通过。run-plans有21条，不以正文提及认局。原全局无效states2/decisions2/brain1行未归属本批，保持未知。

十原Markdown指纹全部匹配；12条关联经验仍在本角色库中。七流选中封套与原140405批字节一致。旧六局消费者输入逐行重新绑定本批原证据，输入/输出SHA和六个消费者相关源码逐字节核；因此复用旧结果，本批未重跑消费者或模拟。旧原失败、六条非战斗缺decision_id排除及362未知窗口仍保留。历史读回共有861题段/4065动作/415可核整轮，完整候选结果仍未认证。工具未知不证明实盘没执行，旧成功码不算本批生产测试或策略有效。

## 实盘可支持的结论及限制

- 751 F17T2/T7同指纹改线分别多9敌净损付5血、多6敌净损付10血；T13省6血同时少6敌净损。五次判死与末次实死分开，不将六试当独立局或拟固定门槛。
- KV F33T5第4/5试同指纹，30血均不变、敌334→298/305；另有阻止补打毒的续问和诅咒选择。直接端点已核，但严格整轮仍未知，净扣不认证毛伤或完整候选因果。
- YQL F17T10毒药水使毒2→8，血26/挡13/自爆41不变，后帧实死；−2为未截断预计剩血。PU F17第5试T15余2血胜的反例保留，不将占位阶段当必死。
- KEN F17T10多6自身失血仅增2敌净损；T5少失2血但能力延迟且追加续问。T8/T9开头无敏捷、T10开头已2，能力收益不能倒填现有挡。
- KEN七次饮药槽位变化均可核，三次接口pending原样保留；槽位消失不证明随机选牌或重问后完整收益，更不证明留药Boss分支会赢。

## 现有实现与未完成范围

source-audit.json核16个相关文件，13个与live字节相同，3个差异只有历史Roy/Dai注释署名，完整base-live.patch保留。七个相关源码commit实核为base/live祖先：持牌失血05cd292c6f01bb31e406473d3a9843e659d62b93、持药未知c4670f4f416c7d93e192e889c5080e7e4e0e733f、候选/动作回执a8b1f8be153fe4f3a34146117546c2178f2e446b、SL资源对照1698adc96ba434a46942321e0237b70657e625b2、巨兽阶段a83d9ab675560a177249aa638e99df40bcfb5553、毒水d5e20aa4dd44168ce30944dfcce74f8322144953、窄末态0d092f6b928a6221eabf3516abad25c48ceaac9c。

这些只证明各自窄覆盖。actual_turn/whole_plan_executed/完整来源仍未认证；anchorRank仍以原始占位HP作同轮排序。直接占位归零会改变参考路径，缺完整受控后继，不当纯显示修正或据此关闭宽提案。

## 逐项处置

- `silent-proposal-366288801d9150d9` — waiting；账本：silent-0079, silent-0176。751 F17同指纹血价已核；缺抽弃重问后的完整候选身份、逐来源结算及受控整战后继，不能拟SL血价门槛。
- `silent-proposal-85929bdfc8a3fc1b` — waiting；账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。已有保守持牌损血和持药未知/无药预测参照；缺751 F13无药整战、留药后战和完整执行收益对照。
- `silent-proposal-efd9f83ee9e1a6dc` — waiting；账本：silent-0079, silent-0176。与原复盘共用751六试无胜线证据；缺同条件完整后继及独立局验证，不能用局部成本禁止探索。
- `silent-proposal-131042659448ae74` — waiting；账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。751分项机制已有窄实现；缺联合逐来源实结算、完整候选执行和跨战留药对照。
- `silent-proposal-990f054036609447` — waiting；账本：silent-0102, silent-0019, silent-0020。KV F33T5零净损、敌净扣36/29端点已核，严格整轮仍未知；缺毛伤回血归属及路线休息替代后继。
- `silent-proposal-e18d3f18e6cac2a0` — waiting；账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。巨兽阶段和毒水局部事实已实现；参考排序仍用原始占位HP，缺新旧改序完整后继和受控药水分支。
- `silent-proposal-9733bb80f445aeae` — waiting；账本：silent-0017, silent-0019, silent-0020, silent-0250。YQL末轮毒2→8而血挡/41来袭不变，PU余2血胜反例保留；缺提前喝、不喝、留药及改序对照。
- `silent-proposal-c51468c5e8ba6668` — waiting；账本：silent-0019。KEN七次用药都有槽位消失后帧，三次接口pending保留；缺随机选牌、重问后完整收益及留药Boss对照。
- `silent-proposal-86a7db08d1a31976` — waiting；账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。KEN T10多2敌净损付6血，T5省2血同时延迟能力；缺逐来源完整兑现、相同后轮及独立验证。
- `silent-proposal-e282a9131b99129a` — waiting；账本：silent-0021, silent-0079, silent-0125, silent-0176。KEN同指纹双向取舍和既有预测拆项已核；缺完整候选认证及受控后继，不拟通用6血/2伤门槛。

## 验证、记录和交付

无生产源码、验证输入、知识或任务模板改动。没有撤源码/恢复试验、tsc、vitest或沙箱套件，tests三个字段均null；30项证据检查和历史消费者读回不折算生产case。

已通过根learner/ledger.py update追加16条既有本角色账本追溯，CLI退出0；输入、stdout/stderr指纹、根账本逐行offset/bytes/SHA及原前缀校验见ledger-cli-receipt.json。只追加proposal/report/note，原claim/首证/prior/evidence/status/version/shipped逐值保持；不重复support、不新增机制证据或提案id。既有shipped条目没有降为proposed，宽提案仍waiting。没有新增机制异议或反证，双向取舍和未知保持明确记录。

没有上线、合入受阻或审批等待，不制造上线decision-log、eval版本、Roy双通知或成功测试。原学习入库和量化父要求保持，报告不冒称经验新入库或大脑已采用。无源码分支回报fixes=[]、merged=null，工作树保持干净；等待原调度器取得逐项所缺的新数据。

完整机器结果见result.json，原始截点/指纹/复核脚本和读回绑定均在本批目录。提交给运维的提案路径为本目录proposal.md。

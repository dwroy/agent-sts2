import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
path = ROOT / 'paper/materials/learning/ledger.jsonl'
payload = (OUT / 'ledger-updates.jsonl').read_bytes()
updates = [json.loads(line) for line in payload.splitlines()]
spec = importlib.util.spec_from_file_location('task_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
fields = ('character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at')
semantic = lambda folded: {u['id']: {k: folded[u['id']].get(k) for k in fields} for u in updates}
before = semantic(ledger.fold(ledger.read_rows(str(path))))
(OUT / 'ledger-semantic-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')

def prefix_sha(size):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        left = size
        while left:
            raw = handle.read(min(left, 1024 * 1024))
            assert raw
            digest.update(raw)
            left -= len(raw)
    return digest.hexdigest()

size = path.stat().st_size
prefix = prefix_sha(size)
env = dict(os.environ, TMPDIR=str(OUT), LEDGER_FILE=str(path), LEDGER_RUNS=str(ROOT / 'logs/runs.jsonl'), LEDGER_VERSIONS=str(ROOT / 'eval/versions.json'))
command = ['nice', '-n', '19', 'python3', str(ROOT / 'learner/ledger.py'), 'update']
result = subprocess.run(command, input=payload, capture_output=True, env=env)
(OUT / 'ledger-cli.stdout').write_bytes(result.stdout)
(OUT / 'ledger-cli.stderr').write_bytes(result.stderr)
receipt = {'command': command, 'exit_code': result.returncode, 'input_sha256': hashlib.sha256(payload).hexdigest(),
           'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
           'source_before_size': size, 'source_before_prefix_sha256': prefix}
(OUT / 'ledger-cli-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
assert result.returncode == 0
assert prefix_sha(size) == prefix
physical = []
with path.open('rb') as handle:
    handle.seek(size)
    while True:
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        row = json.loads(raw)
        if row.get('by') == 'learner:strategy-proposal' and str(OUT / 'report.md') in row.get('where', {}).get('proposal', []):
            expected = next(u for u in updates if u['id'] == row['id'])
            assert all(row.get(k) == v for k, v in expected.items()) and row['op'] == 'update'
            assert set(row) <= {'op', 'ts', 'id', 'by', 'where', 'note'}
            physical.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
assert len(physical) == len(updates) and len({e['row']['id'] for e in physical}) == len(updates)
after = semantic(ledger.fold(ledger.read_rows(str(path))))
assert before == after
receipt.update({'prefix_unchanged': True, 'semantic_fields_unchanged': True, 'appended_rows': physical,
                'updated_ids': sorted(after), 'new_mechanism_evidence': 0, 'status_changes': 0})
(OUT / 'ledger-cli-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': 0, 'appended_rows': len(physical), 'semantic_fields_unchanged': True}, ensure_ascii=False))

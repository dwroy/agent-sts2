## 修 bug 回报

- 合并基线：main → 1176e0296c1af8475992d719e5277e5af1f04fae（开工工作区干净；git merge --no-edit main 已是最新，无冲突）
- 修复（每条一行）：无新增；42个未勾选条目已逐项核对，已修的纯bug不重复提交。无新增修复，撤修复红绿验证不适用。
- 已被别人修掉的：silent-0254：无动作死亡战斗归因 — 3b48088dec5fc6eafe576a1296bbdadde43432ee（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：codex-usage-credit-baseline-recovery：额度窗口恢复基线 — 5b56a452bb9be14d620b368ec46974c1b57901ca（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ascension-up：请求进阶误报为实际进阶 — 8045d9fbf0a12523b1dbe39bbed8af06c7497b09（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout — bae9c45ccffefb284a1c6634526c8768a9f5f7a8（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-ledger-status-prefix-git-divergence — dd478f0b3e5a0f234f082972d21b203dbf8229d7（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-legacy-continuation-notice-ack-identity — 368fccabd42eb72ffcea9a2fe6cbbb7c149326be（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-paper-krane-recorded-line-timeout — befc39e5ca0105f8ff96d47f817df44f0b2760f1（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-learner-event-log-second-collision — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：strategy-proposal：报告 scratch 归属 — 5f04139cefe5c651dd5bf62f7e164014dbf5f23b（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0459：独立 run-plan 请求成本漏计 — 799a5cd0caf9329b43c32376079218a9bd0c3e9e（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：run-plan 证据提取未识别 run 字段 — 78e9b05929366d097a728761d693d790ff16ac87（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：postmortem-capacity-failure-proposal-repair-20261013 — 3fdcd77927f01b35c20c6c5c1fcfd790676032d2（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：blocked-experience-proposal-repair-dispatch — 84366ad06ee4f978394c1b9489a82c83ea12bd36（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：普通 ACK — 672e198a4730012330f599068a0ef1efadb02002（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 — 1594def2e1b65b665d3b345f31444194eb4d09e6（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 — 15eb85e2934e428c5e299fc4a1aba456d92fd685（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：feature 通知来源身份校验 — 38b2f572d90b3b97a23f9eae983f583287492f9a（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：feature/B4 通知来源桥接 — 1dd4d434aef67f1d065dbdba23a875ae82741a88（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：batch-f：包装/参数化测试超时静态解析 — 56c256dad0d33b231b82b53113d3bdd84f9bfa20（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：unassigned-strategy-proposal-resolution — 3a98e213a826e94f9708af4b1a265e1892659f4e（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval 固定历史输入 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-fixed-test-timeouts-010547：Apotheosis 有界夹具 — 9e8c93555131c3347f9e809d9722a848a75c2692（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：compute-memo-worker-data-signature — 8fbb441eb61eef226eb7366f9612003480c83988（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：rollout-live-best-test-determinism — bbc5b993a7524bbb8e80a975f204f8d193657b46（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-targeted-check-continuation：已过覆盖的精确续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：sandbox-glob-startup-race：会话前有界恢复 — bc2c40e313cc36682196277c53c50e30744b88c5（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：sandbox-glob-startup-race：复盘租约绑定 — d9983263ffecea1bed4e29d65e7f854a3d2e33d7（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：core-cycle-implementation-binding-entry — fc95760d4ff8a9cbd45577efdd79b1215bd2cb92（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-20261012-quantitative-continuation — b408252f87a77ee5389c4d90e52a9831c0873348（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：named-card-facts-transport：已批准的事件入口子项 — 42c920f34d9dc1c783ce894659849ab37ed6fd1b（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：core-build-notify-222802-rc2：保留原生失败诊断子项 — 5c92f2aaf0b758a1a5e7d591745694004664f83a（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：paper-dataset-git-consistency-race — 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：boss-sim-codex-home-preflight — 5921f8cd045853182c867a6430e75c3fcde00a87（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：shared-experience-fixed-filesystem-snapshot-20261013 — 8390c62d76fc8c7d7b6b7292121a621f4666d39c（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） — ec8c578b66bf5498372f1b779ae58a766dff8112（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：首项异步夹具 — 95e7f050ef2abe5c85a0367555392652ad73fbfe（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：固定失败诊断 — 9b6459fd99f26b17689134e33aa85d6190e71d7d（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：batch-c-fixed-fixture-timeout — 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：晚写复盘误计为上线后重犯 — 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：学习账本 first_run/asc/prior_note 追加更正 — 87c89b7aea90c7275e0fbb04b1e4148a4209630c（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：subscription-usage：未设置 TMPDIR — 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：deepseek-prompt-dump：状态日志反向流式扫描 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：固定药水测试隔离 — e78352f784d39cf25671446348daaada6ef2060b（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：单次 mod 超时 stall 误报 — a4f4ec868d122dc92af510862c6240cf2eaff2b6（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：学习状态锁被完整检查阻塞 — 233ede56047274ba53a4e1191a245fac816c37a8（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：学习者受阻后兜底完整检查入口 — f670884a188a047bbd3f7f007c260ade62fae36a（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：策略任务及自动派发入口 — afd652a3f75df6e7403439f01c565220327884da（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：旧事件选项重复问大脑 — 25ce09bee5576b1adff8baf196fbe8b197a5ef11（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0153：普通隐秘匕首生成分支 — b7f081fcc26da4506cb775739bb118cb6cbe4ecc（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0256：已观察的狡诈药水容量子项（实际源码提交） — 6403fdcdadc803a092beb5165a068e22bf51c412（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0260：普通紧勒逐牌失血 — 5c7105ff0294466da8319f2934beda05c6040794（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0263：已观察的碾碎爪转向取整子项 — ec29ea34b919344b707e57ba472ea210f9c39d62（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0266：SL 首牌身份 — e784dd9f043bf87c29109573f48975f9903280d3（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0272：商店移除预览与真实选牌页核对 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0324：普通刀舞生成小刀 — 66c22ba7d87b8748690a4183fff838acd346bd3e（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0338：回合末防御事实来源注记 — c1d84804956bedbd29a7f0e81294114e18415b9d（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0367：已用蜥蜴尾巴事实接线 — 5baf663d7e6678efa3690e5a48329c4f8baee109（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-learner-launch-shared-main-config-race — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：固定时间夹具 — b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：续验拒绝诊断 — 63f656fb07a21a7496353234269901a832eae497（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-worktree-history-disk-pressure：broker容量/回执失败隔离 — a136ddc4b5b0a8696f10b2fae3073322d57e724c（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-worktree-history-disk-pressure：无终态标记退出 — db072ddab47ba94efb46dce2913927f936ecb97e（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-worktree-history-disk-pressure：JSONL追加边界 — 9b07240b18f862efdbe630889ade04e8976eaace（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：ops-worktree-history-disk-pressure：历史副本/按需恢复 — c7a6efb1e15ed6c5f31a35ae3ee9833863340393（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：tracked-source Python缓存回收认定 — 1e8af775f6b90f100f20ff7c4a08dfddaba893a9（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：完成报告裸JSON兼容 — 6f86ff6b6b971fb38b96308ebdd34dec574e5b13（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：autoplay安全热交接动作 — 71b835a3150704548fab2ad46e74bde240ccf1f9（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：历史测试入口漏传日志回调 — ccd8bb8e017da9c30b408138d04e6d2bc985836d（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：额度警告固定测试契约 — 1cf0490492bd8a430b85f95f3fdee91eba251191（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：有限结束报告与补验交接 — 2c4ce406c9ae598835f22292e52cfd936ac10b14（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-checks-broker-push-registration — c519952b31e3a0bb3acdd2115883ae8671b8a090（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：host-checks-session-exit-fixture — 874ae603b3927173f805e0b2fe789330bab710c7（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：v5-dpr-health：明确不支持的候选被误计为DPR交付失败（仅分类子项） — 9e6dd82a34fb8c14e012be68fd0b632544f1459f（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：sandbox-glob-startup-race：父注册事务保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0469：已观察聚合体纸鹤组合子项 — 8d386fc7668820c2fc387d966f9d94bdcab189fb（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0317：已观察A10升级计算下注子项 — b49112dbc106e315bd7156361d290fc4c73d29e2（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-0319：已观察A10两费十毒预览子项 — 5b56a452bb9be14d620b368ec46974c1b57901ca（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：infra-feature-root-event-notice-path — 577f0bc424b7287910735cfdc86c253cc7ee8057（原窄子项；已核本分支/live祖先，非本批上线）
- 已被别人修掉的：silent-route-projection-provenance 诊断子项 — 7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a（原窄子项；已核本分支/live祖先，非本批上线）
- 没修的：silent-0271：毒必胜提前返回遗漏保血候选 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0279：SL抽序升级改标 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0308：沙坑截止结束题面 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0311：库存恢复血量预算 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0320：同线新建UNMOVABLE — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0322：升级神化同线升级 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0329：饮药临时力量接线 — 策略类/沿原独立提案，宽父保持
- 没修的：arch-funnel-guard — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：arch-learning-priority — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：arch-unified-resource-value — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：inv-f33-regression — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：silent-0332：成功首战接续nonpositive-hp — 证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知
- 没修的：silent-0334：升级隐秘匕首模型 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0339：尾巴误核销 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0344：坚韧之环延迟格挡 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0347：组装师攻击召唤 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0349：已有虚弱后的减力 — 策略类/沿原独立提案，宽父保持
- 没修的：core-build-notify-222802-rc2：历史发送事实 — 证据不足：后续诊断已修，原历史发送事实未知
- 没修的：silent-0362：背向攻击减力倍率 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0365：未建模药水目标可达性 — 策略类/沿原独立提案，宽父保持
- 没修的：框架外层时限与分段续验收尾 — 太大/独立框架：精确续验入口已实现，宿主收尾范围继续
- 没修的：调度公平性核查 — 证据不足：未证明永久饥饿，沿原框架核查
- 没修的：silent-0481：技能药水生命周期措辞 — 策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项
- 没修的：silent-0487：MAD_SCIENCE三段攻击模型 — 策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。
- 没修的：codex大脑缓存命中偏低 — 证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。
- 没修的：sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因 — 证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。
- 没修的：named-card-facts-transport：事件入口之外范围 — 太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。
- 没修的：boss模拟样本性能及v5-dpr-health宽范围 — 太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。
- 没修的：rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。
- 没修的：silent-0469：纸鹤其他未知组合/整战收益 — 策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。
- 测试：tsc 退出码0；定向vitest 14文件/71用例通过/退出码0，另32用例被筛选未运行；无重跑。无代码变更/提交，未运行完整test-sandbox.sh，不宣称全套通过。
- 合入：未合入（本批无新增提交；只读live快照 0e7998bfa8df267dcf8835a57949bdb982c9feb0；保留main/live既有分叉）
- 需要 Roy 定的事（没有写「无」）：无。

```json
{
  "task": "fix-batch",
  "base": "1176e0296c1af8475992d719e5277e5af1f04fae",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0271：毒必胜提前返回遗漏保血候选",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0279：SL抽序升级改标",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0308：沙坑截止结束题面",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0311：库存恢复血量预算",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0320：同线新建UNMOVABLE",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0322：升级神化同线升级",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0329：饮药临时力量接线",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-funnel-guard",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-learning-priority",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-unified-resource-value",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "inv-f33-regression",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "silent-0332：成功首战接续nonpositive-hp",
      "reason": "证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知"
    },
    {
      "item": "silent-0334：升级隐秘匕首模型",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0339：尾巴误核销",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0344：坚韧之环延迟格挡",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0347：组装师攻击召唤",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0349：已有虚弱后的减力",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足：后续诊断已修，原历史发送事实未知"
    },
    {
      "item": "silent-0362：背向攻击减力倍率",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0365：未建模药水目标可达性",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "框架外层时限与分段续验收尾",
      "reason": "太大/独立框架：精确续验入口已实现，宿主收尾范围继续"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：未证明永久饥饿，沿原框架核查"
    },
    {
      "item": "silent-0481：技能药水生命周期措辞",
      "reason": "策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项"
    },
    {
      "item": "silent-0487：MAD_SCIENCE三段攻击模型",
      "reason": "策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。"
    },
    {
      "item": "codex大脑缓存命中偏低",
      "reason": "证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。"
    },
    {
      "item": "sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因",
      "reason": "证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外范围",
      "reason": "太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。"
    },
    {
      "item": "boss模拟样本性能及v5-dpr-health宽范围",
      "reason": "太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。"
    },
    {
      "item": "silent-0469：纸鹤其他未知组合/整战收益",
      "reason": "策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 71,
    "files": 14,
    "scope": "targeted",
    "not_selected": 32,
    "reruns": [],
    "full_sandbox_run": false
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-100146-6d1bc92d-6dd4-4513-a694-132d79c5f942-fix-batch/report.md"
}
```

# 本批静默策略学习报告

记录时间：2026-10-16T10:13:52+08:00。task=strategy-proposal；character=silent；batch=20261016-100139-strategy-proposal。

本批十个原提案均保留waiting。已有窄实现与六局原记录可核部分机制、选线代价和资源端点，但未补齐持续执行归属、联合生产校准或受控整战比较；没有足够新证据改变预算、留药、血价、SL阈值、启动或目标顺序。没有源码/知识修改、源码提交、live合入、eval版本或新增shipped。

## 身份和基线

开工git status干净。先读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol和learning-code-proposals。根learn.json本批task/character/worktree/runs与题面一致，reason=proposal，十proposal_ids，无proposal_repair/research_request/implementation_request。普通专题请求绑定另一旧batch，本批不承接、不读取其他专题替代身份。执行git merge --no-edit main，Already up to date。

完整base=1176e0296c1af8475992d719e5277e5af1f04fae；HEAD保持该值，不新增提交。自行完成，没有下级agent。六个runs原行均为SILENT/A10负局，独立局数6；SL尝试不扩分母。未读其他角色私有知识，不从预训练知识补事实。

## 原始证据

共用extract_evidence.py抽取默认六流，另在evidence-extra追加runs/fight-plans，不覆盖首份报告。逐流先冻结source_size，按原offset读取bytes，逐行核SHA256、JSON对象及run_id/state.run_id/run/fingerprint.run显式身份，合计6995行全部通过。完整逐局计数、全源无效行计数及输出SHA在两个evidence-manifest.json；逐行读回回执为evidence-verification.json。全源无效JSON不认定属于本六局。fight-plans本截点0行仅说明本次未选到。

| 流 | 冻结source_size字节 | 已核所属行 |
|---|---:|---:|
| states | 13440225269 | 3432 |
| decisions | 1861557943 | 3306 |
| sl-attempts | 42844622 | 29 |
| run-config | 1845250 | 6 |
| run-plans | 8461971 | 33 |
| brain | 657439677 | 183 |
| runs | 345747 | 6 |
| fight-plans | 2233957 | 0 |

44项固定材料断言首次全部通过，见fact-checks.json及stdout。它们验证日志事实，不是生产测试或源码撤换负控。事实投影保留原行号、SHA、时间和指纹，原封套仍可逐字节追溯。

## 关键事实和限制

- VLZ F35/F43神化施放后已观察的升级、能量及场外deck不变可核；F36后抽毒药7毒已有live源码ba23ca693151fa8c6f7fe035e640dc30f05ccd75。F45仅持有不能当实际施放。当前神化参考actual_cast_this_fight仍为null，未知属性组合仍留unknown，不证明未施放必错或本可获胜。
- VLZ F45 T1两次药水题指纹不同；707ms是原题记录的预算消耗，不能作为同盘算法对照。T4 13损/24伤与31损/32伤是题面候选差，攻击替线没有完整实打后继。
- 8JRE F33首/第三试T2 d270216/d270282指纹一致；0/24与5/24预测死亡不同，进一步损失同为47是封顶。实际当轮玩家-3/-15、敌-10/-17，多12血换7敌净扣成立；原线持续至胜利的反事实不存在。T5护栏记录在rationale，hp_guard结构字段为空不代表未触发。
- CA5 F13力0/4/8、喷水11/15/19，虚弱后11/14仍成长；末轮2HP、10挡对14攻完整需损4，实死只扣剩2。未观察正敏捷不补成已有验证。
- 5PM F39第二试T2 d268455/s274379→274380，无毒失落35HP，冒泡实付1能，敌帧完全相同。此局部事实不证明不同启动次序或先建毒雾就能转胜。
- 61E F17 T5/T6吸取后玩家0力/-2敏、敌2力，双防御各3；毒17+16对应敌67→34。F23 T4幻象14→2仍攻击，玩家25→10，T5才退场；本体与幻象成长及退场需分别记录，不规定首杀。
- DUZU F30首试T5尖啸前后及T6 s274929/274932/274934，甲虫力2/-4/4、意图20/14/22；前三次判死中止和末次实死分列。末试多输出也多付当轮血，四次相关失败不支持固定血价/杀序。

## 现有离线消费者实际读回

从本批已核原行准备六份gzip输入，保留原decision_id、observed_ts、fingerprint与物理_line；仅去agent_view，输入及解码SHA在audit-inputs.json。CA5原267143、61E原267517、DUZU原268789/268818/268864五行无decision_id，是有界输入的明确排除，原行留在证据中，不造ID、不跨缺号认证连续性。不是六份完整输入无条件验收。

首轮六次node --import tsx均因工作树根目录无法解析包而ERR_MODULE_NOT_FOUND、exit1，原stderr和audit-receipts.json保留，没有调用到生产函数。随后只改为现有agent/node_modules/tsx/dist/loader.mjs绝对loader，同一输入SHA、同一consumer和wrapper六次exit0；第二轮输出/SHA见audit-r2-receipts.json，原失败未覆盖。没有安装依赖、改生产代码、网络、LLM或游戏调用。

| 局 | 有ID动作 | 题段 | 相邻观测端点 | 终页端点 | 已知轮窗 / 总窗 |
|---|---:|---:|---:|---:|---:|
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 / 46 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 / 73 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 / 101 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 / 96 |
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 / 107 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 / 111 |

合计3301动作、476题段、859相邻端点、4终页端点、534轮窗中121已知/413未知。完整候选actual_full_candidate_result全null，属于消费者保留的认证边界；既不证明没有动作收益，也不认证完整候选已执行、毛伤或策略胜率。净HP/敌HP与候选预测、SL恢复、未结算毒分列。

## 当前源码与实际live来源

只读live快照=0e7998bfa8df267dcf8835a57949bdb982c9feb0。16条精确源码路径中14条逐字节相同，card-model.ts和rollout-live.ts仅Roy/Dai历史注释姓名差异；原diff --binary和逐SHA回执保留。未因此重写历史或借用旧测试绿。

已核实际live祖先源码包括：772b839f8ada31664cb764ea9ad3bdb03da27f64（原神化传播）、3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（候选神化参考）、b2805be4ba44b7375c7908d873889372cc3cfe6c（萎靡升级）、ba23ca693151fa8c6f7fe035e640dc30f05ccd75（毒药升级），以及source-verification.json中其余审计/离线消费者祖先。它们证明窄子项存在，不是本批提交，也不作为宽提案整项duplicate/implemented。原运行代码带dirty，历史提交能定位与刷新知识/移动表/随机池未冻结分开，不笼统宣称历史源码全缺。

## 十项处置

| 原提案ID | 结果 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水、重规划及SL的本战实际施放持续归属；现有actual_cast_this_fight仍为null，重放、虚弱/脆弱等升级组合未校准。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的MC分阶段配对、样本稳定性曲线及留药后继；两个药水题指纹不同，不能据707ms改预算或持有价。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化经验链仍缺本战实际施放归属及未覆盖升级交互校准；窄传播已有live祖先，不足以把整个经验提案登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺原十五经验子项的完整联合生产校准、状态期限及战斗/路线/休息消费者逐源归属；六局原帧与窄源码不构成全子项验收。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有预测阶段、派发及观测轮端点工具；缺跨重规划的持续候选身份、完整执行认证和能力成长逐源兑现，不能据净端点改变SL血价或护栏。 |
| silent-proposal-49632bc4878fb597 | waiting | 蚌战未观察正敏捷；缺力量、正负敏捷、虚弱与独立成长在同一冻结生产调用中的联合校准，历史dirty知识/移动表不能仅凭提交号复原。 |
| silent-proposal-66532328a585941f | waiting | 缺同起始HP、牌组、药水及完整抽序的不同启动顺序整战对照与收益函数；无毒冒泡的局部无效不能拟合固定启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 吸取、负敏捷和毒端点可核，但缺同起始HP/构筑/完整抽序的SL整战配对及另一条已核后继；首试胜利不足以改SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、成长、退场与复现的全链生产校准及另一focus完整后继；现有召唤源码和T4端点不足以证明固定目标顺序收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及当前进阶成长的完整生产全链校准和同抽换序后继；四次相关失败不足以拟合血价或固定杀序。 |

每项原账本、原Markdown、证据局/层/回合、反例、预期行为、验证及回退详见proposal.md；十原文SHA均核一致并保存副本。没有新增重复提案ID，也不改队列或learn.json。code_proposals为本批十个既有CLI ID，implementation_domains=[]，表示本批没有实际实现。

## 记录、验证和交付

仅经根learner/ledger.py update给26个所属静默账本追加by=learner:strategy-proposal、proposal/report链接和具体核验说明；不重复添加既有证据、不改claim/first_run/prior/evidence/status/version或已有shipped。CLI输入、原输出和读回核验单独保留。最终proposal_results由既有调度器消费，waiting保留待新局，不把排队当实现或消费者交付。

无源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试、不冒报0。未启动live合入流程、merged=null；无上线记录、版本号、规则变更双通知。本批原事实读取曾把combat=null当对象产生TypeError，随后按可空字段读取；此交互读取错误留工具转录，不是游戏反证或产品测试失败。scratch与失败日志保留，不删自身工作树。

交运维提案路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-100139/learner/runs/20261016-100144-384b9bde-2323-4e8e-925b-f88aeaea2458-strategy-proposal/proposal.md。
报告路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-100139/learner/runs/20261016-100144-384b9bde-2323-4e8e-925b-f88aeaea2458-strategy-proposal/report.md。
最终干净树、HEAD及账本保护读回和gitleaks结果另见final-verification.json；不关闭原宽学习父要求，不声称经验已新入库或大脑已采用。

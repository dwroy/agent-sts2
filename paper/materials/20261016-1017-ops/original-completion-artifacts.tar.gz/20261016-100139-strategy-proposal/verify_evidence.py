import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract', WORKTREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
runs = json.loads((HERE / 'runs.json').read_text())
floors = {'VLZ6CCT8AQ0A': {35, 36, 37, 43, 45}, '8JRE1C4H4Z2W': {17, 33},
          'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 38, 39},
          '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}
manifest = []
facts = {'states': [], 'decisions': [], 'sl-attempts': [], 'run-config': []}
for folder in ('evidence', 'evidence-extra'):
    for stream in json.loads((HERE / folder / 'evidence-manifest.json').read_text()):
        counts = Counter()
        path = HERE / folder / (stream['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        previous = 0
        with path.open('rb') as f, (Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')).open('rb') as source:
            for line in f:
                digest.update(line)
                e = json.loads(line)
                assert e['offset'] >= previous
                previous = e['offset'] + e['bytes']
                assert previous <= stream['source_size']
                source.seek(e['offset'])
                raw = source.read(e['bytes'])
                assert hashlib.sha256(raw).hexdigest() == e['sha256']
                assert json.loads(raw) == e['row']
                assert extract.run_identity(e['row']) == e['run_id'] and e['run_id'] in runs
                counts[e['run_id']] += 1
                row = e['row']
                common = {'line': e['line'], 'sha256': e['sha256'], 'run_id': e['run_id']}
                if stream['stream'] == 'states':
                    s = row['state']; r = s.get('run') or {}; c = s.get('combat') or {}
                    assert str(r.get('character_id')).lower() == 'silent' and r.get('ascension') == 10
                    if r.get('floor') in floors[e['run_id']] and c:
                        facts['states'].append({**common, 'observed_ts': row['observed_ts'], 'fingerprint': row['fingerprint'],
                            'floor': r['floor'], 'turn': s.get('turn'), 'player': c.get('player'),
                            'hand': c.get('hand'), 'draw_pile': c.get('draw_pile'), 'discard_pile': c.get('discard_pile'),
                            'exhaust_pile': c.get('exhaust_pile'), 'enemies': c.get('enemies'), 'deck': r.get('deck'),
                            'potions': r.get('potions')})
                elif stream['stream'] == 'decisions' and row.get('floor') in floors[e['run_id']]:
                    facts['decisions'].append({**common, **{k: row.get(k) for k in
                        ['decision_id', 'observed_ts', 'fingerprint', 'floor', 'turn', 'sl_attempt', 'sl_reloads',
                         'label', 'chosen', 'result', 'journal', 'questions', 'answers', 'hp_guard', 'sl_explore',
                         'selection_audit', 'rationale', 'rollout_best_chosen']}})
                elif stream['stream'] in ('sl-attempts', 'run-config'):
                    facts[stream['stream']].append({**common, 'row': row})
        assert digest.hexdigest() == stream['output_sha256']
        assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
        manifest.append({**stream, 'verified_rows': sum(counts.values())})
for name, value in facts.items():
    (HERE / (name + '-facts.json')).write_text(json.dumps(value, ensure_ascii=False) + '\n')
receipt = {'streams': manifest, 'total_verified': sum(s['verified_rows'] for s in manifest),
           'selected_facts': {k: len(v) for k, v in facts.items()}}
(HERE / 'evidence-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

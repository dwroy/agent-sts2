import json
from pathlib import Path

P = Path(__file__).resolve().parent
S = {x['line']: x for x in json.loads((P / 'states-facts.json').read_text())}
D = {x['line']: x for x in json.loads((P / 'decisions-facts.json').read_text())}
checks = []

def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})

def player(line, field):
    return S[line]['player'][field]

def enemy(line, ident=None):
    return next(e for e in S[line]['enemies'] if ident is None or e['enemy_id'] == ident)

def power(values, ident):
    return next((p['amount'] for p in values if p['power_id'] == ident), 0)

def card(line, ident):
    return next(c for c in S[line]['hand'] if c['card_id'] == ident)

def dyn(line, ident, field):
    return next(v['current_value'] for v in card(line, ident)['dynamic_values'] if v['name'] == field)

def attack(line, ident=None):
    return sum(i['total_damage'] or 0 for i in enemy(line, ident)['intents'])

check('F35神化能量', [player(n, 'energy') for n in [275564, 275565]], [7, 5])
check('F35防御升级', [dyn(n, 'DEFEND_SILENT', 'Block') for n in [275564, 275565]], [5, 8])
check('F35打击升级含现场力量', [dyn(n, 'STRIKE_SILENT', 'Damage') for n in [275564, 275565]], [7, 10])
check('F35匕首雨逐击升级', [dyn(n, 'DAGGER_SPRAY', 'Damage') for n in [275564, 275565]], [5, 7])
check('F35必备工具费用升级', [card(n, 'TOOLS_OF_THE_TRADE')['energy_cost'] for n in [275564, 275565]], [1, 0])
check('F35场外升级数未变', [sum(bool(c['upgraded']) for c in S[n]['deck']) for n in [275564, 275565]], [1, 1])
check('F43尖啸升级', [dyn(n, 'PIERCING_WAIL', 'StrengthLoss') for n in [275679, 275680]], [6, 8])
check('F43勒紧升级', [dyn(n, 'FASTEN', 'ExtraBlock') for n in [275679, 275680]], [4, 6])
check('F43突然一拳伤害升级', [dyn(n, 'SUCKER_PUNCH', 'Damage') for n in [275679, 275680]], [9, 11])
check('F43突然一拳虚弱升级', [dyn(n, 'SUCKER_PUNCH', 'WeakPower') for n in [275679, 275680]], [1, 2])
check('F43次轮抽到升级毒雾', [card(275687, 'NOXIOUS_FUMES')['upgraded'], dyn(275687, 'NOXIOUS_FUMES', 'PoisonPerTurn')], [True, 3])
check('F43同轮与结算端点玩家血', [player(n, 'current_hp') for n in [275679, 275687]], [90, 77])
check('F43敌血净扣51', enemy(275679)['current_hp'] - enemy(275687)['current_hp'], 51)
check('F36后抽毒药实付1能', player(275604, 'energy') - player(275605, 'energy'), 1)
check('F36后抽毒药目标毒变化', [power(enemy(n)['powers'], 'POISON_POWER') for n in [275604, 275605]], [0, 7])
check('F36毒药施放不立即扣敌本体血', enemy(275604)['current_hp'], enemy(275605)['current_hp'])
check('F45持有不代表建立升级能力', [power(S[275732]['player']['powers'], i) for i in ['FASTEN_POWER', 'ACCELERANT_POWER']], [4, 1])
check('F45两个药水题起点不同', D[269748]['fingerprint'] == D[269754]['fingerprint'], False)
check('沙虫两试同指纹', D[270216]['fingerprint'] == D[270282]['fingerprint'], True)
check('沙虫SL预测保留不同死亡率', ['dead 0/24' in D[270282]['sl_explore']['numbers']['original'], 'dead 5/24' in D[270282]['sl_explore']['numbers']['replacement']], [True, True])
check('蚌当前力量增长', [power(enemy(n)['powers'], 'STRENGTH_POWER') for n in [273239, 273252, 273263]], [0, 4, 8])
check('蚌未虚弱喷水', [attack(n) for n in [273239, 273252, 273263]], [11, 15, 19])
check('蚌虚弱后仍成长', [attack(n) for n in [273254, 273268]], [11, 14])
check('蚌末轮完整需要4血而现有2', [attack(273268) - player(273268, 'block'), player(273268, 'current_hp')], [4, 2])
check('蚌实死HP截顶', [player(273269, 'current_hp'), enemy(273269)['current_hp']], [0, 16])
check('无毒冒泡实付能量', [player(n, 'energy') for n in [274379, 274380]], [5, 4])
check('无毒冒泡敌帧完全相同', S[274379]['enemies'], S[274380]['enemies'])
check('吸取后玩家力与敏捷', [power(S[273504]['player']['powers'], i) for i in ['STRENGTH_POWER', 'DEXTERITY_POWER']], [0, -2])
check('吸取后敌力量', power(enemy(273504)['powers'], 'STRENGTH_POWER'), 2)
check('负敏捷两次防御各3', [player(273505, 'block'), player(273507, 'block') - player(273506, 'block')], [3, 3])
check('吸取战毒17与16合33端点', [enemy(273504)['current_hp'], enemy(273508)['current_hp']], [67, 34])
check('幻象余2未退场', [enemy(n, 'PARAFRIGHT')['current_hp'] for n in [273593, 273595, 273596]], [14, 2, 2])
check('幻象未退场当轮损15', player(273593, 'current_hp') - player(273596, 'current_hp'), 15)
check('航行两实体增力', [power(enemy(273596, ident)['powers'], 'STRENGTH_POWER') for ident in ['PARAFRIGHT', 'THE_OBSCURA']], [6, 6])
check('甲虫临时减力及恢复成长', [power(enemy(n, 'SLUMBERING_BEETLE')['powers'], 'STRENGTH_POWER') for n in [274929, 274932, 274934]], [2, -4, 4])
check('甲虫意图随临减及成长', [attack(n, 'SLUMBERING_BEETLE') for n in [274929, 274932, 274934]], [20, 14, 22])
for r in json.loads((P / 'audit-r2-receipts.json').read_text()):
    audit = json.loads(Path(r['output']).read_text())
    check(r['run_id'] + '完整候选均保持未知', all(s['actual_full_candidate_result'] is None for s in audit['segments']), True)
    if r['run_id'] == '8JRE1C4H4Z2W':
        for attempt, hp, damage in [(1, -3, -10), (3, -15, -17)]:
            t = next(t for t in audit['observed_turns'] if t['floor'] == 33 and t['turn'] == 2 and t['attempt'] == attempt)
            check('沙虫第%d试整轮观测' % attempt, [t['facts']['player_hp_delta'], t['facts']['enemy_hp_changes'][0]['hp_delta']], [hp, damage])
(P / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'passed': sum(x['passed'] for x in checks), 'failed': [x['name'] for x in checks if not x['passed']]}, ensure_ascii=False))
raise SystemExit(0 if all(x['passed'] for x in checks) else 1)

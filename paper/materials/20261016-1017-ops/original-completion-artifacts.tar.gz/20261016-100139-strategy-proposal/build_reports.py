import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
stamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(stamp)
dispatch = json.loads((P / 'dispatch.json').read_text())
proposals = json.loads((P / 'proposals.json').read_text())
source = json.loads((P / 'source-verification.json').read_text())
verified = json.loads((P / 'evidence-verification.json').read_text())
audit = json.loads((P / 'audit-summary.json').read_text())
results = [
    ('缺跨抽牌、选牌、药水、重规划及SL的本战实际施放持续归属；现有actual_cast_this_fight仍为null，重放、虚弱/脆弱等升级组合未校准。',
     'VLZ6CCT8AQ0A F35 T1 s275564→275565，F43 T1 s275679→275680及T2 s275687；F36 T2 s275604→275605。能量7→5、实见升级和后抽毒药7毒均可核。',
     'F45 T1 s275722持有神化，但s275732只建立勒紧4、触媒1；F43施放后仍损13当轮血、整战仍付出代价。持有、施放与战胜的因果不能混写。',
     '保留已证升级传播和未知标记；未来按运行局/战斗/尝试持续关联真实施放、跨重规划状态及未覆盖交互，不加必打优先级。'),
    ('缺完整模型下同起点、同随机池、同总预算的MC分阶段配对、样本稳定性曲线及留药后继；两个药水题指纹不同，不能据707ms改预算或持有价。',
     'VLZ6CCT8AQ0A F45 T1 d269748题面明确707ms随机药水MC和退化非预测；d269754已有不同起点与更成熟局部推演；T4 d269770少损线13损/24伤、攻击候选31损/32伤。',
     '两题间已有多次实打，不能当作同盘预算实验；T4攻击候选未实打。F43胜后90→33及F44回到67不证明另一focus或留药可胜。',
     '保持当前预算、留药与目标规则。仅在冻结同起点/随机池/总时限并补齐神化覆盖后比较成熟度；保留所有合法候选，同推演值并列。'),
    ('同源神化经验链仍缺本战实际施放归属及未覆盖升级交互校准；窄传播已有live祖先，不足以把整个经验提案登记duplicate。',
     'VLZ6CCT8AQ0A F35 T1、F43 T1/T2及F45 T1，与原postmortem神化提案共享事实；原experience=silent-apotheosis-combat-upgrades。',
     '与89354805ee4d7e77是同源不同来源任务链接；题意相同不能替代实际live完整实现证明，F45未施放也不是神化效果反例。',
     '沿原两提案共用已证传播，不新建重复ID。未来补真实施放消费者及未证升级交互，分列持有、候选、模拟与实际。'),
    ('缺原十五经验子项的完整联合生产校准、状态期限及战斗/路线/休息消费者逐源归属；六局原帧与窄源码不构成全子项验收。',
     'VLZ6CCT8AQ0A F43 T1升级、T2负力、T3步法与口红、T4/T5毒；F45 T1未升级能力及T5的临时减力/格挡/敌存活。相关原账本逐项保留。',
     '单轮尖啸不取消后续成长；持有毒雾不等于建立；高血及回血也没有整场胜负保证。旧广范围/历史分母未在本批重算。',
     '继续逐源核算当前力量/敏捷、覆甲、勒紧、毒与回复，已准子项保持。缺完整联合证据时不拟合统一输出、保血或休息权重。'),
    ('已有预测阶段、派发及观测轮端点工具；缺跨重规划的持续候选身份、完整执行认证和能力成长逐源兑现，不能据净端点改变SL血价或护栏。',
     '8JRE1C4H4Z2W F33首/第三试T2 d270216/d270282指纹一致，五轮预测死亡0/24与5/24；当前离线工具核当轮玩家-3/-15、敌-10/-17。F33第二试T5 d270264另含护栏。',
     '六次SL来自同一局；末试T2防御替换确实省当轮血但未赢，反对一律认定保血错误。进一步损失同为47并不等于两线同死亡率。',
     '保留原SL与HP护栏。将候选预测、动作回执、重新提问、能力出现与轮端点分账；后续补持续身份与完整执行，不能把接口completed当整候选完成。'),
    ('蚌战未观察正敏捷；缺力量、正负敏捷、虚弱与独立成长在同一冻结生产调用中的联合校准，历史dirty知识/移动表不能仅凭提交号复原。',
     'CA5KE8GFJ9X2 F13 T1/T3/T5 s273239/273252/273263：力量0/4/8、喷水11/15/19；虚弱后s273254/273268为11/14。末轮2血10挡对14，完整需损4。',
     '虚弱只改变当轮显示攻击，后续仍增力；该战没有正敏捷实测，不能用别局能力收益代填。死亡实扣2受HP截顶，不能当作仅需2血。',
     '按现场属性、逐击修正和成长分项核验，不增加统一血价或输出权重；补固定模型输入与逐步实盘对照后再认定整项覆盖。'),
    ('缺同起始HP、牌组、药水及完整抽序的不同启动顺序整战对照与收益函数；无毒冒泡的局部无效不能拟合固定启动权重。',
     '5PM6JAQG6FNQ F39第二试T2 d268455、s274379→274380：目标失落之物35血无毒，冒泡消耗5→4能量，敌方完整快照相同。F33已建立组件并胜是不同战斗。',
     'F33与F39敌人、资源和生存条件同时变化；不得由F39失败反推只要先建毒雾就能胜。这里只确认该目标在该观测区间没有受益。',
     '分列牌组持有、计划条件、手牌与场上已建立能力；改变启动或构筑权重前需同盘完整后继和后置独立局验证。'),
    ('吸取、负敏捷和毒端点可核，但缺同起始HP/构筑/完整抽序的SL整战配对及另一条已核后继；首试胜利不足以改SL范围或阈值。',
     '61E2QS63Y9WU F17 T5→T6 s273502→273504：玩家力量2→0、敏捷0→-2、敌力量0→2；T6 s273505/s273507双防御各3，下一轮敌67→34。',
     '本局首试胜、未做本场同抽重打；毒17+16端点不能证明未选线胜率。临时减力随后恢复，不能视为永久关闭攻击。',
     '保持当前SL偏好，分列吸取、临时减力、负敏捷格挡和已结算毒；另有同盘完整SL证据后再讨论选择变化。'),
    ('缺A10召唤、成长、退场与复现的全链生产校准及另一focus完整后继；现有召唤源码和T4端点不足以证明固定目标顺序收益。',
     '61E2QS63Y9WU F23 T4 s273593→273595：幻象14→2仍在场；T5 s273596玩家25→10，两实体力量3→6，本体76→41。幻象T5 s273598才为0。',
     'focus幻象39伤零损候选未实打；不能把本体净扣当全员退场，enemy_id是类型也不能认证重复召唤实例。',
     '保留全部目标选项和同值并列；逐实体记录当前剩血/攻击/成长及退场窗口，补全代际和后继再评估目标策略。'),
    ('缺伤害唤醒、眩晕接续及当前进阶成长的完整生产全链校准和同抽换序后继；四次相关失败不足以拟合血价或固定杀序。',
     'DUZUBAJ3A8GP F30首试T3 s274919睡1，T4 s274923已醒；T5 s274929→274932→T6 s274934力量2→-4→4，攻击20→14→22。',
     '末试T4比首试多扣3敌血也多损2玩家血；前三次预测判死中止，末次实际死亡，不能混成四条完整实打死线或独立局。',
     '保持当前杀序与权重，分别核睡眠、失血唤醒、眩晕、临减恢复与成长；缺完整链时保留unknown，不用四败设规则。'),
]
proposal_results = []
originals = P / 'original-proposals'
originals.mkdir(exist_ok=True)
sections = []
manifest = []
for q, (reason, evidence, limits, behavior) in zip(proposals, results):
    original = Path(q['proposal']).read_bytes()
    digest = hashlib.sha256(original).hexdigest()
    assert digest == q['proposal_sha256']
    (originals / (q['id'] + '.md')).write_bytes(original)
    manifest.append({'id': q['id'], 'original': q['proposal'], 'sha256': digest})
    proposal_results.append({'id': q['id'], 'state': 'waiting', 'reason': reason})
    sections.append(f"""## {q['id']}

原题：{q['summary']}

来源：{q['source_task']} → strategy-proposal；角色silent，核实进阶A10。原账本：{', '.join(q['ledger'])}。原提案：{q['proposal']}；SHA256={digest}。

证据：{evidence}

反例、边界与未知：{limits}

当前行为及预期：{behavior}

本次处置：waiting。{reason}

验证方法：使用本批带原offset/bytes/SHA的固定状态与决策，先核逐帧数值及真实派发、重问、观测边界，再冻结本角色当前进阶HP/伤害/移动表、随机池与生产调用。不能拿刷新的知识或当前源码重跑当作旧dirty现场复原。若未来实现，独立固定夹具必须撤源码失败、恢复通过，再运行原沙箱入口并核无关角色等价。本批44项材料断言和现有离线消费者读回仅验证所列事实；本次不声称完成上述待做生产校准。

拟合与时间切分：本批不拟合常数；这些历史六局已用于发现，SL尝试不增加独立局数，不冒称盲测。策略收益须按run_id分组，用后续同角色/进阶独立完局验证。

预期影响与回退：本次只补明确处置及证据追溯，不改变行为、不承诺胜率。无新增源码可回退；保留原始记录。后续规则实际上线后才按Roy-2026-10-07-learning登记真实提交、版本及双通知。本批没有implemented_commit或shipped。
""")
(P / 'original-proposals-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(P / 'proposal.md').write_text(f"""# 本批十项静默策略提案核验

记录时间：{stamp}。task=strategy-proposal；character=silent；batch=20261016-100139-strategy-proposal。

base={source['base']}。只消费本批十个原ID，不新建提案，不覆盖原提案，不扩展其他队列。全部waiting，具体支持、限制及缺口如下。已核原Markdown副本及SHA见original-proposals/与其manifest。共同原始证据入口为evidence/及evidence-extra/，逐行原字节复核见evidence-verification.json。

""" + '\n'.join(sections))
stream_rows = '\n'.join(f"| {v['stream']} | {v['source_size']} | {v['verified_rows']} |" for v in verified['streams'])
audit_rows = '\n'.join(f"| {v['run_id']} | {v['actions']} | {v['segments']} | {v['observed_intervals']} | {v['terminal_endpoints']} | {v['known_turns']} / {v['turns']} |" for v in audit)
result_rows = '\n'.join(f"| {v['id']} | waiting | {v['reason']} |" for v in proposal_results)
report = f"""# 本批静默策略学习报告

记录时间：{stamp}。task=strategy-proposal；character=silent；batch=20261016-100139-strategy-proposal。

本批十个原提案均保留waiting。已有窄实现与六局原记录可核部分机制、选线代价和资源端点，但未补齐持续执行归属、联合生产校准或受控整战比较；没有足够新证据改变预算、留药、血价、SL阈值、启动或目标顺序。没有源码/知识修改、源码提交、live合入、eval版本或新增shipped。

## 身份和基线

开工git status干净。先读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol和learning-code-proposals。根learn.json本批task/character/worktree/runs与题面一致，reason=proposal，十proposal_ids，无proposal_repair/research_request/implementation_request。普通专题请求绑定另一旧batch，本批不承接、不读取其他专题替代身份。执行git merge --no-edit main，Already up to date。

完整base={source['base']}；HEAD保持该值，不新增提交。自行完成，没有下级agent。六个runs原行均为SILENT/A10负局，独立局数6；SL尝试不扩分母。未读其他角色私有知识，不从预训练知识补事实。

## 原始证据

共用extract_evidence.py抽取默认六流，另在evidence-extra追加runs/fight-plans，不覆盖首份报告。逐流先冻结source_size，按原offset读取bytes，逐行核SHA256、JSON对象及run_id/state.run_id/run/fingerprint.run显式身份，合计{verified['total_verified']}行全部通过。完整逐局计数、全源无效行计数及输出SHA在两个evidence-manifest.json；逐行读回回执为evidence-verification.json。全源无效JSON不认定属于本六局。fight-plans本截点0行仅说明本次未选到。

| 流 | 冻结source_size字节 | 已核所属行 |
|---|---:|---:|
{stream_rows}

44项固定材料断言首次全部通过，见fact-checks.json及stdout。它们验证日志事实，不是生产测试或源码撤换负控。事实投影保留原行号、SHA、时间和指纹，原封套仍可逐字节追溯。

## 关键事实和限制

- VLZ F35/F43神化施放后已观察的升级、能量及场外deck不变可核；F36后抽毒药7毒已有live源码ba23ca693151fa8c6f7fe035e640dc30f05ccd75。F45仅持有不能当实际施放。当前神化参考actual_cast_this_fight仍为null，未知属性组合仍留unknown，不证明未施放必错或本可获胜。
- VLZ F45 T1两次药水题指纹不同；707ms是原题记录的预算消耗，不能作为同盘算法对照。T4 13损/24伤与31损/32伤是题面候选差，攻击替线没有完整实打后继。
- 8JRE F33首/第三试T2 d270216/d270282指纹一致；0/24与5/24预测死亡不同，进一步损失同为47是封顶。实际当轮玩家-3/-15、敌-10/-17，多12血换7敌净扣成立；原线持续至胜利的反事实不存在。T5护栏记录在rationale，hp_guard结构字段为空不代表未触发。
- CA5 F13力0/4/8、喷水11/15/19，虚弱后11/14仍成长；末轮2HP、10挡对14攻完整需损4，实死只扣剩2。未观察正敏捷不补成已有验证。
- 5PM F39第二试T2 d268455/s274379→274380，无毒失落35HP，冒泡实付1能，敌帧完全相同。此局部事实不证明不同启动次序或先建毒雾就能转胜。
- 61E F17 T5/T6吸取后玩家0力/-2敏、敌2力，双防御各3；毒17+16对应敌67→34。F23 T4幻象14→2仍攻击，玩家25→10，T5才退场；本体与幻象成长及退场需分别记录，不规定首杀。
- DUZU F30首试T5尖啸前后及T6 s274929/274932/274934，甲虫力2/-4/4、意图20/14/22；前三次判死中止和末次实死分列。末试多输出也多付当轮血，四次相关失败不支持固定血价/杀序。

## 现有离线消费者实际读回

从本批已核原行准备六份gzip输入，保留原decision_id、observed_ts、fingerprint与物理_line；仅去agent_view，输入及解码SHA在audit-inputs.json。CA5原267143、61E原267517、DUZU原268789/268818/268864五行无decision_id，是有界输入的明确排除，原行留在证据中，不造ID、不跨缺号认证连续性。不是六份完整输入无条件验收。

首轮六次node --import tsx均因工作树根目录无法解析包而ERR_MODULE_NOT_FOUND、exit1，原stderr和audit-receipts.json保留，没有调用到生产函数。随后只改为现有agent/node_modules/tsx/dist/loader.mjs绝对loader，同一输入SHA、同一consumer和wrapper六次exit0；第二轮输出/SHA见audit-r2-receipts.json，原失败未覆盖。没有安装依赖、改生产代码、网络、LLM或游戏调用。

| 局 | 有ID动作 | 题段 | 相邻观测端点 | 终页端点 | 已知轮窗 / 总窗 |
|---|---:|---:|---:|---:|---:|
{audit_rows}

合计3301动作、476题段、859相邻端点、4终页端点、534轮窗中121已知/413未知。完整候选actual_full_candidate_result全null，属于消费者保留的认证边界；既不证明没有动作收益，也不认证完整候选已执行、毛伤或策略胜率。净HP/敌HP与候选预测、SL恢复、未结算毒分列。

## 当前源码与实际live来源

只读live快照={source['live_snapshot']}。16条精确源码路径中14条逐字节相同，card-model.ts和rollout-live.ts仅Roy/Dai历史注释姓名差异；原diff --binary和逐SHA回执保留。未因此重写历史或借用旧测试绿。

已核实际live祖先源码包括：772b839f8ada31664cb764ea9ad3bdb03da27f64（原神化传播）、3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（候选神化参考）、b2805be4ba44b7375c7908d873889372cc3cfe6c（萎靡升级）、ba23ca693151fa8c6f7fe035e640dc30f05ccd75（毒药升级），以及source-verification.json中其余审计/离线消费者祖先。它们证明窄子项存在，不是本批提交，也不作为宽提案整项duplicate/implemented。原运行代码带dirty，历史提交能定位与刷新知识/移动表/随机池未冻结分开，不笼统宣称历史源码全缺。

## 十项处置

| 原提案ID | 结果 | 具体缺口 |
|---|---|---|
{result_rows}

每项原账本、原Markdown、证据局/层/回合、反例、预期行为、验证及回退详见proposal.md；十原文SHA均核一致并保存副本。没有新增重复提案ID，也不改队列或learn.json。code_proposals为本批十个既有CLI ID，implementation_domains=[]，表示本批没有实际实现。

## 记录、验证和交付

仅经根learner/ledger.py update给26个所属静默账本追加by=learner:strategy-proposal、proposal/report链接和具体核验说明；不重复添加既有证据、不改claim/first_run/prior/evidence/status/version或已有shipped。CLI输入、原输出和读回核验单独保留。最终proposal_results由既有调度器消费，waiting保留待新局，不把排队当实现或消费者交付。

无源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试、不冒报0。未启动live合入流程、merged=null；无上线记录、版本号、规则变更双通知。本批原事实读取曾把combat=null当对象产生TypeError，随后按可空字段读取；此交互读取错误留工具转录，不是游戏反证或产品测试失败。scratch与失败日志保留，不删自身工作树。

交运维提案路径：{P / 'proposal.md'}。
报告路径：{P / 'report.md'}。
最终干净树、HEAD及账本保护读回和gitleaks结果另见final-verification.json；不关闭原宽学习父要求，不声称经验已新入库或大脑已采用。
"""
(P / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-100139-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [q['id'] for q in proposals], 'implementation_domains': [],
          'proposal_results': proposal_results, 'report': str(P / 'report.md')}
(P / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
notes = []
for ident, entry in json.loads((P / 'ledger-before.json').read_text()).items():
    linked = [q['id'] for q in proposals if ident in q['ledger']]
    reasons = [r['reason'] for r in proposal_results if r['id'] in linked]
    notes.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(P / 'proposal.md'), str(P / 'report.md')]},
        'note': '本批20261016-100139-strategy-proposal核对六局Silent A10原行、44项材料断言及现有离线审计，未改源码/策略/证据计数/旧状态；关联原提案' + ','.join(linked) + '均waiting：' + '；'.join(reasons)})
(P / 'ledger-updates.jsonl').write_text(''.join(json.dumps(n, ensure_ascii=False) + '\n' for n in notes))
assert set(r['id'] for r in proposal_results) == set(dispatch['proposal_ids'])
assert len(notes) == 26
print(json.dumps({'report': str(P / 'report.md'), 'proposals': len(proposal_results), 'ledger_updates': len(notes)}, ensure_ascii=False))

import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { auditSelectionExecution } from '../../lib/selection-execution.ts';

const [input, output] = process.argv.slice(2);
const result = auditSelectionExecution(JSON.parse(gunzipSync(readFileSync(input)).toString()));
writeFileSync(output, JSON.stringify(result) + '\n');
const values = (items, name) => items.filter(item => item[name] != null).length;
console.log(JSON.stringify({run_id: result.run_id, segments: result.segments.length,
  actions: result.observed_actions.length, intervals: result.observed_intervals.length,
  complete_candidates: values(result.segments, 'actual_full_candidate_result'),
  turns: result.observed_turns.length, turn_keys: Object.keys(result.observed_turns[0] ?? {})}));

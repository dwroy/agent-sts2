# 静默A10剃刀牙蛇咬：已观测整步17毒补模

本批20261014-214543-strategy-proposal为reason=tick的普通任务，无proposal_ids/proposal_repair、research_request或implementation_request。工作树初始干净，main合并Already up to date；base=264efa2ead498503a46d75ac4b4307f137648ac9。不承接其它批次专题。宿主原生会话gpt-6.1-sol/xhigh/default，已核conversation_starts实际model/effort，未重启或改变线程。

选题沿既有代码提案silent-proposal-f8b3c984fcd0d2cd；原文与postmortem提案JSON保持。code_proposals CLI原对象去重复用原ID，无重复提案。账本silent-0477（缺口）/silent-0478（整步机制）；原链接0479是恶魔形态对照，不修改其规则，不冒称新实现。来源任务postmortem；当前实现任务strategy-proposal，Roy-2026-10-07-learning。

## 假设与证据

待检验假设：模型将普通7毒、重放1静态计作14，遗漏实盘整步施加的3毒；只补整步，不假设升级发生的内部时点。

W1YY8PEWGUF9 SILENT A10：F33第二试T10，s403106→403107，敌42HP保持、毒0→17、玩家29HP保持、能量3→1；F45首试T1，s403240→403241，敌228HP保持、毒0→17、玩家31HP保持、能量5→3；同层末试T1，s403362→403363复核17。普通SNAKEBITE动态7/7/7未修改、牌文保留/7毒/重放1、两费，持未熔化RAZOR_TOOTH。三个样本同局，不能当三个独立种子或胜率样本。

共用extract_evidence.py冻结本批十局的states/decisions/sl-attempts/run-config/run-plans/brain/runs/fight-plans，保留source_size、物理行号、offset/bytes/SHA、计数及输出SHA。选中六原帧另逐seek核原字节、身份与JSON正文；冻结测试只使用本局原帧和显式空数据库，不加载刷新知识，不调模型/网络。源索引：

|原states行|offset|bytes|SHA256|
|---|---|---|---|
|403106|12765772998|38390|32c4ba1939f8db658de53a684b09edf72ac9fd895f3dcf3ba9f7480a57c9dc58|
|403107|12765811388|37809|057fc94e55f6a831120ea8413bfe3ac66f701c3fc17d7679b63a902fb010ddd9|
|403240|12771609559|50928|4dacce645f6cd3a1f788e27cfa0c54aca145c6a9b5dfcdb1ef9d68f286bf0a69|
|403241|12771660487|50231|c4f92c24c10f392d57451f6563a9da56f53ca5f0c8741bb5c1ec0a41b31bf159|
|403362|12778217021|50928|b21d17885bc2840046776ffb55ffb787923324b82e73842944107b102c379623|
|403363|12778267949|50231|22e5e1cb0f34646d8b6c473277a666c45ba85adea5d12c9a5bd1952207195d62|

## 旧行为、新行为与限制

旧行为：逐次resolveEffects复用7毒，整步14；结算后13毒。新行为：仅Silent A10、持未熔化遗物、当前原始玩家/敌人能力在已观测白名单内、普通精确7毒牌文/重放1、单一无毒/无人工制品/无虚无活目标、实际支付2能量且恰好两次手动效果、无额外复制/斧重放、毒额外触发/淬毒/群蛇和未观察逐技能遗物交互时，在两次原效果后补整步差3毒。总17、实际出牌即时HP伤害仍0、原支付与逐牌触发次数不变；之后原结毒模块独立结算17并剩16。

能力白名单只来自三帧原数据，不认证未知能力或缺失列表。非适用角色、其它进阶、无遗物、升级牌/其它牌文/附魔保持原模型。已持遗物但组合越界的候选保留旧数字并增加明确unknown，不删除选项，不改HP护栏、药水价格、SL门槛或能力优先级。

反例/未知：F45第二试T1不施蛇咬，不能算相同配对；本局F42后继蛇咬+为10毒且无重放，不足以重建重放内部升级顺序，不能推广20毒或永久保留replay1。F33现有懒惰重放名额未知保持。后续模拟回合清除当前原帧认证，返回牌的升级/重放仍用旧近似且明确unknown；不会把当前17毒复用为后续升级公式。没有整场受控反事实，不宣称改选线、省血或转胜；自然消费者另由ops核。

## 验证、切分与回退

使用F45首试原帧校准；同局末试与不同敌人的F33原帧作数值检验，明确不独立。通过production planCombatTurn的solveTap读回输入，再用traceSteps核完整实际单步施毒/支付/HP；将原后帧与模拟结算分开。whole-fight消费者验证第一轮17及后续scope=false，不认证后继牌面。其它角色/进阶/无遗物、未知能力、复制/额外重放/人工制品/已有毒等固定负控比较原算术。源码撤除须使这些真实数值断言失败，恢复后通过；完整沙箱tsc/vitest与gitleaks通过才提交/合入。

每项只提交此窄补丁。回退：实际部署后仅逆向该源码提交（含固定夹具），保留证据/账本/原提案与并行知识；由ops在live锁内登记新回退发布。未上线时不分配release_id、不标shipped；上线后双通知旧/新规则、证据与回退。

实际动作补核：d390915、d391045、d391167各在对应s前后时间窗内，完整fingerprint与前帧一致、原卡index匹配，result均completed；仅时间＋index会误纳相邻复用index动作，仅fingerprint会跨SL重复，已保留两次只读筛选断言失败并联合条件校正。它们不是策略源码失败，也不改变三同局窗口不独立的限制。

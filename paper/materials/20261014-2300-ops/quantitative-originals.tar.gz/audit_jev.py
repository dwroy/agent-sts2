"""Reuse the completed pilot, restricted to shared Silent core/qualification boundaries."""
import collections, gzip, hashlib, json
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2');OUT=ROOT/'learner/runs/20261014-215252-strategy-proposal';P=ROOT/'paper/materials/20261014-v5-jev-ablation/pilot-r2'
cases=json.loads((P/'cases.json').read_text());follow=[json.loads(l) for l in (P/'learner-followup.jsonl').read_text().splitlines()];analysis=json.loads((P/'analysis.json').read_text());by={x['case_id']:x for x in follow}
assert len(cases)==len(by)==32 and analysis['received']==analysis['ok']==144
checks=[];identities={};wanted={x['run'] for x in follow}
with (ROOT/'logs/runs.jsonl').open() as f:
 for line in f:
  if not any(run in line for run in wanted):continue
  d=json.loads(line)
  if d.get('run_id') in wanted:identities[d['run_id']]=d
assert wanted==set(identities) and all(x['character'].lower()=='silent' and x['ascension']==10 for x in identities.values())
(OUT/'pilot-run-identities.json').write_text(json.dumps({k:{f:v.get(f) for f in ['run_id','character','ascension','ended','code','victory']} for k,v in identities.items()},ensure_ascii=False,indent=2)+'\n')
differences=[];all_case_scope=[]
old_proofs={
 'dexterity':['C48LLXBGKXQ9/F33/T11/silent-0005','54G5683J0E5S/F33/T6-9/silent-0141/0385'],
 'poison':['4Y94N8RDPGPM/F48/T10-11/silent-0140/0141','L704TLETMZBM/F48/T3/silent-0194/0376'],
 'discard':['L704TLETMZBM/F48/T3/silent-0194/0376'],
 'shiv':['J8PHG72DGD90/F33/T13/silent-0154/0247'],
}
for case in cases:
 x=by[case['id']];changes=len(set(x['fresh_choices'].values()))>1
 refs=case['originals'];meta=next(a for a in refs if '-decision.' in a['path']);p=P/meta['path']
 if not p.exists():p=P.parent/meta['path']
 if p.exists():
  packed=p.read_bytes();assert hashlib.sha256(packed).hexdigest()==meta['gzip_sha256'];raw=gzip.decompress(packed)
 else:
  source=meta['source'];p=ROOT/source['path']
  with p.open('rb') as f:f.seek(source['offset']);raw=f.read(source['length'])
 assert hashlib.sha256(raw).hexdigest()==meta['raw_sha256'] and len(raw)==meta['raw_bytes']
 d=json.loads(raw);assert d['decision_id']==case['id'] and d['run_id']==x['run']
 checks.append({'case':case['id'],'path':str(p),'raw_sha256':meta['raw_sha256'],'raw_bytes':len(raw),'source':meta['source']})
 if not changes:
  all_case_scope.append({'case':case['id'],'run':x['run'],'changed_across_arms':False,'analysis_scope':'只登记固定输入和无分歧，不重做P0全史标签统计'});continue
 try:observed=json.loads(d['fingerprint'])
 except (ValueError,TypeError):observed={}
 models={};families=set()
 for arm,f in x['chosen_option_model_facts'].items():
  q=f.get('quantitative_turn',{});real=q.get('realization',{});before=real.get('established_before') or {};after=real.get('modeled_after_actions') or {};manual=real.get('manual_plays') or {}
  if before.get('dexterity',0)>0 or 'FOOTWORK' in manual:families.add('dexterity')
  if before.get('poisonExtraTriggers',0)>0 or any(e.get('poison',0)>0 for e in before.get('enemies',[])) or any(c in manual for c in ['ACCELERANT','NOXIOUS_FUMES','DEADLY_POISON','POISONED_STAB']):families.add('poison')
  if any(c in manual for c in ['SURVIVOR','ACROBATICS','CALCULATED_GAMBLE','HAND_TRICK','DAGGER_THROW']):families.add('discard')
  if 'SHIV' in manual or 'BLADE_DANCE' in manual:families.add('shiv')
  models[arm]={'choice':x['fresh_choices'][arm],'plays':f.get('plays'),'hp_loss':f.get('hp_lost'),'damage':f.get('damage_dealt'),'block':f.get('block_gained'),'energy_unused':f.get('energy_unused'),'hp_after':f.get('hp_after'),'potions':f.get('potions_used'),
   'complete_line':real.get('complete_line'),'energy_paid':real.get('energy_paid'),'manual_plays':manual,'effect_resolutions':real.get('effect_resolutions'),
   'initial_dexterity':before.get('dexterity'),'initial_poison_by_target':before.get('enemies'),'final_pending_selection':after.get('pendingSelection'),'unknown':real.get('unknown'),
   'complete_combinations':real.get('complete_combinations'),'scope':'原题面条件模型，未选线没有真实反事实'}
 audit=x['guard_sl_audit'];notes=[]
 if any(m['final_pending_selection'] for m in models.values()):notes.append('complete_line可以为true且后继选择仍pending；不得只用complete_line判完整资格，保留unknown/选择链')
 if any(any(e.get('poison',0)==0 for e in (m['initial_poison_by_target'] or [])) and 'ACCELERANT' in m['manual_plays'] for m in models.values()):notes.append('触媒拟建立时已有目标毒为0；NOXIOUS_FUMES仍在手不等已施放/输出兑现')
 if any('锁镰' in str(m['unknown']) for m in models.values()):notes.append('锁镰落点未展开；条件伤/损/击杀不是保证，不能作独立真值')
 if any(m['potions'] not in [None,'none'] for m in models.values()):notes.append('比较涉及药水消耗；不由伤害差单项判改善')
 notes.append('旧资格签名与本题机制重合不证明整套成型；当前手牌/敏捷/毒不足以补齐永久牌组、支付及全部后继归属')
 record={'case':case['id'],'run':x['run'],'floor':x['floor'],'turn':x['turn'],'source':meta['source'],'raw_sha256':meta['raw_sha256'],
  'character':'silent','ascension':10,'historical_run_code_label':identities[x['run']].get('code'),'historical_exact_source_commit':None,'source_binding_limit':'runs.jsonl的current标签不是精确源码SHA；不指认为冻结R345或旧51e0','role_overlap':sorted(families),'old_evidence_links':{k:old_proofs[k] for k in sorted(families)},
  'fresh_jev_choices':x['fresh_choices'],'historical_jev_choice':x['historical_choice'],'code_candidate_reference':x['direct_baseline'],
  'models':models,'observed_fingerprint_fields':{k:observed.get(k) for k in ['run','turn','hp','maxHp','player','hand','powers','enemies']},
  'historical_guard':{k:audit.get(k) for k in ['attempt','requested_action','execution_status','actual_turn','sl_delta']},
  'guard_stages':{stage:{'planned_steps':(audit.get(stage) or {}).get('planned_steps'),'model_turn':(audit.get(stage) or {}).get('turn'),'line':(audit.get(stage) or {}).get('line')} for stage in ['answer','before_sl','after_sl']},
  'historical_dispatched_request':d.get('chosen'),'historical_request_result':d.get('result'),'sl_attempt':d.get('sl_attempt'),
  'historical_first_action_completed':str(d.get('result','')).startswith('completed:'),
  'historical_first_action_matches_guard':all((d.get('chosen') or {}).get(k)==(audit.get('requested_action') or {}).get(k) for k in ['action','card_index','target_index']),
  'same_projected_guard_steps':audit.get('answer',{}).get('planned_steps')==audit.get('before_sl',{}).get('planned_steps')==audit.get('after_sl',{}).get('planned_steps'),
  'original_guard_scope':audit.get('scope'),'observed_fingerprint_scope':'原决策时实际状态的精简指纹；模型established_before另列，不当完整原帧',
  'actual_fresh_arm_execution':False,'historical_complete_turn_adoption':'unknown','card_draw_SL_followup':'pending_R3_input_not_replayed_here',
  'actual_counterfactual_quality':x.get('actual_counterfactual_quality'),'boundaries':notes,'new_strategy_or_quality_label':None}
 differences.append(record);all_case_scope.append({'case':case['id'],'run':x['run'],'changed_across_arms':True,'role_overlap':sorted(families),'scope':'旧资格/真实记录边界对照，非P0 Jev-versus-code排序工具'})
assert len(differences)==6 and sum(x['fresh_jev_choices']['full']!=x['fresh_jev_choices']['compact_unlabelled'] for x in differences)==5
summary={'cases':32,'runs':len(wanted),'completed_original_calls':144,'new_API_calls':0,'full_compact_changed':5,'any_arm_changed_union':6,
 'same_run_overlap_with_original_024317_15_evidence_runs':sorted(wanted & {'C48LLXBGKXQ9','LRN0HPZ0FZS1','KAY522KT5NXR','ZZMYZ5UBCG72','4Y94N8RDPGPM','25226ZFLNR1J','PU80F84P6HPN','L704TLETMZBM','P5HT1272P5SB','KV0JHNJCKXLS','XTSV1U9JD34T','J8PHG72DGD90','54G5683J0E5S','49HL2N70CHMU','53NU9DWSTG9H'}),
 'overlap_kind':'同角色的旧机制/资格条件与新固定题面重合，非同一对局或同一完整真实窗口',
 'all_six_mechanism_overlap':all(x['role_overlap'] for x in differences),'valid_actual_counterfactual_pairs':0,
 'original_analysis':{'token_reduction_pct':27.566275352733683,'full_compact_changed_choices':5,'pilot_model':'jev-1.13.0'},
 'historical_first_action_completed_in_six':sum(x['historical_first_action_completed'] for x in differences),'historical_first_action_guard_matches_in_six':sum(x['historical_first_action_matches_guard'] for x in differences),'not_game_win_probability_samples':True,'not_closed_P1_P2_or_P0':True}
for name,data in [('jev-differences.json',differences),('jev-case-scope.json',all_case_scope),('jev-input-verification.json',checks),('jev-summary.json',summary)]:
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))

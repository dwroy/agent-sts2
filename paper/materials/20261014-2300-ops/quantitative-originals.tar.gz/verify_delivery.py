"""Final read-only provenance and data-only invariants; never updates task status."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2');OUT=ROOT/'learner/runs/20261014-215252-strategy-proposal';WORK=ROOT/'.worktrees/codex-strategy-silent-20261012-024317'
BASE='51e0c1f475f842b355172f1f2a6f320cae9fb58d'
AT=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(AT)
def meta(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def write(name,d):(OUT/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
r=json.loads((OUT/'report.json').read_text());wanted=set(r['runs']);identities=[];lines=[];off=0
with (ROOT/'logs/runs.jsonl').open('rb') as f:
 for line in f:
  here=off;off+=len(line)
  if not any(s.encode() in line for s in wanted):continue
  d=json.loads(line)
  if d.get('run_id') not in wanted:continue
  assert d['character'].lower()=='silent' and d['ascension']==10 and d['ended']
  identities.append({'run_id':d['run_id'],'character':d['character'],'ascension':d['ascension'],'ended':d['ended'],'code_label':d.get('code'),
   'source':{'path':'logs/runs.jsonl','offset':here,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()}});lines.append(line)
assert len(identities)==len(wanted) and {x['run_id'] for x in identities}==wanted
(OUT/'frozen-run-identity-lines.jsonl').write_bytes(b''.join(lines));write('frozen-run-identity-provenance.json',identities)
manifest=json.loads((OUT/'approved-input.json').read_text());verified=[]
assert meta(OUT/'approved-input.json')['sha256']=='090e06674242b78bae2cd18c5017d164f4f554ed9f5b87d244ca4154431e0ff0'
for x in manifest['inputs']:
 actual=meta(ROOT/x['path'])
 if actual['sha256']!=x['sha256'] or actual['bytes']!=x['bytes']:
  assert x['path']=='docs/v5-s-decision-plan.md'
  recovered=json.loads((OUT/'frozen-document-recovery.json').read_text())
  assert recovered['source_commit']=='264efa2ead498503a46d75ac4b4307f137648ac9' and recovered['original_path']==x['path']
  frozen=meta(recovered['frozen_copy']);assert frozen['sha256']==x['sha256'] and frozen['bytes']==x['bytes']
  actual={'original_path':x['path'],'root_at_final_verification':actual,'verification_source':'fixed_git_blob_recovered_into_authorized_OUT','frozen_copy':frozen,'git_blob':recovered['git_blob'],'source_commit':recovered['source_commit']}
 verified.append(actual)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=WORK,text=True)
assert head==BASE and not status
assert r['base']==BASE and r['fixes']==[] and r['merged'] is None and r['tests']=={'tsc':None,'vitest':None,'cases':None}
assert r['code_proposals']==r['implementation_domains']==[] and r['parent_complete'] is False
assert r['continuation_result']['outcome']=='complete' and all(r['continuation_result']['coverage'].values())
for x in r['continuation_result']['inputs']+r['continuation_result']['results']:assert meta(x['path'])['sha256']==x['sha256']
s=json.loads((OUT/'r2-summary.json').read_text());rows=[json.loads(l) for l in (OUT/'r2-candidate-evidence.jsonl').read_text().splitlines()]
assert len(rows)==778 and sum(x['option']!='__base__' for x in rows)==724
assert s['questions']==30 and s['supported']==27 and s['unsupported']==3 and len(s['groups'])==54
assert s['named_discard_pair_record_rows']==0 and all(x['S'] is None and x['first_complete_core_start'] is None for x in rows)
assert s['reference_order_null_questions']==25 and s['order_field_equality_not_full_trajectory_kill_order_proof']
assert all(x['terminal_dpr_n']==1000 for x in rows)
f=json.loads((OUT/'fixed-offline-validation.json').read_text());assert len(f['checks'])==25 and all(x['passed'] for x in f['checks'])
j=json.loads((OUT/'jev-summary.json').read_text());assert j['new_API_calls']==0 and j['valid_actual_counterfactual_pairs']==0 and j['completed_original_calls']==144
c=json.loads((OUT/'calibration-boundary.json').read_text());assert c['new_R3_results_received'] is False and c['new_replay_or_fit'] is False
assert json.loads((OUT/'parent-and-limited-child-boundary.json').read_text())['deck_table_revision2']['outcome']=='complete'
size=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());assert size<256*1024*1024
write('final-verification.json',{'at':AT,'passed':True,'head':head,'original_worktree_clean':True,'frozen_input_count':len(verified),'frozen_inputs':verified,
 'same_role_frozen_run_count':len(identities),'identity_provenance':meta(OUT/'frozen-run-identity-provenance.json'),
 'outputs_bytes_before_final_manifest':size,'production_source_knowledge_ledger_or_other_owner_written':False,'frozen_document_recovery':meta(OUT/'frozen-document-recovery.json'),
 'limited_delivery_complete':True,'wide_parent_complete':False,'new_simulations':0,'new_API_requests':0,'new_production_release':None,'tests':r['tests']})
# No self-referential hash: this manifest excludes itself, report.json and the final receipt.
files=[meta(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['artifact-manifest.json','report.json','delivery-receipt.json','verify-delivery.stdout','verify-delivery.stderr']]
write('artifact-manifest.json',{'at':AT,'scope':'本轮实际结果/脚本/必要固定副本逐原字节SHA；原重数据只经输入索引引用','files':files,'excluded_self_referential':['artifact-manifest.json','report.json','delivery-receipt.json'],'production_modified':False})
r['continuation_result']['results'].append(meta(OUT/'artifact-manifest.json'));write('report.json',r)
write('delivery-receipt.json',{'at':AT,'report':meta(OUT/'report.md'),'report_json':meta(OUT/'report.json'),'artifact_manifest':meta(OUT/'artifact-manifest.json'),
 'final_verification':meta(OUT/'final-verification.json'),'scope_complete':True,'parent_complete':False,'ops_or_watcher_ack':None})
print(json.dumps({'passed':True,'frozen_inputs':len(verified),'original_head':head,'clean':True,'fixed_offline_checks':25,'bounded_complete':True,'parent_complete':False,'outputs_bytes':size},ensure_ascii=False))

"""Consume frozen R2 artifacts; no simulator, network, ranking policy, or source edits."""
import collections, gzip, hashlib, json, math
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2')
OUT=ROOT/'learner/runs/20261014-215252-strategy-proposal'
P=ROOT/'paper/materials/20261014-2121-ops'
index=json.loads((P/'R2-originals/completed-reference-index.json').read_text())
coverage=json.loads((P/'R2-originals/question-coverage.json').read_text())
packet=json.loads((ROOT/'paper/materials/20261014-v5-boss-revalidation/historical-input-packet-r2.json').read_text())
cases={x['id']:x for x in coverage['cases']}
assert len(cases)==30 and coverage['supported']==27 and coverage['unsupported']==3
checks=[];rows=[];groups=[];violations=[];raw_witnesses=[]
def load_verified(path, sha):
 p=Path(path);p=p if p.is_absolute() else ROOT/p
 assert p.resolve().is_relative_to(ROOT)
 raw=p.read_bytes();actual=hashlib.sha256(raw).hexdigest();assert actual==sha,str(p)
 checks.append({'path':str(p),'sha256':actual,'bytes':len(raw)})
 return json.loads(raw)
for group in index['groups']:
 d=load_verified(group['result']['path'],group['result']['sha256'])
 q=d['full_quantitative'];ids=q['complete_ids'];case=cases[group['id']]
 assert d['reference_complete'] and d['actual_completed_pairs']==1000 and ids==list(range(1000))
 assert d['id']==group['id'] and d['seed']==group['seed']
 options=q['options'];assert isinstance(options,dict)
 option_sims={x['key']:x for x in d['result']['options']}
 assert set(options)==set(option_sims) and len(options)==case['numerical']
 for key,value in [('__base__',q['base']),*options.items()]:
  assert value['samples']==1000
  assert sum(value[x] for x in ['wins','deaths','capped','time_up'])==1000
  dp=value['effective_damage_per_turn'];pd=value['paired_effective_damage_per_turn'];core=value.get('core_window',{})
  assert 0<=dp['n']<=1000 and 0<=pd['difference']['n']<=min(dp['n'],q['base']['effective_damage_per_turn']['n'])
  assert dp['n']==value['wins']+value['deaths']
  for name in ['hp_loss','simulated_turns']:
   assert value[name]['n']==1000
  for name in ['effective_damage_per_turn','hp_loss','simulated_turns']:
   st=value[name]
   if st['n']>1 and st['sd'] is not None:assert math.isclose(st['meanSe'],st['sd']/math.sqrt(st['n']),rel_tol=1e-9,abs_tol=1e-10)
  if core:assert core['valid']+core['missing']==1000
  first={c:metrics['first_play_when_played'] for c,metrics in core.get('cards',{}).items()}
  rows.append({'question':case['id'],'run':case['run_id'],'floor':case['floor'],'label':case['label'],'seed':group['seed'],'option':key,
   'source':group['result'],'model':'R2/093c68ac658980f53b9940756b3df925adfb49bb','common_completed_ids':1000,
   'terminal_dpr_n':dp['n'],'dpr':dp,'paired_dpr':pd,'paired_hp':value.get('paired_hp'),'paired_win':value.get('paired_win'),'DPR_won_only':value.get('damage_per_turn_won'),'DPR_died_only':value.get('damage_per_turn_died'),'wins':value['wins'],'deaths':value['deaths'],'capped':value['capped'],'time_up':value['time_up'],
   'hp_loss':value['hp_loss'],'hp_remaining':value.get('hp_remaining'),'simulated_turns':value['simulated_turns'],'win_only_turns':value['turns_won_only'],
   'core_trace_valid':core.get('valid'),'core_trace_missing':core.get('missing'),'energy_paid':core.get('energy_paid'),'manual_actions':core.get('manual_actions'),'effect_resolutions':core.get('effect_resolutions'),'paired_energy_paid':core.get('paired_energy_paid'),'potions_used':value.get('potions_used'),'first_turn_damage':value.get('first_turn_damage'),'later_damage':value.get('later_damage'),'block_gained':value.get('block_gained'),
   'single_card_first_play_when_played':first,'first_complete_core_start':None,
   'complete_combinations':value.get('complete_combinations'),'core_combinations':core.get('combinations'),
   'boss_margin':value.get('boss_relative_margin'),'S':None,
   'S_missing_reason':'旧R2模型无bossMargin入口参考及敌伤/目标归属契约；不由聚合DPR或capped hpLoss拼S',
   'simulation_not_actual_execution':True,'current_R345_accuracy_or_readiness_not_inferred':True})
 groups.append({'question':case['id'],'run':case['run_id'],'seed':group['seed'],'options':len(options),'common_ids':1000,
  'terminal_dpr_n_min':min(v['effective_damage_per_turn']['n'] for v in options.values()),'terminal_dpr_n_max':max(v['effective_damage_per_turn']['n'] for v in options.values()),
  'core_trace_valid_min':min(v.get('core_window',{}).get('valid',0) for v in options.values()),
  'order':d['result'].get('order'),'orders':d['result'].get('orders'),'source':group['result']})
 assert all(v.get('boss_relative_margin') is None for v in [q['base'],*options.values()])
# Original source bytes remain byte-exact and prove character identity; no historical resampling.
for case in packet['cases']:
 meta=case['state'];p=ROOT/meta['path'];compressed=p.read_bytes();assert hashlib.sha256(compressed).hexdigest()==meta['compressed_sha256']
 raw=gzip.decompress(compressed);assert hashlib.sha256(raw).hexdigest()==meta['raw_sha256'] and len(raw)==meta['raw_bytes'];wrapper=json.loads(raw);state=wrapper.get('state',wrapper)
 run=state['run'];assert run['character_id'].lower()=='silent' and run['ascension']==10
 checks.append({'path':str(p),'sha256':meta['compressed_sha256'],'raw_sha256':meta['raw_sha256'],'raw_bytes':len(raw),'source':meta['source']})
# Repetition is a diagnostic of frozen model noise, not a best-option selector.
by=collections.defaultdict(dict)
for x in rows:
 if x['option']!='__base__':by[(x['question'],x['option'])][x['seed']]=x
repeat=[]
for (qid,key),pair in by.items():
 assert set(pair)=={7,20261014}
 a,b=pair[7],pair[20261014];aa=a['paired_dpr']['difference'];bb=b['paired_dpr']['difference'];usable=aa['n']>0 and bb['n']>0
 orders={g['seed']:g['order'] for g in groups if g['question']==qid}
 repeat.append({'question':qid,'option':key,'seed7':aa,'seed20261014':bb,'both_available':usable,'same_reference_order':orders[7]==orders[20261014],'reference_order_observed':orders[7] is not None and orders[20261014] is not None,
  'paired_difference_sign_changed':usable and aa['mean']*bb['mean']<0,
  'resolved_beyond_two_mean_SE_both':usable and aa['meanSe'] is not None and bb['meanSe'] is not None and abs(aa['mean'])>2*aa['meanSe'] and abs(bb['mean'])>2*bb['meanSe'],
  'no_policy_ranking_or_game_quality_label':True})
assert len(groups)==54
candidates=[x for x in rows if x['option']!='__base__']
summary={'scope':'原54完成参考组的既有数值消费；未重新模拟/重抽/删题','model':'093c68ac658980f53b9940756b3df925adfb49bb',
 'questions':30,'supported':27,'unsupported':3,'common_id_groups':54,'common_ids_each':1000,'unique_common_seed_ids':2000,
 'sample_identity_namespace':['question','seed','sample_id'],'question_seed_sample_IDs':54000,'IDs_not_independent_across_candidate_rows':True,
 'option_metric_rows':len(candidates),'base_metric_rows':len(groups),
 'terminal_dpr_n_range':[min(x['terminal_dpr_n'] for x in candidates),max(x['terminal_dpr_n'] for x in candidates)],
 'option_rows_terminal_dpr_n_lt_1000':sum(x['terminal_dpr_n']<1000 for x in candidates),
 'option_rows_terminal_dpr_n_zero':sum(x['terminal_dpr_n']==0 for x in candidates),
 'core_trace_valid_range':[min(x['core_trace_valid'] for x in candidates),max(x['core_trace_valid'] for x in candidates)],
 'first_complete_core_start_available_rows':0,'S_supported_rows':0,'S_is_unknown_not_zero':True,
 'seed_repeat_option_pairs':len(repeat),'both_seed_dpr_available':sum(x['both_available'] for x in repeat),
 'paired_DPR_sign_changed':sum(x['paired_difference_sign_changed'] for x in repeat),
 'sign_change_beyond_two_SE_both':sum(x['paired_difference_sign_changed'] and x['resolved_beyond_two_mean_SE_both'] for x in repeat),
 'original_11s_gate_pass':{'seed7_supported':{'n':4,'denominator':27},'repeat_supported':{'n':5,'denominator':27},'full30':[4,5]},
 'old_11s_not_current_required_production_stop':True,'full_reference_first_DPR_rank_changes_original_report':13,
 'unsupported_cases':[x for x in coverage['cases'] if x['status']!='supported'],'groups':groups,
 'checks_count':len(checks),'offline_issues':violations}
reversals=[x for x in repeat if x['paired_difference_sign_changed'] and x['resolved_beyond_two_mean_SE_both']]
summary.update({'reference_order_changed_questions':len({x['question'] for x in repeat if not x['same_reference_order']}),'reference_order_null_questions':len({g['question'] for g in groups if g['order'] is None}),'order_field_equality_not_full_trajectory_kill_order_proof':True,
 'named_discard_pair_record_rows':sum(bool((x['core_combinations'] or {}).get('discardBandages')) for x in rows),
 'termination_rows':{'all_option_and_base_rows':len(rows),'capped_samples':sum(x['capped'] for x in rows),'time_up_samples':sum(x['time_up'] for x in rows),'wins_range':[min(x['wins'] for x in rows),max(x['wins'] for x in rows)]},
 'sign_reversal_2SE_candidate_keys':[x['question']+'/'+x['option'] for x in reversals],
 'sign_reversal_2SE_distinct_statistical_contrasts':len({(x['question'],json.dumps([x['seed7'],x['seed20261014']],sort_keys=True)) for x in reversals}),
 'sign_reversal_keys_preserved_no_dedup_or_candidate_drop':True})
for name,data in [('r2-summary.json',summary),('r2-repeat-diagnostic.json',repeat),('r2-input-verification.json',checks)]:
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(OUT/'r2-candidate-evidence.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
print(json.dumps({k:v for k,v in summary.items() if k not in ['groups','unsupported_cases']},ensure_ascii=False))

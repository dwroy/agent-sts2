"""Read frozen records; save bounded provenance and accounting/admission boundaries."""
import gzip, hashlib, json, subprocess
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2')
OUT=ROOT/'learner/runs/20261014-215252-strategy-proposal'
OLD=ROOT/'.worktrees/codex-strategy-silent-20261012-024317'
OPS=ROOT/'paper/materials/20261014-2121-ops'
checks=[]
def read(path, expected=None):
 p=Path(path);p=p if p.is_absolute() else ROOT/p
 assert p.resolve().is_relative_to(ROOT)
 raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest()
 if expected:assert sha==expected,str(p)
 checks.append({'path':str(p),'sha256':sha,'bytes':len(raw)})
 return json.loads(raw)
def write(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
profile=read(OPS/'R2-originals/profiling-manifest.json')
files={f['path']:f for f in profile['files']}
for m in profile['original_manifests']:
 for f in read(m['path'],m['sha256'])['files']:files[f['path']]=f
index=read(OPS/'R2-originals/completed-reference-index.json','e4157a63c7e9558c6b5d67b727bd73ea9f847fd64536ea20efeaebd8870d7d66')
result=read(index['groups'][0]['result']['path'],index['groups'][0]['result']['sha256'])
phase=Path(result['phases'][1]);packed=phase.read_bytes();meta=files[str(phase)]
assert hashlib.sha256(packed).hexdigest()==meta['sha256']
with gzip.open(phase,'rb') as f:line=f.readline()
reply=json.loads(line)
matches=[t for t in reply['results'] if sum(t[3]['lossByTurn'])>t[3]['hpLoss']]
assert matches
deck,order,identity,outcome=matches[0]
(OUT/'raw-worker-first-line.txt').write_bytes(line)
write('raw-model-accounting-witness.json',{'scope':'旧R2已完成模拟的原始worker回复，非实盘/非新模拟',
 'model':'093c68ac658980f53b9940756b3df925adfb49bb',
 'source':{'path':str(phase),'sha256':meta['sha256'],'bytes':len(packed),
  'uncompressed_line_offset':0,'line_bytes':len(line),'line_sha256':hashlib.sha256(line).hexdigest(),
  'manifest_chain':[str(OPS/'R2-originals/profiling-manifest.json'),profile['original_manifests'][0]['path']]},
 'sample':{'question':result['id'],'seed':result['seed'],'deck':deck,'order':order,'sample_id':identity,'outcome':outcome},
 'comparison':{'hpLoss':outcome['hpLoss'],'lossByTurn_sum':sum(outcome['lossByTurn']),'final_model_hp':outcome.get('resources',{}).get('hp'),
  'receivedHpDamage':outcome.get('receivedHpDamage'),'bossMargin':outcome.get('bossMargin')},
 'conclusion':'hpLoss与逐轮loss总额不等；即便逐轮总额可见，敌伤/自伤/回血/目标及入口契约未分解，不补算S。'})
packet=read(ROOT/'paper/materials/20261014-v5-boss-revalidation/historical-input-packet-r2.json')
case=next(c for c in packet['cases'] if c['id']=='a3972427-a5e0-4b04-ac7d-d2069888fd11')
meta=case['state'];raw=gzip.decompress((ROOT/meta['path']).read_bytes());assert hashlib.sha256(raw).hexdigest()==meta['raw_sha256']
state=json.loads(raw).get('state',json.loads(raw));selection=state['selection']
cards=selection['cards'] if isinstance(selection,dict) else selection
selected=[c for c in cards if c.get('index') in [17,18]]
assert len(selected)==2 and all(c['card_id']=='PIERCING_WAIL' and not c['upgraded'] for c in selected)
write('paired-sign-counterexample.json',{'question':case['id'],'source':meta,'cards':selected,
 'option_keys':['card17','card18'],'one_identical_statistical_contrast':True,'candidate_keys_preserved':True,
 'evidence_kind':'真实同角色候选身份+旧模型配对差，不证明实盘胜率变化',
 'differences':[x for x in json.loads((OUT/'r2-repeat-diagnostic.json').read_text()) if x['question']==case['id'] and x['option'] in ['card17','card18']]})
freeze=read(OPS/'current-production-freeze.json','a4913a595c5b8db180a902d358fa1cf981fb9918aeb5a79ec936576ce61f9d53')
frozen={f['path']:f for f in freeze['files']};selected=[]
for p in sorted((OUT/'frozen-production').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(OUT/'frozen-production'));raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest()
 assert sha==frozen[rel]['sha256'] and len(raw)==frozen[rel]['bytes']
 selected.append({'path':str(p),'source_path':rel,'sha256':sha,'bytes':len(raw)})
paths=[x['source_path'] for x in selected]
diff=subprocess.run(['git','diff','--binary','51e0c1f475f842b355172f1f2a6f320cae9fb58d',freeze['live_head'],'--',*paths],cwd=OLD,check=True,capture_output=True).stdout
(OUT/'old-to-R345-source.patch').write_bytes(diff)
write('source-comparison.json',{'old_head':'51e0c1f475f842b355172f1f2a6f320cae9fb58d','frozen_live':freeze['live_head'],'release':freeze['release_id'],
 'archive':freeze['source_archive'],'selected_files':selected,
 'binary_diff':{'path':str(OUT/'old-to-R345-source.patch'),'sha256':hashlib.sha256(diff).hexdigest()},
 'running_reference':freeze['actual_running_config_reference'],'selected_only':True,'source_or_knowledge_modified':False})
pending=read(OPS/'calibration-pending-receipt.json')
read(pending['frozen_input']['path'],pending['frozen_input']['sha256'])
legacy=ROOT/'.worktrees/silent-boss-calibration/learner/runs/20261014-061307-silent-boss-calibration/report.md'
raw=legacy.read_bytes();checks.append({'path':str(legacy),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
write('calibration-boundary.json',{'owner':'061302/01a13753-c032-73f0-aa3f-ddc0e14809cd','frozen_pending_receipt':pending,
 'new_R3_results_received':False,'new_replay_or_fit':False,'pending_as_of_frozen_receipt_not_live_poll':True,
 'legacy_report':checks[-1],'legacy_model':'7e1193cef9467416bc10c8e344a49f4fd98390c7','legacy_model_sha256':'a16714b6349b4d4c79bbc91c3875c979607f80da1e619b59f5a0a82e45210a5a',
 'legacy_sample_scope':'210固定输入；旧36条恶魔B2满足数量但残差未过质量，新39条仍未过质量；F49未获联合可信',
 'not_R345_validation':True,'missing':['同决策/SL/实际采用/模型指纹的真实逐动作匹配','同窗口敌伤/目标/入口参考归属','当前模型分组偏差/绝对误差/覆盖率'],
 'next_owner_action':'原校准owner按冻结R3输入接续；本报告不等待事件、不重放、不拟合，不以旧模型撤可信替代父项完成。'})
parent=read(ROOT/'notes/core-cycle-quantitative-learning-request.json')
progress=read(ROOT/'notes/core-cycle-quantitative-progress.json')
partial=read(ROOT/'paper/materials/20261012-0323-ops/partial-acceptance.json')
oldresult=read(OLD/'learner/runs/20261012-024330-strategy-proposal/result.json')
childbase=ROOT/'.worktrees/codex-strategy-silent-20261012-140741/learner/runs/20261013-core-decklists-live-readback'
child=read(childbase/'result.json');receipt=read(child['learning_result']['consumer_receipt']['path'],child['learning_result']['consumer_receipt']['sha256'])
verification=read(childbase/'final-verification.json')
assert child['learning_result']['outcome']=='complete' and verification['status']=='passed' and receipt['checks']['entry_reads']==15
for e in receipt['evidence']:p=Path(e['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
write('parent-and-limited-child-boundary.json',{'parent_request_id':parent['request_id'],'root_record_state_at_read':parent['state'],'parent_complete':False,
 'old_owner_head':str(OLD),'old_candidate_sources':[x['commit'] for x in oldresult['fixes']],
 'old_12_conflicts_and_failure_history_preserved':True,'old_leaf_commits_not_merged_this_turn':True,
 'later_scoped_integration':progress['actual_publication'],'later_release_distinct_receipt_from_original_leaf':True,'original_leaf_ancestry_of_frozen_R345':json.loads((OUT/'frozen-ancestry.json').read_text()),'old_report_unmerged_point_in_time_not_current_claim':True,
 'original_four_deliverables':partial['deliverables'],'wide_missing':progress['remaining_implementation']+progress['remaining_evidence'],
 'deck_table_revision2':{'request_id':child['learning_result']['request_id'],'revision':2,'outcome':'complete','reopened':False,
  'source':child['source_commit'],'merged':child['merged'],'release':child['release_id'],'receipt':child['learning_result']['consumer_receipt'],
  'fixed_reads':15,'natural_adoption_or_game_benefit':None,'questions_preserved':child['learning_result']['questions']},
 'legacy_completion_not_wide_P1_P2_closure':True,'no_business_status_writes':True})
for name in ['report.md','consumer-coverage.md','prior-evidence-input-manifest.json','coverage.json','fixed-frame-replay.json']:
 p=OLD/'learner/runs/20261012-024330-strategy-proposal'/name;raw=p.read_bytes()
 checks.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'scope':'原完成材料只读引用，不重播'})
write('additional-input-provenance.json',checks)
print(json.dumps({'profile_witness':{'hpLoss':outcome['hpLoss'],'sumLoss':sum(outcome['lossByTurn'])},'verified_source_files':len(selected),'child_r2_completed':True,'new_R3_received':False},ensure_ascii=False))

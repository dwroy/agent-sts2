// Fixed arithmetic and missing-data checks against the frozen R345 functions only.
import assert from 'node:assert/strict';
import { writeFileSync, readFileSync } from 'node:fs';
import { bossRelativeMargin, marginOf, summarizeBossMargin } from './frozen-production/agent/src/sim/boss-margin.ts';
import { pairedDifference, summarizeSamples, abstractHandAccess, binomialInterval } from './frozen-production/agent/src/sim/quantitative-stats.ts';
const checks = [];
const eq = (id, actual, expected) => { assert.deepEqual(actual, expected); checks.push({id, actual, expected, passed:true}); };
const near = (id, actual, expected) => { assert(Math.abs(actual-expected)<1e-12); checks.push({id, actual, expected, passed:true}); };
const sample = (outgoingHp, receivedHp, won=true, extra={}) => ({turns:2, won, died:!won, capped:false,timeUp:false,
  bossMargin:{reference:{bossHp:100,myHp:50,enemyIds:['synthetic-target'],unknown:[]},outgoingHp,receivedHp},...extra});
near('same-window-fixed-entry-reference',marginOf(sample(100,20)),0.3);
eq('missing-trace',marginOf({turns:2,won:false,died:true,capped:false,timeUp:false}),null);
eq('unknown-attribution',marginOf(sample(100,20,true,{bossMargin:{reference:{bossHp:100,myHp:50,enemyIds:[],unknown:['self-cost-or-healing']},outgoingHp:100,receivedHp:20}})),null);
eq('missing-received-not-zero',marginOf(sample(100,null)),null);
eq('zero-entry-hp',bossRelativeMargin(50,10,100,0),null);
eq('zero-window',marginOf(sample(100,20,true,{turns:0})),null);
eq('capped',marginOf(sample(100,20,true,{capped:true})),null);
eq('time-up',marginOf(sample(100,20,true,{timeUp:true})),null);
eq('multi-boss-sequence',marginOf(sample(100,20,true,{sequence:{bosses:2}})),null);
const incomplete=summarizeBossMargin([sample(100,20),sample(100,null)],[sample(100,30),sample(100,30)],[41,7]);
eq('subset-not-ranking-eligible',incomplete.rankingEligible,false);
eq('subset-score-null',incomplete.score,null);
eq('subset-paired-n',incomplete.paired.difference.n,1);
eq('subset-unmatched-base',incomplete.paired.unmatchedBase,1);
const pair=pairedDifference([{sample:41,value:1},{sample:7,value:10}],[{sample:7,value:12},{sample:99,value:100}]);
eq('match-identity-not-order',pair.difference.mean,2);
eq('unmatched-not-zero', [pair.unmatchedBase,pair.unmatchedOption,pair.difference.n],[1,1,1]);
const spread=summarizeSamples([-2,2]);near('SE-not-outcome-spread',spread.meanSe,2);near('outcome-p10',spread.p10,-1.6);
assert(spread.meanSe!==spread.p90-spread.p10);
eq('abstract-access-not-real-combination',abstractHandAccess(10,5,2,12),{probabilityPerHand:2/9,expectedQualifyingHands:8/3});
assert(binomialInterval(0,2)[1]>0 && binomialInterval(2,2)[0]<1);checks.push({id:'zero-all-small-sample-not-proof',passed:true});
// These are abstract trajectories, not card or monster values.
const slow=sample(100,49,true,{turns:1});
const fragileWin=sample(100,0,true,{turns:1});
const fragileDeath=sample(0,50,false,{turns:10});
const slowValues=Array(10).fill(slow),fragileValues=[...Array(9).fill(fragileWin),fragileDeath];
const slowMean=summarizeSamples(slowValues.map(marginOf)).mean;
const fragileMean=summarizeSamples(fragileValues.map(marginOf)).mean;
assert(fragileMean>slowMean && 9/10<1);
checks.push({id:'higher-mean-S-does-not-prove-higher-win-probability',passed:true,
 slow:{meanS:slowMean,wins:10,n:10},fragile:{meanS:fragileMean,wins:9,n:10},gameEvidence:false});
// Arithmetic alone cannot infer the terminal cause; admission must carry own-cost/heal flags.
const untaggedOwnCost=sample(20,0,false,{turns:1});
near('positive-arithmetic-S-with-self-cost-death',marginOf(untaggedOwnCost),0.2);
const taggedOwnCost={...untaggedOwnCost,bossMargin:{...untaggedOwnCost.bossMargin,reference:{...untaggedOwnCost.bossMargin.reference,unknown:['self-cost-not-separable']}}};
eq('correct-unknown-tag-prevents-S-admission',marginOf(taggedOwnCost),null);
checks.push({id:'sign-claim-needs-causal-accounting-and-time-order',passed:true,gameEvidence:false,
 explanation:'构造的自伤死亡例；算术正S不能推出存活。真实自伤/回血/复活归属由上游及独立校准核，非本轮发现实盘机制或生产bug。'});
// Equal marginal means cannot replace the per-sample reference ratios.
const variableEntry=[sample(100,20),sample(100,20,true,{bossMargin:{reference:{bossHp:100,myHp:100,enemyIds:['synthetic-target'],unknown:[]},outgoingHp:100,receivedHp:20}})];
const meanPerSample=summarizeSamples(variableEntry.map(marginOf)).mean;
const ratioOfMeans=bossRelativeMargin(50,10,100,75);
assert(Math.abs(meanPerSample-ratioOfMeans)>1e-3);
checks.push({id:'per-sample-before-summary',passed:true,meanPerSample,ratioOfMeans,gameEvidence:false});
const witness=JSON.parse(readFileSync(new URL('./raw-model-accounting-witness.json',import.meta.url)));
eq('old-R2-raw-does-not-admit-S',marginOf(witness.sample.outcome),null);
writeFileSync(new URL('./fixed-offline-validation.json',import.meta.url),JSON.stringify({scope:'冻结R345纯算术接口及缺字段固定核验，非生产测试/模拟/实盘校准',source:'4437492bb1498181430a5f51ddbafd9d54571aa6',newSimulations:0,newAPICalls:0,checks},null,2)+'\n');
console.log(JSON.stringify({checks:checks.length,passed:true,productionTests:null}));

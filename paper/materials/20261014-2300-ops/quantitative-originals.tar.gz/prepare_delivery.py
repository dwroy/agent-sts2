"""Assemble the bounded data-only continuation, with explicit unresolved parent scopes."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/home/dw/Projects/agent-sts2');OUT=ROOT/'learner/runs/20261014-215252-strategy-proposal'
BASE='51e0c1f475f842b355172f1f2a6f320cae9fb58d'
AT=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
print(AT)
def load(name):return json.loads((OUT/name).read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def meta(p):
 p=Path(p);raw=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
r2=load('r2-summary.json');jev=load('jev-summary.json');diff=load('jev-differences.json');sources=load('source-comparison.json')
parent=load('parent-and-limited-child-boundary.json');cal=load('calibration-boundary.json');fixed=load('fixed-offline-validation.json')
assert len(fixed['checks'])==25 and all(x['passed'] for x in fixed['checks'])
assert len(diff)==6 and all(x['historical_first_action_completed'] and x['historical_first_action_matches_guard'] for x in diff)
write('offline-check-receipt.json',{'at':AT,'scope':'数据与冻结纯算术接口检查；不是tsc/vitest/游戏模拟/LLM或生产消费者新增验收',
 'checks':[{'script':'audit_r2.py','exit_code':0,'evidence':'r2-audit.stdout','groups':54,'option_rows':724},
 {'script':'audit_jev.py','exit_code':0,'evidence':'jev-audit.stdout','original_cases':32,'shared_boundary_differences':6},
 {'script':'audit_boundaries.py','exit_code':0,'evidence':'boundary-audit.stdout','verified_selected_source_files':14},
 {'script':'check-margin.mjs','exit_code':0,'evidence':'fixed-offline-validation.stdout','fixed_checks':25}],
 'saved_failure':'boundary-audit-attempt1.stderr；一次字段名称适配失败保留，不是生产源码测试失败',
 'environment_limits':'environment-failures.txt','tests':{'tsc':None,'vitest':None,'cases':None},
 'new_simulations':0,'new_API_requests':0,'source_removed_tests':None,'production_source_changes':False})
experience=load('frozen-production/knowledge/characters/silent/experience.json')
ids=['silent-core-poison-defense-observation','silent-core-dexterity-defense-observation','silent-core-shiv-defense-observation','silent-core-discard-relic-observation']
entries={e['id']:e for e in experience['entries']}
conditions=[
 '施毒/触媒/具体防御候选分支；持有、到手、实付、建立和实际毒/挡兑现分开。KF9反例限制“每条胜线必须施放指定防御”及“10张已证最小”。',
 '原至少两张永久步法及已观察挡/输出签名不改；已有敏捷与单步法+夜魇不补永久来源。54G T6副本到手未建、T7实际支付建立仍作边界。',
 '供刀/增益/防御分支不等价；已生成刀也须核手位、行动/敌人限额、实际打出及触发后继。',
 '原两种以上实际弃牌组件+指定遗物候选不改；当前可计的杂技/下注/已建3绷带具名分支不是整个原弃牌核心，也不是无限。']
core=[]
for i,c in zip(ids,conditions):
 e=entries[i];core.append({'entry_id':i,'source_path':str(OUT/'frozen-production/knowledge/characters/silent/experience.json'),
  'source_file_sha256':meta(OUT/'frozen-production/knowledge/characters/silent/experience.json')['sha256'],
  'entry_sha256':hashlib.sha256(json.dumps(e,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
  'hash_convention':'完整entry按UTF-8、sorted keys、紧凑JSON规范化；文件原字节SHA另列',
  'unchanged_signature_boundary':c,'current_complete_core_qualification':None,'qualification_probability':None,
  'first_complete_core_start':None,'unconditional_complete_core_count':None,'game_win_probability_from_signature':None,
  'observation_scope':'原r2条目/原角色证据只读复用，不追加知识或支持分母'})
consumers=[
 {'stage':'战斗/回合/已变状态重规划','state':'已存在','source':'agent/src/reflex/combat-plan.ts:3832,3843 + sim/quantitative-facts.ts',
  'provided':'required B2完整配对闸；当前线realization与whole_fight_sim/boss_relative_margin随原候选进入facts',
  'proof':'R345冻结源码；pilot原题面已有quantitative_turn；二者源码命名空间不混',
  'missing':'原四套联合资格/最早可达启动；本轮没有R345新自然读取/整回合采用证据'},
 {'stage':'出牌/药水/弃牌/保留/复制对象','state':'部分已存在','source':'agent/src/sim/core-realization.ts:13 + core-window.ts:14',
  'provided':'合法前缀费用、手动/重放、已建/拟建、未知选择分账；仅具名弃牌分支可计',
  'proof':'原五端点15资源值及后续限定发布；本轮Jev六题历史首动作completed与guard请求相符',
  'missing':'未选线实际反事实、独立弃牌/保留/复制后继、夜魇来源归属、完整后缀与药水实际校准'},
 {'stage':'结束回合/SL','state':'原保护及未知边界保留','source':'现有combat-plan/guard接口；pilot guard_sl_audit',
  'provided':'原guard前/后SL预测与请求可分列；低样本、unknown不可直接当必死',
  'proof':'六题before_sl/after_sl计划相同、projected delta为0；仅一题记录attempt=2，其他attempt空',
  'missing':'这不是SL后真实执行链；本轮不提取真实换手/SL后继、不修SL或必死规则'},
 {'stage':'拿/跳/买/删/升级/变换/事件','state':'已存在有限条件模拟','source':'agent/src/sim/build-sim.ts + build-sim-facts.ts:549',
  'provided':'required完整目标样本/有效终局DPR闸、同ID配对；低可信S禁止排序',
  'proof':'R2旧源54参考完成及当前R345静态契约分列；原四候选实验只证明其有界模型',
  'missing':'候选的真实核心资格、完整资源/价格路径、现模型独立校准、P2语义排序；watcher拥有新排序实现'},
 {'stage':'路线/休息/战前/后续Boss','state':'已有构筑入口；连续资格未支持','source':'agent/src/sim/build-sim-facts.ts:561 + boss-margin.ts:33',
  'provided':'跨Boss模拟/血药已有入口；连续多Boss S及全链组合未知保留',
  'proof':'R345序列拒收与低信任标签；原49HL反例及r2子项KF9出口资源限制',
  'missing':'两个Boss分别启动、准备轮、carryover血药/复活成本与全局生存资格；不由独立均值拼接'},
 {'stage':'S/deltaS','state':'R345已发布计算接口','source':'agent/src/sim/boss-margin.ts:32 + boss-sim.ts:298',
  'provided':'同窗口/每样本入口参考的S，按ID配对；截断、未知、序列保留null；叠加原信任闸',
  'proof':'本輪25项冻结纯函数核验；不冒称实际brain/Jev新增消费者调用或真实校准',
  'missing':'提供的旧R2及pilot记录没有合格的S原始归属窗口；现模型真实敌伤/自伤/回血/复活校准pending'},
 {'stage':'Jev wire请求','state':'R342替换已发布','source':'agent/src/reflex/jev/decision-projection.ts + compact-request.ts',
  'provided':'替换完整中间轨迹，保留有序候选、必要结果、分母/闸/unknown；完整审计仍保留',
  'proof':'冻结request-contract-map final_state与source75249bef…；一笔既有frozen API 22252 tokens；本轮API=0',
  'missing':'32题pilot不证收益；R342真实自然请求接受不等于宽量化模型已校准；P0协议改动由watcher独占'},
 {'stage':'经验消费者','state':'原牌表r2限定子项completed','source':'V4-R313 consumer-receipt.json / current Silent experience只读',
  'provided':'3固定真实构筑题×5新增文本，15/15 live前缀读回',
  'proof':'原receipt SHA4f0b8033…与七份依赖逐SHA核，final-verification passed；未再次执行消费者',
  'missing':'不证明自然采用/胜率或本轮R345请求已读回；宽P1/P2继续'},
 {'stage':'预测/实际校准及自然效果','state':'部分旧交付，当前R3 pending','source':'calibration-boundary.json / 原061302 owner',
  'provided':'旧限定首动作匹配；旧210输入固定模型校准报告；新R3冻结输入需求',
  'proof':'原报告旧模型7e1193…与当前R345不同；冻结21:47回执prepared_not_dispatched_checkout_busy',
  'missing':'新真实动作及窗口配对、偏差/MAE/覆盖率、自然读取→采用→收益；本轮不等待事件、不拟合'}]
write('scope-consumer-map.json',{'at':AT,'parent_complete':False,'core_signatures':core,'consumers':consumers,
 'implementation_excluded':'roy-20261014-s-decision/P0，watcher独占.worktrees/s-decision-20261014',
 'P0_no_source_sorting_readiness_scalar_protocol_work_here':True})
margin=[
 {'kind':'R2 724候选+54baseline聚合统计','n':778,'same_ID_pairing':'题号/seed/id共同；终局DPR n=1000实际核实',
  'supports':['旧模型DPR/HP/费用/回合分布及各自有效分母','旧模型paired DPR/HP/win/energy差及SE'],
  'missing':['raw目标归属','同窗口敌人实际HP伤归属','入口HP/目标参考绑定','自伤/有效回血/复活分离','现模型与原真实动作校准'],
  'S':None,'deltaS':None,'S_eligible':False,'real_game_win_rate':None},
 {'kind':'R2原worker第一个回复内的具名样本','source':'raw-model-accounting-witness.json','n':1,
  'supports':['原逐轮数组/终止类型/样本ID；hpLoss70与lossByTurn86不等'],
  'missing':['receivedHpDamage/bossMargin不存在','逐轮loss不自动等敌伤','实际Boss目标HP参考/自伤回血归属','真实窗口'],
  'S':None,'deltaS':None,'S_eligible':False,'model_witness_not_actual_game':True},
 {'kind':'Jev pilot六个角色条件分歧','n':6,'source':'jev-differences.json',
  'supports':['原决策精简状态指纹','计划/费用/未知/guard预测','历史首动作completed确认'],
  'missing':['完整原实帧后继','实际整回合/整战敌伤归属','新arm实际采用/未选线反事实','五题SL attempt缺失','历史精确源码SHA'],
  'S':None,'deltaS':None,'S_eligible':False,'model_option_rank_is_truth':False},
 {'kind':'原r2 KF9/7S真实窗口和已交付边界','source':'原子项learning_result.questions/原帧索引','n':'沿原窗口，不追加分母',
  'supports':['KF9六轮可见528伤/6=88下界','末7血归零帧缺失','毒441/3=147是启动后子窗口','入口/出口资源不同'],
  'missing':['同窗口敌伤完全归属','回血/自伤/复活分账','退场/最终7血伤害','连续Boss完整资源轨迹'],
  'S':None,'deltaS':None,'S_eligible':False,'window_not_interchangeable':True},
 {'kind':'冻结R345 MarginSample计算契约','source':'boss-margin.ts + boss-sim.ts + rollout.ts','n':None,
  'supports':['有合格原始trace时逐样本S及paired deltaS的计算能力','当前入口/准备及终止轮声明','null/unknown/required/trust闸'],
  'missing':['本交付输入没有该版本的合格真实/模拟逐样本归属数据','机制/时序/血药与连续Boss独立校准'],
  'S':None,'deltaS':None,'S_eligible':False,'interface_capability_not_observed_valid_samples':True},
 {'kind':'25项固定算术/缺失数据核验','source':'fixed-offline-validation.json','n':25,
  'supports':['公式按每样本参考及同窗口算','缺失/截断/序列拒收','按ID配对/非补零','均值S与胜率可异序的抽象反例'],
  'missing':['任何游戏策略收益证据'], 'gameEvidence':False}]
write('margin-record-boundary.json',{'at':AT,'formula':'S=(outgoing_target_HP/turns)/entry_boss_HP-(received_enemy_HP/turns)/entry_player_HP',
 'per_sample_then_summary':True,'entry_and_window_and_model_must_match':True,
 'do_not_use_intent_or_capped_hpLoss_or_unrelated_mean_ratios':True,'record_classes':margin,
 'S_vs_win_vs_readiness':'三个不同量；资格含实际合法可达、alive-through-start与全部资源/后继。S均值不证明胜率，符号需无混杂的时序/伤害条件。',
 'next_required_fields':['角色/进阶/决策/SL/实际采用/模型与状态指纹','Boss目标/阶段与入口HP','起始轮及准备/终止窗口','逐轮胜利相关目标有效HP伤','减伤后敌人HP伤与自伤、回血、药水、复活分别记录','连续Boss carryover血药及再次启动','样本身份、完整/截断/缺失与误差分组']})
claims=[
 {'id':'C01','old':'原报告切点2a62/51e0未合入，12冲突。','update':'历史原件仍正确；冻结R345祖先核验两个commit及后续41e406均true，不能把旧未合入切点当现生产状态。',
  'evidence':['旧report.md/result.json','frozen-ancestry.json','core-cycle-quantitative-progress.json'],'ledger_or_experience':['silent-0021/0194/0376/0385'],'next':'沿原ops核现源码，不merge旧分支、不重做接口。'},
 {'id':'C02','old':'单卡首施放/符号齐全可能被误称完整核心启动/通关率。','update':'R2所有核心trace valid0—1000；没有具名弃牌对记录或完整四核心启动。LKC基线步法首施放n375、core valid384/1000，只是条件单卡时点。',
  'evidence':['r2-candidate-evidence.jsonl','core-window.ts','旧54G到手未建原帧'],'ledger_or_experience':['silent-0385/0141','四原核心条目'],'next':'P1保留qualification/start=null；后续取得支付、身份、真实后继、alive-through-start。'},
 {'id':'C03','old':'完成更多旧模型样本/首DPR名次变化可被误当策略提高或生产仍11秒停算。','update':'54/54仅冻结R2参照；26键配对DPR差跨seed变号，2个2SE键是同局同牌一项对比；旧4/27、5/27未改，R345 required闸另行已发布。',
  'evidence':['r2-summary.json','paired-sign-counterexample.json','build-sim-facts.ts:549'],'ledger_or_experience':['silent-0021/0376'],'next':'已完成参照不重跑；独立现模型校准和逐条件决策，不能据均值排序宣实盘收益。'},
 {'id':'C04','old':'hpLoss或意图伤害可以直接当enemyDPR；均值DPR/HP可拼S。','update':'旧raw样本hpLoss70、逐轮loss86且归属缺失；所有778行S保持null。需同样本同窗/入口/目标/分账后才算S与deltaS。',
  'evidence':['raw-model-accounting-witness.json','margin-record-boundary.json','boss-margin批准定义'],'ledger_or_experience':['silent-0463旧校准条目，未修改'],'next':'交061302 R3核真实敌伤/自伤回血/复活及窗口。'},
 {'id':'C05','old':'S符号等于胜负/均值S较大就更好若无条件使用。','update':'恒定速率及正入口HP时可作连续kill-clock条件判断；时序/自伤回血复活另核。抽象反例：均值S0.89且9/10胜，高于S0.02但10/10胜；不是游戏数值或策略建议。',
  'evidence':['fixed-offline-validation.json','boss-margin批准math_boundary','docs/v5-s-decision-plan.md'],'ledger_or_experience':[],'next':'原ops→watcher→Roy转交条件差异；本轮不修改P0实现、知识或代填ACK。'},
 {'id':'C06','old':'Jev token降低27.566%、五题改选/模型排名相合可以证游戏收益。','update':'32分层题/13关联局/144含原样与倒序重复；模型名次非真值。6个并集分歧仅历史首动作完成，0实盘反事实；弃牌pending、未建立毒、药水/随机落点分别保留。',
  'evidence':['jev-summary.json','jev-differences.json','原pilot analysis.json'],'ledger_or_experience':['silent-0194/0376/0385/0141及原四条机制'],'next':'R342已有契约不再实现；P0 Jev-v-code统计由watcher；真实动作校准由原R3 owner。'},
 {'id':'C07','old':'原r2子项completed/固定消费者live读回等于宽P1/P2消化或自然采用。','update':'原V4-R313三题15/15限定经验交付核实且不重开；原明确P1/P2、模型冲突、完整实例/自然效果仍未知。',
  'evidence':['parent-and-limited-child-boundary.json','原r2 final-verification/consumer-receipt'],'ledger_or_experience':['silent-0440','原r2五条限定经验'],'next':'保持子项completed；本轮只把未完字段交现P0/P1/P2与原效果链。'},
 {'id':'C08','old':'旧7e1193固定校准撤可信可以关闭新R345校准或父要求。','update':'旧210输入质量失败/可信限制有范围；冻结新R3回执尚未实际开始，不是新结果。',
  'evidence':['calibration-boundary.json','calibration-pending-receipt.json'],'ledger_or_experience':['silent-0463'],'next':'原owner按R3输入做真实动作校准；本轮不重放/拟合/轮询或替代验收。'}]
write('claim-updates-and-counterexamples.json',{'at':AT,'claims':claims,'knowledge_or_ledger_changed':False,
 'notification_route':'本报告及handoff packet由原ops接收→现watcher核接线/异议→Roy；本轮未写通知ACK或声称已送达。'})
waiting=[
 {'id':'P1-four-core-qualification','state':'waiting','reason':'其余三完整核心及其他弃牌分支缺身份/实付/合法后继/活过启动联合窗口；单卡/符号概率不能替代，R2完整核心启动仍null。'},
 {'id':'P1-nightmare-independent-choices','state':'waiting','reason':'复制对象→下轮副本→费用/来源归属及独立弃牌/保留/复制后继尚未完整；本轮仅保留旧证据和六题pending选择反例。'},
 {'id':'P2-current-model-calibration-and-attribution','state':'waiting','reason':'旧R2无S原始归属，新R345真实敌伤/自伤/回血/复活与准备/终止/连续Boss窗口未收到R3结果；由061302原owner处理。'},
 {'id':'P2-whole-fight-and-sequential-resource-readiness','state':'waiting','reason':'首次真正合法启动/窗口存活、次Boss重启及血药/复活接续缺证；S、胜率和资格分开，不能由不同样本均值合成。'},
 {'id':'P0-ranking-readiness-decision-protocol','state':'owned_elsewhere','reason':'roy-20261014-s-decision/P0由watcher独占；S计算/必需样本/R342替换已发布，本轮不新增这些接口或合旧分支。'},
 {'id':'natural-read-adopt-benefit','state':'waiting','reason':'当前交付只有旧限定live固定读回、R342既有请求契约及pilot历史首动作；没有本轮R345核心资格新自然读取/采用/收益或未选线反事实。'},
 {'id':'unsupported-original-three-questions','state':'waiting','reason':'两题本幕Boss已败而下一Boss未观察，一题原候选无支持数值转移；保留三题原ID/候选，未删或补零。'}]
coverage={k:True for k in ['original_parent_and_consumers','R2_complete_reference_consumed','Jev_shared_role_boundary','boss_margin_attribution','R3_P0_ownership_boundaries','provenance_conflicts_and_handoff']}
write('coverage.json',{'at':AT,'scope':'仅本冻结增量证据/判定边界交付','required_sections':list(coverage),'coverage':coverage,
 'evidence_map':{'original_parent_and_consumers':['parent-and-limited-child-boundary.json','scope-consumer-map.json','frozen-ancestry.json'],
 'R2_complete_reference_consumed':['r2-summary.json','r2-candidate-evidence.jsonl','r2-input-verification.json','paired-sign-counterexample.json'],
 'Jev_shared_role_boundary':['jev-differences.json','jev-input-verification.json','jev-summary.json'],
 'boss_margin_attribution':['margin-record-boundary.json','raw-model-accounting-witness.json','fixed-offline-validation.json'],
 'R3_P0_ownership_boundaries':['calibration-boundary.json','scope-consumer-map.json'],
 'provenance_conflicts_and_handoff':['binding-verification.json','source-comparison.json','additional-input-provenance.json','claim-updates-and-counterexamples.json']},
 'broad_parent_complete':False,'R2_reference_reopened':False,'deck_table_r2_reopened':False,'P0_implemented_here':False,'remaining':waiting})
packet={'at':AT,'request_id':'roy-20261011-silent-core-cycle-quantitative-learning','parent_batch':'20261012-024317-strategy-proposal',
 'supplement_id':'v5-boss-revalidation-20261014-approved-supplement','scope':'后续宽P1/P2角色资格/量化证据消费输入，非业务状态完成或发布ACK',
 'input_manifest_sha256':'090e06674242b78bae2cd18c5017d164f4f554ed9f5b87d244ca4154431e0ff0',
 'version_namespaces':{'original_owner_head':BASE,'current_production':{'commit':sources['frozen_live'],'release':'V5-R345'},
 'R2_reference':'093c68ac658980f53b9940756b3df925adfb49bb','pilot':'jev-1.13.0；历史runs.code=current非精确源码SHA',
 'legacy_calibration':'7e1193cef9467416bc10c8e344a49f4fd98390c7','running_start':'YUWMCVH6MFUH/R344 b0b4d0a+dirty启动记录，不指认为R345读取'},
 'qualification':core,'quantitative_reference':{'questions':30,'supported':27,'unsupported':3,'groups':54,'ID_each':1000,'option_rows':724,'terminal_DPR_n_range':[1000,1000],'core_trace_valid_range':[0,1000],
 'complete_core_start':None,'S':None,'deltaS':None,'model_only':True,'source_artifact':'r2-candidate-evidence.jsonl'},
 'jev_role_boundary_artifact':'jev-differences.json','margin_admission_artifact':'margin-record-boundary.json',
 'calibration_required_input':cal['frozen_pending_receipt']['frozen_input'],'new_R3_received':False,
 'watcher_P0_exclusion':'.worktrees/s-decision-20261014：排序/readiness/英文Jev/决策协议/标量基础设施均不在本轮实现范围',
 'old_new_claim_differences':'claim-updates-and-counterexamples.json','handoff_route':['原ops','原watcher','Roy'],
 'notification_ACK_written':False,'delivered_to_ops_or_watcher':None,'parent_closed':False,'next_step':waiting}
write('p1p2-consumer-input.json',packet)
# Human report is the concrete bounded result; complete does not close the broad parent.
case_lines=[]
for x in diff:
 f=x['models']['full'];c=x['models']['compact_unlabelled']
 case_lines.append('| '+x['case']+' | '+x['run']+' F'+str(x['floor'])+' T'+str(x['turn'])+' | '+x['fresh_jev_choices']['full']+' / '+x['fresh_jev_choices']['full_unlabelled']+' / '+x['fresh_jev_choices']['compact_unlabelled']+' | '+str(f['damage'])+'/'+str(f['block'])+'/'+str(f['hp_loss'])+' → '+str(c['damage'])+'/'+str(c['block'])+'/'+str(c['hp_loss'])+' | '+('; '.join(x['boundaries'][:-1]) or '同角色资格条件重合，完整来源/后继仍缺')+' |')
consumer_lines=['| '+x['stage']+' | '+x['state']+'；'+x['provided']+' | '+x['missing']+' |' for x in consumers]
report=f'''# 原024317量化P1/P2：限定证据接续交付

本轮完成冻结数据的增量消费与判定边界交付，未改变生产源码、知识、台账、main/live或其他owner。宽父项`roy-20261011-silent-core-cycle-quantitative-learning`及P1/P2保持未完成；原核心牌表r2与R2参考阶段的完成范围保留，不重开。此处`outcome=complete`只指本次六项数据交付。

写时先date：{AT}。输出只在`{OUT}`。原工作树HEAD为`{BASE}`；任务同线程01a12c46，parent_batch=20261012-024317-strategy-proposal，补充输入SHA `090e06674242b78bae2cd18c5017d164f4f554ed9f5b87d244ca4154431e0ff0`。开工17项冻结输入SHA/bytes全部一致。末验发现并行owner更新了docs/v5-s-decision-plan.md，其余16项未变；已从main-pull输入指定的264efa2ead498503a46d75ac4b4307f137648ac9原Git blob核取23338字节、SHA77347e1b…完全相同的冻结正文副本，保存在本OUT，不采用新25790字节正文、不改根文件。原漂移、首次末验失败和Git恢复回执分别见final-input-drift.json、verify-delivery-attempt1.stderr、frozen-document-recovery.json；原17项绑定见binding-verification.json。没有新父请求、全历史研究、模拟、LLM/API、游戏重放或账号变更。

## 身份、历史和已有消费者

先读本树README、最新STATE、decision-log末尾、learning-protocol。旧树状态与现生产按提交分开；原2a62/51e0源码、12处共享/源码冲突、失败与原报告没有覆盖。本轮没有merge/cherry-pick/提交。

只读核验发现必须区分历史切点：原报告在8b886744切点为未合入；后续ops已有41e406061fd5b5220867f016797eb488f31449f3限定集成及S1.quantitative2/S1.exp182。冻结R345的Git祖先中2a62f327d508201d9982983ec2c930789065ece5、51e0、41e406均为true。旧“未上线”记录保留原语境，不能当作今天仍未发布或需要合整条旧分支的依据。证据在frozen-ancestry.json及parent-and-limited-child-boundary.json；这些均为只读检查，不是本轮实现/发布回执。

| 数据/源码 | 固定身份 | 可据此断言的范围 |
| --- | --- | --- |
| 原owner树 | 51e0c1f475f842b355172f1f2a6f320cae9fb58d | 原源码/经验及历史失败保留，本轮base |
| 完成R2参照 | 093c68ac658980f53b9940756b3df925adfb49bb | 固定模型/相同策略/相同样本条件的数量与波动，非R345真实精度 |
| 当前发布冻结 | 4437492bb1498181430a5f51ddbafd9d54571aa6，V5-R345 | 现有源码契约；tar SHA df969b6b8bc5649871acbe66e7f2a3e65138a4ce8d77c4049d6bff3357ff0137 |
| 当前进程配置参考 | YUWMCVH6MFUH，b0b4d0a+dirty/R344启动记录 | 启动配置；不证明进程后来读取R345或本轮资格结果 |
| Jev pilot | jev-1.13.0；13局runs.code为current标签 | 原固定请求/回答及已发动作；历史精确源码SHA未知，不冒称R345反事实 |
| 旧校准 | 7e1193cef9467416bc10c8e344a49f4fd98390c7 | 原210输入旧模型结果，不冒称R345的R3 |

tar只抽取14个必要源码/本角色经验文件，逐字节核冻结SHA；没有复制或展开整库，没有保留tar副本。source-comparison.json与old-to-R345-source.patch保存固定提交间Git二进制差异。源码读取不等于真实消费者采用；证据级别在下表分列。

原`roy-20261012-concrete-core-decklists` revision2已完成：核正式result、七份依赖SHA、consumer-receipt SHA `4f0b8033c04c73976ed4552593eb7f9c02280d3cc1eddd9a8327835be3b112bd`及final-verification。V4-R313/730db1e7b0bf2b313a4cb7193d9568f402cba503中3个固定真实构筑题×5条新增文本，15/15 live读回。它是已完成的限定经验消费，不是自然采用/收益，不关闭父P1/P2。未重跑该消费者，未改子项状态或台账。

| 环节 | 已有能力/证据 | 增量未完范围 |
| --- | --- | --- |
{chr(10).join(consumer_lines)}

详细入口及证明类型见scope-consumer-map.json。当前S计算、required完整样本闸、R342 wire替换已存在；不再次实现。P0归watcher独占.worktrees/s-decision-20261014。本报告只交可用角色条件、数值来源和unknown。

## R2完成参照：限定更新

读取原完成索引54份result及30份冻结真实状态包，逐SHA/bytes核验，共84项；没有重抽30题、重跑54组或删除三题。30题仍为27支持/3不支持，两题本幕Boss已败且下一Boss未观察，一题原候选无支持数值转移；原ID、候选、原因在r2-summary.json及原question-coverage保持。

54组各1000共同ID为0—999，seed=7与20261014。ID必须按“题号/seed/id”匹配；同题候选相关，54000题号样本身份不是独立真实对局数。读取724条候选指标和54条baseline，共778条。所有这些旧固定结果恰好无capped/timeUp，终局DPR有效n均1000=win+death；这是实际核出的本批情况，不把“已返回1000”当一般终局DPR分母定义。胜/死、胜局DPR/轮数、HP、药水、费用、paired HP/win/energy均保留其原分母与未知，不用仅胜局均值代替全体。各原摘要meanSe=sd/√n已核，p10/p90保留为模型结果波动，不称实际游戏预测区间。

核心trace valid为0—1000，不随fight完成自动变1000。完整四核心首次启动/资格次数无可用记录，具名杂技+下注弃牌对在这54组也没有记录。可见的first_play_when_played是单卡在完整trace且实际施放子集中的时点：LKC F19 baseline seed7的步法n375、core valid384/1000、均值2.6213、SE0.0600，不是所有1000样本的完整启动时间，更不是最早合法可达或活过启动概率。四签名保持，qualification/first_complete_core_start/null不补符号概率。

362个跨seed候选对中26个paired DPR均值改变符号；其中2个键在各自seed内|均值|>2SE。它们均为a3972427-a5e0-4b04-ac7d-d2069888fd11的card17/card18，两张普通穿刺尖啸且统计完全相同，仅一个具名统计对比；候选键全部保留。seed7差−0.897412，SE0.366073，p10−16.1274/p90 13.3333；repeat差+0.809091，SE0.351486，p10−12.6522/p90 14.1375；各n1000。27题结果的order字段跨seed无变化，其中25题为null；这只核对已存字段，不能证明逐样本击杀顺序相同或排除未记录的后继路径差异。两倍SE仅内部诊断，不是多重比较校正的显著结论或独立两个实盘反例，也不据此认定bug。原帧offset12442913258/bytes52780/SHA68522587…与全部统计保存在paired-sign-counterexample.json。

原R2报告“补全参照首DPR名次变化13项”原样保留，只能说明同冻结模型完成预算后的变化。旧11秒gate为seed7 4/27、repeat 5/27（全30为4/30与5/30），不改写为现在生产停算。R345的required模式已拒绝timeout/样本未齐及无有效终局DPR。原profiler仅4worker固定环境与四项接续的6个阶段；累计fight时间/GC含策略与转移，solver_only_wall为空，不能外推生产24worker或拆成独立solver耗时。原50组跳过、新4组完成历史保持。

## Jev：只消费原pilot与角色资格差异

32分层题/13关联局/144完成请求含三臂、原样重复和倒序探针，不是144个随机胜率样本；本轮新增调用0。原full↔compact 5题改选，三臂并集6题；只对这六题核角色机制/资格边界，另26题只登记原输入和无差异，不重做P0全史标签。16个有唯一模型名次、16个tie/无名次的原分母保留；模型名次不是真值。

原27.566275% token降低和延时差只属于pilot，5题改选不证明省血、胜率或整局收益。原历史latest回答不是同版本随机对照；倒序未同时改引用数组，不能孤立ID偏见。R342正式替换已有冻结一笔input22252/projected58159 bytes vs原102618及既有自然接受回执；不把pilot百分比套到该请求，也不重发144调用。

下表三选择顺序为full / full_unlabelled / compact；数值为full→compact的模型伤/挡/损，均是原题面条件预测。

| 决策ID | 真实角色局/层/回合 | 原pilot选择 | 模型伤/挡/损 | 资格与未知边界 |
| --- | --- | --- | --- | --- |
{chr(10).join(case_lines)}

六题原decisions字节SHA与源offset/bytes全部核过。实际状态精简fingerprint和模型established_before分开；没有把模型毒层/触发/后继当新增独立原帧校准。原四核心与旧L704/KV0/54G/J8/4Y的ledger/经验链接逐题保存。新13局与旧024317的15个证据局无同局交集，仅同角色机制/资格条件重合，不能合并分母。

历史Jev选择、代码候选名次、guard answer/before_sl/after_sl、已发首动作/结果与新arm分列：六题原guard均predicted_candidates/pending_dispatch，actual_turn空；原decision result六题首动作completed并与guard请求相符。这只确认首动作，不能追认整个选中线。guard投影计划前后相同且delta0，不等于实际换手/SL后继相同；仅E5题记attempt2，其余attempt缺失。新compact/unlabelled臂都没有实盘执行，未选线反事实仍未知；完整采用、换手、SL实际后继交原R3输入，不在这里重放。valid_actual_counterfactual_pairs=0。

## S、胜率和最终资格的边界

按批准定义仅在同sample、同Boss/目标、同窗口、合法入口HP、准备及终止轮已计、减伤后敌人HP伤和目标有效HP伤归属明确时逐样本算S，再汇总和按ID配对deltaS。入口参考不能随轮变小；enemyDPR不是意图伤或capped hpLoss；自伤/有效回血/药水/复活与连续Boss资源另核。不同窗口/样本均值不能拼一个分数。

本输入旧R2所有778统计行、所选原raw worker、六个pilot差异和原r2有限实帧均不具备完整S契约，所以S/deltaS均null，可用真实S分母未知，不填0分或0敌伤。R2具名raw样本died、6轮，hpLoss70但lossByTurn合计86、模型最终HP−16；receivedHpDamage/bossMargin不存在。原raw gzip SHA/解压首行offset0、bytes与SHA及worker/题号/seed/deck/order/sample ID保存于raw-model-accounting-witness.json和raw-worker-first-line.txt。这是旧模型字段计量反例，不是新游戏伤害规则；逐轮loss也不能在未分离自伤/回血时当enemyDPR。

原r2真实KF9限定结论复用：全场六轮可见528/6=88下界，最后7血归零帧缺；535/6=89.17仅血池代理，441/3=147仅毒启动后的子窗口。没有同窗敌伤全账，不补S。连续Boss入口/出口/再次准备与血药carryover不同，不能用独立单场均值作整局资格。详细六类记录可用/缺失字段在margin-record-boundary.json。

冻结R345函数已能处理合格trace，本轮只用其boss-margin/quantitative-stats做25项固定离线算术及missing-data核验，不调用simulateFight/LLM/真实动作。覆盖同窗口/入口、ID配对、未匹配不补零、缺伤归属、非正HP、零窗口、截断/timeUp/连续Boss、结果波动与SE、抽象到手非组合、零/全胜小样本非证明等。两个抽象反例分别说明：(a)较高均值S可有较低胜率，0.89且9/10胜对0.02且10/10胜；(b)自伤死亡而敌伤0可令算术S为正，正确unknown标记应拒收。这些数字是合成数学例，不是牌/怪数据或打法阈值。真实上游是否正确分账待独立R3，不能把固定函数通过当机制可信。

S、模拟胜率和核心资格分开。恒定速率/正HP下S符号可作连续时间kill-clock条件关系；真实行动先后、准备、生存、自伤回血复活与变目标没有由公式消失。经验区间和trust需独立校准，不能以算后终局分数当历史预测正确性标签。对docs“符号等于胜负”若被无条件使用的异议及其条件反例交原ops→watcher→Roy；本轮没有改排序/协议/标量源码、经验或代填通知ACK。

## 校准与剩余工作

原061302/01a13753 owner职责保留。已完成旧报告是7e1193固定模型/210输入，包含恶魔样本量达标仍质量不过、F49低可信、未观察进阶限制。新冻结R3在21:47:26回执为prepared_not_dispatched_checkout_busy，learner_received=false/actually_started=false；没有送入当前输入的新R3结果。本轮保存其冻结输入SHA7468ed75…和所需字段，pending是本冻结切点状态，不对活owner轮询或改状态，不重放/拟合，也不拿旧撤可信关闭父要求。

宽未完项逐条见coverage.json.remaining：四核心联合资格/完整计数与真正启动；夜魇与独立选择后继；现模型真实预测-实际及S归属校准；整战/连续Boss血药生存资格；自然读取→采用→收益。P0排序/readiness/英文Jev/决策协议/标量基础设施由watcher独占。三不支持题保持原候选/原因等待支持条件，不能自行删题换分母。

旧观点、新结论/限制、来源、反例、ledger/经验指针、下一触发条件完整保存于claim-updates-and-counterexamples.json。原ledger-0021/0194/0376/0385、r2-0440与旧校准0463仅只读引用，本轮台账/经验/提案不写、不新建ID、不标implemented/shipped。准备p1p2-consumer-input.json供原ops转现watcher及Roy；是否送达/ACK保持null/false，不代填。完整核心不能算的状态在后续题面继续unknown，不将它当没有能力或必死。

## 离线核验与最终口径

audit_r2/jev/boundaries脚本均实际exit0，25项固定算术通过；boundary首次字段名称不匹配KeyError保留，修正只在本OUT。一次沙箱启动前glob扫描因另一owner临时Git目录消失失败，同只读命令重试成功；apply_patch一次未写入，用授权OUT内shell写文件成功，均留environment-failures.txt。不把这些当生产源码失败或成功测试。

没有生产修改，不重复整套测试、撤源码检查或造版本/合入：tests={{tsc:null,vitest:null,cases:null}}，fixes=[]，merged=null，code_proposals=[]，implementation_domains=[]。旧3035测试属于旧报告，不复报为本轮测试。最后独立核原HEAD/工作树清洁与17项冻结字节（16根输入+1实核Git恢复副本），明确保留根文档漂移，结果在final-verification.json；本轮输出与必要副本约数MiB，未展开整库。报告/outcome仅完成本限定证据包，broad_parent_complete=false；下一步由原ops消费本包、现watcher按自己P0/P1/P2职责接线、原R3 owner提供真实动作校准，原效果链再核自然采用与收益。
'''
(OUT/'report.md').write_text(report)
# The full input hashes are indexed once; report JSON links that index instead of copying heavy files.
runs=sorted({x['run'] for x in r2['groups']}|set(load('pilot-run-identities.json')))
result={'task':'strategy-proposal','character':'silent','batch':'20261014-215252-strategy-proposal','request_id':'roy-20261011-silent-core-cycle-quantitative-learning',
 'base':BASE,'runs':runs,'fixes':[],'skipped':waiting,'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},
 'code_proposals':[],'implementation_domains':[],'report':str(OUT/'report.md'),'parent_complete':False,
 'continuation_result':{'supplement_id':'v5-boss-revalidation-20261014-approved-supplement','parent_batch':'20261012-024317-strategy-proposal',
 'phase':'quantitative-P1-P2','input_manifest_sha256':'090e06674242b78bae2cd18c5017d164f4f554ed9f5b87d244ca4154431e0ff0',
 'outcome':'complete','completion_scope':'仅本次冻结证据与判定边界交付；不关闭宽父项/P1/P2/R3/P0','coverage':coverage,
 'inputs':[meta(OUT/'approved-input.json'),meta(OUT/'binding-verification.json'),meta(OUT/'frozen-inputs/docs/v5-s-decision-plan.md')],
 'results':[meta(OUT/n) for n in ['report.md','coverage.json','p1p2-consumer-input.json','claim-updates-and-counterexamples.json','offline-check-receipt.json','final-input-drift.json','frozen-document-recovery.json']],
 'checkpoint':'54旧完成参考组/724候选+54baseline已核；32题144旧Jev调用仅消费、六个角色边界差异；S与完整核心资格保持null；旧r2子项completed；未改生产；R3新结果未收到。',
 'next_step':'原ops将p1p2-consumer-input.json与异议转现watcher/Roy；watcher独占P0，原061302 owner完成独立真实动作R3校准，再沿原效果链核自然读取/采用/收益；不重跑完成R2/Jev，不merge旧分支。'}}
write('report.json',result)
print(json.dumps({'bounded_outcome':'complete','parent_complete':False,'report':str(OUT/'report.md'),'report_json':str(OUT/'report.json'),'covered_sections':len(coverage),'frozen_runs':len(runs)},ensure_ascii=False))

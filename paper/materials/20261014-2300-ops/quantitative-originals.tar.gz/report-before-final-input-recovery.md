# 原024317量化P1/P2：限定证据接续交付

本轮完成冻结数据的增量消费与判定边界交付，未改变生产源码、知识、台账、main/live或其他owner。宽父项`roy-20261011-silent-core-cycle-quantitative-learning`及P1/P2保持未完成；原核心牌表r2与R2参考阶段的完成范围保留，不重开。此处`outcome=complete`只指本次六项数据交付。

写时先date：2026-10-14 22:46:19 CST。输出只在`/home/dw/Projects/agent-sts2/learner/runs/20261014-215252-strategy-proposal`。原工作树HEAD为`51e0c1f475f842b355172f1f2a6f320cae9fb58d`；任务同线程01a12c46，parent_batch=20261012-024317-strategy-proposal，补充输入SHA `090e06674242b78bae2cd18c5017d164f4f554ed9f5b87d244ca4154431e0ff0`。17项冻结输入SHA/bytes全部一致，见binding-verification.json。没有新父请求、全历史研究、模拟、LLM/API、游戏重放或账号变更。

## 身份、历史和已有消费者

先读本树README、最新STATE、decision-log末尾、learning-protocol。旧树状态与现生产按提交分开；原2a62/51e0源码、12处共享/源码冲突、失败与原报告没有覆盖。本轮没有merge/cherry-pick/提交。

只读核验发现必须区分历史切点：原报告在8b886744切点为未合入；后续ops已有41e406061fd5b5220867f016797eb488f31449f3限定集成及S1.quantitative2/S1.exp182。冻结R345的Git祖先中2a62f327d508201d9982983ec2c930789065ece5、51e0、41e406均为true。旧“未上线”记录保留原语境，不能当作今天仍未发布或需要合整条旧分支的依据。证据在frozen-ancestry.json及parent-and-limited-child-boundary.json；这些均为只读检查，不是本轮实现/发布回执。

| 数据/源码 | 固定身份 | 可据此断言的范围 |
| --- | --- | --- |
| 原owner树 | 51e0c1f475f842b355172f1f2a6f320cae9fb58d | 原源码/经验及历史失败保留，本轮base |
| 完成R2参照 | 093c68ac658980f53b9940756b3df925adfb49bb | 固定模型/相同策略/相同样本条件的数量与波动，非R345真实精度 |
| 当前发布冻结 | 4437492bb1498181430a5f51ddbafd9d54571aa6，V5-R345 | 现有源码契约；tar SHA df969b6b8bc5649871acbe66e7f2a3e65138a4ce8d77c4049d6bff3357ff0137 |
| 当前进程配置参考 | YUWMCVH6MFUH，b0b4d0a+dirty/R344启动记录 | 启动配置；不证明进程后来读取R345或本轮资格结果 |
| Jev pilot | jev-1.13.0；13局runs.code为current标签 | 原固定请求/回答及已发动作；历史精确源码SHA未知，不冒称R345反事实 |
| 旧校准 | 7e1193cef9467416bc10c8e344a49f4fd98390c7 | 原210输入旧模型结果，不冒称R345的R3 |

tar只抽取14个必要源码/本角色经验文件，逐字节核冻结SHA；没有复制或展开整库，没有保留tar副本。source-comparison.json与old-to-R345-source.patch保存固定提交间Git二进制差异。源码读取不等于真实消费者采用；证据级别在下表分列。

原`roy-20261012-concrete-core-decklists` revision2已完成：核正式result、七份依赖SHA、consumer-receipt SHA `4f0b8033c04c73976ed4552593eb7f9c02280d3cc1eddd9a8327835be3b112bd`及final-verification。V4-R313/730db1e7b0bf2b313a4cb7193d9568f402cba503中3个固定真实构筑题×5条新增文本，15/15 live读回。它是已完成的限定经验消费，不是自然采用/收益，不关闭父P1/P2。未重跑该消费者，未改子项状态或台账。

| 环节 | 已有能力/证据 | 增量未完范围 |
| --- | --- | --- |
| 战斗/回合/已变状态重规划 | 已存在；required B2完整配对闸；当前线realization与whole_fight_sim/boss_relative_margin随原候选进入facts | 原四套联合资格/最早可达启动；本轮没有R345新自然读取/整回合采用证据 |
| 出牌/药水/弃牌/保留/复制对象 | 部分已存在；合法前缀费用、手动/重放、已建/拟建、未知选择分账；仅具名弃牌分支可计 | 未选线实际反事实、独立弃牌/保留/复制后继、夜魇来源归属、完整后缀与药水实际校准 |
| 结束回合/SL | 原保护及未知边界保留；原guard前/后SL预测与请求可分列；低样本、unknown不可直接当必死 | 这不是SL后真实执行链；本轮不提取真实换手/SL后继、不修SL或必死规则 |
| 拿/跳/买/删/升级/变换/事件 | 已存在有限条件模拟；required完整目标样本/有效终局DPR闸、同ID配对；低可信S禁止排序 | 候选的真实核心资格、完整资源/价格路径、现模型独立校准、P2语义排序；watcher拥有新排序实现 |
| 路线/休息/战前/后续Boss | 已有构筑入口；连续资格未支持；跨Boss模拟/血药已有入口；连续多Boss S及全链组合未知保留 | 两个Boss分别启动、准备轮、carryover血药/复活成本与全局生存资格；不由独立均值拼接 |
| S/deltaS | R345已发布计算接口；同窗口/每样本入口参考的S，按ID配对；截断、未知、序列保留null；叠加原信任闸 | 提供的旧R2及pilot记录没有合格的S原始归属窗口；现模型真实敌伤/自伤/回血/复活校准pending |
| Jev wire请求 | R342替换已发布；替换完整中间轨迹，保留有序候选、必要结果、分母/闸/unknown；完整审计仍保留 | 32题pilot不证收益；R342真实自然请求接受不等于宽量化模型已校准；P0协议改动由watcher独占 |
| 经验消费者 | 原牌表r2限定子项completed；3固定真实构筑题×5新增文本，15/15 live前缀读回 | 不证明自然采用/胜率或本轮R345请求已读回；宽P1/P2继续 |
| 预测/实际校准及自然效果 | 部分旧交付，当前R3 pending；旧限定首动作匹配；旧210输入固定模型校准报告；新R3冻结输入需求 | 新真实动作及窗口配对、偏差/MAE/覆盖率、自然读取→采用→收益；本轮不等待事件、不拟合 |

详细入口及证明类型见scope-consumer-map.json。当前S计算、required完整样本闸、R342 wire替换已存在；不再次实现。P0归watcher独占.worktrees/s-decision-20261014。本报告只交可用角色条件、数值来源和unknown。

## R2完成参照：限定更新

读取原完成索引54份result及30份冻结真实状态包，逐SHA/bytes核验，共84项；没有重抽30题、重跑54组或删除三题。30题仍为27支持/3不支持，两题本幕Boss已败且下一Boss未观察，一题原候选无支持数值转移；原ID、候选、原因在r2-summary.json及原question-coverage保持。

54组各1000共同ID为0—999，seed=7与20261014。ID必须按“题号/seed/id”匹配；同题候选相关，54000题号样本身份不是独立真实对局数。读取724条候选指标和54条baseline，共778条。所有这些旧固定结果恰好无capped/timeUp，终局DPR有效n均1000=win+death；这是实际核出的本批情况，不把“已返回1000”当一般终局DPR分母定义。胜/死、胜局DPR/轮数、HP、药水、费用、paired HP/win/energy均保留其原分母与未知，不用仅胜局均值代替全体。各原摘要meanSe=sd/√n已核，p10/p90保留为模型结果波动，不称实际游戏预测区间。

核心trace valid为0—1000，不随fight完成自动变1000。完整四核心首次启动/资格次数无可用记录，具名杂技+下注弃牌对在这54组也没有记录。可见的first_play_when_played是单卡在完整trace且实际施放子集中的时点：LKC F19 baseline seed7的步法n375、core valid384/1000、均值2.6213、SE0.0600，不是所有1000样本的完整启动时间，更不是最早合法可达或活过启动概率。四签名保持，qualification/first_complete_core_start/null不补符号概率。

362个跨seed候选对中26个paired DPR均值改变符号；其中2个键在各自seed内|均值|>2SE。它们均为a3972427-a5e0-4b04-ac7d-d2069888fd11的card17/card18，两张普通穿刺尖啸且统计完全相同，仅一个具名统计对比；候选键全部保留。seed7差−0.897412，SE0.366073，p10−16.1274/p90 13.3333；repeat差+0.809091，SE0.351486，p10−12.6522/p90 14.1375；各n1000。27题结果的order字段跨seed无变化，其中25题为null；这只核对已存字段，不能证明逐样本击杀顺序相同或排除未记录的后继路径差异。两倍SE仅内部诊断，不是多重比较校正的显著结论或独立两个实盘反例，也不据此认定bug。原帧offset12442913258/bytes52780/SHA68522587…与全部统计保存在paired-sign-counterexample.json。

原R2报告“补全参照首DPR名次变化13项”原样保留，只能说明同冻结模型完成预算后的变化。旧11秒gate为seed7 4/27、repeat 5/27（全30为4/30与5/30），不改写为现在生产停算。R345的required模式已拒绝timeout/样本未齐及无有效终局DPR。原profiler仅4worker固定环境与四项接续的6个阶段；累计fight时间/GC含策略与转移，solver_only_wall为空，不能外推生产24worker或拆成独立solver耗时。原50组跳过、新4组完成历史保持。

## Jev：只消费原pilot与角色资格差异

32分层题/13关联局/144完成请求含三臂、原样重复和倒序探针，不是144个随机胜率样本；本轮新增调用0。原full↔compact 5题改选，三臂并集6题；只对这六题核角色机制/资格边界，另26题只登记原输入和无差异，不重做P0全史标签。16个有唯一模型名次、16个tie/无名次的原分母保留；模型名次不是真值。

原27.566275% token降低和延时差只属于pilot，5题改选不证明省血、胜率或整局收益。原历史latest回答不是同版本随机对照；倒序未同时改引用数组，不能孤立ID偏见。R342正式替换已有冻结一笔input22252/projected58159 bytes vs原102618及既有自然接受回执；不把pilot百分比套到该请求，也不重发144调用。

下表三选择顺序为full / full_unlabelled / compact；数值为full→compact的模型伤/挡/损，均是原题面条件预测。

| 决策ID | 真实角色局/层/回合 | 原pilot选择 | 模型伤/挡/损 | 资格与未知边界 |
| --- | --- | --- | --- | --- |
| 203cd3a9-945c-4800-a314-e2e94276a890 | E5L15SK6ZHZB F17 T5 | plan3 / plan1 / plan1 | 2/17/0 → 1/17/0 | 同角色资格条件重合，完整来源/后继仍缺 |
| 9d343a2e-a549-447d-a284-3ea9e36178e1 | 4U3WNL3JRRCX F17 T7 | plan6 / plan1 / plan1 | 21/5/15 → 27/5/15 | 同角色资格条件重合，完整来源/后继仍缺 |
| 2bd4d5d2-9fd7-46b2-aa4d-908723a8909a | EBVT8UZM6P12 F43 T3 | plan5 / plan5 / plan1 | 30/11/7 → 45/11/7 | 触媒拟建立时已有目标毒为0；NOXIOUS_FUMES仍在手不等已施放/输出兑现; 比较涉及药水消耗；不由伤害差单项判改善 |
| ab50ed9e-dcc2-4831-98cb-1c34b80f406d | 6ZGMGEQ5YDVK F9 T3 | plan1 / plan1 / plan3 | 0/12/0 → 0/9/3 | complete_line可以为true且后继选择仍pending；不得只用complete_line判完整资格，保留unknown/选择链 |
| 2eed3336-00c1-4dd0-a560-6626020587d5 | 1269Y20SKHUM F45 T1 | plan11 / plan5 / plan11 | 49/8/0 → 49/8/0 | 锁镰落点未展开；条件伤/损/击杀不是保证，不能作独立真值 |
| 170de71d-8ac5-407f-b7d6-4b65d321a5d7 | LKC9YXKZWTKR F12 T2 | plan5 / plan1 / plan1 | 3/8/1 → 20/8/1 | complete_line可以为true且后继选择仍pending；不得只用complete_line判完整资格，保留unknown/选择链 |

六题原decisions字节SHA与源offset/bytes全部核过。实际状态精简fingerprint和模型established_before分开；没有把模型毒层/触发/后继当新增独立原帧校准。原四核心与旧L704/KV0/54G/J8/4Y的ledger/经验链接逐题保存。新13局与旧024317的15个证据局无同局交集，仅同角色机制/资格条件重合，不能合并分母。

历史Jev选择、代码候选名次、guard answer/before_sl/after_sl、已发首动作/结果与新arm分列：六题原guard均predicted_candidates/pending_dispatch，actual_turn空；原decision result六题首动作completed并与guard请求相符。这只确认首动作，不能追认整个选中线。guard投影计划前后相同且delta0，不等于实际换手/SL后继相同；仅E5题记attempt2，其余attempt缺失。新compact/unlabelled臂都没有实盘执行，未选线反事实仍未知；完整采用、换手、SL实际后继交原R3输入，不在这里重放。valid_actual_counterfactual_pairs=0。

## S、胜率和最终资格的边界

按批准定义仅在同sample、同Boss/目标、同窗口、合法入口HP、准备及终止轮已计、减伤后敌人HP伤和目标有效HP伤归属明确时逐样本算S，再汇总和按ID配对deltaS。入口参考不能随轮变小；enemyDPR不是意图伤或capped hpLoss；自伤/有效回血/药水/复活与连续Boss资源另核。不同窗口/样本均值不能拼一个分数。

本输入旧R2所有778统计行、所选原raw worker、六个pilot差异和原r2有限实帧均不具备完整S契约，所以S/deltaS均null，可用真实S分母未知，不填0分或0敌伤。R2具名raw样本died、6轮，hpLoss70但lossByTurn合计86、模型最终HP−16；receivedHpDamage/bossMargin不存在。原raw gzip SHA/解压首行offset0、bytes与SHA及worker/题号/seed/deck/order/sample ID保存于raw-model-accounting-witness.json和raw-worker-first-line.txt。这是旧模型字段计量反例，不是新游戏伤害规则；逐轮loss也不能在未分离自伤/回血时当enemyDPR。

原r2真实KF9限定结论复用：全场六轮可见528/6=88下界，最后7血归零帧缺；535/6=89.17仅血池代理，441/3=147仅毒启动后的子窗口。没有同窗敌伤全账，不补S。连续Boss入口/出口/再次准备与血药carryover不同，不能用独立单场均值作整局资格。详细六类记录可用/缺失字段在margin-record-boundary.json。

冻结R345函数已能处理合格trace，本轮只用其boss-margin/quantitative-stats做25项固定离线算术及missing-data核验，不调用simulateFight/LLM/真实动作。覆盖同窗口/入口、ID配对、未匹配不补零、缺伤归属、非正HP、零窗口、截断/timeUp/连续Boss、结果波动与SE、抽象到手非组合、零/全胜小样本非证明等。两个抽象反例分别说明：(a)较高均值S可有较低胜率，0.89且9/10胜对0.02且10/10胜；(b)自伤死亡而敌伤0可令算术S为正，正确unknown标记应拒收。这些数字是合成数学例，不是牌/怪数据或打法阈值。真实上游是否正确分账待独立R3，不能把固定函数通过当机制可信。

S、模拟胜率和核心资格分开。恒定速率/正HP下S符号可作连续时间kill-clock条件关系；真实行动先后、准备、生存、自伤回血复活与变目标没有由公式消失。经验区间和trust需独立校准，不能以算后终局分数当历史预测正确性标签。对docs“符号等于胜负”若被无条件使用的异议及其条件反例交原ops→watcher→Roy；本轮没有改排序/协议/标量源码、经验或代填通知ACK。

## 校准与剩余工作

原061302/01a13753 owner职责保留。已完成旧报告是7e1193固定模型/210输入，包含恶魔样本量达标仍质量不过、F49低可信、未观察进阶限制。新冻结R3在21:47:26回执为prepared_not_dispatched_checkout_busy，learner_received=false/actually_started=false；没有送入当前输入的新R3结果。本轮保存其冻结输入SHA7468ed75…和所需字段，pending是本冻结切点状态，不对活owner轮询或改状态，不重放/拟合，也不拿旧撤可信关闭父要求。

宽未完项逐条见coverage.json.remaining：四核心联合资格/完整计数与真正启动；夜魇与独立选择后继；现模型真实预测-实际及S归属校准；整战/连续Boss血药生存资格；自然读取→采用→收益。P0排序/readiness/英文Jev/决策协议/标量基础设施由watcher独占。三不支持题保持原候选/原因等待支持条件，不能自行删题换分母。

旧观点、新结论/限制、来源、反例、ledger/经验指针、下一触发条件完整保存于claim-updates-and-counterexamples.json。原ledger-0021/0194/0376/0385、r2-0440与旧校准0463仅只读引用，本轮台账/经验/提案不写、不新建ID、不标implemented/shipped。准备p1p2-consumer-input.json供原ops转现watcher及Roy；是否送达/ACK保持null/false，不代填。完整核心不能算的状态在后续题面继续unknown，不将它当没有能力或必死。

## 离线核验与最终口径

audit_r2/jev/boundaries脚本均实际exit0，25项固定算术通过；boundary首次字段名称不匹配KeyError保留，修正只在本OUT。一次沙箱启动前glob扫描因另一owner临时Git目录消失失败，同只读命令重试成功；apply_patch一次未写入，用授权OUT内shell写文件成功，均留environment-failures.txt。不把这些当生产源码失败或成功测试。

没有生产修改，不重复整套测试、撤源码检查或造版本/合入：tests={tsc:null,vitest:null,cases:null}，fixes=[]，merged=null，code_proposals=[]，implementation_domains=[]。旧3035测试属于旧报告，不复报为本轮测试。最后独立核原HEAD/工作树清洁与17输入SHA，结果在final-verification.json；本轮输出与必要副本约数MiB，未展开整库。报告/outcome仅完成本限定证据包，broad_parent_complete=false；下一步由原ops消费本包、现watcher按自己P0/P1/P2职责接线、原R3 owner提供真实动作校准，原效果链再核自然采用与收益。

# 静默A10纸鹤：校准已观察的新施虚弱当轮伤害

来源／实现任务：strategy-proposal，批次20261014-214302-strategy-proposal；基线264efa2ead498503a46d75ac4b4307f137648ac9。沿原提案silent-proposal-60a60ac13fdaf5fe、账本silent-0469与既有silent-0070，不另建重复提案、不扩展队列。原提案Markdown SHA256为06be2d2be326ea02a03c2f8ec0f87b817fc1ca136267b09e4ef11ea437129972，原文保留。

## 证据与复核

十个派发锚点均在runs.jsonl为SILENT A10；只对EBVT8UZM6P12 F43 T1做本项机制校准。共用extract_evidence.py冻结十局七个流；每行保留source_size、offset、bytes、SHA与显式身份。原复盘索引仅定位，本次重新seek原日志逐字节核18条（16state、2decision），与共用抽取结果完全相同，见paper-krane-cross-verification.json。

首试d387957（decision_id=eb00b014-b0ca-43f7-991a-3f28ec4619c5）plan7：背刺→连枷、幻影之刃+、打击→连枷、中和+→连枷、防御、萎靡X2→魔法；s399969—399976。中和前连枷17→施弱后10；魔法7经减2力量／施弱后3，合13对5挡，41→33失8，旧候选报10。

末试d387990（decision_id=5300a7b9-ff57-4bcd-8c65-c89992926673）plan8：背刺→幽灵、幻影之刃+、打击→幽灵、蛇咬→幽灵、萎靡X1→连枷、中和+→幽灵；s400002—400009。连枷17经减1力量／施弱后9，魔法7，41→25失16，旧候选报19。纸鹤现场说明为虚弱减40%而非25%；与floor(17×0.6)=10、floor((17−1)×0.6)=9、floor((7−2)×0.6)=3一致。两试属于一局，不算两独立样本。

## 旧规则、新行为和边界

旧实现对enemy.newlyWeak一律乘0.75，纸鹤只有抽牌不精确保护表识别。本项接入当前现场未熔化PAPER_KRANE、静默A10、中和+原4伤／2弱或普通萎靡X1/X2原模板，并绑定本次已观察连枷RAM_MOVE单击17、魔法POWER_SHIELD_MOVE单击7及原仅易伤的起始敌能力。

只在同一决策回合、单次手动施弱、敌初始无虚弱、对应已证力量差／弱层数、无易伤／包围／无实体／缩小／巨像／暂减力／污染／换招交互时乘0.6。记录施弱来源；已显示虚弱意图不重复缩放；下一模拟回合清除本次认证。没有证据的来源、动作、升级萎靡、重放、其他角色和进阶保留旧路径。本项不设新药价、SL或终局权重。

## 反例、未知与选题处置

已弱后的s399973／399975使用现场10/3，不能再次乘0.6。其他Weak卡、升级／重放／自动施放、已有Weak叠减力、未观测招式及多击不由本证据推广。另一候选silent-proposal-cae7ed8545a65c66（QRZX F23T1，0474/0475/0294）只有满槽炼制净收纳0且未来消耗收益未知；本批不据此把未知技能总价值5直接归零，保留待证。

## 验证、预期影响与回退

固定八帧来自原18条已核证据；测试完全屏蔽生成知识读取，不联网、不调用模型。首试作为实现夹具、末试作为同局复核，保留预测前后及真实HP分账，不作为独立留出。测试覆盖完整六步8/16失血、伤害／药成本等价、原已弱意图读回、无遗物／熔化／未知状态、非Silent／A9/A11、换招／多击／未知能力与未证交互的旧路径，及共享终局求解和live least-loss消费者。17HP边界和后继toy rollout是工程反事实，不能冒作实际获救或全战校准。

先保存四份原源码.txt，再撤回全部四源码运行新固定测试，必须失败；恢复修改后通过。每次代码提交前跑agent/tools/test-sandbox.sh，gitleaks扫精确提交内容；live锁中查刷新知识与源码重叠、合后沙箱验证。本报告将补真实退出码／提交／合入／编号，不预写成功。

预期消除本次两条已执行线2/3血的高报，可能影响当前候选／必死判断；未证明自然采用、省血或胜率收益。回退仅git revert本项源码提交，保留原提案、账本、日志和并行代码。授权Roy-2026-10-07-learning；实际上线后按要求双收件箱记录，由ops核版本与shipped。

## 本次已完成的验证

原执行另外按本批decisions冻结副本重读16条（两试各6张牌＋结束共14条，另两条下轮动作），均completed，未将首步成功冒称整线执行。见paper-krane-execution.evidence.json。

撤回四源码：paper-krane-source-removed.log退出1，4失败／10通过；恢复后paper-krane-restored.log退出0，14通过。原第一次5失败／9通过及修正后14通过均保留。共享终局16失血／17HP合成边界存在1HP生存线，旧路径全部死亡；live planner因此不再报combat/least-loss，原无纸鹤对照仍报least-loss，未改SL阈值。这是消费者工程读回，不是自然获救对局。

源码gitleaks stdin扫描全部六个staged叶的二进制diff，退出0，无泄漏；完整沙箱检查尚在执行，不借本局夹具绿当整套成功。

## 最终实际结果

源码已单独提交：`0f86964c80c63bb0d26c64bad94b6f639fb561d2`，父提交／报告基线仍`264efa2ead498503a46d75ac4b4307f137648ac9`；六源码／夹具叶，无知识修改。原全局Git身份，Co-Authored-By: Codex GPT-6。本工作树最终干净；source-precommit-readback、source.patch和源commit均可逐Git blob读回。

完整沙箱重跑实际退出0，tsc0；401文件3883项过＋paths 1文件11项过，共402文件3894项。单线程耗时1401.57秒＋2.54秒，首轮406.63秒的1超时／3882通过完整保留，不降生产预算／断言、不借历史绿。固定红绿为撤源退出1／4失败10过，恢复退出0／14过。JSON tests.cases=14指新固定测试数量，sandbox_cases=3894指本次完整沙箱通过总数。

已在ops/live-merge.lock内等待知识builder并重新核现场：live实际`18762ef80909373259ef283cdac2813f3be90cca`，知识刷新已经由其他正常操作提交，本轮只有notes/fight-value-backtest-silent.md与notes/monster-db-check.md未提交，未暂存或覆盖它们；本补丁六叶无dirty重叠。按实际merge-base `6db27908cc3d39e4567eeb589f5541adfd9eb0ea`额外检查继承main的所有差异，merge-tree预检无knowledge冲突。

实际`git merge --no-edit 0f86964c80c63bb0d26c64bad94b6f639fb561d2`退出1，7冲突：agent/src/reflex/card-model.ts、notes/fix-queue-v4.md、notes/for-roy.md、ops/inbox-dev.md、paper/materials/20261014-v5-boss-revalidation/ops-binding.json、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl。未解冲突或挑选覆盖并行记录。已保存live-merge.log、live-merge-preflight.log、live-merge-conflict-index.txt与live-merge-conflict.patch；`git merge --abort`退出0，live HEAD恢复到合前18762ef，原两条dirty笔记仍保持。

本源码不是实际live祖先，最终proposal_results对原60a60ac为waiting：缺的是运维集成／live祖先、合后沙箱及发布回执，非本项已证窗口缺数据。没有合后测试、eval版本、正式release_id、上线decision-log或双实际上线通知；没有标implemented／shipped。0469经CLI仅登记proposed与本源码／报告链接，交ops沿原source集成，不重复新id。未运行play、不停局、不推送、不读key／env／游戏二进制。所有原失败／初稿／证据与本工作树保留。

完整机器回报保存在result.json，proposal.md与report.md均是任务规定的真实根scratch路径；本批不是纯研究，不填写research_complete。后续实际合入后才能发布编号／通知Roy与登记shipped；自然消费者采用／省血／通关收益仍另验。

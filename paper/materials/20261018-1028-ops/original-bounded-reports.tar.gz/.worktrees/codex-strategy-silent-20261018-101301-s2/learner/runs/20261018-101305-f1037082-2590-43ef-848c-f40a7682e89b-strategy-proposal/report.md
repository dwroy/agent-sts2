# 静默猎手策略提案复核报告

本批十项已领取原提案全部保留 waiting。部分窄子项早已在 live 实现，但整项剩余主张缺完整执行归属、条件化后继或可区分的整战对照。本批没有新增源码、经验条目、提交、合入或游戏版本。

批次：20261018-101301-s2-strategy-proposal。角色：silent。任务：strategy-proposal。
完整base：`e8e9c5753240fcd9ce203bcf1529c6dd8a9c7dc0`。开工工作树干净，普通队列身份匹配后执行 git merge --no-edit main，返回 Already up to date；HEAD保持该base。
本次只读观察 live：`b155d00a36080418149e63d2f21b491d34d7f40a`；它不是本批merged值。仅冻结所需13个源码叶，base/live三叶有差异，均保存原blob及原字节，不冒称整仓等价或当前脏树是旧运行源码。
派发身份见 dispatch.json；旧deck-size专题仍绑定另一批次，未读取其work_spec/manifest或套用纯研究完成口径。没有派子agent、联网、模型调用、play或改运维prompt。

## 证据覆盖

| 局号 | 进阶 | 结果/层 | 状态 | 决策 | SL摘要 |
|---|---:|---|---:|---:|---:|
| 10GPK5XGHCK3 | A3 | 胜/F48 | 1020 | 986 | 4 |
| 1LMBFGSMCWKU | A4 | 胜/F48 | 689 | 663 | 3 |
| 9YT51CK8RC39 | A7 | 败/F17 | 566 | 558 | 6 |
| 25226ZFLNR1J | A10 | 败/F48 | 889 | 862 | 9 |
| TCFAHJ9K19VY | A10 | 败/F17 | 489 | 476 | 6 |
| ULP4TN1GNHMK | A10 | 败/F17 | 493 | 484 | 6 |
| 61E2QS63Y9WU | A10 | 败/F28 | 462 | 443 | 7 |
| ZTRGYYMLR8SC | A10 | 败/F17 | 607 | 594 | 6 |
| K2JAGKVJAWZJ | A10 | 败/F46 | 814 | 722 | 3 |
| 79UCJ0K6R9C1 | A10 | 败/F14 | 243 | 235 | 0 |

角色由runs.jsonl逐局核为SILENT，状态帧逐条核角色和进阶；两场低阶胜利不混入A10分母。这些均是旧证据复核，不是新增十局前瞻支持；原运行代码均带dirty且没有完整dirty快照。

| 流 | 本批记录 | source_size |
|---|---:|---:|
| states | 6272 | 14284954858 |
| decisions | 6023 | 2497501331 |
| sl-attempts | 50 | 47706736 |
| run-config | 10 | 2074501 |
| run-plans | 44 | 9272480 |
| brain | 293 | 806135548 |
| runs | 10 | 371605 |
| fight-plans | 0 | 2233957 |

共12,702条原字节逐offset/bytes/SHA256/JSON/显式身份核回，输出SHA、计数与截点核同，结果见 byte-verification.json。run-plans使用run字段；不以正文提及当归属。states、decisions、brain的全源各2条坏行不能归本批；fight-plans此截点0条仅是选取结果，不据此宣称原日志缺失。没有覆盖旧截点报告或零行初稿。
十局资源链得到162个观察窗口；保留已赢战的血价、missing_exit及restart_observed，不将SL恢复算治疗或新获药水，不把净血差作敌伤。116条药水使用/丢弃请求逐一保留接口结果与前后端点，不能自动归因完整候选。

## 关键结论与限制

- K2JAGKVJAWZJ F27T2：d286123，s292788→292789；HP57、格挡0→0、覆甲0→7。原c64稿16挡错误，按原9c3更正稿使用0；两个原稿均保留，没有改写历史。
- K2 F46T1：s293158→293159能量1→0、格挡16→16；T6普通蜃景s293196→293197格挡10→20，其正收益是整类归零的反例。零毒升级窄实现的实际live祖先为5e0f884586521220d451b717c29b99e7876d6244。
- K2 F33T10：毒42→48、敌HP54不变，紧接s292942重开恢复62血与原瓶；第二试原瓶保留且胜28血。79UCJ0K6R9C1 F14T11：毒4→10、敌8血不变，三感染先耗7挡与2血后死亡，末态仍8血10毒。两处只支持各自已观察组合的即时加毒，不提供通用药效、饮药时机或完整后继已校准的证明。
- 79 F14T3 d286684：空过与攻击/施毒选项都显示5轮8样本0实赢，空过约76%来自尾端估计，未执行替线缺实结。T6四感染与敌20攻合损32、T10两感染及两次9攻合损11、T11先死的原帧均保留；不据此调权或禁止空过。
- ZTRGYYMLR8SC F17末T14：s292398→292399弃牌后神官64→61，原投掷匕首直伤此前73→64，随后中和至58；两防御各3合6、4血最终0。局部附伤可以分账，不能由此定所有随机目标/减损/击杀组合。六试入口68/70和原两瓶复用，未当六独立局。
- K2 F33两试多动作共同改变，首29抽相同不能隔离目标或留药胜因。F46以86/91及两药入场仍败，不支持统一高血安全线或固定杀序。K2 T7额外2伤保持未隔离。
本批没有复算原提案所引107次铜钹、全史铁心/毒药水或124局等宽统计；这些只保留原提案出处，不算本批新增分母。所需新增证据详列逐项waiting理由；局部机制是否值得后续独立窄化，应在原提案下补足范围和固定消费者校准，不新造重复id。

## 离线消费者追踪

| 局号 | 动作数 | 计划段 | 相邻可关联区间 | 保留轮窗口 | 排除元记录 |
|---|---:|---:|---:|---:|---:|
| ZTRGYYMLR8SC | 594 | 130 | 388 | 108 | 0 |
| K2JAGKVJAWZJ | 720 | 138 | 138 | 122 | 2 |
| 79UCJ0K6R9C1 | 235 | 78 | 0 | 42 | 0 |

三个现有audit-selection.ts命令退出码均0；这是固定历史输入的观察复算，非tsc/vitest、生产题面消费、完整候选认证或自然实盘验证。原接口按设计将完整候选收益保持null，不能以该字段为null单独证明原始数据绝对无法人工核验。
K2排除d285853/d285888：map/route-change、无decision_id、chosen=null、原文no game action；完整原行保留，未造ID。79各区间缺原尝试身份等而不满足保守关联条件，不填默认尝试号伪造连接。源探针首次把combat=null当dict发生TypeError，已保存probe-first-error.txt并更正为空对象处理；未改生产源码，原错误历史保留。

## 逐项处置

| 原提案id | 账本 | 状态 | 缺数据/原因 |
|---|---|---|---|
| silent-proposal-0b8ef30de463f317 | silent-0013, silent-0277 | waiting | ZTRGYYMLR8SC F17六试重用同两瓶；116条药水动作端点仅是本批全局观察，不能替代取得/实饮/弃用/SL恢复到终局的联合归属，也无同资源晚饮或留药整战对照。覆甲分源及缺表提示已有实现，保留原饮用规则。 |
| silent-proposal-5367449b857450a7 | silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284 | waiting | ZTRGYYMLR8SC F17末T14铜钹附伤与原牌直伤可分，但原107次单弃汇总不足校准多敌随机分配、混合减损或击杀后的完整后继；刀扇本批直接实伤仍为单敌，不把已有临时减力/脆弱覆盖当整组完成。 |
| silent-proposal-9b8890c2649a2734 | silent-0012, silent-0019, silent-0020, silent-0021, silent-0125 | waiting | ZTRGYYMLR8SC F11T3及F17首T10/末T13只见同题局部护栏替换，缺原线与替线完整候选执行和整战资源对照；六次SL同局同组，三次局部省血不能相加成整场收益或拟新阈值。 |
| silent-proposal-645ff7b72e0b9991 | silent-0010, silent-0106, silent-0021, silent-0286 | waiting | K2JAGKVJAWZJ F46T1零毒蜃景及79UCJ0K6R9C1 F14T6/T10/T11感染边界已有窄实现；F14T3空过仍是地平线内0/8实赢加约76%尾端估计，未执行替线无整战实结，缺尾端校准，不改排名权重或禁止空过。 |
| silent-proposal-68ef2857229d1287 | silent-0278, silent-0286 | waiting | K2JAGKVJAWZJ F33T10及79UCJ0K6R9C1 F14T11两次饮用只核当步毒42→48/4→10且敌HP不变；前者直接SL，后者三感染先致死。缺本批修饰组合下完整后继及题面/rollout联合校准，不把局部加6扩成通用非双Boss模型。 |
| silent-proposal-9edfef7a6b2873c2 | silent-0020, silent-0019, silent-0021 | waiting | 路线绝对来源已由live祖先7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a实现，新增敌血池审计已有3f69541b5d3259dac94d3395bfe3da47936b4de9；宽资源链仍缺药水/SL/终局联合消费者归属。K2两条无实际动作的路线记录保留排除，旧比例与空尝试号不能补造成唯一完整执行，不整项duplicate。 |
| silent-proposal-ff1d168227e369e0 | silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178 | waiting | K2JAGKVJAWZJ F46T1/T6与T9只支持已观察零毒、普通有毒和逐击减损子项；未隔离T7额外2伤，重放/暗影/临时减力/钨棍的所有修饰组合及各消费者未逐项核齐，不由窄实现关闭整组。 |
| silent-proposal-c64bdd50a949d16f | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | waiting | 按9c3ff042勘误，K2JAGKVJAWZJ F27T2铁心药前后均0挡、覆甲0→7，旧16挡原稿原样保留。仍缺持续能力实建、药水取得/实饮/弃用/SL恢复至终局的联合归属及早饮/换瓶完整对照，不改时点或持有价。 |
| silent-proposal-243ad8dd038a4ff6 | silent-0019, silent-0020, silent-0065, silent-0106 | waiting | K2JAGKVJAWZJ F33两试62血/原毒瓶且首29抽相同，首目标、后续出牌和洗牌后状态同时改变；第二试留瓶获胜不能隔离留药或首目标胜因。F46高血86仍败仅是反例，缺单因素整战及替路线/休息实走结果，不改杀序或SL规则。 |
| silent-proposal-9c3ff04261867dd2 | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | waiting | K2JAGKVJAWZJ F27T2勘误已由d286123、s292788→292789复核为0即时挡/7覆甲；勘误本身不需新源码。宽资源和终局主张仍缺取得/实饮/弃用/SL恢复至消费者的完整联合归属及饮药时点整战对照，保留独立原ID与历史。 |

每项证据局/层/回合、旧稿指纹、反例、预期行为、验证和回退见 proposal.md。零毒蜃景/路线来源/血池审计等子项祖先已核，但不等于整项duplicate；没有把非live候选commit当实现。本批不新增提案id，code_proposals恰为十个派发原id，implementation_domains=[]表示没有本批实际实现。

## 记录与验收边界

账本只经根learner/ledger.py update追加20条where/note追溯，不添加证据样本、不改变旧科学字段或状态，不标shipped；输入与原CLI回执见ledger-updates.jsonl/ledger-update.stdout.txt/ledger-update.stderr.txt，读回核验见ledger-readback.json。最终队列处置由调用方读取proposal_results，模型未直接改专用队列或learn.json。
没有源码提交，因此撤源码失败/恢复通过不适用，tsc/vitest/cases固定null；未声称测试成功，也未触发代码提交前扫描或上线。没有申请live锁、创建发布号、通知规则已上线、修改经验库或将经验冒称大脑已采用。没有修改main/live及其他角色行为。
最终工作树与HEAD核验、账本保护字段读回和材料指纹见final-verification.json/artifact-manifest.json；这些是材料/追溯检查，不是生产测试。
完整40位base及机器处置见report.json。原失败、旧稿和所有本批材料均留在本批learner/runs目录；没有删除自身工作树或改父请求状态。

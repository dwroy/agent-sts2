import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


extract = module('extract', ROOT / 'learner/extract_evidence.py')
resources = module('resources', ROOT / 'learner/resource_chain.py')
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
checks = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == stream['output_sha256']
    rows = []
    counts = Counter()
    with (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
        for line in data.splitlines():
            item = json.loads(line)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id']
            counts[item['run_id']] += 1
            rows.append(item)
    assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
    streams[name] = rows
    checks.append({'stream': name, 'verified_rows': len(rows), 'source_size': stream['source_size'],
                   'counts': stream['counts'], 'output_sha256': stream['output_sha256'],
                   'invalid_source_lines': stream['invalid_lines'],
                   'incomplete_source_lines': stream['incomplete_lines']})
save('byte-verification.json', {'streams': checks, 'total_verified': sum(c['verified_rows'] for c in checks)})

run_info = {e['run_id']: e['row'] for e in streams['runs']}
state_groups = defaultdict(list)
decision_groups = defaultdict(list)
sl_groups = defaultdict(list)
for item in streams['states']:
    state = item['row']['state']
    info = state.get('run') or {}
    assert info['character_id'].lower() == 'silent'
    assert info['ascension'] == run_info[item['run_id']]['ascension']
    state_groups[item['run_id']].append({**item['row'], '_line': item['line']})
for item in streams['decisions']:
    decision_groups[item['run_id']].append({**item['row'], '_line': item['line']})
for item in streams['sl-attempts']:
    sl_groups[item['run_id']].append(item['row'])

run_summaries = []
potion_endpoints = []
selected_decisions = []
anchor_lines = {285252, 286255, 286431, 286684, 286715, 286716}
for rid, run in run_info.items():
    assert run['character'].lower() == 'silent'
    starts = defaultdict(list)
    for row in sl_groups[rid]:
        if row.get('attempt', 1) > 1 and row.get('started_at'):
            starts[row['floor']].append(row['started_at'])
    chain = resources.resource_chain(state_groups[rid], rid, 'silent', starts)
    save(rid + '-resource-chain.json', chain)
    run_summaries.append({'run_id': rid, 'ascension': run['ascension'], 'victory': run['victory'],
                          'floor': run['floor'], 'historical_code': run['code'],
                          'state_count': len(state_groups[rid]), 'decision_count': len(decision_groups[rid]),
                          'sl_events': len(sl_groups[rid]), 'combats': [
        {k: w.get(k) for k in ['sequence', 'floor', 'entry_is_turn_one', 'end', 'observed_net_hp_loss']}
        | {'entry': {k: w['entry'].get(k) for k in ['line', 'turn', 'hp', 'max_hp', 'potions']},
           'last': {k: w['last'].get(k) for k in ['line', 'turn', 'hp', 'max_hp', 'potions']},
           'exit': None if not w['exit'] else {k: w['exit'].get(k) for k in ['line', 'turn', 'hp', 'max_hp', 'potions']}}
        for w in chain['combats']]})
    state_keys = defaultdict(list)
    for n, row in enumerate(state_groups[rid]):
        state_keys[(row.get('observed_ts'), row.get('fingerprint'))].append(n)
    for row in decision_groups[rid]:
        if row['_line'] in anchor_lines:
            selected_decisions.append(row)
        chosen = row.get('chosen') or {}
        if chosen.get('action') not in ('use_potion', 'discard_potion'):
            continue
        matching = state_keys[(row.get('observed_ts'), row.get('fingerprint'))]
        before = state_groups[rid][matching[0]] if len(matching) == 1 else None
        after = state_groups[rid][matching[0] + 1] if before and matching[0] + 1 < len(state_groups[rid]) else None
        def endpoint(frame):
            if not frame:
                return None
            state = frame['state']; combat = state.get('combat') or {}; player = combat.get('player') or {}
            info = state.get('run') or {}
            return {'line': frame['_line'], 'observed_ts': frame.get('observed_ts'),
                    'screen': state.get('screen'), 'floor': info.get('floor'), 'turn': state.get('turn'),
                    'hp': info.get('current_hp'), 'max_hp': info.get('max_hp'), 'block': player.get('block'),
                    'powers': player.get('powers'), 'potions': info.get('potions'),
                    'relics': [r.get('relic_id') for r in info.get('relics', [])],
                    'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'powers']}
                                for e in combat.get('enemies', [])]}
        potion_endpoints.append({'run_id': rid, 'decision_line': row['_line'], 'decision_id': row.get('decision_id'),
                                 'floor': row.get('floor'), 'turn': row.get('turn'),
                                 'sl_attempt': row.get('sl_attempt'), 'sl_reloads': row.get('sl_reloads'),
                                 'chosen': chosen, 'expect': row.get('expect'), 'result': row.get('result'),
                                 'state_match_count': len(matching), 'before': endpoint(before), 'after': endpoint(after),
                                 'causal_full_candidate_result': None})
    if rid in ('ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1'):
        excluded = [r for r in decision_groups[rid] if not r.get('decision_id') or not (r.get('chosen') or {}).get('action')]
        usable = [r for r in decision_groups[rid] if r not in excluded]
        save(rid + '-selection-input.json', {'run': run, 'decisions': usable, 'states': state_groups[rid]})
        save(rid + '-selection-excluded.json', excluded)
save('run-summary.json', run_summaries)
save('potion-action-endpoints.json', potion_endpoints)
save('anchor-decisions.json', selected_decisions)
save('inspection-notes.json', {'prior_read_only_probe_error': 'TypeError: NoneType is not iterable; first frame combat was null; corrected with combat or {}.',
                              'production_source_modified': False,
                              'verification_kind': '原始字节与观察复算；不是 tsc/vitest 或生产消费者验收'})
print(json.dumps({'verified_rows': sum(c['verified_rows'] for c in checks), 'verified_characters': len(run_info),
                  'potion_requests': len(potion_endpoints), 'anchor_decisions': len(selected_decisions),
                  'run_summaries': len(run_summaries)}, ensure_ascii=False))

# 静默猎手：本批十项原提案的证据复核与处置

批次：20261018-101301-s2-strategy-proposal。记录时间：2026-10-18 10:22:22 CST。
本批仅消费 dispatch.json 中十个已领取 id；没有 research_request / implementation_request / proposal_repair，不承接旧专题，不扩展队列，不新建重复提案。所有十项保留 waiting；没有源码变更、实现提交或合入。

证据只来自本批十局静默猎手及对应原提案/账本。A3/A4两胜、A7一败与A10七败分别记录，不能合成A10策略胜率。十局旧运行代码均有 dirty 标记，缺完整历史脏树，当前源码快照不代表当时执行源码。SL尝试按同局归组，不能当独立样本。

## 本批方法与已核边界

共用 extract_evidence.py 按显式归属提取八流；12,702条记录逐条核回原始 offset/bytes/SHA256/JSON/身份，并核输出 SHA 与 source_size。states/decisions/brain 全源各有2条坏行，无法归属本批；不丢弃限制，不据此猜缺失内容。fight-plans 在此字节截点选到0条，仅说明显式身份未选到，不断言原日志不存在。
十局观察资源链生成162个战斗窗口，保留赢战、缺出口、SL恢复与实际净血差；净HP不是敌伤。三局现有 selection 审计仅关联有身份的原动作，K2两条无ID且无动作的路线元记录单列排除，保留原始全局行号，不补造字段。工具按设计不认证完整候选收益，0项认证不是对全部原始数据的数学不可能性证明。
本次不拟合权重、时点、胜率或阈值。原证据仅作事实与边界复核，同局所有尝试同组；未来新完局及相同条件下完整后继可供时间留出验证。不读取其他角色私有知识，不以预训练补规则。

## 既有实现只按子项记录

- 零毒升级蜃景子项：5e0f884586521220d451b717c29b99e7876d6244，是本批观察到的 live 祖先。
- 路线绝对投影来源：7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a，是 live 祖先。
- 新增敌血池观察：3f69541b5d3259dac94d3395bfe3da47936b4de9，是 live 祖先。
- 恶魔条件化毒药水入口：8043b289e8065a31799cfd1d331e0c6c933bc1d6，是 live 祖先，其完整修饰条件不能冒充本批两场已覆盖。
以上均不是本批新实现。另一个检索到的 b2a30ea6ebadda351fcc345b65b0c0e870bc5d65 不是观察 live 的祖先，没有用它登记 duplicate。完整谱系、blob和13个所需源码叶的原字节副本见 source-audit.json/source/。

## 1. silent-proposal-0b8ef30de463f317

分列药水新增与SL恢复、现场覆甲与后段脆弱，不把早段挡或前战力量当持续战力

账本：silent-0013, silent-0277。来源任务：postmortem；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-potion-plating.md；SHA256 `ac20c158f9134f0c139a7a3886d3c26fbb542517b3ebf2e1c2c8078e228cbeb8`。原字节保存为 original-proposal-01.md。
本批证据：ZTRGYYMLR8SC F6T3、F11T1、F14T1、F17六试及末T14；d285252；s292001—292402；SL1074—1079。
反例与限制：同族第2试更早饮铁心仍更短；洗牌、目标与动作同时改变，不能归因早饮。
处置：waiting。ZTRGYYMLR8SC F17六试重用同两瓶；116条药水动作端点仅是本批全局观察，不能替代取得/实饮/弃用/SL恢复到终局的联合归属，也无同资源晚饮或留药整战对照。覆甲分源及缺表提示已有实现，保留原饮用规则。
预期行为：保留当前实现及已核子项；后续仅在分列药水新增与SL恢复、现场覆甲与后段脆弱，不把早段挡或前战力量当持续战力所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 2. silent-proposal-5367449b857450a7

核验同族临时减力、脆弱、覆甲与铜钹/刀扇分源覆盖

账本：silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284。来源任务：experience-update；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-mechanisms.md；SHA256 `2bbe2e854ce6bdb95609f800eb8434cdb05b6be963cfc8ec1870d81d65aee062`。原字节保存为 original-proposal-02.md。
本批证据：ZTRGYYMLR8SC F11T1、F17末T5/T6/T14；原账本silent-0284的其他六局仅作已登记来源，不在本批重作107次全历史分母。
反例与限制：ULP相关旧汇总有滑溜同现仅减1，不把3作为所有修饰下通用值；本批未重算107次全历史统计。
处置：waiting。ZTRGYYMLR8SC F17末T14铜钹附伤与原牌直伤可分，但原107次单弃汇总不足校准多敌随机分配、混合减损或击杀后的完整后继；刀扇本批直接实伤仍为单敌，不把已有临时减力/脆弱覆盖当整组完成。
预期行为：保留当前实现及已核子项；后续仅在核验同族临时减力、脆弱、覆甲与铜钹/刀扇分源覆盖所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 3. silent-proposal-9b8890c2649a2734

保留候选护栏血价、真实执行与同族重打/路线资源链

账本：silent-0012, silent-0019, silent-0020, silent-0021, silent-0125。来源任务：experience-update；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-trace.md；SHA256 `ddafc2fed623f77ca9c28eff1309aedb8f1f746e3714756f5b71ee5eb1d97f57`。原字节保存为 original-proposal-03.md。
本批证据：ZTRGYYMLR8SC F11T3、F17首T10/末T13/T14；本批selection输入594动作、130段。
反例与限制：护栏局部省血后末试仍败；原线没有实际整场结果，不能把失败归给护栏或定新阈值。
处置：waiting。ZTRGYYMLR8SC F11T3及F17首T10/末T13只见同题局部护栏替换，缺原线与替线完整候选执行和整战资源对照；六次SL同局同组，三次局部省血不能相加成整场收益或拟新阈值。
预期行为：保留当前实现及已核子项；后续仅在保留候选护栏血价、真实执行与同族重打/路线资源链所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 4. silent-proposal-645ff7b72e0b9991

按已观察静默A10状态核对零毒蜃景与短推演收益，保留感染先于毒的结算边界；未知收益不得写成已兑现格挡或实赢。

账本：silent-0010, silent-0106, silent-0021, silent-0286。来源任务：postmortem；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-combat-observed-payoff.md；SHA256 `55cd7445ba3ac32ef6bff153a908a5b729ea6dc7939b84be7ba6712080cd5ace`。原字节保存为 original-proposal-04.md。
本批证据：K2JAGKVJAWZJ F46T1/T6 s293158→293159/s293196→293197；79UCJ0K6R9C1 F14T3/T6/T10/T11 d286684、s293440/293443/293460—293465。
反例与限制：普通蜃景在K2 F46T6真实加10挡；不能把整类蜃景归零。0/8实赢也不等于8/8死亡。
处置：waiting。K2JAGKVJAWZJ F46T1零毒蜃景及79UCJ0K6R9C1 F14T6/T10/T11感染边界已有窄实现；F14T3空过仍是地平线内0/8实赢加约76%尾端估计，未执行替线无整战实结，缺尾端校准，不改排名权重或禁止空过。
预期行为：保留当前实现及已核子项；后续仅在按已观察静默A10状态核对零毒蜃景与短推演收益，保留感染先于毒的结算边界；未知收益不得写成已兑现格挡或实赢。所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 5. silent-proposal-68ef2857229d1287

独立核验将静默A10无加量/阻挡条件下毒药水实观加6传播到已观察非双boss战，按感染先于毒结算比较，保留未核组合与饮用时机限制。

账本：silent-0278, silent-0286。来源任务：postmortem；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-potion-observed-scope.md；SHA256 `f30a8d0b9964ccf0009478cb80065bb5fafc8d6cce81b760bafc7aace1848d6f`。原字节保存为 original-proposal-05.md。
本批证据：K2JAGKVJAWZJ F33T10 d286255、s292940→292941及SL后s292942；79UCJ0K6R9C1 F14T11 d286715—286716、s293463—293465。
反例与限制：K2重试保留原毒瓶仍胜；79虽加6毒仍在结算前死亡，不能将毒层预支成击杀。
处置：waiting。K2JAGKVJAWZJ F33T10及79UCJ0K6R9C1 F14T11两次饮用只核当步毒42→48/4→10且敌HP不变；前者直接SL，后者三感染先致死。缺本批修饰组合下完整后继及题面/rollout联合校准，不把局部加6扩成通用非双Boss模型。
预期行为：保留当前实现及已核子项；后续仅在独立核验将静默A10无加量/阻挡条件下毒药水实观加6传播到已观察非双boss战，按感染先于毒结算比较，保留未核组合与饮用时机限制。所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 6. silent-proposal-9edfef7a6b2873c2

给路线HP投影保留计划时最大生命、节点与预测来源，逐场关联实盘进出资源、SL恢复及新增敌血池，区别boss时钟与整场模拟。

账本：silent-0020, silent-0019, silent-0021。来源任务：postmortem；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-resource-projection-provenance.md；SHA256 `d920109bd6d754df32fa941dc4404e979dbcfaaf48db906b85cbc9d77a45cc96`。原字节保存为 original-proposal-06.md。
本批证据：K2JAGKVJAWZJ F31—F46，尤其F33两试与F46资源；79UCJ0K6R9C1 F8—F14及F14新增虫体血池；原计划run字段按显式身份取44行。
反例与限制：K2投影末战75而实到86，79投影70而实到51；不能统一增减固定血值，也不能按后来上限回填旧计划。
处置：waiting。路线绝对来源已由live祖先7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a实现，新增敌血池审计已有3f69541b5d3259dac94d3395bfe3da47936b4de9；宽资源链仍缺药水/SL/终局联合消费者归属。K2两条无实际动作的路线记录保留排除，旧比例与空尝试号不能补造成唯一完整执行，不整项duplicate。
预期行为：保留当前实现及已核子项；后续仅在给路线HP投影保留计划时最大生命、节点与预测来源，逐场关联实盘进出资源、SL恢复及新增敌血池，区别boss时钟与整场模拟。所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 7. silent-proposal-ff1d168227e369e0

核验零毒蜃景升级版与重放/格挡倍率、临时减力和逐击减损分源

账本：silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178。来源任务：experience-update；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-mechanisms.md；SHA256 `b69ab5987f7e058572c2e42190046ab1f4806712d9939f55db969342df3a34e1`。原字节保存为 original-proposal-07.md。
本批证据：K2JAGKVJAWZJ F46T1 s293158→293159、T6 s293196→293198、T9 s293218→293219；10GPK5XGHCK3 A3仅原观察背景，不外推A10交互。
反例与限制：K2 T6普通蜃景确有收益；钨棍、重放和暗影的未知交互不由单个已知分支推广，T7差2伤保持未知。
处置：waiting。K2JAGKVJAWZJ F46T1/T6与T9只支持已观察零毒、普通有毒和逐击减损子项；未隔离T7额外2伤，重放/暗影/临时减力/钨棍的所有修饰组合及各消费者未逐项核齐，不由窄实现关闭整组。
预期行为：保留当前实现及已核子项；后续仅在核验零毒蜃景升级版与重放/格挡倍率、临时减力和逐击减损分源所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 8. silent-proposal-c64bdd50a949d16f

核验实际能力、药水来源与跨幕回复，保留时点和终局反事实限制

账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。来源任务：experience-update；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-resources.md；SHA256 `979e5eb65499c91eed763906c40aa0b50a42b598925021c83c220bef3e7bc658`。原字节保存为 original-proposal-08.md。
本批证据：K2JAGKVJAWZJ F15T2/F27T2/F33两试/F45/F46；F27 d286123、s292788→292789。
反例与限制：旧稿F27的16挡被原帧否定，采用更正稿0挡；SL恢复药瓶不是新取得，持有能力不等于实建。
处置：waiting。按9c3ff042勘误，K2JAGKVJAWZJ F27T2铁心药前后均0挡、覆甲0→7，旧16挡原稿原样保留。仍缺持续能力实建、药水取得/实饮/弃用/SL恢复至终局的联合归属及早饮/换瓶完整对照，不改时点或持有价。
预期行为：保留当前实现及已核子项；后续仅在核验实际能力、药水来源与跨幕回复，保留时点和终局反事实限制所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 9. silent-proposal-243ad8dd038a4ff6

保留同首29抽帝王蟹重打与强制三骑士资源/成长对照

账本：silent-0019, silent-0020, silent-0065, silent-0106。来源任务：experience-update；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-trace.md；SHA256 `e8f8451e62c4f0435082e636dba0308bbe60ee86b992f85328a17835062a1acc`。原字节保存为 original-proposal-09.md。
本批证据：K2JAGKVJAWZJ F33首T1—T10及重试T1—T11、F46T1—T9；资源链sequence13/14/18。
反例与限制：首29抽相同后多动作仍变、洗牌后未知；高血入三骑士仍败不能证明某个目标顺序必胜。
处置：waiting。K2JAGKVJAWZJ F33两试62血/原毒瓶且首29抽相同，首目标、后续出牌和洗牌后状态同时改变；第二试留瓶获胜不能隔离留药或首目标胜因。F46高血86仍败仅是反例，缺单因素整战及替路线/休息实走结果，不改杀序或SL规则。
预期行为：保留当前实现及已核子项；后续仅在保留同首29抽帝王蟹重打与强制三骑士资源/成长对照所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 10. silent-proposal-9c3ff04261867dd2

更正第94批F27铁心药水零即时挡，核验实际能力/药水与跨幕回复

账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。来源任务：experience-update；目标任务：strategy-proposal；本批实现任务：20261018-101301-s2-strategy-proposal。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-resources-corrected.md；SHA256 `2f19523d142524633da29cdb34fd133fd86b3b8fbc95cf4de2e10c37ad4ebb7b`。原字节保存为 original-proposal-10.md。
本批证据：K2JAGKVJAWZJ F27T2 d286123、s292788→292789；F33首T10毒药实饮后SL恢复与末试保留。
反例与限制：该项更正了旧数字，没有生成新的游戏机制或源码缺陷；缺整战对照时不改饮用门槛。
处置：waiting。K2JAGKVJAWZJ F27T2勘误已由d286123、s292788→292789复核为0即时挡/7覆甲；勘误本身不需新源码。宽资源和终局主张仍缺取得/实饮/弃用/SL恢复至消费者的完整联合归属及饮药时点整战对照，保留独立原ID与历史。
预期行为：保留当前实现及已核子项；后续仅在更正第94批F27铁心药水零即时挡，核验实际能力/药水与跨幕回复所述范围补足可校准证据后实现，不外推角色或进阶。
验证方法：复用固定原始帧及条件化反例，逐一核对题面、求解与后继；涉及规则的未来源码实现须撤源码失败/恢复通过、沙箱入口和实际live验证。不得用局部字段复算或旧绿测试代替消费者验收。
回退：本批无源码净变更，无需源码回退；后续实现须独立提交，可逆向该净补丁，并保留所有日志、旧稿、失败、账本和并行知识。

## 状态与追溯

本批 code_proposals 使用已派发原CLI id，新增id为0。账本仅通过根 learner/ledger.py update 追加本批报告链接和 waiting 注释，不改旧claim、first_run、prior、evidence、status、version、effect，不标shipped。各项具体结果见 proposal-results-detailed.json，最终机械处置由调用方读取 report.json；本批不直接手写队列。
没有改源码，tsc/vitest/cases均为null，撤源码失败/恢复通过不适用，未创建发布号或伪造合入。

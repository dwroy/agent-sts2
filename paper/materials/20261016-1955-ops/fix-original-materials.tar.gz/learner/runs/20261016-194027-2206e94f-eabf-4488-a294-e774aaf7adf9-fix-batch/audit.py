import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-194022'
SCRATCH = ROOT / 'learner/runs/20261016-194027-2206e94f-eabf-4488-a294-e774aaf7adf9-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261016-191312-d3309fa7-2091-4c1f-8fca-0086f48c407d-fix-batch'
EXPECTED_BASE = '4236376da85825af88d33e29c4a3309a6e5e6831'


def git(*args, tree=TREE):
    return subprocess.check_output(['git', '-C', str(tree), *args]).decode().strip()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


# Recheck the prior scope against current bytes, rather than reusing its verdict alone.
checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
base = git('rev-parse', 'HEAD')
assert base == EXPECTED_BASE, base
assert not git('status', '--porcelain=v1')
prior_raw = (PREVIOUS / 'audit.json').read_bytes()
prior = json.loads(prior_raw)
prior_result = json.loads((PREVIOUS / 'result.json').read_text())
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live')
base_ancestors = set(git('rev-list', base).splitlines())
live_ancestors = set(git('rev-list', live).splitlines())
source_changes = [path for path in git('diff', '--name-only', prior['base'], base).splitlines()
                  if path.startswith(('agent/', 'learner/', 'ops/', 'eval/', 'knowledge/builders/'))
                  and path != 'ops/inbox-dev.md']
assert not source_changes, source_changes
files = []
for old in prior['current_files']:
    relative = Path(old['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    assert relative.name != '.env' and not relative.name.endswith('.env')
    assert relative.parts[0] in ('agent', 'ops', 'learner', 'knowledge', 'eval')
    raw = (TREE / relative).read_bytes()
    current_sha = digest(raw)
    assert current_sha == old['sha256'], str(relative)
    files.append({'path': str(relative), 'sha256': current_sha, 'same_as_prior': True})
fixed = []
for old in prior['existing_fixes']:
    commit = old['commit']
    assert commit in base_ancestors and commit in live_ancestors, old
    fixed.append({**old, 'ancestor_in_base': True, 'ancestor_in_live': True,
                  'subject': git('show', '-s', '--format=%s', commit)})
focused = []
for old in prior['focused_source_review']:
    lines = (TREE / old['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if old['anchor'] in line]
    assert found, old
    focused.append({'path': old['path'], 'anchor': old['anchor'], 'lines': found})
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
queue_lines = queue.decode().splitlines()
previous_queue = (PREVIOUS / 'queue-readonly-snapshot.md').read_bytes()
assert digest(previous_queue) == prior['queue_sha256']
assert queue.startswith(previous_queue)
added = queue[len(previous_queue):].decode()
assert len(queue_lines) == 1379 and 'Roy19:16优先 silent-0332' in added, added
unchecked = [(i + 1, line) for i, line in enumerate(queue_lines) if line.startswith('- [ ]')]
assert unchecked == [(row['line'], row['item']) for row in prior['queue_dispositions']]
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)
raw_refs = []
for old in prior['raw_original_references']:
    relative = Path(old['source'])
    assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'logs'
    with (ROOT / relative).open('rb') as handle:
        handle.seek(old['offset'])
        raw = handle.read(old['bytes'])
    assert digest(raw) == old['sha256'], old
    json.loads(raw)
    raw_refs.append({**old, 'sha256_verified': True, 'json_parsed': True})
readbacks = []
for name in ('priority-dispatch-receipt.json', 'priority-start-readback.json'):
    path = ROOT / 'paper/materials/20261016-1920-ops' / name
    raw = path.read_bytes()
    value = json.loads(raw)
    readbacks.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(raw),
                      'request_id': value['request_id'],
                      'native_receipt_claimed': False})
    assert value['request_id'] == 'silent-0332'
    if name == 'priority-dispatch-receipt.json':
        assert value['actual_batch']['task'] == 'strategy-proposal'
        assert value['registration']['state'] == 'running'
        assert value['actual_batch']['learning_request'] == 'silent-0332'
assert not git('status', '--porcelain=v1')
audit = {
    'checked_at': checked_at, 'base': base, 'main_merge': 'Already up to date.',
    'prior_audit': str(PREVIOUS / 'audit.json'), 'prior_audit_sha256': digest(prior_raw),
    'live_read_only_snapshot': live, 'source_changes_since_prior': source_changes,
    'current_files': files, 'existing_fixes': fixed, 'focused_source_review': focused,
    'queue_sha256': digest(queue), 'queue_lines': len(queue_lines), 'queue_append': added,
    'unchecked_entries': len(unchecked), 'queue_dispositions': prior['queue_dispositions'],
    'raw_original_references': raw_refs, 'priority_readbacks': readbacks,
    'scope': '本批只读复核；无新增源码、测试、提交、账本状态或live改动；既有测试结论不当本批结果',
}
save('audit.json', audit)
result = {**prior_result, 'base': base, 'fixes': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
for row in result['skipped']:
    if row['item'].startswith('silent-0332'):
        row['reason'] = ('证据不足；当前正HP契约仍在，原异常resources/steps截断；'
                         '已登记192940原策略owner接续，沿5aa2672bd7cd1bf4等原六提案，不重复派发或放宽正HP/300门槛。')
save('result.json', result)
lines = [
    '## 修 bug 回报', '',
    f'- 合并基线：main → {base}（开工工作区干净，先合main，Already up to date.）',
    '- 修复（每条一行）：无新增纯bug；逐项复核42条未勾选条目和其余既有处置。'
    f'{len(files)}个相关源码/测试/脚本与前批SHA一致，{len(fixed)}项既有修复均为当前base及所核live祖先。'
    '未改源码、未提交；去掉修复时失败验证不适用。',
]
for row in fixed:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['commit']}（已核当前源码及base/live祖先；仅已修子项，不关闭更宽父项）")
for row in result['skipped']:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines.extend([
    '- 测试：tsc未运行，退出码null；vitest未运行，0文件 / 0用例 / 退出码null；无重跑。'
    '本批没有代码提交或合入，不重复跑未变源码；固定offset/bytes/SHA与JSON只读核验10条旧日志，不当生产测试。',
    f'- 合入：未合入（无新增提交）；live只读快照为{live}。没有空合并、新版本、账本改状态或规则通知。',
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'base': base, 'live_read_only_snapshot': live, 'unchanged_files': len(files),
                  'verified_existing_fixes': len(fixed), 'unchecked_entries': len(unchecked),
                  'raw_log_rows_verified': len(raw_refs), 'skipped': len(result['skipped']),
                  'source_changes_since_prior': source_changes, 'report': result['report']}, ensure_ascii=False))

"""Freeze selected source blobs and read back previous offline consumer artifacts."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PREVIOUS = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-183355/learner/runs/20261016-183402-4ef1a6d2-ab15-49d3-9baa-64a77624c833-strategy-proposal')
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
old = json.loads((PREVIOUS / 'source-audit.json').read_text())
files = []
paths = [x['path'] for x in old['files']] + ['agent/src/core/util/json.ts']
for path in paths:
    before = git('show', f'{base}:{path}')
    actual = git('show', f'{live}:{path}')
    prior = git('show', f"{old['base']}:{path}")
    commit = git('log', '-1', '--format=%H', base, '--', path).decode().strip()
    rc = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live], cwd=ROOT).returncode
    assert rc in (0, 1)
    files.append({'path': path, 'base_sha256': sha(before), 'live_sha256': sha(actual),
                  'previous_base_sha256': sha(prior), 'unchanged_from_previous_base': before == prior,
                  'same_as_live': before == actual, 'source_commit': commit, 'source_is_live_ancestor': rc == 0})
(OUT / 'base-live-selected.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
(OUT / 'source-audit.json').write_text(json.dumps({'base': base, 'live': live, 'previous_base': old['base'], 'files': files}, ensure_ascii=False, indent=2) + '\n')

dispatch = json.loads((OUT / 'dispatch.json').read_text())
originals = []
for ident in dispatch['proposal_ids']:
    item = json.loads((OUT / f'{ident}.queue-history.json').read_text())[0]
    raw = Path(item['proposal']).read_bytes()
    assert sha(raw) == item['proposal_sha256']
    (OUT / f'{ident}.original.md').write_bytes(raw)
    originals.append({'id': ident, 'path': item['proposal'], 'sha256': sha(raw), 'ledger': item['ledger']})

summary = json.loads((PREVIOUS / 'consumer-summary.json').read_text())
artifacts = []
for item in summary['summaries']:
    path = PREVIOUS / f"{item['run']}.consumer.json.gz"
    compressed = path.read_bytes()
    expanded = gzip.decompress(compressed)
    assert sha(compressed) == item['compressed_sha256']
    assert sha(expanded) == item['output_sha256']
    result = json.loads(expanded)
    assert result['run_id'] == item['run'] and result['character'] == 'silent'
    assert all(x['actual_full_candidate_result'] is None for x in result['segments'])
    artifacts.append({'path': str(path), 'compressed_sha256': sha(compressed), 'output_sha256': sha(expanded), 'summary': item})
record = {'previous': str(PREVIOUS), 'consumer_invoked_this_batch': False, 'source_files_unchanged_from_previous': all(x['unchanged_from_previous_base'] for x in files),
          'artifacts': artifacts, 'excluded': summary['excluded'], 'new_input_equality': 'pending evidence extraction comparison'}
(OUT / 'consumer-readback.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'live': live, 'source_files': len(files), 'same_live': sum(x['same_as_live'] for x in files),
                  'unchanged_from_previous': sum(x['unchanged_from_previous_base'] for x in files), 'original_proposals': len(originals), 'consumer_artifacts_read_back': len(artifacts)}))

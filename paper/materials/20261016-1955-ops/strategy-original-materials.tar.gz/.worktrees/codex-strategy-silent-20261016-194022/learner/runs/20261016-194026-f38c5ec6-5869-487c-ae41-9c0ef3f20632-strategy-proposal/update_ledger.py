"""Append only trace links through the authorized ledger CLI and verify preservation."""
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
items = json.loads((OUT / 'dispositions.json').read_text())
by_ledger = {}
for item in items:
    for ident in item['ledger']:
        by_ledger.setdefault(ident, []).append(item)
updates = []
for ident, proposals in sorted(by_ledger.items()):
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261016-194022-strategy-proposal：原提案复核，未新增源码、机制证据或独立样本；旧结论/首证/先验/状态/版本及已上线历史保持。'
                            + '；'.join(p['id'] + ' waiting：' + p['reason'] for p in proposals)})
(OUT / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
before = LEDGER.read_bytes()
prefix = {'source': str(LEDGER), 'size': len(before), 'sha256': hashlib.sha256(before).hexdigest()}
(OUT / 'ledger-prefix-before.json').write_text(json.dumps(prefix, ensure_ascii=False, indent=2) + '\n')
before_rows = [json.loads(raw) for raw in before.splitlines() if raw.strip()]
before_rows = [row for row in before_rows if row.get('id') in by_ledger]
(OUT / 'ledger-before.json').write_text(json.dumps(before_rows, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'ledger-updates.json').open('rb') as stdin, (OUT / 'ledger-cli.log').open('wb') as log:
    completed = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], stdin=stdin, stdout=log, stderr=subprocess.STDOUT)
assert completed.returncode == 0
after = LEDGER.read_bytes()
assert after[:len(before)] == before
own = []
offset = len(before)
for raw in after[len(before):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('where', {}).get('proposal') == [str(OUT / 'proposal.md'), str(OUT / 'report.md')] and row.get('by') == 'learner:strategy-proposal':
        own.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(own) == len(updates) == 16
assert {x['row']['id'] for x in own} == set(by_ledger)
expected = {r['id']: r for r in updates}
for entry in own:
    actual = {k: v for k, v in entry['row'].items() if k not in ('op', 'ts')}
    assert actual == expected[actual['id']]

spec = importlib.util.spec_from_file_location('ledger_cli', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
old = module.fold(list(enumerate(before_rows)))
new = module.fold(list(enumerate(before_rows + [e['row'] for e in own])))
preserved = []
for ident in by_ledger:
    a, b = old[ident], new[ident]
    assert a['character'] == 'silent'
    for key in set(a) | set(b):
        if key not in ('where', 'notes', 'history'):
            assert a.get(key) == b.get(key), (ident, key)
    assert b['notes'][:len(a['notes'])] == a['notes']
    assert b['history'][:len(a['history'])] == a['history']
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values
    preserved.append({'id': ident, 'status_preserved': a['status'], 'version_preserved': a['version'], 'protected_fields_unchanged': True})
record = {'cli_exit_code': completed.returncode, 'prefix_unchanged': True,
          'owned_updates': own, 'preservation': preserved, 'new_evidence_added': False, 'new_status_set': False}
(OUT / 'ledger-readback.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit_code': 0, 'owned_updates': len(own), 'protected_items': len(preserved), 'prefix_unchanged': True}))

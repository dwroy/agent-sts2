# 策略提案消费报告：20261016-194022-strategy-proposal

结论：十个派发提案全部waiting；缺的是逐项列出的执行归属与后继数据，未发现足以修改策略的新证据。未改源码或知识，无本批提交、合入或游戏版本；fixes=[]、merged=null。原提案的局部功能已在live，不能据此关闭完整提案。

## 身份与基线

开工git status为空，初始HEAD为4236376da85825af88d33e29c4a3309a6e5e6831。按普通提案要求git merge --no-edit main，实际快进至完整基线10e5e3e10630887b4a521c814c72e27eafb49528，无冲突。此次快进没有新增生产源码，仅接入main既有记录。最终HEAD保持该base，工作树和index保持干净。

只读根learn.json对应批次，task=strategy-proposal、character=silent、reason=proposal、工作树和六个runs均精确匹配，十proposal_ids已全处理，无research_request、implementation_request或proposal_repair。普通专题配置绑定另一批，不进入专题或读取其work_spec。没有修改根请求、learn.json、旧提案或调度状态。未派子agent、联网、调LLM、运行play或模拟池。任务文字要求普通/high；本任务没有可独立核实当前原生模型、推理强度与服务档的字段，不以仓库默认配置冒称已核或自行更改运行身份。

## 证据身份和完整性

六局在runs.jsonl均为SILENT A10，原+dirty标识保留，不假称已复原当时完整运行源码/知识。共用extract_evidence.py实际冻结六个主流，另用同入口提取runs身份流；各流source_size、逐行offset/bytes/SHA/显式run身份与输出SHA均保留并核验。原始日志只读，没有把正文提及当所属局。run-plans按run字段核，其他流同时核run_id/state.run_id/fingerprint.run，冲突拒收。计数如下。

| 局号 | states | decisions | SL行 | run-plans |
|---|---:|---:|---:|---:|
| 751FN9QM9MHQ | 624 | 615 | 6 | 2 |
| KV0JHNJCKXLS | 686 | 669 | 7 | 5 |
| YQL8RZ8BWN1E | 582 | 571 | 6 | 3 |
| L9SGRBB5R698 | 653 | 635 | 6 | 3 |
| PU80F84P6HPN | 1064 | 1033 | 12 | 5 |
| KEN58SH9SLZ6 | 558 | 548 | 6 | 3 |

六主流8438行已逐源核验；runs另核6行。全源invalid/incomplete统计只按manifest报告，不据全源错误推定本批缺帧；未覆盖旧报告或零行初稿，本次未读取fight-plans，亦不据此断言原流不存在。

## 逐项处置

十份原Markdown的SHA均与专用队列add行一致，原字节副本保留在本批*.original.md。下面十项沿用真实CLI id；十项相关16个旧账本均为本角色。

| 原CLI id | 证据局/层/回合/原行 | 既有账本 | waiting原因 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820 | silent-0079、silent-0176 | 缺抽弃与重问后的完整候选身份、逐来源结算和保持后轮条件的整战对照；现有资源比较仅预测，单动作回执不认证完整执行。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3；F17 T7/T13/T17；decisions 272361，states 278500—278505 | silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176 | 持牌未决与持药未知已有窄实现；缺F13不饮药的完整实际后继及留药后战对照，无法拟合持有价或更改用药规则。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13；同366288原帧 | silent-0079、silent-0176 | 与366288共享一局六试；缺完整候选归属、受控后继与独立验证，不能把5/10血局部差额拟成探索门槛。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17 | silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176 | 分项模型和未知值提示已有实现；缺攻击、毒、荆棘、持牌失血、敏捷的联合逐来源实结算校准及跨战用药对照。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 第4/5试T5；states 279460—279465、279511—279515；末试T4 279559/279560 | silent-0102、silent-0019、silent-0020 | 同盘净扣敌36/29、双方零净损及次轮毒20/13可核；缺毛伤/回血逐来源归属和路线休息替代后继，删毒不构成已证保血。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T10 states 280160/280161；L9SGRBB5R698 F17 T14 sl 681；PU80F84P6HPN F17 T17 sl 717 | silent-0017、silent-0250、silent-0011、silent-0027、silent-0046 | 阶段与残壳饮毒事实已有实现，参考路径仍沿原始显示HP平局排序；缺新旧改序的完整后继及提前喝/不喝/留药受控分支。 |
| silent-proposal-9733bb80f445aeae | YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 states 252435/252436 | silent-0017、silent-0019、silent-0020、silent-0250 | 残壳毒2→8未改变41自爆，PU实际余2血胜可核；缺完整阶段估值、排序与用药时点的受控后继，局部阶段说明不关闭整项。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272 | silent-0019 | 七次请求和药栏消耗可核，三次接口回执仍pending；缺随机选牌、发光水后重问的完整执行收益与保留至Boss对照。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 第4/5试T10 decisions 274505/274568；第4/6试T5 274484/274601 | silent-0079、silent-0021、silent-0125、silent-0005、silent-0176 | T10多2敌净损付6血、T5省2血却延后敏捷是双向取舍；缺逐来源兑现、保持后轮条件的对照和时间靠后的独立验证。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T2/T5/T10；decisions 274354/274484/274601/274505/274568 | silent-0021、silent-0079、silent-0125、silent-0176 | 血价、无实体与能力窗口证据可核；现有预测及端点工具不认证完整候选，缺受控后继，不拟统一6血/2伤准入阈值。 |

## 支持、反例与未知

751 F17三组同指纹：T2净损13→18、敌净扣9→18；T7净损13→23、敌净扣12→18；T13净损8→2、敌净扣17→11。未决弃牌的绝对预测误差与换线差额分列，六试全败不构成六个独立样本。F13 T3有药plan2预测损8/伤26，当轮无药plan3及整战无药plan5损8/伤16；plan3后续7/8样本仍饮药。没有无药实际整战或留药后战可赋持有价。

KV F33第4/5试T5同盘双方均零净损，敌净扣36/29、后轮毒20/13；末试T4由327/15毒到342/14毒，与结15毒再回30的观察一致。净血差没有逐来源毛伤归属，不将少输出说成保血。未走路线/营火分支不作为已发生的回血或反事实收益。

YQL F17 T10 states280160/280161：残壳毒2→8，玩家26血/13挡、自爆41均不变。只是该次实盘局部事实，不能证明提前喝/留药的整战价值。L9与PU旧SL anchor仍有占位显示HP；PU F17第5试T15 states252435为24血/20挡对42，252436实际奖励页2血，是本体结束仍需过自爆的反例。跨阶段HP跳变不归为输出或回血。

KEN F17第4/5试T10同指纹，实净损15/21、敌净扣2/4；原B2配对差-0.2583、SE0.0132是模型比较，非实盘胜率。反向T5同指纹净损7/5、敌净扣1/2，第4试已建立2敏捷而末试未建，不能只按省血断优劣。后轮动作、抽序及重问改变，不能隔离单步整战胜因。七次用药请求及各槽由有药到空可核，三条接口pending原样保留；空槽与完成回执均不能证明整条候选或随机选牌收益。

59/59固定材料核验通过；这些是原始证据与算术核验，不是生产tsc/vitest/cases或新校准通过。未发现需要改写旧claim的新机制异议；上述反例、缺帧、SL截断和未知保留。不以没有执行的分支强行支持原假设，也不拟固定门槛。将来若拟参数，按独立局真实时间切分调参与留出，不能把本批旧锚点冒称后期新局验证。

## 现有源码与离线消费者

实际只读live截点为8b65dafb808eb54e965fc1c6c613462fad82306c。20个相关源码叶与前批基线均逐字相同；17叶与本次live逐字相同，其余potion-cost.ts、explore.ts、controller.ts只有历史Roy/Dai注释署名差。选定binary diff保留。source-audit.json逐叶保存完整最近源码commit，并已核都是该live祖先；这不代表当时dirty知识或全仓运行输入均相同。

已有窄源：SL资源预测1698adc96ba434a46942321e0237b70657e625b2，持牌/候选阶段9d8278702dbc581b5015ba7ec9a70dc0fb94cccb，持药未知与无药参考c4670f4f416c7d93e192e889c5080e7e4e0e733f，单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed，巨兽毒水事实40168f4a903ae1d8c48bd03006f8fea19fd3aa3c，巨兽阶段/末态资源b01edf46b4b619f217d070a196e161df9fe716a0。

这些分别仍标current_turn_prediction/execution=unverified、actual_held_hp_loss=null、whole_plan_executed=null；巨兽anchorRank仍沿enemyHpLeft原显示HP平局排序。没有把原子功能当完整提案implemented/duplicate。

前批六个离线消费者产物的压缩与展开SHA、本角色身份和全部未认证字段已逐一读回。本次七流输入与前批对应流逐字SHA相同、消费者相关源码未变，因此复用原结果；本批没有再次调用消费者或模型。原4,065带ID决策、4,167状态、861片段、2,336相邻端点、5终局端点、415回合端点及362未知窗口仅为旧结果覆盖。原6条缺decision_id/observed_ts元数据保持排除，不补ID。完整候选认证为0来自工具明确不做归因的契约，不是零执行率或已证线上故障，不凭端点净差替逐来源联合校准。

## 验证、记录与交付

没有源码变动，未进行源码撤除/恢复、生产tsc/vitest或模拟；tests固定为tsc=null、vitest=null、cases=null，不借历史绿。没有合入、eval版本或shipped登记；其他角色行为保持等价。没有发布规则，无须执行实际上线后的双通知，亦不修改ops prompt。

只经根learner/ledger.py update追加本批proposal/report去处及具体waiting备注，by=learner:strategy-proposal；旧16项claim、first_run、prior、evidence、status、version和shipped历史保持，未重复support/repeat，未将旧shipped条目改成proposed。没有新游戏知识或重复代码提案，code_proposals保留本批十个原CLI id，implementation_domains=[]。

将本目录proposal.md与report.md交运维；原提案仍waiting，后续新局满足具体缺口再派。报告和原始材料均在本批git忽略的learner/runs内，保留旧报告及失败现场。本批无行为回退项。最终CLI读回、账本检查、gitleaks及HEAD/工作树核验见ledger-readback.json和completion-check.json；它们不替代生产测试。

最终核验（2026-10-16 19:51:50 CST）：HEAD/base一致，git status为空，源码/知识与index零差异；账本CLI 16条物理读回及保护字段核验通过，ledger check 0问题，gitleaks扫描本批材料186.84 MB退出0/无泄露。生产tsc/vitest/cases仍为null。

"""Verify frozen evidence envelopes and summarize only this batch's observations."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
RUNS = set(json.loads((OUT / "dispatch.json").read_text())["runs"])
MANIFEST = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
states, decisions, attempts, configs, plans = {}, {}, [], [], []
checks, streams = [], []


def check(name, condition, detail=None):
    checks.append({"name": name, "passed": bool(condition), "detail": detail})
    if not condition:
        raise AssertionError((name, detail))


def snapshot(envelope):
    state = envelope["row"].get("state") or {}
    run, combat = state.get("run") or {}, state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": envelope["line"], "run_id": envelope["run_id"],
        "floor": run.get("floor"), "turn": state.get("turn"),
        "screen": state.get("screen"), "in_combat": state.get("in_combat"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "block": player.get("block"), "energy": player.get("energy"),
        "powers": player.get("powers"),
        "hand": [{k: c.get(k) for k in ("index", "card_id", "upgraded", "resolved_rules_text")}
                 for c in combat.get("hand", [])],
        "potions": [{k: p.get(k) for k in ("index", "potion_id", "occupied")}
                    for p in run.get("potions", [])],
        "enemies": [{k: e.get(k) for k in ("index", "enemy_id", "current_hp", "max_hp", "is_alive", "move_id", "intents", "powers")}
                    for e in combat.get("enemies", [])],
    }


for stream in MANIFEST:
    name = stream["stream"]
    path = OUT / "evidence" / (name + ".evidence.jsonl")
    digest, counts, previous = hashlib.sha256(), collections.Counter(), -1
    source = Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")
    with source.open("rb") as original, path.open("rb") as evidence:
        for encoded in evidence:
            digest.update(encoded)
            item = json.loads(encoded)
            assert Path(item["source"]) == source
            assert item["offset"] > previous
            previous = item["offset"]
            assert item["offset"] + item["bytes"] <= stream["source_size"]
            original.seek(item["offset"])
            raw = original.read(item["bytes"])
            assert raw.endswith(b"\n") and hashlib.sha256(raw).hexdigest() == item["sha256"]
            row = json.loads(raw)
            assert row == item["row"]
            assert extract.run_identity(row) == item["run_id"] in RUNS
            counts[item["run_id"]] += 1
            if name == "states":
                states[item["line"]] = snapshot(item)
            elif name == "decisions":
                decisions[item["line"]] = row
            elif name == "sl-attempts":
                attempts.append({"line": item["line"], "run_id": item["run_id"], "row": row})
            elif name == "run-config":
                configs.append(row)
            elif name == "run-plans":
                plans.append(row)
    check(name + ":output_sha256", digest.hexdigest() == stream["output_sha256"])
    check(name + ":counts", all(counts[run] == stream["counts"][run] for run in RUNS))
    streams.append({"stream": name, "source_size": stream["source_size"], "rows_verified": sum(counts.values()),
                    "counts": dict(counts), "output_sha256": digest.hexdigest()})

(OUT / "state-snapshots.json").write_text(json.dumps(states, ensure_ascii=False, indent=2) + "\n")
(OUT / "sl-summaries.json").write_text(json.dumps(attempts, ensure_ascii=False, indent=2) + "\n")
targets = [272361, 272434, 272575, 272531, 272652, 272483, 272820,
           274131, 274156, 274185, 274235, 274237, 274267, 274272,
           274505, 274568, 274484, 274601, 274354]
(OUT / "decision-slices.json").write_text(json.dumps({n: decisions[n] for n in targets if n in decisions}, ensure_ascii=False, indent=2) + "\n")

# Keep turn-start endpoints and interruptions separate; do not assign a complete plan to a net state difference.
turns = collections.defaultdict(list)
current = {}
for n, s in states.items():
    run = s["run_id"]
    if not s["in_combat"]:
        current.pop(run, None)
        continue
    key = (s["floor"], s["turn"])
    if current.get(run) != key:
        turns[run].append(s)
        current[run] = key
(OUT / "turn-starts.json").write_text(json.dumps(turns, ensure_ascii=False, indent=2) + "\n")
summary = {"streams": streams, "checks": checks, "checks_passed": sum(c["passed"] for c in checks),
           "source_rows_verified": sum(s["rows_verified"] for s in streams),
           "states": len(states), "decisions": len(decisions), "attempt_rows": len(attempts),
           "configs": len(configs), "run_plans": len(plans)}
(OUT / "evidence-audit.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k not in ("streams", "checks")}, ensure_ascii=False))

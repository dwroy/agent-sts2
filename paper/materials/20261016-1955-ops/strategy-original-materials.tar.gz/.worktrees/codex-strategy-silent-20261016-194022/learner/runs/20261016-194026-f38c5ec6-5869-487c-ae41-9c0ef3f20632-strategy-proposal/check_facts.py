"""Check fixed observed endpoints without fitting a gameplay rule."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = json.loads((OUT / "state-snapshots.json").read_text())
decisions = json.loads((OUT / "decision-slices.json").read_text())
checks, facts = [], []


def check(name, observed, expected):
    checks.append({"name": name, "observed": observed, "expected": expected, "passed": observed == expected})


def power(items, ident):
    found = [p["amount"] for p in items if p["power_id"] == ident]
    return found[0] if len(found) == 1 else None


def enemy(s):
    living = [e for e in s["enemies"] if e["is_alive"]]
    assert len(living) == 1
    return living[0]


for a, b in [(272434, 272575), (272531, 272652), (272483, 272820), (274505, 274568), (274484, 274601)]:
    check(f"同指纹 decisions:{a}/{b}", decisions[str(a)]["fingerprint"] == decisions[str(b)]["fingerprint"], True)

for name, a, b, hp_loss, enemy_loss in [
    ("751 T2 首试", 278479, 278483, 13, 9),
    ("751 T2 第三试", 278620, 278623, 18, 18),
    ("751 T7 第二试", 278576, 278581, 13, 12),
    ("751 T7 第四试", 278697, 278702, 23, 18),
    ("751 T13 首试", 278528, 278532, 8, 17),
    ("751 T13 末试", 278865, 278869, 2, 11),
    ("KEN T10 第四试", 280588, 280592, 15, 2),
    ("KEN T10 第五试", 280651, 280655, 21, 4),
    ("KEN T5 第四试", 280567, 280572, 7, 1),
    ("KEN T5 末试", 280684, 280689, 5, 2),
    ("KV T5 第四试", 279460, 279465, 0, 36),
    ("KV T5 第五试", 279511, 279515, 0, 29),
]:
    x, y = states[str(a)], states[str(b)]
    assert x["run_id"] == y["run_id"] and x["floor"] == y["floor"] and y["turn"] == x["turn"] + 1
    ex, ey = enemy(x), enemy(y)
    assert ex["enemy_id"] == ey["enemy_id"] and ex["max_hp"] == ey["max_hp"]
    check(name + "净损血", x["hp"] - y["hp"], hp_loss)
    check(name + "敌净扣", ex["current_hp"] - ey["current_hp"], enemy_loss)
    facts.append({"name": name, "run": x["run_id"], "floor": x["floor"], "turn": x["turn"],
                  "state_lines": [a, b], "net_hp_loss": x["hp"] - y["hp"],
                  "net_enemy_hp_loss": ex["current_hp"] - ey["current_hp"],
                  "attribution": "仅本轮观测净差；不是完整候选或单卡因果"})

for n, dex in [(280572, 2), (280689, None)]:
    check(f"KEN states:{n}已建立敏捷", power(states[str(n)]["powers"], "DEXTERITY_POWER"), dex)

check("KV末试T4毒结后回升", [enemy(states[str(n)])["current_hp"] for n in [279559, 279560]], [327, 342])
check("KV末试T4前后毒层", [power(enemy(states[str(n)])["powers"], "POISON_POWER") for n in [279559, 279560]], [15, 14])
check("KV第四/五试T6毒", [power(enemy(states[str(n)])["powers"], "POISON_POWER") for n in [279465, 279515]], [20, 13])

for n, poison in [(280160, 2), (280161, 8)]:
    s, e = states[str(n)], enemy(states[str(n)])
    check(f"YQL states:{n}自爆末态", [s["hp"], s["block"], e["current_hp"], e["max_hp"], e["move_id"], e["intents"][0]["damage"]],
          [26, 13, 999999999, 999999999, "EXPLODE_MOVE", 41])
    check(f"YQL states:{n}毒层", power(e["powers"], "POISON_POWER"), poison)
check("YQL毒水槽变化", [states[str(n)]["potions"][0]["potion_id"] for n in [280160, 280161]], ["POISON_POTION", None])
check("PU胜线自爆前血挡来袭", [states["252435"]["hp"], states["252435"]["block"], enemy(states["252435"])["intents"][0]["damage"]], [24, 20, 42])
check("PU胜线实际奖励页", [states["252436"]["screen"], states["252436"]["hp"]], ["REWARD", 2])

potion_facts = []
for decision, before, after, slot, ident in [
    (274131, 280206, 280207, 0, "ATTACK_POTION"),
    (274156, 280232, 280233, 0, "STABLE_SERUM"),
    (274185, 280262, 280263, 0, "SPEED_POTION"),
    (274235, 280313, 280314, 1, "WEAK_POTION"),
    (274237, 280315, 280316, 0, "ATTACK_POTION"),
    (274267, 280348, 280349, 1, "GLOWWATER_POTION"),
    (274272, 280354, 280355, 0, "SKILL_POTION"),
]:
    d = decisions[str(decision)]
    check(f"KEN药水请求:{decision}", [d["chosen"]["action"], d["chosen"]["option_index"], d["expect"]["potion"]["id"]], ["use_potion", slot, ident])
    check(f"KEN药水槽:{before}/{after}", [states[str(n)]["potions"][slot]["potion_id"] for n in [before, after]], [ident, None])
    potion_facts.append({"decision": decision, "state_lines": [before, after], "slot": slot,
                         "potion": ident, "result": d["result"], "full_candidate_result": None})
check("KEN七次请求中pending数量", sum(p["result"].startswith("pending") for p in potion_facts), 3)

criteria = decisions["272361"]["questions"]["plan"]["criteria"]
criteria = {k: json.loads(v) if isinstance(v, str) else v for k, v in criteria.items()}
check("751 F13有药/无药当轮预测", [[criteria[k]["hp_lost"], criteria[k]["dmg"]] for k in ["plan2", "plan3", "plan5"]], [[8, 26], [8, 16], [8, 16]])
check("751 F13整战无药参考单列", "no potion for the rest of this fight" in criteria["plan5"]["no_potion_fight"], True)
check("751 F13无药即时线后来仍可能喝", "FLEX_POTION in 7/8" in criteria["plan3"]["potion_cost"], True)

report = {"checks": checks, "passed": sum(x["passed"] for x in checks), "total": len(checks),
          "endpoint_facts": facts, "potion_requests": potion_facts,
          "limitations": ["固定端点核验不是生产测试或受控整战重放", "不补齐敌回血、未截断伤害或单卡来源", "无源码修改；没有拟合新阈值"]}
(OUT / "fixed-facts.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"passed": report["passed"], "total": report["total"]}))
if report["passed"] != report["total"]:
    for item in checks:
        if not item["passed"]:
            print(json.dumps(item, ensure_ascii=False))
    raise SystemExit(1)

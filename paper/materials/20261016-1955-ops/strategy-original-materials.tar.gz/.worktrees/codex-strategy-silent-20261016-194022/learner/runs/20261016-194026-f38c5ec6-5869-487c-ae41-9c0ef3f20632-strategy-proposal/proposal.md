# 静默猎手本批十项策略提案核验

记录时间：2026-10-16 19:49:43 CST。
批次：20261016-194022-strategy-proposal。角色silent，仅本批六局SILENT A10；来源任务及原提案SHA详见dispatch.json、proposal-input-audit.json与十份原字节副本。
普通提案批次已核身份，不承接另一批专题。合入main后基线10e5e3e10630887b4a521c814c72e27eafb49528；只读live截点8b65dafb808eb54e965fc1c6c613462fad82306c。

十项均waiting。已有诊断仅为局部实现，不登记整项duplicate/implemented；没有新源码、知识、参数或live发布，不新建重复提案id。

| 原CLI id | 证据局/层/回合/原行 | 既有账本 | 具体等待条件 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820 | silent-0079、silent-0176 | 缺抽弃与重问后的完整候选身份、逐来源结算和保持后轮条件的整战对照；现有资源比较仅预测，单动作回执不认证完整执行。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3；F17 T7/T13/T17；decisions 272361，states 278500—278505 | silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176 | 持牌未决与持药未知已有窄实现；缺F13不饮药的完整实际后继及留药后战对照，无法拟合持有价或更改用药规则。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13；同366288原帧 | silent-0079、silent-0176 | 与366288共享一局六试；缺完整候选归属、受控后继与独立验证，不能把5/10血局部差额拟成探索门槛。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17 | silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176 | 分项模型和未知值提示已有实现；缺攻击、毒、荆棘、持牌失血、敏捷的联合逐来源实结算校准及跨战用药对照。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 第4/5试T5；states 279460—279465、279511—279515；末试T4 279559/279560 | silent-0102、silent-0019、silent-0020 | 同盘净扣敌36/29、双方零净损及次轮毒20/13可核；缺毛伤/回血逐来源归属和路线休息替代后继，删毒不构成已证保血。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T10 states 280160/280161；L9SGRBB5R698 F17 T14 sl 681；PU80F84P6HPN F17 T17 sl 717 | silent-0017、silent-0250、silent-0011、silent-0027、silent-0046 | 阶段与残壳饮毒事实已有实现，参考路径仍沿原始显示HP平局排序；缺新旧改序的完整后继及提前喝/不喝/留药受控分支。 |
| silent-proposal-9733bb80f445aeae | YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 states 252435/252436 | silent-0017、silent-0019、silent-0020、silent-0250 | 残壳毒2→8未改变41自爆，PU实际余2血胜可核；缺完整阶段估值、排序与用药时点的受控后继，局部阶段说明不关闭整项。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272 | silent-0019 | 七次请求和药栏消耗可核，三次接口回执仍pending；缺随机选牌、发光水后重问的完整执行收益与保留至Boss对照。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 第4/5试T10 decisions 274505/274568；第4/6试T5 274484/274601 | silent-0079、silent-0021、silent-0125、silent-0005、silent-0176 | T10多2敌净损付6血、T5省2血却延后敏捷是双向取舍；缺逐来源兑现、保持后轮条件的对照和时间靠后的独立验证。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T2/T5/T10；decisions 274354/274484/274601/274505/274568 | silent-0021、silent-0079、silent-0125、silent-0176 | 血价、无实体与能力窗口证据可核；现有预测及端点工具不认证完整候选，缺受控后继，不拟统一6血/2伤准入阈值。 |

原行为与拟议行为：当前保留候选、参考排序、HP护栏、药水和SL规则。完成项中，资源对照仍标execution=unverified；持牌预测保留actual_held_hp_loss=null；单动作回执保留whole_plan_executed=null；药水成本0与hold_hp=null分开；巨兽本体已结束与战斗仍未赢分开。未完成项沿原id等待完整候选执行归属、联合逐来源校准及后继分支。

反例：KEN T5省血同时延后敏捷，反驳只保血恒优；751 F13当前无药线的后续仍可能喝药，不能替整战无药；YQL残壳新增毒未减少当前41自爆，不能推导提前喝无用；PU本体结束后需覆盖自爆且实际余2血获胜，不能将占位体归零当胜利。KV删毒当轮双方都零净损，不能把少输出称保血。详见report.md及fixed-facts.json。

验证：原文SHA、显式局号/角色、各流source_size、逐行offset/bytes/SHA/JSON及固定端点分别核验；已有离线消费者仅读回原输入输出及SHA，只有相同输入和源码才复用，不重跑模型或模拟。局部端点不是完整候选认证。同一局六次SL仅算一局，不能拆成训练/独立验证；本批不拟权重或阈值。后续实现按原提案固定原答、最终动作、重问边界与真实状态，独立局按时间切分验证。无关角色和未观察进阶不外推。

预期影响：本批仅补本批核验和缺口追溯，不宣称改善胜率或经验已入库。将本文件与report.md交运维；代码提案仍由调度器据proposal_results保存waiting。将来实际源码上线后才登记commit/版本、通知Roy和由ops核shipped。回退：本批没有行为改动需要回退；原提案、失败、SL截断和未知均保留。

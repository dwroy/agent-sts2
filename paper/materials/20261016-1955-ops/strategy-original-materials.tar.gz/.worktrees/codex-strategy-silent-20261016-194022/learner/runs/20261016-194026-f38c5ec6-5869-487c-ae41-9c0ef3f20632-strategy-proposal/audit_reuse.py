"""Check immutable input equality before reusing prior offline consumer results."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PREVIOUS = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-183355/learner/runs/20261016-183402-4ef1a6d2-ab15-49d3-9baa-64a77624c833-strategy-proposal')
old = {x['stream']: x for x in json.loads((PREVIOUS / 'evidence/evidence-manifest.json').read_text())}
manifests = [(OUT / 'evidence', json.loads((OUT / 'evidence/evidence-manifest.json').read_text())),
             (OUT / 'evidence-runs', json.loads((OUT / 'evidence-runs/evidence-manifest.json').read_text()))]
checks = []
run_rows = []
for directory, manifest in manifests:
    for item in manifest:
        path = directory / f"{item['stream']}.evidence.jsonl"
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        same = digest == item['output_sha256'] == old[item['stream']]['output_sha256']
        assert same
        checks.append({'stream': item['stream'], 'old_source_size': old[item['stream']]['source_size'],
                       'new_source_size': item['source_size'], 'sha256': digest, 'matches_previous': same,
                       'counts': item['counts'], 'invalid_lines_global': item['invalid_lines'],
                       'incomplete_lines_global': item['incomplete_lines']})
        if item['stream'] == 'runs':
            with Path('/home/dw/Projects/agent-sts2/logs/runs.jsonl').open('rb') as source:
                for line in path.read_text().splitlines():
                    row = json.loads(line)
                    source.seek(row['offset'])
                    raw = source.read(row['bytes'])
                    assert hashlib.sha256(raw).hexdigest() == row['sha256']
                    assert json.loads(raw) == row['row']
                    assert row['row']['run_id'] == row['run_id']
                    assert row['row']['character'] == 'SILENT' and row['row']['ascension'] == 10
                    run_rows.append(row)
assert len(run_rows) == 6
(OUT / 'run-identity.json').write_text(json.dumps(run_rows, ensure_ascii=False, indent=2) + '\n')
reuse = json.loads((OUT / 'consumer-readback.json').read_text())
assert reuse['source_files_unchanged_from_previous']
reuse['new_input_equality'] = True
reuse['input_stream_checks'] = checks
reuse['note'] = '七流封套与原批逐字相同，消费代码未变；本批仅读回原产物及其SHA，没有重跑消费者、模型或模拟。'
(OUT / 'consumer-readback.json').write_text(json.dumps(reuse, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'equal_streams': len(checks), 'run_rows_verified': len(run_rows), 'consumer_rerun': False}))

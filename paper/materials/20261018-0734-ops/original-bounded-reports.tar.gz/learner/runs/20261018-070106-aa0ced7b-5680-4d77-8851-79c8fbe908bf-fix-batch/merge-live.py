import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/home/dw/Projects/agent-sts2')
scratch = Path(__file__).resolve().parent
live = root / '.worktrees/live'
branch = 'codex-fix-silent-20261018-070101'
base = '77c91f11ab6932c8b7871c1b06fe87adebfa381e'
result = {'merged': None}


def git(*args, check=True):
    return subprocess.run(['git', '-C', str(live), *args], capture_output=True, text=True, check=check)


def scan(name):
    with (scratch / name).open('w') as handle:
        subprocess.run(['gitleaks', 'git', '--staged', '--redact', '--no-banner', '--no-color'],
                       cwd=live, stdout=handle, stderr=subprocess.STDOUT, check=True)


def changed_notes():
    paths = git('diff', '--name-only', '--', 'notes').stdout.splitlines()
    return {p: hashlib.sha256((live / p).read_bytes()).hexdigest() for p in paths}


try:
    # The caller holds the original live-merge.lock throughout this process.
    while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'],
                         stdout=subprocess.DEVNULL).returncode == 0:
        time.sleep(10)
    if git('diff', '--cached', '--quiet', check=False).returncode:
        raise RuntimeError('live has an existing staged change; preserve its owner')
    git('add', 'notes/fight-value-backtest.md', 'knowledge')
    if git('diff', '--cached', '--quiet', check=False).returncode:
        scan('gitleaks-knowledge-refresh.log')
        git('commit', '-m', 'Refresh knowledge data', '-m',
            'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    before = git('rev-parse', 'HEAD').stdout.strip()
    source = git('rev-parse', branch).stdout.strip()
    own_paths = git('diff', '--name-only', base, source).stdout.splitlines()
    knowledge_paths = [p for p in own_paths if p.startswith('knowledge/')]
    result.update(before=before, source=source, own_paths=own_paths,
                  knowledge_overlap=knowledge_paths, notes_before=changed_notes())
    if knowledge_paths:
        raise RuntimeError('unexpected knowledge changes require an explicit conflict review')
    merged = git('merge', '--no-edit', branch, check=False)
    (scratch / 'live-merge.log').write_text(merged.stdout + merged.stderr)
    result['merge_rc'] = merged.returncode
    if merged.returncode:
        result['conflicts'] = git('diff', '--name-only', '--diff-filter=U').stdout.splitlines()
        if git('rev-parse', '--verify', 'MERGE_HEAD', check=False).returncode == 0:
            result['abort_rc'] = git('merge', '--abort', check=False).returncode
        result.update(after=git('rev-parse', 'HEAD').stdout.strip(), notes_after=changed_notes())
        raise RuntimeError('live merge failed; stop without resolving historical conflicts')
    result['integration_commit'] = git('rev-parse', 'HEAD').stdout.strip()
    with (scratch / 'live-sandbox-tests.log').open('w') as handle:
        checked = subprocess.run(['nice', '-n', '19', 'bash', 'tools/test-sandbox.sh'],
                                 cwd=live / 'agent', stdout=handle, stderr=subprocess.STDOUT)
    result['live_tests_rc'] = checked.returncode
    if checked.returncode:
        result['rollback_rc'] = git('reset', '--merge', before, check=False).returncode
        raise RuntimeError('live sandbox checks failed; restore the pre-merge commit')
    timestamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    line = (f'\n- {timestamp} 静默纯bug学习者：fix-queue-v4 '
            'infra-h0-414-host-fixed-test-stability-20261018/a406-fixed-deadlines '
            f'仅修read_report文件未显式关闭，源码{source}；证据0610原宿主'
            'original-full-check.log:57—70、tree a406c0fa，基础设施夹具无局号/层/回合，'
            '无对应bug-infra账本；撤源4败恢复19过，源码与合后原沙箱入口均0。'
            '不认定五题超时因果、不改对局行为/版本或shipped，其他已测候选沿原集成链。\n')
    with (live / 'paper/materials/decision-log.md').open('a') as handle:
        handle.write(line)
    git('add', 'paper/materials/decision-log.md')
    scan('gitleaks-live-record.log')
    git('commit', '-m', 'Record completion report resource fix deployment', '-m',
        'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    result['merged'] = git('rev-parse', 'HEAD').stdout.strip()
except Exception as error:
    result['error'] = str(error)
finally:
    (scratch / 'merge-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['merged'] else 1)

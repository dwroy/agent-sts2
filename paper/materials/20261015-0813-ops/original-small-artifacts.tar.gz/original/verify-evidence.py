"""Verify frozen source bytes and the dispatched Silent observations; no game simulation."""
import hashlib
import importlib.util
import json
import re
from collections import Counter
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location("extract", WORKTREE / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
job = json.loads((SCRATCH / "dispatch.json").read_text())["job"]
RUNS = set(job["runs"])
rows = {}
manifests = []
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected})


for folder in ("evidence", "evidence-extra"):
    for manifest in json.loads((SCRATCH / folder / "evidence-manifest.json").read_text()):
        stream = manifest["stream"]
        path = SCRATCH / folder / (stream + ".evidence.jsonl")
        counts = Counter({run: 0 for run in RUNS})
        digest = hashlib.sha256()
        values = {}
        with path.open("rb") as selected, (Path('/home/dw/Projects/agent-sts2/logs') / (stream + ".jsonl")).open("rb") as source:
            previous_offset = -1
            for encoded in selected:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item["run_id"] in RUNS
                assert item["offset"] > previous_offset
                previous_offset = item["offset"]
                assert item["offset"] + item["bytes"] <= manifest["source_size"]
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert raw.endswith(b"\n")
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                parsed = json.loads(raw)
                assert parsed == item["row"]
                assert extract.run_identity(parsed) == item["run_id"]
                if stream == "states":
                    assert parsed["state"]["run"]["character_id"].lower() == "silent"
                    assert parsed["state"]["run"]["ascension"] == 10
                if stream == "runs":
                    assert parsed["character"].lower() == "silent"
                    assert parsed["ascension"] == 10
                counts[item["run_id"]] += 1
                values[item["line"]] = item
        assert dict(counts) == manifest["counts"]
        assert digest.hexdigest() == manifest["output_sha256"]
        rows[stream] = values
        manifests.append(manifest)

check("explicit run-plans identity", extract.run_identity({"run": "751FN9QM9MHQ"}), "751FN9QM9MHQ")
check("nested state identity", extract.run_identity({"state": {"run_id": "751FN9QM9MHQ"}}), "751FN9QM9MHQ")
check("fingerprint identity", extract.run_identity({"fingerprint": json.dumps({"run": "751FN9QM9MHQ"})}), "751FN9QM9MHQ")
check("conflicting identities rejected", extract.run_identity({"run_id": "751FN9QM9MHQ", "run": "KEN58SH9SLZ6"}), None)
check("body-only mentions rejected", extract.run_identity({"text": "751FN9QM9MHQ"}), None)
check("selected run membership", {v["run_id"] for v in rows["runs"].values()} == RUNS, True)

decisions = rows["decisions"]
attempts = {}
for item in rows["sl-attempts"].values():
    row = item["row"]
    attempts[(item["run_id"], row["floor"], row["attempt"])] = item


def summary_turn(run, floor, attempt, turn):
    item = attempts[(run, floor, attempt)]
    return next(t for t in item["row"]["summary"]["turns"] if t["turn"] == turn)


def enemy_hp(text):
    return sum(int(hp) for hp, maximum in re.findall(r" (\d+)/(\d+)(?:, |$)", text))


pairs = [
    ("751 T2", 272434, 272575, 13, 18, 9, 18),
    ("751 T7", 272531, 272652, 13, 23, 12, 18),
    ("751 T13", 272483, 272820, 8, 2, 17, 11),
    ("KV T1", 273242, 273474, 0, 0, 28, 14),
    ("KV T5", 273400, 273450, 0, 0, 36, 29),
    ("KEN T5", 274484, 274601, 7, 5, 1, 2),
    ("KEN T10", 274505, 274568, 15, 21, 2, 4),
]
pair_records = []
for name, before_line, after_line, loss_before, loss_after, damage_before, damage_after in pairs:
    original = decisions[before_line]
    replacement = decisions[after_line]
    a, b = original["row"], replacement["row"]
    check(name + " same fingerprint", a["fingerprint"], b["fingerprint"])
    outcomes = []
    for item, expected_loss, expected_damage in [(original, loss_before, damage_before), (replacement, loss_after, damage_after)]:
        row = item["row"]
        turn = summary_turn(item["run_id"], row["floor"], row["sl_attempt"], row["turn"])
        following = summary_turn(item["run_id"], row["floor"], row["sl_attempt"], row["turn"] + 1)
        loss = turn["hp"] - following["hp"]
        damage = enemy_hp(turn["enemies"]) - enemy_hp(following["enemies"])
        check(name + " d" + str(item["line"]) + " net HP loss", loss, expected_loss)
        check(name + " d" + str(item["line"]) + " net enemy HP reduction", damage, expected_damage)
        outcomes.append({"decision_line": item["line"], "attempt": row["sl_attempt"], "turn": turn, "next_turn": following, "net_hp_loss": loss, "net_enemy_hp_reduction": damage})
    pair_records.append({"name": name, "run_id": original["run_id"], "floor": a["floor"], "turn": a["turn"], "same_fingerprint": True, "outcomes": outcomes, "sl_explore": b.get("sl_explore"), "scope": "observed_endpoints_not_gross_damage_or_controlled_whole_fight"})

states = rows["states"]


def state(line):
    return states[line]["row"]["state"]


def power(powers, name):
    return next((p["amount"] for p in powers if p["power_id"] == name), 0)


criteria = decisions[272361]["row"]["questions"]["plan"]["criteria"]
for key, damage in [("plan2", 26), ("plan5", 16)]:
    value = json.loads(criteria[key])
    check("751 F13 " + key + " predicted HP loss", value["hp_lost"], 8)
    check("751 F13 " + key + " predicted card damage", value["damage_dealt"], damage)
    check("751 F13 " + key + " sampled endings", "8/8" in value["rollout"], True)
dry = json.loads(criteria["plan5"])
check("751 whole-fight no-potion reference", "no potion" in dry["plays"].lower() or "no potion" in dry["rollout"].lower(), True)
check("751 current-turn dry line later drinks", "7/8" in json.loads(criteria["plan3"])["potion_cost"], True)
check("751 F13 consumed FLEX", [state(n)["run"]["potions"][0]["potion_id"] for n in (278403, 278404)], ["FLEX_POTION", None])
check("751 F13 actual HP endpoints", [state(n)["combat"]["player"]["current_hp"] for n in (278403, 278407)], [58, 50])

giant = []
for n in (280160, 280161):
    st = state(n)
    p = st["combat"]["player"]
    e = st["combat"]["enemies"][0]
    giant.append([p["current_hp"], p["block"], power(e["powers"], "POISON_POWER"), e["intents"][0]["total_damage"]])
check("YQL husk potion observed endpoints", giant, [[26, 13, 2, 41], [26, 13, 8, 41]])
check("YQL raw husk HP", state(280160)["combat"]["enemies"][0]["max_hp"], 999999999)
check("YQL death HP is clipped", state(280162)["combat"]["player"]["current_hp"], 0)
check("PU giant actual win", [attempts[("PU80F84P6HPN", 17, 5)]["row"][k] for k in ("result", "end_hp")], ["won", 2])
check("L9 giant husk summary", "999999999/999999999" in summary_turn("L9SGRBB5R698", 17, 1, 14)["enemies"], True)
check("PU giant husk summary", "999999989/999999999" in summary_turn("PU80F84P6HPN", 17, 1, 17)["enemies"], True)

potion_uses = [(274131, 280206, 280207, 0, "ATTACK_POTION"), (274156, 280232, 280233, 0, "STABLE_SERUM"), (274185, 280262, 280263, 0, "SPEED_POTION"), (274235, 280313, 280314, 1, "WEAK_POTION"), (274237, 280315, 280316, 0, "ATTACK_POTION"), (274267, 280348, 280349, 1, "GLOWWATER_POTION"), (274272, 280354, 280355, 0, "SKILL_POTION")]
for d, before, after, slot, expected in potion_uses:
    action = {"action": "use_potion", "option_index": slot}
    if expected == "WEAK_POTION":
        action["target_index"] = 0
    check("KEN potion d" + str(d), decisions[d]["row"]["chosen"], action)
    check("KEN potion s" + str(before) + "→" + str(after), [state(n)["run"]["potions"][slot]["potion_id"] for n in (before, after)], [expected, None])
for attempt in range(1, 7):
    check("KEN boss start HP attempt " + str(attempt), summary_turn("KEN58SH9SLZ6", 17, attempt, 1)["hp"], 75)
check("KEN early Dexterity", power(state(280569)["combat"]["player"]["powers"], "DEXTERITY_POWER"), 2)
check("KEN delayed Dexterity", power(state(280702)["combat"]["player"]["powers"], "DEXTERITY_POWER"), 2)
groups = json.loads((SCRATCH / "ken-boss-state-groups.json").read_text())
check("KEN six observed boss entries", len(groups), 6)
check("KEN entry HP and empty potion slots", [[g[0]["hp"], g[0]["potions"]] for g in groups], [[75, []]] * 6)
check("KEN attempt four first Dexterity", next(p["turn"] for p in groups[3] if p["dex"] > 0), 5)
check("KEN attempt six first Dexterity", next(p["turn"] for p in groups[5] if p["dex"] > 0), 9)
check("KEN T10 B2 difference", decisions[274568]["row"]["sl_explore"]["b2"], {"original": 0.385, "replacement": 0.127, "diff": -0.2583, "se": 0.0132})
for run in ("751FN9QM9MHQ", "YQL8RZ8BWN1E", "KEN58SH9SLZ6"):
    check(run + " correlated six attempts not six wins", [attempts[(run, 17, a)]["row"]["result"] for a in range(1, 7)], ["predicted_death"] * 5 + ["died"])

(SCRATCH / "paired-observations.json").write_text(json.dumps(pair_records, ensure_ascii=False, indent=2) + "\n")
(SCRATCH / "fixed-evidence-checks.json").write_text(json.dumps({"checks": checks, "passed": len(checks), "scope": "frozen_evidence_assertions_not_source_tests"}, ensure_ascii=False, indent=2) + "\n")
(SCRATCH / "evidence-verification.json").write_text(json.dumps({"verified_lines": sum(len(v) for v in rows.values()), "streams": manifests, "selected_bytes": sum((SCRATCH / ("evidence-extra" if m["stream"] in ("runs", "fight-plans") else "evidence") / (m["stream"] + ".evidence.jsonl")).stat().st_size for m in manifests)}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_lines": sum(len(v) for v in rows.values()), "checks_passed": len(checks), "pair_count": len(pairs)}))

# 静默猎手策略提案批次报告

记录时间：2026-10-15T08:10:49+08:00。task=strategy-proposal；character=silent；batch=20261015-080141-strategy-proposal。

完整base：`80105358066e092fecff2fa9ac5b4e53efb1a5c8`。开工git干净，普通流程合main无新增提交。本批十项均waiting；fixes=[]，merged=null，无源码/经验改动、提交、合入、新版本或shipped。

## 身份与来源

learn.json本批task/character/worktree/runs及十个proposal_ids核一致，reason=proposal；无research_request/implementation_request/proposal_repair。普通牌数请求属于20261010-150327，不匹配本批，不转入专题。十份原Markdown按原字节保存，SHA全匹配；12个原经验链接在knowledge/characters/silent/experience.json存在。仅处理本批原id。

六局runs原行均SILENT/A10、已经结束、全局victory=false；PU的F17第五次巨兽won且余2血单列。原局存在历史DeepSeek调用和dirty源码，不能宣称全部纯Codex或已恢复完整原运行树。

宿主启动命令指定gpt-6.1-sol/xhigh/default；用户本题指定high，可读原事件前120行无原生model/effort响应头，实际请求不能只凭启动参数报告已核。未调整会话或运行配置，未派下级agent。

## 原始证据

通过共用extract_evidence.py抽六默认流，另用同入口抽runs/fight-plans。各流冻结source_size，逐行重新读取原offset/bytes核SHA和JSON显式所属局，states与runs核角色/进阶；共8444行、87条材料断言、七组同指纹观察通过。

|流|冻结source_size（字节）|选中原行|
|---|---:|---:|
|states|12946236192|4167|
|decisions|1510390568|4071|
|sl-attempts|39971955|43|
|run-config|1726437|6|
|run-plans|7938323|21|
|brain|550277432|130|
|runs|331495|6|
|fight-plans|2233957|0|

states/decisions各2条全源无效行，brain1条全源无效行；未把它们强归本批。fight-plans该截点选中0行，只表示本次未选中，不能称原日志全局缺失。run-plans按run字段有21行；身份冲突和正文仅提及局号均拒收。原流增长不改变本批冻结材料。

材料见evidence/、evidence-extra/、evidence-verification.json、fixed-evidence-checks.json、paired-observations.json、selected-decisions.json、attempts.json、ken-boss-state-groups.json。所有原字节与来源指针保留，没有复制整个源码仓库。

## 支持、反例与未知

751 F17 T2净损13→18/净扣敌9→18；T7净损13→23/净扣12→18；T13净损8→2/净扣17→11。T7原提案的9→15为题面伤口径，本报告12→18为summary端点净扣含其他来源，差额6相同，不能混用口径或伪造反证。六次同局全败，后继不受控。

751 F13 T3 plan2/plan5模型损8且五轮8/8结束、卡牌伤26/16；plan3后继7/8喝不能当整战无药。实喝肌肉药后HP58→50，未实际执行的无药/留药至boss未知，表缺失成本0不当持有价0。

KV F33 T5删毒净扣36→29且均零损；T1删输出净扣28→14且均零损，后续另问结束。净端点不冒称独立毛伤、敌回血或单步导致整场失败；路线/休息未执行分支不填收益。

L9/PU/YQL占位体近十亿血不代表本体进度。PU第五次巨兽真实won/end_hp2，保留胜战；YQL末次喝毒药只有残壳毒2→8，HP26/挡13/来袭41不变，算术−2与死亡截断0分开。缺新参考排序、提前喝/不喝/留药的受控整战比较。

KEN七次耗药逐槽位与决策核；三个pending回执用真实状态补证，不能当整线执行。六次boss入口75血空栏。T10换线净损15→21只多净扣2；T5净损7→5却把2敏捷首次建立从T5延至T9，不能只按省血或多牌面伤排序。B2差/误差是旧模型输出，不当实盘胜率。

没有从这些局拟合参数，没有新的机制反证或新经验；保留已有支持和限制，不关闭父学习要求、不声称消费者采用。

## 当前源码边界

只读核live HEAD=`52046a3deaa359adbafdd9e6d3e96c2527017f49`，13叶工作树与该提交一致、对应源码提交均实际live祖先。祖先与文件blob读回保存source-readback.json；这里的提交是既有实现，本批没有合入。

|源码|实际live祖先commit|base与live同字节|
|---|---|---|
|agent/src/reflex/silent-sl-resource-comparison.ts|`a8b1f8be153fe4f3a34146117546c2178f2e446b`|是|
|agent/src/reflex/silent-sl-comparison.ts|`a8b1f8be153fe4f3a34146117546c2178f2e446b`|是|
|agent/src/reflex/silent-held-loss.ts|`05cd292c6f01bb31e406473d3a9843e659d62b93`|是|
|agent/src/reflex/silent-potion-reference.ts|`04921bd785ac6838066522f91ea0bb6ab95cb6a1`|是|
|agent/src/reflex/silent-selection-audit.ts|`05cd292c6f01bb31e406473d3a9843e659d62b93`|是|
|agent/src/reflex/silent-selection-dispatch.ts|`bade647f9fe4c9103b40e2f26b26296692ad24b7`|是|
|agent/src/reflex/silent-giant-potion.ts|`d5e20aa4dd44168ce30944dfcce74f8322144953`|是|
|agent/src/reflex/combat-plan.ts|`06c6e8c6da5d6e3d5764c2b506e30202a4ca70f4`|是|
|agent/src/reflex/potion-cost.ts|`e1a467e18a0dfa8d99046a24ff4c0e1af59278c8`|否，保存差异patch|
|agent/src/sl/attempts.ts|`0d092f6b928a6221eabf3516abad25c48ceaac9c`|是|
|agent/src/sl/explore.ts|`0d092f6b928a6221eabf3516abad25c48ceaac9c`|否，保存差异patch|
|agent/src/reflex/turn-solver.ts|`8e196be494ada9a33dac3d897a0671a5b14e0e5b`|是|
|agent/src/hand/loop.ts|`767ba5f1ca98e1ad72a1a5ba172836d0af13e97d`|是|

资源对照scope=current_turn_prediction、execution=unverified；candidate_comparison.actual_turn_result=null；selection_audit.actual_turn=null；selection_dispatch.scope=single_action_receipt且whole_plan_executed=null。持牌事实保留弃牌未决与实际失血未知，药值引用保留hold_hp=null。巨兽阶段/末态展示已实现，anchorRank仍沿原存活轮与原显示残血排序。两叶base/live差异只是历史Dai/Roy注释，patch保留，不热更新冻结代码。

## 十项处置

|原id后缀|证据|既有账本|处置|
|---|---|---|---|
|366288801d9150d9|751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820|silent-0079, silent-0176|waiting|
|85929bdfc8a3fc1b|751FN9QM9MHQ F13 T3、F17 T7/T13/T17；d272361/272362，s278403/278404/278407|silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176|waiting|
|efd9f83ee9e1a6dc|751FN9QM9MHQ F17 T2/T7/T13；同上三组与sl-attempts945—950|silent-0079, silent-0176|waiting|
|131042659448ae74|751FN9QM9MHQ F13 T3、F17 T7/T13/T17；d272361与异鱼原状态/summary|silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176|waiting|
|990f054036609447|KV0JHNJCKXLS F33 T1/T5；d273242/273474、273400/273450，续问273451/273480|silent-0102, silent-0019, silent-0020|waiting|
|e18d3f18e6cac2a0|L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17/T15；YQL8RZ8BWN1E F17 T10/T13|silent-0017, silent-0250, silent-0011, silent-0027, silent-0046|waiting|
|9733bb80f445aeae|YQL8RZ8BWN1E F17末次T10；s280160/280161/280162；PU F17第五试T15|silent-0017, silent-0019, silent-0020, silent-0250|waiting|
|c51468c5e8ba6668|KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1,T2/F15T1；d274131/156/185/235/237/267/272|silent-0019|waiting|
|86a7db08d1a31976|KEN58SH9SLZ6 F17 T5/T10；d274484/274601、274505/274568；s280569/280702|silent-0079, silent-0021, silent-0125, silent-0005, silent-0176|waiting|
|e282a9131b99129a|KEN58SH9SLZ6 F17 T5/T10；原经验三链接及上述两组原行|silent-0021, silent-0079, silent-0125, silent-0176|waiting|

逐项支持、反例、既有账本、缺数据、预期行为、验证与回退见proposal.md及assessment-items.json。proposal_results逐项等待原因见proposal-results.json，不将预测或部分子实现登记完整duplicate/implemented，不新造id。

## 验证与交付

材料第一轮断言失败：WEAK_POTION决策具有target_index=0，而自建预期遗漏该字段；原脚本副本verify-evidence-first.txt与evidence-check-first.log保留。按原动作补齐预期目标后，87条材料断言全部通过（evidence-check-final.log）；这不是生产代码失败或降低生产断言。

无生产源码改动，撤源码失败/恢复通过不适用，tsc/vitest/cases均null，未运行源码套件、LLM、网络或play。原CLI提案链接保留；账本仅追加本批where/note追溯，既有claim/首证/prior/evidence/status/version保持，不重复计support，不把原shipped降为proposed。真实CLI回执另存。

最终gitleaks和tracked-clean/HEAD读回另存本目录；无需源码提交或发布，原失败材料和工作树交调度器保留。本批不写实际未发生的上线通知、eval版本或shipped。

提案总表：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-080141/learner/runs/20261015-080144-e94fbeee-92f7-4c5b-aa88-2fdc2e55feeb-strategy-proposal/proposal.md。报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-080141/learner/runs/20261015-080144-e94fbeee-92f7-4c5b-aa88-2fdc2e55feeb-strategy-proposal/report.md。

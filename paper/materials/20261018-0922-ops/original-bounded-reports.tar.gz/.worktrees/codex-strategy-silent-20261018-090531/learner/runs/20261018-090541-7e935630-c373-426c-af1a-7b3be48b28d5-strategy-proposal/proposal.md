# 静默猎手策略提案逐项核验

批次：20261018-090531-strategy-proposal。记录时间：2026-10-18T09:20:48+08:00。
基线：34a42921086a92925dc55d1608e06760440e55d2。本批只消费已领取十个原ID；不新建同题ID，不修改原提案。

十项完整目标均保留waiting。已存在的窄实现逐项核对来源源码和实际live祖先；没有把局部实现或这次原始证据复算当整项duplicate、自然消费或新行为收益。

证据：本批十个锚点，加原提案明确引用的五个同角色来源局。十五局身份均由runs.jsonl核实；A1/A7/A9/A10分别保留，只对各自观察分支作结论。同一局多次SL不作独立样本。本次没有新策略参数或新发现需新账本ID。

## silent-proposal-08eaa60bcc449852

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md
原文SHA256：4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016。本批字节副本：silent-proposal-08eaa60bcc449852.original.md。
关联账本：silent-0019, silent-0020。来源任务：experience-update；实现任务：strategy-proposal。

证据与反例：KEN58SH9SLZ6 A10 F3 T2、F4 T1、F5 T2、F11 T1/T2、F15 T1共7次饮用；F12 26/76→53/81、F16 46/81→75/86；F17六试空药。原始饮用动作见ken-drinks.json，六场胜战净损0/3/0/37/6/0合46见ken-combat-rooms.json及复盘5524起。F15零损仍实际用两药，是不能以零损倒推不用药也零损的反例。

现有实现核查：持药成本仍由potion-cost.ts按表与连战reserve读取；本批未校准新值。

处置：waiting。缺同入口、牌组、后续动作和预算下不用、早用或留至Boss的成对整战结果；七次饮用和两次真实休息不能校准持药价。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-92920295a648b540

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md
原文SHA256：f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf。本批字节副本：silent-proposal-92920295a648b540.original.md。
关联账本：silent-0228, silent-0255。来源任务：postmortem；实现任务：strategy-proposal。

证据与反例：TXZ6RVMQA09D A10 F48第二/三次T6：states 281479→281484实际损3/扣敌36，281535→281539实际损0/扣敌27；第三次T10首胜留4，F49 states 281565→281566开场4→0、出牌0、敌仍111。三个尝试后续牌不同；不能把局部保3血与首战获胜拼成连续通关。

现有实现核查：continuationInput的源码祖先a8b202e34e94b11a340a8733800f7018688371b8已传首场实际样本HP、剩余药和复活；既有功能不重写。

处置：waiting。缺固定后续抽牌、生成、选择、药栏及复活资源的两战成对结果；少损3且少伤9、首胜4血后开场死不能证明新SL线或终局权重更优。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-a327449c331efbc1

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md
原文SHA256：e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925。本批字节副本：silent-proposal-a327449c331efbc1.original.md。
关联账本：silent-0079, silent-0018。来源任务：postmortem；实现任务：strategy-proposal。

证据与反例：WQZVENQ7DTRP A10 F33第二/三次T9：decisions 275894/275960，states 282075→282079为13损/24扣，282144→282148为22损/39扣；相同初始26血/敌184血及手牌。反例：第二/末次T7均扣24，实际损0/4；结束动作前沙坑4/5，下一玩家轮初3/4（282066→282072、282330→282336），均多1而非无收益。末次仍死亡。

现有实现核查：66283dd9982bdd7f480da7a4d9bfefea0572a9ac提供resource_comparison；0e4fe4df89a06682468e0e4716c12126e76369d5补敌方结算后沙坑/结束战斗诊断。其execution明确unverified，不能冒成实际动作验收。

处置：waiting。当轮血伤、毒及沙坑差额诊断已有live子实现；缺固定后继、同预算整战胜负和独立验证，不能拟合血伤或延时排序阈值。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-a099e89437e942bb

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md
原文SHA256：e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2。本批字节副本：silent-proposal-a099e89437e942bb.original.md。
关联账本：silent-0030, silent-0257, silent-0258。来源任务：experience-update；实现任务：strategy-proposal。

证据与反例：九个提案来源局的42次狡诈饮用由实际槽位移除、手牌相邻帧和42个use_potion决策共同确认：37次添3、2次添2、3次添0；新增小刀均升级。WQZ F33第五次T11手8→10→10→10，末次5→8→10→10，重复观测帧另保留；容量不足仍只见本局，六次SL不扩成六局。其余八局均有独立归属证据；未证明完整穿插必胜。

现有实现核查：5b56a452bb9be14d620b368ec46974c1b57901ca已实现狡诈生成、扣锁定手位、剩余小刀结转；观察的保留组合及完整派发仍另验。

处置：waiting。生成、手位截断和剩余小刀结转已有live子实现；仍缺计划妥当保留、跨抽牌重问、SL恢复与完整穿插实际派发的联合验证。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-47910f82a1fdd98f

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md
原文SHA256：d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd。本批字节副本：silent-proposal-47910f82a1fdd98f.original.md。
关联账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。来源任务：experience-update；实现任务：strategy-proposal。

证据与反例：TXZ A10 F43/45/46/48/49出牌前分别70→66、52→48、62→58、60→56、4→0；完整五对原帧281312/313、281338/339、281367/368、281399/400、281565/566。末场22攻击尚未执行。WQZ的两向取舍作为反例。已观察遗物/药栏组合之外，未知回血与自动复活顺序不从此推广。

现有实现核查：5b56a452bb9be14d620b368ec46974c1b57901ca建立限定王室猛毒开场；当前silent-opening.ts限定已观察遗物集合和CombatOnly药栏。a8b202e34e94b11a340a8733800f7018688371b8的连战接续不虚补新鲜资源。

处置：waiting。受限王室猛毒开场和同样本资源接续已有live子实现；未知回血或复活组合时序、留药及SL完整后继和两战联合校准仍缺证。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-f1374df72d8e6a25

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md
原文SHA256：df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0。本批字节副本：silent-proposal-f1374df72d8e6a25.original.md。
关联账本：silent-0019, silent-0020, silent-0050, silent-0253。来源任务：postmortem；实现任务：strategy-proposal。

证据与反例：1913SE84AXQF A10 F29胜61→46，F31入口46；Q6M2Y34MWKRE A10 F2 T1早喝敏捷双挡候选为0损而实选线损12，T3才实际饮用；F8入口57、胜后2，F9 T2死亡。F8 T4紧勒漏算有独立机制来源，不作为药价拟合。Q6 F5/F6零损且留药，反驳一律早喝；无完整替线实打。

现有实现核查：当前potion-cost/rollout按成本和后继估值运行；没有本批证据支持替换现参数。

处置：waiting。缺隔离机制误差后、同入口同预算的不用、早用或留药整战及下一战成对结果；局部药水候选不足修改药价或终局权重。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-38a49e6c97f31eea

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md
原文SHA256：6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0。本批字节副本：silent-proposal-38a49e6c97f31eea.original.md。
关联账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。来源任务：experience-update；实现任务：strategy-proposal。

证据与反例：Q6 A10 F8 T4 states 282887—282892敌HP103→95→85→85→83→80，紧勒逐牌与三毒分开；1913 A10 F31 T2弃磨蚀时能量3不变，后来双防御与逐击荆棘仍未保证存活。对再生/临时敏捷的本两局证据可复查，原17饮/40饮全历史分母本批未重算。普通付费施放等价不代表弃牌路径已闭合。

现有实现核查：66283dd9982bdd7f480da7a4d9bfefea0572a9ac覆盖普通紧勒受限分支；a5f588dfdb3fd254fded2d6cacb646672b90cc14覆盖普通磨蚀付费出牌属性。付费Power映射不等价于弃牌副作用通路。

处置：waiting。普通紧勒及普通磨蚀付费出牌已有live子实现；弃磨蚀、增益分源、再生或自动触发与SL恢复的联合消费者及完整后继未齐。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-ef0e38a5dbd3bc07

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md
原文SHA256：d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5。本批字节副本：silent-proposal-ef0e38a5dbd3bc07.original.md。
关联账本：silent-0019, silent-0020, silent-0021。来源任务：experience-update；实现任务：strategy-proposal。

证据与反例：1913 A10 F24实际锻造，F28休息+21至61，F29胜至46，未来F32营火未到；Q6 A10 F7实36→57、F8胜后2、F9死。未来营火不能当现在到账，路线条件与上限变动另算；两局不是相同敌组/构筑的路线随机对照。原109局宽统计只引用原报告，不冒称本批全量复算。

现有实现核查：本批未证实一个与动作条件完全相同的新路线传递缺陷，未新增公式或固定阈值。

处置：waiting。缺另一营火动作、事件或路线及用药时点的受控完整结果；敌人、构筑、上限和实际动作条件混杂，不能支持路线或终局参数拟合。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-7f820c02d39bfaea

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md
原文SHA256：bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105。本批字节副本：silent-proposal-7f820c02d39bfaea.original.md。
关联账本：silent-0079。来源任务：postmortem；实现任务：strategy-proposal。

证据与反例：NHA2KW0RB7VP A10 F33 T1首试/末试可操作入口均30血，首试14挡至下一轮29血（1损）、敌合408→400（净扣8），末试8挡至23血（7损）、敌合408→384（净扣24）；states 283391/283397、283502/283507。净扣含次轮自动伤，不都称卡牌直伤。生存者弃原案精确切击后重规划，旧题案不能直接视作完整执行；六试皆败，无一独立成功。

现有实现核查：66283dd9982bdd7f480da7a4d9bfefea0572a9ac的诊断覆盖血伤差；sl/explore.ts仍走B2 notWorse或rollout deathShare等现有门槛，没有借旧全败局证明新排序优于现状。

处置：waiting。饱和SL的资源差额诊断已有live子实现；缺同预算排序校准、跨弃牌完整执行归属和成对整战后继，不能由同局六败确定新SL门槛。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

## silent-proposal-04b6b430759815ed

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md
原文SHA256：188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58。本批字节副本：silent-proposal-04b6b430759815ed.original.md。
关联账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。来源任务：experience-update；实现任务：strategy-proposal。

证据与反例：NHA A10 F33 T2同招/−2力量/1虚弱时朝向使显示1→2；F17 T1七/六/五手精确切击1/3/5。K3676LU8B0UH A1 F30 T2升级带毒刺击4毒实际8（states217009/217010）；SADL3CGYTGSR A7 F45及NHA F17/F33支持限定首次放大。NHA 283391/283394/283395/283396同一油灯遗物对象stack一直为null，不能据持有或轮数虚构已消费状态。缺其他X/升级/叠层完整后继，三局不同进阶不混拟A10阈值。

现有实现核查：68711002f15b298b8863d2258ee5da236da151d2覆盖限定蟹朝向；8b9bacbebb20eaaa1133a9945da6c7abfcda745d覆盖普通精确切击相应手数。源码中其他蟹药水限定事实不能替代本提案首次油灯消费状态。

处置：waiting。蟹朝向和普通精确切击已有live子实现；油灯对象stack在首次消费前后均为空，跨动作、新战及SL恢复缺可验证消费状态与联合消费者；未观察组合仍未覆盖。

预期行为：保留当前生产规则，后续只在本角色、已观察条件内完成所缺数据与联合验收后再调整。原案、替线、实际动作及整战结局分别记录。
验证方法：先重放上述冻结原始帧，保持药槽、能力来源、选择和结算时点；需要价值/排序参数时，较早独立局训练、较晚独立局验证，同局SL同组。机械子公式不以整局获胜作为验真的替代。未知字段保留未知，不能用零填齐。
回退：本批无源码修改；未来单项实现按独立提交回退，保留原证据、失败日志和并行刷新数据。

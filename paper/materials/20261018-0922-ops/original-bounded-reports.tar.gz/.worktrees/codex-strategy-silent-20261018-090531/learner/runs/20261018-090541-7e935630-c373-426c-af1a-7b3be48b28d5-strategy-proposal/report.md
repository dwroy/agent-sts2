# 静默猎手策略批次报告

记录时间：2026-10-18T09:20:48+08:00。

十个派发提案均已核验并保留waiting；没有新源码实现、提交、合入或行为发布。原因是现有窄实现尚未覆盖原提案完整验收，其余价值/排序变化仍缺受控后继数据。逐项证据、反例、账本、旧/拟议行为、验证与回退见[proposal.md](proposal.md)，机械处置见proposal-results.json。不是将报告结束当作父要求完成。

## 身份与基线

- task=strategy-proposal，character=silent，batch=20261018-090531-strategy-proposal，reason=proposal；根learn.json行的工作树和十个proposal_ids完全匹配。无research_request、implementation_request、proposal_repair，本批不进入专题或实现请求流程。普通专题文件绑定另一批，未读取它的work_spec/manifest。
- 起始HEAD=ac8eca0c0fad135819157637ffb8b594edf7371f且工作树干净；按普通流程git merge --no-edit main快进，无冲突；report.base=34a42921086a92925dc55d1608e06760440e55d2。快进仅两份文档共23行。后续不追合移动中的main。
- 保存了dispatch.json、十个原提案及其SHA、selected-proposals.json、完整所选历史与31条原账本快照。当前26个相关Silent经验条目全部存在且active；这只证明文件内容，不证明本批自然采用或获益。
- 启动器声明Codex/gpt-6.1-sol、service_tier=default、xhigh；thread.started为01a14c8b-1c92-7f33-857b-6456e4c163c8。题面要求high与宿主声明xhigh有差异；本批未改原线程、宿主参数或配置。未找到对应本地原生session文件，不能把启动参数冒作实际请求模型核验完成；该运行身份限制交运维核回。

## 原始证据与可复现性

共十五局：十个dispatch锚点全部分析；原提案补充1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。两组runs-identity.json分别保存角色、进阶和历史dirty code声明，未把dirty标签还原成确定运行源码。未读其他角色私有知识、游戏二进制或外部资料。

两次均使用本工作树learner/extract_evidence.py共用入口，八流分别冻结source_size、每行offset/bytes/SHA与计数，保存于evidence/和supplemental-evidence/。audit_evidence.py逐行重开原日志核字节SHA、解析正文、显式所属局、截点及输出SHA；共19929条全部一致：states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、runs15、fight-plans0。两组局号不交叠。源states/decisions/brain各2条坏行是同一源截点观察，不能双计新样本，也不能归入任何目标局；fight-plans在所存截点选中0行，不能据此断言原历史记录缺失。

逐行校验和算术复算是离线材料审计，不是生产源码测试、消费者回放、模拟胜率或自然大脑消费。旧原案的105/109局及其他全史统计本批未重做，不拿十五局冒称全历史覆盖。没有读取新的无关局扩选题。

## 关键复算与结论

- KEN七个use_potion动作和两次休息资源链已复核；六场胜战净损合46，F5赢仍损37，F15零损仍耗两药。没有“未喝也相同”对照，不能校准持药价。
- TXZ第二/三次F48 T6实损/敌净扣为3/36与0/27；第三次首胜只留4，F49可操作前4→0、出牌0且敌111。首战改善与连续通关分别验收，不能从未校准0%决定SL新阈值。五个限定开场四血扣除均核原帧。
- WQZ第二/三次F33 T9同盘面实损/敌净扣为13/24与22/39，替线多花9血得15伤。反例T7多花4血、同扣24却延时1：结束动作前沙坑4/5，敌方结算后3/4，不能混用时点或强行只保血。
- 九个提案来源局的42次狡诈饮用逐一匹配动作及前后帧：37次添3、2次添2、3次添0，新小刀升级均真，容量受限仍只来自WQZ同一局。现有生成模型已覆盖相应窄分支；完整保留/穿插/恢复联合验证仍未齐。
- Q6紧勒逐牌窗口独立复核103→95→85→85→83→80；当前普通紧勒已有窄实现。NHA首/末T1实损1/7、跨轮敌净扣8/24复核，自动伤与卡牌直伤分开；同局六败不能训练新SL门槛。
- 油灯遗物对象在首次施负面前后stack均为null，持有不是已验证的消费状态。普通精确切击和限定蟹朝向已有源实现，但不等于首次消费跨动作/新战/SL恢复及完整能力兑现已闭合。

## 源码核查与边界

source-provenance.json、additional-source-provenance.json固定11份基线源码blob/SHA、逐项来源提交和当时live工作字节SHA，source/保留.txt原字节；两份diff.patch保留base→live以及live工作差异。live观察HEAD=9d9f5adb00766a6a3865c46b301bfd62c7ddd7da；11份中5份工作字节不同，不宣称两个整树等价，也不合并或覆盖并行修改。下列提交均实际核为live祖先，仅支持所列子项：

| 子项 | 已有源码提交 |
|---|---|
| 普通紧勒与SL当轮资源差额 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac |
| 沙坑/结束战斗诊断 | 0e4fe4df89a06682468e0e4716c12126e76369d5 |
| 狡诈生成/容量/剩余刀与限定王室猛毒开场 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| 连战同样本资源传递 | a8b202e34e94b11a340a8733800f7018688371b8 |
| 普通磨蚀付费出牌属性 | a5f588dfdb3fd254fded2d6cacb646672b90cc14 |
| 限定蟹朝向 | 68711002f15b298b8863d2258ee5da236da151d2 |
| 普通精确切击相应手数 | 8b9bacbebb20eaaa1133a9945da6c7abfcda745d |

原提案要求超出这些子项，十项均不登记implemented/duplicate，不新增同题id。没有只因其为Roy原定规则而搁置；真正限制是所述证据和输入/消费者合同未齐。所有实现领域为空，不改非目标角色行为。

## 验证、记录与交付

材料入口material-audit-first.log实际退出0，逐行校验19929条；additional-material-checks.json另核五组关键窗口。开发中草稿曾把一个重复观测帧误写为新增后手数，执行断言前已按原帧改为5/8/8/10/10/10；没有改日志或把重复帧当动作。此处的0只对应材料脚本，不填生产tests。

没有生产源码变更，不进行撤源码/恢复测试，tsc/vitest/cases均null；没有运行test-sandbox，也不声称历史测试在本树通过。无源码提交，因此不触发提交前扫描/Co-Authored-By、live锁合入、eval编号、shipped或上线双通知。不运行play、不推送、不调用LLM/网络、不安装依赖。

已有31条账本只通过根learner/ledger.py update追加本批proposal.md/report.md去处和逐项waiting说明；不新增support/repeat分母、不覆盖claim/prior/first_run/evidence/status/version/effect，不将旧shipped经验降级为本批proposed。CLI输入、输出与保护字段读回另保存；最终完成状态由调度器/运维按本回报逐项记处置，不自行改learn.json或专用队列状态。

本批交付完整base、fixes=[]、merged=null、tests三null和十项proposal_results。父提案保留待新数据，原日志、失败历史、提案及工作树现场保留，由原调度器按实际验收回收；不在仍运行时删除自身工作树。

最终读回：根账本CLI一次追加31行退出0，31条保护字段全部保持、proposal.md与report.md链接均读回；十份原提案字节SHA保持，十个派发ID与十个waiting处置逐一一致。最终HEAD仍等于完整base，git status --porcelain为空。详见ledger-updates.result.json、ledger-readback.json、workspace-verification.json与result.json。

from pathlib import Path
import json,hashlib,subprocess,os
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1859';pub=r/'paper/materials/20261015-1859-ops';dest=p/'final-files';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,env=None,data=None):return subprocess.check_output(['git',*a],env=env,input=data,stderr=subprocess.PIPE)
for scan in ['final','helper','archive']:assert json.loads((p/f'{scan}-gitleaks.json').read_text())==[]
m=json.loads((p/'record-manifest.json').read_text());base=m['base'];assert git('rev-parse','HEAD').decode().strip()==base and not git('diff','--cached','--name-only').strip()
for name in ['final-gitleaks.log','helper-gitleaks.log','archive-gitleaks.log','final-ledger-check.log']:
 f=pub/name;b=f.read_bytes();rel=str(f.relative_to(r));out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);m['paths']=[x for x in m['paths'] if x['path']!=rel]+[{'path':rel,'bytes':len(b),'sha256':sha(b)}]
idx=p/'records.index';env={**os.environ,'GIT_INDEX_FILE':str(idx)};git('read-tree',base,env=env)
for row in m['paths']:
 path=row['path'];b=(dest/path).read_bytes();assert sha(b)==row['sha256'];oid=git('hash-object','-w','--stdin',data=b).decode().strip();git('update-index','--add','--cacheinfo','100644',oid,path,env=env)
tree=git('write-tree',env=env).decode().strip();changed=git('diff','--name-only',base,tree).decode().splitlines();assert set(changed)=={x['path'] for x in m['paths']};assert (pub/'final-ledger-check.log').read_text().endswith('0 problem(s)\n');assert all((x.startswith('paper/materials/') or x.startswith('paper/data/')) or x in ['notes/for-roy.md','ops/inbox-dev.md','notes/lessons.md'] for x in changed)
msg='Record unchanged Silent proposal dispositions and original material-check corrections\n\nRetain all ten original waiting proposals, thirty-two trace-only ledger updates and original learner artifacts including failed probe preparation and limited consumer coverage. No source, test, merge, release, dataset generation or game action.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n';commit=git('commit-tree',tree,'-p',base,data=msg.encode()).decode().strip();idxpath=Path(git('rev-parse','--git-path','index').decode().strip()).resolve();lock=Path(str(idxpath)+'.lock');fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);published=False
try:
 assert git('rev-parse','HEAD').decode().strip()==base and not git('diff','--cached','--name-only').strip()
 with os.fdopen(fd,'wb') as out:out.write(idx.read_bytes());out.flush();os.fsync(out.fileno())
 git('update-ref','-m','ops: record unchanged 184302 strategy dispositions','HEAD',commit,base);published=True;os.replace(lock,idxpath)
finally:
 if lock.exists() and not published:lock.unlink()
for row in m['paths']:assert sha(git('show',commit+':'+row['path']))==row['sha256']
assert not git('diff','--cached','--name-only').strip();m.update(commit=commit,tree=tree);(p/'record-manifest-final.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');(p/'commit-readback.json').write_text(json.dumps({'commit':commit,'parent':base,'tree':tree,'ordinary_index_empty':True,'all_owned_blobs_verified':True,'paths':changed},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'commit':commit,'paths':len(changed),'all_owned_blobs_verified':True,'ordinary_index_empty':True}))

from pathlib import Path
import subprocess, json, hashlib, re, os, tarfile, importlib.util
root = Path.cwd(); r = root
p = r / 'ops/codex-ops/record-staging/20261015-1859'
pub = r / 'paper/materials/20261015-1859-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-184302-strategy-proposal'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions'] == report['proposal_results']
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and all(x is None for x in report['tests'].values())
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
final = json.loads((s / 'final-validation.json').read_text())
assert final['base'] == report['base'] and final['git_status_clean'] and final['diff_empty'] and final['dispatch_still_matches'] and final['all_waiting'] and final['proposal_count'] == 10
for path,ref in final['artifacts'].items(): assert sha((s/path).read_bytes()) == ref['sha256'] and (s/path).stat().st_size == ref['bytes']
ev = json.loads((s/'material-validation.json').read_text()); assert ev['verified_rows'] == 6606 and sum(sum(x['counts'].values()) for x in ev['streams']) == 6606
assert len(ev['checks']) == 19 and all(x['passed'] for x in ev['checks']) and ev['product_tests'] is None
consumer = json.loads((s/'consumer-probe-r4.stdout.json').read_text()); assert len(consumer['checks']) == 4 and all(consumer['checks'].values())
assert (s/'consumer-probe-r4.exit.txt').read_text().strip() == '0' and (s/'consumer-probe.exit.txt').read_text().strip() != '0' and (s/'consumer-probe-r2.exit.txt').read_text().strip() != '0'
ledger_validation = json.loads((s/'ledger-validation.json').read_text()); assert ledger_validation['updated_entries'] == 32 and ledger_validation['protected_values_unchanged'] and ledger_validation['cli_exit'] == 0
source = json.loads((s/'source-readback.json').read_text()); assert len(source['files']) == 14 and source['base'] == report['base']
for x in source['files']:
    a = git('show', report['base'] + ':' + x['path']); z = git('show', source['live_head'] + ':' + x['path'])
    assert sha(a) == x['sha256'] and sha(z) == x['live_sha256']
    assert a == z or a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
    for target in [report['base'],source['live_head']]: git('merge-base','--is-ancestor',x['last_source_commit'],target)
for x in source['narrow_sources']:
    assert x['live_ancestor']; git('merge-base','--is-ancestor',x['commit'],source['live_head'])
inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]; owned = []
for raw in (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 32
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
assert len((s/'ledger-update.stdout.log').read_text().split()) == 32
assert {json.loads(x)['id'] for x in owned} == set((s/'ledger-update.stdout.log').read_text().split())
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); seen = set(old.splitlines())
added = b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); before = fold(old); after = fold(old + added)
assert set(before) == set(after)
for ident in before:
    for k in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']: assert before[ident].get(k) == after[ident].get(k), (ident, k)
receipt = {'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'source14_sha_last_source_ancestors_and_four_narrow_live_sources_verified':True,'source10_equal4_historical_comment_differences_preserved':True,'original_material_rows':6606,'original_material_assertions':19,'original_local_consumer_checks':consumer['checks'],'material_or_consumer_probes_reexecuted':False,'owned_ledger_rows':32,'protected_fold_preserved':True,'original_native_gap':'Learner reported no actual native model receipt; ops now verified original Sol6.1/xhigh/input/lease and unchanged workspace-write/no-network sandbox.','original_consumer_probe_scope':consumer['limitation'],'original_failures':['Initial tsx CLI sandbox IPC EPERM; node TypeScript eval syntax error; absent TypeScript package main entry on compile preparation. Final probe removed only probe type annotations and used installed loader; original assertions unchanged, no dependency install or permission expansion.','First CLI receipt verification counted lines instead of space-separated32 IDs; corrected readback without repeating mutation.','Noncombat-null/path material probes and original missing/zero cut boundaries retained.'],'limits':'Five original Silent A10 runs only. First NHA empty 28HP/428enemy frame differs from operative 30HP/408enemy frame. Snapshot options do not simulate later draw/targets/final outcome; static displayed7 damage cannot substitute hand-dependent damage. No complete candidate attribution, paired whole-fight or holdout calibration.','no_source_merge_version_checks_or_game_action':True}
(pub / 'batch-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 350000 and f.suffix in ['.json', '.jsonl', '.md', '.py', '.txt', '.patch', '.log'] and f.name not in ['ledger-snapshot.json', 'state-windows.jsonl', 'ledger-before.json', 'scan-input.txt', 'final-scan-input.txt']]
files += list((s / 'original-proposals').glob('*.md'))
files += [s / 'evidence/evidence-manifest.json']
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1859原184302策略rc0/done、十项waiting/no-source门禁核，cc29干净WT无新提交，testsnull/mergednull，未重合/发号/补测或重复派单。五Silent A10所属6606原行/19材料断言与4局部消费者检查为原学习者读回，不重跑或当完整候选/生产套件/自然收益；NHA最初空手28血/428敌与可操作30血/408敌基线分开，静态7伤不替手牌变动伤害，原24/24失败和后续未知保留。14叶旧livefe646265逐SHA/每叶真实源祖先及4窄源核，10同/4历史Roy-Dai注释差不覆盖，窄子项不关闭宽提案。32原CLI只where/note、保护claim/首证/prior/evidence/status/version；初把单行ID当32行的核验失败原件保留，未重复写入。ops补核实际native Sol6.1/xhigh/input/lease、workspace-write/no-network；原学习者模型未读回边界不改。原tsx IPC拒绝、node未转译TS及包入口缺失准备失败保留，最终固定探针仅去其类型注解/原断言不变，不降权限或安装依赖，不当产品失败或完整回放。无新经验/反证/源码/复盘，不刷新论文，不改当前局/账号模型预算队列prompt，原宽父/owner保持、不等待未来事件。证据paper/materials/20261015-1859-ops/。\n'
note = f'\n- {at} [ops 策略处置] 原184302十项继续waiting，无新源码/合入/版本；32条原CLI仅追溯，原6606行/19材料及4局部消费者检查读回，不当完整套件或完整候选认证。探针准备失败与后续修正、旧未知及真实原native隔离身份均归档，不新派/补测/改对局。回执paper/materials/20261015-1859-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note}; (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in [p / 'prepare-records.py', p / 'seal-records.py', r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'batch': bid, 'waiting': 10, 'own_ledger_rows': 32, 'no_source_tests_merge_release_or_dataset': True, 'protected_fields_preserved': True, 'native_model_and_original_sandbox_verified': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}; values['paper/materials/learning/ledger.jsonl'] = old + added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; rows = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'waiting': 10, 'ledger_rows': 32, 'native_verified': True, 'ledger_check': 0, 'paths': len(rows)}))

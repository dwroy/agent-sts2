# 策略学习报告：20261015-184302-strategy-proposal

本批十项均waiting，未发现可独立提交的新确定缺口或足以拟合新策略参数的证据。已实现窄子项继续有效，未将其冒作复合父提案完成。

- base：`cc29ccb63ffa1f36c0dd7c17316e8ef013fd8622`；开工clean，`git merge --no-edit main`返回Already up to date。
- 只读live核验头：`fe6462651b593b9831581c088deface9957a404f`。14个相关源码叶10个完全相同，其余4个差异均为Roy/Dai历史注释，完整diff保存在live-source-differences.patch；未修改以追求字节相同。
- 五来源局均Silent/A10，run-config与runs及状态身份核同；各自旧code+dirty保留，不以当前源码重写历史。未在当前工具面取得本轮原生请求的模型/推理强度回执，不宣称已核或改配置；启动器原生会话核验仍由ops完成。
- fixes=[]，merged=null，无新commit、eval版本或shipped登记。无源码变更，tsc/vitest/cases均null；撤源码失败/恢复通过不适用，未进行或伪造。

## 原始证据与材料验证

共用入口8流共6606行：states3238、decisions3138、sl-attempts31、run-config5、run-plans26、brain163、runs5、fight-plans0。manifest记录各流独立source_size和逐局计数；逐行seek原日志验证offset/bytes/SHA/JSON/非冲突身份，全通过。run-plans身份按run识别，未按正文提及筛局。fight-plans0只限2233957字节截点，其他流无效行计数不隐去。没有将这些锚点当全历史，也未扩大到别的角色。

material-validation.json的19项固定实帧核算通过，属于材料检查，不是产品测试。核心证据：RC61 F33首/末T1同指纹，实际损4/8、净扣30/23；P74 F23第4试T3实际弃掉精确切击，原零损预测失效；P74 F22赢战53→9且下一战仍9；BTS F31抽弃前后不是同一候选。NHA F33最初空手帧28血/敌428与可操作首手30血/敌408分开，后者才是损1/7与净扣8/24的基线。turn-window-endpoints.json只存原端点，不称完整候选认证。

## 现有消费者读回和失败原件

consumer-probe-r4.stdout.json的四项局部检查通过：唯一打击弃后续打非法、实际被标弃、四份留牌快照、投斧首牌键区分。单生存者的固定当前57激光回放为7挡/损50/余-5；这里只直接使用该帧攻击，不推新通用朝向公式。P74原弃牌帧普通紧勒已知strangle=2，精确切击已知手牌依赖；毒雾有poisonPerTurn=3但仍带known=false，未知不会被改写成已校准。

首次tsx CLI启动因沙箱IPC listen EPERM失败；第二次node eval未转译TypeScript而语法失败；第三次准备转译时typescript包主入口缺失失败。全部stderr/exit及原稿保留。第四次仅移除探针文本类型注解，采用已装tsx loader直接node导入生产函数，exit0，原四项断言未改。未降低沙箱权限、联网或安装依赖。这些准备/环境失败不是产品修复或tsc/vitest结果。

投斧首牌源码e784dd9f043bf87c29109573f48975f9903280d3、普通单弃bf423c173d3be348a4ad714e1d26516df619ff41，以及现有候选/持牌读回接线9d8278702dbc581b5015ba7ec9a70dc0fb94cccb均核为实际live祖先。完整proposal_results仍waiting，未用经验status或单动作回执冒充完整已实现。

## 每项结论

详见proposal.md（逐项账本、层/回合、反例、原/现行为、验证和回退）与proposal-results.json。处置如下：

- silent-proposal-9952ee8e8df9a0fe：waiting；缺跨重规划的完整候选归属、累计成长和同条件后轮/路线分支；即时多16伤、多损6血不确定新的SL或终局HP门槛。
- silent-proposal-47be799a87af03be：waiting；当前四选项快照不含逐分支续牌、目标和最终生存结果；缺四个合法弃牌分支的联合生产回放与未知组合校验，不能用当前7伤静态替代变动手牌伤害或宣称保留线实盘获胜。
- silent-proposal-3a5274da3c42672a：waiting；缺召唤复活、臂甲/士兵一次消费、滑溜与连续用药的联合生产回放；主怪最后归零中间来源缺帧，净血差不足拟合药价或统一杀序。
- silent-proposal-bc4b92d590f2c4ce：waiting；投斧身份和普通单弃只覆盖原提案子项；仍缺跨重规划的完整执行链、余像累计兑现及动态弃牌联合消费者验证。
- silent-proposal-f52fbbab4dccc3b4：waiting；缺资源分源的完整消费者账及同条件路线、休息、SL、保药整战分支；获胜战耗血和后战入口不足以识别因果HP价格。
- silent-proposal-10f37c0edd3d24a6：waiting；缺冻结开场遗物、持续能力、牌挡/被动挡/翻倍和回复的联合生产回放及后置独立校准；单公式存在不能推出未验证组合或新药价。
- silent-proposal-3f82387e2e179703：waiting；缺同抽序同预算整战控制与累计能力收益；24/24全败饱和不证明即时等价，也不能决定保血/铺能力的新排序。
- silent-proposal-aee21084c991abd3：waiting；缺原逐样本抽序、动作和完整实际线路配对回放；一次死亡与3/4预测并存不足证明确定模型偏差或校准权重。
- silent-proposal-df37594e9b12debf：waiting；普通单弃唯一后继取消是已实现子项；宽项仍缺跨重规划完整归属、能力累计与呼唤自损联合消费者验收。
- silent-proposal-42e81c83b2e1e56b：waiting；缺回复、药槽、存档事件的完整分源消费者账和同条件后战反事实；实际回复与存档恢复的统计不能直接确定路线或终局HP价格。

## 记录与交付边界

只经根learner/ledger.py update追加本批报告/提案路径与逐项waiting理由，保留既有claim、首证、prior、evidence、status、version。不直接改账本，不重复登记已有代码提案ID，不重复写历史复盘；执行回执及字段保护校验另存。没有新游戏反证或与旧经验的机制冲突，既有反例/未知继续保留。父学习要求不因本批退出关闭。

无新源码，不走live merge或上线记录/双通知流程，不制造合入提交、版本或生产测试成功。工作树HEAD和源码/knowledge零变更；scratch按任务要求保留。提案和报告交由本批原调度器及ops继续，不能将排队或本报告当Roy/消费者已经读回。

账本CLI已实际一次成功追加32条，退出0；ledger-validation.json核原claim/首证/进阶/prior/evidence/status/version完全保持。首次本人材料检查误把CLI单行32个ID当32行，断言失败原件保留；按空白分词及精确ID集合核验通过，未重复写入。

最终验收：gitleaks扫描144078392字节、退出0、无泄漏；HEAD仍cc29ccb63ffa1f36c0dd7c17316e8ef013fd8622，git status为空，git diff --binary HEAD为空。根learn.json本批task/角色/工作树/十ID/五runs仍匹配，无专题/冻结实现绑定变化。无源码提交/合入/版本；report.json为对应最终机器回执。

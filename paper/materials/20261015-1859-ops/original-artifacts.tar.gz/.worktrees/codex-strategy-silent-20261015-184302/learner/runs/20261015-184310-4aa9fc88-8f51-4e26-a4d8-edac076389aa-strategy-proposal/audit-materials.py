"""Verify frozen own-character evidence; this is a report artifact, not a product test."""
import collections
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(HERE.parents[1]))
from extract_evidence import run_identity

dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
states, decisions, records, selected_raw = {}, {}, {}, {}
verified, summaries, sl = 0, [], []

state_ranges = [(283380, 283510), (283850, 284100), (284626, 284660),
                (284730, 284825), (285314, 285535), (286145, 286176)]
state_anchors = {284817, 285414, 285339, 283398, 283400, 285314, 285321,
                 285491, 285497, 284730, 284761, 284766, 286158, 286162, 286163}
decision_anchors = {277909, 278542, 278543, 278544, 279021, 279117,
                    279197, 279852, 279854}

def powers(entity):
    return {p['power_id']: p['amount'] for p in entity.get('powers', [])}

def project(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'run_id': item['run_id'],
            'floor': run.get('floor'), 'turn': state.get('turn'),
            'screen': state['screen'], 'observed_ts': item['row'].get('observed_ts'),
            'hp': player.get('current_hp', run.get('current_hp')),
            'block': player.get('block'), 'powers': powers(player),
            'hand': [c['card_id'] for c in combat.get('hand', [])],
            'enemies': [{'id': e['enemy_id'], 'hp': e['current_hp'],
                         'block': e['block'], 'powers': powers(e),
                         'intents': e['intents']} for e in combat.get('enemies', [])]}

for stream in manifest:
    name = stream['stream']
    path = HERE / f'evidence/{name}.evidence.jsonl'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    counts = collections.Counter(dict.fromkeys(runs, 0))
    with (ROOT / f'logs/{name}.jsonl').open('rb') as source, path.open() as evidence:
        for line in evidence:
            item = json.loads(line)
            assert item['run_id'] in runs
            assert run_identity(item['row']) == item['run_id']
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            counts[item['run_id']] += 1
            verified += 1
            row = item['row']
            if name == 'states':
                assert row['state']['run']['character_id'] == 'SILENT'
                assert row['state']['run']['ascension'] == 10
                states[item['line']] = project(item)
                if item['line'] in state_anchors:
                    selected_raw[str(item['line'])] = row['state']
            elif name == 'decisions' and item['line'] in decision_anchors:
                decisions[item['line']] = row
            elif name == 'runs':
                assert row['character'] == 'SILENT' and row['ascension'] == 10
                records[row['run_id']] = row
            elif name == 'run-config':
                assert row['character'] == 'SILENT' and row['ascension'] == 10
            elif name == 'sl-attempts':
                sl.append({k: row.get(k) for k in ['run_id','floor','attempt','result','end_hp','incoming']})
    assert dict(counts) == stream['counts']
    summaries.append({'stream': name, 'source_size': stream['source_size'], 'counts': dict(counts)})

checks = []
def check(description, condition):
    checks.append({'description': description, 'passed': bool(condition)})
    assert condition, description

check('五局终局角色与A10身份', set(records) == set(runs))
check('弃牌前1血16挡', states[284817]['hp'] == 1 and states[284817]['block'] == 16)
check('精确切击实际离手', 'PRECISE_CUT' in states[284817]['hand'] and 'PRECISE_CUT' not in states[284818]['hand'])
check('弃牌选择真实为card2', decisions[278543]['answers']['pick']['choice'] == 'card2')
check('弃后重算不沿用零损', '(-7)' in decisions[278544]['rationale'])
check('强制单弃前仅生存者与打击', states[285414]['hand'] == ['SURVIVOR','STRIKE_SILENT'])
check('强制单弃后空手7挡45血', states[285415]['hand'] == [] and states[285415]['block'] == 7 and states[285415]['hp'] == 45)
check('无法兑现转向后仍57激光', states[285415]['enemies'][1]['intents'][0]['damage'] == 57)
check('两次T1指纹一致', decisions[279021]['fingerprint'] == decisions[279197]['fingerprint'])
check('首试实损4', states[285314]['hp'] - states[285321]['hp'] == 4)
check('末试实损8', states[285491]['hp'] - states[285497]['hp'] == 8)
check('首试净扣30', sum(e['hp'] for e in states[285314]['enemies']) - sum(e['hp'] for e in states[285321]['enemies']) == 30)
check('末试净扣23', sum(e['hp'] for e in states[285491]['enemies']) - sum(e['hp'] for e in states[285497]['enemies']) == 23)
check('末试触媒已建1层', states[285497]['powers'].get('ACCELERANT_POWER') == 1)
check('赢战53到9且下战仍9', states[284730]['hp'] == 53 and states[284761]['hp'] == 9 and states[284766]['hp'] == 9)
check('BTS唯一突然一拳被弃', states[286161]['hand'] == ['SURVIVOR','SUCKER_PUNCH'] and states[286162]['hand'] == [])
check('BTS T2实际损14', states[286158]['hp'] - states[286163]['hp'] == 14)
check('BTS抽弃前后指纹不同', decisions[279852]['fingerprint'] != decisions[279854]['fingerprint'])
plans = [json.loads(v) for v in decisions[277909]['questions']['plan']['criteria'].values()]
check('投斧两候选18挡75伤与10挡107伤均存在',
      any(p.get('block_gained') == 18 and p.get('damage_dealt') == 75 for p in plans) and
      any(p.get('block_gained') == 10 and p.get('damage_dealt') == 107 for p in plans))

(HERE / 'frozen-states.json').write_text(json.dumps(selected_raw, ensure_ascii=False) + '\n')
(HERE / 'decision-anchors.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')
(HERE / 'critical-state-trace.json').write_text(json.dumps([v for k,v in states.items() if any(a <= k <= b for a,b in state_ranges)], ensure_ascii=False, indent=2) + '\n')
(HERE / 'sl-summary.json').write_text(json.dumps(sl, ensure_ascii=False, indent=2) + '\n')
result = {'kind': 'evidence_material_validation_only', 'verified_rows': verified,
          'streams': summaries, 'checks': checks, 'product_tests': None}
(HERE / 'material-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': verified, 'checks_passed': len(checks), 'stream_counts': {x['stream']: sum(x['counts'].values()) for x in summaries}}, ensure_ascii=False))

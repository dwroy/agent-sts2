import collections
import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LOGS = pathlib.Path('/home/dw/Projects/agent-sts2/logs')
OLD = pathlib.Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-064301-s2/learner/runs/20261016-064305-3234cef3-e3a0-42c5-94fa-0d7e59388953-strategy-proposal')
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = json.loads((OUT / 'runs-identity.json').read_text())
checks, rows, streams = [], {}, []


def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    (OUT / 'material-check-progress.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    assert value, name


def identity(row):
    values = [row.get('run'), row.get('run_id'), (row.get('state') or {}).get('run_id')]
    fingerprint = row.get('fingerprint')
    if isinstance(fingerprint, str):
        fingerprint = json.loads(fingerprint)
    if isinstance(fingerprint, dict):
        values.append(fingerprint.get('run'))
    return {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}


for meta in json.loads((OUT / 'evidence-retry/evidence-manifest.json').read_text()):
    stream = meta['stream']
    path = OUT / 'evidence-retry' / (stream + '.evidence.jsonl')
    check(stream + ':envelope_sha', hashlib.sha256(path.read_bytes()).hexdigest() == meta['output_sha256'])
    selected = []
    with (LOGS / (stream + '.jsonl')).open('rb') as source:
        for line in path.open():
            envelope = json.loads(line)
            source.seek(envelope['offset'])
            raw = source.read(envelope['bytes'])
            assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
            assert json.loads(raw) == envelope['row']
            assert envelope['offset'] + envelope['bytes'] <= meta['source_size']
            assert identity(envelope['row']) == {envelope['run_id']}
            assert envelope['run_id'] in runs
            selected.append(envelope)
    count = collections.Counter(e['run_id'] for e in selected)
    check(stream + ':raw_bytes_identity_counts', all(count[r] == n for r, n in meta['counts'].items()))
    prior_path = OLD / 'evidence' / (stream + '.evidence.jsonl')
    if not prior_path.exists():
        prior_path = OLD / 'evidence-extra' / (stream + '.evidence.jsonl')
    if prior_path.exists():
        digest = hashlib.sha256()
        for e in selected:
            if e['run_id'] in dispatch['runs']:
                digest.update((json.dumps(e, ensure_ascii=False) + '\n').encode())
        check(stream + ':ten_anchor_envelopes_equal_previous', digest.hexdigest() == hashlib.sha256(prior_path.read_bytes()).hexdigest())
    rows[stream] = selected
    streams.append({'stream': stream, 'rows': len(selected), 'source_size': meta['source_size'],
                    'counts': meta['counts'], 'output_sha256': meta['output_sha256']})

check('runs:eleven_own_character', len(runs) == 11 and all(x['character'] == 'SILENT' for values in runs.values() for x in values))
check('states:character_and_ascension', all(e['row']['state']['run']['character_id'] == 'SILENT' and
      e['row']['state']['run']['ascension'] == runs[e['run_id']][-1]['ascension'] for e in rows['states']))
states = {e['line']: e['row']['state'] for e in rows['states']}


def player(line):
    return states[line]['combat']['player']


def enemy(line, at=0):
    return states[line]['combat']['enemies'][at]


def power(body, name):
    return next((p['amount'] for p in body.get('powers', []) if p['power_id'] == name), 0)


check('K2:F46T1_zero_poison_mirage_paid_one_no_block', player(293158)['block'] == player(293159)['block'] == 16 and
      player(293158)['energy'] - player(293159)['energy'] == 1 and
      all(power(e, 'POISON_POWER') == 0 for e in states[293158]['combat']['enemies']))
check('K2:F33T10_poison_42_to_48_no_hp_damage', power(enemy(292940), 'POISON_POWER') == 42 and
      power(enemy(292941), 'POISON_POWER') == 48 and enemy(292940)['current_hp'] == enemy(292941)['current_hp'] == 54)
check('79:F14T11_poison_4_to_10_no_hp_damage', power(enemy(293463), 'POISON_POWER') == 4 and
      power(enemy(293464), 'POISON_POWER') == 10 and enemy(293463)['current_hp'] == enemy(293464)['current_hp'] == 8)
check('79:F14T11_death_before_poison', states[293464]['run']['current_hp'] == 2 and player(293464)['block'] == 7 and
      states[293465]['run']['current_hp'] == 0 and enemy(293465)['current_hp'] == 8 and power(enemy(293465), 'POISON_POWER') == 10)
check('K2:F27T2_iron_corrected_zero_block_seven_plating', player(292788)['block'] == player(292789)['block'] == 0 and
      power(player(292789), 'PLATING_POWER') - power(player(292788), 'PLATING_POWER') == 7)
check('ZTR:17_potion_requests', sum(e['run_id'] == 'ZTRGYYMLR8SC' and
      (e['row'].get('chosen') or {}).get('action') == 'use_potion' for e in rows['decisions']) == 17)

spec = importlib.util.spec_from_file_location('resource_chain', ROOT / 'learner/resource_chain.py')
resource = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resource)
resource_summary = {}
for run_id in ('ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1'):
    frames = [{**e['row'], '_line': e['line']} for e in rows['states'] if e['run_id'] == run_id]
    starts = collections.defaultdict(list)
    for e in rows['sl-attempts']:
        s = e['row']
        if e['run_id'] == run_id and s.get('attempt', 1) > 1 and s.get('started_at'):
            starts[s['floor']].append(s['started_at'])
    result = resource.resource_chain(frames, run_id, 'silent', starts)
    (OUT / (run_id + '-resources.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    check(run_id + ':resource_audit_same_as_previous', result == json.loads((OLD / (run_id + '-resources.json')).read_text()))
    resource_summary[run_id] = {'combats': len(result['combats']), 'missing_exits': sum(c['exit'] is None for c in result['combats'])}

configs = {}
for e in rows['run-config']:
    code = e['row'].get('code') or {}
    commit = code.get('commit')
    configs[e['run_id']] = {'commit': commit, 'commit_exists': bool(commit) and subprocess.run(
        ['git', 'cat-file', '-e', commit + '^{commit}'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0,
        'dirty': code.get('dirty'), 'dirty_files': code.get('dirty_files')}

check('configs:eleven_commits_located', set(configs) == set(runs) and all(c['commit_exists'] for c in configs.values()))
summary = {'checks': checks, 'total_rows': sum(s['rows'] for s in streams), 'streams': streams,
           'resource_summary': resource_summary, 'historical_run_code': configs,
           'limitations': ['材料断言不等全部行机制认证或生产测试。', '动作回执不等完整候选已执行。',
                           '十锚点相同封套不增加独立证据；UJ仅是原提案所引补充局。',
                           '历史dirty知识联合输入未完整恢复，不能声称原整战已复现。']}
(OUT / 'evidence-check.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'total_rows': summary['total_rows'], 'resource_summary': resource_summary}, ensure_ascii=False))

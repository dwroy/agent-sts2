# 本批工具诊断保留

以下均为工具启动或只读探针问题，没有生产源码变更，也不作为游戏机制或产品故障证据。

- 第一轮提取的工具会话38268被沙箱启动器拦住，返回exit1：`error building bubblewrap command: Fatal error: ripgrep unreadable glob scan failed for /home/dw`；涉及并行回收工作树中不存在的`.codex`目录。一次decision-log只读调用也遇到相同启动错误。未将空输出解释为原日志缺失；提取重试58803成功exit0，完整输出单独保存evidence-retry及extract-retry.stdout.json，原工具响应保留在会话转录。
- 第一次读取本角色折叠账本时，临时Python变量`all`遮蔽内置函数，报`TypeError: 'dict' object is not callable`；改为`entries`后成功，未写根账本。
- 若干只读rg探针引用了不存在的旧文件名。改用rg --files定位实际路径，包括hand/loop.ts、learner/lib/selection-execution.ts和agent/tests目录；没有据此新增产品缺陷。
- 第一次源码对照将新测试路径拿到其创建前的旧基线读取，git show返回128。后续显式检查previous_exists并保留null，不把新叶缺失当源码损坏；最终source-audit.json成功保存18叶SHA与七个真实祖先。
- 第一次发起账本CLI的JavaScript工具封装有括号语法错误，工具在执行shell前拒绝。修正封装后只执行一次实际CLI，不重复写入。

生产测试未启动，三个离线消费者均实际exit0；这些错误不改写为tsc/vitest失败或成功。原Markdown、原字节日志、初稿及现有纠正版均保留。

# 静默猎手策略提案复核报告

本批：20261016-121302-s2-strategy-proposal。基线及最终应保持的HEAD：`f12269c7f9f2018d0e0c94339803dfb7d33138d3`。

结果：十项原提案全部waiting，无新增源码、策略参数、经验知识、提交、live合入或行为版本。已有窄实现不等宽提案完成，未将任何账本标shipped。未运行play、联网、LLM、游戏API、依赖安装、推送或下级agent。

## 派发及证据范围

根learn.json对应行task/character/worktree/十个proposal_ids匹配；没有research_request、implementation_request或proposal_repair。根普通研究请求绑定另一旧批，故本批保持已领取队列任务。开工git status干净，merge main返回Already up to date，未合入后续main。十份原提案SHA均匹配，原文和纠正版分别保存，不覆盖任何历史提案。

十锚点为本次JSON的runs。A3=10GPK5XGHCK3、A4=1LMBFGSMCWKU、A7=9YT51CK8RC39，其余七局A10；原ff1d所引UJ0K3G10609Y另补核A10，不把补充局当新增派发或全历史。所有角色及每帧进阶均核，不读取其他角色私有知识。

共用extract_evidence.py八流选中14,636行，保存每流source_size、逐行物理offset/bytes/SHA及计数。36项材料检查通过，逐原字节/JSON/显式身份核；十锚点八流封套与原064301-s2归档完全相同，新增截点不是新增对局证据。补充UJ贡献1,934行。源流无效行计数states2、decisions2、brain1未接纳为本批证据，归属未认证；fight-plans本次截点0行只表示未选到。第一轮被沙箱启动错误拦住，成功输出另存evidence-retry，不覆盖初稿。

## 关键实帧、反例及消费者

- ZTR F17六试68/70入口，资源工具保留12战斗窗、5缺出口；17条饮药请求不能当17新瓶或独立样本。早喝/晚喝同时伴随目标和抽序变化，缺受控整战对照。
- K2 F46T1升级蜃景1能换16→16挡，全敌零毒；普通正毒蜃景本局确有10挡，反对整类归零。79 F14T3的0/8实赢不等8死，尾端约76%不是已校准胜率。
- K2 F33首T10毒42→48，敌54HP不变；79 F14T11毒4→10，敌8HP不变，玩家2HP/7挡在感染阶段先死，终局仍8HP/10毒。K2次试未喝原瓶仍胜，反对“必须喝才可赢”。
- K2 F27T2原帧292788→292789牌挡0→0、覆甲0→7；c64原稿16挡沿原9c3纠正版保留勘误。数字纠正不证明完整药水时点规则已实现；本批没有新反经验结论或重复通知。
- K2资源工具18窗/1缺出口，79为7窗/0缺出口，三个资源报告与前次逐对象相同。净损包含回血、自伤等；药栏变化不单独判断饮用/丢弃。未走路线、首试缺出口及未执行候选均保留未知。
- 补充UJ A10 F33T7，states248044→248045：可见21攻击/12挡，HP56→48。仅复核原数值观察，不把未移除遗物的端点当独立伤源控制实验；K2三骑士T7额外2损伤来源仍未知。

现有离线消费者audit-selection.ts按冻结三战斗窗实际运行，三个exit0；输入、gzip原输出/解码SHA、stderr及退出码保留。ZTR F17为101候选段/395动作、69可核整轮端点与12未知窗；K2 F46为12段/51动作、9未知窗；79 F14为21段/43动作、11未知窗。三窗合134段/489动作。`actual_full_candidate_result`在工具契约中保留null，不能从它的0个非空值断言实盘从未完整执行，只能说该消费者未提供完整候选认证。已核端点也不能归因整条候选、护栏或SL的因果收益。未知原因逐窗见consumer-summary.json。上述是离线审计读回，不是新自然采用、生产tsc/vitest、整战模拟或收益验证。

## 当前源码与实际live范围

只读核实际live `0e7998bfa8df267dcf8835a57949bdb982c9feb0`。18个相关叶14个SHA相同；四个差异叶run-journal/potion-cost/card-model/rollout-live仅既有Roy/Dai注释文字，原diff保留，不冒称全树相等。七个现有来源提交均为本基线及该live的真实祖先，详见source-audit.json。

特别是`7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a`已经实际存在于live：Silent A10路线计划保存绝对HP/maxHP、起始资源、当前节点、成本快照与假设，不再将旧“未合入”状态当当前结论。该项仍缺完整资源消费者和旧缺decision_id的历史，故宽9edf保持waiting。零毒蜃景来源`5dbb47bfb48d652adfcda2e62c166a804098b6c3`及普通蜃景、药水观测、敌血池、整轮审计来源均核祖先，不重复提交源码。

11局run-config的原40位源码提交均可定位；dirty知识/记录联合字节未全部复原。不能笼统称历史源码不存在，也不能用当前知识重跑后声称重现原整战。未读取原生运行请求元数据，不报告本模型会话已完成运行档切换核验。

## 十项处置

| 原提案 | 既有账本 | waiting的具体缺口 |
| --- | --- | --- |
| silent-proposal-0b8ef30de463f317 | silent-0013, silent-0277 | 缺晚喝、留药的同资源整战对照及取得/饮用/SL恢复到消费者的完整归属。 |
| silent-proposal-5367449b857450a7 | silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284 | 缺刀扇多目标、铜钹多弃/随机目标及混合修饰的可隔离完整后继。 |
| silent-proposal-9b8890c2649a2734 | silent-0012, silent-0019, silent-0020, silent-0021, silent-0125 | 缺候选完整执行与连续资源联合归属；原线、未走路线、晚喝铁心的整战后继未执行。 |
| silent-proposal-645ff7b72e0b9991 | silent-0010, silent-0106, silent-0021, silent-0286 | 缺尾端胜率校准与替代整战结果；0/8实赢不等于8次死亡。 |
| silent-proposal-68ef2857229d1287 | silent-0278, silent-0286 | 这两次只支持当步施毒；缺各自完整修饰组合与整轮后继校准，不能扩大非双boss短推演。 |
| silent-proposal-9edfef7a6b2873c2 | silent-0020, silent-0019, silent-0021 | 宽提案仍缺分类药水/SL/整战资源的联合消费者；旧路线两条无decision_id，旧归一化记录不能唯一恢复。 |
| silent-proposal-ff1d168227e369e0 | silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178 | 缺升级正毒、暗影/重放联合控制样本；三骑士T7额外2损伤来源未隔离，UJ单窗也不是移除遗物反事实。 |
| silent-proposal-c64bdd50a949d16f | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | 数字纠正不关闭宽资源提案；缺持续能力/取得/实饮/SL恢复至终局的联合消费者及早喝/换瓶对照。 |
| silent-proposal-243ad8dd038a4ff6 | silent-0019, silent-0020, silent-0065, silent-0106 | 缺洗牌后同条件与单动作整战对照；替目标、替路线和休息后继未执行。 |
| silent-proposal-9c3ff04261867dd2 | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | 缺实际建立能力、药水取得/弃用/恢复与终局消费者的完整联结，以及饮药时点整战对照。 |

每项层/回合、旧行为、已有覆盖、反例、预期行为、验证与回退均见本目录proposal.md和dispositions.json。code_proposals沿用十个真实原CLI id，不新建重复id；implementation_domains=[]表示本批无生产实现，不删除原提案各自的领域。

## 验证与记录

生产源码与全部knowledge无修改，baseline-diff.patch为空；工作树保持干净、HEAD保持上述base。没有源码撤除/恢复测试，不运行tsc/vitest，也不借旧任务测试绿：tests固定全null。无代码提交，故没有提交前gitleaks、合后测试、eval版本、双上线通知或shipped登记；现有实现只作祖先核实。

根账本只经ledger.py update追加20个既有条目的where/note链接（by=learner:strategy-proposal），不新增support/repeat、游戏结论、账本id或代码提案id，不改旧claim、证据、首证、prior、状态和版本。真实CLI结果及物理前缀保护核验见ledger-links-receipt.txt与ledger-final-audit.json；最终机械处置由调用方读取result.json，不手改专用提案队列。

临时材料全部在本批指定目录。沙箱启动错误、一次只读fold变量遮蔽、旧基线缺新增测试文件以及误名路径探针留工具转录和tool-diagnostics.md，不当产品故障。原日志和失败/初稿不删除；本任务不自删工作树。

import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PROJECT = pathlib.Path('/home/dw/Projects/agent-sts2')
result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
checks = []


def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    assert value, name


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
check('full_base_unchanged', head == result['base'] and len(head) == 40)
check('tracked_and_untracked_clean', not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT))
check('all_tracked_inputs_unchanged', not subprocess.check_output(['git', 'diff', '--binary', result['base']], cwd=ROOT))
check('ten_ids_exact', [p['id'] for p in result['proposal_results']] == dispatch['proposal_ids'] == result['code_proposals'])
check('only_waiting', all(p['state'] == 'waiting' and p['reason'] and not p.get('commit') for p in result['proposal_results']))
check('anchors_exact', result['runs'] == dispatch['runs'])
check('no_fake_implementation', result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == [])
check('no_fake_tests', result['tests'] == {'tsc': None, 'vitest': None, 'cases': None})
check('report_real', pathlib.Path(result['report']) == OUT / 'report.md' and (OUT / 'proposal.md').is_file())

spec = importlib.util.spec_from_file_location('ledger', PROJECT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
path = PROJECT / 'paper/materials/learning/ledger.jsonl'
before = json.loads((OUT / 'ledger-before-links.json').read_text())
current = ledger.fold(ledger.read_rows(str(path)))
prefix = json.loads((OUT / 'ledger-prefix-before.json').read_text())
raw = path.read_bytes()
check('ledger_physical_prefix_preserved', hashlib.sha256(raw[:prefix['bytes']]).hexdigest() == prefix['sha256'])
for ident, old in before.items():
    now = current[ident]
    check(ident + ':protected_values', all(old.get(k) == now.get(k) for k in
          ('character', 'kind', 'claim', 'evidence', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'status', 'version')))
    check(ident + ':where_prefix', all(now.get('where', {}).get(k, [])[:len(v)] == v for k, v in old.get('where', {}).items()))
    check(ident + ':trace_link', all(str(OUT / name) in now.get('where', {}).get('proposal', []) for name in ('proposal.md', 'report.md')))
    check(ident + ':notes_history_prefix', all(now.get(k, [])[:len(old.get(k, []))] == old.get(k, []) for k in ('notes', 'history')))

expected = {row['id']: row for row in map(json.loads, (OUT / 'ledger-links-input.jsonl').read_text().splitlines())}
trace, offset = [], 0
for line, physical in enumerate(raw.splitlines(keepends=True), 1):
    if offset >= prefix['bytes']:
        row = json.loads(physical)
        if row.get('id') in expected and row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith('20261016-121302-s2-strategy-proposal：'):
            check(row['id'] + ':cli_row_fields', all(row.get(k) == v for k, v in expected[row['id']].items()))
            trace.append({'source': str(path), 'line': line, 'offset': offset, 'bytes': len(physical),
                          'sha256': hashlib.sha256(physical).hexdigest(), 'row': row})
    offset += len(physical)
check('twenty_cli_rows_exact', len(trace) == len(expected) == 20 and {e['row']['id'] for e in trace} == set(expected))
(OUT / 'ledger-appended-rows.jsonl').write_text(''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in trace))
receipt = {'checks': checks, 'updates': len(trace), 'preserved_fields': True,
           'original_prefix': prefix, 'head': head, 'worktree_clean': True,
           'ledger_trace_sha256': hashlib.sha256((OUT / 'ledger-appended-rows.jsonl').read_bytes()).hexdigest()}
(OUT / 'ledger-final-audit.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
names = ['report.md', 'proposal.md', 'result.json', 'dispatch.json', 'proposals-original.json',
         'dispositions.json', 'runs-identity.json', 'source-audit.json', 'baseline-diff.patch',
         'evidence-check.json', 'supplementary-evidence.json', 'consumer-summary.json',
         'consumer-audit-receipts.json', 'ledger-links-input.jsonl', 'ledger-links-receipt.txt',
         'ledger-links-stderr.log', 'ledger-appended-rows.jsonl', 'ledger-final-audit.json',
         'verify-evidence.py', 'audit-consumers.py', 'verify-final.py', 'tool-diagnostics.md',
         'evidence-retry/evidence-manifest.json']
manifest = {name: {'bytes': (OUT / name).stat().st_size,
                   'sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()} for name in names}
(OUT / 'final-artifacts.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'ledger_updates': len(trace), 'head': head,
                  'clean': True, 'waiting': len(result['proposal_results'])}, ensure_ascii=False))

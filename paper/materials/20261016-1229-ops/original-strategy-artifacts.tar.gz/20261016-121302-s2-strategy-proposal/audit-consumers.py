import collections
import gzip
import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
runs = json.loads((OUT / 'runs-identity.json').read_text())
windows = [('ZTRGYYMLR8SC', 17), ('K2JAGKVJAWZJ', 46), ('79UCJ0K6R9C1', 14)]
selected = {window: {'run': runs[window[0]][-1], 'decisions': [], 'states': []} for window in windows}
for stream in ('states', 'decisions'):
    for raw in (OUT / 'evidence-retry' / (stream + '.evidence.jsonl')).open():
        envelope = json.loads(raw)
        row = envelope['row']
        floor = row.get('floor') if stream == 'decisions' else (row.get('state') or {}).get('run', {}).get('floor')
        window = (envelope['run_id'], floor)
        if window in selected:
            selected[window][stream].append({**row, '_line': envelope['line']})

receipts = []
for (run, floor), data in selected.items():
    name = run + '-F' + str(floor)
    source = OUT / (name + '-input.json')
    output = OUT / (name + '-audit.json.gz')
    stderr = OUT / (name + '-audit.stderr.log')
    source.write_text(json.dumps(data, ensure_ascii=False) + '\n')
    assert all(row.get('decision_id') for row in data['decisions']), '窗口缺 decision_id，不能自行补号'
    digest = hashlib.sha256()
    size = 0
    with stderr.open('wb') as errors, gzip.open(output, 'wb') as destination:
        child = subprocess.Popen(['node', '--import', './agent/node_modules/tsx/dist/loader.mjs',
                                  'learner/audit-selection.ts', str(source)], cwd=ROOT,
                                 stdout=subprocess.PIPE, stderr=errors)
        while chunk := child.stdout.read(65536):
            digest.update(chunk)
            size += len(chunk)
            destination.write(chunk)
        rc = child.wait()
    receipt = {'run': run, 'floor': floor, 'exit_code': rc, 'input': str(source),
               'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'output': str(output), 'gzip_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
               'decoded_sha256': digest.hexdigest(), 'decoded_bytes': size,
               'stderr_sha256': hashlib.sha256(stderr.read_bytes()).hexdigest()}
    if rc == 0:
        with gzip.open(output, 'rt') as result:
            audit = json.load(result)
        receipt.update(segments=len(audit['segments']), actions=len(audit['observed_actions']),
                       turn_status=dict(collections.Counter(x['status'] for x in audit['observed_turns'])),
                       certified_full_candidates=sum(x['actual_full_candidate_result'] is not None for x in audit['segments']))
    receipts.append(receipt)
    (OUT / 'consumer-audit-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    if rc != 0:
        raise SystemExit(rc)

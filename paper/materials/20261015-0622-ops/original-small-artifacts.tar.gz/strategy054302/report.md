# 静默猎手策略提案逐项处置

记录时间：2026-10-15T05:58:16+08:00。批次20261015-054302-strategy-proposal，角色silent，本批观察A10。
基线：`0ed6d1e80673b5a4df37b7eae7df6db3d666c89e`。开工工作树干净，已执行git merge --no-edit main，返回Already up to date。

本批身份task/character/worktree/runs匹配，普通专用队列仅领取十id；无research_request、implementation_request、proposal_repair。普通专题文件属于旧20261010批、条件不成立，没有转成专题、另读其他专题或扩大队列。已读README、最新STATE、decision-log末尾、学习协议、代码提案闭环。

结论：十项整体waiting，已部署的窄机制保持；余下范围缺可复现校准或完整后继。本次没有新增源码/知识/权重、代码提案id、提交、合入或版本，不标implemented/duplicate/shipped，也不关闭父要求。fixes=[]、merged=null，tracked工作树保持干净；报告与过程材料只在本批scratch。

## 证据及输入边界

六局runs/run-config均核实SILENT/A10且已结束；所有游戏数值只由六局原帧得出，原提案/经验提到的其他局不冒作本批独立校准。现有经验只读silent。各经验历史支持数及asc上限不等于本批验证范围。

按指定extract_evidence.py入口冻结六流，再由同入口抽runs/fight-plans，八流共6995条。逐条回原offset/bytes复读验证SHA256、JSON正文、显式局号与角色，run-plans读取run，冲突身份拒收。manifest与byte-verification.json保存截点/计数/输出SHA。原流无效JSON为states2、decisions2、brain1，这些行不接纳。fight-plans在本截点0行仅说明未选到，不断言永久缺失；run-plans实际33条。没有覆盖旧报告或零行初稿。

| 流 | 冻结source_size字节 | 本批行数 |
|---|---:|---:|
| states | 12898317002 | 3432 |
| decisions | 1477916612 | 3306 |
| sl-attempts | 39755621 | 29 |
| run-config | 1716254 | 6 |
| run-plans | 7881544 | 33 |
| brain | 539500440 | 183 |
| runs | 330452 | 6 |
| fight-plans | 2233957 | 0 |

十份Markdown原字节与队列SHA均一致，见original-proposal-verification.json及<id>.original.md。队列与派发快照为proposal-queue-snapshot.json、dispatch.json，26个原账本链已核（ledger-before.json）。本批未重复复盘或登记机制。

selected-boards.json/selected-decisions.json保存指定层；action-endpoints.json按同局observed_ts连接693条决策与邻接帧。邻接帧可能处在结算中途，不能自动认证整线已执行。verified-claims.json保存35项原帧/原题字段断言全部通过；这是证据核查，不是生产源码测试、tsc/vitest或撤源码红绿。六局run-config均dirty，本批未重建当年完整知识快照，不能将旧现场等同clean Git树。

## 十项原提案

### silent-proposal-89354805ee4d7e77：神化传播与施放身份

证据：VLZ6CCT8AQ0A F35/T1、F43/T1–T5、F45/T1。账本：silent-0237, silent-0238。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md`；原SHA256：`ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d`。

本批原帧核验：已证普通神化实付2能，已见手牌及后继毒雾升级，F43同后继51伤/13损兑现。当前窄传播已部署，actual_cast_this_fight仍null。

处置：waiting。缺跨抽牌、选牌、药水、SL及换战的实际施放持续身份和未覆盖属性/重放交互校准；窄传播源码不足登记整个宽提案duplicate。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：冻结F35/F43普通升级与后继帧，验证状态期限、已升级不重加和未知标记，再用独立A10局校准完整执行链。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-f2bfceddb1898dca：药水MC预算

证据：VLZ6CCT8AQ0A F43/T1、F45/T1/T4/T5。账本：silent-0106, silent-0019, silent-0201。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md`；原SHA256：`fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26`。

本批原帧核验：F45首题药水707ms、1/12样本，rollout1轮1样本且best=null；痊愈药水实加1能2牌、HP67不变。T4少损/攻击候选13损24伤/31损32伤。

处置：waiting。缺完整且校准模型下同起点、同随机池、同总预算的分阶段MC配对和候选稳定性曲线；单次707ms或未选攻击线不足拟合预算、护栏与留药常量。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：先排除模型覆盖差异，冻结数据SHA、随机池与原候选，按相同总预算比较成熟度及完整后继；实抽与中位样本分列。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-283a164780d11e69：神化经验补链

证据：VLZ6CCT8AQ0A F35/T1、F43/T1–T5、F45/T1。账本：silent-0237, silent-0238。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md`；原SHA256：`78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637`。

本批原帧核验：原经验silent-apotheosis-combat-upgrades与0237/0238链接存在，Markdown SHA匹配，不重复写复盘或登记机制。

处置：waiting。原经验与神化窄源码已核，但持续身份和交互全范围未完整交付；不能用经验active代替整个代码提案duplicate。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：沿89354805ee4d7e77和本id去重处理，固定帧校准已支持升级/未知范围，保留原两个来源链。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-ebbfe3b97548756d：十五项攻防与资源分账

证据：VLZ6CCT8AQ0A F43/T1–T5、F45/T1/T3/T5。账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md`；原SHA256：`08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2`。

本批原帧核验：萎靡+付2减3力，步法+敏1→4，12/16毒与触媒2实扣33/45。F45末32血20挡对59，完整需损39，实扣32截零，三敌存活且两雾未建立。

处置：waiting。缺十五条原经验的属性组合、状态期限和战斗/路线/休息消费者联合校准；局部数值复核未覆盖全部被动、房间资源、重规划归属及整战因果。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：逐条分母/来源冻结，保留已匹配子式，仅对可独立证明的缺口实现；怪物按当前进阶DB读取，房间代价保持五样本门槛。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-e5b87be50f28f311：SL与护栏执行归属

证据：8JRE1C4H4Z2W F33/首及第三试T2、第二试T5、末试T11。账本：silent-0079, silent-0021, silent-0125, silent-0018。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md`；原SHA256：`5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709`。

本批原帧核验：首/第三试T2 fingerprint相同，原/换线五轮死亡0/24与5/24，实损3/15、净扣10/17。第二试护栏实损4/扣25；末T11实扣5截零而完整需损15。

处置：waiting。阶段候选、护栏快照与单动作回执已有窄源码；缺跨重规划候选持续身份及完整生产状态归属校准，actual_turn/whole_plan_executed仍null，不能用派发成功认证整轮执行。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：按attempt区分同指纹，冻结原答/护栏/SL/派发及后继状态；抽牌、生成、选牌、喝药后结束原候选完整执行资格，逐已建立能力记时点。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-49632bc4878fb597：力量敏捷虚弱成长

证据：CA5KE8GFJ9X2 F13/T3/T5。账本：silent-0005, silent-0231。原提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md`；原SHA256：`aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2`。

本批原帧核验：加压后力4/8、喷水15/19；虚弱11/14，末2血10挡对14实截零。计划步法没有取得。

处置：waiting。本局无正敏捷实测；缺逐击力量、逐牌敏捷、虚弱及独立成长共同冻结的实际调用输入/消费者校准，不能用单独步法提交关闭复合经验。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：本局加压与虚弱只作回归；需授权并核实的正敏捷组合对照，再校准完整四条路径，不补未见属性阈值。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-66532328a585941f：持有与启动兑现

证据：5PM6JAQG6FNQ F33、F39/第二试T2。账本：silent-0021, silent-0009。原提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md`；原SHA256：`56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831`。

本批原帧核验：无毒失落上冒泡能量5→4、敌HP及能力不变。F33已建立组件且胜与F39条件不同。

处置：waiting。缺同资源、完整抽序下不同启动顺序整战配对及可复现收益函数；持有不等已建立，零即时效果不足拟合启动/构筑权重。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：冻结持有/实际施放/建立时点及实付能量，完整后继比较顺序，独立新A10局验证，保留全部合法选项。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-43a76a31ba7bdcfa：吸取负敏毒与SL

证据：61E2QS63Y9WU F17/T5/T6。账本：silent-0030, silent-0027。原提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md`；原SHA256：`f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c`。

本批原帧核验：吸取后玩家力2→0、敏0→−2、敌力0→2；双防御各3，17+16毒实扣33；本战首试胜。

处置：waiting。缺同起点、同构筑/完整抽序的整战配对与另一可救活完整SL线；首试胜不能支持改SL范围、换线偏好或优先级。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：固定吸取双方属性及期限、毒与牌挡分项校准，再用独立已核后继验证SL；不据本局改阈值。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-5264153a4a4b0e5c：召唤航行与目标

证据：61E2QS63Y9WU F23/T1–T5，重点T4。账本：silent-0039, silent-0209。原提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md`；原SHA256：`b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02`。

本批原帧核验：召唤后本体index0→1；两次航行后力3→6，T4幻象仍2HP并攻击、实损15，T5才死亡/REVIVE。

处置：waiting。缺A10召唤、复现、退场、逐实体成长全链校准及另一focus完整后继；未选39伤零损线无实打对照，旧召唤提交不能证明排序收益。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：冻结稳定敌身份、召唤/复活前后index及逐实体HP/力/意图，完整后继才比目标顺序，相同推演并列，不强制首杀。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

### silent-proposal-bddfa690a84e03d0：睡眠醒来成长

证据：DUZUBAJ3A8GP F30/末试T1–T6。账本：silent-0128, silent-0079。原提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md`；原SHA256：`b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780`。

本批原帧核验：睡层3/2/1后T4醒；T3也结算3毒，未隔离唤醒原因。T5/T6力2/4、尖啸恢复后攻22。四试为三predicted_death后SL和一died。

处置：waiting。缺伤害唤醒、眩晕和睡层期限的独立全链校准，以及同抽不同排序完整后继；四试无赢不足拟合全败排序血价。

旧规则和预期行为：沿原提案要求分账与真实状态变换；保留当前合法选项、排序和未知标记，不凭缺证改权重。拟验证：将睡层减少、伤害唤醒、眩晕分开，临时减力恢复与独立成长分开，按run分组不以四试扩分母，不猜另线胜率。

反例和限制：敌人、资源、抽序或组件建立状态变化；未选线/未结算毒不是实绩，缺整战因果。六局为发现/回归材料，不称独立盲测；后续按run与结束时间划验证集，SL不扩分母。预期影响仅为可追溯事实和缺口；无本批源码可回退，后续实现须保存撤源码失败/恢复通过及实际live祖先和消费者读回。

## 当前源码及消费者边界

只读live切点：`fd0e9c3fa68e9c34a48e7149865c16eaf3465cef`。source-proof.json记录15个base/live源码叶及七个真实live祖先，三个不同叶仅Roy/Dai注释（精确patch留scratch）；不存在的路径已从最终证明排除。对照不代表本批合入或六个旧局消费当前源码。

神化窄源码772b839f8ada31664cb764ea9ad3bdb03da27f64、后继触媒f516592fff557ef02c8ece43433706358c3f7fe6、萎靡b2805be4ba44b7375c7908d873889372cc3cfe6c均为该live真实祖先，未知属性/重放/自动施放仍标未知。combat-plan已接线持有/候选/模拟升级事实，但actual_cast_this_fight=null，不证明实际施放持续身份已交付。

候选审计保存原答/SL前后，hp_guard仅candidate_predictions_before_sl。单动作派发回执源码fdaf787a372880b0438e73bcac7e6d2168b038ed为live祖先、loop已接线；state_effect_verified=false，whole_plan_executed/actual_turn=null，不能认证整个e5原提案。旧六局时间早于这些字段部署，不能反向补成自然消费者读回。本批无LLM/API或游戏调用，整线/自然收益仍未知。

## 反例与未知

神化施放胜战仍有高血价，F45未施放且败不证明必打能赢。预算退化best=null与五轮全死不同。8JRE同盘换线多12HP只多7本轮伤，防御换线延至T11仍死，不能一概否定输出或保血。熟睡甲虫前三试预测死亡后SL，不補记未执行末轮；末试T3毒与时钟同在，不能推所有伤害唤醒条件。CA无正敏实测，61E首试族母胜不支持改SL，未选幻象focus无完整对照。

本批没有与原限定结论冲突的新独立反证，上述限制沿原提案保留，不重复写复盘/通知，不代填watcher或Roy确认；无预训练事实补齐、其他角色私有数据、游戏二进制读取。

## 记录、验证和完成状态

仅经根目录ledger.py update给26条原id追加by/where/note追溯，不新增/修改claim、status、evidence、first_run、prior、asc或version。既有proposed/shipped保留，不降级或冒认本批交付。输入、CLI输出、读回分别保存ledger-updates.jsonl、ledger-update.out、ledger-readback.json。不重复code_proposals add，十个真实CLI id及Markdown链已存在。

没有生产代码/知识修改，未跑源码撤掉/恢复、tsc、vitest；tests固定为{"tsc":null,"vitest":null,"cases":null}。35条原帧断言不是生产测试。完成核HEAD仍基线/工作树tracked clean，gitleaks扫描本批材料并留日志，成功只以实际回执记。没有提交、合入提交或release_id。

保留失败：bubblewrap准备阶段两次因并行树路径消失阻断，命令未启动；其后在原权限内重试，不改权限。一段样例读取combat=null报TypeError后跳过非战斗帧重读成功；apply_patch写scratch失败后用heredoc成功；早先不存在源码路径的搜索已纠正。过程失败保留，均非策略源码或测试失败。

本批launch实际请求gpt-6.1-sol/default/xhigh，与任务模板high分列；没有降低、重启或改配置。runtime-receipt.json保存launch SHA及startup/thread绑定，尚未取得native turn_context，不把启动参数冒作原生请求已完整核验。

运维按proposal.md/report.md核十项waiting，原调度器保留待新证据重派；报告不关闭父范围、不声称新经验入库或大脑采用。工作树与失败现场由原启动器按既有流程验收回收，本模型不删除自身树。最终机器回报在result.json。

## 实际终验回执

2026-10-15T06:01:31+08:00：根目录CLI实际追加26条、每条仅op/id/ts/by/where/note，输入与原账本行逐字段一致；claim/status/first_run/prior/asc/version/shipped_at/effect未变，原证据前缀完整保留、报告链接存在。并行任务另给silent-0005追加1项、silent-0125追加3项证据，已独立记录，不覆盖或归为本批游戏结论。初次读回使用全量evidence相等断言因此失败，保留失败而改为核实际本批行与历史前缀；不改台账、权限或测试口径。

gitleaks dir实际退出0、结果0项；HEAD为0ed6d1e80673b5a4df37b7eae7df6db3d666c89e、tracked status为空、本批派发身份未变。tsc/vitest/源码撤回测试未执行。详情见completion-verification.json、ledger-readback.json及ledger-concurrent-differences.json。

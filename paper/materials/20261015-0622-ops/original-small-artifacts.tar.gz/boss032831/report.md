# Silent / KNOWLEDGE_DEMON B4：20261015-032831-fix-batch

本批 **rejected**，未合 live、未创建行为版本、未登记 shipped。机制候选已留在独立分支，来源提交 `cc31324f916bc987c15e60460ec0e086a8ac4671`；原门槛验收拒绝，原因为 `overall validation coverage mismatch`。不能据不完整结果声明打穿、Brier 或胜率差改善。

不可变 dispatch base 为 `7ccd6158140be85a2e75a66d18d2dd7fde697cfc`，证据 key `5baa12a74077bffb444a3d38509db458f84b64094551fb32a337bcedfdc39aa1`，原件副本 SHA256 `2ec640c01427d1f74b4a8654da4f300a0f23242a6ad1212fdc6a92aa9aae5d61`。初始工作树干净，初始 live 同 base，合 live 为 Already up to date；未替换 base。原生线程的 turn_context 第8行核实 `gpt-6.1-sol / xhigh`，见归档 native-model-audit.json；没有其他模型或工作树批次。

授权原节为 notes/fix-queue-v4.md「B4 / B5 纳入标准流程」、decision-log 2026-10-07 12:11、学习协议及 docs/boss-sim.md §13/14；本次是本角色日志核实的模拟校正，不是人工提供游戏机制。

冻结295个已结束 SILENT 局、1291次boss尝试、528场可用实际结局（386 won、142 died）。原107个tune keys与UTC切点 `2026-10-06T02:46:11.648000` 不变，val421，新6场只进val。派发等级为A11，冻结可用战最高A10，不推断A11机制。两侧 split、dataset SHA `53cd5ba9fdeb857846b4a0d78dc3e95bc7c1e23c12dd30e4bf6fd48c4fa897de`、sources SHA `23547a4cafbaf72955305d6b9bd88c64b55a53207738b1279a83b1828d55c590` 相同；200样本、seed=1+原528行零基索引×101、t1/pre、原tune整体拟合不变。before/after均由不可变基准的 trust.py 自然生成；可信列表未手写，也没有用于发布。

目标56场实际战，14 tune、42 val，49 won、7 died。2621个原始COMBAT帧、576个回合的偏移/长度/SHA保存在 raw-frame-hashes.jsonl，资源、意图和状态在 target-observations.jsonl。目标另44次 predicted_death只作SL截尾，不计实际死亡；actual won/died匹配冻结SL原行偏移/SHA、attempt、ended_at及end_hp。末回合无下一回合帧时enemy-turn leak为null；整回合HP变化、敌方打穿和显示来袭分开，回血造成的负值不改写。逐回合对照及实际场数见各 before/after-per-turn-*.json，源缺失与模拟未计算均保留。

沿用 `silent-0413`，保留173019与220116两次旧rejected。此次独立重核30个tune Ponder后继：T4后14/14、T8后13/13接诅咒，T12后3/3接Slap；证据包括KAY522KT5NXR F33 T4/8、UACFSW4VDDLD F33 T12、JMH5C51RLN4E F33 T4/8。候选只改 boss-sim.ts、rollout.ts 的整场分支；对Silent已观察进阶0/1/3/4/5/6/7/10按次数区分Ponder后继，其他角色及未观察2/8/9/11保持原路径。新增marker由slimInput在模拟入口写入，只有fullFightState在fullFight条件下读取，再供整场后继和前瞻使用；五回合不读入该字段。没有策略网格、阈值或validation调参，B5不适用。

实盘求解/五回合隔离由基准提交的固定runner执行，before/after逐字节同SHA `1bce9c63060eb08d4225bb1facb368d0f52c6b9e1fc3ff80ca35350ad08d6bc0`。真实撤两份候选源码1失败/2通过，逐字节恢复3通过。原sandbox初次中断130；单worker全量原检查407文件中405通过、3920项通过、2失败：扫描用不完整.ts副本导致导入检查，以及原15秒超时。副本只改文本扩展名、保留原字节与失败，不改断言；同原wrapper补验两文件15通过、第二阶段含paths26通过，综合408文件3933固定项/tsc0。不是声称那次全量rc1为0。指定三文件gitleaks0；撤码、恢复、源检查、失败文件续验日志全部保留。

最终live组合不能用旧候选结果代替。候选期间live已更新rollout及保护源码，快照live-drift.json记录 `ffb51b0bf12b3b49e30ec5b8c689550616d30981`；包含combat-plan、turn-solver、silent-kunai和调度检查等变化。把最终组合带入不可变dispatch基准需要扩本批许可范围；没有修改这些文件、换base或启动live合并。故停止本批旧组合剩余计算，自己的定向中断真实rc130保留，未停止对局或调度。

实际before252/1056条（804未计算），after334/1056条（722未计算）。候选目标完整112条含54G5683J0E5S F33 t1/pre两条no solve；before保留K3676LU8B0UH F48两条no solve。未删validation key。非目标原样本按(key,start)逐键复用本次基准结果222条，未复用旧7e1193校准样本。

| 覆盖 | before t1/pre | after t1/pre |
|---|---:|---:|
| 整体有效val | 21 / 19 | 61 / 59 |
| 目标有效val | 1 / 1 | 41 / 41 |
| 目标打穿回合 | 6 / 6 | 237 / 237 |
| 实际拟合tune | 105 / 105 | 105 / 105 |

这是明确不完整的档案，不能与旧小集或当作配对数值结论。原acceptance.py rc1，自然fail closed，isolation passed且base/head为实际提交。发布条件未满足；本批不是bug-infra。账本仅learner proposed→rejected，无accepted/shipped；交原调度完成通道复核和冷却/有界重试，不关闭学习父要求。

所有固定sources/fights/turns、split/provenance、原始与合并部分results、原生模型核实、机制夹具、原日志偏移/SHA、SL实际结局和截尾、失败初稿、工具缺依赖首失败及原门槛验收完整归档：

- `/home/dw/Projects/agent-sts2/.worktrees/boss-sim-silent-knowledge_demon-20261015-032831/experiments/boss-sim/silent/c93be3983186ab9ca0cd5cadded9a4b70717272a11cec6284bc58aaa5ded9ebf`（唯一新目录，未覆盖旧实验）
- 原验收 `/home/dw/Projects/agent-sts2/.worktrees/boss-sim-silent-knowledge_demon-20261015-032831/learner/runs/20261015-032846-boss-sim-batch/acceptance.json`，对应源脚本的原路径/输入SHA未改写；归档保留副本。
- 临时现场 `/home/dw/Projects/agent-sts2/.worktrees/boss-sim-silent-knowledge_demon-20261015-032831/learner/runs/20261015-032846-boss-sim-batch`，report.md / report.json为最终回报；过程稿report.draft.md保留。

保留源分支与归档，未执行main/live完成回收登记。源码可回退为撤该提交的两源改动，保留数据、失败、原日志和账本历史；本批无已上线行为需要回退。

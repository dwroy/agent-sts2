# Silent / KNOWLEDGE_DEMON B4：20261015-032831-fix-batch（过程稿）

此稿只登记已完成核查；数值验收和发布尚未完成，不宣称上线、可信或胜率收益。

不可变派发 base 为 `7ccd6158140be85a2e75a66d18d2dd7fde697cfc`，证据 key 为 `5baa12a74077bffb444a3d38509db458f84b64094551fb32a337bcedfdc39aa1`。证据原件副本 SHA256 为 `2ec640c01427d1f74b4a8654da4f300a0f23242a6ad1212fdc6a92aa9aae5d61`。初始工作树干净，初始 live 同 base，合 live 为 Already up to date；没有换基准。

原生线程 `01a13be3-8b85-7230-9802-2b8a0387b427` 的 turn_context 第8行核实 `gpt-6.1-sol / xhigh`；见 native-model-audit.json。没有另起模型或其他工作树批次。

授权来自 notes/fix-queue-v4.md「B4 / B5 纳入标准流程」、decision-log 2026-10-07 12:11、学习协议及 docs/boss-sim.md §13/14。统计及机制证据只来自已结束 SILENT 的原日志。common 既有模型是固定模拟输入，没有从铁甲私有经验获取机制。

本轮冻结 295 完局、1291 boss 尝试、528 可用实际结局（386 won、142 died）。原 tune 107 keys 和 `2026-10-06T02:46:11.648000` 切点保持，val 421，较派发增加6。A11 为派发当前进阶，冻结可用战实际最多 A10，不推断 A11 机制。dataset/fights.jsonl、turns.jsonl、sources.jsonl、runs-snapshot.jsonl、sl-snapshot.jsonl、split.json 与 before-provenance.json 全部留档。

知识恶魔 56 实际战，14 tune、42 val；49 won、7 died。原帧共2621、576个回合，逐帧字节偏移、长度、SHA在 raw-frame-hashes.jsonl，资源、敌方意图与状态在 target-observations.jsonl。目标 SL 事件另有44次 predicted_death，明确截尾而不计实际死亡。实际结局逐条匹配冻结 SL 原行偏移/SHA、attempt、ended_at 与 end_hp，见 target-sl-events.jsonl 和 sl-outcome-audit.json。末回合无下一回合帧时，enemy-turn leak 为 null；来袭显示、整回合HP变化和敌方打穿不混为同一指标。

机制不是新发现：沿用 `silent-0413`，保留 20261011-173019 与 220116 两次 rejected。此次重新核实 tune 的30个 Ponder 后继：T4后14/14、T8后13/13接诅咒；T12后3/3接 Slap。机制夹具见 mechanism-fixture.json；固定回归见 agent/tests/silent-knowledge-demon-b4.test.ts。候选仅在 Silent 已观察进阶0/1/3/4/5/6/7/10的整场路径区分 Ponder 阶段，未观察2/8/9/11及铁甲路径保留。没有策略网格或 validation 调参。

新增 silentKnowledgeCycle 只由 boss-sim.slimInput 为目标enemy赋值，fullFightState仅在 fullFight 分支读取，再由整场后继/整场前瞻使用；实盘 solver 源码不改，五回合不会将字段读进 SimEnemy。新增固定测试比较相同 solver/五回合全部决策字段，官方基准 runner 另作逐字节隔离。

初稿失败均保留：audit-raw.initial-failed.log（误计非COMBAT帧）、fixture.initial-failed.log（错误纳入墙钟估算字段）、candidate-draft1.patch/fixture-draft1-failed.log（新字段误读层级）。修正夹具后，撤候选1失败/2通过、恢复3通过。原 source-sandbox.log 中旧固定用例出现超时；本批自己的两路重放和第一轮检查随后定向中断，真实exit130，见 interruption-1.json。没有停止游戏或调度器。单 worker 使用原 tools/test-sandbox.sh 续验，所有旧失败与rc保留。重放续算保持原528行序号、200样本、t1/pre和固定seed，不改 runner 或门槛。

候选期间 live 已推进到 `28bec4afac5c6d51e5f1c30de277c1c6575c188b`，包含 rollout、turn-solver、combat-plan 和 silent-kunai 变化；这不是本批源码。不得把旧候选配对结果冒作最终 live 组合结果，仍沿不可变派发 base 核查，发布受此组合边界约束。

所有过程副本位于本工作树 learner/runs/20261015-032846-boss-sim-batch；最终报告会补充原沙箱结果、候选实际commit、两份trust、配对覆盖与官方验收路径。当前 merged=null、无本批eval版本或shipped。

# 本批策略任务报告

十项派发提案均完成证据与源码范围核验，全部保留waiting。本批没有足以支持新增策略参数或完整关闭提案的证据；已有局部审计/现场事实不冒称整项实现。

## 身份和边界

- task=strategy-proposal，character=silent，batch=20261015-060253-strategy-proposal；原learn.json行reason=proposal，工作树匹配，恰为本次十个proposal_ids，无proposal_repair/research_request/implementation_request。普通专题请求文件的batch属于旧派发，本批不承接它。
- 开工git status干净；原HEAD与main均为`10a19978fb559f1afd952f696fc4d526006a6f0a`，按要求merge返回Already up to date；report.base使用此完整40位提交。
- 本批只核六个派发局，runs.jsonl六行全部SILENT/A10。未读取其他角色知识、未启动游戏/模型/网络、未改变提示或其他owner的请求。
- proposal.md：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-060253/learner/runs/20261015-060308-ba838132-8106-4e3b-a373-6f2d32138e5e-strategy-proposal/proposal.md`。每条原文指纹、账本、层/回合、反例、预期行为和验证方式均在其中。

## 原始证据与固定观察

共用extract_evidence.py冻结六流边界，选中8268行：states 4062、decisions 3941、sl-attempts 38、run-config 6、run-plans 33、brain 188。逐行seek原日志重核身份/原JSON/offset/bytes/SHA以及六个输出SHA，全部一致；日志仍只读。来源流中states/decisions各2条、brain 1条无法解析行保留为未归属，未据此补事实。各流截点与计数见evidence/evidence-manifest.json、raw-integrity-audit.json。

run-plans使用`run`身份，本批33条有效，不能因旧零行初稿声称日志缺失。没有覆盖任何旧报告、截点或零行初稿。

固定观察脚本通过34项原帧事实断言，并核四组完整相同fingerprint。它们是日志核验，不是生产tsc/vitest、反事实重放或模型校准：

| 来源局/层/回合 | 原线→替线实际损HP | 敌本体进度 | 证据决策行 |
|---|---:|---:|---|
| 8JRE1C4H4Z2W F33 T2 | 3→15 | 10→17 | 270216/270282 |
| YF0LXT1QSTGG F48 T1 | 0→9 | 45→38 | 271309/271348 |
| XP2SL33HT0D9 F33 T3 | 9→14 | 24→27 | 271992/272040 |
| XP2SL33HT0D9 F33 T1 | 2→10 | 25→34 | 271982/272195 |

本体进度是起点至下一玩家轮的净HP变化，包含实际毒等已结算效果，不能当攻击牌直伤、整候选执行认证或胜率。四组来自三局，不能作八个独立样本；同存档其他抽弃牌、生成和后继未受控。

机制观察包括：棱柱火花/污染的技能代价与毒挡并存；失落返力与遗忘继续抢敏；蚌加压/虚弱与覆甲现场值；电击当轮仍活及跨轮成长；沙虫末轮5血22挡对37、24毒结一次；实验体清阶段毒/力、零毒触媒、后得敏捷不倒补；双蟹轮初挡、临时减力恢复、朝向/弱分别变化。逐帧实际值在selected-state-facts.json和fixed-observation-checks.json，未补未见公式。

保留的反例：YF F33第二试实胜余20（不是全部SL无效）；XP末试T2零损仍全战失败；YF恢复T1防御线仍败；沙虫延至T11仍死；失落毒杀免去其攻击但末试仍死。固定当轮差异不足以拟血价/成长/能力顺序、留药或必休阈值。

## 逐项处置

| 提案 | 本批处置/具体缺口 |
|---|---|
| silent-proposal-c20b5139dd0dff71 | waiting；已核火花3→6、技能污染和9点实损；现有求解及增长路径不等于本局生产适配器的多步联合校准。缺历史dirty移动表原字节，以及污染、虚弱、毒挡收益的同输入重放；不能据此设少打技能规则。 |
| silent-proposal-ae9e692d680e3819 | waiting；已核失落毒死后返4力、步法恢复负敏捷和遗忘继续抢夺；POSSESS能力层数1不是累计借还额。缺混合增益的来源账与遗忘非清场死亡返敏端点，不能用敌方总属性代替借额或指定固定击杀序。 |
| silent-proposal-52f1e1bd2e7db0ed | waiting；当前进阶HP/攻击从首样本读取及房间代价5样本门槛已有源码；本局11/15/19与弱后11/14已核。缺历史dirty移动表和覆甲触发隔离、同输入生产多步重放，不能把现场序列升为完整成长/减层策略。 |
| silent-proposal-6dd8bbff876be528 | waiting；已核同23上限电击力2→4、攻击17→19及T4才退场，现有逐敌growth路径已存在。缺跨召唤稳定实例身份与新旧机器人增长重置联合校准，未执行的先杀线无后继，不能指定杀序。 |
| silent-proposal-578e415a259e6835 | waiting；原答/护栏/SL候选审计及单动作回执已有live源码；沙虫T2实付3→15、进度10→17已核。整候选完成、抽弃牌后归属和重规划边界仍未知，缺独立完整胜线，不能将部分审计记为整项完成。 |
| silent-proposal-c0767768bf6a7ab1 | waiting；已核实验体同指纹T1实损0→9、进度45→38，并保留F33第二试20血胜的SL反例。候选比较与派发回执只覆盖预测/单动作；缺弃牌后续步归属和受控完整胜线，不能拟SL惩罚系数。 |
| silent-proposal-a46bdb7fe711d79a | waiting；实验体111→212清毒/力、零毒触媒2、23挡不因敏捷5→6倒补均已核，现场快照已有live实现。缺阶段、遗物和抽弃牌的逐候选联合归因及自然消费者校准，不能预支未来毒或调整能力优先级。 |
| silent-proposal-1044224808015e5c | waiting；双蟹同指纹T3实损9→14、进度24→27，T1实损2→10、进度25→34已核。缺完整候选执行归属、受控随机池及独立整战胜线；B2零胜差0不能推出安全或低损新排序有效。 |
| silent-proposal-7cbc6005db712ba9 | waiting；已核船夹板14+6=20、临时减力0→−9→0、朝向/虚弱57→38→28及末轮死亡。轮初挡和减力/朝向的现有局部路径不等于联合校准；缺整候选传播及实际消费者结果，不能改持续价值权重。 |
| silent-proposal-c59f592f1427a67e | waiting；已核两局血价、阶段/毒/格挡时点及SL成功反例；现有审计和快照只覆盖子域。缺各子域整候选实际归属、联合校准及受控路线/留药后继，不能拟全局血价、必休血线或把整个综合提案关闭。 |

## 源码和已存在部分

核15个实际live源码叶及各自祖先commit，详情source-audit.json；核验时live为`ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15`。其中10叶完全相同，另5叶差分原件保存base-vs-live-source.patch；没有把当前main冒称实际live。差异中的逃脱计划条件参考属于其他owner，不合旧枝、不覆盖live；其增量也不提供本批宽提案的完整校准。

已存在的silentSelectionAudit保存候选，silentSelectionDispatch只记录single_action_receipt、state_effect_verified=false、whole_plan_executed=null；silentSlComparison保留actual_turn_result=null；silentPhaseCurrentFacts只列现场且poison_damage_already_dealt=null。它们准确保留未知，并非完整执行已证。普通monsterHpAt/moveDamageAt无五样本门槛，roomHpCost的ROOM_COST_MIN_N=5仍独立。机制接线存在不等于当时dirty数据库已复原。

六局run-config的源码基提交可追溯，但都列有未提交知识数据，包含monster-db/move-model且无其完整原字节绑定；run-config-provenance.json保留具体清单。因此当前刷新数据库不能代替旧实盘实际输入完成生产反事实校准。缺输入不等于原始日志缺失，现有机制也不因这项限制自动判错。

## 记录、验证和上线

- 原十个CLI提案id沿用，无新代码提案id，不修改原提案/队列状态、不冒造implemented或shipped。30个既有账本只经根ledger.py update追加本批追溯；24个已shipped条目的状态/版本不降级，另6个保持proposed。原claim、首证、prior和证据分母不改；不重复记同一证据为新支持局。
- 本批没有修改生产代码、知识数据或任务模板。固定观察脚本仅在本批ignored scratch下；源码撤除/恢复验证不适用，tsc/vitest/cases均null，未运行或冒报成功，不借用旧绿。
- fixes=[]、merged=null；无git源码提交、无live合入、无eval版本、无新规则通知、无自然消费者或收益验收。无须新增策略决定/上线记录；本批处置和全部失败/限制保存在本目录。
- 一次源码核验命令在启动前因并行回收路径消失被沙箱glob扫描拦住，随后原命令重试成功；一次只读rg引用不存在的fight-value.ts导致exit2，未涉及测试或代码失败，原情形记入本报告。没有绕过权限或读取密钥。
- 最终干净状态和零差分见final-worktree-readback.json、base-worktree.patch。根ledger CLI原输入/输出及读回另存本目录，交原运维/调度器继续保留waiting，待具体缺失证据满足后重派。

本批不声明学习已入经验库、大脑已经采用或Roy已确认；十个宽项和相关父要求保持原状态。

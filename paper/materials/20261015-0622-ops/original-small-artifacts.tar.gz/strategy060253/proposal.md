# 本批静默猎手十项策略提案核验

批次：20261015-060253-strategy-proposal；来源任务：strategy-proposal；角色/本批实盘范围：silent A10。

基线：`10a19978fb559f1afd952f696fc4d526006a6f0a`。本批是普通专用队列消费，无 research_request / implementation_request，未领取其他id。`git merge --no-edit main` 返回 Already up to date。

十份原Markdown逐字节SHA均与队列add行相同，原件副本见 original-proposals/；原提案、经验、账本既有结论不改写，不新建重复提案。

本批结论：10项waiting，没有新的生产源码实现、提交、合入或版本。以下源码只证明部分现状，不能关闭整项。


## 1. silent-proposal-c20b5139dd0dff71

原请求：冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。

既有学习账本：silent-0168；来源任务：experience-update；目标：strategy-proposal；原领域：combat。

证据：DUZUBAJ3A8GP F27 T4–T6；states 274830–274839：火花3→6；技能污染0→3→6、0→6→12→18；T5实际46→37。技能施毒/格挡同时存在，不能把污染代价当净收益。

原文：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md`；SHA256：`bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。已核火花3→6、技能污染和9点实损；现有求解及增长路径不等于本局生产适配器的多步联合校准。缺历史dirty移动表原字节，以及污染、虚弱、毒挡收益的同输入重放；不能据此设少打技能规则。

验证/缺数据：以冻结手牌/能力/毒/挡及当前进阶移动表逐步重放技能、污染、虚弱与下一轮污染清零，比较玩家HP和敌本体HP；需保存当时实际dirty数据原字节，不能用刷新JSON冒作旧输入。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 2. silent-proposal-ae9e692d680e3819

原请求：提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。

既有学习账本：silent-0183、silent-0005；来源任务：experience-update；目标：strategy-proposal；原领域：combat。

证据：5PM6JAQG6FNQ F39 T4–T6；states 274351–274362：−4力/敏，两步法只把敏捷−4→−2→0；失落2HP/3毒后退场，次轮玩家力归0；遗忘随后再夺2敏。末试274391–274397单步法只回−2，仍死。

原文：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md`；SHA256：`b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。已核失落毒死后返4力、步法恢复负敏捷和遗忘继续抢夺；POSSESS能力层数1不是累计借还额。缺混合增益的来源账与遗忘非清场死亡返敏端点，不能用敌方总属性代替借额或指定固定击杀序。

验证/缺数据：补抢夺、外部增益、毒杀/直伤死亡及再次抢夺的逐来源账；隔离遗忘未清场死亡的返敏端点。按实体追踪，不从能力层数1或敌方总力量反推累计借额。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 3. silent-proposal-52f1e1bd2e7db0ed

原请求：第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。

既有学习账本：silent-0231；来源任务：experience-update；目标：strategy-proposal；原领域：combat。

证据：CA5KE8GFJ9X2 F13 T1–T5；states 273238/273252/273263：喷水11/15/19，力量0/4/8；273254/273268虚弱后11/14，末轮2HP+10挡不足14。覆甲9/9/8/7/6只记现场。

原文：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md`；SHA256：`651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。当前进阶HP/攻击从首样本读取及房间代价5样本门槛已有源码；本局11/15/19与弱后11/14已核。缺历史dirty移动表和覆甲触发隔离、同输入生产多步重放，不能把现场序列升为完整成长/减层策略。

验证/缺数据：固定实际A10移动表和覆甲状态，逐步比对加压/喷水/虚弱；分别验证血量/攻击首样本路径和房间代价五样本路径，不能共用门槛或用序列臆测减层条件。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 4. silent-proposal-6dd8bbff876be528

原请求：复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。

既有学习账本：silent-0233、silent-0209；来源任务：experience-update；目标：strategy-proposal；原领域：combat。

证据：5PM6JAQG6FNQ F38 T3–T4；states 274308/274313/274317：23上限电击力2→4、攻击17→19；T3仍攻击，T4才退场。主怪/爪牙实体index会随退场重排，不能充当跨召唤唯一身份。

原文：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md`；SHA256：`48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。已核同23上限电击力2→4、攻击17→19及T4才退场，现有逐敌growth路径已存在。缺跨召唤稳定实例身份与新旧机器人增长重置联合校准，未执行的先杀线无后继，不能指定杀序。

验证/缺数据：补召唤前后稳定身份、新旧电击本身的能力与增长记录，再做生产适配器跨轮重放；候选先杀线须有后继证据才讨论策略效果。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 5. silent-proposal-578e415a259e6835

原请求：核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则

既有学习账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016；来源任务：experience-update；目标：strategy-proposal；原领域：combat/sl/structure。

证据：8JRE1C4H4Z2W F33 首/三试T2；decisions 270216/270282指纹相同；states 276208→276212、276274→276278：实损3/15，本体进度10/17。末试T11 276433→276434，5血22挡对37，24毒只结一次后敌130。

原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md`；SHA256：`e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。原答/护栏/SL候选审计及单动作回执已有live源码；沙虫T2实付3→15、进度10→17已核。整候选完成、抽弃牌后归属和重规划边界仍未知，缺独立完整胜线，不能将部分审计记为整项完成。

验证/缺数据：关联原答→HP护栏→SL替换→门禁后动作→后续实帧；抽弃牌/生成/药水和重规划需中止旧候选归属。固定T2、第二试T5和末试T11，只报已执行窗口。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 6. silent-proposal-c0767768bf6a7ab1

原请求：全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。

既有学习账本：silent-0079；来源任务：postmortem；目标：strategy-proposal；原领域：sl/combat。

证据：YF0LXT1QSTGG F48 二/三试T1；decisions 271309/271348同指纹，271354主动结束续步；states 277327→277337、277366→277373：实损0/9、本体进度45/38。F33第二试实胜余20（sl-attempts 929）保留为反例。

原文：`/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md`；SHA256：`28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。已核实验体同指纹T1实损0→9、进度45→38，并保留F33第二试20血胜的SL反例。候选比较与派发回执只覆盖预测/单动作；缺弃牌后续步归属和受控完整胜线，不能拟SL惩罚系数。

验证/缺数据：对同指纹的候选预测和实际窗口分账；校验抽弃牌后是否执行/替换/中断，保留F33 SL成功反例。无受控整战证据，不拟惩罚系数或禁止探索。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 7. silent-proposal-a46bdb7fe711d79a

原请求：实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。

既有学习账本：silent-0021、silent-0027、silent-0028、silent-0085；来源任务：postmortem；目标：strategy-proposal；原领域：combat。

证据：YF0LXT1QSTGG F48 末试T3–T5；states 277512/277513阶段111→212清旧毒/力；277520零毒且触媒2；277523/277526敏捷5→6但挡仍23；277520→277527本体197→160，18HP+23挡不足44。

原文：`/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md`；SHA256：`eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。实验体111→212清毒/力、零毒触媒2、23挡不因敏捷5→6倒补均已核，现场快照已有live实现。缺阶段、遗物和抽弃牌的逐候选联合归因及自然消费者校准，不能预支未来毒或调整能力优先级。

验证/缺数据：冻结阶段切换、零毒触媒、苦无取得敏捷时点及本体伤害分账；逐候选连接状态与执行，测试未执行能力不会获得既成收益，不把当前快照当实际整线校准。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 8. silent-proposal-1044224808015e5c

原请求：核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。

既有学习账本：silent-0079；来源任务：postmortem；目标：strategy-proposal；原领域：combat/sl。

证据：XP2SL33HT0D9 F33 首/二试T3 decisions 271992/272040同指纹：states 278028→278031、278076→278079实损9/14、本体进度24/27。首/末T1 271982/272195同指纹：实损2/10、进度25/34。T4 272076的21/24→23/24仅候选，不能登记实际差值。

原文：`/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md`；SHA256：`4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。双蟹同指纹T3实损9→14、进度24→27，T1实损2→10、进度25→34已核。缺完整候选执行归属、受控随机池及独立整战胜线；B2零胜差0不能推出安全或低损新排序有效。

验证/缺数据：固定两组当轮血价并保留手里剑成长，区分候选数值与完整实打；补配对随机池、整候选归属和独立后置整战，才能验证新并列排序。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 9. silent-proposal-7cbc6005db712ba9

原请求：用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。

既有学习账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242；来源任务：postmortem；目标：strategy-proposal；原领域：combat。

证据：XP2SL33HT0D9 F33 末试T2–T5；states 278236/278237/278240/278242：轮初14挡、临时减力0→−9→0、加6挡至20且零损；278249/278252/278253火箭57→38→28；278260末轮11HP+6挡恰抵17而死亡。

原文：`/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md`；SHA256：`f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。已核船夹板14+6=20、临时减力0→−9→0、朝向/虚弱57→38→28及末轮死亡。轮初挡和减力/朝向的现有局部路径不等于联合校准；缺整候选传播及实际消费者结果，不能改持续价值权重。

验证/缺数据：固定14+6、0→−9→0、57→38→28及末轮死亡，核现有求解/跨轮适配器联合传播和实际消费者；不由场内算术改变持续价值权重。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 10. silent-proposal-c59f592f1427a67e

原请求：核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证

既有学习账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242；来源任务：experience-update；目标：strategy-proposal；原领域：combat/sl。

证据：YF0LXT1QSTGG F48 与 XP2SL33HT0D9 F33：上述三组血价和阶段/敏捷/减力/朝向联合观察。各六次尝试仍各计一个独立局；YF F33第二试赢保留，路线/留药替代结果没有实打对照。

原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md`；SHA256：`81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2`。

预期行为：按原提案先提供有证据的事实与条件，保留全部选项；本批保持当前策略。处置：**waiting**。已核两局血价、阶段/毒/格挡时点及SL成功反例；现有审计和快照只覆盖子域。缺各子域整候选实际归属、联合校准及受控路线/留药后继，不能拟全局血价、必休血线或把整个综合提案关闭。

验证/缺数据：按子域分别补齐执行证据，路线/留药以实盘净资源和重置分账；后置新局按run分组，不把同档SL拆成独立样本，未获得的替线结果继续未知。

反例与限制：本条仅对已核本角色/进阶负责；局部关系不等于整战胜因，未执行线不登记为实际收益。无反事实的部分不填模型参数。

拟合与时间切分：本批只核来源局的固定观察，不拟系数；SL按run归组，后续新局作后置验证，当前没有通过的独立策略验证集。

回退/影响：本批无代码可回退，也无自然收益宣称。后续若有实现，撤生产源码须失败、恢复通过并走原沙箱/live流程；涉及规则实际上线后双通知Roy。


## 当前源码的部分覆盖

- `agent/src/reflex/silent-selection-audit.ts`：实际live祖先源码 `05cd292c6f01bb31e406473d3a9843e659d62b93`；基线/live叶完全相同=true。

- `agent/src/reflex/silent-selection-dispatch.ts`：实际live祖先源码 `bade647f9fe4c9103b40e2f26b26296692ad24b7`；基线/live叶完全相同=true。

- `agent/src/reflex/silent-hp-guard-audit.ts`：实际live祖先源码 `a8b1f8be153fe4f3a34146117546c2178f2e446b`；基线/live叶完全相同=true。

- `agent/src/reflex/silent-sl-comparison.ts`：实际live祖先源码 `a8b1f8be153fe4f3a34146117546c2178f2e446b`；基线/live叶完全相同=true。

- `agent/src/reflex/silent-sl-resource-comparison.ts`：实际live祖先源码 `a8b1f8be153fe4f3a34146117546c2178f2e446b`；基线/live叶完全相同=true。

- `agent/src/reflex/silent-phase-current.ts`：实际live祖先源码 `8698c581dac6c7e957f50a381586960a6d0c9b57`；基线/live叶完全相同=true。

- `agent/src/reflex/silent-phase-reference.ts`：实际live祖先源码 `1d57f9d0dbbb63603e9ce9768e74cb2021478464`；基线/live叶完全相同=true。

- `agent/src/reflex/passive-pieces.ts`：实际live祖先源码 `dba8d7caf9f2b44dd2fd11fd8861ecc14be4c09b`；基线/live叶完全相同=false。

- `agent/src/reflex/turn-solver.ts`：实际live祖先源码 `8e196be494ada9a33dac3d897a0671a5b14e0e5b`；基线/live叶完全相同=false。

- `agent/src/reflex/rollout.ts`：实际live祖先源码 `0944cf8cfd06d345548f5271f1e6521b0cd46656`；基线/live叶完全相同=true。

- `agent/src/reflex/rollout-live.ts`：实际live祖先源码 `ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15`；基线/live叶完全相同=false。

- `agent/src/reflex/combat-plan.ts`：实际live祖先源码 `8e196be494ada9a33dac3d897a0671a5b14e0e5b`；基线/live叶完全相同=false。

- `agent/src/hand/loop.ts`：实际live祖先源码 `a9fcf33ca4c204d03cfc310c7f7ced61f196f964`；基线/live叶完全相同=true。

- `agent/src/knowledge/monster-db.ts`：实际live祖先源码 `4ed3c72df30f27b881da637aebf528b97440e0bb`；基线/live叶完全相同=true。

- `agent/src/sl/explore.ts`：实际live祖先源码 `0d092f6b928a6221eabf3516abad25c48ceaac9c`；基线/live叶完全相同=false。


上述commit均经实际live祖先核验；只作为已存在部分的来源，不填入任何整提案implemented/duplicate结果。基线与live的五个不同叶中，passive-pieces只有历史署名差异；combat-plan/turn-solver/rollout-live含其他owner的逃脱计划条件参考增量，sl/explore还含历史署名差异。差分原件见base-vs-live-source.patch，不合入或覆盖其他owner代码。

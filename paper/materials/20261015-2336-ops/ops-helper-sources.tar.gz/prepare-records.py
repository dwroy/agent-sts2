from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile
root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2336'; pub=r/'paper/materials/20261015-2336-ops'; pub.mkdir(exist_ok=True); sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=r): return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
state=load(r/'ops/codex-ops/learn.json'); bid='20261015-231035-strategy-proposal'; b=state['batches'][bid]; report=b['report']; s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(v is None for v in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
final=load(s/'final-validation.json'); assert final['base']==final['head']==report['base'] and final['git_status_porcelain']=='' and final['diff_bytes']==0 and final['new_commits']==[] and final['ledger_rows']==16
assert final['evidence_material_checks']=={'extract':40,'cases':49,'manual':4} and final['all_waiting'] and final['report_json_verified']
manifest=load(s/'artifact-sha256.json')
for name,x in manifest.items():
 f=s/name; assert f.is_relative_to(s); raw=f.read_bytes(); assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],name
evidence=load(s/'evidence-verification.json'); assert evidence['total_rows']==sum(x['rows'] for x in evidence['streams'])==8444 and len(evidence['checks'])==40 and all(x['pass'] for x in evidence['checks'])
cases=load(s/'case-verification.json'); assert len(cases['checks'])==49 and all(x['pass'] for x in cases['checks']); assert load(s/'manual-observations.json')['checks_passed']==4
summary=load(s/'audit-summary.json'); assert len(summary)==6 and sum(x['segments'] for x in summary)==861 and sum(x['observed_turns'] for x in summary)==777 and sum(x['turn_status']['observed_turn_endpoints'] for x in summary)==415 and sum(x['turn_status']['unknown'] for x in summary)==362 and all(x['full_candidate_results']==0 for x in summary)
prep=load(s/'audit-preparation.json'); assert sum(x['decisions'] for x in prep)==4071 and sum(x['audit_decisions'] for x in prep)==4065 and sum(len(x['exclusions']) for x in prep)==6
assert all(x['exit_code']==0 for x in load(s/'audit-execution.json'))
for x in prep: assert sha((s/(x['run']+'.audit-input.json')).read_bytes())==x['input_sha256']
proposals=load(s/'dispatched-proposals.json'); assert set(proposals)==set(report['code_proposals'])
for ident,x in proposals.items():
 f=Path(x['proposal']); assert f.resolve().is_relative_to(r); assert sha(f.read_bytes())==x['proposal_sha256']==sha((s/(ident+'.original.md')).read_bytes())
source=load(s/'source-readback.json'); equal=0; assert len(source['files'])==13
for x in source['files']:
 raw=git('show',report['base']+':'+x['path']); old=git('show',source['live_head']+':'+x['path']); assert sha(raw)==x['base_sha256'] and sha(old)==x['live_sha256']; assert (raw==old)==x['same_bytes'] and raw.replace(b'Roy',b'Dai')==old.replace(b'Roy',b'Dai'); equal+=raw==old; assert x['live_ancestor']; git('merge-base','--is-ancestor',x['live_last_path_commit'],source['live_head'])
assert equal==10
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
inputs=load(s/'ledger-update-input.json'); owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs): owned.append(raw)
assert len(inputs)==len(owned)==16 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned)
assert set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs}; lv=load(s/'ledger-append-verification.json'); assert lv['rows']==16 and lv['exit_code']==0 and sha((s/'ledger-update-input.json').read_bytes())==lv['input_sha256'] and all(x['nontrace_fields_unchanged'] and x['previous_where_history_notes_preserved'] for x in lv['checks'])
old=git('show',base+':paper/materials/learning/ledger.jsonl'); existing=set(old.splitlines()); added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==16
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(a)==set(z)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
 assert z[ident]['history'][:len(a[ident]['history'])]==a[ident]['history']
 for key,items in a[ident]['where'].items(): assert all(x in z[ident]['where'][key] for x in items)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_no_change_gate=b['no_change_proposals'],native=native,original_final_validation=final,original_artifact_sha_verified=True,original_evidence_rows=8444,original_material_checks={'extract':40,'cases':49,'manual':4},original_six_audit_summary=summary,original_exclusions=prep,source13_sha_and_ancestry_verified=True,equal10_historical_comment_only3=True,owned_learner_cli_rows=16,protected_fold_and_old_history_where_preserved=True,material_and_audit_not_reexecuted=True,limits=['861 segments/777 turn windows have415 observed endpoints and362 unknown; all full-candidate results remain null.', 'Six missing decision_id map/route-change metadata excluded; original4071 decisions versus4065 audit input retained. No continuity invented.', 'KV post-end curse selection/timeout endpoints remain manual; tool turn_end_unverified is not overwritten. Three pending KEN potion receipts not promoted to completed.', 'Historical dirty consumed tree/knowledge, complete per-source execution, controlled full fight/cross-fight outcomes and independent holdout remain missing.', 'No new source, behavior release, tests, game knowledge, wide-parent closure or natural-consumer claims from this batch.']))
publication=load(r/'paper/materials/20261015-2321-ops/publication.json'); cbid='20261015-224302-strategy-proposal'; cb=state['batches'][cbid]; found=[x for x in cb['fallback_checks'] if x['tree']==publication['tree']]; assert len(found)==1; check=found[0]; assert check['rc']==0 and check['merged']==publication['actual_live']
logpath=Path(check['log']); raw=logpath.read_bytes(); log=re.sub(r'\x1b\[[0-9;]*m','',raw.decode()); assert '487 passed' in log and '4909 passed' in log and '2 skipped' in log and '637.88s' in log
assert git('rev-parse','HEAD','HEAD^{tree}',cwd=r/'.worktrees/live').decode().splitlines()==[publication['actual_live'],publication['tree']]
git('merge-base','--is-ancestor',publication['source'],check['merged']); versions=load(r/'eval/versions.json'); numbers=[x for x in versions['release_numbering']['releases'] if x['release_id']==publication['release_id']]; assert len(numbers)==1 and numbers[0]['commit']==publication['behavior_commit']
assert cb['state']=='failed' and cb['rc']==0 and cb['report']['merged'] is None
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
closure=dict(at=at,original_batch=cbid,release_id=publication['release_id'],source=publication['source'],actual_live=check['merged'],exact_tree=check['tree'],original_canonical_check=check,full_tsc_exit=0,full_vitest_exit=0,files=487,passed=4909,skipped=2,duration_seconds=637.88,log=dict(path=str(logpath.relative_to(r)),bytes=len(raw),sha256=sha(raw)),original_failed_rc0_mergednull_and_conflicts_preserved=True,prior_pending_receipts_unmodified=True,new_merge_release_test_request_or_ledger_cli=False,natural_consumers='pending next natural matching Silent A10 Pounce coverage payload; no forced model/game requests',wide10proposals='waiting')
write(pub/'host-closure.json',closure); (pub/'host-full.log').write_bytes(raw); pending=load(r/'ops/codex-ops/pending-integrations'/f'{cbid}.json'); pending.update(at=at,host_result='passed precisef7335686 tree',host_closure='paper/materials/20261015-2336-ops/host-closure.json'); write(pub/'publication-acceptance.json',pending); write(r/'ops/codex-ops/pending-integrations'/f'{cbid}.json',pending)
decision=f'\n- {at} 运维codex：2336两事件收尾：原224302策略d3e57c77/V5-R364的精确livecfa1c0be/treef7335686宿主完整tsc/vitest0、487文件4909过2跳/637.88秒，唯一fallback/完整日志SHA核；只关闭此树host，原failed/rc0/mergednull、六冲突/旧pending/红绿保持，不重复合入/发号/请求检查/CLI，下一自然匹配猛扑覆盖消费者及十宽父待验。原231035策略done0/no-source，a37干净WT/HEAD不变、十waiting/testsnull/域空，未补测或空合；六Silent A10原8444行/40+49+4材料检查及六原离线审计SHA核，不重跑/不当生产测试。原861题段777轮窗415观察端点362未知、整候选全null；6无decision_id原map/route-change元数据排除，4071对4065输入保持、不跨缺口造连续性。KV诅咒/超时后端点仍手工未认证，KEN三pending药水不升completed，PU原获胜/相关SL与历史dirty输入缺口保持，不校准统一阈值或关闭资源宽父。13叶旧livee1逐SHA/祖先核10同3历史注释差，16所属CLI纯where/note逐输入/输出ID及私有fold全部非追溯/旧history/where保持，不重复写或降级shipped；native Sol6.1/xhigh/input/lease/workspace-write/no-network实际核，原未独立读模型声明不改。仅本人记录/数据提交，保并行脏记录，不新知识/代码/版本/论文刷新/派发/重启或改账号home模型权限prompt。证据paper/materials/20261015-2336-ops/。\n'
note=f'\n- {at} [ops 验收收尾] V5-R364最终livecfa1c0be/treef7335686宿主tsc/vitest0，487文件4909过2跳；原唯一检查已核，无重复发布/检查，下一自然匹配猛扑消费者仍pending。原231035十项waiting、无源码/生产测试，16所属CLI仅追溯已核。回执paper/materials/20261015-2336-ops/host-closure.json。\n'
handoff=f'\n- {at} V5-R364 d3e57c77原224302策略精确f7335686/livecfa1c0be完整宿主tsc/vitest0（487文件4909过2跳/637.88s），原唯一fallback及日志SHA收尾；新树host pending关闭，不重复请求/借旧树绿。原failed/mergednull/六冲突不改，下一自然匹配Silent A10猛扑known=false及unknownCards消费者仍pending，十宽提案保持waiting，原source WT继续既有retention门槛；不人为开局或新派模型。原231035策略材料不是自然消费者。回执paper/materials/20261015-2336-ops/host-closure.json。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note,'notes/ops-handoff.md':handoff}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,own_ledger_rows=16,exact_host_passed=publication['tree'],release_unchanged='V5-R364',no_new_source_or_test_request=True,natural_consumers='pending'))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<700000]+[s/'evidence/evidence-manifest.json',s/'run-identity/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts); helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(waiting=10,owned_rows=16,host_passed=True,paths=len(entries))))

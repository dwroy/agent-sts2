import collections
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', SCRATCH.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
proposals = json.loads((SCRATCH / 'dispatched-proposals.json').read_text())
runs = list(dict.fromkeys(r for p in proposals.values() for r in p['runs']))
by_run = {r: collections.defaultdict(list) for r in runs}
verified = []
checks = []

def check(label, condition):
    checks.append({'label': label, 'pass': bool(condition)})
    if not condition:
        raise AssertionError(label)

for directory in ('evidence', 'run-identity'):
    for manifest in json.loads((SCRATCH / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        path = SCRATCH / directory / (stream + '.evidence.jsonl')
        check(stream + ': 抽取文件SHA', hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256'])
        counts = collections.Counter()
        with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source, path.open() as handle:
            for line in handle:
                item = json.loads(line)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert extract.run_identity(item['row']) == item['run_id'] in by_run
                counts[item['run_id']] += 1
                row = {**item['row'], '_line': item['line'], '_source_sha256': item['sha256']}
                by_run[item['run_id']][stream].append(row)
        check(stream + ': 全行offset/bytes/SHA/正文/身份', dict(counts) == manifest['counts'])
        verified.append({'stream': stream, 'source_size': manifest['source_size'], 'rows': sum(counts.values()), 'counts': counts})

def frame(row):
    state = row.get('state', {})
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': row['_line'], 'observed_ts': row.get('observed_ts'),
        'run': state.get('run_id'), 'floor': (state.get('run') or {}).get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', (state.get('run') or {}).get('current_hp')),
        'block': player.get('block'), 'player_powers': player.get('powers'),
        'potions': (state.get('run') or {}).get('potions'),
        'hand': [(c.get('card_id'), c.get('index'), c.get('resolved_rules_text')) for c in combat.get('hand', [])],
        'enemies': [{k: e.get(k) for k in ('enemy_id', 'current_hp', 'max_hp', 'powers', 'intents', 'move_id', 'is_alive')} for e in combat.get('enemies', [])],
    }

selected_decisions = {272434, 272575, 272531, 272652, 272483, 272820, 272361,
                      274505, 274568, 274484, 274601, 274354, 274087,
                      274131, 274156, 274185, 274235, 274237, 274267, 274272}
keyframes = {}
preparation = []
attempts = []
for run, streams in by_run.items():
    check(run + ': runs身份', len(streams['runs']) == 1 and streams['runs'][0]['character'].lower() == 'silent' and streams['runs'][0]['ascension'] == 10)
    check(run + ': states身份', all((r['state'].get('run') or {}).get('character_id') == 'SILENT' and (r['state'].get('run') or {}).get('ascension') == 10 for r in streams['states']))
    original = streams['decisions']
    good = []
    excluded = []
    seen = set()
    for d in original:
        ident = d.get('decision_id')
        if not isinstance(ident, str) or not ident.strip():
            excluded.append({'line': d['_line'], 'reason': '缺decision_id', 'label': d.get('label'), 'screen': d.get('screen')})
        elif ident in seen:
            raise AssertionError('重复decision_id: ' + ident)
        else:
            seen.add(ident)
            good.append(d)
    check(run + ': 原决策观测顺序', all(str(a.get('observed_ts', '')) <= str(b.get('observed_ts', '')) for a, b in zip(good, good[1:])))
    data = {'run': streams['runs'][0], 'states': streams['states'], 'decisions': good}
    input_path = SCRATCH / (run + '.audit-input.json')
    input_path.write_text(json.dumps(data, ensure_ascii=False) + '\n')
    preparation.append({'run': run, 'decisions': len(original), 'audit_decisions': len(good), 'states': len(streams['states']), 'exclusions': excluded,
                        'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest()})
    for d in original:
        if d['_line'] in selected_decisions or (run == 'KV0JHNJCKXLS' and d.get('floor') == 33 and d.get('turn') in [1, 5] and str(d.get('label', '')).startswith('combat/plan-choice')):
            keyframes[str(d['_line'])] = {'decision': d, 'matching_states': [frame(s) for s in streams['states'] if s.get('observed_ts') == d.get('observed_ts') and s.get('fingerprint') == d.get('fingerprint')]}
    for a in streams['sl-attempts']:
        attempts.append({k: a.get(k) for k in ('_line', 'run_id', 'floor', 'encounter', 'attempt', 'result', 'turns', 'end_hp', 'end_block', 'incoming', 'explore', 'summary')})
    if run == 'YQL8RZ8BWN1E':
        poison_frames = [s for s in streams['states'] if s['_line'] in (280160, 280161)]
        check('YQL毒水前后帧存在', len(poison_frames) == 2)
        keyframes['YQL毒水'] = [frame(s) for s in poison_frames]
        for s in poison_frames:
            f = frame(s)
            check('YQL帧' + str(s['_line']) + ': 血挡/自爆', f['hp'] == 26 and f['block'] == 13 and f['enemies'][0]['intents'][0]['damage'] == 41)

for a, b in [(272434, 272575), (272531, 272652), (272483, 272820), (274505, 274568), (274484, 274601)]:
    check(str(a) + '/' + str(b) + ': 同指纹', keyframes[str(a)]['decision']['fingerprint'] == keyframes[str(b)]['decision']['fingerprint'])

(SCRATCH / 'keyframes.json').write_text(json.dumps(keyframes, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'attempts.json').write_text(json.dumps(attempts, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'audit-preparation.json').write_text(json.dumps(preparation, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'evidence-verification.json').write_text(json.dumps({'streams': verified, 'total_rows': sum(x['rows'] for x in verified), 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'rows': sum(x['rows'] for x in verified), 'checks_passed': len(checks), 'audit_preparation': preparation}, ensure_ascii=False))

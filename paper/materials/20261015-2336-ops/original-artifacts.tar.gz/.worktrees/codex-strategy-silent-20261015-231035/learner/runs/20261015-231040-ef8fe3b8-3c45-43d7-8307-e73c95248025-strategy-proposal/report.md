# 静默猎手策略队列复核报告

记录时间：2026-10-15T23:17:50+08:00（写入前已执行date）。

10个派发提案全部逐项核对，均保留waiting。无足够证据支持新策略阈值或整战因果；现有窄诊断不能代替完整提案验收。没有源码/知识修改、提交、live合入、eval版本或shipped。本任务未将报告完成当学习入库父要求完成。

## 身份、范围与原件

- 批次20261015-231035-strategy-proposal；根learn.json对应行task=strategy-proposal、character=silent、reason=proposal，绑定本工作树和十原ID，无research_request/implementation_request；不是第1.2节纯研究绑定，不读其他专题来替代。
- 完整base：a37b9d065d05ae3d06aae7591a606ebdb7aa7121。开工工作树干净；git merge --no-edit main为Already up to date。保存baseline.diff.patch；最终HEAD与tracked差异检查见final-validation.json，不制造空提交。
- 六局runs.jsonl均SILENT/A10，原code均带dirty；没有恢复历史dirty源码，不声称按精确历史执行树重放。运行引擎设置未修改，未独立读取原生模型会话元数据，不冒称已验证实际模型/强度。
- 原队列十份Markdown逐份SHA一致，保留原路径和副本；账本16个既有ID均silent。只通过根ledger CLI追加where/note追溯，不改旧claim、证据、首证、prior、已有status/version，不重复添加支持样本或提案ID。

## 原字节与审计

共用extract_evidence.py冻结各流截点，逐行回查原文件offset/bytes/SHA、JSON正文和run_identity，8444行通过；其中默认六流8438行，另runs身份6行。全源有states/decisions各2行、brain1行解析无效，抽取范围和计数保存在manifest，不推断其属于本局。未覆盖旧输出或零行初稿。

| 流 | 本批行数 | 冻结source_size字节 |
|---|---:|---:|
| states | 4167 | 13187137475 |
| decisions | 4071 | 1692499077 |
| sl-attempts | 43 | 41416068 |
| run-config | 6 | 1790852 |
| run-plans | 21 | 8212147 |
| brain | 130 | 607941586 |
| runs | 6 | 338844 |

抽取材料检查40项、关键案例49项、补充原帧检查4项均通过；这些是证据材料检查，不是tsc/vitest或策略成功案例。检查脚本和所有原输入/输出均位于本批scratch。

现有learner/audit-selection.ts按六局串行离线运行，均exit0，不调用模型/网络、不读取刷新知识。6条缺decision_id的map/route-change元数据另列排除，保留原行号，原决策共4071行、审计输入4065行；不跨缺口补造连续性。

| 局号 | 选线题段 | 回合窗口 | 可核净变化端点 | unknown |
|---|---:|---:|---:|---:|
| 751FN9QM9MHQ | 96 | 129 | 83 | 46 |
| KV0JHNJCKXLS | 92 | 114 | 31 | 83 |
| YQL8RZ8BWN1E | 213 | 114 | 63 | 51 |
| L9SGRBB5R698 | 228 | 125 | 65 | 60 |
| PU80F84P6HPN | 136 | 183 | 103 | 80 |
| KEN58SH9SLZ6 | 96 | 112 | 70 | 42 |

共861题段、777回合窗口，415有端点、362未知；全部完整候选收益仍null。工具只建立已落盘链，不能证明同一候选全部执行或因果收益。

## 关键复核与保留限制

751 F17 T2/T7/T13与KEN F17 T5/T10的10个关键回合端点均与原账本观察一致；具体源状态行、净损和敌净扣见case-verification.json。751 T7题面伤9/15、整轮净扣12/18分别保存，不能把题面牌伤当整轮实果。五组同指纹均已核，相关SL不是独立局。

KV F33第4/5试T5观测端点玩家均30→30、敌净扣36/29；实际结束请求后还有诅咒选择及超时重试。现有工具保持turn_end_unverified，本次手工端点只记manual-observations.json，不把它改称认证整轮或逐来源毛伤。缺保持后轮条件的整战支线、敌回血逐源和路线/休息反事实。

YQL F17末T10毒2→8，26血/13挡/41自爆不变；不把新增毒当减伤、当前本体进度或提前喝必胜。PU第5试F17真实won保留，L9/YQL失败不代表所有巨兽样本失败；改变SL排序的受控后继仍未知。

KEN七次use_potion逐一匹配唯一前帧与连续后帧空槽；三次原pending回执原样保留，不升级成completed。该观测未隔离随机选牌、重问后收益、F15不喝或跨战留药效果。六次步法实际请求回合3/5/5/5/5/9，能力建立窗口与本轮省血不能合成统一规则。

## 已有源码范围

只读live快照e1e7ee853b627919a6d1eab51c0cdf263b0bb852。13个相关源码叶10个字节相同；potion-cost.ts、sl/explore.ts、sl/controller.ts的差异仅历史Roy/Dai注释，实际差异另存live-comment-differences.patch，不为等价重写历史。不宣称全仓库或历史dirty源码等价，也未运行全树转译检查。

已有路径最后修改提交均核为该live祖先：candidate comparison/selection audit，single-action dispatch，held loss，potion reference，giant phase/final resources；逐文件SHA与提交见source-readback.json。它们分别提供候选预测、回执、保守持牌损血和当前阶段事实，actual_turn/full candidate归属仍未知。anchorRank继续先存活轮数再原始enemyHpLeft，并未改占位血tie-break。这些是已有子范围，不将任一宽提案记duplicate或本批implemented。

## 十项处置与交付

完整证据、局号/层/回合/账本、反例、旧规则、预期行为、验证切分和回退均在proposal.md逐ID记录；report.json带全部10个proposal_results。10项waiting分别等待各自的完整执行归属、逐源结算、受控整战/跨战支线或独立留出，不能以同局更多SL替代。

本批无新增源码或知识规则。撤源码失败/恢复通过不适用；tsc/vitest/cases均null且未运行，不伪造0或借旧树绿。无提交无需提交前扫描或测试；所有输出保留在忽略的learner/runs任务目录，不改本分支tracked文件。不合live、不取上线锁、不发新版本、不标shipped、不发实际上线通知。账本只经CLI追加16行where/note追溯，已核全部非追溯字段与原where/history/notes前缀保持（ledger-append-verification.json）；根队列最终处置由调度器读取report.json，不手改队列或请求。

运维交付路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-231035/learner/runs/20261015-231040-ef8fe3b8-3c45-43d7-8307-e73c95248025-strategy-proposal/proposal.md；最终报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-231035/learner/runs/20261015-231040-ef8fe3b8-3c45-43d7-8307-e73c95248025-strategy-proposal/report.md。父要求、自然消费者和收益验证保持开放。

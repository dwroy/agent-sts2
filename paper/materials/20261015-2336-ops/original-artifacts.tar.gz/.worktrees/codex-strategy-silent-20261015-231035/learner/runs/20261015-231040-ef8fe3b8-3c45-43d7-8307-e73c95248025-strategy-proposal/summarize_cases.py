import collections
import json
from pathlib import Path

S = Path(__file__).resolve().parent
checks = []

def check(label, condition):
    checks.append({'label': label, 'pass': bool(condition)})
    if not condition:
        raise AssertionError(label)

expected = {
    '751FN9QM9MHQ': {(1, 2): (13, 9), (3, 2): (18, 18), (2, 7): (13, 12),
                    (4, 7): (23, 18), (1, 13): (8, 17), (6, 13): (2, 11)},
    'KEN58SH9SLZ6': {(4, 5): (7, 1), (6, 5): (5, 2), (4, 10): (15, 2), (5, 10): (21, 4)},
}
cases = []
summary = []
for execution in json.loads((S / 'audit-execution.json').read_text()):
    run = execution['run']
    check(run + ': 审计入口退出0', execution['exit_code'] == 0)
    audit = json.loads((S / (run + '.audit.json')).read_text())
    check(run + ': 完整候选收益保持未知', all(x['actual_full_candidate_result'] is None and x['actual_rollout_best'] is None for x in audit['segments']))
    summary.append({'run': run, 'segments': len(audit['segments']), 'turn_windows': len(audit['observed_turns']),
                    'turn_status': dict(collections.Counter(t['status'] for t in audit['observed_turns'])),
                    'unknown_reasons': dict(collections.Counter(t['reason'] for t in audit['observed_turns'] if t['status'] == 'unknown'))})
    for turn in audit['observed_turns']:
        key = turn['attempt'], turn['turn']
        if turn['floor'] != 17 or key not in expected.get(run, {}):
            continue
        f = turn['facts']
        check(run + str(key) + ': 回合端点', turn['status'] == 'observed_turn_endpoints')
        observed = -f['player_hp_delta'], -f['enemy_hp_changes'][0]['hp_delta']
        check(run + str(key) + ': 净损血/净扣敌', observed == expected[run][key])
        cases.append({'run': run, 'floor': 17, 'attempt': key[0], 'turn': key[1],
                      'state_lines': [f['before']['source_line'], f['after']['source_line']],
                      'hp_loss_net': observed[0], 'enemy_hp_decrease_net': observed[1],
                      'candidate_causality': None})

ken = json.loads((S / 'KEN58SH9SLZ6.audit-input.json').read_text())
state_by_line = {r['_line']: r for r in ken['states']}
potions = []
expected_potions = ['ATTACK_POTION', 'STABLE_SERUM', 'SPEED_POTION', 'WEAK_POTION',
                    'ATTACK_POTION', 'GLOWWATER_POTION', 'SKILL_POTION']
for d in ken['decisions']:
    chosen = d.get('chosen') or {}
    if chosen.get('action') != 'use_potion':
        continue
    before = [s for s in ken['states'] if s.get('observed_ts') == d.get('observed_ts') and s.get('fingerprint') == d.get('fingerprint')]
    check('KEN药水' + str(d['_line']) + ': 唯一前帧', len(before) == 1)
    b = before[0]
    a = state_by_line[b['_line'] + 1]
    slot = chosen['option_index']
    bp = next(p for p in b['state']['run']['potions'] if p['index'] == slot)
    ap = next(p for p in a['state']['run']['potions'] if p['index'] == slot)
    check('KEN药水' + str(d['_line']) + ': 连续状态槽位耗用', bp['occupied'] is True and ap['occupied'] is False and a['state']['turn'] == b['state']['turn'])
    potions.append({'decision_line': d['_line'], 'floor': d['floor'], 'turn': d['turn'],
                    'state_lines': [b['_line'], a['_line']], 'slot': slot, 'potion': bp['potion_id'],
                    'original_result': d.get('result'), 'after_slot_occupied': ap['occupied'],
                    'full_potion_plan_benefit': None})
check('KEN七次药水ID顺序', [p['potion'] for p in potions] == expected_potions)
check('KEN三次pending保持原样', sum(p['original_result'].startswith('pending') for p in potions) == 3)

attempts = json.loads((S / 'attempts.json').read_text())
attempt_summary = []
for run in [r['run'] for r in summary]:
    rows = [a for a in attempts if a['run_id'] == run and a['floor'] == 17]
    attempt_summary.append({'run': run, 'floor': 17, 'attempts': [{'attempt': a['attempt'], 'result': a['result'], 'turns': a['turns'], 'end_hp': a['end_hp']} for a in rows]})
    if run == 'PU80F84P6HPN':
        check('PU第五试F17实际胜', any(a['attempt'] == 5 and a['result'] == 'won' for a in rows))

out = {'checks': checks, 'audit_summary': summary, 'paired_turn_cases': cases, 'ken_potions': potions,
       'floor17_attempts': attempt_summary,
       'limitations': ['净HP端点不等于逐来源伤害或完整候选因果。', 'KV T5在结束请求后仍有诅咒选牌/超时重试，现有审计保持turn_end_unverified。', '未运行未执行支线，不拟合策略阈值。']}
(S / 'case-verification.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks_passed': len(checks), 'paired_turn_cases': len(cases), 'ken_potions': len(potions), 'audit_summary': summary}, ensure_ascii=False))

from pathlib import Path
import fcntl,hashlib,json,os,subprocess,sys
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261016-g1c-publication';pub=r/'paper/materials/20261016-global-build-g1c';sha=lambda b:hashlib.sha256(b).hexdigest()
source='9579e378f0c3cd668d6301c0fa1ea4bd15a2ff13';base='50e2da099a5e1745878070ea960f3160324f2217'
template=(r/'ops/codex-ops/record-staging/20261016-0240/publish.py').read_text();exec(template[template.index('def git('):template.index('assert not (pub/')].replace('.ops-poison.tmp','.ops-g1c.tmp'))
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
candidate=json.loads((pub/'source-candidate.json').read_text());disposition=json.loads((pub/'ops-source-disposition.json').read_text());assert candidate['source']==source and disposition['source']==source and disposition['status'].startswith('accepted')
assert not (pub/'ops-publication.json').exists()
paths=list(candidate['files'])
lock=(r/'ops/live-merge.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:
    at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
    log=r/'ops/codex-ops/learner/20261016-071301-strategy-proposal.fallback-adb0266d517d31a17f3b14d07143bea924f95eca.checks.log'
    observed=log.read_bytes() if log.exists() else b''
    stat=os.fstat(lock.fileno());key=f'{os.major(stat.st_dev):02x}:{os.minor(stat.st_dev):02x}:{stat.st_ino}'
    owners=[line for line in Path('/proc/locks').read_text().splitlines() if key in line]
    receipt=dict(at=at,actor='ops',status='accepted source; integration blocked by original live lock',source=source,base=base,paths=candidate['files'],lock='ops/live-merge.lock',lock_rows=owners,original_G4_tree='adb0266d517d31a17f3b14d07143bea924f95eca',original_channel='20261016-071301-strategy-proposal',host_log=dict(path=str(log.relative_to(r)),observed_bytes=len(observed),observed_sha256=sha(observed),RUN_observed=b'RUN' in observed),any_main_live_HEAD_index_or_source_mutation=False,helper_or_report_started=False,source_full_repeated=False,source_full_rc=1,two_supplements_rc=[0,0],next='Original adb0 learner-checks completion wakes ops; reacquire same live lock once and execute this immutable five-leaf integration, then deployed helper once and final combined-tree host along same channel. No timer, repeated waiting or new learner.',scope='No game behavior version, S decision or account/home/model/prompt/game change')
    save(pub/'ops-integration-lock-receipt.json',receipt)
    pending=r/'ops/codex-ops/pending-integrations/global-build-g1c.json';pending.parent.mkdir(parents=True,exist_ok=True)
    save(pending,{**receipt,'integrate_script':str((p/'integrate.py').relative_to(r)),'disposition_receipt':str((pub/'ops-source-disposition.json').relative_to(r))})
    save(pub/'ops-cadence-readback.json',dict(at=at,actor='ops',status='pending actual integration; helper not started',integrated=False,archive=None,manifest=None,state=None,decision_marker=None,readback_passed=False,reason='Preserve original G4 adb0 full check holding live lock; execute only deployed same helper after integration, not old report.py',original_source_hook=dict(file='ops/report.py',caller='ops/autoplay.sh REFRESH_WAIT=1 at actual ended-run boundary',function='global_build_funnel(run_char)',helper='nice -n19 <root>/data/logdb-venv/bin/python <root>/ops/global_build_funnel.py --root <root> --character silent',source_sha256=candidate['files']['ops/report.py']),source_hook_is_live_consumption=False))
    print('original live lock busy; no source/HEAD/index mutation; bounded original-event continuation saved',flush=True)
    sys.exit(75)
with lock:
    at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
    mh=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip()
    assert subprocess.run(['pgrep','-f','/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'],capture_output=True).returncode==1
    assert not git('diff','--name-only','HEAD','--','knowledge',cwd=live).strip()
    values={};before={}
    for path,h in candidate['files'].items():
        raw=blob(source,path);assert sha(raw)==h;values[path]=raw
        f=p/'source-scan'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
    for cwd,head in [(r,mh),(live,lh)]:
        assert not git('diff','--cached','--name-only',cwd=cwd).strip() and not git('ls-files','-u',cwd=cwd).strip()
        for path in paths:
            assert blob(head,path,cwd)==blob(base,path)
            actual=(cwd/path).read_bytes() if (cwd/path).exists() else None
            assert actual==blob(head,path,cwd)
        before[str(cwd)]={path:sha((cwd/path).read_bytes()) for path in git('diff','--name-only','HEAD',cwd=cwd).decode().splitlines() if path not in paths}
    with (pub/'ops-source-gitleaks.log').open('wb') as scan:
        check=subprocess.run(['nice','-n','19','gitleaks','dir',str(p/'source-scan'),'--redact','--no-banner','--report-format','json','--report-path',str(p/'source-gitleaks.json')],stdout=scan,stderr=subprocess.STDOUT,env={**os.environ,'GOMAXPROCS':'1'})
    assert check.returncode==0 and json.loads((p/'source-gitleaks.json').read_text())==[]
    stages=[]
    for cwd,head,label in [(r,mh,'main'),(live,lh,'live')]:
        env={**os.environ,'GIT_INDEX_FILE':str(p/(label+'.index'))};git('read-tree',head,env=env,cwd=cwd)
        for path,raw in values.items():stage(path,raw,env,cwd)
        tree=git('write-tree',env=env,cwd=cwd).decode().strip();assert set(git('diff','--name-only',head,tree,cwd=cwd).decode().splitlines())==set(paths)
        new=commit(tree,[head,source],'Integrate fixed-ten G1c evaluation and existing post-run hook',cwd);stages.append((cwd,head,env,new,tree))
    locks=locks_for([(v[0],v[2]) for v in stages])
    try:
        for cwd,head,env,new,tree in stages:
            assert git('rev-parse','HEAD',cwd=cwd).decode().strip()==head
            assert all(sha((cwd/path).read_bytes())==h for path,h in before[str(cwd)].items())
        for cwd,head,env,new,tree in stages:
            git('update-ref','-m','ops: original G1c exact five-leaf integration','HEAD',new,head,cwd=cwd)
            for path,raw in values.items():install(cwd,path,raw)
        for index,lp in locks:os.replace(lp,index)
    finally:
        for _,lp in locks:
            if lp.exists():lp.unlink()
    for cwd,head,env,new,tree in stages:
        assert not git('diff','--cached','--name-only',cwd=cwd).strip();git('merge-base','--is-ancestor',source,'HEAD',cwd=cwd)
        assert blob(head,'eval/versions.json',cwd)==blob(new,'eval/versions.json',cwd)
        assert all(sha((cwd/path).read_bytes())==h for path,h in before[str(cwd)].items())
    save(pub/'ops-publication.json',dict(at=at,source=source,base=base,main=stages[0][3],old_main=mh,actual_live=stages[1][3],old_live=lh,tree=stages[1][4],leaves=candidate['files'],unrelated_dirty_preserved=before,registry_unchanged=True,new_behavior_release=False,source_full_rc1_preserved=True,source_failure_disposition=str((pub/'ops-source-disposition.json').relative_to(r)),cadence='pending same deployed helper once',host='pending one original serial channel final-composition request'))
    print(json.dumps(dict(integrated=True,main=stages[0][3],live=stages[1][3],tree=stages[1][4],new_behavior_release=False)),flush=True)

from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-g1c-publication';pub=r/'paper/materials/20261016-global-build-g1c';sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((pub/'ops-integration-lock-receipt.json').read_text());assert x['any_main_live_HEAD_index_or_source_mutation'] is False
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
text=f"\n- {at} 运维codex：已本人实读原global-build G1c source9579e378f0c3cd668d6301c0fa1ea4bd15a2ff13/base50e2da099的五叶/SHA、reviewed全检与两原题补验。处置：接受未变源的两补验作为集成依据，保完整tsc0/Vitest rc1（492文件490过2失败、4920过2失败4跳/1315.51s）；既有brain stalled twice只0s/1s首token时序断言差与缺现有venv链接分列，原题各rc0，未改断言/时限/源或安装依赖，不重跑此源full/新派研究修复。原live锁非阻塞尝试被G4 adb0266d517d31a17f3b14d07143bea924f95eca宿主full持有而拒绝，先于任何main/live HEAD/index/源变更退出75，不等待/轮询/打断或另造管线。精确五叶待原G4 learner-checks事件后在同锁窄集成，保全部知识/记录/历史注释及版本表，纯评估/局末归档不增行为号；同一最终组合再沿原071301唯一通道一次host。真正集成后只跑已部署helper一次完成初始十局边界归档并核manifest/state/唯一decision marker，不重跑旧report.py；当前helper未启动、归档/生产钩子消费未通过，不拿源设计或启动充完成。旧24局首试floor/victory相符和16条passed字段差异保留；S仍Roy决定，G1a/G4原owner、0332宽父与当前局/账号home模型权限prompt预算不动。本人处置/锁及未执行边界见paper/materials/20261016-global-build-g1c/ops-source-disposition.json、ops-integration-lock-receipt.json、ops-cadence-readback.json；唯一pending为ops/codex-ops/pending-integrations/global-build-g1c.json，原不可变恢复脚本ops/codex-ops/record-staging/20261016-g1c-publication/integrate.py。\n"
appends=[]
for path in ['notes/for-roy.md','ops/inbox-dev.md','paper/materials/decision-log.md','notes/ops-handoff.md']:
    f=r/path;before=f.read_bytes();raw=text.encode()
    with f.open('ab') as out:out.write(raw)
    appends.append(dict(path=path,offset=len(before),bytes=len(raw),sha256=sha(raw),text=text))
(p/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n')
(pub/'ops-record-appends.json').write_text(json.dumps([{k:v for k,v in a.items() if k!='text'} for a in appends],ensure_ascii=False,indent=2)+'\n')
message=f"【原roy-20261016-global-build/G1c同交付ops本人处置；不是新任务】{at} 已读回9579e378五叶源码/全检两失败/两窄补验，正式ops-source-disposition.json接受未变源的补验并保full rc1，不改测试/时限、不重源full或新研究。当前原G4 adb0完整host仍持ops/live-merge.lock，非阻塞取锁75，未改main/live/普通index或任何源；无归档helper/report.py启动。精确未变五叶已备窄合脚本及唯一pending，等原G4 learner-checks事件后同锁集成、保所有并行知识记录/原编号，再同唯一071301通道对最终组合一份host；不新行为号。真正集成后直接已部署同helper一次初始边界归档，实际核manifest/state/marker和根report钩子，不重跑report.py。ops-cadence-readback.json现明确pending/no archive，没拿source-only/启动充完成；旧24/16边界原件保留。材料在paper/materials/20261016-global-build-g1c/ops-source-disposition.json、ops-integration-lock-receipt.json、ops-cadence-readback.json；唯一pending ops/codex-ops/pending-integrations/global-build-g1c.json。G1a/G4原owner、G4 R367及其自然/fixed消费者、0332父与S待Roy决定/现局账号home模型prompt均保持。本运输不代你/Roy ACK，无需再实现或重跑任何full。"
(pub/'ops-disposition-message.txt').write_text(message)
get=subprocess.run(['herdr','agent','get','wJ:pJT'],capture_output=True);(p/'watcher-get.json').write_bytes(get.stdout);assert get.returncode==0
owner=json.loads(get.stdout)['result']['agent'];assert owner['agent_session']['value']=='01a13dcd-83d4-7c63-b233-f93cf878ecf4' and owner['cwd']==str(r)
sent=subprocess.run(['herdr','agent','prompt','wJ:pJT',message],capture_output=True);(pub/'ops-disposition-transport.stdout').write_bytes(sent.stdout);(pub/'ops-disposition-transport.stderr').write_bytes(sent.stderr)
receipt=dict(at=at,target='wJ:pJT',owner=owner['agent_session']['value'],actor='ops',rc=sent.returncode,message=dict(path=str((pub/'ops-disposition-message.txt').relative_to(r)),sha256=sha(message.encode())),watcher_read=None,Roy_ACK=None,scope='Existing original watcher only, no new session/model task',delivered=False)
if sent.returncode==0:
    response=json.loads(sent.stdout);assert response['result']['type']=='agent_prompted';receipt.update(delivered=True,response=response)
else:
    receipt.update(status='blocked pending original watcher resume',error=sent.stderr.decode());f=r/'ops/codex-ops/pending-deliveries/global-build-g1c-source-disposition.json';f.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
(pub/'ops-disposition-transport.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
archive=pub/'ops-reviewed-originals.tar.gz';assert not archive.exists()
names=['source-candidate.json','source-candidate.patch','reviewed-checks/checks.json','reviewed-checks/environment-repair.json','reviewed-checks/failed-cases-supplement.json','reviewed-checks/vitest.log','reviewed-checks/tsc.log','reviewed-checks/brain-timeout-supplement.log','reviewed-checks/component-usage-supplement.log','ops-snapshot-agreement.json','design-and-validation.md','source-review-interruption.json','source-checks.json','source-checks-cli-rejected.json','vitest-cli-rejected.log','vitest-full.log','gitleaks-source.json']
with tarfile.open(archive,'w:gz') as tar:
    for name in names:tar.add(pub/name,arcname=name)
(pub/'ops-original-archive-manifest.json').write_text(json.dumps(dict(archive=dict(path=str(archive.relative_to(r)),sha256=sha(archive.read_bytes())),files=[dict(path=name,bytes=(pub/name).stat().st_size,sha256=sha((pub/name).read_bytes())) for name in names],full_rc1_preserved=True,first_CLI_rejection_and_interruption_preserved=True),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(transport_rc=sent.returncode,watcher_read='not inferred',source_disposition='accepted supplements, full1 retained',integration='blocked original adb0 host; not attempted again',cadence='not started')),flush=True)

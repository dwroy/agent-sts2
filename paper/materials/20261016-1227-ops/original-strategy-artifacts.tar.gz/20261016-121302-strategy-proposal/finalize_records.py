import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = OUT.parents[2]
BASE = 'f12269c7f9f2018d0e0c94339803dfb7d33138d3'
BATCH = '20261016-121302-strategy-proposal'


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


proposals = json.loads((OUT / 'proposals-before.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True).strip()
reasons = [
    'GX F45 T2→T3与四次SL的clean=19/18/19/18及假inserted已核；尚缺同基ID多副本、真实插牌/洗牌混合时的实体消歧负例和known-draw消费者完整验证。不能仅删除升级标记就认定牌序可继续。',
    'GX F45第2/末试T2→T3只有局部保10血少8伤对照且均败；复活瞬时逐击入伤、此前退出帧和替路线/提前饮药的整战后继未记录，不能校准复活后的资源链或调整药水/SL权重。',
    '普通生存者单弃窄修复bf423c173d3be348a4ad714e1d26516df619ff41已是live祖先；PD9 F49末T10真实32挡/24持伤/23攻仍死。尚缺门槛新增凋萎实体、选择完成余像时点与当前求解器的完整同输入消费回放，不能整包判duplicate。',
    'L2 F17第2试T2护栏保留、第3—6试同处被SL撤回已核；现selection_audit只有候选answer/before_sl/after_sl和pending_dispatch，缺跨抽弃重问稳定父子身份及实饮/自动消耗/SL恢复完整归属。',
    'L2 F17末T6七伤线与结束线的五轮死亡为14/24和11/24，三条整场各1200样本均零赢且侧步未建模；末T8一牌限制实执行，缺相同起点完整替线与后继兑现，不足以新设攻击优先或改变终局排序。',
    'PD9/L2的现场敏捷、余像、凋萎、毒、暂减力与逐击反伤已有观察和部分代码；本批未完成十五账本入口的联合消费者校准，覆甲减层、力量对滚石和换战能力边界仍未隔离，不能从局部匹配推出全部机制实现。',
    'PD9 F48以58血入、10血出且F49仍10血，L2 F14赢战44→24已核；同样本双Boss诊断bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07已在live，但真实次战开场/奖励与联合校准仍unknown，缺到路线、休息消费者的完整资源链验证。',
    'PD9 F49末T7有限全败预测之后抽牌重问实活到T10，L2四次护栏后SL换线与末T8锁牌已核；跨重问原候选完整执行及原线整战反事实缺失，不能把有限全败改成必死或放宽SL边界。',
    'ZTR F17初始324总血和信徒退场后index0从1/62变37/63已核；d1713559f2d237a04b681ec6497ce0c8798ae0f0仅实现当前快照/模型进度。尚缺同型信徒稳定实体身份、精确退场边界及构筑组件实际兑现链。',
    'ZTR F11T3、F17首T10/末T13的三次护栏候选及真实局部端点已核；局部合省10少24不等整轮因果效果，缺跨重问候选归属、原线与替线整战受控后继，不能调整8/24/0规则或整包判duplicate。',
]
evidence = [
    'GXNKW8X1XYJP A10/F45 T2→T3；八局抑制锚点含ZE8F192FKX24 A5/F42 T3→T4，按进阶分账。',
    'GXNKW8X1XYJP A10/F35、38、40、42、44及F45第2/4试T2→T3；同局SL不作独立样本。',
    'PD9AYQVMLQW6 A10/F49第6试T10，s291336—291342、d284707—284711。',
    'L2TSFU62Z57Z A10/F17第2—6试T2/T3，d284918、284967、284971、285020、285024、285073、285077、285126、285130。',
    'L2TSFU62Z57Z A10/F17第6试T6/T8，d285148、285155—285157、s291780—291792。',
    'PD9AYQVMLQW6 A10/F35 T3—T8、F48/F49末T9/T10；L2TSFU62Z57Z A10/F6 T2、F14及F17。历史药水局只核原引用身份，不重做全史校准。',
    'PD9AYQVMLQW6 A10/F48→F49与F17→18、33→34；L2TSFU62Z57Z A10/F13—F17。',
    'PD9AYQVMLQW6 A10/F48 T1、F49末T7→T10；L2TSFU62Z57Z A10/F17 T2/T3/T6/T8。',
    'ZTRGYYMLR8SC A10/F17 T1/T5/T7/T9及末态，s292332、292356—292363、292376、292402。',
    'ZTRGYYMLR8SC A10/F11 T3、F17第1试T10/第6试T13/T14；d285301、285405、285745。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(proposals, reasons)]
save('proposal-results.json', results)

intro = f'''# 静默猎手十项已领取提案核验与处置

批次：{BATCH}。角色silent。基线：{BASE}。来源为原CLI登记的10项提案，目标任务strategy-proposal；没有新增id、没有接管其他批次。授权Roy-2026-10-07-learning只提供实现权限，不提供游戏事实。本批没有research_request或implementation_request，根旧专题批次不匹配，故保持普通队列任务。启动干净，git merge --no-edit main返回Already up to date。

本批派发10局全部由runs.jsonl核为SILENT。为本批两项ZTR提案补提取ZTRGYYMLR8SC的8流；另11个原提案历史引用局仅核runs角色身份，未冒称完成全流分析。实际完整提取范围11局：10个派发锚点与ZTR。ZE8为A5、VN7为A6、2PV为A7，其余实际提取局为A10；不同进阶不混合拟合。

19,523条记录逐行复核原source/offset/bytes/SHA256/JSON及显式身份；每流source_size和计数保存在两份evidence-manifest.json及provenance-verification.json。run-plans按run取身份，其他流含run_id/state.run_id/fingerprint.run；冲突身份不接收。fight-plans在这两次冻结截点选中0行，仅表示该截点没选中，不宣称原日志缺失。19项固定事实材料断言通过，不是生产测试。

十份原Markdown均按队列保存的SHA256核对并保留.original.md。账本29个既有id及当前silent经验23条只作上下文与追溯；不把经验发布当源码实现，不复制其他角色知识。下面各项均waiting，原提案范围不能因窄子项实现而整包关闭。

'''
sections = []
for n, (p, reason, ev) in enumerate(zip(proposals, reasons, evidence), 1):
    sections.append(f'''## {n}. {p['id']}：{p['summary']}

账本：{', '.join(p['ledger'])}。来源任务：{p['source_task']} → strategy-proposal。原文SHA256：{p['proposal_sha256']}。

证据定位：{ev}

处置：waiting。{reason}

旧行为与拟议行为：沿用原文界定；本批保持当前源码与参数。对已证事实仅确认观察与已有接线，尚未确认的机制/跨帧实体/后继结果继续未知，不补成0。原提案的正例不构成完整因果胜线，其反例与缺帧继续保留。

预期行为及验证：收集上述缺口后，以原始固定同盘输入核候选→选择→实际动作→重问→结算，分别报告预测与实测；未知弃牌不预支后继、未结算能力不记实伤，完整候选缺段不得登记已兑现。若新实现需以撤源码失败、恢复通过及固定沙箱入口验收，再按live流程登记实际祖先源码；无完整覆盖继续waiting。

''')
closing = '''## 验证边界、反例与回退

关键反例直接见keyframes.json/keydecisions.json：PD9末T10从8挡经防御18、打击19、生存者选择中31、完成单弃32，余两张12伤凋萎；32挡对24持牌伤+23攻击仍需15HP，真实3血死亡且敌250→244。12伤差不是实际多掉12，更不证明修后必胜。L2末T6打击/侧步7伤线五轮14/24死，结束线11/24死，侧步在unmodelled_cards，整场各1200样本0赢；不能只比较即时伤害。末T8实际16伤后一牌已打，仍余能而四牌blocked_by_hook，17HP/0挡对17攻击死。ZTR可核退场前1HP和退场后序号重排，不能补造零HP帧或稳定实体id。

现有源码只覆盖部分：普通生存者单弃bf423c173d3be348a4ad714e1d26516df619ff41；HP护栏预测f1542578594462e9f9f4e175488795fc480a8a13；当前同族快照d1713559f2d237a04b681ec6497ce0c8798ae0f0；双Boss原始资源诊断bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07；selection_audit整合66283dd9982bdd7f480da7a4d9bfefea0572a9ac及持牌预测后继9d8278702dbc581b5015ba7ec9a70dc0fb94cccb。六个提交均实际base/live祖先，详ancestor-checks.json；这是已有窄覆盖，不是本批实现或宽提案duplicate。12源码叶中10与live字节相同，card-model.ts/draws.ts仅原Roy/Dai注释差。保留完整SHA，不以注释差冒称当前游戏逻辑不同。

本批不拟合伤害权重、用药持有价、护栏、SL或终局参数；旧局是诊断样本，同局SL是一组，后续新角色局方可单列前瞻验证。完整dirty源码/知识输入、复活逐击及未选线整战后继仍未知。当前源码读回不是历史dirty运行树复原，固定材料绿不是生产消费者或胜率验证。

没有源码改动，无撤源码/恢复实验、tsc或vitest；tests均null。不提交、不合入live、不新增eval版本、不登记shipped，不改旧提案/请求/复盘/经验库。铁甲及其他未观察范围保持当前代码。原失败、初稿和日志保留；后续如实现只反向撤独立净补丁，保留知识刷新和并行记录。本批无补丁可回退。

根账本仅经既有ledger.py update追加本提案与报告where/note，保留原status、claim、evidence、首证、prior、version和shipped历史；不重复support/repeat，不新建代码提案。报告/批次完成不关闭学习入库或量化父要求。
'''
(OUT / 'proposal.md').write_text(intro + ''.join(sections) + closing)

report = f'''# 静默猎手策略提案报告

批次{BATCH}；base={BASE}。十项已领取提案已逐项处理，均waiting；缺口详proposal.md与proposal-results.json。没有源码或知识数据修改，fixes=[]、merged=null、版本=null，HEAD与启动基线相同，工作树干净。

## 证据与结论

10派发局和原提案引用ZTR共11个Silent局实际提取8流；另外11个历史引用局仅核runs.jsonl角色，未声称全史复研。共19,523条原记录逐offset/bytes/SHA/JSON/显式身份核验，19项固定材料断言通过。两份manifest保存各流源字节截点、所属局计数与输出SHA；0行fight-plans仅是本截点未选中。逐项局号/层/回合与29个既有账本id见proposal.md，十原Markdown指纹均匹配。

已证局部事实：GX F45四次抑制记录clean=19/18/19/18，战内普通键被记inserted而run.deck保留升级；完整抽序恢复仍缺消歧消费者验证。PD9 F49末T10完成单弃后32挡/24持伤/23攻，3血仍死；不能从单弃旧bug推出本局可胜。L2 F17末T6七伤线14/24死对结束11/24死，三条整场各1200样本零赢且侧步未知；末T8一牌后四牌锁定实死。ZTR F17初始324总HP与信徒退场后index重排已核，不能从当前序号推稳定实例或精确击杀时刻。PD9 F48 58→10且F49仍10、L2 F14赢战44→24，证明赢战也付资源；未选路线、提前用药和少损首王的整战结果没有记录。

## 实现与验证范围

source-readback.json冻结base/live及12源码叶SHA；10叶相同，2叶仅历史Roy/Dai注释差。ancestor-checks.json中的六个窄实现提交均真实base/live祖先，分别覆盖普通单弃、护栏预测、同族当前快照、选择审计及双Boss原始资源诊断。已有实现不等于本批十项原范围全部验收，故未整包登记duplicate/implemented。selection_audit仍为predicted_candidates/pending_dispatch且actual_turn=null；同族模块明确只记录当前帧；continuous-boss-result明确联合校准、S、真实次战开场和奖励unknown。

本批未运行生产测试，tsc/vitest/cases均null；19项是原材料断言，不是产品case数。无源码撤掉失败/恢复通过实验，无提交或合入、eval版本、gitleaks提交扫描和规则变更双通知，因为没有待提交的源码/上线动作。没有把其他批次的测试结果借为本批成功。

仅追加现有账本where/note追溯，原claim/首证/prior/evidence/status/version/shipped与notes/history/where前缀保留；实际CLI回执另存。既有CLI提案id沿用，不重复注册，不把旧经验的shipped当本批实现。report/proposal通过本次完成回报交运维，实际消费者采用、经验入库、校准与宽父要求均未关闭。

## 限制和现场

原dirty整树/知识、复活逐击、跨重问完整候选与未选线受控整战后继缺失；19项材料检查不能证明当前消费者整战收益。现有证据不足以改护栏、药水、SL或终局权重，其他角色代码等价。后续缺数据要求已逐id列明，等待新证据重派。

未派下级agent，未调用游戏、LLM或网络，未读key/.env/游戏二进制、未运行play、未安装依赖、未推送。临时材料只在本批scratch。只读探针曾猜错不存在的control-trace/combat-progress路径并过宽搜索测试目录，未视为产品缺陷；部分短时命令输出句柄未保留，不用其结果作证据。最终证据以保存的原件与核验回执为准。

用户题面要求ordinary/high；沙箱内可见进程链只有codex-linux-sandbox/bash/python，无法独立核原生模型/推理强度，launch-model-summary.json已保存白名单检查。不改配置、不重启任务，不冒称已验证运行模型档位，交宿主运维核实际原生请求。
'''
(OUT / 'report.md').write_text(report)
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
         'runs': dispatch['runs'], 'fixes': [], 'skipped': [p['id'] for p in proposals],
         'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': [p['id'] for p in proposals],
         'implementation_domains': ['combat', 'potion', 'sl', 'terminal', 'structure'],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
save('result.json', final)
updates = []
for ledger_id in sorted({i for p in proposals for i in p['ledger']}):
    related = [r for p, r in zip(proposals, results) if ledger_id in p['ledger']]
    updates.append({'id': ledger_id, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': BATCH + '：仅补提案/报告追溯；' + '；'.join(r['id'] + ' waiting：' + r['reason'] for r in related)
                    + '。本批无源码/合入，不重复support/repeat，不修改原状态或经验结论。'})
(OUT / 'ledger-update.jsonl').write_text(''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates))
print(json.dumps({'proposals': len(results), 'waiting': len(results), 'ledger_links': len(updates), 'report': final['report']}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
path = ROOT / 'paper/materials/learning/ledger.jsonl'
updates = [json.loads(line) for line in (OUT / 'ledger-update.jsonl').read_text().splitlines()]
ids = {u['id'] for u in updates}
assert len(ids) == 29
assert all(set(u) == {'id', 'by', 'where', 'note'} for u in updates)
before = ledger.fold(ledger.read_rows(str(path)))
before = {i: before[i] for i in ids}
assert all(e['character'] == 'silent' for e in before.values())
size = path.stat().st_size
with path.open('rb') as h:
    prefix_sha = hashlib.sha256(h.read(size)).hexdigest()
(OUT / 'ledger-immediate-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
subprocess.run(['date'], check=True)
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                        input=(OUT / 'ledger-update.jsonl').read_bytes(), capture_output=True)
(OUT / 'ledger-cli.stdout').write_bytes(result.stdout)
(OUT / 'ledger-cli.stderr').write_bytes(result.stderr)
(OUT / 'ledger-cli.exit.json').write_text(json.dumps({'returncode': result.returncode}) + '\n')
assert result.returncode == 0
after = ledger.fold(ledger.read_rows(str(path)))
protected = []
for i in sorted(ids):
    old, new = before[i], after[i]
    for k in old:
        if k in ('notes', 'history'):
            assert new[k][:len(old[k])] == old[k]
        elif k == 'where':
            for category, values in old[k].items():
                assert new[k][category][:len(values)] == values
        else:
            assert new[k] == old[k], (i, k)
    assert str(OUT / 'proposal.md') in new['where']['proposal']
    assert str(OUT / 'report.md') in new['where']['proposal']
    protected.append(i)
with path.open('rb') as h:
    assert hashlib.sha256(h.read(size)).hexdigest() == prefix_sha
    offset = size
    own = []
    for raw in h:
        try:
            row = json.loads(raw)
        except ValueError:
            offset += len(raw)
            continue
        if row.get('id') in ids and row.get('note', '').startswith('20261016-121302-strategy-proposal：'):
            own.append({'source': str(path), 'offset': offset, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        offset += len(raw)
assert len(own) == 29
(OUT / 'ledger-appends.json').write_text(json.dumps(own, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-readback.json').write_text(json.dumps({
    'cli_returncode': result.returncode, 'linked_entries': protected, 'appended_rows': len(own),
    'before_size': size, 'before_prefix_sha256': prefix_sha, 'physical_prefix_preserved': True,
    'protected_fields_preserved': True, 'notes_history_where_prefix_preserved': True,
    'claim_evidence_status_version_first_run_prior_unchanged': True,
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_returncode': result.returncode, 'linked_entries': len(protected), 'appended_rows': len(own)}, ensure_ascii=False))

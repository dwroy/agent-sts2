# 静默猎手策略提案报告

批次20261016-121302-strategy-proposal；base=f12269c7f9f2018d0e0c94339803dfb7d33138d3。十项已领取提案已逐项处理，均waiting；缺口详proposal.md与proposal-results.json。没有源码或知识数据修改，fixes=[]、merged=null、版本=null，HEAD与启动基线相同，工作树干净。

## 证据与结论

10派发局和原提案引用ZTR共11个Silent局实际提取8流；另外11个历史引用局仅核runs.jsonl角色，未声称全史复研。共19,523条原记录逐offset/bytes/SHA/JSON/显式身份核验，19项固定材料断言通过。两份manifest保存各流源字节截点、所属局计数与输出SHA；0行fight-plans仅是本截点未选中。逐项局号/层/回合与29个既有账本id见proposal.md，十原Markdown指纹均匹配。

已证局部事实：GX F45四次抑制记录clean=19/18/19/18，战内普通键被记inserted而run.deck保留升级；完整抽序恢复仍缺消歧消费者验证。PD9 F49末T10完成单弃后32挡/24持伤/23攻，3血仍死；不能从单弃旧bug推出本局可胜。L2 F17末T6七伤线14/24死对结束11/24死，三条整场各1200样本零赢且侧步未知；末T8一牌后四牌锁定实死。ZTR F17初始324总HP与信徒退场后index重排已核，不能从当前序号推稳定实例或精确击杀时刻。PD9 F48 58→10且F49仍10、L2 F14赢战44→24，证明赢战也付资源；未选路线、提前用药和少损首王的整战结果没有记录。

## 实现与验证范围

source-readback.json冻结base/live及12源码叶SHA；10叶相同，2叶仅历史Roy/Dai注释差。ancestor-checks.json中的六个窄实现提交均真实base/live祖先，分别覆盖普通单弃、护栏预测、同族当前快照、选择审计及双Boss原始资源诊断。已有实现不等于本批十项原范围全部验收，故未整包登记duplicate/implemented。selection_audit仍为predicted_candidates/pending_dispatch且actual_turn=null；同族模块明确只记录当前帧；continuous-boss-result明确联合校准、S、真实次战开场和奖励unknown。

本批未运行生产测试，tsc/vitest/cases均null；19项是原材料断言，不是产品case数。无源码撤掉失败/恢复通过实验，无提交或合入、eval版本、gitleaks提交扫描和规则变更双通知，因为没有待提交的源码/上线动作。没有把其他批次的测试结果借为本批成功。

仅追加现有账本where/note追溯，原claim/首证/prior/evidence/status/version/shipped与notes/history/where前缀保留；实际CLI回执另存。既有CLI提案id沿用，不重复注册，不把旧经验的shipped当本批实现。report/proposal通过本次完成回报交运维，实际消费者采用、经验入库、校准与宽父要求均未关闭。

## 限制和现场

原dirty整树/知识、复活逐击、跨重问完整候选与未选线受控整战后继缺失；19项材料检查不能证明当前消费者整战收益。现有证据不足以改护栏、药水、SL或终局权重，其他角色代码等价。后续缺数据要求已逐id列明，等待新证据重派。

未派下级agent，未调用游戏、LLM或网络，未读key/.env/游戏二进制、未运行play、未安装依赖、未推送。临时材料只在本批scratch。只读探针曾猜错不存在的control-trace/combat-progress路径并过宽搜索测试目录，未视为产品缺陷；部分短时命令输出句柄未保留，不用其结果作证据。最终证据以保存的原件与核验回执为准。

用户题面要求ordinary/high；沙箱内可见进程链只有codex-linux-sandbox/bash/python，无法独立核原生模型/推理强度，launch-model-summary.json已保存白名单检查。不改配置、不重启任务，不冒称已验证运行模型档位，交宿主运维核实际原生请求。

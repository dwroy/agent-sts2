from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261017-081302'
LIVE = ROOT / '.worktrees/live'
SCRATCH = ROOT / 'learner/runs/20261017-081308-9b5ca07b-0cbe-42a7-8b04-51e29c76de5e-fix-batch'
BASE = 'ac451784ffebed27097bf261bbfaa5ee69c5d4d5'


def git(tree, *args):
    return subprocess.check_output(['git', '-C', str(tree), *args], text=True).strip()


def save(receipt):
    (SCRATCH / 'publication.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)


print(subprocess.check_output(['date'], text=True).strip(), flush=True)
while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
    print('waiting for the existing knowledge builder', flush=True)
    time.sleep(10)
source = git(WORK, 'rev-parse', 'HEAD')
branch = git(WORK, 'branch', '--show-current')
assert not git(WORK, 'status', '--porcelain'), 'source worktree is not clean'
receipt = {'source': source, 'source_branch': branch, 'base': BASE, 'merged': None,
           'initial_live': git(LIVE, 'rev-parse', 'HEAD'), 'dirty_before': git(LIVE, 'status', '--porcelain'),
           'refresh_commit': None}
existing_index = git(LIVE, 'diff', '--cached', '--name-only')
if existing_index:
    receipt.update(state='blocked_existing_index', staged=existing_index.splitlines(), live_after=git(LIVE, 'rev-parse', 'HEAD'))
    save(receipt)
    sys.exit(0)
allowed = ['knowledge']
if git(LIVE, 'ls-files', '--', 'notes/fight-value-backtest.md'):
    allowed.append('notes/fight-value-backtest.md')
refresh_paths = set(git(LIVE, 'diff', '--name-only', '--', *allowed).splitlines())
refresh_paths.update(git(LIVE, 'ls-files', '--others', '--exclude-standard', '--', *allowed).splitlines())
if refresh_paths:
    subprocess.run(['git', '-C', str(LIVE), 'add', '--', *allowed], check=True)
    patch = subprocess.check_output(['git', '-C', str(LIVE), 'diff', '--cached', '--binary'])
    with (SCRATCH / 'live-refresh-gitleaks.log').open('wb') as log:
        scan = subprocess.run(['gitleaks', 'stdin', '--no-banner', '--redact'], input=patch, stdout=log, stderr=subprocess.STDOUT)
    if scan.returncode:
        subprocess.run(['git', '-C', str(LIVE), 'restore', '--staged', '--', *sorted(refresh_paths)], check=True)
        receipt.update(state='blocked_refresh_scan', live_after=git(LIVE, 'rev-parse', 'HEAD'))
        save(receipt)
        sys.exit(0)
    (SCRATCH / 'live-knowledge-refresh.patch').write_bytes(patch)
    print(subprocess.check_output(['date'], text=True).strip(), flush=True)
    subprocess.run(['git', '-C', str(LIVE), 'commit', '-m', 'Refresh knowledge data', '-m',
                    'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'], check=True)
    receipt['refresh_commit'] = git(LIVE, 'rev-parse', 'HEAD')
before = git(LIVE, 'rev-parse', 'HEAD')
changed = set(git(WORK, 'diff', '--name-only', BASE, source).splitlines())
assert changed and all(path.startswith('agent/tests/') for path in changed), 'unexpected non-test source scope'
receipt.update(live_before=before, refresh_paths=sorted(refresh_paths), overlap_with_own_fixes=sorted(changed & refresh_paths))
preview = subprocess.run(['nice', '-n', '19', 'git', '-C', str(WORK), 'merge-tree', '--write-tree', before, source],
                         capture_output=True, text=True)
(SCRATCH / 'final-live-merge-preview.txt').write_text(preview.stdout + preview.stderr)
receipt.update(preview_exit=preview.returncode,
               conflicts=[line for line in preview.stdout.splitlines() if line.startswith('CONFLICT')],
               live_after=git(LIVE, 'rev-parse', 'HEAD'), dirty_after=git(LIVE, 'status', '--porcelain'))
if preview.returncode == 1:
    receipt['state'] = 'conflict'
elif preview.returncode == 0:
    receipt['state'] = 'ready'
else:
    receipt['state'] = 'preview_error'
save(receipt)
if receipt['state'] == 'ready':
    os.execv(sys.executable, [sys.executable, '-B', str(SCRATCH / 'live-publish.py'), '--preflight-complete'])

## 修 bug 回报

- 合并基线：main → ac451784ffebed27097bf261bbfaa5ee69c5d4d5
- 修复：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70 — 测试 `agent/tests/eval_calibration_test.py:FixtureTest.test_cli_does_not_read_the_live_release_table` — 去掉修复时失败：是
- 修复：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d3 — 测试 `agent/tests/potions-jev-call.test.ts:logged potion replays keep real solver inputs and repeatable forecast budgets across host pauses` — 去掉修复时失败：是
- 修复：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66 — 测试 `agent/tests/target-options.test.ts:bounds default EZ2L calls and restores forecast clocks when the real solver fails` — 去掉修复时失败：是
- 修复：infra-test-rollout-ties-host-timeout-15000 — da08fcead2 — 测试 `agent/tests/rollout-ties-fixture.test.ts:the forced tie label fixture never invokes the future-turn simulator` — 去掉修复时失败：是
- 修复：infra-test-build-facts-selection-remove-latency — e2c1d8a2d2 — 测试 `agent/tests/build-facts-audit-fixture.test.ts:the boss fact consumer audits do not invoke the whole-fight sampler` — 去掉修复时失败：是
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb6
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7
- 已被别人修掉的：空产出补链误派 — 84366ad06e
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612b
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a8
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29
- 已被别人修掉的：纸鹤夹具 — befc39e5ca
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e
- 已被别人修掉的：共享main启动冲突 — 22efae5548
- 已被别人修掉的：根事件通知路径 — 577f0bc424
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe
- 已被别人修掉的：局间quiet误报 — 21a9c52484
- 已被别人修掉的：global-health异步测试 — d27df54f06
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径本批另补） — 83a7f796c2
- 已被别人修掉的：retention数字UUID — d91236326b
- 已被别人修掉的：retention旧根scratch — 0699b05c43
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d7
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ce
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a51
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57cea
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8ba
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。
- 没修的：selection-hidden-daggers-conditional-followup-readback（运行期间新增） — 条件后继事实链已有独立strategy-proposal实现提案silent-proposal-59b2e430bb7521d4，按第1.4节沿原策略链；当前pending、未核到派发批次，本批未领取或实现。
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496） — 策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。
- 没修的：silent-0332实际nonpositive-hp资源契约根因 — 证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查 — 独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。
- 没修的：core-build-notify-222802-rc2原生通知恢复 — 旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。
- 没修的：codex缓存实测、DPR性能及历史宿主超时根因 — 证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。
- 测试：本分支 tsc 退出码 0；沙箱 vitest 465 文件 / 4308 用例 / 退出码 0；live 合后 tsc 0 / vitest 470 文件 / 4330 用例 / 退出码 0；Python 校准 22 项通过。重跑过 potions-jev-call/logged boards、target-options/deterministic、passive-pieces/current turn、continuation-failure-b2-planner，同源单 worker 均通过，原完整失败保留。
- 合入：f88c3ccde0fdb5019b117da9d8421e5c04d95518
- 需要 Roy 定的事：无


实际验证与边界：

- 源提交 e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0；tree 7d4451c1ba66e48e97586bd75c3587e9537c6a39；只改 9 个测试/夹具文件，agent/src、knowledge、ops生产代码、运维prompt及eval版本未改。
- 队列输入快照和SHA见 fix-queue-input.md / queue-already-fixed.json；未划改原队列。
- 原通用补丁来源/patch SHA见 reused-patches.json。源对照保留Git提交、逐修复binary diff和必要固定输入，没有展开整仓库副本。
- bug-infra按calibration/eval_calibration、rollout-ties、build-facts-audit、potions-jev-call、infra-target-options关键词经ledger.py查询均无对应条目；没有新建或标shipped。
- 版本表隔离回归撤掉--versions源码参数后失败，恢复Python22项通过；初稿加载次数断言3→1的失败原件保留。
- live校准补验：首次系统Python因缺DuckDB为16过/6跳，保留live-calibration-no-duckdb.log；改用仓库现有data/logdb-venv后22项全部通过、无跳过，见live-calibration.log/exit。未安装依赖或改动测试断言。
- 药水回归仅撤掉有界预测包装、保留固定输入和新增回归时失败；恢复后全部15项通过，64个既有局面与原断言不删。
- EZ2L撤掉默认预算/时钟路由后记录到budget=1e9、step=0并失败；恢复后24项通过。首稿使8样本数值审计降至1样本的失败在fix5-attempt1保留；最终该审计显式保留原先隐式1e9预算，原8样本与30秒断言不变。
- rollout-ties恢复旧源码并保留新模拟器负控时2失败/4通过；恢复后2文件11项通过。
- build-facts恢复旧SerialDeckRunner消费者并保留新负控时5失败/16通过；恢复后2文件41项通过。原四样本、选项、统计依据、无评分断言不变。合成回执不是对原对局胜负或0332根因的证据。
- fix2-attempt1：四worker完整失败2文件/2用例（4272通过）；两原题同源单worker补验2过/35未选。旧log/SHA及早期源码保留，未把补验写成完整通过。
- fix4-sandbox.log：两worker完整失败2文件/2用例（4267通过）；passive-pieces与B2 planner同源单worker补验2过/19未选。随后未改原断言/15秒时限，原完整入口单worker重跑0（463文件/4280用例）。
- 逐提交完整入口统计见 validation-summary.json；全程使用固定输入，不调用真实LLM/网络、不运行play、不推送，不删除原日志/未完成现场。
- 运行期间新增条件后继条目的原CLI/派发核查见queue-end-audit.json：原pending，无匹配派发，不声称已有运行owner；保留其独立strategy-proposal实现链。
- 一次只读工具在bubblewrap构建前遇到scratch临时目录ENOENT，后续同一只读状态查询成功；原件见read-preflight-launch-race.json，不当游戏故障或生命周期已修。
- 原生运行会话按工作树cwd唯一匹配，实际gpt-6.1-sol/xhigh/workspace-write/never；原turn_context偏移/字节/SHA见native-model-readback.json，未改线程、账号、模型prompt或授权范围。
- 开工只读预检曾有20处历史记录冲突；后续live自身同步后最终固定提交预检无冲突。未在本批手动覆盖/调解旧记录。取得锁前的45秒等待失败原件保留，最终锁内知识刷新与五源码提交祖先证明见publication.json/live-source-scope.json。
- 原始live合并预检见 initial-live-merge-preview.txt，最终锁内结果见 publication.json / final-live-merge-preview.txt；没有把本分支测试通过冒称live合入或宿主全套通过。
- 主文件列表：agent/tests/boss-sim-consumer-fixture.ts、agent/tests/build-facts-audit-fixture.test.ts、agent/tests/build-facts-audit.test.ts、agent/tests/eval_calibration_test.py、agent/tests/potions-jev-call.test.ts、agent/tests/rollout-clock-fixture.ts、agent/tests/rollout-ties-fixture.test.ts、agent/tests/rollout-ties.test.ts、agent/tests/target-options.test.ts

```json
{
  "task": "fix-batch",
  "base": "ac451784ffebed27097bf261bbfaa5ee69c5d4d5",
  "fixes": [
    {
      "item": "021302宿主eval校准固定夹具超时（误遍历线上发布表）",
      "commit": "d8748f2e70bfb2a91138ede0e1f6046927c116a4",
      "test": "agent/tests/eval_calibration_test.py",
      "fails_without_fix": true
    },
    {
      "item": "021302宿主potions-jev-call全部局面扫描超时",
      "commit": "c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420",
      "test": "agent/tests/potions-jev-call.test.ts",
      "fails_without_fix": true
    },
    {
      "item": "infra-target-options-fixed-fixture-timeout（默认EZ2L路径）",
      "commit": "c57105ca66bd75c6d6952772dcf712399eda828b",
      "test": "agent/tests/target-options.test.ts",
      "fails_without_fix": true
    },
    {
      "item": "infra-test-rollout-ties-host-timeout-15000",
      "commit": "da08fcead2025c293140f1ba103d8efdbd39a4c3",
      "test": "agent/tests/rollout-ties-fixture.test.ts",
      "fails_without_fix": true
    },
    {
      "item": "infra-test-build-facts-selection-remove-latency",
      "commit": "e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0",
      "test": "agent/tests/build-facts-audit-fixture.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。"
    },
    {
      "item": "selection-hidden-daggers-conditional-followup-readback（运行期间新增）",
      "reason": "条件后继事实链已有独立strategy-proposal实现提案silent-proposal-59b2e430bb7521d4，按第1.4节沿原策略链；当前pending、未核到派发批次，本批未领取或实现。"
    },
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496）",
      "reason": "策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。"
    },
    {
      "item": "silent-0332实际nonpositive-hp资源契约根因",
      "reason": "证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。"
    },
    {
      "item": "arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查",
      "reason": "独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。"
    },
    {
      "item": "core-build-notify-222802-rc2原生通知恢复",
      "reason": "旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。"
    },
    {
      "item": "codex缓存实测、DPR性能及历史宿主超时根因",
      "reason": "证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。"
    }
  ],
  "merged": "f88c3ccde0fdb5019b117da9d8421e5c04d95518",
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4330
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261017-081308-9b5ca07b-0cbe-42a7-8b04-51e29c76de5e-fix-batch/report.md"
}
```

from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261017-081302'
SCRATCH = ROOT / 'learner/runs/20261017-081308-9b5ca07b-0cbe-42a7-8b04-51e29c76de5e-fix-batch'
BASE = 'ac451784ffebed27097bf261bbfaa5ee69c5d4d5'
SPECS = [
 ('fix1', '021302宿主eval校准固定夹具超时（误遍历线上发布表）', 'agent/tests/eval_calibration_test.py', 'FixtureTest.test_cli_does_not_read_the_live_release_table', 'fix1-sandbox.log'),
 ('fix4', '021302宿主potions-jev-call全部局面扫描超时', 'agent/tests/potions-jev-call.test.ts', 'logged potion replays keep real solver inputs and repeatable forecast budgets across host pauses', 'fix4-sandbox-retry1.log'),
 ('fix5', 'infra-target-options-fixed-fixture-timeout（默认EZ2L路径）', 'agent/tests/target-options.test.ts', 'bounds default EZ2L calls and restores forecast clocks when the real solver fails', 'fix5-sandbox.log'),
 ('fix2', 'infra-test-rollout-ties-host-timeout-15000', 'agent/tests/rollout-ties-fixture.test.ts', 'the forced tie label fixture never invokes the future-turn simulator', 'fix2-sandbox.log'),
 ('fix3', 'infra-test-build-facts-selection-remove-latency', 'agent/tests/build-facts-audit-fixture.test.ts', 'the boss fact consumer audits do not invoke the whole-fight sampler', 'fix3-sandbox.log'),
]
SKIPPED = [
 {'item':'sandbox-glob-startup-race目录生命周期与磁盘压力宽项', 'reason':'证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。'},
 {'item':'selection-hidden-daggers-conditional-followup-readback（运行期间新增）', 'reason':'条件后继事实链已有独立strategy-proposal实现提案silent-proposal-59b2e430bb7521d4，按第1.4节沿原策略链；当前pending、未核到派发批次，本批未领取或实现。'},
 {'item':'出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496）', 'reason':'策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。'},
 {'item':'silent-0332实际nonpositive-hp资源契约根因', 'reason':'证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。'},
 {'item':'arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查', 'reason':'独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。'},
 {'item':'core-build-notify-222802-rc2原生通知恢复', 'reason':'旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。'},
 {'item':'codex缓存实测、DPR性能及历史宿主超时根因', 'reason':'证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。'},
]


def git(*args):
    return subprocess.check_output(['git','-C',str(WORK),*args],text=True).strip()


def stats(name):
    raw=(SCRATCH/name).read_text()
    result={label:{key:0 for key in ('passed','failed','skipped')} for label in ('files','cases')}
    for label,key in [('Test Files','files'),('Tests','cases')]:
        for body in re.findall(r'^\s*'+label+r'\s+([^\n]+)',raw,re.M):
            for count,status in re.findall(r'(\d+) (passed|failed|skipped)',body):
                result[key][status]+=int(count)
    return result


assert not git('status','--porcelain'), 'source tree is dirty'
publication=json.loads((SCRATCH/'publication.json').read_text())
assert publication['state'] in ('conflict','blocked_existing_index','blocked_refresh_scan','preview_error','merged','rolled_back','merge_failed','blocked_lock'), 'publication still pending'
assert (SCRATCH/'fix3-sandbox.exit').read_text().strip()=='0'
head=git('rev-parse','HEAD')
assert publication['source']==head
fixes=[]
main=['## 修 bug 回报','',f'- 合并基线：main → {BASE}']
validation=[]
for prefix,item,test,case,log in SPECS:
    commit=(SCRATCH/f'{prefix}-commit.txt').read_text().strip()
    subprocess.run(['git','-C',str(WORK),'merge-base','--is-ancestor',commit,head],check=True)
    summary=stats(log)
    assert summary['files']['passed'] and not summary['files']['failed'] and not summary['cases']['failed']
    fixes.append(dict(item=item,commit=commit,test=test,fails_without_fix=True))
    main.append(f'- 修复：{item} — {commit[:10]} — 测试 `{test}:{case}` — 去掉修复时失败：是')
    validation.append(dict(item=item,commit=commit,log=log,tsc=0,vitest=0,**summary))
already=json.loads((SCRATCH/'queue-already-fixed.json').read_text())
for row in already['items']:
    assert row['source_ancestor']
    label=row['item']
    if label=='target-options固定预算': label='target-options此前两个标注回放的固定预算（默认路径本批另补）'
    if label=='核心通知失败日志': label='核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复）'
    main.append(f"- 已被别人修掉的：{label} — {row['commit'][:10]}")
for row in SKIPPED:
    main.append(f"- 没修的：{row['item']} — {row['reason']}")
last=validation[-1]
live_check=(f"；live 合后 tsc 0 / vitest {publication['live_files']} 文件 / {publication['live_cases']} 用例 / 退出码 0" if publication.get("merged") else (f"；live 合后检查退出码 {publication['live_tests_exit']}，已回退" if publication.get("state")=="rolled_back" else ""))
main.append(f"- 测试：本分支 tsc 退出码 0；沙箱 vitest {last['files']['passed']} 文件 / {last['cases']['passed']} 用例 / 退出码 0{live_check}；Python 校准 22 项通过。重跑过 potions-jev-call/logged boards、target-options/deterministic、passive-pieces/current turn、continuation-failure-b2-planner，同源单 worker 均通过，原完整失败保留。")
merged=publication.get('merged')
if merged:
    merge_text=merged
elif publication['state']=='rolled_back':
    merge_text=f"未合入（合后检查退出码 {publication['live_tests_exit']}，已回退至 {publication['live_after']}，保留知识刷新和并行记录）"
elif publication['state']=='conflict':
    merge_text=f"未合入（live {publication['live_before'][:10]}；持锁预检 {len(publication['conflicts'])} 处冲突，涉及 notes/fix-queue-v4.md、paper/materials/decision-log.md、学习账本等；按第5节停止，保留并行记录）"
else:
    merge_text=f"未合入（{publication['state']}，见 publication.json）"
main.append('- 合入：'+merge_text)
main.append('- 需要 Roy 定的事：无')
payload=dict(task='fix-batch',base=BASE,fixes=fixes,skipped=SKIPPED,merged=merged,
             tests=dict(tsc=0,vitest=0,cases=publication.get('live_cases',last['cases']['passed'])),code_proposals=[],implementation_domains=[],
             report=str(SCRATCH/'report.md'))
block='```json\n'+json.dumps(payload,ensure_ascii=False,indent=2)+'\n```\n'
main_text='\n'.join(main)+'\n'
paths=git('diff','--name-only',BASE,head).splitlines()
assert paths and all(path.startswith('agent/tests/') for path in paths)
details=['','实际验证与边界：','',f'- 源提交 {head}；tree {git("rev-parse","HEAD^{tree}")}；只改 {len(paths)} 个测试/夹具文件，agent/src、knowledge、ops生产代码、运维prompt及eval版本未改。',
 '- 队列输入快照和SHA见 fix-queue-input.md / queue-already-fixed.json；未划改原队列。',
 '- 原通用补丁来源/patch SHA见 reused-patches.json。源对照保留Git提交、逐修复binary diff和必要固定输入，没有展开整仓库副本。',
 '- bug-infra按calibration/eval_calibration、rollout-ties、build-facts-audit、potions-jev-call、infra-target-options关键词经ledger.py查询均无对应条目；没有新建或标shipped。',
 '- 版本表隔离回归撤掉--versions源码参数后失败，恢复Python22项通过；初稿加载次数断言3→1的失败原件保留。',
 '- live校准补验：首次系统Python因缺DuckDB为16过/6跳，保留live-calibration-no-duckdb.log；改用仓库现有data/logdb-venv后22项全部通过、无跳过，见live-calibration.log/exit。未安装依赖或改动测试断言。',
 '- 药水回归仅撤掉有界预测包装、保留固定输入和新增回归时失败；恢复后全部15项通过，64个既有局面与原断言不删。',
 '- EZ2L撤掉默认预算/时钟路由后记录到budget=1e9、step=0并失败；恢复后24项通过。首稿使8样本数值审计降至1样本的失败在fix5-attempt1保留；最终该审计显式保留原先隐式1e9预算，原8样本与30秒断言不变。',
 '- rollout-ties恢复旧源码并保留新模拟器负控时2失败/4通过；恢复后2文件11项通过。',
 '- build-facts恢复旧SerialDeckRunner消费者并保留新负控时5失败/16通过；恢复后2文件41项通过。原四样本、选项、统计依据、无评分断言不变。合成回执不是对原对局胜负或0332根因的证据。',
 '- fix2-attempt1：四worker完整失败2文件/2用例（4272通过）；两原题同源单worker补验2过/35未选。旧log/SHA及早期源码保留，未把补验写成完整通过。',
 '- fix4-sandbox.log：两worker完整失败2文件/2用例（4267通过）；passive-pieces与B2 planner同源单worker补验2过/19未选。随后未改原断言/15秒时限，原完整入口单worker重跑0（463文件/4280用例）。',
 '- 逐提交完整入口统计见 validation-summary.json；全程使用固定输入，不调用真实LLM/网络、不运行play、不推送，不删除原日志/未完成现场。',
 '- 运行期间新增条件后继条目的原CLI/派发核查见queue-end-audit.json：原pending，无匹配派发，不声称已有运行owner；保留其独立strategy-proposal实现链。',
 '- 一次只读工具在bubblewrap构建前遇到scratch临时目录ENOENT，后续同一只读状态查询成功；原件见read-preflight-launch-race.json，不当游戏故障或生命周期已修。',
 '- 原生运行会话按工作树cwd唯一匹配，实际gpt-6.1-sol/xhigh/workspace-write/never；原turn_context偏移/字节/SHA见native-model-readback.json，未改线程、账号、模型prompt或授权范围。',
 '- 开工只读预检曾有20处历史记录冲突；后续live自身同步后最终固定提交预检无冲突。未在本批手动覆盖/调解旧记录。取得锁前的45秒等待失败原件保留，最终锁内知识刷新与五源码提交祖先证明见publication.json/live-source-scope.json。',
 '- 原始live合并预检见 initial-live-merge-preview.txt，最终锁内结果见 publication.json / final-live-merge-preview.txt；没有把本分支测试通过冒称live合入或宿主全套通过。',
 '- 主文件列表：'+'、'.join(paths),
 '']
(SCRATCH/'validation-summary.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
(SCRATCH/'completion.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(SCRATCH/'final-response.md').write_text(main_text+'\n'+block)
(SCRATCH/'report.md').write_text(main_text+'\n'+'\n'.join(details)+'\n'+block)
print(json.dumps({'source':head,'files':last['files'],'cases':last['cases'],'merged':merged,'report':payload['report']},ensure_ascii=False))

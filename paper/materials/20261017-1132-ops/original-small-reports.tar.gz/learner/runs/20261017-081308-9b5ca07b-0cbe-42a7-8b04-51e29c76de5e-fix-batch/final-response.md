## 修 bug 回报

- 合并基线：main → ac451784ffebed27097bf261bbfaa5ee69c5d4d5
- 修复：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70 — 测试 `agent/tests/eval_calibration_test.py:FixtureTest.test_cli_does_not_read_the_live_release_table` — 去掉修复时失败：是
- 修复：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d3 — 测试 `agent/tests/potions-jev-call.test.ts:logged potion replays keep real solver inputs and repeatable forecast budgets across host pauses` — 去掉修复时失败：是
- 修复：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66 — 测试 `agent/tests/target-options.test.ts:bounds default EZ2L calls and restores forecast clocks when the real solver fails` — 去掉修复时失败：是
- 修复：infra-test-rollout-ties-host-timeout-15000 — da08fcead2 — 测试 `agent/tests/rollout-ties-fixture.test.ts:the forced tie label fixture never invokes the future-turn simulator` — 去掉修复时失败：是
- 修复：infra-test-build-facts-selection-remove-latency — e2c1d8a2d2 — 测试 `agent/tests/build-facts-audit-fixture.test.ts:the boss fact consumer audits do not invoke the whole-fight sampler` — 去掉修复时失败：是
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb6
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7
- 已被别人修掉的：空产出补链误派 — 84366ad06e
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612b
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a8
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29
- 已被别人修掉的：纸鹤夹具 — befc39e5ca
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e
- 已被别人修掉的：共享main启动冲突 — 22efae5548
- 已被别人修掉的：根事件通知路径 — 577f0bc424
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe
- 已被别人修掉的：局间quiet误报 — 21a9c52484
- 已被别人修掉的：global-health异步测试 — d27df54f06
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径本批另补） — 83a7f796c2
- 已被别人修掉的：retention数字UUID — d91236326b
- 已被别人修掉的：retention旧根scratch — 0699b05c43
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d7
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ce
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a51
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57cea
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8ba
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。
- 没修的：selection-hidden-daggers-conditional-followup-readback（运行期间新增） — 条件后继事实链已有独立strategy-proposal实现提案silent-proposal-59b2e430bb7521d4，按第1.4节沿原策略链；当前pending、未核到派发批次，本批未领取或实现。
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496） — 策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。
- 没修的：silent-0332实际nonpositive-hp资源契约根因 — 证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查 — 独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。
- 没修的：core-build-notify-222802-rc2原生通知恢复 — 旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。
- 没修的：codex缓存实测、DPR性能及历史宿主超时根因 — 证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。
- 测试：本分支 tsc 退出码 0；沙箱 vitest 465 文件 / 4308 用例 / 退出码 0；live 合后 tsc 0 / vitest 470 文件 / 4330 用例 / 退出码 0；Python 校准 22 项通过。重跑过 potions-jev-call/logged boards、target-options/deterministic、passive-pieces/current turn、continuation-failure-b2-planner，同源单 worker 均通过，原完整失败保留。
- 合入：f88c3ccde0fdb5019b117da9d8421e5c04d95518
- 需要 Roy 定的事：无

```json
{
  "task": "fix-batch",
  "base": "ac451784ffebed27097bf261bbfaa5ee69c5d4d5",
  "fixes": [
    {
      "item": "021302宿主eval校准固定夹具超时（误遍历线上发布表）",
      "commit": "d8748f2e70bfb2a91138ede0e1f6046927c116a4",
      "test": "agent/tests/eval_calibration_test.py",
      "fails_without_fix": true
    },
    {
      "item": "021302宿主potions-jev-call全部局面扫描超时",
      "commit": "c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420",
      "test": "agent/tests/potions-jev-call.test.ts",
      "fails_without_fix": true
    },
    {
      "item": "infra-target-options-fixed-fixture-timeout（默认EZ2L路径）",
      "commit": "c57105ca66bd75c6d6952772dcf712399eda828b",
      "test": "agent/tests/target-options.test.ts",
      "fails_without_fix": true
    },
    {
      "item": "infra-test-rollout-ties-host-timeout-15000",
      "commit": "da08fcead2025c293140f1ba103d8efdbd39a4c3",
      "test": "agent/tests/rollout-ties-fixture.test.ts",
      "fails_without_fix": true
    },
    {
      "item": "infra-test-build-facts-selection-remove-latency",
      "commit": "e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0",
      "test": "agent/tests/build-facts-audit-fixture.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。"
    },
    {
      "item": "selection-hidden-daggers-conditional-followup-readback（运行期间新增）",
      "reason": "条件后继事实链已有独立strategy-proposal实现提案silent-proposal-59b2e430bb7521d4，按第1.4节沿原策略链；当前pending、未核到派发批次，本批未领取或实现。"
    },
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496）",
      "reason": "策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。"
    },
    {
      "item": "silent-0332实际nonpositive-hp资源契约根因",
      "reason": "证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。"
    },
    {
      "item": "arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查",
      "reason": "独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。"
    },
    {
      "item": "core-build-notify-222802-rc2原生通知恢复",
      "reason": "旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。"
    },
    {
      "item": "codex缓存实测、DPR性能及历史宿主超时根因",
      "reason": "证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。"
    }
  ],
  "merged": "f88c3ccde0fdb5019b117da9d8421e5c04d95518",
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4330
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261017-081308-9b5ca07b-0cbe-42a7-8b04-51e29c76de5e-fix-batch/report.md"
}
```

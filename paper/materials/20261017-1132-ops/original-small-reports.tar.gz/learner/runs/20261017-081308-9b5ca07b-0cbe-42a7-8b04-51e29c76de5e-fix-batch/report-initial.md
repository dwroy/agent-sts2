# 修复核查底稿（尚未完成）

基线：ac451784ffebed27097bf261bbfaa5ee69c5d4d5。工作区开工干净，git merge --no-edit main 已完成（Already up to date）。

范围：校准测试固定版本表；rollout 并列标签消费者夹具；构筑事实消费者固定四样本回执；全部既有药水局面夹具的固定数据和有界工作时钟。后三项复用的通用纯测试源及精确 patch SHA 见 reused-patches.json，不带入其他角色的策略或知识。

校准 CLI 旧夹具扫描399个实际发布，现固定为2个历史发布；新增“拒绝读取线上版本表”回归在撤源码后明确失败，恢复后Python22项通过。初稿曾把加载次数断言写为3，核实真实分支只加载1次后更正；初次失败原件 eval-calibration-fixed-targeted.log 保留。fix1-sandbox.log 是当前首轮完整沙箱检查，运行中不记通过。

合入预检：initial-live-merge-preview.txt 已保存真实live/base及20处冲突，尚未修改live。冲突涉及账本/提案队列、并行通知/复盘及论文表；依任务要求不覆盖或手解这些记录。最终提交后仍需持原锁核最新live和知识刷新，若同类冲突保持则回报未合入。

纯工具对应账本按CLI关键词查找，eval_calibration、calibration、rollout-ties、build-facts-audit、potions-jev-call均未命中，没有新建或改shipped。

已核源祖先的历史纯工具修复：

- 额度恢复基线与实际进阶通知：5b56a452bb9be14d620b368ec46974c1b57901ca，当前基线祖先=True。
- 核心通知失败日志：5c92f2aaf0b758a1a5e7d591745694004664f83a，当前基线祖先=True。
- 知识工作线程签名固定输入：8fbb441eb61eef226eb7366f9612003480c83988，当前基线祖先=True。
- rollout最佳候选固定输入：bbc5b993a7524bbb8e80a975f204f8d193657b46，当前基线祖先=True。
- 空产出补链误派：84366ad06ee4f978394c1b9489a82c83ea12bd36，当前基线祖先=True。
- 多角色药水表测试隔离：5ef3c4612bd2673c19968c5a2d24bf62af519ee1，当前基线祖先=True。
- 未派发提案结果登记：3a98e213a826e94f9708af4b1a265e1892659f4e，当前基线祖先=True。
- 事件流同秒碰撞：b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f，当前基线祖先=True。
- 纸鹤夹具：befc39e5ca0105f8ff96d47f817df44f0b2760f1，当前基线祖先=True。
- 账本状态分叉前缀：dd478f0b3e5a0f234f082972d21b203dbf8229d7，当前基线祖先=True。
- 共享main启动冲突：22efae55484bc2bdcc54e847a8dc40bb4888c4e2，当前基线祖先=True。
- 根事件通知路径：577f0bc424b7287910735cfdc86c253cc7ee8057，当前基线祖先=True。
- global-build宿主loadavg：5bc8f025fe043cb8738cce57870354fa23fa84a1，当前基线祖先=True。
- 局间quiet误报：21a9c52484f04d510bd397959c958ec9767f1d2d，当前基线祖先=True。
- global-health异步测试：d27df54f0651c4af84c6c12ceceec82a016f1142，当前基线祖先=True。
- target-options固定预算：83a7f796c24eea8f16eb317bc70bfd832251ad27，当前基线祖先=True。
- retention数字UUID：d91236326bc1af7a5417ce016c1a182f8084e7a3，当前基线祖先=True。
- retention旧根scratch：0699b05c436d3d51d00ee92f153d16d16e64bea4，当前基线祖先=True。
- 无COMBAT决策死亡漏记：3b48088dec5fc6eafe576a1296bbdadde43432ee，当前基线祖先=True。
- broker请求写失败立即退出：eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b，当前基线祖先=True。
- broker回执保留与队列错误隔离：6eb38508ceeb81d534159b3516458521ad09bbed，当前基线祖先=True。
- JSONL残尾边界恢复：3daf122a5168d1a8cb456aed1c926b2d1b6c4488，当前基线祖先=True。
- 宿主定向续验入口：24c2e3a75b5db6bac76d6c924f86b7fcd9438316，当前基线祖先=True。
- 会话启动租约保存屏障：798af209b9a268b7dafab1440150f1b39cd5595d，当前基线祖先=True。

仍不由普通批次实现：游戏机制/出牌/药水/SL/终局与路线条目沿原strategy-proposal链；独立架构、漏斗/公平性/性能归因继续各原任务。silent-0332根因资源证据不足，保持原owner；不降正HP或样本门槛。core-build-notify原失败回执只有rc2、没有stderr，当前CLI参数合法；保留原失败，不重发原生通知。没有新增游戏结论或代码提案。

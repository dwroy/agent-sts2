from pathlib import Path
import json
import os
import re
import runpy
import subprocess
import sys

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261017-081302'
LIVE = ROOT / '.worktrees/live'
SCRATCH = ROOT / 'learner/runs/20261017-081308-9b5ca07b-0cbe-42a7-8b04-51e29c76de5e-fix-batch'


def git(tree, *args):
    return subprocess.check_output(['git', '-C', str(tree), *args], text=True).strip()


def save(receipt):
    (SCRATCH / 'publication.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)


# The caller holds live-merge.lock throughout refresh, merge, checks and the dated record.
if '--preflight-complete' not in sys.argv:
    runpy.run_path(str(SCRATCH / 'live-preflight.py'), run_name='__main__')
receipt = json.loads((SCRATCH / 'publication.json').read_text())
receipt['lock_acquired'] = True
if receipt['state'] != 'ready':
    save(receipt)
    sys.exit(0)
before = receipt['live_before']
source = receipt['source']
assert git(WORK, 'rev-parse', 'HEAD') == source
assert git(LIVE, 'rev-parse', 'HEAD') == before
assert not git(LIVE, 'diff', '--cached', '--name-only')
dirty_paths = git(LIVE, 'diff', '--name-only').splitlines()
assert all(not path.endswith('.env') and Path(path).name != '.env' for path in dirty_paths)
dirty_patch = subprocess.check_output(['git', '-C', str(LIVE), 'diff', '--binary'])
(SCRATCH / 'live-preserved-dirty.patch').write_bytes(dirty_patch)
with (SCRATCH / 'live-merge.log').open('wb') as log:
    merged = subprocess.run(['git', '-C', str(LIVE), 'merge', '--no-edit', receipt['source_branch']], stdout=log, stderr=subprocess.STDOUT)
receipt['merge_exit'] = merged.returncode
if merged.returncode:
    merge_head = subprocess.run(['git', '-C', str(LIVE), 'rev-parse', '--verify', '-q', 'MERGE_HEAD'], capture_output=True)
    if merge_head.returncode == 0:
        subprocess.run(['git', '-C', str(LIVE), 'merge', '--abort'], check=True)
    receipt.update(state='merge_failed', live_after=git(LIVE, 'rev-parse', 'HEAD'))
    save(receipt)
    sys.exit(0)
receipt.update(state='merged_pending_checks', live_merge=git(LIVE, 'rev-parse', 'HEAD'))
save(receipt)
test_env = dict(os.environ, SANDBOX_WORKERS='1', PYTHONDONTWRITEBYTECODE='1', npm_config_offline='true')
with (SCRATCH / 'live-sandbox.log').open('wb') as log:
    checked = subprocess.run(['bash', 'tools/test-sandbox.sh', '--reporter=default'], cwd=LIVE / 'agent', env=test_env, stdout=log, stderr=subprocess.STDOUT)
(SCRATCH / 'live-sandbox.exit').write_text(str(checked.returncode) + '\n')
receipt['live_tests_exit'] = checked.returncode
if checked.returncode:
    # reset --merge preserves the unrelated dirty notes captured before the merge.
    subprocess.run(['git', '-C', str(LIVE), 'reset', '--merge', before], check=True)
    receipt.update(state='rolled_back', merged=None, live_after=git(LIVE, 'rev-parse', 'HEAD'), dirty_after=git(LIVE, 'status', '--porcelain'))
    save(receipt)
    sys.exit(0)
log = (SCRATCH / 'live-sandbox.log').read_text()
files = sum(int(n) for n in re.findall(r'^\s*Test Files\s+(\d+) passed', log, re.M))
cases = sum(int(n) for n in re.findall(r'^\s*Tests\s+(\d+) passed', log, re.M))
assert files > 0 and cases > 0
receipt['dirty_data_changed_during_checks'] = subprocess.check_output(['git', '-C', str(LIVE), 'diff', '--binary']) != dirty_patch
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp, flush=True)
commits = [(SCRATCH / f'{prefix}-commit.txt').read_text().strip() for prefix in ['fix1', 'fix4', 'fix5', 'fix2', 'fix3']]
line = (f'\n- {stamp} Codex离线fix-batch五项纯测试修复合入live {receipt["live_merge"]}：'
        '021302校准固定版本表、potions-jev-call固定输入/工作时钟、target-options默认EZ2L预算、'
        'rollout-ties标签消费者及build-facts-audit消费者夹具；'
        f'来源提交 {" / ".join(commits)}。证据：021302/tree67da9b35宿主超时、G8YYU94P2SBB F30T3、'
        'EZ2LP1P5VRPT F48T2、QUG1DSDARAXU F22选牌（回合不适用）；无对应bug-infra账本条目。'
        f'合后tsc0/vitest {files}文件{cases}用例0；知识刷新已先保存，保留并行记录及刷新。'
        '只改测试/夹具，无生产打法或知识前缀变化，不新增行为发布号，不冒称宿主完整或自然消费者通过。\n')
with (LIVE / 'paper/materials/decision-log.md').open('a') as record:
    record.write(line)
subprocess.run(['git', '-C', str(LIVE), 'add', '--', 'paper/materials/decision-log.md'], check=True)
patch = subprocess.check_output(['git', '-C', str(LIVE), 'diff', '--cached', '--binary'])
with (SCRATCH / 'live-record-gitleaks.log').open('wb') as output:
    scanned = subprocess.run(['gitleaks', 'stdin', '--no-banner', '--redact'], input=patch, stdout=output, stderr=subprocess.STDOUT)
assert scanned.returncode == 0
subprocess.run(['git', '-C', str(LIVE), 'commit', '-m', 'Record fixed fixture batch integration', '-m',
                'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'], check=True)
receipt.update(state='merged', merged=git(LIVE, 'rev-parse', 'HEAD'), live_after=git(LIVE, 'rev-parse', 'HEAD'),
               dirty_after=git(LIVE, 'status', '--porcelain'), live_tsc=0, live_vitest=0, live_files=files, live_cases=cases)
for commit in commits:
    subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', commit, receipt['merged']], check=True)
save(receipt)

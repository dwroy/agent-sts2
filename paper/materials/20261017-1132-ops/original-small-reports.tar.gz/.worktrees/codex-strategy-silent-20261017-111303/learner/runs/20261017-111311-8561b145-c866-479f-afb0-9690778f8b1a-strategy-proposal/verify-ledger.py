import hashlib
import copy
import importlib.util
import json
from pathlib import Path

root = Path('/home/dw/Projects/agent-sts2')
s = Path(__file__).resolve().parent
p = root / 'paper/materials/learning/ledger.jsonl'
prefix = json.loads((s / 'ledger-prefix-before-cli.json').read_text())
before = json.loads((s / 'ledger-protected-before-cli.json').read_text())
raw = p.read_bytes()
old = raw[:prefix['bytes']]
assert hashlib.sha256(old).hexdigest() == prefix['sha256']
assert old.endswith(b'\n')
rows = []
offset = len(old)
for number, line in enumerate(raw[offset:].splitlines(keepends=True), old.count(b'\n') + 1):
    assert line.endswith(b'\n'), '并行追加尚未结束，不能读半行'
    row = json.loads(line)
    if row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith('20261017-111303-strategy-proposal：'):
        assert row['op'] == 'update' and set(row) == {'op', 'id', 'ts', 'by', 'where', 'note'}
        assert row['id'] in before
        rows.append({'line': number, 'offset': offset, 'bytes': len(line),
                     'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert len(rows) == 26 and {r['row']['id'] for r in rows} == set(before)
assert set((s / 'ledger-cli.stdout').read_text().split()) == set(before)
assert (s / 'ledger-cli.stderr').read_text() == ''
sp = importlib.util.spec_from_file_location('ledger', root / 'learner/ledger.py')
m = importlib.util.module_from_spec(sp)
sp.loader.exec_module(m)
prefix_rows = [(number, json.loads(line)) for number, line in enumerate(old.splitlines(), 1) if line.strip()]
replayed = m.fold(prefix_rows)
concurrent = []
own_verified = 0
for number, line in enumerate(raw[len(old):].splitlines(keepends=True), old.count(b'\n') + 1):
    row = json.loads(line)
    ident = row.get('id')
    own = row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith('20261017-111303-strategy-proposal：')
    if ident in before:
        protected = {k: copy.deepcopy(replayed[ident].get(k)) for k in before[ident]}
        m.apply(replayed, row)
        changed_here = [k for k, value in protected.items() if replayed[ident].get(k) != value]
        if own:
            assert not changed_here, [ident, changed_here]
            own_verified += 1
        else:
            concurrent.append({'line': number, 'id': ident, 'by': row.get('by'),
                               'changed_protected_fields': changed_here,
                               'sha256': hashlib.sha256(line).hexdigest()})
assert own_verified == 26
changed = [[i, k] for i, fields in before.items() for k, val in fields.items() if replayed[i].get(k) != val]
receipt = {'prefix': prefix, 'prefix_unchanged': True, 'cli_reported_ids': 26,
           'physical_rows': 26, 'protected_fields_unchanged_by_own_rows': True, 'no_new_evidence_or_status_by_own_rows': True,
           'parallel_protected_changes_at_read_cut': changed, 'parallel_updates': concurrent,
           'historical_empty_physical_lines': sum(not line.strip() for line in old.splitlines()), 'rows': rows}
(s / 'ledger-append-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'rows'}, ensure_ascii=False))

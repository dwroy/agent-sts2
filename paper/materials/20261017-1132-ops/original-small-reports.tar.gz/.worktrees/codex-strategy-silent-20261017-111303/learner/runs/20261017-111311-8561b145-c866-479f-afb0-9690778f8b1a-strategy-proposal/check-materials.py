import gzip
import json
from pathlib import Path

s = Path(__file__).resolve().parent
states = {r['ref']['line']: r for r in json.loads((s / 'selected-state-facts.json').read_text())}
decisions = {r['ref']['line']: r for r in json.loads((s / 'selected-decision-facts.json').read_text())}
checks = []

def check(name, actual, expected, lines):
    ok = actual == expected
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'ok': ok,
                   'refs': [states[n]['ref'] if n in states else decisions[n]['ref'] for n in lines]})
    assert ok, (name, actual, expected)

def card(line, ident):
    return next(c for c in states[line]['hand'] if c['card_id'] == ident)

def value(line, ident, key):
    return next(v['current_value'] for v in card(line, ident)['dynamic_values'] if v['name'] == key)

def power(line, ident, enemy=None):
    row = states[line]
    powers = row['powers'] if enemy is None else next(e['powers'] for e in row['enemies'] if e['enemy_id'] == enemy)
    return next((p['amount'] for p in powers if p['power_id'] == ident), 0)

def enemy_hp(line, ident):
    return next(e['current_hp'] for e in states[line]['enemies'] if e['enemy_id'] == ident)

def consumer(run, kind='full'):
    return json.loads(gzip.decompress((s / (run + '.consumer-' + kind + '.output.json.gz')).read_bytes()))

def window(result, floor, turn, attempt):
    return next(w for w in result['observed_turns'] if (w['floor'], w['turn'], w['attempt']) == (floor, turn, attempt))

check('VLZ F35 神化前后能量', [states[n]['energy'] for n in [275564, 275565]], [7, 5], [275564, 275565])
check('VLZ F35 防御升级牌面', [value(n, 'DEFEND_SILENT', 'Block') for n in [275564, 275565]], [5, 8], [275564, 275565])
check('VLZ F35 打击升级牌面', [value(n, 'STRIKE_SILENT', 'Damage') for n in [275564, 275565]], [7, 10], [275564, 275565])
check('VLZ F35 匕首雨逐击牌面', [value(n, 'DAGGER_SPRAY', 'Damage') for n in [275564, 275565]], [5, 7], [275564, 275565])
check('VLZ F35 必备工具费用', [card(n, 'TOOLS_OF_THE_TRADE')['energy_cost'] for n in [275564, 275565]], [1, 0], [275564, 275565])
check('VLZ F43 突然一拳伤害', [value(n, 'SUCKER_PUNCH', 'Damage') for n in [275679, 275680]], [9, 11], [275679, 275680])
check('VLZ F43 突然一拳虚弱', [value(n, 'SUCKER_PUNCH', 'WeakPower') for n in [275679, 275680]], [1, 2], [275679, 275680])
check('VLZ F43 勒紧升级', [value(n, 'FASTEN', 'ExtraBlock') for n in [275679, 275680]], [4, 6], [275679, 275680])
check('VLZ F43 尖啸升级', [value(n, 'PIERCING_WAIL', 'StrengthLoss') for n in [275679, 275680]], [6, 8], [275679, 275680])
check('VLZ F43 场外升级数保持4', [states[n]['deck_upgraded'] for n in [275679, 275680, 275687]], [4, 4, 4], [275679, 275680, 275687])
check('VLZ F43 T1 敌净扣及玩家净损', [enemy_hp(275679, 'SOUL_NEXUS') - enemy_hp(275687, 'SOUL_NEXUS'), states[275679]['hp'] - states[275687]['hp']], [51, 13], [275679, 275687])
check('VLZ F43 T2 毒雾后续抽牌升级', [card(275687, 'NOXIOUS_FUMES')['upgraded'], value(275687, 'NOXIOUS_FUMES', 'PoisonPerTurn')], [True, 3], [275687])
check('VLZ F45 痊愈药水端点能量与手牌', [states[275730]['energy'] - states[275728]['energy'], len(states[275730]['hand']) - len(states[275728]['hand']), states[275730]['hp'] - states[275728]['hp']], [1, 2, 0], [275728, 275730])
check('VLZ F45 T1 退化推演', [decisions[269748]['rollout']['horizon'], decisions[269748]['rollout']['samples'], decisions[269748]['rollout']['best']], [1, 1, None], [269748])
potion = json.loads(decisions[269748]['questions']['plan']['criteria']['p0'])
check('VLZ F45 MC单样本和707ms原说明', ['1 sample (cut from 12' in potion['simulated'], '707 ms' in potion['rollout']], [True, True], [269748])
check('VLZ F45 T5 玩家HP与已挡', [states[275754]['hp'], states[275754]['block']], [32, 20], [275754])
check('VLZ F45 T5 末态三敌仍活', sorted(e['current_hp'] for e in states[275755]['enemies']), [21, 77, 80], [275755])
check('8JRE 首第三试T2同观测指纹', decisions[270216]['fingerprint'] == decisions[270282]['fingerprint'], True, [270216, 270282])
sl = decisions[270282]['sl_explore']['numbers']
check('8JRE 原SL死亡分母不可并列', ['dead 0/24' in sl['original'], 'dead 5/24' in sl['replacement']], [True, True], [270282])
eight = consumer('8JRE1C4H4Z2W')
a, b = [window(eight, 33, 2, attempt)['facts'] for attempt in [1, 3]]
check('8JRE 两试玩家净损', [a['player_hp_delta'], b['player_hp_delta']], [-3, -15], [270216, 270282])
check('8JRE 两试敌净扣', [a['enemy_hp_changes'][0]['hp_delta'], b['enemy_hp_changes'][0]['hp_delta']], [-10, -17], [270216, 270282])
check('8JRE 多12血只多7敌净扣', [a['player_hp_delta'] - b['player_hp_delta'], a['enemy_hp_changes'][0]['hp_delta'] - b['enemy_hp_changes'][0]['hp_delta']], [12, 7], [270216, 270282])
guard = window(eight, 33, 5, 2)['facts']
check('8JRE 第二试T5整轮端点', [guard['player_hp_delta'], guard['enemy_hp_changes'][0]['hp_delta']], [-4, -25], [270264])
check('CA5 蚌独立加压力', [power(n, 'STRENGTH_POWER', 'SEWER_CLAM') for n in [273237, 273252, 273263]], [0, 4, 8], [273237, 273252, 273263])
check('CA5 无正敏捷实测不能补步法', any(power(n, 'DEXTERITY_POWER') > 0 for n,r in states.items() if r['ref']['run_id'] == 'CA5KE8GFJ9X2' and r['floor'] == 13), False, [273263])
check('5PM 末试无毒冒泡实付1能', [states[274379]['energy'], states[274380]['energy']], [5, 4], [274379, 274380])
check('5PM 末试无毒冒泡敌HP不变', [enemy_hp(n, 'THE_LOST') for n in [274379, 274380]], [35, 35], [274379, 274380])
check('5PM 末试无毒冒泡毒未建', [power(n, 'POISON_POWER', 'THE_LOST') for n in [274379, 274380]], [0, 0], [274379, 274380])
check('61E 吸取前后玩家力量敏捷', [[power(n, 'STRENGTH_POWER'), power(n, 'DEXTERITY_POWER')] for n in [273502, 273504]], [[2, 0], [0, -2]], [273502, 273504])
check('61E 负敏捷两张防御各3', [value(n, 'DEFEND_SILENT', 'Block') for n in [273504, 273505]], [3, 3], [273504, 273505])
lag = window(consumer('61E2QS63Y9WU', 'bounded'), 17, 6, 1)['facts']
check('61E 已建毒T6净扣33', lag['enemy_hp_changes'][0]['hp_delta'], -33, [273504, 273506])
check('61E F23 两次航行各实体力', [[power(n, 'STRENGTH_POWER', e) for e in ['THE_OBSCURA', 'PARAFRIGHT']] for n in [273583, 273589, 273596]], [[0, 0], [3, 3], [6, 6]], [273583, 273589, 273596])
check('61E F23 T4末幻象未退场', enemy_hp(273596, 'PARAFRIGHT'), 2, [273596])
check('DUZU 熟睡递减后醒来', [power(n, 'SLUMBER_POWER', 'SLUMBERING_BEETLE') for n in [274919, 274923]], [1, 0], [274919, 274923])
check('DUZU 尖啸恢复另有增力', [power(n, 'STRENGTH_POWER', 'SLUMBERING_BEETLE') for n in [274931, 274932, 274934]], [2, -4, 4], [274931, 274932, 274934])
check('DUZU 对应意图20到14到22', [next(e for e in states[n]['enemies'] if e['enemy_id'] == 'SLUMBERING_BEETLE')['intents'][0]['total_damage'] for n in [274931, 274932, 274934]], [20, 14, 22], [274931, 274932, 274934])
summary = {'scope': '固定原材料及既有消费者读回，非生产测试或源码撤回负控', 'count': len(checks), 'passed': len(checks), 'checks': checks}
(s / 'material-checks.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'count': len(checks), 'passed': len(checks), 'production_tests': None}, ensure_ascii=False))

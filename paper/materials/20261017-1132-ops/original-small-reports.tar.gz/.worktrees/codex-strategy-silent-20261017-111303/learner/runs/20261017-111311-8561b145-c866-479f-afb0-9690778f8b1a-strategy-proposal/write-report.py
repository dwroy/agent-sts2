import datetime
import hashlib
import json
from pathlib import Path

s = Path(__file__).resolve().parent
dispatch = json.loads((s / 'dispatch.json').read_text())
proposals = json.loads((s / 'proposals-dispatched.json').read_text())
sources = json.loads((s / 'source-snapshot.json').read_text())
manifest = json.loads((s / 'evidence/evidence-manifest.json').read_text())
summary = json.loads((s / 'consumer-summary.json').read_text())
now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
details = [
('89354805ee4d7e77', '神化升级传播', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；补充首证VPW8YH7A4QFM F35 T1',
 'states275564→275565：能量7→5，防御5→8、打击7→10、匕首雨逐击5→7、工具1→0费；275679→275680见勒紧4→6、尖啸6→8。F43整轮端点51伤/13损、场外升级仍4。',
 'F43施放且获胜仍有后续57血代价；F45未施放且败与敌人/牌序/血药不同，不能证明必打或反事实转胜。',
 '缺实际施放在抽牌、选牌、用药、重问、SL及换战间的持续身份与生产读回；虚弱/脆弱/缩小/暗影等升级交互仍明确未知。现有配对转换和候选字段仅覆盖窄项，不能关闭整项。',
 '保留已观察配对状态变换及未知标记；不补未知升级、不加必打优先级。后续用同角色固定原帧验证实际施放标记跨中断/SL/换战的隔离，并逐项校准未覆盖组合。'),
('f2bfceddb1898dca', '全败候选与药水预算', 'VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5',
 'decisions269748的p0原说明为1/12 MC、707ms，rollout horizon1/samples1/best=null；269754喝药后275728→275730实际+1能/+2手牌/HP不变。T5玩家32血20挡，末三敌仍21/80/77。',
 '同局F17/F33首试获胜；T4未实打31损/32伤候选，实际13损/24伤不能证明改线必胜。CURE_ALL不按中文名称误记回血。',
 '缺完整模型下同起点、同随机池、同总预算的分阶段MC配对及样本成熟曲线，亦缺留药与另一focus完整后继。已发布H1工程截止不等于本提案药水分配、药价或击杀顺序的实盘验证。',
 '保留当前工程预算、留药、护栏及全部目标选项；以固定输入比较预算分配/样本稳定性，先控制升级覆盖，再评价预算。不给707ms拟合新游戏参数。'),
('283a164780d11e69', '神化经验补链', '同89354805ee4d7e77，经验silent-apotheosis-combat-upgrades',
 '十份原Markdown SHA全匹配；本项与原postmortem共享silent-0237/0238和VLZ来源，属于同一机制问题的经验来源链。',
 '来源重复不等于全项已在live实现；不能把题意重复本身登记duplicate。',
 '同源神化项仍缺跨中断的实际施放持续身份及未覆盖升级交互校准；只核窄源码祖先不足以将整个经验来源请求登记duplicate。',
 '沿原两id保留来源链接，合并使用同一证据，不新增重复id或支持计数；验收边界同原神化提案。'),
('ebbfe3b97548756d', '攻防、持续输出与资源分账', 'VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5，及胜战/休息资源接续',
 'F43升级差值、F45实际勒紧4/敏捷3/覆甲0分源；F45 T5最终20挡、32血归零，敌毒结算后仍全存活。联动经验19条只作既有知识读回，不把其历史支持数当本批样本。',
 '已持有两毒雾不等已建立；同局多次休息和高血进场不能保证后战低损，缺另一条路线/休息的受控整战。',
 '缺十五子项逐来源的全部属性/升级组合、状态期限及战斗—路线—休息消费者联合校准；本批端点未隔离出新的确定数值失配，不凭已有局部实现关闭复合项。',
 '准确的现有机制保留；逐源固定验证再修明确失配，神化交原专项。不给路线、休息、终局或输出加统一常数。'),
('e5b87be50f28f311', 'SL、护栏与执行归属', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6',
 '270216/270282同fingerprint；原SL对照dead0/24与5/24不相同，进一步损失都封顶47。消费者整轮分别玩家−3/−15、敌−10/−17，多12血只多7净扣。270264含护栏文字，第二试T5整轮−4/−25且有重问。',
 '末试T2保血替换后延至T11仍败，反对把所有防御替换一概判错；六试是一局，未选原线整战胜负未知。',
 '已有三阶段预测、单动作回执和离线端点，但缺跨抽牌、选牌、用药、重问、SL的完整候选持续归属及本局全过程生产校准；113片段不能认证成长收益或整战改线因果。',
 '维持现有选择与探索；审计保留原答/护栏/SL/派发/观测分层，完整归属未知时不填实际候选收益。若将来改阈值，须按run分组做时间后移验证。'),
('49632bc4878fb597', '力量、敏捷、虚弱与独立成长', 'CA5KE8GFJ9X2 F13 T1—T5',
 'states273237/273252/273263蚌力量0/4/8，喷水11/15/19；本局F13无正敏捷实测，不补计划中步法。',
 '临时虚弱没有取消下一次加压；单局没有隔离正敏捷与全部每击修正的联合生产调用。',
 '缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长四路径联合校准；该局无正敏捷实测，不能凭局部步法或成长代码关闭整条复合经验。',
 '保留当前属性与成长分项模型，不加统一保血/输出权重。固定本局弱前后及增力帧，与另行获得的本角色正敏捷证据分列验证，不借其他角色填空。'),
('66532328a585941f', '持有、启动与兑现', '5PM6JAQG6FNQ F39末试T2；反例F33',
 'decisions268455关联states274379→274380：无毒目标THE_LOST仍35血/0毒，能量5→4，毒雾未建立。消费者保留端点而不把它归成整条候选因果。',
 '同局F33已建立能力并赢，同时组件、敌人、血药和生存窗口改变，不是受控启动顺序比较。',
 '缺同HP、牌组、药水、完整抽序下不同启动顺序的受控整战对照及可复现收益函数；无毒冒泡的局部端点不能确定启动阈值或构筑权重。',
 '持有/到手/实付/建立/后继分账；不将持有能力预支为持续伤害。后续冻结实际启动顺序和完整后继，按局切分验证，不拟合统一优先级。'),
('43a76a31ba7bdcfa', '吸取、负敏捷、毒与SL', '61E2QS63Y9WU F17 T5—T7',
 '273502→273504玩家力2→0、敏0→−2，敌力0→2；T6两张防御牌面各3。既有消费者读回本轮敌67→34净扣33。',
 '本场首试获胜，并无同起点可救活的另一SL线；不能把其他局失败归于本场固定出牌顺序。',
 '缺同起始HP/构筑/抽序下的完整生产整战配对与另一可核SL线路；负敏捷和毒端点只支持分项事实，不支持修改SL范围或阈值。',
 '维持SL规则，冻结吸取、牌挡、毒结算及恢复来源，完整配对后再评价改线收益；不把首试赢当阈值证据。'),
('5264153a4a4b0e5c', '召唤、航行与目标顺序', '61E2QS63Y9WU F23 T1—T5',
 '273583/273589/273596两实体力量0→3→6；T4玩家25→10，本体76→41、幻象14→2，合净扣47但幻象未退场。该局T4消费者整轮窗口unknown，不用类型或索引伪造完整实体身份。',
 'focus幻象39伤/零损候选未实打；局部召唤源码的其他进阶固定夹具不能冒A10航行全链验证。',
 '缺A10召唤、航行、复现、退场全链的冻结生产校准及另一focus完整后继；既有召唤源码与T4净扣不能证明目标排序的整战收益。',
 '保留全部合法目标与同值并列。按当前进阶首样本HP/伤害输入逐实体校准，不规定统一首杀。'),
('bddfa690a84e03d0', '熟睡、眩晕与成长', 'DUZUBAJ3A8GP F30四试；首试T3—T6',
 '274919→274923睡1→0后醒；274931/274932/274934甲虫力2/−4/4、对应意图20/14/22，尖啸到期与独立成长分列。',
 '四试均败且末试T4多扣3敌血、多损2玩家血；并无同抽换序完整胜线，失败次数不增加独立局数。',
 '缺伤害唤醒、眩晕接续及当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次相关失败不足拟合新血价、全败排序或固定杀序。',
 '维持当前选择，分别校准睡层/实际失血/眩晕接续/减力恢复/增力，不用已知死局倒推其他线可赢。'),
]

results = []
body = [f'# 静默策略提案：十个已派id的证据复核与处置\n\n记录时间：{now}。batch=20261017-111303-strategy-proposal；base={sources["base"]}。\n',
        '本批无新增源码/知识或游戏规则。只处理派发十项，不领取其他队列；所有原件及原SHA保存。七局均Silent A10，其中六局为派发锚点，VPW仅为原神化提案显式首证补充。SL/回合/日志记录不扩独立局数。\n',
        '本次36条固定材料检查通过，另实际调用既有离线消费者；它们不属于生产tsc/vitest，不是撤源码负控，也不是后置盲测。每个证据ref保存source/line/offset/bytes/SHA；逐项依据见material-checks.json及selected-*-facts.json。\n']
for suffix, title, evidence, support, counter, reason, behavior in details:
    ident = 'silent-proposal-' + suffix
    item = proposals[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    body.append(f'## {ident}：{title}\n\n来源：{item["source_task"]}；实现任务：strategy-proposal；账本：{"、".join(item["ledger"])}。原件：{item["proposal"]}；SHA256={item["proposal_sha256"]}。\n\n证据：{evidence}。{support}\n\n反例/限制：{counter}\n\n旧规则与预期行为：{behavior}\n\n处置：waiting。{reason}\n\n验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。\n')
body.append('## 共同样本与授权边界\n\nRoy-2026-10-07-learning授权足证时修改既定规则，本批不把原规则视为不可改；限制来自证据与验证缺口。没有尚待批准架构被擅自实现。六局与VPW均是历史发现/复核样本，不冒独立盲测；需要效果比较时，以新独立本角色局按结束时间切开发/验证集，SL按run_id分组。当前源码保留未知/并列/全部合法选项，其他角色无修改。\n\n不新增代码提案id，沿已存在的十个CLI id；不直接写队列或learn.json，不覆盖原提案、不重复复盘、不增加support/repeat。只经根ledger CLI追加本批链接和说明；保留原status/claim/first_run/prior/asc/evidence/version/effect及shipped历史。报告完成不关闭学习父要求、0332/H0等原owner任务或任何自然验收。\n')
(s / 'proposal.md').write_text('\n'.join(body))

final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-111303-strategy-proposal',
         'base': sources['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'],
         'implementation_domains': [], 'proposal_results': results, 'report': str(s / 'report.md')}
(s / 'final-report.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

flow_table = '\n'.join(f'| {r["stream"]} | {r["source_size"]} | {sum(r["counts"].values())} |' for r in manifest)
consumer_table = '\n'.join(f'| {r["run_id"]} | {r["kind"]} | {r["actions"]} | {r["segments"]} | {r["adjacent_endpoints"]} | {r["terminal_endpoints"]} | {r["turn_statuses"].get("observed_turn_endpoints", 0)} | {r["turn_statuses"].get("unknown", 0)} |' for r in summary if r['exit_code'] == 0)
result_table = '\n'.join(f'| {r["id"]} | waiting | {r["reason"]} |' for r in results)
report = f'''# 静默策略学习：本批十项完整处置

记录时间：{now}。batch=20261017-111303-strategy-proposal；character=silent。

十项均waiting：已有实现覆盖若干窄项，本批没有发现可以由这些历史数据直接校准的新策略参数或确定数值缺口。没有源码/知识修改、提交、合入、发布号或新增shipped；fixes=[]、merged=null、implementation_domains=[]。逐项证据、账本、反例、预期行为、验证与回退在同目录proposal.md，原提案逐字保存为十份*.original.md。

## 身份与范围

初始git status干净，HEAD=f6f33b98814e6245a7ac86352b0107e1ebda80ba。必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol、learning-code-proposals已读；本批learn.json核task/character/worktree/running及十proposal_ids，无proposal_repair/research_request/implementation_request。根普通专题请求绑定另一batch，不转为专题、不读另一专题代替。按普通任务git merge --no-edit main，无冲突快进到完整base={sources['base']}；后续不再追入main。最终HEAD保持该base。

来源六局runs.jsonl原行均Silent A10：{','.join(dispatch['runs'])}。原神化提案还引用VPW8YH7A4QFM，独立核Silent A10后仅补首证；实际范围为六派发局加这一原文明示局。所有旧运行code带dirty，不能凭Git提交恢复当时完整源码、知识或随机池。其他角色私有知识未读，无下级agent，无联网/模型调用/对局/新模拟。

## 原始证据与旧截点

共用extract_evidence.py提取八流，每流各自source_size冻结，不能当一个原子全局cut。8,449条封套已按offset/bytes/SHA/解码对象/显式run身份逐项原日志读回，结果evidence-verification.json；其中本批六局6,995条、VPW补充1,454条。身份不取正文提及，冲突不接收。987状态、952决策的相关层投影保存在selected-state-facts.json、selected-decision-facts.json。全源states/decisions/brain各2无效JSON行，不据此判断属于本七局；fight-plans 0行仅为此cut未选到。

| 流 | source_size字节 | 所属记录 |
|---|---:|---:|
{flow_table}

按旧报告run-plans截点7754565另存evidence-run-plans-oldcut，六局33行。输出SHA b43fd878a38f6d715e0cab0edc3d7801d2e183d51f766bdd2bb21e9d0557591b与旧保存件一致，比较见oldcut-comparison.json。新全源截点增长不代表本批新增局或新增独立证据，不覆盖旧报告/初稿。

## 实际消费者与固定材料核验

从已核原封套制作单局gzip输入，保留真实decision_id、observed_ts、fingerprint和物理_line，冻结输入SHA和消费者五个递归依赖SHA；nice下实际用node --import tsx调用本base的learner/lib/selection-execution.ts。没有使用刷新知识JSON或LLM。36条固定材料断言全部通过，保存material-checks.json及原stdout/stderr；这是材料和既有消费者读回，不是生产测试。

VLZ/8JRE/5PM完整输入成功。CA5物理267143、61E267517、DUZU268789/268818/268864缺decision_id，完整输入真实拒收，原失败stderr和receipt保留；不造ID。仅去掉这五行另存bounded输入，保留物理行号缺口后成功，不能写成完整输入通过。

| 局 | 输入 | 有ID动作 | 候选片段 | 相邻端点 | 终页端点 | 整轮端点 | 未知轮窗 |
|---|---|---:|---:|---:|---:|---:|---:|
{consumer_table}

合计3,301动作、476片段、859相邻端点、4终页端点、121整轮端点、413未知轮窗。476片段的actual_full_candidate_result全部null是消费者认证边界，不表示候选从未执行、没有可核端点或游戏规则已经失败。8JRE同盘F33 T2多12血/多7敌净扣，0/24和5/24不并列；第二试T5−4/−25有重问，不全归护栏。5PM末试无毒冒泡5→4能、敌35/0毒不变。61E负敏捷两防御各3，毒端点67→34；F23 T4窗口unknown而原状态仍能核幻象2血。DUZU临减恢复与力量继续成长分列，四次尝试不扩独立局数。

## 现有源码核对

只读live快照={sources['live_observed']}。15精确源码叶11同字节，card-model/rollout-live/explore/draws四叶仅独立单词Roy/Dai的历史署名差，原patch保存在source-vs-live.patch.txt，逐字节分类source-diff-classification.json；不据这15叶宣称全树或旧dirty运行等价。source-snapshot的last_source_commit只是main该路径最后触及记录，不能直接当live实现来源。

11个明确窄源均核为base/live祖先，详existing-live-ancestors.json：包括772b839f神化配对、f516592f触媒、b2805be4萎靡、ba23ca69毒药、3aa6c03a候选事实、05cd292c三阶段快照、a8b1f8be护栏审计、fdaf787a派发回执、1e076b17召唤、cf72bd21离线消费者、7af803c0 H1工程预算。这些是既有窄项，不是本批新提交或完整原提案的duplicate证明。当前actual_cast_this_fight仍null，派发state_effect_verified=false/whole_plan_executed=null；因此不把候选模型升级、API返回或离线端点冒持续实际施放/完整候选收益。

H1已授权工程截止在当前源码存在，不能以旧707ms描述当前全局预算不变；本提案仍缺同总预算MC分配、完整覆盖和留药/另一focus受控后继，不把工程发布当游戏收益学习完成。没有发现新科学反证或与旧知识冲突，本轮不重复发送科学通知。

## 十项结果

| 原id | 处置 | 具体缺口 |
|---|---|---|
{result_table}

## 记录、验证与限制

仅经根learner/ledger.py update追加相关26条静默账本的本批proposal/report链接和where/note，by=learner:strategy-proposal；不改claim/status/version/evidence/first_run/asc/prior/effect，不追加support/repeat、不降级旧shipped。队列处置由最终proposal_results交既有调度器，不直接改专用队列/learn.json。CLI输入、返回与受保护字段核验另存本目录，实际回执见ledger-append-verification.json。

无新增生产源码，所以撤源码失败/恢复通过不适用，tsc/vitest/cases固定null；没有复跑生产套件或将材料检查写成测试0。未启动live合入/知识刷新/版本/规则双通知或decision-log上线记录。工作树保持干净，源码diff和HEAD核验见completion-verification.json。本批没有提交，无需伪造Co-Authored-By或源码commit。报告、提案、最终JSON和CLI输入另做gitleaks脱敏扫描，原结果保存。

保留的只读探索错误：最初按猜测路径寻找draws/enemy-tables和若干selection模块未命中，随后以rg及实际learner/lib入口定位；一次临时探索把nullable expect字段当字典而触发AttributeError，原工具回执留史，更正为显式空值处理后完成读回。这些不是生产缺陷或撤源码负控。三份缺ID完整消费者输入的拒收保留，未修改消费者、原日志或验收条件。

当前仍是历史发现样本内复核，没有独立时间后移验证，没有未选整场反事实，没有原dirty全树/随机池重建；不拟合新血价、药价、SL阈值、启动权重或固定杀序。报告与链接不等于经验库发布、大脑采用或父要求关闭。实际原生模型/强度/计费档由宿主回执核，本批未读凭据或改模型/权限配置，不拿默认设置冒原生证明。

运维交付proposal={s / 'proposal.md'}；report={s / 'report.md'}；最终结构化回报另见final-report.json。
'''
(s / 'report.md').write_text(report)
print(json.dumps({'report': str(s / 'report.md'), 'proposal': str(s / 'proposal.md'), 'results': len(results)}, ensure_ascii=False))

# 静默策略学习：本批十项完整处置

记录时间：2026-10-17T11:26:19+08:00。batch=20261017-111303-strategy-proposal；character=silent。

十项均waiting：已有实现覆盖若干窄项，本批没有发现可以由这些历史数据直接校准的新策略参数或确定数值缺口。没有源码/知识修改、提交、合入、发布号或新增shipped；fixes=[]、merged=null、implementation_domains=[]。逐项证据、账本、反例、预期行为、验证与回退在同目录proposal.md，原提案逐字保存为十份*.original.md。

## 身份与范围

初始git status干净，HEAD=f6f33b98814e6245a7ac86352b0107e1ebda80ba。必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol、learning-code-proposals已读；本批learn.json核task/character/worktree/running及十proposal_ids，无proposal_repair/research_request/implementation_request。根普通专题请求绑定另一batch，不转为专题、不读另一专题代替。按普通任务git merge --no-edit main，无冲突快进到完整base=a7082731a849abf2db5055d7fa82236200f3819d；后续不再追入main。最终HEAD保持该base。

来源六局runs.jsonl原行均Silent A10：VLZ6CCT8AQ0A,8JRE1C4H4Z2W,CA5KE8GFJ9X2,5PM6JAQG6FNQ,61E2QS63Y9WU,DUZUBAJ3A8GP。原神化提案还引用VPW8YH7A4QFM，独立核Silent A10后仅补首证；实际范围为六派发局加这一原文明示局。所有旧运行code带dirty，不能凭Git提交恢复当时完整源码、知识或随机池。其他角色私有知识未读，无下级agent，无联网/模型调用/对局/新模拟。

## 原始证据与旧截点

共用extract_evidence.py提取八流，每流各自source_size冻结，不能当一个原子全局cut。8,449条封套已按offset/bytes/SHA/解码对象/显式run身份逐项原日志读回，结果evidence-verification.json；其中本批六局6,995条、VPW补充1,454条。身份不取正文提及，冲突不接收。987状态、952决策的相关层投影保存在selected-state-facts.json、selected-decision-facts.json。全源states/decisions/brain各2无效JSON行，不据此判断属于本七局；fight-plans 0行仅为此cut未选到。

| 流 | source_size字节 | 所属记录 |
|---|---:|---:|
| states | 13828538258 | 4139 |
| decisions | 2178504252 | 3992 |
| sl-attempts | 44993904 | 31 |
| run-config | 1933815 | 7 |
| run-plans | 8808173 | 41 |
| brain | 727082193 | 232 |
| runs | 355966 | 7 |
| fight-plans | 2233957 | 0 |

按旧报告run-plans截点7754565另存evidence-run-plans-oldcut，六局33行。输出SHA b43fd878a38f6d715e0cab0edc3d7801d2e183d51f766bdd2bb21e9d0557591b与旧保存件一致，比较见oldcut-comparison.json。新全源截点增长不代表本批新增局或新增独立证据，不覆盖旧报告/初稿。

## 实际消费者与固定材料核验

从已核原封套制作单局gzip输入，保留真实decision_id、observed_ts、fingerprint和物理_line，冻结输入SHA和消费者五个递归依赖SHA；nice下实际用node --import tsx调用本base的learner/lib/selection-execution.ts。没有使用刷新知识JSON或LLM。36条固定材料断言全部通过，保存material-checks.json及原stdout/stderr；这是材料和既有消费者读回，不是生产测试。

VLZ/8JRE/5PM完整输入成功。CA5物理267143、61E267517、DUZU268789/268818/268864缺decision_id，完整输入真实拒收，原失败stderr和receipt保留；不造ID。仅去掉这五行另存bounded输入，保留物理行号缺口后成功，不能写成完整输入通过。

| 局 | 输入 | 有ID动作 | 候选片段 | 相邻端点 | 终页端点 | 整轮端点 | 未知轮窗 |
|---|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | full | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | full | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | bounded | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | full | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | bounded | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | bounded | 599 | 77 | 189 | 1 | 28 | 68 |

合计3,301动作、476片段、859相邻端点、4终页端点、121整轮端点、413未知轮窗。476片段的actual_full_candidate_result全部null是消费者认证边界，不表示候选从未执行、没有可核端点或游戏规则已经失败。8JRE同盘F33 T2多12血/多7敌净扣，0/24和5/24不并列；第二试T5−4/−25有重问，不全归护栏。5PM末试无毒冒泡5→4能、敌35/0毒不变。61E负敏捷两防御各3，毒端点67→34；F23 T4窗口unknown而原状态仍能核幻象2血。DUZU临减恢复与力量继续成长分列，四次尝试不扩独立局数。

## 现有源码核对

只读live快照=7907ca1af8f88d2adbe6b137ff8b6b8ceb082a23。15精确源码叶11同字节，card-model/rollout-live/explore/draws四叶仅独立单词Roy/Dai的历史署名差，原patch保存在source-vs-live.patch.txt，逐字节分类source-diff-classification.json；不据这15叶宣称全树或旧dirty运行等价。source-snapshot的last_source_commit只是main该路径最后触及记录，不能直接当live实现来源。

11个明确窄源均核为base/live祖先，详existing-live-ancestors.json：包括772b839f神化配对、f516592f触媒、b2805be4萎靡、ba23ca69毒药、3aa6c03a候选事实、05cd292c三阶段快照、a8b1f8be护栏审计、fdaf787a派发回执、1e076b17召唤、cf72bd21离线消费者、7af803c0 H1工程预算。这些是既有窄项，不是本批新提交或完整原提案的duplicate证明。当前actual_cast_this_fight仍null，派发state_effect_verified=false/whole_plan_executed=null；因此不把候选模型升级、API返回或离线端点冒持续实际施放/完整候选收益。

H1已授权工程截止在当前源码存在，不能以旧707ms描述当前全局预算不变；本提案仍缺同总预算MC分配、完整覆盖和留药/另一focus受控后继，不把工程发布当游戏收益学习完成。没有发现新科学反证或与旧知识冲突，本轮不重复发送科学通知。

## 十项结果

| 原id | 处置 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺实际施放在抽牌、选牌、用药、重问、SL及换战间的持续身份与生产读回；虚弱/脆弱/缩小/暗影等升级交互仍明确未知。现有配对转换和候选字段仅覆盖窄项，不能关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的分阶段MC配对及样本成熟曲线，亦缺留药与另一focus完整后继。已发布H1工程截止不等于本提案药水分配、药价或击杀顺序的实盘验证。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化项仍缺跨中断的实际施放持续身份及未覆盖升级交互校准；只核窄源码祖先不足以将整个经验来源请求登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项逐来源的全部属性/升级组合、状态期限及战斗—路线—休息消费者联合校准；本批端点未隔离出新的确定数值失配，不凭已有局部实现关闭复合项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有三阶段预测、单动作回执和离线端点，但缺跨抽牌、选牌、用药、重问、SL的完整候选持续归属及本局全过程生产校准；113片段不能认证成长收益或整战改线因果。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长四路径联合校准；该局无正敏捷实测，不能凭局部步法或成长代码关闭整条复合经验。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水、完整抽序下不同启动顺序的受控整战对照及可复现收益函数；无毒冒泡的局部端点不能确定启动阈值或构筑权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP/构筑/抽序下的完整生产整战配对与另一可核SL线路；负敏捷和毒端点只支持分项事实，不支持修改SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行、复现、退场全链的冻结生产校准及另一focus完整后继；既有召唤源码与T4净扣不能证明目标排序的整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次相关失败不足拟合新血价、全败排序或固定杀序。 |

## 记录、验证与限制

仅经根learner/ledger.py update追加相关26条静默账本的本批proposal/report链接和where/note，by=learner:strategy-proposal；不改claim/status/version/evidence/first_run/asc/prior/effect，不追加support/repeat、不降级旧shipped。队列处置由最终proposal_results交既有调度器，不直接改专用队列/learn.json。CLI输入、返回与受保护字段核验另存本目录，实际回执见ledger-append-verification.json。

无新增生产源码，所以撤源码失败/恢复通过不适用，tsc/vitest/cases固定null；没有复跑生产套件或将材料检查写成测试0。未启动live合入/知识刷新/版本/规则双通知或decision-log上线记录。工作树保持干净，源码diff和HEAD核验见completion-verification.json。本批没有提交，无需伪造Co-Authored-By或源码commit。报告、提案、最终JSON和CLI输入另做gitleaks脱敏扫描，原结果保存。

保留的只读探索错误：最初按猜测路径寻找draws/enemy-tables和若干selection模块未命中，随后以rg及实际learner/lib入口定位；一次临时探索把nullable expect字段当字典而触发AttributeError，原工具回执留史，更正为显式空值处理后完成读回。这些不是生产缺陷或撤源码负控。三份缺ID完整消费者输入的拒收保留，未修改消费者、原日志或验收条件。

当前仍是历史发现样本内复核，没有独立时间后移验证，没有未选整场反事实，没有原dirty全树/随机池重建；不拟合新血价、药价、SL阈值、启动权重或固定杀序。报告与链接不等于经验库发布、大脑采用或父要求关闭。实际原生模型/强度/计费档由宿主回执核，本批未读凭据或改模型/权限配置，不拿默认设置冒原生证明。

运维交付proposal=/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-111303/learner/runs/20261017-111311-8561b145-c866-479f-afb0-9690778f8b1a-strategy-proposal/proposal.md；report=/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-111303/learner/runs/20261017-111311-8561b145-c866-479f-afb0-9690778f8b1a-strategy-proposal/report.md；最终结构化回报另见final-report.json。

结束核验（2026-10-17T11:31:13+08:00）：根账本22530901字节原前缀SHA保持；本批26行按物理offset/bytes/SHA/JSON及逐行fold读回，全部只增where/note，受保护字段没有被本批改动。并行任务在silent-0019/0020/0079/0125各追加证据，保存其四行元数据且不用于本批游戏结论；不以并行变化否定或覆盖原记录。

保留补充核验失败：两次临时核验误把CLI空格分隔id stdout当JSON，原JSONDecodeError保存initial/second.stderr；更正为split读取。第三次全局前后fold断言捕获并行四项evidence变化，原失败保存third.stderr；改按本批实际物理行逐条前后fold检查，确认本批未改保护字段。没有重跑CLI或重复追加证据。一次gitleaks帮助命令在bubblewrap预检因并行临时路径ENOENT未执行，原错误另存，按相同权限重试成功；不视为凭据故障或放宽沙箱。

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const scratch = path.dirname(fileURLToPath(import.meta.url));
const worktree = path.resolve(scratch, '../../..');
const { auditSelectionExecution } = await import(pathToFileURL(path.join(worktree, 'learner/lib/selection-execution.ts')));
const manifest = JSON.parse(fs.readFileSync(path.join(scratch, 'consumer-input-manifest.json'), 'utf8'));
const summaries = [];
for (const item of manifest) {
  for (const [kind, input] of [['full', item.path], ...(item.bounded_path ? [['bounded', item.bounded_path]] : [])]) {
    const prefix = path.join(scratch, `${item.run_id}.consumer-${kind}`);
    const source = JSON.parse(zlib.gunzipSync(fs.readFileSync(input)));
    try {
      const result = auditSelectionExecution(source);
      fs.writeFileSync(prefix + '.output.json.gz', zlib.gzipSync(Buffer.from(JSON.stringify(result))));
      fs.writeFileSync(prefix + '.stderr', '');
      const summary = {
        run_id: item.run_id, kind, exit_code: 0, actions: result.observed_actions.length,
        segments: result.segments.length,
        adjacent_endpoints: result.observed_actions.filter(a => a.observed_interval.status === 'observed_endpoints').length,
        terminal_endpoints: result.observed_actions.filter(a => a.terminal_observation?.status === 'observed_terminal_endpoints').length,
        turn_statuses: result.observed_turns.reduce((out, t) => ({...out, [t.status]: (out[t.status] ?? 0) + 1}), {}),
        uncertified_segments: result.segments.filter(s => s.actual_full_candidate_result === null).length,
        output_sha256: crypto.createHash('sha256').update(fs.readFileSync(prefix + '.output.json.gz')).digest('hex'),
      };
      fs.writeFileSync(prefix + '.receipt.json', JSON.stringify(summary, null, 2) + '\n');
      summaries.push(summary);
    } catch (error) {
      fs.writeFileSync(prefix + '.stderr', String(error) + '\n');
      const receipt = {run_id: item.run_id, kind, exit_code: 1, reason: String(error)};
      fs.writeFileSync(prefix + '.receipt.json', JSON.stringify(receipt, null, 2) + '\n');
      summaries.push(receipt);
    }
  }
}
fs.writeFileSync(path.join(scratch, 'consumer-summary.json'), JSON.stringify(summaries, null, 2) + '\n');
process.stdout.write(JSON.stringify(summaries, null, 2) + '\n');

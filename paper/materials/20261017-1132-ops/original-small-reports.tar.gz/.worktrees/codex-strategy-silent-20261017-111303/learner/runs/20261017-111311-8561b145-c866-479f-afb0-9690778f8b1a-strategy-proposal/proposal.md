# 静默策略提案：十个已派id的证据复核与处置

记录时间：2026-10-17T11:26:19+08:00。batch=20261017-111303-strategy-proposal；base=a7082731a849abf2db5055d7fa82236200f3819d。

本批无新增源码/知识或游戏规则。只处理派发十项，不领取其他队列；所有原件及原SHA保存。七局均Silent A10，其中六局为派发锚点，VPW仅为原神化提案显式首证补充。SL/回合/日志记录不扩独立局数。

本次36条固定材料检查通过，另实际调用既有离线消费者；它们不属于生产tsc/vitest，不是撤源码负控，也不是后置盲测。每个证据ref保存source/line/offset/bytes/SHA；逐项依据见material-checks.json及selected-*-facts.json。

## silent-proposal-89354805ee4d7e77：神化升级传播

来源：postmortem；实现任务：strategy-proposal；账本：silent-0237、silent-0238。原件：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。

证据：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；补充首证VPW8YH7A4QFM F35 T1。states275564→275565：能量7→5，防御5→8、打击7→10、匕首雨逐击5→7、工具1→0费；275679→275680见勒紧4→6、尖啸6→8。F43整轮端点51伤/13损、场外升级仍4。

反例/限制：F43施放且获胜仍有后续57血代价；F45未施放且败与敌人/牌序/血药不同，不能证明必打或反事实转胜。

旧规则与预期行为：保留已观察配对状态变换及未知标记；不补未知升级、不加必打优先级。后续用同角色固定原帧验证实际施放标记跨中断/SL/换战的隔离，并逐项校准未覆盖组合。

处置：waiting。缺实际施放在抽牌、选牌、用药、重问、SL及换战间的持续身份与生产读回；虚弱/脆弱/缩小/暗影等升级交互仍明确未知。现有配对转换和候选字段仅覆盖窄项，不能关闭整项。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-f2bfceddb1898dca：全败候选与药水预算

来源：postmortem；实现任务：strategy-proposal；账本：silent-0106、silent-0019、silent-0201。原件：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。

证据：VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5。decisions269748的p0原说明为1/12 MC、707ms，rollout horizon1/samples1/best=null；269754喝药后275728→275730实际+1能/+2手牌/HP不变。T5玩家32血20挡，末三敌仍21/80/77。

反例/限制：同局F17/F33首试获胜；T4未实打31损/32伤候选，实际13损/24伤不能证明改线必胜。CURE_ALL不按中文名称误记回血。

旧规则与预期行为：保留当前工程预算、留药、护栏及全部目标选项；以固定输入比较预算分配/样本稳定性，先控制升级覆盖，再评价预算。不给707ms拟合新游戏参数。

处置：waiting。缺完整模型下同起点、同随机池、同总预算的分阶段MC配对及样本成熟曲线，亦缺留药与另一focus完整后继。已发布H1工程截止不等于本提案药水分配、药价或击杀顺序的实盘验证。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-283a164780d11e69：神化经验补链

来源：experience-update；实现任务：strategy-proposal；账本：silent-0237、silent-0238。原件：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。

证据：同89354805ee4d7e77，经验silent-apotheosis-combat-upgrades。十份原Markdown SHA全匹配；本项与原postmortem共享silent-0237/0238和VLZ来源，属于同一机制问题的经验来源链。

反例/限制：来源重复不等于全项已在live实现；不能把题意重复本身登记duplicate。

旧规则与预期行为：沿原两id保留来源链接，合并使用同一证据，不新增重复id或支持计数；验收边界同原神化提案。

处置：waiting。同源神化项仍缺跨中断的实际施放持续身份及未覆盖升级交互校准；只核窄源码祖先不足以将整个经验来源请求登记duplicate。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-ebbfe3b97548756d：攻防、持续输出与资源分账

来源：experience-update；实现任务：strategy-proposal；账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。原件：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。

证据：VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5，及胜战/休息资源接续。F43升级差值、F45实际勒紧4/敏捷3/覆甲0分源；F45 T5最终20挡、32血归零，敌毒结算后仍全存活。联动经验19条只作既有知识读回，不把其历史支持数当本批样本。

反例/限制：已持有两毒雾不等已建立；同局多次休息和高血进场不能保证后战低损，缺另一条路线/休息的受控整战。

旧规则与预期行为：准确的现有机制保留；逐源固定验证再修明确失配，神化交原专项。不给路线、休息、终局或输出加统一常数。

处置：waiting。缺十五子项逐来源的全部属性/升级组合、状态期限及战斗—路线—休息消费者联合校准；本批端点未隔离出新的确定数值失配，不凭已有局部实现关闭复合项。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-e5b87be50f28f311：SL、护栏与执行归属

来源：postmortem；实现任务：strategy-proposal；账本：silent-0079、silent-0021、silent-0125、silent-0018。原件：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。

证据：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6。270216/270282同fingerprint；原SL对照dead0/24与5/24不相同，进一步损失都封顶47。消费者整轮分别玩家−3/−15、敌−10/−17，多12血只多7净扣。270264含护栏文字，第二试T5整轮−4/−25且有重问。

反例/限制：末试T2保血替换后延至T11仍败，反对把所有防御替换一概判错；六试是一局，未选原线整战胜负未知。

旧规则与预期行为：维持现有选择与探索；审计保留原答/护栏/SL/派发/观测分层，完整归属未知时不填实际候选收益。若将来改阈值，须按run分组做时间后移验证。

处置：waiting。已有三阶段预测、单动作回执和离线端点，但缺跨抽牌、选牌、用药、重问、SL的完整候选持续归属及本局全过程生产校准；113片段不能认证成长收益或整战改线因果。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-49632bc4878fb597：力量、敏捷、虚弱与独立成长

来源：experience-update；实现任务：strategy-proposal；账本：silent-0005、silent-0231。原件：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。

证据：CA5KE8GFJ9X2 F13 T1—T5。states273237/273252/273263蚌力量0/4/8，喷水11/15/19；本局F13无正敏捷实测，不补计划中步法。

反例/限制：临时虚弱没有取消下一次加压；单局没有隔离正敏捷与全部每击修正的联合生产调用。

旧规则与预期行为：保留当前属性与成长分项模型，不加统一保血/输出权重。固定本局弱前后及增力帧，与另行获得的本角色正敏捷证据分列验证，不借其他角色填空。

处置：waiting。缺同一冻结生产调用中逐击力量、正负敏捷、虚弱与蚌独立成长四路径联合校准；该局无正敏捷实测，不能凭局部步法或成长代码关闭整条复合经验。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-66532328a585941f：持有、启动与兑现

来源：experience-update；实现任务：strategy-proposal；账本：silent-0021、silent-0009。原件：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。

证据：5PM6JAQG6FNQ F39末试T2；反例F33。decisions268455关联states274379→274380：无毒目标THE_LOST仍35血/0毒，能量5→4，毒雾未建立。消费者保留端点而不把它归成整条候选因果。

反例/限制：同局F33已建立能力并赢，同时组件、敌人、血药和生存窗口改变，不是受控启动顺序比较。

旧规则与预期行为：持有/到手/实付/建立/后继分账；不将持有能力预支为持续伤害。后续冻结实际启动顺序和完整后继，按局切分验证，不拟合统一优先级。

处置：waiting。缺同HP、牌组、药水、完整抽序下不同启动顺序的受控整战对照及可复现收益函数；无毒冒泡的局部端点不能确定启动阈值或构筑权重。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-43a76a31ba7bdcfa：吸取、负敏捷、毒与SL

来源：experience-update；实现任务：strategy-proposal；账本：silent-0030、silent-0027。原件：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。

证据：61E2QS63Y9WU F17 T5—T7。273502→273504玩家力2→0、敏0→−2，敌力0→2；T6两张防御牌面各3。既有消费者读回本轮敌67→34净扣33。

反例/限制：本场首试获胜，并无同起点可救活的另一SL线；不能把其他局失败归于本场固定出牌顺序。

旧规则与预期行为：维持SL规则，冻结吸取、牌挡、毒结算及恢复来源，完整配对后再评价改线收益；不把首试赢当阈值证据。

处置：waiting。缺同起始HP/构筑/抽序下的完整生产整战配对与另一可核SL线路；负敏捷和毒端点只支持分项事实，不支持修改SL范围或阈值。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-5264153a4a4b0e5c：召唤、航行与目标顺序

来源：experience-update；实现任务：strategy-proposal；账本：silent-0039、silent-0209。原件：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。

证据：61E2QS63Y9WU F23 T1—T5。273583/273589/273596两实体力量0→3→6；T4玩家25→10，本体76→41、幻象14→2，合净扣47但幻象未退场。该局T4消费者整轮窗口unknown，不用类型或索引伪造完整实体身份。

反例/限制：focus幻象39伤/零损候选未实打；局部召唤源码的其他进阶固定夹具不能冒A10航行全链验证。

旧规则与预期行为：保留全部合法目标与同值并列。按当前进阶首样本HP/伤害输入逐实体校准，不规定统一首杀。

处置：waiting。缺A10召唤、航行、复现、退场全链的冻结生产校准及另一focus完整后继；既有召唤源码与T4净扣不能证明目标排序的整战收益。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## silent-proposal-bddfa690a84e03d0：熟睡、眩晕与成长

来源：experience-update；实现任务：strategy-proposal；账本：silent-0128、silent-0079。原件：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。

证据：DUZUBAJ3A8GP F30四试；首试T3—T6。274919→274923睡1→0后醒；274931/274932/274934甲虫力2/−4/4、对应意图20/14/22，尖啸到期与独立成长分列。

反例/限制：四试均败且末试T4多扣3敌血、多损2玩家血；并无同抽换序完整胜线，失败次数不增加独立局数。

旧规则与预期行为：维持当前选择，分别校准睡层/实际失血/眩晕接续/减力恢复/增力，不用已知死局倒推其他线可赢。

处置：waiting。缺伤害唤醒、眩晕接续及当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次相关失败不足拟合新血价、全败排序或固定杀序。

验证及回退：发现样本内只核原帧/调用事实，不拟合新权重；新增实现必须固定本角色输入、明确撤源码失败/恢复通过，并跑原沙箱入口，再按live流程发布。没有源码变更时无回退提交，不撤现有补丁。原证据、失败回执和提案长期保留。

## 共同样本与授权边界

Roy-2026-10-07-learning授权足证时修改既定规则，本批不把原规则视为不可改；限制来自证据与验证缺口。没有尚待批准架构被擅自实现。六局与VPW均是历史发现/复核样本，不冒独立盲测；需要效果比较时，以新独立本角色局按结束时间切开发/验证集，SL按run_id分组。当前源码保留未知/并列/全部合法选项，其他角色无修改。

不新增代码提案id，沿已存在的十个CLI id；不直接写队列或learn.json，不覆盖原提案、不重复复盘、不增加support/repeat。只经根ledger CLI追加本批链接和说明；保留原status/claim/first_run/prior/asc/evidence/version/effect及shipped历史。报告完成不关闭学习父要求、0332/H0等原owner任务或任何自然验收。

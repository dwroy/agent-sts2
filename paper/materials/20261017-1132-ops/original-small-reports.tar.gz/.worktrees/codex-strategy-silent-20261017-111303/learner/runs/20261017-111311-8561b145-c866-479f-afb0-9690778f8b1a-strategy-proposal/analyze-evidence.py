import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location('extractor', WORKTREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)

def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def reference(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}

manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
streams = {}
verification = []
for stream in manifest:
    name = stream['stream']
    path = SCRATCH / f'evidence/{name}.evidence.jsonl'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    counts = collections.Counter()
    items = []
    with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for encoded in path.open():
            item = json.loads(encoded)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extractor.run_identity(item['row']) == item['run_id']
            counts[item['run_id']] += 1
            items.append(item)
    assert all(counts[r] == n for r, n in stream['counts'].items())
    streams[name] = items
    verification.append({'stream': name, 'source_size': stream['source_size'],
                         'verified_rows': len(items), 'counts': dict(counts), 'ok': True})
save('evidence-verification.json', verification)

floors = {'VLZ6CCT8AQ0A': [35, 36, 37, 43, 44, 45], '8JRE1C4H4Z2W': [17, 33],
          'CA5KE8GFJ9X2': [9, 13], '5PM6JAQG6FNQ': [33, 39],
          '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [27, 30], 'VPW8YH7A4QFM': [35, 38, 39]}
state_facts = []
for item in streams['states']:
    state = item['row']['state']
    run = state.get('run', {})
    assert run.get('character_id', '').lower() == 'silent' and run.get('ascension') == 10
    if run.get('floor') not in floors[item['run_id']]:
        continue
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    state_facts.append({'ref': reference(item), 'observed_ts': item['row'].get('observed_ts'),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': player.get('max_hp', run.get('max_hp')),
        'block': player.get('block'), 'energy': player.get('energy'), 'powers': player.get('powers'),
        'hand': combat.get('hand'), 'enemies': combat.get('enemies'), 'potions': run.get('potions'),
        'deck_upgraded': sum(c.get('upgraded') is True for c in run.get('deck', []))})
save('selected-state-facts.json', state_facts)
decision_facts = []
for item in streams['decisions']:
    row = item['row']
    if row.get('floor') not in floors[item['run_id']]:
        continue
    decision_facts.append({'ref': reference(item), **{k: row.get(k) for k in (
        'decision_id', 'observed_ts', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label',
        'fingerprint', 'chosen', 'expect', 'result', 'rationale', 'answers', 'questions',
        'rollout', 'rollout_best_chosen', 'hp_guard', 'sl_explore', 'selection_audit')}})
save('selected-decision-facts.json', decision_facts)

runs = {r['run_id']: r for r in json.loads((SCRATCH / 'runs-verified.json').read_text())}
input_manifest = []
for run_id in json.loads((SCRATCH / 'dispatch.json').read_text())['runs']:
    data = {'run': runs[run_id], 'decisions': [], 'states': []}
    for key in ('decisions', 'states'):
        for item in streams[key]:
            if item['run_id'] == run_id:
                assert '_line' not in item['row']
                data[key].append({**item['row'], '_line': item['line']})
    raw = json.dumps(data, ensure_ascii=False).encode()
    path = SCRATCH / (run_id + '.consumer-input.json.gz')
    path.write_bytes(gzip.compress(raw, mtime=0))
    missing = [r['_line'] for r in data['decisions'] if not r.get('decision_id')]
    entry = {'run_id': run_id, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
             'bytes': path.stat().st_size, 'decisions': len(data['decisions']), 'states': len(data['states']),
             'missing_decision_id_lines': missing}
    if missing:
        data['decisions'] = [r for r in data['decisions'] if r.get('decision_id')]
        bounded = SCRATCH / (run_id + '.consumer-bounded-input.json.gz')
        bounded.write_bytes(gzip.compress(json.dumps(data, ensure_ascii=False).encode(), mtime=0))
        entry['bounded_path'] = str(bounded)
        entry['bounded_sha256'] = hashlib.sha256(bounded.read_bytes()).hexdigest()
    input_manifest.append(entry)
save('consumer-input-manifest.json', input_manifest)
print(json.dumps({'verified_rows': sum(v['verified_rows'] for v in verification),
                  'selected_states': len(state_facts), 'selected_decisions': len(decision_facts),
                  'consumer_inputs': len(input_manifest)}, ensure_ascii=False))

from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0543';pub=root/'paper/materials/20261016-0543-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-052701-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text()
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==load(s/'result.json')
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert {x['id'] for x in report['proposal_results']}==set(b['proposal_ids'])==set(report['code_proposals'])
assert report['fixes']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-verification.json');assert final['head']==report['base'] and final['status_porcelain']=='' and final['tracked_diff_bytes']==0 and final['relevant_source_leaves_unchanged'] and final['ledger_trace_updates']==26
assert (s/'source-diff.patch').read_bytes()==b'' and final['report_sha256']==sha((s/'report.md').read_bytes()) and final['final_gitleaks_exit_code']==0 and load(s/'gitleaks-final-report.json')==[]
originals=load(s/'proposal-source-verification.json');assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for item in originals:
    f=Path(item['path']);raw=f.read_bytes();assert f.is_relative_to(root) and len(raw)==item['bytes'] and sha(raw)==item['sha256']
facts=load(s/'fact-checks.json');assert facts['count']==len(facts['checks'])==39 and facts['all_passed'] and all(x['passed'] and x['actual']==x['expected'] for x in facts['checks'])
extract=module('original_extract',root/'learner/extract_evidence.py');counts={};runs={};configs={};rows={key:{} for key in ['states','decisions']};raw_receipts=load(s/'raw-verification.json')
for entry in load(s/'evidence/evidence-manifest.json'):
    stream=entry['stream'];h=hashlib.sha256();seen=collections.Counter()
    with (s/'evidence'/(stream+'.evidence.jsonl')).open('rb') as selected,(root/'logs'/(stream+'.jsonl')).open('rb') as source:
        for line in selected:
            h.update(line);e=json.loads(line);source.seek(e['offset']);raw=source.read(e['bytes']);r=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and r==e['row'] and e['offset']+e['bytes']<=entry['source_size'] and extract.run_identity(r)==e['run_id'] in report['runs']
            if stream=='states':assert (r['state']['run']['character_id'],r['state']['run']['ascension'])==('SILENT',10)
            if stream=='runs':assert (r['character'],r['ascension'],r['victory'])==('SILENT',10,False);runs[e['run_id']]=r
            if stream=='run-config':configs[e['run_id']]=r
            if stream in rows:rows[stream][e['line']]=dict(run=e['run_id'],row=r,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert h.hexdigest()==entry['output_sha256'] and dict(seen)=={k:v for k,v in entry['counts'].items() if v}
    count=sum(seen.values());assert next(x for x in raw_receipts if x['stream']==stream)['verified_rows']==count;counts[stream]=count
assert sum(counts.values())==6995 and len(runs)==len(configs)==6
source=load(s/'source-readback.json');live=source['live_read_head'];assert source['base']==report['base'] and len(source['leaves'])==14 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==live
for item in source['leaves']:
    a=git('show',report['base']+':'+item['path']);z=git('show',live+':'+item['path'])
    assert sha(a)==item['base_sha256'] and sha(z)==item['live_sha256'] and (a==z)==item['equal'] and (root/'.worktrees/live'/item['path']).read_bytes()==z
    assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['equal'] for x in source['leaves'])==13
for item in source['ancestry']:
    assert item['base_ancestor'] and item['live_ancestor'];git('merge-base','--is-ancestor',item['commit'],report['base']);git('merge-base','--is-ancestor',item['commit'],live)
receipts=load(s/'offline-audit-receipts.json');summaries=load(s/'offline-summary.json');assert len(receipts)==6
totals=collections.Counter();excluded=[]
for item in receipts:
    run=item['run'];assert item['exit_code']==0
    for suffix,key in [('audit-input.json','input_sha256'),('audit-output.json','output_sha256'),('audit-stderr.txt','stderr_sha256')]:assert sha((s/(run+'.'+suffix)).read_bytes())==item[key]
    data=load(s/(run+'.audit-input.json'));audit=load(s/(run+'.audit-output.json'));assert data['run']==runs[run] and (s/(run+'.audit-stderr.txt')).read_bytes()==b''
    removed=load(s/(run+'.excluded-metadata.json'));excluded.extend(dict(run=run,line=x['line'],sha256=x['sha256']) for x in removed)
    for entry in removed:assert rows['decisions'][entry['line']]['row']==entry['row'] and not entry['row'].get('decision_id')
    for stream in rows:
        selected={line:x for line,x in rows[stream].items() if x['run']==run and (stream!='decisions' or x['row'].get('decision_id'))}
        assert {x['_line'] for x in data[stream]}==set(selected)
        for row in data[stream]:
            original=selected[row['_line']];expected={**original['row'],'_line':row['_line'],'_source_sha256':original['sha256']}
            if stream=='decisions':expected.pop('agent_view',None)
            assert row==expected
    assert all(x['actual_full_candidate_result'] is None for x in audit['segments'])
    actions=audit['observed_actions'];turns=collections.Counter(x['status'] for x in audit['observed_turns']);intervals=collections.Counter((x.get('observed_interval') or {}).get('status','null') for x in actions);terminal=collections.Counter((x.get('terminal_observation') or {}).get('status','null') for x in actions)
    summary=next(x for x in summaries if x['run']==run);assert summary['segments']==len(audit['segments']) and summary['actions']==len(actions) and summary['turns']==turns and summary['intervals']==intervals and summary['terminal']==terminal and summary['whole_candidate_certifications']==0
    totals.update(segments=len(audit['segments']),actions=len(actions),turn_windows=len(audit['observed_turns']),known=turns['observed_turn_endpoints'],unknown=turns['unknown'],intervals=intervals['observed_endpoints'],terminal=terminal['observed_terminal_endpoints'])
assert totals==dict(segments=476,actions=3301,turn_windows=534,known=121,unknown=413,intervals=859,terminal=4) and len(excluded)==5
for item in load(s/'artifact-inventory.json'):
    f=s/item['path'];raw=f.read_bytes();assert f.is_relative_to(s) and len(raw)==item['bytes'] and sha(raw)==item['sha256']
trace=load(s/'ledger-verification.json');owned=trace['own_rows'];prefix=load(s/'ledger-prefix-before.json');inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()]
assert trace['cli_exit_code']==0 and trace['prefix_unchanged'] and trace['private_fold_nontrace_fields_unchanged'] and trace['old_history_notes_where_preserved'] and not trace['status_changes'] and not trace['evidence_added'] and len(owned)==len(inputs)==trace['own_rows_count']==26
assert (s/'ledger-cli.exit.txt').read_text().strip()=='0' and (s/'ledger-cli.stderr.txt').read_bytes()==b'' and set((s/'ledger-cli.stdout.txt').read_text().split())=={x['id'] for x in inputs}
raw_owned=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(prefix['bytes']))==prefix['sha256']
    for item in owned:
        handle.seek(item['offset']);raw=handle.read(item['bytes']);row=json.loads(raw)
        assert sha(raw)==item['sha256'] and row==item['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs);raw_owned.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(raw_owned))==26 and not set(x.rstrip(b'\n') for x in raw_owned)&set(old.splitlines());added=b''.join(raw_owned)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_gate=b['no_change_proposals'],native=native,final=final,stream_counts=counts,original_rows_verified=6995,material_assertions=39,original_proposals=originals,source=source,offline_receipts=receipts,consumer_counts=dict(totals),excluded_original_metadata=excluded,owned_trace_rows=owned,protected_old_fields_and_prefixes_preserved=True,limits=['Material checks and bounded offline receipts are not production tests, whole candidate execution, controlled strategy benefit or natural consumer certification.','Historical dirty knowledge bytes are not reconstructed; current source ancestry does not close the ten broad proposals.','CA46 unknown windows remain unknown. Death loss capped5 differs from displayed deficit15; enemy end-turn24 differs from whole-turn36.','Original case/null-combat/path/output-truncation probes retained; no new gameplay contradiction or other role acknowledgment.','No source, merge blockage, release, production test, simulation rerun, paper refresh, dispatch or game restart. Wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0543原052701策略done0/no-source核收，94dc干净工作树/HEAD不变，十waiting原理由/testsnull/mergednull保持，无提交或合入受阻。六Silent A10八流6995原行逐offset/bytes/SHA/JSON/显式身份核，39原材料断言首次通过；六原有界离线input/output/stderr及原行去decisions.agent_view/加真实_line与_source_sha256投影核，476题段/3301动作/534轮窗（121可核413未知）、859相邻端点/4终态端点，整候选全null。五无decision_id路线元数据原件分列，不补号或跨缺口拼连续性；CA46轮窗unknown不补0，死亡截顶5/显示差15、末动作敌扣24/整轮36分窗。14相关源码13同1历史Roy/Dai注释差、八实际base/live来源祖先核；既有升级传播不再沿用完全未传播费用旧理由，actual_cast_this_fight/actual_turn仍null，完整联合输入及消费者未校准，窄实现不关闭十宽项。26所属CLI原物理前缀/offset/SHA与私有fold核，只where/note追溯，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI/support/repeat。原大小写/null-combat/路径探针/输出截断保留，不当产品或游戏反证；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核。仅本人记录/26追溯提交，保并行记录，无源码/合入/发号/补测/论文刷新/复派/重启局或账号home模型权限prompt变更，不关闭宽父。证据paper/materials/20261016-0543-ops/。\n'
note=f'\n- {at} [运维 codex] 原052701策略十项均waiting，无源码修改或合入阻塞；6995原行、39原材料断言、六有界离线及26条所属追溯核收，完整候选/自然收益不冒认。仅记录提交，宽父/未知保持，无新发布或补测。回执paper/materials/20261016-0543-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=26,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=6995,owned_trace_rows=26,ledger_check=0,paths=len(entries))))

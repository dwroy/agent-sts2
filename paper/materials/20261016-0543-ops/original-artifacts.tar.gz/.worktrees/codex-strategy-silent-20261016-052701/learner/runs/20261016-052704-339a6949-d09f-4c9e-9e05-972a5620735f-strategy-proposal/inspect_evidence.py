import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
RUNS = json.loads((ROOT / 'dispatch.json').read_text())['runs']
FLOORS = {
    'VLZ6CCT8AQ0A': {35, 43, 45},
    '8JRE1C4H4Z2W': {17, 33},
    'CA5KE8GFJ9X2': {13},
    '5PM6JAQG6FNQ': {33, 39},
    '61E2QS63Y9WU': {17, 23},
    'DUZUBAJ3A8GP': {30},
}


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = {}
    fp = fp if isinstance(fp, dict) else {}
    keys = {v for v in [row.get('run_id'), row.get('run'), state.get('run_id'), fp.get('run')]
            if isinstance(v, str) and v and v != 'run_unknown'}
    assert len(keys) == 1, keys
    return next(iter(keys))


def powers(items):
    return {x.get('power_id'): x.get('amount') for x in items or []}


def compact_state(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'sha256': item['sha256'],
        'observed_ts': row.get('observed_ts'), 'screen': state.get('screen'),
        'floor': run.get('floor'), 'turn': state.get('turn'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player.get('powers')),
        'potions': run.get('potions'),
        'hand': [{k: c.get(k) for k in ['index', 'card_id', 'energy_cost', 'upgraded', 'dynamic_values']}
                 for c in combat.get('hand') or []],
        'enemies': [{**{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id', 'intents']},
                     'powers': powers(e.get('powers'))} for e in combat.get('enemies') or []],
        'deck_upgraded': sum(c.get('upgraded') is True for c in run.get('deck') or []),
    }


manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
data = {}
verification = []
for stream in manifest:
    name = stream['stream']
    path = EVIDENCE / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    groups = {run: [] for run in RUNS}
    source_path = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
    count = 0
    with source_path.open('rb') as source, path.open() as selected:
        for line in selected:
            item = json.loads(line)
            assert item['source'] == str(source_path)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert identity(item['row']) == item['run_id']
            groups[item['run_id']].append(item)
            count += 1
    assert {k: len(v) for k, v in groups.items()} == stream['counts']
    verification.append({'stream': name, 'verified_rows': count, 'source_size': stream['source_size'],
                         'output_sha256': stream['output_sha256'], 'counts': stream['counts']})
    data[name] = groups
write('raw-verification.json', verification)

summaries = {}
for run_id in RUNS:
    runs = data['runs'][run_id]
    assert len(runs) == 1
    run = runs[0]['row']
    assert run['character'].lower() == 'silent' and run['ascension'] == 10
    states = data['states'][run_id]
    decisions = data['decisions'][run_id]
    chosen_states = [compact_state(x) for x in states
                     if (x['row']['state'].get('run') or {}).get('floor') in FLOORS[run_id]]
    write(run_id + '.frames.json', chosen_states)
    missing = [x for x in decisions if not x['row'].get('decision_id')]
    accepted = [x for x in decisions if x['row'].get('decision_id')]
    input_data = {
        'run': run,
        'decisions': [{**{k: v for k, v in x['row'].items() if k != 'agent_view'},
                       '_line': x['line'], '_source_sha256': x['sha256']} for x in accepted],
        'states': [{**x['row'], '_line': x['line'], '_source_sha256': x['sha256']} for x in states],
    }
    write(run_id + '.audit-input.json', input_data)
    write(run_id + '.excluded-metadata.json', missing)
    key_decisions = []
    for x in decisions:
        row = x['row']
        if row.get('floor') not in FLOORS[run_id]:
            continue
        if not (str(row.get('label', '')).startswith('combat/plan-choice') or row.get('sl_explore')
                or row.get('hp_guard') or (row.get('chosen') or {}).get('action') == 'use_potion'):
            continue
        key_decisions.append({'line': x['line'], 'sha256': x['sha256'], **{
            k: row.get(k) for k in ['decision_id', 'observed_ts', 'floor', 'turn', 'sl_attempt', 'sl_reloads',
                'label', 'fingerprint', 'answers', 'chosen', 'result', 'hp_guard', 'sl_explore',
                'selection_audit', 'journal', 'rationale', 'questions']}})
    write(run_id + '.key-decisions.json', key_decisions)
    summaries[run_id] = {'run': run, 'stream_rows': {k: len(v[run_id]) for k, v in data.items()},
                         'excluded_decisions': [{'line': x['line'], 'reason': 'no decision_id',
                                                 'label': x['row'].get('label')} for x in missing],
                         'audit_decisions': len(accepted)}
write('run-summary.json', summaries)
print(json.dumps({'streams': len(verification), 'verified_rows': sum(x['verified_rows'] for x in verification),
                  'runs': {r: {'rows': d['stream_rows'], 'audit_decisions': d['audit_decisions'],
                               'excluded': d['excluded_decisions']} for r, d in summaries.items()}}, ensure_ascii=False))

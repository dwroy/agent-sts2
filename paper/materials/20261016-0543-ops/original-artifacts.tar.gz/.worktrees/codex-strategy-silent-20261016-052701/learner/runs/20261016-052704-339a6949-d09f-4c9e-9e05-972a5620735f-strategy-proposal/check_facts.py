import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []


def load(name):
    return json.loads((ROOT / name).read_text())


def check(name, actual, expected, references):
    checks.append({'name': name, 'actual': actual, 'expected': expected,
                   'references': references, 'passed': actual == expected})
    assert actual == expected, (name, actual, expected)


def frames(run):
    return {x['line']: x for x in load(run + '.frames.json')}


def decisions(run):
    return {x['_line']: x for x in load(run + '.audit-input.json')['decisions']}


def criteria(row, key):
    value = row['questions']['plan']['criteria'][key]
    return json.loads(value) if isinstance(value, str) else value


def enemy(frame, key):
    return next(x for x in frame['enemies'] if x['enemy_id'] == key)


def card(frame, key):
    return next(x for x in frame['hand'] if x['card_id'] == key)


def value(frame, key, name):
    return next(x['current_value'] for x in card(frame, key)['dynamic_values'] if x['name'] == name)


run = 'VLZ6CCT8AQ0A'
f = frames(run)
d = decisions(run)
check('神化实耗2能', [f[275564]['energy'], f[275565]['energy']], [7, 5], [run, 'states:275564-275565'])
for key, name, expected in [('DEFEND_SILENT', 'Block', [5, 8]), ('STRIKE_SILENT', 'Damage', [7, 10]),
                             ('DAGGER_SPRAY', 'Damage', [5, 7])]:
    check(key + '实见升级', [value(f[275564], key, name), value(f[275565], key, name)], expected,
          [run, 'states:275564-275565'])
check('必备工具实费传播', [card(f[275564], 'TOOLS_OF_THE_TRADE')['energy_cost'],
                            card(f[275565], 'TOOLS_OF_THE_TRADE')['energy_cost']], [1, 0], [run, 'states:275564-275565'])
check('战内升级不改场外deck计数', [f[n]['deck_upgraded'] for n in [275564, 275565, 275679, 275687]],
      [1, 1, 4, 4], [run, 'states:275564,275565,275679,275687'])
check('神化后同序预测变化', [[criteria(d[n], 'plan1')[k] for k in ['hp_lost', 'damage_dealt']]
                              for n in [269706, 269707]], [[14, 43], [13, 51]], [run, 'decisions:269706-269707'])
check('F43当轮实际端点', [f[275679]['hp'] - f[275687]['hp'],
                             enemy(f[275679], 'SOUL_NEXUS')['current_hp'] - enemy(f[275687], 'SOUL_NEXUS')['current_hp']],
      [13, 51], [run, 'states:275679-275687'])
check('F43升级勒紧实际建立', f[275687]['powers']['FASTEN_POWER'], 6, [run, 'states:275687'])
check('药水实际加能而未回血', [[f[n]['hp'], f[n]['energy']] for n in [275728, 275729]],
      [[67, 1], [67, 2]], [run, 'states:275728-275729'])
check('不同药水题不是同起点', d[269748]['fingerprint'] == d[269754]['fingerprint'], False,
      [run, 'decisions:269748,269754'])
check('全败候选当轮血伤仍不同', [[criteria(d[269770], k)[v] for v in ['hp_lost', 'damage_dealt']]
                                   for k in ['plan1', 'plan2']], [[13, 24], [31, 32]], [run, 'decisions:269770'])
check('三骑士末轮显示来袭', sum(i['total_damage'] or 0 for e in f[275754]['enemies'] for i in e['intents']),
      59, [run, 'states:275754'])
check('三骑士血挡与死亡截断分列', [f[275754]['hp'], f[275754]['block'], f[275755]['hp']],
      [32, 20, 0], [run, 'states:275754-275755'])
check('三骑士结算后全部存活', sorted(e['current_hp'] for e in f[275755]['enemies']), [21, 77, 80],
      [run, 'states:275755'])

run = '8JRE1C4H4Z2W'
d = decisions(run)
audit = load(run + '.audit-output.json')
check('首三试T2指纹相同', d[270216]['fingerprint'] == d[270282]['fingerprint'], True,
      [run, 'decisions:270216,270282'])
check('同指纹不代表样本相同', ['(8 samples)' in criteria(d[270216], 'plan1')['rollout'],
                                 '(24 samples)' in criteria(d[270282], 'plan1')['rollout']], [True, True],
      [run, 'decisions:270216,270282'])
check('第三试SL原替死亡数不并列', ['dead 0/24' in d[270282]['sl_explore']['numbers']['original'],
                                    'dead 5/24' in d[270282]['sl_explore']['numbers']['replacement']], [True, True],
      [run, 'decisions:270282'])
turns = [next(t for t in audit['observed_turns'] if t['floor'] == 33 and t['turn'] == 2 and t['attempt'] == a)
         for a in [1, 3]]
check('同盘SL两轮实付净值', [[t['facts']['player_hp_delta'], t['facts']['enemy_hp_changes'][0]['hp_delta']]
                               for t in turns], [[-3, -10], [-15, -17]], [run, 'observed_turns:F33T2A1,A3'])
check('护栏实际轮端点', [[t['facts']['player_hp_delta'], t['facts']['enemy_hp_changes'][0]['hp_delta']]
                         for t in audit['observed_turns'] if t['floor'] == 33 and t['turn'] == 5 and t['attempt'] == 2],
      [[-4, -25]], [run, 'observed_turns:F33T5A2'])
terminal = next(x['terminal_observation']['facts'] for x in audit['observed_actions']
                if (x.get('terminal_observation') or {}).get('status') == 'observed_terminal_endpoints')
check('末动作与整轮输出分开', [terminal['player_hp_delta'], terminal['enemy_hp_changes'][0]['hp_delta'],
                                 terminal['displayed_attack_reference']['attack_minus_block'], terminal['actual_uncapped_damage']],
      [-5, -24, 15, None], [run, 'decisions:270441-270442', 'states:276433-276434'])

run = 'CA5KE8GFJ9X2'
f = frames(run)
check('蚌加压后力量独立成长', [enemy(f[n], 'SEWER_CLAM')['powers'].get('STRENGTH_POWER') for n in [273239, 273253, 273264]],
      [None, 4, 8], [run, 'states:273239,273253,273264'])
check('蚌无弱同招意图增长', [enemy(f[n], 'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273239, 273253, 273264]],
      [11, 15, 19], [run, 'states:273239,273253,273264'])
check('蚌弱不取消成长', [enemy(f[n], 'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273257, 273268]],
      [11, 14], [run, 'states:273257,273268'])
check('蚌末轮实血挡', [f[273268]['hp'], f[273268]['block']], [2, 10], [run, 'states:273268'])

run = '5PM6JAQG6FNQ'
f = frames(run)
check('未启毒冒泡实耗能', [f[n]['energy'] for n in [274379, 274380]], [5, 4], [run, 'states:274379-274380'])
check('未启毒冒泡敌方帧未改变', f[274379]['enemies'], f[274380]['enemies'], [run, 'states:274379-274380'])
check('末试尚无已建毒雾', 'NOXIOUS_FUMES_POWER' in f[274379]['powers'], False, [run, 'states:274379'])
check('同局已建组件的胜战反例', {k: f[274227]['powers'].get(k) for k in ['NOXIOUS_FUMES_POWER', 'ACCELERANT_POWER', 'SERPENT_FORM_POWER']},
      {'NOXIOUS_FUMES_POWER': 3, 'ACCELERANT_POWER': 1, 'SERPENT_FORM_POWER': 4}, [run, 'states:274227'])

run = '61E2QS63Y9WU'
f = frames(run)
check('吸取后属性逐源', [f[273502]['powers'].get('STRENGTH_POWER'), f[273504]['powers'].get('STRENGTH_POWER'),
                             f[273504]['powers'].get('DEXTERITY_POWER'), enemy(f[273504], 'LAGAVULIN_MATRIARCH')['powers']['STRENGTH_POWER']],
      [2, None, -2, 2], [run, 'states:273502,273504'])
check('负敏捷两防御各3', [f[n]['block'] for n in [273504, 273505, 273507]], [0, 3, 6], [run, 'states:273504,273505,273507'])
check('毒17与16实际净扣33', enemy(f[273504], 'LAGAVULIN_MATRIARCH')['current_hp'] - enemy(f[273508], 'LAGAVULIN_MATRIARCH')['current_hp'],
      33, [run, 'states:273504-273508'])
check('胧光主体与幻象净扣分开', [enemy(f[273593], 'THE_OBSCURA')['current_hp'] - enemy(f[273596], 'THE_OBSCURA')['current_hp'],
                                     enemy(f[273593], 'PARAFRIGHT')['current_hp'] - enemy(f[273596], 'PARAFRIGHT')['current_hp']],
      [35, 12], [run, 'states:273593-273596'])
check('航行成长与仍存幻象', [enemy(f[273596], 'THE_OBSCURA')['powers']['STRENGTH_POWER'],
                              enemy(f[273596], 'PARAFRIGHT')['powers']['STRENGTH_POWER'], enemy(f[273596], 'PARAFRIGHT')['current_hp']],
      [6, 6, 2], [run, 'states:273596'])

run = 'DUZUBAJ3A8GP'
f = frames(run)
check('末试睡层依次下降', [enemy(f[n], 'SLUMBERING_BEETLE')['powers'].get('SLUMBER_POWER') for n in [274993, 274998, 275003, 275007]],
      [3, 2, 1, None], [run, 'states:274993,274998,275003,275007'])
check('末试临减后恢复且成长', [enemy(f[n], 'SLUMBERING_BEETLE')['powers'].get('STRENGTH_POWER') for n in [275013, 275017, 275018]],
      [2, -4, 4], [run, 'states:275013,275017,275018'])
check('末试结尾血挡与来袭', [f[275022]['hp'], f[275022]['block'], enemy(f[275022], 'SLUMBERING_BEETLE')['intents'][0]['total_damage']],
      [1, 16, 22], [run, 'states:275022'])

summary = load('offline-summary.json')
check('离线候选完整执行认证仍为零', sum(x['whole_candidate_certifications'] for x in summary), 0, ['六份审计输出'])
check('整轮观察不冒完整候选', [sum(x['turns'].get('observed_turn_endpoints', 0) for x in summary),
                               sum(x['turns'].get('unknown', 0) for x in summary)], [121, 413], ['六份审计输出'])
(ROOT / 'fact-checks.json').write_text(json.dumps({'checks': checks, 'count': len(checks), 'all_passed': True,
    'scope': '只核材料断言，不是tsc、vitest、策略收益或生产消费者验收'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_assertions': len(checks), 'all_passed': True}, ensure_ascii=False))

# 本批十项策略提案核验

批次：20261016-052701-strategy-proposal；角色：silent；基线：94dc14d3046fb899b8027a40b82bb9fda5464062。

本批仅处理已领取的十个ID。原文及其SHA不变，不新增重复ID。所有处置为waiting；未改源码、知识、策略参数或其他角色行为。完整身份、原始证据核验、消费者输入输出与限制见同目录report.md。

## silent-proposal-89354805ee4d7e77

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256：ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0237, silent-0238。

证据：VLZ6CCT8AQ0A A10 F35T1 states275564→275565；F43T1 decisions269706→269707、states275679→275687；F45T1 states275722→275732。

当前处置：waiting。已核现有神化已观测牌升级传播；actual_cast_this_fight仍为null，缺跨重规划的实际施放归属及未覆盖属性/未知后续抽牌交互校准，不能把窄实现报整项duplicate。

反例与边界：F43施放且获胜仍净损57；F45持有但未施放。不同战斗和资源不能推出神化必打或整战因果。

既有/预期行为：继续按已实见牌对传播升级，实际施放、候选包含、模型覆盖分别记录；未知交互留空，不添加必打规则。

验证方法及仍需输入：冻结同一战斗的施放请求/完成回执、重规划边界与后续抽牌；逐项核实际建立，不能由持有或候选模拟字段回填施放历史。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-f2bfceddb1898dca

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256：fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0106, silent-0019, silent-0201。

证据：VLZ6CCT8AQ0A A10 F45T1 decisions269748/269754及states275728→275729，F45T4 decisions269770，F45T5 states275754→275755；silent-0106/0019/0201。

当前处置：waiting。VLZ F45两药水题指纹不同，缺同盘同随机池同总预算的MC配对及候选稳定性曲线；707毫秒、1/12与12/12不能确定预算、留药、血价或杀序阈值。

反例与边界：F45T4低损候选13损24伤，高伤候选31损32伤且8/8预测死；未实打高伤线，不能把少8伤认作败因。

既有/预期行为：保留预算不足与模拟样本成熟度提示，分列药水真实抽牌/能量、各敌HP与完整生存缺口；保留当前预算与全部目标选项。

验证方法及仍需输入：冻结起始盘面、候选、种子、同一预算及完整知识输入，比较现有和分阶段MC方案的成熟样本与排名；新独立完局后移验证。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-283a164780d11e69

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256：78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0237, silent-0238。

证据：VLZ6CCT8AQ0A A10 F35T1/F43T1/F45T1；账本silent-0237/0238；经验silent-apotheosis-combat-upgrades。

当前处置：waiting。与89354805ee4d7e77是同源神化机制的经验链接；已有传播不等于实际施放归属和全部交互已校准，不能凭同源pending或局部源码关闭此ID。

反例与边界：升级后的同序数值可核，但F35出牌后重规划和目标也变化，37→52伤不能全归神化。

既有/预期行为：沿同源实现及账本去重，不另建提案ID；保留经验、原提案与本批报告链接。

验证方法及仍需输入：复用893原提案的固定帧，但分别核此ID的经验来源和实际live祖先；未解决的归属/覆盖保持waiting。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-ebbfe3b97548756d

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256：08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。

证据：VLZ6CCT8AQ0A A10 F43T1—T5/F45T1—T5；states275687的勒紧6、275754的勒紧4/敏3/20挡/59显示攻击与275755三敌21/80/77；原十四个账本ID保留。

当前处置：waiting。本批复核了升级、勒紧、毒、临时减力和末轮血挡子项；缺原十五经验的全部组合、状态期限及战斗/路线/休息消费者冻结联合校准，局部吻合不足关闭复合项。

反例与边界：F45末轮32血、20挡仍败；毒结算后无敌退场。已成立的局部机制不等于安全血线、固定目标或整战收益。

既有/预期行为：各增益、毒触发、覆甲当前层数与资源分别核验；发现明确子模型差额才单独修，不用固定分覆盖实际状态。

验证方法及仍需输入：建立原十五条经验逐项输入/属性/期限/消费者矩阵，保留胜战与火房资源链；当前仅子项材料核验，不把经验历史支持数当校准分母。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-e5b87be50f28f311

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256：5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。

来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0079, silent-0021, silent-0125, silent-0018。

证据：8JRE1C4H4Z2W A10 F33首/三试T2 decisions270216/270282同指纹，实际轮端点损3/15、扣10/17；第二试T5损4扣25；末试T11 decisions270441→270442。账本silent-0079/0021/0125/0018。

当前处置：waiting。已有原答/护栏/SL阶段与离线轮端点审计；在线actual_turn仍null，离线完整候选认证为零，缺跨重规划持续候选身份与成长逐源归属，不能由净端点倒填因果或改SL血价。

反例与边界：首试题为8样本、第三试24样本；第三试原/替0/24与5/24不同。末试延至T11仍死，不能认定一律保血或一律攻击正确。

既有/预期行为：保留原答、护栏、SL与实际动作链，候选预测/完整执行/整轮观察分列；抽牌或重问结束原候选认证。

验证方法及仍需输入：冻结每个候选的动作身份与重规划终止边界，完整逐源记录能力建立及敌实体变化。T11显示缺口15、实扣5、末动作毒扣24和整轮扣36必须分列。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-49632bc4878fb597

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256：aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0005, silent-0231。

证据：CA5KE8GFJ9X2 A10 F13T1—T5 states273239/273253/273257/273264/273268；末轮2血10挡对14攻击。账本silent-0005/0231。

当前处置：waiting。CA5可核加压后力量4/8、喷水15/19与弱后11/14；关键战未出现正敏捷，缺力、正负敏捷、虚弱与独立成长的联合冻结生产校准，不能借步法子实现补全。

反例与边界：虚弱没有取消第二次加压；计划中的步法不能补作实际取得或已建立的正敏捷。

既有/预期行为：力量、敏捷、逐击修正、虚弱与成长分项核算；不新增统一保血/输出权重。

验证方法及仍需输入：保存相同生产调用中四路径的原始属性、意图、出牌及后继，区分单公式正确与联合组合已验证；等待实际缺失组合样本。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-66532328a585941f

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256：56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0021, silent-0009。

证据：5PM6JAQG6FNQ A10 F39第二试T2 decisions268455→268456、states274379→274380；F33T8 states274227—274229已有雾3/触媒1/群蛇4且获胜。账本silent-0021/0009。

当前处置：waiting。末试F39T2冒泡对无毒目标实耗1能且敌方帧不变，但缺同起始资源、完整同抽序下启动顺序的受控整战对照和可复现收益函数，不能拟合启动优先级。

反例与边界：同局F33已建立组件并赢，F39两试的能力、抽序和生存资源不同；空打不等于构筑必输或某启动顺序必胜。

既有/预期行为：持有、计划、实际建立和可结算输出分别记录；维持现有启动权重。

验证方法及仍需输入：冻结同一起点、完整抽序和后续敌人动作，对比启动顺序；按run分组并用独立新局后移验证，SL尝试不扩分母。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-43a76a31ba7bdcfa

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256：f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0030, silent-0027。

证据：61E2QS63Y9WU A10 F17T5—T7 states273502/273504—273510；吸取前力2，后不再列力、敏−2、敌力2，60进战48血胜。账本silent-0030/0027。

当前处置：waiting。61E首试吸取、负敏捷两防御各3及17+16毒扣33可核；缺同起始HP/构筑/完整抽序的SL整战配对和未选路线后继，首试胜利不能确定SL范围或换线偏好。

反例与边界：本战首试胜利，无本批可核的另一条SL整战赢线；不能把不同历史局的换线结果作为同盘反事实。

既有/预期行为：吸取、负敏捷、毒实际结算分别核验；保留现有SL范围及换线规则。

验证方法及仍需输入：冻结同一初始资源与完整抽序，复验两完整线路和当前进阶敌模型；不由单帧毒伤推出长期路线收益。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-5264153a4a4b0e5c

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256：b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0039, silent-0209。

证据：61E2QS63Y9WU A10 F23T4—T5 states273593→273596、273600；主体76→41，幻象14→2，玩家25→10。账本silent-0039/0209。

当前处置：waiting。61E F23T4各实体力3→6、幻象余2与主体/幻象净扣35/12可核；缺召唤、退场、再现与实体代际全链联合调用校准及另一目标序完整后继，不能规定首杀。

反例与边界：47是这轮主体与幻象合计净扣35+12，不是主体净扣；focus幻象39伤零损只为未执行候选。类型ID也不证明跨召唤物理身份。

既有/预期行为：逐敌记录HP、成长与真实减员，保留全部目标，相同推演值并列，不设固定首杀。

验证方法及仍需输入：冻结完整A10召唤脚本与当前输入，验证新增/退场/再现的代际映射和同步成长，再以同盘完整目标顺序后继比较。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

## silent-proposal-bddfa690a84e03d0

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256：b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。

来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0128, silent-0079。

证据：DUZUBAJ3A8GP A10 F30末试T1—T6 states274993/274998/275003/275007/275013/275017/275018/275022；末1血16挡对22。账本silent-0128/0079。

当前处置：waiting。DUZ四试可核睡3/2/1、醒后力2与临减恢复到4/22攻击；缺伤害唤醒/眩晕/进阶成长全链校准及同抽换序完整后继，相关失败不足拟合血价或杀序。

反例与边界：末试T4相对首试多扣3敌血也多损2玩家血；四次同局失败并非四个独立构筑样本。

既有/预期行为：按当前进阶分别核睡眠、眩晕、当轮减力和后轮成长，不增加固定杀序或全死候选输出权重。

验证方法及仍需输入：冻结睡眠到唤醒/眩晕/恢复的完整状态链、抽序和敌模型；保留死亡截断的未知完整入伤，独立新局再验泛化。

拟合与切分：本批仅复核原发现样本，不拟合新权重或阈值，不称盲测；后移验证须按独立run_id与进阶分组，不能以SL次数扩样本。

回退：本批无源码改动可回退。未来实现须撤生产源码时固定夹具失败、恢复通过，并按原任务运行沙箱检查及实际live流程；原证据、失败和账本历史始终保留。

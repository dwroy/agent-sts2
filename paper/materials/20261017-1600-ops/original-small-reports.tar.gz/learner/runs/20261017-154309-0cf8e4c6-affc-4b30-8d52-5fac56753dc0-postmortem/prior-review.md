# 同角色更早记录的核对

按ledger.py find --character silent检索组装师、FABRICATOR、结实绷带、群蛇、领主阳伞、兑现、路线、镣铐、SHACKLING与高电压，筛选原件保留本目录ledger-search-*.json。复盘仅使用silent标题小节，未引用铁甲打法。

- silent-0020：C48LLXBGKXQ9及后来的54G5683J0E5S资源链，已记恢复缓冲不能保证下一战和未来商店不可预支；本局是support，没有相同选择的受控反事实，非repeat。
- silent-0385：首证4Y94N8RDPGPM、prior=partly，有限可活窗口的能力到手/建立/收益分账。核对其更早静默小节，本次保留首证与prior。
- silent-0418：首证MTQ0EUBJ3R6T、prior=partly，候选/护栏/SL/生成后重问与真实动作分段；本局既有selection_audit能记录SL替换，不新判bug。
- silent-0194：实际弃一张补3挡的旧机制，本局两弃6挡条件支持。
- silent-0348：活体组装师召唤旧机制，本局补20血守护/23血电击/21血戳刺的实例观察，不规定分布。
- 高电压已有silent-0233，临时敏捷已有silent-0080，药水临时力已有silent-0330及手里剑/折扇旧记录；镣铐药水7减力已见更早3UPY3BP2LVS7复盘（仪式兽2→−5），临时恢复也有相关旧减力观察。本局不据另一怪的虚弱取整去解释未虚弱状态，不新建重复机制条目。

本任务没有新机制反证或科学异议；实际药效、SL恢复、净HP与总伤害的限定均在复盘明示。不改任何旧claim、首证、prior、状态或版本。

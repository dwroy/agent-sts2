import json,collections,datetime,re
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()];R=json.load((p/'2PQK67ULZY90-resources.json').open())
def j(x):return json.dumps(x,ensure_ascii=False)
def alive(s):return [(e['name'],e['enemy_id'],e['current_hp'],e.get('block'),e.get('powers'),e.get('intents')) for e in (s.get('combat')or{}).get('enemies',[]) if e['is_alive']]
def dt(t):return datetime.datetime.fromisoformat(t.replace('Z','+00:00'))
with (p/'compact.txt').open('w') as f:
 def pr(*v):print(*v,file=f)
 Q=[d for d in D if d['decider']=='jev' and d['label'].startswith('combat/plan-choice')]
 pr('STATS',len(Q),collections.Counter(d.get('rollout_best_chosen') for d in Q),'rank1',sum(bool(re.search(r'code rank 1(?:\D|$)',d['rationale'])) for d in Q),'low',sum(d['decider']=='jev' and isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35 for d in D))
 foc=[]
 for d in Q:
  q=d.get('questions') or {};ans=d.get('answers') or {}
  if 'focus' in q:foc.append({'floor':d['floor'],'turn':d['turn'],'answer':ans.get('focus'),'options':q['focus'].get('options')})
 pr('FOCUS',j(foc))
 groups=collections.defaultdict(list)
 for d in D:
  if d['label'].startswith('combat/') or d['label'].startswith('selection/') and d.get('turn') is not None:groups[(d['floor'],d.get('sl_attempt') or 1,d['turn'])].append(d)
 own=[k for k,v in groups.items() if any(x['decider']=='code' and x['label'].startswith('combat/') and 'Jev-chosen plan' not in x['rationale'] for x in v)]
 only=[k for k,v in groups.items() if not any(x['decider']=='jev' or 'Jev-chosen plan' in x['rationale'] for x in v)]
 pr('CODE_TURNS',len(groups),len(own),len(only),'actions',sum(x['decider']=='code' and x['label'].startswith('combat/') and 'Jev-chosen plan' not in x['rationale'] for x in D))
 pr('BRAIN_USAGE',len(B),sum(x['usage'].get('inputTokens',0) for x in B),sum(x['usage'].get('outputTokens',0) for x in B),sum(x['usage'].get('cacheHitTokens',0) for x in B),sum(x['latency_ms'] for x in B),collections.Counter(x['accepted'] for x in B))
 pr('JEV_USAGE',j([d['usage'] for d in D if d['decider']=='jev'][:2]))
 pr('TIME_SECONDS',(dt(D[-1]['ts'])-dt(D[0]['ts'])).total_seconds())
 for c in R['combats']:
  frames=[x for x in S if c['entry']['ts']<=x['ts']<=c['last']['ts']];t=collections.OrderedDict()
  for x in frames:
   s=x['state']
   if s.get('in_combat'):t.setdefault(s['turn'],x)
  pr('TURNS',c['sequence'],c['floor'],j([{'t':k,'hp':x['state']['run']['current_hp'],'enemy_hp':sum(e[2] for e in alive(x['state'])),'enemies':[(e[1],e[2]) for e in alive(x['state'])],'offset':x['_source_offset']} for k,x in t.items()]))
  if c['floor'] in [8,33,39,40]:
   pr('ENDSTATE',c['sequence'],j({'hp':frames[-1]['state']['run']['current_hp'],'block':frames[-1]['state']['combat']['player']['block'],'powers':frames[-1]['state']['combat']['player']['powers'],'enemies':alive(frames[-1]['state'])}))
 for a in R['resource_changes']:
  b,e=a['from'],a['to']
  if b['potions']!=e['potions'] or b['hp']<e['hp'] or b['max_hp']!=e['max_hp']:
   pr('RESOURCE',j(a))
 for x in S:
  s=x['state']
  if s['run']['floor']==40 and (s.get('turn')==3 or s.get('turn')==2) and s.get('in_combat') and s['turn'] not in [q[0] for q in []]:
   pass
 print(p/'compact.txt')

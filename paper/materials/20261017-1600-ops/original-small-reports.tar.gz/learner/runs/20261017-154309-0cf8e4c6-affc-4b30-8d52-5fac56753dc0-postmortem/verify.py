import json,hashlib
from pathlib import Path
p=Path(__file__).parent;checked={}
for n in ['decisions','states','brain','run-plans','sl-attempts','run-config']:
 count=0
 with (Path('logs')/(n+'.jsonl')).open('rb') as raw:
  for line in (p/(n+'.jsonl')).open():
   row=json.loads(line);raw.seek(row.pop('_source_offset'));source=json.loads(raw.readline());assert source==row,(n,count);count+=1
 checked[n]=count
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];R=json.load((p/'2PQK67ULZY90-resources.json').open())
assert len(D)==857 and len(S)==887 and len(R['combats'])==23
for c in R['combats']:
 for endpoint in ['entry','last','exit']:
  e=c[endpoint]
  if e is None:continue
  matches=[x for x in S if x['ts']==e['ts'] and x['state']['run']['floor']==e['floor'] and x['state']['turn']==e['turn']]
  assert any(x['state']['run']['current_hp']==e['hp'] and x['state']['run']['max_hp']==e['max_hp'] and sorted([[z['index'],z['potion_id']] for z in x['state']['run']['potions'] if z['occupied']])==sorted(e['potions']) for x in matches),(c['sequence'],endpoint)
assert R['combats'][-1]['entry']['hp']==5 and R['combats'][-1]['exit']['hp']==0
assert D[852]['turn']==3 and '(-22)' in D[852]['rationale']
assert 'hp -4' in D[96]['rationale']
assert (S[-1]['state']['combat']['enemies'][2]['current_hp'])==88
for x in S:
 s=x['state']
 if s['run']['floor']==40 and s.get('turn')==3 and '2026-10-17T07:26:00Z'<x['ts']<'2026-10-17T07:26:24Z':
  print('thirdT3',x['_source_offset'],s['combat']['player']['block'])
result={'source_readback':checked,'resource_endpoints':'23段逐端点血量/上限/槽位一致','key_numbers':'已核5血进场/14挡/44意图/88本体余血/T3死亡/护栏一次','draft_sha256':hashlib.sha256((p/'lesson-draft.md').read_bytes()).hexdigest()}
(p/'validation-before.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

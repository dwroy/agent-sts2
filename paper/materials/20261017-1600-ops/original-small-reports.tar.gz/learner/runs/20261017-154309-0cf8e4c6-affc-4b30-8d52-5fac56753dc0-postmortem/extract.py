import json
from pathlib import Path
run='2PQK67ULZY90'
out=Path('learner/runs/20261017-154309-0cf8e4c6-affc-4b30-8d52-5fac56753dc0-postmortem')
for name in ['decisions','states','run-plans','brain','sl-attempts','run-config']:
 p=Path('logs')/(name+'.jsonl'); size=p.stat().st_size; start=max(0,size-128*1024*1024); count=0; first=last=None
 with p.open('rb') as f,(out/(name+'.jsonl')).open('w') as dest:
  f.seek(start)
  if start: f.readline()
  while f.tell()<size:
   off=f.tell(); line=f.readline()
   if run.encode() not in line: continue
   try:r=json.loads(line)
   except:continue
   r['_source_offset']=off
   dest.write(json.dumps(r,ensure_ascii=False)+'\n');count+=1
   first=first or r.get('ts');last=r.get('ts')
 print(name, count, first,last,'seek',start,'size',size)

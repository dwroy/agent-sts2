import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];S=[json.loads(x) for x in (p/'states.jsonl').open()];B=[json.loads(x) for x in (p/'brain.jsonl').open()]
def dump(x):return json.dumps(x,ensure_ascii=False)
with (p/'summary.txt').open('w') as f:
 def pr(*x):print(*x,file=f)
 pr('DECIDERS',collections.Counter(d['decider'] for d in D));pr('FIRSTLAST',D[0]['ts'],D[-1]['ts']);pr('JOURNAL_KEYS',[(d['label'],list(d.get('journal',{}))) for d in D if d.get('journal')][:4])
 for d in D:
  if d['decider']=='codex' or d['label'].startswith('map/') and d['decider']!='code':
   pr('BRAIN',d['floor'],d['turn'],d['label'],d['_source_offset'],dump(d.get('chosen')),d['rationale'])
  if 'guard' in dump(d.get('journal',{})).lower() or 'hp guard' in d.get('rationale','').lower():pr('GUARD',d['floor'],d['turn'],d['_source_offset'],d['rationale'],dump(d.get('journal'))[:4500])
 for x in [json.loads(t) for t in (p/'run-plans.jsonl').open()]:
  pr('PLAN',x['floor'],x['_source_offset'],dump(x['plan']))
 for x in [json.loads(t) for t in (p/'sl-attempts.jsonl').open()]:
  pr('SL',dump({k:x.get(k) for k in ['floor','attempt','started_at','ended_at','result','turns','end_hp','end_block','incoming','give_up_reason','judge','reload']}));pr('SL_TURNS',dump((x.get('summary') or {}).get('turns')))
 for x in B:pr('USAGE',x.get('engine'),x.get('label'),dump(x.get('usage')),x.get('latency_ms'),x.get('model'),x.get('effort'))
 for d in D:
  a=(d.get('chosen') or {}).get('action',{})
  if 'potion' in dump(d.get('chosen')).lower() and (isinstance(a,dict) and a.get('type') in ['use_potion','discard_potion']):pr('POTION_ACTION',d['floor'],d['turn'],d['_source_offset'],dump(d.get('chosen')),d['rationale'])
 pr('LASTRELICS',dump(S[-1]['state']['run'].get('relics')))
 pr('LASTDECK',dump([(c['name'],c['card_id'],c.get('upgraded')) for c in S[-1]['state']['run']['deck']]))
print(p/'summary.txt')
print('JOURNAL EXAMPLE',dump(next(d.get('journal') for d in D if d.get('journal')))[:6000])
print('CHOSEN',dump(next(d.get('chosen') for d in D if d['decider']=='jev')))
print('BRAIN_KEYS',list(B[0]));print('BRAIN_USAGE',{k:v for k,v in B[0].items() if k in ['usage','engine','model','effort','latency_ms','label']})

# 本批指定提案复核与待补验证

时间：2026-10-16T01:51:51.559072+08:00。角色：silent；已核范围仅六局A10。batch：20261016-014302-s2-strategy-proposal。
基线：`0a16b254ef91be2e7bab9bfc12a2a92d15f58028`；main合并结果Already up to date。普通消费队列，没有research_request或implementation_request；只处理派发10项。

结论：10项waiting；未改源码、经验库、规则、排序或其他角色。没有新增提案id，也没有实现/duplicate/shipped声明。原始提案逐件SHA吻合，保存为*.original.md。

以下旧行为以当前源码和实际live读回定位；游戏结论只来自本角色原帧。授权不是游戏事实。每个局号/层/回合下的同存档SL均属同一局；不拟合血价系数或新优先级。

## silent-proposal-c20b5139dd0dff71

主题：污染与技能血价。来源任务：experience-update；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；原SHA256：bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。
账本：silent-0168。证据：DUZUBAJ3A8GP F27 T4—T6。
支持：污染0→3→6；能力FASTEN不再加污染；次轮火花6，三技能污染6/12/18，下一轮清空。
反例/限制：技能同时有毒、弱和格挡收益，不能把本轮净损9解释为禁技能的因果依据。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：缺历史dirty运行实际消费的A10完整移动表及毒、弱、挡、污染跨轮的联合消费者回放；现有当轮污染接线未发现新的确定性差异。
预期行为及验证：保持所有技能选项及当前排名；冻结同一手牌、能力、进阶移动表和抽序，逐击核弱/污染/挡，再比较完整替线。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-ae9e692d680e3819

主题：抢夺、返还与实体归属。来源任务：experience-update；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；原SHA256：b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。
账本：silent-0183, silent-0005。证据：5PM6JAQG6FNQ F39 T4—T6。
支持：T4玩家力敏−4/−4；两次步法使敏捷−4→−2→0；失落退场后力量回0，T6敏捷再次−2。
反例/限制：步法恢复敏捷与返还被夺量不能混算；未执行另一杀序，不能规定固定先杀顺序。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：缺逐实体累计被夺量、非抢夺属性来源与死亡返还的完整冻结模型输入；另一杀序后继未执行。
预期行为及验证：保留当前负属性现场；用完整进战到返还的逐动作夹具区分抢夺、步法与返还，并验证实体退场重排。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-52f1e1bd2e7db0ed

主题：蚌加压与首样本进阶事实。来源任务：experience-update；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；原SHA256：651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。
账本：silent-0231。证据：CA5KE8GFJ9X2 F13 T1—T5。
支持：力量0/4/8、喷水11/15/19；轮初覆甲9/9/8/7/6。
反例/限制：这些层数不足以独立隔离所有覆甲减层条件，也不能代替房间损血成本。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：当前进阶首样本HP/攻击读取已存在；缺原dirty运行实际消费的A10移动表字节及覆甲完整减层条件的独立联合输入。
预期行为及验证：保留首样本读取和房间代价5样本门槛；冻结实际输入后核加压、弱和覆甲的完整消费者。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-6dd8bbff876be528

主题：电击成长与新召唤归属。来源任务：experience-update；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；原SHA256：48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。
账本：silent-0233, silent-0209。证据：5PM6JAQG6FNQ F38 T3—T4。
支持：23上限电击连续帧力量2→4、攻击17→19，数组index4→3。
反例/限制：数组重排不是新实体；连续窗口也不能证明后来新同类不会继承旧累计量。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：缺稳定召唤代际、新同类替换与累计量归属的冻结输入；当前growth接线存在，不能据单个连续存活窗口关闭新实体边界。
预期行为及验证：保留当前成长公式；固定同类死亡、再召唤及索引重排负例，核新实体初值与旧实体累计量。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-578e415a259e6835

主题：沙虫护栏、SL与实际执行分账。来源任务：experience-update；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；原SHA256：e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。
账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。证据：8JRE1C4H4Z2W F33 首/三试T2、末试T11。
支持：同指纹原/替轮窗损3/15、敌净扣10/17；末试5血、22挡对37，零血帧敌余130。
反例/限制：多12净损只多7敌净扣；末试零血截断净损5与攻击缺口15不同，端点不是逐来源毛伤。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：原答/护栏/SL快照和单动作回执已有；缺跨抽弃牌、护栏及SL的完整候选执行绑定、逐来源兑现与独立后继联合校准。
预期行为及验证：保持探索和护栏；固定T2/T5/T11及F17重问窗口，按候选生命周期结束点逐段核实际动作。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-c0767768bf6a7ab1

主题：实验体SL同轮资源代价。来源任务：postmortem；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；原SHA256：28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。
账本：silent-0079。证据：YF0LXT1QSTGG F48 第二/三试T1、F33第二试。
支持：同指纹27血起点，原/替轮窗损0/9、敌净扣45/38；第三试确有end_turn；F33第二试SL实胜。
反例/限制：F33成功SL反对全局禁探索；F48第六试恢复防御仍败，当前损血差不能证明整战因果。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：同题预测资源差已有展示；缺未执行续步、完整替代线资源/胜负对照及跨重问归属，不能据多9血少7伤校准SL惩罚。
预期行为及验证：保留原SL规则；核预测、首次派发、重规划截断和完整实际轮窗，独立后移新局验证规则。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-a46bdb7fe711d79a

主题：实验体分阶段毒与能力兑现。来源任务：postmortem；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；原SHA256：eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。
账本：silent-0021, silent-0027, silent-0028, silent-0085。证据：YF0LXT1QSTGG F48 末试T3—T5。
支持：阶段敌血4→212、旧毒4→0、力量清0；T5触媒2而零毒；格挡13→23后敏捷5→6，挡仍23；18血23挡对44。
反例/限制：已建能力仍可失败；不能因第二阶段零毒就宣称提前建能力会赢，不能倒补后来敏捷。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：当前阶段快照和零毒说明已有；缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准，未找到本批新确定性错算。
预期行为及验证：保留原动作排序；逐帧固定能力建立、施毒、结算、阶段清空与后取得敏捷的顺序，连接实际执行消费者。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-1044224808015e5c

主题：双蟹零胜并列SL血价。来源任务：postmortem；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；原SHA256：4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。
账本：silent-0079。证据：XP2SL33HT0D9 F33 首/二试T3、首/末试T1。
支持：T3同指纹原/替轮窗损9/14、敌净扣24/27；T1损2/10、敌净扣25/34，末试建立力量1。
反例/限制：永久成长和后续抽序也变；两组六试来自一局，不能当独立局胜率训练集。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：缺原线与换线的独立完整后继、受控随机池及整战结果；B2零胜并列不足以证明低当轮损失优先的新排序更好。
预期行为及验证：保留现有并列及探索；新排序先同盘同预算离线比较，完整后继与后移局支持后才启用。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-7cbc6005db712ba9

主题：双蟹朝向、临时减力与轮初挡。来源任务：postmortem；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；原SHA256：f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。
账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。证据：XP2SL33HT0D9 F33 末试T2—T5。
支持：T2初挡14，镣铐爪0→−9、次轮回0；补挡至20且零损；T4火箭57→38→28，四敏脆弱下挡6，实损22。
反例/限制：14仅是所列轮初现场，不能当每轮固定挡；朝向、虚弱、临时力分别归因，不以能力启动推出减员。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：已有现场值、局部公式及参考；缺逐候选贡献拆分、完整执行绑定与条件联合校准，局部实现不足以把整项登记duplicate。
预期行为及验证：保持权重和角色边界；固定57/38/28、14+6、0/−9/0和终局逐帧，对照候选与消费者的条件贡献。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## silent-proposal-c59f592f1427a67e

主题：机制、资源与SL综合闭环。来源任务：experience-update；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；原SHA256：81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。
账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。证据：YF0LXT1QSTGG F48；XP2SL33HT0D9 F33；本批其余四锚点。
支持：本批只回核六Silent A10来源、上述局部机制与四组同指纹端点；原提案中的101局分母未重算。
反例/限制：旧历史范围不能冒称本批新验证；SL恢复不算回血；未选路线、休息和留药后继未知。
旧行为与本批决定：保留当前实现及全部选项，不新增排名或阈值。waiting：六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。
预期行为及验证：沿原id接续各子域；用完整已绑定历史输入和独立后移局校准，保留未覆盖及反例，不能以本报告关闭父要求。
发现集为本批已发生局；未来验证必须按独立run_id及时间后移切分，不把同局SL拆成训练/验证。未执行反事实保持未知。
回退：本批无源码需回退。后续实际实现须固定夹具撤源码失败/恢复通过、自测、实际live源码祖先及版本/双通知；不回写原提案。

## 共同材料与边界

证据由本树learner/extract_evidence.py共用入口提取；evidence/evidence-manifest.json保存各流source_size和输出SHA，逐行wrapper保存原source、offset、bytes、SHA及显式run身份。fight-plans该截点选中0行，只说明未选到；不推断原日志或其他流缺失。
material-verification.json逐字节回核8,274行并核列出的材料断言；四组配对仅为同起点实际轮窗净端点，不认证整候选、逐来源毛伤、当前生产校准或整战策略收益。
source-readback.json核实际live祖先及14源码叶；12字节相同，rollout-live.ts/move-model.ts仅所列Roy/Dai历史注释文字差，原差异不覆盖，不冒称转译/完整测试。
旧578提案把silent-vajra-opening-strength关联silent-0016，但该账本原claim为护喉甲覆甲。本报告只记录链接语义不一致，未将0016用作金刚杵机制证明，未改原claim/首证/历史。
本批没有新增已证经验，不扩展历史统计，不修改经验库；已有经验入库/消费者/父要求按原链继续。

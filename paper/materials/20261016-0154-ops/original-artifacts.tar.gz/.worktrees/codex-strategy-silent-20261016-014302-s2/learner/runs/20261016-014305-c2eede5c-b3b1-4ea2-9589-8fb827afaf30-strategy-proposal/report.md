# 本批策略提案消费报告

本批10项均waiting；没有源码、知识、策略或对局行为变更，没有提交和合入，没有新eval版本。不是提交/合入受阻。
完整base：`0a16b254ef91be2e7bab9bfc12a2a92d15f58028`。工作树开工干净，普通任务`git merge --no-edit main`返回Already up to date。HEAD保持基线。

## 身份和输入

根learn.json只保存本批派发行到dispatch.json：task=strategy-proposal、character=silent、reason=proposal、工作树吻合，10个proposal_ids均已处理；没有research_request/implementation_request/proposal_repair。普通专题条件不匹配，未接管其他请求或整条队列。
runs.jsonl六来源均SILENT/A10；run-config六条均dirty=true，不把记录的源码commit当成运行时知识文件的完整快照。历史brain配置Sol6.1/high只作为旧记录保存，不据此声称当前学习者原生请求身份已独立核实；本批没有改运行模型、强度或权限。
已读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol和learning-code-proposals。首轮身份摘要脚本误输出过宽、队列历史输出也曾截断；随后改为精确本batch及原add/末事件筛选，正式材料只包含本批指定项，不使用额外批次结论。

## 证据复核

|流|选中行|无效JSON行|source_size|
|---|---:|---:|---:|
|states|4062|2|13241146130|
|decisions|3941|2|1727870452|
|sl-attempts|38|0|41792493|
|run-config|6|0|1801780|
|run-plans|33|0|8262450|
|brain|188|1|618331628|
|runs|6|0|340320|
|fight-plans|0|0|2233957|

共8274行，全部回原日志seek验证offset/bytes/SHA/原JSON、截点和显式身份；所有state及run角色/进阶核验通过。各流原有无效JSON计数保留。fight-plans=0仅限本次截点，不宣称原日志缺失。
列出的39个材料断言通过，详见material-verification.json及audit_evidence.py。它们是原始材料复核，不是生产模型测试、撤源码负控、tsc或vitest。

|来源局/层/回合|原轮窗净损/敌净扣|替轮窗净损/敌净扣|差值：替减原|
|---|---|---|---|
|8JRE1C4H4Z2W F33 T2 尝试1/3|3/10|15/17|净损+12、敌净扣+7|
|YF0LXT1QSTGG F48 T1 尝试2/3|0/45|9/38|净损+9、敌净扣-7|
|XP2SL33HT0D9 F33 T3 尝试1/2|9/24|14/27|净损+5、敌净扣+3|
|XP2SL33HT0D9 F33 T1 尝试1/6|2/25|10/34|净损+8、敌净扣+9|

四组完整fingerprint相同，并以决策observed_ts回连源状态；均只认证表中端点，不将首次派发、候选后缀、抽弃牌后重新规划或永久成长归为已认证整候选。全候选执行保持null。
保留反例：YF F33第二试SL实胜；末试实验体零毒触媒已建却失败，后得敏捷没有倒补格挡；XP同盘换线另得力量且后续抽序改变；沙虫末试5血归零是截断净损，不能拿5替代完整攻击缺口15。

## 逐项处置

每项的原Markdown/SHA、账本id、局号/层/回合、旧行为、支持/反例、预期行为、未来验证与回退都保存在proposal.md。原文逐字节副本和SHA另见proposal-input-manifest.json。

- `silent-proposal-c20b5139dd0dff71`；账本：silent-0168；waiting：缺历史dirty运行实际消费的A10完整移动表及毒、弱、挡、污染跨轮的联合消费者回放；现有当轮污染接线未发现新的确定性差异。

- `silent-proposal-ae9e692d680e3819`；账本：silent-0183, silent-0005；waiting：缺逐实体累计被夺量、非抢夺属性来源与死亡返还的完整冻结模型输入；另一杀序后继未执行。

- `silent-proposal-52f1e1bd2e7db0ed`；账本：silent-0231；waiting：当前进阶首样本HP/攻击读取已存在；缺原dirty运行实际消费的A10移动表字节及覆甲完整减层条件的独立联合输入。

- `silent-proposal-6dd8bbff876be528`；账本：silent-0233, silent-0209；waiting：缺稳定召唤代际、新同类替换与累计量归属的冻结输入；当前growth接线存在，不能据单个连续存活窗口关闭新实体边界。

- `silent-proposal-578e415a259e6835`；账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016；waiting：原答/护栏/SL快照和单动作回执已有；缺跨抽弃牌、护栏及SL的完整候选执行绑定、逐来源兑现与独立后继联合校准。

- `silent-proposal-c0767768bf6a7ab1`；账本：silent-0079；waiting：同题预测资源差已有展示；缺未执行续步、完整替代线资源/胜负对照及跨重问归属，不能据多9血少7伤校准SL惩罚。

- `silent-proposal-a46bdb7fe711d79a`；账本：silent-0021, silent-0027, silent-0028, silent-0085；waiting：当前阶段快照和零毒说明已有；缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准，未找到本批新确定性错算。

- `silent-proposal-1044224808015e5c`；账本：silent-0079；waiting：缺原线与换线的独立完整后继、受控随机池及整战结果；B2零胜并列不足以证明低当轮损失优先的新排序更好。

- `silent-proposal-7cbc6005db712ba9`；账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242；waiting：已有现场值、局部公式及参考；缺逐候选贡献拆分、完整执行绑定与条件联合校准，局部实现不足以把整项登记duplicate。

- `silent-proposal-c59f592f1427a67e`；账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242；waiting：六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。

## 当前源码及边界

source-readback.json记录实际live `cfa1c0be88147b4eac65c13d8c550b23ed4eef17` 与14叶及真实live祖先来源；12叶与本树字节相同，2叶仅所保存Roy/Dai历史注释差。没有把记录同步提交冒称新的源码实现。
已在live的局部来源包括：候选选择审计05cd292c6f01bb31e406473d3a9843e659d62b93；护栏/SL候选比较a8b1f8be153fe4f3a34146117546c2178f2e446b；单动作回执bade647f9fe4c9103b40e2f26b26296692ad24b7；阶段现场快照8698c581dac6c7e957f50a381586960a6d0c9b57；并列即时血价参考1dab14da481fe7951d9020dba52ad0ebebb1029b。上述只是既有子功能，不是本批上线，也未覆盖原提案完整范围，因此不将整id记duplicate。
当前selection audit的actual_turn、HP guard的actual_outcome、SL comparison的actual_turn_result仍明确留空；单动作回执whole_plan_executed=null。现有monsterHpAt/进阶move读取保留首样本，房间代价MEASURED_ROOM_MIN_N仍5。
旧578原文把金刚杵经验关联silent-0016，当前该id原claim是护喉甲覆甲；这是一条既有链接语义差异，报告与CLI追溯note明确分账，不用它证明金刚杵规则，不改历史claim。请ops沿原链核对关联；未提出新机制反证或规则变更。

## 记录、验证与交付

只经根learner/ledger.py update追加本批所属30个既有账本的where.proposal和note；不新增重复证据/提案id、不改claim/首证/prior/原状态/版本，不降级既有shipped；CLI已返回0；ledger-write-receipt.json保存30条原字节offset/bytes/SHA，protected-field-readback.json确认原保护字段及history/notes/where全部保留。新策略无实现，不虚填proposed→shipped。
无源码修改，故未执行撤源码失败/恢复通过、tsc、vitest、沙箱全套或gitleaks提交扫描；这些均不宣称通过。tests固定全null，没有源码提交、合入提交、发布号或上线双通知；不运行play。
临时路径探针曾遇不存在的猜测路径，首次null-combat结构探针TypeError、提取未完成时读取manifest失败，均无生产变更；原会话记录保留，修正后使用实际路径及非空状态，未把这些当生产bug。原提案、失败史、工作树保留。
proposal.md交运维；本批waiting继续等待各项具体缺口所需的新局或绑定输入，不将报告结束当经验入库/消费者验证或量化父要求完成。

最终机器回报见result.json。

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", ROOT / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / "dispatch.json").read_text())
runs = dispatch["runs"]
streams = {}
checks = []


def check(name, actual, expected, references):
    item = {"name": name, "actual": actual, "expected": expected, "references": references,
            "passed": actual == expected}
    checks.append(item)
    if actual != expected:
        (OUT / "material-verification.failed.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2))
        raise AssertionError(item)


for manifest in json.loads((OUT / "evidence/evidence-manifest.json").read_text()):
    name = manifest["stream"]
    path = OUT / "evidence" / (name + ".evidence.jsonl")
    digest = hashlib.sha256()
    rows = []
    counts = dict.fromkeys(runs, 0)
    with open("/home/dw/Projects/agent-sts2/logs/" + name + ".jsonl", "rb") as source:
        for encoded in path.open("rb"):
            digest.update(encoded)
            row = json.loads(encoded)
            source.seek(row["offset"])
            raw = source.read(row["bytes"])
            assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
            assert json.loads(raw) == row["row"]
            assert row["offset"] + row["bytes"] <= manifest["source_size"]
            assert extractor.run_identity(row["row"]) == row["run_id"] in runs
            counts[row["run_id"]] += 1
            rows.append(row)
    assert digest.hexdigest() == manifest["output_sha256"] and counts == manifest["counts"]
    streams[name] = rows

states = {x["line"]: x for x in streams["states"]}
decisions = {x["line"]: x for x in streams["decisions"]}
for x in streams["states"]:
    r = x["row"]["state"]["run"]
    assert r["character_id"] == "SILENT" and r["ascension"] == 10
for x in streams["runs"]:
    assert x["row"]["character"] == "SILENT" and x["row"]["ascension"] == 10
for x in streams["run-config"]:
    assert x["row"]["character"] == "SILENT" and x["row"]["ascension"] == 10
    assert x["row"]["code"]["dirty"] is True


def state(n):
    return states[n]["row"]["state"]


def player(n):
    return state(n)["combat"]["player"]


def power(raw, ident):
    return next((x["amount"] for x in raw["powers"] if x["power_id"] == ident), 0)


def enemy(n, ident=None):
    return next(x for x in state(n)["combat"]["enemies"] if ident is None or x["enemy_id"] == ident)


def attack(n, ident=None):
    return sum(x.get("total_damage") or 0 for x in enemy(n, ident)["intents"])


def outcome(n):
    d = decisions[n]
    r = d["row"]
    matching = [s for s in streams["states"] if s["run_id"] == d["run_id"]
                and s["row"]["fingerprint"] == r["fingerprint"]
                and s["row"].get("observed_ts", s["row"]["ts"]) == r.get("observed_ts", r["ts"])]
    assert matching
    before = matching[0]
    after = next(s for s in streams["states"] if s["run_id"] == d["run_id"] and s["line"] > before["line"]
                 and s["row"]["state"].get("combat")
                 and s["row"]["state"]["turn"] == r["turn"] + 1
                 and s["row"]["state"]["run"]["floor"] == r["floor"])
    a, b = before["row"]["state"]["combat"], after["row"]["state"]["combat"]
    ids_a, ids_b = [e["enemy_id"] for e in a["enemies"]], [e["enemy_id"] for e in b["enemies"]]
    assert ids_a == ids_b
    return {"run": d["run_id"], "floor": r["floor"], "turn": r["turn"], "attempt": r["sl_attempt"],
            "decision_line": n, "state_lines": [before["line"], after["line"]],
            "net_hp_loss": a["player"]["current_hp"] - b["player"]["current_hp"],
            "net_enemy_hp_drop": sum(e["current_hp"] for e in a["enemies"]) - sum(e["current_hp"] for e in b["enemies"]),
            "whole_candidate_execution": None}


check("棱柱T4污染", [power(player(n), "TAINTED_POWER") for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6], [274830, 274831, 274832, 274833])
check("棱柱次轮火花", power(enemy(274834), "VITAL_SPARK_POWER"), 6, [274834])
check("棱柱T5污染", [power(player(n), "TAINTED_POWER") for n in [274834, 274835, 274836, 274837, 274838, 274839]], [0, 0, 6, 12, 18, 0], list(range(274834, 274840)))
check("蚌加压力量", [power(enemy(n), "STRENGTH_POWER") for n in [273237, 273252, 273263]], [0, 4, 8], [273237, 273252, 273263])
check("蚌喷水意图", [attack(n) for n in [273237, 273252, 273263]], [11, 15, 19], [273237, 273252, 273263])
check("蚌轮初覆甲", [power(enemy(n), "PLATING_POWER") for n in [273237, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273237, 273247, 273252, 273258, 273263])
check("电击连续力量", [power(enemy(n, "ZAPBOT"), "STRENGTH_POWER") for n in [274308, 274313]], [2, 4], [274308, 274313])
check("电击连续攻击", [attack(n, "ZAPBOT") for n in [274308, 274313]], [17, 19], [274308, 274313])
check("电击索引重排", [enemy(n, "ZAPBOT")["index"] for n in [274308, 274313]], [4, 3], [274308, 274313])
check("失落被夺力量", power(player(274351), "STRENGTH_POWER"), -4, [274351])
check("遗忘敏捷与步法", [power(player(n), "DEXTERITY_POWER") for n in [274351, 274352, 274354]], [-4, -2, 0], [274351, 274352, 274354])
check("失落退场后力量", power(player(274358), "STRENGTH_POWER"), 0, [274357, 274358])
check("遗忘后续再夺敏", power(player(274362), "DEXTERITY_POWER"), -2, [274362])
check("沙虫终局挡血威胁", [player(276433)["block"], player(276433)["current_hp"], attack(276433)], [22, 5, 37], [276433])
check("沙虫终局零血截断", player(276434)["current_hp"], 0, [276434])
check("实验体末试阶段血", [enemy(n)["current_hp"] for n in [277512, 277513]], [4, 212], [277512, 277513])
check("实验体阶段清毒", [power(enemy(n), "POISON_POWER") for n in [277512, 277513]], [4, 0], [277512, 277513])
check("实验体阶段清力", power(enemy(277513), "STRENGTH_POWER"), 0, [277513])
check("实验体末试触媒零毒", [power(player(277519), "ACCELERANT_POWER"), power(enemy(277519), "POISON_POWER")], [2, 0], [277518, 277519])
check("实验体末试挡不倒补", [[player(n)["block"], power(player(n), "DEXTERITY_POWER")] for n in [277520, 277523, 277526]], [[13, 5], [23, 5], [23, 6]], [277520, 277523, 277526])
check("实验体末试敌净扣", enemy(277519)["current_hp"] - enemy(277527)["current_hp"], 37, [277519, 277527])
check("实验体末试终局", [player(277527)["current_hp"], player(277527)["block"], attack(277527), player(277528)["current_hp"]], [18, 23, 44, 0], [277527, 277528])
check("双蟹末试T2轮初挡", player(278236)["block"], 14, [278236])
check("双蟹镣铐力恢复", [power(enemy(n, "CRUSHER"), "STRENGTH_POWER") for n in [278236, 278237, 278242]], [0, -9, 0], [278236, 278237, 278242])
check("双蟹T2补挡", player(278240)["block"], 20, [278240])
check("双蟹T2净损", player(278236)["current_hp"] - player(278242)["current_hp"], 0, [278236, 278242])
check("双蟹朝向虚弱", [attack(n, "ROCKET") for n in [278249, 278252, 278253]], [57, 38, 28], [278249, 278252, 278253])
check("双蟹脆弱四敏挡", player(278255)["block"], 6, [278254, 278255])
check("双蟹末试T4净损", player(278249)["current_hp"] - player(278257)["current_hp"], 22, [278249, 278257])
pairs = []
for a, b, expected in [(270216, 270282, [3, 10, 15, 17]), (271309, 271348, [0, 45, 9, 38]),
                        (271992, 272040, [9, 24, 14, 27]), (271982, 272195, [2, 25, 10, 34])]:
    check("同指纹配对" + str(a), decisions[a]["row"]["fingerprint"] == decisions[b]["row"]["fingerprint"], True, [a, b])
    aa, bb = outcome(a), outcome(b)
    check("观察轮窗端点" + str(a), [aa["net_hp_loss"], aa["net_enemy_hp_drop"], bb["net_hp_loss"], bb["net_enemy_hp_drop"]], expected, [a, b, *aa["state_lines"], *bb["state_lines"]])
    pairs.append({"original": aa, "replacement": bb, "extra_hp_loss": bb["net_hp_loss"] - aa["net_hp_loss"],
                  "enemy_hp_drop_difference": bb["net_enemy_hp_drop"] - aa["net_enemy_hp_drop"],
                  "limit": "同起点的实际轮窗净端点；不是整候选执行认证、逐来源毛伤或整战受控反事实。"})
check("YF第三试结束动作", decisions[271354]["row"]["chosen"], {"action": "end_turn"}, [271354])
check("YF成功SL反例", any(x["run_id"] == "YF0LXT1QSTGG" and x["row"]["floor"] == 33 and x["row"]["attempt"] == 2 and x["row"]["result"] == "won" for x in streams["sl-attempts"]), True, ["sl-attempts:YF:F33:attempt2"])
result = {"byte_verified_rows": sum(len(v) for v in streams.values()), "counts": {k: len(v) for k, v in streams.items()},
          "checks": checks, "passed": len(checks), "pairs": pairs,
          "scope": "原日志字节、身份与列出的材料断言；没有执行生产模型，也不是tsc/vitest或撤源码红绿。"}
(OUT / "material-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"byte_verified_rows": result["byte_verified_rows"], "material_checks_passed": result["passed"], "pairs": pairs}, ensure_ascii=False))

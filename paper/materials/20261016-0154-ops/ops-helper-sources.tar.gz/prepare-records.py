from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,sys,tarfile

root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0154';pub=root/'paper/materials/20261016-0154-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-014302-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent;out=root/'ops/codex-ops/learner'/(bid+'.out');output=out.read_text()
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert report['fixes']==report['implementation_domains']==[] and len(report['skipped'])==1 and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
final=load(s/'final-git-readback.json');assert final['head']==report['base'] and final['tracked_status_clean'] and final['tracked_diff_empty'] and final['ledger_trace_updates']==30 and final['proposal_count']==10
artifacts=load(s/'artifact-manifest.json')
for row in artifacts:
    raw=(s/row['file']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert (s/'baseline.diff.patch').read_bytes()==b''
proposals=load(s/'proposal-input-manifest.json');assert {x['id'] for x in proposals}==set(report['code_proposals'])
for row in proposals:
    source=Path(row['source']);copy=Path(b['worktree'])/row['copy'];assert source.resolve().is_relative_to(root) and copy.resolve().is_relative_to(root)
    assert sha(source.read_bytes())==row['sha256']==sha(copy.read_bytes())
streams=load(s/'evidence/evidence-manifest.json');assert sum(sum(x['counts'].values()) for x in streams)==8274
for row in streams:assert sha((s/'evidence'/(row['stream']+'.evidence.jsonl')).read_bytes())==row['output_sha256']
material=load(s/'material-verification.json');assert material['byte_verified_rows']==8274 and len(material['checks'])==39 and all(x['passed'] and x['actual']==x['expected'] for x in material['checks'])
source=load(s/'source-readback.json');assert len(source['files'])==14
for row in source['files']:
    a=git('show',report['base']+':'+row['file']);z=git('show',source['live_head']+':'+row['file']);assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256'] and (a==z)==row['equal']
    assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and row['source_is_live_ancestor'];git('merge-base','--is-ancestor',row['live_last_source_commit'],source['live_head'])
assert sum(x['equal'] for x in source['files'])==12
receipt=load(s/'ledger-write-receipt.json');protection=load(s/'protected-field-readback.json');assert receipt['cli_rc']==0 and len(receipt['records'])==30 and protection['own_append_count']==30 and protection['protected_fields_unchanged'] and protection['history_notes_where_preserved']
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];assert len(inputs)==30 and set((s/'ledger-cli.stdout.txt').read_text().split())=={x['id'] for x in inputs}
ledger=root/'paper/materials/learning/ledger.jsonl';own=[]
for entry in receipt['records']:
    with ledger.open('rb') as handle:handle.seek(entry['offset']);raw=handle.read(entry['bytes'])
    row=json.loads(raw);assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update'
    assert any(all(row.get(k)==v for k,v in x.items()) for x in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');existing=set(old.splitlines());assert len(set(own))==30 and all(raw.rstrip(b'\n') not in existing for raw in own);added=b''.join(own)
spec=importlib.util.spec_from_file_location('owned_ledger',root/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
sys.path.insert(0,str(root/'ops'));import learning_requests as flow
notices=[]
for ident in ['733e3a9e9380d9155431980e','b07c96b10b1facb9f887a710']:
    notice=load(root/'ops/codex-ops/learning-notices'/(ident+'.json'));assert notice['request_id']=='silent-proposal-578e415a259e6835'
    stages={}
    for stage in ['ops_forwarded','watcher_received','roy_notified']:
        if notice.get(stage):
            stage_receipt=json.loads(flow.artifact(root,notice[stage]));assert stage_receipt['notice_id']==ident and stage_receipt['stage']==stage and stage_receipt['actor']==('ops' if stage=='ops_forwarded' else 'watcher') and stage_receipt['status']=='delivered';flow.artifact(root,stage_receipt['evidence']);stages[stage]=stage_receipt
    notices.append(dict(notice=notice,verified_stages=stages))
assert set(notices[1]['verified_stages'])=={'ops_forwarded','watcher_received','roy_notified'}
write(pub/'existing-link-notice-readback.json',dict(original_notices=notices,canonical_completed='b07c96b10b1facb9f887a710',old_733_pending_preserved=True,no_new_notice_or_ack_or_resend=True))
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,completion=final,source=source,evidence_output_shas_verified=True,original_rows=8274,original_material_assertions=39,artifact_hashes_verified=len(artifacts),material_not_reexecuted=True,owned_trace_rows=30,protected_fields_and_old_prefixes_preserved=True,existing_link_notice='b07c96b10b1facb9f887a710',limits=['Six historical dirty Silent A10 anchors do not cover the original 101-run denominator or recover original consumed move-table/knowledge bytes.','Four paired same-fingerprint windows certify only bounded endpoints. Full candidate attribution, gross damage, persistent entity/generation identity, alternative kill order and controlled full-fight/potion/route successors remain unknown.','Existing phase snapshots, current ascension first-sample lookup and room minimum n=5 remain scoped; no new deterministic discrepancy or wide-parent completion claimed.','Old 578 Vajra/0016 Gorget association is a known linkage conflict. Canonical historical b07 receipt chain is read back; old pending 733 is untouched, no duplicate notice or other-role ACK.','Original path/null-combat/unfinished-manifest probes and truncated output preserved; material checks are not production tests.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0154原014302-s2策略done0/no-source处置核，0a16干净WT/HEAD不变、十waiting具体缺口/testsnull/域空/mergednull保持，无提交或合入阻塞，不空合/发号/补测。六Silent A10八流8274材料产物SHA/39限定断言及14原件SHA核，不重跑或当生产测试/全候选认证；四同指纹轮窗只证端点，不以截顶5HP损失代完整15缺口，不抹YF已胜SL反例或倒补后得敏捷，XP换线成长/抽序及逐实体累计/召唤代际、原dirty移动表与101局分母未齐等未知保持。14源码叶12同2历史Roy-Dai注释差/真实live祖先核，阶段/护栏/SL与单动作快照不当完整兑现或本批新实现。旧578金刚杵→0016覆甲链接语义冲突已有canonical b07c96b10b1facb9f887a710三角色原回执及证据SHA核，旧733 pending不改、不新建通知/重发/代ACK，不把该链接用作金刚杵规则支持。30所属CLI纯where/note逐输入/输出ID/offset/bytes/SHA及私有fold核，旧claim/首证/prior/证据/状态/版本及history/notes/where保、不重复CLI或降级shipped；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network与188历史脑high分列，原路径/null/未完成manifest探针及宽输出失败保，不当产品故障。仅本人记录/追溯提交，保并行脏记录；无新源码/知识/版本/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261016-0154-ops/。\n'
note=f'\n- {at} [运维 codex] 原014302-s2策略十项继续waiting，无源码变更/合入受阻；39项为限定材料检查，生产tests仍null。30所属追溯已核；旧578链接冲突复用已核历史b07完整通知链，不重复通知或改旧pending。回执paper/materials/20261016-0154-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=30,protected_fields_preserved=True,no_new_source_tests_merge_or_release=True,no_new_notice_or_ack=True,wide_parents='remain open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,owned_trace_rows=30,ledger_check=0,paths=len(entries))))

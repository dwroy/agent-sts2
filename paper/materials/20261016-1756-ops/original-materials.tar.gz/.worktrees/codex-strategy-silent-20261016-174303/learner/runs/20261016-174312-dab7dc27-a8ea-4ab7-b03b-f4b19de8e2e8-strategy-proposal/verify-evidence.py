import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extractor', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
RUNS = set(json.loads((HERE / 'dispatch.json').read_text())['runs'])
checks = []
streams = {}
verification = []


def check(label, actual, expected, lines):
    result = {'statement': label, 'actual': actual, 'expected': expected,
              'source_lines': lines, 'passed': actual == expected}
    checks.append(result)
    (HERE / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    assert result['passed'], result


for folder in ['evidence', 'evidence-extra']:
    manifests = json.loads((HERE / folder / 'evidence-manifest.json').read_text())
    for manifest in manifests:
        stream = manifest['stream']
        path = HERE / folder / (stream + '.evidence.jsonl')
        digest = hashlib.sha256()
        rows = []
        counts = Counter()
        with path.open('rb') as source, (Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')).open('rb') as raw:
            for line in source:
                digest.update(line)
                entry = json.loads(line)
                assert entry['run_id'] in RUNS
                assert extractor.run_identity(entry['row']) == entry['run_id']
                assert entry['offset'] + entry['bytes'] <= manifest['source_size']
                raw.seek(entry['offset'])
                original = raw.read(entry['bytes'])
                assert original.endswith(b'\n')
                assert hashlib.sha256(original).hexdigest() == entry['sha256']
                assert json.loads(original) == entry['row']
                counts[entry['run_id']] += 1
                rows.append(entry)
        assert digest.hexdigest() == manifest['output_sha256']
        assert all(counts[run] == manifest['counts'][run] for run in RUNS)
        verification.append({**manifest, 'verified_rows': len(rows), 'all_bytes_identity_hashes_verified': True})
        streams[stream] = rows
(HERE / 'evidence-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
S = {r['line']: r for r in streams['states']}
D = {r['line']: r for r in streams['decisions']}


def state(line):
    return S[line]['row']['state']


def player(line):
    return state(line)['combat']['player']


def powers(items):
    return {v['power_id']: v['amount'] for v in items}


def values(line, card, key):
    return [next(v['current_value'] for v in c['dynamic_values'] if v['name'] == key)
            for c in state(line)['combat']['hand'] if c['card_id'] == card]


def enemy(line, kind):
    return next(e for e in state(line)['combat']['enemies'] if e['enemy_id'] == kind)


def decision(line):
    return D[line]['row']


for a, b, floor in [(275564, 275565, 35), (275679, 275680, 43)]:
    check(f'VLZ F{floor}神化能量端点', [player(a)['energy'], player(b)['energy']], [7, 5], [a, b])
for card, key, a, b in [('DEFEND_SILENT', 'Block', 5, 8), ('STRIKE_SILENT', 'Damage', 7, 10),
                       ('DAGGER_SPRAY', 'Damage', 5, 7)]:
    check('F35神化牌面/' + card, [values(275564, card, key), values(275565, card, key)], [[a], [b]], [275564, 275565])
check('F35必备工具费用', [[c['energy_cost'] for c in state(n)['combat']['hand'] if c['card_id'] == 'TOOLS_OF_THE_TRADE']
                        for n in [275564, 275565]], [[1], [0]], [275564, 275565])
for card, key, a, b in [('SUCKER_PUNCH', 'Damage', 9, 11), ('SUCKER_PUNCH', 'WeakPower', 1, 2),
                       ('FASTEN', 'ExtraBlock', 4, 6), ('PIERCING_WAIL', 'StrengthLoss', 6, 8)]:
    check('F43神化牌面/' + card + '/' + key, [values(275679, card, key), values(275680, card, key)],
          [[a], [b]], [275679, 275680])
check('F43后抽毒雾', [(c['upgraded'], next(v['current_value'] for v in c['dynamic_values'] if v['name'] == 'PoisonPerTurn'))
                     for c in state(275687)['combat']['hand'] if c['card_id'] == 'NOXIOUS_FUMES'], [(True, 3)], [275687])
check('F45药水前后能量和HP', [[player(n)['energy'], player(n)['current_hp']] for n in [275728, 275729]],
      [[1, 67], [2, 67]], [275728, 275729])
check('F45药水实际手牌', [c['card_id'] for c in state(275729)['combat']['hand']],
      ['APOTHEOSIS', 'TOOLS_OF_THE_TRADE', 'SURVIVOR'], [275728, 275729])
check('F45末轮血和挡', [player(275754)['current_hp'], player(275754)['block']], [32, 20], [275754])
check('F45末轮覆甲', powers(player(275754)['powers']).get('PLATING_POWER', 0), 0, [275754])
check('F45末轮当前来袭', sum(i.get('total_damage') or 0 for e in state(275754)['combat']['enemies'] for i in e['intents']), 59, [275754])
check('CA5蚌力量', [powers(enemy(n, 'SEWER_CLAM')['powers']).get('STRENGTH_POWER', 0) for n in [273237, 273252, 273263]],
      [0, 4, 8], [273237, 273252, 273263])
check('CA5蚌喷水', [enemy(n, 'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273237, 273252, 273263]],
      [11, 15, 19], [273237, 273252, 273263])
check('CA5蚌虚弱后', [enemy(n, 'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273257, 273268]],
      [11, 14], [273257, 273268])
check('61E族母负敏捷', powers(player(273504)['powers'])['DEXTERITY_POWER'], -2, [273504])
check('61E族母防御牌面', values(273504, 'DEFEND_SILENT', 'Block'), [3, 3], [273504])
check('61E族母毒结算端点', [enemy(n, 'LAGAVULIN_MATRIARCH')['current_hp'] for n in [273504, 273508]], [67, 34], [273504, 273508])
check('61E胧光本体和幻象端点', [[enemy(n, kind)['current_hp'] for kind in ['THE_OBSCURA', 'PARAFRIGHT']]
                              for n in [273593, 273596]], [[76, 14], [41, 2]], [273593, 273596])
check('61E胧光玩家端点', [player(n)['current_hp'] for n in [273593, 273596]], [25, 10], [273593, 273596])
check('61E两次航行力量', [[powers(enemy(n, kind)['powers']).get('STRENGTH_POWER', 0) for kind in ['THE_OBSCURA', 'PARAFRIGHT']]
                         for n in [273589, 273596]], [[3, 3], [6, 6]], [273589, 273596])
check('DUZ甲虫减力及恢复成长', [powers(enemy(n, 'SLUMBERING_BEETLE')['powers'])['STRENGTH_POWER'] for n in [274929, 274932, 274934]],
      [2, -4, 4], [274929, 274932, 274934])
check('DUZ甲虫对应来袭', [enemy(n, 'SLUMBERING_BEETLE')['intents'][0]['total_damage'] for n in [274929, 274932, 274934]],
      [20, 14, 22], [274929, 274932, 274934])
check('8JRE首三试同指纹', decision(270216)['fingerprint'] == decision(270282)['fingerprint'], True, [270216, 270282])
numbers = decision(270282)['sl_explore']['numbers']
check('8JRE不同死亡样本', ['dead 0/24' in numbers['original'], 'dead 5/24' in numbers['replacement']], [True, True], [270282])
check('8JRE护栏旧文本', ['HP guard:' in decision(270264)['rationale'], 'hp_guard' in decision(270264)], [True, False], [270264])
mc = decision(269748)['potions']['random'][0]
check('VLZ药水样本和耗时', [mc['samples'], mc['requested'], mc['ms']], [1, 12, 707], [269748])
rollout = decision(269748)['rollout']
check('VLZ退化推演', [rollout['horizon'], rollout['samples'], rollout['best']], [1, 1, None], [269748])
check('5PM无毒冒泡能量', [player(n)['energy'] for n in [274379, 274380]], [5, 4], [274379, 274380, 268455])
check('5PM无毒冒泡敌HP', [enemy(n, 'THE_LOST')['current_hp'] for n in [274379, 274380]], [35, 35], [274379, 274380, 268455])
check('5PM无毒冒泡敌毒', [powers(enemy(n, 'THE_LOST')['powers']).get('POISON_POWER', 0) for n in [274379, 274380]], [0, 0], [274379, 274380, 268455])
check('8JRE首三试T2实际玩家端点差',
      [player(b)['current_hp'] - player(a)['current_hp'] for a, b in [(276208, 276212), (276274, 276278)]],
      [-3, -15], [276208, 276212, 276274, 276278, 270216, 270282])
check('8JRE首三试T2实际敌端点差',
      [enemy(b, 'THE_INSATIABLE')['current_hp'] - enemy(a, 'THE_INSATIABLE')['current_hp']
       for a, b in [(276208, 276212), (276274, 276278)]],
      [-10, -17], [276208, 276212, 276274, 276278, 270216, 270282])

# Retain compact source-linked projections; the full wrappers remain the authoritative evidence.
used = {line for item in checks for line in item['source_lines']}
projection = []
for line in sorted(used):
    if line in S:
        item = S[line]
        raw = state(line)
        projection.append({'stream': 'states', **{k: item[k] for k in ['line', 'run_id', 'offset', 'bytes', 'sha256']},
                           'floor': raw.get('run', {}).get('floor'), 'turn': raw.get('turn'), 'combat': raw.get('combat')})
    if line in D:
        item = D[line]
        projection.append({'stream': 'decisions', **{k: item[k] for k in ['line', 'run_id', 'offset', 'bytes', 'sha256']}, 'row': item['row']})
(HERE / 'selected-facts.json').write_text(json.dumps(projection, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_raw_rows': sum(r['verified_rows'] for r in verification), 'fact_checks': len(checks), 'all_passed': True}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger_cli', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
updates = [json.loads(line) for line in (HERE / 'ledger-updates.jsonl').read_text().splitlines()]
assert len(updates) == 26
assert all(set(row) == {'id', 'by', 'where', 'note'} and row['by'] == 'learner:strategy-proposal' for row in updates)
all_before = ledger.fold(ledger.read_rows(str(LEDGER)))
before = {row['id']: all_before[row['id']] for row in updates}
assert all(row['character'] == 'silent' for row in before.values())
size = LEDGER.stat().st_size
digest = hashlib.sha256()
with LEDGER.open('rb') as source:
    remaining = size
    while remaining:
        block = source.read(min(1024 * 1024, remaining))
        assert block
        digest.update(block)
        remaining -= len(block)
prefix_hash = digest.hexdigest()
(HERE / 'ledger-before-append.json').write_text(json.dumps(before, ensure_ascii=False) + '\n')
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                        input=(HERE / 'ledger-updates.jsonl').read_text(), text=True, capture_output=True)
(HERE / 'ledger-cli.log').write_text(result.stdout + result.stderr)
(HERE / 'ledger-cli.rc').write_text(str(result.returncode) + '\n')
assert result.returncode == 0, result.stderr
after = ledger.fold(ledger.read_rows(str(LEDGER)))
keys = ['character', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'status', 'version', 'effect', 'evidence', 'shipped_at']
for update in updates:
    ident = update['id']
    for key in keys:
        assert before[ident].get(key) == after[ident].get(key), (ident, key)
    assert update['note'] in after[ident]['notes']
    assert all(path in after[ident]['where']['proposal'] for path in update['where']['proposal'])
digest = hashlib.sha256()
physical_rows = []
with LEDGER.open('rb') as source:
    original_prefix = source.read(size)
    digest.update(original_prefix)
    assert digest.hexdigest() == prefix_hash
    offset = size
    for raw in source:
        row = json.loads(raw)
        if row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith('20261016-174303-strategy-proposal逐项核原十提案'):
            expected = next(value for value in updates if value['id'] == row['id'])
            assert all(row[key] == value for key, value in expected.items())
            physical_rows.append({'id': row['id'], 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        offset += len(raw)
assert len(physical_rows) == 26
receipt = {'exit_code': result.returncode, 'updates': len(updates), 'root_ledger': str(LEDGER),
           'original_prefix_size': size, 'original_prefix_sha256': prefix_hash,
           'original_prefix_preserved': True, 'protected_fields_preserved': keys, 'rows': physical_rows}
(HERE / 'ledger-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ledger_cli_exit': result.returncode, 'linked_items': len(updates),
                  'protected_fields_and_prefix_preserved': True}, ensure_ascii=False))

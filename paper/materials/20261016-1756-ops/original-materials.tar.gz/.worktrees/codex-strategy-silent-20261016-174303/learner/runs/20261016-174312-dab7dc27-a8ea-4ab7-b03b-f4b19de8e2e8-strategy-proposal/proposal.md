# 静默猎手：本批十项提案核验与处置

记录时间：2026-10-16T17:53:45+08:00。来源及实现任务：strategy-proposal；batch=20261016-174303-strategy-proposal；角色silent，已观察范围A10。
基线：c75756fe60168c410f1eb4e611433176ed7ec194。仅处理本批已领取十id；原提案Markdown逐字保存于original-proposals/，全部SHA与队列匹配，不覆盖原文、不另建重复id。

六局原runs均为SILENT/A10；SL尝试不扩独立样本。8流6995原行逐offset/bytes/SHA/JSON/显式所属身份核验；37项原帧事实通过。两份manifest、evidence-verification.json与fact-checks.json保留核验输入和结果。
本批不拟合阈值、血价、药价或启动/目标优先级。当前证据支持下述事实及限制，尚不足以完成宽提案的验证；全部waiting，原行为保持。

## silent-proposal-89354805ee4d7e77

原来源任务：postmortem；实现任务：strategy-proposal；domains=combat,structure。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。
账本：silent-0237, silent-0238。经验：沿原复盘账本链。

证据局、层、回合：VLZ6CCT8AQ0A，F35 T1、F43 T1—T5、F45 T1。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：F35打神化后改变目标与重规划，不能把37到52伤全部归神化；F43施放后仍损57，F45未施放败局也不是因果对照。

当前及预期行为：维持已观察卡升级变换；以后补齐实际施放/候选/模型覆盖三账及持续身份，不加必打神化规则。

处置：waiting。已核神化在同线、后续抽牌及致命毒药等局部传播；actual_cast_this_fight仍为null，缺跨抽牌、选择、药水、重问、SL和换战的施放持续身份与未覆盖属性组合校准，不能关闭整项。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-f2bfceddb1898dca

原来源任务：postmortem；实现任务：strategy-proposal；domains=combat,potion。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。
账本：silent-0106, silent-0019, silent-0201。经验：沿原复盘账本链。

证据局、层、回合：VLZ6CCT8AQ0A，F43、F44、F45 T1/T4/T5。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：707毫秒是特定运行预算观测；第二问12/12含药水后新手牌与观测指纹，不能当同盘预算实验。F17/F33获胜也反对一概弃用推演。

当前及预期行为：维持预算与药水价值；已有成熟度展示继续区分不可比较与明确并列，取得配对证据后再评估预算方案。

处置：waiting。首问MC为707毫秒、1/12，退化horizon=1；第二问不属同一观测盘面。缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性曲线及留药完整后继，不改预算、药价或目标顺序。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-283a164780d11e69

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat,structure。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。
账本：silent-0237, silent-0238。经验：silent-apotheosis-combat-upgrades。

证据局、层、回合：VLZ6CCT8AQ0A，F35 T1、F43 T1—T5、F45 T1。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：经验链与复盘链共享同一局，不能增计独立局数；未知牌和未验证属性交互仍须保留unknown。

当前及预期行为：沿用原神化实现链，保留独立经验来源链接，不另造提案或重复升级收益。

处置：waiting。与89354805ee4d7e77同源但保留experience-update链；已发布局部升级传播未补齐实际施放持续身份和剩余组合校准，不能把同题重复当作整项duplicate。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-ebbfe3b97548756d

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat,structure。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。
账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。经验：silent-strength-weak-observation, silent-footwork-block, silent-gorget-plating, silent-vajra-opening-strength, silent-sparkling-rouge-turn-three, silent-fasten-defend-extra-block, silent-piercing-wail-temporary-strength, silent-malaise-x-debuff, silent-accelerant-triggers, silent-noxious-fumes-growth, silent-deck-burst-observation, silent-three-knights-output-buffer-observation, silent-stone-humidifier-rest-growth, silent-rest-buffer-observation, silent-route-hp-observation。

证据局、层、回合：VLZ6CCT8AQ0A，F43 T1—T5、F45 T3/T5、F44休息。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：单次减力不代表永久安全，覆甲须读现场层数；F43赢战损57，F44补血后仍败，不拟合统一安全血线或路线优先级。

当前及预期行为：按原十五子项逐源验证，不预支后续毒、临时减力、敏捷或休息投影；未证部分保留现行为。

处置：waiting。十五个机制和资源子项有局部模型及事实展示，仍缺属性/升级组合、状态期限与战斗、路线、休息消费者在同一冻结输入下的逐源联合校准，不能用单个子项源码关闭全部。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-e5b87be50f28f311

原来源任务：postmortem；实现任务：strategy-proposal；domains=combat,sl。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。
账本：silent-0079, silent-0021, silent-0125, silent-0018。经验：沿原复盘账本链。

证据局、层、回合：8JRE1C4H4Z2W，F33首/三试T2、第二试T5、末试T11；F17 T6。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：末试更防守延至T11仍败，不支持一律攻击或一律保血；候选差、实际整轮端点与完整候选因果分别记录。

当前及预期行为：维持选择与SL规则；需要持续候选标识、重问中断及实际端点认证后再谈整套执行或成长收益。

处置：waiting。8JRE同指纹SL换线的12血换7伤已核；现有三阶段审计、单动作回执和离线端点未认证跨重问完整候选执行及能力收益归属，缺完整执行证据与未选线整战后继，不改SL血价或护栏。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-49632bc4878fb597

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。
账本：silent-0005, silent-0231。经验：silent-strength-weak-observation。

证据局、层、回合：CA5KE8GFJ9X2，F13 T1/T3/T5。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：虚弱未取消下一次加压；计划中的步法未取得，不能把正敏捷补进本战。末轮2血10挡仍不足完整4损。

当前及预期行为：从现场属性逐击/逐牌计算，并分别验证敌人成长，不拟合统一攻防血价。

处置：waiting。CA5 F13力量0/4/8、喷水11/15/19及虚弱后11/14可核；该战无正敏捷实测，缺逐击力量、正负敏捷、虚弱和独立成长四路径的同次冻结生产校准，不增加统一权重。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-66532328a585941f

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat,structure。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。
账本：silent-0021, silent-0009。经验：silent-deck-burst-observation。

证据局、层、回合：5PM6JAQG6FNQ，F39末试T2；F33已建立能力战作为范围反例。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：同局F33已建立雾、触媒并赢，敌人、组件和生存条件同时改变，不能据两战输赢拟合启动次序。

当前及预期行为：保持持有、计划、已建立、已结算分列；没有整战对照不设能力启动优先级。

处置：waiting。5PM末试F39 T2无毒冒泡实付1能而敌HP及毒不变；缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及收益函数，不据组件持有制定启动权重。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-43a76a31ba7bdcfa

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat,sl。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。
账本：silent-0030, silent-0027。经验：silent-lagavulin-siphon-poison-sl。

证据局、层、回合：61E2QS63Y9WU，F17 T5/T6。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：本局首试获胜，不提供另一SL胜线；毒仍结算不等同任意负属性局都可救。

当前及预期行为：维持吸取、负敏捷与毒分项事实；不扩大SL范围或改阈值。

处置：waiting。61E F17 T6负敏捷与17+16毒结算可核，但首试胜利不是SL对照；缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继，不改SL范围或阈值。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-5264153a4a4b0e5c

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。
账本：silent-0039, silent-0209。经验：silent-obscura-summon-growth。

证据局、层、回合：61E2QS63Y9WU，F23 T3/T4/T5。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：幻象剩2血仍攻击，不能把本体净扣当全员退场；另一focus只是候选预测，不称整战胜线。

当前及预期行为：保留全部目标选项，相同推演值并列；依据当前进阶数据库和实盘验证召唤实体及成长。

处置：waiting。61E F23 T4本体/幻象76/14到41/2、玩家25到10可核，39伤/零损候选未实打；缺A10召唤、航行成长、退场和复现全链生产校准及另一focus完整后继，不规定固定杀序。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## silent-proposal-bddfa690a84e03d0

原来源任务：experience-update；实现任务：strategy-proposal；domains=combat。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。
账本：silent-0128, silent-0079。经验：silent-slumbering-beetle-wake-growth。

证据局、层、回合：DUZUBAJ3A8GP，F30 T1—T6及同场四次尝试。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：末试T4多扣3敌血同时多损2玩家血，四次尝试来自同一局，不能扩成独立胜率样本。

当前及预期行为：维持睡眠、眩晕和成长分项事实，不把临时减力当关闭成长，不设固定杀序。

处置：waiting。DUZ F30已核临时减力2到-4再恢复成长到4、来袭20/14/22；缺伤害唤醒、眩晕接续与当前进阶成长的全链校准和同抽换序后继，四次相关失败不能拟合输出血价。

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。

## 十五机制与资源子项边界

ebbfe3b97548756d的十五项分别是力量/虚弱、步法挡、护喉甲覆甲、金刚杵开场力量、口红T3、勒紧防御专属挡、尖啸临时减力、萎靡X、触媒结算、毒雾增长、持有与爆发、三骑士时钟、加湿器休息、休息缓冲、路线HP。各项分母和进阶沿原文分开，不以综合支持数代替每个机制实验数。当前只核本批静默原帧和对应账本，不从其他角色搬运。

Roy-2026-10-07-learning提供已有修改权限，不提供游戏事实；本批未发现足以新定规则的证据或新的机制异议。神化两条原提案共享证据而来源链独立，保留两个waiting，并非重复登记。代码存在、记录生成与经验真正入库/消费者读回/效果分开；本报告不关闭学习父要求。

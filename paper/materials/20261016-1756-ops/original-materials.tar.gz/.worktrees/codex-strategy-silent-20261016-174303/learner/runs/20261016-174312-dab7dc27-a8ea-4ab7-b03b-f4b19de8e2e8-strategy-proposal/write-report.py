import datetime as dt
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = 'c75756fe60168c410f1eb4e611433176ed7ec194'
BATCH = '20261016-174303-strategy-proposal'
dispatch = json.loads((HERE / 'dispatch.json').read_text())
assigned = json.loads((HERE / 'assigned-proposals.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
assert len(assigned) == 10
assert len(json.loads((HERE / 'fact-checks.json').read_text())) == 37
assert all(r['passed'] for r in json.loads((HERE / 'fact-checks.json').read_text()))
stamp = dt.datetime.now().astimezone().isoformat(timespec='seconds')

reasons = [
    '已核神化在同线、后续抽牌及致命毒药等局部传播；actual_cast_this_fight仍为null，缺跨抽牌、选择、药水、重问、SL和换战的施放持续身份与未覆盖属性组合校准，不能关闭整项。',
    '首问MC为707毫秒、1/12，退化horizon=1；第二问不属同一观测盘面。缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性曲线及留药完整后继，不改预算、药价或目标顺序。',
    '与89354805ee4d7e77同源但保留experience-update链；已发布局部升级传播未补齐实际施放持续身份和剩余组合校准，不能把同题重复当作整项duplicate。',
    '十五个机制和资源子项有局部模型及事实展示，仍缺属性/升级组合、状态期限与战斗、路线、休息消费者在同一冻结输入下的逐源联合校准，不能用单个子项源码关闭全部。',
    '8JRE同指纹SL换线的12血换7伤已核；现有三阶段审计、单动作回执和离线端点未认证跨重问完整候选执行及能力收益归属，缺完整执行证据与未选线整战后继，不改SL血价或护栏。',
    'CA5 F13力量0/4/8、喷水11/15/19及虚弱后11/14可核；该战无正敏捷实测，缺逐击力量、正负敏捷、虚弱和独立成长四路径的同次冻结生产校准，不增加统一权重。',
    '5PM末试F39 T2无毒冒泡实付1能而敌HP及毒不变；缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及收益函数，不据组件持有制定启动权重。',
    '61E F17 T6负敏捷与17+16毒结算可核，但首试胜利不是SL对照；缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继，不改SL范围或阈值。',
    '61E F23 T4本体/幻象76/14到41/2、玩家25到10可核，39伤/零损候选未实打；缺A10召唤、航行成长、退场和复现全链生产校准及另一focus完整后继，不规定固定杀序。',
    'DUZ F30已核临时减力2到-4再恢复成长到4、来袭20/14/22；缺伤害唤醒、眩晕接续与当前进阶成长的全链校准和同抽换序后继，四次相关失败不能拟合输出血价。',
]
evidence = [
    'VLZ6CCT8AQ0A，F35 T1、F43 T1—T5、F45 T1',
    'VLZ6CCT8AQ0A，F43、F44、F45 T1/T4/T5',
    'VLZ6CCT8AQ0A，F35 T1、F43 T1—T5、F45 T1',
    'VLZ6CCT8AQ0A，F43 T1—T5、F45 T3/T5、F44休息',
    '8JRE1C4H4Z2W，F33首/三试T2、第二试T5、末试T11；F17 T6',
    'CA5KE8GFJ9X2，F13 T1/T3/T5',
    '5PM6JAQG6FNQ，F39末试T2；F33已建立能力战作为范围反例',
    '61E2QS63Y9WU，F17 T5/T6',
    '61E2QS63Y9WU，F23 T3/T4/T5',
    'DUZUBAJ3A8GP，F30 T1—T6及同场四次尝试',
]
limits = [
    'F35打神化后改变目标与重规划，不能把37到52伤全部归神化；F43施放后仍损57，F45未施放败局也不是因果对照。',
    '707毫秒是特定运行预算观测；第二问12/12含药水后新手牌与观测指纹，不能当同盘预算实验。F17/F33获胜也反对一概弃用推演。',
    '经验链与复盘链共享同一局，不能增计独立局数；未知牌和未验证属性交互仍须保留unknown。',
    '单次减力不代表永久安全，覆甲须读现场层数；F43赢战损57，F44补血后仍败，不拟合统一安全血线或路线优先级。',
    '末试更防守延至T11仍败，不支持一律攻击或一律保血；候选差、实际整轮端点与完整候选因果分别记录。',
    '虚弱未取消下一次加压；计划中的步法未取得，不能把正敏捷补进本战。末轮2血10挡仍不足完整4损。',
    '同局F33已建立雾、触媒并赢，敌人、组件和生存条件同时改变，不能据两战输赢拟合启动次序。',
    '本局首试获胜，不提供另一SL胜线；毒仍结算不等同任意负属性局都可救。',
    '幻象剩2血仍攻击，不能把本体净扣当全员退场；另一focus只是候选预测，不称整战胜线。',
    '末试T4多扣3敌血同时多损2玩家血，四次尝试来自同一局，不能扩成独立胜率样本。',
]
expected = [
    '维持已观察卡升级变换；以后补齐实际施放/候选/模型覆盖三账及持续身份，不加必打神化规则。',
    '维持预算与药水价值；已有成熟度展示继续区分不可比较与明确并列，取得配对证据后再评估预算方案。',
    '沿用原神化实现链，保留独立经验来源链接，不另造提案或重复升级收益。',
    '按原十五子项逐源验证，不预支后续毒、临时减力、敏捷或休息投影；未证部分保留现行为。',
    '维持选择与SL规则；需要持续候选标识、重问中断及实际端点认证后再谈整套执行或成长收益。',
    '从现场属性逐击/逐牌计算，并分别验证敌人成长，不拟合统一攻防血价。',
    '保持持有、计划、已建立、已结算分列；没有整战对照不设能力启动优先级。',
    '维持吸取、负敏捷与毒分项事实；不扩大SL范围或改阈值。',
    '保留全部目标选项，相同推演值并列；依据当前进阶数据库和实盘验证召唤实体及成长。',
    '维持睡眠、眩晕和成长分项事实，不把临时减力当关闭成长，不设固定杀序。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(assigned, reasons)]
(HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

parts = [f'''# 静默猎手：本批十项提案核验与处置

记录时间：{stamp}。来源及实现任务：strategy-proposal；batch={BATCH}；角色silent，已观察范围A10。
基线：{BASE}。仅处理本批已领取十id；原提案Markdown逐字保存于original-proposals/，全部SHA与队列匹配，不覆盖原文、不另建重复id。

六局原runs均为SILENT/A10；SL尝试不扩独立样本。8流6995原行逐offset/bytes/SHA/JSON/显式所属身份核验；37项原帧事实通过。两份manifest、evidence-verification.json与fact-checks.json保留核验输入和结果。
本批不拟合阈值、血价、药价或启动/目标优先级。当前证据支持下述事实及限制，尚不足以完成宽提案的验证；全部waiting，原行为保持。
''']
for p, ev, limit, behavior, result in zip(assigned, evidence, limits, expected, results):
    parts.append(f'''## {p['id']}

原来源任务：{p['source_task']}；实现任务：strategy-proposal；domains={','.join(p['domains'])}。
原提案：{p['proposal']}；SHA256={p['proposal_sha256']}。
账本：{', '.join(p['ledger'])}。经验：{', '.join(p.get('experience', [])) or '沿原复盘账本链'}。

证据局、层、回合：{ev}。本轮原始核验及具体数字见fact-checks.json、selected-facts.json；原完整条件见对应保存原文。

反例及未知：{limit}

当前及预期行为：{behavior}

处置：waiting。{result['reason']}

验证方法：将该项涉及的手牌、出牌/重规划前缀、属性、药水和当前进阶敌人HP/伤害/移动输入冻结，逐源校准实际调用；需要比较策略时使用同起点、同抽序/随机池及同预算，按run_id分组，后续独立本角色完局作时间后置验证。本批六局为已用于发现的证据，不能称盲测。未知保持未知，不用在线LLM、刷新的知识JSON或其他角色私有知识补齐。以后新增源码须有撤源码红/恢复绿及原沙箱检查。

预期影响：使该项事实、现有窄覆盖与剩余缺口可追溯，不承诺整战转胜。本次无代码可回退；后续实现按独立源码commit回退，保留原日志、账本和失败历史，实际上线再按授权双通知Roy。
''')
parts.append('''## 十五机制与资源子项边界

ebbfe3b97548756d的十五项分别是力量/虚弱、步法挡、护喉甲覆甲、金刚杵开场力量、口红T3、勒紧防御专属挡、尖啸临时减力、萎靡X、触媒结算、毒雾增长、持有与爆发、三骑士时钟、加湿器休息、休息缓冲、路线HP。各项分母和进阶沿原文分开，不以综合支持数代替每个机制实验数。当前只核本批静默原帧和对应账本，不从其他角色搬运。

Roy-2026-10-07-learning提供已有修改权限，不提供游戏事实；本批未发现足以新定规则的证据或新的机制异议。神化两条原提案共享证据而来源链独立，保留两个waiting，并非重复登记。代码存在、记录生成与经验真正入库/消费者读回/效果分开；本报告不关闭学习父要求。
''')
(HERE / 'proposal.md').write_text('\n'.join(parts))

verification = json.loads((HERE / 'evidence-verification.json').read_text())
table = '\n'.join(f"| {r['stream']} | {r['source_size']} | {r['verified_rows']} |" for r in verification)
result_table = '\n'.join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
source = json.loads((HERE / 'source-audit.json').read_text())
source['base_live_patch_sha256'] = hashlib.sha256((HERE / 'base-live-source.patch').read_bytes()).hexdigest()
(HERE / 'source-audit.json').write_text(json.dumps(source, ensure_ascii=False, indent=2) + '\n')
report = f'''# 静默策略学习批次报告

记录时间：{stamp}。task=strategy-proposal；character=silent；batch={BATCH}。

## 结论

十个派发提案全部waiting，逐项缺口如下。本批没有源码/知识修改、源码提交、live合入或新版本；fixes=[]、merged=null。完整base={BASE}，工作树保持干净。没有发现可凭本批证据直接制定的新预算、药水血价、HP护栏、SL阈值或固定启动/目标顺序。

## 身份与边界

开工git status干净。已读README、STATE-2026-10-16、decision-log末尾、learning-protocol和learning-code-proposals；精确读取根learn.json本批行并保存dispatch.json。task/character/worktree/runs均匹配，reason=proposal，有且仅有十proposal_ids，无research_request、implementation_request或proposal_repair。普通专题请求属于另一旧batch，不承接、不用其他专题替换身份。按普通批次git merge --no-edit main，返回Already up to date；HEAD保持base。

六局：{', '.join(dispatch['runs'])}。runs.jsonl六原行均为SILENT/A10；独立局数6，同局SL不扩分母。只学习本角色证据，未读取其他角色私有知识，未使用预训练游戏事实。没有下级agent。

任务文字要求普通模式/high，AGENTS另有统一模型要求；本工具没有原生请求模型/强度的独立读回或修改入口，未修改配置、权限或另开会话，也不把默认配置冒充实际原生核验。此项交宿主按真实会话记录核实。

## 原日志与固定事实核验

用本工作树extract_evidence.py共用入口提取默认6流，另以同入口补runs和fight-plans。每流先冻结source_size；按显式run_id/state.run_id/run/fingerprint.run归属，正文提及不算身份，冲突拒收。6995所属行全部逐offset/bytes/SHA256、原始JSON与身份再读回，通过verify-evidence-final.log；37项固定原帧断言通过。初次35项核验成功记录仍保留，随后仅增加两项8JRE实际端点差，最终37项均通过。这是证据数据核验，不是生产测试。

| 流 | source_size字节 | 核验所属行 |
|---|---:|---:|
{table}

states/decisions各有2行全源无效JSON，brain有1行；不据全源计数断言属于本六局。fight-plans本截点六局0行只说明未选到，不称原流不存在。run-plans有33行，使用run字段确认证据，不把旧0行初稿当缺日志。

prior-evidence-comparison.json显示：8流选中字节封套SHA均与20261014-211320批次相同，尽管原流截点更晚，六局没有新增对照结果。旧报告仅作为来源链与历史边界读回；本轮6995行和37项事实独立读原字节核验，没有重跑未变的旧消费者、模拟或生产测试，也没有借用历史绿记录。

关键证据：VLZ F35/F43神化7到5能及已观察手牌升级；F45药水1到2能、HP67不变、实抽工具/生存者，末轮32血20挡对59。CA5 F13蚌力量0/4/8和喷水11/15/19，虚弱后11/14。61E F17 T6负敏捷下两防御各3，敌HP67到34；F23 T4本体/幻象76/14到41/2，玩家25到10。DUZ F30临时减力2到-4、后轮恢复成长4，对应20/14/22。5PM末试F39 T2冒泡付1能、无毒目标仍35HP/0毒。

8JRE F33首/三试T2指纹相同，原SL两线死亡样本0/24与5/24不同；实际T2到T3玩家47到44/32，敌326到316/309，即多12血仅多7净扣。它仍不认证完整候选执行或未选整战胜负。第二试T5原HP护栏在rationale中，缺结构hp_guard不等没有护栏。

## 现有源码与实际live覆盖

只读live快照={source['live_head']}。22个相关源码/消费者路径中18个逐字相同；4个差异文件仅Roy/Dai历史注释署名，完整base-live-source.patch保留。源码SHA、实际祖先与局部截段见source-audit.json、source-excerpts/。未将源码存在或main中的提交自动视为完整实现。

实际live祖先包括：772b839f8ada31664cb764ea9ad3bdb03da27f64（神化基础）、f516592fff557ef02c8ece43433706358c3f7fe6（触媒升级）、b2805be4ba44b7375c7908d873889372cc3cfe6c（萎靡升级）、ba23ca693151fa8c6f7fe035e640dc30f05ccd75（致命毒药升级）、3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化候选事实）、05cd292c6f01bb31e406473d3a9843e659d62b93（三阶段选择事实）、a8b1f8be153fe4f3a34146117546c2178f2e446b（局部审计集成）、cf72bd21148059f111f760cc98a727369e34a47e（离线观测工具）。均为已有窄源，非本批实现/合入commit。

现行神化参考actual_cast_this_fight仍为null；求解器对重放、自动出牌及虚弱/脆弱/缩小/暗影组合保留未验证。三阶段选择审计的actual_turn为null，单动作回执state_effect_verified=false且whole_plan_executed=null；离线消费者也保留actual_full_candidate_result=null。这些边界不证明没有实打动作或机制无效，也不足以认证宽提案。此次无新反证，不把缺口扩大为新游戏规律。

## 逐项处置

| 原id | 状态 | 具体原因 |
|---|---|---|
{result_table}

逐项证据局号/层/回合、原账本id、反例、旧/预期行为、验证和回退详见{HERE / 'proposal.md'}。原提案SHA全部匹配，十项均保留，不新增重复CLI id、不改原提案。implementation_domains=[]是因为本批无新实现；code_proposals沿用十个已登记id。

## 记录、验证和交接

仅经根learner/ledger.py update为26条相关静默原账本追加by=learner:strategy-proposal、proposal/report链接及核验说明。不重添已有证据，不改claim/status/version/first_run/prior/asc或shipped历史；已shipped条目不退回proposed。更新输入和实际CLI回执另存本目录。队列仅通过最终proposal_results交原调度器处置，不手改learn.json或队列。

本次没有源码，所以撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试，不报告0。合入流程未启动，merged=null，无eval版本、shipped、上线记录或规则双通知。工作树内仅保存忽略的研究材料。没有新实现或可归因收益，报告不冒称经验入库、大脑已采用、学习父要求关闭。

失败/限制保留：开工一次README读取被沙箱glob扫描的并行回收路径消失阻断，重试成功；两次探查未存在的辅助路径（silent-combat-facts.ts与工作树ops/codex-ops/learner）失败，不据此认定证据丢失或生产缺陷。一次账本命令输出过长，原文件快照保留并改为有界摘要。旧运行code均带dirty，不能凭Git提交复原当时全部知识/随机池；六局是历史发现样本，没有新后置盲测或整战反事实。

交运维proposal路径：{HERE / 'proposal.md'}。
report：{HERE / 'report.md'}。
'''
(HERE / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in assigned], 'implementation_domains': [],
          'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
ids = sorted({ident for p in assigned for ident in p['ledger']})
updates = [{'id': ident, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
            'note': f'{BATCH}逐项核原十提案；8流6995原行字节/身份/SHA及37项原帧事实通过，相关22源码叶/8实际live窄源祖先已核。十项均waiting，缺口详见报告；无新证据计数、源码、合入或规则更改，旧claim/首证/prior/status/version及shipped历史保持。'}
           for ident in ids]
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'report': str(HERE / 'report.md'), 'proposal': str(HERE / 'proposal.md'),
                  'proposal_results': len(results), 'ledger_links': len(updates)}, ensure_ascii=False))

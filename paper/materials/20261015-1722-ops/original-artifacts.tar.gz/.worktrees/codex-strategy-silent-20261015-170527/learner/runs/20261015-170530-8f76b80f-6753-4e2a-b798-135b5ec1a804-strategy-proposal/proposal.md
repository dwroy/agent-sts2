# 本批静默策略提案逐项复核

批次：20261015-170527-strategy-proposal；角色：silent；基线：`e8931a14f1f9b0bf055f4e44d63ac14e5a13f592`。
本批只处理派来的10个既有CLI id，未领取其他条目、未新建重复提案。所有条目本次处置为waiting；部分诊断已经live，但整项范围尚未满足。

证据范围：六局均经runs.jsonl核实为Silent A10；本批不重算原提案提及的101/102/103/104局历史分母。没有新增游戏规则、固定门槛或经验；未修改源码、知识、版本及live。下列“下一步”是补证条件，不是已验证规则。

## silent-proposal-366288801d9150d9

来源任务：postmortem → strategy-proposal；已登记领域：sl, combat。
既有学习账本：silent-0079、silent-0176。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md`；原SHA256=`0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`，与实际文件一致；本批原字节副本为`366288801d9150d9.original.md`。

证据局/层/回合：751FN9QM9MHQ，F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820。
核实观察与反例：同指纹实际净扣敌血9→18、12→18、17→11；实际损血13→18、13→23、8→2。三组均有双向资源代价，六次同局均未胜。
处置：**waiting**。现有SL资源比较、选择阶段、持牌损血预测及单动作回执已覆盖部分审计。仍缺重问后候选到整轮执行的完整归属，以及原/换线保持其他后继条件一致的整战结果；不能据此设额外失血门槛。
预期行为及验证方法：须补原答、护栏后、SL后及抽弃续问的完整动作链，逐源核实实际整轮血价；若拟改探索准入，再用独立后期局验证，而非把六次当六局。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-85929bdfc8a3fc1b

来源任务：postmortem → strategy-proposal；已登记领域：combat, potion。
既有学习账本：silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md`；原SHA256=`d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`，与实际文件一致；本批原字节副本为`85929bdfc8a3fc1b.original.md`。

证据局/层/回合：751FN9QM9MHQ，F13 T3；decisions 272361；F17 T7/T13/T17。
核实观察与反例：F13用药plan2与全程无药plan5的原模型均8/8结束、损8；牌伤26/16，预计结束轮约2.3/2.9。plan3只限制本轮无药，不能代替plan5。成本0的原文明确为药水表未加载。
处置：**waiting**。未知持有值和未决弃牌的保守持牌损血已具备live结构字段；仍缺实际无药整战、留药至boss后继，以及弃呼唤后逐源完整结算，不校准留药血价或改变弃牌。
预期行为及验证方法：补同入口用药/整战无药分支和后续保留药水的真实战斗；完成弃牌选择后重新读手牌，不从保守预测预扣一张呼唤。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-efd9f83ee9e1a6dc

来源任务：experience-update → strategy-proposal；已登记领域：sl, combat。
既有学习账本：silent-0079、silent-0176。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md`；原SHA256=`0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`，与实际文件一致；本批原字节副本为`efd9f83ee9e1a6dc.original.md`。

证据局/层/回合：751FN9QM9MHQ，F17 T2/T7/T13；与366288801d9150d9同组冻结实盘证据。
核实观察与反例：实盘支持多9净扣付5血、多6净扣付10血、省6血少6净扣；这不是三条独立胜率实验。原经验的历史分母未在本批全量重算，不借原文声称重新验证。
处置：**waiting**。现有候选资源差仍是预测，actual_turn_result=null；缺单因受控后继、整轮逐源兑现和独立时间留出，不能把已有局部诊断认作整个规则提案duplicate。
预期行为及验证方法：与原复盘提案共用证据、保留独立CLI id；补完整后继链后再验证SL排序，未知整战收益继续保留。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-131042659448ae74

来源任务：experience-update → strategy-proposal；已登记领域：combat, potion。
既有学习账本：silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md`；原SHA256=`b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`，与实际文件一致；本批原字节副本为`131042659448ae74.original.md`。

证据局/层/回合：751FN9QM9MHQ，F13 T3、F17 T3/T5/T7/T13/T17；decisions 272361及上述配对。
核实观察与反例：本批独立复核同题用药/无药预测和SL净血差；原提案的敏捷、毒、荆棘及路线子机制分别有既有账本，不能将所有子机制共用一个有效样本数或净差来源。
处置：**waiting**。保守持牌损血、未知持药值及单动作回执只完成结构子项；仍缺攻击/毒/荆棘逐源归属、能力后继兑现和完整无药跨战结果，不标整项duplicate或调整规则。
预期行为及验证方法：每个子机制各自核实际来源、动作和完整后继；本批净敌血差不作为毛攻击伤或毒伤，原历史101局计数不冒称本批复算。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-990f054036609447

来源任务：experience-update → strategy-proposal；已登记领域：combat, sl。
既有学习账本：silent-0102、silent-0019、silent-0020。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md`；原SHA256=`c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`，与实际文件一致；本批原字节副本为`990f054036609447.original.md`。

证据局/层/回合：KV0JHNJCKXLS，F33第4/5试T5；对应原决策、SL summary相邻回合。
核实观察与反例：同入口30血/敌334血，第5试删致命毒药后净扣36→29，当轮两次均零损。后续动作亦改变；原日志存在敌回血，净血差不能当毛伤。
处置：**waiting**。缺保持其他后继条件的完整对照、敌回血与各输出来源的候选归属，以及未走路线/休息分支实果；当前局部分账不足确定SL或终局权重。
预期行为及验证方法：记录敌回血、已结毒、直接攻击及未结部分，单列已兑现休息/开场回血/SL恢复；不能补写判死截断后的结算或将未走营火当回血。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-e18d3f18e6cac2a0

来源任务：postmortem → strategy-proposal；已登记领域：combat, potion, sl, terminal。
既有学习账本：silent-0017、silent-0250、silent-0011、silent-0027、silent-0046。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md`；原SHA256=`3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`，与实际文件一致；本批原字节副本为`e18d3f18e6cac2a0.original.md`。

证据局/层/回合：YQL8RZ8BWN1E F17末试T10，states 280160/280161；L9SGRBB5R698 sl-attempts 681；PU80F84P6HPN 717；YQL 960—963。
核实观察与反例：YQL残壳毒2→8，但26血/13挡/自爆41不变，纯算术26+13−41=−2。L9参考含999999999，PU同T17比较999999981/999999989；均非未打完本体。PU第5试F17实际won，保留其胜线反例。
处置：**waiting**。巨兽阶段和末态资源的事实已有live祖先实现；anchorRank仍按原始显示HP作同轮tie-break。缺候选排序改变后的受控完整后继和资源/结局验证，不将部分阶段修复标作整项完成。
预期行为及验证方法：保留原排序和原HP记录，若提出新的排序须冻结新旧参考选择与本体结束、自爆、药水、净HP分项；不能直接把残壳HP归零后宣称改进。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-9733bb80f445aeae

来源任务：experience-update → strategy-proposal；已登记领域：combat, potion, sl, terminal。
既有学习账本：silent-0017、silent-0019、silent-0020、silent-0250。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md`；原SHA256=`c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`，与实际文件一致；本批原字节副本为`9733bb80f445aeae.original.md`。

证据局/层/回合：YQL8RZ8BWN1E F17末试T10，states 280160/280161；并复核L9/PU巨兽历史参考。
核实观察与反例：毒水只增加本次残壳毒层；当前HP、挡、自爆没有变化。YQL六次未胜，而PU有实际胜线，说明本体结束与整战胜负必须分开。
处置：**waiting**。当前巨兽药水事实已列本次2→8及当前阶段，仍没有提前饮用/不饮用/留药的受控整战或新SL参考排序验证，不能量化持有值和改序收益。
预期行为及验证方法：补同盘完整用药时点分支及后续存活结果；休息与路线只读实际兑现，不用单次无即时收益推出必须提前喝或必须留药。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-c51468c5e8ba6668

来源任务：postmortem → strategy-proposal；已登记领域：potion。
既有学习账本：silent-0019。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md`；原SHA256=`168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`，与实际文件一致；本批原字节副本为`c51468c5e8ba6668.original.md`。

证据局/层/回合：KEN58SH9SLZ6，F3 T2/F4 T1/F5 T2/F11 T1、T2/F15 T1；decisions 274131/274156/274185/274235/274237/274267/274272。
核实观察与反例：七次use_potion均有对应前后槽位实际消耗：攻击药、稳定血清、速度药、虚弱药、攻击药、发光水、技能药。七组原始状态字节核对通过。
处置：**waiting**。单动作回执和槽位耗空不能证明随机选牌/发光水后重问的完整收益；缺F15不喝及留到boss的整战分支，不能从空药boss失败拟逐槽跨战价值。
预期行为及验证方法：补药后选牌/抽牌/重问到完整轮及下场的实际效果链；用药与不饮用支线均须核入口及后继，不把赢战零损当无药也零损。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-86a7db08d1a31976

来源任务：postmortem → strategy-proposal；已登记领域：combat, sl。
既有学习账本：silent-0079、silent-0021、silent-0125、silent-0005、silent-0176。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md`；原SHA256=`10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`，与实际文件一致；本批原字节副本为`86a7db08d1a31976.original.md`。

证据局/层/回合：KEN58SH9SLZ6，F17第4/5试T10（274505/274568）、第4/6试T5（274484/274601）、第2试T2（274354）。
核实观察与反例：T10同指纹实际净扣2→4、损15→21。T5另一对照实际损7→5、净扣1→2；六次步法实际出牌轮为3/5/5/5/5/9，末试能力明显延迟。
处置：**waiting**。新增持牌损血预测和选择/派发审计已经live，但完整逐源实果、候选归属、受控整战及新局留出仍缺；不能拟通用6血/2伤准入或只按省血排序。
预期行为及验证方法：分别核无实体下的实际逐段伤害、持牌自损、能力建立时点与后继挡牌兑现，再验证更差B2候选准入；不把相关SL拆成训练/验证局。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

## silent-proposal-e282a9131b99129a

来源任务：experience-update → strategy-proposal；已登记领域：combat, sl。
既有学习账本：silent-0021、silent-0079、silent-0125、silent-0176。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md`；原SHA256=`a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`，与实际文件一致；本批原字节副本为`e282a9131b99129a.original.md`。

证据局/层/回合：KEN58SH9SLZ6，F17 T2/T5/T10；同86a7db08d1a31976的冻结局证据。
核实观察与反例：本局既出现多付6血仅增2净扣，也出现少付2血但步法从T5推到T9；两方向共同否定从单一即时指标直接制定通用规则。
处置：**waiting**。六次同局无胜；候选预测与单动作回执不足闭合能力后继和整轮实果，缺受控完整胜线及后期独立验证，保持原探索与HP护栏。
预期行为及验证方法：经验与复盘的两个CLI id分别保留，补完整候选/重问/实际结算链；只在新证据充足时改排序，不用现有框架完成替代量化学习完成。
旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。
样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。

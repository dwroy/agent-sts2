import collections
import hashlib
import json
import re
from pathlib import Path


HERE = Path(__file__).resolve().parent
RUNS = set(json.loads((HERE / 'runs-identity.json').read_text())[i]['run_id'] for i in range(6))


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def entries(stream, directory='evidence'):
    with (HERE / directory / (stream + '.evidence.jsonl')).open() as handle:
        for line in handle:
            yield json.loads(line)


def ref(item):
    return {key: item[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


verified = []
for directory in ('evidence', 'run-identity-evidence'):
    for manifest in json.loads((HERE / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        path = HERE / directory / (stream + '.evidence.jsonl')
        check(stream + ':output_sha', hashlib.sha256(path.read_bytes()).hexdigest(), manifest['output_sha256'])
        count = collections.Counter()
        source = None
        try:
            for item in entries(stream, directory):
                if source is None:
                    source = open(item['source'], 'rb')
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
                row = json.loads(raw)
                assert row == item['row'] and item['offset'] + item['bytes'] <= manifest['source_size']
                state = row.get('state') or {}
                fingerprint = row.get('fingerprint')
                if isinstance(fingerprint, str):
                    try:
                        fingerprint = json.loads(fingerprint)
                    except ValueError:
                        fingerprint = None
                identities = {value for value in [row.get('run_id'), row.get('run'), state.get('run_id'),
                    fingerprint.get('run') if isinstance(fingerprint, dict) else None]
                    if isinstance(value, str) and value and value != 'run_unknown'}
                assert identities == {item['run_id']} and item['run_id'] in RUNS
                count[item['run_id']] += 1
        finally:
            if source is not None:
                source.close()
        check(stream + ':counts', dict(sorted(count.items())), dict(sorted(manifest['counts'].items())))
        verified.append({**manifest, 'verified_original_line_count': sum(count.values())})

identity = [x['row'] for x in entries('runs', 'run-identity-evidence')]
check('identity:exact_runs', sorted(x['run_id'] for x in identity), sorted(RUNS))
check('identity:character_ascension', [(x['character'].lower(), x['ascension']) for x in identity], [('silent', 10)] * 6)

states = {}
compact = []
for item in entries('states'):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    snap = {
        'ref': ref(item), 'ts': item['row'].get('observed_ts', item['row']['ts']),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'), 'powers': player.get('powers'),
        'potions': run.get('potions'), 'selection': state.get('selection'),
        'hand': [{key: c.get(key) for key in ('index', 'card_id', 'name', 'is_playable', 'upgraded', 'dynamic_values')}
                 for c in combat.get('hand', [])],
        'enemies': [{key: e.get(key) for key in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'powers', 'move_id', 'intents')}
                    for e in combat.get('enemies', [])],
    }
    states[item['line']] = snap
    compact.append(snap)
save('states-compact.json', compact)

sl = list(entries('sl-attempts'))
save('attempts-compact.json', [{
    'ref': ref(x), **{key: x['row'].get(key) for key in ('floor', 'encounter', 'attempt', 'started_at', 'ended_at',
        'result', 'turns', 'end_hp', 'end_block', 'incoming', 'judge', 'summary')},
    'anchor': ((x['row'].get('explore') or {}).get('target') or {}).get('anchor'),
} for x in sl])
by_attempt = {(x['run_id'], x['row']['floor'], x['row']['attempt']): x for x in sl}


def enemy_hp(text):
    matches = re.findall(r' (\d+)/(\d+)(?:, |$)', text)
    return sum(int(a) for a, _ in matches) if matches else None


def turn_result(run, floor, attempt, turn):
    item = by_attempt[(run, floor, attempt)]
    turns = {x['turn']: x for x in item['row']['summary']['turns']}
    before, after = turns[turn], turns[turn + 1]
    return {'ref': ref(item), 'before': before, 'after': after,
            'hp_loss': before['hp'] - after['hp'],
            'enemy_net_hp_loss': enemy_hp(before['enemies']) - enemy_hp(after['enemies'])}


pair_specs = [
    ('751FN9QM9MHQ', 17, 1, 3, 2, [13, 9, 18, 18]),
    ('751FN9QM9MHQ', 17, 2, 4, 7, [13, 12, 23, 18]),
    ('751FN9QM9MHQ', 17, 1, 6, 13, [8, 17, 2, 11]),
    ('KV0JHNJCKXLS', 33, 4, 5, 5, [0, 36, 0, 29]),
    ('KEN58SH9SLZ6', 17, 4, 5, 10, [15, 2, 21, 4]),
    ('KEN58SH9SLZ6', 17, 4, 6, 5, [7, 1, 5, 2]),
]
pairs = []
for run, floor, old, new, turn, expected in pair_specs:
    a, b = turn_result(run, floor, old, turn), turn_result(run, floor, new, turn)
    values = [a['hp_loss'], a['enemy_net_hp_loss'], b['hp_loss'], b['enemy_net_hp_loss']]
    check(f'{run}:F{floor}:T{turn}:A{old}/{new}', values, expected)
    pairs.append({'run_id': run, 'floor': floor, 'turn': turn, 'original_attempt': old, 'replacement_attempt': new,
                  'original': a, 'replacement': b,
                  'interpretation': '实际相邻回合净血差；敌方回血、毒、反伤和直伤未由净差分源；相关SL非独立实验。'})
save('paired-turns.json', pairs)

decision_lines = {272434, 272575, 272531, 272652, 272483, 272820, 272361, 274484, 274601, 274505, 274568, 274354}
decisions = list(entries('decisions'))
dec_by_line = {x['line']: x for x in decisions}
for a, b in [(272434, 272575), (272531, 272652), (272483, 272820), (274484, 274601), (274505, 274568)]:
    check(f'fingerprint:{a}/{b}', dec_by_line[a]['row']['fingerprint'], dec_by_line[b]['row']['fingerprint'])
focus_decisions = []
for item in decisions:
    row = item['row']
    if item['line'] not in decision_lines and not (item['run_id'] == 'KV0JHNJCKXLS' and row.get('floor') == 33
            and row.get('sl_attempt') in (4, 5) and row.get('turn') == 5 and row.get('label') == 'combat/plan-choice'):
        continue
    focus_decisions.append({'ref': ref(item), **{key: row.get(key) for key in ('floor', 'turn', 'sl_attempt', 'fingerprint',
        'questions', 'answers', 'chosen', 'expect', 'result', 'rationale', 'boss_sim', 'rollout', 'sl_explore')}})
save('decisions-focus.json', focus_decisions)

clam = dec_by_line[272361]['row']['questions']['plan']['criteria']
clam_options = {key: json.loads(clam[key]) for key in ('plan2', 'plan3', 'plan5')}
check('751:clam:hp_losses', [clam_options[key]['hp_lost'] for key in clam_options], [8, 8, 8])
check('751:clam:card_damage', [clam_options[key]['damage_dealt'] for key in clam_options], [26, 16, 16])
check('751:clam:full_dry_reference', 'no potion for the rest of this fight' in clam_options['plan5']['no_potion_fight'], True)
check('751:clam:no_table_cost', 'potion table did not load' in clam_options['plan2']['potion_cost'], True)
check('751:clam:sampled_8_of_8', ['in 8/8' in clam_options[key]['rollout'] for key in ('plan2', 'plan5')], [True, True])
save('clam-potion-model.json', {'ref': ref(dec_by_line[272361]), 'options': clam_options,
    'limit': '这些均为原日志模型抽样，不是无药实际整战、留药后继或已校准持药价格。plan3只当轮无药，plan5才限定整战无药。'})

ken_potions = [x for x in decisions if x['run_id'] == 'KEN58SH9SLZ6' and (x['row'].get('chosen') or {}).get('action') == 'use_potion']
check('KEN:potion_decision_lines', [x['line'] for x in ken_potions], [274131, 274156, 274185, 274235, 274237, 274267, 274272])
potion_specs = [(274131, 280206, 280207, 0, 'ATTACK_POTION'), (274156, 280232, 280233, 0, 'STABLE_SERUM'),
    (274185, 280262, 280263, 0, 'SPEED_POTION'), (274235, 280313, 280314, 1, 'WEAK_POTION'),
    (274237, 280315, 280316, 0, 'ATTACK_POTION'), (274267, 280348, 280349, 1, 'GLOWWATER_POTION'),
    (274272, 280354, 280355, 0, 'SKILL_POTION')]
potion_audit = []
for decision, before, after, slot, ident in potion_specs:
    a, b = states[before], states[after]
    check(f'KEN:{ident}:{decision}:before_slot', a['potions'][slot]['potion_id'], ident)
    check(f'KEN:{ident}:{decision}:after_slot', b['potions'][slot]['occupied'], False)
    potion_audit.append({'decision': ref(dec_by_line[decision]), 'before': a, 'after': b,
        'limit': '已核实际槽位消耗；不能由单动作或即时状态变化推断留药跨战价值或完整方案执行。'})
save('potion-consumption.json', potion_audit)

ken_footwork = [x for x in decisions if x['run_id'] == 'KEN58SH9SLZ6' and x['row'].get('floor') == 17
    and (x['row'].get('chosen') or {}).get('action') == 'play_card'
    and ((x['row'].get('expect') or {}).get('card') or {}).get('id') == 'FOOTWORK']
check('KEN:footwork_play_turns', [x['row']['turn'] for x in ken_footwork], [3, 5, 5, 5, 5, 9])
save('footwork-dispatches.json', [{'ref': ref(x), **{key: x['row'].get(key)
    for key in ('turn', 'sl_attempt', 'chosen', 'expect', 'result')}} for x in ken_footwork])


def power(snapshot, ident):
    return next((p['amount'] for p in snapshot['enemies'][0]['powers'] if p['power_id'] == ident), 0)


a, b = states[280160], states[280161]
check('YQL:poison_before_after', [power(a, 'POISON_POWER'), power(b, 'POISON_POWER')], [2, 8])
check('YQL:hp_block_unchanged', [a['hp'], a['block'], b['hp'], b['block']], [26, 13, 26, 13])
check('YQL:blast_unchanged', [a['enemies'][0]['intents'][0]['damage'], b['enemies'][0]['intents'][0]['damage']], [41, 41])
check('YQL:husk_max_hp', [a['enemies'][0]['max_hp'], b['enemies'][0]['max_hp']], [999999999, 999999999])
anchors = [{'ref': ref(x), 'anchor': ((x['row'].get('explore') or {}).get('target') or {}).get('anchor')}
    for x in sl if x['line'] in {681, 717, 960, 961, 962, 963}]
by_anchor_line = {x['ref']['line']: x['anchor'] for x in anchors}
check('L9:anchor_husk_hp', by_anchor_line[681]['ranked'][0]['enemyHp'], 999999999)
check('PU:anchor_husk_hp', [x['enemyHp'] for x in by_anchor_line[717]['ranked']], [999999981, 999999989])
check('YQL:anchor_husk_hp', [x['enemyHp'] for x in by_anchor_line[960]['ranked']], [999999990, 999999999])
for line in [961, 962, 963]:
    check('YQL:anchor_present:' + str(line), isinstance(by_anchor_line[line]['ranked'], list) and len(by_anchor_line[line]['ranked']) >= 3, True)
save('giant-phase-facts.json', {'before': a, 'after': b, 'arithmetic_hp_after_plain_blast': 26 + 13 - 41,
    'limit': '仅该次饮用前后事实；没有提前用药或留药整战反事实。算术负2与游戏死亡截断0分开。',
    'historical_anchors': anchors})
for run in ['751FN9QM9MHQ', 'YQL8RZ8BWN1E', 'KEN58SH9SLZ6', 'L9SGRBB5R698']:
    rows = [x['row'] for x in sl if x['run_id'] == run and x['row']['floor'] == 17]
    check(run + ':six_attempts_no_win', [len(rows), sum(x['result'] == 'won' for x in rows)], [6, 0])
pu = by_attempt[('PU80F84P6HPN', 17, 5)]['row']
check('PU:F17:A5_won', pu['result'], 'won')
save('evidence-verification.json', {'streams': verified, 'checks': checks, 'passed': all(x['passed'] for x in checks),
    'check_count': len(checks), 'verified_raw_lines': sum(x['verified_original_line_count'] for x in verified)})
print(json.dumps({'passed': all(x['passed'] for x in checks), 'checks': len(checks),
    'raw_lines': sum(x['verified_original_line_count'] for x in verified),
    'failures': [x for x in checks if not x['passed']]}, ensure_ascii=False))
raise SystemExit(0 if all(x['passed'] for x in checks) else 1)

import datetime
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
binding = json.loads((HERE / 'batch-binding.json').read_text())
props = json.loads((HERE / 'dispatched-proposals.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
audit = json.loads((HERE / 'evidence-verification.json').read_text())
assert audit['passed']

details = {
    '366288801d9150d9': (
        '751FN9QM9MHQ，F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820。',
        '同指纹实际净扣敌血9→18、12→18、17→11；实际损血13→18、13→23、8→2。三组均有双向资源代价，六次同局均未胜。',
        '现有SL资源比较、选择阶段、持牌损血预测及单动作回执已覆盖部分审计。仍缺重问后候选到整轮执行的完整归属，以及原/换线保持其他后继条件一致的整战结果；不能据此设额外失血门槛。',
        '须补原答、护栏后、SL后及抽弃续问的完整动作链，逐源核实实际整轮血价；若拟改探索准入，再用独立后期局验证，而非把六次当六局。'),
    '85929bdfc8a3fc1b': (
        '751FN9QM9MHQ，F13 T3；decisions 272361；F17 T7/T13/T17。',
        'F13用药plan2与全程无药plan5的原模型均8/8结束、损8；牌伤26/16，预计结束轮约2.3/2.9。plan3只限制本轮无药，不能代替plan5。成本0的原文明确为药水表未加载。',
        '未知持有值和未决弃牌的保守持牌损血已具备live结构字段；仍缺实际无药整战、留药至boss后继，以及弃呼唤后逐源完整结算，不校准留药血价或改变弃牌。',
        '补同入口用药/整战无药分支和后续保留药水的真实战斗；完成弃牌选择后重新读手牌，不从保守预测预扣一张呼唤。'),
    'efd9f83ee9e1a6dc': (
        '751FN9QM9MHQ，F17 T2/T7/T13；与366288801d9150d9同组冻结实盘证据。',
        '实盘支持多9净扣付5血、多6净扣付10血、省6血少6净扣；这不是三条独立胜率实验。原经验的历史分母未在本批全量重算，不借原文声称重新验证。',
        '现有候选资源差仍是预测，actual_turn_result=null；缺单因受控后继、整轮逐源兑现和独立时间留出，不能把已有局部诊断认作整个规则提案duplicate。',
        '与原复盘提案共用证据、保留独立CLI id；补完整后继链后再验证SL排序，未知整战收益继续保留。'),
    '131042659448ae74': (
        '751FN9QM9MHQ，F13 T3、F17 T3/T5/T7/T13/T17；decisions 272361及上述配对。',
        '本批独立复核同题用药/无药预测和SL净血差；原提案的敏捷、毒、荆棘及路线子机制分别有既有账本，不能将所有子机制共用一个有效样本数或净差来源。',
        '保守持牌损血、未知持药值及单动作回执只完成结构子项；仍缺攻击/毒/荆棘逐源归属、能力后继兑现和完整无药跨战结果，不标整项duplicate或调整规则。',
        '每个子机制各自核实际来源、动作和完整后继；本批净敌血差不作为毛攻击伤或毒伤，原历史101局计数不冒称本批复算。'),
    '990f054036609447': (
        'KV0JHNJCKXLS，F33第4/5试T5；对应原决策、SL summary相邻回合。',
        '同入口30血/敌334血，第5试删致命毒药后净扣36→29，当轮两次均零损。后续动作亦改变；原日志存在敌回血，净血差不能当毛伤。',
        '缺保持其他后继条件的完整对照、敌回血与各输出来源的候选归属，以及未走路线/休息分支实果；当前局部分账不足确定SL或终局权重。',
        '记录敌回血、已结毒、直接攻击及未结部分，单列已兑现休息/开场回血/SL恢复；不能补写判死截断后的结算或将未走营火当回血。'),
    'e18d3f18e6cac2a0': (
        'YQL8RZ8BWN1E F17末试T10，states 280160/280161；L9SGRBB5R698 sl-attempts 681；PU80F84P6HPN 717；YQL 960—963。',
        'YQL残壳毒2→8，但26血/13挡/自爆41不变，纯算术26+13−41=−2。L9参考含999999999，PU同T17比较999999981/999999989；均非未打完本体。PU第5试F17实际won，保留其胜线反例。',
        '巨兽阶段和末态资源的事实已有live祖先实现；anchorRank仍按原始显示HP作同轮tie-break。缺候选排序改变后的受控完整后继和资源/结局验证，不将部分阶段修复标作整项完成。',
        '保留原排序和原HP记录，若提出新的排序须冻结新旧参考选择与本体结束、自爆、药水、净HP分项；不能直接把残壳HP归零后宣称改进。'),
    '9733bb80f445aeae': (
        'YQL8RZ8BWN1E F17末试T10，states 280160/280161；并复核L9/PU巨兽历史参考。',
        '毒水只增加本次残壳毒层；当前HP、挡、自爆没有变化。YQL六次未胜，而PU有实际胜线，说明本体结束与整战胜负必须分开。',
        '当前巨兽药水事实已列本次2→8及当前阶段，仍没有提前饮用/不饮用/留药的受控整战或新SL参考排序验证，不能量化持有值和改序收益。',
        '补同盘完整用药时点分支及后续存活结果；休息与路线只读实际兑现，不用单次无即时收益推出必须提前喝或必须留药。'),
    'c51468c5e8ba6668': (
        'KEN58SH9SLZ6，F3 T2/F4 T1/F5 T2/F11 T1、T2/F15 T1；decisions 274131/274156/274185/274235/274237/274267/274272。',
        '七次use_potion均有对应前后槽位实际消耗：攻击药、稳定血清、速度药、虚弱药、攻击药、发光水、技能药。七组原始状态字节核对通过。',
        '单动作回执和槽位耗空不能证明随机选牌/发光水后重问的完整收益；缺F15不喝及留到boss的整战分支，不能从空药boss失败拟逐槽跨战价值。',
        '补药后选牌/抽牌/重问到完整轮及下场的实际效果链；用药与不饮用支线均须核入口及后继，不把赢战零损当无药也零损。'),
    '86a7db08d1a31976': (
        'KEN58SH9SLZ6，F17第4/5试T10（274505/274568）、第4/6试T5（274484/274601）、第2试T2（274354）。',
        'T10同指纹实际净扣2→4、损15→21。T5另一对照实际损7→5、净扣1→2；六次步法实际出牌轮为3/5/5/5/5/9，末试能力明显延迟。',
        '新增持牌损血预测和选择/派发审计已经live，但完整逐源实果、候选归属、受控整战及新局留出仍缺；不能拟通用6血/2伤准入或只按省血排序。',
        '分别核无实体下的实际逐段伤害、持牌自损、能力建立时点与后继挡牌兑现，再验证更差B2候选准入；不把相关SL拆成训练/验证局。'),
    'e282a9131b99129a': (
        'KEN58SH9SLZ6，F17 T2/T5/T10；同86a7db08d1a31976的冻结局证据。',
        '本局既出现多付6血仅增2净扣，也出现少付2血但步法从T5推到T9；两方向共同否定从单一即时指标直接制定通用规则。',
        '六次同局无胜；候选预测与单动作回执不足闭合能力后继和整轮实果，缺受控完整胜线及后期独立验证，保持原探索与HP护栏。',
        '经验与复盘的两个CLI id分别保留，补完整候选/重问/实际结算链；只在新证据充足时改排序，不用现有框架完成替代量化学习完成。'),
}

results = []
proposal = [
    '# 本批静默策略提案逐项复核', '',
    f'批次：{binding["batch"]}；角色：silent；基线：`{binding["base"]}`。',
    '本批只处理派来的10个既有CLI id，未领取其他条目、未新建重复提案。所有条目本次处置为waiting；部分诊断已经live，但整项范围尚未满足。', '',
    '证据范围：六局均经runs.jsonl核实为Silent A10；本批不重算原提案提及的101/102/103/104局历史分母。'
    '没有新增游戏规则、固定门槛或经验；未修改源码、知识、版本及live。下列“下一步”是补证条件，不是已验证规则。', '',
]
for item in props:
    ident = item['id']
    evidence, observation, reason, next_step = details[ident.removeprefix('silent-proposal-')]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    proposal += [f'## {ident}', '',
        f'来源任务：{item["source_task"]} → strategy-proposal；已登记领域：{", ".join(item["domains"])}。',
        '既有学习账本：' + '、'.join(item['ledger']) + '。',
        f'原提案：`{item["proposal"]}`；原SHA256=`{item["proposal_sha256"]}`，与实际文件一致；本批原字节副本为`{ident.removeprefix("silent-proposal-")}.original.md`。', '',
        f'证据局/层/回合：{evidence}', f'核实观察与反例：{observation}',
        f'处置：**waiting**。{reason}', f'预期行为及验证方法：{next_step}',
        '旧/新规则：本批保持现行出牌、药水、SL和HP护栏；不拟合新权重。未证实的长期收益继续为未知；其他角色与未观察进阶没有变动。',
        '样本与回退：同局SL视为相关重复，不当独立验证；未来规则拟合须按独立局和时间留出。当前无源码提交，无需回滚；保留原失败、未知及证据。', '',
    ]
(HERE / 'proposal.md').write_text('\n'.join(proposal))

final = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': binding['batch'], 'base': binding['base'],
    'runs': binding['row']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [x['id'] for x in props], 'implementation_domains': [],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
(HERE / 'report.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

stream_rows = '\n'.join(f'| {x["stream"]} | {x["source_size"]} | {x["verified_original_line_count"]} | {x["invalid_lines"]} |'
    for x in audit['streams'])
source_rows = '\n'.join(f'| `{x["path"]}` | `{x["live_last_change"]}` | {"相同" if x["equal"] else "仅历史人物名注释差"} |'
    for x in source['leaves'])
result_rows = '\n'.join(f'| {x["id"]} | {"、".join(p["ledger"])} | waiting |'
    for x, p in zip(results, props))
pair_rows = '\n'.join(f'| {x["run_id"]} | F{x["floor"]}/T{x["turn"]} | {x["original_attempt"]}→{x["replacement_attempt"]} | '
    f'{x["original"]["hp_loss"]}→{x["replacement"]["hp_loss"]} | '
    f'{x["original"]["enemy_net_hp_loss"]}→{x["replacement"]["enemy_net_hp_loss"]} |'
    for x in json.loads((HERE / 'paired-turns.json').read_text()))
report = f'''# 本批策略任务报告

本批10个提案均已逐项处理，结论为waiting。没有新源码、知识或游戏规则变动，没有提交、合入、发布编号或shipped登记；原有诊断覆盖只计为部分已有实现，不据此关闭宽提案。详细逐项证据、反例、预期行为及补证条件见[proposal.md](proposal.md)。

记录时间：{datetime.datetime.now().astimezone().isoformat(timespec='seconds')}。
任务：strategy-proposal；角色：silent；批次：{binding['batch']}。
完整基线：`{binding['base']}`。初始工作树干净，核身份后执行`git merge --no-edit main`，结果Already up to date；HEAD未变。
调度行task/character/worktree/runs/10个proposal_ids已核，reason=proposal，没有research_request、implementation_request或proposal_repair。普通任务只读的deck-size专题请求绑定另一批，不适用于本批，因此没有读取其work_spec/manifest或其他专题请求。没有派下级agent。

## 原始证据及复核

六局为751FN9QM9MHQ、KV0JHNJCKXLS、YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN、KEN58SH9SLZ6；runs原始行各1，角色均SILENT、进阶均10。原局code带dirty，未重构或冒认当时完整执行源码；当前live源码核对仅用于认定已有实现边界。

按指定extract_evidence.py入口提取六个默认流，另以同入口抽取runs流。各流保留source_size、每行原offset/bytes/SHA256、明确身份和逐局计数；本批没有重用旧零行截点，也未据零行断言日志缺失。

| 流 | 原字节截点 | 已核所属原始行 | 源流无效行数 |
| --- | ---: | ---: | ---: |
{stream_rows}

总计8444条明确所属的原始行，逐条seek回原日志复核原字节SHA、JSON正文、截点范围、无身份冲突；每个输出文件SHA与manifest相符。全局源流的无效行计数不表示这些六局丢帧。最终证据工具63项检查通过（`evidence-verification.json`、`evidence-audit-anchor-corrected.log`）；这是材料一致性核验，不是tsc/vitest、游戏策略泛化或收益测试。

| 局 | 层/回合 | 尝试 | 实际玩家净损血 | 实际敌人净扣血 |
| --- | --- | --- | ---: | ---: |
{pair_rows}

表内是相邻回合实盘净差，不把敌回血/毒/荆棘合成直伤毛伤。五组指定决策指纹配对相同；KV使用原第4/5试T5同入口及相邻summary核差，后轮动作改变不能归为单因实验。751六试、KEN六试均无胜；省血也可能损失输出或能力建立窗口，不能从单个指标拟统一SL准入。KEN步法实际出牌轮3/5/5/5/5/9已核，不预支能力长期分数为当前格挡。

751 F13 T3用药plan2与整战无药plan5的原模型均8/8结束且损8，但伤26/16、结束轮约2.3/2.9；plan3可能后轮用药，不能当整战无药。原成本0注明缺表，不能当已经量化的持药0价值。此处只读原模拟，不重跑模拟、模型或网络。

KEN七次实际use_potion和七组槽位前后均核：F3攻击药、F4稳定血清、F5速度药、F11虚弱药及攻击药、F15发光水及技能药。实际槽位耗空不证明随机选牌和重问后整条方案收益；不存在本批可核的F15不喝/留到boss受控整战。

巨兽YQL F17 T10原states 280160/280161：残壳毒2→8，血26、挡13、来袭41不变，max_hp=999999999；算术−2与死亡截断0分开。L9原sl-attempts681和PU717及YQL960—963的anchor位于`explore.target.anchor`，原占位值已逐项核实。PU F17第5试实际won，不能把YQL/L9失败当阶段必败或将本体结束当整战获胜。

## 当前已有源码范围

只读live快照：`{source['live_snapshot']}`。以下每个源变更提交均已核为该live HEAD祖先；所列路径在live工作区没有未提交改动。它们是既有代码，不是本批实现或本批新发布。

| 核对源码 | live最近变更祖先 | 与本基线字节 |
| --- | --- | --- |
{source_rows}

14个源码叶中12个字节相同；explore.ts和potion-cost.ts仅保留Roy/Dai历史注释差，完整`git diff --binary`见source-comparison.patch，未为对齐而改写。所需基线源码原字节仅按叶保存到source-leaves/*.txt，无整个源码归档或可执行.ts副本。

未决弃牌的持牌损血已由silent-held-loss暴露，未知持药价与整战无药参考已由silent-potion-reference暴露；SL资源比较和候选阶段已记录预测，selection-dispatch只证明单次派发回执。actual_turn_result/actual_turn仍为null，不能视为毒/攻击/反伤逐源结算或完整方案兑现。巨兽阶段/当前药水事实/特定末态资源已有祖先源码，但anchorRank仍以原始显示敌HP作同存活轮tie-break。阶段诊断已存在，不足以证明替换排序或跨战留药参数有效。

## 每项处置

| 派发CLI id | 既有学习账本 | 处置 |
| --- | --- | --- |
{result_rows}

全部具体缺口见proposal.md相应id。没有因“现规则由人制定”转待审批；等待原因是缺完整执行归属、单因受控后继或独立时间验证。已经完成的诊断子项保留真实live祖先证据，不冒记整个提案duplicate/implemented。

## 验证、记录与限制

没有生产源码改动，因此未跑tsc、vitest或撤源码负控；tests固定为null/null/null，不填0。没有git commit/live merge/eval版本，也未通知为已上线。所有实盘差额与原模型抽样分开，没有用六次SL作六个独立样本。原提案与知识提及的全历史分母不在本批范围，未冒称重新计算；待定药水/SL/终局价值继续未知。父要求保持开放，报告完成不等于知识已入库或大脑已消费。

只经根目录ledger.py update追加本批提案/报告路径及waiting追溯；已有条目的claim、first_run、prior、evidence、status和经验版本不覆写，不将已有shipped知识条目降为proposed。没有新游戏经验，所以不新建账本或重复code_proposals id；最终code_proposals为原10个CLI id，implementation_domains为空（本批实际没有代码实现）。最终CLI读回与工作树验收见completion-verification.json；账本仅增加追溯记录，不代ops登记shipped。

过程偏差如实保留：一次过宽rg命中测试夹具中的非本角色知识文本；该输出立即排除，后续只查明确源码路径，本报告数值均由六局原始行独立复核。不能宣称本次全程零接触非本角色材料，本批不新增游戏规则或泛化学习结论。另有两个不存在源码路径的初探及非战斗combat=null的结构探查报错，随后改为明确存在路径及空值处理；这些不是产品代码或游戏测试失败。证据辅助脚本初版把anchor误取在explore顶层，旧空字段产物和50/55项日志保留为*.before-anchor-fix.txt；发现后改用真实explore.target.anchor并增加断言，最终63项通过。没有覆盖失败日志或把初版未验范围报成已经验证。

材料索引：batch-binding.json、dispatched-proposals.json、10份原提案副本、ledger-before.json、experience-linked.json、原始evidence及run-identity-evidence、paired-turns.json、decisions-focus.json、clam-potion-model.json、potion-consumption.json、footwork-dispatches.json、giant-phase-facts.json、source-readback.json、ledger-updates.jsonl/回执、completion-verification.json、report.json。未清理本工作树及原日志。
'''
(HERE / 'report.md').write_text(report)

ledger_to_ids = {}
for item in props:
    for ident in item['ledger']:
        ledger_to_ids.setdefault(ident, []).append(item['id'])
updates = []
for ident, linked in sorted(ledger_to_ids.items()):
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(HERE / 'proposal.md') + '#' + p for p in linked] + [str(HERE / 'report.md')]},
        'note': f'本批{binding["batch"]}复核：' + '、'.join(linked) +
            '均waiting；六局原始证据与live已有部分诊断已核，具体缺口见逐项提案。无新源码/新游戏规则/合入/版本；不改原claim、证据和状态，不登记shipped。'})
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'proposal_results': len(results), 'ledger_updates': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

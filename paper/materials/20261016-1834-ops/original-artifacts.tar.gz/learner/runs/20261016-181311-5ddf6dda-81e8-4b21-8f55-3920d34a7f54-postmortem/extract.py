import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261016-181311-5ddf6dda-81e8-4b21-8f55-3920d34a7f54-postmortem'
run='JH49PP3EYJH8'; needle=run.encode()
for name in ['decisions','run-plans','states','sl-attempts','run-config','brain','jev-prompts','fight-plans','codex-usage','codex-calls']:
    src=root/'logs'/f'{name}.jsonl'
    if not src.exists():continue
    n=0; offset=0; cutoff=src.stat().st_size
    with src.open('rb') as f,(out/f'{name}.jsonl').open('w') as w:
        for line_no,b in enumerate(f,1):
            here=offset;offset+=len(b)
            if offset>cutoff:break
            if needle not in b:continue
            try:r=json.loads(b)
            except ValueError:continue
            w.write(json.dumps({'_line':line_no,'_offset':here,**r},ensure_ascii=False)+'\n');n+=1
    print(name,n,flush=True)
dec=[json.loads(x) for x in (out/'decisions.jsonl').open()]
start=min(x['ts'] for x in dec);end=max(x['ts'] for x in dec)
n=0; offset=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-reasoning-window.jsonl').open('w') as w:
    for line_no,b in enumerate(f,1):
        here=offset;offset+=len(b)
        try:r=json.loads(b)
        except ValueError:continue
        if start<=r.get('ts','')<=end:
            w.write(json.dumps({'_line':line_no,'_offset':here,**r},ensure_ascii=False)+'\n');n+=1
print('decision-window',start,end,'deepseek-reasoning',n)

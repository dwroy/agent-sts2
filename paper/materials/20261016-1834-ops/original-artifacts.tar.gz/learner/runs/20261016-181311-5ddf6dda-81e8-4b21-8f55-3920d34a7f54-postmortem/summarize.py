import json,collections
from pathlib import Path
p=Path(__file__).parent
read=lambda name:[json.loads(x) for x in (p/f'{name}.jsonl').open()]
d=read('decisions');s=read('states');r=json.loads((p/'JH49PP3EYJH8-resources.json').read_text())
with (p/'decisions-summary.txt').open('w') as f:
 for x in d:
  f.write(f"d{x['_line']} {x['ts']} F{x['floor']} T{x['turn']} SL{x.get('sl_attempt')} {x['decider']} {x['label']} {x.get('chosen')} {x['rationale']} result={x.get('result')}\n")
with (p/'states-summary.txt').open('w') as f:
 for x in s:
  st=x['state'];ru=st.get('run') or {};co=st.get('combat') or {};pl=co.get('player') or {}
  f.write(f"s{x['_line']} {x['ts']} F{ru.get('floor')} T{st.get('turn')} {st.get('screen')} HP{ru.get('current_hp')}/{ru.get('max_hp')} E/B={pl.get('energy')}/{pl.get('block')} powers={pl.get('powers')}\n")
  if co:
   for e in co.get('enemies',[]):f.write(' enemy '+json.dumps(e,ensure_ascii=False)+'\n')
   f.write(' hand '+json.dumps(co.get('hand'),ensure_ascii=False)+'\n')
with (p/'turns-summary.txt').open('w') as f:
 for c in r['combats']:
  f.write(f"战斗{c['sequence']} F{c['floor']} {c['enemies']}\n")
  frames=[x for x in s if c['entry']['line']<=x['_line']<=c['last']['line']]
  for turn,ff in __import__('itertools').groupby(frames,key=lambda x:x['state'].get('turn')):
   a=list(ff);first,last=a[0],a[-1]
   def fmt(x):
    st=x['state'];co=st.get('combat') or {};return dict(line=x['_line'],hp=st['run']['current_hp'],player=co.get('player'),enemies=[{k:e.get(k) for k in ['index','enemy_id','name','current_hp','block','powers','intents','move']} for e in co.get('enemies',[])])
   audit=next((t for t in c['enemy_hp_audit']['turns'] if t['turn']==turn),{})
   f.write(json.dumps({'turn':turn,'first':fmt(first),'last':fmt(last),'audit':{k:audit.get(k) for k in ['live_enemy_hp_start','live_enemy_hp_end','visible_enemy_hp_loss_lower_bound','net_live_enemy_hp_loss','gaps']}},ensure_ascii=False)+'\n')
print('摘要已保存')
print('combat keys',list(next(x['state']['combat'] for x in s if x['state'].get('combat'))))
print('config',json.dumps(read('run-config')[0],ensure_ascii=False)[:5000])

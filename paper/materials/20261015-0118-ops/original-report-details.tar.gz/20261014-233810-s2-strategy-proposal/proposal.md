# 本批十项策略提案核验


本批 20261014-233810-s2-strategy-proposal，角色 silent。仅处理已领取十个原id；无 research_request/implementation_request，不承接另一专题。原 Markdown 副本及 SHA 保存在本目录，不改原文，不重复登记 id。

证据来自本批十锚点及原提案直接关联的五个静默局。所有游戏数值来自原日志；历史 dirty 执行树不以当前源码冒充。已有子源码与未完成整项分别处置。没有充分的新行为证据，本批不修改生产策略。


## silent-proposal-08eaa60bcc449852


原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md
SHA256：4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016
账本：silent-0019, silent-0020。来源任务：experience-update；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：KEN58SH9SLZ6 A10：F3 T2、F4 T1、F5 T2、F11 T1/T2、F15 T1共七饮；F12 26→53、F16 46→75。

处置：waiting。已核七饮、两次回复与空药入口；缺同资源、同后续牌序的不饮用/留药到boss整战对照，不能校准持药价格或固定保留阈值。

反例或限制：零损的F15已耗药；未执行的留药或无精英路线不当反例实果。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：固定原状态逐饮核药槽减少，queued结果需后继状态确认；回复与SL复原分账；以后按run与时间留出整战。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-92920295a648b540


原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md
SHA256：f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf
账本：silent-0228, silent-0255。来源任务：postmortem；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：TXZ6RVMQA09D A10 F48第2/3次T6：48血、敌460，实损/扣血3/36与0/27；F48 T10剩4，F49 T1出牌前4→0。

处置：waiting。已核T6少损3同时少扣9、首胜4血及后场开局归零；缺固定后轮抽序、药栏与入口资源的连续通关替线，不能改SL资格或终局权重。

反例或限制：后轮抽牌与生成牌改变；首战胜不是连战胜，未校准零胜率不能成为必死依据。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：固定两次T6前盘与T7实果，逐尝试核首战退出和后场可操作性；下一数据须同后轮抽序与资源的两战结局。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-a327449c331efbc1


原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md
SHA256：e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925
账本：silent-0079, silent-0018。来源任务：postmortem；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：WQZVENQ7DTRP A10 F33第2/3次T9：26血、敌184、同手/药栏，13损/24扣与22损/39扣；末次T7沙坑4→5，实损4。

处置：waiting。已核同盘T9多损9/多扣15与T7付4血延长沙坑1；缺两条结束边界的完整受控后继、同预算配对与独立胜局，不能定血伤交换阈值。

反例或限制：末T7付血取得延时，限制“一律保血”；末战仍败，不能把延时当挡攻击。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：固定T9成对盘面及T7沙坑/HP，后续成对重放两条结束边界；保持必死闸与现有探索阈值。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-a099e89437e942bb


原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md
SHA256：e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2
账本：silent-0030, silent-0257, silent-0258。来源任务：experience-update；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：WQZVENQ7DTRP A10 F33 T11：本批逐饮核15个窗口；第5次8手→10→10→10，第6次5手→8→10→10。关联SADL3CGYTGSR为A7；F4QKG4J1AJJZ为A9。

处置：waiting。狡诈生成/逐步容量子项已有live源码6403fdcdadc803a092beb5165a068e22bf51c412；已核15个T11饮用窗口，仍缺计划妥当保留选择、完整候选派发和SL恢复的联合消费者验证。

反例或限制：满手耗瓶并不增加刀；有生成子模型不等于已验证保留/完整派发，也不能宣称多刀救局。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：固定3/2/0手位与逐步出刀/饮药；将保留选择、重规划、实际派发与SL恢复联合读回后再验收整项。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-47910f82a1fdd98f


原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md
SHA256：d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd
账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。来源任务：experience-update；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：TXZ6RVMQA09D A10 F48 T10→F49 T1：4血、空药后出牌前扣4，敌111血保持且玩家出牌数0；WQ F33 T7/T9双向血价同上。

处置：waiting。开场扣4及连战资源子项已有live源码e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a；仍缺SL血价、留药、路线预算的受控完整后继及未知回复/复活组合顺序。

反例或限制：当前T1与SL恢复盘面已经支付开场效果，不能再扣一次；未观察回血/复活组合保留未知。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：仅在已观察遗物组合核新战入口；未知回复/复活不扩规则，另核路线、持药、SL后继。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-f1374df72d8e6a25


原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md
SHA256：df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0
账本：silent-0019, silent-0020, silent-0050, silent-0253。来源任务：postmortem；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：Q6M2Y34MWKRE A10 F2 T3：敏捷2、两防御7/14，44血不变；F7 36→57，F8胜57→2，F9 2→0。1913SE84AXQF A10 F29 61→46，F31 46→0。

处置：waiting。已核Q6胜后2血接F9死亡、1913以46血进F31及局部药效；缺隔离机制误差后的同预算完整后继和未用/早用/留药成对整战结果，不能改药价、护栏或终局权重。

反例或限制：早喝候选没有完整执行；零损F5/F6保留药不能据F2外推全局早喝正确。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：固定实际药效和胜后入口；修/隔离机制误差后按同预算早用/不用/留药与完整后继核权重。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-38a49e6c97f31eea


原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md
SHA256：6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0
账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。来源任务：experience-update；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：Q6M2Y34MWKRE A10 F8 T4：敌103→95→85→83→80，T5紧勒层0；F2 T3敏捷与挡分源。1913SE84AXQF A10 F31 T2—4为原提案中的磨蚀/重接/反伤边界。

处置：waiting。普通紧勒5c7105ff0294466da8319f2934beda05c6040794与磨蚀预览d06acd4bcbf2c64608197b7d7b2e572c621bec61均为live祖先；宽项仍缺弃牌触发/增益分源、重接/反伤/再生的联合完整消费者验证。

反例或限制：普通无挡紧勒分支不能外推升级、重放和叠层；弃磨蚀的能力建立不等于有挡或能活。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：逐牌结算及过轮层消失已核；继续对弃牌完成、重接、反伤、回复建立完整动作和消费者归属。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-ef0e38a5dbd3bc07


原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md
SHA256：d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5
账本：silent-0019, silent-0020, silent-0021。来源任务：experience-update；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：1913SE84AXQF A10 F28实40→61、F29胜61→46、F31 46→0；Q6M2Y34MWKRE A10 F7实36→57、F8胜57→2、F9死。

处置：waiting。已核实际休息、赢战退出与后场死亡的资源链；缺另选营火、事件、早用药或换路线的完整受控结果，不能由失败链拟路线血价及持续能力终局权重。

反例或限制：1913原计划营火改锻造，属于条件变化；Q6已经休息仍死，不能据此定更保守阈值。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：逐节点只登记真实动作及到账HP；把替代路线同条件全链实果与机制误差分开校准。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-7f820c02d39bfaea


原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md
SHA256：bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105
账本：silent-0079。来源任务：postmortem；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：NHA2KW0RB7VP A10 F33六试T1→T2：前四试各1损/8扣，末两试各7损/24扣；同一局六试，不作六个独立样本。

处置：waiting。已核NHA六试T1原线1损/8扣、替线7损/24扣；预测比较已有live源码5604982e13890e0e2bc8bf8246272e8267321c0b及c769739b97389fdc978b6515b83a38e3cd900f67，但缺成对完整后继、派发归属及同预算饱和排序校准。

反例或限制：第五与第六为一次替线及重放，非独立成功；六次全败，输出增加不证明更安全或能通关。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：冻结原答、替线、预测、派发及实际整轮；同预算排序校准和独立后移局验证才能改门槛。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。


## silent-proposal-04b6b430759815ed


原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md
SHA256：188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58
账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。来源任务：experience-update；实现任务：strategy-proposal/20261014-233810-s2-strategy-proposal。

证据局/层/回合：NHA2KW0RB7VP A10 F17 T1普通毒药建10毒，F33 T1 X1萎靡建−2力/2弱；F33 T2首/次试实损7/6。K3676LU8B0UH A1 F30 T2带毒刺击建8毒；原提案SADL3CGYTGSR为A7。

处置：waiting。精确切击与蟹朝向子公式已有live；油灯已证现场翻倍，但原状态stack=null且无已消费字段，缺跨动作/新战/SL恢复的可靠消费追踪与未见组合消费者验证；能力完整后继也未证。

反例或限制：已取整显示伤害不能再次简单乘朝向；本批没有油灯所有减益/升级萎靡/零X/叠层证据。

既有规则与预期行为：保留生产规则；先完成原提案所要求的资源/机制/派发联合验证，不将局部预测或首胜替代完整后继。验证方法：先取得可靠“首次负面是否已消费”输入及跨状态恢复语义，再固定当前负面/目标/朝向算术并核完整后继。

拟合与切分：本批作固定证据复验，不拟合参数；同局SL同组，后续独立局按时间后移验证，不借其他角色统计。回退：本批无新源码可回退；若后续实施，仅撤该项实际提交并保留刷新知识、并行源码和失败证据。

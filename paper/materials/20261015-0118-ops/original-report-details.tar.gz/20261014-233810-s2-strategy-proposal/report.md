# 本批策略核验报告


本批十项均为 waiting：已有局部模型或审计源码不能关闭包含完整后继、派发与消费验证的宽提案。没有充分证据支持新增生产规则，本批无新源码、提交、合入、行为版本或 shipped 登记。

## 身份与基线


任务 strategy-proposal；角色 silent；batch 20261014-233810-s2-strategy-proposal。learn.json 对应行 reason=proposal，明确领取十个 proposal_ids，未带 research_request/implementation_request/proposal_repair；普通 deck-size 请求绑定另一旧批次，因此不进入专题。工作树启动干净，起始 HEAD bd1318631ce784435b54d3ab4bb0485b40e4424a；按普通流程 git merge --no-edit main 快进至完整基线 23c3e5faa8dd557a381e91d9168145e6513f138f，仅 eval/versions.json 的并行发布登记变化。之后 HEAD 保持该基线。身份回执 batch-identity.json；未修改根请求、调度身份或旧提案。

独立完成，没有下级agent，没有模型调用、网络、play或对局操作。本会话工具没有原生模型/推理配置的核验入口，不凭任务文字或对局run-config自报本学习会话的运行模型已验证。

## 冻结输入与核验


原日志只读，共用 extract_evidence.py 抽取15个已核SILENT局，保存各流source_size和逐行line/offset/bytes/SHA256；逐条重新seek原日志，核原字节SHA、解析正文和显式身份一致，并核输出SHA及计数，合计19929行，全部通过。run-plans使用顶层run，不将正文提及当所属局；冲突身份拒收。原先输出暂为0的在途states文件没有被解释为原日志不存在。未改旧报告或旧截点。小流独立初稿保留在evidence-small/，最终全流在evidence/。

| 流 | 原字节截点 | 已核行数 |
|---|---:|---:|

| states | 12812878460 | 9815 |

| decisions | 1424844196 | 9448 |

| sl-attempts | 39330624 | 78 |

| run-config | 1705790 | 15 |

| run-plans | 7792164 | 77 |

| brain | 522121555 | 481 |

| runs | 329447 | 15 |


本批runs只报十锚点；五个补证局是原领取提案直接关联的证据，不是新增选题。十五局全部有states/config/runs，不能把所有局当A10，也不能把提案中的全历史统计当本次重新研究的范围。

| 局号 | 进阶 | 终层 | 原成绩 |
|---|---:|---:|---|

| KEN58SH9SLZ6 | A10 | 17 | 败 |

| TXZ6RVMQA09D | A10 | 49 | 败 |

| WQZVENQ7DTRP | A10 | 33 | 败 |

| 02HB4L0C3C67 | A10 | 12 | 败 |

| 4D4J8USKCPAV | A10 | 17 | 败 |

| F4QKG4J1AJJZ | A9 | 38 | 败 |

| JLN5SK17W4FQ | A10 | 33 | 败 |

| LS8035TB32P3 | A10 | 42 | 败 |

| NB8KCF6HRGVF | A10 | 31 | 败 |

| S9UZAK0JP0C0 | A10 | 33 | 败 |

| K3676LU8B0UH | A1 | 48 | 胜（来源原始口径） |

| SADL3CGYTGSR | A7 | 48 | 败 |

| 1913SE84AXQF | A10 | 31 | 败 |

| Q6M2Y34MWKRE | A10 | 9 | 败 |

| NHA2KW0RB7VP | A10 | 33 | 败 |


核验记录：verified-evidence.json、run-identities.json、exact-frames.json、observed-windows.json。完整日志抽取不是全候选的完成认证；历史code带dirty，不以本批基线代替原执行树。

## 固定数值回放


最终49项全部通过；22个饮药窗口包含KEN七饮及WQ F33 T11十五饮，三个KEN queued返回均由后继药槽实际减少确认，不把queued文本当已完成。检查只是原证据数值/资源核验，未执行LLM、随机模拟池或生产测试。两次记录为47项旧核验和补入NHA/TXZ两项后的49项核验；无撤生产源码的红绿测试。

- KEN A10七饮与F12 26→53、F16 46→75核实，回复与SL复原不混算。
- TXZ A10 F48第二/三试T6实损/扣血3/36与0/27；末试F48 T10剩4，F49 T1 4→0，出牌数0、敌111不变，未抵达可操作帧。
- WQ A10同盘T9原线13损/24扣、替线22损/39扣；末T7支付4血，沙坑4→5。两边界不可由死亡率并列抹平。
- 狡诈本批T11十五饮的实际增量均吻合剩余手位，满手仍耗瓶；没有穿插用药整战胜线。
- Q6 A10 F2 T3敏捷2使两防御7/14；F8 T4紧勒后敌103→95→85→83→80，T5层消失。
- Q6 F7实36→57、F8胜57→2、F9 2→0；1913 F28实40→61、F29胜61→46、F31 46→0。
- NHA A10 F33前四试T1各1损/8扣、末两试各7损/24扣，六试属于一局。NHA油灯毒药建10，X1萎靡建−2力/2弱；K367 A1毒刺建8毒。

本次数值核验未重新证实原提案所有机制组合、全历史样本数、全部复活/重接/反伤及能力胜因。没有对未走路线、早用/留药或未执行候选补造胜负。observation-checks.json、potion-observations.json、resource-observations.json、sl-observations.json保存来源行和实值。

## 当前源码与live


只读核验live切点 473b9c0e1563e88d174cc24d6007eda5c5a9a9f9。九个已有源码提交均为该live的真实祖先；十二个相关源码叶中九个字节完全相同，三个仅Roy→Dai署名注释差，已逐字节验证。不冒报整个main/live同树。保存source-audit.json、base-live-source.patch及十二个原字节.txt副本，没有可执行.ts临时源码副本、全仓归档或完整对照checkout。

| 子项 | 已有实际live祖先源码commit |
|---|---|

| 狡诈生成/容量 | 6403fdcdadc803a092beb5165a068e22bf51c412 |
| 新战开场四血/连战接续 | e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a |
| 普通紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 |
| 普通磨蚀预览 | d06acd4bcbf2c64608197b7d7b2e572c621bec61 |
| SL资源比较 | 5604982e13890e0e2bc8bf8246272e8267321c0b |
| SL候选预测/未认证实际结果 | c769739b97389fdc978b6515b83a38e3cd900f67 |
| 精确切击手数子公式 | 8b9bacbebb20eaaa1133a9945da6c7abfcda745d |
| 实测蟹转向取整 | f2c7cc1a7288893bceae0f0b20304a2b1fae5f57 |
| 旧有限子项及适配集成（不当新实现） | a8b1f8be153fe4f3a34146117546c2178f2e446b |

SL两处消费者明确把数字标为预测，并保留actual_turn_result=null或execution=unverified；本批没有把它们当完整派发验收。连战开场仅适用于已观察遗物/药水组合，不对live已支付T1再次扣费。油灯原帧的relic.stack=null，没有“本战首次负面已消费”字段；当前给定源码亦无通用可用次数输入，现场翻倍事实不自动证明跨动作/SL恢复模型。

## 逐项结果


### silent-proposal-08eaa60bcc449852


账本：silent-0019, silent-0020。已核七饮、两次回复与空药入口；缺同资源、同后续牌序的不饮用/留药到boss整战对照，不能校准持药价格或固定保留阈值。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-92920295a648b540


账本：silent-0228, silent-0255。已核T6少损3同时少扣9、首胜4血及后场开局归零；缺固定后轮抽序、药栏与入口资源的连续通关替线，不能改SL资格或终局权重。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-a327449c331efbc1


账本：silent-0079, silent-0018。已核同盘T9多损9/多扣15与T7付4血延长沙坑1；缺两条结束边界的完整受控后继、同预算配对与独立胜局，不能定血伤交换阈值。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-a099e89437e942bb


账本：silent-0030, silent-0257, silent-0258。狡诈生成/逐步容量子项已有live源码6403fdcdadc803a092beb5165a068e22bf51c412；已核15个T11饮用窗口，仍缺计划妥当保留选择、完整候选派发和SL恢复的联合消费者验证。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-47910f82a1fdd98f


账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。开场扣4及连战资源子项已有live源码e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a；仍缺SL血价、留药、路线预算的受控完整后继及未知回复/复活组合顺序。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-f1374df72d8e6a25


账本：silent-0019, silent-0020, silent-0050, silent-0253。已核Q6胜后2血接F9死亡、1913以46血进F31及局部药效；缺隔离机制误差后的同预算完整后继和未用/早用/留药成对整战结果，不能改药价、护栏或终局权重。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-38a49e6c97f31eea


账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。普通紧勒5c7105ff0294466da8319f2934beda05c6040794与磨蚀预览d06acd4bcbf2c64608197b7d7b2e572c621bec61均为live祖先；宽项仍缺弃牌触发/增益分源、重接/反伤/再生的联合完整消费者验证。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-ef0e38a5dbd3bc07


账本：silent-0019, silent-0020, silent-0021。已核实际休息、赢战退出与后场死亡的资源链；缺另选营火、事件、早用药或换路线的完整受控结果，不能由失败链拟路线血价及持续能力终局权重。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-7f820c02d39bfaea


账本：silent-0079。已核NHA六试T1原线1损/8扣、替线7损/24扣；预测比较已有live源码5604982e13890e0e2bc8bf8246272e8267321c0b及c769739b97389fdc978b6515b83a38e3cd900f67，但缺成对完整后继、派发归属及同预算饱和排序校准。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。

### silent-proposal-04b6b430759815ed


账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。精确切击与蟹朝向子公式已有live；油灯已证现场翻倍，但原状态stack=null且无已消费字段，缺跨动作/新战/SL恢复的可靠消费追踪与未见组合消费者验证；能力完整后继也未证。 状态：waiting。原 Markdown 路径/SHA、局号/层/回合、反例、预期行为、验证和回退见本目录 proposal.md 同名节。


十项均有proposal_results，无漏项，不领取其他批次；局部子项已有实现不虚报整个id duplicate/implemented。code_proposals沿用十个真实CLI id，本批不另建重复id；implementation_domains=[]，因为本批没有实现生产域改动。

## 记录与失败保留


原提案/队列Markdown逐个SHA一致，保存assigned-proposals.json和十份.original.md；账本只读取silent条目并准备31条by/where/note追溯链接，通过根ledger CLI追加，不直接改账本，不改原claim/evidence/prior/status/version，不新增机制或将已有shipped知识降回proposed。原proposal队列状态由调度器消费最终JSON，未在模型内直接改队列。CLI退出0，31条逐行offset/bytes/SHA和精确正文读回通过，追加前字节前缀保持；仅op/id/ts/by/where/note字段。ledger-cli-result.json、ledger-cli-output.txt、ledger-prefix-before.json与ledger-readback.json保存实际回执。

本批发生一次角色隔离边界失误：宽范围rg搜索agent/src及agent/test*意外输出旧混合角色知识文本。该输出未被用作游戏结论、参数、反例或证据，后续限制到指定源码/静默材料；必须保留此失误，不能自报全程零接触其他角色知识。所有本次数值结论均独立来自十五个SILENT原日志的字节核验，本批不发布新知识或策略。

另保留两个工具沙箱预检失败（并行回收导致无关扫描路径消失，重试恢复），以及一次探索摘要对combat=null调用get的AttributeError，后续以空combat处理并通过完整核验。这些不是生产源码撤码失败或测试失败。提案初稿、提取小流、探索帧与失败材料均保留。

## 测试、提交和合入


生产源码、任务模板和知识均未修改，工作树保持干净；本批不运行tsc/vitest、不造成功计数，tests固定null/null/null。撤源码失败/恢复通过：未执行，无新源码。提交=null，merged=null，行为版本=null；不通知规则上线、不标shipped。gitleaks全材料扫描exit0、421.74MB、无泄漏；最终新增报告/CLI回执的有界记录扫描也exit0、无泄漏，回执gitleaks-records.json。最终机械验收final-validation.json核完整HEAD/base、git status干净、tracked源码/知识/模板零差异、十原Markdown SHA、49数值项及31 CLI行；无源码自测或上线成功回执。

## 最终JSON


```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261014-233810-s2-strategy-proposal",
  "base": "23c3e5faa8dd557a381e91d9168145e6513f138f",
  "runs": [
    "KEN58SH9SLZ6",
    "TXZ6RVMQA09D",
    "WQZVENQ7DTRP",
    "02HB4L0C3C67",
    "4D4J8USKCPAV",
    "F4QKG4J1AJJZ",
    "JLN5SK17W4FQ",
    "LS8035TB32P3",
    "NB8KCF6HRGVF",
    "S9UZAK0JP0C0"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-08eaa60bcc449852",
    "silent-proposal-92920295a648b540",
    "silent-proposal-a327449c331efbc1",
    "silent-proposal-a099e89437e942bb",
    "silent-proposal-47910f82a1fdd98f",
    "silent-proposal-f1374df72d8e6a25",
    "silent-proposal-38a49e6c97f31eea",
    "silent-proposal-ef0e38a5dbd3bc07",
    "silent-proposal-7f820c02d39bfaea",
    "silent-proposal-04b6b430759815ed"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-08eaa60bcc449852",
      "state": "waiting",
      "reason": "已核七饮、两次回复与空药入口；缺同资源、同后续牌序的不饮用/留药到boss整战对照，不能校准持药价格或固定保留阈值。"
    },
    {
      "id": "silent-proposal-92920295a648b540",
      "state": "waiting",
      "reason": "已核T6少损3同时少扣9、首胜4血及后场开局归零；缺固定后轮抽序、药栏与入口资源的连续通关替线，不能改SL资格或终局权重。"
    },
    {
      "id": "silent-proposal-a327449c331efbc1",
      "state": "waiting",
      "reason": "已核同盘T9多损9/多扣15与T7付4血延长沙坑1；缺两条结束边界的完整受控后继、同预算配对与独立胜局，不能定血伤交换阈值。"
    },
    {
      "id": "silent-proposal-a099e89437e942bb",
      "state": "waiting",
      "reason": "狡诈生成/逐步容量子项已有live源码6403fdcdadc803a092beb5165a068e22bf51c412；已核15个T11饮用窗口，仍缺计划妥当保留选择、完整候选派发和SL恢复的联合消费者验证。"
    },
    {
      "id": "silent-proposal-47910f82a1fdd98f",
      "state": "waiting",
      "reason": "开场扣4及连战资源子项已有live源码e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a；仍缺SL血价、留药、路线预算的受控完整后继及未知回复/复活组合顺序。"
    },
    {
      "id": "silent-proposal-f1374df72d8e6a25",
      "state": "waiting",
      "reason": "已核Q6胜后2血接F9死亡、1913以46血进F31及局部药效；缺隔离机制误差后的同预算完整后继和未用/早用/留药成对整战结果，不能改药价、护栏或终局权重。"
    },
    {
      "id": "silent-proposal-38a49e6c97f31eea",
      "state": "waiting",
      "reason": "普通紧勒5c7105ff0294466da8319f2934beda05c6040794与磨蚀预览d06acd4bcbf2c64608197b7d7b2e572c621bec61均为live祖先；宽项仍缺弃牌触发/增益分源、重接/反伤/再生的联合完整消费者验证。"
    },
    {
      "id": "silent-proposal-ef0e38a5dbd3bc07",
      "state": "waiting",
      "reason": "已核实际休息、赢战退出与后场死亡的资源链；缺另选营火、事件、早用药或换路线的完整受控结果，不能由失败链拟路线血价及持续能力终局权重。"
    },
    {
      "id": "silent-proposal-7f820c02d39bfaea",
      "state": "waiting",
      "reason": "已核NHA六试T1原线1损/8扣、替线7损/24扣；预测比较已有live源码5604982e13890e0e2bc8bf8246272e8267321c0b及c769739b97389fdc978b6515b83a38e3cd900f67，但缺成对完整后继、派发归属及同预算饱和排序校准。"
    },
    {
      "id": "silent-proposal-04b6b430759815ed",
      "state": "waiting",
      "reason": "精确切击与蟹朝向子公式已有live；油灯已证现场翻倍，但原状态stack=null且无已消费字段，缺跨动作/新战/SL恢复的可靠消费追踪与未见组合消费者验证；能力完整后继也未证。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261014-233810-s2/learner/runs/20261014-233814-strategy-proposal/report.md"
}
```

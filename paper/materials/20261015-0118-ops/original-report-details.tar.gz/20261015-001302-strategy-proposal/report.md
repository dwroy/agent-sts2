# 静默猎手策略提案逐项核证

批次：20261015-001302-strategy-proposal。角色：silent，仅本批五局A10。
基线：`7203e1ac068ad994e9f0bb7a53c1a2a91a8dee01`。本批普通队列有10个已领取id，无research_request/implementation_request；
根deck-size请求绑定另一批次，不承接它。开工工作树干净，merge main返回Already up to date。
来源任务与原经验/提案保持原链接，不新建重复id，不重复写复盘。

结论：10项均waiting；三个可隔离的已有子实现已核实际live祖先与当前源码，整项要求仍未覆盖。
本批没有发现足以新增游戏规则的隔离生产数值缺口，保持现有打法；没有修改源码、知识、任务模板或live。

证据入口：extract_evidence.py，七流各自source_size冻结，共6606行；逐行offset/bytes/SHA及原JSON完全读回。
明细在evidence/evidence-manifest.json、evidence-audit.json、compact-states/decisions/sl/run-plans.jsonl。
run-plans显式run字段26行，不使用正文提及认领身份；没有复核旧截点或据零行断言日志缺失。
五局runs.jsonl均SILENT/A10，运行版本均+dirty；当前源码不能冒充旧运行树或当时的知识快照。
原提案历史统计/其他局仅保留来源，不把未重新分析的历史样本算成本批验证。

以下每项保留原授权Roy-2026-10-07-learning；授权不提供游戏事实，不新增阈值或固定拿牌/出牌规则。
DeepSeek/Codex与Jev原日志理由是当时的模型判断，实际机制只由原状态与动作证据核证。

## 本批核证结果

|提案id|处置|具体缺口|
|---|---|---|
|silent-proposal-9952ee8e8df9a0fe|waiting|缺跨重问完整候选执行归属、累计成长收益及同条件后战/路线对照；T1多输出伴随多损血没有确定整战胜负优势，不能校准SL或终局HP门槛。|
|silent-proposal-47be799a87af03be|waiting|已有计划事实/四选项快照子实现，缺精确切击随手牌变化、紧勒、毒、失衡与剩血的四分支联合生产回放；不能把快照当完成整项。|
|silent-proposal-3a5274da3c42672a|waiting|缺召唤/复活、一次翻倍和连续用药的联合生产回放，主怪最后归零中间帧缺失；没有同条件保药/杀序整战对照，不能提出新药价或杀序。|
|silent-proposal-bc4b92d590f2c4ce|waiting|首牌身份、弃牌提示和快照已有live子实现；仍缺跨重问完整候选执行归属、累计余像收益及动态弃牌分支验收，不能把窄子项标为整项duplicate。|
|silent-proposal-f52fbbab4dccc3b4|waiting|已有真实后战入口和局部回复，但缺分源毛伤、复活新增需伤及同条件路线/休息/SL/保药整战支线，不能确定新的路线或终局血价。|
|silent-proposal-10f37c0edd3d24a6|waiting|已核局部临时减力、双毒与格挡增量；缺开场遗物、一次翻倍、能力和回复叠加的联合模型回放及独立后置验证，未定位新生产数值缺口。|
|silent-proposal-3f82387e2e179703|waiting|RC同入口两线损4/8、净扣敌30/23；唯一单弃已有live子实现，仍缺累计能力收益及同抽序同预算整战控制，不能从单轮差额改SL排序。|
|silent-proposal-aee21084c991abd3|waiting|原选线在抽弃后已换线；缺当时模型逐样本抽序、移动及完整执行回放，+dirty运行树和刷新知识未冻结；单次死亡不足校准概率或权重。|
|silent-proposal-df37594e9b12debf|waiting|唯一单弃取消后继攻击/转向已有live子实现；宽项仍缺跨重规划整线、累计能力及呼唤自损的联合消费者验证，当前局部重放不能关闭整项。|
|silent-proposal-42e81c83b2e1e56b|waiting|已核实际营火/后战入口与计划差异；缺回复/药槽/存档事件完整分源账及同条件后战反事实，不能拟合路线或终局HP新参数。|

逐项局号/层/回合、全部原账本id、旧/新行为、反例、预期行为、验证与回退见proposal.md及assigned-proposals.json。
calculated-facts.json保存8组局部重算，selected-facts.json保留固定状态；这些不构成整战干预收益或新经验入库。

## 已有源码及消费者边界

固定核对live HEAD `473b9c0e1563e88d174cc24d6007eda5c5a9a9f9`，三个真实祖先：

- `e784dd9f043bf87c29109573f48975f9903280d3`：投斧首牌身份。
- `a8b1f8be153fe4f3a34146117546c2178f2e446b`：唯一强制弃牌及弃后快照等既有整合。
- `5b56a452bb9be14d620b368ec46974c1b57901ca`：选择题剩余计划事实等既有整合。

9路径的Git blob、完整原字节SHA/长度在source-audit.json；6路径相同，3路径仅Roy/Dai注释差异，原diff在base-live-source.patch。
这些只证明子实现及当前源码核对范围，未把它们填作本批新提交或10个宽项的implemented/duplicate。

只读固定消费者consumer.mjs没有载入刷新的知识JSON、未请求模型/网络、未运行play。
唯一单弃以原帧手牌与显示来袭构造局部输入调用当前modelHandCard/replaySteps：
RC首试显示38激光时7挡、需损31、余14；第三试显示57时7挡、需损50、余−5，后继打击均不可执行。
不把这个局部输入冒作完整生产planCombatTurn或长程模型校准。
投斧原首牌前缀在带身份canon中不同；P74四合法弃牌选项都有retained_cards/current_resources快照。
快照明确未知伤害、格挡、剩血、胜负；完整候选执行结果一律unknown/null。

## 验证与失败保留

- 原始提取exit0；7流6606行全部逐原字节/SHA/JSON/角色身份核对通过，9条固定帧断言通过。
- 8组实盘数值重算完成：NHA即时HP差、RC即时HP/扣敌/挡、P74赢战/滑溜毒、RC自损、BTS末态、G33实休。
- 消费者首跑exit1：scratch选错s284819为弃牌帧，生产返回null；原脚本consumer-initial.txt和consumer-first.log保留。
  改用s284817后exit0，四输出在consumer-results.json、consumer-corrected.log；这是材料脚本修正，不是源码撤回/恢复红绿。
- 初次source-audit误strip末换行，初稿source-audit-initial-stripped.json保留；最终按完整Git blob重新计算。
  evidence-audit初稿固定断言计数10为笔误，实际9条，初稿也保留；原字节通过结论不变。
- 撤源码失败/恢复通过：未执行，无源码改动，不造红绿；tsc/vitest/cases均null，未运行源码测试或借旧批成功。
- 提交=null，合入=null，行为版本=null；不写eval版本、上线通知、implemented或shipped。

## 账本及收尾

32个既有silent账本条目只经根learner/ledger.py update追加本批报告/提案链接及waiting限制。
保留原status/claim/evidence/first_run/prior/version/历史提案，不新增相同事实，不降级旧shipped项。
无新增条目需设proposed；原代码提案id复用，没有再次调用add制造重复id。
CLI原输入/回执在ledger-updates.jsonl、ledger-update.log，核验及安全扫描记录在completion-checks.json。
工作树HEAD等于40位base且git status干净；仅忽略目录scratch材料及授权根账本追加，后者交ops按实际归属收录。
本批没有新异议或机制反证；同局未执行反事实、+dirty源、联合回放和新独立局缺口保持，不能按材料交付关闭父要求。

报告JSON：result.json。提案交运维路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-001302/learner/runs/20261015-001305-strategy-proposal/proposal.md。

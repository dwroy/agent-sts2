# 静默猎手本批策略提案报告

记录时间：2026-10-15T00:54:47+08:00。批次20261015-004301-strategy-proposal；base `07a91f5871d84076f0663276879a040e55800fb5`。

十项处置全部waiting；已有窄子项具备真实live源码祖先，宽范围缺少完整执行/联合校准或资源消费证据。本批无源码修改、无新提交、无合入、无eval版本；没有调整游戏规则或经验库。

开工git status为空；本批task/character/worktree/runs及十proposal_ids已核。没有research_request、implementation_request或proposal_repair。普通专题条件文件绑定另一批，故保持本批队列；git merge --no-edit main返回Already up to date。HEAD保持基线。没有另派agent或读取其他角色私有知识。

十原Markdown指纹全部匹配，31关联账本均silent；逐项证据、反例、旧/新边界、验证和回退详本目录proposal.md。原提案不改写、已有ID不重复登记。

## 原始证据

共4489条八流记录。统一extract_evidence.py入口按显式身份提取，offset/bytes/SHA与原始源逐字节读回，manifest逐流保存source_size。源仍可追加，不跨截点补行。fight-plans在本截点未选到这四局，不据0行断言原日志缺失。全源扫描invalid_lines为states2、decisions2、brain1，不当作四局特定缺帧证明。

| 局号 | states | decisions | SL | config | plans | brain | runs | fight-plans |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| MTQ0EUBJ3R6T | 440 | 424 | 5 | 1 | 4 | 23 | 1 | 0 |
| 7X0W3U8TVA2A | 461 | 445 | 1 | 1 | 4 | 31 | 1 | 0 |
| KFRDELW2TH2P | 620 | 587 | 8 | 1 | 6 | 35 | 1 | 0 |
| GXNKW8X1XYJP | 673 | 649 | 7 | 1 | 10 | 48 | 1 | 0 |

四局runs.jsonl均SILENT/A10、victory=false。run-config的完整源码commit与当时dirty_files存historical-code-context.json；dirty文件列的是生成知识数据，未冻结当时完整知识和后续变更，不认证旧运行全树或dirty行为等价。

## 当前消费者读回

四条缺decision_id/observed_ts的元数据另存audit-input-exclusions.json：KFR282561及GXN283515/283525/283581；提取原件保留，消费者不造身份。原行号不重编、同尝试与时间/状态指纹门禁保持。

| 局号 | 动作 | 题段 | 可见区间 | 可核整轮 | 未核整轮 | 同题预测可比 |
|---|---:|---:|---:|---:|---:|---:|
| MTQ0EUBJ3R6T | 424 | 68 | 156 | 25 | 50 | 57 |
| 7X0W3U8TVA2A | 445 | 119 | 36 | 7 | 64 | 93 |
| KFRDELW2TH2P | 586 | 180 | 224 | 18 | 85 | 174 |
| GXNKW8X1XYJP | 646 | 116 | 178 | 20 | 83 | 98 |

2101动作唯一匹配原timestamp/fingerprint；483题段、594可见区间、70可核整轮、282未核整轮、422同题预测可比。actual_full_candidate_result/actual_rollout_best依工具合同为null，不能用0个认证候选断言0次实际完成，也不把缺行未知补成新bug。

六个KFR真实奇巧帧提示剩2个手动名额上界/能量，continuation_verified=false；42个同修饰组合帧读取6毒（含饮后帧，不是42饮）。这些是已有函数读取历史固定原帧，不等于本批新自然采用或整战收益。

resource_chain读取同批冻结状态和SL事件，四局依次14/11/20/19战斗窗口、61/42/86/87资源变化。窗口包含SL尝试，不能当64独立战斗。赢战净耗、入房和可操作回血分开；重载出口和未见消耗来源保持未知。九个REWARD资源端点断言已核，详resource-fact-validation.json。

33项选线/机制/已有消费者事实断言加9项资源断言共42通过；未修改生产源码，因此不运行tsc/vitest、未撤源码/恢复，tests固定null。不把本材料脚本当生产源码测试。

## 实际live已有子范围

冻结live切点HEAD `473b9c0e1563e88d174cc24d6007eda5c5a9a9f9`。17个相关路径祖先及live无未提交修改已核；14个base/live blob相同，另外card-model、rollout-live、run-journal只差Roy/Dai注释署名。原blob/SHA和二进制Git差分分别保存source-audit.json/source-differences.patch，不认证整仓库等价。

| 已有子范围 | 实际live源码祖先 |
|---|---|
| selection | 05cd292c6f01bb31e406473d3a9843e659d62b93 |
| dispatch | bade647f9fe4c9103b40e2f26b26296692ad24b7 |
| guard_and_sl | a8b1f8be153fe4f3a34146117546c2178f2e446b |
| hand_trick_and_poison | 8bb53d6342b7e9a2adf96de231b53c36eaa943de |
| hp_boundary | 52d7f343f5f183670dc9d0c0d847bf6a15420aae |
| abrasive_attributes | 46d5fb8397edb84d9495ff61a21bed22b6bed7f1 |
| ordinary_snakebite | d385591f37cf2d09a032e3d3b998c4ff5ee5636e |

这些均为已有源码祖先，不是本批提交。普通蛇咬8毒为d385591f，磨蚀属性为46d5fb83；两者分列，未将磨蚀提交冒充蛇咬实现。窄子项存在不关闭原十四机制、七药效、终局或资源父范围。

## 十项处置

- **silent-proposal-f54e8de2381c1250：waiting。** 已有候选/派发审计；F11选牌后重问，缺完整候选执行绑定及同窗口实线排名。 证据：MTQ0EUBJ3R6T F11T1：decisions282138—282140、states288592—288597；F23末试T3：decision282434。 账本：silent-0125。

- **silent-proposal-763a4b9d9f17b815：waiting。** 普通8毒及磨蚀子项已在live；十四项临时属性、持牌伤、能力/药效时点的联合消费者校准仍缺。 证据：7X0W3U8TVA2A F30T3、F31T1/T2/T5/T6/T13；MTQ0EUBJ3R6T F11T1、F17T4—T8、F20T3、F23T3。蛇咬原帧288388→288389、288404→288405、288469→288470。 账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0044、silent-0046、silent-0053、silent-0080、silent-0087、silent-0189、silent-0214、silent-0222、silent-0235、silent-0253。

- **silent-proposal-19a5cff2094e2d8f：waiting。** 暂死重接子项已有；缺生命周期输入到实际终局的联合校准及冻结知识下完整同输入整战对照。 证据：7X0W3U8TVA2A F31T5/T6/T13：states288426、288430；MTQ0EUBJ3R6T F23末试T3：decision282434。 账本：silent-0021、silent-0064、silent-0079、silent-0133、silent-0125。

- **silent-proposal-3540bf4360bf80af：waiting。** 已核赢战净耗及HP边界记录；缺逐源资源事实到路线/休息题面的完整固定消费者读回。 证据：MTQ0EUBJ3R6T F19T1—T3：states288730→288744；F20T1—T7：288750→288776；F23。7X0W3U8TVA2A F30T1—T5、F31。 账本：silent-0019、silent-0020、silent-0243。

- **silent-proposal-0ea5c0b9c030fdd6：waiting。** 奇巧名额/能量和恶魔6毒已在live；完整合法后继及对象收益兑现、提前饮药整战结果仍缺。 证据：KFRDELW2TH2P F33六试T7：decisions282864/282899/282933/282968/283001/283035；末states289533—289538；反例F28T2。 账本：silent-0274、silent-0247、silent-0027、silent-0016。

- **silent-proposal-f915ec544ab94b6e：waiting。** 已核生成牌重问和同盘10伤/6血代价；缺完整执行绑定及同输入整战校准，不能据两败调SL权重。 证据：KFRDELW2TH2P F12T1：decisions282578/282579；F33首/第三试T6：states289339/289414→289345/289420、decision282929。 账本：silent-0079、silent-0125。

- **silent-proposal-8fb51933639faf90：waiting。** 恶魔6毒子项已读回；七项药效/能力的联合多轮校准和覆甲完整减层条件仍缺。 证据：KFRDELW2TH2P F28T2；F33六试T2/T4/T5/T6/T7，末states289536—289538。 账本：silent-0005、silent-0006、silent-0027、silent-0189、silent-0276、silent-0277、silent-0278。

- **silent-proposal-b3bc0eb09211af6c：waiting。** 奇巧、毒药入口及阶段审计子项已有；缺合法后继到实际终结全链及换对象/提前飲毒整战对照。 证据：KFRDELW2TH2P F33六试T7、首/第三试T6，末states289533—289538；F12T1反例。 账本：silent-0021、silent-0079、silent-0102、silent-0247、silent-0274。

- **silent-proposal-fdc3a505fe5e1a55：waiting。** 已核赢战血价及入口，HP边界已有；缺分源事实到路线/休息题面的固定对照及替路线/锻造完整结果。 证据：KFRDELW2TH2P F28T1—T5；F30T1—T6：states289257→289285；F31、F32休息、F33开场。 账本：silent-0019、silent-0020、silent-0243。

- **silent-proposal-5a95725089f53cd8：waiting。** 复活后3/13HP、0/7挡及逐槽观测已有；缺逐击复活帧、完整候选归属和逐源资源消费链。 证据：GXNKW8X1XYJP F35/F38/F40/F42/F44；F45第二/末试T2—T3：decisions283641/283680/283690/283691，states290160/290165/290201/290206/290212—290214。 账本：silent-0019、silent-0079、silent-0005、silent-0016、silent-0087、silent-0027、silent-0030。

## 记录与限制

本批仅经根ledger.py update追加31个既有账本的本批proposal/report链接与复核备注；输入只含id/by/where/note，保持原claim/status/evidence/first_run/version。不存在新提案需add，不重复历史复盘，不标implemented/shipped。队列十个waiting交启动器读取report.json，不手改learn.json、根请求或专用队列。实际CLI、回读和扫描回执在本目录，完成前再核。

完整候选执行、逐击复活及未截断入伤未认证；旧全知识未冻结；读档相关；十四/七项联合多轮消费者不完整；替路线、奇巧换对象/顺序、提前饮药缺受控整战对照。已有工具局部读回和净差不等于因果最优或胜率提升；本批未产生新反证，与上次waiting边界相同，不重复旧异议通知。

无新规则上线，不新增决策日志上线行/行为号或Roy双通知；未运行play/LLM/网络、未改prompt/权限/其他角色。没有源码合入流程适用项，本次merged=null。完成后由原调度器保留证据及waiting并继续派发，不关闭学习父要求。

提案交运维：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-004301/learner/runs/20261015-004305-strategy-proposal/proposal.md

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-004301/learner/runs/20261015-004305-strategy-proposal/report.md

JSON：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-004301/learner/runs/20261015-004305-strategy-proposal/report.json


完成验收（2026-10-15T00:57:18+08:00，写前已执行date）：31条根账本CLI追溯追加已读回，原claim/status/evidence/first_run/version保持；全账本482项、0问题。gitleaks目录扫描退出0、报告为空，约204.98MB材料扫描未发现泄漏。本批派发身份仍匹配、HEAD仍07a91f5871d84076f0663276879a040e55800fb5、git status为空且源码/知识零差异；十原ID均具具体waiting理由。无生产代码改动，tsc/vitest/撤源码红绿未执行，未创建提交或合入/版本。

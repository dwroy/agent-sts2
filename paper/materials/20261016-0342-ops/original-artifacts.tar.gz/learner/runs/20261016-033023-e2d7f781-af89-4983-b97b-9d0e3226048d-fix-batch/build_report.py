import json
from pathlib import Path
import re
import subprocess

SCRATCH = Path('/home/dw/Projects/agent-sts2/learner/runs/20261016-033023-e2d7f781-af89-4983-b97b-9d0e3226048d-fix-batch')
WORK = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261016-033017')
audit = json.loads((SCRATCH / 'audit.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK).decode().strip() == audit['base']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK).strip()
tsc = int((SCRATCH / 'tsc.exit').read_text())
vitest = int((SCRATCH / 'vitest.exit').read_text())
log = (SCRATCH / 'vitest.log').read_text()
assert tsc == 0 and vitest == 0
assert re.search(r'Test Files\s+10 passed', log) and re.search(r'Tests\s+75 passed', log)
names = {
    784: 'silent-0254：无动作死亡战斗归因',
    789: 'silent-0256：狡诈药水已观察容量子项',
    793: 'silent-0260：普通紧勒逐牌失血',
    797: 'silent-0263：已观察转向取整子项',
    801: 'silent-0266：SL投斧首牌身份',
    810: 'silent-0271：毒必胜提前返回遗漏保血候选',
    817: 'silent-0272：商店移除预览核对现场选牌',
    831: 'silent-0279：SL抽序升级改标',
    900: 'rollout最佳线固定夹具确定性',
    912: 'silent-0308：沙坑截止结束题面',
    918: 'silent-0311：库存恢复血量预算',
    923: 'silent-0317：升级全弃手牌分支',
    929: 'silent-0319：升级蛇咬分支',
    930: 'silent-0320：同线新建UNMOVABLE',
    935: 'silent-0322：升级神化同线升级',
    940: 'silent-0324：普通刀舞生成小刀',
    945: 'silent-0329：饮药临时力量接线',
    952: 'arch-funnel-guard', 953: 'arch-learning-priority',
    954: 'arch-unified-resource-value', 955: 'inv-f33-regression',
    959: 'silent-0332：成功首战接续nonpositive-hp',
    964: 'silent-0334：升级隐秘匕首模型',
    968: 'silent-0338：回合末格挡来源注记',
    980: 'silent-0339：尾巴误核销',
    992: 'silent-0344：坚韧之环延迟格挡',
    1001: 'silent-0347：组装师攻击召唤',
    1005: 'silent-0349：已有虚弱后的减力',
    1009: 'core-build-notify-222802-rc2：历史发送事实',
    1020: 'silent-0362：背向攻击减力倍率',
    1022: 'silent-0365：未建模药水目标可达性',
    1024: 'silent-0367：已用尾巴事实接线',
    1029: 'codex-usage-credit-baseline-recovery',
    1034: 'ascension-up：目标进阶误作实际进阶',
    1040: '框架外层时限与分段续验收尾',
    1041: '调度公平性核查',
    1110: 'host-fixed-test-timeouts-010547：eval/Apotheosis固定夹具',
    1294: 'silent-0481：技能药水生命周期措辞',
    1304: 'infra-target-options-fixed-fixture-timeout',
    1308: 'infra-ledger-status-prefix-git-divergence',
    1322: 'infra-learner-launch-shared-main-config-race',
    1344: 'silent-0487：MAD_SCIENCE三段攻击模型',
}
assert set(names) == {d['line'] for d in audit['queue_dispositions']}
fixed, skipped = [], []
for d in audit['queue_dispositions']:
    item = names[d['line']]
    if d['disposition'].startswith('已修'):
        commits = d.get('commits') or [d['commit']]
        fixed.append({'item': item, 'commits': commits, 'scope': d['disposition']})
    else:
        skipped.append({'item': item, 'reason': d['disposition']})
assert len(fixed) == 16 and len(skipped) == 26
extra_limits = [
    {'item': 'codex大脑缓存命中偏低', 'reason': '证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。'},
    {'item': 'sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因', 'reason': '证据不足：798af209注册保存屏障已是main/live祖先；不将历史ENOENT/null租约或本批工具扫描失败全部归因于该窄修复。'},
    {'item': 'named-card-facts-transport：事件入口之外范围', 'reason': '太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。'},
    {'item': 'boss模拟样本性能及v5-dpr-health宽范围', 'reason': '太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。'},
    {'item': 'rest-timeout-accepted-route-not-committed / silent-0446', 'reason': '策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。'},
    {'item': 'silent-0469：纸鹤其他未知组合/整战收益', 'reason': '策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。'},
]
result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': skipped + extra_limits,
    'merged': None, 'tests': {'tsc': tsc, 'vitest': vitest, 'cases': 75},
    'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md'),
}
verification = {
    'tsc': tsc, 'vitest': vitest, 'files': 10, 'cases': 75, 'retried': False,
    'tsc_command': 'nice -n 19 npx tsc -p tsconfig.json --noEmit',
    'vitest_command': 'nice -n 19 npx vitest run --pool=threads --maxWorkers=1 tests/learner-startup-recovery.test.ts tests/learner-launch-failures.test.ts tests/learner-entry.test.ts tests/learner-registration-barrier.test.ts tests/ledger-publication-baseline.test.ts tests/silent-paper-krane.test.ts tests/target-options.test.ts tests/feature-notice-registration.test.ts tests/boss-sim-notice-registration.test.ts tests/silent-paper-krane-beam.test.ts',
    'full_sandbox_suite_run': False,
    'reason': '无源码改动或新提交，只跑类型检查与相关固定回归；没有借此声称完整沙箱/宿主套件通过。',
    'without_fix_check': '不适用：没有新增修复，未撤现有源码；历史红绿不当作本批结果。',
    'environment': 'TMPDIR只在本批scratch；PATH本地Node/npm离线；不继承CHARACTER；nice19/单worker；Python字节码关闭。',
    'preparation_errors': '见preparation-errors.txt；一次工具扫描失败后重试，一次审计初稿允许列表错误与两次只读路径猜测。均不是测试重跑或产品回归。',
}
(SCRATCH / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
out = [
    '## 修 bug 回报',
    f"- 合并基线：main → {audit['base']}（开工工作区干净；git merge --no-edit main 返回 Already up to date）。",
    '- 修复（每条一行）：无新增纯 bug 修复；未创建提交，fixes=[]。无撤源码红绿验证适用项。',
    '- 已被别人修掉的：42条未勾选记录中16条有既有修复/限定子项，逐条提交见下表；另核74个既有来源与本批新增读到的纸鹤策略子项。',
    '- 没修的：26条策略/框架/证据不足项逐条见下表；非勾选记录的宽范围另列。保留原自动策略链，不重复登记提案或派下级。',
    '- 测试：tsc退出码0；vitest定向10文件/75用例/退出码0，无测试重跑。无新源码或提交，未运行完整test-sandbox.sh。',
    '- 合入：未合入（merged=null）；本批无新增源码，不空合并、不改live刷新数据或造发布号。',
    '- 需要 Roy 定的事（没有写「无」）：无。',
    '',
    f"当前队列1344行/SHA256 {audit['queue_sha256']}，与前批快照逐字节一致。381个路径中377个与前批SHA相同，3个源码变化精确等于独立策略8d386fc7668820c2fc387d966f9d94bdcab189fb，另1个是其V5-R365发布记录。已阅读源码差异并补跑该固定回归；不能用旧版全量结果替代本树验证。",
    '',
    f"74个既有来源和纸鹤源均为当前base及只读live快照 {audit['live_read_only_snapshot']} 的祖先。祖先不等于当前live所有叶与main相同；本批没有覆盖live或宣称逐叶等同。",
    '',
    '| 队列行 | 条目 | 处置/提交 |', '|---|---|---|',
]
for d in audit['queue_dispositions']:
    commits = d.get('commits') or ([d['commit']] if d.get('commit') else [])
    out.append(f"| {d['line']} | {names[d['line']]} | {d['disposition']}" + (f"；{'、'.join(commits)}" if commits else '') + ' |')
out += ['', '非勾选记录及既有窄实现之外的范围：', '']
out += [f"- {d['item']} — {d['reason']}" for d in extra_limits]
out += [
    '',
    'silent-0481原silent-proposal-686d4e759478eebb与silent-0487原silent-proposal-0a0b31e284e6793e已在独立策略链。后者队列证据为JWK2C8LE4SFV/A10/F48首试T5与末试T8，本批只核当前源码缺ViolenceHits及原链，不冒称重新完成整局语义研究。技能药水题面知识与三段攻击模型均不混入本普通批。',
    '',
    'silent-0332的正HP资源契约仍保留，旧RQ F40/F48完整resources/steps与机制根因未知，不猜参数。silent-0311库存问题沿既有d2f24919链，正确复现定位为2LZHP9BYFTHE/A10/F37T1/4/10，不沿旧运维F38误写。',
    '',
    '既有修复/限定子项提交（仅确认原范围）：', '',
    '| 条目 | 源码提交 |', '|---|---|',
]
out += [f"| {d['item']} | {d['source_commit']} |" for d in audit['existing_fixes'] + audit['additional_existing_fixes']]
out += [
    '',
    '本批只写指定scratch，未改队列、学习账本、代码提案队列、知识、版本或上线记录。无新修复无需更新bug-infra账本，不登记shipped。测试固定输入，无真实LLM或网络调用；原日志tsc.log/vitest.log及各自exit、verification.json保留。审计输入和结果见audit.py/audit.json/queue-snapshot.md/source.diff，准备失败见preparation-errors.txt。工作区与HEAD结束时仍干净不变。',
    '', '```json', json.dumps(result, ensure_ascii=False, indent=2), '```',
]
(SCRATCH / 'report.md').write_text('\n'.join(out) + '\n')
print(json.dumps({'report': result['report'], 'base': result['base'], 'fixes': 0, 'already_fixed_unchecked': len(fixed), 'unchecked_skipped': len(skipped), 'tests': result['tests'], 'merged': None}, ensure_ascii=False))

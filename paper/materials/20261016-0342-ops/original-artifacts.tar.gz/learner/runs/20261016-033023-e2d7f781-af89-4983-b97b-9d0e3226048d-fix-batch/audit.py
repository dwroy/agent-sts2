import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261016-033017'
SCRATCH = ROOT / 'learner/runs/20261016-033023-e2d7f781-af89-4983-b97b-9d0e3226048d-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-021305-766207d6-5101-44f3-aab1-d54eeb714401-fix-batch/audit.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, head):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', commit, head], cwd=WORK).returncode == 0


prior = json.loads(PRIOR.read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / '.worktrees/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert sha(queue) == prior['queue_sha256'], 'Queue changed: review the new entries before proceeding'
assert not git('status', '--porcelain').strip()
paths = sorted({f['path'] for fix in prior['existing_fixes'] for f in fix['files']})
assert not any(Path(p).name == '.env' or p.endswith('.env') for p in paths)
changed = git('diff', '--name-only', prior['base'], base, '--', *paths).decode().splitlines()
expected_changed = ['agent/src/reflex/card-model.ts', 'agent/src/reflex/combat-plan.ts', 'agent/src/reflex/turn-solver.ts']
assert changed == expected_changed + ['eval/versions.json'], changed
beam = '8d386fc7668820c2fc387d966f9d94bdcab189fb'
assert not git('diff', '--name-only', beam, base, '--', *expected_changed).strip()
assert ancestor(beam, base) and ancestor(beam, live)
files = []
for path in paths:
    current = (WORK / path).read_bytes()
    previous = next(f for fix in prior['existing_fixes'] for f in fix['files'] if f['path'] == path)
    if path not in changed:
        assert sha(current) == previous['sha256'], path
    files.append({'path': path, 'sha256': sha(current), 'same_as_prior': sha(current) == previous['sha256']})
fixes = []
for fix in prior['existing_fixes']:
    commit = fix['source_commit']
    in_base, in_live = ancestor(commit, base), ancestor(commit, live)
    assert in_base and in_live, (fix['item'], commit)
    fixes.append({'item': fix['item'], 'source_commit': commit, 'ancestor_in_base': in_base, 'ancestor_in_live': in_live})
lines = queue.decode().splitlines()
dispositions = []
for old in prior['queue_dispositions']:
    assert lines[old['line'] - 1] == old['item']
    item = dict(old)
    item['verification'] = '本批核队列字节及源码差异；既有来源均为当前main/live祖先，未改变的源码与前批SHA相同。'
    dispositions.append(item)
assert len(dispositions) == sum(line.startswith('- [ ]') for line in lines)
extra = [
    {'item': 'silent-0469：已观察聚合体纸鹤组合子项', 'source_commit': beam,
     'ancestor_in_base': True, 'ancestor_in_live': True,
     'scope': '仅HLAWCGM3KHVB A10 F49 T3已观察模板；不关闭完整纸鹤/未知组合父项'},
]
out = {
    'base': base, 'live_read_only_snapshot': live,
    'prior_audit': str(PRIOR), 'prior_audit_sha256': sha(PRIOR.read_bytes()),
    'prior_base': prior['base'], 'queue_sha256': sha(queue), 'queue_lines': len(lines),
    'queue_unchanged': True, 'unchecked_entries': len(dispositions),
    'existing_fixes': fixes, 'additional_existing_fixes': extra,
    'unique_source_paths': len(paths), 'current_files': files,
    'changed_source_paths_since_prior_base': changed,
    'change_review': '三个改动源码叶完全等于独立策略提交8d386fc76的当前实现；另有其eval发布记录，其余377叶逐SHA与前批相同。',
    'queue_dispositions': dispositions,
    'limits': [
        '未改源码，不空提交/空合入，不登记版本或shipped。',
        '本批只读live祖先；未声称当前live所有源码叶与main相同。',
        '游戏机制/题面知识沿已登记strategy-proposal，不重复登记或派下级。',
        '原nonpositive-hp资源尾部、目录删除者、通知发送事实与永久饥饿仍未知。',
    ],
}
(SCRATCH / 'audit.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'queue-snapshot.md').write_bytes(queue)
(SCRATCH / 'source.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--', 'agent', 'learner', 'ops', 'eval', 'knowledge/builders'))
print(json.dumps({k: out[k] for k in ('base', 'live_read_only_snapshot', 'queue_lines', 'unchecked_entries', 'unique_source_paths', 'changed_source_paths_since_prior_base')}, ensure_ascii=False))

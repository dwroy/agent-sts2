from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0342';pub=root/'paper/materials/20261016-0342-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],input=data,stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-033017-fix-batch';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='skipped'}=={k:v for k,v in report.items() if k!='skipped'}
assert len(scratch['skipped'])==len(report['skipped'])==32
assert [x['item'].split('：')[0] for x in scratch['skipped']]==[x['item'].split('：')[0] for x in report['skipped']]
assert b['state']=='failed' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors']
assert report['fixes']==report['code_proposals']==report['implementation_domains']==[] and report['merged'] is None and report['tests']==dict(tsc=0,vitest=0,cases=75)
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
assert not git('diff','--binary',report['base'],cwd=b['worktree']).strip()
verification=load(s/'verification.json');assert verification['tsc']==verification['vitest']==0 and verification['files']==10 and verification['cases']==75 and verification['retried'] is False and verification['full_sandbox_suite_run'] is False
assert (s/'tsc.exit').read_text().strip()==(s/'vitest.exit').read_text().strip()=='0'
assert 'Test Files  10 passed (10)' in (s/'vitest.log').read_text() and 'Tests  75 passed (75)' in (s/'vitest.log').read_text()
assert 'nice -n 19' in verification['tsc_command'] and 'nice -n 19' in verification['vitest_command'] and '--maxWorkers=1' in verification['vitest_command']
audit=load(s/'audit.json');prior_path=Path(audit['prior_audit']);assert prior_path.is_relative_to(root)
prior_raw=prior_path.read_bytes();assert sha(prior_raw)==audit['prior_audit_sha256'];prior=json.loads(prior_raw)
assert audit['base']==report['base'] and audit['prior_base']==prior['base'] and audit['queue_unchanged']
queue=(s/'queue-snapshot.md').read_bytes();lines=queue.splitlines(keepends=True)
assert sha(queue)==audit['queue_sha256']==prior['queue_sha256'] and len(lines)==audit['queue_lines']==prior['queue_lines']==1344
assert (root/'notes/fix-queue-v4.md').read_bytes().startswith(queue)
dispositions=audit['queue_dispositions'];assert audit['unchecked_entries']==len(dispositions)==42 and sum(x.startswith(b'- [ ]') for x in lines)==42
for x in dispositions:assert lines[x['line']-1].decode().rstrip('\r\n')==x['item']
assert sum(x.get('commit') is not None for x in dispositions)==16
assert len(audit['existing_fixes'])==len(prior['existing_fixes'])==74 and len(audit['additional_existing_fixes'])==1
for fix in audit['existing_fixes']+audit['additional_existing_fixes']:
    assert fix['ancestor_in_base'] and fix['ancestor_in_live']
    git('merge-base','--is-ancestor',fix['source_commit'],report['base']);git('merge-base','--is-ancestor',fix['source_commit'],audit['live_read_only_snapshot'])
leaves={row['path']:row for fix in prior['existing_fixes'] for row in fix['files']};current={row['path']:row for row in audit['current_files']}
assert set(current)==set(leaves) and len(current)==audit['unique_source_paths']==381
assert all(not path.endswith(('.env','.dll','.pck')) and 'auth.json' not in path and not path.startswith('third_party/') for path in current)
changes=git('diff','--name-only',prior['base'],report['base'],'--',*sorted(current)).decode().splitlines()
expected=['agent/src/reflex/card-model.ts','agent/src/reflex/combat-plan.ts','agent/src/reflex/turn-solver.ts','eval/versions.json']
assert changes==audit['changed_source_paths_since_prior_base']==expected
beam='8d386fc7668820c2fc387d966f9d94bdcab189fb'
assert not git('diff','--name-only',beam,report['base'],'--',*expected[:3]).strip()
assert (s/'source.diff').read_bytes()==git('diff','--binary',prior['base'],report['base'],'--','agent','learner','ops','eval','knowledge/builders')
requests=[(commit,path) for path in sorted(current) for commit in [report['base'],audit['live_read_only_snapshot']]]
raw=git('cat-file','--batch',data=''.join(commit+':'+path+'\n' for commit,path in requests).encode());handle=io.BytesIO(raw);blobs={}
for key in requests:
    header=handle.readline().rstrip(b'\n').split()
    if header[-1:]==[b'missing']:blobs[key]=None;continue
    assert header[1]==b'blob';size=int(header[2]);value=handle.read(size);assert len(value)==size and handle.read(1)==b'\n';blobs[key]=value
assert handle.read()==b'';absent=[];different=[]
for path,row in current.items():
    a=blobs[(report['base'],path)];z=blobs[(audit['live_read_only_snapshot'],path)]
    assert a is not None and sha(a)==row['sha256'] and (Path(b['worktree'])/path).read_bytes()==a
    assert (row['sha256']==leaves[path]['sha256'])==row['same_as_prior']==(path not in changes)
    if z is None:absent.append(path)
    elif a!=z:different.append(path)
assert sum(x['same_as_prior'] for x in current.values())==377
versions=json.loads(blobs[(report['base'],'eval/versions.json')]);releases=[x for x in versions['versions'] if x.get('release_id')=='V5-R365']
assert len(releases)==1 and releases[0]['commit']=='52495248f983fe8ba4b98ec1e626fb94a79e2aa5'
assert git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==audit['live_read_only_snapshot']
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_state=b['state'],original_rc=b['rc'],original_report=report,original_scratch_report=scratch,stdout_skip_reasons_abbreviated=True,skip_count_boundary='42 unchecked queue entries:16 covered subitems and26 remaining;32 report skips include those26 and6 additional broad scopes.',native=native,unchanged_clean_worktree=True,no_new_fix_or_merge_block=True,original_audit=audit,prior_raw_reference=dict(path=str(prior_path.relative_to(root)),sha256=sha(prior_raw)),source381_base_shas_and_prior_equalities_verified=True,source_diff_is_historical_comparison_not_current_worktree_delta=True,existing_beam_source=beam,existing_release=releases[0],live_absent_paths=absent,live_different_paths=different,original_verification=verification,no_production_tests_reexecuted=True,limits=['Original failed/rc0/mergednull retained; no source commit or merge is claimed.','The four changed covered leaves are existing R365 source and release metadata, not changes made by this batch.','Source ancestry does not imply current base/live leaf equality or wide-parent completion.','Existing strategy owners and evidence boundaries remain; no duplicate implementation or research.','Original resource/steps tails, notification history, directory lifecycle, leases and fairness remain unknown.','Original preparation scanner failure and initial allowlist/path errors retained; not product test failures.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([x for x in s.iterdir() if x.is_file()]+[out,out.with_suffix('.err'),prior_path]):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0342原033017-fix空修复回报核，原failed/rc0/mergednull保持；222d干净WT/HEAD不变，无新增源码或提交合入受阻，不空合/发号/再派。42未勾队列字节与前批1344行SHA相同，16已有窄覆盖及26原链待查分列，机器32 skipped另含六宽范围，不误计为32条队列或已关闭父项。74旧来源及独立策略8d386真实base/live祖先核；381当前base叶及相对旧基线SHA核，377不变，三源码精确等于已发布R365实现、另eval记录唯一号/behavior52495248保持，不当本批修复；当前live缺叶{len(absent)}/差叶{len(different)}分列，祖先不冒逐叶等同。source.diff仅历史基线比较（含ops记录），当前工作树diff为空。原tsc0、10文件75定向0/nice19单worker/无重跑/未full及原件SHA保，不借其当本树完整套件绿或再派宿主。目录扫描准备失败/审计允许列表漏eval记录/路径猜测原件保，不当产品故障或确定目录删除者；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。0332资源尾部根因、通知发送事实、租约与饥饿仍未知沿原owner；0481/0487与纸鹤宽范围保持原策略链。仅本人记录提交，无源码/知识/账本/队列/论文刷新/补测/对局重启或账号home模型额度权限prompt操作。证据paper/materials/20261016-0342-ops/。\n'
note=f'\n- {at} [运维 codex] 原033017修复批次无新增源码或合入受阻，原failed/rc0保持；原tsc及10文件75项定向通过，未跑完整套件。R365既有三源码和发布记录已核，42项队列继续原链，不空合、发号或补测。回执paper/materials/20261016-0342-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,original_state=b['state'],rc=0,existing_sources=74,additional_existing_sources=1,base_source_leaves=381,unchanged_source_leaves=377,existing_release_source_changes=changes,queue_entries=42,original_tsc=0,original_targeted_files=10,original_targeted_cases=75,original_targeted_exit=0,no_new_fix_commit_merge_release=True,no_tests_reexecuted=True,record_only=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(paths=len(entries),sources=75,leaves=381,no_new_source=True)))

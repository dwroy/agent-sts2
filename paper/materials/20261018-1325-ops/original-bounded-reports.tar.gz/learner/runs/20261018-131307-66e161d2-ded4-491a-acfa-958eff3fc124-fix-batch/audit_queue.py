"""Pin this no-change batch to the frozen queue and actual Git source objects."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261018-131302'
OUT = ROOT / 'learner/runs/20261018-131307-66e161d2-ded4-491a-acfa-958eff3fc124-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261018-121315-ea0c3df9-3269-4bfe-b5c5-c8ecf35727a9-fix-batch'
INVENTORY = ROOT / 'learner/runs/20261018-110259-5792e43b-7ed3-447e-94aa-2879edd38f81-fix-batch'
LIVE = ROOT / '.worktrees/live'


def git(*args, cwd=TREE):
    result = subprocess.run(['git', '-C', str(cwd), *args], capture_output=True)
    if result.returncode:
        raise RuntimeError((args, result.returncode, result.stderr.decode()))
    return result.stdout


def ancestor(source, target):
    result = subprocess.run(['git', '-C', str(TREE), 'merge-base', '--is-ancestor', source, target], capture_output=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode())
    return result.returncode == 0


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


base = git('rev-parse', 'HEAD').decode().strip()
assert base == 'b7ea1d2307cf4931c336548bf8938cebd827b63e'
assert not git('status', '--porcelain=v1', '--untracked-files=all')
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
raw = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
old = (PREVIOUS / 'fix-queue-input.md').read_bytes()
assert raw.startswith(old)
addition = raw[len(old):].decode()
assert '原silent-0365补证，非新增缺陷' in addition
assert 'silent-proposal-96b69a0a3883bd19' in addition
assert len([line for line in addition.splitlines() if line.startswith('- ')]) == 1
(OUT / 'fix-queue-input.md').write_bytes(raw)
(OUT / 'queue-delta.patch').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True), raw.decode().splitlines(True), fromfile='previous-frozen-queue', tofile='current-frozen-queue')))

previous = json.loads((PREVIOUS / 'queue-dispositions.json').read_text())
items = []
fixed_lines = {
    817: 'db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26',
    968: 'c1d84804956bedbd29a7f0e81294114e18415b9d',
    1024: '5baf663d7e6678efa3690e5a48329c4f8baee109',
    1029: '5b56a452bb9be14d620b368ec46974c1b57901ca',
    1034: '5b56a452bb9be14d620b368ec46974c1b57901ca',
    1401: 'a473263eb35ce5bea8e06f1ee94f4da1ba880bc3',
}
for number, line in enumerate(raw.decode().splitlines(), 1):
    if not line.startswith('- [ ]'):
        continue
    row = next(row.copy() for row in previous['items'] if row['text'] == line)
    row['line'] = number
    row['prior_classification_reference'] = str(PREVIOUS / 'queue-dispositions.json')
    if number in fixed_lines:
        row['commit'] = fixed_lines[number]
        row['disposition'] = '已有实际main/live源码窄修复；重新核当前源码对象及祖先，不因旧未勾选标记重复实现'
    if number in (1436, 1438):
        row['commit'] = '5ff419bbf2968a13167c6556885ced73736c6ec6'
        row['disposition'] = ('已修recheck的窄cherry-pick身份子项，已在当前main/live；'
                              '原unassigned_proof注册协议仍缺冻结报告中的base/runs与机器JSON，保留独立接续')
    if number == 1472:
        row['commit'] = '707702873705b81219a23915f4981060cfafff2e'
        row['disposition'] = '退出进程误判已有窄修复；原15秒宿主超时及宽性能归因证据不足，不据此关闭'
    if number == 959:
        row['disposition'] = '证据不足：silent-0332实际资源契约根因仍缺完整输入，已有诊断/时限窄修不外推根因'
    items.append(row)
assert len(items) == 57
save('queue-dispositions.json', {'path': str(ROOT / 'notes/fix-queue-v4.md'), 'sha256': sha(raw), 'items': items})

prior = json.loads((INVENTORY / 'queue-prior-readback.json').read_text())
fixed = [{'item': row['item'], 'commit': row['commit']} for row in prior['already_fixed']]
fixed.extend([
    {'item': 'R394 indifferent监控兼容子项', 'commit': '5011b4cbda9a9056a1fd146e375e3cd67b60c0a9'},
    {'item': '窄cherry-pick的recheck身份子项', 'commit': '5ff419bbf2968a13167c6556885ced73736c6ec6'},
])
for row in fixed:
    row['commit'] = git('rev-parse', row['commit'] + '^{commit}').decode().strip()
    row['in_base'] = ancestor(row['commit'], base)
    row['in_observed_live'] = ancestor(row['commit'], live)
assert all(row['in_base'] for row in fixed)
save('already-fixed-readback.json', fixed)

pending = []
for name, commit in [
    ('infra-paper-dataset-concurrent-gzip-keyscan-20261018', 'dee6386621e8122d123a3cd0017c3e4c199f524e'),  # Verified Git commit, not a credential. gitleaks:allow
    ('a406-fixed-deadlines五处消费夹具', '2a778b13ac1ead79afef957d4708c1df5dfd3757'),
]:
    paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()
    pending.append({'item': name, 'source_commit': commit, 'in_base': ancestor(commit, base),
                    'in_observed_live': ancestor(commit, live), 'changed_paths': paths,
                    'disposition': '已有原owner源码，沿原ops运输链；本批不重复实现/合入旧分支'})
save('pending-sources.json', pending)

previous_base = json.loads((PREVIOUS / 'result.json').read_text())['base']
source_roots = ['agent/src', 'agent/tests', 'agent/tools', 'learner/*.py', 'learner/*.ts', 'learner/lib',
                'learner/tasks', 'ops/*.py', 'ops/*.sh', 'ops/codex', 'ops/tests',
                'knowledge/builders', 'eval/*.py', 'eval/*.ts']
changes = git('diff', '--name-only', previous_base, base, '--', *source_roots).decode().splitlines()
assert set(changes) == {'ops/learner_checks.py', 'ops/tests/test_learner_cherry_pick_recheck.py',
                        'agent/tests/learner-cherry-pick-recheck.test.ts'}
paths = set(changes)
for row in prior['already_fixed']:
    for path in row.get('source_paths', []):
        if path.startswith(('agent/src/', 'agent/tests/', 'agent/tools/', 'ops/', 'learner/')):
            if '/runs/' not in path and not Path(path).name.startswith('.env'):
                paths.add(path)
pins = []
for path in sorted(paths):
    entry = git('ls-tree', base, '--', path).decode().strip()
    if not entry:
        pins.append({'path': path, 'absent_at_base': True})
        continue
    mode, kind, blob = entry.split('\t')[0].split()
    if kind != 'blob' or mode == '120000':
        continue
    body = git('show', base + ':' + path)
    current = TREE / path
    assert current.is_file() and current.read_bytes() == body, path
    pins.append({'path': path, 'mode': mode, 'blob': blob, 'sha256': sha(body),
                 'same_as_previous_base': not bool(git('diff', '--name-only', previous_base, base, '--', path))})
save('source-pins.json', pins)

references = []
for path in [PREVIOUS / 'result.json', PREVIOUS / 'queue-dispositions.json',
             PREVIOUS / 'fix-queue-input.md', INVENTORY / 'queue-prior-readback.json',
             TREE / 'README.md', TREE / 'AGENTS.md', TREE / 'paper/materials/STATE-2026-10-18.md',
             TREE / 'docs/learning-protocol.md', TREE / 'docs/learning-code-proposals.md']:
    body = path.read_bytes()
    references.append({'path': str(path), 'bytes': len(body), 'sha256': sha(body)})
save('input-manifest.json', references)
save('audit-summary.json', {'base': base, 'observed_live': live, 'queue_sha256': sha(raw),
                          'explicit_unchecked_items': len(items), 'existing_fix_sources': len(fixed),
                          'existing_fix_sources_in_live': sum(row['in_observed_live'] for row in fixed),
                          'source_pins': len(pins), 'changed_source_since_previous_batch_base': changes,
                          'queue_addition': addition, 'new_source_changes': [], 'new_test_runs': [],
                          'merged': None, 'reason': '没有新的源码修复需要合入；既有发布/宿主回执与本批验收分列'})
print(json.dumps({'unchecked': len(items), 'already_fixed': len(fixed), 'source_pins': len(pins),
                  'in_observed_live': sum(row['in_observed_live'] for row in fixed), 'pending': pending}, ensure_ascii=False))

"""Write the requested report without inventing fixes, tests, or a publication."""
from pathlib import Path
import json

OUT = Path('/home/dw/Projects/agent-sts2/learner/runs/20261018-131307-66e161d2-ded4-491a-acfa-958eff3fc124-fix-batch')
summary = json.loads((OUT / 'audit-summary.json').read_text())
fixed = json.loads((OUT / 'already-fixed-readback.json').read_text())
skipped = [
    {'item': '出牌/药水/SL/终局/路线及角色机制未完成项（含0365最新补证）',
     'reason': '策略类：沿原strategy-proposal及原证据链；本批无新增独立纯bug，不重复提案或补游戏知识。'},
    {'item': 'silent-0332实际资源契约根因',
     'reason': '证据不足：缺完整原resources/steps及触发输入，诊断/时限/样本身份窄修不等于根因解决。'},
    {'item': 'U5W7NUE925NK F15/F16原G2缺DPR告警完整根因',
     'reason': '证据不足：原未来样本数组及配对分母未保存；已有预算/零前缀窄修不冒认整项。'},
    {'item': 'sandbox-glob-startup-race生命周期、磁盘/宿主超时与DPR性能宽项',
     'reason': '证据不足：已有恢复/租约/回收/固定夹具窄修，不据定向补验认定CPU、产品或调度因果。'},
    {'item': 'arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression / 调度公平性',
     'reason': '太大：独立架构、策略或归因任务，不混入普通纯bug批次。'},
    {'item': 'core-build-notify-222802-rc2旧通知恢复',
     'reason': '证据不足：stderr持久化已修，旧实际送达未证；不重复发消息或代填ACK。'},
    {'item': 'unassigned_proof原窄cherry-pick提案登记宽项',
     'reason': '太大：原Markdown无机器JSON、原输出缺base/runs；需独立冻结原注册/报告/发布协议，recheck窄修已在main/live。'},
    {'item': 'infra-paper-dataset-concurrent-gzip-keyscan-20261018',
     'reason': '已有源dee6386621e8122d123a3cd0017c3e4c199f524e，当前main/live未含；队列明确保原ops运输链，不重复实现。'},
    {'item': 'a406-fixed-deadlines五处消费夹具',
     'reason': '已有源2a778b13ac1ead79afef957d4708c1df5dfd3757，当前main/live未含；保原ops运输链，不盲叠候选。'},
    {'item': '21bf-fake-herdr-workspace-deadline及一般固定测试性能根因',
     'reason': '证据不足：退出进程误判已由707702873窄修，原15秒宿主超时及宽因果未证；保原失败、时限和断言。'},
    {'item': 'infra-chest-claimed-action-conflict-0516',
     'reason': '证据不足：缺领取请求和有界确认契约；沿原结构提案cf77920511042e9c核实。'},
]
result = {
    'task': 'fix-batch', 'base': summary['base'], 'fixes': [], 'skipped': skipped,
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': 0},
    'code_proposals': [], 'implementation_domains': [], 'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
lines = [
    '## 修 bug 回报', '',
    f"- 合并基线：main → {summary['base']}",
    '- 修复（每条一行）：无新增修复；57条显式未勾选项已逐字核验，未新增代码或提交。',
]
lines += [f"- 已被别人修掉的：{row['item']} — {row['commit']}" for row in fixed]
lines += [f"- 没修的：{row['item']} — {row['reason']}" for row in skipped]
lines += [
    '- 测试：tsc未运行；vitest 0文件 / 0用例 / 未运行；本批无源码变更，无撤修复试验或超时重跑。源码对象/字节与祖先核验不是测试结果；未借用原批宿主绿。',
    f"- 合入：未合入（本批无源码差异）；上述62个既有修复提交均已为观测live {summary['observed_live']} 的祖先。未操作live锁、知识刷新或版本/账本。", 
    '- 需要 Roy 定的事（没有写「无」）：无', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
]
(OUT / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'report': result['report'], 'already_fixed': len(fixed), 'fixes': 0,
                  'skipped': len(skipped), 'tests': result['tests'], 'merged': None}, ensure_ascii=False))

"""Verify observed frame arithmetic; this does not execute production strategies."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = json.loads((HERE / 'state-index.json').read_text())
checks = []

def frame(line, run, floor, turn=None):
    row = states[str(line)]
    assert row['run_id'] == run and row['floor'] == floor
    if turn is not None:
        assert row['turn'] == turn
    return row

def change(before, after, run, floor):
    a, b = frame(before, run, floor), frame(after, run, floor)
    assert [e['id'] for e in a['enemies']] == [e['id'] for e in b['enemies']]
    return [a['hp'] - b['hp'], sum(e['hp'] for e in a['enemies']) - sum(e['hp'] for e in b['enemies'])]

wq = 'WQZVENQ7DTRP'
txz = 'TXZ6RVMQA09D'
nha = 'NHA2KW0RB7VP'
wq9 = [change(282075, 282079, wq, 33), change(282144, 282148, wq, 33)]
assert wq9 == [[13, 24], [22, 39]]
checks.append({'case': 'WQ F33 T9 第二/三次', 'actual': wq9, 'frames': [282075,282079,282144,282148]})
wq7 = [change(282066, 282072, wq, 33), change(282330, 282336, wq, 33)]
assert wq7 == [[0, 24], [4, 24]]
sand_after = [frame(n, wq, 33)['enemies'][0]['powers']['SANDPIT_POWER'] for n in [282071,282335]]
sand_next = [frame(n, wq, 33)['enemies'][0]['powers']['SANDPIT_POWER'] for n in [282072,282336]]
assert sand_after == [4,5] and sand_next == [3,4]
checks.append({'case': 'WQ F33 T7 第二/六次', 'actual': wq7, 'sand_before_enemy_turn': sand_after, 'sand_next_player_turn': sand_next})
txz6 = [change(281479,281484,txz,48), change(281535,281539,txz,48)]
assert txz6 == [[3,36],[0,27]]
checks.append({'case':'TXZ F48 T6 第二/三次','actual':txz6,'frames':[281479,281484,281535,281539]})
q6 = [frame(n,'Q6M2Y34MWKRE',8)['enemies'][0]['hp'] for n in range(282887,282893)]
assert q6 == [103,95,85,85,83,80]
checks.append({'case':'Q6 F8 T4 普通紧勒','enemy_hp':q6,'frames':list(range(282887,282893))})
# The first room-transition frame has neither a hand nor actionable energy.
assert not frame(283390,nha,33,1)['hand'] and frame(283390,nha,33,1)['energy'] == 0
nha1 = [change(283391,283397,nha,33), change(283502,283507,nha,33)]
assert nha1 == [[1,8],[7,24]]
checks.append({'case':'NHA F33 T1 第一/六次','actual':nha1,'frames':[283391,283397,283502,283507], 'limitation':'跨轮净扣包含次轮自动伤；283390是房间切换空手0能量帧，不作可操作入口。'})
ken = 'KEN58SH9SLZ6'
rests = [[frame(a,ken,f)['hp'],frame(b,ken,f)['hp']] for a,b,f in [(280336,280337,12),(280382,280383,16)]]
assert rests == [[26,53],[46,75]]
rooms = [(280170,280197,2),(280199,280225,3),(280227,280254,4),(280256,280285,5),(280309,280335,11),(280348,280381,15)]
losses = [frame(a,ken,f)['hp'] - frame(b,ken,f)['hp'] for a,b,f in rooms]
assert losses == [0,3,0,37,6,0] and sum(losses) == 46
checks.append({'case':'KEN六场胜战/两次休息','hp_loss':losses,'rest_hp':rests,'frames':[n for a,b,f in rooms for n in (a,b)]})
assert frame(282756,'1913SE84AXQF',31)['hp'] == 46
assert frame(282912,'Q6M2Y34MWKRE',8)['hp'] == 2
assert frame(282914,'Q6M2Y34MWKRE',9)['hp'] == 2
checks.append({'case':'连续资源实际入口','1913_f31':46,'q6_f8_exit_and_f9_entry':2,'frames':[282756,282912,282914]})
cunning = json.loads((HERE/'cunning-observations.json').read_text())
assert len(cunning)==42 and all(x['added']==x['shivs_added'] and x['upgraded_shivs_after'] for x in cunning)
assert all(x['decision_lines'] and x['hp_unchanged'] and x['energy_unchanged'] for x in cunning)
checks.append({'case':'狡诈42饮','all_have_potion_action':True,'all_added_match_shivs':True,'all_shivs_upgraded':True})
raw_windows = []
with (HERE/'evidence/states.evidence.jsonl').open() as f:
    for line in f:
        item=json.loads(line)
        if item['line'] not in (283394,283395):
            continue
        assert item['run_id']==nha
        relics=item['row']['state']['run']['relics']
        lamp=next(r for r in relics if r.get('relic_id')=='UNSETTLING_LAMP')
        assert lamp.get('stack') is None
        raw_windows.append({'line':item['line'],'run_id':item['run_id'],'lamp':lamp})
assert len(raw_windows)==2
checks.append({'case':'油灯首次负面消费前后','windows':raw_windows,'limitation':'stack均null，不是可验证的消费状态。'})
(HERE/'additional-material-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'production_tests':False,'status':'verified'},ensure_ascii=False))

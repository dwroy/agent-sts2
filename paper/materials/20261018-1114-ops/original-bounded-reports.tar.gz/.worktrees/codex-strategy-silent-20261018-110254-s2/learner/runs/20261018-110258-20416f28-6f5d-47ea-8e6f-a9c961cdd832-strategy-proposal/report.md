# 静默猎手策略批次报告

记录时间：2026-10-18T11:12:54+08:00。

本批十个已领取提案逐项核验后均保留waiting；没有新增源码、策略参数、经验知识、提交、合入或行为版本。原案需要的完整后继、组合消费者及受控独立验证仍不足，已有子实现不等于父提案全部验收。逐项证据局/层/回合、账本、支持、反例、旧/拟议行为与验证见[proposal.md](proposal.md)，机械处置见proposal-results.json。报告完成不关闭父提案或学习要求。

## 身份与基线

根learn.json对应20261018-110254-s2-strategy-proposal，task=strategy-proposal、character=silent、reason=proposal，工作树路径和十个proposal_ids完全匹配；没有research_request、implementation_request或proposal_repair。普通专题文件绑定其他批次，不读取其work_spec/manifest，不扩选其他队列项。

初始HEAD=92024e9e266ee78e29d9909029971f320bb122fe，git status为空。按普通任务执行git merge --no-edit main，纯记录快进，无冲突。report.base=21a1992020b5cb6833b75a7aaa5180b4515242a0；之后固定该基线。十份原提案SHA全部核同并保留original-proposals/；31条关联账本及26条active Silent经验的快照保存，不重复写复盘或登记新提案id。

runtime-profile.json保存启动声明及原生conversation_starts：gpt-6.1-sol / xhigh / default，线程01a14cf6-7336-7b13-8588-e1d93f1a133e。题面要求high，但宿主实际启动为xhigh；本批不把参数声明成high，也未改线程、模型或配置。原生会话事件核验不同于仅凭默认配置推断；没有降强度提速或派下级agent。

## 原始证据与材料核验

十个派发锚点全部读取；仅为处理原案补充1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR，共15局，runs.jsonl逐局核为SILENT。K367为A1、SAD为A7、F4Q为A9，其余为A10；不混进阶拟合。verified-runs.json保存核实记录。历史dirty代码声明不能还原为精确运行源码。

通过本工作树learner/extract_evidence.py共用入口读取八流，各流单独冻结source_size；原始行保留offset/bytes/SHA和显式归局，拒绝冲突身份，不以正文提及当所属局。evidence/evidence-manifest.json列各流计数及输出SHA。截点不是跨文件原子快照。

| 流 | 所选行数 | source_size字节 |
|---|---:|---:|
| states | 9815 | 14295895818 |
| decisions | 9448 | 2510091931 |
| sl-attempts | 78 | 47743216 |
| run-config | 15 | 2080396 |
| run-plans | 77 | 9297388 |
| brain | 481 | 809399283 |
| runs | 15 | 371605 |
| fight-plans | 0 | 2233957 |

audit_evidence.py重新seek每一条原日志，核原字节SHA、JSON正文、run身份、截点和输出SHA，19,929条全部一致；所有所选状态角色也均核为silent。states/decisions/brain各观察到源文件2条坏行，不能归入目标局或计作新增样本。fight-plans在该截点选中0行，仅说明该范围未选到，不证明原历史缺失。未覆盖原案105/109局全史，不把15局或42饮冒作全历史独立样本。

material-audit.log实际退出0；audit_selected_windows.py的9组检查亦退出0，保存additional-material-audit.log、additional-material-checks.json。它们是原始材料的字节/算术核验，不是生产源码测试、消费者回放、Boss模拟或自然大脑消费；没有调用LLM、网络或运行play。

## 已复核的具体结论

- KEN七个饮用动作均核回；F2/3/4/5/11/15六胜战实际净损0/3/0/37/6/0，合46。F12真实26→53、F16真实46→75；F5赢仍损37，F15零损仍耗药。没有不喝也相同的对照，不能更新持药价。
- TXZ F48第二/三次T6实损/敌净扣3/36与0/27；首战赢只剩4，F49出牌前4→0、cards_played=0、敌111。首胜和两战通关分别验收，后续抽牌/生成变化不能当受控对照。
- WQ F33第二/三次T9为13/24与22/39，多损9换15伤；T7反例为多损4、同伤24而沙坑延时1。结束动作前沙坑4/5与下一玩家轮初3/4分开，不能混用结算时点或据全败并列认同安全。
- 九个来源局42次狡诈饮用均有相邻实际饮用动作，37次添3、2次添2、3次添0，新增数与小刀增量一致且均升级，HP/能量不变。容量不足仍只来自WQ同一局；生成公式存在不证明完整保留/穿插/恢复已验证。
- Q6普通紧勒逐帧敌HP103→95→85→85→83→80。NHA首/末T1分别损1/7、跨轮敌净扣8/24；次轮自动伤另列。NHA状态283390是空手0能量的房间切换帧，实际可操作入口为283391的30血，不能用前帧28血计算血价。
- 1913实际F31入口46；Q6 F8胜后2并以2入F9。锻造、未抵达营火、事件与战内再生不能混作已到账回血或同条件预测误差。
- NHA首次萎靡前后两个油灯遗物对象stack均null；有局部放大实帧，不代表已观测消费状态。跨动作、新战、SL恢复及其他负面组合仍未知，不自行补规则。

本批未发现需要推翻上述原案限定结论的新反证；反例和未知仍逐项保留。无新增独立support/repeat分母，不将同战SL拆为独立训练或验证局，也不声称任何替线本可救局。

## 源码定位与部分覆盖

source-provenance.json及additional-source-provenance.json固定11份基线源码blob/SHA和13处来源定位；source/只保存必要.txt原字节，base-to-live.patch及live-working.patch保存有界diff。观察时实际live HEAD=b155d00a36080418149e63d2f21b491d34d7f40a；11份中5份工作字节与本基线不同，因此不宣称两整树等价，不覆盖并行修改。13处源码来源提交均核为该实际live提交祖先，只支持对应子范围：

| 子范围 | 实际live祖先源码提交 |
|---|---|
| 普通紧勒与SL当轮资源差额 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac |
| 沙坑/结束战斗差额诊断 | 0e4fe4df89a06682468e0e4716c12126e76369d5 |
| 狡诈生成/容量/余刀结转和限定开场四血 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| 连战同样本资源传递 | a8b202e34e94b11a340a8733800f7018688371b8 |
| 普通磨蚀付费出牌 | a5f588dfdb3fd254fded2d6cacb646672b90cc14 |
| 已观察蟹朝向 | 68711002f15b298b8863d2258ee5da236da151d2 |
| 普通精确切击手数分支 | 8b9bacbebb20eaaa1133a9945da6c7abfcda745d |

现行SL诊断明示execution=unverified/actual_turn_result=null，不把候选步骤当完整实际派发。参数和门槛维持的原因是证据不足；没有因规则由Roy制定而额外要求批准。其他角色与未观察进阶无行为改动。

## 派发逐项处置

| 提案id | 状态 | 尚缺证据/验收范围 |
|---|---|---|
| silent-proposal-08eaa60bcc449852 | waiting | 固定核七饮、两次休息及Boss六试入口；未来按独立run与时间留出验证不用/早用/留用的完整两战资源。缺少成对实际后继，waiting。 |
| silent-proposal-92920295a648b540 | waiting | 需要固定完整后继及同预算的两战成对结果；单局三试不能拆成独立验证。已有子实现不等于整项验收，waiting。 |
| silent-proposal-a327449c331efbc1 | waiting | 固定同盘面的原答/替线与动作后时点，另需同抽序、同预算完整执行及独立run验证排序；保留waiting。 |
| silent-proposal-a099e89437e942bb | waiting | 固定3/2/0和剩刀结转可复核；原案还需计划妥当选择、抽牌后新题、SL恢复与完整穿插实际派发联合验证。整项waiting。 |
| silent-proposal-47910f82a1fdd98f | waiting | 需要未观察组合时序、完整后继和两战校准；现有窄分支的真实live祖先只作子项来源，不登记父提案duplicate，waiting。 |
| silent-proposal-f1374df72d8e6a25 | waiting | 缺不用/早用/留药的同预算完整后继，局部候选不作为收益；按run/时间分组而非状态帧拟合，waiting。 |
| silent-proposal-38a49e6c97f31eea | waiting | 联合验证弃磨蚀、增益分源、自动效果、再生时点、SL恢复和完整后继仍未齐。已有子实现不关闭此组合提案，waiting。 |
| silent-proposal-ef0e38a5dbd3bc07 | waiting | 需要另一事件/路线/营火动作与用药时点的完整成对后继；旧109局统计未在本批全量重做，不拿15局冒充全史，waiting。 |
| silent-proposal-7f820c02d39bfaea | waiting | 缺相同预算排序校准、跨弃牌的完整执行归属和成对整战后继。实际candidate/派发/结果分开验收，waiting。 |
| silent-proposal-04b6b430759815ed | waiting | 需要可追溯消费状态、跨动作/新战/SL恢复和消费者联合固定验证；无完整早建能力或用药获胜对照，waiting。 |

## 记录、测试与交付

只通过根learner/ledger.py update追加31条原账本的本批proposal/report路径及相关waiting理由，by=learner:strategy-proposal；不添加证据，不改claim、first_run、asc、prior_note、evidence、status、version或effect。旧shipped经验不降级为proposed，也不代运维登记本批shipped。输入、CLI结果和保护字段读回另保存在ledger-updates.jsonl、ledger-cli.out、ledger-readback.json。

没有源码变更，撤源码失败/恢复验证不适用；没有运行tsc、vitest或test-sandbox，tests固定为三个null，不引用旧批测试成功。本批没有提交，因此无提交前gitleaks或Co-Authored-By记录；没有live合入、eval编号、上线决定记录或规则双通知，不伪造merged/implemented。fixes=[]、merged=null、implementation_domains=[]。

最终HEAD及干净工作树读回、原案SHA、派发十id与十waiting一致性保存workspace-verification.json；正式机器回报保存result.json。所有原日志、失败历史、缺数据和当前现场保留，回收交原调度器；不删除仍运行的自身工作树。

最终读回：2026-10-18T11:14:07+08:00，31条根账本CLI追加退出0，所有保护字段不变且proposal/report链接均实读；13处源码定位在实际live工作字节中逐行核回一致（不代表整文件或整树一致）。十原案SHA保持、十个派发ID与十waiting逐项对应。HEAD仍等于base，git status为空，tracked binary diff为0字节；最终结果链接校验通过。

# 静默猎手本批十项策略提案复核

批次：20261018-110254-s2-strategy-proposal。基线：21a1992020b5cb6833b75a7aaa5180b4515242a0。原始十份Markdown及其SHA保存在original-proposals/与assigned-proposals.json；不改原案、不新建重复id。

本批只消费派发十项；普通专题文件绑定其他批，不读取其研究输入。仅核实的十五个静默局用于证据，不读取其他角色知识或外部游戏资料。普通流程合入main为纯记录快进，之后固定该base。

以下为原案限定结论及本批复核目标，原帧材料最终核验见report.md和material-checks.json。每项均无足够新增证据完成原案全部范围，保留waiting。

## silent-proposal-08eaa60bcc449852

原案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md；SHA256=4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016。

来源任务：experience-update；实现任务：strategy-proposal；领域：potion。本次不新增代码或实施领域。

账本：silent-0019, silent-0020。

证据局/层/回合：KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1；F12/F16真实休息。账本silent-0019/0020。

支持和观察：七次饮用，六场胜战净损合46；F5赢仍损37，F15零损仍耗两药。两次真实回复27/29，SL恢复与路线回复分开。

反例及未知：零损战仍花药；没有相同入口、牌组、后继动作和预算下不喝或留药至Boss的整战对照。不能把已喝药的零损当不喝也零损。

旧规则与预期行为：保留当前持药价和饮用规则；将实际获药/饮用/弃药/SL恢复分别核账，不拟合固定留药阈值。

验证及处置：固定核七饮、两次休息及Boss六试入口；未来按独立run与时间留出验证不用/早用/留用的完整两战资源。缺少成对实际后继，waiting。

## silent-proposal-92920295a648b540

原案：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md；SHA256=f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf。

来源任务：postmortem；实现任务：strategy-proposal；领域：combat, sl, terminal。本次不新增代码或实施领域。

账本：silent-0228, silent-0255。

证据局/层/回合：TXZ6RVMQA09D A10 F48第二/三次T6、第三次T10与F49开场T1；账本silent-0228/0255。

支持和观察：同盘48血、敌460血，第二次实损3/敌净扣36，第三次0/27；首战赢后4血，下一房出牌前4→0且敌111。

反例及未知：少损3也少扣9；后续抽牌/生成/出牌变动，首战胜利不能代表两战胜利。低可信模拟的1200首胜/1200后败不是实盘胜率或必死证明。

旧规则与预期行为：现有连战目标和同样本资源传递保留；完整审计需分首胜、药栏/复活、后场开场和可操作帧。

验证及处置：需要固定完整后继及同预算的两战成对结果；单局三试不能拆成独立验证。已有子实现不等于整项验收，waiting。

## silent-proposal-a327449c331efbc1

原案：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md；SHA256=e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925。

来源任务：postmortem；实现任务：strategy-proposal；领域：combat, sl。本次不新增代码或实施领域。

账本：silent-0079, silent-0018。

证据局/层/回合：WQZVENQ7DTRP A10 F33第二/三次T9及末次T7/T11；账本silent-0079/0018。

支持和观察：T9实损/敌净扣13/24→22/39，多损9换15伤；T7实损0→4、同伤24，结束动作前沙坑4→5、下一玩家轮初3→4。

反例及未知：花4血延时一轮约束“总保血”结论；全败模拟并列不能证明实际血价相同，也无固定后继胜局。

旧规则与预期行为：已有当轮血伤/毒/沙坑诊断继续使用；不新增血伤兑换率、延时价值或SL准入阈值。

验证及处置：固定同盘面的原答/替线与动作后时点，另需同抽序、同预算完整执行及独立run验证排序；保留waiting。

## silent-proposal-a099e89437e942bb

原案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md；SHA256=e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2。

来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion。本次不新增代码或实施领域。

账本：silent-0030, silent-0257, silent-0258。

证据局/层/回合：原提案九局02HB4L0C3C67、4D4J8USKCPAV、F4QKG4J1AJJZ、JLN5SK17W4FQ、LS8035TB32P3、NB8KCF6HRGVF、S9UZAK0JP0C0、SADL3CGYTGSR、WQZVENQ7DTRP；重点WQ F33第五/六次T11、NB F31T5、SAD F8T1；账本silent-0030/0257/0258。

支持和观察：42次狡诈饮用：37次添3、2次添2、3次添0；WQ八手连饮为2/0/0、五手为3/2/0，新刀均升级。

反例及未知：容量受限的样本只来自WQ一局；满手耗瓶却不添刀。完整穿插执行未出现受控获胜线，不能声称多出刀可救局。

旧规则与预期行为：当前生成、手位截断和余刀结转已有子实现。保留计划妥当、跨抽牌重新规划及恢复等尚未联合验收边界，不另写相同生成公式。

验证及处置：固定3/2/0和剩刀结转可复核；原案还需计划妥当选择、抽牌后新题、SL恢复与完整穿插实际派发联合验证。整项waiting。

## silent-proposal-47910f82a1fdd98f

原案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md；SHA256=d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd。

来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion, sl, terminal。本次不新增代码或实施领域。

账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。

证据局/层/回合：TXZ6RVMQA09D A10 F43/F45/F46/F48/F49 T1及F48T6；WQZVENQ7DTRP F33T7/T9/T11；账本取原案全链。

支持和观察：TX五个新战前资源70→66、52→48、62→58、60→56、4→0；WQ血伤和沙坑的双向代价同前案。

反例及未知：有未知回血、复活或不同遗物组合时不能套用限定4点；SL恢复不是路线收益。没有完整两战受控优胜线。

旧规则与预期行为：保留限定王室猛毒开场及首战样本实际资源结转；不重复扣现场T1或SL恢复已结算开场，不预支未来药/能力。

验证及处置：需要未观察组合时序、完整后继和两战校准；现有窄分支的真实live祖先只作子项来源，不登记父提案duplicate，waiting。

## silent-proposal-f1374df72d8e6a25

原案：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md；SHA256=df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0。

来源任务：postmortem；实现任务：strategy-proposal；领域：combat, potion, terminal。本次不新增代码或实施领域。

账本：silent-0019, silent-0020, silent-0050, silent-0253。

证据局/层/回合：1913SE84AXQF A10 F17/F19/F23/F24/F28/F29/F31；Q6M2Y34MWKRE A10 F2T1/T3、F8T1/T7、F9T2；账本silent-0019/0020/0050/0253。

支持和观察：1913 F29胜61→46后F31入46；Q6 F8精英胜57→2后F9死。Q6 F2敏捷药早用候选未整线执行，速度药的临时敏捷次轮消失。

反例及未知：F5/F6零损留药是反例；实际两瓶均喝不等丢弃。路线中锻造替代预计休息，预测条件已变；机制误差不能当药价误差。

旧规则与预期行为：现药价/终局权重保持；先隔离机制偏差，再按相同入口和资源链比较当前胜战后继价值。

验证及处置：缺不用/早用/留药的同预算完整后继，局部候选不作为收益；按run/时间分组而非状态帧拟合，waiting。

## silent-proposal-38a49e6c97f31eea

原案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md；SHA256=6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0。

来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion, sl。本次不新增代码或实施领域。

账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。

证据局/层/回合：Q6M2Y34MWKRE A10 F8T4普通紧勒、F2T3力量/敏捷和F8T5—T8；1913SE84AXQF A10 F17再生、F31T2—T4弃磨蚀及千足虫；账本取原案全链。

支持和观察：Q6紧勒链敌HP103→95→85→85→83→80；1913弃磨蚀能量不变且建1敏/4荆棘，付费出牌与弃牌是不同分支。

反例及未知：普通紧勒无挡窄分支不涵盖升级/叠层/重放/有挡；自动效果、弃牌与普通出牌不能混为同一消费者。再生净回复与敌伤分账。

旧规则与预期行为：普通紧勒和普通磨蚀付费出牌已有live子实现；保持未观察分支，不把局部机制修正当整战胜因。

验证及处置：联合验证弃磨蚀、增益分源、自动效果、再生时点、SL恢复和完整后继仍未齐。已有子实现不关闭此组合提案，waiting。

## silent-proposal-ef0e38a5dbd3bc07

原案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md；SHA256=d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5。

来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion, terminal。本次不新增代码或实施领域。

账本：silent-0019, silent-0020, silent-0021。

证据局/层/回合：1913SE84AXQF A10 F18计划/F24锻造/F28休息/F29胜后/F31入口；Q6M2Y34MWKRE A10 F3事件/F7休息/F8胜后/F9死亡；账本silent-0019/0020/0021。

支持和观察：1913实际F31入46，未来F32营火未到；Q6休36→57、精英胜后2。实际营火、锻造、幕间、战内再生和事件分别核账。

反例及未知：敌组、牌组、最大生命和动作改变造成混杂；没有另一营火选择或整条路线的受控结果，不能由低血失败推出固定安全线。

旧规则与预期行为：不预支尚未完成的回血或能力，现有路线/休息/终局参数保持；不重复既有经验入库。

验证及处置：需要另一事件/路线/营火动作与用药时点的完整成对后继；旧109局统计未在本批全量重做，不拿15局冒充全史，waiting。

## silent-proposal-7f820c02d39bfaea

原案：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md；SHA256=bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105。

来源任务：postmortem；实现任务：strategy-proposal；领域：combat, sl。本次不新增代码或实施领域。

账本：silent-0079。

证据局/层/回合：NHA2KW0RB7VP A10 F33第1—4/第5—6次T1及T2—T4；账本silent-0079。

支持和观察：原整轮14挡实损1、跨轮敌净扣8；后整轮8挡实损7、跨轮净扣24。自动伤与卡牌伤分源。

反例及未知：六试全部失败；第5/6次不是独立成功或样本外验证。初题精确切击经弃牌重问，首个派发不能代表全部候选已执行。

旧规则与预期行为：当前SL差额诊断保留执行未核标记；不从全死饱和推导同安全或固定新血价门槛。

验证及处置：缺相同预算排序校准、跨弃牌的完整执行归属和成对整战后继。实际candidate/派发/结果分开验收，waiting。

## silent-proposal-04b6b430759815ed

原案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md；SHA256=188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58。

来源任务：experience-update；实现任务：strategy-proposal；领域：combat, terminal。本次不新增代码或实施领域。

账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。

证据局/层/回合：NHA2KW0RB7VP A10 F17T1精确切击、F33T1萎靡/T2蟹朝向/T4能力；K3676LU8B0UH A1 F30T2、SADL3CGYTGSR A7 F45首施毒；账本取原案全链。

支持和观察：油灯首次毒/萎靡放大有局部实帧，遗物对象stack在消费前后均null；普通精确切击及限定蟹朝向已有子实现。

反例及未知：仅持有油灯不足知道本战首次消费是否已经发生；原dirty运行树不可还原。未验证其他负面、零X、升级、叠层及新战/SL重置，不填为通用规则。

旧规则与预期行为：保留已观察手数与朝向窄实现；不凭null堆层或遗物持有伪造首次消费状态，不预支未触发能力。

验证及处置：需要可追溯消费状态、跨动作/新战/SL恢复和消费者联合固定验证；无完整早建能力或用药获胜对照，waiting。

## 方法、来源和回退

只复算原始同角色帧及实际动作，不把rollout次数、SL尝试或相邻帧当独立局。不拟合新阈值；若以后证据足够，按完整run及开始时间隔离发现、拟合和后期验证。授权Roy-2026-10-07-learning允许有证据的修改，不提供游戏事实。

已实现子项的源码与实际live祖先校验见source-provenance.json和additional-source-provenance.json；原案全范围尚未闭合，不把部分覆盖上报implemented/duplicate。本批源码、知识、游戏行为均不改，无行为回退项；后续每项实现单独提交，验证失败只撤该提交，保留原证据和并行学习。

无新经验或新提案id；既有账本仅经根ledger.py追加本批去处/限制，不新增support/repeat分母、不降级旧shipped状态，不代ops登记shipped。父提案保留等待后续数据，不以本报告结束关闭学习要求。

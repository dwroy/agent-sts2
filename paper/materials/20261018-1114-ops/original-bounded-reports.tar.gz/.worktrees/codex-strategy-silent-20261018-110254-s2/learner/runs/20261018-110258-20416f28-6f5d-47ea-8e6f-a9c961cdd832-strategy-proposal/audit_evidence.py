"""Recompute bounded proposal observations; this is a research artifact, not a production test."""
import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def powers(values):
    return {x["power_id"]: x.get("amount") for x in (values or [])}


def project(item):
    row = item["row"]
    state = row["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    hand = combat.get("hand") or []
    return {
        "line": item["line"], "run_id": item["run_id"], "ts": row["ts"],
        "floor": run.get("floor"), "turn": state.get("turn"), "screen": state.get("screen"),
        "in_combat": state.get("in_combat"), "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "combat_hp": player.get("current_hp"), "energy": player.get("energy"), "block": player.get("block"),
        "cards_played": player.get("cards_played_this_turn"), "powers": powers(player.get("powers")),
        "potions": {str(p["index"]): p.get("potion_id") for p in run.get("potions", []) if p.get("occupied")},
        "hand": [{"id": c.get("card_id"), "upgraded": c.get("upgraded"),
                  "values": {d["name"]: {"base": d.get("base_value"), "current": d.get("current_value")}
                             for d in c.get("dynamic_values", [])}} for c in hand],
        "enemies": [{"id": e.get("enemy_id"), "hp": e.get("current_hp"), "block": e.get("block"),
                     "powers": powers(e.get("powers")), "intents": e.get("intents"), "move": e.get("move_id")}
                    for e in combat.get("enemies", [])],
    }


states = {}
decisions = []
verification = []
for directory in [HERE / "evidence"]:
    manifests = json.loads((directory / "evidence-manifest.json").read_text())
    for manifest in manifests:
        path = directory / (manifest["stream"] + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        with path.open("rb") as rows, (Path("/home/dw/Projects/agent-sts2/logs") / (manifest["stream"] + ".jsonl")).open("rb") as original:
            for encoded in rows:
                digest.update(encoded)
                item = json.loads(encoded)
                original.seek(item["offset"])
                raw = original.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                parsed = json.loads(raw)
                assert parsed == item["row"]
                assert extract.run_identity(parsed) == item["run_id"]
                assert item["offset"] + item["bytes"] <= manifest["source_size"]
                counts[item["run_id"]] += 1
                if manifest["stream"] == "states":
                    assert str((parsed.get("state", {}).get("run") or {}).get("character_id")).lower() == "silent"
                    assert item["line"] not in states
                    states[item["line"]] = project(item)
                elif manifest["stream"] == "decisions":
                    decisions.append({"line": item["line"], "run_id": item["run_id"], "ts": parsed.get("ts"),
                                      "floor": parsed.get("floor"), "turn": parsed.get("turn"),
                                      "chosen": parsed.get("chosen"), "label": parsed.get("label"),
                                      "sl_attempt": parsed.get("sl_attempt"), "result": parsed.get("result")})
        assert digest.hexdigest() == manifest["output_sha256"]
        assert all(counts[r] == n for r, n in manifest["counts"].items())
        verification.append({"directory": directory.name, **manifest, "verified_rows": sum(counts.values()), "verified": True})

save("evidence-verification.json", verification)
save("state-index.json", states)
save("decision-index.json", decisions)
groups = defaultdict(list)
for x in sorted(states.values(), key=lambda x: x["line"]):
    groups[x["run_id"]].append(x)

cunning = []
for run, rows in groups.items():
    for before, after in zip(rows, rows[1:]):
        if not (before["in_combat"] and after["in_combat"] and
                (before["floor"], before["turn"]) == (after["floor"], after["turn"])):
            continue
        consumed = [slot for slot, id_ in before["potions"].items()
                    if id_ == "CUNNING_POTION" and after["potions"].get(slot) != id_]
        if not consumed:
            continue
        nearby = [d for d in decisions if d["run_id"] == run and before["ts"] <= d["ts"] <= after["ts"]
                  and (d["chosen"] or {}).get("action") == "use_potion"]
        new = len(after["hand"]) - len(before["hand"])
        shivs = lambda x: sum(c["id"] == "SHIV" for c in x["hand"])
        cunning.append({"run": run, "floor": before["floor"], "turn": before["turn"],
                        "before": before["line"], "after": after["line"], "consumed_slots": consumed,
                        "hand_before": len(before["hand"]), "hand_after": len(after["hand"]),
                        "added": new, "shivs_added": shivs(after) - shivs(before),
                        "upgraded_shivs_after": all(c["upgraded"] for c in after["hand"] if c["id"] == "SHIV"),
                        "hp_unchanged": before["hp"] == after["hp"], "energy_unchanged": before["energy"] == after["energy"],
                        "decision_lines": [d["line"] for d in nearby]})
save("cunning-observations.json", cunning)

ken_drinks = [d for d in decisions if d["run_id"] == "KEN58SH9SLZ6" and (d["chosen"] or {}).get("action") == "use_potion"]
save("ken-drinks.json", ken_drinks)
ken_rooms = {}
for x in groups["KEN58SH9SLZ6"]:
    if x["in_combat"]:
        record = ken_rooms.setdefault(x["floor"], {"first": x, "last": x})
        record["last"] = x
save("ken-combat-rooms.json", ken_rooms)

# Preserve all cited windows, including nearby frames that can contradict a short quotation.
ranges = [(281312, 281313), (281338, 281339), (281367, 281368), (281399, 281400),
          (281563, 281566), (282070, 282090), (282139, 282160), (282276, 282297),
          (282328, 282367), (282804, 282809), (282887, 282892), (283146, 283148),
          (283388, 283405), (283414, 283425), (283499, 283515), (217009, 217010)]
windows = [x for n, x in sorted(states.items()) if any(a <= n <= b for a, b in ranges)]
save("cited-state-windows.json", windows)

assert len(ken_drinks) == 7
assert [(states[a]["hp"], states[b]["hp"]) for a,b in [(281312,281313), (281338,281339),
    (281367,281368), (281399,281400), (281565,281566)]] == [(70,66),(52,48),(62,58),(60,56),(4,0)]
assert states[281566]["cards_played"] == 0
assert states[281566]["enemies"][0]["hp"] == 111
assert [len(states[n]["hand"]) for n in [282292,282293,282294,282295,282296]] == [8,10,10,10,10]
assert [len(states[n]["hand"]) for n in [282352,282353,282354,282355,282356,282357]] == [5,8,8,10,10,10]
assert len(cunning) == 42
assert Counter(x["added"] for x in cunning) == Counter({3:37,2:2,0:3})
save("material-checks.json", {"purpose":"原始证据复算，非生产代码测试、未运行模拟或LLM", "ken_drinks":7,
    "txz_opening_pairs":5, "txz_f49_no_card_before_death":True, "cunning_drinks":len(cunning),
    "cunning_generation":dict(Counter(x["added"] for x in cunning)), "verified_rows":sum(x["verified_rows"] for x in verification)})
print(json.dumps({"verified_rows":sum(x["verified_rows"] for x in verification), "cunning":len(cunning), "ken_drinks":len(ken_drinks)},ensure_ascii=False))

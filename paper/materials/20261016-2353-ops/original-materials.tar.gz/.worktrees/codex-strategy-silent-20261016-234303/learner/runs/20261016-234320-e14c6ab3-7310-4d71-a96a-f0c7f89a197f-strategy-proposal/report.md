# 静默策略学习：十项处置报告

记录时间：2026-10-16T23:51:15+08:00；task=strategy-proposal；character=silent；batch=20261016-234303-strategy-proposal。

## 结果与身份

十项均waiting；现有材料能够确认局部机制、候选差额和实际端点，未填齐原提案的持续执行身份、组合生产校准或受控整战对照。没有新增可据实直接实现的数值缺口，不改预算、药价、SL阈值、启动权重或固定目标顺序。没有源码/知识提交、合入、版本或新增shipped。

开工工作树干净；普通批执行git merge --no-edit main，返回Already up to date。完整base=863ff95dc199e376abd171540887f83c610fe250，HEAD保持此提交。本批learn.json行已核task/character/worktree/runs/十proposal_ids；无research_request、implementation_request或proposal_repair。普通专题文件绑定另一旧批，不承接该专题、不读取另一请求替代身份。没有下级agent。

六个派发局全部由runs.jsonl核为SILENT/A10：VLZ6CCT8AQ0A, 8JRE1C4H4Z2W, CA5KE8GFJ9X2, 5PM6JAQG6FNQ, 61E2QS63Y9WU, DUZUBAJ3A8GP。独立局数6，SL尝试不扩分母；旧运行版本带dirty，Git提交不能复原完整当时运行树。未将旧deepseek_calls等计数当作引擎纯度判断，未以此报告新爬塔成绩。仅用本角色证据和本角色知识；19条关联原经验只用于追溯，不把其历史宽支持分母作为本批样本。

## 原始证据与固定事实

通过共用extract_evidence.py提取八流，保存逐流source_size和每行offset/bytes/SHA256/计数；另从原日志逐行回读验证，共6995行。身份依据显式run_id/state.run_id/run/fingerprint.run，不把正文提及当归属。提取全源states/decisions/brain各有2个无效JSON行，未据全源计数认定属于本六局。fight-plans零行仅说明冻结截点未选中，不断言历史缺失；本批未用零行初稿作结论。

| 流 | source_size字节 | 本六局行数 |
|---|---:|---:|
| states | 13702083103 | 3432 |
| decisions | 2084478640 | 3306 |
| sl-attempts | 44282117 | 29 |
| run-config | 1906230 | 6 |
| run-plans | 8692287 | 33 |
| brain | 703292085 | 183 |
| runs | 353455 | 6 |
| fight-plans | 2233957 | 0 |

37项固定材料断言通过（fact-checks.json），验证神化实费和牌面升级、痊愈药水能量/HP、蚌独立成长、负敏捷格挡与毒、胧光每实体HP/成长、甲虫临时减力恢复、SL同指纹差额及无毒冒泡零效果。这是材料核验，不是生产测试或撤源码负控。

## 消费者证据复用与边界

本批新提取八流封套与20261014-211320同六局产物逐SHA一致，源文件截点变大但这些所属行未新增。新生成六个消费者输入与旧输入的解码SHA/字节完全相同；四个消费模块selection-execution/observation/turn/terminal与旧基线及当前live源码一致，原六个输出的压缩与解码SHA已读回（consumer-reuse.json）。只复用已执行输出，没有重跑消费者、模型或模拟，不把旧测试归作本批生产检查。

原输出覆盖3301个有ID动作、476候选片段、859相邻动作观测端点、4终页端点、121整轮端点、413未知轮窗口。CA5第267143、61E第267517、DUZU第268789/268818/268864行缺decision_id，原完整输入拒收与仅有ID子集边界保持；原行仍在本批证据。所有actual_full_candidate_result=null是工具认证边界，不证明没有执行或候选必然失败。

8JRE F33首/第三试T2同指纹，原死亡预测0/24和5/24不同、未来损血均封顶47；观测整轮分别损3/15、敌净扣10/17，仍缺未选整战胜线。5PM无毒冒泡的零效果不是统一启动收益函数。61E幻象余2血仍攻击，47总净扣不是本体47伤或全员退场。DUZU前三次预测截断与末次实死分列。

## 当前源码和实际live祖先

只读live快照=5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922。16个精确源码路径中13个base/live相同，3个差异为既有Roy/Dai署名文字，差异patch保存在本目录；物理live叶与该live提交逐SHA核对。相同局部叶不能证明全部dirty知识或运行输入冻结。本批不修改live。

已核窄提交如下，均为实际live祖先；它们不是本批提交，不关闭整项：

- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：ops: replay checked Silent Apotheosis candidate facts，live祖先=True。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：Propagate observed Silent Apotheosis Malaise upgrade，live祖先=True。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：Replay tested held-loss candidate facts on current live，live祖先=True。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：Integrate repaired legacy learning deltas and bounded continuation adapter，live祖先=True。
- cf72bd21148059f111f760cc98a727369e34a47e：Integrate checked offline Silent potion observation tool，live祖先=True。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：Propagate observed Silent Deadly Poison upgrade，live祖先=True。

当前silent-apotheosis-reference仍将actual_cast_this_fight留null；turn-solver对重放、自动出牌和未验证属性组合保留unknown；silent-selection-audit记预测阶段和pending_dispatch，actual_turn留null。已实现的致命毒药5→7升级不能当成本批新增实现，持续身份与未覆盖交互仍缺。

## 逐项处置

| 原id | 结果 | 缺数据或未完成验证 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 已核普通神化及已见升级的窄模型；缺跨抽牌、选牌、用药、重问、SL和换战的实际施放持续身份，以及未覆盖属性组合的生产校准，不能关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性与样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化宽项仍缺实际施放持续身份和跨中断验证；已有窄源码不能证明该经验来源链全部完成，不登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息资源接续；局部端点不能关闭复合项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 现有三阶段审计只保存预测；缺跨抽牌、选牌、生成、药水、SL及重问的完整候选持续归属和成长兑现关联；未选线缺受控整战后继。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部无毒空打不足制定构筑或启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP、构筑、完整抽序的SL整战配对及另一条已核完整后继；首试胜利与毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码与T4端点不足认证目标顺序整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。 |

每项证据局号/层/回合、原账本、来源、反例、现状/预期、验证、影响与回退详见proposal.md。十个原Markdown已逐SHA核验并原字节保存，未新建重复CLI id；code_proposals为本批十个原id，implementation_domains=[]。

## 记录和检查口径

只经根learner/ledger.py update追加本角色原条目的proposal/report链接和核验说明，by=learner:strategy-proposal；尚为proposed的条目继续proposed，既有shipped/版本/首证/claim/prior/evidence保持，未重复追加旧证据或登记新shipped。输入、CLI输出和追加后读回另存本目录；队列由最终proposal_results交原调度器，不手改learn.json或原队列。

无源码修改，因此撤源码失败/恢复通过不适用；tests固定为tsc=null、vitest=null、cases=null，没有将材料断言写成生产测试成功。无提交或live合入，merged=null；不制造eval版本、decision-log上线记录或规则双通知。未运行play、不联网、不读游戏二进制或凭据、不改运维prompt、不推送。

读取/分析失败保留：source查询使用不存在的agent/src/sim/rollout*.ts时rg退出2，改查实际reflex路径；初次把ledger.fold返回dict误解包为二元组产生ValueError，随后按CLI源码读取语义，仅折叠相关26个本角色id，未改账本。这些不是生产测试失败或新游戏反例。

未填齐的主要限制是旧dirty输入、缺完整随机池/抽序及未选线受控后继、同局/同尝试相关性、完整候选认证边界和未观察属性组合。保留未知，不把局部源码、报告或排队当作整项学习完成、实际入库或大脑采用。未关闭其他父要求。

交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-234303/learner/runs/20261016-234320-e14c6ab3-7310-4d71-a96a-f0c7f89a197f-strategy-proposal/proposal.md。
完整报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-234303/learner/runs/20261016-234320-e14c6ab3-7310-4d71-a96a-f0c7f89a197f-strategy-proposal/report.md。

最终读回（2026-10-16T23:52:53+08:00）：26条CLI追加均已核实际物理行offset/bytes/SHA与输入相同；私有折叠确认原claim/status/version/shipped_at/evidence/first_run/asc/prior及旧notes/history/where前缀保留。十派发id全部在proposal_results中，HEAD仍等于完整base，工作树/index和tracked diff为空。交付提案/报告/JSON/CLI输入的gitleaks扫描退出0、无泄漏；未提交或合入。

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261016-234303-strategy-proposal'
queue = json.loads((OUT / 'queue-input.json').read_text())['fold']
source = json.loads((OUT / 'source-verification.json').read_text())
dispatch = json.loads((OUT / 'dispatch-identity.json').read_text())
stamp = (OUT / 'record-time.txt').read_text().strip()

details = [
    ('89354805ee4d7e77', '神化同线及后续升级', 'VLZ6CCT8AQ0A F35 T1、F43 T1—T5、F45 T1',
     'F35实能量7→5，防御5→8、打击7→10、匕首雨每段5→7、必备工具1费→0；F43后抽毒雾升级。F45持有但未施放。',
     '已核普通神化及已见升级的窄模型；缺跨抽牌、选牌、用药、重问、SL和换战的实际施放持续身份，以及未覆盖属性组合的生产校准，不能关闭整项。',
     '按实际已施放状态续接已知升级，未知组合继续标未知；不得给持有神化固定收益。',
     '冻结逐步动作、卡牌身份和战斗身份，在抽牌/选牌/用药/SL/换战边界核施放状态；固定生产调用逐源比较升级数值。'),
    ('f2bfceddb1898dca', '三骑士预算与击杀时钟', 'VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5',
     'F45首题随机药MC 707ms、1/12样本，rollout horizon1/samples1/best=null；药后能量1→2、HP67不变。T5为32血20挡对59，完整需损39。',
     '缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性与样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。',
     '保留现有预算、留药和目标规则，参考中区分退化、并列及未完成推演。',
     '同冻结输入/随机池/总预算对照MC先行和分阶段预算，记录未知覆盖、样本曲线及完整后继；不能拿单题用时拟常量。'),
    ('283a164780d11e69', '神化经验来源补链', 'VLZ6CCT8AQ0A F35 T1、F43 T1—T5、F45 T1',
     '与89354805同源观察，额外关联经验silent-apotheosis-combat-upgrades；两条来源不增加独立局数。',
     '同源神化宽项仍缺实际施放持续身份和跨中断验证；已有窄源码不能证明该经验来源链全部完成，不登记duplicate。',
     '沿原神化实现链共用固定证据，保留独立experience/source_task链接，不重复实现已支持数值。',
     '除神化数值固定调用外，核对原经验、账本、持续身份和消费者读回；完整覆盖后才能按实际live祖先提交处置。'),
    ('ebbfe3b97548756d', '十五项攻防、毒与持续资源', 'VLZ6CCT8AQ0A F43 T1—T5、F45 T3—T5及战斗/休息资源链',
     'F43升级勒紧6/尖啸8，F45普通步法2和口红1分源；末轮覆甲0，四攻击段经减力后合59，32血20挡不足。',
     '缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息资源接续；局部端点不能关闭复合项。',
     '分列当前属性、升级、逐击减力、毒结算、覆甲和真实回复，不将单轮效果预支成整场收益。',
     '按原十五条经验分别固定输入和实际生产调用，检查状态期限、资源接续及各自分母；任何窄缺口均需红绿和角色隔离。'),
    ('e5b87be50f28f311', 'HP护栏、SL换线与实际成长归属', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11及F17 T6',
     '首/第三试T2同指纹：死亡预测0/24与5/24，未来损血均封顶47；实际整轮损3/15、敌净扣10/17。原270264护栏仅在rationale，不因结构字段空认作无护栏。',
     '现有三阶段审计只保存预测；缺跨抽牌、选牌、生成、药水、SL及重问的完整候选持续归属和成长兑现关联；未选线缺受控整战后继。',
     '保留原护栏与SL血价，将原答、护栏后、SL后、实际派发及重问分列；不将候选差值自动记作实收益。',
     '用原decision_id、观察时间和指纹回连状态，逐边界结束或续接候选身份，实际能力建立另账；另一整战线路需独立验证。'),
    ('49632bc4878fb597', '逐击属性、虚弱与蚌成长', 'CA5KE8GFJ9X2 F13 T1—T5',
     '蚌力量0→4→8，同招意图11→15→19；虚弱端点11/14仍继续成长。当前这局没有正敏捷实测。',
     '缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。',
     '维持现有权重，属性修正和独立成长分项验证，不把虚弱当作取消成长。',
     '按当前进阶冻结敌人数据、完整手牌与能力输入，对四路径逐步比较；其他静默证据须另核身份和条件，不能补未观察值。'),
    ('66532328a585941f', '组件持有、计划与实际建立', '5PM6JAQG6FNQ F33及F39末试T2',
     '末试无毒失落之物35血前后不变，冒泡能量5→4、毒仍0；F33组件已建立并赢，但敌人/资源也不同。',
     '缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部无毒空打不足制定构筑或启动权重。',
     '保持持有/计划/已建立分账，不由局部零效果规定统一启动顺序或构筑加分。',
     '同起点完整抽序下比较启动顺序，核实际能力建立与整战资源/胜负；本局已用于发现，未来独立局作后移验证。'),
    ('43a76a31ba7bdcfa', '族母吸取、负敏捷、毒与SL边界', '61E2QS63Y9WU F17 T5—T7',
     'T6玩家敏捷−2，两防御各3，敌本体67→34的毒端点可核；本场首试获胜。',
     '缺A10同起始HP、构筑、完整抽序的SL整战配对及另一条已核完整后继；首试胜利与毒端点不足改变SL范围或阈值。',
     '冻结吸取/负敏捷/毒分项事实，保留SL范围和阈值。',
     '逐步比较毒、挡、玩家血与本体血，同盘完整SL路线需可追溯抽序和后继；首试胜利不能代反事实。'),
    ('5264153a4a4b0e5c', '胧光召唤、航行与目标进度', '61E2QS63Y9WU F23 T1—T6，重点T4',
     '两敌航行后力量3→6，T4本体/幻象血76/14→41/2，玩家25→10；幻象2血仍攻击，候选总47净扣不等全员退场。',
     '缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码与T4端点不足认证目标顺序整战收益。',
     '保留所有目标选项，同推演值并列；按各实体当前血/力量/意图区分伤害与击杀。',
     '固定全战输入核召唤、航行、退场与复现；另一目标线必须有完整后继，不能由未实打39伤零损候选推胜率。'),
    ('bddfa690a84e03d0', '熟睡甲虫唤醒、临时减力与成长', 'DUZUBAJ3A8GP F30各尝试T1—T6',
     '已核甲虫力量2→−4→4及意图20→14→22；前三次为predicted_death截断、末试实际died。四个相关失败不是四个独立局。',
     '缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。',
     '按当前进阶、睡眠/眩晕/成长分项处理，维持原终局排序与血价。',
     '冻结全链状态及当前进阶敌人数据，逐步校准醒来和眩晕后成长；同抽换序需完整后继，不能用预测截断冒实际死亡。'),
]

results = []
parts = [f'# 本批十项策略提案核验\n\n记录时间：{stamp}。角色silent，已核范围A10；batch={BATCH}。授权Roy-2026-10-07-learning只提供修改权限，不提供游戏事实。\n\n本批没有新增可实施数值缺口或足以改策略的受控证据，十项均waiting。既有窄实现不重复提交。\n']
for suffix, title, location, evidence, reason, behavior, validation in details:
    id = 'silent-proposal-' + suffix
    original = queue[id]
    results.append({'id': id, 'state': 'waiting', 'reason': reason})
    parts.append(f'## {id}：{title}\n\n原提案：{original["proposal"]}；原SHA256：{original["proposal_sha256"]}。\n来源任务：{original["source_task"]}；实现任务：strategy-proposal / {BATCH}。\n既有账本：{", ".join(original["ledger"])}。\n\n证据局/层/回合：{location}。{evidence}\n\n旧规则及当前覆盖：见source-verification.json和原提案；本批不改已有生产行为。预期行为：{behavior}\n\n处置：waiting。{reason}\n\n反例与限制：上述不同敌人、资源和不同尝试不可作为同盘受控胜负；已施放而损血/死亡、未选线的局部预测、同局SL均不能证明新策略整场收益。各原提案具体反例保存在original-proposals/，不删改。\n\n验证方法：{validation} 不调用LLM或网络，不以刷新知识JSON作固定输入。原六局为发现/回归集，不能称盲测，不拟新常量；未来同角色独立完局须按时间后置并按进阶和条件分层。实际新增实现才做撤源码失败、恢复通过、原沙箱入口和无关角色等价检查。\n\n预期影响：让证据边界和剩余缺口可追溯；本批对各角色对局行为无影响。回退：本批无生产改动需回退；后续源码按实际提交回退，保留本提案和历史。\n')
(OUT / 'proposal.md').write_text('\n'.join(parts))
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
raw_check = json.loads((OUT / 'raw-readback-verification.json').read_text())
reuse = json.loads((OUT / 'consumer-reuse.json').read_text())
checks = json.loads((OUT / 'fact-checks.json').read_text())
assert raw_check['verified'] and all(x['passed'] for x in checks) and reuse['all_inputs_and_sources_match']
rows = '\n'.join(f'| {m["stream"]} | {m["source_size"]} | {sum(m["counts"].values())} |' for m in manifest)
table = '\n'.join(f'| {r["id"]} | waiting | {r["reason"]} |' for r in results)
source_table = '\n'.join(f'- {c["commit"]}：{c["subject"]}，live祖先={c["is_live_ancestor"]}。' for c in source['narrow_commits'])
report = f'''# 静默策略学习：十项处置报告

记录时间：{stamp}；task=strategy-proposal；character=silent；batch={BATCH}。

## 结果与身份

十项均waiting；现有材料能够确认局部机制、候选差额和实际端点，未填齐原提案的持续执行身份、组合生产校准或受控整战对照。没有新增可据实直接实现的数值缺口，不改预算、药价、SL阈值、启动权重或固定目标顺序。没有源码/知识提交、合入、版本或新增shipped。

开工工作树干净；普通批执行git merge --no-edit main，返回Already up to date。完整base={source['base']}，HEAD保持此提交。本批learn.json行已核task/character/worktree/runs/十proposal_ids；无research_request、implementation_request或proposal_repair。普通专题文件绑定另一旧批，不承接该专题、不读取另一请求替代身份。没有下级agent。

六个派发局全部由runs.jsonl核为SILENT/A10：{', '.join(dispatch['runs'])}。独立局数6，SL尝试不扩分母；旧运行版本带dirty，Git提交不能复原完整当时运行树。未将旧deepseek_calls等计数当作引擎纯度判断，未以此报告新爬塔成绩。仅用本角色证据和本角色知识；19条关联原经验只用于追溯，不把其历史宽支持分母作为本批样本。

## 原始证据与固定事实

通过共用extract_evidence.py提取八流，保存逐流source_size和每行offset/bytes/SHA256/计数；另从原日志逐行回读验证，共{raw_check['total_rows']}行。身份依据显式run_id/state.run_id/run/fingerprint.run，不把正文提及当归属。提取全源states/decisions/brain各有2个无效JSON行，未据全源计数认定属于本六局。fight-plans零行仅说明冻结截点未选中，不断言历史缺失；本批未用零行初稿作结论。

| 流 | source_size字节 | 本六局行数 |
|---|---:|---:|
{rows}

37项固定材料断言通过（fact-checks.json），验证神化实费和牌面升级、痊愈药水能量/HP、蚌独立成长、负敏捷格挡与毒、胧光每实体HP/成长、甲虫临时减力恢复、SL同指纹差额及无毒冒泡零效果。这是材料核验，不是生产测试或撤源码负控。

## 消费者证据复用与边界

本批新提取八流封套与20261014-211320同六局产物逐SHA一致，源文件截点变大但这些所属行未新增。新生成六个消费者输入与旧输入的解码SHA/字节完全相同；四个消费模块selection-execution/observation/turn/terminal与旧基线及当前live源码一致，原六个输出的压缩与解码SHA已读回（consumer-reuse.json）。只复用已执行输出，没有重跑消费者、模型或模拟，不把旧测试归作本批生产检查。

原输出覆盖3301个有ID动作、476候选片段、859相邻动作观测端点、4终页端点、121整轮端点、413未知轮窗口。CA5第267143、61E第267517、DUZU第268789/268818/268864行缺decision_id，原完整输入拒收与仅有ID子集边界保持；原行仍在本批证据。所有actual_full_candidate_result=null是工具认证边界，不证明没有执行或候选必然失败。

8JRE F33首/第三试T2同指纹，原死亡预测0/24和5/24不同、未来损血均封顶47；观测整轮分别损3/15、敌净扣10/17，仍缺未选整战胜线。5PM无毒冒泡的零效果不是统一启动收益函数。61E幻象余2血仍攻击，47总净扣不是本体47伤或全员退场。DUZU前三次预测截断与末次实死分列。

## 当前源码和实际live祖先

只读live快照={source['live']}。16个精确源码路径中13个base/live相同，3个差异为既有Roy/Dai署名文字，差异patch保存在本目录；物理live叶与该live提交逐SHA核对。相同局部叶不能证明全部dirty知识或运行输入冻结。本批不修改live。

已核窄提交如下，均为实际live祖先；它们不是本批提交，不关闭整项：

{source_table}

当前silent-apotheosis-reference仍将actual_cast_this_fight留null；turn-solver对重放、自动出牌和未验证属性组合保留unknown；silent-selection-audit记预测阶段和pending_dispatch，actual_turn留null。已实现的致命毒药5→7升级不能当成本批新增实现，持续身份与未覆盖交互仍缺。

## 逐项处置

| 原id | 结果 | 缺数据或未完成验证 |
|---|---|---|
{table}

每项证据局号/层/回合、原账本、来源、反例、现状/预期、验证、影响与回退详见proposal.md。十个原Markdown已逐SHA核验并原字节保存，未新建重复CLI id；code_proposals为本批十个原id，implementation_domains=[]。

## 记录和检查口径

只经根learner/ledger.py update追加本角色原条目的proposal/report链接和核验说明，by=learner:strategy-proposal；尚为proposed的条目继续proposed，既有shipped/版本/首证/claim/prior/evidence保持，未重复追加旧证据或登记新shipped。输入、CLI输出和追加后读回另存本目录；队列由最终proposal_results交原调度器，不手改learn.json或原队列。

无源码修改，因此撤源码失败/恢复通过不适用；tests固定为tsc=null、vitest=null、cases=null，没有将材料断言写成生产测试成功。无提交或live合入，merged=null；不制造eval版本、decision-log上线记录或规则双通知。未运行play、不联网、不读游戏二进制或凭据、不改运维prompt、不推送。

读取/分析失败保留：source查询使用不存在的agent/src/sim/rollout*.ts时rg退出2，改查实际reflex路径；初次把ledger.fold返回dict误解包为二元组产生ValueError，随后按CLI源码读取语义，仅折叠相关26个本角色id，未改账本。这些不是生产测试失败或新游戏反例。

未填齐的主要限制是旧dirty输入、缺完整随机池/抽序及未选线受控后继、同局/同尝试相关性、完整候选认证边界和未观察属性组合。保留未知，不把局部源码、报告或排队当作整项学习完成、实际入库或大脑采用。未关闭其他父要求。

交运维提案：{OUT / 'proposal.md'}。
完整报告：{OUT / 'report.md'}。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': list(queue), 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'proposal_results': len(results)}, ensure_ascii=False))

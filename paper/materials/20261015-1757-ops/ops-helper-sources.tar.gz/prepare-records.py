from pathlib import Path
import subprocess, json, hashlib, re, os, tarfile, importlib.util
root = Path.cwd(); r = root
p = r / 'ops/codex-ops/record-staging/20261015-1757'
pub = r / 'paper/materials/20261015-1757-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-174302-s2-strategy-proposal'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions'] == report['proposal_results']
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and all(x is None for x in report['tests'].values())
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
final = json.loads((s / 'completion-verification.json').read_text())
assert final['ledger_cli_updates_verified'] == 30 and final['worktree_clean'] and not final['source_changes'] and not final['protected_ledger_fields_in_own_updates']
ev = json.loads((s / 'evidence-verification.json').read_text()); win = json.loads((s / 'window-verification.json').read_text())
assert ev['verified_rows'] == 8274 and sum(x['verified_rows'] for x in ev['streams']) == 8274
assert ev['material_assertion_count'] + win['material_assertion_count'] == 57
assert all(x['actual'] == x['expected'] for x in ev['checks'] + win['checks'])
source = json.loads((s / 'source-provenance.json').read_text()); assert len(source['paths']) == 14
for x in source['paths']:
    a = git('show', report['base'] + ':' + x['path']); z = git('show', source['live_snapshot'] + ':' + x['path'])
    assert sha(a) == x['workspace_sha256'] and sha(z) == x['live_sha256']
    git('merge-base', '--is-ancestor', x['source_commit'], source['live_snapshot'])
    assert a == z or a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]; owned = []
for raw in (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 30
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); seen = set(old.splitlines())
added = b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); before = fold(old); after = fold(old + added)
assert set(before) == set(after)
for ident in before:
    for k in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']: assert before[ident].get(k) == after[ident].get(k), (ident, k)
receipt = {'batch': bid, 'original_report': report, 'native': native, 'canonical_no_change_gate': b['no_change_proposals'], 'source14_sha_and_live_ancestors_verified': True, 'source_historical_comment_differences_preserved': True, 'original_material_rows': 8274, 'original_material_assertions': 57, 'material_tests_reexecuted': False, 'owned_ledger_rows': 30, 'protected_fold_preserved': True, 'original_model_readback_gap': 'Learner could not read native metadata inside its original sandbox; ops now verified actual native Sol6.1/xhigh/input/lease without altering permissions.', 'original_failure_history': ['Repeated same-turn snapshots initially miscounted as independent starts; corrected grouping preserves original observations and first failure.', 'CLI returned 30 space-separated IDs on one line; first completion check miscounted output lines; original failure retained.', 'Read-only bwrap directory scan and missing source-path probes preserved; not classified as production defects.'], 'no_source_merge_version_checks_or_game_action': True}
(pub / 'batch-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 350000 and f.suffix in ['.json', '.jsonl', '.md', '.py', '.txt', '.patch'] and f.name not in ['ledger-snapshot.json', 'state-windows.jsonl']]
files += list((s / 'original-proposals').glob('*.md'))
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1757原174302-s2策略rc0/done、10项waiting/no-source处置门禁核，149d干净WT/无提交、testsnull/mergednull/implementation_domains空，不重合/发号/补测或重复派单。六Silent A10锚点8274原行及37+20=57材料断言为原学习者结果读回，不重复跑或当生产测试；14叶旧livefe646265祖先/SHA核（12同/两历史注释差保持），原dirty知识/完整候选/受控后继/101分母与独立联合校准缺口保留，宽项不关闭。原学习者沙箱内未读到本次模型元数据如实保留，ops本轮补核真实native Sol6.1/xhigh、workspace-write/no-network、原input/lease，不改权限/模型/线程。30原CLI仅where/note，旧claim/首证/prior/evidence/status/version保护同验。窗口重复快照误当独立轮初、完成检查误把单行30ID当30行、只读bwrap/路径探针错误原件保留，修正材料检查不当产品修复。无新经验/源码/复盘，不刷新论文；原对局/账号/模型/额度队列prompt与P2/C2及宽父归属不动，不等待未来事件。证据paper/materials/20261015-1757-ops/。\n'
note = f'\n- {at} [ops 策略处置] 原174302-s2十项继续waiting，无源码/测试/合入/版本；30条原CLI仅补追溯，原材料检查失败与修正均归档，六锚点不当原101局完整分母。ops补核本次真实Sol6.1/xhigh与原隔离权限，未改变原报告或任何模型/对局。回执paper/materials/20261015-1757-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note}; (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in [p / 'prepare-records.py', p / 'seal-records.py', r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'batch': bid, 'waiting': 10, 'own_ledger_rows': 30, 'no_source_tests_merge_release_or_dataset': True, 'protected_fields_preserved': True, 'native_model_and_original_sandbox_verified': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}; values['paper/materials/learning/ledger.jsonl'] = old + added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; rows = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'waiting': 10, 'ledger_rows': 30, 'native_verified': True, 'ledger_check': 0, 'paths': len(rows)}))

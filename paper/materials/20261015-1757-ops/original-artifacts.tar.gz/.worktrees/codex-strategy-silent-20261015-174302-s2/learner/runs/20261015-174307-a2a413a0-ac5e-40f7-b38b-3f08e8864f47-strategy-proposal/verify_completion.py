import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
result = json.loads((OUT / "result.json").read_text())
dispatch = json.loads((OUT / "dispatch.json").read_text())
assigned = json.loads((OUT / "assigned-proposals.json").read_text())
assert result["code_proposals"] == dispatch["proposal_ids"]
assert [r["id"] for r in result["proposal_results"]] == dispatch["proposal_ids"]
assert all(r["state"] == "waiting" and r["reason"] for r in result["proposal_results"])
assert result["fixes"] == [] and result["merged"] is None
assert result["tests"] == {"tsc": None, "vitest": None, "cases": None}
assert Path(result["report"]).is_file() and Path(result["report"]).resolve().parent == OUT
for item in assigned:
    assert hashlib.sha256(Path(item["add"]["proposal"]).read_bytes()).hexdigest() == item["add"]["proposal_sha256"]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
status = subprocess.check_output(["git", "status", "--porcelain"], text=True)
assert head == result["base"] and not status
subprocess.run(["git", "diff", "--quiet"], check=True)
subprocess.run(["git", "diff", "--cached", "--quiet"], check=True)
updates = [json.loads(s) for s in (OUT / "ledger-updates.jsonl").open()]
assert len(updates) == 30 and all(set(u) == {"id", "by", "where", "note"} for u in updates)
physical = []
for line in Path("/home/dw/Projects/agent-sts2/paper/materials/learning/ledger.jsonl").open():
    row = json.loads(line)
    if row.get("by") == "learner:strategy-proposal" and row.get("note", "").startswith(result["batch"] + "："):
        physical.append(row)
assert len(physical) == 30
assert {r["id"] for r in physical} == {u["id"] for u in updates}
assert all(not set(r) & {"status", "claim", "evidence", "first_run", "prior", "version"} for r in physical)
assert set((OUT / "ledger-update.stdout.txt").read_text().split()) == {u["id"] for u in updates}
assert (OUT / "ledger-update.stderr.txt").stat().st_size == 0
assert all(r["exit_code"] == 0 for r in json.loads((OUT / "gitleaks-result.json").read_text()))
final = {"base": head, "worktree_clean": True, "source_changes": False,
         "proposal_result_count": 10, "ledger_cli_updates_verified": 30,
         "protected_ledger_fields_in_own_updates": False, "report_exists": True,
         "gitleaks_deliverables": 0, "tests": result["tests"]}
(OUT / "completion-verification.json").write_text(json.dumps(final, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(final, ensure_ascii=False))

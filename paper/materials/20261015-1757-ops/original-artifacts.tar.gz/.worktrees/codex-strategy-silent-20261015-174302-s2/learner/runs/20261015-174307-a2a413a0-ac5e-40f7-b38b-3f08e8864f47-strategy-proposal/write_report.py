import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / "dispatch.json").read_text())
assigned = json.loads((OUT / "assigned-proposals.json").read_text())
provenance = json.loads((OUT / "source-provenance.json").read_text())
manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
verified = json.loads((OUT / "evidence-verification.json").read_text())
windows = json.loads((OUT / "window-verification.json").read_text())
recorded_at = (OUT / "recorded-at.txt").read_text().strip()
batch = "20261015-174302-s2-strategy-proposal"

details = [
    {
        "location": "DUZUBAJ3A8GP / F27 / T4—T6；states 274830 起的冻结窗口",
        "observation": "T4火花3、污染0/3/6；T5火花6、污染0/6/12/18。按实际状态读取污染及当前敌人每段攻击，不能把污染血价独立于技能毒/挡收益比较。",
        "counterexample": "能力牌不按技能增加污染，技能也有毒/挡收益；本局没有另一完整打法的获胜实证。",
        "reason": "已核火花3→6及污染累积；缺原dirty运行实际消费的A10移动表快照、跨轮毒/挡/污染联合校准和未选线完整后继，未定位新的确定性模型差异。",
        "next": "取得原实际知识快照或来源明确的新A10同类连续观测，固定移动表、技能前缀、污染消失及毒/挡收益做逐步比对；出现可复现源码差异才实现。",
        "existing": "combat-plan当前帧vitalSpark读取；turn-solver污染逐击变换；rollout按观测移动效果增加vitalSpark。接线存在不等于原dirty整战已经校准。",
    },
    {
        "location": "5PM6JAQG6FNQ / F39 / T2、T4—T6",
        "observation": "两次抢夺后玩家力量由−2至−4；首试两步法回到0敏，失落毒死后力量回0，后续遗忘再次抢敏。",
        "counterexample": "末试只建立一步法仍为−2敏；毒杀失落后仍8HP/0挡面对遗忘19而死亡，不能由此规定固定击杀顺序。",
        "reason": "已核负属性及死亡前后变化；缺逐来源已夺累计量、归属和跨死亡/退场的完整模型输入，另一杀序完整后继未知，不能用现帧负属性公式冒称归还规则已闭合。",
        "next": "按来源保留累计抢夺及实体生命周期，冻结毒死、临时属性和再次抢夺前后输入；有完整来源归属及可复现差异后再改返还模型。",
        "existing": "当前属性读取及按移动应用减益路径仍在；没有将通用减益接线登记为整项返还实现。",
    },
    {
        "location": "CA5KE8GFJ9X2 / F13 / T1—T5；states 273237—273264",
        "observation": "T1/3/5轮初力量0/4/8、攻击11/15/19；轮初覆甲9/9/8/7/6。虚弱后的降低与后续力量增长分开。",
        "counterexample": "覆甲现场层数不足以隔离所有减层条件；实际10挡和2HP面对14仍死亡，不把单局损失当固定房间成本。",
        "reason": "已核加压与当前进阶攻击序列；缺原dirty运行实际消费的A10移动表和覆甲减层条件的独立冻结输入，未发现可新增的确定性当轮差异。",
        "next": "冻结同进阶移动表、完整前后状态及减层条件；怪物HP/攻击继续首样本读取，房间代价五样本门槛维持，不能因单局越过门槛。",
        "existing": "monster-db按进阶读取、move-model DamageContext与room-costs五样本门槛均已有，未重复实现。",
    },
    {
        "location": "5PM6JAQG6FNQ / F38 / T3—T4",
        "observation": "同一已观察23HP上限电击在T3/T4力量2/4、攻击17/19，高电压均2；T3仍实际贡献攻击，T4才退场。",
        "counterexample": "先杀爪牙的35伤/损3仅为候选，实际先打主怪线损30；不能宣称换序必保27HP或救后场。",
        "reason": "已核同一观察实体高电压增长；缺稳定实体/召唤代际和新同类连续出现的冻结输入，不能验证新实体不继承旧计数，替代杀序后继未知。",
        "next": "取得可区分旧体死亡、新体召出和新体首次行动的连续快照及移动表，验证模型初始化和逐体增长，不能由同类ID推持久身份。",
        "existing": "rollout的STRENGTH_GROWTH_POWERS含HIGH_VOLTAGE_POWER及逐体growth；通用growth不证明所有召唤代际已验证。",
    },
    {
        "location": "8JRE1C4H4Z2W / F33 / 首试与第三试T2、第二试T5、末试T11；兼原提案F17T6",
        "observation": "decisions270216/270282完整指纹相同。states276208→276212与276274→276278实损3/15、敌本体净扣10/17。末试T11四牌后22挡、5HP面对37，完整需损15。",
        "counterexample": "原答/替线五轮死亡为0/24与5/24，不能说同死率；后续均失败。护栏另有省当轮血的反例，候选省血不能直接算实际收益。",
        "reason": "同指纹血价与已有审计子项已核；缺跨抽弃牌/护栏/SL的整候选执行绑定、逐来源兑现及独立后继校准，原线完整胜负反事实未知。",
        "next": "按原选择→护栏→SL→派发→后续状态关联完整候选，显式终止重规划前候选的执行归属；后移独立A10局校准，不能拟全局血价系数。",
        "existing": "silent-selection-audit、silent-selection-dispatch、silent-hp-guard-audit与silent-sl-resource-comparison均有实际live祖先；派发回执仅覆盖单动作。",
    },
    {
        "location": "YF0LXT1QSTGG / F48 / 第二、第三试T1及271354；原提案F33成功SL反例",
        "observation": "decisions271309/271348完整指纹相同；states277327→277337与277366→277373实损0/9、敌本体净扣45/38。两候选均24/24死、预测后损封顶27。",
        "counterexample": "第六试恢复挡续步后T1零损仍失败；第四试T5弃牌后候选未完整执行；F33第二试确实获胜，不能否定全部SL。",
        "reason": "已核全败并列仍付实际血价；缺未执行续步与完整替代线的资源/胜负对照，以及同一候选跨重规划的执行归属，不能校准SL惩罚或禁止探索。",
        "next": "保留探索及原答，建立完整执行与实际状态绑定；后续独立局同时覆盖换线能赢反例，取得受控后继后再评价规则。",
        "existing": "silent-sl-resource-comparison明示current_turn_prediction/execution=unverified；选择和派发审计未把预测写成实付收益。",
    },
    {
        "location": "YF0LXT1QSTGG / F48 / 末试T3—T5；states277512—277528",
        "observation": "T3末4HP/4毒，T4新阶段212HP、旧毒/力清空；T5已建触媒2但零毒。先取得5敏建立23挡，第三小刀再加敏不倒补。",
        "counterexample": "前五试建立毒雾或余像仍失败；本局没有第三阶段或另一完整构筑胜线，不可把未启动毒当唯一死因。",
        "reason": "已核阶段重置及当前快照；缺下一轮增段、逐阶段/逐来源收益与完整候选执行的联合校准，现帧展示不能关闭候选条件传播的全部要求。",
        "next": "固定已持有/已建立/已施放/已结算/未执行的逐来源输入，验证跨阶段毒和临时属性清除及后续攻击变化；独立新局校准后再评价动作排序。",
        "existing": "silent-phase-current精确列当前快照且poison_damage_already_dealt=null；phase-reference及rollout阶段处理已有，未冒称完整收益传播。",
    },
    {
        "location": "XP2SL33HT0D9 / F33 / 首、第二试T3及首、末试T1",
        "observation": "decisions271992/272040同指纹，实损9/14、敌净扣24/27；271982/272195同指纹，实损2/10、敌净扣25/34。相关状态来源及偏移已保存。",
        "counterexample": "T1换线还建立手里剑力量；末试T2零损、T3保挡亦损4。六次均败且后续不同，不能由当轮代价推整战胜因。",
        "reason": "两组同盘血价已核；缺原线继续与换线的独立完整后继、受控随机池和整战结果，无法验证低当轮损失优先的新排序。",
        "next": "以本局仅作发现/固定回归，保留力量收益及抽牌、药瓶随机落点；有独立时间后移双蟹完整线对照后再比较窄排序，不设全局常数。",
        "existing": "B2有限样本门槛、五轮排名及替换血价记录均已有；不把零胜差或单动作完成称为安全/整战完成。",
    },
    {
        "location": "XP2SL33HT0D9 / F33 / 末试T2—T5；states278236—278254等冻结窗口",
        "observation": "T2轮初14挡，镣铐使爪0→−9力、攻击4→0，T3力恢复0；T4火箭背向57，转向38、弱后28，分列两种贡献。",
        "counterexample": "能力已经建立仍无减员并死亡；T2已有14不是每轮14，也不能把单次14当敏捷公式；本批未扩大到未派发的早期机制局。",
        "reason": "已核14挡、临时减力恢复及57→38→28；缺逐候选贡献拆分、完整执行绑定与条件联合校准，局部公式已有不能把整提案登记duplicate。",
        "next": "保持原优先级，按当前已有挡/本线新增挡、朝向/弱、临时减力/后轮恢复和已兑现/未结算分账；有确定缺字段或模型差异才新增源码。",
        "existing": "现帧属性、朝向、临时减力恢复与候选事实展示已有；只核本批A10来源，不搬其他角色或未派发进阶的证据。",
    },
    {
        "location": "YF0LXT1QSTGG F48 T1/T4/T5与XP2SL33HT0D9 F33 T1—T5；原提案101局历史为未复算范围",
        "observation": "本批复核前述三组SL血价、临时减力/恢复、阶段快照和14挡。原提案的机制、路线/休息/药水账与101局分母是不同范围。",
        "counterexample": "同存档六次不是六局；两局末次仍失败，XP还存在缺中间帧的原限制。无受控替线或留药完整胜局，不推固定避战/必休/留药血线。",
        "reason": "六派发锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准，综合要求继续waiting。",
        "next": "沿原来源清单冻结所需历史分母，逐子公式验证后单独结论；原路线/资源未知保留，后移新局区分自然结果与规则效果。",
        "existing": "原子事实和审计模块的真实live祖先已保存；不把局部模块相等、经验shipped或本批报告完成转换成宽提案已实现。",
    },
]
assert len(details) == len(assigned) == 10
results = []
body = ["# 本批十项静默策略提案复核", "", f"记录时间：{recorded_at}",
        f"批次：{batch}；角色：silent；来源：普通专用队列消费，reason=proposal。",
        f"源码基线：`{provenance['base']}`；`git merge --no-edit main` 返回 Already up to date。",
        "未绑定research_request/implementation_request；普通专题请求属于另一旧批，本批不读取其研究正文、不改请求或扩展选题。", "",
        "本批结论：10项均waiting。没有新的确定性源码差异或足以变更动作规则的独立校准证据；已有局部实现继续使用。", ""]
for item, detail in zip(assigned, details):
    original = item["add"]
    pid = item["id"]
    results.append({"id": pid, "state": "waiting", "reason": detail["reason"]})
    body += [f"## {pid}", "", f"原文：{original['proposal']}",
             f"原文SHA256：`{item['actual_markdown_sha256']}`，与保存指纹一致；当前队列状态waiting。",
             f"关联账本：{', '.join(original['ledger'])}。来源任务：{original['source_task']}；实现任务：strategy-proposal。",
             f"证据局号/层/回合：{detail['location']}。", f"本批核实：{detail['observation']}",
             f"反例与未知：{detail['counterexample']}", f"现有源码：{detail['existing']}",
             "旧规则/本批预期行为：保留现有候选、排名、出牌/药水/SL/终局规则；已有事实只按其声明范围使用。",
             f"待实现条件与验证：{detail['next']}",
             "拟合及时间切分：不拟合新系数；这六局A10已是发现/历史复核样本，SL尝试按同一run分组，不能冒称独立留出。后续新完局才可作时间后移验证。",
             f"处置：waiting。{detail['reason']}",
             "预期影响/回退：仅保存本次复核及缺数据条件，无策略收益主张；本批无生产修改可回退。未来实际源码变更须固定数据红绿、沙箱入口自测和实际live发布后再记录版本。", ""]
(OUT / "proposal.md").write_text("\n".join(body) + "\n")
(OUT / "proposal-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")

summary = {
    "task": "strategy-proposal", "character": "silent", "batch": batch,
    "base": provenance["base"], "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
    "tests": {"tsc": None, "vitest": None, "cases": None},
    "code_proposals": dispatch["proposal_ids"], "implementation_domains": [],
    "proposal_results": results, "report": str(OUT / "report.md"),
}
(OUT / "result.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
report = ["# 静默策略提案批次完成报告", "", f"记录时间：{recorded_at}",
          f"批次：{batch}；工作树：{OUT.parents[2]}。", f"基线：`{provenance['base']}`。", "",
          "## 结果", "", "已逐项处理10个派发ID，全部waiting；没有新增源码、知识、复盘、提案ID或提交。fixes=[]，merged=null。",
          "本批未进入live合入流程、未生成eval版本、未标implemented/duplicate/shipped。", "",
          "代码提案仅引用本批10个原CLI ID，不重复add；implementation_domains=[]表示本批没有实现变更。",
          "原始Markdown按原字节保存在original-proposals/，10份SHA均与专用队列保存值相同。",
          "身份来自根learn.json本批行，task/character/worktree/runs与派发说明一致，既无研究绑定也无实现请求。",
          "普通专题根请求绑定另一旧批，不适用本批；不扩展到fix-queue、整条队列或其他研究。", "",
          "## 冻结证据与范围", "",
          "runs.jsonl核实六局全部SILENT/A10且均失败；只研究这些派发锚点。没有把正文局号作为所属局，也没有使用其他角色知识。",
          "使用本树learner/extract_evidence.py共用入口提取八个流。每个流独立固定source_size，逐行保留line/offset/bytes/SHA256。",
          "随后回读原日志相应字节，逐条复核SHA、JSON、身份、范围和分局计数，并核输出文件SHA。",
          f"共复核{verified['verified_rows']}行；原始流扫描有states/decisions各2行、brain 1行无效JSON，未混入提取结果；所有流incomplete_lines=0。",
          "fight-plans在本次冻结字节截点选到0行，只描述该截点结果，不断言原始日志缺失；run-plans实际33行，按顶层run识别。", "",
          "| 流 | 本批行数 | 固定source_size（字节） |", "|---|---:|---:|"]
for entry in manifest:
    report.append(f"| {entry['stream']} | {sum(entry['counts'].values())} | {entry['source_size']} |")
report += ["", "完整清单：evidence/evidence-manifest.json；原行核验：evidence-verification.json；关键窗口：state-windows.jsonl、window-verification.json；选择原文：decision-anchors.json。", "",
           "## 同盘实付观察", "", "完整指纹相同只控制了本次起点；下表终点为实际下一轮轮初，不是另一线长期反事实。", "",
           "| 局/层/回合 | 原线/替线决策行 | 实际损HP | 敌本体净扣HP |", "|---|---|---|---|"]
for a, b in zip(windows["paired_actual_turns"][::2], windows["paired_actual_turns"][1::2]):
    report.append(f"| {a['run_id']}/F{a['floor']}/T{a['turn']} | {a['decision_line']}/{b['decision_line']} | {a['hp_loss']}/{b['hp_loss']} | {a['enemy_net_hp_removed']}/{b['enemy_net_hp_removed']} |")
report += ["", "这四组支持换线存在当轮血价；不支持统一惩罚系数、禁止探索、固定先铺能力或确定另一线整战获胜。后续抽牌、弃牌、药水落点、护栏和SL仍可能变化。", "",
           "## 已有源码与发布范围", "",
           f"只读live快照：`{provenance['live_snapshot']}`。14个相关源码叶的来源提交均是该live真实祖先；12叶SHA相等，另2叶只有Roy/Dai历史注释差异，原差异保留在source-vs-live.patch。",
           "不将当前live或当前知识文件冒称六局dirty运行的实际源码/知识快照。原run-config中的dirty知识差异使当时实际消费的移动表仍不能完整复原。", "",
           "| 已有子项 | 实际live祖先源码提交 | 范围 |", "|---|---|---|"]
for path, scope in [
    ("silent-sl-resource-comparison.ts", "当轮模型资源比较，execution=unverified"),
    ("silent-hp-guard-audit.ts", "护栏前后预测，actual_outcome=null"),
    ("silent-selection-audit.ts", "原答/SL前后候选及requested_action，pending_dispatch"),
    ("silent-selection-dispatch.ts", "单动作回执，whole_plan_executed=null"),
    ("silent-phase-current.ts", "当前已建能力/持有组件/毒的快照，已兑现毒伤未知"),
    ("silent-phase-reference.ts", "已列阶段结束线的当轮参考")
]:
    entry = next(p for p in provenance["paths"] if p["path"].endswith("/" + path))
    report.append(f"| {path} | `{entry['source_commit']}` | {scope} |")
report += ["", "上述仅证明已有子项和实际部署祖先，不是本批提交或整提案duplicate。怪物同进阶事实首样本读取路径和房间代价n≥5门槛保持；本批未从自己的游戏知识补规则。", "",
           "## 逐项处置", ""]
for item, detail in zip(assigned, details):
    report += [f"- {item['id']}：waiting。{detail['reason']} 证据：{detail['location']}；账本：{', '.join(item['add']['ledger'])}。"]
report += ["", "每项原规则/期望行为、反例、验证输入、时间切分、缺数据和回退均在proposal.md对应ID节。", "",
           "## 验证、记录与限制", "",
           f"材料核验断言{verified['material_assertion_count']}+{windows['material_assertion_count']}={verified['material_assertion_count'] + windows['material_assertion_count']}项通过，均为原日志字节/数值核验，不是tsc/vitest或生产源码红绿测试。",
           "没有生产源码变更，未跑tsc/vitest、未撤源码、未声称红绿或测试成功；tests固定为三个null。",
           "第一次窗口核验因同回合存在多个cards_played=0观测，将重复快照误当多次独立轮初而断言失败；原windows.stderr.txt和stdout保留。改为按(回合,数值)核所有一致取值，windows-v2.*成功，未删除原观测。",
           "一次只读命令遇到宿主bubblewrap目录扫描错误，重试读取成功；另有探索源码路径不存在的只读错误，随后rg --files定位真实路径。未归类为生产缺陷。",
           "账本只通过根learner/ledger.py update追加本批proposal/report链接及复核说明；保留旧claim、所有历史证据、first_run、prior、status、version，不把经验shipped回退proposed，也不标本批shipped。",
           "全部root请求、原提案正文、队列历史、经验库、ops prompt、live对局及其他角色行为未修改。未运行play、LLM、网络或新模拟。",
           "本环境未取得可读的本次原生会话模型/effort元数据；没有改模型配置或声称已验证运行模型。历史对局brain配置只作来源记录，不冒充本次会话核验。",
           "局限：本批只有六个相关A10历史局；没有独立新局留出、完整未执行线后继、原dirty实际知识快照、全部逐来源归属或原101局统计复算。报告完成不关闭宽提案/父要求，不称经验入库或消费者已采用新规则。", "",
           f"提案路径：{OUT / 'proposal.md'}", f"报告路径：{OUT / 'report.md'}", "",
           "机器回报另见result.json，账本CLI实际回执另见ledger-update.stdout.txt与ledger-update.stderr.txt。", ""]
(OUT / "report.md").write_text("\n".join(report))

links = {}
for item in assigned:
    for ledger_id in item["add"]["ledger"]:
        links.setdefault(ledger_id, []).append(item["id"])
with (OUT / "ledger-updates.jsonl").open("w") as handle:
    for ledger_id, ids in sorted(links.items()):
        row = {"id": ledger_id, "by": "learner:strategy-proposal",
               "where": {"proposal": [str(OUT / "proposal.md") + "#" + i for i in ids] + [str(OUT / "report.md")]},
               "note": f"{batch}：仅本批六Silent A10来源复核8274行及57项材料断言；关联原提案{','.join(ids)}均waiting。已有局部源码的真实live祖先见本批source-provenance.json，未将单动作/当前预测冒称完整执行或整项实现。无源码/规则/测试/发布；缺数据按本批proposal.md逐项保留，不改旧claim、证据、first_run、prior、status或version。"}
        handle.write(json.dumps(row, ensure_ascii=False) + "\n")
print(json.dumps({"report": str(OUT / "report.md"), "proposal": str(OUT / "proposal.md"), "proposal_count": len(results), "ledger_updates": len(links)}, ensure_ascii=False))

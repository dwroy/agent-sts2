import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
windows = [json.loads(line) for line in (OUT / "state-windows.jsonl").open()]
anchors = json.loads((OUT / "decision-anchors.json").read_text())
indexed = {a["line"]: a for a in anchors}
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({"label": name, "actual": actual, "expected": expected})


def matching(run, floor, turn=None):
    return [s for s in windows if s["run_id"] == run and s["floor"] == floor and
            (turn is None or s["turn"] == turn)]


def enemy(s, enemy_id):
    return next(e for e in s["enemies"] if e["id"] == enemy_id)


prism = []
for turn in [4, 5]:
    rows = matching("DUZUBAJ3A8GP", 27, turn)
    values = [(s["line"], s["played"], s["powers"].get("TAINTED_POWER", 0),
               enemy(s, "INFESTED_PRISM")["powers"].get("VITAL_SPARK_POWER", 0)) for s in rows]
    prism.append({"turn": turn, "values": values})
check("棱柱T4观测火花", sorted({v[3] for v in prism[0]["values"]}), [3])
check("棱柱T5观测火花", sorted({v[3] for v in prism[1]["values"]}), [6])
check("棱柱T4污染层数", sorted({v[2] for v in prism[0]["values"]}), [0, 3, 6])
check("棱柱T5污染层数", sorted({v[2] for v in prism[1]["values"]}), [0, 6, 12, 18])

clam = [s for s in matching("CA5KE8GFJ9X2", 13) if s["played"] == 0]
check("蚌奇数轮轮初力量", sorted({(s["turn"], enemy(s, "SEWER_CLAM")["powers"].get("STRENGTH_POWER", 0))
      for s in clam if s["turn"] in [1, 3, 5]}), [(1, 0), (3, 4), (5, 8)])
check("蚌奇数轮轮初攻击", sorted({(s["turn"], enemy(s, "SEWER_CLAM")["attack"])
      for s in clam if s["turn"] in [1, 3, 5]}), [(1, 11), (3, 15), (5, 19)])
check("蚌轮初覆甲", sorted({(s["turn"], enemy(s, "SEWER_CLAM")["powers"].get("PLATING_POWER", 0))
      for s in clam}), [(1, 9), (2, 9), (3, 8), (4, 7), (5, 6)])

zap = []
for s in matching("5PM6JAQG6FNQ", 38):
    if s["played"] != 0 or s["turn"] not in [3, 4]:
        continue
    z = enemy(s, "ZAPBOT")
    zap.append({"line": s["line"], "turn": s["turn"], "enemy": z})
check("电击T3/T4力量", sorted({(v["turn"], v["enemy"]["powers"].get("STRENGTH_POWER", 0)) for v in zap}), [(3, 2), (4, 4)])
check("电击T3/T4攻击", sorted({(v["turn"], v["enemy"]["attack"]) for v in zap}), [(3, 17), (4, 19)])
check("电击T3/T4高电压", sorted({(v["turn"], v["enemy"]["powers"].get("HIGH_VOLTAGE_POWER", 0)) for v in zap}), [(3, 2), (4, 2)])

possession = [s for s in matching("5PM6JAQG6FNQ", 39) if s["played"] == 0 and s["turn"] in [2, 4, 5, 6]]
check("抢夺T2负力量", sorted({s["powers"].get("STRENGTH_POWER", 0) for s in possession if s["turn"] == 2}), [-2])
check("抢夺T4负力量", sorted({s["powers"].get("STRENGTH_POWER", 0) for s in possession if s["turn"] == 4}), [-4])

paired = []
for decision_line in [270216, 270282, 271309, 271348, 271992, 272040, 271982, 272195]:
    a = indexed[decision_line]
    d = a["decision"]
    rows = matching(a["run_id"], d["floor"])
    start = next(s for s in rows if s["observed_ts"] == d["observed_ts"])
    end = next(s for s in rows if s["line"] > start["line"] and s["turn"] == d["turn"] + 1)
    paired.append({"decision_line": decision_line, "run_id": a["run_id"], "floor": d["floor"], "turn": d["turn"],
                   "attempt": d["sl_attempt"], "start_line": start["line"], "end_line": end["line"],
                   "hp_loss": start["hp"] - end["hp"],
                   "enemy_net_hp_removed": sum(e["hp"] for e in start["enemies"]) - sum(e["hp"] for e in end["enemies"]),
                   "note": "按当前观测至下一轮轮初净差；不推未执行替线的后续胜负。"})
check("沙虫同盘实损", [p["hp_loss"] for p in paired[:2]], [3, 15])
check("沙虫同盘本体净扣", [p["enemy_net_hp_removed"] for p in paired[:2]], [10, 17])
check("实验体同盘实损", [p["hp_loss"] for p in paired[2:4]], [0, 9])
check("实验体同盘本体净扣", [p["enemy_net_hp_removed"] for p in paired[2:4]], [45, 38])
check("双蟹T3同盘实损", [p["hp_loss"] for p in paired[4:6]], [9, 14])
check("双蟹T3同盘本体净扣", [p["enemy_net_hp_removed"] for p in paired[4:6]], [24, 27])
check("双蟹T1同盘实损", [p["hp_loss"] for p in paired[6:8]], [2, 10])
check("双蟹T1同盘本体净扣", [p["enemy_net_hp_removed"] for p in paired[6:8]], [25, 34])

result = {"prism": prism, "clam": clam, "zapbot": zap, "possession": possession, "paired_actual_turns": paired,
          "checks": checks, "material_assertion_count": len(checks), "production_tests_run": False}
(OUT / "window-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"material_assertion_count": len(checks), "paired_actual_turns": paired}, ensure_ascii=False))

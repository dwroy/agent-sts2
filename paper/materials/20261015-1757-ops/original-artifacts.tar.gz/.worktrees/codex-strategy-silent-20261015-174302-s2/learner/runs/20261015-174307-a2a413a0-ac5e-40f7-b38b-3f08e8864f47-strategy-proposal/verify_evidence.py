import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path


OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / "dispatch.json").read_text())
runs = set(dispatch["runs"])
manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
selected_floors = {
    "DUZUBAJ3A8GP": {27}, "5PM6JAQG6FNQ": {38, 39}, "CA5KE8GFJ9X2": {13},
    "8JRE1C4H4Z2W": {17, 33}, "YF0LXT1QSTGG": {33, 48}, "XP2SL33HT0D9": {33},
}
states = {}
decisions = {}
summaries = []
checks = []


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({"label": label, "actual": actual, "expected": expected})


def powers(holder):
    return {p["power_id"]: p["amount"] for p in holder.get("powers", [])}


def damage(enemy):
    return sum((i.get("damage") or 0) * (i.get("hits") or 1) for i in enemy.get("intents", []))


def compact(envelope):
    state = envelope["row"]["state"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": envelope["line"], "offset": envelope["offset"], "bytes": envelope["bytes"],
        "sha256": envelope["sha256"], "run_id": envelope["run_id"],
        "observed_ts": envelope["row"].get("observed_ts"), "floor": state["run"]["floor"],
        "turn": state.get("turn"), "hp": player.get("current_hp"), "block": player.get("block"),
        "played": player.get("cards_played_this_turn"), "powers": powers(player),
        "enemies": [{"index": e["index"], "id": e["enemy_id"], "hp": e["current_hp"],
                     "max_hp": e["max_hp"], "block": e["block"], "alive": e["is_alive"],
                     "move": e.get("move_id"), "attack": damage(e), "powers": powers(e)}
                    for e in combat.get("enemies", [])],
    }


with (OUT / "state-windows.jsonl").open("w") as windows:
    for entry in manifest:
        stream = entry["stream"]
        path = OUT / "evidence" / (stream + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        with Path("/home/dw/Projects/agent-sts2/logs", stream + ".jsonl").open("rb") as source:
            assert source.seek(0, 2) >= entry["source_size"]
            with path.open("rb") as evidence:
                for encoded in evidence:
                    digest.update(encoded)
                    envelope = json.loads(encoded)
                    run = envelope["run_id"]
                    assert run in runs and extractor.run_identity(envelope["row"]) == run
                    assert envelope["offset"] + envelope["bytes"] <= entry["source_size"]
                    source.seek(envelope["offset"])
                    raw = source.read(envelope["bytes"])
                    assert hashlib.sha256(raw).hexdigest() == envelope["sha256"]
                    assert json.loads(raw) == envelope["row"]
                    counts[run] += 1
                    if stream == "states":
                        state = envelope["row"]["state"]
                        assert state["run"]["character_id"].lower() == "silent"
                        assert state["run"]["ascension"] == 10
                        states[envelope["line"]] = envelope
                        if state["run"]["floor"] in selected_floors[run] and state.get("combat"):
                            windows.write(json.dumps(compact(envelope), ensure_ascii=False) + "\n")
                    elif stream == "decisions":
                        decisions[envelope["line"]] = envelope
                    elif stream in {"runs", "run-config"}:
                        assert envelope["row"]["character"].lower() == "silent"
        check(stream + " 输出指纹", digest.hexdigest(), entry["output_sha256"])
        check(stream + " 分局计数", {r: counts[r] for r in dispatch["runs"]}, entry["counts"])
        summaries.append({"stream": stream, "verified_rows": sum(counts.values()), "source_size": entry["source_size"]})


def state(line):
    return compact(states[line])


def enemy(line, enemy_id):
    return next(e for e in state(line)["enemies"] if e["id"] == enemy_id)


pairs = [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]
for a, b in pairs:
    check(f"决策 {a}/{b} 所属局", decisions[a]["run_id"], decisions[b]["run_id"])
    check(f"决策 {a}/{b} 完整指纹", decisions[a]["row"]["fingerprint"], decisions[b]["row"]["fingerprint"])

check("沙虫末试T11四牌后格挡", state(276433)["block"], 22)
check("沙虫末试T11实际HP", state(276433)["hp"], 5)
check("沙虫末试T11完整待承受损失", enemy(276433, "THE_INSATIABLE")["attack"] - state(276433)["block"], 15)
check("实验体第一阶段末毒", enemy(277512, "TEST_SUBJECT")["powers"]["POISON_POWER"], 4)
check("实验体换阶段HP", enemy(277513, "TEST_SUBJECT")["hp"], 212)
check("实验体换阶段毒", enemy(277513, "TEST_SUBJECT")["powers"].get("POISON_POWER", 0), 0)
check("实验体换阶段力量", enemy(277513, "TEST_SUBJECT")["powers"].get("STRENGTH_POWER", 0), 0)
check("双蟹末试T2轮初挡", state(278236)["block"], 14)
check("双蟹镣铐暂时力量", enemy(278237, "CRUSHER")["powers"]["STRENGTH_POWER"], -9)
check("双蟹镣铐后攻击", enemy(278237, "CRUSHER")["attack"], 0)
check("双蟹T3力量恢复", enemy(278242, "CRUSHER")["powers"].get("STRENGTH_POWER", 0), 0)
check("双蟹背向激光", enemy(278249, "ROCKET")["attack"], 57)
check("双蟹转向弱后激光", enemy(278254, "ROCKET")["attack"], 28)

anchor_lines = {x for pair in pairs for x in pair} | {270264, 271354, 271495, 271509, 272076}
anchors = []
for number in sorted(anchor_lines):
    envelope = decisions[number]
    row = envelope["row"]
    anchors.append({k: envelope[k] for k in ["source", "line", "offset", "bytes", "sha256", "run_id"]} | {
        "decision": {k: row.get(k) for k in ["ts", "observed_ts", "floor", "turn", "decision_id", "sl_attempt", "answers", "chosen", "result", "sl_explore", "sl_retry"]}
    })
(OUT / "decision-anchors.json").write_text(json.dumps(anchors, ensure_ascii=False, indent=2) + "\n")
result = {"verified_rows": sum(e["verified_rows"] for e in summaries), "streams": summaries,
          "checks": checks, "material_assertion_count": len(checks), "production_tests_run": False}
(OUT / "evidence-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_rows": result["verified_rows"], "material_assertion_count": len(checks), "streams": summaries}, ensure_ascii=False))

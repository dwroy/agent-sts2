import { checkCodex, codexEnv, sessionArgs } from '../../../../agent/src/brain/engines/codex.ts';
import { appServerRequest, usageArgs, readCodexUsage, CodexUsageGuard } from '../../../../agent/src/brain/engines/codex-usage.ts';
import { mkdirSync, writeFileSync, existsSync, realpathSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
const root=process.cwd(), out=resolve(root,'paper/materials/20261015-silent-codex1-next-run');
const state=resolve(root,'ops/codex-ops/record-staging/20261015-1213/preflight-state');
const target=resolve(root,'ops/codex-ops/accounts/codex1/brain'), previous='/home/dw/.codex-brain', bin='/home/dw/.local/node/bin/codex';
mkdirSync(state,{recursive:true});mkdirSync(out,{recursive:true});
const save=(name:string,v:unknown)=>writeFileSync(resolve(out,name),JSON.stringify(v,null,2)+'\n');
const env=(home:string)=>codexEnv(bin,home,{HOME:'/home/dw',PATH:'/home/dw/.local/node/bin:/usr/local/bin:/usr/bin:/bin',LANG:'C.UTF-8'});
let stage='metadata';
async function identity(home:string,label:string){
 const cwd=resolve(state,label);mkdirSync(cwd,{recursive:true});
 const reply=await appServerRequest(bin,usageArgs(cwd),{cwd,env:env(home),method:'account/read',params:{refreshToken:false},timeoutMs:20000}) as Record<string,unknown>;
 const a=reply.account as Record<string,unknown>|null;
 if(!a||a.type!=='chatgpt')throw new Error('account_identity_unavailable');
 const id=a.id??a.accountId??a.email;if(typeof id!=='string'||!id)throw new Error('account_identity_missing');
 return {method:'account/read',account_type:a.type,plan_type:a.planType??null,account_identity_sha256:createHash('sha256').update(id).digest('hex'),requires_openai_auth:reply.requiresOpenaiAuth??null};
}
try{
 if(readFileSync(resolve(root,'ops/codex-ops/brain-home'),'utf8').trim()!==previous)throw new Error('selector_changed_since_authorization');
 if(!existsSync(resolve(target,'auth.json')))throw new Error('target_auth_missing');
 for(const name of ['AGENTS.md','AGENTS.override.md'])if(existsSync(resolve(target,name)))throw new Error('target_instruction_file_present');
 const authTarget=realpathSync(resolve(target,'auth.json'));if(!authTarget.startsWith(resolve(root,'ops/codex-ops/accounts/codex1')+'/'))throw new Error('target_auth_link_outside_codex1');
 stage='model-isolation';const model=await checkCodex({bin,home:target},'gpt-6.1-sol','xhigh',{stateDir:resolve(state,'catalog')});if(!model.ok)throw new Error('model_or_isolation_failed');
 stage='identity';const oldAccount=await identity(previous,'current-account'), targetAccount=await identity(target,'target-account');
 const historical=JSON.parse(readFileSync(resolve(root,'paper/materials/20261014-silent-codex-account-recovery/account-preflight.json'),'utf8'));
 if(targetAccount.account_identity_sha256!==historical.old_account.account_identity_sha256 || targetAccount.account_identity_sha256===oldAccount.account_identity_sha256)throw new Error('codex1_identity_mismatch');
 stage='target-usage';const usage=await readCodexUsage({bin,home:target,env:env(target),stateDir:resolve(state,'target-usage')});
 stage='current-usage';const oldUsage=await readCodexUsage({bin,home:previous,env:env(previous),stateDir:resolve(state,'current-usage')});
 stage='existing-guard';const guard=new CodexUsageGuard({stopPct:100,everyCalls:3,everyMin:10,required:true},async()=>usage);const reason=await guard.start();let guardError:string|null=null;
 try{await guard.beforeCall();}catch(e){guardError=e instanceof Error?e.message:'existing_guard_blocked';}
 const args=sessionArgs({catalogFile:resolve(state,'catalog.json'),stateDir:state,effort:'xhigh',summary:'auto',serviceTier:'default'});
 const creditsAvailable=usage.credits?.hasCredits===true && (usage.credits.unlimited===true || (usage.credits.balance??0)>0);
 const record={at:new Date().toISOString(),target_home:target,previous_home:previous,old_account:oldAccount,target_account:targetAccount,distinct_account_verified:true,target_matches_original_codex1_identity:true,auth_link_metadata_target:authTarget,credentials_read_copied_or_logged:false,model:'gpt-6.1-sol',effort:'xhigh',service_tier:'default',model_check:model,no_home_AGENTS_files:true,production_session_isolation:{project_docs_disabled:args.includes('project_doc_max_bytes=0'),reasoning_xhigh:args.includes('model_reasoning_effort="xhigh"'),service_tier_default:args.includes('service_tier="default"')},usage,old_usage:oldUsage,positive_credit_balance:creditsAvailable,existing_guard:{passed:reason===null&&guardError===null,start_reason:reason,before_call_error:guardError},preflight_state:reason||guardError?'blocked_by_existing_no_credits_guard':'passed',no_model_turn_or_reset_credit_action:true,no_selector_process_ops_or_learner_changed:true};
 save('account-preflight.json',record);process.stdout.write(JSON.stringify({state:record.preflight_state,target_identity_verified:true,model_check:model,usage,old_usage:oldUsage,existing_guard:record.existing_guard})+'\n');
 if(!creditsAvailable)process.exitCode=2;
}catch(error){save('account-preflight-failure.json',{at:new Date().toISOString(),stage,error_class:error instanceof Error?error.name:'unknown',raw_error_or_credential_payload_not_archived:true,no_selector_or_process_changed:true});process.stdout.write('preflight_failed; see sanitized stage receipt\n');process.exitCode=1;}

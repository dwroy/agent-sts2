import {readFileSync,writeFileSync,existsSync,realpathSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {checkCodex,codexEnv,sessionArgs} from '../../../../agent/src/brain/engines/codex.ts';
import {readCodexUsage,CodexUsageGuard} from '../../../../agent/src/brain/engines/codex-usage.ts';
const root=process.cwd(),out=resolve(root,'paper/materials/20261015-silent-codex1-next-run'),state=resolve(root,'ops/codex-ops/record-staging/20261015-1213/preflight-state/usage-continuation');mkdirSync(state,{recursive:true});
const bin='/home/dw/.local/node/bin/codex',home=resolve(root,'ops/codex-ops/accounts/codex1/brain');
const id=JSON.parse(readFileSync(resolve(out,'target-rpc-diagnostic.json'),'utf8'));if(id.account_error || !id.account_answered || id.account.identity_sha256!=='68c5321817bf49b5a2e858b541b710066d179948bde150668e4e315cc438c4f8')throw new Error('target identity evidence missing');
let stage='model';
try{
 for(const name of ['AGENTS.md','AGENTS.override.md'])if(existsSync(resolve(home,name)))throw new Error('home instruction file present');
 const model=await checkCodex({bin,home},'gpt-6.1-sol','xhigh',{stateDir:resolve(state,'catalog')});if(!model.ok)throw new Error('model check failed');
 stage='usage';const usage=await readCodexUsage({bin,home,env:codexEnv(bin,home),stateDir:resolve(state,'quota'),timeoutMs:90000});
 stage='guard';const guard=new CodexUsageGuard({stopPct:100,everyCalls:3,everyMin:10,required:true},async()=>usage);const why=await guard.start();let failure=null;try{await guard.beforeCall();}catch(e){failure=e instanceof Error?e.message:'quota';}
 const args=sessionArgs({catalogFile:resolve(state,'catalog.json'),stateDir:state,effort:'xhigh',summary:'auto',serviceTier:'default'});
 const result={at:new Date().toISOString(),target_home:home,target_account:id.account,target_account_read_receipt:'paper/materials/20261015-silent-codex1-next-run/target-rpc-diagnostic.json',current_account:JSON.parse(readFileSync(resolve(out,'current-account-identity.json'),'utf8')),auth_link_metadata_target:realpathSync(resolve(home,'auth.json')),no_AGENTS_home:true,model:'gpt-6.1-sol',effort:'xhigh',service_tier:'default',model_check:model,explicit_session_args:{project_docs_disabled:args.includes('project_doc_max_bytes=0'),xhigh:args.includes('model_reasoning_effort="xhigh"'),default_tier:args.includes('service_tier="default"')},usage,existing_guard:{passed:why===null&&failure===null,start_reason:why,before_call_error:failure},credits_available:usage.credits?.hasCredits===true&&(usage.credits.unlimited||(usage.credits.balance??0)>0),no_model_turn_or_reset_credit_action:true,no_selector_process_ops_learner_or_regent_change:true};
 writeFileSync(resolve(out,'account-preflight.json'),JSON.stringify(result,null,2)+'\n');process.stdout.write(JSON.stringify(result)+'\n');
}catch(e){const result={at:new Date().toISOString(),stage,failure_category:e instanceof Error && /no answer within/.test(e.message)?'bounded_native_rpc_timeout':'sanitized_preflight_failure',no_selector_or_process_changed:true,no_account_unavailable_inference_from_timeout:true};writeFileSync(resolve(out,'usage-preflight-failure.json'),JSON.stringify(result,null,2)+'\n');process.stdout.write(JSON.stringify(result)+'\n');process.exitCode=1;}

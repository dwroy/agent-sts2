from pathlib import Path
import subprocess,json
r=Path.cwd();pub=r/'paper/materials/20261015-silent-codex1-next-run';d=json.loads((pub/'paid-publication-receipt.json').read_text());bid='20261015-051302-s2-strategy-proposal';log=r/'ops/codex-ops/learner'/f'{bid}.fallback-{d["actual_live_tree"]}.checks.log'
assert not (pub/'paid-host-request.json').exists() and not log.exists();assert subprocess.check_output(['git','-C',str(r/'.worktrees/live'),'rev-parse','HEAD'],text=True).strip()==d['actual_live']
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();command=['bash','ops/codex-ops-do.sh','learner-recheck',bid]
with (pub/'paid-host-request.log').open('wb') as handle:proc=subprocess.Popen(command,cwd=r,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
stat=Path(f'/proc/{proc.pid}/stat').read_text();receipt={'at':at,'original_host_channel_batch':bid,'new_feature_source':d['source'],'new_feature_release':d['release_id'],'command':command,'request_pid':proc.pid,'request_birth':stat[stat.rfind(')')+2:].split()[19],'expected_live':d['actual_live'],'expected_tree':d['actual_live_tree'],'expected_log':str(log),'stage':'request process actually launched; exact host result pending','requests_for_this_new_combination':1,'no_old_tree_pass_borrowed':True,'no_new_learner_or_model_dispatch':True,'game_restart':False}
(pub/'paid-host-request.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
code=proc.wait();(pub/'paid-host-client-exit.json').write_text(json.dumps({'request_pid':proc.pid,'actual_client_exit':code,'request_tree':d['actual_live_tree']},indent=2)+'\n');print(json.dumps({'actual_client_exit':code}),flush=True)
raise SystemExit(code)

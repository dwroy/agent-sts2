from pathlib import Path
import subprocess,json,os,hashlib,fcntl,re
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261015-1234-paid';pub=r/'paper/materials/20261015-silent-codex1-next-run';w=r/'.worktrees/silent-codex1-paid-20261015';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r,env=None,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],env=env,input=data,stderr=subprocess.PIPE)
def blob(head,path,cwd=r):
 q=subprocess.run(['git','-C',str(cwd),'show',head+':'+path],capture_output=True);assert q.returncode in [0,128],(path,q.returncode);return q.stdout if q.returncode==0 else None

def stage(path,value,env,cwd,mode='100644'):
 oid=git('hash-object','-w','--stdin',cwd=cwd,data=value).decode().strip();git('update-index','--add','--cacheinfo',mode,oid,path,env=env,cwd=cwd)
def commit(tree,parents,title,cwd):
 args=['commit-tree',tree]
 for parent in dict.fromkeys(parents):args+=['-p',parent]
 return git(*args,cwd=cwd,data=(title+'\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n').encode()).decode().strip()
def install(cwd,path,value,mode='100644'):
 f=cwd/path;f.parent.mkdir(parents=True,exist_ok=True);tmp=f.with_name(f.name+'.paid-credit-publish.tmp');assert not tmp.exists();tmp.write_bytes(value);tmp.chmod(0o755 if mode=='100755' else 0o644);os.replace(tmp,f)
s=json.loads((pub/'paid-source-publication.json').read_text());assert s['source_full']['tsc']==s['source_full']['vitest']==0;assert json.loads((p/'source-gitleaks.json').read_text())==[]
source=s['source'];base=s['parent'];paths=[x['path'] for x in s['paths']];assert len(paths)==8;assert git('rev-parse','HEAD',cwd=w).decode().strip()==source
assert not (pub/'paid-publication-receipt.json').exists()
with (r/'ops/live-merge.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
 heads={str(r):git('rev-parse','HEAD').decode().strip(),str(live):git('rev-parse','HEAD',cwd=live).decode().strip()};oldmain=heads[str(r)];oldlive=heads[str(live)];composed={};selected=[]
 for cwd in [r,live]:
  assert not git('diff','--cached','--name-only',cwd=cwd).strip() and not git('ls-files','-u',cwd=cwd).strip()
  values={}
  for row in s['paths']:
   path=row['path'];original=blob(base,path);current=blob(heads[str(cwd)],path,cwd);desired=blob(source,path);assert desired is not None and sha(desired)==row['sha256'];physical=cwd/path
   assert (physical.read_bytes() if physical.exists() else None)==current,('foreign uncommitted selected leaf',str(cwd),path)
   if current==original:result=desired
   elif current==desired:result=current
   elif original is None:
    assert current is None,('new selected path occupied',path);result=desired
   else:
    assert current is not None
    merge=p/'three-way'/cwd.name/path;merge.parent.mkdir(parents=True,exist_ok=True)
    currentfile=merge.with_suffix(merge.suffix+'.current');basefile=merge.with_suffix(merge.suffix+'.base');sourcefile=merge.with_suffix(merge.suffix+'.source')
    currentfile.write_bytes(current);basefile.write_bytes(original);sourcefile.write_bytes(desired)
    merged=subprocess.run(['git','merge-file','-p',str(currentfile),str(basefile),str(sourcefile)],capture_output=True)
    if merged.returncode and cwd==live and path=='agent/src/brain/engines/codex-usage.ts':
     # Preserve only the three verified historical Dai comment spellings, retaining the new Roy authorization.
     replacements=[(b"guard (Roy 2026-10-03)",b"guard (Dai 2026-10-03)"),(b"eats Roy's weekly Codex window (shared with Roy's own Codex use)",b"eats Dai's weekly Codex window (shared with Dai's own Codex use)"),(b"right after Roy's plan upgrade",b"right after Dai's plan upgrade")]
     normalized=current
     for oldtext,newtext in replacements:
      assert normalized.count(newtext)==1;normalized=normalized.replace(newtext,oldtext)
     assert normalized==original, 'historical exception must contain no executable difference'
     result=desired
     for oldtext,newtext in replacements:
      assert result.count(oldtext)==1;result=result.replace(oldtext,newtext)
    else:
     assert merged.returncode==0,('selected three-way conflict retained',str(cwd),path);result=merged.stdout
   entry=git('ls-tree',source,'--',path).decode().split();mode=entry[0];dest=p/'composed-scan'/cwd.name/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(result);values[path]=(result,mode)
   selected.append({'checkout':str(cwd),'path':path,'mode':mode,'source_sha256':sha(desired),'old_sha256':sha(current) if current is not None else None,'composed_sha256':sha(result),'source_bytes_equal':result==desired,'parallel_changes_preserved_by_three_way':current not in [original,desired]})
  composed[str(cwd)]=values
 # Preserve every existing parallel knowledge refresh before the new behavior commit.
 refresh=[]
 for path in git('diff','--name-only','HEAD','--','knowledge',cwd=live).decode().splitlines():
  data=(live/path).read_bytes();dest=p/'refresh-scan'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);refresh.append({'path':path,'sha256':sha(data)})
 envscan={**os.environ,'GOMAXPROCS':'2'}
 with (pub/'paid-composition-gitleaks.log').open('wb') as h:
  rc=subprocess.run(['nice','-n','19','gitleaks','dir',str(p/'composed-scan'),'--redact','--no-banner','--report-format','json','--report-path',str(p/'composition-gitleaks.json')],env=envscan,stdout=h,stderr=subprocess.STDOUT).returncode
 assert rc==0 and json.loads((p/'composition-gitleaks.json').read_text())==[]
 # Require generated code equality for the preserved historical-comment-only main/live differences.
 equal=[]
 for path in paths:
  mainbytes=composed[str(r)][path][0];livebytes=composed[str(live)][path][0]
  if mainbytes==livebytes:continue
  if path=='ops/run.sh':
   oldline=b'# Ablation (Dai 2026-09-27, A8):';newline=b'# Ablation (Roy 2026-09-27, A8):'
   assert livebytes.count(oldline)==1 and livebytes.replace(oldline,newline)==mainbytes, 'only the original named shell comment may differ'
   for cwd in [r,live]:subprocess.run(['bash','-n',str(p/'composed-scan'/cwd.name/path)],check=True)
   equal.append({'path':path,'normalized_shell_sha256':sha(mainbytes),'only_exact_historical_ablation_comment_differs':True});continue
  assert path.endswith('.ts'),('unexpected composition difference',path)
  code="const fs=require('fs');const esbuild=require(process.argv[1]);for(const p of process.argv.slice(2)){process.stdout.write(JSON.stringify(esbuild.transformSync(fs.readFileSync(p,'utf8'),{loader:'ts',format:'esm',target:'es2022',legalComments:'none'}).code)+'\\n')}"
  files=[p/'composed-scan'/cwd.name/path for cwd in [r,live]]
  generated=subprocess.check_output(['/home/dw/.local/node/bin/node','-e',code,str(r/'agent/node_modules/esbuild'),*[str(x) for x in files]],stderr=subprocess.PIPE).splitlines();assert len(generated)==2 and json.loads(generated[0])==json.loads(generated[1]),('main/live semantic difference needs explicit resolution',path)
  equal.append({'path':path,'generated_js_sha256':sha(json.loads(generated[0]).encode()),'historical_comment_difference_preserved':True})
 envlive={**os.environ,'GIT_INDEX_FILE':str(p/'live-publication.index')};git('read-tree',oldlive,cwd=live,env=envlive)
 for row in refresh:stage(row['path'],(p/'refresh-scan'/row['path']).read_bytes(),envlive,live)
 freshtree=git('write-tree',cwd=live,env=envlive).decode().strip();fresh=commit(freshtree,[oldlive],'Preserve parallel knowledge refresh before scoped credit admission',live) if refresh else oldlive
 for path,(value,mode) in composed[str(live)].items():stage(path,value,envlive,live,mode)
 behaviortree=git('write-tree',cwd=live,env=envlive).decode().strip();assert sorted(git('diff','--name-only',freshtree,behaviortree,cwd=live).decode().splitlines())==sorted(paths)
 behavior=commit(behaviortree,[fresh,source],'Publish authorized main Silent codex1 paid-credit admission',live)
 datasets={};mappings={};sequence={}
 for cwd,head in [(r,oldmain),(live,oldlive)]:
  raw=git('show',head+':eval/versions.json',cwd=cwd);assert (cwd/'eval/versions.json').read_bytes()==raw;data=json.loads(raw);datasets[str(cwd)]=data
  for row in data['release_numbering']['releases']:
   number=int(re.fullmatch(r'V\d+-R(\d+)',row['release_id'])[1]);assert number not in sequence or sequence[number]==row['commit'];sequence[number]=row['commit']
   if row['commit'] in mappings:
    assert mappings[row['commit']]['release_id']==row['release_id'];mappings[row['commit']]['aliases']=list(dict.fromkeys(mappings[row['commit']]['aliases']+row['aliases']))
   else:mappings[row['commit']]=json.loads(json.dumps(row))
 assert set(sequence)==set(range(max(sequence)+1));release=f'V5-R{max(sequence)+1:03d}';name='V5.codex1-paid-credits1';mappings[behavior]={'release_id':release,'commit':behavior,'aliases':[name]};ordered=sorted(mappings.values(),key=lambda x:int(x['release_id'].split('-R')[1]))
 version={'name':name,'family':'V5','character':'SILENT','commit':behavior,'release_id':release,'release_status':'registered-primary-ops','source':f'{at}; Roy2026-10-15 12:34 expressly amends default Roy2026-10-03 usage guard only for main Silent / selected codex1 brain home. Source {source}; default credit prohibition unchanged elsewhere. Exact main live source/workspace/role/home and explicit launcher flag required; positive finite balance, readable quota, spend-control allowance remain mandatory, no reset vouchers. Paid-scope read RPC timeout90s handles actual27-34s host startup; original cadence/model/service/candidates/samples unchanged. Source tsc and full Vitest passed; guard/recovery94 and launcher2/existinghandoff16 fixed checks passed, gitleaks0. Current HLAW never restarted. Selector activation waits for exact final-tree host full and actual native account/guard readback. Evidence paper/materials/20261015-silent-codex1-next-run/; rollback selected home or inverse this scoped eight-leaf patch, preserve current processes/history and parallel V5-S work.'}
 versions={}
 for cwd,data in datasets.items():
  assert not any(row['name']==name for row in data['versions']);data['versions'].append(version);data['release_numbering']['releases']=ordered;versions[cwd]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
 stage('eval/versions.json',versions[str(live)],envlive,live);finaltree=git('write-tree',cwd=live,env=envlive).decode().strip();final=commit(finaltree,[behavior],f'Bind scoped credit admission to {release}',live)
 envmain={**os.environ,'GIT_INDEX_FILE':str(p/'main-publication.index')};git('read-tree',oldmain,env=envmain)
 for path,(value,mode) in composed[str(r)].items():stage(path,value,envmain,r,mode)
 stage('eval/versions.json',versions[str(r)],envmain,r);maintree=git('write-tree',env=envmain).decode().strip();mainnew=commit(maintree,[oldmain,source],f'Integrate scoped main Silent credit admission and {release}',r)
 receipt={'at':at,'source':source,'source_parent':base,'old_main':oldmain,'main_integration':mainnew,'old_live':oldlive,'refresh_commit':fresh,'preserved_knowledge_refresh':refresh,'behavior_commit':behavior,'behavior_tree':behaviortree,'actual_live':final,'actual_live_tree':finaltree,'release_id':release,'name':name,'selected_leaves':selected,'historical_comment_code_equivalence':equal,'source_actual_ancestor':True,'source_checks':s['source_full'],'gitleaks':0,'host_full':'not started; exact final tree required','selector':'unchanged pending host and real native guard acceptance','current_HLAW_restart':False,'other_roles_spaces_regent_ops_learners_changed':False,'P1_P3_P2_C2_and_knowledge':'preserved; no sampling, model or game-rule changes','paid_scope':'main-silent-codex1-20261015','rollback':'Restore previous main brain-home for later processes, or inverse only this eight-leaf feature; preserve all prior model/knowledge/runtime records.'}
 (p/'publication-intended.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 locks=[]
 try:
  for cwd,env in [(r,envmain),(live,envlive)]:
   index=Path(git('rev-parse','--git-path','index',cwd=cwd).decode().strip()).resolve();lockpath=Path(str(index)+'.lock');fd=os.open(lockpath,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   with os.fdopen(fd,'wb') as h:h.write(Path(env['GIT_INDEX_FILE']).read_bytes());h.flush();os.fsync(h.fileno())
   locks.append((index,lockpath))
  assert git('rev-parse','HEAD').decode().strip()==oldmain and git('rev-parse','HEAD',cwd=live).decode().strip()==oldlive
  git('update-ref','-m','ops: publish scoped main Silent paid-credit admission','HEAD',final,oldlive,cwd=live)
  for path,(value,mode) in composed[str(live)].items():install(live,path,value,mode)
  install(live,'eval/versions.json',versions[str(live)])
  git('update-ref','-m','ops: integrate scoped main Silent paid-credit admission','HEAD',mainnew,oldmain)
  for path,(value,mode) in composed[str(r)].items():install(r,path,value,mode)
  install(r,'eval/versions.json',versions[str(r)])
  for index,lockpath in locks:os.replace(lockpath,index)
 finally:
  for index,lockpath in locks:
   if lockpath.exists():lockpath.unlink()
 for cwd,head in [(r,mainnew),(live,final)]:
  assert git('rev-parse','HEAD',cwd=cwd).decode().strip()==head and not git('diff','--cached','--name-only',cwd=cwd).strip();git('merge-base','--is-ancestor',source,head,cwd=cwd)
  for path,(value,mode) in composed[str(cwd)].items():assert (cwd/path).read_bytes()==value
 for row in refresh:assert sha((live/row['path']).read_bytes())==row['sha256']
 (pub/'paid-publication-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'published':True,'release_id':release,'source':source,'live':final,'tree':finaltree,'main':mainnew,'selector':'unchanged','host':'pending','knowledge_refresh':len(refresh)}),flush=True)

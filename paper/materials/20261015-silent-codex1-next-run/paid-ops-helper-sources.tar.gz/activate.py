from pathlib import Path
import os,subprocess,json,hashlib,fcntl,datetime
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1234-paid';pub=r/'paper/materials/20261015-silent-codex1-next-run';live=r/'.worktrees/live';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
d=json.loads((pub/'paid-publication-receipt.json').read_text());host=json.loads((pub/'paid-host-readback.json').read_text());preflight=json.loads((pub/'paid-live-preflight.json').read_text());assert host['exit']==0 and host['tree']==d['actual_live_tree'] and preflight['tree']==host['tree'] and preflight['stage']=='passed' and preflight['actual_published_engine_guard']['before_call_passed']
assert datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(preflight['at'].replace('Z','+00:00'))<datetime.timedelta(minutes=5)
selector=r/'ops/codex-ops/brain-home';target=str(r/'ops/codex-ops/accounts/codex1/brain');original=Path('/home/dw/.codex-brain');expected_old=(str(original)+'\n').encode()
with (r/'ops/live-merge.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 current=git('rev-parse','HEAD',cwd=live).decode().strip();currenttree=git('rev-parse','HEAD^{tree}',cwd=live).decode().strip();git('merge-base','--is-ancestor',d['actual_live'],current,cwd=live)
 # A natural knowledge refresh is allowed; no unverified executable composition may slip past the pinned host result.
 source_paths=['agent/src','agent/tools','agent/tests','agent/package.json','agent/package-lock.json','agent/tsconfig.json','agent/vitest.config.ts','learner','ops/*.sh','ops/*.py','eval/*.py','knowledge/builders']
 assert not git('diff','--name-only',d['actual_live'],current,'--',*source_paths,cwd=live).strip(), 'new executable composition requires its own host acceptance'
 assert not git('diff','--name-only','HEAD','--',*source_paths,cwd=live).strip(), 'uncommitted executable leaves'
 for row in d['selected_leaves']:
  cwd=Path(row['checkout'])
  # Runtime code comes from live; only the main launcher is executed from the integration checkout.
  if cwd==live or row['path']=='ops/run.sh':assert sha((cwd/row['path']).read_bytes())==row['composed_sha256']
 assert selector.read_bytes()==expected_old
 before={};proc=Path('/proc/952170')
 if proc.exists():
  stat=(proc/'stat').read_text();birth=stat[stat.rfind(')')+2:].split()[19];assert birth=='92801432';assert (proc/'cwd').resolve()==live/'agent';before={'pid':952170,'birth':birth,'same_original_process_present':True,'cwd':str((proc/'cwd').resolve()),'run':'HLAWCGM3KHVB','no_signal_or_environment_change':True}
 else:before={'pid':952170,'birth':'92801432','original_process':'absent; no substitute PID touched','run':'HLAWCGM3KHVB'}
 now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(now,flush=True)
 temp=selector.with_name('.brain-home.paid-credit-activation.tmp');assert not temp.exists();temp.write_text(target+'\n');temp.chmod(selector.stat().st_mode & 0o777);os.replace(temp,selector)
 assert selector.read_text()==target+'\n'
 receipt={'at':now,'release_id':d['release_id'],'source':d['source'],'published_live':d['actual_live'],'accepted_host_tree':d['actual_live_tree'],'live_at_selector_activation':current,'tree_at_selector_activation':currenttree,'intervening_changes':'no executable change; any later knowledge/records retained','old_selector':str(original),'new_selector':target,'old_selector_sha256':sha(expected_old),'new_selector_sha256':sha(selector.read_bytes()),'actual_native_account':preflight['actual_native_account'],'fresh_usage':preflight['usage'],'actual_prospective_published_engine_guard_passed':True,'model':'gpt-6.1-sol','effort':'xhigh','service_tier':'default','effective_from':'next natural main Silent controller start after this timestamp; an existing process keeps its original environment','actual_new_game_process_and_accepted_answer':'pending natural start, not claimed by prospective preflight','current_original_process':before,'regent_other_spaces_ops_learner_accounts':'unchanged','credits_authorization':'Roy2026-10-15 12:34; existing positive balance only; no voucher/reset calls','new_game_or_restart_or_model_turn':False,'rollback':'restore old main selector for later starts or inverse only this scoped feature; never touch current process'}
 (pub/'paid-selector-activation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False),flush=True)

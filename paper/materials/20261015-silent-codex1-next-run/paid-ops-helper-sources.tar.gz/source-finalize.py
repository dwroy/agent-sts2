from pathlib import Path
import subprocess,json,hashlib,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1234-paid';pub=r/'paper/materials/20261015-silent-codex1-next-run';w=r/'.worktrees/silent-codex1-paid-20261015';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(w),*a],stderr=subprocess.PIPE)
result=json.loads((pub/'source-full-result.json').read_text());assert result['tsc']==result['vitest']==0
assert json.loads((p/'source-gitleaks.json').read_text())==[]
manifest=json.loads((p/'source-manifest.json').read_text());paths=[x['path'] for x in manifest]
for row in manifest:assert sha((w/row['path']).read_bytes())==row['sha256']
log=(w/'paper/materials/silent-paid-source-full.log').read_text();assert 'Test Files' in log and 'passed' in log
assert not git('diff','--cached','--name-only').strip();actual=set(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines());assert actual==set(paths)
now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(now,flush=True)
for name in ['silent-paid-tsc.log','silent-paid-targeted.log','silent-paid-launcher.log','silent-paid-handoff.log','silent-paid-full-tsc.log','silent-paid-full.log','silent-paid-source-tsc.log','silent-paid-source-full.log']:
 f=w/'paper/materials'/name
 if f.exists():(pub/('source-'+name)).write_bytes(f.read_bytes())
files=[(w/row['path'],row['path']) for row in manifest]+[(p/'prepare-failure-r1.json','operator/prepare-failure-r1.json')]
archive_manifest=[]
with tarfile.open(pub/'paid-source-evidence.tar.gz','w:gz') as archive:
 for f,name in files:
  b=f.read_bytes();archive.add(f,arcname=name);archive_manifest.append({'archive':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(pub/'paid-source-evidence.tar.gz') as archive:
 for row in archive_manifest:assert sha(archive.extractfile(row['archive']).read())==row['sha256']
(pub/'paid-source-evidence-manifest.json').write_text(json.dumps(archive_manifest,indent=2)+'\n')
git('add','--',*paths);git('diff','--cached','--check')
message='Allow scoped paid credits for the authorized main Silent codex1 brain\n\nKeep every default lane on the existing no-credits policy. Only the exact main live source, workspace, Silent role, selected codex1 home and launcher grant admit a positive finite credit balance. Require readable quota and spend control, preserve depletion refusals, never reset credits, and leave running processes untouched.\n\nValidation: source full TypeScript and Vitest passed; fixed guard/recovery and real launcher scope fixtures passed. Wrong thread-pool validation was interrupted and preserved before the correct default-pool full run.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
subprocess.run(['git','-C',str(w),'commit','-F','-'],input=message.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
source=git('rev-parse','HEAD').decode().strip();parent=git('rev-parse','HEAD^').decode().strip();assert set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(paths)
receipt={'at':now,'source':source,'parent':parent,'worktree':str(w),'paths':manifest,'source_full':result,'source_full_summary':log[-1600:],'guard_fixed':'4 files94 cases passed','launcher_python':'2 tests0; existing handoff16 tests0','source_gitleaks':0,'host_full':'not started; pending exact final live','selector':'unchanged','source_original_failures':'wrong thread-pool invocation interrupted130; artifact preparation cwd error retained; no assertions or limits changed','no_game_restart_or_model_request':True}
(pub/'paid-source-publication.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'source':source,'paths':len(paths),'source_full':result}),flush=True)

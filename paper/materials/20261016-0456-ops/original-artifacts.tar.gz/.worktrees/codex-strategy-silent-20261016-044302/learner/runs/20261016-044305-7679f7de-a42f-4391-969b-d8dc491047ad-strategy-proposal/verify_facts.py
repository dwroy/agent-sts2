import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
states = {}
for run in dispatch['runs']:
    for line in (OUT / (run + '.compact-states.jsonl')).open():
        row = json.loads(line)
        states[row['line']] = row
decisions = {}
for line in (OUT / 'evidence/decisions.evidence.jsonl').open():
    row = json.loads(line)
    decisions[row['line']] = row['row']
checks = []


def eq(name, actual, expected, refs):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'source_lines': refs,
                   'pass': actual == expected})
    assert actual == expected, (name, actual, expected)


def enemy(line, id):
    found = [e for e in states[line]['enemies'] if e['enemy_id'] == id]
    assert len(found) == 1
    return found[0]


def power(line, id, who=None):
    if who is None:
        return states[line]['powers'].get(id, 0)
    return next((p['amount'] for p in enemy(line, who)['powers'] if p['power_id'] == id), 0)


def attack(line, who):
    return sum(i['total_damage'] or 0 for i in enemy(line, who)['intents'])


for before, after in [(275564, 275565), (275679, 275680)]:
    eq('神化施放能量变化', states[after]['energy'] - states[before]['energy'], -2, [before, after])
    eq('场外升级数不变', states[after]['deck_upgraded'], states[before]['deck_upgraded'], [before, after])
eq('F35防御升级后文本', next(c['resolved_rules_text'] for c in states[275565]['hand'] if c['card_id'] == 'DEFEND_SILENT'), '获得8点格挡。', [275565])
eq('F43升级后重问预测', [json.loads(decisions[269707]['questions']['plan']['criteria']['plan1'])[k] for k in ['damage_dealt', 'hp_lost']], [51, 13], [269707])
eq('F43实际端点', [90 - states[275687]['hp'], 254 - enemy(275687, 'SOUL_NEXUS')['current_hp']], [13, 51], [275679, 275687])
eq('首题药水MC样本与耗时', [decisions[269748]['potions']['random'][0][k] for k in ['samples', 'requested', 'ms']], [1, 12, 707], [269748])
eq('后题药水MC样本与耗时', [decisions[269754]['potions']['random'][0][k] for k in ['samples', 'requested', 'ms']], [12, 12, 11], [269754])
eq('两题并非同起始盘面', decisions[269748]['fingerprint'] == decisions[269754]['fingerprint'], False, [269748, 269754])
eq('痊愈实际能量变化', states[275729]['energy'] - states[275728]['energy'], 1, [275728, 275729])
eq('痊愈实际HP变化', states[275729]['hp'] - states[275728]['hp'], 0, [275728, 275729])
eq('痊愈后实际手牌', [c['card_id'] for c in states[275729]['hand']], ['APOTHEOSIS', 'TOOLS_OF_THE_TRADE', 'SURVIVOR'], [275729])
eq('F45末轮当前覆甲', power(275754, 'PLATING_POWER'), 0, [275754])
eq('F45末轮挡与来袭', [states[275754]['block'], sum(attack(275754, e['enemy_id']) for e in states[275754]['enemies'])], [20, 59], [275754])
eq('F45末态三敌HP', [e['current_hp'] for e in states[275755]['enemies']], [21, 80, 77], [275755])
eq('F45末态净损与算术需损分列', [states[275754]['hp'] - states[275755]['hp'], 59 - 20], [32, 39], [275754, 275755])

audit = json.loads((OUT / '8JRE1C4H4Z2W.audit-output.json').read_text())
def turn(t, attempt):
    return next(x for x in audit['observed_turns'] if x['floor'] == 33 and x['turn'] == t and x['attempt'] == attempt)
eq('沙虫相同题面指纹', decisions[270216]['fingerprint'], decisions[270282]['fingerprint'], [270216, 270282])
eq('沙虫首三试T2玩家HP差', [turn(2, a)['facts']['player_hp_delta'] for a in [1, 3]], [-3, -15], [270216, 270282])
eq('沙虫首三试T2敌HP差', [turn(2, a)['facts']['enemy_hp_changes'][0]['hp_delta'] for a in [1, 3]], [-10, -17], [270216, 270282])
eq('SL原替候选死亡数区别', [s in decisions[270282]['sl_explore']['numbers'][k] for s, k in [('dead 0/24', 'original'), ('dead 5/24', 'replacement')]], [True, True], [270282])
eq('护栏后实测端点', [turn(5, 2)['facts']['player_hp_delta'], turn(5, 2)['facts']['enemy_hp_changes'][0]['hp_delta']], [-4, -25], [270264])
eq('末试T11只实扣剩5血', turn(11, 6)['facts']['player_hp_delta'], -5, [270437, 270441])

eq('蚌喷水增长', [attack(n, 'SEWER_CLAM') for n in [273237, 273252, 273263]], [11, 15, 19], [273237, 273252, 273263])
eq('蚌虚弱后仍保留增长', [(power(n, 'STRENGTH_POWER', 'SEWER_CLAM'), attack(n, 'SEWER_CLAM')) for n in [273257, 273268]], [(4, 11), (8, 14)], [273257, 273268])
eq('蚌末轮净损不代完整来袭', [states[273268]['hp'], states[273268]['block'], attack(273268, 'SEWER_CLAM')], [2, 10, 14], [273268])
eq('无毒冒泡玩家HP与能量', [(states[n]['hp'], states[n]['energy']) for n in [274379, 274380]], [(29, 5), (29, 4)], [274379, 274380])
eq('无毒冒泡两敌HP不变', [[e['current_hp'] for e in states[n]['enemies']] for n in [274379, 274380]], [[35, 72], [35, 72]], [274379, 274380])
eq('无毒冒泡两敌仍无毒', [[power(n, 'POISON_POWER', e['enemy_id']) for e in states[n]['enemies']] for n in [274379, 274380]], [[0, 0], [0, 0]], [274379, 274380])
eq('吸取后玩家属性', [power(273504, k) for k in ['STRENGTH_POWER', 'DEXTERITY_POWER']], [0, -2], [273503, 273504])
eq('吸取后敌力', power(273504, 'STRENGTH_POWER', 'LAGAVULIN_MATRIARCH'), 2, [273504])
eq('负敏捷双防御总挡', states[273507]['block'], 6, [273504, 273507])
eq('毒触媒下该轮敌净扣', enemy(273507, 'LAGAVULIN_MATRIARCH')['current_hp'] - enemy(273508, 'LAGAVULIN_MATRIARCH')['current_hp'], 33, [273507, 273508])
eq('胧光怪两次成长', [power(n, 'STRENGTH_POWER', 'THE_OBSCURA') for n in [273583, 273589, 273596]], [0, 3, 6], [273583, 273589, 273596])
eq('幻象余2仍未退场', [enemy(273595, 'PARAFRIGHT')['current_hp'], attack(273595, 'PARAFRIGHT'), states[273595]['hp'] - states[273596]['hp']], [2, 15, 15], [273595, 273596])
eq('熟睡甲虫倒计时', [power(n, 'SLUMBER_POWER', 'SLUMBERING_BEETLE') for n in [274906, 274914, 274919, 274923]], [3, 2, 1, 0], [274906, 274914, 274919, 274923])
eq('熟睡甲虫醒后成长来袭', [(power(n, 'STRENGTH_POWER', 'SLUMBERING_BEETLE'), attack(n, 'SLUMBERING_BEETLE')) for n in [274923, 274929, 274934]], [(0, 18), (2, 20), (4, 22)], [274923, 274929, 274934])

(OUT / 'fact-verification.json').write_text(json.dumps({'kind': '材料事实断言，不是生产测试或撤源码负控', 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_assertions': len(checks), 'passed': sum(x['pass'] for x in checks)}, ensure_ascii=False))

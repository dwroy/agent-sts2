import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((OUT / 'dispatch.json').read_text())
queue = json.loads((OUT / 'queue-snapshot.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
now = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
data = [
    ('神化传播与施放归属', 'VLZ6CCT8AQ0A F35T1、F43T1、F45T1',
     '已核2能升级、43/14→51/13和实际51伤/13损；F45持有后弃掉不等于施放。772b839f、ba23ca69已覆盖有界升级，f98a929f的actual_cast_this_fight仍为null。',
     '已有有界升级传播；仍缺跨重规划的实际施放持续归属、未知抽牌及未覆盖交互的联合校准，不能将窄实现登记为整项duplicate。'),
    ('随机药水预算与全败时钟', 'VLZ6CCT8AQ0A F43T1、F45T1/T4/T5',
     'd269748药水MC707ms、1/12，后题d269754为11ms、12/12，但两题指纹不同。痊愈药水实加1能、抽两牌、HP不变。F45末轮32血20挡对59显示来袭。',
     '缺同起始盘面、同随机池、同总预算的MC配对与候选稳定性曲线；不能从两个不同指纹题面拟合预算、留药、血价或目标阈值。'),
    ('神化经验提案补链', 'VLZ6CCT8AQ0A F35T1、F36T2、F37T5、F43T1、F45T1',
     '与89354805ee4d7e77为同源问题，原Markdown及SHA保持。致命毒药5→7传播已有ba23ca69实际live祖先，不另建id。',
     '同源神化问题已有局部实现，完整实际施放归属与未验证交互仍缺；不重复实现或用另一原提案的pending状态冒充已完成。'),
    ('十五经验的机制与资源分账', 'VLZ6CCT8AQ0A F43T1—T5、F44、F45T1—T5',
     'F45当前敏捷3、后空翻8挡、防御12挡，覆甲已0；毒2结算合3后仍三敌存活。保留当前状态、候选、未来收益之别。',
     '缺十五经验全部属性组合、减益期限、毒触发及战斗/路线/休息消费者的冻结联合校准；局部准确端点不足以关闭整项。'),
    ('Jev、护栏、SL与重规划审计', '8JRE1C4H4Z2W F17T6、F33首/三试T2、第二试T5、末试T11',
     '同指纹首/三试T2端点损3/15、扣10/17，SL原替预测死亡0/24与5/24不同。末试T11净扣仅剩5血，整轮经过多次重规划。已有候选与单动作回执及离线端点审计。',
     '缺跨重规划的持续候选身份、完整执行认证和成长逐源归属；现有在线actual_turn/whole_plan_executed仍null，离线端点不能补成因果收益或修改SL阈值。'),
    ('力量、敏捷、虚弱和成长分项', 'CA5KE8GFJ9X2 F13T1/T3/T5',
     '蚌力量0/4/8，喷水11/15/19；弱后11/14仍保留成长。末轮2HP、10挡、显示14，不能把实扣2说成完整只需2。关键战无正敏捷实测。',
     '缺力量、正负敏捷、虚弱、独立成长组合的冻结生产调用与联合校准；本局关键战没有正敏捷实测，不据其他帧硬补组合。'),
    ('组件持有、建立和启动收益', '5PM6JAQG6FNQ F33、F38、F39末试T2',
     's274379→274380玩家29HP不变，能量5→4，两敌35/72HP且无毒不变；d268455证实向无毒目标施放冒泡。其他战已建组件是不同局面。',
     '缺同起始资源、同完整抽序的不同启动顺序受控整战对照与可复现收益函数；不能据一次耗能零效设置统一启动优先级。'),
    ('吸取、负敏捷、毒与SL范围', '61E2QS63Y9WU F17T5—T7',
     's273503→273504玩家力2→0、敏0→−2，敌力0→2；随后双防御共6挡、毒净扣33，临减后又恢复。本战首试赢，整局之后败不改变本战结果。',
     '缺同起始HP、构筑和完整抽序的SL整战配对及未选路线完整后继；首试胜利不足以调整SL范围或换线偏好。'),
    ('胧光怪召唤、成长和目标退场', '61E2QS63Y9WU F23T1—T5，重点T4',
     '实际召唤幻象，力量0→3→6；T4幻象14→2仍打15，本体76→41。旧1e076b17是局部召唤源码，不代表新成长全链和另一个目标顺序正确。',
     '缺A10召唤、退场、再现、实体代际及成长的全链联合调用校准和另一目标顺序完整后继；不把类型ID当实体身份或规定首杀。'),
    ('熟睡甲虫醒来与成长', 'DUZUBAJ3A8GP F30T1—T6，各SL尝试分列',
     '首试睡眠3/2/1后T4显示18，T5力量2/20，T6力量4/22；临减不阻止恢复与增长。四次尝试同属一局，不增独立样本。',
     '缺伤害唤醒、眩晕、当前进阶成长全链校准和同抽换序完整后继；四次相关失败不能确定输出血价或固定杀序。'),
]
assert len(data) == len(queue) == 10
results = []
sections = []
table = ['| 提案 | 主题 | 处置 |', '|---|---|---|']
for item, (title, evidence, observed, reason) in zip(queue, data):
    original = item['original']; id = original['id']
    assert item['actual_sha256'] == original['proposal_sha256']
    results.append({'id': id, 'state': 'waiting', 'reason': reason})
    table.append(f'| `{id}` | {title} | waiting |')
    sections.append(f'''## {id}：{title}

来源：{original['source_task']} → strategy-proposal；角色silent，已观察A10。
原提案：`{original['proposal']}`；SHA256 `{original['proposal_sha256']}`，原字节另存同目录 `{id}.original.md`。
证据：{evidence}。账本：{', '.join(original['ledger'])}。

本批核验：{observed}

处置：**waiting**。{reason}

旧/新行为：保留当前行为；本批没有策略参数或规则变更。预期后续只在冻结实际输入和已观察条件内补齐缺口，相同推演标并列、全部合法选项保持。
反例与限制：原提案的反例和未知完整保留；上述已观察数值不证明未选线胜负，不把候选差、同局SL或场外持有算成已兑现收益。
后续验证：以本段指定帧作发现/回归输入，补齐缺失路径后走实际生产消费者；若新增源码则必须撤码失败、恢复通过及原沙箱检查，再核live祖先。未来独立同角色局按时间后移验证，不能将本六局自称盲测。
预期影响与回退：本批无行为影响、无源码需回退；后续实现以独立实际源码commit回退，保留原日志、账本和本报告。
''')
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
scope = f'''# Silent 十项策略提案复核

记录时间：{now}。批次：20261016-044302-strategy-proposal。
基线/当前HEAD：`{base}`。工作树：`{OUT.parents[2]}`。

本批十项均已逐项处置为waiting。六个派发局号均在runs.jsonl核为Silent A10；已有局部实现有实际live源码祖先，但不能据此关闭更宽的原提案。本批没有新增足以支持规则变更的证据，不修改源码或知识，不创建重复代码提案。

## 身份与边界

只读根learn.json本批行，task=strategy-proposal、character=silent、reason=proposal、state=running、工作树和六runs精确匹配，proposal_ids恰为下表十项；无research_request、implementation_request或proposal_repair。普通专题请求的batch另属20261010，不匹配，本批保持消费队列任务。开工git status干净，git merge --no-edit main返回Already up to date；base保持上值。没有借用其他角色私有知识、没有调LLM/网络或游戏。

## 提案处置

''' + '\n'.join(table) + '\n\n'
(OUT / 'proposal.md').write_text(scope + '\n'.join(sections))
summary = json.loads((OUT / 'audit-summary.json').read_text())
runs = json.loads((OUT / 'run-summary.json').read_text())
counts = ['| 局号 | 状态 | 决策 | 复核层 | 审计决策 | 已知/未知整轮端点 |', '|---|---:|---:|---|---:|---|']
for r, a in zip(runs, summary):
    counts.append(f"| `{r['run_id']}` | {r['counts']['states']} | {r['counts']['decisions']} | {','.join(map(str,r['audit_floors']))} | {r['audit_decisions']} | {a['turns'].get('observed_turn_endpoints',0)}/{a['turns'].get('unknown',0)} |")
report = scope + f'''## 原始证据与复核范围

共用extract_evidence.py按显式run身份抽取八流；`evidence/evidence-manifest.json`保存各source_size、逐局计数及输出SHA，逐行原offset/bytes/SHA保存在各evidence.jsonl。`byte-verification.json`逐行重新seek原日志，6,995行均通过长度、SHA、JSON相等与显式单一身份校验。原states/decisions各2行、brain1行无效JSON是整个扫描截点的计数，不推断为本六局缺帧。fight-plans在本次固定截点选中0行，不断言原流不存在或旧截点缺失。

''' + '\n'.join(counts) + '''

范围是六局的全部所属八流抽取，以及表列层的有界语义/离线审计，未重新验证全历史。六局均记录dirty运行代码，不能用当前干净源码完全复原历史运行树。

`audit-execution.json`保存六次既有learner/audit-selection.ts调用命令、退出码及输入/输出/stderr SHA；六次均exit0，输入只去除decisions.agent_view并附原行号，状态保留原字节语义。157题段、797动作、505相邻观测端点、3个终态端点、146轮窗（76已知、70未知）；所有完整候选认证仍为null。VLZ和CA5缺已知尝试号，严格工具不连接端点，未补填尝试号；原帧事实另行明确列出。材料断言`fact-verification.json`共37项首次37通过，支持上面有限事实；它们不是生产测试、撤源码负控、自然消费者或策略收益证明。

执行设置限制：首轮离线工具未显式设置TMPDIR，不能声称首轮运行器临时缓存全部落在指定目录。保留首轮全部输入/输出/回执后，使用指定scratch作为TMPDIR顺序重跑同六冻结输入；六次exit0、六份输出逐字节相同，回执audit-tmpdir-execution.json及*.audit-tmpdir-output.json完整保存。不删除可能与其他会话共用的默认运行器缓存，不将复跑改写成首轮符合设置；后续命令显式使用本批TMPDIR。

## 关键结论与反例

神化F35的2能升级和F43同序列51伤/13损可直接核，F45未施放不构成升级机制反例，也不能用F35/43胜与F45败估计神化胜率。致命毒药的窄传播已存在，不重复写同一实现。

沙虫原试/三试T2端点分别−3/−15玩家HP、−10/−17敌HP，差12血/7伤；第三试同题原/替预测死亡0/24与5/24须分列。第二试T5护栏后实损4/扣25，末试T11实际净扣5且经过多次重规划；净扣5不等于完整来袭只需5，也不归给某个候选整条收益。末试另一防御替换延长战斗但仍败，保留原提案反对统一攻击/防御规则的限制。

三骑士F45T5显示59攻击、20挡、32血，算术需损39，死亡只实扣剩32；毒后仍有三敌，不能把候选focus写成已退场。随机药水707ms/1样本和后题11ms/12样本指纹不同，不是同盘预算实验；痊愈实际不回血。当前缺新预算常量、留药价值、统一输出血价的因果依据。

蚌弱后仍增长、负敏捷双防御、无毒冒泡耗能零效、胧光怪幻象未退场仍攻击、熟睡甲虫睡眠/恢复/增长均与已登记限定观察一致。无毒冒泡本批用s274379观察时间06:20:33.172Z、d268455完成06:20:35.419Z及后帧06:20:36.248Z区分时钟；玩家为29血，35是敌血，沿既有勘误，不重写历史。没有发现新的机制反证或独立规则冲突。

## 已有源码与实际live边界

`source-readback.json`以本批base及只读live e716bd28fd8eca9e4d76d066680304fd11935e37为快照，17个相关源码叶15个字节相同；card-model.ts、rollout-live.ts差异仅历史Roy/Dai注释，原差异保留，所核叶live均无未提交修改。这只是指定叶快照，不宣称整个live树或旧dirty树等价。

本批独立核以下真实源码提交同时为base和上述live祖先：

- 772b839f8ada31664cb764ea9ad3bdb03da27f64：已观察神化升级。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：致命毒药窄升级传播。
- f98a929f24901c20efed462b29591e25ebb85451：神化候选事实，actual_cast_this_fight=null。
- fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执，whole_plan_executed/actual_turn=null。
- 5604982e13890e0e2bc8bf8246272e8267321c0b：SL候选资源比较。
- 1e076b173c6874cef4bf90fd13cd3eb33355827a：有界召唤与次轮威胁。
- e75438488df159b2e8e9d3458cf219b39aadd933：离线整轮观测审计。
- a32050fbce4c2863f640468c2dbf378fc9157074：离线药水观测。

这些源码证明已有子功能，并不把十项原提案整体登记duplicate或implemented。未实现理由、证据层/回合和账本逐项见proposal.md，原Markdown保存于同目录*.original.md且逐SHA核同。

## 记录、验证和交付

只经根learner/ledger.py update追加26个原账本的本批proposal/report追溯及note，不重复增加证据或新id、不改变原claim/first_run/prior/evidence/status/version，不将原shipped退回proposed。输入、CLI实际stdout、退出码及更新后保护字段校验见ledger-updates.input.jsonl、ledger-updates.stdout.txt、ledger-update-receipt.json；没有声称经验库新沉淀或大脑已采用。

无生产源码或知识改动，无提交、无撤码/恢复实验，无tsc/vitest；tests为null。没有合入live、版本号或shipped登记，不修改根请求/队列原文、运维prompt、通知文件或对局。所有原始材料保留；不删除正在运行的工作树。没有新代码提案，最终code_proposals列本次处理的十个既有CLI id，implementation_domains为空。

最终工作树/HEAD、dispatch身份重核、git diff --binary与脱敏扫描结果另存completion-check.json及gitleaks材料；扫描不作生产测试。运维沿原派发链读取proposal-results.json，每项waiting保留具体缺数原因，等待新增证据，不关闭宽父要求。
'''
(OUT / 'report.md').write_text(report)
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-044302-strategy-proposal',
         'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'proposal_count': len(results), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

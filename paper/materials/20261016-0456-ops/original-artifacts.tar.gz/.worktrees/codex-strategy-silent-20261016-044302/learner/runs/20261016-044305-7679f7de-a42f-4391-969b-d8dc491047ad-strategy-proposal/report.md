# Silent 十项策略提案复核

记录时间：2026-10-16T04:54:41+08:00。批次：20261016-044302-strategy-proposal。
基线/当前HEAD：`38a1f2e4d59f9582bf78e562aeecd39e1dd11375`。工作树：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-044302`。

本批十项均已逐项处置为waiting。六个派发局号均在runs.jsonl核为Silent A10；已有局部实现有实际live源码祖先，但不能据此关闭更宽的原提案。本批没有新增足以支持规则变更的证据，不修改源码或知识，不创建重复代码提案。

## 身份与边界

只读根learn.json本批行，task=strategy-proposal、character=silent、reason=proposal、state=running、工作树和六runs精确匹配，proposal_ids恰为下表十项；无research_request、implementation_request或proposal_repair。普通专题请求的batch另属20261010，不匹配，本批保持消费队列任务。开工git status干净，git merge --no-edit main返回Already up to date；base保持上值。没有借用其他角色私有知识、没有调LLM/网络或游戏。

## 提案处置

| 提案 | 主题 | 处置 |
|---|---|---|
| `silent-proposal-89354805ee4d7e77` | 神化传播与施放归属 | waiting |
| `silent-proposal-f2bfceddb1898dca` | 随机药水预算与全败时钟 | waiting |
| `silent-proposal-283a164780d11e69` | 神化经验提案补链 | waiting |
| `silent-proposal-ebbfe3b97548756d` | 十五经验的机制与资源分账 | waiting |
| `silent-proposal-e5b87be50f28f311` | Jev、护栏、SL与重规划审计 | waiting |
| `silent-proposal-49632bc4878fb597` | 力量、敏捷、虚弱和成长分项 | waiting |
| `silent-proposal-66532328a585941f` | 组件持有、建立和启动收益 | waiting |
| `silent-proposal-43a76a31ba7bdcfa` | 吸取、负敏捷、毒与SL范围 | waiting |
| `silent-proposal-5264153a4a4b0e5c` | 胧光怪召唤、成长和目标退场 | waiting |
| `silent-proposal-bddfa690a84e03d0` | 熟睡甲虫醒来与成长 | waiting |

## 原始证据与复核范围

共用extract_evidence.py按显式run身份抽取八流；`evidence/evidence-manifest.json`保存各source_size、逐局计数及输出SHA，逐行原offset/bytes/SHA保存在各evidence.jsonl。`byte-verification.json`逐行重新seek原日志，6,995行均通过长度、SHA、JSON相等与显式单一身份校验。原states/decisions各2行、brain1行无效JSON是整个扫描截点的计数，不推断为本六局缺帧。fight-plans在本次固定截点选中0行，不断言原流不存在或旧截点缺失。

| 局号 | 状态 | 决策 | 复核层 | 审计决策 | 已知/未知整轮端点 |
|---|---:|---:|---|---:|---|
| `VLZ6CCT8AQ0A` | 729 | 699 | 35,36,37,43,44,45 | 165 | 0/25 |
| `8JRE1C4H4Z2W` | 676 | 659 | 17,33 | 277 | 44/13 |
| `CA5KE8GFJ9X2` | 282 | 265 | 13 | 26 | 0/5 |
| `5PM6JAQG6FNQ` | 660 | 638 | 33,38,39 | 152 | 10/13 |
| `61E2QS63Y9WU` | 462 | 443 | 17,23 | 60 | 5/7 |
| `DUZUBAJ3A8GP` | 623 | 602 | 30 | 117 | 17/7 |

范围是六局的全部所属八流抽取，以及表列层的有界语义/离线审计，未重新验证全历史。六局均记录dirty运行代码，不能用当前干净源码完全复原历史运行树。

`audit-execution.json`保存六次既有learner/audit-selection.ts调用命令、退出码及输入/输出/stderr SHA；六次均exit0，输入只去除decisions.agent_view并附原行号，状态保留原字节语义。157题段、797动作、505相邻观测端点、3个终态端点、146轮窗（76已知、70未知）；所有完整候选认证仍为null。VLZ和CA5缺已知尝试号，严格工具不连接端点，未补填尝试号；原帧事实另行明确列出。材料断言`fact-verification.json`共37项首次37通过，支持上面有限事实；它们不是生产测试、撤源码负控、自然消费者或策略收益证明。

执行设置限制：首轮离线工具未显式设置TMPDIR，不能声称首轮运行器临时缓存全部落在指定目录。保留首轮全部输入/输出/回执后，使用指定scratch作为TMPDIR顺序重跑同六冻结输入；六次exit0、六份输出逐字节相同，回执audit-tmpdir-execution.json及*.audit-tmpdir-output.json完整保存。不删除可能与其他会话共用的默认运行器缓存，不将复跑改写成首轮符合设置；后续命令显式使用本批TMPDIR。

## 关键结论与反例

神化F35的2能升级和F43同序列51伤/13损可直接核，F45未施放不构成升级机制反例，也不能用F35/43胜与F45败估计神化胜率。致命毒药的窄传播已存在，不重复写同一实现。

沙虫原试/三试T2端点分别−3/−15玩家HP、−10/−17敌HP，差12血/7伤；第三试同题原/替预测死亡0/24与5/24须分列。第二试T5护栏后实损4/扣25，末试T11实际净扣5且经过多次重规划；净扣5不等于完整来袭只需5，也不归给某个候选整条收益。末试另一防御替换延长战斗但仍败，保留原提案反对统一攻击/防御规则的限制。

三骑士F45T5显示59攻击、20挡、32血，算术需损39，死亡只实扣剩32；毒后仍有三敌，不能把候选focus写成已退场。随机药水707ms/1样本和后题11ms/12样本指纹不同，不是同盘预算实验；痊愈实际不回血。当前缺新预算常量、留药价值、统一输出血价的因果依据。

蚌弱后仍增长、负敏捷双防御、无毒冒泡耗能零效、胧光怪幻象未退场仍攻击、熟睡甲虫睡眠/恢复/增长均与已登记限定观察一致。无毒冒泡本批用s274379观察时间06:20:33.172Z、d268455完成06:20:35.419Z及后帧06:20:36.248Z区分时钟；玩家为29血，35是敌血，沿既有勘误，不重写历史。没有发现新的机制反证或独立规则冲突。

## 已有源码与实际live边界

`source-readback.json`以本批base及只读live e716bd28fd8eca9e4d76d066680304fd11935e37为快照，17个相关源码叶15个字节相同；card-model.ts、rollout-live.ts差异仅历史Roy/Dai注释，原差异保留，所核叶live均无未提交修改。这只是指定叶快照，不宣称整个live树或旧dirty树等价。

本批独立核以下真实源码提交同时为base和上述live祖先：

- 772b839f8ada31664cb764ea9ad3bdb03da27f64：已观察神化升级。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：致命毒药窄升级传播。
- f98a929f24901c20efed462b29591e25ebb85451：神化候选事实，actual_cast_this_fight=null。
- fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执，whole_plan_executed/actual_turn=null。
- 5604982e13890e0e2bc8bf8246272e8267321c0b：SL候选资源比较。
- 1e076b173c6874cef4bf90fd13cd3eb33355827a：有界召唤与次轮威胁。
- e75438488df159b2e8e9d3458cf219b39aadd933：离线整轮观测审计。
- a32050fbce4c2863f640468c2dbf378fc9157074：离线药水观测。

这些源码证明已有子功能，并不把十项原提案整体登记duplicate或implemented。未实现理由、证据层/回合和账本逐项见proposal.md，原Markdown保存于同目录*.original.md且逐SHA核同。

## 记录、验证和交付

只经根learner/ledger.py update追加26个原账本的本批proposal/report追溯及note，不重复增加证据或新id、不改变原claim/first_run/prior/evidence/status/version，不将原shipped退回proposed。输入、CLI实际stdout、退出码及更新后保护字段校验见ledger-updates.input.jsonl、ledger-updates.stdout.txt、ledger-update-receipt.json；没有声称经验库新沉淀或大脑已采用。

无生产源码或知识改动，无提交、无撤码/恢复实验，无tsc/vitest；tests为null。没有合入live、版本号或shipped登记，不修改根请求/队列原文、运维prompt、通知文件或对局。所有原始材料保留；不删除正在运行的工作树。没有新代码提案，最终code_proposals列本次处理的十个既有CLI id，implementation_domains为空。

最终工作树/HEAD、dispatch身份重核、git diff --binary与脱敏扫描结果另存completion-check.json及gitleaks材料；扫描不作生产测试。运维沿原派发链读取proposal-results.json，每项waiting保留具体缺数原因，等待新增证据，不关闭宽父要求。

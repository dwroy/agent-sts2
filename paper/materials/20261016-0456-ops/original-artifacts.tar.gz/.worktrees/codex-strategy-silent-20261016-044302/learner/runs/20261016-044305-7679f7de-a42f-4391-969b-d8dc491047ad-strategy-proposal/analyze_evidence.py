import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']
FLOORS = {'VLZ6CCT8AQ0A': [35, 36, 37, 43, 44, 45],
          '8JRE1C4H4Z2W': [17, 33], 'CA5KE8GFJ9X2': [13],
          '5PM6JAQG6FNQ': [33, 38, 39], '61E2QS63Y9WU': [17, 23],
          'DUZUBAJ3A8GP': [30]}


def identity(row):
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = None
    state = row.get('state') or {}
    values = [row.get('run'), row.get('run_id'), state.get('run_id'),
              fp.get('run') if isinstance(fp, dict) else None]
    found = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(found)) if len(found) == 1 else None


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(value):
    return {p['power_id']: p.get('amount') for p in value or []}


def compact(e):
    row = e['row']; s = row['state']; r = s.get('run') or {}
    c = s.get('combat') or {}; p = c.get('player') or {}
    return {'line': e['line'], 'ts': row.get('observed_ts'), 'floor': r.get('floor'),
            'turn': s.get('turn'), 'screen': s.get('screen'), 'hp': p.get('current_hp', r.get('current_hp')),
            'max_hp': p.get('max_hp', r.get('max_hp')), 'energy': p.get('energy'), 'block': p.get('block'),
            'powers': powers(p.get('powers')), 'potions': r.get('potions'),
            'deck_upgraded': sum(bool(x.get('upgraded')) for x in r.get('deck', [])),
            'hand': [{k: x.get(k) for k in ['index', 'card_id', 'name', 'upgraded', 'cost', 'resolved_rules_text', 'dynamic_vars']}
                     for x in c.get('hand', [])],
            'enemies': [{k: x.get(k) for k in ['index', 'enemy_id', 'name', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id', 'intents', 'powers']}
                        for x in c.get('enemies', [])]}


def main():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    grouped = defaultdict(lambda: defaultdict(list))
    checks = []
    for entry in manifest:
        stream = entry['stream']; path = OUT / 'evidence' / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
        counts = Counter()
        with open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as source:
            for line in path.open():
                e = json.loads(line); source.seek(e['offset']); raw = source.read(e['bytes'])
                assert len(raw) == e['bytes'] and hashlib.sha256(raw).hexdigest() == e['sha256']
                assert json.loads(raw) == e['row'] and identity(e['row']) == e['run_id']
                assert e['offset'] + e['bytes'] <= entry['source_size']
                counts[e['run_id']] += 1; grouped[stream][e['run_id']].append(e)
        assert all(counts[run] == count for run, count in entry['counts'].items())
        checks.append({'stream': stream, 'verified_rows': sum(counts.values()), 'counts': dict(counts),
                       'source_size': entry['source_size'], 'invalid_lines': entry['invalid_lines'],
                       'incomplete_lines': entry['incomplete_lines']})
    dump('byte-verification.json', checks)
    summaries = []
    for run in RUNS:
        observed_runs = grouped['runs'][run]
        assert len(observed_runs) == 1
        r = observed_runs[0]['row']
        assert str(r.get('character', r.get('character_id', ''))).lower() == 'silent'
        assert r['ascension'] == 10
        rows = [compact(e) for e in grouped['states'][run]]
        with (OUT / (run + '.compact-states.jsonl')).open('w') as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False) + '\n')
        decisions = []
        for e in grouped['decisions'][run]:
            row = dict(e['row']); row.pop('agent_view', None); row['_line'] = e['line']
            if row.get('floor') in FLOORS[run]: decisions.append(row)
        states = [dict(e['row'], _line=e['line']) for e in grouped['states'][run]
                  if (e['row']['state'].get('run') or {}).get('floor') in FLOORS[run]]
        dump(run + '.audit-input.json', {'run': r, 'decisions': decisions, 'states': states})
        summaries.append({'run_id': run, 'run_record': r, 'counts': {s: len(g[run]) for s, g in grouped.items()},
                          'audit_floors': FLOORS[run], 'audit_decisions': len(decisions), 'audit_states': len(states),
                          'missing_decision_ids': [x['_line'] for x in decisions if not x.get('decision_id')]})
    dump('run-summary.json', summaries)
    print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in checks),
                      'runs': [{k: x[k] for k in ['run_id', 'counts', 'audit_floors', 'audit_decisions', 'audit_states', 'missing_decision_ids']}
                               for x in summaries]}, ensure_ascii=False))


if __name__ == '__main__':
    main()

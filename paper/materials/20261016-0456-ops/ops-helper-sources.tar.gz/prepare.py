from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0456';pub=root/'paper/materials/20261016-0456-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-044302-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'completion-check.json');assert final['head']==report['base'] and final['status_porcelain']=='' and all(final[k] for k in ['git_diff_empty','dispatch_identity_unchanged','ten_original_proposals_unchanged','proposal_results_complete','ledger_protected_fields_unchanged','no_source_commit','no_live_merge','tmpdir_rechecks_identical'])
assert final['ledger_cli_rows']==26 and final['material_assertions']==37 and final['production_tests'] is None and (s/'final-head-diff.patch').read_bytes()==b''
originals=load(s/'queue-snapshot.json');assert len(originals)==10 and {x['original']['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    o=x['original'];original=Path(o['proposal']);copy=s/(o['id']+'.original.md');assert original.is_relative_to(root) and x['proposal_exists']
    assert sha(copy.read_bytes())==x['actual_sha256']==o['proposal_sha256']
    if original.exists():assert sha(original.read_bytes())==o['proposal_sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');summaries=load(s/'run-summary.json');runs={x['run_id']:x['run_record'] for x in summaries}
assert set(report['runs'])==set(runs) and len(runs)==6 and all((x['character'],x['ascension'])==('SILENT',10) for x in runs.values())
receipts=load(s/'audit-execution.json');reruns=load(s/'audit-tmpdir-execution.json');assert len(receipts)==len(reruns['results'])==6 and all(x['exit_code']==0 for x in receipts)
needed={stream:set() for stream in ['states','decisions']}
for x in receipts:
    data=load(s/(x['run_id']+'.audit-input.json'))
    for stream in needed:needed[stream].update(row['_line'] for row in data[stream])
counts={};input_rows={stream:{} for stream in needed};manifest=load(s/'evidence/evidence-manifest.json');verification=load(s/'byte-verification.json')
for x in manifest:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in runs
            if x['stream']=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10)
            if x['stream']=='runs':assert row==runs[e['run_id']]
            if x['stream'] in needed and e['line'] in needed[x['stream']]:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==6995
for x in verification:assert counts[x['stream']]==x['verified_rows']
facts=load(s/'fact-verification.json');assert len(facts['checks'])==37 and all(x['pass'] and x['actual']==x['expected'] for x in facts['checks']) and (s/'facts.stderr.txt').read_bytes()==b''
source=load(s/'source-readback.json');assert source['base']==report['base'] and len(source['files'])==17 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_head_observed']
for x in source['files']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head_observed']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (root/'.worktrees/live'/x['path']).read_bytes()==z and x['live_tracked_dirty']==''
    assert (a==z)==x['same_bytes'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['same_bytes'] for x in source['files'])==15
for x in source['source_ancestors']:
    assert x['base_ancestor'] and x['live_ancestor']
    for head in [report['base'],source['live_head_observed']]:git('merge-base','--is-ancestor',x['commit'],head)
totals=collections.Counter();consumers=[]
for x in receipts:
    run=x['run_id'];ip=s/(run+'.audit-input.json');op=s/(run+'.audit-output.json');err=s/(run+'.audit-stderr.txt');again=next(y for y in reruns['results'] if y['run_id']==run)
    assert Path(x['command'][-1])==ip and sha(ip.read_bytes())==x['input_sha256'] and sha(op.read_bytes())==x['output_sha256'] and sha(err.read_bytes())==x['stderr_sha256']
    assert again['exit_code']==0 and again['same_bytes_as_initial'] and again['TMPDIR']==str(s) and again['input_sha256']==x['input_sha256'] and again['output_sha256']==x['output_sha256'] and again['stderr_sha256']==x['stderr_sha256']
    assert (s/(run+'.audit-tmpdir-output.json')).read_bytes()==op.read_bytes() and (s/(run+'.audit-tmpdir-stderr.txt')).read_bytes()==err.read_bytes()
    data=load(ip);audit=load(op);assert data['run']==runs[run]
    for stream in needed:
        for row in data[stream]:
            reference=input_rows[stream][row['_line']];assert reference['run']==run
            expected={**reference['row'],'_line':row['_line']}
            if stream=='decisions':expected.pop('agent_view',None);assert row.get('decision_id')
            assert row==expected
    status=collections.Counter(row['status'] for row in audit['observed_turns']);assert all(row['actual_full_candidate_result'] is None for row in audit['segments'])
    actions=audit['observed_actions'];c=dict(segments=len(audit['segments']),actions=len(actions),intervals=sum((r.get('observed_interval') or {}).get('status')=='observed_endpoints' for r in actions),terminal_intervals=sum((r.get('terminal_observation') or {}).get('status')=='observed_terminal_endpoints' for r in actions),turns=len(audit['observed_turns']),observed_turns=status['observed_turn_endpoints'],unknown_turns=status['unknown'])
    totals.update(c);consumers.append(dict(run=run,**c))
assert totals==dict(segments=157,actions=797,intervals=505,terminal_intervals=3,turns=146,observed_turns=76,unknown_turns=70)
receipt=load(s/'ledger-update-receipt.json');rows=receipt['verified_cli_rows'];inputs=[json.loads(line) for line in (s/'ledger-updates.input.jsonl').read_text().splitlines()]
assert receipt['exit_code']==0 and sha((s/'ledger-updates.input.jsonl').read_bytes())==receipt['input_sha256'] and len(rows)==len(inputs)==26 and receipt['prefix_preserved'] and receipt['prior_where_history_notes_preserved'] and all(receipt['protected_fields_unchanged'].values())
assert set((s/'ledger-updates.stdout.txt').read_text().split())=={x['id'] for x in inputs}==set(receipt['requested_ids']) and (s/'ledger-updates.stderr.txt').read_bytes()==b''
own=[];owned_receipts=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(receipt['source_size_before']))==receipt['prefix_sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row['id']==entry['id'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        matched=[v for v in inputs if (v['id'],v['note'])==(row['id'],row['note'])];assert len(matched)==1 and all(row.get(k)==v for k,v in matched[0].items());own.append(raw);owned_receipts.append(dict(**entry,row=row))
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==26 and not set(raw.rstrip(b'\n') for raw in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
assert load(s/'gitleaks-receipt.json')['exit_code']==0 and load(s/'gitleaks-report.json')==[]
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,original_completion=final,original_proposals=originals,stream_counts=counts,original_rows_verified=6995,ascension_cohorts={10:6},material_assertions=37,source=source,original_consumers=receipts,original_tmpdir_rechecks=reruns,consumer_counts=dict(totals),consumer_summaries=consumers,owned_trace_rows=owned_receipts,protected_fields_and_prefixes_preserved=True,no_checks_reexecuted=True,limits=['Original first six offline calls omitted explicit TMPDIR; retain the original scope limit and six later identical-output rechecks, not relabel first settings.','Bounded six windows,76 observed/70 unknown turns and no certified complete candidates do not close broad strategy proposals or historical dirty-tree reconstruction.','Missing attempts remain unknown; exact observed loss or capped loss is not uncapped incoming damage or complete candidate benefit.','Different-fingerprint random-potion questions and correlated SL attempts are not paired same-budget experiments or independent strategy samples.','No new gameplay counterevidence reported. No source, merge, release, production tests, paper refresh, new dispatch or game action; wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0456原044302策略done0/no-source核收，38a1基线干净WT/HEAD不变，十waiting逐项缺口/testsnull/mergednull保持，无合入受阻。六Silent A10八流6995原行逐offset/bytes/SHA/JSON/显式身份核，37原材料断言首次通过；六有界离线input/output/stderr及原行去decisions.agent_view/加_line投影绑定核，157题段/797动作/505相邻端点/3终态端点/146轮窗（76已知70未知），完整候选全null。原六调用未显式TMPDIR限制及随后指定scratch同六输入复验exit0/六输出逐字节相同分列，不改写首轮设置、不重跑工具或删除共用缓存，不作生产测试/自然消费者/受控整战收益。VLZ/CA缺尝试号不补；不同指纹药瓶题非同预算配对；局部净损/截断毛伤、能力施放/持有/覆盖分列，已沿旧勘误的玩家29/敌35保持无新反证。17相关源码叶15同2历史Roy/Dai注释差及八真实base/live来源祖先核，窄传播/actual空值不关闭宽父。26所属CLI只where/note，原物理前缀/offset/SHA与私有fold核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI、证据或造新提案。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核。仅本人记录/26追溯提交，保并行记录；无源码/合入/发号/补测/论文刷新/复派/重启对局或账号home模型额度权限prompt变更。证据paper/materials/20261016-0456-ops/。\n'
note=f'\n- {at} [运维 codex] 原044302十项继续waiting，无源码修改或合入阻塞；6995原行、37原材料断言、六有界离线及26条所属追溯已核。首轮TMPDIR设置限制和后续同输入等字节复验原件分列，未知后继与宽父保持，无新发布或补测。回执paper/materials/20261016-0456-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=26,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=6995,owned_trace_rows=26,ledger_check=0,paths=len(entries))))

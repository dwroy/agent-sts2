import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
batch = '20261017-214302-strategy-proposal'
dispatch = json.loads((OUT / 'dispatch.json').read_text())
queue = json.loads((OUT / 'queue-snapshot.json').read_text())
analysis = json.loads((OUT / 'evidence-analysis.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())

details = [
    ('89354805ee4d7e77', '神化升级传播',
     'VLZ6CCT8AQ0A F35 T1：states275564→275565，能量7→5，防御5→8、打击7→10、匕首雨5→7、工具1费→0；F43 T1：states275679→275687，decisions269706/269707的43伤/14损→51伤/13损得到原帧端点51/13支持。',
     'F35施放后原候选发生重规划；F43仍是同局发现样本。F45未施放，不能由持有神化预支升级或整战收益。',
     '缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整生产消费者认证；已有A10普通神化窄升级传播和候选事实字段不等于整项实现。',
     '从实际施放日志建立有界归属，分别核同轮已知手牌、后续已知抽牌、重问、SL恢复和换战重置；未知升级及属性组合继续unknown。'),
    ('f2bfceddb1898dca', '随机药水与推演预算',
     'VLZ6CCT8AQ0A F45 T1 decisions269748：MC707ms、1/12；rollout696ms、horizon1/samples1/best=null。269754：MC11ms、12/12，rollout1393ms、horizon5/samples3。T4 decisions269770：plan2/3/4明确并列，31损/32伤，plan1为13损/24伤。',
     '两问状态和剩余手牌不同，不能构成同起点同总预算实验。all-loss与预算未比较不是同义；未实打的另一focus不补成完整胜线。',
     '缺模型充分覆盖下同起点、同随机池、同总预算的MC分配策略配对与样本成熟度曲线；707ms单题及后来12/12不同题不能确定新预算、留药常量或固定目标。',
     '先冻结已覆盖模型、牌堆、随机池与相同总预算，再比较成熟度和候选稳定性；实际喝药后按实抽重算，保留全部选项及真正并列。'),
    ('283a164780d11e69', '神化经验消费链接',
     '同89354805ee4d7e77的VLZ6CCT8AQ0A F35 T1、F43 T1/T2和F45 T1；两份原Markdown均按队列SHA核回。',
     '同源经验链接不是第二份独立机制样本，也不是已经交付全部范围的源码duplicate。',
     '与89354805ee4d7e77同源，仍缺实际施放持续身份及后续生产消费认证；不以同题提案或既有窄实现将整项登记duplicate。',
     '复用原神化提案的证据与后续实现，不另建重复id；逐项验证经验声明与实际消费者范围。'),
    ('ebbfe3b97548756d', '十五机制及资源分账',
     'VLZ6CCT8AQ0A F43 T1升级勒紧6/尖啸8；F43 T2/T3为减力、步法与现场属性组合；F45 T4/T5为当轮损伤、实际成长、零覆甲和残毒分账。原提案关联14账本、15经验。',
     'F43获胜仍损57；F45持有两雾未建立。未知未选路线、休息和focus整战结果不能转作因果。',
     '缺十五机制逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者的固定校准闭环；本批未定位新的确定源码失配，局部机制代码不足证明整条复合提案完成。',
     '按各机制自己的来源、条件和观察分母冻结夹具；分开毒已结算量、能力建立时点、当前覆甲及资源投影，不新增统一血价。'),
    ('e5b87be50f28f311', 'SL及HP护栏实际代价审计',
     '8JRE1C4H4Z2W F33首/三试T2 decisions270216/270282指纹相同。原始状态首试276208→276212为47→44血、326→316敌血；三试276274→276278为47→32血、326→309敌血，差12血/7伤。第三次同题两候选死亡0/24与5/24；首试另为8样本，不能混成24。第二次T5 decisions270264留有护栏前16损/43伤及后4损/25伤差。',
     '同局六次SL不是六个独立样本。抽牌、选牌和药水会截断原候选；派发成功或整轮端点均不证明某条候选全部执行。首试与三试模拟样本预算不同。',
     '已有Jev原答、护栏后、SL后及单动作派发审计；仍缺跨抽牌、选牌、生成、药水重问与SL的候选持续归属和完整实际收益生产认证，不能将端点或前缀视为整线执行。',
     '保持原选择，冻结候选—首次派发—实际前缀—重问—终态链接；显式保留中断和未知，完整分离死亡样本数、损血封顶及SL恢复。'),
    ('49632bc4878fb597', '属性、虚弱与独立成长',
     'CA5KE8GFJ9X2 F13 T1/T3/T5：states273238/273252/273263见敌力0/4/8、喷水11/15/19；T5中和后14，玩家2血10挡，完整需损4，不能以实扣至0的2替代完整代价。',
     '虚弱未停止后续加压；CA5计划中的步法没有取得。本批VLZ有正敏捷观察，但不能冒充CA5的同组属性实验。',
     '缺逐来源冻结的力量逐击、正负敏捷、虚弱与蚌独立成长生产调用及联合输出校准；CA5无正敏捷实测，未核出新的确定失配，不增加统一保血或输出权重。',
     '分项重放来源帧，再核交互与期限；怪物伤害/HP用当前进阶已见数据库值，不以别角色数据补正敏捷。'),
    ('66532328a585941f', '持有、启动与已建立分账',
     '5PM6JAQG6FNQ F39末试T2 decisions268455实际向无毒失落之物打BUBBLE_BUBBLE；保留对应states中真实能量、手牌和敌能力前后。F33是另一个已建立雾/触媒/群蛇并胜的场景。',
     'F33与F39的敌人、资源、组件建立与牌序同时变化，不能由一步无效或另场获胜推启动优先级。',
     '缺同起始HP、构筑、药水及完整抽序下不同启动顺序的受控整战比较与可复现收益函数；零毒目标的单步观察不足确定统一启动优先级或血价。',
     '持有/计划/实际建立分列；若变启动或构筑权重，先做按局分组、时间后移的完整固定对照。'),
    ('43a76a31ba7bdcfa', '吸取、负敏捷与SL',
     '61E2QS63Y9WU F17 T5/T6：states273504→273507见敏捷−2、双防御共6挡；敌67血/17毒，尖啸后17攻击；T7原帧继续核毒结算，首试胜局保留。',
     '本局首试赢，不是另一失败局的同抽可救活SL线路；毒继续结算不说明修改SL范围的收益。',
     '缺A10同起始HP、构筑及完整抽序的另一可核SL全战线路与生产配对；已见负敏捷/毒端点和首试胜利不足更改SL适用范围或门槛。',
     '冻结吸取前后力/敏与毒端点；保留原SL规则，等待完整另一线路再比较，不从同局尝试扩样本。'),
    ('5264153a4a4b0e5c', '召唤、成长与目标选择',
     '61E2QS63Y9WU F23 T4 states273593→273595：幻象14→2仍活，本体76→51，末10毒；T5 states273596玩家25→10，本体41、幻象仍2，敌力3→6。当前源码已有召唤数据库入口与rollout接入。',
     'focus幻象39伤/0损候选没有实打；两实体的血、毒与成长要分别计，不将focus当实际减员。',
     '缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤子项和T4端点不足证明整项完成或整战目标排序收益。',
     '核当前进阶召唤HP与攻击、各实体持续状态及复起；保留全部合法目标，同推演值并列，不强制首杀。'),
    ('bddfa690a84e03d0', '熟睡甲虫唤醒与成长',
     'DUZUBAJ3A8GP F30首试states274909/274914/274919见睡3/2/1，274923的T4滚动18、274929的T5力2/攻20，274934的T6力4/攻22；sl-attempts914—917四次失败同属一局。',
     'T4多扣敌血也可能多付玩家血；四败没有另一同抽完整胜线，不足拟合新杀序或输出血价。',
     '缺伤害唤醒、眩晕接续与A10成长的全链生产校准和同抽换序完整后继；四次相关失败不足确定新排序、胜率或血价。',
     '分别冻结睡层/伤害唤醒/眩晕后继/恢复成长；缺招式和伤害明确未知，等待完整同盘配对后再谈排序。'),
]
assert [f'silent-proposal-{x[0]}' for x in details] == dispatch['proposal_ids']
results = [{'id': f'silent-proposal-{suffix}', 'state': 'waiting', 'reason': reason}
           for suffix, title, evidence, counter, reason, validation in details]
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 本批十项策略提案复核

本批：{batch}；角色：静默猎手；已观察进阶：A10。基线：`{BASE}`。
本批为普通proposal消费：对应learn.json的task/character/worktree/runs与十个proposal_ids核同；无research_request、implementation_request或proposal_repair。普通专题请求绑定另一批，不套用本批。工作树开工干净，`git merge --no-edit main`返回Already up to date。

仅处理这十个原id，十份原Markdown逐SHA匹配，副本保存为`silent-proposal-*.original.md`；不领取其他队列，不另建重复id。六局runs.jsonl身份均为SILENT/A10，运行源码均带dirty，当前源码仅作实现现状，不能反推历史运行树完全相同。

结论：十项全部waiting。本批未找到可以凭这些证据新增实现的确定源码差错，也没有新受控整战证据支持改策略常量。既有窄实现不冒充宽请求完成；所有缺数据逐项列明，待新证据再派。授权Roy-2026-10-07-learning提供修改权限，不提供游戏事实。

## 抽取与核验

使用本树`learner/extract_evidence.py`和本批精确六局，对states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流抽取。`evidence/evidence-manifest.json`保存逐流source_size、计数与输出SHA；各封套保存原offset/bytes/SHA/行号。`integrity.json`逐条重新seek原日志核字节、JSON与显式身份，合计{analysis['total_verified_lines']}条通过。状态3432、决策3306、SL29、配置6、计划33、大脑183、局终6、fight-plans0。fight-plans为该截点选中0，不据此断言原件缺失。抽取器报告全源states/decisions/brain各2条不可解析行，均未混入入选封套；不声称全源所有行有效。抽取中途的临时只读计数不作最终验收。

`state-windows.json`保存131个相关层/回合/尝试状态窗；turn-reset分组仅用于定位，尝试数以SL原行校核，不将相关帧或重打扩成独立局。`anchor-states.json`、`anchor-decisions.json`与`turn-starts.json`保存数值所指原件。分析脚本只做证据读回，不是生产测试或新模拟。

`experience-readback.json`读取本角色经验中相关19个id；`ledger-snapshot.json`只留26个相关账本的历史折叠与更新。保留旧claim、首证、prior、status和version，本次仅经根ledger CLI追加提案/报告追溯，不增加重复support/repeat，不写shipped。未重写历史复盘或经验库。

## 当前实现的边界

读取时live快照为`{source['live_snapshot']}`。`source-readback.json`记录16个来源文件的base/live blob与SHA、live工作文件SHA及最后变更祖先布尔，`source/*.txt`保留基线原字节，`base-live-diff.patch`保留差异。只有card-model.ts、rollout-live.ts、sl/explore.ts存在Roy/Dai署名注释差异，其余这些源码逐字节相同；live这16文件均未脏改。

- `772b839f8ada31664cb764ea9ad3bdb03da27f64`已有观察范围内神化传播，后续`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`等扩展已见牌。当前只启Silent A10普通神化；未知值、附魔、重放/属性组合保留未知。
- `30ec2425012eea75f41226b31d8180b1abb837bc`同步的神化候选事实明确`actual_cast_this_fight=null`，不认证实际施放持续归属。
- `45161a51c2c6b7e4a499b13cf749c4108193bbf5`已有模拟成熟度展示，区分未比较和明确并列；不等于预算策略配对已完成。
- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`中的候选审计及`fdaf787a372880b0438e73bcac7e6d2168b038ed`单动作回执明确actual_turn/whole_plan_executed未认证。护栏与SL对比字段仍为预测。

以上六个提交均另以`existing-ancestor-check.json`核为此live快照祖先，只证明相应限定子项存在，不能作为十条整项implemented/duplicate依据。未借旧测试结果当作本批测试。
'''
sections = []
for suffix, title, evidence, counter, reason, validation in details:
    pid = f'silent-proposal-{suffix}'
    original = queue['adds'][pid]
    sections.append(f'''\n## {pid}：{title}

账本：{'、'.join(original['ledger'])}。来源任务：{original['source_task']}；实现任务：strategy-proposal。本次处置：waiting。

证据：{evidence}

反例与限制：{counter}

旧规则/新行为：本批保留当前规则和全部合法选项；不拟合权重、不改其他角色或未观察进阶。原因：{reason}

待验证的预期行为及方法：{validation} 若之后实现，固定输入不得依赖刷新知识或网络；须撤源码失败、恢复通过，再跑原沙箱入口并核角色范围。已用于发现的同局帧不作盲测；效果验证按run_id和结束时间另分组。

预期影响：只明确本条所缺证据与既有实现边界，不承诺胜率或本局改线可赢。回退：本批无生产变更；保留原提案、证据与CLI追溯，后续实现按实际源码commit回退。
''')
ending = '''
## 验证、提交和交接

本批未改生产源码、测试、知识、任务模板、参数或运维prompt；无git提交、无live合入、无eval发布号，不标implemented/duplicate/shipped。`fixes=[]`、`merged=null`。tsc、vitest、cases均null，撤源码失败/恢复通过不适用；证据一致性和祖先校验不冒作生产测试。未启动游戏、网络或LLM，未触碰其他角色知识。

运维交接：本目录`proposal.md`、`report.md`、`result.json`和十项`proposal-results.json`。请保留这十项waiting并随新局补足各自明确缺口，勿因本报告完成而关闭宽提案或学习父要求；实际经验发布和消费者采用也未在本批宣称完成。
'''
(OUT / 'proposal.md').write_text(intro + ''.join(sections) + ending)
(OUT / 'report.md').write_text(intro + '\n## 逐项处置\n\n' +
    '| 提案 | 证据及账本 | 处置与缺口 |\n|---|---|---|\n' + '\n'.join(
        f'| {r["id"]} | {evidence} 账本：{"、".join(queue["adds"][r["id"]]["ledger"])} | waiting：{r["reason"]} |'
        for r, (_, _, evidence, _, _, _) in zip(results, details)) + '\n' + ending)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch,
          'base': BASE, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'proposal': str(OUT / 'proposal.md'), 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
updates = []
ledger_ids = sorted({i for p in queue['adds'].values() for i in p['ledger']})
for ledger_id in ledger_ids:
    related = [r for r in results if ledger_id in queue['adds'][r['id']]['ledger']]
    updates.append({'id': ledger_id, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': f'{batch}：核本批六局静默A10、八流6995条原件及现源码；仅追加本批追溯，不改旧claim/首证/prior/status/version，不重复增加证据。' +
                            '；'.join(f'{r["id"]} waiting：{r["reason"]}' for r in related)})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
data = ledger_path.read_bytes()
(OUT / 'ledger-prefix-before.json').write_text(json.dumps({'path': str(ledger_path), 'bytes': len(data),
                                                         'sha256': hashlib.sha256(data).hexdigest()}, indent=2) + '\n')
print(json.dumps({'proposal_count': len(results), 'ledger_links': len(updates), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

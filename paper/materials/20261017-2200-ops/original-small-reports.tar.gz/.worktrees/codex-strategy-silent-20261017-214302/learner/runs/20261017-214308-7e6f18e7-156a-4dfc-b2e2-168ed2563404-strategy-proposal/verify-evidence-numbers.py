import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {x['line']: x for x in map(json.loads, (OUT / 'evidence/states.evidence.jsonl').open())}
decisions = {x['line']: x for x in json.loads((OUT / 'anchor-decisions.json').read_text())}
findings = []

def state(line):
    return states[line]['row']['state']

def combat(line):
    return state(line)['combat']

def player(line):
    return combat(line)['player']

def powers(entity):
    return {x['power_id']: x.get('amount') for x in entity.get('powers', [])}

def criterion(line, key):
    return json.loads(decisions[line]['row']['questions']['plan']['criteria'][key])

def add(title, lines, value):
    findings.append({'finding': title, 'state_source_lines': lines, 'observed': value})

assert (player(275564)['energy'], player(275565)['energy']) == (7, 5)
def card_values(line, card_id):
    card = next(c for c in combat(line)['hand'] if c['card_id'] == card_id)
    return card['energy_cost'], {d['name']: d['current_value'] for d in card['dynamic_values']}
for card_id, key, before, after in [('DEFEND_SILENT', 'Block', 5, 8),
                                    ('STRIKE_SILENT', 'Damage', 7, 10), ('DAGGER_SPRAY', 'Damage', 5, 7)]:
    assert (card_values(275564, card_id)[1][key], card_values(275565, card_id)[1][key]) == (before, after)
assert (card_values(275564, 'TOOLS_OF_THE_TRADE')[0], card_values(275565, 'TOOLS_OF_THE_TRADE')[0]) == (1, 0)
before, after = criterion(269706, 'plan1'), criterion(269707, 'plan1')
assert (before['damage_dealt'], before['hp_lost'], after['damage_dealt'], after['hp_lost']) == (43, 14, 51, 13)
assert combat(275679)['enemies'][0]['current_hp'] - combat(275687)['enemies'][0]['current_hp'] == 51
assert player(275679)['current_hp'] - player(275687)['current_hp'] == 13
add('神化的本角色可见变化及F43端点', [275564, 275565, 275679, 275680, 275686, 275687],
    {'forecast_before': [43, 14], 'forecast_after': [51, 13], 'actual_endpoints': [51, 13]})

assert decisions[270216]['row']['fingerprint'] == decisions[270282]['row']['fingerprint']
assert [player(n)['current_hp'] for n in [276208, 276212, 276274, 276278]] == [47, 44, 47, 32]
assert [combat(n)['enemies'][0]['current_hp'] for n in [276208, 276212, 276274, 276278]] == [326, 316, 326, 309]
assert decisions[270216]['row']['rollout']['samples'] == 8
assert decisions[270282]['row']['rollout']['samples'] == 24
assert '0/24' in decisions[270282]['row']['sl_explore']['numbers']['original']
assert '5/24' in decisions[270282]['row']['sl_explore']['numbers']['replacement']
add('同指纹SL实付代价与不同样本预算', [276208, 276212, 276274, 276278],
    {'actual_hp_losses': [3, 15], 'actual_enemy_hp_losses': [10, 17], 'delta': [12, 7],
     'first_and_third_samples': [8, 24], 'third_question_deaths': ['0/24', '5/24']})

mc = decisions[269748]['row']['potions']['random'][0]
assert (mc['samples'], mc['requested'], mc['ms']) == (1, 12, 707)
assert decisions[269748]['row']['rollout']['horizon'] == 1
assert decisions[269748]['row']['rollout']['best'] is None
mc2 = decisions[269754]['row']['potions']['random'][0]
assert (mc2['samples'], mc2['requested'], mc2['ms']) == (12, 12, 11)
assert decisions[269770]['row']['rollout']['tied'] == ['plan2', 'plan3', 'plan4']
assert [(criterion(269770, k)['hp_lost'], criterion(269770, k)['damage_dealt'])
        for k in ('plan1', 'plan2')] == [(13, 24), (31, 32)]
add('退化、成熟度与真正并列分开', [], {'decision_lines': [269748, 269754, 269770],
    'mc': [707, 1, 12], 'later_mc': [11, 12, 12], 'tied': ['plan2', 'plan3', 'plan4']})

assert [powers(combat(n)['enemies'][0]).get('STRENGTH_POWER', 0) for n in (273238, 273252, 273263)] == [0, 4, 8]
assert [combat(n)['enemies'][0]['intents'][0]['total_damage'] for n in (273238, 273252, 273263)] == [11, 15, 19]
assert (player(273268)['current_hp'], player(273268)['block'], combat(273268)['enemies'][0]['intents'][0]['total_damage']) == (2, 10, 14)
add('加压成长与虚弱端点', [273238, 273252, 273263, 273268, 273269],
    {'strength': [0, 4, 8], 'jet': [11, 15, 19], 'final_hp_block_attack': [2, 10, 14]})

assert powers(player(273504))['DEXTERITY_POWER'] == -2
assert player(273507)['block'] == 6
assert combat(273507)['enemies'][0]['current_hp'] - combat(273508)['enemies'][0]['current_hp'] == 17 + 16
add('负敏捷挡与已结算毒', [273504, 273507, 273508], {'dexterity': -2, 'block': 6, 'poison_hp_loss': 33})

assert (player(274379)['energy'], player(274380)['energy']) == (5, 4)
assert combat(274379)['enemies'] == combat(274380)['enemies']
assert 'POISON_POWER' not in powers(combat(274379)['enemies'][0])
assert 'NOXIOUS_FUMES_POWER' not in powers(player(274379))
add('无毒目标冒泡的一步实况', [274379, 274380], {'energy': [5, 4], 'enemy_state_unchanged': True})

assert combat(273595)['enemies'][0]['current_hp'] == 2
assert (player(273593)['current_hp'], player(273596)['current_hp']) == (25, 10)
assert powers(combat(273596)['enemies'][0])['STRENGTH_POWER'] == 6
add('幻象未退场和航行成长', [273593, 273595, 273596], {'illusion_hp': 2, 'player_hp': [25, 10], 'strength': 6})

for n, amount in [(274909, 3), (274914, 2), (274919, 1)]:
    enemy = next(e for e in combat(n)['enemies'] if e['enemy_id'] == 'SLUMBERING_BEETLE')
    assert powers(enemy)['SLUMBER_POWER'] == amount
for n, strength, attack in [(274923, 0, 18), (274929, 2, 20), (274934, 4, 22)]:
    enemy = next(e for e in combat(n)['enemies'] if e['enemy_id'] == 'SLUMBERING_BEETLE')
    assert powers(enemy).get('STRENGTH_POWER', 0) == strength
    assert enemy['intents'][0]['total_damage'] == attack
add('睡层与醒后成长的本批范围', [274909, 274914, 274919, 274923, 274929, 274934],
    {'sleep': [3, 2, 1], 'later_strength': [0, 2, 4], 'later_attack': [18, 20, 22]})
(OUT / 'verified-findings.json').write_text(json.dumps(findings, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'evidence_checks': '通过', 'finding_groups': len(findings),
                  'production_tests': None, 'new_simulations': 0}, ensure_ascii=False))

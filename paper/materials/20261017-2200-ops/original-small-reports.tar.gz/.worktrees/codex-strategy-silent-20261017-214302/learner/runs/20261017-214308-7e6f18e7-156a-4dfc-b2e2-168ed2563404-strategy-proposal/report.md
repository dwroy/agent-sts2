# 本批十项策略提案复核

本批：20261017-214302-strategy-proposal；角色：静默猎手；已观察进阶：A10。基线：`1a677fd8b16bcd538f36a64554b7393b3be6f9e0`。
本批为普通proposal消费：对应learn.json的task/character/worktree/runs与十个proposal_ids核同；无research_request、implementation_request或proposal_repair。普通专题请求绑定另一批，不套用本批。工作树开工干净，`git merge --no-edit main`返回Already up to date。

仅处理这十个原id，十份原Markdown逐SHA匹配，副本保存为`silent-proposal-*.original.md`；不领取其他队列，不另建重复id。六局runs.jsonl身份均为SILENT/A10，运行源码均带dirty，当前源码仅作实现现状，不能反推历史运行树完全相同。

结论：十项全部waiting。本批未找到可以凭这些证据新增实现的确定源码差错，也没有新受控整战证据支持改策略常量。既有窄实现不冒充宽请求完成；所有缺数据逐项列明，待新证据再派。授权Roy-2026-10-07-learning提供修改权限，不提供游戏事实。

## 抽取与核验

使用本树`learner/extract_evidence.py`和本批精确六局，对states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流抽取。`evidence/evidence-manifest.json`保存逐流source_size、计数与输出SHA；各封套保存原offset/bytes/SHA/行号。`integrity.json`逐条重新seek原日志核字节、JSON与显式身份，合计6995条通过。状态3432、决策3306、SL29、配置6、计划33、大脑183、局终6、fight-plans0。fight-plans为该截点选中0，不据此断言原件缺失。抽取器报告全源states/decisions/brain各2条不可解析行，均未混入入选封套；不声称全源所有行有效。抽取中途的临时只读计数不作最终验收。

`state-windows.json`保存131个相关层/回合/尝试状态窗；turn-reset分组仅用于定位，尝试数以SL原行校核，不将相关帧或重打扩成独立局。`anchor-states.json`、`anchor-decisions.json`与`turn-starts.json`保存数值所指原件。分析脚本只做证据读回，不是生产测试或新模拟。

`experience-readback.json`读取本角色经验中相关19个id；`ledger-snapshot.json`只留26个相关账本的历史折叠与更新。保留旧claim、首证、prior、status和version，本次仅经根ledger CLI追加提案/报告追溯，不增加重复support/repeat，不写shipped。未重写历史复盘或经验库。

## 当前实现的边界

读取时live快照为`72ce99f6ddc37bfe30af8082b0f8f32027ec95d0`。`source-readback.json`记录16个来源文件的base/live blob与SHA、live工作文件SHA及最后变更祖先布尔，`source/*.txt`保留基线原字节，`base-live-diff.patch`保留差异。只有card-model.ts、rollout-live.ts、sl/explore.ts存在Roy/Dai署名注释差异，其余这些源码逐字节相同；live这16文件均未脏改。

- `772b839f8ada31664cb764ea9ad3bdb03da27f64`已有观察范围内神化传播，后续`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`等扩展已见牌。当前只启Silent A10普通神化；未知值、附魔、重放/属性组合保留未知。
- `30ec2425012eea75f41226b31d8180b1abb837bc`同步的神化候选事实明确`actual_cast_this_fight=null`，不认证实际施放持续归属。
- `45161a51c2c6b7e4a499b13cf749c4108193bbf5`已有模拟成熟度展示，区分未比较和明确并列；不等于预算策略配对已完成。
- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`中的候选审计及`fdaf787a372880b0438e73bcac7e6d2168b038ed`单动作回执明确actual_turn/whole_plan_executed未认证。护栏与SL对比字段仍为预测。

以上六个提交均另以`existing-ancestor-check.json`核为此live快照祖先，只证明相应限定子项存在，不能作为十条整项implemented/duplicate依据。未借旧测试结果当作本批测试。

## 逐项处置

| 提案 | 证据及账本 | 处置与缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | VLZ6CCT8AQ0A F35 T1：states275564→275565，能量7→5，防御5→8、打击7→10、匕首雨5→7、工具1费→0；F43 T1：states275679→275687，decisions269706/269707的43伤/14损→51伤/13损得到原帧端点51/13支持。 账本：silent-0237、silent-0238 | waiting：缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属及完整生产消费者认证；已有A10普通神化窄升级传播和候选事实字段不等于整项实现。 |
| silent-proposal-f2bfceddb1898dca | VLZ6CCT8AQ0A F45 T1 decisions269748：MC707ms、1/12；rollout696ms、horizon1/samples1/best=null。269754：MC11ms、12/12，rollout1393ms、horizon5/samples3。T4 decisions269770：plan2/3/4明确并列，31损/32伤，plan1为13损/24伤。 账本：silent-0106、silent-0019、silent-0201 | waiting：缺模型充分覆盖下同起点、同随机池、同总预算的MC分配策略配对与样本成熟度曲线；707ms单题及后来12/12不同题不能确定新预算、留药常量或固定目标。 |
| silent-proposal-283a164780d11e69 | 同89354805ee4d7e77的VLZ6CCT8AQ0A F35 T1、F43 T1/T2和F45 T1；两份原Markdown均按队列SHA核回。 账本：silent-0237、silent-0238 | waiting：与89354805ee4d7e77同源，仍缺实际施放持续身份及后续生产消费认证；不以同题提案或既有窄实现将整项登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | VLZ6CCT8AQ0A F43 T1升级勒紧6/尖啸8；F43 T2/T3为减力、步法与现场属性组合；F45 T4/T5为当轮损伤、实际成长、零覆甲和残毒分账。原提案关联14账本、15经验。 账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019 | waiting：缺十五机制逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者的固定校准闭环；本批未定位新的确定源码失配，局部机制代码不足证明整条复合提案完成。 |
| silent-proposal-e5b87be50f28f311 | 8JRE1C4H4Z2W F33首/三试T2 decisions270216/270282指纹相同。原始状态首试276208→276212为47→44血、326→316敌血；三试276274→276278为47→32血、326→309敌血，差12血/7伤。第三次同题两候选死亡0/24与5/24；首试另为8样本，不能混成24。第二次T5 decisions270264留有护栏前16损/43伤及后4损/25伤差。 账本：silent-0079、silent-0021、silent-0125、silent-0018 | waiting：已有Jev原答、护栏后、SL后及单动作派发审计；仍缺跨抽牌、选牌、生成、药水重问与SL的候选持续归属和完整实际收益生产认证，不能将端点或前缀视为整线执行。 |
| silent-proposal-49632bc4878fb597 | CA5KE8GFJ9X2 F13 T1/T3/T5：states273238/273252/273263见敌力0/4/8、喷水11/15/19；T5中和后14，玩家2血10挡，完整需损4，不能以实扣至0的2替代完整代价。 账本：silent-0005、silent-0231 | waiting：缺逐来源冻结的力量逐击、正负敏捷、虚弱与蚌独立成长生产调用及联合输出校准；CA5无正敏捷实测，未核出新的确定失配，不增加统一保血或输出权重。 |
| silent-proposal-66532328a585941f | 5PM6JAQG6FNQ F39末试T2 decisions268455实际向无毒失落之物打BUBBLE_BUBBLE；保留对应states中真实能量、手牌和敌能力前后。F33是另一个已建立雾/触媒/群蛇并胜的场景。 账本：silent-0021、silent-0009 | waiting：缺同起始HP、构筑、药水及完整抽序下不同启动顺序的受控整战比较与可复现收益函数；零毒目标的单步观察不足确定统一启动优先级或血价。 |
| silent-proposal-43a76a31ba7bdcfa | 61E2QS63Y9WU F17 T5/T6：states273504→273507见敏捷−2、双防御共6挡；敌67血/17毒，尖啸后17攻击；T7原帧继续核毒结算，首试胜局保留。 账本：silent-0030、silent-0027 | waiting：缺A10同起始HP、构筑及完整抽序的另一可核SL全战线路与生产配对；已见负敏捷/毒端点和首试胜利不足更改SL适用范围或门槛。 |
| silent-proposal-5264153a4a4b0e5c | 61E2QS63Y9WU F23 T4 states273593→273595：幻象14→2仍活，本体76→51，末10毒；T5 states273596玩家25→10，本体41、幻象仍2，敌力3→6。当前源码已有召唤数据库入口与rollout接入。 账本：silent-0039、silent-0209 | waiting：缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤子项和T4端点不足证明整项完成或整战目标排序收益。 |
| silent-proposal-bddfa690a84e03d0 | DUZUBAJ3A8GP F30首试states274909/274914/274919见睡3/2/1，274923的T4滚动18、274929的T5力2/攻20，274934的T6力4/攻22；sl-attempts914—917四次失败同属一局。 账本：silent-0128、silent-0079 | waiting：缺伤害唤醒、眩晕接续与A10成长的全链生产校准和同抽换序完整后继；四次相关失败不足确定新排序、胜率或血价。 |

## 验证、提交和交接

本批未改生产源码、测试、知识、任务模板、参数或运维prompt；无git提交、无live合入、无eval发布号，不标implemented/duplicate/shipped。`fixes=[]`、`merged=null`。tsc、vitest、cases均null，撤源码失败/恢复通过不适用；证据一致性和祖先校验不冒作生产测试。未启动游戏、网络或LLM，未触碰其他角色知识。

运维交接：本目录`proposal.md`、`report.md`、`result.json`和十项`proposal-results.json`。请保留这十项waiting并随新局补足各自明确缺口，勿因本报告完成而关闭宽提案或学习父要求；实际经验发布和消费者采用也未在本批宣称完成。

## 最终机械核验

八组数值证据一致性检查通过，仅重读原帧与已有数字，不运行生产模拟。根ledger CLI实际退出0、追加26条原id的where/note追溯；原字节前缀SHA保持，追加行逐offset/bytes/SHA保存于completion-check.json，未触碰claim/evidence/首证/prior/status/version。gitleaks退出0、无泄漏。最终HEAD等于base，工作树干净，源码/知识差异为零。没有生产测试、源码撤回实验、git提交、合入或发布号；原失败工具调用未用于成功测试结论。

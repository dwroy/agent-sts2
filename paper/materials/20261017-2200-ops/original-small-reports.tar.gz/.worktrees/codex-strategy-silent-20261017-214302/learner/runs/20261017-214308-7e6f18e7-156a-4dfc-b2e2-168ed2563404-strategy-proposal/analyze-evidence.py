import collections
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract_evidence', WORKTREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
runs = set(dispatch['runs'])
rows = {}
integrity = []
for stream in manifest:
    path = OUT / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    selected = []
    counts = collections.Counter()
    with (Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')).open('rb') as source:
        for line in path.open():
            envelope = json.loads(line)
            assert envelope['run_id'] in runs
            source.seek(envelope['offset'])
            raw = source.read(envelope['bytes'])
            assert len(raw) == envelope['bytes']
            assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
            assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
            row = json.loads(raw)
            assert row == envelope['row']
            assert extractor.run_identity(row) == envelope['run_id']
            counts[envelope['run_id']] += 1
            selected.append(envelope)
    assert dict(counts) == {r: n for r, n in stream['counts'].items() if n}
    integrity.append({'stream': stream['stream'], 'verified_lines': len(selected),
                      'source_size': stream['source_size'], 'counts': stream['counts'],
                      'output_sha256': stream['output_sha256'], 'offset_bytes_sha_json_identity': True})
    rows[stream['stream']] = selected
(OUT / 'integrity.json').write_text(json.dumps(integrity, ensure_ascii=False, indent=2) + '\n')

def reference(envelope):
    return {k: envelope[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}

def compact(envelope):
    s = envelope['row']['state']
    c, run = s.get('combat') or {}, s.get('run') or {}
    p = c.get('player') or {}
    return {'ref': reference(envelope), 'ts': envelope['row'].get('observed_ts'),
            'floor': run.get('floor'), 'turn': s.get('turn'), 'screen': s.get('screen'),
            'hp': p.get('current_hp'), 'max_hp': p.get('max_hp'), 'block': p.get('block'),
            'energy': p.get('energy'),
            'powers': {x['power_id']: x.get('amount') for x in p.get('powers', [])},
            'deck_upgraded': sum(x.get('upgraded') is True for x in run.get('deck', [])),
            'hand': c.get('hand', []),
            'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'name', 'current_hp', 'max_hp',
                                               'block', 'move_id', 'powers', 'intents')}
                        for e in c.get('enemies', [])]}

target_floors = {'VLZ6CCT8AQ0A': {35, 43, 45}, '8JRE1C4H4Z2W': {17, 33},
                 'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 39},
                 '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}
groups = collections.defaultdict(list)
by_line = {}
for envelope in rows['states']:
    s = envelope['row']['state']
    run = s.get('run') or {}
    assert str(run.get('character_id')).lower() == 'silent'
    assert run.get('ascension') == 10
    by_line[envelope['line']] = envelope
    if run.get('floor') in target_floors[envelope['run_id']] and s.get('combat') and isinstance(s.get('turn'), int):
        groups[(envelope['run_id'], run['floor'])].append(envelope)
windows = []
starts = []
for (run_id, floor), group in groups.items():
    attempt, last_turn = 1, 0
    turn_groups = collections.defaultdict(list)
    for envelope in group:
        turn = envelope['row']['state']['turn']
        if turn < last_turn:
            attempt += 1
        last_turn = turn
        turn_groups[(attempt, turn)].append(envelope)
    for (attempt, turn), turn_group in turn_groups.items():
        ready = [x for x in turn_group if x['row']['state'].get('screen') == 'COMBAT'
                 and (x['row']['state']['combat'].get('player') or {}).get('energy', 0) > 0
                 and x['row']['state']['combat'].get('hand')]
        first = ready[0] if ready else turn_group[0]
        record = {'run_id': run_id, 'floor': floor, 'attempt_by_turn_reset': attempt, 'turn': turn,
                  'first': compact(first), 'last': compact(turn_group[-1]),
                  'all_source_lines': [x['line'] for x in turn_group]}
        windows.append(record)
        starts.append({'run_id': run_id, 'floor': floor, 'attempt': attempt, 'turn': turn,
                       'source_line': first['line'], 'hp': record['first']['hp'],
                       'enemies': [{'id': e['enemy_id'], 'hp': e['current_hp'], 'move': e['move_id']}
                                   for e in record['first']['enemies']]})
(OUT / 'state-windows.json').write_text(json.dumps(windows, ensure_ascii=False, indent=2) + '\n')
(OUT / 'turn-starts.json').write_text(json.dumps(starts, ensure_ascii=False, indent=2) + '\n')

selected_lines = {275564, 275565, 275679, 275680, 275686, 275687, 275688, 275722,
                  273263, 273268, 273269, 273504, 273507, 273508, 273593, 273595, 273596}
(OUT / 'anchor-states.json').write_text(json.dumps([compact(by_line[x]) for x in sorted(selected_lines)
                                                  if x in by_line], ensure_ascii=False, indent=2) + '\n')
decision_lines = {269706, 269707, 269748, 269754, 269755, 269770, 270216, 270264, 270282}
decisions = [x for x in rows['decisions'] if x['line'] in decision_lines]
assert {x['line'] for x in decisions} == decision_lines
(OUT / 'anchor-decisions.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')

summary = {'streams': integrity, 'total_verified_lines': sum(x['verified_lines'] for x in integrity),
           'relevant_turn_windows': len(windows), 'anchor_decisions': len(decisions),
           'role_check': '六局全部静默猎手A10',
           'attempt_note': 'turn-reset分组仅定位状态窗，SL尝试数另以原sl-attempts核对；同局尝试不作独立样本'}
(OUT / 'evidence-analysis.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_lines': summary['total_verified_lines'],
                  'streams': {x['stream']: x['verified_lines'] for x in integrity},
                  'turn_windows': len(windows)}, ensure_ascii=False))

from pathlib import Path
import hashlib, json, os, re, subprocess, tarfile

root = Path.cwd()
p = root / 'ops/codex-ops/record-staging/20261016-0637'
pub = root / 'paper/materials/20261016-0637-ops'
pub.mkdir(exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
exec((root / 'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text())
canonical = json.loads((root / 'ops/codex-ops/learn.json').read_text())['batches']
ledger = root / 'paper/materials/learning/ledger.jsonl'
all_rows = []
records = []
with tarfile.open(pub / 'original-strategy-artifacts.tar.gz', 'w:gz') as archive:
    artifact_manifest = []
    for bid, count in [('20261016-061302-strategy-proposal', 46), ('20261016-061302-s2-strategy-proposal', 24)]:
        data = canonical[bid]
        report = data['report']
        scratch = Path(report['report']).parent
        wt = Path(data['worktree'])
        output = root / ('ops/codex-ops/learner/' + bid + '.out')
        errors = output.with_suffix('.err')
        assert data['state'] == 'done' and data['rc'] == 0 and data['merged'] is None
        assert not data['proposal_audit_errors'] and len(data['proposal_ids']) == 10
        assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' and x['reason'] for x in report['proposal_results'])
        assert {x['id'] for x in report['proposal_results']} == set(data['proposal_ids'])
        assert report['fixes'] == [] and report['implementation_domains'] == []
        assert report['tests'] == dict(tsc=None, vitest=None, cases=None)
        head = subprocess.check_output(['git', '-C', str(wt), 'rev-parse', 'HEAD'], text=True).strip()
        status = subprocess.check_output(['git', '-C', str(wt), 'status', '--porcelain', '--untracked-files=no'], text=True)
        assert head == report['base'] and status == ''
        native = runtime(bid, report, output.read_text(), worktree=wt)
        if count == 46:
            receipts = json.loads((scratch / 'ledger-owned-events.json').read_text())
            final = json.loads((scratch / 'completion-validation.json').read_text())
            assert final['ledger_owned_events'] == 46 and final['material_checks'] == 63 and final['offline_consumer_requests'] == 12
            original_cli = json.loads((scratch / 'ledger-validation.json').read_text())
            assert original_cli['cli_returncode'] == 0 and original_cli['owned_old_fields_preserved']
            consumers = json.loads((scratch / 'consumer-summary.json').read_text())
            assert len(consumers) == 12 and all(x['rc'] == 0 and x['certified_candidates'] == 0 for x in consumers)
            scope = dict(raw_rows=22424, silent_A9_runs=3, silent_A10_runs=12, offline_requests=12, actions=8622, segments=1883, adjacent_endpoints=3109, verified_turn_endpoints=431, unknown_turns=974, material_checks=63, full_candidate_results='null; no full-candidate certification')
        else:
            original_cli = json.loads((scratch / 'ledger-receipt.json').read_text())
            receipts = original_cli['owned_updates']
            final = json.loads((scratch / 'final-validation.json').read_text())
            assert final['ledger_owned_updates'] == 24 and original_cli['rc'] == 0 and original_cli['physical_prefix_preserved']
            assert all(original_cli[k] == 0 for k in ['new_claims', 'new_evidence', 'status_changes', 'shipped_changes'])
            checks = json.loads((scratch / 'evidence-checks.json').read_text())
            assert checks['passed'] == 29 and checks['failed'] == 0
            consumers = json.loads((scratch / 'audit-summary.json').read_text())
            assert len(consumers) == 4 and all(x['certified_full_candidates'] == 0 for x in consumers)
            scope = dict(raw_rows=6060, silent_A5_runs=1, silent_A10_runs=4, offline_requests=4, actions=2101, segments=483, adjacent_endpoints=594, verified_turn_endpoints=70, unknown_turns=282, material_checks=29, resource_windows=84, full_candidate_results='null; no full-candidate certification')
        assert len(receipts) == count
        readback = []
        with ledger.open('rb') as handle:
            for item in receipts:
                handle.seek(item['offset'])
                raw = handle.read(item['bytes'])
                assert sha(raw) == item['sha256'] and raw.endswith(b'\n')
                row = json.loads(raw)
                assert row['op'] == 'update' and set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'}
                assert str(scratch) in json.dumps(row, ensure_ascii=False)
                if 'row' in item: assert row == item['row']
                all_rows.append(raw)
                readback.append(dict(offset=item['offset'], bytes=len(raw), sha256=sha(raw), id=row['id'], trace_only=True))
        for f in sorted(scratch.iterdir()):
            if not f.is_file() or f.stat().st_size > 2_000_000 or f.suffix not in ['.json', '.jsonl', '.txt', '.md', '.patch', '.log', '.stdout', '.stderr']:
                continue
            if f.name.startswith(('audit-input-', 'evidence', 'source-code', 'resource-chain-')):
                continue
            raw = f.read_bytes()
            member = bid + '/' + f.name
            archive.add(f, arcname=member, recursive=False)
            artifact_manifest.append(dict(source=str(f.relative_to(root)), member=member, bytes=len(raw), sha256=sha(raw)))
        for f in [output, errors]:
            raw = f.read_bytes()
            archive.add(f, arcname=bid + '/' + f.name, recursive=False)
            artifact_manifest.append(dict(source=str(f.relative_to(root)), member=bid + '/' + f.name, bytes=len(raw), sha256=sha(raw)))
        records.append(dict(batch=bid, source_report=str(scratch.relative_to(root) / 'report.md'), source_report_sha256=sha((scratch / 'report.md').read_bytes()), canonical_report=report, original_no_change_disposition=data['no_change_proposals'], unchanged_source=dict(head=head, tracked_status=status), native=native, material_scope=scope, ledger_cli_rows=readback, original_cli_receipt=str((scratch / ('ledger-validation.json' if count == 46 else 'ledger-receipt.json')).relative_to(root)), original_cli_receipt_sha256=sha((scratch / ('ledger-validation.json' if count == 46 else 'ledger-receipt.json')).read_bytes()), tests='not run: no source changes', release=None, no_new_task_or_parent=True, limitations='Existing scoped implementations do not close broad proposals; raw endpoint checks and offline consumers are not production calibration or benefit. Preserve original probes, missing identities, capped damage and unknown successors.'))
assert len(all_rows) == 70 and len(set(all_rows)) == 70
(p / 'owned-strategy-ledger.jsonl').write_bytes(b''.join(all_rows))
(pub / 'strategy-ledger-row-bindings.json').write_text(json.dumps([dict(batch=x['batch'], rows=x['ledger_cli_rows']) for x in records], ensure_ascii=False, indent=2) + '\n')
(pub / 'strategy-readback.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
(pub / 'original-strategy-artifact-manifest.json').write_text(json.dumps(artifact_manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(strategy_batches=2, waiting=20, owned_trace_rows=70, no_source_changes=True, no_tests_or_merge=True, archived_artifacts=len(artifact_manifest))))

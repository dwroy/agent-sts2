from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, tarfile

sys.dont_write_bytecode = True
r = Path.cwd()
p = r / 'ops/codex-ops/record-staging/20261016-0637'
pub = r / 'paper/materials/20261016-0637-ops'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda f: json.loads(f.read_text())
def write(f, x): f.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
def git(*a): return subprocess.check_output(['git', *a], stderr=subprocess.PIPE)
assert not (p / 'own-appends.json').exists()
deployment = load(pub / 'publication.json')
base = git('rev-parse', 'HEAD').decode().strip()
assert base == deployment['main'] and not git('diff', '--cached', '--name-only').strip()
rid = deployment['release_id']
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(at, flush=True)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x])
ledger = r / 'paper/materials/learning/ledger.jsonl'
before = ledger.read_bytes()
before_items = fold(before)
assert before_items['silent-0491']['status'] == 'proposed'
request = dict(id='silent-0491', by='ops:codex', status='shipped', version='S1.boss-calibration20', where=dict(commits=[deployment['source'], deployment['behavior_commit'], deployment['original_publication'], deployment['live'], deployment['main']]), note=f'原校准20实际发布经ops登记{rid}；原050119宿主精确树6f1f2cb003239b798ee345c9137f4867acd96162 tsc/vitest0，488文件4915通过2跳过；新增live仅versions元数据，生产/data与原绿树不变。87源叶精确main/live绑定。仅冻结模型107调参/460验证，不声称70输入不同的当前生产已重校准、自然采用或收益；THE_INSATIABLE B2按原1.3阈值撤可信，旧0484历史/status/version不变。实际消费者和宽学习父保持待验。回执paper/materials/20261016-0637-ops/publication.json。')
(p / 'shipped-input.json').write_text(json.dumps(request, ensure_ascii=False) + '\n')
result = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'update'], input=(json.dumps(request, ensure_ascii=False) + '\n').encode(), capture_output=True)
(pub / 'shipped-cli.stdout').write_bytes(result.stdout)
(pub / 'shipped-cli.stderr').write_bytes(result.stderr)
assert result.returncode == 0
after = ledger.read_bytes()
assert after.startswith(before)
own_ops = [raw for raw in after[len(before):].splitlines(keepends=True) if json.loads(raw).get('note') == request['note'] and json.loads(raw).get('by') == request['by']]
assert len(own_ops) == 1
own_raw = own_ops[0]
after_items = fold(after)
assert after_items['silent-0491']['status'] == 'shipped' and after_items['silent-0491']['version'] == deployment['name']
assert all(after_items['silent-0484'].get(k) == before_items['silent-0484'].get(k) for k in ['claim', 'first_run', 'prior', 'status', 'version', 'evidence'])
(p / 'owned-ops-ledger.jsonl').write_bytes(own_raw)
write(pub / 'shipped-cli-receipt.json', dict(at=at, cli='learner/ledger.py update', exit_code=0, id='silent-0491', version=deployment['name'], release_id=rid, status='shipped', row=dict(offset=after.index(own_raw, len(before)), bytes=len(own_raw), sha256=sha(own_raw)), prior_0484_claim_evidence_status_version_preserved=True, actual_natural_consumer='pending', no_other_role_ack=True))

notice_id = '676bee9f38912ae4c39c596a'
watcher_dir = r / ('paper/materials/20261016-watcher-notice-' + notice_id)
watcher = load(watcher_dir / 'watcher-readback.json')
roles = []
for stage, receipt_name, binding in [('watcher_received', 'watcher_received.receipt.json', 'native_read'), ('roy_notified', 'roy_notified.receipt.json', 'native_user_visible_reply')]:
    receipt_path = watcher_dir / receipt_name
    receipt = load(receipt_path)
    assert receipt['notice_id'] == notice_id and receipt['stage'] == stage and receipt['actor'] == 'watcher'
    assert receipt['session_id'] == '01a13dcd-83d4-7c63-b233-f93cf878ecf4' and not receipt['CLI_invoked'] and not receipt['Roy_ACK_created']
    evidence_path = r / receipt['evidence']['path']
    raw = evidence_path.read_bytes()
    assert sha(raw) == receipt['evidence']['sha256'] == watcher[binding]['sha256']
    bound = watcher[binding]
    with Path(bound['path']).open('rb') as f:
        f.seek(bound['offset'])
        assert f.read(bound['bytes']) == raw
    value = json.loads(raw)
    if stage == 'roy_notified':
        assert value['payload']['role'] == 'assistant'
        assert '1.316' in raw.decode() and '44' in raw.decode() and notice_id in raw.decode()
    roles.append(dict(stage=stage, original_actor='watcher', original_receipt=str(receipt_path.relative_to(r)), original_receipt_sha256=sha(receipt_path.read_bytes()), native_evidence=receipt['evidence'], original_native_binding=bound, ops_observed_actual_evidence=True, formal_CLI_ack='pending existing root-event path guard', Roy_ACK_created=False))
with tarfile.open(pub / 'original-independent-role-receipts.tar.gz', 'w:gz') as archive:
    for f in sorted(watcher_dir.iterdir()):
        if f.is_file(): archive.add(f, arcname=f.name, recursive=False)
write(pub / 'ops-independent-role-evidence-readback.json', dict(at=at, observer='ops:codex', notice_id=notice_id, roles=roles, actual_read_and_user_visible_notification=True, formal_registry='pending feature root-event guard; original rejection preserved', no_role_cli_called=True, no_resend=True, no_Roy_ack=True))
pending_delivery = r / ('ops/codex-ops/pending-deliveries/' + notice_id + '.json')
pending = load(pending_delivery)
pending.update(watcher_received=True, roy_notified=True, ops_readback=str((pub / 'ops-independent-role-evidence-readback.json').relative_to(r)), role_CLI_registration='pending original root-event guard; no substitute ACK', Roy_ack=False)
write(pending_delivery, pending)

notice = f'\n- {at} [ops校准20正式编号/宿主验收闭环] 实际行为e138b036a79709f6217272e631324fd3e77e2bff统一登记{rid}（S1.boss-calibration20），原source89b6391845eb28b774c23db6f4466160c25876ba/publication4dfac2702bf1ce63199d4579c7d5cda136f13d3d/tree6f1f2cb003239b798ee345c9137f4867acd96162保持；本次锁内main窄同步87数据/报告/归档叶→{deployment["main"]}，live仅补versions元数据→{deployment["live"]}/tree{deployment["tree"]}，所有其他生产/知识叶及并行脏记录逐SHA保持。旧规则：校准19中THE_INSATIABLE B2 n43/打穿比1.296可信；新规则：同冻结模型下n44/1.316超过原1.3，撤B2可信（7→6），B3仍6且本Boss低；阈值、切点、Platt、模型和开关不变。证据VNSXWCWXR3VW A10 F33试1 T1—7实际胜及silent-0484原contradict，0491现经CLI shipped/{deployment["name"]}，旧0484claim/首证/prior/status/version不变。预期更新冻结模型验证表可信分类，不称当前生产已校准或胜率改善：22新实际结局16胜6死、固定107调参/460验证，70当前生产输入差/F49低可信/A0-9独立验证不足保持。原唯一050119宿主full精确6f树tsc0/vitest0：488文件4915通过2跳过；新live仅元数据不借为新树另次full，不重复检查。回退：持原live锁仅逆回本次boss-trust数据，保其他刷新/归档，真实行为回退另分号。watcher本人接收及Roy可见原生消息已由ops逐字节核原676bee9f回执；不是代角色ACK，程序登记仍受原root事件守卫阻挡，唯一非阻塞bug保持，未重发。自然消费者与宽父继续pending。回执paper/materials/20261016-0637-ops/。\n'
decision = f'\n- {at} 运维codex：0637原三事件闭环。原050119校准20宿主精确4dfa/tree6f1f2cb003239b798ee345c9137f4867acd96162完整tsc+vitest exit0，488文件4915通过2跳过/764.84s，canonical checks_pending=false；按0625唯一pending在原live锁核实际祖先与完整registry后登记实际e138行为为{rid}，保原S1.boss-calibration20 name/family/commit/source及旧列表/顺序。main仅精确87原数据/档案叶+versions并绑定source89b祖先→{deployment["main"]}；live仅versions登记→{deployment["live"]}/tree{deployment["tree"]}，生产/data逐blob等于原6f绿树，知识刷新与并行脏记录保持，不重合live/源full/宿主full或新派模型。0491经原CLI shipped，0484原43场claim/status/version/反证历史不改。首次归档gitleaks命中战斗key5X2GHKJ89PN1:48:4:7776970478，核原provenance角色/楼层/试次为复合标识，保首次1 finding与精确fingerprint排除后0，不改源数据或规则。原必要反证watcher本人接收/Roy可见原生字节及独立回执现已实际读回，CLI注册仍被原root事件范围守卫阻挡，旧唯一bug/pending保持，不代填角色或用户ACK、不重发。两原061302策略各十项done0/全waiting、base c98e27e未改、mergednull/testsnull；原生Sol6.1/xhigh/原沙箱/input/lease逐核，主批22424原行/12离线输入/63材料检查与S2 6060原行/4输入/29检查分账，整候选null/未知/原路径与夹具失败保留，不冒生产校准。46+24原CLI仅where/note共70行精确读回并只纳所属追溯，旧claim/证据/先验/status/version保持，不另造源码/版本/研究/反证或关闭父项。当前对局、账号home模型prompt预算均未改；记录paper/materials/20261016-0637-ops/。\n'
handoff = f'\n- {at} 原050119校准20等待已接续：宿主精确4dfa/6f完整0（488文件4915过2跳过）后锁内登记{rid}/实际e138，source89b窄87叶main祖先同步{deployment["main"]}，live元数据登记{deployment["live"]}/tree{deployment["tree"]}，0491 CLI shipped；0484旧43场历史/反证/版本保持。仅versions元数据新差，生产/data同原绿树，不重复full。0625 pending-integrations已标registration/sync/shipped/host完成，下一自然可信表/脑payload消费者仍pending。token676bee9f watcher实际接收与Roy可见原生告知已逐字节核独立回执，role CLI仍因旧root scratch/event guard缺口pending；infra-feature-root-event-notice-path原项保持，不代ACK/重派或假桥。两061302策略20项继续waiting、无源码，仅70原CLI追溯纳入；所有宽学习/校准/0332父保持。\n'
appends = {'paper/materials/decision-log.md': decision, 'ops/inbox-dev.md': notice, 'notes/for-roy.md': notice, 'notes/ops-handoff.md': handoff}
write(p / 'own-appends.json', appends)
values = {}
for path, text in appends.items():
    with (r / path).open('ab') as f: f.write(text.encode())
    values[path] = git('show', base + ':' + path) + text.encode()
old = git('show', base + ':paper/materials/learning/ledger.jsonl')
raw_rows = (p / 'owned-strategy-ledger.jsonl').read_bytes().splitlines(keepends=True) + [own_raw]
existing = set(old.splitlines())
added = b''.join(raw for raw in raw_rows if raw.rstrip(b'\n') not in existing)
assert len(added.splitlines()) == 71
a, z = fold(old), fold(old + added)
for ident in a:
    core = ['claim', 'first_run', 'prior', 'character', 'kind', 'asc', 'evidence']
    if ident != 'silent-0491': core += ['status', 'version', 'shipped_at']
    assert all(a[ident].get(k) == z[ident].get(k) for k in core), ident
assert z['silent-0491']['status'] == 'shipped'
values['paper/materials/learning/ledger.jsonl'] = old + added
pending_integration = r / 'ops/codex-ops/pending-integrations/20261016-050119-calibration-numbering.json'
integration = load(pending_integration)
integration.update(completed_at=at, release_id=rid, numbering='complete', main_sync='complete', ledger_status='shipped', host='original exact6f full exit0', actual_live=deployment['live'], main=deployment['main'], receipt=str((pub / 'publication.json').relative_to(r)), natural_consumer='pending')
write(pending_integration, integration)
write(pub / 'registration-closure.json', dict(at=at, release_id=rid, main=deployment['main'], live=deployment['live'], numbering_and_data_sync='complete', ledger_shipped='silent-0491', host='exact original6f complete0; new versions metadata only', strategy_waiting=20, original_strategy_CLI_rows_staged=70, own_shipped_rows=1, no_new_source_or_full_check=True, role_evidence='actual independent watcher receipt and Roy-visible notification read back; CLI registration pending guard fix', consumer='pending next natural readback', wide_parents='remain open'))
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    helpers = []
    for f in sorted(p.glob('*.py')):
        archive.add(f, arcname=f.name, recursive=False)
        helpers.append(dict(path=str(f.relative_to(r)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
write(pub / 'ops-helper-manifest.json', helpers)
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'
entries = []
for path, raw in values.items():
    f = dest / path
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(p / 'record-manifest.json', dict(base=base, paths=entries))
check = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
print(json.dumps(dict(release_id=rid, paths=len(entries), ledger_rows=71, ledger_check=0, role_native_proofs=2, role_cli='pending root event guard')))

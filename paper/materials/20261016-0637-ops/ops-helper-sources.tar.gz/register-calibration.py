from pathlib import Path
import fcntl, hashlib, json, os, re, subprocess

r = Path.cwd()
live = r / '.worktrees/live'
p = r / 'ops/codex-ops/record-staging/20261016-0637'
pub = r / 'paper/materials/20261016-0637-ops'
pub.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
source = '89b6391845eb28b774c23db6f4466160c25876ba'
behavior = 'e138b036a79709f6217272e631324fd3e77e2bff'
tested = '4dfac2702bf1ce63199d4579c7d5cda136f13d3d'
tested_tree = '6f1f2cb003239b798ee345c9137f4867acd96162'
name = 'S1.boss-calibration20'

def git(*args, cwd=r, env=None, data=None):
    return subprocess.check_output(['git', '-C', str(cwd), *args], env=env, input=data, stderr=subprocess.PIPE)

def blob(ref, path, cwd=r):
    result = subprocess.run(['git', '-C', str(cwd), 'show', ref + ':' + path], capture_output=True)
    assert result.returncode in [0, 128]
    return result.stdout if result.returncode == 0 else None

def write(file, value):
    file.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def stage(path, raw, env, cwd, mode='100644'):
    oid = git('hash-object', '-w', '--stdin', cwd=cwd, data=raw).decode().strip()
    git('update-index', '--add', '--cacheinfo', mode, oid, path, cwd=cwd, env=env)

def commit(tree, parents, title, cwd):
    args = ['commit-tree', tree]
    for parent in dict.fromkeys(parents):
        args += ['-p', parent]
    return git(*args, cwd=cwd, data=(title + '\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n').encode()).decode().strip()

def physical(cwd, path):
    f = cwd / path
    return f.read_bytes() if f.exists() else None

def install(cwd, path, raw):
    f = cwd / path
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_name(f.name + '.ops-calibration20.tmp')
    assert not tmp.exists()
    tmp.write_bytes(raw)
    os.replace(tmp, f)

def dirty_snapshot(cwd, excluded):
    return {path: sha(physical(cwd, path)) for path in git('diff', '--name-only', 'HEAD', cwd=cwd).decode().splitlines() if path not in excluded}

assert not (pub / 'publication.json').exists()
handoff = json.loads((r / 'paper/materials/20261016-0625-ops/pending-publication-handoff.json').read_text())
leaves = handoff['original_source_paths']
paths = [x['path'] for x in leaves]
assert len(paths) == 87 and set(paths) == set(git('diff-tree', '--no-commit-id', '--name-only', '-r', source).decode().splitlines())
batch = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches']['20261016-050119-fix-batch']
check = batch['checks']
assert not batch['checks_pending'] and check['rc'] == 0 and check['merged'] == tested and check['tree'] == tested_tree
hostlog = Path(check['log'])
hostraw = hostlog.read_bytes()
hosttext = re.sub(r'\x1b\[[0-9;]*m', '', hostraw.decode())
assert '488 passed' in hosttext and '4915 passed' in hosttext and '2 skipped' in hosttext
(pub / 'original-host-full.log').write_bytes(hostraw)
write(pub / 'host-completion.json', dict(original_check=check, source_log_sha256=sha(hostraw), files_passed=488, cases_passed=4915, cases_skipped=2, seconds=764.84, no_new_host_request=True))

with (r / 'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    print(at, flush=True)
    mh = git('rev-parse', 'HEAD').decode().strip()
    lh = git('rev-parse', 'HEAD', cwd=live).decode().strip()
    assert lh == tested and git('rev-parse', lh + '^{tree}', cwd=live).decode().strip() == tested_tree
    builders = subprocess.run(['pgrep', '-f', '/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'], capture_output=True)
    assert builders.returncode == 1
    for cwd in [r, live]:
        assert not git('diff', '--cached', '--name-only', cwd=cwd).strip()
        assert not git('ls-files', '-u', cwd=cwd).strip()
    excluded = set(paths) | {'eval/versions.json'}
    foreign = {str(cwd): dirty_snapshot(cwd, excluded) for cwd in [r, live]}
    values = {}
    before = {}
    parent = git('rev-parse', source + '^').decode().strip()
    for leaf in leaves:
        path = leaf['path']
        raw = blob(source, path)
        assert len(raw) == leaf['bytes'] and sha(raw) == leaf['sha256']
        assert raw == blob(lh, path, live) == physical(live, path)
        old = blob(mh, path)
        assert old == blob(parent, path), path
        assert physical(r, path) in [old, raw], path
        before[path] = physical(r, path)
        values[path] = raw
        scan = p / 'composition-scan' / path
        scan.parent.mkdir(parents=True, exist_ok=True)
        scan.write_bytes(raw)
    datasets = {}
    for cwd, head in [(r, mh), (live, lh)]:
        raw = blob(head, 'eval/versions.json', cwd)
        assert physical(cwd, 'eval/versions.json') == raw
        datasets[str(cwd)] = json.loads(raw)
    main_data, live_data = datasets[str(r)], datasets[str(live)]
    assert main_data['release_numbering']['releases'] == live_data['release_numbering']['releases']
    registry = main_data['release_numbering']['releases']
    assert not any(x['commit'] == behavior for x in registry)
    nums = [int(re.fullmatch(r'V\d+-R(\d+)', x['release_id'])[1]) for x in registry]
    assert nums == list(range(max(nums) + 1))
    rid = f'V5-R{max(nums) + 1:03d}'
    entries = [x for x in live_data['versions'] if x['name'] == name]
    assert len(entries) == 1 and entries[0]['commit'] == behavior and not entries[0].get('release_id')
    original_entry = json.loads(json.dumps(entries[0]))
    assert not any(x['name'] == name for x in main_data['versions'])
    main_data['versions'].append(json.loads(json.dumps(original_entry)))
    versions = {}
    for key, data in datasets.items():
        item = next(x for x in data['versions'] if x['name'] == name)
        item.update(release_id=rid, release_status='registered-primary-ops')
        assert {k: v for k, v in item.items() if k not in ['release_id', 'release_status']} == original_entry
        data['release_numbering']['releases'].append(dict(release_id=rid, commit=behavior, aliases=[name]))
        versions[key] = (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode()
        scan = p / 'composition-scan' / ('main-versions.json' if key == str(r) else 'live-versions.json')
        scan.write_bytes(versions[key])
    with (pub / 'composition-gitleaks.log').open('wb') as out:
        scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', str(p / 'composition-scan'), '--redact', '--no-banner', '--report-format', 'json', '--report-path', str(p / 'composition-gitleaks.json')], stdout=out, stderr=subprocess.STDOUT, env={**os.environ, 'GOMAXPROCS': '1'})
    findings = json.loads((p / 'composition-gitleaks.json').read_text())
    if findings:
        assert scan.returncode == 1 and len(findings) == 1
        hit = findings[0]
        fp_path = 'experiments/boss-sim/silent/ae0da4720d7ec28643a6cb9367bc6c2bc30cc8ee4c476f2e05d6f7bbc84f17c6/fight-code-provenance.json'
        assert hit['RuleID'] == 'generic-api-key' and Path(hit['File']) == p / 'composition-scan' / fp_path and hit['StartLine'] == 10866
        provenance = json.loads(values[fp_path])
        row = next(x for x in provenance if x.get('key') == '5X2GHKJ89PN1:48:4:7776970478')
        assert row['run_id'] == '5X2GHKJ89PN1' and row['floor'] == 48 and row['attempt'] == 4
        ignore = p / 'composition.gitleaksignore'
        ignore.write_text(hit['Fingerprint'] + '\n')
        write(pub / 'composition-scan-false-positive.json', dict(rule=hit['RuleID'], path=fp_path, line=10866, fingerprint=hit['Fingerprint'], original_scan_rc=1, validated_fight_identifier=row['key'], run_id=row['run_id'], floor=row['floor'], attempt=row['attempt'], source_blob_unchanged=True, scope='Only this exact identifier fingerprint is excluded; no rule or source change.'))
        with (pub / 'composition-gitleaks-exact-exclusion.log').open('wb') as out:
            scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', str(p / 'composition-scan'), '--redact', '--no-banner', '--gitleaks-ignore-path', str(ignore), '--report-format', 'json', '--report-path', str(p / 'composition-gitleaks-filtered.json')], stdout=out, stderr=subprocess.STDOUT, env={**os.environ, 'GOMAXPROCS': '1'})
        assert scan.returncode == 0 and json.loads((p / 'composition-gitleaks-filtered.json').read_text()) == []
    else:
        assert scan.returncode == 0
    me = {**os.environ, 'GIT_INDEX_FILE': str(p / 'main.index')}
    le = {**os.environ, 'GIT_INDEX_FILE': str(p / 'live.index')}
    git('read-tree', mh, env=me)
    for path, raw in values.items():
        mode = git('ls-tree', source, '--', path).decode().split()[0]
        stage(path, raw, me, r, mode)
    stage('eval/versions.json', versions[str(r)], me, r)
    mt = git('write-tree', env=me).decode().strip()
    main_commit = commit(mt, [mh, source], f'Integrate exact calibration20 data and register {rid}', r)
    git('read-tree', lh, cwd=live, env=le)
    stage('eval/versions.json', versions[str(live)], le, live)
    lt = git('write-tree', cwd=live, env=le).decode().strip()
    assert git('diff', '--name-only', lh, lt, cwd=live).decode().splitlines() == ['eval/versions.json']
    live_commit = commit(lt, [lh], f'Register actual calibration20 behavior as {rid}', live)
    rec = dict(at=at, batch='20261016-050119-fix-batch', source=source, source_parent=parent, original_publication=tested, behavior_commit=behavior, name=name, release_id=rid, original_entry=original_entry, old_main=mh, main=main_commit, old_live=lh, live=live_commit, tree=lt, source_leaves=leaves, host_tested_commit=tested, host_tested_tree=tested_tree, host_rc=0, current_live_delta_from_host=['eval/versions.json'], production_and_data_equal_host=True, no_new_host_request=True, foreign_dirty=foreign, natural_consumer='pending', notice_registration='original root event guard blocked; actual native transfer already retained', game_account_model_home_budget_changed=False)
    write(p / 'intended-publication.json', rec)
    locks = []
    try:
        for cwd, env in [(r, me), (live, le)]:
            idx = Path(git('rev-parse', '--git-path', 'index', cwd=cwd).decode().strip())
            if not idx.is_absolute(): idx = cwd / idx
            lp = Path(str(idx) + '.lock')
            fd = os.open(lp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, 'wb') as out:
                out.write(Path(env['GIT_INDEX_FILE']).read_bytes())
                out.flush()
                os.fsync(out.fileno())
            locks.append((idx, lp))
        assert git('rev-parse', 'HEAD').decode().strip() == mh
        assert git('rev-parse', 'HEAD', cwd=live).decode().strip() == lh
        assert all(physical(r, path) == raw for path, raw in before.items())
        assert {str(cwd): dirty_snapshot(cwd, excluded) for cwd in [r, live]} == foreign
        git('update-ref', '-m', 'ops: register tested calibration20 behavior', 'HEAD', live_commit, lh, cwd=live)
        install(live, 'eval/versions.json', versions[str(live)])
        git('update-ref', '-m', 'ops: narrow calibration20 data integration', 'HEAD', main_commit, mh)
        for path, raw in values.items(): install(r, path, raw)
        install(r, 'eval/versions.json', versions[str(r)])
        for idx, lp in locks: os.replace(lp, idx)
    finally:
        for _, lp in locks:
            if lp.exists(): lp.unlink()
    for cwd in [r, live]:
        assert not git('diff', '--cached', '--name-only', cwd=cwd).strip()
        git('merge-base', '--is-ancestor', source, 'HEAD', cwd=cwd)
    assert {str(cwd): dirty_snapshot(cwd, excluded) for cwd in [r, live]} == foreign
    assert set(git('diff', '--name-only', mh, main_commit).decode().splitlines()) == set(paths) | {'eval/versions.json'}
    rec.update(source_actual_ancestor_main_live=True, all_unrelated_dirty_preserved=True, ordinary_indices_empty=True)
    write(pub / 'publication.json', rec)
    print(json.dumps(dict(release_id=rid, live=live_commit, tree=lt, main=main_commit, host_rc=0, source_paths=87, metadata_only_live=True)), flush=True)

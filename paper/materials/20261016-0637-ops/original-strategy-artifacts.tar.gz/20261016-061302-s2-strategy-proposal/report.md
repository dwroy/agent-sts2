# 本批静默策略提案逐项复核

记录时间：2026-10-16T06:24:43+08:00（写入前已运行date）。任务strategy-proposal；角色silent；批次20261016-061302-s2-strategy-proposal。
基线与最终HEAD：`c98e27e284f16402dd764f982003c08d3d52dce7`。本批没有源码、知识或追踪文件修改，没有提交、合入、上线或发布编号。
派发五局：7X0W3U8TVA2A,MTQ0EUBJ3R6T,KFRDELW2TH2P,GXNKW8X1XYJP,ZE8F192FKX24。只消费本批原10个CLI提案ID，不另领队列、不新建重复ID、不另派agent。

本批10项均waiting。下列既有功能及限定观察不等于整项实现；每个条目的缺口和后续验证独立保留。代码规则保持原状；源码撤除失败/恢复通过不适用，tsc/vitest/cases均null。

## 派发身份与边界

最初git status干净，HEAD与main一致；核完身份后`git merge --no-edit main`返回Already up to date。learn.json只使用batches中的本批行：task=strategy-proposal、character=silent、worktree精确匹配、reason=proposal，10个proposal_ids，没有research_request/implementation_request/proposal_repair。普通专题文件绑定另一批次，故不承接专题，不读取其他专题替代身份，不制造research_complete。

已读README、最新STATE-2026-10-15、decision-log末尾、学习协议和代码提案闭环。本批不是运维会话，不接管其工作；原日志只读，不调用模型、网络或游戏，不运行play，不读二进制、key、.env，不写运维prompt。

模型/模式由原宿主控制，本任务未切换模型或降低强度；没有独立读取原生会话配置的证据，不能凭历史对局脑模型声明当前会话原生参数已核。

## 原始证据

`evidence/evidence-manifest.json`逐流保存各自冻结source_size、局号计数和输出SHA；每行带原source/line/offset/bytes/SHA/row。`integrity.json`重新seek原日志，逐行比原字节SHA、JSON和显式身份；采用run-plans.run及run_id/state.run_id/fingerprint.run，冲突身份不接收，不由正文提及认所属局。八流共6060行全部核对。

| 局号 | 角色/进阶 | 实际结束 | 原运行源码提交（dirty另账） |
|---|---|---|---|
| ZE8F192FKX24 | SILENT/A5 | F48 胜 | `452f7bc7ac23bd1464fe04b951272236f471de8d` |
| 7X0W3U8TVA2A | SILENT/A10 | F31 败 | `047c809e625da861e34469791370f620866dee6f` |
| MTQ0EUBJ3R6T | SILENT/A10 | F23 败 | `ceb74207f90ed2e2f94f96570e70d00d84290081` |
| KFRDELW2TH2P | SILENT/A10 | F33 败 | `a73ce7ccbcfd09a9f9679dc4bddaf3dacb56b253` |
| GXNKW8X1XYJP | SILENT/A10 | F45 败 | `b1714285e60ce5a02798bea8cd5d4aa3118a2512` |

| 流 | source_size | 本批行数 |
|---|---:|---:|
| states | 13348164517 | 2965 |
| decisions | 1803549096 | 2846 |
| sl-attempts | 42327424 | 26 |
| run-config | 1829166 | 5 |
| run-plans | 8380258 | 30 |
| brain | 639830777 | 183 |
| runs | 343717 | 5 |
| fight-plans | 2233957 | 0 |

四局A10与ZE8的A5分列；A5只支持抑制现场版本观察，未进入A10执行审计。没有重算原提案所说118/119/120局全历史、机制分母或胜率。上游扫描跳过的非法行是整条流的计数，不知道是否属本批，不推论缺失内容。fight-plans在该流截点本批为0行，仅说明此截点未选到，不断言原日志或整场计划不存在。

原提案10份Markdown指纹全部匹配，保存`proposal-integrity.json`及原件副本。既有账本原claim/首证/prior/status/version和来源更新已只读保存到`ledger-assigned-events.json`；本批不重复支持或repeat、不新造反证、不降级shipped。

## 固定证据消费者

复用现有`learner/audit-selection.ts`对四局A10做完全离线消费。输入保留真实原行号、observed_ts、fingerprint、源码SHA；KFR一条、GX三条无decision_id元数据在`audit-input-manifest.json`明确排除，原件仍在evidence，不重新编号，不跨这些行认证连续性。四个原输入、输出、stderr和exit-codes均保留；四次rc=0，未调用当前知识库/LLM/游戏。

| 局号 | 候选段 | 动作 | 相邻动作观测端点 | 已核回合端点 | 未知回合 |
|---|---:|---:|---:|---:|---:|
| 7X0W3U8TVA2A | 119 | 445 | 36 | 7 | 64 |
| MTQ0EUBJ3R6T | 68 | 424 | 156 | 25 | 50 |
| KFRDELW2TH2P | 180 | 586 | 224 | 18 | 85 |
| GXNKW8X1XYJP | 116 | 646 | 178 | 20 | 83 |

合计483候选段、2101动作、594相邻动作端点、352回合窗（70已核端点、282未知），另MTQ有1个严格结束页端点。整候选认证0，所有actual_full_candidate_result仍null。KFR六次T6均turn_opening_unverified、T7均turn_end_unverified；手工原帧配对显示的83/93扣与6/12损不替代整轮认证。GX四次T2端点均可记录，净HP变化含复活，不把净增加当无入伤。completed仅动作接口回执，预测名次与同局相关SL不当最优或因果。

另复用`learner/resource_chain.py`的原函数，输入同批已验原状态与SL开始边界（没有再次粗筛原日志），为五局保存`resource-chain-<run>.json`与`resource-summary.json`。84个战斗窗口含相关重试/缺口，不能当84独立战斗或全胜；HP净变包含回复/自损，药槽变化来源与敌总伤仍有未知。实际产物中的观察退出只表示帧边界，不自动判赢。

## 关键实帧与结论范围

1. KFR F33T6，两起点均15血、228敌、36毒、3覆甲；次轮分别9/3血、145/135敌。SL多扣10同时多损6，两条都失败，不能调整统一血价。F12T1 decisions282578的rationale明确原plan5损12被护栏替为plan1损0，生成小刀后282579重问改线，不能声称实省12。
2. KFR末T7 states289533—289537：手上技法7挡，防御后12挡，刺击后已三手动动作且1能量爆发被SLOTH_POWER锁住；毒药37→43而本体159不变，最后43+42=85毒伤，敌74仍活。末9血/12牌挡/2覆甲对显示36攻击，22是算术完整需求，实际实扣到零只有9；不把它们混作伤害观测。
3. GX F45T2 states290160/290201同盘，后290165/290206分别3/13血、0/7挡，敌多8血。末state290213为13血、23挡、2覆甲，对17+12+11=40需要15，余血-2与283691 least-loss及290214实际死亡一致。四次精灵消耗与主动毒药请求分别保留；缺复活瞬时逐击和前三退出，不补未截断伤害。
4. GX F33T5 states289986→289987，已建ACCELERANT_POWER2才实际结29+28+27=84；末战触媒只在手未打，不预支收益。
5. 抑制四次SL摘要1053—1056均有四个普通键inserted与四升级旧键离堆，clean19/18/19/18。states290201→290206同窗有改标与抽牌；A5 states223268/223272确实读取普通现场版本，不能拿场外deck升级抹掉战内降级。纯改标瞬时帧、唯一物理副本和事件顺序未见，不能只凭基ID守恒恢复已知抽序。
6. 路线资源以已到为准：MTQ跨幕19→59、F19/F20入房59/46与开场61/48分开；KFR跨幕22→60、六次休息各+21、F32到36与F33开场38分开；GX三胜入口97→84→66→41、F42至71、F44胜后5、F45入房5/开场7。SL恢复不计路线回血，未来营火、未取得牌和未走路线不填反事实。

上述限定材料共29项断言通过，详`evidence-checks.json`。这是材料一致性核验，不是生产测试、模型全覆盖、自然消费者验收或胜率收益。

## 源码覆盖核对

`source-audit-final.json`记录完整base、冻结live读回提交、17个相关叶SHA、7个既有来源祖先。13叶逐字相同，4叶只差Roy/Dai历史注释归属词；保存`source-live-differences.patch`并核整叶仅该替换相等，未为一致性改动注释。不由这17叶外推整棵树一致或历史模型已校准。

限定奇巧资源提示、恶魔6毒入口、HP净增边界、候选/SL/药槽/回合离线审计都已存在，明确在逐项提案中列出真实祖先；其continuation_verified=false、actual_turn=null、实际完整候选null及来源未知均保留。没有新源码可提交，不把已有子项冒记整项duplicate/implemented。

原运行run-config的完整code.commit均能解析。五局dirty_files只列知识JSON，没有源码叶；故把原提案笼统“dirty完整源码未知”收窄为“历史源码提交可定位，实际刷新知识字节及完整联合消费者输入未复原”。这是来源限制更正，不是游戏机制反证，也不声称历史输入已完全复现。

本次live读回固定为`e138b036a79709f6217272e631324fd3e77e2bff`；这只是只读引用，不是本批merged或新发布。

## 十项处置

| 原CLI ID | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-19a5cff2094e2d8f | waiting | MTQ同盘换线与7X复活血池仅有局部观测；缺未截断入伤、持续实体归属和同输入整战校准，不能由死亡率饱和拟新SL/终局规则。 |
| silent-proposal-3540bf4360bf80af | waiting | 已有HP增加边界和离线资源链；尚缺完整回血来源/逐槽归因及原路线、休息消费者的联合读回，不能以净变化代已到资源或整项实现。 |
| silent-proposal-0ea5c0b9c030fdd6 | waiting | 懒惰奇巧提示及限定恶魔6毒入口已存在；完整合法后继仍标continuation_verified=false，缺自动重放/后继收益及多轮消费者校准，不能把局部覆盖当整项重复。 |
| silent-proposal-f915ec544ab94b6e | waiting | 既有离线工具可关联原答、SL替换和重问，但完整候选收益仍null；KFR T6整轮开端未核、F12原护栏线中断，缺可归属的完整实线及排序对照。 |
| silent-proposal-8fb51933639faf90 | waiting | 限定毒药及力敏/覆甲局部模型已有；覆甲完整减层条件未隔离，叠加药效、能力、能量的多入口联合校准和完整时点收益仍不足。 |
| silent-proposal-b3bc0eb09211af6c | waiting | 奇巧资源提示已有，完整后继与未建立收益仍未知；六次T7和局部SL均未证明替顺序可存活，缺整战兑现与终局价值校准。 |
| silent-proposal-fdc3a505fe5e1a55 | waiting | KFR实际休息、幕间、开场和SL恢复可分列，现有观测器已覆盖部分；完整路线/休息消费链、逐源归因及替路线对照仍缺，不能关闭整项。 |
| silent-proposal-5a95725089f53cd8 | waiting | GX局部复活后3/13血、0/7挡及药槽变化已有审计；缺复活瞬时逐击、未截断入伤、前三出口和完整候选归属，不能据10血/8伤差改规则。 |
| silent-proposal-51fa8bc34774f72d | waiting | 四次假inserted与升级键作差路径可复现；缺仅改标瞬时帧、稳定物理副本身份和并发抽牌/插入次序，不能仅按基ID守恒延长SL已知前缀。 |
| silent-proposal-29b7b36dffbcb017 | waiting | GX已建触媒两层的84毒伤和末战未建立能力可核，既有局部模型不缺；头骨/毒雾/覆甲/力敏联合多轮校准及完整时点对照仍不足。 |

每项证据局/层/回合、账本、既有来源、反例、预期行为、验证与回退详`proposal.md`；原Markdown逐份保留。全部原id维持待新局处理，不改根请求、父要求或原提案，不创建替代id。

## 账本、验证与交付

本批只经根目录ledger.py update追加24个所属账本的where.proposal及note追溯，输入、CLI stdout/stderr/rc、原字节位置与fold读回另存。没有新增游戏claim、支持/反证/repeat、status/version或shipped；不将等新局排队说成已送达或消费者已采用。以`ledger-receipt.json`实际回执为准。

源码撤除失败/恢复通过：不适用，没有源码改动，不构造假失败或假通过。生产tsc/vitest/cases：null/null/null，未运行生产套件；四次离线消费rc0及29项材料断言分账。提交/gitleaks提交扫描：无新提交；合入、上线版本、重建知识及Roy规则变更双通知：均不适用。工作树保持干净、HEAD保持base，根账本只走授权CLI。不推送、不运行play、不碰并行运维记录。

过程保留：首次不匹配rest*.ts的只读路径探针返回rg错误；一次bubblewrap预检遇其他学习过程目录被回收而返回构建错误，原命令未运行、重试读取成功；输出截断仅为显示预算，不作产品缺陷。首份20/21帧锚点初稿`selected-state-anchors.json`保留，最终21/21存另文件；提取等待期间没据未完成输出认日志缺失。全部提取/离线进程nice19，不存在子agent或后台模拟。

交付路径为本目录`proposal.md`、本报告及`result.json`；本批不关闭学习父要求，入库与实际消费者采用均不作声明。

实际完成读回：2026-10-16T06:26:36+08:00（前已date）。根ledger.py update退出0，24条本批where/note追加逐条按offset/bytes/SHA验收，原物理前缀和24条fold的claim/first_run/prior/status/version/shipped_at均保持，旧evidence/history/notes前缀保持，proposal/report链接均实际读回。无重复support/repeat或shipped。最终git status为空、HEAD=c98e27e284f16402dd764f982003c08d3d52dce7、git diff --binary HEAD为空；本批派发身份及10原ID结束前再次核对一致。

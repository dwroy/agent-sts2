# 本批静默策略提案逐项复核

记录时间：2026-10-16T06:24:43+08:00（写入前已运行date）。任务strategy-proposal；角色silent；批次20261016-061302-s2-strategy-proposal。
基线与最终HEAD：`c98e27e284f16402dd764f982003c08d3d52dce7`。本批没有源码、知识或追踪文件修改，没有提交、合入、上线或发布编号。
派发五局：7X0W3U8TVA2A,MTQ0EUBJ3R6T,KFRDELW2TH2P,GXNKW8X1XYJP,ZE8F192FKX24。只消费本批原10个CLI提案ID，不另领队列、不新建重复ID、不另派agent。

本批10项均waiting。下列既有功能及限定观察不等于整项实现；每个条目的缺口和后续验证独立保留。代码规则保持原状；源码撤除失败/恢复通过不适用，tsc/vitest/cases均null。

## 1. silent-proposal-19a5cff2094e2d8f

原提案：同抽重打饱和死亡率与持续敌血池的终局价值审计。状态：waiting。账本：silent-0021,silent-0064,silent-0079,silent-0133,silent-0125。
原来源任务：experience-update；实现任务：strategy-proposal。原领域：combat,potion,sl,terminal，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-sl.md`；原SHA256：`7bf15ce1f8fd2291d52b8d24fc89de1fe613e8fd9812d31621f9cd48c8e2d57d`，已逐字核对并另存`original-silent-proposal-19a5cff2094e2d8f.md`。

- 证据局号/进阶/层/回合：7X0W3U8TVA2A A10 F31 T1—13；MTQ0EUBJ3R6T A10 F23四试T2—5，尤其decisions282434的T3原/替线均24/24死，预测损0/8、扣13/19。
- 本次核实：MTQ原SL记录明确以已知失败线进行探索，不等于认为替线安全或原线能赢。7X持续复活必须分列可见血池新增与净敌血；resource_chain的damage_total仍为null，不能把活体一时为零当终战完成。
- 已有源码/局部覆盖：learner/resource_chain.py的enemy_hp_audit和既有候选/回合端点审计可用；来源3f69541b5d3259dac94d3395bfe3da47936b4de9、e75438488df159b2e8e9d3458cf219b39aadd933已为base/live祖先。只是有界观测消费者，不是本批新实现。
- 反例及限制：原失败线并非已知胜线；相关SL不能当独立局。原模型死亡数相同不证明风险相同，也不能据一个局部血差禁止全部探索。
- 未实现的具体原因：MTQ同盘换线与7X复活血池仅有局部观测；缺未截断入伤、持续实体归属和同输入整战校准，不能由死亡率饱和拟新SL/终局规则。
- 保持的旧行为及有证后预期：保持当前严格必死与探索规则；未来比较须同时呈现当轮完整生存需求、未结收益、复活新增及预测/实盘差别。
- 验证方法：固定原帧保留同盘资源、尝试和实体缺口；若改排序，需同输入同预算整战成对回放、独立后置局及无关角色等价检查。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 2. silent-proposal-3540bf4360bf80af

原提案：连续赢战、已到回复与下一房入口分源记录。状态：waiting。账本：silent-0019,silent-0020,silent-0243。
原来源任务：experience-update；实现任务：strategy-proposal。原领域：structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-resources.md`；原SHA256：`58181f916f63872302d0ab2342b349e5de205083aa365151b8f4bcb79c1b63ce`，已逐字核对并另存`original-silent-proposal-3540bf4360bf80af.md`。

- 证据局号/进阶/层/回合：MTQ0EUBJ3R6T A10 F17→18 states288726→288727实19→59；F19入房59/开场61、F20入房46/开场48；7X0W3U8TVA2A A10 F30—31连续资源链。
- 本次核实：MTQ幕间实回40、开场每次+2和休息21/36分别有原帧，未到的F24不是当时可用血量。现有run-journal记录HP增加观测及边界，明确仅帧间净变化、不推回血因果。
- 已有源码/局部覆盖：agent/src/memory/run-journal.ts:trackSilentHpRecovery；来源5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452已在base/live。旧resource_chain也保留restart与missing_exit。
- 反例及限制：连续赢战仍能耗尽后战缓冲；路线由模型选择且夹有开场回复/事件/休息，不能从观察败局反推替路线必胜。
- 未实现的具体原因：已有HP增加边界和离线资源链；尚缺完整回血来源/逐槽归因及原路线、休息消费者的联合读回，不能以净变化代已到资源或整项实现。
- 保持的旧行为及有证后预期：复用现有资源事实，区分入房与首个可操作HP、已到休息与未来投影；不增加安全HP阈值或重算不在本批的全史统计。
- 验证方法：固定跨幕、休息、开场、战内回复、SL恢复和未到节点负例；还需自然路线/休息输入逐字节消费验证。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 3. silent-proposal-0ea5c0b9c030fdd6

原提案：静默A10知识恶魔：补奇巧选择的懒惰剩余名额与兑现条件；在本局已观察组合中验证毒药6层的量化候选，保留其他条件与提前饮用整场效果未知。。状态：waiting。账本：silent-0274,silent-0247,silent-0027,silent-0016。
原来源任务：postmortem；实现任务：strategy-proposal。原领域：combat,potion,structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261008-054302-postmortem/proposal-sloth-potion.md`；原SHA256：`ed57d3f8b54f0d056efe2e488a4dca2c2b32a7062433c636e71a51b395663391`，已逐字核对并另存`original-silent-proposal-0ea5c0b9c030fdd6.md`。

- 证据局号/进阶/层/回合：KFRDELW2TH2P A10 F33六次T7；decisions282864/282899/282933/282968/283001/283035；states289533—289538。
- 本次核实：实帧为手上技法7挡、防御后12挡，三次手动动作后爆发余1能量仍锁；毒药37→43且敌159当步不变，之后43+42=85、敌74仍活。选牌提示和限定毒药入口已有，不能再沿用旧的完全缺上下文/永远毒量未知理由。
- 已有源码/局部覆盖：silent-hand-trick-facts.ts提供remaining_manual_plays_upper_bound、能量、目标后继要求，保留continuation_verified=false；silent-demon-potion.ts严格限定角色/等级/遗物/能力组合，combat-plan.ts将observedPoison传入。c4a4f4a94b48dff9b30aaa7228624c1092150145为base/live祖先。
- 反例及限制：F28给防御奇巧后也没有继续施放；手上技法自身7挡已兑现，不能因目标未打否定整张牌。没有换目标或早喝毒药的完整胜线。
- 未实现的具体原因：懒惰奇巧提示及限定恶魔6毒入口已存在；完整合法后继仍标continuation_verified=false，缺自动重放/后继收益及多轮消费者校准，不能把局部覆盖当整项重复。
- 保持的旧行为及有证后预期：继续保留所有候选与原排序；不重复新增提示或把限定6层外推到其他修饰组合。完整后继未证仍写未知。
- 验证方法：固定选牌帧和后续三动作、自动重放、能量不足与名额不足负例；完整组合须合法序列及后继收益验证，未来新局按时间留出。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 4. silent-proposal-f915ec544ab94b6e

原提案：追踪静默A10护栏完整候选到重问后实线的预测失效，记录SL同盘多10伤／多6损的局部血价；无新阈值或已胜反事实。。状态：waiting。账本：silent-0079,silent-0125。
原来源任务：postmortem；实现任务：strategy-proposal。原领域：combat,sl,structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261008-054302-postmortem/proposal-sl-tradeoff-guard.md`；原SHA256：`2339e1598f60a64fa1db9be3ebe3cecfe7057ff323c14f15341ccce85b15de98`，已逐字核对并另存`original-silent-proposal-f915ec544ab94b6e.md`。

- 证据局号/进阶/层/回合：KFRDELW2TH2P A10 F12T1 decisions282578/282579；F33T6 decisions282929，states289339→289345与289414→289420。
- 本次核实：两次T6起点均15血/228敌/36毒/3覆甲，次轮9/3血、145/135敌，对应净扣83/93、损6/12。F12原答plan5被护栏变成另一完整候选，斗篷生刀后再问题已改线；预测省12不可当实省12。审计的六个T6仍turn_opening_unverified，手工局部端点不抹掉工具未知。
- 已有源码/局部覆盖：learner/audit-selection.ts及selection-execution/turn/observation保留SL优先于旧journal、回执/重问边界和实际端点；02c4e13ac8e159b82ee35a965ac788a0a029ce5a、e75438488df159b2e8e9d3458cf219b39aadd933已是base/live祖先。在线selection_audit仍actual_turn=null。
- 反例及限制：两条T6线均未赢；F12不同实线损6也不能证明原完整候选预测错或认定受控省血。
- 未实现的具体原因：既有离线工具可关联原答、SL替换和重问，但完整候选收益仍null；KFR T6整轮开端未核、F12原护栏线中断，缺可归属的完整实线及排序对照。
- 保持的旧行为及有证后预期：继续按实际动作关联而非复制整条候选收益；不把B2相近、残敌更少或死亡率饱和变成安全判断。
- 验证方法：固定原答→护栏→生成→重问→实际请求链；若进一步改SL排序，须整场成对验证和后置自然局。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 5. silent-proposal-8fb51933639faf90

原提案：已观察药效和能力的分时点模型覆盖核验。状态：waiting。账本：silent-0005,silent-0006,silent-0027,silent-0189,silent-0276,silent-0277,silent-0278。
原来源任务：experience-update；实现任务：strategy-proposal。原领域：combat,potion，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-mechanisms.md`；原SHA256：`540a529f428b0c342abb969c3d040446149db3d7fb4f855b23f4b950462a64ab`，已逐字核对并另存`original-silent-proposal-8fb51933639faf90.md`。

- 证据局号/进阶/层/回合：KFRDELW2TH2P A10 F28T2敏捷药，F33六试T2铁心、T4敌回血/加力、T5触媒、T6—7；账本0276/0277/0278及0189。
- 本次核实：现有potionEffect及turn-solver已有敏捷/覆甲分时点路径，不能因新增知识文字就认代码缺公式。限定恶魔毒药已接线；当前实帧只证药后能力及后续挡，不能由7→2写出未经隔离的固定减层规则。
- 已有源码/局部覆盖：agent/src/reflex/card-model.ts:potionEffect、turn-solver.ts临时敏捷/覆甲路径、silent-demon-potion.ts；本次逐叶SHA与live对照，原归属词注释差保留。
- 反例及限制：旧提案记载的制品阻毒、头骨加量是不同条件，不能把无加量6层外推；本批未重核全史29/44/16局分母，不宣称全组合通过。
- 未实现的具体原因：限定毒药及力敏/覆甲局部模型已有；覆甲完整减层条件未隔离，叠加药效、能力、能量的多入口联合校准和完整时点收益仍不足。
- 保持的旧行为及有证后预期：复用已存在的有限模型，继续对未观察的组合保留未知；不设早喝、保药或HP持有价参数。
- 验证方法：按能力建立时点、当步挡不变、后续每牌挡、实际毒结算分别核固定组合；联合多轮及新自然消费者仍需补证。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 6. silent-proposal-b3bc0eb09211af6c

原提案：奇巧可执行后续、SL血价与实际终结核验。状态：waiting。账本：silent-0021,silent-0079,silent-0102,silent-0247,silent-0274。
原来源任务：experience-update；实现任务：strategy-proposal。原领域：combat,sl,terminal,structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-sl-selection.md`；原SHA256：`f3279ab3f48180d287e7ad57c0a1484e56ed48910772aac748dd6faf32185bf9`，已逐字核对并另存`original-silent-proposal-b3bc0eb09211af6c.md`。

- 证据局号/进阶/层/回合：KFRDELW2TH2P A10 F33T4/T5/T6/T7；states289533—289538，decisions282929与六次奇巧选择。
- 本次核实：普通触媒1实际两结，最终毒伤85但敌剩74；持有/被选爆发不等于已建立能力。末9血、12牌挡与2覆甲对36的算术缺口22，与实际0血截断必须分开。
- 已有源码/局部覆盖：既有hand_trick_resources、限定毒药、selection_audit及离线观测工具；相应真实祖先见source-audit-final.json，未重复实现原0245重放计数修复。
- 反例及限制：手上技法本身已给7挡；换目标、先爆发、早喝药均没有完整实盘对照。敌更低残血和B2预测不能充已胜。
- 未实现的具体原因：奇巧资源提示已有，完整后继与未建立收益仍未知；六次T7和局部SL均未证明替顺序可存活，缺整战兑现与终局价值校准。
- 保持的旧行为及有证后预期：保持原必死边界、选线及未知抽牌处理；未打能力、未结毒、未完成后继不预支为终局收益。
- 验证方法：同批固定快照分列已建/持有/选择/施放/结算；完成全部后继和整战对照后再评估是否改排序。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 7. silent-proposal-fdc3a505fe5e1a55

原提案：赢战血价、已到回血与跨幕回复事实分源。状态：waiting。账本：silent-0019,silent-0020,silent-0243。
原来源任务：experience-update；实现任务：strategy-proposal。原领域：structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-resources.md`；原SHA256：`9591f8717f33da220db658aaa746a04412cd9b324bb60fbb2f9a376a0796ea75`，已逐字核对并另存`original-silent-proposal-fdc3a505fe5e1a55.md`。

- 证据局号/进阶/层/回合：KFRDELW2TH2P A10 F17→18 states289149→289150实22→60；F29—33，F32休息15→36、F33开场36→38。
- 本次核实：原帧六次休息各+21；跨幕实+38与开场+2另账；前两场赢战把F29后缓冲继续消耗，F32实际到36。SL恢复由重启边界分列，不计路线回血，未来营火及未得到的步法/尖啸不计已到资源。
- 已有源码/局部覆盖：trackSilentHpRecovery与resource_chain已记录HP净增和restart，但都明确不推完整来源；5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452已为实际live祖先。
- 反例及限制：六次回血后仍败不证明回血决策错误；不同路线、药水和构筑随时间变化，F18预测不能直接当F33反事实。
- 未实现的具体原因：KFR实际休息、幕间、开场和SL恢复可分列，现有观测器已覆盖部分；完整路线/休息消费链、逐源归因及替路线对照仍缺，不能关闭整项。
- 保持的旧行为及有证后预期：继续保留已到节点/资源和未来投影的边界，复用原记录；不从单败局拟安全节点或锻造阈值。
- 验证方法：固定六次休息、跨幕、开场、SL恢复及未到节点；线上路线/休息事实题面的完整读回仍待自然窗口。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 8. silent-proposal-5a95725089f53cd8

原提案：A10三骑士同T2盘面复活后3/13血与8伤血价，补Jev原答/SL替换/重问/实际执行与逐槽资源链审计；两线均失败，保留评分和必死规则。。状态：waiting。账本：silent-0019,silent-0079,silent-0005,silent-0016,silent-0087,silent-0027,silent-0030。
原来源任务：postmortem；实现任务：strategy-proposal。原领域：combat,potion,sl,structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261008-064304-postmortem/proposal-resource-bloodprice.md`；原SHA256：`802a23c7d736197db33e3c57daf42eb9064bc4b2ee56fc2f5733b3fdd73fcdb7`，已逐字核对并另存`original-silent-proposal-5a95725089f53cd8.md`。

- 证据局号/进阶/层/回合：GXNKW8X1XYJP A10 F35/38/40/42/44/45；F45T2 states290160→290165及290201→290206；T3 decisions283690/283691和states290212—290214。
- 本次核实：前三胜入口97→84→66→41；F42回至71，F44胜到5，F45入房5/开场7。两试T2同盘后3/13血与0/7挡，末线敌多8血；末13+23+2对40需损15、余血-2，原least-loss与实死一致，不是漏算。
- 已有源码/局部覆盖：selection-observation逐槽及automatic字段、selection-terminal及observed_turns已在live祖先a32050fbce4c2863f640468c2dbf378fc9157074、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933；不是本批新代码。
- 反例及限制：四次精灵自动耗用与主动毒药不同；两线都失败，保多10血并不证明整战优；0血实扣封顶不等完整需伤。
- 未实现的具体原因：GX局部复活后3/13血、0/7挡及药槽变化已有审计；缺复活瞬时逐击、未截断入伤、前三出口和完整候选归属，不能据10血/8伤差改规则。
- 保持的旧行为及有证后预期：继续保留原答、SL替换、自动耗用和请求回执；不改候选排序、精灵模拟或least-loss语义。
- 验证方法：固定T2四窗口已核端点与药槽，复活中间帧/逐击未知保持；新完整逐击及实际线归属才可补齐审计和量化比较。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 9. silent-proposal-51fa8bc34774f72d

原提案：修复已核silent抑制窗口同牌升级改标被SL作差记成假插入/离堆的身份问题；保持实际普通牌与场外升级分账，同ID歧义仍断序，当前无胜负改善证明。。状态：waiting。账本：silent-0279,silent-0280。
原来源任务：postmortem；实现任务：strategy-proposal。原领域：combat,sl,structure，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261008-064304-postmortem/proposal-dampen-identity.md`；原SHA256：`f84a6264bc2846c4e90323039a66b6a3a7104b3503431f942af68601951e1a67`，已逐字核对并另存`original-silent-proposal-51fa8bc34774f72d.md`。

- 证据局号/进阶/层/回合：GXNKW8X1XYJP A10 F45T2→T3；sl-attempts1053—1056，states290160/290165/290201/290206/290214；ZE8F192FKX24 A5 F42T3—4 states223268/223272、decisions218927/218928。
- 本次核实：draws.ts的cardKey带+，observeInserts整堆差分把四普通键视作fresh；四旧+键未入手离堆，clean19/18/19/18。A5现场会读取普通版本，场外deck仍保留升级；这不证明抽序器已修。A10边界同时从T2到T3抽入普通牌，完整纯改标瞬时帧没有保存。
- 已有源码/局部覆盖：agent/src/sl/draws.ts:cardKey/observeInserts/matchDrawn；matchDrawn已有入手改标匹配，但留堆作差未等价修复。与live仅历史归属词注释差，不宣称源码已修。
- 反例及限制：同ID升级/普通多副本及同窗真插入/选择/洗牌都可能使守恒不足以确定物理顺序；不能把run.deck升级字段覆盖战内普通牌。
- 未实现的具体原因：四次假inserted与升级键作差路径可复现；缺仅改标瞬时帧、稳定物理副本身份和并发抽牌/插入次序，不能仅按基ID守恒延长SL已知前缀。
- 保持的旧行为及有证后预期：当前保守断序保持；未来仅在明确窗口和唯一物理配对成立时消除假插入，所有歧义继续断序，不预支抽序或改变SL判死。
- 验证方法：需要单纯改标留堆、并发抽取、真实插入、多副本、升级/普通混合、洗牌、出口恢复负例及真实相邻帧；当前证据不足以安全实现所要求的顺序恢复。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

## 10. silent-proposal-29b7b36dffbcb017

原提案：实际能力、毒结算与现场力挡核验。状态：waiting。账本：silent-0005,silent-0006,silent-0011,silent-0016,silent-0021,silent-0027,silent-0030,silent-0087,silent-0278。
原来源任务：experience-update；实现任务：strategy-proposal。原领域：combat,potion,terminal，本批实际implementation_domains=[]。
原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-mechanisms.md`；原SHA256：`40866aa3c6ee72a028bee5c911c168ddb017fa740833376b7bf6dab1f7dca7eb`，已逐字核对并另存`original-silent-proposal-29b7b36dffbcb017.md`。

- 证据局号/进阶/层/回合：GXNKW8X1XYJP A10 F17T9、F33T3/5/6、F45T1—3；states289986→289987实29+28+27=84，末states290213没有ACCELERANT_POWER。
- 本次核实：F33实建两层触媒才有三结84；末战普通触媒虽在手却没有施放，不能将它的后续收益预支给末轮。末轮按当前2覆甲而非开场4计，13血+23挡+2覆甲对40需15、-2与实死相符。
- 已有源码/局部覆盖：card-model/turn-solver已存在力敏、毒雾、触媒、覆甲及现场版本读取；本次只核限定源码和实帧，不将现有公式或经验条目当全组合准确率。
- 反例及限制：首试与重打抽牌/防御/施放时点共同变化，F17毒收30剩2血不是单独某药时点的因果；制品与头骨条件不混基础剂量。
- 未实现的具体原因：GX已建触媒两层的84毒伤和末战未建立能力可核，既有局部模型不缺；头骨/毒雾/覆甲/力敏联合多轮校准及完整时点对照仍不足。
- 保持的旧行为及有证后预期：复用已核能力时点及当前层数；保留未结算/未建立收益未知，不制定先能力、早喝药或固定集火规则。
- 验证方法：固定已建/未建、毒结算次数、敏捷旧挡不追补、当前覆甲等正反例；联合资源与整战消费者校准仍待补证。

样本切分：本批原始局及其相关SL仅作诊断/固定快照，按局去重；未来独立结束且条件可比的静默局作时间后留出。没有拟合药价、HP/SL阈值、牌值或通用系数；没有用预训练事实补结论。
回退：本批无源码无需撤回；将来若实现，按独立源码提交反向撤销，保留刷新知识、原日志、提案及账本，不改其他角色/未观察进阶。

# 静默猎手策略提案回报

本批十项均为waiting；没有新增源码、知识、提交、live合入或版本。已核实的机械子项已有实际live祖先，原提案剩余组合/消费者/受控后继证据不全；逐项原因见下表及proposal.md。既有人定规则可按授权修改，但本批不凭局部端点拟合新阈值。

本批20261016-061302-strategy-proposal，base **c98e27e284f16402dd764f982003c08d3d52dce7**。开工git status为空，git merge --no-edit main返回Already up to date。派发身份是task=strategy-proposal/character=silent/reason=proposal，只有本批十个proposal_ids，无proposal_repair、research_request、implementation_request；不匹配旧牌组专题，不接手其父要求。未派下级agent。

## 可复核材料

共用extract_evidence.py分别提取十锚点及五个原提案来源，所有局均先由runs.jsonl核SILENT。22,424条材料逐一用source offset/bytes/SHA256和JSON读回相等；各流source_size与产物SHA见两份evidence-manifest.json及raw-verification.json。没有重编号原行。

| 局号 | 进阶 | 状态 | 决策 | SL | 配置 | 计划 | brain | runs |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 25226ZFLNR1J | 10 | 889 | 862 | 9 | 1 | 7 | 45 | 1 |
| 7X0W3U8TVA2A | 10 | 461 | 445 | 1 | 1 | 4 | 31 | 1 |
| 9TG1RP5LFAAK | 10 | 923 | 903 | 11 | 1 | 9 | 47 | 1 |
| 9Z9H2EXKLF3T | 10 | 1018 | 932 | 9 | 1 | 9 | 51 | 1 |
| BTSRF7JL1W1Y | 10 | 653 | 635 | 4 | 1 | 5 | 28 | 1 |
| F4QKG4J1AJJZ | 9 | 728 | 703 | 4 | 1 | 7 | 37 | 1 |
| G403VCZ3BH1B | 9 | 654 | 635 | 4 | 1 | 7 | 48 | 1 |
| HMVJKM56S4Q8 | 9 | 664 | 642 | 9 | 1 | 5 | 31 | 1 |
| JLN5SK17W4FQ | 10 | 810 | 790 | 8 | 1 | 5 | 37 | 1 |
| JMH5C51RLN4E | 10 | 880 | 853 | 13 | 2 | 10 | 53 | 1 |
| JQPT83P8KDSZ | 10 | 523 | 510 | 5 | 1 | 4 | 24 | 1 |
| MTQ0EUBJ3R6T | 10 | 440 | 424 | 5 | 1 | 4 | 23 | 1 |
| RC61MFQM63Y6 | 10 | 694 | 674 | 7 | 1 | 7 | 33 | 1 |
| S9UZAK0JP0C0 | 10 | 861 | 826 | 10 | 1 | 6 | 33 | 1 |
| XTSV1U9JD34T | 10 | 810 | 775 | 10 | 1 | 8 | 49 | 1 |

A9三局与A10十二局分别分析；G403VCZ3BH1B是本材料唯一胜局且属A9，不能充A10验证胜线。runs字段仅十派发锚点，五补充局仅因本批原提案引用。fight-plans在这两个截点对这些局都为0行，只表示该截点未选到，不断言原日志缺失。全源扫描states/decisions各2条、brain1条解析失败，不把全源计数归给这些局。

原十Markdown存在且SHA均匹配队列，已按原字节保存original-<id>.md。46关联账本只读取本角色相应条目；规范CLI fold快照为ledger-before-canonical.json，初步ledger-before.json只作原探针保留，不用作账本验收。不覆盖原提案、不重复历史复盘、不另建代码提案ID。

## 主要证据与边界

- RC61MFQM63Y6 F23T3 states285222—285229：预判后敏1，速度药后6，斗篷12挡、防御再9、第三攻击折扇+4至25；F23T4敏归0。此窗不同时含脆弱及翻倍，不能认证原八组件所有联合条件。
- BTSRF7JL1W1Y F31T2 states286158—286162：生存者后唯一突然一拳消失，13牌挡、覆甲和其他敌威胁分别计；F30胜70→42而F31入42。XTSV1U9JD34T F48胜97→23，F49实际入23；持有能力不能跨场预支。
- XTSV1U9JD34T F49T1 states286897→286898：幽灵新增无实体1，23HP/16挡保持。T4首试/末试夜魇3复制标记存在但未活到下一轮；前两类选择差额不足证明“去掉夜魇即可赢”或“必须晚喝”。
- 9Z9H2EXKLF3T F48第2/3试T7：同开场393敌血/20玩家HP，整轮扣49损11与扣71损9，各含重问；省2/多扣22不是可单归SL替换的因果效应。末T8 states287990→287991实际0→20复活，不能把轮初11到轮末20叫负伤害；末T10三牌挡18+9+10=37，实损15。末T11敌112→32的80净扣与已发生39+38毒及一次3反伤相符，不预支死亡后第二击。
- 7X0W3U8TVA2A F31T13 decisions282021、states288470→288471→288472：后段零毒→7，本体25保持，然后实扣7到18；前段既有8毒另结、中段重接25另计、玩家仍死。只能证这个头骨组合向该零毒目标实加7，不反推无头骨基础量、所有目标或持有价。
- MTQ0EUBJ3R6T F23四试T3：前三次29挡、玩家零损，末次19挡、损8、敌多扣6；旧线仍T6判死，末线T5实死。四试是同局相关样本，不能拟8血门槛、独立胜率或把24/24失败样本当实盘必死。
- 15局共22对跨幕同上限回复端点：A9五对、A10十七对，全部floor(缺血×80%)。9Z F35同时上限77→69和HP66→30，F38→19、F39→11、F45→7、F47只回27，未来营火不可预支。这里只复核本材料，未重算原116局总体或校准房间/路线收益。

## 离线消费者

现有learner/audit-selection.ts按冻结输入运行，12个A10请求均退出0；A9不送入A10合同。原始提取保留12条无decision_id元数据，其中A10七条/A9五条，离线输入排除并另存原行及理由，不补造ID、不连过断点。

| 局号 | 动作 | 题段 | 相邻观测区间 | 可核整轮端点 | 未核整轮 |
|---|---:|---:|---:|---:|---:|
| 25226ZFLNR1J | 862 | 143 | 340 | 49 | 92 |
| 7X0W3U8TVA2A | 445 | 119 | 36 | 7 | 64 |
| 9TG1RP5LFAAK | 901 | 234 | 321 | 45 | 98 |
| 9Z9H2EXKLF3T | 932 | 219 | 382 | 49 | 90 |
| BTSRF7JL1W1Y | 635 | 98 | 238 | 36 | 62 |
| JLN5SK17W4FQ | 789 | 119 | 333 | 47 | 85 |
| JMH5C51RLN4E | 850 | 275 | 239 | 36 | 121 |
| JQPT83P8KDSZ | 510 | 122 | 169 | 22 | 49 |
| MTQ0EUBJ3R6T | 424 | 68 | 156 | 25 | 50 |
| RC61MFQM63Y6 | 674 | 135 | 242 | 29 | 76 |
| S9UZAK0JP0C0 | 826 | 184 | 431 | 59 | 74 |
| XTSV1U9JD34T | 774 | 167 | 222 | 27 | 113 |

合计8622动作、1883题段、3109相邻端点、431可核整轮及974未知整轮。所有actual_full_candidate_result按原合同保留null；这不证明0次实际执行，也不把保守合同当成新bug或缺帧证据。可核整轮只是端点，不能认证单题全部后继或真实最优率。63项固定材料端点/算式核验通过，明细fixed-facts-verification.json；不冒称生产模型或tsc/vitest测试。

## 当前实际live子项

源码审计live切点**e138b036a79709f6217272e631324fd3e77e2bff**。17相关路径14个blob相同；card-model.ts、rollout-live.ts、sl/explore.ts只见历史Roy/Dai注释差异，保留精确blob和source-differences.patch，不说不同blob逐字节全等。所有审计路径在live无未提交改动，live各路径的实际祖先与SHA见source-audit.json。

- 96f17377a331e50ea5b6a3fe8d2b605932ed1bd4：幽灵一层效果；均为本base和实际live祖先。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：窄机制与审计集成；均为本base和实际live祖先。
- 8bb53d6342b7e9a2adf96de231b53c36eaa943de：另一个已观察修饰组合的恶魔毒药6毒；均为本base和实际live祖先。
- bf423c173d3be348a4ad714e1d26516df619ff41：普通生存者单弃；均为本base和实际live祖先。
- 222445a9bb6bf56cb4f3ceea2cc8b20fba54128f：毒胜前保血搜索；均为本base和实际live祖先。

现有observedPoison除双Boss外已有observedDemonPoison入口，所以“只有双Boss能模拟毒药”的旧笼统缺模理由不能沿用；该恶魔完整修饰组合不能认证7X0 F31其他目标/既有毒/重接组合。未知持有价已有silent-potion-reference区分，不将显示成本0当学出的留药价0。已有窄实现不关闭宽提案。

16条run-config记录的源码commit均实际存在，dirty_files仅列knowledge/notes；不能笼统说旧源码无法定位。当前没有冻结当时全部刷新知识/后续运行字节和完整联合消费者输入，不把当前tree当历史完整tree。

## 十项处置

- **silent-proposal-03754e1265894000：waiting。** 缺柔嫩、脆弱、翻倍及八组件联合消费者的完整固定校准，保留原行为。证据：RC61MFQM63Y6 F23T3/T4、F29T3/T4、F33T4。账本及原SHA见proposal.md对应项。

- **silent-proposal-ab055ef7dfbb44e5：waiting。** 幽灵一层已在live；夜魇可执行复制后继及延后饮药整战对照不足，宽提案waiting。证据：XTSV1U9JD34T F49六试T1/T3/T4。账本及原SHA见proposal.md对应项。

- **silent-proposal-0129c465c6f5bd79：waiting。** 单弃和毒胜保血已有live子项；接管内部执行、复制后继及联合候选完整归属仍缺证。证据：BTSRF7JL1W1Y F31T2；XTSV1U9JD34T F48T8/F49T1/T4。账本及原SHA见proposal.md对应项。

- **silent-proposal-abe9d5d0be109a9f：waiting。** 已核胜战掉血和连战入口；缺逐源资源消费者校准及同条件路线/留药/锻造完整对照。证据：BTSRF7JL1W1Y F30/F31；XTSV1U9JD34T F47—F49。账本及原SHA见proposal.md对应项。

- **silent-proposal-f16527e59b5cc1e0：waiting。** 覆甲、钳子与临时减力端点已核；临时属性撤回、毒触发和敌成长的联合分源生产回放不全。证据：BTSRF7JL1W1Y F17T5/F31T2/T3；XTSV1U9JD34T F48T8/F49T1—T4。账本及原SHA见proposal.md对应项。

- **silent-proposal-7a8e9ccb7e646538：waiting。** 缺完整候选归属、逐击未截断伤害及受控整战后继；T7净差和T8复活不能拟SL血价。证据：9Z9H2EXKLF3T F48第2/3试T7及末试T8/T10/T11。账本及原SHA见proposal.md对应项。

- **silent-proposal-cd9f76184de6e29a：waiting。** 22对回复成立；原116局资源模型到路线/休息消费者的完整校准和独立路线收益仍缺。证据：本批十锚点及提案原9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0；9Z9H2EXKLF3T F35/F38/F39/F42/F45/F47/F48。账本及原SHA见proposal.md对应项。

- **silent-proposal-292f6731bdb9b669：waiting。** 零毒后段实加7已核；缺其他目标、既有毒与重接组合共同推演校准，亦缺持有价/时点对照，不能统一扩scalar入口。证据：7X0W3U8TVA2A F31T13，decisions282021、states288470—288472。账本及原SHA见proposal.md对应项。

- **silent-proposal-0802f69b28d25079：waiting。** 已核少挡换伤的8血/6伤；缺独立A10留出和受控完整后继，不足以改变饱和探索/必死门槛。证据：MTQ0EUBJ3R6T F23四试T3、末试T5及F19/F20资源链。账本及原SHA见proposal.md对应项。

- **silent-proposal-763a4b9d9f17b815：waiting。** 十四项临时属性、持牌伤、能力与药效时点缺逐项至联合消费者的完整校准，不能整包duplicate。证据：7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T F17T4—T8/F20T3/F23T2—T5。账本及原SHA见proposal.md对应项。

## 交接与未实现原因

本批没有拟合权重、改变候选/排序、药水时点、必死/SL或终局值，也未更改其他角色。无源码提交；撤源码失败/恢复通过不适用，未运行tsc/vitest，tests为三个null。没有live合入尝试、冲突、合并提交、版本、上线记录或shipped；不制造空合并。

46个既有账本条目仅经根ledger.py update追加本批proposal/report追溯与复核note，不添加重复support/repeat、不改变原claim/first_run/prior/evidence/status/version，尤其不把旧shipped降为proposed。没有新增游戏规则就不发实际规则变更双通知。提案队列和learn.json由宿主消费proposal_results，本模型不手改状态。最终验收、CLI输出和secret扫描回执见本目录后续文件。

共同限制：未记录的逐击毛伤/未截断致死入伤、接管内部动作、未知抽序及可执行复制后继不能补齐；同局SL不是独立验证；替路线、休息/锻造、留药与延后用药缺受控后继；原十四/八组件联合校准未全覆盖。没有借报告完成关闭量化学习、入库或消费者父要求，没有声称大脑已采用或通关收益。

提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-061302/learner/runs/20261016-061312-21ce0b22-e1f9-4ee8-9f36-ce721c073548-strategy-proposal/proposal.md

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-061302/learner/runs/20261016-061312-21ce0b22-e1f9-4ee8-9f36-ce721c073548-strategy-proposal/report.md

机器回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-061302/learner/runs/20261016-061312-21ce0b22-e1f9-4ee8-9f36-ce721c073548-strategy-proposal/report.json

收尾验收：46条本批CLI追溯事件已读回；私有fold核旧claim/首证/prior/evidence/status/version及原history/notes/where前缀保持。gitleaks --redact对本目录约1.37GB材料扫描退出0、发现为空；HEAD仍c98e27e284f16402dd764f982003c08d3d52dce7，git status为空、tracked-diff.patch为0字节；十原ID各有非空waiting理由。报告只完成本批处置，不关闭原宽提案或父要求。

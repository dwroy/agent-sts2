import json, hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261016-014305-f051c87e-146b-4aa7-86d4-288461b9f317-postmortem'
run='JWK2C8LE4SFV'
files=['runs','decisions','run-plans','states','sl-attempts','brain','run-config','jev-reasoning','fight-plans']
manifest={}
for name in files:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists(): continue
 offset=0; count=0; digest=hashlib.sha256(); limit=p.stat().st_size
 with p.open('rb') as f, (out/f'{name}.jsonl').open('wb') as dst, (out/f'{name}-index.jsonl').open('w') as idx:
  for n,b in enumerate(f,1):
   start=offset; offset+=len(b)
   if offset>limit:break
   if run.encode() not in b:continue
   try:r=json.loads(b)
   except ValueError:continue
   count+=1; dst.write(b);digest.update(b)
   idx.write(json.dumps({'line':n,'offset':start,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})+'\n')
 manifest[name]={'rows':count,'sha256':digest.hexdigest(),'source_cutoff':limit}
 print(name,count,flush=True)
d=[json.loads(x) for x in (out/'decisions.jsonl').open()]
ts=[x['ts'] for x in d]
start,end=min(ts),max(ts)
p=root/'logs/deepseek-reasoning.jsonl'; count=0; total=0
with p.open('rb') as f,(out/'deepseek-reasoning.jsonl').open('wb') as dst:
 for b in f:
  total+=1
  try:r=json.loads(b)
  except ValueError:continue
  if start<=r.get('ts','')<=end:dst.write(b);count+=1
manifest['deepseek-reasoning']={'rows':count,'scanned_rows':total,'window':[start,end]}
manifest['window']=[start,end]
(out/'extraction.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False),flush=True)

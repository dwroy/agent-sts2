import json,subprocess
from pathlib import Path
p=Path(__file__).parent;root=p.parents[2];run='JWK2C8LE4SFV'
base={'by':'learner:postmortem','character':'silent','first_run':run,'prior':'unknown','prior_runs':[],'status':'observed','where':{'lessons':[run]}}
items=[('violence-bug','add',{**base,'kind':'bug-infra','claim':'静默A10暴力三段攻击模板疯狂科学MAD_SCIENCE的ViolenceHits=3未被卡牌模型消费；F48首试T5及末试T8均预计13伤、实际同一动作扣39，少报26。只读live card-model.ts:905只取CalculatedHits/Repeat并回退1，:906只认两次文字；此项与休眠Block误算分账。仅覆盖本局未升级、1力量、基础12/当前13的三段现场，未证明修正后整战可胜。','evidence':[{'run':run,'floor':48,'turn':5,'role':'support','note':'首试d403288候选damage13，s416380→416381敌201→162；末试T8 d403579预计13，s416671→416672敌104→65。两次单动作39，现场文本13伤3次、ViolenceHits3、STRENGTH_POWER1。live cfa1c0be，agent/src/reflex/card-model.ts:905。'}],'prior_note':'已按ViolenceHits、暴力、MAD_SCIENCE及疯狂科学查静默账本和更早静默复盘；旧0138只有其他定制模板，未找到此前三段模板的可比实打/预测证据，不能用其他角色的暴力事件作先验。'}),
('dormant-block-repeat','update',{'id':'silent-0394','by':'learner:postmortem','where':{'lessons':[run]},'evidence':[{'run':run,'floor':48,'turn':5,'role':'repeat','note':'首试d403288护栏后候选33挡/损0；s416380→416381疯狂科学只使余像挡0→1，休眠Block当前10未生效，完整MAD_SCIENCE/BURST/FASTEN/DEFLECT末23挡，对32损9，60→51。末试T8 d403579损21，实25挡对56需损31，再差10。旧已修仅12伤2弱2易伤模板；本局三段模板越出窄修复范围，同类休眠字段缺陷复现，不声称旧模板回退。live card-model.ts:877—907。'}],'note':'本次仅追加三段攻击模板的同类缺陷复现；保留原claim、first_run、prior、shipped及S1.legacy17-1，未证明修后胜负。两份fix-queue未检得本三段变体。'}),
('legion-repeat','update',{'id':'silent-0179','by':'learner:postmortem','where':{'lessons':[run]},'evidence':[{'run':run,'floor':48,'turn':6,'role':'repeat','note':'首试d403293完整BURST/PRECISE_CUT/BACKFLIP/STRIKE_SILENT+/DEFEND_SILENT报损0；s416385→416391实51→34，后空翻原预览14，重复实14+7牌挡/2余像，后续防御预览22→11，末38挡对55实损17。2敏捷和FASTEN4不满足live combat-plan.ts:5059/5061的0或3敏捷、2*(5+dex)识别门，士兵只消费一次未进入整线。无MAD_SCIENCE参与，独立于休眠Block。'}],'note':'旧0179一次翻倍消费缺口在2敏捷+勒紧4的新组合边界复现，非旧0/3敏捷窄范围回退；保留原首证、先验和S1.fix33已上线历史，未将17血模型误差冒作实际收益。'}),
('violence-mechanic','add',{**base,'kind':'mechanic','claim':'本局静默A10暴力攻击版疯狂科学MAD_SCIENCE为1费未升级攻击，基础Damage12、玩家1力量时当前Damage13、ViolenceHits3；两个独立动作均对无格挡第二阶段实验体实际扣39。它不提供同时携带的休眠Block当前10，也不实际建立专长、削弱或紧勒模板效果。只认本局该现场，不从同ID动态字段推未启用效果或未知升级。','evidence':[{'run':run,'floor':48,'turn':5,'role':'support','note':'s416380牌面13伤3次/Block10/ViolenceHits3，敌201无挡；s416381敌162、我方挡0→1仅余像。末试T8 s416671→416672再次104→65、挡0→1；力量1来自本局金刚杵。'}],'prior_note':'静默旧账本0103/0136/0138/0396区分其他疯狂科学模板；未检到本三段攻击模板的更早同角色实测，故prior unknown，不把制作选项原文当作已执行。'})]
receipts=[]
for name,command,item in items:
 (p/f'ledger-{name}-input.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n')
 if command=='update':
  r=subprocess.run(['python3',str(root/'learner/ledger.py'),'show',item['id']],text=True,capture_output=True,check=True)
  (p/f'ledger-{item["id"]}-before.json').write_text(r.stdout)
 r=subprocess.run(['python3',str(root/'learner/ledger.py'),command],input=json.dumps(item,ensure_ascii=False)+'\n',text=True,capture_output=True)
 receipt={'name':name,'command':command,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 (p/f'ledger-{name}-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');receipts.append(receipt)
 print(name,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(p/'ledger-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')

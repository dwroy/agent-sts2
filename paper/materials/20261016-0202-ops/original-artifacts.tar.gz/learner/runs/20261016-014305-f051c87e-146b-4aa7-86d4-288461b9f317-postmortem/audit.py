import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()];DI=[json.loads(x) for x in (p/'decisions-index.jsonl').open()]
S=[json.loads(x) for x in (p/'states.jsonl').open()];SI=[json.loads(x) for x in (p/'states-index.jsonl').open()]
R=json.loads((p/'JWK2C8LE4SFV-resources.json').read_text())
O=[]
def emit(s):O.append(str(s))
jev=[d for d in D if d['decider']=='jev'];cp=[d for d in jev if d['label'].startswith('combat/')]
emit(('deciders',collections.Counter(d['decider'] for d in D)))
emit(('low',len([d for d in jev if d.get('confidence') is not None and d['confidence']<.35]),collections.Counter(d['label'] for d in jev if d.get('confidence') is not None and d['confidence']<.35)))
emit(('best',len(cp),collections.Counter(d.get('rollout_best_chosen','missing') for d in cp)))
actions=[d for d in D if d['label'].startswith('combat/') and (d.get('chosen') or {}).get('action') and not d.get('result','').startswith('not dispatched')]
code=[d for d in actions if d['decider']=='code' and d['label']!='combat/plan-continue']
key=lambda d:(d['floor'],d.get('sl_attempt') or 1,d['turn'])
emit(('code decisions/turns/all turns',len(code),len({key(d) for d in code}),len({key(d) for d in actions})))
emit(('continues',collections.Counter(('jev' if 'Jev-chosen' in d['rationale'] else 'code') for d in D if d['label']=='combat/plan-continue')))
emit(('fallback',collections.Counter(str(d.get('fallback')) for d in D)))
for d,i in zip(D,DI):
 if d.get('hp_guard'):emit(('GUARD',i['line'],d['hp_guard']))
 if (d.get('chosen') or {}).get('action') in ['use_potion','discard_potion','buy_potion'] or 'potion' in d['label'] and not d['label'].startswith('combat/'):
  emit(('POTION',i['line'],d['ts'],d['floor'],d['turn'],d.get('sl_attempt'),d.get('expect'),d['rationale'],d['chosen'],d['result']))
for w in R['combats']:
 f=w['floor'];a=w['entry']['line'];z=(w['exit'] or w['last'])['line']
 frames=[(r,i) for r,i in zip(S,SI) if a<=i['line']<=z]
 names={e['enemy_id']:e['name'] for r,i in frames for e in (r['state'].get('combat') or {}).get('enemies',[])}
 emit(('NAMES',w['sequence'],names))
 if f not in [17,33,37,48]:continue
 byturn={}
 for r,i in frames:byturn.setdefault(r['state'].get('turn'),[]).append((r,i))
 for t,rs in byturn.items():
  r,i=rs[0];rr,ii=rs[-1];st=r['state'];en=(st.get('combat') or {}).get('enemies',[])
  aft=next(((n,j) for n,j in zip(S,SI) if j['line']>ii['line']),None)
  endhp=(aft[0]['state']['run']['current_hp'] if aft and (aft[0]['state']['run']['floor']==f and aft[0]['state'].get('turn')!=1) else None)
  enlast=(rr['state'].get('combat') or {}).get('enemies',[])
  emit(('TURN',w['sequence'],f,t,f"s{i['line']}—{ii['line']}",'HP',st['run']['current_hp'],endhp,'en-start',[(e['enemy_id'],e['current_hp'],e['max_hp']) for e in en], 'en-last',[(e['enemy_id'],e['current_hp'],e['max_hp']) for e in enlast]))
(p/'audit.txt').write_text('\n'.join(O)+'\n')
O=[]
for r,i in zip(S,SI):
 st=r['state'];run=st.get('run') or {};co=st.get('combat') or {}
 if co.get('player') is None:continue
 relics=run.get('relics',[])
 if run.get('floor')==48 and st.get('turn') in [5,6] and i['line']<416400:
  emit(('LEGION',i['line'],st['turn'],[(x.get('relic_id'),x.get('stack'),x.get('is_active')) for x in relics if x.get('relic_id')=='PAELS_LEGION']))
for r,i in zip(D,DI):
 if i['line'] in [403271,402730,403026]:
  q=(r.get('questions') or {}).get('plan') or {}; cr=q.get('criteria') or {};emit(('CANDIDATE',i['line'],list(cr)))
  for k,v in list(cr.items())[:2]:emit((k,v))
(p/'candidate-examples.txt').write_text('\n'.join(O)+'\n')
print('审计摘要已保存')

import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()]
I=[json.loads(x) for x in (p/'decisions-index.jsonl').open()]
S=[json.loads(x) for x in (p/'states.jsonl').open()]
SI=[json.loads(x) for x in (p/'states-index.jsonl').open()]
R=json.loads((p/'JWK2C8LE4SFV-resources.json').read_text())
lines=[]
def emit(x):lines.append(str(x))
emit('决策字段 '+str(list(D[-3])))
for d,i in zip(D,I):
 if not d['label'].startswith('combat/') and d['decider']=='codex':
  emit(f"d{i['line']} F{d['floor']} {d['label']} chosen={d.get('chosen')} reason={d.get('rationale')}")
(p/'build.txt').write_text('\n'.join(lines)+'\n');lines=[]
for j,r in enumerate(R['combats']):
 emit(f"战斗{r['sequence']} F{r['floor']} {r['enemies']} entry={r['entry']} exit={r['exit']} last={r['last']} end={r['end']} net={r['observed_net_hp_loss']}")
 for t in r.get('enemy_hp_audit',{}).get('turns',[]):
  emit({k:v for k,v in t.items() if k!='transitions'})
emit('SL')
for r in R['sl_events']:emit(r)
(p/'resources.txt').write_text('\n'.join(lines)+'\n');lines=[]
for d,i in zip(D,I):
 j=d.get('journal') or {}
 if d['label'].startswith('combat/') and ('guard' in d.get('rationale','').lower() or any('guard' in k.lower() for k in j)):
  emit({'line':i['line'],'floor':d['floor'],'turn':d['turn'],'attempt':d.get('sl_attempt'),'label':d['label'],'rationale':d['rationale'],'journal':j})
(p/'guards.txt').write_text('\n'.join(lines)+'\n');lines=[]
for d,i in zip(D,I):
 if d['floor']==48:
  emit(f"d{i['line']} {d['ts']} A{d.get('sl_attempt')} T{d['turn']} {d['decider']} {d['label']} {d['rationale']} chosen={d.get('chosen')} result={str(d.get('result'))[:280]}")
(p/'death-decisions.txt').write_text('\n'.join(lines)+'\n');lines=[]
for s,i in zip(S,SI):
 st=s['state']; r=st.get('run') or {};co=st.get('combat') or {}
 if r.get('floor')==48:
  enemies=co.get('enemies',[]);player=co.get('player') or {}
  emit(f"s{i['line']} {s['ts']} T{st.get('turn')} {st['screen']} HP={r.get('current_hp')}/{r.get('max_hp')} player={player} enemies={[(e.get('name'),e.get('enemy_id'),e.get('current_hp'),e.get('max_hp'),e.get('block'),e.get('powers'),e.get('intents')) for e in enemies]}")
(p/'death-states.txt').write_text('\n'.join(lines)+'\n')
print('已保存构筑、逐战资源、护栏和终战明细')
print('journal keys',collections.Counter(k for d in D for k in (d.get('journal') or {})))
print('sample chosen',D[-3]['chosen']);print('sample expect',D[-3]['expect']);print('sample result',str(D[-3]['result'])[:800])
print('combat keys',list((S[-3]['state'].get('combat') or {})))
for n in ['brain','run-plans','sl-attempts']:
 rr=json.loads(next((p/f'{n}.jsonl').open())); print(n,'keys',list(rr))
 if n=='sl-attempts':print('sl summary', {k:v for k,v in rr.items() if k not in ['turns','memo','snapshots','decisions','explore','judge','replay'] and len(str(v))<1500})
 elif n=='brain':print({k:v for k,v in rr.items() if k in ['engine','model','effort','accepted','usage','ts','label','question_id']})

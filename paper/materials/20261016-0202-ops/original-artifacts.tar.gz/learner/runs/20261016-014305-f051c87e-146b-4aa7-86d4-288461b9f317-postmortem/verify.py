import json,hashlib
from pathlib import Path
p=Path(__file__).parent;root=p.parents[2]
checks=0
for name in ['runs','states','decisions','run-plans','brain','sl-attempts','run-config']:
 with (root/'logs'/f'{name}.jsonl').open('rb') as src, (p/f'{name}.jsonl').open('rb')as selected:
  for b,ix in zip(selected,map(json.loads,(p/f'{name}-index.jsonl').open())):
   src.seek(ix['offset']);original=src.read(ix['bytes'])
   assert original==b and hashlib.sha256(original).hexdigest()==ix['sha256'],(name,ix)
   checks+=1
D={i['line']:r for i,r in zip(map(json.loads,(p/'decisions-index.jsonl').open()),map(json.loads,(p/'decisions.jsonl').open()))}
S={i['line']:r['state'] for i,r in zip(map(json.loads,(p/'states-index.jsonl').open()),map(json.loads,(p/'states.jsonl').open()))}
assert len(D)==1048 and len(S)==1103
assert (S[416674]['run']['current_hp'],S[416674]['combat']['player']['block'])==(28,25)
e=S[416674]['combat']['enemies'][0]
assert(e['current_hp'],e['max_hp'],e['intents'][0]['total_damage'])==(65,212,56)
assert S[416675]['screen']=='GAME_OVER' and S[416675]['run']['current_hp']==0
assert 56-25==31 and 31-28+1==4
for a,b in [(416380,416381),(416671,416672)]:
 assert S[a]['combat']['enemies'][0]['current_hp']-S[b]['combat']['enemies'][0]['current_hp']==39
assert S[416380]['combat']['player']['block']==0 and S[416381]['combat']['player']['block']==1
assert D[403288]['selection_audit']['after_sl']['turn']['block_gained']==33
assert S[416384]['combat']['player']['block']==23 and S[416385]['run']['current_hp']==51
assert S[416385]['run']['current_hp']-S[416391]['run']['current_hp']==17
assert S[416390]['combat']['player']['block']==38
assert 'hp -0' in D[403293]['rationale']
assert [D[i]['expect'].get('card',{}).get('id')for i in range(403293,403298)]==['BURST','PRECISE_CUT','BACKFLIP','STRIKE_SILENT','DEFEND_SILENT']
J=[d for d in D.values()if d['decider']=='jev'];assert len(J)==302
assert sum(d['confidence']<.35 for d in J)==40
C=[d for d in J if d['label'].startswith('combat/')];assert len(C)==238
assert sum(d.get('rollout_best_chosen')is True for d in C)==222
assert sum(d.get('rollout_best_chosen')is False for d in C)==14
assert sum((d.get('chosen')or{}).get('action')=='use_potion' for d in D.values())==15
assert sum((d.get('chosen')or{}).get('action')=='discard_potion' for d in D.values())==0
assert sum('HP guard:' in d.get('rationale','')for d in D.values())==1
assert not any((d.get('expect')or{}).get('card',{}).get('id')=='ROLLING_BOULDER' for d in D.values()if d['floor']==48)
R=json.loads((p/'JWK2C8LE4SFV-resources.json').read_text());assert len(R['combats'])==25
assert sum(w['exit'] is None for w in R['combats'])==5 and all(w['entry_is_turn_one']for w in R['combats'])
assert [x['turns']for x in map(json.loads,(p/'sl-attempts.jsonl').open())if x['floor']==48]==[10,10,8,10,10,8]
claims={'raw_rows_verified':checks,'numeric_assertions':'passed','decisions':1048,'states':1103,'combats':25,'missing_exits':5,'code_changed':False}
(p/'verification.json').write_text(json.dumps(claims,ensure_ascii=False,indent=2)+'\n');print(json.dumps(claims,ensure_ascii=False))

import json,subprocess
from pathlib import Path
p=Path(__file__).parent.resolve();root=p.parents[2];run='JWK2C8LE4SFV'
common='''
角色与边界：静默猎手，实证进阶A10。来源任务postmortem，原批次20261016-014305-f051c87e-146b-4aa7-86d4-288461b9f317-postmortem；目标为独立strategy-proposal实现任务，本复盘任务不修改源码。授权沿Roy-2026-10-07-learning。只改已核条件的模型，不添加人定游戏知识，不改变其他角色和未观察条件。

固定输入：本目录extraction.json、states/decisions及其原文件行号/字节偏移/逐行SHA、JWK2C8LE4SFV-resources.json、verified-resources.json、verification.json；源码对照为live cfa1c0be88147b4eac65c13d8c550b23ed4eef17，三个相关源码叶SHA见source-manifest.json，live-source.diff为空。不把运行时dirty知识或当前源码等同于完整历史环境。

方法与样本切分：这是字段消费/状态推进修正，不拟合HP价值、药价、SL阈值或胜率。以本局启动2026-10-15T15:33:04.410Z为时间边界，边界前仅查同角色既有经验以防重复，边界后以实际相邻帧核验；同局多次SL和同牌多次动作不当独立对局样本，不声称有独立后移留出。固定测试先复现错误、撤修复转红、恢复转绿，再跑规定沙箱检查；本任务仅核记录，未执行策略改动或测试。

实现与回退：实现者通过strategy-proposal接续，核最新live知识冲突、限定源码、自测、实际合入及版本/通知沿既定流程；不能把本提案登记为implemented或shipped。预期改善所列局部事实及其上游比较，不承诺自然收益或整战可胜；回退对应源码提交可恢复旧模型，保留原始日志、失败、账本及提案，不改运维prompt。
'''
items=[
('violence-hits',['silent-0487','silent-0488'],'修复已实测三段疯狂科学的ViolenceHits消费，13伤单段预测应覆盖实打39伤', '''# 三段攻击模板疯狂科学的命中次数

关联账本：silent-0487（新模型bug）、silent-0488（实际机制）。证据JWK2C8LE4SFV／A10／F48首试T5及第六试T8。

旧行为：agent/src/reflex/card-model.ts:905只读CalculatedHits/Repeat，:906只补“两次”；本局牌面13伤3次、ViolenceHits3，却按一击13。新行为：对本局已核的未升级三段攻击模板消费实际激活的ViolenceHits=3，按当前Damage13逐击计算；不要重复加入已含的1力量，也不要拿休眠ViolenceHits为所有MAD_SCIENCE增加攻击。

实际核验：首试s416380→416381敌201→162，第六试s416671→416672敌104→65，均无敌挡且同一动作扣39。d403288／403579对应候选仅13，少26；两次动作均只有余像1挡。卡牌完整动态字段、resolved_rules_text及原选线均保存在抽取输入。

反例与限制：旧专长2力量2敏捷、削弱攻击、攻击紧勒、技能格挡等模板不是三段牌；它们也可携带休眠ViolenceHits，不能只查字段存在。已看到两次同局动作，其他力量、脆弱/易伤、敌挡、多目标、升级或新增定制结果未隔离；保持旧行为/显式未知，不拟合通用模板解析器。本提案只修命中次数，休眠Block另案，不把修后局部多计26当实战多打26或胜利反事实。

固定验证：从上述原帧构造最小输入，当前13、修后39；用既有其他同角色模板为负控，未激活暴力字段保持原次数；核当前伤害不再二次加力量，其他角色保持等价。完整战斗重放/未选分支胜负缺失，须写未知，不能藉单点修正放开模型信任或SL阈值。
'''),
('dormant-block',['silent-0394'],'把三段攻击疯狂科学的休眠Block排除，修护栏33挡预测与实际23挡的10点差', '''# 三段攻击疯狂科学的休眠格挡

关联账本：silent-0394；本局为旧休眠字段缺陷的新模板复现，保留S1.legacy17-1和原削弱模板已修历史。证据JWK2C8LE4SFV／A10／F48首试T5、第六试T8。

旧行为：live card-model.ts:877—900仅识别专长/固定削弱模板，:907对其他MAD_SCIENCE直接读取Block。本局三段攻击仍携带基础8、当前10，实打没有该格挡；建议限定已核三段攻击模板使休眠Block不进入卡牌格挡。不要把本修正扩成所有定制牌一律0挡，也不改变真实技能格挡模板。

实际核验：s416380玩家60血0挡，敌201/212；科学后s416381仅余像使挡到1、敌162。d403288护栏后整线MAD_SCIENCE/BURST/FASTEN/DEFLECT报33挡/损0；d403288—403291完整执行，s416384末23挡，对32攻后s416385 HP51，真实损9。10点虚挡足够解释预测差，其中1点原富余。末试T8 d403579报损21，s416674实25挡对56须损31；此时也差10。攻击少算26由另一提案负责，不与此归因相加为整战收益。

反例与缺数据：旧削弱12伤/2弱/2易伤模板已修范围保持；专长、技能格挡、其他已知及未知定制模板均按其现场证据分账。本次没有同一初始状态重打原Jev线，故不能认定护栏实际浪费/保留9血，不能声称修后可胜。窄模板外的休眠/激活字段组合仍需真实证据。

固定验证：冻结首试T5原输入，卡牌本体格挡为0、余像触发仍1，整线33→23、损0→9；冻结末试T8整线须损31而非21。把休眠Block8/10与卡牌类型、实际resolved文本匹配校验；原技能格挡版本、已修削弱模板及其他角色做等价负控。护栏阈值、排序和SL政策保持，后继整战未知。
'''),
('legion-consumption',['silent-0179'],'扩展士兵一次翻倍消费到本局2敏捷/勒紧4及爆发重放的已核边界', '''# 士兵在2敏捷、勒紧4和技能重放下的一次消费

关联账本：silent-0179，原S1.fix33不降级；新证据仅补已上线窄识别之外的组合。证据JWK2C8LE4SFV／A10／F48首试T6。

旧行为：combat-plan.ts:5059限定普通防御且敏捷0或3，:5061限定预览2*(5+dex)。本局DEXTERITY_POWER2、FASTEN_POWER4使门失效；turn-solver.ts:2174未获得一次消费状态，把多个当前翻倍预览当各自收益。建议只在本局已实测且原帧可证待触发的士兵组合中，沿真实卡牌格挡的第一次结算消费翻倍；同牌爆发重放也必须读消费后的状态。不要猜固定冷却或把余像/遗物挡当卡牌格挡。

实际核验：d403293计划BURST/PRECISE_CUT/BACKFLIP/STRIKE_SILENT+/DEFEND_SILENT报损0；s416385两敏捷、勒紧4，后空翻预览14、防御22。s416387原挡2；后空翻重复后s416388挡25：第一次牌挡14、重复7及余像两次合23；s416389打击后26，s416390防御后38：该牌11和余像1。55攻击后s416391从51到34实损17。无MAD_SCIENCE参与，独立于其休眠Block和多段预测错误；额外预览7+11共18，其中1点原富余，解释17血差。

反例与缺数据：旧SADL/0NZX的0/3敏捷普通防御以及G4PQ无防御手牌边界保留原证据，不重写首证或假称全覆盖。未验证其他敏捷、脆弱、暗影、不同勒紧、升级防御、多种翻倍叠加、无明确待触发标志及跨回合冷却；现有缺口继续显式未知，不能从本例外推全部。没有模型修正后的同抽序整战结局，17是预测误差，不是已经挽回的资源。

固定验证：上述冻结原帧当前线损0、修后末挡38/损17，逐次格挡和爆发计数与实帧一致；核同一原预览只消费一次、余像触发保持、其他角色及已覆盖0/3敏捷原例等价。避免仅改显示数字而后继模拟仍沿旧预览；没有合格跨轮来源则保留限制，不扩大模型信任、HP价值或SL政策。
''')]
receipts=[]
for name,ledger,summary,body in items:
 path=p/f'proposal-{name}.md';path.write_text(body+common)
 item={'character':'silent','ledger':ledger,'runs':[run],'source_task':'postmortem','target_task':'strategy-proposal','domains':['combat'],'summary':summary,'proposal':str(path),'rule_changes':False,'authorization':'Roy-2026-10-07-learning'}
 (p/f'proposal-{name}.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n')
 r=subprocess.run(['python3',str(root/'learner/code_proposals.py'),'add','--character','silent'],input=json.dumps(item,ensure_ascii=False)+'\n',text=True,capture_output=True)
 receipt={'name':name,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'input':str(p/f'proposal-{name}.json')}
 (p/f'proposal-{name}-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');receipts.append(receipt)
 print(name,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(p/'proposal-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')

from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,tarfile

root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0202';pub=r/'paper/materials/20261016-0202-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
bid='20261016-014301';run='JWK2C8LE4SFV';s=r/'learner/runs/20261016-014305-f051c87e-146b-4aa7-86d4-288461b9f317-postmortem';report=load(s/'report.json');assert report['appended']==[run] and len(report['bugs'])==1 and report['bugs'][0]['new'] and report['bugs'][0]['where']=='agent/src/reflex/card-model.ts:905'
assert report['ledger']['added']==['silent-0487','silent-0488'] and set(report['ledger']['updated'])==set(report['ledger']['repeats'])=={'silent-0394','silent-0179'} and report['ledger']['check']==0
b=load(r/'ops/codex-ops/learn.json')['batches'][bid];assert b['state']=='done' and b['rc']==0 and b['done']==[run] and not b['missing'] and not b['proposal_audit_errors']
out=r/'ops/codex-ops/learner'/(bid+'.out');output=out.read_text();supplied=json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1]);assert {k:v for k,v in report.items() if k!='bugs'}=={k:v for k,v in supplied.items() if k!='bugs'} and [(x['run'],x['where'],x['new']) for x in supplied['bugs']]==[(x['run'],x['where'],x['new']) for x in report['bugs']]
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output)
refs=[];counts={};brains=[];runrow=None;config=None;extraction=load(s/'extraction.json')
for stream in ['runs','states','decisions','sl-attempts','run-config','run-plans','brain','fight-plans']:
    frozen=(s/(stream+'.jsonl')).read_bytes();assert sha(frozen)==extraction[stream]['sha256']
    indices=[json.loads(x) for x in (s/(stream+'-index.jsonl')).read_text().splitlines()];lines=frozen.splitlines(keepends=True);assert len(indices)==len(lines)==extraction[stream]['rows']
    with (r/'logs'/(stream+'.jsonl')).open('rb') as original:
        for e,line in zip(indices,lines):
            original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw);assert raw==line and sha(raw)==e['sha256']
            fp=row.get('fingerprint') or {};fp=json.loads(fp) if isinstance(fp,str) else fp;state=row.get('state') or {};sr=state.get('run') or {};ids=[x for x in [row.get('run_id'),row.get('run') if isinstance(row.get('run'),str) else None,state.get('run_id'),sr.get('run_id') if isinstance(sr,dict) else None,fp.get('run') if isinstance(fp,dict) else None] if x is not None];assert ids and all(x==run for x in ids)
            if stream=='states':assert sr['character_id']=='SILENT' and sr['ascension']==10
            if stream=='runs':assert row['character']=='SILENT' and row['ascension']==10 and row['floor']==48 and row['victory'] is False;runrow=row
            if stream=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains.append(row)
            if stream=='run-config':assert config is None;config=row
            refs.append(dict(stream=stream,line=e['line'],offset=e['offset'],bytes=len(raw),sha256=sha(raw)))
    counts[stream]=len(lines)
assert len(refs)==2225 and counts['decisions']==1048 and counts['states']==1103 and len(brains)==50
verification=load(s/'verification.json');completion=load(s/'completion-validation.json');assert verification['numeric_assertions']=='passed' and verification['raw_rows_verified']==2225 and verification['combats']==25 and verification['missing_exits']==5 and verification['code_changed'] is False
assert completion['identities_verified'] and completion['lessons_old_prefix_preserved'] and completion['section_count']==1 and completion['append_bytes']==20736 and completion['ledger_check']==0 and completion['proposals_pending']==3 and completion['errata_needed'] is False
assert sha((s/'report.md').read_bytes())==completion['report_sha256']
source=load(s/'source-manifest.json')
for path,x in source['files'].items():raw=git('show',source['commit']+':'+path);assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
prior=load(s/'lessons-before.json');physical=(r/'notes/lessons.md').read_bytes();assert sha(physical[:prior['bytes']])==prior['sha256'];lesson=(s/'appended-section.md').read_bytes();assert len(lesson)==20736 and physical[prior['bytes']:prior['bytes']+len(lesson)]==lesson and physical.count(b'## JWK2C8LE4SFV')==1;(p/'owned-lessons.md').write_bytes(lesson)
ids=set(report['ledger']['added']+report['ledger']['updated']);owned=[];ledgerrefs=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('by')=='learner:postmortem' and row.get('id') in ids and (any(x.get('run')==run for x in row.get('evidence',[])) or str(s) in json.dumps(row,ensure_ascii=False) or run in row.get('where',{}).get('lessons',[])):
            if row['op']=='add':assert row['id'] in report['ledger']['added'] and row['first_run']==run and row['prior']=='unknown' and row['status']=='observed'
            else:assert row['op']=='update' and set(row)<={'op','id','ts','by','evidence','where','note'}
            assert all(x['run']==run for x in row.get('evidence',[]));owned.append(raw);ledgerrefs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==8 and sum(json.loads(raw)['op']=='add' for raw in owned)==2 and sum('evidence' in json.loads(raw) for raw in owned)==4
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned))
spec=importlib.util.spec_from_file_location('original_proposals',r/'learner/code_proposals.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);queue=module.fold(r/'paper/materials/learning/code-proposals.jsonl');proposals=[]
for ident in report['code_proposals']:
    q=queue[ident];f=Path(q['proposal']);assert q['character']=='silent' and q['runs']==[run] and q['source_task']=='postmortem' and q['target_task']=='strategy-proposal' and f.is_relative_to(r) and sha(f.read_bytes())==q['proposal_sha256'];proposals.append({k:q.get(k) for k in ['id','state','proposal','proposal_sha256','ledger','implemented_commit']})
queuepath='notes/fix-queue-v4.md';existing=(r/queuepath).read_text();assert 'silent-0487' not in existing
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
addition=f'\n- [ ] **silent-0487：非阻塞三段攻击模型缺口，仅转录学习者证据**。JWK2C8LE4SFV SILENT A10 F48首试T5及末试T8，疯狂科学MAD_SCIENCE现场Damage12/当前13、ViolenceHits3、1力量；d403288/d403579均预计13伤，s416380→416381敌201→162、s416671→416672敌104→65，两次单动作均39，少报26。学习者定位只读livecfa1c0be agent/src/reflex/card-model.ts:905只取CalculatedHits/Repeat并回退1，:906只认两次文字；按原silent-proposal-0a0b31e284e6793e独立策略链核固定模板命中次数与未知边界，不由运维修游戏模型。关联机制silent-0488与休眠Block旧缺陷0394分账；0394三段变体及0179士兵2敏捷/勒紧组合复现分别沿原a43b16ebc696514d/ad6953c6c875117d，不把旧已修窄范围标回退/重开或降级shipped。修正后整战胜负未知，不把模型少报等同实际少打。原件learner/runs/20261016-014305-f051c87e-146b-4aa7-86d4-288461b9f317-postmortem/；不另派重复任务。 {at}\n'
with (r/queuepath).open('ab') as handle:handle.write(addition.encode())
write(p/'queue-appends.json',{queuepath:addition})
write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,original_stdout_report=supplied,native=native,original_rows_checked=len(refs),stream_counts=counts,actual_accepted_codex=50,original_run_row=runrow,actual_run_config=config,source_reference=source,original_verification=verification,original_completion=completion,original_lesson_bytes=20736,lessons_prefix_preserved=True,original_ledger_rows=8,new_ledger_ids=report['ledger']['added'],repeated_old_ids=report['ledger']['repeats'],original_proposals=proposals,new_nonblocking_queue_entry='silent-0487',existing_repeat_statuses_preserved=True,source_reference_does_not_prove_complete_dirty_knowledge=True,limits='Complete per-hit/overkill and phase-transition frames, five pre-SL exit settlements, actual counterfactual guard savings, unselected and model-corrected outcomes, consumed dirty knowledge bytes, calibrated clock/second Boss, pure combat time, Jev cache and invoices remain unknown.'))
write(pub/'postmortem-original-references.json',refs);write(pub/'owned-ledger-references.json',ledgerrefs);artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);print(json.dumps(dict(rows=2225,ledger_rows=8,lesson_bytes=20736,new_bug='silent-0487')))

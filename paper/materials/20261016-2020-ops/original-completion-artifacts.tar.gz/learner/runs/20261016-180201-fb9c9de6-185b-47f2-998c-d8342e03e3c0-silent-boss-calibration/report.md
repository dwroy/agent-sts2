# 20261016-180201-fb9c9de6-185b-47f2-998c-d8342e03e3c0-silent-boss-calibration

Roy已授权新功能静默boss模拟校准的定期刷新；fix-batch是调度通道。

数据来源提交：f2617b958e425817ca079ff25a5e95484b5096ba；实际live合入：8b65dafb808eb54e965fc1c6c613462fad82306c；发布：3f81fcbbdd04a57a38c17c2dcb8cb200ad7bb938；固定发布树：8ecee7cbe5526f10f90ccbe4a65f517707d5ee03。
专题版本：S1.boss-calibration21；统一release_id由ops核实际提交分配。账本silent-0497仅由学习者登记proposed及出处，shipped由ops确认。

冻结327个结束SILENT局/1425次boss尝试/588场可用；新增21场/12局，结局{'won': 14, 'died': 7}。固定107调参、验证460→481，切点与调参keys/Platt/进阶项选择不移动。
模型7e1193cef9467416bc10c8e344a49f4fd98390c7，209个仓库输入逐SHA与提交一致，外部game-data另核SHA；200样本/起点、seed=1+原全量行号×101。新增只扩验证，4个历史对照起点除耗时完全相同。
初始索引缺JH49PP3EYJH8六事件；live常规索引追上后只在原冻结runs/SL字节内恢复6尝试/1实际结局，原587场和逐回合输入核同。初始缺帧资料和恢复凭据均保留，未写原日志或DB。
B2/B3 Brier=0.112/0.1146；A10残差=0.03700000000000003/0.040000000000000036，打穿比=1.319/1.336。
A0–4和A5–9独立验证各0、各缺10场；只保留其调参残差。F48战胜不等于整局通关；F49独立四项准入，未估计连战联合胜率。
名单变化{'b2': {'added': [], 'removed': []}, 'b3': {'added': [], 'removed': []}}；数量门槛保持10，所有boss均同时检查Brier、胜率差和打穿比。

| boss | B2 n/不足/失败指标 | B3 n/不足/失败指标 | B2/B3可信 |
|---|---|---|---|
| AEONGLASS | 35/0/brier,gap,leak | 35/0/brier,gap,leak | False/False |
| CEREMONIAL_BEAST | 40/0/无 | 40/0/无 | True/True |
| KAISER_CRAB | 46/0/brier,leak | 46/0/brier,leak | False/False |
| KNOWLEDGE_DEMON | 45/0/leak | 45/0/leak | False/False |
| LAGAVULIN_MATRIARCH | 40/0/无 | 40/0/无 | True/True |
| QUEEN | 31/0/brier,gap | 31/0/brier,gap | False/False |
| SOUL_FYSH | 37/0/无 | 37/0/无 | True/True |
| TEST_SUBJECT | 29/0/brier,leak | 29/0/brier,leak | False/False |
| THE_INSATIABLE | 46/0/leak | 46/0/brier,leak | False/False |
| THE_KIN | 42/0/无 | 42/0/无 | True/True |
| VANTOM | 48/0/无 | 48/0/无 | True/True |
| WATERFALL_GIANT | 40/0/无 | 40/0/无 | True/True |

F49验证n=31，数量缺口0；Brier=0.1821/0.1622，预测/实际=0.464/0.161、0.421/0.161，打穿比=2.704/2.814；继续低可信。

前置完整main可执行集合={'files': 445, 'cases': 4162, 'tsc': 0, 'vitest': 0}；数据刷新后定向夹具tsc/Vitest0，7文件/27项；live检查{'tsc': 0, 'vitest': 0, 'files': 445, 'cases': 4166, 'additional_cli_exclusions': ['tests/global-build-health.test.ts', 'tests/global-build-funnel.test.ts']}。Python校准12、自动化57、派发48；候选消费者28项、live消费者28项。
首轮live完整检查4154项通过，唯一原固定题60000ms超时已回退，原日志/失败树/原刷新保留；原题原时限单独36568ms通过，数据源未改后进行完整重试。
标准入口两次中断130：先发现旧历史副本65个缺引用，SHA保全1096项后恢复环境；再发现main新增Node子进程包装EPERM。最终使用原脚本，仅在命令行排除global-build-health/global-build-funnel两个包装，对应原Python固定夹具直接执行0且stdout为空。原固定排除名单、源码、测试断言与时限未改。标准130/包装EPERM不报通过；完整无排除检查由原调度器在沙箱外补跑。
默认刷新入口在提取阶段中断130以保留固定模型；增量重放保存29起点后串行续算。原日志、指纹、初稿及索引缺帧历史保留。
部署读回：{'source': 'f2617b958e425817ca079ff25a5e95484b5096ba', 'merged': '8b65dafb808eb54e965fc1c6c613462fad82306c', 'publication': '3f81fcbbdd04a57a38c17c2dcb8cb200ad7bb938', 'publication_tree': '8ecee7cbe5526f10f90ccbe4a65f517707d5ee03', 'source_paths_exact': 116, 'all_other_git_blobs_preserved': True, 'source_actual_live_ancestor': True, 'pinned_model_inputs_different_in_publication': 71, 'current_production_model_recalibrated': False, 'working_refresh_scope': {'notes/monster-db-check.md': '0c664fccfffdb651ca730f1ea5209aea035abdea1a2ca14e8b017de3ced3cb49'}, 'scope': 'Exact Git publication and consumer source/data; natural-game adoption and benefit remain unclaimed.'}；gitleaks：{'merge-main': 0, 'source': 0, 'refresh': 0, 'merge': 0, 'publication': 0}。
本表只验证冻结模型；当前生产与其不同的源码/知识未重新校准，不声称自然采用或胜率收益。费用、药水、保血、目标、SL阈值及铁甲数据保持。
定期入口agent/tools/boss-sim/refresh-silent.py，升阶或20个新实际boss结局触发；每小时:13/:43及学习完成事件检查。固定模型恢复入口restore-model.py；完整复现参数refresh-command.json。新指纹995fbdbd421116fc5aff5c375c35623cb939dcdb1f72a5877b6c03b8e91f3a7b，旧目录不覆盖；重复档案及阈值不足跳过，不派子进程且输出字节不变。
Roy提供隔离、模型复用、整体Platt、切分、准入门槛和刷新架构；样本、残差和可信结论来自结束SILENT日志。
报告paper/materials/silent/boss-sim-calibration.md；归档experiments/boss-sim/silent/995fbdbd421116fc5aff5c375c35623cb939dcdb1f72a5877b6c03b8e91f3a7b。
发布阻塞/回退：无。双通知以notification.json实际回执为准，不代填watcher/Roy ACK。
code_proposals=[]，implementation_domains=[]；不关闭学习宽父、自然消费者或收益验收。

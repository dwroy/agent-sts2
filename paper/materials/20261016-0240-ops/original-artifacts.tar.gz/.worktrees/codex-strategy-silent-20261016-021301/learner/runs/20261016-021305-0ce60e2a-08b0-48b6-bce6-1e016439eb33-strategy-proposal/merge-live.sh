#!/usr/bin/env bash
set -eu
root=/home/dw/Projects/agent-sts2
live="$root/.worktrees/live"
work="$root/.worktrees/codex-strategy-silent-20261016-021301"
out="$work/learner/runs/20261016-021305-0ce60e2a-08b0-48b6-bce6-1e016439eb33-strategy-proposal"
export TMPDIR="$out"
export PYTHONPYCACHEPREFIX="$out/pycache"
export PATH="$HOME/.local/node/bin:$PATH"
source_commit=$(cat "$out/source-commit.txt")
base=$(cat "$out/base.txt")
date '+%Y-%m-%d %H:%M:%S %Z'
exec 9>"$root/ops/live-merge.lock"
flock 9
date '+%Y-%m-%d %H:%M:%S %Z' > "$out/live-lock-acquired.txt"
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git -C "$live" status --short > "$out/live-status-before.txt"
git -C "$live" rev-parse HEAD > "$out/live-initial-head.txt"
if ! git -C "$live" diff --cached --quiet; then
  echo 'Existing staged live changes: leave them untouched.'
  exit 21
fi
git -C "$live" diff --name-only -- knowledge notes/fight-value-backtest.md > "$out/live-refresh-paths.txt"
git -C "$live" add notes/fight-value-backtest.md knowledge
if ! git -C "$live" diff --cached --quiet; then
  (cd "$live" && gitleaks git --staged --redact --report-format json --report-path "$out/gitleaks-refresh.json" .) > "$out/gitleaks-refresh.log" 2>&1
  git -C "$live" commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>' > "$out/live-refresh-commit.log" 2>&1
fi
git -C "$live" rev-parse HEAD > "$out/live-premerge-head.txt"
git -C "$work" diff --binary "$base" "$source_commit" > "$out/source-change.patch"
git -C "$work" diff --name-only "$base" "$source_commit" > "$out/source-change-paths.txt"
python3 - "$out" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
overlap=sorted(set((p/'live-refresh-paths.txt').read_text().splitlines()) & set((p/'source-change-paths.txt').read_text().splitlines()))
(p/'live-refresh-overlap.json').write_text(json.dumps({'overlap':overlap},ensure_ascii=False,indent=2)+'\n')
if overlap: raise SystemExit('Refresh overlaps this implementation: stop without replacing data.')
PY
set +e
git -C "$live" merge --no-edit "$source_commit" > "$out/live-merge.log" 2>&1
merge_rc=$?
set -e
printf '%s\n' "$merge_rc" > "$out/live-merge.exit"
if test "$merge_rc" -ne 0; then
  git -C "$live" diff --name-only --diff-filter=U > "$out/live-conflict-paths.txt"
  git -C "$live" ls-files --unmerged > "$out/live-unmerged-index.txt"
  git -C "$live" diff --binary -- agent/src/reflex/card-model.ts agent/src/reflex/combat-plan.ts agent/src/reflex/turn-solver.ts > "$out/live-source-conflicts.patch"
  if git -C "$live" rev-parse --verify -q MERGE_HEAD >/dev/null; then
    git -C "$live" merge --abort > "$out/live-merge-abort.log" 2>&1
  fi
  git -C "$live" rev-parse HEAD > "$out/live-after-abort-head.txt"
  cmp "$out/live-premerge-head.txt" "$out/live-after-abort-head.txt"
  git -C "$live" status --short > "$out/live-status-after-abort.txt"
  cat "$out/live-merge.log"
  echo 'Merge stopped; premerge knowledge refresh retained.'
  exit 20
fi
git -C "$live" rev-parse HEAD > "$out/live-merged-head.txt"
git -C "$live" merge-base --is-ancestor "$source_commit" HEAD
set +e
(cd "$live/agent" && SANDBOX_WORKERS=1 bash tools/test-sandbox.sh) > "$out/sandbox-live.log" 2>&1
test_rc=$?
set -e
printf '%s\n' "$test_rc" > "$out/sandbox-live.exit"
if test "$test_rc" -ne 0; then
  git -C "$live" reset --merge "$(cat "$out/live-premerge-head.txt")" > "$out/live-check-rollback.log" 2>&1
  git -C "$live" rev-parse HEAD > "$out/live-rollback-head.txt"
  tail -n 45 "$out/sandbox-live.log"
  exit 22
fi
tail -n 28 "$out/sandbox-live.log"
echo 'Merge and live checks passed; publication metadata still requires locked registration.'

# 静默A10：纸鹤在聚合体光束新施虚弱中的限定补模

本批：20261016-021301-strategy-proposal。基线：d523c467cb0e00cfbf181f4490ba6a4d0fbf1ba1。来源和实现任务均为strategy-proposal，依据原postmortem的既有代码提案 silent-proposal-0cce435d0d61ac93 实现，不另建重复提案。既有账本 silent-0469、silent-0070；本次实施的限定范围由 ledger CLI 登记为 silent-0489 / proposed，原已shipped条目及版本不降级。

## 身份和选题

根learn.json本批为task=strategy-proposal、character=silent、reason=tick，工作树匹配，没有proposal_ids、proposal_repair、research_request、implementation_request。根默认专题绑定另一批，不承接专题。初始树干净，git merge --no-edit main返回Already up to date，HEAD不变。原10局在runs.jsonl逐局核为SILENT/A10，派发key的A11不作为这些证据的进阶。没有领取别批提案。

从fix-queue-v4.md的silent-0469旧补证及其保存的Markdown选中本项。原骑士窄修复已有实现，本项是尚未覆盖的聚合体光束/普通突然一拳/玩家易伤组合，不声称骑士回归，不处理其他宽策略项。

## 原局证据

HLAWCGM3KHVB A10 F49 T3，原states第410804—410808行及decisions第398069—398072行。selected-evidence.json保存原source_size、offset、bytes、逐行SHA256和完整对象；逐条seek原日志，核实与旧材料一致，并核run_id/state.run_id/fingerprint.run不冲突。共用extract_evidence.py另外抽取本批10局的八个流，冻结截点见evidence/evidence-manifest.json。

- s410804：71/88HP、7挡、4能量；聚合体BEAM_MOVE意图12×3，只有MINION_POWER=1，无既有虚弱；玩家易伤99；纸鹤is_melted=false。普通突然一拳当前6伤、1虚弱、1能量。
- d398069：Jev实际答plan2，代码原rank2，完整线为狩猎→女王、突然一拳→聚合体、致命毒药→女王；题面hp_lost=18，预测剩53/88HP；首动作completed。
- s410805→410806：突然一拳使聚合体179→173HP，新增WEAK_POWER=1，同一招式意图12×3→7×3，玩家8→9挡。d398070为completed。
- s410807：三张牌全部完成，9挡、71HP；d398071与结束回合d398072均completed。s410808为T4开场59HP，故本回合实失12，21来袭减9挡=12。没有抽弃、随机分支或途中重规划替代这三步。

## 旧行为、新行为与消费者

原card-model只给中和/萎靡纸鹤来源标记，combat-plan仅认证两骑士招式，turn-solver新虚弱回退0.75。本题27来袭减9挡=18，高报6。现增加限定的普通突然一拳牌面来源及决策回合光束标记，仅在Silent/A10、未融化纸鹤、聚合体maxHp211/BEAM_MOVE/12×3/仅爪牙1、玩家易伤99，且手动单次原6伤1虚弱1费、目标原无虚弱及没有未观察伤害修正时，采用实际端点7×3。不是从一个含取整样本反推通用伤害公式。

单回合重放、describePlan题面、生产planCombatTurn求解输入和least-loss消费者共享该修正。已经显示7×3的下一决策帧不再乘第二次虚弱系数；原rollout已丢弃决策回合标记，后续招式不带入。SL门槛/药价/终局权重不改。铁甲和未观察进阶不发新标记，固定边界比较保持旧输出。

## 反例与未知

同局T4已经换为TACKLE_3_MOVE且力量变1，不能沿用T3端点；原s410808直接支持此边界。同局其他新虚弱窗口涉及不同敌人/招式/施放来源，不能用来扩大本次认证。已有虚弱、不同玩家易伤、减力、缩小、无实体纸鹤或融化状态、强化/免费/重放突然一拳都保原路径。原EBVT两试T1只是已上线骑士回归用例，不能当独立留出样本。

本次只有一个确定性完整回合，不做参数拟合；训练复现与验证不算两个独立样本。未来同条件自然局才可作为独立留出。目前没有自然新消费者、选线改变、整场省血、修后胜负收益或其他组合取整顺序的证据。14HP单牌测试是从原题构造的固定软件边界，不是实际救回本局。

## 验证与回退

固定原状态脱离刷新的知识JSON，生产建题入口捕获真实SolverInput，重放完整三步、狩猎后的后缀、已有虚弱后的后缀；核12失血、59HP、9挡、每击7及题面消费，保原伤害/药成本。覆盖无关角色/进阶、纸鹤状态、未知招式/力量/数值/重放/牌面边界，以及既有骑士15项。原源码逐字节副本为*.before.txt；撤掉本次三个源码，新六项中3失败、3通过，恢复后由沙箱完整入口验收。初稿误把魂缚耗尽的末帧当作会进入求解器，首失败日志保留，改为两个实际重规划中间帧。

预期影响仅为本已观察场景修正悲观预测，不承诺候选换选或通关。回退独立本次源码提交，保旧骑士修复和全部原日志/账本。自测、gitleaks、live合入与合后检查、版本和双通知均以report.md最终实际结果为准；不提前登记implemented/shipped。

## 最终实施回执

源码8d386fc7668820c2fc387d966f9d94bdcab189fb已提交，完整沙箱tsc0、438文件4110项通过，撤源码3败/恢复通过，gitleaks0。live完整分支合并遇18个记录/统计文件冲突，已abort并核实保留刷新提交3583a02b82f1176c73f38f4fa8725079fd3ee669；源码不是live祖先。未上线、未合后测试、无行为版本，不登记implemented/shipped。原提案waiting仅因集成阻塞，交ops按已测源码接续；详见report.md及integration-result.json。

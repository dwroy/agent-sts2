from pathlib import Path
import hashlib, importlib.util, json, re, subprocess, sys
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0240';pub=r/'paper/materials/20261016-0240-ops';pub.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f):return json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
bid='20261016-021301-strategy-proposal';batch=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=batch['report'];s=Path(report['report']).parent;source=report['fixes'][0]['commit'];parent=report['base']
out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report==load(s/'report.json')
assert batch['state']=='failed' and batch['rc']==0 and batch['proposal_audit_errors']==[] and report['merged'] is None
assert len(report['fixes'])==len(report['proposal_results'])==1 and report['fixes'][0]['id']=='silent-0489' and report['proposal_results'][0]['state']=='waiting'
assert git('rev-parse','HEAD',cwd=batch['worktree']).decode().strip()==source and not git('status','--porcelain','--untracked-files=all',cwd=batch['worktree']).strip()
assert git('rev-parse',source+'^').decode().strip()==parent
paths=git('diff','--name-only',parent,source).decode().splitlines();assert set(paths)=={'agent/src/reflex/card-model.ts','agent/src/reflex/combat-plan.ts','agent/src/reflex/turn-solver.ts','agent/tests/silent-paper-krane-beam-states.json','agent/tests/silent-paper-krane-beam.test.ts'}
for name in ['sandbox-source','gitleaks-source','targeted-green-v2']:assert (s/(name+'.exit')).read_text().strip()=='0'
assert (s/'withdrawn-source.exit').read_text().strip()=='1' and '3 failed | 3 passed (6)' in (s/'withdrawn-source.log').read_text()
assert '437 passed (437)' in (s/'sandbox-source.log').read_text() and '4099 passed (4099)' in (s/'sandbox-source.log').read_text() and '11 passed (11)' in (s/'sandbox-source.log').read_text()
assert load(s/'gitleaks-source.json')==[] and load(s/'gitleaks-refresh.json')==[]
for path in paths[:]:
    if path.startswith('agent/src/'):
        short=Path(path).name;assert (s/(short+'.before.txt')).read_bytes()==git('show',parent+':'+path) and (s/(short+'.after.txt')).read_bytes()==git('show',source+':'+path)
spec=importlib.util.spec_from_file_location('original_extract',r/'learner/extract_evidence.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
manifest=load(s/'evidence/evidence-manifest.json');counts={};runrows={}
for stream in manifest:
    frozen=s/'evidence'/(stream['stream']+'.evidence.jsonl');assert sha(frozen.read_bytes())==stream['output_sha256'];n=0
    with frozen.open() as selected,(r/'logs'/(stream['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert sha(raw)==e['sha256'] and row==e['row'] and extract.run_identity(row)==e['run_id'] and e['run_id'] in report['runs'] and e['offset']+e['bytes']<=stream['source_size'];n+=1
            if stream['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
            if stream['stream']=='runs':assert row['character']=='SILENT' and row['ascension']==10;runrows[row['run_id']]=row
    assert n==sum(stream['counts'].values());counts[stream['stream']]=n
assert sum(counts.values())==14618 and len(runrows)==10
selected=load(s/'selected-evidence.json');assert len(selected)==9;frames={}
for e in selected:
    with Path(e['source']).open('rb') as original:original.seek(e['offset']);raw=original.read(e['bytes'])
    assert sha(raw)==e['sha256'] and json.loads(raw)==e['row'] and extract.run_identity(e['row'])=='HLAWCGM3KHVB'
    if 'state' in e['row']:frames[e['line']]=e
fixtures=json.loads(git('show',source+':agent/tests/silent-paper-krane-beam-states.json'));assert len(fixtures)==5
for f in fixtures:
    original=json.loads(json.dumps(frames[f['line']]['row']['state']));original.pop('agent_view',None)
    assert f['state']==original and f['sha256']==frames[f['line']]['sha256']
integration=load(s/'integration-result.json');assert integration['source_commit']==source and integration['actual_live_ancestor'] is False and integration['integration_exit']==20 and integration['merge_exit']==1 and len(integration['conflicts'])==18 and integration['merged'] is integration['version'] is None
assert integration['retained_live']==(s/'live-premerge-head.txt').read_text().strip()==(s/'live-after-abort-head.txt').read_text().strip()
assert (s/'live-merge-abort.log').read_bytes()==b'' and (s/'live-source-conflicts.patch').read_bytes()==b''
git('merge-base','--is-ancestor',integration['retained_live'],'HEAD',cwd=r/'.worktrees/live')
owned=[];references=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as ledger:
    while True:
        offset=ledger.tell();raw=ledger.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('id') in ['silent-0489','silent-0469','silent-0070'] and row.get('by')=='learner:strategy-proposal' and str(s) in raw.decode():
            assert row['op']=='add' and row['id']=='silent-0489' or row['op']=='update' and set(row)<={'op','id','ts','by','where','note'}
            owned.append(raw);references.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==4 and sum(json.loads(raw)['op']=='add' for raw in owned)==1;(p/'owned-learner-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'owned-learner-ledger-references.json',references)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,batch['worktree'])
write(pub/'strategy-readback.json',dict(batch=bid,original_report=report,source=source,source_parent=parent,source_paths=paths,source_checks=dict(tsc=0,exit_code=0,sandbox_files=437,sandbox_cases=4099,paths_cases=11,total=4110,withdrawn_failures=3,withdrawn_passes=3),original_report_cases_zero_preserved=True,native=native,raw_evidence_rows=14618,stream_counts=counts,all_raw_offsets_and_fixture_states_verified=True,core_original_refs=[{k:v for k,v in e.items() if k!='row'} for e in selected],original_conflicts=integration,owned_learner_rows=4,limits=['One observed Silent A10 HLAW turn only; 14HP boundary is a synthetic fixed assertion, not a rescued game.','Only that plain Sucker Punch / Paper Krane / BEAM_MOVE endpoint is certified. Unknown modifiers, other roles/ascensions, existing Weak and later moves retain their previous paths.','Original first targeted fixture failure, three withdrawn-source failures, record merge conflicts and failed/rc0/mergednull remain preserved. Source full is not a new combined-tree host result.','Natural consumer and whole-game benefit remain unknown. Wide learning/calibration/R2/R3 parents are not closed.']))
print(json.dumps(dict(source=source,source_full=4110,raw_rows=14618,owned_learner_rows=4,conflicts=18,native_verified=True)))

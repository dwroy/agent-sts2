from pathlib import Path
import fcntl,hashlib,json,os,subprocess
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0240';pub=r/'paper/materials/20261016-0240-ops';live=r/'.worktrees/live'
d=json.loads((pub/'publication.json').read_text());env={**os.environ,'PATH':str(Path.home()/'.local/node/bin')+os.pathsep+os.environ['PATH'],'TMPDIR':str(p),'PYTHONPYCACHEPREFIX':str(p/'pycache'),'NODE_COMPILE_CACHE':str(p/'node-compile-cache'),'SANDBOX_WORKERS':'1','npm_config_offline':'true'};env.pop('CHARACTER',None)
assert not (pub/'live-targeted.json').exists()
with (r/'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=live,text=True).strip();assert head==d['actual_live']
    records={path:hashlib.sha256((live/path).read_bytes()).hexdigest() for path in ['notes/fight-value-backtest-silent.md','notes/monster-db-check.md']}
    commands=[['nice','-n','19','npx','--no-install','tsc','-p','tsconfig.json','--noEmit'],['nice','-n','19','npx','--no-install','vitest','run','--pool=threads','--maxWorkers=1','tests/silent-paper-krane-beam.test.ts','tests/silent-paper-krane.test.ts']]
    results=[]
    for name,cmd in zip(['tsc','targeted'],commands):
        with (pub/('live-'+name+'.log')).open('wb') as output:rc=subprocess.run(cmd,cwd=live/'agent',env=env,stdout=output,stderr=subprocess.STDOUT).returncode
        results.append(dict(name=name,command=cmd,exit_code=rc));print(json.dumps(results[-1]),flush=True)
        if rc:break
    actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=live,text=True).strip();assert actual==head
    assert all(hashlib.sha256((live/path).read_bytes()).hexdigest()==digest for path,digest in records.items())
    log=(pub/'live-targeted.log').read_text() if (pub/'live-targeted.log').exists() else ''
    good=len(results)==2 and all(x['exit_code']==0 for x in results) and '21 passed (21)' in log and '2 passed (2)' in log
    receipt=dict(live=head,tree=d['tree'],source=d['source'],results=results,files=2,cases=21,passed=good,whole_suite=False,preexisting_dirty_records_preserved=True)
    (pub/'live-targeted.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');assert good

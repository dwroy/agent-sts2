from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,tarfile
sys.dont_write_bytecode=True
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0240';pub=r/'paper/materials/20261016-0240-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f):return json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
assert not (p/'own-appends.json').exists();d=load(pub/'publication.json');readback=load(pub/'strategy-readback.json');base=git('rev-parse','HEAD').decode().strip();assert base==d['main'] and not git('diff','--cached','--name-only').strip()
targeted=load(pub/'live-targeted.json');assert targeted['passed'] and targeted['live']==d['actual_live'] and targeted['tree']==d['tree'] and targeted['cases']==21
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
ledger=r/'paper/materials/learning/ledger.jsonl';before=ledger.stat().st_size
updates=[]
for ident in ['silent-0489','silent-0469','silent-0070']:
    row=dict(id=ident,by='ops:codex',where={'commits':[d['source'],d['behavior_commit'],d['actual_live']]},note=f'{at} 原021301限定纸鹤光束源码已实际main/live祖先，{d["release_id"]}/{d["name"]}；HLAWCGM3KHVB A10 F49T3普通突然一拳/聚合体BEAM_MOVE已观察12x3→7x3、9挡实际失12，旧预测18修为12。仅此端点组合；非通用取整/模型校准或本局获救，14HP是软件边界。原撤源码3败3过/恢复源437文件4099+paths11/tsc0、合后2文件21项/tsc0；新树一次宿主full与下一自然匹配消费者pending。18原记录冲突/failed/rc0/mergednull及首次定向夹具失败保留，原0469骑士/0070机制状态与版本不改，宽学习/量化父不关闭。回执paper/materials/20261016-0240-ops/。')
    if ident=='silent-0489':row.update(status='shipped',version=d['name'])
    updates.append(row)
payload=''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in updates);(pub/'ledger-input.jsonl').write_text(payload)
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','update','--character','silent'],input=payload,text=True,capture_output=True);(pub/'ledger-cli.log').write_text(result.stdout+result.stderr);assert result.returncode==0
opsrows=[raw for raw in ledger.read_bytes()[before:].splitlines(keepends=True) if any(all(json.loads(raw).get(k)==v for k,v in row.items()) for row in updates)];assert len(opsrows)==3
(p/'owned-ops-ledger.jsonl').write_bytes(b''.join(opsrows));old=git('show',base+':paper/materials/learning/ledger.jsonl');learner=(p/'owned-learner-ledger.jsonl').read_bytes().splitlines(keepends=True);assert len(learner)==4
existing=set(old.splitlines());rows=learner+opsrows;assert all(raw.rstrip(b'\n') not in existing for raw in rows);added=b''.join(rows)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added)
assert set(z)==set(a)|{'silent-0489'}
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert all(value in z[ident]['where'][key] for value in values)
assert z['silent-0489']['status']=='shipped' and z['silent-0489']['version']==d['name'] and z['silent-0489']['first_run']=='HLAWCGM3KHVB' and z['silent-0489']['asc']==10 and z['silent-0489']['prior']=='partly'
write(pub/'ledger-registration.json',dict(at=at,learner_rows=4,ops_rows=3,new_shipped_id='silent-0489',version=d['name'],old_parent_status_versions_evidence_unchanged=True,old_prefixes_preserved=True))
write(pub/'proposal-registration-boundary.json',dict(at=at,proposal='silent-proposal-0cce435d0d61ac93',original_completion='failed/rc0/mergednull and original waiting report preserved',actual_scoped_source_published=d['source'],actual_release=d['release_id'],scope='0489 shipped; old0469/0070 statuses preserved; natural consumer and wide parent remain pending',queue_edit=False,reason='Ordinary unassigned resolution requires the preserved report source identities. Original report has merged=null and waiting; it is not rewritten or replaced with a synthetic learner success. Actual ops publication and ledger provide separate truthful provenance. No duplicate add/parent/research/other-role ACK.'))
request=load(pub/'new-host-request.json');request.update(status='actual broker command submitted once; unified exec session77585; full result pending',unified_exec_session=77585)
write(pub/'new-host-request.json',request);checklog=Path(request['expected_log']);host=dict(request=request,result='pending',stage='broker request submitted once; start not yet independently observed')
if checklog.exists():
    prefix=checklog.read_bytes();host.update(actual_log_exists=True,log_prefix_bytes=len(prefix),log_prefix_sha256=sha(prefix))
    lockrows=subprocess.check_output(['lslocks','--noheadings','--output','PID,COMMAND,PATH'],text=True).splitlines();owners=[line.split()[0] for line in lockrows if line.endswith(str(r/'ops/live-merge.lock'))]
    if len(owners)==1:
        pid=int(owners[0]);stat=Path(f'/proc/{pid}/stat').read_text();host.update(worker_pid=pid,birth=stat[stat.rfind(')')+2:].split()[19],live_lock_owned=True,stage='actual host checker holds the live lock; full result pending')
    if b' RUN ' in prefix:host['vitest_started']=True
write(pub/'host-start.json',host)
handoff=dict(at=at,batch=readback['batch'],source=d['source'],source_parent=d['source_parent'],main=d['main'],actual_live=d['actual_live'],tree=d['tree'],release_id=d['release_id'],behavior_commit=d['behavior_commit'],five_leaves=d['leaves'],original_completion='failed/rc0/mergednull and18 record conflicts preserved',host='paper/materials/20261016-0240-ops/host-start.json',host_result='pending',targeted=targeted,natural_consumer='pending next natural matching Silent A10 Paper Krane/plain Sucker Punch/beam payload and accepted/action; no forced game or model request',worktree='retain source identity and evidence until original host/retention gates; do not delete',wide_parents='open')
write(pub/'publication-handoff.json',handoff);pending=r/'ops/codex-ops/pending-integrations'/f'{readback["batch"]}.json';pending.parent.mkdir(exist_ok=True);write(pending,handoff)
notice=f'\n- {at}｜规则实际上线 {d["release_id"]} / {d["name"]}：旧规则：纸鹤新施虚弱只认证原骑士/中和或萎靡，HLAW原聚合体光束普通突然一拳场景预测失18血。新规则：仅已观察Silent A10、未融化纸鹤、普通6伤/1虚弱/1费突然一拳、聚合体maxHP211/BEAM_MOVE/12×3/仅爪牙1、玩家易伤99及无未观察修正的手动决策回合，认证实际7×3端点，9挡后失12、剩59；已有虚弱帧不重复减伤，其他角色/进阶/招式/修正/后续轮与HP/SL/药价/终局规则保原路径。证据/账本：HLAWCGM3KHVB F49T3 s410804—410808/d398069—398072，原silent-0469/0070保持shipped及版本，本项0489独立shipped；原0cce435d提案/宽父不因单回合关闭。预期：修正该限定场景的悲观预测，不宣称通用取整、校准、救回原局或通关收益；14HP边界为软件构造。source{d["source"]}→behavior{d["behavior_commit"]}→live{d["actual_live"]}/tree{d["tree"]}，五叶窄合/真实main-live祖先，11原知识刷新与两脏记录/历史注释及其他发布保持。源撤3红3绿/恢复437文件4099+paths11/tsc0/gitleaks0；首次夹具失败/18记录冲突及failed/rc0/mergednull不改。回退仅这五叶当前上下文逆补丁，保原骑士及其他发布/知识；合后tsc0/2文件21项0，原021301策略单通道一次新树host full与下一自然消费者pending，不借R364绿、不重跑源full或重启当前局。回执paper/materials/20261016-0240-ops/。\n'
decision=f'\n- {at} 运维codex：0240原021301策略source8d386fc76纸鹤光束限定补模已按已测五叶兜底main/live，实际{d["release_id"]}/behavior{d["behavior_commit"]}/live{d["actual_live"]}/tree{d["tree"]}，原18记录冲突/abort/failed-rc0-mergednull与初夹具错误保留；首次非阻塞锁busy后一次占锁读回无持锁者才接续，原失败日志保持、无等待循环。14618材料行原offset/SHA/JSON/身份、九核心原件/五去agent_view固定帧与native Sol6.1/xhigh/input/lease核；只有HLAW A10 F49T3一独立回合，原tests.cases0与真实438文件4110源全套分列，撤源码3败3过/恢复/tsc0/gitleaks0不重跑。11已提交知识刷新、当前全部非五叶源码/两脏记录及历史注释保持；根旧新/证据/预期/回退双通知。4原CLI（新增0489 proposed及3追溯）精确纳入，另原CLI0489独立shipped/{d["name"]}、0469/0070只补来源，旧claim/首证/prior/evidence/status/version及history前缀保，不伪造原提案/learner成功或父ACK。合后tsc0/2文件21定向0，原021301策略单通道一次精确新树宿主full已请求，实际启动证据与最终结果分列，下一自然匹配消费者pending。无一般系数/收益或宽校准/R2/R3关闭，无新研究/重复提案/模拟/论文刷新/对局重启/账号home模型额度权限prompt变化。回执paper/materials/20261016-0240-ops/。\n'
ops_handoff=f'\n- {at} 原021301策略8d386fc76五叶纸鹤光束限定补模已main/live真实祖先，{d["release_id"]}/live{d["actual_live"]}/tree{d["tree"]}，0489独立shipped、0469/0070及宽父保持；源4110全套、撤3红恢复绿与合后tsc0/2文件21项0核。原18冲突/failed-rc0-mergednull/首次锁忙保留，11知识刷新/两脏记录保。仅一次原learner-recheck已请求，后继事件核精确b7c5dff8树，不重复请求/借R364绿；下一自然匹配Silent A10纸鹤/突然一拳/光束消费者pending，不人为开局/模型或重启。原普通未领提案report不改，代码提案仍原waiting，只以独立实际发布回执链接，不另造成功报告/父项或代ACK。源WT与证据沿既有host/retention门槛保留。回执paper/materials/20261016-0240-ops/publication-handoff.json。\n'
appends={'notes/for-roy.md':notice,'ops/inbox-dev.md':notice,'paper/materials/decision-log.md':decision,'notes/ops-handoff.md':ops_handoff};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (r/path).open('ab') as f:f.write(text.encode())
artifacts=[];s=Path(readback['original_report']['report']).parent
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000 and not f.name.startswith('jev-sts2-settle-')]+[s/'evidence/evidence-manifest.json']+[r/f'ops/codex-ops/learner/{readback["batch"]}{suffix}' for suffix in ['.out','.err']]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers);write(pub/'completion.json',dict(at=at,batch=readback['batch'],source=d['source'],actual_release=d['release_id'],actual_live=d['actual_live'],tree=d['tree'],learner_rows=4,ops_rows=3,old_parent_statuses_preserved=True,source_full=4110,combined_targeted=21,host_full='one actual original request; result pending',natural_consumers='pending',no_source_full_rerun_or_game_account_prompt_change=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));check=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(check.stdout+check.stderr);assert check.returncode==0
print(json.dumps(dict(paths=len(entries),ledger_rows=7,ledger_check=0,release_id=d['release_id'],host_stage=host['stage'])))

import hashlib
import json
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
OUT = ROOT / 'learner/runs/20261015-194306-bcf68a34-5915-46a0-a2ce-8d21b36a27e1-fix-batch'

def sha(data):
    return hashlib.sha256(data).hexdigest()

startup_path = ROOT / 'learner/runs/20261015-191301-5c362584-e14d-47b5-bbba-1910dc2e3f76-postmortem.jsonl'
startup_raw = startup_path.read_bytes()
startup = [json.loads(line) for line in startup_raw.splitlines()]
attempts = [row for row in startup if row.get('type') == 'learner_startup_attempt']
exits = [row for row in startup if row.get('type') == 'learner_startup_exit']
assert len(attempts) == len(exits) == 1
assert attempts[0]['batch'] is None and attempts[0]['lease'] is None
assert exits[0]['retryable'] is True and exits[0]['exit_code'] == 1
assert not [r for r in startup if r.get('type') in ('thread.started', 'learner_startup_retry')]

receipt_path = ROOT / 'paper/materials/20261015-v5-s-completion/on-RQCHNN0W72KF/c1-natural-failure-consumer.json'
receipt_raw = receipt_path.read_bytes()
receipt = json.loads(receipt_raw)
checks = []
for group in receipt['groups']:
    assert [a['completion']['status'] for a in group['attempts']] == ['pending', 'pending', 'degraded']
    for item in group['attempts']:
        source = item['source']
        assert source['path'] == 'logs/decisions.jsonl'
        with (ROOT / source['path']).open('rb') as stream:
            stream.seek(source['offset'])
            raw = stream.read(source['bytes'])
        assert len(raw) == source['bytes'] and sha(raw) == source['sha256']
        row = json.loads(raw)
        assert row['run_id'] == 'RQCHNN0W72KF' and row['floor'] == group['floor']
        checks.append({'source': source, 'run_id': row['run_id'], 'floor': row['floor'],
                       'turn': row.get('turn'), 'status': item['completion']['status'],
                       'samples': item['completion']['samples'], 'error': item['error'],
                       'result': item['result']})
assert len(checks) == 9
result = {
    'startup': {'path': str(startup_path), 'bytes': len(startup_raw), 'sha256': sha(startup_raw),
                'attempt': attempts[0], 'exit': exits[0],
                'limit': '租约为空的具体拒绝分支、注册时序与目录删除者未知；不授权重放。'},
    'resource_receipt': {'path': str(receipt_path), 'sha256': sha(receipt_raw)},
    'raw_decision_checks': checks,
    'limit': '仅核原字节、身份和控制流程。错误尾部截断，完整 resources/steps 与 nonpositive-hp 机制根因未知；未重跑模拟。',
}
(OUT / 'evidence-readback.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'startup_attempts_verified': len(attempts), 'raw_decisions_verified': len(checks),
                  'floors': sorted({r['floor'] for r in checks}), 'resource_root_cause': 'unknown'}, ensure_ascii=False))

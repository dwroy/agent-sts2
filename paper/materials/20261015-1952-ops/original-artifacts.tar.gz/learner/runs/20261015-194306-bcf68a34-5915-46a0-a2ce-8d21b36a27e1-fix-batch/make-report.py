import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-194301'
OUT = ROOT / 'learner/runs/20261015-194306-bcf68a34-5915-46a0-a2ce-8d21b36a27e1-fix-batch'
audit = json.loads((OUT / 'audit.json').read_text())
evidence = json.loads((OUT / 'evidence-readback.json').read_text())
tsc = int((OUT / 'tsc.exit').read_text())
vitest = int((OUT / 'vitest.exit').read_text())
log = (OUT / 'vitest.log').read_text()
files = int(re.search(r'Test Files\s+(\d+) passed', log).group(1))
cases = int(re.search(r'Tests\s+(\d+) passed', log).group(1))
assert (tsc, vitest, files, cases) == (0, 0, 5, 35)
assert not subprocess.check_output(['git', '-C', str(WORK), 'status', '--porcelain'])

skipped = [
    {'item': 'silent-0481：技能药水选牌生命周期措辞', 'reason': '策略类/题面知识：selection.ts 两处旧措辞仍在；已有 silent-proposal-686d4e759478eebb，按独立 strategy-proposal 实现，本普通批不重复登记。'},
    {'item': 'silent-0311：库存后继血量预算', 'reason': '策略类/模型：现有 enemyDown 仍按旧 maxHp 恢复；已有 silent-proposal-d2f24919ee64b90b。2LZHP9BYFTHE 正确定位为 A10 F37 T1/4/10，保留原策略链，不加固定倍率。'},
    {'item': 'silent-0332：成功首战资源 nonpositive-hp', 'reason': '证据不足：已按 offset/bytes/SHA 核 RQCHNN0W72KF F40/F48 九条原决策及三组 pending/pending/degraded；完整 resources/steps 截断，机制根因未知。正 HP 接续契约保持，原提案 silent-proposal-5aa2672bd7cd1bf4 继续。'},
    {'item': 'silent-0469：聚合体纸鹤组合', 'reason': '策略类：HLAWCGM3KHVB F49T3 多击/玩家易伤/突然一拳超出已发布骑士窄范围；沿 silent-proposal-0cce435d0d61ac93，不关闭宽父。'},
    {'item': 'rest-timeout-accepted-route-not-committed / silent-0446', 'reason': '策略类/结构：hand/loop.ts 仍在 dispatch 成功后 applyResolved；沿 silent-proposal-2d3aa8dfb27dbe3f 验证动作确认与路线提交，不无条件提交未确认动作。'},
    {'item': '其余出牌、机制、药水、SL、终局、路线、休息未闭合范围', 'reason': '策略类：沿各条原账本与 strategy-proposal。已发布窄子项不关闭宽父；未新增游戏规则、研究任务或代码提案。41条未勾选项的逐行处置见 queue-dispositions.json。'},
    {'item': 'codex 大脑缓存命中偏低', 'reason': '证据不足：缺当前原生请求的受控同题比较；本离线任务不调用真实 LLM 或网络，不凭历史命中率判断源码缺陷。'},
    {'item': '调度公平性核查', 'reason': '证据不足：原观察未证明永久饥饿，沿原框架任务核 dispatch/seen_runs，不改变并发、优先级或队列状态。'},
    {'item': 'sandbox-glob-startup-race：上游生命周期/租约未绑定', 'reason': '证据不足：已核原191301事件流 attempt1/exit1/retryable=true/batch与lease均null；既有恢复及时间戳复盘租约修复已在main/live。无法据null区分拒绝分支、注册时序或目录删除者，不越租约重放或扩大沙箱。'},
    {'item': 'core-build-notify-222802-rc2：历史发送事实', 'reason': '证据不足：后续原生失败诊断已有5c92f2aaf；原rc2无stderr，无法事后还原是否发送，保留原回执，不重发。'},
    {'item': 'named-card-facts-transport：事件入口之外的范围', 'reason': '太大/独立功能：事件入口42c920f34已实现，其他入口/跨局及P1/P2范围沿原架构owner，不混入普通修复。'},
    {'item': 'boss模拟样本/性能、v5-dpr-health宽范围', 'reason': '太大/独立专项：保持原冻结输入和验收链；固定回归不代替校准，不减样本、扩预算或删候选。'},
    {'item': 'arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression', 'reason': '策略类/独立架构与归因研究：沿既有批准任务，不在普通批改变资源价值、玩法或派发规则。'},
    {'item': '框架外层总时限收尾', 'reason': '太大/独立框架：精确分段续验入口24c2e3a75已实现；剩余包装器与宿主收尾沿原owner，保留历史失败和覆盖。'},
]

fixed = audit['existing_fixes']
fixed_ids = {
    'silent-0254': '3b48088dec', 'silent-0256': '6403fdcdad', 'silent-0260': '5c7105ff02',
    'silent-0263': 'ec29ea34b9', 'silent-0266': 'e784dd9f04', 'silent-0324': '66c22ba7d8',
    'silent-0338': 'c1d8480495', 'silent-0367': '5baf663d7e',
    'codex-usage-credit-baseline-recovery': '5b56a452bb',
    'infra-target-options-fixed-fixture-timeout': 'bae9c45ccf',
    'infra-ledger-status-prefix-git-divergence': 'dd478f0b3e',
    'infra-learner-launch-shared-main-config-race': '22efae5548',
}
dispositions = []
for source in audit['unchecked_queue_entries']:
    text = source['item']
    entry = {**source, 'disposition': '策略类/沿原独立提案，宽父保持'}
    for key, prefix in fixed_ids.items():
        if key in text:
            commit = next(e['source_commit'] for e in fixed if e['source_commit'].startswith(prefix))
            entry.update(disposition='已修或已覆盖窄子项；不关闭更宽父项', commit=commit)
            break
    else:
        if '9Z9H2EXKLF3T' in text:
            entry.update(disposition='已修：移除预览核对实际选牌页', commit=next(e['source_commit'] for e in fixed if e['source_commit'].startswith('db20ec3cc6')))
        elif 'addedSomewhere' in text:
            entry.update(disposition='已修：rollout最佳线固定夹具确定性', commit=next(e['source_commit'] for e in fixed if e['source_commit'].startswith('bbc5b993a7')))
        elif 'ascension-up' in text:
            entry.update(disposition='已修：目标/实际进阶分开', commit=next(e['source_commit'] for e in fixed if e['source_commit'].startswith('8045d9fbf0')))
        elif '010547' in text:
            entry.update(disposition='已修：eval/Apotheosis固定输入及有界夹具', commits=[e['source_commit'] for e in fixed if e['source_commit'].startswith(('d9881ba593', '9e8c935551'))])
        elif 'core-build-notify-222802-rc2' in text:
            entry['disposition'] = '证据不足：后续诊断已修，原历史发送事实未知'
        elif '框架/测试收尾' in text:
            entry['disposition'] = '太大/独立框架：精确续验入口已实现，宿主收尾范围继续'
        elif '调度公平性' in text:
            entry['disposition'] = '证据不足：未证明永久饥饿，沿原框架核查'
        elif 'silent-0332' in text:
            entry['disposition'] = '证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知'
    dispositions.append(entry)
(OUT / 'queue-dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')

report = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': skipped, 'merged': None,
    'tests': {'tsc': tsc, 'vitest': vitest, 'cases': cases, 'files': files, 'scope': 'targeted', 'reruns': []},
    'code_proposals': [], 'implementation_domains': [], 'report': str(OUT / 'report.md'),
}
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
lines = [
    '## 修 bug 回报', '',
    f"- 合并基线：main → {audit['base']}（开工干净，先 merge main，Already up to date.）",
    '- 修复（每条一行）：无新增修复。73项既有修复/窄子项的51个当前源码路径SHA与前批相同，来源提交均为本基线与只读live快照祖先；没有修改源码、提交或适用的撤修复验证。',
]
for item in fixed:
    lines.append(f"- 已被别人修掉的：{item['item']} — 已修，提交 {item['source_commit']}（当前 {item['path']}；仅确认已实现范围，宽父保持）。")
for item in skipped:
    lines.append(f"- 没修的：{item['item']} — {item['reason']}")
lines.extend([
    f'- 测试：tsc退出码{tsc}；Vitest定向{files}文件/{cases}用例/退出码{vitest}，无失败、无重跑。固定数据、无真实LLM/网络。未改源码或提交，未运行完整test-sandbox，不将定向检查称为全套。',
    f"- 合入：未合入（无新源码或提交，merged=null）；73项既有来源均为只读live {audit['live_read_only_snapshot']} 祖先。不创建空合并、刷新提交、发布号或账本状态变更。",
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '报告附件：audit.json逐项源码/祖先核验；queue-snapshot.md与queue-change.diff保存1336行队列及本次增量；queue-dispositions.json覆盖41条未勾选项；evidence-readback.json保存原启动事件与RQ九条原决策的字节/SHA核验。source.diff为空。最新增量是原0332自然补证，没有新增独立缺陷。', '',
    '测试文件：agent/tests/learner-startup-recovery.test.ts、agent/tests/learner-strategy-scratch.test.ts、agent/tests/learner-entry.test.ts、agent/tests/ledger-publication-baseline.test.ts、agent/tests/continuation-diagnostics.test.ts。原始日志和退出码保存在同目录。未对既有源码执行撤修复试验；该要求只对本批新增修复适用。', '',
    '```json', json.dumps(report, ensure_ascii=False, indent=2), '```', '',
])
(OUT / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'report': report['report'], 'existing_fixes': len(fixed), 'unchecked_dispositions': len(dispositions), 'new_fixes': 0, 'tests': report['tests']}, ensure_ascii=False))

import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-194301'
OUT = ROOT / 'learner/runs/20261015-194306-bcf68a34-5915-46a0-a2ce-8d21b36a27e1-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-191308-f6b1a413-b614-4a6d-a0ca-e940f9d1a805-fix-batch'

def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'live').decode().strip()
prior_bytes = (PRIOR / 'audit.json').read_bytes()
prior = json.loads(prior_bytes)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
(OUT / 'queue-snapshot.md').write_bytes(queue)
(OUT / 'queue-change.diff').write_text(''.join(difflib.unified_diff(
    (PRIOR / 'queue-snapshot.md').read_text().splitlines(True),
    queue.decode().splitlines(True), fromfile='previous-queue', tofile='current-queue')))
entries = []
for item in prior['existing_fixes']:
    commit = item['source_commit']
    path = item['path']
    current = (WORK / path).read_bytes()
    committed = git('show', f'{base}:{path}')
    leaf = git('ls-tree', live, '--', path)
    entry = {
        'item': item['item'], 'source_commit': commit, 'path': path,
        'current_source_sha256': sha(current),
        'same_as_prior_audit': sha(current) == item['current_source_sha256'],
        'same_as_committed_base': current == committed,
        'ancestor_in_base': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
        'ancestor_in_live_snapshot': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, live]).returncode == 0,
        'live_leaf_present': bool(leaf),
    }
    if leaf:
        live_bytes = git('show', f'{live}:{path}')
        entry['live_source_sha256'] = sha(live_bytes)
        entry['same_source_in_live'] = current == live_bytes
    entries.append(entry)
    assert all(entry[k] for k in ['same_as_prior_audit', 'same_as_committed_base', 'ancestor_in_base', 'ancestor_in_live_snapshot']), entry

open_lines = [{'line': n, 'item': line} for n, line in enumerate(queue.decode().splitlines(), 1) if line.startswith('- [ ]')]
audit = {
    'base': base, 'live_read_only_snapshot': live,
    'queue_sha256': sha(queue), 'queue_lines': len(queue.splitlines()),
    'prior_audit': str(PRIOR / 'audit.json'), 'prior_audit_sha256': sha(prior_bytes),
    'existing_fixes': entries, 'unchecked_queue_entries': open_lines,
    'no_new_source_changes': not git('diff', '--binary', 'HEAD'),
    'no_new_commits_since_merged_main': not git('rev-list', 'main..HEAD'),
}
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source.diff').write_bytes(git('diff', '--binary', 'HEAD'))
(OUT / 'baseline-change.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--', 'agent', 'learner', 'ops'))
print(json.dumps({'base': base, 'live': live, 'existing_fixes_verified': len(entries), 'unique_paths': len({e['path'] for e in entries}), 'unchecked_entries': len(open_lines), 'queue_lines': audit['queue_lines'], 'new_source_changes': not audit['no_new_source_changes']}, ensure_ascii=False))

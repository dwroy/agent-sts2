from pathlib import Path
import json,subprocess,hashlib,re,tarfile
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-1952';pub=r/'paper/materials/20261015-1952-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
bid='20261015-194301-fix-batch';b=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='failed' and b['rc']==0 and b['proposal_audit_errors']==[]
assert report['fixes']==[] and report['merged'] is None and report['code_proposals']==[] and report['implementation_domains']==[]
assert report['tests']=={'tsc':0,'vitest':0,'cases':35,'files':5,'scope':'targeted','reruns':[]}
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
audit=load(s/'audit.json');assert audit['base']==report['base'] and audit['no_new_source_changes'] and audit['no_new_commits_since_merged_main']
assert len(audit['existing_fixes'])==73 and len({x['path'] for x in audit['existing_fixes']})==51
assert sha((s/'queue-snapshot.md').read_bytes())==audit['queue_sha256'] and sha(Path(audit['prior_audit']).read_bytes())==audit['prior_audit_sha256']
for x in audit['existing_fixes']:
 for target in [report['base'],audit['live_read_only_snapshot']]:git('merge-base','--is-ancestor',x['source_commit'],target)
 assert sha(git('show',report['base']+':'+x['path']))==x['current_source_sha256']
 assert sha(git('show',audit['live_read_only_snapshot']+':'+x['path']))==x['live_source_sha256']
 assert x['same_as_prior_audit'] and x['same_as_committed_base'] and x['ancestor_in_base'] and x['ancestor_in_live_snapshot']
queue=load(s/'queue-dispositions.json');assert len(queue)==len(audit['unchecked_queue_entries'])==41 and all(x['disposition'] for x in queue)
assert [(x['line'],x['item']) for x in queue]==[(x['line'],x['item']) for x in audit['unchecked_queue_entries']]
assert (s/'source.diff').read_bytes()==b''
for name in ['tsc','vitest','gitleaks']:assert (s/(name+'.exit')).read_text().strip()=='0'
assert load(s/'gitleaks.json')==[] and re.search(r'Test Files\s+5 passed', (s/'vitest.log').read_text()) and re.search(r'Tests\s+35 passed', (s/'vitest.log').read_text())
evidence=load(s/'evidence-readback.json')
for ref in [evidence['startup'],evidence['resource_receipt']]:assert sha(Path(ref['path']).read_bytes())==ref['sha256']
assert evidence['startup']['attempt']['lease'] is None and evidence['startup']['attempt']['batch'] is None
assert len(evidence['raw_decision_checks'])==9
for x in evidence['raw_decision_checks']:
 ref=x['source'];fpath=(r/ref['path']).resolve();assert fpath.is_relative_to(r)
 with fpath.open('rb') as f:f.seek(ref['offset']);raw=f.read(ref['bytes'])
 assert sha(raw)==ref['sha256'] and json.loads(raw)['run_id']==x['run_id']=='RQCHNN0W72KF'
write(pub/'fix-readback.json',{'batch':bid,'canonical_state':b['state'],'rc':b['rc'],'original_report':report,'native':native,'source_references':73,'unique_paths':51,'base_and_old_live_source_shas_and_ancestors_verified':True,'original_live_snapshot':audit['live_read_only_snapshot'],'queue_original_unchecked_entries':41,'all_dispositions_read_back':True,'original_checks':report['tests'],'original_check_logs_sha256':{name:sha((s/name).read_bytes()) for name in ['tsc.log','tsc.exit','vitest.log','vitest.exit','gitleaks.log','gitleaks.exit','gitleaks.json']},'checks_reexecuted':False,'no_new_commit_or_merge_blocker':True,'canonical_failed_rc0_preserved_not_product_failure_claim':True,'original_startup_and_nine_resource_failure_rows_verified':True,'unresolved':'Original nonpositive-hp resources/steps truncated; root cause unknown. Empty startup lease does not identify refusal branch, registration timing or directory deleter; no manual replay.','original_preparation_failures_preserved':'Initial historical path guesses and missing-path searches retained in original event/output. No dependency installation or sandbox expansion.','no_new_ledger_status_source_merge_release_dataset_or_runtime_changes':True,'original_wide_parents_and_owners_preserved':True})
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted([f for f in s.iterdir() if f.is_file()]+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);manifest.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',manifest)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
line=f'\n- {at} 运维codex：1952原194301-fix空修复回报核，canonical failed/rc0/mergednull与原史保持；f8ca干净WT无新源码提交或合入阻塞，不空合/发号。73既修复及窄子项的51当前源码叶与base/旧livefe646265逐SHA和来源祖先核，41条原未勾选队列处置读回，不据窄实现关闭宽父；原tsc0、5文件35定向过/无重跑，非完整套件，不重复检查。实际native Sol6.1/xhigh/input/lease与workspace-write/no-network核、原任务high文字及历史路径准备错误留史，不改权限/模型线程。原191301启动事件及RQ F40/F48九条原决策逐字节SHA复核，原0332三组pending/pending/degraded及42/159/0样本少于300不给整场数字已在原链；完整resources/steps仍截断、根因未知，原5aa2672提案保持，不因C1保护出口冒称修复或重派。原startup retryable但batch/lease空不据此归因拒绝分支/目录删除者，也不手动越租约重放。0311 F37勘误/原策略提案、其余机制/性能/框架及宽R2R3由原owner接续；无新bug/反证/经验/ledger或源码，不刷新论文、不改当前局/账号home模型预算队列prompt，不等待未来事件。证据paper/materials/20261015-1952-ops/。\n'
note=f'\n- {at} [ops 修复批次处置] 原194301无新增源码或提交受阻；73项既有修复/窄子项与原35项定向检查核实归档。0332及启动生命周期根因仍缺证，沿原提案/owner保留，不重派、重测、合空提交或新增行为号。回执paper/materials/20261015-1952-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers)
write(pub/'completion.json',{'at':at,'batch':bid,'empty_fix_report':True,'original_targeted_tests':35,'full_suite_claim':False,'new_source_or_merge_blocker':False,'repeat_dispatch_tests_or_game_actions':False,'parallel_records_preserved':True})
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
entries=[];dest=p/'final-files'
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':entries});print(json.dumps({'no_new_fix_or_merge_blocker':True,'existing_sources':73,'original_targeted_tests':35,'raw_decision_refs':9,'paths':len(entries)}))

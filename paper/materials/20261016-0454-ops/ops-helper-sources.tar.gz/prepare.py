from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0454';pub=root/'paper/materials/20261016-0454-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-044302-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip() and (s/'source.diff.patch').read_bytes()==b''
originals=load(s/'original-proposals-check.json');assigned=load(s/'dispatched-proposals.json');assert len(originals)==len(assigned)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    original=Path(x['path']);copy=s/(x['id']+'.original.md');queued=next(y for y in assigned if y['id']==x['id']);assert original.is_relative_to(root) and x['verified']
    assert sha(copy.read_bytes())==x['sha256']==queued['proposal_sha256'] and len(copy.read_bytes())==x['bytes']
    if original.exists():assert sha(original.read_bytes())==x['sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');projection=module('original_projection',s/'verify_evidence.py')
runs={x['row']['run_id']:x['row'] for x in load(s/'runs-identity.json')};assert set(report['runs'])==set(runs) and len(runs)==6 and all((x['character'],x['ascension'],x['victory'])==('SILENT',10,False) for x in runs.values())
pairs=load(s/'fingerprint-pairs.json');endpoints=load(s/'actual-pair-endpoints.json');assert len(pairs)==4 and len(endpoints)==8
needed_states={x[k] for x in endpoints for k in ['start_state_line','end_state_line']};needed_decisions={x['decision_line'] for x in endpoints};states={};decisions={}
counts={};manifest=load(s/'evidence/evidence-manifest.json');verification=load(s/'evidence-verification.json')
for x in manifest:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in runs
            if x['stream']=='states':
                assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10)
                if e['line'] in needed_states:states[e['line']]=dict(row=row,summary=projection.state_summary(e))
            if x['stream']=='runs':assert row==runs[e['run_id']]
            if x['stream']=='decisions' and e['line'] in needed_decisions:decisions[e['line']]=row
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==8274
for x in verification:assert counts[x['stream']]==x['rows'] and x['output_sha256']==next(y['output_sha256'] for y in manifest if y['stream']==x['stream']) and x['byte_identity_verified']
for pair in pairs:
    assert pair['fingerprint_equal'] and decisions[pair['first']]['fingerprint']==decisions[pair['second']]['fingerprint']
for x in endpoints:
    a=states[x['start_state_line']];z=states[x['end_state_line']];d=decisions[x['decision_line']]
    assert a['summary']==x['start'] and z['summary']==x['end'] and a['row']['observed_ts']==d['observed_ts']
    assert d['run_id']==x['run_id']==a['summary']['run_id']==z['summary']['run_id'] and d['sl_attempt']==x['attempt'] and d['floor']==x['floor'] and d['turn']==x['turn']
    assert x['hp_start']==a['summary']['hp'] and x['hp_end']==z['summary']['hp'] and x['net_hp_lost']==x['hp_start']-x['hp_end']
facts=load(s/'material-checks.json');assert len(facts['checks'])==facts['count']==facts['passed']==37 and all(x['matches'] and x['actual']==x['expected'] for x in facts['checks']) and (s/'material-checks.stderr.txt').read_bytes()==b''
source=load(s/'source-provenance.json');assert source['base']==report['base'] and len(source['files'])==14 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_readonly_observed']
for x in source['files']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_readonly_observed']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (root/'.worktrees/live'/x['path']).read_bytes()==z
    assert (a==z)==x['base_live_bytes_equal'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and x['commit_is_base_ancestor'] and x['commit_is_live_ancestor']
    for head in [report['base'],source['live_readonly_observed']]:git('merge-base','--is-ancestor',x['latest_path_commit'],head)
assert sum(x['base_live_bytes_equal'] for x in source['files'])==10
art=load(s/'artifact-manifest.json');assert art['base']==report['base'] and art['code_proposal_links_valid']
for entry in art['files']:
    f=s/entry['path'];raw=f.read_bytes();assert f.is_relative_to(s) and len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
receipt=load(s/'ledger-after-check.json');prefix=load(s/'ledger-physical-before.json');rows=receipt['own_appended_rows'];input_lines=(s/'ledger-updates.jsonl').read_bytes().splitlines(keepends=True);inputs=[json.loads(raw) for raw in input_lines]
assert len(rows)==len(inputs)==30 and receipt['old_physical_prefix_unchanged'] and receipt['links_read_back'] and receipt['stdout_ids_match'] and all(v==[] for v in receipt['protected_fields_unchanged'].values())
assert set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.stderr.txt').read_bytes()==b''
own=[];owned_receipts=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(prefix['size']))==prefix['sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row['id']==entry['id'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        matched=[v for v in inputs if (v['id'],v['note'])==(row['id'],row['note'])];assert len(matched)==1 and all(row.get(k)==v for k,v in matched[0].items());own.append(raw);owned_receipts.append(dict(**entry,row=row))
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==30 and not set(raw.rstrip(b'\n') for raw in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,original_proposals=originals,stream_counts=counts,original_rows_verified=8274,ascension_cohorts={10:6},material_assertions=37,source=source,same_fingerprint_pairs=4,original_endpoints=endpoints,endpoints_bound_to_original_rows=True,owned_trace_rows=owned_receipts,protected_fields_and_prefixes_preserved=True,original_artifact_manifest_verified=len(art['files']),no_checks_reexecuted=True,limits=['Same fingerprint is not same simulation; historical sample counts and capped further loss remain distinct from executed damage or complete fight comparisons.','Eight local endpoints from four pairs cannot reconstruct original101-run statistics, historical dirty source or strategy gains.','Preparation null-combat error, transient directory-scan failure and out-of-scope queue read preserved; unrelated character text excluded from evidence, weighting and denominators.','Current source/current-phase snapshot and pending dispatch do not certify full candidate execution or brain adoption.','No source, merge, release, production tests, paper refresh, new dispatch or game action; wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0454原044302-s2策略done0/no-source核收，38a1基线干净WT/HEAD不变，十waiting逐项缺口/testsnull/mergednull保持，无合入受阻。六Silent A10失败局八流8274原行逐offset/bytes/SHA/JSON/显式身份核，37原材料断言首次通过，四同指纹配对八个当轮端点逐原observed_ts/状态/attempt核；净失血3/15、0/9、9/14、2/10只记局部代价，8/24等原样本差/0与5胜/47封顶分列，不作同推演、完整替线、策略收益或原101局统计重建。14相关源码叶10同4历史Roy/Dai注释差及真实base/live祖先核，当前actual/pending字段非整项联合执行完成。30所属CLI只where/note，原物理前缀/offset/SHA与私有fold核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI或补support/repeat。准备阶段null-combat查看错误、临时并行目录回收扫描失败和误读早期通用队列范围原件保留；非本角色内容未入本批证据、权重或分母，不当产品故障、游戏反证或测试结论。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核。仅本人记录/30追溯提交，保并行记录；无源码/合入/发号/补测/论文刷新/复派/重启对局或账号home模型额度权限prompt变更，不关闭宽父。证据paper/materials/20261016-0454-ops/。\n'
note=f'\n- {at} [运维 codex] 原044302-s2十项继续waiting，无源码修改或合入阻塞；8274原行、37原材料断言、四同指纹局部端点和30条所属追溯已核。准备阶段错误与读取范围限制保留，未宣称整战后继、自然采用或宽父完成。回执paper/materials/20261016-0454-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=30,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=8274,owned_trace_rows=30,ledger_check=0,paths=len(entries))))

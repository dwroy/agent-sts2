import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAMP = "2026-10-16 04:50:02 CST"
BASE = "38a1f2e4d59f9582bf78e562aeecd39e1dd11375"
BATCH = "20261016-044302-s2-strategy-proposal"
proposals = json.loads((HERE / "dispatched-proposals.json").read_text())
dispatch = json.loads((HERE / "dispatch.json").read_text())
source = json.loads((HERE / "source-provenance.json").read_text())
checks = json.loads((HERE / "material-checks.json").read_text())
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())

details = [
    ("感染棱柱污染与技能收益", "DUZUBAJ3A8GP/F27/T4—6；s274830—274839；silent-0168。",
     "火花3→6，T4污染0/3/3/6/0、T5为0/6/12/18/0；能力插入不增污染；本轮实损3/9。",
     "turn-solver.ts:2123、2948和rollout.ts:2391已有技能污染/后续火花接线。",
     "已核火花与污染逐步变化，但缺历史dirty源码、当时实际移动表及迷雾/毒/挡的联合校准；没有完整替代线证据，不能据一次损9强制少打技能。",
     "迷雾同时增加毒并施弱，防御有实际挡；不能把污染新增量单独当作整条技能线净损失。",
     "冻结该联合局面的完整求解输入，逐步对照污染、当前弱、挡和毒结算；另取独立新局验证，禁止由当前知识表代替历史输入。"),
    ("失落/遗忘逐来源抢夺与返还", "5PM6JAQG6FNQ/F39/T4—6；s274351—274362、274391—274397；silent-0183、silent-0005。",
     "首试敏捷−4→−2→0；失落退场前后力量−4→0；T6敏捷再至−2。末试单步法仅使−4→−2，仍死亡。",
     "当前求解输入会读取现场负力/敏；这不证明已保存每次抢夺的来源及死亡返还归属。",
     "现帧负属性和退场后的恢复已核，但缺逐实体抢夺累计、返还归属及再抢的完整联合模型/消费者记录；总负属性不能替代来源账，未有固定杀序胜线。",
     "首试两步法与末试一步法的后继不同；末试失落退场仍被遗忘击杀，不能推出先杀失落即可获胜。",
     "为来源实体及召唤代际保留身份，分别核抢夺、步法增益、毒结算、退场返还与重抢；未见条件保持未知。"),
    ("下水道蚌加压与当前进阶事实", "CA5KE8GFJ9X2/F13/T1—5；s273237、273252、273263—273269；silent-0231。",
     "喷水11/15/19与力量0/4/8；末弱后14攻、2HP/10挡，需损4而实扣到0。",
     "monster-db.ts:712、844从已有当前进阶观测读取攻击/HP，没有五样本门槛；rollout-live.ts:290起读当前进阶移动效果。",
     "当前进阶首样本读数已有源码，尚缺本局dirty运行时的完整移动表与加压/覆甲联合重放；覆甲减层触发只见相关帧，不能据此补成完整机制或更改房间成本门槛。",
     "弱后19降14仍有成长，胜负不能只归于是否施弱；死亡实扣2不能当成完整攻击需损2。",
     "在冻结同一移动表下核加压/弱/覆甲及逐轮端点；房间代价继续保留五样本门槛，不把当前敌人属性观测门槛混入。"),
    ("电击机器人连续增长与实体身份", "5PM6JAQG6FNQ/F38/T3—4；s274308、274313；silent-0233、silent-0209。",
     "23上限的连续电击观察中，力量2→4、攻击17→19，高电压均2；T3仍存活并贡献攻击。",
     "rollout.ts:526、2763将HIGH_VOLTAGE_POWER计入实体增长，spawnedEnemy从新模板初始化。",
     "已核连续现存电击的2→4/17→19，缺召唤者稳定身份与代际完整输入、生成后连续增长的联合校准和替代杀序后继；现存实体连续性不证明新召唤者继承处理正确。",
     "先清爪牙的35伤/损3只是未执行候选，不能声称多保27血会救后场。",
     "固定实际召唤与index变化的身份链，核新实体从何时增长；当前进阶攻击取观测表，保留所有杀序。"),
    ("沙虫SL、护栏与成长实付分账", "8JRE1C4H4Z2W/F33/T2、T5、T11；d270216/270282；s276208—276212、276274—276278、276433—276434；原提案关联12账本。",
     "T2同指纹首/第三试实损3/15、净扣敌10/17；末T11为5HP/22挡对37，毒24实际结算一次、敌154→130。",
     "silent-sl-comparison、silent-selection-audit、silent-hp-guard-audit已有候选/派发前快照；actual_turn、actual_turn_result、actual_outcome仍为null。",
     "候选/护栏/SL快照已有窄实现，完整执行、跨抽弃牌重规划、成长兑现和资源链尚未联合读回；同题0/24与5/24及损失封顶不能替代完整后继或探索收益校准。",
     "更防御的末试仍死亡，不支持一律保血；同指纹两次计算样本分别8和24，不能当完全同批随机实验。",
     "按真实observed_ts回连原状态，分别保留Jev原答、护栏、SL、首次派发与执行端点；后置新局按run_id切分。"),
    ("实验体SL替换与未执行续步", "YF0LXT1QSTGG/F48/T1；d271309/271348/271354；s277327—277337、277366—277373；silent-0079。",
     "同指纹第二/第三试均选plan5；实损0/9、净扣45/38。两次当前题面候选数/执行续步需要分别核，不能由原答标成整线已执行。",
     "silent-sl-resource-comparison已有资源预测且execution=unverified；silent-sl-comparison把actual_turn_result留null。",
     "已核0/9血价与45/38净扣，仍缺跨抽弃牌/覆盖重放后的完整候选归属和未选线后继；当前预测字段不是实际完成证明，不能拟全败SL惩罚系数。",
     "同局F33有成功SL；F48第四次T5候选在弃牌后改变，原提案保留此执行反例，本批不冒重新核完整F33/F48所有尝试。",
     "对原答、替线、覆盖重放、重规划分别核动作前缀和结算端点；后置独立完局验证，不因全败而禁止全部探索。"),
    ("实验体阶段、零毒触媒与敏捷时点", "YF0LXT1QSTGG/F48/T3—5；s277512—277528；silent-0021、0027、0028、0085。",
     "旧阶段4毒/15力到212血新阶段均清零；已建触媒2而当前毒0；末敏捷5→6时已有23挡不倒补，37净扣敌分账。",
     "silent-phase-current.ts已有当前快照与零毒说明；silent-phase-reference.ts展示当前阶段结束参考，已结毒伤仍未知。",
     "阶段清空、零毒触媒和后取得敏捷已有窄参考，仍缺候选逐步施毒/已结毒伤与阶段切换后的完整执行对账；不能把持牌、当前毒或模型预测当实际毒收益，也无调整排序的独立胜负证据。",
     "原提案保留已建毒雾/余像仍败的尝试；组件持有不代表本阶段已建立，提前建能力的整战收益未隔离。",
     "继续分列run_deck/hand/established/poison_now/poison_dealt及候选重规划；可操作末帧44攻与死后下一显示55攻不能混为同一结算依据。"),
    ("双蟹零胜并列SL血价", "XP2SL33HT0D9/F33/T1、T3；d271982/272195、271992/272040；silent-0079。",
     "T3同指纹实损9/14、净扣24/27；T1同指纹实损2/10、净扣25/34，末试同时建立1力量。",
     "现有SL候选比较会记录当轮损血/伤害/力量；explore.ts:1552、1561以B2或死亡比例集合继续排序。",
     "两组配对证实血价，但没有相同抽序及朝向/随机药瓶后继受控的整场胜线；缺零胜并列下血价与永久成长的独立校准，不能设置HP惩罚常数或封禁付血探索。",
     "末试T2/3仍有实际零损/低损分支；T1多9净扣同时多8损血并得1力量，不能丢弃成长项。",
     "对T1/T3分别保留原答、替线与实际端点；原题面样本首T1为4、首T3为8，后题为24，不合并概率分母。"),
    ("双蟹朝向、临时减力与轮初挡", "XP2SL33HT0D9/F33/末试T2—5；s278236—278261；silent-0021、0005、0007、0063、0065、0241、0242。",
     "14轮初挡加斗篷6成20；爪力0→−9→0；火箭攻击57→38→28；T4四敏脆弱挡6且实损22，末轮毒净扣10。",
     "passive-pieces.ts已有船夹板T2/14，turn-solver与rollout处理当前朝向/临减，selection审计仍只为预测。",
     "船夹板和临时减力已有窄实现，仍缺逐候选朝向、弱、临减恢复、已兑现伤害及抽弃牌后续的联合执行记录；当前单帧/候选字段不能证明整提案闭环，未验证条件保持未知。",
     "已建四敏捷且有手里剑仍未减员；两侧均活的样本不能推断一侧死亡后的机制。原提案引用的早期两局本批未重验，不扩充本批分母。",
     "逐来源核57→38→28、临减恢复、14+6与实际端点；不从牌数或总伤反推朝向，不改出牌权重。"),
    ("综合机制、SL与资源消费者闭环", "YF0LXT1QSTGG/F48/T1、T4—5及XP2SL33HT0D9/F33/T1—5；原提案关联22账本。",
     "本批重核上述四组同指纹净血价及阶段/朝向/临时减力；它们属于两局关联尝试，不是原报告101局/1499房的重建。",
     "已有SL/HP护栏/阶段/船夹板等窄功能源码，未提供完整资源归因及实际回合执行消费者。",
     "综合项缺完整路线/休息/药水/SL恢复资源链与候选实际执行的联合消费者读回，以及留药/替线独立验证；六锚点不能替原101局统计重建或关闭宽父要求。",
     "原报告的普通/升级镣铐22次、船夹板50帧及101局分母仅作原文出处，不冒称本批逐一复核；多次SL不增独立局。",
     "沿原id接续资源来源、预测/实际、恢复/回血/用药及成长兑现审计，未见动作规则改进证据时保持原行为。"),
]

results = []
sections = []
for p, (title, anchor, facts, existing, reason, counter, validation) in zip(proposals, details):
    results.append({"id": p["id"], "state": "waiting", "reason": reason})
    sections.append(f"""### {p['id']}：{title}

处置：**waiting**。账本：{', '.join(p['ledger'])}。来源任务：{p['source_task']}；本次实现任务：{BATCH}。原提案SHA256：`{p['proposal_sha256']}`，原字节副本：`{p['id']}.original.md`。

- 证据局/层/回合：{anchor}
- 本批核实：{facts}
- 已有覆盖：{existing}
- 具体缺口：{reason}
- 反例与限制：{counter}
- 预期行为/验证：{validation}

旧行为继续保留；本批不增加强制规则、删选项或拟合参数。以后若补源码，必须用固定输入撤源码失败/恢复通过、原沙箱检查、实际live祖先与上线记录验收。回退本批无需撤生产代码；追溯记录追加保存。
""")

(HERE / "proposal-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
intro = f"""# 静默猎手十项原提案逐项核验

记录时间：{STAMP}（先执行date）。batch：{BATCH}；角色silent；普通已领取提案队列，非专题/实现请求。基线与最终HEAD：`{BASE}`。

本批未发现足以据此新增源码修复或改变策略参数的证据，十项均waiting。局部已实现功能与未完成联合要求分别记录；不把窄实现登记为整项duplicate。原提案完整保存且逐一核对保存的SHA，不新建重复id、改原文或重写复盘。

本批只对六个派发锚点的原日志和本角色条目作数值核验；当前经验中的历史支持数不是本批实验分母。不使用预训练游戏事实。未派下级agent，未联网、运行play或修改其他角色数据。

"""
(HERE / "proposal.md").write_text(intro + "\n".join(sections))

stream_table = "\n".join(f"| {m['stream']} | {sum(m['counts'].values())} | {m['source_size']} | {m['invalid_lines']} |" for m in manifest)
result_table = "\n".join(f"| {p['id']} | waiting | {d[0]} |" for p, d in zip(proposals, details))
report = intro + f"""## 身份、基线和范围

开工git status干净；`git merge --no-edit main`返回Already up to date，HEAD保持上述40位base。根learn.json只选本batch，角色/worktree/runs/十个proposal_ids一致，无proposal_repair、research_request、implementation_request；reason=proposal。普通专题请求属于20261010另一批，身份不匹配，未读其work_spec或manifest、未接管专题。

runs.jsonl逐局核实：CA5KE8GFJ9X2/F13、5PM6JAQG6FNQ/F39、DUZUBAJ3A8GP/F30、8JRE1C4H4Z2W/F33、YF0LXT1QSTGG/F48、XP2SL33HT0D9/F33，均SILENT/A10/失败。原运行源码均带dirty，不宣称当前源码复原历史dirty树。runs-identity.json、dispatch.json保存身份；十份原提案SHA全部一致；ledger-before.json与silent-experience-selection.json只选关联本角色条目，未改知识。

## 原始证据冻结和复核

使用本工作树的共用extract_evidence.py，nice19单进程抽取八流。逐行保存source、line、offset、bytes、SHA和显式身份。verify_evidence.py读回每个原始字节切片、JSON及唯一身份，核各流冻结source_size、输出SHA和逐局计数，共8274行。材料断言{checks['count']}项首次通过，详见material-checks.json；这是材料核验，不是生产测试或源码红绿。

| 流 | 所属行数 | 冻结source_size | 全流无效JSON行 |
|---|---:|---:|---:|
{stream_table}

无效JSON不能归属到本批局号。fight-plans在该截点选择0行，只表示本截点未选到，不断言原始日志缺失。各流独立冻结大小，不把后续增长或正文提及混入。核验脚本和原抽取结果均保留；未覆盖旧报告或零行初稿。

语义分析重点是proposal.md列出的战斗窗口，不冒称对8274行的全部语义、全部历史或其他进阶完成研究。

## 同指纹SL的实际端点

actual-pair-endpoints.json通过决策observed_ts精确回连唯一状态，取本回合结束后的第一状态；不是按候选文本当作实打。四组指纹逐字相等：

| 局/层/回合 | 决策原行 | 状态起点→端点 | 实付净失血 | 敌本体净扣 |
|---|---|---|---|---|
| 8JRE1C4H4Z2W/F33/T2 首/第三试 | 270216/270282 | 276208→276212 / 276274→276278 | 3/15 | 10/17 |
| YF0LXT1QSTGG/F48/T1 第二/第三试 | 271309/271348 | 277327→277337 / 277366→277373 | 0/9 | 45/38 |
| XP2SL33HT0D9/F33/T3 首/第二试 | 271992/272040 | 278028→278031 / 278076→278079 | 9/14 | 24/27 |
| XP2SL33HT0D9/F33/T1 首/末试 | 271982/272195 | 278018→278023 / 278231→278236 | 2/10 | 25/34 |

同指纹不等于同一次推演：沙虫两题分别8/24样本；XP/T3为8/24，XP/T1为4/24；YF两题均24。沙虫第三试同题候选的0/24与5/24及后续损失封顶47须分别保留，不冒同死率。随机采样题面、当前净扣与整战胜负是不同观测。本批不拟合血价、能力优先级、药水价格或SL门槛。

## 当前源码与实际live边界

只读live快照：`{source['live_readonly_observed']}`。source-provenance.json核14个相关源码叶及来源提交，全部来源提交是实际live祖先；10叶字节相同，另4叶仅为已有Roy/Dai注释文字差异，完整差异保存在base-live-source-differences.patch，不覆盖现树。祖先证明仅说明来源已进入历史，不能代替历史dirty运行树、当前消费或整提案实现。

- SL候选比较/资源预测/HP护栏：当前路径来源`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`，已在live历史；actual_turn_result/actual_outcome仍null。
- 选择阶段快照：`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`，actual_turn=null且execution_status=pending_dispatch。
- 实验体当前阶段快照：`aad2700abed6dff1d66e87fb36aaa6fedb39adf3`，已结毒伤仍null；阶段结束参考`1d57f9d0dbbb63603e9ce9768e74cb2021478464`只按已列候选比较。
- 污染/增长/当前进阶DB/船夹板等接线存在，本批核其职责，未以源码存在宣称联合校准、完整候选执行或策略收益。

## 十项处置

| 派发id | 状态 | 范围 |
|---|---|---|
{result_table}

完整逐项证据、全部账本id、反例、旧行为、新行为边界、缺口及验证计划见proposal.md；proposal-results.json逐项保留具体waiting原因，不关闭原父要求。

## 记录与验证结果

源码/任务模板/知识无修改；fixes=[]、merged=null，不运行撤源码负控、tsc、vitest，不制造提交、eval版本、上线/双通知或shipped。tests固定为tsc=null、vitest=null、cases=null。未合入的原因是无源码变更，不是等待额外审批。

仅用根ledger.py update给原有相关条目追加本报告/proposal追溯，by=learner:strategy-proposal；不重复添加同一局support/repeat，不改claim、首证、先验、证据、status、version或冒标shipped。CLI输入/输出与后验保护字段核对见ledger-updates.jsonl、ledger-update.stdout.txt及ledger-after-check.json。无新代码提案，code_proposals沿用十个原CLI id，implementation_domains=[]。

原始失败和限制：一次临时查看首条state把combat=null当字典，AttributeError后改为仅查看combat对象；一次工具启动遇并行回收目录导致bubblewrap扫描失败，后续原命令正常。定位队列时误读fix-queue-v4.md一段早期通用队列，其中非本角色材料未用于结论、证据、权重或分母，后续只处理派发id；本批游戏判断均以上述六局原日志核验为依据。未自行核本原生模型/推理设置，未修改配置或声称切换。它们均不算产品故障、游戏反证、生产测试失败或测试成功；记录原样保留在preparation-notes.md。

后续需有明确新数据或完整联合执行校准再沿原id接续；本批结束不关闭量化学习/学习入库父要求，不冒称大脑已采用或经验已经发布。
"""
(HERE / "report.md").write_text(report)
(HERE / "preparation-notes.md").write_text("# 本批材料准备记录\n\n" + report.split("原始失败和限制：", 1)[1].split("后续需", 1)[0])

ledger_before = json.loads((HERE / "ledger-before.json").read_text())
updates = []
for ident in ledger_before:
    owners = [p["id"] for p in proposals if ident in p["ledger"]]
    updates.append({"id": ident, "by": "learner:strategy-proposal",
                    "where": {"proposal": [str(HERE / "proposal.md"), str(HERE / "report.md")]},
                    "note": f"{BATCH}仅补原提案核验追溯；六局A10原字节与局部数值读回，关联{','.join(owners)}；均waiting，具体缺口见报告。无新游戏结论/重复证据/源码/合入，不改旧claim/首证/prior/status/version，不标shipped。"})
(HERE / "ledger-updates.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in updates))

final = {"task": "strategy-proposal", "character": "silent", "batch": BATCH,
         "base": BASE, "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
         "tests": {"tsc": None, "vitest": None, "cases": None},
         "code_proposals": [p["id"] for p in proposals], "implementation_domains": [],
         "proposal_results": results, "report": str(HERE / "report.md")}
(HERE / "result.json").write_text(json.dumps(final, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"report": final["report"], "proposal_results": len(results), "ledger_link_updates": len(updates),
                  "material_checks": checks["count"]}, ensure_ascii=False))

# 静默猎手十项原提案逐项核验

记录时间：2026-10-16 04:50:02 CST（先执行date）。batch：20261016-044302-s2-strategy-proposal；角色silent；普通已领取提案队列，非专题/实现请求。基线与最终HEAD：`38a1f2e4d59f9582bf78e562aeecd39e1dd11375`。

本批未发现足以据此新增源码修复或改变策略参数的证据，十项均waiting。局部已实现功能与未完成联合要求分别记录；不把窄实现登记为整项duplicate。原提案完整保存且逐一核对保存的SHA，不新建重复id、改原文或重写复盘。

本批只对六个派发锚点的原日志和本角色条目作数值核验；当前经验中的历史支持数不是本批实验分母。不使用预训练游戏事实。未派下级agent，未联网、运行play或修改其他角色数据。

## 身份、基线和范围

开工git status干净；`git merge --no-edit main`返回Already up to date，HEAD保持上述40位base。根learn.json只选本batch，角色/worktree/runs/十个proposal_ids一致，无proposal_repair、research_request、implementation_request；reason=proposal。普通专题请求属于20261010另一批，身份不匹配，未读其work_spec或manifest、未接管专题。

runs.jsonl逐局核实：CA5KE8GFJ9X2/F13、5PM6JAQG6FNQ/F39、DUZUBAJ3A8GP/F30、8JRE1C4H4Z2W/F33、YF0LXT1QSTGG/F48、XP2SL33HT0D9/F33，均SILENT/A10/失败。原运行源码均带dirty，不宣称当前源码复原历史dirty树。runs-identity.json、dispatch.json保存身份；十份原提案SHA全部一致；ledger-before.json与silent-experience-selection.json只选关联本角色条目，未改知识。

## 原始证据冻结和复核

使用本工作树的共用extract_evidence.py，nice19单进程抽取八流。逐行保存source、line、offset、bytes、SHA和显式身份。verify_evidence.py读回每个原始字节切片、JSON及唯一身份，核各流冻结source_size、输出SHA和逐局计数，共8274行。材料断言37项首次通过，详见material-checks.json；这是材料核验，不是生产测试或源码红绿。

| 流 | 所属行数 | 冻结source_size | 全流无效JSON行 |
|---|---:|---:|---:|
| states | 4062 | 13316190678 | 2 |
| decisions | 3941 | 1778992474 | 2 |
| sl-attempts | 38 | 42213013 | 0 |
| run-config | 6 | 1818194 | 0 |
| run-plans | 33 | 8339076 | 0 |
| brain | 188 | 632062342 | 1 |
| runs | 6 | 342261 | 0 |
| fight-plans | 0 | 2233957 | 0 |

无效JSON不能归属到本批局号。fight-plans在该截点选择0行，只表示本截点未选到，不断言原始日志缺失。各流独立冻结大小，不把后续增长或正文提及混入。核验脚本和原抽取结果均保留；未覆盖旧报告或零行初稿。

语义分析重点是proposal.md列出的战斗窗口，不冒称对8274行的全部语义、全部历史或其他进阶完成研究。

## 同指纹SL的实际端点

actual-pair-endpoints.json通过决策observed_ts精确回连唯一状态，取本回合结束后的第一状态；不是按候选文本当作实打。四组指纹逐字相等：

| 局/层/回合 | 决策原行 | 状态起点→端点 | 实付净失血 | 敌本体净扣 |
|---|---|---|---|---|
| 8JRE1C4H4Z2W/F33/T2 首/第三试 | 270216/270282 | 276208→276212 / 276274→276278 | 3/15 | 10/17 |
| YF0LXT1QSTGG/F48/T1 第二/第三试 | 271309/271348 | 277327→277337 / 277366→277373 | 0/9 | 45/38 |
| XP2SL33HT0D9/F33/T3 首/第二试 | 271992/272040 | 278028→278031 / 278076→278079 | 9/14 | 24/27 |
| XP2SL33HT0D9/F33/T1 首/末试 | 271982/272195 | 278018→278023 / 278231→278236 | 2/10 | 25/34 |

同指纹不等于同一次推演：沙虫两题分别8/24样本；XP/T3为8/24，XP/T1为4/24；YF两题均24。沙虫第三试同题候选的0/24与5/24及后续损失封顶47须分别保留，不冒同死率。随机采样题面、当前净扣与整战胜负是不同观测。本批不拟合血价、能力优先级、药水价格或SL门槛。

## 当前源码与实际live边界

只读live快照：`e716bd28fd8eca9e4d76d066680304fd11935e37`。source-provenance.json核14个相关源码叶及来源提交，全部来源提交是实际live祖先；10叶字节相同，另4叶仅为已有Roy/Dai注释文字差异，完整差异保存在base-live-source-differences.patch，不覆盖现树。祖先证明仅说明来源已进入历史，不能代替历史dirty运行树、当前消费或整提案实现。

- SL候选比较/资源预测/HP护栏：当前路径来源`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`，已在live历史；actual_turn_result/actual_outcome仍null。
- 选择阶段快照：`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`，actual_turn=null且execution_status=pending_dispatch。
- 实验体当前阶段快照：`aad2700abed6dff1d66e87fb36aaa6fedb39adf3`，已结毒伤仍null；阶段结束参考`1d57f9d0dbbb63603e9ce9768e74cb2021478464`只按已列候选比较。
- 污染/增长/当前进阶DB/船夹板等接线存在，本批核其职责，未以源码存在宣称联合校准、完整候选执行或策略收益。

## 十项处置

| 派发id | 状态 | 范围 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | waiting | 感染棱柱污染与技能收益 |
| silent-proposal-ae9e692d680e3819 | waiting | 失落/遗忘逐来源抢夺与返还 |
| silent-proposal-52f1e1bd2e7db0ed | waiting | 下水道蚌加压与当前进阶事实 |
| silent-proposal-6dd8bbff876be528 | waiting | 电击机器人连续增长与实体身份 |
| silent-proposal-578e415a259e6835 | waiting | 沙虫SL、护栏与成长实付分账 |
| silent-proposal-c0767768bf6a7ab1 | waiting | 实验体SL替换与未执行续步 |
| silent-proposal-a46bdb7fe711d79a | waiting | 实验体阶段、零毒触媒与敏捷时点 |
| silent-proposal-1044224808015e5c | waiting | 双蟹零胜并列SL血价 |
| silent-proposal-7cbc6005db712ba9 | waiting | 双蟹朝向、临时减力与轮初挡 |
| silent-proposal-c59f592f1427a67e | waiting | 综合机制、SL与资源消费者闭环 |

完整逐项证据、全部账本id、反例、旧行为、新行为边界、缺口及验证计划见proposal.md；proposal-results.json逐项保留具体waiting原因，不关闭原父要求。

## 记录与验证结果

源码/任务模板/知识无修改；fixes=[]、merged=null，不运行撤源码负控、tsc、vitest，不制造提交、eval版本、上线/双通知或shipped。tests固定为tsc=null、vitest=null、cases=null。未合入的原因是无源码变更，不是等待额外审批。

仅用根ledger.py update给原有相关条目追加本报告/proposal追溯，by=learner:strategy-proposal；不重复添加同一局support/repeat，不改claim、首证、先验、证据、status、version或冒标shipped。CLI输入/输出与后验保护字段核对见ledger-updates.jsonl、ledger-update.stdout.txt及ledger-after-check.json。无新代码提案，code_proposals沿用十个原CLI id，implementation_domains=[]。

原始失败和限制：一次临时查看首条state把combat=null当字典，AttributeError后改为仅查看combat对象；一次工具启动遇并行回收目录导致bubblewrap扫描失败，后续原命令正常。定位队列时误读fix-queue-v4.md一段早期通用队列，其中非本角色材料未用于结论、证据、权重或分母，后续只处理派发id；本批游戏判断均以上述六局原日志核验为依据。未自行核本原生模型/推理设置，未修改配置或声称切换。它们均不算产品故障、游戏反证、生产测试失败或测试成功；记录原样保留在preparation-notes.md。

后续需有明确新数据或完整联合执行校准再沿原id接续；本批结束不关闭量化学习/学习入库父要求，不冒称大脑已采用或经验已经发布。

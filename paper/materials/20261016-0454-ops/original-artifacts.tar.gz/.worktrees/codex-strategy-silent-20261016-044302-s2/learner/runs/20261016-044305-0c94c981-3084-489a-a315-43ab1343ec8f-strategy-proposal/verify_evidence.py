import collections
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location("batch_extractor", ROOT / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def write(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(raw):
    return {p["power_id"]: p.get("amount") for p in raw or []}


def state_summary(item):
    st = item["row"].get("state") or {}
    run = st.get("run") or {}
    combat = st.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": item["line"], "run_id": item["run_id"],
        "floor": run.get("floor"), "turn": st.get("turn"),
        "in_combat": st.get("in_combat"), "screen": st.get("screen"),
        "hp": run.get("current_hp"), "block": player.get("block"),
        "played": player.get("cards_played_this_turn"),
        "powers": powers(player.get("powers")),
        "hand": [c.get("card_id") for c in combat.get("hand") or []],
        "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"),
                     "hp": e.get("current_hp"), "max_hp": e.get("max_hp"),
                     "alive": e.get("is_alive"), "block": e.get("block"),
                     "powers": powers(e.get("powers")), "move": e.get("move_id"),
                     "attacks": [[i.get("damage"), i.get("hits")] for i in e.get("intents") or []
                                 if isinstance(i.get("damage"), (int, float))]}
                    for e in combat.get("enemies") or []],
    }


def main():
    dispatch = json.loads((SCRATCH / "dispatch.json").read_text())
    runs = dispatch["runs"]
    manifests = json.loads((SCRATCH / "evidence/evidence-manifest.json").read_text())
    verified = []
    states = {}
    decisions = {}
    anchors = {270216, 270282, 270264, 271309, 271348, 271354, 271992, 272040,
               271982, 272195, 272076, 271495, 271509}
    for manifest in manifests:
        path = SCRATCH / "evidence" / (manifest["stream"] + ".evidence.jsonl")
        counts = collections.Counter()
        digest = hashlib.sha256()
        with open(Path("/home/dw/Projects/agent-sts2/logs") / (manifest["stream"] + ".jsonl"), "rb") as source:
            for encoded in path.open("rb"):
                digest.update(encoded)
                item = json.loads(encoded)
                assert item["run_id"] in runs
                assert item["offset"] + item["bytes"] <= manifest["source_size"]
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                row = json.loads(raw)
                assert row == item["row"]
                assert extractor.run_identity(row) == item["run_id"]
                counts[item["run_id"]] += 1
                if manifest["stream"] == "states":
                    states[item["line"]] = state_summary(item)
                if manifest["stream"] == "decisions" and item["line"] in anchors:
                    decisions[item["line"]] = row
        assert digest.hexdigest() == manifest["output_sha256"]
        assert all(counts[r] == manifest["counts"][r] for r in runs)
        verified.append({"stream": manifest["stream"], "rows": sum(counts.values()),
                         "source_size": manifest["source_size"], "counts": dict(counts),
                         "output_sha256": digest.hexdigest(), "byte_identity_verified": True,
                         "invalid_lines": manifest["invalid_lines"],
                         "incomplete_lines": manifest["incomplete_lines"]})
    write("evidence-verification.json", verified)
    wanted = {"DUZUBAJ3A8GP": {27, 30}, "5PM6JAQG6FNQ": {38, 39},
              "CA5KE8GFJ9X2": {13}, "8JRE1C4H4Z2W": {17, 33},
              "YF0LXT1QSTGG": {33, 48}, "XP2SL33HT0D9": {31, 33}}
    with (SCRATCH / "combat-state-summaries.jsonl").open("w") as target:
        for st in states.values():
            if st["floor"] in wanted[st["run_id"]]:
                target.write(json.dumps(st, ensure_ascii=False) + "\n")
    pairs = []
    for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
        assert decisions[a]["fingerprint"] == decisions[b]["fingerprint"]
        pair = {"first": a, "second": b, "fingerprint_equal": True, "decisions": []}
        for n in [a, b]:
            row = decisions[n]
            criteria = row["questions"]["plan"]["criteria"]
            parsed = {k: json.loads(v) if isinstance(v, str) and v.startswith("{") else v
                      for k, v in criteria.items()}
            pair["decisions"].append({"line": n, "run_id": row["run_id"],
                "floor": row["floor"], "turn": row["turn"], "sl_attempt": row.get("sl_attempt"),
                "answers": row.get("answers"), "chosen": row.get("chosen"),
                "rationale": row.get("rationale"), "rollout": row.get("rollout"),
                "candidates": parsed})
        pairs.append(pair)
    write("fingerprint-pairs.json", pairs)
    windows = []
    for lo, hi in [(277327, 277337), (277366, 277373), (278017, 278021),
                   (278231, 278236), (278236, 278242), (277512, 277528),
                   (278249, 278254)]:
        window = [states[n] for n in range(lo, hi + 1) if n in states]
        assert len(window) == hi - lo + 1
        windows.append({"lo": lo, "hi": hi, "states": window})
    write("anchor-windows.json", windows)
    print(json.dumps({"verified_rows": sum(v["rows"] for v in verified),
                      "streams": verified, "fingerprint_pairs": len(pairs)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

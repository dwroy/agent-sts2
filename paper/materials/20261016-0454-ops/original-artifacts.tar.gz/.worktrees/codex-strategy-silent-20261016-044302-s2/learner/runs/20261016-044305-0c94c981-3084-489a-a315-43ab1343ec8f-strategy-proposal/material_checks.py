import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = {r["line"]: r for r in map(json.loads, (HERE / "combat-state-summaries.jsonl").open())}
checks = []


def equal(label, actual, expected):
    checks.append({"claim": label, "actual": actual, "expected": expected, "matches": actual == expected})


def pp(n, key):
    return states[n]["powers"].get(key, 0)


def enemy(n, ident=None):
    es = states[n]["enemies"]
    return next(e for e in es if e["id"] == ident) if ident else es[0]


def ep(n, key, ident=None):
    return enemy(n, ident)["powers"].get(key, 0)


def threat(n, ident=None):
    return sum(d * h for d, h in enemy(n, ident)["attacks"])


verified = json.loads((HERE / "evidence-verification.json").read_text())
equal("八流原字节及身份核验", all(x["byte_identity_verified"] for x in verified), True)
equal("所属原行总数", sum(x["rows"] for x in verified), 8274)
identity = json.loads((HERE / "runs-identity.json").read_text())
equal("六局角色与进阶", sorted({(x["row"]["character"], x["row"]["ascension"]) for x in identity}), [("SILENT", 10)])

for n, hp, damage in [(270216, 3, 10), (270282, 15, 17), (271309, 0, 45),
                      (271348, 9, 38), (271982, 2, 25), (272195, 10, 34),
                      (271992, 9, 24), (272040, 14, 27)]:
    row = next(x for x in json.loads((HERE / "actual-pair-endpoints.json").read_text()) if x["decision_line"] == n)
    equal(f"d{n}实付净血价/本体净扣", [row["net_hp_lost"], row["enemy_hp_net_reduction"]], [hp, damage])

equal("DU/F27火花3与6", [ep(n, "VITAL_SPARK_POWER") for n in [274830, 274834]], [3, 6])
equal("DU/F27T4污染与能力插入", [pp(n, "TAINTED_POWER") for n in range(274830, 274835)], [0, 3, 3, 6, 0])
equal("DU/F27T5污染及轮初消失", [pp(n, "TAINTED_POWER") for n in range(274835, 274840)], [0, 6, 12, 18, 0])
equal("DU/F27T5弱下攻击增长", [threat(n) for n in range(274835, 274839)], [12, 17, 21, 26])
equal("DU/F27T4/T5净失血", [states[274830]["hp"] - states[274834]["hp"], states[274834]["hp"] - states[274839]["hp"]], [3, 9])
equal("5PM/F38连续电击实体上限", [enemy(n, "ZAPBOT")["max_hp"] for n in [274308, 274313]], [23, 23])
equal("5PM/F38电击增长", [[ep(n, "STRENGTH_POWER", "ZAPBOT"), threat(n, "ZAPBOT")] for n in [274308, 274313]], [[2, 17], [4, 19]])
equal("5PM/F39两步法后敏捷", [pp(n, "DEXTERITY_POWER") for n in [274351, 274352, 274354]], [-4, -2, 0])
equal("5PM/F39失落退场前后力", [pp(n, "STRENGTH_POWER") for n in [274357, 274358]], [-4, 0])
equal("5PM/F39T6再次负敏", pp(274362, "DEXTERITY_POWER"), -2)
equal("5PM/F39末试单步法", [pp(n, "DEXTERITY_POWER") for n in [274391, 274392]], [-4, -2])
equal("CA/F13喷水增长", [[ep(n, "STRENGTH_POWER"), threat(n)] for n in [273237, 273252, 273263]], [[0, 11], [4, 15], [8, 19]])
equal("CA/F13末弱与存活缺口", [threat(273268), states[273268]["hp"], states[273268]["block"], states[273269]["hp"]], [14, 2, 10, 0])
equal("8J/F33末轮可操作攻击与格挡", [threat(276433), states[276433]["block"], states[276433]["hp"]], [37, 22, 5])
equal("8J/F33末毒只结算一次", [enemy(276433)["hp"] - enemy(276434)["hp"], ep(276434, "POISON_POWER")], [24, 23])
equal("YF/F48换阶段前后毒与力量", [[ep(n, "POISON_POWER"), ep(n, "STRENGTH_POWER")] for n in [277512, 277513]], [[4, 15], [0, 0]])
equal("YF/F48零毒触媒建立", [pp(277518, "ACCELERANT_POWER"), ep(277519, "POISON_POWER")], [2, 0])
equal("YF/F48后取得敏捷不倒补挡", [[pp(n, "DEXTERITY_POWER"), states[n]["block"]] for n in [277523, 277526]], [[5, 23], [6, 23]])
equal("YF/F48已付四刀与消耗净扣", enemy(277519)["hp"] - enemy(277527)["hp"], 37)
equal("YF/F48可操作末轮存活缺口", threat(277527) - states[277527]["block"] - states[277527]["hp"], 3)
equal("XP/F33船夹板及斗篷", [states[n]["block"] for n in [278236, 278240]], [14, 20])
equal("XP/F33临时减力与恢复", [ep(n, "STRENGTH_POWER", "CRUSHER") for n in [278236, 278237, 278242]], [0, -9, 0])
equal("XP/F33朝向与弱分账", [threat(n, "ROCKET") for n in [278249, 278252, 278253]], [57, 38, 28])
equal("XP/F33T4脆弱下挡与实损", [states[278255]["block"], states[278255]["hp"] - states[278257]["hp"]], [6, 22])
equal("XP/F33末毒净扣", sum(e["hp"] for e in states[278260]["enemies"]) - sum(e["hp"] for e in states[278261]["enemies"]), 10)
equal("XP/F33末存活缺口", threat(278260, "CRUSHER") - states[278260]["block"] - states[278260]["hp"], 0)

report = {"scope": "原始材料的数值核验，不是生产源码回归、撤源码负控或策略收益验证", "checks": checks,
          "count": len(checks), "passed": sum(c["matches"] for c in checks)}
(HERE / "material-checks.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"count": report["count"], "passed": report["passed"]}, ensure_ascii=False))
assert all(c["matches"] for c in checks)

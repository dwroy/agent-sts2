# 本批十项原策略提案核验与处置

记录时间：2026-10-18T12:11:59+08:00。角色 silent，直接证据范围 A10。批次 20261018-120018-strategy-proposal。基线 `e123a5ee49c21d5560e7533418fb5eeb32339bd2`。

本批为领取原队列的普通策略任务；无 research_request/implementation_request。根普通专题指向另一批次，不作为本批输入。开工tracked clean，执行合并main为Already up to date。仅处理本批十个原id，不新增重复提案、不重复历史复盘。原提案Markdown逐一SHA吻合，副本assigned-01.md至assigned-10.md。

8条流8444引用逐offset/bytes/SHA/JSON/归局核回；五组相同指纹、七次耗药及12份夹具来源核回。净敌血差只称净差，不当逐源毛伤或单步整战因果；同局SL不作独立样本。本批不拟新数值参数。

## silent-proposal-366288801d9150d9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md

来源任务：postmortem；实现任务：strategy-proposal。账本：silent-0079, silent-0176。

证据：751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652；states 278479→278483、278620→278623、278576→278581、278697→278702、278528→278532、278865→278869。

核实事实：同指纹T2净扣敌9→18、实损13→18；T7净扣敌12→18、实损13→23；T13扣敌17→11、实损8→2。B2 T7 .103→.013，差−.09、SE .0088。

反例与限制：T13省血少输出；六次均失败，不能由T7差额给统一血价或关闭全部较差线探索。

既有实现：candidate_comparison/resource_comparison、B2差/SE及selection_audit已存在，actual_turn与整线执行仍未知。

处置：waiting。缺候选逐源实际结算、同后继完整重放及独立验证；现有预测对照不足关闭整项SL成本审计。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：冻结T2/T7/T13原帧，分开原答、护栏、SL、实际派发与后续状态；若改门槛须同抽序完整比较并用后期独立局验证。

## silent-proposal-85929bdfc8a3fc1b

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md

来源任务：postmortem；实现任务：strategy-proposal。账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。

证据：751FN9QM9MHQ F13 T3、F17 T7/T13/T17；decision 272361；states 278402—278407、278577/278580/278581。

核实事实：有药plan2与整战无药plan5均预测损8、8/8胜，卡牌模型伤26/16；实际饮药建5力量，58→50。T7弃牌未决模型保留两呼唤，已选弃牌后剩一呼唤。

反例与限制：plan3只本轮不喝，后续7/8样本用药；plan5才整战无药。实际未走不喝/留到Boss支线，holdHp未知不能填0。

既有实现：silent-held-loss与silent-potion-reference已展示模型/未决弃牌及未知持有值；不把模型入伤当已确定逐源敌伤。

处置：waiting。缺确定弃牌后完整逐源结算与无药/留到后战的实际整战对照；保守模型和未知持有值说明虽已实现，原验证范围仍未闭合。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：固定F13三种候选及T7弃牌前后；分模型与实际，整战无药与仅本轮不喝分列；不据败局拟留药值。

## silent-proposal-efd9f83ee9e1a6dc

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md

来源任务：experience-update；实现任务：strategy-proposal。账本：silent-0079, silent-0176。

证据：751FN9QM9MHQ F17 T2/T7/T13，证据同366288801d9150d9；来源experience-update而非另一个独立样本。

核实事实：三组成对局部净差重核；同源两经验条目不增加独立局N。

反例与限制：SL多次重打共用牌序；不同后续动作、抽牌及弃牌未受控。

既有实现：已有SL预测对照、持牌失血说明及B2差/SE；不把源码祖先存在等同实际整战结算完成。

处置：waiting。缺完整实际成本归属、受控整战及后期独立验证；同源经验与局部诊断不证明整项完成。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：沿原账本和原id，验证与366288801d9150d9共用冻结案例，后期独立局单独留出，不重复登记经验或源码。

## silent-proposal-131042659448ae74

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md

来源任务：experience-update；实现任务：strategy-proposal。账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。

证据：751FN9QM9MHQ F13 T3、F17 T3/T5/T7/T13/T17；原九类经验及账本按assigned-04.md，局部原帧已抽取。

核实事实：已核肌肉药建5力量、普通步法建2敏捷、呼唤实际6失血及毒/荆棘分账的原证据入口；本批不重估各子机制N。

反例与限制：敏捷未有格挡牌不能预支挡；无实体限制下不能把毒层/反伤牌面当已兑现伤。药水持有未知。

既有实现：已存在持牌失血、无药参考、SL预测比较；九种经验的联合实际结算/跨战资源链未由这些格式器全部完成。

处置：waiting。缺九类经验联合的实际消费者结算和跨战留药对照；不能以几个已有组件登记整项duplicate。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：逐机制分母与实际来源分开，候选公式、真实动作及资源归属逐项比对；不得把药水留至Boss的未走支线写成收益。

## silent-proposal-990f054036609447

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md

来源任务：experience-update；实现任务：strategy-proposal。账本：silent-0102, silent-0019, silent-0020。

证据：KV0JHNJCKXLS F33 第4/5试T5；decisions 273400/273450/273451；states 279460→279465、279511→279515。

核实事实：同指纹HP30/敌334；删致命毒药+后本轮净扣敌36→29，当轮两线实损均0；B2均0、差/SE均0。

反例与限制：两个实际分支后续也改变；零损之间删输出没有实录保血收益。敌回血使净血差不能直接当毛伤。

既有实现：SL比较可列HP/净输出/模型剩余毒，但完整毛伤、敌回血、成长与真实跨房资源账未全部表达。

处置：waiting。缺毛伤/回血/成长完整归属、同后继整战及独立验证；同零损删输出不构成保血收益。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：冻结同盘T5与下一轮毒状态，逐事件拆毛伤/回血，SL截断不补敌方结算；路线休息假设与实际分开。

## silent-proposal-e18d3f18e6cac2a0

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md

来源任务：postmortem；实现任务：strategy-proposal。账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。

证据：YQL8RZ8BWN1E F17六试及T10 states 280160/280161；L9SGRBB5R698 F17 T14 sl-attempts 681参考；PU80F84P6HPN F17 T17 sl-attempts 717参考。

核实事实：YQL毒水使残壳毒2→8，HP26/挡13/自爆41未变；43条尝试行中本提案三局的巨兽阶段与旧占位指标原样保留。

反例与限制：YQL首三试最终血挡−来袭为−30/−34/−31。把占位HP统一归0会改变同轮平局排序，不能当纯显示修正；PU末试胜余2不提供改序受控因果。

既有实现：giantPhaseAtTurnStart、巨兽药水观察及有限最终资源记录已存在；enemyHpLeft/anchorRank仍保留旧raw排序，源码明确注明legacy。

处置：waiting。缺改序后的受控整战、完整最终资源及提前饮药结果；归零占位HP会改变同轮排序，阶段说明不等于整项指标/排序修复。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：先逐帧分本体/占位/自爆，原HP保留；如改排序须冻结旧新选择及完整后继，自爆覆盖与胜负分开。

## silent-proposal-9733bb80f445aeae

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md

来源任务：experience-update；实现任务：strategy-proposal。账本：silent-0017, silent-0019, silent-0020, silent-0250。

证据：YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN，F17巨兽原帧与sl-attempts，来源experience-update；非新增独立支持局。

核实事实：本体已结束与自爆仍待结算分开；毒水局部观察与旧SL指标复核吻合。

反例与限制：提前饮毒、替代路线或新参考路径的完整效果未知，不能从2→8毒推减伤6或获胜。

既有实现：阶段/药水子实现已在live；原参考排序仍依raw占位血，有限最终资源函数不适用于所有旧帧。

处置：waiting。缺阶段改序、提前用药及路线的受控验证；已有阶段/药水说明不能登记整项duplicate。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：复用原三局逐阶段冻结证据，先核指标再验证排序；需要新同角色独立验证，不把六次重打当六局。

## silent-proposal-c51468c5e8ba6668

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md

来源任务：postmortem；实现任务：strategy-proposal。账本：silent-0019。

证据：KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1、T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272及原七组前后药槽帧。

核实事实：实际七次use_potion与七组occupied true→false均核回；ATTACK、STABLE_SERUM、SPEED、WEAK、ATTACK、GLOWWATER、SKILL。

反例与限制：F15零净损已消耗两药，不代表不喝也零损；随机选牌与发光水重问切断原候选整线。六次Boss入口75/86空药栏不证明必须留药。

既有实现：已有通用候选/单步派发审计，但不自动给出七次随机/重问后完整收益及跨战未用分支。

处置：waiting。缺随机选牌/发光水重问后的完整收益归属及未饮用或留至Boss的整战分支；七次实耗不能推出持有价值。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：逐药槽连接取得、选择、饮用、重问和后继；逐项效果验证，不把净HP变化当总敌伤；缺少未饮用支线保持未知。

## silent-proposal-86a7db08d1a31976

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md

来源任务：postmortem；实现任务：strategy-proposal。账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。

证据：KEN58SH9SLZ6 F17 第4/5试T10、第4/6试T5、第二试T2；decisions 274505/274568、274484/274601、274354；states 280588→280592、280651→280655、280567→280572、280684→280689。

核实事实：同盘T10净扣敌2→4、实损15→21；B2 .385→.127，差−.2583、SE .0132。T5实损7→5、净扣1→2，末试步法由T5延到T9。

反例与限制：省2血同时失去较早2敏捷；末试T8双防御只有10挡，不能以当轮少损血恒优。HP护栏原迷雾未执行后续，4毒长期价未知。

既有实现：已有SL预测资源、持牌失血、原答/护栏/SL与单步派发拆项；实际回合、能力后继及整战归属未完整验证。

处置：waiting。缺能力后继、逐源实际归属、同后轮整战及独立验证；不能拟统一6血/2伤门槛或仅保血排序。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：固定T10与T5反向成本，追加小刀与重问后续单列；保留旧护栏/探索，需同后继与后期独立局才评价规则变化。

## silent-proposal-e282a9131b99129a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md

来源任务：experience-update；实现任务：strategy-proposal。账本：silent-0021, silent-0079, silent-0125, silent-0176。

证据：KEN58SH9SLZ6 F17 T5/T10，证据同86a7db08d1a31976；来源experience-update。

核实事实：两组成对实盘差额和步法建立窗口重新核回；原经验来源相同，不新增N。

反例与限制：T10多伤付血与T5省血失能力均存在，不能从其中一个方向拟统一探索门槛。

既有实现：已有预测/单步派发审计，actual_turn仍为null，未给出整战受控结算。

处置：waiting。缺续问后完整执行归属、受控整战及后期独立验证；不足关闭探索或改变HP护栏。

预期行为：保留现行排序、护栏、药水持有与SL规则；保存已有事实及未知，不删合法选项。

验证方法：沿原id及账本关联，冻结同指纹局部事实，完整抽弃/施放后继另核；不复写原复盘或以历史重复研究替代新验证。

## 授权、验证、影响与回退

沿Roy-2026-10-07-learning；授权不提供游戏事实。已实现的局部诊断没有重复改写；本批整项waiting不撤销这些子实现或既有账本shipped事实。证据不足不是追加审批理由。源叶及固定测试叶19项按base与observed live核Git blob、SHA、路径末改commit与live祖先；详见source-audit.json，不能把路径末改commit当整项实现commit。17叶相同，explore/controller差异仅历史署名注释，原注释保留。

无生产源码/知识/任务模板修改、无新提交/合入/版本、无规则上线及Roy双通知。tsc、vitest与撤源红/恢复绿均未执行且记null；原始材料核验不是生产回放或消费者通过。回退不适用；保留全部原证据、旧实现、提案与失败历史。后续获得上述缺失数据后，继续原id，不另开重复id；如改源码再做固定红绿、自测与live流程。

通用经验和其他角色知识未用于得出结论，本批不发布共享经验或改变其他角色行为。经验入库/消费者读回及其他父要求保持原流程；仅本报告不关闭。

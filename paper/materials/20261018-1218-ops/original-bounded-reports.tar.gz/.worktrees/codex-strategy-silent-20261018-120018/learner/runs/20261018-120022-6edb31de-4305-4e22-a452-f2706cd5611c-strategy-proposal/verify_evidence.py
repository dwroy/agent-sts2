import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
sys.path.insert(0, str(WORKTREE / "learner"))
from extract_evidence import run_identity


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
dispatch = json.loads((OUT / "dispatch.json").read_text())
runs = set(dispatch["record"]["runs"])
indices = {}
checks = []
for entry in manifest:
    stream = entry["stream"]
    index = {}
    counts = Counter()
    output_hash = hashlib.sha256()
    source = Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")
    with source.open("rb") as original, (OUT / "evidence" / (stream + ".evidence.jsonl")).open("rb") as extracted:
        for raw in extracted:
            output_hash.update(raw)
            item = json.loads(raw)
            assert Path(item["source"]) == source
            assert item["offset"] + item["bytes"] <= entry["source_size"]
            original.seek(item["offset"])
            line = original.read(item["bytes"])
            assert hashlib.sha256(line).hexdigest() == item["sha256"]
            row = json.loads(line)
            assert row == item["row"]
            assert run_identity(row) == item["run_id"] and item["run_id"] in runs
            if stream == "states":
                state_run = row["state"].get("run") or {}
                assert state_run.get("character_id", "").lower() == "silent"
                assert state_run.get("ascension") == 10
            if stream == "runs":
                assert row["character"].lower() == "silent" and row["ascension"] == 10
            counts[item["run_id"]] += 1
            index[item["line"]] = item
    assert dict(counts) == {run: count for run, count in entry["counts"].items() if count}
    assert output_hash.hexdigest() == entry["output_sha256"]
    indices[stream] = index
    checks.append({"stream": stream, "source_size": entry["source_size"], "verified_rows": sum(counts.values()),
                   "counts": dict(counts), "output_sha256": output_hash.hexdigest()})

states = indices["states"]
decisions = indices["decisions"]


def state(line):
    return states[line]["row"]["state"]


def player(line):
    return state(line)["combat"]["player"]


def hp(line):
    return player(line)["current_hp"]


def enemy(line):
    return state(line)["combat"]["enemies"][0]


def power(entity, name):
    return next((p["amount"] for p in entity["powers"] if p["power_id"] == name), 0)


def transition(first, after):
    assert states[first]["run_id"] == states[after]["run_id"]
    return {"state_lines": [first, after], "player_hp": [hp(first), hp(after)],
            "enemy_hp": [enemy(first)["current_hp"], enemy(after)["current_hp"]],
            "net_hp_loss": hp(first) - hp(after),
            "net_enemy_hp_reduction": enemy(first)["current_hp"] - enemy(after)["current_hp"]}


pair_specs = [(272434, 272575), (272531, 272652), (273400, 273450),
              (274505, 274568), (274484, 274601)]
pairs = []
for left, right in pair_specs:
    a, b = decisions[left]["row"], decisions[right]["row"]
    assert a["fingerprint"] == b["fingerprint"]
    pairs.append({"run": a["run_id"], "floor": a["floor"], "turn": a["turn"],
                  "decision_lines": [left, right], "attempts": [a["sl_attempt"], b["sl_attempt"]],
                  "same_fingerprint": True, "sl_record": b.get("sl_explore")})

observations = {
    "751_t2": [transition(278479, 278483), transition(278620, 278623)],
    "751_t7": [transition(278576, 278581), transition(278697, 278702)],
    "751_t13": [transition(278528, 278532), transition(278865, 278869)],
    "kv_t5": [transition(279460, 279465), transition(279511, 279515)],
    "ken_t10": [transition(280588, 280592), transition(280651, 280655)],
    "ken_t5": [transition(280567, 280572), transition(280684, 280689)],
}
assert [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in observations["751_t2"]] == [(9, 13), (18, 18)]
assert [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in observations["751_t7"]] == [(12, 13), (18, 23)]
assert [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in observations["751_t13"]] == [(17, 8), (11, 2)]
assert [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in observations["kv_t5"]] == [(36, 0), (29, 0)]
assert [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in observations["ken_t10"]] == [(2, 15), (4, 21)]
assert [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in observations["ken_t5"]] == [(1, 7), (2, 5)]
assert power(player(280572), "DEXTERITY_POWER") == 2
assert power(player(280689), "DEXTERITY_POWER") == 0
assert power(player(280697), "DEXTERITY_POWER") == 0 and player(280700)["block"] == 10
assert power(player(280705), "DEXTERITY_POWER") == 2
assert hp(278580) - hp(278581) == 13
assert player(278580)["block"] == 20
assert [c["card_id"] for c in state(278580)["combat"]["hand"]].count("BECKON") == 1
assert hp(278403) == hp(278404) == 58 and power(player(278404), "STRENGTH_POWER") == 5
assert hp(278407) == 50
assert power(enemy(280160), "POISON_POWER") == 2 and power(enemy(280161), "POISON_POWER") == 8
assert [(hp(n), player(n)["block"], enemy(n)["intents"][0]["damage"]) for n in [280160, 280161]] == [(26, 13, 41), (26, 13, 41)]

uses = []
for item in decisions.values():
    row = item["row"]
    if row["run_id"] == "KEN58SH9SLZ6" and (row.get("chosen") or {}).get("action") == "use_potion":
        uses.append({"line": item["line"], "floor": row["floor"], "turn": row["turn"], "chosen": row["chosen"]})
assert [v["line"] for v in uses] == [274131, 274156, 274185, 274235, 274237, 274267, 274272]
potion_frames = [(280206, 280207, 0, "ATTACK_POTION"), (280232, 280233, 0, "STABLE_SERUM"),
                 (280262, 280263, 0, "SPEED_POTION"), (280313, 280314, 1, "WEAK_POTION"),
                 (280315, 280316, 0, "ATTACK_POTION"), (280348, 280349, 1, "GLOWWATER_POTION"),
                 (280354, 280355, 0, "SKILL_POTION")]
for before, after, slot, potion in potion_frames:
    a = {p["index"]: p for p in state(before)["run"]["potions"]}[slot]
    b = {p["index"]: p for p in state(after)["run"]["potions"]}[slot]
    assert a["potion_id"] == potion and a["occupied"] is True
    assert b["occupied"] is False

attempts = defaultdict(list)
for item in indices["sl-attempts"].values():
    row = item["row"]
    attempts[row["run_id"]].append({"line": item["line"], "floor": row["floor"], "encounter": row["encounter"],
        "attempt": row["attempt"], "result": row["result"], "turns": row["turns"],
        "end_hp": row["end_hp"], "end_block": row["end_block"], "incoming": row["incoming"],
        "last_turn": row["summary"]["turns"][-1]})

fixture_checks = []
held_fixture = json.loads((WORKTREE / "agent/tests/silent-held-loss-evidence.json").read_text())
for item in held_fixture:
    source = item["source"]
    if source["run"] not in runs:
        continue
    original = states[source["line"]]
    assert original["sha256"] == source["sha256"] and item["state"] == original["row"]["state"]
    fixture_checks.append({"fixture": "silent-held-loss-evidence.json", "line": source["line"]})
potion_fixture = json.loads((WORKTREE / "agent/tests/silent-potion-reference-evidence.json").read_text())
assert states[potion_fixture["state_line"]]["sha256"] == potion_fixture["state_sha256"]
assert decisions[potion_fixture["decision_line"]]["sha256"] == potion_fixture["decision_sha256"]
assert potion_fixture["state"] == state(potion_fixture["state_line"])
fixture_checks.append({"fixture": "silent-potion-reference-evidence.json", "line": potion_fixture["state_line"]})
for frame in json.loads((WORKTREE / "agent/tests/silent-giant-potion-evidence.json").read_text())["frames"]:
    assert states[frame["line"]]["sha256"] == frame["sha256"] and state(frame["line"]) == frame["state"]
    fixture_checks.append({"fixture": "silent-giant-potion-evidence.json", "line": frame["line"]})

save("evidence-verification.json", {"checks": checks, "verified_rows": sum(v["verified_rows"] for v in checks),
    "pairs": pairs, "observations": observations, "ken_potion_uses": uses,
    "ken_potion_state_transitions": potion_frames, "attempts": dict(attempts), "fixture_checks": fixture_checks,
    "scope": "原始字节、归局、局部状态差与既有夹具核验；未执行生产回放或消费者测试，净差不等于逐源毛伤害或单步因果。"})
for key, value in observations.items():
    print(key, [(v["net_enemy_hp_reduction"], v["net_hp_loss"]) for v in value])
print(json.dumps({"verified_rows": sum(v["verified_rows"] for v in checks), "streams": len(checks),
                  "same_fingerprint_pairs": len(pairs), "fixture_checks": len(fixture_checks),
                  "ken_potion_uses": len(uses)}, ensure_ascii=False))

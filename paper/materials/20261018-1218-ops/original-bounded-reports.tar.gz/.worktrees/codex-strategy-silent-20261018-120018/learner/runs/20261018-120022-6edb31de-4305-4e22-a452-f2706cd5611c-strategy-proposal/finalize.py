import hashlib
import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
result = json.loads((out / "result.json").read_text())
assessments = json.loads((out / "assessments.json").read_text())
dispatch = json.loads((out / "dispatch.json").read_text())
source = json.loads((out / "source-audit.json").read_text())
assert result["base"] == subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert subprocess.check_output(["git", "status", "--porcelain=v1"], text=True) == ""
assert len(result["proposal_results"]) == len({item["id"] for item in result["proposal_results"]}) == 10
assert {item["id"] for item in result["proposal_results"]} == set(dispatch["record"]["proposal_ids"])
assert result["code_proposals"] == dispatch["record"]["proposal_ids"]
assert all(item["state"] == "waiting" and item["reason"] for item in result["proposal_results"])
assert result["proposal_results"] == [
    {"id": item["id"], "state": item["state"], "reason": item["reason"]} for item in assessments
]
assert result["tests"] == {"tsc": None, "vitest": None, "cases": None}
assert result["fixes"] == [] and result["merged"] is None and result["implementation_domains"] == []
assert Path(result["report"]).is_file() and (out / "proposal.md").is_file()
assert json.loads((out / "gitleaks.json").read_text()) == []
assert (out / "final-worktree.diff.patch").stat().st_size == 0
base_nonancestors = []
for entry in source["files"]:
    for scope in ["base", "observed_live"]:
        snapshot = Path(entry[scope]["snapshot"])
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == entry[scope]["sha256"]
    assert entry["observed_live"]["last_path_commit_live_ancestor"]
    if not entry["base"]["last_path_commit_live_ancestor"]:
        base_nonancestors.append({"path": entry["path"], "commit": entry["base"]["last_path_commit"]})
assert base_nonancestors == [{
    "path": "agent/src/sl/controller.ts", "commit": "64f7a8d28769028d6a9cbebfc55a14bfe951e984"
}]
validation = {
    "contract": "passed", "results": len(result["proposal_results"]), "waiting": 10,
    "source_or_knowledge_changes": False, "tests": result["tests"],
    "source_snapshots_verified": 38, "observed_live_source_ancestors": 19,
    "base_non_live_ancestors_preserved": base_nonancestors,
    "initial_failure": "final-validation-initial-failure.txt",
}
(out / "final-validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2) + "\n")
with (out / "report.md").open("a") as handle:
    handle.write(
        "\n## 最终材料验收\n\n时间：" + (out / "final-validation-recorded-at.txt").read_text().strip()
        + "。材料gitleaks dir实际退出0，当次扫描178037294字节、未发现泄漏，gitleaks.json为[]；"
        "这是材料扫描，不是代码测试。10项处置与派发id/理由逐一匹配，16个账本只增链接/说明的核验通过；"
        "HEAD仍为" + result["base"] + "，git status为空，tracked diff为空，38份源码/测试快照SHA核回。"
        "skipped=[]表示十项都已审阅，等待处置由proposal_results记录。tsc/vitest/cases仍为null，无源码提交或live合入。\n\n"
        "首次验收误将base侧历史署名提交也要求为live祖先而退出1，原失败保存在final-validation-initial-failure.txt。"
        "复核仅controller.ts的base路径末改64f7a8d28769028d6a9cbebfc55a14bfe951e984不在live祖先；"
        "对应live快照及其他实际live源码祖先全部成立。更正为只要求observed_live的19项真实源码祖先后验收0，"
        "基线原false值、注释差异和所有快照保留。此失败不记产品失败或代码红绿测试。\n"
    )
files = []
for path in sorted(out.rglob("*")):
    if path.is_file() and path.name not in {"delivery-manifest.json", "finalize.log"} and "__pycache__" not in path.parts:
        raw = path.read_bytes()
        files.append({"path": str(path.relative_to(out)), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
(out / "delivery-manifest.json").write_text(json.dumps({
    "files": files, "count": len(files), "scope": "本批材料；manifest自身及正在写入的finalize.log不自哈希。"
}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({**validation, "delivery_files": len(files), "report": result["report"]}, ensure_ascii=False))

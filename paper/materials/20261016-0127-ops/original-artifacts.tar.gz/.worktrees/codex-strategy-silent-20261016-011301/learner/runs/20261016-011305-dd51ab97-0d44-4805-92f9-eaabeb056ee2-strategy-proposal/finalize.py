import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
payload = json.loads((HERE / 'ledger-update-input.json').read_text())
before = json.loads((HERE / 'ledger-prewrite.json').read_text())
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = set(before)
after, own_rows = {}, []
offset = 0
with (ROOT / 'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    for number, raw in enumerate(handle, 1):
        row = json.loads(raw)
        if row.get('id') in ids:
            ledger.apply(after, row)
            if row.get('by') == 'learner:strategy-proposal' and str(HERE / 'report.md') in row.get('where', {}).get('proposal', []):
                own_rows.append({'line': number, 'offset': offset, 'bytes': len(raw),
                                 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        offset += len(raw)
assert len(own_rows) == len(payload) == 33
assert (HERE / 'ledger-update-output.log').read_text().split() == [p['id'] for p in payload]
assert (HERE / 'ledger-update-stderr.log').stat().st_size == 0
for original, receipt in zip(payload, own_rows):
    actual = receipt['row']
    assert set(actual) == set(original) | {'op', 'ts'}
    assert all(actual[key] == value for key, value in original.items())
    assert actual['op'] == 'update'
for identity in ids:
    old, new = before[identity], after[identity]
    assert {k: v for k, v in old.items() if k not in ('where', 'history', 'notes')} == {
        k: v for k, v in new.items() if k not in ('where', 'history', 'notes')}
    assert new['history'][:-1] == old['history']
    assert new['notes'][:-1] == old['notes']
    for key, values in old['where'].items():
        assert new['where'][key][:len(values)] == values
    assert str(HERE / 'report.md') in new['where']['proposal']
proof = {'appended_rows': len(own_rows), 'all_receipts_match_cli_payload': True,
         'protected_fields_unchanged': True, 'old_history_notes_where_preserved': True,
         'statuses_unchanged': {identity: after[identity]['status'] for identity in sorted(ids)},
         'rows': own_rows}
(HERE / 'ledger-update-verification.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')

result = json.loads((HERE / 'result.json').read_text())
dispatch = json.loads((HERE / 'dispatch.json').read_text())
assert {r['id'] for r in result['proposal_results']} == set(dispatch['proposal_ids'])
assert len(result['proposal_results']) == 10
assert all(r['state'] == 'waiting' and r['reason'] for r in result['proposal_results'])
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == []
assert result['report'] == str(HERE / 'report.md')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=HERE.parents[2]).decode().strip()
assert git('rev-parse', 'HEAD') == result['base']
assert git('status', '--porcelain') == ''
assert git('diff', '--name-only', 'HEAD') == ''
history = json.loads((HERE / 'assigned-proposals-history.json').read_text())
for identity, rows in history.items():
    first = rows[0]['row']
    assert hashlib.sha256(Path(first['proposal']).read_bytes()).hexdigest() == first['proposal_sha256']
    assert hashlib.sha256((HERE / (identity + '.original.md')).read_bytes()).hexdigest() == first['proposal_sha256']
files = ['report.md', 'proposal.md', 'result.json', 'dispositions.json', 'source-audit.json',
         'evidence-verification.json', 'material-checks.json', 'ledger-update-verification.json']
final = {'base': result['base'], 'head': git('rev-parse', 'HEAD'), 'worktree_clean': True,
         'tracked_diff_empty': True, 'source_and_knowledge_changes': [], 'new_commits': [],
         'merged': None, 'tests': result['tests'], 'proposal_results_count': 10,
         'ledger_updates': 33, 'material_assertions': 39,
         'sha256': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in files}}
(HERE / 'final-verification.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(final, ensure_ascii=False))

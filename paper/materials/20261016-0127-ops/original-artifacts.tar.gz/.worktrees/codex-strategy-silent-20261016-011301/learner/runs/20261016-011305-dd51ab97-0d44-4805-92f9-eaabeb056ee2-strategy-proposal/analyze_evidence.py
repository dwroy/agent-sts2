import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', HERE.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
rows = {}
verification = []
for stream in manifest:
    name = stream['stream']
    path = HERE / 'evidence' / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    selected = []
    counts = collections.Counter()
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
        for line in path.open():
            item = json.loads(line)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id']
            if name == 'states':
                assert item['row']['state']['run']['character_id'].lower() == 'silent'
            if name == 'runs':
                assert item['row']['character'].lower() == 'silent'
            counts[item['run_id']] += 1
            selected.append(item)
    assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
    rows[name] = selected
    verification.append({'stream': name, 'verified_rows': len(selected), 'counts': dict(counts),
                         'source_size': stream['source_size'], 'output_sha256': stream['output_sha256']})

def powers(value):
    return {p['power_id']: p['amount'] for p in value.get('powers', [])}

anchors = {223268, 223272, 289339, 289345, 289414, 289420, 289533, 289534, 289535,
           289536, 289537, 289538, 290160, 290165, 290201, 290206, 290212, 290213, 290214}
frames = []
for item in rows['states']:
    s = item['row']['state']
    run = s['run']
    if item['line'] not in anchors:
        continue
    c = s.get('combat') or {}
    p = c.get('player') or {}
    frames.append({'line': item['line'], 'run_id': item['run_id'], 'offset': item['offset'],
                   'bytes': item['bytes'], 'sha256': item['sha256'], 'floor': run['floor'],
                   'turn': s.get('turn'), 'screen': s['screen'], 'hp': run['current_hp'],
                   'block': p.get('block'), 'energy': p.get('energy'), 'powers': powers(p),
                   'cards_played': p.get('cards_played_this_turn'),
                   'hand': [{k: card.get(k) for k in ('index', 'card_id', 'upgraded', 'playable', 'unplayable_preventer_id')}
                            for card in c.get('hand', [])],
                   'potions': [{k: v.get(k) for k in ('index', 'potion_id', 'occupied', 'usage')}
                               for v in run.get('potions', [])],
                   'enemies': [{**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'is_alive')},
                                'powers': powers(e)} for e in c.get('enemies', [])],
                   'pile_text': (s.get('agent_view') or {}).get('combat'),
                   'selection': s.get('selection')})
(HERE / 'anchor-frames.json').write_text(json.dumps(frames, ensure_ascii=False, indent=2) + '\n')
(HERE / 'evidence-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in verification),
                  'streams': verification, 'anchor_frames': len(frames)}, ensure_ascii=False))

for stream in ('decisions', 'sl-attempts', 'run-config', 'run-plans', 'brain', 'fight-plans'):
    if rows[stream]:
        print(stream, 'row_keys', list(rows[stream][0]['row']))
print('锚点简表')
for f in frames:
    print(json.dumps({k: f[k] for k in ('line', 'run_id', 'floor', 'turn', 'screen', 'hp', 'block', 'energy', 'powers', 'enemies')}, ensure_ascii=False))

# 本批工具准备失败和更正

这些是本会话实际工具结果的摘记，原工具回执保留在原会话；不是生产源码、模型或测试失败。

- 一次只读命令在执行前被bubblewrap的glob扫描拦下：`error building bubblewrap command: Fatal error: ripgrep unreadable glob scan failed for /home/dw: rg: /home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261016-011301/.codex: No such file or directory (os error 2)`。未执行该命令正文；重试原局号核验和ledger帮助成功，未调整权限。
- 初次猜测源码文件名silent-demon-poison-potion.ts不存在；随后按combat-plan真实import定位silent-demon-potion.ts。没有因此认定生产缺实现。
- 一次rg使用了不存在的agent/src/core/logs/*.ts路径；另在提取尚运行时读evidence-manifest.json得到文件不存在。均未改代码，待共用提取正常exit0后才做原字节验证。
- 一次离线汇总对observed_intervals误取status键，报KeyError；之后只按真实observed_turns.status汇总为32端点/73未知，生产消费者和原输出未修改。
- 多次工具输出达到预算被截断，未把被截断的显示内容当作完整材料；正式判断用落盘JSON及必要窄字段重新读取。
- 材料脚本创建时的本地import相对路径在首次执行前改正；不存在将准备脚本问题当生产缺陷或测试红绿的声明。

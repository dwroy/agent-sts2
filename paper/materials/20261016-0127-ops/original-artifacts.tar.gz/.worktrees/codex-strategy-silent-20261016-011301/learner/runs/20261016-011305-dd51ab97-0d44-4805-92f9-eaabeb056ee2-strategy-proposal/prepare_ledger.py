import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
entries = json.loads((HERE / 'dispositions.json').read_text())
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = sorted({identity for e in entries for identity in e['ledger']})
items = {}
for line in (ROOT / 'paper/materials/learning/ledger.jsonl').open():
    row = json.loads(line)
    if row.get('id') in ids:
        ledger.apply(items, row)
assert set(items) == set(ids)
assert all(item['character'] == 'silent' for item in items.values())
(HERE / 'ledger-prewrite.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
payload = []
for identity in ids:
    assigned = [e for e in entries if identity in e['ledger']]
    payload.append({'id': identity, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261016-011301-strategy-proposal：本批五个派发静默局八流6060行原字节/身份核验；'
                            '仅追加本批复核去处，不新增旧局support/repeat，不改claim/首证/prior/状态/版本。'
                            '所关联原提案继续waiting，无源码/测试/合入/发布：' +
                            '；'.join(e['id'] + '：' + e['reason'] for e in assigned)})
(HERE / 'ledger-update-input.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'updates': len(payload), 'ids': ids}, ensure_ascii=False))

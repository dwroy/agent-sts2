import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
LEARNER = HERE.parents[1]
spec = importlib.util.spec_from_file_location('resource_chain', LEARNER / 'resource_chain.py')
resource = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resource)

def stream(name):
    return [json.loads(line) for line in (HERE / 'evidence' / (name + '.evidence.jsonl')).open()]

states, decisions, sl, runs = map(stream, ('states', 'decisions', 'sl-attempts', 'runs'))
floors = {'7X0W3U8TVA2A': [31], 'MTQ0EUBJ3R6T': [11, 23],
          'KFRDELW2TH2P': [12, 28, 33], 'GXNKW8X1XYJP': [45]}
summary = []
for record in runs:
    run_id = record['run_id']
    entries = [{**item['row'], '_line': item['line'], '_source_sha256': item['sha256']}
               for item in states if item['run_id'] == run_id]
    attempts = [item['row'] for item in sl if item['run_id'] == run_id]
    starts = {}
    for attempt in attempts:
        if attempt.get('attempt', 1) > 1 and attempt.get('started_at'):
            starts.setdefault(attempt['floor'], []).append(attempt['started_at'])
    chain = resource.resource_chain(entries, run_id, 'silent', starts)
    (HERE / (run_id + '.resources.json')).write_text(json.dumps(chain, ensure_ascii=False, indent=2) + '\n')
    chosen_decisions, exclusions = [], []
    for item in decisions:
        if item['run_id'] != run_id:
            continue
        row = item['row']
        if not row.get('decision_id'):
            exclusions.append({'line': item['line'], 'reason': '没有 decision_id 的元数据行'})
        elif run_id in floors and row.get('floor') in floors[run_id]:
            chosen_decisions.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    if run_id in floors:
        selected_states = [item for item in entries if item['state']['run']['floor'] in floors[run_id]]
        payload = {'run': record['row'], 'decisions': chosen_decisions, 'states': selected_states}
        (HERE / (run_id + '.selection-input.json')).write_text(json.dumps(payload, ensure_ascii=False) + '\n')
    summary.append({'run_id': run_id, 'ascension': record['row']['ascension'],
                    'resource_windows': len(chain['combats']), 'selection_floors': floors.get(run_id),
                    'selection_decisions': len(chosen_decisions), 'excluded_metadata': exclusions})
(HERE / 'consumer-input-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))

import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
checks = []

def check(label, condition):
    assert condition, label
    checks.append(label)

frames = {f['line']: f for f in json.loads((HERE / 'anchor-frames.json').read_text())}
check('KFR同盘HP', frames[289339]['hp'] == frames[289414]['hp'] == 15)
check('KFR同盘敌HP', frames[289339]['enemies'][0]['current_hp'] == frames[289414]['enemies'][0]['current_hp'] == 228)
check('KFR同盘毒36', frames[289339]['enemies'][0]['powers']['POISON_POWER'] == frames[289414]['enemies'][0]['powers']['POISON_POWER'] == 36)
check('KFR原线净扣83', 228 - frames[289345]['enemies'][0]['current_hp'] == 83)
check('KFR替线净扣93', 228 - frames[289420]['enemies'][0]['current_hp'] == 93)
check('KFR多损6', frames[289345]['hp'] - frames[289420]['hp'] == 6)
check('KFR奇巧后7挡', frames[289533]['block'] == 7)
check('KFR三牌后12挡', frames[289536]['block'] == 12 and frames[289536]['cards_played'] == 3)
check('KFR余1能量仍锁爆发', frames[289536]['energy'] == 1 and any(c['card_id'] == 'BURST' and c['unplayable_preventer_id'] == 'SLOTH_POWER' for c in frames[289536]['hand']))
check('KFR饮药加6毒', frames[289537]['enemies'][0]['powers']['POISON_POWER'] - frames[289536]['enemies'][0]['powers']['POISON_POWER'] == 6)
check('KFR饮药未扣本体', frames[289537]['enemies'][0]['current_hp'] == frames[289536]['enemies'][0]['current_hp'] == 159)
check('KFR末结算85敌残74', frames[289538]['enemies'][0]['current_hp'] == 74 and 159 - 74 == 43 + 42)
check('KFR实际零血', frames[289538]['hp'] == 0)
check('GX同盘2HP', frames[290160]['hp'] == frames[290201]['hp'] == 2)
check('GX同手牌', frames[290160]['hand'] == frames[290201]['hand'])
check('GX同敌HP', [e['current_hp'] for e in frames[290160]['enemies']] == [e['current_hp'] for e in frames[290201]['enemies']] == [84, 84, 77])
check('GX复活后3与13', frames[290165]['hp'] == 3 and frames[290206]['hp'] == 13)
check('GX复活后0与7挡', frames[290165]['block'] == 0 and frames[290206]['block'] == 7)
check('GX替线敌多8血', sum(e['current_hp'] for e in frames[290206]['enemies']) - sum(e['current_hp'] for e in frames[290165]['enemies']) == 8)
check('GX精灵原槽自动', frames[290201]['potions'][1]['potion_id'] == 'FAIRY_IN_A_BOTTLE' and frames[290201]['potions'][1]['usage'] == 'Automatic')
check('GX下一轮精灵空槽', frames[290206]['potions'][1]['occupied'] is False)
check('GX末轮23挡13HP', frames[290213]['hp'] == 13 and frames[290213]['block'] == 23)
check('GX实际末零血', frames[290214]['hp'] == 0)

sl = [json.loads(line) for line in (HERE / 'evidence/sl-attempts.evidence.jsonl').open()]
gx_sl = [item for item in sl if item['run_id'] == 'GXNKW8X1XYJP' and item['row']['floor'] == 45]
check('GX四次抑制假插牌记录', len(gx_sl) == 4 and all(set(item['row']['draws']['inserted'][0]['cards']) == {'BLADE_DANCE', 'OUTBREAK', 'SUCKER_PUNCH', 'ACCELERANT'} for item in gx_sl))
check('GX旧前缀19/18/19/18', [item['row']['draws']['clean'] for item in gx_sl] == [19, 18, 19, 18])

summary = []
for run in ('7X0W3U8TVA2A', 'MTQ0EUBJ3R6T', 'KFRDELW2TH2P', 'GXNKW8X1XYJP'):
    input_path, output_path = HERE / (run + '.selection-input.json'), HERE / (run + '.selection-output.json')
    data = json.loads(output_path.read_text())
    check(run + '完整候选不冒认证', all(s['actual_full_candidate_result'] is None for s in data['segments']))
    check(run + '固定局身份', data['run_id'] == run and data['ascension'] == 10)
    summary.append({'run_id': run, 'segments': len(data['segments']), 'actions': len(data['observed_actions']),
                    'turn_windows': len(data['observed_turns']), 'window_status': dict(collections.Counter(w['status'] for w in data['observed_turns'])),
                    'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
                    'output_sha256': hashlib.sha256(output_path.read_bytes()).hexdigest()})
    if run == 'MTQ0EUBJ3R6T':
        windows = [w for w in data['observed_turns'] if w['floor'] == 23 and w['turn'] == 3]
        check('MT四次T3端点', len(windows) == 4 and all(w['status'] == 'observed_turn_endpoints' for w in windows))
        check('MT前三零损末次损8', [w['facts']['player_hp_delta'] for w in windows] == [0, 0, 0, -8])

check('候选段总188', sum(s['segments'] for s in summary) == 188)
check('动作总558', sum(s['actions'] for s in summary) == 558)
check('轮窗总105', sum(s['turn_windows'] for s in summary) == 105)
check('端点32/未知73', sum(s['window_status'].get('observed_turn_endpoints', 0) for s in summary) == 32 and sum(s['window_status'].get('unknown', 0) for s in summary) == 73)
result = {'scope': '固定材料算术与既有离线消费者，非生产tsc/vitest或新策略验证',
          'assertions': len(checks), 'checks': checks, 'consumers': summary}
(HERE / 'material-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

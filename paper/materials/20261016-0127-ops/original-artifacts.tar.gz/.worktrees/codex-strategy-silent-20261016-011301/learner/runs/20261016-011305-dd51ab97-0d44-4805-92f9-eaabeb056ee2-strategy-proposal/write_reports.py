import datetime
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch.json').read_text())
history = json.loads((HERE / 'assigned-proposals-history.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
verified = json.loads((HERE / 'evidence-verification.json').read_text())
materials = json.loads((HERE / 'material-checks.json').read_text())
details = [
    ('763a4b9d9f17b815',
     '7X0W3U8TVA2A/F31T1、T2、T5、T6、T11、T13；MTQ0EUBJ3R6T/F23T3（states 288806→288812、288899→288905；decisions 282434）。',
     '十四项属性、持牌伤、已建能力及药效时点，缺逐项固定校准到联合消费者的完整覆盖；本批局部敏捷/毒/持牌观测不能补齐所有条件。',
     'card-model、combat-plan已有机制入口；selection_audit区分模型预测和实际结果。',
     '先保留逐牌格挡、旧挡不追补、临时层撤回及持牌伤先后等原限定事实；只在核全对应条件后接入联合模型。',
     'MT前三次T3不损血、末次损8，不能把这组相关SL当四个独立样本，或由少防御推全部十四项均缺模型。',
     '冻结每项实际前后帧和当时知识输入，逐项核对HP/挡/临时层及多轮次序，再对联合条件和其他角色等价性验证。'),
    ('19a5cff2094e2d8f',
     '7X0W3U8TVA2A/F31T1—T13（本批71动作）；MTQ0EUBJ3R6T/F17T4—T8、F23四试T3—T5。',
     '持续敌段生命周期到实际终局的联合校准及冻结输入下同盘整战比较缺失；不能由死亡率饱和或可见活段HP决定新终局/SL权重。',
     '既有SL资源差额及离线敌HP审计保留预测、活体、增加HP和未知；未认证整战收益。',
     '分别呈现敌段再现、已发生伤害、未结毒及当轮严格生存边界，缺失生命周期保持未知。',
     'MT末次T3多伤同时多损；7X0暂死段不等整战终结。局部更低敌HP不证明更安全，也不证明禁止探索有利。',
     '同局完整生命周期、相同冻结知识/抽序输入的成对整战和时间后移独立局；缺帧不补内部瞬间。'),
    ('3540bf4360bf80af',
     'MTQ0EUBJ3R6T/F19、F20赢战到F23；7X0W3U8TVA2A/F30胜后67HP进F31，及两局休息/跨幕边界。',
     '已有赢战与HP增加边界记录，仍缺逐源恢复、药槽事件到完整路线/休息题面的固定消费者读回；不能把净变化当完整来源链。',
     '5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452记录HP增加观测，显式标仅帧间净变化；run-journal旧药物计数不能证明逐槽来源。',
     '补充有原帧支持的入房/可操作HP、已到恢复和逐槽事件；保留净变化未知来源，不改变安全节点阈值。',
     '高血进场仍失败；计划中未抵达的营火不是已拥有回血，没有替路线或锻造整战对照。',
     '将固定资源链送入真实路线/休息事实消费者，逐字段读回；对比已到节点与预测节点，SL恢复不得算路线回血。'),
    ('0ea5c0b9c030fdd6',
     'KFRDELW2TH2P/F33六试T7，末次states289533—289538；F28T2；decisions282578→282579显示F12T1生成小刀后重问。',
     '奇巧名额事实和限定恶魔毒药6层入口已在live；尚缺完整合法后继、目标收益兑现及替顺序整战数据，原完整提案不能整体标duplicate。',
     'c4a4f4a94b48dff9b30aaa7228624c1092150145：handTrickSlothFacts的continuation_verified=false；observedDemonPoison只匹配已观察遗物/能力组合。',
     '继续展示剩余名额/能量和目标还需后续牌；只有完整可执行序列有证据时才给兑现收益，不固定奇巧对象或喝药时点。',
     '末次奇巧爆发仍余1能量却被三牌限额锁住；手上技法7挡已实得。末饮毒实结85但敌残74且玩家归零，未形成另一顺序胜线。',
     '按原冻结选择帧重放目标到合法后继及实际结果，并以新独立可比局验证；未知自动动作和新修饰条件继续未知。'),
    ('f915ec544ab94b6e',
     'KFRDELW2TH2P/F33首/第三试T6：states289339→289345、289414→289420，decisions282929；F12T1 decisions282578→282579。',
     '局部多扣10、多损6已核；已有原答/护栏/SL/单动作审计，缺完整候选归属和同输入整战校准，不据此调整SL权重。',
     '66283dd9982bdd7f480da7a4d9bfefea0572a9ac与fdaf787a372880b0438e73bcac7e6d2168b038ed区分预测候选、SL资源差和单动作回执。',
     '保留原答→护栏→SL→重问→动作链，完整候选被重问后不得把候选收益归给实线。',
     '两条T6实线后续均未赢；F12护栏完整0损候选中途改变，实损6不能直接视为候选模型误差。',
     '逐步身份/指纹与后帧匹配，再用完整受控后继比较；当前离线窗口unknown和候选结果null不由人工补真。'),
    ('8fb51933639faf90',
     'KFRDELW2TH2P/F28T2、F33T2/T4/T5/T6/T7；末次饮毒states289536→289538。',
     '限定恶魔毒药6层入口已有；力量/敏捷/触媒/覆甲/肉的联合多轮校准及覆甲完整减层条件未隔离，不能把七项整体判为已实现。',
     'c4a4f4a94b48dff9b30aaa7228624c1092150145的窄药效入口及现有potion/card模型。',
     '药效先建层后由后继动作兑现，按当时覆甲实层，额外能量不直接折作防御；条件外保持原行为。',
     '7覆甲不等每轮固定7挡；37→43是施毒，159本体不变；43+42结算与末死分开，无早喝胜局。',
     '各药/能力逐帧校准后核联合多轮输出；把施毒加量、阻挡和未观察修饰条件分开，不据相关SL拟合持药价。'),
    ('b3bc0eb09211af6c',
     'KFRDELW2TH2P/F33六试T7、首/第三试T6、T4回复和末T7；相关原帧289339/289345/289414/289420/289533—289538。',
     '剩余名额及资源差额子项已有；缺合法后继到实际终结全链，换目标/顺序和提前饮毒的完整比较，不能完成SL及终局联合提案。',
     '已有奇巧事实、SL比较、选择/派发及离线轮窗工具；完整候选的实际结果仍为null。',
     '把当前实伤、未结毒、可执行后继和当前终结分账；完整收益依赖的未施放能力不得提前算入。',
     '末次敌74非击杀，玩家22完整需损与实扣归零前9HP不同；没有把爆发提前或换奇巧对象的已胜反事实。',
     '受控完整后继/整战重放及时间后移独立局；不由饱和死亡率、更少敌余血或历史平均出牌数拟新阈值。'),
    ('fdc3a505fe5e1a55',
     'KFRDELW2TH2P/F28—F33：赢战、F32已到休息、F33入房与可操作资源；六次SL为同局相关尝试。',
     '缺逐源事实到完整路线和休息消费者的固定对照，以及替路线/锻造完整结果；已到恢复边界不等于完整资源消费者完成。',
     '5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452仅补HP增加观测；resource_chain提供观测净变化且不认证恢复原因。',
     '区分赢战消耗、休息、跨幕、开场回血及SL恢复/药槽恢复，保留现有安全节点与锻造规则。',
     '六次回血仍失败不证明应少回血；未获得的计划卡、投影入场HP不是实有资源。',
     '固定路线/休息题面读回事实，再对有控制条件的替路线和锻造整战做验证；不混进阶拟合。'),
    ('5a95725089f53cd8',
     'GXNKW8X1XYJP/F45第二/末试T2→T3：states290160→290165、290201→290206，decisions283641/283680/283690/283691；末290212—290214。',
     '逐槽观测和选线差额已有；缺完整复活逐击过程、实际未截断入伤及全候选到资源消费归属，不能把单动作或轮端点当全链完成。',
     '已有选择/派发/SL差额和离线potion_slot_changes、逐状态HP路径；来源及完整候选结果明确未知。',
     '原答、SL替线、重问和实际请求分账；精灵Automatic空槽、主动毒药、SL恢复单列，缺完整复活窗口继续标未知。',
     '两线同起2HP/同五牌；后到3/13HP、0/7挡，替线敌多8HP；末线仍实死，局部保10HP不证明整战胜率改善。中间有0HP帧，不能误写完全无复活观测。',
     '核逐源入伤、复活前后完整状态/药槽与候选前缀；逐击缺帧不可用零血截断净变化补齐，不改SL和必死规则。'),
    ('51fa8bc34774f72d',
     'GXNKW8X1XYJP/F45四次T2→T3：sl-attempts1053—1056，states290160→290165、290201→290206；ZE8F192FKX24/A5/F42T3/T4 states223268/223272。',
     '四次假inserted及旧升级键差分路径已定位；缺纯改标瞬时帧、物理副本唯一身份及并发抽牌/插入/洗牌的顺序证明，不能安全延长SL前缀。',
     'draws.ts仍用含升级键作差；没有把此缺陷冒称已有live修复。旧clean为19/18/19/18。',
     '只在已核且无歧义的改标条件下修身份；多个同ID副本、同帧抽取/插入/恢复保持断序，场外牌组与现场版本分账。',
     '主快照跨T2→T3且同时抽牌，不能凭基础ID守恒认抽序未变；A5已会读普通牌文本不证明抽序器正确。',
     '需冻结纯改标正例和多副本、真插牌、洗牌、恢复/并发抽牌负例，再做撤源码红/恢复绿；本批不伪造瞬时正例。'),
]
by_suffix = {i.removeprefix('silent-proposal-'): i for i in dispatch['proposal_ids']}
entries = []
for suffix, evidence, reason, existing, behavior, counter, validation in details:
    identity = by_suffix[suffix]
    original = history[identity][0]['row']
    entries.append({'id': identity, 'state': 'waiting', 'reason': reason, 'evidence': evidence,
                    'ledger': original['ledger'], 'original_sha256': original['proposal_sha256'],
                    'existing': existing, 'next_behavior': behavior, 'counterexamples': counter,
                    'validation': validation})
assert {e['id'] for e in entries} == set(dispatch['proposal_ids'])
(HERE / 'dispositions.json').write_text(json.dumps(entries, ensure_ascii=False, indent=2) + '\n')

proposal = ['# 本批十项原提案复核与后续实现条件', '',
            '来源/实现任务：strategy-proposal；batch=20261016-011301-strategy-proposal；角色silent。',
            '只处置本批原CLI id，不新建重复提案，不改原提案。原文副本逐一核SHA并保存在本目录的 *.original.md。',
            'Roy-2026-10-07-learning授权保持；授权不补充游戏事实。本批均waiting，没有新增策略或架构调整。', '',
            '共同方法：四局A10按原局/SL尝试分层，A5只用于已观察抑制文本；不用相关SL当独立局。固定原帧用于诊断，后续独立可比完局才可作时间后移留出。本批不重算原全史分母，不拟合HP、药价、SL或终局阈值。', '']
for e in entries:
    proposal.extend([f"## {e['id']}", '', f"账本：{','.join(e['ledger'])}。原文SHA256：{e['original_sha256']}。",
                     f"证据局/层/回合：{e['evidence']}", '', f"旧规则/现有实现：{e['existing']}",
                     f"拟议后续行为：{e['next_behavior']}", f"支持与反例/限制：{e['counterexamples']}",
                     f"验证方法：{e['validation']}", f"本批处置：waiting。{e['reason']}",
                     '预期影响：仅在完成上述验证后才可能减少模型未知或补齐资源追溯，整战收益未知；本批没有新行为影响。',
                     '回退：本批没有源码提交可回退；后续实现应以独立提交撤销对应新增条件/记录，保留本批证据和历史。', ''])
(HERE / 'proposal.md').write_text('\n'.join(proposal) + '\n')

stamp = datetime.datetime.now().astimezone().isoformat()
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-011301-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'],
          'implementation_domains': [], 'proposal_results': [{k: e[k] for k in ('id', 'state', 'reason')} for e in entries],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

report = ['# 静默猎手策略提案批次回报', '', f'记录时间：{stamp}（落盘前已运行date）。', '',
          '10项原提案逐项复核后均为waiting：现有窄实现不能关闭联合模型、完整候选/逐源资源或抽序身份要求；剩余条件缺可核证据。没有新游戏结论、经验库修改、生产源码、提交、合入、版本或shipped。', '',
          '## 身份与基线', '',
          f"开工git status为空；HEAD及main合并后base={source['base']}，git merge --no-edit main返回Already up to date。派发task/character/worktree和五局集合匹配，reason=proposal，恰有10个proposal_ids；没有research_request、implementation_request或proposal_repair。",
          '按普通批次只读根notes/strategy-research-silent.json；其batch为20261010-150327-strategy-proposal，与本批不匹配，因此未承接专题、未读取其work_spec/manifest，也未读取另一专题替代身份。未改learn.json、请求、原队列正文或ops prompt。',
          '独立完成，未派下级agent。任务文字要求普通/high；本会话未调整模型、推理、账号或权限，也未读取原生会话元数据，因此不宣称已独立核实原生模型/强度。', '',
          '## 证据冻结及范围', '',
          '使用共用extract_evidence.py入口，五局、八流；run-plans按run，其余按run_id/state.run_id/fingerprint.run，冲突身份拒收，未把正文提及当所属局。evidence/evidence-manifest.json保留每流source_size/计数/输出SHA；逐行source、offset、bytes、SHA在*.evidence.jsonl。二次只读seek核原字节、JSON与显式身份，全6060行通过；不是全6060行游戏语义逐一分析。', '',
          '| 流 | 行数 | 冻结源字节数 |', '|---|---:|---:|']
for row in verified:
    report.append(f"| {row['stream']} | {row['verified_rows']} | {row['source_size']} |")
report.extend(['', 'fight-plans在该截点选中0行，仅说明本次截点未选到；不据此断言日志不存在。未复写旧截点、旧报告或零行初稿。', '',
               '| 局号 | 进阶 | 结局 | 本批用途 |', '|---|---:|---|---|',
               '| 7X0W3U8TVA2A | A10 | F31败 | 持续敌血池、能力时点、赢战资源；离线仅F31 |',
               '| MTQ0EUBJ3R6T | A10 | F23败 | 敏捷/持牌及SL局部血价；离线F11/F23 |',
               '| KFRDELW2TH2P | A10 | F33败 | 奇巧/限额、毒药、能力与资源；离线F12/F28/F33 |',
               '| GXNKW8X1XYJP | A10 | F45败 | 复活资源、原答/替线、抑制改标；离线F45 |',
               '| ZE8F192FKX24 | A5 | F48胜 | 原提案绑定的F42抑制现场文本；不混A10统计 |', '',
               'runs原始的deepseek_calls字段保留，但不据旧计数字段判实际脑引擎；本批没有全局脑资格或成本结论。原运行code均带dirty，当前源码叶对照不能重建历史dirty树/当时知识字节。', '',
               '## 本批直接核实的限定事实', '',
               '1. KFR/F33首、第三试T6同为15HP、敌228HP、36毒、3覆甲。states289339→289345与289414→289420，敌净扣83/93、玩家后到9/3：替线多扣10、多损6。两条后续均未形成胜线，不拟合全局SL血价。',
               '2. KFR末T7 states289533—289538：手上技法已给7挡，后到12挡、三牌、余1能量，奇巧爆发被SLOTH_POWER锁住。毒药37→43、本体仍159；末结43+42=85后敌74、玩家0。选择目标/施毒均不等于后继收益/已终结；没有另顺序胜局。',
               '3. MT/F23T3前三次端点288806→288812、288837→288843、288868→288874均10→10；末次288899→288905为10→2。d282434保留SL原13伤/0损、替19伤/8损及两线24/24死亡的原预测。实际含抽牌重问，四次相关尝试不能作独立训练/留出。',
               '4. GX/F45第二/末次T2同五牌、2HP、敌84/84/77；states290160→290165与290201→290206后到3/13HP、0/7挡、敌总218/226。精灵槽1原usage=Automatic、后空；末T3毒药槽0请求d283690与后空槽独立记录。原状态路径含0HP→3/13HP，但没有完整逐击复活过程或未截断入伤。末d283691仍least-loss -2，s290214实零；不能把局部多保10HP当整场胜率改善。',
               '5. GX四次sl-attempts1053—1056均把四张改标牌记成普通inserted，旧clean=19/18/19/18；主快照跨T2→T3并伴随抽牌，旧源码含升级键作差路径仍在。ZE/A5 F42T3/T4有现场普通版本和DAMPEN。只能确认记录问题与文本观察，尚不能证明改标期间抽序保持/唯一副本身份。', '',
               '这些事实是原证据的本批复核，不新造历史复盘或已有经验的重复support/repeat。更完整逐项提案见proposal.md与dispositions.json。', '',
               '## 既有实现及消费者读回', '',
               f"只读live指针快照：{source['live_observed']}。source-audit.json保存13叶SHA：10相同，card-model.ts、run-journal.ts、draws.ts仅已有Roy/Dai历史注释差，原差异保留；未改任何源码或将差异静默抹平。",
               '四个窄实现来源66283dd9982bdd7f480da7a4d9bfefea0572a9ac、c4a4f4a94b48dff9b30aaa7228624c1092150145、5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452、fdaf787a372880b0438e73bcac7e6d2168b038ed均为base和该live的真实祖先。这些是既有子项来源，非本批实现/合入，也不据此把整项标implemented/duplicate。',
               '复用既有resource_chain对本角色五局分局保存观测；A5与A10不合统计。audit-selection.ts只读四局A10指定层，完整冻结输入/输出及SHA保存在本目录，未连接游戏、LLM或网络。无decision_id的元数据行单列排除在consumer-input-summary.json，没有重新编号原行。', '',
               '| 局号 | 候选段 | 动作 | 轮窗 | 有端点/未知 |', '|---|---:|---:|---:|---:|'])
for row in materials['consumers']:
    status = row['window_status']
    report.append(f"| {row['run_id']} | {row['segments']} | {row['actions']} | {row['turn_windows']} | {status.get('observed_turn_endpoints', 0)}/{status.get('unknown', 0)} |")
report.extend(['',
               '合计188候选段、558动作、105轮窗（32有端点、73未知）；188段的actual_full_candidate_result均null，这是工具的认证边界，不是证明实盘没有执行过任何完整候选。KFR六次T6整轮窗口均因turn_opening_unverified留unknown，原帧局部配对单列，不手动升级为工具已认证整轮。已有派发日志也只证明单动作回执，不闭合完整候选。',
               '39项固定材料算术/字段断言通过，清单和输入输出SHA见material-checks.json。它们是材料校核及既有离线消费者读回，不是生产测试、自然消费者、策略收益或新实现验收。', '',
               '## 十项处置', '', '| 原提案 | 状态 | 具体未实现原因 |', '|---|---|---|'])
for e in entries:
    report.append(f"| {e['id']} | waiting | {e['reason']} |")
report.extend(['', '每项证据层/回合、账本、现有行为、待实现行为、反例、验证与回退条件已完整列在proposal.md；同一原id继续等新局/完整数据重派，不扩到其他队列。', '',
               '## 验证、记录与交接', '',
               '生产源码与知识零修改，因此撤源码失败/恢复通过不适用；未运行生产tsc/vitest，tests固定null/null/null。不伪报测试成功或撤源码红绿。没有源码提交、Co-Authored-By、gitleaks提交扫描、live合入或eval新版本；无新上线规则，未触发双通知。merge=live只对有源码实现的流程适用，本批未空合。',
               '账本仅经根learner/ledger.py update追加本批proposal/report链接及说明；不改旧claim、first_run、prior、evidence、状态或版本，不把既有shipped降回proposed，不新增游戏条目；本批提案仍为proposed工作阶段，非实现/上线。最终追加读回见ledger-update-verification.json。队列等待状态由调度器消费本报告逐项proposal_results登记，本批不手改队列。',
               '工具准备中的一次bubblewrap/glob启动失败（并行工作树.codex路径消失）后只重试原只读命令成功；另有缺源码文件名/日志目录通配路径探针、汇总误用status键及工具输出截断，均未改生产代码或权限。失败/更正保留会话，未冒作产品故障或套件失败。复活材料明确保留实际0HP帧，不将缺完整过程误写成完全缺帧。',
               '阅读共用源码draws.ts开头及diff时工具输出包含既有非本角色历史注释；未读取其他角色知识目录或对局原件，未把这些注释用于本角色机制/策略/样本结论。后续仅使用本批显式身份数据。',
               '原证据、原报告、原提案和本批材料均保留。临时材料全在指定scratch，工作树不提交这些忽略材料，不删除运行中的自身工作树。最终HEAD/工作树读回见final-verification.json。', '',
               f'交运维提案：{HERE / "proposal.md"}', f'正式报告：{HERE / "report.md"}',
               '最终机器回报原件：result.json。'])
(HERE / 'report.md').write_text('\n'.join(report) + '\n')
print(json.dumps({'report': str(HERE / 'report.md'), 'proposal': str(HERE / 'proposal.md'),
                  'proposal_results': len(entries), 'ledger_ids': len(set(i for e in entries for i in e['ledger']))}, ensure_ascii=False))

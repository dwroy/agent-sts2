from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,tarfile

root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0127';pub=root/'paper/materials/20261016-0127-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-011301-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/'ops/codex-ops/learner'/(bid+'.out');output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
final=load(s/'final-verification.json');assert final['head']==final['base']==report['base'] and final['worktree_clean'] and final['tracked_diff_empty'] and final['source_and_knowledge_changes']==final['new_commits']==[] and final['merged'] is None
assert final['ledger_updates']==33 and final['proposal_results_count']==10 and final['material_assertions']==39
for path,digest in final['sha256'].items():assert sha((s/path).read_bytes())==digest,path
history=load(s/'assigned-proposals-history.json');assert set(history)==set(report['code_proposals'])
for ident,events in history.items():
    original=next(x['row'] for x in events if x['row']['op']=='add');f=Path(original['proposal']);assert f.resolve().is_relative_to(root)
    assert sha(f.read_bytes())==original['proposal_sha256']==sha((s/(ident+'.original.md')).read_bytes())
verification=load(s/'evidence-verification.json');assert sum(x['verified_rows'] for x in verification)==6060
for row in verification:assert sha((s/'evidence'/(row['stream']+'.evidence.jsonl')).read_bytes())==row['output_sha256']
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['leaves'])==13
for row in source['leaves']:
    a=git('show',report['base']+':'+row['path']);z=git('show',source['live_observed']+':'+row['path']);assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256'] and (a==z)==row['equal']
    assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
    git('merge-base','--is-ancestor',row['latest_base_commit'],report['base'])
assert sum(x['equal'] for x in source['leaves'])==10
for row in source['origins']:
    assert row['base_ancestor'] and row['live_ancestor'];git('merge-base','--is-ancestor',row['commit'],report['base']);git('merge-base','--is-ancestor',row['commit'],source['live_observed'])
material=load(s/'material-checks.json');assert material['assertions']==len(material['checks'])==39 and len(material['consumers'])==4
for row in material['consumers']:
    run=row['run_id'];assert sha((s/(run+'.selection-input.json')).read_bytes())==row['input_sha256'] and sha((s/(run+'.selection-output.json')).read_bytes())==row['output_sha256']
    result=load(s/(run+'.selection-output.json'));assert result['run_id']==run and len(result['segments'])==row['segments'] and all(x['actual_full_candidate_result'] is None for x in result['segments'])
    assert (s/(run+'.selection-stderr.log')).read_bytes()==b''
totals={key:sum(x[key] for x in material['consumers']) for key in ['segments','actions','turn_windows']};totals.update(observed=sum(x['window_status'].get('observed_turn_endpoints',0) for x in material['consumers']),unknown=sum(x['window_status'].get('unknown',0) for x in material['consumers']))
assert totals==dict(segments=188,actions=558,turn_windows=105,observed=32,unknown=73)
inputs=load(s/'ledger-update-input.json');receipt=load(s/'ledger-update-verification.json');assert receipt['appended_rows']==33 and receipt['all_receipts_match_cli_payload'] and receipt['protected_fields_unchanged'] and receipt['old_history_notes_where_preserved']
assert len(inputs)==len(receipt['rows'])==33 and set((s/'ledger-update-output.log').read_text().split())=={x['id'] for x in inputs}
ledger=root/'paper/materials/learning/ledger.jsonl';own=[]
for entry in receipt['rows']:
    with ledger.open('rb') as handle:handle.seek(entry['offset']);raw=handle.read(entry['bytes'])
    row=json.loads(raw);assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update'
    assert any(all(row.get(k)==v for k,v in x.items()) for x in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');existing=set(old.splitlines());assert len(set(own))==33 and all(raw.rstrip(b'\n') not in existing for raw in own);added=b''.join(own)
spec=importlib.util.spec_from_file_location('owned_ledger',root/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,completion=final,source=source,evidence_output_sha_verified=True,original_rows=6060,original_material_assertions=39,original_consumer_summaries=material['consumers'],consumer_totals=totals,consumer_not_reexecuted=True,owned_trace_rows=33,protected_fields_and_old_prefixes_preserved=True,limits=['Four A10 offline selection scopes remain distinct from the A5 observation. Historical dirty consumed trees and knowledge are not reconstructed.','All 188 full candidate results remain null; manual paired frames do not upgrade unknown opening/whole-turn certification. Gross incoming damage, revival sequence, full legal continuation and controlled full-fight counterfactuals remain unknown.','Observed Dampen inserted-record issue and old upgraded-key path remain scoped to the original proposal. Missing instantaneous relabel/copy/draw ordering cannot justify extending the SL prefix.','Existing Demon potion and Hand Trick facts are bounded prior implementations; no new mechanism, threshold, natural consumer or wide-parent completion is claimed.','Original sandbox startup/directory race, path/schema probes and truncated tool outputs retained; no permissions expanded or product/test failure inferred.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0127原011301策略done0/no-source处置核，2f719干净WT/HEAD不变、十waiting具体缺口/testsnull/域空/mergednull保持，无提交或合入阻塞，不空合/发号/补测。五Silent八流6060原材料行产物SHA及39限定断言/四A10离线输入输出SHA核，不重跑或冒生产测试；A5原观察单列，不混A10或重算113/115/116局全史。188段558动作105轮窗32端点73未知、全候选结果均null，KFR六T6原turn_opening_unverified保持unknown，手工多扣10/多损6不冒整轮已认证；GX实0HP帧与缺完整逐击/未截断入伤分列，旧假插牌与升级键缺口沿原51fa提案、不擅延长SL前缀。13源码叶10同3历史Roy-Dai注释差及四旧来源main/live祖先核，不当本批实现/消费者或宽父完成。33所属CLI纯where/note逐输入/输出ID/offset/bytes/SHA及私有fold核，旧claim/首证/prior/证据/状态/版本和history/notes/where保、不重复CLI或降级shipped；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network与原未独立读原生说明分列，原目录竞态/路径与schema探针失败/输出截断保，不当产品故障或扩大权限。仅本人记录/追溯提交，保并行脏记录；无新源码/知识/版本/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作。证据paper/materials/20261016-0127-ops/。\n'
note=f'\n- {at} [运维 codex] 原011301策略十项继续waiting，无源码变更/合入受阻；39项为限定材料检查及既有离线消费者读回，生产tests仍null。33所属追溯已核，完整候选/逐源资源与抽序身份等缺口保持。回执paper/materials/20261016-0127-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=33,protected_fields_preserved=True,no_new_source_tests_merge_or_release=True,wide_parents='remain open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,owned_trace_rows=33,ledger_check=0,paths=len(entries))))

from pathlib import Path
import json, subprocess, hashlib, re, tarfile
root = Path.cwd(); r = root; p = r / 'ops/codex-ops/record-staging/20261015-1851'; pub = r / 'paper/materials/20261015-1851-ops'; sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-184302-fix-batch'; b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]; report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'failed' and b['rc'] == 0 and not b['proposal_audit_errors']
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and report['code_proposals'] == []
assert report['tests'] == {'tsc': 0, 'vitest': 0, 'cases': 42}
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
audit = json.loads((s / 'audit.json').read_text()); assert len(audit['existing_fixes']) == 73 and audit['new_fixes'] == [] and audit['merge_performed'] is False
assert sha((s / 'queue-snapshot.md').read_bytes()) == audit['queue_sha256']
assert sha(Path(audit['prior_audit']).read_bytes()) == audit['prior_audit_sha256']
for row in audit['existing_fixes']:
    for target in [report['base'], audit['live_read_only_snapshot']]: git('merge-base', '--is-ancestor', row['source_commit'], target)
    assert sha(git('show', report['base'] + ':' + row['path'])) == row['current_source_sha256']
coverage = audit['verification']; assert coverage['vitest_files'] == 10 and coverage['vitest_cases'] == 42 and coverage['filtered_cases'] == 33 and coverage['full_test_sandbox_run'] is False
for label, ref in coverage['logs'].items(): assert sha(Path(ref['path']).read_bytes()) == ref['sha256']
assert (s / 'tsc.exit').read_text().strip() == '0'
assert all((s / (name + '.exit')).read_text().strip() == '0' for name in ['vitest-core','vitest-fixtures','vitest-startup'])
assert coverage['reruns'] == [] and audit['ledger_updates'] == []
stock = json.loads((s / 'stock-evidence-readback.json').read_text()); refs = []
with Path(stock['original_log']).open('rb') as log, (pub / 'stock-original-frames.jsonl').open('wb') as out:
    for row in stock['rows']:
        log.seek(row['offset']); raw = log.read(row['length']); assert sha(raw) == row['original_log_sha256']; value = json.loads(raw); state = value['state']
        assert state['run_id'] == '2LZHP9BYFTHE' and state['run']['floor'] == 37 and state['turn'] == row['turn']
        out.write(raw); refs.append({'line':row['line'],'offset':row['offset'],'length':row['length'],'sha256':sha(raw),'raw_run_floor':37,'turn':row['turn']})
receipt = {'batch': bid, 'canonical_state': b['state'], 'canonical_rc': b['rc'], 'original_report': report, 'native': native, 'original_73_ancestors_and_base_source_hashes_verified': True, 'original_source_review': audit['changed_audited_source_review'], 'original_queue_snapshot': {'lines': audit['queue_lines'], 'sha256': audit['queue_sha256']}, 'original_coverage': coverage, 'coverage_interpretation': 'tsc0 and 10 selected files/42 cases passed; 33 name-filtered cases not run, no reruns. No full-suite pass asserted.', 'stock_locator_correction': {'old_ops_text':'F38','original_raw_run_floor':37,'original_frames':refs,'scope':'Original learner proposal and three raw frames agree on F37; append-only location correction, no changed arithmetic, mechanism or gameplay conclusion.'}, 'original_probe_failure_preserved': audit['evidence_probe'], 'no_new_commit_or_merge_blocker': True, 'canonical_failed_rc0_mergednull_preserved': True, 'no_repeated_checks_or_full_or_release': True, 'wide_items_unchanged': True}
(pub / 'fix-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
manifest = []
with tarfile.open(pub / 'fix-original-artifacts.tar.gz', 'w:gz') as tar:
    for f in list(s.iterdir()) + [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]:
        if not f.is_file(): continue
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'fix-original-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'existing_fixes': 73, 'no_new_commit': True, 'canonical': 'failed/rc0/mergednull', 'selected_checks_only': 42, 'filtered': 33}))

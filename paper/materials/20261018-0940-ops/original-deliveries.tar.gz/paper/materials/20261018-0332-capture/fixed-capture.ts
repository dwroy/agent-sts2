/** Engineering fault injection only: no historical failure or game mechanic is reproduced. */
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { deserialize } from "node:v8";
import assert from "node:assert/strict";
import { board } from "../../../agent/tests/boss-sim-fixture.js";
import { simulateFight } from "../../../agent/src/reflex/rollout.js";
import { solveTurn } from "../../../agent/src/reflex/turn-solver.js";
import { continuationInput, fightSample } from "../../../agent/src/sim/boss-sim.js";
import { continuationFailureOf, preserveContinuationFailure } from "../../../agent/src/sim/continuation-failure.js";

const directory = new URL("./fixed-capture-v2/", import.meta.url).pathname;
const input = board({ bossHp: 12 });
input.captureResources = true;
input.continuation = { variants: [{ boss: "FIXED_SECOND", count: 1, input: board() }],
  potions: [], source: "engineering synthetic fixture", limitation: "Not a historical or naturally occurring failure" };
const plan = solveTurn(input.solver).plans[0]!;
const trajectory = simulateFight(input, plan, 5, 17);
const first = { ...fightSample({ ...input, continuation: undefined }, plan, 17, 5), won: true, died: false,
  resources: { hp: 0, revives: [], drunkKeys: [] },
  failureTrajectory: trajectory.records.map((row, index, rows) => index !== rows.length - 1 ? row : {
    ...row, won: true, died: false, resources: { hp: 0, revives: [], drunkKeys: [] },
  }) };
let captured;
try { continuationInput(input, first, input.continuation.variants[0]!.input,
  { seed: 17, plan, maxTurns: 5, scripts: true, order: null }); }
catch (error) { captured = continuationFailureOf(error); }
assert(captured);
assert.equal(captured.reason, "nonpositive-hp");
assert.equal(captured.capture, "complete");
const context = { run: "fixed-engineering-only", question_key: "fixed-capture-b2-b3-contract", synthetic: true };
const saved = preserveContinuationFailure(captured, context, directory);
assert.equal(saved.status, "saved");
const raw = readFileSync(String(saved.path));
const envelope = JSON.parse(raw.toString());
const bytes = Buffer.from(envelope.sample.payload, "base64");
assert.equal(createHash("sha256").update(bytes).digest("hex"), envelope.sample.sha256);
const replay = deserialize(bytes);
assert.deepEqual(replay.input, input);
assert.deepEqual(replay.sample.plan, plan);
assert.equal(replay.sample.seed, 17);
assert.equal(replay.first.resources.hp, 0);
assert(replay.first.failureTrajectory.length > 0);
assert(replay.first.failureTrajectory.every((row: Record<string, unknown>) => "resourceAudit" in row));
const again = preserveContinuationFailure(captured, context, directory);
assert.equal(again.status, "deduplicated");
assert.deepEqual(readFileSync(String(again.path)), raw);
writeFileSync(new URL("./fixed-capture-readback.json", import.meta.url), JSON.stringify({
  status: "passed", synthetic: true, reason: captured.reason,
  complete_input_and_plan: true, first_result_and_resources: true,
  trajectory_rows: replay.first.failureTrajectory.length, all_rows_have_resource_audit: true,
  payload_sha256: captured.sha256, immutable_dedup_verified: true, reference: saved,
  scope: "Actual continuationInput encoder, storage and decoder with an injected invalid winning resource. Existing fixed worker/pool/consumer tests separately verify task identities. Not the missing natural sample or root repair.",
}, null, 2) + "\n");

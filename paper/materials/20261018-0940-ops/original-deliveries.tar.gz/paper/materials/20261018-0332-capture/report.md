# 0332 失败现场记录检查

结论：截至本次冻结的 decisions.jsonl **2,478,940,657 字节、431,777 原行**，没有发现 R373 上线后再次发生该资源失败。不是从健康摘要推断：全量原字节检索 `nonpositive-hp`、`missing successful first-fight resources`、封套 schema 和两种资源失败引用，得到 301 条历史匹配，最后一条为 2026-10-16 20:25:19 CST（YZWV37N2MU6N）；R373 在当日 21:30:50 发布。逐行 offset/bytes/SHA 和原件见 raw-failure-scan.json / error-*.jsonl。

B2/B3 主循环均传入 `dirname(decisionLog)/sim-failures`；当前 live/logs 解析为仓库共享 logs。目录按首个完整失败才创建。捕获会保留原 typed error，经 worker/pool 到消费者后独立写文件；决定日志只写引用。此次没有发布后的资源错误或 storage/unconfigured/oversize 引用，故未发现记录机制 bug 或写错位置的证据，无生产源码修复交付。不能因此证明未来绝无写盘失败，原 1MiB/2MiB/每局16题限额仍存在。

固定验证：现有 B2/B3 worker、pool、planner/consumer、编码存储五文件 **14 项通过**，包括超长错误、任务身份、完整资源轨迹、不可变去重及显式写盘失败。另以固定工程故障注入在真实 continuationInput 边界制造 won=true/hp=0，实际生成独立 V8 封套并反序列化核全输入、计划、seed、首战 resources 和逐轮 resourceAudit，重复写入保持原字节。见 fixed-capture-readback.json 和 fixed-capture-v2/。这不是历史 YZW/RQ/TCD 的自然失败，也不增加学习样本。首轮工程探针在建立 continuation 前取轨迹，未启用 resourceAudit；其源码、失败日志和文件保留，修正探针配置后通过，生产记录器未改。

原0332仍缺自然发生的完整失败封套，根资源缺陷和父要求保持开放。原 ops 沿既有循环捕获即可；本次没有开局、模型、监听或重新研究游戏机制。

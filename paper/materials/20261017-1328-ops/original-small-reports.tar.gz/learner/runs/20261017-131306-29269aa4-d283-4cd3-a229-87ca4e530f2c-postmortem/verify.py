import json, hashlib, collections, datetime
from pathlib import Path
p=Path(__file__).parent
root=p.parents[2]
raw_checks={}
all_rows={}
for name in ('decisions','states','brain','run-plans','run-config','sl-attempts'):
 rows=[json.loads(l) for l in (p/f'{name}.jsonl').open()]
 with (root/'logs'/f'{name}.jsonl').open('rb') as f:
  for x in rows:
   f.seek(x['offset']);line=f.read(x['bytes'])
   assert json.loads(line)==x['row'],(name,x['line'])
 raw_checks[name]=len(rows)
 all_rows[name]=rows
D=all_rows['decisions'];S=all_rows['states'];B=all_rows['brain']
ss={x['line']:x['row']['state'] for x in S};dd={x['line']:x['row'] for x in D}
def enemy(line):return ss[line]['combat']['enemies'][0]
def hp(line):return ss[line]['run']['current_hp']
def power(obj,ident):return next((x['amount'] for x in obj['powers'] if x['power_id']==ident),0)
assert [hp(l) for l in [434283,434293,434300,434307,434311,434315]]==[60,42,23,23,8,0]
assert [ss[l]['combat']['player']['block'] for l in [434292,434299,434310,434314]]==[10,4,0,19]
assert [enemy(l)['intents'][0]['total_damage'] for l in [434292,434299,434307,434308,434311,434314]]==[28,23,33,15,44,32]
assert enemy(434315)['current_hp']==157 and enemy(434315)['max_hp']==212
assert power(enemy(434314),'POISON_POWER')==19
assert [power(enemy(l),'STRENGTH_POWER') for l in [434285,434286,434292,434294,434298,434299,434304,434307,434308,434311]]==[0,3,6,9,12,15,18,0,-6,0]
assert [hp(l) for l in [434012,434048,434093,434125,434130,434131,434135]]==[68,57,48,14,14,47,60]
assert [ss[l]['run']['max_hp'] for l in [434012,434125]]==[68,60]
assert 32-19==13 and 13+1-8==6
J=[x['row'] for x in D if x['row']['decider']=='jev']
P=[x for x in J if 'plan-choice' in x['label']]
assert len(J)==184 and sum(x['confidence']<.35 for x in J)==19
assert len(P)==148 and collections.Counter(x.get('rollout_best_chosen') for x in P)=={True:146,False:1,None:1}
assert sum((x['row'].get('chosen') or {}).get('action')=='use_potion' for x in D)==24
assert not any((x['row'].get('chosen') or {}).get('action')=='discard_potion' for x in D)
assert sum(x['row'].get('fallback',False) for x in D)==9
assert sum('HP guard:' in x['row']['rationale'] for x in D)==1
assert sum('sl_explore' in x['row'] for x in D)==16
assert {k:sum(x['row']['usage'].get(k,0) for x in B) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}=={'inputTokens':9503564,'outputTokens':63622,'cacheHitTokens':5724288,'reasoningTokens':55875}
assert sum(x['usage']['input_tokens'] for x in J)==1630421
assert sum(x['usage']['output_tokens'] for x in J)==11351
sl=[x['row'] for x in all_rows['sl-attempts'] if x['row']['floor']==48]
assert [(x['attempt'],x['turns'],x['end_hp'],x['incoming']) for x in sl]==[(1,5,13,44),(2,5,7,32),(3,5,13,44),(4,3,22,51),(5,5,7,32),(6,5,0,32)]
assert len([x for x in sl if (x.get('reload')or{}).get('ok')])==5
assert all(x['row']['engine']=='codex' and x['row']['model']=='gpt-6.1-sol' and x['row']['effort']=='xhigh' for x in B)
lesson=(p/'lesson-draft.md').read_text()
assert lesson.count('\n## 5H83F3J0XSTE')==1
assert len([l for l in lesson.splitlines() if l.startswith('- [') and not l.startswith('- [记录]')])==3
assert '机制：' in lesson and all(i in lesson for i in ['silent-0028','silent-0046','silent-0020'])
result={'raw_offset_readback':raw_checks,'key_assertions':'passed','lesson_bytes':len(lesson.encode()),'lesson_sha256':hashlib.sha256(lesson.encode()).hexdigest()}
(p/'verification-before.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

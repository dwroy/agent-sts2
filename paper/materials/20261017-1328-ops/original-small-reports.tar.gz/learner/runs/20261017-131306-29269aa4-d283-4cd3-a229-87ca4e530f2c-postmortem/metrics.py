import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]
S=[json.loads(l) for l in (p/'states.jsonl').open()]
B=[json.loads(l) for l in (p/'brain.jsonl').open()]
R=json.loads((p/'5H83F3J0XSTE-resources.json').read_text())
def criteria(r):
 out={}
 for k,v in ((r.get('questions') or {}).get('plan') or {}).get('criteria',{}).items():
  if isinstance(v,str):
   try:out[k]=json.loads(v)
   except ValueError:out[k]=v
  else:out[k]=v
 return out
with (p/'metrics.txt').open('w') as w:
 def pr(*a):print(*a,file=w)
 j=[x for x in D if x['row']['decider']=='jev'];pq=[x for x in j if 'plan-choice' in x['row']['label']]
 pr('JEV',len(j),'low',sum((x['row'].get('confidence') or 0)<.35 for x in j),'plan',len(pq))
 for x in pq[:1]:pr('candidate keys',[(k,list(v) if isinstance(v,dict) else type(v).__name__) for k,v in criteria(x['row']).items()])
 best=collections.Counter();rank=collections.Counter();focus=[];guards=[]
 for x in pq:
  r=x['row'];cs=criteria(r);m=re.search(r'Jev chose plan (\d+)',r['rationale']);key='plan'+m.group(1) if m else None
  ch=cs.get(key,{})
  best[str(ch.get('rollout_best_chosen','MISSING'))]+=1
  if isinstance(ch,dict):
   for k in ch:
    if 'best' in k:pass
  rk=re.search(r'code rank ([\d-]+)',r['rationale']);rank[rk.group(1) if rk else 'unknown']+=1
  f={k:v.get('focus') for k,v in cs.items() if isinstance(v,dict) and v.get('focus')}
  if f:focus.append((x['line'],r['floor'],r['turn'],key,f))
  if 'HP guard:' in r['rationale']:
   pr('GUARD',x['line'],r['rationale'])
   for k,v in cs.items():pr(k,{z:v.get(z) for z in ('plays','hp_lost','dmg','hp_after','focus','rollout_best_chosen','rollout_deaths')})
 pr('best_counts',dict(best),'rank_counts',dict(rank),'focus',focus)
 pr('fallback',[(x['line'],x['row']['floor'],x['row']['turn'],x['row']['label'],x['row']['rationale'],x['row'].get('time_budget')) for x in D if x['row'].get('fallback')])
 pr('pots')
 for x in D:
  r=x['row'];a=r.get('chosen') or {}
  if a.get('action') in ('use_potion','discard_potion','buy_potion') or 'Potion' in r.get('rationale','') and r['label']=='reward/claim':pr(x['line'],r['ts'],r['floor'],r['turn'],r.get('sl_attempt'),a,r['rationale'],r.get('result'))
 pr('resource_changes')
 for c in R['resource_changes']:
  a,z=c['from'],c['to']
  if a['potions']!=z['potions'] or c['combat_sequence'] is None:pr('change',a['line'],z['line'],z['ts'],'F',z['floor'],'T',z['turn'],'HP',a['hp'],z['hp'],'max',a['max_hp'],z['max_hp'],'pot',a['potions'],z['potions'],'seq',c['combat_sequence'],'restart',c['restart_boundary'])
 pr('F48 decisions')
 for x in D:
  r=x['row']
  if r['floor']==48:
   pr(x['line'],r['ts'],'T',r['turn'],'A',r.get('sl_attempt'),r['decider'],r['label'],r['rationale'])
   if r.get('sl_attempt')==6 and 'plan-choice' in r['label']:
    for k,v in criteria(r).items():pr('candidate',k,{z:v.get(z) for z in ('plays','hp_lost','dmg','hp_after','rollout_best_chosen','focus','boss_sim','rollout')})
 pr('tokens_jev', {k:sum((x['row'].get('usage') or {}).get(k,0) or 0 for x in j) for k in ('input_tokens','output_tokens','cache_hit_tokens')})
 pr('tokens_brain',{k:sum((x['row'].get('usage') or {}).get(k,0) or 0 for x in B) for k in ('input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens')})
 pr('brain_usage_examples',B[0]['row']['usage'],B[-1]['row']['usage'])
 pr('brain_engine',collections.Counter((x['row']['engine'],x['row']['model'],x['row']['effort']) for x in B),'latency_ms',sum(x['row']['latency_ms'] for x in B))
 pr('firstlast',D[0]['row']['ts'],D[-1]['row']['ts'])
 pr('rounds')
 rounds=collections.defaultdict(list)
 for x in D:
  r=x['row']
  if r.get('turn') is None or not (r.get('screen') in ('COMBAT','CARD_SELECTION') or r['label'].startswith('combat/')):continue
  a=r.get('sl_attempt') or 1
  rounds[(r['floor'],a,r['turn'])].append(r)
 def who(r):
  if r['decider']=='code' and r['rationale'].startswith('continuing the Jev-chosen plan:'):return 'jev-plan'
  return r['decider']
 pr('all_rounds',len(rounds),'anycode',sum(any(who(r)=='code' for r in v) for v in rounds.values()),'nojev',sum(not any(who(r) in ('jev','jev-plan') for r in v) for v in rounds.values()),'codeactions',sum(who(x['row'])=='code' and x['row']['label'].startswith('combat/') for x in D),'deciders_adjusted',collections.Counter(who(x['row']) for x in D))

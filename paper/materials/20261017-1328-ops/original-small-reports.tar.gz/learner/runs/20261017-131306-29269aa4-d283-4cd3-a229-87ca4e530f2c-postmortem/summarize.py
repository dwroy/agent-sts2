import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]
S=[json.loads(l) for l in (p/'states.jsonl').open()]
R=json.loads((p/'5H83F3J0XSTE-resources.json').read_text())
def powers(o):return [(x['power_id'],x.get('amount')) for x in o.get('powers',[])]
with (p/'audit.txt').open('w') as w:
 def pr(*a):print(*a,file=w)
 pr('COUNTS',len(D),len(S),collections.Counter(x['row']['decider'] for x in D))
 for x in D:
  r=x['row']
  if r['floor']>=44 or r['decider']=='codex' or r['fallback'] or 'HP guard:' in r['rationale']:
   pr('D',x['line'],r['ts'],'F',r['floor'],'T',r['turn'],'A',r.get('sl_attempt'),r['decider'],r['label'],'action',r['chosen'],'conf',r['confidence'],'fallback',r['fallback'],'reason',r['rationale'],'journal',r.get('journal'))
 for c in R['combats']:
  e,z=c['entry'],c['exit'] or c['last']
  pr('COMBAT',c['sequence'],c['floor'],c['enemies'],e,z,c['end'])
  by=collections.defaultdict(list)
  for x in S:
   if e['line']<=x['line']<=z['line'] and x['row']['state'].get('combat'):
    by[x['row']['state']['turn']].append(x)
  for t,arr in by.items():
   a=arr[0];b=arr[-1]
   def snap(x):
    s=x['row']['state'];v=s['combat'];return {'s':x['line'],'ts':x['row']['ts'],'hp':s['run']['current_hp'],'max':s['run']['max_hp'],'block':v['player']['block'],'energy':v['player']['energy'],'powers':powers(v['player']),'enemy':[(e['index'],e['enemy_id'],e['current_hp'],e['max_hp'],e.get('block'),powers(e),e.get('move_id'),e['intents']) for e in v['enemies']],'hand':[(h['card_id'],h.get('is_playable'),h.get('current_cost'),h.get('upgrade_level')) for h in v.get('hand',[])]}
   pr('TURN',t,'start',snap(a),'end',snap(b))
   if c['floor']==48:
    for x in arr:
     pr('FRAME',snap(x))
 pr('CHANGES')
 for x in R['resource_changes']:pr(x)
with (p/'brain-summary.txt').open('w') as w:
 for l in (p/'brain.jsonl').open():
  x=json.loads(l);r=x['row']
  print('B',x['line'],r['ts'],r['label'],r['engine'],r['model'],r['effort'],'ANSWER',r['answer'],file=w)
  for q in ('question','options'):
   v=r.get(q)
   if r['label'].startswith(('rest/','map/','run-plan')) or 'plan' in r['label']:print(q,v,file=w)

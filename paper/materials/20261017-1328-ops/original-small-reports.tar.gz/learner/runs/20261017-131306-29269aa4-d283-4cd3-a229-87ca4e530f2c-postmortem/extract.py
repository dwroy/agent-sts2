import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261017-131306-29269aa4-d283-4cd3-a229-87ca4e530f2c-postmortem'
run=b'5H83F3J0XSTE'
for name in ('decisions','states','run-plans','brain','sl-attempts','run-config'):
    path=root/'logs'/f'{name}.jsonl'
    cutoff=path.stat().st_size
    n=0; off=0
    with path.open('rb') as f, (out/f'{name}.jsonl').open('w') as w:
        for ln,line in enumerate(f,1):
            pos=off; off+=len(line)
            if off>cutoff: break
            if run not in line: continue
            try: row=json.loads(line)
            except ValueError: continue
            ident=row.get('run_id', row.get('run', (row.get('state') or {}).get('run_id')))
            if ident!=run.decode(): continue
            w.write(json.dumps({'line':ln,'offset':pos,'bytes':len(line),'row':row},ensure_ascii=False)+'\n');n+=1
    print(name,n,flush=True)
dec=[json.loads(l)['row'] for l in (out/'decisions.jsonl').open()]
lo=min(x['ts'] for x in dec);hi=max(x['ts'] for x in dec)
n=0;off=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as w:
    for ln,line in enumerate(f,1):
        pos=off;off+=len(line)
        try: row=json.loads(line)
        except ValueError: continue
        if lo<=row.get('ts','')<=hi:
            w.write(json.dumps({'line':ln,'offset':pos,'bytes':len(line),'row':row},ensure_ascii=False)+'\n');n+=1
print('window',lo,hi,'deepseek',n,flush=True)

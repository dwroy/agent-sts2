from pathlib import Path
import json, hashlib, subprocess, csv, re, importlib.util, os, tarfile
r = Path.cwd(); p = r / 'ops/codex-ops/record-staging/20261015-1802'; pub = r / 'paper/materials/20261015-1802-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a): return subprocess.check_output(['git', *a], stderr=subprocess.PIPE)
assert not (p / 'record-manifest.json').exists()
result = json.loads((pub / 'paper-dataset-result.json').read_text()); assert result['actual_exit_code'] == 0 and result['calls'] == 1
log = (pub / 'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before = {x['path']: x for x in json.loads((p / 'paper-before.json').read_text())}
store = p / 'paper-owned'; store.mkdir(exist_ok=True); outputs = []
for f in sorted((r / 'paper/data').iterdir()) + [r / 'paper/materials/silent/cost.md']:
    if not f.is_file(): continue
    raw = f.read_bytes(); path = str(f.relative_to(r)); h = sha(raw)
    if path in before and h == before[path]['sha256']: continue
    name = path.replace('/', '--'); (store / name).write_bytes(raw); outputs.append({'path': path, 'bytes': len(raw), 'sha256': h, 'snapshot': name})
(p / 'paper-owned-manifest.json').write_text(json.dumps(outputs, ensure_ascii=False, indent=2) + '\n')
by = {x['path']: x for x in outputs}
def frozen(path):
    if path in by:
        raw = (store / by[path]['snapshot']).read_bytes(); assert sha(raw) == by[path]['sha256']; return raw
    return (r / path).read_bytes()
summary = json.loads(frozen('paper/data/summary.json')); verification = json.loads(frozen('paper/data/verification.json'))
checks = {k: v for k, v in verification['checks'].items() if isinstance(v, bool)}
assert len(checks) == 5 and all(checks.values()) and summary['source_checks_passed'] is True
cut = re.match(r'^cut at (\S+): ', log).group(1); assert summary['generated_at'] == cut
runs = list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected = [x for x in runs if x['run_id'] == '2LZHP9BYFTHE']; assert len(selected) == 1
row = selected[0]
assert all(row[k] == v for k, v in {'character': 'SILENT', 'ascension': '10', 'outcome': 'defeat', 'floor_max': '39', 'n_decisions': '738', 'has_postmortem': '1', 'performance_included': '1'}.items())
brain = json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers'] == {'codex': 39} and brain['failed_or_unaccepted_rows'] == 0
snap = {'request': result, 'generated_at': cut, 'source_cut_bytes': summary['source_cut_bytes'], 'five_checks': checks, 'source_checks_passed': True, 'row_counts': verification['row_counts'], 'total_decision_records': summary['decisions']['play_total'] + summary['decisions']['shadow'], 'original_count_warnings': verification['checks']['runs.jsonl decision-count mismatches'], 'run': {k: row[k] for k in ['run_id', 'character', 'ascension', 'outcome', 'floor_max', 'n_decisions', 'has_postmortem', 'performance_included']}, 'brain_source': brain, 'stage_boundary': 'Original run used P2/C2 shadow; not an on-mode outcome or benefit.', 'changed_outputs': outputs, 'component_costs': 'Separate immutable byte cuts and estimates, not invoice or credit conversion.', 'raw_snapshot': False, 'previous_outputs_preserved': str((p / 'paper-before').relative_to(r))}
(pub / 'paper-snapshot-readback.json').write_text(json.dumps(snap, ensure_ascii=False, indent=2) + '\n')
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); rows = (p / 'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows) == 18
seen = set(old.splitlines()); added = b''.join(x for x in rows if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); bf = fold(old); af = fold(old + added); assert set(bf) == set(af)
for ident in bf:
    for key in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'status', 'version', 'shipped_at', 'effect']:
        assert bf[ident].get(key) == af[ident].get(key), (ident, key)
    earlier = bf[ident].get('evidence', []); later = af[ident].get('evidence', []); assert later[:len(earlier)] == earlier
    assert all(e['run'] == '2LZHP9BYFTHE' and e['role'] == ('repeat' if ident == 'silent-0311' else 'support') for e in later[len(earlier):])
part = (p / 'owned-lessons.md').read_bytes(); oldlesson = git('show', base + ':notes/lessons.md')
assert b'## 2LZHP9BYFTHE' not in oldlesson and len(part) == 22674
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1802原174301/2LZHP9BYFTHE复盘done0闭环：1606原行逐字节JSON/身份、22674字节正文与原前缀核同，原3314材料断言读回不重复跑或冒生产测试；9证据CLI（0311老错repeat/其余support）+9提案链接共18行，旧claim/首证/prior/status/版本与旧证据保护同验。原库存恢复旧上限silent-0311已有非阻塞队列，补本局F38三台278/旧252差26及实际同SHA来源，沿原库存d2f24919与资源a30eeb76自动提案链，原缺口/范围和原ID保留，不新建/另派/补规则或称修后获胜。39实际accepted为Codex Sol6.1/xhigh/default，原9de6d107开局P2/C2均shadow，不当R359/R360 on收益；原逐击毛伤、两首试出口、完整候选兑现、受控替代结局、dirty知识/时钟/纯战斗时间/Jev缓存/账单未知保留。原最终审计status/state字段误取与ops包装器先缺读回的前置guard、原JSON+下划线元数据格式探针失败留盘，实际生成只启动一次。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0，cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性与keyscan CLEAN，2LZ原负局F39/738决策/复盘/39成功Codex入表；成本独立cut估算非账单/收益，旧告警保留。仅提交本轮复盘/18所属CLI/队列补证/生成表及本人回执，物理并行记录保留；无新源码/发布/测试或对局重启/账号模型额度队列prompt改动。证据paper/materials/20261015-1802-ops/。\n'
note = f'\n- {at} [ops 学习闭环] 2LZ复盘已归档：无新增纯bug，旧silent-0311库存上限缺口补复现，沿原提案/租约不重复派修。9证据+9链接共18CLI保持旧字段，实际39 Codex accepted；该局旧P2/C2 shadow，不作新on收益。论文唯一刷新exit0、五一致性/密钥扫描通过，{len(runs)}局；原失败与未记录范围保留，估计非账单。回执paper/materials/20261015-1802-ops/。\n'
queue = f'\n- {at} [原silent-0311非阻塞问题补复现] 仅转录原174301/2LZHP9BYFTHE学习者回报：SILENT A10 F38三台本体合278，旧首上限预算252、少26，定位rollout.ts:1721；原实际9de6d107与只读livefe646265该叶SHA相同，不把dirty整树冒已恢复。原bugs.new=false、正常结束F39，沿既有0311队列/共享租约与本局已登记silent-proposal-d2f24919ee64b90b继续，不另派或新增固定倍率，不归因整局败因或承诺转胜。资源后继提案silent-proposal-a30eeb768880d4aa沿原学习者链；原报告、固定帧及完整未知边界见paper/materials/20261015-1802-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note, 'notes/fix-queue-v4.md': queue}
(p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}
values['notes/lessons.md'] = oldlesson + part; values['paper/materials/learning/ledger.jsonl'] = old + added
for x in outputs: values[x['path']] = frozen(x['path'])
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in list(p.glob('*.py')) + [r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'postmortem': '2LZHP9BYFTHE', 'original_rows': 1606, 'original_lesson_bytes': 22674, 'new_bug': False, 'repeat': 'silent-0311', 'original_evidence_updates': 9, 'original_proposal_links': 9, 'owned_ledger_rows': 18, 'protected_fields_preserved': True, 'paper_single_exit': 0, 'paper_cut': cut, 'paper_output_count': len(outputs), 'five_checks': True, 'no_source_release_game_account_or_prompt_change': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; manifest = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); manifest.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': manifest}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'paths': len(manifest), 'ledger': 18, 'ledger_check': 0, 'paper_outputs': len(outputs), 'runs': len(runs), 'paper_exit': 0}))

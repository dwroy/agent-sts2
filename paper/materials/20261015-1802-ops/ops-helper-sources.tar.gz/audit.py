from pathlib import Path
import json, hashlib, subprocess, re, tarfile, sys
root = Path.cwd(); r = root; p = r / 'ops/codex-ops/record-staging/20261015-1802'; pub = r / 'paper/materials/20261015-1802-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a): return subprocess.check_output(['git', *a], stderr=subprocess.PIPE)
bid = '20261015-174301'; run = '2LZHP9BYFTHE'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
output = (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text()
report = json.loads(re.findall(r'```json\s*(.*?)```', output, re.S)[-1]); s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and report['appended'] == [run]
assert len(report['bugs']) == 1 and report['bugs'][0]['new'] is False and report['ledger']['repeats'] == ['silent-0311']
assert '**silent-0311**' in (r / 'notes/fix-queue-v4.md').read_text()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, output)
refs = []; counts = {}; brain = []; configs = []
for stream in ['runs', 'states', 'decisions', 'run-plans', 'sl-attempts', 'brain', 'run-config']:
    n = 0
    with (r / 'logs' / (stream + '.jsonl')).open('rb') as original, (s / (stream + '.jsonl')).open() as frozen:
        for text in frozen:
            e = json.loads(text); original.seek(e['_offset']); raw = original.read(e['_length']); row = json.loads(raw)
            assert row == {k: v for k, v in e.items() if k not in ['_line', '_offset', '_length']}
            fp = row.get('fingerprint') or {}; fp = json.loads(fp) if isinstance(fp, str) else fp
            ids = [v for v in [row.get('run_id'), row.get('run') if isinstance(row.get('run'), str) else None, (row.get('state') or {}).get('run_id'), ((row.get('state') or {}).get('run') or {}).get('run_id'), fp.get('run')] if v is not None]
            assert ids and all(x == run for x in ids), (stream, ids)
            if stream == 'states': assert row['state']['run']['character_id'] == 'SILENT' and row['state']['run']['ascension'] == 10
            if stream == 'brain':
                assert row['engine'] == 'codex' and row['model'] == 'gpt-6.1-sol' and row['effort'] == 'xhigh' and row['accepted'] is True
                brain.append(row)
            if stream == 'run-config': configs.append(row)
            refs.append({'stream': stream, 'line': e['_line'], 'offset': e['_offset'], 'bytes': e['_length'], 'sha256': sha(raw)}); n += 1
    counts[stream] = n
assert sum(counts.values()) == 1606 and len(brain) == 39 and len(configs) == 1
config = configs[0]; assert config['code']['commit'] == '9de6d107c5dad20095a37e33695f8c18a963d081'
assert config['brain']['codex']['service_tier'] == 'default' and config['loop']['s_build_rank'] == config['loop']['sim_adaptive'] == 'shadow'
verify = json.loads((s / 'verification-after.json').read_text()); assert verify['passed'] == len(verify['checks']) == 3314
before = json.loads((s / 'lessons-before.json').read_text()); physical = (r / 'notes/lessons.md').read_bytes(); part = (s / 'lesson-draft.md').read_bytes()
assert len(part) == 22674 and sha(physical[:before['size']]) == before['sha256'] and physical.count(part) == 1 and part.count(b'## 2LZHP9BYFTHE') == 1
(p / 'owned-lessons.md').write_bytes(part)
source = json.loads((s / 'source-reference.json').read_text())
for leaf in source['leaves']:
    assert sha(git('show', source['live'] + ':' + leaf['path'])) == leaf['sha256']
    assert sha(git('show', source['run_commit'] + ':' + leaf['path'])) == leaf['run_source_sha256']
    assert leaf['same'] is True
ledger = (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True); owned = []
for raw in ledger:
    row = json.loads(raw)
    if row.get('by') == 'learner:postmortem' and (run in json.dumps(row, ensure_ascii=False) or str(s) in json.dumps(row, ensure_ascii=False)):
        assert row['op'] == 'update' and row['id'] in report['ledger']['updated']
        assert set(row) <= {'op', 'id', 'ts', 'by', 'evidence', 'where', 'note'}
        assert all(e['run'] == run and e['role'] == ('repeat' if row['id'] == 'silent-0311' else 'support') for e in row.get('evidence', []))
        owned.append(raw)
assert len(owned) == 18 and sum('evidence' in json.loads(x) for x in owned) == 9
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
sys.path.insert(0, str(r / 'learner')); import code_proposals
queue = code_proposals.fold(r / 'paper/materials/learning/code-proposals.jsonl'); proposals = []
for ident in report['code_proposals']:
    q = queue[ident]; assert q['character'] == 'silent' and q['runs'] == [run] and sha(Path(q['proposal']).read_bytes()) == q['proposal_sha256']
    proposals.append({k: q.get(k) for k in ['id', 'state', 'proposal', 'proposal_sha256']})
post = {'batch': bid, 'run': run, 'original_report': report, 'native': native, 'original_rows_byte_JSON_identity_verified': 1606, 'stream_counts': counts, 'original_material_checks': 3314, 'material_checks_not_reexecuted': True, 'lesson_bytes': 22674, 'original_prefix_preserved': True, 'ledger_rows': 18, 'evidence_updates': 9, 'proposal_links': 9, 'repeat_bug': 'silent-0311; existing nonblocking queue, no new dispatch', 'source_reference': source, 'actual_accepted_brain': 39, 'source_run_config': {'code': config['code'], 's_build_rank': 'shadow', 'sim_adaptive': 'shadow', 'model': 'gpt-6.1-sol', 'effort': 'xhigh', 'service_tier': 'default'}, 'no_new_bug': True, 'original_proposals': proposals, 'limits': 'Gross damage/overkill, two first-try exits, full-candidate execution, alternative controlled outcomes, dirty knowledge, calibrated boss clock, pure combat time, Jev cache and paid invoices remain unrecorded. Old shadow run cannot demonstrate R359/R360 on benefits.', 'original_audit_error_preserved': 'First final audit used status for a proposal queue state field; original CLI writes already succeeded, no duplicate registration.'}
(pub / 'postmortem-readback.json').write_text(json.dumps(post, ensure_ascii=False, indent=2) + '\n')
(pub / 'postmortem-original-references.json').write_text(json.dumps(refs, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 300000 and f.suffix in ['.json', '.md', '.py', '.txt', '.log'] and not f.name.startswith(('ledger-before', 'ledger-find', 'prior-silent'))]
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); target = p / 'archive-scan' / rel; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(pub / 'preflight-failures-preserved.json').write_text(json.dumps({'paper_wrapper_first_exit': 1, 'paper_wrapper_failure': 'Required postmortem-readback did not yet exist; assertion before snapshot or generator spawn. Calls to actual generator so far: zero.', 'read_only_probes': ['Old helper pathname did not exist; no mutation.', 'Initial probe assumed wrapped row/data; actual extraction has original JSON with _line/_offset/_length; corrected parser only.'], 'production_or_source_failure': False}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'rows': 1606, 'lesson_bytes': 22674, 'ledger_rows': 18, 'accepted_codex': 39, 'new_bugs': 0, 'existing_repeat': 'silent-0311'}))

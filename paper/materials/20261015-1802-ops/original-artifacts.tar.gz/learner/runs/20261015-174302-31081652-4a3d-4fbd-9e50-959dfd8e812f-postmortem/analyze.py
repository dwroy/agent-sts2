import json,pathlib,collections
P=pathlib.Path(__file__).parent
D=[json.loads(l) for l in (P/'decisions.jsonl').open()]
S=[json.loads(l) for l in (P/'states.jsonl').open()]
B=[json.loads(l) for l in (P/'brain.jsonl').open()]
R=json.loads((P/'2LZHP9BYFTHE-resources.json').read_text())
def dump(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
with (P/'critical-states.txt').open('w') as o:
 for r in S:
  st=r['state'];run=st.get('run') or {};co=st.get('combat') or {}
  if run.get('floor',0)<37:continue
  o.write(f"s{r['_line']} {r['ts']} F{run.get('floor')} T{st.get('turn')} {st['screen']} HP{run.get('current_hp')}/{run.get('max_hp')} "+dump(co)+'\n')
with (P/'critical-decisions.txt').open('w') as o:
 for r in D:
  if r['floor']>=37:
   rr={k:v for k,v in r.items() if k not in ['fingerprint','questions','deepseek','boss_sim','journal']}
   o.write(dump(rr)+'\n')
with (P/'questions.txt').open('w') as o:
 for r in D:
  if r.get('questions') and r['floor']>=37:o.write('d'+str(r['_line'])+' '+dump(r['questions'])+'\n')
with (P/'plans.txt').open('w') as o:
 for l in (P/'run-plans.jsonl').open():o.write(dump(json.loads(l))+'\n')
for c in R['combats']:
 if c['floor'] not in [17,30,31,33,35,36,37,38,39]:continue
 states=[x for x in S if c['entry']['line']<=x['_line']<=(c['exit'] or c['last'])['line']]
 groups=[]
 for x in states:
  if not x['state'].get('in_combat'):continue
  if not groups or groups[-1][0]['state']['turn']!=x['state']['turn']:groups.append([])
  groups[-1].append(x)
 print('FIGHT',c['sequence'],c['floor'],c['enemies'])
 for i,g in enumerate(groups):
  a=g[0];z=groups[i+1][0] if i+1<len(groups) else states[-1];st=a['state'];en=st['combat']['enemies']
  hp0=a['state']['run']['current_hp'];hp1=z['state']['run']['current_hp'];live=lambda st:sum(e['current_hp'] for e in (st.get('combat') or {}).get('enemies',[]) if e['is_alive'])
  print(' T',st['turn'],'s',a['_line'],'HP',hp0,'->',hp1,'live',live(st),'->',live(z['state']),'enemies',[(e['enemy_id'],e['current_hp']) for e in en], 'player', dump(st['combat'].get('player'))[:900])
print('CRITICAL D')
for r in D:
 if r['floor']>=37: print(r['_line'],r['floor'],r['turn'],r['label'],r.get('sl_reloads'),r.get('rationale'), 'ACTION',r['chosen'])

import pathlib,subprocess,json,hashlib
P=pathlib.Path(__file__).parent
run='2LZHP9BYFTHE'
find=subprocess.run(['python3','learner/ledger.py','find','--run',run,'--json'],text=True,capture_output=True)
assert find.returncode==0
(P/'ledger-final.json').write_text(find.stdout)
items=json.loads(find.stdout)
updated=json.loads((P/'ledger-updated.json').read_text())
assert {x['id'] for x in items}==set(updated)
for x in items:
    before=P/('ledger-before-'+x['id']+'.json')
    if before.exists():
        old=json.loads(before.read_text())
        for key in ['claim','first_run','prior','status','version']:
            assert x.get(key)==old.get(key),(x['id'],key)
    assert run in x.get('where',{}).get('lessons',[])
    ev=[e for e in x['evidence'] if e.get('run')==run]
    assert ev and all(e.get('role')==('repeat' if x['id']=='silent-0311' else 'support') for e in ev)
results=json.loads((P/'proposal-results.json').read_text())
ids=[x['output'] for x in results]
found=[]
with pathlib.Path('paper/materials/learning/code-proposals.jsonl').open() as h:
    for line in h:
        if not any(i in line for i in ids):continue
        row=json.loads(line)
        if row.get('id') in ids and row.get('op')=='add':found.append(row)
assert {x['id'] for x in found}==set(ids)
for x in found:
    assert x['character']=='silent' and x['source_task']=='postmortem' and x['target_task']=='strategy-proposal'
    assert x.get('state')=='pending' and not x.get('implemented_commit')
    assert set(x['ledger'])<=set(updated)
    assert hashlib.sha256(pathlib.Path(x['proposal']).read_bytes()).hexdigest()==x['proposal_sha256']
for x in items:
    assert any(str(P.resolve()/('proposal-'+n+'.md')) in x.get('where',{}).get('proposal',[]) for n in ['stock','resources'])
check=subprocess.run(['python3','learner/ledger.py','check'],text=True,capture_output=True)
(P/'ledger-check-final.txt').write_text(check.stdout+check.stderr)
assert check.returncode==0,check.stdout+check.stderr
post=subprocess.run(['python3',str(P/'verify.py'),'--after'],text=True,capture_output=True)
(P/'verification-final.txt').write_text(post.stdout+post.stderr)
assert post.returncode==0,post.stdout+post.stderr
(P/'final-audit.json').write_text(json.dumps({'ledger_check':check.returncode,'updated':updated,'code_proposals':ids,'preserved_fields':['claim','first_run','prior','status','version'],'material_checks':3314,'new_bugs':0,'repeated_bugs':['silent-0311'],'proposal_state':'pending','proposal_hashes_match':True},ensure_ascii=False,indent=2)+'\n')
print(check.stdout.strip())
print(post.stdout.strip())
print('两个提案均state=pending，文件指纹一致，无实现提交；九个条目链接齐全。')

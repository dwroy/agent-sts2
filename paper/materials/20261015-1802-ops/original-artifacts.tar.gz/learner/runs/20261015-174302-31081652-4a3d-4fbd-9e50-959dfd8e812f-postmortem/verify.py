import json,pathlib,hashlib,datetime,re
P=pathlib.Path(__file__).parent
ROOT=P.parents[2]
checks=[]
def check(name,ok):
    assert ok,name
    checks.append(name)
D=[json.loads(x) for x in (P/'decisions.jsonl').open()]
S=[json.loads(x) for x in (P/'states.jsonl').open()]
B=[json.loads(x) for x in (P/'brain.jsonl').open()]
R=json.loads((P/'2LZHP9BYFTHE-resources.json').read_text())
by_s={x['_line']:x for x in S};by_d={x['_line']:x for x in D}
for kind in ['runs','states','decisions','run-plans','brain','run-config','sl-attempts']:
    n=0
    with (ROOT/'logs'/(kind+'.jsonl')).open('rb') as src:
        for line in (P/(kind+'.jsonl')).open():
            row=json.loads(line);src.seek(row['_offset']);raw=src.read(row['_length']);original=json.loads(raw)
            check(f'{kind}:{row["_line"]}:原字节JSON',original=={k:v for k,v in row.items() if k not in ['_line','_offset','_length']})
            check(f'{kind}:{row["_line"]}:局号',original.get('run_id',original.get('run',(original.get('state') or {}).get('run_id')))=='2LZHP9BYFTHE')
            n+=1
    check(kind+':非空',n>0)
check('24窗口22房',len(R['combats'])==24 and len({c['floor'] for c in R['combats']})==22)
check('所有入口T1',all(c['entry_is_turn_one'] for c in R['combats']))
check('两处缺结算出口',[c['sequence'] for c in R['combats'] if c['exit'] is None]==[21,23])
t=(P/'lesson-draft.md').read_text()
for row in t.splitlines():
    if not row.startswith('| F'):continue
    match=re.search(r'\| (\d+)→(\d+)；(\d\d:\d\d:\d\d\.\d+)—(\d\d:\d\d:\d\d\.\d+) \|$',row)
    if match:
        a,z,ta,tz=match.groups();a,z=int(a),int(z)
        check('表时点'+str(a),by_s[a]['ts'][11:-1]==ta and by_s[z]['ts'][11:-1]==tz)
        a_run=by_s[a]['state']['run'];z_run=by_s[z]['state']['run']
        check('表HP'+str(a),str(a_run['current_hp'])+'→'+('末态' if '出口未记录' in row else '')+str(z_run['current_hp']) in row)
        maximum=str(a_run['max_hp'])+('→'+str(z_run['max_hp']) if a_run['max_hp']!=z_run['max_hp'] else '')
        check('表max'+str(a),'／'+maximum+'；' in row)
check('死亡意图',by_s[412159]['state']['combat']['enemies'][2]['intents'][0]['total_damage']==9)
check('死亡HP挡',(by_s[412159]['state']['run']['current_hp'],by_s[412159]['state']['combat']['player']['block'],by_s[412160]['state']['run']['current_hp'])==(4,0,0))
check('终态存活敌',[(e['enemy_id'],e['current_hp']) for e in by_s[412160]['state']['combat']['enemies']]==[('NOISEBOT',19),('FABRICATOR',86)])
check('库存三台',[by_s[n]['state']['combat']['enemies'][0]['max_hp'] for n in [412004,412017,412046]]==[84,89,105])
check('库存预算',sum([84,89,105])==278 and 3*84==252 and 278-252==26)
check('饮用13次',sum(x['chosen']['action']=='use_potion' for x in D)==13)
check('不丢药',sum(x['chosen']['action']=='discard_potion' for x in D)==0)
check('新取得11瓶',sum(len({tuple(a) for a in c['to']['potions']}-{tuple(a) for a in c['from']['potions']}) for c in R['resource_changes'] if not c['restart_boundary'])==11)
check('两次SL药返还',sum(len({tuple(a) for a in c['to']['potions']}-{tuple(a) for a in c['from']['potions']}) for c in R['resource_changes'] if c['restart_boundary'])==2)
check('SL恢复14',sum(c['to']['hp']-c['from']['hp'] for c in R['resource_changes'] if c['restart_boundary'])==14)
check('无护栏',not any('HP guard:' in x.get('rationale','') or x.get('hp_guard') for x in D))
check('脑39接受',len(B)==39 and all((x['engine'],x['model'],x['effort'],x['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for x in B))
check('脑token',tuple(sum((x.get('usage') or {}).get(k,0) for x in B) for k in ['inputTokens','outputTokens','cacheHitTokens'])==(7337680,47359,4240256))
check('Jevtoken',tuple(sum((x.get('usage') or {}).get(k,0) for x in D if x['decider']=='jev') for k in ['input_tokens','output_tokens'])==(1110029,8796))
check('用时',(datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(D[0]['ts'])).total_seconds()==3479.227)
check('配置至结束',(datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(json.loads((P/'run-config.jsonl').read_text())['ts'])).total_seconds()==3547.776)
check('仅一节三条经验',sum(x.startswith('## ') for x in t.splitlines())==1 and sum(x.startswith('- [') for x in t.splitlines())==4)
# Verify the existing prefix, allowing other agents to append their own independent sections.
before=json.loads((P/'lessons-before.json').read_text());f=ROOT/'notes/lessons.md'
with f.open('rb') as h:
    digest=hashlib.sha256(h.read(before['size'])).hexdigest()
check('旧前缀原字节保持',digest==before['sha256'])
if '--after' in __import__('sys').argv:
    with f.open('rb') as h:
        h.seek(before['size']);new=h.read().decode()
    check('唯一局号标题',len(re.findall(r'^## 2LZHP9BYFTHE',new,re.M))==1)
    check('追加正文与已核草稿完全相同',t in new)
(P/('verification-after.json' if '--after' in __import__('sys').argv else 'verification-before.json')).write_text(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'phase':'after' if '--after' in __import__('sys').argv else 'before'},ensure_ascii=False))

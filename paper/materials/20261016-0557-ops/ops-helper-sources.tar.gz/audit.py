from pathlib import Path
import collections,hashlib,importlib.util,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0557';pub=r/'paper/materials/20261016-0557-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
bid='20261016-054302';run='ATP5MCMJDMQY';s=r/'learner/runs/20261016-054305-55f4735e-f59e-496f-b290-041b22c14e48-postmortem';report=load(s/'result.json');b=load(r/'ops/codex-ops/learn.json')['batches'][bid]
assert report['appended']==[run] and report['bugs']==report['ledger']['added']==report['ledger']['repeats']==[] and len(report['ledger']['updated'])==9 and report['ledger']['check']==0
assert b['state']=='done' and b['rc']==0 and b['done']==[run] and b['missing']==[] and b['proposal_audit_errors']==[]
out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output)
spec=importlib.util.spec_from_file_location('raw_identity',r/'learner/extract_evidence.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
verification=load(s/'verification-input.json');refs=[];counts={};runrow=None;config=None;brains=[];decisions=[];frames={}
for stream in ['states','decisions','sl-attempts','run-config','run-plans','runs','brain','jev-prompts']:
    count=0
    with (s/(stream+'.jsonl')).open('rb') as selected,(r/'logs'/(stream+'.jsonl')).open('rb') as original:
        for encoded in selected:
            frozen=json.loads(encoded);ref=frozen['_source'];original.seek(ref['offset']);raw=original.read(ref['bytes']);row=json.loads(raw)
            assert len(raw)==ref['bytes'] and raw.endswith(b'\n') and sha(raw)==ref['sha256'] and extract.run_identity(row)==run and row=={k:v for k,v in frozen.items() if k!='_source'}
            if stream=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10);frames[ref['line']]=row
            if stream=='runs':assert (row['character'],row['ascension'],row['floor'],row['victory'])==('SILENT',10,17,False);runrow=row
            if stream=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains.append(row)
            if stream=='run-config':config=row
            if stream=='decisions':decisions.append(row)
            refs.append(dict(stream=stream,learner_reported_source_line=ref['line'],offset=ref['offset'],bytes=len(raw),sha256=sha(raw)));count+=1
    counts[stream]=count;assert count==verification['数量'][stream]
assert counts==dict(states=271,decisions=260,**{'sl-attempts':1,'run-config':1,'run-plans':4,'jev-prompts':51},runs=1,brain=18) and len(refs)==607
before=load(s/'lessons-prefix.json');post=load(s/'append-verification.json');physical=(r/'notes/lessons.md').read_bytes();section=(s/'section.md').read_bytes()
assert sha(physical[:before['bytes']])==before['sha256'] and sha(section)==post['本节SHA256'] and len(section)==post['本节字节数']==17315 and physical[before['bytes']:before['bytes']+len(section)]==section
assert post['旧前缀保持'] and post['本局标题数']==1 and sum(x.startswith(b'## ATP5MCMJDMQY') for x in physical.splitlines())==1 and (s/'source-diff.patch').read_bytes()==b''
(p/'owned-lessons.md').write_bytes(section)
assert config['code']['commit']=='e716bd28fd8eca9e4d76d066680304fd11935e37' and all(x.startswith(('knowledge/','notes/')) for x in config['code']['dirty_files']) and len(config['code']['dirty_files'])==12
assert config['brain']['engines']['codex']['model']=='gpt-6.1-sol' and config['brain']['engines']['codex']['effort']=='xhigh' and not any(d.get('fallback') for d in decisions)
usage={key:sum(row['usage'][key] for row in brains) for key in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}
assert usage==dict(inputTokens=3207765,outputTokens=21941,cacheHitTokens=1231488,reasoningTokens=19618) and sum(row['latency_ms'] for row in brains)==610524
assert sum(bool(d.get('hp_guard')) for d in decisions)==1 and collections.Counter(str(d.get('rollout_best_chosen')) for d in decisions if d['decider']=='jev' and d['label'].startswith('combat/'))=={'True':37,'None':1}
keyframes=load(s/'final-keyframe-check.json')
for line,expected in keyframes['关键帧'].items():
    f=frames[int(line)];assert [f['state']['run']['floor'],f['state']['turn'],f['state']['run']['current_hp']]==expected
assert keyframes['自爆来袭']==47 and keyframes['零挡末态缺血']==22 and load(s/'number-checks.json')['通过数']==15
ids=set(report['ledger']['updated']);owned=[];ledgerrefs=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('by')=='learner:postmortem' and row.get('id') in ids and (any(e.get('run')==run for e in row.get('evidence',[])) or str(s) in raw.decode() or run in row.get('where',{}).get('lessons',[])):
            assert row['op']=='update' and set(row)<={'op','id','ts','by','evidence','where','note'} and all(e['run']==run and e['role']=='support' for e in row.get('evidence',[]))
            owned.append(raw);ledgerrefs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==18 and sum('evidence' in json.loads(raw) for raw in owned)==9
for ident in ids:assert (s/(ident+'-update.stdout')).read_text().strip()==ident and (s/(ident+'-update.stderr')).read_bytes()==b''
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'owned-ledger-references.json',ledgerrefs)
item=load(s/'proposal-item.json');ident=(s/'proposal-cli.stdout').read_text().strip();assert report['code_proposals']==[ident] and ident=='silent-proposal-1069ab7df83ba06d' and (s/'proposal-cli.stderr').read_bytes()==b''
matches=[]
with (r/'paper/materials/learning/code-proposals.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('op')=='add' and row.get('id')==ident:matches.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(matches)==1;proposal=matches[0]['row'];assert proposal['state']=='pending' and all(proposal.get(k)==v for k,v in item.items()) and sha(Path(item['proposal']).read_bytes())==proposal['proposal_sha256']
write(pub/'postmortem-original-references.json',refs)
write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,native=native,original_rows_checked=607,stream_counts=counts,raw_binding='Original offsets/bytes/SHA, original JSON and explicit run identity independently verified; source lines remain learner-reported.',actual_accepted_codex=18,original_run_row=runrow,actual_run_config=config,source_reference=config['code']['commit'],source_reference_does_not_reconstruct_dirty_knowledge=True,post_append=post,original_lesson_bytes=17315,old_lesson_prefix_preserved=True,original_ledger_rows=18,new_ledger_ids=[],old_support_ids=report['ledger']['updated'],repeats=[],original_proposals=matches,new_bug=False,actual_brain_usage=usage,original_verification=verification,limits='No reload, one died attempt; final47 demand versus capped26 loss and22 survival gap remain distinct. Six prior wins are resource observations, not controlled retained-potion/rest/unknown-draw alternatives. Missing terminal hits, repeated entity identities, poison/heal intermediate frames and uncapped damage, complete candidate execution, historical refreshed knowledge bytes, comparable DPR, pure combat time, Jev cache and invoices remain unknown. R365 source at startup is not a matched Paper Krane/beam consumer.'))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);print(json.dumps(dict(rows=607,ledger_rows=18,lesson_bytes=17315,new_bug=False)))

from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile
sys.dont_write_bytecode=True
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0557'; pub=r/'paper/materials/20261016-0557-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1; log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut; runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected=[x for x in runs if x['run_id']=='ATP5MCMJDMQY']; assert len(selected)==1; row=selected[0]
assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max='17',n_decisions='260',has_postmortem='1',performance_included='1').items()); brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':18} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],run={k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r))); write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==18; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==18
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(z)==set(a)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['evidence','where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['evidence','where','history','notes']}
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert a[ident].get(key)==z[ident].get(key),(ident,key)
 previous=a[ident].get('evidence',[]); later=z[ident].get('evidence',[]); assert later[:len(previous)]==previous; assert all(x['run']=='ATP5MCMJDMQY' and x['role']=='support' for x in later[len(previous):])
 for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
 for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==17315 and b'## ATP5MCMJDMQY' not in oldlesson and lesson in (r/'notes/lessons.md').read_bytes(); readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged18_rows']=True; readback['parallel_physical_rows_preserved']='Only own chapter and18 original CLI rows staged; other root records and pre-existing whitespace differences remain physical/uncommitted.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0557原054302复盘ATP5MCMJDMQY done0闭环，无新增纯bug，不重复队列/复派。八流607所属原行按冻结offset/bytes/SHA/原JSON/显式身份核，原行号保持学习者报告值；Silent A10/F17瀑布巨兽负局、260决策/271状态/51Jev/18实际accepted Codex Sol6.1/xhigh。七场资源链前六胜、末战一试死/无SL；本体结束后47来袭与零挡26HP实扣封顶分列，保持末态存活至少差22，不倒推未执行抽牌/留固化/回血分支必胜。17315字节正式节及旧物理前缀SHA核；18所属CLI含九旧项support及九原提案追溯，私有fold旧claim/首证/prior/status/version与证据/history/notes/where前缀保持，不重复CLI或造新shipped。1069ab7df83ba06d原注册/SHA/pending沿自动独立策略链，无完整候选/反事实不改规则；37/37只指Jev回答、原后缀被抽弃取消，护栏原线未执行不称实省血，饮4弃0及再生15分列。18脑原用量3207765入/21941出/1231488缓存/19618推理、610524ms核，不重复相加run-plan或编Jev缓存/账单。启动R365/e716与12知识/记录dirty叶分列，不以源码号当纸鹤光束匹配消费者；当前学习者native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0、cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策，五一致性/keyscan CLEAN，本局has_postmortem1/260决策/18成功Codex入表；计数告警/各组件独立cut估计非账单保持。ops初读无report键/状态player路径探针失败保留、不当产品故障。仅所属复盘/18CLI/生成表及证据提交，保并行物理记录，无代码/知识/版本/补测/派发/重启局/账号home模型额度队列prompt改变，不关闭宽父。证据paper/materials/20261016-0557-ops/。\n'
note=f'\n- {at} [ops 学习闭环] ATP5MCMJDMQY复盘及18所属CLI已核，无新增纯bug；九项support与九提案追溯、1069ab原策略提案沿自动链，完整替线/留药后继未知保持。论文唯一刷新exit0、{len(runs)}局、五一致性/keyscan通过，无新发布或对局操作。回执paper/materials/20261016-0557-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in p.glob('*.py'):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortem='ATP5MCMJDMQY',original_rows_checked=607,original_lesson_bytes=17315,original_section_bytes=17315,leading_newline_bytes=0,new_bug=False,owned_ledger_rows=18,evidence_updates=9,repeat_evidence=0,support_evidence=9,proposal_links=9,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=18,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

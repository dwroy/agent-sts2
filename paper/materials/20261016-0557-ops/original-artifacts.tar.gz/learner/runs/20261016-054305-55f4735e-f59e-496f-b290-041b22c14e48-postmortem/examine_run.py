import json,collections
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/(n+'.jsonl')).open()]
d=load('decisions'); s=load('states'); b=load('brain'); j=load('jev-prompts'); r=json.loads((p/'ATP5MCMJDMQY-resources.json').read_text())
print('COUNTS',len(d),len(s),len(b),len(j),'WINDOW',d[0]['ts'],d[-1]['ts']);print('labels',collections.Counter((x['decider'],x['label']) for x in d))
for x in d:
 if x['decider']=='codex':print('BRAINDEC',x['_source']['line'],x['floor'],x['label'],json.dumps(x.get('chosen'),ensure_ascii=False),x['rationale'])
for x in r['combats']:
 print('RESOURCE',json.dumps({k:v for k,v in x.items() if k not in ('enemy_hp_audit','changes')},ensure_ascii=False))
 print('DAMAGE',[(t['turn'],t['live_enemy_hp_start'],t['visible_enemy_hp_loss_lower_bound'],t['gaps']) for t in x['enemy_hp_audit']['turns']])
print('CHANGES')
for x in r['resource_changes']:print(json.dumps(x,ensure_ascii=False))
print('BOSS STATES')
prev=None
for x in s:
 st=x['state']; run=st.get('run') or {}; c=st.get('combat') or {}
 if run.get('floor')==17:
  v={'line':x['_source']['line'],'turn':st['turn'],'screen':st['screen'],'hp':run.get('current_hp'),'player':c.get('player'),'enemies':c.get('enemies')}
  print(json.dumps(v,ensure_ascii=False))

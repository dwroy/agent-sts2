import json,subprocess
from pathlib import Path
p=Path(__file__).parent;run='ATP5MCMJDMQY'
items=[
 ('silent-0017',[(17,10,'d406502/s419762—419766：选择偏折、打击、双防御，23挡损5、敌49→7；所选8样本4胜，提前结束本体候选8样本3胜未执行。'),(17,12,'s419767—419769/d406508/a2262：本体7血35毒转EXPLODE_MOVE占位，26血0挡对47自爆、实扣26，存活至少差22；未知抽牌上界有活线使SL未确认必死，实际直接结束且无重载。')]),
 ('silent-0020',[(16,None,'d406456/s419710—419714：53血选升级步法，未选回血可到70；升级867/1000胜与回血880/1000均低可信，实际53入巨兽T12失败。F12唯一回血37→58；三锻一回。未执行另一营火／保留药水整战，不记同错repeat。'),(11,3,'d406406/s419659—419660：原计划留巨兽的固化已在骇鳗饮用，5→15挡对18实损3，胜后37；后F14赢至53才补再生。赢战资源链与未来意图分账。')]),
 ('silent-0418',[(17,4,'d406476—406479/s419734—419739：匕首→药瓶候选伤25回2，但实际弃药瓶再问迷雾，原后缀未执行；可见匕首扣13、迷雾加6毒，回血／毒中间帧缺失，189→185只作净推进。'),(17,5,'d406480—406484：双防御→匕首→切割，切割被0.23信心弃掉，旧预测明确作废；37/37最优回答不是整线兑现。'),(11,1,'d406392护栏候选省5伤少9，实际换入五步与弃牌完成、13挡对18损5，敌150→135含主动12及荆棘3。未实打原线，不将模型actual_outcome空字段改写为完整反事实。')]),
 ('silent-0005',[(17,3,'d406471/s419728—419729：灵动步法+建立3敏捷、迅速附魔首抽2；T10偏折7与两防御各8合23，比无敏同三牌14多9，仍受28攻损5。T12仍3敏但无现成挡牌、0挡。')]),
 ('silent-0016',[(17,5,'s419714/419722/419727/419734/419739：护喉甲开场覆甲4，T2/3/4为3/2/1，T5无覆甲，末T12零挡；不预支开场持续防御。')]),
 ('silent-0007',[(17,7,'s419750—419753：单敌毒3，经升级药瓶到15、咕嘟冒泡到24；结束敌137→113、毒24→23。T8迷雾加至29，攻击4与已结毒29共可见33，未建触媒。')]),
 ('silent-0225',[(11,3,'d406406/s419659—419661：已有5挡饮固化槽1，5→15，当步增10；18攻实损3，药清槽。只补本局已有挡倍率事实，不强制留药或声称留药必胜。')]),
 ('silent-0259',[(17,1,'d406464/s419719—419745：再生药建5，随后T1—T5实际回5/4/3/2/1合15，未封顶；敌行动扣血另列，末战入口53出口0不等毛伤53。')]),
 ('silent-0046',[(17,2,'本局为瀑布巨兽普通攻击的临时减力补证，非实验体／自爆新规则：尖啸建−6力量使16→10，4偏折+3覆甲，先回4再扣3、58→59；次轮负力消失。保留原首证及适用边界，不外推其他爆炸。')]),
]
updates=[]
for ident,evs in items:
 evidence=[dict(run=run,floor=floor,**({'turn':turn} if turn is not None else {}),note=note,role='support') for floor,turn,note in evs]
 updates.append(dict(id=ident,by='learner:postmortem',evidence=evidence,where={'lessons':[run]},note='20261016-054305-55f4735e-f59e-496f-b290-041b22c14e48-postmortem：本角色原日志补证，保留旧claim/first_run/prior/status/version；没有同一已证失误的复发判定，不记repeat。'))
(p/'ledger-updates.json').write_text(json.dumps(updates,ensure_ascii=False,indent=2)+'\n')
for x in updates:
 result=subprocess.run(['python3','-B','/home/dw/Projects/agent-sts2/learner/ledger.py','update'],input=json.dumps(x,ensure_ascii=False),text=True,capture_output=True)
 (p/(x['id']+'-update.stdout')).write_text(result.stdout);(p/(x['id']+'-update.stderr')).write_text(result.stderr)
 if result.returncode:raise SystemExit(str((x['id'],result.returncode,result.stderr)))
 print(x['id'],result.stdout.strip())
(p/'ledger-result.json').write_text(json.dumps({'added':[],'updated':[x['id'] for x in updates],'repeats':[]},ensure_ascii=False,indent=2)+'\n')

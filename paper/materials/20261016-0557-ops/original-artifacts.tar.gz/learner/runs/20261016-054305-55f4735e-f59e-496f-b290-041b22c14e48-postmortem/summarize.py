import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=load('decisions');s=load('states');b=load('brain');j=load('jev-prompts');r=json.loads((p/'ATP5MCMJDMQY-resources.json').read_text())
print('原行范围',[(n,len(a),a[0]['_source']['line'],a[-1]['_source']['line']) for n,a in [('d',d),('s',s),('b',b),('j',j),('p',load('run-plans'))]])
low=[(x['_source']['line'],x['floor'],x['turn'],x['label'],x.get('confidence')) for x in d if x['decider']=='jev' and isinstance(x.get('confidence'),(float,int)) and x['confidence']<.35];print('低信心',low)
plans=[x for x in d if x['decider']=='jev' and x['label'].startswith('combat/plan-choice')];print('rollout最佳',collections.Counter(x.get('rollout_best_chosen') for x in plans),len(plans))
auto=[x for x in d if x['decider']=='code' and x['label'].startswith('combat/') and x['label']!='combat/plan-continue'];wins={(x['floor'],x.get('sl_reloads') or 0,x['turn']) for x in d if x['label'].startswith('combat/')};print('代码自主',collections.Counter(x['label'] for x in auto),len({(x['floor'],x.get('sl_reloads') or 0,x['turn']) for x in auto}),'全部回合',len(wins))
print('低信心替换',[(x['_source']['line'],x['label']) for x in d if any(k in x for k in ['hp_guardrail','hp_guard','guardrail']) or 'guard' in x.get('rationale','').lower()]);print('可选字段',sorted(set().union(*(x.keys() for x in d))))
for x in d:
 if 'guard' in str(x.get('selection_audit','')).lower():print('GUARD',x['_source']['line'],json.dumps(x['selection_audit'],ensure_ascii=False)[:1500])
print('药水动作',[(x['_source']['line'],x['floor'],x['turn'],x.get('chosen'),x.get('rationale'),x.get('result')) for x in d if (x.get('chosen') or {}).get('action') in ['use_potion','discard_potion','buy_potion']])
print('用量',[(name,sum((x.get('usage') or {}).get(name,0) or 0 for x in b)) for name in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']], 'brainLatency',sum(x.get('latency_ms',0) or 0 for x in b),'jev',sum(x.get('input_tokens',0) or 0 for x in j),sum(x.get('output_tokens',0) or 0 for x in j),'models',collections.Counter((x['engine'],x['model'],x['effort'],x['accepted']) for x in b),'fallback',collections.Counter(x.get('fallback') for x in d))
for c in r['combats']:
 print('HP逐轮',c['floor'],[(t['turn'],sum(max(0,e['from']['hp']-e['to']['hp']) for e in c['changes'] if e['from']['turn']==t['turn']),sum(max(0,e['to']['hp']-e['from']['hp']) for e in c['changes'] if e['from']['turn']==t['turn'])) for t in c['enemy_hp_audit']['turns']])
for x in d:
 if x['label'] in ['map/route-plan','rest/plan']:
  print('路线休息',x['_source']['line'],x['floor'])
  for q in x.get('questions',{}).values():
   for k,v in q.get('criteria',{}).items():
    if x['label']=='rest/plan' and k not in ['o0','o1:c17','o1:c13','o1:c21']:continue
    a=json.loads(v) if isinstance(v,str) and v.startswith('{') else v
    if not isinstance(a,dict):continue
    z={key:a[key] for key in a if key in ['option','then','boss_sim','boss_sim_hp_reference','hp','hp_projection','route','hp_after','projected_boss_hp']}
    qf=a.get('quantitative_fight',{}); z['model']={key:qf.get(key) for key in ['samples','damage_per_turn_won','effective_damage_per_turn','simulated_turns']}
    print(k,json.dumps(z,ensure_ascii=False))
print('死亡手牌',next(x for x in s if x['_source']['line']==419768)['state']['combat']['hand'])
print('计划')
for x in load('run-plans'):print(x['_source']['line'],x['floor'],x['trigger'],json.dumps(x['plan'],ensure_ascii=False))
for x in d:
 if x['floor']==17 and x['label'].startswith('combat/plan-choice'):
  print('末战候选',x['_source']['line'],x['turn'],'答案',x.get('answers'))
  for q in x.get('questions',{}).values():
   for k,v in q.get('criteria',{}).items():
    a=json.loads(v) if isinstance(v,str) and v.startswith('{') else v
    if isinstance(a,dict):print(k,{key:a[key] for key in ['plays','hp_lost','damage_dealt','block_gained','rollout','focus','result'] if key in a},'otherkeys',list(a)[-8:])

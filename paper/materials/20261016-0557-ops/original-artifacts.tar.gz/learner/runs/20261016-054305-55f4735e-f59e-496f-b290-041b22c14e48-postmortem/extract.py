import json,subprocess,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=Path(__file__).parent; run='ATP5MCMJDMQY'
for name in ['runs','decisions','states','run-plans','sl-attempts','brain','jev-prompts','run-config']:
    source=root/'logs'/f'{name}.jsonl'; count=0
    proc=subprocess.Popen(['rg','-n','-b','-F',run,str(source)],stdout=subprocess.PIPE)
    with (out/f'{name}.jsonl').open('w') as dest:
        for line in proc.stdout:
            line_no,offset,raw=line.split(b':',2); row=json.loads(raw)
            row['_source']={'line':int(line_no),'offset':int(offset),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
            dest.write(json.dumps(row,ensure_ascii=False)+'\n'); count+=1
    proc.wait(); print(name,count,'rg_exit',proc.returncode)
rows=[json.loads(x) for x in (out/'decisions.jsonl').open()]
first,last=rows[0]['ts'],rows[-1]['ts']
p=root/'logs/deepseek-reasoning.jsonl'; size=p.stat().st_size; start=max(0,size-65536)
with p.open('rb') as f:
    f.seek(start)
    if start:f.readline()
    tail=[]
    while raw:=f.readline():
        try:tail.append(json.loads(raw))
        except ValueError:pass
print('decision_window',first,last,'reasoning_tail_times',[(x.get('ts'),list(x)[:4]) for x in tail[-2:]])
(out/'deepseek-window-audit.json').write_text(json.dumps({'decision_first':first,'decision_last':last,'file_bytes':size,'tail_seek_offset':start,'tail_last_ts':tail[-1].get('ts') if tail else None,'matched_rows':0,'limitation':'尾部时间早于本局；未将其他局旧推理移入本局'},ensure_ascii=False,indent=2)+'\n')

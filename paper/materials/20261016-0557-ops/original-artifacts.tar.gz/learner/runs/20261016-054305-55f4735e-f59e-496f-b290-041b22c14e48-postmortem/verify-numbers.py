import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
s=load('states');d=load('decisions');b=load('brain');j=load('jev-prompts');r=json.loads((p/'ATP5MCMJDMQY-resources.json').read_text())
checks=[]
def check(name,value):
 assert value,name
 checks.append(name)
check('七场HP入口出口',[(x['floor'],x['entry']['hp'],x['exit']['hp']) for x in r['combats']]==[(2,56,52),(3,52,49),(5,49,46),(8,46,45),(11,45,37),(14,58,53),(17,53,0)])
check('全部T1完整入口出口及maxHP70',all(x['entry_is_turn_one'] and x['exit'] and x['entry']['max_hp']==x['exit']['max_hp']==70 for x in r['combats']))
last=next(x['state'] for x in s if x['_source']['line']==419768);pl=last['combat']['player'];e=last['combat']['enemies'][0]
check('死亡T12及最终资源缺口22',last['turn']==12 and pl['current_hp']==26 and pl['block']==0 and e['intents'][0]['total_damage']==47 and 47-26+1==22)
check('死亡终态',s[-1]['state']['screen']=='GAME_OVER' and s[-1]['state']['run']['current_hp']==0)
check('本体阶段占位形状',e['enemy_id']=='WATERFALL_GIANT' and e['max_hp']==999999999 and e['move_id']=='EXPLODE_MOVE')
check('脑模型身份',all((x['engine'],x['model'],x['effort'],x['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for x in b))
check('脑用量',tuple(sum(x['usage'][k] for x in b) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens'])==(3207765,21941,1231488,19618))
check('Jev用量',sum(x['input_tokens'] for x in j)==243898 and sum(x['output_tokens'] for x in j)==2383)
check('低信心4',sum(x['decider']=='jev' and (x.get('confidence') or 0)<.35 for x in d)==4)
check('推演最优37及无标记药水题1',collections.Counter(x.get('rollout_best_chosen') for x in d if x['decider']=='jev' and x['label'].startswith('combat/plan-choice'))=={True:37,None:1})
check('护栏1',sum(bool(x.get('hp_guard')) for x in d)==1)
check('饮4弃0',collections.Counter((x.get('chosen') or {}).get('action') for x in d)['use_potion']==4 and not any((x.get('chosen') or {}).get('action')=='discard_potion' for x in d))
regen=[e['to']['hp']-e['from']['hp'] for e in r['combats'][-1]['changes'] if e['to']['hp']>e['from']['hp']]
check('再生实际5到1',regen==[5,4,3,2,1])
check('四火仅一次回血',[(x['floor'],(x.get('chosen') or {}).get('option_index')) for x in d if x['label']=='rest/plan']==[(7,1),(9,1),(12,0),(16,1)])
check('无SL重载',all((x.get('sl_reloads') or 0)==0 for x in d) and len(load('sl-attempts'))==1 and load('sl-attempts')[0]['reload'] is None)
(p/'number-checks.json').write_text(json.dumps({'检查':checks,'通过数':len(checks)},ensure_ascii=False,indent=2)+'\n')
print('通过',len(checks),'项关键数字检查')

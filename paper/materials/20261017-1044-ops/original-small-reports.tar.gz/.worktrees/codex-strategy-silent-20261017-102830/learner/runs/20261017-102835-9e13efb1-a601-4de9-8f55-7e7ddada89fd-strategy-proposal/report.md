# 静默猎手策略提案批次报告

批次：20261017-102830-strategy-proposal；记录时间：2026-10-17T10:40:47+08:00。

十个派发 ID 均已复核并保留 waiting。已有诊断只覆盖窄子项，完整候选执行归属、逐来源结算或受控后继仍有具体缺口；本批不新增参数、经验条目或源码。

完整基线：`8d667937a13da48eea9975250e3b821467e7fee8`。`fixes=[]`、`merged=null`，源码提交与行为版本均无。生产 tsc/vitest/cases 均未运行，值为 null；撤源码失败/恢复通过不适用。没有把材料核验、历史源测试或其他 live 发布的绿色结果填成本批测试。

派发身份与逐项证据见 [proposal.md](proposal.md)；原派发行保存在 dispatch.json，十份原提案的角色、账本、路径与 SHA 保存在 assigned-proposals.json、proposal-source-verification.json。普通请求未匹配本批专题身份，仍按指定十项工作；没有领取其余队列。

## 原始证据范围

通过共用 learner/extract_evidence.py 提取八流，共8444条明确身份封套。audit_evidence.py 逐条从原日志 offset 重读 bytes，复核原行 SHA、JSON、显式局身份、截点与输出 SHA；原始日志只读。共31项流/身份材料检查通过。状态与决策各有2条无法解析的源行、大脑流2条，抽取器未将它们计入本批证据；不臆测这些坏行属于本批或可补全。

| 局号 | 状态 | 决策 | SL记录 | 配置 | 计划 | 大脑记录 | 完局记录 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 751FN9QM9MHQ | 624 | 615 | 6 | 1 | 2 | 15 | 1 |
| KV0JHNJCKXLS | 686 | 669 | 7 | 1 | 5 | 32 | 1 |
| YQL8RZ8BWN1E | 582 | 571 | 6 | 1 | 3 | 18 | 1 |
| L9SGRBB5R698 | 653 | 635 | 6 | 1 | 3 | 16 | 1 |
| PU80F84P6HPN | 1064 | 1033 | 12 | 1 | 5 | 31 | 1 |
| KEN58SH9SLZ6 | 558 | 548 | 6 | 1 | 3 | 18 | 1 |

fight-plans在本次2233957字节截点未选到六局记录；这不表示原始日志不存在。本批run-plans使用run字段选中21条，未以正文提及判归属。没有重跑旧截点或覆盖旧零行初稿。每流source_size、逐局计数及输出SHA见 evidence/evidence-manifest.json，每条原行位置和SHA在对应 *.evidence.jsonl。

状态投影得到91个连续战斗片段、763个回合窗口，计入SL重打且不等同独立战斗样本；最后判死或SL截断窗口没有下一帧时保持未知。没有将91片段或43条SL记录当成独立局。

## 本批核实的关键取舍

verify_claims.py完成41项固定材料断言，完整原帧引用及不确定项见 verified-claims.json；与前述31项合计72项材料检查，均不计作生产测试。原始37项中间核验日志及增加能力窗口后41项日志分别保留。

| 对照 | 实测玩家净失血 | 实测敌净HP减少 | 可得结论与限制 |
|---|---|---|---|
| 751 F17 T2，第1/3试 | 13→18 | 9→18 | 多9净扣付5血，不给探索阈值 |
| 751 F17 T7，第2/4试 | 13→23 | 12→18 | 多6净扣付10血；未决弃牌造成的保守绝对误差不能抹去配对实际差额 |
| KEN F17 T10，第4/5试 | 15→21 | 2→4 | 多付6血只多扣2；后轮动作并未控制 |
| KEN F17 T5，第4/6试 | 7→5 | 1→2 | 省2血但敏捷由T5延到T9，T8仍未建立；不能只取最小当轮失血 |
| KV F33 T5，第4/5试 | 0→0 | 36→29 | 删毒没有已记录保血收益，次轮毒20→13；净扣不是逐来源毛伤 |

五组决策指纹均逐字相同，证据局/层/回合、决策行号、状态窗口offset/bytes/SHA及原sl_explore配对B2值保存在 verified-claims.json。单步对照不控制其他回合，complete_candidate_execution_certified与controlled_whole_fight_effect保持null。

751 F13 T3题面同时存在有药、仅本轮无药、整战无药三种范围。plan2用药预测8损26伤；plan3本轮无药8损16伤，但未来7/8样本饮用；plan5才是无药整战参考。该局没有实际不饮用或留药到Boss的完整分支，缺表价0不构成持有价值0。

YQL F17末试T10毒药前后残壳毒2→8，血26、挡13、自爆41均未改变。L9与PU原记录也有近十亿占位血。PU第5试T15过爆后状态252436为2血，不能声称不存在胜线；该胜线与更早药时或新排序之间没有受控因果。

KEN的7次用药请求与7组药栏消耗端点均已核；3次请求回执是pending。槽位消耗支持已用掉药水，不认证随机选牌、重问及后续整条候选收益。所有原回执、药栏前后原帧和未知效果保留。

这些结果与原提案保留的限定结论相容，没有新增机制反证或经验结论异议；没有把同一原证据重复加为support/repeat。

## 已有源码与未交付范围

只读核实live HEAD：`1c8d6d2bd731514e5613ca63f46dc44fef2e59d5`。下列提交均经git merge-base --is-ancestor核为实际live祖先，逐叶工作树和live SHA见source-provenance.json。

| 源码 | 已核实际 live 祖先 | 当前工作树/live字节相同 |
|---|---|---|
| `agent/src/reflex/silent-selection-audit.ts` | `05cd292c6f01bb31e406473d3a9843e659d62b93` | 是 |
| `agent/src/reflex/silent-held-loss.ts` | `05cd292c6f01bb31e406473d3a9843e659d62b93` | 是 |
| `agent/src/reflex/silent-potion-reference.ts` | `04921bd785ac6838066522f91ea0bb6ab95cb6a1` | 是 |
| `agent/src/reflex/silent-giant-potion.ts` | `d5e20aa4dd44168ce30944dfcce74f8322144953` | 是 |
| `agent/src/reflex/combat-plan.ts` | `b831407a8ed13bcb9b5359b0d3e1ae84624d5571` | 是 |
| `agent/src/reflex/turn-solver.ts` | `b831407a8ed13bcb9b5359b0d3e1ae84624d5571` | 是 |
| `agent/src/sl/attempts.ts` | `0d092f6b928a6221eabf3516abad25c48ceaac9c` | 是 |
| `agent/src/sl/explore.ts` | `0d092f6b928a6221eabf3516abad25c48ceaac9c` | 否，仅注释署名；原diff已保存 |
| `agent/src/reflex/potion-cost.ts` | `e1a467e18a0dfa8d99046a24ff4c0e1af59278c8` | 否，仅注释署名；原diff已保存 |

两叶差异的完整补丁保存在live-source-differences.patch，仅Roy/Dai历史注释署名。本批没有将这些差异合入或改写。持牌函数的actual_held_hp_loss和选择审计的actual_turn仍为null；原执行器已有chosen/result只能证明各动作请求或回执，抽弃和续问可能截断原候选。巨兽阶段说明也不等于更改旧anchorRank或证明新排序收益。

没有因窄功能已有代码就把整包标implemented/duplicate；等待项仍需各自上述具体缺口。没有新模拟、LLM/网络调用、play或自然消费者验收，不声称本次经验已入库或大脑已采用。其他角色源码与知识保持零修改。

## 十项处置

- `silent-proposal-366288801d9150d9`：waiting。已有SL前后预测及持牌拆项；缺抽弃、续问后的完整候选归属和逐来源实结算，局部多付5/10血不能确定探索准入门槛。
- `silent-proposal-85929bdfc8a3fc1b`：waiting。持牌未决和持药未知提示已存在；缺逐来源实际损血认证、F13同题不饮药的完整执行分支及留药后战对照，不能完成整项验证或拟合持有价。
- `silent-proposal-efd9f83ee9e1a6dc`：waiting。与366288共享同一局六次SL；已有预测诊断，缺完整候选实际归属、受控整战后继和独立留后验证，不能把经验提案另算新增独立证据。
- `silent-proposal-131042659448ae74`：waiting。预测拆项和未知药价已有实现；缺攻击、毒、荆棘、持牌损血及敏捷的联合逐来源实际校准，以及跨战用药完整对照，不能以单项已有代码关闭整包。
- `silent-proposal-990f054036609447`：waiting。已核同盘零净损、敌净扣36/29及次轮毒20/13；缺毛伤与回血逐来源归属、保持后轮条件的完整对照及路线休息替代后继，不能据删输出声称保血收益。
- `silent-proposal-e18d3f18e6cac2a0`：waiting。本体/自爆及残壳用毒事实已有展示；缺阶段指标改序与提前喝、不喝、留药的受控完整后继，PU既有胜线未隔离这些因素，不能靠占位血归零证明改序更优。
- `silent-proposal-9733bb80f445aeae`：waiting。残壳毒2→8未改41自爆及PU过爆余2已核；缺阶段估值、参考路径排序和用药时点的受控整战比较，已有阶段子功能不能关闭整个经验提案。
- `silent-proposal-c51468c5e8ba6668`：waiting。七次用药均有药栏消耗端点，三次回执pending；缺随机选牌及重问后的完整收益归属、同题未饮用和留至Boss的完整对照，不能从空药栏失败拟合留药价。
- `silent-proposal-86a7db08d1a31976`：waiting。已核T10多付6血只多扣2，以及T5省2血却延迟敏捷；缺逐来源兑现、完整候选认证及保持后轮条件的整战对照，不能设统一6血换2伤阈值或关闭更差线探索。
- `silent-proposal-e282a9131b99129a`：waiting。持牌血价、无实体及能力窗口只有局部配对；缺完整候选归属、受控整战后继和独立验证，不因经验与复盘各有提案就增加样本或设置统一阈值。

逐项账本、证据局/层/回合、原规则与预期行为、反例、时间切分、验证与回退均在proposal.md；不新建重复提案。code_proposals字段只沿用根CLI既有十个ID，implementation_domains为空。

## 追溯与交接

只经根learner/ledger.py update追加本角色既有条目的本批报告/提案链接，by=learner:strategy-proposal。具体输入、stdout/stderr及读回见ledger-updates.jsonl、ledger-cli.log、ledger-verification.json。没有新增游戏知识条目，不变更旧claim、first_run、prior、status、version或evidence，不降级原shipped状态，也不登记新的shipped。

本批无源码改动，因此无需要兜底提交或live合入的补丁，无eval版本、上线记录或规则双通知；不把waiting写成父要求已关闭。根队列状态由调度器按final.json逐项消费，未直接写learn.json或code-proposals.jsonl。

运维入口：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-102830/learner/runs/20261017-102835-9e13efb1-a601-4de9-8f55-7e7ddada89fd-strategy-proposal/proposal.md`；最终机器回报：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-102830/learner/runs/20261017-102835-9e13efb1-a601-4de9-8f55-7e7ddada89fd-strategy-proposal/final.json`。工作树最终HEAD与干净状态及账本受保护字段读回见final-verification.json；材料清单与SHA见artifact-manifest.json。

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261017-102830-strategy-proposal",
  "base": "8d667937a13da48eea9975250e3b821467e7fee8",
  "runs": [
    "751FN9QM9MHQ",
    "KV0JHNJCKXLS",
    "YQL8RZ8BWN1E",
    "L9SGRBB5R698",
    "PU80F84P6HPN",
    "KEN58SH9SLZ6"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-366288801d9150d9",
    "silent-proposal-85929bdfc8a3fc1b",
    "silent-proposal-efd9f83ee9e1a6dc",
    "silent-proposal-131042659448ae74",
    "silent-proposal-990f054036609447",
    "silent-proposal-e18d3f18e6cac2a0",
    "silent-proposal-9733bb80f445aeae",
    "silent-proposal-c51468c5e8ba6668",
    "silent-proposal-86a7db08d1a31976",
    "silent-proposal-e282a9131b99129a"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-366288801d9150d9",
      "state": "waiting",
      "reason": "已有SL前后预测及持牌拆项；缺抽弃、续问后的完整候选归属和逐来源实结算，局部多付5/10血不能确定探索准入门槛。"
    },
    {
      "id": "silent-proposal-85929bdfc8a3fc1b",
      "state": "waiting",
      "reason": "持牌未决和持药未知提示已存在；缺逐来源实际损血认证、F13同题不饮药的完整执行分支及留药后战对照，不能完成整项验证或拟合持有价。"
    },
    {
      "id": "silent-proposal-efd9f83ee9e1a6dc",
      "state": "waiting",
      "reason": "与366288共享同一局六次SL；已有预测诊断，缺完整候选实际归属、受控整战后继和独立留后验证，不能把经验提案另算新增独立证据。"
    },
    {
      "id": "silent-proposal-131042659448ae74",
      "state": "waiting",
      "reason": "预测拆项和未知药价已有实现；缺攻击、毒、荆棘、持牌损血及敏捷的联合逐来源实际校准，以及跨战用药完整对照，不能以单项已有代码关闭整包。"
    },
    {
      "id": "silent-proposal-990f054036609447",
      "state": "waiting",
      "reason": "已核同盘零净损、敌净扣36/29及次轮毒20/13；缺毛伤与回血逐来源归属、保持后轮条件的完整对照及路线休息替代后继，不能据删输出声称保血收益。"
    },
    {
      "id": "silent-proposal-e18d3f18e6cac2a0",
      "state": "waiting",
      "reason": "本体/自爆及残壳用毒事实已有展示；缺阶段指标改序与提前喝、不喝、留药的受控完整后继，PU既有胜线未隔离这些因素，不能靠占位血归零证明改序更优。"
    },
    {
      "id": "silent-proposal-9733bb80f445aeae",
      "state": "waiting",
      "reason": "残壳毒2→8未改41自爆及PU过爆余2已核；缺阶段估值、参考路径排序和用药时点的受控整战比较，已有阶段子功能不能关闭整个经验提案。"
    },
    {
      "id": "silent-proposal-c51468c5e8ba6668",
      "state": "waiting",
      "reason": "七次用药均有药栏消耗端点，三次回执pending；缺随机选牌及重问后的完整收益归属、同题未饮用和留至Boss的完整对照，不能从空药栏失败拟合留药价。"
    },
    {
      "id": "silent-proposal-86a7db08d1a31976",
      "state": "waiting",
      "reason": "已核T10多付6血只多扣2，以及T5省2血却延迟敏捷；缺逐来源兑现、完整候选认证及保持后轮条件的整战对照，不能设统一6血换2伤阈值或关闭更差线探索。"
    },
    {
      "id": "silent-proposal-e282a9131b99129a",
      "state": "waiting",
      "reason": "持牌血价、无实体及能力窗口只有局部配对；缺完整候选归属、受控整战后继和独立验证，不因经验与复盘各有提案就增加样本或设置统一阈值。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-102830/learner/runs/20261017-102835-9e13efb1-a601-4de9-8f55-7e7ddada89fd-strategy-proposal/report.md"
}
```

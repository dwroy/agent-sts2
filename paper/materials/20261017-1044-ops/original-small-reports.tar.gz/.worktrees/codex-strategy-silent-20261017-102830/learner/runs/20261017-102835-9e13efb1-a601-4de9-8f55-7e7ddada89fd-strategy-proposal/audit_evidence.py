import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extract_evidence", HERE.parents[1] / "extract_evidence.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
dispatch = json.loads((HERE / "dispatch.json").read_text())
runs = dispatch["runs"]
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
streams = {}
checks = []


def check(name, condition, details=None):
    checks.append({"name": name, "passed": bool(condition), "details": details})
    if not condition:
        raise AssertionError((name, details))


def reference(envelope):
    return {key: envelope[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}


for entry in manifest:
    name = entry["stream"]
    path = HERE / "evidence" / (name + ".evidence.jsonl")
    digest = hashlib.sha256()
    rows = []
    counts = collections.Counter()
    with Path("/home/dw/Projects/agent-sts2/logs", name + ".jsonl").open("rb") as source:
        for line in path.open("rb"):
            digest.update(line)
            item = json.loads(line)
            source.seek(item["offset"])
            raw = source.read(item["bytes"])
            check_raw = (hashlib.sha256(raw).hexdigest() == item["sha256"] and
                         json.loads(raw) == item["row"] and
                         module.run_identity(item["row"]) == item["run_id"] and
                         item["run_id"] in runs and
                         item["offset"] + item["bytes"] <= entry["source_size"])
            if not check_raw:
                check("原行字节与身份", False, reference(item))
            counts[item["run_id"]] += 1
            rows.append(item)
    check(name + "逐行字节、SHA和身份", True, len(rows))
    check(name + "输出SHA", digest.hexdigest() == entry["output_sha256"])
    check(name + "逐局计数", dict(counts) == {key: value for key, value in entry["counts"].items() if value})
    streams[name] = rows

identities = {}
for item in streams["runs"]:
    row = item["row"]
    check("角色和进阶:" + item["run_id"], row["character"].lower() == "silent" and row["ascension"] == 10)
    identities[item["run_id"]] = row
check("六局身份齐全且无重复", len(streams["runs"]) == len(runs) and set(identities) == set(runs))


def project(item):
    state = item["row"]["state"]
    combat = state.get("combat") or {}
    run = state.get("run") or {}
    player = combat.get("player") or {}
    return {
        "reference": reference(item), "ts": item["row"]["ts"], "floor": run.get("floor"),
        "turn": state.get("turn"), "in_combat": state.get("in_combat"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"), "block": player.get("block"),
        "hand": [{key: card.get(key) for key in ("index", "card_id", "upgraded", "resolved_rules_text")} for card in combat.get("hand", [])],
        "player_powers": player.get("powers", []),
        "enemies": [{key: enemy.get(key) for key in ("index", "enemy_id", "current_hp", "max_hp", "is_alive", "move_id", "powers", "intents")} for enemy in combat.get("enemies", [])],
        "potions": [{key: potion.get(key) for key in ("index", "slot", "potion_id", "occupied")} for potion in run.get("potions", [])],
    }


episodes = []
by_run = {}
for run_id in runs:
    raw_states = [item for item in streams["states"] if item["run_id"] == run_id]
    projected = [project(item) for item in raw_states]
    by_run[run_id] = projected
    current = None
    for frame in projected:
        if not frame["in_combat"]:
            if current is not None:
                current["exit"] = frame
                episodes.append(current)
                current = None
            continue
        if current is not None and (current["floor"] != frame["floor"] or frame["turn"] < current["frames"][-1]["turn"]):
            episodes.append(current)
            current = None
        if current is None:
            current = {"run_id": run_id, "floor": frame["floor"], "frames": [], "exit": None}
        current["frames"].append(frame)
    if current is not None:
        episodes.append(current)

turns = []
for episode in episodes:
    groups = collections.OrderedDict()
    for frame in episode["frames"]:
        groups.setdefault(frame["turn"], []).append(frame)
    items = list(groups.items())
    for index, (turn, group) in enumerate(items):
        next_frame = items[index + 1][1][0] if index + 1 < len(items) else episode["exit"]
        first, last = group[0], group[-1]
        enemy_hp = lambda frame: sum(e["current_hp"] for e in frame["enemies"] if e["is_alive"])
        turns.append({
            "run_id": episode["run_id"], "floor": episode["floor"], "turn": turn,
            "episode_start_line": episode["frames"][0]["reference"]["line"],
            "first": first, "last": last, "next": next_frame,
            "net_player_hp_loss": first["hp"] - next_frame["hp"] if next_frame is not None else None,
            "net_living_enemy_hp_change": enemy_hp(first) - enemy_hp(next_frame) if next_frame is not None else None,
            "complete_to_next_frame": next_frame is not None,
        })

decisions = []
for item in streams["decisions"]:
    row = item["row"]
    entry = {"reference": reference(item), **{key: row.get(key) for key in (
        "ts", "floor", "turn", "label", "sl_attempt", "chosen", "result", "rationale", "expect", "confidence", "questions", "answers", "boss_sim", "sl_explore", "selection_audit", "potions")}}
    decisions.append(entry)

attempts = []
for item in streams["sl-attempts"]:
    row = item["row"]
    attempts.append({"reference": reference(item), **{key: row.get(key) for key in (
        "floor", "attempt", "result", "turns", "end_hp", "end_block", "incoming", "summary", "explore")}})

out = {"checks": checks, "identities": identities, "stream_counts": {entry["stream"]: entry["counts"] for entry in manifest},
       "episodes": len(episodes), "turns": len(turns), "decision_count": len(decisions)}
(HERE / "evidence-audit.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
for filename, entries in [("turns.jsonl", turns), ("decision-projections.jsonl", decisions), ("attempt-projections.jsonl", attempts)]:
    with (HERE / filename).open("w") as handle:
        for entry in entries:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
print(json.dumps({"checks_passed": len(checks), "envelopes": sum(len(rows) for rows in streams.values()),
                  "episodes": len(episodes), "turns": len(turns), "stream_counts": out["stream_counts"]}, ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((HERE / 'dispatch.json').read_text())
assigned = json.loads((HERE / 'assigned-proposals.json').read_text())
dispositions = json.loads((HERE / 'dispositions.json').read_text())
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
audit = json.loads((HERE / 'evidence-audit.json').read_text())
claims = json.loads((HERE / 'verified-claims.json').read_text())
source = json.loads((HERE / 'source-provenance.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
batch = '20261017-102830-strategy-proposal'
stamp = (HERE / 'report-date.txt').read_text().strip()
assert len(base) == 40
assert dispatch['task'] == 'strategy-proposal' and dispatch['character'] == 'silent'
assert dispatch['worktree'] == str(HERE.parents[2])
assert not any(key in dispatch for key in ('research_request', 'implementation_request', 'proposal_repair'))
assert [entry['id'] for entry in dispositions] == dispatch['proposal_ids']
assert len(set(dispatch['runs'])) == 6
assert all(item['passed'] for item in audit['checks'] + claims['checks'])

proposal = [
    '# 静默猎手十项原提案复核', '',
    f'本批：{batch}。记录时间：{stamp}。基线：`{base}`。', '',
    '结论：十项均为 waiting。本批逐项核原提案、账本、原始日志和当前源码，没有新增策略、源码提交、合入或行为版本。已有窄诊断与整包验证分别记载，不用预测字段替代实际完整候选执行。', '',
    '派发为普通队列消费：根 learn.json 对应行 task=strategy-proposal、character=silent、reason=proposal、工作树一致，领取十个 proposal_ids；无 research_request 或 implementation_request。普通专题请求绑定另一批，未读取其 work_spec 或冻结证据，也未转入专题。开工 git status 干净，按任务 git merge --no-edit main 返回 Already up to date。', '',
    '仅核本批六局和 silent 经验，六局 runs.jsonl 角色均为 SILENT、进阶均 A10。原提案正文逐份 SHA 匹配，副本使用原 ID 命名保存；没有新建代码提案 ID，没有重写历史复盘。', '',
]
for item in dispositions:
    original = assigned[item['id']]['original']
    proposal.extend([
        f"## {item['id']}", '',
        '处置：waiting。', '',
        '账本：' + '、'.join(original['ledger']) + '。来源任务：' + original['source_task'] + '；原实现任务：strategy-proposal。', '',
        '证据：' + item['evidence'], '',
        '既有实现与边界：' + item['existing'], '',
        '未完成原因：' + item['reason'], '',
        '预期行为与验证：' + item['validation'], '',
        '本批没有拟合或调整参数。相关 SL 按独立局分组；当前六局作为冻结核验输入，未来若拟合，必须记录更早独立局及时间切点，再留后续新局验证。未经执行的分支保持未知，缺帧或回执 pending 不补成成功。', '',
        '预期影响：完善处置追溯，不宣称胜率或当前运行消费者收益。回退：本批没有行为变更可撤；未来实现应使用独立源码提交回退，保留本批证据、原提案和所有失败历史。', '',
    ])
(HERE / 'proposal.md').write_text('\n'.join(proposal))

count_rows = ['| 局号 | 状态 | 决策 | SL记录 | 配置 | 计划 | 大脑记录 | 完局记录 |', '|---|---:|---:|---:|---:|---:|---:|---:|']
by_stream = {entry['stream']: entry for entry in manifest}
for run in dispatch['runs']:
    count_rows.append('| ' + run + ' | ' + ' | '.join(str(by_stream[key]['counts'][run]) for key in ('states', 'decisions', 'sl-attempts', 'run-config', 'run-plans', 'brain', 'runs')) + ' |')

source_rows = ['| 源码 | 已核实际 live 祖先 | 当前工作树/live字节相同 |', '|---|---|---|']
for entry in source['files']:
    source_rows.append(f"| `{entry['path']}` | `{entry['actual_live_ancestor_commit']}` | {'是' if entry['live_equal'] else '否，仅注释署名；原diff已保存'} |")

results = [{'id': item['id'], 'state': 'waiting', 'reason': item['reason']} for item in dispositions]
final = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
    'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
(HERE / 'final.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

report = [
    '# 静默猎手策略提案批次报告', '',
    f'批次：{batch}；记录时间：{stamp}。', '',
    '十个派发 ID 均已复核并保留 waiting。已有诊断只覆盖窄子项，完整候选执行归属、逐来源结算或受控后继仍有具体缺口；本批不新增参数、经验条目或源码。', '',
    f'完整基线：`{base}`。`fixes=[]`、`merged=null`，源码提交与行为版本均无。生产 tsc/vitest/cases 均未运行，值为 null；撤源码失败/恢复通过不适用。没有把材料核验、历史源测试或其他 live 发布的绿色结果填成本批测试。', '',
    '派发身份与逐项证据见 [proposal.md](proposal.md)；原派发行保存在 dispatch.json，十份原提案的角色、账本、路径与 SHA 保存在 assigned-proposals.json、proposal-source-verification.json。普通请求未匹配本批专题身份，仍按指定十项工作；没有领取其余队列。', '',
    '## 原始证据范围', '',
    '通过共用 learner/extract_evidence.py 提取八流，共8444条明确身份封套。audit_evidence.py 逐条从原日志 offset 重读 bytes，复核原行 SHA、JSON、显式局身份、截点与输出 SHA；原始日志只读。共31项流/身份材料检查通过。状态与决策各有2条无法解析的源行、大脑流2条，抽取器未将它们计入本批证据；不臆测这些坏行属于本批或可补全。', '',
    *count_rows, '',
    'fight-plans在本次2233957字节截点未选到六局记录；这不表示原始日志不存在。本批run-plans使用run字段选中21条，未以正文提及判归属。没有重跑旧截点或覆盖旧零行初稿。每流source_size、逐局计数及输出SHA见 evidence/evidence-manifest.json，每条原行位置和SHA在对应 *.evidence.jsonl。', '',
    '状态投影得到91个连续战斗片段、763个回合窗口，计入SL重打且不等同独立战斗样本；最后判死或SL截断窗口没有下一帧时保持未知。没有将91片段或43条SL记录当成独立局。', '',
    '## 本批核实的关键取舍', '',
    'verify_claims.py完成41项固定材料断言，完整原帧引用及不确定项见 verified-claims.json；与前述31项合计72项材料检查，均不计作生产测试。原始37项中间核验日志及增加能力窗口后41项日志分别保留。', '',
    '| 对照 | 实测玩家净失血 | 实测敌净HP减少 | 可得结论与限制 |',
    '|---|---|---|---|',
    '| 751 F17 T2，第1/3试 | 13→18 | 9→18 | 多9净扣付5血，不给探索阈值 |',
    '| 751 F17 T7，第2/4试 | 13→23 | 12→18 | 多6净扣付10血；未决弃牌造成的保守绝对误差不能抹去配对实际差额 |',
    '| KEN F17 T10，第4/5试 | 15→21 | 2→4 | 多付6血只多扣2；后轮动作并未控制 |',
    '| KEN F17 T5，第4/6试 | 7→5 | 1→2 | 省2血但敏捷由T5延到T9，T8仍未建立；不能只取最小当轮失血 |',
    '| KV F33 T5，第4/5试 | 0→0 | 36→29 | 删毒没有已记录保血收益，次轮毒20→13；净扣不是逐来源毛伤 |', '',
    '五组决策指纹均逐字相同，证据局/层/回合、决策行号、状态窗口offset/bytes/SHA及原sl_explore配对B2值保存在 verified-claims.json。单步对照不控制其他回合，complete_candidate_execution_certified与controlled_whole_fight_effect保持null。', '',
    '751 F13 T3题面同时存在有药、仅本轮无药、整战无药三种范围。plan2用药预测8损26伤；plan3本轮无药8损16伤，但未来7/8样本饮用；plan5才是无药整战参考。该局没有实际不饮用或留药到Boss的完整分支，缺表价0不构成持有价值0。', '',
    'YQL F17末试T10毒药前后残壳毒2→8，血26、挡13、自爆41均未改变。L9与PU原记录也有近十亿占位血。PU第5试T15过爆后状态252436为2血，不能声称不存在胜线；该胜线与更早药时或新排序之间没有受控因果。', '',
    'KEN的7次用药请求与7组药栏消耗端点均已核；3次请求回执是pending。槽位消耗支持已用掉药水，不认证随机选牌、重问及后续整条候选收益。所有原回执、药栏前后原帧和未知效果保留。', '',
    '这些结果与原提案保留的限定结论相容，没有新增机制反证或经验结论异议；没有把同一原证据重复加为support/repeat。', '',
    '## 已有源码与未交付范围', '',
    f"只读核实live HEAD：`{source['live_head']}`。下列提交均经git merge-base --is-ancestor核为实际live祖先，逐叶工作树和live SHA见source-provenance.json。", '',
    *source_rows, '',
    '两叶差异的完整补丁保存在live-source-differences.patch，仅Roy/Dai历史注释署名。本批没有将这些差异合入或改写。持牌函数的actual_held_hp_loss和选择审计的actual_turn仍为null；原执行器已有chosen/result只能证明各动作请求或回执，抽弃和续问可能截断原候选。巨兽阶段说明也不等于更改旧anchorRank或证明新排序收益。', '',
    '没有因窄功能已有代码就把整包标implemented/duplicate；等待项仍需各自上述具体缺口。没有新模拟、LLM/网络调用、play或自然消费者验收，不声称本次经验已入库或大脑已采用。其他角色源码与知识保持零修改。', '',
    '## 十项处置', '',
]
for item in dispositions:
    report.extend([f"- `{item['id']}`：waiting。{item['reason']}"])
report.extend(['', '逐项账本、证据局/层/回合、原规则与预期行为、反例、时间切分、验证与回退均在proposal.md；不新建重复提案。code_proposals字段只沿用根CLI既有十个ID，implementation_domains为空。', '',
               '## 追溯与交接', '',
               '只经根learner/ledger.py update追加本角色既有条目的本批报告/提案链接，by=learner:strategy-proposal。具体输入、stdout/stderr及读回见ledger-updates.jsonl、ledger-cli.log、ledger-verification.json。没有新增游戏知识条目，不变更旧claim、first_run、prior、status、version或evidence，不降级原shipped状态，也不登记新的shipped。', '',
               '本批无源码改动，因此无需要兜底提交或live合入的补丁，无eval版本、上线记录或规则双通知；不把waiting写成父要求已关闭。根队列状态由调度器按final.json逐项消费，未直接写learn.json或code-proposals.jsonl。', '',
               f'运维入口：`{HERE / "proposal.md"}`；最终机器回报：`{HERE / "final.json"}`。工作树最终HEAD与干净状态及账本受保护字段读回见final-verification.json；材料清单与SHA见artifact-manifest.json。', '',
               '```json', json.dumps(final, ensure_ascii=False, indent=2), '```', ''])
(HERE / 'report.md').write_text('\n'.join(report))

ledger_to_proposals = {}
for item in dispositions:
    for ledger_id in assigned[item['id']]['original']['ledger']:
        ledger_to_proposals.setdefault(ledger_id, []).append(item)
with (HERE / 'ledger-updates.jsonl').open('w') as handle:
    for ledger_id, linked in sorted(ledger_to_proposals.items()):
        update = {'id': ledger_id, 'by': 'learner:strategy-proposal',
                  'where': {'proposal': [str(HERE / 'proposal.md')], 'changelog': [str(HERE / 'report.md')]},
                  'note': f'批次{batch}复核；' + '；'.join(item['id'] + '=waiting：' + item['reason'] for item in linked) +
                  '。本批仅追溯，未新增evidence/support/repeat、未改变原状态/claim/首证/prior/版本；无源码、提交、合入或新测试，不将预测和槽位消耗当完整候选兑现。'}
        handle.write(json.dumps(update, ensure_ascii=False) + '\n')
print(json.dumps({'base': base, 'report': str(HERE / 'report.md'), 'waiting': len(results), 'ledger_updates': len(ledger_to_proposals)}, ensure_ascii=False))

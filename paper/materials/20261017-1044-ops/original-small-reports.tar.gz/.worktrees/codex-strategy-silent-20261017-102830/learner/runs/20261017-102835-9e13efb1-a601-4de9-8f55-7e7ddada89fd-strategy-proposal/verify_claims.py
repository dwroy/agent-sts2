import collections
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
rows = {}
for name in ("states", "decisions", "sl-attempts"):
    rows[name] = {item["line"]: item for item in
                  (json.loads(line) for line in (HERE / "evidence" / (name + ".evidence.jsonl")).open())}
turns = [json.loads(line) for line in (HERE / "turns.jsonl").open()]
checks = []
findings = []


def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)


def ref(item):
    return {key: item[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}


def turn_of(run_id, floor, attempt, turn):
    candidates = [entry for entry in turns if entry["run_id"] == run_id and entry["floor"] == floor]
    starts = sorted({entry["episode_start_line"] for entry in candidates})
    return next(entry for entry in candidates if entry["episode_start_line"] == starts[attempt - 1] and entry["turn"] == turn)


pairs = [
    ("751 T2", 272434, 272575, "751FN9QM9MHQ", 17, 1, 3, 2, [13, 18], [9, 18]),
    ("751 T7", 272531, 272652, "751FN9QM9MHQ", 17, 2, 4, 7, [13, 23], [12, 18]),
    ("KEN T10", 274505, 274568, "KEN58SH9SLZ6", 17, 4, 5, 10, [15, 21], [2, 4]),
    ("KEN T5", 274484, 274601, "KEN58SH9SLZ6", 17, 4, 6, 5, [7, 5], [1, 2]),
    ("KV T5", 273400, 273450, "KV0JHNJCKXLS", 33, 4, 5, 5, [0, 0], [36, 29]),
]
for label, old_line, new_line, run_id, floor, old_attempt, new_attempt, turn, losses, damages in pairs:
    old, new = rows["decisions"][old_line], rows["decisions"][new_line]
    check(label + "同指纹", old["row"]["fingerprint"] == new["row"]["fingerprint"])
    actual = [turn_of(run_id, floor, attempt, turn) for attempt in (old_attempt, new_attempt)]
    check(label + "实测净失血", [entry["net_player_hp_loss"] for entry in actual] == losses)
    check(label + "实测敌净HP变化", [entry["net_living_enemy_hp_change"] for entry in actual] == damages)
    findings.append({"label": label, "run_id": run_id, "floor": floor, "turn": turn,
                     "attempts": [old_attempt, new_attempt], "decision_references": [ref(old), ref(new)],
                     "player_net_hp_loss": losses, "enemy_net_hp_change": damages,
                     "state_windows": [[entry["first"]["reference"], entry["next"]["reference"]] for entry in actual],
                     "sl_prediction": new["row"].get("sl_explore"),
                     "complete_candidate_execution_certified": None,
                     "controlled_whole_fight_effect": None})

def dexterity(frame):
    return sum(power["amount"] for power in frame["player_powers"] if power["power_id"] == "DEXTERITY_POWER")


old_setup = turn_of("KEN58SH9SLZ6", 17, 4, 5)
new_setup = turn_of("KEN58SH9SLZ6", 17, 6, 5)
late_setup = turn_of("KEN58SH9SLZ6", 17, 6, 9)
check("KEN省2血但敏捷建立延后", dexterity(old_setup["last"]) == 2 and dexterity(new_setup["last"]) == 0 and dexterity(late_setup["last"]) == 2)
check("KEN末次T8仍未建立敏捷", dexterity(turn_of("KEN58SH9SLZ6", 17, 6, 8)["last"]) == 0)
poison_next = lambda entry: next(power["amount"] for power in entry["next"]["enemies"][0]["powers"] if power["power_id"] == "POISON_POWER")
check("KV配对次轮毒20到13", [poison_next(turn_of("KV0JHNJCKXLS", 33, attempt, 5)) for attempt in (4, 5)] == [20, 13])
check("PU第五试过巨兽后余2血", turn_of("PU80F84P6HPN", 17, 5, 15)["next"]["hp"] == 2)
findings.append({"label": "能力窗口及既有胜线反例", "ken_dexterity": {
    "old_t5": old_setup["last"]["reference"], "new_t5": new_setup["last"]["reference"],
    "new_t9": late_setup["last"]["reference"]}, "kv_poison_next": [20, 13],
    "pu_won_state": turn_of("PU80F84P6HPN", 17, 5, 15)["next"]["reference"],
    "single_action_whole_fight_cause": None})

q = rows["decisions"][272361]["row"]["questions"]["plan"]["criteria"]
options = {key: json.loads(value) for key, value in q.items()}
check("751 F13有药预测8损26伤", options["plan2"]["hp_lost"] == 8 and options["plan2"]["damage_dealt"] == 26)
check("751 F13本轮无药预测8损16伤", options["plan3"]["hp_lost"] == 8 and options["plan3"]["damage_dealt"] == 16)
check("751 F13缺表说明保留", "potion table did not load" in options["plan2"]["potion_cost"])
check("751 F13无药整战参考不等于本轮无药", options["plan5"]["potions_used"] == "none" and "later turns: FLEX_POTION" not in options["plan5"]["potion_cost"] and "7/8" in options["plan3"]["potion_cost"])
findings.append({"label": "751 F13药水对照", "decision_reference": ref(rows["decisions"][272361]),
                 "options": {key: options[key] for key in ("plan2", "plan3", "plan5")},
                 "actual_no_drink_branch": None, "actual_keep_to_boss_branch": None})


def state_at(line):
    return rows["states"][line]["row"]["state"]


def poison(state):
    return next(power["amount"] for power in state["combat"]["enemies"][0]["powers"] if power["power_id"] == "POISON_POWER")


a, b = state_at(280160), state_at(280161)
check("YQL末轮残壳毒2到8", [poison(a), poison(b)] == [2, 8])
check("YQL末轮血挡不变", [a["run"]["current_hp"], b["run"]["current_hp"], a["combat"]["player"]["block"], b["combat"]["player"]["block"]] == [26, 26, 13, 13])
check("YQL末轮自爆仍41", all(state["combat"]["enemies"][0]["intents"][0]["damage"] == 41 for state in (a, b)))
check("YQL末轮确为占位体", all(state["combat"]["enemies"][0]["max_hp"] == 999999999 for state in (a, b)))
findings.append({"label": "巨兽残壳用毒", "references": [ref(rows["states"][line]) for line in (280160, 280161)],
                 "poison": [2, 8], "hp": [26, 26], "block": [13, 13], "incoming": [41, 41],
                 "earlier_use_whole_fight_effect": None})

consumed = []
specs = [(274131, 280206, 280207, "ATTACK_POTION", 0), (274156, 280232, 280233, "STABLE_SERUM", 0),
         (274185, 280262, 280263, "SPEED_POTION", 0), (274235, 280313, 280314, "WEAK_POTION", 1),
         (274237, 280315, 280316, "ATTACK_POTION", 0), (274267, 280348, 280349, "GLOWWATER_POTION", 1),
         (274272, 280354, 280355, "SKILL_POTION", 0)]
for decision, before, after, potion_id, slot in specs:
    row = rows["decisions"][decision]["row"]
    old, new = state_at(before), state_at(after)
    get_slot = lambda state: next(p for p in state["run"]["potions"] if p["index"] == slot)
    check("KEN药栏消耗:" + str(decision), get_slot(old)["potion_id"] == potion_id and get_slot(new)["occupied"] is False and row["chosen"]["option_index"] == slot)
    consumed.append({"decision": ref(rows["decisions"][decision]), "states": [ref(rows["states"][before]), ref(rows["states"][after])],
                     "potion_id": potion_id, "slot": slot, "result": row["result"],
                     "full_effect_attribution_certified": None})
check("KEN七次用药且三次pending回执", len(consumed) == 7 and sum("pending" in item["result"] for item in consumed) == 3)
findings.append({"label": "KEN七次药栏消耗", "uses": consumed, "unconsumed_counterfactual": None})

for run_id in ("751FN9QM9MHQ", "KEN58SH9SLZ6", "YQL8RZ8BWN1E"):
    attempts = [item for item in rows["sl-attempts"].values() if item["run_id"] == run_id]
    check(run_id + "六试零胜", len(attempts) == 6 and all(item["row"]["result"] != "won" for item in attempts))

for run_id in ("L9SGRBB5R698", "PU80F84P6HPN", "YQL8RZ8BWN1E"):
    samples = [item for item in rows["sl-attempts"].values() if item["run_id"] == run_id and item["row"]["floor"] == 17 and
               any("/999999999" in turn["enemies"] for turn in item["row"]["summary"]["turns"])]
    check(run_id + "存在本体结束后占位帧", bool(samples))

result = {"checks": checks, "findings": findings,
          "limits": ["实测敌净HP变化不是逐来源毛伤，不能把敌方回血和来源未决项补成已知。", "同指纹局部配对不控制后轮抽牌、选牌与动作。", "消费药栏和pending回执不认证随机选择后的完整候选收益。", "本批未运行新的模拟、生产测试或自然对局消费者。"]}
(HERE / "verified-claims.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"material_checks_passed": len(checks), "findings": [entry["label"] for entry in findings]}, ensure_ascii=False))

import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
import ledger

path = ROOT / 'paper/materials/learning/ledger.jsonl'
updates = [json.loads(line) for line in (HERE / 'ledger-updates.jsonl').open()]
protected = ('claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'status', 'version', 'evidence', 'shipped_at')
before = ledger.fold()
saved = {item['id']: {key: before[item['id']].get(key) for key in protected} for item in updates}
raw = path.read_bytes()
cut = len(raw)
prefix_sha = hashlib.sha256(raw).hexdigest()
(HERE / 'ledger-cli-before.json').write_text(json.dumps({'source_size': cut, 'prefix_sha256': prefix_sha,
                                                       'protected': saved}, ensure_ascii=False, indent=2) + '\n')
command = [sys.executable, str(ROOT / 'learner/ledger.py'), 'update']
result = subprocess.run(command, input=(HERE / 'ledger-updates.jsonl').read_text(), text=True, capture_output=True)
(HERE / 'ledger-cli.log').write_text(result.stdout)
(HERE / 'ledger-cli.stderr').write_text(result.stderr)
(HERE / 'ledger-cli-result.json').write_text(json.dumps({'command': command, 'exit_code': result.returncode}, indent=2) + '\n')
if result.returncode:
    print(result.stderr)
    raise SystemExit(result.returncode)

after = ledger.fold()
raw_after = path.read_bytes()
assert hashlib.sha256(raw_after[:cut]).hexdigest() == prefix_sha
for item in updates:
    actual = after[item['id']]
    assert {key: actual.get(key) for key in protected} == saved[item['id']]
    assert str(HERE / 'proposal.md') in actual['where']['proposal']
    assert str(HERE / 'report.md') in actual['where']['changelog']
    assert item['note'] in actual['notes']

offset = cut
added = []
for line in raw_after[cut:].splitlines(keepends=True):
    row = json.loads(line)
    if row.get('by') == 'learner:strategy-proposal' and '20261017-102830-strategy-proposal' in row.get('note', ''):
        expected = next(item for item in updates if item['id'] == row['id'])
        assert {key: value for key, value in row.items() if key not in ('op', 'ts')} == expected
        added.append({'id': row['id'], 'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest()})
    offset += len(line)
assert len(added) == len(updates) == 16
verification = {'cli_exit_code': result.returncode, 'prefix_bytes': cut, 'prefix_sha256': prefix_sha,
                'old_prefix_unchanged': True, 'all_protected_fields_unchanged': True,
                'no_added_evidence_support_or_repeat': True, 'append_rows': added}
(HERE / 'ledger-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ledger_cli_exit': result.returncode, 'verified_append_rows': len(added),
                  'old_prefix_unchanged': True, 'protected_fields_unchanged': True}, ensure_ascii=False))

# 静默猎手策略学习交付：源码通过验证，live 合入锁阻塞

源码提交 **d959e176af7338ea2bca6f4ff9a39673b80e5fdf**，仅本角色已证“赤牛8活力＋升级串刺支付2”由30伤改为38伤。**未合入 live，待运维接续锁内合入与合后检查；未发布版本、未登记 implemented／shipped。**

基线：**f39a1b8e9678fddee682dcb83b4b1e8675df352e**。源码树：cf071fa0f89ed8439ee7374eb2152466c3f146b4。任务 strategy-proposal／silent，batch=20261017-191302-strategy-proposal。普通派发行 reason=tick，没有 proposal_ids／proposal_repair／research_request／implementation_request；专题不匹配，未承接其他专题。git merge --no-edit main 返回 Already up to date；源码提交后的工作树干净。启动 key 标A11，实际十局均为SILENT A10，未将计划等级当实盘等级。

## 提案与证据

沿原 **silent-proposal-72e0c8b41d2f5ab8** 实现，没有重复建 ID。根 code_proposals.py add 对原 JSON 幂等返回同一 ID，原提案 Markdown／SHA不改；本批具体提案位于同目录 proposal.md。账本 **silent-0504（缺陷）／silent-0505（机制）**，仅通过根 ledger.py 将 observed→proposed、追加本报告／源码链接，没有修改 claim、首证或先验，没有新增独立证据分母。

账本接续保留一次真实拒绝：19:22两条proposed已物理追加，Git仍为observed，提交源码后再次显式写proposed被CLI差异守卫拒绝，exit2／nothing written。保留ledger-source-status-rejected-input.jsonl及ledger-source-status-rejection.txt；随后只追加where／note的源码追溯，不重复写status，CLI exit0，physical保持proposed、不改Git历史或绕守卫。最终本批4条追加各有offset／bytes／SHA，见ledger-own-rows.final.json。

证据为 **J2VR2DFJG8K4，A10，F22，第2／3试 T1**：

|试次|决策原行|状态原行|实际|旧预测|
|---|---|---|---|---|
|2|422361／422362|436637→436638→436639|防御后支付2，串刺+打丝43→5，38伤|30伤、余13|
|3|422375／422376|436651→436652→436653|防御后支付2，串刺+打石48→10，38伤|30伤、余18|

赤牛未熔化，活力8，牌面基础／附魔11、当前19；无玩家虚弱／力量、敌挡／易伤，串刺后能量0且活力消失。第三试原答是丝，SL实际换石，已按真实动作及后继帧核对。两次重试只属于一局；首／末试打24血卵存在伤害封顶，不用于判断30或38。本局所有试次最终失败，没有修后整战收益证据。

共用入口提取八流，选中13,803行：runs10、run-config11、sl-attempts66、run-plans94、states6824、decisions6447、brain351、fight-plans0。所有选中行逐身份／offset／bytes／SHA／原JSON回读核同；六帧固定夹具另逐SHA核原日志。原流 states／decisions／brain各有2条全源无效行，未作为选中证据；fight-plans在本截点选中0不说明原日志缺失。具体冻结边界及逐流SHA见 evidence/evidence-manifest.json、evidence-verification.json，原始关键帧／动作另存 key-frames.evidence.jsonl、key-decisions.evidence.jsonl。只分析所列局面，不宣称十局全部行为已校准。

本项两个修改叶 combat-plan.ts／turn-solver.ts 的基线字节与本局启动7b61eaa对应字节相同；card-model.ts在之后已变化，原运行dirty知识未重建，不冒称整个运行树等于当前源码。完整比较见 source-reference.json。固定真实输入已在当前基线复现旧30与新38。

## 实现与边界

实际改动只有两个生产源码文件及一个固定测试／一份6帧夹具：入口限定角色Silent、真实A10、未熔化AKABEKO；求解器再次限定升级串刺、X费、单体、基础11、19点牌面签名、手动单次支付2、8活力及已证无修饰条件，后段取19，整张消费一次活力。

未匹配的牌、等级、角色、X数与修饰沿旧分支；铁甲入口不置新字段、固定改角色对照保持30。原单击、前置攻击消费活力、后置攻击不再领取活力均已测试。药水、SL、终局政策没有变化。完整Boss构筑模拟没有新置该字段，不宣称整场已校准。其他现有待定提案继续原链；本批仅选择这一项。

预期修正少报8伤及目标余血，可能改变参考排名、护栏或后续选线，不保证胜率；未知组合保持原行为。若未来上线需回退，仅撤本两叶补丁、保知识刷新和全部历史，并按实际行为登记新发布，不整树回退。

## 检查结果

|检查|结果|原件|
|---|---|---|
|初始固定回归|5失败／7通过，核心是期望38、旧算30|regression.before.log|
|修后固定回归|12通过|regression.after.log|
|实际撤回两个源码文件|exit1，5失败／7通过|regression.withdrawn.log|
|恢复原补丁字节|exit0，12通过|regression.restored.log|
|源码及固定输入SHA恢复|全部与完整沙箱输入一致，index树一致|regression-reversal.json、tested-source-inputs.json|
|bash tools/test-sandbox.sh|exit0，生产tsc0，480文件4399项＋paths1文件11项，总481文件4410项通过|source-sandbox.log、source-sandbox.exit.json|
|提交前gitleaks|exit0，扫描442658字节，无泄漏|source-gitleaks-final.log|
|账本检查|506项，0问题；旧物理前缀SHA保持|ledger-check.log、source-commit-validation.json|
|合后检查|未执行，尚未取得合并锁|live-integration.json|

验证不依赖刷新的知识JSON：牌类型取固定夹具，知识文件读取被隔离、怪物数据库固定空，不调LLM／网络／游戏API。初始红、撤修红、恢复绿及所有失败原件均保留。完整沙箱过程中源码与输入未变，撤修恢复后逐SHA相同，因此没有为同一字节重复整套检查。沙箱固定排除项仍待实际合入后由原调度器补完整宿主检查。

## 合入阻塞与运维接续

首次 LOCK_EX|LOCK_NB 取得根 ops/live-merge.lock 返回Errno11／exit75；保留 live-integration.attempt1.json、integrate-live.attempt1.log。第二次有界等待45秒仍Errno11／exit75，见 live-integration.json、integrate-live.attempt2.log。两次均在任何live写入前失败，未提交知识刷新、未改变live源码、未跑合后测试，未新增eval版本／上线记录／规则双通知。源码截至核验不是live祖先。

只读初始合并预检无冲突；这不能代替锁内实际刷新检查。运维应接续**同一源码提交**，在原live锁内等待知识builder、保存当时刷新数据、检查重叠、合入本分支、运行合后沙箱；若失败保刷新数据并回退本次合入。源码已提供同目录 integrate-live.py 接续入口，固定 source 参数为上述40位提交；脚本记录发布名拟用S1.silent-akabeko-skewer1，只有实际合入及合后通过才会写入，尚未分配或生效。统一release_id由ops核实际提交后分配，并经CLI将0504／0505登记shipped；不得借本批源测试冒称合后通过。

原队列ID最终处置 **waiting**：代码及固定验证已就绪，缺实际live祖先与合后检查，不是证据不足；待ops沿原锁续办。不得登记implemented／duplicate或新发布成功。工作树、分支、原日志及所有过程材料保留，不申请已完成合入回收。

运行说明：启动请求实参为gpt-6.1-sol／xhigh／default，保留在runtime-request-metadata.json；本会话没有运行配置切换接口，未宣称已切到用户文字中的high，也未另启动模型。未派下级agent、未推送、未运行play、未读取其他角色知识或游戏二进制。

"""Run the task-authorized locked integration, preserving existing live data and records."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
OUT = Path(__file__).resolve().parent
SOURCE = sys.argv[1]
AUTHOR = 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
result = {'source_commit': SOURCE, 'merged': None, 'tests': None, 'version': None}


def git(*args, check=True):
    process = subprocess.run(['git', '-C', str(LIVE), *args], capture_output=True, text=True)
    if check and process.returncode:
        raise RuntimeError(process.stderr.strip() or process.stdout.strip())
    return process


def save():
    (OUT / 'live-integration.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')


def scan(name):
    with (OUT / name).open('w') as log:
        process = subprocess.run(['nice', '-n', '19', 'gitleaks', 'git', '--staged', '--no-banner', '--redact'],
                                 cwd=LIVE, stdout=log, stderr=subprocess.STDOUT)
    if process.returncode:
        raise RuntimeError('gitleaks failed: ' + name)


try:
    with (ROOT / 'ops/live-merge.lock').open('a') as lock:
        for attempt in range(46):
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if attempt == 45:
                    raise
                time.sleep(1)
        result['lock_acquired'] = True
        save()
        # Follow the supplied builder guard; its PID visibility is limited to this sandbox.
        while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
            time.sleep(10)
        result['builder_guard'] = 'pgrep guard returned clear; sandbox PID visibility only'
        if git('diff', '--cached', '--name-only').stdout.strip():
            raise RuntimeError('live index already has unrelated staged changes')
        if git('ls-files', '-u').stdout.strip():
            raise RuntimeError('live has pre-existing merge conflicts')
        result['initial_head'] = git('rev-parse', 'HEAD').stdout.strip()
        refresh = git('diff', '--name-only', '--', 'knowledge', 'notes/fight-value-backtest.md').stdout.splitlines()
        common = git('merge-base', 'HEAD', SOURCE).stdout.strip()
        incoming = git('diff', '--name-only', common, SOURCE).stdout.splitlines()
        result['refresh_paths'] = refresh
        result['incoming_paths'] = incoming
        result['refresh_overlap'] = sorted(set(refresh) & set(incoming))
        # Save exact unrelated dirty records so abort/rollback cannot silently lose them.
        unrelated = set(git('diff', '--name-only').stdout.splitlines()) - set(refresh)
        unrelated_hashes = {p: hashlib.sha256((LIVE / p).read_bytes()).hexdigest() for p in unrelated if (LIVE / p).is_file()}
        result['unrelated_dirty_sha256'] = unrelated_hashes
        if refresh:
            git('add', '--', 'notes/fight-value-backtest.md', 'knowledge')
            scan('live-refresh-gitleaks.log')
            git('commit', '-m', 'Refresh knowledge data', '-m', AUTHOR)
        result['before_merge'] = git('rev-parse', 'HEAD').stdout.strip()
        save()
        if result['refresh_overlap']:
            raise RuntimeError('refreshed knowledge overlaps the incoming branch; retained refresh and stopped')
        if set(incoming) & set(unrelated):
            raise RuntimeError('incoming paths overlap unrelated live dirty records; stopped')
        preview = git('merge-tree', '--write-tree', 'HEAD', SOURCE, check=False)
        (OUT / 'live-source-merge-preview.txt').write_text(preview.stdout + preview.stderr)
        result['preview_exit'] = preview.returncode
        if preview.returncode:
            raise RuntimeError('source merge preview has conflicts; live source was not modified')
        merge = git('merge', '--no-edit', SOURCE, check=False)
        (OUT / 'live-merge.log').write_text(merge.stdout + merge.stderr)
        if merge.returncode:
            if git('rev-parse', '-q', '--verify', 'MERGE_HEAD', check=False).returncode == 0:
                git('merge', '--abort')
            raise RuntimeError('live merge failed and was aborted')
        result['merged'] = git('rev-parse', 'HEAD').stdout.strip()
        result['source_is_live_ancestor'] = git('merge-base', '--is-ancestor', SOURCE, 'HEAD', check=False).returncode == 0
        save()
        env = dict(os.environ, TMPDIR=str(OUT), PATH=str(Path.home() / '.local/node/bin') + ':' + os.environ['PATH'])
        with (OUT / 'live-sandbox.log').open('w') as log:
            tests = subprocess.run(['bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', env=env,
                                   stdout=log, stderr=subprocess.STDOUT)
        result['tests'] = tests.returncode
        if tests.returncode:
            git('reset', '--merge', result['before_merge'])
            result['rolled_back_merge'] = result['merged']
            result['merged'] = None
            save()
            raise RuntimeError('merged sandbox tests failed; reverted merge while preserving refreshed data')
        if git('rev-parse', 'HEAD').stdout.strip() != result['merged']:
            raise RuntimeError('live HEAD moved unexpectedly during locked verification')
        for path, digest in unrelated_hashes.items():
            if hashlib.sha256((LIVE / path).read_bytes()).hexdigest() != digest:
                raise RuntimeError('unrelated live dirty record changed: ' + path)
        # Gameplay publication is recorded only after actual live merge and successful checks.
        stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
        result['published_at'] = stamp
        name = 'S1.silent-akabeko-skewer1'
        versions_path = LIVE / 'eval/versions.json'
        versions = json.loads(versions_path.read_text())
        if any(entry['name'] == name for entry in versions['versions']):
            raise RuntimeError('version name already exists; leave allocation to ops')
        versions['versions'].append({'name': name, 'family': 'V5', 'character': 'SILENT',
            'commit': result['merged'], 'release_status': 'pending-primary-ops',
            'source': f'{stamp}; learner20261017-191302 source {SOURCE}; original silent-proposal-72e0c8b41d2f5ab8, '
                'ledger silent-0504/0505, J2VR2DFJG8K4 Silent A10 F22 attempts2/3 T1. '
                'Only active Akabeko/upgraded Skewer/8 Vigor/two paid energy/unmodified shown19-base11 signature: '
                '19+11=30 corrected to19x2=38, then Vigor spent once. Actual targets Silk43->5/Rock48->10. '
                'One independent run with two SL attempts; no victory, other-combination, whole-fight calibration or natural benefit claim. '
                'Other roles and unmatched signatures retain prior behavior. Source and merged sandbox passed; fixed12 passed, '
                'withdrawal5 failed/7 passed, restored12 passed. Official release ID/shipped and external full check by ops. '
                'Rollback only this narrow patch in current context; preserve refreshed knowledge and all evidence/history.'})
        versions_path.write_text(json.dumps(versions, ensure_ascii=False, indent=2) + '\n')
        record = (f'\n- {stamp} 静默策略学习者合入限定赤牛活力／升级串刺修正：'
            f'原silent-proposal-72e0c8b41d2f5ab8，账本silent-0504/0505，J2VR2DFJG8K4 A10 F22第2/3试T1；'
            f'源码{SOURCE}，实际live合入{result["merged"]}。仅已证8活力、支付2、基础11/牌面19的无修饰手动双段由30改38，'
            '整张消费一次，铁甲及未知组合保持旧行为。源／合后沙箱0，固定12过，撤源码5败7过／恢复12过；'
            f'版本名{name}，统一release_id由ops核号，未标shipped，不承诺胜率或整场校准。'
            f'提案／证据／测试：{OUT}/proposal.md。\n')
        with (LIVE / 'paper/materials/decision-log.md').open('a') as handle:
            handle.write(record)
        git('add', '--', 'eval/versions.json', 'paper/materials/decision-log.md')
        scan('live-record-gitleaks.log')
        git('commit', '-m', 'Record Silent Akabeko Skewer repair', '-m', AUTHOR)
        result['record_commit'] = git('rev-parse', 'HEAD').stdout.strip()
        result['version'] = name
        result['release_id'] = None
        save()
        # Explicit task-authorized root dual notification, append only.
        stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
        notice = (f'\n- {stamp} 【规则实际上线／请ops核号与shipped】{name}；本批20261017-191302-strategy-proposal。'
            f'源码{SOURCE}，实际live合入{result["merged"]}，记录{result["record_commit"]}。'
            '旧：活力仅首段加回，原组合算19+11=30；新：仅静默A10未熔化赤牛、升级串刺、8活力、手动支付2、'
            '基础11/牌面19及已证无修饰条件算19×2=38，整张仍消费一次，下一攻击不再继承。'
            '证据J2VR2DFJG8K4 F22第2/3试T1，d422361/422362、422375/422376，s436637—639、436651—653；'
            '丝43→5／石48→10，账本silent-0504/0505、原silent-proposal-72e0c8b41d2f5ab8。'
            '预期只修少报8伤及残血，可能改变参考排名；一局两SL不当两个独立样本，不承诺胜率。'
            '铁甲、其他阶/牌/能量/修饰、药水SL和终局策略保持原行为；完整Boss模拟未置新字段，不冒整场校准。'
            '源与实际合后沙箱0、固定12过、撤5败7过/恢复12过，gitleaks0；合后完整宿主检查待原调度器。'
            '回退仅撤本次两个源码叶补丁，保刷新知识、证据及历史，再登记实际新行为号。'
            f'请运维核实际祖先、分配release_id并按CLI登记shipped；报告{OUT}/report.md，提案{OUT}/proposal.md。\n')
        for path in [ROOT / 'notes/for-roy.md', ROOT / 'ops/inbox-dev.md']:
            with path.open('a') as handle:
                handle.write(notice)
        result['root_dual_notice'] = True
        save()
except (OSError, RuntimeError) as error:
    result['error'] = str(error)
    save()
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(75 if isinstance(error, BlockingIOError) else 1)
print(json.dumps(result, ensure_ascii=False))

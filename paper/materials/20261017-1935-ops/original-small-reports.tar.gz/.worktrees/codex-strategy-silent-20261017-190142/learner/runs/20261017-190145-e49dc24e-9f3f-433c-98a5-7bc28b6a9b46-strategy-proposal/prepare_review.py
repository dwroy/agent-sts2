import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WT = OUT.parents[2]
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']
FLOORS = {
    'NHA2KW0RB7VP': [33],
    'P74C04AEPL1F': [17, 22, 23],
    'G33HU22H2543': [31, 33, 48],
    'RC61MFQM63Y6': [17, 33],
    'BTSRF7JL1W1Y': [17, 31],
}


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


extractor = load_module('frozen_extract', WT / 'learner/extract_evidence.py')
resource = load_module('frozen_resource', WT / 'learner/resource_chain.py')
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
validation = []
streams = {}
for item in manifest:
    path = OUT / 'evidence' / (item['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = collections.Counter()
    streams[item['stream']] = {run: [] for run in RUNS}
    with path.open('rb') as handle, (ROOT / 'logs' / (item['stream'] + '.jsonl')).open('rb') as source:
        for encoded in handle:
            digest.update(encoded)
            env = json.loads(encoded)
            assert env['run_id'] in RUNS
            assert env['offset'] + env['bytes'] <= item['source_size']
            source.seek(env['offset'])
            raw = source.read(env['bytes'])
            assert hashlib.sha256(raw).hexdigest() == env['sha256']
            row = json.loads(raw)
            assert row == env['row']
            assert extractor.run_identity(row) == env['run_id']
            counts[env['run_id']] += 1
            streams[item['stream']][env['run_id']].append(env)
    assert digest.hexdigest() == item['output_sha256']
    assert all(counts[run] == item['counts'][run] for run in RUNS)
    validation.append({'stream': item['stream'], 'verified_lines': sum(counts.values()),
                       'source_size': item['source_size'], 'sha256': digest.hexdigest(),
                       'offset_bytes_sha_identity_row_verified': True})
save('evidence-validation.json', validation)


def row_with_reference(env):
    return {**env['row'], '_line': env['line'], '_source_sha256': env['sha256']}


inputs = []
for run in RUNS:
    known = streams['runs'][run]
    assert len(known) == 1 and known[0]['row']['character'] == 'SILENT'
    assert known[0]['row']['ascension'] == 10
    state_env = streams['states'][run]
    states = [row_with_reference(env) for env in state_env]
    for row in states:
        assert row['state']['run_id'] == run
        assert row['state']['run']['character_id'] == 'SILENT'
        assert row['state']['run']['ascension'] == 10
    decisions = []
    exclusions = []
    for env in streams['decisions'][run]:
        row = row_with_reference(env)
        if row.get('floor') not in FLOORS[run]:
            continue
        if not row.get('decision_id'):
            exclusions.append({'line': env['line'], 'reason': '没有 decision_id 的元数据行', 'row': row})
        else:
            decisions.append(row)
    assert decisions == sorted(decisions, key=lambda row: row['observed_ts'])
    assert len({row['decision_id'] for row in decisions}) == len(decisions)
    input_states = [row for row in states if row['state']['run']['floor'] in FLOORS[run]]
    payload = {'run': known[0]['row'], 'decisions': decisions, 'states': input_states}
    save('audit-input-' + run + '.json', payload)
    inputs.append({'run': run, 'floors': FLOORS[run], 'decisions': len(decisions),
                   'states': len(input_states), 'exclusions': exclusions,
                   'input_sha256': hashlib.sha256((OUT / ('audit-input-' + run + '.json')).read_bytes()).hexdigest()})
    starts = {}
    for env in streams['sl-attempts'][run]:
        attempt = env['row']
        if attempt.get('attempt', 1) > 1 and attempt.get('started_at'):
            starts.setdefault(attempt['floor'], []).append(attempt['started_at'])
    chain = resource.resource_chain(states, run, 'silent', starts)
    save('resource-chain-' + run + '.json', chain)
    save('resource-summary-' + run + '.json', {
        'combats': [{k: window.get(k) for k in ['sequence', 'floor', 'entry', 'last', 'exit', 'end', 'observed_net_hp_loss']}
                    for window in chain['combats']],
        'out_of_combat_changes': [event for event in chain['resource_changes'] if event['combat_sequence'] is None],
    })
save('audit-input-manifest.json', inputs)
save('run-source-configs.json', {run: streams['run-config'][run][0]['row']['code'] for run in RUNS})
save('run-identities.json', {run: streams['runs'][run][0] for run in RUNS})

# Keep all source references for the bounded observed windows; no hypothetical branch is filled in.
windows = {
    'NHA2KW0RB7VP': [(283391, 283400), (283493, 283506)],
    'P74C04AEPL1F': [(284626, 284660), (284730, 284761), (284766, 284771), (284807, 284821)],
    'G33HU22H2543': [(284222, 284312)],
    'RC61MFQM63Y6': [(285307, 285323), (285408, 285417), (285486, 285511)],
    'BTSRF7JL1W1Y': [(286148, 286179)],
}
facts = []
for run, spans in windows.items():
    for env in streams['states'][run]:
        if not any(lo <= env['line'] <= hi for lo, hi in spans):
            continue
        state = env['row']['state']
        player = (state.get('combat') or {}).get('player') or {}
        facts.append({'run': run, 'line': env['line'], 'offset': env['offset'], 'bytes': env['bytes'], 'sha256': env['sha256'],
                      'floor': state['run']['floor'], 'turn': state['turn'], 'screen': state['screen'],
                      'hp': state['run']['current_hp'], 'block': player.get('block'), 'energy': player.get('energy'),
                      'player_powers': player.get('powers'), 'potions': state['run'].get('potions'),
                      'hand': [{k: card.get(k) for k in ['index', 'card_id', 'energy_cost', 'resolved_rules_text']}
                               for card in (state.get('combat') or {}).get('hand', [])],
                      'enemies': [{k: enemy.get(k) for k in ['index', 'enemy_id', 'current_hp', 'block', 'powers', 'intents']}
                                  for enemy in (state.get('combat') or {}).get('enemies', [])]})
save('observed-windows.json', facts)
print(json.dumps({'validated_lines': sum(row['verified_lines'] for row in validation), 'inputs': inputs}, ensure_ascii=False))

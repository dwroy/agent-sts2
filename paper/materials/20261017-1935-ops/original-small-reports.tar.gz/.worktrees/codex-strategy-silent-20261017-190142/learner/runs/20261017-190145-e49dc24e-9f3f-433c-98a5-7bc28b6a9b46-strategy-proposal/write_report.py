import hashlib
import json
from pathlib import Path

OUT = Path(__file__).parent.resolve()
BASE = 'f39a1b8e9678fddee682dcb83b4b1e8675df352e'
BATCH = '20261017-190142-strategy-proposal'
PROPS = json.loads((OUT / 'proposals-fold.json').read_text())
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
RESULTS = [
    ('9952ee8e8df9a0fe', 'NHA2KW0RB7VP F33 T1—T4；F24/F27/F32 实际休息',
     'F33前四次可操作首轮均14挡、损1、净扣敌8；第5/6次8挡、损7、净扣24。多16伤也多6血代价，六试没有击杀。F24 18→42、F27 21→45、F32 4→28均实到；不能把未来营火或读档恢复当作当前血量。',
     '当轮差额已有1698adc96ba434a46942321e0237b70657e625b2等live祖先接线；缺同抽序、同预算的整战后继和受控路线/保药对照，不能由即时取舍拟合新SL门槛或终局HP价格。',
     '补同盘原/替线的实际续步、能力建层与完整结局，按原局分组并作时间后置验证；逐来源资源账须由在线消费者读回。'),
    ('47be799a87af03be', 'P74C04AEPL1F F23 第4次 T3',
     'decisions:278542—278546、states:284816—284821：生存者后1血16挡，石16＋卵8；弃精确切击后重问，卵毒后仍2血、玩家0血。原计划零损是有条件预测。首试也弃精确切击但卵已死，第三试原计划不含该牌，均保留作限制。',
     '原计划后继提示与保留手牌快照已有live祖先实现；snapshot明确没有推演弃牌触发、动态牌面、目标和剩血。缺每个合法弃牌分支的已证动态变化与续步核证，不能把快照当完整分支求解或整项duplicate。',
     '冻结精确切击/贪婪两个合法分支的牌面、费用和触发，重算可执行续步；保留全部选项，未实打分支只报模拟与未知，不宣称必胜。'),
    ('3a5274da3c42672a', 'P74C04AEPL1F F17 T1/T2/T8；F22 T1—T6；F23 T1/T3',
     'F17火焰窗口182→181且滑溜8→7；T8无攻击44→21。F22赢战53→9、T2/T4分别损20/24，下战仍9血；寄生复活与主怪最后归零中间帧不可混同。F23石攻击全挡且随后眩晕，卵仍能造成死亡。',
     '当前已有滑溜、逐敌失衡和普通单弃等组件；本批未定位新增确定源码差额。缺F22主怪最后归零中间帧，以及药水/复活/逐敌结算接下一战的联合消费者核证，不能整项标已实现。',
     '补主怪结束与召唤体归属的连续帧，逐来源核火焰、毒、牌挡及遗物消费；固定核末次1血16挡对两敌，另用新局校准。'),
    ('bc4b92d590f2c4ce', 'G33HU22H2543 F48 T1/T8；P74C04AEPL1F F23 T3',
     'G33 decisions:277909首牌余像/闪亮候选分别18/10挡、75/107伤，不能凭相同牌多重集认效果等价。P74弃牌后后继取消与重问可见；候选、派发和完整实际执行分别保留。',
     '投斧首牌身份e784dd9f043bf87c29109573f48975f9903280d3及弃牌事实均为live祖先已有实现；仍缺跨重规划的完整实线归属、余像累计收益和动态弃牌的联合验证，不能用窄修复关闭宽提案。',
     '保持首牌和目标/副本身份；补完整执行前缀、能力实际建层与续步边界，候选累计收益须与实际窗口分账。'),
    ('f52fbbab4dccc3b4', 'G33HU22H2543 F31 T1—T8、F33 T1—T9、F48；P74C04AEPL1F F22—F23',
     '资源消费者读回G33 F31 83→46赢、F33 76→17赢；P74 F22 53→9赢，F23以9入场。赢战实际消耗不能从失败归因中删去；原记录的多次复活/身体新增不等于初末HP净差。',
     '缺完整逐来源资源账的联合在线消费者验收，以及同条件路线、休息、SL、留药的受控后继；观察性连战耗血不足拟合新HP价格或留药阈值。',
     '把开场变化、战内使用、事件付血、真实休息与SL恢复逐项对账，再取得时间后置的同条件后战证据；不预支未抵达营火。'),
    ('10f37c0edd3d24a6', 'G33HU22H2543 F48 T7/T8、F47；P74C04AEPL1F F17 T1/T2/T8、F22/F23',
     'P74 F17临时减力、普通触媒、滑溜和毒端点分别可见：T2力量−6后双击总2；T8 12毒使44→21。F23的一次格挡放大、被动挡和逐敌失衡分源，不把已见局部公式推广到任意组合。',
     'run-config记录五局完整Git源码commit，dirty清单为知识/相关记录；原dirty知识与移动表字节未完整恢复，不能精确复现全输入。多组件联合回放及独立校准仍缺，本批未发现新的确定源码修正。',
     '冻结运行时实际知识/移动输入与各组件时点，按来源和阶段校准；未观察组合保持unknown，局部吻合不外推整战质量。'),
    ('3f82387e2e179703', 'RC61MFQM63Y6 F33 首/末次 T1、第三次 T4',
     'decisions:279021/279197 fingerprint精确相同。实帧首轮16挡/损4/扣敌30，对末次12挡/损8/扣敌23；两线均用同槽格挡药。首题3轮2样本，末题5轮24样本，不能冒充同预算整战比较。普通单弃取消最后转向另有已修根因0268。',
     '即时损4/8、扣30/23已复核且资源差额已有实现；缺同预算整战、累计能力收益、受控后继与独立验证，不能修改全败SL排序或固定优先能力/保血。',
     '同预算保存各样本轨迹、原/替线实际执行与整战后继，已兑现能力收益和当前血价分开；多次SL按一个原局分组。'),
    ('aee21084c991abd3', 'BTSRF7JL1W1Y F31 T1—T4',
     'states:286148—286174显示睡层消失、醒后攻击18→20→22和力量2→4；T3抽弃前decisions:279852与后279854重规划不同。最终所选防御/两小刀线为5轮4样本3胜1死；实T4 14血、5牌挡＋1覆甲对22，需损16而死亡，至少再3血才存活。',
     '缺最终执行线对应的逐样本轨迹和独立校准；原计划在抽弃后已换线，单局3/4样本线发生一次死亡不足证明概率错误，也不能据此改保血权重或强制先杀甲虫。',
     '按执行后盘面配对睡层、力量、临时虚弱与覆甲变化，保存预测样本轨迹并做新局校准；确定数值失配才提最小修正。'),
    ('df37594e9b12debf', 'RC61MFQM63Y6 F17 T11；F33 第三次 T4、首/末次 T1',
     'states:285414—285415生存者前仅它和打击，后手空；45血7挡而火箭57，候选最后打击转向不能执行。首/末次T1的4/8损血及30/23扣敌另核；呼唤手持自损与毒终结顺序保留原证据，未把毒杀当免自损。',
     '普通生存者唯一后继取消bf423c173d3be348a4ad714e1d26516df619ff41已为live祖先，持牌损失也有独立事实路径；跨选择整线归属、累计能力与呼唤联合消费者仍未验收，不能整项duplicate。',
     '从真实选择后手牌重核攻击与朝向，持续能力和持牌自损按实际兑现窗口对账；不复用已取消方案的安全预测。'),
    ('42e81c83b2e1e56b', 'RC61MFQM63Y6 F24/F27/F32；F33 T1—T4',
     'states:285249—285250、285260—285261、285311—285312，三次实际休息20→41、41→62、31→52，各21。F33实际52血入口，与早先路线投影分开；同瓶SL恢复不当新药或真实治疗。',
     '三火合63及52血入口已核；缺同条件路线、休息、后战对照和逐来源消费者验收，不能新增安全血线或终局HP价格。',
     '记录同条件实际后继、真实已完成回复与存档恢复，时间后置验证；仅观察低血与死亡关联不拟合路线禁令。'),
]

proposal_results = []
sections = []
for suffix, evidence, observation, reason, validation in RESULTS:
    pid = 'silent-proposal-' + suffix
    prop = PROPS[pid]
    proposal_results.append({'id': pid, 'state': 'waiting', 'reason': reason})
    sections.append('\n'.join([
        '## ' + pid,
        '',
        '- 主题：' + prop['summary'],
        '- 原提案：`' + prop['proposal'] + '`；原SHA256：`' + prop['proposal_sha256'] + '`；本批逐字节副本：`' + pid + '.md`。',
        '- 原账本：' + '、'.join(prop['ledger']) + '。',
        '- 已核证据局/层/回合：' + evidence + '。',
        '- 本批读回：' + observation,
        '- 处置：**waiting**。' + reason,
        '- 预期行为/下一步验证：' + validation,
        '- 反例及限制：没有本批同盘完整替代胜线；上述已核局部事实不等于整战因果。保持现有排序、药水、SL与终局规则。',
        '- 实现/回退：本批没有新增源码提交、生产变更或需撤销补丁；既有窄修复只是部分覆盖，未把本项标implemented/duplicate/shipped。',
    ]))

header = f'''# 静默猎手策略提案消费：本批十项处置

记录前已运行date：2026-10-17 19:10:25 CST。来源任务与实现任务均为strategy-proposal，本批 `{BATCH}`；授权Roy-2026-10-07-learning。

基线 `{BASE}`。初始git status干净，`git merge --no-edit main`返回Already up to date。本批只处理learn.json明确派发的十个CLI提案ID；没有proposal_repair/research_request/implementation_request，不承接其他请求，不扩队列，不派下级agent。

五局都由runs.jsonl核为SILENT/A10；原提案Markdown逐SHA核同，32个既有账本条目按ID读取并关联如下。只从这些角色内原提案、复盘、账本及本批原始对局取事实，没有重新全量学习、跨角色统计或使用预训练游戏结论。本批没有新代码/知识修改，没有新增代码提案ID；原十项都保留waiting，缺口逐项列明。

旧/新规则：没有生产规则变更。本次交付证据核对和分项处置，不新增自由参数、安全血线、能力优先、药水留用价、SL阈值或终局HP价格。不制造源码提交、eval版本、上线通知或shipped记录。

## 证据与可重现范围

共用extract_evidence.py冻结八流字节截点；`evidence/evidence-manifest.json`保留逐流source_size/计数/输出SHA，每行封套保留原source/line/offset/bytes/SHA/row。`evidence-validation.json`独立seek读回全部6606条，核身份、原JSON、字节数和SHA；冲突身份不能成立，不以正文提及选局。

3238条states、3138条decisions、31条sl-attempts、5条run-config、26条run-plans、163条brain、5条runs。fight-plans在2233957字节截点选中0，仅表示该截点没有匹配身份，不能推断原日志缺失。原全流无效JSON计数states/decisions/brain各2，已由extractor保留统计，不给无效行补身份。

使用当前既有离线消费者`learner/audit-selection.ts`，五份冻结单局输入按原observed_ts顺序、decision_id和状态指纹严格匹配，零元数据行排除。只覆盖下表楼层，不冒充全历史/整局候选认证；未填补旧sl_attempt=null，不创建新身份。另用既有resource_chain函数从全部本批states读回每局资源窗口，未接游戏、LLM、网络或当前刷新的知识JSON。
'''

summary = json.loads((OUT / 'consumer-summary.json').read_text())
table = ['| 局号 | 消费楼层 | 决策/状态 | 片段 | 可核轮端点 |', '|---|---|---:|---:|---:|']
for item in summary:
    table.append(f"| {item['run']} | {','.join(map(str, item['floors']))} | {item['decisions']}/{item['states']} | {item['segments']} | {item['observed_turn_endpoints']} |")
header += '\n' + '\n'.join(table) + '''

五消费者实际退出码均0；合计1126决策、1144状态、242片段、135可核轮端点。`actual_full_candidate_result`非null数量为0，这是消费者的保守认证边界，不能解释成实际从未完成任何候选。原回答、SL替线、一次接口回执、重问后计划和整轮端点不能互相代替。缺口逐项留waiting，不为凑实现改消费者语义。

初算曾把NHA首战初始化帧states:283390（28血，敌血尚未完成开场变化）当作首轮基线，得到不适用的净变化；已按首个可操作帧283391（30血）修正为损1/扣敌8。`paired-turn-facts.initial.json`保留初算，正式值在`paired-turn-facts.json`，没有回写原日志/旧复盘/账本。这是本批分析口径纠正，不是生产代码缺陷或新机制异议。

## 当前源码与已有窄实现

`source-audit.json`冻结本树与实际live快照。live读取时HEAD为`6f2a20594536087c3453fa9076c5908cbec40e40`；17个相关源码叶中14个字节相同，card-model.ts、sl/explore.ts、sl/controller.ts三叶的差异逐patch保存，仅既有Roy/Dai注释署名不同。没有整树同步或覆盖live。

- `e784dd9f043bf87c29109573f48975f9903280d3`：静默A10投斧首牌身份，含首个非药水卡牌、后继、缺失前缀和旧键边界；已核为本基线和实际live祖先。
- `bf423c173d3be348a4ad714e1d26516df619ff41`：普通生存者无绷带时唯一剩余牌也消费单弃，多选保留未确定边界；已核为两树祖先。
- `1698adc96ba434a46942321e0237b70657e625b2`：静默SL当轮资源比较与预测限定；已核为两树祖先，不证明整战能力收益或新排序已验证。
- 当前`selection.ts`保留原方案后继及其条件，`silent-discard-facts.ts`明说仅投影当前手牌，不推演弃牌触发/后续伤害/格挡/剩血；`silent-selection-audit.ts`与dispatch receipt分开记录预测和一次派发，actual_turn仍未知。源码存在这些事实通道不等于完整提案被消费者验收。

五局run-config均保存完整40位Git源码commit及dirty清单，详见`run-source-configs.json`。清单所列是知识与相关记录，没有据此伪造源码缺失；但清单不是当时dirty字节快照，移动表/知识等完整运行输入未恢复。当前模型的吻合或已有修复不得倒写为旧运行树已正确，也不借当前live或历史完整测试证明本批新实现。

全部原proposal_sha、原始证据、消费者输入/输出SHA、源叶blob/SHA和窄提交祖先布尔均留scratch。不归档展开整个仓库，不覆盖旧报告或零行抽取初稿。
'''

footer = '''

## 验证、登记与交接

本次只做上述证据机械核验、五个既有离线执行消费者读回、资源链读回与源码定位。没有新增/修改生产源码、任务模板或经验库，因此没有运行tsc/vitest，没有撤源码失败/恢复通过实验；这些项目均为不适用，JSON三项tests均为null。消费者退出0不冒充生产测试通过、独立科学校准或自然胜率收益。

没有Git新提交、live合入、eval版本或规则上线，不标implemented/duplicate/shipped，不启动play或调整运行中的对局。原账本/提案状态与原证据全部保留；本批没有新增游戏结论、支持/反例、账本ID或证据角色分母，故未重复追加发现、降级既有shipped条目或重复CLI建ID。32个原账本与十个原CLI ID的处置链接已在本proposal中逐项保存，由原调度完成事件消费proposal_results；等待状态不关闭父学习要求。

原任务要求的status=proposed适用于新增发现/提案，本批没有新增发现；不能为一份复核报告将既有shipped经验覆盖成proposed。没有新科学异议或反证需要另行通知；既有未知与初算修正都明确留档。

本批proposal交接路径即同目录proposal.md，report为同目录report.md。运行资料仍待后续实际证据与消费者验收，不手删工作树/原日志/经验/账本，也不代其他角色确认。gitleaks与最终零差异核验结果另存final-verification.json；不提交/推送。下次重派应补各项具体缺失字段，不将五局旧SL扩作独立新样本。
'''

(OUT / 'proposal.md').write_text(header + '\n\n'.join(sections) + footer)
result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
    'base': BASE, 'runs': DISPATCH['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': DISPATCH['proposal_ids'], 'implementation_domains': [],
    'proposal_results': proposal_results, 'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'proposal-results.json').write_text(json.dumps(proposal_results, ensure_ascii=False, indent=2) + '\n')
(OUT / 'report.md').write_text(
    '# 静默猎手本批策略报告\n\n'
    '十项均waiting：已有窄修复及事实通道已核实际live祖先，但完整分支、整战后继与独立校准不足；未定位新的确定源码差额，未修改生产策略。\n\n'
    '完整逐项证据、账本、反例、预期行为、验证和回退见[proposal.md](proposal.md)。该文件是本报告组成部分，原十份Markdown另存同目录并逐SHA核同。\n\n'
    f'- base：`{BASE}`；HEAD保持；初始与最终工作树检查分别落盘。\n'
    '- 证据：本批五局均Silent A10；八流6606引用逐offset/bytes/SHA/身份核；五消费者0，仅覆盖列明楼层。\n'
    '- 消费者：1126决策/1144状态、242片段/135轮端点；完整候选认证0；不填SL身份、不虚构实线或概率校准。\n'
    '- 源码/知识修改：无。新提交：无。撤源码失败/恢复通过：不适用。tsc/vitest/cases：null/null/null。live合入/新版本：无。\n'
    '- 既有源码：投斧身份e784dd9f043bf87c29109573f48975f9903280d3、普通单弃bf423c173d3be348a4ad714e1d26516df619ff41、资源比较1698adc96ba434a46942321e0237b70657e625b2均为实际live祖先；不将宽提案整项关单。\n'
    '- 原账本/队列未直接修改，未新增提案ID、重复支持、shipped或上线通知。新结论入库与消费者采用未冒称完成。\n\n'
    '```json\n' + json.dumps(result, ensure_ascii=False, indent=2) + '\n```\n')
print(json.dumps({'report': result['report'], 'proposal': str(OUT / 'proposal.md'), 'results': len(proposal_results),
                  'proposal_sha256': hashlib.sha256((OUT / 'proposal.md').read_bytes()).hexdigest()}, ensure_ascii=False))

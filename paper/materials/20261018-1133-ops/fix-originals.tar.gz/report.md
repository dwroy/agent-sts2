## 修 bug 回报
- 合并基线：main → 92024e9e266ee78e29d9909029971f320bb122fe
- 修复（每条一行）：h1-budget-completion-health-contract：R394 indifferent停止标记被健康监测误报为错误 — 5011b4cbda9a9056a1fd146e375e3cd67b60c0a9 — 测试 agent/tests/adaptive_health_test.py:AdaptiveHealth.test_r394_indifferent_eight_original_records_preserve_actual_work_and_unknown_agreement — 去掉修复时失败：是；证据 ET1QAZCV8GUP/A11 F4拿牌、F17 T2—T7（T6两题），8原行offset/bytes/SHA逐条核回；bug-infra按indifferent/h1-budget/局号检索无对应项，不新建账本。
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb9be14d620b368ec46974c1b57901ca
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0b758a1a5e7d591745694004664f83a
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb61eef226eb7366f9612003480c83988
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7524bbb8e80a975f204f8d193657b46
- 已被别人修掉的：空产出补链误派 — 84366ad06ee4f978394c1b9489a82c83ea12bd36
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a826e94f9708af4b1a265e1892659f4e
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f
- 已被别人修掉的：纸鹤夹具 — befc39e5ca0105f8ff96d47f817df44f0b2760f1
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e5a0f234f082972d21b203dbf8229d7
- 已被别人修掉的：共享main启动冲突 — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2
- 已被别人修掉的：根事件通知路径 — 577f0bc424b7287910735cfdc86c253cc7ee8057
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe043cb8738cce57870354fa23fa84a1
- 已被别人修掉的：局间quiet误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d
- 已被别人修掉的：global-health异步测试 — d27df54f0651c4af84c6c12ceceec82a016f1142
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径已另修） — 83a7f796c24eea8f16eb317bc70bfd832251ad27
- 已被别人修掉的：retention数字UUID — d91236326bc1af7a5417ce016c1a182f8084e7a3
- 已被别人修掉的：retention旧根scratch — 0699b05c436d3d51d00ee92f153d16d16e64bea4
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec5fc6eafe576a1296bbdadde43432ee
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ceeb81d534159b3516458521ad09bbed
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a5168d1a8cb456aed1c926b2d1b6c4488
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b7913a53b9e2645f40db1657eb5213c
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb12a1d4b2f34ee767bb2816a3a0b466
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537
- 已被别人修掉的：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70bfb2a91138ede0e1f6046927c116a4
- 已被别人修掉的：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66bd75c6d6952772dcf712399eda828b
- 已被别人修掉的：infra-test-rollout-ties-host-timeout-15000 — da08fcead2025c293140f1ba103d8efdbd39a4c3
- 已被别人修掉的：infra-test-build-facts-selection-remove-latency — e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0
- 已被别人修掉的：h1-budget-completion-health-contract — c40e43fd25c200a01f4da94a4dac8db1b34664a8
- 已被别人修掉的：h1-strict-pick-deadline-stall — b3b9734d85defbdbd1b73ab85fab9ea2f636affd
- 已被别人修掉的：selection-hidden-daggers-conditional-followup-readback — a473263eb35ce5bea8e06f1ee94f4da1ba880bc3
- 已被别人修掉的：silent-0338：末挡诊断漏列既有奥利哈钢 — c1d84804956bedbd29a7f0e81294114e18415b9d
- 已被别人修掉的：silent-0272：商店移除预判误报不可选 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26
- 已被别人修掉的：silent-0367：构筑事实未传已用尾巴状态 — 5baf663d7e6678efa3690e5a48329c4f8baee109
- 已被别人修掉的：h1-b2-margin-sample-identity（已发布V5-R384） — 660b194c950f017e356a4b3da952e127c7e5c768
- 已被别人修掉的：silent-vigor-skewer-J2VR：赤牛活力与串刺两段伤害（J2VR2DFJG8K4 A10 F22第2/3试T1，silent-0504/0505，V5-R387） — d959e176af7338ea2bca6f4ff9a39673b80e5fdf
- 已被别人修掉的：U5W7NUE925NK/H1/G2预算到期诊断及零样本前缀（已实际合入；原F15/F16完整根因仍未知） — 0b1807b159a1e3d7fc09aad541ea6f97be627a91
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval固定历史发布表夹具 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7
- 已被别人修掉的：host-fixed-test-timeouts-010547：F45固定工作时钟与采样夹具 — 9e8c93555131c3347f9e809d9722a848a75c2692
- 已被别人修掉的：ops-learner-recheck-report-fixes-shape-20261018：描述型fixes格式兼容子项 — 4c16dab0457a61e22ef06b27e367d146cb99bab3
- 已被别人修掉的：infra-h0-414-host-fixed-test-stability-20261018：Codex stall固定时间/rollout固定回执（main已集成原031302六测试叶） — 738433d865d943e80b7726588fa2bbeb3a1980da
- 已被别人修掉的：router-timeout-max-gap-76fe29f3：按实际事件及结束时间精确验证最大间隔 — a6913706952661afe1de38f290cd9434cbb91621
- 已被别人修掉的：read_report文件句柄释放 — 9aec57cd7bf8d6c5f67bdaa6b5b9bc115df73239
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：普通通知ACK不再误查学习父要求 — 672e198a4730012330f599068a0ef1efadb02002
- 已被别人修掉的：infra-legacy-continuation-notice-ack-identity：原续跑通知身份桥 — 368fccabd42eb72ffcea9a2fe6cbbb7c149326be
- 已被别人修掉的：strategy-proposal无源码报告scratch归属 — 5f04139cefe5c651dd5bf62f7e164014dbf5f23b
- 已被别人修掉的：silent-0459：独立run-plan请求费用归集 — 799a5cd0caf9329b43c32376079218a9bd0c3e9e
- 已被别人修掉的：postmortem-capacity-failure-proposal-repair-20261013：无输出失败不误派补链 — 3fdcd77927f01b35c20c6c5c1fcfd790676032d2
- 已被别人修掉的：codex-brain-cache-probe固定工具使用隔离home — 548b53ca211231ab5f1079a16fe9ad65f62b3c6c
- 已被别人修掉的：TMPDIR未设置时的订阅采样固定测试 — 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a
- 已被别人修掉的：21bf固定测试链：fake herdr未回收的已退出进程误判忙碌 — 707702873705b81219a23915f4981060cfafff2e
- 已被别人修掉的：silent-0040：boss统计按最终SL尝试分组 — 3f40af6fffbb37a06e258c0e4b314a9fe8faaede
- 已被别人修掉的：学习账本追加式来源元数据更正 — 87c89b7aea90c7275e0fbb04b1e4148a4209630c
- 已被别人修掉的：单次mod超时恢复后的stall误报 — a4f4ec868d122dc92af510862c6240cf2eaff2b6
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（0256/0260/0263/0266/0308/0311/0317/0319/0320/0322/0324/0329/0334/0339/0344/0347/0349/0362/0365/0481/0487，另含XTSV1U9JD34T终局与GXNKW8X1XYJP抽牌身份） — 策略类；沿已有独立strategy-proposal链处理，不重复派发或补入开发者游戏知识。
- 没修的：silent-0339续证：BXU0CKWKH2RU尾巴误核销 — 策略类；已有58ab473f6c814061/c232010cd405fe44原提案链，保留当前行为和原证据。
- 没修的：silent-0332 nonpositive-hp实际资源契约根因 — 证据不足；原专用owner链仍未闭环，诊断及样本身份窄修不等于根因修复。
- 没修的：U5W7NUE925NK F15/F16两次原G2缺DPR告警的完整根因 — 证据不足；原未来样本数组及配对DPR分母未保存，此前窄修只覆盖有固定复现的严格零前缀边界，不将其冒作两次实盘根因。
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；已有启动恢复/租约/回收窄修，目录删除归属与上游时序未确定。
- 没修的：arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression及调度公平性调查 — 独立架构、策略或归因任务，范围太大，超出普通纯bug批次。
- 没修的：core-build-notify-222802-rc2旧原生通知恢复 — 证据不足；stderr持久化已修，旧送达状态未证，不重发可能已送达的通知。
- 没修的：Codex缓存实测、DPR/B2性能及历史宿主超时根因 — 证据不足或独立性能调查；固定测试确定性子项已修，不代表自然性能根因已解决。
- 没修的：原20261018-011241报告的recheck接续 — 证据不足；沿上批固定核验，原源码不是所报提交祖先，输出缺base/runs、Markdown无机器JSON。保留原报告与身份守卫，本批不重做该接续协议。
- 没修的：ops-learner-recheck-report-fixes-shape-20261018补证：窄cherry-pick提案验收 — 太大：原Markdown没有机器JSON、原输出缺runs/base；独立原注册/原报告/六叶源码及发布/真实宿主回执协议超出本批格式修复。不造祖先、不改原报告/提案ID/seen_runs/租约或ACK，保留pending。
- 没修的：infra-h0-414-host-fixed-test-stability-20261018 的生产性能及原full1归因 — 证据不足；已合入的固定测试修复不证明CPU或产品性能根因已解决，保留原失败历史。
- 没修的：silent-0461：9W38TRGPJW9Q F17T10普通斗篷及0511/0512药水窗口补证 — 策略类；先前批次已收到05:16:47追加的旧项证据，沿既有f4eb/7338、c440ae480782dca0和c734f60b55906bae独立策略链，不重复实现或添加机制。
- 没修的：infra-paper-dataset-concurrent-gzip-keyscan-20261018 — 已有原owner已测源码dee6386621e8122d123a3cd0017c3e4c199f524e，当前main基线及只读核得live均未包含；队列明确禁止重复实现，保留原ops运输链，不复制源码或另造提交。
- 没修的：infra-h0-414-host-fixed-test-stability-20261018 / a406-fixed-deadlines 五处消费夹具边界 — 已有原批已测源码2a778b13ac1ead79afef957d4708c1df5dfd3757，当前main基线及只读核得live均未包含；沿原ops pending集成，不盲目叠加。read_report文件关闭缺陷9aec57cd7已在本次基线，无新增代码。
- 没修的：21bf-fake-herdr-workspace-deadline及原完整宿主超时根因 — 证据不足；fake herdr未回收退出进程误判已由707702873705b81219a23915f4981060cfafff2e修复并纳入基线，但原15秒宿主超时及CPU/产品/调度因果未证，保留原full1，不重复原补验或修改断言。
- 没修的：infra-chest-claimed-action-conflict-0516：claimed与领取动作矛盾 — 证据不足；队列及上批固定取证缺领取请求和有界确认契约。原结构提案silent-proposal-cf77920511042e9c沿既有strategy-proposal链核实，本批不重复派发或添加游戏判断。
- 测试：tsc退出码0；沙箱Vitest 493文件 / 4463用例 / 退出码0（492/4452 + paths 1/11），完整入口无失败重跑。Python7项恢复后0；仅撤源码时exit1、9个子断言失败，8原行均复现误报；定向Vitest1文件1项0（包装Python，不重复计入套件总数）。初稿固定停止数期望44误写，按原夹具实际46校正，原1失败日志保留。23原监测行读回observed23/produced15→23/errors8→0，complete_adaptive4→12，budget partial11及unknown11保持，agreement仍null；原告警未改写。源码及原始八行gitleaks均0。
- 合入：未合入；源工作区干净。原live b155d00a36080418149e63d2f21b491d34d7f40a；锁内先提交10项知识刷新 bc375c779f917b3d8d8a5ea25f3630ae07e4fb61（gitleaks0），随后merge-tree预检发现14处冲突，exit77即停，未开始实际合并、未覆盖刷新数据。冲突：eval/versions.json、knowledge/characters/silent/boss-damage.json、knowledge/characters/silent/construction-opportunities.json、knowledge/characters/silent/fight-value-gates.json、knowledge/characters/silent/fight-value.json、knowledge/characters/silent/monster-records.json、knowledge/characters/silent/outcome-stats.json、knowledge/characters/silent/room-costs.json、knowledge/common/card-upgrades.json、knowledge/common/monster-db.json、knowledge/common/move-model.json、notes/fight-value-backtest-silent.md、notes/monster-db-check.md、paper/materials/decision-log.md。live无MERGE_HEAD、无未合路径或暂存内容，两份原有notes刷新保持未提交；未跑合后测试，未写上线decision-log、eval版本或shipped，实际源提交不在live祖先。由原完成事件交ops兜底集成，不自行叠加历史源或清理现场。
- 需要 Roy 定的事：无。

```json
{
  "task": "fix-batch",
  "base": "92024e9e266ee78e29d9909029971f320bb122fe",
  "fixes": [
    {
      "item": "h1-budget-completion-health-contract：R394 indifferent停止标记被健康监测误报为错误",
      "commit": "5011b4cbda9a9056a1fd146e375e3cd67b60c0a9",
      "test": "agent/tests/adaptive_health_test.py",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（0256/0260/0263/0266/0308/0311/0317/0319/0320/0322/0324/0329/0334/0339/0344/0347/0349/0362/0365/0481/0487，另含XTSV1U9JD34T终局与GXNKW8X1XYJP抽牌身份）",
      "reason": "策略类；沿已有独立strategy-proposal链处理，不重复派发或补入开发者游戏知识。"
    },
    {
      "item": "silent-0339续证：BXU0CKWKH2RU尾巴误核销",
      "reason": "策略类；已有58ab473f6c814061/c232010cd405fe44原提案链，保留当前行为和原证据。"
    },
    {
      "item": "silent-0332 nonpositive-hp实际资源契约根因",
      "reason": "证据不足；原专用owner链仍未闭环，诊断及样本身份窄修不等于根因修复。"
    },
    {
      "item": "U5W7NUE925NK F15/F16两次原G2缺DPR告警的完整根因",
      "reason": "证据不足；原未来样本数组及配对DPR分母未保存，此前窄修只覆盖有固定复现的严格零前缀边界，不将其冒作两次实盘根因。"
    },
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；已有启动恢复/租约/回收窄修，目录删除归属与上游时序未确定。"
    },
    {
      "item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression及调度公平性调查",
      "reason": "独立架构、策略或归因任务，范围太大，超出普通纯bug批次。"
    },
    {
      "item": "core-build-notify-222802-rc2旧原生通知恢复",
      "reason": "证据不足；stderr持久化已修，旧送达状态未证，不重发可能已送达的通知。"
    },
    {
      "item": "Codex缓存实测、DPR/B2性能及历史宿主超时根因",
      "reason": "证据不足或独立性能调查；固定测试确定性子项已修，不代表自然性能根因已解决。"
    },
    {
      "item": "原20261018-011241报告的recheck接续",
      "reason": "证据不足；沿上批固定核验，原源码不是所报提交祖先，输出缺base/runs、Markdown无机器JSON。保留原报告与身份守卫，本批不重做该接续协议。"
    },
    {
      "item": "ops-learner-recheck-report-fixes-shape-20261018补证：窄cherry-pick提案验收",
      "reason": "太大：原Markdown没有机器JSON、原输出缺runs/base；独立原注册/原报告/六叶源码及发布/真实宿主回执协议超出本批格式修复。不造祖先、不改原报告/提案ID/seen_runs/租约或ACK，保留pending。"
    },
    {
      "item": "infra-h0-414-host-fixed-test-stability-20261018 的生产性能及原full1归因",
      "reason": "证据不足；已合入的固定测试修复不证明CPU或产品性能根因已解决，保留原失败历史。"
    },
    {
      "item": "silent-0461：9W38TRGPJW9Q F17T10普通斗篷及0511/0512药水窗口补证",
      "reason": "策略类；先前批次已收到05:16:47追加的旧项证据，沿既有f4eb/7338、c440ae480782dca0和c734f60b55906bae独立策略链，不重复实现或添加机制。"
    },
    {
      "item": "infra-paper-dataset-concurrent-gzip-keyscan-20261018",
      "reason": "已有原owner已测源码dee6386621e8122d123a3cd0017c3e4c199f524e，当前main基线及只读核得live均未包含；队列明确禁止重复实现，保留原ops运输链，不复制源码或另造提交。"
    },
    {
      "item": "infra-h0-414-host-fixed-test-stability-20261018 / a406-fixed-deadlines 五处消费夹具边界",
      "reason": "已有原批已测源码2a778b13ac1ead79afef957d4708c1df5dfd3757，当前main基线及只读核得live均未包含；沿原ops pending集成，不盲目叠加。read_report文件关闭缺陷9aec57cd7已在本次基线，无新增代码。"
    },
    {
      "item": "21bf-fake-herdr-workspace-deadline及原完整宿主超时根因",
      "reason": "证据不足；fake herdr未回收退出进程误判已由707702873705b81219a23915f4981060cfafff2e修复并纳入基线，但原15秒宿主超时及CPU/产品/调度因果未证，保留原full1，不重复原补验或修改断言。"
    },
    {
      "item": "infra-chest-claimed-action-conflict-0516：claimed与领取动作矛盾",
      "reason": "证据不足；队列及上批固定取证缺领取请求和有界确认契约。原结构提案silent-proposal-cf77920511042e9c沿既有strategy-proposal链核实，本批不重复派发或添加游戏判断。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4463
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261018-110259-5792e43b-7ed3-447e-94aa-2879edd38f81-fix-batch/report.md"
}
```

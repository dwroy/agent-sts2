from pathlib import Path
import json,hashlib,subprocess,sys,tarfile,importlib.util
sys.dont_write_bytecode=True
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-2111';pub=r/'paper/materials/20261015-2111-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def load(f):return json.loads(f.read_text())
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
readback=load(pub/'postmortem-readback.json');report=readback['original_report'];s=Path(report['report']).parent;runs=report['appended'];refs=[];counts={};brains={};configs={};invalid=[]
for run in runs:
 counts[run]={};brains[run]=[];configs[run]=[]
 for stream in ['states','decisions','sl-attempts','run-config','run-plans','brain']:
  count=0
  with (r/'logs'/(stream+'.jsonl')).open('rb') as original,(s/(run+'-'+stream+'.jsonl')).open() as frozen:
   for text in frozen:
    e=json.loads(text);original.seek(e['offset']);raw=original.readline();row=json.loads(raw);assert row==e['row'];fp=row.get('fingerprint') or {};fp=json.loads(fp) if isinstance(fp,str) else fp
    state=row.get('state') or {};sr=state.get('run') or {};ids=[x for x in [row.get('run_id'),row.get('run') if isinstance(row.get('run'),str) else None,state.get('run_id'),sr.get('run_id') if isinstance(sr,dict) else None,fp.get('run') if isinstance(fp,dict) else None] if x is not None]
    assert ids and all(x==run for x in ids),(stream,run,e['line'],ids)
    if stream=='states':assert state['run']['character_id']=='SILENT' and state['run']['ascension']==10
    if stream=='brain':
     assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains[run].append(row)
    if stream=='run-config':configs[run].append(row)
    refs.append({'run':run,'stream':stream,'line':e['line'],'offset':e['offset'],'bytes':len(raw),'sha256':sha(raw)});count+=1
  counts[run][stream]=count
 assert len(configs[run])==1 and configs[run][0]['loop']['s_build_rank']==configs[run][0]['loop']['sim_adaptive']=='on'
assert counts['RQCHNN0W72KF']['decisions']==772 and len(brains['RQCHNN0W72KF'])==53
original_runs={}
with (r/'logs/runs.jsonl').open('rb') as f:
 offset=0
 for number,raw in enumerate(f,1):
  x=json.loads(raw)
  if x.get('run_id') in runs:assert x['character']=='SILENT' and x['ascension']==10 and x['floor']==49 and x['victory'] is False;original_runs[x['run_id']]={'row':x,'line':number,'offset':offset,'bytes':len(raw),'sha256':sha(raw)}
  offset+=len(raw)
assert set(original_runs)==set(runs)
numbers=load(s/'verified-numbers.json')
for run in runs:
 assert numbers[run]['verified'] and sha((s/(run+'-section.md')).read_bytes())==numbers[run]['section_sha256']
 for x in numbers[run]['key_frames']:
  with (r/'logs/states.jsonl').open('rb') as f:f.seek(x['offset']);row=json.loads(f.readline())
  state=row['state'];player=(state.get('combat') or {}).get('player') or {};assert state['run']['current_hp']==x['hp'] and state['run']['max_hp']==x['max_hp'] and player.get('block')==x['block']
source=load(s/'source-references.json')
for leaf,h in source['leaves'].items():
 assert sha(git('show',source['live_commit']+':'+leaf))==h
 for run in runs:assert sha(git('show',configs[run][0]['code']['commit']+':'+leaf))==h
owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('by')=='learner:postmortem' and (any(x.get('run') in runs for x in row.get('evidence',[])) or str(s) in json.dumps(row,ensure_ascii=False)):
  assert row['id'] in report['ledger']['added']+report['ledger']['updated']
  if row['op']=='update':assert set(row)<={'op','id','ts','by','evidence','where','note'}
  assert all(x['run'] in runs and x['role']==('repeat' if row['id']=='silent-0332' else 'support') for x in row.get('evidence',[]));owned.append(raw)
assert len(owned)==25 and sum(json.loads(x)['op']=='add' for x in owned)==1 and sum('evidence' in json.loads(x) for x in owned)==13
assert json.loads(next(x for x in owned if json.loads(x)['op']=='add'))['id']=='silent-0485'
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned))
spec=importlib.util.spec_from_file_location('original_code_proposals',r/'learner/code_proposals.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);queue=mod.fold(r/'paper/materials/learning/code-proposals.jsonl');proposals=[]
for ident,run in zip(report['code_proposals'],runs):
 q=queue[ident];assert q['character']=='silent' and q['runs']==[run] and q['source_task']=='postmortem' and q['target_task']=='strategy-proposal' and sha(Path(q['proposal']).read_bytes())==q['proposal_sha256'];proposals.append({k:q.get(k) for k in ['id','state','proposal','proposal_sha256','ledger','implemented_commit']})
assert load(s/'final-audit.json')['ledger_check']==0
readback.update(ops_readback_guard_correction='Initial guard incorrectly read state.player; actual HP is state.run and block is state.combat.player. Original failing guard/log retained, no data or producer changed.',byte_stream_audit='complete; original offset rows parsed equal, explicit identity verified, original line bytes/SHA now frozen by ops',stream_counts=counts,original_rows_checked=sum(sum(x.values()) for x in counts.values()),actual_accepted_codex={run:len(brains[run]) for run in runs},actual_run_config={run:{'code':configs[run][0]['code'],'brain':configs[run][0]['brain'],'loop':configs[run][0]['loop']} for run in runs},original_run_rows=original_runs,original_key_number_verification=numbers,three_source_leaves_same_at_each_native_run_base=source,original_ledger_rows=25,evidence_bearing_rows=13,trace_only_proposal_links=12,original_proposals=proposals,original_failure_preserved='First draft used snake_case for camelCase brain usage and divided by zero before appending lessons; exception hook also encountered own inspect.py shadowing stdlib. Own scratch module renamed, draft healing/exit/block-source counts corrected before append; original initial scripts/report/failure retained. No product change or repeated learner.',limits='Gross damage/overkill, early SL exit frames, full fault resources/steps, boss clocks, pure combat times, Jev cache/paid invoices, dirty knowledge and controlled counterfactuals remain unrecorded. RQ prior session-start failure remains history; new completed postmortem does not overwrite it. Descriptive on-mode defeats are not model calibration or benefit proof.')
write(pub/'postmortem-readback.json',readback);write(pub/'postmortem-original-references.json',refs)
files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<300000 and f.suffix in ['.json','.jsonl','.md','.py','.txt','.out','.err','.patch'] and not f.name.startswith(('ledger-before','ledger-after','ledger-','RQCHNN0W72KF-ledger-final','VNSXWCWXR3VW-ledger-final'))]
files+=[r/'ops/codex-ops/learner'/('20261015-204301'+ext) for ext in ['.out','.err']];manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted(files):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);manifest.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',manifest)
print(json.dumps({'rows':readback['original_rows_checked'],'counts':counts,'brains':readback['actual_accepted_codex'],'ledger_rows':25,'new_mechanic':'silent-0485','new_bug':False}))

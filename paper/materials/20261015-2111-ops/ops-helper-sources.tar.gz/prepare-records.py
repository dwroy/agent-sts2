from pathlib import Path
import json,hashlib,subprocess,csv,re,importlib.util,os,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-2111';pub=r/'paper/materials/20261015-2111-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json');assert result['actual_exit_code']==0 and result['calls']==1
log=(pub/'paper-dataset.log').read_text();assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')};store=p/'paper-owned';store.mkdir(exist_ok=True);outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file():continue
 raw=f.read_bytes();path=str(f.relative_to(r));h=sha(raw)
 if path in before and h==before[path]['sha256']:continue
 name=path.replace('/','--');(store/name).write_bytes(raw);outputs.append({'path':path,'bytes':len(raw),'sha256':h,'snapshot':name})
write(p/'paper-owned-manifest.json',outputs);by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes();assert sha(raw)==by[path]['sha256'];return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json'));verification=json.loads(frozen('paper/data/verification.json'));checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}
assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1);assert summary['generated_at']==cut
runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines()));selected={x['run_id']:x for x in runs if x['run_id'] in ['RQCHNN0W72KF','VNSXWCWXR3VW']};assert len(selected)==2
for run,n,answers in [('RQCHNN0W72KF','772',53),('VNSXWCWXR3VW','810',49)]:
 row=selected[run];assert all(row[k]==v for k,v in {'character':'SILENT','ascension':'10','outcome':'defeat','floor_max':'49','n_decisions':n,'has_postmortem':'1','performance_included':'1'}.items());brain=json.loads(row['brain_source']);assert brain['eligible'] is True and brain['successful_answers']=={'codex':answers} and brain['failed_or_unaccepted_rows']==0
snap={'request':result,'generated_at':cut,'source_cut_bytes':summary['source_cut_bytes'],'five_checks':checks,'source_checks_passed':True,'row_counts':verification['row_counts'],'total_decision_records':summary['decisions']['play_total']+summary['decisions']['shadow'],'original_count_warnings':verification['checks']['runs.jsonl decision-count mismatches'],'runs':{run:{k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']} for run,row in selected.items()},'stage_boundary':'Two descriptive on-mode defeats, not causal V5-S improvement or production model calibration. Original RQ startup failure retained; current postmortems completed.','changed_outputs':outputs,'component_costs':'Separate immutable byte cuts and estimates, not invoice or credit conversion.','raw_snapshot':False,'previous_outputs_preserved':str((p/'paper-before').relative_to(r))};write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip();old=git('show',base+':paper/materials/learning/ledger.jsonl');rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True);assert len(rows)==25;seen=set(old.splitlines());added=b''.join(x for x in rows if x.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);bf=fold(old);af=fold(old+added);assert set(af)==set(bf)|{'silent-0485'}
for ident in bf:
 for k in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']:assert bf[ident].get(k)==af[ident].get(k),(ident,k)
 prior=bf[ident].get('evidence',[]);later=af[ident].get('evidence',[]);assert later[:len(prior)]==prior
 assert all(x['run'] in selected and x['role']==('repeat' if ident=='silent-0332' else 'support') for x in later[len(prior):])
assert af['silent-0485']['status']=='observed' and af['silent-0485']['prior']=='unknown' and af['silent-0485']['first_run']=='RQCHNN0W72KF' and af['silent-0485']['asc']==10
lessons=(p/'owned-lessons.md').read_bytes();oldlesson=git('show',base+':notes/lessons.md');assert len(lessons)==38315 and all(('## '+run).encode() not in oldlesson for run in selected)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();readback=load(pub/'postmortem-readback.json')
line=f'\n- {at} 运维codex：2111原204301两局RQCHNN0W72KF/VNSXWCWXR3VW复盘done0闭环，原RQ191301会话前失败历史保留，不冒抹除；六流3483条原offset行JSON/显式身份核并冻结bytes/SHA，另两runs原行核同为Silent A10/F49负局，38315字节两节正式追加/旧前缀核同。53/49原accepted均Codex Sol6.1/xhigh/default，实际两原run-config P2/C2 on；只描述败局，不作收益/重校准或宽父完成。新silent-0485为学习者RQ巨像已见组合当轮观察/observed/prior unknown，旧八条更新仅新增support，0332两条repeat；13证据行含一add+12追溯链接共25所属CLI，旧claim/首证/prior/status/version及旧evidence前缀保护同验，不代知识实施或shipped。无新增纯bug；RQ0332仍是原F40/F48三组nonpositive-hp/资源steps截断，原5aa/1840/1926链只补本复盘链接、不重派/猜改契约；f4e0f382dd79714b与47a7b241b6020251原自动策略链保留。原初稿usage snake_case/零除及inspect同名异常钩子、正式追加前次数/退出/挡分源勘误留史；ops首核误读state.player已按state.run HP及combat.player挡修正，原失败保留，无重复学习/模型/生成。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0，cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性/keyscan CLEAN；两局has_postmortem1、772/810决策及53/49成功Codex入表，旧告警/独立成本cut估算非账单保留。仅提交本人两节复盘/25CLI/旧队列补链/生成表及回执，物理并行记录保留；无新源码/行为号/测试或对局重启/账号home模型预算队列prompt操作。证据paper/materials/20261015-2111-ops/。\n'
note=f'\n- {at} [ops 学习闭环] RQ/VNS两局复盘完成，旧RQ启动失败原件仍保留；无新增纯bug，silent-0332同三组复现只接原链。两节复盘、25条所属CLI含0485限定机制观察与两原提案已核，旧字段/证据前缀保护；不冒实现/收益/宽父完成。论文唯一刷新exit0、{len(runs)}局、五一致性/keyscan通过，两局has_postmortem1，估计非账单。回执paper/materials/20261015-2111-ops/。\n'
appends=load(p/'early-appends.json')|{'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in {'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note}.items():
 with (r/path).open('ab') as f:f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['notes/lessons.md']=oldlesson+lessons;values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs:values[x['path']]=frozen(x['path'])
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in list(p.glob('*.py'))+list(p.glob('audit-first-*.log'))+[r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers);write(pub/'completion.json',{'at':at,'postmortems':list(selected),'original_six_stream_rows':3483,'original_lesson_bytes':38315,'new_bug':False,'old_repeat':'silent-0332','new_bounded_observation':'silent-0485','evidence_bearing_rows':13,'proposal_links':12,'owned_ledger_rows':25,'protected_fields_preserved':True,'paper_single_exit':0,'paper_cut':cut,'paper_output_count':len(outputs),'five_checks':True,'no_source_release_game_account_or_prompt_change':True,'parallel_records_preserved':True})
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';manifest=[]
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);manifest.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':manifest})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
print(json.dumps({'paths':len(manifest),'ledger_rows':25,'ledger_check':0,'paper_outputs':len(outputs),'runs':len(runs),'paper_exit':0}))

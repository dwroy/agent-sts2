from pathlib import Path
import json,hashlib,subprocess,re
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-2111';pub=r/'paper/materials/20261015-2111-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
bid='20261015-204301';b=json.loads((r/'ops/codex-ops/learn.json').read_text())['batches'][bid];out=(r/'ops/codex-ops/learner'/(bid+'.out')).read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['done']==report['appended']==['RQCHNN0W72KF','VNSXWCWXR3VW'] and b['missing']==[] and b['proposal_audit_errors']==[]
assert len(report['bugs'])==1 and report['bugs'][0]['new'] is False and report['ledger']['repeats']==['silent-0332']
assert '**silent-0332**' in (r/'notes/fix-queue-v4.md').read_text()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text());native=runtime(bid,report,out)
physical=(r/'notes/lessons.md').read_bytes();parts=[]
for run in report['appended']:
 meta=json.loads((s/(run+'-append-prefix.json')).read_text());part=b'\n'+(s/(run+'-section.md')).read_bytes()+b'\n';assert sha(physical[:meta['bytes']])==meta['sha256'] and physical[meta['bytes']:meta['bytes']+len(part)]==part and physical.count(part)==1;parts.append(part)
(p/'owned-lessons.md').write_bytes(b''.join(parts))
record={'batch':bid,'original_report':report,'native':native,'done_runs':b['done'],'missing':[],'no_new_bug':True,'old_issue':'silent-0332','lesson_sections_and_original_prefixes_verified':True,'lesson_bytes':list(map(len,parts)),'byte_stream_audit':'pending ops readback; original learner completion retained','no_repeated_learner_or_game_action':True}
(pub/'postmortem-readback.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();queue=f'\n- {at} [原silent-0332复盘补链，非新bug] 原204301复盘已实际完成RQCHNN0W72KF与VNSXWCWXR3VW；RQ仍是原F40/F48三组nonpositive-hp资源接续异常，原1840/1926补证与5aa2672链保持，完整resources/steps仍截断、根因未修，C1降级出口不当根因修复。不重复派同题，不更改正HP契约、样本/预算或对局。新复盘与联合资源/条件机制提案silent-proposal-f4e0f382dd79714b由原自动策略链处理，VNS资源提案47a7b241b6020251独立保留，均不冒实现/上线；学习者原bugs.new=false，无新增阻塞纯bug。原RQ失败启动历史保留。报告learner/runs/20261015-204302-3d780a35-a078-4b93-bcea-905a0e394efe-postmortem/report.md；本轮接收paper/materials/20261015-2111-ops/。\n'
(p/'early-appends.json').write_text(json.dumps({'notes/fix-queue-v4.md':queue},ensure_ascii=False,indent=2)+'\n')
with (r/'notes/fix-queue-v4.md').open('ab') as f:f.write(queue.encode())
print(json.dumps({'done':b['done'],'new_bug':False,'native_verified':True,'lessons_bytes':len(b''.join(parts)),'original_0332_chain_preserved':True}))

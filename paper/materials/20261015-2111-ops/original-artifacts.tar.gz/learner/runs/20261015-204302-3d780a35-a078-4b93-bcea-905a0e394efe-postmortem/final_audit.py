import json,hashlib,subprocess,re
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2');p=Path(__file__).parent
stamp=subprocess.check_output(['date','-Is'],text=True).strip()
added=['silent-0485'];updated=['silent-0027','silent-0028','silent-0059','silent-0173','silent-0228','silent-0253','silent-0332','silent-0418'];runs=['RQCHNN0W72KF','VNSXWCWXR3VW']
audit={'checked_at':stamp,'lessons':{},'ledger':{},'proposals':{}}
for rid in runs:
 meta=json.loads((p/f'{rid}-append-prefix.json').read_text());h=hashlib.sha256()
 with (root/'notes/lessons.md').open('rb') as f:
  left=meta['bytes']
  while left:
   chunk=f.read(min(left,1024*1024));assert chunk;h.update(chunk);left-=len(chunk)
  assert h.hexdigest()==meta['sha256'],'旧内容变化'
  expected=b'\n'+(p/f'{rid}-section.md').read_bytes()+b'\n';assert f.read(len(expected))==expected,'追加段字节变化'
 titles=subprocess.run(['rg','-n','^## '+rid,str(root/'notes/lessons.md')],capture_output=True,text=True,check=True).stdout.splitlines();assert len(titles)==1
 audit['lessons'][rid]={'prefix_unchanged':True,'section_identical':True,'heading':titles[0]}
 found=subprocess.run(['python3',str(root/'learner/ledger.py'),'find','--run',rid,'--json'],capture_output=True,text=True,check=True)
 (p/f'{rid}-ledger-final.json').write_text(found.stdout)
 ids=[x['id'] for x in json.loads(found.stdout)];expect=(['silent-0485','silent-0228','silent-0332','silent-0028','silent-0027'] if rid.startswith('RQ') else ['silent-0228','silent-0028','silent-0418','silent-0059','silent-0027','silent-0253','silent-0173']);assert set(expect)<=set(ids)
 audit['ledger'][rid]={'entries':ids,'required_links':expect}
before=json.load((p/'ledger-before-targets.json').open());after={}
for ident in added+updated:
 result=subprocess.run(['python3',str(root/'learner/ledger.py'),'show',ident],capture_output=True,text=True,check=True);entry=json.loads(result.stdout);after[ident]=entry
 if ident in before:
  for k in ['claim','first_run','prior','prior_runs','prior_note','status','version','character','asc']:assert entry.get(k)==before[ident].get(k),(ident,k)
 else:assert entry['status']=='observed' and entry['by']=='learner:postmortem' and entry['prior']=='unknown'
(p/'ledger-after-targets.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
proposal_ids=[(p/f'proposal-{r}-cli.out').read_text().strip() for r in runs];queue={}
with (root/'paper/materials/learning/code-proposals.jsonl').open() as f:
 for line in f:
  row=json.loads(line)
  if row.get('id') in proposal_ids:queue.setdefault(row['id'],{}).update(row)
for rid,ident in zip(runs,proposal_ids):
 row=queue[ident];assert row['state']=='pending' and row['source_task']=='postmortem' and row['target_task']=='strategy-proposal' and row['runs']==[rid]
 assert row['proposal_sha256']==hashlib.sha256(Path(row['proposal']).read_bytes()).hexdigest()
 assert not row.get('implemented_commit')
 audit['proposals'][rid]={'id':ident,'state':row['state'],'target_task':row['target_task'],'ledger':row['ledger']}
check=subprocess.run(['python3',str(root/'learner/ledger.py'),'check'],capture_output=True,text=True);(p/'ledger-check-final.out').write_text(check.stdout+check.stderr);audit['ledger_check']=check.returncode;assert check.returncode==0
(p/'final-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
report={'task':'postmortem','appended':runs,'skipped':[],'bugs':[{'run':runs[0],'where':'agent/src/sim/boss-sim.ts:338','what':'旧silent-0332成功首战nonpositive-hp资源接续异常复现，完整资源与步骤截断，根因未修','new':False}],'ledger':{'added':added,'updated':updated,'repeats':['silent-0332'],'check':check.returncode},'code_proposals':proposal_ids,'implementation_domains':['combat','potion','terminal','structure'],'report':str(p/'report.md')}
text='''## 复盘回报
- 已追加：RQCHNN0W72KF（A10，第49层，实验体末试T2以4血6挡承受18攻击阵亡）
- 已追加：VNSXWCWXR3VW（A10，第49层，实验体末试T3以4血15挡承受46攻击阵亡）
- 新的纯 bug（file:line，每条一行；没有写「无」）：无。旧项silent-0332已补复现，定位agent/src/sim/boss-sim.ts:338，fix-queue-v4已有。
- 写成「未记录」的项：两局均包括完整逐击／过量伤害及退场中间帧、前五次SL离场结算、传统boss时钟、纯战斗用时、Jev缓存／实付账单、完整dirty知识及受控反事实；RQ另缺接续异常完整resources／steps；VNS自动局报为空。
- 学习账本：RQCHNN0W72KF：新增silent-0485；更新silent-0228、0332、0028、0027（老错silent-0332）。
- 学习账本：VNSXWCWXR3VW：新增无；更新silent-0228、0028、0418、0059、0027、0253、0173；均为support。`ledger.py check`退出码0。
- 代码提案：RQ F48→F49／账本silent-0228、0485、0332、0028、0027 → '''+proposal_ids[0]+''' → strategy-proposal；待验证，故障完整样本不足，保留原行为。
- 代码提案：VNS F48T2／F49T2—T3／账本silent-0228、0028、0418、0059、0027、0253、0173 → '''+proposal_ids[1]+''' → strategy-proposal；待验证，缺同盘受控对照，未实现或上线。
'''
(p/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(p/'report.md').write_text(text+'\n```json\n'+json.dumps(report,ensure_ascii=False)+'\n```\n')
print('最终核验通过：两节各一次追加、原内容未变、关键数字无勘误；账本旧字段保持，check='+str(check.returncode))
print('提案',proposal_ids)
print('报告',p/'report.md')

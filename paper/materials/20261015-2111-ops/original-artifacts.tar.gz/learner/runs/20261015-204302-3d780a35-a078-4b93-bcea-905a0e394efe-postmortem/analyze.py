import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent
for rid in ['RQCHNN0W72KF','VNSXWCWXR3VW']:
 ds=[json.loads(x) for x in (p/f'{rid}-decisions.jsonl').open()]; ss=[json.loads(x) for x in (p/f'{rid}-states.jsonl').open()]
 f=(p/f'{rid}-analysis.txt').open('w')
 def out(*x): print(*x,file=f)
 out('局号',rid)
 counts=collections.Counter(x['row'].get('decider') for x in ds);out('决策者',counts)
 low=[x for x in ds if x['row'].get('decider')=='jev' and isinstance(x['row'].get('confidence'),(int,float)) and x['row']['confidence']<.35];out('低信心',len(low),[(x['line'],x['row']['floor'],x['row'].get('turn'),x['row']['label'],x['row']['confidence']) for x in low])
 plans=[x for x in ds if x['row'].get('decider')=='jev' and re.search('code rank (\d+)',x['row'].get('rationale',''))];out('计划有rank',len(plans),'rank1',sum(bool(re.search('code rank 1(?:;|$)',x['row']['rationale'])) for x in plans))
 code=[x for x in ds if x['row'].get('decider')=='code' and x['row']['label'].startswith('combat/')];out('代码战斗',collections.Counter(x['row']['label'] for x in code),'不含续打的独立题',len([x for x in code if x['row']['label']!='combat/plan-continue']))
 for x in ds:
  d=x['row']; lab=d['label']; rat=d.get('rationale',''); floor=d['floor']
  if d.get('decider')=='codex' or ('guard' in rat.lower() or 'guard' in lab or 'potion' in str(d.get('chosen')) or 'drink' in str(d.get('chosen')) or 'discard_potion' in str(d.get('chosen'))):
   out('决定',x['line'],floor,d.get('turn'),lab,d.get('decider'),'选',d.get('chosen'),'理由',rat,'日志',d.get('journal'))
  if lab.startswith('combat/') and (floor>=48 or (rid=='RQCHNN0W72KF' and floor==33)):
   out('战斗决定',x['line'],floor,d.get('turn'),lab,d.get('decider'),rat,'选',d.get('chosen'),'日志',d.get('journal'))
  if floor in [1,17,33,47,48,49] and d.get('decider')=='codex':
   for qk,q in (d.get('questions') or {}).items():
    if not isinstance(q,dict):continue
    facts=q.get('facts') or {}
    out('事实键',x['line'],qk,list(facts))
    for k,v in facts.items():
     if any(w in k for w in ['clock','route','boss','plan','project']):out('事实',x['line'],k,json.dumps(v,ensure_ascii=False)[:12000])
 for z in ss:
  st=z['row']['state']; c=st.get('combat') or {}; run=st.get('run') or {};floor=run.get('floor'); turn=st.get('turn')
  if floor not in ([17,33,48,49] if rid=='RQCHNN0W72KF' else [17,33,38,48,49]) or not c:continue
  pl=c.get('player') or {}
  out('帧',z['line'],z['row']['ts'],'F',floor,'T',turn,'HP',run.get('current_hp'),'max',run.get('max_hp'),'player',json.dumps(pl,ensure_ascii=False),'敌',json.dumps(c.get('enemies'),ensure_ascii=False),'手牌',[(h.get('card_id'),h.get('name'),h.get('description')) for h in c.get('hand',[])])
 for line in (p/f'{rid}-run-plans.jsonl').open():
  x=json.loads(line);out('计划',x['line'],json.dumps(x['row'],ensure_ascii=False))
 f.close()
 print(rid,'生成分析',len(ds),len(ss))

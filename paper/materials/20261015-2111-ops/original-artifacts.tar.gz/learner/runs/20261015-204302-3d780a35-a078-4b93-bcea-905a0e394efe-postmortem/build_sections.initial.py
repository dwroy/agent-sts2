import json,re,datetime,subprocess,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2');p=Path(__file__).parent
stamp=subprocess.check_output(['date','-Is'],text=True).strip()
intro={
'RQCHNN0W72KF':'''## RQCHNN0W72KF（A10，静默猎手，第49层，死于连续第二boss实验体 #C86 TEST_SUBJECT：六试均4/70血空药进场，前五试T2判死读档；末试T2以4血6挡对18攻击阵亡，完整需损12、存活至少差9血，结毒与荆棘后敌仍44/111血，未过第一阶段）

- [连续首王胜利只留下4血，须按两战资源链评估；打法（大脑路线/构筑/休息，实际Codex）] F47休息50→70，F48女王 QUEEN／火炬头聚合体 TORCH_HEAD_AMALGAM 首试8轮70→4，槽0毒药水 POISON_POTION 在T1饮尽；F49没有回血或补药。大脑明确准备连续双王，不能把这局写成“不知道还有第二王”的重复错误，也不能声称前场留药就能转胜。（之前学过：silent-0228，S1.legacy17-1；本局为support）
- [巨像的减伤依赖敌易伤，且不能延续到下一轮；打法（Jev出牌；机制观察）] 末试T1防御＋ DEFEND_SILENT 后9挡、敌3力25攻击；巨像＋ COLOSSUS 再加8挡，同时触发激怒 ENRAGE_POWER 3使敌至6力，但与弹珠袋 BAG_OF_MARBLES 的易伤配合，意图降至14，17挡保住4血。T2巨像增益与敌易伤均不在，敌先显示22攻击；打防御再激怒至9力25攻，突然一拳 SUCKER_PUNCH 虚弱后仍18攻，6挡不足。只核当前回合及这个组合，不据此强制拿牌或启动顺序（s412949—412960，d400105—400115）。（第一次遇到）
- [成功首战样本的非正HP资源仍触发接续异常；bug（代码，旧项）] F40休息题、F48T1及T6三组模拟均出现 won=true／died=false 却报 nonpositive-hp；本次复现定位于只读live的 agent/src/sim/boss-sim.ts:328／:338（资源契约检查及抛错）。notes/fix-queue.md 未检到该项，但 notes/fix-queue-v4.md:1330／:1336 及 silent-0332 已有，故不是新bug。三组第三次分别仅42／159／0样本，低于原300门槛后隐藏不可用数字并继续；完整末资源与步骤在错误文本中截断，未定位机制根因，不称已修或直接归因整局死亡。（之前见过：silent-0332；repeat）
''',
'VNSXWCWXR3VW':'''## VNSXWCWXR3VW（A10，静默猎手，第49层，死于连续第二boss实验体 #C86 TEST_SUBJECT：六试均11/69血、槽0肌肉药水及槽1速度药水进场，前五试T4／T5／T3／T3／T5判死读档；末试T3以4血15挡对易伤后46攻击阵亡，完整需损31、存活至少差28血，结毒后敌仍11/111血，未过第一阶段）

- [首王后补药并不补血，连续战预算仍需保留实到血量；打法（大脑路线/构筑/休息，实际Codex）] F47休息32→52；F48永世沙漏 AEONGLASS 首试9轮52→11，槽0再生药水 REGEN_POTION 和槽1速度药水 SPEED_POTION 均T1饮用。娇嫩蕨草 DELICATE_FROND 在F49开场将空槽补为肌肉药水 FLEX_POTION／速度药水，HP仍11；六次都实际饮完两药而未过。不能因“可续药”把前场净损41当可忽略，也无留药或另一路线的同盘通关反事实。（之前学过：silent-0228，S1.legacy17-1；本局为support）
- [临时减力须与同轮技能激怒和易伤共同算；打法（Jev出牌／代码）] 实验体 TEST_SUBJECT 本场激怒为3。末试T3开局敌6力、我方易伤1，意图42；防御 DEFEND_SILENT 使力6→9，尖啸 PIERCING_WAIL 自身先触发激怒再暂减6，使9→6，生存者 SURVIVOR 再加至9，末意图46、总挡15。触媒＋ ACCELERANT 虽已建2，但此时只剩1毒，实际仅扣1至敌11血。不是把旧低进阶激怒2套成3，也没有证据证明少打一张技能就能赢（s413908—413914，d400924—400928）。（之前学过：silent-0028，S1.exp189；补本局条件support，非认定同一策略错误repeat）
- [护栏候选中途重问后，标称省血不等于实际省血；打法（代码／Jev出牌）] F48T2 d400754把弹跳药瓶＋ BOUNCING_FLASK／带毒刺击＋ POISONED_STAB 的损19方案换成计划妥当＋ WELL_LAID_PLANS／生存者 SURVIVOR 的损7方案，名义省12但少9当轮伤；杂技＋ ACROBATICS 的弃牌流程后实际只先建计划妥当，d400755再选弹跳药瓶，原生存者后缀未完整兑现，T2实57→45净损12。须按实际动作与选择屏重建，不能把12点模型差写成已省12血，也不把正常抽弃边界认成新纯bug（s413690—413698）。（之前学过：silent-0418，S1.exp182；support）
'''}
body={
'RQCHNN0W72KF':'''  构筑、路线与休息：大脑全部为Codex；DeepSeek只是旧职责／统计字段名。F5选致命毒药 DEADLY_POISON（d399410），F18选黄金印 SEAL_OF_GOLD，原话“黄金印补能，双店补防，三火单精英控险。”（d399590）；F34选十字弓 CROSSBOW，原话“逐轮免费补伤；三火双店，避精英备双王。”（d399840）。F40升级触媒 ACCELERANT，F47再休息；run-plans L3708／3709已明确首王后无恢复节点、剩4血，伤害差未知。实际8次回血（F7＋21、F9＋21、F12＋21、F16＋17、F24＋21、F29＋21、F43＋21、F47＋20）、F40一次锻造；F40另两条rest/plan是同题计算失败，不算额外营火行动。F9改线绕开第二只精英（d399477），不推未走分支胜负。

  关键进场资源追溯：F17以70血入、30血胜出，F18跨幕30→62；F23后39血，F24休息至60，F28千足虫60→26，F29休息至47，F30盛碗虫47→44、F31异螨44→40，F32休息至61，F33火箭 ROCKET／碾碎爪 CRUSHER 胜后2血；F34跨幕2→56。F35卷轴56→56，F37虔诚雕刻师 DEVOTED_SCULPTOR 56→44；F38选芳香蘑菇 FRAGRANT_MUSHROOM 实损15至29（d399904／s412741→412742），F40锻造不回血，F43休息29→50，F44史莱姆狂战士 SLIMED_BERSERKER 50→50、F46组装师 FABRICATOR 50→50且饮槽1痊愈药水 CURE_ALL，F47休息50→70。F48毒药水由F33奖励补入、一直保留至F48T1；F48胜后4血空药栏原样入F49（s412884→412886）。这些均为实际资源变化，战斗净耗血不等敌方毛伤。

  每轮输出／承伤：以下“可见扣血下界”来自逐帧敌HP下降，只计有相邻可核帧的下降；退场、过量伤、阶段恢复及同ID多体不擅自补全。F17族母 LAGAVULIN_MATRIARCH 开场233血，T1—T8下界0／15／25／32／31／38／43／19，末49血退场缺归零帧，不能把缺口30算入可见伤。F33两敌219＋209＝428血，T1—T9下界90／18／12／54／41／60／68／41／0，火箭末26、碾碎末18退场缺归零帧；实际先清火箭、再清碾碎，不能把多题chosen_order的“碾碎爪 > 火箭”当实际击杀顺序（s412662→412663／412668→412669）。F48两敌初始211＋419＝630，但不代表必须独立扣完两者：T1—T8下界65／52／40／28／48／96／103／0，合432；HP各轮70→68→58→49→35→32→14→4→4，净损2／10／9／14／3／18／10／0。末女王83血29毒、触媒2，已足在三次毒结算中结束女王；聚合体115血同时退场，没有单独击杀帧，不把末198消失血池全算实打。F49末试第一阶段需111血，T1下界38、T2下界29，共67，余44；T2出牌前73血，打牌扣20，结束后毒与荆棘合见再扣9。末18攻减6挡需损12而血条仅扣4截顶，存活至少还需9血；后续阶段未到，不能把111当整战需求。

  Jev与代码：207次Jev中低信心＜0.35共13次。rollout_best_chosen为真172／假7／缺2，179道有值战斗题中172/179＝96.09%；这是原回答选最优或并列最优的比例，HP护栏／SL探索可在其后改实线，不能当完整候选执行率。61题记录focus映射；F33T1有碾碎／火箭分别focus，F48T1 plan9聚合体／plan10女王（d399787／399999），实际以毒集中女王并获胜，未证明普遍最优击杀顺序。271条combat/plan-continue中216沿Jev线、55沿代码线；代码实际自主首选66条，分布44个回合／全113个有战斗动作回合（按层、SL尝试、回合去重，同回合可同时有Jev）。另4条combat/plan为计算待完成且无动作，不计已出牌；运行汇总的code290／jev-plan216是重分类口径。

  保血护栏只替换1题：F8T1 d399444将打击 STRIKE_SILENT／防御／带毒刺击的损13伤15改为两防御／带毒刺击的损8伤9，模型省5血、少6伤，三步确有执行（d399444—399446）。这次原触发比较的是更便宜候选，并非说13与8的差大于8；未执行原线，无实盘因果省血量。F48T1初选plan4预测损2，抽牌切断后重新选线并饮毒，实际下一轮68与预测一致，只能验证该轮HP、不能把后继65可见扣血全部归原56伤候选。F49末试d400110预测本线余HP−8；实际18攻减6挡需损12，4−12＝−8相符，血条0为截顶而非只需损4。

  SL：前三场boss F17／F33／F48各首试赢，SL记录L2196—2198；F49 L2199—2204共6试，前5次均T2判死且退出帧缺失，末次T2实死。判死时敌攻击依次25／25／21／23／21／18，末前均4血6挡；首两试T1行动摘要相同，后续改变T1分支，六试T2均沿带毒刺击／必备工具 TOOLS_OF_THE_TRADE／打击／防御／突然一拳。每次读档重建4血空药，恢复不是回血；已截断5次不能算另5场实际死亡，也无证据宣称这六条覆盖全部可活路线。

  路线预测与时钟：F47 d399996基准未休息投影入口50，所选休息条件投影70，实际F48首帧70，差0；F32休息条件投影61、实际F33入口61。F47回血候选两战模拟0%、约7回合并标低可信，基准300样本；这是连续通关模拟摘要，不是女王单战必死判断或单战时钟。实际F48首试8轮赢、F49末试2轮败；传统boss-clock“需要／估计DPR”的字段在本局题面未记录，逐击毛伤与完整伤害归属未记录，不能用630/8替代实DPR或把联合0%当女王胜利反例。F40种子607614716／F48T1种子614798807／F48T6种子46797397的三组失败原件保留（d399911—399913、400001—400003、400026—400028），不能用增加样本或降级完成冒称根因已修。

  机制：新增巨像＋ COLOSSUS 与易伤的当轮减伤观察对应第二条账本，既有代码已含colossus分支，不等于本任务发现新代码缺陷。F49末试T1防御＋使敌力0→3、巨像＋再3→6且25攻变14；T2巨像消失，防御再6→9，突然一拳将25→18，仍缺挡（silent-0028补A10激怒3的support，不把其旧激怒2常数外推）。意外光滑的石头 ODDLY_SMOOTH_STONE 提供现场1敏捷，T2普通防御实际6挡；必备工具能力建立时敌力与既有挡不变，不能把能力当技能激怒。F48T5触媒＋建立ACCELERANT_POWER2后，女王16毒实302→257扣45＝16＋15＋14；T6的28毒实257→176扣81，验证额外两次结算（silent-0027 support）。末试T1敌80→73包含4毒及现场3荆棘，终局53→44包含6毒及3荆棘，均不归为攻击牌本体伤害；没有分离组件的整战胜率。
''',
'VNSXWCWXR3VW':'''  构筑、路线与休息：实际大脑为Codex。F1拿巨大扭蛋 LARGE_CAPSULE，获得打击木偶 STRIKE_DUMMY／意外光滑的石头 ODDLY_SMOOTH_STONE（本局状态）；F5事件吃下使54→63并升级迷雾 HAZE（d400177／s413024→413025），F15吃蛋使53/70→60/77（d400296／s413148→413149）。F18选美味饼干 YUMMY_COOKIE，原话“四升强化留牌与防御，走商店避精英。”（d400345）；F34选娇嫩蕨草 DELICATE_FROND，原话“蕨草续药联动饰品，四火避精英，备战连续双王。”（d400557）。F39删打击并买侧步 SIDESTEP（d400636—400639），F40升级弹跳药瓶；F42／F44／F47均回血。实际6次休息回血（F12＋21、F27＋23、F32＋23、F42＋20、F44＋20、F47＋20），3次营火锻造（F8生存者、F16毒雾 NOXIOUS_FUMES、F40弹跳药瓶），没有把事件／美味饼干升级算成营火。run-plans L3722／3723已明确连续第二王、补药和无恢复节点；所需DPR未知，不能归为“不知道双王”。

  关键进场资源追溯：F17同族首王60/77→19/77，F18跨幕19→65；F19外骨骼虫 EXOSKELETON 65→61，F20地道虫 TUNNELER 61→31并饮敏捷药水 DEXTERITY_POTION，F23胧光怪 THE_OBSCURA 31→31且饮铁心 HEART_OF_IRON／流动铜液 LIQUID_BRONZE；F27休息至54，F29三敌54→43、F30外骨骼虫43→40，F32休息至63，F33无厌沙虫 THE_INSATIABLE 63→22，F34跨幕22→66。F35卷轴66→66，F37炮塔操作员 TURRET_OPERATOR／活体盾 LIVING_SHIELD 66→38，F38卷轴38/77→26/69，max HP实际少8（s413511—413520）；本节只记逐帧77→75→71→69，不从同ID敌人混排反推每只的独立扣上限次数。F40锻造无回血；F42休息26→46，F43组装师 FABRICATOR 46→37，F44休息37→57，F45法官猫头鹰 OWL_MAGISTRATE 57→49，F46史莱姆狂战士 SLIMED_BERSERKER 49→32并饮虚弱药水 WEAK_POTION，奖励补槽0再生；F47休息32→52。F48两药用尽且胜后11/69，F49蕨草补槽0肌肉／槽1速度、HP未恢复（s413746→413748）；SL补回同一房间药水另列，不作新获药。

  每轮输出／承伤：“可见扣血下界”仍按逐帧下降，不当毛伤、过量或退场自动补数。F17开场神官 KIN_PRIEST 199、两信徒 KIN_FOLLOWER 63／62，存活血池净下降T1—T8为92／18／20／17／45／47／66／19；同ID两信徒不能逐体稳定对齐，末19神官退场缺归零帧，故这不是逐击伤害表。F33沙虫开场341，T1—T7可见下界46／32／24／39／55／82／0，末63退场缺归零帧；七轮清场不能证明固定48.71毛DPR。F48沙漏535血，T1—T9下界0／4／53／27／63／98／84／87／4，合420，末115退场缺逐击清零。HP各轮52→57→45→48→47→48→42→32→16→11，净变化＋5／−12／＋3／−1／＋1／−6／−10／−16／−5；净损41包含再生收益，不能当敌总伤害。末47毒、触媒2可结47＋46＋45＝138，足够结束115血沙漏，但手持凋萎 WITHER 9伤先由4挡承接，仍实扣5，16→11获胜（s413745→413746），不是毒斩杀免除持牌伤。F49末试第一阶段111血，T1／T2／T3实见扣69／30／1，共100，余11；HP11→4→4→0，最后血条扣4为截顶，实际46攻减15挡需损31、至少再28血才存活。第二阶段未到，整战所需伤害未记录；第一／二／五试确实进入212上限新阶段且旧毒消失，不能将换体当回血或无伤。

  Jev与代码：176次Jev，低信心＜0.35共13次。rollout_best_chosen真143／假8／缺4，有值151题中143/151＝94.70%，只代表原回答，后续SL探索、护栏和抽弃牌可能改变兑现。31题有focus映射；F17T1有神官与“信徒x2”的focus（d400303／400305），T6后的chosen_order改为信徒优先，但不能倒写成全程同一顺序。实际T8两信徒先退场，神官最后19血退场（s413191→413193）；F49是单敌，多阶段不是多目标focus。284条combat/plan-continue中236沿Jev、48沿代码；代码独立首选130条，分布92个回合／全131个有战斗动作回合（层／尝试／回合去重，非互斥）；汇总code334／jev-plan236是重分类口径。

  HP护栏共替换2题。F38T3 d400615把防御／打击／毒雾＋／固化药水 FORTIFIER 的损14改为两防御／打击／固化的损0，模型省14，代价为本线未建立毒雾＋；后续T4子弹时间 BULLET_TIME 才建立毒雾，不能说整战永远失去该能力。F48T2名义省12、少9伤，但原防御后缀中断，实际净损12已在第三条说明；两次名义差合26不能写成实省26血。F48T1 Jev选plan7预测净回5至57，实际57符合该轮HP；d400751又在免费背刺 BACKSTAB 与结束之间选结束，之后不按plan7完整一线打九轮。F49末试T3最少损线预测余血−27，与4−(46−15)＝−27相符；四条combat/mod-lethal的“推演0承伤、mod判死”发生在毒将换阶段的窗口（d400804／400805／400831／400896），这些回合实际换体后仍活到下一轮，不凭提示差异认定新的实盘误判或改SL阈值。

  SL：F17／F23／F33／F38／F48均首试赢（L2205—2209）。F49 L2210—2215六试，前五在T4／T5／T3／T3／T5判死读档，末T3实死；判死时HP／挡／意图分别2／19／32、4／28／32、4／13／55、6／15／51、4／28／32、4／15／46。前三种新阶段入口仅第一、第二、第五试实际到达212血阶段，不是全六试皆打穿第一阶段。每试T1饮槽0肌肉、T2饮槽1速度；五次重载把末见HP2／4／4／6／4恢复为11并各恢复两药，属于存档恢复，既不计治疗，也不计新获得10瓶；前五次都缺真实退出结算帧，不当实际死亡。

  路线预测与时钟：F47 d400742未休息基准投影32、所选回血条件投影52，实F48入口52；F32休息条件投影63，实际F33入口63，均差0，仅验证该段条件投影。F47基准700样本两战通关0%，所选休息摘要约8回合且明确低可信；实首王9轮赢、末王3轮败不能混作同一时钟校准。传统boss-clock需要／估计DPR未记录；535/9＝59.44只是清场需求／轮代理，可见扣血420/9＝46.67仅下界，退出115缺逐击，二者均不当完整毛DPR，也不据联合0%判第一王必死。

  机制：本节为旧机制加本局support。实验体激怒3使每张技能加3力，末T3防御／尖啸／生存者合触发9力，尖啸暂减6后净增3；玩家易伤使相同攻击的威胁又被放大，42→46而15挡仍不够（silent-0028）。能力触媒＋在末试T2建立ACCELERANT_POWER2，不触发技能激怒，4毒实结4＋3＋2＝9，敌21→12；T3只剩1毒，不能按仍有三份4毒估伤（silent-0027）。速度药水在末试T2使敏捷1→6，下一轮回1；T2第一张后空翻 BACKFLIP 在6敏捷下给10挡、当轮两张攻击另有骇人头盔 INTIMIDATING_HELMET 格挡，不能把总18挡都归速度，药水没有永久提高T3防御（silent-0253）。F48T5触媒＋与毒雾＋都实际建起，22毒结63，451→388；末轮9伤凋萎、4挡先耗5血后毒胜，印证毒胜仍结持牌伤（silent-0059）。爬行动物饰品 REPTILE_TRINKET 的当轮力量与蕨草续药均确有本局状态，但没有拆分其独立整战胜因，不把补药当补血。
'''}

def load(rid,name):return [json.loads(x) for x in (p/f'{rid}-{name}.jsonl').open()]
for rid in intro:
 ds=load(rid,'decisions');ss=load(rid,'states');rs=json.load((p/f'{rid}-resources.json').open());names={};potnames={}
 for z in ss:
  st=z['row']['state']
  for e in (st.get('combat') or {}).get('enemies',[]):names[e['enemy_id']]=re.sub(r' #[0-9]+$','',e['name'])
  for pot in st['run'].get('potions',[]):
   if pot.get('potion_id'):potnames[pot['potion_id']]=pot.get('name') or pot['potion_id']
 def pots(lst):return '、'.join(f"槽{slot}:{pid}" for slot,pid in lst) or '空'
 lines=[intro[rid],f'- [记录] 复盘时间{stamp}。runs.jsonl L'+('787' if rid.startswith('RQ') else '788')+'：SILENT、A10、victory=false、F49、code=current；run-config实际源码基底为'+('3d066a583631b85acb208813c31510864007adac（3d066a5+dirty）' if rid.startswith('RQ') else 'fe6462651b593b9831581c088deface9957a404f（fe64626+dirty）')+'。本文file:line按复盘只读live fe6462651b593b9831581c088deface9957a404f；不冒称恢复了当时全部dirty知识。'+('已读notes/run-1015-1905-RQCHNN0W72KF.md全部103行。' if rid.startswith('RQ') else 'notes/run-1015-2041-VNSXWCWXR3VW.md为空文件，复盘由原始日志重建。')+'两个局号的所有同名运行笔记均已检查；DeepSeek推理文件按首末决策时间窗流式检查，0条。原生brain逐请求核到'+('53' if rid.startswith('RQ') else '49')+'条，均Codex／gpt-6.1-sol／xhigh／accepted=true。\n\n'+body[rid]]
 lines.append('  实盘逐场资源表：21场先行战斗均首试获胜；F49为同一战斗的6次尝试，共27个资源窗口，首帧均T1。证据s＝logs/states.jsonl行号、d＝logs/decisions.jsonl行号；表中时间均为2026-10-15 UTC，进／出时间以资源JSON完整字段复核。空退出的净变化写未记录；末见HP另列，不当结算。\n\n| 层／尝试 | 现场敌人 | 进→出HP/max HP；净变化 | 药水进→出 | 状态证据；进→出/末见时间 |\n|---|---|---|---|---|')
 for w in rs['combats']:
  ent=w['entry'];exit=w['exit'];last=exit or w['last'];seq=w['sequence'];att=seq-21 if w['floor']==49 else 1
  es=set()
  for z in ss:
   if ent['line']<=z['line']<=w['last']['line']:
    es.update(e['enemy_id'] for e in (z['row']['state'].get('combat') or {}).get('enemies',[]))
  enemy='／'.join(f'{names.get(e,e)} {e}' for e in sorted(es))
  hp=f"{ent['hp']}/{ent['max_hp']}→{last['hp']}/{last['max_hp']}；"+(f"{last['hp']-ent['hp']:+d}" if exit else '退出缺帧，净变化未记录（右为末见）')
  evidence=f"s{ent['line']}→s{last['line']}；{ent['ts'][11:]}→{last['ts'][11:]}"
  lines.append(f"| F{w['floor']}／{att} | {enemy} | {hp} | {pots(ent['potions'])}→{pots(last['potions'])} | {evidence} |")
 lines.append('\n  药水ID对照：'+'；'.join(f'{name} {pid}' for pid,name in sorted(potnames.items()))+'。')
 lines.append('\n  逐瓶获得／补充（SL恢复已排除）：')
 gains=[]
 for c in rs['resource_changes']:
  if c['restart_boundary']:continue
  bef={tuple(a) for a in c['from']['potions']};aft={tuple(a) for a in c['to']['potions']}
  for slot,pid in sorted(aft-bef):gains.append(f"F{c['to']['floor']}槽{slot} {pid}（s{c['from']['line']}→s{c['to']['line']}，{c['to']['ts']}）")
 lines.append('  '+'；'.join(gains)+'。')
 lines.append('\n  逐次实际饮用（排队请求另核后续状态已消费）：')
 drinks=[]
 for z in ds:
  d=z['row'];a=d.get('chosen') or {}
  if a.get('action')!='use_potion':continue
  # The decision frame records inventory before the action; later selection frames confirm queued drinks.
  candidate=[x for x in ss if x['row']['ts']==d['ts']]
  if not candidate:candidate=[x for x in ss if x['row']['ts']<=d['ts']][-1:]
  slot=a['option_index'];pid=next((t.get('potion_id') for t in candidate[-1]['row']['state']['run']['potions'] if t.get('index')==slot), '未记录')
  drinks.append(f"F{d['floor']}／试{d.get('sl_attempt') or 1}T{d['turn']}槽{slot} {pid}（d{z['line']}，{d['ts']}）")
 lines.append('  '+'；'.join(drinks)+'。')
 lines.append('  '+('新取得9瓶，实际饮用9次，主动丢弃0，事件交药0，终局空药。' if rid.startswith('RQ') else '新取得16瓶（含蕨草填槽），实际饮用26次＝首次资源16次＋五次重载恢复后10次；主动丢弃0，事件交药0，终局空药。F17能力药水、F37技能药水的首动作返回pending，后续选择屏与库存消失确认已饮，不能按pending本身算成功。'))
 brains=load(rid,'brain');usage={k:sum((x['row'].get('usage') or {}).get(k,0) or 0 for x in brains) for k in ['input_tokens','output_tokens','cache_hit_tokens']}
 jev={k:sum((x['row'].get('usage') or {}).get(k,0) or 0 for x in ds if x['row'].get('decider')=='jev') for k in ['input_tokens','output_tokens']}
 a=datetime.datetime.fromisoformat(ds[0]['row']['ts']);b=datetime.datetime.fromisoformat(ds[-1]['row']['ts']);cfg=load(rid,'run-config')[0]['row'];start=datetime.datetime.fromisoformat(cfg['ts']);span=(b-a).total_seconds();full=(b-start).total_seconds()
 lines.append(f"\n  用时／token：首末决策{ds[0]['row']['ts']}—{ds[-1]['row']['ts']}，跨度{span:.3f}秒；run-config至结束{full:.3f}秒，含思考／等待／SL，纯战斗用时未记录。Jev输入{jev['input_tokens']}、输出{jev['output_tokens']}、合{sum(jev.values())}，与runs.tokens相符；Jev缓存命中未记录，不把缺字段算0。原生Codex {len(brains)}次输入{usage['input_tokens']}、输出{usage['output_tokens']}、缓存{usage['cache_hit_tokens']}，输入命中{usage['cache_hit_tokens']/usage['input_tokens']*100:.2f}%；其中独立run-plan4次已含在总数，不重复相加。旧ds_tokens字段是Codex用量，实付账单未记录。")
 lines.append('\n  限制／去向：每轮可见HP减少与需要清场的HP分开，未记录完整逐击毛伤／过量伤害及退出中间击杀帧；前五次SL真实离场结算、完整boss时钟、未走路线与未选动作的受控整战反事实、完整dirty知识字节、Jev缓存和实付账单亦未记录。'+('资源契约故障完整末资源／步骤截断，保留旧0332链。' if rid.startswith('RQ') else '护栏两条名义差均不冒称实际收益，补药后的独立胜因未知。')+'学习账本逐条关联，出牌／药水／终局与所涉结构验证写入本任务代码提案，来源postmortem、目标独立strategy-proposal；未改源码、未实现、未上线、不提交。原资源JSON、抽取行号与偏移、brain原请求及失败日志均保存在本任务目录。\n')
 section='\n'.join(lines)
 (p/f'{rid}-section.md').write_text(section)
 (p/f'append-{rid}.sh').write_text("cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n\n"+section+"\nEOF\n")
 print(rid,'节字数',len(section),'主要经验',section.count('\n- [')-1,'获得',len(gains),'饮用',len(drinks))
# Freeze only the source leaves needed to make current file:line references reviewable.
paths=['agent/src/sim/boss-sim.ts','agent/src/reflex/combat-plan.ts','agent/src/reflex/turn-solver.ts']
live=root/'.worktrees/live';head=subprocess.check_output(['git','-C',str(live),'rev-parse','HEAD'],text=True).strip()
meta={'live_commit':head,'leaves':{}}
for path in paths:
 data=(live/path).read_bytes();target=p/'source-leaves'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);meta['leaves'][path]=hashlib.sha256(data).hexdigest()
(p/'source-references.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
(p/'live-source-diff.binary.patch').write_bytes(subprocess.check_output(['git','-C',str(live),'diff','--binary','--',*paths]))
(p/'run-bases-source-diff.binary.patch').write_bytes(subprocess.check_output(['git','-C',str(live),'diff','--binary','3d066a583631b85acb208813c31510864007adac','fe6462651b593b9831581c088deface9957a404f','--',*paths]))

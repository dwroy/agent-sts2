import json,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2');by='learner:postmortem'
def update(ident,rid,floor,turn,note,role='support'):
 return {'id':ident,'by':by,'evidence':[{'run':rid,'floor':floor,'turn':turn,'role':role,'note':note}],'where':{'lessons':[rid]}}
rq='RQCHNN0W72KF';v='VNSXWCWXR3VW'
new={'character':'silent','by':by,'kind':'mechanic','claim':'静默A10本局巨像＋COLOSSUS的减伤只在当回合、敌有易伤时兑现：实验体激怒3在施放时使敌力3→6，但意图25→14，玩家挡9→17。下一轮巨像增益及敌易伤都消失，不能把当轮减伤延续；仅核本局组合，不定拿牌优先级或独立整战胜因。','evidence':[{'run':rq,'floor':49,'turn':1,'role':'support','note':'末试d400105—400109/s412949—412953：弹珠袋易伤1，防御＋9挡/敌3力25攻；巨像＋后17挡/敌6力14攻，T1血4保持。'},{'run':rq,'floor':49,'turn':2,'role':'support','note':'s412954—412960/d400110—400115：巨像与敌易伤消失，开始敌6力22攻；防御激怒到9力25，突然一拳虚弱后18；我方4血6挡死亡，敌终44/111。当前live已有colossus接线，未定位新代码bug。'}],'first_run':rq,'prior':'unknown','prior_runs':[],'prior_note':'用ledger.py find --character silent分别检索巨像/COLOSSUS，并按##标题筛静默猎手更早复盘，未见此机制的可比记载；没有使用标题无角色的铁甲战士记录作先验。当前代码已有相关分支不等于更早实盘已经做对。','status':'observed','where':{'lessons':[rq]}}
(p/'RQCHNN0W72KF-new-mechanic.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n')
rqu=[update('silent-0228',rq,48,8,'d399996/s412841—412886：休息50→70，女王/聚合体首试8轮70→4且T1用尽槽0毒；无恢复入F49。大脑原计划已知两王，只补support，不因末局失败记策略repeat。'),update('silent-0332',rq,40,None,'d399911—399913：同seed607614716两次nonpositive-hp，won=true/died=false/23turns，第三次42<300不给数字；旧资源契约故障重现，完整resources/steps截断。','repeat'),update('silent-0332',rq,48,1,'d400001—400003及400026—400028：seed614798807/46797397各两次pending后第三次degraded，样本159/0不足300不给整场数字。live boss-sim.ts:328/:338契约失败；fix-queue-v4.md已有，根因未知。','repeat'),update('silent-0028',rq,49,2,'末试s412954—412959/d400110—400114：A10现场ENRAGE3，防御把6力22攻升到9力25攻，突然一拳虚弱后18；必备工具能力未加敌力。是本局条件support，不将旧激怒2普遍化。'),update('silent-0027',rq,48,5,'s412868—412869：触媒＋ACCELERANT2，女王16毒使302→257扣45=16+15+14；T6的28毒再结81。仅本局兑现，末胜不推独立胜因。')]
vu=[update('silent-0228',v,48,9,'s413680—413748：休息32→52后沙漏9轮52→11，T1饮再生/速度；蕨草下一战补肌肉/速度但HP仍11，六试最终败。已明知连续双王，不记策略repeat或假设留药转胜。'),update('silent-0028',v,49,3,'末试s413908—413914/d400924—400928：6力42攻、玩家易伤1；防御到9力，尖啸自身激怒+3减6后回6力，生存者再到9力46攻，总挡15、4HP死亡。support激怒条件与临时减力并算，不证明另一顺序能胜。'),update('silent-0418',v,48,2,'d400754护栏把损19/伤9换损7/伤0的计划妥当＋生存者，后缀实际未完整兑现；d400755另选药瓶，T2 HP57→45净损12。不能把名义12血差写成实际省12血，未定位新纯bug。'),update('silent-0059',v,48,9,'s413745→413746：末沙漏115血47毒，ACCELERANT2，玩家16HP4挡、手中9伤凋萎；实际毒胜但HP16→11。缺逐击归零，不把胜前持牌惩罚抹去。'),update('silent-0027',v,49,2,'末试s413906—413908：触媒＋建立2，21HP敌4毒实际结9后剩12/111；T3只剩1毒实际仅扣1到11。另F48T5的22毒实结63；不把能力持有当充足当前毒。'),update('silent-0253',v,49,2,'末试s413903—413908：速度药槽1实饮，敏捷1→6，普通后空翻0→11挡；下一轮敏捷回1。总18另含首能力冰晶7，不把全部格挡归药或当永久敏捷。'),update('silent-0173',v,49,2,'末试s413906→413907/d400922：触媒＋是本战首次能力，格挡11→18补7，随后T3归零。与同轮速度/后空翻11分源；无独立整战收益对照。')]
for rid,rows in [(rq,rqu),(v,vu)]:
 (p/f'{rid}-ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
ids=sorted({x['id'] for x in rqu+vu});snapshot={}
for ident in ids:
 r=subprocess.run(['python3',str(root/'learner/ledger.py'),'show',ident],capture_output=True,text=True,check=True);snapshot[ident]=json.loads(r.stdout)
(p/'ledger-before-targets.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n')
print('待更新',ids)

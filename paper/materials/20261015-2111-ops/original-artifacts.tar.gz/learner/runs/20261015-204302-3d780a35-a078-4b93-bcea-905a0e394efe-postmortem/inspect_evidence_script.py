import json,collections
from pathlib import Path
p=Path(__file__).parent
for rid in ['RQCHNN0W72KF','VNSXWCWXR3VW']:
 d=[json.loads(x) for x in (p/f'{rid}-decisions.jsonl').open()]
 s=[json.loads(x) for x in (p/f'{rid}-states.jsonl').open()]
 print('\n',rid,'WINDOW',d[0]['row']['ts'],d[-1]['row']['ts'])
 print('Dkeys',d[0]['row'].keys(),'Skeys',s[0]['row'].keys())
 print('Dfirst',json.dumps(d[0],ensure_ascii=False)[:2000])
 print('Sfirst',json.dumps(s[0],ensure_ascii=False)[:2000])
 resources=json.load((p/f'{rid}-resources.json').open())
 print('Rkeys',resources.keys())
 for w in resources['combats']:
  print('FIGHT',w['sequence'],w['floor'],w['enemies'],'entry',w['entry'],'last',w['last'],'exit',w['exit'],'end',w['end'])
 for x in (p/f'{rid}-sl-attempts.jsonl').open():
  z=json.loads(x);r=z['row'];print('SL',z['line'],json.dumps(r,ensure_ascii=False)[:1200])

import json,re,hashlib
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2')
checks={
 'RQCHNN0W72KF':[(412841,70,70,None,None),(412884,4,70,None,None),(412886,4,70,None,None),(412959,4,70,6,18),(412960,0,70,0,18)],
 'VNSXWCWXR3VW':[(413680,52,69,None,None),(413746,11,69,None,None),(413748,11,69,None,None),(413913,4,69,15,46),(413914,0,69,0,31)]}
result={}
for rid,items in checks.items():
 ds=[json.loads(x) for x in (p/f'{rid}-decisions.jsonl').open()];ss=[json.loads(x) for x in (p/f'{rid}-states.jsonl').open()];by={x['line']:x for x in ss};r=json.load((p/f'{rid}-resources.json').open());sec=(p/f'{rid}-section.md').read_text();evidence=[]
 assert len(r['combats'])==27 and all(x['entry_is_turn_one'] for x in r['combats'])
 assert len(re.findall(r'^- \[(?!记录)',sec,re.M))==3
 assert len(re.findall(r'^\| F',sec,re.M))==27
 with (root/'logs/states.jsonl').open('rb') as f:
  for ln,hp,mx,b,inc in items:
   z=by[ln];f.seek(z['offset']);raw=json.loads(f.readline());assert raw==z['row']
   st=raw['state'];assert st['run']['current_hp']==hp and st['run']['max_hp']==mx
   pl=(st.get('combat') or {}).get('player') or {};en=(st.get('combat') or {}).get('enemies') or []
   if b is not None:assert pl['block']==b
   if inc is not None:assert sum((i.get('total_damage') or 0) for e in en for i in e['intents'])==inc
   evidence.append({'state_line':ln,'offset':z['offset'],'ts':raw['ts'],'hp':hp,'max_hp':mx,'block':pl.get('block'),'enemies':[(e['enemy_id'],e['current_hp']) for e in en]})
 sl=[json.loads(x)['row'] for x in (p/f'{rid}-sl-attempts.jsonl').open()];last=[x for x in sl if x['floor']==49];assert [x['turns'] for x in last]==([2]*6 if rid.startswith('RQ') else [4,5,3,3,5,3]);assert [x['result'] for x in last]==['predicted_death']*5+['died']
 assert sum((x['row'].get('chosen') or {}).get('action')=='use_potion' for x in ds)==(9 if rid.startswith('RQ') else 26)
 assert sum(x['row']['label']=='rest/plan' and (x['row'].get('chosen') or {}).get('option_index')==0 for x in ds)==(9 if rid.startswith('RQ') else 6)
 for x in r['combats']:
  for key in ['entry','last','exit']:
   y=x.get(key)
   if y:assert by[y['line']]['row']['state']['run']['current_hp']==y['hp']
 result[rid]={'verified':True,'key_frames':evidence,'sl_turns':[x['turns'] for x in last],'section_sha256':hashlib.sha256(sec.encode()).hexdigest()}
 print(rid,'关键HP/挡/意图/死亡回合及全部资源表验证通过')
(p/'verified-numbers.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

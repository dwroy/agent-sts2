import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261015-204302-3d780a35-a078-4b93-bcea-905a0e394efe-postmortem'
ids=['RQCHNN0W72KF','VNSXWCWXR3VW']
for name in ['decisions','run-plans','sl-attempts','states','run-config']:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists(): continue
 handles={rid:(out/f'{rid}-{name}.jsonl').open('w') for rid in ids}
 counts={rid:0 for rid in ids}
 with p.open('rb') as f:
  off=0
  for ln,line in enumerate(f,1):
   for rid in ids:
    if rid.encode() in line:
     try: row=json.loads(line)
     except ValueError: continue
     if name=='states' and (row.get('state') or {}).get('run_id',row.get('run_id'))!=rid: continue
     handles[rid].write(json.dumps({'line':ln,'offset':off,'row':row},ensure_ascii=False)+'\n'); counts[rid]+=1
   off+=len(line)
 for h in handles.values(): h.close()
 print(name,counts,flush=True)

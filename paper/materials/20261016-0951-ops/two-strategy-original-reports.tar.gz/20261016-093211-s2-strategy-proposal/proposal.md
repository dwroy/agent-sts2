# 本批十项策略提案逐项复核

批次：20261016-093211-s2-strategy-proposal；角色silent；基线 `112895c82a326d853323d9df5cc8d56f2c73f231`。普通队列，10个原CLI id全部处理，不新增或重领提案。

结论：全部waiting。已核局部子项与整份提案区分；不新增打法、参数或源码。未改变旧结论，没有新增须经ops→watcher→Roy告知的游戏反证。

共同方法：原提案逐份SHA核同并保存原字节txt；runs先核角色，八流用共用提取入口冻结字节截点，再逐行seek原日志复核。只从本角色证据推断，不读取其他角色私有知识。

共同切分：15局为本十项原证据复核集，含派发10个锚点和原文直接引用5局；同局SL只算相关观测，不拟自由参数或同时训练/验证；未来独立Silent A10完局才能作策略留出。原113/115/116局全史模型没有在本批重建，不把这些历史计数冒报成本批覆盖。

共同回退：本批无行为差量，无需回退；未来任何实现须单独源码提交、固定原帧撤码失败/恢复通过、自测和live核验，并仅撤本角色已验证分支，保留原日志、原提案、并行知识与账本历史。

来源任务和实现任务沿各原CLI条目source_task→strategy-proposal；授权Roy-2026-10-07-learning只授权实施，不提供游戏事实。每项原文仍为其原规则/拟行为/切分/反例完整定义。

## 1. silent-proposal-03754e1265894000

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-mechanisms.md；SHA256 `518c139723decc4238c7ea5641e671c8738ec240118ff5140ca503612295599f`。

账本：silent-0006、silent-0011、silent-0013、silent-0080、silent-0088、silent-0101、silent-0232、silent-0253。

证据局/层/回合：RC61MFQM63Y6 F17T2/T11、F23T3/T4、F29T3/T4、F33六试T1/T4。

本批支持：F23原帧285222—285229：预判后净敏1，速度饮后6，斗篷加12挡后敏5，刺击后敏4，防御加9挡；小刀本体未扣血但第三攻击加4挡。

反例/限制：这些帧只核当次已建立效果。F33失败不是基础公式反例；未建立的幻影/毒雾不能按整场持续收益计入。

**waiting：**八组件原提案仍缺逐项至联合生产消费者的完整固定校准，尤其柔嫩/脆弱/翻倍/被动挡同时出现时的来源及结算对应；局部实帧不能证明整项实现。

旧/拟行为、预期与验证：保留当前逐牌计算；后续冻结原帧与相同知识输入，按各组件逐项核增益时点、取整、临时层撤回和联合输出，其他角色与未观察进阶作等价对照。

## 2. silent-proposal-ab055ef7dfbb44e5

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-survival-and-ghost.md；SHA256 `c5490a44836c3900e1d03b59370dea8c076a8b5435236f7a5e575e4c0b516b17`。

账本：silent-0140、silent-0069、silent-0005、silent-0206。

证据局/层/回合：XTSV1U9JD34T F49六试T1/T3/T4。

本批支持：286897—286899核幽灵一层、来袭26→1、HP23不变及次轮余挡10；286986夜魇3、1HP/6挡对16，286987死亡，复制未到手。

反例/限制：本局早喝幽灵已兑现零损，不支持必须延后；所有已执行后段均死，没有去掉夜魇就能活的真实对照。

**waiting：**幽灵单层已有真实live祖先源码；夜魇收益的可执行复制后继、存活条件消费者，以及延后饮药完整整战对照仍缺，不能将整项登记duplicate或改持有价。

旧/拟行为、预期与验证：保留原饮药/夜魇排序。后续须同抽序核T3/T4、死亡前未来收益与实际后继；已死收益归零须在真实生产消费者输入中验证，不由结果倒推新规则。

## 3. silent-proposal-0129c465c6f5bd79

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-replay.md；SHA256 `bf425049a5868e3bec28ff845f0dcc2f5560594b3b85b4380a378ab2295bdcdc`。

账本：silent-0009、silent-0021、silent-0024、silent-0057、silent-0079、silent-0090、silent-0140、silent-0164、silent-0205、silent-0268、silent-0271。

证据局/层/回合：BTSRF7JL1W1Y F17四试/F30/F31T2；XTSV1U9JD34T F33/F48T8/F49T4。

本批支持：BTS286158—286163核生存者后突然一拳离手、13牌挡且35→21；XTS286893—286896核毒胜32→23、无恢复入F49；夜魇死亡前标记不算复制到手。

反例/限制：普通单弃及连战毒胜保血已有源码和固定夹具；旧0268、0271子项不能当本批新缺陷。耳环接管内部动作未记录，不能凭余能量推可执行牌。

**waiting：**普通单弃与毒胜保血为已实现子项；接管内部执行、复制后继及抽弃重问后的联合候选归属未闭合，不能以两个子项关闭整份提案。

旧/拟行为、预期与验证：保留现有窄修复，下一步逐动作核弃牌、重问、接管和下一轮到手；完整执行缺口与模型差额分列，不设新固定击杀序或SL门槛。

## 4. silent-proposal-abe9d5d0be109a9f

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-resources.md；SHA256 `21263e5782fa17b030141cf5d79a9968115beeb1a99dc66f6309cbac9b51957b`。

账本：silent-0019、silent-0020。

证据局/层/回合：BTSRF7JL1W1Y F17/F30/F31；XTSV1U9JD34T F33/F47/F48T8/F49。

本批支持：XTS F48胜后23原样进入F49，胜战耗血与恢复分列；BTS F31实际入35的T2牌挡13后仍损14。原提案中的营火、战斗回复与SL原来源保留。

反例/限制：赢战不等于无代价；相关SL恢复并非新回血或新获得药。没有同条件改线、留药或锻造胜负对照。

**waiting：**当前已有资源和连王接口，但逐源资源到终局/路线消费者的匹配输入校准不完整，缺同条件路线/留药/锻造完整后继，不能拟安全血线或药价。

旧/拟行为、预期与验证：保持当前评分；以实到HP、药槽和消耗/恢复来源逐节点核当前消费者，明确未来火与SL恢复来源，后续独立新局留出验证。

## 5. silent-proposal-f16527e59b5cc1e0

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-mechanisms.md；SHA256 `a71d6c87441d33115c5a8f4d3e0103673fd07798805978646f3a3961fb749079`。

账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0016、silent-0027、silent-0046、silent-0069、silent-0095、silent-0128、silent-0196、silent-0241。

证据局/层/回合：BTSRF7JL1W1Y F17末试T5/F31T2及末轮；XTSV1U9JD34T F48T8/F49T1—T4。

本批支持：BTS同一窗口覆甲3与13牌挡分列，未阻止其他攻击损14；XTS幽灵后钳子只留10、后续仍损血，毒胜前32→23实到后战。

反例/限制：覆甲当前层不能当每轮固定挡；步法不能追补旧挡，幽灵不能作未来恒定减伤。失败不反驳已兑现局部机制。

**waiting：**临时属性撤回、触媒/毒触发、留挡与敌成长的联合分源生产回放未齐；日志端点不提供完整毛伤或每个组件的独立因果。

旧/拟行为、预期与验证：保留原行为；固定输入须分别核牌挡/覆甲/留挡、力量撤回、敌成长与毒结算，之后再核联合消费者；不设用药时点或留药阈值。

## 6. silent-proposal-7a8e9ccb7e646538

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-combat.md；SHA256 `e365da8858d06c845b8f83b662fad011721eeab59fd4e0dce4c46aa3925b640f`。

账本：silent-0005、silent-0006、silent-0011、silent-0021、silent-0024、silent-0027、silent-0034、silent-0077、silent-0079、silent-0123、silent-0129、silent-0180、silent-0221。

证据局/层/回合：9Z9H2EXKLF3T F35、F48三试T2/T4/T7—T11。

本批支持：末试287985—287991：首挡32后可见0→20复活；288000/288003/288004首偏折18、后偏折9、防御10共37，288005仍18→3。

反例/限制：复活净HP上升不能当少受伤；同局读档相关，后续熔炉时点和抽牌同时改变。死亡后未执行击数不得预支反伤。

**waiting：**缺逐击未截断伤害及完整候选归属，SL替换与后续药水/抽序未受控，不能由局部净差拟SL血价或认定整战改线更安全。

旧/拟行为、预期与验证：保留SL/终局排序；按实际0HP中间帧、复活和每次重问审计；后续整战对照须分实际轮窗与单题预测，不以24/24全败作必死事实。

## 7. silent-proposal-cd9f76184de6e29a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-resources.md；SHA256 `54f562100db0a2dbc72c07a5b1411e42838e3370221a23ea4b769795196c66aa`。

账本：silent-0019、silent-0020、silent-0243。

证据局/层/回合：HMVJKM56S4Q8、F4QKG4J1AJJZ、G403VCZ3BH1B、25226ZFLNR1J、JLN5SK17W4FQ、JMH5C51RLN4E、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、9Z9H2EXKLF3T 的F17→18/F33→34（已到节点）；9Z F35/F38/F39/F42/F45/F47/F48。

本批支持：本批15局全部可到跨幕端点重新核得22对，同上限实际回复均为floor(缺失HP×0.8)，逐对原行/SHA见act-transition-observations.json；A9三局和A10十二局分列。

反例/限制：这22对不是116局资源表重算，也不提供路线/锻造受控收益；投影与实到节点条件不同不能直接归因模型误差。

**waiting：**局部跨幕公式成立；原116局资源模型未在本批重建完整历史输入与消费者校准，独立路线收益缺失，不以22对或已存在结构接口关闭整项。

旧/拟行为、预期与验证：只保留本角色已观察A9/A10边界；后续重放原资源模型时分营火、上限变化、胜战耗血和SL恢复，不跨未到节点预支回复。

## 8. silent-proposal-292f6731bdb9b669

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-044302-postmortem/proposal-poison-potion.md；SHA256 `2f943d1aee2e7ed6d1ddfa07b469a4488d27525bad4714cec58f6a94917a8c63`。

账本：silent-0087、silent-0020。

证据局/层/回合：7X0W3U8TVA2A F31T1—T13，尤其288470—288472。

本批支持：后段零毒→7、HP25未即时变，结束扣7到18；前段旧毒8另扣至4，中段0→25接续，玩家1HP/14挡后死亡。

反例/限制：已饮仍死反驳有7毒就足够救场，不否定可能的早用价值；单一头骨组合不能隔离基础药效，也未见其他目标/既有毒/人工制品对照。

**waiting：**现有observedPoison是全候选目标共用数值，只由双王或特定恶魔组合提供。本局只有后段零毒一次观测，缺其他可选目标、既有毒与接续组合的适用证据及持有价；不能把7填为全局模型。

旧/拟行为、预期与验证：保持全部可喝选项和未知展示；后续按目标/现有毒/遗物组合固定校准，不能重复加头骨，也不能把未知持有价当已校准0；早喝整战收益仍待独立证据。

## 9. silent-proposal-0802f69b28d25079

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-sl.md；SHA256 `79e1696de63d19810eb442ee3afa83dd5795f1693f4c9f4a48433fef014e3596`。

账本：silent-0079、silent-0019、silent-0044、silent-0080、silent-0253、silent-0011、silent-0214、silent-0189、silent-0046、silent-0222、silent-0243、silent-0262。

证据局/层/回合：MTQ0EUBJ3R6T F19/F20/F23四试T3/T5—T6；states288806—288812与288899—288905。

本批支持：原线29挡、HP10→10、敌合计净扣13；替线19挡、HP10→2、净扣19。两次速度已饮，替线多损8只多即时6；原线和替线整场都没有实到胜局。

反例/限制：四次来自同一局；后段抽序和能力建立不同，T5/T6敌残不构成独立胜率比较。两只MYTE同型，工具不认证跨帧实例归属。

**waiting：**当前已有SL即时资源对比诊断，但缺独立A10留出、受控完整后继及同生产输入校准；不能由8血/6伤制定阈值或替换饱和探索排序。

旧/拟行为、预期与验证：保留原SL探索。后续将HP缺口、即时伤、存活轮数和整场结局分列；不可把不更常死亡称更安全，也不可把有限全败样本称实盘必死。

## 10. silent-proposal-763a4b9d9f17b815

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-mechanisms.md；SHA256 `989dcea2a0dd5cad05d276157131dec57fdb9d17b2bdab66cbd25f32e0e9ad39`。

账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0044、silent-0046、silent-0053、silent-0080、silent-0087、silent-0189、silent-0214、silent-0222、silent-0235、silent-0253。

证据局/层/回合：7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T F11T1/F17T4—T8/F20T3/F23T2—T5。

本批支持：MTQ速度5敏与29/19挡的实际兑现、次轮临时层消失；7X后段7毒与实际死亡分列。知识条目存在不是所有机制已被模型消费的证明。

反例/限制：两局没有提前建立磨蚀、保药或不同路线的受控胜局；能力未建立时不记持续收益。单次药效不拟持有价。

**waiting：**十四项临时属性、持牌伤、昏眩、能力与药效时点缺逐项到联合生产消费者的完整校准，不能将若干已实现机制与文字支持合为整项duplicate。

旧/拟行为、预期与验证：保留各旧机制和策略；用对应原帧逐项核牌挡/力量撤回/毒素/能力/昏眩，再验证联合后继，其他角色与未观察进阶保持等价。

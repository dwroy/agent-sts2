# 静默猎手策略提案批次报告

十项提案全部逐项复核，保留waiting及具体缺口。没有充分证据完成新的整项策略修改或认证整项duplicate；不新增源码、知识、参数、提交、live合入、版本或shipped。逐项证据、账本、反例、预期及继续条件见[proposal.md](proposal.md)与dispositions.json。

## 身份与范围

- batch：20261016-093211-s2-strategy-proposal，task=strategy-proposal，character=silent。
- 完整base：`112895c82a326d853323d9df5cc8d56f2c73f231`。开工干净，按普通批次git merge --no-edit main，结果Already up to date；HEAD保持该值。无research_request或implementation_request，不借另一批running专题身份选题。
- 只处理dispatch.json的十个proposal_ids，原提案SHA十份全部一致，原字节另存original-proposals/*.txt；不重复登记id、不补写旧复盘。
- 派发runs保留原十锚点。额外只核原提案直接引用的9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T。共15局全由runs.jsonl核为SILENT：A9三局、A10十二局，未混合角色或进阶统计。
- 原生运行证据native-runtime.json：gpt-6.1-sol / xhigh，service_tier=default。任务题面写high，实际宿主会话/请求是xhigh；本批没有改配置、重启或声称已切换high。没有另派agent。

## 原日志与消费者核查

原日志共八流22,424所属行，逐流source_size、计数、每行offset/bytes/SHA保存于evidence/及evidence/streams/。raw-validation.json独立seek每条原字节并核SHA/JSON/显式身份，states逐行核角色，全部通过。run-plans按显式run归属，正文提及不当所属；fight-plans本截点选中0行，仅说明该截点为0，不据此断言原日志缺失。states/decisions全源扫描各2条无效JSON、brain1条，均未作为选中本局证据；全部不完整末行计数0。

| 流 | 所属行 |
|---|---:|
| states | 11008 |
| decisions | 10609 |
| sl-attempts | 109 |
| run-config | 16 |
| run-plans | 97 |
| brain | 570 |
| runs | 15 |
| fight-plans | 0 |

六组限定层数固定输入沿原learner/audit-selection.ts执行，输入保留真实_line及_source_sha256，decisions仅去agent_view。第一次tsx CLI六组都因沙箱listen EPERM失败，原input/output/stderr与SHA完整保存在audit-first-attempt/，不是代码或游戏失败。随后以Node --import同一tsx loader、原生产/离线函数及同一输入执行，六组exit均0，输入SHA与首次完全一致；未修改生产函数或放宽断言。最终回执见audit-receipts.json，没有缺decision_id的排除项。

| 局号 | 限定层 | 题段 | 动作 | 轮窗 | 可核端点 | 未知 |
|---|---|---:|---:|---:|---:|---:|
| RC61MFQM63Y6 | 17,23,29,33 | 94 | 332 | 55 | 29 | 26 |
| XTSV1U9JD34T | 33,48,49 | 69 | 211 | 49 | 21 | 28 |
| BTSRF7JL1W1Y | 17,30,31 | 62 | 307 | 53 | 36 | 17 |
| 9Z9H2EXKLF3T | 35,38,39,42,45,47,48 | 131 | 332 | 50 | 33 | 17 |
| 7X0W3U8TVA2A | 30,31 | 42 | 99 | 18 | 0 | 18 |
| MTQ0EUBJ3R6T | 19,20,23 | 32 | 169 | 33 | 16 | 17 |

合计430题段、1450动作、258轮窗（135可核、123未知）、1056相邻动作端点、2终态端点。工具actual_full_candidate_result全部保持null，不认证原候选整线或排序因果。7X的18轮窗全部unknown，手工原帧三点只证明局部药效，不能覆盖该消费者缺口。接口completed/pending、候选预测、整轮净HP和实际完整执行分别列账；未重跑Boss模拟、LLM或联网。

## 支持与边界

44项原帧检查全部首次通过，见check_materials.py、material-checks.json、material-source-refs.json。它们是材料算术/事实核验，不是生产tsc/vitest或撤码红绿。

- RC F23T3重新核预判净敏1、速度后6、斗篷12/防御9及折扇4的不同来源。BTS F31T2生存者后唯一突然一拳离手，牌挡13后35→21，不能沿旧后继预测当实际。
- XTS F48T8为32→23并以23入F49；F49T1幽灵单层使26来袭变1、23HP不变，次轮钳子余10挡。末T4夜魇标记3但复制兑现前死亡，没有去夜魇或延后药水的受控胜线。现有局部修复不关闭原整项策略问题。
- 9Z F48末试T8首挡32，实际中间帧0→20复活；T10首偏折18、第二张9、防御10共37仍18→3。净HP不能代替完整入伤，未执行击数不补反伤，读档改变的后续抽序/熔炉不能隔离成一条候选收益。
- 7X F31T13后段零毒实加总量7，HP25当步不变，结束后18；前段旧8毒另结算，中段0→25接续。已饮仍死只否定这次足够救场，不否定早喝可能性；无基础药效与头骨隔离、其他目标/既有毒对照或持有价依据。
- MTQ F23T3原线29挡/零损/净扣13，替线19挡/损8/净扣19，两条都已饮速度。同局四试非独立A10留出；多损8多扣6不能拟新8点门槛或宣称饱和替线更安全。
- 十五局能到达的F17→18/F33→34共22对同上限端点均符合floor(缺失HP×80%)，见act-transition-observations.json；未重建原116局资源表，不外推更低等级、未知组合或独立路线收益。

## 源码与历史输入

source-audit.json绑定只读live `0e7998bfa8df267dcf8835a57949bdb982c9feb0`：19相关生产/离线叶15个相同，4个差异叶（card-model、rollout-live、sl/explore、sl/judge）的git diff --binary全部仅Roy/Dai历史注释差，原patch保留，不覆盖live。没有借这次读取声称当前live已完成新精确全套校准。

已核真实live祖先的子项来源：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`（含幽灵一层、普通单弃、毒胜保血及选择阶段审计源码/固定夹具）；`fdaf787a372880b0438e73bcac7e6d2168b038ed`（单动作观测）；`07192e6faf1da89c2719e22b3e0c280617795f22`、`e75438488df159b2e8e9d3458cf219b39aadd933`（离线追踪/轮窗）；`e1a467e18a0dfa8d99046a24ff4c0e1af59278c8`（双Boss资源接口）。这些是旧子项源码来源，不是本批实现、合入或十项整项duplicate。

16份run-config覆盖15局（JMH有两份），历史完整40位源码commit全部真实存在，列出的dirty_files全部属于knowledge/notes，无所列源码dirty路径。原提案“dirty完整源码未知”原文保留；精确缺口是当时刷新知识/移动表字节及联合消费者输入未复原，而非源码commit找不到。不能以当前代码加当前知识冒认历史运行树。

## 账本与交付

本批仅经根learner/ledger.py update为46个已关联账本追加proposal.md/report.md追溯和waiting核查说明，by=learner:strategy-proposal；不重复原证据support/repeat，不改claim、首证、prior、evidence、status或version，不将原已shipped子项降回proposed。CLI输入/输出、即时前后保护检查见ledger-update.json、ledger-update.stdout.txt、ledger-trace-verification.json；最终状态以实际CLI回执为准。十个原code_proposals复用，implementation_domains=[]表示本批未实现源码域。

没有源码或知识变更，tests固定为tsc/vitest/cases均null；撤源码失败/恢复通过不适用，没有运行或冒报生产测试成功。无需live合并、eval版本、上线双通知或shipped，未推送、运行play、停止对局或删除原件。不关闭学习入库/量化学习等宽父要求。HEAD和工作树最终核验见head.txt/git-status.txt；机器回报见result.json，运维交付入口为本目录proposal.md与report.md。

# 静默猎手本批策略提案核验

记录时间：2026-10-16T09:42:37+08:00（写入前实际执行 date -Is）。批次：20261016-093211-strategy-proposal。来源任务 strategy-proposal，实现任务仍为原独立 strategy-proposal 链，授权 Roy-2026-10-07-learning。

本批十项全部 waiting：已证局部机制与已上线窄修复保留；没有隔离出新的确定源码差额，证据不足以修改策略参数、SL门槛、药水或终局血价。无源码修改、无提交、无合入、无新增版本，亦不登记 implemented 或 shipped。

基线与最终 HEAD：`112895c82a326d853323d9df5cc8d56f2c73f231`。初始 git status 干净；普通批次执行 git merge --no-edit main 返回 Already up to date。learn.json 的角色/任务/五局集合/工作树与本题一致，reason=proposal，恰有十个 proposal_ids，无 proposal_repair、research_request 或 implementation_request。普通专题入口 notes/strategy-research-silent.json 绑定的是旧20261010-150327，未匹配本批；不读取另一专题替代身份，不领取其他提案。

八流共6606条本批所属原行，均逐行回读 source/offset/bytes/SHA/原JSON和显式身份。五局在 runs.jsonl 均为 SILENT/A10，结束于2026-10-07，均负局。提取的3238状态、3138决策、31 SL、5 run-config、26 run-plans、163 brain、5 runs、0 fight-plans，各流冻结字节截点与计数见 evidence/evidence-manifest.json；后者0只表示本截点未选到该流的所属记录。源日志其他位置有states2/decisions2/brain1条无效JSON，未作为本批证据。未混入其他角色知识、未使用预训练游戏事实或把正文提及当所属局。

十份原提案原字节均已保存，来源路径、长度和SHA见 original-proposals-manifest.json。每项既有账本和原文如下；原提案包含的其他角色内历史统计仅保留出处，本批没有重算全历史，不能把其分母算成本次分析。

| 原提案ID | 本批证据窗口 | 既有账本ID | 处置及缺口 |
|---|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | NHA2KW0RB7VP F33 T1；states 283391/283396/283397 与 283502/283506/283507 | silent-0019, silent-0020, silent-0065, silent-0264, silent-0079 | waiting；同指纹T1已核多16净伤、多损6血；缺同抽序同预算整战、能力累计兑现及路线/留药对照，不能确定新SL或终局门槛。 |
| silent-proposal-47be799a87af03be | P74C04AEPL1F F23 末次T3；states 284816–284821 | silent-0205 | waiting；四个合法弃牌快照及后继取消提示已有实现；快照明确不推演动态牌面、目标、弃牌触发和续步生存，保留精确切击的分支未实打。 |
| silent-proposal-3a5274da3c42672a | P74C04AEPL1F F17 T1–T9、F22 T1–T6、F23 末次T3 | silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006 | waiting；局部机制实帧成立，但主怪死亡中间来源缺帧；缺连续用药、召唤复活与下一战资源的完整联合消费者回放，未隔离新源码差额。 |
| silent-proposal-bc4b92d590f2c4ce | G33HU22H2543 F48 T1及末次T8；P74C04AEPL1F F23 末次T3 | silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266 | waiting；投斧首牌身份和普通单弃已有实际live祖先子项；缺跨重规划执行归属、余像累计兑现及动态弃牌分支联合验收，不能关闭整项。 |
| silent-proposal-f52fbbab4dccc3b4 | P74C04AEPL1F F22→F23；G33HU22H2543 F48 末次T7–T8 | silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064 | waiting；P74赢战53→9与下一战9血入口、G33末战资源边界已核；缺逐来源消费者账及同条件路线、休息、SL或保药的完整后继。 |
| silent-proposal-10f37c0edd3d24a6 | G33HU22H2543 F48 末次T7–T8；P74C04AEPL1F F17/F22/F23 | silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069 | waiting；五局历史源码提交均可定位，dirty路径仅knowledge/notes；缺历史刷新知识和移动表原字节、完整组合联合回放及独立校准，未隔离新错误。 |
| silent-proposal-3f82387e2e179703 | RC61MFQM63Y6 F33 首/末T1、第三试T4；decisions 279021/279197 | silent-0079, silent-0027, silent-0065, silent-0080, silent-0088 | waiting；同指纹T1已核少7净伤、多损4血；首末题分别3轮2样本、5轮24样本，缺同预算受控整战及累计能力收益，不能据此改SL排序。 |
| silent-proposal-aee21084c991abd3 | BTSRF7JL1W1Y F31 T1–T4；decisions 279852/279854；states 286148–286174 | silent-0128 | waiting；醒虫成长与覆甲实帧成立；抽弃前3轮4样本、重算后5轮4样本，缺逐样本抽序/动作与最终实线配对，一次死亡不足调权或强制集火。 |
| silent-proposal-df37594e9b12debf | RC61MFQM63Y6 F33 第三试T4、首/末T1；原提案另列F17 T11呼唤，本批未对其重跑联合消费者 | silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268 | waiting；普通单弃取消唯一后继已有实际live祖先实现；缺跨选择完整执行归属、累计能力及呼唤自损的联合消费者验收，局部修复不关闭整项。 |
| silent-proposal-42e81c83b2e1e56b | RC61MFQM63Y6 F33 T1 52血入口；F18/F27路线与回复引用原提案，不重算其历史总体统计 | silent-0019, silent-0020 | waiting；原提案的实际回复和F33的52血入口有记录；本批未恢复逐来源路线消费者账及同条件后战对照，不能确定新路线或终局HP价格。 |

## 支持、反例与结论限制

1. **即时血价可核，但未推出新排序。** NHA F33首/末T1同指纹，30→29/23，14/8挡，端点净扣8/24；RC F33首/末T1同指纹，52→48/44，16/12挡，端点净扣30/23，末线确有触媒1层。配对结果分别为多16伤多损6血、少7伤多损4血。净扣是同名单观测端点，不等同单卡总伤害或整候选因果收益。同局重打不当独立样本；后续抽牌、出牌和目标不同。RC首题3轮2样本，末题5轮24样本，不能混称同预算24/24全死的受控实验。完整能力价值、留药/换路线后的胜负均未知。
2. **弃牌不许沿用已经取消的后继预测。** P74 F23末T3为1HP/16挡对石16+卵8，四个合法选项都在，精确切击当时0费、当前7伤并明确依赖手牌。终态玩家0HP、石眩晕、卵仍2HP；局部完全格挡与另一敌人继续造成伤害同时成立。首试/第三试卵已在早轮结束，目标和动作不同，是“固定必须弃贪婪/先杀卵即可获胜”的边界，未执行保留精确切击分支不能写必胜。
3. **药水和机制仅按已见窗口核证。** P74 F17滑溜下火焰182→181、滑溜8→7；F22寄生T3归零后T4恢复21，T2/T4实际各损20/24，53→9虽赢但F23仍9血空药入口。主怪最后归零缺中间帧，净本体差不能当全部需伤，也不能把未知来源或缺失资源消费者账补为0。没有保留该瓶药/少损前战血后完整胜局的对照，不能由败局指定新留药阈值。
4. **已施放能力与未执行计划分开。** G33末T8余像已建2层，三张牌及其基础挡实际12，31显示攻击仍需损19，12血实际被扣到0，存活至少差8；不能拿死亡封顶12当完整入伤。BTS F31 T3/T4甲虫力量2/4、末轮22攻，玩家14血、5挡加1覆甲仍死亡。抽弃前题为3轮4样本，重算后为5轮4样本；原选最优被重问替代，一次死亡不是概率模型错误或强制集火规则的充分证据。F17曾实际建立步法+与F31没有建立的情况不混用。
5. **路线与SL恢复不混作治疗。** 真实赢战掉血和下一场入口有直接记录；原提案记载的休息、遗物、幕间回复与读档恢复保持分账。当前并未恢复同条件路线、休息、留药完整后继及逐来源消费者账；原总体统计不充作本批新校准。不新增固定安全血线、路线禁令或终局血价。

拟合方法：未拟合任何新自由参数。本批仅五个原派发A10锚点的固定回归，七个战斗楼层窗口，不是新局时间后置验证，更不是全历史胜率评估。预期可验证的行为仍沿原提案：保留合法选项、让计划取消/即时资源/未兑现能力可核，未来新增规则必须有联合消费者与新局校准证据。

## 当前源码、既有实现与消费者范围

冻结只读live为 `0e7998bfa8df267dcf8835a57949bdb982c9feb0`。核对8个相关执行/审计源码叶，7个原字节相同；sl/explore.ts仅3处既有Roy/Dai注释差，未据此冒称两完整运行树相等。具体文件SHA、Git blob与祖先关系见 source-audit.json。

- `e784dd9f043bf87c29109573f48975f9903280d3` 为真实base/live祖先：投斧首牌键修复，不能关闭bc4宽项中的跨选择执行与累计能力验收。
- `bf423c173d3be348a4ad714e1d26516df619ff41` 为真实base/live祖先：普通生存者消费唯一弃牌、取消虚构后继；多选保留 pendingSelection。不能据此关闭df宽项。
- `4b0823f519f1b724d6cff2b1cd50b74146dc4a9d` 为真实base/live祖先：弃牌后保留手牌及单卡费用快照。源码明确说明不推演弃牌触发、后续牌面/伤害/格挡/剩血，因而不能把快照当完整分支安全证明。
- 暂停计划提示代码现由真实祖先 `5b56a452bb9be14d620b368ec46974c1b57901ca` 引入当前树。曾定位的原功能提交 `f34700874c9f48b614991f769532115a0f24f27b` 不是当前base/live祖先，不能把该侧支号冒作实际上线提交；本批保留真实核查结果。
- 当前 silentSelectionAudit 保留 predicted_candidates、pending_dispatch、actual_turn=null；现有离线工具能关联动作/重问和观测端点，不能认证每张牌的物理身份、未落盘动作及完整候选执行。工具来源 `a32050fbce4c2863f640468c2dbf378fc9157074`、`e75438488df159b2e8e9d3458cf219b39aadd933` 均核为真实base/live祖先。该范围不足以将整项置 duplicate。

五份原run-config的完整源码commit均在Git中存在，dirty_files仅knowledge/notes；不是“源码无法定位”。准确缺口是当时刷新的知识、移动表等原字节及完整联合消费者输入未复原。当前源码与历史运行输入不等同。逐局完整提交和脏路径见 historical-code-facts.json；本批未借用当前刷新表重跑整场模拟、未提供新怪物参数，未拟合房间代价。

## 已完成验证与交付

`learner/audit-selection.ts` 对七份有界、单局冻结输入全部exit0，无LLM或联网。输入仅删除decisions.agent_view冗余，使用真实原_line与_source_sha256，显式身份经共用提取器核对后供给run_id；未补造decision_id。七窗口共170个题段、735个动作、642个相邻观测端点、2个终态观测端点、140个整轮窗口，其中86个可核、54个unknown。完整候选认证为0。P74 F22和BTS F31的保守unknown保持，不以人工可读实帧取代工具归属认证。输入/输出/stderr与SHA见 audit-inputs.json、offline-consumer-results.json、offline-summary.json。

固定原帧算术及边界37/37通过，见 material-checks.json；6606原行逐字节回读见 raw-verification.json；两组同指纹见 paired-fingerprint-checks.json。以上是材料/现有消费者检查，不是生产tsc/vitest，也不证明自然消费或策略收益。

本批无源码修改，因此tsc/vitest/cases均null；无撤源码失败/恢复通过实验，无新源码提交、合入提交或发布号。无权把旧绿树、经验shipped或窄子项源码号作为本批实现成功。其他角色行为没有改动。回退无需代码动作；本批只追加追溯，保留全部原提案/证据/失败与待新局状态。十项都保留waiting，随新本角色数据沿原队列重派；本报告不关闭学习入库父要求。

账本仅经根目录learner/ledger.py追加本次proposal/report链接及核查说明，不追加重复support/repeat、不重置原claim/first_run/prior/status/version、也不新建提案ID。CLI输入/退出码与物理读回见 ledger-update-input.json、ledger-cli-receipt.json、ledger-readback.json。

初期探针保留在initial-probes.txt：character原值SILENT被首次私有断言直接当小写导致失败；规范化后五局均通过。不存在路径/展示截断仅属阅读探针，不当产品故障或游戏反证，未删除任何初稿/失败原件。未读取凭据或.env、未运行play、未派下级agent、未推送。

交运维：本目录proposal.md与report.md；逐项机器结果为result.json。无需合入/live兜底或发号；请沿原队列保留十项具体缺口，不登记新implemented/shipped或关闭宽父。

机器结果见同目录 result.json。

补充验收：根账本CLI exit0，32条追加逐offset/bytes/SHA读回，原物理前缀及claim/首证/prior/证据/status/version保持；工作树HEAD未变且git status干净。过程材料gitleaks扫描exit0、0命中，原stdout/stderr/JSON/退出码均保留。

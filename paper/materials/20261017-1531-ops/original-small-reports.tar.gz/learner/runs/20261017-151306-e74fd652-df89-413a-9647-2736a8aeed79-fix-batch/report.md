## 修 bug 回报

- 合并基线：main → 5bd559de30f6a23739f3748426ab5be2321ecd0c
- 修复（每条一行）：h1-b2-margin-sample-identity：B2后续批次到期时参考前缀ID长度错误 — 660b194c950f017e356a4b3da952e127c7e5c768 — 测试 agent/tests/human-pace-sampling.test.ts:B2 pairs an eliminated prefix with a longer reference after a later C2 deadline — 去掉修复时失败：是（1失败/11通过）；恢复后12通过
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb9be14d620b368ec46974c1b57901ca（本基线和实际live祖先已重核）
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0b758a1a5e7d591745694004664f83a（本基线和实际live祖先已重核）
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb61eef226eb7366f9612003480c83988（本基线和实际live祖先已重核）
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7524bbb8e80a975f204f8d193657b46（本基线和实际live祖先已重核）
- 已被别人修掉的：空产出补链误派 — 84366ad06ee4f978394c1b9489a82c83ea12bd36（本基线和实际live祖先已重核）
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1（本基线和实际live祖先已重核）
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a826e94f9708af4b1a265e1892659f4e（本基线和实际live祖先已重核）
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（本基线和实际live祖先已重核）
- 已被别人修掉的：纸鹤夹具 — befc39e5ca0105f8ff96d47f817df44f0b2760f1（本基线和实际live祖先已重核）
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e5a0f234f082972d21b203dbf8229d7（本基线和实际live祖先已重核）
- 已被别人修掉的：共享main启动冲突 — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2（本基线和实际live祖先已重核）
- 已被别人修掉的：根事件通知路径 — 577f0bc424b7287910735cfdc86c253cc7ee8057（本基线和实际live祖先已重核）
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe043cb8738cce57870354fa23fa84a1（本基线和实际live祖先已重核）
- 已被别人修掉的：局间quiet误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d（本基线和实际live祖先已重核）
- 已被别人修掉的：global-health异步测试 — d27df54f0651c4af84c6c12ceceec82a016f1142（本基线和实际live祖先已重核）
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径本批另补） — 83a7f796c24eea8f16eb317bc70bfd832251ad27（本基线和实际live祖先已重核）
- 已被别人修掉的：retention数字UUID — d91236326bc1af7a5417ce016c1a182f8084e7a3（本基线和实际live祖先已重核）
- 已被别人修掉的：retention旧根scratch — 0699b05c436d3d51d00ee92f153d16d16e64bea4（本基线和实际live祖先已重核）
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec5fc6eafe576a1296bbdadde43432ee（本基线和实际live祖先已重核）
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b（本基线和实际live祖先已重核）
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ceeb81d534159b3516458521ad09bbed（本基线和实际live祖先已重核）
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a5168d1a8cb456aed1c926b2d1b6c4488（本基线和实际live祖先已重核）
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（本基线和实际live祖先已重核）
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d（本基线和实际live祖先已重核）
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093（本基线和实际live祖先已重核）
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7（本基线和实际live祖先已重核）
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b7913a53b9e2645f40db1657eb5213c（本基线和实际live祖先已重核）
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb12a1d4b2f34ee767bb2816a3a0b466（本基线和实际live祖先已重核）
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537（本基线和实际live祖先已重核）
- 已被别人修掉的：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70bfb2a91138ede0e1f6046927c116a4（本基线和实际live祖先已重核）
- 已被别人修掉的：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420（本基线和实际live祖先已重核）
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66bd75c6d6952772dcf712399eda828b（本基线和实际live祖先已重核）
- 已被别人修掉的：infra-test-rollout-ties-host-timeout-15000 — da08fcead2025c293140f1ba103d8efdbd39a4c3（本基线和实际live祖先已重核）
- 已被别人修掉的：infra-test-build-facts-selection-remove-latency — e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0（本基线和实际live祖先已重核）
- 已被别人修掉的：h1-budget-completion-health-contract — c40e43fd25c200a01f4da94a4dac8db1b34664a8（本基线和实际live祖先已重核）
- 已被别人修掉的：h1-strict-pick-deadline-stall — b3b9734d85defbdbd1b73ab85fab9ea2f636affd（本基线和实际live祖先已重核）
- 已被别人修掉的：selection-hidden-daggers-conditional-followup-readback — a473263eb35ce5bea8e06f1ee94f4da1ba880bc3（本基线和实际live祖先已重核）
- 已被别人修掉的：silent-0338：末挡诊断漏列既有奥利哈钢 — c1d84804956bedbd29a7f0e81294114e18415b9d（本基线和实际live祖先已重核）
- 已被别人修掉的：silent-0272：商店移除预判误报不可选 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26（本基线和实际live祖先已重核）
- 已被别人修掉的：silent-0367：构筑事实未传已用尾巴状态 — 5baf663d7e6678efa3690e5a48329c4f8baee109（本基线和实际live祖先已重核）
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（含0308/0311/0365/0481/0487/0496） — 策略类；已有独立strategy-proposal链，本批不增加游戏知识或重复派发。
- 没修的：silent-0332实际nonpositive-hp资源契约根因 — 证据不足；沿原0332/5aa2672专用owner，本次样本身份修复不关闭资源根因。
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；启动恢复、租约、UUID及旧scratch窄修已存在，删除归属和扫描竞态根因未知，保原失败和隔离守卫。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查 — 独立架构、策略和归因任务，超出普通纯bug批次。
- 没修的：core-build-notify-222802-rc2旧原生通知恢复 — 证据不足；旧失败缺stderr，不能确认未送达，保留原失败且不重发通知。
- 没修的：Codex缓存实测、DPR/B2性能及历史宿主超时根因 — 证据不足或独立性能调查；离线不调用模型，不将固定回归当自然性能根因闭环。
- 测试：tsc退出码0；vitest合计474文件 / 4373用例 / 退出码0（473文件4362项＋paths 1文件11项）；无超时重跑；定向12项0；gitleaks源码及刷新patch均0。
- 合入：未合入；锁内预检25处历史记录冲突，未执行源码merge；已保存刷新提交 7b61eaa636148221cbfc166067662e481ac7e0a7。
- 需要 Roy 定的事：无

证据与边界：

- 原局2PQK67ULZY90 / SILENT A10 / F33 T3，同计算键两次pending、failure=true、samples=200/requested=600，第三次C1 degraded0/600并继续。三条原decisions按运维冻结offset/length/SHA独立读回，见 original-prefix-readback.json；原样本数组缺失，不能宣称还原其具体失配维度或完整dirty运行树。
- 当前源码可确定复现：首批200结束后淘汰一个候选，其余两个继续到214而遇期限；adaptiveComplete=false，旧代码将200个候选ID默认复用给214个参考结果而触发身份守卫。新代码仅为不等长参考传自身ID；按共同200个身份配对，14个参考尾样本明确unmatched，不补0、不截去原结果、不放松守卫。
- 回归保留缺ID/重复ID拒绝、未知归属、n=1误差unknown、低可信闸、真实B2 worker错误和C1故障出口，已有初批partial及复用用例同时通过；固定数据不依赖刷新知识、模型或网络。保留测试仅stash源码时1项红，恢复后12项绿，详见targeted-without-fix.log、targeted-restored.log；完整入口source-sandbox.log/exit覆盖最终两叶源码，未修改或排除其他测试。
- 仅修配对身份协议；采样数、300最低/原目标、C2淘汰、H1期限、排序和S用途、药水/SL及其他角色策略保持。Ironclad不启用该quantitative capture路径。没有新游戏经验或策略提案，code_proposals与implementation_domains为空；未把此项当0332资源契约、模型可信度或自然验收已解决。
- ledger.py按bug-infra与局号/sample identity检索均0项，未新建或改写账本、未标shipped。40个历史已修条目逐commit核实际基线/live祖先，结合前批源码审计及本基线差异复核去重；selection提案59b2实际implemented/a473已核，不重复认领。
- live锁内等待builder，先保存10份刷新知识数据，gitleaks0；与源分支变更无重叠，见live-refresh-overlap.json。随后默认merge-tree预检25处历史记录冲突，按任务停止；没有实际merge或修改live源码/index，原notes/fight-value-backtest-silent.md、notes/monster-db-check.md的未提交修改保留。未跑合后测试、未写上线日志/行为版本或实际上线双通知；不得将刷新提交当本修复合入。
- 运维可据本完成事件兜底精确集成两叶源码，实际合入并核实B2服务恢复的行为发布后核号/登记上线；本批merged=null，不冒shipped或已上线。原分支、失败、补丁和输入均保留，无推送/play/模型调用/下级agent/运维prompt修改/回收。

冲突清单：

- CONFLICT (modify/delete): docs/human-pace-plan.md deleted in HEAD and modified in codex-fix-silent-20261017-151301.  Version codex-fix-silent-20261017-151301 of docs/human-pace-plan.md left in tree.
- CONFLICT (content): Merge conflict in notes/fix-queue-v4.md
- CONFLICT (content): Merge conflict in notes/for-roy.md
- CONFLICT (content): Merge conflict in notes/lessons.md
- CONFLICT (content): Merge conflict in notes/ops-handoff.md
- CONFLICT (content): Merge conflict in ops/inbox-dev.md
- CONFLICT (content): Merge conflict in paper/data/README.md
- CONFLICT (content): Merge conflict in paper/data/commits.csv
- CONFLICT (content): Merge conflict in paper/data/cost-curve-silent.csv
- CONFLICT (content): Merge conflict in paper/data/cost-silent.csv
- CONFLICT (content): Merge conflict in paper/data/cost-sources.json
- CONFLICT (content): Merge conflict in paper/data/cost-unattributed.csv
- CONFLICT (content): Merge conflict in paper/data/decisions_by_label.csv
- CONFLICT (content): Merge conflict in paper/data/learning-curve-silent.csv
- CONFLICT (content): Merge conflict in paper/data/runs.csv
- CONFLICT (content): Merge conflict in paper/data/summary.json
- CONFLICT (content): Merge conflict in paper/data/verification.json
- CONFLICT (modify/delete): paper/materials/20261017-human-pace-control/checkpoint.json deleted in HEAD and modified in codex-fix-silent-20261017-151301.  Version codex-fix-silent-20261017-151301 of paper/materials/20261017-human-pace-control/checkpoint.json left in tree.
- CONFLICT (modify/delete): paper/materials/20261017-human-pace-h1/checkpoint.json deleted in HEAD and modified in codex-fix-silent-20261017-151301.  Version codex-fix-silent-20261017-151301 of paper/materials/20261017-human-pace-h1/checkpoint.json left in tree.
- CONFLICT (modify/delete): paper/materials/20261017-human-pace-h1/natural/checkpoint.json deleted in HEAD and modified in codex-fix-silent-20261017-151301.  Version codex-fix-silent-20261017-151301 of paper/materials/20261017-human-pace-h1/natural/checkpoint.json left in tree.
- CONFLICT (modify/delete): paper/materials/20261017-human-pace-h1/natural/report.md deleted in HEAD and modified in codex-fix-silent-20261017-151301.  Version codex-fix-silent-20261017-151301 of paper/materials/20261017-human-pace-h1/natural/report.md left in tree.
- CONFLICT (content): Merge conflict in paper/materials/decision-log.md
- CONFLICT (modify/delete): paper/materials/learning/code-proposals.jsonl deleted in HEAD and modified in codex-fix-silent-20261017-151301.  Version codex-fix-silent-20261017-151301 of paper/materials/learning/code-proposals.jsonl left in tree.
- CONFLICT (content): Merge conflict in paper/materials/learning/ledger.jsonl
- CONFLICT (content): Merge conflict in paper/materials/silent/cost.md

```json
{
  "task": "fix-batch",
  "base": "5bd559de30f6a23739f3748426ab5be2321ecd0c",
  "fixes": [
    {
      "item": "h1-b2-margin-sample-identity：B2后续批次到期时参考前缀ID长度错误",
      "commit": "660b194c950f017e356a4b3da952e127c7e5c768",
      "test": "agent/tests/human-pace-sampling.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（含0308/0311/0365/0481/0487/0496）",
      "reason": "策略类；已有独立strategy-proposal链，本批不增加游戏知识或重复派发。"
    },
    {
      "item": "silent-0332实际nonpositive-hp资源契约根因",
      "reason": "证据不足；沿原0332/5aa2672专用owner，本次样本身份修复不关闭资源根因。"
    },
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；启动恢复、租约、UUID及旧scratch窄修已存在，删除归属和扫描竞态根因未知，保原失败和隔离守卫。"
    },
    {
      "item": "arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查",
      "reason": "独立架构、策略和归因任务，超出普通纯bug批次。"
    },
    {
      "item": "core-build-notify-222802-rc2旧原生通知恢复",
      "reason": "证据不足；旧失败缺stderr，不能确认未送达，保留原失败且不重发通知。"
    },
    {
      "item": "Codex缓存实测、DPR/B2性能及历史宿主超时根因",
      "reason": "证据不足或独立性能调查；离线不调用模型，不将固定回归当自然性能根因闭环。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4373
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261017-151306-e74fd652-df89-413a-9647-2736a8aeed79-fix-batch/report.md"
}
```

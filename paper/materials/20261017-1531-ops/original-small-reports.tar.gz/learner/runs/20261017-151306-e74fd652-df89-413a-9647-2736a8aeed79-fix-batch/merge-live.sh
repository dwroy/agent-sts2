#!/usr/bin/env bash
# Run only under the project's existing live-merge lock.
set -eu
export PATH="$HOME/.local/node/bin:$PATH"
export TMPDIR="/home/dw/Projects/agent-sts2/learner/runs/20261017-151306-e74fd652-df89-413a-9647-2736a8aeed79-fix-batch"
cd /home/dw/Projects/agent-sts2/.worktrees/live
date '+%Y-%m-%d %H:%M:%S %z'
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git diff --cached --quiet || { echo 'Existing staged work; no changes made'; exit 41; }
git rev-parse HEAD > "$TMPDIR/live-before-refresh.txt"
git status --short > "$TMPDIR/live-status-before.txt"
git add notes/fight-value-backtest.md knowledge
if ! git diff --cached --quiet; then
  git diff --cached --binary > "$TMPDIR/live-refresh.patch"
  gitleaks stdin --no-banner --redact < "$TMPDIR/live-refresh.patch" > "$TMPDIR/live-refresh-gitleaks.log" 2>&1
  date '+%Y-%m-%d %H:%M:%S %z'
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
git rev-parse HEAD > "$TMPDIR/live-before-merge.txt"
python3 - <<'PY'
import json, subprocess, os
from pathlib import Path
scratch = Path(os.environ['TMPDIR'])
before = (scratch / 'live-before-refresh.txt').read_text().strip()
source = 'codex-fix-silent-20261017-151301'
base = subprocess.check_output(['git', 'merge-base', 'HEAD', source], text=True).strip()
paths = lambda a, b: set(subprocess.check_output(['git', 'diff', '--name-only', a, b], text=True).splitlines())
refreshed = paths(before, 'HEAD')
source_paths = paths(base, source)
overlap = sorted(refreshed & source_paths)
(scratch / 'live-refresh-overlap.json').write_text(json.dumps({'merge_base': base, 'refreshed': sorted(refreshed), 'source_paths': sorted(source_paths), 'overlap': overlap}, indent=2) + '\n')
if overlap:
    raise SystemExit('Refreshed knowledge overlaps source: stop without merging')
PY
set +e
git merge-tree --write-tree --messages HEAD codex-fix-silent-20261017-151301 > "$TMPDIR/live-merge-preview.log" 2>&1
preview=$?
set -e
printf '%s\n' "$preview" > "$TMPDIR/live-merge-preview.exit"
if [ "$preview" -ne 0 ]; then
  echo 'Merge preflight has conflicts; live source and records unchanged'
  exit 42
fi
echo 'Merge preflight passed; no source merge performed'

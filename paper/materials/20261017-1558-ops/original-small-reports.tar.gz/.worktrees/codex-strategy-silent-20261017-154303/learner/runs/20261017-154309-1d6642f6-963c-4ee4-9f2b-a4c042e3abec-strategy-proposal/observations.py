import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {r['source_line']: r for r in map(json.loads, (OUT / 'focused-states.jsonl').open())}
facts = []

def keep(label, lines, result):
    facts.append({'label': label, 'references': [{k: states[n][k] for k in ['run_id', 'source_line', 'offset', 'bytes', 'sha256', 'floor', 'turn']} for n in lines], 'result': result})

def hand(line, ident):
    return next(c for c in states[line]['hand'] if c['card_id'] == ident)

def var(card, key):
    return next(v['current_value'] for v in card['dynamic_values'] if v['name'] == key)

assert [states[n]['player']['energy'] for n in [275564,275565]] == [7,5]
assert [var(hand(n,'DEFEND_SILENT'),'Block') for n in [275564,275565]] == [5,8]
assert [var(hand(n,'STRIKE_SILENT'),'Damage') for n in [275564,275565]] == [7,10]
assert [var(hand(n,'DAGGER_SPRAY'),'Damage') for n in [275564,275565]] == [5,7]
assert [hand(n,'TOOLS_OF_THE_TRADE')['energy_cost'] for n in [275564,275565]] == [1,0]
assert [states[n]['deck_upgraded'] for n in [275564,275565]] == [1,1]
keep('VLZ F35 T1 已观察升级', [275564,275565], {'energy':[7,5],'defend':[5,8],'strike_at_strength_one':[7,10],'dagger_spray_per_hit_at_strength_one':[5,7],'tools_cost':[1,0],'permanent_deck_upgrades':[1,1]})
assert [var(hand(n,'FASTEN'),'ExtraBlock') for n in [275679,275680]] == [4,6]
assert [var(hand(n,'PIERCING_WAIL'),'StrengthLoss') for n in [275679,275680]] == [6,8]
assert [states[n]['player']['current_hp'] for n in [275679,275687]] == [90,77]
assert [states[n]['enemies'][0]['current_hp'] for n in [275679,275687]] == [254,203]
keep('VLZ F43 T1 到T2的实际端点', [275679,275680,275687], {'fasten':[4,6],'wail':[6,8],'player_net_loss':13,'enemy_net_loss':51,'permanent_deck_upgrades':[4,4]})
assert [c['card_id'] for c in states[275731]['hand']] == ['APOTHEOSIS','SURVIVOR']
assert states[275732]['hand'] == []
keep('VLZ F45 T1 生存者前后持有与施放分列', [275731,275732], {'hand_before':['APOTHEOSIS','SURVIVOR'],'hand_after':[],'apotheosis_cost':2,'energy_before':1,'no_full_candidate_or_causal_certification':True})

for run in ['8JRE1C4H4Z2W','61E2QS63Y9WU','DUZUBAJ3A8GP']:
    audit=json.loads((OUT/'consumer'/(run+'.audit.json')).read_text())
    for turn in audit['observed_turns']:
        chosen = run == '8JRE1C4H4Z2W' and turn['floor']==33 and turn['turn']==2 and turn['attempt'] in [1,3]
        chosen |= run == '61E2QS63Y9WU' and turn['floor']==17 and turn['turn']==6
        chosen |= run == 'DUZUBAJ3A8GP' and turn['floor']==30 and turn['turn']==6 and turn['attempt']==4
        if chosen:
            assert turn['status']=='observed_turn_endpoints'
            f=turn['facts']
            keep(run+' 已核整轮观测端点', [f['before']['source_line'],f['after']['source_line']], {'floor':turn['floor'],'turn':turn['turn'],'attempt':turn['attempt'],'player_hp_delta':f['player_hp_delta'],'enemy_hp_changes':f['enemy_hp_changes'],'actual_full_candidate_result':f['actual_full_candidate_result']})
assert [states[n]['player']['current_hp'] for n in [276433,276434]] == [5,0]
assert [states[n]['enemies'][0]['current_hp'] for n in [276433,276434]] == [154,130]
keep('8JRE 末试T11终局截断', [276433,276434], {'player_net_loss':5,'enemy_net_loss':24,'displayed_attack':37,'current_block':22,'displayed_difference':15,'actual_uncapped_damage':None})

notes=Path('/home/dw/Projects/agent-sts2/notes')
(OUT/'original-run-reports').mkdir(exist_ok=True)
checks=[]
for run in 'VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP'.split():
    paths=list(notes.glob('run-*'+run+'.md'))
    assert len(paths)==1
    path=paths[0];raw=path.read_bytes()
    (OUT/'original-run-reports'/path.name).write_bytes(raw)
    checks.append({'run_id':run,'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(OUT/'observations.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
(OUT/'run-report-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verified_observations':len(facts),'verified_original_run_reports':len(checks)},ensure_ascii=False))

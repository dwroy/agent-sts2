import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = Path.cwd()
OUT = Path(__file__).resolve().parent
BATCH = '20261017-154303-strategy-proposal'
IDS = ['silent-proposal-' + x for x in '89354805ee4d7e77 f2bfceddb1898dca 283a164780d11e69 ebbfe3b97548756d e5b87be50f28f311 49632bc4878fb597 66532328a585941f 43a76a31ba7bdcfa 5264153a4a4b0e5c bddfa690a84e03d0'.split()]
RUNS = 'VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP'.split()

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def matches(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == BATCH:
                yield child
            else:
                yield from matches(child)
    elif isinstance(value, list):
        for child in value:
            yield from matches(child)

time = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
dispatches = list(matches(json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())))
assert len(dispatches) == 1, len(dispatches)
dispatch = dispatches[0]
assert dispatch['task'] == 'strategy-proposal' and dispatch['character'] == 'silent'
assert dispatch['worktree'] == str(WORK) and dispatch['proposal_ids'] == IDS
assert set(dispatch['runs']) == set(RUNS) and len(dispatch['runs']) == len(RUNS)
assert not dispatch.get('research_request') and not dispatch.get('implementation_request')
assert git('status', '--porcelain') == ''
save('dispatch.json', {'checked_at': time, 'batch': BATCH, 'initial_base': '5d31b4f1bedd2117aba1389f97a988f878e271c6', 'base': git('rev-parse', 'HEAD'), 'dispatch': dispatch})

adds, latest, refs = {}, {}, []
source = ROOT / 'paper/materials/learning/code-proposals.jsonl'
with source.open('rb') as handle:
    offset = 0
    for line, raw in enumerate(handle, 1):
        row = json.loads(raw)
        if row.get('id') in IDS:
            latest[row['id']] = row
            if row.get('op') == 'add':
                adds[row['id']] = row
                refs.append({'source': str(source), 'line': line, 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        offset += len(raw)
assert set(adds) == set(IDS)
material_checks = []
(OUT / 'original-proposals').mkdir(exist_ok=True)
for ident in IDS:
    row = adds[ident]
    assert row['character'] == 'silent' and set(row['runs']) <= set(RUNS)
    path = Path(row['proposal'])
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    assert actual == row['proposal_sha256'], (ident, actual)
    (OUT / 'original-proposals' / (ident + '.md')).write_bytes(raw)
    material_checks.append({'id': ident, 'path': str(path), 'bytes': len(raw), 'sha256': actual, 'matches_registered_sha256': True})
save('queue.json', {'adds': adds, 'latest': latest, 'references': refs})

ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
ledger_raw = ledger_path.read_bytes()
save('ledger-prefix.json', {'source': str(ledger_path), 'bytes': len(ledger_raw), 'sha256': hashlib.sha256(ledger_raw).hexdigest()})
spec = importlib.util.spec_from_file_location('task_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ledger_ids = sorted({i for row in adds.values() for i in row['ledger']})
folded = ledger.fold()
selected = {i: folded[i] for i in ledger_ids}
assert all(row['character'] == 'silent' for row in selected.values())
save('ledger-before.json', selected)
for ident, row in selected.items():
    print(json.dumps({'id': ident, 'status': row['status'], 'claim': row['claim'], 'evidence_for_dispatch': [e for e in row['evidence'] if e['run'] in RUNS]}, ensure_ascii=False))

experience = json.loads((WORK / 'knowledge/characters/silent/experience.json').read_text())
experience_ids = {i for row in adds.values() for i in row.get('experience', [])}
def entries(x):
    if isinstance(x, dict):
        if x.get('id') in experience_ids:
            yield x
        for v in x.values():
            yield from entries(v)
    elif isinstance(x, list):
        for v in x:
            yield from entries(v)
save('experience-selected.json', list(entries(experience)))
save('material-checks.json', material_checks)
print(json.dumps({'base': git('rev-parse', 'HEAD'), 'proposals': len(adds), 'ledger_items': len(selected), 'material_checks': len(material_checks)}, ensure_ascii=False))

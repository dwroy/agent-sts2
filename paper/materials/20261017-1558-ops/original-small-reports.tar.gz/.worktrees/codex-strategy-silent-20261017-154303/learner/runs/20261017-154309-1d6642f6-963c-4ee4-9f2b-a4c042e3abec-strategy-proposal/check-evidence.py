import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
spec = importlib.util.spec_from_file_location('evidence_extractor', WORK / 'learner/extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
RUNS = 'VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP'.split()
FLOORS = dict(zip(RUNS, [{17, 33, 35, 36, 37, 43, 45}, {17, 33}, {13}, {33, 39}, {17, 23}, {30}]))

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

all_rows = {run: collections.defaultdict(list) for run in RUNS}
checks = []
for folder in ['identity', 'evidence']:
    manifest = json.loads((OUT / folder / 'evidence-manifest.json').read_text())
    for entry in manifest:
        stream = entry['stream']
        path = OUT / folder / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
        counts = collections.Counter()
        source_path = None
        with path.open() as rows:
            for text in rows:
                envelope = json.loads(text)
                if source_path is None:
                    source_path = Path(envelope['source'])
                    original = source_path.open('rb')
                assert str(source_path) == envelope['source']
                assert envelope['offset'] + envelope['bytes'] <= entry['source_size']
                original.seek(envelope['offset'])
                raw = original.read(envelope['bytes'])
                assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == envelope['sha256']
                assert json.loads(raw) == envelope['row']
                assert module.run_identity(envelope['row']) == envelope['run_id']
                run = envelope['run_id']
                assert run in RUNS
                counts[run] += 1
                all_rows[run][stream].append(envelope)
        if source_path is not None:
            original.close()
        assert dict(counts) == {r: c for r, c in entry['counts'].items() if c}
        checks.append({'stream': stream, 'source_size': entry['source_size'], 'counts': entry['counts'], 'verified_references': sum(counts.values()), 'sha256': entry['output_sha256']})

def row_with_refs(envelope):
    return {**envelope['row'], '_line': envelope['line'], '_source_sha256': envelope['sha256']}

def state_summary(envelope):
    row = envelope['row']
    state = row.get('state', {})
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    def card(c):
        return {k: c.get(k) for k in ['card_id', 'index', 'upgraded', 'energy_cost', 'dynamic_values', 'resolved_rules_text']}
    return {'source_line': envelope['line'], 'offset': envelope['offset'], 'bytes': envelope['bytes'], 'sha256': envelope['sha256'],
            'observed_ts': row.get('observed_ts'), 'run_id': envelope['run_id'], 'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'player': {k: player.get(k) for k in ['current_hp', 'max_hp', 'block', 'energy', 'powers']},
            'run_hp': run.get('current_hp'), 'potions': run.get('potions'),
            'hand': [card(c) for c in combat.get('hand', [])],
            'deck_upgraded': sum(c.get('upgraded') is True for c in run.get('deck', [])),
            'enemies': [{k: e.get(k) for k in ['enemy_id', 'index', 'current_hp', 'max_hp', 'block', 'powers', 'intents', 'move_id', 'is_alive']} for e in combat.get('enemies', [])]}

(OUT / 'consumer').mkdir(exist_ok=True)
exclusions, summaries, focused = [], {}, []
for run in RUNS:
    rows = all_rows[run]
    assert len(rows['runs']) == 1
    run_row = rows['runs'][0]['row']
    assert run_row['character'].lower() == 'silent' and run_row['ascension'] == 10
    decisions = [e for e in rows['decisions'] if e['row'].get('floor') in FLOORS[run]]
    states = [e for e in rows['states'] if (e['row'].get('state', {}).get('run') or {}).get('floor') in FLOORS[run]]
    rejected = []
    ids = set()
    last_ts = ''
    accepted = []
    for e in decisions:
        row = e['row']
        reason = None
        if not row.get('decision_id'):
            reason = '原决策元数据无decision_id；保持原行和原行号，不补造身份'
        elif not row.get('observed_ts'):
            reason = '原决策无observed_ts，不能认证端点次序'
        elif row['decision_id'] in ids:
            reason = '原decision_id重复，不能认证唯一动作身份'
        elif row['observed_ts'] < last_ts:
            reason = '原观测时间倒序，不重新排序制造连续证据'
        if reason:
            rejected.append({'run_id': run, 'source_line': e['line'], 'offset': e['offset'], 'bytes': e['bytes'], 'sha256': e['sha256'], 'reason': reason})
        else:
            ids.add(row['decision_id'])
            last_ts = row['observed_ts']
            accepted.append(e)
    exclusions.extend(rejected)
    save('consumer/' + run + '.input.json', {'run': run_row, 'decisions': [row_with_refs(e) for e in accepted], 'states': [row_with_refs(e) for e in states]})
    summaries[run] = {'floors': sorted(FLOORS[run]), 'all_stream_counts': {s: len(es) for s, es in rows.items()}, 'consumer_decisions': len(accepted), 'consumer_states': len(states), 'excluded_decisions': len(rejected)}
    focused.extend(state_summary(e) for e in states)

save('evidence-verification.json', {'checks': checks, 'total_verified_references': sum(c['verified_references'] for c in checks), 'runs': summaries})
save('consumer-exclusions.json', exclusions)
with (OUT / 'focused-states.jsonl').open('w') as handle:
    for row in focused:
        handle.write(json.dumps(row, ensure_ascii=False) + '\n')

selected_decisions = {269598,269634,269668,269706,269707,269748,269754,269755,269770,270216,270264,270282,270441,270442}
selected = []
for run, streams in all_rows.items():
    for e in streams['decisions']:
        if e['line'] in selected_decisions:
            selected.append(e)
save('key-decisions.json', selected)
print(json.dumps({'verified_references': sum(c['verified_references'] for c in checks), 'runs': summaries, 'excluded': exclusions}, ensure_ascii=False))

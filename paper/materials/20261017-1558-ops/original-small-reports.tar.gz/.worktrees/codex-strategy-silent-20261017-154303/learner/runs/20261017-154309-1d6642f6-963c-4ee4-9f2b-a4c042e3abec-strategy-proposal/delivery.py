import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
time = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
dispatch = json.loads((OUT/'dispatch.json').read_text())
queue = json.loads((OUT/'queue.json').read_text())
verified = json.loads((OUT/'evidence-verification.json').read_text())
consumers = json.loads((OUT/'consumer-results.json').read_text())
sources = json.loads((OUT/'source-check.json').read_text())
assert json.loads((OUT/'observations.json').read_text())
base = dispatch['base']
batch = dispatch['batch']
DATA = [
('89354805ee4d7e77','神化状态传播与实际施放分账',
 'VLZ6CCT8AQ0A A10 F35 T1、F43 T1—T2、F45 T1；d269598、d269706/269707、d269748/269754/269755；s275564/275565、s275679/275680/275687、s275731/275732。',
 '原帧确认F35花2能量后防御5→8、力量1下打击7→10、匕首雨每击5→7、必备工具1费→0；场外升级数仍1。F43后继端点玩家90→77、敌254→203，场外升级数仍4。F45生存者前只余神化与生存者、能量1，后手牌空；不能把持有神化当实际施放。',
 '缺跨抽牌、选牌、用药重问、SL及换战的实际施放持续身份与生产读回；已有已观察升级转换及候选参考，actual_cast_this_fight仍为null，未知组合未校准。',
 '冻结同场施放动作、重问与换战边界，逐步核已覆盖与未知牌、费用和场外deck；实际施放状态必须有动作证据，不从升级手牌倒推。F35/F43是发现样本，后续独立局再验证。'),
('f2bfceddb1898dca','三骑士全败候选与药水预算',
 'VLZ6CCT8AQ0A A10 F17/F33/F43及F45 T1/T4/T5；d269748/269754/269770。',
 'F45首题药水MC只1/12样本，后问12/12是局部药水样本；原神化覆盖同时有缺口。T4所选13损/24伤与未选31损/32伤是候选比较。已胜F43仍90→33，F44回血到67后进F45，不把回血前资源省略。',
 '缺模型覆盖充分后的同起点、同随机池、同总预算MC配对与成熟度曲线，以及另一focus和留药的完整后继；现有预算诊断不能确定新预算分配或药价。',
 '固定原局面和同种子随机池，记录每阶段样本、候选稳定性、时间与未建模项；模型缺口与预算耗尽分开。缺稳定对照时不拟常量、不改留药或focus。'),
('283a164780d11e69','神化经验消费者补链',
 '同一来源局VLZ6CCT8AQ0A F35 T1、F43 T1—T2、F45 T1；原经验silent-apotheosis-combat-upgrades。',
 '本条与89354805ee4d7e77同源，是经验消费者链；原两份Markdown分别逐SHA读回。单局四次施放不能增成四个独立支持；已有窄源码只证明其覆盖的配对。',
 '同源神化提案仍缺实际施放持续归属与未知组合验证；同源关系和窄live实现不足以将整个请求登记duplicate。',
 '沿原两id共享证据与实际源码追溯，补足施放持续身份和消费者读回后逐原范围验收，不新建重复提案。'),
('ebbfe3b97548756d','十五项攻防、毒与资源的逐来源验证',
 'VLZ6CCT8AQ0A A10 F43 T1—T5、F45 T3/T5及本局休息/路线记录；原提案的十五条经验与十四条账本保持原映射。',
 '原提案逐项覆盖当前力量/弱、步法、覆甲、金刚杵、口红、勒紧、尖啸、萎靡、触媒、毒雾、组件兑现、三骑士时钟、石头加湿器、回血与路线。F43升级勒紧6与F45普通4分列；末局现场覆甲0，不沿用开场4。F45末轮显示83攻击经尖啸后59，32血20挡仍差7；这些原帧事实未验证新的整场权重。',
 '缺十五子项在同一冻结生产调用中的逐来源、期限、升级组合及战斗—路线—休息联合校准；本批没有定位新的确定源码数值失配。',
 '逐子项冻结实际属性、升级、当前进阶敌人数据库与动作前缀，比较即时与持续资源；路线代价仍需原五样本门槛。未知来源与未结算毒保持未知，不按一个子公式关闭整个复合请求。'),
('e5b87be50f28f311','Jev、护栏、SL与执行重规划审计',
 '8JRE1C4H4Z2W A10 F17 T6、F33首/三试T2、第二试T5、末试T11；d270216/270282、d270263—270266、d270441/270442；s276208—276212、s276274—276278、s276433/276434。',
 '首/三试T2的起点指纹一致，端点实损3/15、实扣10/17；原题推演死亡0/24与5/24，不能说同死亡率。第二试T5整轮实损4、实扣25。末试T11结束动作前5血22挡对37攻击，终态0血且敌154→130；显示差15与实扣5分列，不补未截断入伤。六次SL只是一局。',
 '本局66个选线片段均未认证完整候选执行；仍缺抽牌、选择、用药、重问及SL后的完整持续归属与逐来源收益，不能凭回合端点拟合护栏或探索门槛。',
 '复用已有原答/最终线、动作端点、终态与整轮消费者；另核所有中断与持续身份。只有整条原要求获验证才能关闭，本批不改护栏或SL选择。'),
('49632bc4878fb597','力量、敏捷、弱与独立成长分项',
 'CA5KE8GFJ9X2 A10 F13 T1—T5，特别T5；s273237、273252、273263及后继；原提案来源局保持CA5。',
 '轮初喷水11/15/19与力量0/4/8可核；覆甲9/9/8/7/6。虚弱后显示11/14仍有后继成长，不能当取消成长。本局计划中的正敏捷未建立，不从其他局或旧经验搬入本局。该局尝试号为空，现有严格消费者将轮端点留unknown；原帧仍存在。',
 '缺当前属性、正负敏捷、虚弱和独立成长四路径的同一冻结生产联合对照；本局没有正敏捷实测，本批未发现新的确定子公式失配。',
 '按各实测来源分别核每击力量、每牌敏捷、弱与独立成长；同一冻结代码与当前进阶输入作生产回放，不补造尝试号来绕过消费者守卫。'),
('66532328a585941f','持有、计划和实际建立的分账',
 '5PM6JAQG6FNQ A10 F33及F39末试T2；d268455/268456原咕嘟冒泡动作及相邻状态；原经验silent-deck-burst-observation。',
 '末试T2原请求将咕嘟冒泡指向无毒失落之物；原帧显示付1能而目标无新增毒。F33已建立成长后胜，和F39组件/资源/敌人不同，不能用跨战差异拟启动权重。',
 '缺同起始HP、牌组、药水与完整抽序下不同启动顺序的受控整战对照及收益函数；空打端点不支持启动阈值或构筑权重。',
 '保留持有、计划、实际能力状态各自来源；先核相同完整输入下的多种启动后继，再作按run分组的时间后置验证，不以尝试数增加独立分母。'),
('43a76a31ba7bdcfa','吸取、负敏捷、毒与SL范围',
 '61E2QS63Y9WU A10 F17 T5—T7，特别T6；s273502/273504，d267612—267615。',
 'T5玩家力量2，T6玩家无力量项、敏捷−2，敌力量2；两普通防御的现场值均3，17毒加16毒在后继合扣33，敌67→34；消费者对应整轮玩家净损8。本战首试获胜，不把本局首胜换成另一SL线路证据。',
 '缺同起始HP、构筑和完整抽序的另一可核SL全战线路；现有负敏捷与17+16毒端点不足以改SL范围、换线偏好或阈值。',
 '分别验证吸取与毒结算，另冻结同抽完整战斗配对；未有新线路和独立局数据前保留SL规则。'),
('5264153a4a4b0e5c','召唤、航行、成长与实体退场',
 '61E2QS63Y9WU A10 F23 T1—T5，特别T4/T5；d267696—267698原目标本体线。',
 '原T4本体线47伤/损15，幻象仍2HP且继续攻击，T5才退场；未选幻象线39伤/零损只是预测。当前该战尝试身份未知，严格整轮消费者留空；原帧与选线候选保留，不能将空值解释成未执行。',
 '缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；既有召唤支持和局部端点不能证明目标排序的整战收益。',
 '逐帧保留增员、退场和敌人index变化；enemy_id只作类型，不当稳定实例身份。保留所有目标选项，相同推演值并列，不加入固定首杀。'),
('bddfa690a84e03d0','睡眠、眩晕与成长的不同期限',
 'DUZUBAJ3A8GP A10 F30四次尝试，末试T4—T6；d269062—269077，尤其d269073—269077。',
 '原睡3/2/1后T4醒，T5力量2，临时尖啸后T6恢复并成长到4、攻击22。末试T6整轮端点玩家净损1、甲虫59→32；死亡前16挡与1血不能补记完整入伤。本局四试都败，仍是一局。',
 '缺伤害唤醒、眩晕接续与A10成长的冻结生产全链校准及同抽换序完整后继；四试失败不足以拟合血价、全败排序或固定杀序。',
 '按睡眠、受伤、眩晕、临时减力恢复和独立成长分别冻结状态；同抽不同顺序的完整后继与后置独立局用于检验，未知胜线不补造。'),
]

results = []
sections = []
for short, title, evidence, conclusion, reason, validation in DATA:
    ident = 'silent-proposal-' + short
    original = queue['adds'][ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append('\n'.join([
        '## ' + ident + '：' + title,
        '', '处置：**waiting**。账本：' + '、'.join(original['ledger']) + '。',
        '', '证据：' + evidence,
        '', '本批核实与反例/未知：' + conclusion,
        '', '缺数据：' + reason,
        '', '旧/预期行为：保留现有策略与未知标记。' + validation,
        '', '验证与回退：本批仅复核，不增加参数、分数、选项过滤或新机制。后续若补实现，须用固定原帧做撤源码失败/恢复通过，再跑原沙箱入口；回退该实际源码提交，保留原证据。未观察进阶和其他角色保持等价。',
        '', '原任务：' + original['source_task'] + ' → strategy-proposal；原Markdown：' + original['proposal'] + '；原SHA256：' + original['proposal_sha256'] + '。',
    ]))

proposal = '\n'.join([
    '# 本批十项已领取提案的证据复核与处置', '',
    '记录时间：' + time + '。角色silent，观察进阶A10；batch=' + batch + '。', '',
    '本批只消费原十id，不新建同源提案。新策略参数与规则均证据不足，十项保留waiting；已实现的窄子项继续按真实live源码追溯，不将其扩大成完整implemented或duplicate。',
    '', '样本与时间切分：六局均为2026-10-07历史证据，已用于发现与复盘，不是盲测。不同SL尝试不扩独立局分母；未执行候选、未观察升级组合和长期胜负不补数值。未新增科学反证或与既有结论冲突的发现；上述限制延续原提案。',
    *sections,
]) + '\n'
(OUT/'proposal.md').write_text(proposal)
(OUT/'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2)+'\n')

counts = []
for c in verified['checks']:
    counts.append('| ' + c['stream'] + ' | ' + str(c['source_size']) + ' | ' + str(c['verified_references']) + ' |')
consumer_table = []
for c in consumers:
    r = verified['runs'][c['run_id']]
    consumer_table.append('| ' + c['run_id'] + ' | ' + ','.join(map(str, r['floors'])) + ' | ' + str(r['consumer_decisions']) + '/' + str(r['consumer_states']) + ' | ' + str(c['segments']) + ' | ' + str(c['observed_turns'].get('observed_turn_endpoints',0)) + ' | ' + str(c['exit_code']) + ' |')
segment_total=sum(c['segments'] for c in consumers)
turn_total=sum(c['observed_turns'].get('observed_turn_endpoints',0) for c in consumers)
assert segment_total == 168 and turn_total == 86

report = '\n'.join([
    '# 静默猎手策略提案复核报告', '',
    '十项原提案均保留waiting；本批未定位可由现有证据确定修正的新源码失配，未修改策略、经验或参数。完整逐项证据、反例、缺口和验证方案见proposal.md。', '',
    '记录时间：' + time + '。batch=' + batch + '；角色silent；本批六个来源局均由runs.jsonl确认SILENT/A10。', '',
    '## 身份、基线与范围', '',
    '- 开工工作树干净；初始HEAD=' + dispatch['initial_base'] + '。',
    '- 本批learn.json为普通已领取提案任务，reason=proposal，有原十proposal_ids；无research_request、implementation_request及proposal_repair。根notes/strategy-research-silent.json绑定另一历史批次，不符合本批身份，未读取其他专题正文。',
    '- 按任务git merge --no-edit main无冲突快进；report.base=' + base + '。只同步了docs/human-pace-plan.md的既有main变更；没有借此报告新实现。',
    '- 只研究派发六局及其静默复盘、原Markdown和knowledge/characters/silent对应经验。其余历史局仅保留原账本/经验引用，不算本批核实来源。',
    '- 当前生产源码只读快照live=' + sources['live'] + '；不把这些历史dirty运行版本当该live版本的干净实验。', '',
    '## 原证据与消费者', '',
    '使用共用extract_evidence.py提取身份与七条流；每条封套均按原文件offset/bytes/SHA256回读并复核显式所属局、冻结source_size和输出SHA，合' + str(verified['total_verified_references']) + '条。run-plans的run与各流run_id/state.run_id/fingerprint.run按入口核身份，不以正文提及认领。未覆盖输出、未复用旧零行报告。', '',
    '| 流 | 冻结source_size（字节） | 本批封套数 |', '|---|---:|---:|', *counts, '',
    'fight-plans为该截点未选到本批记录，不据此断言原日志缺失。states/decisions/brain各有入口记录的两条全流无效JSON行；它们未归属本批，不补造所属局。其余计数及无效行口径保存在各evidence-manifest.json。', '',
    '消费者仅使用下表楼层的冻结原始状态、动作与runs记录；保留原始_line/SHA、全部重问与原尝试字段。851决策、878状态；排除清单为空，没有补ID、补尝试号或重编号。表外楼层不声称已做完整消费者验证。', '',
    '| 局号 | 限定楼层 | 决策/状态 | 选线片段 | 可核轮端点 | 退出码 |', '|---|---|---:|---:|---:|---:|', *consumer_table, '',
    '六次既有离线消费者均exit0，合168选线片段、86可核轮端点；完整候选认证数0。actual_full_candidate_result/actual_rollout_best留null，表示当前工具不认证，不能反推候选没有实际执行。CA5与61E2 F23的原尝试身份为空，严格端点留unknown；原帧仍可核实当前显示值。死亡截断的净损、显示攻击减挡、完整入伤分别保留，不从5→0补造入伤15。', '',
    '逐帧断言与引用见observations.json、observations.log；消费者命令/输入输出SHA和退出码见consumer-results.json；每份完整输出及stderr保存在consumer/。这属于证据读回，不是新增实现的红绿测试、生产全套测试或模型质量过闸。', '',
    '## 现有源码的已核边界', '',
    '15叶base/live源码保存原字节.txt及Git blob、SHA、last_path_commit和live祖先判断。13叶相同；card-model.ts和sl/explore.ts仅旧Roy/Dai注释字节不同，差异原样保留；没有改动任何一个。', '',
    '- 神化已观察配对：ba23ca693151fa8c6f7fe035e640dc30f05ccd75；候选/持有参考：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17，均为该live祖先。A10/Silent入口及未知组合守卫保留。',
    '- 原答/SL审计：05cd292c6f01bb31e406473d3a9843e659d62b93；护栏候选审计：a8b1f8be153fe4f3a34146117546c2178f2e446b，为该live祖先，实际收益仍留空。',
    '- 原观测区间：cf72bd21148059f111f760cc98a727369e34a47e；终态：04921bd785ac6838066522f91ea0bb6ab95cb6a1；整轮端点：9b87d54f097d84521152e6cca8d6072af8140394，均为该live祖先。仅其窄范围成立。',
    '- 这些已有源码提供局部机制或审计，不能证明预算新策略、完整候选归属、未知组合、整场反事实或十五项联合生产校准已经完成。source-check.json保留完整15叶核验，不把一个祖先提交当整项兑现。', '',
    '## 十项处置', '',
    *['- ' + r['id'] + '：waiting；' + r['reason'] for r in results], '',
    '## 记录、验证与交接', '',
    '原十份提案逐登记SHA核对，六份原角色局报从根notes只读找到并保存原字节（工作树缺这些未跟踪报告，git ls-tree HEAD对应路径为空，不推断证据缺失）。最初两次工作树路径读取不存在，仅为材料定位失败，不是代码测试失败；原执行历史保留。', '',
    '关联26条原账本只通过根learner/ledger.py update追加本批proposal/report与waiting追溯；不新增机制条目、支持或repeat，不改变claim、first_run、asc、prior、evidence、status、version、shipped或effect，旧shipped不降级。具体CLI及逐物理行验证见ledger-cli.json与ledger-verification.json。原提案队列不手改、不新建重复id，由原调度器按最终proposal_results处置。', '',
    '未改生产源码，所以撤源码失败/恢复通过不适用；tsc、vitest、cases均null，未运行原沙箱套件，不冒称测试成功。没有源码提交、合入、行为版本或shipped。未运行游戏、模型请求、联网、经验构建器或当前局操作；其他角色行为保持等价。无需合入live，merged=null；本报告不关闭原宽提案或父学习要求。', '',
    '运维交接：proposal=' + str(OUT/'proposal.md') + '；report=' + str(OUT/'report.md') + '。十项具体重派条件已逐项写明；实际源码改动以后再按原固定测试与live流程上线。',
]) + '\n'
(OUT/'report.md').write_text(report)
final = {'task':'strategy-proposal','character':'silent','batch':batch,'base':base,'runs':dispatch['dispatch']['runs'],'fixes':[],'skipped':[r['id'] for r in results],'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':[r['id'] for r in results],'implementation_domains':[],'proposal_results':results,'report':str(OUT/'report.md')}
(OUT/'result.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
updates=[]
for ident in sorted({i for row in queue['adds'].values() for i in row['ledger']}):
    related=[r['id'] for r in results if ident in queue['adds'][r['id']]['ledger']]
    updates.append({'id':ident,'by':'learner:strategy-proposal','where':{'proposal':[str(OUT/'proposal.md'),str(OUT/'report.md')]},'note':batch+'：逐原帧/源码范围复核；'+','.join(related)+'均waiting。详见本批报告逐项缺数据；只补追溯，不新增独立支持、repeat或反例，不改原claim/首证/角色/进阶/prior/证据/status/version/shipped/effect；未改源码，无实现提交或上线。'})
(OUT/'ledger-updates.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in updates))
print(json.dumps({'base':base,'proposal_results':len(results),'ledger_updates_prepared':len(updates),'report':str(OUT/'report.md')},ensure_ascii=False))

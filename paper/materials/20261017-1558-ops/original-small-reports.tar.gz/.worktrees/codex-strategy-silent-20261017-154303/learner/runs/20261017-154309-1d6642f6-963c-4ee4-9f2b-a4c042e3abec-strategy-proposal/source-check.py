import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
FILES = [
    'agent/src/reflex/silent-apotheosis.ts', 'agent/src/reflex/silent-apotheosis-reference.ts',
    'agent/src/reflex/card-model.ts', 'agent/src/reflex/turn-solver.ts', 'agent/src/reflex/rollout.ts',
    'agent/src/reflex/combat-plan.ts', 'agent/src/reflex/silent-selection-audit.ts',
    'agent/src/reflex/silent-hp-guard-audit.ts', 'agent/src/reflex/silent-held-loss.ts',
    'agent/src/sl/explore.ts', 'learner/audit-selection.ts', 'learner/lib/selection-execution.ts',
    'learner/lib/selection-observation.ts', 'learner/lib/selection-terminal.ts', 'learner/lib/selection-turn.ts',
]
def git(*args):
    return subprocess.check_output(['git', *args])
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'live').decode().strip()
(OUT / 'source').mkdir(exist_ok=True)
checks = []
for path in FILES:
    row = {'path': path}
    for label, commit in [('base', base), ('live', live)]:
        raw = git('show', commit + ':' + path)
        dest = label + '-' + path.replace('/', '__') + '.txt'
        (OUT / 'source' / dest).write_bytes(raw)
        last = git('log', '-1', '--format=%H', commit, '--', path).decode().strip()
        ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', last, live], check=False).returncode
        assert ancestor in (0, 1)
        row[label] = {'blob': git('rev-parse', commit + ':' + path).decode().strip(), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'last_path_commit': last, 'last_path_commit_is_live_ancestor': ancestor == 0}
    row['same_bytes'] = row['base']['sha256'] == row['live']['sha256']
    checks.append(row)
(OUT / 'source-check.json').write_text(json.dumps({'base': base, 'live': live, 'files': checks}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source-base.patch').write_bytes(git('diff', '--binary', base, '--', 'agent', 'learner', 'eval', 'ops', 'knowledge'))
print(json.dumps({'base': base, 'live': live, 'files': len(checks), 'same_bytes': sum(row['same_bytes'] for row in checks)}, ensure_ascii=False))

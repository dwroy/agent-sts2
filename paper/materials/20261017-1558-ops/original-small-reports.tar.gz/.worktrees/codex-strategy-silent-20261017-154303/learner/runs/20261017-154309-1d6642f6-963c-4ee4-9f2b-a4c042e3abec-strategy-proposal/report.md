# 静默猎手策略提案复核报告

十项原提案均保留waiting；本批未定位可由现有证据确定修正的新源码失配，未修改策略、经验或参数。完整逐项证据、反例、缺口和验证方案见proposal.md。

记录时间：2026-10-17T15:57:00+08:00。batch=20261017-154303-strategy-proposal；角色silent；本批六个来源局均由runs.jsonl确认SILENT/A10。

## 身份、基线与范围

- 开工工作树干净；初始HEAD=5d31b4f1bedd2117aba1389f97a988f878e271c6。
- 本批learn.json为普通已领取提案任务，reason=proposal，有原十proposal_ids；无research_request、implementation_request及proposal_repair。根notes/strategy-research-silent.json绑定另一历史批次，不符合本批身份，未读取其他专题正文。
- 按任务git merge --no-edit main无冲突快进；report.base=790c762698b503076fbdf99fc8a2f87468be178e。只同步了docs/human-pace-plan.md的既有main变更；没有借此报告新实现。
- 只研究派发六局及其静默复盘、原Markdown和knowledge/characters/silent对应经验。其余历史局仅保留原账本/经验引用，不算本批核实来源。
- 当前生产源码只读快照live=19988d1118ca43c1409fe900fc8c94f9f6ac32cc；不把这些历史dirty运行版本当该live版本的干净实验。

## 原证据与消费者

使用共用extract_evidence.py提取身份与七条流；每条封套均按原文件offset/bytes/SHA256回读并复核显式所属局、冻结source_size和输出SHA，合6995条。run-plans的run与各流run_id/state.run_id/fingerprint.run按入口核身份，不以正文提及认领。未覆盖输出、未复用旧零行报告。

| 流 | 冻结source_size（字节） | 本批封套数 |
|---|---:|---:|
| runs | 358345 | 6 |
| states | 13933309143 | 3432 |
| decisions | 2257459108 | 3306 |
| sl-attempts | 45534986 | 29 |
| run-config | 1956506 | 6 |
| run-plans | 8930094 | 33 |
| brain | 747659780 | 183 |
| fight-plans | 2233957 | 0 |

fight-plans为该截点未选到本批记录，不据此断言原日志缺失。states/decisions/brain各有入口记录的两条全流无效JSON行；它们未归属本批，不补造所属局。其余计数及无效行口径保存在各evidence-manifest.json。

消费者仅使用下表楼层的冻结原始状态、动作与runs记录；保留原始_line/SHA、全部重问与原尝试字段。851决策、878状态；排除清单为空，没有补ID、补尝试号或重编号。表外楼层不声称已做完整消费者验证。

| 局号 | 限定楼层 | 决策/状态 | 选线片段 | 可核轮端点 | 退出码 |
|---|---|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 17,33,35,36,37,43,45 | 257/268 | 43 | 10 | 0 |
| 8JRE1C4H4Z2W | 17,33 | 277/280 | 66 | 44 | 0 |
| CA5KE8GFJ9X2 | 13 | 26/33 | 4 | 0 | 0 |
| 5PM6JAQG6FNQ | 33,39 | 114/116 | 21 | 10 | 0 |
| 61E2QS63Y9WU | 17,23 | 60/63 | 12 | 5 | 0 |
| DUZUBAJ3A8GP | 30 | 117/118 | 22 | 17 | 0 |

六次既有离线消费者均exit0，合168选线片段、86可核轮端点；完整候选认证数0。actual_full_candidate_result/actual_rollout_best留null，表示当前工具不认证，不能反推候选没有实际执行。CA5与61E2 F23的原尝试身份为空，严格端点留unknown；原帧仍可核实当前显示值。死亡截断的净损、显示攻击减挡、完整入伤分别保留，不从5→0补造入伤15。

逐帧断言与引用见observations.json、observations.log；消费者命令/输入输出SHA和退出码见consumer-results.json；每份完整输出及stderr保存在consumer/。这属于证据读回，不是新增实现的红绿测试、生产全套测试或模型质量过闸。

## 现有源码的已核边界

15叶base/live源码保存原字节.txt及Git blob、SHA、last_path_commit和live祖先判断。13叶相同；card-model.ts和sl/explore.ts仅旧Roy/Dai注释字节不同，差异原样保留；没有改动任何一个。

- 神化已观察配对：ba23ca693151fa8c6f7fe035e640dc30f05ccd75；候选/持有参考：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17，均为该live祖先。A10/Silent入口及未知组合守卫保留。
- 原答/SL审计：05cd292c6f01bb31e406473d3a9843e659d62b93；护栏候选审计：a8b1f8be153fe4f3a34146117546c2178f2e446b，为该live祖先，实际收益仍留空。
- 原观测区间：cf72bd21148059f111f760cc98a727369e34a47e；终态：04921bd785ac6838066522f91ea0bb6ab95cb6a1；整轮端点：9b87d54f097d84521152e6cca8d6072af8140394，均为该live祖先。仅其窄范围成立。
- 这些已有源码提供局部机制或审计，不能证明预算新策略、完整候选归属、未知组合、整场反事实或十五项联合生产校准已经完成。source-check.json保留完整15叶核验，不把一个祖先提交当整项兑现。

## 十项处置

- silent-proposal-89354805ee4d7e77：waiting；缺跨抽牌、选牌、用药重问、SL及换战的实际施放持续身份与生产读回；已有已观察升级转换及候选参考，actual_cast_this_fight仍为null，未知组合未校准。
- silent-proposal-f2bfceddb1898dca：waiting；缺模型覆盖充分后的同起点、同随机池、同总预算MC配对与成熟度曲线，以及另一focus和留药的完整后继；现有预算诊断不能确定新预算分配或药价。
- silent-proposal-283a164780d11e69：waiting；同源神化提案仍缺实际施放持续归属与未知组合验证；同源关系和窄live实现不足以将整个请求登记duplicate。
- silent-proposal-ebbfe3b97548756d：waiting；缺十五子项在同一冻结生产调用中的逐来源、期限、升级组合及战斗—路线—休息联合校准；本批没有定位新的确定源码数值失配。
- silent-proposal-e5b87be50f28f311：waiting；本局66个选线片段均未认证完整候选执行；仍缺抽牌、选择、用药、重问及SL后的完整持续归属与逐来源收益，不能凭回合端点拟合护栏或探索门槛。
- silent-proposal-49632bc4878fb597：waiting；缺当前属性、正负敏捷、虚弱和独立成长四路径的同一冻结生产联合对照；本局没有正敏捷实测，本批未发现新的确定子公式失配。
- silent-proposal-66532328a585941f：waiting；缺同起始HP、牌组、药水与完整抽序下不同启动顺序的受控整战对照及收益函数；空打端点不支持启动阈值或构筑权重。
- silent-proposal-43a76a31ba7bdcfa：waiting；缺同起始HP、构筑和完整抽序的另一可核SL全战线路；现有负敏捷与17+16毒端点不足以改SL范围、换线偏好或阈值。
- silent-proposal-5264153a4a4b0e5c：waiting；缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；既有召唤支持和局部端点不能证明目标排序的整战收益。
- silent-proposal-bddfa690a84e03d0：waiting；缺伤害唤醒、眩晕接续与A10成长的冻结生产全链校准及同抽换序完整后继；四试失败不足以拟合血价、全败排序或固定杀序。

## 记录、验证与交接

原十份提案逐登记SHA核对，六份原角色局报从根notes只读找到并保存原字节（工作树缺这些未跟踪报告，git ls-tree HEAD对应路径为空，不推断证据缺失）。最初两次工作树路径读取不存在，仅为材料定位失败，不是代码测试失败；原执行历史保留。

关联26条原账本只通过根learner/ledger.py update追加本批proposal/report与waiting追溯；不新增机制条目、支持或repeat，不改变claim、first_run、asc、prior、evidence、status、version、shipped或effect，旧shipped不降级。具体CLI及逐物理行验证见ledger-cli.json与ledger-verification.json。原提案队列不手改、不新建重复id，由原调度器按最终proposal_results处置。

未改生产源码，所以撤源码失败/恢复通过不适用；tsc、vitest、cases均null，未运行原沙箱套件，不冒称测试成功。没有源码提交、合入、行为版本或shipped。未运行游戏、模型请求、联网、经验构建器或当前局操作；其他角色行为保持等价。无需合入live，merged=null；本报告不关闭原宽提案或父学习要求。

运维交接：proposal=/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-154303/learner/runs/20261017-154309-1d6642f6-963c-4ee4-9f2b-a4c042e3abec-strategy-proposal/proposal.md；report=/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-154303/learner/runs/20261017-154309-1d6642f6-963c-4ee4-9f2b-a4c042e3abec-strategy-proposal/report.md。十项具体重派条件已逐项写明；实际源码改动以后再按原固定测试与live流程上线。

import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
RUNS = 'VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP'.split()
env = dict(os.environ)
env['TMPDIR'] = str(OUT)
env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + env['PATH']
results = []
for run in RUNS:
    source = OUT / 'consumer' / (run + '.input.json')
    output = OUT / 'consumer' / (run + '.audit.json')
    error = OUT / 'consumer' / (run + '.stderr.txt')
    command = ['nice', '-n', '10', 'node', '--import', './agent/node_modules/tsx/dist/loader.mjs', 'learner/audit-selection.ts', str(source)]
    with output.open('w') as stdout, error.open('w') as stderr:
        process = subprocess.run(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
    record = {'run_id': run, 'command': command, 'exit_code': process.returncode, 'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'output_sha256': hashlib.sha256(output.read_bytes()).hexdigest()}
    if process.returncode == 0:
        result = json.loads(output.read_text())
        record.update({'segments': len(result['segments']), 'observed_actions': len(result['observed_actions']),
            'certified_full_candidates': sum(s['actual_full_candidate_result'] is not None for s in result['segments']),
            'observed_turns': dict(collections.Counter(t.get('status') for t in result['observed_turns'])),
            'turn_unknown_reasons': dict(collections.Counter(t.get('reason') for t in result['observed_turns'] if t.get('reason'))),
            'action_intervals': dict(collections.Counter(a['observed_interval']['status'] for a in result['observed_actions'])),
            'terminal_intervals': dict(collections.Counter(a['terminal_observation']['status'] for a in result['observed_actions'] if a.get('terminal_observation')))})
    results.append(record)
    (OUT / 'consumer-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(record, ensure_ascii=False), flush=True)
assert len(results) == 6 and all(r['exit_code'] == 0 for r in results)

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT/'paper/materials/learning/ledger.jsonl'
BATCH = '20261017-154303-strategy-proposal'
assert not (OUT/'ledger-cli.json').exists(), '禁止重复CLI追加'
time = subprocess.check_output(['date','-Iseconds'],text=True).strip()
raw = LEDGER.read_bytes()
spec=importlib.util.spec_from_file_location('task_ledger', ROOT/'learner/ledger.py')
ledger=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
updates=[json.loads(l) for l in (OUT/'ledger-updates.jsonl').read_text().splitlines()]
ids={r['id'] for r in updates}
pre=ledger.fold([(n,json.loads(line)) for n,line in enumerate(raw.splitlines(),1)])
(OUT/'ledger-pre-cli.json').write_text(json.dumps({i:pre[i] for i in ids},ensure_ascii=False,indent=2)+'\n')
command=['python3',str(ROOT/'learner/ledger.py'),'update']
process=subprocess.run(command,input=(OUT/'ledger-updates.jsonl').read_text(),text=True,capture_output=True)
receipt={'at':time,'command':command,'input_sha256':hashlib.sha256((OUT/'ledger-updates.jsonl').read_bytes()).hexdigest(),'exit_code':process.returncode,'stdout':process.stdout,'stderr':process.stderr,'prefix_bytes':len(raw),'prefix_sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'ledger-cli.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
assert process.returncode==0, receipt
after=LEDGER.read_bytes()
assert after[:len(raw)]==raw
own=[]
offset=len(raw)
for line in after[len(raw):].splitlines(keepends=True):
    row=json.loads(line)
    if row.get('note','').startswith(BATCH+'：'):
        assert row['id'] in ids
        assert set(row)<= {'op','id','ts','by','where','note'}
        assert row['op']=='update' and row['by']=='learner:strategy-proposal'
        before=copy.deepcopy(pre[row['id']])
        temp={row['id']:copy.deepcopy(before)}
        ledger.apply(temp,row)
        protected=lambda r:{k:v for k,v in r.items() if k not in {'where','history','notes'}}
        assert protected(temp[row['id']])==protected(before)
        own.append({'id':row['id'],'source':str(LEDGER),'offset':offset,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'only_where_note_history_added':True})
    offset+=len(line)
assert len(own)==len(updates)==26 and {r['id'] for r in own}==ids
(OUT/'ledger-verification.json').write_text(json.dumps({'original_prefix_preserved':True,'prefix_bytes':len(raw),'prefix_sha256':hashlib.sha256(raw).hexdigest(),'own_append_rows':own,'protected_fields_unchanged_by_each_own_row':True},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cli_exit_code':process.returncode,'own_append_rows':len(own),'original_prefix_preserved':True,'protected_fields_unchanged':True},ensure_ascii=False))

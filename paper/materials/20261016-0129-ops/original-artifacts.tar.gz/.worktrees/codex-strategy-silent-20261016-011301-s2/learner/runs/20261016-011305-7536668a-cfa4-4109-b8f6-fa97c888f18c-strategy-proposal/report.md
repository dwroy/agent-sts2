# 本批静默猎手策略提案处置

记录时间：2026-10-16 01:22:47 CST（写入前已运行date）。

本批 `strategy-proposal` / silent / `20261016-011301-s2-strategy-proposal`，仅消费派发的10项提案。初始git status干净；普通批身份与工作树完全匹配，无research_request/implementation_request；根deck-size专题绑定另一批，未承接、未读其正文或其他专题。`git merge --no-edit main`返回Already up to date，base/HEAD均为`2f719f8561bd7bcde7d30b37ed982b8017a30218`。

本批结论为10项waiting，源码改动0、提交0、合入null、发布号null；没有新建重复代码提案、经验或历史复盘，没有修改策略。这里的waiting只属于整项代码提案，不撤销已上线的窄功能，也不把任何既有账本降级。32条关联账本当前29 shipped、3 proposed，本次仅追加where/note追溯，由运维核读本报告；不代填shipped或其他角色确认。

## 可复核输入与覆盖

派发锚点：GXNKW8X1XYJP,2PVLGRBGUX9S,DPYF2BAA3DKT,UMVLWER4CD98,VLZ6CCT8AQ0A,VN7RQJMJEFMX,YF0LXT1QSTGG,ZE8F192FKX24,PD9AYQVMLQW6,L2TSFU62Z57Z。原提案SHA全部10/10匹配，原字节保存在original-proposals/，原路径/指纹在queue-folded.json及queue-history.json。最初queue-assigned.json只保留各ID末事件；随后已经按add/update完整折叠，所有处置均用queue-folded.json，未用末行替代原提案。

原提案关联局与十锚点合计22局，逐局由原runs.jsonl核实character=SILENT。它们是A1×1、A5×1、A6×4、A7×1、A8×1、A10×14，分阶保留；这里只对下列限定关键窗口做语义判断，不声称把全部抽取行或历史所有机制做了完整语义审计。账本更早来源仅作为既有记录阅读，未把未抽取的历史局冒认本批重新验证。

统一extract_evidence.py以nice 10单进程抽取8流，保存各source_size、原line/offset/bytes/SHA和计数；audit_evidence.py对每条选中行回读原字节、JSON、显式身份、输出SHA与计数，合计38759行通过。各流统计：

| 流 | 选中行 | 冻结源字节截点 | 源无效JSON行 |
| --- | ---: | ---: | ---: |
| states | 19036 | 13227236955 | 2 |
| decisions | 18398 | 1721978841 | 2 |
| sl-attempts | 161 | 41721015 | 0 |
| run-config | 22 | 1796239 | 0 |
| run-plans | 154 | 8254321 | 0 |
| brain | 966 | 616672084 | 1 |
| runs | 22 | 339600 | 0 |
| fight-plans | 0 | 2233957 | 0 |

各流不完整行均0；无效JSON是全源截至截点的统计，不冒称属于本批。fight-plans在该截点选中0，仅表示此范围未选到，不断言原日志或别的记录流缺失。run-plans选中154，按显式run字段归属，不以正文提及作为身份。证据索引在evidence/evidence-manifest.json，逐字节复核在byte-readback.json。

149个指定状态、26个决策、35个SL摘要和23个计划另存selected-*.json；resource-frames.json用于资源端点定位。33条固定材料断言通过，详见material-checks.json；它们只检查原观察和算术，不是tsc/vitest、撤源码负控、整场模拟或完整候选执行认证。

## 逐项处置与后续验收

### 1. silent-proposal-29b7b36dffbcb017 — waiting

原题：实际能力、毒结算与现场力挡核验。账本：silent-0005,silent-0006,silent-0011,silent-0016,silent-0021,silent-0027,silent-0030,silent-0087,silent-0278。

亲核证据：GXNKW8X1XYJP A10 F45 T2—3，states 290201—290213；silent-0005/0006/0011/0016/0021/0027/0030/0087/0278。T3普通刀刃实生三刀，触媒在手但未建立；13血、23挡、2覆甲面对40攻击，不能把未打能力或未结毒补成生存资源。

具体缺口：已有毒雾、触媒、现场力敏与药水局部模型；本批仍缺覆甲完整减层及头骨/阻毒/多次结算的联合消费者回放，也无提前饮药或先打能力的同输入整战对照。

反例与限制：制品阻挡、头骨加量与普通施毒必须分条件；末帧致死不能证明提前打能力能赢，复活中间0血亦不能当完整入伤。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：逐入口冻结原帧，核模型→候选→实际出牌→结算；补覆甲减层的独立事件与阻毒组合边界，再用后续独立Silent A10局验证。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-mechanisms.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 2. silent-proposal-2631859b524e0652 — waiting

原题：抑制战内版本和SL身份守恒审计。账本：silent-0280。

亲核证据：ZE8F192FKX24 A5 F42 T3—4，states 223267→223268及223268—223272；GXNKW8X1XYJP A10 F45 T2→3，290146→290147、290164→290165、290187→290188、290205→290206。关联八局共11个抑制新增窗口的全牌区基ID计数均守恒，详见dampen-windows.json；账本silent-0280。

具体缺口：11个抑制窗口支持战内版本变化与场外升级分账，但基ID守恒不能认证多副本物理身份、抽序或SL恢复；仍缺真实插牌/洗牌/同ID普通升级并存的消歧负例和生产抽序消费者回放。

反例与限制：守恒只约束数量，不能以它证明逐张对应或把clean前缀自动延长；触媒等降级文本不等于降级后实际施放。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：固定八局11窗口及真实新增/多副本负例；只有唯一可证的版本映射才允许接续，否则保守断序；核出口恢复与SL known-order消费者，不用聚合计数认证实体。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-dampen.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 3. silent-proposal-b13fda1dfeb37927 — waiting

原题：赢战资源链与复活后的同盘血价追踪。账本：silent-0019,silent-0020,silent-0079,silent-0243。

亲核证据：GXNKW8X1XYJP A10 F45末试T2—3，states 290201—290206可见2血→中间0血→13血；F35/38/40/42/44资源帧另存resource-frames.json。账本silent-0019/0020/0079/0243。

具体缺口：实际资源端点可追溯，但仍缺复活逐击未截断入伤、原候选整线执行归属及提前饮药/替路线整战对照；净HP差不足以校准血价、药价或放宽SL。

反例与限制：0→13是复活链的一部分，不能把它记作一般回血；赢战也可能耗掉后续所需资源，同局多次SL不增独立样本。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：按尝试/指纹匹配逐击、复活消耗和实际药栏，另取未选路线与用药时点的受控完整后继；先报来源分解，再考虑权重。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-resources-sl.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 4. silent-proposal-d7b8d36cf3d0303d — waiting

原题：PD9AYQVMLQW6 F49末T10：旧普通生存者单弃根因补36→24持牌伤证据，解耦绷带收益与弃牌消费。账本：silent-0268。

亲核证据：PD9AYQVMLQW6 A10 F49第6试T10，decisions 284707—284711，states 291336—291342，sl-attempts 1067；账本silent-0268。初两WITHER各12伤；生存者选择中31挡三张，完成后32挡两张；23攻击+24持牌伤−32挡=15，3血的算术余血−12，实盘0血/敌244。

具体缺口：普通生存者唯一可弃牌的修复已是live祖先；当前新增凋萎仍在终局计数，缺从原开场贯通生成实体、真实选择完成、余像与持牌伤顺序的固定生产回放，不能把窄单弃修复当整项duplicate。

反例与限制：实际弃一张后仍致死；36与24的持牌伤差不是实际额外损12血或修后可胜。多选择保持pending/unknown是现有保守边界。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：以原T10帧检查生成→选择→32挡/24持伤/23攻击全链，加入唯一后继、多选、无绷带、有绷带及未知选择回归；不能凭显式后手帧的算术替代初始帧生产回放。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-071302-postmortem/proposal-survivor-discard.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 5. silent-proposal-c873d6543c414f92 — waiting

原题：逐段保存Jev/支配/护栏/SL/抽牌重问的候选与实线身份，核对9条护栏中4条被SL撤回及药水饮用/恢复，保持打法参数。。账本：silent-0125,silent-0005,silent-0044,silent-0253。

亲核证据：L2TSFU62Z57Z A10 F17第2—6试T2—3；decisions 284918/284967/284971/285020/285024/285073/285077/285126/285130；states 291553—291562、291602—291611、291761—291770。九条HP guard中四条随后被SL覆盖；账本silent-0125/0005/0044/0253。

具体缺口：已有选择阶段/护栏快照与单动作日志，但actual_turn/actual_outcome仍为空，缺跨抽弃重问的稳定候选身份、父子链和饮药/恢复全链认证；阶段审计不能关闭完整执行追踪。

反例与限制：第2试T2真实保留省血线，后四试T2护栏被撤回；候选预计省血90不能当实际省血90。T3重问后的实际输出也不能等同旧候选的0伤。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：固定九护栏、四覆盖与抽牌重问，认证完成前缀/未执行后缀及药水实际饮用、弃置、SL恢复各自来源；完整链未知时继续显式unknown。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-074302-postmortem/proposal-control-trace.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 6. silent-proposal-dfbf51502f30c9b1 — waiting

原题：核验仪式兽160阈值后的全败并列和昏眩一牌额度，对照T6结束与7伤/侧步候选的完整代价；缺少受控胜线时保留策略，不预支能量或候选伤害。。账本：silent-0021,silent-0133,silent-0222,silent-0049,silent-0020。

亲核证据：L2TSFU62Z57Z A10 F17末试T6，decision 285148及states 291780—291783；T8 291790—291792、285155—285157；账本silent-0021/0133/0222/0049/0020。168→159跨现场160阈值并清8力，后到145；三候选各1200样本零胜并列。

具体缺口：七伤线五轮死亡14/24而结束线11/24，侧步未建模；缺同抽序完整替线与侧步后继兑现，不能仅凭即时多7伤改全败并列的排序。

反例与限制：T8昏眩1打精密瞄准后余1能但四牌blocked_by_hook，17血0挡受17实际死亡、敌113；剩能量不证明可继续出牌。有限零胜也不证明现实必败。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：固定原三候选及阈值、一牌额度，补侧步实际增能与受控同抽序整线后继；若推演已正确显示取舍，只补观测，不设固定优先攻击。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-074302-postmortem/proposal-ringing-terminal.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 7. silent-proposal-c2888032d1337388 — waiting

原题：现场力敏、逐牌/逐击收益和实际能力结算覆盖核验。账本：silent-0005,silent-0006,silent-0011,silent-0016,silent-0023,silent-0024,silent-0027,silent-0049,silent-0083,silent-0094,silent-0133,silent-0222,silent-0253,silent-0276,silent-0282。

亲核证据：PD9AYQVMLQW6 A10 F49末T10，states 291336—291342；L2TSFU62Z57Z A10 F17末T6/T8、F14资源帧；关联18个原提案来源局均核silent并按分阶抽取。十五账本ID见本节下方清单。

具体缺口：现场力敏、余像、仪式、毒雾/触媒及药水已有局部入口；仍缺十五账本全部机制入口的联合固定消费者回放，特别是覆甲减层、力量与滚石及换战未结算能力，不能据子模型关闭整项。

反例与限制：PD9滚石50已显示但死亡前仅毒结6；F48建立的能力不能当F49已建立，药水当步加层不等于整战胜因。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：每个原账本逐入口对照现场层数、每牌/每击和换战重置；从原状态到Jev/脑题面再到实际结算逐项验，未知组合保留，不拟早喝/留药阈值。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-075539-experience-update/proposal-mechanisms.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 8. silent-proposal-042ee2299084b528 — waiting

原题：首boss胜后的血药接续与真实路线/休息资源核算。账本：silent-0019,silent-0020,silent-0021,silent-0090,silent-0228,silent-0239,silent-0243。

亲核证据：PD9AYQVMLQW6 A10 F48首Boss58血进场、赢后F49以10血空药进场，F49第6试T10终局见291342；L2TSFU62Z57Z A10 F14及F17六试资源另存resource-frames.json；账本silent-0019/0020/0021/0090/0228/0239/0243。

具体缺口：双Boss同样本资源接续接口已有实现；仍缺真实血药/复活链到路线休息消费者的联合校准和未选完整路线/用药对照，不能把接口存在当资源价值已校准。

反例与限制：首Boss胜不等于续战资源齐；同幕10血空药接续不能补跨幕回血。最新silent-0090已记录两种获胜顺序，不能据旧单一顺序强制集火。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：用原同样本首战出口资源建立次战输入，核路线/休息实际消费并保留跨幕与同幕差异；房间代价保持五样本门槛，不改四局数据或因果阈值。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-075539-experience-update/proposal-resources.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 9. silent-proposal-8cd3db3bad5f34f1 — waiting

原题：有限推演、HP护栏和SL后实际执行链分账。账本：silent-0021,silent-0133,silent-0222,silent-0228,silent-0239。

亲核证据：PD9AYQVMLQW6 A10 F49末T10的实际出口；L2TSFU62Z57Z A10 F17第2—6试T2/T3与末T6/T8，见selected-decisions.json、selected-attempts.json；账本silent-0021/0133/0222/0228/0239。

具体缺口：有限推演、护栏/SL阶段与实际端点可分账；完整候选执行结果仍不能跨抽牌重问认证，缺稳定身份及原线整战反事实，不足以放宽SL必死边界。

反例与限制：PD9后期有限全死与实际继续到T10不是同一条完整候选的反证；L2实际T3输出16不能灌回旧0伤候选，六次SL相关。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：逐段认证Jev原答→支配→护栏→SL→实际动作→抽弃重问的前缀与父子关系；完整替线、输入模型覆盖及独立后继齐全后再判规则。

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-075539-experience-update/proposal-sl-trace.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

### 10. silent-proposal-43fe170707574455 — waiting

原题：为群伤与构筑计划提供逐目标退场进度及临时减力边界，避免把群伤存在当已兑现长战输出。账本：silent-0021,silent-0012,silent-0046。

亲核证据：ZTRGYYMLR8SC A10 F17末试，states 292332—292402，decisions 285353/285357，run-plans 2638/2639；账本silent-0021/0012/0046。初两信徒+神官合324血，两信徒同型；退场后索引不构成原实体身份。

具体缺口：同族当前全部活敌总血、本体血及暂减力快照已有实现；缺同型信徒跨帧稳定实例身份与构筑组件取得→支付→建立→后继的联合归属，不能把逐帧汇总当计划兑现全链。

反例与限制：某敌首次不可见不补造前一回合零血帧；临时减力不当永久削弱。抽序、铁心/洗牌等变化未控，不能推统一集火顺序或安全DPR。

预期行为：保留现有策略与保守未知边界，不新增牌值/血价/药价/SL阈值。 验证要求：保持当前帧index_now语义，冻结退场重排/缺帧及暂减力恢复，补可靠实体字段或显式歧义；组件计划须有真实取得与建立证据，再验消费者。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-combat-progress.md`；本批结果及原SHA见proposal-assessments.json与queue-folded.json。

## 现有源码、消费边界与验证状态

只读核验时实际live HEAD为`cfa1c0be88147b4eac65c13d8c550b23ed4eef17`。12个相关源码叶全部核真实来源commit为该live祖先，9叶原字节相同；card-model.ts、sl/draws.ts、boss-start.ts三叶存在历史Roy/Dai注释差，分别保存*.live-diff.patch，不覆盖、不声称逐字节相同。详细base blob、源commit与SHA在source-live-audit.json。已有局部源码来源（不等于本批新实现）：

- 66283dd9982bdd7f480da7a4d9bfefea0572a9ac：survivorDiscard、silentSelectionAudit、silentHpGuardAudit入口；普通生存者窄修bf423c173d3be348a4ad714e1d26516df619ff41另核祖先。
- d1713559f2d237a04b681ec6497ce0c8798ae0f0：同族当前快照事实。它明确声明index_now不作跨帧实体身份。
- e1a467e18a0dfa8d99046a24ff4c0e1af59278c8：双Boss continuationInput。它转交同样本资源，但接口存在不证明本提案的实际路线/休息联合校准已完成。

源码亲读：silent-selection-audit.ts显式execution_status=pending_dispatch、actual_turn=null；silent-hp-guard-audit.ts显式actual_outcome=null；quantitative-log-extract.ts仅匹配首个完成手动动作，并拒收跨回合/SL/未完成选择，不是整候选执行认证。turn-solver.ts未知弃牌保留pendingSelection/unknown，新增WITHER在终局withersAdded计算，不能把外部算术当原开场回放已完成。sl/draws.ts按版本键处理pile变化，当前没有足以由本批11个聚合守恒窗口认证物理身份与完整抽序的消费者材料。

未拟合任何牌值、血价、药价、SL或终局权重；发现样本均为历史来源局，同局SL相关，不把本批材料断言当独立留出。各提案的后续固定回放、未观察组合和新增独立本角色局的要求逐项列出。最新账本silent-0079/0087/0090的claim变更也已读回，尤其0090有不同获胜顺序，不固化旧单一集火结论。

源码无修改，tsc=null、vitest=null、cases=null；没有源码可撤，因此撤源码失败/恢复通过均不适用，没有运行或借用历史成功测试。不触发live锁、知识刷新提交、eval版本、上线双通知或shipped登记。其他角色执行代码与全部knowledge保持零差异。

账本只经根learner/ledger.py update追加报告/提案路径与本批缺口，输入ledger-updates.jsonl、原CLI回执和保护字段核验落在同目录。没有改变原claim/首证/prior/evidence/status/version，没有重复添加既有证据或新提案ID；队列最终状态由原完成流程消费proposal_results，不手改队列。

## 限制与现场保留

原runs.code带dirty，当前源码不能冒认当时完整运行树；这限制历史模型精确复原，不把它当不能验证任意窄修的统一理由。缺整线身份、逐击未截断入伤、未执行反事实或独立后期结果时均保留未知。

historical-brain-identities.json是来源局966条brain记录的实际engine/model/effort，不据其ds_*兼容计数推断真实引擎，也不据这些历史brain字段证明本学习者当前原生请求模型。当前没有可用原生会话自省工具，本批不冒称已核当前模型或擅改模型/账号/权限。

开工有相对ops/codex-ops/learner目录、agent/src/core/types.ts以及不存在测试glob的定位失败，另有宽输出截断；均为材料定位/展示准备，不当新产品bug或测试失败。已改用根目录精确派发行、实际源码路径和落盘限定投影；初始输出、未覆盖的末事件快照与工具记录保留，简记见tooling-notes.md。

没有待审批动作；没有等待未来对局或自行调度新任务。10项具体waiting均保留，沿原提案等待补数据重派，不关闭学习入库/量化父要求。运维接收入口为本目录proposal.md和report.md，最终机器结果为result.json。本工作树不自删，由原启动器按任务完成及保留门禁接续。

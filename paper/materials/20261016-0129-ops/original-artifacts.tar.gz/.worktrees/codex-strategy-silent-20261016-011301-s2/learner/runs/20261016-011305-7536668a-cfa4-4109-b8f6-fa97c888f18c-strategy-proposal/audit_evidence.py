"""Read back frozen bytes and prepare bounded, source-linked evidence views."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
spec = importlib.util.spec_from_file_location("extract", WORK / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(values):
    return {p.get("power_id"): p.get("amount") for p in values or []}


def location(e):
    return {k: e[k] for k in ("source", "line", "offset", "bytes", "sha256", "run_id")}


def state_view(e):
    s = e["row"]["state"]
    r, c = s.get("run") or {}, s.get("combat") or {}
    p = c.get("player") or {}
    return {
        **location(e), "ts": e["row"].get("observed_ts"),
        "floor": r.get("floor"), "turn": s.get("turn"), "screen": s.get("screen"),
        "in_combat": s.get("in_combat"), "hp": p.get("current_hp", r.get("current_hp")),
        "max_hp": r.get("max_hp"), "block": p.get("block"), "energy": p.get("energy"),
        "played": p.get("cards_played_this_turn"), "powers": powers(p.get("powers")),
        "potions": [x.get("potion_id") for x in r.get("potions", [])],
        "hand": [{k: x.get(k) for k in ("index", "card_id", "name", "upgraded", "energy_cost", "resolved_rules_text", "playable", "unplayable_reason")} for x in c.get("hand", [])],
        "enemies": [{"index": x.get("index"), "id": x.get("enemy_id"), "hp": x.get("current_hp"), "max_hp": x.get("max_hp"), "alive": x.get("is_alive"), "powers": powers(x.get("powers")), "intent": x.get("intents")} for x in c.get("enemies", [])],
        "piles": {k: v for k, v in (s.get("agent_view") or {}).get("combat", {}).items() if k in ("draw", "discard", "exhaust")},
        "deck_upgrades": [x.get("card_id") for x in r.get("deck", []) if x.get("upgraded")],
        "selection": s.get("selection"),
    }


targets = {
    "GXNKW8X1XYJP": [(290201, 290214)],
    "PD9AYQVMLQW6": [(291336, 291342)],
    "L2TSFU62Z57Z": [(291553, 291562), (291602, 291611), (291761, 291792)],
    "ZTRGYYMLR8SC": [(292332, 292402)],
    "ZE8F192FKX24": [(223268, 223272)],
}
decision_targets = {
    "PD9AYQVMLQW6": [(284707, 284711)],
    "L2TSFU62Z57Z": [(284918, 284918), (284967, 284967), (284971, 284971), (285020, 285020), (285024, 285024), (285073, 285073), (285077, 285077), (285126, 285130), (285148, 285148), (285155, 285157)],
    "ZTRGYYMLR8SC": [(285353, 285357)],
}
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
verified = json.loads((HERE / "verified-runs.json").read_text())
checks, states, decisions, attempts, plans = [], [], [], [], []
resources = collections.defaultdict(list)
brain = collections.Counter()
state_counts = collections.Counter()
for m in manifest:
    path = HERE / "evidence" / (m["stream"] + ".evidence.jsonl")
    digest = hashlib.sha256()
    counts = collections.Counter()
    last_offset = -1
    with path.open("rb") as selected, Path("/home/dw/Projects/agent-sts2/logs", m["stream"] + ".jsonl").open("rb") as source:
        for encoded in selected:
            digest.update(encoded)
            e = json.loads(encoded)
            assert e["offset"] > last_offset
            last_offset = e["offset"]
            assert e["offset"] + e["bytes"] <= m["source_size"]
            source.seek(e["offset"])
            raw = source.read(e["bytes"])
            assert hashlib.sha256(raw).hexdigest() == e["sha256"]
            assert json.loads(raw) == e["row"]
            assert extract.run_identity(e["row"]) == e["run_id"]
            assert e["run_id"] in verified
            counts[e["run_id"]] += 1
            r, run = e["row"], e["run_id"]
            if m["stream"] == "states":
                s = r["state"]
                if s.get("run"):
                    assert s["run"].get("character_id", "").lower() == "silent"
                state_counts[run] += 1
                if any(a <= e["line"] <= b for a, b in targets.get(run, [])):
                    states.append(state_view(e))
                sr = s.get("run") or {}
                if run in ("GXNKW8X1XYJP", "PD9AYQVMLQW6", "L2TSFU62Z57Z"):
                    c = s.get("combat") or {}
                    if c.get("enemies") or s.get("screen") in ("REST", "MAP", "GAME_OVER"):
                        resources[run].append({**location(e), "floor": sr.get("floor"), "turn": s.get("turn"), "screen": s.get("screen"), "hp": sr.get("current_hp"), "potions": [x.get("potion_id") for x in sr.get("potions", [])], "enemy_hp": [(x.get("enemy_id"), x.get("current_hp")) for x in c.get("enemies", [])]})
            elif m["stream"] == "decisions" and any(a <= e["line"] <= b for a, b in decision_targets.get(run, [])):
                decisions.append({**location(e), "row": r})
            elif m["stream"] == "sl-attempts" and run in set(targets):
                attempts.append({**location(e), "row": r})
            elif m["stream"] == "run-plans" and run in ("GXNKW8X1XYJP", "PD9AYQVMLQW6", "L2TSFU62Z57Z", "ZTRGYYMLR8SC"):
                plans.append({**location(e), "floor": r.get("floor"), "trigger": r.get("trigger"), "plan": r.get("plan")})
            elif m["stream"] == "brain":
                brain[(run, r.get("engine"), r.get("model"), r.get("effort"))] += 1
    assert digest.hexdigest() == m["output_sha256"]
    assert {run: counts[run] for run in m["counts"]} == m["counts"]
    checks.append({"stream": m["stream"], "rows": sum(counts.values()), "source_size": m["source_size"], "output_sha256": digest.hexdigest(), "bytes_identity_counts_verified": True})
save("byte-readback.json", checks)
save("selected-states.json", states)
save("selected-decisions.json", decisions)
save("selected-attempts.json", attempts)
save("selected-plans.json", plans)
save("resource-frames.json", resources)
save("historical-brain-identities.json", [{"run": k[0], "engine": k[1], "model": k[2], "effort": k[3], "count": n} for k, n in sorted(brain.items(), key=lambda x: str(x[0]))])
print(json.dumps({"streams": checks, "selected_states": len(states), "selected_decisions": len(decisions), "selected_attempts": len(attempts), "selected_plans": len(plans), "state_counts": dict(state_counts)}, ensure_ascii=False))

"""Count observable version changes without assigning unobserved physical identities."""
import collections
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
q = json.loads((HERE / "queue-folded.json").read_text())
runs = set(q["silent-proposal-2631859b524e0652"]["runs"])


def counted(state):
    combat = state.get("combat") or {}
    by_base, by_version = collections.Counter(), collections.Counter()
    for card in combat.get("hand", []):
        base = card.get("card_id")
        by_base[base] += 1
        by_version[base + ("+" if card.get("upgraded") else "")] += 1
    view = (state.get("agent_view") or {}).get("combat") or {}
    for pile in ("draw", "discard", "exhaust"):
        for card in view.get(pile, []):
            ids = card.get("card_ids") or []
            if not ids:
                continue
            line = card.get("line", "")
            match = re.search(r"^[^\[：:]*?\*(\d+)\s*\[", line)
            n = max(1, int(match[1]) if match else 1)
            up = bool(re.search(r"^[^\[*：:]*?\+\s*(?:\*\d+\s*)?\[", line))
            by_base[ids[0]] += n
            by_version[ids[0] + ("+" if up else "")] += n
    return by_base, by_version


previous, windows = {}, []
for line in (HERE / "evidence/states.evidence.jsonl").open():
    e = json.loads(line)
    run = e["run_id"]
    if run not in runs:
        continue
    s = e["row"]["state"]
    c = s.get("combat") or {}
    p = c.get("player") or {}
    amount = next((x.get("amount") for x in p.get("powers", []) if x.get("power_id") == "DAMPEN_POWER"), 0)
    old = previous.get(run)
    if amount and old:
        before, old_amount = old["row"]["state"], old["amount"]
        if not old_amount and (before.get("run") or {}).get("floor") == (s.get("run") or {}).get("floor") and before.get("in_combat"):
            a, av = counted(before)
            b, bv = counted(s)
            changed = sorted(k for k in av.keys() | bv.keys() if av[k] != bv[k])
            windows.append({"run": run, "floor": (s.get("run") or {}).get("floor"), "before_line": old["line"], "after_line": e["line"], "before_turn": before.get("turn"), "after_turn": s.get("turn"), "base_counts_conserved": a == b, "changed_versions": changed, "before_counts": dict(av), "after_counts": dict(bv), "physical_identity_verified": False, "ordered_draws_verified": False})
    previous[run] = {**e, "amount": amount}
result = {"scope": "八个派发关联局中实际观察到的抑制新增窗口，非实体或抽序认证", "runs": sorted(runs), "windows": windows, "count": len(windows), "conserved": sum(x["base_counts_conserved"] for x in windows)}
(HERE / "dampen-windows.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "windows"}, ensure_ascii=False))

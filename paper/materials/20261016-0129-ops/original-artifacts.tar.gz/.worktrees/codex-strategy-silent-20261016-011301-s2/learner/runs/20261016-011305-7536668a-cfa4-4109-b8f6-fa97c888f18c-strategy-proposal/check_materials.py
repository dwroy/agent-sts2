"""Check observed endpoints without treating them as full-plan certification."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = {x["line"]: x for x in json.loads((HERE / "selected-states.json").read_text())}
decisions = {x["line"]: x["row"] for x in json.loads((HERE / "selected-decisions.json").read_text())}
checks = []


def check(name, condition):
    assert condition, name
    checks.append(name)


def cards(line, card):
    return [x for x in states[line]["hand"] if x["card_id"] == card]


check("PD9末轮3血8带挡", (states[291336]["hp"], states[291336]["block"]) == (3, 8))
check("PD9原手两张12伤凋萎", len(cards(291336, "WITHER")) == 2 and all("12" in x["resolved_rules_text"] for x in cards(291336, "WITHER")))
check("PD9选择中31挡三凋萎", states[291340]["block"] == 31 and len(cards(291340, "WITHER")) == 3)
check("PD9选择后32挡两凋萎", states[291341]["block"] == 32 and len(cards(291341, "WITHER")) == 2)
check("PD9敌23攻击", states[291341]["enemies"][0]["intent"][0]["total_damage"] == 23)
check("PD9需承受15伤算术余血负12", 3 - max(0, 24 + 23 - 32) == -12)
check("PD9实亡敌244", states[291342]["hp"] == 0 and states[291342]["enemies"][0]["hp"] == 244)
check("PD9已有滚石50未追加结算", states[291341]["powers"].get("ROLLING_BOULDER_POWER") == 50 and states[291341]["enemies"][0]["hp"] - states[291342]["enemies"][0]["hp"] == 6)
check("GX场外六升级保持", len(states[290201]["deck_upgrades"]) == 6 and states[290201]["deck_upgrades"] == states[290206]["deck_upgrades"])
check("GX战内普通刀刃三刀文本", not cards(290206, "BLADE_DANCE")[0]["upgraded"] and "3张小刀" in cards(290206, "BLADE_DANCE")[0]["resolved_rules_text"])
check("GX实生三刀", len(cards(290209, "SHIV")) == 3)
check("GX普通触媒仅文本额外一次", not cards(290206, "ACCELERANT")[0]["upgraded"] and "额外触发1次" in cards(290206, "ACCELERANT")[0]["resolved_rules_text"])
check("GX未建立触媒", all("ACCELERANT_POWER" not in states[n]["powers"] for n in range(290206, 290214)))
check("GX复活中间0血与后帧13血分开", states[290205]["hp"] == 0 and states[290206]["hp"] == 13)
check("GX末帧13血23挡2覆甲", states[290212]["hp"] == 13 and states[290212]["block"] == 23 and states[290212]["powers"].get("PLATING_POWER") == 2)
check("L2现场阈值160力量8", states[291780]["enemies"][0]["powers"] == {"PLOW_POWER": 160, "STRENGTH_POWER": 8})
check("L2阈值168到159并清力量", states[291780]["enemies"][0]["hp"] == 168 and states[291781]["enemies"][0]["hp"] == 159 and "STRENGTH_POWER" not in states[291781]["enemies"][0]["powers"])
check("L2再打14到145", states[291782]["enemies"][0]["hp"] == 145)
check("L2末轮昏眩1", states[291790]["powers"].get("RINGING_POWER") == 1)
check("L2一牌后仍余1能", states[291791]["played"] == 1 and states[291791]["energy"] == 1)
check("L2四牌均被hook阻止", len(states[291791]["hand"]) == 4 and all(x["unplayable_reason"] == "blocked_by_hook" for x in states[291791]["hand"]))
check("L2末17血0挡受17亡", states[291791]["hp"] == 17 and states[291791]["block"] == 0 and states[291791]["enemies"][0]["intent"][0]["total_damage"] == 17 and states[291792]["hp"] == 0)
check("L2敌余113实际扣149", states[291792]["enemies"][0]["hp"] == 113 and 262 - 113 == 149)
q = decisions[285148]
options = {k: json.loads(v) for k, v in q["questions"]["plan"]["criteria"].items()}
check("L2七伤线与结束即时损血均0", options["plan1"]["damage_dealt"] == 7 and options["plan1"]["hp_lost"] == options["plan3"]["hp_lost"] == 0)
check("L2侧步未建模", "侧步" in options["plan1"]["unmodelled_cards"])
check("L2五轮14比11死亡不支持无价追加攻击", "dead within 5 turns in 14/24" in options["plan1"]["rollout"] and "dead within 5 turns in 11/24" in options["plan3"]["rollout"])
check("L2三线1200样本整场零胜且并列", q["boss_sim"]["samples"] == 1200 and q["boss_sim"]["best"] is None and len(q["boss_sim"]["tied"]) == 3 and all(x["win"] == 0 for x in q["boss_sim"]["lines"].values()))
guard = [d for d in decisions.values() if "HP guard:" in (d.get("rationale") or "")]
check("L2九条护栏", len(guard) == 9)
check("L2四条护栏被SL覆盖", sum("SL explore" in d["rationale"] for d in guard) == 4)
kin = [x for x in states.values() if x["run_id"] == "ZTRGYYMLR8SC"]
initial = next(x for x in kin if len(x["enemies"]) == 3)
check("ZTR开场总血324", sum(x["hp"] for x in initial["enemies"]) == 324)
check("ZTR两个同类型信徒非实体身份", sum(x["id"] == "KIN_FOLLOWER" for x in initial["enemies"]) == 2)
resources = json.loads((HERE / "resource-frames.json").read_text())
pd = resources["PD9AYQVMLQW6"]
f48 = [x for x in pd if x["floor"] == 48 and x["enemy_hp"]]
f49 = [x for x in pd if x["floor"] == 49 and x["enemy_hp"]]
check("PD9首Boss58血进场", f48[0]["hp"] == 58)
check("PD9次Boss10血空药进场", f49[0]["hp"] == 10 and not any(f49[0]["potions"]))
result = {"kind": "限定材料断言，非源码测试或完整候选认证", "passed": len(checks), "checks": checks}
(HERE / "material-checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False))

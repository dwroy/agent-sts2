# 本批工具准备记录

- 首次rg相对ops/codex-ops/learner失败：本树该历史目录未展开；绑定以根目录learn.json指定行完成，未因此认定根回执缺失。普通批无专题回执要求。
- 首个queue-assigned.json保存末事件；queue-history.json和queue-folded.json保留完整add/update与原提案元数据，未覆盖首件。
- rg曾引用不存在的agent/src/core/types.ts、dampen/ringing测试glob，并展开到较大JSON，退出2/输出截断；后改精确现存源码及固定投影。
- 长decision-log尾部、账本原evidence、状态完整run和宽源码搜索曾被展示截断；改读12行尾部、32条claim和149状态限定投影，原材料仍可复核。
- 三次git diff --no-index退出1表示实际历史注释差，不是产品错误；原patch逐份保存。
- 抽取、逐行字节核、11窗口分析、33材料断言均退出0，没有生产测试、撤源码负控或模拟调用。

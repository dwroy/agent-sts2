from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,tarfile

root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0129';pub=root/'paper/materials/20261016-0129-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-011301-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent;out=root/'ops/codex-ops/learner'/(bid+'.out');output=out.read_text()
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
final=load(s/'final-verification.json');assert final['head']==report['base'] and final['git_status_porcelain']=='' and final['tracked_diff_bytes']==0 and final['source_changes']==0 and final['commits']==[] and final['waiting']==10 and final['proposal_ids_complete']
for path,digest in final['artifacts'].items():assert sha((s/path).read_bytes())==digest,path
assert (s/'tracked-diff.patch').read_bytes()==b''
proposals=load(s/'queue-folded.json');assert set(proposals)==set(report['code_proposals'])
for ident,row in proposals.items():
    f=Path(row['proposal']);assert f.resolve().is_relative_to(root) and sha(f.read_bytes())==row['proposal_sha256']==sha((s/'original-proposals'/(ident+'.md')).read_bytes())
verification=load(s/'byte-readback.json');assert sum(x['rows'] for x in verification)==38759 and all(x['bytes_identity_counts_verified'] for x in verification)
for row in verification:assert sha((s/'evidence'/(row['stream']+'.evidence.jsonl')).read_bytes())==row['output_sha256']
source=load(s/'source-live-audit.json');assert source['base']==report['base'] and len(source['files'])==12
for row in source['files']:
    a=git('show',report['base']+':'+row['path']);z=git('show',source['live_head']+':'+row['path']);assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256'] and (a==z)==row['same_live_bytes']
    assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and row['source_is_live_ancestor'] and row['live_exists']
    git('merge-base','--is-ancestor',row['last_source_commit'],source['live_head'])
assert sum(x['same_live_bytes'] for x in source['files'])==9
origins=load(s/'existing-source-commits.json')
for row in origins:assert row['live_ancestor'];git('merge-base','--is-ancestor',row['source_commit'],source['live_head'])
material=load(s/'material-checks.json');assert material['passed']==len(material['checks'])==33
dampen=load(s/'dampen-windows.json');assert dampen['count']==len(dampen['windows'])==11 and dampen['conserved'] and all(x['base_counts_conserved'] for x in dampen['windows'])
receipt=load(s/'ledger-update-receipt.json');assert receipt['exit_code']==0 and receipt['own_updates']==32 and receipt['old_prefix_preserved'] and receipt['all_nontrace_fields_preserved'] and receipt['old_notes_history_where_preserved'] and receipt['status_changes'] is False and receipt['new_evidence_rows']==0
ledger=root/'paper/materials/learning/ledger.jsonl'
with ledger.open('rb') as handle:prefix=handle.read(receipt['previous_bytes']);added=handle.read(receipt['append_bytes'])
assert sha(prefix)==receipt['previous_sha256'] and len(added)==receipt['append_bytes']
inputs=[json.loads(line) for line in (s/'ledger-updates.jsonl').read_text().splitlines()];own=added.splitlines(keepends=True);assert len(inputs)==len(own)==len(set(own))==32 and set((s/'ledger-cli.stdout.txt').read_text().split())==set(receipt['ids'])
refs=[];offset=receipt['previous_bytes']
for raw in own:
    row=json.loads(raw);assert set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs)
    refs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row));offset+=len(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');existing=set(old.splitlines());assert all(raw.rstrip(b'\n') not in existing for raw in own)
spec=importlib.util.spec_from_file_location('owned_ledger',root/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
write(pub/'owned-ledger-references.json',refs)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,completion=final,source=source,original_source_origins=origins,evidence_output_shas_verified=True,original_rows=38759,original_material_assertions=33,original_dampen_windows=dampen,material_not_reexecuted=True,owned_trace_rows=32,protected_fields_and_old_prefixes_preserved=True,original_cli_receipt=receipt,limits=['Twenty-two historical Silent runs remain separated by their original ascension; broad extracted coverage is not a full semantic audit or independent holdout. Historical dirty source/knowledge bytes remain unresolved.','Base-ID conservation in eleven windows does not establish physical copy identity, draw order, SL restoration or safe known-prefix extension.','Original stage predictions, guard/SL replacement and completed actions are distinct. Empty actual_turn/actual_outcome and incomplete whole-candidate execution remain unknown; predicted 90 HP savings are not realized savings.','Existing narrow Survivor, live board snapshots and paired continuation interfaces do not close generated Wither attribution, cross-frame entity identity or calibrated route/resource values.','Original last-event-only queue snapshot was superseded by the full add/update fold; all original probes and truncated output retained. No new mechanism/threshold, natural consumer, source or wide-parent completion claimed.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0129原011301-s2策略done0/no-source处置核，2f719干净WT/HEAD不变、十waiting具体缺口/testsnull/域空/mergednull保持，无提交或合入阻塞，不空合/发号/补测。22个Silent来源分阶保留，八流38759材料行产物SHA/33限定断言及最终材料SHA核，不重跑或当全语义审计/生产测试。11抑制新增窗口基ID数量守恒不认证物理副本/抽序/SL恢复，不延长前缀；末事件旧快照与后续完整add/update fold原件并存。12源码叶9同3历史Roy-Dai注释差/真实live来源祖先核，既有单弃、当前同族总血/index_now和双Boss接续接口不当本批上线或联合资源校准；PD9终局持牌伤/新生实体链、L2原答护栏SL和重问后实际线/预测省血90、ZTR同型实体归属等未知保持，不拟血价/药价/SL/集火规则或关闭宽父。32所属CLI纯where/note逐输入/输出ID、offset/bytes/SHA及私有fold核，旧claim/首证/prior/证据/状态/版本及history/notes/where保，不重复CLI/证据或降级shipped。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network与966条历史brain及原未自省说明分列，原路径/glob/宽输出失败不当产品故障。仅本人记录/追溯提交，保并行脏记录；无新源码/知识/版本/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作。证据paper/materials/20261016-0129-ops/。\n'
note=f'\n- {at} [运维 codex] 原011301-s2策略十项继续waiting，无源码修改或合入受阻；33项为限定材料断言，11窗口数量守恒不等于实体/抽序认证，生产tests仍null。32所属追溯已核并保留原状态/证据，宽父继续开放。回执paper/materials/20261016-0129-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=32,protected_fields_preserved=True,no_new_source_tests_merge_or_release=True,wide_parents='remain open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,owned_trace_rows=32,ledger_check=0,paths=len(entries))))

import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extractor', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def card_keys(cards):
    result = []
    for card in cards or []:
        ids = card.get('card_ids')
        result.extend(ids if isinstance(ids, list) else
                      [str(card.get('card_id')) + ('+' if card.get('upgraded') else '')])
    return result


def compact(envelope):
    row = envelope['row']
    state = row.get('state') or {}
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    view = (state.get('agent_view') or {}).get('combat') or {}
    return {
        'line': envelope['line'], 'offset': envelope['offset'], 'sha256': envelope['sha256'],
        'run_id': envelope['run_id'], 'floor': run.get('floor'), 'turn': state.get('turn'),
        'screen': state.get('screen'), 'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'played': player.get('cards_played_this_turn'), 'powers': player.get('powers'),
        'hand': card_keys(combat.get('hand')), 'draw_base_ids': card_keys(view.get('draw')),
        'draw_display': view.get('draw'),
        'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                     'alive': e.get('is_alive'), 'powers': e.get('powers'),
                     'intents': e.get('intents')} for e in combat.get('enemies') or []],
        'potions': [{'index': p.get('index'), 'id': p.get('potion_id'), 'occupied': p.get('occupied')}
                    for p in run.get('potions') or []],
    }


dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
checks = []
for entry in manifest:
    stream = entry['stream']
    counts = Counter()
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    digest = hashlib.sha256()
    rows = []
    with (Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')).open('rb') as original:
        with path.open('rb') as handle:
            for encoded in handle:
                digest.update(encoded)
                envelope = json.loads(encoded)
                original.seek(envelope['offset'])
                raw = original.read(envelope['bytes'])
                assert raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
                assert envelope['offset'] + len(raw) <= entry['source_size']
                assert json.loads(raw) == envelope['row']
                assert extractor.run_identity(envelope['row']) == envelope['run_id'] in runs
                if stream == 'states':
                    info = envelope['row']['state']['run']
                    assert info['character_id'].lower() == 'silent'
                if stream == 'runs':
                    assert envelope['row']['character'].lower() == 'silent'
                counts[envelope['run_id']] += 1
                rows.append(envelope)
    assert {run: counts[run] for run in runs} == entry['counts']
    assert digest.hexdigest() == entry['output_sha256']
    streams[stream] = rows
    checks.append({'stream': stream, 'rows': len(rows), 'source_size': entry['source_size'],
                   'sha256': digest.hexdigest(), 'original_bytes_verified': True,
                   'identity_verified': True})
save('evidence-validation.json', {'rows': sum(x['rows'] for x in checks), 'streams': checks})

run_rows = {e['run_id']: e['row'] for e in streams['runs']}
floors = {'7X0W3U8TVA2A': {31}, 'MTQ0EUBJ3R6T': {11, 17, 19, 20, 23},
          'KFRDELW2TH2P': {12, 28, 33}, 'GXNKW8X1XYJP': {33, 44, 45}}
for run, selected in floors.items():
    decisions = [dict(e['row'], _line=e['line']) for e in streams['decisions']
                 if e['run_id'] == run and e['row'].get('floor') in selected]
    states = [dict(e['row'], _line=e['line']) for e in streams['states']
              if e['run_id'] == run and e['row']['state']['run'].get('floor') in selected]
    save(run + '.consumer-input.json', {'run': run_rows[run], 'decisions': decisions, 'states': states})

lines = {288402, 288407, 288408, 288409, 288426, 288430, 289339, 289345, 289414, 289420,
         289533, 289534, 289535, 289536, 289537, 289538, 289539, 289986, 289987, 289993,
         289994, 290160, 290165, 290201, 290206, 290212, 290213, 290214, 223268, 223272}
endpoints = [compact(e) for e in streams['states'] if e['line'] in lines]
save('endpoints.json', endpoints)
missing = lines - {e['line'] for e in streams['states']}
save('endpoint-selection.json', {'requested': sorted(lines), 'missing': sorted(missing)})

candidate_rows = []
decision_lines = {282578, 282579, 282929, 282864, 282899, 282933, 282968, 283001, 283035,
                  283641, 283680, 283690, 283691}
for e in streams['decisions']:
    row = e['row']
    mtq = row['run_id'] == 'MTQ0EUBJ3R6T' and row.get('floor') == 23 and row.get('turn') == 3
    if e['line'] not in decision_lines and not mtq:
        continue
    criteria = ((row.get('questions') or {}).get('plan') or {}).get('criteria') or {}
    parsed = {key: json.loads(value) if isinstance(value, str) else value for key, value in criteria.items()}
    candidate_rows.append({'line': e['line'], 'offset': e['offset'], 'sha256': e['sha256'],
                           'run_id': row['run_id'], 'floor': row.get('floor'), 'turn': row.get('turn'),
                           'attempt': row.get('sl_attempt'), 'label': row.get('label'),
                           'answer': row.get('answers'), 'chosen': row.get('chosen'),
                           'sl': row.get('sl_explore'), 'hp_guard': row.get('hp_guard'),
                           'criteria': parsed, 'result': row.get('result')})
save('candidate-facts.json', candidate_rows)

draws = [e for e in streams['sl-attempts'] if e['run_id'] == 'GXNKW8X1XYJP']
save('gx-sl-records.json', draws)
hp_boundaries = []
for run in runs:
    previous = None
    for e in streams['states']:
        if e['run_id'] != run:
            continue
        now = compact(e)
        if previous and isinstance(now['hp'], int) and isinstance(previous['hp'], int) and now['hp'] > previous['hp']:
            hp_boundaries.append({'run_id': run, 'from': previous, 'to': now, 'delta': now['hp'] - previous['hp'],
                                  'attribution': '仅相邻已记录帧的净HP增加；不推断来源或完整治疗事件'})
        previous = now
save('hp-boundaries.json', hp_boundaries)
by_line = {e['line']: e for e in streams['states']}
pairs = []
for first, second in [(289339, 289414), (290160, 290201)]:
    a, b = by_line[first]['row'], by_line[second]['row']
    pairs.append({'first': first, 'second': second,
                  'same_fingerprint': a['fingerprint'] == b['fingerprint'],
                  'same_hand': a['state']['combat']['hand'] == b['state']['combat']['hand'],
                  'same_player': a['state']['combat']['player'] == b['state']['combat']['player'],
                  'same_enemies': a['state']['combat']['enemies'] == b['state']['combat']['enemies'],
                  'limitation': '同一已记录盘面不证明后续同随机结果、完整候选执行或因果胜率'})
save('paired-snapshots.json', pairs)
print(json.dumps({'verified_rows': sum(x['rows'] for x in checks), 'endpoints': len(endpoints),
                  'missing_endpoints': sorted(missing), 'candidate_questions': len(candidate_rows),
                  'hp_increase_boundaries': len(hp_boundaries)}, ensure_ascii=False))

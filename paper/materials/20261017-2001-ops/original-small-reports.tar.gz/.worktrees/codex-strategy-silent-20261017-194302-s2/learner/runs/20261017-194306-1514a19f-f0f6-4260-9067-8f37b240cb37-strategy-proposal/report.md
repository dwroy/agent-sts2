# 静默猎手策略提案批次报告

记录时间：2026-10-17T19:55:20+08:00

**结果：十项均waiting；没有源码/知识修改、提交、合入或新版本。** 现有局部实现不等于原宽提案整体交付。

- task=strategy-proposal；character=silent；batch=20261017-194302-s2-strategy-proposal。
- base=f8a724899be11fa19c4b835b7d391a5560866a79；起始工作树干净，普通任务按要求git merge --no-edit main，结果Already up to date。
- 根learn.json对应行reason=proposal，工作树与五锚点匹配；存在且仅领取十个proposal_ids，没有research_request/implementation_request。普通专题文件绑定的是另一批，未将本批转换为专题。
- 实际live只读快照=31db98183b162f9e2213884f6b8ab518fe6ff89b；不冒称该快照是历史dirty运行源码。

## 证据范围与完整性

runs.jsonl核四局Silent A10：7X0W3U8TVA2A、MTQ0EUBJ3R6T、KFRDELW2TH2P、GXNKW8X1XYJP；ZE8F192FKX24为Silent A5，仅作为原抑制文本先例。所有局的原code均带dirty，完整运行树不可由当前源码替代。本批只分析这五局，没有重做全历史或把其他角色加入分母。

| 流 | 本批行数 | 冻结source_size |
|---|---:|---:|
| states | 2965 | 14012143211 |
| decisions | 2846 | 2318597892 |
| sl-attempts | 26 | 45887921 |
| run-config | 5 | 1980450 |
| run-plans | 30 | 9028544 |
| brain | 183 | 765121267 |
| runs | 5 | 361313 |

共6060行；共用extract_evidence.py提取，evidence-manifest.json保存每流截点、各局计数与输出SHA，每个封套保留原行号/offset/bytes/SHA。evidence-validation.json逐原字节读回、JSON同一性和显式身份核验通过；冲突身份不接收。run-plans按run身份解析，不拿正文提及当所属局。

全文件扫描中states/decisions/brain各有2条无法解析JSON的行；其局号无法核实，不归到任一锚点、不填补为证据。没有不完整末行。请求端点289539未被选为本批身份，只说明选取未命中，不声称原日志不存在。

## 已有实现的限定边界

18个相关文件保留源码原字节.txt及base/live blob/SHA；15个文件与live相同，3个仅Roy/Dai历史注释署名差异。各最新相关源码commit均是该live快照祖先。source-audit.json与source/*.live-diff.patch可读回。以下四提交均已另核base和live祖先，只支持各自窄范围，不用于把整项标duplicate：

- c4a4f4a94b48dff9b30aaa7228624c1092150145：奇巧名额/能量事实和限定恶魔毒药入口；continuation_verified仍false。
- 5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452：RunJournal的HP增加边界，明确仅帧间净变化。
- 3f69541b5d3259dac94d3395bfe3da47936b4de9：离线资源/敌HP审计，不提供缺失逐击事件。
- a32050fbce4c2863f640468c2dbf378fc9157074：既有离线执行关联工具；完整候选归属仍未知。

## 本批消费者读回

仅运行现有learner/audit-selection.ts，不调求解器、模拟、LLM或网络。输入为从本批封套保留原行号的四个有界楼层窗口，未填造尝试号或SL身份。

| 局号 | 固定楼层 | 决策片段 | 整轮记录 | 可核轮端点 | 退出码 |
|---|---|---:|---:|---:|---:|
| 7X0W3U8TVA2A | 31 | 32 | 13 | 0 | 0 |
| MTQ0EUBJ3R6T | 11、17、19、20、23 | 49 | 50 | 25 | 0 |
| KFRDELW2TH2P | 12、28、33 | 100 | 51 | 12 | 0 |
| GXNKW8X1XYJP | 33、44、45 | 42 | 24 | 6 | 0 |

223个片段、138个轮记录，其中43个可核轮端点；完整候选认证仍为0。轮端点可核不证明中间没有未落盘动作，不把null当0或把替线后的净差归给原候选。consumer-receipts.json保存四组输入/输出/空stderr的SHA与退出码。

## 逐项结果

- silent-proposal-19a5cff2094e2d8f：waiting。饱和死亡样本仍对应不同即时资源；暂死部件仍会接续。缺未截断入伤、持续实体归属及同输入同后继整战校准，不能据敌余血更少设新SL或终局权重。 证据：MTQ F23T3决策282434：原线及替线均24/24死亡，当前损血预测0/8、扣敌13/19；7X F31T5→T6状态288426→288430为0/0/35→25/25/21。 账本：silent-0021、silent-0064、silent-0079、silent-0133、silent-0125。
- silent-proposal-3540bf4360bf80af：waiting。实际HP增加边界已有消费者；尚缺休息、战斗开场、SL与逐槽药水的完整来源归因及路线/休息联合读回。净变化记录不足关闭原提案。 证据：7X F7/16/28营火增加21/21/19，共61；MTQ F9/16营火增加21/36，共57。MTQ F17→F18为19→59，F19/20赢战入59→46、46→8；F24未抵达。 账本：silent-0019、silent-0020、silent-0243。
- silent-proposal-0ea5c0b9c030fdd6：waiting。限定奇巧资源提示和恶魔毒药6入口已有实际live祖先；提示仍continuation_verified=false。缺自动重放、合法完整后继与多轮兑现校准，不能将局部入口列整项duplicate。 证据：KFR F33六次T7选择决策282864/282899/282933/282968/283001/283035；末次289533—289538：7→12挡、三手动动作后爆发锁住，毒37→43，最后敌159→74且玩家死亡。 账本：silent-0274、silent-0247、silent-0027、silent-0016。
- silent-proposal-f915ec544ab94b6e：waiting。原答→护栏/SL替换→重问→已记录动作的离线关联已有；本批完整候选结果仍null，F12生成后改线，F33T6缺可核整轮开端，不能用净差校准原完整候选或新排序。 证据：KFR F12T1决策282578护栏换完整线，生成小刀后282579重问改线；F33T6状态289339→289345和289414→289420同盘，扣敌83/93、损血6/12。 账本：silent-0079、silent-0125。
- silent-proposal-8fb51933639faf90：waiting。已有限定毒药、力量、敏捷和覆甲局部模型；缺完整覆甲减层条件、能量/药效/能力多入口联合消费者校准，没有定位新可隔离源码数值差额。 证据：KFR F28T2敏捷药与防御/手上技法；F33六试T2铁心、T4力药与回复、T5触媒、T7毒药；末次毒药37→43，43+42=85对应159→74。 账本：silent-0005、silent-0006、silent-0027、silent-0189、silent-0276、silent-0277、silent-0278。
- silent-proposal-b3bc0eb09211af6c：waiting。奇巧资源提示与SL即时资源比较已有；完整后继、未建立能力收益及整战终局价值仍未校准。六次T7没有可核整战胜线，不能据局部资源差改保血/用药规则。 证据：KFR F33六次T7奇巧爆发未兑现；首/第三试T6为15玩家HP、228敌HP、36毒、3覆甲，同盘资源差为多扣10/多损6。 账本：silent-0021、silent-0079、silent-0102、silent-0247、silent-0274。
- silent-proposal-fdc3a505fe5e1a55：waiting。HP边界观测已有实际live实现；完整逐源路线/休息消费者链与可比替路线后继仍缺，不能从六次回血后失败调整阈值或关闭整项。 证据：KFR六次已到营火各补21，共126；F17→F18跨层22→60补38，F32为15→36，F33开场36→38，SL回退与实到回复分列。 账本：silent-0019、silent-0020、silent-0243。
- silent-proposal-5a95725089f53cd8：waiting。已有局部原答/SL替换/动作及资源审计；缺复活瞬时逐击、未截断入伤、前三次退出和完整候选归属。不能以10HP/8敌HP差改评分或SL。 证据：GX F45第二/末试T2状态290160/290201完全同盘；T3为290165的3HP/0挡与290206的13HP/7挡、首敌64/72。最终290212为13HP/23挡、覆甲2，对40仍差2，290214死亡。 账本：silent-0019、silent-0079、silent-0005、silent-0016、silent-0087、silent-0027、silent-0030。
- silent-proposal-51fa8bc34774f72d：waiting。含升级键的整堆作差路径仍在；当前T2→T3同时抽牌，缺纯改标中间帧、唯一物理副本和并发次序，不能仅按基ID守恒安全延长SL前缀。 证据：GX F45四试sl-attempts1053—1056均T2 inserted四普通键，clean为19/18/19/18；290160/290201 T2抽堆显示升级文本，290165/290206 T3普通入手/留堆，290214出口恢复。ZE A5 F42T3/4仅作战内文本先例。 账本：silent-0279、silent-0280。
- silent-proposal-29b7b36dffbcb017：waiting。已建能力与毒结算局部模型已有；头骨/毒雾/覆甲/力敏的联合多轮消费者校准、完整时点对照仍不足，没有定位新独立源码差额。 证据：GX F33T5状态289986→289987：已建触媒2层，29+28+27=84，敌214→130；T6→T7为107→10，其中90毒与另7分账。F45未建立触媒，最后13+23+2对40。 账本：silent-0005、silent-0006、silent-0011、silent-0016、silent-0021、silent-0027、silent-0030、silent-0087、silent-0278。

每项原文、反例、当前/预期行为、后续验证和回退边界见proposal.md。本批不新增游戏结论、独立support/repeat、经验条目或重复提案id；不改首证/prior/claim。仅经根ledger.py update追加24个既有本角色账本的where/note追溯，保留既有status/version/evidence/effect，尤其不将shipped降为proposed、不冒认新shipped。实际CLI回执与保护字段读回见ledger-update-receipt.txt和ledger-verification.json。

## 测试、提交与上线

- 源码改动：无；fixes=[]；implementation_domains=[]；merged=null；新commit/版本：无。
- tsc/vitest/cases均null，未运行生产测试；四个离线消费者退出0和材料核验不冒充生产测试成功。
- 撤源码失败/恢复通过：不适用，本批没有源码补丁。
- 未执行live刷新/merge/重建/版本登记；没有新上线规则，无规则双通知，不调用play。
- proposal.md和report.md位于本批scratch，scratch受git忽略；末验HEAD仍为完整base且tracked/index干净。根台账例外只用CLI追加，未直接改ledger或learn.json。

## 操作限制与保留记录

早期摘要输出因过长被工具截断，后续按十项ID保存原文并核SHA；三条猜测源码路径不存在，之后以rg --files定位实际文件。两次临时结构探查分别因combat为空和空手数组报AttributeError/IndexError，未作为缺帧或游戏事实。校验首次尝试被bubblewrap初始化中无关并行工作树.codex消失导致的rg错误阻断，随后重试实际执行0；未更改沙箱权限，也未当源码失败。

compact初稿仅抽取draw的card_ids（原视图为基础ID，不携带升级位），后补存draw_display原文本并保留analysis.log、analysis-corrected.log，防止据基础ID虚构版本。analyze.py的SHA/计数复核再次通过。全部原日志、封套、原提案、失败记录和源码副本保留；未归档整个仓库、未删除自身树或其他会话材料。

后续应沿原十个提案等待各自列明的新证据或可核消费者输入；本报告不关闭学习父要求、不认定生产收益。

## 完成核验

completion-verification.json确认HEAD仍为f8a724899be11fa19c4b835b7d391a5560866a79，工作树与index干净，二者diff均0字节；十个原派发id均有waiting与具体理由。41项材料检查通过。根账本CLI退出0、24条追溯实际读回、原字节前缀SHA和保护字段均保持。scratch的gitleaks扫描实际退出0、无发现，原日志和空JSON报告保留。本批不提交、不推送、不合入或删除工作树，留既有调度器验收。

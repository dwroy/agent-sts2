import hashlib
import json
import subprocess
from collections import Counter
from datetime import datetime
from pathlib import Path

OUT = Path(__file__).resolve().parent
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
receipts = json.loads((OUT / 'consumer-receipts.json').read_text())
endpoints = {e['line']: e for e in json.loads((OUT / 'endpoints.json').read_text())}
checks = []


def check(name, condition):
    assert condition, name
    checks.append({'name': name, 'passed': True})


check('七流6060封套均已逐原字节核验', json.loads((OUT / 'evidence-validation.json').read_text())['rows'] == 6060)
check('两对盘面指纹、手牌、玩家和敌人完全相同', all(all(x[k] for k in
      ['same_fingerprint', 'same_hand', 'same_player', 'same_enemies'])
      for x in json.loads((OUT / 'paired-snapshots.json').read_text())))
check('KFR原线损6、扣敌83', endpoints[289339]['hp'] - endpoints[289345]['hp'] == 6 and
      endpoints[289339]['enemies'][0]['hp'] - endpoints[289345]['enemies'][0]['hp'] == 83)
check('KFR替线损12、扣敌93', endpoints[289414]['hp'] - endpoints[289420]['hp'] == 12 and
      endpoints[289414]['enemies'][0]['hp'] - endpoints[289420]['enemies'][0]['hp'] == 93)
check('GX两线后帧相差10HP、7挡、8敌HP', endpoints[290206]['hp'] - endpoints[290165]['hp'] == 10 and
      endpoints[290206]['block'] - endpoints[290165]['block'] == 7 and
      endpoints[290206]['enemies'][0]['hp'] - endpoints[290165]['enemies'][0]['hp'] == 8)
check('GX最终13HP和23牌挡加2覆甲仍比40少2', endpoints[290212]['hp'] == 13 and
      endpoints[290212]['block'] == 23 and 13 + 23 + 2 - 40 == -2 and endpoints[290214]['hp'] == 0)
check('GX已建触媒窗口实扣84', endpoints[289986]['enemies'][0]['hp'] - endpoints[289987]['enemies'][0]['hp'] == 84)
check('7X待接续部分没有永久消失', [x['hp'] for x in endpoints[288426]['enemies']] == [0, 0, 35] and
      [x['hp'] for x in endpoints[288430]['enemies']] == [25, 25, 21])
check('四消费者均正常返回且没有认证完整候选', len(receipts) == 4 and all(x['exit_code'] == 0 and
      x['certified_full_candidates'] == 0 for x in receipts))
for item in assigned:
    check(item['id'] + '原提案SHA', hashlib.sha256(Path(item['markdown_copy']).read_bytes()).hexdigest() == item['sha256'])
for f in source['files']:
    check(f['path'] + '源码未变', hashlib.sha256((OUT / 'source' / (f['path'].replace('/', '__') + '.txt')).read_bytes()).hexdigest() == f['sha256'])
    if not f['same_live_blob']:
        local = (OUT / 'source' / (f['path'].replace('/', '__') + '.txt')).read_bytes()
        live = subprocess.check_output(['git', 'show', source['live_snapshot'] + ':' + f['path']])
        check(f['path'] + '仅Roy/Dai文本差', local.replace(b'Roy', b'Dai') == live)

detail = [
    ('MTQ F23T3决策282434：原线及替线均24/24死亡，当前损血预测0/8、扣敌13/19；7X F31T5→T6状态288426→288430为0/0/35→25/25/21。',
     '饱和死亡样本仍对应不同即时资源；暂死部件仍会接续。缺未截断入伤、持续实体归属及同输入同后继整战校准，不能据敌余血更少设新SL或终局权重。',
     '两条MTQ线均失败；7X局部部件清零并未结束整战。',
     '保留严格判死及探索边界；未来可核即时血价、持牌伤和持续敌进度，推演相同仍并列。',
     '同输入、同后继的固定整战对照，同时核实体接续和毛伤，独立新局按时间留出；缺帧不填零。'),
    ('7X F7/16/28营火增加21/21/19，共61；MTQ F9/16营火增加21/36，共57。MTQ F17→F18为19→59，F19/20赢战入59→46、46→8；F24未抵达。',
     '实际HP增加边界已有消费者；尚缺休息、战斗开场、SL与逐槽药水的完整来源归因及路线/休息联合读回。净变化记录不足关闭原提案。',
     '已赢前战也会消耗后续入口资源；未抵达营火不是现有血量。两条非随机路线不构成因果比较。',
     '继续分列已到节点、入房与可操作HP；完整源链未核实时明确未知，不改休息/锻造阈值。',
     '用固定全局面串入房、开场、战斗、奖励、营火与跨幕；逐槽核主动用药/丢弃/新获/自动消耗/SL恢复，再读回两种消费者。'),
    ('KFR F33六次T7选择决策282864/282899/282933/282968/283001/283035；末次289533—289538：7→12挡、三手动动作后爆发锁住，毒37→43，最后敌159→74且玩家死亡。',
     '限定奇巧资源提示和恶魔毒药6入口已有实际live祖先；提示仍continuation_verified=false。缺自动重放、合法完整后继与多轮兑现校准，不能将局部入口列整项duplicate。',
     'F28T2选防御也未继续打出；毒药实际加6不证明提前饮用能赢。',
     '保留名额、能量与目标费用事实；目标选择不等于施放，不预支未验证后继收益。',
     '固定六试选牌帧及后续动作核额度/重放/药槽/毒结算；后续独立同组合局留出，不把六试当六局。'),
    ('KFR F12T1决策282578护栏换完整线，生成小刀后282579重问改线；F33T6状态289339→289345和289414→289420同盘，扣敌83/93、损血6/12。',
     '原答→护栏/SL替换→重问→已记录动作的离线关联已有；本批完整候选结果仍null，F12生成后改线，F33T6缺可核整轮开端，不能用净差校准原完整候选或新排序。',
     '两条T6后续均失败，少损6不等于已知胜线；护栏完整候选并未完整实打。',
     '保留预测与观测分账；遇生成、选择或重问保留断点，不把初次预测复制给后来实线。',
     '固定源行、指纹、时间和尝试号关联；完整归属及反事实缺失保持null，再用新独立实盘验证。'),
    ('KFR F28T2敏捷药与防御/手上技法；F33六试T2铁心、T4力药与回复、T5触媒、T7毒药；末次毒药37→43，43+42=85对应159→74。',
     '已有限定毒药、力量、敏捷和覆甲局部模型；缺完整覆甲减层条件、能量/药效/能力多入口联合消费者校准，没有定位新可隔离源码数值差额。',
     '覆甲层数变化不能据此推成每轮固定减1；提前饮毒的整场效果未知。',
     '按当前已建立能力与已核修饰条件供事实，保留条件外unknown，不设药水持有价或硬优先级。',
     '固定各时点的牌挡、每击力伤、药槽、毒层及实际结算成对核验；隔离减层事件后才扩大模型范围。'),
    ('KFR F33六次T7奇巧爆发未兑现；首/第三试T6为15玩家HP、228敌HP、36毒、3覆甲，同盘资源差为多扣10/多损6。',
     '奇巧资源提示与SL即时资源比较已有；完整后继、未建立能力收益及整战终局价值仍未校准。六次T7没有可核整战胜线，不能据局部资源差改保血/用药规则。',
     '手上技法本身7挡已兑现；目标锁住不否定整张牌。两条T6线均失败。',
     '继续区分已建立能力、未施放手牌、未结毒与实际终结，不替换现有权重。',
     '固定合法后继和最终结算核验；无完整毛伤、退出或胜线时保留未知，以新独立局验证。'),
    ('KFR六次已到营火各补21，共126；F17→F18跨层22→60补38，F32为15→36，F33开场36→38，SL回退与实到回复分列。',
     'HP边界观测已有实际live实现；完整逐源路线/休息消费者链与可比替路线后继仍缺，不能从六次回血后失败调整阈值或关闭整项。',
     '三火零精英且失败并不证明休息选择错；投影入口、未取得牌和真实入口不同。',
     '保留赢战血价与实际回复，SL恢复不计路线回血，未观察进阶不外推80%公式。',
     '固定全资源链按入口/出口/回退分列，读回路线及休息题面；跨路线因果与锻造比较需另有完整可比证据。'),
    ('GX F45第二/末试T2状态290160/290201完全同盘；T3为290165的3HP/0挡与290206的13HP/7挡、首敌64/72。最终290212为13HP/23挡、覆甲2，对40仍差2，290214死亡。',
     '已有局部原答/SL替换/动作及资源审计；缺复活瞬时逐击、未截断入伤、前三次退出和完整候选归属。不能以10HP/8敌HP差改评分或SL。',
     '两条实线均失败；精灵自动消耗不是主动喝药，更多存活HP不等于整战获胜。',
     '保留既有复活模型与least-loss剩血语义，继续逐槽分类并标复活中间帧缺失。',
     '同盘核血/带挡/敌HP差与四次自动耗药、恢复边界；完整原始入伤和瞬时复活帧缺失不能从HP下限反推。'),
    ('GX F45四试sl-attempts1053—1056均T2 inserted四普通键，clean为19/18/19/18；290160/290201 T2抽堆显示升级文本，290165/290206 T3普通入手/留堆，290214出口恢复。ZE A5 F42T3/4仅作战内文本先例。',
     '含升级键的整堆作差路径仍在；当前T2→T3同时抽牌，缺纯改标中间帧、唯一物理副本和并发次序，不能仅按基ID守恒安全延长SL前缀。',
     'A5已按普通牌文本选牌不证明抽序器身份正确；四次相关重试不增加独立局数，同ID副本歧义仍需断序。',
     '保留当前保守断序与原bug账本proposed；只在唯一身份和完整窗口被证明后修假插入/离堆，不造缺失抽序。',
     '所需新增固定证据为纯改标瞬时帧/稳定副本身份；负例覆盖同ID混合升级、真插牌、洗牌、同帧抽牌与恢复，未知仍断序。'),
    ('GX F33T5状态289986→289987：已建触媒2层，29+28+27=84，敌214→130；T6→T7为107→10，其中90毒与另7分账。F45未建立触媒，最后13+23+2对40。',
     '已建能力与毒结算局部模型已有；头骨/毒雾/覆甲/力敏的联合多轮消费者校准、完整时点对照仍不足，没有定位新独立源码差额。',
     'F33能力兑现不能证明F45先打持有的普通触媒能赢；额外遗物7不属于毒伤。',
     '继续按现场力敏、当前覆甲和已建立能力建模，持牌能力和待结毒不提前计入实收益。',
     '逐入口核固定原帧的每击力伤、逐牌挡、毒修饰与结算；留出独立后续同组合局，未知机制不补外推。'),
]
results = []
proposal = ['# 本批十项既有策略提案复核', '',
            '本批：20261017-194302-s2-strategy-proposal；角色silent。仅消费dispatch.json的十个原CLI id，不新增提案或领取其他批次。', '',
            '以下为既有提案的本批证据处置，不是新的规则上线。完整原文及其SHA保存在assigned-proposals.json和同名Markdown。', '']
for item, (evidence, reason, counterexample, behavior, validation) in zip(assigned, detail):
    original = item['original']
    results.append({'id': item['id'], 'state': 'waiting', 'reason': reason})
    proposal += ['## ' + item['id'], '', original['summary'], '',
                 '- 来源任务：' + original['source_task'] + '；实现任务strategy-proposal；原授权Roy-2026-10-07-learning。',
                 '- 证据局：' + '、'.join(original['runs']) + '；范围以原文已观察进阶为限。',
                 '- 账本：' + '、'.join(original['ledger']) + '。',
                 '- 本批核对：' + evidence,
                 '- 处置：waiting。' + reason,
                 '- 反例与限制：' + counterexample,
                 '- 当前行为及预期边界：' + behavior,
                 '- 后续验证方法：' + validation,
                 '- 拟合/时间切分：本批不拟合参数；同局SL不当独立样本，未来独立新局按时间留出。',
                 '- 回退：本批无代码或知识改动，无新发布需回退；保留全部原始失败与待处理状态。', '']
(OUT / 'proposal.md').write_text('\n'.join(proposal))
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

total_segments = sum(r['segments'] for r in receipts)
total_turns = sum(r['observed_turns'] for r in receipts)
status = Counter()
for r in receipts:
    data = json.loads((OUT / (r['run'] + '.consumer-output.json')).read_text())
    status.update(t['status'] for t in data['observed_turns'])

report = ['# 静默猎手策略提案批次报告', '',
          '记录时间：' + datetime.now().astimezone().isoformat(timespec='seconds'), '',
          '**结果：十项均waiting；没有源码/知识修改、提交、合入或新版本。** 现有局部实现不等于原宽提案整体交付。', '',
          '- task=strategy-proposal；character=silent；batch=20261017-194302-s2-strategy-proposal。',
          '- base=' + source['base'] + '；起始工作树干净，普通任务按要求git merge --no-edit main，结果Already up to date。',
          '- 根learn.json对应行reason=proposal，工作树与五锚点匹配；存在且仅领取十个proposal_ids，没有research_request/implementation_request。普通专题文件绑定的是另一批，未将本批转换为专题。',
          '- 实际live只读快照=' + source['live_snapshot'] + '；不冒称该快照是历史dirty运行源码。', '',
          '## 证据范围与完整性', '',
          'runs.jsonl核四局Silent A10：7X0W3U8TVA2A、MTQ0EUBJ3R6T、KFRDELW2TH2P、GXNKW8X1XYJP；ZE8F192FKX24为Silent A5，仅作为原抑制文本先例。所有局的原code均带dirty，完整运行树不可由当前源码替代。本批只分析这五局，没有重做全历史或把其他角色加入分母。', '',
          '| 流 | 本批行数 | 冻结source_size |', '|---|---:|---:|']
for m in manifest:
    report.append('| ' + m['stream'] + ' | ' + str(sum(m['counts'].values())) + ' | ' + str(m['source_size']) + ' |')
report += ['',
           '共6060行；共用extract_evidence.py提取，evidence-manifest.json保存每流截点、各局计数与输出SHA，每个封套保留原行号/offset/bytes/SHA。evidence-validation.json逐原字节读回、JSON同一性和显式身份核验通过；冲突身份不接收。run-plans按run身份解析，不拿正文提及当所属局。', '',
           '全文件扫描中states/decisions/brain各有2条无法解析JSON的行；其局号无法核实，不归到任一锚点、不填补为证据。没有不完整末行。请求端点289539未被选为本批身份，只说明选取未命中，不声称原日志不存在。', '',
           '## 已有实现的限定边界', '',
           '18个相关文件保留源码原字节.txt及base/live blob/SHA；15个文件与live相同，3个仅Roy/Dai历史注释署名差异。各最新相关源码commit均是该live快照祖先。source-audit.json与source/*.live-diff.patch可读回。以下四提交均已另核base和live祖先，只支持各自窄范围，不用于把整项标duplicate：', '',
           '- c4a4f4a94b48dff9b30aaa7228624c1092150145：奇巧名额/能量事实和限定恶魔毒药入口；continuation_verified仍false。',
           '- 5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452：RunJournal的HP增加边界，明确仅帧间净变化。',
           '- 3f69541b5d3259dac94d3395bfe3da47936b4de9：离线资源/敌HP审计，不提供缺失逐击事件。',
           '- a32050fbce4c2863f640468c2dbf378fc9157074：既有离线执行关联工具；完整候选归属仍未知。', '',
           '## 本批消费者读回', '',
           '仅运行现有learner/audit-selection.ts，不调求解器、模拟、LLM或网络。输入为从本批封套保留原行号的四个有界楼层窗口，未填造尝试号或SL身份。', '',
           '| 局号 | 固定楼层 | 决策片段 | 整轮记录 | 可核轮端点 | 退出码 |',
           '|---|---|---:|---:|---:|---:|']
floor_text = ['31', '11、17、19、20、23', '12、28、33', '33、44、45']
for r, f in zip(receipts, floor_text):
    d = json.loads((OUT / (r['run'] + '.consumer-output.json')).read_text())
    count = sum(t['status'] == 'observed_turn_endpoints' for t in d['observed_turns'])
    report.append('| ' + r['run'] + ' | ' + f + ' | ' + str(r['segments']) + ' | ' +
                  str(r['observed_turns']) + ' | ' + str(count) + ' | ' + str(r['exit_code']) + ' |')
report += ['', str(total_segments) + '个片段、' + str(total_turns) + '个轮记录，其中' +
           str(status['observed_turn_endpoints']) + '个可核轮端点；完整候选认证仍为0。轮端点可核不证明中间没有未落盘动作，不把null当0或把替线后的净差归给原候选。consumer-receipts.json保存四组输入/输出/空stderr的SHA与退出码。', '',
           '## 逐项结果', '']
for item, d in zip(assigned, detail):
    report += ['- ' + item['id'] + '：waiting。' + d[1] + ' 证据：' + d[0] +
               ' 账本：' + '、'.join(item['original']['ledger']) + '。']
report += ['',
           '每项原文、反例、当前/预期行为、后续验证和回退边界见proposal.md。本批不新增游戏结论、独立support/repeat、经验条目或重复提案id；不改首证/prior/claim。仅经根ledger.py update追加24个既有本角色账本的where/note追溯，保留既有status/version/evidence/effect，尤其不将shipped降为proposed、不冒认新shipped。实际CLI回执与保护字段读回见ledger-update-receipt.txt和ledger-verification.json。', '',
           '## 测试、提交与上线', '',
           '- 源码改动：无；fixes=[]；implementation_domains=[]；merged=null；新commit/版本：无。',
           '- tsc/vitest/cases均null，未运行生产测试；四个离线消费者退出0和材料核验不冒充生产测试成功。',
           '- 撤源码失败/恢复通过：不适用，本批没有源码补丁。',
           '- 未执行live刷新/merge/重建/版本登记；没有新上线规则，无规则双通知，不调用play。',
           '- proposal.md和report.md位于本批scratch，scratch受git忽略；末验HEAD仍为完整base且tracked/index干净。根台账例外只用CLI追加，未直接改ledger或learn.json。', '',
           '## 操作限制与保留记录', '',
           '早期摘要输出因过长被工具截断，后续按十项ID保存原文并核SHA；三条猜测源码路径不存在，之后以rg --files定位实际文件。两次临时结构探查分别因combat为空和空手数组报AttributeError/IndexError，未作为缺帧或游戏事实。校验首次尝试被bubblewrap初始化中无关并行工作树.codex消失导致的rg错误阻断，随后重试实际执行0；未更改沙箱权限，也未当源码失败。', '',
           'compact初稿仅抽取draw的card_ids（原视图为基础ID，不携带升级位），后补存draw_display原文本并保留analysis.log、analysis-corrected.log，防止据基础ID虚构版本。analyze.py的SHA/计数复核再次通过。全部原日志、封套、原提案、失败记录和源码副本保留；未归档整个仓库、未删除自身树或其他会话材料。', '',
           '后续应沿原十个提案等待各自列明的新证据或可核消费者输入；本报告不关闭学习父要求、不认定生产收益。', '']
(OUT / 'report.md').write_text('\n'.join(report))

result = {'task': 'strategy-proposal', 'character': 'silent',
          'batch': '20261017-194302-s2-strategy-proposal', 'base': source['base'],
          'runs': json.loads((OUT / 'dispatch.json').read_text())['runs'],
          'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [x['id'] for x in assigned], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'material-checks.json').write_text(json.dumps({'checks': checks, 'count': len(checks)}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'proposal_results': len(results), 'segments': total_segments,
                  'turn_records': total_turns, 'verified_turn_endpoints': status['observed_turn_endpoints'],
                  'report': str(OUT / 'report.md')}, ensure_ascii=False))

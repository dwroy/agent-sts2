import collections
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
checks = []


def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        raise AssertionError(name)


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verified = []
for stream in manifest:
    path = OUT / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    counts = collections.Counter()
    digest = hashlib.sha256()
    with (ROOT / 'logs' / (stream['stream'] + '.jsonl')).open('rb') as source:
        for raw in path.open('rb'):
            digest.update(raw)
            envelope = json.loads(raw)
            source.seek(envelope['offset'])
            original = source.read(envelope['bytes'])
            assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
            assert hashlib.sha256(original).hexdigest() == envelope['sha256']
            assert json.loads(original) == envelope['row']
            counts[envelope['run_id']] += 1
    check('原始字节与封套-' + stream['stream'], digest.hexdigest() == stream['output_sha256'] and
          all(counts[k] == v for k, v in stream['counts'].items()), dict(counts))
    verified.append({'stream': stream['stream'], 'rows': sum(counts.values()), 'source_size': stream['source_size'],
                     'output_sha256': digest.hexdigest()})

states = {x['line']: x for x in map(json.loads, (OUT / 'state-timeline.jsonl').open())}
decisions = {x['line']: x for x in map(json.loads, (OUT / 'evidence/decisions.evidence.jsonl').open())}
timelines = json.loads((OUT / 'combat-timelines.json').read_text())


def turn(run, floor, attempt, number):
    segment = next(c for c in timelines if (c['run'], c['floor'], c['attempt_in_extracted_combat']) ==
                   (run, floor, attempt))
    return next(t for t in segment['turns'] if t['turn'] == number)


def enemy(line, enemy_id):
    return next(e for e in states[line]['enemies'] if e['id'] == enemy_id)


def candidate(line, key):
    return json.loads(decisions[line]['row']['questions']['plan']['criteria'][key])


check('NHA首轮开场资源须与可操作帧分开', states[283390]['hp'] == 28 and states[283391]['hp'] == 30,
      '首个入房帧尚未完成开场；原始分段净差不是战斗操作损血。')
check('NHA同首手SL即时差额', states[283391]['hp']-states[283397]['hp'] == 1 and
      turn('NHA2KW0RB7VP', 33, 2, 1)['enemy_hp_net_removed'] == 8 and
      turn('NHA2KW0RB7VP', 33, 6, 1)['hp_net_loss'] == 7 and
      turn('NHA2KW0RB7VP', 33, 6, 1)['enemy_hp_net_removed'] == 24,
      {'原线损血': 1, '替线损血': 7, '原线扣敌': 8, '替线扣敌': 24})
check('RC首末决策同指纹', decisions[279021]['row']['fingerprint'] == decisions[279197]['row']['fingerprint'])
check('RC首末首轮资源', [(turn('RC61MFQM63Y6',33,a,1)['hp_net_loss'],
      turn('RC61MFQM63Y6',33,a,1)['enemy_hp_net_removed'],
      turn('RC61MFQM63Y6',33,a,1)['pre_end']['block']) for a in (1,6)] == [(4,30,16),(8,23,12)])
first, last = candidate(279021,'plan4'), candidate(279197,'plan1')
check('RC首末推演预算不能混同', first['rollout'].startswith('3-turn rollout (2 samples)') and
      last['rollout'].startswith('5-turn rollout (24 samples)'),
      {'首次': first['rollout'], '末次': last['rollout']})
check('P74弃牌后真实换线', decisions[278543]['row']['chosen']['option_index'] == 2 and
      '精确切击' in decisions[278543]['row']['rationale'] and
      '紧勒 -> 盛碗虫（丝）' in decisions[278544]['row']['rationale'])
check('P74末轮局部眩晕不等全场安全', states[284817]['hp'] == 1 and states[284817]['block'] == 16 and
      sum(e['attack'] for e in states[284817]['enemies']) == 24 and states[284821]['hp'] == 0 and
      enemy(284821,'BOWLBUG_EGG')['hp'] == 2 and enemy(284821,'BOWLBUG_ROCK')['move'] == 'STUNNED')
check('P74赢战资源接下战', turn('P74C04AEPL1F',22,1,2)['hp_net_loss'] == 20 and
      turn('P74C04AEPL1F',22,1,4)['hp_net_loss'] == 24 and states[284730]['hp'] == 53 and
      states[284761]['hp'] == 9 and states[284766]['hp'] == 9)
check('RC强制单弃后的攻击未执行', [c['id'] for c in states[285414]['hand']] == ['SURVIVOR','STRIKE_SILENT'] and
      not states[285415]['hand'] and states[285415]['hp'] == 45 and states[285415]['block'] == 7,
      '断点判死保留45HP，不能当已执行敌方损血。')
check('G33投斧不同首牌候选有资源差', (candidate(277909,'plan1')['block_gained'],
      candidate(277909,'plan2')['block_gained'],candidate(277909,'plan1')['damage_dealt'],
      candidate(277909,'plan2')['damage_dealt']) == (18,10,75,107))
check('G33两场赢战耗血', states[283916]['hp'] == 83 and states[283958]['hp'] == 46 and
      states[283967]['hp'] == 76 and states[284007]['hp'] == 17)
check('BTS抽弃后换线', decisions[279852]['row']['fingerprint'] != decisions[279854]['row']['fingerprint'] and
      '小刀 -> 盛碗虫（石）' in decisions[279854]['row']['rationale'] and
      '3/4' in candidate(279854,'plan2')['rollout'])
check('BTS末轮覆甲仍不足', states[286173]['hp'] == 14 and states[286173]['block'] == 5 and
      states[286173]['powers']['PLATING_POWER'] == 1 and enemy(286173,'SLUMBERING_BEETLE')['attack'] == 22 and
      states[286174]['hp'] == 0 and enemy(286174,'SLUMBERING_BEETLE')['hp'] == 13,
      '22-(5+1)=16，14HP仍差至少3HP才能存活；不是将实际HP扣至-2。')

base = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
live = subprocess.check_output(['git','-C',str(ROOT/'.worktrees/live'),'rev-parse','HEAD'],text=True).strip()
commits = ['e784dd9f043bf87c29109573f48975f9903280d3','bf423c173d3be348a4ad714e1d26516df619ff41',
           '4b0823f519f1b724d6cff2b1cd50b74146dc4a9d','5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56',
           '5604982e13890e0e2bc8bf8246272e8267321c0b','c769739b97389fdc978b6515b83a38e3cd900f67',
           'a8b1f8be153fe4f3a34146117546c2178f2e446b']
ancestry = []
for commit in commits:
    before = subprocess.run(['git','merge-base','--is-ancestor',commit,base]).returncode == 0
    deployed = subprocess.run(['git','merge-base','--is-ancestor',commit,live]).returncode == 0
    ancestry.append({'commit':commit,'base_ancestor':before,'live_ancestor':deployed})
    expected = commit != '5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56'
    check('源码运输身份-'+commit,before == expected and deployed == expected,
          '原5d7不是实际祖先，现有接线由实际祖先a8b1等集成；不拿原稿当部署提交。' if not expected else None)
files = ['agent/src/hand/screens/selection.ts','agent/src/hand/screens/silent-discard-facts.ts',
         'agent/src/reflex/card-model.ts','agent/src/reflex/turn-solver.ts','agent/src/reflex/combat-plan.ts',
         'agent/src/reflex/silent-sl-resource-comparison.ts','agent/src/reflex/silent-sl-comparison.ts',
         'agent/src/reflex/rollout.ts','agent/src/reflex/rollout-live.ts','agent/src/reflex/potion-cost.ts',
         'agent/src/sl/controller.ts','agent/src/sl/explore.ts','agent/src/sim/boss-sim.ts']
source = []
for path in files:
    record = {'path':path}
    for label,ref in [('base',base),('live',live)]:
        raw = subprocess.check_output(['git','show',f'{ref}:{path}'])
        record[label]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),
                       'blob':subprocess.check_output(['git','rev-parse',f'{ref}:{path}'],text=True).strip()}
    source.append(record)
snapshot = {'base':base,'live_snapshot':live,'ancestry':ancestry,'files':source}
(OUT/'source-readback.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n')
result = {'checks':checks,'check_count':len(checks),'passed':all(c['passed'] for c in checks),
          'raw_envelopes_verified':sum(x['rows'] for x in verified),'streams':verified,
          'production_tests':None,'note':'只读材料核证，不是tsc/vitest或策略收益验收。'}
(OUT/'evidence-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'raw_envelopes':result['raw_envelopes_verified'],
                  'base':base,'live_snapshot':live},ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261017-211302-s2-strategy-proposal'
dispatch = json.loads((OUT/'dispatch-snapshot.json').read_text())
items = json.loads((OUT/'assigned-proposals-folded.json').read_text())
verified = json.loads((OUT/'evidence-verification.json').read_text())
source = json.loads((OUT/'source-readback.json').read_text())
base = source['base']

details = [
('NHA2KW0RB7VP F33 T1，六次；F24—33连续资源',
 '原线14挡/损1/扣敌8，替线8挡/损7/扣敌24；多16输出同时多损6HP。开场原帧283390为28HP，283391完成开场才为30HP；不能把开场变化算作出牌净损。首末六试无同条件整战胜线。',
 '当轮候选资源差额已有实现；缺同抽序、同预算整战后继及受控路线、保药对照，不能据此修改SL门槛或终局HP价格。'),
('P74C04AEPL1F F23第4次T3；第1/3次作为反例',
 'decisions278542—278546：生存者后弃精确切击，再规划为紧勒打丝/毒雾。states284817为1HP/16挡，对石16＋卵8；284821石眩晕而卵2HP仍活，玩家死亡。选择帧的精确切击7伤依赖手牌，不能当作替代完整线的固定伤害。首试及第三试的目标与卵存活状态不同。',
 '计划提示和保留手牌快照已有实现；缺各合法弃牌分支的动态牌面、弃牌触发、目标及续步剩血核证，不能强制保留某牌或宣称替线必胜。'),
('P74C04AEPL1F F17 T1—9、F22 T1—6、F23 T1/3',
 'F22实盘53→9，T2/T4损20/24，下一F23仍9HP；主怪15HP/12毒的最后归零中间帧缺失。F23局部完整挡住石攻击后眩晕与卵继续攻击同时成立。原提案另含滑溜下火焰、毒、复活和一次翻倍，不能以一处已有模型覆盖全部联合消费。',
 '缺F22主怪最后归零中间帧，以及药水、复活、逐敌结算接下一战的联合消费者核证；本批未定位新增确定源码差额。'),
('G33HU22H2543 F48 T1/T8；P74C04AEPL1F F23第4次T3',
 'G33 decisions277909余像先与闪亮先候选分别18/10挡、75/107伤，原首牌身份缺口已有e784源码。P74弃牌后重新规划已实际发生；这些不能证明跨重规划的整条原线完整兑现，亦不能将已建立能力层数当作未支付的未来收益。',
 '投斧首牌身份与弃牌事实已有live祖先实现；跨重规划完整实线归属、余像累计收益与动态弃牌联合验证仍缺，不能把局部修复记为宽提案duplicate。'),
('G33HU22H2543 F31 T1—8、F33 T1—9、F48 T1—8；P74C04AEPL1F F22—23',
 'G33两场赢战83→46、76→17；P74 F22赢战53→9后空药接F23。含召唤/复活的敌HP净差不等完整需伤；SL恢复和实际休息/药水/幕间回复分别记录。原始分段净值见combat-timelines，不能将复活净增加当负伤害或把被截断轮当已执行败局。',
 '缺逐来源连续资源账的联合在线消费者验收，以及同条件路线、休息、SL和留药的受控后继，不能新增路线禁令、留药阈值或HP权重。'),
('G33HU22H2543 F48 T4/T7—8、F38/39/45开场；P74C04AEPL1F F17 T1—9、F22 T4—5、F23 T1/3',
 'run-config已保存五局完整源码commit与dirty_files；dirty项主要为当时生成知识。知道commit不等于复原dirty知识/移动表字节。多来源毒结算、临时减力、牌挡/被动挡/一次翻倍及开场净值必须逐项区分，不能以死亡反推组件机制全部错误。',
 '原运行源码提交已知，但dirty知识和移动表字节未完整恢复；缺多组件联合回放及独立校准，本批未发现可隔离的新源码修正。'),
('RC61MFQM63Y6 F33首/末次T1；第三次T4；末次T3—4',
 'decisions279021/279197指纹相同，首/末实挡16/12、损4/8、扣敌30/23，同瓶药均实际使用。首题原文为3轮2样本，末题5轮24样本；原提案将两者概括为五轮24/24的口径不能沿用作等预算配对。第三次T4生存者前states285414仅生存者/打击，285415手空、45HP/7挡，57激光判死但未结算。',
 '同指纹即时差额已核，但首次/末次推演预算不同；缺同预算整战、累计能力收益及独立验证，不能由全败饱和添加固定保血或先能力规则。'),
('BTSRF7JL1W1Y F31 T1—4；F17已施放步法反例',
 'decisions279852抽牌前最佳线与279854抽弃后防御/两刀打石线不是同一完整线路；后者4样本3胜1死，实T4甲虫22攻击对5牌挡＋1覆甲，14HP实际归零、敌13HP。需损16、存活至少还差3HP；一次死亡不能证明75%概率错误。',
 '抽弃后已换线；缺最终执行线对应的逐样本轨迹与独立校准，单局3/4样本线死亡一次不足修改概率权重或强制先杀甲虫。'),
('RC61MFQM63Y6 F17 T11、F33第3次T4/首末T1；BTSRF7JL1W1Y F31 T2重复证据',
 '普通生存者唯一余牌取消已由bf423源码实现；真实后继攻击没有派发，不能继续计转向或伤害。RC F17末轮呼唤自损须与毒终结分账；旧0205弃牌选择观察不等于0268独立根因。没有完整整战受控对照可估能力优先级。',
 '普通生存者唯一后继取消已有live祖先修复；跨选择整线归属、累计能力与呼唤自损的联合消费者仍未验收，不能把局部实现冒作整项完成。'),
('RC61MFQM63Y6 F24/F27/F32休息及F33 T1—4',
 'states285249→285250为20→41，285260→285261为41→62，285311→285312为31→52，三次各21合63。三火确已兑现，但F33仍六试未赢；五次SL各恢复原瓶药不等新得药，也没有同条件锻造/另路线/留药的完整实打胜局。',
 '三次休息合63及52HP实际入口已核；缺同条件路线、休息、后战对照和逐来源消费者验收，不能据此调整终局血价或路线规则。'),
]

results = []
sections = []
for index, (pid, detail) in enumerate(zip(dispatch['proposal_ids'], details), 1):
    item = items[pid]
    location, facts, reason = detail
    results.append({'id':pid,'state':'waiting','reason':reason})
    sections.append(f'''## {index}. {pid}

来源任务：{item['source_task']} → strategy-proposal；角色仅silent，直接证据进阶A10。
原提案：`{item['proposal']}`；登记SHA `{item['proposal_sha256']}`，本批实读匹配。
账本：{', '.join(item['ledger'])}。
证据位置：{location}。

核证与反例：{facts}

处置：**waiting**。{reason}

旧/新行为及预期：保留现行行为与全部合法候选；本批没有足够数据定义新增生产规则，无参数拟合和胜率改善估计。下一步只在上述缺口补齐后验证。固定回归只能验证该状态，整战收益需后置独立静默局并按原局分组；同局SL不拆成独立样本。没有改动需要回退，现有历史和失败材料保留。
''')

result = {'task':'strategy-proposal','character':'silent','batch':BATCH,'base':base,'runs':dispatch['runs'],
          'fixes':[],'skipped':[],'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},
          'code_proposals':dispatch['proposal_ids'],'implementation_domains':[],
          'proposal_results':results,'report':str(OUT/'report.md')}
(OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

table = '\n'.join('| '+m['stream']+' | '+str(sum(m['counts'].values()))+' | '+str(m['source_size'])+' |'
                  for m in json.loads((OUT/'evidence/evidence-manifest.json').read_text()))
common = f'''# 本批十项策略提案核证与处置

批次 `{BATCH}`；base `{base}`；角色silent。结论：十项均waiting，本批无新增源码/知识修改、提交、live合入或行为版本。已有窄实现不等于宽提案完成；没有新受控证据时不改SL、终局HP价值、出牌权重或路线/保药阈值。

## 派发和证据边界

从根learn.json只读取本批：task=strategy-proposal、character=silent、reason=proposal、state=running、工作树一致，正好十个proposal_ids；无proposal_repair/research_request/implementation_request，不承接其他批次专题。本树初始干净，git merge --no-edit main返回Already up to date；HEAD维持base。仅处理派发十项，不选其他队列项目。

五个派发局号：{', '.join(dispatch['runs'])}。runs.jsonl逐局均SILENT/A10，均于2026-10-07结束；未混入其他角色知识。五局旧数据不能冒称本轮新增独立验证局。没有读取游戏二进制、key或.env，没有网络、play、推送、下级agent或生产模拟。

通过本树learner/extract_evidence.py冻结八流；逐条封套包含source/line/offset/bytes/SHA和严格身份。总计{verified['raw_envelopes_verified']}行，全部逐offset重新读取原日志、比较原字节SHA及JSON正文。各流cutoff和输出SHA详见evidence/evidence-manifest.json；原日志只读。

| 流 | 本批行数 | 源字节截点 |
| --- | ---: | ---: |
{table}

fight-plans在该截点选中0行，只说明此cutoff/身份选择没有匹配行，不断言原日志缺失。run-plans按原run字段正确选到26行。states/decisions/brain源流分别有2个解析无效行，提取器记录并跳过；本批封套核证不代表全源日志完整。没有复用旧截点为零的初稿或覆盖旧报告。

## 当前源码与实际部署身份

本批对13个相关源码叶保存base与live快照的blob/SHA/字节数，见source-readback.json。只读live快照为`{source['live_snapshot']}`；此为磁盘提交，不作为原局dirty树或当前已加载运行树的证明。

实核base/live祖先：投斧首牌e784dd9f043bf87c29109573f48975f9903280d3；普通生存者单弃bf423c173d3be348a4ad714e1d26516df619ff41；弃牌手牌快照4b0823f519f1b724d6cff2b1cd50b74146dc4a9d；当轮SL资源5604982e13890e0e2bc8bf8246272e8267321c0b；候选对比c769739b97389fdc978b6515b83a38e3cd900f67；修复后集成a8b1f8be153fe4f3a34146117546c2178f2e446b。

原弃牌提示稿5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56不是base/live祖先，不能拿它作部署提交。当前selection.ts提供discard_plan剩余动作/条件预测，silent-discard-facts.ts只提供当前保留手牌快照，明确不推演弃牌触发和后续结果；单弃求解器只对唯一余牌给确定取消，未知选择继续重读。SL resource/candidate比较仍明确标模型预测与execution=unverified；这些事实不证明完整后继或自然策略收益。

## 验证、口径与限制

evidence-verification.json最终{verified['check_count']}项材料核证通过，含原始封套、关键实帧差额和源码运输身份；这是只读材料核验，不是生产tsc/vitest或候选整战验收。combat-timelines.json保存91个可见战斗片段及3238状态的原始分段，state-timeline.jsonl保留逐帧摘要。原始分段从首入房帧开始，可能含开场HP/敌伤变化，且复活/重附着使净差不是累计伤害；关键结论以明确可操作原帧及决策指纹核，不直接以分段首末差替代实打伤害。判死截断末轮也不算敌方动作已执行。

材料脚本失败原件均保留：首次身份检查误把SILENT与silent作大小写敏感比较；verify首稿把唯一余牌窗口错放285411/285413，复读后纠正为285414/285415；第二稿错误预期原5d7为实际祖先，修正为记录其非祖先身份并核a8b1集成；第三稿误写不存在的sim/whole-fight.ts，按实际文件改为sim/boss-sim.ts。原日志、原稿.txt与各轮失败log保留，最终完整核验另存complete.log，未将这些材料错误当生产缺陷或测试失败。

本批没有源码变动，故没有撤源码失败/恢复通过实验，没有运行tsc/vitest/sandbox，三项tests均null；没有gitleaks提交扫描、git commit、decision上线记录或eval版本，因为没有提交或上线。tracked-diff.patch为空，最终git状态另见completion-check.json。经验/账本原claim、首证、prior、支持/反例、status与version保持；只经根ledger.py追加本批报告/提案的追溯链接和note，不新增支持证据、不新建重复proposal id、不标shipped。原队列waiting状态由调度器消费最终proposal_results登记，不直接修改learn.json/队列。

## 口径异议与交接

RC原提案中“首末同为五轮24/24”不能当受控预算：原decisions279021为3轮2样本，279197为5轮24样本；即时同指纹差额仍成立。这与队列已有“首末题预算不同”的waiting限制一致，不能为了支持规则修改而抹去。关联silent-0079及第7/9项；本报告显式交ops沿既有ops→watcher→Roy链呈报此限制，不代填其他角色送达/已知回执，不把排队算送达。本批无已绑定的学习入库父request，不自行编辑根请求或造通知ACK。

十项宽提案保持待新证据，不因报告结束关闭父要求、不声称经验已入库、大脑已采用或胜率改善。若后续获得同预算/同抽序整战对照或完整分支轨迹，按下列逐项缺口复派；无需重复写旧复盘。

## 逐项处置

'''
body = common + '\n'.join(sections)
(OUT/'proposal.md').write_text(body)
(OUT/'report.md').write_text(body + '\n## 最终机器回报\n\n```json\n'+json.dumps(result,ensure_ascii=False,indent=2)+'\n```\n')

ledger_path = ROOT/'paper/materials/learning/ledger.jsonl'
ledger_raw = ledger_path.read_bytes()
ledger_ids = sorted({lid for item in items.values() for lid in item['ledger']})
before = {'path':str(ledger_path),'source_size':len(ledger_raw),'prefix_sha256':hashlib.sha256(ledger_raw).hexdigest(),
          'ids':ledger_ids,'by':'learner:strategy-proposal'}
(OUT/'ledger-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
with (OUT/'ledger-trace-updates.jsonl').open('w') as f:
    for lid in ledger_ids:
        d = {'id':lid,'by':'learner:strategy-proposal',
             'where':{'proposal':[str(OUT/'proposal.md'),str(OUT/'report.md')]},
             'note':f'{BATCH}：仅复核派发十项及五个Silent A10原局，均waiting。原始字节和局部已有源码身份见本批report.md；保留同预算整战、动态弃牌、联合资源和独立校准限制。此行仅追溯，不新增支持/反例，不改claim/首证/prior/status/version，不登记implemented/shipped。RC首题3轮2样本、末题5轮24样本，不能沿用原提案的等预算概括；该限制交ops沿既有链转交，不冒已送达。'}
        f.write(json.dumps(d,ensure_ascii=False)+'\n')
print(json.dumps({'report':str(OUT/'report.md'),'proposals':len(results),'ledger_trace_updates':len(ledger_ids)},ensure_ascii=False))

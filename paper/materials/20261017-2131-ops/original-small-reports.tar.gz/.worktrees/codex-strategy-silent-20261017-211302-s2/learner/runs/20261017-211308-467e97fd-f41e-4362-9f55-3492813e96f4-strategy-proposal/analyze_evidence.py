import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
rows = [json.loads(s) for s in (OUT / 'evidence/states.evidence.jsonl').open()]


def slim(x):
    state = x['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    return {
        'line': x['line'], 'sha256': x['sha256'], 'run': x['run_id'],
        'floor': run.get('floor'), 'turn': state.get('turn'),
        'hp': player.get('current_hp', run.get('current_hp')),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': {p['power_id']: p.get('amount') for p in player.get('powers', [])},
        'hand': [{'index': c.get('index'), 'id': c.get('card_id'),
                  'cost': c.get('energy_cost'), 'text': c.get('resolved_rules_text')}
                 for c in combat.get('hand', [])],
        'selection': None if not state.get('selection') else {
            k: state['selection'].get(k) for k in ('kind', 'prompt', 'min_select', 'max_select', 'selected_count')},
        'enemies': [{
            'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'block': e.get('block'),
            'alive': e.get('is_alive'), 'move': e.get('move_id'),
            'attack': sum(i.get('total_damage') or 0 for i in e.get('intents', [])),
            'powers': {p['power_id']: p.get('amount') for p in e.get('powers', [])},
        } for e in combat.get('enemies', [])],
    }


segments = []
active = None
previous = None
for x in rows:
    st = x['row']['state']
    floor = (st.get('run') or {}).get('floor')
    combat = st.get('combat') or {}
    if st.get('in_combat') and combat.get('player') and st.get('turn'):
        key = (x['run_id'], floor)
        reset = active is None or key != active['key'] or st['turn'] < previous['row']['state'].get('turn', 0)
        if reset:
            active = {'key': key, 'rows': [], 'after': None}
            segments.append(active)
        active['rows'].append(x)
        previous = x
    else:
        if active:
            active['after'] = x
        active = None
        previous = None

summary = []
attempts = collections.Counter()
for segment in segments:
    key = segment['key']
    attempts[key] += 1
    turns = collections.OrderedDict()
    for x in segment['rows']:
        turns.setdefault(x['row']['state']['turn'], []).append(x)
    turnlist = list(turns.values())
    result = {'run': key[0], 'floor': key[1], 'attempt_in_extracted_combat': attempts[key],
              'entry': slim(segment['rows'][0]),
              'exit_or_last': slim(segment['after'] or segment['rows'][-1]), 'turns': []}
    for i, frames in enumerate(turnlist):
        after = turnlist[i+1][0] if i+1 < len(turnlist) else segment['after']
        start, end = slim(frames[0]), slim(frames[-1])
        nxt = slim(after) if after else None
        hp = lambda frame: sum(e['hp'] or 0 for e in frame['enemies'] if e['alive'])
        result['turns'].append({'turn': start['turn'], 'start': start, 'pre_end': end, 'after': nxt,
                                'hp_net_loss': start['hp'] - nxt['hp'] if nxt else None,
                                'enemy_hp_net_removed': hp(start) - hp(nxt) if nxt and nxt['enemies'] else None,
                                'enemy_settlement_complete': after is not None})
    summary.append(result)
(OUT / 'combat-timelines.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
with (OUT / 'state-timeline.jsonl').open('w') as f:
    for x in rows:
        f.write(json.dumps(slim(x), ensure_ascii=False)+'\n')
focus = {'NHA2KW0RB7VP': [33], 'P74C04AEPL1F': [17, 22, 23], 'G33HU22H2543': [31, 33, 48],
         'RC61MFQM63Y6': [17, 33], 'BTSRF7JL1W1Y': [31]}
for c in summary:
    if c['floor'] not in focus[c['run']]:
        continue
    print(json.dumps({'run': c['run'], 'floor': c['floor'], 'attempt': c['attempt_in_extracted_combat'],
                      'entry_hp': c['entry']['hp'], 'entry_line': c['entry']['line'],
                      'last_hp': c['exit_or_last']['hp'], 'last_line': c['exit_or_last']['line'],
                      'turns': [{'t': t['turn'], 'loss': t['hp_net_loss'], 'damage_net': t['enemy_hp_net_removed'],
                                 'block': t['pre_end']['block']} for t in c['turns']]}, ensure_ascii=False))
print(json.dumps({'state_count': len(rows), 'segments': len(segments), 'counts': dict(collections.Counter(x['run_id'] for x in rows))}))

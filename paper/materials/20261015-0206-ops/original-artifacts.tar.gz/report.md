# 静默猎手策略队列报告

记录时间：2026-10-15T01:56:26+08:00

本批10项全部处置为waiting，未修改源码、知识、权重、药水、SL或终局规则。已实现的窄路径与宽提案未完成范围分别记录，不虚填duplicate/implemented/shipped。

## 身份与范围

- task=strategy-proposal，character=silent，batch=20261015-014302-strategy-proposal。learn.json该行reason=proposal，proposal_ids恰为本报告10项，没有proposal_repair/research_request/implementation_request。
- 开工干净HEAD为3e4b82d6485ed24b1c7213461f64d53dc1bea601；按普通任务要求git merge --no-edit main快进，无冲突，report.base=`ce7380056283f513fc226143dccea0f8f2deb069`。此后不追合新main。
- 专题普通匹配文件绑定20261010-150327，且本批带proposal_ids，不符合专题身份；未读取其他专题代替任务，未自行更改请求/learn.json。
- 派发runs只保留指定10局；额外9局仅来自这10个提案的原runs字段，没有领取其他id。全部19局runs.jsonl为SILENT，含A3/A4/A6/A7/A8/A10，不能混作同一进阶统计或推到其他角色。UJ0旧运行引擎含DeepSeek，保留历史原值；本次没有运行模型请求/对局。

| run | 进阶 | 结束层 | 原结果 |
|---|---|---|---|
| 10GPK5XGHCK3 | A3 | 48 | 胜 |
| 9YBKCNBFP0X5 | A4 | 48 | 负 |
| UACFSW4VDDLD | A6 | 48 | 负 |
| 4Y94N8RDPGPM | A7 | 48 | 胜 |
| LLYSRQQ35AVW | A8 | 48 | 胜 |
| UJ0K3G10609Y | A10 | 48 | 负 |
| TCFAHJ9K19VY | A10 | 17 | 负 |
| ZVYUL2YP3518 | A10 | 49 | 负 |
| UMVLWER4CD98 | A10 | 48 | 负 |
| HSX4HYATB4E2 | A10 | 48 | 负 |
| TDLBRNA0R05B | A10 | 49 | 负 |
| TXZ6RVMQA09D | A10 | 49 | 负 |
| 1913SE84AXQF | A10 | 31 | 负 |
| BTSRF7JL1W1Y | A10 | 31 | 负 |
| 9Z9H2EXKLF3T | A10 | 48 | 负 |
| K2JAGKVJAWZJ | A10 | 46 | 负 |
| 79UCJ0K6R9C1 | A10 | 14 | 负 |
| NEWRFAYKTQHR | A10 | 31 | 负 |
| 9R916WW0V65N | A10 | 49 | 负 |

## 证据冻结与字节验收

共用extract_evidence.py已提取8流；evidence/evidence-manifest.json逐流保存source_size、计数、输出SHA，每行保留source、line、offset、bytes、SHA及原row。audit_evidence.py独立seek原日志，33276行逐一核长度/截点/原字节SHA/JSON/显式身份，无角色混入。source_size不随之后日志增长变化。

| 流 | source_size | 本次行数 | 源流坏行/尾行 |
|---|---:|---:|---|
| states | 12836675586 | 16561 | 2/0 |
| decisions | 1445892019 | 15612 | 2/0 |
| sl-attempts | 39426593 | 137 | 0/0 |
| run-config | 1705790 | 19 | 0/0 |
| run-plans | 7824174 | 130 | 0/0 |
| brain | 529836255 | 798 | 1/0 |
| runs | 329447 | 19 | 0/0 |
| fight-plans | 2233957 | 0 | 0/0 |

130条run-plans使用run身份，不依正文提及；与各流run_id/state.run_id/fingerprint.run一致。坏行仅是原源全扫描计数，不计所选证据；fight-plans 0只说明本截点这19局未选到，不代表源全缺失。没有覆盖/重建旧零行报告，也未冒认核过旧截点。

## 逐项结果

| id | 既有账本 | 局/层/回合 | 处置及具体缺口 |
|---|---|---|---|
| silent-proposal-243ad8dd038a4ff6 | silent-0019,silent-0020,silent-0065,silent-0106 | K2JAGKVJAWZJ F33T1–11、F46T1/5/6/9 | waiting：原同首29抽蟹重打和三骑士资源对照仍只有实走线路；缺洗牌后可核同条件、单动作及另一整战/路线对照，不能据低损开场改SL或资源阈值。 |
| silent-proposal-9c3ff04261867dd2 | silent-0021,silent-0243,silent-0276,silent-0277,silent-0278 | K2JAGKVJAWZJ F15T2、F27T2、F33/F46 | waiting：F27铁心0挡→0挡、覆甲0→7已核；现有7覆甲代码不能闭合实际能力建立、逐槽药水与跨幕/饮药时点的全部资源消费者。 |
| silent-proposal-650ea306e8627f9e | silent-0010,silent-0012,silent-0013,silent-0019,silent-0020,silent-0021,silent-0046,silent-0065,silent-0077,silent-0106,silent-0115,silent-0178,silent-0243,silent-0276,silent-0277,silent-0278 | K2JAGKVJAWZJ 全局、F27T2/F33/F46；10GPK5XGHCK3 F17T5；UJ0K3G10609Y F33T7 | waiting：48条brain与71次含复用Codex决策已更正核实；来源勘误不等于关联16项机制、跨轮和资源实现全部验证，旧dirty运行源码仍未复原。 |
| silent-proposal-aff5ac3bb7cdb81b | silent-0079,silent-0135,silent-0167,silent-0168,silent-0010 | NEWRFAYKTQHR F31T2–4 | waiting：已有HP/伤害/格挡与毒端点对照；污染差额和饱和状态的完整结构记录、原答/实线及消费者尚未闭合，不能将死亡率并列视为资源等价。 |
| silent-proposal-60e68d681e861d1c | silent-0286,silent-0278 | 79UCJ0K6R9C1 F14T10–11；NEWRFAYKTQHR F17T7/F28T7/F31T2–4；其余原提案自有局 | waiting：持牌伤先于毒的窄路径已有live源码；毒药水仅有特定入口，头骨/制品及其他组合与完整消费者未齐，不能把窄实现当全提案duplicate。 |
| silent-proposal-9aa48a84227bcdb5 | silent-0019,silent-0020,silent-0243,silent-0021,silent-0276,silent-0277,silent-0259 | 79UCJ0K6R9C1 F14；NEWRFAYKTQHR F17/F28/F31 | waiting：实际HP/药槽和SL恢复可以分账；未执行路线、不同饮药时点与整战结果缺配对，不能拟留药价格或终局HP阈值。 |
| silent-proposal-7cfd0f9b6b0fbbda | silent-0012,silent-0005,silent-0016,silent-0080,silent-0046,silent-0084,silent-0011,silent-0023,silent-0010,silent-0123,silent-0168,silent-0079,silent-0135,silent-0133,silent-0289 | 79UCJ0K6R9C1 F14T2–4/T10–11；ZVYUL2YP3518 F33T6–8；NEWRFAYKTQHR F31T2–4 | waiting：坚韧之环即时挡已有通用读取，但两轮施放快照及叠层/重放尚无专用接线；显示power层数是2/1，不能用作7/11挡额度或按当前敏捷重算。 |
| silent-proposal-e6f9cb57c1204036 | silent-0286,silent-0278 | 同silent-proposal-60e68d681e861d1c：79UCJ0K6R9C1 F14T10–11等 | waiting：已遵循combat/potion领域勘误，不涉及终局价值；原感染/毒药水宽提案仍有未覆盖入口和组合，勘误不能代替实际实现验收。 |
| silent-proposal-8df611363cd82fc9 | silent-0291,silent-0085,silent-0005 | 9R916WW0V65N F49T1–2 | waiting：普通手动第三攻增敏及后继挡已证，当前仍缺苦无前瞻分支；stack与手动计数不同步，自动/重放混用及可靠入口/跨轮计数未验，不照搬其他攻击遗物计数。 |
| silent-proposal-6353ffbadaaac619 | silent-0228,silent-0290,silent-0291 | 9R916WW0V65N F42T7、F48T1–15、F49T1–2及F43–47资源链 | waiting：F48→F49实际12HP空药已核；缺F42独立复活/剩余充能观测，以及固定实际HP、药槽、种子和抽弃的两战配对与独立留出，不能改留药/终局权重。 |

每项支持、反例、旧行为/预期、验证、限制及回退见本目录proposal.md。10份原Markdown指纹均与队列登记相同，原文副本为各id.original.md。

## 当前源码与实际live覆盖

冻结当前live为`eafecc850a8ad55d36e67644236a98d196b61161`。source-audit.json逐叶记录base/live Git blob、SHA256、实际live祖先源码commit；17叶14字节相同，其余3叶差异逐行仅Roy/Dai署名替换，完整差异见base-live-selected.patch。只保存这17个所需源码.txt，没有全仓展开副本。此审计证明选定叶和祖先，不冒认旧dirty运行源码。

- turn-solver.ts已有持牌伤前缀死亡检查（历史源码2e6fa2e5c6，后续endBlockParts修订c1d8480495），所以不报告“感染完全漏算”。POISON_POTION仍依observedPoison上下文，不能将恶魔/双Boss入口外推所有敌人与制品/头骨组合。
- silent-sl-resource-comparison.ts及silent-sl-comparison.ts实际live源码祖先a8b1f8be153fe4f3a34146117546c2178f2e446b已提供HP/伤/挡、原/替预测及毒端点；TAINTED差额/饱和状态及完整消费未齐，不把已有毒端点说成缺失。其original_stage明确为护栏后、SL前，不能改称最初Jev原答。
- KUNAI仅在探索识别中见名，PlayerSim/attackRelics仍缺增敏前瞻。原帧手动计数3、stack3之后技能又使stack0；第四攻击手动数4/stack1。不能直接套别的遗物stack逻辑，缺口保留。
- TORIC_TOUGHNESS_POWER原帧amount=2/1只给剩余次数，未携7/11挡额度；当前BLOCK_NEXT_TURN_POWER路径是其他已观察机制，不能据名称相近认为覆盖了坚韧之环。
- 联合Boss既有continuationInput传递逐样本HP、剩药与revives；BATTLE_TRANCE同线noDraw已有实现。9R复活充能却无直接读数，本批不因已持有LIZARD_TAIL填可用，不重复实现既有接续，也不在未校准模型上拟留药价。

## 原帧核对与离线消费

check_observed_facts.py的43项固定原帧/来源/算术核对43通过：铁心0/7、棱柱5HP/−7伤/−7挡及毒/污染差、感染死前毒不结算、坚韧11快照跨两轮、苦无两条不同牌序、F48→F49 12HP空槽等。它们是材料验收，非生产测试或撤源码红绿。

现有audit-selection.ts使用明确限定层的投影输入，保留原line/observed_ts/fingerprint/decision_id；只删除消费者不读取的run大字段，原字节仍在evidence。没有补id/时间/尝试号，四输入排除决策均0。通过node --import tsx离线执行，不调用LLM/网络。

| run | 动作 | 片段 | 可连接观测区间 | 已核整轮端点/窗口 |
|---|---:|---:|---:|---:|
| K2JAGKVJAWZJ | 259 | 70 | 138 | 25/52 |
| NEWRFAYKTQHR | 241 | 63 | 219 | 35/53 |
| 79UCJ0K6R9C1 | 43 | 21 | 0 | 0/11 |
| 9R916WW0V65N | 542 | 108 | 407 | 43/77 |

合计1085动作、262片段、764可连接区间、321未知区间；103/193整轮端点，90窗口未知。所有动作都能匹配唯一时间/指纹状态，但不能跨房间/缺尝试元数据/缺源决策的边界连线；79局0区间源于缺显式同尝试元数据，不是原帧缺失。所有完整候选结果均null；这不能认证完整候选收益或新胜率规则。原始终局/药槽/能力与净HP变化各自保留，不将completed当整线已执行。

## 交付与限制

- 无源码修改：fixes=[]，merged=null；无源码提交、实际live合入、本批release_id、规则通知或shipped登记。merge=live流程因没有源码增量不执行。不运行play、不推送、不改运维prompt。铁甲及其他角色行为保持等价。
- tests={"tsc":null,"vitest":null,"cases":null}；未跑生产门禁、未撤源码，不用43材料核对或4消费者exit0冒充。
- 只经根目录learner/ledger.py update将本报告/提案追溯追加到既有35个silent账本；不改claim/status/version/first_run/asc/prior/evidence，不新造经验、提案或提交。CLI输入/输出/精确追加行与读回在本目录ledger-*文件；旧shipped不倒置为proposed。
- 未新增游戏结论或反对原证据；确认的输入边界、已有勘误及未证组合明确保留，waiting父项不关闭。后续需要可靠计数/快照/复活充能和受控/独立留出证据，不能只重复本窗口就提升置信度。
- gitleaks脱敏扫描结果见本目录gitleaks.exit与gitleaks.log。工作树最终核验见final-verification.json；报告自身存于忽略的learner/runs目录，未制作源码或记录提交。

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-014302/learner/runs/20261015-014310-strategy-proposal/report.md
提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-014302/learner/runs/20261015-014310-strategy-proposal/proposal.md

末次核验：HEAD等于report.base、git status干净、相对base全部tracked差异为空；10项处置与派发一致。gitleaks全目录扫描exit0（无大小跳过配置）。首轮沙箱准备失败和末次检查相对路径断言失败分别留原件，均非生产代码失败；未扩权限，有限重试与绝对路径修正后通过。

import json,pathlib,collections,datetime
p=pathlib.Path(__file__).parent
ss=list(map(json.loads,(p/'states.jsonl').open())); ds=list(map(json.loads,(p/'decisions.jsonl').open()))
r=json.loads((p/'0NMF36KX3F7Y-resources.json').read_text())
windows=[]
for c in r['combats']:
 if c['sequence']==12:continue
 end=c['exit'] or c['last']
 if c['sequence']==11:end=r['combats'][11]['last']
 frames=[x for x in ss if c['entry']['line']<=x['_source_line']<=end['line']]
 groups=[]
 for x in frames:
  t=x['state']['turn']
  if not groups or groups[-1][0]['state']['turn']!=t:groups.append([])
  groups[-1].append(x)
 def hp(x):return x['state']['run']['current_hp']
 def ehp(x):return sum(e['current_hp'] for e in (x['state'].get('combat')or{}).get('enemies',[]) if e['is_alive'])
 rows=[]
 for i,g in enumerate(groups):
  start=g[0];stop=groups[i+1][0] if i+1<len(groups) else g[-1]
  rows.append({'turn':start['state']['turn'],'need':ehp(start),'net_damage':ehp(start)-ehp(stop),'hp_loss':hp(start)-hp(stop),'lines':[start['_source_line'],stop['_source_line']]})
 windows.append({'floor':c['floor'],'sequence':c['sequence'],'entry':c['entry'],'end':end,'enemies':c['enemies'],'turns':rows})
(p/'turn-audit.json').write_text(json.dumps(windows,ensure_ascii=False,indent=2)+'\n')
for c in windows:
 print('F',c['floor'],'seq',c['sequence'],'need',[t['need'] for t in c['turns']],'net',[t['net_damage'] for t in c['turns']],'hp',[t['hp_loss'] for t in c['turns']])
# Actual state windows, rather than sl_attempt alone, identify the restarted process's continuation.
def attempt(d):
 if d['floor']!=17:return 0
 line=d['_source_line']
 return d.get('sl_attempt') or 1
# Match decision timestamps against six observed T1 entrances; process restart does not create an entrance.
starts=[c['entry']['ts'] for c in windows if c['floor']==17]
def key(d):return(d['floor'],sum(t<=d['ts'] for t in starts) if d['floor']==17 else 0,d['turn'])
noncontinue=[d for d in ds if d['label'].startswith('combat/') and d['label']!='combat/plan-continue']
code=[d for d in noncontinue if d['decider'] in ['code','code-fallback']]
jev=[d for d in noncontinue if d['decider']=='jev']
codekeys={key(d) for d in code};jevkeys={key(d) for d in jev}
print('code independent',len(code),'windows',len(codekeys),'onlycode',len(codekeys-jevkeys),'labels',dict(collections.Counter(d['label'] for d in code)))
print('continue origins',dict(collections.Counter('jev-plan' if 'Jev-chosen' in d['rationale'] else 'code' for d in ds if d['label']=='combat/plan-continue')))
print('low all',sum(d['decider']=='jev' and isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35 for d in ds),'combat',sum(d['decider']=='jev' and d['label'].startswith('combat/') and isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35 for d in ds))
focus=[]
for d in jev:
 offered=[];selected=[]
 for qname,q in d['questions'].items():
  ans=(d.get('answers')or{}).get(qname,{}).get('choice')
  for k,v in q.get('criteria',{}).items():
   try:v=json.loads(v)
   except:continue
   if isinstance(v,dict) and 'focus' in v:
    offered.append((k,v['focus']))
    if ans==k:selected.append((k,v['focus']))
 if offered:focus.append({'line':d['_source_line'],'key':key(d),'offered':offered,'selected':selected})
print('focus',json.dumps(focus,ensure_ascii=False))
(p/'focus-audit.json').write_text(json.dumps(focus,ensure_ascii=False,indent=2)+'\n')
print('potions changes')
for c in r['resource_changes']:
 if c['from']['potions']!=c['to']['potions']:print(c['from']['line'],c['to']['line'],c['to']['floor'],c['to']['turn'],c['from']['potions'],c['to']['potions'],c['restart_boundary'])
print('usage jev',dict(collections.Counter({k:sum((d.get('usage')or{}).get(k,0) or 0 for d in ds if d['decider']=='jev') for k in ['input_tokens','output_tokens','cache_hit_tokens']})))
print('usage codex actions', {k:sum((d.get('usage')or{}).get(k,0) or 0 for d in ds if d['decider']=='codex') for k in ['input_tokens','output_tokens','cache_hit_tokens']})
print('seconds decisions',(datetime.datetime.fromisoformat(ds[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(ds[0]['ts'].replace('Z','+00:00'))).total_seconds())
print('seconds config',(datetime.datetime.fromisoformat(ds[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat('2026-10-17T17:09:17.918+00:00')).total_seconds())

import json,pathlib,subprocess
p=pathlib.Path(__file__).parent
run='0NMF36KX3F7Y'
items=[
('silent-0019','support',9,None,'F9多尼斯异鸟胜56→20；羽毛及HEAL补至F12入口53，问号藤蔓及F13/F14/F15胜战逐段53→30→20→2→1；F16羽毛12及休息21到34。F11所选HEAL档boss投影70，实到34，无其他路线整战对照。'),
('silent-0079','repeat',17,3,'第6试d427760：Jev防守候选伤10/损1，SL改伤14/损9，候选多4伤多付8HP；两线五轮均24/24死。d427763弃中和后旧后继失效、改偏折，实T3伤12/损6/挡13（s442394→442400）。不将未执行原线或弃牌前整线当实盘，也不证明原线可赢。'),
('silent-0365','repeat',17,3,'d427760/s442394同ts，两毒药合法目标[0,1,2]而整回合各仅前二，遗漏神官槽2。本局66道适用整线题均漏2（首领60），39道单动作列全；当前只读live215d73d combat-plan.ts:3887预留最多2、:4024 slice(0,2)。fix-queue-v4:1022已有。'),
('silent-0021','support',17,5,'六次未杀任何同族敌人；末试五轮净扣11/23/12/25/32，合103/324，死亡后敌42/49/130。2敏捷已兑现但未补输出缺口，缺触媒/毒雾；不从六次失败证明构筑必输或指定必胜顺序。'),
('silent-0005','support',17,1,'普通步法实建2敏捷，末试s442386→442389两防御各7合14，比基础10多4；T3防御7+偏折6合13，比基础9多4，对19攻仍损6。不是每轮自动格挡，无玩家力量增益。'),
('silent-0012','support',17,5,'末试T4尖啸令信徒力量3→-3/神官0→-6，唯一8攻击变2；T5撤减力并成长后信徒6/3、神官3，原威胁11+10+12=33，中和及突然一拳降至11+6+9=26，12挡/10血仍死。只补本局A10事实。'),
('silent-0278','support',17,5,'末试s442409→442411两瓶毒药各使第一信徒毒加6，0→6→12，HP54保持；s442412真实结12到42。前五试判死前未结算毒不预支伤害，无头骨/制品或触媒增量外推。'),
('silent-0142','support',11,None,'取得羽毛后F11到火20→32回12、HEAL32→53另21；F16到火1→13回12、HEAL13→34另21。maxHP70；遗物到火与休息动作、SL恢复分账，未据此拟拿牌增回公式。'),
('silent-0498','support',17,5,'六次混沌/格挡在首试T6、后五试T5使用；两毒首试T9神官、第2/4试T6第一信徒、第3/5/6试T5第一信徒。均先混沌占自身槽补一格挡、后两毒，无先清毒槽再补药的完整受控实线；有时点变化不等穷尽或早饮获胜。')]
updates=[]
for ident,role,floor,turn,note in items:
 e={'run':run,'floor':floor,'note':note,'role':role}
 if turn is not None:e['turn']=turn
 updates.append({'id':ident,'by':'learner:postmortem','evidence':[e],'where':{'lessons':[run]},'note':'来源任务：20261018-021305-4e13fb06-2fb6-4081-bed7-d330dd29d3f3-postmortem；只追加本角色证据，原claim/first_run/prior/status/version保持。'})
(p/'ledger-updates.json').write_text(json.dumps(updates,ensure_ascii=False,indent=2)+'\n')
results=[]
for item in updates:
 r=subprocess.run(['python3','/home/dw/Projects/agent-sts2/learner/ledger.py','update'],input=json.dumps(item,ensure_ascii=False),text=True,capture_output=True)
 results.append({'id':item['id'],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});print(item['id'],r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
 (p/'ledger-cli-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)

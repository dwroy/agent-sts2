import json,pathlib,bisect
p=pathlib.Path(__file__).parent
ss=list(map(json.loads,(p/'states.jsonl').open())); ds=list(map(json.loads,(p/'decisions.jsonl').open())); times=[d['ts'] for d in ss]
miss=[];single=[]
for d in ds:
 if d['label'] not in ['combat/plan-choice+potion','combat/play']:continue
 ts=d['ts'];idx=bisect.bisect_right(times,ts)-1
 if idx<0:continue
 s=ss[idx]
 eligible=[x for x in s['state']['run']['potions'] if x.get('occupied') and x.get('potion_id')=='POISON_POTION' and 2 in x.get('valid_target_indices',[])]
 if not eligible or not d.get('questions'):continue
 cri={k for q in d.get('questions',{}).values() for k in q.get('criteria',{})}
 bad=[x['index'] for x in eligible if f"p{x['index']}->e2" not in cri]
 row={'floor':d['floor'],'turn':d['turn'],'same_turn':s['state']['turn']==d['turn'],'decision':d['_source_line'],'state':s['_source_line'],'observed_ts':ts,'slots':[x['index'] for x in eligible],'missing':bad,'keys':sorted(k for k in cri if k.startswith('p')and'->e'in k)}
 if d['label']=='combat/plan-choice+potion':miss.append(row)
 if d['label']=='combat/play':single.append(row)
(p/'potion-target-audit.json').write_text(json.dumps({'whole_turn':miss,'single_action':single},ensure_ascii=False,indent=2)+'\n')
print('wholeturn',len(miss),'missing',sum(bool(x['missing'])for x in miss),'single',len(single),'single missing',sum(bool(x['missing'])for x in single));print('firstlast',miss[:1],miss[-1:]);print('evidence',next(x for x in miss if x['decision']==427760))
print('sl nonzero audit')
for d in ds:
 a=d.get('selection_audit')or{};delta=a.get('sl_delta')or{}
 if any(delta.get(k,0)!=0 for k in ['hp_loss','damage','strength_gained','lasting_value']):print(d['_source_line'],d['floor'],d['turn'],d.get('sl_attempt'),delta)
print('hp guard keys',[k for d in ds for k in d if 'guard'in k.lower()])
a=json.loads((p/'ledger-before.json').read_text());d=next(d for d in a if d['id']=='silent-0079');print('0079',d['status'],d['version'])
(p/'extraction-notes.md').write_text('初次药水覆盖抽取误用valid_targets，未匹配原state字段valid_target_indices，零样本后触发StopIteration；第二轮漏处理无questions的代码续步触发KeyError。最终脚本只对整回合和单动作题按原字段审计，失败零计数不使用。一次ledger find的FO G MOG参数错误退出2，后续已用中文药水/怪名及完整ID核对。原日志和失败历史保留。\n')

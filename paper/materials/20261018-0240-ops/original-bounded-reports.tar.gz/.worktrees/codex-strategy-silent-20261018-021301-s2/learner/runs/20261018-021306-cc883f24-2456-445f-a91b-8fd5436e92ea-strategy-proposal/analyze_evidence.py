import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FLOORS = {
    'DUZUBAJ3A8GP': {27, 30},
    '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48},
    'XP2SL33HT0D9': {33},
}


def powers(raw):
    return {p['power_id']: p.get('amount') for p in raw or []}


def reference(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def main():
    evidence = HERE / 'evidence'
    manifest = json.loads((evidence / 'evidence-manifest.json').read_text())
    validation = []
    targets = []
    decisions = []
    state_keys = set()
    for stream in manifest:
        name = stream['stream']
        counts = collections.Counter()
        output = evidence / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
            with output.open('rb') as extracted:
                for encoded in extracted:
                    digest.update(encoded)
                    item = json.loads(encoded)
                    source.seek(item['offset'])
                    raw = source.read(item['bytes'])
                    assert hashlib.sha256(raw).hexdigest() == item['sha256']
                    assert json.loads(raw) == item['row']
                    row = item['row']
                    counts[item['run_id']] += 1
                    if name == 'states':
                        state = row['state']
                        state_keys.add((state.get('run') or {}).get('character_id'))
                        combat = state.get('combat') or {}
                        floor = (state.get('run') or {}).get('floor')
                        if floor not in FLOORS[item['run_id']] or not combat:
                            continue
                        player = combat.get('player') or {}
                        targets.append({
                            'ref': reference(item), 'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
                            'floor': floor, 'turn': state.get('turn'), 'screen': state.get('screen'), 'in_combat': state.get('in_combat'),
                            'hp': player.get('current_hp'), 'block': player.get('block'),
                            'energy': player.get('energy'), 'played': player.get('cards_played_this_turn'),
                            'attacks': player.get('attacks_played_this_turn'), 'powers': powers(player.get('powers')),
                            'hand': [{'id': c.get('card_id'), 'upgraded': c.get('upgraded')} for c in combat.get('hand') or []],
                            'enemies': [{
                                'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                                'max_hp': e.get('max_hp'), 'block': e.get('block'), 'move': e.get('move_id'),
                                'alive': e.get('is_alive'), 'powers': powers(e.get('powers')),
                                'intents': [{'type': i.get('intent_type'), 'damage': i.get('damage'), 'hits': i.get('hits')} for i in e.get('intents') or []],
                            } for e in combat.get('enemies') or []],
                        })
                    elif name == 'decisions' and row.get('floor') in FLOORS[item['run_id']]:
                        decisions.append({'ref': reference(item), 'row': row})
        assert digest.hexdigest() == stream['output_sha256']
        assert all(counts[r] == n for r, n in stream['counts'].items())
        validation.append({'stream': name, 'source_size': stream['source_size'], 'counts': dict(counts), 'verified_rows': sum(counts.values()), 'source_bytes_sha256_and_json': True, 'output_sha256': digest.hexdigest()})
    assert state_keys <= {'SILENT'}, state_keys
    (HERE / 'source-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
    (HERE / 'target-states.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in targets))
    (HERE / 'target-decisions.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in decisions))
    print(json.dumps({'streams': validation, 'target_states': len(targets), 'target_decisions': len(decisions)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

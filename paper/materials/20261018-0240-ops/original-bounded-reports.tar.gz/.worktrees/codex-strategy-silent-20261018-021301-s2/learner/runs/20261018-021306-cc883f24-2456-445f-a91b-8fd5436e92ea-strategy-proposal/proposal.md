# 本批静默策略提案逐项处置

记录时间：2026-10-18T02:26:12+08:00。batch=20261018-021301-s2-strategy-proposal；base=9ed8ac27c45992bf48e6526c38bd77c8bbfa8132。

本批是普通已领取队列任务：task=strategy-proposal、character=silent、reason=proposal，proposal_ids共10项，无research_request/implementation_request/proposal_repair。本批与根牌数研究的旧绑定不匹配，按普通队列执行，不借用其他专题。开工工作树干净，已执行git merge --no-edit main（Already up to date）。六局均经runs.jsonl核实为SILENT/A10/败局；不读取其他角色知识、不将历史正文提及当成所属局。

结果：10项waiting，生产源码和knowledge零改动，fixes=[]，merged=null。既有窄实现不能替代整项验收；本批未新建重复id，未冒填implemented/duplicate/shipped或版本。没有代码提交、无live写入、无LLM/网络/对局动作；本批只在scratch留材料并经根ledger CLI追加处置链接。

抽取使用共用learner/extract_evidence.py，显式身份按run_id/state.run_id/run/fingerprint.run核，冲突拒收。八流共8274行，已逐行按原offset/bytes重新读取SHA及JSON并核输出SHA；证据清单在evidence/evidence-manifest.json与source-validation.json。fight-plans零行仅表示本截点未选到本批行，不证明原日志缺失。states/decisions/brain各有2个全流invalid_lines，本批不靠无效行下结论。

材料核对11项机制、4组同指纹局部窗全部通过，详见mechanism-facts.json、paired-facts.json与findings.stdout.json；不是tsc/Vitest或撤源码测试。未修改生产源码，tests固定使用null，不制造成功测试。抽取与核对均nice单进程；初步读状态时遇combat=null的探索命令失败，后续分析显式处理；初版目标筛选未包含GAME_OVER，v2修正并重新回读8274行，初版stdout/stderr保留。未将中间筛选缺帧判为原日志缺失。

六局run-config记录的开局生产Git提交可追溯，dirty_files所列为knowledge及少量notes，没有列生产源码；当前缺的是旧运行时实际知识表完整字节与调用归属，不能笼统把dirty当作源码未知，也不能用当前刷新知识代替旧输入。详见runtime-input-limits.json。只读取本批六局证据与其相关静默经验，未重验原宽专题/101局历史支持分母。

固定源码读回记录在source-readback.json：15个相关源码叶的所记源码提交均是固定live 215d73daca47f0ec0f699be41d1504ee5279fa3f 的真实祖先。三个文件与base的差异只为注释署名，已保存base-live-source-comments.patch；不覆盖并行live更改。本次没有将源码在live中存在、模型单步正确或端点吻合等同为完整联合候选认证。

## silent-proposal-c20b5139dd0dff71：棱柱污染与技能血价

来源任务：experience-update；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-c20b5139dd0dff71.md`，与队列SHA256一致。

证据：DUZUBAJ3A8GP F27 T4—6。states 274830—274839：污染0→3→3→6；后继火花为6，三技能污染6/12/18，T6清除；T4损3、T5损9。

既有学习账本：silent-0168。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：turn-solver.ts:2145、2978及rollout.ts:2419已有技能污染、逐击伤害与火花增长路径；silent-sl-resource-comparison.ts已有污染预测分栏。

反例与限制：技能同时提供挡、毒或抽弃牌收益，不能由损9认定所有技能有害。

预期行为及验证：仅核现场技能净效果与逐击污染成本，保留候选；有完整原输入后逐状态重放，不能先新增禁技能规则。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。缺该局运行时实际移动表字节及火花增长、污染清除、弱、毒、格挡的联合生产重放认证；缺同抽序完整替线。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-ae9e692d680e3819：抢夺、返还与负属性

来源任务：experience-update；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-ae9e692d680e3819.md`，与队列SHA256一致。

证据：5PM6JAQG6FNQ F39 T4—6。states 274351—274358：力敏各−4，两次步法使敏−4→−2→0；失落毒死后力量−4→0；274362遗忘再次夺敏至−2。

既有学习账本：silent-0183, silent-0005。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：当前负属性可进入牌值计算；源码搜索POSSESS两个power只定位到combat-plan的已识别能力清单，不能因此认证逐来源返还模型。

反例与限制：末试一步法只恢复至−2敏，毒杀失落后仍不能承受遗忘攻击；单次返力不证明全部返还条件。

预期行为及验证：按实体及来源分别记录实际夺取与返还；拿到步法不预支正敏捷，不设固定击杀序；补齐来源状态与退场前后帧后验证。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。缺逐实体累计夺取来源、遗忘退场返敏端点及另一目标顺序的整战后继；当前总属性不能唯一还原被夺来源。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-52f1e1bd2e7db0ed：下水道蚌加压与当前进阶事实

来源任务：experience-update；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-52f1e1bd2e7db0ed.md`，与队列SHA256一致。

证据：CA5KE8GFJ9X2 F13 T1—5。states 273238/273252/273263：力0/4/8，同喷水11/15/19；覆甲现场9/8/6。原五轮轮初序列9/9/8/7/6保留。

既有学习账本：silent-0231。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：monster-db.ts:711/843与rollout-live.ts:271从当前进阶首个观测读攻击/HP；room-costs.ts的MEASURED_ROOM_MIN_N仍5。rollout.ts有移动增力及覆甲分栏。

反例与限制：虚弱会降低当前意图但不消除后续增力；观察到覆甲递减不能推定未隔离的全部条件。

预期行为及验证：保留首样本怪物事实与五样本房间成本的区别；补原移动输入及完整结算帧后校验，不拟固定房间损血或新减层规则。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。当前进阶取数子项已有实现；仍缺旧实际输入下加压、覆甲与弱的联合重放及完整减层条件，不足以关闭整项。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-6dd8bbff876be528：电击机器人逐实体成长

来源任务：experience-update；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-6dd8bbff876be528.md`，与队列SHA256一致。

证据：5PM6JAQG6FNQ F38 T3—4。states 274308/274313：23上限电击力2→4、攻17→19，index4→3；T3玩家61→31。原候选先杀线未实打。

既有学习账本：silent-0233, silent-0209。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：rollout.ts:528/2402已有HIGH_VOLTAGE_POWER增长路径及spawnedEnemy初始化，移动表按当前进阶读取。

反例与限制：index改变不是新召唤证明；先杀爪牙候选35伤/损3未执行，不能称必多保27血或救下场。

预期行为及验证：将连续存活实体的增长与新召唤初态分别核验；补代际身份/召唤前后帧及实际表后再做联合重放，不规定通用杀序。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。旧日志只有enemy_id与可重排index，缺可靠召唤代际标识、旧实际移动输入及另一杀序完整后继，不能认证全部重置条件。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-578e415a259e6835：沙虫选择、护栏与执行分段

来源任务：experience-update；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-578e415a259e6835.md`，与队列SHA256一致。

证据：8JRE1C4H4Z2W F33 第1/3试T2、第2试T5、末试T11；F17 T6。decisions270216/270282指纹相同，states276208→276212与276274→276278核实损3/15、扣10/17；五轮候选为0/24与5/24死亡，不能写成同死率。

既有学习账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：silent-selection-audit、silent-selection-dispatch、silent-hp-guard-audit及hand/loop接线已在live；actual_turn/actual_outcome/whole_plan_executed保留null。

反例与限制：第二试T5护栏候选省12血少18伤；末试T2省3血少10伤且更晚死亡，不能把所有防御替换都判错；候选省血不自动等于实际省血。

预期行为及验证：继续按原答、护栏、SL、派发与重规划分别审计，不加成长/血价系数；未来核完整段落及来源账，保留判死截断与SL恢复。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。已有候选、派发与端点审计；仍缺完整续步归属、沙坑逐来源和路线资源链的联合认证及完整替线后继。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-c0767768bf6a7ab1：实验体全败SL的实付资源差

来源任务：postmortem；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-c0767768bf6a7ab1.md`，与队列SHA256一致。

证据：YF0LXT1QSTGG F48 第2/3试T1；第4试T5；F33第2试。decisions271309/271348指纹相同；states277327→277337和277366→277373：损0/9、敌本体净扣45/38；候选24/24死亡不能当安全。

既有学习账本：silent-0079。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：silent-sl-resource-comparison及combat-plan的SL前后记录已有；单动作回执明确state_effect_verified=false、whole_plan_executed=null。

反例与限制：第4试T5抽弃牌后候选未完整执行；第6试补防御续步仍败；F33有SL实胜，不能否定全部SL。

预期行为及验证：保留全败封顶、原答/替换与未执行续步的事实；未来以完整执行段与同预算整战后继验收，不改探索门槛。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。缺完整候选执行、逐来源血价认证和独立整战胜线；端点差额不能据以拟惩罚系数或禁止探索。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-a46bdb7fe711d79a：实验体分阶段毒与敏捷兑现

来源任务：postmortem；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-a46bdb7fe711d79a.md`，与队列SHA256一致。

证据：YF0LXT1QSTGG F48 末试T3—5。states277512/277513新阶段212且旧毒、旧力归零；277519零毒而触媒2；277523先得23挡，277526后加敏至6仍23挡；277528实死。

既有学习账本：silent-0021, silent-0027, silent-0028, silent-0085。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：silent-phase-current.ts已按A10/F48/已见签名提供当前快照；rollout.ts已有换阶段清毒/清力；旧挡不由后加敏倒补。

反例与限制：前五试第二阶段曾建立毒雾或余像仍败；持有或升级毒牌不等于该阶段实际施放，不能认未启动毒是唯一死因。

预期行为及验证：继续分持有、已建、实毒、即时施毒、已结毒伤与未执行候选；补完整来源与执行窗口才验证新展示/排序，不预支未来毒。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。当前阶段快照已有实现；逐候选施毒、已结毒伤、额外扣血和敏捷取得顺序仍缺完整执行归属，不调整排序。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-1044224808015e5c：双蟹B2零胜并列血价

来源任务：postmortem；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-1044224808015e5c.md`，与队列SHA256一致。

证据：XP2SL33HT0D9 F33 第1/2试T3、第1/6试T1、第3试T4。decisions271992/272040同指纹：states278028→278031与278076→278079损9/14、扣24/27；271982/272195同指纹：损2/10、扣25/34。

既有学习账本：silent-0079。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：SL资源差及候选阶段审计已有；explore.ts:1552与1564仍按B2/死亡比例及原排名选未试线，符合既有允许探索的规则。

反例与限制：T1替线还获得手里剑1力；末试T2临减/朝向零损，T3保挡损4；不能只按输出或少挡牌数下结论。

预期行为及验证：本轮血价、输出、永久成长与样本门槛分列；将本局仅作发现/固定验收，后移新独立A10同类局才评窄并列策略。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。当轮血价已核；缺同抽序完整替线、成长兑现后继和独立整战胜线，不拟全局HP系数或新并列规则。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-7cbc6005db712ba9：双蟹朝向、临减与轮初挡

来源任务：postmortem；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-7cbc6005db712ba9.md`，与队列SHA256一致。

证据：XP2SL33HT0D9 F33 末试T2—5。states278236/237/242临减0→−9→0，14轮初挡加牌挡到20；278249/252/253攻击57→38→28；278255为4敏脆弱下6挡。

既有学习账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：passive-pieces.ts:107—108已有T2/14挡；rollout.ts恢复临减，turn-solver已有朝向与挡计算；silent-kunai限制未核组合。

反例与限制：能力已建立仍未减员且战败；转向与虚弱的下降分别19/10，不能混作单一因果；普通观察不自动补未知升级组合。

预期行为及验证：仅补有证据的缺项参考；先重放完整实际前缀、敌方结算及临减恢复，不变更出牌权重或能力优先级。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。格挡、朝向及观察参考有窄实现；缺逐候选完整联合执行认证，本批没有可确证的新源码失配，不冒标整项duplicate。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

## silent-proposal-c59f592f1427a67e：两局能力、SL与路线资源综合核验

来源任务：experience-update；目标strategy-proposal；角色silent，仅本批A10证据。原Markdown保存为本目录`silent-proposal-c59f592f1427a67e.md`，与队列SHA256一致。

证据：YF0LXT1QSTGG F48 T1/T3—5；XP2SL33HT0D9 F33 T1—5；原路线/休息链。本批四组同指纹局部配对与11项机制端点重新核对；全部仍属于6局中的局部窗，未重做原101局/1499房历史研究。

既有学习账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。原经验/账本状态、首证、历史claim、支持数均保留；本轮只追加处置与报告链接，不重复写复盘或support/repeat。

旧规则/已有实现：SL资源/选择/派发、当前阶段和HP护栏审计已在live；现有静默经验25条已读取，历史支持数仅作原经验内容，未冒称本批重新验证。

反例与限制：SL恢复不计新回血，药水恢复不计新取得；前段胜战可消耗后场资源，单次净HP端点不能分解全部原因。

预期行为及验证：复用原提案去重接续，分栏毒/直伤/遗忘/临减/回血/药水/SL；补完整链后验收，不拟必休血线、留药或终局权重。 固定输入核对只认证材料，新增生产实现必须另做撤源码失败、恢复通过及原沙箱入口测试。按独立run_id分训练/验证，同存档尝试不扩分母；本批不拟合参数。

处置：waiting。逐来源资源账和完整候选执行尚未联合认证；缺路线、药水时机受控替线及独立整战后继。

预期影响与回退：当前仅保存证据、缺口及既有提案链接，没有行为变化或待回退源码；后续实现须引用实际live祖先、单独源码提交与按规则通知。Roy-2026-10-07-learning是权限依据，不是游戏事实。

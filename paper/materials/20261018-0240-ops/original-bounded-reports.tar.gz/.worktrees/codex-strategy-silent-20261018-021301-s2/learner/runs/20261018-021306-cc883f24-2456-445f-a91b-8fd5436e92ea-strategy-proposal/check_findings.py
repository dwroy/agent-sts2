import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    states = {x['ref']['line']: x for x in map(json.loads, (HERE / 'target-states.jsonl').open())}
    decisions = {x['ref']['line']: x for x in map(json.loads, (HERE / 'target-decisions.jsonl').open())}
    pairs = []
    for a, b, sa, ea, sb, eb, expected in [
        (270216, 270282, 276208, 276212, 276274, 276278, (3, 15, 10, 17)),
        (271309, 271348, 277327, 277337, 277366, 277373, (0, 9, 45, 38)),
        (271992, 272040, 278028, 278031, 278076, 278079, (9, 14, 24, 27)),
        (271982, 272195, 278018, 278023, 278231, 278236, (2, 10, 25, 34)),
    ]:
        da, db = decisions[a], decisions[b]
        assert da['row']['fingerprint'] == db['row']['fingerprint']
        start_a, end_a, start_b, end_b = (states[n] for n in (sa, ea, sb, eb))
        for decision, state in ((da, start_a), (db, start_b)):
            assert decision['row']['observed_ts'] == state['observed_ts']
            assert decision['row']['ts'] < (end_a if decision is da else end_b)['observed_ts']
        hp_a, hp_b = start_a['hp'] - end_a['hp'], start_b['hp'] - end_b['hp']
        net_hp = lambda state: sum(e['hp'] for e in state['enemies'])
        damage_a, damage_b = net_hp(start_a) - net_hp(end_a), net_hp(start_b) - net_hp(end_b)
        assert (hp_a, hp_b, damage_a, damage_b) == expected
        pairs.append({
            'run_id': da['ref']['run_id'], 'floor': da['row']['floor'], 'turn': da['row']['turn'],
            'attempts': [da['row']['sl_attempt'], db['row']['sl_attempt']],
            'decisions': [da['ref'], db['ref']], 'fingerprint_equal': True,
            'fingerprint_sha256': hashlib.sha256(da['row']['fingerprint'].encode()).hexdigest(),
            'state_endpoints': [x['ref'] for x in (start_a, end_a, start_b, end_b)],
            'hp_losses': [hp_a, hp_b], 'enemy_body_net_losses': [damage_a, damage_b],
            'replacement_minus_original': {'hp_loss': hp_b - hp_a, 'enemy_body_net_loss': damage_b - damage_a},
            'candidate_comparison': db['row']['sl_explore'],
            'scope': '已观测当轮净端点差；非逐来源伤害归属、完整候选执行认证或整战反事实。',
        })
    checks = []

    def check(label, actual, expected, lines):
        assert actual == expected, (label, actual, expected)
        checks.append({'claim': label, 'actual': actual, 'expected': expected, 'evidence': [states[n]['ref'] for n in lines]})

    check('棱柱技能污染及能力不追加', [states[n]['powers'].get('TAINTED_POWER', 0) for n in (274830, 274831, 274832, 274833)], [0, 3, 3, 6], (274830, 274831, 274832, 274833))
    check('棱柱后继技能增6且次轮清除', [states[n]['powers'].get('TAINTED_POWER', 0) for n in (274834, 274836, 274837, 274838, 274839)], [0, 6, 12, 18, 0], (274834, 274836, 274837, 274838, 274839))
    check('蚌加压力量', [states[n]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) for n in (273238, 273252, 273263)], [0, 4, 8], (273238, 273252, 273263))
    zap = [next(e for e in states[n]['enemies'] if e['id'] == 'ZAPBOT') for n in (274308, 274313)]
    check('电击连续增长，index重排不作新生证明', [e['powers']['STRENGTH_POWER'] for e in zap], [2, 4], (274308, 274313))
    check('负敏步法实建及失落毒死后力量返还', [states[n]['powers'].get('DEXTERITY_POWER', 0) for n in (274351, 274352, 274354)], [-4, -2, 0], (274351, 274352, 274354))
    check('失落退出后的返力端点', [states[n]['powers'].get('STRENGTH_POWER', 0) for n in (274357, 274358)], [-4, 0], (274357, 274358))
    check('实验体新阶段毒力清除', [states[277513]['enemies'][0]['max_hp'], states[277513]['enemies'][0]['powers'].get('POISON_POWER', 0), states[277513]['enemies'][0]['powers'].get('STRENGTH_POWER', 0)], [212, 0, 0], (277512, 277513))
    check('苦无后加敏不补已生成23挡', [states[n]['block'] for n in (277523, 277526)], [23, 23], (277523, 277526))
    check('双蟹临时减力次轮恢复', [states[n]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) for n in (278236, 278237, 278242)], [0, -9, 0], (278236, 278237, 278242))
    check('船夹板及新增牌挡', [states[n]['block'] for n in (278236, 278240)], [14, 20], (278236, 278240))
    check('火箭转向与弱分别记账', [states[n]['enemies'][1]['intents'][0]['damage'] for n in (278249, 278252, 278253)], [57, 38, 28], (278249, 278252, 278253))
    (HERE / 'paired-facts.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
    (HERE / 'mechanism-facts.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'paired_windows': len(pairs), 'mechanism_readbacks': len(checks), 'kind': '仅材料核对，未运行生产测试'}, ensure_ascii=False))


if __name__ == '__main__':
    main()

import json,pathlib,hashlib,collections,bisect,datetime,re
root=pathlib.Path('/home/dw/Projects/agent-sts2');p=pathlib.Path(__file__).parent
checks=[]
def ck(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
expect={
 'PTGQF9BEQ6G1':{'ds':835,'ss':856,'brain':33,'plans':9,'sl':7,'combats':20,'acquired':11,'jev':206,'low':14,'best':146,'notbest':23,'missingbest':7,'independent':30,'entry':81,'max':81,'death':14,'end_enemy':[44,69]},
 'A3X30TN54LSH':{'ds':195,'ss':201,'brain':11,'plans':3,'sl':0,'combats':6,'acquired':1,'jev':32,'low':2,'best':28,'notbest':0,'missingbest':0,'independent':12,'entry':42,'max':70,'death':10,'end_enemy':[11]}}
compact=json.loads((p/'compact-audit.json').read_text())
for run,e in expect.items():
 rows={}
 for name in ['runs','states','decisions','brain','run-plans','sl-attempts','run-config']:
  rows[name]=[json.loads(l) for l in (p/f'{run}-{name}.jsonl').open()]
  with (root/f'logs/{name}.jsonl').open('rb') as f:
   for w in rows[name]:
    f.seek(w['offset']);original=json.loads(f.readline());ck(f'{run}/{name}:{w["line"]} 原始偏移逐行一致',original==w['row'])
 ds=[w['row'] for w in rows['decisions']];ss=rows['states'];cfg=rows['run-config'][0]['row'];rr=rows['runs'][0]['row'];res=json.loads((p/f'{run}-resources.json').read_text());pots=json.loads((p/f'{run}-potion-audit.json').read_text())
 ck(run+'角色与完局',rr['character'].lower()=='silent' and bool(rr['ended']) and rr['victory'] is False)
 for n,actual in [('ds',len(ds)),('ss',len(ss)),('brain',len(rows['brain'])),('plans',len(rows['run-plans'])),('sl',len(rows['sl-attempts'])),('combats',len(res['combats'])),('acquired',pots['acquired'])]:ck(run+'/'+n,actual==e[n])
 ck(run+'饮药瓶数',len(pots['drinks'])==e['acquired'])
 ck(run+'无弃药动作',not any(d.get('chosen',{}).get('action')=='discard_potion' for d in ds))
 ck(run+'大脑实际模型',all((w['row']['engine'],w['row']['model'],w['row']['effort'],w['row']['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for w in rows['brain']))
 ck(run+'Jev次数',sum(d['decider']=='jev' for d in ds)==e['jev'])
 ck(run+'Jev低信心',sum(d['decider']=='jev' and d.get('confidence',1)<.35 for d in ds)==e['low'])
 for k,val in [('best',True),('notbest',False),('missingbest',None)]:ck(run+'/'+k,sum(d.get('rollout_best_chosen') is val for d in ds if 'rollout' in d)==e[k])
 independent={ (d['floor'],d.get('sl_attempt'),d['turn']) for d in ds if d['decider']=='code' and d['label'].startswith('combat/') and 'continue' not in d['label'] and not d.get('rationale','').startswith('continuing the Jev-chosen') and d['chosen']['action']!='end_turn'}
 ck(run+'代码自主非结束轮',len(independent)==e['independent'])
 ck(run+'未见HP护栏替换',not any('hp guard' in str(d.get('rationale','')).lower() or 'hp_guard' in d for d in ds))
 for c in res['combats']:
  ck(run+f'/战窗{c["sequence"]}首帧T1',c['entry_is_turn_one'])
  matches=[w for w in ss if c['entry']['line']<=w['line']<=c['last']['line'] and (w['row']['state'].get('combat') or {}).get('action_readiness',{}).get('can_use_combat_actions')]
  ready=matches[0]['row']['state'];ck(run+f'/战窗{c["sequence"]}就绪入口一致',ready['run']['current_hp']==c['entry']['hp'] and [[q['index'],q['potion_id']] for q in ready['run']['potions'] if q['occupied']]==c['entry']['potions'])
  if c['exit'] and c['exit']['screen']=='REWARD':
   state=next(w['row']['state'] for w in ss if w['line']==c['exit']['line']);ck(run+f'/战窗{c["sequence"]}赢战人工出口复核',not any(x['is_alive'] for x in (state.get('combat') or {}).get('enemies',[])))
 last=res['combats'][-1];ck(run+'末战入口',last['entry']['hp']==e['entry'] and last['entry']['max_hp']==e['max'] and last['entry']['potions']==[])
 end=ss[-1]['row']['state'];ck(run+'真实死亡',end['turn']==e['death'] and end['run']['current_hp']==0 and end['screen']=='GAME_OVER')
 ck(run+'终态敌血',[x['current_hp'] for x in end['combat']['enemies']]==e['end_enemy'])
 before=ss[-2]['row']['state']['combat']['player'];ck(run+'死亡前HP格挡',before['current_hp']==3 and before['block']==12)
 for x in pots['drinks']:
  aa=next(w['row']['state'] for w in ss if w['line']==x['before_s']);zz=next(w['row']['state'] for w in ss if w['line']==x['after_s']);ck(run+f'/药d{x["d"]}已消费',next(v for v in aa['run']['potions'] if v['index']==x['slot'])['potion_id']==x['id'] and next(v for v in zz['run']['potions'] if v['index']==x['slot'])['potion_id']!=x['id'])
 draft=(p/f'{run}-draft.md').read_text();ck(run+'三经验一记录',sum(l.startswith('- [') for l in draft.splitlines())==4 and draft.count('- [记录]')==1)
 ck(run+'关键数字在稿',f"以3血12挡对{'火箭41' if run=='PTGQF9BEQ6G1' else '25'}攻击" in draft)
ck('PTG末次逐轮输出', [t['enemy_net_hp_loss'] for t in compact['PTGQF9BEQ6G1']['combats'][-1]['turns']]==[50,32,44,22,24,0,8,47,22,6,0,22,34,4])
ck('PTG末次逐轮净损',[t['player_net_hp_loss'] for t in compact['PTGQF9BEQ6G1']['combats'][-1]['turns']]==[0,15,0,26,6,0,0,3,13,1,5,9,0,3])
ck('A3末次逐轮输出',[t['enemy_net_hp_loss'] for t in compact['A3X30TN54LSH']['combats'][-1]['turns']]==[19,10,0,9,17,7,25,6,7,21])
ck('A3末次逐轮净损',[t['player_net_hp_loss'] for t in compact['A3X30TN54LSH']['combats'][-1]['turns']]==[0,0,0,4,16,0,16,3,0,3])
d=next(json.loads(l)['row'] for l in (p/'A3X30TN54LSH-decisions.jsonl').open() if json.loads(l)['line']==401953)
q={k:json.loads(v) for k,v in d['questions']['plan']['criteria'].items()}
ck('A3T8抢伤样本真3胜5死','3/8' in q['plan2']['rollout'] and '5/8' in q['plan2']['rollout'])
ck('A3T8保血样本0胜8死','0/8' in q['plan1']['rollout'] and '8/8' in q['plan1']['rollout'])
ck('A3T8即时价差',q['plan2']['hp_lost']==3 and q['plan1']['hp_lost']==0 and q['plan2']['damage_dealt']==6 and q['plan1']['damage_dealt']==0)
base=json.loads((p/'lessons-before.json').read_text());h=hashlib.sha256()
with (root/'notes/lessons.md').open('rb') as f:
 remaining=base['bytes']
 while remaining:
  b=f.read(min(1048576,remaining));h.update(b);remaining-=len(b)
ck('复盘旧前缀保留',h.hexdigest()==base['sha256'])
(p/'verification.json').write_text(json.dumps({'check_count':len(checks),'checks':checks,'result':'pass'},ensure_ascii=False,indent=2))
print(json.dumps({'核验数':len(checks),'结果':'通过'},ensure_ascii=False))

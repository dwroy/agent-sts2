import json,pathlib,collections,bisect,datetime
p=pathlib.Path(__file__).parent
runs=['PTGQF9BEQ6G1','A3X30TN54LSH']
S={r:[json.loads(l) for l in (p/f'{r}-states.jsonl').open()] for r in runs}
D={r:[json.loads(l) for l in (p/f'{r}-decisions.jsonl').open()] for r in runs}
R={r:json.loads((p/f'{r}-resources.json').read_text()) for r in runs}
A=json.loads((p/'compact-audit.json').read_text())
names={}
for ss in S.values():
 for w in ss:
  s=w['row']['state']
  for e in (s.get('combat') or {}).get('enemies',[]):names[e['enemy_id']]=e['name']
  for v in s['run'].get('potions',[]):
   if v.get('potion_id'):names[v['potion_id']]=v['name']
def belt(x):return '、'.join(f"槽{i}:{pid}" for i,pid in x) or '空'
def table(r):
 lines=['| 层／试 | 敌人中文名与ID（含本场后续出现者） | 进场→离场HP/max；净变化 | 进场→离场药栏 | 原始states行；UTC起止 |','|---|---|---|---|---|']
 for c in R[r]['combats']:
  e=c['entry'];z=c.get('exit') or c['last'];ss=[w for w in S[r] if e['line']<=w['line']<=z['line']]
  ids=sorted({a['enemy_id'] for w in ss for a in (w['row']['state'].get('combat') or {}).get('enemies',[])})
  a=1 if c['floor']!=33 or r!=runs[0] else c['sequence']-14
  hp=f"{e['hp']}/{e['max_hp']}→{z['hp']}/{z['max_hp']}"
  net=f"{z['hp']-e['hp']:+d}" if c.get('exit') else '退出缺帧，净变化未记录；右为读档前末见'
  times=e['ts'][11:]+'→'+z['ts'][11:]
  lines.append(f"| F{c['floor']}／{a} | {'／'.join(names[x]+' '+x for x in ids)} | {hp}；{net} | {belt(e['potions'])}→{belt(z['potions'])} | s{e['line']}→s{z['line']}；{times} |")
 return '\n'.join(lines)
def potion(r):
 lines=['  药水ID对照：'+'；'.join(names[i]+' '+i for i in sorted({pid for x in R[r]['resource_changes'] for a in ['from','to'] for slot,pid in x[a]['potions']}))+'。','  逐瓶获得／补充（不计SL恢复）：']
 acquired=0
 for x in R[r]['resource_changes']:
  if x['restart_boundary']:continue
  old=set(map(tuple,x['from']['potions']));new=set(map(tuple,x['to']['potions']))
  for slot,pid in sorted(new-old):
   acquired+=1;b=x['to'];lines.append(f"  F{b['floor']}槽{slot} {names[pid]} {pid}（s{x['from']['line']}→s{b['line']}，{b['ts']}）。")
 lines.append('  逐次饮用（另核库存消失；不是把购买、排队或弃药算成饮用）：')
 times=[x['row']['ts'] for x in S[r]];drink=[]
 for w in D[r]:
  d=w['row']
  if d.get('chosen',{}).get('action')!='use_potion':continue
  before=S[r][max(0,bisect.bisect_right(times,d['ts'])-1)];slot=d['chosen']['option_index'];v=next(v for v in before['row']['state']['run']['potions'] if v['index']==slot)
  after=next(x for x in S[r] if x['row']['ts']>d['ts'] and next((a for a in x['row']['state']['run'].get('potions',[]) if a['index']==slot),{}).get('potion_id')!=v['potion_id'])
  drink.append({'d':w['line'],'floor':d['floor'],'turn':d['turn'],'slot':slot,'id':v['potion_id'],'before_s':before['line'],'after_s':after['line'],'ts':d['ts']})
  lines.append(f"  F{d['floor']}T{d['turn']}槽{slot} {names[v['potion_id']]} {v['potion_id']}（d{w['line']}，s{before['line']}→s{after['line']}，{d['ts']}）。")
 (p/f'{r}-potion-audit.json').write_text(json.dumps({'acquired':acquired,'drinks':drink},ensure_ascii=False,indent=2))
 return '\n'.join(lines)
ptg='''## PTGQF9BEQ6G1（A10，静默猎手，第33层，死于二幕boss碾碎爪 CRUSHER／火箭 ROCKET：六试均81/81血空药进场，前五试T9／T12／T11／T14／T12判死读档；末试T14以3血12挡对火箭41攻击阵亡，完整需损29、存活至少差27血，两敌仍44/219及69/209血）

- [开场输出与长战推进要分开验收，敏捷和虚弱不能抵作已完成的击杀；打法（DeepSeek构筑职责，实际Codex；Jev出牌）] 末次F33先建立灵动步法+ FOOTWORK 的3敏捷，连续反弹+ RICOCHET、两张回响斩击+ ECHOING_SLASH、匕首雨+ DAGGER_SPRAY 等共在前三轮扣敌126血，但十四轮只扣315，428初始敌血仍余113；T6／T11实扣均0。后空翻+ BACKFLIP、偏折+ DEFLECT 和扫腿 LEG_SWEEP 兑现的是有限防御，不是持续输出已经补齐。大脑F29已说明输出诊断缺口，F33计划也明确“Damage gap is unknown, not zero”；这是一局的推进边界再证，没有受控替代构筑，不据此规定多拿攻击或移除防御必能过关。（之前学过：silent-0021，S1.exp203）
- [帝王蟹换线延长了尝试，但六次都没有杀掉一侧；打法（Jev出牌、代码SL／终局估值）] 六次末见碾碎爪 CRUSHER／火箭 ROCKET 分别为97/84、77/56、84/70、70/60、71/68、44/69血；前五次只是判死截断。末试T1的后空翻+ BACKFLIP→灵动步法+ FOOTWORK 等为SL改线，不是Jev原选整线照打；末试T14打击 STRIKE_SILENT 转向火箭使激光显示61→41，仍只有12挡和3血。换线、转向确有局部效果，不能把轮数延长或剩敌血更少写成已经取得击杀顺序的胜利证据；本局没有“一侧死后”的蟹之怒 CRAB_RAGE_POWER 窗口。（之前学过：silent-0062，S1.exp188）
- [赢战耗药与末火回血须连到强制boss入口，满血不代表准备完毕；打法（DeepSeek路线／构筑／休息职责，实际Codex；Jev用药）] F29棘刺蟾蜍 SPINY_TOAD 赢战79→79，但实际用了固化药水 FORTIFIER 和技能药水 SKILL_POTION；F30补入铁心药水 HEART_OF_IRON、易伤药水 VULNERABLE_POTION 后，F31熟睡甲虫 SLUMBERING_BEETLE 与两种盛碗虫 BOWLBUG_ROCK／BOWLBUG_SILK 赢战79→74并把两瓶饮尽。F32回血只补7至81，F33六试都空药。既不能省掉两场赢战的药水支出，也不能从终局失败反推前面留药或锻造就能赢；提案只要求联查前战实耗、补给机会与boss入口，再验证候选规则。（之前学过：silent-0020，S1.exp203）

- [记录] runs.jsonl:789确认SILENT、A10、F33败、code="current"；run-config:435另记实际源码fe6462651b593b9831581c088deface9957a404f／fe64626+dirty，脏项是知识数据及记录，未保存的开局脏数据字节不补造。已读唯一局报notes/run-1015-2215-PTGQF9BEQ6G1.md全文。835条决策d400933—d401767、856帧s413918—s414773、9条run-plans、7条SL日志均按局号抽取并核对；33条brain请求全为accepted的Codex／gpt-6.1-sol／xhigh，其中2次独立run-plan。47条codex职责动作包括计划续步，不等于47次模型调用；旧deepseek_calls=33及ds_tokens_*实际记Codex，决策时间窗deepseek-reasoning为0条，实际DeepSeek请求0。日志源、原行号和字节偏移、抽取脚本与资源JSON留在本任务目录。

  完整实盘资源链如下，日期均为2026-10-15，s为logs/states.jsonl原行号。所有战斗首帧均为T1，个别是尚未发手牌的过渡帧；随后可操作帧入口HP／药栏一致。前十四个战斗房的退出均已人工核见REWARD和敌方清场，F33末试核见GAME_OVER；工具本身没有代判胜负。净HP变化含持牌扣血等，不是敌人攻击总伤害。

{TABLE}

  关键入口追溯：F1营养牡蛎 NUTRITIOUS_OYSTER 使56/70→67/81（s413918→413919）；F2／F3／F5／F8累计67→43，F9休息43→67（s414042→414043）；F12／F14／F15再至55，F16休息55→79（s414122→414123）。F17赢后30血，F18跨幕实回40至70（s414193→414194），不是营火或SL回血；F19／F20／F23依次70→51→48→31，F25与F27各实回24，31→55→79（s414287→414288、414294→414295）。F28赢战79→79，F29赢战79→79、两药清空，F30购两药、F31赢战79→74／两药清空、F32休息74→81／药空、F33入口81／药空；相邻段没有省略赢战。F33五次SL恢复依次7→81、8→81、6→81、3→81、15→81，均原存档恢复，不能累计成回血。

  逐轮“需要”取当轮首个可操作状态仍活着的敌HP合计；“扣”取到下一轮首帧／退出的敌HP净减少，含已结算被动和毒，过量按剩血截顶。只有无新增／复活的这些关键窗口可直接作推进量；完整逐击毛伤、过量及缺失死亡中间帧未记录。玩家“损”是同窗净损血，判死读档末轮未执行敌方结算，不填成实际死亡。
  F17灵魂异鱼 SOUL_FYSH：79→30，T1—T13需要[221,193,172,144,132,128,109,90,74,64,63,42,21]，扣[28,21,28,12,4,19,19,16,10,1,21,21,21]，净损[0,4,0,0,0,0,20,9,0,2,0,14,0]。T12末持呼唤 BECKON 文本为回合末失6血，另20攻击减12挡为8，合净损14（s414184→414185），不能全算敌伤。
  F31三敌：79→74，T1—T7需要[180,159,141,120,94,81,36]，扣[21,18,21,26,13,45,36]，净损[0,0,3,2,0,0,0]；丝虫先于石虫退出，最后杀熟睡甲虫，退出中间死亡帧不全，表中净减少不冒称每击毛伤。
  F33末试：T1—T14需要[428,378,346,302,280,256,256,248,201,179,173,173,151,117]，扣[50,32,44,22,24,0,8,47,22,6,0,22,34,4]，净损[0,15,0,26,6,0,0,3,13,1,5,9,0,3]，末3为HP截顶。若仅回顾这十四轮，清掉428需平均30.57，实际315/14=22.50、尚差113；这是事后算术，不是经校准的战前必需DPR。末轮打击只打火箭4血，朝向改变后41攻击、两张脆弱下的防御各6挡，完整损29，3血只能实扣3；存活至少差27血（s414769—414773，d401763—401766）。
  F33前五试末轮依次T9／T12／T11／T14／T12，以7血17挡对29、8血19挡对29、6血22挡对28、3血20挡对66、15血19挡对35判死读档，真实敌方响应与离场HP未记录；SL原行2217—2221。末试T14才有实际死亡，原行2222。六次同局重打不当作六个独立样本。

  大脑决策：开局拿牡蛎；F6买力量药水 STRENGTH_POTION 与灵动步法 FOOTWORK；F7锻造突然一拳 SUCKER_PUNCH，F11改成无第二精英、添营火的路线并锻造匕首雨 DAGGER_SPRAY，F13锻造中和 NEUTRALIZE；F9／F16／F25／F27／F32回血。F18选择四张升级并定二幕零精英三营火，F20拿后空翻+ BACKFLIP，F23拿扫腿 LEG_SWEEP；F29拿第二张回响斩击+ ECHOING_SLASH，F31因缺施毒源跳过触媒 ACCELERANT 等。F21买明耀酊剂／固化，F24商店空买，F30买铁心／易伤。上述来自brain:14736—14768、决策与run-plans；不是从结局倒推的大脑意图。
  路线预测：F1冻结路线把F8精英入口投为81，实际55，期间F7选择锻造，不能作为同策略残差；F11换线题预测F16到火75/81，实55/81，期间F13又选择锻造，未走旧线。最后已选F16回血条件投影F17为79、实79；已选F32回血条件投影F33为81、实81（d401129／401409）。初始二幕路线对F19／F20／F23／F25／F27／F28／F31／F33依次投70／61／52／43／67／81／72／81，实70／51／48／31／55／79／79／81；是冻结路线与后来实际选择的对照，不充逐题重算预测。
  boss时钟：初题灵魂异鱼参考221血，但构筑DPR、每轮损血、可活轮数、缺口均null，明确尚无silent时钟校准，需要／估计及实打／时钟估值比未记录。整场模拟另记：F16已选回血300样本、298胜，79入口、99%、赢局掉血中位40、摘要约14轮；实F17同79入口13轮胜、净损49，轮数比13/14≈0.93、净损比49/40=1.225仅为单局描述，非校准结论。F32已选回血300样本0胜，81入口、终止轮数中位7／均7.01、平均有效伤害145.91；实末试14轮扣315、净损81，14/7=2仅是终止时长比。参考基准74血行把无胜样本写成“赢局约6回合”，该字段无胜时使用全部终止样本回合（只读live agent/src/sim/build-sim.ts:252、build-sim-facts.ts:675），本节不当作获胜时钟；更早本角色复盘已提醒此口径，不登记为新机制或把所有模拟残差归成新bug。

  Jev与代码：Jev共206次，低信心<0.35有14次；176次战斗方案选择中169次有布尔rollout_best_chosen，146次为true，即86.39%，另7次该字段缺失，不能当false。这个比例针对Jev原答，SL后执行线另核。selection_audit选中focus前缀共33次，F33含火箭9、碾碎爪13、二者2；其余包括气态炸弹 GAS_BOMB、石／蜜／丝虫和产卵虫，focus是候选中后继目标顺序的条件信息，不等于该轮先手打的目标或已实际击杀。F33两侧六试都未死。末试T13所选方案预计损0、扣34、21挡，实际66+85→44+73、HP仍3，局部相符；该线五轮24/24死亡，次轮实死，不把局部模型吻合冒作整战准确。原始code=582中277条是继续Jev已选计划，局报按jev-plan分出后code=305；按“代码独立发起非结束回合的出牌／击杀／least-loss线，同层同SL尝试同回合去重”共30轮，若连纯结束回合也计则134轮。HP护栏替换日志0次，替换直接代价0；不从未发生替换推断护栏永远没有约束候选。

{POTIONS}
  新取得11瓶、实饮11次，主动丢弃0、事件交药0；F29技能药水首动作返回pending，随后库存消失及选牌屏s414340确认消费，不按pending本身计成功。六次F33均未恢复任何药，终局药空。药水使用建议仅提交上述资源链验证，不给无证据的固定留药价格／门槛。

  机制：灵动步法+ FOOTWORK 实建3敏捷，末试T13防御+ DEFEND_SILENT 实11、偏折+ DEFLECT 实10合21，和本局已见基础8／7相比各多3；下一轮脆弱 FRAIL_POWER 下两普通防御各6，不能把3敏捷直接当3挡或沿用上一轮21挡。末试T4萎靡+ MALAISE 使火箭力量3→0并加虚弱，当前激光42→26，但本轮零挡仍净损26；两侧都还活着时，后段碾碎爪力量升到6、火箭再升到6，末次火箭同招转向61→41仍致死。减力、虚弱、朝向、敏捷和实际出挡分别记账，不能将42→26全归某一个因素，亦没有同伴死亡后的狂怒触发证据。补证已有silent-0005／0065，不添加未观察倍率或通用增长公式。

  用时／token：首末决策2026-10-15T12:49:07.607Z—14:15:10.332Z，跨度5162.725秒；run-config至结束5230.080秒，含思考／等待／SL，纯战斗用时未记录。Jev输入2346713、输出12841、合2359554，与runs.tokens相符；Jev缓存字段缺失，命中量未记录，不能把缺失加总的0当真实0。Codex33次输入6125733、输出37489、缓存2736512，输入命中44.67%；2次独立run-plan已含在总数。实付账单未记录。
  限制／去向：完整逐击毛伤／过量、前五次SL的真实离场与终局、未走路线与未选动作的受控结局、开局dirty知识的完整字节、已校准boss时钟、纯战斗耗时、Jev缓存与实付账单未记录。三条主经验为旧边界的support，不把未验证的打法反事实标repeat；账本补本局证据及机制读回，出牌／药水／SL／终局另经本任务代码提案关联strategy-proposal，未改代码、未实现、未上线、不提交。

'''
a3='''## A3X30TN54LSH（A10，静默猎手，第12层，死于精英旧日雕像 BYGONE_EFFIGY：42/70血空药进场，双灵动步法T3已建立4敏捷；T10以3血12挡对25攻击阵亡，完整需损13、存活至少差11血，结3毒后敌仍11/132血，无SL）

- [赢下前一场仍会耗尽后续精英的生存缓冲；打法（DeepSeek路线／休息职责，实际Codex；Jev出牌）] F7休息52→70后，F8蛮兽 MAWLER 赢战净损6；F11树叶史莱姆（中） LEAF_SLIME_M／飞蝇菌子 FLYCONID 又赢但64→42，T2／T3／T4分别净损4／6／12。T4两敌仍15／34血、易伤 VULNERABLE_POWER 下各显示13攻击，14挡不足覆盖26；直到T6才清场。F12因此以42血空药入旧日雕像 BYGONE_EFFIGY，不能把“下一精英前有营火”错接成这场之前回血；原路线的下个营火在F13。只确认真实支出与先后，不声称前一场改目标／买药就一定过精英。（之前学过：silent-0019，S1.exp203）
- [双步法确实建立，但4敏捷并未补齐每轮格挡与输出；打法（DeepSeek构筑职责，实际Codex；Jev出牌）] F6拿第一张灵动步法 FOOTWORK，F9又花79金币买第二张并花49买带毒刺击 POISONED_STAB，F11拿串刺 SKEWER，属于本局实际双步法防御方向，不是用单张组件冒充。F12T2／T3各打步法，敏捷0→2→4；T3两防御 DEFEND_SILENT 合18正好挡18，T5与T7各只有9挡对25，各损16；T10生存者 SURVIVOR 的12挡对25仍缺13。钢笔尖 PEN_NIB 和已有进攻牌并未使这场提前结束，不能把有两个步法与构筑组件的签名等同过关，更不能由一次失败认定第二步法一定买错。（之前学过：silent-0353，S1.exp147）
- [五轮三胜的抢伤候选仍有实付血价，不能按均值当保证；打法（Jev出牌、代码终局估值）] F12T8以6血对45血旧日雕像 BYGONE_EFFIGY，Jev以0.98信心选打击 STRIKE_SILENT→扫腿 LEG_SWEEP，预计扣6／损3，五轮8样本3胜5死；另一防御 DEFEND_SILENT→扫腿线预计扣0／损0、8样本全死。实际所选线确实6→3血、敌45→39，T9再扣7，T10扣18加已结算3毒后敌仍11血而死。这里是38%（3/8四舍五入）的短程候选没有在本次实盘兑现，不是“两线都8/8死”的饱和案例，也不是纯代码bug；未实打保血替线，不能宣称省下3血就能赢。提案保留实际样本胜／死、当轮血价及后继，再做独立回放验证。（第一次遇到）

- [记录] runs.jsonl:790确认SILENT、A10、F12败、code="current"；run-config:436实际源码f92636aec0e099e656eb18d14ef73c7dc266ff55／f92636a+dirty，开局知识／记录脏项未完整冻结，不冒称当前live等于当时所有输入。已读唯一局报notes/run-1015-2235-A3X30TN54LSH.md全文。195条决策d401771—d401965、201帧s414777—s414977、3条run-plans、0条SL记录逐局号核对；11条brain请求全为accepted的Codex／gpt-6.1-sol／xhigh，14个codex职责动作含商店计划续步。实际DeepSeek请求0，旧deepseek_calls=11／ds_tokens_*是兼容字段，决策时间窗deepseek-reasoning0条。原行／字节偏移、抽取与资源链JSON均存本任务目录。

  完整实盘资源链如下，日期均为2026-10-15，s为原始states行。六场首帧均T1，首个过渡帧与可操作帧入口资源一致；前五场已核REWARD／清场，末场核GAME_OVER。各场max HP均70，无SL恢复。净HP变化不是敌人总伤害。

{TABLE}

  关键入口追溯：F1奥术卷轴 ARCANE_SCROLL 加入谋杀 MURDER，HP仍56/70；F2零损并获一瓶爆炸安瓿 EXPLOSIVE_AMPOULE，F4饮用后赢战56→52、药空；F6赢战52→52，F7休息实回18封顶至70（s414855→414856）。F8赢战70→64，F9商店买两牌但没有买药，F10获得钢笔尖 PEN_NIB，F11赢战64→42、空药，随后无回血／药水奖励，F12精英42→0、空药；原计划F13营火尚未抵达。不能删除F11的胜战支出，或把F7回复额度21当实际回复21。
  逐轮口径与上局一致：敌“扣”为已观察净HP减少，含结毒；没有新生／复活的这两场可作推进量，但死亡缺中间帧时不称逐击毛伤。F11初需84，T1—T6需要[84,75,61,49,36,27]，扣[9,14,12,13,9,27]，玩家净损[0,4,6,12,0,0]；F6小史莱姆按树叶小→树枝小→树枝中退出，F11最后一轮按树叶中→飞蝇菌子收尾，清场回合存在敌体移除而无0HP中间帧。
  F12初需132，T1—T10需要[132,113,103,103,94,77,70,45,39,32]，扣[19,10,0,9,17,7,25,6,7,21]，玩家净损[0,0,0,4,16,0,16,3,0,3]，末3为死亡截顶。实际共扣121，尚缺11；若仅回顾这十轮，清132需均13.2、实121/10=12.1，这不是战前已校准要求。T10精确切击 PRECISE_CUT→带毒刺击 POISONED_STAB→打击 STRIKE_SILENT 实扣5+6+7=18，生存者 SURVIVOR 得12挡，结3毒后敌14→11、玩家3→0；完整承伤25−12=13，存活至少再需11血（d401960—401965、s414972—414977）。

  大脑构筑／路线／休息：开局选择免费稀有牌来源奥术卷轴 ARCANE_SCROLL，随后得到谋杀 MURDER；F2拿扫腿 LEG_SWEEP，F3接受藏宝图 SPOILS_MAP 而不花8血换未知药水，F4拿猛扑 POUNCE，F5给中和 NEUTRALIZE 附伤害附魔，F6拿灵动步法 FOOTWORK。F7选择回复18血至满，理由为在两场走廊和精英前增加缓冲；F8拿精确切击 PRECISE_CUT，F9花128金币买第二步法与带毒刺击、剩8金币，未同时买药，组合的抽牌稀释在原答中明确未测。F11拿串刺 SKEWER，计划更新为双步法方向、避免更多精英／之后优先回血；原路线F12精英仍是通向后续营火的当前既定节点。以上来自brain:14769—14779和决策，不把run-plan的“avoid”解释成已实际绕过精英。
  路线投影：F1冻结route_plan对F7营火入口47、实52；对F8入口68、实70；对F11入口65、实64；对F12精英入口62、实42，末项差20（d401773）。这是当时路线与后来实际事件／出牌／构筑的对照，不冒称同一预测条件不变；F11题仍route=keep，下一个F13营火尚未执行。F7已选回血条件的boss投影62/70、F11题boss基准投影40/70，均指F17而非F12雕像，没有boss实到值。
  boss时钟：仪式兽 CEREMONIAL_BEAST 参考262血，构筑每轮估计、损血率、可活轮数、差额均null，注明尚无silent时钟校准，所需／估计及实打／时钟估值比例未记录。整场模拟另记：F11串刺候选1000样本、0胜、有效DPR14.91，配对增1.50±0.08；原答+14.1 DPR是模型诊断，不是F12雕像的需求。候选终止轮均8.845且胜样本数0，不能把摘要“约9回合”当成功时钟。本局未到仪式兽，模拟获胜率的实盘校准与实打／估值比未记录。

  Jev与代码：Jev32次、低信心<0.35为2次（F2弃牌0.08、F8弃藏宝图0.22）；28次战斗方案选择的rollout_best_chosen全为true，28/28=100%，这不是实盘胜率。选中focus前缀4次：F6树叶小、树枝小各1，F11飞蝇菌子、树叶中各1；标签描述后继优先，F11T5实际先扫腿压菌子、再带毒刺击压史莱姆，不可把focus文字当成已清掉目标。F12只有一个敌人，无多敌focus。F12T8选中线的即时扣6／损3与实际相符，五轮3/8实胜仍未兑现于本次；T9代码零损7伤线实际相符，T10least-loss显示-10是预计剩余HP，等于3−13，不误记成完整伤害10。原始code=149中51条续行是Jev已选计划，局报分出jev-plan后code=98；按代码独立发起非结束回合的出牌／击杀／least-loss线去重共12轮，若连纯结束回合也计37轮。HP护栏替换日志0次、直接替换代价0，不把T8少挡归成护栏干预。

{POTIONS}
  全局新得1瓶、实饮1次、主动丢弃0、事件交药0；F3拒绝付血取药不算获得或弃药，F9未买药也不算消耗。F12入口及终局均空药。没有本局留药／另购药的受控结局，不据此另定饮用或持有门槛。

  机制：F12T1雕像SLEEP_MOVE无攻击，T2为WAKE_MOVE、仍无攻击，T3实有STRENGTH_POWER10；同招无虚弱25、已有虚弱时18。两张灵动步法 FOOTWORK 在T2／T3把敏捷0→2→4，T3两防御各9合18，较本局基础5+5多8挡，恰好覆盖18；T5与T7只有一张防御各9仍漏16。T8扫腿以4敏捷给15挡，虚弱把当前攻击25→18，仍实漏3；T10生存者8+4=12，对25需损13。T2所获13挡没有跨入T3，不能把敏捷、旧挡或虚弱持续时间混为常量。T10带毒刺击给3毒，实际结算3后剩2毒，未结算的2不当已打伤害。钢笔尖确已持有，但其单独胜因未隔离；不由这些状态补写未观察的缓慢 SLOW_POWER 公式。补证已有silent-0005／0307，没有新增机制规则。

  用时／token：首末决策2026-10-15T14:22:59.921Z—14:35:35.197Z，跨度755.276秒；run-config至结束844.048秒，含模型／计算等待，纯战斗用时未记录。Jev输入179273、输出1552、合180825，与runs.tokens一致；Jev缓存字段缺失，命中量未记录。Codex11次输入1902673、输出13295、缓存684416，输入命中35.97%；无独立run-plan额外计费项。实付账单未记录。
  新旧／限制／去向：前两条为旧边界support；第三条的6血／45敌血、当轮3血换6伤及五轮3/8胜的具体比较，账本和本角色更早复盘未检出，新增fight观察、prior=unknown。检索已包含BYGONE_EFFIGY／旧日雕像／FOOTWORK／灵动步法及短程相关词；已有雕像增力／虚弱机制与不同敌人全败饱和观察不冒作同一可比先验。完整逐击毛伤／过量、未选保血线／购物／路线的受控后继、开局dirty知识完整字节、已校准boss时钟／boss实际交手、纯战斗时间、Jev缓存和实付账单未记录。未定位新纯bug；出牌／终局证据及账本经本任务提案关联独立strategy-proposal，证据不足保留现行行为，未改代码、未实现、未上线、不提交。

'''
for r,body in [(runs[0],ptg),(runs[1],a3)]:
 body=body.replace('{TABLE}',table(r)).replace('{POTIONS}',potion(r))
 (p/f'{r}-draft.md').write_text(body)
 print(r,len(body.encode()),'bytes')

import json,pathlib,collections,datetime,hashlib
p=pathlib.Path(__file__).parent
out={}
for r in ['PTGQF9BEQ6G1','A3X30TN54LSH']:
 states=[json.loads(l) for l in (p/f'{r}-states.jsonl').open()]; ds=[json.loads(l) for l in (p/f'{r}-decisions.jsonl').open()]
 res=json.loads((p/f'{r}-resources.json').read_text()); result={'combats':[],'potions':[]}
 for c in res['combats']:
  lo=c['entry']['line'];hi=(c.get('exit') or c['last'])['line'];ss=[w for w in states if lo<=w['line']<=hi]
  ts=collections.defaultdict(list)
  for w in ss:
   t=w['row']['state'].get('turn')
   if t is not None:ts[t].append(w)
  turns=[]
  for t,rows in ts.items():
   ready=[w for w in rows if (w['row']['state'].get('combat') or {}).get('action_readiness',{}).get('can_use_combat_actions')]
   a=(ready or rows)[0];z=rows[-1]
   def eh(w):
    es=(w['row']['state'].get('combat') or {}).get('enemies')
    return sum(e['current_hp'] for e in es if e['is_alive']) if es is not None else None
   nxt=ts.get(t+1,[])
   nextready=[w for w in nxt if (w['row']['state'].get('combat') or {}).get('action_readiness',{}).get('can_use_combat_actions')]
   end=(nextready or nxt)[0] if nxt else z
   q={'turn':t,'start_s':a['line'],'end_s':end['line'],'hp_start':a['row']['state']['run']['current_hp'],'hp_after':end['row']['state']['run']['current_hp'],'enemy_start':eh(a),'enemy_after':eh(end)}
   q['enemy_net_hp_loss']=q['enemy_start']-q['enemy_after'] if q['enemy_start'] is not None and q['enemy_after'] is not None else None
   q['player_net_hp_loss']=q['hp_start']-q['hp_after']
   turns.append(q)
  result['combats'].append({'sequence':c['sequence'],'floor':c['floor'],'entry':c['entry'],'exit':c['exit'],'last':c['last'],'turns':turns})
  if (r=='PTGQF9BEQ6G1' and c['floor'] in [17,31,33]) or (r=='A3X30TN54LSH' and c['floor'] in [11,12]):
   print(r,'F',c['floor'],'seq',c['sequence'],'need',[t['enemy_start'] for t in turns],'enemy_net',[t['enemy_net_hp_loss'] for t in turns],'hp_loss',[t['player_net_hp_loss'] for t in turns])
 for w in ds:
  d=w['row']
  if d.get('chosen',{}).get('action')=='use_potion':
   obs=next((s for s in states if s['row']['ts']==d.get('observed_ts')),None)
   slot=d['chosen']['option_index'];pot=next((x for x in (obs['row']['state']['run'].get('potions',[]) if obs else []) if x['index']==slot),{})
   row={'d':w['line'],'ts':d['ts'],'floor':d['floor'],'turn':d['turn'],'slot':slot,'id':pot.get('potion_id'),'name':pot.get('name'),'s':obs['line'] if obs else None,'result':d.get('result')};result['potions'].append(row)
 print(r,'DRINKS',result['potions'])
 out[r]=result
(p/'compact-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))

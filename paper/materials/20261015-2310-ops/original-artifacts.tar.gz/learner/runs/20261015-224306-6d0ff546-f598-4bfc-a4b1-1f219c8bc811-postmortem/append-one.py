import sys,pathlib,json,subprocess,hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2');p=pathlib.Path(__file__).parent
run=sys.argv[1];assert run in ['PTGQF9BEQ6G1','A3X30TN54LSH']
lessons=root/'notes/lessons.md';draft=(p/f'{run}-draft.md').read_text();assert '\nEOF\n' not in draft
assert not (p/f'{run}-append-receipt.json').exists()
with lessons.open() as f:
 assert not any(l.startswith('## '+run) for l in f),'already appended'
before=lessons.stat().st_size
stamp=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %z'],text=True).strip();print(stamp,flush=True)
script="cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+draft+"EOF\n"
(p/f'{run}-append-command.sh').write_text(script)
subprocess.run(['bash'],input=script,text=True,check=True,cwd=root)
with lessons.open('rb') as f:
 f.seek(before);appended=f.read()
assert appended==draft.encode(),'parallel tail needs readback; never rewrite'
receipt={'run':run,'time_from_date':stamp,'offset':before,'bytes':len(appended),'sha256':hashlib.sha256(appended).hexdigest(),'cat_heredoc_invocations':1}
(p/f'{run}-append-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print(json.dumps(receipt,ensure_ascii=False))

import json,pathlib,collections
p=pathlib.Path(__file__).parent
for r in ['PTGQF9BEQ6G1','A3X30TN54LSH']:
 rows=[json.loads(l) for l in (p/f'{r}-decisions.jsonl').open()]
 with (p/f'{r}-decisions-view.txt').open('w') as f:
  for w in rows:
   d=w['row']; fp=json.loads(d.get('fingerprint','{}'))
   f.write(json.dumps({'line':w['line'],'ts':d['ts'],'f':d['floor'],'t':d.get('turn'),'sl':d.get('sl_attempt'),'hp':fp.get('hp'),'enemies':fp.get('enemies'),'label':d['label'],'by':d['decider'],'chosen':d.get('chosen'),'rationale':d.get('rationale'),'confidence':d.get('confidence'),'journal':d.get('journal'),'guard':d.get('hp_guard'),'result':d.get('result'),'rollout':d.get('rollout'),'sim':d.get('sim'),'deepseek':{k:v for k,v in (d.get('deepseek') or {}).items() if k in ['answer','reason','choice','raw','plan','route']}},ensure_ascii=False)+'\n')
 with (p/f'{r}-plans-view.txt').open('w') as f:
  for l in (p/f'{r}-run-plans.jsonl').open():
   w=json.loads(l);d=w['row'];f.write(json.dumps({'line':w['line'],'ts':d['ts'],'f':d['floor'],'plan':d['plan']},ensure_ascii=False)+'\n')
 with (p/f'{r}-resources-view.txt').open('w') as f:
  d=json.loads((p/f'{r}-resources.json').read_text())
  for c in d['combats']:
   f.write(json.dumps({k:c[k] for k in ['sequence','floor','enemies','entry','last','exit','entry_is_turn_one','end','observed_net_hp_loss']},ensure_ascii=False)+'\n')
  f.write('SL '+json.dumps(d['sl_events'],ensure_ascii=False)+'\n')
  f.write('CHANGES\n')
  for x in d['resource_changes']:f.write(json.dumps(x,ensure_ascii=False)+'\n')
 print(r,'first combat keys',next(d['row'].keys() for d in rows if d['row'].get('label')=='combat/plan-choice'))
 print('brain keys',json.loads((p/f'{r}-brain.jsonl').open().readline())['row'].keys())

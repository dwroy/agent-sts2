import json,pathlib,collections,datetime
p=pathlib.Path(__file__).parent
for r in ['PTGQF9BEQ6G1','A3X30TN54LSH']:
 ws=[json.loads(l) for l in (p/f'{r}-decisions.jsonl').open()];ds=[w['row'] for w in ws]
 def walk(o,path=''):
  if isinstance(o,dict):
   for k,v in o.items():
    if 'guard' in k.lower():yield path+'.'+k,v
    if k not in ['questions','fingerprint','payload']:yield from walk(v,path+'.'+k)
  elif isinstance(o,list):
   for i,v in enumerate(o):yield from walk(v,path+f'[{i}]')
 print('\nRUN',r,'actual deciders',collections.Counter(d['decider'] for d in ds))
 print('JEV low',[(w['line'],w['row']['floor'],w['row'].get('sl_attempt'),w['row']['turn'],w['row']['confidence']) for w in ws if w['row']['decider']=='jev' and w['row'].get('confidence',1)<.35])
 print('rollouts',collections.Counter((bool(d.get('rollout',{}).get('available')),d.get('rollout_best_chosen')) for d in ds if 'rollout' in d))
 for w in ws:
  guards=list(walk(w['row']))
  if guards:print('guard',w['line'],guards)
 for criterion in ['initial-nonend','all-nonend','all-incl-end']:
  selected=[d for d in ds if d['decider']=='code' and d['label'].startswith('combat/') and not d.get('rationale','').startswith('continuing the Jev-chosen') and (criterion=='all-incl-end' or d['chosen']['action']!='end_turn') and (criterion!='initial-nonend' or 'continue' not in d['label'])]
  print('code',criterion,len(selected),len({(d['floor'],d.get('sl_attempt'),d['turn']) for d in selected}))
 print('JEV usage', {k:sum(d.get('usage',{}).get(k,0) or 0 for d in ds) for k in ['input_tokens','output_tokens','cache_hit_tokens']})
 bs=[json.loads(l)['row'] for l in (p/f'{r}-brain.jsonl').open()]
 print('BRAIN',len(bs),collections.Counter((b.get('engine'),b.get('model'),b.get('effort'),b.get('accepted')) for b in bs))
 print('brain usage', {k:sum(b.get('usage',{}).get(k,0) or 0 for b in bs) for k in ['input_tokens','output_tokens','cache_hit_tokens','cached_input_tokens']},'usage sample',bs[-1]['usage'])
 print('config',json.loads((p/f'{r}-run-config.jsonl').open().readline())['row']['code'])
 print('duration decisions',(datetime.datetime.fromisoformat(ds[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(ds[0]['ts'].replace('Z','+00:00'))).total_seconds())
 print('end brain',bs[-1].get('answer'))

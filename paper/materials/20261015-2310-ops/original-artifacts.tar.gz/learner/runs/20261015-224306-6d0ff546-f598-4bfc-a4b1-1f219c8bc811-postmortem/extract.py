import json,pathlib,hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261015-224306-6d0ff546-f598-4bfc-a4b1-1f219c8bc811-postmortem'
runs=['PTGQF9BEQ6G1','A3X30TN54LSH']
meta={}
p=root/'notes/lessons.md'
h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
(out/'lessons-before.json').write_text(json.dumps({'bytes':p.stat().st_size,'sha256':h.hexdigest()}))
for name in ['runs','decisions','run-plans','sl-attempts','run-config','brain']:
 p=root/f'logs/{name}.jsonl'
 handles={r:(out/f'{r}-{name}.jsonl').open('w') for r in runs}
 counts={r:0 for r in runs}
 offset=0
 with p.open('rb') as f:
  for n,line in enumerate(f,1):
   for r in runs:
    if r.encode() not in line:continue
    try:row=json.loads(line)
    except ValueError:continue
    if row.get('run_id',row.get('run'))!=r:continue
    handles[r].write(json.dumps({'line':n,'offset':offset,'row':row},ensure_ascii=False)+'\n')
    counts[r]+=1
   offset+=len(line)
 for f in handles.values():f.close()
 meta[name]=counts
 print(name,counts,flush=True)
windows={}
for r in runs:
 ds=[json.loads(l)['row'] for l in (out/f'{r}-decisions.jsonl').open()]
 windows[r]=[min(d['ts'] for d in ds),max(d['ts'] for d in ds)]
p=root/'logs/deepseek-reasoning.jsonl'
counts={r:0 for r in runs}
handles={r:(out/f'{r}-deepseek-reasoning.jsonl').open('w') for r in runs}
with p.open('rb') as f:
 offset=0
 for n,line in enumerate(f,1):
  try:row=json.loads(line)
  except ValueError:offset+=len(line);continue
  ts=row.get('ts',row.get('timestamp',''))
  for r,(a,b) in windows.items():
   if a<=ts<=b:
    handles[r].write(json.dumps({'line':n,'offset':offset,'row':row},ensure_ascii=False)+'\n');counts[r]+=1
  offset+=len(line)
for f in handles.values():f.close()
meta['deepseek-reasoning']=counts
meta['windows']=windows
(out/'extraction-summary.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(meta,flush=True)

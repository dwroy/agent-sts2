import pathlib,json
root=pathlib.Path('/home/dw/Projects/agent-sts2');p=pathlib.Path(__file__).parent
runs=['PTGQF9BEQ6G1','A3X30TN54LSH'];handles={r:(p/f'{r}-states.jsonl').open('wb') for r in runs};counts={r:0 for r in runs}
with (root/'logs/states.jsonl').open('rb') as f:
 offset=0
 for n,line in enumerate(f,1):
  for r in runs:
   if r.encode() not in line:continue
   try:d=json.loads(line)
   except ValueError:continue
   if (d.get('state') or {}).get('run_id',d.get('run_id'))!=r:continue
   handles[r].write(json.dumps({'line':n,'offset':offset,'row':d},ensure_ascii=False).encode()+b'\n');counts[r]+=1
  offset+=len(line)
for f in handles.values():f.close()
print(counts)

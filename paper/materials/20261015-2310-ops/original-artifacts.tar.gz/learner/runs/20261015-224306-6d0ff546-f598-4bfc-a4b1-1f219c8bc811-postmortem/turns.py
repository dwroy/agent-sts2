import json,pathlib,collections
p=pathlib.Path(__file__).parent
for r in ['PTGQF9BEQ6G1','A3X30TN54LSH']:
 states=[json.loads(l) for l in (p/f'{r}-states.jsonl').open()]
 ds=[json.loads(l) for l in (p/f'{r}-decisions.jsonl').open()]
 res=json.loads((p/f'{r}-resources.json').read_text())
 def powers(o):return {x['power_id']:x['amount'] for x in o.get('powers',[])}
 def brief(w):
  s=w['row']['state'];c=s.get('combat') or {};pl=c.get('player') or {}
  return {'s':w['line'],'t':s.get('turn'),'hp':s['run']['current_hp'],'block':pl.get('block'),'powers':powers(pl),'e':[{'id':x['enemy_id'],'hp':x['current_hp'],'block':x.get('block'),'intent':x.get('move_id'),'atk':sum(i.get('total_damage') or 0 for i in x.get('intents',[])),'p':powers(x)} for x in c.get('enemies',[])],'hand':[x.get('card_id') for x in c.get('hand',[])]}
 with (p/f'{r}-turns.txt').open('w') as f:
  for comb in res['combats']:
   f.write(f"F{comb['floor']} sequence {comb['sequence']}\n")
   lo=comb['entry']['line'];hi=(comb.get('exit') or comb['last'])['line']
   ss=[w for w in states if lo<=w['line']<=hi]
   for t in sorted({w['row']['state']['turn'] for w in ss if w['row']['state'].get('turn') is not None}):
    ts=[w for w in ss if w['row']['state']['turn']==t]
    ready=[w for w in ts if ((w['row']['state'].get('combat') or {}).get('action_readiness') or {}).get('can_use_combat_actions')]
    start=ready[0] if ready else ts[0]
    end=ts[-1]
    dd=[w for w in ds if w['row'].get('turn')==t and start['row']['ts']<=w['row']['ts']<=end['row']['ts']]
    td=next((a for a in comb['enemy_hp_audit']['turns'] if a['turn']==t),{})
    f.write(json.dumps({'start':brief(start),'end':brief(end),'visible_loss_lb':td.get('visible_enemy_hp_loss_lower_bound'),'enemy_added':td.get('observed_hp_added'),'gaps':td.get('gaps'),'actions':[{'d':w['line'],'by':w['row']['decider'],'a':w['row']['chosen'],'why':w['row'].get('rationale')} for w in dd]},ensure_ascii=False)+'\n')
 print(r,'written')

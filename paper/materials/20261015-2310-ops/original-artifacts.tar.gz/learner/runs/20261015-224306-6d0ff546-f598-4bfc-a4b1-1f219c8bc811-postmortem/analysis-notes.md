# 本任务材料边界与过程保留

本任务没有代码修改、提交、推送、play、联网或下级agent。只追加lessons、经专用CLI追加账本／提案队列，并在指定scratch存原始局号抽取、原行号／偏移、初稿、核验、CLI回执与报告。源码对照的HEAD和相关文件SHA、二进制diff保存在source-reference.json／diff，不复制整个仓库。

第一次统计探针把字符串jev_context当作对象，调用.keys()得到AttributeError后终止；原始工具回执保留在调用方会话日志。本目录stats.py／stats.txt为后续明确字段类型和引擎口径的读回。这个探针失败是分析脚本的类型假设错误，不是产品bug。

compact-audit.py的第一版按observed_ts精确等值寻找饮药前帧，未匹配时potions的id/name为null；原compact-audit.txt／json保持。最终逐瓶证据改用决策之前最近的states帧并核库存消失，结果在各局potion-audit.json。初稿中的null不能冒作药水ID未记录。实际F29技能药水的pending返回，后续选牌与库存消失共同确认消费。

新条目silent-0486记录的是旧日雕像特定低血候选的观测，未断言排序错误、因果收益或通用规则，prior=unknown。已有机制／边界只加support；本任务没有repeat，不将失败本身计成复犯。提案当前仅登记pending，无implemented_commit、未声称shipped；待独立strategy-proposal处理具体完整后继／缺证。

追加后再次读回发现PTG首条把持有的RICOCHET列入前三轮输出来源，已仅追加勘误；原主节和初稿均保留。实际T3它仍在手中、未施放，原126／315与终局数字不变。勘误正文／字节偏移／SHA在PTGQF9BEQ6G1-erratum.md与erratum-receipt.json。账本与代码提案没有该错误归因，无须覆盖旧条目。

2293项验证为原始JSON字节偏移一致、资源／统计与材料关系核验，不是生产tsc/vitest。仅改记录，未运行生产代码测试。全局ledger.py check结果0。旧账本8项claim、首证、prior、status和version与任务前快照核同，CLI只加本局证据／去向／说明；新fight保持observed。

完整逐击毛伤／过量、未选动作或路线的受控后继、运行时dirty知识完整字节、已校准boss时钟、纯战斗时间、Jev缓存和实付账单没有证据；PTG前五次SL未执行的敌方响应／真实离场也不补填。A3未交手boss，不从boss模拟推断雕像的实盘时钟。

cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'
### 勘误（2026-10-15 23:08:39 +0800，learner）

PTGQF9BEQ6G1第一条经验的前三轮施牌归属更正：末试T1实际攻击为回响斩击+ ECHOING_SLASH、突然一拳 SUCKER_PUNCH；T2为打击 STRIKE_SILENT、回响斩击+ ECHOING_SLASH；T3为中和+ NEUTRALIZE、突然一拳+ SUCKER_PUNCH、打击 STRIKE_SILENT、匕首雨+ DAGGER_SPRAY。连续反弹+ RICOCHET 虽在牌组、T3也已到手，但留在手中而未施放，不能列入这三轮输出来源（s414703—414720、d401697—401713）。前三轮实扣50+32+44=126、十四轮315、末敌113及死亡数字均不变。

EOF

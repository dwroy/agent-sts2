from pathlib import Path
import hashlib, importlib.util, json, re, subprocess, sys, tarfile

root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2310'; pub=r/'paper/materials/20261015-2310-ops'; pub.mkdir(exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
bid='20261015-224302'; s=r/'learner/runs/20261015-224306-6d0ff546-f598-4bfc-a4b1-1f219c8bc811-postmortem'; report=load(s/'result.json'); runs=report['appended']; assert runs==['PTGQF9BEQ6G1','A3X30TN54LSH'] and report['bugs']==report['skipped']==[]
b=load(r/'ops/codex-ops/learn.json')['batches'][bid]; assert b['state']=='done' and b['rc']==0 and b['done']==runs and not b['missing'] and not b['proposal_audit_errors']
exec((p/'readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text())
refs=[]; counts={}; brains={}; config={}; runrows={}
for run,floor,answers in [('PTGQF9BEQ6G1',33,33),('A3X30TN54LSH',12,11)]:
 counts[run]={}; brains[run]=[]
 for stream in ['runs','states','decisions','sl-attempts','run-config','run-plans','brain']:
  count=0
  with (r/'logs'/(stream+'.jsonl')).open('rb') as original,(s/(run+'-'+stream+'.jsonl')).open() as frozen:
   for line in frozen:
    e=json.loads(line); original.seek(e['offset']); raw=original.readline(); row=json.loads(raw); assert row==e['row']
    fp=row.get('fingerprint') or {}; fp=json.loads(fp) if isinstance(fp,str) else fp; state=row.get('state') or {}; sr=state.get('run') or {}
    ids=[x for x in [row.get('run_id'),row.get('run') if isinstance(row.get('run'),str) else None,state.get('run_id'),sr.get('run_id') if isinstance(sr,dict) else None,fp.get('run') if isinstance(fp,dict) else None] if x is not None]; assert ids and all(x==run for x in ids)
    if stream=='states': assert state['run']['character_id']=='SILENT' and state['run']['ascension']==10
    if stream=='runs': assert row['character']=='SILENT' and row['ascension']==10 and row['victory'] is False and row['floor']==floor; runrows[run]=row
    if stream=='brain': assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True; brains[run].append(row)
    if stream=='run-config': assert run not in config; config[run]=row
    refs.append(dict(run=run,stream=stream,line=e['line'],offset=e['offset'],bytes=len(raw),sha256=sha(raw))); count+=1
  counts[run][stream]=count
 assert counts[run]['runs']==counts[run]['run-config']==1 and len(brains[run])==answers
assert counts[runs[0]]['decisions']==835 and counts[runs[1]]['decisions']==195
verification=load(s/'verification.json'); assert verification['result']=='pass' and verification['check_count']==len(verification['checks'])==2293
assert load(s/'closure-verification.json')['result']=='pass' and (s/'ledger-check.exit').read_text().strip()=='0'
source=load(s/'source-reference.json')
for path,h in source['files'].items(): assert sha(git('show',source['head']+':'+path))==h
lessons=r/'notes/lessons.md'; previous=load(s/'lessons-before.json'); raw=lessons.read_bytes(); assert sha(raw[:previous['bytes']])==previous['sha256']; owned=[]; lessonrefs=[]
for run in runs:
 receipt=load(s/(run+'-append-receipt.json')); start=receipt['offset']; piece=raw[start:start+receipt['bytes']]; assert receipt['cat_heredoc_invocations']==1 and sha(piece)==receipt['sha256'] and piece==(s/(run+'-draft.md')).read_bytes(); owned.append(piece); lessonrefs.append(receipt)
erratum=load(s/'erratum-receipt.json'); piece=raw[erratum['offset']:erratum['offset']+erratum['bytes']]; assert sha(piece)==erratum['sha256'] and piece==(s/'PTGQF9BEQ6G1-erratum.md').read_bytes(); owned.append(piece); lessonrefs.append(erratum); assert sum(map(len,owned))==29684; (p/'owned-lessons.md').write_bytes(b''.join(owned))
ledgerrows=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('by')=='learner:postmortem' and (any(x.get('run') in runs for x in row.get('evidence',[])) or str(s) in json.dumps(row,ensure_ascii=False)):
  assert row['id'] in report['ledger']['added']+report['ledger']['updated']
  if row['op']=='update': assert set(row)<={'op','id','ts','by','evidence','where','note'}
  assert all(x['run'] in runs and x['role']=='support' for x in row.get('evidence',[])); ledgerrows.append(raw)
assert len(ledgerrows)==20 and sum(json.loads(raw)['op']=='add' for raw in ledgerrows)==1 and sum('evidence' in json.loads(raw) for raw in ledgerrows)==10
assert json.loads(next(raw for raw in ledgerrows if json.loads(raw)['op']=='add'))['id']=='silent-0486'; (p/'owned-ledger.jsonl').write_bytes(b''.join(ledgerrows))
spec=importlib.util.spec_from_file_location('original_code_proposals',r/'learner/code_proposals.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); queue=mod.fold(r/'paper/materials/learning/code-proposals.jsonl'); proposals=[]
for ident,run in zip(report['code_proposals'],runs):
 q=queue[ident]; assert q['character']=='silent' and q['runs']==[run] and q['source_task']=='postmortem' and q['target_task']=='strategy-proposal'; f=Path(q['proposal']); assert f.is_relative_to(r) and sha(f.read_bytes())==q['proposal_sha256']; proposals.append({k:q.get(k) for k in ['id','state','proposal','proposal_sha256','ledger','implemented_commit']})
readback=dict(batch=bid,original_report=report,original_done=b['done'],native=native,original_rows_checked=len(refs),stream_counts=counts,actual_accepted_codex={run:len(brains[run]) for run in runs},original_run_rows=runrows,actual_run_config=config,source_reference=source,source_reference_does_not_prove_native_dirty_tree_equivalence=True,original_lesson_bytes=29684,original_lesson_receipts=lessonrefs,lessons_prefix_preserved=True,original_ledger_rows=20,evidence_bearing_rows=10,trace_only_proposal_links=10,original_proposals=proposals,learner_original_verification_checks=2293,original_erratum_preserved='PTG first-three-turn RICOCHET possession was not play; original postmortem retained plus appended erratum. Damage totals unchanged.',limits='Gross/overkill damage, first five PTG SL exit frames, controlled alternative outcomes, original consumed dirty knowledge bytes, calibrated clock, pure combat time, Jev cache and invoice remain unknown. A3 never fought the Boss. Original SL-censored statuses do not certify exits or independent games. New0486 is a bounded fight observation, not rule implementation; no new pure bug or game-rule adjustment.')
write(pub/'postmortem-readback.json',readback); write(pub/'postmortem-original-references.json',refs)
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<300000 and not f.name.startswith('ledger-search')]+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); manifest.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',manifest); print(json.dumps(dict(rows=len(refs),counts=counts,ledger_rows=20,lesson_bytes=29684,new_bug=False)))

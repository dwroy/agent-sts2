from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, tarfile

r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261015-2310'; pub=r/'paper/materials/20261015-2310-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1
log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut
runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected={x['run_id']:x for x in runs if x['run_id'] in ['PTGQF9BEQ6G1','A3X30TN54LSH']}; assert len(selected)==2
for run,n,floor,answers in [('PTGQF9BEQ6G1','835','33',33),('A3X30TN54LSH','195','12',11)]:
 row=selected[run]; assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max=floor,n_decisions=n,has_postmortem='1',performance_included='1').items())
 brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':answers} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],runs={run:{k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']} for run,row in selected.items()},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r)))
write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==20; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==20
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); oldfold=fold(old); newfold=fold(old+added); assert set(newfold)==set(oldfold)|{'silent-0486'}
for ident in oldfold:
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert oldfold[ident].get(key)==newfold[ident].get(key),(ident,key)
 previous=oldfold[ident].get('evidence',[]); later=newfold[ident].get('evidence',[]); assert later[:len(previous)]==previous
 assert all(x['run'] in selected and x['role']=='support' for x in later[len(previous):])
new=newfold['silent-0486']; assert new['kind']=='fight' and new['status']=='observed' and new['prior']=='unknown' and new['first_run']=='A3X30TN54LSH' and new['asc']==10
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==29684 and all(('## '+run).encode() not in oldlesson for run in selected)
physical=(r/'notes/lessons.md').read_bytes(); assert all(piece in physical for piece in [(p/'owned-lessons.md').read_bytes()]); prior=load(r/'learner/runs/20261015-224306-6d0ff546-f598-4bfc-a4b1-1f219c8bc811-postmortem/lessons-before.json'); assert sha(physical[:prior['bytes']])==prior['sha256']
readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged_20_rows']=True; readback['ops_initial_native_guard_failure']='Historical helper assumed postmortem startup batch=None. Actual startup has exact registered20261015-224302 with unchanged lease/input/native context; local read-only guard corrected and original failing helper/log retained. No learner rerun.'; readback['physical_prior_notes_vs_HEAD']='Pre-existing whitespace differences remain physical/uncommitted; private staged file retains exact HEAD prefix and only the two owned sections plus erratum.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
line=f'\n- {at} 运维codex：2310原224302两局PTGQF9BEQ6G1/A3X30TN54LSH复盘done0闭环，无新增纯bug/无需补队列或派修；原2154行含两runs及六流offset逐行JSON/身份核、SHA冻结，两局均Silent A10/F33及F12负局、835/195决策，33/11原accepted均Codex Sol6.1/xhigh。两节正式复盘29083字节加601字节PTG施牌勘误逐原append收据/一次cat/旧物理前缀核，前三轮RICOCHET仅持有未施放，126/315/末敌113等数字不变，原文加更正留史；不据接管后帧或净差补游戏机制。新silent-0486为A3 F12T8特定低血抢伤/3of8模拟与实际负后继的fight观察、observed/prior unknown，非新规则/独立胜率；20所属CLI一add+9证据update+10提案追溯，旧claim/首证/prior/status/version/evidence前缀保护，原d1e2ba39/5cf543e6按策略链pending不冒实现/shipped。PTG六试前五离场截断、dirty知识、逐击毛伤/过量、受控替线、时钟/纯战斗时间/缓存/账单未知保持，A3未交Boss不造实战。ops初核旧native helper将postmortem批号误设None，实际注册224302/lease/input精确核后仅本次只读guard更正，原失败保留，不改producer/权限/重派模型。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0，cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策，五一致性/keyscan CLEAN、两局has_postmortem1/成功Codex入表；成本独立cut估计非账单。仅本人两节与勘误/20CLI/生成表和证据提交、保物理并行记录/旧空白差，不新源码/版本/测试/重启/改账号home模型额度队列prompt或关闭宽父。证据paper/materials/20261015-2310-ops/。\n'
note=f'\n- {at} [ops 学习闭环] PTG/A3两局复盘已核，无新增纯bug；保留PTG原文并追加施牌归属勘误，silent-0486只作限定fight观察。20所属CLI及两原策略提案来源核实，保持原规则与未知边界；论文一次刷新exit0、{len(runs)}局、五一致性/keyscan通过，两局has_postmortem1。回执paper/materials/20261015-2310-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in list(p.glob('*.py'))+list(p.glob('*failure.log')):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortems=list(selected),original_rows_checked=2154,original_lesson_bytes=29684,erratum_bytes=601,new_bug=False,new_bounded_fight_observation='silent-0486',owned_ledger_rows=20,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=20,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

from pathlib import Path
import json,hashlib,subprocess,tarfile,re,os,importlib.util
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-1955';pub=r/'paper/materials/20261015-1955-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
bid='20261015-194301-strategy-proposal';b=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert report['fixes']==report['implementation_domains']==report['skipped']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
final=load(s/'final-verification.json');assert final['head']==report['base'] and final['git_status']=='' and final['tracked_diff_bytes']==0 and final['ledger_updates']==16 and final['protected_fields_unchanged']
manifest=load(s/'artifacts-manifest.json')
for x in manifest['files']:
 raw=(s/x['path']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],x['path']
evidence=load(s/'evidence-audit.json');assert evidence['verified_total']==8444 and sum(x['verified_rows'] for x in evidence['verified_streams'].values())==8444
assert evidence['all_material_checks_pass'] and len(evidence['material_checks'])==56 and all(x['pass'] and x['actual']==x['expected'] for x in evidence['material_checks'])
for x in load(s/'evidence/evidence-manifest.json'):
 z=evidence['verified_streams'][x['stream']];assert x['output_sha256']==z['output_sha256'] and x['source_size']==z['source_size'] and sum(x['counts'].values())==z['verified_rows']
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['paths'])==13
equal=0
for x in source['paths']:
 a=git('show',report['base']+':'+x['path']);z=git('show',source['live']+':'+x['path']);assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256']
 if a==z:equal+=1
 else:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
 assert x['commit_is_live_ancestor'];git('merge-base','--is-ancestor',x['live_path_commit'],source['live'])
assert equal==11
for x in source['existing_sources']:
 assert x['is_live_ancestor'];git('merge-base','--is-ancestor',x['commit'],source['live'])
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs):owned.append(raw)
assert len(inputs)==len(owned)==16 and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
readback=load(s/'ledger-readback.json');assert readback['count']==16 and readback['all_links_present'] and readback['protected_fields_unchanged'] and readback['protected_changes']==[]
for x in readback['entries'].values():
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as f:f.seek(x['offset']);raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and raw in owned
assert set((s/'ledger-update.log').read_text().split())=={json.loads(x)['id'] for x in owned}
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 for k in ['claim','first_run','asc','prior','prior_note','prior_runs','evidence','status','version','shipped_at','effect']:assert before[ident].get(k)==after[ident].get(k),(ident,k)
write(pub/'batch-readback.json',{'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_final_verification':final,'original_artifact_manifest_entries_verified':len(manifest['files']),'source13_leaves_sha_and_actual_live_ancestors_verified':True,'source11_equal2_historical_name_comment_differences_preserved':True,'original_evidence_rows':8444,'original_material_assertions':56,'material_probes_reexecuted':False,'owned_trace_only_ledger_rows':16,'protected_fold_preserved':True,'original_material_failure':'Initial old question container incorrectly read options; original KeyError retained. Corrected criteria read passed original material assertions without claiming production tests.','native_gap':'Original learner explicitly lacked native request readback; ops verified original Sol6.1/xhigh/input/lease/workspace-write/no-network. Task high wording preserved.','limits':evidence['limitations']+['Six Silent A10 runs have dirty source identities, not reconstructed whole historical execution trees. L9 original deepseek-for-codex summary is not pure Codex performance certification.','Pending potion replies remain pending despite later slot consumption; neither action acknowledgement nor net HP proves whole-plan completion or per-source damage.','Original placeholder HP tie-break and actual_turn=null remain; existing narrow facts do not close wide proposals or learning parents.'],'no_source_tests_merge_release_dataset_or_game_actions':True})
files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<350000 and f.suffix in ['.json','.jsonl','.md','.py','.patch','.log']];files+=[s/'evidence/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']];refs=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted(files):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);refs.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',refs)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
line=f'\n- {at} 运维codex：1955原194301策略rc0/done/no-source门禁核，十项waiting；f8ca干净WT无新源码提交，testsnull/mergednull/域空，不重合/发号/补测或重复提案。六Silent A10原8444行字节/身份与56材料断言为原学习者读回，固定材料首脚本误读options的KeyError与改读criteria后通过均留史，不当生产测试或整战收益。13叶旧livefe646265逐SHA/真实源祖先核，11同/2历史Roy-Dai注释差保持，原占位HP tie-break及actual_turn未知不冒闭合。16原CLI仅where/note/逐offset和SHA，claim/首证/prior/evidence/status/version等保护同验，未重复CLI或降级已shipped窄经验。ops补核实际native Sol6.1/xhigh/input/lease和workspace-write/no-network，原学习者未核native及任务high文字边界不改。KEN七饮药有后帧消费但三原pending不改completed，不冒整候选或逐来源归属；净血差/多次同局SL/PU第五试胜反例均保原条件边界，L9 deepseek-for-codex汇总与dirty历史树不当纯Codex战绩或完整源码还原。无新知识/反证/复盘/源码，不刷新论文、不改当前局/账号home模型预算队列prompt，原宽父及各owner保持、不等待未来事件。证据paper/materials/20261015-1955-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原194301十项继续waiting，无源码/合入/版本；16条CLI仅追溯且原知识/状态保护不变。原8444行/56材料检查及初始KeyError后修正读回均归档，不冒完整候选、生产测试或收益，不重复派单。回执paper/materials/20261015-1955-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers);write(pub/'completion.json',{'at':at,'batch':bid,'waiting':10,'own_ledger_rows':16,'new_to_HEAD_rows':len(added.splitlines()),'protected_ledger_fields_preserved':True,'no_source_tests_merge_release_or_dataset':True,'native_model_and_original_sandbox_verified':True,'parallel_records_preserved':True})
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
entries=[];dest=p/'final-files'
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':entries})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
print(json.dumps({'waiting':10,'owned_ledger_rows':16,'native_verified':True,'ledger_check':0,'paths':len(entries)}))

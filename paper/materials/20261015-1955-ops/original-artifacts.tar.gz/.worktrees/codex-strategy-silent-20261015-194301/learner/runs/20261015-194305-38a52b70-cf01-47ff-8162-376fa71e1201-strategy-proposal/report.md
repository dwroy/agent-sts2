# 本批指定策略提案复核

记录时间：2026-10-15T19:52:21+08:00。角色：silent，仅已核实A10。批次：20261015-194301-strategy-proposal。

基线：`f8ca991199183fb007dbeeb512cfa861912433dc`；初始工作树干净，普通任务执行`git merge --no-edit main`返回Already up to date。本批明确领取十个既有CLI提案；无research_request或implementation_request，不承接其他专题/队列。原专题文件绑定旧批次，未读取其work_spec或冻结材料。

十份原Markdown均按队列保存SHA核验并以`<id>.original.md`保存原字节。本次不新建重复提案，不重写历史复盘。下列均为waiting；原经验的shipped与本次宽提案waiting是不同口径，不撤销已上线窄事实。

## 本批结果

十项均已逐项核对，全部waiting，无源码/知识变更、无新提交、无live合入、无版本、无implemented/shipped声明。提案与逐项证据见`proposal.md`；机器处置见`result.json`。implementation_domains为空仅表示本批未实现代码，原提案领域保留于`dispatched-proposals.json`。

## 原日志复核

使用共用extract_evidence入口，六局均在runs.jsonl核为SILENT A10。共8444条记录在冻结source_size内逐条seek读回，核offset/bytes/SHA、JSON原文和显式局身份；56项材料断言全部通过。逐流输出SHA与计数保存`evidence/evidence-manifest.json`，逐事实读回保存`evidence-audit.json`。未用正文提及确认身份。

| 流 | 冻结字节截点 | 入选行数 | 源扫描无效行 |
|---|---:|---:|---:|
| runs | 336816 | 6 | 0 |
| states | 13115580575 | 4167 | 2 |
| decisions | 1644671738 | 4071 | 2 |
| sl-attempts | 40814845 | 43 | 0 |
| run-config | 1774491 | 6 | 0 |
| run-plans | 8135172 | 21 | 0 |
| brain | 595529696 | 130 | 1 |
| fight-plans | 2233957 | 0 | 0 |

源扫描无效行没有作为有效证据；fight-plans在该截点选中0行，只表示该截点无入选行，不声称原日志缺失。未复用或覆盖旧截点/零行报告。八流每条原offset/bytes/SHA均保留在evidence文件。

## 当前实现复核

只读live快照`fe6462651b593b9831581c088deface9957a404f`；13源码叶中11叶原字节相同，potion-cost.ts与explore.ts的两个差叶仅Roy/Dai历史注释，完整补丁保存在本目录，不覆盖它们。实际live路径最后提交/祖先和SHA见`source-audit.json`。现有固定测试也明确保持原始占位HP排序以及actual_turn未知，本批只阅读这些测试，没有运行或借用旧测试绿。

## 已有实现和保留边界

- `silent-held-loss.ts`将总损血、持牌失血、未决弃牌及来源分列，actual_held_hp_loss为空；未决弃牌不能预扣一张呼唤。
- `silent-potion-reference.ts`将持药值null与成本0分开，并将本轮不喝与模型整战不喝分开；不制造持药数值。
- `silent-sl-comparison.ts`、`silent-sl-resource-comparison.ts`和`silent-selection-audit.ts`记录原/替候选及模型差值；`silent-selection-dispatch.ts`只记录单动作回执，actual_turn/whole_plan仍未知。
- `attempts.ts`与`silent-giant-potion.ts`分开本体已结束、自爆待结算和原始占位HP。`explore.ts:anchorRank`仍保留原参考排序；阶段提示不意味着排序修复或胜率改善。

本次只读核验的真实live祖先包括5604982e13890e0e2bc8bf8246272e8267321c0b（SL资源对照）、a83d9ab675560a177249aa638e99df40bcfb5553（巨兽阶段）、05cd292c6f01bb31e406473d3a9843e659d62b93（持牌候选事实）、c4670f4f416c7d93e192e889c5080e7e4e0e733f（未知持药值）、fdaf787a372880b0438e73bcac7e6d2168b038ed（单动作回执）、d5e20aa4dd44168ce30944dfcce74f8322144953（巨兽药水阶段事实）。这些只证明对应窄功能存在，不登记整项implemented/duplicate。

## 证据、反例与未知

751 F17 T2第1/3试实际损13/18、敌净扣9/18；T7第2/4试实际损13/23、敌净扣12/18；T13第1/6试实际损8/2、敌净扣17/11。净扣包含实际结算的全部来源，不冒称逐源直伤。六试全败不能证明禁止更差线能获胜。

KEN F17第4/5试T10实际损15/21、净扣2/4；T5第4/6试损7/5、净扣1/2，但后者步法延迟到T9，T5净扣还含续问追加的小刀，不归原模型误差。不能据此认定最少失血恒优。

KV F33第4/5试T5损血均0、净扣36/29，题面同指纹；删掉输出没有已观察即时保血。两试都T10判死但后继动作亦变，不能把结果全归这一步；回血使净HP差不等于毛伤害。

YQL F17末试T10毒水只观察到毒2→8，玩家26血/13挡、已显示自爆41均不变；26+13−41=−2是该末态算术，不是任意替线的终局公式。L9六试未胜，PU第五试F17实际胜余2是必须保留的反例；不把本体结束判成整场胜利，也不把近十亿占位血改为通用进度。

KEN七次喝药均有对应槽位前后帧；其中274131、274237、274272原result为pending，后帧耗药可证消费，不能把pending改写为completed或据此认定完整药水方案执行。F15两药后赢战零损不等于无药也零损；F17入口75/86空药栏，不证明某瓶留药必胜。

不读取其他角色知识，不将历史mixed/DeepSeek局称为纯Codex战绩：L9的runs原deciders含deepseek (for codex)，其他五局原汇总含codex；未核完整native调用，不作本批收益/纯脑资格统计。所有原code都含dirty，不能据短提交重建当时完整执行树。
## 逐项处置与交付

- `silent-proposal-366288801d9150d9`：waiting；751 F17 T2/T7/T13同盘净扣与失血已核；SL候选对照及单动作回执已有live实现，但完整回合执行归属、抽弃续问后的逐源结果与受控整战后继未闭合，不能拟合额外失血门槛。 账本：silent-0079, silent-0176。
- `silent-proposal-85929bdfc8a3fc1b`：waiting；751 F13 T3有药plan2与整战无药模型plan5均8/8结束、损8，plan3后轮仍7/8用药；缺实际无药整战、留至boss分支及未决弃呼唤后的逐源结算，不把未知持药值设为0。 账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。
- `silent-proposal-efd9f83ee9e1a6dc`：waiting；751换线多9净扣付5血、多6付10及省6少6均复核；六次同局重打均败，已有预测分账不等于整轮实果，缺受控完整后继与独立后期验证，不改SL排序。 账本：silent-0079, silent-0176。
- `silent-proposal-131042659448ae74`：waiting；现有持牌保守失血、未决弃牌与持药值未知字段已覆盖窄展示；actual_turn仍null，缺攻击/毒/荆棘逐源归属、能力后继兑现及跨战无药结果，不能将宽提案整体标duplicate。 账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。
- `silent-proposal-990f054036609447`：waiting；KV F33第4/5试T5同指纹去掉致命毒药后净扣36→29且都零损；后轮动作也变，缺受控完整后继、回血逐源与未走路线/休息实果，不能拟合SL或终局权重。 账本：silent-0102, silent-0019, silent-0020。
- `silent-proposal-e18d3f18e6cac2a0`：waiting；巨兽本体/占位体/末态资源已有live祖先源码；anchorRank仍按原始占位HP作同轮tie-break。L9/YQL失败与PU第五试F17胜均保留，缺改序后的受控完整后继及结局校准。 账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。
- `silent-proposal-9733bb80f445aeae`：waiting；YQL F17末试T10毒药水使残壳毒2→8，26血/13挡/自爆41不变；既有提示只覆盖该局部事实，提前喝、不喝、留药及改变SL排序的整战收益仍缺受控分支。 账本：silent-0017, silent-0019, silent-0020, silent-0250。
- `silent-proposal-c51468c5e8ba6668`：waiting；KEN七次use_potion均有后帧槽位消耗，三次原回执是pending；缺随机选牌/发光水重问后的完整收益归属、F15不喝及留到boss的整战对照，不能量化跨战持药值。 账本：silent-0019。
- `silent-proposal-86a7db08d1a31976`：waiting；KEN F17第4/5试T10多损6仅多净扣2；第4/6试T5省2却将步法从T5延至T9。缺完整逐源归属、受控整战及新局留出验证，不能设统一6血/2伤阈值。 账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。
- `silent-proposal-e282a9131b99129a`：waiting；KEN双向取舍支持现有条件性经验；六次SL仍为同一局且未胜，预测与单动作回执不能闭合能力后继或整轮实果，缺受控胜线与后期独立验证，保留探索及HP护栏。 账本：silent-0021, silent-0079, silent-0125, silent-0176。

## 验证与失败保留

本批未改生产源码，无撤源码负控/恢复测试；tsc、vitest、cases均为null，没有运行沙箱生产测试，不把56项材料检查填成生产测试成功。无提交，故未执行提交前gitleaks流程；未推送。第一次材料脚本把旧题目候选容器误读成options，KeyError原日志保存在evidence-audit.log；按实际criteria字段修正后，evidence-audit-v2.log记录56项通过。该失败是材料脚本准备错误，不是产品失败，未删除原件。

不拟合新阈值，不重复模拟池/调用模型/网络，不运行play，不改根专题/调度状态/其他owner，不尝试没有源码差异的空合入。旧模型文字high与仓库xhigh要求并存，本会话没有独立native请求读回，不声称已核实际运行模型或改过配置。

账本已通过根learner/ledger.py update追加16条本批proposal/report追溯，CLI退出0，逐条原offset/bytes/SHA读回确认；原claim、evidence、first_run、prior、status、version等保护字段全部不变，未把已shipped经验改回proposed。CLI输入/输出和保护字段核验见ledger-updates.jsonl、ledger-update.log、ledger-readback.json。本批不新建游戏知识条目，不重复add原十提案，不将报告结束当学习入库/消费者已采用或父要求完成。

最终已核HEAD等于完整base且git status为空，tracked diff为0字节；见final-verification.json及workspace-final.patch。scratch为原已忽略learner/runs范围。根账本CLI追加属于授权记录例外，留给原调度/运维接收，不自行提交其他并行记录。

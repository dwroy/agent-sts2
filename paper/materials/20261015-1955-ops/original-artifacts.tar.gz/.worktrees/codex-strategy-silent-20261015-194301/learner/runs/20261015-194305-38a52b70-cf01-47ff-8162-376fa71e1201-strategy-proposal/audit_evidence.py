import hashlib
import importlib.util
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['record']['runs']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
rows = {}
verified = {}
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'pass': actual == expected})


def ref(item):
    return {k: item[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']}


for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = Counter()
    rows[name] = {}
    source_path = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
    with source_path.open('rb') as source, path.open('rb') as handle:
        for line in handle:
            digest.update(line)
            item = json.loads(line)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256'], (name, item['line'])
            assert json.loads(raw) == item['row'], (name, item['line'])
            assert extract.run_identity(item['row']) == item['run_id'] in runs
            assert item['offset'] + item['bytes'] <= stream['source_size']
            counts[item['run_id']] += 1
            rows[name][item['line']] = item
    assert digest.hexdigest() == stream['output_sha256']
    assert {run: counts[run] for run in runs} == stream['counts']
    verified[name] = {'verified_rows': sum(counts.values()), 'counts': dict(counts),
                      'source_size': stream['source_size'], 'output_sha256': digest.hexdigest(),
                      'source_invalid_lines': stream['invalid_lines']}

for item in rows['runs'].values():
    row = item['row']
    check('角色:' + item['run_id'], row['character'], 'SILENT')
    check('进阶:' + item['run_id'], row['ascension'], 10)
for item in rows['states'].values():
    state = item['row']['state']
    assert state['run']['character_id'] == 'SILENT'
    assert state['run']['ascension'] == 10

originals = json.loads((OUT / 'dispatched-proposals.json').read_text())
for record in originals:
    original = record['original']
    data = (OUT / (record['id'] + '.original.md')).read_bytes()
    check('提案原件:' + record['id'], hashlib.sha256(data).hexdigest(), original['proposal_sha256'])

for left, right in [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601), (273400, 273450)]:
    check('同指纹:' + str(left) + '/' + str(right),
          rows['decisions'][left]['row']['fingerprint'] == rows['decisions'][right]['row']['fingerprint'], True)

attempts = {(x['run_id'], x['row']['floor'], x['row']['attempt']): x for x in rows['sl-attempts'].values()}


def turn_delta(run, floor, attempt, turn):
    item = attempts[(run, floor, attempt)]
    turns = {t['turn']: t for t in item['row']['summary']['turns']}
    before, after = turns[turn], turns[turn + 1]
    hp = lambda t: sum(int(v) for v in re.findall(r' (\d+)/\d+', t['enemies']))
    return {'hp_loss': before['hp'] - after['hp'], 'enemy_net_hp_removed': hp(before) - hp(after),
            'plays': before['plays'], 'source': ref(item)}


turn_facts = {}
for run, floor, attempt, turn, expected in [
    ('751FN9QM9MHQ', 17, 1, 2, [13, 9]),
    ('751FN9QM9MHQ', 17, 3, 2, [18, 18]),
    ('751FN9QM9MHQ', 17, 2, 7, [13, 12]),
    ('751FN9QM9MHQ', 17, 4, 7, [23, 18]),
    ('751FN9QM9MHQ', 17, 1, 13, [8, 17]),
    ('751FN9QM9MHQ', 17, 6, 13, [2, 11]),
    ('KV0JHNJCKXLS', 33, 4, 5, [0, 36]),
    ('KV0JHNJCKXLS', 33, 5, 5, [0, 29]),
    ('KEN58SH9SLZ6', 17, 4, 10, [15, 2]),
    ('KEN58SH9SLZ6', 17, 5, 10, [21, 4]),
    ('KEN58SH9SLZ6', 17, 4, 5, [7, 1]),
    ('KEN58SH9SLZ6', 17, 6, 5, [5, 2]),
]:
    key = f'{run}/F{floor}/A{attempt}/T{turn}'
    fact = turn_delta(run, floor, attempt, turn)
    turn_facts[key] = fact
    check('实际整轮净变化:' + key, [fact['hp_loss'], fact['enemy_net_hp_removed']], expected)

def state_at(line):
    return rows['states'][line]['row']['state']


def giant_snapshot(line):
    state = state_at(line)
    player = state['combat']['player']
    enemy = state['combat']['enemies'][0]
    poison = next((p['amount'] for p in enemy['powers'] if p['power_id'] == 'POISON_POWER'), 0)
    return [player['current_hp'], player['block'], enemy['intents'][0]['damage'], poison, enemy['current_hp']]


check('残壳毒水前', giant_snapshot(280160), [26, 13, 41, 2, 999999999])
check('残壳毒水后', giant_snapshot(280161), [26, 13, 41, 8, 999999999])
potions = []
for decision, before, after, slot, potion in [
    (274131, 280206, 280207, 0, 'ATTACK_POTION'),
    (274156, 280232, 280233, 0, 'STABLE_SERUM'),
    (274185, 280262, 280263, 0, 'SPEED_POTION'),
    (274235, 280313, 280314, 1, 'WEAK_POTION'),
    (274237, 280315, 280316, 0, 'ATTACK_POTION'),
    (274267, 280348, 280349, 1, 'GLOWWATER_POTION'),
    (274272, 280354, 280355, 0, 'SKILL_POTION'),
]:
    d = rows['decisions'][decision]['row']
    a, b = state_at(before)['run']['potions'][slot], state_at(after)['run']['potions'][slot]
    check('耗药槽位:' + str(decision), [d['chosen']['action'], d['chosen']['option_index'], a['potion_id'], b['occupied']],
          ['use_potion', slot, potion, False])
    potions.append({'decision': ref(rows['decisions'][decision]), 'floor': d['floor'], 'turn': d['turn'],
                    'potion': potion, 'result': d.get('result'), 'before': ref(rows['states'][before]),
                    'after': ref(rows['states'][after]), 'whole_plan_executed': None})

q = rows['decisions'][272361]['row']['questions']['plan']
options = {key: json.loads(value) if isinstance(value, str) else value for key, value in q['criteria'].items()}
check('有药与整战无药即时损血', [options['plan2']['hp_lost'], options['plan5']['hp_lost']], [8, 8])
check('全程无药参考有明确标签', 'no_potion_fight' in options['plan5'], True)
check('本轮无药不等于全程无药', '7/8' in options['plan3']['potion_cost'], True)

attempt_summary = [{**ref(x), 'floor': x['row']['floor'], 'attempt': x['row']['attempt'],
                    'result': x['row']['result'], 'turns': x['row']['turns'], 'end_hp': x['row']['end_hp']}
                   for x in rows['sl-attempts'].values()]
for run in ['751FN9QM9MHQ', 'YQL8RZ8BWN1E', 'L9SGRBB5R698', 'KEN58SH9SLZ6']:
    a = [x for x in attempt_summary if x['run_id'] == run and x['floor'] == 17]
    check('六试无胜:' + run, [len(a), sum(x['result'] == 'won' for x in a)], [6, 0])
check('巨兽胜线反例保留', attempts[('PU80F84P6HPN', 17, 5)]['row']['result'], 'won')

result = {'verified_streams': verified, 'verified_total': sum(x['verified_rows'] for x in verified.values()),
          'material_checks': checks, 'all_material_checks_pass': all(x['pass'] for x in checks),
          'turn_facts': turn_facts, 'potion_consumptions': potions, 'attempts': attempt_summary,
          'limitations': ['整轮净扣血不是逐源伤害归属。', '模拟或局部实果不是未执行分支的整战反事实。',
                          '本脚本只核材料，不是生产tsc/vitest或策略收益测试。']}
(OUT / 'evidence-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_total': result['verified_total'], 'material_checks': len(checks),
                  'all_pass': result['all_material_checks_pass']}, ensure_ascii=False))
assert result['all_material_checks_pass']

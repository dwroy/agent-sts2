from pathlib import Path
import json, hashlib, subprocess, csv, re, importlib.util, os, tarfile
r = Path.cwd(); p = r / 'ops/codex-ops/record-staging/20261015-1913'; pub = r / 'paper/materials/20261015-1913-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a): return subprocess.check_output(['git', *a], stderr=subprocess.PIPE)
assert not (p / 'record-manifest.json').exists()
result = json.loads((pub / 'paper-dataset-result.json').read_text()); assert result['actual_exit_code'] == 0 and result['calls'] == 1
log = (pub / 'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before = {x['path']: x for x in json.loads((p / 'paper-before.json').read_text())}
store = p / 'paper-owned'; store.mkdir(exist_ok=True); outputs = []
for f in sorted((r / 'paper/data').iterdir()) + [r / 'paper/materials/silent/cost.md']:
    if not f.is_file(): continue
    raw = f.read_bytes(); path = str(f.relative_to(r)); h = sha(raw)
    if path in before and h == before[path]['sha256']: continue
    name = path.replace('/', '--'); (store / name).write_bytes(raw); outputs.append({'path': path, 'bytes': len(raw), 'sha256': h, 'snapshot': name})
(p / 'paper-owned-manifest.json').write_text(json.dumps(outputs, ensure_ascii=False, indent=2) + '\n')
by = {x['path']: x for x in outputs}
def frozen(path):
    if path in by:
        raw = (store / by[path]['snapshot']).read_bytes(); assert sha(raw) == by[path]['sha256']; return raw
    return (r / path).read_bytes()
summary = json.loads(frozen('paper/data/summary.json')); verification = json.loads(frozen('paper/data/verification.json'))
checks = {k: v for k, v in verification['checks'].items() if isinstance(v, bool)}
assert len(checks) == 5 and all(checks.values()) and summary['source_checks_passed'] is True
cut = re.match(r'^cut at (\S+): ', log).group(1); assert summary['generated_at'] == cut
runs = list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected = [x for x in runs if x['run_id'] == 'RQCHNN0W72KF']; assert len(selected) == 1
row = selected[0]
assert all(row[k] == v for k, v in {'character': 'SILENT', 'ascension': '10', 'outcome': 'defeat', 'floor_max': '49', 'n_decisions': '772', 'has_postmortem': '0'}.items())
brain = json.loads(row['brain_source'])
snap = {'request': result, 'generated_at': cut, 'source_cut_bytes': summary['source_cut_bytes'], 'five_checks': checks, 'source_checks_passed': True, 'row_counts': verification['row_counts'], 'total_decision_records': summary['decisions']['play_total'] + summary['decisions']['shadow'], 'original_count_warnings': verification['checks']['runs.jsonl decision-count mismatches'], 'run': {k: row[k] for k in ['run_id', 'character', 'ascension', 'outcome', 'floor_max', 'n_decisions', 'has_postmortem', 'performance_included']}, 'brain_source': brain, 'stage_boundary': 'Original run used P2/C2 on and C1 no-numbers degradation. Descriptive defeat only, no causal benefit or completed learner postmortem; original startup failure remains.', 'changed_outputs': outputs, 'component_costs': 'Separate immutable byte cuts and estimates, not invoice or credit conversion.', 'raw_snapshot': False, 'previous_outputs_preserved': str((p / 'paper-before').relative_to(r))}
(pub / 'paper-snapshot-readback.json').write_text(json.dumps(snap, ensure_ascii=False, indent=2) + '\n')
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1913原191301/RQCHNN0W72KF复盘失败核，原failed/rc1/done空/missingRQ、attempts1/retry20:13:08CST/最多3次保持。原native thread/start前bubblewrap/ripgrep扫描ENOENT、3.7秒/0模型轮/0工具/0token；启动telemetry Sol6.1/xhigh与/models200不当正式模型调用或额度证明，非额度/登录故障证据。retryabletrue但batch/lease均null，不越租约手动重放；d998仍祖先/恢复叶相同，根launcher与live既有差异分列，不能仅凭null认定具体守卫或删除者。原日志提及外项目路径，未读核改其他项目、不扩沙箱/凭据deny，沿原启动竞态队列补证，不新派研究/重复修复。原失败跳过空提案审计生效，scratch空/无复盘/无本批ledger或提案，不冒既有ops0332追溯为学习者产出；原已有lessons/ledger及并行记录不暂存。ops首记录guard误要求整launcher main-live相同，在生成实际启动前已纠正并保独立SHA；没有重复启动generator/学习者。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0，cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性/keyscan CLEAN；RQ原负局F49/772决策入表、has_postmortem0及原脑资格/未知按原口径保存，P2/C2 on与C1降级为描述性边界，不作收益/原父完成声明。成本独立cut估算非账单，旧告警保持。仅提交本人失败/队列/生成产物和回执，无新源码/发布/测试或对局重启/账号模型预算队列prompt变更，不等待未来重试事件。证据paper/materials/20261015-1913-ops/。\n'
note = f'\n- {at} [ops 复盘失败] RQ原191301在session创建前因已知目录扫描ENOENT退出1，无模型轮/完成复盘，非额度/登录故障证据；原20:13:08一小时重试/次数保持，batch/lease null不越权重放。旧启动竞态链补证，不查改外项目或扩大权限，不影响对局。论文单次刷新exit0、{len(runs)}局/五一致性/keyscan通过，RQ has_postmortem=0保留，原错误不当游戏机制或收益结论。回执paper/materials/20261015-1913-ops/。\n'
appends = json.loads((p/'early-appends.json').read_text()) | {'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note}
(p/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n')
for path,text in {'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note}.items():
    with (r/path).open('ab') as out:out.write(text.encode())
values = {path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for x in outputs: values[x['path']] = frozen(x['path'])
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in list(p.glob('*.py')) + [r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at':at,'postmortem':'RQCHNN0W72KF','canonical':'failed/rc1/no completed postmortem','old_issue':'sandbox-glob-startup-race','scheduler_retry_preserved':True,'owned_ledger_or_lesson_rows':0,'paper_single_exit':0,'paper_cut':cut,'paper_output_count':len(outputs),'five_checks':True,'no_source_release_game_account_or_prompt_change':True,'parallel_records_preserved':True},ensure_ascii=False,indent=2)+'\n')
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; manifest = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); manifest.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': manifest}, ensure_ascii=False, indent=2) + '\n')
(p/'preserved-head-ledger.jsonl').write_bytes(git('show',base+':paper/materials/learning/ledger.jsonl'))
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(p / 'preserved-head-ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'paths': len(manifest), 'ledger': 0, 'ledger_check': 0, 'paper_outputs': len(outputs), 'runs': len(runs), 'paper_exit': 0}))

from analyze import *
import sys
mode=sys.argv[1]
def ps(p):return [(x['power_id'],x['amount']) for x in p or []]
if mode=='frames':
 for r in S:
  s=r['state'];f=s['run']['floor'];c=s.get('combat') or {}
  if f not in (17,23,24) or not s.get('in_combat'):continue
  p=c.get('player') or {}
  print(r['_line'],'F'+str(f),'T'+str(s['turn']),'HBE',s['run']['current_hp'],p.get('block'),p.get('energy'),'P',ps(p.get('powers')),'E',[(e['index'],e['enemy_id'],e['current_hp'],e['block'],ps(e['powers']),[(i.get('intent_type'),i.get('damage'),i.get('hits')) for i in e['intents']]) for e in c['enemies']])
if mode=='meta':
 for d in D:
  if d.get('deepseek'):print(d['_line'],d['label'],'deepseek keys',d['deepseek'].keys());break
 for d in D:
  if d['floor'] in (23,24) or d['_line']==428003:
   print('d',d['_line'],d['label'],d['rationale'])
   a=d.get('selection_audit') or {}
   for key in ('answer','before_sl','after_sl'):
    z=a.get(key) or {}
    if z:print(key,z.get('line'),z.get('turn'),z.get('rollout'))
 print('guards',[(d['_line'],d.get('hp_guard'),d['rationale']) for d in D if d.get('hp_guard') or 'HP guard' in d['rationale']])

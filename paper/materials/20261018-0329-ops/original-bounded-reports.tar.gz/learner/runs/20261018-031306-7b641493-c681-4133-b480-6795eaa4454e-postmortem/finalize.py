from analyze import *
import subprocess,hashlib
from datetime import datetime
ids=['silent-0019','silent-0079','silent-0025','silent-0023','silent-0044','silent-0316','silent-0133','silent-0222','silent-0243']
items=json.loads((P/'ledger-final.json').read_text());assert {x['id'] for x in items}==set(ids)
for i in items:
 assert any(e['run']=='559UJVNHZ5NM' and e.get('role')=='support' for e in i['evidence'])
 assert i['status']=='shipped'
check=int((P/'ledger-check-exit.txt').read_text());assert check==0
fights=R['combats'];fr={r['_line']:r['state'] for r in S}
expected={17:([262,240,223,209,180,158,124,114,81,55,38,2],[22,17,14,29,22,34,10,33,26,17,36,2],[0,5,16,12,0,0,4,4,0,11,18,0]),23:([140,136,120,105,88,46,31],[4,16,15,17,42,15,31],[10,0,19,0,0,12,0])}
for w in fights:
 if w['floor'] not in expected:continue
 seq=[r for r in S if w['entry']['line']<=r['_line']<=w['exit']['line']];a=[];d=[];h=[]
 hp=lambda s:sum(e['current_hp'] for e in (s.get('combat') or {}).get('enemies',[]) if e['is_alive'])
 for t in range(1,w['last']['turn']+1):
  x=next(r['state'] for r in seq if r['state']['turn']==t);y=next((r['state'] for r in seq if type(r['state']['turn'])==int and r['state']['turn']>t),fr[w['exit']['line']]);a.append(hp(x));d.append(hp(x)-hp(y));h.append(x['run']['current_hp']-y['run']['current_hp'])
 assert (a,d,h)==expected[w['floor']]
s651=fr[442651];s652=fr[442652];assert s651['turn']==5 and s652['turn']==6
powers=lambda s:{p['power_id']:p['amount'] for p in s['combat']['enemies'][0]['powers']}
assert powers(s651)=={'PLOW_POWER':160,'STRENGTH_POWER':6,'POISON_POWER':12}
assert powers(s652)=={'POISON_POWER':11}
assert s651['combat']['enemies'][0]['current_hp']==170 and s652['combat']['enemies'][0]['current_hp']==158
text=Path('notes/lessons.md').read_text();section=text.split('## 559UJVNHZ5NM',1)[1].split('\n## ',1)[0]
assert section.count('- [记录]')==1 and section.count('- [')==4
assert text.count('## 559UJVNHZ5NM')==1
assert 's442651的T5末仪式兽170血' in section
props=[(P/'potion-timing-receipt.json').read_text().strip(),(P/'artifact-receipt.json').read_text().strip()]
assert all(s.startswith('silent-proposal-') for s in props)
missing='开局dirty完整字节；前序路线／用药／启动／目标顺序的受控胜负；其他药水生成结果及全部合法排列；前三次判死后实际结算；部分末击帧、重复ID固定击杀身份及雾菇完整逐击伤害；最终完整最优线执行率；旧boss时钟需要／估计与对应比值、二幕boss实打；纯战斗墙钟、Jev缓存、实付账单'
report={"task":"postmortem","appended":["559UJVNHZ5NM"],"skipped":[],"bugs":[],"ledger":{"added":[],"updated":ids,"repeats":[],"check":check},"code_proposals":props,"implementation_domains":["combat","potion","sl","terminal"],"report":str(P/'report.md')}
md='''## 复盘回报
- 已追加：559UJVNHZ5NM（A10，第24层，4血10挡承受双啃咬机18攻击死亡；已附机制及取时勘误）。
- 新的纯 bug（file:line，每条一行；没有写「无」）：
  - 无
- 写成「未记录」的项：559UJVNHZ5NM：'''+missing+'''。
- 学习账本：559UJVNHZ5NM：新增无；更新 '''+'、'.join(ids)+'''（均为support，老错重犯无）；`ledger.py check`退出码0。
- 代码提案：'''+props[0]+'''（F24T1，silent-0079／0023，能力药与SL时序）；'''+props[1]+'''（F24T1，silent-0025，人工制品下药水后继）。均由CLI关联独立strategy-proposal，pending；单局同存档证据不足以改阈值或宣称换线获胜，未实现／上线。

```json
'''+json.dumps(report,ensure_ascii=False)+'''\n```
'''
(P/'report.md').write_text(md);(P/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(P/'post-append-verification.json').write_text(json.dumps({'checks':0,'run':'559UJVNHZ5NM','ledger_items':ids,'proposals':props,'lesson_sha256':hashlib.sha256(section.encode()).hexdigest(),'verified':'两场关键战逐轮数组、15窗口入口末态、终战死亡数字、毒未建立、阈值勘误、9条support、账本check0'},ensure_ascii=False,indent=2)+'\n')
print(md)

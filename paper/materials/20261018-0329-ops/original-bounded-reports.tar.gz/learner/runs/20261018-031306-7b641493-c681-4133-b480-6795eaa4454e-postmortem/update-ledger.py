import json,subprocess
from pathlib import Path
P=Path(__file__).parent
run='559UJVNHZ5NM'
items=[
('silent-0019',23,7,'本局F17首试75/77→5/77胜，跨幕5→62；F19/F20/F22/F23胜战净耗2/3/12/41，F24仅4血。F22题b16085投影F24为36、首火F25为27，实到F24为4且首火未到；仅支持连续资源链，未验证替路或前序留药可赢。'),
('silent-0079',24,1,'四试同入口4/77、敌67+66。前两试较早喝能力药取得余像，后续两牌各补1挡，末12挡；第3/4试d428187/428196的SL把喝药移到中和+、打击+、匕首雨+之后，末10挡。四试均扣65敌HP、余20/48，完整需损6/6/8/8；前三试未结算，末试仅实扣4即死。只支持同败仍有2挡时序代价，没有已证可活替线，不记repeat、不据此改阈值。'),
('silent-0025',24,1,'四试中和+对攻击者实扣7，ARTIFACT_POWER2→1，无虚弱且18意图不变；毒药每次指非攻击者，仅使其人工制品2→1，48血不变、无POISON_POWER。s442826→827、442835→836、442844→845、442853→854；换指仍有1制品的攻击者也不能预支中毒，未核其他完整排列。'),
('silent-0023',24,1,'能力药四次均选并施放普通余像。前两试余像自身格挡10→10，其后中和+10→11、打击+11→12，毒药不增挡；后两试在攻击序列末才建余像，10→10、其后只有药水且仍10。s442823—827/442832—836/442843—845/442852—854；支持自身不倒补、药水不触发及后续逐牌1挡，均失败不定普遍优先级。'),
('silent-0044',23,4,'T1普通磨蚀花3能量，实建1敏捷4荆棘并损10；敌140→136由反伤4。T4无脆弱防御6+生存者9=15，比基础13多2；T6脆弱下防御4+生存者6=10，对22损12。T1/T3/T4/T6各反伤4共16，T7毒先杀敌无额外反伤；只记本组合，不称磨蚀无用或免费启动必然可达。'),
('silent-0316',23,6,'虱虫T3力量7/挡18、T6力量14/挡18；T4中和使17攻击降12，尖啸令力7→1、已有虚弱下12→8，玩家15挡零损；T5力回7、T6再长14，22攻对10挡损12。s442785/442795—798/442803—807；临时减力未关闭后续成长。'),
('silent-0133',17,6,'本局A10 PLOW_POWER.amount=160；T5末s442651为170HP/12毒/6力量/PLOW160，敌方响应后s442652的T6首帧158HP/11毒、PLOW与力量均清、非攻击意图。故毒跨160已取消该轮攻击，T6冲刺158→148在后，不能归因该冲刺，也不套旧A0的150。后段T10力4/21攻、T11力4/23攻，仍非后段零威胁。lessons附机制勘误。'),
('silent-0222',17,10,'仪式兽T7与T10有RINGING_POWER1，分别仅实打生存者8挡/冲刺10挡后结束，尚余2/1能量，面对12/21攻击实损4/11；毒仍结10/7。s442656—659、442669—671，单卡限制和持续毒分账，不规定固定首选牌。'),
('silent-0243',18,None,'本局A10仪式兽获胜出口5/77，跨幕s442688→442689为62/77，实际回57，等于floor((77−5)*0.8)；最大HP未变。F9/F13/F16 HEAL分别21/23/23和草莓+7分账，SL三次HP4不变、仅药水/敌状态复原，不当新回血。')]
results=[]
for ident,f,t,note in items:
 ev={'run':run,'floor':f,'role':'support','note':note}
 if t is not None:ev['turn']=t
 row={'id':ident,'by':'learner:postmortem','evidence':[ev],'where':{'lessons':[run]},'note':'本局只追加支持；原claim、first_run、prior、status、version不改。'}
 data=json.dumps(row,ensure_ascii=False)+'\n';(P/(ident+'-update.json')).write_text(data)
 subprocess.run(['date'],check=True)
 r=subprocess.run(['python3','/home/dw/Projects/agent-sts2/learner/ledger.py','update'],input=data,text=True,capture_output=True)
 results.append({'id':ident,'input':row,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 print(ident,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
 if r.returncode:break
(P/'ledger-update-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
if any(r['returncode'] for r in results):raise SystemExit(1)

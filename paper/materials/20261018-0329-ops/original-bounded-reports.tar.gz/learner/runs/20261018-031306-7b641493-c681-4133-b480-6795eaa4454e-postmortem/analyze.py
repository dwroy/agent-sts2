import json,collections
from pathlib import Path
P=Path(__file__).parent

def rows(name):
 out=[]
 for line in (P/(name+'.extract')).open():
  n,s=line.split(':',1);r=json.loads(s);r['_line']=int(n);out.append(r)
 return out
D=rows('decisions');S=rows('states');R=json.loads((P/'559UJVNHZ5NM-resources.json').read_text())
if __name__=='__main__':
 print('DECISION WINDOW',D[0]['ts'],D[-1]['ts']);print('decision keys',D[0].keys());print('state keys',S[0].keys());print('state nested keys',S[0]['state'].keys())
 for w in R['combats']:
  print('FIGHT',w['sequence'],w['floor'],w['enemies'],'entry',w['entry'],'last',w['last'],'exit',w['exit'],'end',w['end'])
 print('SL')
 for r in rows('sl-attempts'):print(json.dumps(r,ensure_ascii=False))
 print('NONCOMBAT HP')
 for c in R['resource_changes']:
  if c['combat_sequence'] is None:print(json.dumps(c,ensure_ascii=False))
 print('DECISIONS NONCOMBAT')
 for d in D:
  if d['decider']=='codex':print(d['_line'],d['floor'],d.get('turn'),d['label'],json.dumps(d.get('chosen'),ensure_ascii=False),d['rationale'])

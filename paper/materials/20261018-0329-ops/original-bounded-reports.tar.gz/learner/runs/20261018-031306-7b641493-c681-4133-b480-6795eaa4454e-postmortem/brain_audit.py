from analyze import *
B=rows('brain')
for b in B:
 print('b',b['_line'],b.get('ts'),b.get('label'),'keys',list(b.keys())[:30])
 print('meta',{k:b.get(k) for k in ('engine','model','effort','usage','latency_ms','floor') if k in b})
 for k in ('facts','question','options','answer','response'):
  v=b.get(k)
  if isinstance(v,dict):print(k,'keys',list(v.keys())[:30])
  elif isinstance(v,str):print(k,v[:100])
 if b.get('label') in ('rest/plan','event/act-plan','map/route-plan'):
  def walk(v,path=''):
   if isinstance(v,dict):
    for k,x in v.items():
     kp=path+'.'+k
     if k in ('boss_clock','act_boss_clock','route_projection','route_health','next_rest','boss_sim','act_boss_sim') or ('projection' in k):print(kp,json.dumps(x,ensure_ascii=False)[:11000])
     elif isinstance(x,(dict,list)):walk(x,kp)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,path+f'[{i}]')
  walk(b)

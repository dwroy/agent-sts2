from analyze import *
import hashlib,datetime,shutil,subprocess
assert len(D)==423 and len(S)==440
assert D[0]['_line']==427782 and D[-1]['_line']==428204
assert S[0]['_line']==442416 and S[-1]['_line']==442855
assert [w['entry']['hp'] for w in R['combats']]==[56,44,44,53,51,59,75,62,60,57,45,4,4,4,4]
assert [w['last']['hp'] for w in R['combats']]==[44,44,41,51,36,52,5,60,57,45,4,4,4,4,4]
assert all(w['entry_is_turn_one'] for w in R['combats'])
for w in R['combats'][-4:]:
 a=next(r['state'] for r in S if r['_line']==w['entry']['line']);b=next(r['state'] for r in S if r['_line']==w['last']['line'])
 assert [e['current_hp'] for e in a['combat']['enemies']]==[67,66]
 assert [e['current_hp'] for e in b['combat']['enemies']]==[20,48]
 assert all(not any(p['power_id']=='POISON_POWER' for p in e['powers']) for e in b['combat']['enemies'])
assert [next(r['state']['combat']['player']['block'] for r in S if r['_line']==w['last']['line']) for w in R['combats'][-4:]]==[12,12,10,10]
assert len([d for d in D if (d.get('chosen') or {}).get('action')=='use_potion'])==12
assert not [d for d in D if d.get('hp_guard') or 'HP guard' in d['rationale']]
assert len([d for d in D if d['decider']=='jev' and d.get('confidence',1)<.35])==24
source=['agent/src/reflex/combat-plan.ts','agent/src/reflex/turn-solver.ts','agent/src/sl/explore.ts']
manifest={'run':'559UJVNHZ5NM','live_commit':subprocess.check_output(['git','-C','.worktrees/live','rev-parse','HEAD'],text=True).strip(),'files':[],'checks':'入口血量、末态、余像挡量、毒未建立、用药与护栏计数全部通过'}
for f in source:
 data=(Path('.worktrees/live')/f).read_bytes();dst=P/('source-'+Path(f).name);dst.write_bytes(data);manifest['files'].append({'path':f,'sha256':hashlib.sha256(data).hexdigest(),'snapshot':str(dst)})
manifest['source_diff']=subprocess.check_output(['git','-C','.worktrees/live','diff','--binary','--',*source],text=True)
(P/'verification.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False))

from analyze import *
import sys,datetime
mode=sys.argv[1]
def ep(e):return {k:e.get(k) for k in ('index','enemy_id','name','current_hp','block','powers','intents','intent','is_alive') if k in e}
def pl(s):
 c=s.get('combat') or {};return {k:c.get(k) for k in ('energy','block','powers','player') if k in c}
if mode=='states':
 for r in S:
  s=r['state'];f=(s.get('run') or {}).get('floor')
  if f in (17,23,24) and s.get('in_combat'):
   c=s['combat'];print(r['_line'],f,s.get('turn'),'hp',s['run']['current_hp'],'player',json.dumps(pl(s),ensure_ascii=False),'en',json.dumps([ep(e) for e in c['enemies']],ensure_ascii=False),'hand',[(x.get('index'),x.get('card_id'),x.get('can_play')) for x in c.get('hand',[])])
if mode=='decisions':
 for d in D:
  if d['floor'] in (17,23,24) and d['decider']!='code' or d['floor'] in (17,23,24) and not d['label'].endswith('continue'):
   a=d.get('selection_audit') or {};print('d',d['_line'],'F',d['floor'],'T',d['turn'],'sl',d.get('sl_attempt'),d['label'],d['decider'],d['rationale'])
   for key in ('answer','before_sl','after_sl'):
    z=a.get(key) or {}
    if z:print(key,{k:z.get(k) for k in ('line','turn','rollout')})
if mode=='counts':
 J=[d for d in D if d['decider']=='jev'];C=[d for d in J if d['label'].startswith('combat/')];best=[d for d in C if 'rollout_best_chosen' in d]
 print('jev',len(J),'combat',len(C),'low',len([d for d in J if d.get('confidence',1)<.35]),'lowcombat',len([d for d in C if d.get('confidence',1)<.35]),'best',collections.Counter(d['rollout_best_chosen'] for d in best))
 print('nonbest',[(d['_line'],d['floor'],d['turn'],d['rationale']) for d in best if not d['rollout_best_chosen']])
 code=[d for d in D if d['decider']=='code' and d['label'] in ('combat/plan','combat/lethal','combat/least-loss')];print('code',len(code),'windows',len({(d['floor'],d.get('sl_attempt') or 1,d['turn']) for d in code}),collections.Counter(d['label'] for d in code))
 cw={(d['floor'],d.get('sl_attempt') or 1,d['turn']) for d in C};print('codeonly',len({(d['floor'],d.get('sl_attempt') or 1,d['turn']) for d in code}-cw))
 for d in D:
  a=d.get('selection_audit') or {};x=a.get('answer');y=a.get('before_sl');z=a.get('after_sl')
  if x and y and x!=y:print('guarddiff',d['_line'],x,y)
  if y and z and y!=z:print('sldiff',d['_line'],a.get('sl_delta'),y.get('line'),z.get('line'))
 for group,arr in [('jev',J),('brain',[d for d in D if d.get('deepseek')])]:
  print('usage',group,collections.Counter({k:sum((d.get('usage') or {}).get(k,0) for d in arr) for k in {k for d in arr for k in (d.get('usage') or {})}}))
 print('focus',[(d['_line'],d['floor'],d['turn'],k) for d in C for k in d.get('questions',{}) if 'focus' in k])
 print('focus candidates',sum('focus' in json.dumps(d.get('questions',{})) for d in C))
 print('duration',(datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(D[0]['ts'])).total_seconds())
if mode=='turntable':
 for w in R['combats']:
  fr=[r for r in S if w['entry']['line']<=r['_line']<= (w.get('exit') or w['last'])['line']]
  turns=[]
  for t in sorted({r['state'].get('turn') for r in fr if type(r['state'].get('turn'))==int}):
   rr=[r for r in fr if r['state'].get('turn')==t];first=rr[0]['state'];nexts=next((r['state'] for r in fr if type(r['state'].get('turn'))==int and r['state']['turn']>t),fr[-1]['state']);h0=first['run']['current_hp'];h1=nexts['run']['current_hp'];hps=lambda s:sum(e['current_hp'] for e in (s.get('combat') or {}).get('enemies',[]) if e.get('is_alive'))
   turns.append((t,h0,h0-h1,hps(first),hps(first)-hps(nexts)))
  print(w['sequence'],w['floor'],turns)

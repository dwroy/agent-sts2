from analyze import *
import sys
mode=sys.argv[1]
if mode=='turns':
 for w in R['combats']:
  print('FIGHT',w['sequence'],'F',w['floor'])
  obs=w['enemy_hp_audit']['observations'];fr={r['_line']:r for r in S}
  seen=set()
  for o in obs:
   t=o['turn']
   if t in seen:continue
   seen.add(t);s=fr[o['line']]['state'];c=s.get('combat') or {};p=c.get('player') or {}
   print(' T',t,'s',o['line'],'HP',s['run']['current_hp'],'player',p,'EN',json.dumps(c.get('enemies'),ensure_ascii=False)[:5000])
  print('AUDIT',[(x['turn'],x['live_enemy_hp_start'],x.get('live_enemy_hp_end'),x.get('net_live_enemy_hp_loss')) for x in w['enemy_hp_audit']['turns']])
if mode=='decision':
 for d in D:
  if d['floor'] in [17,23,24] and (d['decider']!='jev-plan' and not (d['decider']=='code' and d['label'].endswith('continue'))):
   print('d',d['_line'],'F',d['floor'],'T',d['turn'],'sl',d.get('sl_attempt'),d['label'],d['decider'],'conf',d.get('confidence'),'chosen',json.dumps(d.get('chosen'),ensure_ascii=False),d['rationale'])
   if d['label'].startswith('combat/'):
    print('journal',json.dumps(d.get('journal'),ensure_ascii=False)[:12000])
if mode=='summary':
 print('SL',[(x['_line'],{k:x.get(k) for k in ('floor','attempt','started_at','ended_at','result','end_hp','incoming','judge','reload','give_up_reason')}) for x in rows('sl-attempts')])
 for c in R['resource_changes']:
  a,b=c['from'],c['to'];print('RESOURCE','F'+str(b['floor']),'T'+str(b['turn']),a['line'],b['line'],b['ts'],a['hp'],b['hp'],a['max_hp'],b['max_hp'],a['potions'],b['potions'],'SL',c['restart_boundary'])
 print('COUNTS',collections.Counter((d['decider'],d['label']) for d in D))
 for d in D:
  if d['decider']=='codex':print(d['_line'],d['floor'],d['label'],d['rationale'])
if mode=='shape':
 for d in D:
  if d['decider']=='jev' and d['label'].startswith('combat/plan-choice'):
   print(json.dumps(d,ensure_ascii=False)[:25000]);break
 print('state',json.dumps(S[-2],ensure_ascii=False)[:22000])
 print('config',json.dumps(rows('run-config')[0],ensure_ascii=False)[:5000])

import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
decisions = {x['line']: x for x in json.loads((OUT / 'keydecisions.json').read_text())}
checks = []


def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})


row = decisions[285148]['row']
candidates = [{'id': key, **json.loads(value)} for key, value in row['questions']['plan']['criteria'].items()]
keys = ['id', 'plays', 'damage_dealt', 'hp_lost', 'whole_fight_sim', 'rollout', 'unmodelled_cards']
candidates = [{key: item.get(key) for key in keys} for item in candidates]
(OUT / 'L2-T6-candidates.json').write_text(json.dumps(candidates, ensure_ascii=False, indent=2) + '\n')
check('L2 T6同题plan1即时7伤零损', candidates[0]['damage_dealt'] == 7 and candidates[0]['hp_lost'] == 0)
check('L2 T6三候选整场各1200样本无赢样本', all('1200 samples' in c['whole_fight_sim'] and 'no winning sample' in c['whole_fight_sim'] for c in candidates))
check('L2 T6攻击线五轮14/24死而结束11/24', '14/24' in candidates[0]['rollout'] and '11/24' in candidates[2]['rollout'])
check('L2 T6侧步仍未建模', candidates[0]['unmodelled_cards'] == '侧步' and candidates[1]['unmodelled_cards'] == '侧步')
check('L2 T6实际回答结束0.94', row['answers']['plan']['choice'] == 'plan3' and row['confidence'] == 0.94)
ids = [284918, 284967, 284971, 285020, 285024, 285073, 285077, 285126, 285130]
check('L2九条护栏原文均存在', all('HP guard:' in decisions[i]['row']['rationale'] for i in ids))


def sl_line(entry):
    sl = entry.get('sl_explore') or {}
    return sl.get('replacement') or sl.get('replay', {}).get('line') or ''


check('L2四条T2护栏被SL覆盖', all('稳定血清' in sl_line(decisions[i]['row']) for i in [284967, 285020, 285073, 285126]))
check('ZTR三次护栏原文分列25至20/15至12/2至0', all(a in decisions[i]['row']['rationale'] and b in decisions[i]['row']['rationale'] for i, a, b in [(285301, 'hp -25', 'hp -20'), (285405, 'hp -15', 'hp -12'), (285745, 'hp -2', 'hp -0')]))
check('ZTR后两次预算已24且容许0', all('24+ extra HP' in decisions[i]['row']['rationale'] and 'more than 0 HP' in decisions[i]['row']['rationale'] for i in [285405, 285745]))
references = []
for line in sorted(set(ids + [285148, 285301, 285405, 285745])):
    entry = decisions[line]
    with open(entry['source'], 'rb') as handle:
        handle.seek(entry['offset'])
        raw = handle.read(entry['bytes'])
    assert hashlib.sha256(raw).hexdigest() == entry['sha256'] and json.loads(raw) == entry['row']
    references.append({key: entry[key] for key in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']})
gx = []
for entry in json.loads((OUT / 'sl-selected.json').read_text()):
    row = entry['row']
    if entry['run_id'] == 'GXNKW8X1XYJP' and row['floor'] == 45:
        inserted = [item for item in row.get('draws', {}).get('inserted', [])
                    if item['turn'] == 2 and item['cards'] == ['BLADE_DANCE', 'OUTBREAK', 'SUCKER_PUNCH', 'ACCELERANT']]
        if inserted:
            gx.append({'source': {key: entry[key] for key in ['source', 'line', 'offset', 'bytes', 'sha256']},
                       'attempt': row['attempt'], 'inserted': inserted, 'clean': row['draws'].get('clean')})
check('GX F45四个SL inserted的原字段turn=2、clean分别19/18/19/18',
      len(gx) == 4 and [item['clean'] for item in gx] == [19, 18, 19, 18])
(OUT / 'GX-inserted-audit.json').write_text(json.dumps(gx, ensure_ascii=False, indent=2) + '\n')
(OUT / 'additional-material-checks.json').write_text(json.dumps({'checks': checks,
    'passed': sum(x['passed'] for x in checks), 'total': len(checks), 'references': references,
    'production_tests': False}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': sum(x['passed'] for x in checks), 'total': len(checks),
                  'failed': [x['name'] for x in checks if not x['passed']]}, ensure_ascii=False))
assert all(x['passed'] for x in checks)

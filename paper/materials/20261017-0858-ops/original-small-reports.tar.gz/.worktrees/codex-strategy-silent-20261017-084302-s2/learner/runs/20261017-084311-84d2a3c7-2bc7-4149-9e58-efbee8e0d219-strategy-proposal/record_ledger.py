import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
assignments = json.loads((OUT / 'assigned-proposals.json').read_text())
ids = {item for proposal in assignments['proposals'] for item in proposal['original']['row']['ledger']}
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
path = ROOT / 'paper/materials/learning/ledger.jsonl'
raw = path.read_bytes()
prefix = {'source': str(path), 'source_size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
rows = [(i, json.loads(line)) for i, line in enumerate(raw.splitlines(), 1)]
before = ledger.fold([(i, copy.deepcopy(row)) for i, row in rows if row.get('id') in ids])
del raw, rows
assert set(before) == ids and len(ids) == 29


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


save('ledger-before-update.json', before)
save('ledger-prefix-at-update.json', prefix)
changes = []
for item in sorted(ids):
    proposals = [p['id'] for p in assignments['proposals'] if item in p['original']['row']['ledger']]
    changes.append({'id': item, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261017-084302-s2-strategy-proposal：仅复核原证据与源码/消费者边界，关联' + ','.join(proposals) +
                    '；本批各项waiting、fixes=[]、merged=null，tests均null。八流选中内容与旧同范围证据一致，不增加独立局、support/repeat或原规则。具体缺项见本批proposal.md；不改原状态/版本/shipped。'})
save('ledger-update-input.json', changes)
with (OUT / 'ledger-update-input.json').open() as stdin, (OUT / 'ledger-update.stdout.log').open('w') as stdout, (OUT / 'ledger-update.stderr.log').open('w') as stderr:
    result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'], stdin=stdin, stdout=stdout, stderr=stderr)
save('ledger-update-receipt.json', {'exit_code': result.returncode, 'entries': len(changes)})
assert result.returncode == 0

with path.open('rb') as handle:
    assert hashlib.sha256(handle.read(prefix['source_size'])).hexdigest() == prefix['sha256']
after = ledger.fold([(i, row) for i, row in ledger.read_rows(str(path)) if row and row.get('id') in ids])
protected = ['claim', 'character', 'kind', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'shipped_at', 'effect']
for item in ids:
    assert all(before[item].get(key) == after[item].get(key) for key in protected), item
    assert after[item]['history'][:len(before[item]['history'])] == before[item]['history']
    assert after[item]['notes'][:len(before[item]['notes'])] == before[item]['notes']
    for key, values in before[item]['where'].items():
        assert after[item]['where'][key][:len(values)] == values
    assert str(OUT / 'report.md') in after[item]['where']['proposal']

physical = []
with path.open('rb') as handle:
    offset = 0
    for number, raw in enumerate(handle, 1):
        row = json.loads(raw)
        if row.get('id') in ids and row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith('20261017-084302-s2-strategy-proposal：'):
            physical.append({'source': str(path), 'line': number, 'offset': offset, 'bytes': len(raw),
                             'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        offset += len(raw)
assert {row['row']['id'] for row in physical} == ids and len(physical) == 29
save('ledger-update-verification.json', {'cli_exit_code': 0, 'entries': 29,
     'protected_fields': protected, 'protected_fields_equal': True,
     'original_physical_prefix_unchanged': True, 'history_notes_where_prefix_unchanged': True,
     'physical_append_rows': physical})
print(json.dumps({'cli_exit_code': 0, 'entries': 29, 'protected_fields_equal': True,
                  'original_physical_prefix_unchanged': True}, ensure_ascii=False))

# 静默猎手本批十项策略提案处置

批次：20261017-084302-s2-strategy-proposal；base：dee5dd9ed2e2d8af33f956bcb196e70a151a3a32。只处理本批proposal_ids，无专题/implementation_request。

结论：十项保留waiting。本批无源码、知识、参数、提示词或架构更改，无提交、合入或版本。已有窄实现不当作原宽提案完成。

证据范围：10个派发锚点，加12个原提案明确引用局，均经runs.jsonl和状态character_id核Silent。A1一、A5一、A6四、A7一、A8一、A10十四分别保存；同局SL不是独立局。八流source_size、逐行offset/bytes/SHA/显式身份及计数见evidence/和provenance-verification.json。

本批没有新拟合。原日志作为发现/固定材料，未来独立Silent同进阶局才作时间外验证；材料重核不增加支持局数。日志字段/消费者验收与胜率或反事实规则验证分开。

## silent-proposal-2631859b524e0652：抑制版本与SL抽序

账本：silent-0280。来源任务：experience-update；实现任务：strategy-proposal。

证据局/层/回合：GXNKW8X1XYJP A10 F45 T2→T3，SL原行1053—1056；ZE8F192FKX24 A5 F42 T3—4为原提案首证。

支持与已核范围：四个GX记录的inserted原字段turn=2，clean为19/18/19/18；版本状态观察窗口为T2→T3，不把两种回合口径混写。战内普通版本与场外升级记录分离。当前draws.ts仍按升级键比较整堆，而不是稳定实体ID。

既有行为与预期行为：旧：普通键增长可能被记成插牌。拟议：仅在版本变化被唯一证明时配对，实际新牌、移动、洗牌和抽牌分源；歧义继续断序。

反例、未知及waiting理由：同基ID总数守恒不能证明每张牌的去向。缺纯改标瞬时帧、同ID多副本与真插牌/洗牌同帧负例，以及known-draw消费者从输入到重试的完整验证；不能仅删升级标记延长确定抽序。

验证方法：固定纯改标正例和多副本/真插牌/洗牌负例，并核clean、exact与known-draw消费者；保持其他角色和未观察组合等价。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-dampen.md；SHA256=3bd609ffdd19ea3102ba54d0d9cc52d0c59953dba5ad70fe1036f2e7570c482d；本批保存原字节副本于original-proposals/。

## silent-proposal-b13fda1dfeb37927：赢战资源与复活同盘血价

账本：silent-0019、silent-0020、silent-0079、silent-0243。来源任务：experience-update；实现任务：strategy-proposal。

证据局/层/回合：GXNKW8X1XYJP A10 F35/38/40/42/44资源链、F45第2/末试T2—T3；原提案引用的八个Silent局。

支持与已核范围：原提案的双毒/翻滚局部取舍与SL药水恢复必须分开核；本批保存GX F45全部T2/T3版本帧及七条SL摘要，没有补造缺失瞬时结算。

既有行为与预期行为：旧：已有候选预测与局部端点。拟议：赢战损血、复活、实饮、自动耗药、SL恢复逐来源关联，候选和实际分别登记。

反例、未知及waiting理由：缺复活瞬时逐击入伤、前三试退出帧和逐槽来源；局部净HP不能倒推出吞掉的原始伤害。药水时点或替路线的完整反事实也未观察，不拟统一血价。

验证方法：先验事实链接字段及同尝试边界，再分别校准真实资源路径；药水/路线规则改变另需同输入、同预算后继，不能要求反事实胜局才验日志字段。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-resources-sl.md；SHA256=04c480d08ee3896bc39bf68b6cec7a06bfc86829401ca776030a9b823c4984da；本批保存原字节副本于original-proposals/。

## silent-proposal-d7b8d36cf3d0303d：普通生存者单弃与新增凋萎

账本：silent-0268。来源任务：postmortem；实现任务：strategy-proposal。

证据局/层/回合：PD9AYQVMLQW6 A10 F49第6试T10；decisions284707—284711、states291336—291342、SL1067。

支持与已核范围：3HP/8带挡/两凋萎→防御后18挡/三凋萎→生存者选择中31挡/三凋萎→弃一后32挡/两凋萎。24持伤+23攻击−32挡=15需损，算术HP−12，实际HP0；毒250→244。

既有行为与预期行为：普通生存者单弃解耦绷带已有bf423c173d3be348a4ad714e1d26516df619ff41；唯一余牌移除，多选仍pendingSelection。拟议余项是新增凋萎实体、弃牌完成时点与终局消费者联合对照。

反例、未知及waiting理由：这是已定位的模型表示/联合校准余项，不称普通单弃尚未修。当前新增凋萎仍在终局聚合，不是可供选择的实体；本批没有完成生成/选择边界的生产回放，不能拿旧唯一余牌修复或材料算术当整项duplicate。

验证方法：固定本次32挡/24持伤/23攻击及31→32选择时点；联合回放门槛新增牌、未知选择和唯一余牌，核无绷带/有绷带及未观察组合边界。两凋萎仍致死，不能许诺转胜。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261008-071302-postmortem/proposal-survivor-discard.md；SHA256=5a1880920741718dd2508044d240ac63c67569f881689efb85ca286b4bc27909；本批保存原字节副本于original-proposals/。

## silent-proposal-c873d6543c414f92：仪式兽控制与药水执行归属

账本：silent-0125、silent-0005、silent-0044、silent-0253。来源任务：postmortem；实现任务：strategy-proposal。

证据局/层/回合：L2TSFU62Z57Z A10 F17；九条护栏决策284918/284967/284971/285020/285024/285073/285077/285126/285130。

支持与已核范围：第2试T2护栏保留；第3—6试四条T2护栏被SL覆盖。原数据分别使用sl_explore.replacement和sl_explore.replay.line，不混为同一字段。T3有抽牌重问，不能把候选扣敌0当全轮0。

既有行为与预期行为：已有silentHpGuardAudit和silentSelectionAudit记录预测阶段、请求动作并保留实际结果null；拟议完整候选父子标识、跨重问与实际饮药/SL恢复关联。

反例、未知及waiting理由：现有预测字段已覆盖一部分，旧日志没有完整跨重问父子身份及药水逐槽归属；旧离线消费者明确不认证完整候选。这里不以缺反事实胜线为新增字段的验收门槛，也不补填不存在的历史ID。

验证方法：固定第2试保留、后四次撤回、T3重问和实际药水动作的归属正反例；字段回放、自然消费者读回和打法收益分别验。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261008-074302-postmortem/proposal-control-trace.md；SHA256=6b1f8de019e4e4af3ed55d07c0b8d7ecc2902637e244b866f7c320cfa42e1a0d；本批保存原字节副本于original-proposals/。

## silent-proposal-dfbf51502f30c9b1：全败并列与昏眩单牌额度

账本：silent-0021、silent-0133、silent-0222、silent-0049、silent-0020。来源任务：postmortem；实现任务：strategy-proposal。

证据局/层/回合：L2TSFU62Z57Z A10 F17末试T6/T8；decision285148，states291780—291792。

支持与已核范围：168→159清8力及横冲直撞；T6打击/侧步候选7伤零损但五轮死14/24，结束11/24，三条整场各1200样本无赢样本且侧步未建模。T8只出一牌扣16后四牌hook阻止，17HP/0挡对17攻击死亡。

既有行为与预期行为：现有RINGING_POWER出牌上限为1。拟议仅核当轮可兑现输出、阈值、下一轮额度与尚未兑现的抽牌/能量，不新增固定优先攻击规则。

反例、未知及waiting理由：缺侧步完整后继与同预算受控候选回放；不能把当轮7伤加到实盘，不能用整场零胜覆盖五轮死亡差，不能从旧A0阈值推本局。

验证方法：同一T6原题三线核模型范围、未知牌和后继；一牌限制/药水动作另验；不改变全败排序、护栏或SL边界。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261008-074302-postmortem/proposal-ringing-terminal.md；SHA256=b05bf09cf80e5f6d21801f79db38f3853f5af4a466bb256ca139299045556282；本批保存原字节副本于original-proposals/。

## silent-proposal-c2888032d1337388：十五机制的联合消费者覆盖

账本：silent-0005、silent-0006、silent-0011、silent-0016、silent-0023、silent-0024、silent-0027、silent-0049、silent-0083、silent-0094、silent-0133、silent-0222、silent-0253、silent-0276、silent-0282。来源任务：experience-update；实现任务：strategy-proposal。

证据局/层/回合：原提案十八个Silent来源局；本批锚点PD9AYQVMLQW6 A10 F35 T3—8、F48/F49及L2TSFU62Z57Z A10 F6/F14/F17。

支持与已核范围：PD9末T10状态分别保存四敏捷、余像、带挡和凋萎；末次死亡前显示的未来能力量不等于已兑现收益。本批不将原提案全史动作统计重新记为新独立样本。

既有行为与预期行为：已有card-model/turn-solver能力与持牌结算，以及独立观察工具。拟议按各入口核现场力敏、逐牌/逐击收益和换战能力重建至同一生产消费者。

反例、未知及waiting理由：十五账本不是一个新根因bug。缺逐机制/组合输入到联合生产消费者的校准；力量对滚石、覆甲减层及换战能力边界不能凭单步端点补齐。不得以若干叶SHA或旧绿整包认证。

验证方法：每机制固定实动作前后值、来源与进阶；单步、组合、换战分别核，未知组合保持未知；缺数据不拟药价或能力时点。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-075539-experience-update/proposal-mechanisms.md；SHA256=4f60d9af2120759b9d20815cdc88450bfe5410c216bd24e834280f120742bd5c；本批保存原字节副本于original-proposals/。

## silent-proposal-042ee2299084b528：首Boss胜后的真实资源接续

账本：silent-0019、silent-0020、silent-0021、silent-0090、silent-0228、silent-0239、silent-0243。来源任务：experience-update；实现任务：strategy-proposal。

证据局/层/回合：PD9AYQVMLQW6 A10 F48→F49、L2TSFU62Z57Z A10 F14→F17；相关账本含silent-0228/0243。

支持与已核范围：PD9 F48入58、出口10，F49入口仍10；L2 F14赢战44→24。战内能力建立不等于下一战资源齐备，不能把同幕两王之间当跨幕回复。

既有行为与预期行为：same_sample连续Boss原始资源诊断已有bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07；actualSecondOpening、奖励和未观察开场效果仍unknown。拟议与真实次战及路线/休息消费者联合校准。

反例、未知及waiting理由：缺真实次战开场/奖励转移的完整模型校准及路线休息联合消费；独立四局拟合不充真实接续证据，未选路线/早喝药没有整战结果。不重拟四局参数。

验证方法：保留首战同样本实际HP/药/复活，再对真实次战入口和可观察奖励；跨幕回复与同幕接续分开，五样本房间代价门槛保持。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-075539-experience-update/proposal-resources.md；SHA256=696540b4102ca32821760af92fca2f6ec189f83b8f80e7de4bf175bb2f7d2039；本批保存原字节副本于original-proposals/。

## silent-proposal-8cd3db3bad5f34f1：有限推演与SL后的实际执行

账本：silent-0021、silent-0133、silent-0222、silent-0228、silent-0239。来源任务：experience-update；实现任务：strategy-proposal。

证据局/层/回合：PD9AYQVMLQW6 A10 F48/F49，L2TSFU62Z57Z A10 F17第2—6试T2/T3及末T6/T8。

支持与已核范围：SL可能撤回护栏，抽牌可能产生重问；四局旧离线产物的完整候选结果均保留null。观察到全轮端点不等于原候选全线执行。

既有行为与预期行为：已有选中候选、SL前后预测和observedSelectionTurns离线端点。拟议将原答、控制、重问、前缀和实线出口关联，限定样本分母。

反例、未知及waiting理由：缺原线/改线完整执行认证与同入口同预算整战后继，不能用有限全败加后续存活直接改变必死/SL规则。历史dirty运行树也未完整复原。

验证方法：先验完整候选归属正反例与缺帧边界；规则校准另核同预算后继，既不把null补零，也不把认证数0说成实际没有执行。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-075539-experience-update/proposal-sl-trace.md；SHA256=370e09576ca99e86a3a141546425e28111d2160606576aa6a4c3820cf404bfda；本批保存原字节副本于original-proposals/。

## silent-proposal-43fe170707574455：同族总血与退场进度

账本：silent-0021、silent-0012、silent-0046。来源任务：postmortem；实现任务：strategy-proposal。

证据局/层/回合：ZTRGYYMLR8SC A10 F17 T1/T5/T7/T9及末试T7—T14；states292332—292402。

支持与已核范围：首帧三敌合324、信徒合125；退场前index0尚1HP，下一帧index0变37HP/63上限，序号重排。缺帧不能生成T6精确零血时点。

既有行为与预期行为：d1713559f2d237a04b681ec6497ce0c8798ae0f0已有当前存活总血/神官血/信徒血/暂减力快照，以及本候选当前目标模型汇总；拟议余项为稳定实例、实际退场和构筑能力兑现关联。

反例、未知及waiting理由：缺稳定敌实例身份、精确退场边界及计划能力实得/已建链；现有日志的种类和index不能唯一追踪同种信徒。不能强行指定固定先杀目标。

验证方法：当前快照与预测字段先分验，再以有实例身份的日志校准退场边界和计划兑现；不以无反事实胜局阻止快照字段验收。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-combat-progress.md；SHA256=6998cd559e0899056005231af7bbadd3d271513733f6ca28a5f65638e9a9f122；本批保存原字节副本于original-proposals/。

## silent-proposal-3f5a665dca133a8c：HP护栏的局部血价与整轮结果

账本：silent-0125。来源任务：postmortem；实现任务：strategy-proposal。

证据局/层/回合：ZTRGYYMLR8SC A10 F11 T3、F17首试T10/末试T13；decisions285301/285405/285745。

支持与已核范围：三次候选损25→20、15→12、2→0；后两次预算已24、容许0。局部候选合省10/少24不是三次整场因果收益，抽牌重问后的整轮扣血另算。

既有行为与预期行为：已有护栏预测和SL前后审计；拟议补控制链、稳定方案键、实际前缀与全轮净HP/敌HP，保持8/24/0参数。

反例、未知及waiting理由：缺跨重问完整归属以及原线/替线同预算整战后继；候选省血不能直接记实得收益。无需新游戏参数，也不将符合现有护栏的行为认定纯bug。

验证方法：固定三次局部端点及重问/SL边界，模型选择、最终派发、全轮资源分别验；只由新增受控证据调整策略。

授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-guard-sl-trace.md；SHA256=223f0fdd623ff185e4b476a528e5a70a3ce5e99d5733ae5354139ffcd9ac5523；本批保存原字节副本于original-proposals/。

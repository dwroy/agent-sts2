import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BATCH = '20261017-084302-s2-strategy-proposal'
dispatch = json.loads((OUT / 'assigned-proposals.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
source = json.loads((OUT / 'source-readback.json').read_text())
material = json.loads((OUT / 'material-checks.json').read_text())
additional = json.loads((OUT / 'additional-material-checks.json').read_text())
assert material['passed'] == material['total'] == 19
assert additional['passed'] == additional['total'] == 10
reuse = json.loads((OUT / 'consumer-reuse.json').read_text())
assert reuse['input_rows_bound_to_current_evidence'] == 5548

items = [
    ('抑制版本与SL抽序',
     'GXNKW8X1XYJP A10 F45 T2→T3，SL原行1053—1056；ZE8F192FKX24 A5 F42 T3—4为原提案首证。',
     '四个GX记录的inserted原字段turn=2，clean为19/18/19/18；版本状态观察窗口为T2→T3，不把两种回合口径混写。战内普通版本与场外升级记录分离。当前draws.ts仍按升级键比较整堆，而不是稳定实体ID。',
     '旧：普通键增长可能被记成插牌。拟议：仅在版本变化被唯一证明时配对，实际新牌、移动、洗牌和抽牌分源；歧义继续断序。',
     '同基ID总数守恒不能证明每张牌的去向。缺纯改标瞬时帧、同ID多副本与真插牌/洗牌同帧负例，以及known-draw消费者从输入到重试的完整验证；不能仅删升级标记延长确定抽序。',
     '固定纯改标正例和多副本/真插牌/洗牌负例，并核clean、exact与known-draw消费者；保持其他角色和未观察组合等价。'),
    ('赢战资源与复活同盘血价',
     'GXNKW8X1XYJP A10 F35/38/40/42/44资源链、F45第2/末试T2—T3；原提案引用的八个Silent局。',
     '原提案的双毒/翻滚局部取舍与SL药水恢复必须分开核；本批保存GX F45全部T2/T3版本帧及七条SL摘要，没有补造缺失瞬时结算。',
     '旧：已有候选预测与局部端点。拟议：赢战损血、复活、实饮、自动耗药、SL恢复逐来源关联，候选和实际分别登记。',
     '缺复活瞬时逐击入伤、前三试退出帧和逐槽来源；局部净HP不能倒推出吞掉的原始伤害。药水时点或替路线的完整反事实也未观察，不拟统一血价。',
     '先验事实链接字段及同尝试边界，再分别校准真实资源路径；药水/路线规则改变另需同输入、同预算后继，不能要求反事实胜局才验日志字段。'),
    ('普通生存者单弃与新增凋萎',
     'PD9AYQVMLQW6 A10 F49第6试T10；decisions284707—284711、states291336—291342、SL1067。',
     '3HP/8带挡/两凋萎→防御后18挡/三凋萎→生存者选择中31挡/三凋萎→弃一后32挡/两凋萎。24持伤+23攻击−32挡=15需损，算术HP−12，实际HP0；毒250→244。',
     '普通生存者单弃解耦绷带已有bf423c173d3be348a4ad714e1d26516df619ff41；唯一余牌移除，多选仍pendingSelection。拟议余项是新增凋萎实体、弃牌完成时点与终局消费者联合对照。',
     '这是已定位的模型表示/联合校准余项，不称普通单弃尚未修。当前新增凋萎仍在终局聚合，不是可供选择的实体；本批没有完成生成/选择边界的生产回放，不能拿旧唯一余牌修复或材料算术当整项duplicate。',
     '固定本次32挡/24持伤/23攻击及31→32选择时点；联合回放门槛新增牌、未知选择和唯一余牌，核无绷带/有绷带及未观察组合边界。两凋萎仍致死，不能许诺转胜。'),
    ('仪式兽控制与药水执行归属',
     'L2TSFU62Z57Z A10 F17；九条护栏决策284918/284967/284971/285020/285024/285073/285077/285126/285130。',
     '第2试T2护栏保留；第3—6试四条T2护栏被SL覆盖。原数据分别使用sl_explore.replacement和sl_explore.replay.line，不混为同一字段。T3有抽牌重问，不能把候选扣敌0当全轮0。',
     '已有silentHpGuardAudit和silentSelectionAudit记录预测阶段、请求动作并保留实际结果null；拟议完整候选父子标识、跨重问与实际饮药/SL恢复关联。',
     '现有预测字段已覆盖一部分，旧日志没有完整跨重问父子身份及药水逐槽归属；旧离线消费者明确不认证完整候选。这里不以缺反事实胜线为新增字段的验收门槛，也不补填不存在的历史ID。',
     '固定第2试保留、后四次撤回、T3重问和实际药水动作的归属正反例；字段回放、自然消费者读回和打法收益分别验。'),
    ('全败并列与昏眩单牌额度',
     'L2TSFU62Z57Z A10 F17末试T6/T8；decision285148，states291780—291792。',
     '168→159清8力及横冲直撞；T6打击/侧步候选7伤零损但五轮死14/24，结束11/24，三条整场各1200样本无赢样本且侧步未建模。T8只出一牌扣16后四牌hook阻止，17HP/0挡对17攻击死亡。',
     '现有RINGING_POWER出牌上限为1。拟议仅核当轮可兑现输出、阈值、下一轮额度与尚未兑现的抽牌/能量，不新增固定优先攻击规则。',
     '缺侧步完整后继与同预算受控候选回放；不能把当轮7伤加到实盘，不能用整场零胜覆盖五轮死亡差，不能从旧A0阈值推本局。',
     '同一T6原题三线核模型范围、未知牌和后继；一牌限制/药水动作另验；不改变全败排序、护栏或SL边界。'),
    ('十五机制的联合消费者覆盖',
     '原提案十八个Silent来源局；本批锚点PD9AYQVMLQW6 A10 F35 T3—8、F48/F49及L2TSFU62Z57Z A10 F6/F14/F17。',
     'PD9末T10状态分别保存四敏捷、余像、带挡和凋萎；末次死亡前显示的未来能力量不等于已兑现收益。本批不将原提案全史动作统计重新记为新独立样本。',
     '已有card-model/turn-solver能力与持牌结算，以及独立观察工具。拟议按各入口核现场力敏、逐牌/逐击收益和换战能力重建至同一生产消费者。',
     '十五账本不是一个新根因bug。缺逐机制/组合输入到联合生产消费者的校准；力量对滚石、覆甲减层及换战能力边界不能凭单步端点补齐。不得以若干叶SHA或旧绿整包认证。',
     '每机制固定实动作前后值、来源与进阶；单步、组合、换战分别核，未知组合保持未知；缺数据不拟药价或能力时点。'),
    ('首Boss胜后的真实资源接续',
     'PD9AYQVMLQW6 A10 F48→F49、L2TSFU62Z57Z A10 F14→F17；相关账本含silent-0228/0243。',
     'PD9 F48入58、出口10，F49入口仍10；L2 F14赢战44→24。战内能力建立不等于下一战资源齐备，不能把同幕两王之间当跨幕回复。',
     'same_sample连续Boss原始资源诊断已有bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07；actualSecondOpening、奖励和未观察开场效果仍unknown。拟议与真实次战及路线/休息消费者联合校准。',
     '缺真实次战开场/奖励转移的完整模型校准及路线休息联合消费；独立四局拟合不充真实接续证据，未选路线/早喝药没有整战结果。不重拟四局参数。',
     '保留首战同样本实际HP/药/复活，再对真实次战入口和可观察奖励；跨幕回复与同幕接续分开，五样本房间代价门槛保持。'),
    ('有限推演与SL后的实际执行',
     'PD9AYQVMLQW6 A10 F48/F49，L2TSFU62Z57Z A10 F17第2—6试T2/T3及末T6/T8。',
     'SL可能撤回护栏，抽牌可能产生重问；四局旧离线产物的完整候选结果均保留null。观察到全轮端点不等于原候选全线执行。',
     '已有选中候选、SL前后预测和observedSelectionTurns离线端点。拟议将原答、控制、重问、前缀和实线出口关联，限定样本分母。',
     '缺原线/改线完整执行认证与同入口同预算整战后继，不能用有限全败加后续存活直接改变必死/SL规则。历史dirty运行树也未完整复原。',
     '先验完整候选归属正反例与缺帧边界；规则校准另核同预算后继，既不把null补零，也不把认证数0说成实际没有执行。'),
    ('同族总血与退场进度',
     'ZTRGYYMLR8SC A10 F17 T1/T5/T7/T9及末试T7—T14；states292332—292402。',
     '首帧三敌合324、信徒合125；退场前index0尚1HP，下一帧index0变37HP/63上限，序号重排。缺帧不能生成T6精确零血时点。',
     'd1713559f2d237a04b681ec6497ce0c8798ae0f0已有当前存活总血/神官血/信徒血/暂减力快照，以及本候选当前目标模型汇总；拟议余项为稳定实例、实际退场和构筑能力兑现关联。',
     '缺稳定敌实例身份、精确退场边界及计划能力实得/已建链；现有日志的种类和index不能唯一追踪同种信徒。不能强行指定固定先杀目标。',
     '当前快照与预测字段先分验，再以有实例身份的日志校准退场边界和计划兑现；不以无反事实胜局阻止快照字段验收。'),
    ('HP护栏的局部血价与整轮结果',
     'ZTRGYYMLR8SC A10 F11 T3、F17首试T10/末试T13；decisions285301/285405/285745。',
     '三次候选损25→20、15→12、2→0；后两次预算已24、容许0。局部候选合省10/少24不是三次整场因果收益，抽牌重问后的整轮扣血另算。',
     '已有护栏预测和SL前后审计；拟议补控制链、稳定方案键、实际前缀与全轮净HP/敌HP，保持8/24/0参数。',
     '缺跨重问完整归属以及原线/替线同预算整战后继；候选省血不能直接记实得收益。无需新游戏参数，也不将符合现有护栏的行为认定纯bug。',
     '固定三次局部端点及重问/SL边界，模型选择、最终派发、全轮资源分别验；只由新增受控证据调整策略。'),
]
assert len(items) == len(dispatch['proposals']) == 10
proposal_results = []
text = ['# 静默猎手本批十项策略提案处置', '',
        f'批次：{BATCH}；base：{base}。只处理本批proposal_ids，无专题/implementation_request。', '',
        '结论：十项保留waiting。本批无源码、知识、参数、提示词或架构更改，无提交、合入或版本。已有窄实现不当作原宽提案完成。', '',
        '证据范围：10个派发锚点，加12个原提案明确引用局，均经runs.jsonl和状态character_id核Silent。A1一、A5一、A6四、A7一、A8一、A10十四分别保存；同局SL不是独立局。八流source_size、逐行offset/bytes/SHA/显式身份及计数见evidence/和provenance-verification.json。', '',
        '本批没有新拟合。原日志作为发现/固定材料，未来独立Silent同进阶局才作时间外验证；材料重核不增加支持局数。日志字段/消费者验收与胜率或反事实规则验证分开。', '']
original_dir = OUT / 'original-proposals'
original_dir.mkdir(exist_ok=True)
for assigned, item in zip(dispatch['proposals'], items):
    title, evidence, support, behavior, reason, validation = item
    original = assigned['original']['row']
    raw = Path(original['proposal']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == original['proposal_sha256']
    (original_dir / (assigned['id'] + '.md')).write_bytes(raw)
    proposal_results.append({'id': assigned['id'], 'state': 'waiting', 'reason': reason})
    text.extend([f'## {assigned["id"]}：{title}', '',
        '账本：' + '、'.join(original['ledger']) + '。来源任务：' + original['source_task'] + '；实现任务：strategy-proposal。', '',
        f'证据局/层/回合：{evidence}', '', f'支持与已核范围：{support}', '',
        f'既有行为与预期行为：{behavior}', '', f'反例、未知及waiting理由：{reason}', '',
        f'验证方法：{validation}', '',
        '授权：Roy-2026-10-07-learning仅授权改规则，不提供游戏事实。回退：本批无代码可回退；后续实现逐项独立逆向源码净补丁，保留原日志、提案、账本、知识刷新与并行记录。', '',
        f'原Markdown：{original["proposal"]}；SHA256={original["proposal_sha256"]}；本批保存原字节副本于original-proposals/。', ''])
(OUT / 'proposal.md').write_text('\n'.join(text))
(OUT / 'proposal-results.json').write_text(json.dumps(proposal_results, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': base,
          'runs': dispatch['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [x['id'] for x in dispatch['proposals']], 'implementation_domains': [],
          'proposal_results': proposal_results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
report = f'''# 静默猎手策略批次回报

批次：{BATCH}；base={base}。开工tracked/index干净，普通派发10个proposal_ids的角色、工作树、锚点均匹配；无research_request或implementation_request。根deck-size请求属于20261010旧专题，未借用其输入或改本批范围。git merge --no-edit main返回Already up to date。

十项全部waiting，完整逐项证据局号/层/回合、29个既有账本、旧/预期行为、反例、具体缺项、验证及回退见proposal.md和proposal-results.json。fixes=[]、merged=null；无源码/知识提交、待合补丁、游戏版本或规则双通知，未关闭任何父学习要求。原十份Markdown SHA全部匹配并保存原字节副本，没有重复提案id。

## 本角色证据与结论

22个已核Silent局：10个派发锚点、12个原提案补充局；A1一/A5一/A6四/A7一/A8一/A10十四，不混进阶、不把SL当独立局。八流共38759行逐offset/bytes/SHA/JSON/显式身份核；source_size与逐局计数在evidence/evidence-manifest.json。各流分别冻结，非跨流同时快照；整源invalid计数保留，fight-plans选中0只表示该截点未选中。八流选中SHA及计数与004303-s2同范围产物相同，较新全源截点不增加本提案证据。旧run-plans的8676775字节截点另存共用入口重提，154行同SHA，不覆盖旧文件/零行初稿。

PD9末T10由31挡/三凋萎选择中变32挡/两凋萎，24持伤+23攻击−32挡需损15，3HP仍死，毒250→244；不能将持牌伤12差当实际多扣12或修后可赢。普通单弃已修，新增凋萎实体/完成时点的联合校准余项明确保存，不以证据不足掩盖已知模型表示缺口。

L2末T6七伤线五轮死亡14/24而结束11/24，三条整场各1200样本无赢样本、侧步未建模；末T8一牌后四牌hook阻止，17HP对17攻击实死。九条护栏中的四条T2被SL覆盖，explore和replay两种结构分别核。GX四个SL记录的inserted原字段turn=2（clean19/18/19/18）与状态T2→T3战内改标窗口分列，总数守恒不证明抽序。初次材料检查误假定inserted.turn=3而失败，失败原件保留、读回原字段后更正，不作机制反例。ZTR起点总敌血324，退场后index重排，局部护栏省血与全轮净变化分开。共19项原材料检查加10项更正后补充检查通过，仅为固定材料事实/算术核验，生产tests仍null。

## 已有源码与消费者边界

只读live快照={source['live']}。19叶源码中16叶同004303-s2基准，3叶差分仅现有紧勒升级后继与计算下注接线；均保存精确diff，不当本批新增实现或整个历史dirty运行树。17叶同live，card-model.ts/draws.ts两叶差异仅历史Roy/Dai署名注释，原补丁保留。八个既有窄源码提交均为本base与该live真实祖先，列表在ancestor-checks.json：普通生存者单弃、护栏预测、同族当前快照、same_sample连续Boss资源诊断等各限原范围，不关闭全部宽提案。

四局旧离线消费者12个输入/输出/stderr逐SHA和大小核，六个递归依赖闭包同字节；5548条输入状态/带ID决策逐行绑定本批新提取封套（2852状态、2696有ID动作，另6条无ID元数据原样排除）。本批只读复用，不重跑消费者、模型或模拟。重计488片段、462轮窗，其中209 observed_turn_endpoints、253 unknown；完整候选结果保持null，认证数0不等于实盘没有执行候选，也不能据observed/completed补原线因果收益。

十项余缺分为：版本/实例消歧；复活与药槽来源；生成凋萎和选择完成时点；跨重问候选归属；未执行后继及终局比较；十五机制联合生产校准；真实次王/路线休息资源；有限推演对应实线认证；稳定敌实例与构筑兑现；护栏整轮控制链。已可验证的预测/快照字段与仍需数据的规则分开，没有因为缺反事实胜线而拒验日志字段。没有从本批派发锚点之外另选新题。

## 记录与验证

本批只经根learner/ledger.py update为29个原条目追加where/note追溯，by=learner:strategy-proposal；不新增support/repeat，不改原claim/首证/prior/evidence/status/version/effect/shipped，不把原shipped重置为proposed。CLI输入/输出、前缀与字段保护核验保存在本批scratch；最终以ledger-update-verification.json为准。专用提案队列状态交回原调度处理，本批不手改或重复add。

没有源码改动，撤源码失败/恢复通过、tsc/vitest/cases均null；未运行生产测试、提交前gitleaks、提交、合入或编号，不借旧批次绿充本批结果。HEAD保持完整base，最终tracked/index/源码/知识零差异以final-readback.json为准。研究过程脚本和材料均在本批忽略目录，临时源码diff用.patch，未造可执行.ts副本。

未派子agent，不运行play、不联网、不推送、不安装依赖、不读key/.env或游戏二进制。未改变其他角色行为、运维prompt或模型配置；本批原生模型/推理强度及服务档若无独立原生回执则保留未核，不把任务文字当切换证明。历史局的大脑来源不由ds兼容字段倒写。未得新科学反证或与旧知识冲突，不新增重复通知或代他人确认。中间探测/脚本错误与更正保留在diagnostic-notes.md，不作机制反例或生产失败。

报告和proposal.md交原调度/运维验收；不冒称经验已新入库、大脑已采用、源码implemented或账本shipped。
'''
(OUT / 'report.md').write_text(report)
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal_count': len(proposal_results),
                  'base': base, 'source_changes': 0}, ensure_ascii=False))

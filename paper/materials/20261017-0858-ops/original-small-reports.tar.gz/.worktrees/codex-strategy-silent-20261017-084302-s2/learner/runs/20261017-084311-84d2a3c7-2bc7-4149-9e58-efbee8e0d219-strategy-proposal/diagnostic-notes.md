# 本批过程探测与更正

- 初次派发行读取器只匹配值，未匹配batch字典键，未输出本批；随后按batches的精确键只读匹配，十个ID/角色/路径均核。一次以工作树相对路径找根ops回执目录报不存在；已改查根目录。本批普通队列无专题/实现回执要求，不据此称证据缺失。
- 初次私有账本折叠器复用了原add对象，导致内存内的references.row跟随折叠被改。根账本未写。两份初稿以ledger-references.initial.json、ledger-fold.initial.json保留；随后重新读原物理字节、深拷贝并使用官方ledger.fold，生成ledger-references.json和ledger-before.json。没有据错误初稿更改游戏结论。
- 初次SL补充材料读取假定所有sl_explore都有replacement，实际重放使用replay.line，触发KeyError。原错误输出保存在initial-inline-readback-error.txt；随后按两种原结构读取。
- 初次GX材料断言把版本观察窗口T2→T3误写为inserted.turn=3，实际四条原记录1053—1056均turn=2、clean=19/18/19/18。更正为精确原字段并保留四个指定卡ID；没有推断两个回合口径的隐含因果。初次脚本、9/10失败结果、stderr、空GX产物均以initial-turn-assumption.txt材料后缀保存。报告生成器当时拒绝9/10输入，原拒绝另存initial-report-generation-error.txt。更正后补充材料10/10，只是材料核验，不是生产测试；不覆写原提案或旧报告。
- 首次完整账本/evidence信息的终端输出过大而被工具截断；实际文件原件完整保留，后续只输出所需摘要。截断不作为日志或知识缺失的证据。
- 根learn行的pid在本沙箱进程视图中没有可见ps/子进程结果；没有据此宣称宿主/模型已停或换档。原生模型、推理强度与服务档未得到独立回执，不写成已核。
- 本批没有生产代码或策略更改，无生产测试/源码撤回测试/提交/合入失败。上述材料探测失败与更正不当作游戏机制反例，不借更正后的材料通过冒称tsc/vitest通过。

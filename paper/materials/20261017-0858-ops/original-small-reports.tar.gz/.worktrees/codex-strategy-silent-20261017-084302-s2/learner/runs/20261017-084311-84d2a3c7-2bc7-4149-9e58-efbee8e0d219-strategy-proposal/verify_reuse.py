import collections
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-004303-s2/learner/runs/20261017-004316-d4513542-99d9-4a69-99a7-da1bd74324a2-strategy-proposal')


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def canonical(row):
    return hashlib.sha256(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
old_manifest = {x['stream']: x for x in json.loads((OLD / 'evidence/evidence-manifest.json').read_text())}
comparison = []
for entry in manifest:
    old = old_manifest[entry['stream']]
    same = entry['output_sha256'] == old['output_sha256'] and entry['counts'] == old['counts']
    comparison.append({'stream': entry['stream'], 'same_selected_sha_and_counts': same,
                       'source_size': entry['source_size'], 'old_source_size': old['source_size'],
                       'selected_lines': sum(entry['counts'].values())})
    assert same
save('evidence-comparison.json', comparison)
cutoff = json.loads((OUT / 'old-runplans-cutoff/evidence-manifest.json').read_text())[0]
assert cutoff['output_sha256'] == old_manifest['run-plans']['output_sha256']
assert cutoff['counts'] == old_manifest['run-plans']['counts']
save('old-runplans-cutoff-check.json', {'source_size': cutoff['source_size'],
     'selected_lines': sum(cutoff['counts'].values()), 'same_old_selected_sha_and_counts': True})

reuse = json.loads((OLD / 'consumer-reuse.json').read_text())
closure = set()


def dependencies(relative):
    if relative in closure:
        return
    closure.add(relative)
    source = ROOT / relative
    for name in re.findall(r'from\s+["\'](\.[^"\']+)["\']', source.read_text()):
        path = source.parent / name
        if path.suffix == '.js':
            path = path.with_suffix('.ts')
        dependencies(str(path.resolve().relative_to(ROOT.resolve())))


dependencies('learner/audit-selection.ts')
assert closure == {x['path'] for x in reuse['dependency_closure']}
for dependency in reuse['dependency_closure']:
    assert digest(ROOT / dependency['path']) == dependency['sha256']

expected = {}
summaries = []
artifacts = []
for run in reuse['runs']:
    for artifact in run['artifacts']:
        path = Path(artifact['path'])
        assert path.stat().st_size == artifact['bytes']
        assert digest(path) == artifact['sha256']
        artifacts.append({**artifact, 'verified': True})
    inp = next(Path(x['path']) for x in run['artifacts'] if '.input.' in x['path'])
    data = json.loads(inp.read_text())
    assert data['run']['run_id'] == run['run_id']
    assert data['run']['character'].lower() == 'silent' and data['run']['ascension'] == 10
    for stream in ['states', 'decisions']:
        for original in data[stream]:
            row = dict(original)
            line = row.pop('_line')
            expected[(stream, line)] = (run['run_id'], canonical(row))
    del data
    outp = next(Path(x['path']) for x in run['artifacts'] if '.output.' in x['path'])
    output = json.loads(outp.read_text())
    assert output['run_id'] == run['run_id']
    summaries.append({'run_id': run['run_id'], 'segments': len(output['segments']),
                      'observed_actions': len(output['observed_actions']),
                      'turn_windows': len(output['observed_turns']),
                      'turn_statuses': dict(collections.Counter(x['status'] for x in output['observed_turns'])),
                      'certified_full_candidates': sum(x['actual_full_candidate_result'] is not None for x in output['segments'])})
    del output

seen = set()
for stream in ['states', 'decisions']:
    with (OUT / 'evidence' / (stream + '.evidence.jsonl')).open() as handle:
        for raw in handle:
            entry = json.loads(raw)
            key = (stream, entry['line'])
            if key in expected:
                assert expected[key] == (entry['run_id'], canonical(entry['row']))
                seen.add(key)
assert seen == set(expected)
save('consumer-reuse.json', {'source_receipt': str(OLD / 'consumer-reuse.json'),
     'dependency_closure': reuse['dependency_closure'], 'verified_artifacts': artifacts,
     'input_rows_bound_to_current_evidence': len(seen), 'runs': summaries,
     'scope': '只读复用旧离线产物；本批没有执行消费者、模型或模拟，不计生产测试。'})
total = {key: sum(x[key] for x in summaries) for key in ['segments', 'observed_actions', 'turn_windows', 'certified_full_candidates']}
total['observed_turn_endpoints'] = sum(x['turn_statuses'].get('observed_turn_endpoints', 0) for x in summaries)
total['unknown_turn_windows'] = sum(x['turn_statuses'].get('unknown', 0) for x in summaries)
save('consumer-readback-counts.json', {'runs': summaries, 'total': total,
     'limitation': '完整候选结果的null来自原消费者契约，不解释为实盘未执行候选；不能将观察端点当原候选因果收益。'})
print(json.dumps({'same_streams': len(comparison), 'verified_artifacts': len(artifacts),
                  'dependency_modules': len(closure), 'bound_input_rows': len(seen), 'totals': total}, ensure_ascii=False))

# 静默猎手策略批次回报

批次：20261017-084302-s2-strategy-proposal；base=dee5dd9ed2e2d8af33f956bcb196e70a151a3a32。开工tracked/index干净，普通派发10个proposal_ids的角色、工作树、锚点均匹配；无research_request或implementation_request。根deck-size请求属于20261010旧专题，未借用其输入或改本批范围。git merge --no-edit main返回Already up to date。

十项全部waiting，完整逐项证据局号/层/回合、29个既有账本、旧/预期行为、反例、具体缺项、验证及回退见proposal.md和proposal-results.json。fixes=[]、merged=null；无源码/知识提交、待合补丁、游戏版本或规则双通知，未关闭任何父学习要求。原十份Markdown SHA全部匹配并保存原字节副本，没有重复提案id。

## 本角色证据与结论

22个已核Silent局：10个派发锚点、12个原提案补充局；A1一/A5一/A6四/A7一/A8一/A10十四，不混进阶、不把SL当独立局。八流共38759行逐offset/bytes/SHA/JSON/显式身份核；source_size与逐局计数在evidence/evidence-manifest.json。各流分别冻结，非跨流同时快照；整源invalid计数保留，fight-plans选中0只表示该截点未选中。八流选中SHA及计数与004303-s2同范围产物相同，较新全源截点不增加本提案证据。旧run-plans的8676775字节截点另存共用入口重提，154行同SHA，不覆盖旧文件/零行初稿。

PD9末T10由31挡/三凋萎选择中变32挡/两凋萎，24持伤+23攻击−32挡需损15，3HP仍死，毒250→244；不能将持牌伤12差当实际多扣12或修后可赢。普通单弃已修，新增凋萎实体/完成时点的联合校准余项明确保存，不以证据不足掩盖已知模型表示缺口。

L2末T6七伤线五轮死亡14/24而结束11/24，三条整场各1200样本无赢样本、侧步未建模；末T8一牌后四牌hook阻止，17HP对17攻击实死。九条护栏中的四条T2被SL覆盖，explore和replay两种结构分别核。GX四个SL记录的inserted原字段turn=2（clean19/18/19/18）与状态T2→T3战内改标窗口分列，总数守恒不证明抽序。初次材料检查误假定inserted.turn=3而失败，失败原件保留、读回原字段后更正，不作机制反例。ZTR起点总敌血324，退场后index重排，局部护栏省血与全轮净变化分开。共19项原材料检查加10项更正后补充检查通过，仅为固定材料事实/算术核验，生产tests仍null。

## 已有源码与消费者边界

只读live快照=99737be9fdb9c2ea92089d768947c49b49b62382。19叶源码中16叶同004303-s2基准，3叶差分仅现有紧勒升级后继与计算下注接线；均保存精确diff，不当本批新增实现或整个历史dirty运行树。17叶同live，card-model.ts/draws.ts两叶差异仅历史Roy/Dai署名注释，原补丁保留。八个既有窄源码提交均为本base与该live真实祖先，列表在ancestor-checks.json：普通生存者单弃、护栏预测、同族当前快照、same_sample连续Boss资源诊断等各限原范围，不关闭全部宽提案。

四局旧离线消费者12个输入/输出/stderr逐SHA和大小核，六个递归依赖闭包同字节；5548条输入状态/带ID决策逐行绑定本批新提取封套（2852状态、2696有ID动作，另6条无ID元数据原样排除）。本批只读复用，不重跑消费者、模型或模拟。重计488片段、462轮窗，其中209 observed_turn_endpoints、253 unknown；完整候选结果保持null，认证数0不等于实盘没有执行候选，也不能据observed/completed补原线因果收益。

十项余缺分为：版本/实例消歧；复活与药槽来源；生成凋萎和选择完成时点；跨重问候选归属；未执行后继及终局比较；十五机制联合生产校准；真实次王/路线休息资源；有限推演对应实线认证；稳定敌实例与构筑兑现；护栏整轮控制链。已可验证的预测/快照字段与仍需数据的规则分开，没有因为缺反事实胜线而拒验日志字段。没有从本批派发锚点之外另选新题。

## 记录与验证

本批只经根learner/ledger.py update为29个原条目追加where/note追溯，by=learner:strategy-proposal；不新增support/repeat，不改原claim/首证/prior/evidence/status/version/effect/shipped，不把原shipped重置为proposed。CLI输入/输出、前缀与字段保护核验保存在本批scratch；最终以ledger-update-verification.json为准。专用提案队列状态交回原调度处理，本批不手改或重复add。

没有源码改动，撤源码失败/恢复通过、tsc/vitest/cases均null；未运行生产测试、提交前gitleaks、提交、合入或编号，不借旧批次绿充本批结果。HEAD保持完整base，最终tracked/index/源码/知识零差异以final-readback.json为准。研究过程脚本和材料均在本批忽略目录，临时源码diff用.patch，未造可执行.ts副本。

未派子agent，不运行play、不联网、不推送、不安装依赖、不读key/.env或游戏二进制。未改变其他角色行为、运维prompt或模型配置；本批原生模型/推理强度及服务档若无独立原生回执则保留未核，不把任务文字当切换证明。历史局的大脑来源不由ds兼容字段倒写。未得新科学反证或与旧知识冲突，不新增重复通知或代他人确认。中间探测/脚本错误与更正保留在diagnostic-notes.md，不作机制反例或生产失败。

报告和proposal.md交原调度/运维验收；不冒称经验已新入库、大脑已采用、源码implemented或账本shipped。

最终验收：根账本CLI退出0，29个原条目的保护字段与物理前缀/历史前缀保持；修正后的13253条原账本引用逐offset/bytes/SHA/JSON回读通过。HEAD仍为完整base，tracked/index/源码/知识干净。本批产物及失败初稿见artifact-index.json，交原调度接续waiting，不冒称上线。

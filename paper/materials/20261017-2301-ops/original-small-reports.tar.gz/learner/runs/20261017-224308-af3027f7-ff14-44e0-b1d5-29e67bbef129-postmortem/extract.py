import json, subprocess, hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261017-224308-af3027f7-ff14-44e0-b1d5-29e67bbef129-postmortem'
run='75DAD6GBWEU1'
for name in ['runs','decisions','run-plans','states','sl-attempts','brain','fight-plans','run-config','human-pace-shadow']:
    path=root/'logs'/f'{name}.jsonl'
    process=subprocess.Popen(['rg','-n','-b','-F',run,str(path)],stdout=subprocess.PIPE)
    count=0
    with (out/f'{name}.jsonl').open('w') as target:
        for raw in process.stdout:
            number,offset,line=raw.split(b':',2)
            row=json.loads(line)
            target.write(json.dumps({'line':int(number),'offset':int(offset),'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'row':row},ensure_ascii=False)+'\n')
            count+=1
    code=process.wait()
    print(name,count,'rg_rc',code,flush=True)

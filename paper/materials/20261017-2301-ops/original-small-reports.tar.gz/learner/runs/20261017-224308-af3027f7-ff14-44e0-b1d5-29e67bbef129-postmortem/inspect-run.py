import json, collections
from pathlib import Path
p=Path(__file__).parent
def read(n): return [json.loads(x) for x in (p/f'{n}.jsonl').open()]
ds=read('decisions'); ss=read('states')
print('WINDOW',ds[0]['row']['ts'],ds[-1]['row']['ts'])
print('DECISION_SAMPLE',json.dumps(ds[0],ensure_ascii=False)[:2800])
print('STATE_SAMPLE',json.dumps(ss[-2],ensure_ascii=False)[:5500])
for n in ['run-config','run-plans','sl-attempts']:
 print('\nFILE',n)
 if not (p/f'{n}.jsonl').exists():continue
 for x in read(n): print(x['line'],json.dumps(x['row'],ensure_ascii=False)[:6500])
print('\nNONCOMBAT')
for x in ds:
 d=x['row']
 if not str(d['label']).startswith(('combat/','selection/choose','reward/claim','reward/proceed','map/route-follow')):
  print(x['line'],d.get('floor'),d['label'],json.dumps({k:d.get(k) for k in ['chosen','rationale','journal']},ensure_ascii=False)[:2200])
print('\nKEYCOMBAT')
for x in ds:
 d=x['row']
 if d.get('floor',0)>=33:
  print(x['line'],d.get('floor'),d.get('turn'),d['label'],d.get('decider'),d.get('chosen'),d.get('rationale'))

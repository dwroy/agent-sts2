import json,hashlib,re,collections
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2')
def rows(name):return [json.loads(l) for l in (p/f'{name}.jsonl').open()]
checked={}
for name in ['runs','decisions','states','sl-attempts','run-plans','brain','run-config','human-pace-shadow','fight-plans']:
 n=0
 with (root/'logs'/f'{name}.jsonl').open('rb') as src:
  for x in rows(name):
   src.seek(x['offset']);raw=src.read(x['bytes']);assert hashlib.sha256(raw).hexdigest()==x['sha256'],(name,x['line']);assert json.loads(raw)==x['row'];n+=1
 checked[name]=n
ss={x['line']:x['row']['state'] for x in rows('states')};ds={x['line']:x['row'] for x in rows('decisions')}
h=lambda line:(ss[line]['run']['current_hp'],ss[line]['run']['max_hp'])
for line,value in {440679:(7,70),440680:(28,70),440682:(53,70),440731:(2,70),440736:(56,70),440739:(56,70),440768:(22,70),440784:(22,70),440811:(4,62),440816:(4,62),440867:(4,62),440878:(2,62),440883:(2,62),440884:(0,62)}.items():assert h(line)==value,(line,h(line),value)
last=ss[440883]['combat'];assert last['player']['block']==14
assert [sum(v.get('total_damage') or 0 for v in e['intents']) for e in last['enemies']]==[16,12,12]
assert [e['current_hp'] for e in ss[440884]['combat']['enemies']]==[31,40,70]
g=ds[426141]['hp_guard'];assert (g['before_guard']['hp_lost'],g['after_guard']['hp_lost'],g['before_guard']['damage_dealt'],g['after_guard']['damage_dealt'])==(18,0,48,12)
assert sum('HP guard:' in d.get('rationale','') for d in ds.values())==1
jev=[d for d in ds.values() if d['decider']=='jev'];assert len(jev)==191
assert sum(isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35 for d in jev)==28
plans=[d for d in jev if d['label'].startswith('combat/plan-choice')];assert len(plans)==144
assert collections.Counter(str(d.get('rollout_best_chosen')) for d in plans)=={'True':130,'False':5,'None':9}
assert sum(d.get('chosen',{}).get('action')=='use_potion' for d in ds.values())==14
assert not any(d.get('chosen',{}).get('action')=='discard_potion' for d in ds.values())
assert len(rows('sl-attempts'))==9
r=json.load((p/'75DAD6GBWEU1-resources.json').open());assert len(r['combats'])==24;assert all(c['entry_is_turn_one'] for c in r['combats'])
for c in r['combats']:
 for point in [c['entry'],c['exit'] or c['last']]:assert h(point['line'])==(point['hp'],point['max_hp'])
section=(p/'lesson-section.md').read_text();assert len(re.findall(r'^- \[(?!记录)',section,re.M))==3
for needle in ['四试均4/62','完整需损26','至少差25血','53/70→2/70','56/70→22/70','22/70→4/62','每轮实盘','130/135＝96.30%','机制：']:
 assert needle in section,needle
lesson=root/'notes/lessons.md';matches=[]
with lesson.open() as f:
 for number,line in enumerate(f,1):
  if line.startswith('## 75DAD6GBWEU1'):matches.append(number)
assert len(matches)<=1
result={'原件逐字节校验':checked,'关键数字核验':'通过','复盘标题行':matches,'资源窗口':24,'说明':'候选与实际、SL恢复与治疗、净推进与逐击毛伤分列；未知未补值'}
(p/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

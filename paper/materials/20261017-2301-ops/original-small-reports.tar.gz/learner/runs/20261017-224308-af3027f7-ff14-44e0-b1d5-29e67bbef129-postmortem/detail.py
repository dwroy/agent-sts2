import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
def read(n):return [json.loads(x) for x in (p/f'{n}.jsonl').open()]
ds=read('decisions'); ss=read('states')
print('DSKEYS',ds[2]['row'].keys())
for x in ds:
 d=x['row']
 if (d.get('floor')==29 and d.get('turn')==1) or x['line']==426141:
  print('D',x['line'],d['label'],d['rationale'],d.get('chosen'))
  q=d.get('questions') or {}; print('QKEYS',[(k,list(v.keys()) if isinstance(v,dict) else type(v).__name__) for k,v in q.items()])
  for k,v in q.items():
   if isinstance(v,dict):
    print('FACTKEYS',list((v.get('facts') or {}).keys()))
    print('OPTIONS',json.dumps(v.get('options'),ensure_ascii=False)[:9000])
print('SKEY29')
for x in ss:
 s=x['row']['state'];f=s.get('run',{}).get('floor')
 if f==29 and s.get('in_combat') and s.get('turn') in [1,2]:
  c=s['combat'];print(x['line'],s.get('turn'),s['run']['current_hp'],'block',c['player']['block'],'E',c['player']['energy'],'powers',c['player']['powers'],'hand',[(a['card_id'],a['name']) for a in c['hand']],'enemies',[(a['enemy_id'],a['current_hp'],a.get('powers'),a.get('intents')) for a in c['enemies']])
print('BRAINS',collections.Counter((x['row']['engine'],x['row']['model'],x['row']['effort'],x['row']['accepted']) for x in read('brain')))
print('USAGE',read('brain')[0]['row']['usage'])
print('DSUSAGE',next(d['row']['usage'] for d in ds if d['row'].get('usage')))
print('LAST37')
for x in ss[-19:]:
 s=x['row']['state'];c=s.get('combat') or {};print(x['line'],s['screen'],s.get('turn'),s['run']['current_hp'],s['run']['max_hp'],(c.get('player') or {}).get('block'),[(a['enemy_id'],a['current_hp'],[(z['power_id'],z['amount']) for z in a.get('powers',[])]) for a in c.get('enemies',[])])

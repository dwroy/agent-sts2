import json, collections
from pathlib import Path
p=Path(__file__).parent
def read(n):return [json.loads(x) for x in (p/f'{n}.jsonl').open()]
ds=read('decisions');ss=read('states');r=json.load((p/'75DAD6GBWEU1-resources.json').open())
for c in r['combats']:
 e=c['entry'];z=c['exit'] or c['last']
 print('C',c['sequence'],c['floor'],','.join(c['enemies']),f"{e['hp']}/{e['max_hp']}->{z['hp']}/{z['max_hp']}",e['potions'],'->',z['potions'],c['end'],f"s{e['line']}->{z['line']}",e['ts'],z['ts'])
print('SL')
for x in read('sl-attempts'):
 d=x['row'];print(x['line'],d['floor'],d['attempt'],d['result'],d.get('turns'),d.get('end_hp'),d.get('end_block'),d.get('incoming'),d.get('started_at'),d.get('ended_at'))
print('PLANS')
for x in read('run-plans'):
 d=x['row'];print(x['line'],d['floor'],json.dumps(d.get('plan', {k:v for k,v in d.items() if k not in ('question','raw')}),ensure_ascii=False))
print('BRAIN_KEYS',read('brain')[0]['row'].keys())
print('JOURNAL_KEYS')
for x in ds:
 d=x['row']
 if d.get('journal') and d['label'].startswith('combat/plan-choice'):
  print(x['line'],d['journal'].keys(),json.dumps(d['journal'],ensure_ascii=False)[:1700]);break
print('GUARDS')
for x in ds:
 d=x['row']
 if any(a in str(d.get('rationale','')).lower() for a in ['guard','护栏','sl explor','sl replay']):
  print(x['line'],d.get('floor'),d.get('turn'),d['label'],d['rationale']);print(json.dumps(d.get('journal'),ensure_ascii=False)[:2500])
print('NONCOMBAT')
for x in ds:
 d=x['row']
 if d.get('decider')=='codex' or d['label'].startswith('rest/'):
  print(x['line'],d.get('floor'),d['label'],d.get('chosen'),d.get('rationale'))

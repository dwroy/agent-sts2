import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
def read(n):return [json.loads(x) for x in (p/f'{n}.jsonl').open()]
ds=read('decisions');ss=read('states');r=json.load((p/'75DAD6GBWEU1-resources.json').open())
def opts(d):
 out={}
 for q in d.get('questions',{}).values():
  for k,v in q.get('criteria',{}).items():
   if isinstance(v,str):
    try:v=json.loads(v)
    except ValueError:continue
   out[k]=v
 return out
print('COMBAT_OPTIONS')
for x in ds:
 d=x['row']
 if x['line'] in [426020,426022,426141,426268,426269,426287,426288]:
  print('D',x['line'],'BOSS',[(k,{z:v.get(z) for z in ['win_rate','winRate','samples','death_rate']}) for k,v in (d.get('boss_sim') or {}).get('lines',{}).items()])
  for k,v in opts(d).items():
   print(k,{z:v.get(z) for z in ['plays','damage_dealt','hp_lost','block_gained','hp_after','scaling_gained','rollout','rollout_best_chosen','hp_guard','focus'] if z in v})
  print('OTHER', {k:d[k] for k in d if 'rollout' in k or 'guard' in k})
print('POTIONS')
for x in ds:
 d=x['row'];a=d.get('chosen') or {}
 if a.get('action') in ['use_potion','discard_potion','buy_potion','claim_reward'] and ('potion' in str(a).lower() or '药' in str(d.get('rationale'))):
  print(x['line'],d['floor'],d.get('turn'),a,d['rationale'])
print('RESOURCE_CHANGES')
for e in r['resource_changes']:
 a,b=e['from'],e['to']
 if e['combat_sequence'] is None or a['potions']!=b['potions']:
  print(f"s{a['line']}->{b['line']}",f"F{a['floor']}->{b['floor']}",b['turn'],f"{a['hp']}/{a['max_hp']}->{b['hp']}/{b['max_hp']}",a['potions'],'->',b['potions'],'SL',e['restart_boundary'])
print('TURNS')
for c in r['combats']:
 if c['floor']<29:continue
 rows=[x for x in ss if c['entry']['line']<=x['line']<=(c['exit'] or c['last'])['line']]
 turns={}
 for x in rows:
  s=x['row']['state']
  if s.get('in_combat') and s.get('combat',{}).get('enemies'):
   turns.setdefault(s.get('turn'),[]).append(x)
 for t,ts in turns.items():
  st=ts[0]['row']['state'];en=ts[-1]['row']['state'];nxt=next((x for x in rows if x['line']>ts[-1]['line']),None);ns=nxt['row']['state'] if nxt else en
  def enemies(s):return [(e['index'],e['enemy_id'],e['current_hp'],e['is_alive'],[(z['power_id'],z['amount']) for z in e.get('powers',[])]) for e in (s.get('combat') or {}).get('enemies',[])]
  print('C',c['sequence'],'F',c['floor'],'T',t,f"s{ts[0]['line']}->{ts[-1]['line']}->{nxt['line'] if nxt else '?'}",'HP',st['run']['current_hp'],ns['run']['current_hp'],'endblock',en['combat']['player']['block'],'endpowers',[(z['power_id'],z['amount']) for z in en['combat']['player']['powers']],'enemy',enemies(st),'LAST',enemies(en),'NEXT',enemies(ns))
print('STATS')
jev=[x for x in ds if x['row'].get('decider')=='jev'];plans=[x for x in jev if x['row']['label'].startswith('combat/plan-choice')]
print('JEV',len(jev),'LOW',collections.Counter(x['row']['label'] for x in jev if isinstance(x['row'].get('confidence'),(int,float)) and x['row']['confidence']<.35),'PLAN',len(plans))
print('FOCUS',[(x['line'],x['row']['floor'],x['row'].get('turn'),[(k,v.get('focus')) for k,v in opts(x['row']).items() if isinstance(v,dict) and v.get('focus') is not None]) for x in plans if any(isinstance(v,dict) and v.get('focus') is not None for v in opts(x['row']).values())])
print('TOPKEYS',collections.Counter(k for x in ds for k in x['row'] if 'log' in k or 'rollout' in k))
print('USAGE_JEV',{k:sum((x['row'].get('usage') or {}).get(k,0) or 0 for x in jev) for k in ['input_tokens','output_tokens','cache_hit_tokens']})
brain=read('brain');print('USAGE_BRAIN',{k:sum((x['row'].get('usage') or {}).get(k,0) or 0 for x in brain) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']})
print('LABELS',collections.Counter((x['row']['decider'],x['row']['label']) for x in ds))

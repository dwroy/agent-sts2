import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
stamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(stamp)
batch = '20261017-155957-strategy-proposal'
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
proposals = json.loads((OUT / 'selected-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
assert base == source['base'] == '04c4ed556f0baac3bcbbb207f0f35ff0500c65c9'

# Each entry keeps the original proposal scope and supplies a concrete redispatch condition.
details = [
    ('c20b5139dd0dff71', '污染逐击血价',
     'DUZUBAJ3A8GP F27 T4—T5；states 274830—274838：火花3时污染0→3→6，能力勒紧不加；下一轮污染清除、火花变6，三技能后污染18，攻击26、挡17、实损9。',
     '技能同时提供毒、虚弱或格挡；本局没有少打技能的同抽序完整胜线，9血代价不能推出统一禁技能。',
     '求解器已有技能污染与逐击入伤，rollout已有火花增长和当前进阶移动表入口；这些接口不等于旧运行输入已经恢复。',
     '缺原运行实际读取的A10移动表冻结字节，以及火花增长、污染清除、毒/弱/挡联合后继的生产校准；不能据9损新增禁技能规则。',
     '补原调用移动表及完整状态/动作输入，固定重放T4→T6，逐步核污染、毒、挡和双方HP；另线整战后继单列。'),
    ('ae9e692d680e3819', '逐实体抢夺及返还',
     '5PM6JAQG6FNQ F39 T4—T6；states 274351/274352/274354/274358/274362：玩家力敏−4，步法逐次回敏，失落退场后玩家力量回0，遗忘随后再抢2敏。',
     '末试只打一张步法，仍为−2敏；毒杀失落后仍死于遗忘，不能推出固定击杀序。',
     '现帧负属性与返力端点可核；敌人类型、index和总力敏不是显式逐来源抢夺账。',
     '缺逐实体抢夺累计的显式真值、可靠实例连续身份、遗忘退场返敏及再次抢夺的完整固定链；不能用敌方总属性代填被抢数。',
     '新日志须保留实例身份、抢夺来源/累计与退场返还，核两种退场和后续重抢；没有该真值时保留未知。'),
    ('52f1e1bd2e7db0ed', '当前进阶事实与加压',
     'CA5KE8GFJ9X2 F13 T1/T3/T5；states 273237/273252/273254/273263及后继：力量0/4/8，喷水11/15/19，虚弱后11/14；轮初覆甲9/9/8/7/6。',
     '覆甲层数下降只记录现场，尚未隔离完整减层条件；T5两血对14攻击和10挡仍死。',
     'enemyTable按当前asc读取观测DB；MEASURED_ROOM_MIN_N仍为5，不把怪物第一样本门槛混成房间统计门槛。',
     '缺原调用A10移动表字节与加压/覆甲全过程的联合校准；本局缺已知SL尝试元数据，严格消费者没有认证完整轮。',
     '冻结实际调用表和全部动作，分别验当前进阶攻击/HP、加压、弱、覆甲；房间代价保持5样本门槛，未知减层条件不补公式。'),
    ('6dd8bbff876be528', '机器人逐实体成长',
     '5PM6JAQG6FNQ F38 T3—T4；states 274308/274313/274317：23最大血的电击机器人力量2→4、攻击17→19，T3仍贡献17攻击、T4才退场。',
     '先杀爪牙的题面35伤/损3未实打；类型/最大HP相同不足以认证召唤代际，不能许诺省27血救后场。',
     'HIGH_VOLTAGE_POWER已列成长来源，rollout有逐实体增长和新召唤初始化路径。',
     '缺原移动表、可靠召唤代际身份与连续后继的冻结生产校准；现有成长接口不认证跨代重置或统一集火收益。',
     '补实例与召唤代际、实际移动表，固定核老实体成长/退场及新实体初始化；目标顺序另需完整后继。'),
    ('578e415a259e6835', '沙虫护栏/SL与实际资源分账',
     '8JRE1C4H4Z2W F33首/第三试T2：decisions 270216/270282同完整指纹，实际损血3/15、敌HP净扣10/17；第二试T5护栏及F17 T6抽牌重规划，末试T11 states276433/276434。',
     '末试T2换防御延至T11仍败，反对把所有保血替换认定错误；T11仅实扣5，显示攻击37−挡22=15不可冒充实测完整入伤。',
     '候选阶段、护栏预测、SL资源差、单动作派发回执和离线端点均有实际live祖先。',
     '缺全部重规划后的逐候选续步身份，以及沙坑/能力和路线资源逐来源结算；现有消费者明确不认证完整候选，不能拼接窄子项关闭整项。',
     '补抽牌/选牌/生成/药水/SL后的持续身份与完整派发链，逐来源核HP、毒、挡、沙坑；未派发续步与死亡截断单列，策略收益后移验证。'),
    ('c0767768bf6a7ab1', '全败SL血价与重放',
     'YF0LXT1QSTGG F48第二/第三试T1：decisions271309/271348同指纹，原/替实际损0/9、敌HP净扣45/38；题面均24/24死、后损封顶27。',
     '第四次T5换线在弃牌后没有完整执行；F33第二次SL实际获胜，不能以终战全败否定全部SL价值。',
     '1698adc96ba434a46942321e0237b70657e625b2已有替换/重放/avoid预测差，fdaf787a372880b0438e73bcac7e6d2168b038ed只记录单动作回执。',
     '缺整候选实际续步与血价归属、同抽序完整替线及独立整战验证；全败有限样本并列不足以拟HP惩罚常数或禁止探索。',
     '核原答/护栏/SL/实际分段身份、所有续步与重问，分开预测损10和实损9；留独立后续局校准规则，保留成功SL反例。'),
    ('a46bdb7fe711d79a', '阶段与已兑现毒/挡',
     'YF0LXT1QSTGG F48末试T3—T5；states277512—277528：第一阶段4HP→新阶段212，旧毒/力清空；触媒2但零毒；5敏时两牌挡23，随后苦无加至6敏不倒补。',
     '前五试第二阶段建立毒雾或余像仍败；持有升级毒性爆发不等于此阶段施放，不推出强制能力先手或牌组上限。',
     'aad2700abed6dff1d66e87fb36aaa6fedb39adf3提供当前阶段、持有组件及已建能力；rollout已有阶段重置。',
     '缺逐候选即时施毒/已结算毒、额外扣血与敏捷取得顺序的来源归属，以及完整派发结果的联合认证。',
     '固定核阶段切换、零毒触媒、23挡不倒补与37扣血的各来源；补全动作身份，当前帧参考不替代实际收益账。'),
    ('1044224808015e5c', '双蟹零胜并列SL血价',
     'XP2SL33HT0D9 F33首/第二试T3：decisions271992/272040同指纹，损血9/14、敌HP净扣24/27；首/末试T1：271982/272195，损2/10、净扣25/34。',
     '末试T1同时取得手里剑力量，不能抹去成长收益；末试T2零损、T3保留挡仍败，后继抽序不同，不能按存活轮数判单卡因果。',
     'SL预测差及同题样本比较已实现；B2零胜并列没有消除当轮成本。',
     '缺同抽序完整替线、成长兑现后继与独立整战胜线；不能据两组当轮端点拟低血优先门槛、HP常数或禁止付血探索。',
     '固定验9/14与24/27、2/10与25/34，同时核力量成长和后续重规划；规则训练/验证按局与时间分开，同存档不扩分母。'),
    ('7cbc6005db712ba9', '双蟹朝向/减力/格挡兑现',
     'XP2SL33HT0D9 F33末试T2—T5；states278236/278237/278242：轮初挡14，镣铐0→−9力及恢复；278249/278252/278253激光57→38→28；4敏脆弱下偏折/防御各6挡。',
     '船夹板14只在已观察T2；朝向与虚弱贡献分别19/10，不合成通用减伤常数；能力已建仍未减员，不说明固定杀序可赢。',
     '船夹板T2/14、临时减力恢复、朝向和脆弱算式已有源码；观测参考仅属其已观察条件。',
     '缺逐候选拆分原有/新增挡、朝向/弱、已结算毒与存活HP的统一来源校准；现场参考不等同完整执行模型。',
     '以原帧验14+6=20、临减及恢复、57→38→28和6挡、16/20直伤、末轮3+7毒；各来源与动作顺序单列，不改原权重。'),
    ('c59f592f1427a67e', '综合机制/资源与SL闭环',
     'YF0LXT1QSTGG F48 T1/T4/T5及XP2SL33HT0D9 F33 T1—T5；同指纹配对、阶段、临时减力、轮初挡与敏捷顺序见上述原行及mechanism-frame-readback.json。',
     '两局多次SL仍是两个独立局；YF F33成功SL保留，已建毒/挡仍败及候选因弃牌未完均保留；本批未重核原提案引用的其他历史局。',
     '多个机制与审计窄功能已有实际live祖先；原经验状态和历史分母保持，不能当本批全范围再验证。',
     '缺逐来源资源账、所有重规划后完整候选归属、路线/药水时机及受控整战后继；不能以多个窄事实替代原宽请求交付。',
     '按本批可核范围补完整身份、资源来源和未执行续步，先校准事实再留独立新局验策略；原宽项与父学习要求继续保留。'),
]

results = []
proposal_text = ['# 静默猎手十项原提案逐项复核', '',
                 f'记录时间：{stamp}；batch={batch}；已观察策略范围：silent/A10。', '',
                 '本批只处理learn.json已领取的十个原ID。六来源局已经runs.jsonl核角色；没有专题或实现请求绑定，未领取其他提案。',
                 '所有提案保持waiting；已有窄实现不冒称整项implemented/duplicate。没有新源码失配、参数拟合或新机制结论。', '',
                 '共用验证：原日志封套按offset/bytes/SHA/JSON/显式身份读回；旧消费者输入及六叶执行源码与当前逐字相同，复用原输出并核SHA/内容。',
                 '已有机制不等于整战因果。固定帧为发现/回归输入，同一SL存档不拆训练/验证；未选线完整抽序与独立后移胜线仍未知。',
                 '以后新增源码必须撤源失败、恢复通过，再跑固定沙箱入口并按live流程上线；本批没有源码，未执行这些生产测试。', '']
for suffix, title, evidence, counter, existing, missing, validation in details:
    ident = 'silent-proposal-' + suffix
    original = proposals[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': missing})
    proposal_text.extend([f'## {ident}：{title}', '',
        f'来源任务：{original["source_task"]}；目标任务：strategy-proposal；原提案：{original["proposal"]}。',
        '原关联账本：' + '、'.join(original['ledger']) + '。', '',
        '证据：' + evidence, '', '反例/范围：' + counter, '',
        '旧规则/已有实现：' + existing, '',
        '预期行为：' + original['summary'] + ' 本批保留现有出牌、护栏、药水、SL、终局价值与候选选项。', '',
        '处置与重派缺口：waiting。' + missing, '',
        '验证方案：' + validation, '',
        '回退/影响：本批未改对局行为，无源码提交或回退项。以后只撤独立实现补丁，保留历史、刷新知识和其他角色行为；收益未知。', ''])
(OUT / 'proposal.md').write_text('\n'.join(proposal_text) + '\n')
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
consumers = json.loads((OUT / 'consumer-reuse.json').read_text())
report = ['# 静默猎手策略提案批次报告', '',
          '十项原提案均保留waiting。本批六局原证据与前批相同，没有新数据足以补齐原提案或支持新策略参数；未修改源码、知识或游戏规则。', '',
          f'记录时间：{stamp}。batch={batch}；task=strategy-proposal；character=silent。', '',
          '## 身份、基线和范围', '',
          '- 初始工作树干净，初始HEAD=d95f0b8dcecc08ca4f585a5348f8a446363e29bd。',
          f'- 本批为普通reason=proposal，精确十proposal_ids；无research_request、implementation_request、proposal_repair。普通专题文件绑定另一历史批次，未按专题继续。',
          f'- git merge --no-edit main无冲突快进，base/最终HEAD={base}；本批未提交。',
          '- 六局runs.jsonl均为SILENT/A10：DUZUBAJ3A8GP、5PM6JAQG6FNQ、CA5KE8GFJ9X2、8JRE1C4H4Z2W、YF0LXT1QSTGG、XP2SL33HT0D9。运行code均有+dirty，不冒称还原原运行完整源码/知识。',
          '- 仅核本批六局、对应原复盘/提案、30个关联账本及25项静默经验。原提案中其他历史局和较宽进阶分母未当成本批验证；不读取其他角色私有知识。', '',
          '## 证据读回', '',
          '使用本树共用extract_evidence.py，按run/run_id/state.run_id/fingerprint.run显式身份抽取；冲突拒收，不以正文提及选局。七流8274条封套均按原路径offset/bytes/SHA256/JSON及身份读回。', '',
          '| 流 | 冻结source_size字节 | 本批行数 | 全源无效JSON行 |',
          '|---|---:|---:|---:|']
for entry in manifest:
    report.append(f'| {entry["stream"]} | {entry["source_size"]} | {sum(entry["counts"].values())} | {entry["invalid_lines"]} |')
report.extend(['', '各流输出SHA与前批同范围输出完全一致。CA5的sl-attempts为0行，只表示该截点未选到；run-plans按run字段实际选33行。全流无效JSON计数不归因于本批，不覆盖旧报告或零行初稿。原封套/计数见evidence/与raw-verification.json。', '',
    '四组完整fingerprint相同的起点，按observed_ts+fingerprint唯一回连状态，重新计算起点至下一轮首匹配决策的净变化：', '',
    '| 局/层/回合 | 决策原行 | 原/替实损HP | 原/替敌HP净扣 |', '|---|---|---:|---:|',
    '| 8JRE1C4H4Z2W F33 T2 | 270216/270282 | 3/15 | 10/17 |',
    '| YF0LXT1QSTGG F48 T1 | 271309/271348 | 0/9 | 45/38 |',
    '| XP2SL33HT0D9 F33 T3 | 271992/272040 | 9/14 | 24/27 |',
    '| XP2SL33HT0D9 F33 T1 | 271982/272195 | 2/10 | 25/34 |', '',
    '这些是观测端点净差，非单卡因果或整候选执行认证。106个旧机制/关键帧摘要已逐原行SHA及字段读回，包含污染、火花增长、加压、抢夺返力、电击成长、阶段重置、零毒触媒、敏捷顺序、14轮初挡与57→38→28朝向/弱。没有新增机制反证；既有反例全部保留，不重复增加support/repeat。', '',
    '## 消费者验证的实际范围', '',
    '本批重新准备六份有界输入，保留指定楼层全部决策和状态、原行号、所有重问与原尝试字段，没有补ID或删行。输入字节、消费者五模块及json辅助模块六叶源码均与前批相同，故读取并核验前批原输出/退出回执，没有再次运行消费者、模拟器或LLM。', '',
    '| 局号 | 楼层 | 决策/状态 | 复用原片段 | 原可核轮端点 | 原退出码 |',
    '|---|---|---:|---:|---:|---:|'])
scopes = {row['run_id']: row for row in json.loads((OUT / 'consumer-input-scopes.json').read_text())}
for row in consumers:
    s = scopes[row['run_id']]; c = row['verified_summary']
    report.append(f'| {row["run_id"]} | {",".join(map(str, s["floors"]))} | {s["decisions"]}/{s["states"]} | {c["segments"]} | {c["turns_observed"]} | {row["prior_exit"]} |')
report.extend(['',
    '复用206片段、119个可核轮端点，完整候选认证数0。actual_full_candidate_result=null表示工具没有认证，并不证明候选从未执行。CA5/DUZ尝试身份未知时仍按原消费者合同保unknown；死亡截断净损与显示攻击算式分开。旧输出路径、当前输入与六叶SHA见consumer-reuse.json/consumer-source-comparison.json，属于材料读回而非本批生产测试成功。', '',
    '## 当前源码与逐项处置', '',
    f'只读冻结live={source["live_head"]}。18叶base/live源码原字节.txt、blob/SHA/最近路径提交及祖先布尔、三叶差异patch保存在source/和source-readback.json。15叶同字节，三叶仅原Roy/Dai历史署名注释差；并非本批修改。', '',
    '已核下列源码提交均为当前live及base祖先，仅认证各自窄范围：', '',
    '- 1698adc96ba434a46942321e0237b70657e625b2：原/替/重放/avoid的同轮预测资源差。',
    '- 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb：预测候选阶段审计；fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执。',
    '- aad2700abed6dff1d66e87fb36aaa6fedb39adf3：实验体当前阶段/组件/已建能力。',
    '- a32050fbce4c2863f640468c2dbf378fc9157074、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933：离线相邻观测、终态与轮端点。', '',
    '当前进阶DB读取、房间代价5样本门槛、逐击污染、成长和阶段重置路径已核。接口存在不替代六局旧dirty调用输入，也不将多个窄祖先合成为宽提案implemented/duplicate。逐项证据局号/层/回合/全部账本、反例、旧/预期行为、验证和回退见proposal.md：', ''])
for row in results:
    report.append(f'- {row["id"]}：waiting；{row["reason"]}')
report.extend(['', '## 记录、测试与交接', '',
    '本批仅经根learner/ledger.py update为30个既有账本补本批proposal/report追溯。没有新发现，不新建提案ID，不重复support/repeat，不更改claim、first_run、asc、prior、evidence、status、version、shipped或effect；旧shipped不降级。根专用队列由原调度器按proposal_results处理，本任务不手改。CLI及原前缀/逐物理行核验另存ledger-cli.json/ledger-verification.json。', '',
    '未改源码：撤源码失败/恢复通过不适用；tsc=null、vitest=null、cases=null，未跑生产沙箱套件，也未借用原测试称本批绿色。fixes=[]、merged=null，无源码commit、合入commit、eval版本或shipped；没有live合入步骤需要执行。其他角色对局行为等价。', '',
    '过程材料失败保留：校验草稿假定runs和其他流共用旧manifest，实际旧runs在evidence-runs独立目录；KeyError原日志、源码初稿保留，修正后8274行全部核验通过。两次只读路径猜测不存在及进程探测未匹配也保留执行历史，不作为产品缺陷或源码红绿。', '',
    '没有新科学异议/反证，不重复发送旧学习通知，不代任何角色确认。不关闭宽父学习要求，不声称经验已入库、自然消费者已采用或策略获益。', '',
    f'运维交接proposal：{OUT / "proposal.md"}；report：{OUT / "report.md"}。十个原ID均有waiting理由，待所列新输入重派。保持工作树干净；原日志、失败与初稿保留，结束交原调度器验收回收。', ''])
(OUT / 'report.md').write_text('\n'.join(report))
print(json.dumps({'base': base, 'proposals': len(results), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261017-144302/learner/runs/20261017-144307-a376ee27-f3d5-45d8-9ab4-551bd57576f0-strategy-proposal'


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


spec = importlib.util.spec_from_file_location('extract_evidence', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
identities = json.loads((OUT / 'run-identities.json').read_text())
runs = {row['run_id']: row for row in identities}
assert len(runs) == 6
assert all(row['character'].lower() == 'silent' and row['ascension'] == 10 for row in identities)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
prior_manifest = {}
prior_outputs = {}
for directory in ['evidence', 'evidence-runs']:
    for row in json.loads((PRIOR / directory / 'evidence-manifest.json').read_text()):
        assert row['stream'] not in prior_manifest
        prior_manifest[row['stream']] = row
        prior_outputs[row['stream']] = PRIOR / directory / (row['stream'] + '.evidence.jsonl')
streams = {}
verification = []
for entry in manifest:
    name = entry['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    assert sha(path.read_bytes()) == entry['output_sha256']
    counts = collections.Counter()
    rows = []
    expected_source = ROOT / 'logs' / (name + '.jsonl')
    with expected_source.open('rb') as source:
        for line in path.open():
            item = json.loads(line)
            assert Path(item['source']) == expected_source
            assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= entry['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
            assert json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id'] and item['run_id'] in runs
            counts[item['run_id']] += 1
            rows.append(item)
    assert all(counts[run] == count for run, count in entry['counts'].items())
    streams[name] = rows
    verification.append({'stream': name, 'source_size': entry['source_size'], 'rows': len(rows),
                         'counts': dict(counts), 'raw_offset_bytes_sha_json_identity_verified': True,
                         'prior_path': str(prior_outputs[name]),
                         'same_selected_output_as_prior': prior_manifest[name]['output_sha256'] == entry['output_sha256']})
save('raw-verification.json', verification)

floors = {'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [38, 39], 'DUZUBAJ3A8GP': [27],
          '8JRE1C4H4Z2W': [17, 33], 'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [29, 33]}
consumer_sources = ['learner/audit-selection.ts', 'learner/lib/selection-execution.ts',
                    'learner/lib/selection-observation.ts', 'learner/lib/selection-terminal.ts',
                    'learner/lib/selection-turn.ts', 'agent/src/core/util/json.ts']
prior_base = json.loads((PRIOR / 'source-readback.json').read_text())['base']
source_match = []
for path in consumer_sources:
    before = subprocess.check_output(['git', 'show', prior_base + ':' + path])
    current = Path(path).read_bytes()
    source_match.append({'path': path, 'prior_base': prior_base, 'prior_sha256': sha(before),
                         'current_sha256': sha(current), 'same_bytes': before == current})
save('consumer-source-comparison.json', source_match)

scopes = []
for run, wanted in floors.items():
    selected = {}
    for name in ['decisions', 'states']:
        selected[name] = []
        for item in streams[name]:
            if item['run_id'] != run:
                continue
            row = item['row']
            floor = row.get('floor') if name == 'decisions' else row['state']['run'].get('floor')
            if floor in wanted:
                selected[name].append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    selected['decisions'].sort(key=lambda row: row.get('observed_ts') or '')
    data = (json.dumps({'run': runs[run], **selected}, ensure_ascii=False) + '\n').encode()
    path = OUT / (run + '.consumer-input.json')
    path.write_bytes(data)
    prior_input = PRIOR / path.name
    scopes.append({'run_id': run, 'floors': wanted, 'decisions': len(selected['decisions']),
                   'states': len(selected['states']), 'input_sha256': sha(data),
                   'same_input_as_prior': data == prior_input.read_bytes(),
                   'missing_decision_id_lines': [row['_line'] for row in selected['decisions'] if not row.get('decision_id')],
                   'exclusions': [], 'scope': '指定楼层所有原始决策和状态，保留原行号、全部重问与尝试字段；不覆盖其他楼层。'})
save('consumer-input-scopes.json', scopes)

# Recompute the four paired endpoints from the current frozen evidence.
decisions = {item['line']: item for item in streams['decisions']}
states = collections.defaultdict(list)
for item in streams['states']:
    states[(item['row'].get('observed_ts'), item['row'].get('fingerprint'))].append(item)


def matched(row):
    found = states[(row.get('observed_ts'), row.get('fingerprint'))]
    assert len(found) == 1
    return found[0]


pairs = []
for left, right in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    a, b = decisions[left], decisions[right]
    assert a['row']['fingerprint'] == b['row']['fingerprint']
    observations = []
    for item in [a, b]:
        row = item['row']
        successors = [other for other in streams['decisions'] if other['line'] > item['line']
                      and other['run_id'] == item['run_id'] and other['row'].get('floor') == row['floor']
                      and other['row'].get('sl_attempt') == row['sl_attempt']
                      and other['row'].get('turn') == row['turn'] + 1]
        nxt = min(successors, key=lambda other: other['line'])
        start, end = matched(row), matched(nxt['row'])
        before, after = start['row']['state']['combat'], end['row']['state']['combat']
        assert [(e['enemy_id'], e['max_hp']) for e in before['enemies']] == [(e['enemy_id'], e['max_hp']) for e in after['enemies']]
        observations.append({'decision_line': item['line'], 'next_decision_line': nxt['line'],
                             'run_id': item['run_id'], 'floor': row['floor'], 'turn': row['turn'], 'attempt': row['sl_attempt'],
                             'before_state_line': start['line'], 'after_state_line': end['line'],
                             'before_state_sha256': start['sha256'], 'after_state_sha256': end['sha256'],
                             'observed_hp_loss': before['player']['current_hp'] - after['player']['current_hp'],
                             'observed_enemy_hp_reduction': sum(e['current_hp'] for e in before['enemies']) - sum(e['current_hp'] for e in after['enemies']),
                             'sl_forecast': row.get('sl_explore'), 'actual_full_candidate_result': None})
    pairs.append({'decision_lines': [left, right], 'same_fingerprint': True, 'observations': observations})
save('paired-endpoints.json', pairs)

print(json.dumps({'raw_rows_verified': sum(row['rows'] for row in verification),
                  'all_selected_stream_bytes_equal_prior': all(row['same_selected_output_as_prior'] for row in verification),
                  'consumer_sources_equal_prior': all(row['same_bytes'] for row in source_match),
                  'consumer_inputs_equal_prior': all(row['same_input_as_prior'] for row in scopes),
                  'pairs': [{'decisions': p['decision_lines'], 'hp_loss': [x['observed_hp_loss'] for x in p['observations']],
                             'enemy_reduction': [x['observed_enemy_hp_reduction'] for x in p['observations']]} for p in pairs]}, ensure_ascii=False))

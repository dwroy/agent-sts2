## 复盘：run YF0LXT1QSTGG — 阵亡，最高第 48 层

- 决策 1065 个；Jev 调用 269 次，Claude 0 次，大脑 47 次（codex 47）；token 1,114,495 入 / 14,053 出，约 $0.0474（Jev）；大脑 token 5,935,629 入（缓存命中 4,196,352，71%）/ 12,025 出；用时 53.9 分钟
- 决策者：code 447，jev-plan 288，jev 269，codex 61

### 战斗掉血（按层）
- 第 2 层 蟾蜍蝌蚪: HP 56→51（-5），决策 code 11，jev 6，jev-plan 6
- 第 3 层 海洋混混: HP 51→50（-1），决策 code 12，jev 5，jev-plan 5
- 第 5 层 噬尸蛞蝓: HP 50→50（-0），决策 code 9，jev 9，jev-plan 1
- 第 6 层 海洋混混/钙化邪教徒: HP 50→39（-11），决策 jev-plan 12，code 12，jev 9
- 第 11 层 花园幽灵鳗: HP 62→48（-14），决策 jev 13，jev-plan 13，code 9
- 第 14 层 潮湿邪教徒/钙化邪教徒: HP 50→50（-0），决策 jev 5，jev-plan 5，code 3
- 第 15 层 幽灵船: HP 52→50（-2），决策 jev 9，jev-plan 6，code 4
- 第 17 层 瀑布巨兽: HP 70→40（-30），决策 jev 29，jev-plan 24
- 第 19 层 外骨骼虫: HP 66→66（-0），决策 jev 5，jev-plan 3，code 2
- 第 22 层 地道虫: HP 68→56（-12），决策 jev 12，jev-plan 10，code 1
- 第 23 层 异螨: HP 58→58（-0），决策 jev 12，jev-plan 11，code 5
- 第 24 层 棘刺蟾蜍: HP 60→26（-34），决策 jev-plan 10，jev 7，code 1
- 第 27 层 熟睡甲虫/盛碗虫（丝）/盛碗虫（石）: HP 49→37（-12），决策 jev 17，jev-plan 16，code 2
- 第 28 层 啃咬机: HP 39→32（-7），决策 jev-plan 9，jev 7，code 3
- 第 31 层 幼虫/直飞产卵虫/结实的卵: HP 55→53（-2），决策 jev 11，jev-plan 10，code 4
- 第 33 层 无厌沙虫: HP 55→20（-35），决策 jev-plan 37，code 34，jev 31
- 第 35 层 活体盾/高塔炮手: HP 62→52（-10），决策 jev-plan 10，jev 9，code 1
- 第 36 层 虔诚雕刻师: HP 54→19（-35），决策 jev-plan 13，jev 11，code 3
- 第 38 层 失落之物/遗忘之物: HP 21→12（-9），决策 jev-plan 15，code 11，jev 9
- 第 45 层 幽灵骑士/连枷骑士/魔法骑士: HP 70→2（-68），决策 jev-plan 16，jev 13，code 11
- 第 46 层 战斗好伙伴V1.0: HP 4→4（-0），决策 jev-plan 5，code 4，jev 2
- 第 48 层 实验体 #C64: HP 27→0（-27），决策 code 145，jev-plan 51，jev 38

### 死亡战斗：第 48 层 实验体 #C64
- T4 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 计算下注
- T4 [jev] combat/plan-choice: Jev chose plan 1/2 (触媒+) with confidence 0.46; code rank 1 conf 0.46
- T4 [code] combat/plan: code plan (only line): end turn; hp -0, dmg 0
- T5 [code] combat/plan: code plan (only line): 生存者, 防御, 防御; hp -11, dmg 0
- T5 [jev] selection/choose: Jev chose 防御 with confidence 0.21 conf 0.21
- T5 [code] combat/least-loss: every simulated line dies; drawing first for a kill or block the hand does not have (then re-planning), on the most-damage line (dmg 0): 刀刃之舞+, 防御
- T5 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-3): 防御, 小刀 -> 实验体 #C64, 小刀 -> 实验体 #C64, 小刀 -> 实验体 #C64, 小刀 -> 实验体 #C64
- T5 [code] combat/plan-continue: continuing the code-chosen plan: 小刀 -> 实验体 #C64
- T5 [code] combat/plan-continue: continuing the code-chosen plan: 小刀 -> 实验体 #C64
- T5 [code] combat/plan-continue: continuing the code-chosen plan: 小刀 -> 实验体 #C64
- T5 [code] combat/plan-continue: continuing the code-chosen plan: 小刀 -> 实验体 #C64
- T5 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-3): end turn

### 各类决策由谁做
- combat/plan-continue / jev-plan: 288
- combat/plan-choice+potion / jev: 135
- combat/plan-continue / code: 111
- combat/plan / code: 108
- combat/plan-choice / jev: 69
- selection/choose / jev: 62
- reward/claim / code: 56
- map/route-follow / code: 42
- combat/lethal / code: 35
- combat/least-loss / code: 22
- reward/card / codex: 20
- reward/proceed / code: 20
- rest/plan / codex: 11
- event/leave / code: 10
- rest/proceed / code: 10
- shop/buy / codex: 7
- combat/end_turn / code: 6
- event/choose / codex: 6
- chest/open / code: 4
- chest/proceed / code: 4
- chest/relic / code: 4
- selection/upgrade / codex: 4
- combat/mod-lethal / code: 3
- selection/take into my hand / jev: 3
- shop/leave / code: 3
- shop/open / code: 3
- shop/plan / codex: 3
- event/act-plan / codex: 2
- event/plan / codex: 2
- map/route-follow / codex: 2
- map/route-only / code: 2
- selection/add / codex: 2
- combat/sandpit-guard / code: 1
- map/route-plan / codex: 1
- rest/plan / code: 1
- run/finalize / code: 1
- selection/remove / codex: 1
- selection/take into my hand / code: 1

### 兜底介入（Claude/DeepSeek）：0 次（推翻 Jev 0 次）

### Jev 低置信度（<0.35）决策：44 个
- 第 2 层 combat/plan-choice: Jev chose plan 2/2 (打击 -> 蟾蜍蝌蚪 #1, 生存者, 打击 -> 蟾蜍蝌蚪 #2) with confidence 0.14; code rank 2 (0.14)
- 第 3 层 selection/choose: Jev chose 打击 with confidence 0.16 (0.16)
- 第 5 层 combat/plan-choice+potion: Jev chose to drink 发光水, then re-plan (confidence 0.33) (0.33)
- 第 6 层 selection/choose: Jev chose 打击 with confidence 0.11 (0.11)
- 第 6 层 selection/choose: Jev chose 打击 with confidence 0.32 (0.32)
- 第 6 层 selection/choose: Jev chose 打击 with confidence 0.23 (0.23)
- 第 11 层 selection/choose: Jev chose 防御 with confidence 0.24 (0.24)
- 第 11 层 selection/choose: Jev chose 防御 with confidence 0.30 (0.30)
- 第 11 层 combat/plan-choice+potion: Jev chose to drink 无色药水, then re-plan (confidence 0.30) (0.30)
- 第 11 层 selection/choose: Jev chose 打击 with confidence 0.17 (0.17)
- 第 15 层 selection/choose: Jev chose 打击+ with confidence 0.20 (0.20)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.28; code rank 1 (0.28)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/2 (打击+ -> 瀑布巨兽, 回响斩击, 生存者) with confidence 0.22; code rank 1 (0.22)
- 第 17 层 selection/choose: Jev chose 打击 with confidence 0.27 (0.27)
- 第 19 层 selection/choose: Jev chose 防御 with confidence 0.34 (0.34)

# 静默猎手策略提案批次报告

十项原提案均保留waiting。本批六局原证据与前批相同，没有新数据足以补齐原提案或支持新策略参数；未修改源码、知识或游戏规则。

记录时间：2026-10-17T16:11:42+08:00。batch=20261017-155957-strategy-proposal；task=strategy-proposal；character=silent。

## 身份、基线和范围

- 初始工作树干净，初始HEAD=d95f0b8dcecc08ca4f585a5348f8a446363e29bd。
- 本批为普通reason=proposal，精确十proposal_ids；无research_request、implementation_request、proposal_repair。普通专题文件绑定另一历史批次，未按专题继续。
- git merge --no-edit main无冲突快进，base/最终HEAD=04c4ed556f0baac3bcbbb207f0f35ff0500c65c9；本批未提交。
- 六局runs.jsonl均为SILENT/A10：DUZUBAJ3A8GP、5PM6JAQG6FNQ、CA5KE8GFJ9X2、8JRE1C4H4Z2W、YF0LXT1QSTGG、XP2SL33HT0D9。运行code均有+dirty，不冒称还原原运行完整源码/知识。
- 仅核本批六局、对应原复盘/提案、30个关联账本及25项静默经验。原提案中其他历史局和较宽进阶分母未当成本批验证；不读取其他角色私有知识。

## 证据读回

使用本树共用extract_evidence.py，按run/run_id/state.run_id/fingerprint.run显式身份抽取；冲突拒收，不以正文提及选局。七流8274条封套均按原路径offset/bytes/SHA256/JSON及身份读回。

| 流 | 冻结source_size字节 | 本批行数 | 全源无效JSON行 |
|---|---:|---:|---:|
| states | 13936760946 | 4062 | 2 |
| decisions | 2262108696 | 3941 | 2 |
| sl-attempts | 45560418 | 38 | 0 |
| run-config | 1956506 | 6 | 0 |
| run-plans | 8935400 | 33 | 0 |
| brain | 748967437 | 188 | 2 |
| runs | 358345 | 6 | 0 |

各流输出SHA与前批同范围输出完全一致。CA5的sl-attempts为0行，只表示该截点未选到；run-plans按run字段实际选33行。全流无效JSON计数不归因于本批，不覆盖旧报告或零行初稿。原封套/计数见evidence/与raw-verification.json。

四组完整fingerprint相同的起点，按observed_ts+fingerprint唯一回连状态，重新计算起点至下一轮首匹配决策的净变化：

| 局/层/回合 | 决策原行 | 原/替实损HP | 原/替敌HP净扣 |
|---|---|---:|---:|
| 8JRE1C4H4Z2W F33 T2 | 270216/270282 | 3/15 | 10/17 |
| YF0LXT1QSTGG F48 T1 | 271309/271348 | 0/9 | 45/38 |
| XP2SL33HT0D9 F33 T3 | 271992/272040 | 9/14 | 24/27 |
| XP2SL33HT0D9 F33 T1 | 271982/272195 | 2/10 | 25/34 |

这些是观测端点净差，非单卡因果或整候选执行认证。106个旧机制/关键帧摘要已逐原行SHA及字段读回，包含污染、火花增长、加压、抢夺返力、电击成长、阶段重置、零毒触媒、敏捷顺序、14轮初挡与57→38→28朝向/弱。没有新增机制反证；既有反例全部保留，不重复增加support/repeat。

## 消费者验证的实际范围

本批重新准备六份有界输入，保留指定楼层全部决策和状态、原行号、所有重问与原尝试字段，没有补ID或删行。输入字节、消费者五模块及json辅助模块六叶源码均与前批相同，故读取并核验前批原输出/退出回执，没有再次运行消费者、模拟器或LLM。

| 局号 | 楼层 | 决策/状态 | 复用原片段 | 原可核轮端点 | 原退出码 |
|---|---|---:|---:|---:|---:|
| CA5KE8GFJ9X2 | 13 | 26/33 | 4 | 0 | 0 |
| 5PM6JAQG6FNQ | 38,39 | 108/112 | 18 | 7 | 0 |
| DUZUBAJ3A8GP | 27 | 45/47 | 8 | 0 | 0 |
| 8JRE1C4H4Z2W | 17,33 | 277/280 | 66 | 44 | 0 |
| YF0LXT1QSTGG | 33,48 | 343/345 | 52 | 40 | 0 |
| XP2SL33HT0D9 | 29,33 | 247/248 | 58 | 28 | 0 |

复用206片段、119个可核轮端点，完整候选认证数0。actual_full_candidate_result=null表示工具没有认证，并不证明候选从未执行。CA5/DUZ尝试身份未知时仍按原消费者合同保unknown；死亡截断净损与显示攻击算式分开。旧输出路径、当前输入与六叶SHA见consumer-reuse.json/consumer-source-comparison.json，属于材料读回而非本批生产测试成功。

## 当前源码与逐项处置

只读冻结live=19988d1118ca43c1409fe900fc8c94f9f6ac32cc。18叶base/live源码原字节.txt、blob/SHA/最近路径提交及祖先布尔、三叶差异patch保存在source/和source-readback.json。15叶同字节，三叶仅原Roy/Dai历史署名注释差；并非本批修改。

已核下列源码提交均为当前live及base祖先，仅认证各自窄范围：

- 1698adc96ba434a46942321e0237b70657e625b2：原/替/重放/avoid的同轮预测资源差。
- 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb：预测候选阶段审计；fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执。
- aad2700abed6dff1d66e87fb36aaa6fedb39adf3：实验体当前阶段/组件/已建能力。
- a32050fbce4c2863f640468c2dbf378fc9157074、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933：离线相邻观测、终态与轮端点。

当前进阶DB读取、房间代价5样本门槛、逐击污染、成长和阶段重置路径已核。接口存在不替代六局旧dirty调用输入，也不将多个窄祖先合成为宽提案implemented/duplicate。逐项证据局号/层/回合/全部账本、反例、旧/预期行为、验证和回退见proposal.md：

- silent-proposal-c20b5139dd0dff71：waiting；缺原运行实际读取的A10移动表冻结字节，以及火花增长、污染清除、毒/弱/挡联合后继的生产校准；不能据9损新增禁技能规则。
- silent-proposal-ae9e692d680e3819：waiting；缺逐实体抢夺累计的显式真值、可靠实例连续身份、遗忘退场返敏及再次抢夺的完整固定链；不能用敌方总属性代填被抢数。
- silent-proposal-52f1e1bd2e7db0ed：waiting；缺原调用A10移动表字节与加压/覆甲全过程的联合校准；本局缺已知SL尝试元数据，严格消费者没有认证完整轮。
- silent-proposal-6dd8bbff876be528：waiting；缺原移动表、可靠召唤代际身份与连续后继的冻结生产校准；现有成长接口不认证跨代重置或统一集火收益。
- silent-proposal-578e415a259e6835：waiting；缺全部重规划后的逐候选续步身份，以及沙坑/能力和路线资源逐来源结算；现有消费者明确不认证完整候选，不能拼接窄子项关闭整项。
- silent-proposal-c0767768bf6a7ab1：waiting；缺整候选实际续步与血价归属、同抽序完整替线及独立整战验证；全败有限样本并列不足以拟HP惩罚常数或禁止探索。
- silent-proposal-a46bdb7fe711d79a：waiting；缺逐候选即时施毒/已结算毒、额外扣血与敏捷取得顺序的来源归属，以及完整派发结果的联合认证。
- silent-proposal-1044224808015e5c：waiting；缺同抽序完整替线、成长兑现后继与独立整战胜线；不能据两组当轮端点拟低血优先门槛、HP常数或禁止付血探索。
- silent-proposal-7cbc6005db712ba9：waiting；缺逐候选拆分原有/新增挡、朝向/弱、已结算毒与存活HP的统一来源校准；现场参考不等同完整执行模型。
- silent-proposal-c59f592f1427a67e：waiting；缺逐来源资源账、所有重规划后完整候选归属、路线/药水时机及受控整战后继；不能以多个窄事实替代原宽请求交付。

## 记录、测试与交接

本批仅经根learner/ledger.py update为30个既有账本补本批proposal/report追溯。没有新发现，不新建提案ID，不重复support/repeat，不更改claim、first_run、asc、prior、evidence、status、version、shipped或effect；旧shipped不降级。根专用队列由原调度器按proposal_results处理，本任务不手改。CLI及原前缀/逐物理行核验另存ledger-cli.json/ledger-verification.json。

未改源码：撤源码失败/恢复通过不适用；tsc=null、vitest=null、cases=null，未跑生产沙箱套件，也未借用原测试称本批绿色。fixes=[]、merged=null，无源码commit、合入commit、eval版本或shipped；没有live合入步骤需要执行。其他角色对局行为等价。

过程材料失败保留：校验草稿假定runs和其他流共用旧manifest，实际旧runs在evidence-runs独立目录；KeyError原日志、源码初稿保留，修正后8274行全部核验通过。两次只读路径猜测不存在及进程探测未匹配也保留执行历史，不作为产品缺陷或源码红绿。

没有新科学异议/反证，不重复发送旧学习通知，不代任何角色确认。不关闭宽父学习要求，不声称经验已入库、自然消费者已采用或策略获益。

运维交接proposal：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-155957/learner/runs/20261017-160007-0cac0e4c-974d-4ee3-a88b-a59da150ad9d-strategy-proposal/proposal.md；report：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-155957/learner/runs/20261017-160007-0cac0e4c-974d-4ee3-a88b-a59da150ad9d-strategy-proposal/report.md。十个原ID均有waiting理由，待所列新输入重派。保持工作树干净；原日志、失败与初稿保留，结束交原调度器验收回收。

最终材料验收（2026-10-17T16:13:39+08:00）：39项通过；30条根CLI追溯逐物理offset/bytes/SHA核验及旧账本前缀保持，所有保护字段未变。根ledger check退出0，gitleaks红化扫描退出0/发现0；HEAD及工作树/index干净。详见material-validation.json、ledger-verification.json及secret-scan-receipt.json。生产tests三项仍为null。

## 复盘：run DUZUBAJ3A8GP — 阵亡，最高第 30 层

- 决策 602 个；Jev 调用 84 次，Claude 0 次，大脑 28 次（codex 28）；token 426,404 入 / 4,320 出，约 $0.0181（Jev）；大脑 token 3,480,565 入（缓存命中 2,140,672，62%）/ 8,926 出；用时 31.8 分钟
- 决策者：code 306，jev-plan 171，jev 84，codex 41

### 战斗掉血（按层）
- 第 2 层 毛绒伏地虫: HP 56→56（-0），决策 code 16，jev-plan 5，jev 3
- 第 4 层 缩小甲虫: HP 56→56（-0），决策 code 14
- 第 5 层 小啃兽: HP 56→56（-0），决策 jev-plan 10，code 7，jev 3
- 第 6 层 小啃兽: HP 56→38（-18），决策 code 13，jev-plan 4，jev 2
- 第 7 层 蛮兽: HP 38→29（-9），决策 code 13，jev-plan 9，jev 4
- 第 8 层 方柱构装体: HP 34→29（-5），决策 code 14，jev-plan 7，jev 5
- 第 14 层 树叶史莱姆（中）/树叶史莱姆（小）/树枝史莱姆（中）/树枝史莱姆（小）: HP 51→52（+1），决策 jev-plan 6，jev 1，code 1
- 第 17 层 同族信徒/同族神官: HP 71→34（-37），决策 jev-plan 25，code 18，jev 13
- 第 19 层 地道虫: HP 64→30（-34），决策 jev-plan 9，code 8，jev 3
- 第 21 层 外骨骼虫: HP 35→45（+10），决策 jev-plan 7，code 7，jev 3
- 第 22 层 幼虫/直飞产卵虫/结实的卵: HP 45→33（-12），决策 jev-plan 10，code 8，jev 5
- 第 27 层 感染棱柱: HP 82→26（-56），决策 jev-plan 14，code 11，jev 9
- 第 29 层 残杀千足虫: HP 68→21（-47），决策 jev-plan 13，code 12，jev 9
- 第 30 层 熟睡甲虫/盛碗虫（丝）/盛碗虫（石）: HP 21→0（-21），决策 jev-plan 52，code 38，jev 24

### 死亡战斗：第 30 层 熟睡甲虫/盛碗虫（丝）/盛碗虫（石）
- T4 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 小刀 -> 熟睡甲虫
- T4 [code] combat/plan: code plan (only line): end turn; hp -4, dmg 10
- T5 [jev] combat/plan-choice: Jev chose plan 1/2 (防御, 致命毒药 -> 熟睡甲虫, 尖啸, 蜃景) with confidence 0.92; code rank 1 conf 0.92
- T5 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 致命毒药 -> 熟睡甲虫
- T5 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 尖啸
- T5 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 蜃景
- T5 [code] combat/plan: code plan (only line): end turn; hp -0, dmg 11
- T6 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-5): 回响斩击, 爆发, 打击 -> 熟睡甲虫, 生存者
- T6 [code] combat/plan-continue: continuing the code-chosen plan: 爆发
- T6 [code] combat/plan-continue: continuing the code-chosen plan: 打击 -> 熟睡甲虫
- T6 [code] combat/plan-continue: continuing the code-chosen plan: 生存者
- T6 [code] combat/end_turn: no playable cards; ending the turn

### 各类决策由谁做
- combat/plan-continue / jev-plan: 171
- combat/plan / code: 91
- combat/plan-choice / jev: 76
- combat/plan-continue / code: 55
- reward/claim / code: 35
- map/route-follow / code: 26
- selection/discard / code: 20
- combat/lethal / code: 17
- reward/card / codex: 13
- reward/proceed / code: 13
- selection/confirm / code: 11
- selection/choose / jev: 7
- shop/buy / codex: 6
- event/leave / code: 5
- rest/plan / codex: 5
- rest/proceed / code: 5
- combat/end_turn / code: 4
- combat/least-loss / code: 4
- chest/open / code: 3
- chest/proceed / code: 3
- chest/relic / code: 3
- event/plan / codex: 3
- map/route-change / codex: 3
- shop/leave / code: 3
- shop/open / code: 3
- shop/plan / codex: 3
- event/choose / codex: 2
- selection/remove / codex: 2
- combat/plan-choice+potion / jev: 1
- event/act-plan / codex: 1
- map/route-follow / codex: 1
- map/route-only / code: 1
- map/route-plan / codex: 1
- run/finalize / code: 1
- selection/free-card / code: 1
- selection/take into my hand / code: 1
- selection/take-planned / code: 1
- selection/upgrade / codex: 1

### 兜底介入（Claude/DeepSeek）：0 次（推翻 Jev 0 次）

### Jev 低置信度（<0.35）决策：7 个
- 第 6 层 combat/plan-choice: Jev chose plan 2/2 (打击 -> 小啃兽 #1, 打击 -> 小啃兽 #1, 打击 -> 小啃兽 #2) with confidence 0.02; code rank 2 (0.02)
- 第 17 层 combat/plan-choice: Jev chose plan 5/5 (背刺 -> 同族信徒 #1, 猎杀者 -> 同族信徒 #1, 防御, 切割 -> 同族信徒 #1, 打击 -> 同族信徒 #1) with confidence 0.33; code rank 5 (0.33)
- 第 17 层 combat/plan-choice: Jev chose plan 2/4 (中和 -> 同族神官, 防御, 防御, 小刀 -> 同族神官) with confidence 0.33; code rank 2 (0.33)
- 第 19 层 combat/plan-choice: Jev chose plan 5/5 (背刺 -> 地道虫, 猎杀者 -> 地道虫, 打击 -> 地道虫, 切割 -> 地道虫, 打击 -> 地道虫) with confidence 0.34; code rank 5 (0.34)
- 第 30 层 combat/plan-choice: Jev chose plan 2/3 (生存者, 防御, 带毒刺击 -> 熟睡甲虫, 防御) with confidence 0.34; code rank 2 (0.34)
- 第 30 层 combat/plan-choice: Jev chose plan 1/2 (带毒刺击 -> 盛碗虫（石）, 斗篷与匕首, 致命毒药 -> 盛碗虫（石）, 尖啸) with confidence 0.14; code rank 1 (0.14)
- 第 30 层 combat/plan-choice: Jev chose plan 3/3 (带毒刺击 -> 熟睡甲虫, 小刀 -> 熟睡甲虫) with confidence 0.13; code rank 3 (0.13)

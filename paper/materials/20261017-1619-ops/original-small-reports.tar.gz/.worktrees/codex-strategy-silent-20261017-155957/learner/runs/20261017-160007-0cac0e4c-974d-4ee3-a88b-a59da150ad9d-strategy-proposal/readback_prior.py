import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-144302/learner/runs/20261017-144307-a376ee27-f3d5-45d8-9ab4-551bd57576f0-strategy-proposal')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


assert all(row['same_selected_output_as_prior'] for row in json.loads((OUT / 'raw-verification.json').read_text()))
assert all(row['same_bytes'] for row in json.loads((OUT / 'consumer-source-comparison.json').read_text()))
scopes = json.loads((OUT / 'consumer-input-scopes.json').read_text())
assert all(row['same_input_as_prior'] for row in scopes)
summary = {row['run_id']: row for row in json.loads((PRIOR / 'consumer-summary.json').read_text())}
exits = {row['run_id']: row['exit'] for row in json.loads((PRIOR / 'consumer-exits.json').read_text())}
reused = []
for scope in scopes:
    run = scope['run_id']
    path = PRIOR / (run + '.consumer-output.json')
    output = json.loads(path.read_text())
    item = summary[run]
    assert exits[run] == item['exit'] == 0
    assert len(output['segments']) == item['segments']
    assert len(output['observed_actions']) == item['actions'] == scope['decisions']
    assert all(row.get('actual_full_candidate_result') is None for row in output['segments'])
    reused.append({'run_id': run, 'mode': 'verified_prior_output_reused_no_consumer_rerun',
                   'prior_output': str(path), 'prior_output_sha256': sha(path),
                   'prior_exit_receipt': str(PRIOR / 'consumer-exits.json'),
                   'prior_exit': exits[run], 'input_sha256': scope['input_sha256'],
                   'verified_summary': item})
save('consumer-reuse.json', reused)

states = {row['line']: row for row in map(json.loads, (OUT / 'evidence/states.evidence.jsonl').open())}
old = json.loads((PRIOR / 'verified-facts.json').read_text())
frames = old['mechanism_frames'] + old['key_states']
checks = []
for frame in frames:
    current = states[frame['line']]
    assert current['sha256'] == frame['sha256'] and current['run_id'] == frame['run']
    state = current['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    observed = {'line': current['line'], 'sha256': current['sha256'], 'run': current['run_id'],
                'floor': state['run'].get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
                'hp': player.get('current_hp', state['run'].get('current_hp')), 'block': player.get('block'),
                'powers': {p['power_id']: p.get('amount') for p in player.get('powers', [])},
                'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                             'max_hp': e.get('max_hp'), 'move': e.get('move_id'),
                             'powers': {p['power_id']: p.get('amount') for p in e.get('powers', [])},
                             'intents': e.get('intents')} for e in combat.get('enemies', [])]}
    assert observed == frame
    checks.append({'line': current['line'], 'sha256': current['sha256'], 'matched': True})
save('mechanism-frame-readback.json', {'source': str(PRIOR / 'verified-facts.json'),
                                     'source_sha256': sha(PRIOR / 'verified-facts.json'),
                                     'checks': checks, 'mechanism_frames': old['mechanism_frames'], 'key_states': old['key_states']})
save('prior-receipts.json', {name: {'path': str(PRIOR / name), 'sha256': sha(PRIOR / name)}
                            for name in ['consumer-exits.json', 'consumer-summary.json', 'verified-facts.json', 'material-validation.json']})
print(json.dumps({'mode': 'prior_output_readback_not_rerun', 'consumers': len(reused),
                  'mechanism_frames_read_back': len(checks),
                  'segments': sum(row['verified_summary']['segments'] for row in reused),
                  'verified_turn_endpoints': sum(row['verified_summary']['turns_observed'] for row in reused)}, ensure_ascii=False))

# 本批策略提案复核报告

本批10项均waiting：六局证据支持局部事实，仍不足以关闭原宽提案或改变策略。没有生产代码、知识或行为变更，没有新提交、live合入或发布号。原提案及父学习要求保持待证。

基线/最终HEAD：`33b82e2d1e16cad58ceec34877dde2b9845eb593`。工作树：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261014-231302-s2`。批次：20261014-231302-s2-strategy-proposal。

已先读README、STATE-2026-10-14、decision-log末尾、学习协议和代码提案协议。git初始干净；本批普通领取10项，无专题/实现绑定；普通merge main无变化。未读取其他角色知识、游戏二进制、key或.env，未联网/启动游戏/派agent/推送。

用户指定普通模式/high；没有可调用接口核验或修改本原生模型请求参数，未把仓库默认设置或旧对局配置当成本会话运行参数已核。未变更账号、权限或调度输入。

## 证据范围

| 流 | 本批原行数 | 冻结源字节截点 |
|---|---:|---:|
| states | 4062 | 12807237089 |
| decisions | 3941 | 1421570568 |
| sl-attempts | 38 | 39330624 |
| run-config | 6 | 1700723 |
| run-plans | 33 | 7786222 |
| runs | 6 | 328958 |

合计8,086原行：4,062状态、3,941决策、38 SL、6配置、33计划、6终态。每行均重新从根logs按offset/bytes读取，对SHA和解析内容；所有流输出SHA、逐局计数及身份均核实。全源states/decisions各有2条无效JSON，提取器拒收；不猜其局归属。没有用正文提及局号认身份，没有覆盖旧截点报告。

六局均SILENT/A10且失败：DUZUBAJ3A8GP/F30、5PM6JAQG6FNQ/F39、CA5KE8GFJ9X2/F13、8JRE1C4H4Z2W/F33、YF0LXT1QSTGG/F48、XP2SL33HT0D9/F33。详细原运行提交、dirty文件、终态时间见verified-evidence.json；本批不复验原宽提案的全101局或其他早期角色样本。下文s表示states原行号，d表示decisions原行号。

## 逐项处置

| 原提案ID | 证据局/层/回合 | 状态及具体缺口 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | DUZUBAJ3A8GP F27 T4—5；s274830—274838 | waiting：缺冻结移动表及火花增长、污染撤除、虚弱和迷雾收益的同一多步生产重放；不能由本轮9血价推出少打技能规则。 |
| silent-proposal-ae9e692d680e3819 | 5PM6JAQG6FNQ F39 T4—6；s274351—274366、274391—274397 | waiting：缺混合增益时逐来源抢夺账、遗忘死亡返敏的非清场端点和完整候选校准；不能把敌当前全部力量/敏捷返还玩家或固定击杀序。 |
| silent-proposal-52f1e1bd2e7db0ed | CA5KE8GFJ9X2 F13 T1—5；s273237—273269 | waiting：缺历史dirty移动表和加压/覆甲/弱的生产多步重放、减层触发隔离；不能改固定房间成本或宣称完整覆甲条件已证。 |
| silent-proposal-6dd8bbff876be528 | 5PM6JAQG6FNQ F38 T3—4；s274308—274317 | waiting：缺召唤前后稳定实例身份、增长计数重置和实际移动模板重放；另一击杀序未实打，不能将候选少损27计作实际收益。 |
| silent-proposal-578e415a259e6835 | 8JRE1C4H4Z2W F33 T2、T11；d270216/270282，s276433/276434 | waiting：缺完整候选身份、抽弃牌重问后的续步执行归属及受控后继；0016是覆甲账本，原金刚杵错链不能重新支持或关闭宽项。 |
| silent-proposal-c0767768bf6a7ab1 | YF0LXT1QSTGG F48 T1及F33反例；d271309/271348，s277327—277373 | waiting：缺完整候选续步归属、同抽序同预算整战反事实及后移独立验证；不能拟合SL血价系数或禁止探索。 |
| silent-proposal-a46bdb7fe711d79a | YF0LXT1QSTGG F48末试T3—5；s277512—277528 | waiting：缺延迟施毒、抽弃牌及后取得敏捷在完整候选中的传播与生产联合校准；不能强制能力先手或预支未来毒伤。 |
| silent-proposal-1044224808015e5c | XP2SL33HT0D9 F33首/二试T3、首/末试T1；d271992/272040、271982/272195 | waiting：缺完整候选执行归属、配对随机池/预算与独立双蟹整战胜线；B2零差或零标准误不支持更改并列探索优先级。 |
| silent-proposal-7cbc6005db712ba9 | XP2SL33HT0D9 F33末试T2—5；s278236—278261 | waiting：缺轮初挡、减力恢复、朝向/弱和攻次成长的整候选联合传播与消费者校准；不以局部已实现冒认整个提案duplicate。 |
| silent-proposal-c59f592f1427a67e | YF0LXT1QSTGG F48 T1—5；XP2SL33HT0D9 F33 T1—5；账本所列各子域 | waiting：缺各子域完整候选实果、联合校准和受控路线/留药后继；历史支持总数不能替代独立因果分母，不改成长或终局权重。 |

每项账本ID、支持/反例、旧/拟行为、验证、拟合/时间切分与回退详见proposal.md；十原Markdown的SHA全部与队列保存值相等，副本未改写。code_proposals回报沿用原10个CLI ID，不另建重复ID、不改原队列租约或手动填implemented。

## 事实核验与消费者读回

本批verify_facts.py的36项断言通过，含污染、加压、增长、抢夺/返力、阶段清空、零毒触媒、先造挡后增敏、临时减力恢复、朝向与弱、攻次成长和终局零血截断。fact-checks.json保存数值及原行，fact-checks.log保存执行结果。这是证据核验，不是生产源码撤码红绿。

| 同指纹窗口 | 原/替线观测损血 | 原/替线敌本体净扣 |
|---|---:|---:|
| 8JRE1C4H4Z2W F33 T2 | 3 / 15 | 10 / 17 |
| YF0LXT1QSTGG F48 T1 | 0 / 9 | 45 / 38 |
| XP2SL33HT0D9 F33 T3 | 9 / 14 | 24 / 27 |
| XP2SL33HT0D9 F33 T1 | 2 / 10 | 25 / 34 |

这些是同起点当轮观测窗口，SL同存档高度相关。未控制后续抽序/生成/重规划，不能把净HP窗口归于完整候选或用整战回合数证明某张牌的因果收益。沙虫终局5→0仅实扣5；37−22=15为显示攻击/挡算术；敌154→130单记24净扣。

本批用当前既有learner/lib/selection-execution.ts消费者读取冻结单局输入，得到3937个有ID动作、641个选线片段、1353个可核区间/2584个未知区间、186个整轮端点/450个未知轮组及5个核实终局端点。actual_full_candidate_result全部null，不把派发completed、题内最佳、原始窗口净差当作整候选执行或收益认证。

DUZ有3条、CA有1条map/route-change元数据缺decision_id，原完整输入按现有校验拒收；错误保存在各consumer.json.gz与consumer-summary.json。其后只在每个缺口两侧分别处理有界块，原_line不重编号，不跨缺口连接。其余4局完整输入可读；CA可核区间为0，不解释为没有原始状态。输入/输出以gzip保存并由consume.mjs直接解压消费；未调LLM、网络或刷新知识JSON。

## 源码与上线边界

当前live核对切点为`1e4be6b85e2d19e7e4dde8f0b5846846e06b250e`。source-audit.json保存19个相关源码叶的base/live blob、SHA及最后修改提交的实际live祖先检查，19项祖先均真；16叶字节相同，3叶只差Roy→Dai署名注释，完整差异见base-live-source.patch/source-comparison.json。

| 已有子项 | 实际live祖先源码提交 |
|---|---|
| agent/src/reflex/silent-selection-audit.ts | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb |
| agent/src/reflex/silent-selection-dispatch.ts | fdaf787a372880b0438e73bcac7e6d2168b038ed |
| agent/src/reflex/silent-phase-current.ts | aad2700abed6dff1d66e87fb36aaa6fedb39adf3 |
| learner/lib/selection-execution.ts | a32050fbce4c2863f640468c2dbf378fc9157074 |
| learner/lib/selection-terminal.ts | 83512ddcd2c70fd9b983dc38524ff25c8970c1d3 |
| learner/lib/selection-turn.ts | e75438488df159b2e8e9d3458cf219b39aadd933 |

这些提交只证明已有窄实现，不关闭十个原宽项；本批不认领为自己的implemented/duplicate、源码提交或合入。原历史dirty知识输入未完整冻结，不冒称当前生产模型等于原运行树。当前进阶怪物HP/攻击的首样本读取与房间代价5样本门槛保持；不更改其他角色/进阶、药水、SL或终局参数。

0016原错链继续明确：silent-0016是覆甲耗尽，不能当作金刚杵来源；原proposal原文与已有勘误均保留。本批没有新增与旧知识不同的游戏结论，不重写历史复盘、不新增反证通知或代填ops/watcher/Roy确认。

无源码改动，因此撤源码失败/恢复通过、tsc、vitest与生产测试cases全部不适用/null；没有运行test-sandbox或借用历史成功值。36项证据核验和消费者执行exit0独立记录。无源码提交，未进live合入流程、不造merged、eval版本或shipped；无需为记录报告停止当前对局。

## 记录与可复核材料

proposal.md为运维接续入口；report.md为本报告。ledger-updates.jsonl只对既有30个silent账本条目追加本批proposal/report追溯，by=learner:strategy-proposal，不改claim/first_run/prior/status/evidence/version，不新增支持计数、不把旧shipped条目降级或将本批标shipped。只经根learner/ledger.py update执行，回执见ledger-update.log及ledger-readback.json；本批没有新游戏提案需要CLI add。

过程定位曾误用不存在的selection文件名、一次非战斗combat=null的临时查看触发AttributeError；随后依据rg --files与空值守卫更正。原工具输出保留在本会话记录；这是只读定位错误，不是生产源码失败。完整输入缺ID的拒收属于预期边界，未放宽原校验。

关键材料：dispatch.json、assigned-proposals.json、十份*.original.md及original-proposal-hashes.json；evidence/evidence-manifest.json和*.evidence.jsonl；verified-evidence.json/verification.log；focused-states.json/fact-checks.json；六份*.input.json.gz和*.consumer.json.gz、consumer-summary.json/consumer.log；source-audit.json/base-live-source.patch/baseline.patch；ledger CLI材料；result.json。

gitleaks结果及最终HEAD/干净状态由final-verification.json、gitleaks.log和gitleaks.json记录。scratch由gitignore排除，留存交原调度器验收回收；不删除自身工作树。

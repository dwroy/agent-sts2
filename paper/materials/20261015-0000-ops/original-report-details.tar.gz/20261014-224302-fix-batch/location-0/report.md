## 修 bug 回报
- 合并基线：main → f1f431e88e8e613aed599c521d616b6c08d187b3
- 修复（每条一行）：无，本批无新增源码修复
- 已被别人修掉的：fight-value 构建器 observe_combat 参数缺失 — aba384cc503e53001933fceb688e9d2c24442b19
- 已被别人修掉的：失败的大脑调用记录零耗时和零用量 — 531d15444f5e9c29d85d36ff098f3fbf33e647af
- 已被别人修掉的：大脑失败及回退的耗时、用量与引擎归属 — fc5b2e5e6314c40590dd976189d0137309383c6b
- 已被别人修掉的：SL 日志把低血走廊标为 elite — af6f07adfee1ad62ec85d613ab36a7b11857ce89
- 已被别人修掉的：outcome-stats 刷新后进程仍读旧缓存 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537
- 已被别人修掉的：fix-batch/experience-update 旧队列及 v3 合入模板 — afd652a3f75df6e7403439f01c565220327884da
- 已被别人修掉的：DeepSeek 题面导出整读超大 states 日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093
- 已被别人修掉的：tsc 纳入 learner/runs 临时源码 — 7bc835803f2efd44a5cc6f2009933f3c3bee7653
- 已被别人修掉的：兜底合入后缺宿主完整检查入口 — f670884a188a047bbd3f7f007c260ade62fae36a
- 已被别人修掉的：单次 mod 超时误报持续卡死 — a4f4ec868d122dc92af510862c6240cf2eaff2b6
- 已被别人修掉的：账本无法追加更正来源元数据 — 87c89b7aea90c7275e0fbb04b1e4148a4209630c
- 已被别人修掉的：长检查阻塞学习状态锁 — 233ede56047274ba53a4e1191a245fac816c37a8
- 已被别人修掉的：额度测试错误依赖已设置 TMPDIR — 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a
- 已被别人修掉的：rollout/target-options 单调截止传播 — 9889436c3b332a3984cdb7f850a1349f464182d1
- 已被别人修掉的：无新增修复的成功批次被误标失败 — 01b560ef4966da945511bfccd41abd09440fb0e9
- 已被别人修掉的：历史大脑测试入口漏传日志回调 — ccd8bb8e017da9c30b408138d04e6d2bc985836d
- 已被别人修掉的：silent-0254 无决策死亡战斗错误归因 — 3b48088dec5fc6eafe576a1296bbdadde43432ee
- 已被别人修掉的：rollout 最佳线路固定测试的时钟与知识隔离 — bbc5b993a7524bbb8e80a975f204f8d193657b46
- 已被别人修掉的：codex-usage-credit-baseline-recovery — e5e2995d659d15af79ec8bba67a4a25c1cb7295f
- 已被别人修掉的：升阶通知及审计误用请求目标进阶 — 8045d9fbf0a12523b1dbe39bbed8af06c7497b09
- 已被别人修掉的：host-checks-broker-push-registration — c519952b31e3a0bb3acdd2115883ae8671b8a090
- 已被别人修掉的：host-checks-session-exit-fixture — 874ae603b3927173f805e0b2fe789330bab710c7
- 已被别人修掉的：host-targeted-check-continuation 固定分段补验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316
- 已被别人修掉的：调度夹具缺生产 feature 路径 — 2b09c47d431a580e9955d157f4dfb0e576186206
- 已被别人修掉的：sandbox-glob-startup-race 会话前有界恢复 — bc2c40e313cc36682196277c53c50e30744b88c5
- 已被别人修掉的：blocked-experience-proposal-repair-dispatch — 84366ad06ee4f978394c1b9489a82c83ea12bd36
- 已被别人修掉的：multi-character-potion-table-fixture-isolation — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1
- 已被别人修掉的：compute-memo-worker-data-signature 固定知识输入 — 8fbb441eb61eef226eb7366f9612003480c83988
- 已被别人修掉的：unassigned-strategy-proposal-resolution — 3a98e213a826e94f9708af4b1a265e1892659f4e
- 已被别人修掉的：ops-stall-recovery 测试执行及诊断确定性 — 9b6459fd99f26b17689134e33aa85d6190e71d7d
- 已被别人修掉的：batch-c-fixed-fixture-timeout — 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff
- 已被别人修掉的：host-fixed-test-timeouts-010547 评估版本夹具 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7
- 已被别人修掉的：paper-dataset-git-consistency-race — 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f
- 已被别人修掉的：boss-sim-codex-home-preflight — 5921f8cd045853182c867a6430e75c3fcde00a87
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301 — b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa
- 已被别人修掉的：工作树磁盘容量预检与历史副本共享 — c7a6efb1e15ed6c5f31a35ae3ee9833863340393
- 已被别人修掉的：broker 容量及请求回执失败隔离 — a136ddc4b5b0a8696f10b2fae3073322d57e724c
- 已被别人修掉的：普通通知 ACK 误查不存在的父要求 — 672e198a4730012330f599068a0ef1efadb02002
- 已被别人修掉的：无产出失败复盘误派提案补链 — 3fdcd77927f01b35c20c6c5c1fcfd790676032d2
- 已被别人修掉的：普通通知 ACK 前阶段回执再校验 — 1594def2e1b65b665d3b345f31444194eb4d09e6
- 已被别人修掉的：会话前恢复遗漏纯时间戳复盘租约 ID — d9983263ffecea1bed4e29d65e7f854a3d2e33d7
- 已被别人修掉的：历史牌组夹具与新 deck cap 的隔离 — ec8c578b66bf5498372f1b779ae58a766dff8112
- 已被别人修掉的：公共经验固定文件快照兼容 — 8390c62d76fc8c7d7b6b7292121a621f4666d39c
- 已被别人修掉的：普通通知 ACK 第二策略槽批号兼容 — 15eb85e2934e428c5e299fc4a1aba456d92fd685
- 已被别人修掉的：持药固定时钟与知识隔离 — 8867041f57f0e511606127e568603510af59a0e7
- 已被别人修掉的：锁夹具异步有界等待 — e770a6d09a8398aee4126f1b7ea37fc70687989f
- 已被别人修掉的：首 token 前长思考及路径拒绝进程夹具 — a18376cce22eb9e47377d474a85fb864f7c636e2
- 已被别人修掉的：可重建 Python 缓存阻塞回收 — 1e8af775f6b90f100f20ff7c4a08dfddaba893a9
- 已被别人修掉的：合法校准 feature 通知来源校验 — 38b2f572d90b3b97a23f9eae983f583287492f9a
- 已被别人修掉的：宿主长参数题名承载 — f8896692b0d868b900ccffc8ed910321d0f3e765
- 已被别人修掉的：升阶报告批量异步固定解析夹具 — a11e32ae1a01ecf75cc57519be21f2d144c2cd18
- 已被别人修掉的：研究调度固定分组夹具 — cd1f5593430a2d13479368679b5d42994540f7c8
- 已被别人修掉的：随机药水固定板重复性夹具 — 519b63549f1c61276755066e5a76d0351cf09a7c
- 已被别人修掉的：rollout 排序及自动动作固定矩阵夹具 — b68a650ab95c15a492cccac598906f32284229be
- 已被别人修掉的：包装/参数化测试的静态期限解析 — 56c256dad0d33b231b82b53113d3bdd84f9bfa20
- 已被别人修掉的：feature producer 到 canonical notice 身份桥接 — 1dd4d434aef67f1d065dbdba23a875ae82741a88
- 已被别人修掉的：run-plans 证据提取漏识别 run 字段 — 78e9b05929366d097a728761d693d790ff16ac87
- 已被别人修掉的：Jev 超限请求传输及 R342 合同替换 — 75249befaad497b68ffbdbf242c9e1672beba850
- 已被别人修掉的：strategy-proposal无源码回报scratch归属闸 — 5f04139cefe5c651dd5bf62f7e164014dbf5f23b
- 已被别人修掉的：status查询在PID沙箱误将宿主活复盘标lost — e04cffa915cfa0b2120f1e087efc0627dae9ad2e
- 已被别人修掉的：autoplay无法写终态标记时持续等待 — db072ddab47ba94efb46dce2913927f936ecb97e
- 已被别人修掉的：JSONL中断尾部与新记录粘连 — 9b07240b18f862efdbe630889ade04e8976eaace
- 没修的：游戏机制、出牌、药水、SL、终局及结构模型（含silent-0311/0459/0465/0467/0469/0471/0474/0477） — 策略类；保留已注册strategy-proposal链与原证据，不在普通纯bug批次实现或重复派发
- 没修的：arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression / 独立缓存及校准研究 — 独立功能/研究，超出普通纯bug批次，保留原拥有者
- 没修的：sandbox-glob-startup-race上游目录生命周期 — 证据不足；有界恢复与复盘租约子项已修，具体目录删除者及上游根因未证
- 没修的：调度公平性核查 — 证据不足；原插入序现象不能证明永久饥饿，保留原核查范围
- 没修的：core-build-notify-222802-rc2 — 证据不足；保留原native rc2及诊断，本任务不重放外部通知
- 没修的：v5-dpr-health-20261013暖池性能 / R1-R2 / P1-P2 — 独立研究已有原线程拥有者；执行和传输子项已修，不关闭性能父项
- 没修的：框架外层总时限收尾 — 原分段宿主补验入口24c2e3a75已修；原包装器及精确覆盖收尾由框架拥有者接续
- 没修的：本批验证出现的learner-raw-report固定子进程status=null — 证据不足；原5000ms子进程首次返回null、日志未记error/signal；同源码重跑原15项全过，不据此改生产或放宽测试，保留首轮失败
- 测试：tsc退出码0；沙箱首轮404文件/3888用例（3887通过、1失败）/退出码1。learner-raw-report.test.ts 的 recognizes a raw completion only after verifying its live ancestor 首轮固定Python子进程status=null、单项5463ms；同源码单worker复测该文件15项并补paths11项，2文件/26项/退出码0。去重覆盖405文件3899项；首轮完整命令仍记1，不冒称一次完整全绿。gitleaks原材料扫描0。
- 合入：未合入；本批没有新增源码提交。上述62个已有修复提交均核为main/live祖先，最新scratch修复实际发布live059bf4cfb3ab843754f4c26a38c70942a8940408由原owner完成。
- 需要 Roy 定的事（没有写「无」）：无。

核查说明：开工工作区干净并先合main，初始基线4ae762386e6bf43696caf4328917c008f4ba804d。核到其他批5f04139ce同项修复新进入main后，先保存本批重复初稿及所有失败/通过日志，再撤回初稿，干净fast-forward到所列base。当前源码保留中央事件流、工作树内scratch及父symlink越界拒绝；未改no_change原路径闸。原批源码红绿不算本批新增修复。无本批账本更新、提案追加、行为版本或上线记录。

队列核查截点最初1284行，后追加至1286行仅为原scratch同项上线回执，见queue-latest-readback.json；未修改原队列。既有游戏模型与策略链不重复实现、派发或关父要求。

初稿记录：首次测试夹具固定UTC与本地stamp不一致，4项失败；改为固定本地时间后两文件28项通过。随后整份初稿撤回，原件以.txt/.patch保存在指定scratch，见draft-provenance.json；这些结果不当最终树验证。

验证原件：final-sandbox.log保留首轮退出1；failed-file-and-paths-recheck.log保留定向退出0；queue-source-ancestry.json含62条main/live祖先核验。沙箱首轮set-e在Vitest退出1后未跑paths，由定向复测补齐；未扩大排除名单、抬超时或改断言。

```json
{"task": "fix-batch", "base": "f1f431e88e8e613aed599c521d616b6c08d187b3", "fixes": [], "skipped": [{"item": "游戏机制、出牌、药水、SL、终局及结构模型（含silent-0311/0459/0465/0467/0469/0471/0474/0477）", "reason": "策略类；保留已注册strategy-proposal链与原证据，不在普通纯bug批次实现或重复派发"}, {"item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression / 独立缓存及校准研究", "reason": "独立功能/研究，超出普通纯bug批次，保留原拥有者"}, {"item": "sandbox-glob-startup-race上游目录生命周期", "reason": "证据不足；有界恢复与复盘租约子项已修，具体目录删除者及上游根因未证"}, {"item": "调度公平性核查", "reason": "证据不足；原插入序现象不能证明永久饥饿，保留原核查范围"}, {"item": "core-build-notify-222802-rc2", "reason": "证据不足；保留原native rc2及诊断，本任务不重放外部通知"}, {"item": "v5-dpr-health-20261013暖池性能 / R1-R2 / P1-P2", "reason": "独立研究已有原线程拥有者；执行和传输子项已修，不关闭性能父项"}, {"item": "框架外层总时限收尾", "reason": "原分段宿主补验入口24c2e3a75已修；原包装器及精确覆盖收尾由框架拥有者接续"}, {"item": "本批验证出现的learner-raw-report固定子进程status=null", "reason": "证据不足；原5000ms子进程首次返回null、日志未记error/signal；同源码重跑原15项全过，不据此改生产或放宽测试，保留首轮失败"}], "merged": null, "tests": {"tsc": 0, "vitest": 1, "cases": 3888}, "code_proposals": [], "implementation_domains": [], "report": "/home/dw/Projects/agent-sts2/learner/runs/20261014-224322-fix-batch/report.md", "recheck": {"vitest": 0, "files": 2, "cases": 26, "file": "agent/tests/learner-raw-report.test.ts", "case": "recognizes a raw completion only after verifying its live ancestor", "paths_completed": true}}
```

# 静默策略提案：本批十项证据复核

记录时间：2026-10-14T23:26:12+08:00。batch=20261014-231302-strategy-proposal；base=33b82e2d1e16cad58ceec34877dde2b9845eb593。

本批仅消费十个原CLI id，均waiting；未新建提案、改源码或知识。六局全部由runs.jsonl及原状态核为SILENT/A10。以下是本批补充处置，不覆盖原提案。

## silent-proposal-89354805ee4d7e77

来源任务：postmortem；目标任务：strategy-proposal；原domains=combat, structure。账本：silent-0237, silent-0238。原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d，原字节副本已保存。

证据局/层/回合：VLZ6CCT8AQ0A A10 F35/T1、F43/T1–T2、F45/T1；states 275564/275565、275679/275680/275687、275728/275729；decisions 269706/269707/269748。

本批核验：F35神化实际耗能7→5，防御5→8、打击7→10、匕首雨5→7、工具1→0费；F43突然一拳9/1弱→11/2弱、勒紧4→6、尖啸6→8，后续毒雾已升级；场外deck升级数仍4。

反例与未知：F45药水只使能量1→2、抽牌，HP仍67；神化未施放，不能把持有当成已升级。本批没有同盘施放/不施放的整战胜负对照。

旧规则与预期行为：既有silent-apotheosis.ts只认证已观测普通/升级对；turn-solver已传播剩余手牌、保留牌和已知后续牌，复杂属性/重放保持未知。silent-apotheosis-reference.ts仍明确actual_cast_this_fight=null。预期是补真实施放持续身份和未知边界验证，不定必打优先级。

验证方法：已核六个原神化夹具与日志完全一致；后续须在同一生产调用链核实际施放、抽牌/选牌/药水重问及SL/换战清除，未见升级或属性组合保持未知。

处置：waiting。缺跨抽牌、选牌、药水、SL与换战的实际施放持续身份及生产读回；现有窄升级传播未验证全部属性组合。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-f2bfceddb1898dca

来源任务：postmortem；目标任务：strategy-proposal；原domains=combat, potion。账本：silent-0106, silent-0019, silent-0201。原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26，原字节副本已保存。

证据局/层/回合：VLZ6CCT8AQ0A A10 F45/T1、T4、T5，decisions 269748/269770，states 275728/275729、275752–275754；F44 states 275718/275719。

本批核验：首题药水MC实记1/12、707ms；rollout horizon=1、samples=1、best=null。药水实际+1能量且HP不变。F44实际33/99→67/104；末轮32血20挡，对尖啸后59攻击，完整需损39、算术差7。

反例与未知：退化和全败不同；少损线与攻击线是题面对比，未选完整后继没有实打结果。一次707ms不支持新的时间常量、留药价格或固定集火。

旧规则与预期行为：保留当前预算与资源规则；原提案允许先诊断成熟度、当轮代价和逐敌击杀缺口。现有记录能复核样本与预算，不能证明分阶段MC更好。

验证方法：需完整模型覆盖后的同起点、同随机池、同总预算配对，记录非药和药水候选样本成熟度、时间曲线与排序稳定性。

处置：waiting。缺完整模型下同起点、同随机池、同总预算的分阶段MC配对及候选稳定性曲线，不能由707ms样本制定新规则。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-283a164780d11e69

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat, structure。账本：silent-0237, silent-0238。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637，原字节副本已保存。

证据局/层/回合：VLZ6CCT8AQ0A A10 F35/T1、F43/T1–T2、F45/T1；与第一项同源实帧。

本批核验：原experience-update提案SHA独立核过，关联silent-apotheosis-combat-upgrades及silent-0237/0238；引用同一实际施放证据，不增加独立局分母。

反例与未知：文字主题重复不等实际live已完整实现；F45未施放也不构成已施放效果的反例。

旧规则与预期行为：沿第一项的升级状态和实际施放分账路径，不新建重复id、不重复改同一机制；当前完整实现仍未认证。

验证方法：同第一项固定实帧、持续身份和未覆盖交互验证；共同实现完成后再引用实际live祖先源码处置两原id。

处置：waiting。与第一项同源，但仍缺实际施放持续身份和未覆盖交互校准；没有完整live实现证明，暂不能登记duplicate。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-ebbfe3b97548756d

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat, structure。账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2，原字节副本已保存。

证据局/层/回合：VLZ6CCT8AQ0A A10 F43/T1–T5、F45/T3–T5、F44休息；states 275679/275680、275751–275754、275718/275719。

本批核验：本批核F45后空翻实增8、防御实增12，现场勒紧4/敏捷3且无覆甲；尖啸四段显示合计83→59；另两敌未中毒。F44即时HP+34、上限+5分别核实。原十五主题分别关联原账本，不把全部支持局当一次联合实验。

反例与未知：持有毒组件未证明已建立，临时减力未证明持续安全；休息后67血仍败不证明休息无用。原提案的全资源/路线或十五条历史子分母本批没有重新全量认定。

旧规则与预期行为：现有属性、专属挡、毒和期限模型继续使用现场值；不加统一血价、路线或目标优先级。神化升级由专属两项负责。

验证方法：需要逐子机制的当前进阶冻结调用，以及属性/升级/期限交互与战斗、路线、休息消费者联合核验；只有局部端点正确不关闭整项。

处置：waiting。缺十五条机制的属性组合、升级联动、状态期限及战斗/路线/休息消费者联合校准，局部端点和源码不证明全覆盖。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-e5b87be50f28f311

来源任务：postmortem；目标任务：strategy-proposal；原domains=combat, sl。账本：silent-0079, silent-0021, silent-0125, silent-0018。原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709，原字节副本已保存。

证据局/层/回合：8JRE1C4H4Z2W A10 F33首/第三试T2 decisions 270216/270282，第二试T5 decision 270264；F17/T6及末试F33/T11。

本批核验：270216/270282起点fingerprint逐字相同；第三次SL原/换线推演死亡0/24与5/24，封顶后续损均47。消费者整轮端点实损3/15、敌净扣10/17，确证多12血/多7扣。270264护栏在rationale，缺结构hp_guard不能当零次。

反例与未知：整轮包括重问，不能归给单候选；末段防御替换也有少损少伤，反对所有保血替换一概错误。未选整战胜线未知。

旧规则与预期行为：现有silent-selection-audit保留三阶段预测，HP/SL审计分列差值，selection-execution消费者保留端点、重问和未知。actual_full_candidate_result仍未认证。

验证方法：固定本局首/三试T2、第二试T5、F17/T6、末T11，核跨抽牌、生成、选牌、药水和SL后的持续候选身份、重问原因和资源建立时点。

处置：waiting。已有预测阶段与端点审计，仍缺跨抽牌、选牌、重问、药水、SL的候选持续归属及本局全过程生产校准。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-49632bc4878fb597

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat。账本：silent-0005, silent-0231。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2，原字节副本已保存。

证据局/层/回合：CA5KE8GFJ9X2 A10 F13/T1、T3、T5；states 273237/273252/273263、273257/273268。

本批核验：蚌力量0/4/8，同招显示11/15/19；虚弱下实录11/14。实际敌成长和当前属性分别核验，未把虚弱当停成长。

反例与未知：本局没有正敏捷取得的实测，不用构筑计划补齐；末轮净扣受零血截断，完整入伤不能由净HP反推。

旧规则与预期行为：保持逐击力量、逐牌敏捷、虚弱和独立敌成长分项，不拟合统一保血/输出权重。

验证方法：需在冻结生产调用中联合校准逐击力量、正负敏捷、虚弱及当前进阶独立成长，实盘未观察的正敏捷分支等待新证据。

处置：waiting。本局无正敏捷实测，缺逐击力量、正负敏捷、虚弱与蚌独立成长的冻结生产联合校准。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-66532328a585941f

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat, structure。账本：silent-0021, silent-0009。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831，原字节副本已保存。

证据局/层/回合：5PM6JAQG6FNQ A10 F39末试/T2，states 274379/274380、decision 268455；F33为原提案的已建立组件对照范围。

本批核验：冒泡前后能量5→4，失落目标35血不变且毒0；只确认该步未兑现毒收益。

反例与未知：F33成立的组件和存活条件不同，不能与F39直接拟合启动权重。持有、计划和已建立必须分列。

旧规则与预期行为：保留当前构筑与启动规则；不把候选里的成长或下一轮毒预记为实际已结算输出。

验证方法：需要同HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照及可复现收益函数。

处置：waiting。缺同HP、牌组、药水、完整抽序下不同启动顺序的受控整战对照和收益函数，无毒冒泡局部事实不足以拟合权重。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-43a76a31ba7bdcfa

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat, sl。账本：silent-0030, silent-0027。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c，原字节副本已保存。

证据局/层/回合：61E2QS63Y9WU A10 F17/T5–T6；states 273504/273508，原账本silent-0030/0027。

本批核验：T6敏捷−2，两防御牌面各3；同轮敌HP67→34。毒与负敏捷分别核，不将能力持有当成已建立。

反例与未知：本场原提案记录首试胜，不能据此更改其他局SL范围或宣布另一换线可救活。

旧规则与预期行为：现有吸取、负属性和毒规则继续保留；SL范围、阈值与换线偏好没有本批受控依据。

验证方法：需要A10同起始HP、构筑、抽序的生产整战配对及另一可核SL线；局部机制正确与SL策略收益分别验收。

处置：waiting。缺A10同起始HP、构筑、抽序的生产整战配对及另一可核SL线，首试胜利和毒端点不足以改SL范围或阈值。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-5264153a4a4b0e5c

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat。账本：silent-0039, silent-0209。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02，原字节副本已保存。

证据局/层/回合：61E2QS63Y9WU A10 F23/T4，states 273589/273593/273596；原账本silent-0039/0209。

本批核验：T4本体76→41、幻象14→2、玩家25→10；两次航行后两实体力量3→6。幻象尚活并非退场，净扣不能代替击杀窗口。

反例与未知：focus幻象的39伤零损候选未实打，不补其完整后继或统一首杀规则。

旧规则与预期行为：保留所有目标选项，相同推演值并列；现有召唤/成长窄实现不等整战目标收益认证。

验证方法：需要A10召唤、航行、复现、退场全链冻结生产调用及另一focus的完整后继，分别核实体身份和目标排序。

处置：waiting。缺A10召唤、航行、复现、退场全链生产校准及另一focus完整后继，已有召唤源码与T4端点未认证整战排序收益。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

## silent-proposal-bddfa690a84e03d0

来源任务：experience-update；目标任务：strategy-proposal；原domains=combat。账本：silent-0128, silent-0079。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780，原字节副本已保存。

证据局/层/回合：DUZUBAJ3A8GP A10 F30/T4–T6；states 274929/274932/274934，原账本silent-0128/0079。

本批核验：甲虫T5临时力量2→−4、攻击20→14；T6恢复与成长后力量4、攻击22。按已实录当前进阶分核，不预训练推睡层或伤害唤醒条件。

反例与未知：四试失败不是四个独立局；预测截断不称实际死亡。同盘多输出伴随多血价，没有未知换线胜率。

旧规则与预期行为：保持睡眠、眩晕、当前力量、临时减力恢复和成长分别计算，不拟新的血价或固定杀序。

验证方法：需要伤害唤醒、眩晕接续、当前进阶成长的完整生产全链校准，以及同抽换序完整后继。

处置：waiting。缺伤害唤醒、眩晕接续与当前进阶成长的生产全链校准及同抽换序后继，四次相关失败不能拟新血价或杀序。

预期影响仅为限定可验证的机制或审计边界，不承诺整场转胜。当前不拟合常数；以上六局属于已用于发现/回归的相关旧样本，后续按run_id分组、按结束时间后置验证，SL尝试不扩独立局分母。未来新增实现须撤源码失败、恢复通过及原沙箱检查；本批无源码改动，不冒报红绿。当前无生产回退；后续按独立实现源码提交/开关回退并保留原证据、账本和失败。

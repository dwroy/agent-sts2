# 20261014-224302-strategy-proposal 完成报告

十个派发提案均已逐项核对，全部waiting；没有证据支持本批新增策略源码。实际源码提交、合入提交、发布版本均为null。处置理由、证据局/层/回合、账本、反例、预期行为及验证/回退详见本目录 proposal.md；逐项机器结果在report.json。

记录时间：2026-10-14T23:02:24+08:00。角色：silent；基线：`4ae762386e6bf43696caf4328917c008f4ba804d`。开工git status干净，按普通任务merge main输出Already up to date；本批无research_request/implementation_request，旧牌数专题绑定其他批次，不读取它的工作规格或冻结证据来替代本批。结束已核HEAD未变、工作树干净。

## 原始证据与复核

六个runs条目均SILENT/A10/失败，末层分别DU30、5PM39、CA13、8JRE33、YF48、XP33。共用extract_evidence.py按显式run身份提取；正文提及不作局归属。以下逐流截点独立冻结，未声称全局同一时刻的快照。

| 流 | source_size（字节） | 本批实际记录数 |
| --- | ---: | ---: |
| states | 12802902474 | 4062 |
| decisions | 1418898483 | 3941 |
| sl-attempts | 39330624 | 38 |
| run-config | 1695570 | 6 |
| run-plans | 7783352 | 33 |
| brain | 520135618 | 188 |
| runs | 328404 | 6 |

独立verify_bundle.py对8274行逐一seek原日志，核offset/bytes/SHA、解析正文、所属局和逐流计数/output SHA；所有选中state都核SILENT/A10。states/decisions的全源各2条JSON解析失败及brain全源1条保留于manifest统计，未归因本批六局。run-plans按真实run字段得到33行，不用历史零行初稿断言没有计划。

固定核验16项加补充2项，全部通过；4组同指纹整轮观测对照也通过。依次为8JRE T2（实损3/15、净扣10/17）、YF T1（0/9、45/38）、XP T3（9/14、24/27）、XP T1（2/10、25/34）。它们是同存档的相关观测，不认证完整候选/单卡因果/整战反事实。末轮显示攻击减挡与零血截断分开；所有原字段和未知保留。

## 现有消费者读回

执行当前live的learner/lib/selection-execution.ts，输入是本批原日志准备的单局gzip JSON；保存原正文与gzip SHA及输出SHA。与base对应消费者blob一致，实际live源码祖先已核。完整输入的DU/CA分别因3/1条map/route-change原行缺decision_id拒绝；拒绝及原行SHA保留，随后只沿缺口分块读取有ID动作，不补ID、不重排行号、不跨缺口。CA原帧282条仍在，0连接区间来自当前消费者要求已知SL尝试上下文，不解释成CA没有原帧。

| run | full输入 | 有ID动作 | 选线片段 | 可连/未知区间 | 整轮端点/未知轮 |
| --- | --- | ---: | ---: | ---: | ---: |
| DUZUBAJ3A8GP | rejected | 599 | 77 | 189/410 | 28/68 |
| 5PM6JAQG6FNQ | accepted | 638 | 83 | 202/436 | 25/76 |
| CA5KE8GFJ9X2 | rejected | 264 | 41 | 0/264 | 0/46 |
| 8JRE1C4H4Z2W | accepted | 659 | 113 | 264/395 | 44/67 |
| YF0LXT1QSTGG | accepted | 1065 | 204 | 424/641 | 54/106 |
| XP2SL33HT0D9 | accepted | 712 | 123 | 274/438 | 35/87 |

合计动作3937、选线片段641、区间3937（后端点1353、未知2584）、轮窗口636（可核端点186、未知450），终局端点5。所有完整候选实果为null，已认证完整候选数量0。读回不证明自然采用/校准完成或胜率提升。

## 源码与历史边界

核查切点live HEAD：`18aec66704fa7ce58de6c67eb6e603c5c8163f9d`。每个所列实际live源码commit均核为该HEAD祖先，实际文件字节与该HEAD一致；保留base来源提交的真实祖先true/false。base turn-solver/rollout最后提交本身不是此live祖先，但叶blob相同；不把main源码提交自报已部署。只有rollout-live整叶blob不同，保存4,004字节base-live-source.patch，其差别是Roy→Dai注释；未做整仓副本或归档。

| 路径 | 实际live源码祖先 | base/live Git blob |
| --- | --- | --- |
| agent/src/reflex/turn-solver.ts | ec7eba421e49983ddcf08afffd3e3f72249049b0 | 相同 |
| agent/src/reflex/rollout.ts | 7cf62b7b13de5883632f4ddcf2c1d534c279b235 | 相同 |
| agent/src/reflex/rollout-live.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 注释不同，见patch |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 相同 |
| agent/src/reflex/silent-selection-dispatch.ts | bade647f9fe4c9103b40e2f26b26296692ad24b7 | 相同 |
| agent/src/reflex/silent-sl-resource-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |
| agent/src/reflex/silent-sl-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |
| agent/src/reflex/silent-hp-guard-audit.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |
| agent/src/reflex/silent-phase-current.ts | 8698c581dac6c7e957f50a381586960a6d0c9b57 | 相同 |
| agent/src/reflex/silent-phase-reference.ts | 1d57f9d0dbbb63603e9ce9768e74cb2021478464 | 相同 |
| agent/src/knowledge/monster-db.ts | 4ed3c72df30f27b881da637aebf528b97440e0bb | 相同 |
| agent/src/knowledge/room-costs.ts | 295a90aef9eb6f5b267490294f7733806419c45a | 相同 |
| learner/lib/selection-execution.ts | cf72bd21148059f111f760cc98a727369e34a47e | 相同 |
| learner/lib/selection-observation.ts | cf72bd21148059f111f760cc98a727369e34a47e | 相同 |
| learner/lib/selection-turn.ts | 9b87d54f097d84521152e6cca8d6072af8140394 | 相同 |
| learner/lib/selection-terminal.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | 相同 |

这些实现只覆盖原提案的窄事实或审计范围；宽条目不标duplicate/implemented。不修改其他角色、未观察进阶、运维prompt、原请求或旧done父请求，不把框架/审计交付当量化策略学习完成。

## 记录与验证口径

只经根learner/ledger.py update为原账本加本批proposal/report追溯链接，by=learner:strategy-proposal；不新建经验或提案id，不修改原claim/evidence/首证/先验/版本和已存在status，不标shipped。十份原Markdown保存原字节并逐一核SHA，旧复盘不重复追加。具体CLI输入、输出与追加原字节另存本目录。

本批没有生产源码改动，因此tsc/vitest/cases均null，没有生产撤码失败/恢复通过、源码提交、live合入或新eval版本；不挪用历史测试绿。证据脚本/消费者成功只是材料核验。首次临时frame脚本因combat=null抛AttributeError，错误保存initial-frame-inspection-failure.txt，修正的inspect_frames.py已重新读取通过，不能称为生产红绿。完整消费者的预期无ID拒收亦不当代码失败或源码撤码结果。

原抽取、失败、等待和未知均保留，不操作play、不停对局、不推送。新局补齐对应输入/后继再由原调度器重派；本批不等未来事件，也不关闭经验实际入库/消费者采用或量化父要求。

## 最终材料验收

账本CLI实际退出0，30条追加逐offset/bytes/SHA读回，字段仅op/id/ts/by/where/note；原status等游戏字段未由本批写入。基线与干净工作树及消费者源码再次核实。gitleaks对本批约195.47 MB材料扫描退出0，无泄漏；无源码提交。最终核验初稿曾把纯文本CLI回执误当JSON，错误保存在completion-first-failure.txt；修正回执读取，没有重复执行update。这与首次combat=null脚本失败一样只属材料核验，不是生产源码撤码红绿。

并发live更新：核查切点之后live推进至 `907fa494efb34f0286a0205e8976ab161d4b59f7`，旧切点仍为其祖先；唯一变化叶为rollout.ts，源码 `78b691b8f4395f52be5e0bfb566450492ee0e9d6`，新增outgoingHpDamage统计字段及实际反伤记账，原growth/tainted路径未改。差异保存live-concurrent-source.patch，不能归为本批提交或合入。第一个修正版最终核验对旧16叶全相同的断言因此失败，原stderr保存在completion-live-changed.stderr.txt；不覆盖旧切点证明，另存并发版本并确认本批实际调用的selection消费者叶仍相同。完整候选认证/联合校准缺口未被此统计增量关闭，十项waiting保持。

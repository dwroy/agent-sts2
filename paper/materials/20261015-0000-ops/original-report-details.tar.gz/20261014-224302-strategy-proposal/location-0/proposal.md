# 静默猎手本批十项策略提案复核

批次：strategy-proposal / 20261014-224302-strategy-proposal；记录时间：2026-10-14T23:02:24+08:00。
基线：`4ae762386e6bf43696caf4328917c008f4ba804d`；只处理已派发的十原提案，不新领其他队列、不承接不匹配的手动专题。

十项都保留waiting。已经存在的事实、审计和机制接线只按子范围列出，缺少完整候选归属、历史输入或联合校准时不据局部核验关闭宽项。

证据边界：六局由runs.jsonl核为SILENT/A10；抽取与独立逐行重读共8274行。18项原帧断言和4组同指纹配对通过；不调用游戏、LLM或网络，不读其他角色知识。现有消费者只读冻结输入，不改变生产策略。原稿与历史失败保留。

## 1. silent-proposal-c20b5139dd0dff71

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；原Markdown SHA256：`bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c`。
来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0168；本批角色/进阶：silent / A10。

证据：DUZUBAJ3A8GP / F27 / T4—6。原行定位：states 274830—274839；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：污染None→3→3→6；次轮火花3→6、污染未列；三技能6/12/18，26攻击与17挡后实损9。技能同时施毒，不能一概判亏。

原提案期望行为：冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/turn-solver.ts`：`ec7eba421e49983ddcf08afffd3e3f72249049b0`; `agent/src/reflex/rollout.ts`：`7cf62b7b13de5883632f4ddcf2c1d534c279b235`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。污染与火花增长接线已有；缺历史dirty移动表和火花增长、临时污染、虚弱、施毒收益的同一生产多步校准，不据9损启用少打技能规则。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 2. silent-proposal-ae9e692d680e3819

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；原Markdown SHA256：`b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5`。
来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0183, silent-0005；本批角色/进阶：silent / A10。

证据：5PM6JAQG6FNQ / F39 / T4—6。原行定位：states 274351—274362、274391—274397；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：玩家−4力/−4敏，两步法只恢复至敏捷未列；失落退场后力量未列，T6再−2敏。末试单步法只至−2敏，8血0挡对遗忘19仍败。

原提案期望行为：提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/turn-solver.ts`：`ec7eba421e49983ddcf08afffd3e3f72249049b0`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。本批可核负力敏与失落退场端点；缺各次抢夺的独立来源账、混合增益及遗忘死亡返敏端点，不能把敌当前全部力敏当返还量。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 3. silent-proposal-52f1e1bd2e7db0ed

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；原Markdown SHA256：`651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376`。
来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0231；本批角色/进阶：silent / A10。

证据：CA5KE8GFJ9X2 / F13 / T1、3、5。原行定位：states 273238、273252、273263、273268—273269；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：喷水11/15/19；加压后力量4/8；弱后11/14，末2血10挡对14显示需求4，但实际净扣仅2、敌最终16。覆甲端点不证明完整减层条件。

原提案期望行为：第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/knowledge/monster-db.ts`：`4ed3c72df30f27b881da637aebf528b97440e0bb`; `agent/src/knowledge/room-costs.ts`：`295a90aef9eb6f5b267490294f7733806419c45a`; `agent/src/reflex/rollout.ts`：`7cf62b7b13de5883632f4ddcf2c1d534c279b235`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。当前进阶事实读取及房间代价五样本门槛已有；缺当时实际dirty移动表和加压、覆甲减层、虚弱的联合生产重放，不填固定房间成本。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 4. silent-proposal-6dd8bbff876be528

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；原Markdown SHA256：`48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5`。
来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0233, silent-0209；本批角色/进阶：silent / A10。

证据：5PM6JAQG6FNQ / F38 / T3—4。原行定位：states 274308、274313；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：23最大血电击端点力量2/4、高电压2、攻击17/19；T3玩家61→31。另一先杀线未实打，候选省27不能登记实省27。

原提案期望行为：复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/rollout.ts`：`7cf62b7b13de5883632f4ddcf2c1d534c279b235`; `agent/src/reflex/rollout-live.ts`：`a8b1f8be153fe4f3a34146117546c2178f2e446b`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。HIGH_VOLTAGE增长已有；同类型最大血端点不足证明跨召唤持久实例与计数重置，缺冻结移动表联合校准及另一目标序后继。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 5. silent-proposal-578e415a259e6835

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；原Markdown SHA256：`e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a`。
来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016；本批角色/进阶：silent / A10。

证据：8JRE1C4H4Z2W / F33 / T2、T11。原行定位：decisions 270216、270282；states 276433—276434；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：首/三试T2指纹相同、实损3/15与净扣10/17；原五轮0/24对5/24不是并列。末试5血22挡对37显示需求15，实际净扣5，敌154→130；失败截断不冒充完整入伤。

原提案期望行为：核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/silent-selection-audit.ts`：`05cd292c6f01bb31e406473d3a9843e659d62b93`; `agent/src/reflex/silent-selection-dispatch.ts`：`bade647f9fe4c9103b40e2f26b26296692ad24b7`; `agent/src/reflex/silent-hp-guard-audit.ts`：`a8b1f8be153fe4f3a34146117546c2178f2e446b`; `learner/lib/selection-terminal.ts`：`04921bd785ac6838066522f91ea0bb6ab95cb6a1`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。原答、替换、派发、整轮与终局观测已有窄实现；完整候选身份及重问后续步归属仍未知，金刚杵与silent-0016旧错链不据此关闭。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 6. silent-proposal-c0767768bf6a7ab1

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；原Markdown SHA256：`28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb`。
来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0079；本批角色/进阶：silent / A10。

证据：YF0LXT1QSTGG / F48 / 第2、3试T1。原行定位：decisions 271309、271348；states 277327—277373；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：同指纹实损0/9、净扣45/38；预测0/10、54/36另列，两候选24/24死。第六试恢复挡仍败；F33成功SL是反例边界，不能由末Boss六败否定全部探索。

原提案期望行为：全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/silent-sl-resource-comparison.ts`：`a8b1f8be153fe4f3a34146117546c2178f2e446b`; `agent/src/reflex/silent-sl-comparison.ts`：`a8b1f8be153fe4f3a34146117546c2178f2e446b`; `learner/lib/selection-execution.ts`：`cf72bd21148059f111f760cc98a727369e34a47e`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。同指纹T1实损0/9、净扣45/38已核；缺完整候选续步归属、同抽序同预算整战反事实及后移独立验证，不拟SL血价惩罚或禁止探索。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 7. silent-proposal-a46bdb7fe711d79a

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；原Markdown SHA256：`eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6`。
来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0021, silent-0027, silent-0028, silent-0085；本批角色/进阶：silent / A10。

证据：YF0LXT1QSTGG / F48 / 末试T3—5。原行定位：states 277512—277528；decision 271495；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：阶段4/111血、4毒变212/212血、旧毒未列；触媒2已建但毒未列。敏捷5→6时既有23挡不倒补；末18血23挡对44仍败。已建毒雾的旧尝试亦败，不支持强制先手。

原提案期望行为：实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/silent-phase-current.ts`：`8698c581dac6c7e957f50a381586960a6d0c9b57`; `agent/src/reflex/silent-phase-reference.ts`：`1d57f9d0dbbb63603e9ce9768e74cb2021478464`; `learner/lib/selection-observation.ts`：`cf72bd21148059f111f760cc98a727369e34a47e`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。阶段现场与零毒触媒说明已有；缺延迟施毒、抽弃牌、后取得敏捷在完整候选中的传播及生产联合校准，不强制能力先手或预支未来毒。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 8. silent-proposal-1044224808015e5c

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；原Markdown SHA256：`4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5`。
来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0079；本批角色/进阶：silent / A10。

证据：XP2SL33HT0D9 / F33 / 首、2试T3；首、末试T1。原行定位：decisions 271992、272040、271982、272195、272076；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：T3同指纹实损9/14、净扣24/27；T1实损2/10、净扣25/34且末试建立1力量。B2 diff/se均0不是安全认证；第3试T4的候选8/16与11/23未完整实打。

原提案期望行为：核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/silent-sl-resource-comparison.ts`：`a8b1f8be153fe4f3a34146117546c2178f2e446b`; `agent/src/reflex/silent-selection-audit.ts`：`05cd292c6f01bb31e406473d3a9843e659d62b93`; `learner/lib/selection-turn.ts`：`9b87d54f097d84521152e6cca8d6072af8140394`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。B2零胜并列及T3多5血价多3净扣已核；缺完整候选执行归属、配对随机池预算及独立整战胜线，不改并列探索优先级。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 9. silent-proposal-7cbc6005db712ba9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；原Markdown SHA256：`f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291`。
来源任务：postmortem；实现任务：strategy-proposal；账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242；本批角色/进阶：silent / A10。

证据：XP2SL33HT0D9 / F33 / 末试T2—5。原行定位：states 278236—278261；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：轮初14挡，镣铐爪−9力、4攻击→0，后斗篷至20挡，T3减力未列。火箭57→38→28分步下降；4敏/脆弱2后偏折6挡。末11血6挡对17，毒净扣3/7，仍未减员。

原提案期望行为：用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`agent/src/reflex/turn-solver.ts`：`ec7eba421e49983ddcf08afffd3e3f72249049b0`; `learner/lib/selection-observation.ts`：`cf72bd21148059f111f760cc98a727369e34a47e`; `learner/lib/selection-turn.ts`：`9b87d54f097d84521152e6cca8d6072af8140394`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。轮初14挡、临时减力恢复、57/38/28及能力时点已核；缺这些机制的完整候选联合传播和消费者校准，不以单帧说明验收整线。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。
## 10. silent-proposal-c59f592f1427a67e

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；原Markdown SHA256：`81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2`。
来源任务：experience-update；实现任务：strategy-proposal；账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242；本批角色/进阶：silent / A10。

证据：YF0LXT1QSTGG / F48；XP2SL33HT0D9 / F33。原行定位：上述两局配对、阶段、临时减力与轮初挡原帧；逐行offset/bytes/SHA见 evidence/，固定核验见 verified-bundle.json / followup-frame-assertions.json。

本次观察与反例：支持组件持有、建立、时点、毒结算和SL血价分账；后三个同指纹配对仍都没有受控整战胜线，路线/休息/留药反事实亦不完整。本批不复核未派发的99局或其他角色。

原提案期望行为：核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证。目前只核到局部已实现范围及观测事实，未验证完整候选或新增策略收益。当前live祖先的局部源码：`learner/lib/selection-execution.ts`：`cf72bd21148059f111f760cc98a727369e34a47e`; `learner/lib/selection-observation.ts`：`cf72bd21148059f111f760cc98a727369e34a47e`; `learner/lib/selection-turn.ts`：`9b87d54f097d84521152e6cca8d6072af8140394`。这不是整提案duplicate，原祖先和Git blob核验见 source-provenance.json。

处置：**waiting**。宽提案各局部事实消费者已有；仍缺各子域完整候选实果、联合校准和受控路线/用药后继，历史支持数不作独立因果分母。

下一次验证：冻结该条件下的手牌、抽弃序、尝试/实体来源、当前进阶移动表和所有候选；在生产求解/推演调用中逐步对照已观测端点。仅可核前缀时保持后缀未知；若调整选择，按独立run_id切分发现与时间后置验证，保存原规则/新规则对照和撤源码失败/恢复通过。无新充分数据不拟阈值或权重。

预期影响与回退：当前保留候选、并列、排序、出牌/药水/SL/终局规则。后续增量的预期收益仅限所验证范围，须另有实际源码commit、自测及live流程；本批没有源码或游戏行为需要回退。

## 共同限制

- 本批六局是发现/固定核验来源，SL尝试不增加独立局分母；没有新增时间后置独立验证局，不把重复核同一证据当新学习收益。
- run-config列出的dirty知识/移动数据未完整冻结到本批；当前数据库不能冒充当时实际输入。当前进阶事实从第一观测读、房间代价五样本门槛均保持。
- 原动作回执、相邻端点、整轮观测、候选预测与候选因果归属分别保存；净HP不等于完整入伤，enemy_id类型/最大血不等于持久实例。
- silent-proposal-578e415a259e6835中的金刚杵→silent-0016历史错链保留：原0016 claim属于护喉甲。本批不重复写历史复盘、不修改claim/首证/先验，不强行支持错链；沿旧ops勘误链，不代称watcher或Roy已确认。
- 未实现策略、不新增源码/经验库、无提交/合入/版本、不标shipped；后续实际入库和自然消费者采用仍由原流程独立验收。

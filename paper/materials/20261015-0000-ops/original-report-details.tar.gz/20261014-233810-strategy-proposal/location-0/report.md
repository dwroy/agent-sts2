# 20261014-233810 静默猎手策略复核报告

本次base：`23c3e5faa8dd557a381e91d9168145e6513f138f`。六个派发锚点均核实为静默猎手A10，十项原提案全部复核，均waiting。源码/知识零改动，fixes=[]、merged=null、无提交、无新游戏版本；tsc/vitest/cases均null。

## 证据与处置

共8444行（states4167、decisions4071、SL43、run-config6、run-plans21、brain130、runs6）逐offset/bytes/SHA/正文重读相符。run-plans用真实run字段，不以正文提及为所属局；每流source_size单独冻结，原无效行计数states2/decisions2/brain1保留，不据此断言本角色日志缺失。原十个Markdown SHA、16个账本关联及11条源码路径的live祖先已核。

完整逐项证据、层/回合、原账本、反例、旧/预期行为、验证和回退在[proposal.md](proposal.md)。逐项JSON在[proposal-results.json](proposal-results.json)。已有子诊断、完整候选实果与整战受控收益分别记录，不以任何展示子项关闭原id。

## 本批固定读回与限制

35项事实断言全部通过；analysis.stderr.txt与fact-verification.stderr.txt为空。离线复用既有resource_chain读取六局冻结帧，91战斗窗口/452资源变化，turn端点474/517；43无下一轮端点保留未知，不跨SL拼接或补最后未执行敌方回合。没有执行新模拟、LLM、联网或play。

主要限制是同局SL相关、原执行树dirty未恢复、抽弃和用药后可能续问，缺完整候选归属、未执行无药/留药/路线支线及后期独立整战校准。KEN步法延迟为省血不恒优反例；PU末试胜利不证明某一处改线因果。没有足够证据拟统一血价、留药或新SL参考排序。

KV回合端点仅直接观察到327→342净增15；原提案30回血算术不能冒作中间帧直接观测或完整毛伤认证。初版与修订事实核验均保留。未改历史账本，不新造机制结论。

## 执行与记录

按普通批次先快进main至本报告base；之后不追随刷新。十个原proposal_ids逐项处理，未新增代码提案。仅使用授权的ledger update补by/where/note，保持既有账本status及首证/claim/prior/版本/证据。具体CLI输入/回执及后读回见ledger-update-input.json、ledger-update.stdout.txt、ledger-update-readback.json。

本工作树scratch被git忽略；最终核HEAD/base、git status与diff为零，并保存final-worktree-check.json及baseline-diff.patch。本批未提交源码，因此没有源代码负控、tsc/vitest、自测合入、eval版本或Roy规则上线通知。记录与数据材料不借用历史绿测试。本批学习结束不表示经验已入live或模型已采用。

原始日志、SHA、提案副本、初版核验及本批材料全部留在本scratch，不清理自身工作树。无游戏行为回退事项。

## 逐项最终处置

- silent-proposal-366288801d9150d9：waiting；751 F17 T2/T7/T13局部血价可核；live已有SL预测资源及配对B2比较、单动作回执。跨抽弃/续问的完整候选实果仍为未知，缺固定其余后继的整战对照与独立后期校准，不能定额外失血准入阈值。
- silent-proposal-85929bdfc8a3fc1b：waiting；751 F13 T3只有实际喝药分支；F17保守持牌项及同题无药参考已有live。缺不喝/留到boss的完整支线、续问后的逐源实果及跨战验证，不能把hold_hp=null拟成0或改弃牌/留药规则。
- silent-proposal-efd9f83ee9e1a6dc：waiting；原经验的751配对成本有证据，预测资源和回执子项有live源码；六次SL相关且全败，完整实际候选归属、受控整战及独立验证仍缺，不以子诊断关闭原经验提案。
- silent-proposal-131042659448ae74：waiting；751持牌、敏捷/毒/荆棘及药水分账的部分预测已有live；完整能力兑现、毒/反伤逐源归属、抽弃/重问后的完整执行及无药/留药跨战联合验证尚缺，综合提案不能登记完成。
- silent-proposal-990f054036609447：waiting；KV F33 T5同盘删毒药输出净差及敌回血可核，毛伤总量不能仅由净HP差认证；缺完整候选末端和逐伤源、固定后继的整战对照及未执行路线/休息支线，不能拟SL/回血门槛。
- silent-proposal-e18d3f18e6cac2a0：waiting；YQL/L9/PU巨兽本体/占位体阶段及YQL T10一次饮毒限制已有live展示；legacy占位残血仍保留原排序。缺受控完整后继、最终资源适用校准和新排序独立验证，不能将展示子项算整项duplicate。
- silent-proposal-9733bb80f445aeae：waiting；巨兽阶段和残壳饮毒的一次局部限制有实盘及live子诊断；提前喝/不喝/留药与新SL参考排序均无受控整战比较，跨战药值和策略收益未知，原经验提案继续等待。
- silent-proposal-c51468c5e8ba6668：waiting；KEN七次实际耗药及F17 75/86空栏入口可核；随机选牌、发光水后续问和完整药水候选净收益缺认证，F15不喝/保留至boss支线未执行，不能校准跨战预算。
- silent-proposal-86a7db08d1a31976：waiting；KEN F17 T10同指纹2/15对4/21及T5步法延迟反例可核；live有局部预测和单动作回执。缺完整伤源/能力兑现归属、固定后继整战及独立校准，不能收窄更差B2探索或改HP护栏。
- silent-proposal-e282a9131b99129a：waiting；KEN双向局部取舍有证，六次尝试属于同一局；省血同时延迟步法反驳只取最少失血。完整后继反事实、能力兑现归属和独立后期校准不足，不能拟统一血价或以子诊断关闭经验提案。

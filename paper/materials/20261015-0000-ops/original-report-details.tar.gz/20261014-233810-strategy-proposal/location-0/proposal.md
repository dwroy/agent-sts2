# 本批静默猎手十项已领取策略提案复核

批次：20261014-233810-strategy-proposal；当前完整基线：`23c3e5faa8dd557a381e91d9168145e6513f138f`。派发初始HEAD：`bd1318631ce784435b54d3ab4bb0485b40e4424a`；正常批次按任务合入main，仅快进到本基线，无冲突。

本批没有research_request或implementation_request，reason=proposal，十个proposal_ids与工作树、角色、六个派发局号相符。普通专题请求仍绑定旧20261010批次，未承接、未读取其work_spec或扩展选题。只复核这十项，不新领队列项、不新建重复提案。

## 证据与共同限制

六局均为SILENT A10。原提案Markdown逐一SHA相符，原字节副本在original-proposals/。抽取及原字节重读见evidence/、identity-evidence/、raw-verification.json；所有来源均来自本角色。原对局code含+dirty，当前基线源码不能替代历史dirty执行树。

完整候选的预测、一次派发回执、可观测回合端点、受控整战后继分别核验。抽弃/随机选牌/重问会改变续步；未执行的无药/留药/路线支线未知。没有新阈值的训练/验证局划分，不把相关SL拆成独立样本，不根据预训练游戏知识填规则。

## 逐项提案、原账本和处置

| 原提案id | 证据与观察 | 账本 | 处置及缺数据 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；272434/272575、272531/272652同指纹；净扣敌/净损血9/13→18/18、12/13→18/23、17/8→11/2。 | silent-0079, silent-0176 | waiting：751 F17 T2/T7/T13局部血价可核；live已有SL预测资源及配对B2比较、单动作回执。跨抽弃/续问的完整候选实果仍为未知，缺固定其余后继的整战对照与独立后期校准，不能定额外失血准入阈值。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3（272361）有药与无药参考；F17 T7持呼唤保守项，T13/T17实结损血。 | silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176 | waiting：751 F13 T3只有实际喝药分支；F17保守持牌项及同题无药参考已有live。缺不喝/留到boss的完整支线、续问后的逐源实果及跨战验证，不能把hold_hp=null拟成0或改弃牌/留药规则。 |
| silent-proposal-efd9f83ee9e1a6dc | 同751 F17三组端点与配对B2；六次SL属于一局，六次未胜。原经验及原提案保留。 | silent-0079, silent-0176 | waiting：原经验的751配对成本有证据，预测资源和回执子项有live源码；六次SL相关且全败，完整实际候选归属、受控整战及独立验证仍缺，不以子诊断关闭原经验提案。 |
| silent-proposal-131042659448ae74 | 同751 F13 T3及F17 T3/T5/T7/T13/T17；能力/毒/反伤/持牌与跨战药水联合范围。 | silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176 | waiting：751持牌、敏捷/毒/荆棘及药水分账的部分预测已有live；完整能力兑现、毒/反伤逐源归属、抽弃/重问后的完整执行及无药/留药跨战联合验证尚缺，综合提案不能登记完成。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33第4/5试T5（273400/273450）同指纹；334→298/305、双方30→30；下一轮毒20/13。末试T4末327→T5 342净增15。 | silent-0102, silent-0019, silent-0020 | waiting：KV F33 T5同盘删毒药输出净差及敌回血可核，毛伤总量不能仅由净HP差认证；缺完整候选末端和逐伤源、固定后继的整战对照及未执行路线/休息支线，不能拟SL/回血门槛。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T10（274087、states280160/280161）毒2→8、血26/挡13/自爆41不变；L9SGRBB5R698 F17 T14、PU80F84P6HPN F17 T17原SL占位残血。 | silent-0017, silent-0250, silent-0011, silent-0027, silent-0046 | waiting：YQL/L9/PU巨兽本体/占位体阶段及YQL T10一次饮毒限制已有live展示；legacy占位残血仍保留原排序。缺受控完整后继、最终资源适用校准和新排序独立验证，不能将展示子项算整项duplicate。 |
| silent-proposal-9733bb80f445aeae | 同三巨兽局及YQL末试T10一次饮毒；PU F17第5试获胜，但多轮动作改变。 | silent-0017, silent-0019, silent-0020, silent-0250 | waiting：巨兽阶段和残壳饮毒的一次局部限制有实盘及live子诊断；提前喝/不喝/留药与新SL参考排序均无受控整战比较，跨战药值和策略收益未知，原经验提案继续等待。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1七次use_potion、0次discard_potion；七组state槽位相邻前后核；F17六次75/86空栏。 | silent-0019 | waiting：KEN七次实际耗药及F17 75/86空栏入口可核；随机选牌、发光水后续问和完整药水候选净收益缺认证，F15不喝/保留至boss支线未执行，不能校准跨战预算。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17第4/5试T10（274505/274568）同指纹2/15→4/21；第4/6试T5（274484/274601）1/7→2/5，敏捷2首建立T5→T9；T2护栏274354。 | silent-0079, silent-0021, silent-0125, silent-0005, silent-0176 | waiting：KEN F17 T10同指纹2/15对4/21及T5步法延迟反例可核；live有局部预测和单动作回执。缺完整伤源/能力兑现归属、固定后继整战及独立校准，不能收窄更差B2探索或改HP护栏。 |
| silent-proposal-e282a9131b99129a | 同KEN T10/T5双向取舍；原经验保留。六次SL不是六个独立验证局。 | silent-0021, silent-0079, silent-0125, silent-0176 | waiting：KEN双向局部取舍有证，六次尝试属于同一局；省血同时延迟步法反驳只取最少失血。完整后继反事实、能力兑现归属和独立后期校准不足，不能拟统一血价或以子诊断关闭经验提案。 |

## 反例与预期行为

KEN省2血同时把步法延到T9，反驳只按当轮最少失血排序；T10多6血只换2伤，也不能推出适用于所有战斗的固定6血/2伤准入线。PU巨兽F17末试胜利存在，但其他回合与抽序同变，不能支持单步换线因果。751 F13同题无药参考的8/8抽样胜利不等于已执行无药整战；YQL残壳毒水一次无减伤不等于所有阶段药值为零。

本批预期行为为保留现行出牌、药水、SL、HP护栏和参考排序；使用既有诊断继续核实际来源。未来若取得相同起点的完整原/新后继、逐源资源校准及时间靠后的独立本角色证据，再拟合并验证；诊断字段通过不宣称胜率或通关收益。

## 既有源码与验证入口

- `agent/src/reflex/silent-sl-resource-comparison.ts`：当前live源码祖先 `a8b1f8be153fe4f3a34146117546c2178f2e446b`；基线/live原字节相同。
- `agent/src/reflex/silent-held-loss.ts`：当前live源码祖先 `05cd292c6f01bb31e406473d3a9843e659d62b93`；基线/live原字节相同。
- `agent/src/reflex/silent-potion-reference.ts`：当前live源码祖先 `04921bd785ac6838066522f91ea0bb6ab95cb6a1`；基线/live原字节相同。
- `agent/src/reflex/silent-selection-audit.ts`：当前live源码祖先 `05cd292c6f01bb31e406473d3a9843e659d62b93`；基线/live原字节相同。
- `agent/src/reflex/silent-selection-dispatch.ts`：当前live源码祖先 `bade647f9fe4c9103b40e2f26b26296692ad24b7`；基线/live原字节相同。
- `agent/src/reflex/silent-giant-potion.ts`：当前live源码祖先 `d5e20aa4dd44168ce30944dfcce74f8322144953`；基线/live原字节相同。
- `agent/src/sl/attempts.ts`：当前live源码祖先 `0d092f6b928a6221eabf3516abad25c48ceaac9c`；基线/live原字节相同。
- `agent/src/sl/explore.ts`：当前live源码祖先 `0d092f6b928a6221eabf3516abad25c48ceaac9c`；基线/live原字节不同（仅三处Roy→Dai注释；完整差异base-live-explore.patch）。
- `agent/src/reflex/combat-plan.ts`：当前live源码祖先 `ec7eba421e49983ddcf08afffd3e3f72249049b0`；基线/live原字节相同。
- `agent/src/hand/loop.ts`：当前live源码祖先 `a9fcf33ca4c204d03cfc310c7f7ced61f196f964`；基线/live原字节相同。
- `learner/resource_chain.py`：当前live源码祖先 `3f69541b5d3259dac94d3395bfe3da47936b4de9`；基线/live原字节相同。

资源对照为current_turn_prediction；持牌事实actual_held_hp_loss=null；selection_audit.actual_turn=null；单动作selection_dispatch.whole_plan_executed/actual_turn=null。巨兽本体/占位体展示和一次饮毒限制已有；enemyHpLeft及同轮参考排序仍保留legacy原值。它们属于已上线子诊断，不足关闭各原提案的联合验证/策略要求。出处见source-audit.json。本批未将任何原id登记implemented/duplicate，也未登记shipped。

## 实现、验证与回退

没有源码或知识改动，无提交、无合入、无发布版本。报告及本批分析材料在忽略的scratch内，工作树保持干净；仅经根ledger CLI补追溯，不降级既有shipped机制、不修改历史claim/首证/prior/证据/版本。代码提案仍使用十个原CLI id，无新增id。

原字节核验8444行；固定事实复核35项通过（fact-verification.json），以及六局既有resource_chain消费者离线读回91个战斗窗口、452个资源变化。517个本批分组回合中474有相邻下一轮端点，43缺该端点；这些数量不代表完整伤源、整条候选或未执行支线已认证。

未改生产源码，未撤源码或运行tsc/vitest，tests={tsc:null,vitest:null,cases:null}。固定事实核验不是源代码红绿测试或游戏收益验证。回退当前报告/追溯追加不涉及游戏行为；未来实际源码回退应限定其独立提交并保留全部原日志、失败和提案。

首次事实核验把327→342与已知15毒的条件算术写成30；现已将观察断言改为原帧可见净增15，原初版保存在fact-verification.initial.json和verify_facts.initial.txt。原账本30回血口径未改，本批未捕获同区间的中间结算帧，不凭这两端点认证30毛回血或整战206毛伤。

检索时曾猜测turn.ts/loop.ts及两个不存在的sl辅助文件；已通过rg定位combat-plan.ts/hand/loop.ts/attempts.ts，不把路径探针失败当代码或测试失败。

运维应读取本proposal.md、report.md及proposal-results.json逐项处置；waiting等待具体新数据，报告结束不关闭父要求。

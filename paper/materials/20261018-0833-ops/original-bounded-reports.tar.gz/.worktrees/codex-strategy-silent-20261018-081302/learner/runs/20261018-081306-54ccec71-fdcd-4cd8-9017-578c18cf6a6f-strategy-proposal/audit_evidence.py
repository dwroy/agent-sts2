import hashlib
import json
from pathlib import Path
import sys

SCRATCH = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRATCH.parents[2] / "learner"))
from extract_evidence import run_identity

RUNS = set("VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP".split())
FLOORS = {
    "VLZ6CCT8AQ0A": {35, 36, 37, 39, 40, 42, 43, 44, 45},
    "8JRE1C4H4Z2W": {17, 33},
    "CA5KE8GFJ9X2": {13},
    "5PM6JAQG6FNQ": {33, 39},
    "61E2QS63Y9WU": {17, 23},
    "DUZUBAJ3A8GP": {30},
}
KEY_DECISIONS = {269598, 269706, 269707, 269748, 269754, 269755, 269770, 270216, 270282, 270264}


def power_map(values):
    return {v.get("power_id"): v.get("amount") for v in values or []}


def compact_state(item):
    row = item["row"]
    state = row.get("state") or {}
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    if run.get("floor") not in FLOORS[item["run_id"]] or not combat:
        return None
    player = combat.get("player") or {}
    return {
        "reference": {k: item[k] for k in ("line", "offset", "bytes", "sha256", "run_id")},
        "floor": run.get("floor"), "turn": state.get("turn"),
        "ts": row.get("ts"), "observed_ts": row.get("observed_ts"),
        "fingerprint": row.get("fingerprint"),
        "screen": state.get("screen"), "readiness": combat.get("action_readiness"),
        "player": {k: player.get(k) for k in ("current_hp", "max_hp", "block", "energy", "cards_played_this_turn")},
        "powers": power_map(player.get("powers")),
        "enemies": [
            {**{k: e.get(k) for k in ("index", "enemy_id", "current_hp", "max_hp", "block", "move_id", "intents")},
             "powers": power_map(e.get("powers"))}
            for e in combat.get("enemies") or []
        ],
        "hand": [{k: c.get(k) for k in ("card_id", "card_index", "upgraded", "energy_cost", "resolved_rules_text", "dynamic_values")}
                 for c in combat.get("hand") or []],
        "deck_size": len(run.get("deck") or []),
        "deck_upgraded": sum(bool(c.get("upgraded")) for c in run.get("deck") or []),
        "potions": run.get("potions"),
    }


def main():
    summaries = []
    keys = []
    turn_boundaries = []
    audit = []
    all_combat_keys = set()
    all_view_keys = set()
    all_run_keys = set()
    for directory in ("evidence", "evidence-extra"):
        manifest = json.loads((SCRATCH / directory / "evidence-manifest.json").read_text())
        for entry in manifest:
            stream = entry["stream"]
            output = SCRATCH / directory / (stream + ".evidence.jsonl")
            digest = hashlib.sha256()
            counts = dict.fromkeys(RUNS, 0)
            previous_offset = -1
            source = Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")
            with source.open("rb") as raw_file, output.open("rb") as extracted:
                for encoded in extracted:
                    digest.update(encoded)
                    item = json.loads(encoded)
                    assert item["source"] == str(source)
                    assert item["offset"] > previous_offset
                    previous_offset = item["offset"]
                    assert item["offset"] + item["bytes"] <= entry["source_size"]
                    raw_file.seek(item["offset"])
                    raw = raw_file.read(item["bytes"])
                    assert raw.endswith(b"\n")
                    assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                    row = json.loads(raw)
                    assert row == item["row"]
                    assert run_identity(row) == item["run_id"] in RUNS
                    counts[item["run_id"]] += 1
                    if stream == "states":
                        state = row.get("state") or {}
                        run = state.get("run") or {}
                        if run:
                            assert str(run.get("character_id")).lower() == "silent"
                            assert run.get("ascension") == 10
                        all_run_keys.update(run)
                        all_combat_keys.update(state.get("combat") or {})
                        all_view_keys.update((state.get("agent_view") or {}).get("combat") or {})
                        summary = compact_state(item)
                        if summary:
                            summaries.append(summary)
                    if stream == "decisions":
                        if item["line"] in KEY_DECISIONS:
                            keys.append(item)
                        if (row.get("chosen") or {}).get("action") == "end_turn" and row.get("floor") in FLOORS[item["run_id"]]:
                            turn_boundaries.append({k: v for k, v in item.items() if k != "row"} | {
                                "row": {k: row.get(k) for k in ("floor", "turn", "sl_attempt", "fingerprint", "observed_ts", "ts", "chosen")}})
                    if stream == "runs":
                        assert str(row.get("character")).lower() == "silent"
                        assert row.get("ascension") == 10
            assert counts == entry["counts"]
            assert digest.hexdigest() == entry["output_sha256"]
            audit.append({**entry, "verified_rows": sum(counts.values()), "raw_bytes_and_identity_verified": True})
    (SCRATCH / "verified-state-summaries.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in summaries))
    (SCRATCH / "key-decisions.json").write_text(json.dumps(keys, ensure_ascii=False, indent=2) + "\n")
    (SCRATCH / "turn-boundaries.json").write_text(json.dumps(turn_boundaries, ensure_ascii=False, indent=2) + "\n")
    result = {"streams": audit, "verified_rows": sum(x["verified_rows"] for x in audit),
              "state_summaries": len(summaries), "key_decisions": len(keys),
              "combat_keys": sorted(all_combat_keys), "agent_view_combat_keys": sorted(all_view_keys),
              "run_keys": sorted(all_run_keys), "scope": "原日志证据一致性核验，不是生产测试或策略效果验证"}
    (SCRATCH / "evidence-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "streams"}, ensure_ascii=False))


if __name__ == "__main__":
    main()

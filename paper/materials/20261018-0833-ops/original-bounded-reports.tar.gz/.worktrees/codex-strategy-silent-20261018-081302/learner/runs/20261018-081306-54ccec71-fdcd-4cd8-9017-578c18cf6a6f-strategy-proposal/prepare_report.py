import hashlib
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
ROOT = Path("/home/dw/Projects/agent-sts2")
BASE = "d6023fa476a507fd3466835067815c063d9da876"
BATCH = "20261018-081302-strategy-proposal"
LIVE = "4eaad4c93ca1ea9f73b75dad4d9e719ea217a2b1"
RUNS = "VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP".split()
assigned = json.loads((S / "assigned-proposals.json").read_text())
audit = json.loads((S / "evidence-audit.json").read_text())
observations = json.loads((S / "observations.json").read_text())
assert audit["verified_rows"] == 6995
assert len(observations) == 11
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == BASE
assert subprocess.check_output(["git", "status", "--porcelain"], text=True) == ""
now = subprocess.check_output(["date", "+%Y-%m-%d %H:%M:%S %Z"], text=True).strip()
print(now)

details = [
    {
        "title": "神化同线、后续抽牌与实际施放分账",
        "evidence": "VLZ6CCT8AQ0A A10 F35 T1 s275564→275565：7→5能，防御5→8、打击7→10、匕首雨5→7、必备工具1→0费，场外升级数仍1。F43 T1 d269706/269707、s275679→275687：候选43伤/14损变51伤/13损并兑现，场外升级数仍4。F45 T1 s275722→275732：未记录施放神化，普通勒紧4、触媒1，生存者后手牌空。",
        "current": "实际live祖先772b839f8ada31664cb764ea9ad3bdb03da27f64已有静默A10局部升级变换；当前牌表叶ba23ca693151fa8c6f7fe035e640dc30f05ccd75进一步覆盖若干实见差值。3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17提供持有/候选/模型分列，但actual_cast_this_fight仍null。",
        "reason": "已有神化同线和牌堆升级子实现；本批缺完整确定抽序、战内原始各堆卡实例，以及跨抽牌、重规划、SL和换战的实际施放归属与消费者校准，不能登记整项实现。",
        "counter": "F35/F43施放且获胜、F45未施放且败，敌人、HP和抽牌不同；F43胜局仍付血，不能拟合必打规则或宣称修后转胜。",
        "verify": "冻结普通神化的战内各堆实例、完整抽序及动作归属；对同线、后继抽牌、重规划、SL恢复、换战重置及未知升级分别接生产入口验证，再做源码消融。",
    },
    {
        "title": "三骑士预算成熟度与药水",
        "evidence": "VLZ6CCT8AQ0A A10 F45 T1 d269748：药水MC 707ms、1/12，rollout horizon1/samples1/best=null。d269754为不同指纹，药水12/12；相邻原帧确认实增1能/2牌、HP仍67。T4 d269770：原选24伤/13损，未选攻击候选32伤/31损。",
        "current": "当前live rollout-live.ts已分别保存ms/horizon/samples/degraded/best/tied，退化best=null和明确并列有区别；这些诊断不等于预算策略或药水持有价格已验证。",
        "reason": "缺同起点、同随机池、同总预算的配对实验和候选稳定性曲线；707ms的1/12与后问12/12来自不同盘面，不能据此修改预算、留药或固定目标规则。",
        "counter": "少损线实打、攻击线未实打；不能把少8伤当整战败因。痊愈药水该帧未回血，名称不能替代效果。",
        "verify": "先固定已覆盖模型与状态，比较同种子、同总预算下MC先行和保留非药推演预算；记录多次用时/样本/排名稳定性，未通过不设新常量。",
    },
    {
        "title": "神化经验来源补链",
        "evidence": "与89354805ee4d7e77同一VLZ6CCT8AQ0A A10 F35/F43/F45帧；原Markdown增加experience-update来源及silent-apotheosis-combat-upgrades经验链接，原SHA已核。",
        "current": "与原神化提案共享现有升级及事实分列子实现，没有独立整项完成证明。",
        "reason": "该经验提案与原神化提案共享实盘证据，但实际施放及后继消费尚未闭环；同主题和局部实现不足以登记duplicate，沿原ID等待。",
        "counter": "来源链重复不是新的独立支持局；不新增提案ID，不累加同一局的四次施放为四局。",
        "verify": "复用原神化任务的冻结夹具与生产消费者验收，分别保留两个来源ID；完成后只引用真实live祖先源码提交。",
    },
    {
        "title": "十五项攻防、持续输出与资源机制",
        "evidence": "VLZ6CCT8AQ0A A10 F43 T1/T2及F45 T1：升级、勒紧4/6、触媒1/2和各来源属性须分账。F45 T4 d269770的24伤/13损与32伤/31损仅前者实打。原Markdown完整列十五经验与十四账本，均保留并逐一关联本报告。",
        "current": "已有神化、逐源属性、当轮资源及候选审计等窄子实现；本批只核部分确定帧，未执行十五子项共同覆盖战斗、路线、休息的生产回归。",
        "reason": "十五子项仍缺按来源、持续期限和属性组合冻结的战斗/路线/休息联合生产校准；局部正确公式与知识文字不能代替整项实现证明。",
        "counter": "已胜战仍消耗HP；临时减力不等于后续恒定防御；持有能力不等于已建立。原十五经验支持数不是相同条件的共同实验分母。",
        "verify": "逐子项建立带进阶、现场属性、敌人数据库输入和来源期限的固定生产夹具，再核战斗/路线/休息各自消费者；不得用固定权重替代状态变换。",
    },
    {
        "title": "SL与HP护栏的整线执行审计",
        "evidence": "8JRE1C4H4Z2W A10 F33首/三试T2 d270216/d270282指纹相同；s276208→276212与s276274→276278实损3/15、扣10/17。第三问题面原/替换为0/24与5/24死，不能称同死率。原提案另含第二试T5 d270264、F17 T6和末试T11，未把候选差额补成实收益。",
        "current": "05cd292c6f01bb31e406473d3a9843e659d62b93候选审计、bade647f9fe4c9103b40e2f26b26296692ad24b7单动作回执、a8b1f8be153fe4f3a34146117546c2178f2e446b护栏审计均为实际live祖先；源码明确actual_turn/whole_plan_executed/actual_outcome为null、state_effect_verified=false。",
        "reason": "已有候选、护栏与单动作派发审计；缺跨抽牌、选择、用药、重规划和SL的连续执行认证及能力实际建立归属，不能用单动作回执关闭整线审计。",
        "counter": "相同预期损失封顶不等于同死亡率；末试更保血且活更久仍败，不能把所有防御替换都判错。六次尝试是同一局，不是六个独立样本。",
        "verify": "固定首/三试T2、第二试T5、F17 T6与末试T11，追踪候选前缀终止、实际状态与重问归属；SL恢复与回血分开。任何规则改动另需按run分组的完整比较。",
    },
    {
        "title": "力量、敏捷、虚弱与独立成长",
        "evidence": "CA5KE8GFJ9X2 A10 F13 s273238/s273252/s273263：喷水11/15/19，敌力0/4/8；s273268末轮弱后14、玩家2HP/10挡，完整需损4。所核F13帧未建立正敏捷。",
        "current": "原现场值能够核对加压、虚弱和威胁；本批未发现可独立复现的新数值缺陷，也没有四条路径联合校准的完整实现证明。",
        "reason": "本场未建立正敏捷；缺力量逐击、正负敏捷、虚弱和独立成长的联合生产输入与校准，不能据此新增统一保血或输出权重。",
        "counter": "弱降低当前喷水，却未取消下一轮加压；不得把计划中的步法当已取得。",
        "verify": "使用本角色已观察的正/负属性夹具分别验证逐击、取整与成长，并保留当前进阶数据库输入；本局只作已观察部分回归。",
    },
    {
        "title": "持有、计划、实建与启动价值",
        "evidence": "5PM6JAQG6FNQ A10 F33 T1 s274200实建雾3/触媒1/群蛇4；F39末试T2 d268455、s274379→274380向无毒失落打冒泡：能5→4、敌HP/能力未变，未建毒雾。",
        "current": "事实应保持持有/实付/实建分账；当前经验库文本也保留这些限制，但文字不是本批独立生产消费者验证。",
        "reason": "F33和F39敌人、起始HP、资源及抽序不同；缺同起点同抽序下不同启动顺序的受控整战对照与可复现收益函数，不能拟合启动权重。",
        "counter": "F33已实建后获胜与F39未建后败存在多项共同变化，不能单因归给雾或把未来组件价值当即时输出。",
        "verify": "先给完整已知牌序、动作归属和可活窗口，再对不同启动顺序做同盘配对；按局划发现/后移验证，不把SL尝试扩为独立分母。",
    },
    {
        "title": "族母吸取、负敏捷、毒与SL",
        "evidence": "61E2QS63Y9WU A10 F17 T5→T6 s273503→273504：玩家力2→0、敏0→-2、敌力0→2。T6 s273507双防御共6挡，至s273508毒17+16实扣33。该场首试60HP进场后获胜。",
        "current": "可冻结吸取、负敏捷和毒的分项观察；这不提供另一条完整SL路径的胜率或换线收益。",
        "reason": "F17只有首试获胜证据，缺同起始HP、构筑及完整抽序下另一完整SL线路；不能据首试胜利改变SL范围或换线偏好。",
        "counter": "吸取后毒仍推进，不说明所有资源相同的别线可救活；本局成功也不证明固定顺序最优。",
        "verify": "分别核吸取前后属性、每张防御与毒的真实结算；SL规则须另有同起点完整线路和生产回归，未获得时保持现行为。",
    },
    {
        "title": "胧光怪召唤、成长与目标顺序",
        "evidence": "61E2QS63Y9WU A10 F23 s273583召21HP幻象；s273589与273596显示双方力3→6。T4 s273593→273596实扣47、损15，幻象尚2HP；s273599才见其0HP/REVIVE_MOVE。",
        "current": "已有召唤等子实现；本批没有完整冻结A10召唤、双方成长、复现和退场的生产全链校准。",
        "reason": "缺A10召唤、航行双方成长、幻象复现与退场的完整生产校准，以及另一focus的完整后继；不能用未选候选强制首杀或登记整项duplicate。",
        "counter": "当轮总扣血47仍留下攻击者；原未选39伤/零损候选不是实际赢线，不将暂退等同永久击杀。",
        "verify": "冻结每个实体ID、HP、成长、召唤/复现与退场时点；保留全部合法目标，相同推演并列，再核不同focus的完整后继。",
    },
    {
        "title": "熟睡甲虫睡眠、醒后成长与换序血价",
        "evidence": "DUZUBAJ3A8GP A10 F30 s274913→274914睡3→2；s274929醒后力2，末试T6 s275022力4/攻22、1HP/16挡，s275023实死。首试T4 s274928→274929损2；末试s275012→275013损4，甲虫多扣3并未带来获胜。",
        "current": "已有睡眠等窄路径不能证明全部唤醒/眩晕接续与本进阶成长均已联合校准。",
        "reason": "四次尝试无胜线；缺伤害唤醒、睡眠/眩晕接续和当前进阶成长的完整生产校准，以及同抽换序完整后继，不能拟合固定杀序或输出血价。",
        "counter": "末试T4相对首试多扣3甲虫HP但多损2玩家HP；敌人少血不能单独证明更安全，截断尝试不补写完整结算。",
        "verify": "冻结睡层、覆甲、眩晕和醒后成长的独立状态链，使用同起点同抽序完整线路对照；保持未知，不据四次失败改权重。",
    },
]
assert len(details) == len(assigned) == 10
results = [{"id": a["add"]["id"], "state": "waiting", "reason": d["reason"]} for a, d in zip(assigned, details)]
(S / "proposal-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")

proofs = []
for commit, scope in [
    ("772b839f8ada31664cb764ea9ad3bdb03da27f64", "神化升级子实现"),
    ("3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17", "神化候选分账"),
    ("05cd292c6f01bb31e406473d3a9843e659d62b93", "候选审计"),
    ("bade647f9fe4c9103b40e2f26b26296692ad24b7", "单动作回执"),
    ("a8b1f8be153fe4f3a34146117546c2178f2e446b", "护栏审计"),
]:
    code = subprocess.run(["git", "merge-base", "--is-ancestor", commit, LIVE]).returncode
    assert code == 0
    proofs.append({"commit": commit, "scope": scope, "live": LIVE, "ancestor_rc": code,
                   "limitation": "只证明已有子实现，不证明原提案整体implemented或duplicate"})
(S / "partial-live-proofs.json").write_text(json.dumps(proofs, ensure_ascii=False, indent=2) + "\n")

text = f"""# 本批静默策略提案复核

记录时间：{now}。task=strategy-proposal；character=silent；batch={BATCH}。

## 身份与范围

本批普通队列只领取下列十个原ID。根learn.json本行task/character/worktree/runs均匹配，reason=proposal，无research_request、implementation_request或proposal_repair。普通专题文件绑定的是旧批20261010-150327，不属于本批；没有读取另一专题或退回整队列选题。开始时工作树干净，git merge --no-edit main返回Already up to date；base/HEAD为{BASE}。没有下级agent、联网、模型调用、play或游戏操作。

来源六局均在runs.jsonl核为SILENT、A10；旧运行源码均带dirty，不冒称已还原当时完整运行树。只分析派发六局、原Markdown、关联账本及silent经验；库中其他局的支持数仅保留上下文，不当本批独立实证。19个关联经验只读不改。没有新发现需要另建重复代码提案。

## 共同证据和现状

标准入口extract_evidence.py六默认流和runs/fight-plans补充流共6995条；两份manifest保存各流source_size、逐局计数、输出SHA，每行保留原line/offset/bytes/SHA。audit_evidence.py逐条回读原字节、JSON和显式身份，全部通过；身份冲突/未知不靠正文归属。run-plans以run所属，共33条；fight-plans在2233957字节截点为0，不能据此断言原日志缺失。states/decisions/brain各有2条全源坏行，仅保留流级计数，不归到本批。

全部3432个本批状态没有原始战内各堆卡实例字段；agent_view确有draw/discard/exhaust文本视图，不能把它说成没有牌堆信息，也不能等同完整确定抽序/实例/升级状态。s275687可见神化后的升级抽牌，但不能补齐所有后继和SL归属。固定证据中有11组算术/归属观察，见observations.json；这是证据核验，不是生产测试。

只读观察的实际live为{LIVE}。16个相关源码叶已逐文件保存Git blob/SHA/最近源码commit和祖先证明于source-manifest.json，源码副本均用.txt。11叶与本树相同、5叶不同，差异在live-source-differences.patch；判断已有实现以冻结的实际live字节为准，不把本树或旧树测试当当前live验证。partial-live-proofs.json只记录五个已有子实现的实际live祖先，不用于关闭宽提案。

## 逐项提案与处置

"""
for i, (a, d) in enumerate(zip(assigned, details), 1):
    original = a["add"]
    text += f"""### {i}. {original['id']}：{d['title']}

角色/进阶：silent/A10；账本：{', '.join(original['ledger'])}。原来源任务：{original['source_task']}；目标实现任务：strategy-proposal。原Markdown/SHA见proposal-source-manifest.json及同名.original.md。

证据：{d['evidence']}

现状：{d['current']}

反例与限制：{d['counter']}

旧/新行为：本批保留现行为；不增加规则、权重、阈值或删选项。预期行为仍以原提案为准：先恢复事实和未知边界，再据固定证据决定实现。授权Roy-2026-10-07-learning只提供修改权限，不提供数值。

处置：waiting。{d['reason']}

验证条件：{d['verify']} 以上均为后续验收条件，本批未执行新的生产验证。发现与校验来自相同六局，不称盲测；SL按局归并，未来独立完局才可做时间后移验证。预期影响只限追溯与消除错误归因，不承诺胜率改善。没有新增源码可回退；将来实现按实际源码提交回退，原日志/初稿/账本保留。

"""
text += """## 记录和交付边界

只向根ledger.py update提交本次报告/提案路径与处置说明，by=learner:strategy-proposal；不新增支持次数、不重写历史复盘、不改claim/首证/状态/version/effect，不标shipped。账本CLI原始输入与回执分别保存；若失败应保留并回报，不冒称完成。专用提案队列只通过最终proposal_results交原调度器登记，本任务不手写队列状态。

没有源码或知识改动，没有git commit、live merge、版本号、规则双通知或新的implemented/duplicate。tsc、vitest、生产固定case和撤源码红/恢复绿均未执行、不适用；最终tests三个null。已核证据算术不冒称这些检查通过。铁甲及其他角色行为保持等价。

原失败保留在collection-errors.txt：首次若干源码路径猜错；源码收集误用core/loop.ts退出1，后用实际hand/loop.ts完整重收；有界预读遇combat=null退出1，随后连续范围扫描遇无明确所属身份退出1并保留初稿。正式八流抽取与6995条审核独立完成，不放宽归属或覆盖失败初稿。没有把这些收集错误认定为代码失败。
"""
(S / "proposal.md").write_text(text)

table = "| 流 | 冻结源字节数 | 本批条数 |\n|---|---:|---:|\n"
for entry in audit["streams"]:
    table += f"| {entry['stream']} | {entry['source_size']} | {entry['verified_rows']} |\n"
report = f"""# 静默策略批次报告

记录时间：{now}。本批十个派发ID全部waiting；没有足够的新完整输入或受控证据改变策略，也没有可核整项完成的实际live源码证明。全部逐项证据/账本、已有子实现、反例和验收条件在[proposal.md](proposal.md)。

- batch：{BATCH}；character：silent。
- base/HEAD：{BASE}；起始clean，合main返回Already up to date；不提交、不改源码/知识/任务模板。
- runs：{', '.join(RUNS)}；六局均核SILENT/A10。
- fixes=[]；merged=null；无新版本、无shipped、无implemented/duplicate。
- tests={{"tsc":null,"vitest":null,"cases":null}}；无源码修改，未做源码消融或生产测试。
- 实际只读live观察：{LIVE}；16叶源码已冻结，5叶与本树不同；不转化为本批合入或测试结果。

## 证据核验

{table}

共6995条原始行逐offset/bytes/SHA/JSON/显式run身份核回，输出SHA和逐局计数匹配两份manifest。11组关键事实算术核回；前述结果不是策略效果或生产回归验证。run-plans为33条，fight-plans只在本截点为0；全源六条坏行不能归给本批。原始牌堆文本视图与缺完整实例/抽序分别记录，不把未选线补成实打。

## 十项结果

"""
for r in results:
    report += f"- {r['id']}：waiting。{r['reason']}\n"
report += f"""
## 交付与限制

提案交运维的真实路径：{S / 'proposal.md'}。
报告真实路径：{S / 'report.md'}。
原提案十份SHA均匹配登记值；原ID和来源任务不变。本批code_proposals列这十个已有CLI ID，不创建新ID；implementation_domains=[]，不把讨论领域当实际实现领域。26个既有账本只追加本次追溯链接和waiting说明，实际回执见ledger-update.stdout.log，未改原证据/状态/版本。CLI检查及末次Git状态另存验收文件，以真实结果为准。

未补齐的核心是完整执行认证、确定后继输入、属性/来源联合校准和同盘受控比较，不是权限待批准。原规则和所有角色行为保持；不通知Roy规则已改、不制造发布号、提交、合入或测试成功。原错误、零行/部分预读初稿和所有抽取材料保留。没有关闭学习父要求，也不声称经验已更新或消费者采用。
"""
(S / "report.md").write_text(report)

links = {}
for a, d in zip(assigned, details):
    for item in a["add"]["ledger"]:
        links.setdefault(item, []).append((a["add"]["id"], d["reason"]))
updates = [{"id": item, "by": "learner:strategy-proposal", "where": {"proposal": [str(S / "proposal.md"), str(S / "report.md")]},
            "note": f"本批{BATCH}只复核原六局，追加追溯，不新增支持或改状态：" + "；".join(i + " waiting：" + reason for i, reason in values)}
           for item, values in sorted(links.items())]
assert len(updates) == 26
(S / "ledger-update-input.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in updates))
result = {"task": "strategy-proposal", "character": "silent", "batch": BATCH,
          "base": BASE, "runs": RUNS, "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": [a["add"]["id"] for a in assigned], "implementation_domains": [],
          "proposal_results": results, "report": str(S / "report.md")}
(S / "report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"reports_written": True, "proposal_results": len(results), "ledger_updates_prepared": len(updates)}, ensure_ascii=False))

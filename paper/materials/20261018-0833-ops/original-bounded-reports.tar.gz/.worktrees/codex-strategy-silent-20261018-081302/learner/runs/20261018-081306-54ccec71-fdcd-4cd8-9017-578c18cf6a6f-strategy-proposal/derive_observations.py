import json
from pathlib import Path

S = Path(__file__).resolve().parent
states = [json.loads(line) for line in (S / "verified-state-summaries.jsonl").open()]
by_line = {x["reference"]["line"]: x for x in states}
decisions = [json.loads(line) for line in (S / "evidence/decisions.evidence.jsonl").open()]
by_decision = {x["line"]: x for x in decisions}
observations = []


def save(name, lines, text, **values):
    observations.append({"key": name, "state_references": [by_line[n]["reference"] for n in lines],
                         "observation": text, **values})


def at_decision(number):
    item = by_decision[number]
    row = item["row"]
    index = next(i for i, state in enumerate(states)
                 if state["reference"]["run_id"] == item["run_id"] and state["observed_ts"] == row["observed_ts"])
    return index, states[index]


before, after = by_line[275564], by_line[275565]
assert (before["player"]["energy"], after["player"]["energy"]) == (7, 5)
assert before["deck_upgraded"] == after["deck_upgraded"] == 1
for card_id, field, old, new in [("DEFEND_SILENT", "Block", 5, 8), ("STRIKE_SILENT", "Damage", 7, 10),
                                  ("DAGGER_SPRAY", "Damage", 5, 7)]:
    a = next(c for c in before["hand"] if c["card_id"] == card_id)
    b = next(c for c in after["hand"] if c["card_id"] == card_id)
    assert next(v["current_value"] for v in a["dynamic_values"] if v["name"] == field) == old
    assert next(v["current_value"] for v in b["dynamic_values"] if v["name"] == field) == new
    assert b["upgraded"]
assert next(c for c in after["hand"] if c["card_id"] == "TOOLS_OF_THE_TRADE")["energy_cost"] == 0
save("apotheosis_hand", [275564, 275565], "VLZ F35 T1：2能消耗及已见手牌升级，场外升级数保持1。")

a, b = by_line[275679], by_line[275687]
assert a["enemies"][0]["current_hp"] - b["enemies"][0]["current_hp"] == 51
assert a["player"]["current_hp"] - b["player"]["current_hp"] == 13
assert a["deck_upgraded"] == b["deck_upgraded"] == 4
p = json.loads(by_decision[269706]["row"]["questions"]["plan"]["criteria"]["plan1"])
q = json.loads(by_decision[269707]["row"]["questions"]["plan"]["criteria"]["plan1"])
assert (p["damage_dealt"], p["hp_lost"], q["damage_dealt"], q["hp_lost"]) == (43, 14, 51, 13)
save("apotheosis_forecast", [275679, 275680, 275687], "VLZ F43 T1：原候选43伤/14损，升级后51伤/13损且实盘兑现；不是整战因果实验。", decision_lines=[269706, 269707])

a = by_decision[269748]["row"]
b = by_decision[269754]["row"]
assert a["fingerprint"] != b["fingerprint"]
mc_a, mc_b = a["potions"]["random"][0], b["potions"]["random"][0]
assert (mc_a["samples"], mc_a["requested"], mc_a["ms"]) == (1, 12, 707)
assert (mc_b["samples"], mc_b["requested"]) == (12, 12)
assert a["rollout"]["horizon"] == 1 and a["rollout"]["best"] is None
observations.append({"key": "budget_not_paired", "run_id": "VLZ6CCT8AQ0A", "floor": 45, "turn": 1,
                     "decision_lines": [269748, 269754], "observation": "两问题面指纹不同；707ms的1/12与后问12/12不是同盘预算实验。"})
index, pre = at_decision(269754)
post = states[index + 1]
assert post["player"]["energy"] - pre["player"]["energy"] == 1
assert len(post["hand"]) - len(pre["hand"]) == 2
assert post["player"]["current_hp"] == pre["player"]["current_hp"] == 67
save("potion_actual", [pre["reference"]["line"], post["reference"]["line"]], "VLZ F45痊愈药水：实增1能、两牌，HP仍67；药名不证明回血。")
assert not any((x["row"].get("expect") or {}).get("card", {}).get("id") == "APOTHEOSIS"
               for x in decisions if x["run_id"] == "VLZ6CCT8AQ0A" and x["row"].get("floor") == 45)
assert by_line[275732]["hand"] == []
assert by_line[275732]["powers"]["FASTEN_POWER"] == 4
save("ownership_not_cast", [275722, 275729, 275731, 275732], "VLZ F45未记录神化施放；普通勒紧4与触媒1保持，生存者后手牌为空。")

assert by_decision[270216]["row"]["fingerprint"] == by_decision[270282]["row"]["fingerprint"]
costs = []
lines = []
for number in (270216, 270282):
    index, pre = at_decision(number)
    post = next(x for x in states[index + 1:] if x["reference"]["run_id"] == "8JRE1C4H4Z2W"
                and x["floor"] == 33 and x["turn"] == 3)
    costs.append((pre["player"]["current_hp"] - post["player"]["current_hp"],
                  pre["enemies"][0]["current_hp"] - post["enemies"][0]["current_hp"]))
    lines.extend([pre["reference"]["line"], post["reference"]["line"]])
assert costs == [(3, 10), (15, 17)]
save("sl_actual_cost", lines, "8JRE F33首/三试T2同指纹：实损3/15、实扣10/17，替线多12血换7伤。", decision_lines=[270216, 270282], outcomes=costs)
assert "0/24" in by_decision[270282]["row"]["sl_explore"]["numbers"]["original"]
assert "5/24" in by_decision[270282]["row"]["sl_explore"]["numbers"]["replacement"]

clam = [by_line[n] for n in (273238, 273252, 273263)]
assert [x["enemies"][0]["powers"].get("STRENGTH_POWER", 0) for x in clam] == [0, 4, 8]
assert [x["enemies"][0]["intents"][0]["total_damage"] for x in clam] == [11, 15, 19]
assert by_line[273268]["enemies"][0]["intents"][0]["total_damage"] == 14
assert by_line[273268]["player"]["current_hp"] == 2 and by_line[273268]["player"]["block"] == 10
assert all(x["powers"].get("DEXTERITY_POWER", 0) <= 0 for x in states if x["reference"]["run_id"] == "CA5KE8GFJ9X2")
save("clam_growth", [273238, 273252, 273263, 273268], "CA5 F13：0/4/8力、喷水11/15/19；末轮弱后14，2血10挡，完整需损4；本场无正敏捷实建。")

index, pre = at_decision(268455)
post = states[index + 1]
assert pre["player"]["energy"] - post["player"]["energy"] == 1
assert pre["enemies"] == post["enemies"]
assert pre["powers"].get("NOXIOUS_FUMES_POWER", 0) == 0
assert by_line[274200]["powers"]["NOXIOUS_FUMES_POWER"] == 3
assert by_line[274200]["powers"]["ACCELERANT_POWER"] == 1
assert by_line[274200]["powers"]["SERPENT_FORM_POWER"] == 4
save("setup_not_established", [274200, pre["reference"]["line"], post["reference"]["line"]],
     "5PM F33实建雾3/触媒1/群蛇4；F39末试T2无雾，向无毒失落打冒泡实耗1能且敌状态不变。两战不是同起点对照。", decision_lines=[268455])

assert by_line[273503]["powers"]["STRENGTH_POWER"] == 2
assert by_line[273504]["powers"].get("STRENGTH_POWER", 0) == 0
assert by_line[273504]["powers"]["DEXTERITY_POWER"] == -2
assert by_line[273504]["enemies"][0]["powers"]["STRENGTH_POWER"] == 2
assert by_line[273507]["player"]["block"] == 6
assert by_line[273507]["enemies"][0]["current_hp"] - by_line[273508]["enemies"][0]["current_hp"] == 33
save("siphon_separate_sources", [273503, 273504, 273507, 273508], "61E F17 T5→T6：玩家力2→0、敏0→-2、敌力0→2；T6双防御共6挡，17+16毒实扣33。无另一完整SL线路。")

assert by_line[273589]["enemies"][0]["powers"]["STRENGTH_POWER"] == 3
assert by_line[273596]["enemies"][0]["powers"]["STRENGTH_POWER"] == 6
assert sum(x["current_hp"] for x in by_line[273593]["enemies"]) - sum(x["current_hp"] for x in by_line[273596]["enemies"]) == 47
assert by_line[273593]["player"]["current_hp"] - by_line[273596]["player"]["current_hp"] == 15
assert by_line[273596]["enemies"][0]["current_hp"] == 2
save("obscura_entities", [273583, 273589, 273593, 273596, 273599], "61E F23：召21血幻象，双方航行增力3→6；T4实扣47、损15，T5幻象仍2血，后才暂退。未选focus不当已打胜线。")

assert by_line[274913]["enemies"][-1]["powers"]["SLUMBER_POWER"] == 3
assert by_line[274914]["enemies"][-1]["powers"]["SLUMBER_POWER"] == 2
assert by_line[274929]["enemies"][-1]["powers"]["STRENGTH_POWER"] == 2
assert by_line[275022]["enemies"][0]["powers"]["STRENGTH_POWER"] == 4
assert by_line[275022]["enemies"][0]["intents"][0]["total_damage"] == 22
assert by_line[275023]["player"]["current_hp"] == 0
assert by_line[274928]["player"]["current_hp"] - by_line[274929]["player"]["current_hp"] == 2
assert by_line[275012]["player"]["current_hp"] - by_line[275013]["player"]["current_hp"] == 4
save("beetle_growth_and_cost", [274913, 274914, 274928, 274929, 275012, 275013, 275022, 275023],
     "DUZ F30：睡层下降、醒后增力，末试T6力4/攻22实死；首试T4损2、末试损4，不能只凭多扣敌血拟合输出血价。")

(S / "observations.json").write_text(json.dumps(observations, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"observations": len(observations), "assertions": "全部通过", "scope": "证据算术和归属复核，不是生产测试"}, ensure_ascii=False))

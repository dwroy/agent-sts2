# 策略学习回报

本批十项均waiting；没有新增源码、知识、提交或live合入。核验时间：2026-10-17T10:25:55+08:00。

- task：strategy-proposal；character：silent；batch：20261017-101303-strategy-proposal。
- 完整base：`65e6a9ef31a272fe04809f9ccf938f73dbfb11af`，HEAD保持该值，Git tracked/index及可见非忽略文件干净。
- 派发行task/character/worktree/runs均匹配，reason=proposal；没有research_request、implementation_request或proposal_repair字段，只有这十个proposal_ids。普通专题请求仍绑定另一旧批次，未承接或读取其冻结正文。
- 六局runs.jsonl角色值均为SILENT、进阶10，运行code均有+dirty；当前源码只用于现状核查，不冒称还原六棵原运行dirty树。未读取其他角色专属知识或游戏二进制。

## 证据与复核

共用extract_evidence.py抽取八流，以每流开始读取时的source_size为边界；逐封套保存source/line/offset/bytes/SHA256，身份由显式字段判定，冲突不接收。verify_materials.py已将所有8274封套逐条与原文件原字节、SHA和身份对照，输出摘要在material-verification.json。

| 流 | 冻结source_size（字节） | 选中行数 |
|---|---:|---:|
| states | 13800530333 | 4062 |
| decisions | 2160134668 | 3941 |
| sl-attempts | 44874593 | 38 |
| run-config | 1928062 | 6 |
| run-plans | 8781604 | 33 |
| brain | 721372919 | 188 |
| runs | 355475 | 6 |
| fight-plans | 2233957 | 0 |

fight-plans选中0行仅描述本次截点和所选显式身份，不代表源文件缺失。run-plans选中33行，其中身份使用run字段。本批没有复核旧截点，不覆盖旧报告或零行初稿。

分析1033个限定楼层战斗帧、185个连续回合窗；原始全选中状态4062帧，决策3941行。19项确定性数值核验通过，四组原始fingerprint完全相同。这些是材料核验，不是生产测试、整线消费者认证或新独立对局。

| 配对 | 原线实际损血/本体净扣 | 替线实际损血/本体净扣 | 限制 |
|---|---|---|---|
| 8JRE F33 T2 首/第三试 | 3 / 10 | 15 / 17 | 同局，后继没有受控整战胜线 |
| YF F48 T1 第二/第三试 | 0 / 45 | 9 / 38 | 末试恢复防御续步仍败；本局F33有SL成功 |
| XP F33 T3 首/第二试 | 9 / 24 | 14 / 27 | 两线后继抽牌等不等价 |
| XP F33 T1 首/末试 | 2 / 25 | 10 / 34 | 替线另建1力量，不能忽略成长 |

死亡帧单独核：蚌2血10挡对14只实际损2；沙虫5血22挡对37只实际损5；实验体18血23挡对44差3；双蟹11血6挡对17实死。剩余毒结算以GAME_OVER原帧为据，不拿死亡截断实损替代完整所需损失，不由死亡后玩家powers清空推断返还。

## 原有源码覆盖及剩余范围

现状比对live提交：`1c8d6d2bd731514e5613ca63f46dc44fef2e59d5`。19个相关源码文件记录本地SHA与最近提交，这些提交均核为该live祖先；15个文件字节一致，4个仅既有Roy/Dai注释署名差，精确补丁保存在scratch。源码存在与祖先关系只证明窄覆盖，不表示十个原提案完整implemented/duplicate。

| 窄覆盖 | 实际live祖先源码commit | 仍不证明 |
|---|---|---|
| 候选原答/SL快照 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 完整候选已派发及执行 |
| 单动作回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | whole_plan_executed、actual_turn |
| HP护栏与SL比较 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 实际整轮保血及伤害收益 |
| 预测资源差 | 1698adc96ba434a46942321e0237b70657e625b2 | 后继重规划与逐来源实际资源 |
| 实验体现帧事实 | aad2700abed6dff1d66e87fb36aaa6fedb39adf3 | 完整候选施毒、伤害及阶段联合校准 |

其余成长、当前进阶数据库攻击与房间五样本入口见source-audit-expanded.json。本批没有读取刷新知识JSON来充当原运行的冻结移动表。当前代码与旧运行不等价时，本批不推断旧模拟必然按当前路径算过。

## 逐项处置

逐项原账本、证据局/层/回合、反例、旧行为、缺口、验证方法及回退均见proposal.md；下表为派发全量，无遗漏。

| 原提案id | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | waiting | 已核火花3→6、污染跨轮清零及T5实损9；缺原dirty运行的移动表冻结输入及挡/毒/成长/完整候选的联合消费者校准，既有逐击子模型不足以关闭整项，亦不足以新增少打技能规则。 |
| silent-proposal-ae9e692d680e3819 | waiting | 已核失落退场返4力及遗忘重抢2敏；缺逐敌被夺量真值、遗忘退场返敏及退场后同轮续步的完整消费者校准，不能由总属性推出来源返还量或规定固定击杀序。 |
| silent-proposal-52f1e1bd2e7db0ed | waiting | 已核两次加压各4力及弱后攻击；缺33f02a6f+dirty实际调用的冻结移动表、覆甲完整减层条件及联合消费者校准，当前DB入口存在不能冒称复原原运行输入。 |
| silent-proposal-6dd8bbff876be528 | waiting | 已核该局力量2→4和攻击17→19；缺新召唤/同名替换的独立身份真值、冻结移动输入及完整消费者后继校准，不能由同名或同上限证明旧计数可继承或已完全隔离。 |
| silent-proposal-578e415a259e6835 | waiting | 同盘血价和护栏实际窗口已核，原答/SL预测/单动作回执已有窄实现；剩余完整执行分段、重规划后归属、逐来源资源与整战后继未认证，不能以这些窄入口把整个宽提案记duplicate。 |
| silent-proposal-c0767768bf6a7ab1 | waiting | 已核同盘多损9且少扣7；候选预测已有窄实现，剩余整线执行、抽弃牌分段与完整后继联合校准不足，策略部分也缺受控整战对照，不据全败封顶拟HP惩罚或禁止探索。 |
| silent-proposal-a46bdb7fe711d79a | waiting | 阶段清毒、零毒触媒和后得敏捷时点已核且有窄实现；完整候选后续施毒、增段攻击、遗忘额外扣血/消耗及抽弃牌重规划的联合消费者仍未认证，不能关闭整个提案。 |
| silent-proposal-1044224808015e5c | waiting | 已核T3多损5多伤3、T1多损8多伤9并保留成长；缺同抽序完整替线后继及独立整战验证，不拟血价系数、禁全部付血探索或以零胜并列证明安全。完整执行审计仍是未认证范围。 |
| silent-proposal-7cbc6005db712ba9 | waiting | 已核14→20挡、临时减9后恢复及57→38→28；仍缺所有条件组合与完整候选实际兑现的联合消费者校准，不把分散的单项模型记整项duplicate，也不调整原出牌权重。 |
| silent-proposal-c59f592f1427a67e | waiting | 两局同盘血价和局部机制已核；分段实际执行、逐来源资源、阶段/朝向/临减的完整后继联合校准仍缺，已有窄入口不能拼成整个综合提案实现或长期策略收益。 |

## 验证、记录及边界

- 无生产代码改动：撤源码失败/恢复通过不适用；tsc、vitest、cases均null，未运行沙箱生产测试，不借旧批次绿测。本次两个scratch分析脚本与数值核验不算生产实现。
- 未提交，故没有新commit、gitleaks提交前扫描、eval版本、merged或shipped登记；live合入流程不触发。没有运行play、模型调用、网络、游戏模拟或改动运维prompt。
- 原账本只经根learner/ledger.py追加追溯链接和处置说明；不新增support/repeat，不改变claim、首证、prior、原evidence或已上线状态。本批没有新增知识条目。已proposed保持proposed，既有shipped只追加追溯，不降级为本次提案或再次宣称shipped。实际CLI回执与保护字段复核将在最终验收文件给出。
- 金刚杵→silent-0016为原稿既有归属错配，原claim是护喉甲；保留原稿和队列，本批仅标明不采纳该支持链接，不重复改写历史或重复登记新异议。
- 保留工具/分析初稿：初次角色断言未归一化SILENT大小写，纠正后通过；只读路径猜测中的不存在文件不作为缺证依据。material-verification.log保存材料核验错误：把斗篷后20挡误指278239（实际14），原帧显示278240才20；原失败脚本以.txt保存，修正版19项通过见material-verification-v2.log。初版shell末尾cat使外层返回0，不能当核验通过；修正版命令直接返回Python退出码0。未改断言20或原始证据。

完整机器回报另存final-report.json；提案队列状态由调用方按proposal_results消费，本批不自行改根learn.json或原请求。报告结束不代表经验已入库或大脑已采用。


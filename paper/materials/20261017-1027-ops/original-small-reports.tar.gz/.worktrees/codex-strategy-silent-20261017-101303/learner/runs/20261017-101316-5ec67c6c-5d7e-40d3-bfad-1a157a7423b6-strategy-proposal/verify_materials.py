import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract_evidence', OUT.parents[1] / 'extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verified = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = collections.Counter()
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source, path.open('rb') as envelopes:
        for raw in envelopes:
            digest.update(raw)
            env = json.loads(raw)
            assert env['offset'] + env['bytes'] <= stream['source_size']
            source.seek(env['offset'])
            original = source.read(env['bytes'])
            assert hashlib.sha256(original).hexdigest() == env['sha256']
            assert json.loads(original) == env['row']
            assert extractor.run_identity(env['row']) == env['run_id']
            counts[env['run_id']] += 1
    assert digest.hexdigest() == stream['output_sha256']
    assert all(counts[r] == n for r, n in stream['counts'].items())
    verified.append({'stream': name, 'verified_envelopes': sum(counts.values()),
                     'source_size': stream['source_size'], 'sha256': digest.hexdigest()})

states = {}
for raw in (OUT / 'evidence/states.evidence.jsonl').open():
    env = json.loads(raw)
    states[env['line']] = env


def power(line, id, enemy=False):
    combat = states[line]['row']['state']['combat']
    holder = combat['enemies'][0] if enemy else combat['player']
    return next((p['amount'] for p in holder['powers'] if p['power_id'] == id), 0)


def enemy(line, index=0):
    return states[line]['row']['state']['combat']['enemies'][index]


def hp(line):
    return states[line]['row']['state']['combat']['player']['current_hp']


checks = []


def check(label, observed, expected, lines):
    assert observed == expected, (label, observed, expected)
    checks.append({'claim': label, 'observed': observed,
                   'evidence': [{k: states[i][k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}
                                for i in lines]})


check('棱柱跨轮火花3→6', [power(274833, 'VITAL_SPARK_POWER', True), power(274834, 'VITAL_SPARK_POWER', True)], [3, 6], [274833, 274834])
check('棱柱污染6→轮初0→本轮18→轮初0', [power(i, 'TAINTED_POWER') for i in [274833, 274834, 274838, 274839]], [6, 0, 18, 0], [274833, 274834, 274838, 274839])
check('蚌两次加压各4力', [power(i, 'STRENGTH_POWER', True) for i in [273247, 273252, 273258, 273263]], [0, 4, 4, 8], [273247, 273252, 273258, 273263])
check('失落退场前后玩家负4力→0', [power(i, 'STRENGTH_POWER') for i in [274357, 274358]], [-4, 0], [274357, 274358])
check('遗忘再次抢夺玩家0敏→负2敏', [power(i, 'DEXTERITY_POWER') for i in [274361, 274362]], [0, -2], [274361, 274362])
check('实验体跨阶段111→212上限', [enemy(i)['max_hp'] for i in [277512, 277513]], [111, 212], [277512, 277513])
check('实验体跨阶段旧毒4→0且旧力15→0', [[power(i, p, True) for p in ['POISON_POWER', 'STRENGTH_POWER']] for i in [277512, 277513]], [[4, 15], [0, 0]], [277512, 277513])
check('末试已建触媒2但零毒', [power(277519, 'ACCELERANT_POWER'), power(277519, 'POISON_POWER', True)], [2, 0], [277519])
check('双蟹轮初14挡→斗篷后20挡', [states[i]['row']['state']['combat']['player']['block'] for i in [278236, 278240]], [14, 20], [278236, 278240])
check('镣铐暂减9力及次轮恢复', [power(i, 'STRENGTH_POWER', True) for i in [278236, 278237, 278242]], [0, -9, 0], [278236, 278237, 278242])
check('末试实验体23挡不倒补后得敏捷', [states[277527]['row']['state']['combat']['player']['block'], power(277527, 'DEXTERITY_POWER')], [23, 6], [277527])
check('末试实验体四刀和消耗额外扣血共37', enemy(277519)['current_hp'] - enemy(277527)['current_hp'], 37, [277519, 277527])
check('实验体同盘原线和替线实损0/9', [hp(277327)-hp(277337), hp(277366)-hp(277373)], [0, 9], [277327, 277337, 277366, 277373])
check('实验体同盘原线和替线敌本体扣45/38', [enemy(277327)['current_hp']-enemy(277337)['current_hp'], enemy(277366)['current_hp']-enemy(277373)['current_hp']], [45, 38], [277327, 277337, 277366, 277373])
check('沙虫同盘原线和替线实损3/15', [hp(276208)-hp(276212), hp(276274)-hp(276278)], [3, 15], [276208, 276212, 276274, 276278])
check('沙虫同盘原线和替线敌本体扣10/17', [enemy(276208)['current_hp']-enemy(276212)['current_hp'], enemy(276274)['current_hp']-enemy(276278)['current_hp']], [10, 17], [276208, 276212, 276274, 276278])
check('双蟹同盘T3原线和替线实损9/14', [hp(278028)-hp(278031), hp(278076)-hp(278079)], [9, 14], [278028, 278031, 278076, 278079])
check('双蟹同盘T1原线和替线实损2/10', [hp(278017)-hp(278023), hp(278231)-hp(278236)], [2, 10], [278017, 278023, 278231, 278236])
check('双蟹末试死亡后两侧剩153/125', [enemy(278261, i)['current_hp'] for i in [0, 1]], [153, 125], [278261])

(OUT / 'material-verification.json').write_text(json.dumps({'streams': verified, 'fact_checks': checks,
    'scope': '原始封套、身份与确定性数值核验；不是生产源码测试或完整候选消费者认证',
    'production_tests': None}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_envelopes': sum(x['verified_envelopes'] for x in verified),
                  'fact_checks': len(checks)}, ensure_ascii=False))

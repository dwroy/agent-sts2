import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
before = json.loads((OUT / 'ledger-protected-before.json').read_text())
spec = importlib.util.spec_from_file_location('root_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
path = ROOT / 'paper/materials/learning/ledger.jsonl'
raw = path.read_bytes()
assert hashlib.sha256(raw[:before['source_size']]).hexdigest() == before['prefix_sha256']
selected = []
own = []
offset = 0
for n, line in enumerate(raw.splitlines(keepends=True), 1):
    item = json.loads(line)
    if item.get('id') in before['items']:
        selected.append((n, item))
        if str(OUT / 'report.md') in item.get('where', {}).get('proposal', []):
            assert offset >= before['source_size']
            own.append({'source': str(path), 'line': n, 'offset': offset, 'bytes': len(line),
                        'sha256': hashlib.sha256(line).hexdigest(), 'row': item})
    offset += len(line)
assert len(own) == 30 and len({x['row']['id'] for x in own}) == 30
assert all(x['row']['by'] == 'learner:strategy-proposal' for x in own)
assert all('evidence' not in x['row'] and 'claim' not in x['row'] for x in own)
after = ledger.fold(selected)
for id, expected in before['items'].items():
    assert {k: after[id].get(k) for k in expected} == expected, id
(OUT / 'ledger-cli-trace.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in own))

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert head == dispatch['base']
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True)
assert status == ''
assert subprocess.check_output(['git', 'diff', '--binary', head]) == b''
assert subprocess.check_output(['git', 'diff', '--cached', '--binary', head]) == b''
q = json.loads((OUT / 'queue-selected.json').read_text())
for id, original in q['original'].items():
    assert hashlib.sha256((OUT / (id + '.original.md')).read_bytes()).hexdigest() == original['proposal_sha256']
result = json.loads((OUT / 'final-report.json').read_text())
assert result['report'] == str(OUT / 'report.md') and Path(result['report']).is_file()
assert [x['id'] for x in result['proposal_results']] == dispatch['dispatch']['proposal_ids']
assert all(x['state'] == 'waiting' and x['reason'] and 'commit' not in x for x in result['proposal_results'])
assert result['fixes'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
result['skipped'] = []
(OUT / 'final-report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

stamp = subprocess.check_output(['date', '-Is'], text=True).strip()
report = (OUT / 'report.md').read_text()
report += ('\n## 最终读回\n\n'
           f'{stamp}：根账本CLI实际追加30行，stdout/err原件及每行物理offset/bytes/SHA保存在'
           '`ledger-cli.out`、`ledger-cli.err`、`ledger-cli-trace.jsonl`。旧源前缀SHA未变，30条'
           'claim/首证/prior/evidence/status/version/shipped_at等保护字段逐值保持，无新增support/repeat。'
           '工作树HEAD与完整base一致，tracked/index及Git可见工作区干净；十原稿SHA未变。'
           '最终fixes=[]、merged=null、tests全null，十项完整waiting。\n')
(OUT / 'report.md').write_text(report)
checks = {'timestamp': stamp, 'base': head, 'git_status': status,
          'production_source_diff': False, 'ledger_updates': len(own),
          'old_ledger_prefix_unchanged': True, 'protected_ledger_items_unchanged': 30,
          'original_proposals_sha_verified': 10, 'proposal_results_complete': True,
          'production_tests': {'tsc': None, 'vitest': None, 'cases': None},
          'report_sha256': hashlib.sha256((OUT / 'report.md').read_bytes()).hexdigest()}
(OUT / 'final-verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
manifest = []
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name != 'artifact-manifest.json':
        digest = hashlib.sha256()
        with p.open('rb') as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                digest.update(block)
        manifest.append({'path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': digest.hexdigest()})
(OUT / 'artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(checks, ensure_ascii=False, indent=2))

import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())['dispatch']
RUNS = set(DISPATCH['runs'])
FLOORS = {
    'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13}, '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33},
}
DECISION_ANCHORS = {
    270216, 270282, 270264, 271309, 271348, 271354,
    271495, 271509, 271992, 272040, 271982, 272195, 272076,
}


def powers(holder):
    return {p['power_id']: p.get('amount') for p in holder.get('powers', [])}


def ref(env):
    return {k: env[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def snapshot(env):
    row = env['row']
    s = row['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {
        **ref(env), 'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
        'floor': (s.get('run') or {}).get('floor'), 'turn': s.get('turn'),
        'screen': s.get('screen'), 'hp': p.get('current_hp'),
        'block': p.get('block'), 'energy': p.get('energy'), 'powers': powers(p),
        'cards_played': p.get('cards_played_this_turn'),
        'attacks_played': p.get('attacks_played_this_turn'),
        'hand': [{'id': x.get('card_id'), 'index': x.get('index'),
                  'upgraded': x.get('upgraded')} for x in c.get('hand', [])],
        'enemies': [{
            'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
            'max_hp': e.get('max_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
            'move': e.get('move_id'), 'powers': powers(e),
            'attacks': [a.get('total_damage') for a in e.get('intents', [])
                        if a.get('intent_type') == 'Attack'],
        } for e in c.get('enemies', [])],
    }


def load_stream(name):
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    with path.open() as f:
        for raw in f:
            env = json.loads(raw)
            assert env['run_id'] in RUNS
            yield env


def main():
    compact = []
    counts = collections.Counter()
    state_refs = {}
    for env in load_stream('states'):
        counts[env['run_id']] += 1
        s = env['row']['state']
        assert str((s.get('run') or {}).get('character_id')).lower() == 'silent'
        assert (s.get('run') or {}).get('ascension') == 10
        if s.get('in_combat') and (s.get('run') or {}).get('floor') in FLOORS[env['run_id']]:
            item = snapshot(env)
            compact.append(item)
            state_refs[env['line']] = item
    (OUT / 'state-snapshots.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in compact))

    groups = []
    last_key = None
    attempts = collections.Counter()
    previous_turn = {}
    for item in compact:
        rf = (item['run_id'], item['floor'])
        t = item['turn']
        if rf not in previous_turn or t < previous_turn[rf]:
            attempts[rf] += 1
        previous_turn[rf] = t
        key = (*rf, attempts[rf], t)
        if key != last_key:
            groups.append({'run_id': key[0], 'floor': key[1], 'attempt': key[2],
                           'turn': key[3], 'first': item, 'last': item, 'frames': 1})
            last_key = key
        else:
            groups[-1]['last'] = item
            groups[-1]['frames'] += 1
    for i, group in enumerate(groups):
        if i + 1 < len(groups):
            nxt = groups[i + 1]
            if (group['run_id'], group['floor'], group['attempt']) == (nxt['run_id'], nxt['floor'], nxt['attempt']):
                group['next_turn_first'] = nxt['first']
                group['observed_hp_change_to_next_turn'] = group['first']['hp'] - nxt['first']['hp']
        # A turn boundary is evidence; it does not certify every original candidate step was dispatched.
        group['whole_candidate_executed'] = None
    (OUT / 'turn-windows.json').write_text(json.dumps(groups, ensure_ascii=False, indent=2) + '\n')

    anchors = []
    decisions_count = collections.Counter()
    for env in load_stream('decisions'):
        decisions_count[env['run_id']] += 1
        if env['line'] in DECISION_ANCHORS:
            row = env['row']
            anchors.append({**ref(env), 'row': row})
    assert {x['line'] for x in anchors} == DECISION_ANCHORS
    (OUT / 'decision-anchors.json').write_text(json.dumps(anchors, ensure_ascii=False, indent=2) + '\n')
    by_line = {x['line']: x['row'] for x in anchors}
    pairs = []
    for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
        assert by_line[a]['fingerprint'] == by_line[b]['fingerprint']
        pairs.append({'decisions': [a, b], 'fingerprint_equal': True,
                      'run_id': next(x['run_id'] for x in anchors if x['line'] == a)})
    summary = {'state_counts': dict(counts), 'decision_counts': dict(decisions_count),
               'selected_state_frames': len(compact), 'turn_windows': len(groups),
               'attempts_by_floor': {f'{r}/F{f}': n for (r, f), n in attempts.items()},
               'same_fingerprint_pairs': pairs,
               'production_tests': None}
    (OUT / 'evidence-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

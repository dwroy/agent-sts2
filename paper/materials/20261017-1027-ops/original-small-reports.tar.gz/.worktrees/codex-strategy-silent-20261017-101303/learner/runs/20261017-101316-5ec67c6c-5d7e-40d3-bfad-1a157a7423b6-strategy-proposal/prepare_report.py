import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((OUT / 'dispatch.json').read_text())
queue = json.loads((OUT / 'queue-selected.json').read_text())
items = json.loads((OUT / 'dispositions.json').read_text())
assert [x['id'] for x in items] == dispatch['dispatch']['proposal_ids']
summary = json.loads((OUT / 'evidence-summary.json').read_text())
verification = json.loads((OUT / 'material-verification.json').read_text())
source = json.loads((OUT / 'source-audit-expanded.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == dispatch['base'] and len(base) == 40
assert subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True) == ''
timestamp = subprocess.check_output(['date', '-Is'], text=True).strip()

proposal = [
    '# 本批指定策略提案的证据核验与处置', '',
    f'核验时间：{timestamp}。角色silent，批次20261017-101303-strategy-proposal。',
    f'基线：`{base}`；普通提案消费任务，开工合并main返回Already up to date。',
    '仅处理原CLI已登记的十个id，不新增提案id，不承接其他专题。全部处置为waiting，保留当前行为。', '',
    '本批原稿逐份保存为`<id>.original.md`，全部SHA与队列首条一致；原稿未改写。'
    '账本是原有链接，不代表本次新增发现或再次上线。Roy授权只提供改规则权限。', '',
]
for i, item in enumerate(items, 1):
    original = queue['original'][item['id']]
    proposal += [
        f'## {i}. {item["title"]}', '', f'- 提案：`{item["id"]}`；处置：waiting。',
        f'- 证据范围：{item["location"]}。',
        '- 原账本：' + '、'.join(f'`{x}`' for x in original['ledger']) + '。',
        f'- 已核证据：{item["evidence"]}', f'- 反例/限制：{item["counterexample"]}',
        f'- 当前行为与已有覆盖：{item["current"]}',
        f'- 未实现原因：{item["reason"]}',
        f'- 预期行为与验证：{item["next_validation"]}',
        '- 拟合与切分：只核本角色已观察A10；同存档尝试按run_id聚合，不拟新权重。'
        '本批六锚点不是独立后移验证集，未选长期后继保留未知。',
        '- 回退：本批无源码/知识修改，无需生产回退；未来实际实现须独立撤源失败/恢复通过、'
        '原沙箱测试与live合入。事实审计本身不要求先证明胜率提高，尚未认证的范围不标完成。', '',
    ]
(OUT / 'proposal.md').write_text('\n'.join(proposal) + '\n')

results = [{'id': x['id'], 'state': 'waiting', 'reason': x['reason']} for x in items]
report = [
    '# 策略学习回报', '',
    f'本批十项均waiting；没有新增源码、知识、提交或live合入。核验时间：{timestamp}。', '',
    f'- task：strategy-proposal；character：silent；batch：20261017-101303-strategy-proposal。',
    f'- 完整base：`{base}`，HEAD保持该值，Git tracked/index及可见非忽略文件干净。',
    '- 派发行task/character/worktree/runs均匹配，reason=proposal；没有research_request、'
    'implementation_request或proposal_repair字段，只有这十个proposal_ids。普通专题请求仍绑定另一旧批次，未承接或读取其冻结正文。',
    '- 六局runs.jsonl角色值均为SILENT、进阶10，运行code均有+dirty；当前源码只用于现状核查，'
    '不冒称还原六棵原运行dirty树。未读取其他角色专属知识或游戏二进制。',
    '', '## 证据与复核', '',
    '共用extract_evidence.py抽取八流，以每流开始读取时的source_size为边界；'
    '逐封套保存source/line/offset/bytes/SHA256，身份由显式字段判定，冲突不接收。'
    'verify_materials.py已将所有8274封套逐条与原文件原字节、SHA和身份对照，输出摘要在material-verification.json。', '',
    '| 流 | 冻结source_size（字节） | 选中行数 |', '|---|---:|---:|',
]
for stream in verification['streams']:
    report.append(f'| {stream["stream"]} | {stream["source_size"]} | {stream["verified_envelopes"]} |')
report += [
    '', 'fight-plans选中0行仅描述本次截点和所选显式身份，不代表源文件缺失。'
    'run-plans选中33行，其中身份使用run字段。本批没有复核旧截点，不覆盖旧报告或零行初稿。', '',
    f'分析{summary["selected_state_frames"]}个限定楼层战斗帧、{summary["turn_windows"]}个连续回合窗；'
    '原始全选中状态4062帧，决策3941行。19项确定性数值核验通过，四组原始fingerprint完全相同。'
    '这些是材料核验，不是生产测试、整线消费者认证或新独立对局。', '',
    '| 配对 | 原线实际损血/本体净扣 | 替线实际损血/本体净扣 | 限制 |',
    '|---|---|---|---|',
    '| 8JRE F33 T2 首/第三试 | 3 / 10 | 15 / 17 | 同局，后继没有受控整战胜线 |',
    '| YF F48 T1 第二/第三试 | 0 / 45 | 9 / 38 | 末试恢复防御续步仍败；本局F33有SL成功 |',
    '| XP F33 T3 首/第二试 | 9 / 24 | 14 / 27 | 两线后继抽牌等不等价 |',
    '| XP F33 T1 首/末试 | 2 / 25 | 10 / 34 | 替线另建1力量，不能忽略成长 |',
    '', '死亡帧单独核：蚌2血10挡对14只实际损2；沙虫5血22挡对37只实际损5；'
    '实验体18血23挡对44差3；双蟹11血6挡对17实死。剩余毒结算以GAME_OVER原帧为据，'
    '不拿死亡截断实损替代完整所需损失，不由死亡后玩家powers清空推断返还。', '',
    '## 原有源码覆盖及剩余范围', '',
    f'现状比对live提交：`{source["live"]}`。19个相关源码文件记录本地SHA与最近提交，'
    '这些提交均核为该live祖先；15个文件字节一致，4个仅既有Roy/Dai注释署名差，精确补丁保存在scratch。'
    '源码存在与祖先关系只证明窄覆盖，不表示十个原提案完整implemented/duplicate。', '',
    '| 窄覆盖 | 实际live祖先源码commit | 仍不证明 |', '|---|---|---|',
    '| 候选原答/SL快照 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 完整候选已派发及执行 |',
    '| 单动作回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | whole_plan_executed、actual_turn |',
    '| HP护栏与SL比较 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 实际整轮保血及伤害收益 |',
    '| 预测资源差 | 1698adc96ba434a46942321e0237b70657e625b2 | 后继重规划与逐来源实际资源 |',
    '| 实验体现帧事实 | aad2700abed6dff1d66e87fb36aaa6fedb39adf3 | 完整候选施毒、伤害及阶段联合校准 |',
    '', '其余成长、当前进阶数据库攻击与房间五样本入口见source-audit-expanded.json。'
    '本批没有读取刷新知识JSON来充当原运行的冻结移动表。当前代码与旧运行不等价时，'
    '本批不推断旧模拟必然按当前路径算过。', '',
    '## 逐项处置', '',
    '逐项原账本、证据局/层/回合、反例、旧行为、缺口、验证方法及回退均见proposal.md；下表为派发全量，无遗漏。', '',
    '| 原提案id | 状态 | 具体缺口 |', '|---|---|---|',
]
for item in items:
    report.append(f'| {item["id"]} | waiting | {item["reason"]} |')
report += [
    '', '## 验证、记录及边界', '',
    '- 无生产代码改动：撤源码失败/恢复通过不适用；tsc、vitest、cases均null，未运行沙箱生产测试，'
    '不借旧批次绿测。本次两个scratch分析脚本与数值核验不算生产实现。',
    '- 未提交，故没有新commit、gitleaks提交前扫描、eval版本、merged或shipped登记；live合入流程不触发。'
    '没有运行play、模型调用、网络、游戏模拟或改动运维prompt。',
    '- 原账本只经根learner/ledger.py追加追溯链接和处置说明；不新增support/repeat，不改变claim、'
    '首证、prior、原evidence或已上线状态。本批没有新增知识条目。已proposed保持proposed，'
    '既有shipped只追加追溯，不降级为本次提案或再次宣称shipped。实际CLI回执与保护字段复核将在最终验收文件给出。',
    '- 金刚杵→silent-0016为原稿既有归属错配，原claim是护喉甲；保留原稿和队列，'
    '本批仅标明不采纳该支持链接，不重复改写历史或重复登记新异议。',
    '- 保留工具/分析初稿：初次角色断言未归一化SILENT大小写，纠正后通过；'
    '只读路径猜测中的不存在文件不作为缺证依据。material-verification.log保存材料核验错误：'
    '把斗篷后20挡误指278239（实际14），原帧显示278240才20；原失败脚本以.txt保存，'
    '修正版19项通过见material-verification-v2.log。初版shell末尾cat使外层返回0，'
    '不能当核验通过；修正版命令直接返回Python退出码0。未改断言20或原始证据。',
    '', '完整机器回报另存final-report.json；提案队列状态由调用方按proposal_results消费，'
    '本批不自行改根learn.json或原请求。报告结束不代表经验已入库或大脑已采用。', '',
]
(OUT / 'report-draft.md').write_text('\n'.join(report) + '\n')
(OUT / 'report.md').write_text('\n'.join(report) + '\n')
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'],
         'base': base, 'runs': dispatch['dispatch']['runs'], 'fixes': [],
         'skipped': [{'id': x['id'], 'reason': x['reason']} for x in items], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['dispatch']['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'final-report.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('root_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = {i for x in queue['original'].values() for i in x['ledger']}
raw_ledger = (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()
selected = [(n, x) for n, line in enumerate(raw_ledger.splitlines(), 1)
            if (x := json.loads(line)).get('id') in ids]
folded = ledger.fold(selected)
assert set(folded) == ids and all(x['character'] == 'silent' for x in folded.values())
protected_keys = ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note',
                  'prior_runs', 'evidence', 'status', 'version', 'shipped_at']
protected = {i: {k: item.get(k) for k in protected_keys} for i, item in folded.items()}
(OUT / 'ledger-protected-before.json').write_text(json.dumps({'source_size': len(raw_ledger),
    'prefix_sha256': hashlib.sha256(raw_ledger).hexdigest(), 'items': protected}, ensure_ascii=False, indent=2) + '\n')
updates = []
for id in sorted(ids):
    linked = [x for x in items if id in queue['original'][x['id']]['ledger']]
    update = {'id': id, 'by': 'learner:strategy-proposal',
              'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
              'note': '20261017-101303-strategy-proposal：仅核本批六局Silent A10既有证据；关联原CLI提案' +
                      '、'.join(x['id'] for x in linked) + '均waiting。详见本批proposal.md逐项缺口；'
                      '无源码、提交、合入、版本或新增support/repeat，不改旧claim/首证/prior/evidence/已上线状态。' +
                      ('原稿金刚杵→本账本为既有归属错配，本批不将其视作支持，原claim保持。' if id == 'silent-0016' else '')}
    if folded[id]['status'] == 'proposed':
        update['status'] = 'proposed'
    updates.append(update)
(OUT / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'report.md'), 'proposals': len(items),
                  'ledger_trace_updates_prepared': len(updates)}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
previous = root / '.worktrees/codex-strategy-silent-20261017-004303/learner/runs/20261017-004316-c5b34dde-6fac-4b32-9f97-ce80ef0033be-strategy-proposal'
prior = json.loads((previous / 'source-audit.json').read_text())
dispatch = json.loads((scratch / 'dispatch.json').read_text())
base = dispatch['base']
live = subprocess.check_output(['git', '-C', str(root / '.worktrees/live'), 'rev-parse', 'HEAD'], text=True).strip()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=workspace)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

files = []
paths = [entry['path'] for entry in prior['files']]
for path in paths:
    raw = (workspace / path).read_bytes()
    old = git('show', prior['base'] + ':' + path)
    published = git('show', live + ':' + path)
    assert raw == git('show', base + ':' + path)
    actual_live = (root / '.worktrees/live' / path).read_bytes()
    files.append({'path': path, 'base_sha256': sha(raw), 'previous_base_sha256': sha(old),
                  'same_as_previous_base': raw == old, 'live_sha256': sha(published),
                  'same_as_live': raw == published, 'live_source_clean_at_read': actual_live == published})
ancestors = []
for old in prior['ancestors']:
    commit = old['commit']
    ancestors.append({'commit': commit, 'subject': git('show', '-s', '--format=%s', commit).decode().strip(),
                      'base': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, base], cwd=workspace).returncode == 0,
                      'live': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live], cwd=workspace).returncode == 0})
for name, left, right in [('previous-base-source.patch', prior['base'], base), ('base-live-source.patch', base, live)]:
    (scratch / name).write_bytes(git('diff', '--binary', left, right, '--', *paths))
result = {'base': base, 'live_read_only': live, 'previous_audit': str(previous / 'source-audit.json'),
          'previous_audit_sha256': sha((previous / 'source-audit.json').read_bytes()),
          'files': files, 'ancestors': ancestors}
(scratch / 'source-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
originals = json.loads((scratch / 'original-proposals.json').read_text())
index = []
for entry in originals:
    raw = Path(entry['proposal']).read_bytes()
    assert sha(raw) == entry['proposal_sha256']
    target = scratch / (entry['id'] + '.original.md')
    target.write_bytes(raw)
    index.append({'id': entry['id'], 'source': entry['proposal'], 'copy': str(target), 'bytes': len(raw), 'sha256': sha(raw)})
(scratch / 'original-proposal-index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
(scratch / 'batch.json').write_text(json.dumps(dispatch['dispatch'], ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(files), 'changed_since_previous': [x['path'] for x in files if not x['same_as_previous_base']],
                  'different_from_live': [x['path'] for x in files if not x['same_as_live']], 'ancestors': ancestors,
                  'original_proposals_sha_verified': len(index)}, ensure_ascii=False))

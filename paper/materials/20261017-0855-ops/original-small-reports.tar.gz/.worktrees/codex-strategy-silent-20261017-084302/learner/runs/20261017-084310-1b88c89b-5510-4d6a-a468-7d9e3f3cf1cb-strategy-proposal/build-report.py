import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()

def read(name):
    return json.loads((scratch / name).read_text())

dispatch = read('dispatch.json')
base = dispatch['base']
batch = dispatch['batch']
runs = dispatch['dispatch']['runs']
dispositions = read('dispositions.json')
source = read('source-audit.json')
integrity = read('integrity.json')
checks = read('evidence-checks.json')
consumers = read('prior-consumer-receipt.json')
run_info = read('run-identities.json')
old_plans = read('old-plans-audit.json')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
          'runs': runs, 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['dispatch']['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{'id': x['id'], 'state': x['state'], 'reason': x['reason']} for x in dispositions],
          'report': str(scratch / 'report.md')}
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

proposal = [f'# 静默策略提案逐项复核\n\n记录时间：{stamp}（先执行date）。',
            f'本批 `{batch}`；完整base：`{base}`。仅处理派发的十个原CLI ID，十项均waiting；没有新源码、知识、行为规则或新提案ID。',
            '依据本批五局原始证据和现有源码复核，不从自己的游戏知识补结论。A10四局与A5一局分列；同局SL不当独立样本。旧运行dirty，当前源码不冒充历史完整树。',
            '拟合与时间切分：不拟合新阈值、牌值、药水持有价或胜率参数。本批五局是原诊断资料；之后独立结束的可比静默局才可作为后置验证。已有部分实现分别登记真实祖先，不用它关闭原宽范围。',
            '共同回退和边界：本批无行为差量可回退。保留源码、原日志、历史复盘、原提案和失败回执；后续若有独立修复，再按固定正反例、撤源码失败/恢复通过及原沙箱入口验证后合入live。铁甲和未观察范围保持现状。']
for item in dispositions:
    proposal += [f"## {item['id']}：{item['state']}",
                 f"原题：{item['original_proposal']}；SHA256：`{item['original_sha256']}`。原字节副本：`{item['id']}.original.md`。",
                 f"账本：{', '.join(item['ledger'])}。证据：{item['evidence']}",
                 f"旧规则/现有覆盖：原规则保留。已核live祖先子项：{', '.join(item['source_coverage']) or '无可关闭整项的实现'}；对应源码职责见source-audit.json。",
                 f"反例和限制：{item['counterexample']}",
                 f"期望行为：{item['expected']}",
                 f"验证方法：{item['validation']}",
                 f"本批处置及缺数据：{item['reason']}",
                 '原始引用：']
    for ref in item['evidence_refs']:
        proposal.append(f"- {Path(ref['source']).name}:{ref['line']}；run={ref['run_id']}；offset={ref['offset']}；bytes={ref['bytes']}；SHA256={ref['sha256']}")
    proposal.append('')
proposal += ['## 后续交付边界',
             '本批是普通队列复核，未承接手动专题或实现冻结请求；不修改根请求、调度状态、其他ID或其他角色知识。',
             '没有新的科学异议或旧知识冲突，原提案的限制继续保留，不重写历史复盘。不代ops/watcher/Roy确认，不把报告完成当学习入库或量化父要求关闭。',
             f'完整报告：{scratch / "report.md"}；机器结果：{scratch / "result.json"}。']
(scratch / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')

stream_table = '\n'.join(f"| {x['stream']} | {x['source_size']} | {x['verified_rows']} | {str(x['same_selected_bytes_as_prior']).lower()} |" for x in integrity)
run_table = '\n'.join(f"| {run} | {run_info[run]['character']} | {run_info[run]['ascension']} | F{run_info[run]['floor']} {'胜' if run_info[run]['victory'] else '败'} |" for run in runs)
consumer_table = '\n'.join(f"| {x['run']} | {x['segments']} | {x['actions']} | {x['turns']['observed_turn_endpoints']} | {x['turns']['unknown']} | {x['certified_full_candidates']} |" for x in consumers['summary'])
result_table = '\n'.join(f"| {x['id']} | {x['state']} | {x['reason']} |" for x in dispositions)
ancestor_table = '\n'.join(f"| {x['commit']} | {x['subject']} | {str(x['base']).lower()}/{str(x['live']).lower()} |" for x in source['ancestors'])
report = f'''# 静默策略队列复核报告

记录时间：{stamp}（先执行date）。task=strategy-proposal，character=silent，batch={batch}。

十个原提案均waiting：本批没有新增能支持规则修改的实盘输入，当前也未定位新的可隔离源码失配。fixes=[]、merged=null；没有源码或知识提交、eval版本、implemented或shipped声明。部分现有实现继续复用，各原宽项和学习父要求保留。

完整base/HEAD：`{base}`。开工git status为空，普通身份核实后git merge --no-edit main返回Already up to date。

## 身份与范围

已读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol、learning-code-proposals、learning-requests和fix-queue的相关原项。根learn.json只读本批行，task/character/worktree/五个runs/十个proposal_ids核对；没有research_request、implementation_request和proposal_repair。普通专题文件仍绑定另一个旧批，本批不承接专题，也不领取其他队列项。独立完成，未派下级agent。

| 局号 | 角色 | 进阶 | 结果 |
|---|---|---:|---|
{run_table}

ZE8 A5只作抑制现场版本观察，不混作A10策略验证。只读本角色知识中的21个关联经验条目，保存内容及整文件SHA，不把知识文本更新视为本批实盘。五局run-config的历史完整commit和dirty_files另存historical-source-limits.json；旧dirty输入未完整重建，当前代码不能充作历史运行树。兼容deepseek_calls字段不单独证明实际引擎。

## 证据完整性

使用本树extract_evidence.py，以nice10从只读logs提取八流。全部6060封套逐行seek原源核offset/bytes/SHA/JSON、截点及显式局身份；run-plans.run和run_id/state.run_id/fingerprint.run沿共用入口读取，冲突身份拒收。每流截点分别冻结，不称同一墙钟快照。

| 流 | source_size | 核验条数 | 与旧同范围封套相同 |
|---|---:|---:|---|
{stream_table}

八流选中内容与原061302-s2及上一004303同五局范围一致；全源扫描边界增长没有增加本批独立局或SL支持。fight-plans零行只说明该截点未选到，不断言原流不存在。states/decisions/brain各有2条无法解析的全源行，不将其归为本批局故障。

旧run-plans截点{old_plans['old_source_size']}独立用同入口--streams run-plans --source-size复核并另存evidence-old-plans；与本次{old_plans['current_source_size']}截点同30行/同SHA。所有旧报告、零行初稿和失败历史保持。

重算37项固定材料断言，通过；本批另核两对原指纹及完整原手牌相同、原提案全部引用匹配本次封套，并读回KFR旧护栏rationale和GX抑制版本帧。它们是材料核验，不是生产tsc/vitest/cases。同指纹同手牌仍不能证明隐藏状态及整战后继相同。

## 实盘支持、反例与未知

- MTQ F23末试T3两候选均24/24死亡，模型即时损血0/8、扣敌13/19仍不同；实帧T3到T4从10到2血。原线先前已失败，探索替线不等宣称更安全，不能凭饱和死亡率制定保血或SL阈值。
- 7X F31三段初血合150，可见帧差增加175、下降278、末残47。已发生重接不能当永久击杀，帧差也不是完整逐来源伤害或持续实体认证。
- KFR F33T6两试同15HP/228敌HP/36毒/3覆甲，原线净扣83损6，替线净扣93损12；之后均失败。F12 decisions282578的护栏在rationale而非结构化hp_guard字段：原答plan5，journal改为斗篷起手；282579生刀后重问改蛇咬/中和/小刀。实际损6不能归到原完整0损候选。
- KFR末T7手上技法7挡、防御后12挡，三次手动动作满额，爆发剩1能仍锁；毒药37→43当步敌159不变，随后43+42=85，敌余74。手法7挡已兑现，换对象、顺序或提前喝药的整战结果未知。
- GX F45同T2后3/13血、0/7挡，保血线敌多8HP；末13HP+23挡+2覆甲对40需损15，hpAfter=-2与实死一致。缺完整复活瞬时逐击、未截断入伤和前三出口，不由净血差拟新评分。
- GX F33已建触媒2层才有29+28+27=84；末战未建立不能预支。四次SL普通键inserted及旧升级键作差仍在，但T2→T3伴随抽牌，缺改标后原牌全留抽堆的独立瞬时帧和稳定物理副本身份；基ID总量守恒不足以安全延长已知抽序。ZE8 A5现场普通版与场外升级分账。
- MTQ跨幕19→59、KFR跨幕22→60可核，但营火、开场和SL恢复必须分别归属。没有可比替路线后继，不能从六次回血仍败调整休息/锻造阈值。

本批没有重算原提案全部历史药水/营火总额，不把其旧全史统计冒作本批样本；没有未执行候选、未走路线或提前喝药的受控整战结论。

## 现有实现及离线消费者

只读live提交：`{source['live_read_only']}`，不是本批merged。23个相关源码叶中19个与上一004303基线相同；4个变化为selection的沙坑弃牌入口、combat-plan的普通计算下注重抽，以及card-model/turn-solver的DAGGER_SPRAY+紧勒触发覆盖。这些变化未关闭本批原宽提案，不把别批新来源冒成本批证据。与live相比18叶同字节，5叶只差历史Roy/Dai署名，实际物理文件与live HEAD相符；两份精确git diff --binary保存，不由23叶推断全树等价。

直接读回：奇巧facts仍continuation_verified=false，selection_audit.actual_turn=null，SL资源比较scope=current_turn_prediction且execution=unverified；离线actual_uncapped_hp_loss、actual_full_candidate_result和causal_source仍null。run-journal给HP增加边界而非完整因果，resource_chain明确药槽变化不能独自识别饮用/丢弃。已有受限通道不等完整归属或联合校准。

| 实际源码祖先commit | 已有子项 | base/live祖先 |
|---|---|---|
{ancestor_table}

20份原消费者输入/输出/stderr/退出码及资源链产物按原manifest逐SHA复核；四个A10输入由本次原帧重新构建后逐字相等。消费者8个递归依赖/入口与原实际consumer_base同字节，本批没有重跑消费者、模型或模拟池；原rc0只保持历史归属，不算本批测试。

| A10局 | 候选段 | 有ID动作 | 已核回合端点 | 未知回合窗 | 完整候选认证 |
|---|---:|---:|---:|---:|---:|
{consumer_table}

合483候选段、2101有ID动作，352回合窗中70个已核端点、282未知。KFR一条/GX三条无decision_id元数据排除并保留，不补ID；完整候选认证0表示保守工具未认证，不等于实际未执行。未进行完整后继、整战因果或自然消费者采用验收。

## 逐项处置

证据局号/层/回合、账本id、反例、旧规则、期望行为、验证与原字节引用逐项见proposal.md和dispositions.json；原十份Markdown逐SHA复制保留。

| 原CLI ID | 状态 | 具体缺口 |
|---|---|---|
{result_table}

## 记录与交付

仅经根learner/ledger.py update给24个既有相关账本追加本批proposal/report追溯；不新增support/repeat，不改claim/first_run/prior/evidence/status/version/effect/shipped，不重复历史复盘或创建新提案。实际CLI及追加物理行核验以ledger-receipt.json为准，code_proposals沿用十个原CLI ID，implementation_domains=[]。

无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均未运行，tests固定为null；材料断言不作生产cases。无源码提交，不运行提交前gitleaks和沙箱测试，不合入live或创建eval版本/上线行/规则双通知，不冒implemented/shipped。保留原日志与当前工作树，不回收仍在运行的自身树。

本批宿主launch参数实际为gpt-6.1-sol、xhigh、service_tier=default，与题面high存在差异；原生会话/请求模型和结算服务档没有独立回执，未改宿主模型、账号或prompt，不凭默认配置冒称实际已切换，见runtime-model-limits.json。未运行play/网络/游戏API，不读游戏二进制、其他角色知识或密钥，不派下级。

开工一次错误地把learn.json批次视为顶层键导致KeyError，随后按嵌套结构只读定位并严格核同批；另一次两个猜测源码路径不存在，改用rg定位实际文件。原工具失败由宿主转录保留，不作游戏反例或产品故障，未因此更改数据/断言/权限。

没有新科学异议或旧知识冲突，保留已有限制，不强行支持旧假设；不代ops/watcher/Roy确认、不关闭任何学习入库或量化父要求。最终HEAD/工作树/派发身份复核见final-validation.json。

运维提案：{scratch / 'proposal.md'}

报告：{scratch / 'report.md'}；机器结果：{scratch / 'result.json'}。
'''
(scratch / 'report.md').write_text(report)
print(json.dumps({'report': str(scratch / 'report.md'), 'proposal': str(scratch / 'proposal.md'),
                  'base': base, 'waiting': len(dispositions)}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
dispatch = json.loads((scratch / 'dispatch.json').read_text())
result = json.loads((scratch / 'result.json').read_text())
source = json.loads((scratch / 'source-audit.json').read_text())
ledger = json.loads((scratch / 'ledger-receipt.json').read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=workspace)

def find_batch(value):
    if isinstance(value, dict):
        if dispatch['batch'] in value:
            return value[dispatch['batch']]
        for item in value.values():
            found = find_batch(item)
            if found is not None:
                return found
    elif isinstance(value, list):
        for item in value:
            found = find_batch(item)
            if found is not None:
                return found
    return None

head = git('rev-parse', 'HEAD').decode().strip()
assert head == dispatch['base'] == result['base']
assert len(head) == 40
status = git('status', '--porcelain')
patch = git('diff', '--binary', 'HEAD')
index = git('diff', '--cached', '--binary')
assert status == patch == index == b''
(scratch / 'source-worktree.patch').write_bytes(patch)
current = find_batch(json.loads((root / 'ops/codex-ops/learn.json').read_text()))
assert current is not None
for key in ['task', 'character', 'worktree', 'runs', 'proposal_ids']:
    assert current[key] == dispatch['dispatch'][key]
assert 'research_request' not in current and 'implementation_request' not in current
assert set(result['code_proposals']) == set(current['proposal_ids'])
assert set(x['id'] for x in result['proposal_results']) == set(current['proposal_ids'])
assert all(x['state'] == 'waiting' and x['reason'] for x in result['proposal_results'])
assert result['fixes'] == result['implementation_domains'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert Path(result['report']) == scratch / 'report.md'
assert ledger['returncode'] == 0 and len(ledger['physical_rows']) == 24
for leaf in source['files']:
    assert hashlib.sha256((workspace / leaf['path']).read_bytes()).hexdigest() == leaf['base_sha256']
review = json.loads((scratch / 'review-r2.stdout.json').read_text())
assert review['assigned_ids_reviewed'] == 10
versions = json.loads((scratch / 'dampen-observations.json').read_text())
assert all(isinstance(frame['draw_pile'], list) for frame in versions['frames'])
for name in ['report.md', 'proposal.md']:
    backup = scratch / name.replace('.md', '.initial.md')
    assert not backup.exists()
    backup.write_bytes((scratch / name).read_bytes())
with (scratch / 'report.md').open('a') as handle:
    handle.write(f'\n最终核验：{stamp}（先date）。根ledger CLI实际退出0，24条追加均逐物理offset/bytes/SHA/JSON读回，旧物理前缀及受保护字段/历史保持。派发五局和十ID仍匹配，HEAD仍等于完整base，tracked/index及source-worktree.patch为空。\n\n'
                 '本批抑制材料初稿误从combat.draw_pile取字段得到null，随后按draws.ts实际入口改读agent_view.combat.draw，四帧真实牌堆列表已读回；原初稿及脚本保留为.initial文件，不将初稿null当作缺失证据。修正仅涉及scratch展示，原始封套/37材料断言/逐项处置及源码均未改。\n')
proof = {'time': stamp, 'base': head, 'head': head, 'worktree_clean': True, 'index_clean': True,
         'binary_diff_bytes': len(patch), 'dispatch_binding_matches': True, 'assigned_ids': len(current['proposal_ids']),
         'all_proposal_results_waiting': True, 'source_leaf_hashes_unchanged': len(source['files']),
         'ledger_cli_returncode': 0, 'ledger_physical_appends': 24,
         'production_tests': result['tests'], 'merged': None, 'source_commits': []}
(scratch / 'final-validation.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
manifest = []
for file in sorted(scratch.rglob('*')):
    if not file.is_file() or file.name == 'artifact-manifest.json':
        continue
    raw = file.read_bytes()
    manifest.append({'path': str(file.relative_to(scratch)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(scratch / 'artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': head, 'waiting': 10, 'worktree_clean': True, 'ledger_appends': 24,
                  'artifacts': len(manifest), 'report': result['report']}, ensure_ascii=False))

import hashlib
import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
previous = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-004303/learner/runs/20261017-004316-c5b34dde-6fac-4b32-9f97-ce80ef0033be-strategy-proposal')
dispatch = json.loads((scratch / 'dispatch.json').read_text())['dispatch']

def read_stream(name):
    return [json.loads(line) for line in (scratch / 'evidence' / (name + '.evidence.jsonl')).open()]

states = {x['line']: x for x in read_stream('states')}
decisions = {x['line']: x for x in read_stream('decisions')}
streams = {'states': states, 'decisions': decisions,
           'sl-attempts': {x['line']: x for x in read_stream('sl-attempts')}}
paired = []
for left, right in [(289339, 289414), (290160, 290201)]:
    a, b = states[left]['row'], states[right]['row']
    assert a['fingerprint'] == b['fingerprint']
    assert a['state']['combat']['hand'] == b['state']['combat']['hand']
    paired.append({'lines': [left, right], 'same_logged_fingerprint': True,
                   'same_raw_hand': True, 'hidden_state_or_followup_verified': False})
(scratch / 'paired-board-checks.json').write_text(json.dumps(paired, ensure_ascii=False, indent=2) + '\n')

dispositions = json.loads((previous / 'dispositions.json').read_text())
originals = {x['id']: x for x in json.loads((scratch / 'original-proposals.json').read_text())}
assert {x['id'] for x in dispositions} == set(dispatch['proposal_ids'])
for disposition in dispositions:
    original = originals[disposition['id']]
    assert disposition['ledger'] == original['ledger']
    assert disposition['runs'] == original['runs']
    assert disposition['original_sha256'] == original['proposal_sha256']
    for reference in disposition['evidence_refs']:
        stream = Path(reference['source']).stem
        actual = streams[stream][reference['line']]
        assert all(actual[key] == value for key, value in reference.items())
    disposition['review_scope'] = '本批重新提取并逐字节核实原证据，当前源码子项已读回；无新独立样本，不更改原规则。'
(scratch / 'dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')

versions = []
ids = ['BLADE_DANCE', 'ACCELERANT', 'OUTBREAK', 'SUCKER_PUNCH']
for left, right in [(290160, 290165), (290201, 290206)]:
    for line in [left, right]:
        state = states[line]['row']['state']
        combat = state['combat']
        versions.append({'source_line': line, 'turn': state['turn'],
                         'draw_pile': state['agent_view']['combat']['draw'],
                         'hand': [{'id': c['card_id'], 'upgraded': c['upgraded']} for c in combat['hand'] if c['card_id'] in ids],
                         'deck': [{'id': c['card_id'], 'upgraded': c['upgraded']} for c in state['run']['deck'] if c['card_id'] in ids],
                         'powers': combat['player']['powers']})
(scratch / 'dampen-observations.json').write_text(json.dumps({'frames': versions,
    'limitation': 'T2到T3之间同时发生抽牌及改标，未保存改标后全部原牌仍留抽堆的独立瞬时帧；不据总数守恒认证物理副本或延长已知顺序。'}, ensure_ascii=False, indent=2) + '\n')

guard = decisions[282578]['row']
reask = decisions[282579]['row']
assert 'HP guard' in guard['rationale'] and 'hp -12' in guard['rationale'] and 'hp -0' in guard['rationale']
assert guard['answers']['plan']['choice'] == 'plan5'
assert '斗篷与匕首' in guard['journal']['choice']
assert '蛇咬' in reask['journal']['choice'] and '小刀' in reask['journal']['choice']
assert '-2' in decisions[283691]['row']['rationale']
(scratch / 'guard-observations.json').write_text(json.dumps({'guard_source_line': 282578,
    'guard_rationale': guard['rationale'], 'original_answer': guard['answers']['plan']['choice'],
    'guarded_journal': guard['journal'], 'reask_source_line': 282579, 'reasked_journal': reask['journal'],
    'structured_hp_guard': guard.get('hp_guard'), 'terminal_rationale': decisions[283691]['row']['rationale'],
    'limitation': '旧行的结构化hp_guard字段为空，护栏来自实际rationale；之后重问改变实线，原完整候选的执行和收益不能由journal补证。'}, ensure_ascii=False, indent=2) + '\n')

now = {x['stream']: x for x in json.loads((scratch / 'evidence/evidence-manifest.json').read_text())}
old = json.loads((scratch / 'evidence-old-plans/evidence-manifest.json').read_text())[0]
assert old['output_sha256'] == now['run-plans']['output_sha256']
assert old['counts'] == now['run-plans']['counts']
(scratch / 'old-plans-audit.json').write_text(json.dumps({'old_source_size': old['source_size'],
    'current_source_size': now['run-plans']['source_size'], 'selected_sha256': old['output_sha256'],
    'counts': old['counts'], 'same_selected_bytes': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'assigned_ids_reviewed': len(dispositions), 'paired_boards_verified': len(paired),
                  'old_plans_same_selected_bytes': True, 'production_tests_run': False}, ensure_ascii=False))

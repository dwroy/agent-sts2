# 静默策略队列复核报告

记录时间：2026-10-17 08:52:27 CST（先执行date）。task=strategy-proposal，character=silent，batch=20261017-084302-strategy-proposal。

十个原提案均waiting：本批没有新增能支持规则修改的实盘输入，当前也未定位新的可隔离源码失配。fixes=[]、merged=null；没有源码或知识提交、eval版本、implemented或shipped声明。部分现有实现继续复用，各原宽项和学习父要求保留。

完整base/HEAD：`dee5dd9ed2e2d8af33f956bcb196e70a151a3a32`。开工git status为空，普通身份核实后git merge --no-edit main返回Already up to date。

## 身份与范围

已读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol、learning-code-proposals、learning-requests和fix-queue的相关原项。根learn.json只读本批行，task/character/worktree/五个runs/十个proposal_ids核对；没有research_request、implementation_request和proposal_repair。普通专题文件仍绑定另一个旧批，本批不承接专题，也不领取其他队列项。独立完成，未派下级agent。

| 局号 | 角色 | 进阶 | 结果 |
|---|---|---:|---|
| 7X0W3U8TVA2A | SILENT | 10 | F31 败 |
| MTQ0EUBJ3R6T | SILENT | 10 | F23 败 |
| KFRDELW2TH2P | SILENT | 10 | F33 败 |
| GXNKW8X1XYJP | SILENT | 10 | F45 败 |
| ZE8F192FKX24 | SILENT | 5 | F48 胜 |

ZE8 A5只作抑制现场版本观察，不混作A10策略验证。只读本角色知识中的21个关联经验条目，保存内容及整文件SHA，不把知识文本更新视为本批实盘。五局run-config的历史完整commit和dirty_files另存historical-source-limits.json；旧dirty输入未完整重建，当前代码不能充作历史运行树。兼容deepseek_calls字段不单独证明实际引擎。

## 证据完整性

使用本树extract_evidence.py，以nice10从只读logs提取八流。全部6060封套逐行seek原源核offset/bytes/SHA/JSON、截点及显式局身份；run-plans.run和run_id/state.run_id/fingerprint.run沿共用入口读取，冲突身份拒收。每流截点分别冻结，不称同一墙钟快照。

| 流 | source_size | 核验条数 | 与旧同范围封套相同 |
|---|---:|---:|---|
| runs | 354231 | 5 | true |
| states | 13759608697 | 2965 | true |
| decisions | 2132905991 | 2846 | true |
| sl-attempts | 44691707 | 26 | true |
| run-config | 1916880 | 5 | true |
| run-plans | 8756282 | 30 | true |
| brain | 714738855 | 183 | true |
| fight-plans | 2233957 | 0 | true |

八流选中内容与原061302-s2及上一004303同五局范围一致；全源扫描边界增长没有增加本批独立局或SL支持。fight-plans零行只说明该截点未选到，不断言原流不存在。states/decisions/brain各有2条无法解析的全源行，不将其归为本批局故障。

旧run-plans截点8380258独立用同入口--streams run-plans --source-size复核并另存evidence-old-plans；与本次8756282截点同30行/同SHA。所有旧报告、零行初稿和失败历史保持。

重算37项固定材料断言，通过；本批另核两对原指纹及完整原手牌相同、原提案全部引用匹配本次封套，并读回KFR旧护栏rationale和GX抑制版本帧。它们是材料核验，不是生产tsc/vitest/cases。同指纹同手牌仍不能证明隐藏状态及整战后继相同。

## 实盘支持、反例与未知

- MTQ F23末试T3两候选均24/24死亡，模型即时损血0/8、扣敌13/19仍不同；实帧T3到T4从10到2血。原线先前已失败，探索替线不等宣称更安全，不能凭饱和死亡率制定保血或SL阈值。
- 7X F31三段初血合150，可见帧差增加175、下降278、末残47。已发生重接不能当永久击杀，帧差也不是完整逐来源伤害或持续实体认证。
- KFR F33T6两试同15HP/228敌HP/36毒/3覆甲，原线净扣83损6，替线净扣93损12；之后均失败。F12 decisions282578的护栏在rationale而非结构化hp_guard字段：原答plan5，journal改为斗篷起手；282579生刀后重问改蛇咬/中和/小刀。实际损6不能归到原完整0损候选。
- KFR末T7手上技法7挡、防御后12挡，三次手动动作满额，爆发剩1能仍锁；毒药37→43当步敌159不变，随后43+42=85，敌余74。手法7挡已兑现，换对象、顺序或提前喝药的整战结果未知。
- GX F45同T2后3/13血、0/7挡，保血线敌多8HP；末13HP+23挡+2覆甲对40需损15，hpAfter=-2与实死一致。缺完整复活瞬时逐击、未截断入伤和前三出口，不由净血差拟新评分。
- GX F33已建触媒2层才有29+28+27=84；末战未建立不能预支。四次SL普通键inserted及旧升级键作差仍在，但T2→T3伴随抽牌，缺改标后原牌全留抽堆的独立瞬时帧和稳定物理副本身份；基ID总量守恒不足以安全延长已知抽序。ZE8 A5现场普通版与场外升级分账。
- MTQ跨幕19→59、KFR跨幕22→60可核，但营火、开场和SL恢复必须分别归属。没有可比替路线后继，不能从六次回血仍败调整休息/锻造阈值。

本批没有重算原提案全部历史药水/营火总额，不把其旧全史统计冒作本批样本；没有未执行候选、未走路线或提前喝药的受控整战结论。

## 现有实现及离线消费者

只读live提交：`99737be9fdb9c2ea92089d768947c49b49b62382`，不是本批merged。23个相关源码叶中19个与上一004303基线相同；4个变化为selection的沙坑弃牌入口、combat-plan的普通计算下注重抽，以及card-model/turn-solver的DAGGER_SPRAY+紧勒触发覆盖。这些变化未关闭本批原宽提案，不把别批新来源冒成本批证据。与live相比18叶同字节，5叶只差历史Roy/Dai署名，实际物理文件与live HEAD相符；两份精确git diff --binary保存，不由23叶推断全树等价。

直接读回：奇巧facts仍continuation_verified=false，selection_audit.actual_turn=null，SL资源比较scope=current_turn_prediction且execution=unverified；离线actual_uncapped_hp_loss、actual_full_candidate_result和causal_source仍null。run-journal给HP增加边界而非完整因果，resource_chain明确药槽变化不能独自识别饮用/丢弃。已有受限通道不等完整归属或联合校准。

| 实际源码祖先commit | 已有子项 | base/live祖先 |
|---|---|---|
| c4a4f4a94b48dff9b30aaa7228624c1092150145 | Sync observed Demon input delta to main | true/true |
| 02c4e13ac8e159b82ee35a965ac788a0a029ce5a | Sync tested offline selection execution audit to main | true/true |
| a32050fbce4c2863f640468c2dbf378fc9157074 | Integrate checked offline Silent potion observation tool | true/true |
| e75438488df159b2e8e9d3458cf219b39aadd933 | Apply tested offline observed-turn audit and explicit unsupported-DPR diagnostics | true/true |
| 83512ddcd2c70fd9b983dc38524ff25c8970c1d3 | Audit Silent terminal HP observations after final end turns | true/true |
| 5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452 | Record observed Silent HP recovery boundaries | true/true |
| 3f69541b5d3259dac94d3395bfe3da47936b4de9 | Audit observed enemy HP changes in Silent replays | true/true |
| 1698adc96ba434a46942321e0237b70657e625b2 | Complete Silent SL resource comparison audit | true/true |

20份原消费者输入/输出/stderr/退出码及资源链产物按原manifest逐SHA复核；四个A10输入由本次原帧重新构建后逐字相等。消费者8个递归依赖/入口与原实际consumer_base同字节，本批没有重跑消费者、模型或模拟池；原rc0只保持历史归属，不算本批测试。

| A10局 | 候选段 | 有ID动作 | 已核回合端点 | 未知回合窗 | 完整候选认证 |
|---|---:|---:|---:|---:|---:|
| 7X0W3U8TVA2A | 119 | 445 | 7 | 64 | 0 |
| MTQ0EUBJ3R6T | 68 | 424 | 25 | 50 | 0 |
| KFRDELW2TH2P | 180 | 586 | 18 | 85 | 0 |
| GXNKW8X1XYJP | 116 | 646 | 20 | 83 | 0 |

合483候选段、2101有ID动作，352回合窗中70个已核端点、282未知。KFR一条/GX三条无decision_id元数据排除并保留，不补ID；完整候选认证0表示保守工具未认证，不等于实际未执行。未进行完整后继、整战因果或自然消费者采用验收。

## 逐项处置

证据局号/层/回合、账本id、反例、旧规则、期望行为、验证与原字节引用逐项见proposal.md和dispositions.json；原十份Markdown逐SHA复制保留。

| 原CLI ID | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-19a5cff2094e2d8f | waiting | MTQ F23T3两候选均24/24死亡、即时损血0/8仍不同；7X F31存在重接血池。缺同输入同后继的整战校准、未截断入伤及持续实体归属，不能拟新SL或终局权重。 |
| silent-proposal-3540bf4360bf80af | waiting | 跨幕HP增加边界与资源链已有实现；尚缺休息、开场、SL和逐槽药水的完整来源归因及路线/休息消费者联合读回，现有净变化记录不足关闭原提案。 |
| silent-proposal-0ea5c0b9c030fdd6 | waiting | 奇巧名额/费用提示和限定恶魔6毒入口已在live；提示仍continuation_verified=false。缺自动重放、合法完整后继与多轮收益校准，不将局部入口登记成整项duplicate。 |
| silent-proposal-f915ec544ab94b6e | waiting | 已有离线原答→SL替换→重问→执行关联，但完整候选收益仍null；KFR F12护栏后生刀重问改线，F33T6缺整轮可归属开端，无法用实际净差校准原完整候选或新排序。 |
| silent-proposal-8fb51933639faf90 | waiting | 已有限定毒药、力量、敏捷和覆甲局部模型；缺覆甲完整减层条件及能量/药效/能力在多入口叠加时的联合消费者校准，当前未定位新可隔离数值失配。 |
| silent-proposal-b3bc0eb09211af6c | waiting | 奇巧资源提示与SL即时血价审计已有；完整后继、未建立能力收益和终局价值仍未校准。六次T7及局部换线均无可核整战胜线，不能由此设新保血或用药规则。 |
| silent-proposal-fdc3a505fe5e1a55 | waiting | KFR跨幕22→60等实际回复可分列且已有HP边界观测；缺完整逐源路线/休息消费者验收及可比替路线后继，不能从六次回血仍失败调整阈值或关闭整项。 |
| silent-proposal-5a95725089f53cd8 | waiting | GX同T2复活后3/13血、0/7挡及敌多8血可核，已有审计工具；缺复活瞬时逐击、未截断入伤、前三出口及完整候选归属，不足据局部10血差更改评分或SL。 |
| silent-proposal-51fa8bc34774f72d | waiting | GX四次普通键inserted及升级键作差路径仍存在；T2→T3同时抽牌，缺纯改标中间帧和唯一物理副本/并发顺序证据，不能仅以基ID守恒安全延长已知抽序。 |
| silent-proposal-29b7b36dffbcb017 | waiting | GX已建立触媒2层后的84毒伤及末战未建立可核，现有局部模型保留；缺头骨/毒雾/覆甲/力敏联合多轮消费者校准和完整时点对照，未定位新独立源码差额。 |

## 记录与交付

仅经根learner/ledger.py update给24个既有相关账本追加本批proposal/report追溯；不新增support/repeat，不改claim/first_run/prior/evidence/status/version/effect/shipped，不重复历史复盘或创建新提案。实际CLI及追加物理行核验以ledger-receipt.json为准，code_proposals沿用十个原CLI ID，implementation_domains=[]。

无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均未运行，tests固定为null；材料断言不作生产cases。无源码提交，不运行提交前gitleaks和沙箱测试，不合入live或创建eval版本/上线行/规则双通知，不冒implemented/shipped。保留原日志与当前工作树，不回收仍在运行的自身树。

本批宿主launch参数实际为gpt-6.1-sol、xhigh、service_tier=default，与题面high存在差异；原生会话/请求模型和结算服务档没有独立回执，未改宿主模型、账号或prompt，不凭默认配置冒称实际已切换，见runtime-model-limits.json。未运行play/网络/游戏API，不读游戏二进制、其他角色知识或密钥，不派下级。

开工一次错误地把learn.json批次视为顶层键导致KeyError，随后按嵌套结构只读定位并严格核同批；另一次两个猜测源码路径不存在，改用rg定位实际文件。原工具失败由宿主转录保留，不作游戏反例或产品故障，未因此更改数据/断言/权限。

没有新科学异议或旧知识冲突，保留已有限制，不强行支持旧假设；不代ops/watcher/Roy确认、不关闭任何学习入库或量化父要求。最终HEAD/工作树/派发身份复核见final-validation.json。

运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-084302/learner/runs/20261017-084310-1b88c89b-5510-4d6a-a468-7d9e3f3cf1cb-strategy-proposal/proposal.md

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-084302/learner/runs/20261017-084310-1b88c89b-5510-4d6a-a468-7d9e3f3cf1cb-strategy-proposal/report.md；机器结果：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-084302/learner/runs/20261017-084310-1b88c89b-5510-4d6a-a468-7d9e3f3cf1cb-strategy-proposal/result.json。

最终核验：2026-10-17 08:55:25 CST（先date）。根ledger CLI实际退出0，24条追加均逐物理offset/bytes/SHA/JSON读回，旧物理前缀及受保护字段/历史保持。派发五局和十ID仍匹配，HEAD仍等于完整base，tracked/index及source-worktree.patch为空。

本批抑制材料初稿误从combat.draw_pile取字段得到null，随后按draws.ts实际入口改读agent_view.combat.draw，四帧真实牌堆列表已读回；原初稿及脚本保留为.initial文件，不将初稿null当作缺失证据。修正仅涉及scratch展示，原始封套/37材料断言/逐项处置及源码均未改。

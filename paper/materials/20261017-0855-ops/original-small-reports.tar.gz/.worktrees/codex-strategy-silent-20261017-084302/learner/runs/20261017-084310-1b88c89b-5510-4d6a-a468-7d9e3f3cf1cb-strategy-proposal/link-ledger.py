import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
scratch = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
ledger_path = root / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger_cli', root / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
dispositions = json.loads((scratch / 'dispositions.json').read_text())
ids = sorted({ident for item in dispositions for ident in item['ledger']})
assert len(ids) == 24
prefix = ledger_path.read_bytes()
relevant = [(i, row) for i, raw in enumerate(prefix.splitlines(), 1)
            if (row := json.loads(raw)).get('id') in ids]
before = ledger.fold(relevant)
assert all(before[ident]['character'] == 'silent' for ident in ids)
(scratch / 'ledger-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in ids:
    linked = [item['id'] for item in dispositions if ident in item['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(scratch / 'proposal.md'), str(scratch / 'report.md')]},
                    'note': '20261017-084302-strategy-proposal本批追溯：' + '、'.join(linked) +
                    '均waiting，逐项缺数据见proposal.md/dispositions.json。五局八流6060封套逐offset/bytes/SHA/身份核，37材料断言及两对原指纹/手牌核实；8个消费者依赖与原输入输出同SHA，未重跑消费者。当前23源码叶19同旧/4已知窄更新、8子项实际live祖先核，未发现本批新可隔离差额；无源码/知识提交、生产测试、合入/版本或shipped。仅加where/note，不增加独立support/repeat，不改claim/首证/prior/evidence/status/version/effect及历史。'})
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates).encode()
(scratch / 'ledger-updates.jsonl').write_bytes(payload)
subprocess.run(['date'], check=True)
run = subprocess.run(['python3', str(root / 'learner/ledger.py'), 'update'], input=payload, capture_output=True)
(scratch / 'ledger-cli.stdout.txt').write_bytes(run.stdout)
(scratch / 'ledger-cli.stderr.txt').write_bytes(run.stderr)
(scratch / 'ledger-cli.rc.txt').write_text(str(run.returncode) + '\n')
assert run.returncode == 0, run.stderr.decode()
after_raw = ledger_path.read_bytes()
assert after_raw[:len(prefix)] == prefix
offset = len(prefix)
physical = []
for raw in after_raw[len(prefix):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('id') in ids and str(scratch / 'report.md') in row.get('where', {}).get('proposal', []):
        expected = next(x for x in updates if x['id'] == row['id'])
        assert {k: v for k, v in row.items() if k not in ['op', 'ts']} == expected
        assert row['op'] == 'update'
        physical.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(physical) == len(ids) and {x['row']['id'] for x in physical} == set(ids)
own_fold = copy.deepcopy(before)
for item in physical:
    ledger.apply(own_fold, item['row'])
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'effect', 'shipped_at']
for ident in ids:
    assert all(before[ident].get(key) == own_fold[ident].get(key) for key in protected)
    for key in ['history', 'notes']:
        assert own_fold[ident][key][:len(before[ident][key])] == before[ident][key]
    for key, values in before[ident]['where'].items():
        assert own_fold[ident]['where'][key][:len(values)] == values
(scratch / 'ledger-own-fold-after.json').write_text(json.dumps(own_fold, ensure_ascii=False, indent=2) + '\n')
receipt = {'command': ['python3', str(root / 'learner/ledger.py'), 'update'], 'returncode': run.returncode,
           'ledger': str(ledger_path), 'old_prefix_bytes': len(prefix),
           'old_prefix_sha256': hashlib.sha256(prefix).hexdigest(), 'old_prefix_unchanged': True,
           'protected_fields': protected, 'protected_fields_unchanged_for_own_updates': True,
           'old_where_notes_history_prefixes_preserved': True, 'new_evidence_or_status_updates': 0,
           'physical_rows': physical}
(scratch / 'ledger-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_returncode': run.returncode, 'linked_ledger_items': len(physical),
                  'protected_fields_unchanged': True, 'old_prefix_unchanged': True}, ensure_ascii=False))

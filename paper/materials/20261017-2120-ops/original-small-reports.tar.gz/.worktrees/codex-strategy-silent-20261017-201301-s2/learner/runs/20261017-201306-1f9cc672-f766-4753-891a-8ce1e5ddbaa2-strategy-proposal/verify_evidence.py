import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
SPEC = importlib.util.spec_from_file_location('extractor', OUT.parents[1] / 'extract_evidence.py')
EXTRACTOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXTRACTOR)
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


streams = {}
validation = []
for directory in ('evidence', 'evidence-extra'):
    manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
    for entry in manifest:
        stream = entry['stream']
        path = OUT / directory / (stream + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = dict.fromkeys(RUNS, 0)
        rows = []
        with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as original:
            for raw in path.open('rb'):
                digest.update(raw)
                envelope = json.loads(raw)
                original.seek(envelope['offset'])
                source = original.read(envelope['bytes'])
                assert hashlib.sha256(source).hexdigest() == envelope['sha256']
                row = json.loads(source)
                assert row == envelope['row']
                assert EXTRACTOR.run_identity(row) == envelope['run_id']
                assert envelope['offset'] + envelope['bytes'] <= entry['source_size']
                counts[envelope['run_id']] += 1
                rows.append(envelope)
        assert counts == entry['counts']
        assert digest.hexdigest() == entry['output_sha256']
        streams[stream] = rows
        validation.append({**entry, 'verified_raw_rows': len(rows)})
save('envelope-validation.json', validation)


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw.get('powers', [])}


def snapshot(envelope):
    row = envelope['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'run_id': envelope['run_id'], 'source_line': envelope['line'],
        'offset': envelope['offset'], 'bytes': envelope['bytes'], 'sha256': envelope['sha256'],
        'observed_ts': row.get('observed_ts'), 'ts': row.get('ts'),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'block': player.get('block'),
        'powers': powers(player),
        'played': player.get('cards_played_this_turn'),
        'hand': [{'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                  'text': c.get('resolved_rules_text')} for c in combat.get('hand', [])],
        'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'is_alive', 'move_id')}
                    | {'powers': powers(e), 'attacks': e.get('intents', [])}
                    for e in combat.get('enemies', [])],
    }


floors = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
          '8JRE1C4H4Z2W': [17, 33], 'YF0LXT1QSTGG': [48], 'XP2SL33HT0D9': [33]}
snapshots = [snapshot(e) for e in streams['states']
             if (e['row']['state'].get('run') or {}).get('floor') in floors[e['run_id']]]
save('target-snapshots.json', snapshots)
by_line = {e['line']: e for e in streams['states']}
decision_lines = [270216, 270282, 271309, 271348, 271992, 272040, 271982, 272195]
decisions = {e['line']: e for e in streams['decisions'] if e['line'] in decision_lines}
assert set(decisions) == set(decision_lines)
pairs = []
for left, right in zip(decision_lines[::2], decision_lines[1::2]):
    a, b = decisions[left], decisions[right]
    assert a['row']['fingerprint'] == b['row']['fingerprint']
    observations = []
    for decision in (a, b):
        row = decision['row']
        candidates = [e for e in streams['states'] if e['run_id'] == decision['run_id']
                      and e['row'].get('observed_ts') == row.get('observed_ts')]
        assert len(candidates) == 1, (decision['line'], len(candidates))
        start = candidates[0]
        same_run = [e for e in streams['states'] if e['run_id'] == decision['run_id'] and e['line'] > start['line']]
        endpoint = None
        for e in same_run:
            s = e['row']['state']
            if (s.get('run') or {}).get('floor') != row['floor']:
                break
            if isinstance(s.get('turn'), int) and s['turn'] != row['turn']:
                if s['turn'] == row['turn'] + 1:
                    endpoint = e
                break
        assert endpoint is not None, decision['line']
        before, after = snapshot(start), snapshot(endpoint)
        assert [e['enemy_id'] for e in before['enemies']] == [e['enemy_id'] for e in after['enemies']]
        assert [e['max_hp'] for e in before['enemies']] == [e['max_hp'] for e in after['enemies']]
        observations.append({'decision_line': decision['line'], 'decision_sha256': decision['sha256'],
                             'start_line': start['line'], 'next_turn_line': endpoint['line'],
                             'hp_loss': before['hp'] - after['hp'],
                             'enemy_net_hp_removed': sum(e['current_hp'] for e in before['enemies'])
                                 - sum(e['current_hp'] for e in after['enemies'])})
    pairs.append({'run_id': a['run_id'], 'floor': a['row']['floor'], 'turn': a['row']['turn'],
                  'fingerprint_equal': True, 'observations': observations,
                  'delta_hp_loss': observations[1]['hp_loss'] - observations[0]['hp_loss'],
                  'delta_enemy_net_hp_removed': observations[1]['enemy_net_hp_removed'] - observations[0]['enemy_net_hp_removed'],
                  'scope': '当轮边界的玩家净血差与敌本体净血差，不是逐来源伤害或整战因果'} )
save('paired-turn-observations.json', pairs)

key_lines = [273237, 273254, 276212, 277512, 277513, 277528,
             278236, 278237, 278249, 278250, 278251, 278252, 278253, 278254]
save('referenced-snapshots.json', [snapshot(by_line[n]) for n in key_lines if n in by_line])
save('sl-summary.json', [{'run_id': e['run_id'], 'line': e['line'], **{k: e['row'].get(k)
                          for k in ('floor', 'attempt', 'started_at', 'ended_at', 'result', 'turns', 'end_hp')}}
                         for e in streams['sl-attempts']])
print(json.dumps({'verified_rows': sum(e['verified_raw_rows'] for e in validation),
                  'target_snapshots': len(snapshots), 'pairs': pairs}, ensure_ascii=False))

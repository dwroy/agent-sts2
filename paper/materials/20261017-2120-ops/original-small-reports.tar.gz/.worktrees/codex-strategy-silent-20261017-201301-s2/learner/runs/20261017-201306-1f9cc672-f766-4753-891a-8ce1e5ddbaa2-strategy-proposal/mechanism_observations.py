import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
snapshots = json.loads((OUT / 'target-snapshots.json').read_text())
observations = []
for run in ['DUZUBAJ3A8GP', '5PM6JAQG6FNQ', 'CA5KE8GFJ9X2', 'YF0LXT1QSTGG', 'XP2SL33HT0D9']:
    previous = {}
    attempts = {}
    for s in snapshots:
        if s['run_id'] != run or not s['enemies'] or not isinstance(s['turn'], int):
            continue
        floor = s['floor']
        attempts.setdefault(floor, 1)
        if floor in previous and s['turn'] < previous[floor]:
            attempts[floor] += 1
        previous[floor] = s['turn']
        keep = (run == 'DUZUBAJ3A8GP' and s['turn'] in (4, 5, 6)) or (
            run == '5PM6JAQG6FNQ' and (floor == 38 and s['turn'] in (3, 4) or floor == 39 and s['turn'] in (4, 5, 6))) or (
            run == 'CA5KE8GFJ9X2') or (
            run == 'YF0LXT1QSTGG' and 277512 <= s['source_line'] <= 277528) or (
            run == 'XP2SL33HT0D9' and 278236 <= s['source_line'] <= 278260)
        if keep:
            observations.append({k: s[k] for k in ('run_id', 'source_line', 'floor', 'turn', 'hp', 'block', 'powers', 'played')}
                                | {'attempt_by_turn_reset': attempts[floor], 'enemies': s['enemies']})
(OUT / 'mechanism-observations.json').write_text(json.dumps(observations, ensure_ascii=False, indent=2) + '\n')
for row in observations:
    enemies = [(e['enemy_id'], e['current_hp'], e['max_hp'], e['powers'],
                [a['total_damage'] for a in e['attacks'] if a.get('total_damage') is not None]) for e in row['enemies']]
    print(row['run_id'], row['source_line'], 'F', row['floor'], 'A', row['attempt_by_turn_reset'],
          'T', row['turn'], 'HP', row['hp'], 'B', row['block'], row['powers'], enemies)

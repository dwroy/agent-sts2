import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
before = json.loads((OUT / 'ledger.snapshot.json').read_text())
prefix = json.loads((OUT / 'ledger-prefix-before.json').read_text())
data = (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()
assert hashlib.sha256(data[:prefix['bytes']]).hexdigest() == prefix['sha256']
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
prefix_rows = list(enumerate([json.loads(line) for line in data[:prefix['bytes']].splitlines()], 1))
pre_cli = module.fold(prefix_rows)
after = module.fold(module.read_rows(str(ROOT / 'paper/materials/learning/ledger.jsonl')))
protected = ['character', 'kind', 'scope', 'claim', 'first_run', 'asc', 'prior', 'prior_note',
             'prior_runs', 'evidence', 'status', 'version']
assert not [(i, field) for i in before for field in protected if pre_cli[i].get(field) != after[i].get(field)]
parallel = [{'id': i, 'initial_evidence_count': len(before[i].get('evidence', [])),
             'before_cli_evidence_count': len(pre_cli[i].get('evidence', [])),
             'after_cli_evidence_count': len(after[i].get('evidence', []))}
            for i in before if before[i].get('evidence') != pre_cli[i].get('evidence')]
assert {p['id'] for p in parallel} == {'silent-0023', 'silent-0125'}
updates = [json.loads(line) for line in (OUT / 'ledger-update.jsonl').read_text().splitlines()]
for row in updates:
    assert set(row) == {'id', 'by', 'where', 'note'}
    for path in row['where']['proposal']:
        assert path in after[row['id']]['where']['proposal']
writers = [{k: row.get(k) for k in ('id', 'ts', 'by')}
           for _, row in prefix_rows if row.get('id') in {'silent-0023', 'silent-0125'}
           and row.get('ts') == '2026-10-17T20:34:21+08:00' and 'evidence' in row]
integrity = {'root_prefix_preserved': True, 'prefix': prefix, 'linked_entries': len(updates),
             'protected_field_changes_after_cli': [], 'cli_exit_code': 0,
             'parallel_changes_before_cli': parallel, 'parallel_writers': writers}
(OUT / 'ledger-integrity.json').write_text(json.dumps(integrity, ensure_ascii=False, indent=2) + '\n')
result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert {p['id'] for p in result['proposal_results']} == set(dispatch['proposal_ids'])
assert len(result['proposal_results']) == len(dispatch['proposal_ids']) == 10
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', 'status', '--short'], text=True)
assert head == result['base'] and not status
assert subprocess.check_output(['git', 'diff', '--binary', result['base']]) == b''
final = {'base': head, 'git_status': status, 'source_and_knowledge_diff_empty': True,
         'proposal_results': 10, 'all_waiting': all(p['state'] == 'waiting' for p in result['proposal_results']),
         'evidence_rows': sum(e['verified_raw_rows'] for e in json.loads((OUT / 'envelope-validation.json').read_text())),
         'ledger_cli_exit_code': 0, 'tests': result['tests'], 'merged': None}
(OUT / 'final-verification.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'integrity': integrity, 'final': final}, ensure_ascii=False))

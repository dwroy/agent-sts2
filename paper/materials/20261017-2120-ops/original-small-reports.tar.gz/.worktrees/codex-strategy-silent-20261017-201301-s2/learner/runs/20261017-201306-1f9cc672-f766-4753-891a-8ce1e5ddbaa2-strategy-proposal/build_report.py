import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
batch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'proposals.snapshot.json').read_text())
sources = json.loads((OUT / 'source-readback.json').read_text())
base = sources['base']
details = [
    ('c20b5139dd0dff71', '污染与当前技能效果', 'DUZUBAJ3A8GP F27 T4—T6；states 274830—274843。',
     'T4火花3、污染0→3→6；T5火花6、污染0→6→12→18，T6轮初污染消失。T4/T5敌本体101→93→80，玩家49→46→37；不能忽略技能同时带来的毒与格挡。',
     '已有技能加污染、逐击伤害、火花增长路径。本批没有完成火花增长、污染清除、弱、毒及格挡联合的生产固定重放，不能认证整项实现，也没有少打技能的受控整战依据。',
     '冻结上述每步实际手牌、能力、A10敌招输入；联合重放逐步比较毒、挡、玩家血与敌本体血。增加实现时要求撤源码失败、恢复通过；不据净血差拟新技能权重。'),
    ('ae9e692d680e3819', '逐实体抢夺与返还', '5PM6JAQG6FNQ F39 首试T4—T6；states 274351—274366。',
     '玩家−4力/−4敏，经两次步法至0敏；失落2血/3毒后退出，下一轮玩家力量负值消失。遗忘仍带POSSESS_SPEED_POWER=1而敏捷4→6，玩家再变−2敏。层数1不能代替累计抢夺量。',
     '缺逐实体累计抢夺来源真值和遗忘退场返敏的完整链；现帧负属性及POSSESS层数不足以认证返还量，亦无完整目标顺序对照。',
     '需要保留实体生命周期、每次抢夺、玩家其他增减属性来源和退场返还；固定重放毒杀与再抢夺。不得以现有总属性推定单一来源或规定击杀序。'),
    ('52f1e1bd2e7db0ed', '下水道蚌加压与当前进阶取数', 'CA5KE8GFJ9X2 F13 T1—T5；states 273237—273269。',
     'A10现场58上限；加压后力量0→4→8，喷水11→15→19，弱时15→11、19→14。轮初覆甲9/9/8/7/6；末轮只有2血与10挡仍死亡，死亡状态不能当正常后继状态。',
     '当前已有按进阶取数与覆甲路径，未确定新的源码失配；尚缺加压、覆甲、弱联合的固定生产重放及旧dirty输入复原，不能将存在路径等同整项duplicate。',
     '对当前生产适配器使用冻结A10事实逐步重放，并分别报告现场与数据库输入。怪物HP/攻击从首个样本读取；不调整房间代价五样本门槛，也不把单场失血写成固定房间成本。'),
    ('6dd8bbff876be528', '电击机器人逐实体增长', '5PM6JAQG6FNQ F38 T3—T4；states 274308—274317。',
     '23上限的电击机器人T3力量2/攻击17，T4力量4/攻击19，T3仍参与攻击；T4才退出。高电压为2。敌列表缩短，不能将列表index当恒久实体身份。',
     '已有HIGH_VOLTAGE增长接线，但本批缺可靠召唤代际身份及相应冻结移动输入的联合重放，不能由两帧增长认证新召唤者重置或固定击杀序。',
     '保存召唤/退场/再召唤边界，验证新实体从现场初值开始，旧实体增长仅作用自身；固定A10攻击与完整敌方回合后继，不以未执行先杀爪牙线作胜利对照。'),
    ('578e415a259e6835', '沙虫SL、护栏和资源分账', '8JRE1C4H4Z2W F33 首/第三试T2；decisions 270216/270282；states 276208—276212及276274—276278。原提案另含F17 T6和F33 T5/T11。',
     '完整指纹相同；玩家净损3→15，敌本体净扣10→17，即多12血换7本轮进度。同存档多次失败不是独立样本，无法据此否定所有防御换线或确认长期成长收益。',
     '已有候选分段及单动作回执；缺完整候选续步执行归属、沙坑逐来源结算与路线资源链联合认证，未取得独立受控整战后继，不改护栏或探索参数。',
     '逐一串接Jev原答、护栏、SL、重规划和每步动作实收；来源损血、延长沙坑及已建能力另列。按run分发现/后移验证，抽弃牌切断后不冒称完整候选已执行。'),
    ('c0767768bf6a7ab1', '实验体全败SL的实际资源代价', 'YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348；states 277327—277337及277366—277373。',
     '完整指纹相同；净损0→9、敌本体净扣45→38。原提案保留F33第二次SL获胜及F48第四次T5换线未完整执行的反例；本批不将有限模拟比例写成安全。',
     '缺完整候选执行认证和逐来源血价归属；单动作回执不证明全轮完成，也无同抽序完整替线及独立胜线，不能拟惩罚系数或禁探索。',
     '固定观测配对先验证当前回合净值，再记录未执行续步和终止原因；需要未来独立完整A10尝试检验探索规则，保留成功SL反例。'),
    ('a46bdb7fe711d79a', '阶段、毒与后取得敏捷', 'YF0LXT1QSTGG F48 末试T3—T5；states 277512—277528。',
     '4血/4毒第一阶段变212上限新阶段，旧毒/力清空；T4双尖啸33→15→0。T5触媒2且敌零毒；5敏时先建13+10=23挡，第三小刀后才到6敏，不能倒补既有挡。末轮18血、23挡对44攻击仍死亡。',
     '已有当前阶段快照及零毒说明；逐候选施毒、已结算毒伤、额外扣血和敏捷取得顺序的完整执行归属尚缺，不能用窄阶段修复认整项完成或改排序。',
     '联合重放零毒触媒、阶段清毒及先挡后加敏，分列施毒、结算伤害和额外扣血；对候选持有/建立/兑现逐步核实，不能把组件持有当生效。'),
    ('1044224808015e5c', '双蟹全败并列SL血价', 'XP2SL33HT0D9 F33 首/第二试T3及首/末试T1；decisions 271992/272040、271982/272195。',
     '两组完整指纹分别相同。T3净损9→14、净扣24→27；T1净损2→10、净扣25→34。后一组同时有手里剑成长，不把成长记成零，也不以全败判付血一律错误。',
     '缺同抽序完整替线、成长兑现的受控后继与独立整战胜线；多5血换3伤、多8血换9伤不能拟全局参数或确认新并列规则优于旧规则。',
     '固定验收两组净值且保留力量成长、朝向及临时减力；如评估新并列规则，先冻结候选规则、比较完整后继，再用时间后移独立局验证。'),
    ('7cbc6005db712ba9', '双蟹朝向与能力兑现窗口', 'XP2SL33HT0D9 F33 末试T2—T5；states 278236—278260。',
     '轮初14挡，镣铐令爪0→−9力/4→0攻，斗篷再6挡至20，T3减力恢复；T4火箭57→38→28分别对应朝向与弱，4敏脆弱下偏折实增6挡。不能把14当每轮固定挡。',
     '已有相关机制和部分参考，但缺逐候选既有/新增挡、朝向虚弱、已结算毒与生存HP统一来源的生产联合认证，不冒整项duplicate或新增出牌权重。',
     '以固定日志验14+6=20、0→−9→0、57→38→28及先后顺序；逐来源输出条件，不向未观察升级或其他角色外推。'),
    ('c59f592f1427a67e', '合并经验的资源与执行闭环', 'YF0LXT1QSTGG F48 T1/T3—T5及XP2SL33HT0D9 F33 T1—T5；沿上述配对与阶段/双蟹原帧。',
     '独立复核了三个同指纹血价配对及两局能力/减益时点。原提案还包含路线、休息、药水恢复和历史机制汇总；本批六锚点不冒充完整101局历史量化复验。',
     '缺逐来源资源账与完整候选归属联合认证，亦无路线/药水时机受控替线及独立整战后继；不能由部分日志字段存在关闭整项请求。',
     '按原经验id/账本逐条关联实际执行和资源来源，再验证路线与药水时机受控替线；同SL存档不跨训练/验证，未结算毒、SL恢复和实际回血分列。'),
]

sections = []
results = []
for suffix, title, evidence, support, reason, validation in details:
    ident = 'silent-proposal-' + suffix
    item = proposals[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append(f'''## {ident}

题目：{title}。处置：**waiting**。仅静默猎手已观察A10；原经验更宽范围不作为本批验证。

证据：{evidence}

既有账本：{', '.join(item['ledger'])}。原提案：`{item['proposal']}`；原Markdown逐SHA核验并保存为本目录`{ident}.original.md`，未改原文。

支持、反例与边界：{support}

旧行为/当前实现：以本目录`source-readback.json`记录的源码及原提案为准。预期行为：{item['summary']} 所需事实记录应与实际执行分开；本批不新增选择规则、权重或门槛。

未实现原因：{reason}

验证和后续输入：{validation}

拟合/时间切分：本批为原发现局重核，不拟系数；同一存档尝试相关，不能增加独立局分母。后续独立完局按run_id与时间切分；没有未选线完整后继时记未知。

预期影响与回退：此次只提供可复查追溯，不能宣称策略收益。没有新源码需要回退；后续实现需独立撤源码失败/恢复通过、沙箱验收及真实live合入证明。原规则与未观察分支保留。
''')

proposal = f'''# 本批十项静默策略提案核验

生成前已运行date：2026-10-17 20:38:19 CST。
任务strategy-proposal；batch=20261017-201301-s2-strategy-proposal；基线`{base}`。
根learn.json核实character=silent、工作树匹配，proposal_ids恰为本报告十项，无research_request、implementation_request或proposal_repair。不承接其他专题，不创建重复提案id。

## 证据来源与共同边界

仅分析六个派发局：{', '.join(batch['runs'])}，runs.jsonl逐局核实均SILENT/A10。运行版本均带dirty，因此不声称恢复旧运行树。源码用于核当前能力，不以源码或预训练知识生成新游戏事实。

共用提取器保存八流截点、逐行offset/bytes/SHA及计数。`verify_evidence.py`重新seek原日志逐字节、JSON及显式归属核实8274行；生成953个目标层快照。fight-plans在本截点选中0行，只表示本截点未选到；CA5的SL流同理。不因0行断言原日志缺失。

四组完整fingerprint配对已独立复算，详`paired-turn-observations.json`；这些是相邻回合边界净值，不是逐来源损伤或整战因果。原提案十份逐SHA相同；既有账本保护首证、claim、状态、证据与版本，本批仅通过CLI追加追溯路径。

## 当前源码核对与处置口径

14叶base/live提交及live磁盘逐SHA冻结。10叶字节相同；4叶差异仅Roy/Dai历史注释署名，见`live-source-differences.patch`。live磁盘14叶均等于冻结live提交。四个窄审计源码提交在base与实际live均为祖先：

- `0e4fe4df89a06682468e0e4716c12126e76369d5`：沙坑资源比较字段。
- `1698adc96ba434a46942321e0237b70657e625b2`：SL当前轮资源比较。
- `aad2700abed6dff1d66e87fb36aaa6fedb39adf3`：实验体当前阶段/零毒事实。
- `fdaf787a372880b0438e73bcac7e6d2168b038ed`：单动作派发回执。

`29f146292892704f618cda8f4db733f21f9cdb1f`仅核为live祖先、不是本base祖先；相关rollout叶实际字节相同，不伪造base祖先关系或本批实现。上述均为旧有窄功能，不将它们合称十项完整交付。当前`silent-selection-dispatch.ts`明确whole_plan_executed=null，`silent-sl-resource-comparison.ts`为execution=unverified，`silent-hp-guard-audit.ts`的actual_outcome=null；阶段快照也不认证逐候选毒伤。此次未运行新生产消费者、求解、模拟或测试，不借旧批绿色。

本批没有足够依据确定新的策略参数或新源码失配；10项逐项waiting，保留原规则，缺失实现/联合验证继续在原id接续。没有新游戏机制异议或与旧知识冲突；不新增支持计数、反例、经验、提案id或shipped。证据核验脚本仅为scratch材料，不修改agent/learner/eval/ops生产脚本。

''' + '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal)

result = {'task': 'strategy-proposal', 'character': 'silent',
          'batch': '20261017-201301-s2-strategy-proposal', 'base': base, 'runs': batch['runs'],
          'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': list(proposals), 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

ledger_ids = sorted({i for p in proposals.values() for i in p['ledger']})
updates = []
for ident in ledger_ids:
    linked = [p for p in proposals if ident in proposals[p]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md') + '#' + p for p in linked]},
                    'note': '20261017-201301-s2-strategy-proposal：六局A10原日志重核，关联原提案逐项waiting；8274原行校验、四组同指纹当轮净值复算；无新机制结论、状态/支持数/规则/源码/上线变更。详 ' + str(OUT / 'report.md')})
(OUT / 'ledger-update.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in updates))
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
data = ledger_path.read_bytes()
(OUT / 'ledger-prefix-before.json').write_text(json.dumps({'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}) + '\n')
report = f'''# 本批策略核验报告

结论：十项均waiting。未发现本批可确定的新源码失配，当前证据不足以修改SL、护栏、技能权重、目标顺序或终局规则。没有源码/知识提交、live合入或新版本。

- task=strategy-proposal；character=silent；batch=20261017-201301-s2-strategy-proposal。
- base=`{base}`；开工干净，按普通批次merge main为Already up to date。最终要求HEAD及tracked工作树保持该基线。
- 实际live只读快照=`{sources['live_snapshot']}`；不是本批merged。四个旧窄源码祖先证明详proposal.md和source-readback.json。
- 六局均Silent A10，八流8274原封套逐offset/len/SHA/JSON/显式身份校验；953个目标状态和四组同fingerprint配对。没有把正文提及当所属局，也没有将SL尝试扩分母。
- 撤源码失败/恢复通过：不适用，未改源码；tsc/vitest/cases均null。未运行生产测试或消费者；证据脚本通过不报成生产测试成功。无提交因此无提交前扫描/Co-author/发布步骤；最终材料单独扫描。
- 提案交运维路径：`{OUT / 'proposal.md'}`。逐项证据层/回合、账本、反例、缺口、预期行为、验证与回退见该文件。原Markdown和原历史未覆盖。

四组当轮实付差值（替换减原线）：8JRE F33T2净损+12/敌净扣+7；YF0L F48T1净损+9/敌净扣−7；XP2S F33T3净损+5/敌净扣+3；XP2S F33T1净损+8/敌净扣+9。仅确认当轮资源取舍；缺完整控制抽序、逐来源归属与独立整战胜线，不能据此认证新参数。

独立核实的机制端点：DUZU F27火花3→6/污染清除；5PM F38力量2→4、攻击17→19及F39负属性/返力；CA5 F13力量0→4→8、攻击11→15→19、弱后11/14；YF F48阶段清毒及5敏先建23挡后到6敏；XP F33T2 14+6挡及镣铐恢复，T4朝向57→38后弱到28。完整来源快照保存在target-snapshots.json与mechanism-observations.json，不把这些端点外推为整项实现。

限制：六局均旧发现样本，运行dirty全树未复原；本批没有新增独立验证局或完整未选线；现有部分审计仍明确执行未知，逐来源资源/联合消费者认证未完成。fight-plans零行与CA5 SL零行仅有截点含义。原提案的历史支持数、升级机制及全101局统计未在本批全量复验，不作为本批新结论。部分只读定位命令探查了不存在的源码路径后以rg --files定位，未修改生产源码或影响证据校验。首次scratch报告生成因括号语法错误退出1，随后CLI因输入尚不存在退出1且未触及根账本；失败脚本原字节及失败回执保存build_report.failed.txt、report-build-failures.txt，修正后另记成功，不作生产测试失败或覆盖旧记录。

账本追溯：准备{len(updates)}条CLI update，只添加proposal链接与note，不改claim/first_run/evidence/prior/status/version/计数。实际CLI结果与保护字段复核分别见ledger-cli.log、ledger-integrity.json；若失败保留日志且不冒称登记成功。

最终机械检查与材料SHA见final-verification.json、artifacts-manifest.json。没有新规则上线，故未追加上线日志/版本或规则双通知，不修改运维prompt。回收由原调度器完成，保留本批工作树与原件，不自行删除。

逐项机器处置见result.json；所有派发id恰覆盖一次，implemented/duplicate均为0，不登记shipped。
'''
(OUT / 'report.md').write_text(report)
print(json.dumps({'proposal_count': len(results), 'ledger_links': len(updates), 'base': base,
                  'report': str(OUT / 'report.md')}, ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/home/dw/Projects/agent-sts2")
dispatch = json.loads((HERE / "dispatch.json").read_text())
snapshot = json.loads((HERE / "proposal-snapshot.json").read_text())
base = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert base == "9ed8ac27c45992bf48e6526c38bd77c8bbfa8132"

specs = [
    ("89354805ee4d7e77", "神化升级传播与实际施放归属",
     "VLZ6CCT8AQ0A F35/T1、F43/T1、F45/T1；s275564→275565实付2能、防御5→8；s275679→275687同轮实扣51、损13，场外升级数保持4。",
     "已有观察配对与模拟传播；生产参考的 actual_cast_this_fight 仍为 null。缺跨抽牌、选牌、药水重问、SL及换战的实际神化施放持续归属与消费者核验，不能登记整项实现。",
     "F35/F43打出后仍有显著损血；F45没打出而败不是同盘因果对照。",
     "先冻结真实动作—后继状态的归属链，验证同线与后抽升级、未知覆盖、换战清空以及场外牌组不变；源码消融红/恢复绿后再按原入口自测。"),
    ("f2bfceddb1898dca", "药水MC预算与全败候选",
     "VLZ6CCT8AQ0A F45/T1 d269748：MC707ms、1/12，rollout一轮、best=null；d269754：MC12/12但指纹已不同；F45/T4 d269770三个候选并列。",
     "缺同起点、同随机池、同总预算的MC顺序配对，以及时间—样本—候选稳定性曲线；两道不同盘面不能确定新预算常量、留药价格或固定目标。",
     "第一问预算退化不等于确定死亡；T4高伤线未实际执行，不把其8伤差认作败因。",
     "冻结同盘状态、随机种子与总预算，再比较MC先行和分阶段预算；分别记录模型缺口、样本、排序稳定性与耗时，缺证继续保留现行为。"),
    ("283a164780d11e69", "神化经验补链",
     "VLZ6CCT8AQ0A F35/T1、F43/T1及后抽、F45/T1；与89354805ee4d7e77共享silent-0237/0238，原Markdown及experience链接均核回。",
     "同源经验链仍缺实际施放持续归属及完整消费核验；题意重复和局部配对源码不能作为整个请求duplicate的live实现证明。",
     "同局四次施放不增加独立局数；持有固有神化也不证明末战已经建立升级。",
     "沿同一神化实现链复用固定帧与消费者验收；不新建重复提案id，不重复累计支持或重写原复盘。"),
    ("ebbfe3b97548756d", "十五项攻防机制与资源分账",
     "VLZ6CCT8AQ0A F43/T1—T5、F45/T1—T5；已复核升级/实际扣血帧、现场敏捷/勒紧/覆甲/毒层；原提案包含十五机制及路线、休息资源消费者。",
     "缺十五子项逐来源、持续期限、升级属性组合及战斗—路线—休息消费者的固定联合校准；本批关键帧与已有子实现不足证明整条复合提案完成。",
     "能力持有和已建立须分列；单轮减力不是永久收益，残毒不是已兑现伤害，另一focus和火堆选择未形成受控整战对照。",
     "逐子项冻结输入并逐步核对，再验证三类消费者及资源链；仅对实测不符的子项修源码，不拟合统一权重。"),
    ("e5b87be50f28f311", "SL、HP护栏与真实执行审计",
     "8JRE1C4H4Z2W F33/首试及第三试T2 d270216/d270282指纹相同；第三试日志明确原线死0/24、替线5/24；F33/第二试T5 d270264护栏候选损16→4。",
     "已有候选阶段、护栏和单动作回执；actual_turn、whole_plan_executed仍为null，state_effect_verified仍为false。缺跨抽牌、选牌、重问、SL的持续执行归属与实际整线兑现核验。",
     "首轮回执不能证明全部候选已执行；候选少12损血不是实际因果保血。0/24与5/24不能说成相同死率，六次尝试仍只是一局。",
     "冻结F17/T6、F33首/三试T2、第二试T5、末试T11的阶段与状态链；实际施放、重规划中断、净HP、敌本体与未结算毒分列，不能把审计上线当胜率提升。"),
    ("49632bc4878fb597", "力量、敏捷、虚弱和独立成长",
     "CA5KE8GFJ9X2 F13/T3、T5：敌力量4→8；s273263喷水19，s273268虚弱后14，玩家2HP/10挡，s273269死亡；末轮完整需损4。",
     "缺力量逐击、正负敏捷、虚弱与独立成长的生产调用固定联合校准。CA5未取得步法；本批其他局有敏捷帧，但不是已完成四路径生产配对的证明，不能以单个步法实现关闭复合请求。",
     "虚弱未取消下一次加压；死亡仅实扣余2HP，不能把完整攻击需求误写成2。",
     "分项冻结每击基础、当前力敏、弱、独立成长及取整；对生产调用输入做逐步对照，保持未观察组合未知，不增加统一攻防权重。"),
    ("66532328a585941f", "组件持有、启动与兑现",
     "5PM6JAQG6FNQ F33/T2已建雾3/触媒1/群蛇4；F39/T2 s274379→274380零雾、零毒冒泡实付1能，两个敌人HP与状态未变。",
     "缺相同起始资源、构筑及完整抽序下不同启动顺序的受控整战比较和可复现收益函数；现有持有/当前建立事实子项不等于通用构筑或启动权重已验证。",
     "F33与F39敌人与资源不同，不能把一胜一败归因于单一组件；不将空打冒泡直接推广成固定必打顺序。",
     "先将持有、候选、实际建立和逐轮收益分账，再按run_id做时间后置验证；缺受控比较时不改启动阈值。"),
    ("43a76a31ba7bdcfa", "族母吸取、负敏捷与毒",
     "61E2QS63Y9WU F17/T5—T7；s273504敏捷−2、敌力2、毒17；s273505与273507两防御各实得3挡；至s273508敌67→34，已结17+16毒。",
     "分项事实已冻结，仍缺同起始HP、构筑及完整抽序的另一可核SL全战线路与生产配对，不能据首试获胜改变SL范围、阈值或换线偏好。",
     "吸取后的毒仍有效不等于所有构筑均可依毒转胜；本局首试60血七轮赢，不能用它代替另一局的失败反事实。",
     "逐步比对吸取、负敏捷、毒减层和实际净血；需要SL规则改变时另做同盘完整线路验证，不跨进阶外推。"),
    ("5264153a4a4b0e5c", "胧光怪召唤、航行与退场",
     "61E2QS63Y9WU F23/T4—T5；s273593两实体力量3，s273596均6，幻象仍2HP并存活；原本体线当轮47伤/损15与focus幻象候选须分开。",
     "已有活体召唤及当前进阶首样本取数子实现；缺本次A10召唤、航行、复现与退场全链的生产校准，以及另一focus完整后继，不能登记整项duplicate或强制首杀。",
     "旧召唤测试覆盖A0/A9子输入，不能充当本局A10全链验证；未打的39伤零损候选不是已证明的整战胜线。",
     "冻结实体ID、当前进阶HP/伤害、两次航行、退场及再召唤；保留全部目标，等值并列，不用净伤替代退场进度。"),
    ("bddfa690a84e03d0", "熟睡甲虫睡眠、唤醒与成长",
     "DUZUBAJ3A8GP F30/T1—T6；s274906/274914/274919睡3/2/1，T4醒来；s274934敌力4、攻击22。原四次尝试均败，不能扩成四局。",
     "已有其他固定Silent A10帧的保守必死判定子修复；缺伤害唤醒、眩晕接续与本次成长的全链校准，以及同抽换序完整后继；四次相关失败不足拟合新规则。",
     "额外扣敌3HP同时多付玩家2HP，不足支持仅按敌剩血重排所有死线；现有毒后伴怪退场攻击下界修复不覆盖完整唤醒脚本。",
     "分别冻结睡层自然下降、伤害唤醒、眩晕后继、增力/临时减力和退场；改换线偏好前验证相同抽序完整后继，不猜获胜线。"),
]

dispositions = []
lines = ["# 本批十项静默策略提案复核", "", f"批次：{HERE.name}；调度：20261018-021301-strategy-proposal。", "",
         "角色silent，六个来源局均为A10。只处理本批领取的十个原id；没有新建代码提案，没有修改原提案。", "",
         "结论：本轮均为waiting。现有子实现和实盘观察可确认，但没有完整满足原请求的live源码证明，也没有新的充分证据支持改动策略。保留行为；不登记implemented、duplicate或shipped。", "",
         "证据提取与逐行复核见evidence/evidence-manifest.json、evidence-verification.json、verified-references.jsonl；关键帧断言见key-facts-checks.json。原提案及指纹见proposal-snapshot.json与十份.original.md。", "",
         "所有发现帧均为发现/回归样本，不称盲测；SL尝试不增加独立局数。以下预期行为和验证是后续待办，本批未执行代码实现、消融、生产测试或合入。", ""]
for suffix, title, evidence, missing, counterexample, validation in specs:
    ident = "silent-proposal-" + suffix
    original = snapshot[ident]["effective"]
    dispositions.append({"id": ident, "state": "waiting", "reason": missing})
    lines.extend([f"## {ident}：{title}", "", f"- 证据：{evidence}",
                  f"- 既有账本：{'、'.join(original['ledger'])}；来源任务：{original['source_task']}；实现任务：strategy-proposal。",
                  f"- 当前处置/缺口：{missing}", f"- 反例/限制：{counterexample}",
                  f"- 旧/新行为：本批保持当前行为；后续只补已核实的事实、状态变换和执行分账，不添加固定优先级或收益常数。",
                  f"- 预期与验证：{validation}",
                  "- 回退：本批没有生产改动；后续实现须用其实际源码提交回退并保留证据、原日志和失败历史。", ""])
(HERE / "proposal.md").write_text("\n".join(lines) + "\n")
(HERE / "proposal-results.json").write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + "\n")

requests = []
ledger_ids = sorted({i for v in snapshot.values() for i in v["effective"]["ledger"]})
for ident in ledger_ids:
    related = [d for d in dispositions if ident in snapshot[d["id"]]["effective"]["ledger"]]
    requests.append({"id": ident, "by": "learner:strategy-proposal",
                     "where": {"proposal": [str(HERE / "proposal.md"), str(HERE / "report.md")]},
                     "note": "20261018-021301-strategy-proposal本批复核，关联" + "、".join(d["id"] for d in related) +
                             "均waiting。" + "；".join(d["reason"] for d in related) +
                             "本次只追加处置追溯，不增加support/repeat、不更改claim/prior/进阶/状态/版本，不标shipped；证据和源码范围见本批报告。"})
(HERE / "ledger-update-requests.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in requests))

result = {"task": "strategy-proposal", "character": "silent", "batch": "20261018-021301-strategy-proposal",
          "base": base, "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": dispatch["proposal_ids"], "implementation_domains": [],
          "proposal_results": dispositions, "report": str(HERE / "report.md")}
(HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"proposal_results": len(dispositions), "ledger_links": len(requests), "base": base}, ensure_ascii=False))

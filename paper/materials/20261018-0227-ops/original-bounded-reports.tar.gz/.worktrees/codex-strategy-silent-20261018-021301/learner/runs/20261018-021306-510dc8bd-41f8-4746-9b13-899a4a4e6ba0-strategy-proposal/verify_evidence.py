import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((HERE / "dispatch.json").read_text())
allowed = set(dispatch["runs"])
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
windows = {
    "VLZ6CCT8AQ0A": {35: {1}, 36: {1, 2}, 37: {5}, 43: None, 45: None},
    "8JRE1C4H4Z2W": {17: {6}, 33: None},
    "CA5KE8GFJ9X2": {13: None},
    "5PM6JAQG6FNQ": {33: {1, 2, 3}, 39: None},
    "61E2QS63Y9WU": {17: {5, 6, 7}, 23: None},
    "DUZUBAJ3A8GP": {30: None},
}


def wanted(run, floor, turn):
    if floor not in windows[run]:
        return False
    turns = windows[run][floor]
    return turns is None or turn in turns


def powers(raw):
    return {p.get("power_id"): p.get("amount") for p in raw or []}


def card(raw):
    return {k: raw.get(k) for k in ("index", "card_id", "upgraded", "energy_cost", "dynamic_values")}


verified = {}
grouped = defaultdict(list)
decision_summaries = []
key_lines = {}
selected = Counter()
with (HERE / "verified-references.jsonl").open("w") as references:
    for stream in manifest:
        name = stream["stream"]
        counts = Counter()
        digest = hashlib.sha256()
        evidence = HERE / "evidence" / (name + ".evidence.jsonl")
        with evidence.open("rb") as records, Path("/home/dw/Projects/agent-sts2/logs", name + ".jsonl").open("rb") as source:
            for encoded in records:
                digest.update(encoded)
                item = json.loads(encoded)
                run = item["run_id"]
                assert run in allowed and extractor.run_identity(item["row"]) == run
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                counts[run] += 1
                ref = {k: item[k] for k in ("source", "line", "offset", "bytes", "sha256", "run_id")}
                references.write(json.dumps(ref, ensure_ascii=False) + "\n")
                row = item["row"]
                if name == "states":
                    state = row.get("state") or {}
                    context = state.get("run") or {}
                    assert str(context.get("character_id", "silent")).lower() == "silent"
                    combat = state.get("combat") or {}
                    player = combat.get("player") or {}
                    floor, turn = context.get("floor"), state.get("turn")
                    if wanted(run, floor, turn) and combat:
                        view = {"line": item["line"], "offset": item["offset"], "sha256": item["sha256"],
                                "ts": row.get("observed_ts", row.get("ts")), "floor": floor, "turn": turn,
                                "screen": state.get("screen"), "hp": player.get("current_hp"),
                                "energy": player.get("energy"), "block": player.get("block"),
                                "powers": powers(player.get("powers")), "hand": [card(c) for c in combat.get("hand") or []],
                                "deck_upgraded": sum(bool(c.get("upgraded")) for c in context.get("deck") or []),
                                "enemies": [{**{k: e.get(k) for k in ("index", "enemy_id", "current_hp", "block", "is_alive", "move_id", "intents")},
                                             "powers": powers(e.get("powers"))} for e in combat.get("enemies") or []]}
                        grouped[run].append(view)
                        selected[name] += 1
                        key_lines["states:" + str(item["line"])] = view
                elif name == "decisions" and wanted(run, row.get("floor"), row.get("turn")):
                    view = {**ref, "row": row}
                    decision_summaries.append(view)
                    selected[name] += 1
                    key_lines["decisions:" + str(item["line"])] = view
        assert digest.hexdigest() == stream["output_sha256"]
        assert {r: counts[r] for r in allowed} == stream["counts"]
        verified[name] = {"source_size": stream["source_size"], "counts": stream["counts"],
                          "verified_rows": sum(counts.values()), "output_sha256": digest.hexdigest(),
                          "invalid_lines": stream["invalid_lines"], "incomplete_lines": stream["incomplete_lines"]}

(HERE / "state-windows.json").write_text(json.dumps(grouped, ensure_ascii=False, indent=2) + "\n")
with (HERE / "decision-windows.jsonl").open("w") as f:
    for item in decision_summaries:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")
(HERE / "evidence-verification.json").write_text(json.dumps({"streams": verified, "selected_windows": selected}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"streams": {k: v["verified_rows"] for k, v in verified.items()}, "selected_windows": selected}, ensure_ascii=False))
for run, frames in grouped.items():
    print(run, "选定状态帧", len(frames), "首末行", frames[0]["line"], frames[-1]["line"])
for line in [275564, 275565, 275679, 275687, 275732, 276255, 276259]:
    view = key_lines.get("states:" + str(line))
    if view:
        print("关键帧", json.dumps({k: view[k] for k in ("line", "floor", "turn", "hp", "energy", "block", "powers", "enemies")}, ensure_ascii=False))

# 只读检查过程说明

1. 最初角色断言直接比较silent，与runs.jsonl原值SILENT大小写不同而失败；随后使用lower()核实六局均为silent/A10，未改原字节。run-identities.json保存原值与来源。
2. 检查首个状态的combat字段时，该过渡帧combat=null，直接list(None)出现TypeError；改为跳过空combat后读取结构。证据入口完整运行退出0，独立逐字节复核也退出0。
3. 起初只读定位silent-selection-dispatch.ts误放在hand/act下，sed提示不存在；rg --files确认真实路径为agent/src/reflex/silent-selection-dispatch.ts，后续读取和source-audit均使用真实路径。

没有把探针错误当作游戏数据缺失、源码失败或生产测试结果。没有删除或改写原日志、旧报告、历史原文或失败转录。本轮正式证据入口、复核、固定事实断言、根账本CLI及账本check均另有实际结果。

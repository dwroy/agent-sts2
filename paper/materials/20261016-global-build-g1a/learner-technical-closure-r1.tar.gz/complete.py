"""Verify and reuse the actual ops current-version probe without rerunning it."""
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
RECOVERY = ROOT / 'paper/materials/20261016-global-build-g1a/ops-recovery'
PRIOR = WORK / 'learner/runs/20261016-global-build-g1a-r1'
PAPER = WORK / 'paper/materials/20261016-global-build-g1a'
REQUEST_ID = 'roy-20261016-global-build-g1a'
INPUT_SHA = '66f3ad3a272f4fe74f12d0832ea220be57f5aade9e2f89a0a1044e261166ff5b'
MERGED = 'b2bdb0b1dbc7ec9a39909595238b00efbb718321'
PUBLICATION = '3394e7912f2b4bec3715761858f831f3fa6040dd'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def read(path):
    return json.loads(path.read_bytes())


def reference(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(LIVE), *args]).decode().strip()


def main():
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK).strip()
    initial_work_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK).decode().strip()
    original_report = PRIOR / 'report.json'
    old = read(original_report)
    receipt_path = RECOVERY / 'current-consumer-receipt.json'
    receipt = read(receipt_path)
    assert sha(receipt_path.read_bytes()) == '621860c8c6316358b1e730f52d40f3fe1003803f645e14ef9ad6d5066f7c451c'
    protected = [PRIOR / 'report.md', original_report, PRIOR / 'consumer-input.json',
                 PRIOR / 'live-consumer-output.json', PAPER / 'validation/consumer-receipt.json',
                 PAPER / 'validation/consumer-input.json', PAPER / 'validation/live-consumer-output.json',
                 PAPER / 'validation/consumer.mts']
    protected.extend(sorted(RECOVERY.glob('*.json')))
    protected.extend([RECOVERY / 'current-consumer.log'])
    before = {str(p): sha(p.read_bytes()) for p in protected}
    frozen = {
        'input-r1.md': (INPUT_SHA, None),
        'r1-frozen/learner-request-original.md': ('80f6e63ccf87bea63e2637d5085f3a029e6d89eb3d8955009d387eb89f5bdb86', 1878),
        'r1-frozen/approved-plan.md': ('cfb3fbd55c6e052d1acf21cc5b1f1ccf97a5bf65263b3b62d86db90506499803', 9763),
        'r1-frozen/parent-requirements.json': ('932431d39ad68e5cd5d75e9c3fd6fdba0be6821b5fd2f14b5a64a6c7ea5cf15d', 9336),
        'r1-frozen/parent-checkpoint.json': ('05c0be2733f202852caa665ac61401660a310f27d7720dfc7d5f6024910eaa89', 1731),
        'r1-frozen/parent-input-manifest.json': ('96cb4ca91bd1a27aa576fe3369551aea1061c8256768a0d47470c7a51bdd9d5c', 3043),
    }
    for name, (expected, length) in frozen.items():
        p = PAPER / 'ops-dispatch' / name
        raw = p.read_bytes()
        assert sha(raw) == expected and (length is None or length == len(raw))
        before[str(p)] = sha(raw)
    req_path = ROOT / 'notes/learning-requests' / (REQUEST_ID + '.json')
    req = read(req_path)
    assert req['id'] == REQUEST_ID and req['revision'] == 1 and req['input']['sha256'] == INPUT_SHA
    assert req['thread_id'] == '01a1415e-a511-7131-be7c-a2dc691c847f'
    assert req['original_batch'] == '20261016-050119-fix-batch'
    assert sha((ROOT / req['input']['path']).read_bytes()) == INPUT_SHA
    current_head, current_tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
    experience_raw = (LIVE / 'knowledge/characters/silent/experience.json').read_bytes()
    experience = json.loads(experience_raw)
    if receipt['experience_version'] != experience['version']:
        raise RuntimeError('CURRENT_VERSION_CHANGED: a new real invocation is required; existing receipt remains untouched')
    entries = {e['id']: e for e in experience['entries']}
    coverage = old['learning_result']['coverage']
    expected = {r['id']: r['sha256'] for refs in coverage.values() for r in refs}
    assert len(expected) == 5 and set(coverage) == set(req['requirements'])
    for ident, digest in expected.items():
        assert entries[ident]['status'] == 'active' and entries[ident]['evidence']
        assert sha(canonical(entries[ident])) == digest
    assert {r['id']: r['sha256'] for r in receipt['entries']} == expected
    assert receipt['request_id'] == REQUEST_ID and receipt['revision'] == 1 and receipt['character'] == 'silent'
    assert receipt['kind'] == 'fixed-consumer' and receipt['status'] == 'passed'
    assert receipt['tested_tree'] == git('rev-parse', receipt['live_commit'] + '^{tree}')
    for commit in [MERGED, PUBLICATION, old['fixes'][0]['commit'], receipt['live_commit']]:
        subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', commit, current_head], check=True)
    assert not git('diff', '--name-only', receipt['live_commit'], current_head, '--', 'agent/src')
    evidence = []
    for item in receipt['evidence']:
        p = Path(item['path'])
        assert sha(p.read_bytes()) == item['sha256']
        evidence.append(reference(p))
    original_input = read(PRIOR / 'consumer-input.json')
    current_input = read(RECOVERY / 'current-consumer-input.json')
    assert {**original_input, 'experience_version': experience['version']} == current_input
    assert current_input['entries'] == [entries[e['id']] for e in current_input['entries']]
    command = read(RECOVERY / 'current-consumer-command.json')
    output = read(RECOVERY / 'current-consumer-output.json')
    assert command['exit'] == 0 and command['cwd'] == str(LIVE)
    assert command['actual_live'] == receipt['live_commit'] and command['tree'] == receipt['tested_tree']
    assert command['experience_sha256'] == sha(experience_raw)
    assert output['root'] == str(LIVE) and output['experience_version'] == experience['version']
    assert sha(output['rendered_text'].encode()) == output['rendered_sha256']
    assert len(output['checks']) == 5 and {e['id'] for e in output['checks']} == set(expected)
    assert output['ascension_exclusion'] == [0, 9] and output['character_exclusion'] == 'ironclad'
    for item in output['checks']:
        assert all(item[k] is True for k in ['loaded', 'rendered', 'queried'])
        assert entries[item['id']]['lesson'] in output['queried_text']
    script = PAPER / 'validation/consumer.mts'
    original_script = subprocess.check_output(['git', 'show', 'HEAD:paper/materials/20261016-global-build-g1a/validation/consumer.mts'], cwd=WORK)
    assert script.read_bytes() == original_script
    questions = read(RECOVERY / 'original-learning-result-questions.json')
    forwarded = read(RECOVERY / 'questions-forwarding.json')
    assert json.loads(forwarded['notice']['message']) == questions
    assert forwarded['question_count'] == 3 and forwarded['exact_original_learning_result_questions'] is True
    for item in forwarded['destinations']:
        p = ROOT / item['path']
        with p.open('rb') as handle:
            handle.seek(item['offset']); raw = handle.read(item['bytes'])
        assert sha(raw) == item['sha256']
    versions_raw = subprocess.check_output(['git', '-C', str(LIVE), 'show', current_head + ':eval/versions.json'])
    versions = json.loads(versions_raw)
    versions = versions if isinstance(versions, list) else versions['versions']
    version = [v for v in versions if v['name'] == 'V5.silent-g1a-knowledge1']
    assert len(version) == 1 and version[0]['commit'] == MERGED and version[0]['release_id'] == 'V5-R368'
    original_receipt = PAPER / 'validation/consumer-receipt.json'
    assert sha(original_receipt.read_bytes()) == 'f5e9d51ac128110bd8ce39bea9dd5beb6e5395003b0622da11c898dd801f168f'
    verification = {
        'request_id': REQUEST_ID, 'revision': 1, 'input_sha256': INPUT_SHA,
        'original_batch': req['original_batch'], 'previous_completion_batch': '20261016-075726-strategy-proposal',
        'thread_id': req['thread_id'], 'observed_at': dt.datetime.now(dt.timezone.utc).isoformat(),
        'observed_live_commit': current_head, 'observed_live_tree': current_tree,
        'experience_version': experience['version'], 'experience_sha256': sha(experience_raw),
        'probe_tested_commit': receipt['live_commit'], 'probe_tested_tree': receipt['tested_tree'],
        'production_src_changes_since_probe': [], 'five_objects': expected,
        'probe_reused': True, 'new_probe_invocations': 0, 'input_difference_from_old': ['experience_version'],
        'receipt': reference(receipt_path), 'probe_evidence': evidence,
        'original_questions_forwarding': reference(RECOVERY / 'questions-forwarding.json'),
        'new_notifications_or_ACKs': 0, 'new_merge_or_experience_publication': False,
        'release_id': 'V5-R368', 'worktree_head': initial_work_head,
    }
    save('verification.json', verification)
    save('protected-artifacts-before.json', before)
    learning = {
        'request_id': REQUEST_ID, 'revision': 1, 'input_sha256': INPUT_SHA,
        'outcome': 'complete', 'coverage': coverage,
        'consumer_receipt': {'path': str(receipt_path), 'sha256': sha(receipt_path.read_bytes())},
        'questions': questions,
        'scope': 'Knowledge readability completion only; existing parent interface/natural acceptance, production calibration, 0332 and wider goals remain open. Original failure and old receipt unchanged; no actor ACK added.'
    }
    report = {
        'task': 'strategy-proposal', 'character': 'silent', 'base': initial_work_head,
        'fixes': [], 'merged': MERGED, 'publication': PUBLICATION,
        'merge_action': 'reuse existing live ancestor; no merge in this continuation',
        'release_id': 'V5-R368', 'experience_version': experience['version'],
        'tests': {'existing_real_consumer': 'reused ops invocation, 5/5 passed',
                  'receipt_evidence_sha': len(receipt['evidence']), 'canonical_objects_sha': 5,
                  'frozen_inputs_sha': 6, 'read_only_verify_experience': 'passed',
                  'new_probe_invocations': 0, 'new_simulations': 0, 'new_tsc_vitest': False,
                  'source_full_or_G4_checks_claimed': False},
        'code_proposals': [], 'implementation_domains': [], 'proposal_results': [],
        'existing_proposal_reference': 'silent-proposal-08156445e1c13d33',
        'existing_ledger_reference': 'silent-0494',
        'report': str(OUT / 'completion.md'), 'completion_receipt': reference(OUT / 'verification.json'),
        'questions_forwarding': reference(RECOVERY / 'questions-forwarding.json'),
        'learning_result': learning
    }
    spec = importlib.util.spec_from_file_location('g1a_readonly_guard', ROOT / 'ops/learning_requests.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.verify_experience(ROOT, req, report) == learning
    save('report.json', report)
    save('learning-result.json', learning)
    save('guard-readback.json', {'function': 'ops.learning_requests.verify_experience', 'status': 'passed',
                                'report': reference(OUT / 'report.json'), 'request': reference(req_path),
                                'receipt': reference(receipt_path), 'scope': 'Read-only verifier; no finish, scheduler mutation, notification or ACK.'})
    text = f'''# G1a 同原owner消费者闭环接续

request={REQUEST_ID}，revision=1，输入SHA={INPUT_SHA}。原批050119、原thread={req['thread_id']}；前次075726的failed/blocked与原报告保留。

当前live读回为 {current_head} / tree {current_tree}，经验库版本 {experience['version']}，全库SHA {sha(experience_raw)}。五个原对象canonical SHA与原coverage、运维回执全部一致。

直接复用ops于08:46:22执行的原脚本真实探针：tested commit {receipt['live_commit']} / tree {receipt['tested_tree']}。其后到当前HEAD的agent/src差异为空；输入只比旧输入改变真实经验库版本，五对象和脚本内容不变。5/5 load/render/query及角色、进阶隔离通过，实际输入/输出/command/log/脚本五份SHA均核。没有再执行同一探针，没有改旧输出的version冒充新运行。

所用新回执为 {receipt_path}，SHA {sha(receipt_path.read_bytes())}；旧f5e9回执原样保留。只读调用当前verify_experience对本次新report.json通过，没有调用finish或编辑注册/旧failed状态。

既有实际经验合入 {MERGED}、发布 {PUBLICATION} 均为当前live祖先；运维已登记G1a为V5-R368。未重新merge、更新经验版本、登记新账本/提案或借用G4 R367检查。

三原questions逐值复用ops原件，正式disagreement通知44fc95c93f6df419f94e2314的原文与实际转发范围SHA已核；不另发变体通知、不代其他角色ACK。

本次complete仅表示五项知识均在live并有当前版本真实固定消费者读回。固定读回不证明自然采用、收益、生产模型重校准或两场联合率；通用连战接口、自然消费、0332及宽父保持原watcher职责。
'''
    (OUT / 'completion.md').write_text(text)
    for path, expected_sha in before.items():
        assert sha(Path(path).read_bytes()) == expected_sha, 'protected original changed: ' + path
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK).strip()
    assert initial_work_head == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK).decode().strip()
    final_exp = read(LIVE / 'knowledge/characters/silent/experience.json')
    assert final_exp['version'] == receipt['experience_version'], 'version changed before final completion'
    assert module.verify_experience(ROOT, req, report) == learning
    save('preservation-readback.json', {'protected_count': len(before), 'unchanged': True,
                                       'worktree_tracked_changes': False, 'source_head_unchanged': True,
                                       'final_current_version_guard': 'passed'})
    refs = [reference(OUT / name) for name in ['verification.json','report.json','learning-result.json',
                                              'guard-readback.json','completion.md','preservation-readback.json']]
    save('manifest.json', refs)
    print(json.dumps({'complete': True, 'experience_version': experience['version'], 'reused_consumer': True,
                      'new_probes': 0, 'five_objects': len(expected), 'guard': 'passed',
                      'report': str(OUT / 'report.json'), 'receipt_sha256': sha(receipt_path.read_bytes())}))


if __name__ == '__main__':
    main()

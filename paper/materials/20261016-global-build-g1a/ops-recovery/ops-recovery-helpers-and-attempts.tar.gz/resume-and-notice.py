from pathlib import Path
import datetime as dt,hashlib,json,os,subprocess,sys
r=Path.cwd();sys.path.insert(0,str(r/'ops'));import learning_requests as lr
from learner_jobs import start_learner,STRATEGY_WORKERS
d=r/'ops/codex-ops';p=r/'paper/materials/20261016-global-build-g1a/ops-recovery';ident='roy-20261016-global-build-g1a';sha=lambda b:hashlib.sha256(b).hexdigest()
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
with lr.locked(d) as state:
    rec=state['learning_requests'][ident];batch=state['batches']['20261016-075726-strategy-proposal'];assert rec['state']=='blocked' and batch['rc']==0 and batch['state']=='failed'
    original=json.loads(json.dumps(batch));questions=batch['report']['learning_result']['questions'];assert len(questions)==3
    message=json.dumps(questions,ensure_ascii=False)
    notice=lr.notify(r,d,rec,'disagreement',message)
    if notice not in rec.setdefault('notices',[]):rec['notices'].append(notice)
    rec['questions']=questions
    rec['checkpoint']='原075726已结束rc0，旧failed/blocked原因仅consumer receipt经验全库版本g1a-r1与G4后当前2026-10-16.2不符；五要求对象canonical SHA全相等、旧probe5文件SHA全核，原结果和旧receipt不可改。ops本人诊断见主根paper/materials/20261016-global-build-g1a/ops-recovery/ops-received.json。只沿本原thread补当前live同一固定消费者一次并保存全新输入/输出/command/receipt及原五项coverage，生成新的completion report；原f5e9旧receipt/input/output/report和原failed状态不改，不以旧输出只改version充新读回。消费者逻辑保持，仅为本次真实运行冻结current experience_version字段与实际HEAD/tree，五原对象及脚本内容不改；不研究/重校准/重模拟/源full或新模型实验，不重新merge或更新经验version。当前live含五对象且源祖先，实际publication3394/b2b保留，编号由ops锁内补录，不得冒用G4 R367或其检查。本轮三原learning_result.questions已由ops沿原注册父正式disagreement通知，保持原文，回执ops-recovery/questions-forwarding.json；不要另写变体通知，不代其他角色ACK。通用连战接口/自然消费/0332/宽父仍watcher原职责。只知识可读闭环不等生产重校准/自然效果。'
    assert batch==original
value=json.loads((d/'learning-notices'/f'{notice}.json').read_text());assert value['message']==message and value['request_id']==ident and value['ops_forwarded']
receipt=json.loads(lr.artifact(r,value['ops_forwarded']));inbox=json.loads(lr.artifact(r,receipt['evidence']));raw=inbox['text'].encode()
dest=[]
for path in ['ops/inbox-dev.md','notes/for-roy.md']:
    content=(r/path).read_bytes();assert content.count(raw)==1;dest.append(dict(path=path,offset=content.index(raw),bytes=len(raw),sha256=sha(raw)))
(p/'questions-forwarding.json').write_text(json.dumps(dict(at=at,actor='ops',request_id=ident,revision=1,original_batch='20261016-075726-strategy-proposal',notice_id=notice,question_count=3,exact_original_learning_result_questions=True,notice=value,ops_actual_forward_receipt=value['ops_forwarded'],destinations=dest,other_actor_ACK=False,watcher_prior_native_notice_can_be_bound_by_watcher=True),ensure_ascii=False,indent=2)+'\n')
local=r/'ops/codex-ops/record-staging/20261016-g1a-recovery';(local/'notice-append.json').write_text(json.dumps(dict(text=inbox['text'],destinations=dest),ensure_ascii=False,indent=2)+'\n')
reason=dict(at=at,actor='ops',request_id=ident,revision=1,status='original current-version fixed consumer-only continuation authorized',received=dict(path=str((p/'ops-received.json').relative_to(r)),sha256=sha((p/'ops-received.json').read_bytes())),same_original_owner='01a1415e-a511-7131-be7c-a2dc691c847f',current_version='2026-10-16.2',scope='Do not rewrite old receipt/report/state, rerun simulations/source full or re-publish knowledge. Only one real current-version fixed readback and unchanged five requirement coverage. Original independent ops release registration and host identity remain separate; wider parents open.')
(p/'owner-resume-reason.json').write_text(json.dumps(reason,ensure_ascii=False,indent=2)+'\n')
cmd=['python3','ops/learning_requests.py','retry','--request',ident,'--receipt',str((p/'owner-resume-reason.json').relative_to(r))];run=subprocess.run(cmd,capture_output=True)
(p/'owner-retry-cli.json').write_text(json.dumps(dict(argv=cmd,rc=run.returncode,stdout=run.stdout.decode(),stderr=run.stderr.decode()),ensure_ascii=False,indent=2)+'\n');assert run.returncode==0
def alive(pid):
    try:os.kill(int(pid),0);return True
    except (ValueError,TypeError,OSError):return False
with lr.locked(d) as state:
    assert state['learning_requests'][ident]['state']=='pending'
    pending=[k for k,v in state['learning_requests'].items() if v.get('state')=='pending' and k!=ident];assert not pending,pending
    assert not any((d/f).exists() for f in ['ACCOUNT_DRAIN','LLM_DRAIN'])
    result=lr.reconcile(state,r,r/'ops','silent',alive,dt.datetime.now().strftime('%Y%m%d-%H%M%S'),start_learner,STRATEGY_WORKERS)
    rec=state['learning_requests'][ident];original=state['batches']['20261016-075726-strategy-proposal'];assert original==batch
    data=dict(at=at,result=result,request=rec,batch=state['batches'].get(rec.get('batch')),original_075726_failed_report_unchanged=True,first_reply_not_inferred=True,scope='Existing two slots, exact original owner/thread and frozen r1 input; current-version fixed probe only')
    lr.atomic(p/'owner-start.json',data)
print(json.dumps(dict(notice_id=notice,ops_forwarded=True,batch=rec.get('batch'),state=rec['state'],dispatch_result=result,old_batch_preserved=True),ensure_ascii=False),flush=True)

from pathlib import Path
import collections,hashlib,json,subprocess,tarfile
r=Path.cwd();priv=r/'ops/codex-ops/record-staging/20261016-g1a-recovery';pub=r/'paper/materials/20261016-global-build-g1a/ops-recovery';g1c=r/'paper/materials/20261016-global-build-g1c';sha=lambda b:hashlib.sha256(b).hexdigest()
reg=json.loads((pub/'ops-release-registration.json').read_text());cp=json.loads((g1c/'ops-publication.json').read_text());cadence=json.loads((g1c/'ops-cadence-readback.json').read_text());assert cadence['readback_passed']
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
msg=f"\n- {at} 运维codex：G1a原075726 rc0/failed/blocked已本人定位为旧consumer全库version g1a-r1与G4后2026-10-16.2不符，五对象及五原probe SHA/所有其余守卫均一致。旧report/receipt/input/output/failed状态原件不改；本ops已对实际live用原脚本作全新当前版本固定loader/render/query 5/5与角色/进阶隔离读回，内存报告副本引用新真实receipt后verify_experience通过，不伪造原owner完成。原owner/thread01a1415e-a511-7131-be7c-a2dc691c847f/r1仅补同一技术闭环，retry CLI0；现有两槽由两个原084302策略占用，仍pending，未扩槽/中断/新研究模型，排队不是实收。三条原learning_result.questions已原文正式注册原父disagreement44fc95c93f6df419f94e2314，ops_forwarded本人CLI0；既有dd77本人watcher两阶段字节SHA已核，不代新notice watcher/Roy ACK，其本人可绑定已发生原生告知，无须再通知用户。\n  G1a原行为b2bdb0b1dbc7ec9a39909595238b00efbb718321/原实际发布3394e7912f2b4bec3715761858f831f3fa6040dd（08:24:29）已原锁单独补登 **{reg['release_id']}**，保name/family/commit/source和旧行顺序/G4 R367，历史漏登追加下一可用号不重排。登记live{reg['registration_live']}/tree{reg['registration_tree']}；main{reg['main']}仅五对象窄补及版本表，保G4四对象、其他知识/并行暂存。旧规则：旧经验未含本批逐Boss质量缺口、生产输入差及连战端点限定。新规则：五条学习经验明确数量满足不等质量过闸、原固定107/460与原70/本批71生产指纹差分列、均值出口HP/旧0胜曲线不替联合率；保持四闸与未知，不改S/SL/留药阈值。证据/账本：silent-0494、R366冻结表、VNSXWCWXR3VW及六局实际端点/原资源契约。预期仅使这些限定在适用经验提示可读；当前固定读回不是自然采用、通用接口/生产重校准或收益。回退只五对象按当前上下文撤该增量，保G4及其他知识，实际回退另编号不重置整树。0494已本ops原CLI shipped，不关闭原owner/0332/校准/全局宽父。\n  G1c原source9579e378五叶在接受原full1/两补验后实际窄合main{cp['main']}/live{cp['actual_live']}/tree{cp['tree']}，版本表不变、不增行为号；并行记录暂存及刷新知识均保留。已部署同helper实际单次exit0，归档{cadence['archive']}，完整十局边界40、总42的尾2独立保留，5导出SQL/manifest/SHA及state/唯一marker全核，根report.py→nice19/helper原局末钩子字节已核；未重跑report.py/源full/模型/旧模拟或启动游戏。生成decision前缀watcher是原脚本文字，实际调用人为ops而非其他角色ACK。原24共享首试与16 passed字段差不改。新组合独立G1a075726宿主须按当前刷新稳定树单次核，不借G4 adb0或R366绿；原adb0全检0仅关闭其本树。S去留仍Roy待定，所有账号home模型权限prompt预算及当前对局不动。材料G1a/ops-recovery/与G1c/ops-cadence-readback.json。\n"
appends=[]
for path in ['notes/for-roy.md','ops/inbox-dev.md','paper/materials/decision-log.md','notes/ops-handoff.md']:
    f=r/path;raw=msg.encode();before=f.read_bytes()
    with f.open('ab') as out:out.write(raw)
    appends.append(dict(path=path,offset=len(before),bytes=len(raw),sha256=sha(raw),text=msg))
notice=json.loads((priv/'notice-append.json').read_text())
for dest in notice['destinations']:appends.append(dict(**dest,text=notice['text']))
decision=(r/'ops/codex-ops/record-staging/20261016-g1c-publication/cadence-decision-row.txt').read_bytes();appends.append(dict(path='paper/materials/decision-log.md',text=decision.decode(),bytes=len(decision),sha256=sha(decision)))
(priv/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n');(pub/'root-record-appends.json').write_text(json.dumps([{k:v for k,v in a.items() if k!='text'} for a in appends],ensure_ascii=False,indent=2)+'\n')
raw=(r/'paper/materials/learning/ledger.jsonl').read_bytes();head=subprocess.check_output(['git','show','HEAD:paper/materials/learning/ledger.jsonl']);count=collections.Counter(head.splitlines(keepends=True));owned=[];proof=[];offset=0
for n,line in enumerate(raw.splitlines(keepends=True),1):
    row=json.loads(line)
    if count[line]>0:count[line]-=1
    elif row.get('id')=='silent-0494':owned.append(line);proof.append(dict(line=n,offset=offset,bytes=len(line),sha256=sha(line),op=row['op'],by=row['by'],status=row.get('status')))
    offset+=len(line)
assert not any(count.values()) and len(owned)>=2 and sum(json.loads(x).get('by')=='ops' and json.loads(x).get('status')=='shipped' for x in owned)==1
(priv/'own-ledger-rows.jsonl').write_bytes(b''.join(owned));(pub/'ledger-original-row-readback.json').write_text(json.dumps(dict(id='silent-0494',rows=proof,only_original_CLI_rows=True,no_other_claim_or_status_changes=True),ensure_ascii=False,indent=2)+'\n')
src=r/'.worktrees/silent-boss-calibration';report=src/'learner/runs/20261016-global-build-g1a-r1/report.md';material=src/'paper/materials/20261016-global-build-g1a';old_receipt=json.loads((material/'validation/consumer-receipt.json').read_text());files=[report,material/'questions.json',material/'experience-links.json',material/'validation/validation.json',material/'validation/prior-checks.json',material/'validation/consumer-receipt.json',*[Path(x['path']) for x in old_receipt['evidence']]]
archive=pub/'original-g1a-report-and-probe.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for i,f in enumerate(files):tar.add(f,arcname=f'{i:02d}-{f.name}')
(pub/'original-g1a-archive-manifest.json').write_text(json.dumps(dict(archive_sha256=sha(archive.read_bytes()),originals=[dict(path=str(f.relative_to(r)),sha256=sha(f.read_bytes()),bytes=f.stat().st_size) for f in files],old_failed_batch_retained=True),ensure_ascii=False,indent=2)+'\n')
arc=r/cadence['archive'];f=g1c/'ops-initial-archive-evidence.tar.gz';assert not f.exists()
with tarfile.open(f,'w:gz') as tar:
    for file in arc.iterdir():
        if file.is_file():tar.add(file,arcname=file.name)
old_state=r/'ops/codex-ops/global-build-funnel/state.json';(g1c/'ops-initial-cadence-state.json').write_bytes(old_state.read_bytes())
for name in ['current-fixed-probe.py','resume-and-notice.py','register-release.py']:
    assert (priv/name).exists()
helpers=pub/'ops-recovery-helpers-and-attempts.tar.gz'
with tarfile.open(helpers,'w:gz') as tar:
    for f in priv.iterdir():
        if f.is_file() and (f.suffix in ['.py','.log']):tar.add(f,arcname=f.name)
    gp=r/'ops/codex-ops/record-staging/20261016-g1c-publication'
    for f in gp.iterdir():
        if f.is_file() and (f.name.startswith('integration-') or f.name=='integrate.py'):tar.add(f,arcname='g1c/'+f.name)
(pub/'ops-transaction-boundaries.json').write_text(json.dumps(dict(original_batch_guard_failure='kept rc0/failed/blocked and all original probe bytes',initial_registration_guard='foreign main index staged original watcher records; stopped before mutation',next_guard='watcher committed own622cf records during preflight; ref/index guard stopped before mutation',resolution='private commit indexes and exact preserved foreign staged entries; retry only after actual owner record commit, not a wait/poll loop',G1c_prior_blocks=['old adb0 host lock','disjoint active knowledge preflight','retention sweep lock','index stat cache bytes guard'],G1c_resolution='five source paths are disjoint from all generated knowledge, so preserve every other tree leaf and staged entry; compare actual index object/mode entries, retain old guard attempts, never stop builders/retention or overwrite shared records',no_product_bug_or_game_discovery=True,no_new_fix_or_research_task=True),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(own_appends=len(appends),ledger_rows=len(owned),real_archive=cadence['archive'],release_id=reg['release_id'],S='unchanged'),ensure_ascii=False),flush=True)

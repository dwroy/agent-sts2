from pathlib import Path
import fcntl,hashlib,json,os,re,subprocess,sys
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261016-g1a-recovery';pub=r/'paper/materials/20261016-global-build-g1a/ops-recovery';sha=lambda b:hashlib.sha256(b).hexdigest()
template=(r/'ops/codex-ops/record-staging/20261016-0240/publish.py').read_text();exec(template[template.index('def git('):template.index('assert not (pub/')].replace('.ops-poison.tmp','.ops-g1a.tmp'))
def save(path,v):path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
actual='3394e7912f2b4bec3715761858f831f3fa6040dd';behavior='b2bdb0b1dbc7ec9a39909595238b00efbb718321';source='28161b2d2a31e95587999fc6e5028acd727cecb2';name='V5.silent-g1a-knowledge1';leaf='knowledge/characters/silent/experience.json'
assert not (pub/'ops-release-registration.json').exists()
lock=(r/'ops/live-merge.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:
    at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
    value=dict(at=at,actor='ops',state='pending original live lock',original_actual_publication=actual,original_behavior=behavior,source=source,release_id=None,main_live_index_or_registry_changed=False,reason='Do not interrupt original G4 adb0 host; assign next available release only after lock acquired. Old G1a probes and new current-version fixed receipt distinct; original owner waits existing two slots.',next='Original adb0 learner-checks event, same lock and this exact registration script; no polling or new pipeline',script=str((p/'register-release.py').relative_to(r)))
    save(pub/'ops-release-pending.json',value);f=r/'ops/codex-ops/pending-integrations/global-build-g1a-registration.json';f.parent.mkdir(parents=True,exist_ok=True);save(f,value);print('G1a number remains unassigned; original live lock busy',flush=True);sys.exit(75)
with lock:
    at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
    mh=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip()
    for x in [actual,behavior,source]:git('merge-base','--is-ancestor',x,'HEAD',cwd=live)
    assert not git('diff','--name-only','HEAD','--','knowledge',cwd=live).strip()
    cached={};index_snapshot={};index_paths={};index_entries={}
    for cwd in [r,live]:
        assert not git('ls-files','-u',cwd=cwd).strip()
        cached[str(cwd)]=git('diff','--cached','--name-status',cwd=cwd);index_entries[str(cwd)]=git('ls-files','--stage','-z',cwd=cwd)
        staged=set(git('diff','--cached','--name-only',cwd=cwd).decode().splitlines());assert not staged.intersection([leaf,'eval/versions.json'])
        idx=Path(git('rev-parse','--git-path','index',cwd=cwd).decode().strip());idx=idx if idx.is_absolute() else cwd/idx;index_paths[str(cwd)]=idx;index_snapshot[str(cwd)]=idx.read_bytes()
    current=blob(lh,leaf,live);exp=json.loads(current);expected=json.loads((pub/'current-consumer-receipt.json').read_text())['entries'];by={e['id']:e for e in exp['entries']}
    canonical=lambda e:json.dumps(e,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
    for ref in expected:assert sha(canonical(by[ref['id']]))==ref['sha256']
    oldmain=blob(mh,leaf);mainexp=json.loads(oldmain);oldby={e['id']:e for e in mainexp['entries']};desired={e['id']:e for e in exp['entries'] if e['id'] in {x['id'] for x in expected}}
    assert len(desired)==5 and len(set(desired)-set(oldby))==4
    original_before=json.loads(blob(behavior+'^1',leaf,live));original_by={e['id']:e for e in original_before['entries']}
    for key in desired:
        if key in oldby:assert oldby[key]==original_by[key]
    mainexp['entries']=[desired.get(e['id'],e) for e in mainexp['entries']]+[e for e in exp['entries'] if e['id'] in desired and e['id'] not in oldby]
    mainexp['version']=exp['version'];newmain=(json.dumps(mainexp,ensure_ascii=False,indent=2)+'\n').encode();assert newmain==current
    datasets={}
    for cwd,head in [(r,mh),(live,lh)]:
        raw=blob(head,'eval/versions.json',cwd);assert (cwd/'eval/versions.json').read_bytes()==raw;datasets[str(cwd)]=json.loads(raw)
    registry=datasets[str(live)]['release_numbering']['releases'];assert registry==datasets[str(r)]['release_numbering']['releases'];assert not any(x['commit']==behavior for x in registry)
    nums=[int(re.fullmatch(r'V\d+-R(\d+)',x['release_id'])[1]) for x in registry];assert nums==list(range(max(nums)+1));rid=f'V5-R{max(nums)+1:03d}'
    original=[x for x in datasets[str(live)]['versions'] if x.get('name')==name];assert len(original)==1 and original[0]['commit']==behavior and not original[0].get('release_id')
    registered={**original[0],'release_id':rid,'release_status':'registered-primary-ops'};versions={}
    for cwd in [r,live]:
        data=datasets[str(cwd)];found=[i for i,v in enumerate(data['versions']) if v.get('name')==name]
        if cwd==live:assert len(found)==1;data['versions'][found[0]]=registered
        else:assert not found;data['versions'].append(registered)
        data['release_numbering']['releases'].append(dict(release_id=rid,commit=behavior,aliases=[name]))
        versions[str(cwd)]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
    before={str(cwd):{path:sha((cwd/path).read_bytes()) for path in git('diff','--name-only','HEAD',cwd=cwd).decode().splitlines() if path not in [leaf,'eval/versions.json']} for cwd in [r,live]}
    scanvalues={p/'registration-scan/main'/leaf:newmain,p/'registration-scan/live'/leaf:current,p/'registration-scan/registration.json':(json.dumps(registered,ensure_ascii=False,indent=2)+'\n').encode()}
    reuse=(p/'registration-gitleaks.json').exists() and json.loads((p/'registration-gitleaks.json').read_text())==[] and all(f.exists() and f.read_bytes()==raw for f,raw in scanvalues.items())
    for f,raw in scanvalues.items():f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
    if not reuse:
        with (pub/'registration-gitleaks.log').open('wb') as scan:run=subprocess.run(['nice','-n','19','gitleaks','dir',str(p/'registration-scan'),'--redact','--no-banner','--report-format','json','--report-path',str(p/'registration-gitleaks.json')],stdout=scan,stderr=subprocess.STDOUT,env={**os.environ,'GOMAXPROCS':'1'})
        assert run.returncode==0
    assert json.loads((p/'registration-gitleaks.json').read_text())==[]
    le={**os.environ,'GIT_INDEX_FILE':str(p/'live.index')};git('read-tree',lh,cwd=live,env=le);stage('eval/versions.json',versions[str(live)],le,live);lt=git('write-tree',cwd=live,env=le).decode().strip();ln=commit(lt,[lh],'Register original G1a knowledge publication as '+rid,live)
    me={**os.environ,'GIT_INDEX_FILE':str(p/'main.index')};git('read-tree',mh,env=me);stage(leaf,newmain,me,r);stage('eval/versions.json',versions[str(r)],me,r);mt=git('write-tree',env=me).decode().strip();mn=commit(mt,[mh,source],'Integrate original G1a experience and register '+rid,r)
    normal=[]
    for cwd,original_env,label in [(r,me,'main'),(live,le,'live')]:
        target=p/(label+'-preserved.index');target.write_bytes(index_snapshot[str(cwd)]);env={**os.environ,'GIT_INDEX_FILE':str(target)}
        if cwd==r:stage(leaf,newmain,env,cwd)
        stage('eval/versions.json',versions[str(cwd)],env,cwd);normal.append((cwd,env))
    locks=locks_for(normal)
    try:
        for cwd,head in [(r,mh),(live,lh)]:assert git('rev-parse','HEAD',cwd=cwd).decode().strip()==head;assert git('ls-files','--stage','-z',cwd=cwd)==index_entries[str(cwd)];assert all(sha((cwd/path).read_bytes())==value for path,value in before[str(cwd)].items())
        git('update-ref','-m','ops: register historical G1a publication without re-publishing knowledge','HEAD',ln,lh,cwd=live);install(live,'eval/versions.json',versions[str(live)])
        git('update-ref','-m','ops: bounded original five G1a experience integration','HEAD',mn,mh);install(r,leaf,newmain);install(r,'eval/versions.json',versions[str(r)])
        for idx,lp in locks:os.replace(lp,idx)
    finally:
        for _,lp in locks:
            if lp.exists():lp.unlink()
    assert git('diff','--name-only',lh,ln,cwd=live).decode().splitlines()==['eval/versions.json']
    for cwd in [r,live]:assert git('diff','--cached','--name-status',cwd=cwd)==cached[str(cwd)];assert all(sha((cwd/path).read_bytes())==value for path,value in before[str(cwd)].items())
    value=dict(at=at,release_id=rid,name=name,original_behavior_commit=behavior,original_publication=actual,original_publication_tree='de12005a2b4dde0db4adbd83c116e7e9914038cc',original_publication_time='2026-10-16 08:24:29 CST',source=source,old_live=lh,registration_live=ln,registration_tree=lt,old_main=mh,main=mn,five_source_objects=expected,main_experience_sha256=sha(newmain),live_experience_unchanged_sha256=sha(current),live_only_registry_changed=True,old_name_family_commit_source_and_list_order_preserved=True,G4_R367_and_old_registry_preserved=True,historical_missed_release_appended_no_reordering=True,no_knowledge_republication_or_new_game_behavior=True,host='pending independent original075726 exact final-composition check; no borrowing G4 or R366',current_fixed_probe='actual fresh5 passed, owner completion pending existing slots',wide_parents='open')
    save(pub/'ops-release-registration.json',value);print(json.dumps(dict(release_id=rid,registration_live=ln,tree=lt,main=mn,live_experience_unchanged=True)),flush=True)

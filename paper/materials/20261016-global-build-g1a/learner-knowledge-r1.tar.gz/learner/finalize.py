"""Independently read back fixed publication, exact experience hashes and real receipts."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
WORK=OUT.parents[2]
ROOT=Path('/home/dw/Projects/agent-sts2')
LIVE=ROOT/'.worktrees/live'
PAPER=WORK/'paper/materials/20261016-global-build-g1a'


def sha(data): return hashlib.sha256(data).hexdigest()


def git(*args): return subprocess.check_output(['git','-C',str(LIVE),*args])


def reference(path): return {'path':str(path),'sha256':sha(path.read_bytes())}


def main():
    s=json.loads((OUT/'publication.json').read_text())
    assert s['publication'] and s['merged'] and not s.get('error')
    assert git('rev-parse',s['publication']+'^{tree}').decode().strip()==s['fixed_release_tree']
    commits=['c5de2c42bcb944822c36dd0efecff11e541baf76','ef6831db40cb90733bcedced3760dbe53a2f8e88',s['source'],s['receipt_source'],s['merged'],s['publication'],'b342d47ba211a252085749e8c254e5d68ce20327']
    for commit in commits:
        subprocess.run(['git','-C',str(LIVE),'merge-base','--is-ancestor',commit,'HEAD'],check=True)
    before=s['before_code']
    changed=git('diff','--name-only',before,s['publication']).decode().splitlines()
    assert all(p=='knowledge/characters/silent/experience.json' or p.startswith('paper/materials/20261016-global-build-g1a/') or p in ['eval/versions.json','paper/materials/decision-log.md'] for p in changed)
    data=json.loads(git('show',s['publication']+':knowledge/characters/silent/experience.json'))
    by_id={e['id']:e for e in data['entries']}
    for entry in s['experience_refs']:
        assert sha(json.dumps(by_id[entry['id']],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==entry['sha256']
    receipt_path=Path(s['consumer_receipt']['path']); receipt=json.loads(receipt_path.read_text())
    assert sha(receipt_path.read_bytes())==s['consumer_receipt']['sha256']
    assert receipt_path.read_bytes()==git('show',s['publication']+':'+str(receipt_path.relative_to(WORK)))
    assert receipt['request_id']==s['request_id'] and receipt['revision']==1 and receipt['character']=='silent'
    assert receipt['status']=='passed' and receipt['kind']=='fixed-consumer'
    for entry in receipt['evidence']: assert sha(Path(entry['path']).read_bytes())==entry['sha256']
    for filename in ['consumer.mts','consumer-input.json','live-consumer-output.json','live-consumer-command.json','live-consumer.log']:
        assert (OUT/filename).read_bytes()==(PAPER/'validation'/filename).read_bytes()
    command=json.loads((OUT/'live-consumer-command.json').read_text()); assert command['exit']==0 and command['cwd']==str(LIVE)
    actual=json.loads((OUT/'live-consumer-output.json').read_text()); assert actual['root']==str(LIVE) and len(actual['checks'])==5
    versions=json.loads(git('show',s['publication']+':eval/versions.json')); items=versions if isinstance(versions,list) else versions['versions']
    version=[v for v in items if v['name']==s['version']]; assert len(version)==1 and version[0]['commit']==s['merged']
    notices=json.loads((OUT/'notification.json').read_text())
    for record in notices['evidence']:
        with Path(record['path']).open('rb') as h:h.seek(record['offset']); chunk=h.read(record['bytes'])
        assert sha(chunk)==record['sha256']
    assert subprocess.check_output(['git','status','--porcelain'],cwd=WORK).decode()==''
    by_ref={e['id']:e for e in s['experience_refs']}
    bosses=[by_ref['silent-g1a-'+boss+'-calibration-boundary'] for boss in ['aeonglass','queen','test-subject']]
    boundary=by_ref['silent-g1a-fixed-production-boundary']; handoff=by_ref['silent-double-boss-resource-handoff']
    coverage={'global-g1a-low-trust-per-boss':bosses,'global-g1a-fixed-and-production-inputs':[boundary],
              'global-g1a-continuous-resource-contract':[handoff],'global-g1a-experience-live-consumer':s['experience_refs'],
              'global-g1a-unknowns-and-objections':[boundary,handoff]}
    learning={'request_id':s['request_id'],'revision':1,'input_sha256':'66f3ad3a272f4fe74f12d0832ea220be57f5aade9e2f89a0a1044e261166ff5b',
              'outcome':'complete','coverage':coverage,'consumer_receipt':s['consumer_receipt'],
              'questions':json.loads((PAPER/'questions.json').read_text()),
              'scope':'G1a knowledge requirements delivered to live and fixed consumers. Parent G1a interface/natural acceptance, calibration/0332/global-build and delivery ACKs remain open; no registry or ACK changed.'}
    (OUT/'learning-result.json').write_text(json.dumps(learning,ensure_ascii=False,indent=2)+'\n')
    result={'task':'strategy-proposal','character':'silent','base':'50e2da099a5e1745878070ea960f3160324f2217',
            'fixes':[{'item':'Roy已授权G1a：静默Boss校准边界经验入库与连续Boss资源契约','commit':s['source'],
                      'test':'30原帧、70原行SHA、24四闸行；候选及实际live五条经验生产消费者/角色进阶隔离；提案链及gitleaks通过','fails_without_fix':False,'nature':'authorized knowledge feature; no production source or strategy threshold change','ledger':['silent-0494']}],
            'merged':s['merged'],'publication':s['publication'],'fixed_release_tree':s['fixed_release_tree'],'version':s['version'],
            'experience_version':data['version'],'release_id':None,'release_id_status':'ops核实际发布后统一登记；不是等待Roy批准',
            'tests':{'candidate_consumer':0,'live_consumer':0,'readback_entries':5,'character_and_ascension_isolation':True,
                     'raw_states_sha':30,'run_sl_rows_sha':70,'four_gate_rows':24,'unchanged_other_entries':231,
                     'proposal_chain':0,'gitleaks':0,'tsc_vitest_this_revision':'not rerun: data-only; original exact-tree checks reused per request',
                     'prior_checks':reference(PAPER/'validation/prior-checks.json'),
                     'preserved_failures':['audit initial encounter alias mismatch','tsx IPC EPERM, same probe passed with Node loader','first live publication ignored-log staging rejection; own merge rolled back and refresh retained'],
                     'external_full':'dispatcher owns complete external checks'},
            'code_proposals':['silent-proposal-08156445e1c13d33'],'implementation_domains':['structure'],
            'proposal_results':[{'id':'silent-proposal-08156445e1c13d33','status':'waiting',
                                 'reason':'经验数据已发布且实际消费通过；当前生产模型新校准/联合率缺质量与独立结局证据，未冒称新增源码接口implemented，原watcher负责通用连战接口；不重复派原研究。'}],
            'commits':commits,'rolled_back_commit':'4d2a9ad50cf4e66eab60cefc717edf6df284fe4d',
            'report':str(OUT/'report.md'),'materials':str(PAPER/'completion.md'),'resource_contract':reference(PAPER/'continuous-resource-contract.json'),
            'notification':reference(OUT/'notification.json'),'learning_result':learning}
    (OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    report=(PAPER/'completion.md').read_text()
    report+='\n## 实际交付读回\n\n'
    report+=f'源码链 c5de2c42bcb944822c36dd0efecff11e541baf76 / ef6831db40cb90733bcedced3760dbe53a2f8e88 / {s["source"]}，实际经验合入 {s["merged"]}，读取回执源 {s["receipt_source"]}，发布 {s["publication"]}，固定树 {s["fixed_release_tree"]}。全部已核为实际live祖先。版本 {s["version"]} / 经验 {data["version"]}，正式release_id交ops核号。\n\n'
    report+='账本silent-0494只由CLI追加proposed及实际来源；shipped由ops登记。提案silent-proposal-08156445e1c13d33为结构追溯，当前生产校准/通用联合接口未标implemented。既有资源提案/普通策略owner保持。首轮锁忙未改live；第一次live探针通过但材料.log被忽略规则拒绝暂存，合入4d2a9ad已撤回，保留刷新b342d47；失败原件见failed-publication-1/。修正精确审计文件force-add后完整发布成功，未重跑全套/旧模拟。\n\n'
    report+=f'生产消费者实际读取5条经验，输入/输出/命令均冻结；回执 {receipt_path}，SHA {s["consumer_receipt"]["sha256"]}。30原帧、70原行与24闸表通过；其他231条经验值不变。未证明自然采用、收益、生产模型校准或两场接口完成。\n\n'
    report+='根目录双通知已实际追加并pread核SHA，见notification.json；只证明写入，未冒watcher/Roy已读或ACK。原676/原校准身份未重开或改revision。learning_result complete仅表示本轮五项知识交付入live且固定消费者通过，注册仍由ops/watcher沿awaiting_delivery闭环；不关闭原校准、0332或global-build宽父。\n'
    (OUT/'report.md').write_text(report)
    with (OUT/'source-final.diff').open('wb') as h: subprocess.run(['git','diff','--binary','50e2da099a5e1745878070ea960f3160324f2217',s['source']],cwd=WORK,stdout=h,check=True)
    verification={'publication':s['publication'],'fixed_tree':s['fixed_release_tree'],'live_ancestors':commits,'allowed_changed_paths':len(changed),'experience_hashes':s['experience_refs'],
                  'receipt_sha':s['consumer_receipt']['sha256'],'root_notification_ranges_verified':2,'worktree_clean':True,'ledger_status':'proposed; CLI trace appended, shipped reserved to ops'}
    (OUT/'final-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
    refs=[reference(PAPER/'calibration-readback.json'),reference(PAPER/'continuous-resource-contract.json'),reference(PAPER/'production-boundary.json'),reference(OUT/'report.md'),reference(OUT/'report.json'),reference(OUT/'final-verification.json'),reference(OUT/'source-final.diff')]
    (OUT/'delivery-manifest.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'verified':True,'publication':s['publication'],'source_ancestors':len(commits),'receipt':s['consumer_receipt'],'report':str(OUT/'report.md')}))


if __name__=='__main__': main()

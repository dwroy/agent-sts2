import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extractor", ROOT / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
dispatch = json.loads((OUT / "dispatch.json").read_text())
runs = set(dispatch["runs"])
streams = {}
verification = []
for stream in manifest:
    name = stream["stream"]
    path = OUT / "evidence" / (name + ".evidence.jsonl")
    digest = hashlib.sha256()
    count = collections.Counter(dict.fromkeys(dispatch["runs"], 0))
    entries = []
    previous = -1
    with Path("/home/dw/Projects/agent-sts2/logs", name + ".jsonl").open("rb") as source, path.open("rb") as evidence:
        for encoded in evidence:
            digest.update(encoded)
            entry = json.loads(encoded)
            assert previous < entry["offset"]
            previous = entry["offset"]
            assert entry["offset"] + entry["bytes"] <= stream["source_size"]
            source.seek(entry["offset"])
            raw = source.read(entry["bytes"])
            assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
            assert json.loads(raw) == entry["row"]
            assert extractor.run_identity(entry["row"]) == entry["run_id"] in runs
            count[entry["run_id"]] += 1
            entries.append(entry)
    assert dict(count) == stream["counts"]
    assert digest.hexdigest() == stream["output_sha256"]
    streams[name] = entries
    verification.append({"stream": name, "verified_rows": len(entries), "counts": dict(count),
                         "source_size": stream["source_size"], "raw_bytes_sha_json_identity": True,
                         "output_sha256": digest.hexdigest()})
write("evidence-verification.json", verification)


def slim(entry):
    state = entry["row"]["state"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    run = state.get("run") or {}
    return {"source_line": entry["line"], "ts": entry["row"]["ts"], "run_id": entry["run_id"],
            "screen": state["screen"], "floor": run.get("floor"), "turn": state.get("turn"),
            "hp": player.get("current_hp", run.get("current_hp")), "block": player.get("block"),
            "player_powers": player.get("powers"),
            "hand": [{k: card.get(k) for k in ("index", "card_id", "energy_cost")} for card in combat.get("hand") or []],
            "enemies": [{k: enemy.get(k) for k in ("index", "enemy_id", "current_hp", "max_hp", "block", "is_alive", "powers", "move_id", "intents")}
                        for enemy in combat.get("enemies") or []],
            "potions": [{k: potion.get(k) for k in ("slot", "potion_id", "occupied")} for potion in run.get("potions") or []]}


states = collections.defaultdict(list)
for entry in streams["states"]:
    states[entry["run_id"]].append(entry)
decisions = {entry["line"]: entry for entry in streams["decisions"]}
state_lines = {entry["line"]: entry for entry in streams["states"]}


def window(line):
    decision = decisions[line]
    row = decision["row"]
    candidates = [entry for entry in states[decision["run_id"]] if entry["row"]["ts"] >= row["ts"]]
    start = next(entry for entry in candidates if entry["row"]["state"].get("turn") == row["turn"])
    selected = []
    for entry in candidates:
        selected.append(entry)
        state = entry["row"]["state"]
        if state.get("turn") != row["turn"] or state.get("screen") == "GAME_OVER":
            break
    end = selected[-1]
    actions = [{"source_line": entry["line"], **{key: entry["row"].get(key) for key in ("ts", "label", "chosen", "result", "sl_attempt", "sl_explore")}}
               for entry in streams["decisions"] if entry["run_id"] == decision["run_id"]
               and row["ts"] <= entry["row"]["ts"] <= end["row"]["ts"]]
    a, b = slim(start), slim(end)
    enemy_start = {e["enemy_id"]: e["current_hp"] for e in a["enemies"]}
    enemy_end = {e["enemy_id"]: e["current_hp"] for e in b["enemies"]}
    same_enemies = set(enemy_start) == set(enemy_end)
    return {"decision_line": line, "run_id": decision["run_id"], "floor": row["floor"], "turn": row["turn"],
            "attempt": row.get("sl_attempt"), "original_answer": row.get("answers"), "sl_explore": row.get("sl_explore"),
            "states": [slim(entry) for entry in selected], "actions": actions,
            "observed_hp_loss": a["hp"] - b["hp"],
            "observed_net_enemy_hp_reduction": sum(enemy_start[k] - enemy_end[k] for k in enemy_start) if same_enemies else None,
            "scope": "候选首次派发至下一回合观测的净变化；未执行原线仍未知；净扣血不自动当毛伤害或单来源贡献"}


pairs = [(272434, 272575), (272531, 272652), (272483, 272820),
         (273400, 273450), (274505, 274568), (274484, 274601)]
paired = []
for first, second in pairs:
    a, b = decisions[first], decisions[second]
    assert a["run_id"] == b["run_id"]
    assert a["row"]["fingerprint"] == b["row"]["fingerprint"]
    left, right = window(first), window(second)
    paired.append({"decisions": [first, second], "same_fingerprint": True,
                   "fingerprint_sha256": hashlib.sha256(a["row"]["fingerprint"].encode()).hexdigest(),
                   "original": left, "replacement": right,
                   "delta_hp_loss": right["observed_hp_loss"] - left["observed_hp_loss"],
                   "delta_net_enemy_hp_reduction": right["observed_net_enemy_hp_reduction"] - left["observed_net_enemy_hp_reduction"]})
write("paired-observations.json", paired)

potion_pairs = [(280206, 280207), (280232, 280233), (280262, 280263),
                (280313, 280314), (280315, 280316), (280348, 280349), (280354, 280355)]
write("ken-potion-transitions.json", [{"before": slim(state_lines[a]), "after": slim(state_lines[b])} for a, b in potion_pairs])
write("giant-poison-transition.json", {"before": slim(state_lines[280160]), "after": slim(state_lines[280161])})

attempts = []
for entry in streams["sl-attempts"]:
    row = entry["row"]
    attempts.append({"source_line": entry["line"], "run_id": entry["run_id"],
                     **{key: row.get(key) for key in ("floor", "attempt", "result", "turns", "end_hp", "end_block", "incoming")},
                     "last_turn": (row.get("summary", {}).get("turns") or [None])[-1],
                     "anchor": (row.get("explore") or {}).get("target", {})})
write("attempt-outcomes.json", attempts)

write("focused-decisions.json", [decisions[line] for line in sorted(set(sum(([a, b] for a, b in pairs), [])) |
    {272361, 272362, 274087, 274131, 274156, 274185, 274235, 274237, 274267, 274272, 274354, 273451})])
print(json.dumps({"verified_rows": sum(len(rows) for rows in streams.values()), "streams": len(streams),
                  "pairs": [{"decisions": p["decisions"], "hp_loss": [p["original"]["observed_hp_loss"], p["replacement"]["observed_hp_loss"]],
                             "net_enemy_hp_reduction": [p["original"]["observed_net_enemy_hp_reduction"], p["replacement"]["observed_net_enemy_hp_reduction"]]}
                            for p in paired]}, ensure_ascii=False))

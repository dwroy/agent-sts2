import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {r['line']: r for r in map(json.loads, (OUT / 'state-summaries.jsonl').open())}
checks = []

def check(name, actual, expected, lines):
    result = {'name': name, 'actual': actual, 'expected': expected,
              'state_source_lines': lines, 'passed': actual == expected}
    checks.append(result)

def p(line, key):
    return states[line]['powers'].get(key)

def hp(line):
    return states[line]['hp']

check('预判之后柔嫩净敏捷', p(285223, 'DEXTERITY_POWER'), 1, [285222, 285223])
check('速度药当步敏捷增量', p(285224, 'DEXTERITY_POWER') - p(285223, 'DEXTERITY_POWER'), 5, [285223, 285224])
for a, b, expected in [(285224, 285225, 12), (285226, 285227, 9), (285228, 285229, 4)]:
    check('卡牌或折扇的相邻实挡增量', states[b]['block'] - states[a]['block'], expected, [a, b])
for power in ['ANTICIPATE_POWER', 'SPEED_POTION_POWER', 'DEXTERITY_POWER', 'STRENGTH_POWER']:
    check('下一轮原帧未列临时项：' + power, p(285230, power), None, [285229, 285230])
check('柔嫩仍在', p(285230, 'TENDER_POWER'), 1, [285230])
check('生存者后跨轮实际净损', hp(286158) - hp(286163), 14, [286158, 286163])
check('覆甲跨轮层数', [p(286162, 'PLATING_POWER'), p(286163, 'PLATING_POWER')], [3, 2], [286162, 286163])
check('获胜战入血与后房入血', [hp(286112), hp(286146), hp(286147)], [70, 42, 42], [286112, 286146, 286147])
check('沙漏毒胜仍支付9点持牌伤', hp(286893) - hp(286894), 9, [286893, 286894])
check('毒胜剩余合法防御牌及能量', [states[286893]['energy'], sorted(c['id'] for c in states[286893]['hand'] if c['playable'] and c['values'].get('Block', 0) > 0)], [5, ['DEFEND_SILENT', 'HAND_TRICK', 'UNTOUCHABLE']], [286893])
check('连战不预支回血', [hp(286840), hp(286842), hp(286895), hp(286896)], [97, 97, 23, 23], [286840, 286842, 286895, 286896])
check('新战不继承旧能力', states[286896]['powers'], {}, [286893, 286896])
check('幽灵实加一层', [p(286897, 'INTANGIBLE_POWER'), p(286898, 'INTANGIBLE_POWER')], [None, 1], [286897, 286898])
check('幽灵当步不改变已有挡', [states[286897]['block'], states[286898]['block']], [16, 16], [286897, 286898])
check('下一轮真实存活与钳子余挡', [hp(286899), states[286899]['block']], [23, 10], [286898, 286899])
check('临死前夜魇建立复制标记', p(286986, 'NIGHTMARE_POWER'), 3, [286986])
check('复制后未到下一轮便死亡', [states[286986]['turn'], states[286987]['turn'], hp(286987)], [4, 4, 0], [286986, 286987])
check('后段毒药实加总量7', [states[288470]['enemies'][2]['powers'].get('POISON_POWER'), states[288471]['enemies'][2]['powers']['POISON_POWER']], [None, 7], [288470, 288471])
check('饮毒药当步敌HP与玩家HP不变', [hp(288470), hp(288471), states[288470]['enemies'][2]['hp'], states[288471]['enemies'][2]['hp']], [1, 1, 25, 25], [288470, 288471])
check('后段实结7到18', states[288472]['enemies'][2]['hp'], 18, [288471, 288472])
check('中段后继发生重接', [states[288471]['enemies'][1]['hp'], states[288472]['enemies'][1]['hp']], [0, 25], [288471, 288472])
check('毒药末轮仍死', hp(288472), 0, [288472])
for line, block in [(288811, 29), (288904, 19)]:
    check('速度药已经兑现到实际挡', [states[line]['block'], p(line, 'DEXTERITY_POWER'), p(line, 'SPEED_POTION_POWER')], [block, 5, 5], [line])
    held = sum(c['values'].get('Damage', 0) for c in states[line]['hand'] if c['id'] == 'TOXIC')
    attack = sum(i.get('total_damage') or 0 for e in states[line]['enemies'] for i in e['intents'])
    check('持牌伤与显示攻击分别记录', [held, attack], [10, 17], [line])
check('同盘起始HP与敌HP一致', [[hp(n), [e['hp'] for e in states[n]['enemies']]] for n in [288806, 288899]], [[10, [61, 41]], [10, [61, 41]]], [288806, 288899])
check('同盘两实线血价', [hp(288806) - hp(288812), hp(288899) - hp(288905)], [0, 8], [288806, 288812, 288899, 288905])
check('末线敌残净差6，仅限端点', sum(e['hp'] for e in states[288812]['enemies']) - sum(e['hp'] for e in states[288905]['enemies']), 6, [288812, 288905])
check('沙漏末轮39毒与额外一次触发', [states[288007]['enemies'][0]['powers']['POISON_POWER'], p(288007, 'ACCELERANT_POWER')], [39, 1], [288007])
check('沙漏末轮总敌净差80', states[288007]['enemies'][0]['hp'] - states[288008]['enemies'][0]['hp'], 80, [288007, 288008])
check('毒两触发77与其余3不混为80毒伤', 39 + 38, 77, [288007, 288008])
check('零血截断仅观察玩家净扣3', hp(288007) - hp(288008), 3, [288007, 288008])
heals = json.loads((OUT / 'act-heal-readback.json').read_text())
check('跨幕固定端点数量', len(heals), 22, [])
check('跨幕同上限80%缺血回复逐对成立', all(r['matches'] for r in heals), True, [])
check('跨幕样本按进阶分列', {str(a): sum(r['ascension'] == a for r in heals) for a in [9, 10]}, {'9': 5, '10': 17}, [])
for receipt in json.loads((OUT / 'audit-receipts.json').read_text()):
    check('有界离线审计退出码：' + receipt['run_id'], receipt['exit_code'], 0, [])
    data = json.loads((OUT / ('audit-' + receipt['run_id'] + '.json')).read_text())
    check('不认证完整候选：' + receipt['run_id'], all(s['actual_full_candidate_result'] is None for s in data['segments']), True, [])
(OUT / 'material-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'passed': sum(c['passed'] for c in checks), 'failed': [c for c in checks if not c['passed']]}, ensure_ascii=False))
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)

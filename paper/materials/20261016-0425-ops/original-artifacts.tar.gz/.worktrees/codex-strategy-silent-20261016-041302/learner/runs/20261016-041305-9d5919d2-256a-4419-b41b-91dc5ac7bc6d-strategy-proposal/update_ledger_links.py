import copy
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
ids = sorted({i for proposal in assigned for i in proposal['ledger']})
before_bytes = LEDGER.read_bytes()
before_fold = ledger.fold(ledger.read_rows(str(LEDGER)))
before = {i: before_fold[i] for i in ids}
assert all(r['character'] == 'silent' for r in before.values())
(OUT / 'ledger-update-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
rows = []
for ident in ids:
    proposals = [p['id'] for p in assigned if ident in p['ledger']]
    rows.append({'id': ident, 'by': 'learner:strategy-proposal',
                 'where': {'proposal': [str(OUT / 'proposal.md')]},
                 'note': '20261016-041302-strategy-proposal逐项证据核查；' + ','.join(proposals)
                         + '均waiting。15局八流原字节已核；六限定离线窗口与53材料断言不充作完整模型校准或策略收益。具体证据/现有窄实现/待补数据见本批proposal.md和report.md；本次仅补追溯，不改旧结论、证据、状态或版本。'})
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows)
(OUT / 'ledger-update-input.jsonl').write_text(payload)
run = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], input=payload,
                     text=True, capture_output=True)
(OUT / 'ledger-update.stdout.txt').write_text(run.stdout)
(OUT / 'ledger-update.stderr.txt').write_text(run.stderr)
(OUT / 'ledger-update-receipt.json').write_text(json.dumps({'exit_code': run.returncode,
    'before_size': len(before_bytes), 'before_sha256': hashlib.sha256(before_bytes).hexdigest(),
    'ids': ids, 'input_sha256': hashlib.sha256(payload.encode()).hexdigest()}, ensure_ascii=False, indent=2) + '\n')
if run.returncode:
    raise SystemExit(run.returncode)
assert run.stdout.split() == ids
after_bytes = LEDGER.read_bytes()
assert after_bytes[:len(before_bytes)] == before_bytes
appends, offset = [], len(before_bytes)
for raw in after_bytes[len(before_bytes):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith('20261016-041302-strategy-proposal逐项证据核查；'):
        assert row['id'] in ids and set(row) == {'op', 'id', 'by', 'where', 'note', 'ts'}
        appends.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert [r['row']['id'] for r in appends] == ids
private = copy.deepcopy(before)
for record in appends:
    ledger.apply(private, record['row'])
protected = []
for ident in ids:
    old, new = before[ident], private[ident]
    for key in set(old) | set(new):
        if key not in {'where', 'notes', 'history'}:
            assert old.get(key) == new.get(key), (ident, key)
    for key, values in old['where'].items():
        assert new['where'][key][:len(values)] == values
    assert new['notes'][:len(old['notes'])] == old['notes'] and len(new['notes']) == len(old['notes']) + 1
    assert new['history'][:len(old['history'])] == old['history'] and len(new['history']) == len(old['history']) + 1
    protected.append({'id': ident, 'non_trace_fields_unchanged': True, 'old_where_preserved': True,
                      'history_and_notes_prefix_preserved': True, 'status': old['status']})
(OUT / 'ledger-update-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-protection.json').write_text(json.dumps({'prefix_preserved': True,
    'prefix_sha256': hashlib.sha256(before_bytes).hexdigest(), 'own_appends': len(appends),
    'items': protected}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': run.returncode, 'own_appends': len(appends),
                  'prefix_preserved': True, 'protected_items': len(protected)}, ensure_ascii=False))

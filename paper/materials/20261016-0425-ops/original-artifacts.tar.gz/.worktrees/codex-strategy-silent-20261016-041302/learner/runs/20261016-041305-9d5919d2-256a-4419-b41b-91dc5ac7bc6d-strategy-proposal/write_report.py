import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
batch = json.loads((OUT / 'dispatch.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
reasons = [
    'RC61 F23T3已核柔嫩下预判净敏1、速度药再加5与12/9/4实挡；缺柔嫩、脆弱及翻倍同时作用的逐牌模型校准和后轮能力兑现对照，不能以现有局部模型关闭整项。',
    'XTSV F49T1幽灵一层已有live祖先实现；T4夜魇建3层后同轮死亡属已观察限制。缺复制到手且可合法执行的存活后继及延后饮药的整战对照，不修改时机或持有价。',
    'BTSR F31T2原线预计损4而实损14、XTSV F48T8毒胜仍损9均已核；弃牌、毒胜保血搜索和耳环未知提示已有窄实现。接管内部动作、复制后继及联合候选完整执行仍无证，保留父项。',
    'BTSR F30胜战70→42并以42入F31、XTSV F48胜战97→23直接入F49成立；缺同条件改线、留药或锻造的完整后继和独立留出校准，不能据赢战掉血拟合新资源阈值。',
    'BTSR F31覆甲3→2、XTSV F49钳子留10和末次减力后仍致死可逐帧核；缺覆甲、临时属性撤回、毒触发、留挡与敌成长的分源联合生产模型回放，当前材料不支持补新组合规则。',
    '9Z9H F48两试T7玩家20→9/11、敌393→344/322是含重问的整轮端点；T8有归零后恢复，T11零血截断。缺逐击未封顶损伤、完整候选归属及受控整战后继，不能用预测或净差拟合SL排序。',
    '15个指定及原提案关联局核得22对同上限跨幕回复，A9五对/A10十七对均符缺血80%取整；未重做原116局资源模型、分阶房间代价与独立路线收益验证，不把局部回复观察当父项完成。',
    '7X0 F31T13后段零毒→7、25HP保持后实结到18已核；中段同时有重接后继。单次组合效应不足校准其他目标、既有毒或重接共同推演，亦缺持有价样本，不反推基础药效或早喝规则。',
    'MTQ0 F23T3四次相关尝试中末线29→19挡、多损8血并多扣6敌血成立；无独立A10留出或完整反事实胜线。饱和死亡样本不能拟合新的HP权重、8点门槛或更安全声明。',
    '7X0 F31及MTQ0 F23固定窗口核实临时敏捷、持牌伤和既有能力边界；原十四机制尚缺逐项固定生产模型校准至联合消费者的完整覆盖，单层效果与字段存在不足关闭复合提案。',
]
evidence = [
    'RC61MFQM63Y6 F23T3—T4，states 285222—285230；原提案另列F17/F29/F33，未将其冒充全部联合机制已回放。',
    'XTSV1U9JD34T F49T1→T2，states 286897—286899；末试T4，286986→286987。',
    'BTSRF7JL1W1Y F31T2→T3，states 286158—286163，decisions 279846；XTSV1U9JD34T F48T8→F49T1，286893—286896。',
    'BTSRF7JL1W1Y F30→F31，states 286112/286146/286147；XTSV1U9JD34T F47→F49，286840/286842/286895/286896。',
    'BTSRF7JL1W1Y F31T2→T3，286162→286163；XTSV1U9JD34T F49T1→T2及末T4，286898/286899/286986/286987。',
    '9Z9H2EXKLF3T F48第二、三试T7—T10及末T11；audit-9Z9H2EXKLF3T.json，states 288000—288008。',
    'act-heal-readback.json逐对列15局中22次实际F17→18/F33→34端点；9Z9H2EXKLF3T 287265→287267、287573→287575。',
    '7X0W3U8TVA2A F31T13，states 288470→288471→288472。',
    'MTQ0EUBJ3R6T F23四试T3；首试states 288806—288812、末试288899—288905；audit-MTQ0EUBJ3R6T.json。',
    '7X0W3U8TVA2A F31T13，288470—288472；MTQ0EUBJ3R6T F23T3，288811/288904及其下一轮。',
]
counter = [
    'RC61该柔嫩窗口无脆弱，不能把分别观察到的机制合成已验证联合取整；战败也不反驳已核局部效果。',
    '幽灵T1已兑现零损，不能称早喝无效；所有实打T4均不足挡，不能称禁夜魇可救活。',
    '弃牌后的新问题/新手牌可能中断原计划；耳环接管后的题面不提供内部动作顺序。',
    '胜战仍可耗血；未来未抵达的火不能算回血，SL药栏恢复不是新获药。没有受控替线胜负。',
    '钳子保留的是实际余挡上限；覆盖一个来源不证明临时减力与敌独立成长同时正确。',
    'T7单题预测多损7换16伤与整轮实际省2、多扣22分账；T8净回血9不等于未承伤，T11敌净扣80不等于80毒。',
    'act_id在原Boss层先变、HP尚未回复；必须接到下一层实际回复帧。低进阶与未见交互不外推。',
    'T13已喝仍死亡；7为该组合总增量，不能另加一次头骨或声称基础药效7。',
    '原线也未证明能赢；不同尝试后续抽牌和能力启动变化，不能把末轮敌残全归第一张攻击。',
    '手牌拥有能力不是已建立；施放临时敏捷不补旧挡，未到下一轮的复制/成长不算已兑现。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reasons[i]} for i, p in enumerate(assigned)]
(OUT / 'proposal-dispositions.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
sections = []
for i, p in enumerate(assigned):
    sections.append(f"## {i+1}. {p['id']}\n\n{p['summary']}\n\n- 账本：{', '.join(p['ledger'])}。\n- 已核证据：{evidence[i]}\n- 限制/反例：{counter[i]}\n- 处置：waiting。{reasons[i]}\n- 预期行为：保留当前策略和未知标记；只有相应机制或完整后继被校准后，才实现原提案所述增量，不预设胜率收益。\n- 验证要求：冻结实际原帧、合法动作、目标与抽弃牌；当前生产入口逐步回放应复现实值；涉及联合机制须同时冻结各来源和时间边界。任何新选择权重须另有独立本角色时间留出，不把本样本同时用于拟合与验证。\n- 回退：本批无行为改动，无需回退；后续实现只逆向相应源码增量，保留原日志、账本和并行知识刷新。\n")
proposal = f"# 本批10项静默猎手提案证据核查\n\n批次：{batch.get('batch', '20261016-041302-strategy-proposal')}；角色silent；来源/实现任务strategy-proposal。基线`{base}`。本批为普通队列消费，无research_request/implementation_request，不承接其他专题。原10份Markdown原字节及SHA均已保存并核匹配。\n\n本批没有形成证据充分的新源码增量。下述每项均保留waiting；局部已有live祖先实现不等于整份复合提案duplicate。没有新增提案ID、经验或规则；既有授权Roy-2026-10-07-learning不作为游戏证据。\n\n" + '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal)
manifest = json.loads((OUT / 'byte-verification.json').read_text())
audit = json.loads((OUT / 'audit-summary.json').read_text())
source = json.loads((OUT / 'source-manifest.json').read_text())
stream_table = '\n'.join(f"| {r['stream']} | {r['verified_rows']} | {r['source_size']} |" for r in manifest)
audit_table = '\n'.join(f"| {r['run_id']} | {r['segments']} | {r['observed_actions']} | {r['turns']} | {r['turn_statuses'].get('observed_turn_endpoints',0)} |" for r in audit)
item_table = '\n'.join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
report = f"""# 静默猎手策略批次核查报告

本批10项均waiting，无新增源码、提交、live合入或版本。已核局部机制及现有窄实现，证据尚不足完成各复合提案；不新增策略权重或药水/SL门槛。

## 身份与基线

- task=strategy-proposal；character=silent；batch=20261016-041302-strategy-proposal。
- report.base：`{base}`。开工git status为空，按普通任务执行git merge --no-edit main，结果Already up to date；HEAD未变。
- 根learn.json本批为reason=proposal，准确派发这10个proposal_ids。没有research_request、implementation_request或proposal_repair；默认专题请求绑定其他批次，因此不读取其work_spec或manifest、不切换研究范围。
- 仅本人操作，无下级agent。没有运行play、联网、读环境密钥或游戏二进制。没有新依赖。
- 派发10锚点见dispatch.json；为逐项处理原提案，另核9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T。15局runs角色均SILENT，A9三局、A10十二局，分阶使用。未核本原生模型请求元数据，不把项目默认模型或历史脑字段当本会话实际模型证明。

## 冻结证据与材料检查

共用extract_evidence.py抽取八流，按显式run/run_id/state.run_id/fingerprint.run核所属，不以正文局号匹配；逐行原source offset/bytes/SHA、JSON和身份再次核验。共{sum(r['verified_rows'] for r in manifest)}行，SHA全部匹配。完整清单见evidence/evidence-manifest.json、byte-verification.json；命令原stdout/stderr保留。

| 流 | 本角色选中原行 | source_size字节 |
|---|---:|---:|
{stream_table}

fight-plans在该固定截点选中0行，只表示本次截点与局号未选中，不断言原日志不存在。run-plans选中97行，使用其run身份；未覆盖或改写任何旧抽取报告。

53项材料断言首次通过，详见material-checks.json和原stdout/stderr。它们核实原帧数字与本报告限定结论，属于材料核对，不能当生产tsc/vitest或策略有效性测试。

## 六个有界离线消费者窗口

使用仓库既有learner/audit-selection.ts，冻结输入只移除agent_view并添加原_line/_source_sha256，未改原决策号、时间、fingerprint、尝试号；输入输出stderr逐SHA见audit-receipts.json。六次实际退出码均0，无重跑。窗口为RC61 F23/F33、XTSV F48/F49、BTSR F31、9Z9H F48、7X0 F31、MTQ0 F23。

| 局号 | 选线片段 | 决策动作 | 回合窗口 | 可核整轮端点 |
|---|---:|---:|---:|---:|
{audit_table}

总计261片段、769决策、138回合窗口，77个轮端点可核、61未知。全部完整候选结果保持null；工具设计不认证完整候选，所以不能把null计为候选未执行或失败。BTSR/7X0的尝试上下文未知，工具不连接后端点；另用已SHA核验的原状态描述局部观察，不补造sl_attempt。MTQ同类MYTE有两个，工具不认证敌实体端点；6敌血差只作为所列原帧的净差，不作跨帧实例因果。

## 关键结论与反例

1. RC61 F23T3：预判后柔嫩净敏1，速度药到6，后续实挡12、9、折扇4；T4原帧不再列临时力量/敏捷，柔嫩仍在。此窗口没有脆弱，不能补齐柔嫩×脆弱×倍率的联合校准。
2. BTSR F31T2：原题预计损4、伤13并杀丝，生存者后的实线跨轮35→21；覆甲3→2另计。旧弃牌问题已有实现，不将历史重复当新纯bug。F30胜战70→42，F31以42入场。
3. XTSV F48T8：仍有5能量及三张合法挡牌，毒胜前32→23，F49直接以23入场，前战能力不继承。F49T1幽灵实加无实体1、已有16挡不变，T2存活23且余挡10；末T4夜魇建3标记仍同轮死亡。早喝有已兑现效果，晚喝或禁夜魇能否改变整场未知。
4. 9Z9H F48：第二/三试T7同20HP、敌393，下一轮玩家9/11、敌344/322。整轮净损11/9、净扣49/71包含各次重问，不能替换原SL单题8/15及42/58预测。末试T8的11→0→20与整轮净+9分别保留；T10实际18→3，首题和least-loss是两题。T11敌112→32净扣80，与39+38=77及其余3分账；玩家3→0不提供完整未封顶入伤。
5. 7X0 F31T13：目标后段0→7毒，当步HP25与玩家1不变；结算后后段18，前段12→4，中段0→25重接。本样本只支持该组合与目标的实加总量，不能反推基础药效、对既有毒再加值、完整排序或药价。
6. MTQ0 F23T3：首三试29挡、零损，末试19挡、损8；已喝速度药的5敏捷没有第二次收益。两毒素共10与显示攻击17分列，末线敌净扣多6。四试属于一个相关局，原线也没有整场胜利，不能拟合新SL阈值。
7. 跨幕22对实际回复端点全部符合floor(缺失HP×80%)：A9五对、A10十七对，上限保持。act_id先在旧Boss层改变而HP未回，再接实际F18/F34回复帧，不能取act_id翻转当回血。9Z9H为24/70→60/70与23/77→66/77。逐对见act-heal-readback.json；未复算原116局资源预测或路线收益。

以上限定观察与原提案已有结论一致，没有本批新增机制反证或不同意见，也不以败局反驳局部机制。缺失后继、未选线、逐击与原dirty运行树继续写未知。

## 当前源码与实际live

源码材料固定于base，live观察提交`{source['live_observed']}`。16个相关叶11个逐字节相同，5个仅Roy/Dai历史注释字样差异；原差异完整保存在source-vs-live.patch，不改原文件、不借祖先关系冒称全部叶逐字节相等。所有16个live工作树叶与该live提交相同。

- 毒胜保血搜索和幽灵调用边界的现有叶来源：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`，已核实际live祖先。
- 脆弱下新敏捷差值的现有行来源：`1912b5e0c2c9d87622f6915d8a299f0ef6222588`，已核实际live祖先。
- 耳环未建模提示：`a78bb40ef73af8bb15f40f7fa302dd33a76c2907`，已核实际live祖先；提示不等于接管动作模型。
- 离线整轮观测工具来源：`e75438488df159b2e8e9d3458cf219b39aadd933`，已核实际live祖先；本批只执行有限窗口，不把其离线产出当自然消费者或完整模型校准。

完整路径、SHA及行来源见source-manifest.json、source-ancestor-readback.json。未使用当前源码重建历史+dirty完整树，也没有声称本批新实现上述功能。

## 逐项处置

| 提案ID | 状态 | 原因 |
|---|---|---|
{item_table}

各项完整账本ID、局/层/回合、原规则、反例、期望验证与回退见同目录proposal.md及原original-01.md至original-10.md。原提案Markdown的10个SHA全部与队列相符，不覆盖旧原文、不另建重复ID。46个既有账本仅经根ledger.py追加本批proposal路径和核查说明；不改claim/首证/prior/evidence/status/version、不登记shipped。实际CLI原输入/输出和字段保护核验见ledger-update*及ledger-protection.json。

## 验证、交付与限制

- fixes=[]，merged=null；无源码撤回/恢复实验，因本批没有源码增量；不冒造撤码失败。
- tests={{"tsc":null,"vitest":null,"cases":null}}。未跑生产测试，六次离线审计与53材料断言另列，不借旧树测试绿。
- code_proposals为原10个CLI ID；implementation_domains=[]，无新实现领域。无新commit、release_id、eval版本、规则上线通知或合入受阻。
- proposal绝对路径：{OUT / 'proposal.md'}。
- report绝对路径：{OUT / 'report.md'}。正式JSON另存result.json；最终HEAD与git状态见final-git-state.json。
- 本批只对这15局的原行、上述6窗口与22回复对进行限定核查，不声称原112/115/116/118局历史模型已重建、完整候选全部认证、后置盲测或收益成立。等待的是各项列明的机制共同校准/后继与独立数据，不将报告交付当经验入库、采用或父要求关闭。
"""
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-041302-strategy-proposal',
          'base': base, 'runs': batch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in assigned], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'proposal_results': len(results), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

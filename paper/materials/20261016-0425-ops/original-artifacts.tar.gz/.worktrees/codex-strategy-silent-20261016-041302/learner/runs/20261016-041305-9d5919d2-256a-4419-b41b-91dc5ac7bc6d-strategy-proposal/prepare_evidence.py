import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', OUT.parents[2] / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
runs = json.loads((OUT / 'verified-runs.json').read_text())
windows = {'RC61MFQM63Y6': [23, 33], 'XTSV1U9JD34T': [48, 49],
           'BTSRF7JL1W1Y': [31], '9Z9H2EXKLF3T': [48],
           '7X0W3U8TVA2A': [31], 'MTQ0EUBJ3R6T': [23]}
inputs = {rid: {'run': runs[rid], 'decisions': [], 'states': []} for rid in windows}
manifests = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
checks, summaries, exclusions, transitions = [], [], [], []
previous = {}

def powers(items):
    return {p['power_id']: p.get('amount') for p in items or []}

for manifest in manifests:
    stream = manifest['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    digest, counts = hashlib.sha256(), Counter()
    with path.open('rb') as evidence, (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for encoded in evidence:
            digest.update(encoded)
            item = json.loads(encoded)
            rid, row = item['run_id'], item['row']
            assert rid in runs and extract.run_identity(row) == rid
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == row
            counts[rid] += 1
            if stream == 'states':
                state = row['state']
                run, combat = state.get('run') or {}, state.get('combat') or {}
                player = combat.get('player') or {}
                assert run.get('character_id') == 'SILENT'
                assert run.get('ascension') == runs[rid]['ascension']
                summary = {'run_id': rid, 'line': item['line'], 'offset': item['offset'],
                           'sha256': item['sha256'], 'observed_ts': row.get('observed_ts'),
                           'floor': run.get('floor'), 'act': run.get('act_id'),
                           'turn': state.get('turn'), 'screen': state.get('screen'),
                           'hp': player.get('current_hp', run.get('current_hp')),
                           'max_hp': player.get('max_hp', run.get('max_hp')),
                           'block': player.get('block'), 'energy': player.get('energy'),
                           'powers': powers(player.get('powers')), 'potions': run.get('potions'),
                           'relics': [r.get('relic_id') for r in run.get('relics', [])],
                           'hand': [{'id': c.get('card_id'), 'index': c.get('index'),
                                     'upgraded': c.get('upgraded'), 'playable': c.get('playable'),
                                     'text': c.get('resolved_rules_text'),
                                     'values': {v['name']: v.get('current_value') for v in c.get('dynamic_values', [])}}
                                    for c in combat.get('hand', [])],
                           'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'),
                                        'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                                        'block': e.get('block'), 'alive': e.get('is_alive'),
                                        'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                                       for e in combat.get('enemies', [])]}
                summaries.append(summary)
                prior = previous.get(rid)
                if prior and prior['act'] is not None and summary['act'] is not None and prior['act'] != summary['act']:
                    transitions.append({'run_id': rid, 'ascension': runs[rid]['ascension'], 'before': prior, 'after': summary})
                previous[rid] = summary
            if stream in ('states', 'decisions') and rid in windows:
                floor = (row.get('state', {}).get('run') or {}).get('floor') if stream == 'states' else row.get('floor')
                if floor not in windows[rid]:
                    continue
                if stream == 'decisions' and not row.get('decision_id'):
                    exclusions.append({'run_id': rid, 'line': item['line'], 'sha256': item['sha256'],
                                       'label': row.get('label'), 'reason': '原行没有decision_id，保留原行号缺口，不重新编号'})
                    continue
                row['_line'], row['_source_sha256'] = item['line'], item['sha256']
                if stream == 'states':
                    row['state'].pop('agent_view', None)
                row.pop('agent_view', None)
                inputs[rid][stream].append(row)
    assert digest.hexdigest() == manifest['output_sha256']
    assert all(counts[rid] == n for rid, n in manifest['counts'].items())
    checks.append({'stream': stream, 'verified_rows': sum(counts.values()),
                   'source_size': manifest['source_size'], 'output_sha256': digest.hexdigest()})

with (OUT / 'state-summaries.jsonl').open('w') as handle:
    for summary in summaries:
        handle.write(json.dumps(summary, ensure_ascii=False) + '\n')
(OUT / 'byte-verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
(OUT / 'act-transitions.json').write_text(json.dumps(transitions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'audit-exclusions.json').write_text(json.dumps(exclusions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'audit-inputs').mkdir(exist_ok=True)
for rid, data in inputs.items():
    (OUT / 'audit-inputs' / (rid + '.json')).write_text(json.dumps(data, ensure_ascii=False) + '\n')
print(json.dumps({'verified_rows': checks, 'state_count': len(summaries),
                  'act_transition_count': len(transitions), 'audit_exclusions': exclusions,
                  'audit_windows': {rid: {'floors': windows[rid], 'decisions': len(data['decisions']),
                                         'states': len(data['states'])} for rid, data in inputs.items()}}, ensure_ascii=False))

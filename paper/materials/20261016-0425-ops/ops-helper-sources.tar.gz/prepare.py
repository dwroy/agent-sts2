from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0425';pub=root/'paper/materials/20261016-0425-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-041302-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-git-state.json');assert final['head']==report['base'] and final['status_porcelain']=='' and final['tracked_changes'] is False and final['result_validation'] and final['ledger_protection']
assert (s/'final.diff.patch').read_bytes()==b'' and final['diff_sha256']==sha(b'')
originals=load(s/'original-proposal-manifest.json');assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    original=Path(x['path']);copy=Path(x['copy']);assert original.is_relative_to(root) and copy.is_relative_to(s) and x['matches_queue']
    assert sha(copy.read_bytes())==x['sha256']
    if original.exists():assert sha(original.read_bytes())==x['sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');runs=load(s/'verified-runs.json');assert set(report['runs'])<=set(runs) and len(runs)==15 and all(x['character']=='SILENT' for x in runs.values())
assert collections.Counter(x['ascension'] for x in runs.values())=={9:3,10:12}
receipts=load(s/'audit-receipts.json');assert len(receipts)==6 and all(x['exit_code']==0 for x in receipts)
needed={stream:set() for stream in ['states','decisions']}
for x in receipts:
    input_path=Path(x['command'][-1]);assert input_path==s/'audit-inputs'/(x['run_id']+'.json')
    data=load(input_path)
    for stream in needed:needed[stream].update(row['_line'] for row in data[stream])
counts={};input_rows={stream:{} for stream in needed};manifest=load(s/'evidence/evidence-manifest.json')
for x in manifest:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in runs
            if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==runs[e['run_id']]['ascension']
            if x['stream']=='runs':assert row==runs[e['run_id']]
            if x['stream'] in needed and e['line'] in needed[x['stream']]:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==22424
for x in load(s/'byte-verification.json'):assert counts[x['stream']]==x['verified_rows']
facts=load(s/'material-checks.json');assert len(facts)==53 and all(x['passed'] and x['actual']==x['expected'] for x in facts) and (s/'material-checks.stderr.txt').read_bytes()==b''
heals=load(s/'act-heal-readback.json');assert len(heals)==22 and collections.Counter(x['ascension'] for x in heals)=={9:5,10:17} and all(x['matches'] and x['observed_gain']==x['expected_80_percent_missing'] for x in heals)
source=load(s/'source-manifest.json');assert source['base']==report['base'] and len(source['paths'])==16 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_observed']
for x in source['paths']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_observed']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_commit_sha256']==x['live_worktree_sha256'] and x['live_worktree_equals_live_commit'] and (root/'.worktrees/live'/x['path']).read_bytes()==z
    assert (a==z)==x['base_equals_live_commit'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['base_equals_live_commit'] for x in source['paths'])==11
for x in load(s/'source-ancestor-readback.json'):assert x['actual_live_ancestor'];git('merge-base','--is-ancestor',x['source_commit'],source['live_observed'])
totals=collections.Counter();summaries=[]
for x in receipts:
    input_path=Path(x['command'][-1]);output_path=s/('audit-'+x['run_id']+'.json');stderr=s/('audit-'+x['run_id']+'.stderr.txt')
    assert sha(input_path.read_bytes())==x['input_sha256'] and sha(output_path.read_bytes())==x['output_sha256'] and sha(stderr.read_bytes())==x['stderr_sha256']
    data=load(input_path);audit=load(output_path);assert data['run']==runs[x['run_id']]
    for stream in needed:
        for row in data[stream]:
            reference=input_rows[stream][row['_line']];assert reference['run']==x['run_id'] and row['_source_sha256']==reference['sha256']
            expected={**reference['row'],'_line':row['_line'],'_source_sha256':reference['sha256']};expected.pop('agent_view',None)
            if stream=='states':expected['state']={k:v for k,v in expected['state'].items() if k!='agent_view'}
            assert row==expected
    status=collections.Counter(row['status'] for row in audit['observed_turns']);assert all(row['actual_full_candidate_result'] is None for row in audit['segments'])
    c=dict(run=x['run_id'],segments=len(audit['segments']),actions=len(audit['observed_actions']),turns=len(audit['observed_turns']),turn_endpoints=status['observed_turn_endpoints'],turn_unknown=status['unknown']);totals.update({k:v for k,v in c.items() if k!='run'});summaries.append(c)
assert totals==dict(segments=261,actions=769,turns=138,turn_endpoints=77,turn_unknown=61) and load(s/'audit-exclusions.json')==[]
receipt=load(s/'ledger-update-receipt.json');protection=load(s/'ledger-protection.json');rows=load(s/'ledger-update-appends.json');inputs=[json.loads(line) for line in (s/'ledger-update-input.jsonl').read_text().splitlines()]
assert receipt['exit_code']==0 and len(rows)==len(inputs)==protection['own_appends']==46 and receipt['input_sha256']==sha((s/'ledger-update-input.jsonl').read_bytes())
assert set(receipt['ids'])==set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.stderr.txt').read_bytes()==b''
assert protection['prefix_preserved'] and all(x['non_trace_fields_unchanged'] and x['old_where_preserved'] and x['history_and_notes_prefix_preserved'] for x in protection['items']);own=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(receipt['before_size']))==receipt['before_sha256']==protection['prefix_sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        assert any(all(row.get(k)==v for k,v in item.items()) for item in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==46 and all(raw.rstrip(b'\n') not in set(old.splitlines()) for raw in own);added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
assert load(s/'gitleaks-receipt.json')['exit_code']==0 and load(s/'gitleaks.json')==[]
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,scratch_reason_abbreviation_only=True,original_gate=b['no_change_proposals'],native=native,original_final_git_state=final,original_proposals=originals,stream_counts=counts,original_rows_verified=22424,ascension_cohorts={9:3,10:12},material_assertions=53,original_act_heal_readback=heals,source=source,original_consumers=receipts,consumer_counts=dict(totals),consumer_summaries=summaries,owned_trace_rows=rows,protected_fields_and_prefixes_preserved=True,no_checks_reexecuted=True,limits=['A9 and A10 remain separate; same-run SL and abstract samples are not independent production results.','Six bounded windows and22 observed heal endpoints do not certify the original116-run resource model, whole candidates, controlled successors or strategy gains.','Enemy instance attribution, missing attempt context and uncapped incoming damage remain unknown.','No new counterevidence reported; existing f165/292f notice history and role acknowledgements are not altered.','Existing narrow live source does not close broad proposals; no source, merge, release, production tests, paper refresh or game action.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0425原041302策略done0/no-source核收，5b86基线干净WT/HEAD不变，十waiting具体缺口/testsnull/mergednull保持，无合入受阻。十五Silent A9三/A10十二，八流22424原行逐offset/bytes/SHA/JSON/显式身份核，不混进阶或SL独立样本；53原材料断言首次通过，六有界离线input/output/stderr SHA及原行去agent_view绑定核，261片段/769动作/138轮窗、77端点/61未知、完整候选全null，不当生产测试/自然消费者/策略收益。22跨幕回复端点按A9五/A10十七原样分列，不替代原116局资源模型、原dirty消费者或路线留药完整后继；同类实体、未知attempt及未封顶毛伤不补造。十六相关源码叶11同5历史Roy/Dai注释差及五真实live祖先核，窄功能不关闭组合要求。46所属CLI只where/note，原真实前缀/offset/SHA及私有fold核，旧claim/首证/prior/evidence/status/version和history/notes/where前缀保持，不重复CLI或重开旧f165/292f通知/代其他角色ACK；原scratch详细与最终短理由分列。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。仅本人记录/46追溯提交，保并行记录；不合入/发号/补测/刷新论文/复派/重启对局或变更账号home模型额度权限prompt，不关闭宽父。证据paper/materials/20261016-0425-ops/。\n'
note=f'\n- {at} [运维 codex] 原041302十项继续waiting，无源码修改或合入阻塞；22424原行、53原材料检查、六有界离线读回及46条所属追溯已核。缺失后继与宽父保持，不新增发布或补测。回执paper/materials/20261016-0425-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=46,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=22424,owned_trace_rows=46,ledger_check=0,paths=len(entries))))

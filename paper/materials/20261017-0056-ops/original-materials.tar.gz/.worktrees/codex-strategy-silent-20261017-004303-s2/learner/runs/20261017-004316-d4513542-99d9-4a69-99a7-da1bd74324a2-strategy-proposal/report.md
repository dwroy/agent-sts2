# 静默猎手策略批次回报

批次：20261017-004303-s2-strategy-proposal。base=345ef7a7099618af52a27a9ed5ffce6f9d6728dc。开工干净，git merge --no-edit main无变化。仅处理本批十个proposal_ids；无绑定专题/实现请求。十项全部waiting，完整局号/层/回合、29个既有账本id、旧新行为、反例、缺数据、验证与回退逐项见proposal.md和proposal-results.json。fixes=[]、merged=null，无源码提交、待合入补丁或新版本；未关闭父学习要求。

## 证据和结论

22个经runs.jsonl核角色的Silent局，10个派发锚点与12个原提案引用局分开：A1一/A5一/A6四/A7一/A8一/A10十四，不混角色/进阶，不把相关SL当独立局。八流38759原行已逐offset/bytes/SHA/JSON/显式身份核验；source_size和逐局计数在evidence/evidence-manifest.json，详细复核在provenance-verification.json。各流单独冻结边界，非全流同时快照；invalid计数是整源扫描统计，不归因本角色。fight-plans选中0仅表示该截点未选中。

八流选中内容的SHA和逐局计数与上一同范围批次全部相同，较新全源截点不增本范围样本。旧run-plans的8676775字节截点通过共用入口另存重提，154行及manifest与原件完全相同，没有覆盖旧产物或零行初稿。

PD9 F49末T10在生存者选择中31挡/三凋萎，完成弃牌后32挡/两凋萎，24持伤+23攻击−32挡需15HP，现有3HP仍死亡；250→244毒结算可核，不把12持伤差当实际多损12或修后必胜。L2 F17末T6七伤线五轮死亡14/24、结束11/24，三整场各1200样本零胜且侧步未知；末T8一牌后四牌hook阻止、17血对17攻击实死。ZTR初始324总敌血，退场后index重排，不能补造T6零血帧或稳定实例。GX四次SL的假inserted及战内版本变化可核，但缺改标/真插牌/洗牌及多副本消歧；PD9首王58→10、次王入口仍10和L2赢战44→24不提供未选路线或提前饮药的整战结果。材料19项算术/帧检查通过，只验材料，不是生产测试。

## 现有实现及消费者边界

冻结19源码叶，18叶与上一同范围批次相同；唯一变化是build-sim.ts已有F48 shadow日志接线，差分另存，不据此宣称真实接续资源已校准。live只读快照=5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922；17叶与该live HEAD相同，另两叶仅历史Roy/Dai署名注释差，精确补丁和SHA在source-readback.json。八个旧窄源码提交已核为本base和该live的真实祖先。

已有普通生存者单弃、护栏候选记录、同族当前快照、same_sample连续Boss原始资源诊断及离线观测，不能合并当作十个宽提案全部完成。尤其生成凋萎仍在终局聚合计数，跨重问实际归属、稳定敌实体、真实次战开场/奖励和联合生产校准仍缺。

四局旧离线消费者的输入/输出/stderr SHA及本WT对旧base的全部六个递归依赖已核相同；只复用旧产物，不重跑模型、消费者或模拟。覆盖2852状态、2696带ID动作、488片段、462轮窗，其中209个observed_turn_endpoints、253未知；六个原无ID元数据排除保留。完整候选结果在消费者契约中保留null，认证数0不能解释为实盘没有执行候选，也不能用动作completed或全轮HP差填原线因果结果。consumer-reuse.json和consumer-readback-counts.json保留精确路径/指纹与本次重计。

## 逐项处置和交付

十项具体缺口分别是：抑制身份消歧；复活逐击与药槽来源；凋萎生成及弃牌完成时点；跨重问控制/用药归属；侧步完整后继与终局取舍；十五机制联合消费者；双Boss真实开场/奖励及路线休息校准；有限全败对应原线的完整执行；同族稳定实例与构筑能力兑现；护栏完整链及受控整战后继。逐ID理由在proposal-results.json，保留waiting等待包含具体缺项的新局或补充证据，不新增重复提案或support/repeat。日志字段验收与胜率证明分开，未用缺反事实胜局阻止已有字段的记录验收。

本批仅经根learner/ledger.py update追加where/note追溯，不改原claim、首证、prior、evidence、status、version或shipped，不将旧shipped账本重置为proposed。输入、输出和保护核验另存；十个CLI提案id沿原记录，不调用add制造新id，不手改专用队列。

没有源码改动，撤源码失败/恢复通过、tsc/vitest/cases均为null；无代码提交、提交前gitleaks、live合入、版本或规则上线双通知，不借其他批次的绿。HEAD保持完整base，tracked/index/源码/知识干净；scratch保留全部原件与失败诊断。报告与proposal.md交原调度/运维验收，不代他人确认shipped或消费者实盘采用。

未派子agent，不运行play、不推送、不安装依赖、不读key/.env或游戏二进制。未改变其他角色行为、运维prompt或模型设置；原生模型/强度未独立核验。工具进入失败及路径探测记录见diagnostic-notes.md，没有新增科学冲突或异议结论。

最终验收：根ledger CLI exit0，29个既有条目的保护字段与原物理前缀均保留；本批源码/知识/index/工作树干净，HEAD仍为完整base。历史带dirty的完整运行源码和知识输入未复原，不把当前源码或有限叶SHA当作原运行树。final-readback.json及artifact-index.json保存验收和产物指纹。

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


checks = []


def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})


states = {}
decisions = {}
sl = {}
floor_edges = {}
dampen = collections.defaultdict(list)
provenance = []
targets = set(range(291336, 291344)) | set(range(291780, 291793))
targets |= {291553, 291554, 291562, 291602, 291611, 291761, 291770}
targets |= {292332, 292356, 292357, 292358, 292359, 292362, 292363, 292376, 292402}
decision_targets = {284707, 284708, 284709, 284710, 284711, 284918, 284967, 284971,
                    285020, 285024, 285073, 285077, 285126, 285130, 285148,
                    285155, 285156, 285157, 285301, 285405, 285745}


def power(rows):
    return {p['power_id']: p['amount'] for p in rows}


def compact(e):
    s = e['row']['state']
    r = s['run']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {
        'source': {k: e[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256')},
        'run_id': e['run_id'], 'floor': r['floor'], 'turn': s['turn'],
        'screen': s['screen'], 'in_combat': s['in_combat'],
        'hp': r['current_hp'], 'max_hp': r['max_hp'],
        'potions': [x.get('potion_id') for x in r.get('potions', [])],
        'block': p.get('block'), 'energy': p.get('energy'),
        'played': p.get('cards_played_this_turn'), 'powers': power(p.get('powers', [])),
        'enemies': [{
            'index': x.get('index'), 'id': x['enemy_id'], 'hp': x['current_hp'],
            'max_hp': x['max_hp'], 'powers': power(x.get('powers', [])),
            'attacks': [i.get('total_damage') for i in x.get('intents', []) if i.get('total_damage') is not None],
        } for x in c.get('enemies', [])],
        'hand': [{k: x.get(k) for k in ('index', 'card_id', 'upgraded', 'resolved_rules_text', 'playable', 'unplayable_reason')}
                 for x in c.get('hand', [])],
    }


for folder in ('evidence',):
    manifest = json.loads((OUT / folder / 'evidence-manifest.json').read_text())
    for stream in manifest:
        counts = collections.Counter()
        total = 0
        digest = hashlib.sha256()
        source = ROOT / 'logs' / (stream['stream'] + '.jsonl')
        with source.open('rb') as raw, (OUT / folder / (stream['stream'] + '.evidence.jsonl')).open('rb') as handle:
            for line in handle:
                digest.update(line)
                e = json.loads(line)
                raw.seek(e['offset'])
                original = raw.read(e['bytes'])
                assert hashlib.sha256(original).hexdigest() == e['sha256']
                assert json.loads(original) == e['row']
                assert extract.run_identity(e['row']) == e['run_id']
                counts[e['run_id']] += 1
                total += 1
                if stream['stream'] == 'states':
                    s = e['row']['state']
                    assert s['run']['character_id'].lower() == 'silent'
                    if e['line'] in targets:
                        states[e['line']] = compact(e)
                    if s['in_combat']:
                        key = (e['run_id'], s['run']['floor'])
                        if key not in floor_edges:
                            floor_edges[key] = {'first': compact(e)}
                        floor_edges[key]['last'] = compact(e)
                    if e['run_id'] == 'GXNKW8X1XYJP' and s['run']['floor'] == 45 and s['turn'] in (2, 3):
                        # Preserve version observations without claiming persistent card identity.
                        d = compact(e)
                        d['permanent_upgrades'] = [x['card_id'] for x in s['run'].get('deck', []) if x.get('upgraded')]
                        d['draw'] = (s.get('agent_view') or {}).get('combat', {}).get('draw', [])
                        dampen[str(s['turn'])].append(d)
                elif stream['stream'] == 'decisions' and e['line'] in decision_targets:
                    decisions[e['line']] = e
                elif stream['stream'] == 'sl-attempts' and e['run_id'] in ('GXNKW8X1XYJP', 'PD9AYQVMLQW6', 'L2TSFU62Z57Z', 'ZTRGYYMLR8SC'):
                    sl[e['line']] = e
        assert digest.hexdigest() == stream['output_sha256']
        assert all(counts[r] == n for r, n in stream['counts'].items())
        provenance.append({'folder': folder, 'stream': stream['stream'], 'source_size': stream['source_size'],
                           'verified_lines': total, 'counts': dict(counts), 'output_sha256': digest.hexdigest(),
                           'offset_bytes_sha_json_identity': True})

check('PD9初始3血8挡两张凋萎', states[291336]['hp'] == 3 and states[291336]['block'] == 8
      and len([c for c in states[291336]['hand'] if c['card_id'] == 'WITHER']) == 2)
check('PD9防御后18挡且门槛新增凋萎', states[291338]['block'] == 18
      and len([c for c in states[291338]['hand'] if c['card_id'] == 'WITHER']) == 3)
check('PD9生存者选择中31挡三凋萎', states[291340]['block'] == 31 and len(states[291340]['hand']) == 3)
check('PD9完成弃牌后32挡两凋萎', states[291341]['block'] == 32 and len(states[291341]['hand']) == 2
      and all('12' in c['resolved_rules_text'] for c in states[291341]['hand']))
check('PD9真实攻击23且3血实死', states[291341]['enemies'][0]['attacks'] == [23] and states[291342]['hp'] == 0)
check('PD9真实毒结算250到244', states[291341]['enemies'][0]['hp'] == 250 and states[291342]['enemies'][0]['hp'] == 244)
check('PD9算术总损15不冒称实际多损12', 24 + 23 - 32 == 15 and 3 - 15 == -12)
check('L2阈值前168血8力量', states[291780]['enemies'][0]['hp'] == 168
      and states[291780]['enemies'][0]['powers'].get('STRENGTH_POWER') == 8)
check('L2阈值后159血已清力量和横冲直撞', states[291781]['enemies'][0]['hp'] == 159
      and states[291781]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) == 0
      and states[291781]['enemies'][0]['powers'].get('PLOW_POWER', 0) == 0)
check('L2末T8一层昏眩', states[291790]['powers'].get('RINGING_POWER') == 1)
check('L2末T8实扣16', states[291790]['enemies'][0]['hp'] - states[291791]['enemies'][0]['hp'] == 16)
check('L2末T8四张牌被hook阻止', len(states[291791]['hand']) == 4
      and all(c['unplayable_reason'] == 'blocked_by_hook' for c in states[291791]['hand']))
check('L2末17血0挡对17攻击实死', states[291791]['hp'] == 17 and states[291791]['block'] == 0
      and states[291791]['enemies'][0]['attacks'] == [17] and states[291792]['hp'] == 0)
check('ZTR初始324总血含125信徒血', sum(e['hp'] for e in states[292332]['enemies']) == 324
      and sum(e['hp'] for e in states[292332]['enemies'] if e['id'] == 'KIN_FOLLOWER') == 125)
check('ZTR退场前index0仍有1HP', states[292362]['enemies'][0]['hp'] == 1)
check('ZTR退场后index0变为37HP63上限', states[292363]['enemies'][0]['hp'] == 37
      and states[292363]['enemies'][0]['max_hp'] == 63)
pd48 = floor_edges[('PD9AYQVMLQW6', 48)]
pd49 = floor_edges[('PD9AYQVMLQW6', 49)]
check('PD9首王58到10', pd48['first']['hp'] == 58 and pd48['last']['hp'] == 10)
check('PD9次王入口10无跨幕回复', pd49['first']['hp'] == 10)
check('L2F14赢战44到24', floor_edges[('L2TSFU62Z57Z', 14)]['first']['hp'] == 44
      and floor_edges[('L2TSFU62Z57Z', 14)]['last']['hp'] == 24)

save('provenance-verification.json', provenance)
save('keyframes.json', list(states.values()))
save('keydecisions.json', list(decisions.values()))
save('sl-selected.json', list(sl.values()))
save('dampen-version-frames.json', dampen)
save('floor-resource-edges.json', [{'run_id': k[0], 'floor': k[1], **v} for k, v in floor_edges.items()])
save('material-checks.json', {'checks': checks, 'passed': sum(x['passed'] for x in checks),
                             'total': len(checks), 'production_tests': False})
print(json.dumps({'verified_lines': sum(x['verified_lines'] for x in provenance),
                  'material_checks_passed': sum(x['passed'] for x in checks), 'material_checks_total': len(checks),
                  'failed': [x['name'] for x in checks if not x['passed']],
                  'decisions_found': len(decisions), 'dampen_frames': {k: len(v) for k, v in dampen.items()}}, ensure_ascii=False))
assert all(x['passed'] for x in checks)

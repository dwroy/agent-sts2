# 本批静默策略提案复核与处置

批次：20261016-213300-strategy-proposal；角色：silent；完整 base：32e47decdc3e706482f9c5ddeff77504c3f43d28。

结论：所派十项均 waiting，逐项理由见下文与 result.json。本批未定位新的可归责计算差额，完整候选执行归属、联合生产校准和受控整战后继仍未补齐。既有局部实现不代表整提案完成；本批没有源码、经验或知识改动，没有提交、合入、版本或 shipped。

## 身份和执行范围

开工 git status --short 为空，HEAD 为上述完整 base；按普通批次执行 git merge --no-edit main 后仍为同一提交。根 learn.json 本批 task/character/worktree/runs/十 proposal_ids 匹配；reason=proposal，不带 research_request、implementation_request、proposal_repair。普通专题根请求绑定另一旧批，本批不承接，不读取其他专题，不扩展队列。本次只沿用十个既有 CLI ID，没有新建重复提案、改写请求、派发状态或原提案。

十原 Markdown SHA256 全部匹配专用队列，并各保存 .original.txt；已读对应30条本角色账本及25个当前经验条目。保留原 claim、首证、支持分母、已上线状态及既有反例。游戏结论只用本角色对局和原复盘；未读取其他角色私有知识。六局由 runs 原行与 runs.jsonl 复核均为 SILENT/A10，版本均含 dirty；当前干净源码不能替代旧运行的完整源码、知识及移动表输入。

## 本批证据和源码核验

复用前批共用 extract_evidence.py 生成的八流冻结封套，本批重新逐行回原日志验证 source/offset/bytes/SHA256/JSON/显式身份，合计8274行：states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0。原封套位置、manifest SHA及本批核验索引见 evidence-reuse.json、evidence-verification.json、verified-evidence-index.jsonl。各流 source_size 与逐局计数保留；未重新扫描当前全历史，未将原冻结截点称本批最新全集。fight-plans零行仅是原截点未选到，不断言原日志缺失。

另外实际经本工作树共用入口以 --streams run-plans --source-size 8621197 另存 evidence-run-plans-prior-cutoff，选中33行、逐局6/7/2/6/7/5，输出SHA与原封套一致（1c08ff380911341c267f8174aa02424162052bef75087118833eaa4b1991f49b）。没有覆盖旧报告或零行初稿。身份解析使用 run/run_id/state.run_id/fingerprint.run，冲突身份不接收，正文提及不算所属局。

本批材料核验27项原帧/同指纹端点、6项候选数值和成功SL反例均通过；实际重新运行，原断言保留，脚本仅适配原封套读取路径，原字节和改动SHA见 material-helper-provenance.json。这33项是证据材料校验，未调用生产模拟器、LLM、网络或游戏，不能冒称生产测试、整候选完成或获胜反事实。

本批只读实际 live 快照 a0dcde7e6eaf30b3b3edab996a2c7408ab072ea9。相关19个源码叶中16个与前批基线逐字同；另外3叶为 rollout.ts 的 resourceAudit 和 combat-plan.ts/hand/loop.ts 的 sim-failures 诊断接线。新增诊断不能证明原候选完整执行、逐来源归属或联合模型校准已完成。当前base与该live快照14叶同字节，另5叶仅历史Roy/Dai署名注释差；差异保存 prior-base-source.patch、base-live-source.patch。引用的17个窄源码提交已逐一核为该真实live祖先，结果见 source-audit.json；这不证明全部知识与旧dirty运行一致。

monsterHpAt/moveDamageAt 当前进阶已有记录从第一样本直接读取；room-costs.MEASURED_ROOM_MIN_N 保持5。silent-selection-dispatch 仍明确 whole_plan_executed=null、actual_turn=null、state_effect_verified=false；resource_comparison 是 current_turn_prediction/execution=unverified；silent-phase-current 是本帧事实且 poison_damage_already_dealt=null。源码已具备部分事实记录，不能将这些未知字段认作已完成的执行/结算证据。

## 逐项提案

以下每项的本轮事实均由上述原流回验和固定材料校验确认；前批报告只作原任务与源码对照，不把前批的成功回执当本批测试。

## silent-proposal-c20b5139dd0dff71：感染棱柱：技能收益与污染血价

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；原Markdown SHA256：bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。

账本：silent-0168。证据局/层/回合：DUZUBAJ3A8GP F27 T4—T6；states 274830—274839。

本批核实：T4污染0/3/3/6；火花3→6后T5污染0/6/12/18，次轮清空。两轮实损3/9，敌本体净扣8/13。

旧规则及已有实现：求解器技能叠污染、推演增长及SL资源差已有路径；1698adc96ba434a46942321e0237b70657e625b2为实际live祖先。

处置：waiting。缺原dirty运行知识、实际移动表及火花增长/污染撤除/虚弱/毒/格挡的冻结联合生产校准；未定位新的可归责计算差额。

反例与限制：技能同时有毒或挡收益，实损9不支持强制少打技能；未执行另一线不当获胜反事实。

预期行为与验证：保留选项，逐击血价与毒/挡分列；固定同一生产源码、知识、移动表与实际前缀后，定位差额再修。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-ae9e692d680e3819：失落与遗忘：抢夺来源与返还

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；原Markdown SHA256：b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。

账本：silent-0183、silent-0005。证据局/层/回合：5PM6JAQG6FNQ F39 T2、T4—T6；states 274341/274351/274352/274354/274358/274362。

本批核实：玩家力敏−2/−2→−4/−4；两步法使敏捷−4→−2→0。失落退场后力量0，随后遗忘再抢到敏捷−2。

旧规则及已有实现：当前负力量/负敏捷已被求解和推演读取；当前值不等于逐来源累计及退场返还认证。

处置：waiting。缺稳定实体身份、逐来源抢夺/毒杀返还/再次抢夺的完整对账，另一杀序缺受控整战后继。

反例与限制：原末试只建立一次步法，返还后仍死亡；不能从端点规定固定击杀序。

预期行为与验证：按实体及代际记来源，不能把重排index当持续身份；固定累计和返还输入，杀序价值另验。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-52f1e1bd2e7db0ed：下水道蚌：当前进阶事实与加压

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；原Markdown SHA256：651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。

账本：silent-0231。证据局/层/回合：CA5KE8GFJ9X2 F13 T1—T5；states 273238/273247/273252/273254/273258/273263/273268。

本批核实：力量0/4/8，无弱攻击11/15/19，弱后15→11、19→14；轮初覆甲9/9/8/7/6。

旧规则及已有实现：monsterHpAt/moveDamageAt直接使用当前进阶已有记录，无五样本限制；room-costs.MEASURED_ROOM_MIN_N仍为5。4ed3c72df30f27b881da637aebf528b97440e0bb是实际live祖先。

处置：waiting。首样本接口已有实现；缺原实际移动表及加压、覆甲、虚弱的联合生产校准，未完整隔离覆甲减层条件。

反例与限制：现场覆甲序列不能证明全部减层条件；死亡截断实损不代替完整需损。

预期行为与验证：维持当前进阶首样本事实及房间代价五样本门槛，冻结原输入后逐步校准，不补未观察规则。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-6dd8bbff876be528：电击机器人：高电压与召唤身份

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；原Markdown SHA256：48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。

账本：silent-0233、silent-0209。证据局/层/回合：5PM6JAQG6FNQ F38 T3/T4；states 274308/274312/274313。

本批核实：23上限电击的索引4→3，力量2→4、意图17→19；T3仍贡献17攻击。

旧规则及已有实现：HIGH_VOLTAGE_POWER在增长路径中，新实体有初始化路径；f3dea91880600bc2e7228268a110a644531738f7为实际live祖先。

处置：waiting。缺稳定召唤代际身份、原A10移动表及跨代重置联合校准；先杀爪牙的未执行线缺完整后继。

反例与限制：同类型、同血量上限和index重排不能独立证明实体连续；35伤/损3候选未实打。

预期行为与验证：固定召唤、退场、再召唤身份与移动表后核增长/重置，不据候选击杀预记实际退场。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-578e415a259e6835：沙虫：SL血价、HP护栏与能力兑现

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；原Markdown SHA256：e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。

账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。证据局/层/回合：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；decisions 270216/270282/270264。

本批核实：首/第三试T2完整指纹相同：实损3→15，净扣10→17；候选死亡0/24与5/24，预计后损都47，不能称同死率。

旧规则及已有实现：66283dd9982bdd7f480da7a4d9bfefea0572a9ac有候选/护栏审计；1698adc扩资源差；bade647f9fe4c9103b40e2f26b26296692ad24b7及fdaf787a372880b0438e73bcac7e6d2168b038ed有单动作回执，均已核实际live祖先。

处置：waiting。缺跨抽弃、生成、用药与重问的整候选连续归属、逐来源能力兑现及联合资源消费者；单动作回执不足证明整候选完成。

反例与限制：原末次更防御线延至T11仍败；候选省血与重规划后实际省血不同。

预期行为与验证：分列原答、护栏、SL替换、单步派发与结算；先核连续归属和真实资源链，不设新探索系数。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-c0767768bf6a7ab1：实验体：全败SL及续步截断

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；原Markdown SHA256：28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。

账本：silent-0079。证据局/层/回合：YF0LXT1QSTGG F48第二/第三试T1；decisions 271309/271348/271354，states 277327—277373。

本批核实：两题完整指纹相同，实损0→9、净扣45→38；候选均24/24死。271354实际end_turn，原候选数字损0/10、伤54/36单列。

旧规则及已有实现：SL资源差明确是current_turn_prediction、execution=unverified；单动作回执whole_plan_executed=null。

处置：waiting。缺截断续步的完整执行归属、同抽序后轮及受控获胜后继；全败并列不足拟血价惩罚或禁止探索。

反例与限制：同局F33成功SL后奖励帧20血已核；F48失败不否定全部SL。原第四试弃牌后未完成候选的反例保留。

预期行为与验证：核同题预测与实际端点、覆盖重放和未完成续步；不把有限样本同败称安全，不改探索门槛。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-a46bdb7fe711d79a：实验体：阶段、毒与敏捷取得时点

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；原Markdown SHA256：eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。

账本：silent-0021、silent-0027、silent-0028、silent-0085。证据局/层/回合：YF0LXT1QSTGG F48末试T3—T5；states 277512/277513/277519/277524/277526/277527。

本批核实：阶段4血4毒/111上限→212血212上限/零毒；触媒2而毒0；敏捷5→6时现有挡仍23。末轮净扣37，18血对44−23需21，差3。

旧规则及已有实现：silent-phase-current分列当前能力、持有组件和毒；8698c581dac6c7e957f50a381586960a6d0c9b57及aad2700abed6dff1d66e87fb36aaa6fedb39adf3为实际live祖先。

处置：waiting。缺跨阶段整候选执行、逐来源施毒/结算及敏捷取得顺序的联合生产校准；当前快照不足认证后继收益。

反例与限制：前五试建过毒雾或余像仍败；不能将零毒作为唯一死因或强制能力先手。

预期行为与验证：阶段变化重读现场，不预支未建能力或零毒触媒收益，不把后得敏捷倒补既有挡；冻结建立和结算时点验证。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-1044224808015e5c：双蟹：B2零胜并列与实付血价

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；原Markdown SHA256：4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。

账本：silent-0079。证据局/层/回合：XP2SL33HT0D9 F33首/末T1、首/第二T3及第三T4；decisions 271982/272195/271992/272040/272076。

本批核实：T1同指纹实损2→10、净扣25→34；T3同指纹实损9→14、净扣24→27。272076两线B2均0，五轮死亡21/24→23/24为候选事实。

旧规则及已有实现：已有候选审计、当轮资源差及单动作回执；窄源实际live祖先见source-audit.json。

处置：waiting。缺同抽序、药瓶随机落点后继、成长兑现及受控整战比较；零胜并列和当轮血价不足拟新探索门槛。

反例与限制：付血伴随手里剑成长；末试T2零损及T3保挡构成限制，不能仅按挡牌数量判错。

预期行为与验证：成对报告HP、输出、成长与采样；按独立run/时间后移验证，相同存档六试不充六局，不拟全局血伤常数。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-7cbc6005db712ba9：双蟹：朝向、临时减力与轮初格挡

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；原Markdown SHA256：f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。

账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。证据局/层/回合：XP2SL33HT0D9 F33末试T2/T4/T5；states 278236/278237/278240/278242/278249/278252/278253/278255/278260/278261。

本批核实：14挡加斗篷到20；镣铐力0→−9→0；激光57→转向38→弱28；四敏脆弱时6挡；末轮毒扣3+7且玩家归零。

旧规则及已有实现：passive-pieces有HORN_CLEAT_BLOCK=14、T2；临减/恢复/朝向/弱已有求解与推演路径，实际源码与祖先范围见source-audit.json。

处置：waiting。缺全部修饰组合的冻结生产回放、抽弃后的整候选执行及未选后继；已有窄覆盖不等于全部组合校准。

反例与限制：临减次轮恢复；已建能力仍无减员，不外推未见叠层或固定目标顺序。

预期行为与验证：朝向、弱、临减、轮初挡按来源及先后分别对账，冻结组合输入；保留排名、HP护栏与能力权重。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## silent-proposal-c59f592f1427a67e：综合机制：联合资源消费者

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；原Markdown SHA256：81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。

账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。证据局/层/回合：YF0LXT1QSTGG F48、XP2SL33HT0D9 F33及本批另四局上述锚点。

本批核实：六局A10身份和四组同指纹当轮配对已核；六锚点不等于原101局/1499房历史全量重建。

旧规则及已有实现：候选、护栏、阶段快照和单动作回执已有局部覆盖，未证明逐来源联合资源消费全部闭合。

处置：waiting。六局不能替代原101局联合资源重建；完整候选、路线、休息、实际用药及SL恢复的逐来源联合消费仍缺。

反例与限制：SL恢复不是回血；候选省血不是实际收益；持有组件不是已施放。原历史分母保留，不充本批重算。

预期行为与验证：按原范围逐run核资源与归属，分别验证观察事实和受控后继；不关闭量化、联合消费者和学习入库父要求。

样本及回退：同局SL尝试相关，不能跨训练/验证集合；后移独立局再验。确定计算误差可在冻结原输入上验证，不以获胜反事实作为修纯计算错误的前提。本批没有生产修改；未来变更须固定夹具撤源码失败/恢复通过，自测与实际live合入后记录版本及回退提交。

## 验证、限制及交付

本批没有生产修改，撤源码失败/恢复通过不适用且未运行；tsc/vitest/cases 均为 null，不写成功0。fixes=[]、merged=null，无源码提交、live知识刷新、eval版本、规则双通知或运维shipped。implementation_domains=[]表示本批没有实际代码实现；十原提案领域仍按原队列保留。未向其他角色发送消息，最终报告和 proposal_results 由原调度器接收，不把排队当送达。

计算差额与策略价值分开验收：确定的计算错误可在冻结原输入上定位和验证，无须把受控获胜后继当作修纯计算错误的前置；本批未定位这种新差额。更改探索、杀序或成长权重则缺同抽序/相同资源的完整后继及独立时间后移验证。不能由全败/饱和数字拟合全局血价系数，不能以本批六锚点替原101局/1499房完整重建。SL恢复、回血、实际用药、弃药与未发生的留药价值继续分账；普通机制现场支持不等于所有组合或未观察进阶策略已证。

账本只经根 learner/ledger.py update 为30个既有角色条目追加本批 proposal/report where 和 waiting 处置 note，by=learner:strategy-proposal；不重复 support/repeat，不改 claim、first_run、prior、evidence、status、版本或 shipped，保留既有 proposed/shipped。CLI输入、退出码、逐物理追加回执及受保护字段前后对账保存在本目录。本批没有新的机制反证或与旧知识冲突，不关闭原学习入库、量化或联合消费者父要求。

首次只读定位用了不存在的 monster-models.ts，随后用 rg 定位实际 monster-db.ts，不当产品故障；大段控制台输出截断后已分段读取原提案和账本claim，未改原材料。未独立核实际原生模型、推理强度及服务档，不以任务文本冒称运行切换，未改账号、模型、权限或prompt。

交运维：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-213300/learner/runs/20261016-213306-ccba94a9-0fb3-4e6d-849b-03da9bd5d125-strategy-proposal/proposal.md；完整报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-213300/learner/runs/20261016-213306-ccba94a9-0fb3-4e6d-849b-03da9bd5d125-strategy-proposal/report.md；机器处置：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-213300/learner/runs/20261016-213306-ccba94a9-0fb3-4e6d-849b-03da9bd5d125-strategy-proposal/result.json。本工作树保持上述完整 base，无需兜底提交或合入；最后完整性和保密扫描另见 final-integrity.json 与 gitleaks.log。

最终核验：HEAD=base、工作树及索引干净，十原提案SHA/派发身份和19源码叶仍匹配；8274原行、33材料检查和30条仅where/note账本CLI均核验通过；gitleaks退出0/零发现。生产测试仍为null，无提交、合入或版本。

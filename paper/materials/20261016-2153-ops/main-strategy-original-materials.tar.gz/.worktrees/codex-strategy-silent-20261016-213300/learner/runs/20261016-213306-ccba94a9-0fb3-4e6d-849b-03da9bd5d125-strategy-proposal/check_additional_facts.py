import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
decisions = json.loads((OUT / 'fixed-decisions.json').read_text())
checks = []


def check(name, observed, expected, lines):
    assert observed == expected, (name, observed, expected)
    checks.append({'check': name, 'observed': observed, 'evidence_lines': lines})


for line, expected in [
    ('270282', ['rollout dead 0/24, further loss 47, win ~36%; whole-fight sim win 0%; this turn hp -3, dmg 10',
                'rollout dead 5/24, further loss 47, win ~22%; whole-fight sim win 0%; this turn hp -15, dmg 17']),
    ('271348', ['rollout dead 24/24, further loss 27, win ~0%; whole-fight sim win 0%; this turn hp -0, dmg 54',
                'rollout dead 24/24, further loss 27, win ~0%; whole-fight sim win 0%; this turn hp -10, dmg 36']),
    ('272076', ['rollout dead 21/24, further loss 36, win ~0%; whole-fight sim win 0%; this turn hp -8, dmg 11',
                'rollout dead 23/24, further loss 36, win ~0%; whole-fight sim win 0%; this turn hp -16, dmg 23']),
]:
    numbers = decisions[line]['sl_explore']['numbers']
    check('原始候选数值独立于实打端点' + line, [numbers['original'], numbers['replacement']], expected, [int(line)])
check('双蟹B2零胜并列', decisions['272076']['sl_explore']['b2'], {'original': 0, 'replacement': 0, 'diff': 0, 'se': 0}, [272076])
check('实验体续步后结束回合', decisions['271354']['chosen'], {'action': 'end_turn'}, [271354])
counterexample = []
for line in (Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-191302-s2/learner/runs/20261016-191310-af808c4a-983a-45c8-8512-08969ae79344-strategy-proposal/evidence/states.evidence.jsonl')).open():
    e = json.loads(line)
    if e['line'] in range(277086, 277091):
        state = e['row']['state']
        assert e['run_id'] == 'YF0LXT1QSTGG'
        assert state['screen'] == 'REWARD' and state['run']['floor'] == 33 and state['run']['current_hp'] == 20
        counterexample.append(e)
check('同局F33成功SL的奖励帧', len(counterexample), 5, list(range(277086, 277091)))
(OUT / 'success-sl-counterexample.json').write_text(json.dumps(counterexample, ensure_ascii=False, indent=2) + '\n')
(OUT / 'additional-facts-verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'additional_material_checks': len(checks), 'scope': '原候选文字与已核原帧；不是生产测试或获胜反事实'}, ensure_ascii=False))

import json
from pathlib import Path

S = Path(__file__).resolve().parent
dispatch = json.loads((S / 'dispatch.json').read_text())
proposals = json.loads((S / 'dispatched-proposals.json').read_text())
source = json.loads((S / 'source-audit.json').read_text())
verification = json.loads((S / 'evidence-verification.json').read_text())
ledger = json.loads((S / 'ledger-selected-before.json').read_text())
history = json.loads((S / 'proposal-history.json').read_text())
ids = dispatch['proposal_ids']
reasons = {i: history[i][-1]['reason'] for i in ids}
anchors = [
    '751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820',
    '751FN9QM9MHQ F13 T3；d272361/272362；F17 T7/T13/T17',
    '751FN9QM9MHQ F17 T2/T7/T13；同366288原始帧',
    '751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17',
    'KV0JHNJCKXLS F33 第4/5试T5；s279460—279465、279511—279515；末试T4 s279559/279560',
    'YQL8RZ8BWN1E F17 T10 s280160/280161；L9SGRBB5R698 F17 T14 sl681；PU80F84P6HPN F17 T17 sl717',
    'YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 s252435/252436',
    'KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；d274131/274156/274185/274235/274237/274267/274272',
    'KEN58SH9SLZ6 F17 第4/5试T10 d274505/274568；第4/6试T5 d274484/274601',
    'KEN58SH9SLZ6 F17 T2/T5/T10；d274354/274484/274601/274505/274568',
]
table = '| 原CLI id | 核实证据局／层／回合／原行 | 原账本 | 处置与具体缺口 |\n|---|---|---|---|\n'
for i, anchor in zip(ids, anchors):
    table += f"| {i} | {anchor} | {'、'.join(proposals[i]['ledger'])} | waiting：{reasons[i]} |\n"

proposal = f'''# 本批十项原提案的证据复核与处置

批次：20261016-213300-s2-strategy-proposal。角色：silent；六个派发锚点均已由runs.jsonl核为A10。
来源任务沿各原提案的postmortem／experience-update，当前实现任务strategy-proposal。授权沿Roy-2026-10-07-learning，授权不构成游戏事实。仅处理dispatch.json内十个原CLI id，不领取其他提案，不新建重复id。

本次没有足够证据提出新的策略参数或修改源码，十项继续waiting。以下每项保留原Markdown及原SHA；*.original.md是原字节副本，dispatched-proposals.json保留原角色、证据局、账本、经验链接及提案指纹。原提案的完整旧／新行为、拟合限制和回退不改写。

{table}

## 当前行为与预期行为

当前资源比较只报告current_turn_prediction和execution=unverified；持牌提示actual_held_hp_loss=null；药水持有价缺失保持hold_hp=null并展示同题无药模型参考；单动作回执whole_plan_executed=null。巨兽本体／自爆和毒药局部事实已有实现，SL anchorRank仍按存活回合、原始enemyHpLeft等排序。这些部分实现不能关闭完整提案。

待验证的行为是把原答、护栏／SL后候选、抽弃牌／随机选牌／重问及实际续步连成可核的执行链，并分开本体输出、已结毒／荆棘、持牌失血、敌回血与能力建立时点。只有联合结算和完整后继足以支持时，才改本角色策略；本批不设5/10血、6血/2伤或固定留药门槛，不改变候选集合或现有规则。

## 支持、反例、未知与验证

751 F17同盘T2实净损13→18、敌净扣9→18；T7实净损13→23、敌净扣12→18；T13实净损8→2、敌净扣17→11。不同方向的取舍不支持单一血价阈值，六试不是六个独立局。

KV F33第4/5试T5双方都零净损，敌净扣36/29，后帧毒20/13；删毒不能称为已证保血。末试s279559→279560由327/15毒到342/14毒，毒结算与回血需分账；缺独立内部帧时不能把残差当直接观测的毛伤或回血来源。

YQL s280160/280161的毒2→8、血26／挡13／自爆41不变；只证明该次局部观测，提前喝、不喝和留药的完整支线未知。PU s252435为24血20挡对42，s252436奖励页余2血，证明本体结束后仍需覆盖自爆；不能用阶段标识当整场胜利。

KEN F17第4/5试T10同盘实净损15/21、敌净扣2/4；第4/6试T5同盘实净损7/5、敌净扣1/2，但末试敏捷直到T9建立，T8双防御各5。后一案例是反对“只省血就更好”的证据。七次药栏有药→空可核，其中d274131/274237/274272接口回执仍pending；不把槽位变化或单动作completed认证为整条候选兑现。

本批八流8444封套逐行核原始offset/bytes/SHA/JSON与显式身份；关键43状态、21决策原封套和29项材料核验另存。验证产物见evidence-verification.json、state-anchors.json、decision-anchors.json、sl-anchors.json、turn-endpoints.json、material-checks.json。它们是材料核验，不是生产测试、整战模拟或完整候选认证。

后续验证使用原始指纹与动作边界，先确认抽弃／重问后的实际分支，再核逐来源结算和保持后轮条件的完整对照；模拟结果与实际观测分列。若拟合参数，按独立局真实时间切分调参与留出，不把同局SL分进不同样本集。本批锚点均旧局，不能冒充未来新局验证。

预期影响：补足上述缺口后才有依据评估规则收益；本次不宣称胜率改善。回退：本批无源码／知识变更，无行为回退项；保留所有原提案、失败记录和缺数据。其他角色保持等价。
'''
(S / 'proposal.md').write_text(proposal)

counts = {v['stream']: v for v in verification['streams']}
count_table = '| 局号 | states | decisions | SL行 | run-plans |\n|---|---:|---:|---:|---:|\n'
for run in dispatch['runs']:
    count_table += '| ' + run + ' | ' + ' | '.join(str(counts[k]['counts'][run]) for k in ['states', 'decisions', 'sl-attempts', 'run-plans']) + ' |\n'
partial_table = '| 已有局部功能 | 实际live祖先源码提交 |\n|---|---|\n'
for row in source['files']:
    if row['path'] in [
        'agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/reflex/silent-held-loss.ts',
        'agent/src/reflex/silent-potion-reference.ts', 'agent/src/reflex/silent-giant-potion.ts',
        'agent/src/reflex/silent-selection-dispatch.ts', 'agent/src/sl/attempts.ts',
    ]:
        partial_table += f"| {row['path']} | {row['last_source_commit']} |\n"

report = f'''# 策略提案消费报告：20261016-213300-s2-strategy-proposal

结论：十个派发提案全部waiting，缺口逐项列明。已存在的诊断子项不重复实现，也不据其关闭完整策略要求。本批无生产源码或知识变化，无提交、合入、版本或shipped登记；fixes=[]、merged=null，tsc/vitest/cases均null。

## 身份、运行参数与基线

开工git status为空。初始HEAD={source['base']}；普通任务按要求执行git merge --no-edit main，返回Already up to date，report.base仍为完整40位{source['base']}。

只读根learn.json本批行，task=strategy-proposal、character=silent、reason=proposal，工作树与六个runs精确匹配，十proposal_ids无重复且已全部处理；无research_request、implementation_request或proposal_repair。普通专题请求绑定另一批，不适用本树，未读其work_spec或其他专题来替代身份。未修改learn.json、根专题请求、旧提案或调度状态。

runtime-launch-audit.json记录本批启动器实际参数：gpt-6.1-sol、xhigh、default；任务正文要求普通/high，启动器传入的推理强度与文字不同。这里只核了启动器参数，没有独立核到本原生请求的模型／强度／服务档；未借默认配置冒称已核运行身份，未改账号、配置或原线程。全程独立完成，没有派子agent、联网、调用LLM／游戏API、运行play或模拟池。

## 原始证据与范围

六局由runs.jsonl核为SILENT A10，原+dirty源码标识和各自大脑来源保持，不假称复原当时完整运行树，不把混合／未知来源用于纯Codex爬塔战绩。只读取本角色证据、关联复盘及knowledge/characters/silent；不读取其他角色知识。

实际使用共用learner/extract_evidence.py，对本批六局提取states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流。每流source_size、输出SHA、每行原offset/bytes/SHA及计数保存于evidence/；8444封套全部重新seek原日志核字节、SHA、JSON和显式局号。run-plans的run、其他流run_id/state.run_id/fingerprint.run按共同入口识别，冲突拒收，不以正文提及认领局号。verification.stdout.txt和evidence-verification.json保存实际退出0及结果。

{count_table}

六主流8438行、runs另6行，fight-plans在本次冻结截点的六局显式身份匹配均0。这只说明该截点没有选中行，不推断原日志缺失，更不据此断言没有完整执行。全源states/decisions各2个invalid、brain1个invalid，所有流incomplete=0；这些全源计数不直接变成本批缺帧结论。没有覆盖旧截点、零行初稿或原报告。

## 逐项结果与证据结论

十份原Markdown的SHA与专用队列add指纹均一致；原件副本、原队列历史和16个既有本角色账本快照保留。所有局号／层／回合／账本及具体waiting原因如下。

{table}

具体支持、反例、预期行为、未知、时间切分及后续验证方案见同目录proposal.md。已直接核对751三组同盘净差、KV净扣及回血窗口、YQL残壳毒2→8而41自爆不变、PU实际过爆余2血、KEN两组双向取舍和七次药栏消耗。29项原始材料断言通过，不等同生产测试或策略校准通过。没有得到保持其余后轮条件的整战受控胜线，未拟合探索、药水或终局新阈值。

本轮结论延续原提案的限定观察，没有新机制异议或与旧知识相反而尚未通知的发现。反例和未知保留；不能把“未证更好”写成“已证更差”，不能把一局多试当独立验证局。

## 当前源码及消费者边界

只读live截点={source['live_snapshot']}。15个相关源码叶的最近源码commit均是该live祖先，live工作文件与该提交相同；12叶与本树字节相同，potion-cost.ts、sl/explore.ts、sl/controller.ts仅已有Roy/Dai注释署名差。逐叶SHA与祖先关系见source-audit.json，精确差分见base-live-source.patch。此检查不推定整个仓库或刷新知识均相同。

{partial_table}

资源比较仍是current_turn_prediction/execution=unverified，actual_held_hp_loss与whole_plan_executed仍null。阶段说明不等于参考排序已改；anchorRank仍调用enemyHpLeft的原始显示HP。离线audit-selection消费者源码明确不认证actual_full_candidate_result／actual_rollout_best；相邻观测净差不能替代逐来源因果或整条候选收益。本批没有再次运行消费者或模型，没有把旧产物、源码存在或单动作回执冒称自然读回成功。

## 验证与交付

没有生产源码变动，因此未撤源码／恢复、未跑生产tsc/vitest或整战模拟，tests固定为tsc=null、vitest=null、cases=null。没有源码提交，不需要代码提交前完整测试；没有本批合入，未执行live合并、发布编号或实际上线双通知，不登记implemented/duplicate/shipped。其他角色和所有现行规则保持等价。

只经根learner/ledger.py update为16个旧账本追加本批proposal/report去处及逐项waiting备注，by=learner:strategy-proposal；不把旧shipped状态改为proposed，不重复追加旧support/repeat，不改claim、首证、prior、旧evidence、version或shipped历史。不新建代码提案id，code_proposals为本批十个原CLI id，implementation_domains=[]。

交付路径为本目录proposal.md、report.md、result.json。最终账本CLI实录／物理读回、保护字段核验、gitleaks及HEAD／index／工作树检查保存于ledger-update.stdout.txt、ledger-readback.json、gitleaks.stdout.txt和completion-check.json；这些材料核验不替代生产测试。后续只在有足够具体新证据时重审waiting项，原报告和失败历史保持。
'''
(S / 'report.md').write_text(report)

updates = []
for ident, entry in sorted(ledger.items()):
    related = [i for i in ids if ident in proposals[i]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
                    'note': '20261016-213300-s2-strategy-proposal复核；' + '；'.join(i + ' waiting：' + reasons[i] for i in related)
                            + '。八流8444原封套核验、29项材料核验；无源码/知识/生产测试/合入，不改原claim、证据和发布状态。'})
(S / 'ledger-updates.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in updates))
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-213300-s2-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': ids,
          'implementation_domains': [], 'proposal_results': [{'id': i, 'state': 'waiting', 'reason': reasons[i]} for i in ids],
          'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'proposal_results': len(ids), 'ledger_updates': len(updates)}, ensure_ascii=False))

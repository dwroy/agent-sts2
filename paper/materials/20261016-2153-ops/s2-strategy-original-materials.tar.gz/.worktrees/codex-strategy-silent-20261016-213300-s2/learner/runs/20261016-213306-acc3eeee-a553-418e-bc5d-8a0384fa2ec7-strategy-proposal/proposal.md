# 本批十项原提案的证据复核与处置

批次：20261016-213300-s2-strategy-proposal。角色：silent；六个派发锚点均已由runs.jsonl核为A10。
来源任务沿各原提案的postmortem／experience-update，当前实现任务strategy-proposal。授权沿Roy-2026-10-07-learning，授权不构成游戏事实。仅处理dispatch.json内十个原CLI id，不领取其他提案，不新建重复id。

本次没有足够证据提出新的策略参数或修改源码，十项继续waiting。以下每项保留原Markdown及原SHA；*.original.md是原字节副本，dispatched-proposals.json保留原角色、证据局、账本、经验链接及提案指纹。原提案的完整旧／新行为、拟合限制和回退不改写。

| 原CLI id | 核实证据局／层／回合／原行 | 原账本 | 处置与具体缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820 | silent-0079、silent-0176 | waiting：缺抽弃与重问后的完整候选身份、逐来源结算和保持后轮条件的整战对照；现有资源比较仅预测，单动作回执不认证完整执行。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3；d272361/272362；F17 T7/T13/T17 | silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176 | waiting：持牌未决与持药未知已有窄实现；缺F13不饮药的完整实际后继及留药后战对照，无法拟合持有价或更改用药规则。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13；同366288原始帧 | silent-0079、silent-0176 | waiting：与366288共享一局六试；缺完整候选归属、受控后继与独立验证，不能把5/10血局部差额拟成探索门槛。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17 | silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176 | waiting：分项模型和未知值提示已有实现；缺攻击、毒、荆棘、持牌失血、敏捷的联合逐来源实结算校准及跨战用药对照。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 第4/5试T5；s279460—279465、279511—279515；末试T4 s279559/279560 | silent-0102、silent-0019、silent-0020 | waiting：同盘净扣敌36/29、双方零净损及次轮毒20/13可核；缺毛伤/回血逐来源归属和路线休息替代后继，删毒不构成已证保血。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T10 s280160/280161；L9SGRBB5R698 F17 T14 sl681；PU80F84P6HPN F17 T17 sl717 | silent-0017、silent-0250、silent-0011、silent-0027、silent-0046 | waiting：阶段与残壳饮毒事实已有实现，参考路径仍沿原始显示HP平局排序；缺新旧改序的完整后继及提前喝/不喝/留药受控分支。 |
| silent-proposal-9733bb80f445aeae | YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 s252435/252436 | silent-0017、silent-0019、silent-0020、silent-0250 | waiting：残壳毒2→8未改变41自爆，PU实际余2血胜可核；缺完整阶段估值、排序与用药时点的受控后继，局部阶段说明不关闭整项。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；d274131/274156/274185/274235/274237/274267/274272 | silent-0019 | waiting：七次请求和药栏消耗可核，三次接口回执仍pending；缺随机选牌、发光水后重问的完整执行收益与保留至Boss对照。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 第4/5试T10 d274505/274568；第4/6试T5 d274484/274601 | silent-0079、silent-0021、silent-0125、silent-0005、silent-0176 | waiting：T10多2敌净损付6血、T5省2血却延后敏捷是双向取舍；缺逐来源兑现、保持后轮条件的对照和时间靠后的独立验证。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T2/T5/T10；d274354/274484/274601/274505/274568 | silent-0021、silent-0079、silent-0125、silent-0176 | waiting：血价、无实体与能力窗口证据可核；现有预测及端点工具不认证完整候选，缺受控后继，不拟统一6血/2伤准入阈值。 |


## 当前行为与预期行为

当前资源比较只报告current_turn_prediction和execution=unverified；持牌提示actual_held_hp_loss=null；药水持有价缺失保持hold_hp=null并展示同题无药模型参考；单动作回执whole_plan_executed=null。巨兽本体／自爆和毒药局部事实已有实现，SL anchorRank仍按存活回合、原始enemyHpLeft等排序。这些部分实现不能关闭完整提案。

待验证的行为是把原答、护栏／SL后候选、抽弃牌／随机选牌／重问及实际续步连成可核的执行链，并分开本体输出、已结毒／荆棘、持牌失血、敌回血与能力建立时点。只有联合结算和完整后继足以支持时，才改本角色策略；本批不设5/10血、6血/2伤或固定留药门槛，不改变候选集合或现有规则。

## 支持、反例、未知与验证

751 F17同盘T2实净损13→18、敌净扣9→18；T7实净损13→23、敌净扣12→18；T13实净损8→2、敌净扣17→11。不同方向的取舍不支持单一血价阈值，六试不是六个独立局。

KV F33第4/5试T5双方都零净损，敌净扣36/29，后帧毒20/13；删毒不能称为已证保血。末试s279559→279560由327/15毒到342/14毒，毒结算与回血需分账；缺独立内部帧时不能把残差当直接观测的毛伤或回血来源。

YQL s280160/280161的毒2→8、血26／挡13／自爆41不变；只证明该次局部观测，提前喝、不喝和留药的完整支线未知。PU s252435为24血20挡对42，s252436奖励页余2血，证明本体结束后仍需覆盖自爆；不能用阶段标识当整场胜利。

KEN F17第4/5试T10同盘实净损15/21、敌净扣2/4；第4/6试T5同盘实净损7/5、敌净扣1/2，但末试敏捷直到T9建立，T8双防御各5。后一案例是反对“只省血就更好”的证据。七次药栏有药→空可核，其中d274131/274237/274272接口回执仍pending；不把槽位变化或单动作completed认证为整条候选兑现。

本批八流8444封套逐行核原始offset/bytes/SHA/JSON与显式身份；关键43状态、21决策原封套和29项材料核验另存。验证产物见evidence-verification.json、state-anchors.json、decision-anchors.json、sl-anchors.json、turn-endpoints.json、material-checks.json。它们是材料核验，不是生产测试、整战模拟或完整候选认证。

后续验证使用原始指纹与动作边界，先确认抽弃／重问后的实际分支，再核逐来源结算和保持后轮条件的完整对照；模拟结果与实际观测分列。若拟合参数，按独立局真实时间切分调参与留出，不把同局SL分进不同样本集。本批锚点均旧局，不能冒充未来新局验证。

预期影响：补足上述缺口后才有依据评估规则收益；本次不宣称胜率改善。回退：本批无源码／知识变更，无行为回退项；保留所有原提案、失败记录和缺数据。其他角色保持等价。

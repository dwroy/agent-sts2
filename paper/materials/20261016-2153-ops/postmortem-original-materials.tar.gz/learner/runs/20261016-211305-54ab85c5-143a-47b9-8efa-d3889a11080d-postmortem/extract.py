import json, subprocess
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261016-211305-54ab85c5-143a-47b9-8efa-d3889a11080d-postmortem'; run='YZWV37N2MU6N'
for name in ('decisions','run-plans','sl-attempts','run-config'):
    p=root/'logs'/f'{name}.jsonl'
    if not p.exists(): continue
    proc=subprocess.Popen(['rg','-n','-F',run,str(p)],stdout=subprocess.PIPE,text=True)
    count=0
    with (out/f'{name}.jsonl').open('w') as dest:
        for line in proc.stdout:
            no,raw=line.split(':',1)
            try: row=json.loads(raw)
            except ValueError: continue
            if row.get('run_id',row.get('run'))!=run: continue
            row['_line']=int(no); dest.write(json.dumps(row,ensure_ascii=False)+'\n'); count+=1
    proc.wait(); print(name,count)

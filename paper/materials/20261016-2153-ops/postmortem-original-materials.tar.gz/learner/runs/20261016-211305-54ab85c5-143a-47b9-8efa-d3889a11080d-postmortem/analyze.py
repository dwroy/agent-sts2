import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
d=[json.loads(x) for x in (p/'decisions.jsonl').open()]; states=[json.loads(x) for x in (p/'states.jsonl').open()]; res=json.load((p/'YZWV37N2MU6N-resources.json').open())
def compact(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
with (p/'noncombat.txt').open('w') as f:
 for r in d:
  if r['decider']=='codex':
   f.write(f"d{r['_line']} F{r['floor']} {r['label']} {compact(r['chosen'])} 理由 {r['rationale']}\n")
with (p/'combat-details.txt').open('w') as f:
 for c in res['combats']:
  if c['floor']<48:continue
  f.write(f"\n战斗 {c['sequence']} F{c['floor']}\n")
  ss=[r for r in states if c['entry']['line']<=r['_line']<=(c.get('exit') or c['last'])['line']]
  for i,r in enumerate(ss):
   s=r['state']; co=s.get('combat') or {}; pl=co.get('player') or {}
   f.write(f"s{r['_line']} {r['ts']} T{s.get('turn')} hp{(s.get('run') or {}).get('current_hp')} block{pl.get('block')} E{pl.get('energy')} 玩家{compact({x['power_id']:x['amount'] for x in pl.get('powers',[])})} ")
   f.write('敌'+compact([{k:e.get(k) for k in ('index','enemy_id','current_hp','block','powers','intents')} for e in co.get('enemies',[])])+'\n')
   if i+1<len(ss):
    for a in d:
     if r['ts']<=a['ts']<=ss[i+1]['ts'] and a['screen']=='COMBAT': f.write(f" d{a['_line']} {a['decider']} {a['label']} {compact(a.get('chosen'))} {a['rationale']}\n")
with (p/'resource-changes.txt').open('w') as f:
 for r in res['resource_changes']:
  a,b=r['from'],r['to']; f.write(f"s{a['line']}→{b['line']} {b['ts']} F{a['floor']}→{b['floor']} T{b['turn']} {a['screen']}→{b['screen']} HP{a['hp']}→{b['hp']} 药{a['potions']}→{b['potions']} 战{r['combat_sequence']} SL{r['restart_boundary']}\n")
print('deciders',collections.Counter(r['decider'] for r in d),'labels',collections.Counter(r['label'] for r in d))
r=next(x for x in d if x['decider']=='jev' and x['floor']==49)
print('jev sample',compact({k:r.get(k) for k in ('_line','chosen','journal','expect','sl_attempt')}))
print('question keys',[(k,list(v) if isinstance(v,dict) else type(v).__name__) for k,v in r.get('questions',{}).items()])
print('outputs', 'noncombat.txt','combat-details.txt','resource-changes.txt')

import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent; d=[json.loads(x) for x in (p/'decisions.jsonl').open()]; s=[json.loads(x) for x in (p/'states.jsonl').open()]; res=json.load((p/'YZWV37N2MU6N-resources.json').open())
counter=collections.Counter
j=[x for x in d if x['decider']=='jev']; q=[x for x in j if x['label'].startswith('combat/plan-choice')]
print('Jev',len(j),'low',len([x for x in j if x.get('confidence',1)<.35]),'plan',len(q),'best',counter(str(x.get('rollout_best_chosen')) for x in q),'rank1',sum(bool(re.search(r'Jev chose plan 1/',x.get('rationale',''))) for x in q))
print('rollout',json.dumps(q[-4].get('rollout'),ensure_ascii=False)[:700]); print('lastq',q[-4]['_line'])
print('guard',[(x['_line'],x['rationale']) for x in d if re.search('HP guard|hp.guard|HP护栏',x.get('rationale',''),re.I)])
print('focus',[(x['_line'],x['floor'],x['turn'],x['rationale']) for x in q if re.search('focus',x['rationale'],re.I)])
print('actual sl',[(x['_line'],x['floor'],x['turn']) for x in d if 'SL explore' in x.get('rationale','')])
print('fallback',sum(x.get('fallback') is True for x in d))
seeds=[x for x in d if x['decider']=='code' and x['label'].startswith('combat/') and x['label']!='combat/plan-continue']; print('code seeds',len(seeds),counter(x['label'] for x in seeds))
print('seed results',counter(x.get('result') for x in seeds))
print('code windows',len({(x['floor'],x.get('sl_attempt'),x['turn']) for x in seeds if str(x.get('result','')).startswith('completed')}))
print('all combat windows',len({(x['floor'],x.get('sl_attempt'),x['turn']) for x in d if x['screen']=='COMBAT'}))
print('latency jev',sum(x.get('latency_ms',{}).get('jev',0) for x in j),'usage',counter({k:sum(x.get('usage',{}).get(k,0) for x in j) for k in ('input_tokens','output_tokens')}))
for c in res['combats']:
 if c['floor'] not in (17,33,48,49): continue
 ss=[x for x in s if c['entry']['line']<=x['_line']<=(c.get('exit') or c['last'])['line']]
 by=collections.defaultdict(list)
 for x in ss:by[x['state'].get('turn')].append(x)
 print('战',c['sequence'],'F',c['floor'])
 for t,rs in by.items():
  a,b=rs[0],rs[-1]; co=a['state'].get('combat') or {}; en=co.get('enemies') or []; pl=co.get('player') or {}
  au=next((z for z in c['enemy_hp_audit']['turns'] if z['turn']==t),{})
  power=lambda who:{z['power_id']:z['amount'] for z in who.get('powers',[])}
  print('T',t,'s',a['_line'],b['_line'],'HP',a['state']['run']['current_hp'],b['state']['run']['current_hp'],'enemy',[(e['enemy_id'],e['current_hp']) for e in en], '推进',au.get('visible_enemy_hp_loss_lower_bound'),'增血',au.get('observed_hp_added'),'玩家',power(pl))
  if c['floor']==49 and c['sequence'] in (24,27):
   print('  last',json.dumps({'player':{k:(b['state'].get('combat')or{}).get('player',{}).get(k) for k in ('block','energy')},'enemies':[{k:e.get(k) for k in ('enemy_id','current_hp','powers','intents')} for e in (b['state'].get('combat') or {}).get('enemies',[])]},ensure_ascii=False))
(p/'metrics.json').write_text(json.dumps({'jev':len(j),'low_confidence':[x['_line'] for x in j if x.get('confidence',1)<.35],'combat_choices':len(q),'rollout_best':dict(counter(str(x.get('rollout_best_chosen')) for x in q)),'code_seed_lines':[x['_line'] for x in seeds],'sl_override_lines':[x['_line'] for x in d if 'SL explore' in x.get('rationale','')]},ensure_ascii=False,indent=2)+'\n')

import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent;S=[json.loads(x) for x in(p/'states.jsonl').open()];D=[json.loads(x)for x in(p/'decisions.jsonl').open()];R=json.load((p/'YZWV37N2MU6N-resources.json').open());B=[json.loads(x)for x in(p/'brain.jsonl').open()]
state={x['_line']:x['state']for x in S};checks=[]
def ok(test,note):
 assert test,note
 checks.append(note)
ok(len(R['combats'])==27,'21场胜战＋6次终战尝试')
ok(all(c['entry_is_turn_one']for c in R['combats']),'所有战斗入口均T1')
ok(all(c['entry']['max_hp']==70for c in R['combats']),'所有战斗最大血70')
ok(R['combats'][20]['entry']['hp']==67 and R['combats'][20]['exit']['hp']==27,'F48入口67、退出27、净损40')
ok(all(c['entry']['hp']==52and not c['entry']['potions']for c in R['combats'][21:]),'六次F49入口52空药')
ok([c['last']['turn']for c in R['combats'][21:]]==[6,7,9,8,9,9],'六试截断／死亡回合')
for c in R['combats'][22:]:
 rows=[x['state']for x in S if c['entry']['line']<=x['_line']<=c['last']['line']]
 ok(not any(any(z['power_id']=='NOXIOUS_FUMES_POWER'for z in(x.get('combat')or{}).get('player',{}).get('powers',[]))for x in rows),'第'+str(c['sequence']-21)+'试未建立毒雾')
 t1=[x for x in rows if x.get('turn')==1][-1]
 ok(t1['combat']['player']['block']==25,'重试T1末25挡')
ok(state[428762]['combat']['player']['block']==20,'末试T9结算前20挡')
ok(state[428762]['combat']['enemies'][0]['intents'][0]['total_damage']==45,'末试T9来袭45')
ok(state[428763]['run']['current_hp']==0,'终帧HP0')
ok([(x['enemy_id'],x['current_hp'])for x in state[428763]['combat']['enemies']]==[('TORCH_HEAD_AMALGAM',117),('QUEEN',342)],'终帧聚合体117、女王342')
ok(state[428644]['combat']['player']['block']==12 and state[428644]['combat']['enemies'][0]['intents'][0]['total_damage']==27,'第3试T9为12挡对27')
for key in ('hand','player','enemies'):
 ok(state[428640]['combat'][key]==state[428758]['combat'][key],'第3／6试T9可见'+key+'相同')
ok(sum(x['usage'].get('inputTokens',0)for x in B)==10148004,'大脑输入10148004')
ok(sum(x['usage'].get('cacheHitTokens',0)for x in B)==5546368,'大脑缓存5546368')
ok(len([x for x in D if 'HP guard:'in x.get('rationale','')])==2,'HP护栏2次')
text=(p/'section-draft.md').read_text();ok('F48T1，d414732' in text,'毒药水动作引用d414732')
ok(text.count('\n- [')==4,'3条经验＋1条记录')
(p/'verification.json').write_text(json.dumps({'checks':checks,'count':len(checks),'section_sha256':hashlib.sha256(text.encode()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
print('核验通过',len(checks),'项；草稿SHA256',hashlib.sha256(text.encode()).hexdigest())

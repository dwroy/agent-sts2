import json,subprocess
from pathlib import Path
p=Path('/home/dw/Projects/agent-sts2'); out=p/'learner/runs/20261016-211305-54ab85c5-143a-47b9-8efa-d3889a11080d-postmortem'
proc=subprocess.Popen(['rg','-n','-F','YZWV37N2MU6N',str(p/'logs/states.jsonl')],stdout=subprocess.PIPE,text=True)
n=0
with (out/'states.jsonl').open('w') as dst:
 for line in proc.stdout:
  no,raw=line.split(':',1)
  try: r=json.loads(raw)
  except ValueError: continue
  s=r.get('state') or {}
  if s.get('run_id',r.get('run_id'))!='YZWV37N2MU6N': continue
  r['_line']=int(no); dst.write(json.dumps(r,ensure_ascii=False)+'\n'); n+=1
proc.wait(); print('states',n)
d=[json.loads(x) for x in (out/'decisions.jsonl').open()]; lo=d[0]['ts']; hi=d[-1]['ts']; n=0; last=None
with (out/'deepseek-reasoning.jsonl').open('w') as dst:
 with (p/'logs/deepseek-reasoning.jsonl').open() as src:
  for i,line in enumerate(src,1):
   try:r=json.loads(line)
   except ValueError:continue
   ts=r.get('ts',''); last=ts
   if lo<=ts<=hi: r['_line']=i; dst.write(json.dumps(r,ensure_ascii=False)+'\n'); n+=1
print('reasoning_time_window',lo,hi,'matches',n,'last_ts',last)

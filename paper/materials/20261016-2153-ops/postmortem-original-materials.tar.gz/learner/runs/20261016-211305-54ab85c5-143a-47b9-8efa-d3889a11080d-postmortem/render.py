import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent;R=json.load((p/'YZWV37N2MU6N-resources.json').open());S=[json.loads(x) for x in (p/'states.jsonl').open()];D=[json.loads(x) for x in (p/'decisions.jsonl').open()];L=[json.loads(x) for x in (p/'sl-attempts.jsonl').open()]
byline={x['_line']:x for x in S}
def belt(x):return '＋'.join(f'{slot}:{ident}' for slot,ident in x) or '空'
def time(x):return x['ts'][11:23]
resource=['  | 层／实见敌人，结果 | HP入→出／净变化 | 药槽入→出 | 状态行／UTC入→出 |','  | --- | --- | --- | --- |']
for c in R['combats'][:21]:
 a,b=c['entry'],c['exit'];en={}
 for r in S:
  if a['line']<=r['_line']<=b['line']:
   for e in (r['state'].get('combat')or{}).get('enemies',[]):en.setdefault(e['enemy_id'],set()).add(e['name'])
 names='、'.join('／'.join(sorted(v))+' '+k for k,v in en.items())
 resource.append(f"  | F{c['floor']} {names}，胜 | {a['hp']}/70→{b['hp']}/70／{'−'+str(a['hp']-b['hp']) if a['hp']!=b['hp'] else '0'} | {belt(a['potions'])}→{belt(b['potions'])} | s{a['line']}→{b['line']}／{time(a)}→{time(b)} |")
sl=['  | F49尝试／截断或死亡回合 | HP入→末见／退出 | 最后挡／来袭 | 状态行／UTC入→末见或出 |','  | --- | --- | --- | --- |']
for c,l in zip(R['combats'][21:],L[3:]):
 a=c['entry'];b=c['exit']or c['last'];pl=(byline[c['last']['line']]['state'].get('combat')or{}).get('player')or{}
 sl.append(f"  | {l['attempt']}／T{l['turns']}{'实际死' if c['exit'] else '判死，无退出帧'} | 52→{b['hp']}{'／净−52' if c['exit'] else '，仅已减'+str(52-b['hp'])} | {pl.get('block')}／{l['incoming']} | s{a['line']}→{b['line']}／{time(a)}→{time(b)} |")
turns=['  | 战斗／尝试 | T1起每轮需要 | 本轮窗口可见推进下界 | 玩家逐轮净损 |','  | --- | --- | --- | --- |']
for c in R['combats']:
 if c['floor']not in (17,33,48,49):continue
 ss=[r for r in S if c['entry']['line']<=r['_line']<=(c['exit']or c['last'])['line']];by=collections.defaultdict(list)
 for r in ss:by[r['state'].get('turn')].append(r)
 ts=list(by);need=[];loss=[];dam=[]
 for i,t in enumerate(ts):
  a=by[t][0];en=(a['state'].get('combat')or{}).get('enemies')or[]
  need.append(str(sum(e['current_hp'] for e in en if e['is_alive'])))
  au=next((z for z in c['enemy_hp_audit']['turns']if z['turn']==t),{});val=au.get('visible_enemy_hp_loss_lower_bound',0)
  missing=any(g in au.get('gaps',[]) for g in ('body_removed_without_death_frame','changed_max_hp_identity_unknown'))
  dam.append(str(val)+('及缺帧' if missing else ''))
  if i+1<len(ts):end=by[ts[i+1]][0]['state']['run']['current_hp'];loss.append(str(a['state']['run']['current_hp']-end))
  elif c['exit']:loss.append(str(a['state']['run']['current_hp']-c['exit']['hp']))
  else:loss.append('未结算')
 label=f"F{c['floor']}"+(f"／第{c['sequence']-21}试"if c['floor']==49 else '')
 turns.append('  | '+label+' | '+'／'.join(need)+' | '+'／'.join(dam)+' | '+'／'.join(loss)+' |')
potions=['  | 新获来源／槽位／ID／落地状态与UTC | 饮用层回合／动作／落地状态与UTC |','  | --- | --- |']
gains=[];uses=[]
for e in R['resource_changes']:
 a,b=e['from'],e['to'];old={tuple(x)for x in a['potions']};new={tuple(x)for x in b['potions']}
 for item in sorted(new-old):gains.append((item,a,b))
 for item in sorted(old-new):uses.append((item,a,b))
assert len(gains)==len(uses)==13
for item,a,b in gains:
 item2,c,d=next((u for u in uses if u[0]==item and u[2]['ts']>b['ts']))
 assert item==item2
 actions=[x for x in D if c['ts']<=x['ts']<=d['ts'] and (x.get('chosen')or{}).get('action')=='use_potion' and (x.get('chosen')or{}).get('option_index')==item[0]]
 if not actions:
  actions=[x for x in D if x['floor']==d['floor'] and x['turn']==c['turn'] and (x.get('chosen')or{}).get('action')=='use_potion' and (x.get('chosen')or{}).get('option_index')==item[0]]
 act=actions[-1];slot,ident=item
 source='商店购买'if b['screen']=='SHOP'else'奖励领取'
 potions.append(f"  | F{b['floor']}{source}，槽{slot} {ident}，s{a['line']}→{b['line']}／{time(b)} | F{act['floor']}T{act['turn']}，d{act['_line']}，s{c['line']}→{d['line']}／{time(d)} |")
s=(p/'section-template.md').read_text();s=s.replace('到T2三技能后12力量、34攻，21挡实损13以内的具体结算需以现场帧核对，不用第一阶段力量外推后三阶段。','只核这一步能力／技能与力量变化，不用第一阶段力量外推后三阶段。')
for key,rows in [('RESOURCE_TABLE',resource),('SL_TABLE',sl),('TURN_TABLE',turns),('POTION_TABLE',potions)]:s=s.replace('@@'+key+'@@','\n'.join(rows))
assert '@@' not in s
(p/'section-draft.md').write_text(s)
(p/'append-section.sh').write_text("cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+s+"EOF\n")
print('草稿字数',len(s),'战斗表21胜＋6终战尝试，药水13行','SHA256',hashlib.sha256(s.encode()).hexdigest())
print('\n'.join(turns));print('\n'.join(potions))

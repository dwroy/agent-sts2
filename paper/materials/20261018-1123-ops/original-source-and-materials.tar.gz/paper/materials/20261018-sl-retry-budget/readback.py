"""Read frozen raw references only; no model, gameplay or simulated game outcomes."""
import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SOURCE = ROOT / "paper/materials/20261018-h1-regression/decisions.compact.jsonl"
RUNS = ["0NMF36KX3F7Y", "9W38TRGPJW9Q", "NRZAYVRMM7M0", "KCA04Q3SEYTF", "KRLPMR0FWVZE"]
rows = []
for line in SOURCE.read_bytes().splitlines():
    candidate = json.loads(line)
    if candidate["run_id"] not in RUNS or candidate.get("floor") != 17:
        continue
    ref = candidate["raw"]
    with (ROOT / ref["path"]).open("rb") as source:
        source.seek(ref["offset"])
        original = source.read(ref["bytes"])
    assert hashlib.sha256(original).hexdigest() == ref["sha256"]
    raw = json.loads(original)
    budget = raw.get("time_budget") or {}
    if not budget.get("key", "").startswith(raw["run_id"] + ":17:"):
        continue
    keys = ["ts", "run_id", "floor", "turn", "screen", "label", "decision_id", "decider", "rationale", "sl_attempt", "sl_reloads",
            "time_budget", "timing", "latency_ms", "no_jev", "request_ids", "chosen", "result"]
    row = {key: raw.get(key) for key in keys}
    row["raw"] = ref
    row["has_combat_question"] = bool(raw.get("questions")) and raw["label"].startswith("combat/")
    rows.append(row)

(OUT / "five-fights-budget-records.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))
summary = []
turns = collections.defaultdict(list)
segments = collections.Counter()
previous = {}
for row in rows:
    budget = row["time_budget"]
    base = budget["key"]
    if base in previous and budget["turn_actual_ms"] < previous[base] - 2:
        segments[base] += 1  # A restarted process is not silently merged with its prior clock.
    previous[base] = budget["turn_actual_ms"]
    turns[(base, segments[base])].append(row)

def jev_ms(row):
    return sum(s["actual_ms"] for s in row["time_budget"].get("stages", []) if s["stage"] == "Jev" or s["stage"].startswith("Jev_"))

def cut(row):
    return row["time_budget"].get("fallback") in ["Jev_deadline_current_candidate", "deadline_current_code_candidate"] or any(
        s["stage"] == "Jev" and s.get("timed_out") for s in row["time_budget"].get("stages", []))

schedule = []
for (key, segment), group in turns.items():
    first = next((i for i, row in enumerate(group) if row["has_combat_question"]), None)
    initial = group[0]
    attempt = initial.get("sl_attempt") or 1
    item = {"run_id": initial["run_id"], "attempt": attempt, "turn": initial["turn"], "key": key, "clock_segment": segment,
            "old_kind": initial["time_budget"]["kind"], "old_limit_ms": initial["time_budget"]["budget_ms"],
            "record_count": len(group), "choice_question_observed": first is not None,
            "old_cutoffs": sum(cut(row) for row in group), "allowed_under_four_attempt_cap": attempt <= 4,
            "raw_references": [row["raw"] for row in group]}
    if first is not None:
        decision = group[first]
        budget = decision["time_budget"]
        before = budget["budget_ms"] - budget["entry_budget_ms"] + budget["shared_actual_ms"]
        consumed_by_jev = sum(jev_ms(row) for row in group[:first + 1])
        item.update(observed_pre_first_question_computation_ms=max(0, before - consumed_by_jev),
                    first_question_raw=decision["raw"], first_question_decision_id=decision["decision_id"],
                    old_first_jev_stage_ms=next((s["budget_ms"] for s in budget.get("stages", []) if s["stage"] == "Jev"), None))
    schedule.append(item)

for run in RUNS:
    group = [row for row in rows if row["run_id"] == run and row["label"].startswith("combat/")]
    cuts = [row for row in group if cut(row)]
    summary.append({"run_id": run, "combat_records": len(group), "jev_cutoffs": len(cuts),
                    "first_attempt_cutoffs": sum((row.get("sl_attempt") or 1) <= 1 for row in cuts),
                    "retry_cutoffs": sum((row.get("sl_attempt") or 1) >= 2 for row in cuts),
                    "cutoffs_by_original_sl_attempt": dict(collections.Counter(str(row["sl_attempt"]) for row in cuts))})
(OUT / "five-fights-schedule.json").write_text(json.dumps(schedule, ensure_ascii=False, indent=2) + "\n")
(OUT / "five-fights-correction.json").write_text(json.dumps({"source_compact_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "verified_raw_records": len(rows), "original_attempt_numbering": "first=1, retry>=2; absent means untracked first",
    "previous_csv_error": "first_attempt_jev_deadline used not(sl_attempt or0), incorrectly excluding first attempt1",
    "old_csv_preserved": True, "groups": summary, "turn_clock_groups": len(schedule),
    "groups_with_question": sum(row["choice_question_observed"] for row in schedule),
    "first_attempt_cutoffs": sum(row["first_attempt_cutoffs"] for row in summary),
    "retry_cutoffs": sum(row["retry_cutoffs"] for row in summary)}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_raw_records": len(rows), "groups": summary, "turn_clock_groups": len(schedule)}, ensure_ascii=False))

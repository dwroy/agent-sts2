原ops请紧急接源并按Roy已批准的规则变更单独发布。此前预告已发原wJ:p5，这条是最终交源，源检查现已终局0。

授权：Claude指派/Roy2026-10-18/docs/human-pace-plan.md §2 commit678104758，请求roy-20261017-human-pace。实际Silent only三项：
1. 每个战斗回合为Jev保护3秒，planner里的solver/B2/rollout及闲时预计算/thief计算统一服从计算剩余；普通/精英/Boss均覆盖。整个回合共享一次预留，Jev实际等待消耗它，不在每张牌重加3秒；正常接受答案保持，真正JeV超时仍用既有候选。
2. 实际SL重试按战斗类型取Boss60/精英15/普通10秒，与首试相同；精确缓存照用。兼容常量retry10000仍在，但实际Silent循环不再因slEnv选择retry种类。
3. 实际Silent所有既有SL门槛最多4次总尝试；原配置更少时保持。判死/重载/门槛/其他SL规则及其他角色均保持。通用配置默认5不改，实际角色controller限制三次重试，不影响其他角色。

固定源 cde4957955c45587672c2767b093cd558c9e1c60 / tree b8dbab608c9731255b4694954c8b92978e4490d7，parent b155d00a36080418149e63d2f21b491d34d7f40a；WT .worktrees/sl-retry-budget-20261018，提交后clean。仅8叶：core/decision-budget.ts、hand/loop.ts、hand/pace-precompute.ts、sl/controller.ts，及human-pace-jev、human-pace-sampling、human-pace-sl-budget、human-pace-sl-loop四测试。source.patch、source-before-check.json、source-commit.json逐SHA可核。只窄移此八叶，保当前live刷新知识/校准/其他发布/历史，不整树替换。

源验证终局：tsc0；唯一完整原沙箱入口0，主体494文件4467过+独立paths1文件11过=495文件4478项0，1245.94秒；最终5文件34重点0为子集、初始4文件20项0另保不加总。八SHA前后一致，source/materials gitleaks0，未重复source full。生产runLoop重试Boss真实预算60、算满计算份额后仍调用Jev并接受回答；SDK固定入口普通/精英/Boss均拿到3秒且实际取消；B2 worker受限；三个SL门槛/其他角色原六次路径均固定过。见checks.json及sandbox-final-source.log，完整logSHA d7c265043bf01403996200eed72b4e3c58e6c91bc97cdbce385094cc7d08e2c0。不借这些源绿冒新live完整绿。

五场离线核：原offset/bytes/SHA回seek1356记录，281回合时钟组。新上限内97个attempt2–4候选回合全部有JeV时间；按原耗时需求静态回放最低50.052秒、算满57秒边界仍3秒。原attempt5/6的96回合不执行；不是重开旧局或生成新答案/胜负。完整report.md、five-fights-clock-replay.json及可重算脚本已保存。

必须明确纠错告知Roy：watcher旧per-fight.csv把sl_attempt=1排除出首试，是watcher统计错误。五场78截止实际首试7、重试71：0NMF1/19，9W383/29，NRZA3/17，KCA00/4，KRLP0/2；55条有JeV限时阶段、23条请求前无JeV阶段，不是全部重试或全部未调用。旧CSV/报告不重写；另附442场仅两列更正副本，75行变化、其他单元格逐项保持，原1356行核证界限保持。更正已由watcher本人在Roy可见回复说明，不代你或其他角色ACK。

请尽快按原live锁独立正式release_id/版本登记，根for-roy/inbox双通知逐项旧/新/授权/证据/预期影响和回退；新实际最终live精确树完整宿主只沿原唯一通道请求一次，保所有原失败/源绿与新组合区别，不另重未变source full。回退只反向八叶本增量并保R394、校准、并行知识、历史，实际行为回退另编号。实际生效运行身份由你记录，旧attempt5/6日志不倒改，未知自然效果不填。

这是原授权系统规则交付，不新增游戏知识或学习账本shipped，不关闭H0/0332/human-pace/main-push等宽父；不新开研究/局/模拟/模型/自然观察器，不改账号/home/模型或运维prompt。请保留源WT至真实入库/宿主验收，再由原retention complete；watcher本轮不代发布/编号/实收或回收。可在本材料目录追加你本人ops-received/ops-disposition真实回执。watcher交完按Claude指派停下。

"""Correct two first-attempt fields in a new copy; keep the frozen CSV and all other cells unchanged."""
import csv
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
OLD = OUT.parent / "20261018-h1-regression"
source = OLD / "per-fight.csv"
decisions_path = OLD / "decisions.compact.jsonl"
decisions = [json.loads(row) for row in decisions_path.read_bytes().splitlines()]
grouped = {}
for row in decisions:
    if row.get("label", "").startswith("combat/"):
        grouped.setdefault((row["run_id"], row.get("floor")), []).append(row)

def jev_cut(row):
    budget = row.get("time_budget") or {}
    return budget.get("fallback") in ["Jev_deadline_current_candidate", "deadline_current_code_candidate"] or any(
        stage.get("stage") == "Jev" and stage.get("timed_out") for stage in budget.get("stages", []))

with source.open() as handle:
    reader = csv.DictReader(handle)
    fields = reader.fieldnames
    rows = list(reader)
changes = []
for row in rows:
    candidates = grouped.get((row["run_id"], int(row["floor"])), [])
    first = [decision for decision in candidates if (decision.get("sl_attempt") or 1) <= 1]
    before = {field: row[field] for field in ["first_attempt_questions", "first_attempt_jev_deadline"]}
    row["first_attempt_questions"] = str(len(first))
    row["first_attempt_jev_deadline"] = str(sum(jev_cut(decision) for decision in first))
    after = {field: row[field] for field in before}
    if before != after:
        changes.append({"run_id": row["run_id"], "floor": row["floor"], "before": before, "after": after})
destination = OUT / "per-fight-first-attempt-corrected.csv"
with destination.open("w") as handle:
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
with source.open() as handle:
    original = list(csv.DictReader(handle))
for before, after in zip(original, rows, strict=True):
    assert all(before[key] == after[key] for key in fields if key not in ["first_attempt_questions", "first_attempt_jev_deadline"])
(OUT / "csv-first-attempt-correction-receipt.json").write_text(json.dumps({
    "source": str(source.relative_to(OUT.parents[2])), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "frozen_decisions_sha256": hashlib.sha256(decisions_path.read_bytes()).hexdigest(),
    "destination": destination.name, "destination_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
    "rows": len(rows), "changed_rows": len(changes), "changes": changes,
    "other_cells_unchanged": True, "old_files_rewritten": False,
    "verification_scope": "Two fields recomputed from the previously raw-verified frozen extract; this turn independently re-seeks1356 raw records for the five requested F17 fights.",
}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"rows": len(rows), "changed_rows": len(changes), "other_cells_unchanged": True}))

/** Counterfactual clock schedule only. No game simulation, model response, or new gameplay evidence. */
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { DecisionBudget, combatBudgetKind, withCombatComputation, withDecisionBudget, withinDecisionBudget }
  from "../../../.worktrees/sl-retry-budget-20261018/agent/src/core/decision-budget.js";

async function main() {
  const out = fileURLToPath(new URL(".", import.meta.url));
  const bytes = readFileSync(join(out, "five-fights-schedule.json"));
  const schedule = JSON.parse(bytes.toString("utf8"));
  const rows = [];
  for (const observed of schedule) {
    const { run_id, attempt, turn, key, clock_segment } = observed;
    const identity = { run_id, attempt, turn, key, clock_segment };
    if (!observed.allowed_under_four_attempt_cap) {
      rows.push({ ...identity, status: "attempt5_or6_not_reachable_under_new_cap", allowance_ms: null });
      continue;
    }
    if (!observed.choice_question_observed) {
      rows.push({ ...identity, status: "code_only_no_observed_choice_question", allowance_ms: null });
      continue;
    }
    let time = 0, called = false;
    // All five F17 first-attempt clocks are observed Boss60; retries use that same fight kind.
    const budget = new DecisionBudget(key, combatBudgetKind("boss"), () => time);
    let computation = 0, allowance = 0;
    await withDecisionBudget(budget, async () => {
      withCombatComputation(() => {
        computation = Math.min(observed.observed_pre_first_question_computation_ms, budget.remaining());
        time += computation;
      });
      allowance = budget.remaining();
      if (allowance < 3000) throw new Error(`reservation lost for ${key}`);
      await withinDecisionBudget("Jev", async () => {
        called = true;
        time += 150; // A fixed response latency, never a generated game answer.
      });
    });
    if (!called || budget.elapsed() > 60000) throw new Error(`invalid schedule for ${key}`);
    // Also exhaust the entire allowed computation to certify the cutoff boundary, not only easy historical turns.
    const saturated = new DecisionBudget(`${key}:boundary`, combatBudgetKind("boss"), () => 0);
    withDecisionBudget(saturated, () => withCombatComputation(() => saturated.charge(saturated.remaining())));
    if (saturated.remaining() !== 3000) throw new Error(`bad boundary for ${key}`);
    rows.push({ ...identity, status: "fixed_clock_checked", old_limit_ms: observed.old_limit_ms,
      new_limit_ms: 60000, old_pre_first_question_computation_ms: observed.observed_pre_first_question_computation_ms,
      replay_computation_ms: computation, allowance_ms: allowance, saturated_allowance_ms: saturated.remaining(),
      placeholder_invoked: called, first_question_raw: observed.first_question_raw,
      original_cutoffs_in_turn: observed.old_cutoffs, actual_game_answer_or_outcome: "unknown" });
  }
  const runs = [...new Set(rows.map((r) => r.run_id))].map((run) => {
    const selected = rows.filter((r) => r.run_id === run);
    const retries = selected.filter((r) => r.attempt >= 2 && r.status === "fixed_clock_checked");
    return { run_id: run, retained_retry_choice_turns: retries.length,
      min_jev_allowance_ms: Math.min(...retries.map((r) => r.allowance_ms!)),
      removed_attempt5_or6_turns: selected.filter((r) => r.status === "attempt5_or6_not_reachable_under_new_cap").length };
  });
  writeFileSync(join(out, "five-fights-clock-replay.json"), JSON.stringify({
    schema: "sl-jev-fixed-clock-audit-v1", schedule_sha256: createHash("sha256").update(bytes).digest("hex"),
    scope: "Cooperative deadline replay over the original observed pre-first-question compute demand; not natural latency or a counterfactual game answer. New attempts5/6 do not execute.",
    new_model_calls: 0, new_game_actions: 0, new_game_simulations: 0, runs, rows,
  }, null, 2) + "\n");
  console.log(JSON.stringify({ runs, total_turn_clock_groups: rows.length,
    retained_retry_choice_turns: runs.reduce((n, r) => n + r.retained_retry_choice_turns, 0) }));
}
main().catch((error) => { console.error(error); process.exitCode = 1; });

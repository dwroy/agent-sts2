import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
import ledger

subprocess.run(['date', '-Iseconds'], check=True)
items = json.loads((S / 'dispatched-proposals.json').read_text())
ids = sorted({i for item in items.values() for i in item['ledger']})
path = ROOT / 'paper/materials/learning/ledger.jsonl'
cut = path.stat().st_size
digest = hashlib.sha256()
with path.open('rb') as f:
    remaining = cut
    while remaining:
        chunk = f.read(min(1024 * 1024, remaining))
        assert chunk
        remaining -= len(chunk)
        digest.update(chunk)
prefix_hash = digest.hexdigest()
before = ledger.fold(ledger.read_rows(str(path)))
before = {i: before[i] for i in ids}
assert all(x['character'] == 'silent' for x in before.values())
(S / 'ledger-pre-link.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in ids:
    related = [p for p, value in items.items() if ident in value['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
        'note': '20261017-132758-strategy-proposal复核；' + '、'.join(related) +
                '均waiting；仅补本批六局证据/当前窄实现/消费者限制的追溯，不新增支持或重犯，不改原claim、首证、先验、状态、版本，不标shipped。'})
payload = '\n'.join(json.dumps(x, ensure_ascii=False) for x in updates) + '\n'
(S / 'ledger-update-input.jsonl').write_text(payload)
environment = dict(os.environ, LEDGER_FILE=str(path), LEDGER_RUNS=str(ROOT / 'logs/runs.jsonl'),
                   LEDGER_VERSIONS=str(ROOT / 'eval/versions.json'))
with (S / 'ledger-update.out').open('w') as out, (S / 'ledger-update.err').open('w') as err:
    result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'],
                            input=payload, text=True, env=environment, stdout=out, stderr=err)
assert result.returncode == 0, 'ledger CLI rejected update; original stderr retained'
after = ledger.fold(ledger.read_rows(str(path)))
after = {i: after[i] for i in ids}
(S / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
protected = ['character', 'asc', 'kind', 'claim', 'first_run', 'prior', 'prior_runs', 'prior_note',
             'evidence', 'status', 'version', 'effect']
differences = [{'id': i, 'field': k} for i in ids for k in protected if before[i].get(k) != after[i].get(k)]
digest = hashlib.sha256()
ours = []
with path.open('rb') as f:
    remaining = cut
    while remaining:
        chunk = f.read(min(1024 * 1024, remaining))
        assert chunk
        remaining -= len(chunk)
        digest.update(chunk)
    prefix_preserved = digest.hexdigest() == prefix_hash
    offset = cut
    for raw in f:
        row = json.loads(raw)
        if row.get('by') == 'learner:strategy-proposal' and row.get('id') in ids and row.get('note', '').startswith('20261017-132758-strategy-proposal复核；'):
            assert set(row) <= {'op', 'id', 'by', 'ts', 'where', 'note'}
            ours.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        offset += len(raw)
assert prefix_preserved
assert len(ours) == len(ids) and {x['row']['id'] for x in ours} == set(ids)
assert all(str(S / 'proposal.md') in after[i]['where']['proposal'] for i in ids)
receipt = {'exit_code': result.returncode, 'root_ledger': str(path), 'prefix_size': cut,
           'prefix_sha256': prefix_hash, 'prefix_preserved': prefix_preserved,
           'updates': len(ours), 'protected_fields': protected, 'protected_differences': differences, 'rows': ours}
(S / 'ledger-link-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'rows'}, ensure_ascii=False))
assert not differences, 'selected protected fields changed concurrently; inspect receipt without rewriting history'

import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
TIME = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
ITEMS = json.loads((S / 'dispatched-proposals.json').read_text())
DETAIL = [
    ('感染棱柱技能污染', 'DUZUBAJ3A8GP F27 T4—T6；silent-0168',
     '原帧274830—274839：污染未列出→3→3→6，勒紧能力不加；下一轮火花3→6，三技能污染6/12/18，显示攻击17/21/26，17挡后净损9。T4迷雾加6毒、末结8毒，T5加6毒、末结13毒。',
     '不能由技能污染推出禁止技能；迷雾同时提供毒与弱，替代整条战斗没有实打对照。',
     '已有技能污染、逐击入伤及SL资源预测字段；本批未取得原运行时数据库字节与同一完整后继的校准输入，尚未核实增长、临时污染消失、迷雾收益在候选到完整执行间同时闭合。不能以现帧损9认定需要新的禁技能规则。',
     '保留原选项；后续用冻结A10数据库、状态及完整技能前缀逐步重放毒/挡/污染/火花，分别核预测与实际，不拟新惩罚系数。'),
    ('失落/遗忘逐来源抢夺与返还', '5PM6JAQG6FNQ F39 T2/T4—T6；silent-0183、silent-0005',
     '首试274351—274358：敏捷负4→负2→未列出，防御实给5挡；失落从2血3毒退出后，玩家力量负4→未列出。274362遗忘敏捷6、玩家敏捷负2。末试274391—274397单步法只回负2，失落退出后仍死于剩余敌人。',
     '两步法抵消负敏捷和毒杀返还发生，不代表固定先杀失落就能赢；末试8血仍死亡。能力未列出与显式零分开保存。',
     '现帧负属性算式和观测端点已具备；逐实体抢夺累计、毒杀返还归源及之后重抢的完整候选重放尚缺闭合输入。敌方类型和index不能认证稳定实例，不能据返还端点直接声称预测模型已正确记账。',
     '后续保存稳定来源/实例或明确未知、累计扣取与返还，冻结T4至T6动作和数据库；先验逐来源结算，不设固定击杀序。'),
    ('下水道蚌加压成长', 'CA5KE8GFJ9X2 F13 T1—T5；silent-0231',
     '273237/273252/273263：力量0/4/8，喷水11/15/19；已施弱后11/14。273247起覆甲9/8/7/6，末2血10挡对14攻击，完整显示差4而仅剩2血。',
     '覆甲变化没有完整条件隔离；末死亡的实际扣2不能替代显示未挡4，也不能拟固定房间代价。',
     'enemyTable已读当前进阶移动数据库，房间代价仍保留5胜样本；缺原运行时A10移动表冻结字节及加压/覆甲全过程的预测校准，未观察减层条件仍未知。本批不把源码接线存在等同完整模型验收。',
     '保留现状；以后冻结实际调用的A10表，从首样本读HP/攻击，重放加压与弱，逐步比覆甲/敌挡；不将覆甲相关性扩成减层规则。'),
    ('电击机器人连续增长与召唤身份', '5PM6JAQG6FNQ F38 T3/T4；silent-0233、silent-0209',
     '两轮匹配原题状态中ZAPBOT最大血均23，高电压2，力量2→4，攻击17→19；T3到T4玩家61→31。T4才群伤结束电击。',
     '另一候选35伤/损3未实打，不称必省27血救后场；最大血相同和类型相同仍不等同稳定实例证明。',
     '现有HIGH_VOLTAGE_POWER增长和新召唤者初始化路径存在；原运行A10数据库、召唤身份和连续后继未完整冻结校准。另一击杀序仍只有预测，不能登记整项duplicate或改统一集火规则。',
     '以后冻结A10移动表、出生/退出及实例链，检验新召唤不继承旧增长；分列爪牙退场和本体中毒，保留所有目标顺序。'),
    ('沙虫护栏/SL/成长/资源综合审计', '8JRE1C4H4Z2W F17 T6、F33 T2/T5/T11；silent-0079、silent-0021、silent-0125、silent-0018及原关联账本',
     '270216/270282指纹相同，0/24与5/24死亡样本不可并为相同死亡率；消费者核首/三试T2净损3/15、扣10/17。二试T5净损4、扣25。末T11整轮净损5、扣36；行动末154血24毒，终态130，显示37攻击/22挡差15。',
     '末T2保血延长仍失败，F17抽牌重规划后不能把护栏预测省5当实际省5；SL重置不是回血，零血截断不是完整伤害。',
     '候选阶段、护栏、单动作回执、连续观测和终态消费者已有live祖先；仍不能逐候选证明完整执行、逐来源结算全部能力/沙坑/资源或补出未选完整胜线。原宽提案不能因部分审计已实现而关闭。',
     '复用已有审计，不重复增加相同字段；后续补完整候选归属、已结算毒/能力与终局入伤来源，独立新A10局作后移验证；现阶段不改护栏/探索/路线阈值。'),
    ('全败SL替换与重放资源成本', 'YF0LXT1QSTGG F48 第二/第三试T1；silent-0079',
     '271309/271348指纹相同，原题预测损0/10、伤54/36，均24/24死；原帧277327→277337与277366→277373实际净损0/9、净扣45/38。271354是后续避线结束回合，不合并为原候选完整执行。',
     'F33第二次SL实胜，不能从F48全败否定所有探索；第四次T5弃牌打断原线，未执行续步不能算收益。',
     '1698adc96ba434a46942321e0237b70657e625b2已实现替换、重放和avoid的预测资源差值，fdaf787a372880b0438e73bcac7e6d2168b038ed只认证单动作回执；完整续步归属和实际血价的候选级结算仍未被认证，策略改动缺受控完整后继及独立验证。',
     '保留既有探索门槛；需要能关联原答/替换/重问/执行的完整候选结果与未执行续步，成对记录当轮代价，不拟全局血价常数或禁止SL。'),
    ('实验体分阶段毒启动与能力兑现', 'YF0LXT1QSTGG F48 末试T3—T5；silent-0021、silent-0027、silent-0028、silent-0085',
     '277512/277513从4/111血、4毒变212/212、未列出毒；277519触媒2已建而敌未列毒。277524/277526敏捷5→6，既有23挡不变；277527为18血23挡对44攻击，终敌160。',
     '前五试有毒雾或余像仍失败，拥有升级毒性爆发不等于新阶段实际施放；不能推强制能力先手、牌组上限或必胜弃牌。',
     'aad2700abed6dff1d66e87fb36aaa6fedb39adf3已提供当前阶段/持有/建立的窄事实，离线消费者保留相邻观测；逐候选已结算毒、后续攻击与敏捷取得顺序的来源归属、完整派发结果仍未闭合。现帧展示不是完整候选模型或整战参数校准。',
     '复用当前事实与阶段参考；后续逐步核0毒触媒、阶段清毒、23挡时点与37净扣，新增独立A10完整后继验证后才讨论动作排名。'),
    ('双蟹零胜并列SL血价', 'XP2SL33HT0D9 F33 首/二试T3、首/末试T1；silent-0079',
     '271992/272040同指纹、B2均0且diff/se均0，整轮观测损9/14、扣24/27；271982/272195同指纹，原帧T1到T2损2/10、扣25/34。272076的21/24→23/24仅候选数字。',
     '末试T2零损、T3损4，减力和朝向确实有收益；首/末T1输出差还含手里剑成长，不能断言所有付血探索错。',
     '已有SL预测差值、并列即时损血参考和观测消费者；B2零差并不消除当轮成本，但本批无受控完整胜线或时间后移策略样本，完整候选与力量成长因果仍未知，不能拟新的低血优先/惩罚系数。',
     '保留当前门槛与全部候选；后续同起点分列损血/本体进度/成长/置信度，控制抽弃及随机落点，按独立局留出验证再评估窄策略。'),
    ('双蟹朝向、临时减力与轮初挡', 'XP2SL33HT0D9 F33 末试T2—T5；silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242',
     '278236/278240轮初14挡到斗篷后20；278237碾碎爪负9力量/0攻击，278242恢复为未列出力量。278249/278252/278253火箭57→38→28；四敏脆弱时偏折只6挡。278260到278261已结毒3/7，两敌剩153/125。',
     '四敏、手里剑和毒均已启动仍未减员，不能强制先铺能力；本批未重新核其他早期局，不沿用原文跨进阶分母冒称本次覆盖。',
     '普通船夹板14/T2、临时减力及朝向算式已有源码；逐候选分拆朝向/弱/新增挡与原挡、已结算毒和实际存活的统一来源比较尚缺完整验收，观察参考不能静默代入未知组合。',
     '保留排名与权重；以后固定重放57→38→28、14+6、负9恢复、四敏脆弱6挡和终局结毒，逐候选保留未知组合与重规划边界。'),
    ('两局临时减力/能力兑现/SL综合链', 'YF0LXT1QSTGG F48、XP2SL33HT0D9 F33；原22条账本见派发原文与dispatched-proposals.json',
     '本批重新核实两局三组同指纹成本：YF损0/9、扣45/38；XP T3损9/14、扣24/27；XP T1损2/10、扣25/34。阶段清毒、后来敏捷不倒补、临时减力恢复、T2轮初挡分别有原帧。',
     '原提案101局/1499房和历史22次镣铐/50帧船夹板是旧批范围，本批仅六个派发局，不重新冒称全历史验证；相关SL不扩独立样本数。',
     '既有源码覆盖多项窄事实，但逐来源结算、全部重规划后的完整候选归属、路线/药水资源与受控整战后继没有完整交付；不以多个子功能live祖先合成整项implemented/duplicate。',
     '复用原ID和账本，未来补完整动作/资源/候选链和独立验证；不新建重复提案、不改旧原文或强推统一SL/能力/药水规则。'),
]
assert len(ITEMS) == len(DETAIL) == 10
RESULTS = []
sections = []
for (ident, item), (title, loc, evidence, counter, reason, method) in zip(ITEMS.items(), DETAIL):
    RESULTS.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append(f'''## {ident}：{title}

来源任务：{item['source_task']} → strategy-proposal；本次batch为20261017-132758-strategy-proposal。
角色silent；本次仅A10；原提案路径：{item['proposal']}。
原Markdown SHA256：{item['proposal_sha256']}（已复制原字节并核同）。
原关联账本：{'、'.join(item['ledger'])}。
证据位置：{loc}。

核实结果：{evidence}

反例与边界：{counter}

现状、旧行为与处置：waiting。{reason}

预期行为及验证：{method} 不删选项，同值保留并列；本批无生产源码改变，无新游戏规则。后续实现须固定数据撤源码失败/恢复通过并过沙箱入口，实际合入后另记版本和双通知。

样本与拟合：本批仅复核派发六局中的对应局，同存档尝试相关，不按尝试拟胜率。没有独立时间后移策略验证，不拟权重/血价/安全阈值。原文提到的额外早期局与宽历史统计仅作为旧记录，不算本批新核支持。
预期影响：明确可用窄事实和待补证据，未证明策略收益。回退：本批无生产代码可回退，原提案/日志/账本保留；后续行为变更按其实际源码提交单独回退。
''')

proposal = f'''# 本批十项静默策略提案复核

记录时间：{TIME}（先执行date）。base={BASE}。
本批为普通消费队列，身份匹配task=strategy-proposal、character=silent、reason=proposal和工作树；只处理本批十个proposal_ids，无proposal_repair/research_request/implementation_request，不承接根目录中其他batch的专题。
开工git status干净；git merge --no-edit main返回Already up to date。未派子agent。
总处置：十项waiting，保留原行为；无新源码/知识、提交、合入、版本或shipped。

共用证据：evidence/evidence-manifest.json保存八流字节截点、逐局计数、坏行数和输出SHA；每个封套包含source/line/offset/bytes/SHA256。envelope-readback.json确认8274个封套全部按原偏移读回同字节、同JSON。material-verification.json为52项材料核验，非生产测试。
本提案是原ID的实现任务复核，不新建重复code_proposals ID，不覆盖原文；只通过根ledger.py追加本角色where/note追溯，保留既有状态和证据分母。

''' + '\n'.join(sections)
(S / 'proposal.md').write_text(proposal)

receipts = json.loads((S / 'consumer-receipts.json').read_text())
verification = json.loads((S / 'material-verification.json').read_text())
assert verification['failures'] == 0 and all(r['exit_code'] == 0 for r in receipts)
report = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-132758-strategy-proposal',
    'base': BASE, 'runs': RUNS if (RUNS := json.loads((S / 'dispatch.json').read_text())['runs']) else [],
    'fixes': [], 'skipped': [], 'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': list(ITEMS), 'implementation_domains': [], 'proposal_results': RESULTS,
    'report': str(S / 'report.md'),
}
(S / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
(S / 'proposal-results.json').write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2) + '\n')
table = '\n'.join(f"| {r['run']} | {','.join(str(x) for x in r['floors'])} | {r['states']} | {r['decisions']} |" for r in json.loads((S / 'consumer-input-inventory.json').read_text()))
result_table = '\n'.join(f"| {ident} | {d[0]} | waiting |" for ident, d in zip(ITEMS, DETAIL))
body = f'''# 静默策略消费回报：20261017-132758-strategy-proposal

记录时间：{TIME}。本批十项均waiting；当前证据支持原有观察，但不足以新增策略规则或认证宽提案完整实现。fixes=[]、merged=null、implementation_domains=[]。没有源码/知识修改、代码提交、live合入、发布版本或shipped声明。

## 身份、基线与范围

完整base：{BASE}。开工工作树/index干净；普通任务执行git merge --no-edit main，返回Already up to date；HEAD未改变。
根learn.json只读本batch，对应task/character/worktree和六局集合匹配；reason=proposal，领取十个proposal_ids，未带proposal_repair、research_request或implementation_request。普通专题条件不匹配（根strategy-research-silent.json绑定旧batch），没有退入任何专题或额外队列。
十原提案的角色/证据局/账本均已读，原Markdown逐字节复制、SHA与专用队列一致；事件offset/bytes/SHA存proposal-events.json。相关30条账本的只读状态存ledger-before.json。
六局runs.jsonl全部SILENT A10且均失败，完整身份与原行指纹存run-identities.json。各局均code+dirty，因此本批源码只证明当前窄功能，不复原历史dirty全树。无其他角色知识读取或混合统计，未派下级agent。

## 原始证据与限定输入

共用extract_evidence.py一次抽八流，退出0；原stdout/err和evidence-manifest.json保留。8274个封套均逐偏移/长度/SHA256/JSON回读成功。各流逐局计数和source_size在manifest，不把正文提及当身份。
states/decisions/brain各有2个扫描坏行，不知道其所属局，不归给本批或修写原流；其余流扫描无坏行。fight-plans在本次2233957字节截点对六局全0，仅表示该截点未选中，不表示源日志缺失。run-plans按run身份实际取得33条；没有零行旧报告覆盖问题。

按提案房间准备六份有界消费者输入，保留真实原行号、observed_ts、fingerprint和源SHA，不重新编号；全部选中行均有decision_id/observed_ts，consumer-exclusions.json为空。这些是限定房间输入，不宣称六局全历史消费者覆盖。

| 局号 | 分析层 | 状态帧 | 决策 |
|---|---|---:|---:|
{table}

六次现有learner/audit-selection.ts均实际退出0，回执见consumer-receipts.json。合计228个候选片段、1160相邻观测区间、209个轮窗，其中136个轮窗可核端点；所有片段actual_full_candidate_result均null。null表示未认证，不证明完整候选从未执行。
消费者拒绝认证首轮开场（缺前轮结束边界）和SL尝试未知的普通战斗，保持其原门槛；本批另从原首题状态到下一轮帧核YF与XP的T1净变化，未修改消费者或伪造前轮。蚌/棱柱普通战斗的unknown不意味着没有原始帧。

## 核实的关键事实及限制

- 棱柱DUZU F27 T4/T5污染增量3/6与迷雾加毒均可见，末行动9/17挡、12/26攻击，实际净损3/9；次轮污染未列出。污染代价与毒/弱收益共存，不推出禁技能。
- 蚌CA5 F13喷水11/15/19、力量0/4/8、弱后11/14；末2血10挡对14。覆甲减层条件仍未知，不把实际扣2当完整入伤4。
- 5PM F38相同最大血23电击的力量2→4、攻击17→19；F39负属性抵消和失落退出后力量未列出有原帧，但没有完整逐来源候选返还账和稳定实例证明。
- 沙虫8J F33首/三试T2同指纹，实损3/15、扣10/17；原题0/24与5/24死亡样本不同。二试T5护栏后损4扣25不证明原线必省12；末T11整轮损5扣36，行动末154血24毒→终130。显示37−22=15是显示参考，实际只剩5血，未截断完整入伤未知。
- YF F48二/三试T1同指纹，实际损0/9、扣45/38，题面则损0/10、伤54/36。末试4血4毒旧阶段到212新阶段未列毒；触媒2已建仍无现存毒。敏捷5→6时23挡不倒补；末18血23挡对44差3。
- XP F33首/二试T3同指纹，实损9/14、扣24/27，B2均0及diff/se=0不抹掉血价。首/末T1损2/10、扣25/34。末T2轮初14挡、斗篷后20；普通镣铐负9恢复，火箭转向/弱57→38→28；四敏脆弱只6挡，末毒3+7已结后敌剩153/125。

以上全部见52项material-verification.json（52通过、0失败）及所带原帧引用；是材料核验，不是tsc/vitest或新源码红绿。完整原文/层/回合/账本/反例/预期行为/验证/回退逐项在proposal.md。
同存档SL不作独立局，后轮抽弃/生成/洗牌不同不作整战单变量实验；本批不拟血价、HP护栏、SL限制、药价、终局权重或固定杀序。没有新增机制反证/与旧经验冲突；重复的已知限制不新发科学异议通知，也不关闭学习父要求。

## 当前源码与已有窄功能

source-snapshot.json固定base和当时live 6fbbd82abd6d407dbaf93f82639b7f927efa54a0的18叶SHA及逐项祖先检查；15叶同字节，3叶差异仅历史Roy/Dai注释，原patch保存base-live-comment-diff.patch。main的c6e6同步提交不是当时live祖先，不能拿其提交号冒live实现证明；其相同rollout字节与live已有H0源分开记。
已核的实际live祖先窄功能包括：

- 1698adc96ba434a46942321e0237b70657e625b2：SL替换/重放/avoid的当前轮预测资源比较，execution仍unverified。
- 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb：原答/护栏后/SL后的候选审计；fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执，不认证全候选。
- 66283dd9982bdd7f480da7a4d9bfefea0572a9ac：现有护栏审计；aad2700abed6dff1d66e87fb36aaa6fedb39adf3：实验体当前阶段持有/建立/现存毒窄事实；1d57f9d0dbbb63603e9ce9768e74cb2021478464：阶段结束参考。
- a32050fbce4c2863f640468c2dbf378fc9157074：离线相邻观测；83512ddcd2c70fd9b983dc38524ff25c8970c1d3：有限终态端点；e75438488df159b2e8e9d3458cf219b39aadd933：轮窗端点与中间HP路径。

这些子项不用重复实现；其存在不能认证宽提案整体duplicate。已读enemyTable的当前进阶取数路径及ROOM_COST_MIN_N=5，无证据把五样本房间统计门槛加在怪物首次攻击观察上。本批没有调用刷新中的知识JSON作测试，也不声称已冻结旧运行数据库。

## 十项处置

| 原ID | 主题 | 处置 |
|---|---|---|
{result_table}

逐项具体缺数据理由见proposal.md、proposal-results.json和report.json；每项保留waiting，未声称implemented/duplicate或shipped。code_proposals为十个真实原CLI ID，本批不登记重复新ID。implementation_domains=[]因为没有实际实现。

## 验证、记录与回收边界

生产代码/知识差异为零，不创建代码提交，无撤源码红/恢复绿，tsc/vitest/cases全部null；六次消费者与52项材料核验不能替代生产测试。没有live合入、上线记录或eval版本；无实际规则上线，不发送旧新规则双通知。
根账本仅按既有ledger.py CLI追加30条where.proposal和note，以learner:strategy-proposal记本批追溯；不重复support/repeat、不改claim/first_run/prior/asc/evidence/status/version/effect、不降级旧shipped，未标本批shipped。实际CLI回执、前后保护核对和旧前缀SHA另存ledger-link-receipt.json。
首次工具编排有两次JS语法错误（Unexpected token ':'，执行前失败，无shell副作用），已修正；早期rg探索了不存在的agent/test、agent/src/loop.ts、amounts.ts、sim/route.ts，均为路径探索错误，未当产品bug。错误事实保留于process-notes.json及原会话工具记录，不伪称生产红绿。
原日志、封套、消费者输入输出、原提案、账本快照与全部过程材料保留本scratch，不删自身工作树，不关闭宽父或制造自然采用/胜率验收。最终git状态和artifact-manifest.json另存。
'''
(S / 'report.md').write_text(body)
(S / 'process-notes.json').write_text(json.dumps({'tool_composition_failures': [
    {'kind': 'JavaScript SyntaxError', 'message': "Unexpected token ':'", 'count': 2, 'shell_started': False},
], 'read_only_path_search_errors': ['agent/test', 'agent/src/loop.ts', 'agent/src/knowledge/amounts.ts', 'agent/src/sim/route.ts'],
    'production_source_changed': False, 'source_red_green': None}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': BASE, 'proposal_count': len(RESULTS), 'report': str(S / 'report.md')}, ensure_ascii=False))

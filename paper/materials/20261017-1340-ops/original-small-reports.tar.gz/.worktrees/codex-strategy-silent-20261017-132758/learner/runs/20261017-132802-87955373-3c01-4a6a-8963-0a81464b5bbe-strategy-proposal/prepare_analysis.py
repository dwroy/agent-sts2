import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

S = Path(__file__).resolve().parent
FLOORS = {
    'DUZUBAJ3A8GP': {27, 30},
    '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48},
    'XP2SL33HT0D9': {33},
}


def save(name, value):
    (S / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def ref(e):
    return {k: v for k, v in e.items() if k != 'row'}


def powers(items):
    return {p['power_id']: p.get('amount') for p in items or []}


def snapshot(e):
    row = e['row']
    st = row['state']
    run = st.get('run') or {}
    combat = st.get('combat') or {}
    p = combat.get('player') or {}
    return {
        'ref': ref(e), 'observed_ts': row.get('observed_ts'),
        'floor': run.get('floor'), 'turn': st.get('turn'), 'screen': st.get('screen'),
        'hp': p.get('current_hp', run.get('current_hp')), 'block': p.get('block'),
        'energy': p.get('energy'), 'player_powers': powers(p.get('powers')),
        'enemies': [{
            'index': x.get('index'), 'id': x.get('enemy_id'), 'hp': x.get('current_hp'),
            'max_hp': x.get('max_hp'), 'block': x.get('block'), 'alive': x.get('is_alive'),
            'powers': powers(x.get('powers')), 'move_id': x.get('move_id'),
            'intents': x.get('intents'),
        } for x in combat.get('enemies') or []],
    }


def main():
    manifest = json.loads((S / 'evidence/evidence-manifest.json').read_text())
    streams = {}
    verified = []
    for entry in manifest:
        stream = entry['stream']
        p = S / 'evidence' / (stream + '.evidence.jsonl')
        assert hashlib.sha256(p.read_bytes()).hexdigest() == entry['output_sha256']
        data = []
        counts = Counter()
        with p.open() as f, open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as source:
            for line in f:
                e = json.loads(line)
                assert e['run_id'] in FLOORS
                source.seek(e['offset'])
                raw = source.read(e['bytes'])
                assert hashlib.sha256(raw).hexdigest() == e['sha256']
                assert json.loads(raw) == e['row']
                data.append(e)
                counts[e['run_id']] += 1
        assert all(counts[r] == entry['counts'][r] for r in FLOORS)
        streams[stream] = data
        verified.append({'stream': stream, 'source_size': entry['source_size'], 'verified': len(data), 'counts': dict(counts)})
    save('envelope-readback.json', verified)
    states = defaultdict(list)
    decisions = defaultdict(list)
    raw_runs = {e['run_id']: e['row'] for e in streams['runs']}
    for e in streams['states']:
        st = e['row']['state']
        assert st['run_id'] == e['run_id']
        assert st['run']['character_id'].lower() == 'silent' and st['run']['ascension'] == 10
        if st['run']['floor'] in FLOORS[e['run_id']]:
            states[e['run_id']].append(e)
    exclusions = []
    for e in streams['decisions']:
        r = e['row']
        if r.get('floor') not in FLOORS[e['run_id']]:
            continue
        if not r.get('decision_id') or not r.get('observed_ts'):
            exclusions.append({'ref': ref(e), 'reason': 'missing_decision_id_or_observed_ts', 'row': r})
            continue
        decisions[e['run_id']].append(e)
    save('consumer-exclusions.json', exclusions)
    inventory = []
    for run in FLOORS:
        def annotated(e):
            return {**e['row'], '_line': e['line'], '_source_sha256': e['sha256']}
        d = sorted(decisions[run], key=lambda e: (e['row']['observed_ts'], e['line']))
        save('consumer-' + run + '.input.json', {
            'run': raw_runs[run], 'decisions': [annotated(e) for e in d],
            'states': [annotated(e) for e in states[run]],
        })
        projections = [snapshot(e) for e in states[run]]
        save('frames-' + run + '.json', projections)
        slim = []
        for e in d:
            r = e['row']
            slim.append({'ref': ref(e), **{k: r.get(k) for k in [
                'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label', 'decision_id',
                'observed_ts', 'chosen', 'result', 'journal', 'sl_explore', 'hp_guard',
            ]}})
        save('decisions-' + run + '.json', slim)
        inventory.append({'run': run, 'floors': sorted(FLOORS[run]), 'states': len(states[run]),
                          'decisions': len(d), 'exclusions': sum(e['ref']['run_id'] == run for e in exclusions)})
    save('consumer-input-inventory.json', inventory)
    save('attempts.json', streams['sl-attempts'])
    print(json.dumps({'verified_envelopes': sum(e['verified'] for e in verified), 'inputs': inventory}, ensure_ascii=False))


if __name__ == '__main__':
    main()

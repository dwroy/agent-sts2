import json
from pathlib import Path

S = Path(__file__).resolve().parent
RUNS = json.loads((S / 'dispatch.json').read_text())['runs']
FRAMES = {r: {x['ref']['line']: x for x in json.loads((S / ('frames-' + r + '.json')).read_text())} for r in RUNS}
INPUTS = {r: json.loads((S / ('consumer-' + r + '.input.json')).read_text()) for r in RUNS}
AUDITS = {r: json.loads((S / ('consumer-' + r + '.output.json')).read_text()) for r in RUNS}
CHECKS = []


def check(label, actual, expected, refs=()):
    CHECKS.append({'label': label, 'actual': actual, 'expected': expected,
                   'pass': actual == expected, 'refs': list(refs)})


def f(run, line):
    return FRAMES[run][line]


def e(run, line, ident=None):
    enemies = f(run, line)['enemies']
    return enemies[0] if ident is None else next(x for x in enemies if x['id'] == ident)


def atk(enemy):
    return sum(x.get('total_damage') or 0 for x in enemy['intents'] or [])


def dec(run, line):
    return next(x for x in INPUTS[run]['decisions'] if x['_line'] == line)


def refs(run, lines):
    return [f(run, line)['ref'] for line in lines]


r = 'DUZUBAJ3A8GP'
lines = [274830, 274831, 274832, 274833, 274834, 274836, 274837, 274838, 274839]
check('棱柱技能污染与次轮不列出污染', [f(r, n)['player_powers'].get('TAINTED_POWER') for n in lines],
      [None, 3, 3, 6, None, 6, 12, 18, None], refs(r, lines))
check('棱柱火花跨轮3到6', [e(r, n)['powers']['VITAL_SPARK_POWER'] for n in [274830, 274834]], [3, 6], refs(r, [274830, 274834]))
check('棱柱T4已见毒2到8与T5的7到13', [e(r, n)['powers']['POISON_POWER'] for n in [274830, 274831, 274834, 274838]], [2, 8, 7, 13], refs(r, [274830, 274831, 274834, 274838]))
check('棱柱T4和T5净损3和9', [f(r, 274830)['hp'] - f(r, 274834)['hp'], f(r, 274834)['hp'] - f(r, 274839)['hp']], [3, 9], refs(r, [274830, 274834, 274839]))
check('棱柱末行动挡9和17、显示攻击12和26', [[f(r, n)['block'], atk(e(r, n))] for n in [274833, 274838]], [[9, 12], [17, 26]], refs(r, [274833, 274838]))

r = 'CA5KE8GFJ9X2'
lines = [273237, 273252, 273263]
check('蚌喷水已见力量与攻击', [[e(r, n)['powers'].get('STRENGTH_POWER', 0), atk(e(r, n))] for n in lines], [[0, 11], [4, 15], [8, 19]], refs(r, lines))
check('蚌后轮覆甲9/8/7/6', [e(r, n)['powers']['PLATING_POWER'] for n in [273247, 273252, 273258, 273263]], [9, 8, 7, 6], refs(r, [273247, 273252, 273258, 273263]))
for turn, expected in [(3, 11), (5, 14)]:
    weak = [x for x in FRAMES[r].values() if x['screen'] == 'COMBAT' and x['turn'] == turn and e(r, x['ref']['line'])['powers'].get('WEAK_POWER', 0) > 0]
    check('蚌T' + str(turn) + '施弱后显示攻击', atk(weak[0]['enemies'][0]), expected, [weak[0]['ref']])
last = [x for x in FRAMES[r].values() if x['screen'] == 'COMBAT' and x['turn'] == 5][-1]
check('蚌死亡前仅2血10挡与14攻击', [last['hp'], last['block'], atk(last['enemies'][0])], [2, 10, 14], [last['ref']])

r = '5PM6JAQG6FNQ'
zap = []
for turn in [3, 4]:
    d = next(x for x in INPUTS[r]['decisions'] if x['floor'] == 38 and x['turn'] == turn and x['label'].startswith('combat/plan-choice'))
    state = next(x for x in INPUTS[r]['states'] if x['observed_ts'] == d['observed_ts'] and x['fingerprint'] == d['fingerprint'])
    zap.append(f(r, state['_line']))
check('电击相同最大血23、增长2到4且攻击17到19', [[e(r, x['ref']['line'], 'ZAPBOT')['max_hp'], e(r, x['ref']['line'], 'ZAPBOT')['powers']['STRENGTH_POWER'], atk(e(r, x['ref']['line'], 'ZAPBOT'))] for x in zap], [[23, 2, 17], [23, 4, 19]], [x['ref'] for x in zap])
check('组装师T3到T4玩家净损30', zap[0]['hp'] - zap[1]['hp'], 30, [x['ref'] for x in zap])
check('首试两步法的敏捷负4到负2到未列出', [f(r, n)['player_powers'].get('DEXTERITY_POWER') for n in [274351, 274352, 274354]], [-4, -2, None], refs(r, [274351, 274352, 274354]))
check('首试失落毒杀端点前后力量负4到未列出', [f(r, n)['player_powers'].get('STRENGTH_POWER') for n in [274357, 274358]], [-4, None], refs(r, [274357, 274358]))
check('首试T6遗忘再抢后玩家负2敏捷、敌6敏捷', [f(r, 274362)['player_powers']['DEXTERITY_POWER'], e(r, 274362)['powers']['DEXTERITY_POWER']], [-2, 6], refs(r, [274362]))
check('末试单步法只从负4到负2敏捷', [f(r, n)['player_powers']['DEXTERITY_POWER'] for n in [274391, 274392]], [-4, -2], refs(r, [274391, 274392]))

for r, a, b in [('8JRE1C4H4Z2W', 270216, 270282), ('YF0LXT1QSTGG', 271309, 271348), ('XP2SL33HT0D9', 271992, 272040), ('XP2SL33HT0D9', 271982, 272195)]:
    check(r + '相同原指纹' + str(a) + '/' + str(b), dec(r, a)['fingerprint'] == dec(r, b)['fingerprint'], True,
          [{'stream': 'decisions', 'line': a}, {'stream': 'decisions', 'line': b}])

for r, attempt, turn, loss, damage in [
    ('8JRE1C4H4Z2W', 1, 2, 3, 10), ('8JRE1C4H4Z2W', 3, 2, 15, 17),
    ('8JRE1C4H4Z2W', 2, 5, 4, 25), ('XP2SL33HT0D9', 1, 3, 9, 24), ('XP2SL33HT0D9', 2, 3, 14, 27),
]:
    row = next(x for x in AUDITS[r]['observed_turns'] if x['floor'] == 33 and x['attempt'] == attempt and x['turn'] == turn)
    facts = row['facts'] or {}
    check(r + '整轮观测' + str(attempt) + '/' + str(turn),
          [row['status'], -facts['player_hp_delta'], -sum(x['hp_delta'] for x in facts['enemy_hp_changes'])],
          ['observed_turn_endpoints', loss, damage], refs(r, [facts['before']['source_line'], facts['after']['source_line']]))

for r, a, b, loss, damage in [('YF0LXT1QSTGG', 277327, 277337, 0, 45), ('YF0LXT1QSTGG', 277366, 277373, 9, 38), ('XP2SL33HT0D9', 278017, 278023, 2, 25), ('XP2SL33HT0D9', 278231, 278236, 10, 34)]:
    check(r + '首题到T2原帧净变化' + str(a), [f(r, a)['hp'] - f(r, b)['hp'], sum(x['hp'] for x in f(r, a)['enemies']) - sum(x['hp'] for x in f(r, b)['enemies'])], [loss, damage], refs(r, [a, b]))

r = 'YF0LXT1QSTGG'
check('实验体阶段4血4毒到新阶段212血且未列出毒', [[e(r, n)['hp'], e(r, n)['max_hp'], e(r, n)['powers'].get('POISON_POWER')] for n in [277512, 277513]], [[4, 111, 4], [212, 212, None]], refs(r, [277512, 277513]))
check('实验体触媒2已建而未列出毒', [f(r, 277519)['player_powers']['ACCELERANT_POWER'], e(r, 277519)['powers'].get('POISON_POWER')], [2, None], refs(r, [277519]))
check('苦无后来5到6敏捷不倒补23挡', [[f(r, n)['player_powers']['DEXTERITY_POWER'], f(r, n)['block']] for n in [277524, 277526]], [[5, 23], [6, 23]], refs(r, [277524, 277526]))
check('实验体末轮18血23挡对44攻击', [f(r, 277527)['hp'], f(r, 277527)['block'], atk(e(r, 277527))], [18, 23, 44], refs(r, [277527]))

r = 'XP2SL33HT0D9'
check('双蟹末试T2轮初14挡与斗篷后20挡', [f(r, n)['block'] for n in [278236, 278240]], [14, 20], refs(r, [278236, 278240]))
check('普通镣铐负9与T3未列出力量', [e(r, n, 'CRUSHER')['powers'].get('STRENGTH_POWER') for n in [278237, 278242]], [-9, None], refs(r, [278237, 278242]))
check('双蟹激光转向与虚弱57到38到28', [atk(e(r, n, 'ROCKET')) for n in [278249, 278252, 278253]], [57, 38, 28], refs(r, [278249, 278252, 278253]))
check('双蟹脆弱四敏捷只6挡', [f(r, 278255)['player_powers']['DEXTERITY_POWER'], f(r, 278255)['block']], [4, 6], refs(r, [278255]))
check('双蟹末轮已结毒3和7，敌剩153和125', [[e(r, 278260, ident)['powers']['POISON_POWER'], e(r, 278261, ident)['hp']] for ident in ['CRUSHER', 'ROCKET']], [[3, 153], [7, 125]], refs(r, [278260, 278261]))

r = '8JRE1C4H4Z2W'
check('沙虫末轮显示37攻击、22挡、仅5血', [atk(e(r, 276433)), f(r, 276433)['block'], f(r, 276433)['hp']], [37, 22, 5], refs(r, [276433]))
check('沙虫末轮末段24毒结算、本体154到130、玩家到零', [e(r, 276433)['powers']['POISON_POWER'], e(r, 276433)['hp'], e(r, 276434)['hp'], f(r, 276434)['hp']], [24, 154, 130, 0], refs(r, [276433, 276434]))
for r in RUNS:
    check(r + '消费者不认证完整候选', all(x['actual_full_candidate_result'] is None for x in AUDITS[r]['segments']), True)
    check(r + '限定房间输入未删除元数据', sum(x['ref']['run_id'] == r for x in json.loads((S / 'consumer-exclusions.json').read_text())), 0)

result = {'scope': 'frozen_material_checks_not_production_tests', 'checks': len(CHECKS),
          'failures': sum(not x['pass'] for x in CHECKS), 'results': CHECKS}
(S / 'material-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'results'}, ensure_ascii=False))
raise SystemExit(1 if result['failures'] else 0)

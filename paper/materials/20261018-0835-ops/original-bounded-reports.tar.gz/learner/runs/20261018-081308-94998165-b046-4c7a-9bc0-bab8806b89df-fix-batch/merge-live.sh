#!/usr/bin/env bash
set -u
export PATH="$HOME/.local/node/bin:$PATH"
export npm_config_offline=true
live=/home/dw/Projects/agent-sts2/.worktrees/live
source_tree=/home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261018-081302
source_branch=codex-fix-silent-20261018-081302
source_commit=$(git -C "$source_tree" rev-parse HEAD) || exit 2
cd "$live" || exit 2
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git status --short > "$TMPDIR/live-status-before.txt"
git diff --cached --quiet || { echo 'Live index already contains staged changes'; exit 70; }
git rev-parse HEAD > "$TMPDIR/live-initial-head.txt"
git diff --name-only -- knowledge notes/fight-value-backtest.md > "$TMPDIR/live-refreshed-paths.txt"
git add notes/fight-value-backtest.md knowledge || exit 2
if ! git diff --cached --quiet; then
  git diff --cached --binary | nice -n 19 gitleaks stdin --no-banner --redact > "$TMPDIR/gitleaks-live-refresh.log" 2>&1 || exit 71
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>' > "$TMPDIR/live-refresh-commit.log" 2>&1 || exit 2
fi
before=$(git rev-parse HEAD) || exit 2
printf '%s\n' "$before" > "$TMPDIR/live-before-merge.txt"
base=$(git merge-base "$before" "$source_commit") || exit 2
python3 - "$base" "$source_commit" "$TMPDIR" <<'PY'
from pathlib import Path
import json,subprocess,sys
base,source,scratch=sys.argv[1:]
fresh=set((Path(scratch)/'live-refreshed-paths.txt').read_text().splitlines())
incoming=set(subprocess.check_output(['git','diff','--name-only',base,source,'--','knowledge','notes/fight-value-backtest.md'],text=True).splitlines())
(Path(scratch)/'live-knowledge-overlap.json').write_text(json.dumps({'merge_base':base,'refreshed_paths':sorted(fresh),'incoming_paths':sorted(incoming),'overlap':sorted(fresh&incoming)},indent=2)+'\n')
PY
git merge-tree --write-tree --name-only --messages "$before" "$source_commit" > "$TMPDIR/live-merge-preflight.txt" 2>&1
preflight=$?
printf '%s\n' "$preflight" > "$TMPDIR/live-merge-preflight.exit"
if [ "$preflight" -ne 0 ]; then
  git status --short > "$TMPDIR/live-status-after.txt"
  git rev-parse HEAD > "$TMPDIR/live-final-head.txt"
  echo 'Merge preflight found conflicts; live index and working files left intact.'
  sed -n '1,42p' "$TMPDIR/live-merge-preflight.txt"
  exit 3
fi
git merge --no-edit "$source_branch" > "$TMPDIR/live-merge.log" 2>&1
merged=$?
if [ "$merged" -ne 0 ]; then
  git diff --name-only --diff-filter=U > "$TMPDIR/live-merge-conflicts.txt"
  if git rev-parse -q --verify MERGE_HEAD >/dev/null; then git merge --abort || exit 72; fi
  git rev-parse HEAD > "$TMPDIR/live-final-head.txt"
  exit 4
fi
cd agent || exit 2
bash tools/test-sandbox.sh > "$TMPDIR/sandbox-live.log" 2>&1
checks=$?
printf '%s\n' "$checks" > "$TMPDIR/sandbox-live.exit"
cd .. || exit 2
if [ "$checks" -ne 0 ]; then
  git reset --merge "$before" > "$TMPDIR/live-rollback.log" 2>&1 || exit 73
  git rev-parse HEAD > "$TMPDIR/live-final-head.txt"
  exit 5
fi
date
source_commit="$source_commit" python3 - <<'PY'
from pathlib import Path
from datetime import datetime
import os
stamp=datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')
line=f'\n- {stamp} 学习者fix-batch：队列21bf-fake-herdr-workspace-deadline的fake herdr未回收退出进程忙碌误判窄修已合live，源码{os.environ["source_commit"]}；固定进程状态撤修1/恢复0，源及合后沙箱0。来源20261018-070101-fix-batch/tree21bf5842，游戏局号/层/回合及对应bug-infra账本无；仅测试夹具，无游戏行为发布号；原15秒宿主超时根因仍未知，旧full1与其他父项保留。\n'
with Path('paper/materials/decision-log.md').open('a') as out: out.write(line)
PY
git add paper/materials/decision-log.md || exit 2
git diff --cached --binary | nice -n 19 gitleaks stdin --no-banner --redact > "$TMPDIR/gitleaks-live-record.log" 2>&1 || exit 71
git commit -m 'Record fake herdr exited-process fixture deployment' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>' > "$TMPDIR/live-record-commit.log" 2>&1 || exit 2
git rev-parse HEAD > "$TMPDIR/live-final-head.txt"
git status --short > "$TMPDIR/live-status-after.txt"
echo 'Live merge and checks completed.'

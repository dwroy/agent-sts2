import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')


def git(where, *args):
    return subprocess.check_output(['git', '-C', str(where), *args])


base = git(ROOT, 'rev-parse', 'HEAD').decode().strip()
live_head = git(LIVE, 'rev-parse', 'HEAD').decode().strip()
paths = ['agent/src/reflex/' + name + '.ts' for name in (
    'silent-sl-resource-comparison', 'silent-sl-comparison', 'silent-held-loss', 'silent-potion-reference',
    'silent-selection-audit', 'silent-selection-dispatch', 'silent-giant-potion',
    'combat-plan', 'potion-cost', 'turn-solver')]
paths += ['agent/src/sl/attempts.ts', 'agent/src/sl/explore.ts', 'agent/src/hand/loop.ts']
items = []
for path in paths:
    before = git(ROOT, 'show', base + ':' + path)
    deployed = git(LIVE, 'show', live_head + ':' + path)
    source = git(LIVE, 'log', '-1', '--format=%H', live_head, '--', path).decode().strip()
    ancestor = subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', source, live_head],
                              capture_output=True).returncode == 0
    assert ancestor and git(LIVE, 'show', source + ':' + path) == deployed
    item = {'path': path, 'base_sha256': hashlib.sha256(before).hexdigest(),
            'live_sha256': hashlib.sha256(deployed).hexdigest(), 'base_live_equal': before == deployed,
            'live_workspace_equal': (LIVE / path).read_bytes() == deployed,
            'actual_live_ancestor_commit': source, 'ancestor_verified': ancestor}
    if before != deployed:
        patch = git(ROOT, 'diff', '--binary', base, live_head, '--', path)
        target = OUT / (Path(path).name + '.base-live.patch')
        target.write_bytes(patch)
        item['diff'] = str(target)
    items.append(item)
(OUT / 'source-audit.json').write_text(json.dumps({'base': base, 'live_head': live_head, 'files': items},
                                               ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'live_head': live_head, 'files': len(items),
                  'equal': sum(i['base_live_equal'] for i in items),
                  'deployed_workspace_equal': all(i['live_workspace_equal'] for i in items)}, ensure_ascii=False))

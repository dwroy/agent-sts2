import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'learner'))
from extract_evidence import run_identity

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT / 'evidence'
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
RUNS = DISPATCH['runs']


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def ref(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def state_projection(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'source': ref(item), 'ts': item['row']['ts'],
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'block': player.get('block'),
        'energy': player.get('energy'), 'player_powers': player.get('powers'),
        'potions': run.get('potions'),
        'hand': [{k: c.get(k) for k in ('index', 'card_id', 'is_upgraded', 'upgraded', 'dynamic_values')}
                 for c in combat.get('hand') or []],
        'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block',
                                         'is_alive', 'move_id', 'powers', 'intents')}
                    for e in combat.get('enemies') or []],
    }


selected_decisions = {
    272361, 272362, 272434, 272575, 272531, 272652,
    274087, 274131, 274156, 274185, 274235, 274237, 274267, 274272,
    274354, 274484, 274601, 274505, 274568,
}
selected_states = {
    278383, 278403, 278404, 278405, 278406, 278407,
    280160, 280161, 280162, 280206, 280207, 280232, 280233,
    280262, 280263, 280313, 280314, 280315, 280316,
    280348, 280349, 280354, 280355,
}
manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
checks, states, decisions, attempts, configs, run_rows = [], {}, {}, [], [], []
for stream in manifest:
    name = stream['stream']
    file = EVIDENCE / (name + '.evidence.jsonl')
    counts = dict.fromkeys(RUNS, 0)
    digest = hashlib.sha256()
    with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source, file.open('rb') as extracted:
        for encoded in extracted:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['source'] == str(source.name)
            assert item['run_id'] in RUNS
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert run_identity(item['row']) == item['run_id']
            counts[item['run_id']] += 1
            row = item['row']
            if name == 'states':
                run = row['state'].get('run') or {}
                if run:
                    assert run.get('character_id') == 'SILENT'
                    assert run.get('ascension') == 10
                if item['line'] in selected_states:
                    states[item['line']] = state_projection(item)
            elif name == 'decisions':
                if item['line'] in selected_decisions:
                    decisions[item['line']] = {'source': ref(item), 'row': row}
            elif name == 'sl-attempts':
                attempts.append({'source': ref(item), 'row': row})
            elif name == 'run-config':
                assert row['character'] == 'SILENT' and row['ascension'] == 10
                configs.append({'source': ref(item), 'row': row})
            elif name == 'runs':
                assert row['character'] == 'SILENT' and row['ascension'] == 10
                assert row['ended'] and row['victory'] is False
                run_rows.append({'source': ref(item), 'row': row})
    assert counts == stream['counts']
    assert digest.hexdigest() == stream['output_sha256']
    checks.append({'stream': name, 'counts': counts, 'verified_rows': sum(counts.values()),
                   'source_size': stream['source_size'], 'sha256': digest.hexdigest()})
assert len(run_rows) == len(RUNS) and len(configs) == len(RUNS)
assert set(states) == selected_states and set(decisions) == selected_decisions
save('evidence-verification.json', {'streams': checks, 'verified_rows': sum(c['verified_rows'] for c in checks),
                                   'explicit_identity_verified': True, 'raw_bytes_verified': True,
                                   'all_run_characters': 'SILENT', 'all_ascensions': 10})
save('selected-state-projections.json', states)
save('selected-decisions.json', decisions)
save('attempts.json', attempts)

pairs = [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601)]
pair_results = []
for a, b in pairs:
    ra, rb = decisions[a]['row'], decisions[b]['row']
    assert ra['fingerprint'] == rb['fingerprint']
    pair_results.append({'a': a, 'b': b, 'run_id': ra['run_id'], 'floor': ra['floor'], 'turn': ra['turn'],
                         'identical_fingerprint': True,
                         'answers': [ra.get('answers'), rb.get('answers')],
                         'chosen': [ra.get('chosen'), rb.get('chosen')],
                         'sl_explore': [ra.get('sl_explore'), rb.get('sl_explore')]})
save('paired-decisions.json', pair_results)

summary = []
for item in attempts:
    row = item['row']
    turns = (row.get('summary') or {}).get('turns') or []
    relevant = []
    wanted = {'751FN9QM9MHQ': [2, 3, 7, 8, 13, 14, 17], 'KV0JHNJCKXLS': [1, 2, 4, 5, 6, 10],
              'KEN58SH9SLZ6': [2, 3, 5, 6, 8, 9, 10, 11, 12, 13, 15]}.get(row['run_id'], [])
    for turn in turns:
        if turn['turn'] in wanted or '999999' in turn.get('enemies', ''):
            relevant.append(turn)
    summary.append({'source': item['source'], **{k: row.get(k) for k in ('run_id', 'floor', 'encounter', 'attempt',
                    'result', 'turns', 'end_hp', 'end_block', 'incoming')}, 'selected_turns': relevant})
save('attempt-summary.json', summary)
assert run_identity({'run_id': RUNS[0], 'run': RUNS[1]}) is None
assert run_identity({'rationale': RUNS[0]}) is None
assert run_identity({'run': RUNS[0]}) == RUNS[0]
print(json.dumps({'verified_rows': sum(c['verified_rows'] for c in checks), 'selected_states': len(states),
                  'selected_decisions': len(decisions), 'paired_fingerprints': len(pair_results)}, ensure_ascii=False))

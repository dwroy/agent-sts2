import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
attempts = json.loads((OUT / 'attempts.json').read_text())
states = json.loads((OUT / 'selected-state-projections.json').read_text())
decisions = json.loads((OUT / 'selected-decisions.json').read_text())
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})


def attempt(run, floor, number):
    return next(a['row'] for a in attempts if a['row']['run_id'] == run and
                a['row']['floor'] == floor and a['row']['attempt'] == number)


def delta(run, floor, number, turn):
    row = attempt(run, floor, number)
    a = next(t for t in row['summary']['turns'] if t['turn'] == turn)
    b = next(t for t in row['summary']['turns'] if t['turn'] == turn + 1)
    hp = lambda t: int(re.search(r' (\d+)/\d+$', t['enemies'])[1])
    return [a['hp'] - b['hp'], hp(a) - hp(b)]


for run, number, turn, expected in [
    ('751FN9QM9MHQ', 1, 2, [13, 9]), ('751FN9QM9MHQ', 3, 2, [18, 18]),
    ('751FN9QM9MHQ', 2, 7, [13, 12]), ('751FN9QM9MHQ', 4, 7, [23, 18]),
    ('751FN9QM9MHQ', 1, 13, [8, 17]), ('751FN9QM9MHQ', 6, 13, [2, 11]),
    ('KEN58SH9SLZ6', 4, 10, [15, 2]), ('KEN58SH9SLZ6', 5, 10, [21, 4]),
    ('KEN58SH9SLZ6', 4, 5, [7, 1]), ('KEN58SH9SLZ6', 6, 5, [5, 2]),
]:
    check(f'{run} F17 attempt{number} T{turn} 净端点', delta(run, 17, number, turn), expected)
for number, expected in [(4, [0, 36]), (5, [0, 29])]:
    check(f'KV F33 attempt{number} T5 净端点', delta('KV0JHNJCKXLS', 33, number, 5), expected)
for number, expected in [(1, [0, 28]), (6, [0, 14])]:
    check(f'KV F33 attempt{number} T1 净端点', delta('KV0JHNJCKXLS', 33, number, 1), expected)
additional = {item['line']: item for item in json.loads((OUT / 'additional-pair-decisions.json').read_text())}
for a, b in [(272483, 272820), (273400, 273450), (273242, 273474)]:
    check(f'd{a}/d{b} 同指纹', additional[a]['row']['fingerprint'] == additional[b]['row']['fingerprint'], True)

drinks = []
for decision, before, after, slot, potion in [
    (274131, 280206, 280207, 0, 'ATTACK_POTION'),
    (274156, 280232, 280233, 0, 'STABLE_SERUM'),
    (274185, 280262, 280263, 0, 'SPEED_POTION'),
    (274235, 280313, 280314, 1, 'WEAK_POTION'),
    (274237, 280315, 280316, 0, 'ATTACK_POTION'),
    (274267, 280348, 280349, 1, 'GLOWWATER_POTION'),
    (274272, 280354, 280355, 0, 'SKILL_POTION'),
]:
    a, b = states[str(before)], states[str(after)]
    pick = lambda frame: next(p for p in frame['potions'] if p['index'] == slot)
    check(f'd{decision} 饮用前药水', pick(a)['potion_id'], potion)
    check(f'd{decision} 饮用后槽位', pick(b)['occupied'], False)
    row = decisions[str(decision)]['row']
    check(f'd{decision} 动作', [row['chosen']['action'], row['chosen']['option_index']], ['use_potion', slot])
    drinks.append({'decision_line': decision, 'state_lines': [before, after], 'slot': slot, 'potion': potion,
                   'receipt': row['result'], 'hp_before': a['hp'], 'hp_after': b['hp'],
                   'scope': '槽位耗用已核；完整候选收益未核'})

for line, poison in [('280160', 2), ('280161', 8)]:
    state = states[line]
    enemy = state['enemies'][0]
    amount = next(p['amount'] for p in enemy['powers'] if p['power_id'] == 'POISON_POWER')
    check(f's{line} 巨兽末态', [state['hp'], state['block'], enemy['intents'][0]['total_damage'], amount],
          [26, 13, 41, poison])
plan = decisions['272361']['row']['questions']['plan']['criteria']
wet, dry = json.loads(plan['plan2']), json.loads(plan['plan5'])
check('751 F13 T3 两候选损血', [wet['hp_lost'], dry['hp_lost']], [8, 8])
check('751 F13 T3 两候选牌伤', [wet['damage_dealt'], dry['damage_dealt']], [26, 16])
check('751 F13 T3 整战无药参考', 'later turns drink no potion' in dry['rollout'], True)
check('751 F13 T3 本轮无药线后续仍饮用', 'FLEX_POTION in 7/8 samples' in json.loads(plan['plan3'])['potion_cost'], True)
check('PU F17 第5试确实获胜', attempt('PU80F84P6HPN', 17, 5)['result'], 'won')
check('PU F17 获胜末血', attempt('PU80F84P6HPN', 17, 5)['end_hp'], 2)

windows = {number: attempt('KEN58SH9SLZ6', 17, number) for number in range(1, 7)}
first_dex = {}
entry = {}
with (OUT / 'evidence/states.evidence.jsonl').open() as handle:
    for line in handle:
        item = json.loads(line)
        if item['run_id'] != 'KEN58SH9SLZ6':
            continue
        row = item['row']
        state = row['state']
        if (state.get('run') or {}).get('floor') != 17 or not state.get('in_combat'):
            continue
        for number, window in windows.items():
            if not window['started_at'] <= row['ts'] <= window['ended_at']:
                continue
            if state['turn'] == 1 and number not in entry:
                entry[number] = {'line': item['line'], 'hp': state['combat']['player']['current_hp'],
                                 'potions': state['run']['potions']}
            dex = [p['amount'] for p in state['combat']['player']['powers'] if p['power_id'] == 'DEXTERITY_POWER']
            if dex == [2] and number not in first_dex:
                first_dex[number] = {'line': item['line'], 'turn': state['turn'], 'amount': 2}
check('KEN 第4试能力首次真实建立', first_dex[4]['turn'], 5)
check('KEN 第6试能力首次真实建立', first_dex[6]['turn'], 9)
for number in range(1, 7):
    check(f'KEN 第{number}试 boss 入口', [entry[number]['hp'], any(p['occupied'] for p in entry[number]['potions'])], [75, False])

result = {'scope': '固定日志材料断言，不是生产源码测试或模拟校准', 'checks': checks,
          'assertions': len(checks), 'drinks': drinks, 'ken_first_dexterity': first_dex, 'ken_entries': entry}
(OUT / 'fixed-material-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'assertions': len(checks), 'drinks': len(drinks), 'ken_first_dexterity': first_dex}, ensure_ascii=False))

import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
queue = json.loads((OUT / 'queue-snapshot.json').read_text())['original']
source = json.loads((OUT / 'source-audit.json').read_text())
verification = json.loads((OUT / 'evidence-verification.json').read_text())
fixed = json.loads((OUT / 'fixed-material-verification.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(now)
assert base == source['base'] == 'f67a7fb93826192772cd73f1ce833c363d32980e'
assert dispatch['task'] == 'strategy-proposal' and dispatch['character'] == 'silent'
assert not dispatch.get('research_request') and not dispatch.get('implementation_request')
assert len(dispatch['proposal_ids']) == 10
reasons = [
    '751 F17 T2/T7/T13同指纹血价已核；live已有候选预测审计，完整执行归属仍为空。缺跨抽弃续问的完整候选实果、受控整战后继及独立后期校准，不能拟额外失血准入阈值。',
    '751 F13 T3有药与整战无药参考均预测损8且8/8结束，但只实打喝药；live已有持有价值未知与未决弃牌拆项。缺无药、留药至boss的完整分支和实际候选归属，不能拟持有价值或改变弃牌。',
    '原经验提案覆盖751同局六次SL；局部成本与持牌事实已有实现，六次全败不能作六局独立验证。缺完整候选实果及保持后继受控的整战比较，不将局部审计当全部实现。',
    '751能力、毒/反伤、持牌损血与药水已有部分预测拆项，未决弃牌不能当必然失血。缺逐源实际兑现与抽弃后完整执行、跨战无药/留药对照，不能关闭全部经验关联。',
    'KV F33 T5同指纹删毒净扣36→29、均零损；T1删输出净扣28→14、均零损。缺完整候选末端、受控后继整战和独立回血毛伤核验，未执行路线/休息分支仍未知，不设SL或回血门槛。',
    '三巨兽局的占位血与自爆阶段已核；live已有阶段/末态资源展示，anchorRank仍按原存活轮与原残血排序。缺新排序的受控完整后继和独立最终资源校准，不将局部阶段实现当整项duplicate。',
    'YQL F17末次T10毒药使残壳毒2→8，但26血/13挡/自爆41不变；PU F17第5试确实获胜，不能据全局失败否认它。缺提前喝、不喝、留药和新SL排序的受控整战对照，跨战药值未知。',
    'KEN七次耗药与六次F17入口75血空栏均由原状态复核，三条pending回执另由槽位补证。缺随机选牌/发光水续问后完整候选收益，以及F15不喝或留药至boss的分支。',
    'KEN F17 T10同指纹多损6仅多净扣2；T5省2却把2敏捷首次建立由T5推迟到T9。缺完整逐源兑现、受控整战后继与独立校准，不能改变探索准入或HP护栏。',
    'KEN原经验提案的两向成本已核，六次相关尝试不作独立训练/验证。live预测及单动作回执不等于完整实果；缺后继受控的反事实和新局验证，不拟统一血价或关闭原提案。',
]
evidence = [
    '751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820',
    '751FN9QM9MHQ F13 T3、F17 T7；d272361/272362，s278403–278407',
    '751FN9QM9MHQ F17 T2/T7/T13；原经验版本及账本链接保留',
    '751FN9QM9MHQ F13 T3、F17 T7/T13/T17；原经验关联保留',
    'KV0JHNJCKXLS F33 T1/T5；d273242/273474、273400/273450，另有续问d273451/273480',
    'L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17/T15；YQL8RZ8BWN1E F17 T10/T13',
    'YQL8RZ8BWN1E F17 T10 s280160/280161；PU80F84P6HPN F17第5试T15',
    'KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1,T2/F15T1；七组原帧见fixed-material-verification.json',
    'KEN58SH9SLZ6 F17 T5/T10；d274484/274601、274505/274568；敏捷实帧s280569/280702',
    'KEN58SH9SLZ6 F17 T5/T10；原经验关联与账本保留',
]
results = [{'id': ident, 'state': 'waiting', 'reason': reason}
           for ident, reason in zip(dispatch['proposal_ids'], reasons)]
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
table = ['| 原提案 id | 证据局号、层、回合 | 既有账本 | 本批处置与缺口 |',
         '|---|---|---|---|']
for i, result in enumerate(results):
    a = queue[result['id']]
    table.append('| ' + result['id'] + ' | ' + evidence[i] + ' | ' + '、'.join(a['ledger']) +
                 ' | waiting：' + result['reason'] + ' |')

proposal = f'''# 本批十个已领取策略提案的证据复核与等待条件

记录时间：{now}。来源及实现任务 strategy-proposal；角色 silent；已核实进阶 A10；batch=20261015-063022-strategy-proposal；基线 `{base}`。本批仅消费十个原 CLI id，不新建重复提案，不领取其他队列。

本批没有 research_request / implementation_request / proposal_repair，reason=proposal；根目录牌数专题绑定的是另一个批次，未读取其任务正文或冻结输入。普通流程已执行 `git merge --no-edit main`，结果 Already up to date。

十个原 Markdown 均存在、逐字节 SHA 与原队列一致；原文副本和指纹见 original-proposals-manifest.json。以下是一份复核总表，不冒称新增已验证策略。

{chr(10).join(table)}

## 旧行为、可考虑的新行为及本次结论

旧行为包括现行SL探索、HP护栏、药水成本和最长存活优先的参考路径排序。当前 live 已提供 `resource_comparison/current_turn_prediction`、`candidate_comparison/candidate_forecast`、未决持牌失血、同题无药参考、巨兽阶段，以及单动作派发回执；它们明确保留 actual_turn_result / actual_turn / whole_plan_executed 的未知，不是完整候选实果。

原提案考虑的下一步为完整归属候选被哪些实际动作执行、在哪次抽弃/用药重问被截断，分列净HP、未封顶入伤、持牌自损、已兑现输出、能力建立、敌回血、药水/复活；同时验证探索血价、药水持有价值和阶段排序的后续收益。本批尚无保持后续动作与抽序受控的整战资料，也没有可独立校准的新后期验证局，保留原行为。局部事实展示的既有实现不能关闭整项。

反例必须共同保留：751 T13保血同时少输出；KEN T10增加损血而仅增少量净输出，T5保血却推迟能力；PU巨兽第5试获胜，但多轮换线同时发生，不能归单步；YQL残壳加毒未改变当前41来袭，却不证明提前喝或留药没有价值。未观察分支不记0，也不推导统一血量价格。

## 预期行为与验证入口

后续只有在取得完整候选执行链与受控后继后才验证策略。相同观测盘面冻结原答/护栏后/SL后/派发动作/实际状态，按重问边界区分已执行与未执行续步；候选对照保存抽序、敌阶段、药水、复活和伤害来源。同一局SL只能在同一数据分区；更早独立 silent 局用于核公式或拟合，时间更晚的新局单独验证。相同推演保留并列与所有合法选项，不把模拟候选当真实反事实。

各项验证先复现表列局/层/回合的局部事实，再检查完整战斗及跨战资源。净敌血差不能代替回血后的毛输出，净玩家HP不能代替未封顶敌伤；占位体扣血不能作本体进度，本体结束也不当整战胜利。没有足够数据就继续 waiting，不设置5/6/10等数值门槛。

本次只形成材料验证和待数据清单，预期影响是可追溯地保留原提案；无已验证胜率收益。未修改源码或知识，故无行为回退提交。以后实现必须独立提交、固定红绿验证、自测及实际live合入，实际规则上线再双通知Roy；既有授权 Roy-2026-10-07-learning 不当作游戏事实。
'''
(OUT / 'proposal.md').write_text(proposal)

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
stream_table = ['| 流 | 冻结 source_size（字节） | 本批选中行数 |', '|---|---:|---:|']
for item in manifest:
    stream_table.append(f"| {item['stream']} | {item['source_size']} | {sum(item['counts'].values())} |")
source_table = ['| 当前 live 源码 | 实际 live 祖先提交 | 与本批base是否同字节 |', '|---|---|---|']
for item in source['files']:
    source_table.append('| ' + item['path'] + ' | ' + item['actual_live_ancestor_commit'] + ' | ' +
                        ('是' if item['base_live_equal'] else '否，补丁已保存') + ' |')

report = f'''# 静默猎手策略提案批次回报

记录时间：{now}。task=strategy-proposal；character=silent；batch=20261015-063022-strategy-proposal。

完整 base：`{base}`。git 初始干净，按普通流程合 main 得到 Already up to date；没有源码、知识、任务模板或已跟踪记录改动。fixes=[]，merged=null；未创建提交、行为版本或shipped，也未运行play、联网、改模型配置或派下级agent。

本批十项均 waiting。原因是完整执行归属及受控整战/独立验证不足，不是Roy授权不足；各项原编号和账本保留。原提案的局部审计已有源码时只记录真实祖先及功能边界，不冒称整项duplicate或implemented。

## 身份与范围

learn.json 本批 task/character/worktree/runs 与任务一致，reason=proposal、十个proposal_ids；无research_request、implementation_request或proposal_repair。根牌数专题属于20261010-150327，与本批不匹配，保持普通领取任务。派发及原队列快照见 dispatch.json、queue-snapshot.json。所有十份原Markdown的SHA与队列完全一致，副本保持原字节。

本批六局均有已结束的runs原行，character=SILENT、ascension=10，全局victory=false；PU F17第5试单战获胜仍单独保留。运行记录有历史DeepSeek调用/dirty源码，不把六局宣称纯Codex大脑或可恢复完整dirty运行树。普通/high是本任务要求；可访问本批err前100行未见原生model/effort头，runtime-header.json保留空核验结果，不凭项目默认或旧局配置宣称本原生会话实际模型已核实；未改任何运行配置。

## 原始证据及独立复核

使用仓库 learner/extract_evidence.py 共用入口，显式选这六局并扩展到八流。每条均复核source、offset、bytes、SHA256、原JSON正文和显式所属局；角色/进阶由原state/run-config/runs核实。身份冲突与正文仅提及局号的边界另做材料断言。全部 {verification['verified_rows']} 行通过字节读回，计数与输出SHA一致。

{chr(10).join(stream_table)}

每流各自冻结截点；原日志后续增长不改变本批材料。states与decisions各有2条全源无效行，brain有1条全源无效行，未据此编造所属局或损伤已选行。fight-plans在该截点未选到六局，不能从0行推出日志全局缺失；run-plans按原run字段选到21行。原0行文件及所有manifest保留，未覆盖旧截点报告。

材料索引：evidence/evidence-manifest.json、evidence-verification.json、selected-decisions.json、additional-pair-decisions.json、paired-decisions.json、selected-state-projections.json、attempts.json、attempt-summary.json。所有原行仍有source/offset/bytes/SHA；投影只为阅读，不替代原件。

## 支持、相反取舍与未知

751 F17 T2同指纹首/第三试净损13→18、净扣敌9→18；T7第二/第四试净损13→23、净扣敌12→18；T13首/末试净损8→2、净扣敌17→11。T7原提案写的9→15不是本批端点总净扣口径，账本同局说明为12→18；保留原文，成本差均为6，不能把不同范围的数混写或据此新造机制反证。六次同局全败，局部血价不证明整场哪个策略更好。

751 F13 T3 plan2与plan5模型均损8、8/8在五轮内结束，牌伤26与16；plan5明确后续不喝，plan3虽本轮无药却后续7/8喝，二者不能混用。实际s278403→278404槽0耗药，之后s278407为58→50。未喝、留至boss分支未实际记录，缺表成本0也不证明持有价值0。

KV F33第4/5试T5同指纹，删致命毒药净扣36→29，玩家均30→30；d273451继续阻止补毒。首/末T1同指纹去掉究极打击净扣28→14、均零损，但抽牌/能力续步随后重问。后轮动作变化，不能给单步胜因。本文端点净差不声称完整敌回血毛伤或独立未封顶敌伤，原路线和休息反事实亦未实打。

三巨兽局验证保留阶段：L9 F17首试T14、PU F17首/次T17、YQL F17末态均有近十亿占位血。PU F17第5试T15确实won、end_hp=2，不能把该局最终F33失败说成巨兽全败。YQL末试T10原帧s280160/280161为毒2→8，HP26/挡13/来袭41均不变；s280162实际死亡0血是截断结果，不能倒算足额毛损。本体结束、占位体扣血、更多毒或更长存活都不单独代表胜利。提前用药、留药或新参考排序的整战收益仍未知。

KEN七组药水动作与槽位前后变化核实；d274131/274237/274272是pending(unstable)，另用原槽位帧补证耗用，不把回执文字当完整候选执行。六次F17入口均75血空药栏。F15两瓶已经用掉与“若保留”的收益不同；随机选牌、发光水抽牌及重问后没有完整候选因果归属。

KEN F17第4/5试T10同指纹，净损15→21、净扣敌2→4，B2原0.385→0.127、配对差−0.2583/SE0.0132；这是旧模型预测差，不是真实胜率。第4/6试T5同指纹，净损7→5、净扣敌1→2，同时原能力在s280569/T5实见2敏捷，末试直到s280702/T9才首次实见2。不能只取最少失血，也不能以未试过推更安全。两组后轮都变，不能归整战结果于单步。

未拟合任何游戏参数，不用预训练事实补结论，不把同局SL拆成独立训练/留出。上述均为原证据复核，未新增经验条目、纯bug判断或与旧知识相反的新结论；双向成本与原提案限制继续保留。

## 现有源码及真实live范围

只读核验时live HEAD=`{source['live_head']}`，13叶均与该live提交工作树同字节；各祖先提交经merge-base核实，且该提交文件blob与live一致。只证明局部实现存在，不是本批合入或自然消费证明。

{chr(10).join(source_table)}

9叶base/live同字节。potion-cost.ts与explore.ts差异仅历史Roy/Dai注释；combat-plan.ts及turn-solver.ts另有既有escapePlanUnresolved条件参考处理，补丁逐字节保存为*.base-live.patch。没有把13叶报全等价，也未把该并行改动归本任务、合入后续main或重跑其源码检查；本批事实复核用原始日志，不以不同模型版本生成新胜率。

具体功能边界：silent-sl-resource-comparison为current_turn_prediction且execution=unverified；silent-sl-comparison.actual_turn_result=null；silent-selection-audit.actual_turn=null；silent-selection-dispatch只证明single_action_receipt，whole_plan_executed=null。silent-held-loss保留未决弃牌和actual_held_hp_loss=null；silent-potion-reference保留hold_hp=null及同题模型参考。巨兽阶段与末态展示已有，anchorRank仍使用存活轮/原显示血作为旧排序。完整归属、受控排序收益与跨战药值并未因此交付。

## 每项处置

{chr(10).join(table)}

报告与proposal.md均位于指定scratch，原id全部保留；未修改队列状态，交调度器消费proposal_results后继续waiting，待缺失数据满足再重派。本批不注册重复代码提案。

## 验证、记录及交付限制

固定材料 {fixed['assertions']} 条断言全部通过，另有逐原行字节/角色/身份/计数复核和七组同指纹复核；这些不是tsc、vitest、完整模拟或策略校准。材料首轮误用了药水slot字段，原帧实际为index；首次KeyError日志保留，修正材料读取字段后原数值断言通过。状态null及猜测源码路径的准备错误见preparation-errors.txt。没有生产源码变更，撤源码失败/恢复通过不适用，tsc/vitest/cases均null，未启动沙箱或宿主源码测试，不伪造测试成功。

账本已有16个相关id，均保持既有claim/evidence/first_run/prior/status/version；本批仅经根ledger.py update追加by/where/note追溯，回执在ledger-update.log、ledger-update-receipts.json。不会把既有shipped降为proposed；status=proposed只适用于新提案记录，本批无新id。没有提交或实际上线，不写发布版本和上线双通知，不将此次报告当经验库已入库或大脑已采用。

gitleaks及最终tracked-clean读回分别见gitleaks-scan.log与final-readback.json；实际结果在末次验收后落盘。提案总表绝对路径：{OUT / 'proposal.md'}。报告绝对路径：{OUT / 'report.md'}。未完整执行、未执行反事实、dirty原树、旧引擎与当前原生模型不可核的限制不抹去，父学习要求不关闭。
'''
(OUT / 'report.md').write_text(report)

final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-063022-strategy-proposal',
         'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': dispatch['proposal_ids'],
         'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
ledger_ids = sorted({item for a in queue.values() for item in a['ledger']})
updates = []
for ident in ledger_ids:
    linked = [r['id'] for r in results if ident in queue[r['id']]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261015-063022-strategy-proposal：仅复核并保留waiting；关联原id ' + ','.join(linked) +
                            '。8444原行字节与54固定材料断言核实；无源码、知识、合入或新版本，不修改既有claim/evidence/首证/先验/status/version。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'proposals': len(results), 'ledger_trace_updates': len(updates), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

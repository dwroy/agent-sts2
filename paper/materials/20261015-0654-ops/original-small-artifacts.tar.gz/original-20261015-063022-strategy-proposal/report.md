# 静默猎手策略提案批次回报

记录时间：2026-10-15 06:42:09 CST。task=strategy-proposal；character=silent；batch=20261015-063022-strategy-proposal。

完整 base：`f67a7fb93826192772cd73f1ce833c363d32980e`。git 初始干净，按普通流程合 main 得到 Already up to date；没有源码、知识、任务模板或已跟踪记录改动。fixes=[]，merged=null；未创建提交、行为版本或shipped，也未运行play、联网、改模型配置或派下级agent。

本批十项均 waiting。原因是完整执行归属及受控整战/独立验证不足，不是Roy授权不足；各项原编号和账本保留。原提案的局部审计已有源码时只记录真实祖先及功能边界，不冒称整项duplicate或implemented。

## 身份与范围

learn.json 本批 task/character/worktree/runs 与任务一致，reason=proposal、十个proposal_ids；无research_request、implementation_request或proposal_repair。根牌数专题属于20261010-150327，与本批不匹配，保持普通领取任务。派发及原队列快照见 dispatch.json、queue-snapshot.json。所有十份原Markdown的SHA与队列完全一致，副本保持原字节。

本批六局均有已结束的runs原行，character=SILENT、ascension=10，全局victory=false；PU F17第5试单战获胜仍单独保留。运行记录有历史DeepSeek调用/dirty源码，不把六局宣称纯Codex大脑或可恢复完整dirty运行树。普通/high是本任务要求；可访问本批err前100行未见原生model/effort头，runtime-header.json保留空核验结果，不凭项目默认或旧局配置宣称本原生会话实际模型已核实；未改任何运行配置。

## 原始证据及独立复核

使用仓库 learner/extract_evidence.py 共用入口，显式选这六局并扩展到八流。每条均复核source、offset、bytes、SHA256、原JSON正文和显式所属局；角色/进阶由原state/run-config/runs核实。身份冲突与正文仅提及局号的边界另做材料断言。全部 8444 行通过字节读回，计数与输出SHA一致。

| 流 | 冻结 source_size（字节） | 本批选中行数 |
|---|---:|---:|
| states | 12913161744 | 4167 |
| decisions | 1488976384 | 4071 |
| sl-attempts | 39848782 | 43 |
| run-config | 1721286 | 6 |
| run-plans | 7902978 | 21 |
| brain | 543230743 | 130 |
| runs | 330941 | 6 |
| fight-plans | 2233957 | 0 |

每流各自冻结截点；原日志后续增长不改变本批材料。states与decisions各有2条全源无效行，brain有1条全源无效行，未据此编造所属局或损伤已选行。fight-plans在该截点未选到六局，不能从0行推出日志全局缺失；run-plans按原run字段选到21行。原0行文件及所有manifest保留，未覆盖旧截点报告。

材料索引：evidence/evidence-manifest.json、evidence-verification.json、selected-decisions.json、additional-pair-decisions.json、paired-decisions.json、selected-state-projections.json、attempts.json、attempt-summary.json。所有原行仍有source/offset/bytes/SHA；投影只为阅读，不替代原件。

## 支持、相反取舍与未知

751 F17 T2同指纹首/第三试净损13→18、净扣敌9→18；T7第二/第四试净损13→23、净扣敌12→18；T13首/末试净损8→2、净扣敌17→11。T7原提案写的9→15不是本批端点总净扣口径，账本同局说明为12→18；保留原文，成本差均为6，不能把不同范围的数混写或据此新造机制反证。六次同局全败，局部血价不证明整场哪个策略更好。

751 F13 T3 plan2与plan5模型均损8、8/8在五轮内结束，牌伤26与16；plan5明确后续不喝，plan3虽本轮无药却后续7/8喝，二者不能混用。实际s278403→278404槽0耗药，之后s278407为58→50。未喝、留至boss分支未实际记录，缺表成本0也不证明持有价值0。

KV F33第4/5试T5同指纹，删致命毒药净扣36→29，玩家均30→30；d273451继续阻止补毒。首/末T1同指纹去掉究极打击净扣28→14、均零损，但抽牌/能力续步随后重问。后轮动作变化，不能给单步胜因。本文端点净差不声称完整敌回血毛伤或独立未封顶敌伤，原路线和休息反事实亦未实打。

三巨兽局验证保留阶段：L9 F17首试T14、PU F17首/次T17、YQL F17末态均有近十亿占位血。PU F17第5试T15确实won、end_hp=2，不能把该局最终F33失败说成巨兽全败。YQL末试T10原帧s280160/280161为毒2→8，HP26/挡13/来袭41均不变；s280162实际死亡0血是截断结果，不能倒算足额毛损。本体结束、占位体扣血、更多毒或更长存活都不单独代表胜利。提前用药、留药或新参考排序的整战收益仍未知。

KEN七组药水动作与槽位前后变化核实；d274131/274237/274272是pending(unstable)，另用原槽位帧补证耗用，不把回执文字当完整候选执行。六次F17入口均75血空药栏。F15两瓶已经用掉与“若保留”的收益不同；随机选牌、发光水抽牌及重问后没有完整候选因果归属。

KEN F17第4/5试T10同指纹，净损15→21、净扣敌2→4，B2原0.385→0.127、配对差−0.2583/SE0.0132；这是旧模型预测差，不是真实胜率。第4/6试T5同指纹，净损7→5、净扣敌1→2，同时原能力在s280569/T5实见2敏捷，末试直到s280702/T9才首次实见2。不能只取最少失血，也不能以未试过推更安全。两组后轮都变，不能归整战结果于单步。

未拟合任何游戏参数，不用预训练事实补结论，不把同局SL拆成独立训练/留出。上述均为原证据复核，未新增经验条目、纯bug判断或与旧知识相反的新结论；双向成本与原提案限制继续保留。

## 现有源码及真实live范围

只读核验时live HEAD=`5b70942253b9004315093cd961e4f34e0c277d5e`，13叶均与该live提交工作树同字节；各祖先提交经merge-base核实，且该提交文件blob与live一致。只证明局部实现存在，不是本批合入或自然消费证明。

| 当前 live 源码 | 实际 live 祖先提交 | 与本批base是否同字节 |
|---|---|---|
| agent/src/reflex/silent-sl-resource-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 是 |
| agent/src/reflex/silent-sl-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 是 |
| agent/src/reflex/silent-held-loss.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 是 |
| agent/src/reflex/silent-potion-reference.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | 是 |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 是 |
| agent/src/reflex/silent-selection-dispatch.ts | bade647f9fe4c9103b40e2f26b26296692ad24b7 | 是 |
| agent/src/reflex/silent-giant-potion.ts | d5e20aa4dd44168ce30944dfcce74f8322144953 | 是 |
| agent/src/reflex/combat-plan.ts | 8e196be494ada9a33dac3d897a0671a5b14e0e5b | 否，补丁已保存 |
| agent/src/reflex/potion-cost.ts | e1a467e18a0dfa8d99046a24ff4c0e1af59278c8 | 否，补丁已保存 |
| agent/src/reflex/turn-solver.ts | 8e196be494ada9a33dac3d897a0671a5b14e0e5b | 否，补丁已保存 |
| agent/src/sl/attempts.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 是 |
| agent/src/sl/explore.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 否，补丁已保存 |
| agent/src/hand/loop.ts | a9fcf33ca4c204d03cfc310c7f7ced61f196f964 | 是 |

9叶base/live同字节。potion-cost.ts与explore.ts差异仅历史Roy/Dai注释；combat-plan.ts及turn-solver.ts另有既有escapePlanUnresolved条件参考处理，补丁逐字节保存为*.base-live.patch。没有把13叶报全等价，也未把该并行改动归本任务、合入后续main或重跑其源码检查；本批事实复核用原始日志，不以不同模型版本生成新胜率。

具体功能边界：silent-sl-resource-comparison为current_turn_prediction且execution=unverified；silent-sl-comparison.actual_turn_result=null；silent-selection-audit.actual_turn=null；silent-selection-dispatch只证明single_action_receipt，whole_plan_executed=null。silent-held-loss保留未决弃牌和actual_held_hp_loss=null；silent-potion-reference保留hold_hp=null及同题模型参考。巨兽阶段与末态展示已有，anchorRank仍使用存活轮/原显示血作为旧排序。完整归属、受控排序收益与跨战药值并未因此交付。

## 每项处置

| 原提案 id | 证据局号、层、回合 | 既有账本 | 本批处置与缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820 | silent-0079、silent-0176 | waiting：751 F17 T2/T7/T13同指纹血价已核；live已有候选预测审计，完整执行归属仍为空。缺跨抽弃续问的完整候选实果、受控整战后继及独立后期校准，不能拟额外失血准入阈值。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3、F17 T7；d272361/272362，s278403–278407 | silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176 | waiting：751 F13 T3有药与整战无药参考均预测损8且8/8结束，但只实打喝药；live已有持有价值未知与未决弃牌拆项。缺无药、留药至boss的完整分支和实际候选归属，不能拟持有价值或改变弃牌。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13；原经验版本及账本链接保留 | silent-0079、silent-0176 | waiting：原经验提案覆盖751同局六次SL；局部成本与持牌事实已有实现，六次全败不能作六局独立验证。缺完整候选实果及保持后继受控的整战比较，不将局部审计当全部实现。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3、F17 T7/T13/T17；原经验关联保留 | silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176 | waiting：751能力、毒/反伤、持牌损血与药水已有部分预测拆项，未决弃牌不能当必然失血。缺逐源实际兑现与抽弃后完整执行、跨战无药/留药对照，不能关闭全部经验关联。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 T1/T5；d273242/273474、273400/273450，另有续问d273451/273480 | silent-0102、silent-0019、silent-0020 | waiting：KV F33 T5同指纹删毒净扣36→29、均零损；T1删输出净扣28→14、均零损。缺完整候选末端、受控后继整战和独立回血毛伤核验，未执行路线/休息分支仍未知，不设SL或回血门槛。 |
| silent-proposal-e18d3f18e6cac2a0 | L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17/T15；YQL8RZ8BWN1E F17 T10/T13 | silent-0017、silent-0250、silent-0011、silent-0027、silent-0046 | waiting：三巨兽局的占位血与自爆阶段已核；live已有阶段/末态资源展示，anchorRank仍按原存活轮与原残血排序。缺新排序的受控完整后继和独立最终资源校准，不将局部阶段实现当整项duplicate。 |
| silent-proposal-9733bb80f445aeae | YQL8RZ8BWN1E F17 T10 s280160/280161；PU80F84P6HPN F17第5试T15 | silent-0017、silent-0019、silent-0020、silent-0250 | waiting：YQL F17末次T10毒药使残壳毒2→8，但26血/13挡/自爆41不变；PU F17第5试确实获胜，不能据全局失败否认它。缺提前喝、不喝、留药和新SL排序的受控整战对照，跨战药值未知。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1,T2/F15T1；七组原帧见fixed-material-verification.json | silent-0019 | waiting：KEN七次耗药与六次F17入口75血空栏均由原状态复核，三条pending回执另由槽位补证。缺随机选牌/发光水续问后完整候选收益，以及F15不喝或留药至boss的分支。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 T5/T10；d274484/274601、274505/274568；敏捷实帧s280569/280702 | silent-0079、silent-0021、silent-0125、silent-0005、silent-0176 | waiting：KEN F17 T10同指纹多损6仅多净扣2；T5省2却把2敏捷首次建立由T5推迟到T9。缺完整逐源兑现、受控整战后继与独立校准，不能改变探索准入或HP护栏。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T5/T10；原经验关联与账本保留 | silent-0021、silent-0079、silent-0125、silent-0176 | waiting：KEN原经验提案的两向成本已核，六次相关尝试不作独立训练/验证。live预测及单动作回执不等于完整实果；缺后继受控的反事实和新局验证，不拟统一血价或关闭原提案。 |

报告与proposal.md均位于指定scratch，原id全部保留；未修改队列状态，交调度器消费proposal_results后继续waiting，待缺失数据满足再重派。本批不注册重复代码提案。

## 验证、记录及交付限制

固定材料 54 条断言全部通过，另有逐原行字节/角色/身份/计数复核和七组同指纹复核；这些不是tsc、vitest、完整模拟或策略校准。材料首轮误用了药水slot字段，原帧实际为index；首次KeyError日志保留，修正材料读取字段后原数值断言通过。状态null及猜测源码路径的准备错误见preparation-errors.txt。没有生产源码变更，撤源码失败/恢复通过不适用，tsc/vitest/cases均null，未启动沙箱或宿主源码测试，不伪造测试成功。

账本已有16个相关id，均保持既有claim/evidence/first_run/prior/status/version；本批仅经根ledger.py update追加by/where/note追溯，16条真实回执在ledger-update.log、ledger-update-receipts.json。不会把既有shipped降为proposed；status=proposed只适用于新提案记录，本批无新id。首次回执检查误把唯一相关账本数写为15，实际输入与CLI回执均为16；已按派发集合修正验收计数，未重新追加。没有提交或实际上线，不写发布版本和上线双通知，不将此次报告当经验库已入库或大脑已采用。

gitleaks首轮扫描约159.94 MB、退出0且未发现泄漏；报告计数修正及回执保存后再扫描，末次结果与最终tracked-clean读回分别见gitleaks-final.log与final-readback.json。提案总表绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-063022/learner/runs/20261015-063025-17349d9c-b35e-4264-87db-3cc5ca8557fb-strategy-proposal/proposal.md。报告绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-063022/learner/runs/20261015-063025-17349d9c-b35e-4264-87db-3cc5ca8557fb-strategy-proposal/report.md。未完整执行、未执行反事实、dirty原树、旧引擎与当前原生模型不可核的限制不抹去，父学习要求不关闭。

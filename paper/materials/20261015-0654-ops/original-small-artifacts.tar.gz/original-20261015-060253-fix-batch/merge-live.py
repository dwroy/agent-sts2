import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
OUT = ROOT / 'learner/runs/20261015-060313-109dd307-0a9c-49f5-8d4a-9075722e6093-fix-batch'
BRANCH = 'codex-fix-silent-20261015-060253'
BASE = '10a19978fb559f1afd952f696fc4d526006a6f0a'
record = {'branch': BRANCH, 'source_base': BASE, 'merged': None, 'tests_run': False}


def git(*args, check=True):
    p = subprocess.run(['git', '-C', str(LIVE), *args], capture_output=True, text=True)
    if check and p.returncode:
        raise RuntimeError(f'git {args[0]}: {p.stderr}')
    return p


def save():
    (OUT / 'merge-result.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')


try:
    subprocess.run(['date'], check=True)
    while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
        time.sleep(10)
    record['before_refresh'] = git('rev-parse', 'HEAD').stdout.strip()
    record['initial_dirty'] = git('status', '--short').stdout.splitlines()
    if git('diff', '--cached', '--quiet', check=False).returncode:
        raise RuntimeError('live index already contains staged changes; no staging or merge attempted')
    git('add', 'notes/fight-value-backtest.md', 'knowledge')
    if git('diff', '--cached', '--quiet', check=False).returncode:
        subprocess.run(['date'], check=True)
        git('commit', '-m', 'Refresh knowledge data', '-m',
            'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
    record['premerge'] = git('rev-parse', 'HEAD').stdout.strip()
    own = set(git('diff', '--name-only', BASE, BRANCH).stdout.splitlines())
    refreshed = set(git('diff', '--name-only', record['before_refresh'], record['premerge']).stdout.splitlines())
    record['refresh_overlap'] = sorted(own & refreshed)
    if record['refresh_overlap']:
        raise RuntimeError('refresh data overlaps this batch; retained refresh and stopped before merge')
    merged = git('merge', '--no-edit', BRANCH, check=False)
    (OUT / 'live-merge.log').write_text(merged.stdout + merged.stderr)
    record['merge_exit'] = merged.returncode
    if merged.returncode:
        record['conflicts'] = git('diff', '--name-only', '--diff-filter=U').stdout.splitlines()
        if git('rev-parse', '-q', '--verify', 'MERGE_HEAD', check=False).returncode == 0:
            git('merge', '--abort')
            record['aborted'] = True
        record['after_abort'] = git('rev-parse', 'HEAD').stdout.strip()
        record['final_dirty'] = git('status', '--short').stdout.splitlines()
        save()
        print(json.dumps(record, ensure_ascii=False, indent=2))
        sys.exit(4)
    record['merged'] = git('rev-parse', 'HEAD').stdout.strip()
    save()
    record['tests_run'] = True
    test_env = {**os.environ, 'TMPDIR': str(OUT), 'SANDBOX_WORKERS': '1',
                'PATH': str(Path.home() / '.local/node/bin') + ':' + os.environ.get('PATH', '')}
    with (OUT / 'live-sandbox.log').open('w') as log:
        test = subprocess.run(['bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', env=test_env,
                              stdout=log, stderr=subprocess.STDOUT)
    record['test_exit'] = test.returncode
    if test.returncode:
        git('reset', '--merge', record['premerge'])
        record['rolled_back_to'] = git('rev-parse', 'HEAD').stdout.strip()
        record['merged'] = None
    save()
    print(json.dumps(record, ensure_ascii=False, indent=2))
    sys.exit(test.returncode)
except Exception as error:
    record['error'] = str(error)
    save()
    print(json.dumps(record, ensure_ascii=False, indent=2))
    sys.exit(5)

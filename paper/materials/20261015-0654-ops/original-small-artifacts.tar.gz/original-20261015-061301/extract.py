import json,hashlib
from pathlib import Path
p=Path('/home/dw/Projects/agent-sts2'); out=p/'learner/runs/20261015-061302-2b58f517-71a4-4936-b159-71bbeedc7324-postmortem'; run='2E4UQ1BZTQWB'
for name in ['decisions','run-plans','states','sl-attempts','brain','run-config','codex-calls']:
 src=p/'logs'/f'{name}.jsonl'; n=0; offset=0; cut=src.stat().st_size
 with src.open('rb') as f,(out/f'{name}.jsonl').open('w') as w:
  for lineno,line in enumerate(f,1):
   start=offset;offset+=len(line)
   if offset>cut:break
   if run.encode() not in line:continue
   try:r=json.loads(line)
   except ValueError:continue
   actual=r.get('run_id',r.get('run'))
   if name=='states':actual=(r.get('state') or {}).get('run_id',actual)
   if actual!=run:continue
   w.write(json.dumps({'line':lineno,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'data':r},ensure_ascii=False)+'\n');n+=1
 print(name,n,flush=True)
ds=[json.loads(l)['data'] for l in (out/'decisions.jsonl').open()]; a=min(r['ts'] for r in ds);b=max(r['ts'] for r in ds)
n=0
with (p/'logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as w:
 for lineno,line in enumerate(f,1):
  try:r=json.loads(line)
  except ValueError:continue
  if a<=r.get('ts','')<=b:w.write(json.dumps({'line':lineno,'data':r},ensure_ascii=False)+'\n');n+=1
print('decision_window',a,b,'deepseek_reasoning',n)

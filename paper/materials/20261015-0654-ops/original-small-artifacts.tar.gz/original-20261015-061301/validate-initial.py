import json,hashlib,re,collections,datetime
from pathlib import Path
P=Path(__file__).parent;ROOT=P.parents[2];RUN='2E4UQ1BZTQWB'
def read(name):return [json.loads(l) for l in (P/(name+'.jsonl')).open()]
D=read('decisions');S=read('states');B=read('brain');R=json.loads((P/(RUN+'-resources.json')).read_text());di={x['line']:x['data'] for x in D};si={x['line']:x['data']['state'] for x in S};checks=[]
def check(name,condition):
 checks.append({'核验':name,'通过':bool(condition)})
 if not condition:raise AssertionError(name)
with (ROOT/'logs/runs.jsonl').open() as h:run=next(json.loads(l) for l in h if RUN in l)
check('完局角色与进阶',run['character'].lower()=='silent' and run['ascension']==10 and run['floor']==22 and not run['victory'] and bool(run['ended']))
for name in ['decisions','states','brain','run-plans','run-config','sl-attempts','codex-calls']:
 rows=read(name)
 with (ROOT/'logs'/(name+'.jsonl')).open('rb') as h:
  for row in rows:
   h.seek(row['offset']);b=h.read(row['bytes']);check(f'{name}原行{row["line"]}字节与SHA',hashlib.sha256(b).hexdigest()==row['sha256'] and json.loads(b)==row['data'])
check('日志条数',len(D)==450 and len(S)==473 and len(B)==23 and len(R['combats'])==17)
check('全部进场T1且最大HP70',all(c['entry_is_turn_one'] and c['entry']['max_hp']==70 for c in R['combats']))
expect=[(2,56,55),(4,65,65),(5,65,52),(6,52,45),(8,45,45),(14,66,63),(15,63,62),(17,62,11),(19,62,26),(20,26,22),(21,22,None),(21,22,None),(21,22,7),(22,7,None),(22,7,None),(22,7,None),(22,7,0)]
check('各战实到HP',[(c['floor'],c['entry']['hp'],c['exit']['hp'] if c['exit'] else None) for c in R['combats']]==expect)
check('五次SL截断',sum(c['exit'] is None for c in R['combats'])==5 and len(R['sl_events'])==9)
check('实胜与实死',sum(e['result']=='won' for e in R['sl_events'])==3 and sum(e['result']=='died' for e in R['sl_events'])==1)
p=si[406977]['combat']['player'];e=si[406977]['combat']['enemies'][0];end=si[406978]['combat']['enemies'][0]
check('最终23被虚弱降17、8挡需9、至少差3',p['current_hp']==7 and p['block']==8 and e['intents'][0]['total_damage']==17 and 17-8==9 and 9+1-7==3)
check('敌末血84结10毒至74',e['current_hp']==84 and end['current_hp']==74 and si[406978]['run']['current_hp']==0)
check('斗篷前手牌无匕首雨', [c['card_id'] for c in si[406967]['combat']['hand']]==['FOOTWORK','CLOAK_AND_DAGGER','SLICE','DEFEND_SILENT','DEFEND_SILENT'])
check('斗篷只生SHIV',collections.Counter(c['card_id'] for c in si[406969]['combat']['hand'])-collections.Counter(c['card_id'] for c in si[406968]['combat']['hand'])==collections.Counter({'SHIV':1}))
check('三次代码候选报25含未到手匕首雨',all('dmg 25' in di[n]['rationale'] and '匕首雨' in di[n]['rationale'] for n in [394381,394393,394405]))
check('实T2推进21',si[406967]['combat']['enemies'][0]['current_hp']-si[406972]['combat']['enemies'][0]['current_hp']==21)
check('取融入暗影与跨幕回血分账',[si[n]['run']['current_hp'] for n in [406783,406784,406785,406786]]==[11,31,31,62])
check('两次SL覆盖',[(x['data']['floor'],x['data']['turn']) for x in D if 'SL explore' in x['data']['rationale']]==[(21,1),(22,1)])
primary=[x for x in D if x['data']['decider']=='code' and x['data']['label'].startswith('combat/') and x['data']['label']!='combat/plan-continue'];win=lambda x:(x['data']['floor'],x['data'].get('sl_reloads'),x['data']['turn']);windows=set(map(win,primary));sl=[x for x in D if 'SL explore' in x['data']['rationale']]
check('代码自主86条59窗口',len(primary)==86 and len(windows)==59 and set(map(win,sl))<=windows)
check('HP护栏0',not any('hp guard' in x['data']['rationale'].lower() or 'hp_guard' in (x['data'].get('journal') or {}) for x in D))
flags=collections.Counter()
for x in D:
 r=x['data']
 if r['decider']!='jev' or not r['label'].startswith('combat/plan'):continue
 opts={k:json.loads(v) for k,v in next(iter(r['questions'].values()))['criteria'].items()};m=re.search(r'Jev chose plan (\d+)/\d+',r['rationale']);key='plan'+m[1] if m else next(k for k,v in opts.items() if v.get('plays')==r['journal']['choice']);v=opts[key];flags['best']+=bool(v.get('rollout_best'));flags['tied']+=bool(v.get('rollout_tied'));flags['total']+=1
check('最优含并列78/82',flags=={'best':66,'tied':12,'total':82})
check('低信心2',sum(x['data']['decider']=='jev' and x['data']['confidence']<.35 for x in D)==2)
check('脑模型与次数',all(x['data']['engine']=='codex' and x['data']['model']=='gpt-6.1-sol' and x['data']['effort']=='xhigh' for x in B) and sum(x['data']['label']=='run-plan' for x in B)==1)
check('全部脑tokens',{k:sum(x['data']['usage'].get(k,0) for x in B) for k in ['inputTokens','cacheHitTokens','outputTokens','reasoningTokens']}=={'inputTokens':4000899,'cacheHitTokens':1503744,'outputTokens':26988,'reasoningTokens':23807})
check('Jev tokens',sum((x['data'].get('usage') or {}).get('input_tokens',0)+(x['data'].get('usage') or {}).get('output_tokens',0) for x in D if x['data']['decider']=='jev')==671912)
check('饮药14无弃药',sum(x['data']['chosen']['action']=='use_potion' for x in D)==14 and not any(x['data']['chosen']['action']=='discard_potion' for x in D))
changes=[c for c in R['resource_changes'] if c['combat_sequence'] is None and not c['restart_boundary']];gained=sum(len(set(map(tuple,c['to']['potions']))-set(map(tuple,c['from']['potions']))) for c in changes);check('非SL获药9',gained==9)
check('用时1844.676秒',(datetime.datetime.fromisoformat(D[-1]['data']['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['data']['ts'].replace('Z','+00:00'))).total_seconds()==1844.676)
check('DeepSeek时间窗无记录',(P/'deepseek-reasoning.jsonl').stat().st_size==0)
ref=json.loads((P/'source-reference.json').read_text())
for f in ref['files']:check('当前源码SHA '+f['path'],hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256'] and f['diff_bytes']==0)
# A cleared reward enemy panel never supplies a final blow's damage.
a=json.loads((P/'analysis.json').read_text());a['stats']['rollout_tied']=12;a['stats']['rollout_best_including_ties']=78
for c in a['combats']:
 for t in c['turns']:
  tail=si[t['lines'][1]]
  if tail.get('screen')=='REWARD' and not (tail.get('combat') or {}).get('enemies'):
   t['enemy_pool'][1]=None;t['net_enemy_progress']=None;t['limitation']='胜战退出敌面板清空，不倒填最后一击伤害。'
a['limitations']=['敌血池净变化不等于逐击总伤害；同类型实体跨压缩索引身份有歧义。','首次分析的单一best匹配曾误取重复plays第一项，已保留initial并按plan序号修正；正文采用66单一best＋12并列。']
(P/'analysis.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
(P/'validation-before-append.json').write_text(json.dumps({'通过':True,'核验数':len(checks),'checks':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'通过':True,'核验数':len(checks)},ensure_ascii=False))

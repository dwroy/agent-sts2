import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent
def read(n):return [json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=read('decisions'); ss=read('states'); states={x['line']:x['data']['state'] for x in ss};r=json.loads((p/'2E4UQ1BZTQWB-resources.json').read_text())
def powers(z):return {x['power_id']:x['amount'] for x in z.get('powers',[])}
def summ(n):
 s=states[n];c=s.get('combat') or {};a=c.get('player') or {};return {'s':n,'T':s['turn'],'hp':s['run']['current_hp'],'block':a.get('block'),'e':a.get('energy'),'p':powers(a),'enemy':[(z['index'],z['enemy_id'],z['current_hp'],z['block'],powers(z),z.get('move_id'),z.get('intents')) for z in c.get('enemies',[])]}
turns=[]
for c in r['combats']:
 frames=[x for x in ss if c['entry']['line']<=x['line']<=c.get('exit',c['last'])['line']] if c.get('exit') else [x for x in ss if c['entry']['line']<=x['line']<=c['last']['line']]
 groups=[]
 for x in frames:
  if not groups or groups[-1][0]['data']['state']['turn']!=x['data']['state']['turn']:groups.append([])
  groups[-1].append(x)
 rows=[]
 for i,g in enumerate(groups):
  start=g[0]['line'];end=groups[i+1][0]['line'] if i+1<len(groups) else g[-1]['line'];a=states[start];b=states[end];total=lambda s:sum(e['current_hp'] for e in (s.get('combat') or {}).get('enemies',[]) if e['is_alive']) if (s.get('combat') or {}).get('enemies') else 0
  rows.append({'turn':a['turn'],'lines':[start,end],'hp':[a['run']['current_hp'],b['run']['current_hp']],'enemy_pool':[total(a),total(b)],'net_enemy_progress':total(a)-total(b)})
 c['turn_endpoints']=rows;turns.append({'seq':c['sequence'],'floor':c['floor'],'end':c['end'],'turns':rows})
 print('COMBAT',c['sequence'],'F',c['floor'],c['end'],'; '.join(f"T{a['turn']} s{a['lines'][0]}→{a['lines'][1]} hp{a['hp']} 敌池{a['enemy_pool']}" for a in rows))
 if c['floor']>=17:
  print('FIRST',summ(c['entry']['line']));print('LAST',summ(c['last']['line']))
jev=[x for x in d if x['data']['decider']=='jev']; plans=[x for x in jev if x['data']['label'].startswith('combat/plan')];ranks=[];bests=[];focus=[]
for x in plans:
 z=x['data'];m=re.search(r'code rank (\d+)',z['rationale']);ranks.append(int(m[1]) if m else None)
 opts=next(iter(z['questions'].values()))['criteria'];opts={k:json.loads(v) for k,v in opts.items()}; chosen=z.get('journal',{}).get('choice'); selected=[(k,v) for k,v in opts.items() if v.get('plays')==chosen]
 bests.append(selected[0][1].get('rollout_best') if len(selected)==1 else None)
 if any('focus' in v for v in opts.values()):focus.append((x['line'],z['floor'],z['turn']))
code=[x for x in d if x['data']['decider']=='code'];primary=[x for x in code if x['data']['label'].startswith('combat/') and x['data']['label']!='combat/plan-continue']; windows=lambda a:set((x['data']['floor'],x['data'].get('sl_reloads'),x['data']['turn']) for x in a)
stats={'jev':len(jev),'low':[(x['line'],x['data']['floor'],x['data']['turn'],x['data']['confidence']) for x in jev if x['data']['confidence']<.35],'plan_questions':len(plans),'ranks':dict(collections.Counter(map(str,ranks))),'rollout_best':dict(collections.Counter(map(str,bests))),'focus':focus,'code_raw':len(code),'jev_continue':sum('Jev-chosen' in x['data']['rationale'] for x in code),'code_primary':dict(collections.Counter(x['data']['label'] for x in primary)),'code_primary_windows':len(windows(primary)),'SL_explore':[(x['line'],x['data']['floor'],x['data']['turn']) for x in d if 'SL explore' in x['data']['rationale']],'hp_guard':sum('HP guard' in x['data']['rationale'] or 'hp_guard' in (x['data'].get('journal') or {}) for x in d),'fallback':sum(bool(x['data'].get('fallback')) for x in d),'deciders':dict(collections.Counter(x['data']['decider'] for x in d))}
print('STATS',json.dumps(stats,ensure_ascii=False))
for x in d:
 z=x['data']
 if z['chosen']['action'] in ['use_potion','discard_potion']:print('POTION',x['line'],z['floor'],z['turn'],z.get('sl_attempt'),z['chosen'],z['journal']['choice'])
print('RESOURCE_NONCOMBAT')
for a in r['resource_changes']:
 if a['combat_sequence'] is None:print(a['from']['line'],a['to']['line'],'F',a['to']['floor'],a['from']['hp'],a['to']['hp'],a['from']['potions'],a['to']['potions'],'restart',a['restart_boundary'])
for x in read('brain'):
 z=x['data'];u=z['usage'];print('USAGE',x['line'],z['label'],u)
report={'stats':stats,'combats':turns};(p/'analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { resolve } from 'node:path';
import { strict as assert } from 'node:assert';
const taskDir = new URL('.', import.meta.url);
const workspace = resolve(new URL('../../..', taskDir).pathname);
const originalRead = fs.readFileSync;
fs.readFileSync = function(path, ...args) {
  if (typeof path === 'string' && resolve(path).startsWith(workspace + '/knowledge/')) throw new Error('No mutable knowledge in this fixed consumer');
  return originalRead.call(this, path, ...args);
};
syncBuiltinESMExports();
const { parseGameState } = await import(workspace + '/agent/src/hand/mod/schema.ts');
const { makeKnowledge } = await import(workspace + '/agent/src/knowledge/index.ts');
await import(workspace + '/agent/src/reflex/combat-plan.ts');
const { judgeEndTurn } = await import(workspace + '/agent/src/sl/judge.ts');
const rows = JSON.parse(fs.readFileSync(new URL('selected-anchors.json', taskDir), 'utf8'));
const raw = structuredClone(rows.find((entry) => entry.line === 307493).row.state);
// Synthetic boundary only: no new game effect is assigned to this unknown relic.
raw.run.relics.push({ relic_id: 'UNOBSERVED_PROTECTION' });
const verdict = judgeEndTurn(parseGameState(raw), { label: 'combat/end_turn', revives: [], knowledge: makeKnowledge({}, 'cache') });
console.log(JSON.stringify({ certain: verdict.certain, reason: verdict.reason }));
assert.equal(verdict.certain, false);

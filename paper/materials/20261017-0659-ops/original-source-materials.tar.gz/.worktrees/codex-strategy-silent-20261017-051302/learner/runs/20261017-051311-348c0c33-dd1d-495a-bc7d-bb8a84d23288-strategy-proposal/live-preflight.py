import json, subprocess, sys, time
from pathlib import Path

root = Path('/home/dw/Projects/agent-sts2')
workspace = root / '.worktrees/codex-strategy-silent-20261017-051302'
out = Path(__file__).resolve().parent
live = root / '.worktrees/live'
assert (out / 'sandbox-4.exit').read_text().strip() == '0'
source = subprocess.check_output(['git', '-C', str(workspace), 'rev-parse', 'HEAD'], text=True).strip()
base = 'e5fc1a2d90b67b2a0dff253e9b0ba89fd3310aea'
assert source != base
assert subprocess.check_output(['git', '-C', str(workspace), 'rev-parse', 'HEAD^{tree}'], text=True).strip() == (out / 'tested-tree-final.txt').read_text().strip()
def git(*args, check=True):
    return subprocess.run(['git', '-C', str(live), *args], capture_output=True, text=True, check=check)
record = {'source': source, 'base': base, 'merged': None, 'refresh_commit': None}
while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
    print('等待可见的知识刷新进程', flush=True)
    time.sleep(10)
record['status_before'] = git('status', '--short').stdout
record['initial_live'] = git('rev-parse', 'HEAD').stdout.strip()
if git('diff', '--cached', '--name-only').stdout.strip():
    record['state'] = 'blocked-existing-index'
    (out / 'live-preflight.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    sys.exit(21)
refresh_paths = sorted(set(git('diff', '--name-only', '--', 'notes/fight-value-backtest.md', 'knowledge').stdout.splitlines()) | set(git('ls-files', '--others', '--exclude-standard', '--', 'notes/fight-value-backtest.md', 'knowledge').stdout.splitlines()))
changed = subprocess.check_output(['git', '-C', str(workspace), 'diff', '--name-only', base, source], text=True).splitlines()
record['refresh_paths'] = refresh_paths
record['overlap'] = sorted(set(refresh_paths) & set(changed))
if record['overlap']:
    record['state'] = 'blocked-refresh-overlap'
    (out / 'live-preflight.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    sys.exit(22)
if refresh_paths:
    git('add', '--', 'notes/fight-value-backtest.md', 'knowledge')
    leak = subprocess.run(['gitleaks', 'protect', '--staged', '--redact'], cwd=live, capture_output=True, text=True)
    (out / 'live-refresh-gitleaks.log').write_text(leak.stdout + leak.stderr)
    if leak.returncode:
        git('restore', '--staged', '--', *refresh_paths)
        record['state'] = 'blocked-refresh-keyscan'
        (out / 'live-preflight.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
        sys.exit(23)
    message = out / 'refresh-commit.txt'
    message.write_text('Refresh knowledge data\n\nCo-Authored-By: Codex GPT-6.1 Sol <noreply@openai.com>\n')
    commit = git('commit', '--only', '-F', str(message), '--', 'notes/fight-value-backtest.md', 'knowledge')
    (out / 'live-refresh-commit.log').write_text(commit.stdout + commit.stderr)
    record['refresh_commit'] = git('rev-parse', 'HEAD').stdout.strip()
record['pre_merge_live'] = git('rev-parse', 'HEAD').stdout.strip()
preview = subprocess.run(['git', '-C', str(workspace), 'merge-tree', '--write-tree', '--name-only', record['pre_merge_live'], source], capture_output=True, text=True)
(out / 'live-merge-preview.log').write_text(preview.stdout + preview.stderr)
record['preview_exit'] = preview.returncode
record['state'] = 'blocked-conflicts' if preview.returncode else 'ready'
record['status_after'] = git('status', '--short').stdout
(out / 'live-preflight.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(record, ensure_ascii=False, indent=2))
# Conflicts are never resolved here; the shared record owners retain their original data.
sys.exit(20 if preview.returncode else 0)

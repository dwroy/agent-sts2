import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { resolve } from 'node:path';
import { strict as assert } from 'node:assert';
const taskDir = new URL('.', import.meta.url);
const workspace = resolve(new URL('../../..', taskDir).pathname);
const originalRead = fs.readFileSync;
fs.readFileSync = function(path, ...args) {
  if (typeof path === 'string' && resolve(path).startsWith(workspace + '/knowledge/')) throw new Error('No mutable knowledge in this fixed consumer');
  return originalRead.call(this, path, ...args);
};
syncBuiltinESMExports();
const { cardHpOf } = await import(workspace + '/agent/src/sim/thief-card-hp.ts');
const { cardLoot, lootCostText, lootHpOf } = await import(workspace + '/agent/src/reflex/thief.ts');
const rows = JSON.parse(fs.readFileSync(new URL('counterexample-values.json', taskDir), 'utf8'));
const output = [];
for (const entry of rows) {
  const value = entry.row.thief_card_value;
  const recalculated = cardHpOf(value.measures);
  assert.equal(recalculated.hp, value.hp);
  assert.equal(recalculated.status, value.status);
  const loot = { ...cardLoot(value, value.fight), showUnknownHp: true };
  const thief = { index: 0, id: 'THIEVING_HOPPER', name: '固定分类输入', hp: 100, maxHp: 100, block: 0,
    cards: [value.card], turnsLeft: 4, flutter: 0, loot };
  // The 1/1 loss forecast is synthetic and checks only units/formatting, not an observed outcome.
  const text = lootCostText({ outcome: { enemyHpAfter: [{ index: 0, hp: 100 }] } }, thief, { lost: 1, samples: 1 });
  assert.ok(text.includes(`loot cost ${value.hp} HP:`));
  assert.ok(!text.includes('unknown HP'));
  assert.deepEqual(Object.values(lootHpOf([thief])), value.hp === 0 ? [] : [value.hp]);
  output.push({ run: entry.run_id, line: entry.line, hp: value.hp, status: value.status, text });
}
fs.writeFileSync(new URL('counterexample-consumer.json', taskDir), JSON.stringify({ exit: 0, cases: output }, null, 2) + '\n');
console.log('3 fixed historical classification/formatter cases passed');

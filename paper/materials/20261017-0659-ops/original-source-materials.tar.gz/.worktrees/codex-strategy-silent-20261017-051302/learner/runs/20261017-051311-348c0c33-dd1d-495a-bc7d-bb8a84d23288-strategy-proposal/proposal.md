# 本批策略提案核验与实现

批次：20261017-051302-strategy-proposal；角色：silent；来源局：M0GY0A4M2F7H、Z91JN3S3PQX2、LY83ZMTFVKJH，三局均A10。

本批只处理learn.json领取的十个原ID；无research_request、implementation_request或proposal_repair。初始工作树干净，按要求merge main为Already up to date；base=e5fc1a2d90b67b2a0dff253e9b0ba89fd3310aea。原十份Markdown均按专用队列保存SHA256复核并保留原字节；没有重复创建提案。

## 三项可复现的窄实现

1. **沙坑/钨棍终局（90a4…、6330…）**：Z91JN3S3PQX2 F33T13，s307493→307494、d299963、sl1235；账本silent-0313/0018/0178。17HP/8挡、沙坑1、THRASH_MOVE_2、空手，敌50血/5毒；实际HP归零、挡仍8、敌45血。旧判官因never logged with the Sandpit拒判。新分支只解除已见Silent A10、空手、该动作、现场已见能力范围且只有钨棍减损时的该拒判；其他保护/多敌/意图隐藏/敌可能先死/可用行动保护保留。不得把仅攻击需16的预算写为真实先损16再损1；不预支下轮滚石30或抱抱14，不声称SL会赢。原帧回归与合成边界分列；撤回judge独立提交恢复旧保守行为。

2. **紧勒的已见升级后续牌（04cb…）**：LY83ZMTFVKJH F21T7 s308030→308032（77→69→67，实10），F21T10 s308041→308044（40→32→18→16，实24），d300482/d300493；账本silent-0260/0261。既有普通紧勒源码5c7105ff0294466da8319f2934beda05c6040794已接2层，但升级匕首雨仍被未知分支排除，后续紧勒层被抹为null。新marker只由Silent A10升级DAGGER_SPRAY产生，求解器仍核双击、手动单次、普通2层和既有无挡无减损边界；两段攻击触发一次2失血，偏折再触发2。普通紧勒自身/升级建立/叠加/自动/重放/其他升级保持原边界。A0不借A10补证，铁甲保持等价；无因果整战胜负结论。回退本项独立提交。

3. **失窃卡的未知血价（c3ef…）**：LY83ZMTFVKJH F20T2 d300426（1000固定原样本，非本批新模拟）、s307971→307973，逃脱s307994与死亡s308053；账本silent-0314/0315。卡进度差21.464±0.9731、HP斜率−0.2843±0.0417、hp=null/status=flat，不能表成已证零。新显示仅Silent A10的失窃卡，保留原进度/误差、换算失败原因及已有丢牌样本；没有样本写未知。正HP/已知0、其他角色/未观察进阶维持原表达与数值。withLoot→thiefFact→lootCostText和thiefContextJson固定读回验证；lootHpOf/lastTurnLoot不造价。失窃后当前deck已无THRUMMING_HATCHET+，逃脱与死亡帧均不返还；rollout-live从当前run.deck建未来牌模型，本批不修改后继模拟牌组或重复罚分。所有展示线均预测逃脱，不能据另线12伤强制救牌。回退本项独立提交。

## 每项派发处置与具体缺口

### silent-proposal-2d711af284735508

核墨影全败与SL换线的同底板血价、滑溜实际进度和成长兑现；缺整场对照时保留现探索与护栏门槛

账本：silent-0079, silent-0224, silent-0227, silent-0005；证据局：M0GY0A4M2F7H。

F17T9同底板替线实多扣6敌血、多损9自身血，但原/替完整后继未配对；末试T3药时点与牌序同时变化。已有候选/SL审计不能证明跨抽牌完整执行，缺可信整战配对，不改探索或HP门槛。

### silent-proposal-1de0737d94ac87f5

沙虫能力实际建立与双结束线核算，记录两次护栏预计省22血少26伤；不凭单局统一提前滚石或改护栏

账本：silent-0093, silent-0094, silent-0125, silent-0005, silent-0018, silent-0162；证据局：Z91JN3S3PQX2。

F33T3已存在建滚石候选、随后另喝挡药；T5/T11护栏预计共省22血、少26伤，原线均未整场执行。缺支付能力后的受控抽牌/截止后继及整战比较，不能由T9启动较晚统一改setup/护栏。

### silent-proposal-90a4a4981be3c760

接入本角色A10已观察钨棍不能阻止沙坑归零致死的组合；窄化判官未知项，其他防死与未知条件保守

账本：silent-0313, silent-0018, silent-0178；证据局：Z91JN3S3PQX2。

窄接已见Silent A10空手THRASH_MOVE_2、钨棍/沙坑1终局；其余减损/复活/敌先死/隐藏意图保护保留。

### silent-proposal-16f7cf00059df9a0

本局毒药施6毒、挡药加12及生成牌实际兑现接线；取得与SL恢复分账，不拟新饮用或留药门槛

账本：silent-0079, silent-0224, silent-0278, silent-0276, silent-0023；证据局：M0GY0A4M2F7H, Z91JN3S3PQX2。

F33T12毒0→6当步敌HP136不变、随后结6+5；M末试无色生成闪亮登场未打而后弃。缺生成药产物与后继执行的完整配对/分布、普通毒药及阻挡组合的统一消费者校准；保留饮后重算与未知退路，不拟喝留门槛。

### silent-proposal-ab3bf902b22662f4

静默实建敏捷、临时减力与轮初成长伤害的兑现核验

账本：silent-0005, silent-0012, silent-0023, silent-0093, silent-0094, silent-0162, silent-0046；证据局：Z91JN3S3PQX2。

步法/尖啸/滚石/抱抱/余像在原帧可核，但复合提案要求支付、建立、轮初与后继来源联合核算。现有局部模型及审计不构成整组消费者通过；本局无提前能力的同盘受控整战后继，不拟永远先能力规则。

### silent-proposal-6330c4ade7528ec9

静默钨合金棍不能据此抵挡沙坑：已观察组合的窄判死核验

账本：silent-0178, silent-0313, silent-0018；证据局：Z91JN3S3PQX2。

与90a4原提案共用同一窄源码实现，不新增重复id；只改变已观察组合的判官拒判。

### silent-proposal-089bd208926f8962

静默资源接续与HP护栏的即时血价、能力启动和截止分账

账本：silent-0019, silent-0020, silent-0243, silent-0021, silent-0125；证据局：Z91JN3S3PQX2。

资源等式56−95+113−29+34=79与护栏预测22/26须分开；原线未整场执行、早期路线预测条件后来改变。已有护栏/路线审计不闭合能力支付、截止及条件营火的联合消费者配对，缺固定原/替线完整后继。

### silent-proposal-9849e537607099bd

静默敏捷、毒与痊愈药水已见药效和实际结算核验

账本：silent-0276, silent-0278, silent-0240；证据局：Z91JN3S3PQX2。

F12加2敏、F28加1能抽2且HP不变、F33施6毒均是局部观察；药效正确不证明新喝留/购买策略。缺三药与生成/重算路径的统一固定消费者对照及未观察药池边界，不新设药价/时点。

### silent-proposal-04cbbf6b3a547aea

补普通紧勒真实2层与逐牌失血接线；核本局T7预测8实10、T10预测20实24，先合并既有bug提案链，未知边界保留。

账本：silent-0260, silent-0261；证据局：LY83ZMTFVKJH。

保留已有普通紧勒实现5c7105ff；新增本局T10已见升级匕首雨的单次2失血及后续偏折接续，仅Silent A10。

### silent-proposal-c3ef922a9a5f8285

失窃卡hp未知与已测构筑进度损失分开表达、核逃脱后牌组；本局正卡进度21.464但负HP斜率，先分类与题面验证，不设固定HP牌价。

账本：silent-0314, silent-0315；证据局：LY83ZMTFVKJH。

Silent A10候选把hp=null显示为血价未知，保留卡进度/换算原因与丢牌样本；数值排序/已知零和正HP不变，当前牌组失窃/逃脱后不返还已从原帧核验。

## 支持、反例与未知

三局失败不是机制反例，也不证明改线可转胜。M同底板T9局部损血/伤害可比，T3饮药/牌序混杂；Z护栏原线没有整战执行，沙坑攻击独立结算次序缺帧；LY升级后续牌仅核本局双击匕首雨，不外推其他升级/叠层/穿挡。失牌已知零、正HP和外角色用例只是合成分类保护，不当新增游戏观察。原提案列举的其他Silent历史只保留其来源，本批未扩为全历史研究。

本批不新增经验支持/反例计数，不改经验库；源码消费者固定读回不等于自然局已采用或收益提高。保留原dirty运行记录9949a5de+dirty、049dff24+dirty，当前源码不冒充当时完整dirty树。

## 验证方法与输入边界

共用extract_evidence.py冻结八流source_size，3243条选中原行逐offset/bytes/SHA256和完整JSON复核，states/runs另核Silent A10身份。run-plans按run字段归属，正文提及不算所属；fight-plans在该截点0条只说明未选中。见evidence/evidence-manifest.json与evidence-verified.json。

固定回归不联网、不调LLM、不运行play、不读取刷新知识JSON；原帧完整保存，合成变体明示。各项源码撤掉时核心固定用例必须失败，恢复后通过；随后按原test-sandbox.sh跑完整沙箱可运行套件。首次测试初稿多敌变体复制了攻击导致攻击本身致死，以及非空手拒判原因断言不准，已保留rod-before/rod-after原件并修正测试输入，最终removed/restored单独保存。首次dispatch脚本误把learn.json批次当顶层key的KeyError已纠正，无记录写入。

安全边界：一次搜索意外输出旧其他角色测试夹具的一整行；未将其用于本批结论、新增夹具或数值。后续新增材料只取这三局。所有原记录与失败日志保留。

生产套件、提交、合入和版本的最终状态见report.md；本提案不预填成功。

## 沙箱首轮终局与受限包装器补验

原入口首轮：tsc已通过；Vitest 458文件/4254项过，唯一global-build-health.test.ts因spawnSync /usr/bin/python3 EPERM失败，总退出1、943.60秒。原内部4项Python已显示OK；独立python3 -B agent/tests/global_build_health_test.py再核4项、exit0，原paths.test.ts fork模式11项exit0。全部原断言/时限/脚本及首轮日志保持。

第二次仅在原脚本CLI临时额外排除这一个已证沙箱受限的子进程包装器，paths仍由原入口执行：bash tools/test-sandbox.sh --exclude tests/global-build-health.test.ts。这不是改测试源码或把首轮full1改写为full0；最终状态见report.md。所测四叶源码SHA和暂存树保持，尚未因补验提前提交、合live或造正式版本。

## 原提案指定的三局分类回归补核

补充只属于c3ef原提案的三局较早Silent A10：PU80F84P6HPN d247224普通步法hp0/status=worse_with；5X2GHKJ89PN1 d248287串刺hp0/status=worse_with；NB8KCF6HRGVF d247822弹跳药瓶+ hp20.7/status=ok。共用入口另存decisions/runs封套，2431原行逐offset/bytes/SHA与JSON核验（不覆盖主三局3243行）。未全量补研究或重抽较早战后返还帧，不把较早整体胜负当本局救牌反事实。

三原估值经当前cardHpOf、cardLoot、lootCostText、lootHpOf固定读回全部exit0；1/1丢牌预测只是单位/格式脚手架，非原实盘结果。知识数据文件读取被禁用。首次tsx CLI因沙箱listen IPC EPERM失败保留，改用node --import tsx直接模块加载后3项过，代码/输入不改。见counterexample-verification.json与counterexample-consumer.json。

沙箱第二次457文件4251项过，唯旧target-options三项在原20/30秒时限超时，exit1/1129.60秒；首轮同树该文件已过。按任务要求仅作一次高负载超时复跑，SANDBOX_WORKERS=1，其他源码/断言/时限不改。最终第三次结果见report.md，前两次full1不回填。

## 最终修订r2：未知遗物组合保护

旧窄分支虽限制角色/进阶、空手、THRASH_MOVE_2及能力范围，仍未拒绝额外未知遗物。合成原终局帧添加UNOBSERVED_PROTECTION，不赋予任何游戏效果，当前判官实际certain=true，逻辑边界断言失败；这不是新增实盘反例。r2只接受原s307493已见九种遗物且不出现重复遗物行，其余组合沿原不确定分支，不假定未知遗物无效。原帧九遗物描述均已另读回，未引入其他角色知识。

r2固定4文件40项全过；撤回judge到原字节时2项失败/16项过，恢复40项过；额外未知遗物辅助消费者改为certain=false。首次独立judge导入触发既有循环初始化ReferenceError，按实际combat-plan先初始化后复现逻辑问题；原辅助入口错误保留，不作新游戏结论或另建提案。

旧sandbox-3在新修订后成为superseded，源码输入变化后即使终局0也不作为最终冻结树通过。最终冻结树/SHA、source-final.patch与后续sandbox-4单独保存；前两轮full1、旧树执行及所有初稿保留。一次工具启动在命令执行前因其他临时目录消失引起bubblewrap glob扫描错误，随后原命令重试成功，未当代码失败或删除其他目录。

## 最终源码与处置

三项源码提交已自测完成；最终冻结树与gitleaks均通过。live锁内保存三叶刷新为51511b28e8fa085adbd30f232e625ebee058fe59后，六共享记录仍冲突，未实际合入本批源码，不造版本或shipped。逐项最终状态与完整原始测试差异见report.md / proposal-results.json。

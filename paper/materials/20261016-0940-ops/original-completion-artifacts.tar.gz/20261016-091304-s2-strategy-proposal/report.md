# 本批策略核验报告

十项已领取提案均完成核对，均保留 waiting：缺完整受控后继或联合消费者校准。未改源码、经验或规则；没有提交、合入、版本或测试成功声明。详细逐项证据/账本/反例/预期行为在 [proposal.md](proposal.md)。

## 身份与范围

- batch：`20261016-091304-s2-strategy-proposal`；task=strategy-proposal，character=silent，reason=proposal。
- base/最终HEAD：`43dec287c6886ac22b509a30416d9931406c861e`。普通批次，已按要求合main，返回 Already up to date。
- root learn.json只读取本批对应行；原十proposal_ids完全一致，无proposal_repair/research_request/implementation_request。
- 专题普通匹配只读根notes/strategy-research-silent.json身份：该请求绑定20261010-150327，未匹配本批，继续原十提案。
- 本次派发十锚点：KEN58SH9SLZ6、TXZ6RVMQA09D、WQZVENQ7DTRP、02HB4L0C3C67、4D4J8USKCPAV、F4QKG4J1AJJZ、JLN5SK17W4FQ、LS8035TB32P3、NB8KCF6HRGVF、S9UZAK0JP0C0。
- 补充五局：SADL3CGYTGSR、1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH，均为已领取提案的直接来源。
- 运行模型/推理配置没有通过本批材料独立核验，不将自报型号或旧对局配置当当前原生会话证明。未修改模型、账号、配置或权限。

| 进阶 | 核实局号 |
|---|---|
| A1 | K3676LU8B0UH |
| A7 | SADL3CGYTGSR |
| A9 | F4QKG4J1AJJZ |
| A10 | JLN5SK17W4FQ、4D4J8USKCPAV、S9UZAK0JP0C0、NB8KCF6HRGVF、LS8035TB32P3、02HB4L0C3C67、KEN58SH9SLZ6、TXZ6RVMQA09D、WQZVENQ7DTRP、1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP |

## 原始材料与验证范围

共用入口一次抽取八流；`extraction.stdout.json`、`extraction.stderr.txt`、`evidence/evidence-manifest.json`保留。source_size在读取前冻结，逐行记录原line/offset/bytes/SHA；拒收冲突身份。`verify_prepare.py`独立seek回原日志核字节、SHA、JSON及显式身份，核对输出整体SHA与计数，exit 0。

| 流 | 所属行数 |
|---|---|
| states | 9815 |
| decisions | 9448 |
| sl-attempts | 78 |
| run-config | 15 |
| run-plans | 77 |
| brain | 481 |
| runs | 15 |
| fight-plans | 0 |

fight-plans=0仅表示本次冻结截点未选到所属行，不能据此断言原日志缺失。未复用零行初稿或旧截点。原流无效/未完成行计数见manifest，并未归属为本角色证据。

六次现有 `learner/audit-selection.ts` 有界离线调用全部exit 0，显式TMPDIR限定在本批scratch，nice19、串行、无LLM/网络/模拟池。每次输入/输出/stderr SHA、命令和退出码见selection/receipts.json；输入保留真实 `_line`/`_source_sha256`，仅移除agent_view。两条无decision_id元数据KEN274207、Q6 276607独立排除，原行保留于excluded-metadata.json，不补号或跨缺口认证连续性。

| 局号 | 有界层窗口 | 题段 | 动作记录 | 回合窗 | 可核回合端点 |
|---|---|---:|---:|---:|---:|
| 1913SE84AXQF | 17,18,19,23,24,28,29,30,31 | 21 | 152 | 24 | 6 |
| KEN58SH9SLZ6 | 3,4,5,11,12,15,16,17 | 92 | 488 | 106 | 70 |
| NHA2KW0RB7VP | 17,19,30,33 | 63 | 248 | 46 | 20 |
| Q6M2Y34MWKRE | 2,3,7,8,9 | 13 | 78 | 14 | 0 |
| TXZ6RVMQA09D | 43,45,46,48,49 | 63 | 197 | 41 | 22 |
| WQZVENQ7DTRP | 33 | 139 | 377 | 64 | 53 |

合计391题段、1540动作记录、295回合窗（171可核端点、124未知），1010相邻决策观测端点。全部完整候选结果均null；回执completed不等于效果或整线完成。有界窗口不是整局完整候选/因果验证。

## 证据结论与反例

- 狡诈九局42饮重现37×3/2×2/3×0的新增升级刀；不混进阶，不推留药/穿插用药胜因。
- KEN七饮、两次真实回复及六胜战净损[0,3,0,37,6,0]重现；F15零损已花两药，缺未用药/留Boss完整对照。
- TXZ F48第二/三次T6同盘面3损36敌净扣→0损27敌净扣；首战留4，F49 4→0、敌111未变，零手牌无可用药。后续条件未控制。
- WQ F33第二/三次T9同盘13损24敌净扣→22损39敌净扣；T7第二/末次同盘0损24→4损24，后者出牌末沙坑4→5。不能从一侧边界推出统一保血/换伤门槛。
- NHA F33T1第一/第五/六次端点1/7/7净损、8/24/24敌净扣；含次轮自动伤，原工具开场unknown保持，不补为整候选执行。
- Q6 F8普通紧勒103→95→85→85→83；弃牌完成才扣技能触发。Q6精英胜后2血接走廊死；1913 F29胜后46血入F31死，不是单场获胜便资源充足。
- 油灯九端点另核实际target_index：K367目标index1建8毒、SADL目标index1建10毒、NHA F17建10毒及F33六试X1建−2力/2弱。不是原17窗口/全组合认证。

`fact_audit.py`首次运行exit0，205项固定材料断言通过；`lamp_audit.py`首次exit0，九端点核验通过。原stdout/stderr和facts-audit.json/lamp-nine-observations.json保留。它们不是生产回归测试、量化模型重校准或自然消费者验收。

## 十项处置

| 提案 | 状态 | 未实现原因 |
|---|---|---|
| silent-proposal-08eaa60bcc449852 | waiting | 缺F15不饮用及同入口、同后继把药留至Boss的完整成对结果；七次饮用与两次真实回复不能校准持药价值。 |
| silent-proposal-92920295a648b540 | waiting | 缺保持抽序、生成牌、药栏及后续选择一致的两战完整替线；现有连战和开场子实现不能证明SL资源比较已校准。 |
| silent-proposal-a327449c331efbc1 | waiting | 缺攻防和沙坑两边界的完整受控后继、跨重规划的候选执行归属及独立胜局；9血换15敌净扣不能确定新SL阈值。 |
| silent-proposal-a099e89437e942bb | waiting | 确定生成与容量已有live子实现；仍缺计划妥当保留容量、出刀穿插、跨重问整候选派发及SL恢复的联合校准，42饮不能关闭整项。 |
| silent-proposal-47910f82a1fdd98f | waiting | 四血开场已有live子实现；仍缺留药、路线及SL的完整后继对照和未知回血/复活组合结算顺序，联合要求保留。 |
| silent-proposal-f1374df72d8e6a25 | waiting | 缺隔离机制误差后的同入口、同预算不用/早用/留药的整战及下一战成对结果；未执行早喝候选和两条失败资源链不能拟合新权重。 |
| silent-proposal-38a49e6c97f31eea | waiting | 普通紧勒已有live窄实现；仍缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准与受控整战后继。 |
| silent-proposal-ef0e38a5dbd3bc07 | waiting | 缺另一营火、事件、路线及用药时机的受控完整结果；实际资源链只核兑现，不能据两败拟合路线或终局权重。 |
| silent-proposal-7f820c02d39bfaea | waiting | 缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继；同局六次失败和1/7血价差不足确定新SL门槛。 |
| silent-proposal-04b6b430759815ed | waiting | 缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及未覆盖X值、升级组合及能力整战后继；九端点不能认证原17窗口或全组合。 |

## 源码、历史与后续

检查时live为 `ef4b07a64db0fb76eea7990b768fb8d3be47a4b4`。16个相关源码/工具叶中14字节相同，card-model.ts及sl/explore.ts仅历史Roy/Dai注释差；未覆盖刷新数据。三组已存在子实现来源及base/live祖先核验在source-provenance.json；未将这些窄实现登记为十项implemented/duplicate。

十五局原run-config均记录完整源码commit，dirty_files没有源码路径（run-source-boundaries.json）。当时刷新知识/移动表字节未完整冻结，因此不能恢复完整生产消费者输入；该限制不等于源码提交未知。未重建原105/109局总体、旧冻结校准、留出结果或全组合机制。

本批只经根learner/ledger.py update追加31个已关联账本的where/note报告链接。不重复添加support/repeat，不变更claim/first_run/prior/evidence/status/version，不新增提案id或填写shipped。追加前后物理前缀、所属行及fold保持核验材料见ledger-before.json、ledger-append-verification.json。

没有源码改动，所以撤源码失败/恢复通过不适用；tsc、vitest、cases均null，未运行生产测试。没有git commit，所以无提交前gitleaks成功声明；没有live合入、eval版本或规则双通知。已存在子实现及原宽父继续保留，后续新证据由原调度链处理，不自行领取其他任务。

完整提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-091304-s2/learner/runs/20261016-091314-3038fabf-057d-4ffa-8440-ced1808388f5-strategy-proposal/proposal.md`。报告：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-091304-s2/learner/runs/20261016-091314-3038fabf-057d-4ffa-8440-ced1808388f5-strategy-proposal/report.md`。
最终工作树/HEAD和追加结果以final-validation.json为准；scratch为被忽略材料，不进入源码提交。

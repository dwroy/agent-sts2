# 静默猎手策略提案逐项核验

本批：20261016-091304-s2-strategy-proposal。普通队列消费，十项全部处理。

基线：`43dec287c6886ac22b509a30416d9931406c861e`；开工工作树干净，`git merge --no-edit main` 返回 Already up to date。本批没有 research_request 或 implementation_request；根普通专题绑定其他批次，不能借用。

结论：十项均 waiting。没有新增策略源码、知识或规则变更，不建立重复提案，不把已上线子项当整项完成。以下均为对局证据核验及待实现行为，不是新游戏规则；原提案字节和SHA已保留。

证据保存：`evidence/` 八流19929条；`evidence-verification.json` 已逐行回查来源offset/bytes/SHA/JSON及显式身份。十五局均核角色silent；A1一局、A7一局、A9一局、A10十二局。五个补充局直接来自已领取提案，不扩到其他队列。

## silent-proposal-08eaa60bcc449852

账本：silent-0019、silent-0020。领域：potion。

证据：KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1共七次饮用；六胜战净损0/3/0/37/6/0。F12原帧280336起26→53、F16原帧280382起46→75。

反例与限制：F15零净损伴随两次饮药，不能当未饮也零损；实际回复不等于SL恢复。

当前/预期行为：保留现持药价值；按逐槽实际消耗、胜战退出资源和后战入口核资源结转。若以后调价，须按独立局和时间切分验证完整后继。

处置：waiting；缺F15不饮用及同入口、同后继把药留至Boss的完整成对结果；七次饮用与两次真实回复不能校准持药价值。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md`，原文SHA256 `4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`；原文副本 `silent-proposal-08eaa60bcc449852.original.md`。来源任务 `experience-update`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-92920295a648b540

账本：silent-0228、silent-0255。领域：combat、sl、terminal。

证据：TXZ6RVMQA09D A10 F48第二/三次T6原帧281480→281485、281536→281540：3损/36敌净扣与0损/27敌净扣；三次SL记录972/973/974，第三次首战赢留4。281563奖励4血，281565→281566第二Boss开场4→0、敌111不变、零手牌、空药栏。

反例与限制：首战赢且少损3也少扣9；两战最终仍败。后续抽牌和生成牌改变，不是受控的整战改善；预测全败并非必死证明。

当前/预期行为：已有同样本HP/药/复活传递与四血开场分支，保留低可信和SL限制。新增证据需同时验两战终点及可操作前入口。

处置：waiting；缺保持抽序、生成牌、药栏及后续选择一致的两战完整替线；现有连战和开场子实现不能证明SL资源比较已校准。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md`，原文SHA256 `f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`；原文副本 `silent-proposal-92920295a648b540.original.md`。来源任务 `postmortem`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-a327449c331efbc1

账本：silent-0079、silent-0018。领域：combat、sl。

证据：WQZVENQ7DTRP A10 F33第二/三次T9同指纹，282075→282079为13损/24敌净扣、282144→282148为22损/39敌净扣；第二/末次T7同指纹，282066→282072为0损/24净扣、282330→282336为4损/24净扣。

反例与限制：末次T7多付4血而出牌后沙坑从4变5；不能据T9血价笼统禁止多损血换延时。均无独立胜局。

当前/预期行为：继续并列显示血价、敌血/毒和沙坑预测；全败模拟不抹掉这些差额。不拟统一阈值、不放宽必死SL。

处置：waiting；缺攻防和沙坑两边界的完整受控后继、跨重规划的候选执行归属及独立胜局；9血换15敌净扣不能确定新SL阈值。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md`，原文SHA256 `e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`；原文副本 `silent-proposal-a327449c331efbc1.original.md`。来源任务 `postmortem`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-a099e89437e942bb

账本：silent-0030、silent-0257、silent-0258。领域：combat、potion。

证据：原提案九局42饮均由期望药物身份和唯一原帧核对：37次添3、两次添2、三次添0，新增均为升级SHIV。SADL3CGYTGSR A7、F4QKG4J1AJJZ A9及其余A10分列；WQZVENQ7DTRP F33第五/六次T11容量分支详见facts-audit.json。

反例与限制：满手饮用消耗药而不加刀；容量分支仅原观察，不能推所有生成牌或宣称穿插用药能赢。42饮不是42独立局。

当前/预期行为：沿已观察A7/A9/A10狡诈生成分支，保留其他分支；未来联合验证饮用—出刀—饮用及恢复后的整条合法执行。

处置：waiting；确定生成与容量已有live子实现；仍缺计划妥当保留容量、出刀穿插、跨重问整候选派发及SL恢复的联合校准，42饮不能关闭整项。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md`，原文SHA256 `e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`；原文副本 `silent-proposal-a099e89437e942bb.original.md`。来源任务 `experience-update`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-47910f82a1fdd98f

账本：silent-0018、silent-0019、silent-0020、silent-0021、silent-0025、silent-0079、silent-0198、silent-0228、silent-0255。领域：combat、potion、sl、terminal。

证据：TXZ6RVMQA09D A10 F49原帧281565→281566：4血至0、敌111未动；F48T6同盘局部代价及WQZVENQ7DTRP F33T7/T9两种血价边界均已核。

反例与限制：四血开场已覆盖本局观察分支；未知回血/复活组合仍不能补结算全序。局部多挡或多输出都未证明连战胜。

当前/预期行为：既有观察分支按新战开场扣血且不重复扣live/SL已结算现场；完整资源契约和阈值等待可核对照。

处置：waiting；四血开场已有live子实现；仍缺留药、路线及SL的完整后继对照和未知回血/复活组合结算顺序，联合要求保留。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md`，原文SHA256 `d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`；原文副本 `silent-proposal-47910f82a1fdd98f.original.md`。来源任务 `experience-update`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-f1374df72d8e6a25

账本：silent-0019、silent-0020、silent-0050、silent-0253。领域：combat、potion、terminal。

证据：1913SE84AXQF A10 F29首可操作61血、奖励46血；F31以46入场死亡。Q6M2Y34MWKRE A10 F8由57胜至2、F9以2入场死亡；F2T1早饮敏捷候选未完整实打，原请求与重问均保留在有界输入。

反例与限制：Q6 F5/F6赢战零损，不能推出所有药都应早喝；F8漏紧勒与价值参数分开。不同候选并非同预算完整后继。

当前/预期行为：保留持续/临时药效和退出HP分账；完整后继用于将来检验持药和终局价值，先不调整数值。

处置：waiting；缺隔离机制误差后的同入口、同预算不用/早用/留药的整战及下一战成对结果；未执行早喝候选和两条失败资源链不能拟合新权重。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md`，原文SHA256 `df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`；原文副本 `silent-proposal-f1374df72d8e6a25.original.md`。来源任务 `postmortem`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-38a49e6c97f31eea

账本：silent-0006、silent-0011、silent-0025、silent-0044、silent-0050、silent-0064、silent-0133、silent-0253、silent-0259、silent-0261、silent-0262。领域：combat、potion、sl。

证据：Q6M2Y34MWKRE A10 F8T4原帧282887—282891敌103→95→85→85→83，普通紧勒建2，弃牌完成才见技能触发；1913SE84AXQF A10 F31弃磨蚀、荆棘及重接现场位于本批冻结流。

反例与限制：技能请求和选牌完成之间不是同一步；既有普通紧勒修复不认证弃磨蚀、自动触发、增益分源或SL恢复的全组合，也不证明整局得救。

当前/预期行为：仅核已观察普通无挡分支；保留临时/持续/自动伤与能力实际建立时点，未知组合不扩大。

处置：waiting；普通紧勒已有live窄实现；仍缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准与受控整战后继。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md`，原文SHA256 `6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`；原文副本 `silent-proposal-38a49e6c97f31eea.original.md`。来源任务 `experience-update`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-ef0e38a5dbd3bc07

账本：silent-0019、silent-0020、silent-0021。领域：combat、potion、terminal。

证据：1913SE84AXQF A10 F24为40→40（锻造不回血）、F28为40→61，F29胜至46、F31以46入场；Q6M2Y34MWKRE F7为36→57、F8胜至2、F9入2死亡。

反例与限制：1913 F24计划条件变更，不能将原精英投影60与实际46之差全算同条件模型误差。Q6已休息仍败，不等于拒绝回血。

当前/预期行为：只计实际动作、实际回复和已建能力，不预支未来火；旧109局统计未重建，不新增权重。

处置：waiting；缺另一营火、事件、路线及用药时机的受控完整结果；实际资源链只核兑现，不能据两败拟合路线或终局权重。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md`，原文SHA256 `d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`；原文副本 `silent-proposal-ef0e38a5dbd3bc07.original.md`。来源任务 `experience-update`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-7f820c02d39bfaea

账本：silent-0079。领域：combat、sl。

证据：NHA2KW0RB7VP A10 F33T1第一/第五/六次原帧283391→283397、283478→283483、283502→283507，玩家30→29/23/23，敌合计净扣8/24/24。第五/六次出牌末挡8、第一试14；六次SL记987—992。

反例与限制：跨轮净扣含轮初自动伤，不冒当单卡输出。工具T1开场仍unknown，手工局部端点不补成整候选认证；六败是同一局。

当前/预期行为：现SL预测差额和单动作回执保留；继续区分即时存活、击杀推进与未知抽序，缺完整胜负样本不改门槛。

处置：waiting；缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继；同局六次失败和1/7血价差不足确定新SL门槛。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md`，原文SHA256 `bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`；原文副本 `silent-proposal-7f820c02d39bfaea.original.md`。来源任务 `postmortem`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## silent-proposal-04b6b430759815ed

账本：silent-0005、silent-0006、silent-0021、silent-0011、silent-0065、silent-0264、silent-0079、silent-0133、silent-0169、silent-0189、silent-0013、silent-0053、silent-0162、silent-0265。领域：combat、terminal。

证据：K3676LU8B0UH A1 F30T2原帧217009→217010目标index=1的BOWLBUG_NECTAR建8毒；SADL3CGYTGSR A7 F45T1原帧232562→232563目标index=1建10毒；NHA2KW0RB7VP A10 F17T1建10毒及F33六试T1普通X1萎靡各建−2力量/2弱。九个端点见lamp-nine-observations.json。

反例与限制：目标按chosen.target_index关联，不以首敌替代。九端点不是原17窗口重建，更不是首次消费跨动作、新战、恢复身份的全组合认证。能力已持有也不能预支后轮收益。

当前/预期行为：现有已观察子公式保持；核当前目标、费用/手数/脆弱、能力建立及生存时点，未知组合待补证。

处置：waiting；缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及未覆盖X值、升级组合及能力整战后继；九端点不能认证原17窗口或全组合。

验证：本批固定原帧、完整保存的题面和六组有界离线执行审计；证据断言205项通过。未来整战验证必须固定输入、隔离机制误差，按run及时间后移留出；SL不能拆作独立样本。

来源：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md`，原文SHA256 `188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`；原文副本 `silent-proposal-04b6b430759815ed.original.md`。来源任务 `experience-update`；实现任务 `strategy-proposal/20261016-091304-s2-strategy-proposal`。

## 实现边界、校准与回退

已有live祖先子实现：狡诈生成/四血开场 `5b56a452bb9be14d620b368ec46974c1b57901ca`；普通紧勒/连战接口/SL候选预测 `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`；单动作派发回执 `fdaf787a372880b0438e73bcac7e6d2168b038ed`。只表示所列源码行存在，非十项整体实现。

本批不拟合血价、药价、路线或终局曲线；原105/109局分母、旧冻结校准与生产输入未重新验证。十五局run-config均有具体源码commit且dirty_files不含源码目录；缺当时刷新知识/公共移动表完整字节，所以无法复原完整运行输入，不能笼统称源码commit不可定位。

没有新的反向游戏结论；原反例及限制已逐项保留。本批不回写复盘、不改经验、不关闭学习父请求。没有代码回退对象；后续实现应单项隔离、先固定测试，再按live流程发布，回退仅撤对应实现，保留证据与并行数据。

import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
previous = root / '.worktrees/codex-strategy-silent-20261016-221302-s2/learner/runs/20261016-221312-1df78c3e-666c-4e58-be40-54a413553091-strategy-proposal'


def git(*args, cwd=workspace):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


prior_raw = (previous / 'source-audit.json').read_bytes()
prior = json.loads(prior_raw)
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=root / '.worktrees/live').decode().strip()
files = []
for old in prior['files']:
    path = old['path']
    current = (workspace / path).read_bytes()
    live_current = (root / '.worktrees/live' / path).read_bytes()
    assert current == git('show', f'{base}:{path}'), path
    assert sha(git('show', f'{prior["base"]}:{path}')) == old['base_sha256'], path
    row = {
        'path': path, 'base_sha256': sha(current),
        'previous_base_sha256': old['base_sha256'],
        'same_as_previous_base': sha(current) == old['base_sha256'],
        'live_sha256': sha(live_current), 'same_as_live': current == live_current,
        'live_source_clean_at_read': live_current == git('show', f'{live}:{path}'),
    }
    if current != live_current:
        # Ignore attribution comments only after preserving the complete patch.
        normalized = lambda raw: raw.replace(b'Roy', b'Dai')
        row['attribution_only'] = normalized(current) == normalized(live_current)
    files.append(row)

paths = [x['path'] for x in files]
(scratch / 'previous-base-source.patch').write_bytes(git('diff', '--binary', prior['base'], base, '--', *paths))
(scratch / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
ancestors = []
for old in prior['ancestors']:
    commit = old['commit']
    row = {'commit': commit, 'subject': git('show', '-s', '--format=%s', commit).decode().strip()}
    for target, head in [('base', base), ('live', live)]:
        rc = subprocess.run(['git', '-C', str(workspace), 'merge-base', '--is-ancestor', commit, head]).returncode
        assert rc in (0, 1)
        row[target] = rc == 0
    ancestors.append(row)

assigned = json.loads((scratch / 'assigned-proposals.json').read_text())
originals = []
for ident in assigned['ids']:
    item = assigned['originals'][ident]
    raw = Path(item['proposal']).read_bytes()
    assert sha(raw) == item['proposal_sha256']
    assert raw == (scratch / (ident + '.original.md')).read_bytes()
    assert item['character'] == 'silent'
    originals.append({'id': ident, 'path': item['proposal'], 'bytes': len(raw), 'sha256': sha(raw)})
(scratch / 'original-proposal-index.json').write_text(json.dumps(originals, ensure_ascii=False, indent=2) + '\n')

experience = json.loads((workspace / 'knowledge/characters/silent/experience.json').read_text())
ids = {e for p in assigned['originals'].values() for e in p.get('experience', [])}
selected = [e for e in experience['entries'] if e['id'] in ids]
assert {e['id'] for e in selected} == ids
(scratch / 'linked-experience.json').write_text(json.dumps({'version': experience.get('version'), 'entries': selected}, ensure_ascii=False, indent=2) + '\n')

audit = {'base': base, 'live_read_only': live, 'previous_audit': str(previous / 'source-audit.json'),
         'previous_audit_sha256': sha(prior_raw), 'files': files, 'ancestors': ancestors}
(scratch / 'source-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'live': live, 'source_files': len(files),
                  'same_as_previous': sum(x['same_as_previous_base'] for x in files),
                  'same_as_live': sum(x['same_as_live'] for x in files),
                  'different_files': [x for x in files if not x['same_as_previous_base'] or not x['same_as_live']],
                  'ancestors': ancestors, 'original_proposals': len(originals),
                  'linked_experience_entries': len(selected)}, ensure_ascii=False))

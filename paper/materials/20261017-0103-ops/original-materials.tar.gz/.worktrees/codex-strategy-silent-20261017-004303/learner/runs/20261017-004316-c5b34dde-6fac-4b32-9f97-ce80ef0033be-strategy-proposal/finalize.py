import hashlib
import json
from pathlib import Path
import re
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
batch_name = '20261017-004303-strategy-proposal'
batch = json.loads((scratch / 'batch.json').read_text())
source = json.loads((scratch / 'source-audit.json').read_text())
notes = json.loads((scratch / 'dispositions.json').read_text())
receipt = json.loads((scratch / 'ledger-receipt.json').read_text())
assert receipt['cli_rc'] == 0 and receipt['own_rows'] == 24


def git(*args):
    return subprocess.check_output(['git', '-C', str(workspace), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


prior = root / '.worktrees/codex-strategy-silent-20261016-061302-s2/learner/runs/20261016-061312-75aa99f7-7591-4dc3-92bb-76a83a3b598b-strategy-proposal'
consumer_base = json.loads((prior / 'source-audit.json').read_text())['base']
dependencies = set()


def collect(path):
    if path in dependencies:
        return
    dependencies.add(path)
    for match in re.finditer(r'from\s+["\'](\.[^"\']+)["\']', (workspace / path).read_text()):
        target = ((workspace / path).parent / match.group(1)).resolve()
        if target.suffix == '.js':
            target = target.with_suffix('.ts')
        assert target.is_relative_to(workspace) and target.is_file()
        collect(target.relative_to(workspace).as_posix())


collect('learner/audit-selection.ts')
dependencies.add('learner/resource_chain.py')
dependencies.add('learner/extract_evidence.py')
dependency_audit = []
for path in sorted(dependencies):
    raw = (workspace / path).read_bytes()
    old = git('show', f'{consumer_base}:{path}')
    assert raw == old, path
    dependency_audit.append({'path': path, 'current_sha256': sha(raw), 'consumer_base_sha256': sha(old), 'same': True})
(scratch / 'consumer-dependency-audit.json').write_text(json.dumps({'consumer_base': consumer_base, 'files': dependency_audit}, ensure_ascii=False, indent=2) + '\n')

previous = root / '.worktrees/codex-strategy-silent-20261016-221302-s2/learner/runs/20261016-221312-1df78c3e-666c-4e58-be40-54a413553091-strategy-proposal'
old_manifests = json.loads((previous / 'evidence/evidence-manifest.json').read_text()) + json.loads((previous / 'combat-evidence/evidence-manifest.json').read_text())
old_streams = {x['stream']: x for x in old_manifests}
current = json.loads((scratch / 'evidence/evidence-manifest.json').read_text())
same_streams = []
for stream in current:
    old = old_streams[stream['stream']]
    assert stream['output_sha256'] == old['output_sha256'] and stream['counts'] == old['counts']
    same_streams.append({'stream': stream['stream'], 'previous_source_size': old['source_size'],
                         'current_source_size': stream['source_size'], 'output_sha256': stream['output_sha256'], 'same_selected_bytes': True})
(scratch / 'previous-batch-selection-audit.json').write_text(json.dumps(same_streams, ensure_ascii=False, indent=2) + '\n')

dispatch_data = json.loads((root / 'ops/codex-ops/learn.json').read_text())
matches = []


def scan(value):
    if isinstance(value, dict):
        if value.get('batch') == batch_name or value.get('batch_id') == batch_name:
            matches.append(value)
            return
        for key, child in value.items():
            if key == batch_name:
                matches.append(child)
            else:
                scan(child)
    elif isinstance(value, list):
        for child in value:
            scan(child)


scan(dispatch_data)
assert len(matches) == 1
for key in ('task', 'character', 'runs', 'proposal_ids', 'worktree'):
    assert matches[0][key] == batch[key], key
assert not matches[0].get('research_request') and not matches[0].get('implementation_request')

ledger_path = root / 'paper/materials/learning/ledger.jsonl'
with ledger_path.open('rb') as handle:
    assert sha(handle.read(receipt['old_prefix_bytes'])) == receipt['old_prefix_sha256']
    for row in receipt['rows']:
        handle.seek(row['offset'])
        raw = handle.read(row['bytes'])
        assert sha(raw) == row['sha256'] and json.loads(raw) == row['row']

head = git('rev-parse', 'HEAD').decode().strip()
status = git('status', '--porcelain=v1', '--untracked-files=all').decode()
patch = git('diff', '--binary', 'HEAD')
index_patch = git('diff', '--cached', '--binary')
assert head == source['base'] and not status and not patch and not index_patch
(scratch / 'source-worktree.patch').write_bytes(patch)
timestamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(timestamp)
validation = {'recorded_at': timestamp, 'head': head, 'base': source['base'], 'status_porcelain': status,
              'worktree_patch_bytes': len(patch), 'index_patch_bytes': len(index_patch),
              'dispatch_still_matches': True, 'ledger_rows_reverified': 24,
              'consumer_dependency_files_equal_to_original_base': len(dependency_audit),
              'tests_run': False, 'source_commits': [], 'merged': None, 'release': None}
(scratch / 'final-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')

with (scratch / 'report.md').open('a') as handle:
    handle.write(f'\n最终验收：{timestamp}（先date）。根ledger CLI实际退出0，24条追加已逐offset/bytes/SHA/JSON读回，旧物理前缀和原字段/历史保持；本批五局/十ID绑定仍匹配。')
    handle.write(f'原离线消费者递归相对依赖加两份Python入口共{len(dependency_audit)}叶与实际原消费者base={consumer_base}同字节，八流也与上一221302-s2原manifest直接核为同SHA/计数；没有重跑消费者或模拟。')
    handle.write('HEAD仍等于完整base，tracked/index干净，source-worktree.patch为空。没有源码提交、live合入、版本或生产测试；十项waiting均保留具体缺口。\n')

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch_name,
          'base': source['base'], 'runs': batch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': batch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{'id': n['id'], 'state': n['state'], 'reason': n['reason']} for n in notes],
          'report': str(scratch / 'report.md')}
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
artifacts = []
for path in sorted(scratch.rglob('*')):
    if path.is_file() and path.name != 'artifact-manifest.json':
        raw = path.read_bytes()
        artifacts.append({'path': path.relative_to(scratch).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
(scratch / 'artifact-manifest.json').write_text(json.dumps({'artifacts': artifacts, 'scope': '本批材料，清单自身除外；无生产源码差量'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'head': head, 'clean': True, 'waiting': len(notes), 'ledger_rows': 24,
                  'consumer_dependency_files': len(dependency_audit), 'artifacts': len(artifacts),
                  'report': result['report']}, ensure_ascii=False))

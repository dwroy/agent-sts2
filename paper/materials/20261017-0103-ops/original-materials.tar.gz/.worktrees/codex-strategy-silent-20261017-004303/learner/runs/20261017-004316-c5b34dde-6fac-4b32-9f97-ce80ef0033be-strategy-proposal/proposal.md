# 本批十项静默策略提案逐项处置

记录时间：2026-10-17T00:56:55+08:00（写入前执行date）。批次20261017-004303-strategy-proposal；角色silent；实现任务strategy-proposal。

完整base：`345ef7a7099618af52a27a9ed5ffce6f9d6728dc`；只读核验live：`5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922`。本批十项均waiting，无源码或知识改动。

只处理assigned-proposals.json中本批已领取的十个原CLI ID；原Markdown已逐SHA保存为*.original.md，不另建重复提案。只在原证据范围内核算，来源任务、授权、历史方法/切分和全部反例以原件为准。本批不重做原提案声称的全历史统计。

共同验证边界：按实际局号、角色和已观察进阶分账；四个A10锚点用于相关策略核查，ZE8的A5仅用于现场版本观察。读档不拆成独立样本。实际取证、输入/输出SHA和材料核算不冒称生产测试、自然采用或整战因果。

## silent-proposal-19a5cff2094e2d8f — 同抽重打饱和死亡率与持续敌血池的终局价值审计

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：experience-update；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0021、silent-0064、silent-0079、silent-0133、silent-0125。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-sl.md

原Markdown SHA256：`7bf15ce1f8fd2291d52b8d24fc89de1fe613e8fd9812d31621f9cd48c8e2d57d`。

证据：MTQ0EUBJ3R6T A10 F23末试T3—T4（decisions282434、states288904/288905）；7X0W3U8TVA2A A10 F31T1—T13（states288401、288471/288472）。

处置：waiting。MTQ F23T3两候选均24/24死亡、即时损血0/8仍不同；7X F31存在重接血池。缺同输入同后继的整战校准、未截断入伤及持续实体归属，不能拟新SL或终局权重。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：1698adc96ba434a46942321e0237b70657e625b2、3f69541b5d3259dac94d3395bfe3da47936b4de9；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：原线先前已经失败，探索替线不等于宣称更安全。7X可见血池增加175、下降278是连续帧差，不能充作完整逐来源伤害或跨复活实体身份。

预期行为：保留原SL判死和探索规则；分别列当前实际HP、已结输出、持牌伤、毒和重接进度，不由饱和死亡率判即时血价等同。

验证与时间切分：冻结同指纹、同预算和同抽序的完整实际动作，分来源核未截断入伤及敌实体接续；以之后独立静默A10局作留出，不将SL拆成独立样本。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| decisions:282434 | MTQ0EUBJ3R6T | 727646777 | 18324 | 1255c15da8079392e399a9fab0c9057835afff32a1f7fce5a90a9b5aa6f9c97d |
| states:288904 | MTQ0EUBJ3R6T | 8932545648 | 38001 | abb96c8884568cf2aa9fa472013a1d1a5d99b5bcb0d1698d80e1b3d424f16fb2 |
| states:288905 | MTQ0EUBJ3R6T | 8932583649 | 38269 | 7853a048f47a1eeea9fdd93802626707d08091493178c61c2cc7efeba4ba45b7 |
| states:288401 | 7X0W3U8TVA2A | 8916843424 | 35552 | c8124fc63f2e7b9488e9bcb9fdea7ba47b3eb8e5a52cfc0c7ca6b6d27931a18f |
| states:288472 | 7X0W3U8TVA2A | 8919666143 | 36902 | e24cb6aee8c4af45ac72f352f2c23be0ceac2fe5cd3ce7e12bf7de6d4561746a |

## silent-proposal-3540bf4360bf80af — 连续赢战、已到回复与下一房入口分源记录

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：experience-update；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0019、silent-0020、silent-0243。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-resources.md

原Markdown SHA256：`58181f916f63872302d0ab2342b349e5de205083aa365151b8f4bcb79c1b63ce`。

证据：MTQ0EUBJ3R6T A10 F17→18（states288726/288727）19→59；7X0W3U8TVA2A A10 F31接续失败。F19/F20赢战及全局回复金额沿原提案引用，本批不重算全历史。

处置：waiting。跨幕HP增加边界与资源链已有实现；尚缺休息、开场、SL和逐槽药水的完整来源归因及路线/休息消费者联合读回，现有净变化记录不足关闭原提案。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452、3f69541b5d3259dac94d3395bfe3da47936b4de9；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：未抵达F24营火不是F23已有资源；未走路线没有可比较结局。HP增加观测器明确只定位边界，不隔离真实治疗来源。

预期行为：当前最大HP与已到回复、赢战消耗、存档恢复分别记录；保持原路线和休息规则，低阶或未观察交互不外推。

验证与时间切分：对同一连续资源链读回实际路线/休息题面，逐笔核休息、事件、开场、跨幕和SL；需要改阈值时另补同条件完整后继。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| states:288726 | MTQ0EUBJ3R6T | 8926223519 | 41067 | f3cacdc3948415e3d09f2433c57dae0e4cc6f0b9372761e7fc088af559057e2a |
| states:288727 | MTQ0EUBJ3R6T | 8926264586 | 23086 | eee9b5b3d41ec1ec18e48c4effd874c70231601eef7bd27bf79d9081196a8ea5 |

## silent-proposal-0ea5c0b9c030fdd6 — 静默A10知识恶魔：补奇巧选择的懒惰剩余名额与兑现条件；在本局已观察组合中验证毒药6层的量化候选，保留其他条件与提前饮用整场效果未知。

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：postmortem；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0274、silent-0247、silent-0027、silent-0016。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-054302-postmortem/proposal-sloth-potion.md

原Markdown SHA256：`ed57d3f8b54f0d056efe2e488a4dca2c2b32a7062433c636e71a51b395663391`。

证据：KFRDELW2TH2P A10 F33六次T7（decisions282864/282899/282933/282968/283001/283035）；末试states289533—289538。

处置：waiting。奇巧名额/费用提示和限定恶魔6毒入口已在live；提示仍continuation_verified=false。缺自动重放、合法完整后继与多轮收益校准，不将局部入口登记成整项duplicate。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：c4a4f4a94b48dff9b30aaa7228624c1092150145；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：手上技法7挡有效，不能因奇巧爆发未出而否定整张牌。末试毒药37→43后85毒伤、敌余74，换对象、换顺序或早喝的整战结果未知。

预期行为：继续显示当前手牌、剩余手动名额上界、能量和后继条件；未实出目标不计收益，条件外毒药保持未知，不固定指定对象或用药时点。

验证与时间切分：在原固定状态分别核满3次后锁牌、毒药当步只施毒和后轮两结；补每个合法对象的完整执行及自动重放名额核证后再评估完整收益。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| decisions:283035 | KFRDELW2TH2P | 730182982 | 2010 | 1d5a63433760455f87e15d49b86e407bee537201b9919e51edcee8a772a2a992 |
| states:289533 | KFRDELW2TH2P | 8952416481 | 37323 | fea8bec98655d36e3e9c1bf367e56cca3a1ac0be397c4b15a3015cbfff315b3d |
| states:289535 | KFRDELW2TH2P | 8952489762 | 35188 | 49bafb03d6e0cbb26cde57a96afe65ea6324c02da2e9c8de74c1e6a29e7b589d |
| states:289536 | KFRDELW2TH2P | 8952524950 | 34361 | 0f74065d57858f6af148e274beb15589aae44df3718c55a5224b7e4d31bbdf1e |
| states:289537 | KFRDELW2TH2P | 8952559311 | 34076 | d89cede2e0036f67b481c71a5db89b6beed69127fc0d4d3b519b57d6457d437b |
| states:289538 | KFRDELW2TH2P | 8952593387 | 32965 | e9dabf92cbe910af986f63a75a20211f26ee387a07b8f2e8db82d29986725b87 |

## silent-proposal-f915ec544ab94b6e — 追踪静默A10护栏完整候选到重问后实线的预测失效，记录SL同盘多10伤／多6损的局部血价；无新阈值或已胜反事实。

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：postmortem；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0079、silent-0125。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-054302-postmortem/proposal-sl-tradeoff-guard.md

原Markdown SHA256：`2339e1598f60a64fa1db9be3ebe3cecfe7057ff323c14f15341ccce85b15de98`。

证据：KFRDELW2TH2P A10 F12T1（decisions282578/282579）；F33首试/第三试T6（decisions282929、states289339/289345/289414/289420）。

处置：waiting。已有离线原答→SL替换→重问→执行关联，但完整候选收益仍null；KFR F12护栏后生刀重问改线，F33T6缺整轮可归属开端，无法用实际净差校准原完整候选或新排序。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：02c4e13ac8e159b82ee35a965ac788a0a029ce5a、e75438488df159b2e8e9d3458cf219b39aadd933、1698adc96ba434a46942321e0237b70657e625b2；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：T6同15血/228敌/36毒/3覆甲，原线损6净扣83、替线损12净扣93；两线都未赢。F12完整0损候选没实打，实际6损不能直接证明该候选预测错。

预期行为：保持当前护栏和SL探索；完整候选预测、派发动作、生成后重问和实际资源端点分别记录，不跨不同实线归收益。

验证与时间切分：冻结原候选每步身份及派发结果，记录首次中断点和之后所有重问；仅对完整可核同输入后继作成对校准。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| decisions:282578 | KFRDELW2TH2P | 728199257 | 11032 | 6bef2086842505f6db9fedf31293b8deeeac7ec2bb0ac6467707feab440a20db |
| decisions:282579 | KFRDELW2TH2P | 728210289 | 7982 | 2d4811ef4c0cc840af4d708bbbfb4aae07496123b018f0393f6be2506e30093b |
| decisions:282929 | KFRDELW2TH2P | 729716357 | 9669 | 251902c3d9304fe86b6b775af2c9372b9417f1a2108d629a4859deeabd255ae4 |
| states:289339 | KFRDELW2TH2P | 8945482839 | 36484 | e30c0b700db05548fe6bde4b079994a14ae31e6e6581eedf43ccd51f0d64e446 |
| states:289345 | KFRDELW2TH2P | 8945696297 | 36789 | ec2ba830e7b777304f891fef4bc999b57e17a7a2ace9a7d51ee7614ea1abedad |
| states:289414 | KFRDELW2TH2P | 8948164361 | 36484 | cfe239afafede3768773c5fe1e205b76a1ab79fd66895ccb57c4ea0d52ec0e4f |
| states:289420 | KFRDELW2TH2P | 8948377489 | 36785 | d282a46e1ef282eb062084408c77e3a5002e59a2c8f24c4536a95c451b9d6fe6 |

## silent-proposal-8fb51933639faf90 — 已观察药效和能力的分时点模型覆盖核验

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：experience-update；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0005、silent-0006、silent-0027、silent-0189、silent-0276、silent-0277、silent-0278。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-mechanisms.md

原Markdown SHA256：`540a529f428b0c342abb969c3d040446149db3d7fb4f855b23f4b950462a64ab`。

证据：KFRDELW2TH2P A10 F28T2敏捷药；F33T2铁心、T3起能量、T5触媒、首/第三试T6和六次T7。直接复核末T6/7原帧，其余历史数量保留原提案归属。

处置：waiting。已有限定毒药、力量、敏捷和覆甲局部模型；缺覆甲完整减层条件及能量/药效/能力在多入口叠加时的联合消费者校准，当前未定位新可隔离数值失配。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：c4a4f4a94b48dff9b30aaa7228624c1092150145、a32050fbce4c2863f640468c2dbf378fc9157074；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：覆甲7→后轮剩层不能推出完整固定减层规则；制品阻毒、头骨加量属于条件分支。提前用药没有同后继整战对照。

预期行为：按现场力敏、当前覆甲和实际能量计价；不追补旧挡、不预支未建能力，不放宽未观察组合，也不拟药水持有价。

验证与时间切分：先恢复当时源码与知识/移动表实际输入，再对局部固定状态核逐牌挡、药槽、建层和结毒时点；多入口联合轨迹另行校准。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| states:289339 | KFRDELW2TH2P | 8945482839 | 36484 | e30c0b700db05548fe6bde4b079994a14ae31e6e6581eedf43ccd51f0d64e446 |
| states:289345 | KFRDELW2TH2P | 8945696297 | 36789 | ec2ba830e7b777304f891fef4bc999b57e17a7a2ace9a7d51ee7614ea1abedad |
| states:289536 | KFRDELW2TH2P | 8952524950 | 34361 | 0f74065d57858f6af148e274beb15589aae44df3718c55a5224b7e4d31bbdf1e |
| states:289537 | KFRDELW2TH2P | 8952559311 | 34076 | d89cede2e0036f67b481c71a5db89b6beed69127fc0d4d3b519b57d6457d437b |

## silent-proposal-b3bc0eb09211af6c — 奇巧可执行后续、SL血价与实际终结核验

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：experience-update；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0021、silent-0079、silent-0102、silent-0247、silent-0274。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-sl-selection.md

原Markdown SHA256：`f3279ab3f48180d287e7ad57c0a1484e56ed48910772aac748dd6faf32185bf9`。

证据：KFRDELW2TH2P A10 F33T6/T7及F12T1，关键原帧states289339/289345/289414/289420/289533—289538。

处置：waiting。奇巧资源提示与SL即时血价审计已有；完整后继、未建立能力收益和终局价值仍未校准。六次T7及局部换线均无可核整战胜线，不能由此设新保血或用药规则。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：c4a4f4a94b48dff9b30aaa7228624c1092150145、1698adc96ba434a46942321e0237b70657e625b2；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：损血6→12同时净扣83→93，不证明探索不应发生；末43+42毒后敌74尚活。候选0损在生刀后重问中断，没有另一顺序能赢的实盘。

预期行为：将持有、选中、实际施放、能力建立和结算分开；维持现有SL严格必死边界，不把未兑现奇巧或未结毒记胜线。

验证与时间切分：固定完整选择→实际执行→回合终点，核自动重放和有限名额；以独立后续局核整战剩血/输出，不拟单局全局权重。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| states:289339 | KFRDELW2TH2P | 8945482839 | 36484 | e30c0b700db05548fe6bde4b079994a14ae31e6e6581eedf43ccd51f0d64e446 |
| states:289414 | KFRDELW2TH2P | 8948164361 | 36484 | cfe239afafede3768773c5fe1e205b76a1ab79fd66895ccb57c4ea0d52ec0e4f |
| states:289536 | KFRDELW2TH2P | 8952524950 | 34361 | 0f74065d57858f6af148e274beb15589aae44df3718c55a5224b7e4d31bbdf1e |
| states:289538 | KFRDELW2TH2P | 8952593387 | 32965 | e9dabf92cbe910af986f63a75a20211f26ee387a07b8f2e8db82d29986725b87 |

## silent-proposal-fdc3a505fe5e1a55 — 赢战血价、已到回血与跨幕回复事实分源

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：experience-update；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0019、silent-0020、silent-0243。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-resources.md

原Markdown SHA256：`9591f8717f33da220db658aaa746a04412cd9b324bb60fbb2f9a376a0796ea75`。

证据：KFRDELW2TH2P A10 F17→18（states289149/289150）22→60；F33T6/T7失败。全局营火126、小血瓶20、SL恢复145等金额仍为原提案的历史核算，本批未重新核算。

处置：waiting。KFR跨幕22→60等实际回复可分列且已有HP边界观测；缺完整逐源路线/休息消费者验收及可比替路线后继，不能从六次回血仍失败调整阈值或关闭整项。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：5c3dd2ea1500aa0eb8ebc4de73669c083d0a0452；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：F18计划投影和实际Boss入口并非同一未来输入；构筑、药水和沿途行动会变。SL恢复不是路线回血，后战失败不证明六次休息选择错误。

预期行为：实际到达节点、当前最大HP、赢战消耗与各类回复分别登记，保留预测为预测；原休息/安全节点规则保持。

验证与时间切分：逐源连接两战之间所有实际节点、消费与题面，核SL恢复未混入治疗，再另取同条件路线/休息的完整后继比较。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| states:289149 | KFRDELW2TH2P | 8939129182 | 38927 | 6e6cd5c4ef7d17b4fff577fb33361ffbbf045dcb03b283b3e662dbd739c7d2f7 |
| states:289150 | KFRDELW2TH2P | 8939168109 | 22981 | a5909fcde06975b2dd1d41429f4798ef825c0b2c1ae0092ef6b5a24d3966d8f2 |

## silent-proposal-5a95725089f53cd8 — A10三骑士同T2盘面复活后3/13血与8伤血价，补Jev原答/SL替换/重问/实际执行与逐槽资源链审计；两线均失败，保留评分和必死规则。

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：postmortem；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0019、silent-0079、silent-0005、silent-0016、silent-0087、silent-0027、silent-0030。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-064304-postmortem/proposal-resource-bloodprice.md

原Markdown SHA256：`802a23c7d736197db33e3c57daf42eb9064bc4b2ee56fc2f5733b3fdd73fcdb7`。

证据：GXNKW8X1XYJP A10 F45第2/末试T2—T3（decisions283641/283680/283690/283691、states290160/290165/290201/290206/290213/290214）；此前F35/38/40赢战资源链按原提案保留。

处置：waiting。GX同T2复活后3/13血、0/7挡及敌多8血可核，已有审计工具；缺复活瞬时逐击、未截断入伤、前三出口及完整候选归属，不足据局部10血差更改评分或SL。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：02c4e13ac8e159b82ee35a965ac788a0a029ce5a、a32050fbce4c2863f640468c2dbf378fc9157074、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、1698adc96ba434a46942321e0237b70657e625b2；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：两条同盘线均失败；末13HP+23牌/带挡+2覆甲对40需损15，hpAfter=-2是预计剩血。精灵为自动消耗，毒药为主动饮用，不能混记。

预期行为：保留原least-loss语义、护栏和SL规则；原答、替换、重问与实际执行分阶段，自动消耗/主动用药/新获/SL恢复按槽和来源分别记录。

验证与时间切分：用完整逐击复活帧与每次退出核真实代价，保留无精灵、未替换、缺出口和跨重问负例；不由净HP差推未截断需伤。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| decisions:283641 | GXNKW8X1XYJP | 732518556 | 18421 | bde181f405a7796c1b7f0743b5b4a28bc22d70e7d30c6c27ffcdf6f60228bff3 |
| decisions:283680 | GXNKW8X1XYJP | 732772699 | 19551 | c7afaeb3e085669c3523392852ea2c00c8b44238697d9704f5b45b2ade990200 |
| decisions:283690 | GXNKW8X1XYJP | 732830649 | 3549 | 3439bce2156a39d9a21572b7ef42ff8582f951e85a7e230db4e6ed1e551af5e7 |
| decisions:283691 | GXNKW8X1XYJP | 732834198 | 1459 | 83bf7d8553f2ae3f4aeca67b980c4fc884f1337248f78d2947ecab8c7f81ca88 |
| states:290160 | GXNKW8X1XYJP | 8973192215 | 51041 | d9a4bf6274eab69c7d54af2756e9674aaa214ddbe4460ff2edbf5bc1c6fe5b29 |
| states:290165 | GXNKW8X1XYJP | 8973437200 | 51091 | f5885bfe600d1e7bbc7b23e7a74233c55e8cd8729b5c4beaed730b2b7842f159 |
| states:290201 | GXNKW8X1XYJP | 8975259804 | 51041 | 1dbb2bba94d4f8ace96a1be5339ccd66f892bce8d939acf0630f093c1f6c55b1 |
| states:290206 | GXNKW8X1XYJP | 8975505600 | 51366 | b912464330cec1eac1e0ed2d35f26171b16cdeef7119f922cd5c3961327fccc9 |
| states:290213 | GXNKW8X1XYJP | 8975864878 | 50032 | 8fcff39ad290939ff3ea8552b290b34275711d2fbe4c0140b4ffb1ed140d1f83 |
| states:290214 | GXNKW8X1XYJP | 8975914910 | 46897 | 83c0d8bf41b3220dcb0a4b108de3057c701513679451988386268187249ed374 |

## silent-proposal-51fa8bc34774f72d — 修复已核silent抑制窗口同牌升级改标被SL作差记成假插入/离堆的身份问题；保持实际普通牌与场外升级分账，同ID歧义仍断序，当前无胜负改善证明。

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：postmortem；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0279、silent-0280。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-064304-postmortem/proposal-dampen-identity.md

原Markdown SHA256：`f84a6264bc2846c4e90323039a66b6a3a7104b3503431f942af68601951e1a67`。

证据：GXNKW8X1XYJP A10 F45T2→T3（sl-attempts1053—1056、states290160/290165/290201/290206）；ZE8F192FKX24 A5 F42T3/T4（states223268/223272、decisions218927/218928）仅作现场普通文本证据。

处置：waiting。GX四次普通键inserted及升级键作差路径仍存在；T2→T3同时抽牌，缺纯改标中间帧和唯一物理副本/并发顺序证据，不能仅以基ID守恒安全延长已知抽序。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：没有可证明本项完整实现的源码提交；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：同ID多副本、普通/升级混合及抽牌并发不能由总数守恒唯一恢复顺序；更早A5能读普通牌不证明A10抽序器正确，也不证明抑制导致败局。

预期行为：保留已知前缀的保守断序与实际战内普通文本，场外升级另账；仅当唯一身份及明确改标窗口已证时才实现重标配对。

验证与时间切分：补纯改标/恢复前后牌区的稳定唯一身份夹具，再核抽牌、插牌、同ID多副本和洗牌反例；不能按基础ID直接消除断序。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| sl-attempts:1053 | GXNKW8X1XYJP | 17692123 | 8419 | b28f7d668a68020eca64fb34b54b674f356aa21ae0852b9571dc68171d1588a7 |
| sl-attempts:1054 | GXNKW8X1XYJP | 17700542 | 11645 | 5777fee126eacd9911ee577bdc30cfdcc33508b8d3a56d030524c33c314b6c2d |
| sl-attempts:1055 | GXNKW8X1XYJP | 17712187 | 16704 | 3e4908e86f07cc6f96123814caa7ceb445f3aa6b2916bf8643a9c74d867d21c1 |
| sl-attempts:1056 | GXNKW8X1XYJP | 17728891 | 13134 | c45e02983cc4bf082d5b7133fc463af0ef6fe0845f17209e2b0a5cfbd6ad15d9 |
| states:223268 | ZE8F192FKX24 | 6727813397 | 43407 | fb533718af4113bf28f4ad8ceb3f2574633e21e384af4b2cab7969e1d4fbd595 |
| states:223272 | ZE8F192FKX24 | 6727981298 | 43642 | 49fe52b5565668af60d26656bd15ee31a0d557dbd06e07adc4db3e34d114cb33 |
| states:290165 | GXNKW8X1XYJP | 8973437200 | 51091 | f5885bfe600d1e7bbc7b23e7a74233c55e8cd8729b5c4beaed730b2b7842f159 |
| states:290206 | GXNKW8X1XYJP | 8975505600 | 51366 | b912464330cec1eac1e0ed2d35f26171b16cdeef7119f922cd5c3961327fccc9 |

## silent-proposal-29b7b36dffbcb017 — 实际能力、毒结算与现场力挡核验

角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。

来源任务：experience-update；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。

既有账本：silent-0005、silent-0006、silent-0011、silent-0016、silent-0021、silent-0027、silent-0030、silent-0087、silent-0278。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-071205-experience-update/proposal-mechanisms.md

原Markdown SHA256：`40866aa3c6ee72a028bee5c911c168ddb017fa740833376b7bf6dab1f7dca7eb`。

证据：GXNKW8X1XYJP A10 F33T5/T6（states289986/289987）29+28+27=84；F45T2/T3（states290206/290213/290214）触媒未建立且玩家实死。F17T9负力量取胜仍沿原提案引用。

处置：waiting。GX已建立触媒2层后的84毒伤及末战未建立可核，现有局部模型保留；缺头骨/毒雾/覆甲/力敏联合多轮消费者校准和完整时点对照，未定位新独立源码差额。

旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：a32050fbce4c2863f640468c2dbf378fc9157074、e75438488df159b2e8e9d3458cf219b39aadd933、83512ddcd2c70fd9b983dc38524ff25c8970c1d3；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。

反例与未知：末战持有触媒不等建立；未结毒、初始遗物扣血不能并入已实毒伤。提前饮药或先建能力没有同条件完整胜线；单个正确局部公式不证明联合模型已校准。

预期行为：按现场能力层和已结毒记实际输出，牌挡/覆甲/药效分源；不预支未建立能力，不设固定优先级或提前用药阈值。

验证与时间切分：固定现场逐项核力量每击、敏捷逐牌、头骨施毒与触媒结算，补联合多轮真实轨迹及时间后独立局；未知条件仍保留未知。

拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。

| 原流/行 | 局号 | offset | bytes | 原行SHA256 |
|---|---|---:|---:|---|
| states:289986 | GXNKW8X1XYJP | 8965831326 | 36219 | f94fc8fdd01cb7c6f2d92739441d2bb7cad89de8efcb924b28f0ff355c7156e9 |
| states:289987 | GXNKW8X1XYJP | 8965867545 | 35984 | 9ec0b627750121eced05eeaa7c46b27162a314ed47d2fc153fdcb2aa2c6f0045 |
| states:290213 | GXNKW8X1XYJP | 8975864878 | 50032 | 8fcff39ad290939ff3ea8552b290b34275711d2fbe4c0140b4ffb1ed140d1f83 |
| states:290214 | GXNKW8X1XYJP | 8975914910 | 46897 | 83c0d8bf41b3220dcb0a4b108de3057c701513679451988386268187249ed374 |

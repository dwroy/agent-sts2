import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
scratch = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
notes = json.loads((scratch / 'dispositions.json').read_text())
ledger_path = root / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger', root / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = sorted({i for n in notes for i in n['ledger']})
assert len(ids) == 24
prefix = ledger_path.read_bytes()
before = ledger.fold([(i, json.loads(raw)) for i, raw in enumerate(prefix.splitlines(), 1) if raw.strip()])
selected_before = {i: before[i] for i in ids}
assert all(item['character'] == 'silent' for item in selected_before.values())
(scratch / 'ledger-immediate-before.json').write_text(json.dumps(selected_before, ensure_ascii=False, indent=2) + '\n')

updates = []
for ident in ids:
    related = [n for n in notes if ident in n['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(scratch / 'proposal.md'), str(scratch / 'report.md')]},
                    'note': '20261017-004303-strategy-proposal：仅追加本批逐项追溯；' +
                    '；'.join(n['id'] + '=waiting：' + n['reason'] for n in related) +
                    '。6060原行与既有五局封套相同，37材料断言及2对原指纹/手牌核算通过；23相关源码叶未变。无新独立支持/重犯、源码或知识提交、生产测试、合入或shipped；原状态与证据保持。'})
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates).encode()
(scratch / 'ledger-updates.jsonl').write_bytes(payload)
timestamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(timestamp)
with (scratch / 'ledger-cli.stdout.txt').open('wb') as stdout, (scratch / 'ledger-cli.stderr.txt').open('wb') as stderr:
    result = subprocess.run(['python3', str(root / 'learner/ledger.py'), 'update'], input=payload, stdout=stdout, stderr=stderr)
(scratch / 'ledger-cli.rc.txt').write_text(str(result.returncode) + '\n')
if result.returncode:
    raise SystemExit(result.returncode)

after_raw = ledger_path.read_bytes()
assert after_raw.startswith(prefix)
ours = []
offset = len(prefix)
for raw in after_raw[len(prefix):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith('20261017-004303-strategy-proposal：'):
        expected = next(u for u in updates if u['id'] == row['id'])
        assert {k: v for k, v in row.items() if k not in ('op', 'ts')} == expected
        assert row['op'] == 'update'
        assert set(row) == {'op', 'id', 'ts', 'by', 'where', 'note'}
        ours.append({'id': row['id'], 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert sorted(x['id'] for x in ours) == ids
for item in ours:
    with ledger_path.open('rb') as handle:
        handle.seek(item['offset'])
        raw = handle.read(item['bytes'])
    assert hashlib.sha256(raw).hexdigest() == item['sha256'] and json.loads(raw) == item['row']

after = ledger.fold([(i, json.loads(raw)) for i, raw in enumerate(after_raw.splitlines(), 1) if raw.strip()])
protected = ['claim', 'character', 'kind', 'first_run', 'asc', 'prior', 'prior_note', 'evidence', 'status', 'version', 'effect', 'shipped_at']
for ident in ids:
    for key in protected:
        assert before[ident].get(key) == after[ident].get(key), (ident, key)
    for key in ('notes', 'history'):
        assert after[ident][key][:len(before[ident][key])] == before[ident][key]
    for key, values in before[ident]['where'].items():
        assert after[ident]['where'][key][:len(values)] == values
(scratch / 'ledger-after.json').write_text(json.dumps({i: after[i] for i in ids}, ensure_ascii=False, indent=2) + '\n')
receipt = {'recorded_at': timestamp, 'cli_rc': result.returncode, 'ids': ids, 'own_rows': len(ours),
           'old_prefix_bytes': len(prefix), 'old_prefix_sha256': hashlib.sha256(prefix).hexdigest(),
           'old_prefix_preserved': True, 'protected_fields_preserved': protected,
           'where_history_notes_prefixes_preserved': True, 'rows': ours}
(scratch / 'ledger-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_rc': result.returncode, 'appended_and_read_back': len(ours), 'old_prefix_preserved': True,
                  'protected_fields_preserved': True}, ensure_ascii=False))

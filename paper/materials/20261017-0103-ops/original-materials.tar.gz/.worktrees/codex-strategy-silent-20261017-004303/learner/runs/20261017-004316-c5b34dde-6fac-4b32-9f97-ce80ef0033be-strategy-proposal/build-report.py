import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]


def render(blocks):
    result = ''
    previous = ''
    for block in blocks:
        continuous = (previous.startswith('|') and block.startswith('|')) or (
            previous.startswith('- ') and block.startswith('- '))
        result += ('\n' if continuous else '\n\n') + block if result else block
        previous = block
    return result + '\n'


batch = json.loads((scratch / 'batch.json').read_text())
assigned = json.loads((scratch / 'assigned-proposals.json').read_text())
notes = json.loads((scratch / 'review-notes.json').read_text())
source = json.loads((scratch / 'source-audit.json').read_text())
integrity = json.loads((scratch / 'integrity.json').read_text())
checks = json.loads((scratch / 'evidence-checks.json').read_text())
consumers = json.loads((scratch / 'prior-consumer-receipt.json').read_text())
identities = json.loads((scratch / 'run-identities.json').read_text())
states = json.loads((scratch / 'selected-states.json').read_text())
assert [x['id'] for x in notes] == assigned['ids']
assert checks['failed'] == 0 and checks['passed'] == 37
assert all(x['same_selected_bytes_as_prior'] for x in integrity)
assert all(x['same_as_previous_base'] for x in source['files'])

pair_checks = []
for a, b in [('289339', '289414'), ('290160', '290201')]:
    left, right = states[a]['row'], states[b]['row']
    assert left['fingerprint'] == right['fingerprint']
    assert left['state']['combat']['hand'] == right['state']['combat']['hand']
    pair_checks.append({'lines': [int(a), int(b)], 'same_logged_fingerprint': True,
                        'same_raw_hand': True, 'hidden_state_or_followup_verified': False})
(scratch / 'paired-board-checks.json').write_text(json.dumps(pair_checks, ensure_ascii=False, indent=2) + '\n')

references = {}
for line, item in states.items():
    references['states:' + line] = item
for item in json.loads((scratch / 'selected-decisions.json').read_text()):
    references['decisions:' + str(item['line'])] = item
for raw in (scratch / 'evidence/sl-attempts.evidence.jsonl').open():
    item = json.loads(raw)
    references['sl-attempts:' + str(item['line'])] = item
anchors = [
    ['decisions:282434', 'states:288904', 'states:288905', 'states:288401', 'states:288472'],
    ['states:288726', 'states:288727'],
    ['decisions:283035', 'states:289533', 'states:289535', 'states:289536', 'states:289537', 'states:289538'],
    ['decisions:282578', 'decisions:282579', 'decisions:282929', 'states:289339', 'states:289345', 'states:289414', 'states:289420'],
    ['states:289339', 'states:289345', 'states:289536', 'states:289537'],
    ['states:289339', 'states:289414', 'states:289536', 'states:289538'],
    ['states:289149', 'states:289150'],
    ['decisions:283641', 'decisions:283680', 'decisions:283690', 'decisions:283691', 'states:290160', 'states:290165', 'states:290201', 'states:290206', 'states:290213', 'states:290214'],
    ['sl-attempts:1053', 'sl-attempts:1054', 'sl-attempts:1055', 'sl-attempts:1056', 'states:223268', 'states:223272', 'states:290165', 'states:290206'],
    ['states:289986', 'states:289987', 'states:290213', 'states:290214'],
]
for note, keys in zip(notes, anchors):
    item = assigned['originals'][note['id']]
    note['ledger'] = item['ledger']
    note['runs'] = item['runs']
    note['original_proposal'] = item['proposal']
    note['original_sha256'] = item['proposal_sha256']
    note['evidence_refs'] = [{k: references[key][k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}
                             for key in keys]
    assert all(ref['run_id'] in item['runs'] for ref in note['evidence_refs'])
    for commit in note['source_coverage']:
        ancestor = next(x for x in source['ancestors'] if x['commit'] == commit)
        assert ancestor['base'] and ancestor['live']
(scratch / 'dispositions.json').write_text(json.dumps(notes, ensure_ascii=False, indent=2) + '\n')

timestamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(timestamp)
proposal = [
    '# 本批十项静默策略提案逐项处置',
    f'记录时间：{timestamp}（写入前执行date）。批次20261017-004303-strategy-proposal；角色silent；实现任务strategy-proposal。',
    f'完整base：`{source["base"]}`；只读核验live：`{source["live_read_only"]}`。本批十项均waiting，无源码或知识改动。',
    '只处理assigned-proposals.json中本批已领取的十个原CLI ID；原Markdown已逐SHA保存为*.original.md，不另建重复提案。只在原证据范围内核算，来源任务、授权、历史方法/切分和全部反例以原件为准。本批不重做原提案声称的全历史统计。',
    '共同验证边界：按实际局号、角色和已观察进阶分账；四个A10锚点用于相关策略核查，ZE8的A5仅用于现场版本观察。读档不拆成独立样本。实际取证、输入/输出SHA和材料核算不冒称生产测试、自然采用或整战因果。',
]
for note in notes:
    item = assigned['originals'][note['id']]
    proposal.extend([
        f'## {note["id"]} — {item["summary"]}',
        '角色/进阶：silent；策略核查仅已观察A10，抑制现场文本另含ZE8 A5。其他角色和未观察范围没有行为变化。',
        '来源任务：' + item['source_task'] + '；实现任务：strategy-proposal；既有授权：Roy-2026-10-07-learning（授权不提供游戏事实）。',
        '既有账本：' + '、'.join(note['ledger']) + '。',
        f'原提案：{note["original_proposal"]}\n\n原Markdown SHA256：`{note["original_sha256"]}`。',
        '证据：' + note['evidence'],
        '处置：waiting。' + note['reason'],
        '旧规则与已有覆盖：保留当前原行为。已核实际live祖先的子实现：' + ('、'.join(note['source_coverage']) if note['source_coverage'] else '没有可证明本项完整实现的源码提交') + '；仅证明上述受限子项，不能据此将原整项标为duplicate/implemented。',
        '反例与未知：' + note['counterexample'],
        '预期行为：' + note['expected'],
        '验证与时间切分：' + note['validation'],
        '拟合：本批不拟合全局权重、药水价格、保血或SL阈值；缺少的因果与身份不以先验补齐。回退：本批无行为差量可回退，已有源码和原失败证据保留；未来实现须独立固定正负例、撤源码失败/恢复通过及原沙箱检查后合入。',
        '| 原流/行 | 局号 | offset | bytes | 原行SHA256 |',
        '|---|---|---:|---:|---|',
    ])
    proposal.extend(f'| {Path(r["source"]).stem}:{r["line"]} | {r["run_id"]} | {r["offset"]} | {r["bytes"]} | {r["sha256"]} |' for r in note['evidence_refs'])
(scratch / 'proposal.md').write_text(render(proposal))

report = [
    '# 静默策略队列本批报告',
    f'记录时间：{timestamp}（写入前执行date）。task=strategy-proposal，character=silent，batch=20261017-004303-strategy-proposal。',
    '十个原提案均waiting。本批没有新增可支持规则修改的实盘输入，也未发现新的可隔离源码差额；没有源码或知识提交，fixes=[]、merged=null。已有局部实现保留，未关闭原宽提案或任何学习入库/量化父要求。',
    f'完整base/HEAD：`{source["base"]}`。开工git status为空；普通批次身份核实后git merge --no-edit main返回Already up to date。',
    '## 身份与范围',
    '已读README.md、STATE-2026-10-16.md、decision-log末尾、learning-protocol、learning-code-proposals及learning-requests。根learn.json只读本批行，task、character、工作树、五个runs和十个proposal_ids精确核对。没有research_request/implementation_request/proposal_repair；普通专题文件绑定另一个旧批，不适用本批。不领取其他队列项，不改调度状态或根请求。独立完成，未派下级agent。',
    '| 局号 | 角色 | 进阶 | 结束 |',
    '|---|---|---:|---|',
]
for run in batch['runs']:
    info = identities[run]
    report.append(f'| {run} | {info["character"]} | {info["ascension"]} | F{info["floor"]} {"胜" if info["victory"] else "败"} |')
report.extend([
    'ZE8 A5只用于抑制现场版本观察，不混作A10策略验证。角色已由runs.jsonl及原帧核实。旧run-config完整提交/dirty_files见historical-source-limits.json；当时dirty知识及移动表原字节未重建，当前源码不能充作历史完整运行输入。兼容deepseek_calls字段不能单独证明实际大脑来源。',
    '## 原始证据与复用',
    '本树共用extract_evidence.py以nice19提取八流，保存每流source_size、逐行原offset/bytes/SHA及计数。全部6060封套逐行seek原源重核SHA、JSON、截点和显式局身份，run-plans.run、run_id、state.run_id、fingerprint.run按同一入口处理，冲突身份拒收。原日志只读。',
    '| 流 | source_size | 核验行数 | 与旧封套SHA相同 |',
    '|---|---:|---:|---|',
])
for row in integrity:
    report.append(f'| {row["stream"]} | {row["source_size"]} | {row["verified_rows"]} | true |')
report.extend([
    '八流封套均与原061302-s2及上一批221302-s2的同五局输入一致。源文件扫描边界增长，不增加本批独立局、读档样本或可校准胜线。fight-plans该2233957字节截点选到0行，仅表示该截点未选到；不据此断言日志不存在。states/decisions/brain全源各有2条非法行，不将无法归属的非法行当本批故障结论。',
    '旧run-plans截点8380258用同CLI --streams run-plans --source-size独立复核，另存evidence-old-plans/；仍30行且封套SHA与本次8718364截点一致。保留所有旧报告与零行初稿，不覆盖或改写。各流截点分别记录，不声称同一墙钟快照。',
    '37项既有材料断言本批重算通过；另核KFR T6与GX T2各一对原指纹及完整原手牌相同，保存paired-board-checks.json。相同已记指纹不能证明隐藏状态、整战同后继或因果收益。它们不是tsc/vitest或生产cases。',
    '仅复核20份既有离线消费者输入、输出、stderr、退出码及资源链SHA；四个A10输入由当前原帧重构后逐字相等。对应七个learner源码叶与旧base相同，没有重跑消费者、模型或模拟。原离线rc0只保留历史归属，不报本批测试成功。',
    '| A10局 | 候选段 | 带ID动作 | 已核回合端点 | 未知回合窗 | 完整候选认证 |',
    '|---|---:|---:|---:|---:|---:|',
])
for row in consumers['summary']:
    report.append(f'| {row["run"]} | {row["segments"]} | {row["actions"]} | {row["turns"].get("observed_turn_endpoints", 0)} | {row["turns"].get("unknown", 0)} | {row["certified_full_candidates"]} |')
report.extend([
    '合483候选段、2101带ID动作；352回合窗中70个已核端点、282未知，完整候选认证0。KFR一条、GX三条无decision_id原元数据行保留，不补ID、不跨缺口认证连续性。认证为0表示该保守工具未认证，不能倒推出实际没有执行。',
    '## 支持、反例与限制',
    '- KFR F33T6同盘15HP/228敌HP/36毒/3覆甲，原线净扣83损6，替线净扣93损12；两线后续均失败。F12护栏完整0损候选在生刀后重问改线，不能将实际6损当该完整候选的预测误差。',
    '- KFR末T7手上技法后7挡、防御后12挡；三次手动动作后奇巧爆发剩1能仍被SLOTH锁。毒药37→43当步敌159不变，随后43+42=85、敌余74。手法7挡确有收益，换对象、顺序或早喝的整战胜负未知。',
    '- GX F45同T2复活后3/13HP和0/7挡，保血线敌多8HP；末13HP+23挡+2覆甲对40需损15，hpAfter=-2与实死一致。缺完整复活逐击、未截断入伤及前三退出帧，不能用净血差代总伤。',
    '- GX F33触媒已建2层时29+28+27=84；末战未建立不能预支。四次SL的普通键inserted和旧升级键作差路径仍在，但T2→T3伴随抽牌，缺纯改标瞬时帧和稳定副本身份；基础ID总数守恒不足以安全延长已知抽序。ZE8 A5普通现场牌与场外升级分账。',
    '- MTQ跨幕19→59、KFR跨幕22→60，与已到休息、开场和SL恢复分别看。MTQ F23T3两候选均24/24死亡而即时损0/8、扣敌13/19不同；原线先前失败，探索替线不等于宣称更安全。7X F31可见血池150+增加175-下降278=47仅是帧差核算，非完整逐源伤害或持续实体认证。',
    '本批没有重新计算原提案所有历史药水、营火、SL和路线总额，也没有恢复旧dirty输入；已引用金额均明确沿原提案归属。没有未走路线、未执行候选或提前喝药的受控整战结论，不添加预训练游戏事实，不拟静态阈值。',
    '## 现有源码覆盖',
    f'只读live提交：`{source["live_read_only"]}`，不是本批merged。23个相关源码叶全部与上一批221302-s2基线相同；18叶与live同字节，其余5叶只有历史Roy/Dai署名注释差且物理文件与live HEAD相符。两份精确binary diff已保存，不由有限叶一致推断全运行输入等价。',
    '直接读回：hand-trick事实仍continuation_verified=false；selection_audit仍actual_turn=null；SL资源比较scope=current_turn_prediction、execution=unverified；离线整轮的actual_uncapped_hp_loss/actual_full_candidate_result及causal_source仍为null。run-journal只给HP增加边界，resource_chain明确药槽变化不能独自分清饮用或丢弃。已有受限信息通道不等于完整执行归属或联合校准。',
    '| 真实源码commit（base/live祖先均true） | 子项 |',
    '|---|---|',
])
for ancestor in source['ancestors']:
    labels = ['限定恶魔毒药与奇巧事实入口', '离线选择与执行关联', '离线药水观测',
              '离线整轮端点观测', '末轮结束页HP观测', '实际HP增加边界',
              '敌HP变化与资源链', 'SL当前轮预测资源比较']
    report.append(f'| {ancestor["commit"]} | {labels[source["ancestors"].index(ancestor)]} |')
report.extend([
    '上述子实现不重复开发；全部十项原宽提案仍有各自未交付范围。没有新可隔离源码失配，铁甲及其他角色行为保持原样。未改知识构建器或重建知识。',
    '## 逐项处置',
    '完整证据局号/层/回合/账本、反例、预期行为、验证与原行offset/bytes/SHA逐项见proposal.md、dispositions.json和十份原Markdown。',
    '| 原CLI ID | 状态 | 具体缺口 |',
    '|---|---|---|',
])
for note in notes:
    report.append(f'| {note["id"]} | waiting | {note["reason"]} |')
report.extend([
    '## 记录、测试与交付',
    '本批只通过根learner/ledger.py update给24个既有账本追加where.proposal和note追溯，不改claim、first_run、prior、evidence、status、version、effect或shipped，不重复support/repeat，不重写历史复盘。没有新增经验或新代码提案ID；最终code_proposals沿用十个已派原CLI ID。实际写入成功及逐物理行读回以ledger-receipt.json为准。',
    '源码撤掉失败/恢复通过不适用；tsc/vitest/cases均未运行，tests={"tsc":null,"vitest":null,"cases":null}。材料断言不填生产cases，不借旧绿。本批没有代码提交，因此不执行提交前测试/gitleaks或live合入；没有eval版本、decision-log上线行或规则双通知，不冒implemented/shipped。',
    '没有新科学冲突或需要新增决定的结论；旧限制明确保留，未强行支持原假设。不代ops/watcher/Roy确认，不把本报告结束当父学习要求完成。未运行play、游戏API、网络、LLM或模拟池，未改运维prompt、账号或模型配置；本会话实际原生模型/推理强度/服务档未独立核实，不用历史对局配置冒充本会话运行证明。',
    '本批没有行为差量可回退，只追加追溯；源码和原失败日志均保留。最终需核HEAD仍等于base、git status与git diff --binary HEAD为空。工作树仍在运行，不自行删除或回收。',
    f'运维交付proposal：{scratch / "proposal.md"}\n\n报告：{scratch / "report.md"}；机器回报：{scratch / "result.json"}。',
])
(scratch / 'report.md').write_text(render(report))
print(json.dumps({'proposal': str(scratch / 'proposal.md'), 'report': str(scratch / 'report.md'),
                  'proposals': len(notes), 'ledger_ids': len({i for n in notes for i in n['ledger']})}, ensure_ascii=False))

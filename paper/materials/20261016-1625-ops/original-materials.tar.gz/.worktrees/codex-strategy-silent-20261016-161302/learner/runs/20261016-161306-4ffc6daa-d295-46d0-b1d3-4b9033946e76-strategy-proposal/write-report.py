import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
STAMP = subprocess.check_output(['date', '-Is'], text=True).strip()
BATCH = '20261016-161302-strategy-proposal'
queue = json.loads((HERE/'dispatched-proposals.json').read_text())
dispatch = json.loads((HERE/'dispatch.json').read_text())
checks = json.loads((HERE/'material-checks.json').read_text())
verification = json.loads((HERE/'evidence-verification.json').read_text())
assert checks['passed'] == checks['total'] == 19
assert verification['rows_verified'] == 6606

details = [
('9952ee8e8df9a0fe', 'NHA2KW0RB7VP F33 首/末试T1；s283391/283396/283397、283502/283506/283507',
 '同指纹两线实损1/7、挡14/8、净扣8/24；替线多16净扣且多损6血。',
 '缺同抽序、同预算和同后继的整战对照，以及能力累计兑现、路线与留药的受控后继；即时血价诊断已有live实现，不能据此改SL或终局权重。',
 '未记录另一条获胜整战，后轮目标/抽弃不同；不能将全败采样当安全等价，也不能反向规定永远保血。',
 '保留当前生产选择规则，继续逐候选列当轮模型血价、已执行资源和未知后继；有受控整战与时间后置独立局后再校准。'),
('47be799a87af03be', 'P74C04AEPL1F F23 第4试T3；s284817/284821、d278542—278546',
 '1HP/16挡对24攻击，四个弃牌选项均在；精确切击当时0费7伤且依赖手牌。实际弃后死亡、石眩晕而卵仍2血。',
 '暂停计划提示和弃后手牌快照已有live子实现；仍缺动态牌面、弃牌触发、目标及续步剩血的完整分支验证，未隔离新数值失配。',
 '首试卵已较早退场，第三试原线不含精确切击；没有保留精确后的实打整战，不能固定弃贪婪或宣称转胜。',
 '保留全部合法选项；后续固定回放须分别核弃后实际牌面、可支付续步、逐敌来袭和未知，并区分预测与执行。'),
('3a5274da3c42672a', 'P74C04AEPL1F F17 T1—T9、F22 T1—T6、F23 T1/T3；s284630/284631、284743/284744、284748/284749、284753/284754、284817/284821',
 '滑溜下火焰扣1且8→7；寄生0→21复活；F22 T2/T4实损20/24。石虫全挡后眩晕与卵仍致死能同时成立。',
 '缺主怪最后死亡的中间来源帧，以及药水、复活、逐敌失衡与下一战资源的联合消费者回放；已有局部模型不能认证整项，未隔离新的源码差额。',
 '赢战后9血不是该战杀序错误的因果证据；多次SL的目标和弃牌不同，火焰面值也不是本次实伤。',
 '以固定逐来源窗口核火焰、毒、一次翻倍、逐敌攻击及复活时点；缺失死亡来源保留未知，不新增保药或目标阈值。'),
('bc4b92d590f2c4ce', 'G33HU22H2543 F48 T1/末T8；P74C04AEPL1F F23末T3；s284407/284408、284817/284821',
 'G33末T8实际余像2层、12HP/12挡对31攻击；P74单弃后的原计划并未完整执行。',
 '投斧首牌身份、普通单弃及暂停计划提示已有live祖先窄修复；跨重规划执行归属、余像累计收益和动态弃牌的联合验收仍缺，不能整项duplicate。',
 '候选首牌余像线未实际完成；药水补层不能据此宣称恢复首牌机会或证明先能力能赢。',
 '沿用首牌身份修复；按真实派发/重规划切断未执行续步，只有实际建立层数和实际出牌触发计入兑现。'),
('f52fbbab4dccc3b4', 'P74C04AEPL1F F22→F23；G33HU22H2543 F48末T8；s284730/284761/284766、284407/284408',
 'P74 F22从53到9赢战，下一战入口仍9血；G33末轮死亡扣血有上限，31攻对12挡的完整需求为19，不能记成仅需12。',
 '缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的后继对照；赢战资源消耗成立，仍不能拟合新的HP价格或路线禁令。',
 '计划中的下一营火未到达；没有另路线、保药或少耗血的完整实打胜线，SL恢复不能充真实治疗。',
 '分别记已完成回复、战斗实际消耗、药水使用和读档恢复；仅把真实下战入口用于验收，未兑现未来回复保持预测。'),
('10f37c0edd3d24a6', 'P74C04AEPL1F F17/F22/F23；G33HU22H2543 F48末T7—T8；原提案各子窗口及本批关键状态',
 '本批重新核火焰滑溜、寄生复活、末轮余像/格挡与死亡端点；普通触媒、毒雾及临时减力细节沿已核原提案保留，未重跑原全量统计。',
 '缺历史刷新知识/移动表的原字节和临时减力、毒多结算、一次格挡、开场及回复的完整组合联合回放与独立校准；当前未发现可隔离新失配。',
 '临时负力不等下一轮恒定减伤，待触发士兵/臂甲不等每牌恒定翻倍；不能用当前刷新表冒作历史dirty输入。',
 '固定每个已观察来源/回合及消费状态，分开当前牌挡、被动挡、能力未来触发和开场净值；未观察组合不扩展。'),
('3f82387e2e179703', 'RC61MFQM63Y6 F33 首/末T1、第三试T4；s285315/285320/285321、285491/285496/285497；d279021/279197',
 '同指纹52HP，首/末实损4/8、挡16/12、净扣30/23；触媒确建1层。两个问题预算为3轮2样本与5轮24样本。',
 '缺同预算整战和累计能力收益的受控对照；同盘T1少7净扣、多损4血可核，但不足修改全败SL排序或新增固定HP惩罚。',
 '首试后续到T7而末试T4结束，后续行动不同；第三试普通生存者的不可达后继已另有窄修复。',
 '继续展示每条候选的预算、当轮成本和未知成长；只有可达且同条件后继形成对照才评价新SL选择规则。'),
('aee21084c991abd3', 'BTSRF7JL1W1Y F31 T1—T4；s286163/286170/286173/286174；d279852/279854',
 '甲虫T3/T4力量2/4，末轮14HP/5挡/1覆甲死亡；抽弃前后为不同指纹、分别3轮和5轮、各4样本。',
 '缺逐样本轨迹和最终执行线的配对校准；一次3/4样本线的死亡不能证明模型错误，未定位可隔离的醒虫成长数值失配。',
 '抽牌前“最优”后继被重规划替换；该战未建立步法，不能借其他战已施放的敏捷；不能强制先杀甲虫。',
 '按实际最终线核醒虫力量/虚弱期限/覆甲递减和逐轮结算，按原局分组并以新独立局验证，当前保留权重。'),
('df37594e9b12debf', 'RC61MFQM63Y6 F33首/末T1、第三试T4；F17 T11呼唤沿原提案出处',
 '同盘T1代价差及触媒建立可核；普通生存者取消唯一打击的代码已与绷带收益解耦。呼唤自损的历史来源保留，本批未重算其联合消费者。',
 '生存者取消唯一后继已由实际live祖先覆盖；跨选择整线归属、累计能力和呼唤自损的联合消费者仍未验收，不能把窄修复当整项duplicate。',
 '多选弃牌仍是未知，不能替Jev虚构选择；毒杀不删除已发生的持牌自损，也不证明其他结算组合。',
 '保留唯一弃牌确定消费与多选边界；后续验证真实续步、朝向、持牌来源和毒终结的先后，预测与实绩分开。'),
('42e81c83b2e1e56b', 'RC61MFQM63Y6 F33 T1；F18/F27及休息/资源总账沿原提案出处',
 'F33真实入口52HP由本批原帧核实；原提案营火/餐券/幕间/SL回复分别有出处，本批未重算历史总体统计。',
 '缺同条件路线、休息和后战对照及逐来源资源消费者验收；实入口52和既有回复账不能支持新的安全血线或终局HP价格。',
 '旧低血休息与事件案例敌人、牌组和间隔不同；五次读档恢复同一药水不等获得五瓶新药。',
 '按已完成回复和赢战消耗核实入口，不预支未来营火；以完整同条件后继和独立局校准后再讨论血价。'),
]

dispositions = []
proposal = [f'# 静默猎手十项已领取策略提案复核\n\n记录时间：{STAMP}（写前实际执行date）。批次：{BATCH}。基线：`{BASE}`。\n',
 '本批只处理learn.json绑定的十个原id；不新建重复提案，不领取队列其他项。五局均已核为静默A10。十项目前均waiting：证据能支持局部事实，但没有新的可隔离源码失配或足够的规则参数证据。当前建议保留策略行为。\n',
 '原提案Markdown均逐字节核SHA并保存在original-proposals/，原文不修改。完整原证据在evidence/；关键端点、19项材料断言、源码祖先核对分别见key-*-envelopes.json、material-checks.json、source-audit.json。\n']
table = ['| 原提案 | 证据窗口 | 账本 | 处置与缺数据 |', '|---|---|---|---|']
for suffix, window, supported, missing, counter, future in details:
    ident = 'silent-proposal-' + suffix
    original = queue[ident]['original']
    d = {'id': ident, 'state': 'waiting', 'reason': missing,
         'evidence_window': window, 'ledger': original['ledger'],
         'support': supported, 'counterexamples_and_limits': counter,
         'expected_behavior_and_verification': future,
         'source_task': original['source_task'], 'target_task': 'strategy-proposal',
         'original_proposal': original['proposal'], 'proposal_sha256': original['proposal_sha256']}
    dispositions.append(d)
    proposal.append(f"## {ident}\n\n来源任务：{original['source_task']}；实现任务：strategy-proposal；角色/进阶：silent/A10；领域：{', '.join(original['domains'])}。\n\n账本：{', '.join(original['ledger'])}。证据：{window}。\n\n已核事实：{supported}\n\n旧/拟议新行为：原提案[{original['summary']}](original-proposals/{ident}.md)；当前具体建议与验证：{future}\n\n反例/未知：{counter}\n\n处置：waiting。{missing}\n\n预期影响：只有上述事实与执行范围更可审计，尚无本批策略改动或胜率改善估计。回退：本批没有源码改动，无需回退；未来若实现仅逆实际源码差量，保留日志、经验、并行知识及所有失败记录。\n")
    table.append(f"| {ident} | {window} | {', '.join(original['ledger'])} | waiting：{missing} |")
proposal.append('## 共用方法与边界\n\n本批不拟合自由参数；五局是原提案的固定回归输入，不能冒称时间后置独立验证，同局SL不拆成独立样本。历史统计与未重算子窗口均明确沿原提案出处，不把再次读取算新support/repeat。新参数需要按完局时间切分独立局与受控后继；缺字段和未知结算保持未知。\n\n已有实际live祖先：投斧身份e784dd9f043bf87c29109573f48975f9903280d3、普通生存者bf423c173d3be348a4ad714e1d26516df619ff41、弃后快照4b0823f519f1b724d6cff2b1cd50b74146dc4a9d、暂停计划5b56a452bb9be14d620b368ec46974c1b57901ca、资源比较1698adc96ba434a46942321e0237b70657e625b2、推演范围45161a51c2c6b7e4a499b13cf749c4108193bbf5。只作为窄覆盖依据，均不能关闭相应宽项。旧侧支f34700874c9f48b614991f769532115a0f24f27b不是实际live祖先，不冒认上线。\n\n源码未改，不运行tsc/vitest、撤源码/恢复测试或live合入；不新增版本、不登记implemented/shipped，不触发规则上线双通知。保留其他角色当前行为。所有台账链接只经根目录ledger.py追加；不重置已shipped子经验，不改旧claim/首证/prior/evidence/status/version。\n')
(HERE/'proposal.md').write_text('\n'.join(proposal))
(HERE/'dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2)+'\n')

report = f'''# 静默猎手策略提案处置报告

记录时间：{STAMP}（写前实际执行date）。批次：{BATCH}。

十项均waiting：局部可核事实与现有窄实现保留，仍缺各项联合消费者/完整执行线/受控后继。未隔离新的确定源码失配，没有足够证据拟合新规则。无源码/知识修改、无新提交、无合入、无新版本，不登记implemented或shipped，不关闭学习父要求。

初始git status干净；核普通派发行task=strategy-proposal、character=silent、reason=proposal、工作树和五局集合相符，十个proposal_ids完整，无proposal_repair/research_request/implementation_request。普通专题入口绑定旧20261010-150327，不匹配本批；没有退回另选题。按任务执行git merge --no-edit main，结果Already up to date，完整base=`{BASE}`。

## 逐项处置

{chr(10).join(table)}

逐项支持、反例、未知、旧/拟议行为、验证、回退和原文链接见本目录proposal.md及dispositions.json；十份原Markdown SHA全匹配，未修改原提案或另造id。

## 原证据及核验

共用extract_evidence.py按本批五局提取八流，逐流source_size、计数和输出SHA在evidence/evidence-manifest.json。states3238、decisions3138、SL31、run-config5、run-plans26、brain163、runs5、fight-plans0，共6606原行；逐行seek回读原logs，offset/bytes/SHA/JSON与显式身份全部核过。身份只按run_id/state.run_id/run/fingerprint.run，不以正文提及认领。五局runs.jsonl均SILENT/A10，均负局。fight-plans为0仅表示该截点未选到；无效JSON为states2/decisions2/brain1，未纳入证据。

八流选中字节SHA与111303批次冻结输入完全一致；源截点增长没有增加本五局证据。本批独立从新封套取31状态和4决策，19项材料断言全部通过。这是证据材料检查，生产测试三项均null。未再次运行模型、模拟池或消费者。

NHA F33首/末T1同指纹，实损1/7、14/8挡、净扣8/24：替线多16净扣、多损6血。RC同指纹52HP，实损4/8、16/12挡、净扣30/23：替线少7净扣、多损4血，触媒确建1层；两个问题预算分别3轮2样本、5轮24样本。当前端点差额不等于整战同预算因果收益，没有据此改变SL、能力优先级或终局参数。

P74 F23末T3四个弃牌选项均保留，精确切击当前0费7伤且受手牌数量影响；1HP/16挡对24，终态石眩晕、卵2HP而玩家死亡。首试/第三试条件不同，未执行保留分支不能宣称必胜。F17火焰仅扣1且滑溜8→7；F22寄生0→21复活、T2/T4实损20/24、53→9赢，F23仍9血入口。缺失主怪死亡中间来源及完整资源对照继续未知。

G33末T8余像2层、12HP/12挡对31，死亡封顶实扣12不能当完整所需损血19。BTS F31甲虫力量2→4，末轮14HP/5挡/1覆甲死亡；抽弃前后指纹不同、预算3轮/5轮各4样本。单次3/4预测的死亡不能证明模型错或支持强制目标。历史总体路线/营火/回复统计本批未重算，不新增血线/留药阈值。

## 源码覆盖与消费者限制

只读live冻结为a9e687d9f0acccccddbfa92895d7966b58900658。19相关源码叶中17与live原字节一致；sl/explore.ts与card-model.ts仅既有Roy/Dai署名注释差，差分已保存。与111303审计共同14叶中13不变，selection.ts新增的生存者沙坑2入口限定单活沙虫，不覆盖P74石/卵题，不能当十项联合要求已满足。

source-audit.json逐叶保存SHA/blob及11提交祖先检查；投斧身份e784dd9、普通单弃bf423c1、弃后快照4b0823f、暂停计划5b56a45、资源比较1698adc和范围45161a等均实际base/live祖先。旧f347008侧支不是祖先。相关模块明确仍是current_turn_prediction/candidate_forecast/single_action_receipt，actual_turn或整条执行保持未知；快照函数明确不推演弃牌触发、动态费用、伤害或剩血。不能将已有日志框架当完整校准。

原七离线窗口的输入/输出/stderr共21原件SHA本批读回一致，见prior-consumer-readback.json；只复用其既有范围和限制，未重跑，不把旧exit0算本批测试、自然消费者采用或收益。历史dirty运行的刷新知识/移动表原字节未在本批复原；不能以当前刷新表充历史联合输入。

## 验证与交付边界

fixes=[]、merged=null；tests={{"tsc":null,"vitest":null,"cases":null}}。源码撤掉失败/恢复通过不适用。没有新提交、行为发布号或上线通知，其他角色行为保持等价。CLI只补32个既有账本的本批proposal/report追溯，不重复support/repeat、不改旧claim/first_run/prior/evidence/status/version，不把已shipped子项重置为proposed。CLI实际结果与最终工作树/扫描核验随后追加。

运维交付路径：{HERE/'proposal.md'}；报告：{HERE/'report.md'}。逐项waiting原因在dispositions.json/result.json，等待新本角色完局或补齐明确缺失字段后沿原队列重审；本报告不等学习入库或大脑采用。

仅用本批范围、只读原logs、不读凭据/.env/游戏二进制，无下级agent、网络、LLM调用、play或推送。若干旧路径读取失败和一次未改文件的转义误判已在read-probes.txt保留；并非生产源码/游戏结论失败。
'''
(HERE/'report.md').write_text(report)
result = {'task':'strategy-proposal', 'character':'silent', 'batch':BATCH,
          'base':BASE, 'runs':dispatch['runs'], 'fixes':[], 'skipped':[], 'merged':None,
          'tests':{'tsc':None,'vitest':None,'cases':None},
          'code_proposals':list(queue), 'implementation_domains':[],
          'proposal_results':[{'id':d['id'],'state':d['state'],'reason':d['reason']} for d in dispositions],
          'report':str(HERE/'report.md')}
(HERE/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'base':BASE, 'report':result['report'], 'dispositions':len(dispositions)}, ensure_ascii=False))

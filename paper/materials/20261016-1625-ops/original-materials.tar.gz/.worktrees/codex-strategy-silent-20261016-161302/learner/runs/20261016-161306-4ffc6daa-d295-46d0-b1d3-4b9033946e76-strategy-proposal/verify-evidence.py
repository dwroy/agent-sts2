import collections
import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal')
identity = runpy.run_path(str(ROOT / 'learner/extract_evidence.py'))['run_identity']
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
old = {x['stream']: x for x in json.loads((PRIOR / 'evidence-manifest-combined.json').read_text())}
verified = []
for item in manifest:
    path = HERE / 'evidence' / (item['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = collections.Counter()
    previous = -1
    source = Path('/home/dw/Projects/agent-sts2/logs') / (item['stream'] + '.jsonl')
    with source.open('rb') as raw_source, path.open('rb') as handle:
        for raw in handle:
            digest.update(raw)
            e = json.loads(raw)
            assert Path(e['source']) == source
            assert e['offset'] > previous
            assert e['offset'] + e['bytes'] <= item['source_size']
            previous = e['offset']
            raw_source.seek(e['offset'])
            original = raw_source.read(e['bytes'])
            assert original.endswith(b'\n')
            assert hashlib.sha256(original).hexdigest() == e['sha256']
            assert json.loads(original) == e['row']
            assert identity(e['row']) == e['run_id']
            counts[e['run_id']] += 1
    assert digest.hexdigest() == item['output_sha256']
    assert all(counts[k] == v for k, v in item['counts'].items())
    assert set(counts).issubset(item['counts'])
    same = digest.hexdigest() == old[item['stream']]['output_sha256']
    verified.append({**item, 'path': str(path), 'raw_rows_verified': sum(counts.values()),
                     'same_selected_bytes_as_prior': same})
out = {'streams': verified, 'rows_verified': sum(x['raw_rows_verified'] for x in verified),
       'same_selected_bytes_as_prior': all(x['same_selected_bytes_as_prior'] for x in verified),
       'prior_manifest': str(PRIOR / 'evidence-manifest-combined.json')}
(HERE / 'evidence-verification.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'rows_verified': out['rows_verified'],
                  'same_selected_bytes_as_prior': out['same_selected_bytes_as_prior'],
                  'counts': {x['stream']: x['raw_rows_verified'] for x in verified}}, ensure_ascii=False))

import json
from pathlib import Path
HERE = Path(__file__).resolve().parent

def save(name, value):
    (HERE/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

wanted_states = {283391,283396,283397,283502,283506,283507,285315,285320,285321,285491,285496,285497,284817,284821,284730,284761,284766,284743,284744,284753,284754,284748,284749,284630,284631,286163,286170,286173,286174,284407,284408}
wanted_decisions = {279021,279197,279852,279854}
envelopes = {}
decision_envelopes = {}
for stream, wanted, dest in [('states',wanted_states,envelopes),('decisions',wanted_decisions,decision_envelopes)]:
    for line in (HERE/'evidence'/(stream+'.evidence.jsonl')).open():
        e = json.loads(line)
        if e['line'] in wanted: dest[e['line']] = e
    assert set(dest) == wanted, (stream, wanted-set(dest))
save('key-state-envelopes.json', list(envelopes.values()))
save('key-decision-envelopes.json', list(decision_envelopes.values()))
frames = {k: e['row']['state'] for k,e in envelopes.items()}
decisions = {k: e['row'] for k,e in decision_envelopes.items()}
checks = []


def check(name, passed, lines):
    checks.append({'name': name, 'passed': bool(passed), 'source_lines': lines})


def player(line):
    return (frames[line].get('combat') or {}).get('player') or frames[line]['run']


def hp(line):
    return player(line)['current_hp']


def enemy(line, ident):
    return next(x for x in frames[line]['combat']['enemies'] if x['enemy_id'] == ident)


def power(entity, ident):
    return next((x['amount'] for x in entity['powers'] if x['power_id'] == ident), 0)


def net(a, b):
    return sum(x['current_hp'] for x in frames[a]['combat']['enemies']) - sum(x['current_hp'] for x in frames[b]['combat']['enemies'])


check('NHA首试T1实损1、14挡、净扣8', hp(283391) - hp(283397) == 1 and player(283396)['block'] == 14 and net(283391, 283397) == 8, [283391, 283396, 283397])
check('NHA末试T1实损7、8挡、净扣24', hp(283502) - hp(283507) == 7 and player(283506)['block'] == 8 and net(283502, 283507) == 24, [283502, 283506, 283507])
check('NHA两线起始指纹相同', envelopes[283391]['row']['fingerprint'] == envelopes[283502]['row']['fingerprint'], [283391, 283502])
check('RC首试T1实损4、16挡、净扣30', hp(285315) - hp(285321) == 4 and player(285320)['block'] == 16 and net(285315, 285321) == 30, [285315, 285320, 285321])
check('RC末试T1实损8、12挡、净扣23', hp(285491) - hp(285497) == 8 and player(285496)['block'] == 12 and net(285491, 285497) == 23, [285491, 285496, 285497])
check('RC末试触媒确建1层', power(player(285497), 'ACCELERANT_POWER') == 1, [285497])
cards = frames[284817]['selection']['cards']
check('P74单弃四个合法选项均在', {c['card_id'] for c in cards} == {'STRANGLE', 'NOXIOUS_FUMES', 'PRECISE_CUT', 'GREED'}, [284817])
precise = next(c for c in cards if c['card_id'] == 'PRECISE_CUT')
check('精确切击0费7伤且受手牌数量影响', precise['energy_cost'] == 0 and '造成7点伤害' in precise['resolved_rules_text'] and '每有一张牌' in precise['resolved_rules_text'], [284817])
attack = sum(i['total_damage'] or 0 for e in frames[284817]['combat']['enemies'] for i in e['intents'])
check('P74末试1血16挡对24攻击', hp(284817) == 1 and player(284817)['block'] == 16 and attack == 24, [284817])
check('P74实际死亡时石眩晕、卵仍2血', hp(284821) == 0 and enemy(284821, 'BOWLBUG_ROCK')['move_id'] == 'STUNNED' and enemy(284821, 'BOWLBUG_EGG')['current_hp'] == 2, [284821])
check('P74赢战53到9、下一战9血入口', [hp(i) for i in [284730, 284761, 284766]] == [53, 9, 9], [284730, 284761, 284766])
check('P74胧光怪T2/T4实损20/24', hp(284743) - hp(284744) == 20 and hp(284753) - hp(284754) == 24, [284743, 284744, 284753, 284754])
check('寄生从0血复活至21血', enemy(284748, 'PARAFRIGHT')['current_hp'] == 0 and enemy(284749, 'PARAFRIGHT')['current_hp'] == 21, [284748, 284749])
check('滑溜下火焰扣1血、层数8到7', enemy(284630, 'VANTOM')['current_hp'] - enemy(284631, 'VANTOM')['current_hp'] == 1 and [power(enemy(i, 'VANTOM'), 'SLIPPERY_POWER') for i in [284630, 284631]] == [8, 7], [284630, 284631])
check('BTS甲虫力量2到4', [power(enemy(i, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER') for i in [286163, 286170]] == [2, 4], [286163, 286170])
check('BTS14血/5挡/1覆甲实际死亡', hp(286173) == 14 and player(286173)['block'] == 5 and power(player(286173), 'PLATING_POWER') == 1 and hp(286174) == 0, [286173, 286174])
check('G33已建余像2层，12血12挡面对31攻', power(player(284407), 'AFTERIMAGE_POWER') == 2 and hp(284407) == 12 and player(284407)['block'] == 12 and enemy(284407, 'TORCH_HEAD_AMALGAM')['intents'][0]['total_damage'] == 31 and hp(284408) == 0, [284407, 284408])
check('RC首末题同指纹、预算不同', decisions[279021]['fingerprint'] == decisions[279197]['fingerprint'] and [(decisions[i]['rollout']['horizon'], decisions[i]['rollout']['samples']) for i in [279021, 279197]] == [(3, 2), (5, 24)], [279021, 279197])
check('BTS抽弃前后不是同题面、预算3轮/5轮各4样本', decisions[279852]['fingerprint'] != decisions[279854]['fingerprint'] and [(decisions[i]['rollout']['horizon'], decisions[i]['rollout']['samples']) for i in [279852, 279854]] == [(3, 4), (5, 4)], [279852, 279854])
save('material-checks.json', {'checks': checks, 'passed': sum(c['passed'] for c in checks), 'total': len(checks), 'production_tests': False})
print(json.dumps({'passed': sum(c['passed'] for c in checks), 'total': len(checks), 'failed': [c for c in checks if not c['passed']]}, ensure_ascii=False))
assert all(c['passed'] for c in checks)

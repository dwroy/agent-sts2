import collections
import fcntl
import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
before = json.loads((HERE/'ledger-prefix-before-cli.json').read_text())
updates = [json.loads(line) for line in (HERE/'ledger-updates.jsonl').read_text().splitlines()]
want = {row['id']: row for row in updates}
ids = set(want)
with Path(before['source']).open('rb') as handle:
    fcntl.flock(handle, fcntl.LOCK_SH)
    raw = handle.read()
    fcntl.flock(handle, fcntl.LOCK_UN)
assert hashlib.sha256(raw[:before['source_size']]).hexdigest() == before['prefix_sha256']
rows, own = [], []
offset = other_suffix = 0
for n, line in enumerate(raw.splitlines(keepends=True), 1):
    row = json.loads(line)
    rows.append((n, row))
    if offset >= before['source_size']:
        expected = want.get(row.get('id'))
        if expected and row.get('where', {}).get('proposal') == expected['where']['proposal'] and row.get('note') == expected['note']:
            assert row['op'] == 'update'
            assert all(row.get(k) == v for k, v in expected.items())
            assert set(row) == set(expected) | {'ts', 'op'}
            own.append({'id': row['id'], 'line': n, 'offset': offset, 'bytes': len(line),
                        'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
        else:
            other_suffix += 1
    offset += len(line)
assert len(own) == 32 and collections.Counter(x['id'] for x in own) == collections.Counter(ids)
ledger = runpy.run_path('/home/dw/Projects/agent-sts2/learner/ledger.py')
after = ledger['fold']([(n, row) for n, row in rows if row.get('id') in ids])
excluded = {'where', 'history', 'notes'}
for ident in ids:
    a, b = before['folded'][ident], after[ident]
    assert {k: v for k, v in a.items() if k not in excluded} == {k: v for k, v in b.items() if k not in excluded}, ident
    assert b['notes'][:len(a['notes'])] == a['notes']
    assert b['history'][:len(a['history'])] == a['history']
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values
    assert all(x in b['where']['proposal'] for x in want[ident]['where']['proposal'])
    assert all(x in b['where']['lessons'] for x in want[ident]['where']['lessons'])
# The CLI emits one space-separated line of IDs.
stdout = (HERE/'ledger-cli.stdout.txt').read_text().split()
assert len(stdout) == 32 and set(stdout) == ids
assert not (HERE/'ledger-cli.stderr.txt').read_text()
result = {'cli_exit_code': 0, 'verified_updates': len(own), 'prefix_preserved': True,
          'protected_fields_unchanged': True, 'old_notes_history_where_prefixes_preserved': True,
          'other_suffix_rows': other_suffix, 'appends': own}
(HERE/'ledger-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'appends'}, ensure_ascii=False))

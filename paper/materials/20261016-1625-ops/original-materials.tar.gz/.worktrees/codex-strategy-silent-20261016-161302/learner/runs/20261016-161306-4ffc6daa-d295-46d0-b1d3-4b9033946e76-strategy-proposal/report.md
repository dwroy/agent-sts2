# 静默猎手策略提案处置报告

记录时间：2026-10-16T16:22:36+08:00（写前实际执行date）。批次：20261016-161302-strategy-proposal。

十项均waiting：局部可核事实与现有窄实现保留，仍缺各项联合消费者/完整执行线/受控后继。未隔离新的确定源码失配，没有足够证据拟合新规则。无源码/知识修改、无新提交、无合入、无新版本，不登记implemented或shipped，不关闭学习父要求。

初始git status干净；核普通派发行task=strategy-proposal、character=silent、reason=proposal、工作树和五局集合相符，十个proposal_ids完整，无proposal_repair/research_request/implementation_request。普通专题入口绑定旧20261010-150327，不匹配本批；没有退回另选题。按任务执行git merge --no-edit main，结果Already up to date，完整base=`9950156be1476d8a31ef3439dabe6a0cb4f6e8cb`。

## 逐项处置

| 原提案 | 证据窗口 | 账本 | 处置与缺数据 |
|---|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | NHA2KW0RB7VP F33 首/末试T1；s283391/283396/283397、283502/283506/283507 | silent-0019, silent-0020, silent-0065, silent-0264, silent-0079 | waiting：缺同抽序、同预算和同后继的整战对照，以及能力累计兑现、路线与留药的受控后继；即时血价诊断已有live实现，不能据此改SL或终局权重。 |
| silent-proposal-47be799a87af03be | P74C04AEPL1F F23 第4试T3；s284817/284821、d278542—278546 | silent-0205 | waiting：暂停计划提示和弃后手牌快照已有live子实现；仍缺动态牌面、弃牌触发、目标及续步剩血的完整分支验证，未隔离新数值失配。 |
| silent-proposal-3a5274da3c42672a | P74C04AEPL1F F17 T1—T9、F22 T1—T6、F23 T1/T3；s284630/284631、284743/284744、284748/284749、284753/284754、284817/284821 | silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006 | waiting：缺主怪最后死亡的中间来源帧，以及药水、复活、逐敌失衡与下一战资源的联合消费者回放；已有局部模型不能认证整项，未隔离新的源码差额。 |
| silent-proposal-bc4b92d590f2c4ce | G33HU22H2543 F48 T1/末T8；P74C04AEPL1F F23末T3；s284407/284408、284817/284821 | silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266 | waiting：投斧首牌身份、普通单弃及暂停计划提示已有live祖先窄修复；跨重规划执行归属、余像累计收益和动态弃牌的联合验收仍缺，不能整项duplicate。 |
| silent-proposal-f52fbbab4dccc3b4 | P74C04AEPL1F F22→F23；G33HU22H2543 F48末T8；s284730/284761/284766、284407/284408 | silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064 | waiting：缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的后继对照；赢战资源消耗成立，仍不能拟合新的HP价格或路线禁令。 |
| silent-proposal-10f37c0edd3d24a6 | P74C04AEPL1F F17/F22/F23；G33HU22H2543 F48末T7—T8；原提案各子窗口及本批关键状态 | silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069 | waiting：缺历史刷新知识/移动表的原字节和临时减力、毒多结算、一次格挡、开场及回复的完整组合联合回放与独立校准；当前未发现可隔离新失配。 |
| silent-proposal-3f82387e2e179703 | RC61MFQM63Y6 F33 首/末T1、第三试T4；s285315/285320/285321、285491/285496/285497；d279021/279197 | silent-0079, silent-0027, silent-0065, silent-0080, silent-0088 | waiting：缺同预算整战和累计能力收益的受控对照；同盘T1少7净扣、多损4血可核，但不足修改全败SL排序或新增固定HP惩罚。 |
| silent-proposal-aee21084c991abd3 | BTSRF7JL1W1Y F31 T1—T4；s286163/286170/286173/286174；d279852/279854 | silent-0128 | waiting：缺逐样本轨迹和最终执行线的配对校准；一次3/4样本线的死亡不能证明模型错误，未定位可隔离的醒虫成长数值失配。 |
| silent-proposal-df37594e9b12debf | RC61MFQM63Y6 F33首/末T1、第三试T4；F17 T11呼唤沿原提案出处 | silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268 | waiting：生存者取消唯一后继已由实际live祖先覆盖；跨选择整线归属、累计能力和呼唤自损的联合消费者仍未验收，不能把窄修复当整项duplicate。 |
| silent-proposal-42e81c83b2e1e56b | RC61MFQM63Y6 F33 T1；F18/F27及休息/资源总账沿原提案出处 | silent-0019, silent-0020 | waiting：缺同条件路线、休息和后战对照及逐来源资源消费者验收；实入口52和既有回复账不能支持新的安全血线或终局HP价格。 |

逐项支持、反例、未知、旧/拟议行为、验证、回退和原文链接见本目录proposal.md及dispositions.json；十份原Markdown SHA全匹配，未修改原提案或另造id。

## 原证据及核验

共用extract_evidence.py按本批五局提取八流，逐流source_size、计数和输出SHA在evidence/evidence-manifest.json。states3238、decisions3138、SL31、run-config5、run-plans26、brain163、runs5、fight-plans0，共6606原行；逐行seek回读原logs，offset/bytes/SHA/JSON与显式身份全部核过。身份只按run_id/state.run_id/run/fingerprint.run，不以正文提及认领。五局runs.jsonl均SILENT/A10，均负局。fight-plans为0仅表示该截点未选到；无效JSON为states2/decisions2/brain1，未纳入证据。

八流选中字节SHA与111303批次冻结输入完全一致；源截点增长没有增加本五局证据。本批独立从新封套取31状态和4决策，19项材料断言全部通过。这是证据材料检查，生产测试三项均null。未再次运行模型、模拟池或消费者。

NHA F33首/末T1同指纹，实损1/7、14/8挡、净扣8/24：替线多16净扣、多损6血。RC同指纹52HP，实损4/8、16/12挡、净扣30/23：替线少7净扣、多损4血，触媒确建1层；两个问题预算分别3轮2样本、5轮24样本。当前端点差额不等于整战同预算因果收益，没有据此改变SL、能力优先级或终局参数。

P74 F23末T3四个弃牌选项均保留，精确切击当前0费7伤且受手牌数量影响；1HP/16挡对24，终态石眩晕、卵2HP而玩家死亡。首试/第三试条件不同，未执行保留分支不能宣称必胜。F17火焰仅扣1且滑溜8→7；F22寄生0→21复活、T2/T4实损20/24、53→9赢，F23仍9血入口。缺失主怪死亡中间来源及完整资源对照继续未知。

G33末T8余像2层、12HP/12挡对31，死亡封顶实扣12不能当完整所需损血19。BTS F31甲虫力量2→4，末轮14HP/5挡/1覆甲死亡；抽弃前后指纹不同、预算3轮/5轮各4样本。单次3/4预测的死亡不能证明模型错或支持强制目标。历史总体路线/营火/回复统计本批未重算，不新增血线/留药阈值。

## 源码覆盖与消费者限制

只读live冻结为a9e687d9f0acccccddbfa92895d7966b58900658。19相关源码叶中17与live原字节一致；sl/explore.ts与card-model.ts仅既有Roy/Dai署名注释差，差分已保存。与111303审计共同14叶中13不变，selection.ts新增的生存者沙坑2入口限定单活沙虫，不覆盖P74石/卵题，不能当十项联合要求已满足。

source-audit.json逐叶保存SHA/blob及11提交祖先检查；投斧身份e784dd9、普通单弃bf423c1、弃后快照4b0823f、暂停计划5b56a45、资源比较1698adc和范围45161a等均实际base/live祖先。旧f347008侧支不是祖先。相关模块明确仍是current_turn_prediction/candidate_forecast/single_action_receipt，actual_turn或整条执行保持未知；快照函数明确不推演弃牌触发、动态费用、伤害或剩血。不能将已有日志框架当完整校准。

原七离线窗口的输入/输出/stderr共21原件SHA本批读回一致，见prior-consumer-readback.json；只复用其既有范围和限制，未重跑，不把旧exit0算本批测试、自然消费者采用或收益。历史dirty运行的刷新知识/移动表原字节未在本批复原；不能以当前刷新表充历史联合输入。

## 验证与交付边界

fixes=[]、merged=null；tests={"tsc":null,"vitest":null,"cases":null}。源码撤掉失败/恢复通过不适用。没有新提交、行为发布号或上线通知，其他角色行为保持等价。CLI只补32个既有账本的本批proposal/report追溯，不重复support/repeat、不改旧claim/first_run/prior/evidence/status/version，不把已shipped子项重置为proposed。CLI实际结果与最终工作树/扫描核验随后追加。

运维交付路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-161302/learner/runs/20261016-161306-4ffc6daa-d295-46d0-b1d3-4b9033946e76-strategy-proposal/proposal.md；报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-161302/learner/runs/20261016-161306-4ffc6daa-d295-46d0-b1d3-4b9033946e76-strategy-proposal/report.md。逐项waiting原因在dispositions.json/result.json，等待新本角色完局或补齐明确缺失字段后沿原队列重审；本报告不等学习入库或大脑采用。

仅用本批范围、只读原logs、不读凭据/.env/游戏二进制，无下级agent、网络、LLM调用、play或推送。若干旧路径读取失败和一次未改文件的转义误判已在read-probes.txt保留；并非生产源码/游戏结论失败。

最终账本验收：2026-10-16T16:24:40+08:00（先执行date）。根ledger.py update实际退出0，32条追加逐物理offset/bytes/SHA/JSON/输入字段读回；原物理前缀、claim/首证/prior/evidence/status/version/shipped及旧notes/history/where前缀保持。首个读回脚本误把CLI空格分隔ID当逐行输出而失败，原错误保留，修正后通过；没有再次追加。

最终交付核验：2026-10-16T16:25:16+08:00（先执行date）。gitleaks实际退出0、0命中，原报告gitleaks.json保留；HEAD仍为9950156be1476d8a31ef3439dabe6a0cb4f6e8cb，git status干净，tracked与index差异均0，当前派发绑定再次核对一致。未运行生产测试或合入，无版本或shipped。

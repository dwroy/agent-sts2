# 静默猎手策略提案批次核验报告

记录时间：2026-10-15 23:54:42 CST。

**结果：10项均waiting；未修改源码或知识、未提交、未合入live、未新增版本。** 每项具体证据、账本、反例与验证范围见proposal.md。

- batch：20261015-234301-s2-strategy-proposal；task：strategy-proposal；character：silent。
- base：`7b1f183919293758065344e894b39e1035c9b7c0`。开工git status干净，合main无变动；最终HEAD与干净状态另存completion-check.json。
- 无手动专题/implementation_request绑定；只处理派发的10个原id，未领取其他队列、未写learn.json或根请求。

## 证据范围

| 流 | source_size（字节截点） | 选中行数 |
|---|---:|---:|
| states | 13196019354 | 4062 |
| decisions | 1699077523 | 3941 |
| sl-attempts | 41519660 | 38 |
| run-config | 1796239 | 6 |
| run-plans | 8221343 | 33 |
| brain | 609867297 | 188 |
| runs | 339600 | 6 |
| fight-plans | 2233957 | 0 |

六局runs均为SILENT/A10/负局。states 4062、decisions 3941；八流合8274条逐行原字节及身份核验通过。states/decisions各2条、brain 1条无法解析的源行是抽取器全截点统计，不归到本角色或当成缺帧补值。fight-plans选中0行只说明冻结截点未选到。
run-config六局均标dirty且列出知识文件，八流没有提供可还原当时实际消费数据的全量字节快照；当前数据库不能冒充历史dirty输入。188条本批brain日志均codex/gpt-6.1-sol/high/accepted=true；这是历史六局的元数据。
相关原复盘已定位于notes/lessons.md的六局小节；原Markdown10/10 SHA匹配并原字节保存，不重复写历史复盘。ledger-before.json保留30个既有账本的状态、首证、先验、历史与证据，未新增游戏结论。

## 逐项处置

| 原提案ID | 状态 | 具体限制 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | waiting | 缺历史dirty运行实际消费的A10移动表字节及毒、挡、污染跨轮的完整候选联合回放；本批未定位新的确定性当轮公式差异。 |
| silent-proposal-ae9e692d680e3819 | waiting | 缺逐实体累计被夺量、非抢夺属性来源与死亡返还的完整冻结模型输入；另一杀序后继未执行。 |
| silent-proposal-52f1e1bd2e7db0ed | waiting | 缺原dirty运行实际消费的A10移动表快照及覆甲完整减层条件的独立输入；首样本读取路径已存在，未定位新的当轮缺陷。 |
| silent-proposal-6dd8bbff876be528 | waiting | 缺稳定召唤代际、新同类替换及累计量归属的冻结输入；一个连续存活窗口不能证明新实体不继承旧计数。 |
| silent-proposal-578e415a259e6835 | waiting | 缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准；预测或观察端点已有不能闭合整项。 |
| silent-proposal-c0767768bf6a7ab1 | waiting | 缺未执行续步、完整替代线的资源/胜负对照及跨重问执行归属；多9血少7伤不足以校准SL惩罚或禁止探索。 |
| silent-proposal-a46bdb7fe711d79a | waiting | 缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；已有当前快照及零毒说明只覆盖局部。 |
| silent-proposal-1044224808015e5c | waiting | 缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列证明低当轮损失优先的新排序更好。 |
| silent-proposal-7cbc6005db712ba9 | waiting | 缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不足以把整项登记duplicate。 |
| silent-proposal-c59f592f1427a67e | waiting | 六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。 |

## 已有实现及实际live范围

只读live提交：`cfa1c0be88147b4eac65c13d8c550b23ed4eef17`。source-audit.json保存16叶字节SHA及最后修改commit，并逐项核是该live祖先；这些源码叶在live无未提交变动。13叶与本批一致，3叶差异仅为历史Roy/Dai注释字样，完整diff存base-to-live-source.patch，原差异保留。
- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`：Silent原答/SL前后候选预测与待派发记录。
- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：护栏预测差值；actual_outcome仍null。
- `aad2700abed6dff1d66e87fb36aaa6fedb39adf3`：实验体当前阶段、牌组/手牌/已建能力与零毒说明。
- `1dab14da481fe7951d9020dba52ad0ebebb1029b`：长程并列中的即时损血参考，仍保留其他指标及选择权。
- `a32050fbce4c2863f640468c2dbf378fc9157074`、`e75438488df159b2e8e9d3458cf219b39aadd933`：离线相邻观察及整轮窗口；完整候选归属与因果仍null。
monster-db的moveDamageAt/monsterHpAt存在当前进阶优先、首样本不设5局门槛的读取路径；roomHpCost继续ROOM_COST_MIN_N=5。HIGH_VOLTAGE_POWER现有逐敌增长、污染/临时减力/格挡/毒等局部模型均不能替代完整联合回放。上述commit仅证明子项来源，未将任何宽提案整体标duplicate/implemented。

## 固定证据与消费者核验

verify_evidence.py核8274条原始选中行；verify_cases.py的37个材料断言通过。它们不是tsc、vitest或策略收益测试。四组同盘端点净损/敌净扣为：

| 局与位置 | 原尝试 | SL替换尝试 | 实际差值 |
|---|---|---|---|
| 8JRE F33 T2 | 3 / 10 | 15 / 17 | 多损12、多扣7；原预测死亡0/24对5/24 |
| YF F48 T1 | 0 / 45 | 9 / 38 | 多损9、少扣7；两线预测24/24死亡 |
| XP F33 T3 | 9 / 24 | 14 / 27 | 多损5、多扣3；B2零胜并列 |
| XP F33 T1 | 2 / 25 | 10 / 34 | 多损8、多扣9；后轮另有变化 |

这些手工端点包括全部实际重问与续步，不认证某个原始候选完成，也不是受控整战反事实。F33/YF第二次SL实际获胜的反例已核并保留；不否定全部SL价值。

| 局 | 审计层 | 候选段 | 轮窗 | 可观察轮端点 | 未知轮窗 | 完整候选认证 |
|---|---|---:|---:|---:|---:|---:|
| DUZUBAJ3A8GP | [27] | 8 | 8 | 0 | 8 | 0 |
| 5PM6JAQG6FNQ | [38, 39] | 18 | 15 | 7 | 8 | 0 |
| CA5KE8GFJ9X2 | [13] | 4 | 5 | 0 | 5 | 0 |
| 8JRE1C4H4Z2W | [17, 33] | 66 | 57 | 44 | 13 | 0 |
| YF0LXT1QSTGG | [33, 48] | 52 | 55 | 40 | 15 | 0 |
| XP2SL33HT0D9 | [33] | 58 | 45 | 28 | 17 | 0 |

六份既有learner/audit-selection.ts消费者均退出0，输入/输出SHA均保存；总206候选段、185轮窗，119有观察端点、66未知，完整候选认证0。普通走廊sl_attempt为空、T1没有前轮结束边界或读档/终结缺口时，现有保守消费者会保留unknown；这不反驳经原帧人工核实的局部数值，也不能强制改为完整认证。
代码未改：未执行撤源码失败/恢复通过、tsc、vitest或完整套件；tests严格为null。不制造合入、eval版本、代码收益或经验已入库/大脑已采用的声明。

## 账本、运行配置与过程限制

仅通过根learner/ledger.py update为30个既有silent账本追加本批proposal/report追溯和具体waiting限制，by=learner:strategy-proposal；不重复追加旧证据，不改claim/first_run/prior/status/version/effect，不降级已有shipped。CLI输入、回执与前后保护核验另存ledger-*文件。专用原队列不手改，最终proposal_results交原调度器登记。
本模型宿主launch声明gpt-6.1-sol、xhigh、service_tier=default；题文要求high的差异保存在launcher-metadata.json。本次未改启动器/线程/权限，未独立读回原生请求模型，不能将启动参数当原生运行验收。历史六局high与本次派发配置分列。
过程错误保留：两次只读源码定位猜了不存在的审计文件名，命令退出2；随后按rg --files找到真实silent-selection-audit及learner/lib/selection-*。大段队列历史/复盘输出曾被工具截断；原提案随后原字节保存、关键机制均按固定原帧复核。没有把这些工具定位/展示限制记成产品bug。
限制：未重算原101局历史；缺当时dirty知识字节、稳定召唤代际与逐来源累计量；缺未选方案完整后继、独立随机池/时间后移验证；净HP差不等于毛入伤、恢复不等于新取得；零胜预测不证明现实必败，相关SL不提供独立胜率样本。
没有新反证推翻旧经验或新增游戏规则；未重复复盘、经验发布、通知或发号。工作树无源码提交，保留全部初始抽取与过程材料；无需live锁、刷新、合入或版本登记。

运维入口：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-234301-s2/learner/runs/20261015-234305-67f8b5ec-d934-43c3-bdca-1e1eb5141619-strategy-proposal/proposal.md；报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-234301-s2/learner/runs/20261015-234305-67f8b5ec-d934-43c3-bdca-1e1eb5141619-strategy-proposal/report.md。原任务后续等待可核实的新数据，不关闭宽父要求。


## 最终机械核验

2026-10-15 23:56:25 CST：30行CLI追溯追加实收，输入ID与回执逐项相同；非追溯字段、旧证据/历史/链接全部保留。10个派发ID均有waiting及具体限制，CLI既有提案链接校验无错；HEAD仍为7b1f183919293758065344e894b39e1035c9b7c0，git status为空，16个审计源码叶未变。详见completion-check.json、ledger-link-receipt.json与result.json。

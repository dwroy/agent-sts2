import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())['entry']
runs = dispatch['runs']
floors = dict(zip(runs, [{27}, {38, 39}, {13}, {17, 33}, {33, 48}, {33}]))
data = {stream: {run: [] for run in runs} for stream in ['states', 'decisions', 'runs']}
verified = []
compact_states = []
compact_decisions = []
metadata = {'configs': [], 'brain': collections.Counter(), 'sl': []}


def powers(items):
    return {item['power_id']: item['amount'] for item in items or []}


for entry in manifest:
    stream = entry['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = collections.Counter()
    with path.open('rb') as selected, open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as raw_source:
        for encoded in selected:
            digest.update(encoded)
            item = json.loads(encoded)
            raw_source.seek(item['offset'])
            raw = raw_source.read(item['bytes'])
            assert item['offset'] + item['bytes'] <= entry['source_size']
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            row = json.loads(raw)
            assert row == item['row']
            run = extract.run_identity(row)
            assert run == item['run_id'] and run in runs
            counts[run] += 1
            row['_line'] = item['line']
            if stream == 'runs':
                assert row['character'].lower() == 'silent' and row['ascension'] == 10
                data[stream][run].append(row)
            elif stream == 'states':
                state = row['state']
                assert state['run_id'] == run
                assert state['run']['character_id'].lower() == 'silent' and state['run']['ascension'] == 10
                if state['run']['floor'] not in floors[run]:
                    continue
                data[stream][run].append(row)
                combat = state.get('combat') or {}
                player = combat.get('player') or {}
                compact_states.append({'run': run, 'line': item['line'], 'offset': item['offset'],
                    'sha256': item['sha256'], 'observed_ts': row.get('observed_ts'),
                    'floor': state['run']['floor'], 'turn': state.get('turn'), 'screen': state['screen'],
                    'hp': player.get('current_hp'), 'block': player.get('block'),
                    'played': player.get('cards_played_this_turn'), 'powers': powers(player.get('powers')),
                    'hand': [x['card_id'] for x in combat.get('hand') or []],
                    'enemies': [{'id': x['enemy_id'], 'index': x['index'], 'hp': x['current_hp'],
                        'max_hp': x['max_hp'], 'block': x.get('block'), 'powers': powers(x.get('powers')),
                        'move': x.get('move_id'), 'intents': x.get('intents'), 'alive': x.get('is_alive')}
                        for x in combat.get('enemies') or []]})
            elif stream == 'decisions' and row.get('floor') in floors[run]:
                data[stream][run].append(row)
                candidates = {}
                for key, val in (row.get('questions') or {}).get('plan', {}).get('criteria', {}).items():
                    val = json.loads(val) if isinstance(val, str) else val
                    candidates[key] = {k: val[k] for k in ['plays', 'hp_lost', 'damage_dealt', 'block_gained',
                        'rollout', 'rollout_best', 'cards_drawn', 'scaling_gained'] if k in val}
                compact_decisions.append({k: row.get(k) for k in ['run_id', '_line', 'floor', 'turn',
                    'label', 'decision_id', 'observed_ts', 'ts', 'sl_attempt', 'sl_reloads', 'chosen',
                    'result', 'answers', 'journal', 'sl_explore', 'hp_guard', 'selection_audit', 'rationale']} |
                    {'candidates': candidates})
            elif stream == 'run-config':
                metadata['configs'].append({'run_id': run, 'code': row['code'],
                    'brain': row['brain'], 'knowledge': row['knowledge']})
            elif stream == 'brain':
                metadata['brain'][str((row.get('engine'), row.get('model'), row.get('effort'), row.get('accepted')))] += 1
            elif stream == 'sl-attempts':
                metadata['sl'].append({k: row.get(k) for k in ['run_id', 'floor', 'attempt', 'result', 'turns', 'end_hp']})
    assert all(counts[run] == entry['counts'][run] for run in runs)
    assert digest.hexdigest() == entry['output_sha256']
    verified.append({'stream': stream, 'rows_verified': sum(counts.values()), 'source_size': entry['source_size'],
        'counts': dict(counts), 'sha256': digest.hexdigest()})

inputs = OUT / 'audit-inputs'
inputs.mkdir(exist_ok=True)
input_summary = []
for run in runs:
    assert len(data['runs'][run]) == 1
    decisions = data['decisions'][run]
    omitted = [x['_line'] for x in decisions if not x.get('decision_id')]
    value = {'run': data['runs'][run][0], 'states': data['states'][run],
        'decisions': [x for x in decisions if x.get('decision_id')]}
    encoded = json.dumps(value, ensure_ascii=False).encode()
    (inputs / (run + '.json')).write_bytes(encoded)
    input_summary.append({'run_id': run, 'floors': sorted(floors[run]), 'decisions': len(value['decisions']),
        'states': len(value['states']), 'omitted_no_decision_id': omitted,
        'input_sha256': hashlib.sha256(encoded).hexdigest()})

metadata['brain'] = dict(metadata['brain'])
for name, value in [('verified-evidence', verified), ('audit-inputs', input_summary),
                    ('states-summary', compact_states), ('decisions-summary', compact_decisions),
                    ('run-metadata', metadata)]:
    (OUT / (name + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['rows_verified'] for x in verified), 'streams': verified,
    'audit_inputs': input_summary, 'brain_requests': metadata['brain']}, ensure_ascii=False))

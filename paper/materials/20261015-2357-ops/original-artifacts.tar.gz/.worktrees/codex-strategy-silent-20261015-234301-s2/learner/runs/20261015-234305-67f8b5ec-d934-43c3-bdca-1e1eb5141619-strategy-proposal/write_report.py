import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
snapshot = json.loads((OUT / 'proposals-snapshot.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
entries = snapshot['items']
ids = dispatch['entry']['proposal_ids']
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(now)
details = [
    ('棱柱技能污染及收益', 'DUZUBAJ3A8GP F27 T4—T6',
     'states 274830—274839：T4污染0→3→3→6→0，勒紧能力不增加；T5火花6，污染0→6→12→18→0。两轮玩家净损3/9、敌本体净扣8/13。',
     '技能同时施毒、加挡；不能由污染血价判定技能一律亏，也没有另一线完整获胜实证。',
     '缺历史dirty运行实际消费的A10移动表字节及毒、挡、污染跨轮的完整候选联合回放；本批未定位新的确定性当轮公式差异。',
     '已有技能累积污染与当前进阶读取路径。后续只在冻结移动表、手牌与实际动作齐备时验证跨轮火花、污染清除、毒与挡，不设置少打技能优先级。'),
    ('抢夺与死亡返还归源', '5PM6JAQG6FNQ F39 T4—T6',
     'states 274351—274358：首试负力/敏各−4，两步法使敏捷−4→−2→0，失落退场后力量恢复0；274362遗忘又令敏捷−2。',
     '首试建立两步法、末试单步法是不同路径；当前总负敏捷不能代表被夺总量，不能由失落退场外推固定击杀序能赢。',
     '缺逐实体累计被夺量、非抢夺属性来源与死亡返还的完整冻结模型输入；另一杀序后继未执行。',
     '按逐来源事件验证抢夺/返还，当前属性照现场读取；不能把净负属性直接当返还量，也不能仅由类型及index断言稳定实体身份。'),
    ('蚌加压与当前进阶事实', 'CA5KE8GFJ9X2 F13 T1—T5',
     'states 273238/273252/273263：力量0/4/8，喷水11/15/19；273268虚弱后14、玩家10挡2血，273269死亡净损2，完整未挡4。覆甲轮初9/9/8/7/6。',
     '覆甲序列不是完整减层条件；零血净损不能当完整入伤，走廊败局不能替代固定房间成本。',
     '缺原dirty运行实际消费的A10移动表快照及覆甲完整减层条件的独立输入；首样本读取路径已存在，未定位新的当轮缺陷。',
     '保留当前进阶HP/攻击首样本路径与房间代价5样本门槛；验证加压、虚弱、覆甲的完整前后帧，不追加未观察触发条件。'),
    ('电击成长与召唤身份', '5PM6JAQG6FNQ F38 T3—T4',
     'states 274308→274313：唯一已见ZAPBOT上限23，力量2→4，攻击17→19，高电压均2；index由4重排为3，T3仍存活并贡献攻击。',
     '同类型不能自动当同实体；本窗口仅有连续存活的电击，不能验证新召唤者的重置，也没有先杀爪牙的整战后继。',
     '缺稳定召唤代际、新同类替换及累计量归属的冻结输入；一个连续存活窗口不能证明新实体不继承旧计数。',
     '已有HIGH_VOLTAGE_POWER增长路径。后续需固定召唤/退场/同类替换边界验证逐实体初始化，不硬编码新的目标顺序。'),
    ('沙虫护栏、SL与资源分账', '8JRE1C4H4Z2W F17 T6、F33 T2/T5/T11',
     'decisions 270216/270282指纹相同；手工状态端点276208→276212、276274→276278，玩家净损3/15、敌净扣10/17。原日志SL numbers区分0/24与5/24死亡，不能称同死率。270264保留HP护栏后候选，六次尝试仍是一局。',
     '抽牌/弃牌/护栏可切断候选；较低当轮损失不证明整战获胜，未建能力与未结算毒不计实际收益。',
     '缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准；预测或观察端点已有不能闭合整项。',
     '保留原答、护栏后、SL后预测及实际派发分账；现有日志只认证可观察端点，不强认完整候选，不调整护栏或SL参数。'),
    ('实验体SL截断的同轮血价', 'YF0LXT1QSTGG F48 第二/第三次T1、F33 第二次',
     'decisions 271309/271348指纹相同，原答均plan5。states 277327→277337与277366→277373：净损0/9、敌净扣45/38。271354原答还有挡续步，SL覆盖改结束。',
     'F33第二次SL result=won，反对一概禁止探索；F48恢复挡续步的末次仍败，第四次T5的候选另被重问切断。',
     '缺未执行续步、完整替代线的资源/胜负对照及跨重问执行归属；多9血少7伤不足以校准SL惩罚或禁止探索。',
     '保存同轮血价、输出与未执行续步，有限死亡比例只作预测；保留探索，不拟合新的血价系数。'),
    ('实验体阶段与真实能力兑现', 'YF0LXT1QSTGG F48 末次T3—T5',
     'states 277512→277513：111上限、4血4毒变212上限/212血且零毒。277519触媒2但当前零毒；277525/277527敏捷5→6，已有23挡不变。277527为18血23挡对44，277528实际死亡、敌仍160。',
     '持有毒牌不等于已建立；前五次有建立能力仍失败的记录。阶段端点不能单独归因某牌或推出强制先手。',
     '缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；已有当前快照及零毒说明只覆盖局部。',
     '现有silent-phase-current区分手牌、牌组与已建能力；继续按真实阶段读毒和格挡，完整候选、后轮增段与因果收益仍需独立验证。'),
    ('双蟹B2零胜并列与SL血价', 'XP2SL33HT0D9 F33 首/第二次T3、首/末次T1',
     'decisions 271992/272040同指纹，端点净损9/14、敌净扣24/27；271982/272195同指纹，净损2/10、敌净扣25/34。SL记录两组B2 original=replacement=0，保留原始零差。',
     '六试相关且全败，后轮抽序和动作亦改变；不能由T1/T3差值认定整战胜因，B2有限零差不是安全或等价证明。',
     '缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列证明低当轮损失优先的新排序更好。',
     '当前已有长程并列中的即时损血参考；不改B2、SL探索或血价权重，完整反事实齐备后再验证。'),
    ('双蟹朝向、临时减力与贡献分账', 'XP2SL33HT0D9 F33 末次T2—T5',
     'states 278236/278240轮初挡14→新建后20；278236/278237/278242爪力量0→−9→0；278249/278252/278253火箭攻击57→38→28；278255/278260为4敏脆弱下6挡，278261死亡，两敌毒结算3+7。',
     '固定帧验证局部变化，不能将朝向/虚弱/能力的联合净差当单来源收益，不能把普通版及该现场外推所有额外条件。',
     '缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不足以把整项登记duplicate。',
     '已有当轮公式及局部参考保持；后续固定顺序核每项贡献、原有挡与新建挡，禁止把整轮净差归给一条未完成候选。'),
    ('历史综合资源与机制提案', 'YF0LXT1QSTGG F33/F48、XP2SL33HT0D9 F33；原提案另含101局历史',
     '本次直接核六锚点，复核上述四组同盘差值、阶段变化、临时减力与轮初挡；原提案的101局/1499房/91实死及各机制分母只保留为原作者历史报告，本次未重算。',
     '同局SL不扩独立样本数；赢战也耗资源。没有未走路线、延后喝药或另一构筑的受控整场结果，六锚点不等于全历史覆盖。',
     '六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。',
     '原历史分母和来源继续保留；本次不扩展到未派发全历史、不拟统一资源阈值，等待可归源完整后继。'),
]

results = []
parts = ['# 本批已领取策略提案的证据核验与处置', '',
    f'记录时间：{now}。角色silent，已核实进阶A10；批次{dispatch["batch"]}。',
    f'基线：`{source["base"]}`；`git merge --no-edit main` 返回Already up to date。',
    '本批是普通proposal消费任务：reason=proposal，只有下列10个proposal_ids，没有research_request、implementation_request或proposal_repair；不承接另一批专题。',
    '来源任务按各原提案记录，目标均为strategy-proposal。原件在original-proposals/，10份SHA256与专用队列一致。没有新建重复提案或改写原提案。',
    '本次没有足够证据修改策略源码。以下均保留waiting；局部已有实现不作宽提案implemented/duplicate。Roy-2026-10-07-learning是授权，不是游戏事实。', '']
for ident, detail in zip(ids, details):
    title, location, evidence, counterexample, reason, expected = detail
    item = entries[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    parts += [f'## {ident}：{title}', '',
        '账本：' + '、'.join(item['ledger']) + '。',
        f'来源任务：{item["source_task"]}；实现任务：strategy-proposal；原文：{item["proposal"]}；SHA256：`{item["proposal_sha256"]}`。',
        f'证据局号/层/回合：{location}。', f'本次核验：{evidence}', f'反例与限制：{counterexample}',
        f'旧规则与预期行为/验证范围：{expected}', f'处置：waiting。{reason}', '']
parts += ['## 公共验证、拟合及回退边界', '',
    '八流共8274条选中记录逐条seek原日志，核offset/bytes/SHA256、JSON内容及显式身份；source_size和分流计数存evidence/evidence-manifest.json。未以正文提及判归属。',
    '只对提案相关层生成六份audit-inputs/，保留原_line；其余层仍在原始抽取中，本次没有逐动作语义审完。fight-plans在记录截点对六局选中0行，仅作该截点结果，不推断日志缺失。',
    '37项固定材料断言通过，含4组完整fingerprint配对和端点差值；六份既有离线消费者审计退出0。它们不是生产测试、撤源码红绿或新策略效果。',
    '不拟合新权重、强制优先级、血价、药水持有价值、必死/SL或终局阈值。六局各是独立局；同存档尝试相关。若将来拟新规则，这些局只作发现/回归，须按run_id分组并将新完局后移验证，未选线不可补成胜局。',
    '回退：本次无生产代码、知识数据或版本可回退；仅CLI追溯追加保留历史。未来实现按其真实源码提交回退，实际live上线后再记版本与通知，不预填shipped。',
    '无关角色与未观察机制无行为变化。没有启动游戏、联网、LLM调用、安装依赖、推送或修改运维prompt。', '']
(OUT / 'proposal.md').write_text('\n'.join(parts) + '\n')
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

audits = json.loads((OUT / 'offline-audit-summary.json').read_text())
man = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
report = ['# 静默猎手策略提案批次核验报告', '', f'记录时间：{now}。', '',
    '**结果：10项均waiting；未修改源码或知识、未提交、未合入live、未新增版本。** 每项具体证据、账本、反例与验证范围见proposal.md。', '',
    f'- batch：{dispatch["batch"]}；task：strategy-proposal；character：silent。',
    f'- base：`{source["base"]}`。开工git status干净，合main无变动；最终HEAD与干净状态另存completion-check.json。',
    '- 无手动专题/implementation_request绑定；只处理派发的10个原id，未领取其他队列、未写learn.json或根请求。', '',
    '## 证据范围', '',
    '| 流 | source_size（字节截点） | 选中行数 |', '|---|---:|---:|']
for x in man:
    report.append(f'| {x["stream"]} | {x["source_size"]} | {sum(x["counts"].values())} |')
report += ['',
    '六局runs均为SILENT/A10/负局。states 4062、decisions 3941；八流合8274条逐行原字节及身份核验通过。states/decisions各2条、brain 1条无法解析的源行是抽取器全截点统计，不归到本角色或当成缺帧补值。fight-plans选中0行只说明冻结截点未选到。',
    'run-config六局均标dirty且列出知识文件，八流没有提供可还原当时实际消费数据的全量字节快照；当前数据库不能冒充历史dirty输入。188条本批brain日志均codex/gpt-6.1-sol/high/accepted=true；这是历史六局的元数据。',
    '相关原复盘已定位于notes/lessons.md的六局小节；原Markdown10/10 SHA匹配并原字节保存，不重复写历史复盘。ledger-before.json保留30个既有账本的状态、首证、先验、历史与证据，未新增游戏结论。', '',
    '## 逐项处置', '', '| 原提案ID | 状态 | 具体限制 |', '|---|---|---|']
for x in results:
    report.append(f'| {x["id"]} | waiting | {x["reason"]} |')
report += ['', '## 已有实现及实际live范围', '',
    f'只读live提交：`{source["live"]}`。source-audit.json保存16叶字节SHA及最后修改commit，并逐项核是该live祖先；这些源码叶在live无未提交变动。13叶与本批一致，3叶差异仅为历史Roy/Dai注释字样，完整diff存base-to-live-source.patch，原差异保留。',
    '- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`：Silent原答/SL前后候选预测与待派发记录。',
    '- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：护栏预测差值；actual_outcome仍null。',
    '- `aad2700abed6dff1d66e87fb36aaa6fedb39adf3`：实验体当前阶段、牌组/手牌/已建能力与零毒说明。',
    '- `1dab14da481fe7951d9020dba52ad0ebebb1029b`：长程并列中的即时损血参考，仍保留其他指标及选择权。',
    '- `a32050fbce4c2863f640468c2dbf378fc9157074`、`e75438488df159b2e8e9d3458cf219b39aadd933`：离线相邻观察及整轮窗口；完整候选归属与因果仍null。',
    'monster-db的moveDamageAt/monsterHpAt存在当前进阶优先、首样本不设5局门槛的读取路径；roomHpCost继续ROOM_COST_MIN_N=5。HIGH_VOLTAGE_POWER现有逐敌增长、污染/临时减力/格挡/毒等局部模型均不能替代完整联合回放。上述commit仅证明子项来源，未将任何宽提案整体标duplicate/implemented。', '',
    '## 固定证据与消费者核验', '',
    'verify_evidence.py核8274条原始选中行；verify_cases.py的37个材料断言通过。它们不是tsc、vitest或策略收益测试。四组同盘端点净损/敌净扣为：', '',
    '| 局与位置 | 原尝试 | SL替换尝试 | 实际差值 |', '|---|---|---|---|',
    '| 8JRE F33 T2 | 3 / 10 | 15 / 17 | 多损12、多扣7；原预测死亡0/24对5/24 |',
    '| YF F48 T1 | 0 / 45 | 9 / 38 | 多损9、少扣7；两线预测24/24死亡 |',
    '| XP F33 T3 | 9 / 24 | 14 / 27 | 多损5、多扣3；B2零胜并列 |',
    '| XP F33 T1 | 2 / 25 | 10 / 34 | 多损8、多扣9；后轮另有变化 |', '',
    '这些手工端点包括全部实际重问与续步，不认证某个原始候选完成，也不是受控整战反事实。F33/YF第二次SL实际获胜的反例已核并保留；不否定全部SL价值。', '',
    '| 局 | 审计层 | 候选段 | 轮窗 | 可观察轮端点 | 未知轮窗 | 完整候选认证 |', '|---|---|---:|---:|---:|---:|---:|']
inputs = {x['run_id']: x for x in json.loads((OUT / 'audit-inputs.json').read_text())}
for a in audits:
    status = a['turn_status']
    report.append(f'| {a["run_id"]} | {inputs[a["run_id"]]["floors"]} | {a["segments"]} | {a["turns"]} | {status.get("observed_turn_endpoints", 0)} | {status.get("unknown", 0)} | {a["certified_candidate_results"]} |')
report += ['',
    '六份既有learner/audit-selection.ts消费者均退出0，输入/输出SHA均保存；总206候选段、185轮窗，119有观察端点、66未知，完整候选认证0。普通走廊sl_attempt为空、T1没有前轮结束边界或读档/终结缺口时，现有保守消费者会保留unknown；这不反驳经原帧人工核实的局部数值，也不能强制改为完整认证。',
    '代码未改：未执行撤源码失败/恢复通过、tsc、vitest或完整套件；tests严格为null。不制造合入、eval版本、代码收益或经验已入库/大脑已采用的声明。', '',
    '## 账本、运行配置与过程限制', '',
    '仅通过根learner/ledger.py update为30个既有silent账本追加本批proposal/report追溯和具体waiting限制，by=learner:strategy-proposal；不重复追加旧证据，不改claim/first_run/prior/status/version/effect，不降级已有shipped。CLI输入、回执与前后保护核验另存ledger-*文件。专用原队列不手改，最终proposal_results交原调度器登记。',
    '本模型宿主launch声明gpt-6.1-sol、xhigh、service_tier=default；题文要求high的差异保存在launcher-metadata.json。本次未改启动器/线程/权限，未独立读回原生请求模型，不能将启动参数当原生运行验收。历史六局high与本次派发配置分列。',
    '过程错误保留：两次只读源码定位猜了不存在的审计文件名，命令退出2；随后按rg --files找到真实silent-selection-audit及learner/lib/selection-*。大段队列历史/复盘输出曾被工具截断；原提案随后原字节保存、关键机制均按固定原帧复核。没有把这些工具定位/展示限制记成产品bug。',
    '限制：未重算原101局历史；缺当时dirty知识字节、稳定召唤代际与逐来源累计量；缺未选方案完整后继、独立随机池/时间后移验证；净HP差不等于毛入伤、恢复不等于新取得；零胜预测不证明现实必败，相关SL不提供独立胜率样本。',
    '没有新反证推翻旧经验或新增游戏规则；未重复复盘、经验发布、通知或发号。工作树无源码提交，保留全部初始抽取与过程材料；无需live锁、刷新、合入或版本登记。', '',
    f'运维入口：{OUT / "proposal.md"}；报告：{OUT / "report.md"}。原任务后续等待可核实的新数据，不关闭宽父要求。', '']
(OUT / 'report.md').write_text('\n'.join(report) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'],
    'base': source['base'], 'runs': dispatch['entry']['runs'], 'fixes': [],
    'skipped': ['10项原提案均因具体证据缺口保留waiting，详见proposal_results与proposal.md'],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': ids, 'implementation_domains': [], 'proposal_results': results,
    'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'proposal': str(OUT / 'proposal.md'), 'proposal_results': len(results)}, ensure_ascii=False))

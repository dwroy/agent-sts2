# 本批已领取策略提案的证据核验与处置

记录时间：2026-10-15 23:54:42 CST。角色silent，已核实进阶A10；批次20261015-234301-s2-strategy-proposal。
基线：`7b1f183919293758065344e894b39e1035c9b7c0`；`git merge --no-edit main` 返回Already up to date。
本批是普通proposal消费任务：reason=proposal，只有下列10个proposal_ids，没有research_request、implementation_request或proposal_repair；不承接另一批专题。
来源任务按各原提案记录，目标均为strategy-proposal。原件在original-proposals/，10份SHA256与专用队列一致。没有新建重复提案或改写原提案。
本次没有足够证据修改策略源码。以下均保留waiting；局部已有实现不作宽提案implemented/duplicate。Roy-2026-10-07-learning是授权，不是游戏事实。

## silent-proposal-c20b5139dd0dff71：棱柱技能污染及收益

账本：silent-0168。
来源任务：experience-update；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；SHA256：`bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c`。
证据局号/层/回合：DUZUBAJ3A8GP F27 T4—T6。
本次核验：states 274830—274839：T4污染0→3→3→6→0，勒紧能力不增加；T5火花6，污染0→6→12→18→0。两轮玩家净损3/9、敌本体净扣8/13。
反例与限制：技能同时施毒、加挡；不能由污染血价判定技能一律亏，也没有另一线完整获胜实证。
旧规则与预期行为/验证范围：已有技能累积污染与当前进阶读取路径。后续只在冻结移动表、手牌与实际动作齐备时验证跨轮火花、污染清除、毒与挡，不设置少打技能优先级。
处置：waiting。缺历史dirty运行实际消费的A10移动表字节及毒、挡、污染跨轮的完整候选联合回放；本批未定位新的确定性当轮公式差异。

## silent-proposal-ae9e692d680e3819：抢夺与死亡返还归源

账本：silent-0183、silent-0005。
来源任务：experience-update；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；SHA256：`b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5`。
证据局号/层/回合：5PM6JAQG6FNQ F39 T4—T6。
本次核验：states 274351—274358：首试负力/敏各−4，两步法使敏捷−4→−2→0，失落退场后力量恢复0；274362遗忘又令敏捷−2。
反例与限制：首试建立两步法、末试单步法是不同路径；当前总负敏捷不能代表被夺总量，不能由失落退场外推固定击杀序能赢。
旧规则与预期行为/验证范围：按逐来源事件验证抢夺/返还，当前属性照现场读取；不能把净负属性直接当返还量，也不能仅由类型及index断言稳定实体身份。
处置：waiting。缺逐实体累计被夺量、非抢夺属性来源与死亡返还的完整冻结模型输入；另一杀序后继未执行。

## silent-proposal-52f1e1bd2e7db0ed：蚌加压与当前进阶事实

账本：silent-0231。
来源任务：experience-update；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；SHA256：`651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376`。
证据局号/层/回合：CA5KE8GFJ9X2 F13 T1—T5。
本次核验：states 273238/273252/273263：力量0/4/8，喷水11/15/19；273268虚弱后14、玩家10挡2血，273269死亡净损2，完整未挡4。覆甲轮初9/9/8/7/6。
反例与限制：覆甲序列不是完整减层条件；零血净损不能当完整入伤，走廊败局不能替代固定房间成本。
旧规则与预期行为/验证范围：保留当前进阶HP/攻击首样本路径与房间代价5样本门槛；验证加压、虚弱、覆甲的完整前后帧，不追加未观察触发条件。
处置：waiting。缺原dirty运行实际消费的A10移动表快照及覆甲完整减层条件的独立输入；首样本读取路径已存在，未定位新的当轮缺陷。

## silent-proposal-6dd8bbff876be528：电击成长与召唤身份

账本：silent-0233、silent-0209。
来源任务：experience-update；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；SHA256：`48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5`。
证据局号/层/回合：5PM6JAQG6FNQ F38 T3—T4。
本次核验：states 274308→274313：唯一已见ZAPBOT上限23，力量2→4，攻击17→19，高电压均2；index由4重排为3，T3仍存活并贡献攻击。
反例与限制：同类型不能自动当同实体；本窗口仅有连续存活的电击，不能验证新召唤者的重置，也没有先杀爪牙的整战后继。
旧规则与预期行为/验证范围：已有HIGH_VOLTAGE_POWER增长路径。后续需固定召唤/退场/同类替换边界验证逐实体初始化，不硬编码新的目标顺序。
处置：waiting。缺稳定召唤代际、新同类替换及累计量归属的冻结输入；一个连续存活窗口不能证明新实体不继承旧计数。

## silent-proposal-578e415a259e6835：沙虫护栏、SL与资源分账

账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。
来源任务：experience-update；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；SHA256：`e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a`。
证据局号/层/回合：8JRE1C4H4Z2W F17 T6、F33 T2/T5/T11。
本次核验：decisions 270216/270282指纹相同；手工状态端点276208→276212、276274→276278，玩家净损3/15、敌净扣10/17。原日志SL numbers区分0/24与5/24死亡，不能称同死率。270264保留HP护栏后候选，六次尝试仍是一局。
反例与限制：抽牌/弃牌/护栏可切断候选；较低当轮损失不证明整战获胜，未建能力与未结算毒不计实际收益。
旧规则与预期行为/验证范围：保留原答、护栏后、SL后预测及实际派发分账；现有日志只认证可观察端点，不强认完整候选，不调整护栏或SL参数。
处置：waiting。缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准；预测或观察端点已有不能闭合整项。

## silent-proposal-c0767768bf6a7ab1：实验体SL截断的同轮血价

账本：silent-0079。
来源任务：postmortem；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；SHA256：`28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb`。
证据局号/层/回合：YF0LXT1QSTGG F48 第二/第三次T1、F33 第二次。
本次核验：decisions 271309/271348指纹相同，原答均plan5。states 277327→277337与277366→277373：净损0/9、敌净扣45/38。271354原答还有挡续步，SL覆盖改结束。
反例与限制：F33第二次SL result=won，反对一概禁止探索；F48恢复挡续步的末次仍败，第四次T5的候选另被重问切断。
旧规则与预期行为/验证范围：保存同轮血价、输出与未执行续步，有限死亡比例只作预测；保留探索，不拟合新的血价系数。
处置：waiting。缺未执行续步、完整替代线的资源/胜负对照及跨重问执行归属；多9血少7伤不足以校准SL惩罚或禁止探索。

## silent-proposal-a46bdb7fe711d79a：实验体阶段与真实能力兑现

账本：silent-0021、silent-0027、silent-0028、silent-0085。
来源任务：postmortem；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；SHA256：`eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6`。
证据局号/层/回合：YF0LXT1QSTGG F48 末次T3—T5。
本次核验：states 277512→277513：111上限、4血4毒变212上限/212血且零毒。277519触媒2但当前零毒；277525/277527敏捷5→6，已有23挡不变。277527为18血23挡对44，277528实际死亡、敌仍160。
反例与限制：持有毒牌不等于已建立；前五次有建立能力仍失败的记录。阶段端点不能单独归因某牌或推出强制先手。
旧规则与预期行为/验证范围：现有silent-phase-current区分手牌、牌组与已建能力；继续按真实阶段读毒和格挡，完整候选、后轮增段与因果收益仍需独立验证。
处置：waiting。缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；已有当前快照及零毒说明只覆盖局部。

## silent-proposal-1044224808015e5c：双蟹B2零胜并列与SL血价

账本：silent-0079。
来源任务：postmortem；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；SHA256：`4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5`。
证据局号/层/回合：XP2SL33HT0D9 F33 首/第二次T3、首/末次T1。
本次核验：decisions 271992/272040同指纹，端点净损9/14、敌净扣24/27；271982/272195同指纹，净损2/10、敌净扣25/34。SL记录两组B2 original=replacement=0，保留原始零差。
反例与限制：六试相关且全败，后轮抽序和动作亦改变；不能由T1/T3差值认定整战胜因，B2有限零差不是安全或等价证明。
旧规则与预期行为/验证范围：当前已有长程并列中的即时损血参考；不改B2、SL探索或血价权重，完整反事实齐备后再验证。
处置：waiting。缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列证明低当轮损失优先的新排序更好。

## silent-proposal-7cbc6005db712ba9：双蟹朝向、临时减力与贡献分账

账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。
来源任务：postmortem；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；SHA256：`f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291`。
证据局号/层/回合：XP2SL33HT0D9 F33 末次T2—T5。
本次核验：states 278236/278240轮初挡14→新建后20；278236/278237/278242爪力量0→−9→0；278249/278252/278253火箭攻击57→38→28；278255/278260为4敏脆弱下6挡，278261死亡，两敌毒结算3+7。
反例与限制：固定帧验证局部变化，不能将朝向/虚弱/能力的联合净差当单来源收益，不能把普通版及该现场外推所有额外条件。
旧规则与预期行为/验证范围：已有当轮公式及局部参考保持；后续固定顺序核每项贡献、原有挡与新建挡，禁止把整轮净差归给一条未完成候选。
处置：waiting。缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不足以把整项登记duplicate。

## silent-proposal-c59f592f1427a67e：历史综合资源与机制提案

账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。
来源任务：experience-update；实现任务：strategy-proposal；原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；SHA256：`81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2`。
证据局号/层/回合：YF0LXT1QSTGG F33/F48、XP2SL33HT0D9 F33；原提案另含101局历史。
本次核验：本次直接核六锚点，复核上述四组同盘差值、阶段变化、临时减力与轮初挡；原提案的101局/1499房/91实死及各机制分母只保留为原作者历史报告，本次未重算。
反例与限制：同局SL不扩独立样本数；赢战也耗资源。没有未走路线、延后喝药或另一构筑的受控整场结果，六锚点不等于全历史覆盖。
旧规则与预期行为/验证范围：原历史分母和来源继续保留；本次不扩展到未派发全历史、不拟统一资源阈值，等待可归源完整后继。
处置：waiting。六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。

## 公共验证、拟合及回退边界

八流共8274条选中记录逐条seek原日志，核offset/bytes/SHA256、JSON内容及显式身份；source_size和分流计数存evidence/evidence-manifest.json。未以正文提及判归属。
只对提案相关层生成六份audit-inputs/，保留原_line；其余层仍在原始抽取中，本次没有逐动作语义审完。fight-plans在记录截点对六局选中0行，仅作该截点结果，不推断日志缺失。
37项固定材料断言通过，含4组完整fingerprint配对和端点差值；六份既有离线消费者审计退出0。它们不是生产测试、撤源码红绿或新策略效果。
不拟合新权重、强制优先级、血价、药水持有价值、必死/SL或终局阈值。六局各是独立局；同存档尝试相关。若将来拟新规则，这些局只作发现/回归，须按run_id分组并将新完局后移验证，未选线不可补成胜局。
回退：本次无生产代码、知识数据或版本可回退；仅CLI追溯追加保留历史。未来实现按其真实源码提交回退，实际live上线后再记版本与通知，不预填shipped。
无关角色与未观察机制无行为变化。没有启动游戏、联网、LLM调用、安装依赖、推送或修改运维prompt。


import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROJECT = Path('/home/dw/Projects/agent-sts2')
batch = '20261015-234301-s2-strategy-proposal'
spec = importlib.util.spec_from_file_location('ledger_read', PROJECT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
entries = json.loads((OUT / 'proposals-snapshot.json').read_text())['items']
results = {x['id']: x for x in json.loads((OUT / 'proposal-results.json').read_text())}
ids = sorted({x for value in entries.values() for x in value['ledger']})
before = {ident: value for ident, value in ledger.fold().items() if ident in ids}
assert len(before) == 30 and all(x['character'] == 'silent' for x in before.values())
(OUT / 'ledger-before-write.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
rows = []
for ident in ids:
    linked = [proposal for proposal, value in entries.items() if ident in value['ledger']]
    note = batch + '：只做原提案追溯，未新增机制结论/证据/规则/源码或状态。' + '；'.join(
        proposal + '=waiting：' + results[proposal]['reason'] for proposal in linked)
    rows.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]}, 'note': note})
encoded = ''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in rows)
(OUT / 'ledger-update-input.jsonl').write_text(encoded)
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(now)
call = subprocess.run(['python3', str(PROJECT / 'learner/ledger.py'), 'update', '--character', 'silent'],
    cwd=PROJECT, input=encoded, text=True, capture_output=True)
(OUT / 'ledger-update.stdout').write_text(call.stdout)
(OUT / 'ledger-update.stderr').write_text(call.stderr)
assert call.returncode == 0, call.stderr
assert call.stdout.split() == ids
after = {ident: value for ident, value in ledger.fold().items() if ident in ids}
protected = {}
for ident in ids:
    left, right = before[ident], after[ident]
    for key, val in left.items():
        if key not in {'where', 'notes', 'history'}:
            assert right[key] == val, (ident, key)
    assert right['history'][:len(left['history'])] == left['history']
    assert right['notes'][:len(left['notes'])] == left['notes']
    for key, values in left['where'].items():
        assert all(value in right['where'].get(key, []) for value in values)
    assert all(p in right['where']['proposal'] for p in [str(OUT / 'proposal.md'), str(OUT / 'report.md')])
    protected[ident] = {'status': right['status'], 'claim_first_prior_evidence_version_unchanged': True,
        'old_history_notes_where_preserved': True}
owned = []
with open(PROJECT / 'paper/materials/learning/ledger.jsonl', 'rb') as handle:
    offset = 0
    for number, raw in enumerate(handle, 1):
        try:
            row = json.loads(raw)
        except ValueError:
            offset += len(raw)
            continue
        if row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith(batch + '：'):
            assert set(row) == {'op', 'id', 'ts', 'by', 'where', 'note'}
            owned.append({'line': number, 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                'id': row['id'], 'fields': sorted(row)})
        offset += len(raw)
assert len(owned) == 30 and sorted(x['id'] for x in owned) == ids
receipt = {'exit_code': call.returncode, 'written_at': now, 'rows': len(owned),
    'append_only_trace_links': True, 'protected': protected, 'physical_rows': owned}
(OUT / 'ledger-after-write.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-link-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': call.returncode, 'rows': len(owned), 'protected_ids': len(protected)}, ensure_ascii=False))

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {x['line']: x for x in json.loads((OUT / 'states-summary.json').read_text())}
receipts = []


def check(name, actual, expected, lines):
    assert actual == expected, (name, actual, expected)
    receipts.append({'check': name, 'actual': actual, 'expected': expected,
        'state_lines': lines})


def power(line, key):
    return states[line]['powers'].get(key, 0)


def enemy(line, key):
    found = [x for x in states[line]['enemies'] if x['id'] == key]
    assert len(found) == 1
    return found[0]


def attack(line, key):
    return sum(x.get('total_damage') or 0 for x in enemy(line, key)['intents'] or [])


check('棱柱T4技能与能力污染变化', [power(i, 'TAINTED_POWER') for i in range(274830, 274835)],
    [0, 3, 3, 6, 0], list(range(274830, 274835)))
check('棱柱T5技能污染变化', [power(i, 'TAINTED_POWER') for i in range(274835, 274840)],
    [0, 6, 12, 18, 0], list(range(274835, 274840)))
check('棱柱火花增长', [enemy(i, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'] for i in [274830, 274834]],
    [3, 6], [274830, 274834])
check('棱柱两轮玩家净损', [states[a]['hp'] - states[b]['hp'] for a, b in [(274830, 274834), (274834, 274839)]],
    [3, 9], [274830, 274834, 274839])
check('棱柱两轮敌血净扣', [enemy(a, 'INFESTED_PRISM')['hp'] - enemy(b, 'INFESTED_PRISM')['hp']
    for a, b in [(274830, 274834), (274834, 274839)]], [8, 13], [274830, 274834, 274839])
check('失落首试T4负力敏', [power(274351, p) for p in ['STRENGTH_POWER', 'DEXTERITY_POWER']],
    [-4, -4], [274351])
check('两步法逐次恢复敏捷', [power(i, 'DEXTERITY_POWER') for i in [274351, 274352, 274354]],
    [-4, -2, 0], [274351, 274352, 274354])
check('失落退场后的玩家力量', power(274358, 'STRENGTH_POWER'), 0, [274357, 274358])
check('遗忘再次夺敏', power(274362, 'DEXTERITY_POWER'), -2, [274362])
check('电击已见跨轮成长与索引重排',
    [[enemy(i, 'ZAPBOT')['index'], enemy(i, 'ZAPBOT')['max_hp'],
      enemy(i, 'ZAPBOT')['powers']['STRENGTH_POWER'], attack(i, 'ZAPBOT')] for i in [274308, 274313]],
    [[4, 23, 2, 17], [3, 23, 4, 19]], [274308, 274313])
check('蚌喷水与加压', [[enemy(i, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0), attack(i, 'SEWER_CLAM')]
    for i in [273238, 273252, 273263]], [[0, 11], [4, 15], [8, 19]], [273238, 273252, 273263])
check('蚌覆甲仅观察层数', [enemy(i, 'SEWER_CLAM')['powers']['PLATING_POWER']
    for i in [273238, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273238, 273247, 273252, 273258, 273263])
check('蚌末轮现场需求与死亡净损分开', [attack(273268, 'SEWER_CLAM'), states[273268]['block'],
    states[273268]['hp'], states[273269]['hp']], [14, 10, 2, 0], [273268, 273269])
check('实验体阶段切换只保留实际新帧',
    [[enemy(i, 'TEST_SUBJECT')['max_hp'], enemy(i, 'TEST_SUBJECT')['hp'],
      enemy(i, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)] for i in [277512, 277513]],
    [[111, 4, 4], [212, 212, 0]], [277512, 277513])
check('实验体零毒且触媒已建', [enemy(277519, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0),
    power(277519, 'ACCELERANT_POWER')], [0, 2], [277519])
check('后来敏捷不倒补格挡', [[power(i, 'DEXTERITY_POWER'), states[i]['block']] for i in [277525, 277527]],
    [[5, 23], [6, 23]], [277525, 277527])
check('实验体末轮零血不是完整入伤', [states[277527]['hp'], states[277527]['block'],
    attack(277527, 'TEST_SUBJECT'), states[277528]['hp']], [18, 23, 44, 0], [277527, 277528])
check('船夹板与新建挡分别可见', [states[i]['block'] for i in [278236, 278240]], [14, 20], [278236, 278240])
check('普通镣铐及下一轮恢复', [enemy(i, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0)
    for i in [278236, 278237, 278242]], [0, -9, 0], [278236, 278237, 278242])
check('朝向及虚弱顺次变化', [attack(i, 'ROCKET') for i in [278249, 278252, 278253]], [57, 38, 28], [278249, 278252, 278253])
check('四敏脆弱下格挡及死亡', [[states[i]['hp'], states[i]['block']] for i in [278255, 278260, 278261]],
    [[33, 6], [11, 6], [0, 0]], [278255, 278260, 278261])
check('末轮毒仅结算十点', [enemy(278260, key)['hp'] - enemy(278261, key)['hp'] for key in ['CRUSHER', 'ROCKET']],
    [3, 7], [278260, 278261])

inputs = {x['run_id']: json.loads((OUT / 'audit-inputs' / (x['run_id'] + '.json')).read_text())
    for x in json.loads((OUT / 'audit-inputs.json').read_text())}
paired = []
for run, a, b, expected in [('8JRE1C4H4Z2W', 270216, 270282, [[3, 10], [15, 17]]),
                          ('YF0LXT1QSTGG', 271309, 271348, [[0, 45], [9, 38]]),
                          ('XP2SL33HT0D9', 271992, 272040, [[9, 24], [14, 27]]),
                          ('XP2SL33HT0D9', 271982, 272195, [[2, 25], [10, 34]])]:
    value = inputs[run]
    decisions = value['decisions']
    index = {x['_line']: x for x in decisions}
    check('同盘指纹-' + str(a), index[a]['fingerprint'], index[b]['fingerprint'], [])
    state_index = {(x['observed_ts'], x['fingerprint']): x['_line'] for x in value['states']}
    observations = []
    endpoints = []
    for line in [a, b]:
        before = index[line]
        later = next(x for x in decisions if x['_line'] > line and x.get('turn') == before['turn'] + 1
            and all(x.get(k) == before.get(k) for k in ['floor', 'sl_attempt', 'sl_reloads']))
        lo = state_index[(before['observed_ts'], before['fingerprint'])]
        hi = state_index[(later['observed_ts'], later['fingerprint'])]
        left, right = states[lo], states[hi]
        observations.append([left['hp'] - right['hp'], sum(x['hp'] for x in left['enemies']) - sum(x['hp'] for x in right['enemies'])])
        endpoints.extend([lo, hi])
    check('同轮手工端点差-' + str(a), observations, expected, endpoints)
    paired.append({'run': run, 'decision_lines': [a, b], 'state_lines': endpoints,
        'observed_hp_loss_and_enemy_net_loss': observations,
        'scope': '同盘不同尝试的手工整轮端点，包含所有重问，不认证完整候选或整战反事实'})

for item in json.loads((OUT / 'offline-audit-summary.json').read_text()):
    check('离线审计无整候选认证-' + item['run_id'], item['certified_candidate_results'], 0, [])
sl = json.loads((OUT / 'run-metadata.json').read_text())['sl']
check('成功SL反例保留', any(x['run_id'] == 'YF0LXT1QSTGG' and x['floor'] == 33 and x['attempt'] == 2 and x['result'] == 'won' for x in sl), True, [])
(OUT / 'fixed-case-verification.json').write_text(json.dumps({'scope': '固定证据材料断言；不是生产测试或反事实策略收益',
    'checks': len(receipts), 'receipts': receipts, 'paired_observations': paired}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(receipts), 'passed': True, 'paired_observations': paired}, ensure_ascii=False))

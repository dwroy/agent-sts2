from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile
root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2357'; pub=r/'paper/materials/20261015-2357-ops'; pub.mkdir(exist_ok=True); sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=r): return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261015-234301-s2-strategy-proposal'; b=load(r/'ops/codex-ops/learn.json')['batches'][bid]; report=b['report']; s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert report['fixes']==report['implementation_domains']==[] and report['merged'] is None and all(v is None for v in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
completion=load(s/'completion-check.json'); assert completion['base']==report['base'] and completion['tracked_status_clean'] and completion['new_source_commits']==0 and completion['proposal_results_complete'] and completion['code_proposal_links_valid'] and completion['ledger_trace_updates']==30 and completion['ledger_protected_fields_unchanged'] and completion['source_audit_leaves_unchanged']==16 and completion['material_assertions']==37 and completion['offline_consumer_exits']==[0]*6
for name,x in load(s/'final-artifacts.json').items():
 raw=(s/name).read_bytes(); assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
verified=load(s/'verified-evidence.json'); assert sum(x['rows_verified'] for x in verified)==8274 and len(verified)==8
for x in verified: assert sha((s/'evidence'/(x['stream']+'.evidence.jsonl')).read_bytes())==x['sha256']
assert load(s/'verification-output.json')['verified_rows']==8274
cases=load(s/'fixed-case-verification.json'); assert cases['checks']==len(cases['receipts'])==37 and all(x['actual']==x['expected'] for x in cases['receipts'])
summary=load(s/'offline-audit-summary.json'); assert len(summary)==6 and all(x['exit_code']==0 and x['certified_candidate_results']==0 for x in summary)
assert sum(x['segments'] for x in summary)==206 and sum(x['turns'] for x in summary)==185 and sum(x['turn_status'].get('observed_turn_endpoints',0) for x in summary)==119 and sum(x['turn_status'].get('unknown',0) for x in summary)==66
for x in summary: assert sha((s/(x['run_id']+'-selection-audit.json')).read_bytes())==x['sha256']
auditinputs=load(s/'audit-inputs.json')
for x in auditinputs: assert sha((s/'audit-inputs'/(x['run_id']+'.json')).read_bytes())==x['input_sha256'] and x['omitted_no_decision_id']==[]
proposals=load(s/'proposals-snapshot.json')['items']; assert set(proposals)==set(report['code_proposals'])
for ident,x in proposals.items():
 f=Path(x['proposal']); assert f.resolve().is_relative_to(r); assert sha(f.read_bytes())==x['proposal_sha256']==sha((s/'original-proposals'/(ident+'.md')).read_bytes())
source=load(s/'source-audit.json'); assert source['base']==report['base'] and len(source['paths'])==16; equal=0
for x in source['paths']:
 raw=git('show',report['base']+':'+x['path']); live=git('show',source['live']+':'+x['path']); assert sha(raw)==x['sha256'] and sha(live)==x['live_sha256']; assert raw.replace(b'Roy',b'Dai')==live.replace(b'Roy',b'Dai'); equal+=raw==live; assert x['last_change_is_live_ancestor']; git('merge-base','--is-ancestor',x['last_change'],source['live'])
assert equal==13
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()]; ledger=r/'paper/materials/learning/ledger.jsonl'; owned=[]
for raw in ledger.read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs): owned.append(raw)
assert len(inputs)==len(owned)==30 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned)
assert set((s/'ledger-update.stdout').read_text().split())=={x['id'] for x in inputs}; receipt=load(s/'ledger-link-receipt.json'); assert receipt['rows']==30 and receipt['exit_code']==0 and receipt['append_only_trace_links'] and all(x['claim_first_prior_evidence_version_unchanged'] and x['old_history_notes_where_preserved'] for x in receipt['protected'].values())
for x in receipt['physical_rows']:
 with ledger.open('rb') as f: f.seek(x['offset']); raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and raw in owned
old=git('show',base+':paper/materials/learning/ledger.jsonl'); existing=set(old.splitlines()); added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==30
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(a)==set(z)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
 assert z[ident]['history'][:len(a[ident]['history'])]==a[ident]['history']
 for key,items in a[ident]['where'].items(): assert all(x in z[ident]['where'][key] for x in items)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_no_change_gate=b['no_change_proposals'],native=native,original_completion=completion,original_artifacts_and_evidence_sha_verified=True,original_evidence_rows=8274,original_material_assertions=37,original_audit_summary=summary,original_audit_inputs=auditinputs,source16_sha_and_ancestry_verified=True,equal13_historical_comment_only3=True,owned_learner_cli_rows=30,original_offset_bytes_sha_readback_verified=True,protected_fold_history_where_preserved=True,material_or_consumer_not_reexecuted=True,limits=['206 segments/185 windows:119 observed endpoints,66 unknown, no certified full candidate. Selected floors only, not whole historical denominator.', 'Four manual same-board pairs contain all actual requests/replans; not certification of an original candidate or a controlled full-fight counterfactual. Original victorious SL counterexample retained.', 'Historical188 accepted Codex brain records are high; current learner native Sol6.1/xhigh independently bound without changing historical records.', 'Dirty consumed knowledge bytes, stable summon generations, per-source cumulative ownership, alternative full outcomes and independent holdout remain missing.', 'Original two guessed nonexistent paths and truncated displays retained; no new contradiction, game rule, source, production test, release or parent closure.']))
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：2357原234301-s2策略done0/no-source处置核，7b1干净WT/HEAD不变，十waiting均有具体缺口，testsnull/域空/mergednull，无源码或合入阻塞，不空合/发号/补测。六Silent A10八流8274原行SHA、37原材料断言及六原离线消费者输入/输出SHA核，不重跑或当生产测试/收益；选层206候选段/185轮窗119观察端点66未知、完整候选认证0，四手工同盘净差与已胜SL反例/历史dirty输入及逐源/受控后继缺口保持，不推出统一SL血价、禁探索或101局全史已校准。16叶旧livecfa1逐SHA/祖先核13同3历史注释差，不重写注释或宣称历史dirty树等价；30原CLI纯where/note逐原输入/输出ID、offset/bytes/SHA核，私有fold全部非追溯字段/旧history和where保持，不重复CLI/新增证据或降级shipped。原历史188脑high与当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network分列，原未独立读原生说明保留；两旧路径定位失败/输出截断不当产品失败或另派修复。仅本人记录/30所属追溯提交，保并行脏记录；无新源码/规则/复盘/论文刷新/测试/模型派发/对局重启/账号home额度队列prompt操作，不关闭宽父。证据paper/materials/20261015-2357-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原234301-s2十项继续waiting，无源码/合入阻塞或生产测试；8274原行、37材料断言与六份限定离线审计读回已归档，30所属CLI只补追溯。完整候选、历史dirty输入、逐源及受控后继缺口保持，不新增版本或学习父。回执paper/materials/20261015-2357-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,own_ledger_rows=30,protected_fields_preserved=True,no_new_source_or_tests_or_merge=True,wide_parents='remain open'))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts); helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(waiting=10,owned_cli_rows=30,ledger_check=0,paths=len(entries))))

# 静默猎手策略队列本批报告

记录时间：2026-10-16T21:20:53+08:00

本批十项均waiting，没有足够证据新增策略规则，也没有发现已被现有窄实现遗漏、能够独立验收的新模型数值差额。未改生产源码、任务模板、知识或当前对局行为，没有源码提交、合入、eval版本或shipped声明。逐项证据/账本/反例/旧行为/预期行为/验证/回退见proposal.md。

base：`e207d1db4222f6e66d4cccc31ad6a6c3bc3aca23`。开工git status干净；普通批按任务执行git merge --no-edit main，返回Already up to date。HEAD保持该40位提交。
batch=20261016-211301-strategy-proposal、task=strategy-proposal、character=silent、reason=proposal；十个proposal_ids精确核对，无research_request/implementation_request/proposal_repair。根deck-size请求绑定旧批，不代替本批身份；没有进入专题。派发快照dispatch.json，十原提案与SHA在assigned-proposals.json及*.original.md。

## 原始证据复核

六局runs.jsonl均为SILENT/A10，身份见runs-identity.json和verified-runs.json。只读本角色日志、已链接复盘/账本及knowledge/characters/silent中19个相关经验；当前经验的后续案例未当成本批新实盘证明。普通/升级神化的其他来源局不在六锚点内，本批不据经验摘要扩展其模型。

复用20261016-191302批由learner/extract_evidence.py保存的八流封套，本批不重新扫全历史、不复制整份136MiB证据或230MiB消费者材料、不覆盖旧报告/截点。引用与manifest SHA保存evidence-reference.json；本批逐行按source_size界内的offset/bytes/SHA读回只读原日志，核JSON完全相等与run_id/state.run_id/run/fingerprint.run显式身份一致，合计6995行。正文提及不算所属局，冲突身份不接收；fight-plans零行只说明该旧截点未选到。

| 流 | 冻结source_size字节 | 逐行核验数 |
|---|---:|---:|
| states | 13615328878 | 3432 |
| decisions | 2026157101 | 3306 |
| sl-attempts | 43865613 | 29 |
| run-config | 1895188 | 6 |
| run-plans | 8621197 | 33 |
| brain | 686334717 | 183 |
| runs | 351918 | 6 |
| fight-plans | 2233957 | 0 |

37项原帧材料检查通过，原始检查与投影见fact-checks.json、checked-state-projections.json，命令结果evidence-verification.log；它们不是生产tsc/Vitest或源码红绿。涵盖普通神化已见升级、药水真实能量/HP、蚌成长与虚弱、负敏捷/毒净扣、召唤体各自HP/力量、甲虫临减力恢复、无毒冒泡和同指纹SL端点。原稿中持有、预测、实际派发、实际观测与未来未结算值仍分列，未补造中间因果或未选线结果。

## 现有消费者材料与源码

只读live快照：`c783c6c83d09e669f49518a4536ae5bc3766c2a2`。source-verification.json记录21个相关源码叶：全部与前批base相同，19叶与该live字节相同，card-model.ts/sl/explore.ts两叶仅历史Roy/Dai注释差，差分完整保留live-source-diff.patch。全部本树叶与本批base相同。检查范围不代表旧dirty源码、刷新知识、移动表或全生产输入已复原。

九个已有窄源均重新核为实际base/live祖先：

- ordinary_upgrade：`772b839f8ada31664cb764ea9ad3bdb03da27f64`；base/live祖先=True/True。
- accelerant_upgrade：`f516592fff557ef02c8ece43433706358c3f7fe6`；base/live祖先=True/True。
- apotheosis_reference：`3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17`；base/live祖先=True/True。
- malaise_upgrade：`b2805be4ba44b7375c7908d873889372cc3cfe6c`；base/live祖先=True/True。
- deadly_poison_upgrade：`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`；base/live祖先=True/True。
- selection_snapshots：`05cd292c6f01bb31e406473d3a9843e659d62b93`；base/live祖先=True/True。
- guard_sl_audit：`a8b1f8be153fe4f3a34146117546c2178f2e446b`；base/live祖先=True/True。
- offline_consumer：`cf72bd21148059f111f760cc98a727369e34a47e`；base/live祖先=True/True。
- offline_terminal：`83512ddcd2c70fd9b983dc38524ff25c8970c1d3`；base/live祖先=True/True。

这些不是本批新提交或合入。神化reference的actual_cast_this_fight仍null；三阶段预测及single_action_receipt没有认证整个候选。现有数值已覆盖的窄子项不能替代整个原提案的实现证明。

consumer-reference-verification.json保留前批消费者输入/输出/失败stderr的27份文件及readback的SHA核验；九份旧完整/有界输入均按6995条已核封套的原行号、SHA与原行对象复核，有限输入只剔除原来声明的缺ID行。消费者及实际依赖源码与前批相同，本批只读回旧产物、没有重跑消费者/模型/模拟，不把旧命令rc冒称本批新执行。

旧结果：VLZ、8JRE、5PM完整输入rc0；CA5第267143、61E第267517、DUZU第268789/268818/268864原行缺decision_id，旧完整输入rc1保留，排除上述五行的有界输入rc0。不补ID，不把有界结果叫完整局成功。

| 局号 | 带ID动作 | 候选片段 | 相邻动作端点 | 终局端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |

合计3301动作、476片段、859相邻端点、4终局端点、121整轮端点、413未知轮窗口。所有片段actual_full_candidate_result仍null，表示没有被该消费者认证，不能解读为实际零执行或零收益。完整归属缺口与策略阈值/预算/血价需要的受控后继缺口分开；后者不是拒绝窄审计或已核纯模型修复的理由，本批没有隔离出新的窄差额。

## 逐项处置

| 原提案 | 状态 | 具体待补条件 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、用药、重问、SL和换战的持续施放身份核验及剩余属性交互校准；已见数值的窄模型已有live实现，本批未隔离出新的数值差额。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型、同起点/随机池/总预算的配对实验、候选稳定性与样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化宽项仍缺实际施放持续身份和跨中断验证；不能仅凭同题或已有窄源码将该独立经验来源链登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息的资源接续；局部端点不能关闭复合项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；另缺未选线的受控整战后继，不改护栏或SL血价。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部无毒空打不足制定构筑或启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利与毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码与T4端点不足认证目标顺序的整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。 |

## 记录与验证边界

通过根learner/ledger.py update仅追加26个原账本的本批proposal/report路径和note追溯；不重复新增证据计数，不改claim/首证/prior/evidence/status/version/shipped，不新建代码提案id，专用队列只由调度器消费proposal_results。CLI输入、结果与逐物理追加核验单独保存。部分旧账本已有shipped属于历史子实现，不当本批宽项完成。

本批没有生产源码修改，撤源码失败/恢复通过不适用；tests固定为{"tsc":null,"vitest":null,"cases":null}，未运行或借用成功生产测试。没有启动live合入、不造空提交、上线decision-log、eval编号或规则双通知；全部角色行为保持等价。没有改运维prompt、读key/.env/游戏二进制、联网、play、停止对局、推送或派下级agent。

工具接口没有提供本原生会话model/reasoning/service的可独立核验请求回执；不凭任务文字自证运行切换，也未修改模型/账号/服务档/权限。最终git状态与HEAD核验见final-verification.json。

本次报告不关闭学习入库或其他宽父，不声称经验已发布、大脑采用、收益成立或源码已上线。fixes=[]、merged=null；十项保留等待具体新数据，不把重复派发次数当证据。

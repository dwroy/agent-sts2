# 静默猎手十项原提案的本批证据与处置

记录时间：2026-10-16T21:20:53+08:00

batch=20261016-211301-strategy-proposal；base=e207d1db4222f6e66d4cccc31ad6a6c3bc3aca23；全部为waiting。
只消费派来的十个原id；不领取新项、不改原提案、不重写复盘、不新建重复提案。

共同边界：六个来源局均SILENT/A10且原代码带dirty。旧帧已用于发现和回归，不是后置盲测；同局SL不当独立样本。游戏数值仅取这些原帧及原账本；后续经验文字不是本批独立验证。没有拟合新权重、阈值或最优顺序。

## silent-proposal-89354805ee4d7e77

主题：神化升级传播与实际施放。角色silent，已观察A10。
账本：silent-0237, silent-0238；来源任务：postmortem；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d；原字节另存silent-proposal-89354805ee4d7e77.original.md。

证据：VLZ6CCT8AQ0A F35 T1、F43 T1—T2、F45 T1；states275564→275565、275679→275680、275687、275728→275732；decisions269706/269707/269748。
支持：F35神化实付2能；防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费。F43突然一拳9→11/弱1→2、勒紧4→6、尖啸6→8，后抽毒雾升级。两次同后续牌序预测43伤/14损与51伤/13损分列。
反例与限制：F45持有神化但未施放并被弃；F43施放仍整战损57，不能把升级与胜负等同。
已有覆盖与旧行为：已见普通升级配对、同线与已知后抽状态变换、持有/候选/模型覆盖参考已有窄实现；actual_cast_this_fight仍明确为null。
本批处置：waiting。缺跨抽牌、选牌、用药、重问、SL和换战的持续施放身份核验及剩余属性交互校准；已见数值的窄模型已有live实现，本批未隔离出新的数值差额。
预期行为与验证：保持现有数值和未知标记；后续需冻结带连续战斗/尝试身份、派发回执和后继状态的施放链，验证建立、重问、SL恢复与换战清零；仅持牌或升级牌面不能补造施放事件。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-f2bfceddb1898dca

主题：预算成熟度、即时血价与药水。角色silent，已观察A10。
账本：silent-0106, silent-0019, silent-0201；来源任务：postmortem；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26；原字节另存silent-proposal-f2bfceddb1898dca.original.md。

证据：VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；decisions269745/269748/269754/269770，states275728→275729、275754。
支持：F45首题药水MC为707ms、1/12样本；rollout horizon1/samples1/best=null。药水后能量1→2、HP67不变，手牌为神化、必备工具、生存者；末轮32HP/20挡对59显示来袭。
反例与限制：best=null不等于并列；成熟度不同的后问不能充当同预算实验。F43胜利仍消耗57血，回血后死亡不能证明回血无效。
已有覆盖与旧行为：silent-simulation-reference已区分样本范围、降级、未知牌、抽牌重问、药水采样与明确并列；没有将未比出最佳包装成并列。
本批处置：waiting。缺完整模型、同起点/随机池/总预算的配对实验、候选稳定性与样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。
预期行为与验证：保持预算、留药和目标规则；验证须固定知识/移动表/随机池与总预算，先分清模型遗漏及耗时，再比较候选稳定性，不由单题定常量。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-283a164780d11e69

主题：神化经验来源的独立补链。角色silent，已观察A10。
账本：silent-0237, silent-0238；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637；原字节另存silent-proposal-283a164780d11e69.original.md。

证据：VLZ6CCT8AQ0A，与89354805ee4d7e77共用F35/F43/F45证据；来源为experience-update，经验silent-apotheosis-combat-upgrades。
支持：保留经验来源与复盘来源两条真实CLI id及各自Markdown SHA，不把同局多次施放增加为独立局。
反例与限制：同题与同证据不意味着完整实现已在live，F45未施放不能充当施放机制反例。
已有覆盖与旧行为：共用上述有限配对与参考实现；原提案要求的持续施放身份仍未完成。
本批处置：waiting。同源神化宽项仍缺实际施放持续身份和跨中断验证；不能仅凭同题或已有窄源码将该独立经验来源链登记duplicate。
预期行为与验证：沿原id补本批报告链接，不新建重复提案；实现与验证条件同普通神化项，完整满足后才引用实际live祖先commit关闭。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-ebbfe3b97548756d

主题：十五个机制与资源子项。角色silent，已观察A10。
账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2；原字节另存silent-proposal-ebbfe3b97548756d.original.md。

证据：VLZ6CCT8AQ0A F43 T1—T5、F45 T3—T5及F44；原提案保留15个经验→14个账本映射。
支持：F45末轮覆甲0、牌挡20、显示来袭59已直接核；F43升级勒紧6与F45普通4分列，毒/临时减力/属性/回复分别按原账本与原帧，不增加整战固定收益。
反例与限制：末轮尚存多敌不等于focus必胜；持有两毒雾不等于已经建立。跨路线或不同战斗的赢败不作受控比较。
已有覆盖与旧行为：属性、毒额外结算、现场覆甲、有限升级与资源展示有局部模型；这些不能替代十五子项的共同消费者验收。
本批处置：waiting。缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息的资源接续；局部端点不能关闭复合项。
预期行为与验证：原行为保留；冻结每个来源的值、期限、当前进阶数据库与消费者输入，对已核实差额单独修复，神化模型沿原专属项，避免重复实现。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-e5b87be50f28f311

主题：SL与护栏的候选、派发和实际收益。角色silent，已观察A10。
账本：silent-0079, silent-0021, silent-0125, silent-0018；来源任务：postmortem；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709；原字节另存silent-proposal-e5b87be50f28f311.original.md。

证据：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11及F17 T6；decisions270216/270282/270264。
支持：270216/270282指纹完全相同；第三试原/替线死亡样本0/24与5/24不同。按同尝试后继帧核得T2实际玩家/敌HP净差分别−3/−10与−15/−17，即多付12HP只多扣7当轮敌血。
反例与限制：两次均未形成受控胜线；末次更防守延至T11仍败。候选省血不能自动记为实省血，0/24与5/24不能写成相同死率。
已有覆盖与旧行为：已有三阶段预测、单动作派发回执与离线端点；它们保留whole_plan_executed/actual_full_candidate_result未知，不认证跨重问整候选。
本批处置：waiting。缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；另缺未选线的受控整战后继，不改护栏或SL血价。
预期行为与验证：保留审计与原选择；完整归属需要稳定候选/步骤/尝试身份及中断边界，回执和后继观测共同验证。上述实际HP端点只作观测差，不强归因某张牌。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-49632bc4878fb597

主题：力量、敏捷、虚弱与蚌成长。角色silent，已观察A10。
账本：silent-0005, silent-0231；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2；原字节另存silent-proposal-49632bc4878fb597.original.md。

证据：CA5KE8GFJ9X2 F13 T1/T3/T5；states273237/273252/273263、273257/273268。
支持：敌力0/4/8，同招显示来袭11/15/19；虚弱后11/14，成长并未取消。
反例与限制：该战没有取得计划中的步法，不能补正敏捷实测；死亡不能反证逐击属性机制。
已有覆盖与旧行为：当前属性模型和成长输入有实现，未据此核准四条路径的整体联合输入。
本批处置：waiting。缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。
预期行为与验证：保持权重；按当前进阶固定数据库、牌面与属性逐步对照，不用经验支持局总数充当每个子式样本。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-66532328a585941f

主题：组件持有与启动兑现。角色silent，已观察A10。
账本：silent-0021, silent-0009；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831；原字节另存silent-proposal-66532328a585941f.original.md。

证据：5PM6JAQG6FNQ F39末试T2，states274379→274380、decision268455；同局F33反例保留。
支持：冒泡实际消耗1能，敌THE_LOST HP35不变、毒0不变；玩家HP为29，35是敌HP，沿旧账本更正口径。
反例与限制：同局F33建立组件并赢时生存和其他条件也改变，不能归因为固定早建顺序。
已有覆盖与旧行为：现有BUBBLE_BUBBLE模型带poisonRequiresExisting，组件计划与现场能力分开，未发现该局部事实的新模型差额。
本批处置：waiting。缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部无毒空打不足制定构筑或启动权重。
预期行为与验证：保持构筑/启动规则；新比较应明确实付、建立和后继窗口，不能以持有代替能力已经生效。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-43a76a31ba7bdcfa

主题：负敏捷、毒与SL边界。角色silent，已观察A10。
账本：silent-0030, silent-0027；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c；原字节另存silent-proposal-43a76a31ba7bdcfa.original.md。

证据：61E2QS63Y9WU F17 T5—T6；states273504→273508。
支持：T6敏捷−2，两防御牌面各3；敌HP67→34为当轮净扣33端点，与17+16毒账分列。
反例与限制：该战首试胜利，不是SL换线对照；端点净扣不能擅自补中间结算帧。
已有覆盖与旧行为：已见负属性和毒结算有局部模型，原SL条件保持。
本批处置：waiting。缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利与毒端点不足改变SL范围或阈值。
预期行为与验证：保留原范围/阈值；验证整局按run_id分组，SL多次不能扩大独立分母，原帧回归不称后置盲测。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-5264153a4a4b0e5c

主题：召唤、实体成长与目标顺序。角色silent，已观察A10。
账本：silent-0039, silent-0209；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02；原字节另存silent-proposal-5264153a4a4b0e5c.original.md。

证据：61E2QS63Y9WU F23 T4；states273589/273593/273596。
支持：按唯一敌人类型定位，本体/幻象76/14→41/2，玩家25→10；两次航行后两实体力量3→6。
反例与限制：另一focus幻象的39伤/零损候选未实打；本体与幻象不能按数组位置假定身份。
已有覆盖与旧行为：已有召唤结构与独立敌人状态模型，原数据端点不认证完整退场/复现链或目标收益。
本批处置：waiting。缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码与T4端点不足认证目标顺序的整战收益。
预期行为与验证：保留所有目标选项与同值并列；冻结实体身份和当前进阶数据逐帧验召唤/成长/退出，不规定首杀。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。

## silent-proposal-bddfa690a84e03d0

主题：睡眠、临时减力与醒后成长。角色silent，已观察A10。
账本：silent-0128, silent-0079；来源任务：experience-update；实现任务：strategy-proposal。
原稿：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780；原字节另存silent-proposal-bddfa690a84e03d0.original.md。

证据：DUZUBAJ3A8GP F30 T5—T6；states274929/274932/274934；睡3/2/1与T4醒来见原提案。
支持：甲虫力量2→−4→4，来袭20→14→22；临时减力恢复与成长不能混为永久压制。
反例与限制：四次相关尝试都失败，末试某轮多伤但多损血，不足拟合输出血价或固定杀序。
已有覆盖与旧行为：已有睡眠/唤醒和成长结构，未完成该局全部唤醒/眩晕/成长联合校准。
本批处置：waiting。缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。
预期行为与验证：保持规则；按现场睡眠、覆甲、临减力恢复和成长分别验，缺中间帧留未知，不从当前源码补旧局事实。
预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。
回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。


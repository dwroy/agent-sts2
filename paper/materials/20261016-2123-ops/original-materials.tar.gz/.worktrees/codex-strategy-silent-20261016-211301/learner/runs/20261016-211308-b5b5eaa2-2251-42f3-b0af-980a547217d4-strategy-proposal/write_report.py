"""Preserve this batch's bounded conclusions without changing production or queue state."""
import datetime as dt
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / "dispatch.json").read_text())
assigned = json.loads((HERE / "assigned-proposals.json").read_text())
source = json.loads((HERE / "source-verification.json").read_text())
envelopes = json.loads((HERE / "envelope-verification.json").read_text())
consumer = json.loads((HERE / "consumer-reference-verification.json").read_text())
stamp = dt.datetime.now().astimezone().isoformat(timespec="seconds")

findings = [
    ("89354805ee4d7e77", "神化升级传播与实际施放",
     "VLZ6CCT8AQ0A F35 T1、F43 T1—T2、F45 T1；states275564→275565、275679→275680、275687、275728→275732；decisions269706/269707/269748。",
     "F35神化实付2能；防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费。F43突然一拳9→11/弱1→2、勒紧4→6、尖啸6→8，后抽毒雾升级。两次同后续牌序预测43伤/14损与51伤/13损分列。",
     "F45持有神化但未施放并被弃；F43施放仍整战损57，不能把升级与胜负等同。",
     "已见普通升级配对、同线与已知后抽状态变换、持有/候选/模型覆盖参考已有窄实现；actual_cast_this_fight仍明确为null。",
     "缺跨抽牌、选牌、用药、重问、SL和换战的持续施放身份核验及剩余属性交互校准；已见数值的窄模型已有live实现，本批未隔离出新的数值差额。",
     "保持现有数值和未知标记；后续需冻结带连续战斗/尝试身份、派发回执和后继状态的施放链，验证建立、重问、SL恢复与换战清零；仅持牌或升级牌面不能补造施放事件。"),
    ("f2bfceddb1898dca", "预算成熟度、即时血价与药水",
     "VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；decisions269745/269748/269754/269770，states275728→275729、275754。",
     "F45首题药水MC为707ms、1/12样本；rollout horizon1/samples1/best=null。药水后能量1→2、HP67不变，手牌为神化、必备工具、生存者；末轮32HP/20挡对59显示来袭。",
     "best=null不等于并列；成熟度不同的后问不能充当同预算实验。F43胜利仍消耗57血，回血后死亡不能证明回血无效。",
     "silent-simulation-reference已区分样本范围、降级、未知牌、抽牌重问、药水采样与明确并列；没有将未比出最佳包装成并列。",
     "缺完整模型、同起点/随机池/总预算的配对实验、候选稳定性与样本成熟曲线及留药完整后继；707ms单题不足设新预算、药价或focus规则。",
     "保持预算、留药和目标规则；验证须固定知识/移动表/随机池与总预算，先分清模型遗漏及耗时，再比较候选稳定性，不由单题定常量。"),
    ("283a164780d11e69", "神化经验来源的独立补链",
     "VLZ6CCT8AQ0A，与89354805ee4d7e77共用F35/F43/F45证据；来源为experience-update，经验silent-apotheosis-combat-upgrades。",
     "保留经验来源与复盘来源两条真实CLI id及各自Markdown SHA，不把同局多次施放增加为独立局。",
     "同题与同证据不意味着完整实现已在live，F45未施放不能充当施放机制反例。",
     "共用上述有限配对与参考实现；原提案要求的持续施放身份仍未完成。",
     "同源神化宽项仍缺实际施放持续身份和跨中断验证；不能仅凭同题或已有窄源码将该独立经验来源链登记duplicate。",
     "沿原id补本批报告链接，不新建重复提案；实现与验证条件同普通神化项，完整满足后才引用实际live祖先commit关闭。"),
    ("ebbfe3b97548756d", "十五个机制与资源子项",
     "VLZ6CCT8AQ0A F43 T1—T5、F45 T3—T5及F44；原提案保留15个经验→14个账本映射。",
     "F45末轮覆甲0、牌挡20、显示来袭59已直接核；F43升级勒紧6与F45普通4分列，毒/临时减力/属性/回复分别按原账本与原帧，不增加整战固定收益。",
     "末轮尚存多敌不等于focus必胜；持有两毒雾不等于已经建立。跨路线或不同战斗的赢败不作受控比较。",
     "属性、毒额外结算、现场覆甲、有限升级与资源展示有局部模型；这些不能替代十五子项的共同消费者验收。",
     "缺十五子项在同一冻结生产输入下的逐源联合校准，尤其属性/升级组合、状态期限及战斗→路线→休息的资源接续；局部端点不能关闭复合项。",
     "原行为保留；冻结每个来源的值、期限、当前进阶数据库与消费者输入，对已核实差额单独修复，神化模型沿原专属项，避免重复实现。"),
    ("e5b87be50f28f311", "SL与护栏的候选、派发和实际收益",
     "8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11及F17 T6；decisions270216/270282/270264。",
     "270216/270282指纹完全相同；第三试原/替线死亡样本0/24与5/24不同。按同尝试后继帧核得T2实际玩家/敌HP净差分别−3/−10与−15/−17，即多付12HP只多扣7当轮敌血。",
     "两次均未形成受控胜线；末次更防守延至T11仍败。候选省血不能自动记为实省血，0/24与5/24不能写成相同死率。",
     "已有三阶段预测、单动作派发回执与离线端点；它们保留whole_plan_executed/actual_full_candidate_result未知，不认证跨重问整候选。",
     "缺跨抽牌、选牌、生成、药水、SL和重问的完整候选持续归属及成长兑现关联；另缺未选线的受控整战后继，不改护栏或SL血价。",
     "保留审计与原选择；完整归属需要稳定候选/步骤/尝试身份及中断边界，回执和后继观测共同验证。上述实际HP端点只作观测差，不强归因某张牌。"),
    ("49632bc4878fb597", "力量、敏捷、虚弱与蚌成长",
     "CA5KE8GFJ9X2 F13 T1/T3/T5；states273237/273252/273263、273257/273268。",
     "敌力0/4/8，同招显示来袭11/15/19；虚弱后11/14，成长并未取消。",
     "该战没有取得计划中的步法，不能补正敏捷实测；死亡不能反证逐击属性机制。",
     "当前属性模型和成长输入有实现，未据此核准四条路径的整体联合输入。",
     "缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长的联合校准；本局无正敏捷实测，不增加统一保血或输出权重。",
     "保持权重；按当前进阶固定数据库、牌面与属性逐步对照，不用经验支持局总数充当每个子式样本。"),
    ("66532328a585941f", "组件持有与启动兑现",
     "5PM6JAQG6FNQ F39末试T2，states274379→274380、decision268455；同局F33反例保留。",
     "冒泡实际消耗1能，敌THE_LOST HP35不变、毒0不变；玩家HP为29，35是敌HP，沿旧账本更正口径。",
     "同局F33建立组件并赢时生存和其他条件也改变，不能归因为固定早建顺序。",
     "现有BUBBLE_BUBBLE模型带poisonRequiresExisting，组件计划与现场能力分开，未发现该局部事实的新模型差额。",
     "缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；局部无毒空打不足制定构筑或启动权重。",
     "保持构筑/启动规则；新比较应明确实付、建立和后继窗口，不能以持有代替能力已经生效。"),
    ("43a76a31ba7bdcfa", "负敏捷、毒与SL边界",
     "61E2QS63Y9WU F17 T5—T6；states273504→273508。",
     "T6敏捷−2，两防御牌面各3；敌HP67→34为当轮净扣33端点，与17+16毒账分列。",
     "该战首试胜利，不是SL换线对照；端点净扣不能擅自补中间结算帧。",
     "已见负属性和毒结算有局部模型，原SL条件保持。",
     "缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利与毒端点不足改变SL范围或阈值。",
     "保留原范围/阈值；验证整局按run_id分组，SL多次不能扩大独立分母，原帧回归不称后置盲测。"),
    ("5264153a4a4b0e5c", "召唤、实体成长与目标顺序",
     "61E2QS63Y9WU F23 T4；states273589/273593/273596。",
     "按唯一敌人类型定位，本体/幻象76/14→41/2，玩家25→10；两次航行后两实体力量3→6。",
     "另一focus幻象的39伤/零损候选未实打；本体与幻象不能按数组位置假定身份。",
     "已有召唤结构与独立敌人状态模型，原数据端点不认证完整退场/复现链或目标收益。",
     "缺A10召唤、航行成长、退场及复现全链的冻结生产校准，以及另一focus完整后继；已有源码与T4端点不足认证目标顺序的整战收益。",
     "保留所有目标选项与同值并列；冻结实体身份和当前进阶数据逐帧验召唤/成长/退出，不规定首杀。"),
    ("bddfa690a84e03d0", "睡眠、临时减力与醒后成长",
     "DUZUBAJ3A8GP F30 T5—T6；states274929/274932/274934；睡3/2/1与T4醒来见原提案。",
     "甲虫力量2→−4→4，来袭20→14→22；临时减力恢复与成长不能混为永久压制。",
     "四次相关尝试都失败，末试某轮多伤但多损血，不足拟合输出血价或固定杀序。",
     "已有睡眠/唤醒和成长结构，未完成该局全部唤醒/眩晕/成长联合校准。",
     "缺伤害唤醒、眩晕接续及A10成长的完整冻结生产校准和同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。",
     "保持规则；按现场睡眠、覆甲、临减力恢复和成长分别验，缺中间帧留未知，不从当前源码补旧局事实。"),
]
assert {"silent-proposal-" + row[0] for row in findings} == set(dispatch["proposal_ids"]) == set(assigned)
results = []
proposal = ["# 静默猎手十项原提案的本批证据与处置", "", f"记录时间：{stamp}", "",
    f"batch={dispatch.get('batch', '20261016-211301-strategy-proposal')}；base={source['base']}；全部为waiting。",
    "只消费派来的十个原id；不领取新项、不改原提案、不重写复盘、不新建重复提案。", "",
    "共同边界：六个来源局均SILENT/A10且原代码带dirty。旧帧已用于发现和回归，不是后置盲测；同局SL不当独立样本。游戏数值仅取这些原帧及原账本；后续经验文字不是本批独立验证。没有拟合新权重、阈值或最优顺序。", ""]
for suffix, title, evidence, observation, counterexample, existing, reason, validation in findings:
    ident = "silent-proposal-" + suffix
    item = assigned[ident]
    results.append({"id": ident, "state": "waiting", "reason": reason})
    proposal.extend([f"## {ident}", "", f"主题：{title}。角色silent，已观察A10。",
        f"账本：{', '.join(item['ledger'])}；来源任务：{item['source_task']}；实现任务：strategy-proposal。",
        f"原稿：{item['proposal']}；SHA256={item['proposal_sha256']}；原字节另存{ident}.original.md。", "",
        f"证据：{evidence}", f"支持：{observation}", f"反例与限制：{counterexample}",
        f"已有覆盖与旧行为：{existing}", f"本批处置：waiting。{reason}",
        f"预期行为与验证：{validation}",
        "预期影响：本次只补可追溯证据和具体待补条件，不声称提高胜率或实际消费者已采用。",
        "回退：本批没有生产变更；保留原行为与全部历史。以后若实现，须保存固定输入、撤源码失败/恢复通过、原沙箱自测、真实live源码祖先和实际发布通知。Roy-2026-10-07-learning只提供权限，不提供游戏事实。", ""])
(HERE / "proposal.md").write_text("\n".join(proposal) + "\n")

table = "\n".join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
stream_table = "\n".join(f"| {r['stream']} | {r['source_size']} | {r['verified']} |" for r in envelopes)
consumer_table = "\n".join(f"| {r['run_id']} | {r['summary']['actions']} | {r['summary']['segments']} | {r['summary']['observed_action_endpoints']} | {r['summary']['terminal_endpoints']} | {r['summary']['observed_turn_endpoints']} | {r['summary']['unknown_turn_windows']} |" for r in consumer['runs'])
commit_table = "\n".join(f"- {r['topic']}：`{r['commit']}`；base/live祖先={r['base_ancestor']}/{r['live_ancestor']}。" for r in source['commits'])
report = f"""# 静默猎手策略队列本批报告

记录时间：{stamp}

本批十项均waiting，没有足够证据新增策略规则，也没有发现已被现有窄实现遗漏、能够独立验收的新模型数值差额。未改生产源码、任务模板、知识或当前对局行为，没有源码提交、合入、eval版本或shipped声明。逐项证据/账本/反例/旧行为/预期行为/验证/回退见proposal.md。

base：`{source['base']}`。开工git status干净；普通批按任务执行git merge --no-edit main，返回Already up to date。HEAD保持该40位提交。
batch=20261016-211301-strategy-proposal、task=strategy-proposal、character=silent、reason=proposal；十个proposal_ids精确核对，无research_request/implementation_request/proposal_repair。根deck-size请求绑定旧批，不代替本批身份；没有进入专题。派发快照dispatch.json，十原提案与SHA在assigned-proposals.json及*.original.md。

## 原始证据复核

六局runs.jsonl均为SILENT/A10，身份见runs-identity.json和verified-runs.json。只读本角色日志、已链接复盘/账本及knowledge/characters/silent中19个相关经验；当前经验的后续案例未当成本批新实盘证明。普通/升级神化的其他来源局不在六锚点内，本批不据经验摘要扩展其模型。

复用20261016-191302批由learner/extract_evidence.py保存的八流封套，本批不重新扫全历史、不复制整份136MiB证据或230MiB消费者材料、不覆盖旧报告/截点。引用与manifest SHA保存evidence-reference.json；本批逐行按source_size界内的offset/bytes/SHA读回只读原日志，核JSON完全相等与run_id/state.run_id/run/fingerprint.run显式身份一致，合计6995行。正文提及不算所属局，冲突身份不接收；fight-plans零行只说明该旧截点未选到。

| 流 | 冻结source_size字节 | 逐行核验数 |
|---|---:|---:|
{stream_table}

37项原帧材料检查通过，原始检查与投影见fact-checks.json、checked-state-projections.json，命令结果evidence-verification.log；它们不是生产tsc/Vitest或源码红绿。涵盖普通神化已见升级、药水真实能量/HP、蚌成长与虚弱、负敏捷/毒净扣、召唤体各自HP/力量、甲虫临减力恢复、无毒冒泡和同指纹SL端点。原稿中持有、预测、实际派发、实际观测与未来未结算值仍分列，未补造中间因果或未选线结果。

## 现有消费者材料与源码

只读live快照：`{source['live_snapshot']}`。source-verification.json记录21个相关源码叶：全部与前批base相同，19叶与该live字节相同，card-model.ts/sl/explore.ts两叶仅历史Roy/Dai注释差，差分完整保留live-source-diff.patch。全部本树叶与本批base相同。检查范围不代表旧dirty源码、刷新知识、移动表或全生产输入已复原。

九个已有窄源均重新核为实际base/live祖先：

{commit_table}

这些不是本批新提交或合入。神化reference的actual_cast_this_fight仍null；三阶段预测及single_action_receipt没有认证整个候选。现有数值已覆盖的窄子项不能替代整个原提案的实现证明。

consumer-reference-verification.json保留前批消费者输入/输出/失败stderr的27份文件及readback的SHA核验；九份旧完整/有界输入均按6995条已核封套的原行号、SHA与原行对象复核，有限输入只剔除原来声明的缺ID行。消费者及实际依赖源码与前批相同，本批只读回旧产物、没有重跑消费者/模型/模拟，不把旧命令rc冒称本批新执行。

旧结果：VLZ、8JRE、5PM完整输入rc0；CA5第267143、61E第267517、DUZU第268789/268818/268864原行缺decision_id，旧完整输入rc1保留，排除上述五行的有界输入rc0。不补ID，不把有界结果叫完整局成功。

| 局号 | 带ID动作 | 候选片段 | 相邻动作端点 | 终局端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
{consumer_table}

合计3301动作、476片段、859相邻端点、4终局端点、121整轮端点、413未知轮窗口。所有片段actual_full_candidate_result仍null，表示没有被该消费者认证，不能解读为实际零执行或零收益。完整归属缺口与策略阈值/预算/血价需要的受控后继缺口分开；后者不是拒绝窄审计或已核纯模型修复的理由，本批没有隔离出新的窄差额。

## 逐项处置

| 原提案 | 状态 | 具体待补条件 |
|---|---|---|
{table}

## 记录与验证边界

通过根learner/ledger.py update仅追加26个原账本的本批proposal/report路径和note追溯；不重复新增证据计数，不改claim/首证/prior/evidence/status/version/shipped，不新建代码提案id，专用队列只由调度器消费proposal_results。CLI输入、结果与逐物理追加核验单独保存。部分旧账本已有shipped属于历史子实现，不当本批宽项完成。

本批没有生产源码修改，撤源码失败/恢复通过不适用；tests固定为{{"tsc":null,"vitest":null,"cases":null}}，未运行或借用成功生产测试。没有启动live合入、不造空提交、上线decision-log、eval编号或规则双通知；全部角色行为保持等价。没有改运维prompt、读key/.env/游戏二进制、联网、play、停止对局、推送或派下级agent。

工具接口没有提供本原生会话model/reasoning/service的可独立核验请求回执；不凭任务文字自证运行切换，也未修改模型/账号/服务档/权限。最终git状态与HEAD核验见final-verification.json。

本次报告不关闭学习入库或其他宽父，不声称经验已发布、大脑采用、收益成立或源码已上线。fixes=[]、merged=null；十项保留等待具体新数据，不把重复派发次数当证据。
"""
(HERE / "report.md").write_text(report)
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261016-211301-strategy-proposal",
          "base": source['base'], "runs": dispatch['runs'], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None}, "code_proposals": list(assigned),
          "implementation_domains": [], "proposal_results": results, "report": str(HERE / "report.md")}
(HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"proposal": str(HERE / 'proposal.md'), "report": str(HERE / 'report.md'), "proposal_results": len(results)}, ensure_ascii=False))

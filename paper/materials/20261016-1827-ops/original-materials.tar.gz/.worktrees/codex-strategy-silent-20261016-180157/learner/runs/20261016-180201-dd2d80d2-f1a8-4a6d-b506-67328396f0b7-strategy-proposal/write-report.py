import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BATCH = '20261016-180157-strategy-proposal'
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
ASSIGNED = json.loads((OUT / 'assigned-proposals.json').read_text())
SOURCE = json.loads((OUT / 'source-verification.json').read_text())
BASE = SOURCE['base']
STAMP = subprocess.check_output(['date', '-Is'], text=True).strip()
print(STAMP)

DATA = [
    ('89354805ee4d7e77', '神化升级传播与实际施放',
     'VLZ6CCT8AQ0A F35 T1、F43 T1—T5、F45 T1—T5；states 275564/275565、275679/275680/275687、275728/275729；decisions 269748。',
     'F35神化前后能量7→5，防御5→8、打击7→10、匕首雨逐段5→7、必备工具1费→0；F43后续抽到升级毒雾。已证同线及后续已知抽牌的局部传播，不是整战收益。',
     'F43施放后仍有大量损血，F45持有却未施放；跨战斗资源和敌人不同，不能据胜负制定必打规则。',
     '缺跨抽牌、选牌、药水、重问、SL与换战的实际施放持续身份及未覆盖属性组合校准；actual_cast_this_fight仍为null，已有局部升级源码不能关闭整项。',
     '保留已观察升级的状态变换；持有、计划施放、模拟生效、实际施放分列，未知交互保持未知，不加神化固定优先级。',
     '以F35/F43/F45原帧建立同一战斗/尝试的持续动作证据，逐次核已施放、已升级与未知覆盖；保留重问、换战及SL边界。'),
    ('f2bfceddb1898dca', '三骑士药水预算与全败候选',
     'VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；decisions 269748、269754、269770；states 275728/275729、275754。',
     'F45首题随机药水MC=707毫秒、1/12样本，rollout horizon=1/samples=1/best=null；实际药水能量1→2、HP67不变。末轮32血20挡、显示合计来袭59。',
     '第二题有12/12样本但已不是同一盘面；T4少损线实打与未选攻击线只构成预测比较，不是留药或目标顺序的整战对照。',
     '缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性/样本成熟度曲线及留药完整后继；不由707毫秒单题修改预算、药价或focus。',
     '保留现有预算、留药与目标选择规则；将模拟成熟度、当轮血价、实际药水效果和敌人剩血分别展示，相同推演结果并列。',
     '冻结完整生产输入和随机池，先排除模型缺覆盖，再比较相同总预算的现规则与分阶段MC；需保存原始用时、样本和完整后继，不能把同题之外的重问当配对。'),
    ('283a164780d11e69', '神化经验来源补链',
     'VLZ6CCT8AQ0A F35/F43/F45；与89354805ee4d7e77同源，保留experience-update及silent-apotheosis-combat-upgrades链。',
     '原提案Markdown与登记SHA一致；本次同一局的四次施放不扩成四个独立样本，局部升级传播已存在。',
     '同题的两个来源请求不构成新增独立证据；已有局部源码也不等于原完整请求已实现。',
     '同源神化项仍缺实际施放持续身份及未覆盖升级交互校准；保留独立experience-update链，不仅凭同题或窄源码登记duplicate。',
     '沿原id及原经验链接复用专属升级实现；不再创建重复id，不修改原经验或提案正文。',
     '沿89354805ee4d7e77的持续施放/升级边界核验，并保存两个来源任务的真实链接及实际live源码证明。'),
    ('ebbfe3b97548756d', '十五项攻防机制与资源联合校准',
     'VLZ6CCT8AQ0A F43 T1—T5、F44、F45 T1/T3/T5；states 275679/275680、275748/275754；原十五子项及账本见原Markdown。',
     '可核升级前后牌面、后续毒雾、末轮现场覆甲0、32HP/20挡与合计59来袭；牌面、当前属性、暂时减力、毒和休息资源必须各自记账。',
     '本局已施放神化的胜场仍可能大幅损血；单轮减力和开场覆甲不能自动当成后续固定资源。原十五子项的历史支持数不是十五种组合的本批分母。',
     '缺十五个机制/资源子项的全部属性与升级组合、状态期限，以及战斗/路线/休息消费者在同一冻结知识和移动表下的逐源联合校准；局部模型和端点不足关闭整项。',
     '保持各来源机制及消费者现状；只对未来实际证明的模型缺口补状态变换，不增加统一保血、输出、休息或路线权重。',
     '逐子项固定手牌、属性、当前进阶敌人数据、移动表与消费者输入，分开核单轮结算、持续资源、即时回血与路线投影；神化沿专项复用。'),
    ('e5b87be50f28f311', 'SL与护栏替换的实际代价审计',
     '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11及F17 T6；decisions 270216/270282、270264。',
     '首/第三试T2指纹逐字相同；SL预测死亡0/24与5/24，实际整轮玩家-3/-15、敌血-10/-17，即多12血价与多7敌血净扣。270264护栏记在rationale，不能按结构字段缺失认作未发生。',
     '六次尝试来自一局；原线没有受控胜局。第二试T5及F17抽牌后重问，整轮端点不全归初始候选，末试更长存活也不能证明统一防御优先。',
     '现有三阶段预测审计、单动作回执和离线端点仍未认证跨抽牌/选牌/重问/药水/SL的完整候选持续归属及成长收益；缺完整执行证据和受控未选线后继，不改护栏或SL血价。',
     '原答、护栏后、SL后、首次派发与实际观测分列；completed只作为一次接口回执，重规划边界保留，不把预测差额登记成实际收益。',
     '固定首/三试T2、第二试T5及末试T11，核原指纹、尝试、卡牌和实体身份、每次重问与执行前缀；需要另有完整动作归属才能认证整条候选。'),
    ('49632bc4878fb597', '力量、敏捷、虚弱与蚌成长',
     'CA5KE8GFJ9X2 F13 T1—T5；states 273237/273252/273263、273257/273268。',
     '敌力0/4/8，同招来袭11/15/19；虚弱后11/14。只能分别确认已见属性和成长端点。',
     '本场没有正敏捷实测；计划中的步法没有取得，不能用该场补正敏捷样本，也不能把虚弱当成取消后续成长。',
     '缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长四路径的联合校准；本局无正敏捷实测，不增加统一保血/输出权重。',
     '保留当前属性与成长的分项计算；每击修正、每牌格挡和独立成长分别验证，不把单个步法提交视为整项完成。',
     '保存当前进阶敌人HP/伤害/移动表、完整手牌和实际前缀，逐步对比四路径；正敏捷需要本角色另有真实证据，不补预训练数值。'),
    ('66532328a585941f', '持有、启动与持续输出兑现',
     '5PM6JAQG6FNQ F39末试T2；states 274379/274380、decision 268455；F33为条件不同的反例窗口。',
     '向无毒THE_LOST打冒泡，能量5→4、目标HP35→35、毒0→0；该局部事实不提供完整启动顺序收益函数。',
     'F33已建立组件并赢，与末试F39敌人、生存条件和抽序不同；不能从持有组件或单次空打拟合固定启动阈值。',
     '缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；无毒冒泡局部无效不足制定构筑或启动权重。',
     '组件持有、计划与本战已建立分账，保留原构筑/启动规则；不将预期持续输出当作已经兑现。',
     '冻结同一起始资源和完整抽序，按run_id分组比较不同启动顺序的整战状态及输出；当前历史窗口只作发现和回归。'),
    ('43a76a31ba7bdcfa', '族母吸取、负敏捷、毒与SL',
     '61E2QS63Y9WU F17 T5—T7；states 273504/273508。',
     'T6玩家敏捷-2、两防御各3，敌HP67→34，对应已记录17+16毒结算；负敏捷与毒分别记账。',
     '本场首试胜利不是同盘SL对照；不能把别局重打失败直接归因固定顺序，也不能把毒端点推为某个SL阈值。',
     '缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利和负敏捷/毒端点不足改变SL范围或阈值。',
     '保留吸取、负敏捷和毒的分项事实及现有SL规则，不推固定换线偏好。',
     '冻结完整移动表、牌组、状态和抽序，分别核属性变化、直接伤害与每次毒结算；SL取舍另需完整同盘对照。'),
    ('5264153a4a4b0e5c', '胧光召唤、成长与目标顺序',
     '61E2QS63Y9WU F23 T2—T6，重点T4；states 273589、273593/273596。',
     'T4本体/幻象HP76/14→41/2，玩家25→10；两次航行后的敌力3→6可核。幻象尚2HP，不把本体扣血等同减员。',
     '另一focus候选39伤/零损没有实打，不能当整战胜线；T5退场与后续复现仍需按实体代际核对。',
     '缺A10召唤、航行成长、退场和复现全链的冻结生产校准与另一focus完整后继；已有召唤源码和单轮端点不能认证目标排序收益。',
     '复用已有召唤模型并保留全部目标选项，相同推演值并列；不制定固定首杀。',
     '以各实体的出现、成长、死亡与复现原帧验证当前进阶全链，避免按index复用混淆实体；另一个目标顺序只有可核完整后继才作收益比较。'),
    ('bddfa690a84e03d0', '熟睡甲虫唤醒与持续成长',
     'DUZUBAJ3A8GP F30四次相关尝试，重点T1—T6；states 274929/274932/274934。',
     '甲虫力量2→-4→4，来袭20→14→22，分别为暂时减力和后轮恢复/成长的观测端点。',
     '四次尝试属于一局，前三次预测死亡截断不等于实际执行到死亡；末试T4多敌血净扣伴随更多玩家损血，不能只按伤害改排序。',
     '缺伤害唤醒、眩晕接续与A10成长的完整冻结生产校准及同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。',
     '按睡眠、眩晕、暂时减力和成长分别验证，保持原目标选择和终局血价。',
     '冻结睡层下降、失血唤醒、眩晕接续和成长全链输入，区分预测截断与真实结算；同抽换序需保存完整后继，不能将失败重试扩独立分母。'),
]

assert len(DATA) == 10
ASSESS = []
for suffix, title, evidence, observation, counterexample, reason, behavior, validation in DATA:
    key = 'silent-proposal-' + suffix
    original = ASSIGNED[key]
    ASSESS.append({
        'id': key, 'state': 'waiting', 'title': title,
        'runs': original['runs'], 'ledger': original['ledger'], 'domains': original['domains'],
        'evidence': evidence, 'observation': observation, 'counterexample': counterexample,
        'reason': reason, 'expected_behavior': behavior, 'validation': validation,
        'original_proposal': original['proposal'], 'original_sha256': original['proposal_sha256'],
    })
assert [x['id'] for x in ASSESS] == DISPATCH['proposal_ids']
(OUT / 'assessments.json').write_text(json.dumps(ASSESS, ensure_ascii=False, indent=2) + '\n')

proposal = [
    '# 静默猎手策略提案逐项核验\n',
    f'时间：{STAMP}。batch={BATCH}；来源与实现任务均沿各原id保留；角色silent，实核进阶A10。',
    f'base={BASE}。本批只处理派发的十个原id，均为waiting；未新增游戏规则、源码或知识。',
    '六个来源局逐runs.jsonl核角色。原提案逐份校验SHA，副本以原id.md保存在本目录；原文、账本claim、历史支持/反例和状态不改。',
    '本次从原日志共用入口提取并逐行核验6995行。所有具体原行的offset/bytes/SHA及所属局可在evidence/读回；37项原帧事实核验通过，但这不是生产代码测试。',
]
for x in ASSESS:
    proposal += [
        f"\n## {x['id']}：{x['title']}\n",
        f"来源：{ASSIGNED[x['id']]['source_task']}；目标：strategy-proposal；经验链接：{', '.join(ASSIGNED[x['id']].get('experience', [])) or '沿原账本'}。",
        f"账本：{', '.join(x['ledger'])}。证据：{x['evidence']}",
        f"实核范围：{x['observation']}",
        f"反例与限制：{x['counterexample']}",
        f"现有实现及未实现原因：{x['reason']}",
        f"旧规则/预期行为：{x['expected_behavior']}",
        f"后续验证：{x['validation']}",
        '不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。',
        '本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。',
        f"原文：{x['original_proposal']}；SHA256={x['original_sha256']}。结论：waiting。",
    ]
proposal += [
    '\n## 联合机制子项边界\n',
    'ebbfe3b97548756d包含：力量/虚弱与步法（0005）、覆甲（0016）、金刚杵（0049）、口红（0071）、勒紧（0143）、暂时减力（0046）、萎靡（0053）、触媒（0027）、毒雾（0011）、爆发与持续输出（0021）、三骑士时钟（0106）、石炉加湿器（0204）、休息缓冲（0020）、路线血量（0019）；以上编号均为silent-前缀。各子项条件和原经验id以保存原文为准。',
    '当前源码已有部分机制、当前进阶敌人数值及房间代价五样本门槛；本批未重建或调整这些数据。端点、牌面和单一子项源码不替代上述所有组合在同一冻结生产输入中的联合校准。',
    'Roy-2026-10-07-learning是修改权限，不是游戏事实。本批既未提出未授权架构变更，也没有足够新证据修改预算、护栏、药水、SL或终局价值。',
]
(OUT / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
consumer = json.loads((OUT / 'consumer-readback.json').read_text())
facts = json.loads((OUT / 'fact-checks.json').read_text())
assert len(facts) == 37 and all(x['passed'] for x in facts)
assert all(x['same_selected_envelope_sha256'] and x['same_counts'] for x in json.loads((OUT / 'prior-evidence-comparison.json').read_text()))
assert all(x['same_previous_output'] for x in json.loads((OUT / 'consumer-prior-comparison.json').read_text()))
stream_table = '\n'.join(f"| {x['stream']} | {x['source_size']} | {sum(x['counts'].values())} |" for x in manifest)
consumer_table = '\n'.join(f"| {x['run_id']} | {x['actions']} | {x['segments']} | {x['observed_intervals']} | {x['terminal_intervals']} | {x['observed_turn_endpoints']} | {x['unknown_turns']} |" for x in consumer)
results_table = '\n'.join(f"| {x['id']} | waiting | {x['reason']} |" for x in ASSESS)
commits = '\n'.join(f"- {x['commit']}：{x['subject']}；实际live祖先={str(x['live_ancestor']).lower()}。" for x in SOURCE['narrow_source_commits'])
report = f'''# 静默策略批次核验与逐项处置

时间：{STAMP}。task=strategy-proposal；character=silent；batch={BATCH}。

本批十个原提案均保留waiting。六个来源局及当前局部实现可确认原有机制和资源端点，仍不足完成原提案要求的持续执行归属、冻结生产联合校准或受控完整后继；本次没有提出可据实修改的新预算、血价、SL范围、启动或目标顺序。fixes=[]、merged=null；没有源码/知识提交、上线、版本或shipped。

## 派发与基线

开工git status干净，HEAD=main={BASE}；按普通提案流程git merge --no-edit main返回Already up to date。本批learn.json只读对应行，task/character/worktree/runs均匹配，reason=proposal、state=running、十proposal_ids，无research_request、implementation_request或proposal_repair；普通专题根请求绑定另一旧batch，不据其running接管，不读取其他专题替代身份。只处理这十项，不扩选其他队列项目。

已读README、STATE-2026-10-16、decision-log末尾、learning-protocol和learning-code-proposals。独立执行，无下级agent。六个runs均为SILENT/A10：{', '.join(DISPATCH['runs'])}；独立局数6，不以SL次数扩分母。所有对局结论均来自本角色原帧/原提案；没有从其他角色私有知识导入结论。

十份原Markdown存在、角色/局号集合匹配且SHA256与专用队列逐项一致，原文副本及源路径保存在proposal-inputs.json与原id.md。26个关联账本只读折叠快照为ledger-before.json；不将历史广进阶支持数或已shipped经验当本批生产实现成功。

## 原始证据

执行共用learner/extract_evidence.py，选择8流。逐流冻结source_size，选中行保存原offset/bytes/SHA/完整JSON，逐行从只读原logs回读，显式身份再次核对run_id/state.run_id/run/fingerprint.run，6995行全部一致。只取显式所属，不将正文提及当局号；提取器拒收冲突身份。原运行code均带dirty，不以提交号冒还原全部当时源码或知识。

| 流 | 冻结source_size字节 | 选中行 |
|---|---:|---:|
{stream_table}

states/decisions全源各2个无效JSON行，brain全源1行，不据全源计数认定属于本六局；无未完行。fight-plans为0仅说明该截点未选到，不说明原日志缺失。run-plans按显式run读取，选中33行。没有覆盖旧报告或旧零行初稿。

八流选中封套SHA/逐局计数与20261014-211320旧提取相同，虽然各原流截点已有增长；这不构成六个新样本。prior-evidence-comparison.json逐流保存比较，旧报告/原件未改。保存718个相关状态、696个相关决策和29条SL记录投影；37项原帧事实断言通过。原神化参考夹具6帧逐状态匹配，致命毒药夹具6条来源offset/bytes/SHA匹配；现有夹具来源核验不冒作本批Vitest通过。

## 当前离线消费者读回

冻结原决策和状态、保留decision_id/observed_ts/fingerprint/_line，逐局调用当前基线learner/lib/selection-execution.ts；不调LLM、游戏或网络，不读取刷新的知识JSON。consumer-input-manifest.json保存输入原SHA，consumer-readback.json及gzip输出保存真实结果与范围。

| 局 | 有ID动作 | 候选片段 | 相邻动作端点 | 终页端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
{consumer_table}

合计3301个有ID动作、476候选片段、859相邻动作端点、4终页端点、121整轮端点、413未知轮窗口。CA5的267143、61E的267517及DUZU的268789/268818/268864五行缺decision_id，完整输入被现有消费者真实拒收；不伪造ID，只剔除这五行得到有界子集，原行仍完整留在提取和原输入中。其余三局为完整输入接受。

所有actual_full_candidate_result仍为null，是工具的认证边界，不证明没有执行或策略失败。六局当前输出解压字节与旧消费者输出一致，consumer-prior-comparison.json保存SHA；没有把再次计算旧材料当新增学习。8JRE同盘首/第三试T2的整轮玩家-3/-15、敌血-10/-17再次核到；预测死亡0/24与5/24分开，第二试护栏在rationale而非结构hp_guard。整轮端点含重问，不能直接归因某条候选或成长卡。

VLZ F45首问707毫秒/1of12和horizon1/samples1/best=null，与第二问12/12不是同盘预算实验；药水实加能量不回血。5PM无毒冒泡实际耗1能但敌HP/毒不变；61E负敏捷双防御各3及17+16毒端点、胧光T4本体/幻象76/14→41/2、玩家25→10；DUZU减力2→-4→4及来袭20/14/22，均是有范围的原帧事实，不推出未选线整战胜负。

## 当前源码与实际live祖先

只读live快照={SOURCE['live_snapshot']}。本批核23个精确源码叶，18个base/live字节相同；5个差异路径为card-model.ts、rollout-live.ts、potion-mc.ts、move-model.ts及sl/explore.ts，保存完整差异，均为历史Roy/Dai署名注释差。没有覆盖live数据或以相同blob替代提交祖先核验。

当前silent-apotheosis.ts保留已观察的逐牌升级对；card-model.ts限silent/A10绑定，turn-solver.ts仍把重放/自动/属性组合及未知后续抽牌明确标未知。silent-apotheosis-reference.ts的actual_cast_this_fight明确为null；silent-selection-audit.ts保存预测三阶段、actual_turn=null；silent-selection-dispatch.ts只保存单动作回执、whole_plan_executed=null。离线消费者也不认证整候选。这些实际源码边界支撑waiting，而不是单凭旧队列状态延续结论。

八个已有窄源码commit已逐个核为该实际live快照祖先：

{commits}

其中致命毒药升级与单动作回执扩大了局部覆盖，仍不满足持续身份和联合校准。它们不是本批commit、merged或implemented。怪物按当前进阶取数据、房间代价5样本门槛的现有接口未改；本批没有运行依赖刷新的知识或模拟器来补旧dirty输入。23叶的base/live SHA、最近路径commit及祖先结果见source-verification.json。

## 十项结果

| 原id | 处置 | 具体未实现原因 |
|---|---|---|
{results_table}

每项证据局/层/回合、账本、反例、旧/预期行为、验证、回退及原文SHA详见proposal.md和assessments.json。同题原id保留来源，不新增重复id；没有任何项据局部实现冒称implemented/duplicate或shipped。code_proposals填十个既有CLI id，implementation_domains=[]，因为本批无新的实际实现。

## 账本、测试与未变边界

本批只通过根learner/ledger.py update为相关静默条目追加本报告/提案链接及核验说明，by=learner:strategy-proposal，不追加重复support/repeat，不改claim、首证、prior、asc、evidence、status、version或shipped历史。旧proposed保持proposed、旧shipped保持shipped；不为追溯降级历史发布状态。精确输入/CLI输出/物理行和私有折叠读回另存ledger-updates.jsonl、ledger-update.log和ledger-update-readback.json。专用队列处置仅由最终proposal_results交既有调度器，不手写队列或learn.json。

没有源码改动或代码提交，故不做撤源码失败/恢复通过，也没有tsc/Vitest执行；tests固定为tsc=null、vitest=null、cases=null。37项是材料事实核验，不充生产测试的cases，也不借历史绿。没有提交/合入受阻；未启动live合入、知识刷新提交、上线decision-log、eval编号或规则双通知，不制造空合入。

本次保留失败：自写离线调用脚本首版相对import多退一级，模块未找到退出1；原脚本read-consumer.initial.txt和consumer-readback.initial.log保留。改为正确learner/lib路径后同冻结输入调用成功。这是分析脚本路径错误，不是生产bug、源码撤回负控或游戏反证。只读定位中的几个猜测路径不存在，后改用rg定位真实hand/loop与knowledge路径；不据此断言模块或证据缺失。旧失败记录也未改写。

原运行dirty源码/运行知识/移动表与完整随机池未冻结可还原；六局已用于历史发现，非独立后置盲测；端点、单动作回执、候选预测、整轮归因及整战收益分别记录。当前任务文字要求普通/high，允许的shell材料未独立证明本原生会话实际模型/服务档/推理配置，不冒称已切换；未改账号、权限、配置或重开模型。没有新增机制异议、反证或与旧知识冲突，不将未知包装成否定既有经验。

报告与批次处置不关闭Roy学习宽父、不冒称经验入库、大脑采用或消费者自然实盘验证。实际可实现项仍待明确缺口补齐后的既有重派；不扩做其他请求。

交运维提案：{OUT / 'proposal.md'}。
报告：{OUT / 'report.md'}。
最终交付前另存git状态、HEAD、各id集合、原文SHA与gitleaks扫描结果；无源码/知识/index差异，HEAD应保持base。
'''
(OUT / 'report.md').write_text(report)

result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
    'base': BASE, 'runs': DISPATCH['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': DISPATCH['proposal_ids'], 'implementation_domains': [],
    'proposal_results': [{'id': x['id'], 'state': x['state'], 'reason': x['reason']} for x in ASSESS],
    'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

ledger = json.loads((OUT / 'ledger-before.json').read_text())
updates = []
for key in ledger:
    linked = [x for x in ASSESS if key in x['ledger']]
    text = '；'.join(f"{x['id']}：{x['reason']}" for x in linked)
    updates.append({
        'id': key, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')] + [x['id'] for x in linked]},
        'note': f'{BATCH}追溯核验：八流6995原行及37项材料事实与旧证据一致，当前窄源码及消费者边界已核。{text} 本批仅where/note追加，不重复support/repeat，不改原claim/evidence/status/version，不标shipped，无源码或知识改动。',
    })
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'base': BASE, 'proposals': len(ASSESS), 'ledger_updates_prepared': len(updates), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

# 静默策略批次核验与逐项处置

时间：2026-10-16T18:12:50+08:00。task=strategy-proposal；character=silent；batch=20261016-180157-strategy-proposal。

本批十个原提案均保留waiting。六个来源局及当前局部实现可确认原有机制和资源端点，仍不足完成原提案要求的持续执行归属、冻结生产联合校准或受控完整后继；本次没有提出可据实修改的新预算、血价、SL范围、启动或目标顺序。fixes=[]、merged=null；没有源码/知识提交、上线、版本或shipped。

## 派发与基线

开工git status干净，HEAD=main=57e2d6ef443d92d5705098a81526d7c4e936b524；按普通提案流程git merge --no-edit main返回Already up to date。本批learn.json只读对应行，task/character/worktree/runs均匹配，reason=proposal、state=running、十proposal_ids，无research_request、implementation_request或proposal_repair；普通专题根请求绑定另一旧batch，不据其running接管，不读取其他专题替代身份。只处理这十项，不扩选其他队列项目。

已读README、STATE-2026-10-16、decision-log末尾、learning-protocol和learning-code-proposals。独立执行，无下级agent。六个runs均为SILENT/A10：VLZ6CCT8AQ0A, 8JRE1C4H4Z2W, CA5KE8GFJ9X2, 5PM6JAQG6FNQ, 61E2QS63Y9WU, DUZUBAJ3A8GP；独立局数6，不以SL次数扩分母。所有对局结论均来自本角色原帧/原提案；没有从其他角色私有知识导入结论。

十份原Markdown存在、角色/局号集合匹配且SHA256与专用队列逐项一致，原文副本及源路径保存在proposal-inputs.json与原id.md。26个关联账本只读折叠快照为ledger-before.json；不将历史广进阶支持数或已shipped经验当本批生产实现成功。

## 原始证据

执行共用learner/extract_evidence.py，选择8流。逐流冻结source_size，选中行保存原offset/bytes/SHA/完整JSON，逐行从只读原logs回读，显式身份再次核对run_id/state.run_id/run/fingerprint.run，6995行全部一致。只取显式所属，不将正文提及当局号；提取器拒收冲突身份。原运行code均带dirty，不以提交号冒还原全部当时源码或知识。

| 流 | 冻结source_size字节 | 选中行 |
|---|---:|---:|
| states | 13592913771 | 3432 |
| decisions | 2007667243 | 3306 |
| sl-attempts | 43731371 | 29 |
| run-config | 1884063 | 6 |
| run-plans | 8590723 | 33 |
| brain | 681179723 | 183 |
| runs | 351171 | 6 |
| fight-plans | 2233957 | 0 |

states/decisions全源各2个无效JSON行，brain全源1行，不据全源计数认定属于本六局；无未完行。fight-plans为0仅说明该截点未选到，不说明原日志缺失。run-plans按显式run读取，选中33行。没有覆盖旧报告或旧零行初稿。

八流选中封套SHA/逐局计数与20261014-211320旧提取相同，虽然各原流截点已有增长；这不构成六个新样本。prior-evidence-comparison.json逐流保存比较，旧报告/原件未改。保存718个相关状态、696个相关决策和29条SL记录投影；37项原帧事实断言通过。原神化参考夹具6帧逐状态匹配，致命毒药夹具6条来源offset/bytes/SHA匹配；现有夹具来源核验不冒作本批Vitest通过。

## 当前离线消费者读回

冻结原决策和状态、保留decision_id/observed_ts/fingerprint/_line，逐局调用当前基线learner/lib/selection-execution.ts；不调LLM、游戏或网络，不读取刷新的知识JSON。consumer-input-manifest.json保存输入原SHA，consumer-readback.json及gzip输出保存真实结果与范围。

| 局 | 有ID动作 | 候选片段 | 相邻动作端点 | 终页端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |

合计3301个有ID动作、476候选片段、859相邻动作端点、4终页端点、121整轮端点、413未知轮窗口。CA5的267143、61E的267517及DUZU的268789/268818/268864五行缺decision_id，完整输入被现有消费者真实拒收；不伪造ID，只剔除这五行得到有界子集，原行仍完整留在提取和原输入中。其余三局为完整输入接受。

所有actual_full_candidate_result仍为null，是工具的认证边界，不证明没有执行或策略失败。六局当前输出解压字节与旧消费者输出一致，consumer-prior-comparison.json保存SHA；没有把再次计算旧材料当新增学习。8JRE同盘首/第三试T2的整轮玩家-3/-15、敌血-10/-17再次核到；预测死亡0/24与5/24分开，第二试护栏在rationale而非结构hp_guard。整轮端点含重问，不能直接归因某条候选或成长卡。

VLZ F45首问707毫秒/1of12和horizon1/samples1/best=null，与第二问12/12不是同盘预算实验；药水实加能量不回血。5PM无毒冒泡实际耗1能但敌HP/毒不变；61E负敏捷双防御各3及17+16毒端点、胧光T4本体/幻象76/14→41/2、玩家25→10；DUZU减力2→-4→4及来袭20/14/22，均是有范围的原帧事实，不推出未选线整战胜负。

## 当前源码与实际live祖先

只读live快照=a9e687d9f0acccccddbfa92895d7966b58900658。本批核23个精确源码叶，18个base/live字节相同；5个差异路径为card-model.ts、rollout-live.ts、potion-mc.ts、move-model.ts及sl/explore.ts，保存完整差异，均为历史Roy/Dai署名注释差。没有覆盖live数据或以相同blob替代提交祖先核验。

当前silent-apotheosis.ts保留已观察的逐牌升级对；card-model.ts限silent/A10绑定，turn-solver.ts仍把重放/自动/属性组合及未知后续抽牌明确标未知。silent-apotheosis-reference.ts的actual_cast_this_fight明确为null；silent-selection-audit.ts保存预测三阶段、actual_turn=null；silent-selection-dispatch.ts只保存单动作回执、whole_plan_executed=null。离线消费者也不认证整候选。这些实际源码边界支撑waiting，而不是单凭旧队列状态延续结论。

八个已有窄源码commit已逐个核为该实际live快照祖先：

- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：ops: replay checked Silent Apotheosis candidate facts；实际live祖先=true。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：Propagate observed Silent Apotheosis Malaise upgrade；实际live祖先=true。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：Replay tested held-loss candidate facts on current live；实际live祖先=true。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：Integrate repaired legacy learning deltas and bounded continuation adapter；实际live祖先=true。
- cf72bd21148059f111f760cc98a727369e34a47e：Integrate checked offline Silent potion observation tool；实际live祖先=true。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：Propagate observed Silent Deadly Poison upgrade；实际live祖先=true。
- fdaf787a372880b0438e73bcac7e6d2168b038ed：Record Silent candidate dispatch receipts separately from forecasts；实际live祖先=true。
- f516592fff557ef02c8ece43433706358c3f7fe6：Propagate the observed Silent Apotheosis Accelerant upgrade；实际live祖先=true。

其中致命毒药升级与单动作回执扩大了局部覆盖，仍不满足持续身份和联合校准。它们不是本批commit、merged或implemented。怪物按当前进阶取数据、房间代价5样本门槛的现有接口未改；本批没有运行依赖刷新的知识或模拟器来补旧dirty输入。23叶的base/live SHA、最近路径commit及祖先结果见source-verification.json。

## 十项结果

| 原id | 处置 | 具体未实现原因 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水、重问、SL与换战的实际施放持续身份及未覆盖属性组合校准；actual_cast_this_fight仍为null，已有局部升级源码不能关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性/样本成熟度曲线及留药完整后继；不由707毫秒单题修改预算、药价或focus。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化项仍缺实际施放持续身份及未覆盖升级交互校准；保留独立experience-update链，不仅凭同题或窄源码登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五个机制/资源子项的全部属性与升级组合、状态期限，以及战斗/路线/休息消费者在同一冻结知识和移动表下的逐源联合校准；局部模型和端点不足关闭整项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 现有三阶段预测审计、单动作回执和离线端点仍未认证跨抽牌/选牌/重问/药水/SL的完整候选持续归属及成长收益；缺完整执行证据和受控未选线后继，不改护栏或SL血价。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长四路径的联合校准；本局无正敏捷实测，不增加统一保血/输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；无毒冒泡局部无效不足制定构筑或启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利和负敏捷/毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行成长、退场和复现全链的冻结生产校准与另一focus完整后继；已有召唤源码和单轮端点不能认证目标排序收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续与A10成长的完整冻结生产校准及同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。 |

每项证据局/层/回合、账本、反例、旧/预期行为、验证、回退及原文SHA详见proposal.md和assessments.json。同题原id保留来源，不新增重复id；没有任何项据局部实现冒称implemented/duplicate或shipped。code_proposals填十个既有CLI id，implementation_domains=[]，因为本批无新的实际实现。

## 账本、测试与未变边界

本批只通过根learner/ledger.py update为相关静默条目追加本报告/提案链接及核验说明，by=learner:strategy-proposal，不追加重复support/repeat，不改claim、首证、prior、asc、evidence、status、version或shipped历史。旧proposed保持proposed、旧shipped保持shipped；不为追溯降级历史发布状态。精确输入/CLI输出/物理行和私有折叠读回另存ledger-updates.jsonl、ledger-update.log和ledger-update-readback.json。专用队列处置仅由最终proposal_results交既有调度器，不手写队列或learn.json。

没有源码改动或代码提交，故不做撤源码失败/恢复通过，也没有tsc/Vitest执行；tests固定为tsc=null、vitest=null、cases=null。37项是材料事实核验，不充生产测试的cases，也不借历史绿。没有提交/合入受阻；未启动live合入、知识刷新提交、上线decision-log、eval编号或规则双通知，不制造空合入。

本次保留失败：自写离线调用脚本首版相对import多退一级，模块未找到退出1；原脚本read-consumer.initial.txt和consumer-readback.initial.log保留。改为正确learner/lib路径后同冻结输入调用成功。这是分析脚本路径错误，不是生产bug、源码撤回负控或游戏反证。只读定位中的几个猜测路径不存在，后改用rg定位真实hand/loop与knowledge路径；不据此断言模块或证据缺失。旧失败记录也未改写。

原运行dirty源码/运行知识/移动表与完整随机池未冻结可还原；六局已用于历史发现，非独立后置盲测；端点、单动作回执、候选预测、整轮归因及整战收益分别记录。当前任务文字要求普通/high，允许的shell材料未独立证明本原生会话实际模型/服务档/推理配置，不冒称已切换；未改账号、权限、配置或重开模型。没有新增机制异议、反证或与旧知识冲突，不将未知包装成否定既有经验。

报告与批次处置不关闭Roy学习宽父、不冒称经验入库、大脑采用或消费者自然实盘验证。实际可实现项仍待明确缺口补齐后的既有重派；不扩做其他请求。

交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-180157/learner/runs/20261016-180201-dd2d80d2-f1a8-4a6d-b506-67328396f0b7-strategy-proposal/proposal.md。
报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-180157/learner/runs/20261016-180201-dd2d80d2-f1a8-4a6d-b506-67328396f0b7-strategy-proposal/report.md。
最终交付前另存git状态、HEAD、各id集合、原文SHA与gitleaks扫描结果；无源码/知识/index差异，HEAD应保持base。


## 最终交付读回

2026-10-16T18:15:00+08:00：根账本CLI退出0，实际26条只含where/note的追溯更新逐原物理offset/bytes/SHA与输入读回一致，原物理前缀SHA保持；私有fold的claim/evidence/首证/prior/状态/版本/shipped及旧notes/history/where前缀均保持。十个原id与结果集合完全相同，原Markdown源与副本SHA再核一致。HEAD=57e2d6ef443d92d5705098a81526d7c4e936b524、git status为空、工作树和index的binary diff为空；未提交、未合入。第一轮发布材料gitleaks退出0，无泄漏，最终材料扫描另见gitleaks-final.log/json。

# 静默猎手策略提案逐项核验


时间：2026-10-16T18:12:50+08:00。batch=20261016-180157-strategy-proposal；来源与实现任务均沿各原id保留；角色silent，实核进阶A10。

base=57e2d6ef443d92d5705098a81526d7c4e936b524。本批只处理派发的十个原id，均为waiting；未新增游戏规则、源码或知识。

六个来源局逐runs.jsonl核角色。原提案逐份校验SHA，副本以原id.md保存在本目录；原文、账本claim、历史支持/反例和状态不改。

本次从原日志共用入口提取并逐行核验6995行。所有具体原行的offset/bytes/SHA及所属局可在evidence/读回；37项原帧事实核验通过，但这不是生产代码测试。


## silent-proposal-89354805ee4d7e77：神化升级传播与实际施放


来源：postmortem；目标：strategy-proposal；经验链接：沿原账本。

账本：silent-0237, silent-0238。证据：VLZ6CCT8AQ0A F35 T1、F43 T1—T5、F45 T1—T5；states 275564/275565、275679/275680/275687、275728/275729；decisions 269748。

实核范围：F35神化前后能量7→5，防御5→8、打击7→10、匕首雨逐段5→7、必备工具1费→0；F43后续抽到升级毒雾。已证同线及后续已知抽牌的局部传播，不是整战收益。

反例与限制：F43施放后仍有大量损血，F45持有却未施放；跨战斗资源和敌人不同，不能据胜负制定必打规则。

现有实现及未实现原因：缺跨抽牌、选牌、药水、重问、SL与换战的实际施放持续身份及未覆盖属性组合校准；actual_cast_this_fight仍为null，已有局部升级源码不能关闭整项。

旧规则/预期行为：保留已观察升级的状态变换；持有、计划施放、模拟生效、实际施放分列，未知交互保持未知，不加神化固定优先级。

后续验证：以F35/F43/F45原帧建立同一战斗/尝试的持续动作证据，逐次核已施放、已升级与未知覆盖；保留重问、换战及SL边界。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。结论：waiting。


## silent-proposal-f2bfceddb1898dca：三骑士药水预算与全败候选


来源：postmortem；目标：strategy-proposal；经验链接：沿原账本。

账本：silent-0106, silent-0019, silent-0201。证据：VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；decisions 269748、269754、269770；states 275728/275729、275754。

实核范围：F45首题随机药水MC=707毫秒、1/12样本，rollout horizon=1/samples=1/best=null；实际药水能量1→2、HP67不变。末轮32血20挡、显示合计来袭59。

反例与限制：第二题有12/12样本但已不是同一盘面；T4少损线实打与未选攻击线只构成预测比较，不是留药或目标顺序的整战对照。

现有实现及未实现原因：缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性/样本成熟度曲线及留药完整后继；不由707毫秒单题修改预算、药价或focus。

旧规则/预期行为：保留现有预算、留药与目标选择规则；将模拟成熟度、当轮血价、实际药水效果和敌人剩血分别展示，相同推演结果并列。

后续验证：冻结完整生产输入和随机池，先排除模型缺覆盖，再比较相同总预算的现规则与分阶段MC；需保存原始用时、样本和完整后继，不能把同题之外的重问当配对。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。结论：waiting。


## silent-proposal-283a164780d11e69：神化经验来源补链


来源：experience-update；目标：strategy-proposal；经验链接：silent-apotheosis-combat-upgrades。

账本：silent-0237, silent-0238。证据：VLZ6CCT8AQ0A F35/F43/F45；与89354805ee4d7e77同源，保留experience-update及silent-apotheosis-combat-upgrades链。

实核范围：原提案Markdown与登记SHA一致；本次同一局的四次施放不扩成四个独立样本，局部升级传播已存在。

反例与限制：同题的两个来源请求不构成新增独立证据；已有局部源码也不等于原完整请求已实现。

现有实现及未实现原因：同源神化项仍缺实际施放持续身份及未覆盖升级交互校准；保留独立experience-update链，不仅凭同题或窄源码登记duplicate。

旧规则/预期行为：沿原id及原经验链接复用专属升级实现；不再创建重复id，不修改原经验或提案正文。

后续验证：沿89354805ee4d7e77的持续施放/升级边界核验，并保存两个来源任务的真实链接及实际live源码证明。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。结论：waiting。


## silent-proposal-ebbfe3b97548756d：十五项攻防机制与资源联合校准


来源：experience-update；目标：strategy-proposal；经验链接：silent-strength-weak-observation, silent-footwork-block, silent-gorget-plating, silent-vajra-opening-strength, silent-sparkling-rouge-turn-three, silent-fasten-defend-extra-block, silent-piercing-wail-temporary-strength, silent-malaise-x-debuff, silent-accelerant-triggers, silent-noxious-fumes-growth, silent-deck-burst-observation, silent-three-knights-output-buffer-observation, silent-stone-humidifier-rest-growth, silent-rest-buffer-observation, silent-route-hp-observation。

账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。证据：VLZ6CCT8AQ0A F43 T1—T5、F44、F45 T1/T3/T5；states 275679/275680、275748/275754；原十五子项及账本见原Markdown。

实核范围：可核升级前后牌面、后续毒雾、末轮现场覆甲0、32HP/20挡与合计59来袭；牌面、当前属性、暂时减力、毒和休息资源必须各自记账。

反例与限制：本局已施放神化的胜场仍可能大幅损血；单轮减力和开场覆甲不能自动当成后续固定资源。原十五子项的历史支持数不是十五种组合的本批分母。

现有实现及未实现原因：缺十五个机制/资源子项的全部属性与升级组合、状态期限，以及战斗/路线/休息消费者在同一冻结知识和移动表下的逐源联合校准；局部模型和端点不足关闭整项。

旧规则/预期行为：保持各来源机制及消费者现状；只对未来实际证明的模型缺口补状态变换，不增加统一保血、输出、休息或路线权重。

后续验证：逐子项固定手牌、属性、当前进阶敌人数据、移动表与消费者输入，分开核单轮结算、持续资源、即时回血与路线投影；神化沿专项复用。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。结论：waiting。


## silent-proposal-e5b87be50f28f311：SL与护栏替换的实际代价审计


来源：postmortem；目标：strategy-proposal；经验链接：沿原账本。

账本：silent-0079, silent-0021, silent-0125, silent-0018。证据：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11及F17 T6；decisions 270216/270282、270264。

实核范围：首/第三试T2指纹逐字相同；SL预测死亡0/24与5/24，实际整轮玩家-3/-15、敌血-10/-17，即多12血价与多7敌血净扣。270264护栏记在rationale，不能按结构字段缺失认作未发生。

反例与限制：六次尝试来自一局；原线没有受控胜局。第二试T5及F17抽牌后重问，整轮端点不全归初始候选，末试更长存活也不能证明统一防御优先。

现有实现及未实现原因：现有三阶段预测审计、单动作回执和离线端点仍未认证跨抽牌/选牌/重问/药水/SL的完整候选持续归属及成长收益；缺完整执行证据和受控未选线后继，不改护栏或SL血价。

旧规则/预期行为：原答、护栏后、SL后、首次派发与实际观测分列；completed只作为一次接口回执，重规划边界保留，不把预测差额登记成实际收益。

后续验证：固定首/三试T2、第二试T5及末试T11，核原指纹、尝试、卡牌和实体身份、每次重问与执行前缀；需要另有完整动作归属才能认证整条候选。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。结论：waiting。


## silent-proposal-49632bc4878fb597：力量、敏捷、虚弱与蚌成长


来源：experience-update；目标：strategy-proposal；经验链接：silent-strength-weak-observation。

账本：silent-0005, silent-0231。证据：CA5KE8GFJ9X2 F13 T1—T5；states 273237/273252/273263、273257/273268。

实核范围：敌力0/4/8，同招来袭11/15/19；虚弱后11/14。只能分别确认已见属性和成长端点。

反例与限制：本场没有正敏捷实测；计划中的步法没有取得，不能用该场补正敏捷样本，也不能把虚弱当成取消后续成长。

现有实现及未实现原因：缺同一冻结生产调用中逐击力量、正负敏捷、虚弱和蚌独立成长四路径的联合校准；本局无正敏捷实测，不增加统一保血/输出权重。

旧规则/预期行为：保留当前属性与成长的分项计算；每击修正、每牌格挡和独立成长分别验证，不把单个步法提交视为整项完成。

后续验证：保存当前进阶敌人HP/伤害/移动表、完整手牌和实际前缀，逐步对比四路径；正敏捷需要本角色另有真实证据，不补预训练数值。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。结论：waiting。


## silent-proposal-66532328a585941f：持有、启动与持续输出兑现


来源：experience-update；目标：strategy-proposal；经验链接：silent-deck-burst-observation。

账本：silent-0021, silent-0009。证据：5PM6JAQG6FNQ F39末试T2；states 274379/274380、decision 268455；F33为条件不同的反例窗口。

实核范围：向无毒THE_LOST打冒泡，能量5→4、目标HP35→35、毒0→0；该局部事实不提供完整启动顺序收益函数。

反例与限制：F33已建立组件并赢，与末试F39敌人、生存条件和抽序不同；不能从持有组件或单次空打拟合固定启动阈值。

现有实现及未实现原因：缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整战比较及可复现收益函数；无毒冒泡局部无效不足制定构筑或启动权重。

旧规则/预期行为：组件持有、计划与本战已建立分账，保留原构筑/启动规则；不将预期持续输出当作已经兑现。

后续验证：冻结同一起始资源和完整抽序，按run_id分组比较不同启动顺序的整战状态及输出；当前历史窗口只作发现和回归。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。结论：waiting。


## silent-proposal-43a76a31ba7bdcfa：族母吸取、负敏捷、毒与SL


来源：experience-update；目标：strategy-proposal；经验链接：silent-lagavulin-siphon-poison-sl。

账本：silent-0030, silent-0027。证据：61E2QS63Y9WU F17 T5—T7；states 273504/273508。

实核范围：T6玩家敏捷-2、两防御各3，敌HP67→34，对应已记录17+16毒结算；负敏捷与毒分别记账。

反例与限制：本场首试胜利不是同盘SL对照；不能把别局重打失败直接归因固定顺序，也不能把毒端点推为某个SL阈值。

现有实现及未实现原因：缺A10同起始HP/构筑/完整抽序的SL整战配对及另一条已核完整后继；首试胜利和负敏捷/毒端点不足改变SL范围或阈值。

旧规则/预期行为：保留吸取、负敏捷和毒的分项事实及现有SL规则，不推固定换线偏好。

后续验证：冻结完整移动表、牌组、状态和抽序，分别核属性变化、直接伤害与每次毒结算；SL取舍另需完整同盘对照。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。结论：waiting。


## silent-proposal-5264153a4a4b0e5c：胧光召唤、成长与目标顺序


来源：experience-update；目标：strategy-proposal；经验链接：silent-obscura-summon-growth。

账本：silent-0039, silent-0209。证据：61E2QS63Y9WU F23 T2—T6，重点T4；states 273589、273593/273596。

实核范围：T4本体/幻象HP76/14→41/2，玩家25→10；两次航行后的敌力3→6可核。幻象尚2HP，不把本体扣血等同减员。

反例与限制：另一focus候选39伤/零损没有实打，不能当整战胜线；T5退场与后续复现仍需按实体代际核对。

现有实现及未实现原因：缺A10召唤、航行成长、退场和复现全链的冻结生产校准与另一focus完整后继；已有召唤源码和单轮端点不能认证目标排序收益。

旧规则/预期行为：复用已有召唤模型并保留全部目标选项，相同推演值并列；不制定固定首杀。

后续验证：以各实体的出现、成长、死亡与复现原帧验证当前进阶全链，避免按index复用混淆实体；另一个目标顺序只有可核完整后继才作收益比较。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。结论：waiting。


## silent-proposal-bddfa690a84e03d0：熟睡甲虫唤醒与持续成长


来源：experience-update；目标：strategy-proposal；经验链接：silent-slumbering-beetle-wake-growth。

账本：silent-0128, silent-0079。证据：DUZUBAJ3A8GP F30四次相关尝试，重点T1—T6；states 274929/274932/274934。

实核范围：甲虫力量2→-4→4，来袭20→14→22，分别为暂时减力和后轮恢复/成长的观测端点。

反例与限制：四次尝试属于一局，前三次预测死亡截断不等于实际执行到死亡；末试T4多敌血净扣伴随更多玩家损血，不能只按伤害改排序。

现有实现及未实现原因：缺伤害唤醒、眩晕接续与A10成长的完整冻结生产校准及同抽换序后继；四次相关失败不能拟合新的输出血价或固定杀序。

旧规则/预期行为：按睡眠、眩晕、暂时减力和成长分别验证，保持原目标选择和终局血价。

后续验证：冻结睡层下降、失血唤醒、眩晕接续和成长全链输入，区分预测截断与真实结算；同抽换序需保存完整后继，不能将失败重试扩独立分母。

不拟合新常数；这些旧局已经用于发现，不能称盲测。新规则若要验证泛化，须按独立run_id和时间后移切分，不用SL次数增加样本数。

本批没有新代码可撤回。后续若按证据实现，必须固定输入、撤源码失败/恢复通过、沙箱检查和实际live祖先核验；回退相应真实源码提交，保留原日志、提案和账本。

原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。结论：waiting。


## 联合机制子项边界


ebbfe3b97548756d包含：力量/虚弱与步法（0005）、覆甲（0016）、金刚杵（0049）、口红（0071）、勒紧（0143）、暂时减力（0046）、萎靡（0053）、触媒（0027）、毒雾（0011）、爆发与持续输出（0021）、三骑士时钟（0106）、石炉加湿器（0204）、休息缓冲（0020）、路线血量（0019）；以上编号均为silent-前缀。各子项条件和原经验id以保存原文为准。

当前源码已有部分机制、当前进阶敌人数值及房间代价五样本门槛；本批未重建或调整这些数据。端点、牌面和单一子项源码不替代上述所有组合在同一冻结生产输入中的联合校准。

Roy-2026-10-07-learning是修改权限，不是游戏事实。本批既未提出未授权架构变更，也没有足够新证据修改预算、护栏、药水、SL或终局价值。

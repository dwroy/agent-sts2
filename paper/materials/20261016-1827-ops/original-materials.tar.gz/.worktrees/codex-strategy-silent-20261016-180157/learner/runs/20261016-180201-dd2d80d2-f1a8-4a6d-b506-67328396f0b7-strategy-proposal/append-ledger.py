import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PATH = ROOT / 'paper/materials/learning/ledger.jsonl'
PREPARED = [json.loads(line) for line in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
IDS = {x['id'] for x in PREPARED}
MARKER = '20261016-180157-strategy-proposal追溯核验：'

spec = importlib.util.spec_from_file_location('strategy_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)

with PATH.open('rb') as handle:
    prefix = handle.read()
before_rows = []
for line_number, raw in enumerate(prefix.splitlines(), 1):
    row = json.loads(raw)
    if row.get('id') in IDS:
        assert not row.get('note', '').startswith(MARKER), '本批追溯已经登记，禁止重复CLI'
        before_rows.append((line_number, row))
before = ledger.fold(before_rows)
assert set(before) == IDS and all(x['character'] == 'silent' for x in before.values())
prefix_meta = {'source': str(PATH), 'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest()}
(OUT / 'ledger-prefix-before-cli.json').write_text(json.dumps(prefix_meta, indent=2) + '\n')

print(subprocess.check_output(['date', '-Is'], text=True).strip(), flush=True)
command = [sys.executable, '-B', str(ROOT / 'learner/ledger.py'), 'update']
completed = subprocess.run(command, input=(OUT / 'ledger-updates.jsonl').read_bytes(), capture_output=True)
(OUT / 'ledger-update.log').write_bytes(completed.stdout + completed.stderr)
assert completed.returncode == 0, f'账本CLI失败：{completed.returncode}'
assert set(completed.stdout.decode().split()) == IDS

with PATH.open('rb') as handle:
    assert hashlib.sha256(handle.read(len(prefix))).hexdigest() == prefix_meta['sha256']
    tail = handle.read()
own = []
refs = []
offset = len(prefix)
for raw in tail.splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('id') in IDS and row.get('note', '').startswith(MARKER):
        own.append((row, raw))
        refs.append({'id': row['id'], 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    offset += len(raw)
assert len(own) == len(PREPARED) and {x['id'] for x, _ in own} == IDS
expected = {x['id']: x for x in PREPARED}
private = copy.deepcopy(before)
for row, raw in own:
    assert set(row) == set(expected[row['id']]) | {'op', 'ts'}
    assert row['op'] == 'update'
    assert all(row[key] == value for key, value in expected[row['id']].items())
    ledger.apply(private, row)
fixed = ['claim', 'evidence', 'first_run', 'prior', 'prior_note', 'asc', 'status', 'version', 'shipped_at', 'effect']
for key in IDS:
    assert all(before[key].get(field) == private[key].get(field) for field in fixed)
    assert private[key]['notes'][:-1] == before[key]['notes']
    assert private[key]['history'][:-1] == before[key]['history']
    assert all(private[key]['where'][where][:len(items)] == items for where, items in before[key]['where'].items())
(OUT / 'ledger-appended-rows.jsonl').write_bytes(b''.join(raw for _, raw in own))
readback = {
    'cli_exit_code': completed.returncode, 'verified_rows': len(own), 'prefix_preserved': True,
    'append_fields': ['where', 'note'], 'by': 'learner:strategy-proposal',
    'original_claim_evidence_status_version_preserved_in_private_fold': True,
    'notes_history_where_prefixes_preserved': True, 'physical_rows': refs,
}
(OUT / 'ledger-update-readback.json').write_text(json.dumps(readback, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit_code': completed.returncode, 'verified_rows': len(own), 'prefix_preserved': True}, ensure_ascii=False))

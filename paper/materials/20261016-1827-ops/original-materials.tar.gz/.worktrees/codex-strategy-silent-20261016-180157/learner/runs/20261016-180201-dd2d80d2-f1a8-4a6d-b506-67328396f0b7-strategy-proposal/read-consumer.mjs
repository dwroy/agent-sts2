import { readFileSync, writeFileSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { auditSelectionExecution } from '../../lib/selection-execution.ts';

const scratch = dirname(fileURLToPath(import.meta.url));
const inputs = JSON.parse(readFileSync(resolve(scratch, 'consumer-input-manifest.json'), 'utf8'));
const summaries = [];
for (const item of inputs) {
  const input = JSON.parse(gunzipSync(readFileSync(item.path)).toString('utf8'));
  let fullError = null;
  let audit = null;
  let scope = 'full';
  try { audit = auditSelectionExecution(input); }
  catch (error) { fullError = String(error); }
  if (fullError) {
    scope = 'existing_decision_ids_only';
    input.decisions = input.decisions.filter((row) => row.decision_id);
    audit = auditSelectionExecution(input);
  }
  const actions = audit.observed_actions;
  const bytes = gzipSync(JSON.stringify(audit));
  const path = resolve(scratch, `${item.run_id}.consumer-output.json.gz`);
  writeFileSync(path, bytes);
  summaries.push({
    run_id: item.run_id, scope, full_error: fullError, excluded_lines: item.missing_decision_id_lines,
    actions: actions.length, segments: audit.segments.length,
    observed_intervals: actions.filter((x) => x.observed_interval.status === 'observed_endpoints').length,
    terminal_intervals: actions.filter((x) => x.terminal_observation?.status === 'observed_terminal_endpoints').length,
    observed_turn_endpoints: audit.observed_turns.filter((x) => x.status === 'observed_turn_endpoints').length,
    unknown_turns: audit.observed_turns.filter((x) => x.status === 'unknown').length,
    certified_full_candidates: audit.segments.filter((x) => x.actual_full_candidate_result !== null).length,
    output: path, output_sha256: createHash('sha256').update(bytes).digest('hex'),
  });
}
writeFileSync(resolve(scratch, 'consumer-readback.json'), JSON.stringify(summaries, null, 2) + '\n');
process.stdout.write(JSON.stringify(summaries, null, 2) + '\n');

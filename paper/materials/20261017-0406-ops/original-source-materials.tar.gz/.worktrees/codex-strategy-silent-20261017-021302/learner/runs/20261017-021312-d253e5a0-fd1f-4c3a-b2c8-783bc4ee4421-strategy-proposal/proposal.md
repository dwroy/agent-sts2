# 单动作沙坑截止事实接线

本批：20261017-021302-strategy-proposal；角色：silent；实施范围：已观察 A10。基线：da15f934556e33c01b4cdf00e8bf144a0ddc681c。派发为普通 tick，无 proposal_ids/proposal_repair、research_request 或 implementation_request。普通专题请求仍绑定另一历史批次，不承接、不修改。main 合并结果为 Already up to date。

沿既有 silent-0308（首证 CNKR125PFHJ5）及机制账本 silent-0018 实施，不新建重复提案 ID。原代码提案 silent-proposal-3707a98930a03d83，原 Markdown SHA256=761450420c4fa913c2c5c3a16e055708847446b1a19e030a760dd7fab4cbdb05，保留原文；旧链 silent-proposal-0ff91bb5da98a252 不重写。来源任务 postmortem；本次实现任务 strategy-proposal。授权 Roy-2026-10-07-learning；授权不构成游戏事实。

## 证据与反例

本批十局已在 runs.jsonl 核实均为 SILENT A10。共用 extract_evidence.py 提取八流，各流 source_size、逐行 offset/bytes/SHA、各局计数和输出 SHA 保存在 evidence/evidence-manifest.json。所选帧另逐原文件 seek 回读核 SHA；不把正文提及当所属局。

- 0YQJ9D1MC4NK，F33T7，decisions 原行412490—412494：五道 combat/play 的 end_turn.lethal 均为 false。states 原行426127—426131与五题同 fingerprint 逐一绑定；五帧沙坑均1，攻击与已计伤害后HP仍为正数。
- 最后一题 d412494 / s426131：玩家50HP、11挡、0能量；敌192HP、45毒、沙坑1，当前攻击21。旧 incoming_damage=10、hp_after_enemy_turn=40、lethal=false；s426132实际玩家0HP、敌147HP，本局未重打。正数40只来自该伤害估计，不是完整回合存活。
- 同局 F33T3：s426106→426107，实际逃离后沙坑3→4；F33T5 s426118→426119，逃离后2→3。不能将当前结束致死扩为所有当前动作致死，也不等于延长就能赢。
- 同局 F33T5 s426116（沙坑2）、s426119（沙坑3）及 T1 s426096（无沙坑）为非截止原帧控制。未知保护、敌人可能先被毒等结算终结，仅作合成边界检查，不能称为新增实盘机制证据。
- 原帧最后仍有可用毒药水；未实际饮用，不知道它在这个窗口的整场收益。判官因仍有药水而拒绝“无其他办法”的SL结论，原判断必须保持。

## 旧行为与新行为

旧单动作入口只合 mod 致死标记与已计伤害，正血量会被当作完整敌方回合后的HP。整回合求解与判官已有独立沙坑事实，但没有传到这个回退入口。

本次只在 Silent A10、活着的 THE_INSATIABLE 存在沙坑1时投影现有保守判官的“现在结束”结论。判官复用全部原有保护、复活、特殊阶段、敌人提前终结等拒绝条件；仅在这些检查完成后，允许单独评估结束选项，不要求手上已无牌药。原 judgeEndTurn 入口沿原分支，未改变SL资格。

已确定致死时 end_turn 的完整结局HP=0、lethal=true，同时独立显示 hp_after_counted_damage（本例40）；未知时完整结局HP=null、lethal=null、给出拒绝原因。题面明确这是当前结束选项，不是所有选择必死。药水/卡牌/结束选项集合、参考分数、默认回退、resolver和强制逻辑保持原路径；不额外强喝药、不强制SL、不推断提前用药或另一整线能赢。其他角色与未观察进阶保持原行为。

## 样本、拟合与限制

不拟合权重或新阈值；五道题是同局同回合的五个状态，不作为五个独立胜负样本。既有早期首证保留，本局作为后期复现及固定验证。没有独立留出整局收益、真实模型答选或后续live消费者验收，不能将固定题通过解释为胜率提高。完整 dirty 历史知识树未冻结，不宣称还原原运行树。

## 验证与回退

固定夹具保留九个原帧及 provenance，五个题前帧、一个终局帧、三个非截止控制；测试隔离生成知识，不联网或调用模型。验证原题40与实际0分账、选项和逐项动作映射保持、原SL继续拒绝、未知保护与可能终结边界、其他角色/未观察进阶等价、非strict模式不强喝药。源码撤回必须失败，恢复后通过；原始结果另存本目录。先前夹具投影漏 state_version 的失败及路径设置错误保留，不冒称产品失败。

代码提交前按原入口完成 sandbox 的 tsc/Vitest 和 gitleaks；实际合live后才登记implemented及发布记录，由ops核号与shipped。若原知识刷新与本分支路径冲突，不覆盖刷新数据。回退为精确撤回本源码提交；不回退其他并行发布、知识或原日志。完整结果与提交/版本见 report.md。

import json,collections,datetime,subprocess
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/(n+'.jsonl')).open()]
ds=load('decisions');ss=load('states');r=json.load((p/'BGRC1SURKBJY-resources.json').open());bs=load('brain')
# Match the legacy reasoning stream by its timestamp, without loading the source.
start,end=ds[0]['ts'],ds[-1]['ts'];n=0
with Path('/home/dw/Projects/agent-sts2/logs/deepseek-reasoning.jsonl').open() as src,(p/'deepseek-reasoning.jsonl').open('w') as dest:
 for lineno,l in enumerate(src,1):
  try:d=json.loads(l)
  except ValueError:continue
  if start <= d.get('ts','') <= end:
   d['_line']=lineno;dest.write(json.dumps(d,ensure_ascii=False)+'\n');n+=1
print('legacy reasoning in window',n)
print('best',collections.Counter(str(d.get('rollout_best_chosen')) for d in ds if d['label'].startswith('combat/plan-choice')))
print('combat primary labels',collections.Counter(d['label'] for d in ds if d['decider']=='code' and d['label'].startswith('combat/') and d['label']!='combat/plan-continue'))
print('HP guard / overrides')
for d in ds:
 if 'guard' in json.dumps(d.get('selection_audit',{})).lower() or any(k in (d.get('rationale') or '').lower() for k in ['guard','overrid','replac']):
  print(d['_line'],d['floor'],d['turn'],d.get('sl_attempt'),d['rationale'],json.dumps(d.get('selection_audit'),ensure_ascii=False))
print('potions actions')
for d in ds:
 if (d.get('chosen') or {}).get('action') in ['use_potion','discard_potion','buy_potion']:
  print(d['_line'],d['floor'],d['turn'],d.get('sl_attempt'),d['chosen'],d['rationale'],d.get('result'))
print('brain',collections.Counter((d['engine'],d.get('model'),d.get('effort'),d.get('accepted')) for d in bs))
print('usage', {k:sum((d.get('usage') or {}).get(k,0) or 0 for d in bs) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']},'latency',sum(d.get('latency_ms',0) for d in bs))
print('decision usage',{k:sum((d.get('usage') or {}).get(k,0) or 0 for d in ds) for k in ['input_tokens','output_tokens']})
with (p/'combat-summary.txt').open('w') as f:
 for c in r['combats']:
  f.write(f"\n#{c['sequence']} F{c['floor']} {c['enemies']}\n")
  rows=[s for s in ss if c['entry']['line']<=s['_line']<=(c['exit'] or c['last'])['line']]
  ts=collections.OrderedDict()
  for s in rows:
   if s['state'].get('turn') is not None:ts.setdefault(s['state']['turn'],[]).append(s)
  for turn,rs in ts.items():
   a=rs[0]['state'];z=rs[-1]['state'];zz=(z.get('combat') or {})
   nxt=rows[rows.index(rs[-1])+1] if rows.index(rs[-1])+1<len(rows) else None
   after=nxt['state'] if nxt else z
   combat=a.get('combat') or {}; en=combat.get('enemies') or []
   f.write(f"T{turn} s{rs[0]['_line']}->{rs[-1]['_line']} HP {a['run']['current_hp']}->{after['run']['current_hp']} 敵初{[(e.get('name'),e.get('enemy_id'),e.get('current_hp')) for e in en]} 末{[(e.get('name'),e.get('current_hp')) for e in zz.get('enemies',[])]}\n")
   f.write('末前 '+json.dumps({k:(rs[-2] if z.get('screen')=='GAME_OVER' and len(rs)>1 else rs[-1])['state'].get('combat',{}).get(k) for k in ['player','enemies','hand']},ensure_ascii=False)+'\n')
print('summary saved')

#!/bin/bash
set -euo pipefail
cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'

### 勘误（2026-10-16 04:59:55 CST，learner）

“六条缺值为单药饮用后重问”改为：rollout_best_chosen缺值的6题是1次饮药（d405218）、4次施牌选线（d405219／405224／405371／405656）及1次结束选线（d405225），不能据缺值推断其原因；168/177＝94.92%、168/183＝91.80%及缺值6题的计数不变。
EOF

import json, subprocess
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261016-044305-02e02d4e-7627-48e9-8dc0-0a0e1fb7f1b5-postmortem'
run='BGRC1SURKBJY'
for name in ['runs','decisions','run-plans','sl-attempts','run-config','brain','states']:
    src=root/'logs'/f'{name}.jsonl'
    if not src.exists():
        print(name,'missing',flush=True); continue
    n=0
    with (out/f'{name}.jsonl').open('w') as dest:
        proc=subprocess.Popen(['rg','-n','-b','-F',run,str(src)],stdout=subprocess.PIPE)
        for raw in proc.stdout:
            lineno,offset,payload=raw.split(b':',2)
            obj=json.loads(payload)
            obj['_line']=int(lineno);obj['_offset']=int(offset)
            dest.write(json.dumps(obj,ensure_ascii=False)+'\n');n+=1
        proc.wait()
    print(name,n,flush=True)

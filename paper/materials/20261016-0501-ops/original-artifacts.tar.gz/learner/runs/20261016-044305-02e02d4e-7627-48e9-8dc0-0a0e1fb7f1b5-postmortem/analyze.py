import json,collections
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/(n+'.jsonl')).open()]
ds=load('decisions'); ss=load('states');bs=load('brain')
with (p/'decision-summary.txt').open('w') as f:
 for d in ds:
  f.write(f"d{d['_line']} {d['ts']} F{d['floor']}T{d['turn']} a{d.get('sl_attempt')} {d['decider']} {d['label']} {json.dumps(d.get('chosen'),ensure_ascii=False)}\n{d.get('rationale')}\n")
print('decision range',ds[0]['ts'],ds[-1]['ts'],'deciders',collections.Counter(d['decider'] for d in ds))
print('low',[(d['_line'],d['floor'],d['turn'],d['label'],d['confidence']) for d in ds if d['decider']=='jev' and isinstance(d.get('confidence'),(float,int)) and d['confidence']<.35])
for name in ['brain','sl-attempts','run-plans']:
 rows=load(name);print(name,'keys',list(rows[0]))
 if name=='sl-attempts':
  for d in rows: print({k:d.get(k) for k in ['_line','floor','attempt','started_at','ended_at','result','reason','hp','turn','reloaded']})
print('last states')
for d in ss[-5:]:
 s=d['state']; c=s.get('combat') or {};r=s.get('run') or {}
 print(d['_line'],d['ts'],s.get('screen'),s.get('turn'),r.get('current_hp'), 'player',c.get('player'), 'enemies', [{k:e.get(k) for k in ['name','enemy_id','current_hp','max_hp','block','intent','powers']} for e in c.get('enemies',[])], 'hand',[(x.get('name'),x.get('card_id'),x.get('resolved_rules_text')) for x in c.get('hand',[])])
print('last decision extras', {k:v for k,v in ds[-2].items() if k not in ['questions','fingerprint']})
print('first brain usage', {k:bs[0].get(k) for k in ['ts','engine','model','usage','latency_ms','accepted','label']})

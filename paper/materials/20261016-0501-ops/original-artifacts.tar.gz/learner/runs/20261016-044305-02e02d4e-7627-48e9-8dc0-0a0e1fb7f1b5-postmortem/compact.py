import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/(n+'.jsonl')).open()]
ss=load('states');ds=load('decisions');bs=load('brain');r=json.load((p/'BGRC1SURKBJY-resources.json').open());idx={x['_line']:x for x in ss}
print('turn arrays (需/可见扣下界/我方净损)')
for c in r['combats']:
 ts=c['enemy_hp_audit']['turns'];hp=[]
 for t in ts:
  a=idx[t['start_line']]['state']['run']['current_hp'];z=idx[t['end_line']]['state']['run']['current_hp'];hp.append(a-z)
 print(c['floor'],c['sequence'],'/'.join(str(t['live_enemy_hp_start']) for t in ts),'|','/'.join(str(t['visible_enemy_hp_loss_lower_bound']) for t in ts),'|','/'.join(map(str,hp)))
print('boss snapshots turn-start')
for c in r['combats'][-4:]:
 print('attempt',c['sequence']-18)
 for t in c['enemy_hp_audit']['turns']:
  s=idx[t['start_line']]['state'];cp=s['combat'];ep=cp['enemies'][0];pl=cp['player'];print(t['turn'],s['run']['current_hp'],'powers',[(x['power_id'],x['amount']) for x in pl['powers']], 'enemy',ep['current_hp'],[(x['power_id'],x['amount']) for x in ep['powers']],ep['intents'])
print('potions receipts')
for d in ds:
 if (d.get('chosen') or {}).get('action')=='use_potion':
  n=next(i for i,x in enumerate(ss) if x['ts']==d['ts']) if any(x['ts']==d['ts'] for x in ss) else None
  a=ss[n] if n is not None else None;z=ss[n+1] if n is not None and n+1<len(ss) else None
  print('d',d['_line'],'s',a['_line'] if a else None,z['_line'] if z else None,'belt',[x['potion_id'] for x in a['state']['run']['potions'] if x['occupied']] if a else None,'->',[x['potion_id'] for x in z['state']['run']['potions'] if x['occupied']] if z else None)
print('route clocks locate')
for b in bs:
 if b['label']=='rest/plan':
  si=b['payload'].get('situation');print(b['_line'], 'situation',str(si)[:140])
  # Only print projection facts, not whole candidate metrics.
  def search(o,path=''):
   if isinstance(o,dict):
    for k,v in o.items():
     if k in ['route_review','plan_facts','lookahead']:print('found',path,k,str(v)[:900])
     elif k in ['memory','situation','facts','run_brief']:search(v,path+'.'+k)
  search(b['payload'])
print('end duration seconds',(datetime.datetime.fromisoformat(ds[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(ds[0]['ts'].replace('Z','+00:00'))).total_seconds())

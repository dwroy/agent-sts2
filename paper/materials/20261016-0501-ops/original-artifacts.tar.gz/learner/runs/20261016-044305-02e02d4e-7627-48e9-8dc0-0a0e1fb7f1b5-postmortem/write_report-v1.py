import json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).parent.resolve();root=p.parents[2]
updated=['silent-0005','silent-0011','silent-0020','silent-0024','silent-0025','silent-0027','silent-0079','silent-0162','silent-0418']
proposal=(p/'proposal-cli-receipt.json').read_text().strip();assert proposal=='silent-proposal-c2485021e58e3c01'
raw=(p/'proposal-queue-readback.jsonl').read_text().splitlines();queue=[json.loads(line.split(':',1)[1]) for line in raw]
assert any(q.get('id')==proposal and q.get('status')=='pending' for q in queue),queue
before=json.load((p/'lessons-before.json').open());h=hashlib.sha256()
with (root/'notes/lessons.md').open('rb') as f:
 remaining=before['bytes']
 while remaining:
  block=f.read(min(1024*1024,remaining));assert block;h.update(block);remaining-=len(block)
 tail=f.read()
assert h.hexdigest()==before['sha256']
draft=(p/'lesson-draft.md').read_bytes();erratum=(p/'erratum.md').read_bytes()
assert tail.count(draft)==1 and tail.count(erratum)==1
assert tail.count(b'## BGRC1SURKBJY')==1
check=subprocess.run(['python3',str(root/'learner/ledger.py'),'check'],capture_output=True,text=True)
assert check.returncode==0; (p/'ledger-final-check.txt').write_text(check.stdout+check.stderr)
audit={'run':'BGRC1SURKBJY','lessons_prefix_bytes':before['bytes'],'lessons_prefix_sha256':h.hexdigest(),'draft_sha256':hashlib.sha256(draft).hexdigest(),'erratum_sha256':hashlib.sha256(erratum).hexdigest(),'only_own_append_since_prefix':tail==draft+erratum,'source_head':(p/'source-head.txt').read_text().strip(),'source_diff_bytes':(p/'source.diff').stat().st_size,'ledger_preserved_fields':['claim','first_run','prior','prior_runs','prior_note','status','version'],'ledger_updated':updated,'ledger_roles':['support'],'ledger_check':0,'proposal':proposal,'proposal_status':'pending','implementation':'未实现；独立strategy-proposal待核验','code_changed':False,'tests':'纯记录任务，无需生产代码测试','erratum':'最优标记缺值6题的动作构成；计数及比例不变'}
(p/'final-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
result={'task':'postmortem','appended':['BGRC1SURKBJY'],'skipped':[],'bugs':[],'ledger':{'added':[],'updated':updated,'repeats':[],'check':0},'code_proposals':[proposal],'implementation_domains':['combat','sl'],'report':str(p/'report.md')}
missing='完整逐击／过量伤与退场尾击、同ID实体代际及部分杀序、前三试SL实际轮末结算、第3试原始求解输入与偏差根因、未选路线／留药／抽弃替线完整后继及完整候选兑现率、启动dirty知识完整快照、校准boss时钟和实打／估值比、F49实战、纯战斗耗时、Jev缓存命中与实付账单。'
report=f'''## 复盘回报
- 已追加：BGRC1SURKBJY（A10，第48层，永世沙漏AEONGLASS；末试4血33挡对24攻击＋27凋萎伤，需损18而亡，敌余181/535）；已追加勘误：最优标记缺值6题的动作构成，比例不变。
- 新的纯 bug（file:line，每条一行；没有写「无」）：
  - 无。
- 写成「未记录」的项：BGRC1SURKBJY：{missing}
- 学习账本：BGRC1SURKBJY：新增无；更新{ '、'.join(updated) }；均为support，老错无；`ledger.py check`退出码0。
- 代码提案：{proposal}；证据BGRC1SURKBJY/F48/T4、T7及抽弃／SL边界，关联0024、0079、0418与机制账本；实现任务strategy-proposal，领域combat/sl。缺完整原始输入、根因未定位，已登记pending，未实现／上线。

```json
{json.dumps(result,ensure_ascii=False)}
```
'''
(p/'report.md').write_text(report)
(p/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(p/'report.md'),'proposal':proposal,'proposal_status':'pending','ledger_check':check.returncode,'only_append':audit['only_own_append_since_prefix'],'updated':len(updated),'erratum':1},ensure_ascii=False))

import json,subprocess
from pathlib import Path
p=Path(__file__).parent
run='BGRC1SURKBJY'
items=[
 ('silent-0024',48,7,'末试s418913为4血33挡、24攻击和三张各9伤WITHER，需损18；s418914实死，敌220经14+13+12毒至181。d405698的-14是hpAfter，不是损血14。仅补证既有持牌伤，未证另一抽弃顺序可赢。'),
 ('silent-0079',48,4,'第3试d405632的SL原/替线预测损6伤27→损0伤17，两线五轮24/24死亡；实际双防御/尖啸后24挡对24攻及新生6伤凋萎，31→25、敌373→356。替线零损预测未兑现；原线未完整实打，无受控省血/胜率结论。本次为有限support而非策略repeat。'),
 ('silent-0020',47,None,'F38赢71/71→58/67，F39赢58→22；F40锻触媒不回血，F42/F44回20/20，F45/F46赢战62→54→51，F47回16才67血入F48，四试仍败。八营火实回167，不含跨幕/药/SL；无另一路线或锻造的受控胜负。'),
 ('silent-0005',48,7,'末试T1异鱼之油建1敏，T2步法再2至3；T7生存者+/防御/后空翻+实际14/8/11挡合33，较本体11/5/8共多9，仍不及24攻加27持牌伤。仅补证本局层数及窗口。'),
 ('silent-0011',48,2,'首试夜魇复制毒雾+后T2实建NOXIOUS_FUMES_POWER6，T3首帧敌毒6；T5再建至9。其他三试T1建3、T5追加至6。能力建立与实际施毒/后续结算分账，未证固定先后顺序胜率。'),
 ('silent-0025',48,1,'首试T1暴露清人工制品3→0；后三试T1先毒雾再刺杀使3→2，T2轮初毒雾消一至1，再由暴露清掉。末试油给1力量/1敏捷，T7敌增强后6力量且有虚弱仍24攻；只扩本局实见窗口。'),
 ('silent-0027',48,7,'末试已建ACCELERANT_POWER2，末盘毒14→11、敌220→181，实扣14+13+12=39，仍181/535而玩家死亡；SL前未结算的毒不计实伤。'),
 ('silent-0162',48,1,'首试s418674→418675在卡牌行动前敌535→534，持抱抱先生MR_STRUGGLES；后三试首状态已534/max535。入口被动扣1与本体上限、动作伤害分开，不当SL改了敌max HP。'),
 ('silent-0418',48,3,'第2/3/4试d405583/405630/405674，生存者后Jev均弃掉原计划后继小刀，原条明确预测失效并回战斗重算；不以原计划24与结束线12相减冒充完整实伤差。本次仅核执行边界。')
]
with (p/'ledger-cli-receipts.jsonl').open('a') as log:
 for ident,floor,turn,note in items:
  ev={'run':run,'floor':floor,'role':'support','note':note}
  if turn is not None:ev['turn']=turn
  data={'id':ident,'by':'learner:postmortem','evidence':[ev],'where':{'lessons':[run]},'note':'本次只追加本局补证与复盘去处；保留旧claim/first_run/prior/status/version，不登记新失误或已实现。'}
  (p/(ident+'-update.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
  res=subprocess.run(['python3','/home/dw/Projects/agent-sts2/learner/ledger.py','update'],input=json.dumps(data,ensure_ascii=False),text=True,capture_output=True)
  log.write(json.dumps({'id':ident,'returncode':res.returncode,'stdout':res.stdout,'stderr':res.stderr},ensure_ascii=False)+'\n');log.flush()
  print(ident,res.returncode,res.stdout.strip(),res.stderr.strip(),flush=True)
  if res.returncode:raise SystemExit(res.returncode)

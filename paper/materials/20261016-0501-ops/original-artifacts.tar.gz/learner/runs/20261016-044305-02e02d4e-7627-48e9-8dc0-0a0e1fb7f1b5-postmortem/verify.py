import json,collections,re,hashlib,datetime
from pathlib import Path
p=Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/(n+'.jsonl')).open()]
ds=load('decisions');ss=load('states');bs=load('brain');sl=load('sl-attempts');idx={s['_line']:s['state'] for s in ss};di={d['_line']:d for d in ds};r=json.load((p/'BGRC1SURKBJY-resources.json').open());draft=(p/'lesson-draft.md').read_text()
assert len(ds)==875 and len(ss)==969 and len(bs)==48 and len(load('run-plans'))==14
assert all(b['accepted'] and b['engine']=='codex' and b['model']=='gpt-6.1-sol' and b['effort']=='xhigh' for b in bs)
assert len(r['combats'])==22 and all(c['entry_is_turn_one'] for c in r['combats'])
assert len([c for c in r['combats'] if c['floor']!=48])==18
assert len(sl)==6 and [x['result'] for x in sl]==['won','won','predicted_death','predicted_death','predicted_death','died']
assert all(x['reload']['ok'] for x in sl[2:5])
end=idx[418913];last=idx[418914];c=end['combat'];e=c['enemies'][0]
assert end['run']['current_hp']==4 and c['player']['block']==33
assert sum((x.get('total_damage') or 0) for x in e['intents'])==24
withers=[x for x in c['hand'] if x['card_id']=='WITHER'];assert len(withers)==3 and all('9点伤害' in x['resolved_rules_text'] for x in withers)
assert 24+3*9-33==18 and last['run']['current_hp']==0 and last['combat']['enemies'][0]['current_hp']==181
assert e['current_hp']==220 and 14+13+12==220-181
q=di[405632]['sl_explore']['candidate_comparison'];assert (q['original']['hp_loss'],q['original']['damage'],q['replacement']['hp_loss'],q['replacement']['damage'])==(6,27,0,17)
assert idx[418827]['run']['current_hp']==31 and idx[418833]['run']['current_hp']==25
assert idx[418827]['combat']['enemies'][0]['current_hp']==373 and idx[418833]['combat']['enemies'][0]['current_hp']==356
assert not any(d.get('hp_guard') or d['label']=='combat/plan-guarded' for d in ds)
assert collections.Counter(str(d.get('rollout_best_chosen')) for d in ds if d['label'].startswith('combat/plan-choice'))=={'True':168,'False':9,'None':6}
assert sum(d['decider']=='jev' and isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35 for d in ds)==17
assert sum((d.get('chosen') or {}).get('action')=='use_potion' for d in ds)==16
assert not any((d.get('chosen') or {}).get('action')=='discard_potion' for d in ds)
assert not any(d.get('fallback') for d in ds)
assert sum(b['usage']['inputTokens'] for b in bs)==9042157
assert sum(b['usage']['outputTokens'] for b in bs)==63356
assert sum(b['usage']['cacheHitTokens'] for b in bs)==5063936
assert sum(b['usage']['reasoningTokens'] for b in bs)==55590
assert sum(b['latency_ms'] for b in bs)==1644453
assert sum(d['usage']['input_tokens'] for d in ds if d['decider']=='jev')==1915160
assert sum(d['usage']['output_tokens'] for d in ds if d['decider']=='jev')==12776
assert draft.count('\n## BGRC1SURKBJY')==1 and len(re.findall(r'^- \[.*；(?:打法|bug)',draft,re.M))==3
assert 'METEOR_STRIKE' not in draft and '56.0036%' in draft
# Match every generated battle row and turn array to the extracted raw observations.
for battle in r['combats']:
 a=battle['entry'];z=battle['exit'] or battle['last'];assert f"s{a['line']}→s{z['line']}" in draft
 for frame in [a,z]:
  obs=idx[frame['line']];assert obs['run']['current_hp']==frame['hp'] and obs['run']['max_hp']==frame['max_hp']
primary=[d for d in ds if d['decider']=='code' and d['label'] in ['combat/plan','combat/plan-guarded','combat/lethal','combat/least-loss','combat/end_turn','combat/mod-lethal']]
executed=[d for d in primary if not d.get('result','').startswith('not dispatched')]
assert len(primary)==129 and len(executed)==126 and len({(d['floor'],d.get('sl_attempt') or 1,d['turn']) for d in executed})==71
assert sum(len(x['enemy_hp_audit']['turns']) for x in r['combats'])==115
heals=[]
for b in bs:
 if b['label']=='rest/plan' and b['answer']['choice']=='o0':
  o=json.loads(b['options']['o0']);heals.append(o['boss_sim_hp_reference']['immediate_hp_gain'])
assert heals==[21,21,21,24,24,20,20,16] and sum(heals)==167
# Check the untouched existing lessons prefix both before and after the append.
before=json.load((p/'lessons-before.json').open());h=hashlib.sha256()
with Path('notes/lessons.md').open('rb') as f:
 remaining=before['bytes']
 while remaining:
  b=f.read(min(1024*1024,remaining));assert b;h.update(b);remaining-=len(b)
assert h.hexdigest()==before['sha256']
print('通过：身份、资源端点、SL、终局、候选差、护栏、Jev／代码计数、营火、用量、旧复盘前缀。')

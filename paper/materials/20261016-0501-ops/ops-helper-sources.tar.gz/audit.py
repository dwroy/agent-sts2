from pathlib import Path
import collections,hashlib,importlib.util,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0501';pub=r/'paper/materials/20261016-0501-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
bid='20261016-044302';run='BGRC1SURKBJY';s=r/'learner/runs/20261016-044305-02e02d4e-7627-48e9-8dc0-0a0e1fb7f1b5-postmortem';report=load(s/'result.json');b=load(r/'ops/codex-ops/learn.json')['batches'][bid]
assert report['appended']==[run] and report['bugs']==report['ledger']['added']==report['ledger']['repeats']==[] and len(report['ledger']['updated'])==9 and report['ledger']['check']==0
assert b['state']=='done' and b['rc']==0 and b['done']==[run] and b['missing']==[] and b['proposal_audit_errors']==[]
out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output)
spec=importlib.util.spec_from_file_location('raw_identity',r/'learner/extract_evidence.py');extract=importlib.util.module_from_spec(spec);spec.loader.exec_module(extract)
refs=[];counts={};runrow=None;config=None;brains=[];decisions=[]
for stream in ['states','decisions','sl-attempts','run-config','run-plans','runs','brain']:
    count=0
    with (s/(stream+'.jsonl')).open('rb') as selected,(r/'logs'/(stream+'.jsonl')).open('rb') as original:
        for encoded in selected:
            frozen=json.loads(encoded);original.seek(frozen['_offset']);raw=original.readline();row=json.loads(raw)
            assert raw.endswith(b'\n') and extract.run_identity(row)==run and row=={k:v for k,v in frozen.items() if k not in ['_line','_offset']}
            if stream=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10)
            if stream=='runs':assert (row['character'],row['ascension'],row['floor'],row['victory'])==('SILENT',10,48,False);runrow=row
            if stream=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True;brains.append(row)
            if stream=='run-config':config=row
            if stream=='decisions':decisions.append(row)
            refs.append(dict(stream=stream,learner_reported_source_line=frozen['_line'],offset=frozen['_offset'],bytes=len(raw),sha256=sha(raw)));count+=1
    counts[stream]=count
assert counts==dict(states=969,decisions=875,**{'sl-attempts':6,'run-config':1,'run-plans':14},runs=1,brain=48) and len(refs)==1914
for e in load(s/'original-row-verification.json'):
    with (r/'logs'/(e['stream']+'.jsonl')).open('rb') as original:original.seek(e['offset']);raw=original.read(e['bytes'])
    assert sha(raw)==e['sha256'] and extract.run_identity(json.loads(raw))==run
post=load(s/'final-audit.json');before=load(s/'lessons-before.json');physical=(r/'notes/lessons.md').read_bytes();draft=(s/'lesson-draft.md').read_bytes();erratum=(s/'erratum.md').read_bytes();lesson=draft+erratum
assert before['bytes']==post['lessons_prefix_bytes'] and sha(physical[:before['bytes']])==before['sha256']==post['lessons_prefix_sha256']
assert sha(draft)==post['draft_sha256'] and sha(erratum)==post['erratum_sha256'] and len(lesson)==24470
assert physical[before['bytes']:before['bytes']+len(lesson)]==lesson and sum(x.startswith(b'## BGRC1SURKBJY') for x in physical.splitlines())==1
assert post['ledger_roles']==['support'] and post['ledger_check']==0 and post['code_changed'] is False and (s/'source.diff').read_bytes()==b''
(p/'owned-lessons.md').write_bytes(lesson)
source=(s/'source-head.txt').read_text().strip();assert source==post['source_head']==config['code']['commit']=='e716bd28fd8eca9e4d76d066680304fd11935e37'
assert config['brain']['engines']['codex']['model']=='gpt-6.1-sol' and config['brain']['engines']['codex']['effort']=='xhigh' and config['brain']['codex']['service_tier']=='default'
assert not any(d.get('fallback') for d in decisions)
usage={key:sum(row['usage'][key] for row in brains) for key in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}
assert usage==dict(inputTokens=9042157,outputTokens=63356,cacheHitTokens=5063936,reasoningTokens=55590) and sum(row['latency_ms'] for row in brains)==1644453
choices=[d for d in decisions if d['label'].startswith('combat/plan-choice')];missing=[d for d in choices if d.get('rollout_best_chosen') is None]
assert collections.Counter(str(d.get('rollout_best_chosen')) for d in choices)=={'True':168,'False':9,'None':6}
assert collections.Counter(d['chosen']['action'] for d in missing)=={'use_potion':1,'play_card':4,'end_turn':1}
ids=set(report['ledger']['updated']);owned=[];ledgerrefs=[]
with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        row=json.loads(raw)
        if row.get('by')=='learner:postmortem' and row.get('id') in ids and (any(e.get('run')==run for e in row.get('evidence',[])) or str(s) in raw.decode() or run in row.get('where',{}).get('lessons',[])):
            assert row['op']=='update' and set(row)<={'op','id','ts','by','evidence','where','note'} and all(e['run']==run and e['role']=='support' for e in row.get('evidence',[]))
            owned.append(raw);ledgerrefs.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(owned)==17 and sum('evidence' in json.loads(raw) for raw in owned)==9
for ident in ids:
    item=load(s/(ident+'-update.json'));assert any(all(json.loads(raw).get(k)==v for k,v in item.items()) for raw in owned)
cli=[json.loads(line) for line in (s/'ledger-cli-receipts.jsonl').read_text().splitlines()];assert len(cli)==9 and all(x['returncode']==0 and x['stderr']=='' for x in cli)
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));write(pub/'owned-ledger-references.json',ledgerrefs)
item=load(s/'proposal-item.json');ident=(s/'proposal-cli-receipt.json').read_text().strip();assert report['code_proposals']==[ident] and ident=='silent-proposal-c2485021e58e3c01'
queued=(s/'proposal-queue-readback.jsonl').read_text().strip().split(':',1);number=int(queued[0]);original_proposal=json.loads(queued[1]);assert original_proposal['id']==ident and original_proposal['state']=='pending'
with (r/'paper/materials/learning/code-proposals.jsonl').open() as f:
    actual=next(line for index,line in enumerate(f,1) if index==number)
assert json.loads(actual)==original_proposal and all(original_proposal.get(k)==v for k,v in item.items()) and sha(Path(item['proposal']).read_bytes())==original_proposal['proposal_sha256']
spec=importlib.util.spec_from_file_location('original_proposals',r/'learner/code_proposals.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);current=m.fold(r/'paper/materials/learning/code-proposals.jsonl')[ident]
write(pub/'postmortem-original-references.json',refs)
write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,native=native,original_rows_checked=1914,stream_counts=counts,raw_binding='Learner original offsets independently read as original JSON with explicit run identity; source line numbers retained as learner-reported.',actual_accepted_codex=48,original_run_row=runrow,actual_run_config=config,source_reference=source,source_reference_does_not_reconstruct_dirty_knowledge=True,post_append=post,original_lesson_bytes=24470,original_draft_bytes=24115,original_erratum_bytes=355,old_lesson_prefix_preserved=True,original_ledger_rows=17,new_ledger_ids=[],old_support_ids=report['ledger']['updated'],repeats=[],original_proposals=[original_proposal],current_proposal_state=current['state'],new_bug=False,actual_brain_usage=usage,original_missing_best_actions=dict(collections.Counter(d['chosen']['action'] for d in missing)),limits='Three terminal SL tails, per-hit/overkill, same-type entity generations, unchosen full successors, candidate realization and dirty knowledge snapshots remain unknown; no model root cause or strategy gain proven. R365 code at startup is not itself a matched Paper Krane/beam consumer. Jev cache, calibrated clocks, F49 combat, pure-combat time and paid invoices remain unknown.',material_failures_retained=['Initial missing chosen-field analysis failure, unsupported show CLI rc2 and report status-vs-state assertion preserved.','Original chapter sentence about6 missing-best actions remains; separate append-only erratum corrects1 potion/4 play/1 end-turn, counts unchanged.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);print(json.dumps(dict(rows=1914,ledger_rows=17,lesson_bytes=24470,new_bug=False)))

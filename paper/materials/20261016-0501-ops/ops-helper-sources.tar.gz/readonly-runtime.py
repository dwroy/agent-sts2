def runtime(bid, report, output, worktree=None):
    thread = re.search(r"会话：([^\n]+)", output).group(1)
    log = Path(re.search(r"^日志：([^\n]+)", output, re.M).group(1))
    expected_tree = Path(worktree) if worktree else (Path(report["report"]).parents[3] if report["task"] == "strategy-proposal" else root)
    scratch = Path(report["report"]).parent
    events = []
    with log.open("rb") as handle:
        for index in range(512):
            offset = handle.tell(); raw = handle.readline()
            if not raw: break
            value = json.loads(raw)
            if value.get("type") in ["learner_launch", "learner_startup_attempt", "learner_startup_exit", "learner_startup_retry", "thread.started"]:
                events.append(dict(offset=offset, bytes=len(raw), sha256=sha(raw), value=value))
            if value.get("type") == "item.completed": break
    launches = [item for item in events if item["value"].get("type") == "learner_launch"]
    assert len(launches) == 1
    launch = launches[0]["value"]
    assert launch["cwd"] == str(expected_tree) and launch["params"]["scratch"] == str(scratch)
    registered_batch = launch.get("params", {}).get("batch")
    if report["task"] == "postmortem":
        assert registered_batch is None and launch["task"] == "postmortem"
        registered_batch = bid
    elif report["task"] == "fix-batch":
        assert registered_batch is None and launch["task"] == "fix-batch"
        registered_batch = bid
    else: assert registered_batch == bid
    starts = [item for item in events if item["value"].get("type") == "learner_startup_attempt"]
    assert starts and all(item["value"].get("batch") == registered_batch for item in starts)
    assert len({item["value"]["input_sha256"] for item in starts}) == 1
    assert len({item["value"]["command_sha256"] for item in starts}) == 1
    assert len({json.dumps(item["value"].get("lease"), sort_keys=True) for item in starts}) == 1
    threads = [item for item in events if item["value"].get("type") == "thread.started"]
    assert len(threads) == 1 and threads[0]["value"]["thread_id"] == thread
    successful_start = [item for item in starts if item["offset"] < threads[0]["offset"]][-1]
    prior_exits = [item for item in events if item["value"].get("type") == "learner_startup_exit"]
    assert len(prior_exits) == len(starts) - 1
    native = list((root / "ops/codex-ops/accounts/codex1/learner/sessions").glob("**/*" + thread + ".jsonl"))
    assert len(native) == 1
    context = None; actual_input = None
    with native[0].open("rb") as handle:
        for index in range(512):
            offset = handle.tell(); raw = handle.readline()
            if not raw: break
            value = json.loads(raw); payload = value.get("payload", {})
            if value.get("type") == "turn_context":
                assert payload["cwd"] == str(expected_tree) and payload["model"] == "gpt-6.1-sol" and payload["effort"] == "xhigh"
                assert payload["sandbox_policy"]["type"] == "workspace-write" and payload["sandbox_policy"].get("network_access") is False
                assert payload["approval_policy"] == "never"
                context = dict(source=str(native[0].relative_to(root)), offset=offset, bytes=len(raw), sha256=sha(raw), model=payload["model"], effort=payload["effort"], sandbox=payload["sandbox_policy"], approval_policy=payload["approval_policy"])
            if value.get("type") == "response_item" and payload.get("role") == "user":
                words = "".join(item.get("text", "") for item in payload.get("content", []) if item.get("type") == "input_text")
                if sha(words.encode()) == successful_start["value"]["input_sha256"]:
                    actual_input = dict(offset=offset, bytes=len(raw), sha256=sha(raw), input_sha256=successful_start["value"]["input_sha256"])
            if context and actual_input: break
    assert context and actual_input
    return dict(batch=bid, thread=thread, cwd=str(expected_tree), event_log=str(log.relative_to(root)), registered_launch_batch=registered_batch,
                original_lease=successful_start["value"].get("lease"), native_context=context, native_user_input=actual_input,
                original_header_events=[{key:value for key,value in item.items() if key != "value"} | {"type":item["value"]["type"], "attempt":item["value"].get("attempt"), "code":item["value"].get("code")} for item in events],
                startup_attempts=len(starts), failed_startups_preserved=len(prior_exits), no_model_or_manual_restart=True)

from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, tarfile
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0501'; pub=r/'paper/materials/20261016-0501-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1; log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut; runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected=[x for x in runs if x['run_id']=='BGRC1SURKBJY']; assert len(selected)==1; row=selected[0]
assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max='48',n_decisions='875',has_postmortem='1',performance_included='1').items()); brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':48} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],run={k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r))); write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==17; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==17
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(z)==set(a)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['evidence','where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['evidence','where','history','notes']}
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert a[ident].get(key)==z[ident].get(key),(ident,key)
 previous=a[ident].get('evidence',[]); later=z[ident].get('evidence',[]); assert later[:len(previous)]==previous; assert all(x['run']=='BGRC1SURKBJY' and x['role']=='support' for x in later[len(previous):])
 for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
 for key,values in a[ident]['where'].items():assert all(value in z[ident]['where'][key] for value in values)
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==24470 and b'## BGRC1SURKBJY' not in oldlesson and lesson in (r/'notes/lessons.md').read_bytes(); readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged17_rows']=True; readback['parallel_physical_rows_preserved']='Only own chapter and17 original CLI rows staged; other root records and pre-existing whitespace differences remain physical/uncommitted.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0501原044302复盘BGRC1SURKBJY done0闭环，无新增纯bug，不追加重复队列或复派。七流1914原行按原offset逐bytes/SHA/JSON/显式身份核，原来源行号保持学习者报告值；Silent A10/F48 AEONGLASS负局、875决策/969状态/48原accepted Codex Sol6.1/xhigh。18段此前战斗及末战四试分列，前三SL截断而末试实际死；末试4HP33挡对24攻及三张各9持牌伤完整需损18，实扣剩4、敌220经39毒至181/535，不以封顶伤替需求或编造斩杀。第3试SL原/替预测损6伤27→损0伤17，实际31→25及373→356，原线未完整执行、两线24/24预测死，不归因受控省血或新根因。正式24115字节章及355字节只追加勘误/旧物理前缀SHA核；六缺值实际1饮药4施牌1结束，168/177及168/183比例不变，旧句/初稿保留不回写。17所属CLI含九旧项support及八原提案追溯，私有fold旧claim/首证/prior/status/version及证据/history/notes/where前缀保，不重复CLI或新增shipped；c2485021e58e3c01原注册/SHA及pending沿自动独立策略链，不手工重派/实现。原chosen缺值分析失败、unsupported-show rc2、报告status/state核验失败及v1均保，不当产品失败；48脑请求实际用量9042157入/63356出/5063936缓存/55590推理核，Jev缓存及实付账单不造。启动R365/e716含十dirty知识/记录叶，不复原完整知识快照或仅凭源码当纸鹤光束匹配消费者；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0、cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性/keyscan CLEAN，本局has_postmortem1/875决策/48成功Codex入表；原计数告警及组件独立cut估计非账单保持。仅所属复盘/17CLI/生成表及证据提交，保并行记录/旧空白差，无代码/知识/版本/补测/派发/对局重启/账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261016-0501-ops/。\n'
note=f'\n- {at} [ops 学习闭环] BGRC1SURKBJY复盘及17所属CLI已核，无新增纯bug；九项support与八提案追溯、c2485021原策略提案沿自动链，根因/未选后继保持未知。原章与追加动作构成勘误均保留；论文唯一刷新exit0、{len(runs)}局、五一致性/keyscan通过，无新发布或对局操作。回执paper/materials/20261016-0501-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in p.glob('*.py'):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortem='BGRC1SURKBJY',original_rows_checked=1914,original_lesson_bytes=24470,original_draft_bytes=24115,original_erratum_bytes=355,new_bug=False,owned_ledger_rows=17,evidence_updates=9,repeat_evidence=0,support_evidence=9,proposal_links=8,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=17,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

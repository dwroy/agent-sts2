## 修 bug 回报

- 合并基线：main → 04c4ed556f0baac3bcbbb207f0f35ff0500c65c9（工作区干净，先合 main，快进且无冲突）
- 修复（每条一行）：无新增；队列与前批快照相同，41 项既有修复已核为本次基线、main 和 live 的祖先。
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb9be14d620b368ec46974c1b57901ca
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0b758a1a5e7d591745694004664f83a
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb61eef226eb7366f9612003480c83988
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7524bbb8e80a975f204f8d193657b46
- 已被别人修掉的：空产出补链误派 — 84366ad06ee4f978394c1b9489a82c83ea12bd36
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a826e94f9708af4b1a265e1892659f4e
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f
- 已被别人修掉的：纸鹤夹具 — befc39e5ca0105f8ff96d47f817df44f0b2760f1
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e5a0f234f082972d21b203dbf8229d7
- 已被别人修掉的：共享main启动冲突 — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2
- 已被别人修掉的：根事件通知路径 — 577f0bc424b7287910735cfdc86c253cc7ee8057
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe043cb8738cce57870354fa23fa84a1
- 已被别人修掉的：局间quiet误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d
- 已被别人修掉的：global-health异步测试 — d27df54f0651c4af84c6c12ceceec82a016f1142
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径本批另补） — 83a7f796c24eea8f16eb317bc70bfd832251ad27
- 已被别人修掉的：retention数字UUID — d91236326bc1af7a5417ce016c1a182f8084e7a3
- 已被别人修掉的：retention旧根scratch — 0699b05c436d3d51d00ee92f153d16d16e64bea4
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec5fc6eafe576a1296bbdadde43432ee
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ceeb81d534159b3516458521ad09bbed
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a5168d1a8cb456aed1c926b2d1b6c4488
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b7913a53b9e2645f40db1657eb5213c
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb12a1d4b2f34ee767bb2816a3a0b466
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537
- 已被别人修掉的：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70bfb2a91138ede0e1f6046927c116a4
- 已被别人修掉的：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66bd75c6d6952772dcf712399eda828b
- 已被别人修掉的：infra-test-rollout-ties-host-timeout-15000 — da08fcead2025c293140f1ba103d8efdbd39a4c3
- 已被别人修掉的：infra-test-build-facts-selection-remove-latency — e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0
- 已被别人修掉的：h1-budget-completion-health-contract — c40e43fd25c200a01f4da94a4dac8db1b34664a8
- 已被别人修掉的：h1-strict-pick-deadline-stall — b3b9734d85defbdbd1b73ab85fab9ea2f636affd
- 已被别人修掉的：selection-hidden-daggers-conditional-followup-readback — a473263eb35ce5bea8e06f1ee94f4da1ba880bc3
- 已被别人修掉的：silent-0338：末挡诊断漏列既有奥利哈钢 — c1d84804956bedbd29a7f0e81294114e18415b9d
- 已被别人修掉的：silent-0272：商店移除预判误报不可选 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26
- 已被别人修掉的：silent-0367：构筑事实未传已用尾巴状态 — 5baf663d7e6678efa3690e5a48329c4f8baee109
- 已被别人修掉的：h1-b2-margin-sample-identity（本轮期间由原ops发布V5-R384，宿主检查待完成） — 660b194c950f017e356a4b3da952e127c7e5c768
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（含0308/0311/0365/0481/0487/0496） — 策略类；已有独立strategy-proposal链，本批不重复实现或派发。
- 没修的：silent-0332实际nonpositive-hp资源契约根因 — 证据不足；原0332资源契约专用链已有owner，本批不凭开发者知识猜机制或重复实现。
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；窄启动恢复、租约和回收修复已在基线；目录删除归属、扫描竞态根因与自然时序仍未知。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查 — 独立架构、策略或归因任务，超出普通纯bug批次。
- 没修的：core-build-notify-222802-rc2旧原生通知恢复 — 证据不足；旧失败缺stderr，无法确认是否送达，保留原失败、不重发。
- 没修的：Codex缓存实测、DPR/B2性能及历史宿主超时根因 — 证据不足或独立性能调查；离线不调用模型，不将固定回归当自然性能根因闭环。
- 测试：本批无代码改动，tsc 未运行；vitest 0 文件 / 0 用例 / 未运行，无重跑；未借用前批测试结果。
- 合入：未合入（本批无新提交）；只读核验时 live 为 19988d1118ca43c1409fe900fc8c94f9f6ac32cc，不重复刷新知识、发布或编号。
- 需要 Roy 定的事：无

```json
{
  "task": "fix-batch",
  "base": "04c4ed556f0baac3bcbbb207f0f35ff0500c65c9",
  "fixes": [],
  "skipped": [
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（含0308/0311/0365/0481/0487/0496）",
      "reason": "策略类；已有独立strategy-proposal链，本批不重复实现或派发。"
    },
    {
      "item": "silent-0332实际nonpositive-hp资源契约根因",
      "reason": "证据不足；原0332资源契约专用链已有owner，本批不凭开发者知识猜机制或重复实现。"
    },
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；窄启动恢复、租约和回收修复已在基线；目录删除归属、扫描竞态根因与自然时序仍未知。"
    },
    {
      "item": "arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查",
      "reason": "独立架构、策略或归因任务，超出普通纯bug批次。"
    },
    {
      "item": "core-build-notify-222802-rc2旧原生通知恢复",
      "reason": "证据不足；旧失败缺stderr，无法确认是否送达，保留原失败、不重发。"
    },
    {
      "item": "Codex缓存实测、DPR/B2性能及历史宿主超时根因",
      "reason": "证据不足或独立性能调查；离线不调用模型，不将固定回归当自然性能根因闭环。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": 0
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261017-160006-57b7ce99-dcb6-4595-94d2-18b8f2e4ec47-fix-batch/report.md"
}
```

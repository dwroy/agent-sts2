import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261016-160244-s2-strategy-proposal'
subprocess.run(['date', '+%Y-%m-%d %H:%M:%S %Z'], check=True)
spec = importlib.util.spec_from_file_location('ledger_cli_module', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
items = json.loads((HERE / 'dispositions.json').read_text())
ids = sorted({ident for v in items for ident in v['ledger']})
updates = []
for ident in ids:
    related = [v for v in items if ident in v['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md')], 'lessons': [str(HERE / 'report.md')]},
                    'note': BATCH + '：指定提案复核均waiting；' + '；'.join(v['id'] + '：' + v['reason'] for v in related) +
                    '。无源码/知识修改、提交、合入或新版本；只追加本批追溯，不改旧claim/首证/prior/证据/状态/版本，不重复support/repeat。'})
raw_before = Path(ledger.LEDGER).read_bytes()
rows_before = [(i, json.loads(raw)) for i, raw in enumerate(raw_before.splitlines(), 1) if raw.strip()]
before = ledger.fold(rows_before)
selected = {ident: before[ident] for ident in ids}
assert all(v['character'] == 'silent' for v in selected.values())
assert not any(BATCH in note for v in selected.values() for note in v.get('notes', []))
(HERE / 'ledger-immediate-before.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
prefix = {'path': ledger.LEDGER, 'source_size': len(raw_before), 'sha256': hashlib.sha256(raw_before).hexdigest()}
(HERE / 'ledger-prefix-before.json').write_text(json.dumps(prefix, ensure_ascii=False, indent=2) + '\n')
text = ''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in updates)
(HERE / 'ledger-updates.jsonl').write_text(text)
environ = os.environ.copy()
environ['PYTHONDONTWRITEBYTECODE'] = '1'
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], input=text, text=True, capture_output=True, env=environ)
(HERE / 'ledger-cli.stdout.txt').write_text(result.stdout)
(HERE / 'ledger-cli.stderr.txt').write_text(result.stderr)
assert result.returncode == 0, result.stderr
assert result.stdout.split() == ids
raw_after = Path(ledger.LEDGER).read_bytes()
assert hashlib.sha256(raw_after[:len(raw_before)]).hexdigest() == prefix['sha256']
appended = []
offset = len(raw_before)
for raw in raw_after[offset:].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and BATCH in row.get('note', ''):
        appended.append({'source': ledger.LEDGER, 'offset': offset, 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(appended) == len(updates) == 31
private = json.loads(json.dumps(selected))
for expected, actual in zip(updates, appended):
    row = actual['row']
    assert {k: row[k] for k in expected} == expected
    assert set(row) == set(expected) | {'op', 'ts'}
    assert row['op'] == 'update'
    ledger.apply(private, row)
for ident in ids:
    a, b = selected[ident], private[ident]
    assert {k: v for k, v in a.items() if k not in ('where', 'notes', 'history')} == {k: v for k, v in b.items() if k not in ('where', 'notes', 'history')}
    assert b['notes'][:len(a['notes'])] == a['notes']
    assert b['history'][:len(a['history'])] == a['history']
    assert all(set(values) <= set(b['where'].get(key, [])) for key, values in a['where'].items())
audit = {'cli_exit_code': result.returncode, 'appended_rows': len(appended), 'ids': ids,
         'prefix_before': prefix, 'prefix_preserved': True, 'protected_fields_preserved_in_private_fold': True,
         'old_notes_history_where_preserved': True, 'appends': appended,
         'note': '私有fold仅应用本批实际CLI追加行；其他并行追加不归本批，不改写物理原账本。'}
(HERE / 'ledger-update-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit_code': result.returncode, 'appended_rows': len(appended), 'prefix_preserved': True, 'protected_fields_preserved': True}, ensure_ascii=False))

# 静默猎手指定十项策略复核

记录时间：2026-10-16 16:10:28 CST；batch=20261016-160244-s2-strategy-proposal；task=strategy-proposal；character=silent。

完整基线：`90e3b267f8a9d724aeee9167d4e41c82089546a7`。十项均waiting，本批无源码或知识修改。

来源任务及原文以proposals-original.json和十份*.original.md为准；原Markdown指纹逐一匹配。仅处理本批领取的十个ID，没有另领提案、改写旧复盘或新建重复ID。

范围为十个派发锚点和已领取提案直接关联的五局：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。十五局均核SILENT；K367为A1、SADL为A7、F4Q为A9，其余A10。不混进阶或将SL尝试当独立局。

## 1. 赢战耗药与后战资源 — waiting

原id：`silent-proposal-08eaa60bcc449852`；来源任务：experience-update；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`。

既有账本：silent-0019, silent-0020。

证据局号/层/回合：KEN58SH9SLZ6 A10：F3T2、F4T1、F5T2、F11T1/T2、F15T1两饮，共七饮；F2/3/4/5/11/15六胜战净损0/3/0/37/6/0。F12实际26→53、F16实际46→75。

反例及限制：F15零损已经使用两药，不能推为不喝也零损；SL恢复不算新药或实际路线回复。

旧行为与预期行为：现行持药/饮用价值保持。原提案要求核槽位、真实回复和Boss入口资源，不把胜战退出等同资源无消耗。

本批处置：已核七饮与回复，现有资源审计是局部事实/预测；缺F15不饮用及同入口、同后继留药到Boss的完整成对结果，不能校准持药价值。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 2. SL首战与连续通关 — waiting

原id：`silent-proposal-92920295a648b540`；来源任务：postmortem；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`。

既有账本：silent-0228, silent-0255。

证据局号/层/回合：TXZ6RVMQA09D A10 F48第二/三试T6：同盘面实际损3/扣敌36→损0/扣敌27；第三试首战胜后4血，F49开场4→0，敌111血未变。关键states行281563、281565、281566。

反例及限制：后续抽序、生成牌和打法未控制；少损3同时少输出9，不证明两战改善。1200首胜/后败仍低可信。

旧行为与预期行为：已有同样本连战资源接续、四血开场及零可操作回合分支。新continuous结果保留首战资源/第二入口，并明确联合校准与实际第二开场unknown；不能以新增输出关闭完整验证。

本批处置：缺保持抽序、生成牌、药栏及后续选择一致的两战完整替线；现有连战与新增continuous审计不是实际联合校准或SL资源比较收益。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 3. SL双向血价与沙坑 — waiting

原id：`silent-proposal-a327449c331efbc1`；来源任务：postmortem；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`。

既有账本：silent-0079, silent-0018。

证据局号/层/回合：WQZVENQ7DTRP A10 F33第二/三试T9：同指纹实际损13/扣敌24→损22/扣敌39；第二/末试T7同扣敌24、损0→4，沙坑末值4→5。

反例及限制：T7付4血确有一轮沙坑收益，不能概括为一律保血；T9两线均失败不能概括为同样安全。末T11内部先致死来源未知。

旧行为与预期行为：现有SL候选/资源比较已经列预测HP、输出和沙坑等字段；保持现有探索资格，不拟固定9血换15伤常数。

本批处置：缺攻防/沙坑两边界的受控完整后继、跨重规划整候选执行归属及独立胜局；局部9血换15净扣不足制定新SL阈值。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 4. 狡诈生成、保留与穿插 — waiting

原id：`silent-proposal-a099e89437e942bb`；来源任务：experience-update；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`。

既有账本：silent-0030, silent-0257, silent-0258。

证据局号/层/回合：九个直接来源局42饮狡诈：37次加三刀、两次加两刀、三次加零刀，均为新增升级刀；WQZVENQ7DTRP A10 F33第五/六试T11分别新增2/0/0和3/2/0。NB8KCF6HRGVF A10 F31T5、SADL3CGYTGSR A7 F8T1为有空位端点。

反例及限制：满手仍耗瓶，不是未成功饮用；当前牌面受现场增益影响，不据4/7/8等显示值推翻基础6。多生成不等于已执行完整胜线。

旧行为与预期行为：CUNNING_POTION确定生成、手位及升级刀模型已有live子实现，出刀/用药仍由现场重规划执行；不重复加入生成模型。

本批处置：确定生成与容量已在live；仍缺计划妥当保留容量、出刀穿插、跨重问整候选派发和SL恢复的联合校准，42次饮用不足关闭完整提案。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 5. 连战开场和真实资源结转 — waiting

原id：`silent-proposal-47910f82a1fdd98f`；来源任务：experience-update；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`。

既有账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。

证据局号/层/回合：TXZ6RVMQA09D A10 F43/45/46/48/49出牌前净失4，F48第三试T10余4、F49可操作前死；WQZVENQ7DTRP F33T7/T9血价及沙坑边界同上。

反例及限制：旧王室猛毒+小血瓶净2只保留组合观察，不拆单件数值；未知回血/复活顺序不补造。首场胜不能替代连战胜。

旧行为与预期行为：已有observedRoyalPoisonOpeningLoss对已观察组合返回4，fresh fight扣费与live/SL恢复分开；已有同样本HP/药水/复活接续，不重复扣开场。

本批处置：四血开场已有live子实现；仍缺留药、路线和SL的受控完整后继及未知回血/复活组合结算顺序，联合要求保留。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 6. 胜战退出与药水价值 — waiting

原id：`silent-proposal-f1374df72d8e6a25`；来源任务：postmortem；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`。

既有账本：silent-0019, silent-0020, silent-0050, silent-0253。

证据局号/层/回合：1913SE84AXQF A10 F29胜61→46，F31入口46后死；Q6M2Y34MWKRE A10 F2T1早喝敏捷候选未完整执行、T3实际饮用；F8T1速度当轮兑现、T2撤层，F8胜57→2、F9T2死。

反例及限制：Q6已实际休息且药最终喝掉，F5/F6零损留药不是丢药；1913 F24改锻造使路线条件改变。原紧勒漏算不能当价值权重误差。

旧行为与预期行为：保留药价/HP护栏/终局权重。临时/持续增益、实际回复及下一战入口需分别核；普通紧勒窄缺口已由旧源码处理。

本批处置：缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果；未执行候选和两条失败资源链不能拟合新权重。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 7. 逐牌紧勒及增益分源 — waiting

原id：`silent-proposal-38a49e6c97f31eea`；来源任务：experience-update；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`。

既有账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。

证据局号/层/回合：Q6M2Y34MWKRE A10 F8T4敌HP103→95→85→85→83：紧勒后攻击另扣2，生存者弃牌完成再扣2；1913SE84AXQF A10 F31T2弃磨蚀不耗出牌能量并建敏捷/荆棘，T3仍损5、T4死亡。

反例及限制：普通无挡紧勒不能推广升级/叠层/自动重放；反伤不得提前取消已经发动的攻击。再生总回复与敌HP伤/净损分账。

旧行为与预期行为：普通紧勒已在card-model、turn-solver和combat-plan接线，未知交互保留unknown；现有再生/速度等子模型不等于完成联合消费者校准。

本批处置：普通紧勒已有live窄实现；仍缺弃磨蚀、增益分源、再生、自动触发和SL恢复的联合消费者校准及受控完整后继。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 8. 实际回复与未来路线 — waiting

原id：`silent-proposal-ef0e38a5dbd3bc07`；来源任务：experience-update；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`。

既有账本：silent-0019, silent-0020, silent-0021。

证据局号/层/回合：1913SE84AXQF A10 F24锻造不回血、F28休息+21至61、F29赢损15至46、F31死亡且F32未来营火未到；Q6M2Y34MWKRE F3事件付8、F7休息36→57、F8赢损55至2、F9死亡。

反例及限制：未来营火未到账；条件变动不能全部当同条件模型误差。两败与其他构筑不同的低血案例均无改线因果。

旧行为与预期行为：保持路线/休息及资源值；按实际动作和已建能力结转，不把尚未触发毒雾或计划取得组件计成收益。

本批处置：缺另一营火、事件、路线及用药时机的受控完整结果；实际资源链只核兑现，不能据两败拟合路线或终局权重。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 9. 死亡统计饱和下的SL代价 — waiting

原id：`silent-proposal-7f820c02d39bfaea`；来源任务：postmortem；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`。

既有账本：silent-0079。

证据局号/层/回合：NHA2KW0RB7VP A10 F33T1：第一/第五/六试净损1/7/7、跨轮敌净扣8/24/24；原始30血。关键states283391→283397、283478→283483、283502→283507。原候选中精确切击被弃牌后又重规划。

反例及限制：跨轮净扣含抱抱先生自动伤，不能全归卡牌；第五/六次不是独立局或成功样本，六试均失败。

旧行为与预期行为：现有SL比较字段分开模型预测和执行未知，保持原notWorse/探索规则；饱和死亡比例不能证明额外付血无代价。

本批处置：缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继；同局六次失败和1/7血价差不足确定新SL门槛。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 10. 油灯、朝向及能力兑现 — waiting

原id：`silent-proposal-04b6b430759815ed`；来源任务：experience-update；实现任务：strategy-proposal/20261016-160244-s2-strategy-proposal。原文SHA256：`188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`。

既有账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。

证据局号/层/回合：K3676LU8B0UH A1 F30T2带毒刺击目标index1建8毒；SADL3CGYTGSR A7 F45毒药目标index1建10毒；NHA2KW0RB7VP A10 F17T1建10毒、F33六试T1 X1萎靡建-2力/2弱。共九目标端点。NHA F33T2爪正面1→背面2，能力未触发不预支。

反例及限制：九端点不冒称原17窗口或油灯全组合；不能把已取整1再乘1.5当实际2。F33毒雾T4建立而无T5不能计未来补毒。

旧行为与预期行为：蟹已取整弱/朝向修正已有live祖先；其他现帧公式只在已观察分支使用，油灯首次消费身份的跨动作/新战/SL联合输入仍未核实。

本批处置：缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及未覆盖X值、升级组合和能力整战后继；九端点不能认证原17窗口或全组合。

验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。

后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。

## 当前live已有子实现

本次只读live快照：`a9e687d9f0acccccddbfa92895d7966b58900658`。22个相关源码文件均与前批基线逐字相同；18个与live逐字相同，另四个只有历史Roy/Dai注释差，完整二进制diff见source-live.patch。

以下只登记已有范围，不将宽提案整体标implemented/duplicate：

- `5b56a452bb9be14d620b368ec46974c1b57901ca`：Integrate verified live dependencies into main while retaining main-only fixes；已核本base与实际live祖先。

- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：Sync repaired legacy learning and continuation adapter to main；已核本base与实际live祖先。

- `68711002f15b298b8863d2258ee5da236da151d2`：Sync tested Silent Crusher facing rounding from live；已核本base与实际live祖先。

- `fdaf787a372880b0438e73bcac7e6d2168b038ed`：Record Silent candidate dispatch receipts separately from forecasts；已核本base与实际live祖先。

- `1698adc96ba434a46942321e0237b70657e625b2`：Complete Silent SL resource comparison audit；已核本base与实际live祖先。

- `bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07`：Record raw continuous boss stages and per-sample resource diagnostics；已核本base与实际live祖先。

- `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`：Extend observed Silent opening HP combinations；已核本base与实际live祖先。

狡诈生成/容量、普通紧勒、四血开场、蟹朝向取整、单动作回执、SL预测差额与raw连续Boss结果均有已有实现。当前scope仍分别是candidate_forecast/current_turn_prediction/single_action_receipt/raw_simulation；actual_turn_result和whole_plan_executed未认证，联合校准及实际第二开场为unknown，不能据此承诺完整候选收益。

## 拟合、回退与闭环边界

本批不拟新阈值、血价、药价、SL准入或路线权重，没有独立受控后继时保留现行为。Roy-2026-10-07-learning是修改授权，不是游戏证据；这里未因旧规则由人制定而额外要求批准。

没有上线，无回退动作。后续有依据的实现须独立提交，仅撤对应源码范围且保留刷新知识、其他发布和所有原失败；实际上线再由ops核release_id、登记shipped和双通知Roy。

没有新增机制反证或与旧知识冲突的新结论，不重复support/repeat，不关闭学习入库、量化或其他宽父要求。只经根ledger.py update追加本批追溯，不改原claim/首证/prior/evidence/status/version，不降级已shipped项目。

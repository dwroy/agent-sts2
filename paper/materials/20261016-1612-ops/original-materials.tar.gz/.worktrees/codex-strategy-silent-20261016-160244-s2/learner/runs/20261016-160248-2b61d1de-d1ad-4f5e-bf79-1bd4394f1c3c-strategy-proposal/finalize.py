import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
result = json.loads((HERE / 'result.json').read_text())
dispatch = json.loads((HERE / 'dispatch.json').read_text())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True)
diff = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'])
index = subprocess.check_output(['git', 'diff', '--cached', '--binary'])
assert head == result['base'] and len(head) == 40
assert status == '' and diff == b'' and index == b''
assert result['task'] == dispatch['task'] == 'strategy-proposal'
assert result['character'] == dispatch['character'] == 'silent'
assert result['runs'] == dispatch['runs']
assert result['code_proposals'] == dispatch['proposal_ids']
assert [v['id'] for v in result['proposal_results']] == dispatch['proposal_ids']
assert all(v['state'] == 'waiting' and v['reason'] for v in result['proposal_results'])
assert result['fixes'] == result['implementation_domains'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert Path(result['report']) == HERE / 'report.md'
assert json.loads((HERE / 'gitleaks.json').read_text()) == []
assert 'no leaks found' in (HERE / 'gitleaks.log').read_text()
ledger = json.loads((HERE / 'ledger-update-audit.json').read_text())
assert ledger['cli_exit_code'] == 0 and ledger['appended_rows'] == 31
assert ledger['prefix_preserved'] and ledger['protected_fields_preserved_in_private_fold']
with (HERE / 'report.md').open('a') as f:
    f.write('\n最终验收（' + now + '）：材料gitleaks实际exit0，扫描约16.90MB，无泄漏；只覆盖本批交付材料。HEAD=' + head + '，git status、工作树diff与index均空，十项waiting和tests三项null经机器读回一致。\n')
(HERE / 'workspace.diff.patch').write_bytes(diff)
record = {'checked_at': now, 'head': head, 'base': result['base'], 'status': status,
          'worktree_diff_bytes': len(diff), 'index_diff_bytes': len(index),
          'source_knowledge_unchanged': True, 'proposal_results': len(result['proposal_results']),
          'all_waiting': True, 'tests': result['tests'], 'merged': None,
          'ledger_cli_exit_code': 0, 'ledger_appended_rows': 31,
          'ledger_prefix_preserved': True, 'ledger_protected_fields_preserved': True,
          'gitleaks': {'exit_code': 0, 'scope': '本批交付材料', 'findings': 0, 'log': str(HERE / 'gitleaks.log')},
          'report': result['report'], 'proposal': str(HERE / 'proposal.md')}
(HERE / 'final-verification.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
artifacts = []
for path in sorted(HERE.rglob('*')):
    if path.is_file() and path.name != 'artifact-manifest.json':
        raw = path.read_bytes()
        artifacts.append({'path': str(path.relative_to(HERE)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(HERE / 'artifact-manifest.json').write_text(json.dumps({'files': artifacts, 'external_evidence_origins': str(HERE / 'evidence-origins.json')}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': head, 'clean': True, 'waiting': 10, 'ledger_updates': 31, 'tests': result['tests'], 'report': result['report']}, ensure_ascii=False))

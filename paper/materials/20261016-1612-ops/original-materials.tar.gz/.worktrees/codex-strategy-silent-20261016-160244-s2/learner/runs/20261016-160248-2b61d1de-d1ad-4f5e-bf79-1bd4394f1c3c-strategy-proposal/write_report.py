import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-105929-s2/learner/runs/20261016-105932-20ddbfd6-7fde-42e5-a063-834d51b0f668-strategy-proposal')
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
batch = '20261016-160244-s2-strategy-proposal'
dispatch = json.loads((HERE / 'dispatch.json').read_text())
original = json.loads((HERE / 'proposals-original.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
evidence = json.loads((HERE / 'evidence-verification.json').read_text())
items = json.loads((OLD / 'dispositions.json').read_text())
assert [v['id'] for v in items] == dispatch['proposal_ids']
for item in items:
    old = original[item['id']]
    assert item['original_sha256'] == old['proposal_sha256']
    assert item['ledger'] == old['ledger']
    assert item['state'] == 'waiting'
(HERE / 'dispositions.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
proposal = [
    '# 静默猎手指定十项策略复核',
    f'记录时间：{now}；batch={batch}；task=strategy-proposal；character=silent。',
    f'完整基线：`{base}`。十项均waiting，本批无源码或知识修改。',
    '来源任务及原文以proposals-original.json和十份*.original.md为准；原Markdown指纹逐一匹配。仅处理本批领取的十个ID，没有另领提案、改写旧复盘或新建重复ID。',
    '范围为十个派发锚点和已领取提案直接关联的五局：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。十五局均核SILENT；K367为A1、SADL为A7、F4Q为A9，其余A10。不混进阶或将SL尝试当独立局。',
]
for index, item in enumerate(items, 1):
    old = original[item['id']]
    proposal.extend([
        f"## {index}. {item['title']} — waiting",
        f"原id：`{item['id']}`；来源任务：{old['source_task']}；实现任务：strategy-proposal/{batch}。原文SHA256：`{old['proposal_sha256']}`。",
        '既有账本：' + ', '.join(item['ledger']) + '。',
        '证据局号/层/回合：' + item['evidence'],
        '反例及限制：' + item['counterexamples'],
        '旧行为与预期行为：' + item['behavior'],
        '本批处置：' + item['reason'],
        '验证方法：本批逐原始offset/bytes/SHA/JSON与显式身份核对；186项动作/端点材料检查、九油灯端点及十五份历史代码记录另存evidence-verification.json、supplemental-verification.json。旧六份消费者只核保存SHA及原回执，本批未重跑，不能作为本次模型校准。',
        '后续实现验收：冻结完整生产输入和候选，跨抽弃牌、用药及重规划核实际派发与后继；机制数值和整战收益分别验证。旧局用于发现/固定回放，未来新局按时间后移验证，SL不拆样本；缺反事实不补造新参数。若实现代码，固定用例须撤源码失败、恢复通过，再跑规定沙箱检查。',
    ])
proposal.extend([
    '## 当前live已有子实现',
    f"本次只读live快照：`{source['live_snapshot']}`。22个相关源码文件均与前批基线逐字相同；18个与live逐字相同，另四个只有历史Roy/Dai注释差，完整二进制diff见source-live.patch。",
    '以下只登记已有范围，不将宽提案整体标implemented/duplicate：',
])
for row in source['commits']:
    assert row['base_ancestor'] and row['live_ancestor']
    proposal.append(f"- `{row['commit']}`：{row['subject']}；已核本base与实际live祖先。")
proposal.extend([
    '狡诈生成/容量、普通紧勒、四血开场、蟹朝向取整、单动作回执、SL预测差额与raw连续Boss结果均有已有实现。当前scope仍分别是candidate_forecast/current_turn_prediction/single_action_receipt/raw_simulation；actual_turn_result和whole_plan_executed未认证，联合校准及实际第二开场为unknown，不能据此承诺完整候选收益。',
    '## 拟合、回退与闭环边界',
    '本批不拟新阈值、血价、药价、SL准入或路线权重，没有独立受控后继时保留现行为。Roy-2026-10-07-learning是修改授权，不是游戏证据；这里未因旧规则由人制定而额外要求批准。',
    '没有上线，无回退动作。后续有依据的实现须独立提交，仅撤对应源码范围且保留刷新知识、其他发布和所有原失败；实际上线再由ops核release_id、登记shipped和双通知Roy。',
    '没有新增机制反证或与旧知识冲突的新结论，不重复support/repeat，不关闭学习入库、量化或其他宽父要求。只经根ledger.py update追加本批追溯，不改原claim/首证/prior/evidence/status/version，不降级已shipped项目。',
])
(HERE / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')
manifest_table = '\n'.join(f"| {v['stream']} | {v['source_size']} | {v['verified_lines']} |" for v in evidence['streams'])
results_table = '\n'.join(f"| {v['id']} | waiting | {v['reason']} |" for v in items)
report = f'''# 本批静默猎手策略处置报告

记录时间：{now}。task=strategy-proposal，character=silent，batch={batch}。

十项均waiting。原证据支持局部数值，相关窄功能已有live实现；本批未发现足够完整执行归属、联合生产校准或受控整战后继来支持新策略。无源码/知识修改、新提案ID、提交、live合入、版本或shipped；fixes=[]，merged=null。逐项证据、层/回合、账本、反例、预期行为、验证和回退见proposal.md。

## 身份与基线

开工git status干净，已读README、最新STATE-2026-10-16、decision-log末尾、learning-protocol和learning-code-proposals。根learn.json只取本批行，task/character/worktree/十个proposal_ids和十个派发局号匹配，reason=proposal，没有research_request、implementation_request或proposal_repair。普通专题文件绑定另一旧批次，本批不承接专题、不读取其他专题替代身份。十份原Markdown的SHA256均匹配，31个关联账本和26个本角色经验条目已读回。

已执行git merge --no-edit main；完整base/HEAD=`{base}`。十五个直接来源局均核SILENT：十个派发锚点之外，仅补读已领取提案直接关联的1913、Q6、NHA、K367、SADL。K367为A1、SADL为A7、F4Q为A9，其余A10；不混阶或扩独立局数。没有派下级agent，不读其他角色私有知识，不联网、调LLM/游戏API/模拟或play，不改模型/账号/权限/运维prompt。本批工具未独立核验当前原生会话实际模型和推理参数，不冒称已切换，交宿主按原线程核。

## 原证据与验证

本次真实调用共用extract_evidence.py提取runs/run-config/run-plans/fight-plans四流；states/decisions/sl-attempts/brain复用105929-s2共用提取器的冻结封套与原source_size，不冒称重新扫描大流。所有来源路径及manifest保存evidence-origins.json；本次四流manifest独立保存在evidence/，旧截点、报告和零行初稿均保留。

19,929条封套本批逐原日志offset/bytes/SHA256/JSON及显式身份读回通过。run-plans使用run，其他流按run_id/state.run_id/fingerprint.run；正文提及不作所属身份，冲突拒收。八流选中内容SHA与前批相同，不计新增独立证据。无效JSON计数仅保留原提取记录，不归本批样本；fight-plans零行只代表该截点未选到，不能推断原日志缺失。

| 流 | 冻结source_size字节 | 已读回行数 |
|---|---:|---:|
{manifest_table}

186项材料检查本批实际通过：42次狡诈/九独立局的37×3、2×2、3×0容量及升级刀；KEN七饮；TXZ首胜余4和第二场4→0、敌111未受攻击；Q6普通紧勒端点103→95→85→85→83；NHA第一/五/六试T1损1/7/7、跨轮敌净扣8/24/24；以及TXZ/WQ三组同指纹端点。跨轮净扣包含自动伤等来源，不认证完整候选归因或整战因果。

另核九个油灯目标端点：K367 F30T2建8毒、SADL F45建10毒、NHA F17建10毒及F33六试X1萎靡建−2力/2弱；九端点不等于原17窗口或首次消费持续身份。十五份历史run-config完整源码提交均存在，dirty_files未列生产代码；具体刷新知识/移动表字节未全部冻结，不能称完整历史生产重放。

旧六份有界selection消费者输入/输出SHA和exit0回执已核，旧205项材料回执保存引用；本批没有重跑它们，不借旧绿作为本批生产测试或联合校准。原提案其他历史汇总保留为原提案观察，没有重新展开全历史统计。详evidence-verification.json、supplemental-verification.json及原引用SHA。

## 当前源码与已有live边界

只读live=`{source['live_snapshot']}`。22个相关文件与前批基线全部相同；18个与live逐字相同，四个差异仅历史Roy/Dai注释，source-since-previous.patch为空、source-live.patch保留精确差异。source-audit.json核七个实际live祖先提交，proposal.md逐一列出。

狡诈生成/容量、四血开场及零可操作回合、普通紧勒、蟹朝向取整、单动作dispatch、SL资源比较与raw连续Boss结果均已有子实现。当前SL资源字段仍是模型预测、execution=unverified；dispatch是single_action_receipt且whole_plan_executed=null；continuous校准及实际第二开场unknown。不得将这些局部实现升级为整项duplicate/implemented。当前进阶怪物数据库与房间五样本门槛保持，本批未读刷新数据库来冒充旧运行输入。

## 十项结果

| 原提案ID | 状态 | 具体剩余缺口 |
|---|---|---|
{results_table}

## 记录与完成边界

只经根learner/ledger.py update追加31个既有账本的本批proposal/report链接及waiting说明，by=learner:strategy-proposal；实际CLI及物理追加验收以ledger-update-audit.json为准。不新增重复经验/提案ID，不改claim/首证/prior/evidence/status/version，不把已shipped条目降级proposed。最终proposal_results交原调度器消费，不手改提案队列、learn.json或根请求，不代其他角色确认。

无源码修改，撤源码失败/恢复通过不适用，生产tests为{{"tsc":null,"vitest":null,"cases":null}}。未运行或声明生产套件通过；未进入live锁、造空合并/版本或实际规则上线通知。保留waiting是具体缺数据，没有新增机制异议或与旧知识冲突的新结论；报告不关闭学习入库/量化父要求。

材料只放本任务learner/runs目录。一次误探不存在的source-readback.json，以及初次读取同日其他静默批次报告用于定位，均未被当成本批证据或产品故障；本批实际引用已绑定105929-s2/091304-s2对应原ID与SHA。原工具输出保留，不修改历史。最终HEAD、工作树、源码/knowledge/index差异和材料gitleaks实际结果记录final-verification.json；材料扫描不冒称完整历史或源码提交前检查。

提案交运维：{HERE / 'proposal.md'}
报告：{HERE / 'report.md'}
机器回报：{HERE / 'result.json'}
'''
(HERE / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
          'runs': dispatch['runs'], 'fixes': [],
          'skipped': [{'id': v['id'], 'reason': v['reason']} for v in items], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{'id': v['id'], 'state': 'waiting', 'reason': v['reason']} for v in items],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'items': len(items), 'base': base}, ensure_ascii=False))

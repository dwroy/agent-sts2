"""Verify frozen source bytes and project only the dispatched Silent evidence."""
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('evidence_entry', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def project_state(item):
    row, state = item['row'], item['row']['state']
    run, combat = state.get('run') or {}, state.get('combat') or {}
    assert str(run['character_id']).lower() == 'silent'
    player = combat.get('player') or {}
    return {
        'run': item['run_id'], 'line': item['line'], 'ts': row.get('ts'),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'in_combat': state.get('in_combat'), 'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'asc': run.get('ascension'), 'block': player.get('block'), 'energy': player.get('energy'),
        'played': player.get('cards_played_this_turn'), 'powers': player.get('powers', []),
        'ready': (combat.get('action_readiness') or {}).get('can_use_combat_actions'),
        'actions': state.get('available_actions'),
        'potions': [{'index': p.get('index'), 'id': p.get('potion_id')} for p in run.get('potions', []) if p.get('occupied')],
        'relics': [p.get('relic_id') for p in run.get('relics', [])],
        'hand': [{'index': c.get('index'), 'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                  'cost': c.get('energy_cost'), 'values': c.get('dynamic_values', [])} for c in combat.get('hand', [])],
        'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'is_alive', 'block', 'powers', 'intents', 'move_id']}
                    for e in combat.get('enemies', [])],
    }


def main():
    sources, projected, rows, runs = {}, [], [], {}
    for name in ['evidence', 'evidence-linked']:
        directory = OUT / name
        manifest = json.loads((directory / 'evidence-manifest.json').read_text())
        for stream in manifest:
            counts, digest, verified = Counter(), hashlib.sha256(), 0
            path = directory / (stream['stream'] + '.evidence.jsonl')
            with path.open('rb') as inp:
                for encoded in inp:
                    digest.update(encoded)
                    item = json.loads(encoded)
                    counts[item['run_id']] += 1
                    assert extractor.run_identity(item['row']) == item['run_id']
                    assert item['offset'] + item['bytes'] <= stream['source_size']
                    if item['source'] not in sources:
                        sources[item['source']] = Path(item['source']).open('rb')
                    source = sources[item['source']]
                    source.seek(item['offset'])
                    raw = source.read(item['bytes'])
                    assert hashlib.sha256(raw).hexdigest() == item['sha256']
                    assert json.loads(raw) == item['row']
                    if stream['stream'] == 'states':
                        projected.append(project_state(item))
                    if stream['stream'] == 'runs':
                        assert item['row']['character'].lower() == 'silent'
                        runs[item['run_id']] = item['row']
                    verified += 1
            assert digest.hexdigest() == stream['output_sha256']
            assert all(counts[k] == v for k, v in stream['counts'].items())
            rows.append({'directory': name, **stream, 'verified_rows': verified})
    for handle in sources.values():
        handle.close()
    projected.sort(key=lambda s: s['line'])
    (OUT / 'states-projection.jsonl').write_text(''.join(json.dumps(s, ensure_ascii=False) + '\n' for s in projected))
    (OUT / 'verified-runs.json').write_text(json.dumps(runs, ensure_ascii=False, indent=2) + '\n')
    report = {'streams': rows, 'rows': sum(r['verified_rows'] for r in rows), 'states': len(projected),
              'runs': len(runs), 'source_byte_verification': True,
              'limitations': ['逐行身份/字节校验不代表历史dirty执行树可还原。', '抽取流的零行仅指固定截点未选到。']}
    (OUT / 'evidence-checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['rows', 'states', 'runs', 'source_byte_verification']}, ensure_ascii=False))


if __name__ == '__main__':
    main()

"""Derive bounded observations without inventing candidate execution or counterfactuals."""
import bisect
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent


def entries(stream):
    for sub in ['evidence', 'evidence-linked']:
        with (OUT / sub / (stream + '.evidence.jsonl')).open() as handle:
            for line in handle:
                yield json.loads(line)


def power(powers, ident):
    return next((p['amount'] for p in powers if p['power_id'] == ident), 0)


def enemy_hp(state):
    return sum(e['current_hp'] for e in state['enemies'] if e['is_alive'])


def main():
    states = [json.loads(line) for line in (OUT / 'states-projection.jsonl').open()]
    by_run = defaultdict(list)
    for s in states:
        by_run[s['run']].append(s)
    times = {run: [s['ts'] for s in rows] for run, rows in by_run.items()}
    decisions = list(entries('decisions'))
    sl = list(entries('sl-attempts'))
    checked = []

    def check(name, actual, expected):
        assert actual == expected, (name, actual, expected)
        checked.append({'name': name, 'actual': actual, 'expected': expected})

    def adjacent(d):
        run = d['run_id']
        # A decision may retain an older observation timestamp across a completed selection.
        pos = bisect.bisect_right(times[run], d['ts']) - 1
        before = by_run[run][pos]
        after = by_run[run][pos + 1]
        assert (before['floor'], before['turn']) == (d['floor'], d['turn'])
        return before, after

    potions = []
    for item in decisions:
        d = item['row']
        if (d.get('chosen') or {}).get('action') != 'use_potion':
            continue
        before, after = adjacent(d)
        ident = ((d.get('expect') or {}).get('potion') or {}).get('id')
        slot = d['chosen']['option_index']
        assert {'index': slot, 'id': ident} in before['potions']
        assert {'index': slot, 'id': ident} not in after['potions']
        potions.append({'run': d['run_id'], 'decision_line': item['line'], 'floor': d['floor'],
                        'turn': d['turn'], 'attempt': d.get('sl_attempt'), 'potion': ident,
                        'state_lines': [before['line'], after['line']],
                        'hand': [len(before['hand']), len(after['hand'])],
                        'hp': [before['hp'], after['hp']], 'energy': [before['energy'], after['energy']],
                        'enemy_hp': [enemy_hp(before), enemy_hp(after)],
                        'potions': [before['potions'], after['potions']]})
        if ident == 'CUNNING_POTION':
            check('狡诈手位 ' + str(item['line']), len(after['hand']) - len(before['hand']), min(3, 10 - len(before['hand'])))
            check('狡诈即时资源 ' + str(item['line']), [after['hp'], after['energy'], enemy_hp(after)],
                  [before['hp'], before['energy'], enemy_hp(before)])
            for c in after['hand']:
                if c['id'] == 'SHIV':
                    check('狡诈升级小刀 ' + str(item['line']) + ':' + str(c['index']), c['upgraded'], True)
                    damage = next(v for v in c['values'] if v['name'] == 'Damage')
                    check('狡诈基础伤 ' + str(item['line']) + ':' + str(c['index']), damage['base_value'], 6)
    cunning = [p for p in potions if p['potion'] == 'CUNNING_POTION']
    check('原九局狡诈饮用数', len(cunning), 42)
    check('原九局狡诈新增手数分布', dict(Counter(p['hand'][1] - p['hand'][0] for p in cunning)), {3: 37, 2: 2, 0: 3})
    ken = [p for p in potions if p['run'] == 'KEN58SH9SLZ6']
    check('KEN七次饮用', [(p['floor'], p['turn']) for p in ken], [(3, 2), (4, 1), (5, 2), (11, 1), (11, 2), (15, 1), (15, 1)])

    def attempt_states(run, floor, attempt):
        event = next(i['row'] for i in sl if (i['row']['run_id'], i['row']['floor'], i['row']['attempt']) == (run, floor, attempt))
        return [s for s in by_run[run] if s['floor'] == floor and event['started_at'] <= s['ts'] <= event['ended_at']]

    turns = []
    for run, floor, attempts, turn_numbers in [
        ('TXZ6RVMQA09D', 48, [2, 3], [6]),
        ('WQZVENQ7DTRP', 33, [2, 3, 6], [7, 9]),
        ('NHA2KW0RB7VP', 33, [1, 2, 3, 4, 5, 6], [1]),
    ]:
        for attempt in attempts:
            observations = attempt_states(run, floor, attempt)
            for turn in turn_numbers:
                ready = [s for s in observations if s['turn'] == turn and s['ready']]
                successors = [s for s in observations if s['turn'] == turn + 1 and s['ready']]
                if not ready or not successors:
                    continue
                a, b = ready[0], successors[0]
                turns.append({'run': run, 'floor': floor, 'attempt': attempt, 'turn': turn,
                              'state_lines': [a['line'], b['line']], 'hp': [a['hp'], b['hp']],
                              'observed_net_hp_loss': a['hp'] - b['hp'],
                              'net_live_enemy_hp_loss': enemy_hp(a) - enemy_hp(b),
                              'sandpit': [power(s['enemies'][0]['powers'], 'SANDPIT_POWER') for s in [a, ready[-1], b]],
                              'last_block': ready[-1]['block'], 'actual_candidate_execution': None,
                              'limitation': '端点净差包含轮间触发，只说明本次实际回合；不能直接归给初题完整候选。'})
    def turn(run, attempt, number):
        return next(t for t in turns if (t['run'], t['attempt'], t['turn']) == (run, attempt, number))
    for attempt, loss, damage in [(2, 3, 36), (3, 0, 27)]:
        t = turn('TXZ6RVMQA09D', attempt, 6)
        check('TXZ T6端点 ' + str(attempt), [t['observed_net_hp_loss'], t['net_live_enemy_hp_loss']], [loss, damage])
    for attempt, loss, damage in [(2, 13, 24), (3, 22, 39)]:
        t = turn('WQZVENQ7DTRP', attempt, 9)
        check('WQ T9端点 ' + str(attempt), [t['observed_net_hp_loss'], t['net_live_enemy_hp_loss']], [loss, damage])
    for attempt, loss, damage in [(1, 1, 8), (5, 7, 24), (6, 7, 24)]:
        t = turn('NHA2KW0RB7VP', attempt, 1)
        check('NHA T1端点 ' + str(attempt), [t['observed_net_hp_loss'], t['net_live_enemy_hp_loss']], [loss, damage])
    mapped = {s['line']: s for s in states}
    check('TXZ首战奖励及后场死亡', [mapped[n]['hp'] for n in [281563, 281565, 281566]], [4, 4, 0])
    check('TXZ后战敌HP未变', [enemy_hp(mapped[n]) for n in [281565, 281566]], [111, 111])
    check('TXZ后战未出牌', mapped[281566]['played'], 0)
    check('Q6紧勒逐步敌血', [enemy_hp(mapped[n]) for n in [282887, 282888, 282889, 282891, 282892]], [103, 95, 85, 83, 80])
    results = {'checks': checked, 'check_count': len(checked), 'potions': potions,
               'cunning': cunning, 'actual_turn_windows': turns,
               'limitations': ['未执行候选没有受控后继；本材料校验不是生产tsc/vitest。',
                              '净敌血差只用于上述固定无换相窗口，不作通用毛伤或逐击归因。']}
    (OUT / 'facts.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'check_count': len(checked), 'cunning': len(cunning), 'actual_turn_windows': len(turns)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

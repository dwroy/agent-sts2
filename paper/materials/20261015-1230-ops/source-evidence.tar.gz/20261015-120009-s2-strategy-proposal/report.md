# 静默猎手策略提案批次报告

记录时间：2026-10-15T12:11:58+08:00。批次20261015-120009-s2-strategy-proposal，角色silent。

**十个派发提案全部核验，均保留waiting；无源码修改。** 原行为保持，fixes=[]，merged=null。未创建源码提交、eval版本或shipped记录。完整base：`93cce82eebf435770a60913f22f5d690f5606ef8`。开工git status干净，按普通批次执行git merge --no-edit main，结果Already up to date。本批无冻结专题或实现请求，不适用纯研究完成字段。

## 证据范围与核验

十个派发锚点：KEN58SH9SLZ6, TXZ6RVMQA09D, WQZVENQ7DTRP, 02HB4L0C3C67, 4D4J8USKCPAV, F4QKG4J1AJJZ, JLN5SK17W4FQ, LS8035TB32P3, NB8KCF6HRGVF, S9UZAK0JP0C0。

只补核原提案本身明确关联的五局：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR；未领取其他提案，也未扩展整条队列。十五局runs.jsonl均核为SILENT。K367 A1、SADL A7、F4Q A9，其余A10；不同进阶没有混作统一参数。

调用本工作树learner/extract_evidence.py，分别保存evidence/与evidence-linked/，每次八流。共19929行、9815个状态。audit_evidence.py对每行原身份、source_size截点、offset/bytes、原行SHA、JSON相等及输出哈希全部通过。所有source_size和分局计数保存在两份manifest及evidence-checks.json。

| 流 | 本批核验行数 |
|---|---:|
| states | 9815 |
| decisions | 9448 |
| sl-attempts | 78 |
| run-config | 15 |
| run-plans | 77 |
| brain | 481 |
| runs | 15 |
| fight-plans | 0 |

两次扫描states的source_size同为13008716395；decisions截点分别1556580259及1556685840，记录真实扫描时的边界，未声称跨流原子快照。源扫描states/decisions/brain各有2/2/1行解析失败，这是全流扫描统计，未认作本角色坏行。fight-plans在本次截点选0行，只能说明该范围未选到，不能断言原日志缺失。run-plans有run字段的记录已按显式身份收取，不以正文提及归局。

## 逐项处置

| 提案 | 账本 | 处置/缺口 |
|---|---|---|
| silent-proposal-08eaa60bcc449852 | silent-0019, silent-0020 | waiting：KEN F3/4/5/11/15七次饮用、六胜战净损46和两次真实营火回复已复核；F15零净损同时耗两药。缺相同入口、后续抽牌及药栏下不饮用或留到Boss的成对整战结果，不能据此重拟持药价。 |
| silent-proposal-92920295a648b540 | silent-0228, silent-0255 | waiting：TXZ F48第二/三试T6实损3/0且敌净扣36/27，第三试首胜4血而F49开场4→0；开场子项已有live祖先e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a。缺同后续抽牌、生成与药栏的两战通关替线，不能调整SL门槛或把首胜当连续通关改善。 |
| silent-proposal-a327449c331efbc1 | silent-0079, silent-0018 | waiting：WQ F33第二/三试T9复现多损9血换多扣15敌血；第六试T7又是多付4血换沙坑末值4→5且敌净扣同为24。已有候选审计，但缺双边界完整受控后继及独立胜局，无法验证新的探索排序或固定血价阈值。 |
| silent-proposal-a099e89437e942bb | silent-0030, silent-0257, silent-0258 | waiting：九局42次狡诈饮用复核为37次添3、2次添2、3次添0，确定生成及手位子项已由实际live祖先6403fdcdadc803a092beb5165a068e22bf51c412覆盖。整项仍缺计划妥当选择、穿插出刀、完整候选派发与SL恢复的联合消费者校准，不把子项覆盖登记为整项duplicate。 |
| silent-proposal-47910f82a1fdd98f | silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255 | waiting：TXZ已观察遗物组合五次出牌前净扣4及WQ双向血价均核对；e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a是live祖先，旧fc7042d1df0626e9e726f4bc912d9c6f626d908f不是。缺留药/路线/SL完整后继对照与未知回血复活组合的结算顺序，不能关闭整个资源价值要求。 |
| silent-proposal-f1374df72d8e6a25 | silent-0019, silent-0020, silent-0050, silent-0253 | waiting：1913 F29胜后46血接F31、Q6 F8胜后2血接F9死亡的实际资源链已核；缺隔离机制误差后同入口、同预算、同后续的未用/早用/留药成对整战结果。单题早喝候选未完整执行，不能校准药水持有价或终局权重。 |
| silent-proposal-38a49e6c97f31eea | silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262 | waiting：Q6 F8T4普通紧勒逐步敌血103→95→85→83→80已复核；受限普通分支已有live祖先5c7105ff0294466da8319f2934beda05c6040794。1913弃磨蚀、重接及反伤仍需与增益分源、再生、自动触发/SL恢复作完整联合消费者校准，不能以一个普通无挡子项关闭整项或外推升级叠层。 |
| silent-proposal-ef0e38a5dbd3bc07 | silent-0019, silent-0020, silent-0021 | waiting：1913 F24实际锻造、F28回21、F29胜损15而46入F31；Q6 F7回21后F8仍损55，2血入F9。没有另一营火、事件、路线与药时的完整受控结果；条件改变与同条件模型误差须分开，两败不足拟合资源权重或保证未来营火可达。 |
| silent-proposal-7f820c02d39bfaea | silent-0079 | waiting：NHA F33首四试T1实损1/敌净扣8，对后两试实损7/敌净扣24已核；277248/277272的生存者仍是pending，弃牌后另题才派回响。live祖先c769739b97389fdc978b6515b83a38e3cd900f67与5604982e13890e0e2bc8bf8246272e8267321c0b只保存预测。缺同预算饱和排序校准、整候选派发归属与成对完整后继。 |
| silent-proposal-04b6b430759815ed | silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265 | waiting：NHA F33T2爪1→2且火箭30→20已核，取整子项已有live祖先ec29ea34b919344b707e57ba472ea210f9c39d62及重放f2c7cc1a7288893bceae0f0b20304a2b1fae5f57。油灯已见毒4→8、5→10和普通X1萎靡减力/弱各2，但缺可靠首次消费来源、跨动作/新战/SL恢复联合验证；其他X值升级组合和能力整战后继未知。 |

每项完整旧/新行为、证据层/回合、账本、反例、时间切分、验证与回退见本目录proposal.md。原十份Markdown已全部读取并逐SHA核对一致，见proposal-source-checks.json；没有修改原提案或新建重复ID。proposal_results以dispositions.json和最终result.json为准。

## 已复算的实际结果及限制

- KEN F3T2/F4T1/F5T2/F11T1–2/F15T1共7饮；六胜战净损0/3/0/37/6/0合46，F5损37不能被胜利遮蔽。F15零损但已用两药。F12回复26→53、F16 46→75（上限同时变化），五次SL恢复单列348；没有不喝/留药的完整受控Boss后继。
- TXZ F48第二/三试T6端点分别48→45、48→48，敌净扣36/27；第三试T10首胜4血，states 281563/281565/281566核4→4→0，F49敌111不变、出牌数0。不是三局独立样本，也不能把未校准第二战0%当SL证明。
- WQ F33第二/三试T9，states 282075→282079与282144→282148，损13/22、敌净扣24/39。第六试T7对第二试同轮，损0→4而敌净扣都24、行动末沙坑4→5。既不能把多损血都禁掉，也不能把死亡率并列当等安全。
- 九局42次狡诈实际饮用：37次添3、2次添2、3次添0；逐窗核新增升级刀基础6与即时HP/能量/敌血不变。第五/六试满手仍耗瓶；手位子项已实现，穿插出刀的完整候选归属和整战胜因没有实证。
- 1913 F17胜14、幕间实际补44；F24锻造不回血，F28实回21到61，F29胜后46进F31。Q6 F7实回21到57，F8赢却损55至2，F9T2死亡。已有六局资源消费者共94战窗，77个观察退出、17个重启边界、0缺退出；这是观察资源链消费，不是完整候选派发验证或策略收益。六份原输出与resource-chain-summary.json保留。
- Q6 F8T4紧勒链states 282887/282888/282889/282891/282892敌血103→95→85→83→80。1913 F31T2 states 282767→282768能量保持3并实际建立1敏/4荆棘；T3两防御共12、后轮25→20，T4中段重接25、旧毒/力不沿用；死亡前已建毒雾没有下一轮兑现。原限定机制不自动给出弃牌自动触发/反伤/恢复的联合模型正确性。
- NHA F33首四试T1实14挡/损1/敌净扣8，后两试8挡/损7/敌净扣24；277248/277272原生结果为pending，后续弃牌完成又在277250/277274派回响。实际端点和初题候选的完整执行归属分开，actual_candidate_execution保持null。
- 不安油灯：K367 F30T2 states 217009→217010带毒刺击毒0→8，随后的217010→217011毒药8→15，不能所有后续都翻倍；SADL F45T1 232562→232563毒0→10；NHA F17T1毒0→10及F33六试X1萎靡减力/弱各2。NHA F33T2 283397→283399爪1→2、火箭30→20。三局81个相关实际施牌窗口另存lamp-observed-actions.json，仅这些目标与现场分支，不称81个独立首用或全部受控样本。

这些端点差允许复核实际代价；没有召唤/换相的选定窗口才比较敌净血差，不能推广为通用毛伤。新参数若日后拟合，必须按独立run和时间切分，SL同局同组，并在更晚独立局检验；本批未拟合或改变药价、HP护栏、SL门槛、终局曲线与目标排序。

## 当前源码与live祖先

核验时live为`fba193dfe31844e1dbde9f2ad7174427fcd446dc`；逐提交结果见source-ancestry.json。

| 实际源码提交 | live祖先 | 范围 |
|---|---|---|
| `e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a` | 是 | Model observed Silent opening HP loss in continuous fights |
| `6403fdcdadc803a092beb5165a068e22bf51c412` | 是 | Model observed Silent Cunning Potion generation and hand capacity |
| `5c7105ff0294466da8319f2934beda05c6040794` | 是 | Model observed ordinary Strangle losses for Silent |
| `c769739b97389fdc978b6515b83a38e3cd900f67` | 是 | Record candidate comparisons for Silent SL replacements |
| `5604982e13890e0e2bc8bf8246272e8267321c0b` | 是 | Log Silent A10 SL candidate resource comparisons |
| `ec29ea34b919344b707e57ba472ea210f9c39d62` | 是 | Fix observed Silent Crusher facing rounding |
| `f2c7cc1a7288893bceae0f0b20304a2b1fae5f57` | 是 | Replay tested Silent Crusher facing rounding on current live |
| `15ea09ad75a421d4bd65a820c187c8ee188186c8` | 否 | Model observed Silent Cunning Potion generation and hand capacity |
| `fc7042d1df0626e9e726f4bc912d9c6f626d908f` | 否 | Model observed Silent Royal Poison opening HP in continuous fights |

source-file-checks.json比较11个相关源码/工具叶：10个与live逐字节相同，card-model.ts仅两处Roy/Dai历史注释不同，完整差异保留base-live-selected.diff.patch。这里仅报告叶/祖先核验，不借此声称整树相同或重跑了历史dirty源码。候选审计现有实现明确scope=candidate_forecast/current_turn_prediction，并保留actual_turn_result=null、execution=unverified；没有整候选消费者联合验收，所以宽项不登记duplicate。

## 材料检查、失败保留与记录

facts-first-run.log保留首次材料夹具失败：234751按较早observed_ts取到上一张牌的弃牌选择帧，手数误成3→2；原脚本留analyze_facts.first.txt。原始相邻帧239620=选择中3手、239621=选择完成2手仍持药、239622=饮后5手药消失。改用动作ts定位，并同时要求目标药槽饮前存在、饮后消失，未放宽42次/3-2-0、基础6、资源不变的断言。修正后facts-second-run.log退出0、366项材料断言通过，另有14个实际端点窗口。这不是生产源码失败、撤源码试验或tsc/vitest通过。

没有生产源码变化，因此撤源码失败/恢复通过、tsc、vitest及源码用例数全部不适用，最终tests固定为null；未运行LLM、网络、play或Boss模拟池。没有需要合入的源码，不执行live合入、版本登记或规则双通知。铁甲及其他未观察分支没有改动。31个既有账本只经根learner/ledger.py补本批proposal/report追溯，不改claim、首证、prior、evidence、status或version；实际CLI回执与读回另存本目录。没有新经验或新代码提案ID，沿用本批十个已有ID。父学习要求及宽量化要求保持开放，waiting由调度器在新证据出现后重派。

工作树最终保持tracked clean，HEAD保持base。gitleaks及最终身份/工树读回见completion-checks.json。全部原日志只读；材料在本批learner/runs目录，未删除失败、旧提案或过程副本。

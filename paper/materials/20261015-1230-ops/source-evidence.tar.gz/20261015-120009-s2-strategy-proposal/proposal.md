# 静默猎手十项已领取提案逐项核验

记录时间：2026-10-15T12:11:58+08:00。批次：20261015-120009-s2-strategy-proposal。

本批为普通消费队列：task=strategy-proposal、character=silent、reason=proposal，worktree与派发一致，恰含以下十个proposal_ids；没有research_request、implementation_request或proposal_repair。手动专题文件属于另一批，不承接、不读取其研究正文。开工tracked clean，git merge --no-edit main返回Already up to date。完整基线为`93cce82eebf435770a60913f22f5d690f5606ef8`。

结论：十项均waiting。已实现的局部子项经实际live祖先核验，不代表宽提案整体已实现。无源码、生产测试、经验库、游戏版本或live合入；不申请新提案ID，不把本批材料校验写成代码自测成功。未来证据不足时仍保留现行规则。

输入范围为十个派发锚点与原提案明确关联的五个静默局1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。共15局，runs.jsonl角色均SILENT；K367 A1、SADL A7、F4Q A9，其余A10。各局code均带dirty，不能用当前源码冒充当时完整执行树；SL尝试不是独立局。本批没有用这些相关失败链拟合新参数，也没有借其他角色知识补结论。

## 1. silent-proposal-08eaa60bcc449852

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md`。原Markdown SHA256：`4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`，本批已核一致。

账本：silent-0019, silent-0020。来源任务：experience-update；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：KEN58SH9SLZ6 A10，F3T2/F4T1/F5T2/F11T1–2/F15T1；F12/F16回复；F17六试。

旧：现有用药/持有规则。候选：按实际七药和HP接续审计，缺成对整战前保留现值。

反例与限制：F15零损同时用了发光/技能两药；未喝药也零损未知。

预期与验证：固定核七饮、六胜战净损46、营火27/29及五次SL恢复348；后续按独立run时间留出不饮用/留药对照。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。KEN F3/4/5/11/15七次饮用、六胜战净损46和两次真实营火回复已复核；F15零净损同时耗两药。缺相同入口、后续抽牌及药栏下不饮用或留到Boss的成对整战结果，不能据此重拟持药价。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 2. silent-proposal-92920295a648b540

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md`。原Markdown SHA256：`f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`，本批已核一致。

账本：silent-0228, silent-0255。来源任务：postmortem；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：TXZ6RVMQA09D A10，F48第二/三试T6与第三试T10，F49T1。

旧：已有连续两战目标及低可信限制。候选：首胜退出、后场可操作入口、两战结局联合验收。

反例与限制：第三试省3血同时少扣9敌血，后续生成/抽序也变；首胜后仍开场死亡。

预期与验证：固定states 281479/281484、281535/281539、281563/281565/281566；未来保持后续抽序/生成/药栏验证两战，不据未校准0%改SL。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。TXZ F48第二/三试T6实损3/0且敌净扣36/27，第三试首胜4血而F49开场4→0；开场子项已有live祖先e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a。缺同后续抽牌、生成与药栏的两战通关替线，不能调整SL门槛或把首胜当连续通关改善。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 3. silent-proposal-a327449c331efbc1

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md`。原Markdown SHA256：`e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`，本批已核一致。

账本：silent-0079, silent-0018。来源任务：postmortem；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：WQZVENQ7DTRP A10，F33第二/三试T9、第六试T7及末T11。

旧：死亡率饱和时探索未试线。候选：联合列HP、输出、毒、沙坑与未知后续；排序阈值待验证。

反例与限制：T9多付9血换15输出；T7又能多付4血换一个沙坑回合，不能统一禁付血或禁逃离。

预期与验证：固定T9 states 282075→282079与282144→282148；T7 282066→282072对282330→282336；后续两边界均需完整受控后继与独立胜局。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。WQ F33第二/三试T9复现多损9血换多扣15敌血；第六试T7又是多付4血换沙坑末值4→5且敌净扣同为24。已有候选审计，但缺双边界完整受控后继及独立胜局，无法验证新的探索排序或固定血价阈值。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 4. silent-proposal-a099e89437e942bb

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md`。原Markdown SHA256：`e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`，本批已核一致。

账本：silent-0030, silent-0257, silent-0258。来源任务：experience-update；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：九静默局A7/A9/A10，42次饮用；WQZVENQ7DTRP F33第五/六试T11；NB8KCF6HRGVF F31T5；SADL3CGYTGSR F8T1。

旧缺口中的确定生成/手位已实现。候选剩余：计划妥当保留选择、合法出刀穿插、完整派发/恢复联合验证。

反例与限制：满手仍耗瓶只添0，不等于插刀必能救局；未执行完整顺序没有实际胜线。

预期与验证：facts.json保留42次decision/state行、手数、药栏、基础6与升级状态；以后用固定完整派发/SL恢复输入验证，不重复实现容量子项。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。九局42次狡诈饮用复核为37次添3、2次添2、3次添0，确定生成及手位子项已由实际live祖先6403fdcdadc803a092beb5165a068e22bf51c412覆盖。整项仍缺计划妥当选择、穿插出刀、完整候选派发与SL恢复的联合消费者校准，不把子项覆盖登记为整项duplicate。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 5. silent-proposal-47910f82a1fdd98f

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md`。原Markdown SHA256：`d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`，本批已核一致。

账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。来源任务：experience-update；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：TXZ6RVMQA09D A10 F43/F45/F46/F48/F49开场、F48T6；WQZVENQ7DTRP A10 F33T7/T9。

旧：已有连续两战及本组合开场扣血。候选剩余：资源接续/SL双向比较及未观察组合校准。

反例与限制：同持小血瓶的旧组合净值不能拆作单件顺序；SL恢复不能当奖励/回血；省血少伤不证连战赢。

预期与验证：固定核五次出牌前净4及双向血价；未知回复/复活顺序保持未知，需留药/路线/SL成对完整后继。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。TXZ已观察遗物组合五次出牌前净扣4及WQ双向血价均核对；e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a是live祖先，旧fc7042d1df0626e9e726f4bc912d9c6f626d908f不是。缺留药/路线/SL完整后继对照与未知回血复活组合的结算顺序，不能关闭整个资源价值要求。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 6. silent-proposal-f1374df72d8e6a25

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md`。原Markdown SHA256：`df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`，本批已核一致。

账本：silent-0019, silent-0020, silent-0050, silent-0253。来源任务：postmortem；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：1913SE84AXQF A10 F17/F24/F28/F29/F31；Q6M2Y34MWKRE A10 F2T1/T3、F8T1/T7/T8、F9T2。

旧：现行护栏/药价/终局权重。候选：先审计实际胜后HP药栏和临时/持续药效，再作独立校准。

反例与限制：Q6早敏捷候选没有完整实打；F5/F6留药零损反对一律早喝。1913 F24改锻造导致条件改变。

预期与验证：资源消费者分别复现1913 F31入46和Q6 F9入2；隔离紧勒等机制误差，收同入口/预算/后续的整战成对药时结果。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。1913 F29胜后46血接F31、Q6 F8胜后2血接F9死亡的实际资源链已核；缺隔离机制误差后同入口、同预算、同后续的未用/早用/留药成对整战结果。单题早喝候选未完整执行，不能校准药水持有价或终局权重。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 7. silent-proposal-38a49e6c97f31eea

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md`。原Markdown SHA256：`6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`，本批已核一致。

账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。来源任务：experience-update；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：Q6M2Y34MWKRE A10 F8T4、F9T1–2；1913SE84AXQF A10 F17与F31T2–4；K3676LU8B0UH A1 F9。

旧缺口中的普通无挡紧勒已实现，普通主动磨蚀已有受限模型。候选剩余：弃牌自动触发、增益分源、重接、逐击反伤/再生联合校准。

反例与限制：有能力不等已建立，重接净差不等毛伤；T4反杀不能取消已发动攻击。升级/叠层/自动出牌不可从普通子项外推。

预期与验证：固定紧勒103→95→85→83→80；1913 282767→282768能量3不变而建1敏/4荆棘；282776→282777损5并重接25；联合恢复/执行归属仍缺。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。Q6 F8T4普通紧勒逐步敌血103→95→85→83→80已复核；受限普通分支已有live祖先5c7105ff0294466da8319f2934beda05c6040794。1913弃磨蚀、重接及反伤仍需与增益分源、再生、自动触发/SL恢复作完整联合消费者校准，不能以一个普通无挡子项关闭整项或外推升级叠层。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 8. silent-proposal-ef0e38a5dbd3bc07

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md`。原Markdown SHA256：`d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`，本批已核一致。

账本：silent-0019, silent-0020, silent-0021。来源任务：experience-update；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：1913SE84AXQF A10 F24/F28/F29/F31（未来F32未到）；Q6M2Y34MWKRE A10 F3/F7/F8/F9。

旧：实际路线、休息及资源估值。候选：只用实际完成回复、接续强制走廊与实建能力；参数待独立验证。

反例与限制：1913改变营火动作须分离条件变化；Q6已休息，不能说拒绝回复。未来营火和未取得组件不算现有资源。

预期与验证：六局资源消费者94窗口单列17个重启；两目标链核实际休息/锻造/事件及入口HP。要另一完整路线/营火/药时的受控结果才改排序。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。1913 F24实际锻造、F28回21、F29胜损15而46入F31；Q6 F7回21后F8仍损55，2血入F9。没有另一营火、事件、路线与药时的完整受控结果；条件改变与同条件模型误差须分开，两败不足拟合资源权重或保证未来营火可达。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 9. silent-proposal-7f820c02d39bfaea

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md`。原Markdown SHA256：`bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`，本批已核一致。

账本：silent-0079。来源任务：postmortem；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：NHA2KW0RB7VP A10 F33六试T1，decisions 277248/277250/277272/277274；T4结局。

旧：饱和notWorse与探索。候选：审计原答/替线完整即时血价、击杀推进及实际派发，阈值待验证。

反例与限制：首四试14挡损1，后两试8挡损7，敌净扣8→24而均未杀一侧；弃牌重规划不能把初题算成整线执行。

预期与验证：固定states 283391→283397、283478→283483、283502→283507；原生pending/后续completed分开；候选预测保留actual_turn_result=null/execution=unverified。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。NHA F33首四试T1实损1/敌净扣8，对后两试实损7/敌净扣24已核；277248/277272的生存者仍是pending，弃牌后另题才派回响。live祖先c769739b97389fdc978b6515b83a38e3cd900f67与5604982e13890e0e2bc8bf8246272e8267321c0b只保存预测。缺同预算饱和排序校准、整候选派发归属与成对完整后继。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 10. silent-proposal-04b6b430759815ed

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md`。原Markdown SHA256：`188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`，本批已核一致。

账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。来源任务：experience-update；实现任务：strategy-proposal，本批20261015-120009-s2-strategy-proposal。角色、进阶、证据层/回合：NHA2KW0RB7VP A10 F17T1/F33T1–2；K3676LU8B0UH A1 F30T2；SADL3CGYTGSR A7 F45T1。

旧缺口中的爪朝向取整已实现。候选剩余：油灯首次消费状态、现场增益和已兑现能力窗口的联合验证。

反例与限制：K367同T2首刺4→8后毒药只再加7，反对拥有油灯就每次翻倍；已有显示1再乘1.5取整不能当实际2。

预期与验证：固定217009/217010/217011、232562/232563、283394/283395与283397/283399；先取得可靠首次消费与跨动作/新战/SL来源，其他X/升级/负面组合仍未知。 本批仅确认可追溯事实；尚不能声明选线/整局收益。未来拟合按独立run及开始时间切分，SL同局同组，当前发现集不得同时冒作独立留出。

处置：**waiting**。NHA F33T2爪1→2且火箭30→20已核，取整子项已有live祖先ec29ea34b919344b707e57ba472ea210f9c39d62及重放f2c7cc1a7288893bceae0f0b20304a2b1fae5f57。油灯已见毒4→8、5→10和普通X1萎靡减力/弱各2，但缺可靠首次消费来源、跨动作/新战/SL恢复联合验证；其他X值升级组合和能力整战后继未知。

回退：本批未改行为，无新源码可回退。未来实现应隔离本角色充分观察分支，失败仅撤该实际提交，保留旧提案、失败材料与并行知识数据；实际规则上线后按既有授权通知Roy。

## 材料与下一次重派边界

证据入口为evidence/与evidence-linked/的原始提取及各自evidence-manifest.json；evidence-checks.json逐行核身份、source_size、offset/bytes/SHA、原JSON相等与输出哈希。facts.json记录366项固定材料断言、42次狡诈饮用与14个实际端点窗口，actual_candidate_execution保持null。resource-chain-summary.json与六份原资源消费者输出保留退出、死亡和SL重启边界。

这十项只保持等待新证据重派；不关闭量化学习父要求，不将排队/审计产物当实际上线或消费者采用。没有发现本批新增、不同于原提案已存限制的反证结论；本批不制造重复通知或重复提案。

# 本批十项策略提案复核

批次：20261015-120009-strategy-proposal；角色：silent；基线：`93cce82eebf435770a60913f22f5d690f5606ef8`。
本文件是已领取原提案的本批处置材料，不创建新游戏规则、经验或重复提案ID；十份原Markdown均按队列SHA核对，未改原文。没有research_request或implementation_request绑定；旧deck-size请求属于另一批，不承接。

## 证据、已实现范围与结论

六局均经runs.jsonl核对为Silent A10。八流共8444原所属行按offset/bytes/SHA/原JSON/显式身份复核；52项材料事实断言通过。详见evidence-manifest.json、evidence-verification.json及facts-verification.json。样本仅六个已派发局，SL次数不作独立局。

已确认的局部实现包括候选原答/护栏/SL阶段快照、持牌保守损血、药值未知与无药模型参考、SL预测资源比较、单动作派发回执，以及巨兽阶段和末态资源展示。实际live源码祖先及逐叶SHA在source-readback.json；这些局部功能不覆盖完整执行归属、受控整战或游戏权重量化。

## 逐项处置

### silent-proposal-366288801d9150d9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md。
账本：silent-0079、silent-0176；来源任务：postmortem → strategy-proposal；领域：sl/combat。
证据：751FN9QM9MHQ，F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820。
处置：waiting。751 F17 T2/T7/T13同指纹净血差已复核；现有候选/B2/持牌审计仍未把抽弃续问后的完整执行线、逐源实果与原答闭合，缺受控整战后继及独立验证，不能定SL额外失血阈值。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-85929bdfc8a3fc1b

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md。
账本：silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176；来源任务：postmortem → strategy-proposal；领域：combat/potion。
证据：751FN9QM9MHQ，F13 T3；decision 272361；F17 T7/T13/T17持牌与弃牌范围。
处置：waiting。751 F13 T3有药与plan5无药参考均8/8只属模型，plan3后轮7/8仍用药；缺无药实际整战、留至boss的受控分支及弃呼唤后完整候选归属，不能校准持药血价或改弃牌。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-efd9f83ee9e1a6dc

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md。
账本：silent-0079、silent-0176；来源任务：experience-update → strategy-proposal；领域：sl/combat。
证据：751FN9QM9MHQ，F17 T2/T7/T13；与前一SL来源交叉，不增加独立样本。
处置：waiting。751三组双向血价及六次同局均败已核；已有局部诊断不等于完整候选实果，缺单因受控后继和时间靠后的独立验证，不能据相关SL拟合新探索排序。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-131042659448ae74

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md。
账本：silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176；来源任务：experience-update → strategy-proposal；领域：combat/potion。
证据：751FN9QM9MHQ，F13 T3、F17 T3/T5/T7/T13/T17；各机制和已建能力分源。
处置：waiting。已核持牌/药值未知诊断及候选阶段/单动作回执，actual_turn仍null；缺逐源攻击/毒/荆棘与能力兑现的完整归属、无药跨战分支和校准，不将部分事实诊断当整项实现。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-990f054036609447

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md。
账本：silent-0102、silent-0019、silent-0020；来源任务：experience-update → strategy-proposal；领域：combat/sl。
证据：KV0JHNJCKXLS，F33第4/5试T5；decisions 273400/273450/273451；路线/休息仅实际分支。
处置：waiting。KV F33第4/5试T5删致命毒药后敌净扣36→29、两次零损已复核，均无当轮保血收益；缺保持后轮条件的受控整战及路线/休息未执行分支，不能拟合SL或终局权重。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-e18d3f18e6cac2a0

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md。
账本：silent-0017、silent-0250、silent-0011、silent-0027、silent-0046；来源任务：postmortem → strategy-proposal；领域：combat/potion/sl/terminal。
证据：L9SGRBB5R698 F17 T14、PU80F84P6HPN F17 T17及胜次T15、YQL8RZ8BWN1E F17 T10。
处置：waiting。巨兽阶段/末态资源展示已有live祖先源码，旧占位血仍保留作历史tie-break；L9失败、PU第五次F17胜与YQL六败均保留，缺新参考排序完整受控后继及资源/结局校准，不能将整项标duplicate。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-9733bb80f445aeae

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md。
账本：silent-0017、silent-0019、silent-0020、silent-0250；来源任务：experience-update → strategy-proposal；领域：combat/potion/sl/terminal。
证据：YQL8RZ8BWN1E，F17第6试T10；decision 274087、states 280160/280161。
处置：waiting。YQL F17第6试T10实药前后毒2→8，26血/13挡/41自爆不变已核；已有阶段提示不证明提前喝、不喝、留药及改SL排序的整战收益，缺这些受控分支。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-c51468c5e8ba6668

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md。
账本：silent-0019；来源任务：postmortem → strategy-proposal；领域：potion。
证据：KEN58SH9SLZ6，F3T2/F4T1/F5T2/F11T1、T2/F15T1；七个实际槽位变化。
处置：waiting。KEN七次use_potion均有对应槽位消耗，三次初始pending回执不单独当效果完成；缺随机选牌/发光水重问后完整收益归属及F15不喝/留至boss的整战分支，无法量化逐槽持有值。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-86a7db08d1a31976

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md。
账本：silent-0079、silent-0021、silent-0125、silent-0005、silent-0176；来源任务：postmortem → strategy-proposal；领域：combat/sl。
证据：KEN58SH9SLZ6，F17第4/5试T10、第4/6试T5；decisions 274505/274568、274484/274601。
处置：waiting。KEN F17第4/5试T10多损6仅多净扣2，第4/6试T5省2却步法T5延至T9均复核；缺逐源/完整候选归属、受控整战及独立新局验证，不能设6血/2伤通用准入阈值。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

### silent-proposal-e282a9131b99129a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md。
账本：silent-0021、silent-0079、silent-0125、silent-0176；来源任务：experience-update → strategy-proposal；领域：combat/sl。
证据：KEN58SH9SLZ6，F17 T5/T10及T2护栏；与前一来源交叉，不增加独立样本。
处置：waiting。KEN双向取舍与原经验一致，六次SL属于同一局；现有预测和单动作回执不闭合完整执行与能力后继，缺受控胜线及后期独立验证，保留原探索/HP护栏。
验证方法：先用已冻结原帧、同指纹及跨轮实果核验事实；补完整动作/选牌/抽牌/重问归属后才能验证候选兑现。涉及排序或药水价值时，需要本角色受控后继与按独立局/真实时间切分的后期验证；不从相关SL拟合固定阈值。
反例与预期：省当轮血不等于保留持续能力或整战更优；PU巨兽有胜次，不把全历史概括为必败。完整反事实仍未知，本批预期仅为可追溯复核，无已验证胜率收益。回退：本批无源码修改可撤，保留原规则及所有材料；原提案各自未来实现须用独立提交回退。

## 边界

只分析派发六局和本角色知识，未读取其他角色知识、游戏二进制或密钥。未运行模型/API、模拟池、play或安装依赖，未改变其他角色行为。未改源码/知识/经验，未合live、未分配版本、未登记implemented或shipped。现有shipped账本条目只补追溯，不降格/重写首证、claim、prior、evidence或version。
十项均waiting的原因分别保存在proposal-results.json，父学习要求保持。新规则未成立，因此没有新增代码提案ID或规则上线通知。

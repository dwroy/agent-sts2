# 静默猎手策略提案批次回报

生成时间：2026-10-15T12:10:51+08:00。
批次：20261015-120009-strategy-proposal；task=strategy-proposal；character=silent。
结论：十项原提案全部waiting。局部事实与已有实现已核，但未补足完整执行归属、受控整战或持药反事实；本批没有新增源码或游戏规则，不冒称实现、重复实现、shipped或父要求关闭。

## 身份与基线

- 完整base与最终HEAD：`93cce82eebf435770a60913f22f5d690f5606ef8`；开工git status干净，git merge --no-edit main返回Already up to date。普通队列只处理该batch的十个proposal_ids，未领取其他提案。
- learn.json本行reason=proposal，绑定本工作树；没有research_request、implementation_request或proposal_repair。根deck-size请求仍绑定20261010另一批，不能套用为本批专题；没有本批授权实现任务附文，未进入第1.3节。派发快照在dispatch-binding.json。
- 原生会话01a13db7-df82-76e3-a594-a43ad93ffcf4的turn_context实核gpt-6.1-sol/xhigh，启动命令service_tier=default。它与任务模板的high字样不同；实际强度按原会话记录报告，未切换线程/模型/权限或降低强度。native读取仅本人会话上下文字段，见runtime-readback.json。
- 已读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol与learning-code-proposals。未承接运维角色，未改运维prompt。

## 冻结证据与材料验证

派发局：751FN9QM9MHQ,KV0JHNJCKXLS,YQL8RZ8BWN1E,L9SGRBB5R698,PU80F84P6HPN,KEN58SH9SLZ6。六局runs.jsonl均明确Silent A10。L9的历史大脑为deepseek (for codex)，其余runs字段有Codex记录但各流仍有历史DeepSeek标记；全部运行码带dirty。这里用于角色实盘机制与资源核验，不把历史标签消去、不恢复不存在的dirty执行树，也不宣称六局全为纯Codex战绩。

按共用learner/extract_evidence.py提取八流，每流冻结自身source_size；各流截点不同，不声称全日志同一原子快照。逐选中行重新seek原文件核offset、bytes、SHA、LF、原JSON相等及显式run_id/state.run_id/run/fingerprint.run身份；冲突身份不接收。原始selected输出未覆盖。

| 流 | 所属行数 | 冻结source_size |
|---|---:|---:|
| states | 4167 | 13008716395 |
| decisions | 4071 | 1556580259 |
| sl-attempts | 43 | 40310132 |
| run-config | 6 | 1747793 |
| run-plans | 21 | 8008911 |
| brain | 130 | 565636242 |
| runs | 6 | 333707 |
| fight-plans | 0 | 2233957 |

总计8444行；十份原Markdown的SHA与专用队列一致。states/decisions/brain源扫描各有2/2/1条无法解析行，计数保留，未补正文归属。fight-plans此截点选中0行，只说明范围未选到，不断言原流或历史不存在；本批不做旧截点复核。具体SHA和逐局计数见evidence/evidence-manifest.json及evidence-verification.json。
材料脚本verify_evidence.py、verify_facts.py退出0；后者52项原材料断言均通过，记录facts-verification.json。这些是实盘材料/字节核验，不是生产tsc、vitest或源码回归测试。

## 实盘结论、反例与限制

| 局与窗口 | 原/替线的实际净损血 | 敌HP实际净扣 | 限制 |
|---|---:|---:|---|
| 751 F17 T2，第1/3试 | 13 / 18 | 9 / 18 | 同指纹；后轮动作不同 |
| 751 F17 T7，第2/4试 | 13 / 23 | 12 / 18 | 未决弃牌影响绝对预测，实际血差仍10 |
| 751 F17 T13，第1/6试 | 8 / 2 | 17 / 11 | 省6血同时少6净输出 |
| KEN F17 T10，第4/5试 | 15 / 21 | 2 / 4 | 无实体现场；B2 .385/.127、差−.2583、SE .0132 |
| KEN F17 T5，第4/6试 | 7 / 5 | 1 / 2 | 含续问追加小刀；步法首次T5延至T9 |
| KV F33 T5，第4/5试 | 0 / 0 | 36 / 29 | 删毒当轮没有保血收益；非整战因果 |

这六组decisions指纹分别完全相同。窗口值来自相邻玩家轮初的实际状态摘要，包含当轮全部续问/动作与已发生敌阶段，未把净HP差细分成卡牌/毒/荆棘毛伤，也没有自动归属为一条原候选完整兑现；完整候选归属在材料中保留null。
751 F13 T3：用药plan2与完全无药参考plan5模型即时均损8、牌伤26/16；五轮8样本均8/8只属模拟。本轮不喝plan3的后续7/8仍喝药，不能混作整战不喝。缺表成本0不证持有价值为0；未执行plan5与留至boss支线仍未知。
YQL F17第6试T10：states280160→280161毒2→8，但26血、13挡、41自爆及占位体HP未变；26+13−41=−2只是该记录末态代数差，不是新必死阈值或替线存活预测。六次本体结束后首次占位玩家轮T13/T13/T12/T13/T13/T10，对应本体结束T12/T12/T11/T12/T12/T9。
巨兽反例必须保留：L9 F17六次无胜，YQL六次无胜，PU F17第五次实际won；不能从两败局推出全部构筑必败，不能把本体结束、占位体减血或活更久独立当成整战获胜/新排序收益。
KEN七次实际use_potion及槽位消耗逐一核对：F3T2攻击、F4T1稳定、F5T2速度、F11T1虚弱、F11T2攻击、F15T1发光水、F15T1技能。三次初始结果为pending(unstable)，通过后继实际槽位核消耗，没有把pending当完整效果。弃药动作0；六次F17轮初均75血。仍缺随机选牌/发光水之后完整收益归属及F15不喝/留药整战对照。
同局多次SL是相关尝试；本批不拟合数值权重或阈值，不将相同六局分为训练与独立验证。原经验的局部观察保持，没有发现需反转旧claim的新反证；未知不包装为已验证规则。

## 当前live局部实现读回

检查时actual live HEAD为`fba193dfe31844e1dbde9f2ad7174427fcd446dc`。下列源码commit均为该HEAD真实祖先；source-readback.json保存11叶逐SHA和祖先结果。

| 已有局部实现 | 真实live源码commit |
|---|---|
| 原答/护栏/SL预测快照与持牌事实 | 05cd292c6f01bb31e406473d3a9843e659d62b93 |
| 药值未知及同题无药预测 | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 |
| 巨兽当前阶段/残壳药水观察 | d5e20aa4dd44168ce30944dfcce74f8322144953 |
| 巨兽阶段与结束前资源展示 | 0d092f6b928a6221eabf3516abad25c48ceaac9c |
| 单动作派发回执 | bade647f9fe4c9103b40e2f26b26296692ad24b7 |
| SL两线候选及当前轮资源预测 | a8b1f8be153fe4f3a34146117546c2178f2e446b |

11叶中10叶与本树逐字节相同，explore.ts只见三段Roy/Dai历史注释署名差，保留live-explore-historical-comment-difference.patch，未覆盖。当前源码用于核功能覆盖，未称历史对局执行该树。
消费者接线已读combat-plan.ts和hand/loop.ts：持牌/药值/巨兽事实进入候选题面；原答、护栏后、SL后候选进入selection_audit，单动作派发进入selection_dispatch。候选actual_turn=null、派发whole_plan_executed=null/state_effect_verified=false，回执限单次动作；不能据此关闭重规划后的整候选归属或全战校准。巨兽占位HP仍按现行legacy tie-break参与参考排序，阶段文字明确不当本体进度，本批不改新排序。

## 十项逐项处置

详细证据局号/层/回合/账本、原Markdown、反例、拟验证与回退逐项见proposal.md；proposal-results.json与最终JSON列同一批十个id。

- `silent-proposal-366288801d9150d9`；账本silent-0079、silent-0176：waiting。751 F17 T2/T7/T13同指纹净血差已复核；现有候选/B2/持牌审计仍未把抽弃续问后的完整执行线、逐源实果与原答闭合，缺受控整战后继及独立验证，不能定SL额外失血阈值。

- `silent-proposal-85929bdfc8a3fc1b`；账本silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176：waiting。751 F13 T3有药与plan5无药参考均8/8只属模型，plan3后轮7/8仍用药；缺无药实际整战、留至boss的受控分支及弃呼唤后完整候选归属，不能校准持药血价或改弃牌。

- `silent-proposal-efd9f83ee9e1a6dc`；账本silent-0079、silent-0176：waiting。751三组双向血价及六次同局均败已核；已有局部诊断不等于完整候选实果，缺单因受控后继和时间靠后的独立验证，不能据相关SL拟合新探索排序。

- `silent-proposal-131042659448ae74`；账本silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176：waiting。已核持牌/药值未知诊断及候选阶段/单动作回执，actual_turn仍null；缺逐源攻击/毒/荆棘与能力兑现的完整归属、无药跨战分支和校准，不将部分事实诊断当整项实现。

- `silent-proposal-990f054036609447`；账本silent-0102、silent-0019、silent-0020：waiting。KV F33第4/5试T5删致命毒药后敌净扣36→29、两次零损已复核，均无当轮保血收益；缺保持后轮条件的受控整战及路线/休息未执行分支，不能拟合SL或终局权重。

- `silent-proposal-e18d3f18e6cac2a0`；账本silent-0017、silent-0250、silent-0011、silent-0027、silent-0046：waiting。巨兽阶段/末态资源展示已有live祖先源码，旧占位血仍保留作历史tie-break；L9失败、PU第五次F17胜与YQL六败均保留，缺新参考排序完整受控后继及资源/结局校准，不能将整项标duplicate。

- `silent-proposal-9733bb80f445aeae`；账本silent-0017、silent-0019、silent-0020、silent-0250：waiting。YQL F17第6试T10实药前后毒2→8，26血/13挡/41自爆不变已核；已有阶段提示不证明提前喝、不喝、留药及改SL排序的整战收益，缺这些受控分支。

- `silent-proposal-c51468c5e8ba6668`；账本silent-0019：waiting。KEN七次use_potion均有对应槽位消耗，三次初始pending回执不单独当效果完成；缺随机选牌/发光水重问后完整收益归属及F15不喝/留至boss的整战分支，无法量化逐槽持有值。

- `silent-proposal-86a7db08d1a31976`；账本silent-0079、silent-0021、silent-0125、silent-0005、silent-0176：waiting。KEN F17第4/5试T10多损6仅多净扣2，第4/6试T5省2却步法T5延至T9均复核；缺逐源/完整候选归属、受控整战及独立新局验证，不能设6血/2伤通用准入阈值。

- `silent-proposal-e282a9131b99129a`；账本silent-0021、silent-0079、silent-0125、silent-0176：waiting。KEN双向取舍与原经验一致，六次SL属于同一局；现有预测和单动作回执不闭合完整执行与能力后继，缺受控胜线及后期独立验证，保留原探索/HP护栏。

## 账本、验证与上线结果

只经根learner/ledger.py update追加本角色16个既有账本的本批proposal/report追溯与note；不重复写复盘、不追加旧支持样本、不改原claim/首证/prior/证据/status/version、不标shipped。CLI输入、stdout/stderr和前后不变量读回在ledger-update-input.jsonl、ledger-update-stdout.txt、ledger-update-stderr.txt、ledger-trace-readback.json及ledger-invariants-before.json。既有条目已shipped，不能因本批waiting降为proposed；本批无新学习条目。
没有新增游戏知识结论或待实现方向，不用code_proposals add制造重复ID。code_proposals字段仅列本批实际已领取CLI ID；implementation_domains为空表示没有实际源码实现，并不删除原提案domains。专用队列状态留给调度器按proposal_results追加，本模型不直接改队列。
源码/知识/经验修改：无；fixes=[]；新提交：无；merged=null；发布版本：无。未执行第4节live变更动作；未运行play、网络/API、额外模型或模拟池、不推送、不安装依赖。无规则上线，因此未生成Roy双通知或新的decision-log上线行；没有新反证通知。
生产tsc=null、vitest=null、cases=null；撤源码失败/恢复通过均不适用，没有撤源码也没有声称生产检查通过。未改代码/无待提交源码，本批不重跑生产全套。材料核验与先前完整宿主绿不替代本批源码测试。
工具现场限制：一次只读工具在bubblewrap预扫描报无关路径不存在，随后重试成功；早期两个猜测源码文件路径不存在，已按实际文件重读，未据此判证据缺失。日志原有非法行与全部材料保留，非生产代码测试失败。
最终完整JSON：final-report.json。报告与提案交运维按原调度验收；本批worktree不自行删除，父学习请求与等待新局的十项保持。

最终验收：final-validation.json核HEAD等于base、git status --porcelain为空、tracked diff为0、十项原提案SHA未变及逐项处置完整。本批材料gitleaks dir --redact退出0，见gitleaks-result.json；该扫描不冒称源码提交检查或生产测试。

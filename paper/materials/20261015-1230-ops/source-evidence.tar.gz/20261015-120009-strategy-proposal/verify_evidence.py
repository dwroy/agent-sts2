import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("evidence_extractor", OUT.parents[1] / "extract_evidence.py")
EXTRACTOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXTRACTOR)


def main():
    manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
    binding = json.loads((OUT / "dispatch-binding.json").read_text())
    runs = binding["row"]["runs"]
    rows = {}
    checks = []
    for entry in manifest:
        stream = entry["stream"]
        path = OUT / "evidence" / (stream + ".evidence.jsonl")
        encoded = path.read_bytes()
        assert hashlib.sha256(encoded).hexdigest() == entry["output_sha256"]
        counts = collections.Counter()
        items = []
        source = Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")
        with source.open("rb") as handle:
            for line in encoded.splitlines():
                item = json.loads(line)
                assert item["run_id"] in runs
                assert item["source"] == str(source)
                assert item["offset"] + item["bytes"] <= entry["source_size"]
                handle.seek(item["offset"])
                raw = handle.read(item["bytes"])
                assert raw.endswith(b"\n")
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                assert EXTRACTOR.run_identity(item["row"]) == item["run_id"]
                counts[item["run_id"]] += 1
                items.append(item)
        assert {run: counts[run] for run in runs} == entry["counts"]
        rows[stream] = items
        checks.append({"stream": stream, "verified_rows": len(items), "counts": dict(counts),
                       "source_size": entry["source_size"], "output_sha256": entry["output_sha256"]})
    run_rows = {}
    for item in rows["runs"]:
        row = item["row"]
        assert row["character"].lower() == "silent" and row["ascension"] == 10
        run_rows[item["run_id"]] = row
    assert set(run_rows) == set(runs)
    for item in rows["states"]:
        state = item["row"].get("state", item["row"])
        run = state.get("run")
        if isinstance(run, dict) and run.get("character_id"):
            assert run["character_id"].lower() == "silent" and run["ascension"] == 10
    proposals = json.loads((OUT / "assigned-proposals.json").read_text())
    for proposal in proposals:
        assert proposal["character"] == "silent"
        assert set(proposal["runs"]) <= set(runs)
        assert hashlib.sha256(Path(proposal["proposal"]).read_bytes()).hexdigest() == proposal["proposal_sha256"]
    result = {"streams": checks, "total_verified_rows": sum(x["verified_rows"] for x in checks),
              "run_identity_and_character": True, "proposal_count": len(proposals),
              "proposal_markdown_sha256_verified": True, "runs": run_rows}
    (OUT / "evidence-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "runs"}, ensure_ascii=False))
    for stream in ["states", "decisions", "sl-attempts", "run-config", "run-plans", "brain", "fight-plans"]:
        if rows[stream]:
            first = rows[stream][0]
            print("SCHEMA", stream, first["line"], list(first["row"]))
    target_decisions = {272361, 272434, 272575, 272531, 272652, 272483, 272820,
                        274087, 274484, 274601, 274505, 274568, 274354}
    selected = [x for x in rows["decisions"] if x["line"] in target_decisions]
    (OUT / "selected-decisions.json").write_text(json.dumps(selected, ensure_ascii=False, indent=2) + "\n")
    for item in selected:
        row = item["row"]
        print("DECISION", item["line"], item["run_id"], row.get("floor"), row.get("turn"),
              row.get("label"), list(row.get("log", {})))


if __name__ == "__main__":
    main()

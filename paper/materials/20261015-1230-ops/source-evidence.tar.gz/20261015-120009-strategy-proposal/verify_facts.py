import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
CHECKS = []


def check(name, actual, expected):
    CHECKS.append({"name": name, "actual": actual, "expected": expected, "ok": actual == expected})


def load(stream):
    return [json.loads(line) for line in (OUT / "evidence" / (stream + ".evidence.jsonl")).open()]


def enemy_hp(text):
    match = re.fullmatch(r".+ (\d+)/(\d+)", text)
    assert match
    return int(match[1])


def main():
    decisions = {x["line"]: x["row"] for x in load("decisions")}
    states = {x["line"]: x["row"]["state"] for x in load("states")}
    attempts = {(x["run_id"], x["row"]["floor"], x["row"]["attempt"]): x for x in load("sl-attempts")}
    pairs = [(272434, 272575), (272531, 272652), (272483, 272820),
             (274505, 274568), (274484, 274601), (273400, 273450)]
    for a, b in pairs:
        check(f"同指纹 decisions {a}/{b}", decisions[a]["fingerprint"], decisions[b]["fingerprint"])
    windows = []
    for run, floor, attempt, turn, expected in [
        ("751FN9QM9MHQ", 17, 1, 2, [13, 9]), ("751FN9QM9MHQ", 17, 3, 2, [18, 18]),
        ("751FN9QM9MHQ", 17, 2, 7, [13, 12]), ("751FN9QM9MHQ", 17, 4, 7, [23, 18]),
        ("751FN9QM9MHQ", 17, 1, 13, [8, 17]), ("751FN9QM9MHQ", 17, 6, 13, [2, 11]),
        ("KEN58SH9SLZ6", 17, 4, 10, [15, 2]), ("KEN58SH9SLZ6", 17, 5, 10, [21, 4]),
        ("KEN58SH9SLZ6", 17, 4, 5, [7, 1]), ("KEN58SH9SLZ6", 17, 6, 5, [5, 2]),
        ("KV0JHNJCKXLS", 33, 4, 5, [0, 36]), ("KV0JHNJCKXLS", 33, 5, 5, [0, 29]),
    ]:
        item = attempts[(run, floor, attempt)]
        turns = {t["turn"]: t for t in item["row"]["summary"]["turns"]}
        a, b = turns[turn], turns[turn + 1]
        actual = [a["hp"] - b["hp"], enemy_hp(a["enemies"]) - enemy_hp(b["enemies"])]
        check(f"{run} F{floor} 第{attempt}次 T{turn} 实际净损血/敌净扣", actual, expected)
        windows.append({"run": run, "floor": floor, "attempt": attempt, "turn": turn,
                        "sl_source_line": item["line"], "before": a, "next_turn": b,
                        "hp_net_loss": actual[0], "enemy_hp_net_drop": actual[1],
                        "damage_source_attribution": None, "complete_candidate_attribution": None})
    for attempt, expected in [(4, 5), (6, 9)]:
        turns = attempts[("KEN58SH9SLZ6", 17, attempt)]["row"]["summary"]["turns"]
        first = next(t["turn"] for t in turns if "灵动步法" in t["plays"])
        check(f"KEN 第{attempt}次首次实际步法回合", first, expected)
    check("KEN T10 B2原/换/配对差/SE", list(decisions[274568]["sl_explore"]["b2"].values()),
          [0.385, 0.127, -0.2583, 0.0132])
    for run, floor, expected in [("751FN9QM9MHQ", 17, 0), ("KEN58SH9SLZ6", 17, 0),
                                  ("YQL8RZ8BWN1E", 17, 0), ("L9SGRBB5R698", 17, 0),
                                  ("PU80F84P6HPN", 17, 1)]:
        count = sum(x["row"]["result"] == "won" for (rid, f, _), x in attempts.items() if rid == run and f == floor)
        check(f"{run} F{floor} 实际won尝试数", count, expected)
    blast = []
    for n in range(1, 7):
        turns = attempts[("YQL8RZ8BWN1E", 17, n)]["row"]["summary"]["turns"]
        blast.append(next(t["turn"] for t in turns if "/999999999" in t["enemies"]))
    check("YQL六次首次占位阶段玩家回合", blast, [13, 13, 12, 13, 13, 10])
    giant = []
    for line, expected_poison in [(280160, 2), (280161, 8)]:
        s = states[line]
        p = s["combat"]["player"]
        e = s["combat"]["enemies"][0]
        poison = next(x["amount"] for x in e["powers"] if x["power_id"] == "POISON_POWER")
        signature = [p["current_hp"], p["block"], e["current_hp"], e["max_hp"],
                     e["move_id"], e["intents"][0]["total_damage"], poison]
        check(f"YQL残壳药前后 states {line}", signature,
              [26, 13, 999999999, 999999999, "EXPLODE_MOVE", 41, expected_poison])
        giant.append({"state_line": line, "signature": signature})
    check("YQL结束前血挡来袭代数差（非存活预测）", 26 + 13 - 41, -2)
    potion_specs = [(274131, 280206, 280207, 0, "ATTACK_POTION"),
                    (274156, 280232, 280233, 0, "STABLE_SERUM"),
                    (274185, 280262, 280263, 0, "SPEED_POTION"),
                    (274235, 280313, 280314, 1, "WEAK_POTION"),
                    (274237, 280315, 280316, 0, "ATTACK_POTION"),
                    (274267, 280348, 280349, 1, "GLOWWATER_POTION"),
                    (274272, 280354, 280355, 0, "SKILL_POTION")]
    potions = []
    for decision, before, after, slot, potion in potion_specs:
        action = decisions[decision]["chosen"]
        check(f"KEN药水动作 {decision}", [action["action"], action["option_index"]], ["use_potion", slot])
        before_slot = next(p for p in states[before]["run"]["potions"] if p["index"] == slot)
        after_slot = next(p for p in states[after]["run"]["potions"] if p["index"] == slot)
        check(f"KEN实际槽位消耗 {before}/{after}",
              [before_slot["potion_id"], before_slot["occupied"], after_slot["occupied"]], [potion, True, False])
        potions.append({"decision_line": decision, "before_state": before, "after_state": after,
                        "potion": potion, "slot": slot, "initial_receipt": decisions[decision]["result"],
                        "full_potion_branch_value": None})
    uses = [d for d in decisions.values() if d.get("run_id") == "KEN58SH9SLZ6" and d.get("chosen", {}).get("action") == "use_potion"]
    discards = [d for d in decisions.values() if d.get("run_id") == "KEN58SH9SLZ6" and d.get("chosen", {}).get("action") == "discard_potion"]
    check("KEN全局实际药水动作数", len(uses), 7)
    check("KEN全局弃药动作数", len(discards), 0)
    starts = [attempts[("KEN58SH9SLZ6", 17, n)]["row"]["summary"]["turns"][0]["hp"] for n in range(1, 7)]
    check("KEN六次F17入口血", starts, [75] * 6)
    dry = decisions[272361]
    criteria = {k: json.loads(v) for k, v in dry["questions"]["plan"]["criteria"].items()}
    check("751 F13 T3有药/无药即时损血与牌伤", [criteria[k][f] for k in ["plan2", "plan5"] for f in ["hp_lost", "damage_dealt"]], [8, 26, 8, 16])
    check("751无药整战参考key", dry["rollout"]["no_potion"], {"key": "plan5", "merged": False})
    check("751无药整战参考抽样8/8", "fight over within 5 turns in 8/8" in criteria["plan5"]["rollout"], True)
    check("751本轮不喝plan3后轮仍用药", "FLEX_POTION in 7/8 samples" in criteria["plan3"]["potion_cost"], True)
    check("751选药题成本缺表", "potion table did not load" in criteria["plan2"]["potion_cost"], True)
    result = {"kind": "evidence_material_checks_not_production_tests", "checks": CHECKS,
              "count": len(CHECKS), "all_passed": all(c["ok"] for c in CHECKS),
              "actual_windows": windows, "giant_use": giant, "potion_consumption": potions,
              "limitations": ["净血差没有自动归因到完整候选或逐源伤害。", "同局SL尝试不作独立训练/验证样本。",
                              "未执行无药、留药、改序分支的受控整战结果仍未知。"]}
    (OUT / "facts-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"count": result["count"], "all_passed": result["all_passed"],
                      "failures": [c for c in CHECKS if not c["ok"]]}, ensure_ascii=False))
    if not result["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

import collections
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
FLOORS = {
    'NHA2KW0RB7VP': {33},
    'P74C04AEPL1F': {17, 22, 23},
    'G33HU22H2543': {31, 33, 48},
    'RC61MFQM63Y6': {17, 33},
    'BTSRF7JL1W1Y': {31},
}


def powers(entity):
    return {p['power_id']: p.get('amount') for p in entity.get('powers', [])}


def card(c):
    return {
        'index': c.get('index'), 'id': c.get('card_id'),
        'upgraded': c.get('upgraded'), 'cost': c.get('energy_cost'),
        'values': {p.get('name'): p.get('current_value') for p in c.get('dynamic_values', [])},
        'text': c.get('resolved_rules_text'),
    }


def compact(item):
    s = item['row']['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    selection = s.get('selection') or {}
    return {
        'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
        'sha256': item['sha256'], 'run': item['run_id'],
        'floor': (s.get('run') or {}).get('floor'), 'turn': s.get('turn'),
        'screen': s.get('screen'), 'in_combat': s.get('in_combat'),
        'hp': p.get('current_hp'), 'max_hp': p.get('max_hp'),
        'block': p.get('block'), 'energy': p.get('energy'), 'powers': powers(p),
        'hand': [card(v) for v in c.get('hand', [])],
        'enemies': [{
            'index': e.get('index'), 'id': e.get('enemy_id'),
            'hp': e.get('current_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
            'move': e.get('move_id'), 'powers': powers(e), 'intents': e.get('intents'),
        } for e in c.get('enemies', [])],
        'potions': (s.get('run') or {}).get('potions'),
        'selection': {'prompt': selection.get('prompt'), 'cards': [card(v) for v in selection.get('cards', [])]},
        'readiness': c.get('action_readiness'),
    }


def main():
    frames = []
    counts = collections.Counter()
    partial = 0
    with (OUT / 'evidence/states.evidence.jsonl').open('rb') as f:
        for line in f:
            if not line.endswith(b'\n'):
                partial += 1
                continue
            item = json.loads(line)
            counts[item['run_id']] += 1
            s = item['row']['state']
            if (s.get('run') or {}).get('floor') in FLOORS[item['run_id']]:
                frames.append(compact(item))
    complete = (OUT / 'evidence/evidence-manifest.json').exists()
    target = 'state-facts.json' if complete else 'state-facts-initial.json'
    (OUT / target).write_text(json.dumps({'complete': complete, 'counts': counts, 'partial': partial, 'frames': frames}, ensure_ascii=False, indent=2) + '\n')
    groups = []
    for frame in frames:
        if frame['hp'] is None:
            continue
        key = frame['run'], frame['floor'], frame['turn']
        if groups and groups[-1]['key'] == key:
            groups[-1]['last'] = frame
        else:
            groups.append({'key': key, 'first': frame, 'last': frame})
    print(json.dumps({'complete': complete, 'counts': counts, 'selected': len(frames), 'partial': partial}))
    for group in groups:
        run, floor, turn = group['key']
        if (run == 'G33HU22H2543' and floor == 48 and turn not in {1, 7, 8}) or (run == 'RC61MFQM63Y6' and floor == 17 and turn != 11):
            continue
        a, b = group['first'], group['last']
        print(json.dumps({'run': run, 'floor': floor, 'turn': turn, 'lines': [a['line'], b['line']], 'hp': [a['hp'], b['hp']], 'block': [a['block'], b['block']], 'enemies': [[e['id'], e['hp'], e['powers'].get('POISON_POWER')] for e in b['enemies']]}, ensure_ascii=False))


if __name__ == '__main__':
    main()

# 策略提案本批回报

十项均 waiting；没有足够新证据支持策略改动。本批无源码/知识修改、提交、合入或版本。

- 时间：2026-10-15T12:24:13+08:00。task=strategy-proposal，character=silent，batch=20261015-121301-strategy-proposal。
- 完整基线：`93cce82eebf435770a60913f22f5d690f5606ef8`；普通main合并已核，无新增提交。
- 提案处置附件：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-121301/learner/runs/20261015-121304-9b54d6fb-2a5f-49be-bda5-458f7502e476-strategy-proposal/proposal.md`。
- 调度、原件指纹和初始账本见dispatch.json、dispatched-proposals.json、各*.original.md、ledger-before.json。十原件全部SHA匹配，未改原文，未另建重复ID。

## 原日志与材料核证

五局在runs.jsonl及run-config中均为SILENT A10；实际历史brain请求163条均为codex/gpt-6.1-sol/high，保留ds_*兼容统计，不据字段名冒称DeepSeek消费。该检查不证明本学习者当前原生会话的运行模型/推理配置，本任务未改其配置。五局均有dirty记录，未复原当时全部源码，当前源码不冒作历史运行树。

共用入口learner/extract_evidence.py实际exit0。八流逐一冻结source_size；全部6606行已回原文件按offset/bytes/SHA256核原字节、JSON正文和显式run身份；states/run-config/runs另核角色和A10。输出和计数见evidence/evidence-manifest.json，逐行索引在各*.evidence.jsonl。

| 流 | 本批行数 | 原字节截点 |
|---|---:|---:|
| states | 3238 | 13010520585 |
| decisions | 3138 | 1557552658 |
| sl-attempts | 31 | 40310132 |
| run-config | 5 | 1747793 |
| run-plans | 26 | 8012129 |
| brain | 163 | 566020901 |
| runs | 5 | 333707 |
| fight-plans | 0 | 2233957 |

states/decisions各有2行、brain有1行原文件无效JSON，未被接收为本批证据；不修原日志。fight-plans在本次截点选中0行，仅表示该范围无本批身份行，不断言原日志从未存在。run-plans实际以run字段核26行，不以正文提及归属。

原帧提炼896个目标楼层状态见state-facts.json；选择题和候选摘要见selected-decision-summary.json。evidence-audit.json中39项材料断言全部通过，非生产tsc/vitest或策略胜率测试。

核证过程失败均保留：最初NHA敌血推进硬编码428（与RC入口总量相同），结果28/44而非8/24；第二次从NHA首个未就绪帧283390读取仍为428，包含开场已发生的20敌血差，故仍失败。最终明确从首个可操作帧283391的408开始对齐同一T1选择，8/24断言目标不变并通过。evidence-audit-initial.json、evidence-audit-second.json及三次日志保留；不是原经验反证、生产失败或放松断言。一次只读字段检查对非战斗combat=null访问报错，随后以可选字段读取修正，未改任何原日志。

## 当前源码和live边界

只读核live快照 `fba193dfe31844e1dbde9f2ad7174427fcd446dc`。16个相关源码/固定测试叶逐SHA记录在source-review.json；14叶逐字节相同，card-model.ts与sl/explore.ts的差异仅为现有Roy/Dai注释文本，差量保留。未把这两个叶冒称字节等同，也未借旧测试结果宣称本批检查成功。

- 普通生存者唯一单弃：`bf423c173d3be348a4ad714e1d26516df619ff41`是真实live祖先；当前A6/A10普通牌分支移除唯一弃牌，多选pendingSelection不预支后继。
- 投斧首牌身份、弃后快照、候选差额：`a8b1f8be153fe4f3a34146117546c2178f2e446b`是真实live祖先；当前turnCanon保留首牌、弃牌题有计划影响/手牌快照，silentSlComparison等明确标候选预测、actual_turn_result=null。
- `52d6a2e86ae32cd5b53cb0d58ece6a5a0b021fed`也为live祖先；它是记录合并，不被本批冒作新增策略源码。以上均见narrow-ancestor-checks.json。
- 四分支精确结果仍不能从快照拼出：精确切击手牌数和初始牌面有核证范围，紧勒有挡/特殊交互及升级后继会保留unknown。不能把当前7伤当整线固定常量，或将已有快照称为完整预测器。

## 逐项结果

| 原提案 | 证据位置 | 账本 | 处置与缺失 |
|---|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | NHA2KW0RB7VP F33 T1–T4 | silent-0019, silent-0020, silent-0065, silent-0264, silent-0079 | waiting：缺跨重规划的完整候选归属、累计成长与同条件后轮/路线验证；1对7损血只证明即时差额，不能据此拟合SL或终局HP门槛。 |
| silent-proposal-47be799a87af03be | P74C04AEPL1F F23 第4试T3 | silent-0205 | waiting：现有题面有后继移除标记和弃后手牌快照，但没有该四分支联合重放。精确切击依赖变动手牌，当前7伤不能固定沿用；紧勒面对8挡及后续升级能力存在模型未知，缺可验证的完整保留分支。 |
| silent-proposal-3a5274da3c42672a | P74C04AEPL1F F17 T1–T9、F22 T1–T6、F23 T1/T3 | silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006 | waiting：缺召唤复活、臂甲/士兵一次消费与连续用药的联合生产重放；主怪最后归零的完整来源不可分解，不能用净血差拟药价或统一杀序，现有局部模型不构成宽项duplicate。 |
| silent-proposal-bc4b92d590f2c4ce | G33HU22H2543 F48 T1/T7–T8；P74C04AEPL1F F23 T3 | silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266 | waiting：首牌键与普通单弃仅为已实现子项；仍缺跨重规划的完整执行链、余像累计兑现与动态弃牌的联合消费者验证，不能把整项登记duplicate或implemented。 |
| silent-proposal-f52fbbab4dccc3b4 | G33HU22H2543 F31/F33/F48；P74C04AEPL1F F22/F23 | silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064 | waiting：缺资源分源的完整消费者账，以及同条件路线/休息/SL/保药整战分支；胜战耗血与后战入口不能估出因果HP价格，保持现有终局和路线参数。 |
| silent-proposal-10f37c0edd3d24a6 | G33HU22H2543 F48 T7–T8；P74C04AEPL1F F17/F22/F23 | silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069 | waiting：相关接线已存在，未定位新增确定数值缺口；缺冻结开场遗物、持续能力、牌挡/被动挡/翻倍及回复的联合生产重放和时间后置独立验证，不能扩大已有窄公式或拟合新药价。 |
| silent-proposal-3f82387e2e179703 | RC61MFQM63Y6 F33 首试/末试T1及第3试T4 | silent-0079, silent-0027, silent-0065, silent-0080, silent-0088 | waiting：缺同抽序同预算的整战控制与累计能力收益；末题original不能冒充首试实际执行线，24/24全败不证明即时安全，也不足确定保血/铺能力的新排序。 |
| silent-proposal-aee21084c991abd3 | BTSRF7JL1W1Y F31 T1–T4 | silent-0128 | waiting：缺原逐样本抽序、动作与完整实线重放；抽弃前后不是同一计划，一次死亡与3/4预测并不构成确定模型偏差，不能据此校准权重或强制焦点。 |
| silent-proposal-df37594e9b12debf | RC61MFQM63Y6 F17 T11、F33 T1/T4 | silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268 | waiting：普通单弃唯一后继取消已实现；本宽项仍缺跨重规划执行归属、能力累计与呼唤自损联合消费者验收，不能把窄修复当整项完成，没有新独立纯bug可提交。 |
| silent-proposal-42e81c83b2e1e56b | RC61MFQM63Y6 F8/F13/F24/F27/F32、F33各试 | silent-0019, silent-0020 | waiting：缺回复、药槽、存档事件的完整分源账与同条件后战反事实；105实际回血和存档恢复不能推出路线/终局HP价格，保持原参数，等待新局受控分支。 |

各项原规则、新行为建议、反例、验证/切分/回退详见proposal.md。原提案ID仍是本次消费的十个ID；未创建新提案，无需code_proposals add。既有窄实现不关闭宽提案，也不将账本shipped误作代码提案implemented。

## 验证、记录和交付

- 生产代码、生成知识与任务模板均无改动，tsc/vitest/cases均为null。撤源码失败/恢复通过不适用；没有移除生产源码或运行模拟/LLM/网络。
- 合入为null，无新行为版本，无实际上线通知或shipped登记。live仅只读祖先/叶核对，不取得合入锁、不提交并行刷新。其他角色行为无变化。
- 32条原账本通过根目录learner/ledger.py update只追加本报告/提案附件和waiting理由追溯；不重复追加历史复盘或原证据，不修改status/version/claim/prior/first_run。实际CLI结果及读回核验另存ledger-update*.jsonl、ledger-update*.log、ledger-readback.json。
- 无新机制冲突或反证；当前仍是原条目的限制，不额外创建通知/学习父要求，不声明大脑已采用或Roy已确认。
- 工作树保持tracked clean和原基线；过程文件只在本批scratch。最终仓库状态、回报契约及材料清单见final-verification.json和artifact-manifest.json。

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261015-121301-strategy-proposal",
  "base": "93cce82eebf435770a60913f22f5d690f5606ef8",
  "runs": [
    "NHA2KW0RB7VP",
    "P74C04AEPL1F",
    "G33HU22H2543",
    "RC61MFQM63Y6",
    "BTSRF7JL1W1Y"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-9952ee8e8df9a0fe",
    "silent-proposal-47be799a87af03be",
    "silent-proposal-3a5274da3c42672a",
    "silent-proposal-bc4b92d590f2c4ce",
    "silent-proposal-f52fbbab4dccc3b4",
    "silent-proposal-10f37c0edd3d24a6",
    "silent-proposal-3f82387e2e179703",
    "silent-proposal-aee21084c991abd3",
    "silent-proposal-df37594e9b12debf",
    "silent-proposal-42e81c83b2e1e56b"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-9952ee8e8df9a0fe",
      "state": "waiting",
      "reason": "缺跨重规划的完整候选归属、累计成长与同条件后轮/路线验证；1对7损血只证明即时差额，不能据此拟合SL或终局HP门槛。"
    },
    {
      "id": "silent-proposal-47be799a87af03be",
      "state": "waiting",
      "reason": "现有题面有后继移除标记和弃后手牌快照，但没有该四分支联合重放。精确切击依赖变动手牌，当前7伤不能固定沿用；紧勒面对8挡及后续升级能力存在模型未知，缺可验证的完整保留分支。"
    },
    {
      "id": "silent-proposal-3a5274da3c42672a",
      "state": "waiting",
      "reason": "缺召唤复活、臂甲/士兵一次消费与连续用药的联合生产重放；主怪最后归零的完整来源不可分解，不能用净血差拟药价或统一杀序，现有局部模型不构成宽项duplicate。"
    },
    {
      "id": "silent-proposal-bc4b92d590f2c4ce",
      "state": "waiting",
      "reason": "首牌键与普通单弃仅为已实现子项；仍缺跨重规划的完整执行链、余像累计兑现与动态弃牌的联合消费者验证，不能把整项登记duplicate或implemented。"
    },
    {
      "id": "silent-proposal-f52fbbab4dccc3b4",
      "state": "waiting",
      "reason": "缺资源分源的完整消费者账，以及同条件路线/休息/SL/保药整战分支；胜战耗血与后战入口不能估出因果HP价格，保持现有终局和路线参数。"
    },
    {
      "id": "silent-proposal-10f37c0edd3d24a6",
      "state": "waiting",
      "reason": "相关接线已存在，未定位新增确定数值缺口；缺冻结开场遗物、持续能力、牌挡/被动挡/翻倍及回复的联合生产重放和时间后置独立验证，不能扩大已有窄公式或拟合新药价。"
    },
    {
      "id": "silent-proposal-3f82387e2e179703",
      "state": "waiting",
      "reason": "缺同抽序同预算的整战控制与累计能力收益；末题original不能冒充首试实际执行线，24/24全败不证明即时安全，也不足确定保血/铺能力的新排序。"
    },
    {
      "id": "silent-proposal-aee21084c991abd3",
      "state": "waiting",
      "reason": "缺原逐样本抽序、动作与完整实线重放；抽弃前后不是同一计划，一次死亡与3/4预测并不构成确定模型偏差，不能据此校准权重或强制焦点。"
    },
    {
      "id": "silent-proposal-df37594e9b12debf",
      "state": "waiting",
      "reason": "普通单弃唯一后继取消已实现；本宽项仍缺跨重规划执行归属、能力累计与呼唤自损联合消费者验收，不能把窄修复当整项完成，没有新独立纯bug可提交。"
    },
    {
      "id": "silent-proposal-42e81c83b2e1e56b",
      "state": "waiting",
      "reason": "缺回复、药槽、存档事件的完整分源账与同条件后战反事实；105实际回血和存档恢复不能推出路线/终局HP价格，保持原参数，等待新局受控分支。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-121301/learner/runs/20261015-121304-9b54d6fb-2a5f-49be-bda5-458f7502e476-strategy-proposal/report.md"
}
```

import collections
import hashlib
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[1]))
from extract_evidence import run_identity


def main():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    provenance = []
    decisions = {}
    rest = collections.defaultdict(list)
    brains = collections.Counter()
    sl = []
    for stream in manifest:
        name = stream['stream']
        source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
        count = collections.Counter()
        digest = hashlib.sha256()
        with source.open('rb') as raw, (OUT / ('evidence/' + name + '.evidence.jsonl')).open('rb') as extracted:
            for encoded in extracted:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['source'] == str(source)
                assert item['offset'] >= 0 and item['offset'] + item['bytes'] <= stream['source_size']
                raw.seek(item['offset'])
                line = raw.read(item['bytes'])
                assert hashlib.sha256(line).hexdigest() == item['sha256']
                row = json.loads(line)
                assert row == item['row']
                assert run_identity(row) == item['run_id']
                count[item['run_id']] += 1
                if name == 'states':
                    state = row['state']
                    run = state.get('run') or {}
                    assert run['character_id'] == 'SILENT' and run['ascension'] == 10
                    if item['run_id'] == 'RC61MFQM63Y6' and state['screen'] == 'REST':
                        rest[run['floor']].append({'line': item['line'], 'hp': run['current_hp']})
                elif name == 'decisions':
                    decisions[item['line']] = row
                elif name == 'brain':
                    brains[(item['run_id'], row.get('engine'), row.get('model'), row.get('effort'))] += 1
                elif name == 'run-config':
                    assert row['character'] == 'SILENT' and row['ascension'] == 10
                elif name == 'runs':
                    assert row['character'] == 'SILENT' and row['ascension'] == 10
                elif name == 'sl-attempts':
                    sl.append({'line': item['line'], 'run': item['run_id'], 'floor': row['floor'],
                               'attempt': row['attempt'], 'result': row['result'], 'end_hp': row.get('end_hp'),
                               'reload': row.get('reload')})
        assert dict(count) == {k: v for k, v in stream['counts'].items() if v}
        assert digest.hexdigest() == stream['output_sha256']
        provenance.append({'stream': name, 'source_size': stream['source_size'], 'verified_rows': sum(count.values()),
                           'counts': dict(count), 'output_sha256': digest.hexdigest(),
                           'invalid_source_lines': stream['invalid_lines'], 'incomplete_source_lines': stream['incomplete_lines']})

    frames = {f['line']: f for f in json.loads((OUT / 'state-facts.json').read_text())['frames']}
    checks = []

    def eq(key, actual, expected, refs):
        checks.append({'check': key, 'actual': actual, 'expected': expected, 'refs': refs, 'pass': actual == expected})

    def enemy(line, ident):
        return next(e for e in frames[line]['enemies'] if e['id'] == ident)

    def attack(line, ident):
        return sum(i.get('total_damage') or 0 for i in enemy(line, ident)['intents'])

    def criterion(line, key):
        return json.loads(decisions[line]['questions']['plan']['criteria'][key])

    for line, block in [(283396, 14), (283482, 8)]:
        eq('NHA_T1_block_' + str(line), frames[line]['block'], block, [line])
    eq('NHA_T1_hp_loss', [30 - frames[n]['hp'] for n in [283397, 283483]], [1, 7], [283397, 283483])
    eq('NHA_T1_enemy_net_loss', [sum(e['hp'] for e in frames[283391]['enemies']) - sum(e['hp'] for e in frames[n]['enemies']) for n in [283397, 283483]], [8, 24], [283391, 283397, 283483])

    eq('P74_discard_resources', [frames[284817][k] for k in ['hp', 'block', 'energy']], [1, 16, 2], [284817])
    eq('P74_all_four_legal_discards', [c['id'] for c in frames[284817]['selection']['cards']],
       ['STRANGLE', 'NOXIOUS_FUMES', 'PRECISE_CUT', 'GREED'], [284817])
    eq('P74_actual_discard', decisions[278543]['chosen'], {'action': 'select_deck_card', 'option_index': 2}, ['decisions:278543'])
    eq('P74_removes_precise_cut', 'PRECISE_CUT' in [c['id'] for c in frames[284818]['hand']], False, [284818])
    eq('P74_incoming_split', [attack(284820, e) for e in ['BOWLBUG_ROCK', 'BOWLBUG_EGG']], [16, 8], [284820])
    eq('P74_egg_survives_poison', enemy(284821, 'BOWLBUG_EGG')['hp'], 2, [284821])
    eq('P74_dead_and_rock_stunned', [frames[284821]['hp'], enemy(284821, 'BOWLBUG_ROCK')['move']], [0, 'STUNNED'], [284821])
    eq('P74_same_fight_counterexample_egg_absent', any(e['id'] == 'BOWLBUG_EGG' for e in frames[284776]['enemies']), False, [284776])

    eq('P74_obscura_won_resource_chain', [frames[n]['hp'] for n in [284730, 284744, 284754, 284761, 284766]], [53, 33, 9, 9, 9], [284730, 284744, 284754, 284761, 284766])
    eq('P74_illusion_returns', [enemy(n, 'PARAFRIGHT')['hp'] for n in [284748, 284749]], [0, 21], [284748, 284749])
    eq('P74_fire_potion_slippery', [enemy(n, 'VANTOM')['hp'] for n in [284630, 284631]], [182, 181], [284630, 284631])
    eq('P74_poison_slippery', [enemy(n, 'VANTOM')['hp'] for n in [284635, 284636]], [180, 178], [284635, 284636])
    eq('P74_poison_without_slippery', [enemy(n, 'VANTOM')['hp'] for n in [284658, 284659]], [44, 21], [284658, 284659])
    eq('P74_wail_temporary', [enemy(n, 'VANTOM')['powers'].get('STRENGTH_POWER', 0) for n in [284635, 284636]], [-6, 0], [284635, 284636])
    eq('P74_wail_two_hits', attack(284635, 'VANTOM'), 2, [284635])

    eq('G33_axe_forecasts_block', [criterion(277909, k)['block_gained'] for k in ['plan1', 'plan2']], [18, 10], ['decisions:277909'])
    eq('G33_axe_forecasts_damage', [criterion(277909, k)['damage_dealt'] for k in ['plan1', 'plan2']], [75, 107], ['decisions:277909'])
    eq('G33_final_enemy_hp', [enemy(284408, e)['hp'] for e in ['TORCH_HEAD_AMALGAM', 'QUEEN']], [29, 148], [284408])

    eq('RC_same_first_question_fingerprint', decisions[279021]['fingerprint'], decisions[279197]['fingerprint'], ['decisions:279021', 'decisions:279197'])
    eq('RC_T1_blocks', [frames[n]['block'] for n in [285320, 285496]], [16, 12], [285320, 285496])
    eq('RC_T1_losses', [52 - frames[n]['hp'] for n in [285321, 285497]], [4, 8], [285321, 285497])
    eq('RC_T1_enemy_net_loss', [428 - sum(e['hp'] for e in frames[n]['enemies']) for n in [285321, 285497]], [30, 23], [285321, 285497])
    eq('RC_first_budget', '3-turn rollout (2 samples)' in criterion(279021, 'plan4')['rollout'], True, ['decisions:279021'])
    eq('RC_last_budget', '5-turn rollout (24 samples)' in criterion(279197, 'plan1')['rollout'], True, ['decisions:279197'])
    eq('RC_survivor_hand_before', [c['id'] for c in frames[285414]['hand']], ['SURVIVOR', 'STRIKE_SILENT'], [285414])
    eq('RC_survivor_hand_after', frames[285415]['hand'], [], [285415])
    eq('RC_unturned_laser', [frames[285415]['hp'], frames[285415]['block'], attack(285415, 'ROCKET')], [45, 7, 57], [285415])
    heal_floors = [8, 13, 24, 27, 32]
    changes = [rest[f][-1]['hp'] - rest[f][0]['hp'] for f in heal_floors]
    eq('RC_actual_rest_deltas', changes, [21] * 5, [r['line'] for f in heal_floors for r in rest[f]])
    eq('RC_actual_rest_total', sum(changes), 105, [r['line'] for f in heal_floors for r in rest[f]])

    eq('BTS_beetle_strength', [enemy(n, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'] for n in [286163, 286170]], [2, 4], [286163, 286170])
    eq('BTS_beetle_attack', [attack(n, 'SLUMBERING_BEETLE') for n in [286163, 286170]], [20, 22], [286163, 286170])
    eq('BTS_terminal_hp_block_plating', [frames[286173]['hp'], frames[286173]['block'], frames[286173]['powers']['PLATING_POWER']], [14, 5, 1], [286173])
    eq('BTS_original_then_replan_targets', [decisions[279852]['chosen'].get('target_index'), decisions[279854]['chosen'].get('target_index')], [2, None], ['decisions:279852', 'decisions:279854'])
    eq('BTS_post_draw_choice', decisions[279854]['answers']['plan']['choice'], 'plan2', ['decisions:279854'])
    eq('BTS_post_draw_tied_value', [criterion(279854, k).get('rollout') for k in ['plan2', 'plan4']],
       [criterion(279854, 'plan2').get('rollout')] * 2, ['decisions:279854'])

    result = {'kind': 'raw_material_verification_only', 'provenance': provenance,
              'total_rows': sum(p['verified_rows'] for p in provenance),
              'fact_checks': checks, 'fact_checks_passed': sum(c['pass'] for c in checks),
              'fact_checks_failed': sum(not c['pass'] for c in checks),
              'brain_requests': [{'run': k[0], 'engine': k[1], 'model': k[2], 'effort': k[3], 'count': v} for k, v in brains.items()],
              'rest_frames': dict(rest), 'sl_attempts': sl}
    (OUT / 'evidence-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['kind', 'total_rows', 'fact_checks_passed', 'fact_checks_failed']}, ensure_ascii=False))
    for check in checks:
        if not check['pass']:
            print(json.dumps(check, ensure_ascii=False))
    return 1 if result['fact_checks_failed'] else 0


if __name__ == '__main__':
    raise SystemExit(main())

import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-081302'
SCRATCH = ROOT / 'learner/runs/20261015-081305-8a32fd8d-ffb6-4d82-969b-f00f47272604-fix-batch'
BASE = '8b1ed57810b7af38074e91eceb3c20bd7a7a5cfd'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args], text=True).strip()


def ancestor(commit, target):
    return subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, target]).returncode == 0


sources = [
    ('silent-0254：无动作死亡战斗归因', '3b48088de', 'ops/report.py'),
    ('codex-usage-credit-baseline-recovery：额度窗口恢复基线', '5b56a452b', 'agent/src/brain/engines/codex-usage.ts'),
    ('ascension-up：请求进阶误报为实际进阶', '8045d9fbf', 'ops/codex-ops-learn.py'),
    ('infra-target-options-fixed-fixture-timeout', 'bae9c45c', 'agent/tests/target-option-fixture.ts'),
    ('infra-ledger-status-prefix-git-divergence', 'dd478f0b3', 'learner/ledger.py'),
    ('infra-legacy-continuation-notice-ack-identity', '368fccab', 'ops/learning_requests.py'),
    ('infra-paper-krane-recorded-line-timeout', 'befc39e5c', 'agent/tests/silent-paper-krane.test.ts'),
    ('infra-learner-event-log-second-collision', 'b6ee3f8c2', 'learner/lib/launcher.ts'),
    ('strategy-proposal：报告 scratch 归属', '5f04139ce', 'learner/lib/launcher.ts'),
    ('silent-0459：独立 run-plan 请求成本漏计', '799a5cd0c', 'ops/report.py'),
    ('run-plan 证据提取未识别 run 字段', '78e9b0592', 'learner/extract_evidence.py'),
    ('postmortem-capacity-failure-proposal-repair-20261013', '3fdcd7792', 'ops/codex-ops-learn.py'),
    ('blocked-experience-proposal-repair-dispatch', '84366ad06', 'ops/proposal_dispatch.py'),
    ('learning-notice-ordinary-ack-registry-20261013：普通 ACK', '672e198a4', 'ops/learning_requests.py'),
    ('learning-notice-ordinary-ack-registry-20261013：前阶段回执校验', '1594def2e', 'ops/learning_requests.py'),
    ('learning-notice-ordinary-ack-registry-20261013：第二策略槽批号', '15eb85e29', 'ops/learning_requests.py'),
    ('feature 通知来源身份校验', '38b2f572d', 'ops/learning_requests.py'),
    ('feature/B4 通知来源桥接', '1dd4d434a', 'ops/learning_requests.py'),
    ('batch-f：包装/参数化测试超时静态解析', '56c256dad', 'agent/tests/batch-f.test.ts'),
    ('unassigned-strategy-proposal-resolution', '3a98e213a', 'ops/proposal_dispatch.py'),
    ('host-fixed-test-timeouts-010547：eval 固定历史输入', 'd9881ba59', 'agent/tests/eval.test.ts'),
    ('host-fixed-test-timeouts-010547：Apotheosis 有界夹具', '9e8c93555', 'agent/tests/silent-apotheosis-reference.test.ts'),
    ('compute-memo-worker-data-signature', '8fbb441eb', 'agent/tests/compute-memo.test.ts'),
    ('rollout-live-best-test-determinism', 'bbc5b993a', 'agent/tests/rollout-live.test.ts'),
    ('host-targeted-check-continuation：已过覆盖的精确续验入口', '24c2e3a75', 'ops/learner_check_continuation.py'),
    ('sandbox-glob-startup-race：会话前有界恢复', 'bc2c40e31', 'learner/lib/startup-recovery.ts'),
    ('sandbox-glob-startup-race：复盘租约绑定', 'd9983263f', 'learner/lib/startup-recovery.ts'),
    ('core-cycle-implementation-binding-entry', 'fc95760d4', 'ops/strategy_implementation_jobs.py'),
    ('ops-20261012-quantitative-continuation', 'b408252f8', 'ops/strategy_implementation_continuation.py'),
    ('named-card-facts-transport：已批准的事件入口子项', '42c920f34', 'agent/src/hand/screens/event.ts'),
    ('core-build-notify-222802-rc2：保留原生失败诊断子项', '5c92f2aaf', 'ops/core_build_jobs.py'),
    ('paper-dataset-git-consistency-race', '16bfe0bd6', 'ops/paper_dataset.py'),
    ('boss-sim-codex-home-preflight', '5921f8cd0', 'ops/report.py'),
    ('shared-experience-fixed-filesystem-snapshot-20261013', '8390c62d7', 'agent/tests/historical-knowledge-fs.ts'),
    ('silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成）', 'ec8c578b6', 'agent/tests/silent-tail-resource.test.ts'),
    ('ops-stall-recovery-test-subprocess-timeout：首项异步夹具', '95e7f050e', 'agent/tests/ops-stall-recovery.test.ts'),
    ('ops-stall-recovery-test-subprocess-timeout：固定失败诊断', '9b6459fd9', 'agent/tests/ops-stall-recovery.test.ts'),
    ('batch-c-fixed-fixture-timeout', '5dd8a20c9', 'agent/tests/batch-c.test.ts'),
    ('晚写复盘误计为上线后重犯', '2610945b6', 'learner/ledger.py'),
    ('学习账本 first_run/asc/prior_note 追加更正', '87c89b7ae', 'learner/ledger.py'),
    ('subscription-usage：未设置 TMPDIR', '6bfbe3d2e', 'agent/tests/subscription-usage.test.ts'),
    ('deepseek-prompt-dump：状态日志反向流式扫描', '6ee8e2a2c', 'agent/tools/deepseek-prompt-dump.ts'),
    ('固定药水测试隔离', 'e78352f7', 'agent/tests/potion-cost.test.ts'),
    ('单次 mod 超时 stall 误报', 'a4f4ec86', 'ops/stall-check.sh'),
    ('学习状态锁被完整检查阻塞', '233ede56', 'ops/codex-ops-learn.py'),
    ('学习者受阻后兜底完整检查入口', 'f670884a', 'ops/learner_checks.py'),
    ('策略任务及自动派发入口', 'afd652a3', 'ops/proposal_dispatch.py'),
    ('旧事件选项重复问大脑', '25ce09bee', 'agent/src/hand/loop.ts'),
    ('silent-0153：普通隐秘匕首生成分支', 'b7f081fcc', 'agent/src/reflex/card-model.ts'),
    ('silent-0256：已观察的狡诈药水容量子项（实际源码提交）', '6403fdcda', 'agent/src/reflex/card-model.ts'),
    ('silent-0260：普通紧勒逐牌失血', '5c7105ff0', 'agent/src/reflex/card-model.ts'),
    ('silent-0263：已观察的碾碎爪转向取整子项', 'ec29ea34b', 'agent/src/reflex/silent-crusher-facing.ts'),
    ('silent-0266：SL 首牌身份', 'e784dd9f0', 'agent/src/sl/explore.ts'),
    ('silent-0272：商店移除预览与真实选牌页核对', 'db20ec3cc', 'agent/src/hand/screens/shop.ts'),
    ('silent-0324：普通刀舞生成小刀', '66c22ba7d', 'agent/src/reflex/card-model.ts'),
    ('silent-0338：回合末防御事实来源注记', 'c1d848049', 'agent/src/reflex/turn-solver.ts'),
    ('silent-0367：已用蜥蜴尾巴事实接线', '5baf663d7', 'agent/src/brain/build-facts.ts'),
]

existing = []
for item, ref, source in sources:
    commit = git('rev-parse', ref)
    # Historical renames can move a file; retain the exact committed source paths as evidence.
    paths = git('diff-tree', '--root', '--no-commit-id', '--name-only', '-r', commit).splitlines()
    record = {'item': item, 'commit': commit, 'in_base': ancestor(commit, BASE),
              'in_live': ancestor(commit, 'live'), 'inspected_source': source,
              'source_exists': (WORK / source).is_file(), 'committed_paths': paths}
    assert record['in_base'] and record['in_live'], record
    assert record['source_exists'], record
    existing.append(record)

# Check explicit, currently unchecked entries separately from later deployment notes.
queue = ROOT / 'notes/fix-queue-v4.md'
content = queue.read_bytes()
lines = content.decode().splitlines()
heading = ''
unchecked = []
for n, line in enumerate(lines, 1):
    if line.startswith('#'):
        heading = line
    if line.startswith('- [ ]'):
        ids = sorted(set(re.findall(r'silent-\d+', line + ' ' + heading)))
        unchecked.append({'line': n, 'heading': heading, 'item': line, 'ledger_ids': ids,
                          'existing_proposal_ids': re.findall(r'silent-proposal-[0-9a-f]+', line)})

ledger = json.loads((SCRATCH / 'ledger-readback.json').read_text())
for entry in ledger:
    entry['commit_ancestry'] = [{'commit': c, 'in_base': ancestor(c, BASE), 'in_live': ancestor(c, 'live')}
                              for c in entry['commits']]

skipped = [
    {'item': 'silent-0481：技能药水选牌生命周期措辞', 'reason': '策略类/题面游戏知识：当前 selection.ts:311/:333 仍有旧措辞；原 silent-proposal-686d4e759478eebb 已登记 strategy-proposal，本普通工具批不重复实现或新增提案。'},
    {'item': 'rest-timeout-accepted-route-not-committed / silent-0446', 'reason': '策略类/structure：当前 hand/loop.ts 仍只在 dispatch 成功后 applyResolved；已有 silent-proposal-2d3aa8dfb27dbe3f，超时后的实际动作确认/路线提交须按原独立提案验证，不无条件提交未确认动作。'},
    {'item': '其余未闭合的出牌、机制、药水、SL、终局、路线与休息条目', 'reason': '策略类：沿队列已有 strategy-proposal 和原账本处理；游戏知识不能由本批工具审计补入。账本有已发布项，也有 observed/proposed 或只完成窄子项，未把经验发布当作整条代码修复。'},
    {'item': 'codex 大脑缓存命中偏低', 'reason': '证据不足：队列为旧命中率观察，缺当前原生调用的可控同题对比，离线且禁止真实 LLM 请求；不把命中率变化认定为缓存源码 bug。'},
    {'item': '调度公平性核查', 'reason': '证据不足：原条目明确尚非永久饥饿证明；保留原 dispatch/seen_runs 核查与已获准框架迭代边界，不更改并发或队列状态。'},
    {'item': 'sandbox-glob-startup-race：目录生命周期上游根因', 'reason': '证据不足：有界恢复和复盘租约源码已在 base/live；目录移除者、自然恢复和上游生命周期仍未证，不取消凭据 deny 或放宽沙箱。'},
    {'item': 'core-build-notify-222802-rc2：原失败通知的发送/恢复事实', 'reason': '证据不足：诊断保存源码 5c92f2aaf 已部署；旧 rc2 无 stderr 不能事后重建原发送事实，不重发通知或改旧回执。'},
    {'item': 'named-card-facts-transport：事件入口之外的宽范围', 'reason': '策略类/独立功能：事件入口 42c920f34 已实现；其他入口/跨局及 P1/P2 仍属原独立架构任务，不扩大普通 bug 批次。'},
    {'item': 'boss 模拟样本/性能与 v5-dpr-health 的宽范围', 'reason': '太大/独立功能：原冻结输入与学习 owner 的专项仍开放，不混入本批或以低样本、扩预算、删候选掩盖问题。'},
    {'item': 'arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression', 'reason': '策略类/独立架构及归因研究：已有获准独立任务；不在纯 bug 批次改变玩法、资源价格或派发优先级。'},
]

assert git('rev-parse', 'HEAD') == BASE
assert not git('status', '--porcelain')
audit = {'base': BASE, 'branch': git('branch', '--show-current'), 'initial_merge': 'Already up to date.',
         'queue': {'path': str(queue), 'sha256': hashlib.sha256(content).hexdigest(), 'lines': len(lines)},
         'existing_fixes': existing, 'unchecked_items': unchecked, 'ledger_readback': ledger,
         'skipped': skipped, 'head': BASE, 'source_changes': [], 'live_observed': git('rev-parse', 'live'),
         'merged': None, 'new_commits': [], 'ledger_writes': [], 'code_proposals_added': [],
         'tests': {'tsc': 0, 'vitest': 0, 'files': 20, 'cases': 142, 'filtered_out': 34,
                   'python_death_fight_cases': 3, 'python_death_fight_exit': 0, 'reruns': [],
                   'scope': '现有固定回归定向验证；未执行全量 test-sandbox.sh，未声称宿主完整套件通过'},
         'negative_controls': '本批没有新增修复，因此没有撤源码负对照；不冒称对旧提交重新完成红绿验收。'}
replay_paths = ['agent/tests/historical-run-constraints-fixture.ts', 'agent/tests/historical-run-constraints.test.ts',
                'agent/tests/silent-route-relic.test.ts', 'agent/tests/silent-tail-resource.test.ts']
audit['replayed_fix'] = {'source_commit': git('rev-parse', 'c0999eaa2'),
                        'deployed_commit': git('rev-parse', 'ec8c578b6'),
                        'source_is_ancestor': False, 'blob_comparison': [
                            {'path': p, 'equal': git('rev-parse', 'c0999eaa2:' + p) == git('rev-parse', 'ec8c578b6:' + p)}
                            for p in replay_paths], 'initial_guard_failure': 'audit-initial-failure.log'}
assert all(r['equal'] for r in audit['replayed_fix']['blob_comparison'])
(SCRATCH / 'queue-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'source-diff.patch').write_bytes(subprocess.check_output(['git', '-C', str(WORK), 'diff', '--binary', BASE]))

result = {'task': 'fix-batch', 'base': BASE, 'fixes': [], 'skipped': skipped, 'merged': None,
          'tests': {'tsc': 0, 'vitest': 0, 'cases': 142}, 'code_proposals': [],
          'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
report = ['## 修 bug 回报', f'- 合并基线：main → {BASE}（工作区开工前干净，合并 Already up to date.）',
          '- 修复：无新增修复、提交或代码改动；已实现的纯工具条目不重复修。']
report += [f'- 已被别人修掉的：{r["item"]} — {r["commit"]}（当前 base/live 祖先均已核）' for r in existing]
report += [f'- 没修的：{r["item"]} — {r["reason"]}' for r in skipped]
report += ['- 测试：tsc 退出码 0；定向 vitest 20 文件 / 142 用例通过 / 退出码 0；34 项为筛选未运行，非本批删除或改 skip；Python 死亡归因固定回归 3 项 / 退出码 0；无重跑。',
           '- 合入：未合入（没有新增源码提交，不将 main 的无关记录整枝合入 live；当前只读 live 为 ' + audit['live_observed'] + '）。',
           '- 需要 Roy 定的事：无。', '',
           '本批未新增源码，故未执行每个提交前/合后全量沙箱入口、撤源码红绿、知识刷新/合入/发布编号、decision-log 上线记录或账本 proposed/shipped 更新；这些都没有新修复或实际上线作为前提。最终工作树保持原 HEAD 且干净。',
           '已检阅 README、STATE-2026-10-15、decision-log 末尾、learning-protocol 与 learning-code-proposals。队列 SHA、未勾选条目原文/行号、源码祖先和账本只读状态均保存在 queue-audit.json；既有范围未全部关闭。',
           '定向原始输出：tsc.log、vitest-targeted.log、vitest-fixtures.log、report-death-fight.log。source-diff.patch 为空；没有新经验、提案、知识数据、游戏动作或对局进程操作。', '',
           '```json', json.dumps(result, ensure_ascii=False), '```']
(SCRATCH / 'report.md').write_text('\n'.join(report) + '\n')
print(json.dumps({'existing_fixes': len(existing), 'unchecked_items': len(unchecked), 'source_diff_bytes': (SCRATCH / 'source-diff.patch').stat().st_size, 'report': result['report']}, ensure_ascii=False))

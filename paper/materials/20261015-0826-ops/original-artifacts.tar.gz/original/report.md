## 修 bug 回报
- 合并基线：main → 8b1ed57810b7af38074e91eceb3c20bd7a7a5cfd（工作区开工前干净，合并 Already up to date.）
- 修复：无新增修复、提交或代码改动；已实现的纯工具条目不重复修。
- 已被别人修掉的：silent-0254：无动作死亡战斗归因 — 3b48088dec5fc6eafe576a1296bbdadde43432ee（当前 base/live 祖先均已核）
- 已被别人修掉的：codex-usage-credit-baseline-recovery：额度窗口恢复基线 — 5b56a452bb9be14d620b368ec46974c1b57901ca（当前 base/live 祖先均已核）
- 已被别人修掉的：ascension-up：请求进阶误报为实际进阶 — 8045d9fbf0a12523b1dbe39bbed8af06c7497b09（当前 base/live 祖先均已核）
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout — bae9c45ccffefb284a1c6634526c8768a9f5f7a8（当前 base/live 祖先均已核）
- 已被别人修掉的：infra-ledger-status-prefix-git-divergence — dd478f0b3e5a0f234f082972d21b203dbf8229d7（当前 base/live 祖先均已核）
- 已被别人修掉的：infra-legacy-continuation-notice-ack-identity — 368fccabd42eb72ffcea9a2fe6cbbb7c149326be（当前 base/live 祖先均已核）
- 已被别人修掉的：infra-paper-krane-recorded-line-timeout — befc39e5ca0105f8ff96d47f817df44f0b2760f1（当前 base/live 祖先均已核）
- 已被别人修掉的：infra-learner-event-log-second-collision — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（当前 base/live 祖先均已核）
- 已被别人修掉的：strategy-proposal：报告 scratch 归属 — 5f04139cefe5c651dd5bf62f7e164014dbf5f23b（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0459：独立 run-plan 请求成本漏计 — 799a5cd0caf9329b43c32376079218a9bd0c3e9e（当前 base/live 祖先均已核）
- 已被别人修掉的：run-plan 证据提取未识别 run 字段 — 78e9b05929366d097a728761d693d790ff16ac87（当前 base/live 祖先均已核）
- 已被别人修掉的：postmortem-capacity-failure-proposal-repair-20261013 — 3fdcd77927f01b35c20c6c5c1fcfd790676032d2（当前 base/live 祖先均已核）
- 已被别人修掉的：blocked-experience-proposal-repair-dispatch — 84366ad06ee4f978394c1b9489a82c83ea12bd36（当前 base/live 祖先均已核）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：普通 ACK — 672e198a4730012330f599068a0ef1efadb02002（当前 base/live 祖先均已核）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 — 1594def2e1b65b665d3b345f31444194eb4d09e6（当前 base/live 祖先均已核）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 — 15eb85e2934e428c5e299fc4a1aba456d92fd685（当前 base/live 祖先均已核）
- 已被别人修掉的：feature 通知来源身份校验 — 38b2f572d90b3b97a23f9eae983f583287492f9a（当前 base/live 祖先均已核）
- 已被别人修掉的：feature/B4 通知来源桥接 — 1dd4d434aef67f1d065dbdba23a875ae82741a88（当前 base/live 祖先均已核）
- 已被别人修掉的：batch-f：包装/参数化测试超时静态解析 — 56c256dad0d33b231b82b53113d3bdd84f9bfa20（当前 base/live 祖先均已核）
- 已被别人修掉的：unassigned-strategy-proposal-resolution — 3a98e213a826e94f9708af4b1a265e1892659f4e（当前 base/live 祖先均已核）
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval 固定历史输入 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7（当前 base/live 祖先均已核）
- 已被别人修掉的：host-fixed-test-timeouts-010547：Apotheosis 有界夹具 — 9e8c93555131c3347f9e809d9722a848a75c2692（当前 base/live 祖先均已核）
- 已被别人修掉的：compute-memo-worker-data-signature — 8fbb441eb61eef226eb7366f9612003480c83988（当前 base/live 祖先均已核）
- 已被别人修掉的：rollout-live-best-test-determinism — bbc5b993a7524bbb8e80a975f204f8d193657b46（当前 base/live 祖先均已核）
- 已被别人修掉的：host-targeted-check-continuation：已过覆盖的精确续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（当前 base/live 祖先均已核）
- 已被别人修掉的：sandbox-glob-startup-race：会话前有界恢复 — bc2c40e313cc36682196277c53c50e30744b88c5（当前 base/live 祖先均已核）
- 已被别人修掉的：sandbox-glob-startup-race：复盘租约绑定 — d9983263ffecea1bed4e29d65e7f854a3d2e33d7（当前 base/live 祖先均已核）
- 已被别人修掉的：core-cycle-implementation-binding-entry — fc95760d4ff8a9cbd45577efdd79b1215bd2cb92（当前 base/live 祖先均已核）
- 已被别人修掉的：ops-20261012-quantitative-continuation — b408252f87a77ee5389c4d90e52a9831c0873348（当前 base/live 祖先均已核）
- 已被别人修掉的：named-card-facts-transport：已批准的事件入口子项 — 42c920f34d9dc1c783ce894659849ab37ed6fd1b（当前 base/live 祖先均已核）
- 已被别人修掉的：core-build-notify-222802-rc2：保留原生失败诊断子项 — 5c92f2aaf0b758a1a5e7d591745694004664f83a（当前 base/live 祖先均已核）
- 已被别人修掉的：paper-dataset-git-consistency-race — 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f（当前 base/live 祖先均已核）
- 已被别人修掉的：boss-sim-codex-home-preflight — 5921f8cd045853182c867a6430e75c3fcde00a87（当前 base/live 祖先均已核）
- 已被别人修掉的：shared-experience-fixed-filesystem-snapshot-20261013 — 8390c62d76fc8c7d7b6b7292121a621f4666d39c（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） — ec8c578b66bf5498372f1b779ae58a766dff8112（当前 base/live 祖先均已核）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：首项异步夹具 — 95e7f050ef2abe5c85a0367555392652ad73fbfe（当前 base/live 祖先均已核）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：固定失败诊断 — 9b6459fd99f26b17689134e33aa85d6190e71d7d（当前 base/live 祖先均已核）
- 已被别人修掉的：batch-c-fixed-fixture-timeout — 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff（当前 base/live 祖先均已核）
- 已被别人修掉的：晚写复盘误计为上线后重犯 — 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39（当前 base/live 祖先均已核）
- 已被别人修掉的：学习账本 first_run/asc/prior_note 追加更正 — 87c89b7aea90c7275e0fbb04b1e4148a4209630c（当前 base/live 祖先均已核）
- 已被别人修掉的：subscription-usage：未设置 TMPDIR — 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a（当前 base/live 祖先均已核）
- 已被别人修掉的：deepseek-prompt-dump：状态日志反向流式扫描 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093（当前 base/live 祖先均已核）
- 已被别人修掉的：固定药水测试隔离 — e78352f784d39cf25671446348daaada6ef2060b（当前 base/live 祖先均已核）
- 已被别人修掉的：单次 mod 超时 stall 误报 — a4f4ec868d122dc92af510862c6240cf2eaff2b6（当前 base/live 祖先均已核）
- 已被别人修掉的：学习状态锁被完整检查阻塞 — 233ede56047274ba53a4e1191a245fac816c37a8（当前 base/live 祖先均已核）
- 已被别人修掉的：学习者受阻后兜底完整检查入口 — f670884a188a047bbd3f7f007c260ade62fae36a（当前 base/live 祖先均已核）
- 已被别人修掉的：策略任务及自动派发入口 — afd652a3f75df6e7403439f01c565220327884da（当前 base/live 祖先均已核）
- 已被别人修掉的：旧事件选项重复问大脑 — 25ce09bee5576b1adff8baf196fbe8b197a5ef11（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0153：普通隐秘匕首生成分支 — b7f081fcc26da4506cb775739bb118cb6cbe4ecc（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0256：已观察的狡诈药水容量子项（实际源码提交） — 6403fdcdadc803a092beb5165a068e22bf51c412（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0260：普通紧勒逐牌失血 — 5c7105ff0294466da8319f2934beda05c6040794（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0263：已观察的碾碎爪转向取整子项 — ec29ea34b919344b707e57ba472ea210f9c39d62（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0266：SL 首牌身份 — e784dd9f043bf87c29109573f48975f9903280d3（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0272：商店移除预览与真实选牌页核对 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0324：普通刀舞生成小刀 — 66c22ba7d87b8748690a4183fff838acd346bd3e（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0338：回合末防御事实来源注记 — c1d84804956bedbd29a7f0e81294114e18415b9d（当前 base/live 祖先均已核）
- 已被别人修掉的：silent-0367：已用蜥蜴尾巴事实接线 — 5baf663d7e6678efa3690e5a48329c4f8baee109（当前 base/live 祖先均已核）
- 没修的：silent-0481：技能药水选牌生命周期措辞 — 策略类/题面游戏知识：当前 selection.ts:311/:333 仍有旧措辞；原 silent-proposal-686d4e759478eebb 已登记 strategy-proposal，本普通工具批不重复实现或新增提案。
- 没修的：rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/structure：当前 hand/loop.ts 仍只在 dispatch 成功后 applyResolved；已有 silent-proposal-2d3aa8dfb27dbe3f，超时后的实际动作确认/路线提交须按原独立提案验证，不无条件提交未确认动作。
- 没修的：其余未闭合的出牌、机制、药水、SL、终局、路线与休息条目 — 策略类：沿队列已有 strategy-proposal 和原账本处理；游戏知识不能由本批工具审计补入。账本有已发布项，也有 observed/proposed 或只完成窄子项，未把经验发布当作整条代码修复。
- 没修的：codex 大脑缓存命中偏低 — 证据不足：队列为旧命中率观察，缺当前原生调用的可控同题对比，离线且禁止真实 LLM 请求；不把命中率变化认定为缓存源码 bug。
- 没修的：调度公平性核查 — 证据不足：原条目明确尚非永久饥饿证明；保留原 dispatch/seen_runs 核查与已获准框架迭代边界，不更改并发或队列状态。
- 没修的：sandbox-glob-startup-race：目录生命周期上游根因 — 证据不足：有界恢复和复盘租约源码已在 base/live；目录移除者、自然恢复和上游生命周期仍未证，不取消凭据 deny 或放宽沙箱。
- 没修的：core-build-notify-222802-rc2：原失败通知的发送/恢复事实 — 证据不足：诊断保存源码 5c92f2aaf 已部署；旧 rc2 无 stderr 不能事后重建原发送事实，不重发通知或改旧回执。
- 没修的：named-card-facts-transport：事件入口之外的宽范围 — 策略类/独立功能：事件入口 42c920f34 已实现；其他入口/跨局及 P1/P2 仍属原独立架构任务，不扩大普通 bug 批次。
- 没修的：boss 模拟样本/性能与 v5-dpr-health 的宽范围 — 太大/独立功能：原冻结输入与学习 owner 的专项仍开放，不混入本批或以低样本、扩预算、删候选掩盖问题。
- 没修的：arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression — 策略类/独立架构及归因研究：已有获准独立任务；不在纯 bug 批次改变玩法、资源价格或派发优先级。
- 测试：tsc 退出码 0；定向 vitest 20 文件 / 142 用例通过 / 退出码 0；34 项为筛选未运行，非本批删除或改 skip；Python 死亡归因固定回归 3 项 / 退出码 0；无重跑。
- 合入：未合入（没有新增源码提交，不将 main 的无关记录整枝合入 live；当前只读 live 为 52046a3deaa359adbafdd9e6d3e96c2527017f49）。
- 需要 Roy 定的事：无。

本批未新增源码，故未执行每个提交前/合后全量沙箱入口、撤源码红绿、知识刷新/合入/发布编号、decision-log 上线记录或账本 proposed/shipped 更新；这些都没有新修复或实际上线作为前提。最终工作树保持原 HEAD 且干净。
已检阅 README、STATE-2026-10-15、decision-log 末尾、learning-protocol 与 learning-code-proposals。队列 SHA、未勾选条目原文/行号、源码祖先和账本只读状态均保存在 queue-audit.json；既有范围未全部关闭。
定向原始输出：tsc.log、vitest-targeted.log、vitest-fixtures.log、report-death-fight.log。source-diff.patch 为空；没有新经验、提案、知识数据、游戏动作或对局进程操作。

```json
{"task": "fix-batch", "base": "8b1ed57810b7af38074e91eceb3c20bd7a7a5cfd", "fixes": [], "skipped": [{"item": "silent-0481：技能药水选牌生命周期措辞", "reason": "策略类/题面游戏知识：当前 selection.ts:311/:333 仍有旧措辞；原 silent-proposal-686d4e759478eebb 已登记 strategy-proposal，本普通工具批不重复实现或新增提案。"}, {"item": "rest-timeout-accepted-route-not-committed / silent-0446", "reason": "策略类/structure：当前 hand/loop.ts 仍只在 dispatch 成功后 applyResolved；已有 silent-proposal-2d3aa8dfb27dbe3f，超时后的实际动作确认/路线提交须按原独立提案验证，不无条件提交未确认动作。"}, {"item": "其余未闭合的出牌、机制、药水、SL、终局、路线与休息条目", "reason": "策略类：沿队列已有 strategy-proposal 和原账本处理；游戏知识不能由本批工具审计补入。账本有已发布项，也有 observed/proposed 或只完成窄子项，未把经验发布当作整条代码修复。"}, {"item": "codex 大脑缓存命中偏低", "reason": "证据不足：队列为旧命中率观察，缺当前原生调用的可控同题对比，离线且禁止真实 LLM 请求；不把命中率变化认定为缓存源码 bug。"}, {"item": "调度公平性核查", "reason": "证据不足：原条目明确尚非永久饥饿证明；保留原 dispatch/seen_runs 核查与已获准框架迭代边界，不更改并发或队列状态。"}, {"item": "sandbox-glob-startup-race：目录生命周期上游根因", "reason": "证据不足：有界恢复和复盘租约源码已在 base/live；目录移除者、自然恢复和上游生命周期仍未证，不取消凭据 deny 或放宽沙箱。"}, {"item": "core-build-notify-222802-rc2：原失败通知的发送/恢复事实", "reason": "证据不足：诊断保存源码 5c92f2aaf 已部署；旧 rc2 无 stderr 不能事后重建原发送事实，不重发通知或改旧回执。"}, {"item": "named-card-facts-transport：事件入口之外的宽范围", "reason": "策略类/独立功能：事件入口 42c920f34 已实现；其他入口/跨局及 P1/P2 仍属原独立架构任务，不扩大普通 bug 批次。"}, {"item": "boss 模拟样本/性能与 v5-dpr-health 的宽范围", "reason": "太大/独立功能：原冻结输入与学习 owner 的专项仍开放，不混入本批或以低样本、扩预算、删候选掩盖问题。"}, {"item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression", "reason": "策略类/独立架构及归因研究：已有获准独立任务；不在纯 bug 批次改变玩法、资源价格或派发优先级。"}], "merged": null, "tests": {"tsc": 0, "vitest": 0, "cases": 142}, "code_proposals": [], "implementation_domains": [], "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-081305-8a32fd8d-ffb6-4d82-969b-f00f47272604-fix-batch/report.md"}
```

import json,pathlib,hashlib,re,collections
P=pathlib.Path(__file__).parent
m=json.loads((P/'append-manifest-before.json').read_text());expected=(P/'section.md').read_bytes();h=hashlib.sha256();remaining=m['before_bytes']
with pathlib.Path('notes/lessons.md').open('rb') as f:
 while remaining:
  b=f.read(min(remaining,1048576));assert b;h.update(b);remaining-=len(b)
 assert h.hexdigest()==m['before_sha256'],'历史前缀发生变化'
 assert f.read(len(expected))==expected,'追加正文不同'
assert hashlib.sha256(expected).hexdigest()==m['section_sha256']
assert sum(1 for l in pathlib.Path('notes/lessons.md').open() if l.startswith('## Q9KFP3J3JNU5'))==1
D=[json.loads(l) for l in (P/'decisions.jsonl').open()];S=[json.loads(l) for l in (P/'states.jsonl').open()];R=[json.loads(l) for l in (P/'states-refs.jsonl').open()];by={r['line']:s['state'] for r,s in zip(R,S)};C=json.loads((P/'Q9KFP3J3JNU5-resources.json').read_text());sl=[json.loads(l) for l in (P/'sl-attempts.jsonl').open()]
assert len(D)==1159 and len(S)==1251 and len(C['combats'])==32
assert len([c for c in C['combats'] if c['exit']])==23
assert len([x for x in sl if x['result']=='predicted_death'])==9
assert all(c['entry_is_turn_one'] and c['entry']['max_hp']==70 for c in C['combats'])
f48=[c for c in C['combats'] if c['floor']==48];assert len(f48)==6 and all(c['entry']['hp']==41 and c['entry']['potions']==[] for c in f48)
last=by[447422];e=last['combat']['enemies'][0];p=last['combat']['player'];hand=last['combat']['hand'];w=[c for c in hand if c['card_id']=='WITHER']
assert last['run']['current_hp']==32 and p['block']==6 and e['current_hp']==407 and e['max_hp']==535
wd=sum(next(v['current_value'] for v in c['dynamic_values'] if v['name']=='Damage') for c in w)
assert len(w)==2 and wd==18
incoming=sum(i.get('total_damage') or 0 for i in e['intents']);need=incoming+wd-p['block'];assert incoming==35 and need==47 and need-32+1==16
assert by[447423]['run']['current_hp']==0 and by[447423]['turn']==7
assert by[447388]['combat']['enemies'][0]['current_hp']==468
assert by[447397]['combat']['enemies'][0]['current_hp']==450
assert by[447404]['combat']['enemies'][0]['current_hp']==427
assert by[447413]['combat']['enemies'][0]['current_hp']==426
assert by[447420]['combat']['enemies'][0]['current_hp']==407
assert 18+9+1==28 and 535-407==128
assert [(x['turns'],x['result']) for x in sl if x['floor']==48]==[(7,'predicted_death'),(5,'predicted_death'),(7,'predicted_death'),(7,'predicted_death'),(7,'predicted_death'),(7,'died')]
assert sum(1 for x in D if (x.get('chosen') or {}).get('action')=='use_potion')==17
assert sum(1 for x in D if (x.get('chosen') or {}).get('action')=='discard_potion')==0
assert len([x for x in D if 'HP guard:' in str(x.get('rationale',''))])==2
assert json.loads(D[135]['fingerprint'])['hp']==22
assert len([x for x in D if x.get('decider')=='jev' and x.get('confidence') is not None and x['confidence']<.35])==22
B=[json.loads(l) for l in (P/'brain.jsonl').open()];assert len(B)==47
assert sum(x['usage']['inputTokens'] for x in B)==8750725
assert sum(x['usage']['outputTokens'] for x in B)==57988
assert sum(x['usage'].get('cacheHitTokens',0) for x in B)==894336
assert all(x['engine']=='codex' and x['model']=='gpt-6.1-sol' and x['effort']=='xhigh' for x in B)
assert len([x for x in B if x['label']=='run-plan'])==1
st=json.loads((P/'metrics-details.json').read_text())['stats'];assert (st['rollout_known'],st['rollout_chosen_best'],st['boss_known'],st['boss_chosen_best'])==(233,219,39,32)
text=expected.decode();needles=['41/70血','32血6挡','35攻击','各9伤','完整需损47','差16血','407/535血','5943.888秒','HP护栏实际替换2次','独立取得15瓶','饮用14瓶']
assert all(x in text for x in needles)
result={'history_prefix_unchanged':True,'section_exact_once':True,'section_bytes':len(expected),'states':len(S),'decisions':len(D),'combat_windows':len(C['combats']),'numeric_checks':'全部通过','errata_required':False}
(P/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

import json,pathlib,collections,re
P=pathlib.Path(__file__).parent
D=[json.loads(l) for l in (P/'decisions.jsonl').open()]
S=[json.loads(l) for l in (P/'states.jsonl').open()]
R=[json.loads(l) for l in (P/'states-refs.jsonl').open()]
C=json.load((P/'Q9KFP3J3JNU5-resources.json').open())
byline={r['line']:s for r,s in zip(R,S)}
def short(s):
 st=s['state'];c=st.get('combat') or {};pl=c.get('player') or {}
 return {'ts':s['ts'],'F':st['run']['floor'],'T':st.get('turn'),'hp':st['run']['current_hp'],'max':st['run']['max_hp'],'screen':st['screen'],'block':pl.get('block'),'pow':[(v['power_id'],v['amount']) for v in pl.get('powers',[])],'enemies':[(e['enemy_id'],e['current_hp'],e.get('block'),[(v['power_id'],v['amount']) for v in e.get('powers',[])],e.get('intents')) for e in c.get('enemies',[])],'hand':[(v['index'],v['card_id'],v['name'],v.get('energy_cost'),v.get('resolved_rules_text'),v.get('playable')) for v in c.get('hand',[])]}
print('STAT',collections.Counter((x.get('decider'),x.get('label')) for x in D))
print('JEV LOW',[(i,x['floor'],x.get('turn'),x['label'],x['confidence']) for i,x in enumerate(D,1) if x.get('decider')=='jev' and x.get('confidence') is not None and x['confidence']<.35])
for i,x in enumerate(D,1):
 if any(w in str(x.get('rationale','')).lower() for w in ['guard','guardrail','hp护栏']): print('GUARD',i,x['rationale'])
for x in C['combats']:
 seq=x['sequence']; a=x['entry'];b=x['exit'] or x['last'];ss=[s for r,s in zip(R,S) if a['line']<=r['line']<=b['line']]
 turns={}
 for s in ss:
  if not s['state'].get('in_combat'):continue
  t=s['state'].get('turn')
  if t not in turns:turns[t]=s
 starts=list(turns.values());ends=starts[1:]+[ss[-1]]
 vals=[]
 for st,en in zip(starts,ends):
  def hp(s):return sum(e['current_hp'] for e in (s['state'].get('combat') or {}).get('enemies',[]) if e.get('is_alive'))
  vals.append((st['state'].get('turn'),hp(st),hp(st)-hp(en),st['state']['run']['current_hp']-en['state']['run']['current_hp']))
 print('TURNS',seq,x['floor'],vals)
 if x['floor'] in [33,45,48]:
  print('END',seq,short(byline[b['line']]))
print('POTION ACTIONS')
for i,x in enumerate(D,1):
 ch=x.get('chosen') or {}
 if any(w in ch.get('action','') for w in ['potion']):print(i,x['floor'],x.get('turn'),ch,x.get('expect'),x.get('rationale'))
print('FINAL RELICS',[(x['relic_id'],x['name'],x.get('description'),x.get('counter')) for x in S[-1]['state']['run'].get('relics',[])])
for n in [892,893,1090,1120]:
 x=D[n-1];print('QS',n,json.dumps(x.get('questions'),ensure_ascii=False)[:10000])

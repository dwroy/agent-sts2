import json,pathlib,collections
P=pathlib.Path(__file__).parent
S=[json.loads(l) for l in (P/'states.jsonl').open()];R=[json.loads(l) for l in (P/'states-refs.jsonl').open()]
D=[json.loads(l) for l in (P/'decisions.jsonl').open()]
print('BOSS FINAL FRAMES')
for r,s in zip(R,S):
 if r['line']<447371:continue
 st=s['state'];c=st.get('combat') or {};pl=c.get('player') or {};en=c.get('enemies',[])
 print(r['line'],st.get('turn'),st['run']['current_hp'],pl.get('block'),'P',[(p['power_id'],p['amount']) for p in pl.get('powers',[])], 'E',[(e['current_hp'],[(p['power_id'],p['amount']) for p in e.get('powers',[])]) for e in en],'hand',[(x['card_id'],x['name']) for x in c.get('hand',[])])
print('guard plans')
for n in [136,682]:
 x=D[n-1];print(n,x['rationale']);print(json.dumps(x['questions'],ensure_ascii=False)[:11000])
print('STATS brain',len([x for x in D if x.get('deepseek')]))
print('CODE AUTONOMY')
code=[x for x in D if x.get('decider')=='code' and x['label'].startswith('combat/') and x['label']!='combat/plan-continue'];print(len(code),len(set((x['floor'],x.get('sl_attempt'),x.get('turn')) for x in code)),collections.Counter(x.get('sl_attempt') for x in code))
print('jev prompts')
for n,l in enumerate((P/'jev-prompts.jsonl').open(),1):
 x=json.loads(l)
 if n<3: print(n,list(x), {k:v for k,v in x.items() if k not in ['prompt','state','system','messages','request','questions','context','response']})

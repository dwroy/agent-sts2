import pathlib,json,collections,datetime
P=pathlib.Path(__file__).parent
C=json.load((P/'Q9KFP3J3JNU5-resources.json').open());S=[json.loads(l) for l in (P/'states.jsonl').open()];R=[json.loads(l) for l in (P/'states-refs.jsonl').open()];D=[json.loads(l) for l in (P/'decisions.jsonl').open()]
nums=collections.Counter();res=['| 层／尝试与敌人 | 进→出HP／上限；净耗 | 药栏进→出（槽:ID） | 结果；原states行；UTC时间 |','| --- | --- | --- | --- |'];turns=['| 层／尝试，回合顺序 | 轮初活敌血池（仍需净扣） | 本轮活敌血池净减少 | 玩家净耗HP |','| --- | --- | --- | --- |']
def pot(x):return '，'.join(str(n)+':'+v for n,v in x) or '空'
for c in C['combats']:
 f=c['floor'];nums[f]+=1;att=nums[f];a=c['entry'];b=c['exit'] or c['last'];ss=[(r,s) for r,s in zip(R,S) if a['line']<=r['line']<=b['line']];names={}
 for _,s in ss:
  for e in (s['state'].get('combat') or {}).get('enemies',[]):names[e['enemy_id']]=e['name']
 result='胜' if c['exit'] and f!=48 else '败' if c['exit'] else '判死读档，缺退出帧'
 hploss=a['hp']-b['hp'];net=str(hploss) if c['exit'] else '已观测'+str(hploss)+'，完整净耗未记录'
 res.append(f"| F{f}／{att} "+'、'.join(n+' '+k for k,n in names.items())+f" | {a['hp']}→{b['hp']}／{a['max_hp']}→{b['max_hp']}；{net} | {pot(a['potions'])}→{pot(b['potions'])} | {result}；{a['line']}→{b['line']}；{a['ts'][11:23]}→{b['ts'][11:23]} |")
 ts={}
 for _,s in ss:
  st=s['state']
  if st.get('in_combat') and st.get('turn') not in ts:ts[st.get('turn')]=s
 starts=list(ts.values());ends=starts[1:]+[ss[-1][1]];need=[];loss=[];own=[]
 for x,y in zip(starts,ends):
  def pool(v):return sum(e['current_hp'] for e in (v['state'].get('combat') or {}).get('enemies',[]) if e.get('is_alive'))
  need.append(pool(x));loss.append(pool(x)-pool(y));own.append(x['state']['run']['current_hp']-y['state']['run']['current_hp'])
 suffix='（末轮仅行动前缀，未结敌方回合）' if not c['exit'] else ''
 turns.append(f"| F{f}／{att} T"+'—T'.join(map(str,[min(ts),max(ts)]))+suffix+' | '+'／'.join(map(str,need))+' | '+'／'.join(map(str,loss))+' | '+'／'.join(map(str,own))+' |')
(P/'resource-table.md').write_text('\n'.join(res)+'\n');(P/'turn-table.md').write_text('\n'.join(turns)+'\n')
code=[x for x in D if x.get('decider')=='code' and x['label'].startswith('combat/') and x['label']!='combat/plan-continue'];jev=[x for x in D if x.get('decider')=='jev' and x['label'].startswith('combat/')];key=lambda x:(x['floor'],x.get('sl_attempt') or 1,x.get('turn'))
print('autonomous',len(code),len(set(map(key,code))),'noJev',len(set(map(key,code))-set(map(key,jev))))
print('seconds',(datetime.datetime.fromisoformat(D[-1]['ts'])-datetime.datetime.fromisoformat(D[0]['ts'])).total_seconds())
# Compare every original selected byte with the preserved run-only copy.
for name in ['states','decisions','runs','run-plans','sl-attempts','brain','jev-prompts','run-config','codex-calls','fight-plans']:
 ref=P/(name+'-refs.jsonl')
 if not ref.exists():continue
 n=0
 with pathlib.Path('logs',name+'.jsonl').open('rb') as src,(P/(name+'.jsonl')).open('rb') as copy:
  for line in ref.open():
   r=json.loads(line);src.seek(r['offset']);raw=src.read(r['bytes']);assert raw==copy.readline(),(name,n);assert b'Q9KFP3J3JNU5' in raw;n+=1
  assert copy.read(1)==b''
 print('bytecheck',name,n)

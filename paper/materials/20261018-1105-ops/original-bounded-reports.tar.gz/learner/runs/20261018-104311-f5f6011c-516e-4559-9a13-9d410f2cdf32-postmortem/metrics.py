import json,pathlib,collections,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(l) for l in (P/'decisions.jsonl').open()];J=[json.loads(l) for l in (P/'jev-prompts.jsonl').open()]
by=collections.defaultdict(list)
for x in J:by[x['decision_id']].append(x)
st=collections.Counter();problems=[];focus=[];details=[]
for i,x in enumerate(D,1):
 if x.get('decider')!='jev' or 'plan-choice' not in x['label']:continue
 rows=[r for r in by[x['decision_id']] if (r.get('answers',{}).get('plan') or {}).get('choice')]
 if not rows:problems.append(i);continue
 r=rows[-1];ans=r['answers']['plan']['choice'];s=r.get('decision_evidence',r['request'])['state'];ref=s.get('simulation_reference',{}).get('rollout',{});best=ref.get('tied') or ([ref['best']] if ref.get('best') else [])
 st['plan_questions']+=1
 if best:st['rollout_known']+=1;st['rollout_chosen_best']+=ans in best
 else:st['rollout_unknown']+=1
 bs=x.get('boss_sim') or {};bb=bs.get('tied') or ([bs['best']] if bs.get('best') else [])
 if bb:st['boss_known']+=1;st['boss_chosen_best']+=ans in bb
 crit=x['questions']['plan']['criteria'];q=[]
 for k,v in crit.items():
  try:v=json.loads(v)
  except:continue
  if any('focus' in z.lower() for z in v):q.append((k,{z:t for z,t in v.items() if 'focus' in z.lower()}))
 if q:focus.append({'d':i,'floor':x['floor'],'turn':x.get('turn'),'answer':ans,'options':q})
 details.append({'d':i,'answer':ans,'best':best,'boss_best':bb,'rollout':ref,'chosen_criterion':json.loads(crit.get(ans,'{}'))})
print('METRICS',dict(st),'problems',problems)
print('FOCUS',len(focus),focus[:10])
(P/'metrics-details.json').write_text(json.dumps({'stats':dict(st),'problems':problems,'focus':focus,'details':details},ensure_ascii=False,indent=2))
print('CLOCK PATHS')
def walk(o,path=''):
 if isinstance(o,dict):
  for k,v in o.items():
   if 'clock' in k.lower(): print(path+'.'+k,json.dumps(v,ensure_ascii=False)[:3000])
   elif k not in ['criteria','construction','global_build','globalBuild','human_pace_h2']:walk(v,path+'.'+k)
 elif isinstance(o,list):
  for i,v in enumerate(o):walk(v,path+f'[{i}]')
for n in [82,440,749,889]:
 print('D',n);walk(D[n-1].get('boss_sim',{}));print('deepseekguide',str((D[n-1].get('deepseek') or {}).get('guide',''))[:200])
print('BRAIN TOKENS')
B=[json.loads(l) for l in (P/'brain.jsonl').open()];print('rows',len(B),'keys',list(B[0]));print('engines',collections.Counter(str(x.get('engine')) for x in B))
for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens']:print(k,sum(x.get(k,0) or 0 for x in B))
for n in [892,1116]:
 bs=D[n-1].get('boss_sim',{});print('BOSS',n,{k:bs.get(k) for k in ['best','tied','samples','requested','low_trust','boss']});print('line',json.dumps(next(iter(bs.get('lines',{}).values()),{}),ensure_ascii=False)[:1600])

#!/bin/bash
set -e
date
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0020", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 1, "role": "support", "note": "F33第四试55→4胜，跨幕56；三幕F40／43／44／45胜战分别净耗10／19／11／15，F46星图补5、F47休息补21，才以41/70空药进沙漏六试。无替路线／休息／留药受控胜线，不将死亡记repeat。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0385", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 1, "role": "support", "note": "末试T1触媒+建2层但抽入毒雾／两药瓶未施放；T3蛇咬7毒才启动，T3／4／5结18／9／1共28；T6加普通触媒至3层时敌无毒，磨蚀未建立。含开场9伤共净扣128，敌407/535，支持组件与实际窗口分账，不认定原候选完整执行或重犯。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0024", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 7, "role": "support", "note": "末试s447420—447423：32HP、6挡、35攻击、两张各9伤凋萎，完整需损47，最小损失代码预告余−15，实际0HP且敌407/535；SL理由已计18持牌伤，支持机制边界而非漏算bug／repeat。"}, {"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 5, "role": "support", "note": "第二试2HP27挡面对24攻击及一张6伤凋萎而判死读档，没有真实死亡退出帧，不拿27>24声称可活。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0005", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 1, "role": "support", "note": "末试螺线两刀使1敏→3敏，后空翻两张和防御各8合24，相对保留入口1敏的18多6；T2回1敏。仅补已观察后继牌挡及临时来源，不将磨蚀计已施。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0105", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 1, "role": "support", "note": "末试s447380—447388两刀依次敏捷1→2→3、HELICAL_DART_POWER1→2，旧挡逐攻击仅多1，随后两后空翻及防御各8，T2只剩入口1敏；T5先挡后刀不追补。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0063", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 1, "role": "support", "note": "末试T1九张攻击各给风的女儿1挡，加三张各8的挡牌合33；小刀临时敏捷另记，不按伤害段数或永久敏捷补挡。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0025", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 2, "role": "support", "note": "末试初3制品；T1中和消1，T2迷雾+消余2、未建立毒，扫腿才施虚弱；T3蛇咬才有7毒。敌力量T4为4、T7为9，末攻击35，未把玩家增敏当关闭敌成长。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0027", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 48, "turn": 3, "role": "support", "note": "末试T1触媒+建2层，T3蛇咬7毒实结7+6+5=18；T4残4毒实结4+3+2=9；T5残1毒只结1。T6普通触媒层数增至3但无毒，没有四次正伤证据，不扩推新公式。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0125", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 9, "turn": 8, "role": "support", "note": "d136护栏原plan3预测损10／伤12→plan1损0／伤0，实22HP不变；F40T1 d682原损9／伤33→损0／伤26，实70HP不变。两次预测省19血少19伤，原线未执行，不能把条件差当实战因果或认定护栏错误。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF
python3 /home/dw/Projects/agent-sts2/learner/ledger.py update <<'EOF'
{"id": "silent-0243", "by": "learner:postmortem", "evidence": [{"run": "Q9KFP3J3JNU5", "floor": 18, "turn": null, "role": "support", "note": "F17赢后16/70→F18 59/70，实回43；F33赢后4/70→F34 56/70，实回52。均与既有缺失HP乘80%向下取整一致；另九次SL恢复与六次营火实回121分账。"}], "where": {"lessons": ["Q9KFP3J3JNU5"]}, "note": "来源20261018-104311-f5f6011c-516e-4559-9a13-9d410f2cdf32-postmortem；只追加本角色支持与复盘去处，保留旧claim/first_run/prior/status/version/effect，无新增repeat。"}
EOF

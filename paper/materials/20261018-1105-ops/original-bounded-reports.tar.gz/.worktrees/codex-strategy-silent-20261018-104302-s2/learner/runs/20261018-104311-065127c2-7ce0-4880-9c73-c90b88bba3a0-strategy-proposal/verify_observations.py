import collections
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load(name):
    return json.loads((HERE / name).read_text())


frames = {r['line']: r for r in map(json.loads, (HERE / 'target-state-summaries.jsonl').open())}
checks = []


def record(name, lines, condition):
    assert condition, name
    checks.append({'name': name, 'state_lines': lines, 'verified': True,
                   'refs': [{k: frames[n][k] for k in ['run', 'line', 'offset', 'bytes', 'sha256']} for n in lines]})


def power(line, key):
    return frames[line]['player'].get(key, 0)


def enemy(line, ident=None):
    values = frames[line]['enemies']
    return values[0] if ident is None else next(e for e in values if e['id'] == ident)


def attack(line, ident=None):
    return sum(i.get('total_damage') or 0 for i in enemy(line, ident)['intents'])


record('棱柱T4/T5/T6实际净HP49→46→37，污染轮初消失', [274830, 274834, 274839],
       [frames[n]['hp'] for n in [274830, 274834, 274839]] == [49, 46, 37]
       and all(power(n, 'TAINTED_POWER') == 0 for n in [274830, 274834, 274839]))
record('棱柱火花3→6，T4技能污染3/6、能力不增加；T5先保留弃牌中间帧再核6/12/18',
       list(range(274830, 274840)),
       enemy(274830)['powers']['VITAL_SPARK_POWER'] == 3
       and enemy(274834)['powers']['VITAL_SPARK_POWER'] == 6
       and [power(n, 'TAINTED_POWER') for n in [274831, 274832, 274833]] == [3, 3, 6]
       and [power(n, 'TAINTED_POWER') for n in [274835, 274836, 274837, 274838]] == [0, 6, 12, 18])
record('下水道蚌当前攻击11/15/19，力量0/4/8', [273237, 273252, 273263],
       [attack(n) for n in [273237, 273252, 273263]] == [11, 15, 19]
       and [enemy(n)['powers'].get('STRENGTH_POWER', 0) for n in [273237, 273252, 273263]] == [0, 4, 8])
record('蚌T5显示14攻击/10挡/2血，实扣截断2，终敌16', [273268, 273269],
       attack(273268) == 14 and frames[273268]['block'] == 10 and frames[273268]['hp'] == 2
       and frames[273269]['hp'] == 0 and enemy(273269)['hp'] == 16)
record('电击23上限相同但index4→3，力量2→4、攻击17→19', [274308, 274313],
       [enemy(n, 'ZAPBOT')['max_hp'] for n in [274308, 274313]] == [23, 23]
       and [enemy(n, 'ZAPBOT')['index'] for n in [274308, 274313]] == [4, 3]
       and [enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'] for n in [274308, 274313]] == [2, 4]
       and [attack(n, 'ZAPBOT') for n in [274308, 274313]] == [17, 19])
record('抢夺后两步法敏捷−4→−2→0，失落退场后玩家力量−4→0',
       [274351, 274352, 274354, 274358],
       [power(n, 'DEXTERITY_POWER') for n in [274351, 274352, 274354]] == [-4, -2, 0]
       and power(274354, 'STRENGTH_POWER') == -4 and power(274358, 'STRENGTH_POWER') == 0
       and [e['id'] for e in frames[274358]['enemies']] == ['THE_FORGOTTEN'])
record('遗忘下一次抢夺后敏捷又为−2', [274362], power(274362, 'DEXTERITY_POWER') == -2)
record('实验体跨阶段4/111→212/212，旧毒和力量消失', [277512, 277513],
       enemy(277512)['hp'] == 4 and enemy(277512)['max_hp'] == 111
       and enemy(277513)['hp'] == enemy(277513)['max_hp'] == 212
       and enemy(277512)['powers']['POISON_POWER'] == 4
       and enemy(277512)['powers']['STRENGTH_POWER'] == 15
       and enemy(277513)['powers'].get('POISON_POWER', 0) == 0
       and enemy(277513)['powers'].get('STRENGTH_POWER', 0) == 0)
record('实验体已建触媒2但当前零毒；后来敏捷5→6不倒补23挡', [277520, 277525, 277526, 277527],
       power(277520, 'ACCELERANT_POWER') == 2 and enemy(277520)['powers'].get('POISON_POWER', 0) == 0
       and [power(n, 'DEXTERITY_POWER') for n in [277525, 277526]] == [5, 6]
       and frames[277525]['block'] == frames[277526]['block'] == frames[277527]['block'] == 23)
record('双蟹船夹板14加本轮6成20、临时−9力次轮消失', [278236, 278237, 278240, 278242],
       frames[278236]['block'] == 14 and frames[278240]['block'] == 20
       and enemy(278237, 'CRUSHER')['powers']['STRENGTH_POWER'] == -9
       and attack(278237, 'CRUSHER') == 0
       and enemy(278242, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) == 0
       and frames[278242]['hp'] == frames[278236]['hp'])
record('双蟹火箭朝向与虚弱分步57→38→28', [278249, 278252, 278253],
       [attack(n, 'ROCKET') for n in [278249, 278252, 278253]] == [57, 38, 28])
record('沙虫末轮显示37/22/5；实扣5、敌154→130与显示差15分列', [276433, 276434],
       attack(276433) == 37 and frames[276433]['block'] == 22
       and [frames[n]['hp'] for n in [276433, 276434]] == [5, 0]
       and [enemy(n)['hp'] for n in [276433, 276434]] == [154, 130])

pairs = []
expected = [(270216, 270282, [(3, 10), (15, 17)]), (271309, 271348, [(0, 45), (9, 38)]),
            (271992, 272040, [(9, 24), (14, 27)]), (271982, 272195, [(2, 25), (10, 34)])]
pair_inputs = load('same-fingerprint-pairs.json')
for a, b, values in expected:
    pair = next(p for p in pair_inputs if p['lines'] == [a, b])
    source = load(pair['run'] + '.selection-input.json')
    states = source['states']
    outcomes = []
    for index, item in enumerate(pair['decisions']):
        d = item['row']
        matches = [i for i, st in enumerate(states)
                   if st.get('observed_ts') == d['observed_ts'] and st.get('fingerprint') == d['fingerprint']]
        assert len(matches) == 1
        start_index = matches[0]
        following = next(st for st in states[start_index + 1:]
                         if st['state'].get('turn') != d['turn'])
        assert following['state']['turn'] == d['turn'] + 1
        assert following['state']['run']['floor'] == d['floor']
        start, end = states[start_index]['state']['combat'], following['state']['combat']
        loss = start['player']['current_hp'] - end['player']['current_hp']
        damage = sum(e['current_hp'] for e in start['enemies']) - sum(e['current_hp'] for e in end['enemies'])
        assert (loss, damage) == values[index]
        outcomes.append({'decision_line': item['line'], 'start_state_line': states[start_index]['_line'],
                         'next_turn_state_line': following['_line'], 'observed_net_hp_loss': loss,
                         'observed_net_enemy_hp_drop': damage, 'candidate_causal_result': None})
    pairs.append({'run': pair['run'], 'floor': pair['decisions'][0]['row']['floor'],
                  'turn': pair['decisions'][0]['row']['turn'], 'same_fingerprint': True,
                  'outcomes': outcomes, 'hp_loss_delta': values[1][0] - values[0][0],
                  'enemy_hp_drop_delta': values[1][1] - values[0][1]})

audit_summary = []
for run in load('dispatch.json')['runs']:
    out = load(run + '.selection-output.json')
    segments = out['segments']
    assert all(s['actual_full_candidate_result'] is None and s['actual_rollout_best'] is None for s in segments)
    audit_summary.append({'run': run, 'segments': len(segments), 'actions': len(out['observed_actions']),
                          'observed_turns': len(out['observed_turns']),
                          'turn_status': dict(collections.Counter(t['status'] for t in out['observed_turns'])),
                          'actual_full_candidate_result_nonnull': 0, 'actual_rollout_best_nonnull': 0})
result = {'checks': checks, 'paired_observed_windows': pairs, 'consumer_audits': audit_summary,
          'limitations': ['本脚本只核原始观测和既有消费者输出，不是生产代码测试或策略改善验证。',
                          '同指纹起点不控制后续抽牌、目标、随机药瓶和重规划；窗口净变化不归因单个候选。',
                          '跨帧index、类型与最大血量不能认证持久实例或召唤代际身份。']}
(HERE / 'verified-observations.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'observation_checks': len(checks), 'paired_observed_windows': pairs,
                  'consumer_audits': audit_summary}, ensure_ascii=False))

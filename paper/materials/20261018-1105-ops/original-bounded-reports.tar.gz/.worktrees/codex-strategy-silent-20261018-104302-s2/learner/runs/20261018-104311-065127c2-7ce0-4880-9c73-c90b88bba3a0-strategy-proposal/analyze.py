import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', HERE.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def powers(items):
    return {p['power_id']: p.get('amount') for p in items or []}


manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
batch = json.loads((HERE / 'dispatch.json').read_text())
runs = set(batch['runs'])
by_stream = {}
checks = []
for entry in manifest:
    stream = entry['stream']
    path = HERE / 'evidence' / (stream + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
    rows = [json.loads(line) for line in path.open()]
    counts = collections.Counter()
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for row in rows:
            source.seek(row['offset'])
            raw = source.read(row['bytes'])
            assert hashlib.sha256(raw).hexdigest() == row['sha256']
            assert json.loads(raw) == row['row']
            assert row['offset'] + row['bytes'] <= entry['source_size']
            assert extract.run_identity(row['row']) == row['run_id'] in runs
            counts[row['run_id']] += 1
    assert all(counts[r] == entry['counts'][r] for r in runs)
    by_stream[stream] = rows
    checks.append({'stream': stream, 'count': len(rows), 'source_size': entry['source_size'],
                   'counts': dict(counts), 'source_bytes_verified': True})
save('evidence-verification.json', checks)

targets = {'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39}, 'CA5KE8GFJ9X2': {13},
           '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}
summaries = []
for frame in by_stream['states']:
    row = frame['row']
    state = row['state']
    run = frame['run_id']
    info = state.get('run') or {}
    floor = info.get('floor')
    if floor not in targets[run]:
        continue
    assert str(info.get('character_id')).lower() == 'silent' and info.get('ascension') == 10
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    summaries.append({'run': run, 'line': frame['line'], 'offset': frame['offset'], 'bytes': frame['bytes'],
                      'sha256': frame['sha256'], 'observed_ts': row.get('observed_ts'),
                      'screen': state.get('screen'), 'floor': floor, 'turn': state.get('turn'),
                      'hp': player.get('current_hp', info.get('current_hp')), 'block': player.get('block'),
                      'played': combat.get('cards_played_this_turn'), 'player': powers(player.get('powers')),
                      'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                                   'max_hp': e.get('max_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
                                   'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                                  for e in combat.get('enemies', [])]})
with (HERE / 'target-state-summaries.jsonl').open('w') as out:
    for row in summaries:
        out.write(json.dumps(row, ensure_ascii=False) + '\n')

decision_index = {x['line']: x for x in by_stream['decisions']}
pairs = []
for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    x, y = decision_index[a], decision_index[b]
    assert x['run_id'] == y['run_id']
    assert x['row']['fingerprint'] == y['row']['fingerprint']
    pairs.append({'run': x['run_id'], 'lines': [a, b], 'same_fingerprint': True,
                  'decisions': [x, y]})
save('same-fingerprint-pairs.json', pairs)

excluded = []
for run in batch['runs']:
    ds = []
    for item in by_stream['decisions']:
        if item['run_id'] != run:
            continue
        row = dict(item['row'], _line=item['line'], _source_sha256=item['sha256'])
        if row.get('floor') not in targets[run]:
            continue
        if not row.get('decision_id'):
            excluded.append({'run': run, 'line': item['line'], 'sha256': item['sha256'],
                             'reason': '原日志无 decision_id 的元数据；不伪造动作或尝试号', 'row': item['row']})
            continue
        ds.append(row)
    ds.sort(key=lambda row: row['observed_ts'])
    states = [dict(x['row'], _line=x['line'], _source_sha256=x['sha256'])
              for x in by_stream['states'] if x['run_id'] == run
              and (x['row']['state'].get('run') or {}).get('floor') in targets[run]]
    run_rows = [x['row'] for x in by_stream['runs'] if x['run_id'] == run]
    assert len(run_rows) == 1
    save(run + '.selection-input.json', {'run': run_rows[0], 'decisions': ds, 'states': states})
save('selection-input-exclusions.json', excluded)
print(json.dumps({'verified_references': sum(x['count'] for x in checks), 'streams': checks,
                  'target_frames': len(summaries), 'same_fingerprint_pairs': len(pairs),
                  'excluded_metadata': len(excluded)}, ensure_ascii=False))

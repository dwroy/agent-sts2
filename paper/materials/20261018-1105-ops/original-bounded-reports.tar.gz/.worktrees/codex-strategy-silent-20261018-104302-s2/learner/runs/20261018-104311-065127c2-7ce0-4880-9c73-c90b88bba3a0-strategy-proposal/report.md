# 静默策略队列核验报告

本批十项全部waiting；无源码改动，fixes=[]、merged=null。完整40位base为`c1d54326e65bd3681fb72261ee2381609d8e0785`，HEAD保持该值，工作树tracked/index干净。
逐项提案、账本、证据层/回合、已有实现、反例、预期行为、验证与回退见[proposal.md](proposal.md)。最终机器回执见[result.json](result.json)。本批未另建重复提案id，原队列id全覆盖。

## 身份与证据

只处理本批十个已领取id；普通批次不套用专题纯研究或不可变实现请求口径。先读README、最新STATE-2026-10-18、decision-log末尾、learning-protocol与learning-code-proposals。未派下级agent，未运行play、游戏、LLM、网络或模拟。
日志通过本工作树learner/extract_evidence.py共同入口提取，额外显式包含runs/fight-plans；每流独立冻结source_size，保存原行offset/bytes/SHA及计数，再逐条seek原日志核字节/SHA/JSON及无冲突显式身份，共8274条引用。
归局读取run_id、state.run_id、run-plans.run及fingerprint.run，未把正文提及算所属局。六局runs记录均SILENT/A10/失败，结束层为CA13、5PM39、DUZ30、8J33、YF48、XP33；SL尝试不增加独立局数。verified-runs.json保留原行与来源坐标。

| 流 | 本批行数 | 冻结source_size |
|---|---:|---:|
| states | 4062 | 14290395449 |
| decisions | 3941 | 2503323072 |
| sl-attempts | 38 | 47706736 |
| run-config | 6 | 2080396 |
| run-plans | 33 | 9283264 |
| brain | 188 | 807673732 |
| runs | 6 | 371605 |
| fight-plans | 0 | 2233957 |

fight-plans零行仅说明此截点/六局未选到该流记录，不据此断言日志缺失。未覆盖任何旧抽取报告或零行初稿。
分析定位1062个关键楼层状态帧；生产消费者读回输入限定DUZ F27、5PM F38/39、CA F13、8J F17/33、YF F33/48、XP F33，保留真实原行号。selection-input-exclusions.json为零项：上述限定楼层无需排除无decision_id元数据；这不证明全局所有元数据都是动作。

## 同指纹实际窗口

以下是同一指纹起点至下一玩家轮的观测净变化；不是完整候选因果认证。

| 局/层/回合 | decisions原行 | 实际净损血 | 敌本体净扣血 | 差额（后者减前者） |
|---|---|---|---|---|
| 8JRE1C4H4Z2W F33 T2 | 270216/270282 | 3→15 | 10→17 | HP损失+12、敌净扣+7 |
| YF0LXT1QSTGG F48 T1 | 271309/271348 | 0→9 | 45→38 | HP损失+9、敌净扣-7 |
| XP2SL33HT0D9 F33 T3 | 271992/272040 | 9→14 | 24→27 | HP损失+5、敌净扣+3 |
| XP2SL33HT0D9 F33 T1 | 271982/272195 | 2→10 | 25→34 | HP损失+8、敌净扣+9 |

verified-observations.json保存12组原帧观察核对、四组窗口起止原行与限制；same-fingerprint-pairs.json保留对应原决策。零血实际净扣不冒充未截断入伤，未结算毒不补记伤害。

## 现有消费者及源码

本批对六份冻结单局限定楼层输入调用原learner/audit-selection.ts，六次实际退出0、stderr空，命令/输入输出SHA见selection-execution-results.json。未修改消费者或注入知识。

| 局 | 候选段 | 原动作行 | 观测回合 | 已核整轮端点/未知 |
|---|---:|---:|---:|---|
| DUZUBAJ3A8GP | 8 | 45 | 8 | 0/8 |
| 5PM6JAQG6FNQ | 18 | 108 | 15 | 7/8 |
| CA5KE8GFJ9X2 | 4 | 26 | 5 | 0/5 |
| 8JRE1C4H4Z2W | 66 | 277 | 57 | 44/13 |
| YF0LXT1QSTGG | 52 | 343 | 55 | 40/15 |
| XP2SL33HT0D9 | 58 | 244 | 45 | 28/17 |

总206段、1043动作、185个观测回合，119个回合有端点、66个未知。每段actual_full_candidate_result和actual_rollout_best实际均为null；非空计数为0不写成数值结果0。这是该保守API的范围，不据此断言日志一律无法人工核验；上表四组实际窗口已另外复核。已有单动作回执、观测区间、药槽与终局审计不等同整条候选执行或逐来源因果认证。

source-manifest.json固定22份执行/消费源码的base blob/SHA、取证时live=`b155d00a36080418149e63d2f21b491d34d7f40a`、实际live祖先源码commit与双份.txt字节快照。所选叶在取证时live均无未提交源码；17叶与base相同，5叶有差，完整有界差异保存base-live-source.patch。
5叶差异包括3叶署名注释、rollout/rollout-live的独立Queen/Amalgam条件路径与署名注释；本批不讨论该独立机制、不套到六局，也不冒称base/live整树等价。原六局run-config均为dirty知识数据；只有prefix/config摘要，不能复原原实际DB/移动表原字节。

可核的已有子实现所在实际live祖先：

- agent/src/reflex/silent-selection-audit.ts：`05cd292c6f01bb31e406473d3a9843e659d62b93`。
- agent/src/reflex/silent-selection-dispatch.ts：`bade647f9fe4c9103b40e2f26b26296692ad24b7`。
- agent/src/reflex/silent-sl-resource-comparison.ts：`0e4fe4df89a06682468e0e4716c12126e76369d5`。
- agent/src/reflex/silent-hp-guard-audit.ts：`a8b1f8be153fe4f3a34146117546c2178f2e446b`。
- agent/src/reflex/silent-phase-current.ts：`8698c581dac6c7e957f50a381586960a6d0c9b57`。
- learner/lib/selection-execution.ts：`cf72bd21148059f111f760cc98a727369e34a47e`。
- learner/lib/selection-terminal.ts：`04921bd785ac6838066522f91ea0bb6ab95cb6a1`。
- learner/lib/selection-turn.ts：`9b87d54f097d84521152e6cca8d6072af8140394`。

这些是包含当前源码叶的真实live祖先，不冒称其全部改动专为本十提案；不能由这些局部功能把宽提案整体登记implemented/duplicate。

## 失败、更正与验收范围

原verify-observations-initial.log退出1：本批分析脚本错将states274835的生存者弃牌中间帧当作污染已结算，原0被错期待为6。原脚本字节保留verify_observations.initial.txt。读回274835—274838后按0/6/12/18修正，仅改scratch验证脚本；verify-observations-corrected.log退出0，12组观察及四组窗口通过。没有改原日志、机制源码或旧提案，不把这个材料复算错误报为产品bug。
初始源码路径探针selection-trace.ts/phase-facts.ts/core/loop.ts等不存在；随后用rg确定真实silent-selection-*、silent-phase-*、hand/loop路径，实际使用源码在manifest内。路径探针不构成代码测试结果。
无生产源码或知识修改，未运行tsc/vitest/沙箱测试，不冒造撤源码失败/恢复通过；tests固定为三null。上述离线CLI与原帧复算0不替代源码测试、自然采用或胜率改善。
未合入live，无新提交/版本，不登记shipped，不执行上线双通知或宽父关闭。所有原日志、原提案、初稿与失败材料保留；无工作树回收。

## 账本交付

仅通过根learner/ledger.py update追加本角色既有账本的where.proposal及note，by=learner:strategy-proposal；无新claim、无新增支持局、无status/version/first_run/prior/effect改写。原shipped条目不降回proposed，队列waiting与账本历史状态分开。实际追加及check的退出码、行偏移/字节/SHA、受保护字段核对另见ledger-update-results.json与ledger-protected-check.json；执行结果须以回执为准。
根队列的waiting由最终proposal_results交原调度器消费，本批不直接手改队列或learn.json。学习入库父要求及原异议保持，报告不代表已入经验库、大脑采用或量化学习完成。

实际ledger update退出0，30条原账本追加成功，原物理前缀完整保留；所有所列受保护字段前后零变化。根ledger check退出0，516项、0问题。回执与原追加逐行引用已落盘。
gitleaks目录扫描实际退出0，扫描约321.16MB、无发现；原redacted日志与JSON保留。最终HEAD/工作树/索引及本批身份、十项覆盖检查见final-check.json，材料逐文件SHA见artifact-manifest.json。

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BATCH = '20261018-104302-s2-strategy-proposal'


def load(name):
    return json.loads((HERE / name).read_text())


items = [
    ('c20b5139dd0dff71', '棱柱技能污染', 'DUZUBAJ3A8GP F27 T4—6；states 274830—274839',
     '火花3→6，T4污染0→3→3→6；T5须先保留生存者弃牌中间帧0，结算后才6→12→18。实际49→46→37HP；迷雾同时有毒/弱收益。',
     'turn-solver.ts 已按技能累积污染并逐击计算；rollout.ts 已接火花增长。',
     '缺原运行实际DB/招式表字节与毒、弱、挡、污染、火花联合校准；已核净损9不支持少打技能规则。'),
    ('ae9e692d680e3819', '抢夺属性与返还', '5PM6JAQG6FNQ F39 T2/4/6；states 274341、274351—274362、274379、274391',
     '两步法令敏捷−4→−2→0，失落退场后玩家力量−4→0，T6遗忘再夺后敏捷−2；末试毒杀失落仍败。',
     '当前负力量/敏捷现场输入及招式施加属性路径存在；这不等同于逐来源累计被夺量。',
     '缺逐实体累计被夺量与其他属性来源的完整区分、遗忘退场返敏端点和联合候选校准；不能把当前总属性当被夺量或规定击杀序。'),
    ('52f1e1bd2e7db0ed', '下水道蚌加压', 'CA5KE8GFJ9X2 F13 T1—5；states 273237—273269',
     '同招显示11/15/19，力量0/4/8；末轮弱后14、10挡、2HP，实扣仅2截断，敌最终16。',
     'monster-db.ts 的当前进阶HP/攻击读取没有五样本门槛；room-costs.ts 明确保留MEASURED_ROOM_MIN_N=5。',
     '首样本事实读取及房间代价五样本门槛已有；缺原实际移动输入、加压/弱/覆甲联合重放及完整减层条件，不新增固定房间成本。'),
    ('6dd8bbff876be528', '电击逐实体成长', '5PM6JAQG6FNQ F38 T3—4；states 274308—274313',
     '23最大血的电击从index4变3，力量2→4、攻击17→19；T3玩家61→31，电击仍攻击，T4才退场。',
     'rollout.ts 的STRENGTH_GROWTH_POWERS含HIGH_VOLTAGE_POWER，敌人循环分别加growth。',
     'HIGH_VOLTAGE增长已有；缺召唤代际持久身份、原实际移动输入及另一杀序完整后继；index重排不能认证新旧实体，不规定先杀爪牙。'),
    ('578e415a259e6835', '沙虫机制、SL与资源审计', '8JRE1C4H4Z2W F17 T6、F33 T2/T5/T11；decisions 270216/270282；states 276433—276434',
     '同起点T2实损3→15、敌净扣10→17；末轮5HP/22挡/37攻击，实扣5、敌154→130，显示未挡15另列。候选差额不等于实际保血。',
     'selection_audit、单动作回执、SL资源预测、HP护栏审计和离线观测窗口均已有；末轮终态审计已有。',
     '缺跨抽弃牌、生成、用药和重规划的完整候选执行及分来源资源认证；原金刚杵误链silent-0016保留，不能把局部审计当整项完成。'),
    ('c0767768bf6a7ab1', '全败SL资源代价', 'YF0LXT1QSTGG F48第二/第三试T1；decisions 271309/271348；states 277327—277337、277366—277373',
     '两起点完整指纹相同；实际损0→9、敌净扣45→38。第六次恢复挡续步仍败；F33存在成功SL反例，不否定全部SL。',
     'silent-sl-resource-comparison.ts 已分列预测与未认证执行；离线审计已有回执、区间、选牌与重问边界。',
     '同轮端点和预测对照已有；缺跨重规划完整候选归属、逐来源HP价及受控整战后继，不从24/24全败拟惩罚系数或禁止探索。'),
    ('a46bdb7fe711d79a', '实验体分阶段兑现', 'YF0LXT1QSTGG F48末试T3—5；states 277512—277528',
     '4/111→212/212清旧毒/力；触媒已建2但当前零毒。敏捷5→6时23挡不倒补，18HP对44攻击/23挡仍差3。',
     'silent-phase-current.ts 已区分持有组件/已建能力/当前毒，silent-phase-reference.ts 已分列当前阶段结束参考；离线区间记录原帧。',
     '当前阶段/持有组件/已建能力快照已有；缺逐候选施毒、结算、消耗附伤与敏捷顺序的联合执行校准，不启用能力优先级。'),
    ('1044224808015e5c', '双蟹B2零胜并列血价', 'XP2SL33HT0D9 F33 T1/T3；decisions 271982/272195、271992/272040',
     'T3损9→14、敌净扣24→27；T1损2→10、敌净扣25→34。T1同时成长，末试T2临时减力/朝向后零损是边界。',
     'explore.ts 仍按B2或rollout门槛与原排名探索；同题资源比较及单动作审计已有，不把零胜并列写安全。',
     '缺同抽序、随机药瓶落点和相同预算的完整替线、成长后继及独立验证；B2零胜并列不足以启用新保血门槛。'),
    ('7cbc6005db712ba9', '双蟹朝向与能力窗口', 'XP2SL33HT0D9 F33末试T2—5；states 278236—278259',
     '船夹板14加本轮6成20；爪0→−9力次轮恢复；火箭57→38→28；4敏脆弱偏折6挡，T4实际33→11HP。',
     'passive-pieces.ts 已有船夹板T2/14；当前求解器含朝向、虚弱、临时减力和能力时点，离线读回保留端点。',
     '局部机制已有；缺抽弃牌后完整候选的联合执行与分来源消费认证，不将局部实现登记整项duplicate。'),
    ('c59f592f1427a67e', '综合机制、SL、路线资源', 'YF0LXT1QSTGG F33/F48；XP2SL33HT0D9 F33；沿用两原局及原账本',
     '本批复核两局上述阶段、临时减力、轮初挡和三组血价端点；原101局历史支持数未在本批重做，不能把重读当新独立支持。',
     '当前机制、预测资源、药槽观测、末轮与整轮端点审计是已有子项；完整候选和因果归属保持未知。',
     '缺逐来源HP/药/恢复账、完整候选执行及路线/休息/药水时机受控替线联合认证；本批未重做原101局历史审计。'),
]
proposals = load('selected-proposals.json')
by_id = {p['id']: p for p in proposals}
assert {f'silent-proposal-{i[0]}' for i in items} == set(by_id)
base = (HERE / 'base.txt').read_text().strip()
dispatch = load('dispatch.json')
observations = load('verified-observations.json')
verification = load('evidence-verification.json')
sources = load('source-manifest.json')
results = [{'id': 'silent-proposal-' + i[0], 'state': 'waiting', 'reason': i[5]} for i in items]
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': base,
         'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
text = f'''# 本批十项策略提案逐项处置

本批：{BATCH}。角色：silent；核实范围：六个派发局，均A10。
基线：`{base}`；普通批次，`git merge --no-edit main` 为 Already up to date。
根learn.json本批为task=strategy-proposal、reason=proposal，含十个proposal_ids，无research_request/implementation_request/proposal_repair。
普通专题文件绑定另一旧批次，本批不承接专题，不读取其他专题代替本批身份。

结论：十项均waiting。本批未发现可由这六局证明、且当前实现尚未覆盖的独立策略增量；不重复实现已存在的局部机制/审计，也不把宽提案整体标duplicate。
未修改生产源码、经验或知识数据，无提交、合入、eval版本或shipped。原选项、排序、护栏、药水、SL和终局参数保持；其他角色不受影响。
来源任务、原经验、原账本列表及完整原文见selected-proposals.json与十份*.original.md；原文件SHA逐项相等，proposal-queue-refs.json保存原add与最新状态的真实根队列行偏移/字节/SHA。

'''
for suffix, title, evidence, fact, existing, missing in items:
    p = by_id['silent-proposal-' + suffix]
    text += f'''## {p['id']}：{title}

- 来源任务：{p['source_task']}；实现任务：strategy-proposal；原规则变更标记：{p.get('rule_changes', False)}。
- 原账本：{', '.join(p['ledger'])}。
- 证据：{evidence}。
- 核实事实及边界：{fact}
- 既有实现：{existing}
- 处置：waiting。{missing}
- 预期行为：现有事实/预测保持；后续只在来源可核、完整执行条件明确的范围补接。缺证时不强制目标顺序、少打技能、保血或能力优先。
- 验证方法：使用本批冻结原帧/真实行号、固定现场与实际招式输入逐步比对；候选预测、动作回执、观测净变化、逐来源消费和整战结果分列。策略参数须按独立run分组、时间后移验证，同一SL存档不拆入训练和验证。
- 反例与未知：保留上列收益/重规划/失败边界与原文反例；没有未选替线实打时不宣称必胜。回退：本批无新源码可回退；后续实现须单独提交，按实际live源码及固定红绿验收回退。

'''
text += '''## 支持、反例与原有异议

不拟合任何全局HP惩罚、能力分数、房间固定成本、必休血线或药水持有价值；四组同指纹只确认实际回合窗口，不控制未来抽牌、随机落点、后续重规划或整战，不能推断单候选因果与胜率。
YF本局F33有成功SL；原提案记录恢复挡续步仍败和能力已建仍败，继续作为反例/限制。此两处原文限制不冒称本批重新做了全历史胜率审计。
578原经验把金刚杵链接到silent-0016；当前原账本claim是护喉甲覆甲。这是原批已有异议，原提案及原id保留，本批不改claim/来源，不以该误链推学习增益，请ops按原通告链保留。
既有经验的宽asc与历史支持数量是原记录，不等于本批验证了未观察进阶；本次机制和策略窗口均以六局A10为界。
'''
(HERE / 'proposal.md').write_text(text)

report = f'''# 静默策略队列核验报告

本批十项全部waiting；无源码改动，fixes=[]、merged=null。完整40位base为`{base}`，HEAD保持该值，工作树tracked/index干净。
逐项提案、账本、证据层/回合、已有实现、反例、预期行为、验证与回退见[proposal.md](proposal.md)。最终机器回执见[result.json](result.json)。本批未另建重复提案id，原队列id全覆盖。

## 身份与证据

只处理本批十个已领取id；普通批次不套用专题纯研究或不可变实现请求口径。先读README、最新STATE-2026-10-18、decision-log末尾、learning-protocol与learning-code-proposals。未派下级agent，未运行play、游戏、LLM、网络或模拟。
日志通过本工作树learner/extract_evidence.py共同入口提取，额外显式包含runs/fight-plans；每流独立冻结source_size，保存原行offset/bytes/SHA及计数，再逐条seek原日志核字节/SHA/JSON及无冲突显式身份，共{sum(x['count'] for x in verification)}条引用。
归局读取run_id、state.run_id、run-plans.run及fingerprint.run，未把正文提及算所属局。六局runs记录均SILENT/A10/失败，结束层为CA13、5PM39、DUZ30、8J33、YF48、XP33；SL尝试不增加独立局数。verified-runs.json保留原行与来源坐标。

| 流 | 本批行数 | 冻结source_size |
|---|---:|---:|
'''
for e in verification:
    report += f"| {e['stream']} | {e['count']} | {e['source_size']} |\n"
report += '''
fight-plans零行仅说明此截点/六局未选到该流记录，不据此断言日志缺失。未覆盖任何旧抽取报告或零行初稿。
分析定位1062个关键楼层状态帧；生产消费者读回输入限定DUZ F27、5PM F38/39、CA F13、8J F17/33、YF F33/48、XP F33，保留真实原行号。selection-input-exclusions.json为零项：上述限定楼层无需排除无decision_id元数据；这不证明全局所有元数据都是动作。

## 同指纹实际窗口

以下是同一指纹起点至下一玩家轮的观测净变化；不是完整候选因果认证。

| 局/层/回合 | decisions原行 | 实际净损血 | 敌本体净扣血 | 差额（后者减前者） |
|---|---|---|---|---|
'''
for p in observations['paired_observed_windows']:
    a, b = p['outcomes']
    report += f"| {p['run']} F{p['floor']} T{p['turn']} | {a['decision_line']}/{b['decision_line']} | {a['observed_net_hp_loss']}→{b['observed_net_hp_loss']} | {a['observed_net_enemy_hp_drop']}→{b['observed_net_enemy_hp_drop']} | HP损失{p['hp_loss_delta']:+d}、敌净扣{p['enemy_hp_drop_delta']:+d} |\n"
report += '''
verified-observations.json保存12组原帧观察核对、四组窗口起止原行与限制；same-fingerprint-pairs.json保留对应原决策。零血实际净扣不冒充未截断入伤，未结算毒不补记伤害。

## 现有消费者及源码

本批对六份冻结单局限定楼层输入调用原learner/audit-selection.ts，六次实际退出0、stderr空，命令/输入输出SHA见selection-execution-results.json。未修改消费者或注入知识。

| 局 | 候选段 | 原动作行 | 观测回合 | 已核整轮端点/未知 |
|---|---:|---:|---:|---|
'''
for a in observations['consumer_audits']:
    report += f"| {a['run']} | {a['segments']} | {a['actions']} | {a['observed_turns']} | {a['turn_status'].get('observed_turn_endpoints', 0)}/{a['turn_status'].get('unknown', 0)} |\n"
report += f'''
总206段、1043动作、185个观测回合，119个回合有端点、66个未知。每段actual_full_candidate_result和actual_rollout_best实际均为null；非空计数为0不写成数值结果0。这是该保守API的范围，不据此断言日志一律无法人工核验；上表四组实际窗口已另外复核。已有单动作回执、观测区间、药槽与终局审计不等同整条候选执行或逐来源因果认证。

source-manifest.json固定22份执行/消费源码的base blob/SHA、取证时live=`{sources[0]['live_head']}`、实际live祖先源码commit与双份.txt字节快照。所选叶在取证时live均无未提交源码；17叶与base相同，5叶有差，完整有界差异保存base-live-source.patch。
5叶差异包括3叶署名注释、rollout/rollout-live的独立Queen/Amalgam条件路径与署名注释；本批不讨论该独立机制、不套到六局，也不冒称base/live整树等价。原六局run-config均为dirty知识数据；只有prefix/config摘要，不能复原原实际DB/移动表原字节。

可核的已有子实现所在实际live祖先：

'''
for path in ['agent/src/reflex/silent-selection-audit.ts', 'agent/src/reflex/silent-selection-dispatch.ts',
             'agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/reflex/silent-hp-guard-audit.ts',
             'agent/src/reflex/silent-phase-current.ts', 'learner/lib/selection-execution.ts',
             'learner/lib/selection-terminal.ts', 'learner/lib/selection-turn.ts']:
    e = next(x for x in sources if x['path'] == path)
    report += f"- {path}：`{e['live_last_source_commit']}`。\n"
report += '''
这些是包含当前源码叶的真实live祖先，不冒称其全部改动专为本十提案；不能由这些局部功能把宽提案整体登记implemented/duplicate。

## 失败、更正与验收范围

原verify-observations-initial.log退出1：本批分析脚本错将states274835的生存者弃牌中间帧当作污染已结算，原0被错期待为6。原脚本字节保留verify_observations.initial.txt。读回274835—274838后按0/6/12/18修正，仅改scratch验证脚本；verify-observations-corrected.log退出0，12组观察及四组窗口通过。没有改原日志、机制源码或旧提案，不把这个材料复算错误报为产品bug。
初始源码路径探针selection-trace.ts/phase-facts.ts/core/loop.ts等不存在；随后用rg确定真实silent-selection-*、silent-phase-*、hand/loop路径，实际使用源码在manifest内。路径探针不构成代码测试结果。
无生产源码或知识修改，未运行tsc/vitest/沙箱测试，不冒造撤源码失败/恢复通过；tests固定为三null。上述离线CLI与原帧复算0不替代源码测试、自然采用或胜率改善。
未合入live，无新提交/版本，不登记shipped，不执行上线双通知或宽父关闭。所有原日志、原提案、初稿与失败材料保留；无工作树回收。

## 账本交付

仅通过根learner/ledger.py update追加本角色既有账本的where.proposal及note，by=learner:strategy-proposal；无新claim、无新增支持局、无status/version/first_run/prior/effect改写。原shipped条目不降回proposed，队列waiting与账本历史状态分开。实际追加及check的退出码、行偏移/字节/SHA、受保护字段核对另见ledger-update-results.json与ledger-protected-check.json；执行结果须以回执为准。
根队列的waiting由最终proposal_results交原调度器消费，本批不直接手改队列或learn.json。学习入库父要求及原异议保持，报告不代表已入经验库、大脑采用或量化学习完成。
'''
(HERE / 'report.md').write_text(report)
links = {}
for p in proposals:
    for ident in p['ledger']:
        links.setdefault(ident, []).append(p['id'])
notes = {r['id']: r['reason'] for r in results}
updates = [{'id': ident, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
            'note': f'{BATCH}；六局A10原证据重核；' + '；'.join(p + '=waiting：' + notes[p] for p in ids)
                    + '；无源码/知识/规则修改，未合入，无新增独立样本；原状态/版本及首证保持。'}
           for ident, ids in sorted(links.items())]
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'proposal_results': len(results), 'ledger_links': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

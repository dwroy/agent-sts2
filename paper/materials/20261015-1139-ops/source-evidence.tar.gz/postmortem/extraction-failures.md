# 本次抽取初稿失败记录

下列为本会话工具输出的转录，不冒充原始生产日志。原始生产日志未修改，失败只发生在临时分析脚本，随后固定抽取校验通过。

- metrics.py初稿按分号切code rank，遇到附带calc mismatch说明的文本，报ValueError: invalid literal for int() with base 10: '2 [calc mismatch: solver says ending now does not kill, mod says lethal: no end-of-turn block, Regen or Buffer the flag leaves out'。修为只读开头数字的正则，不更改生产内容或统计分母。
- 临时交互式查看将criteria字典当可切片字符串，报KeyError: slice(None, 2500, None)。后续按JSON字典及每个候选的JSON值解析。
- 初步代码定位同时查询不存在的agent/src/brain/rest.ts，rg返回该文件不存在；随后仅对真实reflex/combat-plan.ts、reflex/turn-solver.ts和sim/route-projection.ts做源码对照。
- 早期大段日志／旧账本输出在工具返回被截断；后续按局号保存完整匹配行及_line/_offset，以白名单字段打印，再按原始字节seek核对。不能将被截断的终端展示当作完整取证结果。

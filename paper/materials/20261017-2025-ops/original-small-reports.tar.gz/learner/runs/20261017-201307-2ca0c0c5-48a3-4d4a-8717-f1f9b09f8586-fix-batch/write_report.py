import json
from pathlib import Path


SCRATCH = Path('/home/dw/Projects/agent-sts2/learner/runs/20261017-201307-2ca0c0c5-48a3-4d4a-8717-f1f9b09f8586-fix-batch')
audit = json.loads((SCRATCH / 'source-audit.json').read_text())
skipped = [
    {
        'item': '出牌、药水、SL、终局、路线及角色机制条目（含0256/0260/0263/0266/0308/0311/0317/0319/0320/0322/0324/0329/0334/0339/0344/0347/0349/0362/0365/0481/0487）',
        'reason': '策略类；沿已有独立strategy-proposal链处理，不重复派发或加入开发者游戏知识。',
    },
    {
        'item': 'silent-0332实际nonpositive-hp资源契约根因',
        'reason': '证据不足；沿原专用owner链。样本身份及诊断窄修不等于资源契约根因已修。',
    },
    {
        'item': 'sandbox-glob-startup-race目录生命周期与磁盘压力宽项',
        'reason': '证据不足；窄启动恢复、租约保存及回收修复已存在，目录删除归属与上游扫描时序未确定。',
    },
    {
        'item': 'arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression及调度公平性调查',
        'reason': '独立架构、策略或归因任务，范围太大，超出本普通纯bug批次。',
    },
    {
        'item': 'core-build-notify-222802-rc2旧原生通知恢复',
        'reason': '证据不足；历史stderr及送达证据缺失，不重发可能已经送达的通知。',
    },
    {
        'item': 'Codex缓存实测、DPR/B2性能及历史宿主超时根因',
        'reason': '证据不足或独立性能调查；固定测试确定性子项已修，不代表自然性能根因已解决；本批不调用模型或网络。',
    },
]
report = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': skipped,
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': 0},
    'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md'),
}
encoded = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
(SCRATCH / 'report.json').write_text(encoded)
lines = [
    '## 修 bug 回报',
    '- 合并基线：main → ' + audit['base'],
    '- 修复（每条一行）：无新增修复；181个相关源码/测试路径与上批一致，47条未勾选项已逐项留处置清单。队列仅新增既有赤牛串刺修复的验收回执。',
]
for item in audit['already_fixed']:
    lines.append('- 已被别人修掉的：' + item['item'] + ' — ' + item['commit'])
for item in skipped:
    lines.append('- 没修的：' + item['item'] + ' — ' + item['reason'])
lines.extend([
    '- 测试：tsc未运行（退出码null）；vitest 0文件 / 0用例 / 退出码null。本批未改代码、未提交，无新增修复需要撤修红绿测试；不借历史检查作为本批结果。',
    '- 合入：未合入（本批无新提交；42项既有修复均为基线、main及核对时live ' + audit['live'] + '的祖先；未重复合入、编号或更新账本）。',
    '- 需要 Roy 定的事：无',
    '', '```json', encoded.rstrip(), '```', '',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines))
print('报告已保存；既有修复', len(audit['already_fixed']), '项；本批fixes=[]、merged=null、tests=null。')

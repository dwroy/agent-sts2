import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261017-194302'
SCRATCH = ROOT / 'learner/runs/20261017-194307-085eaaee-c882-4af9-a011-0e331c8b0003-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261017-182649-7faa35aa-4105-4992-af30-167d860c59c0-fix-batch'


def git(*args, cwd=WORK):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


def ancestor(commit, head):
    result = subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, head])
    if result.returncode not in (0, 1):
        raise RuntimeError('Unable to verify ancestry')
    return result.returncode == 0


def blob_map(ref, paths):
    result = {}
    for entry in git('ls-tree', '-r', '-z', ref, '--', *paths).split(b'\0'):
        if entry:
            metadata, path = entry.split(b'\t', 1)
            result[path.decode()] = metadata.split()[2].decode()
    return result


previous = json.loads((PREVIOUS / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
main = git('rev-parse', 'main').decode().strip()
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
(SCRATCH / 'fix-queue-v4.snapshot.md').write_bytes(queue)
queue_unchanged = queue == (PREVIOUS / 'fix-queue.snapshot.md').read_bytes()
paths = sorted(set(previous['source_blobs']) | {
    'agent/src/reflex/silent-sl-resource-comparison.ts',
    'agent/tests/silent-sl-resource-comparison.test.ts',
    'agent/tests/silent-sl-sandpit-state.json',
    'agent/tests/silent-akabeko-skewer.test.ts',
    'agent/tests/silent-akabeko-skewer-evidence.json',
})
base_blobs = blob_map(base, paths)
live_blobs = blob_map(live, paths)
source_blobs = {}
changed = []
for path in paths:
    if Path(path).name == '.env' or path.endswith('.env'):
        raise RuntimeError('Denied input')
    content = (WORK / path).read_bytes()
    working_blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    source_blobs[path] = {'blob': base_blobs[path], 'working_blob': working_blob,
                          'sha256': hashlib.sha256(content).hexdigest(), 'live_blob': live_blobs.get(path)}
    old = previous['source_blobs'].get(path, {}).get('blob')
    if old != base_blobs[path]:
        changed.append({'path': path, 'previous_blob': old, 'base_blob': base_blobs[path]})
    assert working_blob == base_blobs[path], path

fixed = [{'item': row['item'], 'commit': row['commit']} for row in previous['already_fixed']]
fixed.append({'item': 'silent-vigor-skewer-J2VR：赤牛活力与串刺两段伤害（J2VR2DFJG8K4 A10 F22第2/3试T1，silent-0504/0505，V5-R387）',
              'commit': 'd959e176af7338ea2bca6f4ff9a39673b80e5fdf'})
for row in fixed:
    for name, head in [('base', base), ('main', main), ('live', live)]:
        row[name + '_ancestor'] = ancestor(row['commit'], head)
assert all(row[name + '_ancestor'] for row in fixed for name in ['base', 'main', 'live'])

for name, ref in [('implementation-since-previous.diff', previous['base'])]:
    (SCRATCH / name).write_bytes(git('diff', '--binary', ref, base, '--', 'agent', 'learner', 'ops', 'knowledge/builders'))
(SCRATCH / 'working-tree.diff').write_bytes(git('diff', '--binary', base))
dirty = git('status', '--porcelain', '--untracked-files=all').decode().splitlines()

# Read only the existing proposal records; do not create duplicate proposals or change their lifecycle.
proposal_ids = {'silent-proposal-72e0c8b41d2f5ab8', 'silent-proposal-59b2e430bb7521d4'}
proposals = []
with (ROOT / 'paper/materials/learning/code-proposals.jsonl').open() as stream:
    for line in stream:
        row = json.loads(line)
        if row.get('id') in proposal_ids:
            proposals.append(row)
(SCRATCH / 'existing-proposals-readback.json').write_text(json.dumps(proposals, ensure_ascii=False, indent=2) + '\n')

source_paths = ['agent/src', 'agent/tools', 'agent/tests', 'agent/package*.json', 'agent/tsconfig*.json',
                'agent/vitest*', 'learner/*.ts', 'learner/*.py', 'learner/lib', 'learner/tasks', 'ops/*.sh',
                'ops/*.py', 'ops/codex', 'eval/*.py', 'eval/*.ts', 'eval/cost-config.json', 'knowledge/builders']
live_source_diff = git('diff', '--name-only', base, live, '--', *source_paths).decode().splitlines()
(SCRATCH / 'preexisting-main-live-source-differences.json').write_text(json.dumps({
    'base': base, 'live': live, 'paths': live_source_diff,
    'note': '这是既有main/live差异，不是本批修改；空修复完成闸要求源码相同，本批未绕过该闸、合并旧差异或伪造测试/merged。',
}, ensure_ascii=False, indent=2) + '\n')

audit = {
    'base': base, 'main': main, 'live': live, 'previous_base': previous['base'],
    'previous_audit': str(PREVIOUS / 'source-audit.json'),
    'queue_sha256': hashlib.sha256(queue).hexdigest(), 'queue_unchanged': queue_unchanged,
    'already_fixed': fixed, 'source_paths_checked': len(source_blobs), 'source_blobs': source_blobs,
    'changed_paths_since_previous': changed, 'dirty_paths': dirty,
    'change_review': '队列未变。新增源码仅原SL沙坑诊断0e4fe4df8及限定赤牛串刺模型d959e176a；两源均已main/live祖先，不重复实现、合入、编号或降级既有shipped账本。',
    'existing_live_source_diff_count': len(live_source_diff),
    'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
}
(SCRATCH / 'source-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({
    'base': base, 'main': main, 'live': live, 'queue_unchanged': queue_unchanged,
    'existing_fix_count': len(fixed), 'all_fixed_commits_base_main_live_ancestors': True,
    'source_paths_checked': len(source_blobs), 'changed_paths': changed,
    'existing_live_source_diff_count': len(live_source_diff), 'working_tree_clean': not dirty,
}, ensure_ascii=False, indent=2))
assert queue_unchanged and not dirty

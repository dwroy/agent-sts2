import hashlib
import json
import subprocess
from pathlib import Path


SCRATCH = Path('/home/dw/Projects/agent-sts2/learner/runs/20261017-194307-085eaaee-c882-4af9-a011-0e331c8b0003-fix-batch')
audit = json.loads((SCRATCH / 'source-audit.json').read_text())
skipped = [
    {'item': '出牌、药水、SL、终局、路线及角色机制条目（含0308/0311/0365/0481/0487/0496）',
     'reason': '策略类；沿已有独立strategy-proposal链处理，不重复派发或补入开发者游戏知识；最新赤牛串刺已由d959e176a修复，另列已修。'},
    {'item': 'silent-0332 实际nonpositive-hp资源契约根因',
     'reason': '证据不足；沿原专用owner链。样本身份修复、限定实验体阶段能力和SL沙坑诊断不等于资源契约根因已修。'},
    {'item': 'sandbox-glob-startup-race目录生命周期与磁盘压力宽项',
     'reason': '证据不足；窄启动恢复、租约保存及回收修复已存在，目录删除归属与上游扫描时序未确定。'},
    {'item': 'arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression及调度公平性调查',
     'reason': '独立架构、策略或归因任务，范围太大，超出本普通纯bug批次。'},
    {'item': 'core-build-notify-222802-rc2旧原生通知恢复',
     'reason': '证据不足；历史stderr及送达证据缺失，不重发可能已经送达的通知。'},
    {'item': 'Codex缓存实测、DPR/B2性能及历史宿主超时根因',
     'reason': '证据不足或独立性能调查；固定测试确定性子项已修，不代表自然性能根因已解决；本批不调用模型或网络。'},
]
result = {'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': skipped,
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
lines = ['## 修 bug 回报', f"- 合并基线：main → {audit['base']}",
         '- 修复（每条一行）：无新增修复。队列与上批快照逐字一致；181个相关源码/测试路径已核，新增差异为已上线的SL沙坑诊断及限定赤牛串刺修复。']
for row in audit['already_fixed']:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['commit']}")
for row in skipped:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines += ['- 测试：tsc未运行（退出码null）；vitest 0文件 / 0用例 / 退出码null。本批未改代码、未提交，无撤修复红绿测试；不借历史检查作为本批测试结果。',
          f"- 合入：未合入（本批无新提交；42项既有修复均核为基线、main及live {audit['live']}的祖先；没有重复合入、编号或更新账本）。",
          '- 需要 Roy 定的事：无']
report = '\n'.join(lines) + '\n\n```json\n' + json.dumps(result, ensure_ascii=False, indent=2) + '\n```\n'
(SCRATCH / 'report.md').write_text(report)
(SCRATCH / 'report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
with (SCRATCH / 'gitleaks.log').open('w') as log:
    scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', '--redact', '--no-banner', str(SCRATCH)], stdout=log, stderr=subprocess.STDOUT)
validation = {
    'queue_snapshot_sha256': audit['queue_sha256'], 'queue_unchanged': audit['queue_unchanged'],
    'existing_fix_count': len(audit['already_fixed']), 'source_path_count': audit['source_paths_checked'],
    'all_fixed_commits_base_main_live_ancestors': all(row[key] for row in audit['already_fixed'] for key in ['base_ancestor', 'main_ancestor', 'live_ancestor']),
    'working_sources_match_base': all(row['blob'] == row['working_blob'] for row in audit['source_blobs'].values()),
    'working_tree_clean': not audit['dirty_paths'], 'no_new_source_commit_or_live_merge': True,
    'empty_fix_completion_gate': {'source_matches_live': audit['existing_live_source_diff_count'] == 0,
                                 'existing_source_diff_count': audit['existing_live_source_diff_count'],
                                 'passing_checks_reported': False,
                                 'note': '既有152路径main/live差异另存清单；未修改完成闸、伪造测试或merged，也未把空修复自称调度done。'},
    'tests': result['tests'], 'report_sha256': hashlib.sha256(report.encode()).hexdigest(),
    'gitleaks_exit_code': scan.returncode,
    'gitleaks_log_sha256': hashlib.sha256((SCRATCH / 'gitleaks.log').read_bytes()).hexdigest(),
}
(SCRATCH / 'validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
assert result['fixes'] == [] and result['merged'] is None
assert report.count('- 已被别人修掉的：') == 42
assert validation['all_fixed_commits_base_main_live_ancestors'] and validation['working_tree_clean']
print(json.dumps({'report': result['report'], 'gitleaks_exit_code': scan.returncode,
                  'existing_fixes': len(audit['already_fixed']), 'source_paths': audit['source_paths_checked']}, ensure_ascii=False))
raise SystemExit(scan.returncode)

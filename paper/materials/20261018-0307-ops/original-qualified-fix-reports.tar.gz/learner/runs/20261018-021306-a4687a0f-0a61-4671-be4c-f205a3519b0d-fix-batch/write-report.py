import json
import re
from pathlib import Path

SCRATCH = Path(__file__).parent
BASE = '9ed8ac27c45992bf48e6526c38bd77c8bbfa8132'
PRIOR = Path('/home/dw/Projects/agent-sts2/learner/runs/20261018-003115-8ad70407-50a9-47b0-8119-46886f8d36c0-fix-batch')
ITEM = 'ops-learner-recheck-report-fixes-shape-20261018：兼容显式源码的描述型fixes并保留拒绝守卫'
TEST = 'agent/tests/learner-report-fixes-shape.test.ts'
CASE = 'rechecks descriptive fixes only with verified sources and unchanged published leaves'
source = (SCRATCH / 'source-commit.txt').read_text().strip()
source_log = 'source-sandbox-retry' if (SCRATCH / 'source-sandbox-retry.exit').exists() else 'source-sandbox'
source_rc = int((SCRATCH / (source_log + '.exit')).read_text())
assert source_rc == 0
assert (SCRATCH / 'without-fix.exit').read_text().strip() == '1'
assert (SCRATCH / 'restored.exit').read_text().strip() == '0'
log = re.sub(r'\x1b\[[0-9;]*m', '', (SCRATCH / (source_log + '.log')).read_text())
files = sum(int(n) for n in re.findall(r'^\s*Test Files\s+(\d+) passed', log, re.M))
cases = sum(int(n) for n in re.findall(r'^\s*Tests\s+(\d+) passed', log, re.M))
assert files > 0 and cases > 0
merged = (SCRATCH / 'live-final.txt').read_text().strip() if (SCRATCH / 'live-final.txt').exists() else None
merge_result = (SCRATCH / 'merge-result.txt').read_text().strip() if (SCRATCH / 'merge-result.txt').exists() else 'live lock unavailable'
if merge_result == 'merge preflight conflicts; stopped before merge; knowledge refresh preserved':
    merge_result = '锁内预检发现历史冲突，合入停止，刷新数据已保留'
conflicts = (SCRATCH / 'live-merge-conflicts.txt').read_text().splitlines() if (SCRATCH / 'live-merge-conflicts.txt').exists() else []
before = (SCRATCH / 'live-before-merge.txt').read_text().strip() if (SCRATCH / 'live-before-merge.txt').exists() else None
skipped = json.loads((PRIOR / 'report.json').read_text())['skipped']
skipped.append({'item': '原20261018-011241报告的recheck接续', 'reason': '证据不足：固定原报告的9ae48941源码不是所报dddad5d67发布提交祖先；六叶相同不代替祖先证明。原报告/状态/recheck2保留，未重复075726已验宿主，格式修复不冒称原批full0。'})
skipped.append({'item': 'ops-learner-recheck-report-fixes-shape-20261018补证：窄cherry-pick提案验收', 'reason': '太大：原Markdown没有机器JSON、原输出缺runs/base；独立原注册/原报告/六叶源码及发布/真实宿主回执协议超出本批格式修复。不造祖先、不改原报告/提案ID/seen_runs/租约或ACK，保留pending。'})
skipped.append({'item': 'infra-h0-414-host-fixed-test-stability-20261018', 'reason': '证据不足；02:54本批启动后追加，原条目明确不热改当前任务输入、下一原空槽接续。固定进程秒数/rollout工作量需独立核验，保留原宿主full1与后续补验范围；本批源端0不冒充该live0。'})
fix = {'item': ITEM, 'commit': source, 'test': TEST, 'fails_without_fix': True}
report = {'task': 'fix-batch', 'base': BASE, 'fixes': [fix], 'skipped': skipped, 'merged': merged,
          'tests': {'tsc': 0, 'vitest': 0, 'files': files, 'cases': cases, 'initial_vitest': 1, 'rerun': ['agent/tests/continuation-failure-b2-planner.test.ts']},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
(SCRATCH / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
audit = json.loads((SCRATCH / 'source-audit.json').read_text())
lines = ['## 修 bug 回报', '', '- 合并基线：main → ' + BASE,
         f'- 修复（每条一行）：{ITEM} — {source} — 测试 {TEST}:{CASE} — 去掉修复时失败：是']
for old in audit['already_fixed']:
    lines.append('- 已被别人修掉的：' + old['item'] + ' — ' + old['commit'])
for row in skipped:
    lines.append('- 没修的：' + row['item'] + ' — ' + row['reason'])
lines.append(f'- 测试：tsc退出码0；Vitest {files}文件 / {cases}用例 / 退出码0；首轮全套1：484文件4429项过、唯一continuation-failure-b2-planner.test.ts原15000ms超时；原用例定向重跑1文件1项退出0（test 2.14秒），随后完整沙箱重跑退出0。原时限/断言/源码均未改。有效撤源码：新用例退出1（Python三项中两项失败）；恢复后4文件19项退出0。首次相对路径错误导致消融无效，已保留并重做；详见verification-notes.md。gitleaks退出0。')
if merged:
    lines.append('- 合入：' + merged + '；合后沙箱退出0，纯工具无行为版本；decision-log已追加。')
else:
    message = '- 合入：未合入；' + merge_result
    if before:
        message += '；刷新数据保留于 ' + before
    if conflicts:
        message += f'；{len(conflicts)}处历史合并冲突，清单见live-merge-conflicts.txt；锁内合并预检停止，未覆盖现场'
    lines.append(message + '；未运行合后测试、未修改版本表或登记源码上线。')
lines.append('- 需要 Roy 定的事：无')
(SCRATCH / 'report.md').write_text('\n'.join(lines) + '\n\n```json\n' + json.dumps(report, ensure_ascii=False, indent=2) + '\n```\n')
print(json.dumps({'fix_commit': source, 'merged': merged, 'tests': report['tests'], 'conflict_count': len(conflicts), 'report': report['report']}, ensure_ascii=False, indent=2))

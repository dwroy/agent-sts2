# 固定验证范围

- 唯一新增普通纯 bug：队列第1436行 ops-learner-recheck-report-fixes-shape-20261018。原输出已按完整 SHA 固定到 original-support-report.out；只读查验，不改原报告或调度状态。
- 本批改动只涉及 ops/learner_checks.py、对应固定 Python 用例及 Vitest 包装，不改游戏规则或任何角色经验。code_proposals 与 implementation_domains 均为空。
- 初次消融在 agent 目录用了相对路径 ops/learner_checks.py，stash 未创建，因此该次绿色测试无效。随后 pop 触到了已有历史 stash；该 stash 因已存在的测试文件而保留。git status 及逐文件 blob 核对确认只有本批三叶净变动，没有提交或丢弃历史 stash。
- 有效消融改用工作树根目录 git diff --binary 保存补丁，git restore 仅恢复源码，测试保留。新 Vitest 用例失败，Python 3项中2项失败；退出1。再 git apply 恢复，4文件19项通过、退出0。
- 对应账本查询关键词 fixes、recheck 的命中均与本缺陷无关；source_commit、20261018-011241 无 bug-infra 命中。不新增账本，不冒填 shipped。
- 真实 Git 额外查验暴露祖先限制：9ae48941 是 main 中的源码提交，live 实际发布 dddad5d67；六叶匹配但源并非 live 或所报发布提交祖先。因此兼容格式后仍明确拒绝这个原报告，不造原批 full0，不重复原宿主。详细退出码见 frozen-report-git-proof.json；初次全祖先断言失败亦保留标记。
- 上述真实报告读回不计作固定单测，不调用 LLM、网络、游戏或原批宿主。原策略、0332、历史性能与目录生命周期宽项沿已有 owner/提案链，不重复派下级。

- 首轮完整沙箱（SANDBOX_WORKERS=1）tsc0，Vitest1：485文件中484过/1失败，4429过/1失败；仅continuation-failure-b2-planner.test.ts原15000ms超时、实际19284ms。原用例未改定向重跑0（1文件1项、test2.14秒），随后按原脚本SANDBOX_WORKERS=2重新完整验证，保留两轮日志，不把定向0称首轮全套0。

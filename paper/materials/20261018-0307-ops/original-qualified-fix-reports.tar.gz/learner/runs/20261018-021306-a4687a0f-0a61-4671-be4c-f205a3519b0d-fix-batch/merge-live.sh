#!/usr/bin/env bash
set -eu
TASK_SCRATCH=/home/dw/Projects/agent-sts2/learner/runs/20261018-021306-a4687a0f-0a61-4671-be4c-f205a3519b0d-fix-batch
TASK_ROOT=/home/dw/Projects/agent-sts2
TASK_LIVE="$TASK_ROOT/.worktrees/live"
TASK_BRANCH=codex-fix-silent-20261018-021301
TASK_BASE=9ed8ac27c45992bf48e6526c38bd77c8bbfa8132
export TMPDIR="$TASK_SCRATCH"
export PATH="$HOME/.local/node/bin:$PATH"
export SANDBOX_WORKERS=1
cd "$TASK_LIVE"
test "$(git branch --show-current)" = live
test -z "$(git ls-files -u)"
if ! git diff --cached --quiet || test -n "$(git status --porcelain --untracked-files=all -- agent/src agent/tests agent/tools knowledge/builders 'ops/*.py' 'ops/*.sh' ops/tests)"; then
  printf '%s\n' 'live source or index dirty; stopped before staging' > "$TASK_SCRATCH/merge-result.txt"
  exit 6
fi
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git rev-parse HEAD > "$TASK_SCRATCH/live-before-refresh.txt"
git status --porcelain > "$TASK_SCRATCH/live-status-before-refresh.txt"
git diff --name-only -- knowledge > "$TASK_SCRATCH/refreshed-knowledge-paths.txt"
git diff --name-only "$TASK_BASE" "$TASK_BRANCH" -- knowledge notes/fight-value-backtest.md > "$TASK_SCRATCH/branch-knowledge-paths.txt"
git add -- knowledge
if test -f notes/fight-value-backtest.md; then git add -- notes/fight-value-backtest.md; fi
if ! git diff --cached --quiet; then
  gitleaks git --pre-commit --staged --no-banner --redact > "$TASK_SCRATCH/gitleaks-refresh.log" 2>&1
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
git rev-parse HEAD > "$TASK_SCRATCH/live-before-merge.txt"
if comm -12 <(sort "$TASK_SCRATCH/refreshed-knowledge-paths.txt") <(sort "$TASK_SCRATCH/branch-knowledge-paths.txt") | rg .; then
  printf '%s\n' 'knowledge overlap; stopped with knowledge refresh preserved' > "$TASK_SCRATCH/merge-result.txt"
  exit 3
fi
set +e
git merge-tree --write-tree --name-only "$TASK_BRANCH" HEAD > "$TASK_SCRATCH/live-preflight-after-refresh.log" 2>&1
TASK_PREFLIGHT_RC=$?
set -e
if test "$TASK_PREFLIGHT_RC" -ne 0; then
  python3 -B - "$TASK_SCRATCH" <<'PROOF'
from pathlib import Path
import sys
scratch = Path(sys.argv[1])
lines = (scratch / 'live-preflight-after-refresh.log').read_text().splitlines()[1:]
paths = []
for line in lines:
    if not line:
        break
    paths.append(line)
(scratch / 'live-merge-conflicts.txt').write_text('\n'.join(paths) + '\n')
PROOF
  printf '%s\n' 'merge preflight conflicts; stopped before merge; knowledge refresh preserved' > "$TASK_SCRATCH/merge-result.txt"
  exit 4
fi
if ! git merge --no-edit "$TASK_BRANCH" -m "Merge branch '$TASK_BRANCH' into live" -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>' > "$TASK_SCRATCH/live-merge.log" 2>&1; then
  git diff --name-only --diff-filter=U > "$TASK_SCRATCH/live-merge-conflicts.txt"
  git status --porcelain > "$TASK_SCRATCH/live-status-merge-failed.txt"
  if git rev-parse -q --verify MERGE_HEAD >/dev/null; then git merge --abort; fi
  printf '%s\n' 'merge failed; knowledge refresh preserved; source not integrated' > "$TASK_SCRATCH/merge-result.txt"
  exit 4
fi
git rev-parse HEAD > "$TASK_SCRATCH/live-source-merged.txt"
set +e
bash agent/tools/test-sandbox.sh > "$TASK_SCRATCH/live-sandbox.log" 2>&1
TASK_CHECK_RC=$?
set -e
printf '%s\n' "$TASK_CHECK_RC" > "$TASK_SCRATCH/live-sandbox.exit"
if test "$TASK_CHECK_RC" -ne 0; then
  git reset --merge "$(cat "$TASK_SCRATCH/live-before-merge.txt")"
  printf '%s\n' 'live checks failed; reverted to saved knowledge refresh' > "$TASK_SCRATCH/merge-result.txt"
  exit 5
fi
TASK_TIME=$(date '+%Y-%m-%d %H:%M:%S %Z')
printf '%s\n' "$TASK_TIME"
TASK_SOURCE=$(cat "$TASK_SCRATCH/source-commit.txt")
printf '\n- %s 静默纯bug学习者：队列ops-learner-recheck-report-fixes-shape-20261018，来源批20261018-011241-strategy-proposal（运维schema缺陷，无对局层/回合及对应bug-infra账本id），源码%s已合live并经合后沙箱0。仅兼容显式source_commit的描述型fixes，保角色/祖先/发布及当前叶字节守卫、原报告与失败，不重复原宿主或改shipped。原报告9ae48941/实际发布dddad5d67祖先差异仍明确拒绝。纯工具不加行为号；证据learner/runs/20261018-021306-a4687a0f-0a61-4671-be4c-f205a3519b0d-fix-batch/。\n' "$TASK_TIME" "$TASK_SOURCE" >> paper/materials/decision-log.md
git add -- paper/materials/decision-log.md
gitleaks git --pre-commit --staged --no-banner --redact > "$TASK_SCRATCH/gitleaks-live-record.log" 2>&1
git commit -m 'Record learner report schema fix deployment' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
git rev-parse HEAD > "$TASK_SCRATCH/live-final.txt"
printf '%s\n' 'merged; post-merge sandbox passed; deployment recorded' > "$TASK_SCRATCH/merge-result.txt"

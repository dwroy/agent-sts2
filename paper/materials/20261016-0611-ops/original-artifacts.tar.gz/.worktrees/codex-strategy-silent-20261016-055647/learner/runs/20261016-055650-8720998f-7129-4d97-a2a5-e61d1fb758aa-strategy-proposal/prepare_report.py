"""生成本批逐项处置、可读报告和既有账本追溯输入。"""
import hashlib
import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
W = S.parents[2]
batch = json.loads((S / 'batch-binding.json').read_text())
originals = json.loads((S / 'assigned-proposals.json').read_text())['origins']
source = json.loads((S / 'source-readback.json').read_text())
items = [
('9952ee8e8df9a0fe', 'NHA2KW0RB7VP F33 第1/6试T1；F24—F33资源链',
 '同初始指纹30血，两线末挡14/8，至T2实损1/7、敌总血净减少8/24；没有击杀。F30窗口40→4、F33首帧28后开场30。',
 '缺同抽序、同预算的整战对照及能力累计兑现，路线/留药后继也未受控；多16净伤与多损6血不能确定新SL或终局HP门槛。',
 '新证据按独立局分组，固定同盘、完整选择和预算，记录即时血价、击杀与后续窗口；未证之前保留SL/路线/终局规则。'),
('47be799a87af03be', 'P74C04AEPL1F F23 第4试T3；states 284816—284821 / decision 278543',
 '1血16挡，石16与卵8来袭；四个合法选项为紧勒、毒雾+、精确切击、贪婪。实际弃精确后末态卵2血、玩家0血。当前生产函数给四份弃后手牌快照。',
 '缺四个合法弃牌分支的动态牌面、目标、弃牌触发及续步生存联合验证；当前快照明确未模拟这些结果，保留精确分支没有实打。',
 '所有合法选项继续可选；独立冻结分支验证手牌变化、精确动态伤害与真实敌方结算；不把原预计零损当执行承诺。'),
('3a5274da3c42672a', 'P74C04AEPL1F F17 T1/T2/T8，F22 T2/T4/T6，F23 T1/T3',
 'F17火焰前后182→181、滑溜8→7；T2尖啸后攻击14→2，T8敌44→21。F22寄生21→0→21，T2损20/T4损24，赢战53→9，F23仍9血空药进入。',
 '主怪最后归零的中间来源仍缺；逐敌结算、复活、连续用药与下战资源缺完整联合消费者回放，未隔离新的确定源码差额。',
 '固定核对一次触发、逐敌来袭和实入口；召唤/退场不能混作卡牌扣血，不推统一先杀或通用留药阈值。'),
('bc4b92d590f2c4ce', 'G33HU22H2543 F48 T1/T8；P74C04AEPL1F F23第4试T3',
 '本批冻结开手有余像+与闪亮登场+；现有turnCanon在投斧作用域区分两首牌，而旧多重集键相同。末轮两层余像与已打牌分账；P74弃牌现场同上。',
 '投斧身份和普通单弃已有live窄实现；仍缺跨重规划完整执行归属、余像累计兑现及动态弃牌分支联合验收，不能整项标duplicate。',
 '沿既有首牌身份与选择中断边界，验证完整实际前缀和当前能力层；不把持有、原计划或药水补层当已经兑现。'),
('f52fbbab4dccc3b4', 'G33HU22H2543 F31/F33/F48；P74C04AEPL1F F22/F23',
 'G33赢下F31仍83→46、F33为76→17，F48首帧81、可操作77；P74 F22赢后9血空药直接F23，未来F24火没有抵达。',
 '已见赢战耗血和实入口，缺逐来源资源消费者账与同条件路线、休息、SL或保药完整后继，不能拟合因果HP价格。',
 '保留实回血、存档恢复、战内消耗的不同来源；在新局同条件完整后继可核后再讨论阈值。'),
('10f37c0edd3d24a6', 'G33HU22H2543 F48 T7/T8；P74C04AEPL1F F17/F22/F23',
 '临时减力、滑溜下火焰与毒、一次翻倍、能力实层都有原帧；当前局部模型和候选审计已经存在。五局运行commit都可定位，dirty清单仅知识/记录，不能笼统称源码提交缺失。',
 '缺当时刷新知识/移动表原字节、未知组合的模型/求解/药水/终局联合回放和独立校准；子机制实帧不能认证完整组合，未隔离新错误。',
 '恢复精确输入后按组件、费用、当前触发与后续未知分别核验；保留未观察组合和其他角色等价。'),
('3f82387e2e179703', 'RC61MFQM63Y6 F33 首/末T1；第3试T4',
 '首末题指纹相同52血；末挡16→12，至T2血48/44、敌总血398/405，即少7净伤、多损4血。末线触媒确实建立1层。普通单弃取消唯一打击已有live实现。',
 '首试题面实际3轮2样本，末次5轮24样本；末次SL的24/24数字属于末次比较，不能回填首试。缺同预算受控整战及能力累计收益，不能改排序/权重。',
 '按原始题面预算分层，先保证弃牌后攻击/朝向可达；独立新局验证前保留现有选择与SL门槛。'),
('aee21084c991abd3', 'BTSRF7JL1W1Y F31 T1—T4；decisions 279852/279854',
 'T3/T4醒虫力量2/4、覆甲2/1；末动作后14血5牌挡、覆甲1，醒虫22攻击，最终0血而敌13。抽弃前3轮4样本题与重算后5轮4样本题不同，实际没有建立步法敏捷。',
 '缺逐样本抽序、动作和实际最终线的配对及独立校准；3/4预测的一次实死不足调权、强制集火或证明模型错误。',
 '只验证最终实际线的成长、临时弱与挡，先定位可复现数值差额；无差额不改概率权重。'),
('df37594e9b12debf', 'RC61MFQM63Y6 F17 T11；F33第3试T4与首/末T1',
 '原提案关联普通生存者唯一后继取消已由bf423c17源码覆盖；当前选择候选/动作接口/实际整轮分开记录。首末T1即时血价见3f项，不能跨轮归单因。',
 '普通单弃已有live窄实现；缺跨选择的完整执行归属、累计能力和呼唤自损的联合消费者验收，单动作回执不证明整条候选执行。',
 '固定核持牌自损先于毒终结及弃牌后的合法后继；不把未执行朝向和长期成长预支为生存收益。'),
('42e81c83b2e1e56b', 'RC61MFQM63Y6 F23/F29；F33六试入口52；原资源提案F24/F27/F32',
 '资源窗口复核F23为44→20、F29为62→31，各次F33均52血；真实休息、赢战耗血与读档恢复须分开。原113局总体统计本批未重建。',
 '缺逐来源资源消费者账及同条件改路线、休息或保药后的整战对照；52血入口和已兑现回复不能确定新的路线/终局HP价格。',
 '按实入口检验已完成回复，不预支未来营火，保留现有路线与终局规则；新的因果血价须有独立后继证据。'),
]
details = []
for short, evidence, observed, reason, validation in items:
    pid = 'silent-proposal-' + short
    assert pid in originals
    details.append({'id': pid, 'state': 'waiting', 'reason': reason, 'evidence': evidence,
                    'observed': observed, 'validation': validation, 'ledger': originals[pid]['ledger']})
assert {d['id'] for d in details} == set(batch['proposal_ids'])
(S / 'dispositions.json').write_text(json.dumps(details, ensure_ascii=False, indent=2) + '\n')
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-055647-strategy-proposal',
         'base': source['base'], 'runs': batch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': batch['proposal_ids'],
         'implementation_domains': [],
         'proposal_results': [{k: d[k] for k in ['id', 'state', 'reason']} for d in details],
         'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
date = subprocess.check_output(['date'], text=True).strip()
(S / 'report-date.txt').write_text(date + '\n')
verification = json.loads((S / 'evidence-verification.json').read_text())
receipts = json.loads((S / 'consumer-receipts.json').read_text())
checks = json.loads((S / 'material-checks.json').read_text())
count_table = '\n'.join('| ' + x['stream'] + ' | ' + ' | '.join(str(x['counts'][run]) for run in batch['runs']) +
    ' | ' + str(x['source_size']) + ' |' for x in verification)
proposal_sections = '\n\n'.join(
    '## ' + d['id'] + '：waiting\n\n' + originals[d['id']]['summary'] + '\n\n'
    '证据：' + d['evidence'] + '。账本：' + '、'.join(d['ledger']) + '。\n\n'
    '本批核对：' + d['observed'] + '\n\n缺口及反例：' + d['reason'] + '\n\n'
    '预期行为及验证：' + d['validation'] + '\n\n'
    '原提案保存为 `' + d['id'] + '.original.md`，原Markdown SHA256与专用队列add记录一致；未覆盖原文。'
    for d in details)
proposal = '# 静默猎手十项已领取策略提案的本批核证\n\n'
proposal += '时间：' + date + '。批次：20261016-055647-strategy-proposal。\n\n'
proposal += ('只处理batch-binding.json中的十个原CLI id；无新提案、无参数拟合、无源码或知识修改。'
             '所有处置保留waiting；局部已有实现不代表宽提案全部实现，缺完整反事实也不否定已证机制。'
             '授权沿Roy-2026-10-07-learning，来源为各原提案，当前实现任务strategy-proposal。\n\n')
proposal += proposal_sections
proposal += ('\n\n## 共同方法、限制与回退\n\n只从本批五局静默A10原始记录及原提案学习。'
             '每次SL按原局分组，不能作为独立训练/留出局。原提案的110/112/113局统计、其他局反例与历史模型结果本批未重建，'
             '不将转述当本批新核实。没有可验证的新参数或独立整战收益，所以生产行为保持现状。'
             '未来若有确定源码差额，按该项独立提交、源码撤下失败/恢复通过、沙箱自测和live流程交付；'
             '本批无新源码，撤源码对照、tsc/vitest、合入和版本均不适用。无需回退生产；全部原件、初探错误与未知保留。\n')
(S / 'proposal.md').write_text(proposal)
report = '# 本批策略提案回报\n\n'
report += ('十项均为waiting。本批没有源码改动、提交、live合入、行为版本或新增规则；未定位新的确定源码差额。\n\n'
           '时间：' + date + '。base：`' + source['base'] + '`。独立执行，没有下级agent、联网、游戏运行或其他角色知识读取。\n\n'
           '## 身份及范围\n\n初始git status干净，git merge --no-edit main返回Already up to date。'
           '本批learn.json对应task=strategy-proposal、character=silent、reason=proposal，工作树一致，且有十个proposal_ids；'
           '没有research_request、implementation_request或proposal_repair。普通研究请求文件绑定其他旧batch，故未读取它的work_spec/manifest，'
           '未将本批转成专题。十份原提案SHA全部吻合。\n\n'
           '## 冻结证据与材料校验\n\n五局runs记录均SILENT/A10且已结束；八流共' + str(sum(x['verified_rows'] for x in verification)) +
           '条所属行。共用extract_evidence.py保存每流source_size、逐行offset/bytes/SHA和计数；'
           '本批对所有选中行另seek回只读原日志，逐条核原字节SHA、JSON及显式身份。'
           '此校验不代表完整语义审计。原流states/decisions各有2条、brain有1条无效JSON，均记源流诊断；'
           '不推断为本五局缺帧。fight-plans在本次截点选中0行，仅表示该截点无匹配，不断言原日志缺失。\n\n'
           '| 流 | NHA2 | P74 | G33 | RC61 | BTS | 冻结字节截点 |\n|---|---:|---:|---:|---:|---:|---:|\n' + count_table +
           '\n\n固定材料断言' + str(checks['count']) + '项通过，原件见material-checks.json；'
           'mechanism-facts.json另保留P74 F17/F22及G33末轮机制帧。不是生产测试或新规则收益验证。\n\n'
           '## 实际消费者与源码读回\n\n现有audit-selection离线入口只接七个声明的层：NHA33、P74的17/22/23、G33的48、RC33、BTS31。'
           '七次返回0，输入/输出/stderr的SHA和范围见consumer-receipts.json；输入只去decisions.agent_view并加真实原行号/SHA，'
           '保留states字段；本七窗没有无decision_id元数据。不得把这七层当五整局完整执行认证。'
           '共170题段、735动作、642相邻观测端点、2终态端点、140轮窗（86可核/54未知）；'
           '全部actual_full_candidate_result/actual_rollout_best仍null。P74 F22与BTS31没有可认证轮窗，主要是旧尝试身份不足，不能把unknown补0。\n\n'
           'read_current_helpers.mjs用P74原states284817直接读取既有生产函数的四个弃牌快照；'
           '使用原278542及284816确认来源为生存者。它不推演动态弃牌后果、续牌或生存结果。'
           'G33原states284162读回投斧首牌作用域：AFTERIMAGE+/DRAMATIC_ENTRANCE+两种顺序旧多重集键相同、现有首牌键不同。'
           '原源码e784dd9f043bf87c29109573f48975f9903280d3与bf423c173d3be348a4ad714e1d26516df619ff41均为base/live祖先；'
           '这是既有子项，不是本批提交，不足关闭整个bc4/df等宽提案。\n\n'
           '只读live HEAD为`' + source['live_head_readonly'] + '`；17相关源码/工具叶15同2异，'
           '差异是card-model.ts与sl/explore.ts的历史Roy/Dai注释，原二进制diff保留，未改动或声称逐叶全等。'
           '五局run-config均有完整源码commit且dirty清单只有知识/记录；精确脏知识、移动表和运行中刷新输入未恢复。'
           '因此缺口是历史完整运行输入及联合校准，不能笼统说源码commit不可定位。\n\n'
           '资源链使用同一批冻结行调用现有resource_chain，保存五局窗口及缺退出原因；原赢战仍保留。'
           '净HP不是毛伤，召唤/退场/重复类型不是稳定实例，读档恢复不算回血/新获药，终局截顶实扣不等于完整入伤。\n\n'
           '## 旧原件与本批限制\n\nRC61原提案“首末五轮24样本”不能作两个题面的共同预算：'
           'decision279021实为3轮2样本，279197为5轮24样本，末次SL记录的24/24属于末次比较。'
           '这与队列最近waiting理由一致；本批不覆盖旧提案、不重复新增机制或通知。BTS抽弃前3轮4样本与重算后5轮4样本也分开。'
           'NHA多16净伤/多损6血、RC少7净伤/多损4血均只限已观察局部窗口，不证明少铺能力普遍更好或原替线必错。\n\n'
           '## 逐项处置\n\n详见proposal.md及dispositions.json，每项均给原账本、证据局/层/回合、反例、缺口与验证方法。\n\n')
report += '\n'.join('- `' + d['id'] + '`：waiting。' + d['reason'] for d in details)
report += ('\n\n## 记录、测试及交付边界\n\n原账本只通过根目录ledger.py update追加本批where/note链接，'
           '不新增重复证据、不改claim/first_run/prior/status/version，不把已有shipped降级为proposed；'
           '具体CLI回执及前后字段保持校验见ledger-update-receipt.json与final-validation.json。'
           '现有十个code_proposals id保留，未新建id或改队列；调度器按最终proposal_results消费。'
           '没有源代码修改，源码撤除失败/恢复通过不适用，tsc/vitest/cases均null；七次离线消费者和28项材料断言另记，不能填成生产测试成功。'
           '无提交，merged=null、版本无、不登记shipped；没有merge阻塞或需要运维兜底的源码。\n\n'
           '首次角色小写精确比较因日志为SILENT而拒绝，已仅归一化标识后复核；最初宽输出截断和猜测路径的只读探针失败保留在会话/initial-probes，'
           '不是游戏机制或产品bug。没有运行模型配置更改，历史局high记录不改写；本报告不以历史run-config冒称当前学习者原生请求证明。\n\n'
           '运维入口：`' + str(S / 'proposal.md') + '`；最终机器回报为result.json。'
           '父学习要求、经验入库与后续消费者采用仍开放，不因报告完成关闭。\n')
(S / 'report.md').write_text(report)

ledger_ids = sorted({i for d in details for i in d['ledger']})
updates = []
for ledger_id in ledger_ids:
    related = [d['id'] for d in details if ledger_id in d['ledger']]
    updates.append({'id': ledger_id, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
        'note': '20261016-055647-strategy-proposal：本批五局Silent A10冻结证据与现有消费者核对，所属原提案' +
        '、'.join(related) + '仍waiting；逐项范围/缺口见本批report.md。无新源码/参数/合入；仅追加追溯，保留旧claim、首证、prior、证据、status与version，不重复支持或登记shipped。'})
(S / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(d, ensure_ascii=False) + '\n' for d in updates))
print(json.dumps({'report': str(S / 'report.md'), 'proposal': str(S / 'proposal.md'),
                  'proposal_results': len(details), 'ledger_updates_prepared': len(updates)}, ensure_ascii=False))

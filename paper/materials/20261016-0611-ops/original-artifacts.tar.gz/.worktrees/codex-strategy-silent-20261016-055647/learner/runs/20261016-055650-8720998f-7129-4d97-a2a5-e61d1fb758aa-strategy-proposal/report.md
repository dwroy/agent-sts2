# 本批策略提案回报

十项均为waiting。本批没有源码改动、提交、live合入、行为版本或新增规则；未定位新的确定源码差额。

时间：Fri Oct 16 06:07:00 CST 2026。base：`c6478b123f45de0fc325a732460f3f72a692d8f0`。独立执行，没有下级agent、联网、游戏运行或其他角色知识读取。

## 身份及范围

初始git status干净，git merge --no-edit main返回Already up to date。本批learn.json对应task=strategy-proposal、character=silent、reason=proposal，工作树一致，且有十个proposal_ids；没有research_request、implementation_request或proposal_repair。普通研究请求文件绑定其他旧batch，故未读取它的work_spec/manifest，未将本批转成专题。十份原提案SHA全部吻合。

## 冻结证据与材料校验

五局runs记录均SILENT/A10且已结束；八流共6606条所属行。共用extract_evidence.py保存每流source_size、逐行offset/bytes/SHA和计数；本批对所有选中行另seek回只读原日志，逐条核原字节SHA、JSON及显式身份。此校验不代表完整语义审计。原流states/decisions各有2条、brain有1条无效JSON，均记源流诊断；不推断为本五局缺帧。fight-plans在本次截点选中0行，仅表示该截点无匹配，不断言原日志缺失。

| 流 | NHA2 | P74 | G33 | RC61 | BTS | 冻结字节截点 |
|---|---:|---:|---:|---:|---:|---:|
| states | 602 | 410 | 879 | 694 | 653 | 13341785782 |
| decisions | 584 | 395 | 850 | 674 | 635 | 1796438538 |
| sl-attempts | 7 | 5 | 8 | 7 | 4 | 42327424 |
| run-config | 1 | 1 | 1 | 1 | 1 | 1829166 |
| run-plans | 5 | 3 | 6 | 7 | 5 | 8371189 |
| brain | 34 | 23 | 45 | 33 | 28 | 637543666 |
| runs | 1 | 1 | 1 | 1 | 1 | 343717 |
| fight-plans | 0 | 0 | 0 | 0 | 0 | 2233957 |

固定材料断言28项通过，原件见material-checks.json；mechanism-facts.json另保留P74 F17/F22及G33末轮机制帧。不是生产测试或新规则收益验证。

## 实际消费者与源码读回

现有audit-selection离线入口只接七个声明的层：NHA33、P74的17/22/23、G33的48、RC33、BTS31。七次返回0，输入/输出/stderr的SHA和范围见consumer-receipts.json；输入只去decisions.agent_view并加真实原行号/SHA，保留states字段；本七窗没有无decision_id元数据。不得把这七层当五整局完整执行认证。共170题段、735动作、642相邻观测端点、2终态端点、140轮窗（86可核/54未知）；全部actual_full_candidate_result/actual_rollout_best仍null。P74 F22与BTS31没有可认证轮窗，主要是旧尝试身份不足，不能把unknown补0。

read_current_helpers.mjs用P74原states284817直接读取既有生产函数的四个弃牌快照；使用原278542及284816确认来源为生存者。它不推演动态弃牌后果、续牌或生存结果。G33原states284162读回投斧首牌作用域：AFTERIMAGE+/DRAMATIC_ENTRANCE+两种顺序旧多重集键相同、现有首牌键不同。原源码e784dd9f043bf87c29109573f48975f9903280d3与bf423c173d3be348a4ad714e1d26516df619ff41均为base/live祖先；这是既有子项，不是本批提交，不足关闭整个bc4/df等宽提案。

只读live HEAD为`e716bd28fd8eca9e4d76d066680304fd11935e37`；17相关源码/工具叶15同2异，差异是card-model.ts与sl/explore.ts的历史Roy/Dai注释，原二进制diff保留，未改动或声称逐叶全等。五局run-config均有完整源码commit且dirty清单只有知识/记录；精确脏知识、移动表和运行中刷新输入未恢复。因此缺口是历史完整运行输入及联合校准，不能笼统说源码commit不可定位。

资源链使用同一批冻结行调用现有resource_chain，保存五局窗口及缺退出原因；原赢战仍保留。净HP不是毛伤，召唤/退场/重复类型不是稳定实例，读档恢复不算回血/新获药，终局截顶实扣不等于完整入伤。

## 旧原件与本批限制

RC61原提案“首末五轮24样本”不能作两个题面的共同预算：decision279021实为3轮2样本，279197为5轮24样本，末次SL记录的24/24属于末次比较。这与队列最近waiting理由一致；本批不覆盖旧提案、不重复新增机制或通知。BTS抽弃前3轮4样本与重算后5轮4样本也分开。NHA多16净伤/多损6血、RC少7净伤/多损4血均只限已观察局部窗口，不证明少铺能力普遍更好或原替线必错。

## 逐项处置

详见proposal.md及dispositions.json，每项均给原账本、证据局/层/回合、反例、缺口与验证方法。

- `silent-proposal-9952ee8e8df9a0fe`：waiting。缺同抽序、同预算的整战对照及能力累计兑现，路线/留药后继也未受控；多16净伤与多损6血不能确定新SL或终局HP门槛。
- `silent-proposal-47be799a87af03be`：waiting。缺四个合法弃牌分支的动态牌面、目标、弃牌触发及续步生存联合验证；当前快照明确未模拟这些结果，保留精确分支没有实打。
- `silent-proposal-3a5274da3c42672a`：waiting。主怪最后归零的中间来源仍缺；逐敌结算、复活、连续用药与下战资源缺完整联合消费者回放，未隔离新的确定源码差额。
- `silent-proposal-bc4b92d590f2c4ce`：waiting。投斧身份和普通单弃已有live窄实现；仍缺跨重规划完整执行归属、余像累计兑现及动态弃牌分支联合验收，不能整项标duplicate。
- `silent-proposal-f52fbbab4dccc3b4`：waiting。已见赢战耗血和实入口，缺逐来源资源消费者账与同条件路线、休息、SL或保药完整后继，不能拟合因果HP价格。
- `silent-proposal-10f37c0edd3d24a6`：waiting。缺当时刷新知识/移动表原字节、未知组合的模型/求解/药水/终局联合回放和独立校准；子机制实帧不能认证完整组合，未隔离新错误。
- `silent-proposal-3f82387e2e179703`：waiting。首试题面实际3轮2样本，末次5轮24样本；末次SL的24/24数字属于末次比较，不能回填首试。缺同预算受控整战及能力累计收益，不能改排序/权重。
- `silent-proposal-aee21084c991abd3`：waiting。缺逐样本抽序、动作和实际最终线的配对及独立校准；3/4预测的一次实死不足调权、强制集火或证明模型错误。
- `silent-proposal-df37594e9b12debf`：waiting。普通单弃已有live窄实现；缺跨选择的完整执行归属、累计能力和呼唤自损的联合消费者验收，单动作回执不证明整条候选执行。
- `silent-proposal-42e81c83b2e1e56b`：waiting。缺逐来源资源消费者账及同条件改路线、休息或保药后的整战对照；52血入口和已兑现回复不能确定新的路线/终局HP价格。

## 记录、测试及交付边界

原账本只通过根目录ledger.py update追加本批where/note链接，不新增重复证据、不改claim/first_run/prior/status/version，不把已有shipped降级为proposed；具体CLI回执及前后字段保持校验见ledger-update-receipt.json与final-validation.json。现有十个code_proposals id保留，未新建id或改队列；调度器按最终proposal_results消费。没有源代码修改，源码撤除失败/恢复通过不适用，tsc/vitest/cases均null；七次离线消费者和28项材料断言另记，不能填成生产测试成功。无提交，merged=null、版本无、不登记shipped；没有merge阻塞或需要运维兜底的源码。

首次角色小写精确比较因日志为SILENT而拒绝，已仅归一化标识后复核；最初宽输出截断和猜测路径的只读探针失败保留在会话/initial-probes，不是游戏机制或产品bug。没有运行模型配置更改，历史局high记录不改写；本报告不以历史run-config冒称当前学习者原生请求证明。

运维入口：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-055647/learner/runs/20261016-055650-8720998f-7129-4d97-a2a5-e61d1fb758aa-strategy-proposal/proposal.md`；最终机器回报为result.json。父学习要求、经验入库与后续消费者采用仍开放，不因报告完成关闭。

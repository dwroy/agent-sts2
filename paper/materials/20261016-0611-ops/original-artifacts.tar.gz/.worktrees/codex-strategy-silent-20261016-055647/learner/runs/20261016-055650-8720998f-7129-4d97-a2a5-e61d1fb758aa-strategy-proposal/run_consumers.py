"""用已经冻结的本角色输入，顺序运行现有离线审计入口。"""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
requests = json.loads((SCRATCH / 'consumer-input-manifest.json').read_text())
receipts = []
for request in requests:
    name = request['name']
    inp = SCRATCH / (name + '.audit-input.json')
    out = SCRATCH / (name + '.audit-output.json')
    err = SCRATCH / (name + '.audit-stderr.txt')
    with out.open('wb') as stdout, err.open('wb') as stderr:
        result = subprocess.run(['nice', '-n', '19', 'node', '--import',
            './agent/node_modules/tsx/dist/loader.mjs', 'learner/audit-selection.ts', str(inp)],
            cwd=WORKTREE, stdout=stdout, stderr=stderr)
    receipt = {**request, 'exit_code': result.returncode, 'input_sha256': sha(inp),
               'output_sha256': sha(out), 'stderr_sha256': sha(err)}
    if result.returncode == 0:
        data = json.loads(out.read_text())
        actions = data['observed_actions']
        turns = data['observed_turns']
        receipt['audit'] = {'segments': len(data['segments']), 'actions': len(actions),
            'observed_intervals': sum(a['observed_interval']['status'] == 'observed_endpoints' for a in actions),
            'terminal_observations': sum((a.get('terminal_observation') or {}).get('status') == 'observed_terminal_endpoints' for a in actions),
            'turns': len(turns), 'observed_turns': sum(t['status'] == 'observed_turn_endpoints' for t in turns),
            'unknown_turns': sum(t['status'] != 'observed_turn_endpoints' for t in turns),
            'whole_candidate_verified': 0}
        assert all(segment['actual_full_candidate_result'] is None and segment['actual_rollout_best'] is None
                   for segment in data['segments'])
        assert all(turn['facts'] is None or (turn['facts']['actual_full_candidate_result'] is None and
                   turn['facts']['actual_uncapped_hp_loss'] is None) for turn in turns)
    receipts.append(receipt)
(SCRATCH / 'consumer-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('batch_resources', WORKTREE / 'learner/resource_chain.py')
resource = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resource)
all_states = [json.loads(line) for line in (SCRATCH / 'evidence/states.evidence.jsonl').open()]
sl = [json.loads(line) for line in (SCRATCH / 'evidence/sl-attempts.evidence.jsonl').open()]
resource_summary = []
for run in json.loads((SCRATCH / 'batch-binding.json').read_text())['runs']:
    entries = [{**item['row'], '_line': item['line']} for item in all_states if item['run_id'] == run]
    starts = {}
    for item in sl:
        row = item['row']
        if item['run_id'] == run and row.get('attempt', 1) > 1 and row.get('started_at'):
            starts.setdefault(row['floor'], []).append(row['started_at'])
    data = resource.resource_chain(entries, run, 'silent', starts)
    (SCRATCH / (run + '.resource-chain.json')).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    resource_summary.append({'run_id': run, 'combat_windows': len(data['combats']),
        'missing_exits': sum(w['exit'] is None for w in data['combats']),
        'windows': [{key: w.get(key) for key in ['sequence', 'floor', 'entry', 'exit', 'end', 'observed_net_hp_loss']}
                    for w in data['combats']]})
(SCRATCH / 'resource-summary.json').write_text(json.dumps(resource_summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'consumer_runs': len(receipts), 'exit_codes': [r['exit_code'] for r in receipts],
    'resources': [{k: v for k, v in row.items() if k != 'windows'} for row in resource_summary]}, ensure_ascii=False))

import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { survivorDiscardFacts } from '../../../agent/src/hand/screens/silent-discard-facts.ts';
import { parseGameState } from '../../../agent/src/hand/mod/schema.ts';
import { firstCardReplayScope, turnCanon } from '../../../agent/src/sl/explore.ts';

const input = (name) => JSON.parse(readFileSync(new URL(name, import.meta.url), 'utf8'));
const discard = input('P74C04AEPL1F-F23.audit-input.json');
const original = discard.states.find((frame) => frame._line === 284817);
const before = discard.states.find((frame) => frame._line === 284816);
const cause = discard.decisions.find((row) => row._line === 278542);
assert.equal(before.state.combat.hand.find((card) => card.index === cause.chosen.card_index).card_id, 'SURVIVOR');
const facts = survivorDiscardFacts(parseGameState(original.state), true);
assert.deepEqual([...facts.keys()], [0, 1, 2, 3]);
assert.equal(facts.get(2).retained_cards.some((card) => card.card_id === 'PRECISE_CUT'), false);
assert.equal(facts.get(3).retained_cards.some((card) => card.card_id === 'PRECISE_CUT'), true);
assert.equal(survivorDiscardFacts(parseGameState(original.state), false), null);

const axe = input('G33HU22H2543-F48.audit-input.json');
const opening = axe.states.find((frame) => frame.state.screen === 'COMBAT' && frame.state.turn === 1 &&
  frame.state.combat.player.energy > 0 && frame.state.combat.player.cards_played_this_turn === 0);
assert.equal(firstCardReplayScope(parseGameState(opening.state)), true);
const hand = opening.state.combat.hand;
const after = hand.find((card) => card.card_id === 'AFTERIMAGE');
const bright = hand.find((card) => card.name.includes('闪亮登场'));
assert.ok(after && bright);
const key = (card) => `${card.card_id}${card.upgraded ? '+' : ''}`;
const a = [key(after), key(bright)], b = [...a].reverse();
assert.equal(turnCanon(a), turnCanon(b));
assert.notEqual(turnCanon(a, true), turnCanon(b, true));

writeFileSync(new URL('current-helper-readback.json', import.meta.url), JSON.stringify({
  scope: '既有生产函数的冻结材料读回；没有新增实现或完整候选认证',
  discard_source_line: 284817,
  survivor_source_decision_line: 278542,
  discarded_option_snapshots: [...facts].map(([index, value]) => ({ index, value })),
  axe_source_line: opening._line,
  axe_original_order: a, axe_reverse_order: b,
  legacy_multiset_keys_equal: turnCanon(a) === turnCanon(b),
  scoped_first_card_keys_distinct: turnCanon(a, true) !== turnCanon(b, true),
  full_discard_branch_outcomes: null, full_candidate_execution: null,
}, null, 2) + '\n');

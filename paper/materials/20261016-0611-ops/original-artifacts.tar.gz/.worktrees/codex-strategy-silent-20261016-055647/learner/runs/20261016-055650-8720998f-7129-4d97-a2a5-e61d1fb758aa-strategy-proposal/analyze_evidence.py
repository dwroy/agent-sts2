"""本批冻结证据的原字节复核、局部事实投影和有界消费者输入。"""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

WORKTREE = Path(__file__).resolve().parents[3]
SCRATCH = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_evidence', WORKTREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
bound = json.loads((SCRATCH / 'batch-binding.json').read_text())
runs = bound['runs']
streams = {}
verification = []
for entry in manifest:
    path = SCRATCH / 'evidence' / (entry['stream'] + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
    rows = [json.loads(line) for line in path.open()]
    counts = collections.Counter()
    with Path('/home/dw/Projects/agent-sts2/logs', entry['stream'] + '.jsonl').open('rb') as source:
        for item in rows:
            assert item['run_id'] in runs
            assert item['offset'] + item['bytes'] <= entry['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extractor.run_identity(item['row']) == item['run_id']
            if entry['stream'] == 'states':
                info = item['row']['state']['run']
                assert info['character_id'].lower() == 'silent' and info['ascension'] == 10
            counts[item['run_id']] += 1
    assert {run: counts[run] for run in runs} == entry['counts']
    streams[entry['stream']] = rows
    verification.append({'stream': entry['stream'], 'verified_rows': len(rows),
                         'source_size': entry['source_size'], 'output_sha256': entry['output_sha256'],
                         'offset_bytes_sha_json_identity': True, 'counts': entry['counts'],
                         'source_invalid_lines': entry['invalid_lines'],
                         'source_incomplete_lines': entry['incomplete_lines']})

def save(name, data):
    (SCRATCH / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

save('evidence-verification.json', verification)
states = {item['line']: item for item in streams['states']}
decisions = {item['line']: item for item in streams['decisions']}

def snap(line):
    item = states[line]
    raw = item['row']['state']
    combat = raw.get('combat') or {}
    player = combat.get('player') or {}
    selection = raw.get('selection') or {}
    def cards(pool):
        return [{key: card.get(key) for key in ['index', 'card_id', 'upgraded', 'energy_cost',
                                               'resolved_rules_text', 'dynamic_values']}
                for card in pool]
    return {'run_id': item['run_id'], 'source_line': line, 'source_sha256': item['sha256'],
            'floor': raw['run']['floor'], 'turn': raw.get('turn'), 'screen': raw['screen'],
            'fingerprint': item['row'].get('fingerprint'),
            'hp': player.get('current_hp', raw['run'].get('current_hp')), 'block': player.get('block'),
            'energy': player.get('energy'), 'player_powers': player.get('powers'),
            'potions': raw['run'].get('potions'), 'hand': cards(combat.get('hand') or []),
            'selection': cards(selection.get('cards') or []),
            'enemies': [{key: enemy.get(key) for key in ['index', 'enemy_id', 'current_hp', 'max_hp',
                         'block', 'is_alive', 'powers', 'intents']} for enemy in combat.get('enemies') or []]}

def enemy_hp(line):
    return sum(e['current_hp'] for e in snap(line)['enemies'] if e['is_alive'])

def player_power(line, power):
    return next((p['amount'] for p in snap(line)['player_powers'] if p['power_id'] == power), None)

def enemy_power(line, enemy_id, power):
    return next((p['amount'] for e in snap(line)['enemies'] if e['enemy_id'] == enemy_id
                 for p in e['powers'] if p['power_id'] == power), None)

checks = []
def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})

check('NHA首试T1至T2净损', snap(283391)['hp'] - snap(283397)['hp'], 1)
check('NHA第六试T1至T2净损', snap(283502)['hp'] - snap(283507)['hp'], 7)
check('NHA首试T1至T2敌总血净减少', enemy_hp(283391) - enemy_hp(283397), 8)
check('NHA第六试T1至T2敌总血净减少', enemy_hp(283502) - enemy_hp(283507), 24)
check('NHA两线动作前指纹相同', snap(283391)['fingerprint'] == snap(283502)['fingerprint'], True)
check('NHA首线末挡', snap(283396)['block'], 14)
check('NHA替线末挡', snap(283506)['block'], 8)
check('RC首末题指纹相同', decisions[279021]['row']['fingerprint'] == decisions[279197]['row']['fingerprint'], True)
check('RC首线末挡', snap(285320)['block'], 16)
check('RC末线末挡', snap(285496)['block'], 12)
check('RC首线T2血', snap(285321)['hp'], 48)
check('RC末线T2血', snap(285497)['hp'], 44)
check('RC首线T2敌总血', enemy_hp(285321), 398)
check('RC末线T2敌总血', enemy_hp(285497), 405)
check('RC末线实际建普通触媒', player_power(285495, 'ACCELERANT_POWER'), 1)
check('P74末试单弃前实血和挡', [snap(284817)['hp'], snap(284817)['block']], [1, 16])
check('P74合法单弃候选四张', [c['card_id'] for c in snap(284817)['selection']],
      ['STRANGLE', 'NOXIOUS_FUMES', 'PRECISE_CUT', 'GREED'])
check('P74实弃精确切击', decisions[278543]['row']['chosen'], {'action': 'select_deck_card', 'option_index': 2})
check('P74终局剩血', snap(284821)['hp'], 0)
check('P74终局卵仍2血', next(e['current_hp'] for e in snap(284821)['enemies'] if e['enemy_id'] == 'BOWLBUG_EGG'), 2)
check('BTS第三轮醒虫力量', enemy_power(286163, 'SLUMBERING_BEETLE', 'STRENGTH_POWER'), 2)
check('BTS第四轮醒虫力量', enemy_power(286170, 'SLUMBERING_BEETLE', 'STRENGTH_POWER'), 4)
check('BTS第三轮覆甲', player_power(286163, 'PLATING_POWER'), 2)
check('BTS第四轮覆甲', player_power(286170, 'PLATING_POWER'), 1)
check('BTS未施放步法不造敏捷', player_power(286173, 'DEXTERITY_POWER'), None)
check('BTS末动作后HP和牌挡', [snap(286173)['hp'], snap(286173)['block']], [14, 5])
check('BTS终局净扣截顶', snap(286173)['hp'] - snap(286174)['hp'], 14)
check('BTS终局剩醒虫血', next(e['current_hp'] for e in snap(286174)['enemies']), 13)

selected_lines = set(range(283390, 283398)) | set(range(283478, 283484)) | set(range(283502, 283508))
selected_lines |= set(range(285314, 285322)) | set(range(285491, 285498))
selected_lines |= set(range(284816, 284822)) | set(range(286148, 286175))
selected_lines |= {item['line'] for item in streams['states'] if item['run_id'] == 'G33HU22H2543'
                   and item['row']['state']['run']['floor'] == 48}
save('focused-facts.json', [snap(line) for line in sorted(selected_lines) if line in states])
save('material-checks.json', {'checks': checks, 'count': len(checks),
     'scope': '仅冻结材料断言；不是生产tsc/vitest，不认证整候选、完整入伤或新策略收益。'})

source_identity = []
for item in streams['run-config']:
    code = item['row']['code']
    source_identity.append({'run_id': item['run_id'], 'source_line': item['line'],
                            'source_sha256': item['sha256'], 'code': code,
                            'limits': '提交可定位；脏知识/移动表原字节及运行中刷新输入未由提交恢复。'})
save('run-source-identities.json', source_identity)

# 全部原行保留在evidence；消费者只取七个已声明的层，不重编号源行。
scopes = [('NHA2KW0RB7VP', 33), ('P74C04AEPL1F', 17), ('P74C04AEPL1F', 22),
          ('P74C04AEPL1F', 23), ('G33HU22H2543', 48), ('RC61MFQM63Y6', 33), ('BTSRF7JL1W1Y', 31)]
run_info = {item['run_id']: item['row'] for item in streams['runs']}
requests = []
for run, floor in scopes:
    ds, ss, excluded = [], [], []
    for item in streams['decisions']:
        if item['run_id'] != run or item['row'].get('floor') != floor:
            continue
        row = item['row'].copy()
        if not row.get('decision_id'):
            excluded.append({'line': item['line'], 'sha256': item['sha256'],
                             'reason': '原行无decision_id；元数据单列，不补号或拼接连续性'})
            continue
        row.pop('agent_view', None)
        row.update(_line=item['line'], _source_sha256=item['sha256'])
        ds.append(row)
    for item in streams['states']:
        if item['run_id'] == run and item['row']['state']['run']['floor'] == floor:
            ss.append({**item['row'], '_line': item['line'], '_source_sha256': item['sha256']})
    name = run + '-F' + str(floor)
    save(name + '.audit-input.json', {'run': run_info[run], 'decisions': ds, 'states': ss})
    requests.append({'name': name, 'run_id': run, 'floor': floor, 'decisions': len(ds),
                     'states': len(ss), 'excluded_metadata': excluded,
                     'projection': 'decisions仅移除agent_view；逐行附真实_line和_source_sha256；states不删字段'})
save('consumer-input-manifest.json', requests)
print(json.dumps({'verified_rows': sum(e['verified_rows'] for e in verification),
                  'material_checks': len(checks), 'consumer_inputs': requests}, ensure_ascii=False))

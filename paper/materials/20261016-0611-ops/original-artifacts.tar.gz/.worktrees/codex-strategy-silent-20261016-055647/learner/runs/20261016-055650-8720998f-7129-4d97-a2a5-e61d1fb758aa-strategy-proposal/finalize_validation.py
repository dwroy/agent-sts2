"""保存本批交付边界与所属CLI记录的只读验收。"""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
W = S.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
date = subprocess.check_output(['date'], text=True).strip()
result = json.loads((S / 'result.json').read_text())
batch = json.loads((S / 'batch-binding.json').read_text())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=W, text=True)
assert head == result['base'] and len(head) == 40 and not status
assert result['fixes'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['implementation_domains'] == []
assert len(result['proposal_results']) == 10
assert {r['id'] for r in result['proposal_results']} == set(batch['proposal_ids'])
assert all(r['state'] == 'waiting' and r['reason'] and 'commit' not in r for r in result['proposal_results'])
assert result['report'] == str(S / 'report.md') and (S / 'proposal.md').is_file()

old = json.loads((S / 'ledger-before.json').read_text())
spec = importlib.util.spec_from_file_location('batch_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
rows = []
for n, raw in enumerate((ROOT / 'paper/materials/learning/ledger.jsonl').open(), 1):
    row = json.loads(raw)
    if row.get('id') in old:
        rows.append((n, row))
new = ledger.fold(rows)
preserved = []
for item_id, before in old.items():
    after = new[item_id]
    for key in ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_runs', 'prior_note',
                'evidence', 'status', 'version']:
        assert before.get(key) == after.get(key), (item_id, key)
    for key in ['history', 'notes']:
        prior = before.get(key, [])
        assert after.get(key, [])[:len(prior)] == prior, (item_id, key)
    for key, values in before.get('where', {}).items():
        assert after['where'][key][:len(values)] == values, (item_id, 'where', key)
    assert str(S / 'report.md') in after['where']['proposal']
    assert str(S / 'proposal.md') in after['where']['proposal']
    preserved.append({'id': item_id, 'status': after['status'], 'version': after.get('version'),
                      'core_fields_evidence_and_history_prefix_preserved': True})
receipt = json.loads((S / 'ledger-update-receipt.json').read_text())
with (ROOT / 'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(receipt['ledger_before_bytes'])) == receipt['ledger_before_sha256']
    for item in receipt['own_rows']:
        handle.seek(item['offset'])
        raw = handle.read(item['bytes'])
        assert sha(raw) == item['sha256'] and json.loads(raw) == item['row']

budgets = []
for raw in (S / 'evidence/decisions.evidence.jsonl').open():
    item = json.loads(raw)
    if item['line'] in [279021, 279197, 279852, 279854]:
        row = item['row']
        budgets.append({'source_line': item['line'], 'source_sha256': item['sha256'],
                        'run_id': item['run_id'], 'rollout': row.get('rollout'),
                        'sl_explore': row.get('sl_explore'), 'journal': row.get('journal')})
(S / 'forecast-budget-readback.json').write_text(json.dumps(budgets, ensure_ascii=False, indent=2) + '\n')
validation = {'date': date, 'head': head, 'git_status_porcelain': status,
    'source_tests': result['tests'], 'no_source_commit_or_live_merge': True,
    'ten_assigned_ids_exact': True, 'all_proposal_original_sha_verified': True,
    'ledger_update_exit': receipt['exit_code'], 'ledger_own_rows': receipt['own_rows_count'],
    'ledger_old_physical_prefix_preserved': True, 'ledger_owned_rows_re_read': True,
    'ledger_preservation': preserved,
    'material_checks': 28, 'offline_audit_inputs': 7, 'offline_audit_exit_codes': [0] * 7,
    'helper_readback_exit': 0,
    'limits': '材料断言与离线读回不是tsc/vitest；没有新增规则、收益或完整候选认证。'}
(S / 'final-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
inventory = []
for path in sorted(S.rglob('*')):
    if path.is_file() and path.name != 'artifact-manifest.json':
        inventory.append({'path': str(path.relative_to(S)), 'bytes': path.stat().st_size,
                          'sha256': sha(path.read_bytes())})
(S / 'artifact-manifest.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': head, 'worktree_clean': not status, 'proposal_results': 10,
                  'ledger_rows_verified': len(preserved), 'artifacts': len(inventory),
                  'result': str(S / 'result.json')}, ensure_ascii=False))

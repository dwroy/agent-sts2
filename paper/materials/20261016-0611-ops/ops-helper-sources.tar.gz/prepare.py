from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0611';pub=root/'paper/materials/20261016-0611-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-055647-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();original=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in report.items() if k!='proposal_results'}=={k:v for k,v in original.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in report['proposal_results']]==[(x['id'],x['state']) for x in original['proposal_results']] and all(x['reason'] for x in original['proposal_results'])
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(b['proposal_ids'])==set(report['code_proposals'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-validation.json');assert final['head']==report['base'] and final['git_status_porcelain']=='' and final['no_source_commit_or_live_merge'] and final['ledger_own_rows']==32 and final['ledger_update_exit']==0 and final['source_tests']==report['tests']
for item in load(s/'artifact-manifest.json'):
    f=s/item['path'];raw=f.read_bytes();assert f.is_relative_to(s) and len(raw)==item['bytes'] and sha(raw)==item['sha256']
assigned=load(s/'assigned-proposals.json')['origins'];assert set(assigned)==set(report['code_proposals']);originals=[]
for ident,item in assigned.items():
    f=s/(ident+'.original.md');raw=f.read_bytes();assert sha(raw)==item['proposal_sha256']==sha(Path(item['proposal']).read_bytes());originals.append(dict(id=ident,path=str(f.relative_to(root)),sha256=sha(raw),bytes=len(raw)))
source=load(s/'source-readback.json');live=source['live_head_readonly'];assert source['base']==report['base'] and len(source['leaves'])==17
for item in source['leaves']:
    a=git('show',report['base']+':'+item['path']);z=git('show',live+':'+item['path'])
    assert sha(a)==item['base_sha256'] and sha(z)==item['live_sha256'] and (a==z)==item['same'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and item['source_live_ancestor'];git('merge-base','--is-ancestor',item['base_last_touch'],live)
assert sum(x['same'] for x in source['leaves'])==15 and (s/'source-live-worktree-diff.patch').read_bytes()==b''
for item in source['prior_sources']:
    assert item['base_ancestor'] and item['live_ancestor'];git('merge-base','--is-ancestor',item['commit'],report['base']);git('merge-base','--is-ancestor',item['commit'],live)
current_live=git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip();git('merge-base','--is-ancestor',live,current_live)
facts=load(s/'material-checks.json');assert len(facts['checks'])==28 and all(x['actual']==x['expected'] for x in facts['checks'])
receipts=load(s/'consumer-receipts.json');assert len(receipts)==7 and all(x['exit_code']==0 and x['excluded_metadata']==[] for x in receipts)
for item in receipts:
    for suffix,key in [('audit-input.json','input_sha256'),('audit-output.json','output_sha256'),('audit-stderr.txt','stderr_sha256')]:assert sha((s/(item['name']+'.'+suffix)).read_bytes())==item[key]
totals={key:sum(x['audit'][key] for x in receipts) for key in receipts[0]['audit']};assert totals==dict(segments=170,actions=735,observed_intervals=642,terminal_observations=2,turns=140,observed_turns=86,unknown_turns=54,whole_candidate_verified=0)
helper=load(s/'current-helper-readback.json');assert len(helper['discarded_option_snapshots'])==4 and helper['legacy_multiset_keys_equal'] and helper['scoped_first_card_keys_distinct']
trace=load(s/'ledger-update-receipt.json');inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()];own=[];owned=[]
assert trace['exit_code']==0 and trace['old_physical_prefix_preserved'] and len(inputs)==len(trace['own_rows'])==32 and sha((s/'ledger-update-input.jsonl').read_bytes())==trace['input_sha256']
assert (s/'ledger-update.stderr.txt').read_bytes()==b'' and set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs}
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(trace['ledger_before_bytes']))==trace['ledger_before_sha256']
    for entry in trace['own_rows']:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs)
        own.append(raw);owned.append(entry)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==32 and not set(x.rstrip(b'\n') for x in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,longer_original_result=original,report_reason_scope='Stdout and scheduler match; original result has longer reasons with identical IDs/dispositions and other fields. Original overstrict whole-object comparison failure retained in the ops log.',original_gate=b['no_change_proposals'],native=native,completion=final,source=source,original_live=live,current_live_at_ops_read=current_live,no_live_write_by_this_wake=True,original_proposals=originals,original_evidence_verification=load(s/'evidence-verification.json'),material_checks=facts,consumer_receipts=receipts,original_consumer_totals=totals,current_helper_readback=helper,owned_trace_rows=owned,protected_old_fields_and_prefixes_preserved=True,verification_scope='Original artifacts and seven consumer input/output/stderr hashes checked; no reexecution of extraction, material scripts, helpers or offline audits and no new semantic certification of6606rows.',limits=['Seven layer windows are not five complete runs. All complete candidate outcomes remain unknown; P74F22/BTS31 lack certifiable turn windows.','Four discard snapshots do not simulate dynamic card/target/trigger/survival outcomes. Existing first-card identity and single-discard fixes do not close broad requirements.','RC first forecast3turns2samples versus last5turns24samples, and BTS before3/after5turns4samples, remain separate budgets. This repeats the existing queue limitation, not a new notice.','Historical source commits exist; dirty knowledge/move-table bytes and complete joint inputs are not reconstructed. Frozen source audit binds e716, not later calibration trees.','Original case/path/output probes retained; no new gameplay contradiction or other role ACK. No source, release, production tests, paper refresh, dispatch or game action. Broad parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0611原055647策略done0/no-source核收，c647基线干净工作树/HEAD不变，十waiting逐项原缺口/testsnull/mergednull保持，无提交或合入受阻。原材料报告五Silent A10八流6606行、28固定断言及七指定层有界审计；本轮按清单SHA核档、七input/output/stderr SHA核，不重执行提取/材料/生产函数或审计，不新增6606行完整语义认证。原审计合170题段/735动作/642相邻端点/2终态端点/140轮窗（86可核54未知），整候选认证0；P74F22/BTS31未知不补0。四合法弃牌快照不充动态分支/续步生存，既有投斧首牌/普通单弃窄实现不关闭bc4/df宽项。RC原首题3轮2样本/末题5轮24样本与BTS抽弃前3轮4样本/重算后5轮4样本分列，沿既有waiting不重复通知；NHA多16净伤多损6血及RC少7净伤多损4血不拟新SL/血价/排序。17源码15同2历史Roy/Dai注释差、来源及两旧修复base/原e716 live祖先核；源码可定位与历史刷新知识/移动表完整输入未复原分列，原审计不借给后继live校准树。32所属CLI原物理前缀/offset/bytes/SHA与私有fold核，仅where/note追溯，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI/support/repeat或造shipped。原大小写/猜路径/宽输出探针保留；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。仅所属记录/32追溯提交，保并行记录，无源码/合入/发号/补测/论文刷新/复派/对局或账号home模型权限prompt改变，不关闭宽父。证据paper/materials/20261016-0611-ops/。\n'
note=f'\n- {at} [运维 codex] 原055647策略十项均waiting，无源码修改或合入阻塞；原材料和七有界审计回执按SHA归档，32所属追溯核收。完整候选/动态分支/受控后继缺口保持，本轮无新发布、补测或对局操作。回执paper/materials/20261016-0611-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=32,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,owned_trace_rows=32,ledger_check=0,paths=len(entries))))

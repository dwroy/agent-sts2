import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = [json.loads(line) for line in (HERE / 'focus-states.jsonl').open()]
byline = {s['line']: s for s in states}
decisions = {d['line']: d for d in json.loads((HERE / 'focus-decisions.json').read_text())}
checks = []


def check(name, actual, expected, refs):
    assert actual == expected, (name, actual, expected)
    checks.append({'项目': name, '实际': actual, '预期': expected, '证据行': refs})


def enemy(line, ident):
    return next(e for e in byline[line]['enemies'] if e['enemy_id'] == ident)


def ep(line, ident, power):
    return enemy(line, ident)['powers'].get(power, 0)


def pp(line, power):
    return byline[line]['powers'].get(power, 0)


def attack(line, ident):
    return sum(d * max(1, h or 1) for d, h in enemy(line, ident)['attacks'])


def paired(first, second, expected):
    a, b = decisions[first]['row'], decisions[second]['row']
    check('同指纹 ' + str(first) + '/' + str(second), a['fingerprint'] == b['fingerprint'], True, [first, second])
    outputs = []
    for d in [a, b]:
        start = next(s for s in states if s['ts'] == d['observed_ts'])
        end = next(s for s in states if s['run_id'] == start['run_id'] and s['floor'] == start['floor'] and s['line'] > start['line'] and isinstance(s['turn'], int) and s['turn'] > start['turn'])
        check('可操作稳定起点 ' + str(start['line']), [start['readiness']['can_use_combat_actions'], start['readiness']['actions_settled'], start['readiness']['snapshot_stable']], [True] * 3, [start['line']])
        outputs.append({'start': start['line'], 'end': end['line'], 'hp_loss': start['hp'] - end['hp'], 'enemy_net_hp_loss': sum(e['current_hp'] for e in start['enemies']) - sum(e['current_hp'] for e in end['enemies'])})
    check('当轮实损/敌净扣 ' + str(first) + '/' + str(second), [[x['hp_loss'], x['enemy_net_hp_loss']] for x in outputs], expected, [x for o in outputs for x in [o['start'], o['end']]])
    return {'decisions': [first, second], 'outcomes': outputs}


check('T4技能/能力污染', [pp(n, 'TAINTED_POWER') for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6], [274830, 274831, 274832, 274833])
check('棱柱火花增长', [ep(n, 'INFESTED_PRISM', 'VITAL_SPARK_POWER') for n in [274830, 274834]], [3, 6], [274830, 274834])
check('T5污染逐技能累积', [pp(n, 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]], [0, 6, 12, 18], [274834, 274836, 274837, 274838])
check('T5挡/攻/实际血价', [byline[274838]['block'], attack(274838, 'INFESTED_PRISM'), byline[274834]['hp'] - byline[274839]['hp']], [17, 26, 9], [274834, 274838, 274839])
check('次轮污染撤去', pp(274839, 'TAINTED_POWER'), 0, [274839])
check('负属性与步法先后', [[pp(n, 'STRENGTH_POWER'), pp(n, 'DEXTERITY_POWER')] for n in [274351, 274352, 274354, 274358, 274362]], [[-4, -4], [-4, -2], [-4, 0], [0, 0], [0, -2]], [274351, 274352, 274354, 274358, 274362])
check('末次一步法仍负敏', pp(274392, 'DEXTERITY_POWER'), -2, [274391, 274392])
check('毒死失落后仍死亡', [byline[274397]['hp'], [e['enemy_id'] for e in byline[274397]['enemies']]], [0, ['THE_FORGOTTEN']], [274396, 274397])
check('蚌当前力量', [ep(n, 'SEWER_CLAM', 'STRENGTH_POWER') for n in [273239, 273252, 273263]], [0, 4, 8], [273239, 273252, 273263])
check('蚌喷水意图', [attack(n, 'SEWER_CLAM') for n in [273239, 273252, 273263]], [11, 15, 19], [273239, 273252, 273263])
check('蚌弱后意图', [attack(n, 'SEWER_CLAM') for n in [273254, 273268]], [11, 14], [273254, 273268])
check('蚌覆甲现场', [ep(n, 'SEWER_CLAM', 'PLATING_POWER') for n in [273239, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273239, 273247, 273252, 273258, 273263])
check('蚌末轮完整需求/截顶血价', [attack(273268, 'SEWER_CLAM') - byline[273268]['block'], byline[273268]['hp'], byline[273269]['hp']], [4, 2, 0], [273268, 273269])
check('电击连续现场增长', [[enemy(n, 'ZAPBOT')['max_hp'], ep(n, 'ZAPBOT', 'HIGH_VOLTAGE_POWER'), ep(n, 'ZAPBOT', 'STRENGTH_POWER'), attack(n, 'ZAPBOT')] for n in [274308, 274313]], [[23, 2, 2, 17], [23, 2, 4, 19]], [274308, 274313])
check('电击T3仍出手损30', byline[274308]['hp'] - byline[274313]['hp'], 30, [274308, 274313])
check('电击T4才清退', any(e['enemy_id'] == 'ZAPBOT' for e in byline[274317]['enemies']), False, [274313, 274317])
pairs = [paired(270216, 270282, [[3, 10], [15, 17]]), paired(271309, 271348, [[0, 45], [9, 38]]), paired(271992, 272040, [[9, 24], [14, 27]]), paired(271982, 272195, [[2, 25], [10, 34]])]
check('沙虫末试真实能力', [pp(276433, 'DEXTERITY_POWER'), pp(276433, 'AFTERIMAGE_POWER'), byline[276433]['block']], [2, 1, 22], [276433])
check('沙虫末轮需求/血价/毒/时钟', [attack(276433, 'THE_INSATIABLE') - byline[276433]['block'], byline[276433]['hp'] - byline[276434]['hp'], enemy(276433, 'THE_INSATIABLE')['current_hp'] - enemy(276434, 'THE_INSATIABLE')['current_hp'], ep(276434, 'THE_INSATIABLE', 'SANDPIT_POWER')], [15, 5, 24, 1], [276433, 276434])
check('实验体阶段旧毒/力清空', [[enemy(n, 'TEST_SUBJECT')['max_hp'], ep(n, 'TEST_SUBJECT', 'POISON_POWER'), ep(n, 'TEST_SUBJECT', 'STRENGTH_POWER')] for n in [277512, 277513]], [[111, 4, 15], [212, 0, 0]], [277512, 277513])
check('零毒触媒当前层数', [pp(277519, 'ACCELERANT_POWER'), ep(277519, 'TEST_SUBJECT', 'POISON_POWER')], [2, 0], [277519])
check('后得敏捷不倒补挡', [[pp(n, 'DEXTERITY_POWER'), byline[n]['block']] for n in [277523, 277526]], [[5, 23], [6, 23]], [277523, 277526])
check('实验体末轮净扣37', enemy(277519, 'TEST_SUBJECT')['current_hp'] - enemy(277527, 'TEST_SUBJECT')['current_hp'], 37, [277519, 277527])
check('实验体末轮攻击44与少3血', [attack(277527, 'TEST_SUBJECT'), attack(277527, 'TEST_SUBJECT') - byline[277527]['block'] - byline[277527]['hp']], [44, 3], [277527])
check('镣铐临减/恢复', [ep(n, 'CRUSHER', 'STRENGTH_POWER') for n in [278236, 278237, 278242]], [0, -9, 0], [278236, 278237, 278242])
check('轮初赠挡与实打挡', [byline[278236]['played'], byline[278236]['block'], byline[278240]['block'], byline[278236]['hp'] - byline[278242]['hp']], [0, 14, 20, 0], [278236, 278240, 278242])
check('双蟹朝向/弱逐步意图', [attack(n, 'ROCKET') for n in [278249, 278252, 278253]], [57, 38, 28], [278249, 278252, 278253])
check('双蟹四敏脆弱挡', [pp(278255, 'DEXTERITY_POWER'), byline[278255]['block'], byline[278258]['block']], [4, 6, 6], [278255, 278258])
check('双蟹两次匕首雨即时扣', [sum(e['current_hp'] for e in byline[a]['enemies']) - sum(e['current_hp'] for e in byline[b]['enemies']) for a, b in [(278255, 278256), (278259, 278260)]], [16, 20], [278255, 278256, 278259, 278260])
check('双蟹末轮已结算毒', [enemy(278260, ident)['current_hp'] - enemy(278261, ident)['current_hp'] for ident in ['CRUSHER', 'ROCKET']], [3, 7], [278260, 278261])
sl = [x['row'] for x in json.loads((HERE / 'sl-attempts.json').read_text())]
check('SL实际胜利反例', [(x['attempt'], x['result'], x['end_hp']) for x in sl if x['run_id'] == 'YF0LXT1QSTGG' and x['floor'] == 33], [(1, 'predicted_death', 4), (2, 'won', 20)], ['sl-attempts:928', 'sl-attempts:929'])
for run, floor in [('8JRE1C4H4Z2W', 33), ('YF0LXT1QSTGG', 48), ('XP2SL33HT0D9', 33)]:
    rows = [x for x in sl if x['run_id'] == run and x['floor'] == floor]
    check('五次预测死/一次实死 ' + run, [x['result'] for x in rows], ['predicted_death'] * 5 + ['died'], [x['attempt'] for x in rows])
(HERE / 'material-verification.json').write_text(json.dumps({'说明': '仅核原始材料，不是生产源码测试、撤源码负控或独立收益验证', '检查数': len(checks), 'checks': checks, 'pairs': pairs}, ensure_ascii=False, indent=2) + '\n')
print('材料核验通过：' + str(len(checks)) + '项；生产测试未运行。')

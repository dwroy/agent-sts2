import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(value):
    return {p['power_id']: p['amount'] for p in value.get('powers', [])}


def compact(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **{k: v for k, v in item.items() if k != 'row'},
        'ts': row.get('observed_ts', row['ts']),
        'floor': (state.get('run') or {}).get('floor'), 'turn': state.get('turn'),
        'screen': state.get('screen'), 'hp': player.get('current_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'played': player.get('cards_played_this_turn'), 'powers': powers(player),
        'actions': state.get('available_actions'), 'readiness': combat.get('action_readiness'),
        'hand': [c.get('card_id') for c in combat.get('hand', [])],
        'enemies': [{**{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id']},
                     'powers': powers(e), 'attacks': [(i.get('damage'), i.get('hits')) for i in e.get('intents', []) if i.get('damage') is not None]}
                    for e in combat.get('enemies', [])],
    }


def main():
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    streams = {}
    verifications = []
    for entry in manifest:
        stream = entry['stream']
        path = HERE / 'evidence' / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256'], stream
        items = []
        counts = collections.Counter()
        with (Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')).open('rb') as source:
            for line in path.open():
                item = json.loads(line)
                assert item['offset'] + item['bytes'] <= entry['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert extract.run_identity(item['row']) == item['run_id']
                counts[item['run_id']] += 1
                items.append(item)
        assert all(counts[run] == n for run, n in entry['counts'].items())
        streams[stream] = items
        verifications.append({'stream': stream, 'source_size': entry['source_size'], 'verified_rows': len(items), 'output_sha256': entry['output_sha256'], 'byte_identity_json_counts_ok': True})
    save('byte-verification.json', verifications)
    runs = {i['run_id']: i['row'] for i in streams['runs']}
    assert len(runs) == 6
    assert all(r['character'] == 'SILENT' and r['ascension'] == 10 for r in runs.values())
    save('run-identities.json', runs)
    configs = []
    for item in streams['run-config']:
        r = item['row']
        configs.append({'run_id': item['run_id'], 'code': r['code'], 'brain': r['brain'], 'knowledge': r['knowledge'], 'source_line': item['line']})
    save('historical-run-configs.json', configs)
    focus = {'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39}, 'CA5KE8GFJ9X2': {13}, '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}
    focused = [compact(i) for i in streams['states'] if (i['row']['state'].get('run') or {}).get('floor') in focus[i['run_id']]]
    with (HERE / 'focus-states.jsonl').open('w') as out:
        for item in focused:
            out.write(json.dumps(item, ensure_ascii=False) + '\n')
    decisions = []
    for item in streams['decisions']:
        r = item['row']
        if r.get('floor') not in focus[item['run_id']]:
            continue
        decisions.append({**{k: v for k, v in item.items() if k != 'row'}, 'row': {k: r.get(k) for k in ['ts', 'observed_ts', 'floor', 'turn', 'sl_attempt', 'label', 'fingerprint', 'chosen', 'rationale', 'result', 'questions']}})
    save('focus-decisions.json', decisions)
    save('sl-attempts.json', streams['sl-attempts'])
    save('run-plans-index.json', [{**{k: v for k, v in i.items() if k != 'row'}, 'floor': i['row'].get('floor'), 'trigger': i['row'].get('trigger')} for i in streams['run-plans']])
    print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in verifications), 'focus_states': len(focused), 'focus_decisions': len(decisions), 'runs': list(runs)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

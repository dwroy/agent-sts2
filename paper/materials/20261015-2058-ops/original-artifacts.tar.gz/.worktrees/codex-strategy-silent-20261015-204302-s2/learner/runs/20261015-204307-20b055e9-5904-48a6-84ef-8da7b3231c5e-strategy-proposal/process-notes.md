本批材料定位过程保留说明：

- 两次rg猜测路径不存在：combat-candidate-audit.ts、known-mechanics.ts、fight-value.ts、room-cost.ts。后用rg --files找到silent-selection-audit.ts、silent-hp-guard-audit.ts、room-costs.ts等实际路径。原命令返回2，未修改生产文件。
- 一次材料预览对combat=null使用list，返回TypeError；随后以空值保护预览并完成正式8274行核验，原提取输出未覆盖。
- 多次终端预览因预算截断，完整原Markdown副本、selected-proposals.json、ledger-before.json、selected-experience.json及源码diff均保留；逐项结论来自重新限定字段读取和原材料断言。
- 导入抽取器生成的本树字节码已移到本批source/extract_evidence.cpython-314.pyc.txt，临时副本集中本批目录；未删除其他会话缓存。

这些是材料命令/预览边界，不当产品bug、撤源码负控或生产检查结果。

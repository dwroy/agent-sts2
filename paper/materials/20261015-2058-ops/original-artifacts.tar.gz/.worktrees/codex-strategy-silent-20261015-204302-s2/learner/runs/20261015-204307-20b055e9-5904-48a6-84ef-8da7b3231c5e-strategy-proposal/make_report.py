import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261015-204302-s2-strategy-proposal'
stamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
dispatch = json.loads((HERE / 'dispatch.json').read_text())
proposals = json.loads((HERE / 'selected-proposals.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
source = json.loads((HERE / 'source-audit.json').read_text())
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
assert base == 'cd6be6ac456b731612522a7e044ee1e2b7763819'

details = [
    ('感染棱柱污染', 'DUZUBAJ3A8GP F27 T4—6；states:274830—274839。T4污染0→3→3→6，T5火花6、技能污染0→6→12→18，17挡对26攻实损9，T6撤污染。',
     '当前turn-solver已有技能污染及逐击伤害，rollout已有火花增层；未发现新的确定性差异。',
     '同时比较技能毒/挡、污染、弱与后轮变化；不固定禁技能。',
     '缺历史dirty运行实际消费的A10移动表，以及毒、挡、污染跨轮的完整候选联合回放；不能由局部9血代价拟新技能优先级。',
     '技能同时提供毒/挡，不能把污染视作净损；未选线整战结果未知。'),
    ('抢夺与返还归属', '5PM6JAQG6FNQ F39 T4—6；states:274351—274362、274391—274397。首试力敏−4/−4，两步法回0敏，失落退场后力回0，T6又被夺至−2敏。末试一步法仍−2敏，最终死亡。',
     '当前候选读取现场负属性；这不等于按来源保存累计被夺量。',
     '逐实体保存实际夺取/归还量，区分步法新得与返还；不给固定击杀顺序。',
     '缺逐来源累计被夺量、非抢夺属性来源及死亡返还的完整冻结模型输入；现帧总负属性不能替代应返还量，另一杀序完整后继未知。',
     '末试毒退失落后仍死于遗忘；不能据退掉一敌保证存活。'),
    ('下水道蚌当前进阶事实', 'CA5KE8GFJ9X2 F13 T1—5；states:273239、273252、273263、273268—273269。力0/4/8，喷水11/15/19，弱后11/14；末轮完整需损4，只有2血。',
     'monster-db的当前进阶HP/伤害从已有第一样本读取；room-costs仍保留5样本门槛，均无需本批重写。',
     '冻结A10加压/弱与实际覆甲，不从单场生成房间成本。',
     '缺原dirty运行实际消费的A10移动表快照及覆甲完整减层条件的独立输入；未定位新的当轮公式缺陷。',
     '覆甲9/9/8/7/6只是观察序列，不能推出所有减层条件；死亡HP损2不等于完整攻击只需损2。'),
    ('高电压逐实体增长', '5PM6JAQG6FNQ F38 T3—4；states:274308—274317。同23上限电击高电压2、力2→4、攻17→19，T3实损30，T4群伤才退电击。',
     'rollout已有HIGH_VOLTAGE_POWER增长及召唤模板路径，另有未建模召唤提示；这些不证明召唤代际完整归属。',
     '当前进阶事实与每个实际存活实体的累计增长分别核对。',
     '缺稳定召唤代际、新同类替换及累计量归属的冻结输入；本局一个连续存活样本不能验证新实体不继承旧计数。',
     '先杀爪牙的35伤/损3只属未执行候选，不能声称必省27血或救下后场。'),
    ('沙虫候选、护栏与资源分账', '8JRE1C4H4Z2W F33首/三试T2；decisions:270216/270282，states:276208→276212、276274→276278。同指纹实损3→15、敌净扣10→17。第二试T5 HP护栏见decision:270264；末试T11见states:276433—276434。',
     '已有选择审计及护栏审计，分别保存预测；actual_turn/actual_outcome仍为null，不是完整执行账。',
     '跨抽弃牌、护栏、SL绑定实际完成前缀、逐来源能力/毒/血价；保留现选择。',
     '缺跨抽弃牌、护栏和SL的完整候选执行归属、逐来源兑现及资源联合校准；已有预测/端点字段不能闭合整项。',
     '原答/替线五轮死0/24与5/24有区别，不能写成同死率；末试5血22挡对37，完整需损15而实扣仅5，24毒结后敌余130、沙坑1。'),
    ('实验体SL截断续步', 'YF0LXT1QSTGG F48第二/三试T1；decisions:271309/271348/271354，states:277327→277337、277366→277373。同指纹实损0→9、敌净扣45→38。F33第二试SL实际胜20血，sl-attempts:928—929。',
     'SL仍允许原路径已失败时探索；已有原答/替换预测审计，不把全败并列称安全。',
     '分列原答、替换、实际首次动作及未执行续步；保留探索。',
     '缺未执行续步、完整替代线的资源/胜负对照及跨重问执行归属；不能据同轮劣化校准SL惩罚或禁止探索。',
     '第六次恢复挡、T1零损仍失败；F33 SL实胜反对全盘否定探索。第四次T5弃牌切断替换候选，不作为完整执行。'),
    ('实验体阶段与毒能力兑现', 'YF0LXT1QSTGG F48末试T3—5；states:277512—277528。111血阶段剩4毒/15力，换212血时归零；触媒2、当前毒0；5敏先得23挡，第三小刀升6敏不倒补，净扣37，18血对44攻/23挡差3。',
     '已部署当前阶段快照，区分持有与建立，并把已兑现毒伤保留null；不预测下一轮贡献。',
     '逐阶段、逐候选核实已建能力、施毒、真实结算与增段，不预支未来收益。',
     '缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准；当前阶段快照和零毒提示只覆盖局部。',
     '前试已建毒雾/余像仍败；不能认定未启动毒是唯一死因，未见第三阶段实盘。'),
    ('双蟹零胜并列换线血价', 'XP2SL33HT0D9 F33首/二试T3、首/末试T1；decisions:271992/272040、271982/272195。states:278028→278031、278076→278079实损9→14/净扣24→27；278018→278023、278231→278236实损2→10/净扣25→34。',
     '已有并列和即时损血参考，SL仍按既有门槛/排序探索；保留全部选项。',
     '比较同轮血价、输出、能力条件；新保血优先排序必须另有数据支持。',
     '缺原线与换线的独立完整后继、受控随机池及整战结果；不能由B2零胜并列验证低当轮损失优先的新排序。',
     '首末T1同时获得手里剑成长；末试T2零损、T3实损4仍败，不能忽略成长/朝向或认定所有付血探索都错。'),
    ('双蟹朝向与能力兑现窗口', 'XP2SL33HT0D9 F33末试T2—5；states:278236—278261。镣铐0→−9→0，T2轮初14、斗篷后20/零损；T4意图57→38→28；4敏脆弱两牌各6挡；两次匕首雨即时扣16/20，末轮毒实结3+7。',
     '已有临减到期恢复、朝向/弱、轮初14挡及后继敏捷模型；这不等于逐候选完整贡献拆分已完成。',
     '现场已有挡/本线新挡、临减、朝向、弱、已结毒、能力持续值分别审计。',
     '缺逐候选贡献拆分、完整执行绑定及条件联合校准；局部公式和观察参考不足以将整项登记duplicate。',
     '实际五轮净扣150而两敌仍153/125；建立能力不保证减员或存活。'),
    ('历史机制、路线及SL综合闭环', '本批直接锚点YF0LXT1QSTGG、XP2SL33HT0D9的F48/F33关键回合如上；读取25条关联静默经验、30个关联账本。原提案的101局历史统计及跨机制分母只作为原文范围保留。',
     '已有局部机制、当前快照和选择审计；本批六锚点不等于原101局独立核验。',
     '保留全部历史来源，按实际资源及完整候选执行核验；不强制能力、路线或休息规则。',
     '六锚点不覆盖原101局历史分母；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准。',
     '同局SL不增加独立局数，候选差不冒充实际收益；无留药或改路受控获胜对照。'),
]
assert len(proposals) == len(details) == 10
results = [{'id': p['id'], 'state': 'waiting', 'reason': detail[4]} for p, detail in zip(proposals, details)]

intro = f'''# 本批静默策略提案核验

登记时间：{stamp}（写入前执行date）。角色silent，已观察进阶A10。来源/实现任务strategy-proposal，批次{BATCH}。本批普通队列，只处理dispatch.json中的10个原ID，没有research_request或implementation_request；根普通专题请求绑定其他批次，不转专题、不扩队列。

工作树初始干净；执行git merge --no-edit main返回Already up to date。完整base/HEAD：`{base}`。无生产源码、知识、任务模板或验证输入变更；fixes=[]，merged=null。未提交、未合live、未发eval版本、未标shipped。没有新代码提案ID；沿用原CLI登记的10个ID。旧账本已shipped的状态不退回proposed，未完成代码要求仍waiting。

## 证据范围与复核方法

六局runs.jsonl均为SILENT/A10，六个独立来源局，SL尝试不扩分母。共用extract_evidence.py按显式身份抽取八流；保存逐行source/offset/bytes/SHA、source_size、计数及输出SHA。analyze_evidence.py逐行seek回只读原日志，核8274行原字节、JSON、身份、计数及输出哈希全部一致。语义重点为原题相关1062帧状态、1043条决策，不声称逐机制重做全历史统计。

49项原材料断言通过，见material-verification.json/log；这是材料复核，不是生产tsc/vitest、撤源码负控、整场模型校准或收益检验。无生产源码修改，tests={{"tsc":null,"vitest":null,"cases":null}}，撤源码失败/恢复通过均不适用。

各流所选行数：

|流|行数|冻结原字节截点|无效JSON行数|
|---|---:|---:|---:|
'''
intro += ''.join(f"|{m['stream']}|{sum(m['counts'].values())}|{m['source_size']}|{m['invalid_lines']}|\n" for m in manifest)
intro += '''
fight-plans本截点选中0行，仅表示当前截点未选到，不判原日志缺失；run-plans身份来自run字段，本批实际33行。states/decisions/brain全流扫描分别有2/2/1行无效JSON，原件保留、不修日志、不把它们计为六局有效证据。提取输出没有不完整末行。

## 当前源码与实际live边界

source-audit.json冻结15叶源码及实际live HEAD，11叶逐字相同，4叶只存在Roy/Dai文字替换差；精确diff保存在source/*.diff.txt，未覆盖历史差异。所查15叶live工作副本均与该HEAD一致。保留base源码.txt及空worktree.diff.patch，不归档/展开整个仓库。相关原局全为dirty运行，run-config虽记录commit/dirty文件清单，未提供每局实际消费的完整知识字节；当前表不能冒称原dirty输入。

已有实际live祖先的局部功能：选择审计05cd292c6f01bb31e406473d3a9843e659d62b93；护栏审计a8b1f8be153fe4f3a34146117546c2178f2e446b；当前阶段事实8698c581dac6c7e957f50a381586960a6d0c9b57。已按实际live祖先检查并核源码字节；它们只证明已有局部路径，不能把整项waiting改成duplicate，也不算本批实现。

monster-db.moveDamageAt/monsterHpAt使用当前进阶已有观测，未设五样本拦截；room-costs.MEASURED_ROOM_MIN_N=5保持。silentSelectionAudit.scope=predicted_candidates、execution_status=pending_dispatch、actual_turn=null，护栏actual_outcome=null；silentPhaseCurrentFacts.scope=observed_current_snapshot、poison_damage_already_dealt=null。已知与未知边界不混用。

本批未读取其他角色知识、游戏二进制或密钥，未联网/调LLM/运行play/停对局/推送/改运维prompt。历史run-config里的大脑模型gpt-6.1-sol/effort=high只描述历史局，不能当本学习者原生会话参数读回；本批没有独立原生运行参数回执，不虚报运行配置已切换。

## 逐项处置

'''
sections = []
for p, (title, evidence, old, expected, missing, counter) in zip(proposals, details):
    sections.append(f'''### {p['id']}：{title}

来源任务：{p['source_task']}；目标实现任务：strategy-proposal。原Markdown：{p['proposal']}；原SHA256 `{p['proposal_sha256']}` 与本批原字节副本一致。

账本：{', '.join(p['ledger'])}。

证据：{evidence}

旧规则/当前实现：{old}

预期行为：{expected}

反例与限制：{counter}

处置：waiting。{missing}

验证：固定上述状态、手牌、原候选/执行前缀与实际消费的模型输入，按同一run/尝试/指纹比较每步HP、敌本体HP、毒、挡及能力时点；抽弃牌与重规划后重新绑定。局部确定性新增接线须撤生产源码失败、恢复通过，再经原沙箱入口；策略参数需独立后移局验证，同局SL不跨训练/验证。本批不拟系数，不预支未执行候选胜负。

预期影响与回退：目前仅补可追溯处置，出牌/药水/SL/终局规则均保持。无生产代码需回退；后续改动须以真实源码提交回退并按授权通知Roy。现有授权Roy-2026-10-07-learning不提供游戏事实。

''')
proposal_text = intro + ''.join(sections)
(HERE / 'proposal.md').write_text(proposal_text)
report_text = proposal_text.replace('# 本批静默策略提案核验', '# 本批静默策略完成报告', 1)
report_text += f'''## 完成与交接

10个原ID全部核验并分别waiting；没有遗漏、另领取、重复建ID或伪造源码提交。code_proposals沿用原CLI ID，implementation_domains=[]（无本批实现）。本批实际live只读快照 `{source['live_head']}`，未执行合并流程。未新增游戏结论/反证，不重写历史复盘，也不关闭学习入库父要求。

通过根目录learner/ledger.py update仅对30个关联静默账本追加本报告/提案去处与本批限制，by=learner:strategy-proposal；原claim/证据/first_run/prior/asc/status/version/effect保持。输入/输出、原字节位置和保护字段校验见ledger-update-input.jsonl、ledger-update.stdout、ledger-update.stderr、ledger-update-verification.json；结果以真实回执为准。

材料定位中出现不存在的猜测源码路径，已改用rg --files定位；一次预览对combat=null调用list而失败，未改数据，随后用空值保护完成抽取和49项核验。相关说明保留，不把材料命令失败当产品bug或生产测试。所有原提案、副本、提取报告及过程文件留在本批目录，日志只读。

交运维的提案：{HERE / 'proposal.md'}。
交运维的报告：{HERE / 'report.md'}。

源码提交：无。撤源码负控/恢复：未运行，无源码可撤。tsc/vitest：未运行（null）。合入提交/发布编号：无。收益/自然消费者：未验证。具体待补数据以每个原ID的waiting理由为准。
'''
(HERE / 'report.md').write_text(report_text)
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': base,
         'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': [p['id'] for p in proposals], 'implementation_domains': [],
         'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('ledger', PROJECT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
ids = sorted({ident for p in proposals for ident in p['ledger']})
items = ledger.fold()
protected_keys = ['character', 'kind', 'claim', 'evidence', 'first_run', 'prior', 'prior_note', 'prior_runs', 'asc', 'status', 'version', 'effect', 'shipped_at']
before = {ident: {k: items[ident].get(k) for k in protected_keys} for ident in ids}
assert all(v['character'] == 'silent' for v in before.values())
(HERE / 'ledger-protected-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
with (HERE / 'ledger-update-input.jsonl').open('w') as out:
    for ident in ids:
        related = [r for p, r in zip(proposals, results) if ident in p['ledger']]
        note = f"{BATCH}：本批六静默A10锚点8274行字节核、49项材料核验；关联原提案均waiting，无新源码/合入/版本/生产测试，不改原经验或已上线状态。" + '；'.join(r['id'] + '：' + r['reason'] for r in related)
        out.write(json.dumps({'id': ident, 'by': 'learner:strategy-proposal', 'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]}, 'note': note}, ensure_ascii=False) + '\n')
print(json.dumps({'report': str(HERE / 'report.md'), 'proposals': len(results), 'ledger_updates_prepared': len(ids), 'production_changes': 0}, ensure_ascii=False))

from pathlib import Path
p=Path('ops/codex-ops/record-staging/20261015-2058')
old=Path('ops/codex-ops/record-staging/20261015-2026/prepare-records.py').read_text().replace('20261015-2026','20261015-2058').replace('20261015-201302-s2-strategy-proposal','20261015-204302-s2-strategy-proposal')
a=old.index('final=');z=old.index('inputs=')
old=old[:a]+'''final=load(s/'final-verification.json');assert final['head']==report['base'] and final['working_tree_clean'] and final['no_source_changes'] and final['proposal_results']==10 and final['ledger_updates']==30 and final['material_checks']==49
assert sha((s/'report.md').read_bytes())==final['report_sha256'] and sha((s/'proposal.md').read_bytes())==final['proposal_sha256']
markdown=load(s/'selected-proposals.json');assert len(markdown)==10
for x in markdown:assert x['character']=='silent' and sha((s/(x['id']+'.original.md')).read_bytes())==x['proposal_sha256']
evidence=load(s/'byte-verification.json');assert len(evidence)==8 and sum(x['verified_rows'] for x in evidence)==8274 and all(x['byte_identity_json_counts_ok'] for x in evidence)
identities=load(s/'run-identities.json');assert len(identities)==6 and all(x['character']=='SILENT' and x['ascension']==10 for x in identities.values())
materials=load(s/'material-verification.json');assert materials['检查数']==49 and len(materials['checks'])==49 and all(x['实际']==x['预期'] for x in materials['checks'])
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['files'])==15;equal=0
for x in source['files']:
 a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head']+':'+x['path']);assert sha(a)==x['base_sha256'] and sha(z)==x['live_head_sha256']==x['live_working_sha256'] and x['live_working_matches_head']
 if a==z:equal+=1
 else:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
 assert x['source_is_live_ancestor'];git('merge-base','--is-ancestor',x['last_live_source_commit'],source['live_head'])
assert equal==11
for commit in ['05cd292c6f01bb31e406473d3a9843e659d62b93','a8b1f8be153fe4f3a34146117546c2178f2e446b','8698c581dac6c7e957f50a381586960a6d0c9b57']:
 for target in [report['base'],source['live_head']]:git('merge-base','--is-ancestor',commit,target)
''' +old[z:]
a=old.index('inputs=');z=old.index("(p/'owned-ledger.jsonl')")
old=old[:a]+'''inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()];owned=[];owned_refs=[];offset=0
for number,raw in enumerate((r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True),1):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs):owned.append(raw);owned_refs.append({'id':row['id'],'line':number,'offset':offset,'bytes':len(raw),'sha256':sha(raw)})
 offset+=len(raw)
assert len(inputs)==len(owned)==30 and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
receipt=load(s/'ledger-update-verification.json');assert receipt['rows']==30 and len(receipt['entries'])==30 and receipt['protected_fields_unchanged'] and receipt['stdout_ids_match'] and receipt['stderr_empty']
for x in receipt['entries']:
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as f:f.seek(x['offset']);raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and raw in owned
ids=(s/'ledger-update.stdout').read_text().split();assert len(ids)==30 and set(ids)=={json.loads(x)['id'] for x in owned}
''' +old[z:]
old=old.replace("assert load(s/'gitleaks.json')==[] and (s/'gitleaks.exit').read_text().strip()=='0'",'')
a=old.index("write(pub/'batch-readback.json'");z=old.index('files=',a)
old=old[:a]+'''write(pub/'batch-readback.json',{'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_final_verification':final,'report_proposal_and_ten_original_markdown_shas_verified':True,'source15_base_and_old_live_sha_live_leaf_sources_and_three_narrow_ancestors_verified':True,'source11_equal4_historical_name_comments_preserved':True,'original_evidence_rows':8274,'original_material_assertions':49,'material_probes_reexecuted':False,'original_cohort':'Six original Silent A10 runs; repeated SL is not independent data.','owned_trace_only_ledger_rows':30,'owned_ledger_byte_refs':owned_refs,'protected_fold_preserved':True,'original_preparation_failures':'Wrong source guesses, combat=null TypeError during preview and truncated output retained; generated extraction bytecode was relocated to own scratch, not a product failure or source patch.','native_gap':'Ops verified original Sol6.1/xhigh/input/lease/workspace-write/no-network. Historical run-config high setting and learner lack of native readback remain separately scoped.','limits':['49 checks are original material arithmetic, not product tests, full model calibration, independent holdout or benefit.','Current-snapshot, predicted-candidate and pending-dispatch scopes retain actual_turn, actual_outcome and poison_damage_already_dealt null.','Observed negative stats do not establish per-source stolen/returned quantities; one persistent summon does not calibrate replacement generations.','Different death counts0/24 and5/24 remain distinct; death-capped actual HP is not gross incoming damage.','Six anchors do not recertify original101-run history; wide proposals and learning parents remain open.'],'no_source_tests_merge_release_dataset_or_game_actions':True})
''' +old[z:]
old=old.replace("'.stdout','.stderr','.exit'", "'.stdout','.stderr','.exit','.log'")
old=old.replace("files+=[s/'evidence/evidence-manifest.json']", "files+=list((s/'source').glob('*.diff.txt'))+[s/'evidence/evidence-manifest.json']")
a=old.index('line=f');z=old.index("appends={'paper",a)
old=old[:a]+'''line=f'\\n- {at} 运维codex：2058原204302-s2策略rc0/done/no-source门禁核，十项waiting；cd6b干净WT无新源码提交，testsnull/mergednull/域空，不重合/发号/补测或新派。六Silent A10原8274行字节/身份与49材料断言为原学习者读回，不重跑或当生产测试/完整候选/整战收益；1062状态/1043决策为语义重点而非全行全历史，原101局分母不以六锚点冒重验。15叶旧livefe646265逐SHA/每叶真实源祖先及三窄源码main-live祖先核，11同/4历史Roy-Dai注释差保持；候选预测/待派发/当前快照与actual_turn/actual_outcome/已结毒伤null边界保留，不据局部审计关闭宽提案。30原CLI只where/note、逐输入和原offset/bytes/SHA与保护字段核，claim/首证/prior/evidence/status/version等不变、不重复CLI。ops补核实际native Sol6.1/xhigh/input/lease、workspace-write/no-network；历史run-config high与本学习者原未读native边界不改。原错误源码猜测/combat空值TypeError/截断输出留史，抽取器字节码迁入本人scratch不当源码修改；材料准备失败不作产品bug。总负属性不替逐源夺返量、连续实体不替召唤代际、SL原0/24与5/24不当同死率、死亡实扣不冒毛伤、同局多次SL不增独立样本，原受控后继/留药/路线及联合校准仍缺。无新知识/反证/源码/复盘，不刷新论文、不改当前局/账号home模型预算队列prompt，原宽父与owner继续原链、不等待未来事件。证据paper/materials/20261015-2058-ops/。\\n'
note=f'\\n- {at} [ops 策略处置] 原204302-s2十项继续waiting，无源码/合入/版本；30条CLI仅追溯且保护旧知识/状态。原8274行/49材料与准备错误均归档，完整候选/归属/后继与原101局范围仍待原链，不重派或补测。回执paper/materials/20261015-2058-ops/。\\n'
''' +old[z:]
old=old.replace("'own_ledger_rows':44", "'own_ledger_rows':30").replace("'owned_ledger_rows':44", "'owned_ledger_rows':30")
old=old.replace("p/'prepare-records.py',p/'seal-records.py',", "p/'prepare-records.py',p/'make-helper.py',p/'seal-records.py',")
(p/'prepare-records.py').write_text(old)
seal=Path('ops/codex-ops/record-staging/20261015-2026/seal-records.py').read_text().replace('20261015-2026','20261015-2058').replace('forty-four trace-only ledger updates','thirty trace-only ledger updates').replace('ops: record unchanged 201302-s2 strategy dispositions','ops: record unchanged 204302-s2 strategy dispositions')
(p/'seal-records.py').write_text(seal)

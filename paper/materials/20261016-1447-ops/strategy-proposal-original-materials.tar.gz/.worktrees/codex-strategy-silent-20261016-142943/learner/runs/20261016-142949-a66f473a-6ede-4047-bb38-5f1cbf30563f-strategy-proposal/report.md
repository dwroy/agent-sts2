# 静默策略批次回报

批次 `20261016-142943-strategy-proposal`，基线 `aba2c9cf76a5d029c0a96a812318029a1aee083f`。

本批十项逐一复核后均 waiting，没有新增源码、知识、参数或提交；未合入 live、未创建版本、未登记 shipped。工作树保持干净。完整证据、账本、反例、缺数据及验收方法见同目录 `proposal.md`，逐项机器结果见 `result.json`。

## 本批身份和输入

- 开工 git status 干净；HEAD=main，按普通批次执行 merge main，Already up to date。没有研究/实现请求绑定，不读取其他专题替代本批，不处理其他队列 id。
- 10份派发提案原 Markdown 的实际 SHA256 全部匹配，保存字节副本。31个关联 silent 账本只追加本批追溯链接和处置说明；不修改旧claim、首证、prior、证据计数、状态、版本或shipped历史，不重复追加support/repeat。
- 10派发锚点加原提案直接引用的5局，runs.jsonl 均为SILENT；A1/A7/A9/A10分列。没有读其他角色私有知识，未把静默经验的更大历史计数冒充本批重算。

## 原日志核验

共用提取器保存source_size、每行原offset/bytes/SHA与计数，输出均经源字节和显式身份读回。八流合19,929行：

| 流 | 字节截点 | 入选行 |
| --- | ---: | ---: |
| states | 13523192532 | 9815 |
| decisions | 1902409408 | 9448 |
| sl-attempts | 43219517 | 78 |
| run-config | 1861635 | 15 |
| run-plans | 8525649 | 77 |
| brain | 669280871 | 481 |
| runs | 347705 | 15 |
| fight-plans | 2233957 | 0 |

fight-plans零入选只表示该截点未选到，不断言原日志缺失。源流扫描的无效JSON行保留在manifest计数，未纳入证据；不推断它们属于本批。各流独立截点，不声称同一时间原子快照。

## 可核的结论与限制

- 狡诈原九局42饮：37次添3、两次添2、三次添0，每次实耗瓶；新增刀升级、基础Damage6。确定生成已有live源码，保留/穿插/跨重问/SL恢复及完整后继仍未联合认证。
- WQZVENQ7DTRP F33第2/3次T9实损13/22、敌净扣24/39；末次T7另有损4换沙坑末值4→5、敌净扣仍24的约束。不从这些局部差额拟合新SL门槛。
- TXZ6RVMQA09D F48第2/3次T6少损3也少扣9，末次首胜4血，F49可操作前4→0。四血开场和连续目标已有子实现，仍缺两战完整受控替线。
- NHA2KW0RB7VP F33首四试T1实损1、末两试损7，敌净扣8→24；必须从30血/敌408的就绪帧开始，不能混入28血/敌428的开场过渡。
- KEN七次饮药、两次实际营火回复，1913与Q6的赢战后资源链都可逐帧核；它们没有不用/早用/留药或替代路线的完整成对结果。不能据失败资源链校准新药价/终局/路线权重。

上述结论只复核原限定观察，没有发现需要推翻旧经验的新反证，也没有新增胜率或因果收益结论。全部十项的具体waiting理由和原账本id逐项保存在proposal.md/result.json，不整包登记duplicate。

## 源码与验证

读取时live为 `a9e687d9f0acccccddbfa92895d7966b58900658`。已有确定子实现及诊断的实际祖先已核：

| 内容 | 实际源码提交 |
| --- | --- |
| 狡诈生成/容量 | 6403fdcdadc803a092beb5165a068e22bf51c412 |
| 普通紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 |
| 四血开场实际集成 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| 后续开场组合扩展 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 |
| SL当轮预测差额诊断 | 5604982e13890e0e2bc8bf8246272e8267321c0b |
| 诊断未知/饱和边界补齐 | 1698adc96ba434a46942321e0237b70657e625b2 |
| 碾碎爪取整窄分支 | ec29ea34b919344b707e57ba472ea210f9c39d62 |

早期王室猛毒原提交fc7042d1非base/live祖先，未用于登记implemented。12源码叶8叶同live，另4叶只有Roy/Dai历史注释差，保留原字节补丁。此核验不是自然采用或完整校准。

生产检查未运行：tsc=null、vitest=null、cases=null；没有新增源码，撤源码失败/恢复通过不适用。八项固定证据检查通过，输出evidence-checks.json；这是原数据一致性核验，不是生产测试或整战模拟。未运行play、LLM、游戏API、网络或Boss模拟池。

## 过程修正与留存

第一次只按时间找药水前帧会错配同回合的前一选择状态；第一次NHA回合摘要也包含未就绪开场。原草稿以 `.v1.txt` 保留，最终改为完全fingerprint绑定、就绪帧端点，八项检查均用修正结果。两个早期只读结构探针的StopIteration/NoneType失败保留在原转录，未作为日志缺失或产品代码故障。生产源码未因这些过程问题改变。

主要材料：dispatch-binding.json、assigned-proposals.json、十份original.md、run-identities.json、evidence/、evidence-verification.json、floor-resources.json、turn-endpoints.json、numeric-comparisons.json、cunning-42-drinks.json、potion-action-pairs.json、source-ancestry.json、selected-silent-experience.json、evidence-checks.json。源码工作树差异source-worktree.diff.patch为空。

没有新代码提案或游戏规则，无需新版本/双通知/回退。本批仅给既有31账本增加CLI追溯；根专用代码提案队列状态留给调度器按最终proposal_results登记，不手改learn.json或旧父请求。等待项保留待新局重派；宽学习要求、实际经验入库、消费者读回及量化收益均未关闭。

import bisect
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def dump(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(raw):
    return {p.get("power_id"): p.get("amount") for p in raw.get("powers", [])}


def compact(x):
    row = x["row"]
    state = row["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": x["line"], "offset": x["offset"], "sha256": x["sha256"],
        "ts": row["ts"], "run": x["run_id"], "floor": run.get("floor"),
        "screen": state.get("screen"), "turn": state.get("turn"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "block": player.get("block"), "energy": player.get("energy"),
        "powers": powers(player), "cards_played": player.get("cards_played_this_turn"),
        "readiness": combat.get("action_readiness"),
        "hand": [{k: c.get(k) for k in ["index", "card_id", "upgraded", "energy_cost", "dynamic_values"]}
                 for c in combat.get("hand", [])],
        "potions": [{k: p.get(k) for k in ["index", "potion_id", "occupied", "usage"]}
                    for p in run.get("potions", [])],
        "relics": [r.get("relic_id") for r in run.get("relics", [])],
        "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"), "hp": e.get("current_hp"),
                     "alive": e.get("is_alive"), "block": e.get("block"), "move": e.get("move_id"),
                     "powers": powers(e), "intents": e.get("intents")}
                    for e in combat.get("enemies", [])],
    }


def verify():
    result = []
    for path in sorted((HERE / "evidence").glob("*.evidence.jsonl")):
        counts = collections.Counter()
        handles = {}
        digest = hashlib.sha256()
        total = 0
        try:
            for encoded in path.open("rb"):
                digest.update(encoded)
                x = json.loads(encoded)
                handle = handles.setdefault(x["source"], None)
                if handle is None:
                    handle = handles[x["source"]] = open(x["source"], "rb")
                handle.seek(x["offset"])
                raw = handle.read(x["bytes"])
                assert hashlib.sha256(raw).hexdigest() == x["sha256"], x["line"]
                assert json.loads(raw) == x["row"], x["line"]
                assert extract.run_identity(x["row"]) == x["run_id"], x["line"]
                counts[x["run_id"]] += 1
                total += 1
        finally:
            for handle in handles.values():
                if handle:
                    handle.close()
        result.append({"stream": path.name, "rows": total, "counts": dict(counts),
                       "output_sha256": digest.hexdigest(), "raw_bytes_identity_verified": True})
    dump("evidence-verification.json", result)


def analyze():
    states = collections.defaultdict(list)
    fingerprints = collections.defaultdict(lambda: collections.defaultdict(list))
    full = {}
    for line in (HERE / "evidence/states.evidence.jsonl").open():
        x = json.loads(line)
        fingerprints[x["run_id"]][x["row"]["fingerprint"]].append(len(states[x["run_id"]]))
        states[x["run_id"]].append(compact(x))
        if x["line"] in set(range(281563, 281567)) | set(range(282330, 282337)) | set(range(282887, 282893)) | {282075, 282144, 283400, 283422}:
            full[str(x["line"])] = x
    dump("selected-original-frames.json", full)
    turns = []
    floors = []
    focus = {"TXZ6RVMQA09D": {43, 45, 46, 48, 49}, "WQZVENQ7DTRP": {33},
             "NHA2KW0RB7VP": {17, 19, 30, 33}, "Q6M2Y34MWKRE": {2, 8, 9},
             "1913SE84AXQF": {17, 24, 28, 29, 31}, "KEN58SH9SLZ6": set(range(1, 18)),
             "K3676LU8B0UH": {30}, "SADL3CGYTGSR": {45}}
    for run, frames in states.items():
        floor_groups = collections.defaultdict(list)
        turn_groups = collections.OrderedDict()
        attempt = 1
        prev = None
        for f in frames:
            floor_groups[f["floor"]].append(f)
            if f["screen"] != "COMBAT" or f["turn"] is None:
                continue
            if prev and f["floor"] == prev["floor"] and f["turn"] < prev["turn"]:
                attempt += 1
            if prev and f["floor"] != prev["floor"]:
                attempt = 1
            prev = f
            key = (f["floor"], attempt, f["turn"])
            turn_groups.setdefault(key, []).append(f)
        for floor, fs in floor_groups.items():
            cs = [f for f in fs if f["screen"] == "COMBAT"]
            floors.append({"run": run, "floor": floor, "first": fs[0], "last": fs[-1],
                           "combat_first": cs[0] if cs else None, "combat_last": cs[-1] if cs else None})
        for (floor, attempt, turn), fs in turn_groups.items():
            if floor in focus.get(run, set()):
                actionable = [f for f in fs if (f.get("readiness") or {}).get("can_use_combat_actions") is True
                              and (f.get("readiness") or {}).get("snapshot_stable") is True
                              and (f.get("readiness") or {}).get("local_turn_ready") is True]
                turns.append({"run": run, "floor": floor, "attempt": attempt, "turn": turn,
                              "first": actionable[0] if actionable else fs[0], "first_is_actionable": bool(actionable),
                              "last": fs[-1], "frame_lines": [f["line"] for f in fs]})
    dump("floor-resources.json", floors)
    dump("turn-endpoints.json", turns)
    timestamps = {r: [f["ts"] for f in fs] for r, fs in states.items()}
    drinks = []
    sl = []
    for line in (HERE / "evidence/decisions.evidence.jsonl").open():
        x = json.loads(line)
        row = x["row"]
        intent = row.get("chosen") or row.get("intent") or {}
        action = intent.get("action") or row.get("action")
        if action == "use_potion":
            run = x["run_id"]
            matches = [i for i in fingerprints[run].get(row.get("fingerprint"), [])
                       if states[run][i]["ts"] <= row["ts"]]
            k = matches[-1] if matches else None
            drinks.append({"line": x["line"], "offset": x["offset"], "sha256": x["sha256"],
                           "row": row, "pairing": "exact decision/state fingerprint; next observed frame",
                           "before": states[run][k] if k is not None else None,
                           "after": states[run][k + 1] if k is not None and k + 1 < len(states[run]) else None})
        if row.get("sl_explore") or (row.get("log") or {}).get("sl_explore"):
            sl.append(x)
    dump("potion-action-pairs.json", drinks)
    dump("sl-decision-records.json", sl)
    print(json.dumps({"states": {r: len(fs) for r, fs in states.items()}, "drinks": len(drinks),
                      "sl_decisions": len(sl), "selected_frames": len(full)}, ensure_ascii=False))


if __name__ == "__main__":
    verify()
    analyze()

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261016-044302'
SCRATCH = ROOT / 'learner/runs/20261016-044306-b7b6f90b-cbb2-4eb7-8ee7-5d096e290623-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-033023-e2d7f781-af89-4983-b97b-9d0e3226048d-fix-batch/audit.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, head):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', commit, head], cwd=WORK).returncode == 0


prior = json.loads(PRIOR.read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / '.worktrees/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert sha(queue) == prior['queue_sha256'], 'Queue changed; inspect the new entries'
assert not git('status', '--porcelain').strip()
files = []
for old in prior['current_files']:
    path = old['path']
    assert not Path(path).name.endswith('.env') and Path(path).name != '.env'
    current = (WORK / path).read_bytes()
    assert sha(current) == old['sha256'], path
    files.append({'path': path, 'sha256': sha(current), 'same_as_prior': True})
source_changes = git('diff', '--name-only', prior['base'], base, '--',
                     'agent', 'learner', 'ops', 'eval', 'knowledge/builders').decode().splitlines()
assert source_changes == ['ops/inbox-dev.md'], source_changes
fixes = []
for fix in prior['existing_fixes'] + prior['additional_existing_fixes']:
    commit = fix['source_commit']
    in_base, in_live = ancestor(commit, base), ancestor(commit, live)
    assert in_base and in_live, (fix['item'], commit)
    fixes.append({'item': fix['item'], 'source_commit': commit,
                  'ancestor_in_base': in_base, 'ancestor_in_live': in_live})
gamble = 'b49112dbc106e315bd7156361d290fc4c73d29e2'
snakebite = '5b56a452bb9be14d620b368ec46974c1b57901ca'
for name, commit in [('silent-0317：已观察A10升级计算下注子项', gamble),
                     ('silent-0319：已观察A10两费十毒预览子项', snakebite)]:
    assert ancestor(commit, base) and ancestor(commit, live), (name, commit)
    fixes.append({'item': name, 'source_commit': commit,
                  'ancestor_in_base': True, 'ancestor_in_live': True,
                  'scope': '仅既有已观察模板；未知费用、附魔、其他进阶及更宽组合仍由原策略链核验'})
lines = queue.decode().splitlines()
dispositions = []
for old in prior['queue_dispositions']:
    assert lines[old['line'] - 1] == old['item']
    item = dict(old)
    item['verification'] = '本批核当前381叶SHA完全相同、原来源为base/live祖先，另读相关实现及固定测试；未将历史测试结果当本批验收。'
    if item['line'] == 923:
        item.update(disposition='已覆盖已观察A10升级手牌模板子项；其他输入沿原策略链',
                    commit=gamble,
                    scope='card-model.ts的upgradedGamble与discardsHand/drawDiscardedHand；固定AYTX5H4H69E3 F45 T1，不声称已复原旧HEM完整dirty树')
    if item['line'] == 929:
        item.update(disposition='已覆盖已观察A10两费十毒模板子项；A6及未知组合保持原边界',
                    commit=snakebite,
                    scope='card-model.ts的upgradedSnakebite；固定VLZ6CCT8AQ0A A10 F43 T1/T5为预览配对，不将未施放升级牌当实际伤害；原e27dbda源码经5b56a452实际集成，e27本身不是base/live祖先')
    dispositions.append(item)
assert len(dispositions) == sum(line.startswith('- [ ]') for line in lines)
extra_paths = ['agent/tests/silent-calculated-gamble-upgraded.test.ts',
               'agent/tests/silent-calculated-gamble-upgraded-evidence.json',
               'agent/tests/silent-apotheosis-snakebite.test.ts',
               'agent/tests/silent-apotheosis-snakebite-evidence.json']
out = {
    'base': base, 'live_read_only_snapshot': live,
    'prior_audit': str(PRIOR), 'prior_audit_sha256': sha(PRIOR.read_bytes()),
    'prior_base': prior['base'], 'queue_sha256': sha(queue), 'queue_lines': len(lines),
    'queue_unchanged': True, 'unchecked_entries': len(dispositions),
    'existing_fixes': fixes, 'unique_source_paths': len(files), 'current_files': files,
    'additional_reviewed_files': [{'path': p, 'sha256': sha((WORK / p).read_bytes())} for p in extra_paths],
    'changed_paths_since_prior_base': source_changes,
    'change_review': '仅ops/inbox-dev.md有10行既有运维记录变化；核验范围内源码/固定测试/版本381叶完全相同。',
    'queue_dispositions': dispositions,
    'limits': [
        '没有新修复，不创建空提交或空合入，不登记版本或shipped。',
        'live只读核祖先；未宣称live全部叶与main相同。',
        '策略/游戏题面知识沿原独立提案；不重复登记或派下级。',
        '0332完整resources/steps及机制根因、目录生命周期与历史发送事实仍未知。',
        '两项旧升级模板已有窄实现，纠正本批处置，不改前批报告或关闭宽父项。',
        '首轮审计将原e27dbda误作实际祖先而拒绝；保留audit.log/audit.stderr，更正为真实集成5b56a452；不是产品或测试失败。',
    ],
}
(SCRATCH / 'audit.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'queue-snapshot.md').write_bytes(queue)
(SCRATCH / 'source.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--',
    'agent/src', 'agent/tests', 'learner', 'ops', 'eval', 'knowledge/builders'))
print(json.dumps({k: out[k] for k in ('base', 'live_read_only_snapshot', 'queue_lines',
      'unchecked_entries', 'unique_source_paths', 'changed_paths_since_prior_base')}, ensure_ascii=False))
print('既有来源祖先核验：', len(fixes))

import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
SCRATCH = ROOT / 'learner/runs/20261016-044306-b7b6f90b-cbb2-4eb7-8ee7-5d096e290623-fix-batch'
WORK = ROOT / '.worktrees/codex-fix-silent-20261016-044302'
PRIOR = ROOT / 'learner/runs/20261016-033023-e2d7f781-af89-4983-b97b-9d0e3226048d-fix-batch/report.md'
audit = json.loads((SCRATCH / 'audit.json').read_text())
prior_text = PRIOR.read_text()
prior_result = json.loads(re.search(r'```json\n(.*?)\n```', prior_text, re.S)[1])
labels = {}
for line in prior_text.splitlines():
    match = re.match(r'\| (\d+) \| ([^|]+) \|', line)
    if match:
        labels[int(match[1])] = match[2].strip()
assert len(labels) == audit['unchecked_entries']
assert (SCRATCH / 'tsc.exit').read_text().strip() == '0'
assert (SCRATCH / 'vitest.exit').read_text().strip() == '0'
vitest_log = (SCRATCH / 'vitest.log').read_text()
assert re.search(r'Test Files\s+12 passed \(12\)', vitest_log)
assert re.search(r'Tests\s+90 passed \(90\)', vitest_log)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK).decode().strip() == audit['base']
assert hashlib.sha256((ROOT / 'notes/fix-queue-v4.md').read_bytes()).hexdigest() == audit['queue_sha256']

verification = {
    'tsc': 0, 'vitest': 0, 'files': 12, 'cases': 90, 'retried': False,
    'tsc_command': 'nice -n 19 npx tsc -p tsconfig.json --noEmit',
    'vitest_command': 'nice -n 19 npx vitest run --pool=threads --maxWorkers=1 '
        'tests/learner-startup-recovery.test.ts tests/learner-launch-failures.test.ts '
        'tests/learner-entry.test.ts tests/learner-registration-barrier.test.ts '
        'tests/ledger-publication-baseline.test.ts tests/silent-paper-krane.test.ts '
        'tests/target-options.test.ts tests/feature-notice-registration.test.ts '
        'tests/boss-sim-notice-registration.test.ts tests/silent-paper-krane-beam.test.ts '
        'tests/silent-calculated-gamble-upgraded.test.ts tests/silent-apotheosis-snakebite.test.ts',
    'full_sandbox_suite_run': False,
    'reason': '无源码改动或新提交；本次只运行类型检查与相关固定回归，不宣称完整沙箱或宿主套件通过。',
    'without_fix_check': '不适用：没有新增修复，未撤既有源码；历史红绿结果不当本批结果。',
    'environment': 'TMPDIR仅指定scratch；本地Node/npm离线；不继承CHARACTER；nice19/单worker；Python字节码关闭。',
    'read_errors': '两次只读定位使用了不存在的路径；首轮审计错误要求原e27dbda必须为祖先，被断言拒绝，已更正为真实集成5b56a452。audit.stderr保留；均非测试重跑或产品失败。',
}
(SCRATCH / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
skipped = [item for item in prior_result['skipped']
           if not item['item'].startswith(('silent-0317', 'silent-0319'))]
for item in skipped:
    if item['item'].startswith('sandbox-glob-startup-race'):
        item['reason'] = '证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。'
    if item['item'] in {'arch-funnel-guard', 'arch-learning-priority', 'arch-unified-resource-value', 'inv-f33-regression'}:
        item['reason'] = '太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。'
result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': skipped,
    'merged': None, 'tests': {'tsc': 0, 'vitest': 0, 'cases': 90},
    'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md'),
}
covered = [item for item in audit['queue_dispositions'] if item.get('commit') or item.get('commits')]
waiting = [item for item in audit['queue_dispositions'] if item not in covered]
assert len(covered) == 18 and len(waiting) == 24
body = [
    '## 修 bug 回报',
    '',
    f"- 合并基线：main → {audit['base']}（开工工作区干净；git merge --no-edit main 返回 Already up to date）。",
    '- 修复（每条一行）：无新增纯 bug 修复；未创建提交，fixes=[]；撤源码红绿验证不适用。',
    '- 已被别人修掉的：42条未勾选记录中18条已修或有明确窄覆盖；逐条提交见下表。77项既有来源引用对应76个独立提交，均已核本批base和只读live祖先。',
    '- 没修的：24条未勾选策略/框架/证据不足项逐条见下表，另保留6项非勾选宽范围；不派下级、不重复登记已有策略提案。',
    '- 测试：tsc退出码0；vitest定向12文件/90用例/退出码0，未重跑。无新源码或提交，未运行完整test-sandbox.sh。',
    '- 合入：未合入（merged=null）；本批无新增源码，不空合并、不改live刷新数据、不造发布号。',
    '- 需要 Roy 定的事（没有写「无」）：无。',
    '',
    f"队列{audit['queue_lines']}行，SHA256 {audit['queue_sha256']}；与前批逐字节相同。381个已核路径的当前SHA全部与前批相同；基线以来相关目录唯一变化是ops/inbox-dev.md的10行既有运维记录，source.diff保留。另读升级计算下注、蛇咬固定测试及其证据夹具。",
    '',
    f"只读live快照为{audit['live_read_only_snapshot']}。祖先核验不表示当前live所有叶与main相同；本批没有写live、获取合并锁、登记上线或更新账本。",
    '',
    '| 队列行 | 条目 | 当前处置/提交 |',
    '|---|---|---|',
]
for item in audit['queue_dispositions']:
    commits = item.get('commits', [item['commit']] if item.get('commit') else [])
    body.append(f"| {item['line']} | {labels[item['line']]} | {item['disposition']}" +
                ('；' + '、'.join(commits) if commits else '') + ' |')
body += [
    '',
    '0317已有b49112dbc的限定A10升级手牌模板：card-model的upgradedGamble接入discardsHand/drawDiscardedHand。本批9项固定回归覆盖AYTX5H4H69E3/F45T1；未知文本/其他进阶保持旧模型。不能把该窄覆盖扩成旧HEM整棵dirty运行树或所有升级来源已验收。',
    '',
    '0319已有5b56a452实际集成的A10两费十毒模板。原e27dbda不在base/live祖先链，本批首轮审计因此拒绝；改用实际祖先5b56a452，并保留首轮audit.stderr。新增读回6项固定回归以VLZ6CCT8AQ0A/F43T1/T5预览配对为准，不把未施放升级牌当实伤，不把A6或未知组合也记已修。前批报告原文不回写。',
    '',
    '非勾选记录及既有窄实现之外的范围：',
]
for item in skipped:
    if any(item['item'] == labels[d['line']] for d in waiting):
        continue
    if item not in prior_result['skipped'][-6:]:
        continue
    body.append(f"- {item['item']} — {item['reason']}")
body += [
    '',
    'silent-0481当前selection.ts仍有“only for this turn”生命周期措辞，原silent-proposal-686d4e759478eebb仍归独立策略链；不能用刀舞模型的窄修复冒称本项已修。silent-0487当前card-model.ts仍仅读CalculatedHits/Repeat，未认ViolenceHits；原silent-proposal-0a0b31e284e6793e沿独立策略链处理，不由本纯工具批引入三段攻击知识。',
    '',
    'silent-0332当前continuationInput仍要求成功首战有正HP资源，诊断可区分nonpositive-hp；RQ F40/F48完整resources/steps及机制根因仍缺，不能靠删契约或捏造正HP修复。silent-0311库存问题沿既有d2f24919策略链，2LZHP9BYFTHE正确证据是F37T1/4/10，原运维F38误写及勘误保留。',
    '',
    '既有修复/限定子项来源（只确认原范围，不关闭宽父项）：',
    '',
    '| 条目 | 实际祖先提交 |',
    '|---|---|',
]
for item in audit['existing_fixes']:
    body.append(f"| {item['item']} | {item['source_commit']} |")
body += [
    '',
    '只写本批scratch。未改代码、队列、知识、账本、提案队列、版本或上线记录；无新修复不追加bug-infra状态，不登记implemented/shipped。无真实LLM或网络调用；未停对局、运行play、推送或修改账号/模型/权限/prompt。',
    '',
    '验证证据：audit.py/audit.json、queue-snapshot.md、source.diff、tsc.log/tsc.exit、vitest.log/vitest.exit、verification.json。首轮审计拒绝保留audit.stderr，成功结果在audit-2.log。本报告生成前重核队列SHA、HEAD与工作区均保持。',
    '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
]
(SCRATCH / 'report.md').write_text('\n'.join(body))
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'covered_unchecked': len(covered),
                  'waiting_unchecked': len(waiting), 'skipped': len(skipped),
                  'tests': result['tests']}, ensure_ascii=False))

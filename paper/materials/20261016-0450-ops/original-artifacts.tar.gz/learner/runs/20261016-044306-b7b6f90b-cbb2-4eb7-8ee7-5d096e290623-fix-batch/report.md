## 修 bug 回报

- 合并基线：main → 38a1f2e4d59f9582bf78e562aeecd39e1dd11375（开工工作区干净；git merge --no-edit main 返回 Already up to date）。
- 修复（每条一行）：无新增纯 bug 修复；未创建提交，fixes=[]；撤源码红绿验证不适用。
- 已被别人修掉的：42条未勾选记录中18条已修或有明确窄覆盖；逐条提交见下表。77项既有来源引用对应76个独立提交，均已核本批base和只读live祖先。
- 没修的：24条未勾选策略/框架/证据不足项逐条见下表，另保留6项非勾选宽范围；不派下级、不重复登记已有策略提案。
- 测试：tsc退出码0；vitest定向12文件/90用例/退出码0，未重跑。无新源码或提交，未运行完整test-sandbox.sh。
- 合入：未合入（merged=null）；本批无新增源码，不空合并、不改live刷新数据、不造发布号。
- 需要 Roy 定的事（没有写「无」）：无。

队列1344行，SHA256 fa01d7cc3df396919bac965182819e0a08bb3f819c9d7ce04f2c24ec1f6270c8；与前批逐字节相同。381个已核路径的当前SHA全部与前批相同；基线以来相关目录唯一变化是ops/inbox-dev.md的10行既有运维记录，source.diff保留。另读升级计算下注、蛇咬固定测试及其证据夹具。

只读live快照为e716bd28fd8eca9e4d76d066680304fd11935e37。祖先核验不表示当前live所有叶与main相同；本批没有写live、获取合并锁、登记上线或更新账本。

| 队列行 | 条目 | 当前处置/提交 |
|---|---|---|
| 784 | silent-0254：无动作死亡战斗归因 | 已修或已覆盖窄子项；不关闭更宽父项；3b48088dec5fc6eafe576a1296bbdadde43432ee |
| 789 | silent-0256：狡诈药水已观察容量子项 | 已修或已覆盖窄子项；不关闭更宽父项；6403fdcdadc803a092beb5165a068e22bf51c412 |
| 793 | silent-0260：普通紧勒逐牌失血 | 已修或已覆盖窄子项；不关闭更宽父项；5c7105ff0294466da8319f2934beda05c6040794 |
| 797 | silent-0263：已观察转向取整子项 | 已修或已覆盖窄子项；不关闭更宽父项；ec29ea34b919344b707e57ba472ea210f9c39d62 |
| 801 | silent-0266：SL投斧首牌身份 | 已修或已覆盖窄子项；不关闭更宽父项；e784dd9f043bf87c29109573f48975f9903280d3 |
| 810 | silent-0271：毒必胜提前返回遗漏保血候选 | 策略类/沿原独立提案，宽父保持 |
| 817 | silent-0272：商店移除预览核对现场选牌 | 已修：移除预览核对实际选牌页；db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26 |
| 831 | silent-0279：SL抽序升级改标 | 策略类/沿原独立提案，宽父保持 |
| 900 | rollout最佳线固定夹具确定性 | 已修：rollout最佳线固定夹具确定性；bbc5b993a7524bbb8e80a975f204f8d193657b46 |
| 912 | silent-0308：沙坑截止结束题面 | 策略类/沿原独立提案，宽父保持 |
| 918 | silent-0311：库存恢复血量预算 | 策略类/沿原独立提案，宽父保持 |
| 923 | silent-0317：升级全弃手牌分支 | 已覆盖已观察A10升级手牌模板子项；其他输入沿原策略链；b49112dbc106e315bd7156361d290fc4c73d29e2 |
| 929 | silent-0319：升级蛇咬分支 | 已覆盖已观察A10两费十毒模板子项；A6及未知组合保持原边界；5b56a452bb9be14d620b368ec46974c1b57901ca |
| 930 | silent-0320：同线新建UNMOVABLE | 策略类/沿原独立提案，宽父保持 |
| 935 | silent-0322：升级神化同线升级 | 策略类/沿原独立提案，宽父保持 |
| 940 | silent-0324：普通刀舞生成小刀 | 已修或已覆盖窄子项；不关闭更宽父项；66c22ba7d87b8748690a4183fff838acd346bd3e |
| 945 | silent-0329：饮药临时力量接线 | 策略类/沿原独立提案，宽父保持 |
| 952 | arch-funnel-guard | 策略类/沿原独立提案，宽父保持 |
| 953 | arch-learning-priority | 策略类/沿原独立提案，宽父保持 |
| 954 | arch-unified-resource-value | 策略类/沿原独立提案，宽父保持 |
| 955 | inv-f33-regression | 策略类/沿原独立提案，宽父保持 |
| 959 | silent-0332：成功首战接续nonpositive-hp | 证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知 |
| 964 | silent-0334：升级隐秘匕首模型 | 策略类/沿原独立提案，宽父保持 |
| 968 | silent-0338：回合末格挡来源注记 | 已修或已覆盖窄子项；不关闭更宽父项；c1d84804956bedbd29a7f0e81294114e18415b9d |
| 980 | silent-0339：尾巴误核销 | 策略类/沿原独立提案，宽父保持 |
| 992 | silent-0344：坚韧之环延迟格挡 | 策略类/沿原独立提案，宽父保持 |
| 1001 | silent-0347：组装师攻击召唤 | 策略类/沿原独立提案，宽父保持 |
| 1005 | silent-0349：已有虚弱后的减力 | 策略类/沿原独立提案，宽父保持 |
| 1009 | core-build-notify-222802-rc2：历史发送事实 | 证据不足：后续诊断已修，原历史发送事实未知 |
| 1020 | silent-0362：背向攻击减力倍率 | 策略类/沿原独立提案，宽父保持 |
| 1022 | silent-0365：未建模药水目标可达性 | 策略类/沿原独立提案，宽父保持 |
| 1024 | silent-0367：已用尾巴事实接线 | 已修或已覆盖窄子项；不关闭更宽父项；5baf663d7e6678efa3690e5a48329c4f8baee109 |
| 1029 | codex-usage-credit-baseline-recovery | 已修或已覆盖窄子项；不关闭更宽父项；5b56a452bb9be14d620b368ec46974c1b57901ca |
| 1034 | ascension-up：目标进阶误作实际进阶 | 已修：目标/实际进阶分开；8045d9fbf0a12523b1dbe39bbed8af06c7497b09 |
| 1040 | 框架外层时限与分段续验收尾 | 太大/独立框架：精确续验入口已实现，宿主收尾范围继续 |
| 1041 | 调度公平性核查 | 证据不足：未证明永久饥饿，沿原框架核查 |
| 1110 | host-fixed-test-timeouts-010547：eval/Apotheosis固定夹具 | 已修：eval/Apotheosis固定输入及有界夹具；d9881ba593b0b8d701ebbe1c95626c0ebdd554c7、9e8c93555131c3347f9e809d9722a848a75c2692 |
| 1294 | silent-0481：技能药水生命周期措辞 | 策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项 |
| 1304 | infra-target-options-fixed-fixture-timeout | 已修或已覆盖窄子项；不关闭更宽父项；bae9c45ccffefb284a1c6634526c8768a9f5f7a8 |
| 1308 | infra-ledger-status-prefix-git-divergence | 已修或已覆盖窄子项；不关闭更宽父项；dd478f0b3e5a0f234f082972d21b203dbf8229d7 |
| 1322 | infra-learner-launch-shared-main-config-race | 已修或已覆盖窄子项；不关闭更宽父项；22efae55484bc2bdcc54e847a8dc40bb4888c4e2 |
| 1344 | silent-0487：MAD_SCIENCE三段攻击模型 | 策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。 |

0317已有b49112dbc的限定A10升级手牌模板：card-model的upgradedGamble接入discardsHand/drawDiscardedHand。本批9项固定回归覆盖AYTX5H4H69E3/F45T1；未知文本/其他进阶保持旧模型。不能把该窄覆盖扩成旧HEM整棵dirty运行树或所有升级来源已验收。

0319已有5b56a452实际集成的A10两费十毒模板。原e27dbda不在base/live祖先链，本批首轮审计因此拒绝；改用实际祖先5b56a452，并保留首轮audit.stderr。新增读回6项固定回归以VLZ6CCT8AQ0A/F43T1/T5预览配对为准，不把未施放升级牌当实伤，不把A6或未知组合也记已修。前批报告原文不回写。

非勾选记录及既有窄实现之外的范围：
- codex大脑缓存命中偏低 — 证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。
- sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因 — 证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。
- named-card-facts-transport：事件入口之外范围 — 太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。
- boss模拟样本性能及v5-dpr-health宽范围 — 太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。
- rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。
- silent-0469：纸鹤其他未知组合/整战收益 — 策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。

silent-0481当前selection.ts仍有“only for this turn”生命周期措辞，原silent-proposal-686d4e759478eebb仍归独立策略链；不能用刀舞模型的窄修复冒称本项已修。silent-0487当前card-model.ts仍仅读CalculatedHits/Repeat，未认ViolenceHits；原silent-proposal-0a0b31e284e6793e沿独立策略链处理，不由本纯工具批引入三段攻击知识。

silent-0332当前continuationInput仍要求成功首战有正HP资源，诊断可区分nonpositive-hp；RQ F40/F48完整resources/steps及机制根因仍缺，不能靠删契约或捏造正HP修复。silent-0311库存问题沿既有d2f24919策略链，2LZHP9BYFTHE正确证据是F37T1/4/10，原运维F38误写及勘误保留。

既有修复/限定子项来源（只确认原范围，不关闭宽父项）：

| 条目 | 实际祖先提交 |
|---|---|
| silent-0254：无动作死亡战斗归因 | 3b48088dec5fc6eafe576a1296bbdadde43432ee |
| codex-usage-credit-baseline-recovery：额度窗口恢复基线 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| ascension-up：请求进阶误报为实际进阶 | 8045d9fbf0a12523b1dbe39bbed8af06c7497b09 |
| infra-target-options-fixed-fixture-timeout | bae9c45ccffefb284a1c6634526c8768a9f5f7a8 |
| infra-ledger-status-prefix-git-divergence | dd478f0b3e5a0f234f082972d21b203dbf8229d7 |
| infra-legacy-continuation-notice-ack-identity | 368fccabd42eb72ffcea9a2fe6cbbb7c149326be |
| infra-paper-krane-recorded-line-timeout | befc39e5ca0105f8ff96d47f817df44f0b2760f1 |
| infra-learner-event-log-second-collision | b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f |
| strategy-proposal：报告 scratch 归属 | 5f04139cefe5c651dd5bf62f7e164014dbf5f23b |
| silent-0459：独立 run-plan 请求成本漏计 | 799a5cd0caf9329b43c32376079218a9bd0c3e9e |
| run-plan 证据提取未识别 run 字段 | 78e9b05929366d097a728761d693d790ff16ac87 |
| postmortem-capacity-failure-proposal-repair-20261013 | 3fdcd77927f01b35c20c6c5c1fcfd790676032d2 |
| blocked-experience-proposal-repair-dispatch | 84366ad06ee4f978394c1b9489a82c83ea12bd36 |
| learning-notice-ordinary-ack-registry-20261013：普通 ACK | 672e198a4730012330f599068a0ef1efadb02002 |
| learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 | 1594def2e1b65b665d3b345f31444194eb4d09e6 |
| learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 | 15eb85e2934e428c5e299fc4a1aba456d92fd685 |
| feature 通知来源身份校验 | 38b2f572d90b3b97a23f9eae983f583287492f9a |
| feature/B4 通知来源桥接 | 1dd4d434aef67f1d065dbdba23a875ae82741a88 |
| batch-f：包装/参数化测试超时静态解析 | 56c256dad0d33b231b82b53113d3bdd84f9bfa20 |
| unassigned-strategy-proposal-resolution | 3a98e213a826e94f9708af4b1a265e1892659f4e |
| host-fixed-test-timeouts-010547：eval 固定历史输入 | d9881ba593b0b8d701ebbe1c95626c0ebdd554c7 |
| host-fixed-test-timeouts-010547：Apotheosis 有界夹具 | 9e8c93555131c3347f9e809d9722a848a75c2692 |
| compute-memo-worker-data-signature | 8fbb441eb61eef226eb7366f9612003480c83988 |
| rollout-live-best-test-determinism | bbc5b993a7524bbb8e80a975f204f8d193657b46 |
| host-targeted-check-continuation：已过覆盖的精确续验入口 | 24c2e3a75b5db6bac76d6c924f86b7fcd9438316 |
| sandbox-glob-startup-race：会话前有界恢复 | bc2c40e313cc36682196277c53c50e30744b88c5 |
| sandbox-glob-startup-race：复盘租约绑定 | d9983263ffecea1bed4e29d65e7f854a3d2e33d7 |
| core-cycle-implementation-binding-entry | fc95760d4ff8a9cbd45577efdd79b1215bd2cb92 |
| ops-20261012-quantitative-continuation | b408252f87a77ee5389c4d90e52a9831c0873348 |
| named-card-facts-transport：已批准的事件入口子项 | 42c920f34d9dc1c783ce894659849ab37ed6fd1b |
| core-build-notify-222802-rc2：保留原生失败诊断子项 | 5c92f2aaf0b758a1a5e7d591745694004664f83a |
| paper-dataset-git-consistency-race | 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f |
| boss-sim-codex-home-preflight | 5921f8cd045853182c867a6430e75c3fcde00a87 |
| shared-experience-fixed-filesystem-snapshot-20261013 | 8390c62d76fc8c7d7b6b7292121a621f4666d39c |
| silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） | ec8c578b66bf5498372f1b779ae58a766dff8112 |
| ops-stall-recovery-test-subprocess-timeout：首项异步夹具 | 95e7f050ef2abe5c85a0367555392652ad73fbfe |
| ops-stall-recovery-test-subprocess-timeout：固定失败诊断 | 9b6459fd99f26b17689134e33aa85d6190e71d7d |
| batch-c-fixed-fixture-timeout | 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff |
| 晚写复盘误计为上线后重犯 | 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39 |
| 学习账本 first_run/asc/prior_note 追加更正 | 87c89b7aea90c7275e0fbb04b1e4148a4209630c |
| subscription-usage：未设置 TMPDIR | 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a |
| deepseek-prompt-dump：状态日志反向流式扫描 | 6ee8e2a2c1edc31492962137b96af8c6e1d12093 |
| 固定药水测试隔离 | e78352f784d39cf25671446348daaada6ef2060b |
| 单次 mod 超时 stall 误报 | a4f4ec868d122dc92af510862c6240cf2eaff2b6 |
| 学习状态锁被完整检查阻塞 | 233ede56047274ba53a4e1191a245fac816c37a8 |
| 学习者受阻后兜底完整检查入口 | f670884a188a047bbd3f7f007c260ade62fae36a |
| 策略任务及自动派发入口 | afd652a3f75df6e7403439f01c565220327884da |
| 旧事件选项重复问大脑 | 25ce09bee5576b1adff8baf196fbe8b197a5ef11 |
| silent-0153：普通隐秘匕首生成分支 | b7f081fcc26da4506cb775739bb118cb6cbe4ecc |
| silent-0256：已观察的狡诈药水容量子项（实际源码提交） | 6403fdcdadc803a092beb5165a068e22bf51c412 |
| silent-0260：普通紧勒逐牌失血 | 5c7105ff0294466da8319f2934beda05c6040794 |
| silent-0263：已观察的碾碎爪转向取整子项 | ec29ea34b919344b707e57ba472ea210f9c39d62 |
| silent-0266：SL 首牌身份 | e784dd9f043bf87c29109573f48975f9903280d3 |
| silent-0272：商店移除预览与真实选牌页核对 | db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26 |
| silent-0324：普通刀舞生成小刀 | 66c22ba7d87b8748690a4183fff838acd346bd3e |
| silent-0338：回合末防御事实来源注记 | c1d84804956bedbd29a7f0e81294114e18415b9d |
| silent-0367：已用蜥蜴尾巴事实接线 | 5baf663d7e6678efa3690e5a48329c4f8baee109 |
| infra-learner-launch-shared-main-config-race | 22efae55484bc2bdcc54e847a8dc40bb4888c4e2 |
| host-loop-time-cap-wall-clock-061301：固定时间夹具 | b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa |
| host-loop-time-cap-wall-clock-061301：续验拒绝诊断 | 63f656fb07a21a7496353234269901a832eae497 |
| ops-worktree-history-disk-pressure：broker容量/回执失败隔离 | a136ddc4b5b0a8696f10b2fae3073322d57e724c |
| ops-worktree-history-disk-pressure：无终态标记退出 | db072ddab47ba94efb46dce2913927f936ecb97e |
| ops-worktree-history-disk-pressure：JSONL追加边界 | 9b07240b18f862efdbe630889ade04e8976eaace |
| ops-worktree-history-disk-pressure：历史副本/按需恢复 | c7a6efb1e15ed6c5f31a35ae3ee9833863340393 |
| tracked-source Python缓存回收认定 | 1e8af775f6b90f100f20ff7c4a08dfddaba893a9 |
| 完成报告裸JSON兼容 | 6f86ff6b6b971fb38b96308ebdd34dec574e5b13 |
| autoplay安全热交接动作 | 71b835a3150704548fab2ad46e74bde240ccf1f9 |
| 历史测试入口漏传日志回调 | ccd8bb8e017da9c30b408138d04e6d2bc985836d |
| 额度警告固定测试契约 | 1cf0490492bd8a430b85f95f3fdee91eba251191 |
| 有限结束报告与补验交接 | 2c4ce406c9ae598835f22292e52cfd936ac10b14 |
| host-checks-broker-push-registration | c519952b31e3a0bb3acdd2115883ae8671b8a090 |
| host-checks-session-exit-fixture | 874ae603b3927173f805e0b2fe789330bab710c7 |
| v5-dpr-health：明确不支持的候选被误计为DPR交付失败（仅分类子项） | 9e6dd82a34fb8c14e012be68fd0b632544f1459f |
| sandbox-glob-startup-race：父注册事务保存屏障 | 798af209b9a268b7dafab1440150f1b39cd5595d |
| silent-0469：已观察聚合体纸鹤组合子项 | 8d386fc7668820c2fc387d966f9d94bdcab189fb |
| silent-0317：已观察A10升级计算下注子项 | b49112dbc106e315bd7156361d290fc4c73d29e2 |
| silent-0319：已观察A10两费十毒预览子项 | 5b56a452bb9be14d620b368ec46974c1b57901ca |

只写本批scratch。未改代码、队列、知识、账本、提案队列、版本或上线记录；无新修复不追加bug-infra状态，不登记implemented/shipped。无真实LLM或网络调用；未停对局、运行play、推送或修改账号/模型/权限/prompt。

验证证据：audit.py/audit.json、queue-snapshot.md、source.diff、tsc.log/tsc.exit、vitest.log/vitest.exit、verification.json。首轮审计拒绝保留audit.stderr，成功结果在audit-2.log。本报告生成前重核队列SHA、HEAD与工作区均保持。

```json
{
  "task": "fix-batch",
  "base": "38a1f2e4d59f9582bf78e562aeecd39e1dd11375",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0271：毒必胜提前返回遗漏保血候选",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0279：SL抽序升级改标",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0308：沙坑截止结束题面",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0311：库存恢复血量预算",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0320：同线新建UNMOVABLE",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0322：升级神化同线升级",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0329：饮药临时力量接线",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-funnel-guard",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-learning-priority",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-unified-resource-value",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "inv-f33-regression",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "silent-0332：成功首战接续nonpositive-hp",
      "reason": "证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知"
    },
    {
      "item": "silent-0334：升级隐秘匕首模型",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0339：尾巴误核销",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0344：坚韧之环延迟格挡",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0347：组装师攻击召唤",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0349：已有虚弱后的减力",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足：后续诊断已修，原历史发送事实未知"
    },
    {
      "item": "silent-0362：背向攻击减力倍率",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0365：未建模药水目标可达性",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "框架外层时限与分段续验收尾",
      "reason": "太大/独立框架：精确续验入口已实现，宿主收尾范围继续"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：未证明永久饥饿，沿原框架核查"
    },
    {
      "item": "silent-0481：技能药水生命周期措辞",
      "reason": "策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项"
    },
    {
      "item": "silent-0487：MAD_SCIENCE三段攻击模型",
      "reason": "策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。"
    },
    {
      "item": "codex大脑缓存命中偏低",
      "reason": "证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。"
    },
    {
      "item": "sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因",
      "reason": "证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外范围",
      "reason": "太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。"
    },
    {
      "item": "boss模拟样本性能及v5-dpr-health宽范围",
      "reason": "太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。"
    },
    {
      "item": "silent-0469：纸鹤其他未知组合/整战收益",
      "reason": "策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 90
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-044306-b7b6f90b-cbb2-4eb7-8ee7-5d096e290623-fix-batch/report.md"
}
```

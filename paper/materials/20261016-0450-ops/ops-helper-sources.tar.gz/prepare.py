from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0450';pub=root/'paper/materials/20261016-0450-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],input=data,stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-044302-fix-batch';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='skipped'}=={k:v for k,v in report.items() if k!='skipped'}
assert len(scratch['skipped'])==len(report['skipped'])==30
assert [x['item'].split('：')[0] for x in scratch['skipped']]==[x['item'].split('：')[0] for x in report['skipped']]
assert b['state']=='failed' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors']
assert report['fixes']==report['code_proposals']==report['implementation_domains']==[] and report['merged'] is None and report['tests']==dict(tsc=0,vitest=0,cases=90)
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base']==base and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
assert not git('diff','--binary',report['base'],cwd=b['worktree']).strip()
verification=load(s/'verification.json');assert verification['tsc']==verification['vitest']==0 and verification['files']==12 and verification['cases']==90 and verification['retried'] is False and verification['full_sandbox_suite_run'] is False
assert (s/'tsc.exit').read_text().strip()==(s/'vitest.exit').read_text().strip()=='0'
assert 'Test Files  12 passed (12)' in (s/'vitest.log').read_text() and 'Tests  90 passed (90)' in (s/'vitest.log').read_text()
assert 'nice -n 19' in verification['tsc_command'] and 'nice -n 19' in verification['vitest_command'] and '--maxWorkers=1' in verification['vitest_command']
audit=load(s/'audit.json');prior_path=Path(audit['prior_audit']);assert prior_path.is_relative_to(root)
prior_raw=prior_path.read_bytes();assert sha(prior_raw)==audit['prior_audit_sha256'];prior=json.loads(prior_raw)
assert audit['base']==report['base'] and audit['prior_base']==prior['base'] and audit['queue_unchanged']
queue=(s/'queue-snapshot.md').read_bytes();lines=queue.splitlines(keepends=True)
assert sha(queue)==audit['queue_sha256']==prior['queue_sha256'] and len(lines)==audit['queue_lines']==prior['queue_lines']==1344
assert (root/'notes/fix-queue-v4.md').read_bytes().startswith(queue)
dispositions=audit['queue_dispositions'];assert audit['unchecked_entries']==len(dispositions)==42 and sum(x.startswith(b'- [ ]') for x in lines)==42
for x in dispositions:assert lines[x['line']-1].decode().rstrip('\r\n')==x['item']
assert sum(bool(x.get('commit') or x.get('commits')) for x in dispositions)==18
assert len(audit['existing_fixes'])==77 and len({x['source_commit'] for x in audit['existing_fixes']})==76
for fix in audit['existing_fixes']:
    assert fix['ancestor_in_base'] and fix['ancestor_in_live']
    git('merge-base','--is-ancestor',fix['source_commit'],report['base']);git('merge-base','--is-ancestor',fix['source_commit'],audit['live_read_only_snapshot'])
rejected='e27dbda2f8c7bb8cfbb0c9e8043dfe34cd298801';integration='5b56a452bb9be14d620b368ec46974c1b57901ca'
assert rejected in (s/'audit.stderr').read_text() and (s/'audit-2.stderr').read_bytes()==b''
for head in [report['base'],audit['live_read_only_snapshot']]:assert subprocess.run(['git','merge-base','--is-ancestor',rejected,head],capture_output=True).returncode==1
assert next(x for x in dispositions if x['line']==929)['commit']==integration
leaves={row['path']:row for row in prior['current_files']};current={row['path']:row for row in audit['current_files']}
assert set(current)==set(leaves) and len(current)==audit['unique_source_paths']==381
extra={x['path']:x for x in audit['additional_reviewed_files']};assert len(extra)==4
all_paths=sorted(set(current)|set(extra));assert all(not path.endswith(('.env','.dll','.pck')) and 'auth.json' not in path and not path.startswith('third_party/') for path in all_paths)
changes=git('diff','--name-only',prior['base'],report['base'],'--','agent','learner','ops','eval','knowledge/builders').decode().splitlines()
assert changes==audit['changed_paths_since_prior_base']==['ops/inbox-dev.md']
assert (s/'source.diff').read_bytes()==git('diff','--binary',prior['base'],report['base'],'--','agent/src','agent/tests','learner','ops','eval','knowledge/builders')
requests=[(commit,path) for path in all_paths for commit in [report['base'],audit['live_read_only_snapshot']]]
raw=git('cat-file','--batch',data=''.join(commit+':'+path+'\n' for commit,path in requests).encode());handle=io.BytesIO(raw);blobs={}
for key in requests:
    header=handle.readline().rstrip(b'\n').split()
    if header[-1:]==[b'missing']:blobs[key]=None;continue
    assert header[1]==b'blob';size=int(header[2]);value=handle.read(size);assert len(value)==size and handle.read(1)==b'\n';blobs[key]=value
assert handle.read()==b'';absent=[];different=[]
for path in all_paths:
    a=blobs[(report['base'],path)];z=blobs[(audit['live_read_only_snapshot'],path)]
    row=current.get(path,extra.get(path));assert a is not None and sha(a)==row['sha256'] and (Path(b['worktree'])/path).read_bytes()==a
    if path in current:assert current[path]['same_as_prior'] and current[path]['sha256']==leaves[path]['sha256']
    if z is None:absent.append(path)
    elif a!=z:different.append(path)
versions=json.loads(blobs[(report['base'],'eval/versions.json')]);releases=[x for x in versions['versions'] if x.get('release_id')=='V5-R365']
assert len(releases)==1 and releases[0]['commit']=='52495248f983fe8ba4b98ec1e626fb94a79e2aa5'
assert git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==audit['live_read_only_snapshot']
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_state=b['state'],original_rc=b['rc'],original_report=report,original_scratch_report=scratch,stdout_skip_reasons_abbreviated=True,skip_count_boundary='42 unchecked queue entries:18 covered subitems and24 remaining;30 report skips include those24 and6 additional broad scopes.',native=native,unchanged_clean_worktree=True,no_new_fix_or_merge_block=True,original_audit=audit,prior_raw_reference=dict(path=str(prior_path.relative_to(root)),sha256=sha(prior_raw)),source381_and_four_reviewed_files_base_blobs_verified=True,source_diff_is_historical_records_not_current_worktree_delta=True,source_references=77,unique_ancestor_commits=76,rejected_nonancestor=rejected,actual_snakebite_integration=integration,existing_release=releases[0],live_absent_paths=absent,live_different_paths=different,original_verification=verification,no_production_tests_reexecuted=True,limits=['Original failed/rc0/mergednull retained; no source commit or merge is claimed.','Upgraded Gamble and Snakebite limited observed A10 templates already existed; this batch adds no gameplay model or wider coverage.','Original nonancestor assertion rejection and corrected actual integration retained; not a product or test failure.','Source ancestry does not imply base/live leaf equality or broad-parent completion.','0332 resource/steps tails, notification send history, directory lifecycle and fairness remain unknown; original owners remain.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([x for x in s.iterdir() if x.is_file()]+[out,out.with_suffix('.err'),prior_path]):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0450原044302-fix空修复核收，原failed/rc0/mergednull保持；38a1干净WT/HEAD不变，无新增源码或提交合入受阻，不空合/发号/复派。42未勾队列字节与前批1344行SHA相同，18已有窄覆盖及24原链待查分列，机器30 skipped另含六宽范围；升级计算下注b49112与升级蛇咬5b56a452仅原已观察A10模板，不关闭宽父或混其他进阶。77原来源引用对应76独立提交的base/live祖先核，381当前base叶与前批全同，另四固定测试/证据叶blob核；source.diff只有既有ops/inbox十行历史记录，当前WTdiff为空。e27dbda非base/live祖先引发首轮审计拒绝及更正实际集成5b56a452成功原件保留，不回写旧报告或当产品/测试失败；祖先不冒逐叶同一，live缺叶{len(absent)}/差叶{len(different)}另列。原tsc0、12文件90定向0/nice19单worker/无重跑/非full原件核，不借当宿主全检或再补测。原路径猜测只读错误保留；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。0332资源尾根因、历史通知发送、目录生命周期与公平性仍未知沿原owner；0481/0487及纸鹤宽范围保持策略链。仅本人记录提交，无源码/知识/账本/队列/论文刷新/对局重启或账号home模型额度权限prompt操作。证据paper/materials/20261016-0450-ops/。\n'
note=f'\n- {at} [运维 codex] 原044302修复批次无新增源码或合入受阻，原failed/rc0保持；原类型检查与12文件90项定向通过，未跑完整套件。42项队列中18已有窄覆盖、24项及六宽范围沿原链；非祖先审计失败及真实集成更正原件保留，无新发布或补测。回执paper/materials/20261016-0450-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,original_state=b['state'],rc=0,source_references=77,unique_ancestor_commits=76,base_source_leaves=381,unchanged_source_leaves=381,additional_reviewed_leaves=4,queue_entries=42,covered_subitems=18,remaining_entries=24,additional_broad_scopes=6,original_tsc=0,original_targeted_files=12,original_targeted_cases=90,original_targeted_exit=0,no_new_fix_commit_merge_release=True,no_tests_reexecuted=True,record_only=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(paths=len(entries),references=77,unique_commits=76,leaves=381,no_new_source=True)))

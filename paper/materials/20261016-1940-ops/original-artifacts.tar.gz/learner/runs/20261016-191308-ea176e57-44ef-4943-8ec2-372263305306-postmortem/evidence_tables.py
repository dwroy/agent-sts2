import json,collections
from pathlib import Path
p=Path(__file__).parent

def ix(n):return [(i['line'],x) for i,x in zip(map(json.loads,(p/(n+'-index.jsonl')).open()),map(json.loads,(p/(n+'.jsonl')).open()))]
ss=ix('states');ds=ix('decisions');rs=json.loads((p/'DQSH393WPZW0-resources.json').read_text())
for w in rs['combats']:
 obs=w['enemy_hp_audit']['turns'];fr=[(n,x) for n,x in ss if w['entry']['line']<=n<=(w['exit'] or w['last'])['line']]
 groups=[]
 for n,x in fr:
  s=x['state']
  if not groups or groups[-1][0]!=s['turn']:groups.append((s['turn'],[]))
  groups[-1][1].append((n,x))
 loss=[];need=[];progress=[];endblock=[]
 for i,(t,group) in enumerate(groups):
  first=group[0][1]['state'];last=group[-1][1]['state'];nxt=groups[i+1][1][0][1]['state'] if i+1<len(groups) else last
  need.append(sum(e['current_hp'] for e in (first.get('combat') or {}).get('enemies',[]) if e['is_alive']))
  lastneed=sum(e['current_hp'] for e in (nxt.get('combat') or {}).get('enemies',[]) if e['is_alive'])
  progress.append(need[-1]-lastneed)
  loss.append(first['run']['current_hp']-nxt['run']['current_hp']);endblock.append(((last.get('combat') or {}).get('player') or {}).get('block'))
 print('F',w['floor'],'seq',w['sequence'],'need',need,'net enemy pool change',progress,'hp loss',loss,'visible lowerbound',[(x['turn'],x['visible_enemy_hp_loss_lower_bound'],x.get('gaps')) for x in obs])
print('FINALE frames')
for attempt,w in enumerate([c for c in rs['combats'] if c['floor']==33],1):
 fr=[(n,x['state']) for n,x in ss if w['entry']['line']<=n<=w['last']['line']]
 seen=set()
 for n,s in fr:
  hand=(s.get('combat') or {}).get('hand',[])
  f=next((a for a in hand if a['card_id']=='GRAND_FINALE'),None)
  if not f or s['turn'] in seen:continue
  seen.add(s['turn']);draw=(s.get('agent_view') or {}).get('run',{}).get('piles',{}).get('draw',[])
  count=sum(len(a.get('card_ids',[])) for a in draw)
  print(attempt,n,s['turn'],'playable',f['playable'],'draw rows',len(draw),'idcount',count,'text',f.get('resolved_rules_text'))
print('POTION before/after')
for n,d in ds:
 if d.get('chosen',{}).get('action')=='use_potion':
  before=[(sn,x) for sn,x in ss if x['ts']==d['ts']]
  # Decisions ts is pre-action frame timestamp; resource updates find immediate successor.
  if not before:before=[(sn,x) for sn,x in ss if x['ts']<=d['ts']][-1:]
  sn,x=before[-1];idx=next(i for i,(v,_) in enumerate(ss) if v==sn)
  an,after=ss[idx+1]
  e=lambda s:[(v['enemy_id'],v['current_hp'],[(a['power_id'],a['amount']) for a in v.get('powers',[])]) for v in (s.get('combat') or {}).get('enemies',[])]
  print(n,d['floor'],d.get('sl_attempt'),d['turn'],d['expect'].get('potion'),sn,an,after['ts'],e(x['state']),e(after['state']))

import json,collections
from pathlib import Path
p=Path(__file__).parent

def indexed(n):return [(i['line'],x) for i,x in zip(map(json.loads,(p/(n+'-index.jsonl')).open()),map(json.loads,(p/(n+'.jsonl')).open()))]
ss=indexed('states');ds=indexed('decisions')
r=json.loads((p/'DQSH393WPZW0-resources.json').read_text())
for w in r['combats']:
 print('\nF',w['floor'],'seq',w['sequence'],'entry',w['entry']['hp'],'exit',None if w['exit'] is None else w['exit']['hp'])
 frames=[(n,x) for n,x in ss if w['entry']['line']<=n<=w['last']['line']]
 if w['exit']:frames+=[(n,x) for n,x in ss if n==w['exit']['line']]
 groups=[]
 for n,x in frames:
  if not groups or groups[-1][0]!=x['state']['turn']:groups.append((x['state']['turn'],[]))
  groups[-1][1].append((n,x))
 def brief(s):
  c=s.get('combat') or {};pl=c.get('player') or {}
  return {'HP':s['run']['current_hp'],'block':pl.get('block'),'E':pl.get('energy'),'power':[(v['power_id'],v['amount']) for v in pl.get('powers',[])],'enemy':[(v['enemy_id'],v['current_hp'],[(z['power_id'],z['amount']) for z in v.get('powers',[])],[(z.get('damage'),z.get('hits')) for z in v.get('intents',[])]) for v in c.get('enemies',[])]}
 for j,(t,rows) in enumerate(groups):
  first=rows[0];last=rows[-1]
  # ready and stable first real hand; empty setup frames remain source.
  ready=next(((n,x) for n,x in rows if (x['state'].get('combat') or {}).get('hand')),first)
  after=groups[j+1][1][0] if j+1<len(groups) else last
  print('T',t,'s',first[0],ready[0],last[0],'first',brief(ready[1]['state']),'last',brief(last[1]['state']),'nextHP',after[1]['state']['run']['current_hp'])
  actions=[(n,d) for n,d in ds if d.get('floor')==w['floor'] and d.get('turn')==t and first[1]['ts']<=d['ts']<=last[1]['ts']]
  print('ACT',[(n,d.get('expect'),d.get('rationale')) for n,d in actions])

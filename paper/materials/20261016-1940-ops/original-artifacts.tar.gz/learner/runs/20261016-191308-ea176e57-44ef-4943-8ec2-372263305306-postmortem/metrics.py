import json,collections,re,datetime
from pathlib import Path
p=Path(__file__).parent

def ix(n):return [(i['line'],x) for i,x in zip(map(json.loads,(p/(n+'-index.jsonl')).open()),map(json.loads,(p/(n+'.jsonl')).open()))]
ds=ix('decisions');ss=ix('states');bs=ix('brain')
jev=[(n,x) for n,x in ds if x.get('decider')=='jev'];plan=[(n,x) for n,x in jev if x.get('label','').startswith('combat/plan-choice')]
seed=[(n,x) for n,x in ds if x.get('decider')=='code' and x.get('label') in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]
window=lambda x:(x['floor'],x.get('sl_attempt') or 1,x.get('turn'))
jw={window(x) for n,x in jev if x.get('label','').startswith('combat/')}
sw={window(x) for n,x in seed}
metrics={'jev':len(jev),'low_conf':[(n,x['floor'],x.get('sl_attempt'),x.get('turn'),x['confidence']) for n,x in jev if isinstance(x.get('confidence'),(int,float)) and x['confidence']<.35], 'plans':len(plan),'rollout_best':dict(collections.Counter(x.get('rollout_best_chosen') for n,x in plan)), 'code_rank_1':sum('code rank 1' in x.get('rationale','') for n,x in plan),'seed_count':len(seed),'seed_labels':dict(collections.Counter(x['label'] for n,x in seed)),'seed_windows':len(sw),'seed_only_windows':len(sw-jw),'all_combat_windows':len(sw|jw),'fallback':sum(x.get('fallback') is True for n,x in ds),'seed_results':dict(collections.Counter(str(x.get('result')) for n,x in seed)),'sl_explore':[(n,x.get('sl_attempt'),x.get('turn'),x.get('rationale')) for n,x in ds if 'SL explore' in x.get('rationale','')],'usage_jev':{k:sum(x.get('usage',{}).get(k,0) or 0 for n,x in jev) for k in ['input_tokens','output_tokens','cache_hit_tokens']},'brain_engines':dict(collections.Counter('|'.join(str(x.get(k)) for k in ['engine','model','effort','accepted']) for n,x in bs)),'brain_usage':{k:sum(x.get('usage',{}).get(k,0) or 0 for n,x in bs) for k in set().union(*(x.get('usage',{}).keys() for n,x in bs))},'jev_latency_ms':sum((x.get('latency_ms') or {}).get('jev',0) or 0 for n,x in jev),'brain_latency_ms':sum(x.get('latency_ms',0) or 0 for n,x in bs)}
metrics['duration_sec']=(datetime.datetime.fromisoformat(ds[-1][1]['ts'])-datetime.datetime.fromisoformat(ds[0][1]['ts'])).total_seconds()
metrics['continued_jev']=sum(x['label']=='combat/plan-continue' and 'Jev-chosen' in x.get('rationale','') for n,x in ds)
metrics['guards']=[(n,{k:v for k,v in x.items() if 'guard' in k or 'override' in k},x.get('rationale')) for n,x in ds if any('guard' in k or 'override' in k for k in x) or 'guard' in x.get('rationale','').lower()]
focus=[]
for n,x in plan:
 c=x.get('questions',{}).get('plan',{}).get('criteria',{})
 parsed={}
 for k,v in c.items():
  try:z=json.loads(v)
  except (ValueError,TypeError):continue
  if isinstance(z,dict):parsed[k]=z
 choices={k:z.get('focus') for k,z in parsed.items() if z.get('focus')}
 if choices:
  pick=x.get('answers',{}).get('plan',{}).get('choice');focus.append((n,x['floor'],pick,choices.get(pick),choices))
metrics['focus']=focus
(p/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n')
for k,v in metrics.items():print(k,json.dumps(v,ensure_ascii=False) if k not in ['sl_explore','focus'] else ('count='+str(len(v))+' '+json.dumps(v[:3],ensure_ascii=False)))
print('CRITERIA SUMMARIES')
for n,x in ds:
 if n in [413810,413825,413943,414015,414019,414027,414033,414011]:
  print('D',n,'fields',list(x))
  for q,v in x.get('questions',{}).items():
   choice=x.get('answers',{}).get(q,{}).get('choice');print('choice',choice)
   for key,text in v.get('criteria',{}).items():
    try:z=json.loads(text)
    except (TypeError,ValueError):continue
    out={k:z[k] for k in ['plays','hp_lost','dmg','damage_dealt','hp_after','rollout','whole_fight_sim','simulated'] if k in z}
    if isinstance(z.get('quantitative_fight'),dict):
     f=z['quantitative_fight'];out['fight']={k:f[k] for k in ['samples','damage_hp','simulated_turns','effective_damage_per_turn'] if k in f}
    if q=='plan' or key in ['card1','skip','o0']:print(key,json.dumps(out,ensure_ascii=False))

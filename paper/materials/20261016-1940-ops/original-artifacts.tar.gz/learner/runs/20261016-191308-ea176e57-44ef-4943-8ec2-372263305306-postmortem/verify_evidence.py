import json,re,hashlib,datetime,subprocess
from pathlib import Path
p=Path(__file__).parent; root=p.parents[2]
def ix(n):return [(i['line'],x) for i,x in zip(map(json.loads,(p/(n+'-index.jsonl')).open()),map(json.loads,(p/(n+'.jsonl')).open()))]
ds=dict(ix('decisions'));ss={n:x['state'] for n,x in ix('states')}
rs=json.loads((p/'DQSH393WPZW0-resources.json').read_text());m=json.loads((p/'metrics.json').read_text())
assert len(ds)==676 and len(ss)==697 and len(rs['combats'])==20
assert len(m['low_conf'])==27 and m['rollout_best']=={'true':181,'false':7,'null':2} and m['guards']==[]
assert [(c['floor'],c['entry']['hp'],None if c['exit'] is None else c['exit']['hp']) for c in rs['combats'][:14]]==[(2,70,70),(3,70,66),(4,66,66),(5,66,60),(6,60,53),(8,53,20),(13,70,49),(14,49,49),(17,74,52),(19,77,68),(20,68,60),(22,60,38),(24,38,21),(28,71,18)]
assert all(c['entry_is_turn_one'] and c['entry']['max_hp']==84 for c in rs['combats'])
assert all(c['exit'] is None for c in rs['combats'][14:19])
assert [(c['last']['hp'],c['last']['turn']) for c in rs['combats'][14:]]==[(10,7),(5,9),(4,9),(8,9),(16,7),(8,7)]
assert ss[427722]['combat']['player']['block']==15 and ss[427722]['run']['current_hp']==8
assert ss[427722]['combat']['enemies'][0]['intents'][0]['total_damage']==24
assert ss[427722]['combat']['enemies'][0]['current_hp']==131
assert ss[427723]['combat']['enemies'][0]['current_hp']==98 and ss[427723]['run']['current_hp']==0
assert ss[427721]['run']['relics'][5]['relic_id']=='TUNING_FORK' and ss[427721]['run']['relics'][5]['stack']==10
assert ss[427719]['run']['relics'][5]['stack']==9
counts={}
for n in [427520,427698,427618,427655]:
 draw=ss[n]['agent_view']['run']['piles']['draw'];counts[n]=sum(int(re.search(r'\*(\d+)\s*\[',a['line']).group(1)) if re.search(r'\*(\d+)\s*\[',a['line']) else 1 for a in draw)
assert counts=={427520:13,427698:16,427618:8,427655:8}
finale=[(n,c) for n,s in ss.items() for c in (s.get('combat') or {}).get('hand',[]) if c['card_id']=='GRAND_FINALE']
assert len(finale)==33 and all(c['playable'] is False for n,c in finale)
assert not any(d.get('expect',{}).get('card',{}).get('id')=='GRAND_FINALE' and d['chosen']['action']=='play_card' for d in ds.values())
assert (ss[427631]['run']['current_hp'],ss[427635]['run']['current_hp'],ss[427631]['combat']['enemies'][0]['current_hp'],ss[427635]['combat']['enemies'][0]['current_hp'])==(61,40,287,266)
assert (ss[427700]['run']['current_hp'],ss[427704]['run']['current_hp'],ss[427700]['combat']['enemies'][0]['current_hp'],ss[427704]['combat']['enemies'][0]['current_hp'])==(61,35,287,257)
assert ds[414019]['sl_explore']['candidate_comparison']['delta_replacement_minus_original']=={'hp_loss':5,'damage':9,'block_gained':-5,'strength_gained':0}
power=lambda s,id:next((v['amount'] for v in s['combat']['enemies'][0]['powers'] if v['power_id']==id),0)
for a,b,before,after in [(427540,427541,39,45),(427582,427583,18,24),(427621,427622,34,40),(427658,427659,37,43),(427690,427691,12,18),(427721,427722,27,33)]:
 assert power(ss[a],'POISON_POWER')==before and power(ss[b],'POISON_POWER')==after
 assert ss[a]['combat']['enemies'][0]['current_hp']==ss[b]['combat']['enemies'][0]['current_hp']
assert len([d for d in ds.values() if d.get('chosen',{}).get('action')=='use_potion'])==14
assert not any(d.get('chosen',{}).get('action')=='discard_potion' for d in ds.values())
# Re-read the original log records by their byte offsets; never scan whole large files into memory.
verified={}
for name in ['runs','decisions','states','brain','run-plans','sl-attempts']:
 indices=[json.loads(l) for l in (p/(name+'-index.jsonl')).open()]
 with (root/'logs'/(name+'.jsonl')).open('rb') as original:
  for i in indices:
   original.seek(i['offset']);raw=original.read(i['bytes'])
   assert hashlib.sha256(raw).hexdigest()==i['sha256'],(name,i['line'])
 verified[name]=len(indices)
for n,s in ss.items():
 if n in [427719,427722,427723,427700,427704]:print('原帧复核',n,'HP',s['run']['current_hp'],'挡',s['combat']['player']['block'],'敌HP',s['combat']['enemies'][0]['current_hp'],'毒',power(s,'POISON_POWER'),'沙坑',power(s,'SANDPIT_POWER'))
result={'原日志逐偏移SHA核对':verified,'收场折叠行展开张数':counts,'资源窗口':len(rs['combats']),'关键断言':'全部通过','新纯bug':[]}
(p/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

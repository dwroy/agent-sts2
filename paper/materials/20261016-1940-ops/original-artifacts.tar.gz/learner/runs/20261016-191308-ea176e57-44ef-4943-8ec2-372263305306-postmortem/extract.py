import json, hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261016-191308-ea176e57-44ef-4943-8ec2-372263305306-postmortem'
needle=b'DQSH393WPZW0'
for name in ['runs','decisions','run-plans','sl-attempts','brain','states']:
    source=root/'logs'/f'{name}.jsonl'
    if not source.exists():
        print(name,'missing',flush=True);continue
    count=0; offset=0; limit=source.stat().st_size
    with source.open('rb') as h,(out/f'{name}.jsonl').open('wb') as d,(out/f'{name}-index.jsonl').open('w') as ix:
        for line_no,line in enumerate(h,1):
            start=offset;offset+=len(line)
            if offset>limit:break
            if needle not in line:continue
            row=json.loads(line)
            actual=row.get('run_id') or row.get('run') or (row.get('state') or {}).get('run_id')
            if actual!='DQSH393WPZW0':continue
            count+=1;d.write(line)
            ix.write(json.dumps({'line':line_no,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'ts':row.get('ts')})+'\n')
    print(name,count,'cutoff',limit,flush=True)
ds=[json.loads(x) for x in (out/'decisions.jsonl').open()]
start=min(x['ts'] for x in ds);end=max(x['ts'] for x in ds)
count=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as h,(out/'deepseek-reasoning-window.jsonl').open('wb') as d:
    for line in h:
        row=json.loads(line)
        if start<=str(row.get('ts',''))<=end:d.write(line);count+=1
print('decision-window',start,end,'deepseek-reasoning',count,flush=True)

import json,collections
from pathlib import Path
p=Path(__file__).parent

def rows(n):return [json.loads(l) for l in (p/(n+'.jsonl')).open()]
def indexed(n):return [(i['line'],x) for i,x in zip(rows(n+'-index'),rows(n))]
ds=indexed('decisions'); ss=indexed('states')
r=json.loads((p/'DQSH393WPZW0-resources.json').read_text())
print('COMBATS')
for c in r['combats']:
    e=c['entry'];l=c['last'];x=c['exit'];print(c['sequence'],c['floor'],c['enemies'],'entry',e,'last',l,'exit',x,'end',c['end'])
print('RESOURCE CHANGES')
for x in r['resource_changes']:
    a=x['from'];b=x['to'];print('s%d→s%d F%sT%s %s→%s max%s→%s pot%s→%s seq%s restart%s %s'%(a['line'],b['line'],b['floor'],b['turn'],a['hp'],b['hp'],a['max_hp'],b['max_hp'],a['potions'],b['potions'],x['combat_sequence'],x['restart_boundary'],b['ts']))
print('SL')
for n,x in indexed('sl-attempts'):
    print(n,{k:x.get(k) for k in ['floor','attempt','started_at','ended_at','result','turns','end_hp','end_block','incoming','judge','reload','give_up_reason']})
    print('summary',x.get('summary'))
print('SAMPLES')
for label in ['combat/plan-choice+potion','combat/play','combat/plan','selection/choose']:
    n,x=next((n,x) for n,x in ds if x['floor']==33 and x['label']==label)
    print('d',n,'keys',list(x),'sample',json.dumps(x,ensure_ascii=False)[:26000])
print('STATES HEAD/TAIL')
for n,x in [ss[1],next((n,x) for n,x in ss if x['state']['run']['floor']==33),ss[-2],ss[-1]]:
    s=x['state'];print('s',n,json.dumps(s,ensure_ascii=False)[:22000])

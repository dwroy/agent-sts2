import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
def rows(name):
 for ln in (p/(name+'.lines')).open():
  n,s=ln.split(':',1);r=json.loads(s);r['_line']=int(n);yield r
D=list(rows('decisions'));S=list(rows('states'));B=list(rows('brain'));R=json.load((p/'4Z2GCLA4DU52-resources.json').open())
for b in B:
 if b['_line'] not in [15223,15229,15232,15237]:continue
 q=b['payload'];print('B',b['_line'])
 rr=q.get('route_review') or {};pf=rr.get('plan_facts') or {};print('arrival',pf.get('arrival'),'nextrest',rr.get('next_rest'))
 facts=q.get('facts') or {};print('sim', {k:v for k,v in (facts.get('act_boss_sim') or {}).items() if k in ['boss','entry_hp','current_deck','samples']})
 if b['_line']==15229:
  x=json.loads(b['options']['o0']);print('HEAL', {k:v for k,v in x.items() if k in ['boss_sim','boss_relative_margin','quantitative_fight']})
 if b['_line']==15237: print('shopentry',facts.get('hp'))
for w in R['combats']:
 print('win audit',w['floor'],w['sequence'],[(t['turn'],t.get('gaps')) for t in w['enemy_hp_audit']['turns'] if t.get('gaps')])
print('enemynames',sorted({(e['name'],e['enemy_id']) for s in S for e in (s['state'].get('combat') or {}).get('enemies',[])}))
print('focus questions')
for d in D:
 pairs=[]
 for q in (d.get('questions') or {}).values():
  for k,v in (q.get('criteria') or {}).items():
   if isinstance(v,str):
    try:v=json.loads(v)
    except:continue
   if isinstance(v,dict) and v.get('focus') is not None:pairs.append([k,v['focus']])
 if pairs and d['floor']==24:print(d['_line'],pairs)
for x in S:
 if x['_line'] in [424599,424600,424610,424611,424614,424615,424642,424816,424817,424820,424821,424825,424837,424841,424851,424857,424858,424860]:
  s=x['state'];print('state',x['_line'],'T',s['turn'],'player',(s.get('combat') or {}).get('player'),'enemies',[(e['enemy_id'],e['current_hp'],[(z['power_id'],z['amount']) for z in e['powers']]) for e in (s.get('combat') or {}).get('enemies',[])])

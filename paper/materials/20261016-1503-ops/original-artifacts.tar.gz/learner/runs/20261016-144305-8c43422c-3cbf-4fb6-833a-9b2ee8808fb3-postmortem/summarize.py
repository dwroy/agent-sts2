exec(open(__file__.replace('summarize.py','inspect.py')).read().split("D=list(rows('decisions'))")[0])
D=list(rows('decisions'));S=list(rows('states'))
R=json.load((p/'4Z2GCLA4DU52-resources.json').open())
for name,items in [('resources',R['resource_changes']),('sl',list(rows('sl-attempts')))]:
 with (p/(name+'-summary.txt')).open('w') as out:
  for x in items:
   if name=='sl':x={k:v for k,v in x.items() if k not in ['draws','explore','judge','summary'] }|{'summary':x.get('summary')}
   out.write(json.dumps(x,ensure_ascii=False)+'\n')
with (p/'combat-summary.txt').open('w') as out:
 for d in D:
  if not d['label'].startswith('combat/') and d['label'] not in ['sl/reload','sl/give-up']:continue
  if d['decider']=='code' and 'continuing the Jev' in d.get('rationale',''):continue
  sa=d.get('selection_audit') or {}
  out.write(f"d{d['_line']} F{d['floor']}T{d['turn']} attempt={d.get('sl_attempt')} {d['label']} {d['decider']} c={d.get('confidence')} best={d.get('rollout_best_chosen')} {d.get('rationale')} "+json.dumps({'turn':(sa.get('answer') or {}).get('turn'),'sl_delta':sa.get('sl_delta'),'chosen':d.get('chosen')},ensure_ascii=False)+'\n')
with (p/'noncombat-summary.txt').open('w') as out:
 for d in D:
  if d['decider']=='codex':out.write(f"d{d['_line']} F{d['floor']} {d['label']} {d['rationale']}\n")
with (p/'turns.txt').open('w') as out:
 for w in R['combats']:
  states=[r for r in S if r['_line']>=w['entry']['line'] and r['_line']<=(w.get('exit') or w['last'])['line']]
  ts={}
  for r in states:
   if r['state'].get('in_combat'):ts.setdefault(r['state']['turn'],[]).append(r)
  out.write(f"F{w['floor']} seq{w['sequence']}\n")
  for t,rs in ts.items():
   first=rs[0];nxt=next((z for z in states if z['_line']>rs[-1]['_line']),rs[-1]);s=first['state'];ns=nxt['state']
   enemies=s['combat']['enemies'];e2=(ns.get('combat') or {}).get('enemies')
   need=sum(e['current_hp'] for e in enemies if e['is_alive'])
   after=None if e2 is None else sum(e['current_hp'] for e in e2 if e['is_alive'])
   out.write(json.dumps({'t':t,'s':first['_line'],'end':nxt['_line'],'hp':[s['run']['current_hp'],ns['run']['current_hp']],'need':need,'after':after,'enemy':[[e.get('enemy_id'),e['current_hp'],e.get('block'),e.get('intents'),e.get('powers')] for e in enemies]},ensure_ascii=False)+'\n')
print('done')
print('combat keys',S[3]['state'].get('combat',{}).keys())
for x in rows('sl-attempts'):
 print('sl',x['_line'],{k:x.get(k) for k in ['floor','attempt','result','started_at','ended_at','turns','end_hp','end_block','incoming','give_up_reason','reload']})

import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
def rows(name):
 for ln in (p/(name+'.lines')).open():
  n,s=ln.split(':',1);r=json.loads(s);r['_line']=int(n);yield r
D=list(rows('decisions'));S=list(rows('states'));B=list(rows('brain'));R=json.load((p/'4Z2GCLA4DU52-resources.json').open())
J=[d for d in D if d['decider']=='jev'];plan=[d for d in J if d['label'].startswith('combat/plan-choice')]
print('Jev',len(J),'low',[(d['_line'],d['confidence']) for d in J if d.get('confidence') is not None and d['confidence']<.35]);print('best',len(plan),collections.Counter(d.get('rollout_best_chosen') for d in plan))
cont=[d for d in D if d['decider']=='code' and 'continuing the Jev-chosen plan' in d.get('rationale','')];aut=[d for d in D if d['decider']=='code' and d not in cont];combat=[d for d in aut if d['label'].startswith('combat/')]
k=lambda d:(d['floor'],d['turn'],d.get('sl_attempt'))
a={k(d) for d in combat};j={k(d) for d in plan};print('code',len(cont),len(aut),'combat actions',len(combat),'turns',len(a),'withoutjevplan',len(a-j),'withoutanyjev',len(a-{k(d) for d in J if d['label'].startswith('combat/')}),'fallback',sum(bool(d.get('fallback')) for d in D))
print('usage jev', {k:sum(d.get('usage',{}).get(k,0) or 0 for d in J) for k in ['input_tokens','output_tokens','cache_hit_tokens']})
for d in D:
 if 'HP guard:' in d.get('rationale',''):
  print('GUARD',d['_line'],d['floor'],d['turn'],d.get('sl_attempt'),'fields',[(k,v) for k,v in d.items() if 'guard' in k]);print('SA',json.dumps(d.get('selection_audit'),ensure_ascii=False)[:2500])
for w in R['combats']:
 pts=[]
 for t in w['enemy_hp_audit']['turns']:
  pts.append({k:t.get(k) for k in ['turn','live_enemy_hp_start','live_enemy_hp_end','net_live_enemy_hp_loss','visible_enemy_hp_loss_lower_bound','observed_hp_added','gaps']})
 print('combat turns',w['sequence'],w['floor'],json.dumps(pts,ensure_ascii=False))
print('brain keys',list(B[0]));print('brain meta',json.dumps({k:v for k,v in B[0].items() if k not in ['messages','response','request','prompt','parsed','raw','facts','state','memory']},ensure_ascii=False)[:3500])
for d in D:
 if d['floor']!=24 or not d.get('questions'):continue
 for k,q in d['questions'].items():
  crit=q.get('criteria',{})
  pot=[x for x in crit if x.startswith('p') and not x.startswith('plan')]
  print('Q24',d['_line'],d['turn'],d.get('sl_attempt'),'pot',pot,'answer',json.dumps(d.get('answers'),ensure_ascii=False)[:280])

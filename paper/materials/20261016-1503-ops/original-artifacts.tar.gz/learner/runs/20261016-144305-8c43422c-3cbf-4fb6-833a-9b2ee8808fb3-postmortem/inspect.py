import json,collections
from pathlib import Path
p=Path(__file__).parent
def rows(name):
 for line in (p/(name+'.lines')).open():
  n,s=line.split(':',1); r=json.loads(s);r['_line']=int(n);yield r
D=list(rows('decisions'));S=list(rows('states'))
with (p/'decisions-summary.txt').open('w') as out:
 for d in D:
  info={k:d.get(k) for k in ['_line','ts','floor','turn','label','decider','chosen','rationale','confidence','fallback','journal','sl_attempt','sl_reloads']}
  out.write(json.dumps(info,ensure_ascii=False)+'\n')
with (p/'states-summary.txt').open('w') as out:
 for r in S:
  s=r['state'];run=s['run'];c=s.get('combat') or {};player=c.get('player') or {}
  info={'line':r['_line'],'ts':r['ts'],'f':run.get('floor'),'t':s.get('turn'),'screen':s['screen'],'hp':[run.get('current_hp'),run.get('max_hp')],'pot':[[x.get('index'),x.get('potion_id')] for x in run.get('potions',[]) if x.get('occupied')],'player':player,'enemies':c.get('enemies'),'hand':[{k:x.get(k) for k in ['index','card_id','upgraded','energy_cost','resolved_rules_text']} for x in c.get('hand',[])],'pending':c.get('pending_card')}
  out.write(json.dumps(info,ensure_ascii=False)+'\n')
print('counts',len(D),len(S),[(n,len(list(rows(n)))) for n in ['brain','run-plans','sl-attempts','run-config']])
print('time',D[0]['ts'],D[-1]['ts'])
print('deciders',collections.Counter(d['decider'] for d in D))
for d in D:
 if d['decider']=='jev':
  print('jev keys',list(d.keys()));print('example',json.dumps({k:v for k,v in d.items() if k not in ['questions','fingerprint','audit','facts']},ensure_ascii=False)[:7000]);break
print('last',json.dumps(D[-1],ensure_ascii=False)[:1500])
for r in rows('run-config'): print('config',json.dumps(r,ensure_ascii=False)[:7000])
for r in rows('run-plans'):print('run-plan',json.dumps(r,ensure_ascii=False)[:4500])

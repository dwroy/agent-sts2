import json,collections,hashlib
from pathlib import Path
p=Path(__file__).parent

def rows(name):
    for ln in (p/(name+'.lines')).open():
        n,s=ln.split(':',1)
        r=json.loads(s);r['_line']=int(n)
        yield r

D=list(rows('decisions'));S=list(rows('states'));B=list(rows('brain'))
M={s['_line']:s['state'] for s in S}
R=json.load((p/'4Z2GCLA4DU52-resources.json').open())
assert (len(D),len(S),len(B),len(list(rows('run-plans'))),len(list(rows('sl-attempts'))))==(390,406,24,6,5)
assert len(R['combats'])==14
entries=[56,49,49,47,68,65,52,70,58,37,33,33,33,33]
exits=[56,49,47,47,65,52,45,14,37,33,None,None,None,0]
for i,w in enumerate(R['combats']):
    assert w['entry']['hp']==entries[i]
    assert (w.get('exit') or {}).get('hp')==exits[i]
    assert w['entry_is_turn_one']
    assert w['entry']['max_hp']==70
assert M[424883]['turn']==3 and M[424883]['run']['current_hp']==0
assert [e['current_hp'] for e in M[424883]['combat']['enemies']]==[23,21,0]
assert M[424882]['run']['current_hp']==2 and M[424882]['combat']['player']['block']==0
assert [e['current_hp'] for e in M[424882]['combat']['enemies']]==[26,21,2]
assert [M[n]['run']['current_hp'] for n in [424861,424872,424876,424883]]==[33,24,2,0]
assert [sum(e['current_hp'] for e in M[n]['combat']['enemies'] if e['is_alive']) for n in [424861,424872,424876,424883]]==[150,80,64,44]
assert [M[n]['run']['current_hp'] for n in [424826,424837,424842,424851]]==[33,19,33,11]
assert M[424836]['combat']['player']['block']==14
assert M[424850]['combat']['player']['block']==6
assert [e['current_hp'] for e in M[424837]['combat']['enemies']]==[29,28,17]
assert [e['current_hp'] for e in M[424851]['combat']['enemies']]==[29,28,17]
assert [M[n]['run']['current_hp'] for n in [424580,424581,424684,424685,424737,424738]]==[47,68,45,70,14,58]
assert 'REGAL_PILLOW' not in {x['relic_id'] for x in M[424584]['run']['relics']}
assert 'REGAL_PILLOW' in {x['relic_id'] for x in M[424585]['run']['relics']}
assert 'JOSS_PAPER' in {x['relic_id'] for x in M[424622]['run']['relics']}
J=[d for d in D if d['decider']=='jev'];P=[d for d in J if d['label'].startswith('combat/plan-choice')]
assert len(J)==144 and sum(d['confidence']<.35 for d in J)==15
assert len(P)==104 and collections.Counter(d.get('rollout_best_chosen') for d in P)=={True:94,False:5,None:5}
g=[d for d in D if d.get('hp_guard')]
assert len(g)==9 and collections.Counter(d['sl_attempt'] for d in g)=={2:3,3:3,4:3}
assert all(d['hp_guard']['predicted_hp_saved']==8 and d['hp_guard']['predicted_damage_change']==0 for d in g)
miss=[]
for d in D:
    crit=((d.get('questions') or {}).get('plan') or {}).get('criteria') or {}
    if d['floor']==24 and 'p0->e0' in crit and 'p0->e2' not in crit:
        match=[s for s in S if s['fingerprint']==d['fingerprint'] and s.get('observed_ts')==d.get('observed_ts')]
        assert len(match)==1
        assert match[0]['state']['run']['potions'][0]['valid_target_indices']==[0,1,2]
        miss.append({'decision':d['_line'],'state':match[0]['_line']})
assert len(miss)==19
assert sum((d.get('chosen') or {}).get('action')=='use_potion' for d in D)==14
assert sum((d.get('chosen') or {}).get('action')=='discard_potion' for d in D)==0
newpot=0;restore=0
for c in R['resource_changes']:
    before={tuple(x) for x in c['from']['potions']};after={tuple(x) for x in c['to']['potions']}
    if c['restart_boundary']:restore+=len(after-before)
    else:newpot+=len(after-before)
assert (newpot,restore)==(8,6)
sl=[r for r in rows('sl-attempts') if (r.get('reload') or {}).get('ok')]
assert len(sl)==3
assert sum(M[n2]['run']['current_hp']-M[n1]['run']['current_hp'] for n1,n2 in [(424825,424826),(424841,424842),(424860,424861)])==54
usage={k:sum(b['usage'].get(k,0) or 0 for b in B) for k in ['inputTokens','outputTokens','reasoningTokens','cacheHitTokens']}
assert usage=={'inputTokens':4355853,'outputTokens':26768,'reasoningTokens':23277,'cacheHitTokens':2094208}
assert all(b['engine']=='codex' and b['model']=='gpt-6.1-sol' and b['effort']=='xhigh' for b in B)
actual_code=[d for d in D if d['decider']=='code' and d['label'].startswith('combat/') and 'continuing the Jev-chosen plan' not in d.get('rationale','') and d.get('result','').startswith('completed:')]
assert len(actual_code)==32
assert len({(d['floor'],d['turn'],d.get('sl_attempt')) for d in actual_code})==16
section=[];active=False
with Path('notes/lessons.md').open() as f:
    for line in f:
        if line.startswith('## 4Z2GCLA4DU52'):
            assert not active;active=True
        if active:section.append(line)
section=''.join(section)
assert section.count('## 4Z2GCLA4DU52')==1
assert '### 勘误（2026-10-16 14:56:39 +0800，learner）' in section
proof={'局号':'4Z2GCLA4DU52','决策数':len(D),'状态数':len(S),'战斗窗口数':len(R['combats']),'终战末态':{'回合':3,'玩家HP':0,'敌HP':[23,21,0]},'目标遗漏配对':miss,'护栏题数':len(g),'药水新取得':newpot,'实际饮用':14,'SL恢复药':restore,'SL恢复HP':54,'大脑用量':usage,'代码自主实际执行':{'动作':32,'回合':16},'关键数字核对':'通过','勘误':['皇家枕头实得于F10、金纸F11','末试未赢不等于所有未选分支无胜线','代码决定35条/18回合含SL未派发，实际32条/16回合'],'复盘本节SHA256':hashlib.sha256(section.encode()).hexdigest()}
(p/'numbers-checked.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'核对':'通过','目标遗漏配对':len(miss),'勘误':proof['勘误'],'复盘本节SHA256':proof['复盘本节SHA256']},ensure_ascii=False))

import hashlib,json,pathlib,re,subprocess
P=pathlib.Path(__file__).resolve().parent
base='1fcbbfa59ac00e9bf04552d376ba693969f54e9f'
dispatch=json.loads((P/'dispatch.json').read_text());results=json.loads((P/'proposal-results.draft.json').read_text());source=json.loads((P/'source-commit.json').read_text()) if (P/'source-commit.json').exists() else None
live_now=subprocess.check_output(['git','rev-parse','live'],text=True).strip()
full=(P/'sandbox-full.log').read_text();full_exit=int((P/'sandbox-full.exit.txt').read_text());assert full_exit in [0,1]
summaries=re.findall(r'Tests\s+([^\n]+)',full)
source_commit=source['commit'] if source else None
for x in results:
 if x['id']=='silent-proposal-9c3554ff02a3119c':
  x['reason']='已证窄源码'+(source_commit or '（完整沙箱未通过，尚未提交）')+'已备妥；固定7题通过、撤生产净补丁5败/2过、恢复7过。整支live合并预检9处历史记录冲突，七叶净补丁apply-check=0但未实际合入；缺的是实际live祖先提交和集成验收，不是机制证据不足。'
fields={'task':'strategy-proposal','character':'silent','batch':'20261017-091302-s2-strategy-proposal','base':base,'runs':dispatch['runs'],'evidence_runs':['T0DGVABPV60U'],'fixes':[{'id':'silent-proposal-9c3554ff02a3119c','ledger':['silent-0293'],'commit':source_commit,'summary':'静默A10螺线显式小刀同线增敏、后继挡牌兑现与轮末临时敏捷撤回','source_only':True}],'skipped':[],'merged':None,'tests':{'tsc':0,'vitest':full_exit,'cases':None},'code_proposals':dispatch['proposal_ids'],'implementation_domains':['combat'],'proposal_results':results,'report':str(P/'report.md')}
# Count only passed fixed cases reported by the actual required sandbox entry point.
if full_exit==0:
 counts=[]
 for s in summaries:
  found=re.search(r'(\d+) passed',s)
  if found:counts.append(int(found.group(1)))
 assert len(counts)>=2, summaries
 fields['tests']['cases']=sum(counts)
else:
 fields['test_limitations']=['完整沙箱原失败保留；固定7题通过不替代完整套件通过。']
text=f'''# 本批策略实现回报

批次：{fields['batch']}；角色silent。完整基线：{base}。原派发10个锚点与14个原提案补充局已分别核角色；HEAD及源码提交见下文，非纯研究任务。

本批完成一个已领取原提案的窄源码：螺线飞镖silent-proposal-9c3554ff02a3119c／silent-0293；源码提交：{source_commit or '尚无，保留精确staged源码树与patch'}。其余九项不新增策略阈值。十个原ID都保留最终逐项处置；由于尚无实际live祖先，本批螺线项也仍waiting，不能登记implemented/shipped。

证据：T0DGVABPV60U／SILENT A10 F48末试T2、T4，s296633—296642、296655—296661；11个生产固定夹具投影与原字节SHA绑定。普通小刀3→4敏后相同偏折/普通防御同线15→17挡，实际后继防御换升级的另外3挡才使实盘到20；升级小刀1→4敏和次轮消失另验。没有完整dirty源码或同盘整战胜线，不声称修后转胜。

旧行为：只能重读入口敏捷，漏同线触发且将入口临时量带入后轮。新行为：SILENT A10单敌人、未熔化唯一HELICAL_DART、无未证联合触发；只对已核普通/升级无附魔零费显式小刀模板加本轮1敏，已有挡不倒补，后继挡牌才兑现。既有/新增临时量轮末撤回，永久敏捷保留。自动/重放/未知组合继续标未知；其他角色与未观察进阶入口不设标记，原行为保持。没有新增牌值/药价/SL/终局权重，未认证生成但尚未重读的药水小刀。

验证：生产目标tsc=0；固定初稿7题5失败因夹具投影漏state_version，随后一次错误cwd使修正未执行且未变重跑仍失败，原件均保；恢复原字段后7通过。撤四个既有生产叶的净补丁（保留helper供测试加载）时5失败/2通过，恢复7通过。原断言、预算和生产源码验证方法未放宽。必要完整入口bash tools/test-sandbox.sh退出{full_exit}，摘要{summaries!r}；{('总通过固定用例'+str(fields['tests']['cases'])) if full_exit==0 else '原失败详情保留在sandbox-full.log，不把目标7绿当完整绿'}。暂存七文件gitleaks=0，source manifest/净patch/恢复前后log齐全。

集成：只读预检绑定live=99737be9fdb9c2ea92089d768947c49b49b62382，最终读回live={live_now}。整支只读merge-tree预检exit1、9处历史记录冲突，未实际merge、未覆盖live刷新数据；本批七文件净patch在该live的git apply --check退出0，无实际应用。原ops pending-integrations/20261016-124302-s2-strategy-proposal.json明确沿原提案接受精确自测窄源，不要求先整枝合main；本批交付source.patch及精确源码供该原链集成，不另建父请求或新提案。尚无实际live合入提交、版本、实际上线规则双通知或shipped登记，留给ops核实际合入后履行。

证据范围：八流43112条输出封套SHA与逐局计数核对；47条关键原状态、4条原决策（含d289605原选15挡）和16条完成交接状态另核offset/bytes/SHA/JSON。K2为48脑调用/71含复用Codex决策。八局F48结算后→F49血量相同；最后可操作帧不当结算后出口，初始投影与修正后的完成交接材料分别保留。24局分阶，不混作策略训练样本；没有新独立胜负支持或旧support/repeat。35个相关经验原样只读，经验入库/自然消费者收益不冒称完成。

逐项证据、既有账本、原Markdown SHA、反例、未知、验证与回退详见同目录proposal.md。新代码的回退为逆向精确七文件提交，保留既有经验、日志、原提案与并行刷新；本批未运行play、LLM、网络或改其他角色知识。

实际原生会话上下文已核model=gpt-6.1-sol、effort=xhigh、workspace-write、network_access=false、approval_policy=never；任务旧文字high与实际xhigh分别记录，未自行修改配置或降强度，计费服务档未独立核。工具初次bubblewrap因并行目录消失拒绝只读命令、夹具/工作目录初稿错误均保留，不当游戏机制反证。

'''
for x in results:text+='- '+x['id']+'：'+x['state']+'；'+x['reason']+'\n'
text+='\n```json\n'+json.dumps(fields,ensure_ascii=False,indent=2)+'\n```\n'
(P/'report.md').write_text(text);(P/'result.json').write_text(json.dumps(fields,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source':source_commit,'tests':fields['tests'],'report':str(P/'report.md')},ensure_ascii=False))

# 静默猎手经验代码提案：mechanisms

来源任务：experience-update / 20261008-111006；实现任务：独立strategy-proposal。授权：Roy-2026-10-07-learning。

账本：silent-0012,silent-0005,silent-0016,silent-0080,silent-0046,silent-0084,silent-0011,silent-0023,silent-0010,silent-0123,silent-0168,silent-0079,silent-0135,silent-0133,silent-0289。经验：silent-strength-weak-observation,silent-footwork-block,silent-gorget-plating,silent-anticipate-temporary-dexterity,silent-piercing-wail-temporary-strength,silent-envenom-unblocked-attack-poison,silent-noxious-fumes-growth,silent-afterimage-per-card-block,silent-mirage-poison-card-block,silent-paels-legion-card-block-double,silent-infested-prism-tainted-skill-cost,silent-ceremonial-beast-threshold-growth-sl,silent-toric-toughness-delayed-block。

角色仅silent；策略范围仅实见A8/A10及所列案例，机制按已观察条件。新局79UCJ0K6R9C1 A10/F14和NEWRFAYKTQHR A10/F17/F28/F31；完整dirty源码未保存，当前代码仅作覆盖审计，不能冒认原运行快照。

79UCJ0K6R9C1 F14T10两个感染先耗6挡，13挡后余7、敌18攻损11；T11三感染9先耗7挡并扣2血死亡，已饮毒药目标仍8HP/10毒，无毒结算。T3空过及攻击/双毒三案五轮八样本均0/8赢，实际空过0伤；不把尾端估计76%当实际赢样本或必死。

NEWRFAYKTQHR F31首/第三/末试T2同28HP、敌151HP/4毒、2力量及五张同手；先毒后蜃景11挡、损3/扣30，末SL改蜃景前置且删毒只4挡、损8/扣23。两案24/24模拟死，却相差5HP/7伤；后轮改变，无原线整场胜利反事实。末T3防御10挡但污染加3令三击18→27、实损17，T4三技能15挡/9污染对19需损4，实际3血归零，严格存活差2。

历石场景：F17T7敌70HP/24毒、19HP零挡，结束后胜仍19；F28第四试T7敌52HP/9毒、8HP零挡对40，结束后胜仍8。前三试未执行末结算，不能补获胜；当前judge.ts分别持有52伤上界及13/22毒，前两试57/59HP却只单源判mayDie。52来自当前代码而非本局独立精确实伤，不据归零反算遗物值；新纯bug0287只留修复记录。

坚韧之环6局24次施放已核，普通基础5+施放敏捷后核脆弱、建2次轮初挡。79UCJ0K6R9C1 F14T2给5，T3/T4各5；T10两敏给7，T11带7仍死感染。ZVYUL2YP3518 F33T6临时敏叠至6给11，T7/T8敏回2仍各11；升级/叠层/重放组合未知。

赢战资源链：79UCJ0K6R9C1雕像47→7净损40，其中敵伤55、再生实回15；三火各21、F12赢损19后51进末精英。NEWRFAYKTQHR二幕四走廊赢损46，F24回复21后34进蜂群，第四试赢损26到8，F29回复21后29进棱柱败；六SL恢复165/原药6另记，不算回血或新获药。未来F32/F33/F48/F49及另一线路未实到，终局价值参数不拟合。

旧/新行为：逐牌核力量、敏捷、临时减力、能力施毒、余像、士兵、蜃景/污染及坚韧之环延迟定额挡。尤其SL死亡率饱和仍展示已核即时5HP/7伤差，不以同死亡率抹掉实际代价；独立任务检查现有实现，未覆盖的机制仅按实见条件补，其他角色等价。

拟合及验证：不拟合新权重或门槛，本批126静默完局按时间先核旧124局逐行一致，再新增两局；机制证据/反例/进阶见changes.json及update-summary.json。使用所列run/floor/turn冻结帧做固定回放；未知分支保留原行为，策略只在可证明覆盖缺口时改。独立策略任务应核已有live祖先实现避免重复，按原沙箱测试/gitleaks/live流程。预期影响为已观察状态数值与结束时点一致，不承诺整局胜率提升。回退只逆向各独立源码提交，保留经验、证据、刷新数据和其他角色；本任务不改源码、不登记implemented/shipped。

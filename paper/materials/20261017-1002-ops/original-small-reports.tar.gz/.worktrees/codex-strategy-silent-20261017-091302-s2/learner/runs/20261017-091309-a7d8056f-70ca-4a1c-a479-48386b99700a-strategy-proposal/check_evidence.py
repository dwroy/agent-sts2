import collections,hashlib,json,pathlib
P=pathlib.Path(__file__).resolve().parent
E=P/'evidence'
manifest=json.loads((E/'evidence-manifest.json').read_text())
allowed={x['run_id'] for x in json.loads((P/'runs-selected.json').read_text())}
assert len(allowed)==24
helical=json.loads((P/'helical-original-envelopes.json').read_text())
helical_lines={x['line'] for x in helical}
fixed_lines={293440,293443,293460,293461,293463,293464,293465,295422,295423,295424,295458,295459,295460,295463,295549}
handoffs={};refs=[];summary=[];brain=[];plans=[]
def projection(x):
 s=x['row']['state'];r=s.get('run') or {};c=s.get('combat') or {};p=c.get('player') or {}
 return {'source_ref':{k:x[k] for k in ['source','line','offset','bytes','sha256','run_id']},'floor':r.get('floor'),'turn':s.get('turn'),'screen':s.get('screen'),'hp':p.get('current_hp',r.get('current_hp')),'max_hp':p.get('max_hp',r.get('max_hp')),'block':p.get('block'),'potions':r.get('potions'),'powers':p.get('powers'),'hand':[(z.get('card_id'),z.get('upgraded')) for z in c.get('hand',[])],'enemies':[{k:z.get(k) for k in ['enemy_id','current_hp','max_hp','powers','move_id']} for z in c.get('enemies',[])]}
for item in manifest:
 name=item['stream'];counts=collections.Counter();digest=hashlib.sha256();critical=[]
 with (E/(name+'.evidence.jsonl')).open('rb') as f:
  for encoded in f:
   digest.update(encoded);x=json.loads(encoded);assert x['run_id'] in allowed;counts[x['run_id']]+=1
   if name=='brain' and x['run_id']=='K2JAGKVJAWZJ':brain.append({k:x['row'].get(k) for k in ['engine','label','question_id','error']})
   if name=='decisions' and x['run_id']=='K2JAGKVJAWZJ':plans.append(x['row'].get('decider'))
   if name=='states':
    s=x['row']['state'];r=s.get('run') or {};c=s.get('combat') or {};floor=r.get('floor');turn=s.get('turn')
    if x['line'] in fixed_lines or x['line'] in helical_lines:critical.append(x)
    if x['run_id']=='ZVYUL2YP3518' and floor==33 and turn in [6,7,8]:critical.append(x)
    if s.get('in_combat') and floor in [48,49]:
     z=handoffs.setdefault(x['run_id'],{})
     if floor==48:z['last_f48']=projection(x)
     elif 'first_f49' not in z:z['first_f49']=projection(x)
 assert digest.hexdigest()==item['output_sha256'],name
 assert all(counts[k]==v for k,v in item['counts'].items()),name
 if critical:
  source=pathlib.Path(item['stream']+'.jsonl')
  with open(critical[0]['source'],'rb') as src:
   for x in critical:
    src.seek(x['offset']);raw=src.read(x['bytes']);assert hashlib.sha256(raw).hexdigest()==x['sha256'];assert json.loads(raw)==x['row'];refs.append(projection(x))
 summary.append({'stream':name,'counts':dict(counts),'count':sum(counts.values()),'source_size':item['source_size'],'output_sha256':digest.hexdigest(),'critical_source_rows_rechecked':len(critical)})
(P/'evidence-verification.json').write_text(json.dumps({'streams':summary,'total':sum(x['count'] for x in summary),'critical_count':len(refs),'scope':'Envelope hashes/counts for all selected rows; raw offset/bytes/SHA and decoded JSON rechecked for critical rows only.'},ensure_ascii=False,indent=2)+'\n')
(P/'critical-projections.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
(P/'resource-handoffs.json').write_text(json.dumps(handoffs,ensure_ascii=False,indent=2)+'\n')
(P/'k2-provenance-counts.json').write_text(json.dumps({'brain_rows':len(brain),'brain_fields':brain,'decision_rows':len(plans),'decider_counts':dict(collections.Counter(plans))},ensure_ascii=False,indent=2)+'\n')
fixture=json.load(open(P.parents[2]/'agent/tests/silent-helical-dart-evidence.json'))
original={x['line']:x['row']['state'] for x in helical}
for f in fixture['frames']:
 assert f['state']=={k:original[f['line']][k] for k in f['state']}
print(json.dumps({'total':sum(x['count'] for x in summary),'critical_count':len(refs),'fixture_frames':len(fixture['frames']),'k2_brain':len(brain),'k2_codex_decisions':collections.Counter(plans)['codex']},ensure_ascii=False))

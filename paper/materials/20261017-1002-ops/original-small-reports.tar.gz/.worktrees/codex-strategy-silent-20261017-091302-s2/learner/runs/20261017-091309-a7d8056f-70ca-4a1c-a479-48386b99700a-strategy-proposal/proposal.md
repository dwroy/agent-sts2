# 本批策略提案与证据复核

批次：20261017-091302-s2-strategy-proposal。角色：silent。基线：1fcbbfa59ac00e9bf04552d376ba693969f54e9f。普通已领取队列任务；本批没有research_request、implementation_request或proposal_repair。git status开工干净，git merge --no-edit main为Already up to date；不领取其他ID，不派下级agent。

本批10个派发锚点与14个原提案关联补充局均由runs.jsonl确认SILENT，分阶A3一局/A4一局/A6一局/A7一局/A8一局/A10十九局；不混作同阶策略样本。八流43112条封套，source_size、offset/bytes/SHA及逐局计数保存在evidence/。全选中封套输出SHA/计数核对通过，47条关键原行另核source字节与JSON；11个固定夹具投影逐字段与原行相同。fight-plans为当前所选截点0行，仅说明未选中，不据此判原日志缺失。

## 可实现部分：螺线飞镖

原提案silent-proposal-9c3554ff02a3119c，账本silent-0293，原Markdown及SHA不改，无新提案ID。原ops pending-integrations/20261016-124302-s2-strategy-proposal.json明确尚无源码、整支记录冲突不是缺机制证据，并允许沿既有提案交精确自测窄源。本批是该原ID已派发续办，不另派学习者。

证据T0DGVABPV60U/SILENT A10 F48末试：T2 s296633→296634普通SHIV使0→1敏捷；s296638→296641三张已实际入手的SHIV+使1→4并建立HELICAL_DART_POWER4，s296642 T3两项消失。T4 s296655→296656普通SHIV使3→4；后继偏折s296658→296659实增8挡，防御+s296659→296660实增12挡。原普通防御同线计算15，修正同牌17，实际换升级另外+3才到20，不能把全部5挡归遗物。s296661 T5保留永久3敏，临时1撤回。六次SL属同一局，不增独立样本。

旧行为：真实入口敏捷可重读，仍漏同线新增敏捷；后轮把现场HELICAL_DART_POWER隐含的敏捷当永久。新行为：仅SILENT A10、单敌人、一个未熔化遗物，且无苦无/手里剑和未证临时/脆弱等组合；对已观察普通/升级无附魔0费小刀模板，显式一次出牌后新增1本回合敏捷，只影响后继挡牌。新增与现场临时量轮末撤回，永久步法不撤回。自动、重放、未知模板或组合保留原数值并标未知；不拟新排序权重、药价、SL或终局参数。其他角色入口不设标记，原行为保持。已生成但尚未重读实手的药水小刀不额外认证。

反例/限制：先挡后刀不倒补；T2四敏无挡仍0挡。原局末战失败不证明修后可胜。没有完整dirty源码/整场替代胜线；本批没有自然局消费或收益结论。旧局按原进阶分列，T0仅一个机制建立样本，后续新增A10完局才能作独立时间后验。

验证：固定原帧进入真实planCombatTurn/solver、逐张升级小刀、普通防御与升级差额隔离、先挡后刀、禁用/未知组合与两种rollout(fullFight=false/true)的入口/新触发临时撤回。撤四个既有生产叶净补丁时保留helper使模块可加载，7题中5失败/2通过；恢复7通过。原初稿fixture漏state_version的5失败、错误cwd导致一次修改未执行及未变重跑结果均保留；修正只恢复原字段，断言不放宽。

预期影响：当前候选同牌格挡与后轮敏捷更准确；不保证整战转胜。回退为逆向本批七文件源码/固定夹具提交，保留经验、原始日志、提案与并行知识。实际live集成与发布编号须由ops核实；源码在live祖先之前原ID只可waiting，不标implemented/shipped。

## 逐项处置

### silent-proposal-650ea306e8627f9e

更正第94批脑来源口径：48调用/71含计划复用的脑决策，旧机制边界保持

证据局：K2JAGKVJAWZJ,10GPK5XGHCK3,UJ0K3G10609Y；账本：silent-0010,silent-0012,silent-0013,silent-0019,silent-0020,silent-0021,silent-0046,silent-0065,silent-0077,silent-0106,silent-0115,silent-0178,silent-0243,silent-0276,silent-0277,silent-0278。

处置：已核K2为48条脑调用、71条含计划复用的Codex决策；没有定位消费错误固定计数的生产源码。原勘误包含的宽机制/规则缺完整历史dirty源码与知识联合快照，不能用数据勘误冒称源码duplicate。

### silent-proposal-60e68d681e861d1c

核感染持牌伤先于毒结算和毒药非即时伤覆盖

证据局：79UCJ0K6R9C1,9YBKCNBFP0X5,UACFSW4VDDLD,4Y94N8RDPGPM,TCFAHJ9K19VY,UMVLWER4CD98,TXZ6RVMQA09D,1913SE84AXQF,BTSRF7JL1W1Y,9Z9H2EXKLF3T,NEWRFAYKTQHR；账本：silent-0286,silent-0278。

处置：感染先于毒结算的窄路径已有live祖先5dbb47bfb48d652adfcda2e62c166a804098b6c3；毒药水多入口、异蛇头骨/制品和持牌伤组合缺完整同条件消费者验证，不能关闭原宽项；按e6f更正只核combat/potion。

### silent-proposal-9aa48a84227bcdb5

核静默实际资源与预测分账，未执行路线/药水反事实保持未知

证据局：79UCJ0K6R9C1,NEWRFAYKTQHR；账本：silent-0019,silent-0020,silent-0243,silent-0021,silent-0276,silent-0277,silent-0259。

处置：实到血量、回血、饮药与SL恢复可分账；未执行的路线、早喝/留药时点没有完整同条件胜负配对及按局独立留出，不能从失败记录拟合路线/药价。

### silent-proposal-7cfd0f9b6b0fbbda

核蜃景/污染即时血价与坚韧之环施放快照及增益分源

证据局：79UCJ0K6R9C1,NEWRFAYKTQHR,LLYSRQQ35AVW,ZVYUL2YP3518,HSX4HYATB4E2,TDLBRNA0R05B,1913SE84AXQF；账本：silent-0012,silent-0005,silent-0016,silent-0080,silent-0046,silent-0084,silent-0011,silent-0023,silent-0010,silent-0123,silent-0168,silent-0079,silent-0135,silent-0133,silent-0289。

处置：已核坚韧之环施放时6敏给11挡、后轮2敏仍11挡；原状态只给剩余轮数，缺跨重问/SL恢复可追溯的施放额度与剩余轮次联合入口，升级/叠层/重放及整包机制组合仍未知。

### silent-proposal-e6f9cb57c1204036

更正60e68d681e861d1c领域为combat/potion：核感染持牌伤与毒药结算，不涉及终局价值

证据局：79UCJ0K6R9C1,9YBKCNBFP0X5,UACFSW4VDDLD,4Y94N8RDPGPM,TCFAHJ9K19VY,UMVLWER4CD98,TXZ6RVMQA09D,1913SE84AXQF,BTSRF7JL1W1Y,9Z9H2EXKLF3T,NEWRFAYKTQHR；账本：silent-0286,silent-0278。

处置：已遵循60e68d的combat/potion领域勘误；没有独立源码实现提交，该勘误也不补齐原感染/毒瓶多入口与条件组合的消费者缺口。

### silent-proposal-6353ffbadaaac619

补F42至F49实盘HP/逐槽药水/SL来源审计；先校正缺机制，未有受控胜线前不改留药和终局权重。

证据局：9R916WW0V65N；账本：silent-0228,silent-0290,silent-0291。

处置：9R局F48完成后12/74空药接F49已核；禁抽/苦无已有窄实现，仍缺独立复活充能真值、固定输入/种子的两战配对与按局留出校准，不能据后战失败改留药/终局权重。

### silent-proposal-9e5d50fdd7bf1fbd

旧/新行为：保留已有连续Boss联合模型，核实际HP/药水/复活可观测状态与战斗增益清空。缺复活充能明确未知。当前留药/终局权重/路线评分保持；只先完善审计及固定两战配对验证，证据足够时独立提出参数候选，否则waiting，不因8局全败拟合阈值。

证据局：9R916WW0V65N,JMH5C51RLN4E,9TG1RP5LFAAK,ZVYUL2YP3518,TDLBRNA0R05B,TXZ6RVMQA09D,XTSV1U9JD34T,PD9AYQVMLQW6；账本：silent-0228,silent-0020,silent-0019,silent-0021,silent-0243,silent-0259,silent-0276。

处置：八局完成F48后至F49实际血量连续已核；缺保药/改线的受控两战结果、复活充能真值和独立留出，不能由八局后战均败拟药水或终局权重。

### silent-proposal-20b9df170d51b280

旧/新行为：独立核余像逐牌、滚石轮初、精准小刀、冰晶一次收益、实验体技能激怒/换阶段和女王减益/魂缚。只补当前源码缺少的已观察传播，不固定杀序。实验体首两试截断、末试胜且后续手牌/出牌同变，不能声称哪项单因转胜；女王没有赢次，不归失败于运气或尚未做过的替代线。

证据局：9R916WW0V65N；账本：silent-0023,silent-0094,silent-0054,silent-0173,silent-0028,silent-0069,silent-0079。

处置：既有窄机制源码不等于六类机制及其完整组合均认证；实验体早期尝试与女王判死出口截断、后续手牌/动作同变，缺同条件完整消费者对照，不支持单因转胜或固定杀序。

### silent-proposal-91cc7fd647077569

更正实验体尝试数字的证据范围：13支持局55试5赢，真正重打12场54试4赢；不混用全角色该Boss其他局数字。

证据局：9R916WW0V65N；账本：silent-0023,silent-0094,silent-0054,silent-0173,silent-0028,silent-0069,silent-0079。

处置：保留原冻结勘误13支持局55试5赢、真正重打12场54试4赢；本批未重算完整13局，且没有定位消费该固定分母的生产源码，不能以当前经验文字/数据提交登记源码duplicate。

### silent-proposal-9c3554ff02a3119c

接入螺线飞镖同线小刀增敏及跨轮失效，隔离后继升级换牌的误差

证据局：T0DGVABPV60U；账本：silent-0293。

处置：T0局A10 F48T2/T4机制证据充分，本批已完成窄源码和固定测试，沿原提案/账本交付；尚待完整沙箱结果与实际live集成，整支live预检有9处历史记录冲突，未把源码完成登记为实际live implemented。

## 资源与勘误的范围

K2原脑来源48调用与71含计划复用决策复核一致，见k2-provenance-counts.json。实验体13局固定分母是原保存勘误，本批没有将当前27局经验反填旧冻结分母。领域e6f只是原感染项范围勘误，不涉及terminal。

八局交接以完成结算的最后F48状态到首次F49状态核：JMH 243533→243534 8HP；9TG 244373→244374 17；ZVY 258180→258181 50；TDL 270373→270374 2；TXZ 281564→281565 4；XTS 286895→286896 23；PD9 291020→291021 10；9R 295423→295424 12。初始resource-handoffs.json保留的是最后可操作战斗帧，部分尚未付敌攻/回复，不能当完成出口；最终resource-handoffs-completed.json采用结算后状态，不作为新机制反例。药水逐槽、SL恢复及复活真值缺口分开，八局后战均败不是保药/换线胜率的受控证据。

原47关键帧、原队列Markdown、选择账本行、35个相关经验条目和源码覆盖审计均保留。不改变旧claim/首证/prior/evidence/计数和已shipped状态，不重复登记旧support/repeat，不冒称经验入库或大脑自然采用。


最终执行回执：源码提交 b831407a8ed13bcb9b5359b0d3e1ae84624d5571，完整沙箱退出0（4275＋11＝4286项）；撤生产净补丁5败/2过、恢复7过；gitleaks0。root ledger CLI实际追加39条where/note，其中0293关联本精确源码；CLI退出0、旧22389334字节前缀与受保护字段/历史均保，实际追加note逐条读回。未新增evidence/support/repeat、不改旧状态/版本。实际未合live，无新发布号或shipped。

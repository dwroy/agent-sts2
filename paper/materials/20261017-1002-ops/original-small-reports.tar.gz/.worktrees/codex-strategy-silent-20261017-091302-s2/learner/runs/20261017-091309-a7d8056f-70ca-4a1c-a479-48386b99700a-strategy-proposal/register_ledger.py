import pathlib,json,hashlib,subprocess,importlib.util
P=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/home/dw/Projects/agent-sts2');ledger=root/'paper/materials/learning/ledger.jsonl'
changes=[json.loads(s) for s in (P/'ledger-trace-updates.template.jsonl').read_text().splitlines()];ids={x['id'] for x in changes}
source=json.loads((P/'source-commit.json').read_text()) if (P/'source-commit.json').exists() else None
if source:
 for row in changes:
  if row['id']=='silent-0293':row['where']['commits']=[source['commit']];row['note']+=' 精确螺线窄源码提交'+source['commit']+'；自测已过，actual live合并因九处历史记录冲突尚未进行。七叶source.patch在冻结live apply-check=0，交原ops窄集成；当前proposed状态保持，未标shipped。'
assert (P/'report.md').is_file()
spec=importlib.util.spec_from_file_location('ledger_cli',root/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def selected():
 rows=[]
 with ledger.open() as f:
  for n,line in enumerate(f):
   x=json.loads(line)
   if x.get('id') in ids:rows.append((n,x))
 return m.fold(rows)
before=selected();size=ledger.stat().st_size
with ledger.open('rb') as f:prefix=hashlib.sha256(f.read(size)).hexdigest()
(P/'ledger-before-cli.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
text=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in changes);(P/'ledger-cli-input.jsonl').write_text(text)
r=subprocess.run(['python3',str(root/'learner/ledger.py'),'update'],input=text,text=True,capture_output=True)
(P/'ledger-cli.stdout.txt').write_text(r.stdout);(P/'ledger-cli.stderr.txt').write_text(r.stderr);assert r.returncode==0,(r.returncode,r.stderr)
after=selected()
protected=['claim','first_run','asc','prior','prior_note','prior_runs','evidence','status','version','effect','shipped_at']
for i in ids:
 for key in protected:assert before[i].get(key)==after[i].get(key),(i,key)
 for key,old in before[i].get('where',{}).items():assert after[i]['where'][key][:len(old)]==old,(i,key)
 assert after[i]['history'][:len(before[i]['history'])]==before[i]['history']
 assert after[i]['notes'][:len(before[i]['notes'])]==before[i]['notes']
with ledger.open('rb') as f:assert hashlib.sha256(f.read(size)).hexdigest()==prefix
(P/'ledger-after-cli.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
(P/'ledger-cli-verification.json').write_text(json.dumps({'exit_code':r.returncode,'own_updates':len(changes),'old_prefix_bytes':size,'old_prefix_sha256':prefix,'protected_fields':protected,'old_history_notes_where_preserved':True,'no_added_evidence':True,'source_commit':source['commit'] if source else None},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit':r.returncode,'updates':len(changes),'protected':True},ensure_ascii=False))

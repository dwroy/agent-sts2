# 静默猎手策略提案批次报告

记录时间：2026-10-17T09:51:21+08:00；batch=20261017-094303-strategy-proposal。

本批十项均waiting。核实已有神化升级、候选事实和动作观测子项后，仍缺各提案指定的持续执行归属、联合生产校准或受控整战后继；没有隔离新的可修复数值失配。无源码或知识修改、提交、live合入、新版本或shipped。

## 身份与范围

开工git status为空，HEAD=001666ed867451178b0e568a65da531e21b1c31d；普通批git merge --no-edit main返回Already up to date，此后HEAD保持。根learn本批task/character/worktree、六runs及十proposal_ids匹配；没有research_request、implementation_request或proposal_repair。普通专题文件绑定另一旧批，本批不承接专题、不扩展队列，没有下级agent。

本批局号：VLZ6CCT8AQ0A、8JRE1C4H4Z2W、CA5KE8GFJ9X2、5PM6JAQG6FNQ、61E2QS63Y9WU、DUZUBAJ3A8GP。runs六条及全部所属state均核SILENT/A10；六局最终均败，胜战与SL仍分别观察。只采用这六局和本角色原提案，不读其他角色知识。原dirty完整执行源码与知识不能由一个Git哈希复原；旧兼容字段不作为脑引擎身份证明。

## 原始证据与复核

共用extract_evidence.py提取八流，每流在打开时冻结独立source_size；显式run/run_id/state.run_id/fingerprint.run冲突拒收，不按正文提及收局。6995行全部从原日志按offset/bytes/SHA和JSON回读一致，原字节和计数均保留。

| 流 | source_size（字节） | 所属行数 |
|---|---:|---:|
| states | 13793958456 | 3432 |
| decisions | 2151926865 | 3306 |
| sl-attempts | 44842644 | 29 |
| run-config | 1922422 | 6 |
| run-plans | 8769794 | 33 |
| brain | 718673205 | 183 |
| runs | 354997 | 6 |
| fight-plans | 2233957 | 0 |

states、decisions、brain全源各2行无效JSON保留计数，不能断言它们属于本六局；fight-plans零匹配仅说明该截点未选到，不能倒推日志缺失或动作未发生。八流选中封套SHA与071302原批完全相同，全源截点增长未增加本批独立证据；未覆盖旧报告或零行初稿。

十原Markdown均与队列add行SHA一致；队列物理offset/bytes/SHA、26条相关账本的原始行与正确CLI折叠语义均保存。初次只读简化展示将evidence/where当覆盖字段，未用于结论或写入；随后按ledger.apply的追加语义重折叠并保存ledger-current.json.gz。

718条目标状态与696条目标决策见selected-state-facts.json和selected-decision-facts.json。37项既有材料检查在本批新提取且回读的原字节上再次通过，包括神化能量/牌面、药水HP不变、蚌虚弱后成长、无毒冒泡零效果、负敏捷与毒、胧光分体净扣、甲虫减力期限和8JRE同指纹端点。检查不是tsc/vitest，也没有源码撤除负控。

## 既有消费者和源码

重新生成六个离线输入，与071302各解码输入逐字节一致；四个selection模块及递归JSON辅助依赖共五叶，在旧base、本树和实际live均逐SHA相同。六份原输出压缩/解码SHA复核后复用，未重新执行消费者、模型或模拟。完整来源与SHA见consumer-reuse.json。

六输出合计476段、3301条带ID动作、534轮窗，121个轮窗有观察端点，413个未知。CA5一条、61E一条、DUZU三条无decision_id的原元数据仍保存于完整输入，既有消费排除边界不变。actual_full_candidate_result均null属于工具认证范围，不能解释为实盘没有执行；整轮端点也不能直接归因给中途被重问替换的单个候选。

只读live观察提交=99737be9fdb9c2ea92089d768947c49b49b62382。13个相关生产叶中11个相同，card-model.ts和sl/explore.ts差异仅旧Roy/Dai署名注释，补丁原件保存。这不是全仓或历史dirty树等价证明。以下六窄源均核为本base及实际live祖先，changed_paths已保存，它们不是本批实现：

- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：ops: replay checked Silent Apotheosis candidate facts。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：Propagate observed Silent Apotheosis Malaise upgrade。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：Replay tested held-loss candidate facts on current live。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：Integrate repaired legacy learning deltas and bounded continuation adapter。
- cf72bd21148059f111f760cc98a727369e34a47e：Integrate checked offline Silent potion observation tool。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：Propagate observed Silent Deadly Poison upgrade。

当前actual_cast_this_fight仍null；神化对未验证属性/自动出牌等交互保留unknown；selection_dispatch只记录单动作回执，完整候选及因果结果未认证。现有窄功能不能替代原整项验收，也不能由旧测试绿色推出新量化规则。

## 逐项处置

| 原id | 状态 | 具体待补项 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺实际施放在抽牌、选牌、用药、重问、SL和换战后的持续身份核验，以及未覆盖升级交互的生产校准；已有窄实现不足关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算配对、样本成熟曲线与留药完整后继；707ms单题不足确定新预算、药价或focus。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化提案仍缺实际施放持续身份及跨中断验证；不能仅凭已有配对转换将经验来源整项登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项逐来源联合校准，尤其升级/属性组合、状态期限及战斗到路线和休息的资源接续；本批没有隔离新的数值失配。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨抽牌、选牌、生成、用药、SL和重问的完整候选持续归属及成长兑现关联；未选线整战后继未知，不能据12换7更改阈值。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺把逐击力量、正负敏捷、虚弱与蚌独立成长同时冻结的生产调用校准；本来源局未实测正敏捷，不拟新保血/输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水与完整抽序下不同启动顺序的整战配对和可复现收益函数；一次零效果不足拟合启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺A10同起始HP、构筑及完整抽序的SL整战配对和另一条完整后继；首试胜利及单轮端点不足改变SL规则。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行、退场及复现全链的冻结生产校准和另一focus完整后继；T4净扣47不足确定目标顺序收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续和A10成长的完整冻结生产校准及同抽换序后继；四次相关失败不足拟合新血价或固定杀序。 |

各项证据局号、层、回合、原账本、反例、当前覆盖、预期及验证方法见proposal.md。沿用十个真实CLI id；无新提案，无implemented/duplicate登记，无新增implementation_domains。未关闭量化、策略或学习入库父要求，也不宣称经验已入库或被大脑采用。

## 记录与验证

账本追溯登记状态以ledger-cli-receipt.json和ledger-readback.json为准；只经根learner/ledger.py update追加proposal/report和本批复核说明，by=learner:strategy-proposal。旧claim、首证、prior、evidence及status/version/shipped/effect保持，不把同一证据重登support/repeat，不降已shipped条目为proposed。队列处置交最终proposal_results，不手改队列或learn.json。

无源码改动，撤源码失败/恢复通过不适用；未运行生产tsc/vitest，tests={"tsc":null,"vitest":null,"cases":null}。无提交、merge或版本，无上线decision-log或规则双通知。其他角色行为保持原状。gitleaks与最终干净状态见final-checks.json。

限制：六局及多次SL均为已用于发现的相关样本；未知完整抽序、未选线后继和同随机池/预算实验不能靠现有端点补齐。宿主PID在工具进程命名空间不可见，未独立核实本批原生模型、推理强度及计费服务档，不把文档默认值当实际切换证明；未改运行配置。

只读查询曾猜测不存在的源码路径，rg/sed非零后改用rg --files定位；无产品故障或机制反例。未联网、不运行play、不读凭据/.env或游戏二进制、不改运维prompt、不推送。

交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/proposal.md。
完整报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/report.md。

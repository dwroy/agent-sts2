# 静默猎手十个原提案复核

记录时间：2026-10-17T09:51:21+08:00；batch=20261017-094303-strategy-proposal；base=001666ed867451178b0e568a65da531e21b1c31d。

本批只处理已领取十个CLI id，十项均waiting，无新增源码或知识修改。六局均已按runs与state核为SILENT/A10。原日志八流6995行逐offset/bytes/SHA回读，37项材料断言通过；这些是发现样本内事实复核，不能记为生产测试或独立盲测。

本批不拟合新权重。已有窄实现保存实际base/live祖先证明；原提案余项仍须逐项验收。后续有新源码须固定输入撤源码失败、恢复通过，并经原沙箱入口自测、实际live合入核验；本批无源码红绿可报告。继续保留合法选项与模型选择权，相同推演值并列。

回退：本批仅报告和CLI追溯，无生产行为可回退。后续源码按对应实际提交回退；原日志、原提案、账本及失败记录保留。两个神化来源共享事实，不另建重复id，也不扩分母。

## silent-proposal-89354805ee4d7e77

按静默已观测帧补齐神化在同线及后续抽牌中的升级传播，并区分持有、施放与模型覆盖；无整场转胜保证。

- 来源任务：postmortem；实现任务：strategy-proposal；原账本：silent-0237、silent-0238。
- 证据局号/层/回合：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1。
- 已核事实：s275564→275565、s275679→275680均7→5能；防御5→8、打击7→10；F43后抽毒雾升级。
- 反例与限制：F43施放神化后仍整战损57；F45持有而未施放，不能推出必打或必胜。
- 当前规则和覆盖：普通神化、已观察升级配对与模拟传播已有窄实现；silent-apotheosis-reference的actual_cast_this_fight仍为null。
- 本批处置：waiting。缺实际施放在抽牌、选牌、用药、重问、SL和换战后的持续身份核验，以及未覆盖升级交互的生产校准；已有窄实现不足关闭整项。
- 预期行为与验证：沿原账本核对真实动作与各堆实例；未知升级保持unknown，不能用候选planned_plays代替实际施放。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-89354805ee4d7e77.md；指纹见proposal-provenance.json。

## silent-proposal-f2bfceddb1898dca

核验三骑士全败候选的即时血价、击杀缺口与药水MC预算成熟度；先做同盘预算实验，缺对照时保留原护栏、留药与目标规则。

- 来源任务：postmortem；实现任务：strategy-proposal；原账本：silent-0106、silent-0019、silent-0201。
- 证据局号/层/回合：VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5。
- 已核事实：d269748药水1/12样本、707ms，rollout为horizon1/samples1/best=null；s275728→275729能1→2、HP67不变。末轮32血20挡对59。
- 反例与限制：后问药水样本完成不等于整战成熟；高伤候选未完整实打，不能声称本可获胜。
- 当前规则和覆盖：simulation_reference已分列范围、样本、耗时、未比较与并列；本批保留原预算、留药、护栏和目标规则。
- 本批处置：waiting。缺完整模型下同起点、同随机池、同总预算配对、样本成熟曲线与留药完整后继；707ms单题不足确定新预算、药价或focus。
- 预期行为与验证：先固定模型覆盖与随机池，再对同总预算策略作配对；真实药效、中位抽样与整战结果分别核验。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-f2bfceddb1898dca.md；指纹见proposal-provenance.json。

## silent-proposal-283a164780d11e69

神化已观察升级进入同方案与后续抽牌，保留未知边界，不定必打规则

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0237、silent-0238。
- 证据局号/层/回合：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1。
- 已核事实：与89354805ee4d7e77同源的升级观察；保留experience-update与silent-apotheosis-combat-upgrades的独立来源链接。
- 反例与限制：两个来源id只对应一局事实，不扩大独立支持数；提案相似本身不是已有源码duplicate证明。
- 当前规则和覆盖：沿用原神化窄实现；持有、候选及实际施放须继续分列。
- 本批处置：waiting。同源神化提案仍缺实际施放持续身份及跨中断验证；不能仅凭已有配对转换将经验来源整项登记duplicate。
- 预期行为与验证：共享同一实现和固定证据，保留两个原id；逐来源验收，不另建重复提案。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-283a164780d11e69.md；指纹见proposal-provenance.json。

## silent-proposal-ebbfe3b97548756d

逐源验证当前攻防、毒触发与持续资源，不从持有或单轮减力预支整场收益

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。
- 证据局号/层/回合：VLZ6CCT8AQ0A F43 T1—T5、F44休息、F45 T1—T5。
- 已核事实：升级勒紧/尖啸、当前覆甲及能力建立分源；s275754无覆甲，32血20挡对59完整需损39。
- 反例与限制：F43胜局仍损57，F44回复至67仍于F45败；不能由不同血档推出统一安全线。
- 当前规则和覆盖：已有攻防、毒与资源的局部计算和提示；十五经验子项未在本轮同一冻结生产调用中完成联合校准。
- 本批处置：waiting。缺十五子项逐来源联合校准，尤其升级/属性组合、状态期限及战斗到路线和休息的资源接续；本批没有隔离新的数值失配。
- 预期行为与验证：按原帧逐项核收益和期限，保留赢战耗血；神化沿专属id推进，不从暂时减力预支永久收益。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-ebbfe3b97548756d.md；指纹见proposal-provenance.json。

## silent-proposal-e5b87be50f28f311

静默A10同盘SL以12血换7伤重犯：补齐Jev原答、HP护栏、SL换线及重规划的候选代价与实际成长兑现审计；单局不足以改阈值，保留现行为并独立验证。

- 来源任务：postmortem；实现任务：strategy-proposal；原账本：silent-0079、silent-0021、silent-0125、silent-0018。
- 证据局号/层/回合：8JRE1C4H4Z2W F33首/三试T2、二试T5、末试T11；F17 T6。
- 已核事实：d270216/d270282指纹逐字相同；SL原/替换死亡预测0/24与5/24；整轮实损3/15、敌血净扣10/17，多12血换7伤。
- 反例与限制：末次防御替换延至T11仍败；没有保持原线至获胜的反事实。0/24与5/24不等同。
- 当前规则和覆盖：在线selection_audit记录预测阶段，selection_dispatch仅为single_action_receipt；离线工具不认证完整候选。
- 本批处置：waiting。缺跨抽牌、选牌、生成、用药、SL和重问的完整候选持续归属及成长兑现关联；未选线整战后继未知，不能据12换7更改阈值。
- 预期行为与验证：保留原问、护栏、SL、派发及重问边界；实际净HP、能力建立与候选预测逐项关联，缺端点保持未知。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-e5b87be50f28f311.md；指纹见proposal-provenance.json。

## silent-proposal-49632bc4878fb597

把当前属性、每击修正、弱与成长分项验证，不增加统一保血或输出权重。

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0005、silent-0231。
- 证据局号/层/回合：CA5KE8GFJ9X2 F13 T1/T3/T5。
- 已核事实：s273237/273252/273263蚌力量0/4/8、同招11/15/19；s273257/273268虚弱后11/14，仍继续成长。
- 反例与限制：本局计划步法没有取得；本局不能补正敏捷实测，末轮仍不足存活。
- 当前规则和覆盖：逐击力量、虚弱、敏捷和独立成长已有局部路径；没有从本轮材料隔离出新的算式错误。
- 本批处置：waiting。缺把逐击力量、正负敏捷、虚弱与蚌独立成长同时冻结的生产调用校准；本来源局未实测正敏捷，不拟新保血/输出权重。
- 预期行为与验证：使用A10现场敌人数据与真实牌面逐击核；正敏捷仅用本角色已观察证据补齐，不用未取得的牌补值。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-49632bc4878fb597.md；指纹见proposal-provenance.json。

## silent-proposal-66532328a585941f

持有/计划/已建立分账；如提构筑或启动权重，先做实盘兑现与受控整场验证。

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0021、silent-0009。
- 证据局号/层/回合：5PM6JAQG6FNQ F39末试T2；F33为不同战对照。
- 已核事实：d268455及s274379→274380：无毒失落35血、毒0均未变，能5→4。
- 反例与限制：F33建立组件并赢，但敌人、资源和抽序不同；不能作为启动顺序受控对照。
- 当前规则和覆盖：持有、计划与实际建立继续分账；本批不赋予启动或构筑固定权重。
- 本批处置：waiting。缺同HP、牌组、药水与完整抽序下不同启动顺序的整战配对和可复现收益函数；一次零效果不足拟合启动权重。
- 预期行为与验证：冻结相同起点及抽序，按run_id划开发/后置验证；保留未选线未知，不从败局倒推必胜顺序。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-66532328a585941f.md；指纹见proposal-provenance.json。

## silent-proposal-43a76a31ba7bdcfa

冻结吸取、负敏捷与毒的分项事实；任何SL范围或换线偏好需完整同盘验证。

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0030、silent-0027。
- 证据局号/层/回合：61E2QS63Y9WU F17 T5/T6/T7。
- 已核事实：s273504敏捷−2、两防御各3；s273504→273508族母67→34，与17+16已结毒相符。
- 反例与限制：本场首试获胜；不能据此声称别局SL换线可以救活。
- 当前规则和覆盖：负敏捷与毒结算分项保留；SL范围、阈值和换线偏好维持。
- 本批处置：waiting。缺A10同起始HP、构筑及完整抽序的SL整战配对和另一条完整后继；首试胜利及单轮端点不足改变SL规则。
- 预期行为与验证：先逐步核吸取、挡和毒端点；规则比较须同起点完整后继，SL恢复不算回血。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-43a76a31ba7bdcfa.md；指纹见proposal-provenance.json。

## silent-proposal-5264153a4a4b0e5c

复验已有召唤和各实体成长；保留所有目标选项，相同推演值并列，不强制首杀。

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0039、silent-0209。
- 证据局号/层/回合：61E2QS63Y9WU F23 T3/T4/T5。
- 已核事实：s273593→273596本体76→41、幻象14→2，合计47=35+12；玩家25→10。两次航行后两实体力3→6。
- 反例与限制：幻象余2仍攻击；focus幻象39伤/零损候选未实打，不能称整战胜线。
- 当前规则和覆盖：召唤与成长已有局部模型；每实体剩血和退场进度须分别核验。
- 本批处置：waiting。缺A10召唤、航行、退场及复现全链的冻结生产校准和另一focus完整后继；T4净扣47不足确定目标顺序收益。
- 预期行为与验证：逐实体核各阶段HP、成长和实际退场，保留全部目标及相同推演值并列，不规定首杀。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-5264153a4a4b0e5c.md；指纹见proposal-provenance.json。

## silent-proposal-bddfa690a84e03d0

按当前进阶、睡眠/眩晕/成长分别验证；不把未知换线胜率或固定杀序写成规则。

- 来源任务：experience-update；实现任务：strategy-proposal；原账本：silent-0128、silent-0079。
- 证据局号/层/回合：DUZUBAJ3A8GP F30 T1—T6、四次相关尝试。
- 已核事实：s274929/274932/274934甲虫力量2→−4→4，显示来袭20→14→22；临时减力后恢复并继续成长。
- 反例与限制：末试T4多扣3敌血却多损2玩家血；四试失败不支持固定输出血价或一律保血。
- 当前规则和覆盖：睡眠与成长已有局部模拟；不将单轮减力视作关闭成长。
- 本批处置：waiting。缺伤害唤醒、眩晕接续和A10成长的完整冻结生产校准及同抽换序后继；四次相关失败不足拟合新血价或固定杀序。
- 预期行为与验证：分阶段核睡层、唤醒/眩晕及期限；同起点完整后继再评换序，SL次数不增加独立局数。
- 原Markdown及SHA：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-094303/learner/runs/20261017-094311-135df0dd-07ad-43c8-bada-32f23eabd9c1-strategy-proposal/silent-proposal-bddfa690a84e03d0.md；指纹见proposal-provenance.json。

import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
STAMP = '2026-10-17T09:51:21+08:00'
BATCH = '20261017-094303-strategy-proposal'
dispatch = json.loads((HERE / 'dispatch.json').read_text())
history = json.loads((HERE / 'assigned-proposals.json').read_text())
originals = {i: next(x['row'] for x in rows if x['row'].get('op') == 'add') for i, rows in history.items()}
items = [
    ('89354805ee4d7e77', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1',
     's275564→275565、s275679→275680均7→5能；防御5→8、打击7→10；F43后抽毒雾升级。',
     'F43施放神化后仍整战损57；F45持有而未施放，不能推出必打或必胜。',
     '普通神化、已观察升级配对与模拟传播已有窄实现；silent-apotheosis-reference的actual_cast_this_fight仍为null。',
     '缺实际施放在抽牌、选牌、用药、重问、SL和换战后的持续身份核验，以及未覆盖升级交互的生产校准；已有窄实现不足关闭整项。',
     '沿原账本核对真实动作与各堆实例；未知升级保持unknown，不能用候选planned_plays代替实际施放。'),
    ('f2bfceddb1898dca', 'VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5',
     'd269748药水1/12样本、707ms，rollout为horizon1/samples1/best=null；s275728→275729能1→2、HP67不变。末轮32血20挡对59。',
     '后问药水样本完成不等于整战成熟；高伤候选未完整实打，不能声称本可获胜。',
     'simulation_reference已分列范围、样本、耗时、未比较与并列；本批保留原预算、留药、护栏和目标规则。',
     '缺完整模型下同起点、同随机池、同总预算配对、样本成熟曲线与留药完整后继；707ms单题不足确定新预算、药价或focus。',
     '先固定模型覆盖与随机池，再对同总预算策略作配对；真实药效、中位抽样与整战结果分别核验。'),
    ('283a164780d11e69', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1',
     '与89354805ee4d7e77同源的升级观察；保留experience-update与silent-apotheosis-combat-upgrades的独立来源链接。',
     '两个来源id只对应一局事实，不扩大独立支持数；提案相似本身不是已有源码duplicate证明。',
     '沿用原神化窄实现；持有、候选及实际施放须继续分列。',
     '同源神化提案仍缺实际施放持续身份及跨中断验证；不能仅凭已有配对转换将经验来源整项登记duplicate。',
     '共享同一实现和固定证据，保留两个原id；逐来源验收，不另建重复提案。'),
    ('ebbfe3b97548756d', 'VLZ6CCT8AQ0A F43 T1—T5、F44休息、F45 T1—T5',
     '升级勒紧/尖啸、当前覆甲及能力建立分源；s275754无覆甲，32血20挡对59完整需损39。',
     'F43胜局仍损57，F44回复至67仍于F45败；不能由不同血档推出统一安全线。',
     '已有攻防、毒与资源的局部计算和提示；十五经验子项未在本轮同一冻结生产调用中完成联合校准。',
     '缺十五子项逐来源联合校准，尤其升级/属性组合、状态期限及战斗到路线和休息的资源接续；本批没有隔离新的数值失配。',
     '按原帧逐项核收益和期限，保留赢战耗血；神化沿专属id推进，不从暂时减力预支永久收益。'),
    ('e5b87be50f28f311', '8JRE1C4H4Z2W F33首/三试T2、二试T5、末试T11；F17 T6',
     'd270216/d270282指纹逐字相同；SL原/替换死亡预测0/24与5/24；整轮实损3/15、敌血净扣10/17，多12血换7伤。',
     '末次防御替换延至T11仍败；没有保持原线至获胜的反事实。0/24与5/24不等同。',
     '在线selection_audit记录预测阶段，selection_dispatch仅为single_action_receipt；离线工具不认证完整候选。',
     '缺跨抽牌、选牌、生成、用药、SL和重问的完整候选持续归属及成长兑现关联；未选线整战后继未知，不能据12换7更改阈值。',
     '保留原问、护栏、SL、派发及重问边界；实际净HP、能力建立与候选预测逐项关联，缺端点保持未知。'),
    ('49632bc4878fb597', 'CA5KE8GFJ9X2 F13 T1/T3/T5',
     's273237/273252/273263蚌力量0/4/8、同招11/15/19；s273257/273268虚弱后11/14，仍继续成长。',
     '本局计划步法没有取得；本局不能补正敏捷实测，末轮仍不足存活。',
     '逐击力量、虚弱、敏捷和独立成长已有局部路径；没有从本轮材料隔离出新的算式错误。',
     '缺把逐击力量、正负敏捷、虚弱与蚌独立成长同时冻结的生产调用校准；本来源局未实测正敏捷，不拟新保血/输出权重。',
     '使用A10现场敌人数据与真实牌面逐击核；正敏捷仅用本角色已观察证据补齐，不用未取得的牌补值。'),
    ('66532328a585941f', '5PM6JAQG6FNQ F39末试T2；F33为不同战对照',
     'd268455及s274379→274380：无毒失落35血、毒0均未变，能5→4。',
     'F33建立组件并赢，但敌人、资源和抽序不同；不能作为启动顺序受控对照。',
     '持有、计划与实际建立继续分账；本批不赋予启动或构筑固定权重。',
     '缺同HP、牌组、药水与完整抽序下不同启动顺序的整战配对和可复现收益函数；一次零效果不足拟合启动权重。',
     '冻结相同起点及抽序，按run_id划开发/后置验证；保留未选线未知，不从败局倒推必胜顺序。'),
    ('43a76a31ba7bdcfa', '61E2QS63Y9WU F17 T5/T6/T7',
     's273504敏捷−2、两防御各3；s273504→273508族母67→34，与17+16已结毒相符。',
     '本场首试获胜；不能据此声称别局SL换线可以救活。',
     '负敏捷与毒结算分项保留；SL范围、阈值和换线偏好维持。',
     '缺A10同起始HP、构筑及完整抽序的SL整战配对和另一条完整后继；首试胜利及单轮端点不足改变SL规则。',
     '先逐步核吸取、挡和毒端点；规则比较须同起点完整后继，SL恢复不算回血。'),
    ('5264153a4a4b0e5c', '61E2QS63Y9WU F23 T3/T4/T5',
     's273593→273596本体76→41、幻象14→2，合计47=35+12；玩家25→10。两次航行后两实体力3→6。',
     '幻象余2仍攻击；focus幻象39伤/零损候选未实打，不能称整战胜线。',
     '召唤与成长已有局部模型；每实体剩血和退场进度须分别核验。',
     '缺A10召唤、航行、退场及复现全链的冻结生产校准和另一focus完整后继；T4净扣47不足确定目标顺序收益。',
     '逐实体核各阶段HP、成长和实际退场，保留全部目标及相同推演值并列，不规定首杀。'),
    ('bddfa690a84e03d0', 'DUZUBAJ3A8GP F30 T1—T6、四次相关尝试',
     's274929/274932/274934甲虫力量2→−4→4，显示来袭20→14→22；临时减力后恢复并继续成长。',
     '末试T4多扣3敌血却多损2玩家血；四试失败不支持固定输出血价或一律保血。',
     '睡眠与成长已有局部模拟；不将单轮减力视作关闭成长。',
     '缺伤害唤醒、眩晕接续和A10成长的完整冻结生产校准及同抽换序后继；四次相关失败不足拟合新血价或固定杀序。',
     '分阶段核睡层、唤醒/眩晕及期限；同起点完整后继再评换序，SL次数不增加独立局数。'),
]

sections = []
results = []
for suffix, location, facts, counter, current, reason, validation in items:
    ident = 'silent-proposal-' + suffix
    original = originals[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append(f'''## {ident}

{original['summary']}

- 来源任务：{original['source_task']}；实现任务：strategy-proposal；原账本：{'、'.join(original['ledger'])}。
- 证据局号/层/回合：{location}。
- 已核事实：{facts}
- 反例与限制：{counter}
- 当前规则和覆盖：{current}
- 本批处置：waiting。{reason}
- 预期行为与验证：{validation}
- 原Markdown及SHA：{HERE / (ident + '.md')}；指纹见proposal-provenance.json。
''')

proposal = f'''# 静默猎手十个原提案复核

记录时间：{STAMP}；batch={BATCH}；base={BASE}。

本批只处理已领取十个CLI id，十项均waiting，无新增源码或知识修改。六局均已按runs与state核为SILENT/A10。原日志八流6995行逐offset/bytes/SHA回读，37项材料断言通过；这些是发现样本内事实复核，不能记为生产测试或独立盲测。

本批不拟合新权重。已有窄实现保存实际base/live祖先证明；原提案余项仍须逐项验收。后续有新源码须固定输入撤源码失败、恢复通过，并经原沙箱入口自测、实际live合入核验；本批无源码红绿可报告。继续保留合法选项与模型选择权，相同推演值并列。

回退：本批仅报告和CLI追溯，无生产行为可回退。后续源码按对应实际提交回退；原日志、原提案、账本及失败记录保留。两个神化来源共享事实，不另建重复id，也不扩分母。

''' + '\n'.join(sections)
(HERE / 'proposal.md').write_text(proposal)
(HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} |" for m in manifest)
result_table = '\n'.join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
ancestors = json.loads((HERE / 'narrow-ancestor-readback.json').read_text())
ancestor_text = '\n'.join(f"- {r['commit']}：{r['subject']}。" for r in ancestors)
report = f'''# 静默猎手策略提案批次报告

记录时间：{STAMP}；batch={BATCH}。

本批十项均waiting。核实已有神化升级、候选事实和动作观测子项后，仍缺各提案指定的持续执行归属、联合生产校准或受控整战后继；没有隔离新的可修复数值失配。无源码或知识修改、提交、live合入、新版本或shipped。

## 身份与范围

开工git status为空，HEAD={BASE}；普通批git merge --no-edit main返回Already up to date，此后HEAD保持。根learn本批task/character/worktree、六runs及十proposal_ids匹配；没有research_request、implementation_request或proposal_repair。普通专题文件绑定另一旧批，本批不承接专题、不扩展队列，没有下级agent。

本批局号：{'、'.join(dispatch['runs'])}。runs六条及全部所属state均核SILENT/A10；六局最终均败，胜战与SL仍分别观察。只采用这六局和本角色原提案，不读其他角色知识。原dirty完整执行源码与知识不能由一个Git哈希复原；旧兼容字段不作为脑引擎身份证明。

## 原始证据与复核

共用extract_evidence.py提取八流，每流在打开时冻结独立source_size；显式run/run_id/state.run_id/fingerprint.run冲突拒收，不按正文提及收局。6995行全部从原日志按offset/bytes/SHA和JSON回读一致，原字节和计数均保留。

| 流 | source_size（字节） | 所属行数 |
|---|---:|---:|
{table}

states、decisions、brain全源各2行无效JSON保留计数，不能断言它们属于本六局；fight-plans零匹配仅说明该截点未选到，不能倒推日志缺失或动作未发生。八流选中封套SHA与071302原批完全相同，全源截点增长未增加本批独立证据；未覆盖旧报告或零行初稿。

十原Markdown均与队列add行SHA一致；队列物理offset/bytes/SHA、26条相关账本的原始行与正确CLI折叠语义均保存。初次只读简化展示将evidence/where当覆盖字段，未用于结论或写入；随后按ledger.apply的追加语义重折叠并保存ledger-current.json.gz。

718条目标状态与696条目标决策见selected-state-facts.json和selected-decision-facts.json。37项既有材料检查在本批新提取且回读的原字节上再次通过，包括神化能量/牌面、药水HP不变、蚌虚弱后成长、无毒冒泡零效果、负敏捷与毒、胧光分体净扣、甲虫减力期限和8JRE同指纹端点。检查不是tsc/vitest，也没有源码撤除负控。

## 既有消费者和源码

重新生成六个离线输入，与071302各解码输入逐字节一致；四个selection模块及递归JSON辅助依赖共五叶，在旧base、本树和实际live均逐SHA相同。六份原输出压缩/解码SHA复核后复用，未重新执行消费者、模型或模拟。完整来源与SHA见consumer-reuse.json。

六输出合计476段、3301条带ID动作、534轮窗，121个轮窗有观察端点，413个未知。CA5一条、61E一条、DUZU三条无decision_id的原元数据仍保存于完整输入，既有消费排除边界不变。actual_full_candidate_result均null属于工具认证范围，不能解释为实盘没有执行；整轮端点也不能直接归因给中途被重问替换的单个候选。

只读live观察提交={source['live_observed']}。13个相关生产叶中11个相同，card-model.ts和sl/explore.ts差异仅旧Roy/Dai署名注释，补丁原件保存。这不是全仓或历史dirty树等价证明。以下六窄源均核为本base及实际live祖先，changed_paths已保存，它们不是本批实现：

{ancestor_text}

当前actual_cast_this_fight仍null；神化对未验证属性/自动出牌等交互保留unknown；selection_dispatch只记录单动作回执，完整候选及因果结果未认证。现有窄功能不能替代原整项验收，也不能由旧测试绿色推出新量化规则。

## 逐项处置

| 原id | 状态 | 具体待补项 |
|---|---|---|
{result_table}

各项证据局号、层、回合、原账本、反例、当前覆盖、预期及验证方法见proposal.md。沿用十个真实CLI id；无新提案，无implemented/duplicate登记，无新增implementation_domains。未关闭量化、策略或学习入库父要求，也不宣称经验已入库或被大脑采用。

## 记录与验证

账本追溯登记状态以ledger-cli-receipt.json和ledger-readback.json为准；只经根learner/ledger.py update追加proposal/report和本批复核说明，by=learner:strategy-proposal。旧claim、首证、prior、evidence及status/version/shipped/effect保持，不把同一证据重登support/repeat，不降已shipped条目为proposed。队列处置交最终proposal_results，不手改队列或learn.json。

无源码改动，撤源码失败/恢复通过不适用；未运行生产tsc/vitest，tests={{"tsc":null,"vitest":null,"cases":null}}。无提交、merge或版本，无上线decision-log或规则双通知。其他角色行为保持原状。gitleaks与最终干净状态见final-checks.json。

限制：六局及多次SL均为已用于发现的相关样本；未知完整抽序、未选线后继和同随机池/预算实验不能靠现有端点补齐。宿主PID在工具进程命名空间不可见，未独立核实本批原生模型、推理强度及计费服务档，不把文档默认值当实际切换证明；未改运行配置。

只读查询曾猜测不存在的源码路径，rg/sed非零后改用rg --files定位；无产品故障或机制反例。未联网、不运行play、不读凭据/.env或游戏二进制、不改运维prompt、不推送。

交运维提案：{HERE / 'proposal.md'}。
完整报告：{HERE / 'report.md'}。
'''
(HERE / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposal': str(HERE / 'proposal.md'), 'report': result['report'], 'waiting': len(results)}, ensure_ascii=False))

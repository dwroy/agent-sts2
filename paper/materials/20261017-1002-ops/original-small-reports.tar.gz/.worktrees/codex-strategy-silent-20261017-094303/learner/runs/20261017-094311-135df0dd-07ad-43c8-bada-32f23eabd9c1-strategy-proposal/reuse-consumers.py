import gzip,hashlib,json,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
PRIOR=Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-071302/learner/runs/20261017-071308-6d71d601-4e5a-4b05-bc81-916a1398a654-strategy-proposal')
LIVE=Path('/home/dw/Projects/agent-sts2/.worktrees/live')
sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((PRIOR/'consumer-reuse.json').read_text())
source=old['source_modules']+[{'path':'agent/src/core/util/json.ts','prior_sha256':json.loads((PRIOR/'consumer-helper-readback.json').read_text())['sha256']}]
modules=[]
for s in source:
 p=s['path'];a=Path(p).read_bytes();b=(LIVE/p).read_bytes();c=subprocess.check_output(['git','show','6c3a776b741276285beb422d2f9be98c6112851a'+':'+p])
 assert sha(a)==s['prior_sha256']==sha(b)==sha(c),p
 modules.append({'path':p,'sha256':sha(a),'prior_base':'6c3a776b741276285beb422d2f9be98c6112851a','prior_and_live_match':True})
streams=[]
for meta in json.loads((HERE/'evidence/evidence-manifest.json').read_text()):
 previous=next(x for x in old['streams'] if x['stream']==meta['stream'])
 assert meta['counts']==previous['counts'] and meta['output_sha256']==previous['sha256'],meta['stream']
 streams.append({'stream':meta['stream'],'source_size':meta['source_size'],'prior_source_size':previous['source_size'],'counts':meta['counts'],'sha256':meta['output_sha256'],'same_selected_bytes':True})
consumers=[]
for item in json.loads((HERE/'consumer-input-manifest.json').read_text()):
 run=item['run_id'];raw=gzip.decompress((HERE/(run+'.consumer-input.json.gz')).read_bytes());oldraw=gzip.decompress((PRIOR/(run+'.consumer-input.json.gz')).read_bytes())
 assert raw==oldraw,run
 record=next(x for x in old['consumers'] if x['run_id']==run)
 packed=(PRIOR/(run+'.consumer-output.json.gz')).read_bytes();unpacked=gzip.decompress(packed)
 assert sha(packed)==record['output_packed_sha256'] and sha(unpacked)==record['output_raw_sha256']
 (HERE/(run+'.consumer-output.json.gz')).write_bytes(packed)
 output=json.loads(unpacked)
 consumers.append({'run_id':run,'source':str(PRIOR/(run+'.consumer-output.json.gz')),'input_sha256':sha(raw),'output_packed_sha256':sha(packed),'output_raw_sha256':sha(unpacked),'reexecuted':False,'counts':{k:len(v) for k,v in output.items() if isinstance(v,list)}})
result={'prior':str(PRIOR),'all_inputs_and_sources_match':True,'streams':streams,'source_modules':modules,'consumers':consumers,'note':'同冻结输入、四模块及JSON辅助依赖逐SHA一致后复用原离线输出；本批未执行消费者、模拟或生产测试。'}
(HERE/'consumer-reuse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'same_consumers':len(consumers),'same_source_modules':len(modules)},ensure_ascii=False))

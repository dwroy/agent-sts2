import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
BATCH = '20261017-094303-strategy-proposal'
spec = importlib.util.spec_from_file_location('task_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
props = json.loads((HERE / 'assigned-proposals.json').read_text())
related = {}
for ident, history in props.items():
    original = next(x['row'] for x in history if x['row'].get('op') == 'add')
    for item in original['ledger']:
        related.setdefault(item, []).append(ident)


def snapshot(raw):
    rows = []
    for n, line in enumerate(raw.splitlines(), 1):
        row = json.loads(line)
        if row.get('id') in related:
            rows.append((n, row))
    items = ledger.fold(rows)
    assert set(items) == set(related)
    assert all(x['character'] == 'silent' for x in items.values())
    return items


before = LEDGER.read_bytes()
before_items = snapshot(before)
(HERE / 'ledger-before.json.gz').write_bytes(gzip.compress(json.dumps(before_items, ensure_ascii=False).encode(), mtime=0))
updates = [
    {'id': item, 'by': 'learner:strategy-proposal',
     'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
     'note': f'{BATCH}：原提案{",".join(ids)}复核waiting；6995行原字节回读、37项材料核验；没有新增源码、证据或实现登记，具体待补项见proposal.md。'}
    for item, ids in sorted(related.items())
]
payload = ''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates)
(HERE / 'ledger-update.jsonl').write_text(payload)
date = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
result = subprocess.run([sys.executable, '-B', str(ROOT / 'learner/ledger.py'), 'update'],
                        input=payload, text=True, capture_output=True)
(HERE / 'ledger-update.stdout').write_text(result.stdout)
(HERE / 'ledger-update.stderr').write_text(result.stderr)
receipt = {'date_before_append': date, 'exit_code': result.returncode,
           'prefix_bytes': len(before), 'prefix_sha256': hashlib.sha256(before).hexdigest(),
           'input_sha256': hashlib.sha256(payload.encode()).hexdigest(), 'requested_ids': sorted(related)}
(HERE / 'ledger-cli-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
assert result.returncode == 0, result.stderr
after = LEDGER.read_bytes()
assert after.startswith(before)
after_items = snapshot(after)
(HERE / 'ledger-after.json.gz').write_bytes(gzip.compress(json.dumps(after_items, ensure_ascii=False).encode(), mtime=0))
protected = ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'shipped_at', 'effect']
for item in related:
    a, b = before_items[item], after_items[item]
    assert all(a.get(key) == b.get(key) for key in protected), item
    assert b['history'][:len(a['history'])] == a['history'], item
    assert b['notes'][:len(a['notes'])] == a['notes'], item
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values, (item, key)
    assert str(HERE / 'proposal.md') in b['where']['proposal']
    assert str(HERE / 'report.md') in b['where']['proposal']

physical = []
offset = len(before)
for line in after[len(before):].splitlines(keepends=True):
    row = json.loads(line)
    if row.get('id') in related and BATCH in row.get('note', '') and row.get('by') == 'learner:strategy-proposal':
        physical.append({'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert len(physical) == len(updates)
assert {x['row']['id'] for x in physical} == set(related)
(HERE / 'ledger-readback.json').write_text(json.dumps({
    'prefix_preserved': True, 'protected_fields_preserved': True,
    'only_trace_updates': True, 'updated_ids': sorted(related), 'appended_rows': physical,
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': result.returncode, 'trace_updates': len(physical),
                  'protected_fields_preserved': True}, ensure_ascii=False))

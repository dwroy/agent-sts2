import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', HERE.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
RUNS = json.loads((HERE / 'dispatch.json').read_text())['runs']


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


streams = {}
verification = []
for directory in ['evidence', 'evidence-additional']:
    for manifest in json.loads((HERE / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        output = HERE / directory / (stream + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = collections.Counter()
        records = []
        previous_offset = -1
        with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
            for raw in output.open('rb'):
                digest.update(raw)
                envelope = json.loads(raw)
                assert envelope['offset'] > previous_offset
                previous_offset = envelope['offset']
                assert envelope['offset'] + envelope['bytes'] <= manifest['source_size']
                source.seek(envelope['offset'])
                original = source.read(envelope['bytes'])
                assert hashlib.sha256(original).hexdigest() == envelope['sha256']
                row = json.loads(original)
                assert row == envelope['row']
                assert extract.run_identity(row) == envelope['run_id'] in RUNS
                assert Path(envelope['source']) == ROOT / 'logs' / (stream + '.jsonl')
                counts[envelope['run_id']] += 1
                records.append(envelope)
        assert digest.hexdigest() == manifest['output_sha256']
        assert {run: counts[run] for run in RUNS} == manifest['counts']
        streams[stream] = records
        verification.append({**manifest, 'verified_rows': len(records), 'raw_bytes_verified': True})

write('envelope-verification.json', verification)
states = collections.defaultdict(list)
for item in streams['states']:
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    assert run.get('character_id') == 'SILENT' and run.get('ascension') == 10
    states[item['run_id']].append(item)
assert {x['run_id'] for x in streams['runs']} == set(RUNS)
for item in streams['runs']:
    assert item['row']['character'] == 'SILENT' and item['row']['ascension'] == 10
write('run-identities.json', [item['row'] for item in streams['runs']])


def slim(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'ts': item['row']['ts'], 'floor': run.get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'in_combat': state.get('in_combat'),
        'hp': player.get('current_hp', run.get('current_hp')), 'block': player.get('block'),
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'), 'text': c.get('resolved_rules_text')}
                 for c in combat.get('hand', [])],
        'player_powers': {p['power_id']: p['amount'] for p in player.get('powers', [])},
        'potions': [{'index': p.get('index'), 'id': p.get('potion_id'), 'occupied': p.get('occupied')}
                    for p in run.get('potions', [])],
        'enemies': [{
            'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
            'alive': e.get('is_alive'), 'block': e.get('block'), 'move': e.get('move_id'),
            'powers': {p['power_id']: p['amount'] for p in e.get('powers', [])},
            'intents': e.get('intents'),
        } for e in combat.get('enemies', [])],
    }


decisions = {item['line']: item for item in streams['decisions']}
pair_lines = [(272434, 272575), (272531, 272652), (272483, 272820),
              (273400, 273450), (274505, 274568), (274484, 274601)]
pairs = []
selected_states = {}
for first, second in pair_lines:
    one, two = decisions[first], decisions[second]
    assert one['run_id'] == two['run_id']
    assert one['row']['fingerprint'] == two['row']['fingerprint']
    outcomes = []
    for item in [one, two]:
        decision = item['row']
        candidates = [s for s in states[item['run_id']]
                      if s['row']['fingerprint'] == decision['fingerprint'] and
                      s['row']['ts'] <= decision['ts']]
        assert candidates
        before = candidates[-1]
        floor, turn = decision['floor'], decision['turn']
        later = [s for s in states[item['run_id']] if s['line'] > before['line'] and
                 (s['row']['state'].get('run') or {}).get('floor') == floor and
                 s['row']['state'].get('in_combat') and s['row']['state'].get('turn') == turn + 1]
        assert later
        after = later[0]
        a, b = slim(before), slim(after)
        selected_states[before['line']] = a
        selected_states[after['line']] = b
        hp_loss = a['hp'] - b['hp']
        enemy_net = sum(e['hp'] for e in a['enemies']) - sum(e['hp'] for e in b['enemies'])
        chosen_key = ((decision.get('answers') or {}).get('plan') or {}).get('choice')
        criteria = ((decision.get('questions') or {}).get('plan') or {}).get('criteria') or {}
        outcomes.append({
            'decision_line': item['line'], 'attempt': decision.get('sl_attempt') or 1,
            'state_before': a['line'], 'state_next_turn': b['line'],
            'player_hp_before': a['hp'], 'player_hp_after': b['hp'],
            'observed_turn_hp_loss': hp_loss, 'observed_enemy_net_hp_reduction': enemy_net,
            'next_turn_enemy_powers': [e['powers'] for e in b['enemies']],
            'chosen_action_receipt': decision.get('result'),
            'chosen_plan_fact': json.loads(criteria[chosen_key]) if chosen_key in criteria else None,
            'sl_explore': decision.get('sl_explore'),
            'attribution': 'whole observed turn including later actions; not proof every planned step executed',
        })
    pairs.append({'run': one['run_id'], 'floor': one['row']['floor'], 'turn': one['row']['turn'],
                  'same_fingerprint': True, 'observed': outcomes})
write('paired-observations.json', pairs)

expected = [((13, 18), (9, 18)), ((13, 23), (12, 18)), ((8, 2), (17, 11)),
            ((0, 0), (36, 29)), ((15, 21), (2, 4)), ((7, 5), (1, 2))]
for pair, (loss, damage) in zip(pairs, expected):
    assert tuple(o['observed_turn_hp_loss'] for o in pair['observed']) == loss
    assert tuple(o['observed_enemy_net_hp_reduction'] for o in pair['observed']) == damage

giant = []
for run in RUNS:
    for item in states[run]:
        state = item['row']['state']
        if item['line'] in {280160, 280161, 280162}:
            selected_states[item['line']] = slim(item)
        if (state.get('run') or {}).get('floor') != 17 or not state.get('in_combat'):
            continue
        enemies = (state.get('combat') or {}).get('enemies') or []
        if any(e.get('enemy_id') == 'WATERFALL_GIANT' and e.get('max_hp') == 999999999 for e in enemies):
            giant.append({'run': run, **slim(item)})
write('giant-phase-observations.json', giant)
before, after = selected_states[280160], selected_states[280161]
assert before['enemies'][0]['powers']['POISON_POWER'] == 2
assert after['enemies'][0]['powers']['POISON_POWER'] == 8
for snapshot in [before, after]:
    assert snapshot['hp'] == 26 and snapshot['block'] == 13
    assert snapshot['enemies'][0]['intents'][0]['total_damage'] == 41

potions = []
for line in [274131, 274156, 274185, 274235, 274237, 274267, 274272]:
    item = decisions[line]
    row = item['row']
    chosen = row['chosen']
    assert chosen['action'] == 'use_potion' and item['run_id'] == 'KEN58SH9SLZ6'
    before = [s for s in states[item['run_id']] if s['row']['fingerprint'] == row['fingerprint']
              and s['row']['ts'] <= row['ts']][-1]
    after = next(s for s in states[item['run_id']] if s['line'] > before['line'])
    a, b = slim(before), slim(after)
    slot = chosen['option_index']
    pa = next(p for p in a['potions'] if p['index'] == slot)
    pb = next(p for p in b['potions'] if p['index'] == slot)
    assert pa['occupied'] is True and pb['occupied'] is False
    selected_states[before['line']] = a
    selected_states[after['line']] = b
    potions.append({'run': item['run_id'], 'decision_line': line, 'floor': row['floor'],
                    'turn': row['turn'], 'slot': slot, 'potion': pa['id'],
                    'state_before': before['line'], 'state_after': after['line'],
                    'receipt': row.get('result'), 'slot_consumed': True,
                    'full_candidate_effect_attribution': None})
write('potion-observations.json', potions)

attempts = []
for item in streams['sl-attempts']:
    row = item['row']
    attempts.append({
        'line': item['line'], 'run': item['run_id'], 'floor': row.get('floor'),
        'attempt': row.get('attempt'), 'encounter': row.get('encounter'),
        'result': row.get('result'), 'turns': row.get('turns'),
        'end_hp': row.get('end_hp'), 'end_block': row.get('end_block'),
        'incoming': row.get('incoming'),
        'last_turn': (row.get('summary', {}).get('turns') or [None])[-1],
        'anchor': ((row.get('explore') or {}).get('target') or {}).get('anchor'),
    })
write('attempt-observations.json', attempts)
write('selected-states.json', [selected_states[line] for line in sorted(selected_states)])
write('key-decisions.json', [decisions[line] for line in sorted({n for p in pair_lines for n in p} |
      {272361, 272362, 274087, 274131, 274156, 274185, 274235, 274237, 274267, 274272})])

summary = {
    'runs': RUNS, 'verified_envelopes': sum(len(v) for v in streams.values()),
    'counts': {name: dict(collections.Counter(e['run_id'] for e in values)) for name, values in streams.items()},
    'paired_comparisons': [{'run': p['run'], 'floor': p['floor'], 'turn': p['turn'],
                            'hp_loss': [o['observed_turn_hp_loss'] for o in p['observed']],
                            'enemy_net_reduction': [o['observed_enemy_net_hp_reduction'] for o in p['observed']]}
                           for p in pairs],
    'potion_uses_verified': len(potions),
    'pending_potion_receipts': sum('pending' in p['receipt'] for p in potions),
    'actual_full_candidate_effect_attribution': None,
    'controlled_complete_fight_comparison': None,
    'production_tests_run': False,
}
write('evidence-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))

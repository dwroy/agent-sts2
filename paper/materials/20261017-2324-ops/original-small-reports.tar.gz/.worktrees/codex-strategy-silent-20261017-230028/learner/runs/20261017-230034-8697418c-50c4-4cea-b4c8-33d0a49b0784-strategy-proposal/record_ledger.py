import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
ledger = ROOT / 'paper/materials/learning/ledger.jsonl'
inputs = (HERE / 'ledger-updates.jsonl').read_text()
updates = [json.loads(line) for line in inputs.splitlines()]
ids = {row['id'] for row in updates}
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def selected_entries():
    return module.fold([(number, row) for number, row in module.read_rows(str(ledger))
                        if isinstance(row, dict) and row.get('id') in ids])


def protected():
    entries = selected_entries()
    keys = ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note',
            'prior_runs', 'evidence', 'status', 'version', 'effect']
    return {ident: {key: entry.get(key) for key in keys} for ident, entry in entries.items()}


def digest(data):
    return hashlib.sha256(data).hexdigest()


before = protected()
prefix = ledger.read_bytes()
size = len(prefix)
prefix_sha = digest(prefix)
del prefix
date = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
(HERE / 'ledger-date.txt').write_text(date + '\n')
environment = dict(os.environ)
environment.update(LEDGER_FILE=str(ledger), LEDGER_RUNS=str(ROOT / 'logs/runs.jsonl'),
                   LEDGER_VERSIONS=str(ROOT / 'eval/versions.json'))
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                        input=inputs, text=True, capture_output=True, env=environment)
(HERE / 'ledger-cli.log').write_text(result.stdout + result.stderr)
receipt = {'checked_at': date, 'cli_exit': result.returncode, 'before_size': size,
           'before_prefix_sha256': prefix_sha, 'expected_ids': sorted(ids)}
assert result.returncode == 0
after = protected()
with ledger.open('rb') as handle:
    original_prefix = handle.read(size)
    tail = handle.read()
receipt.update(prefix_preserved=digest(original_prefix) == prefix_sha,
               protected_fields_preserved=before == after,
               tail_sha256=digest(tail), tail_bytes=len(tail))
own = [row for line in tail.splitlines() if line.strip()
       for row in [json.loads(line)] if row.get('id') in ids and
       row.get('by') == 'learner:strategy-proposal' and
       row.get('where', {}).get('proposal') == [str(HERE / 'proposal.md'), str(HERE / 'report.md')]]
receipt['own_rows'] = len(own)
receipt['own_ids'] = sorted(row['id'] for row in own)
assert receipt['prefix_preserved'] and receipt['protected_fields_preserved']
assert len(own) == len(ids) == 16 and {row['id'] for row in own} == ids
assert all(set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for row in own)
entries = selected_entries()
assert all(str(HERE / 'report.md') in entry['where']['proposal'] for entry in entries.values())
receipt['trace_links_read_back'] = True
(HERE / 'ledger-update-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

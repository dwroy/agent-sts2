import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
dispatch = json.loads((HERE / 'dispatch.json').read_text())
proposals = json.loads((HERE / 'dispatched-proposals.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
summary = json.loads((HERE / 'evidence-summary.json').read_text())

details = [
    {
        'evidence': '751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820。六组原/后帧见 paired-observations.json；本项实际是同局三对。',
        'finding': '同指纹实损13→18、13→23、8→2；敌方净扣9→18、12→18、17→11。持牌惩罚与配对B2预测须分别记，不把所有额外输出都叫免费探索。',
        'counter': 'T13省6血同时少6净扣；T2的B2差在配对误差内。六次重打属于一个局且全败，不能由局部差值推定固定门槛或整战收益。',
        'reason': '751 F17 T2/T7/T13局部血价已核；已有SL预测成本诊断，仍缺逐来源实际结算、完整候选执行归属及固定后续整战对照，不能拟探索门槛。',
        'validation': '保留三对同指纹原题、原答、替线及续问；补完整候选逐动作归属、持牌与敌伤分源、同种子且固定后续的整战对照，再以较晚独立Silent局验证。',
    },
    {
        'evidence': '751FN9QM9MHQ F13 T3 decisions 272361/272362；F17 T7/T13/T17与 silent-0176 所列原帧。',
        'finding': 'F13 plan2用药与plan5整战无药参考的当轮预测均损8，伤26/16，五回合各8/8模拟胜；plan3仅当轮不喝，后续7/8样本喝药，不能和plan5混同。实际只执行用药支线。',
        'counter': 'F17 T7弃牌确定后保守持牌损血可以变化；模型中持牌失血不能直接当已结算敌伤。F13无药8/8是模拟，未实际保留该瓶到Boss。',
        'reason': '751 F13 T3实际只执行用药支线；持牌及未知持有价、无药参考已展示，仍缺未决弃牌后的完整收益分源、不喝及留药后战实果。',
        'validation': '用F13同题分别保留当轮不喝与整战无药参考；待弃牌确定后核实际手牌和续步，补本角色跨战留药对照，不由缺表成本0拟合持有价。',
    },
    {
        'evidence': '同366288801d9150d9的751FN9QM9MHQ F17 T2/T7/T13；来源experience-update原Markdown及其SHA已核。',
        'finding': '与首项共用同一局三组局部对照。已有经验和诊断记录不产生新的独立样本。',
        'counter': '原线、换线的后续抽序及动作变化；同局六试不能分别用作训练和验证。',
        'reason': '共享751同局三组对照；预测与单动作回执仍不能认证完整候选的实际执行成本，缺受控整战及独立验证，不新增重复实现。',
        'validation': '沿原首项补逐来源实际结算及受控后继；保留本经验来源链接，不新建重复代码提案或重复计数。',
    },
    {
        'evidence': '751FN9QM9MHQ F13 T3、F17 T3/T5/T7/T13/T17；原Markdown的九个账本及九个经验链接已逐项读取。',
        'finding': '已有持牌保守预测、持有价值未知及无药参考。原经验将敏捷、直伤、毒、荆棘与持牌失血分列，不能由单一总血差认证全部来源。',
        'counter': 'F17 T17没有挡牌时已建敏捷不自动给挡；无实体、毒与反伤存在分源限制。相关字段存在不等于联合结算已被完整验证。',
        'reason': '已有持牌失血、未知持有价和无药参考子项；仍缺敏捷、毒、荆棘及未决弃牌的完整实际收益归属，以及跨战留药对照。',
        'validation': '固定各子机制的实际牌序与轮末结算，分别核兑现来源和分母；补完整候选及后续资源，跨战持有价保持未知。',
    },
    {
        'evidence': 'KV0JHNJCKXLS F33 第4/5试T5 decisions 273400/273450，后续补打被273451阻止；states 279460→279465、279511→279515。',
        'finding': '同指纹原/替线当轮净损均0，敌净扣36→29；下一轮毒20→13。删输出没有在该轮得到已观察的保血收益。',
        'counter': '两试后轮动作也变且都失败；敌方回血意味着净扣不等毛伤。路线与休息实际回复不能代替未走路线反事实。',
        'reason': 'KV F33 T5同指纹扣敌36→29、均零净损；已有预测资源对照，仍缺敌回血与能力完整结算归属、受控胜线及独立验证，不改SL或路线门槛。',
        'validation': '分开实毒、回血、毛/净扣血与未结算轮；固定其余后继后比较完整原/替线，并保留实际休息、开场回复、SL恢复的不同来源。',
    },
    {
        'evidence': 'YQL8RZ8BWN1E F17 T10 decisions 274087、states 280160/280161；L9SGRBB5R698 sl-attempts 681、PU80F84P6HPN 717、YQL 960—963。',
        'finding': '末次毒水让残壳毒2→8，血26/挡13/当前自爆41不变。旧anchor确实使用近十亿占位血；live已补阶段及本体0的说明，旧参考排序明确保留。',
        'counter': '本体结束不等胜；26+13−41=−2与死亡帧截断0分别保存。PU有胜试但多处后继变化；归零排序可能改变平局选择，不能当已证改善。',
        'reason': 'YQL F17 T10毒2→8而血26、挡13、来袭41不变；阶段子项已有，仍缺完整后继下的受控改序、最终自爆资源及提前用药验证，不直接归零占位HP改序。',
        'validation': '保原始HP及阶段字段，覆盖未知状态与本体未清状态；若改参考排序，保存原/新选择及完整后继、自爆最终资源和药水时点结果。',
    },
    {
        'evidence': '与e18d3f18e6cac2a0共用YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN F17；本项原经验提案SHA已核。',
        'finding': 'PU sl-attempts 719 第5试T15记won、余2血；YQL六试未胜。它们支持阶段与资源分列，没有隔离排序、药时或路线的单因素收益。',
        'counter': 'PU胜试并非只换一个排序规则，原参考更长存活也未赢。阶段说明不构成宽提案的终局/SL/药水完整交付。',
        'reason': '共享YQL/L9/PU阶段证据；已有阶段事实，PU胜线多处动作同变，仍缺改序、提前用药和路线的受控验证，不把子项当整项完成。',
        'validation': '沿阶段提案保存相同冻结材料与原经验链；补受控后继及独立局，不新增重复ID或据一条胜试拟合终局权重。',
    },
    {
        'evidence': 'KEN58SH9SLZ6 F3 T2、F4 T1、F5 T2、F11 T1/T2、F15 T1；decisions 274131/274156/274185/274235/274237/274267/274272及对应逐槽前后帧。',
        'finding': '七次use_potion请求逐一匹配有药→空槽。其中两次攻击药及技能药共三条回执为pending，后帧确认槽位消耗，不把pending本身称完整候选已执行。',
        'counter': 'F15零净损同时消耗两瓶，不证明不喝也零损；F17空药入口不证明留药必胜。随机选牌、发光水后重问与收益归属不能由空槽单独认证。',
        'reason': 'KEN七次请求及槽位消耗已核；仍缺随机选牌、发光水重问后完整候选收益归属，以及不喝或留至Boss的支线，不能拟持有价。',
        'validation': '补饮用后随机选牌、获得牌/能力、实际施放与重问全链；将当轮和跨战使用/未使用分开，保持七次逐槽审计，不估固定留药价。',
    },
    {
        'evidence': 'KEN58SH9SLZ6 F17 第4/5试T10 decisions 274505/274568，states 280588→280592/280651→280655；第4/6试T5 decisions 274484/274601。',
        'finding': 'T10同盘实损15→21，敌净扣2→4，B2 .385→.127，配对差−.2583/SE .0132。T5实损7→5、敌净扣1→2，但步法建立由T5延至T9。',
        'counter': '省血线延后能力，新增攻击也付出持牌血价；两种相反取舍都不能单独推出更优整战排序。后续尝试动作不固定。',
        'reason': 'KEN F17 T10实损15→21、净扣2→4；T5省2血却延步法至T9。已有预测成本子项，仍缺完整候选与能力收益归属、固定后续整战及独立验证。',
        'validation': '保持原HP护栏与探索；逐动作核持牌失血、无实体分段输出和能力兑现时点，再做固定后续及较晚独立局验证。',
    },
    {
        'evidence': '同86a7db08d1a31976的KEN58SH9SLZ6 F17 T10/T5；sl-attempts 964—969核步法首建轮3/5/5/5/5/9。',
        'finding': '本项与上一项共用一个局的两对局面。六次SL是相关尝试，不能扩成六局证据或独立验证集。',
        'counter': '省2血伴能力延后、付6血只多2实伤均已核，但没有保持其余后轮不变的受控胜线。',
        'reason': '共享KEN同局两组对照；六次SL不当六局，仍缺受控整战与后期独立验证，不拟统一6血/2伤阈值或重复实现诊断。',
        'validation': '沿上一项补完整候选归属及后继，原来源和经验链接分别保留；不得用KEN同时拟合和宣称独立胜率验证。',
    },
]
assert len(details) == len(proposals) == 10
results = [{'id': p['id'], 'state': 'waiting', 'reason': d['reason']} for p, d in zip(proposals, details)]
report = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-230028-strategy-proposal',
    'base': source['base'], 'runs': dispatch['runs'], 'fixes': [],
    'skipped': [],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
(HERE / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

paragraphs = [
    '# 本批策略提案处置', '',
    f'写入前时间：{now}。任务 strategy-proposal，角色 silent，批次 20261017-230028-strategy-proposal。', '',
    '只消费派发的10个原ID；无 research_request / implementation_request。本文件是本次复核与未完成部分的说明，原Markdown、原经验及原提案ID均保持。', '',
    f'源码基线 `{source["base"]}`；只读 live 快照 `{source["live_snapshot"]}`。本次无新源码提交、无合入、无版本；不将已有窄实现认作宽提案全部完成。', '',
]
for p, d in zip(proposals, details):
    paragraphs += [f'## {p["id"]}', '',
        f'来源：{p["source_task"]} → strategy-proposal；领域：{", ".join(p["domains"])}；范围：静默猎手已观察A10。', '',
        f'既有账本：{", ".join(p["ledger"])}。原提案：`{p["proposal"]}`；SHA256 `{p["proposal_sha256"]}`。', '',
        '证据：' + d['evidence'], '', '本次复核：' + d['finding'], '',
        '反例与未知：' + d['counter'], '',
        '旧规则与预期行为：保留当前出牌、药水、探索、终局及参考排序。已有事实诊断继续使用；本批没有据证据补出新权重、门槛或强制动作。', '',
        '处置：waiting。' + d['reason'], '',
        '验证方法与重派所需：' + d['validation'], '',
        '拟合/切分：本批只复核冻结局面，不拟合参数；将同局全部SL放在同一时间分组，规则研究须另有较晚独立局验证。', '',
        '预期影响与回退：仅补可追溯记录，未证明胜率收益；无行为改动可回退，不回退既有live源码。未来实现按独立提交及原自测/live流程。', '',
    ]
(HERE / 'proposal.md').write_text('\n'.join(paragraphs))

rows = ['| 局号 | 状态 | 决策 | SL记录 | 计划 | brain |', '|---|---:|---:|---:|---:|---:|']
for run in dispatch['runs']:
    rows.append('| ' + run + ' | ' + ' | '.join(str(summary['counts'][k].get(run, 0))
                 for k in ['states', 'decisions', 'sl-attempts', 'run-plans', 'brain']) + ' |')
pairs = ['| 局号/层/回合 | 决策行 | 原/替实损 | 原/替敌净扣 |', '|---|---|---|---|']
for p in json.loads((HERE / 'paired-observations.json').read_text()):
    pairs.append(f'| {p["run"]} F{p["floor"]} T{p["turn"]} | ' +
                 '/'.join(str(o['decision_line']) for o in p['observed']) + ' | ' +
                 '→'.join(str(o['observed_turn_hp_loss']) for o in p['observed']) + ' | ' +
                 '→'.join(str(o['observed_enemy_net_hp_reduction']) for o in p['observed']) + ' |')
dispositions = ['| 派发ID | 处置及具体缺口 |', '|---|---|']
for r in results:
    dispositions.append(f'| {r["id"]} | waiting；{r["reason"]} |')

text = f'''# 静默猎手策略队列复核报告

写入前时间：{now}。本批10项均waiting；没有新增源码、经验规则、提交、live合入或发布版本。各原提案的完整证据、账本、反例、预期行为及验证方法见同目录 proposal.md。

## 身份与范围

本批 `{report['batch']}`，task=strategy-proposal、character=silent；learn.json工作树、六局集合及10个proposal_ids均与派发一致，无research_request、implementation_request或proposal_repair。普通专题请求绑定另一批次，不适用本批；没有读取其他专题代替任务。

开工HEAD为9eea5fea5e30621e7297dcb72e51f1d2bf2665a9，git status干净。按普通批次要求合入main，实际fast-forward到完整基线 `{source['base']}`。仅带入既有记录，未产生本任务提交。报告以该完整提交为base。已读README、最新STATE-2026-10-17、decision-log末尾、学习协议及代码提案闭环。

只分析本角色六局、原提案及knowledge/characters/silent关联条目；未借用其他角色知识，也未将知识库中的更广支持集合冒充本批独立分析。六局runs.jsonl均SILENT/A10，历史brain来源按原记录保留，不据本批计算当前纯Codex爬塔成绩。

## 原日志与可复核数字

共用extract_evidence入口完成八流抽取，保留每流source_size与逐行offset/bytes/SHA，正式audit_evidence.py对全部8,444封套逐一读回原字节、身份、JSON与输出SHA，退出0。角色与进阶对全部4,167状态及六条runs记录再次校验。没有将正文提及当所属局。默认六流在evidence/，runs及fight-plans在evidence-additional/，两份manifest独立保留。

{chr(10).join(rows)}

另有每局run-config与runs各1条。fight-plans在本次2,233,957字节截点选中0条，仅表示该截点未选到这些显式身份，不断言日志缺失；run-plans为21条而非零行。states/decisions/brain全源各有2条非法JSON计数，原manifest保留，没有将其改写成这些六局缺帧的结论。无旧截点报告被覆盖。

{chr(10).join(pairs)}

六对均原始fingerprint完全相等；表中敌净扣包含实际该轮毒/反伤/后来追加动作，不冒称全部是卡牌直接伤害或完整原候选已兑现。逐帧出处、题面预测、B2差/误差、动作回执和未知归属保存在paired-observations.json、selected-states.json与key-decisions.json。

751 F13 T3明确无药plan5和用药plan2均为五回合8/8模拟胜；plan3后续7/8样本会喝，不能当整战无药。实盘仅用药分支，缺表成本0不等于已证留药价值0。KEN七次use_potion都有有药→空槽，三条请求回执为pending；后帧确认消耗，未据此认证全部随机选择和方案收益。KEN步法首建轮3/5/5/5/5/9已用六条原SL summary核回。

YQL F17 T10毒2→8而血26/挡13/来袭41均不变；26+13−41=−2与随后死亡帧0分列。L9 sl681、PU sl717、YQL sl960—963确实含近十亿占位anchor血。PU第五试sl719实记T15胜余2血，但后续动作多处改变；不作排序或提前用药的单因素受控胜线。

## 当前实现及剩余缺口

只读live快照 `{source['live_snapshot']}`。13个相关源码叶已核base/live blob或SHA与实际工作区字节；其中4叶差异的完整patch已保留，均为Roy/Dai注释称呼，不改本次所核执行逻辑。source-readback.json保存真实祖先布尔；没有修改当年标dirty的源码或假称恢复原dirty树。

- a8b1f8be153fe4f3a34146117546c2178f2e446b：已集成选线审计/初始SL资源诊断；silent-selection-audit明确是predicted_candidates，actual_turn仍null，不能认证完整实际候选。
- 1698adc96ba434a46942321e0237b70657e625b2、0e4fe4df89a06682468e0e4716c12126e76369d5：SL预测资源差分及后续窄扩充；execution=unverified，B2配对数由原sl_explore另列。不是逐来源实际伤害归属。
- 04921bd785ac6838066522f91ea0bb6ab95cb6a1：未知持有价与同题无药预测参考，保留null和无药范围，未拟合本批跨战药价。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：呼唤持牌预测/未决弃牌分列，actual_held_hp_loss仍null，不虚构确定弃牌。
- a83d9ab675560a177249aa638e99df40bcfb5553、0d092f6b928a6221eabf3516abad25c48ceaac9c、d5e20aa4dd44168ce30944dfcce74f8322144953：本体/自爆阶段、限定最终资源及药水观察说明。enemyHpLeft/anchorRank仍保留旧占位HP平局次序；限定最终资源不外推到未满足条件的YQL输入。

上述八个提交全部是所核实际live祖先，仅作为已有窄子项证据。本批10项仍含未完成的实际归属、联合校准、受控后继或较晚独立验证，不能整项报duplicate/implemented。

{chr(10).join(dispositions)}

## 账本、验证与交付边界

不新建重复提案ID、不重写历史复盘、不追加重复游戏支持/反例；本次只经根目录ledger.py update为16个既有账本增加proposal/report追溯与本批处置说明。保留claim、first_run、asc、prior、evidence、status、version与effect，不把历史shipped改成proposed，也不代ops标新shipped。CLI退出码、追加字节与读回见ledger-cli.log、ledger-update-receipt.json；这是追溯记录，不表示经验已新增入库或消费者已采用新策略。code_proposals沿用原CLI产生的10个ID，队列waiting由调用方消费proposal_results。

本批仅scratch证据分析，没有生产源码变更。tsc/vitest/cases均null，未运行沙箱全套、LLM、网络、模拟池或play；撤源码失败/恢复通过不适用，不借历史绿色或材料断言冒称生产测试。原字节审计、六对差分、七槽消费和能力时点核验退出0；它们只是证据核对。探索性只读脚本的combat=null错误及旧猜测路径错误保留于exploratory-read-notes.md。账本包装脚本首次因read_rows返回元组而在CLI前只读预检退出1，原脚本及失败记录保留，修正后CLI与字段读回结果单列；未改根CLI或账本格式。这些不是生产失败或机制反证。

无源码提交/合入/版本，merge=live的源码发布流程不触发，不通知已上线，不关闭父学习要求。production source.diff.patch为空，最终git status干净；根账本例外变动仅CLI追加。最终验收与材料哈希另存final-validation.json及artifact-manifest.json。gitleaks只扫描本批材料，结果另存gitleaks.log/JSON，不读取任何key或.env。

## 限制与下一步证据

1. 同局SL为相关尝试；六对只是三局中的局部窗，不是六场独立实验。没有用同局分别训练和验证。
2. 本批没有固定其余后轮的受控整战新证据，没有拟合权重、药水持有价、SL额外血价或终局排序参数。新局与受控后继仍须区分实盘和模拟。
3. 单动作回执、槽位消耗、选线预测与完整方案收益分属不同证据。actual_turn/完整收益归属仍未知，未填0。
4. 原本体阶段说明、低层公式与现行探索允许更差未试线分别保留；本任务没有新机制异议或反证，不制造需通知的游戏结论。
5. 不证明本批能提高胜率、改变路线/药时可赢，或其他角色/未观察进阶已验证。后续重派按每项具体缺口补数据，原失败、等待及原源码身份保持。

提案交付路径：{HERE / 'proposal.md'}

机器回报：{HERE / 'report.json'}
'''
(HERE / 'report.md').write_text(text)

ledger_before = json.loads((HERE / 'ledger-before.json').read_text())
updates = []
for ident in sorted(ledger_before):
    linked = [r for p, r in zip(proposals, results) if ident in p['ledger']]
    updates.append({
        'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
        'note': '20261017-230028-strategy-proposal：本批仅复核与补追溯；' +
                '；'.join(r['id'] + '=waiting：' + r['reason'] for r in linked) +
                '。未改源码/规则、未合入、不新增支持或反例、不标shipped，原保护字段保持。',
    })
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'base': report['base'], 'proposals': len(results), 'ledger_links': len(updates),
                  'report': report['report'], 'proposal': str(HERE / 'proposal.md')}, ensure_ascii=False))

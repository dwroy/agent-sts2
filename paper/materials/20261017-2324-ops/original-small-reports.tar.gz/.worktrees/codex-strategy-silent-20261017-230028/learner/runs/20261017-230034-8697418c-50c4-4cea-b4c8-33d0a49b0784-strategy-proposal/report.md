# 静默猎手策略队列复核报告

写入前时间：2026-10-17 23:19:10 CST。本批10项均waiting；没有新增源码、经验规则、提交、live合入或发布版本。各原提案的完整证据、账本、反例、预期行为及验证方法见同目录 proposal.md。

## 身份与范围

本批 `20261017-230028-strategy-proposal`，task=strategy-proposal、character=silent；learn.json工作树、六局集合及10个proposal_ids均与派发一致，无research_request、implementation_request或proposal_repair。普通专题请求绑定另一批次，不适用本批；没有读取其他专题代替任务。

开工HEAD为9eea5fea5e30621e7297dcb72e51f1d2bf2665a9，git status干净。按普通批次要求合入main，实际fast-forward到完整基线 `eb6b1bb19cd5fee0f89e0e2519b84ba5364cc8c3`。仅带入既有记录，未产生本任务提交。报告以该完整提交为base。已读README、最新STATE-2026-10-17、decision-log末尾、学习协议及代码提案闭环。

只分析本角色六局、原提案及knowledge/characters/silent关联条目；未借用其他角色知识，也未将知识库中的更广支持集合冒充本批独立分析。六局runs.jsonl均SILENT/A10，历史brain来源按原记录保留，不据本批计算当前纯Codex爬塔成绩。

## 原日志与可复核数字

共用extract_evidence入口完成八流抽取，保留每流source_size与逐行offset/bytes/SHA，正式audit_evidence.py对全部8,444封套逐一读回原字节、身份、JSON与输出SHA，退出0。角色与进阶对全部4,167状态及六条runs记录再次校验。没有将正文提及当所属局。默认六流在evidence/，runs及fight-plans在evidence-additional/，两份manifest独立保留。

| 局号 | 状态 | 决策 | SL记录 | 计划 | brain |
|---|---:|---:|---:|---:|---:|
| 751FN9QM9MHQ | 624 | 615 | 6 | 2 | 15 |
| KV0JHNJCKXLS | 686 | 669 | 7 | 5 | 32 |
| YQL8RZ8BWN1E | 582 | 571 | 6 | 3 | 18 |
| L9SGRBB5R698 | 653 | 635 | 6 | 3 | 16 |
| PU80F84P6HPN | 1064 | 1033 | 12 | 5 | 31 |
| KEN58SH9SLZ6 | 558 | 548 | 6 | 3 | 18 |

另有每局run-config与runs各1条。fight-plans在本次2,233,957字节截点选中0条，仅表示该截点未选到这些显式身份，不断言日志缺失；run-plans为21条而非零行。states/decisions/brain全源各有2条非法JSON计数，原manifest保留，没有将其改写成这些六局缺帧的结论。无旧截点报告被覆盖。

| 局号/层/回合 | 决策行 | 原/替实损 | 原/替敌净扣 |
|---|---|---|---|
| 751FN9QM9MHQ F17 T2 | 272434/272575 | 13→18 | 9→18 |
| 751FN9QM9MHQ F17 T7 | 272531/272652 | 13→23 | 12→18 |
| 751FN9QM9MHQ F17 T13 | 272483/272820 | 8→2 | 17→11 |
| KV0JHNJCKXLS F33 T5 | 273400/273450 | 0→0 | 36→29 |
| KEN58SH9SLZ6 F17 T10 | 274505/274568 | 15→21 | 2→4 |
| KEN58SH9SLZ6 F17 T5 | 274484/274601 | 7→5 | 1→2 |

六对均原始fingerprint完全相等；表中敌净扣包含实际该轮毒/反伤/后来追加动作，不冒称全部是卡牌直接伤害或完整原候选已兑现。逐帧出处、题面预测、B2差/误差、动作回执和未知归属保存在paired-observations.json、selected-states.json与key-decisions.json。

751 F13 T3明确无药plan5和用药plan2均为五回合8/8模拟胜；plan3后续7/8样本会喝，不能当整战无药。实盘仅用药分支，缺表成本0不等于已证留药价值0。KEN七次use_potion都有有药→空槽，三条请求回执为pending；后帧确认消耗，未据此认证全部随机选择和方案收益。KEN步法首建轮3/5/5/5/5/9已用六条原SL summary核回。

YQL F17 T10毒2→8而血26/挡13/来袭41均不变；26+13−41=−2与随后死亡帧0分列。L9 sl681、PU sl717、YQL sl960—963确实含近十亿占位anchor血。PU第五试sl719实记T15胜余2血，但后续动作多处改变；不作排序或提前用药的单因素受控胜线。

## 当前实现及剩余缺口

只读live快照 `deb9135b8c8e63080beae091b959a04738c64587`。13个相关源码叶已核base/live blob或SHA与实际工作区字节；其中4叶差异的完整patch已保留，均为Roy/Dai注释称呼，不改本次所核执行逻辑。source-readback.json保存真实祖先布尔；没有修改当年标dirty的源码或假称恢复原dirty树。

- a8b1f8be153fe4f3a34146117546c2178f2e446b：已集成选线审计/初始SL资源诊断；silent-selection-audit明确是predicted_candidates，actual_turn仍null，不能认证完整实际候选。
- 1698adc96ba434a46942321e0237b70657e625b2、0e4fe4df89a06682468e0e4716c12126e76369d5：SL预测资源差分及后续窄扩充；execution=unverified，B2配对数由原sl_explore另列。不是逐来源实际伤害归属。
- 04921bd785ac6838066522f91ea0bb6ab95cb6a1：未知持有价与同题无药预测参考，保留null和无药范围，未拟合本批跨战药价。
- 05cd292c6f01bb31e406473d3a9843e659d62b93：呼唤持牌预测/未决弃牌分列，actual_held_hp_loss仍null，不虚构确定弃牌。
- a83d9ab675560a177249aa638e99df40bcfb5553、0d092f6b928a6221eabf3516abad25c48ceaac9c、d5e20aa4dd44168ce30944dfcce74f8322144953：本体/自爆阶段、限定最终资源及药水观察说明。enemyHpLeft/anchorRank仍保留旧占位HP平局次序；限定最终资源不外推到未满足条件的YQL输入。

上述八个提交全部是所核实际live祖先，仅作为已有窄子项证据。本批10项仍含未完成的实际归属、联合校准、受控后继或较晚独立验证，不能整项报duplicate/implemented。

| 派发ID | 处置及具体缺口 |
|---|---|
| silent-proposal-366288801d9150d9 | waiting；751 F17 T2/T7/T13局部血价已核；已有SL预测成本诊断，仍缺逐来源实际结算、完整候选执行归属及固定后续整战对照，不能拟探索门槛。 |
| silent-proposal-85929bdfc8a3fc1b | waiting；751 F13 T3实际只执行用药支线；持牌及未知持有价、无药参考已展示，仍缺未决弃牌后的完整收益分源、不喝及留药后战实果。 |
| silent-proposal-efd9f83ee9e1a6dc | waiting；共享751同局三组对照；预测与单动作回执仍不能认证完整候选的实际执行成本，缺受控整战及独立验证，不新增重复实现。 |
| silent-proposal-131042659448ae74 | waiting；已有持牌失血、未知持有价和无药参考子项；仍缺敏捷、毒、荆棘及未决弃牌的完整实际收益归属，以及跨战留药对照。 |
| silent-proposal-990f054036609447 | waiting；KV F33 T5同指纹扣敌36→29、均零净损；已有预测资源对照，仍缺敌回血与能力完整结算归属、受控胜线及独立验证，不改SL或路线门槛。 |
| silent-proposal-e18d3f18e6cac2a0 | waiting；YQL F17 T10毒2→8而血26、挡13、来袭41不变；阶段子项已有，仍缺完整后继下的受控改序、最终自爆资源及提前用药验证，不直接归零占位HP改序。 |
| silent-proposal-9733bb80f445aeae | waiting；共享YQL/L9/PU阶段证据；已有阶段事实，PU胜线多处动作同变，仍缺改序、提前用药和路线的受控验证，不把子项当整项完成。 |
| silent-proposal-c51468c5e8ba6668 | waiting；KEN七次请求及槽位消耗已核；仍缺随机选牌、发光水重问后完整候选收益归属，以及不喝或留至Boss的支线，不能拟持有价。 |
| silent-proposal-86a7db08d1a31976 | waiting；KEN F17 T10实损15→21、净扣2→4；T5省2血却延步法至T9。已有预测成本子项，仍缺完整候选与能力收益归属、固定后续整战及独立验证。 |
| silent-proposal-e282a9131b99129a | waiting；共享KEN同局两组对照；六次SL不当六局，仍缺受控整战与后期独立验证，不拟统一6血/2伤阈值或重复实现诊断。 |

## 账本、验证与交付边界

不新建重复提案ID、不重写历史复盘、不追加重复游戏支持/反例；本次只经根目录ledger.py update为16个既有账本增加proposal/report追溯与本批处置说明。保留claim、first_run、asc、prior、evidence、status、version与effect，不把历史shipped改成proposed，也不代ops标新shipped。CLI退出码、追加字节与读回见ledger-cli.log、ledger-update-receipt.json；这是追溯记录，不表示经验已新增入库或消费者已采用新策略。code_proposals沿用原CLI产生的10个ID，队列waiting由调用方消费proposal_results。

本批仅scratch证据分析，没有生产源码变更。tsc/vitest/cases均null，未运行沙箱全套、LLM、网络、模拟池或play；撤源码失败/恢复通过不适用，不借历史绿色或材料断言冒称生产测试。原字节审计、六对差分、七槽消费和能力时点核验退出0；它们只是证据核对。探索性只读脚本的combat=null错误及旧猜测路径错误保留于exploratory-read-notes.md。账本包装脚本首次因read_rows返回元组而在CLI前只读预检退出1，原脚本及失败记录保留，修正后CLI与字段读回结果单列；未改根CLI或账本格式。这些不是生产失败或机制反证。

无源码提交/合入/版本，merge=live的源码发布流程不触发，不通知已上线，不关闭父学习要求。production source.diff.patch为空，最终git status干净；根账本例外变动仅CLI追加。最终验收与材料哈希另存final-validation.json及artifact-manifest.json。gitleaks只扫描本批材料，结果另存gitleaks.log/JSON，不读取任何key或.env。

## 限制与下一步证据

1. 同局SL为相关尝试；六对只是三局中的局部窗，不是六场独立实验。没有用同局分别训练和验证。
2. 本批没有固定其余后轮的受控整战新证据，没有拟合权重、药水持有价、SL额外血价或终局排序参数。新局与受控后继仍须区分实盘和模拟。
3. 单动作回执、槽位消耗、选线预测与完整方案收益分属不同证据。actual_turn/完整收益归属仍未知，未填0。
4. 原本体阶段说明、低层公式与现行探索允许更差未试线分别保留；本任务没有新机制异议或反证，不制造需通知的游戏结论。
5. 不证明本批能提高胜率、改变路线/药时可赢，或其他角色/未观察进阶已验证。后续重派按每项具体缺口补数据，原失败、等待及原源码身份保持。

提案交付路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-230028/learner/runs/20261017-230034-8697418c-50c4-4cea-b4c8-33d0a49b0784-strategy-proposal/proposal.md

机器回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-230028/learner/runs/20261017-230034-8697418c-50c4-4cea-b4c8-33d0a49b0784-strategy-proposal/report.json

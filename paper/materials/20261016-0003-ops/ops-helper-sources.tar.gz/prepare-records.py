from pathlib import Path
import csv, hashlib, importlib.util, json, os, re, subprocess, tarfile
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0003'; pub=r/'paper/materials/20261016-0003-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists()
result=load(pub/'paper-dataset-result.json'); assert result['actual_exit_code']==0 and result['calls']==1; log=(pub/'paper-dataset.log').read_text(); assert 'key scan: CLEAN (no sk-<key> patterns)' in log
before={x['path']:x for x in load(p/'paper-before.json')}; store=p/'paper-owned'; store.mkdir(exist_ok=True); outputs=[]
for f in sorted((r/'paper/data').iterdir())+[r/'paper/materials/silent/cost.md']:
 if not f.is_file(): continue
 raw=f.read_bytes(); path=str(f.relative_to(r)); h=sha(raw)
 if path in before and h==before[path]['sha256']: continue
 name=path.replace('/','--'); (store/name).write_bytes(raw); outputs.append(dict(path=path,bytes=len(raw),sha256=h,snapshot=name))
write(p/'paper-owned-manifest.json',outputs); by={x['path']:x for x in outputs}
def frozen(path):
 if path in by:
  raw=(store/by[path]['snapshot']).read_bytes(); assert sha(raw)==by[path]['sha256']; return raw
 return (r/path).read_bytes()
summary=json.loads(frozen('paper/data/summary.json')); verification=json.loads(frozen('paper/data/verification.json')); checks={k:v for k,v in verification['checks'].items() if isinstance(v,bool)}; assert len(checks)==5 and all(checks.values()) and summary['source_checks_passed'] is True
cut=re.match(r'^cut at (\S+): ',log).group(1); assert summary['generated_at']==cut; runs=list(csv.DictReader(frozen('paper/data/runs.csv').decode().splitlines())); selected=[x for x in runs if x['run_id']=='ZE2DNC29WWHB']; assert len(selected)==1; row=selected[0]
assert all(row[k]==v for k,v in dict(character='SILENT',ascension='10',outcome='defeat',floor_max='23',n_decisions='564',has_postmortem='1',performance_included='1').items()); brain=json.loads(row['brain_source']); assert brain['eligible'] is True and brain['successful_answers']=={'codex':24} and brain['failed_or_unaccepted_rows']==0
snap=dict(request=result,generated_at=cut,source_cut_bytes=summary['source_cut_bytes'],five_checks=checks,source_checks_passed=True,row_counts=verification['row_counts'],total_decision_records=summary['decisions']['play_total']+summary['decisions']['shadow'],original_count_warnings=verification['checks']['runs.jsonl decision-count mismatches'],run={k:row[k] for k in ['run_id','character','ascension','outcome','floor_max','n_decisions','has_postmortem','performance_included','brain_source']},changed_outputs=outputs,component_costs='Separate immutable cuts and estimates, not invoices or credit conversions.',raw_snapshot=False,previous_outputs_preserved=str((p/'paper-before').relative_to(r))); write(pub/'paper-snapshot-readback.json',snap)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip(); old=git('show',base+':paper/materials/learning/ledger.jsonl'); rows=(p/'owned-ledger.jsonl').read_bytes().splitlines(keepends=True); assert len(rows)==16; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==16
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(a)==set(z)
for ident in a:
 for key in ['character','kind','claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']: assert a[ident].get(key)==z[ident].get(key),(ident,key)
 previous=a[ident].get('evidence',[]); later=z[ident].get('evidence',[]); assert later[:len(previous)]==previous; assert all(x['run']=='ZE2DNC29WWHB' and x['role']=='support' for x in later[len(previous):])
lesson=(p/'owned-lessons.md').read_bytes(); oldlesson=git('show',base+':notes/lessons.md'); assert len(lesson)==19764 and b'## ZE2DNC29WWHB' not in oldlesson and lesson in (r/'notes/lessons.md').read_bytes(); readback=load(pub/'postmortem-readback.json'); readback['protected_fold_verified_on_private_staged16_rows']=True; readback['parallel_physical_rows_preserved']='Only own chapter and16 original CLI rows staged; other root records and pre-existing whitespace differences remain physical/uncommitted.'; write(pub/'postmortem-readback.json',readback)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：0003原234301复盘ZE2DNC29WWHB done0闭环，无新增纯bug/老错复发，不补派修复或重复队列。原1328行含runs及状态/决策/SL/config/计划/brain/Jev题面逐offset/bytes/SHA/JSON/显式身份核，Silent A10/F23负局、564决策/589状态/24原accepted Codex Sol6.1/xhigh，原17战斗窗五次SL退出截断和重复幼虫实体归属未知保持。正式19764字节单次cat章/旧物理前缀/原SHA核，追加前8/4低置信细分及F8取药时间初稿更正保留，无需重复勘误；原chosen缺字段探针/宽status输出截断不当产品故障。16所属CLI为8旧条support及8原提案追溯、无新增项/repeat；旧claim/首证/prior/status/version和evidence前缀保，三个46e9a239/bbfd3da8/31324ef8策略提案来源指纹核沿原链pending，不拟血价/分靶/SL规则或冒实现/shipped。原2773材料检查非生产测试，引用livecfa1两叶SHA不证明原dirty运行树等价；完整逐击/过量、受控替线、dirty知识、时钟/二幕Boss实战/纯战斗时间/缓存/账单未知保留。唯一nice19 paper_dataset --no-raw PID{result["pid"]}实exit0，cut{cut}、{len(runs)}局/{snap["total_decision_records"]}决策、五一致性/keyscan CLEAN，本局has_postmortem1/564决策/24成功Codex入表；原计数告警/成本独立cut估计非账单保留。仅本人复盘/16CLI/生成表和证据提交，保物理并行记录/旧空白差，不新源码/版本/测试/派发/重启/改账号home模型额度队列prompt，不关闭宽父。证据paper/materials/20261016-0003-ops/。\n'
note=f'\n- {at} [ops 学习闭环] ZE2DNC29WWHB复盘及16所属CLI已核，无新增纯bug；8条旧项只补support，三原提案沿策略链pending。论文一次刷新exit0、{len(runs)}局、五一致性/keyscan通过，本局has_postmortem1；截断/反事实/逐源/校准未知保持，不冒规则已实现或宽父完成。回执paper/materials/20261016-0003-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['notes/lessons.md']=oldlesson+lesson; values['paper/materials/learning/ledger.jsonl']=old+added
for x in outputs: values[x['path']]=frozen(x['path'])
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in p.glob('*.py'):
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,postmortem='ZE2DNC29WWHB',original_rows_checked=1328,original_lesson_bytes=19764,new_bug=False,owned_ledger_rows=16,evidence_updates=8,proposal_links=8,protected_fields_and_old_evidence_preserved=True,paper_single_exit=0,paper_cut=cut,paper_output_count=len(outputs),five_checks=True,no_source_release_game_account_prompt_change=True,parallel_records_preserved=True))
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=16,ledger_check=0,paper_outputs=len(outputs),runs=len(runs))))

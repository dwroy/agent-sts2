from pathlib import Path
import hashlib, importlib.util, json, re, subprocess, tarfile
root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261016-0003'; pub=r/'paper/materials/20261016-0003-ops'; pub.mkdir(exist_ok=True); sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
bid='20261015-234301'; run='ZE2DNC29WWHB'; s=r/'learner/runs/20261015-234304-5484c8cd-bd0f-4134-9238-c64226bc11c4-postmortem'; report=load(s/'report.json'); assert report['appended']==[run] and report['bugs']==report['skipped']==report['ledger']['added']==report['ledger']['repeats']==[]
b=load(r/'ops/codex-ops/learn.json')['batches'][bid]; assert b['state']=='done' and b['rc']==0 and b['done']==[run] and not b['missing'] and not b['proposal_audit_errors']
exec((p/'readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text())
refs=[]; counts={}; brains=[]; config=None; runrow=None
for stream in ['runs','states','decisions','sl-attempts','run-config','run-plans','brain','jev-prompts']:
 count=0
 with (r/'logs'/(stream+'.jsonl')).open('rb') as original,(s/(stream+'.jsonl')).open() as frozen:
  for line in frozen:
   e=json.loads(line); original.seek(e['offset']); raw=original.read(e['bytes']); row=json.loads(raw); assert sha(raw)==e['sha256'] and row==e['row']
   fp=row.get('fingerprint') or {}; fp=json.loads(fp) if isinstance(fp,str) else fp; state=row.get('state') or {}; sr=state.get('run') or {}; ids=[x for x in [row.get('run_id'),row.get('run') if isinstance(row.get('run'),str) else None,state.get('run_id'),sr.get('run_id') if isinstance(sr,dict) else None,fp.get('run') if isinstance(fp,dict) else None] if x is not None]; assert ids and all(x==run for x in ids)
   if stream=='states': assert state['run']['character_id']=='SILENT' and state['run']['ascension']==10
   if stream=='runs': assert row['character']=='SILENT' and row['ascension']==10 and row['floor']==23 and row['victory'] is False; runrow=row
   if stream=='brain': assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh' and row['accepted'] is True; brains.append(row)
   if stream=='run-config': assert config is None; config=row
   refs.append(dict(stream=stream,line=e['line'],offset=e['offset'],bytes=len(raw),sha256=sha(raw))); count+=1
 counts[stream]=count
assert counts['runs']==counts['run-config']==1 and counts['decisions']==564 and counts['states']==589 and len(brains)==24
verification=load(s/'verification.json'); assert verification['material_checks']==2773 and verification['result']=='通过'; completion=load(s/'completion-verification.json'); assert completion['lessons_prefix_unchanged'] and completion['chapter_equal'] and completion['unique_heading'] and completion['ledger_check']==0 and load(s/'ledger-check.json')['returncode']==0
source=load(s/'source-reference.json')
for path,x in source['files'].items(): raw=git('show',source['commit']+':'+path); assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
lessonraw=(r/'notes/lessons.md').read_bytes(); prior=load(s/'lessons-before.json'); assert sha(lessonraw[:prior['size']])==prior['sha256']; receipt=load(s/'append-receipt.json'); lesson=lessonraw[receipt['start']:receipt['start']+receipt['bytes']]; assert len(lesson)==19764 and sha(lesson)==receipt['sha256'] and lesson==(s/'chapter.md').read_bytes() and receipt['prior_prefix_unchanged']; (p/'owned-lessons.md').write_bytes(lesson)
owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('by')=='learner:postmortem' and (any(x.get('run')==run for x in row.get('evidence',[])) or str(s) in json.dumps(row,ensure_ascii=False)):
  assert row['op']=='update' and row['id'] in report['ledger']['updated'] and set(row)<={'op','id','ts','by','evidence','where','note'}; assert all(x['run']==run and x['role']=='support' for x in row.get('evidence',[])); owned.append(raw)
assert len(owned)==16 and sum('evidence' in json.loads(raw) for raw in owned)==8; (p/'owned-ledger.jsonl').write_bytes(b''.join(owned))
spec=importlib.util.spec_from_file_location('original_code_proposals',r/'learner/code_proposals.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); queue=mod.fold(r/'paper/materials/learning/code-proposals.jsonl'); proposals=[]
for ident in report['code_proposals']:
 q=queue[ident]; f=Path(q['proposal']); assert q['character']=='silent' and q['runs']==[run] and q['source_task']=='postmortem' and q['target_task']=='strategy-proposal' and f.is_relative_to(r) and sha(f.read_bytes())==q['proposal_sha256']; proposals.append({k:q.get(k) for k in ['id','state','proposal','proposal_sha256','ledger','implemented_commit']})
assert load(s/'gitleaks.json')==[]
write(pub/'postmortem-readback.json',dict(batch=bid,original_report=report,native=native,original_rows_checked=len(refs),stream_counts=counts,actual_accepted_codex=len(brains),original_run_row=runrow,actual_run_config=config,source_reference=source,source_reference_does_not_prove_consumed_dirty_tree_equivalence=True,original_lesson_bytes=19764,original_lesson_receipt=receipt,lessons_prefix_preserved=True,original_ledger_rows=16,evidence_bearing_rows=8,trace_only_proposal_links=8,original_proposals=proposals,learner_original_material_checks=2773,original_process_notes=(s/'process-notes.md').read_text(),limits='Five SL pre-exit frames, complete per-hit/overkill damage and repeated enemy identity, unselected route/target/potion outcomes, consumed dirty knowledge bytes, calibrated clock/second-act Boss combat, pure combat time, Jev cache and invoice remain unknown. Eight support updates only; no new pure bug, repeated old bug, game-rule implementation or parent closure.'))
write(pub/'postmortem-original-references.json',refs); artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<300000]+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts); print(json.dumps(dict(rows=len(refs),counts=counts,ledger_rows=16,lesson_bytes=19764,new_bug=False)))

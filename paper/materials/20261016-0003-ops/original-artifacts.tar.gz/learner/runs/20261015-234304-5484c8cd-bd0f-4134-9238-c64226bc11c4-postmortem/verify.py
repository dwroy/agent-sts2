import json,pathlib,collections,datetime,hashlib,subprocess
p=pathlib.Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/f'{n}.jsonl').open()]
s={x['line']:x['row']['state'] for x in load('states')};d=load('decisions');b=load('brain');r=json.load(open(p/'ZE2DNC29WWHB-resources.json'));checks=0
def check(test):
 global checks
 assert test
 checks+=1
check(len(d)==564);check(len(s)==589);check(len(b)==24);check(all((x['row']['engine'],x['row']['model'],x['row']['effort'],x['row']['accepted'])==('codex','gpt-6.1-sol','xhigh',True) for x in b))
expected=[(2,56,50,70),(3,50,41,70),(5,34,33,70),(8,33,29,70),(12,70,64,70),(13,64,63,70),(14,63,53,70),(17,70,3,70),(17,70,1,70),(19,56,41,70),(20,41,29,70),(21,29,8,70),(21,29,3,70),(23,13,1,80),(23,13,7,80),(23,13,1,80),(23,13,0,80)]
for w,(f,a,z,m) in zip(r['combats'],expected):
 check(w['floor']==f);check(w['entry']['hp']==a);check((w.get('exit')or w['last'])['hp']==z);check(w['entry']['max_hp']==m);check(w['entry_is_turn_one'])
check(len(r['combats'])==17);check(sum(w['exit'] is None for w in r['combats'])==5)
check(s[415568]['run']['current_hp']==1);check(s[415568]['combat']['player']['block']==8);check(s[415569]['run']['current_hp']==0)
e=s[415568]['combat']['enemies'];check([x['current_hp'] for x in e]==[22,21,23,25]);check(sum(i.get('total_damage')or 0 for x in e for i in x['intents'])==21)
check(21-8==13);check(13-1+1==13)
check(all(any(q['power_id']=='STRENGTH_POWER' and q['amount']==-6 for q in x['powers']) for x in s[415563]['combat']['enemies']));check(all(not any(q['power_id']=='STRENGTH_POWER' for q in x['powers']) for x in s[415564]['combat']['enemies']))
for a,z,h0,h1 in [(415076,415077,29,50),(415083,415084,50,70),(415155,415156,53,70),(415314,415315,1,56),(415429,415430,3,13)]:check(s[a]['run']['current_hp']==h0 and s[z]['run']['current_hp']==h1)
low=[x['row'] for x in d if x['row']['decider']=='jev' and x['row'].get('confidence')is not None and x['row']['confidence']<.35];check(len(low)==12);check(sum(x['label'].startswith('combat/') for x in low)==8)
combat=[x['row'] for x in d if x['row']['decider']=='jev' and x['row']['label'].startswith('combat/')];check(len(combat)==112);check(sum(x.get('rollout_best_chosen')is True for x in combat)==98);check(sum(x.get('rollout_best_chosen')is False for x in combat)==12)
check(sum(x['row'].get('usage',{}).get('input_tokens',0) for x in d if x['row']['decider']=='jev')==1107610);check(sum(x['row']['usage']['inputTokens'] for x in b)==4164905);check(sum(x['row']['usage']['cacheHitTokens'] for x in b)==1779200)
sl=load('sl-attempts');check([(x['row']['floor'],x['row']['attempt'],x['row']['result'],x['row']['turns']) for x in sl]==[(17,1,'predicted_death',15),(17,2,'won',17),(21,1,'predicted_death',5),(21,2,'won',7),(23,1,'predicted_death',3),(23,2,'predicted_death',5),(23,3,'predicted_death',7),(23,4,'died',7)])
check(sum(1 for x in d if x['row'].get('chosen',{}).get('action')=='use_potion')==12);check(not any(x['row'].get('chosen',{}).get('action')=='discard_potion' for x in d));check(not any('HP guard:' in x['row'].get('rationale','') or 'over the HP guard bound' in x['row'].get('rationale','') for x in d))
# Verify cited identities directly against the preserved raw source at byte offsets.
for name in ['runs','run-config','decisions','states','run-plans','sl-attempts','brain','jev-prompts']:
 with (pathlib.Path('/home/dw/Projects/agent-sts2/logs')/(name+'.jsonl')).open('rb') as src:
  for x in load(name):
   src.seek(x['offset']);raw=src.read(x['bytes']);check(hashlib.sha256(raw).hexdigest()==x['sha256']);check(json.loads(raw)==x['row'])
print(json.dumps({'material_checks':checks,'result':'通过','scope':'固定日志与稿件关键数字核验，不是产品测试'},ensure_ascii=False))

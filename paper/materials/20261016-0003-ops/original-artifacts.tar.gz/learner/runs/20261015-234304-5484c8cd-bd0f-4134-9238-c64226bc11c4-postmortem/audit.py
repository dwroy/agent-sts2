import json,pathlib,collections,datetime
p=pathlib.Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/f'{n}.jsonl').open()]
d=load('decisions');s=load('states');r=json.load(open(p/'ZE2DNC29WWHB-resources.json'));j=load('jev-prompts')
for x in d:
 t=x['row'];rat=t.get('rationale','')
 if t.get('decider')=='codex' and x['line']>=402126:print('B',x['line'],t['floor'],t['label'],t.get('chosen'),rat)
 if 'guard' in rat.lower() or '护栏' in rat: print('GUARD',x['line'],rat)
print('COUNTS',collections.Counter(t['row'].get('decider') for t in d));print('JEV COMBAT JOURNAL')
x=next(t for t in d if t['row']['decider']=='jev' and t['row']['label'].startswith('combat/'));print(x['line'],json.dumps(x['row'].get('journal'),ensure_ascii=False))
print('PROMPT KEYS',j[0]['line'],list(j[0]['row']));print(json.dumps(j[0]['row'],ensure_ascii=False)[-2000:])
print('NONCOMBAT RESOURCES')
for x in r['resource_changes']:
 if not x['combat_sequence']: print('s',x['from']['line'],'->',x['to']['line'],'F',x['to']['floor'],x['from']['hp'],x['from']['max_hp'],x['from']['potions'],'->',x['to']['hp'],x['to']['max_hp'],x['to']['potions'],'restart',x['restart_boundary'])
print('POTION ACTIONS')
for x in d:
 t=x['row'];a=t.get('chosen',{}).get('action','')
 if 'potion' in a: print('d',x['line'],'F',t['floor'],'T',t.get('turn'),'try',t.get('sl_attempt'),a,t.get('chosen'),t['result'],t.get('rationale','')[:200])
print('TURN AUDIT')
for w in r['combats']:
 if w['floor']<17:continue
 frames=[x for x in s if w['entry']['line']<=x['line']<=(w.get('exit') or w['last'])['line']]
 turns=collections.OrderedDict()
 for x in frames:
  t=x['row']['state']; turns.setdefault(t.get('turn'),[]).append(x)
 print('F',w['floor'],'SEQ',w['sequence'])
 for turn,group in turns.items():
  a=group[0]['row']['state'];z=group[-1]['row']['state']; print('T',turn,'s',group[0]['line'],group[-1]['line'],'HP',a['run']['current_hp'],z['run']['current_hp'],'enemies-first',[(e['index'],e['name'],e['enemy_id'],e['current_hp'],e.get('block'),e['intent']) for e in (a.get('combat')or{}).get('enemies',[])], 'last',[(e['index'],e['enemy_id'],e['current_hp']) for e in (z.get('combat')or{}).get('enemies',[])])

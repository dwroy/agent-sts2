import json,pathlib,collections,datetime
p=pathlib.Path(__file__).parent;s=[json.loads(x) for x in (p/'states.jsonl').open()];d=[json.loads(x) for x in (p/'decisions.jsonl').open()];b=[json.loads(x) for x in (p/'brain.jsonl').open()];r=json.load(open(p/'ZE2DNC29WWHB-resources.json'));report=[]
for w in r['combats']:
 frames=[x for x in s if w['entry']['line']<=x['line']<=(w.get('exit') or w['last'])['line']];turns=collections.OrderedDict()
 for x in frames:turns.setdefault(x['row']['state'].get('turn'),[]).append(x)
 needs=[];loss=[];hp=[];mother=[];motherdrop=[]
 groups=list(turns.values())
 for i,group in enumerate(groups):
  st=group[0]['row']['state'];z=(groups[i+1][0] if i+1<len(groups) else group[-1])['row']['state'];total=lambda a:sum(e['current_hp'] for e in (a.get('combat')or{}).get('enemies',[]) if e.get('is_alive'))
  needs.append(total(st));loss.append(total(st)-total(z));hp.append(st['run']['current_hp']-z['run']['current_hp']);getm=lambda a:next((e['current_hp'] for e in (a.get('combat')or{}).get('enemies',[]) if e['enemy_id']=='OVICOPTER'),None);a,c=getm(st),getm(z);mother.append(a);motherdrop.append(a-c if a is not None and c is not None else None)
 row={'seq':w['sequence'],'floor':w['floor'],'needs':needs,'net_enemy_hp_drop':loss,'net_player_hp_loss':hp,'mother_needs':mother,'mother_drop':motherdrop,'last_turn_censored':w['exit'] is None};report.append(row)
 if w['floor']>=17:print(row)
(p/'turn-numbers.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('TOKEN ratios',1779200/4164905*100,'RAW BEST',98/110*100,98/112*100)
for x in b:
 if x['line']!=14795:continue
 rr=x['row'];print('F16 baseline',rr['payload']['facts']['act_boss_sim']['entry_hp'],rr['payload']['facts']['act_boss_sim']['current_deck'])
 for key in ['o0','o1:c16']:
  opt=rr['options'].get(key)
  if opt:
   opt=json.loads(opt); q=opt.get('quantitative_fight',{});print('option',key,{k:q.get(k) for k in ['samples','raw_win_mc_interval95','effective_damage_per_turn','simulated_turns','damage_per_turn_won']})
print('SL line fields')
for x in map(json.loads,(p/'sl-attempts.jsonl').open()):
 rr=x['row'];print(x['line'],rr['floor'],rr['attempt'],rr.get('result'),rr.keys() if rr['floor']==23 and rr['attempt']==4 else '')

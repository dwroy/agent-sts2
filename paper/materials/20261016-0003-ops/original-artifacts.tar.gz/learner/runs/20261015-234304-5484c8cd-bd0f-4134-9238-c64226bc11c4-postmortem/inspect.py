import json,pathlib,collections
p=pathlib.Path(__file__).parent
load=lambda n:[json.loads(x) for x in (p/f'{n}.jsonl').open()]
d=load('decisions');s=load('states');b=load('brain');c=load('run-config')[0];
print('CONFIG',json.dumps(c,ensure_ascii=False)[:6500])
print('SAMPLE DECISION',json.dumps(d[5],ensure_ascii=False)[:3500]);print('SAMPLE BRAIN',json.dumps(b[0],ensure_ascii=False)[:2200]);print('SAMPLE STATE',json.dumps(s[-2],ensure_ascii=False)[:8000])
with (p/'brain-summary.txt').open('w') as f:
 for x in b:
  r=x['row']; f.write(f"\nBRAIN line={x['line']} keys={list(r)}\n"+json.dumps(r,ensure_ascii=False)+'\n')
with (p/'decisions-summary.txt').open('w') as f:
 for x in d:
  r=x['row']; f.write(f"d{x['line']} F{r.get('floor')} T{r.get('turn')} {r.get('ts')} {r.get('decider')} {r.get('label')}\n"+json.dumps({k:v for k,v in r.items() if k not in ['ts','run_id','floor','turn','label','decider','usage']},ensure_ascii=False)+'\n')

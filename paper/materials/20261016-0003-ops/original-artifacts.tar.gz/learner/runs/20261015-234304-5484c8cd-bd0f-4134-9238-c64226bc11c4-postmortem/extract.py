import json, pathlib, hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261015-234304-5484c8cd-bd0f-4134-9238-c64226bc11c4-postmortem'; rid=b'ZE2DNC29WWHB'
for name in ['runs','decisions','run-plans','sl-attempts','run-config','fight-plans','brain','jev-prompts','states']:
    src=root/'logs'/f'{name}.jsonl'; count=0; offset=0
    with src.open('rb') as inp, (out/f'{name}.jsonl').open('w') as dst:
        for n,raw in enumerate(inp,1):
            pos=offset; offset+=len(raw)
            if rid not in raw: continue
            row=json.loads(raw)
            if name=='states' and row.get('state',{}).get('run_id',row.get('run_id'))!=rid.decode(): continue
            if name=='run-plans' and row.get('run')!=rid.decode(): continue
            if name not in ['states','run-plans'] and row.get('run_id',row.get('run'))!=rid.decode(): continue
            dst.write(json.dumps({'line':n,'offset':pos,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'row':row},ensure_ascii=False)+'\n'); count+=1
    print(name,count,flush=True)
decs=[json.loads(x)['row'] for x in (out/'decisions.jsonl').open()]; start=min(x['ts'] for x in decs); end=max(x['ts'] for x in decs)
count=0; offset=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as src,(out/'deepseek-reasoning.jsonl').open('w') as dst:
    for n,raw in enumerate(src,1):
        pos=offset; offset+=len(raw)
        row=json.loads(raw)
        if start<=row.get('ts','')<=end:
            dst.write(json.dumps({'line':n,'offset':pos,'row':row},ensure_ascii=False)+'\n');count+=1
print('reasoning',count,'window',start,end)

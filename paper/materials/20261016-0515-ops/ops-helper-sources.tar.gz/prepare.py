from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0515';pub=root/'paper/materials/20261016-0515-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-050119-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip() and (s/'source.diff.patch').read_bytes()==b''
final=load(s/'acceptance.json');assert final['base']==report['base'] and final['git_status_clean'] and final['assigned_proposals']==final['waiting']==10 and final['evidence_rows']==19929 and final['material_assertions']==124 and final['ledger_cli_updates']==31
assigned=load(s/'assigned-proposals.json');assert len(assigned)==10 and {x['id'] for x in assigned}==set(report['code_proposals'])
for x in assigned:
    original=Path(x['proposal']);copy=s/(x['id']+'.original.md');assert original.is_relative_to(root) and sha(copy.read_bytes())==x['proposal_sha256']
    if original.exists():assert sha(original.read_bytes())==x['proposal_sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');runs=load(s/'run-identities.json');assert set(report['runs'])<=set(runs) and len(runs)==15 and all(x['character']=='SILENT' for x in runs.values())
cohorts=collections.Counter(x['ascension'] for x in runs.values());assert cohorts=={1:1,7:1,9:1,10:12}
receipts=load(s/'offline-audit-receipts.json');retry=load(s/'offline-audit-retry-receipt.json');assert len(receipts)==6 and collections.Counter(x['rc'] for x in receipts)=={0:5,1:1} and retry['rc']==0
needed={stream:set() for stream in ['states','decisions']}
for x in receipts:
    data=load(s/(x['run']+'.audit-input.json'))
    for stream in needed:needed[stream].update(row['_line'] for row in data[stream])
counts={};input_rows={stream:{} for stream in needed};manifest=load(s/'evidence/evidence-manifest.json');verification=load(s/'evidence-verification.json')
for x in manifest:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in runs
            if x['stream']=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',runs[e['run_id']]['ascension'])
            if x['stream']=='runs':assert row==runs[e['run_id']]
            if x['stream'] in needed and e['line'] in needed[x['stream']]:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==verification['rows']==19929
for x in verification['streams']:assert counts[x['stream']]==x['rows'] and x['offset_bytes_sha_json_identity_verified']
facts=load(s/'material-checks.json');assert len(facts['checks'])==facts['passed']==124 and facts['failed']==0 and all(x['ok'] and x['actual']==x['expected'] for x in facts['checks'])
source=load(s/'source-audit.json');assert len(source['leaves'])==17 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_head']
for x in source['leaves']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head']+':'+x['path'])
    assert sha(a)==x['base_sha256']==x['work_sha256'] and sha(z)==x['live_tracked_sha256']==x['live_work_sha256'] and (root/'.worktrees/live'/x['path']).read_bytes()==z
    assert (a==z)==x['live_work_equals_base'] and x['work_equals_base'] and x['live_work_equals_tracked'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['live_work_equals_base'] for x in source['leaves'])==13
for x in source['commits'].values():
    assert x['base_ancestor'] and x['live_ancestor']
    for head in [report['base'],source['live_head']]:git('merge-base','--is-ancestor',x['commit'],head)
totals=collections.Counter();consumers=[]
for x in receipts:
    run=x['run'];ip=s/(run+'.audit-input.json');data=load(ip);assert data['run']==runs[run]
    for name,h in x['files'].items():assert sha((s/name).read_bytes())==h
    for stream in needed:
        for row in data[stream]:
            reference=input_rows[stream][row['_line']];assert reference['run']==run
            expected={**reference['row'],'_line':row['_line']}
            if stream=='decisions':expected.pop('agent_view',None)
            assert row==expected
    active=x
    if x['rc']==1:
        assert run==retry['run']=='Q6M2Y34MWKRE' and (s/(run+'.audit.json')).read_bytes()==b'' and b'decision_id' in (s/(run+'.audit.stderr.txt')).read_bytes()
        for name,h in retry['files'].items():assert sha((s/name).read_bytes())==h
        filtered=load(s/(run+'.action-input.json'));assert filtered['run']==data['run'] and filtered['states']==data['states'] and filtered['decisions']==[row for row in data['decisions'] if row.get('decision_id')]
        excluded=[row for row in data['decisions'] if not row.get('decision_id')];assert len(excluded)==1 and excluded[0]['_line']==276607 and excluded[0]['label']=='map/route-change'
        audit=load(s/(run+'.action-audit.json'));active=retry
    else:audit=load(s/(run+'.audit.json'))
    status=collections.Counter(row['status'] for row in audit['observed_turns']);assert all(row['actual_full_candidate_result'] is None for row in audit['segments'])
    actions=audit['observed_actions'];c=dict(segments=len(audit['segments']),actions=len(actions),turns=len(audit['observed_turns']),observed_turns=status['observed_turn_endpoints'],unknown_turns=status['unknown'],observed_intervals=sum((row.get('observed_interval') or {}).get('status')=='observed_endpoints' for row in actions),terminal_intervals=sum((row.get('terminal_observation') or {}).get('status')=='observed_terminal_endpoints' for row in actions))
    assert all(c[k]==active[k] for k in c if k!='unknown_turns');totals.update(c);consumers.append(dict(run=run,**c))
assert totals==dict(segments=316,actions=1146,turns=228,observed_turns=164,unknown_turns=64,observed_intervals=979,terminal_intervals=3)
for entry in load(s/'artifact-manifest.json'):
    f=Path(entry['path']);assert f.is_relative_to(s);raw=f.read_bytes();assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
check=load(s/'ledger-update-verification.json');prefix=load(s/'ledger-write-before.json');rows=check['owned_rows'];inputs=[json.loads(line) for line in (s/'ledger-update-input.jsonl').read_text().splitlines()]
assert check['cli_rc']==0 and len(rows)==len(inputs)==31 and check['prefix_unchanged'] and all(check['private_fold_nontrace_fields_unchanged'].values()) and check['new_evidence_rows']==check['status_changes']==check['new_ids']==0
assert set((s/'ledger-update-output.jsonl').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.stderr.txt').read_bytes()==b''
own=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(prefix['source_size']))==prefix['prefix_sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        assert any(all(row.get(k)==v for k,v in item.items()) for item in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==31 and not set(raw.rstrip(b'\n') for raw in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,original_completion=final,original_proposals=assigned,stream_counts=counts,original_rows_verified=19929,ascension_cohorts=dict(cohorts),material_assertions=124,source=source,original_consumers=receipts,original_filtered_retry=retry,consumer_counts=dict(totals),consumer_summaries=consumers,owned_trace_rows=rows,protected_fields_and_prefixes_preserved=True,no_checks_reexecuted=True,limits=['Fifteen Silent runs A1/A7/A9 one each andA10 twelve remain separate; same-run SL attempts are not independent experiments.','Q6 original metadata rejection rc1/empty output retained; filtered single retry is bounded with no attempt fabrication or continuity across removed row.','Six bounded windows and164 observed/64 unknown turns do not certify complete candidates or historical105/109-run studies.','Forty-two Cunning potion observations and local capacity/damage facts do not calibrate complete successor execution, SL recovery or retention value.','Old TXZ death attribution correction and proper lamp target identity remain narrow existing evidence; no new contrary knowledge reported.','Original CLI stdout format-probe JSON error retained; no duplicate CLI or product failure. No source, merge, release, production tests, paper refresh, new dispatch or game action; wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0515原050119-s2策略done0/no-source核收，b09c基线干净WT/HEAD不变，十waiting逐项缺口/testsnull/mergednull保持，无合入受阻。十五Silent A1/A7/A9各一及A10十二分列，八流19929原行逐offset/bytes/SHA/JSON/显式身份核；124原材料断言首次通过，42饮容量/紧勒时点/正确油灯目标/零动作开场原事实不作完整联合策略收益。原六离线首轮5rc0/Q6元数据276607缺id拒收rc1与空输出/SHA保，过滤后单次有限复验0另列；input/output/stderr与原行仅去decisions.agent_view/加_line投影核，316题段/1146动作/228轮窗（164可核64未知）、979相邻端点/3终态端点、整候选全null，不补尝试号或跨删除行认证连续性。17源码叶13同4历史Roy/Dai注释差及五真实base/live来源核，TXZ归因/开场与容量等窄实现不关闭宽父或复原dirty树；旧105/109局分母/留出/留药后继不重建。31所属CLI只where/note，原物理前缀/offset/SHA和私有fold核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI或增support/repeat；stdout误按JSON探查的旧错误及真实空格id输出分列，不当产品/游戏反证。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核，原窄proc查询runtime参数空不冒当前模型证明。仅本人记录/31追溯提交，保并行记录，无源码/合入/发号/补测/论文刷新/复派/重启对局或账号home模型额度权限prompt变更。证据paper/materials/20261016-0515-ops/。\n'
note=f'\n- {at} [运维 codex] 原050119-s2十项继续waiting，无源码修改或合入阻塞；19929原行、124原材料断言、原六离线/过滤复验及31条所属追溯已核。Q6原失败、CLI格式探查错误、unknown与宽父保留，无新发布、补测或论文刷新。回执paper/materials/20261016-0515-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=31,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=19929,owned_trace_rows=31,ledger_check=0,paths=len(entries))))

import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {}
for run_id in json.loads((OUT / 'run-identities.json').read_text()):
    for row in json.loads((OUT / (run_id + '.states-compact.json')).read_text()):
        states[row['line']] = row
checks = []

def check(label, actual, expected, lines=None):
    checks.append({'label': label, 'actual': actual, 'expected': expected, 'lines': lines or [], 'ok': actual == expected})

def raw_state(line):
    row = states[line]
    with open('/home/dw/Projects/agent-sts2/logs/states.jsonl', 'rb') as handle:
        handle.seek(row['offset'])
        raw = handle.readline()
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    return json.loads(raw)['state']

def enemy(line, ident):
    return next(e for e in states[line]['enemies'] if e['enemy_id'] == ident)

def power(line, ident, name):
    return next((p['amount'] for p in enemy(line, ident)['powers'] if p['power_id'] == name), 0)

def chain(run):
    return json.loads((OUT / (run + '.resource-chain.json')).read_text())

ken = chain('KEN58SH9SLZ6')['combats']
check('KEN六赢战净损，零净损仍可已耗药', [w['observed_net_hp_loss'] for w in ken[:6]], [0, 3, 0, 37, 6, 0])
check('KEN前五Boss尝试退出未观测，不补死亡端点', [w['end'] for w in ken[6:-1]], ['restart_observed'] * 5)
ks = json.loads((OUT / 'KEN58SH9SLZ6.states-compact.json').read_text())
for floor, before_hp, before_max, after_hp, after_max in [(12, 26, 76, 53, 81), (16, 46, 81, 75, 86)]:
    found = [(a['line'], b['line']) for a, b in zip(ks, ks[1:]) if b['floor'] == floor and
             (a['hp'], a['max_hp'], b['hp'], b['max_hp']) == (before_hp, before_max, after_hp, after_max)]
    check('KEN F' + str(floor) + '实际回复端点', len(found), 1, [n for pair in found for n in pair])
kd = json.loads((OUT / 'KEN58SH9SLZ6.decisions.json').read_text())
drinks = [d for d in kd if (d.get('chosen') or {}).get('action') == 'use_potion']
check('KEN七饮用请求', len(drinks), 7)
check('KEN三条pending原回执不改写', [d['_line'] for d in drinks if d['result'].startswith('pending')], [274131, 274237, 274272])

for before, after, expected in [(281312, 281313, [70, 66]), (281338, 281339, [52, 48]),
                                (281367, 281368, [62, 58]), (281399, 281400, [60, 56]),
                                (281565, 281566, [4, 0])]:
    check('TXZ新房间开场HP端点', [states[before]['hp'], states[after]['hp']], expected, [before, after])
    check('TXZ开场未出牌', raw_state(after)['combat']['player']['cards_played_this_turn'], 0, [after])
check('TXZ首胜奖励页真实余血', [states[281563]['screen'], states[281563]['hp']], ['REWARD', 4], [281563])
check('TXZ F49敌HP未扣', [enemy(281565, 'TEST_SUBJECT')['current_hp'], enemy(281566, 'TEST_SUBJECT')['current_hp']], [111, 111], [281565, 281566])

for run, filename, pairs in [
    ('TXZ6RVMQA09D', 'TXZ6RVMQA09D.audit.json', [(48, 6, 2, [48, 45, 36]), (48, 6, 3, [48, 48, 27])]),
    ('WQZVENQ7DTRP', 'WQZVENQ7DTRP.audit.json', [(33, 9, 2, [26, 13, 24]), (33, 9, 3, [26, 4, 39]),
        (33, 7, 2, [26, 26, 24]), (33, 7, 6, [26, 22, 24])]),
]:
    data = json.loads((OUT / filename).read_text())
    for floor, turn, attempt, expected in pairs:
        row = next(t for t in data['observed_turns'] if (t['floor'], t['turn'], t['attempt']) == (floor, turn, attempt))
        facts = row['facts']
        actual = [facts['before']['hp'], facts['after']['hp'], -facts['enemy_hp_changes'][0]['hp_delta']]
        check(run + ' F' + str(floor) + 'T' + str(turn) + '第' + str(attempt) + '试整轮观测端点', actual, expected,
              [facts['before']['source_line'], facts['after']['source_line']])
    if run.startswith('WQ'):
        for line, expected in [(282071, 4), (282335, 5)]:
            check('WQ T7末沙坑两种边界', power(line, 'THE_INSATIABLE', 'SANDPIT_POWER'), expected, [line])

cunning = json.loads((OUT / 'cunning-observations.json').read_text())
check('狡诈药水独立来源局数', len({x['run'] for x in cunning}), 9)
check('狡诈药水42饮新增容量分布', [sum(x['added'] == n for x in cunning) for n in [3, 2, 0]], [37, 2, 3])
for row in cunning:
    before, after = row['before_line'], row['after_line']
    old = sum(c['card_id'] == 'SHIV' for c in states[before]['hand'])
    new = [c for c in raw_state(after)['combat']['hand'] if c['card_id'] == 'SHIV']
    check('狡诈药水观测刀数 ' + str(before), len(new) - old, row['added'], [before, after])
    check('狡诈药水观测升级与基础伤 ' + str(before), all(c['upgraded'] is True and
          next(v['base_value'] for v in c['dynamic_values'] if v['name'] == 'Damage') == 6 for c in new), True, [after])

check('Q6普通紧勒与技能完成后逐步HP', [enemy(n, 'TERROR_EEL')['current_hp'] for n in range(282887, 282893)],
      [103, 95, 85, 85, 83, 80], list(range(282887, 282893)))
check('Q6普通紧勒下轮清层', [power(282891, 'TERROR_EEL', 'STRANGLE_POWER'), power(282892, 'TERROR_EEL', 'STRANGLE_POWER')], [2, 0], [282891, 282892])
for run, floor, expected in [('Q6M2Y34MWKRE', 8, [57, 2, 55]), ('Q6M2Y34MWKRE', 9, [2, 0, 2]),
                            ('1913SE84AXQF', 17, [58, 14, 44]), ('1913SE84AXQF', 29, [61, 46, 15]),
                            ('1913SE84AXQF', 31, [46, 0, 46])]:
    row = next(w for w in chain(run)['combats'] if w['floor'] == floor)
    check(run + ' F' + str(floor) + '实际资源链', [row['entry']['hp'], row['exit']['hp'], row['observed_net_hp_loss']], expected)

check('NHA初试与末试T1实际血价', [states[283391]['hp'] - states[283397]['hp'], states[283502]['hp'] - states[283507]['hp']], [1, 7], [283391, 283397, 283502, 283507])
check('NHA初试与末试T1跨轮敌净扣，含轮初遗物', [sum(e['current_hp'] for e in states[a]['enemies']) - sum(e['current_hp'] for e in states[b]['enemies'])
      for a, b in [(283391, 283397), (283502, 283507)]], [8, 24], [283391, 283397, 283502, 283507])
check('NHA普通萎靡实际建两弱/减二力', [power(283395, 'CRUSHER', 'WEAK_POWER'), power(283395, 'CRUSHER', 'STRENGTH_POWER')], [2, -2], [283395])
check('NHA首次毒药现场实际5到10', [power(283146, 'CEREMONIAL_BEAST', 'POISON_POWER'), power(283147, 'CEREMONIAL_BEAST', 'POISON_POWER')], [0, 10], [283146, 283147])
check('K367油灯观测明确为蜜目标，非第一敌人', [power(217010, 'BOWLBUG_ROCK', 'POISON_POWER'), power(217010, 'BOWLBUG_NECTAR', 'POISON_POWER')], [0, 8], [217009, 217010])

bad = [c for c in checks if not c['ok']]
(OUT / 'material-checks.json').write_text(json.dumps({'kind': '只读材料断言；不是生产回归或策略收益验证',
    'checks': checks, 'passed': len(checks) - len(bad), 'failed': len(bad)}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(checks) - len(bad), 'failed': bad}, ensure_ascii=False))
raise SystemExit(bool(bad))

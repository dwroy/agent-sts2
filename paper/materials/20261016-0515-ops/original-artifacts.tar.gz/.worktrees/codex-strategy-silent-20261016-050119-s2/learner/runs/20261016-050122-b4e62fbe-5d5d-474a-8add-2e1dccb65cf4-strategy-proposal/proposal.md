# 静默猎手本批十项策略提案复核

本批十项均 waiting。已有窄实现保留，未得到足以修改生产门槛、药价或联合机制的新完整证据；不将子项完成当整项关闭。

基线：`b09c827062ca0f061571c181f324828016d17a10`。派发：`20261016-050119-s2-strategy-proposal`。根 learn.json 对应行 task=strategy-proposal、character=silent、reason=proposal，工作树和十个proposal_ids精确匹配，没有research_request、implementation_request或proposal_repair。普通专题请求当前绑定另一旧批，本批不承接，不读取其他专题work_spec或扩展队列。开工工作树干净；`git merge --no-edit main` 返回 Already up to date。

仅从本角色十五个已完成局取证，十二局A10及A1/A7/A9各一，SL同局不当独立局。九局42次狡诈药水为局部机制观测，不是42个独立收益样本。所有原稿十份SHA均匹配，31个原账本已核角色和关联。没有重写历史复盘、经验、原提案或旧结论。

共用extract_evidence.py提取八流19929行，逐行核原offset/bytes/SHA、JSON及显式身份；manifest保留source_size和计数。原流累计invalid_lines为states2、decisions2、brain1，均未进入证据；不将它们断言属于本批局。fight-plans本截点选中0行，仅限该截点。逐流边界独立冻结，不冒称跨流原子快照。

124项只读材料断言通过，六组有界离线审计316候选片段、1146动作、228轮窗、164已观察轮端点/64未知，979相邻动作端点和3终态端点，完整候选认证0。Q6原输入一条map/route-change无decision_id导致拒收，失败原输入/输出/错误保留；另存action-input仅排该元数据（decisions276607），不补attempt、不跨行缺口连接；复验rc0但该局已核轮端点仍0。材料核验不是生产回归、在线消费者或策略收益。详见report.md。

所有提案统一方法：已保存本局只作发现/固定核验集，不既拟合又当独立验证；如将来拟合，按独立局及时间前后拆分，同局SL/候选/rollout样本同组，先排除机制误差。现有支持、反例、未知均保留；Roy-2026-10-07-learning仅提供权限，不提供游戏事实。

<a id="silent-proposal-08eaa60bcc449852"></a>

## silent-proposal-08eaa60bcc449852：赢战耗药与Boss入口结转

角色：silent。原来源任务：experience-update；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0019、silent-0020。本次没有新增提案id或重写原提案。

证据：KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1，共七条饮用请求。三条原回执为pending（decisions 274131/274237/274272），不改成completed。六赢战退出净损0/3/0/37/6/0合46，F15已用药而净损0；F12 26/76→53/81、F16 46/81→75/86两次真实回复端点均复核。F17前五尝试只有重启边界，最后尝试退出0；未补全缺失退出。

当前实现与旧规则：当前药价接口仍按角色表及下一场reserve取值；资源链工具区分重启、缺退出和实际净损。旧提案的105局统计不在本批十五局材料上重新拟合。

本次处置：waiting。缺F15未饮用及同入口、同后继把药留到Boss的完整成对结果；七次请求和两次回复端点不能校准持药价，三条pending仍只按后继状态另核。

预期行为与验证：现有生产规则保持。以后冻结同入口、同预算的用药/未用/保留药栏完整后继，隔离临时药效与机制误差，按独立局时间前移训练、后移验证；SL留在同组。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md`；SHA256 `4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`。本批逐字节保存为 `silent-proposal-08eaa60bcc449852.original.md`。

<a id="silent-proposal-92920295a648b540"></a>

## silent-proposal-92920295a648b540：SL首胜与连续通关分开验收

角色：silent。原来源任务：postmortem；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0228、silent-0255。本次没有新增提案id或重写原提案。

证据：TXZ6RVMQA09D A10 F48T6第2/3试，states 281480→281485、281536→281540：两次48血、敌460起步，损3/扣36与损0/扣27；少损3也少9伤。T10奖励页281563确为4血，F49 281565→281566由4到0，敌111不变且cards_played_this_turn=0。后轮抽牌和生成已变化，三试不是独立三局。

当前实现与旧规则：连战开场已有实际live祖先e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a；当前continuationUtility和第二场模板接续已存在，不能把这局报告为又漏认F49。

本次处置：waiting。缺保持抽序、生成牌和药栏一致的两战完整替线；本局首胜后开场死亡，现有连战开场子实现不能证明SL资源比较已校准。

预期行为与验证：现有生产规则保持。逐尝试列首战胜负/退出HP/药栏、第二场开场后资源和可操作状态，保留低可信原模拟及未知；未校准0%不改必死/SL资格。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md`；SHA256 `f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`。本批逐字节保存为 `silent-proposal-92920295a648b540.original.md`。

<a id="silent-proposal-a327449c331efbc1"></a>

## silent-proposal-a327449c331efbc1：沙虫同盘面血价与沙坑双边界

角色：silent。原来源任务：postmortem；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0079、silent-0018。本次没有新增提案id或重写原提案。

证据：WQZVENQ7DTRP A10 F33第2/3试T9，states 282075→282079与282144→282148复核：26→13/4，敌184→160/145，即多15伤、多付9血。第2试T7 282066→282072为0损/24扣、末沙坑4；末试282330→282336为4损/24扣、末沙坑5。多损4有延时端点，不能一律禁止。

当前实现与旧规则：5604982e13890e0e2bc8bf8246272e8267321c0b已给当前轮预测的原线/替线资源差；其execution=unverified，不是整候选实际执行证书。原日志运行树31914e4b+dirty不可由当前clean树还原。

本次处置：waiting。缺攻防与沙坑两边界的完整受控后继、跨重规划候选执行归属及独立胜局；9血换15伤和4血换一沙坑轮均不足确定新SL阈值。

预期行为与验证：现有生产规则保持。同题先保留原答/替线/HP与已结输出/沙坑/毒分别记录，再以完整实际动作和后继核验；所有SL按同一局计，不从全败饱和统计推同安全。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md`；SHA256 `e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`。本批逐字节保存为 `silent-proposal-a327449c331efbc1.original.md`。

<a id="silent-proposal-a099e89437e942bb"></a>

## silent-proposal-a099e89437e942bb：狡诈药水容量、保留与穿插序列

角色：silent。原来源任务：experience-update；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0030、silent-0257、silent-0258。本次没有新增提案id或重写原提案。

证据：九局42饮逐观测端点复核：37次添3、两次八手添2、三次满手添0；新增小刀均升级且基础Damage=6，当前牌面加成不作反例。WQ F33第5试T11 states 282292→282293→282294→282295为8→10→10→10手；第6试282352→282353→282355→282357为5→8→10→10。来源另含SADL A7、F4Q A9及02HB/4D4/JLN/LS/NB/S9 A10，进阶不混拟合。

当前实现与旧规则：6403fdcdadc803a092beb5165a068e22bf51c412是基线与live真实祖先；modelPotion生成升级刀、turn-solver限10手并允许穿插，既有固定测试也有穿插与后续刀身份分支。本次未重跑那些测试，不重复修改已实现容量。

本次处置：waiting。容量与确定生成已有live窄实现；仍缺计划妥当保留容量、穿插出刀、跨重问整候选派发和SL恢复的联合校准，42饮不能关闭整项。

预期行为与验证：现有生产规则保持。联合冻结实际保留选择、饮用、出刀、重问、同一attempt及存档恢复，核每一步合法身份和容量后继；完整实际结果与模型预测分列，不宣称穿插能救本局。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md`；SHA256 `e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`。本批逐字节保存为 `silent-proposal-a099e89437e942bb.original.md`。

<a id="silent-proposal-47910f82a1fdd98f"></a>

## silent-proposal-47910f82a1fdd98f：王室猛毒开场、SL与路线资源联合结转

角色：silent。原来源任务：experience-update；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0018、silent-0019、silent-0020、silent-0021、silent-0025、silent-0079、silent-0198、silent-0228、silent-0255。本次没有新增提案id或重写原提案。

证据：TXZ A10 F43/45/46/48/49 states 281312/281338/281367/281399/281565及各下一帧复核70→66、52→48、62→58、60→56、4→0，均出牌0。WQ T9攻防代价和T7沙坑反例同上。只有这些已观察组合；旧小血瓶净2组合未纳本批原日志，不拆成单件或结算顺序。

当前实现与旧规则：e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a及当前silent-opening.ts已经覆盖受限开场；实时T1和SL恢复盘面不再重复扣。存在的窄实现不替代未知回血/复活组合。

本次处置：waiting。四血开场已有live子实现；仍缺留药、路线和SL完整后继对照，以及未知回血/复活组合的内部结算顺序，不能关闭联合要求。

预期行为与验证：现有生产规则保持。入口前/开场后/可操作时三层资源分别记，已存恢复不当新奖励；完整下一场/路线实证后才评估药价与价值曲线，其他组合保留未建模。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md`；SHA256 `d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`。本批逐字节保存为 `silent-proposal-47910f82a1fdd98f.original.md`。

<a id="silent-proposal-f1374df72d8e6a25"></a>

## silent-proposal-f1374df72d8e6a25：胜战退出、临时药效与下一场资源价值

角色：silent。原来源任务：postmortem；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0019、silent-0020、silent-0050、silent-0253。本次没有新增提案id或重写原提案。

证据：1913SE84AXQF A10 F17胜58→14、F19 58→44、F23 44→40、F29 61→46、F31入口46且最终0；Q6M2Y34MWKRE A10 F2 56→44、F5/F6均36→36、F8 57→2、F9 2→0。Q6 F2T3确饮敏捷而非丢药，F8T1速度不是持续到所有后轮的敏捷。原路线F24由回血改锻造，条件改变单列。

当前实现与旧规则：当前药价表接口、continuation HP与reserve分支已存在，不能说生产只看当前战胜负；旧原运行源码/知识为dirty，当前来源不能证明旧预测输入相同。

本次处置：waiting。缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战和下一战后继；两条失败资源链及未执行早喝候选不能拟合新权重。

预期行为与验证：现有生产规则保持。固定核持续/临时药效及事件、营火实际动作，按run时间切分；用实际退出与下场入口核资源，不把候选省血当真实回血。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md`；SHA256 `df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`。本批逐字节保存为 `silent-proposal-f1374df72d8e6a25.original.md`。

<a id="silent-proposal-38a49e6c97f31eea"></a>

## silent-proposal-38a49e6c97f31eea：普通紧勒与再生、弃磨蚀、增益分源联合核验

角色：silent。原来源任务：experience-update；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0006、silent-0011、silent-0025、silent-0044、silent-0050、silent-0064、silent-0133、silent-0253、silent-0259、silent-0261、silent-0262。本次没有新增提案id或重写原提案。

证据：Q6 A10 F8T4 states 282887—282892敌HP103→95→85→85→83→80；技能CARD_SELECTION中间帧不提前触发，完成后扣2，下一轮STRANGLE_POWER消失。1913 A10 F17胜58→14净损44；再生与敌入伤分别算，不当净损等于毛入伤。F31入口46、最后20到0，重接/反伤不以敌净差充总伤；原提案保留137毛伤与重接的范围，本次未重做完整逐击归因。

当前实现与旧规则：5c7105ff0294466da8319f2934beda05c6040794已实现普通紧勒受限无挡分支；card-model现有再生5和速度临时敏捷分支。未看到WELL_LAID_PLANS或油灯通用首次消费状态的联合实现，不借单个子公式宣布全部完成。

本次处置：waiting。普通紧勒已有live窄实现；仍缺弃磨蚀、增益分源、再生、自动触发和SL恢复的联合消费者校准及受控整战后继。

预期行为与验证：现有生产规则保持。按已有帧验证普通无挡后续单次Attack/Skill；升级、叠层、自动触发、有挡与复活身份留未知。先排机制误差，再校准整战价值，不用低阶基伤填A10。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md`；SHA256 `6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`。本批逐字节保存为 `silent-proposal-38a49e6c97f31eea.original.md`。

<a id="silent-proposal-ef0e38a5dbd3bc07"></a>

## silent-proposal-ef0e38a5dbd3bc07：路线承诺、实际回复与未抵达营火

角色：silent。原来源任务：experience-update；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0019、silent-0020、silent-0021。本次没有新增提案id或重写原提案。

证据：1913 A10 F24实际锻造、F28回复后61、F29胜后46，F31死亡未抵达F32；Q6 A10 F7实际36→57，F8精英胜后2，F9死亡。未走另一条完整路线，没有未用药/另选营火的实打因果对照。

当前实现与旧规则：资源链工具已区分实际HP变动、重启、缺退出；本批复核实际链，不重建原109局统计或将将来营火当到账。

本次处置：waiting。缺另一营火、事件、路线和用药时机的受控完整结果；两条实际资源链只验证兑现，不能据此拟合路线或终局权重。

预期行为与验证：现有生产规则保持。保持原计划与实际动作分账，条件变化不当同条件预测误差；下一更高层战斗与实际可操作入口分别核，按独立新局留出验证。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md`；SHA256 `d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`。本批逐字节保存为 `silent-proposal-ef0e38a5dbd3bc07.original.md`。

<a id="silent-proposal-7f820c02d39bfaea"></a>

## silent-proposal-7f820c02d39bfaea：死亡统计饱和下SL探索的即时血价

角色：silent。原来源任务：postmortem；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0079。本次没有新增提案id或重写原提案。

证据：NHA2KW0RB7VP A10 F33T1，首试states 283391→283397从30→29，末试283502→283507从30→23，敌合408→400/384，即损1/7、跨轮净扣8/24（含下一轮遗物，不能全归卡牌）。decisions 277248/277250为第5试覆盖，277272/277274为第6试重放；初案精确切击已被弃后重问，不是完整执行原四步。原277248记录rollout 24/24全死、B2双方0；不换成别题的样本数。

当前实现与旧规则：5604982e13890e0e2bc8bf8246272e8267321c0b记录的是当前轮预测对比，不跨弃牌证明整条线执行，也不提供由实盘校准的新饱和排序门槛。首T1无前轮结束请求，离线工具保留unknown；上述差额为人工核对的真实端点。

本次处置：waiting。缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对完整后继；同局六次失败和1/7血价差不足确定新SL阈值。

预期行为与验证：现有生产规则保持。原答、覆盖、实际动作分别记录；保留两侧敌HP与未击杀、重问、未知抽牌和完整后继，不以全死并列解释为同安全，不禁止全部探索。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md`；SHA256 `bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`。本批逐字节保存为 `silent-proposal-7f820c02d39bfaea.original.md`。

<a id="silent-proposal-04b6b430759815ed"></a>

## silent-proposal-04b6b430759815ed：油灯首次负面、蟹朝向、费用与能力兑现

角色：silent。原来源任务：experience-update；实现任务：strategy-proposal，本批 20261016-050119-s2-strategy-proposal。
账本：silent-0005、silent-0006、silent-0021、silent-0011、silent-0065、silent-0264、silent-0079、silent-0133、silent-0169、silent-0189、silent-0013、silent-0053、silent-0162、silent-0265。本次没有新增提案id或重写原提案。

证据：NHA A10 F17T1 states 283146→283147首次毒5实际建10；F33T1 283395/283506萎靡X1实−2力/2弱。K3676LU8B0UH A1 F30T2 217009→217010的带毒刺击+目标是index1 BOWLBUG_NECTAR，0→8毒；index0 BOWLBUG_ROCK没有毒，不错取第一敌人。NHA F33T2 283398→283400保持−2力/1弱，转向后15挡仍29→22；不以显示1再次乘1.5代实际2。A1、A7、A10与未观察组合分列。

当前实现与旧规则：68711002f15b298b8863d2258ee5da236da151d2为实际live祖先，silent-crusher-facing.ts限定A10已观察move/力量/弱/名单，并从当前进阶库读取首样本，不能关掉整项油灯/能力联合要求。原运行b8ca9311+dirty无法还原。

本次处置：waiting。蟹朝向已有live窄实现；仍缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及未覆盖X值、升级组合和能力整战后继。

预期行为与验证：现有生产规则保持。联合目标身份、首次消费前后、当前费用/手数/能力实际建立及跨战恢复，未知零X/其他负面/多层不外推；持有或建立能力不等于后轮已兑现。

反例/未知与回退：没有支持替代整战获胜的受控结果，不以局部端点或失败证明新门槛；未来规则仅在本人核实分支生效，其他角色及未观察组合保持等价。若后续实现，单独源码提交、固定输入撤源失败/恢复通过、沙箱自测及实际live核验后通知Roy；本批无上线可回退。

原稿：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md`；SHA256 `188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`。本批逐字节保存为 `silent-proposal-04b6b430759815ed.original.md`。

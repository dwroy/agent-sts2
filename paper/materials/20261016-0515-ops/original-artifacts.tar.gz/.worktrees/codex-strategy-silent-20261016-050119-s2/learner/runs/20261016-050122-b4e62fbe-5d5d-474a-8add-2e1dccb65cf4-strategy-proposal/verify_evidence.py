import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

extractor = module('extractor', ROOT / 'learner/extract_evidence.py')
chain = module('resource_chain', ROOT / 'learner/resource_chain.py')
runs = json.loads((OUT / 'run-identities.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
focused = {
    'KEN58SH9SLZ6': [15, 17],
    'TXZ6RVMQA09D': [48, 49],
    'WQZVENQ7DTRP': [33],
    '1913SE84AXQF': [17, 31],
    'Q6M2Y34MWKRE': [2, 8, 9],
    'NHA2KW0RB7VP': [33],
}
inputs = {r: {'run': runs[r], 'decisions': [], 'states': []} for r in focused}
sl = collections.defaultdict(list)
compact = collections.defaultdict(list)
decisions = collections.defaultdict(list)
resources = collections.defaultdict(list)
verified = []
for item in manifest:
    stream = item['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = dict.fromkeys(runs, 0)
    source = Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')
    with source.open('rb') as original, path.open('rb') as frozen:
        for encoded in frozen:
            digest.update(encoded)
            evidence = json.loads(encoded)
            row, run_id = evidence['row'], evidence['run_id']
            assert evidence['source'] == str(source)
            assert 0 <= evidence['offset'] < item['source_size']
            assert evidence['offset'] + evidence['bytes'] <= item['source_size']
            original.seek(evidence['offset'])
            raw = original.read(evidence['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == evidence['sha256']
            assert json.loads(raw) == row
            assert extractor.run_identity(row) == run_id
            assert runs[run_id]['character'].lower() == 'silent'
            counts[run_id] += 1
            if stream == 'states':
                state = row['state']
                info = state.get('run') or {}
                combat = state.get('combat') or {}
                player = combat.get('player') or {}
                assert info['character_id'].lower() == 'silent'
                assert info['ascension'] == runs[run_id]['ascension']
                floor = info.get('floor')
                view = {
                    'line': evidence['line'], 'offset': evidence['offset'],
                    'sha256': evidence['sha256'], 'ts': row.get('ts'),
                    'observed_ts': row.get('observed_ts'), 'fingerprint': row.get('fingerprint'),
                    'floor': floor, 'turn': state.get('turn'), 'screen': state.get('screen'),
                    'in_combat': state.get('in_combat'),
                    'hp': info.get('current_hp'), 'max_hp': info.get('max_hp'),
                    'potions': info.get('potions'), 'relics': info.get('relics'),
                    'player': player,
                    'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'damage', 'block', 'cost', 'description', 'dynamic_vars']} for c in combat.get('hand') or []],
                    'enemies': combat.get('enemies'),
                }
                compact[run_id].append(view)
                reduced = {
                    'ts': row.get('ts'), '_line': evidence['line'], 'run_id': run_id,
                    'state': {k: state.get(k) for k in ['run_id', 'in_combat', 'turn', 'screen']},
                }
                reduced['state']['run'] = {k: info.get(k) for k in ['character_id', 'floor', 'current_hp', 'max_hp', 'potions']}
                reduced['state']['combat'] = {'enemies': combat.get('enemies')}
                resources[run_id].append(reduced)
                if run_id in focused and floor in focused[run_id]:
                    inputs[run_id]['states'].append({**row, '_line': evidence['line']})
            elif stream == 'decisions':
                selected = {k: v for k, v in row.items() if k != 'agent_view'}
                selected['_line'] = evidence['line']
                decisions[run_id].append(selected)
                if run_id in focused and row.get('floor') in focused[run_id]:
                    inputs[run_id]['decisions'].append(selected)
            elif stream == 'sl-attempts':
                sl[run_id].append({**row, '_line': evidence['line']})
    assert counts == item['counts'], (stream, counts, item['counts'])
    assert digest.hexdigest() == item['output_sha256'], stream
    verified.append({'stream': stream, 'source_size': item['source_size'], 'counts': counts,
                     'rows': sum(counts.values()), 'output_sha256': digest.hexdigest(),
                     'offset_bytes_sha_json_identity_verified': True})

for run_id in runs:
    save(OUT / (run_id + '.states-compact.json'), compact[run_id])
    save(OUT / (run_id + '.decisions.json'), decisions[run_id])
    save(OUT / (run_id + '.sl.json'), sl[run_id])
    starts = collections.defaultdict(list)
    for attempt in sl[run_id]:
        if attempt.get('attempt', 1) > 1 and attempt.get('started_at'):
            starts[attempt.get('floor')].append(attempt['started_at'])
    report = chain.resource_chain(resources[run_id], run_id, 'silent', starts)
    save(OUT / (run_id + '.resource-chain.json'), report)
for run_id, value in inputs.items():
    (OUT / (run_id + '.audit-input.json')).write_text(json.dumps(value, ensure_ascii=False) + '\n')
save(OUT / 'evidence-verification.json', {'streams': verified, 'rows': sum(x['rows'] for x in verified),
     'runs': list(runs), 'focus_floors': focused, 'tests': None})
print(json.dumps({'verified_rows': sum(x['rows'] for x in verified),
                 'streams': {x['stream']: x['rows'] for x in verified},
                 'runs': len(runs), 'focused_inputs': {r: {k: len(v[k]) for k in ['states', 'decisions']} for r, v in inputs.items()}}, ensure_ascii=False))

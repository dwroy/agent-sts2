# 静默猎手策略提案核证报告

本批10个原提案全部保留waiting。普通单弃、毒胜保血、一层幽灵和SL资源差值审计已有真实live祖先源码；剩余要求尚缺可验证的完整后继、组合输入或独立留出。本批未确认有充分证据的新源码失配，保持现有游戏行为。

## 身份与基线

- task=strategy-proposal；character=silent；batch=20261018-094302-strategy-proposal。
- 根learn.json对应行reason=proposal；10个proposal_ids、角色、工作树、派发runs一致；没有proposal_repair、research_request或implementation_request。普通专题请求绑定另一历史批次，不承接专题或其他队列。
- 初始干净HEAD=84d37ee0947517411a9825460cfa4f3952ab35d8，按要求git merge --no-edit main快进成功。
- report.base=a39157dabea8791c896df7b5cc477707ec5c89fd；固定live核证点=8c7657bac63f42830854b069a7da894fb295ba62。没有本批提交或合入。
- 派发锚点：RC61MFQM63Y6,XTSV1U9JD34T,BTSRF7JL1W1Y,9Z9H2EXKLF3T,HMVJKM56S4Q8,F4QKG4J1AJJZ,G403VCZ3BH1B,25226ZFLNR1J,JLN5SK17W4FQ,JMH5C51RLN4E。
- 直接关联补充局：9TG1RP5LFAAK,JQPT83P8KDSZ,S9UZAK0JP0C0,7X0W3U8TVA2A,MTQ0EUBJ3R6T。15局全部在runs.jsonl核实为silent；只处理这些对局、原提案和本角色关联账本。

## 证据范围与复核

- 共用extract_evidence.py提取八流，22,424条引用全部逐原物理offset/bytes/SHA256/JSON/显式归局核回；各流source_size、各局计数和输出SHA均保留且一致。
- states=11008，decisions=10609，sl-attempts=109，run-config=16，run-plans=97，brain=570，runs=15，fight-plans=0。run-plans使用run字段，其余同时核run_id/state.run_id/fingerprint.run；不按正文提及归局。
- states/decisions/brain源流各2条坏JSON，不能作为可归局有效证据；不把坏行或fight-plans在本截点选中0条写成历史日志不存在。未覆盖旧报告或零行初稿。
- 精读窗口335帧，24个明确物理行引用均核回；逐局资源链保留观察出口、缺出口、SL重启和多体HP身份歧义。
- 原资源提案十局16个同上限跨幕帧对全部匹配floor(缺失HP×80%)；15局共22对亦匹配。后6对是其他已派/直接关联旧局，不增加独立N，不冒称重做原115/116局训练。
- 本次仅重核旧实帧和算术，没有生产求解/整战模拟、LLM、网络、新自然局、受控完整反事实或自然消费者采用验证。多次SL按相关样本处理。

## 关键观察

1. RC61MFQM63Y6 F23 T3：敏捷1→速度药后6；斗篷实增12挡，防御实增9，末刀本体零伤但被动增4至25挡；次轮临时项撤回。F33 T4生存者后唯一打击确被弃，45HP/7挡仍对57激光。
2. BTSRF7JL1W1Y F31 T2：唯一突然一拳被弃。13牌挡+3覆甲对30攻击，实际35→21损14；石虫下轮眩晕不要求全场零损。F30胜战70→42并耗明晰，F31实入42。
3. XTSV1U9JD34T F48 T8：32血先付凋萎9到23再毒胜，无恢复进入F49。幽灵T1实增无实体1，26攻击变1，16挡下零损，次轮留10挡；六次均T1喝，缺延后实打对照。末T3损22，末T4夜魇3层未兑现便死，1+6−16=−9与致死一致。
4. 9Z9H2EXKLF3T F48末T11敌112→32净降80，与39+38毒及一次3反伤一致；玩家3血归零，死亡截断处毛伤与未执行击数未知。F35当前HP66→30、上限77→69分别记录，不把上限损失8再加到敌伤。
5. 7X0W3U8TVA2A F31 T13：后段零毒→7，当步25HP不变，结束扣7至18；前段另扣8到4，中段接续至25，玩家仍死。一次组合不能分离基础药效和头骨贡献，不能外推其他目标、叠毒、重接、持有价或时点。
6. MTQ0EUBJ3R6T F23四试T3同10HP/敌61和41；前三次29挡/损0/净扣13，末次19挡/损8/净扣19。两毒素10+敌17=27，局部差8血/6净伤成立；原线也无已核整战胜线，24/24败样本不能替实际必死证明。

## 逐项处置

### silent-proposal-03754e1265894000

牌挡敏捷/脆弱/柔嫩逐张核；折扇被动挡、触发时点与持有能力分源。

证据局号/层/回合：RC61MFQM63Y6，A10，F17 T2/T11、F23 T3/T4、F29 T3/T4、F33 T4。实核重点为 states:285222—285230 与285411—285415。

账本：silent-0006,silent-0011,silent-0013,silent-0080,silent-0088,silent-0101,silent-0232,silent-0253。

核证：F23 T3预判后敏捷1，速度药后6；斗篷实增12挡，后续防御实增9，末刀本体零伤但被动实增4至25挡；次轮临时属性撤回。与原提案的局部观察一致。

反例与范围：末次蟹战并未建立可持续收益后安全通关；F33普通生存者后唯一打击实际被弃。局部属性符合观察，不能证明未执行能力或另一出牌序能赢。

处置：waiting。已核逐牌属性与被动挡；本批未定位现有实现的新失配，原八组件尚缺完整、同条件的消费者回放及未观察首刀组合边界，保留waiting。

预期行为与验证：现有选择、药价、SL及终局规则保留。固定上述实帧核逐牌敏捷、脆弱、柔嫩、折扇计数、9层幻影首刀及能力建立时点；只对已观察输入比较求解器与实际后继，未观察条件保留原边界。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-ab055ef7dfbb44e5

验证夜魇收益的存活兑现条件，并只建模本局已观察的幽灵一层无实体；延后饮用整场效果不足，保留旧时点与药价规则。。

证据局号/层/回合：XTSV1U9JD34T，A10，F49六次尝试T1、末次T3/T4；states:286897—286899、286978/286982/286986/286987，decisions:280550/280635。

账本：silent-0140,silent-0069,silent-0005,silent-0206。

核证：幽灵实增无实体1，现场攻击26变1，16挡下本轮零损且次轮留10挡；末次T3实损22。T4夜魇建立3层后，1血/6挡对16攻击仍死，预计剩血−9与致死事实一致。

反例与范围：早喝当轮已有零损收益；所有尝试均T1喝，没有延后饮用的实际对照。去掉夜魇或改复制对象的可存活整战后继未观察。

处置：waiting。幽灵一层子项已有live祖先源码66283dd9982bdd7f480da7a4d9bfefea0572a9ac；夜魇存活兑现与延后饮药缺同条件完整后继，不能关闭整项或改时点、药价。

预期行为与验证：现有选择、药价、SL及终局规则保留。沿当前一层幽灵入口回放已核帧；后续取得复制对象/时点对照时锁定抽序、预算和其他条件，再审死亡前收益与整战兑现。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：postmortem；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-0129c465c6f5bd79

强制弃牌后候选重核、毒胜保血候选及夜魇/接管首轮兑现边界。

证据局号/层/回合：BTSRF7JL1W1Y，A10，F31 T2/T3；XTSV1U9JD34T，A10，F48 T8/F49 T4；关联RC61MFQM63Y6 F33 T4。states:286158/286161—286163、286893—286896、285414/285415。

账本：silent-0009,silent-0021,silent-0024,silent-0057,silent-0079,silent-0090,silent-0140,silent-0164,silent-0205,silent-0268,silent-0271。

核证：普通生存者确实弃唯一后继；B局T2实际13牌挡+3覆甲对30攻击，损14而不是候选损4。X局毒胜先付凋萎9，32到23，并以23进F49。

反例与范围：生存者单弃修复与毒胜保血扩展已在真实live祖先源码存在，不能再报同一缺口；也不能据少损血反推F49必胜。接管内部动作没有完整可操作前帧。

处置：waiting。普通单弃和毒胜保血子项已有live祖先源码66283dd9982bdd7f480da7a4d9bfefea0572a9ac；接管内部动作、夜魇后继及跨抽弃完整候选执行归属仍缺。

预期行为与验证：现有选择、药价、SL及终局规则保留。固定单弃与毒胜实帧核当前子分支；其余部分等待明确的接管执行事件及选择/抽牌后可归属后继，不预支前战能力。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-abe9d5d0be109a9f

赢战血价、真实回复与存档恢复接续，连王剩血按实到资源。

证据局号/层/回合：BTSRF7JL1W1Y，A10，F30全战、F31 T1；XTSV1U9JD34T，A10，F47/F48全战及T8、F49 T1。资源链逐窗口保存。

账本：silent-0019,silent-0020。

核证：B局F30胜战70到42且耗明晰，F31实入42并持液态记忆；X局F48虽胜仍97到23净损74，没有恢复就进F49。SL恢复与自然回血及药水新获得分开。

反例与范围：赢战不代表零血价；未抵达营火不能预支回复。完整115局模型训练输入未在本批重做，单条资源链不是路线、休息或留药因果对照。

处置：waiting。已核局部入血与赢战消耗接续；缺原115局完整分源输入、路线/休息消费者校准及同条件后继和独立留出，不能拟新阈值。

预期行为与验证：现有选择、药价、SL及终局规则保留。后续固定分源资源输入，分别验证自然回复、药水获得/饮用/恢复、连王实到HP与路线/休息题面读回；不可把净失血全归敌伤。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-f16527e59b5cc1e0

敏捷/脆弱/覆甲分源、毒与临时减力时点及留挡上限按实帧核。

证据局号/层/回合：BTSRF7JL1W1Y，A10，F17 T5/F31 T2/T3；XTSV1U9JD34T，A10，F48 T8、F49 T1—T4。

账本：silent-0005,silent-0006,silent-0011,silent-0013,silent-0016,silent-0027,silent-0046,silent-0069,silent-0095,silent-0128,silent-0196,silent-0241。

核证：B局石虫16经临时减力为7，甲虫中和后13；总攻击30与13牌挡、3覆甲解释实际损14，次轮石虫眩晕。X局幽灵后留10挡、步法不追补旧挡、尖啸后16攻击仍致死。

反例与范围：一个敌人被全挡而眩晕时，其他敌人仍可造成失血；留挡上限不是每回合免费保底，前场能力与临时属性不能跨战继承。

处置：waiting。局部留挡、减力、毒和眩晕有实帧支持；共同输入下临时属性撤回、留挡上限、毒触发及敌成长的联合消费者结果仍未齐，未定位新可实施失配。

预期行为与验证：现有选择、药价、SL及终局规则保留。按同一原始盘面验证逐牌与回合末/次轮边界，独立核临时力量恢复、覆甲衰减、留挡实际余额和毒触发，缺帧不补值。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-7a8e9ccb7e646538

毒/倍率挡/持牌伤及荆棘按实结算，SL换线预测与整轮实差分账。

证据局号/层/回合：9Z9H2EXKLF3T，A10，F48末试T10/T11、F35胜战；states:287998—288008。

账本：silent-0005,silent-0006,silent-0011,silent-0021,silent-0024,silent-0027,silent-0034,silent-0077,silent-0079,silent-0123,silent-0129,silent-0180,silent-0221。

核证：末试T11敌112到32净降80，与39+38毒及一次3反伤一致；玩家3血归零，不能预支死后第二击反伤。F35当前血66到30与上限77到69分别记录。

反例与范围：死亡截断后只见0HP，不能倒推未截断逐击毛伤；末轮净降80不是80毒。换线后药水时点、抽序和整战后继均可能变化。

处置：waiting。末轮77毒加3反伤及上限/当前血分账已核；仍缺死亡截断处逐击毛伤、完整执行归属和同条件整战后继，不据净差修改SL血价。

预期行为与验证：现有选择、药价、SL及终局规则保留。后续以完整逐击事件账核士兵一次消费、持牌伤、复活与反伤顺序，配对固定原线和换线；预测与实际、净值与毛伤分别保存。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-cd9f76184de6e29a

跨幕缺血80%回复与营火/胜战消耗/SL资源接续按实到节点分账。

证据局号/层/回合：原提案十局：HMVJKM56S4Q8,F4QKG4J1AJJZ,G403VCZ3BH1B,25226ZFLNR1J,JLN5SK17W4FQ,JMH5C51RLN4E,9TG1RP5LFAAK,JQPT83P8KDSZ,S9UZAK0JP0C0,9Z9H2EXKLF3T；A9/A10，F17→18或F33→34，非战斗节点回合不适用。

账本：silent-0019,silent-0020,silent-0243。

核证：原十局16对同上限跨幕帧全部匹配floor(缺失HP×80%)。本批15局总计22对也匹配；后6对是其他已派/直接关联旧局，不计新独立支持。9Z局后段赢战损血、营火、复活、SL恢复另列。

反例与范围：公式的局部吻合不等于完整资源模型已校准；未见先古/遗物交互及更低进阶不推广。F49未到、未来营火不可预支。

处置：waiting。原十局16对跨幕回复公式已核；缺原116局完整资源输入、逐来源路线/休息消费者校准与独立收益验证，不能认证整个资源模型。

预期行为与验证：现有选择、药价、SL及终局规则保留。保持A9/A10及已见条件边界，固定完整资源链后核当前题面/路线/休息/SL消费者读回；补样本须标实际来源与独立分母。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-292f6731bdb9b669

核对静默A10头骨组合毒药水实加7毒与现有窄范围上下文，未知持有价不当已校准零值，不拟合早喝规则。

证据局号/层/回合：7X0W3U8TVA2A，A10，F31 T13；decisions:282021，states:288470→288471→288472；T1原候选281953。

账本：silent-0087,silent-0020。

核证：带头骨组合实喝槽0毒药，对后段零毒实增7；当步本体25不变，结束扣7到18。前段另扣8到4、中段接续到25，玩家仍死。

反例与范围：该次饮药不能分离基础药效和头骨贡献；不能给已有毒的前段、中段、重接状态或其他遗物组合统一赋7，也不能由失败推固定早喝。

处置：waiting。仅后段零毒实加7有实帧；其他目标、叠毒/接续组合及持有价、时点缺可比数据，现有标量observedPoison不能据此给全体目标赋7。

预期行为与验证：现有选择、药价、SL及终局规则保留。若后续补足目标与组合边界，固定药槽/目标/当前毒/遗物回放：后段实测18、当步HP不变，不重复加头骨；未知目标继续标未知，不拟药价。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：postmortem；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-0802f69b28d25079

静默A10同盘SL少一防御以8血换6即时伤；固定核对速度药/毒素/资源链，验证饱和探索血价并保留缺反事实限制。

证据局号/层/回合：MTQ0EUBJ3R6T，A10，F23四次尝试T3，F19/F20资源链；states:288806—288812、288837—288843、288868—288874、288899—288905；decisions:282434。

账本：silent-0079,silent-0019,silent-0044,silent-0080,silent-0253,silent-0011,silent-0214,silent-0189,silent-0046,silent-0222,silent-0243,silent-0262。

核证：同盘10HP、敌61/41，前三次29挡/损0/净扣13，末次19挡/损8/净扣19；两毒素10加敌17共需27。原线与替线的即时血价差8、净伤差6成立。

反例与范围：原线也没有已核整战胜线；多次SL为同一相关样本，后续出牌/抽序亦变。24/24模拟全败不证明实际必死，不能把剩敌差归单张牌整场收益。

处置：waiting。同盘少防御多损8血、多伤6已核，差值审计已有live祖先源码66283dd9982bdd7f480da7a4d9bfefea0572a9ac；缺独立A10留出与固定抽弃、用药时点完整后继，不拟新排序阈值。

预期行为与验证：现有选择、药价、SL及终局规则保留。保留实际四试固定夹具与药水消费事实，分别审计原线、SL替线、完整执行、即时HP缺口和整战结局；新增时间留出后再评估全败排序。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：postmortem；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

### silent-proposal-763a4b9d9f17b815

逐牌敏捷、临时减力、持牌伤和已建立能力的时间边界。

证据局号/层/回合：7X0W3U8TVA2A，A10，F31 T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T，A10，F11 T1、F17 T4—T8、F20 T3、F23 T2—T5。

账本：silent-0005,silent-0006,silent-0011,silent-0013,silent-0044,silent-0046,silent-0053,silent-0080,silent-0087,silent-0189,silent-0214,silent-0222,silent-0235,silent-0253。

核证：本批复核毒药实加7、速度临时属性、两毒素持牌伤与同盘29/19挡、能力未跨战预支等关键窗口；14项的旧账本与经验链接完整保留。

反例与范围：前场建立能力不代表后场已建立；毒药组合不反推基础数值，未知抽牌、自动出牌与昏眩后继不能凭当前知识文字补齐。

处置：waiting。已核局部属性、持牌伤及能力时点；十四项完整联合生产消费者结果与部分能力/昏眩后继仍未齐，本批未确认新的可实施源码失配，保留waiting。

预期行为与验证：现有选择、药价、SL及终局规则保留。按每项已观察边界固定手牌、临时属性、药槽、能力时点和选择/抽牌后继，逐项核生产消费者；未观察组合保持原行为。

拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。

来源任务：experience-update；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。

回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。

## 源码核证与等价范围

- 原10份Markdown逐字节核登记SHA并保存；没有修改原文、重复注册id或手改队列。
- 普通单弃survivorDiscard、毒胜保血preservePoisonWinHp、幽灵observedGhostInAJar、silentSlResourceComparison均经git log -S追溯至真实源码66283dd9982bdd7f480da7a4d9bfefea0572a9ac，并验证为固定live祖先。这仅认证四个子项，不冒标整个原提案duplicate/implemented。
- 冻结15个实际源码/工具叶的base/live原字节、Git blob与SHA，共30份文本快照。初次agent/src/sim/rollout.ts不存在，原失败项保留，补正为agent/src/reflex/rollout.ts另存supplement。没有整仓归档或可执行.ts副本。
- 重要勘误：初次可用13叶中的4个字节差异仅为注释署名；补充rollout实际存在observedSilentQueenAllyStrength功能分支差量。base-live-rollout-difference.patch保留该差量，不能声称本基线与live整套执行源码等价，也不从该分支未派发证据学习新结论。
- 旧局都带+dirty，当前固定源码不重建其完整运行树、知识、抽序或预算。现有局部机制与诊断不证明自然消费者采用、未观察组合或整战量化任务完成。
- 本工作树相对report.base的跟踪文件保持零差异，本批未改源码、任务、knowledge或其他角色行为。

## 验证、账本与交付

- 离线材料算术检查32项通过、0失败；性质仅为原帧复算，不是生产回放、tsc/vitest或源码负控。
- 无生产源码改动，源码撤除失败/恢复通过不适用；未运行仓库tsc/vitest，tests={"tsc":null,"vitest":null,"cases":null}。无提交、合入、版本或shipped。
- 仅经根learner/ledger.py update追加46条silent where.proposal/note；CLI退出0，逐原字节追加按offset/bytes/SHA核回，claim/首证/进阶/prior/原evidence/status/version/effect均保持。没有新增support/repeat或将旧shipped改为proposed。
- 根账本完整check实际退出0：/home/dw/Projects/agent-sts2/paper/materials/learning/ledger.jsonl: 516 item(s), 0 problem(s)
- code_proposals沿用派发10个真实CLI id；implementation_domains=[]。proposal_results逐项waiting，队列最终处置交宿主机械登记，不手改learn.json或队列。
- 源码提交=[]；fixes=[]；merged=null；没有发布版本。本次未合入是因为没有满足证据条件的新实现，原父要求与等待项继续保留。

## 材料索引

- proposal.md：十项原提案、证据、账本、反例、旧/预期行为、验证、回退和任务链。proposal-results.json/report.json：实际逐项处置与机器回报。
- dispatch.json、selected-proposals.json、run-identities.json、all-run-identities.json、original-proposals/、ledger-selected.json、ledger-source-rows.jsonl：冻结身份和原链。
- evidence/evidence-manifest.json、evidence-check.json、observed-windows.jsonl、exact-frames.json、decision-windows.jsonl、window-analysis.json、act-boundaries.json、resource-chains/：原字节及观察材料。
- source-pin.json、source-pin-supplement.json、source-pin-validation.json、source-pins/*.txt、base-diff.patch、base-live-source-difference.patch、base-live-rollout-difference.patch：固定源码与差量。
- audit_evidence.py、verify_observations.py、audit.log、observation-checks.json/log：scratch内材料复核工具和实际0回执。
- ledger-updates.jsonl、ledger-cli.stdout/stderr.txt、ledger-update-receipt.json、ledger-check.log：唯一账本写入及追加证明。
- diagnostic-errors.md、decision-diagnostics.json、report-generation-initial.failure.txt：只读诊断和报告格式断言的失败/更正，不当产品失败。
- 最终clean检查及artifact-manifest另存；所有过程材料留在本批scratch，不在模型运行时删除工作树。

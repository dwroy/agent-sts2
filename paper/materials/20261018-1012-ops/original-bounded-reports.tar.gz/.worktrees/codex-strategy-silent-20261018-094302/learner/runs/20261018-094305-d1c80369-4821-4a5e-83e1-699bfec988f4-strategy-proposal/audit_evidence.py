import collections
import hashlib
import importlib.util
import json
from pathlib import Path


SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def write(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(entity):
    return {p.get("power_id"): p.get("amount") for p in entity.get("powers", [])}


def compact(item):
    row = item["row"]
    state = row["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "source": {k: item[k] for k in ("source", "line", "offset", "bytes", "sha256", "run_id")},
        "ts": row.get("ts"), "floor": run.get("floor"), "turn": state.get("turn"),
        "screen": state.get("screen"), "in_combat": state.get("in_combat"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "player": {**{k: player.get(k) for k in ("current_hp", "max_hp", "block", "energy", "cards_played_this_turn", "attacks_played_this_turn")}, "powers": powers(player)},
        "potions": run.get("potions"),
        "enemies": [{**{k: e.get(k) for k in ("index", "enemy_id", "current_hp", "max_hp", "is_alive", "intents", "next_move_id", "move")}, "powers": powers(e)} for e in combat.get("enemies") or []],
        "hand": [{k: h.get(k) for k in ("index", "card_id", "upgraded", "energy_cost", "is_playable", "can_play", "dynamic_values", "resolved_rules_text")} for h in combat.get("hand") or []],
    }


def main():
    extractor = module("extractor", WORKTREE / "learner/extract_evidence.py")
    resources = module("resource_chain", WORKTREE / "learner/resource_chain.py")
    runs = json.loads((SCRATCH / "all-run-identities.json").read_text())
    manifest = json.loads((SCRATCH / "evidence/evidence-manifest.json").read_text())
    state_rows = collections.defaultdict(list)
    sl_starts = collections.defaultdict(lambda: collections.defaultdict(list))
    stream_results = []
    windows = []
    exact = {}
    wanted = {285411, 285412, 285413, 285414, 285415, 286158, 286161, 286162, 286163,
              286893, 286894, 286896, 286897, 286898, 286899, 286978, 286982,
              286986, 286987, 288470, 288471, 288472, 288904, 288905}
    focus = {
        "RC61MFQM63Y6": {23: {3, 4}, 29: {3, 4}, 33: {4}},
        "XTSV1U9JD34T": {48: {8}, 49: {1, 2, 3, 4}},
        "BTSRF7JL1W1Y": {17: {5}, 31: {2, 3}},
        "9Z9H2EXKLF3T": {48: {7, 8, 10, 11}},
        "7X0W3U8TVA2A": {31: {1, 2, 13}},
        "MTQ0EUBJ3R6T": {17: {8}, 23: {3, 4, 5}},
    }
    decision_summary = collections.defaultdict(collections.Counter)
    decision_windows = []
    schema = {}
    for stream in manifest:
        name = stream["stream"]
        path = SCRATCH / "evidence" / (name + ".evidence.jsonl")
        output_sha = hashlib.sha256()
        counts = collections.Counter()
        source_handle = None
        source_name = None
        with path.open("rb") as handle:
            for encoded in handle:
                output_sha.update(encoded)
                item = json.loads(encoded)
                assert item["run_id"] in runs
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                if item["source"] != source_name:
                    if source_handle is not None:
                        source_handle.close()
                    source_handle = Path(item["source"]).open("rb")
                    source_name = item["source"]
                source_handle.seek(item["offset"])
                original = source_handle.read(item["bytes"])
                assert hashlib.sha256(original).hexdigest() == item["sha256"]
                row = json.loads(original)
                assert row == item["row"]
                assert extractor.run_identity(row) == item["run_id"]
                run_id = item["run_id"]
                counts[run_id] += 1
                schema.setdefault(name, {"keys": list(row), "sample_run": run_id})
                if name == "states":
                    state = row["state"]
                    run = state.get("run") or {}
                    assert str(run.get("character_id", "")).lower() == "silent"
                    combat = state.get("combat") or {}
                    slim = {"_line": item["line"], "ts": row.get("ts"), "state": {
                        "run_id": run_id, "run": {k: run.get(k) for k in ("character_id", "floor", "current_hp", "max_hp", "potions")},
                        "turn": state.get("turn"), "screen": state.get("screen"), "in_combat": state.get("in_combat"),
                        "combat": {"enemies": [{k: e.get(k) for k in ("index", "enemy_id", "current_hp", "max_hp", "is_alive")} for e in combat.get("enemies") or []]},
                    }}
                    state_rows[run_id].append(slim)
                    if state.get("turn") in focus.get(run_id, {}).get(run.get("floor"), set()):
                        windows.append(compact(item))
                    if item["line"] in wanted:
                        exact[str(item["line"])] = compact(item)
                elif name == "sl-attempts":
                    floor = row.get("floor")
                    timestamp = row.get("started_at")
                    if row.get("attempt", 1) > 1 and type(floor) is int and isinstance(timestamp, str):
                        sl_starts[run_id][floor].append(timestamp)
                elif name == "decisions":
                    decision = row.get("decision") or {}
                    label = decision.get("label", row.get("label", "?")) if isinstance(decision, dict) else "?"
                    decision_summary[run_id][label] += 1
                    if row.get("turn") in focus.get(run_id, {}).get(row.get("floor"), set()):
                        decision_windows.append(item)
        if source_handle is not None:
            source_handle.close()
        assert output_sha.hexdigest() == stream["output_sha256"]
        assert {r: counts[r] for r in runs} == stream["counts"]
        stream_results.append({**stream, "verified_rows": sum(counts.values()), "physical_sha_identity_and_output_verified": True})

    chains = {}
    (SCRATCH / "resource-chains").mkdir(exist_ok=True)
    boundaries = []
    for run_id, entries in state_rows.items():
        chain = resources.resource_chain(entries, run_id, "silent", sl_starts[run_id])
        write("resource-chains/" + run_id + ".json", chain)
        chains[run_id] = {"combats": len(chain["combats"]), "resource_changes": len(chain["resource_changes"])}
        for before, after in zip(entries, entries[1:]):
            a, b = before["state"]["run"], after["state"]["run"]
            if (a["floor"], b["floor"]) not in ((17, 18), (33, 34)):
                continue
            boundary = {"run_id": run_id, "from_line": before["_line"], "to_line": after["_line"], "from_floor": a["floor"], "to_floor": b["floor"], "before_hp": a["current_hp"], "after_hp": b["current_hp"], "before_max": a["max_hp"], "after_max": b["max_hp"]}
            if a["max_hp"] == b["max_hp"] and type(a["current_hp"]) is int and type(a["max_hp"]) is int:
                boundary["observed_heal"] = b["current_hp"] - a["current_hp"]
                boundary["restricted_formula"] = (a["max_hp"] - a["current_hp"]) * 80 // 100
                boundary["matches"] = boundary["observed_heal"] == boundary["restricted_formula"]
            boundaries.append(boundary)

    (SCRATCH / "observed-windows.jsonl").write_text("".join(json.dumps(w, ensure_ascii=False) + "\n" for w in windows))
    (SCRATCH / "decision-windows.jsonl").write_text("".join(json.dumps(w, ensure_ascii=False) + "\n" for w in decision_windows))
    write("exact-frames.json", exact)
    write("act-boundaries.json", boundaries)
    write("decision-summary.json", decision_summary)
    write("stream-schema.json", schema)
    write("evidence-check.json", {"streams": stream_results, "total_verified_rows": sum(s["verified_rows"] for s in stream_results), "state_runs": len(state_rows), "critical_windows": len(windows), "exact_frames": len(exact), "missing_requested_exact_frames": sorted(wanted - {int(k) for k in exact}), "resource_chains": chains})
    print(json.dumps({"verified_rows": sum(s["verified_rows"] for s in stream_results), "critical_windows": len(windows), "exact_frames": len(exact), "act_boundaries": len(boundaries), "nonmatching_boundaries": [b for b in boundaries if b.get("matches") is not True], "stream_schema": schema}, ensure_ascii=False))


if __name__ == "__main__":
    main()

import json
from pathlib import Path

s = Path(__file__).resolve().parent
read = lambda name: json.loads((s / name).read_text())
ps, dispatch, pin = read('selected-proposals.json'), read('dispatch.json'), read('source-pin.json')
audit, checks, receipt = read('evidence-check.json'), read('observation-checks.json'), read('ledger-update-receipt.json')
results, details = read('proposal-results.json'), read('disposition-details.json')
assert checks['failed'] == 0 and receipt['exit_code'] == 0
assert receipt['verified_own_append_count'] == 46 and not receipt['protected_field_changes']
checklog = (s / 'ledger-check.log').read_text()
assert '0 problem(s)' in checklog

lines = ['# 静默猎手策略提案核证报告', '',
'本批10个原提案全部保留waiting。普通单弃、毒胜保血、一层幽灵和SL资源差值审计已有真实live祖先源码；剩余要求尚缺可验证的完整后继、组合输入或独立留出。本批未确认有充分证据的新源码失配，保持现有游戏行为。', '',
'## 身份与基线', '',
'- task=strategy-proposal；character=silent；batch=20261018-094302-strategy-proposal。',
'- 根learn.json对应行reason=proposal；10个proposal_ids、角色、工作树、派发runs一致；没有proposal_repair、research_request或implementation_request。普通专题请求绑定另一历史批次，不承接专题或其他队列。',
'- 初始干净HEAD=84d37ee0947517411a9825460cfa4f3952ab35d8，按要求git merge --no-edit main快进成功。',
f'- report.base={pin["base"]}；固定live核证点={pin["live"]}。没有本批提交或合入。',
'- 派发锚点：' + ','.join(dispatch['runs']) + '。',
'- 直接关联补充局：9TG1RP5LFAAK,JQPT83P8KDSZ,S9UZAK0JP0C0,7X0W3U8TVA2A,MTQ0EUBJ3R6T。15局全部在runs.jsonl核实为silent；只处理这些对局、原提案和本角色关联账本。', '',
'## 证据范围与复核', '',
f'- 共用extract_evidence.py提取八流，{audit["total_verified_rows"]:,}条引用全部逐原物理offset/bytes/SHA256/JSON/显式归局核回；各流source_size、各局计数和输出SHA均保留且一致。',
'- states=11008，decisions=10609，sl-attempts=109，run-config=16，run-plans=97，brain=570，runs=15，fight-plans=0。run-plans使用run字段，其余同时核run_id/state.run_id/fingerprint.run；不按正文提及归局。',
'- states/decisions/brain源流各2条坏JSON，不能作为可归局有效证据；不把坏行或fight-plans在本截点选中0条写成历史日志不存在。未覆盖旧报告或零行初稿。',
f'- 精读窗口{audit["critical_windows"]}帧，{audit["exact_frames"]}个明确物理行引用均核回；逐局资源链保留观察出口、缺出口、SL重启和多体HP身份歧义。',
'- 原资源提案十局16个同上限跨幕帧对全部匹配floor(缺失HP×80%)；15局共22对亦匹配。后6对是其他已派/直接关联旧局，不增加独立N，不冒称重做原115/116局训练。',
'- 本次仅重核旧实帧和算术，没有生产求解/整战模拟、LLM、网络、新自然局、受控完整反事实或自然消费者采用验证。多次SL按相关样本处理。', '',
'## 关键观察', '',
'1. RC61MFQM63Y6 F23 T3：敏捷1→速度药后6；斗篷实增12挡，防御实增9，末刀本体零伤但被动增4至25挡；次轮临时项撤回。F33 T4生存者后唯一打击确被弃，45HP/7挡仍对57激光。',
'2. BTSRF7JL1W1Y F31 T2：唯一突然一拳被弃。13牌挡+3覆甲对30攻击，实际35→21损14；石虫下轮眩晕不要求全场零损。F30胜战70→42并耗明晰，F31实入42。',
'3. XTSV1U9JD34T F48 T8：32血先付凋萎9到23再毒胜，无恢复进入F49。幽灵T1实增无实体1，26攻击变1，16挡下零损，次轮留10挡；六次均T1喝，缺延后实打对照。末T3损22，末T4夜魇3层未兑现便死，1+6−16=−9与致死一致。',
'4. 9Z9H2EXKLF3T F48末T11敌112→32净降80，与39+38毒及一次3反伤一致；玩家3血归零，死亡截断处毛伤与未执行击数未知。F35当前HP66→30、上限77→69分别记录，不把上限损失8再加到敌伤。',
'5. 7X0W3U8TVA2A F31 T13：后段零毒→7，当步25HP不变，结束扣7至18；前段另扣8到4，中段接续至25，玩家仍死。一次组合不能分离基础药效和头骨贡献，不能外推其他目标、叠毒、重接、持有价或时点。',
'6. MTQ0EUBJ3R6T F23四试T3同10HP/敌61和41；前三次29挡/损0/净扣13，末次19挡/损8/净扣19。两毒素10+敌17=27，局部差8血/6净伤成立；原线也无已核整战胜线，24/24败样本不能替实际必死证明。', '',
'## 逐项处置', '']
for p, result in zip(ps, results):
    d = details[p['id'].removeprefix('silent-proposal-')]
    lines.extend([f'### {p["id"]}', '', p['summary'] + '。', '',
        '证据局号/层/回合：' + d['evidence'], '',
        '账本：' + ','.join(p['ledger']) + '。', '',
        '核证：' + d['finding'], '',
        '反例与范围：' + d['counterexample'], '',
        '处置：waiting。' + result['reason'], '',
        '预期行为与验证：现有选择、药价、SL及终局规则保留。' + d['validation'], '',
        '拟合/切分：本次只核旧局，不加独立分母、不拟阈值；后续应冻结同角色训练输入和A10时间留出。无关角色及未观察进阶保持等价。', '',
        '来源任务：' + p['source_task'] + '；实现任务：strategy-proposal；授权Roy-2026-10-07-learning。原提案路径和SHA见proposal.md及original-proposals/。', '',
        '回退：本批无源码改动；后续实现只撤实际源码差量，保留并行知识与失败记录，按固定负控、自测、live锁、实际编号和双通知发布。', ''])
lines.extend(['## 源码核证与等价范围', '',
'- 原10份Markdown逐字节核登记SHA并保存；没有修改原文、重复注册id或手改队列。',
'- 普通单弃survivorDiscard、毒胜保血preservePoisonWinHp、幽灵observedGhostInAJar、silentSlResourceComparison均经git log -S追溯至真实源码66283dd9982bdd7f480da7a4d9bfefea0572a9ac，并验证为固定live祖先。这仅认证四个子项，不冒标整个原提案duplicate/implemented。',
'- 冻结15个实际源码/工具叶的base/live原字节、Git blob与SHA，共30份文本快照。初次agent/src/sim/rollout.ts不存在，原失败项保留，补正为agent/src/reflex/rollout.ts另存supplement。没有整仓归档或可执行.ts副本。',
'- 重要勘误：初次可用13叶中的4个字节差异仅为注释署名；补充rollout实际存在observedSilentQueenAllyStrength功能分支差量。base-live-rollout-difference.patch保留该差量，不能声称本基线与live整套执行源码等价，也不从该分支未派发证据学习新结论。',
'- 旧局都带+dirty，当前固定源码不重建其完整运行树、知识、抽序或预算。现有局部机制与诊断不证明自然消费者采用、未观察组合或整战量化任务完成。',
'- 本工作树相对report.base的跟踪文件保持零差异，本批未改源码、任务、knowledge或其他角色行为。', '',
'## 验证、账本与交付', '',
'- 离线材料算术检查32项通过、0失败；性质仅为原帧复算，不是生产回放、tsc/vitest或源码负控。',
'- 无生产源码改动，源码撤除失败/恢复通过不适用；未运行仓库tsc/vitest，tests={"tsc":null,"vitest":null,"cases":null}。无提交、合入、版本或shipped。',
'- 仅经根learner/ledger.py update追加46条silent where.proposal/note；CLI退出0，逐原字节追加按offset/bytes/SHA核回，claim/首证/进阶/prior/原evidence/status/version/effect均保持。没有新增support/repeat或将旧shipped改为proposed。',
'- 根账本完整check实际退出0：' + checklog.strip(),
'- code_proposals沿用派发10个真实CLI id；implementation_domains=[]。proposal_results逐项waiting，队列最终处置交宿主机械登记，不手改learn.json或队列。',
'- 源码提交=[]；fixes=[]；merged=null；没有发布版本。本次未合入是因为没有满足证据条件的新实现，原父要求与等待项继续保留。', '',
'## 材料索引', '',
'- proposal.md：十项原提案、证据、账本、反例、旧/预期行为、验证、回退和任务链。proposal-results.json/report.json：实际逐项处置与机器回报。',
'- dispatch.json、selected-proposals.json、run-identities.json、all-run-identities.json、original-proposals/、ledger-selected.json、ledger-source-rows.jsonl：冻结身份和原链。',
'- evidence/evidence-manifest.json、evidence-check.json、observed-windows.jsonl、exact-frames.json、decision-windows.jsonl、window-analysis.json、act-boundaries.json、resource-chains/：原字节及观察材料。',
'- source-pin.json、source-pin-supplement.json、source-pin-validation.json、source-pins/*.txt、base-diff.patch、base-live-source-difference.patch、base-live-rollout-difference.patch：固定源码与差量。',
'- audit_evidence.py、verify_observations.py、audit.log、observation-checks.json/log：scratch内材料复核工具和实际0回执。',
'- ledger-updates.jsonl、ledger-cli.stdout/stderr.txt、ledger-update-receipt.json、ledger-check.log：唯一账本写入及追加证明。',
'- diagnostic-errors.md、decision-diagnostics.json、report-generation-initial.failure.txt：只读诊断和报告格式断言的失败/更正，不当产品失败。',
'- 最终clean检查及artifact-manifest另存；所有过程材料留在本批scratch，不在模型运行时删除工作树。', ''])
(s / 'report.md').write_text('\n'.join(lines))
proposal = (s / 'proposal.md').read_text().replace('没有新源码失配及足够的新参数证据支持行为变更', '本批未确认新的源码失配，也没有足够的新参数证据支持行为变更')
(s / 'proposal.md').write_text(proposal)
(s / 'diagnostic-errors.md').write_text('''# 诊断失败和更正

- 初次引用不存在的agent/src/sim/rollout.ts；真实路径为agent/src/reflex/rollout.ts，初稿缺失项保留，补正另存。
- 一次rg显式通配路径未展开为现存测试文件，后续改查agent/tests/。
- stream-schema.json在审计完成前读取失败，实际审计完成后生成并核回。
- 临时打印decision-windows将可选questions当必填而KeyError，改用get后另存decision-diagnostics.json；没有修改源数据或丢证据。
- “差异仅注释”只适用于初次已核13叶，补充rollout有功能差量；进度和正式报告已更正，不声称整套执行源码等价。
- 初次报告生成误以账本check成功文本必须含OK而断言失败；实际CLI退出0、516 item(s)/0 problem(s)，更正为检查0 problem(s)。失败发生在写正式报告前，原失败回执另存。
''')
(s / 'report-generation-initial.failure.txt').write_text('''首次报告生成实际退出1：AssertionError。
原因：检查ledger-check.log中包含OK；该CLI实际成功格式为“516 item(s), 0 problem(s)”。
根ledger.py check实际退出0；未改账本、检查结果或源码来绕过断言。write_report.py改为核对真实成功格式。
首次失败发生在report.md/report.json写入之前，保留该回执并重新生成。
''')
report = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-094302-strategy-proposal',
          'base': pin['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in ps], 'implementation_domains': [],
          'proposal_results': results, 'report': str(s / 'report.md')}
(s / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': report['report'], 'proposal_results': len(results), 'all_waiting': all(r['state'] == 'waiting' for r in results), 'ledger_updates': receipt['verified_own_append_count']}, ensure_ascii=False))

# 诊断失败和更正

- 初次引用不存在的agent/src/sim/rollout.ts；真实路径为agent/src/reflex/rollout.ts，初稿缺失项保留，补正另存。
- 一次rg显式通配路径未展开为现存测试文件，后续改查agent/tests/。
- stream-schema.json在审计完成前读取失败，实际审计完成后生成并核回。
- 临时打印decision-windows将可选questions当必填而KeyError，改用get后另存decision-diagnostics.json；没有修改源数据或丢证据。
- “差异仅注释”只适用于初次已核13叶，补充rollout有功能差量；进度和正式报告已更正，不声称整套执行源码等价。
- 初次报告生成误以账本check成功文本必须含OK而断言失败；实际CLI退出0、516 item(s)/0 problem(s)，更正为检查0 problem(s)。失败发生在写正式报告前，原失败回执另存。

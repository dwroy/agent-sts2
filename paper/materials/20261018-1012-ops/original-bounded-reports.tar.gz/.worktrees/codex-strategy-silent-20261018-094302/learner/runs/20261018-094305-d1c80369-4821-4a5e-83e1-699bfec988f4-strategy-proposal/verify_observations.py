import json
from pathlib import Path

s = Path(__file__).resolve().parent
exact = json.loads((s / 'exact-frames.json').read_text())
windows = [json.loads(line) for line in (s / 'observed-windows.jsonl').open()]
by_line = {w['source']['line']: w for w in windows}
by_line.update({int(k): v for k, v in exact.items()})
analysis = json.loads((s / 'window-analysis.json').read_text())
checks = []

def check(name, actual, expected, lines):
    checks.append({'name': name, 'actual': actual, 'expected': expected,
                   'source_lines': lines, 'ok': actual == expected})

def enemy(line, index):
    return next(e for e in by_line[line]['enemies'] if e['index'] == index)

def attack(line):
    return sum(i.get('total_damage') or 0 for e in by_line[line]['enemies']
               if e['is_alive'] for i in e['intents'] or [])

check('普通生存者实际移除唯一后继', [h['card_id'] for h in by_line[285415]['hand']], [], [285414, 285415])
check('原双蟹局只兑现7挡', by_line[285415]['player']['block'], 7, [285415])
check('重复单弃实际移除突然一拳', [h['card_id'] for h in by_line[286162]['hand']], [], [286161, 286162])
check('重复单弃整轮真实失血', by_line[286158]['hp'] - by_line[286163]['hp'], 14, [286158, 286163])
check('分源挡与攻击解释失血', attack(286162) - by_line[286162]['player']['block'] - by_line[286162]['player']['powers']['PLATING_POWER'], 14, [286162, 286163])
check('石虫下轮显示眩晕', enemy(286163, 0)['intents'][0]['intent_type'], 'Stun', [286163])
check('毒胜仍支付凋萎9', by_line[286893]['hp'] - by_line[286894]['hp'], 9, [286893, 286894])
check('连战真实入血23', by_line[286896]['hp'], 23, [286894, 286896])
check('幽灵现场攻击26变1', [attack(286897), attack(286898)], [26, 1], [286897, 286898])
check('幽灵只确认实增一层', by_line[286898]['player']['powers'].get('INTANGIBLE_POWER'), 1, [286897, 286898])
check('幽灵当轮零损且次轮留10挡', [by_line[286899]['hp'], by_line[286899]['player']['block']], [23, 10], [286899])
check('末次T3实际失血22', by_line[286978]['hp'] - by_line[286982]['hp'], 22, [286978, 286982])
check('夜魇已建3层但本轮死亡', [by_line[286986]['player']['powers'].get('NIGHTMARE_POWER'), by_line[286987]['hp']], [3, 0], [286986, 286987])
check('末轮致死预测未构成单独误判', by_line[286986]['hp'] + by_line[286986]['player']['block'] - attack(286986), -9, [286986])
check('毒药实增7不立即扣本体', [enemy(288470, 2)['powers'].get('POISON_POWER', 0), enemy(288471, 2)['powers'].get('POISON_POWER'), enemy(288470, 2)['current_hp'], enemy(288471, 2)['current_hp']], [0, 7, 25, 25], [288470, 288471])
check('后段毒结算扣7至18', enemy(288472, 2)['current_hp'], 18, [288471, 288472])
check('其他目标与接续分账', [enemy(288472, 0)['current_hp'], enemy(288472, 1)['current_hp']], [4, 25], [288470, 288472])
check('该毒药已喝仍失败', by_line[288472]['hp'], 0, [288472])
rc = analysis['RC61MFQM63Y6:F23:T3'][0]
check('预判后速度药敏捷1变6', [by_line[285223]['player']['powers']['DEXTERITY_POWER'], by_line[285224]['player']['powers']['DEXTERITY_POWER']], [1, 6], [285223, 285224])
check('柔嫩逐牌格挡累计12到21', [by_line[285225]['player']['block'], by_line[285227]['player']['block']], [12, 21], [285225, 285227])
check('零直伤末刀被动加4挡', [by_line[285228]['enemies'][0]['current_hp'], by_line[285229]['enemies'][0]['current_hp'], by_line[285229]['player']['block'] - by_line[285228]['player']['block']], [81, 81, 4], [285228, 285229])
check('次轮临时属性撤回', [rc['next']['powers'].get('DEXTERITY_POWER', 0), rc['next']['powers'].get('SPEED_POTION_POWER', 0), rc['next']['powers'].get('ANTICIPATE_POWER', 0)], [0, 0, 0], [285230])
mt = analysis['MTQ0EUBJ3R6T:F23:T3']
check('四试同T3起点', [[g['start']['hp'], g['start']['enemy_hp']] for g in mt], [[10, [[0, 61], [1, 41]]]] * 4, [g['start']['line'] for g in mt])
check('三原线29挡替线19挡', [g['end']['block'] for g in mt], [29, 29, 29, 19], [g['end']['line'] for g in mt])
check('三原线零损替线8损', [g['start']['hp'] - g['next']['hp'] for g in mt], [0, 0, 0, 8], [g['next']['line'] for g in mt])
check('净扣13与19分开', [sum(hp for _, hp in g['start']['enemy_hp']) - sum(hp for _, hp in g['next']['enemy_hp']) for g in mt], [13, 13, 13, 19], [g['next']['line'] for g in mt])
check('末试支付两毒素加攻击27', attack(288904) + 2 * 5, 27, [288904])
check('速度层次轮撤回', by_line[288905]['player']['powers'].get('SPEED_POTION_POWER', 0), 0, [288904, 288905])
z = analysis['9Z9H2EXKLF3T:F48:T11'][0]
check('末轮112到32净降80', z['start']['enemy_hp'][0][1] - z['end']['enemy_hp'][0][1], 80, [288006, 288008])
check('已核毒77与一次反伤3解释净降', 39 + 38 + 3, 80, [288006, 288008])
boundaries = json.loads((s / 'act-boundaries.json').read_text())
check('本次22个跨幕帧对一致', [len(boundaries), sum(b.get('matches') is True for b in boundaries)], [22, 22], [b['to_line'] for b in boundaries])
ps = json.loads((s / 'selected-proposals.json').read_text())
original = next(p for p in ps if p['id'].endswith('cd9f76184de6e29a'))['runs']
restricted = [b for b in boundaries if b['run_id'] in original]
check('原资源提案10局16帧对未变成新样本', [len(set(b['run_id'] for b in restricted)), len(restricted)], [10, 16], [b['to_line'] for b in restricted])
result = {'kind': 'offline_evidence_arithmetic_not_production_tests', 'checks': checks,
          'passed': sum(c['ok'] for c in checks), 'failed': sum(not c['ok'] for c in checks),
          'limitations': ['没有运行生产求解、模拟、LLM或网络；没有生成受控反事实或独立留出样本。', '净HP变化与已观察效果一致不证明逐击毛伤事件账完整。', '多次SL属于相关观察；本次重读不增加独立样本数。']}
(s / 'observation-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'failed': result['failed'], 'failed_items': [c for c in checks if not c['ok']]}, ensure_ascii=False))
raise SystemExit(bool(result['failed']))

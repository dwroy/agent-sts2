import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extractor', Path.cwd() / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = set(dispatch['runs'])
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
data = defaultdict(list)
verification = []
for entry in manifest:
    stream = entry['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    counts = Counter()
    digest = hashlib.sha256()
    with path.open('rb') as selected, (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for encoded in selected:
            digest.update(encoded)
            item = json.loads(encoded)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert raw.endswith(b'\n')
            assert item['offset'] + item['bytes'] <= entry['source_size']
            row = json.loads(raw)
            assert row == item['row']
            assert extractor.run_identity(row) == item['run_id'] in runs
            counts[item['run_id']] += 1
            data[stream].append(item)
    assert digest.hexdigest() == entry['output_sha256']
    assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
    verification.append({**entry, 'verified_rows': sum(counts.values()), 'raw_bytes_and_identity_verified': True})

states = defaultdict(list)
decisions = {}
for item in data['states']:
    state = item['row']['state']
    assert state['run']['character_id'].lower() == 'silent'
    assert state['run']['ascension'] == 10
    states[item['run_id']].append(item)
for item in data['decisions']:
    decisions[item['line']] = item

def ref(item):
    return {key: item[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}

def frame(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'ref': ref(item), 'observed_ts': row.get('observed_ts'), 'screen': state['screen'],
        'floor': state['run']['floor'], 'turn': state['turn'],
        'hp': player.get('current_hp', state['run'].get('current_hp')), 'block': player.get('block'),
        'player_powers': player.get('powers'), 'cards_played': player.get('cards_played_this_turn'),
        'enemies': [{key: e.get(key) for key in ('index', 'enemy_id', 'current_hp', 'max_hp', 'is_alive', 'powers', 'intents')}
                    for e in combat.get('enemies', [])],
    }

def enemy_hp(item):
    return sum(e['current_hp'] for e in item['row']['state']['combat']['enemies'] if e['is_alive'])

pairs = []
for a, b, expected in [
    (270216, 270282, [(3, 10), (15, 17)]),
    (271309, 271348, [(0, 45), (9, 38)]),
    (271992, 272040, [(9, 24), (14, 27)]),
    (271982, 272195, [(2, 25), (10, 34)]),
]:
    selected = [decisions[a], decisions[b]]
    assert selected[0]['run_id'] == selected[1]['run_id']
    assert selected[0]['row']['fingerprint'] == selected[1]['row']['fingerprint']
    members = []
    for item, numbers in zip(selected, expected):
        row = item['row']
        series = states[item['run_id']]
        matches = [i for i, s in enumerate(series) if s['row'].get('observed_ts') == row['observed_ts']
                   and s['row'].get('fingerprint') == row['fingerprint']]
        assert len(matches) == 1
        start = matches[0]
        before = series[start]
        end = next(i for i in range(start + 1, len(series))
                   if series[i]['row']['state']['turn'] != row['turn']
                   or series[i]['row']['state']['run']['floor'] != row['floor']
                   or series[i]['row']['state']['screen'] == 'GAME_OVER')
        after = series[end]
        assert after['row']['state']['screen'] == 'COMBAT'
        assert after['row']['state']['turn'] == row['turn'] + 1
        hp_loss = frame(before)['hp'] - frame(after)['hp']
        hp_progress = enemy_hp(before) - enemy_hp(after)
        assert (hp_loss, hp_progress) == tuple(numbers), (a, b, item['line'], hp_loss, hp_progress)
        members.append({'decision': ref(item), 'attempt': row.get('sl_attempt'),
                        'before': frame(before), 'after': frame(after),
                        'observed_hp_loss': hp_loss, 'observed_enemy_hp_progress': hp_progress,
                        'full_candidate_executed': None, 'causal_effect': None,
                        'state_refs': [ref(s) for s in series[start:end + 1]]})
    pairs.append({'run_id': selected[0]['run_id'], 'floor': selected[0]['row']['floor'],
                  'turn': selected[0]['row']['turn'], 'same_fingerprint': True, 'members': members,
                  'scope': '同指纹回合观测端点；含后续重问，不认证原候选完整执行或单卡因果'})

windows = {'DUZUBAJ3A8GP': {27: {4, 5, 6}}, '5PM6JAQG6FNQ': {38: {3, 4}, 39: {4, 5, 6}},
           'CA5KE8GFJ9X2': {13: {1, 2, 3, 4, 5}}, '8JRE1C4H4Z2W': {33: {2, 5, 11}},
           'YF0LXT1QSTGG': {48: {1, 3, 4, 5}}, 'XP2SL33HT0D9': {33: {1, 2, 3, 4, 5}}}
frames = []
for run, series in states.items():
    for item in series:
        s = item['row']['state']
        if s['turn'] in windows[run].get(s['run']['floor'], set()):
            frames.append(frame(item))
(OUT / 'verified-streams.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
(OUT / 'paired-endpoints.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
(OUT / 'mechanism-frames.json').write_text(json.dumps(frames, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in verification),
                  'counts': {e['stream']: e['counts'] for e in verification},
                  'paired_endpoints': [{'run': p['run_id'], 'floor': p['floor'], 'turn': p['turn'],
                                       'values': [[m['observed_hp_loss'], m['observed_enemy_hp_progress']] for m in p['members']]} for p in pairs],
                  'mechanism_frames': len(frames)}, ensure_ascii=False))

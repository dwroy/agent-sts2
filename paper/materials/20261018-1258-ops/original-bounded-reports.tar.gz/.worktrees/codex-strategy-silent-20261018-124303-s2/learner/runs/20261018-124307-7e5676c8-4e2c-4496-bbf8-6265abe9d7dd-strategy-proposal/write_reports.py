import json,pathlib,hashlib,subprocess
out=pathlib.Path(__file__).resolve().parent
p=json.loads((out/'assigned-proposals.json').read_text())
dispatch=json.loads((out/'dispatch.json').read_text())
source=json.loads((out/'source-pins.json').read_text())
rows=[
('silent-proposal-c20b5139dd0dff71','感染棱柱污染','DUZUBAJ3A8GP F27 T4—6；states 274830—274843','火花3→6；T4末污染6、9挡对12攻击，49→46；T5末污染18、17挡对26攻击，46→37；次轮污染消失。','技能同时带来挡与施毒，现有9点净损不能推出少打技能必胜。','缺原运行实际DB/移动输入与污染、弱、毒、格挡、火花增长的联合生产重放校准；现有逐技能增污染子路径不足以登记整项完成。','冻结原帧和当前进阶事实输入，逐动作验证污染、意图、挡、毒与HP；未执行替线保持未知。'),
('silent-proposal-ae9e692d680e3819','失落与遗忘抢夺','5PM6JAQG6FNQ F39 T4—6；states 274351—274397','末试T4玩家力敏各−4、一步法仅把敏捷恢复至−2；首试失落退场后力量恢复，T6遗忘敏捷6、玩家敏捷−2。','末试毒杀失落仍8血零挡对遗忘19攻击死亡；当前总属性不能等同累计被夺量。','缺逐实体累计被夺量与其他属性来源的完整区分、遗忘退场返敏端点及联合候选校准；不设置固定击杀序。','按实际归局帧建立抢夺来源账，分开步法等新增属性；对敌方退场与index重排保留歧义，不用当前总属性逆推。'),
('silent-proposal-52f1e1bd2e7db0ed','下水道蚌加压','CA5KE8GFJ9X2 F13 T1—5；states 273237—273269','力量0/4/8、喷水11/15/19；T3虚弱后11，T5虚弱后14；T5结束前2血10挡，死亡后敌16血。','覆甲轮初9/9/8/7/6只是层数观察，减层的完整条件未隔离；不把死局当作房间固定成本。','当前进阶首样本HP/攻击读取及房间代价五样本门槛已有；缺原实际移动输入、加压/弱/覆甲联合重放和完整减层条件，不能将局部已实现标为整项duplicate。','以冻结A10移动数据校准五轮状态与实际攻击，房间代价仍要求五个样本；未观察覆甲条件保持未知。'),
('silent-proposal-6dd8bbff876be528','电击机器人增长','5PM6JAQG6FNQ F38 T3—4；states 274308—274317','23上限电击的连续窗内力量2→4、意图17→19；戳刺消失后电击index4→3，T3仍参与30总攻击，T4才退场。','另一先杀爪牙候选未实打；index不是持久实体身份，不把其损3预测当实际省27。','HIGH_VOLTAGE增长路径已有；缺召唤代际持久身份、原实际移动输入及另一杀序完整后继，不规定先杀爪牙。','冻结完整召唤/退场链和移动输入，分别校准旧实体增长与新实体初值，不沿index继承旧计数。'),
('silent-proposal-578e415a259e6835','沙虫SL与资源审计','8JRE1C4H4Z2W F33 T2/T5/T11，原提案另含F17 T6；paired-endpoints.json','首/第三试T2同指纹，实损3/15、敌本体进度10/17；末T11开场5HP，既有2敏捷/余像1，结束前22挡对37，死亡后敌130。','后三次未建立触媒；候选省血不是实际省血，防御替换延长尝试仍败不等于保血错误。','缺跨抽弃牌、生成、用药和重规划的完整候选执行与分来源资源认证；金刚杵→silent-0016历史误链仍须ops→watcher→Roy追溯。','复用已有候选/派发/端点字段，固定原提案全部窗口，补足执行边界与来源未知项；原98局审计本批未重做。'),
('silent-proposal-c0767768bf6a7ab1','实验体全败SL血价','YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348，states 277327—277373','同指纹两回合实损0/9，敌本体进度45/38；同题24/24全败不能抹掉多9血价与少7进度。','第六次恢复防御续步T1零损仍败；原提案记载F33第二试实胜，不能据F48失败禁止全部探索。','同轮端点与候选预测比较已有；缺跨重规划完整候选归属、逐来源HP价及受控整战后继，不从全败样本拟惩罚系数或禁止探索。','以同题和观测时间/指纹连接原答、SL替换与后续动作，缺帧、重问或排队回执保留未知，另留后移整战验证。'),
('silent-proposal-a46bdb7fe711d79a','实验体阶段与能力兑现','YF0LXT1QSTGG F48 末试T3—5；states 277508—277528','111阶段末4血4毒，下一轮212新阶段无旧毒/力量；T4建立触媒2，T5零毒；5敏捷时挡先13后23，第三小刀才获第6敏捷，既有23挡不倒补。','持有升级毒爆发不等本阶段施放；先前已建立毒雾/余像的尝试亦败，不支持能力强制优先。','阶段/持有组件/已建能力快照已有；缺逐候选施毒、毒结算、消耗附伤与敏捷取得顺序的联合执行校准，不启用能力优先级。','分别核阶段清空、当前能力、即时施毒、已结算伤害与后取敏捷；将37本体进度中的小刀本体与消耗附伤分开，后移验证不跨SL存档。'),
('silent-proposal-1044224808015e5c','双蟹零胜率并列SL','XP2SL33HT0D9 F33 T1/T3；decisions 271982/272195、271992/272040','T3同指纹实损9/14、进度24/27；T1同指纹实损2/10、进度25/34，末试同时取得手里剑力量。','末试T2临时减力并用船夹板零损，T3又损4；后续抽序不同，不能单归某张牌，也不能把成长抹去。','缺同抽序、随机药瓶落点和相同预算的完整替线、成长后继及独立验证；B2零胜并列不足以启用新保血门槛。','本局只作发现/固定回归，整局分组、时间后移验证低当轮损失候选；保留原探索、排名与所有选项。'),
('silent-proposal-7cbc6005db712ba9','双蟹能力兑现窗口','XP2SL33HT0D9 F33 末试T2—5；states 278236—278261','T2轮初14挡，镣铐使爪0→−9力/4→0攻击；斗篷后20挡，T3恢复0力；T4火箭57→38→28，4敏脆弱下偏折6挡。','末轮11HP、6挡对17，毒已结算10后两敌153/125仍存活；能力建立不等于结束战斗。','局部机制与只读参考已有；缺抽弃牌后完整候选的联合执行与分来源消费认证；本批未重新核原A1/A6早期历史分支，不把局部实现登记整项duplicate。','固定朝向、虚弱、临时减力及挡的发生顺序；早期两局另需明确原始帧校验，未知升级/叠层不由本批补推。'),
('silent-proposal-c59f592f1427a67e','综合机制、SL及资源','YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1—5；关联原提案的101局历史审计本批未重做','复核上述三组YF/XP同指纹端点与阶段、镣铐、轮初挡、成长兑现；原记录的净HP、候选预测和末轮零血截断分列。','YF阶段结束不等整战获胜；XP赢走廊仍耗血耗药；未知替线/留药不能推成受控收益。','缺逐来源HP/药/恢复账、完整候选执行及路线/休息/药水时机受控替线的联合认证；本批六局不能替代原101局历史审计。','保持原ID，按逐局逐轮资源链和候选执行边界验收；净差、SL恢复、实际回血、弃药与实际喝药分别记录，缺来源保持未知。'),
]
assert [x[0] for x in rows]==dispatch['proposal_ids']
results=[{'id':ident,'state':'waiting','reason':missing} for ident,_,_,_,_,missing,_ in rows]
result={'task':'strategy-proposal','character':'silent','batch':'20261018-124303-s2-strategy-proposal','base':source['base'],'runs':dispatch['runs'],'fixes':[],'skipped':[],'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':dispatch['proposal_ids'],'implementation_domains':[],'proposal_results':results,'report':str(out/'report.md')}
(out/'final-report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
lead=f'''# 本批提案逐项处置

批次：20261018-124303-s2-strategy-proposal；角色：silent；已核范围仅六个派发来源局，均A10。基线完整提交：`{source['base']}`。本批普通提案队列绑定十个原ID；无research_request、implementation_request或proposal_repair。按要求执行`git merge --no-edit main`，结果Already up to date。没有领取其他提案，没有重做原98/101局全历史，没有把六个旧局当新独立支持样本。

十项均waiting。以下保留旧规则、已实现子项与真实待验部分，不新建重复ID、不将局部实现认成宽项duplicate/implemented。现有观察足以核对当轮端点，尚不足以发布本批新增选线规则。没有源码、知识、模型题面、排序或参数变更。

各原Markdown按队列SHA核回并保存`<id>.original.md`；原队列事件、对应账本原行及折叠视图分别见assigned-proposal-events.json、assigned-ledger-events.json、assigned-ledger.json。原经验仅从knowledge/characters/silent/experience.json读取，25条相关条目快照见assigned-experience.json；其他角色私有知识未读取。

'''
parts=[lead]
for ident,title,evidence,observed,counter,missing,validation in rows:
 parts.append(f'''## {title} — {ident}

- 账本：{', '.join(p[ident]['ledger'])}；来源任务：{p[ident]['source_task']}，目标任务：strategy-proposal。
- 本批核实证据：{evidence}。
- 实际观察：{observed}
- 反例与限制：{counter}
- 旧规则与预期行为：沿用原提案，只增可核验事实的方向；当前候选、护栏、探索与权重保持。具体原设计见保存的原Markdown；本批不改变或扩展其职责。
- 处置：waiting。{missing}
- 验证方法：{validation} 新源码若后续实现，须另做撤生产源码失败/恢复通过、固定数据和原沙箱入口验证；本批没有将材料核对当这些测试。

''')
parts.append('''## 拟合、时间切分与回退

不拟合血价常数、HP门槛、能力优先级、药水时机、固定杀序或终局权重。六局全部在2026-10-07结束，本次只是重核旧证据；同存档SL不能拆成训练/验证的独立局，也不新增support/repeat证据。后续独立新局按结束时间后移，现有局只作发现/固定回归。事实/日志接线是否存在、接口是否接受、自然消费及效果各自验收，不以源码阅读或SHA一致替代消费者运行。

本批没有生产提交可回退；保持原行为。后续真正上线应按各提案源码提交回退并通知Roy。本次代码提案仍沿原十ID，不新建重复ID，未登记implemented/shipped或新eval版本。

## 已见历史误链及通知边界

silent-proposal-578e415a259e6835原Markdown把金刚杵链接至silent-0016；本批实际核到0016主张为护喉甲覆甲，不是金刚杵。该问题已在派发原waiting理由中存在，本次没有改写历史、没有向0016追加金刚杵支持，也没有改知识或伪造新账本归属。报告交运维沿原ops→watcher→Roy通知链核实；本批不代填其他角色确认，未声称已送达Roy。
''')
(out/'proposal.md').write_text(''.join(parts))
verified=json.loads((out/'verified-streams.json').read_text());pairs=json.loads((out/'paired-endpoints.json').read_text());identities=json.loads((out/'run-identities.json').read_text())
report=[f'''# 静默猎手策略提案批次回报

本批十项均waiting；没有源码或知识改动、提交、live合入、版本发布或shipped。`fixes=[]`、`merged=null`，测试三项均null。完整基线`{source['base']}`；观测live参考提交`{source['observed_live']}`。工作树已按普通提案流程合main，结果Already up to date。

本次派发绑定、原提案指纹、证据局角色与实际源码范围均完成核对。详细逐项证据、反例、账本、等待条件和验证方法见本目录[proposal.md](proposal.md)，其绝对路径为`{out/'proposal.md'}`。全部原派发ID均保留，未额外领取队列或进入其他专题。

## 证据范围

| 局号 | 角色 | 进阶 | 结束层 | 原运行代码 |
|---|---|---|---|---|
''']
for r in identities:report.append(f"| {r['run_id']} | SILENT | {r['ascension']} | {r['floor']} | {r['code']} |\n")
report.append('''
原运行均为带dirty的历史记录；本批不冒称复原完整开局源码。原日志通过本工作树learner/extract_evidence.py抽取，实际八流输入逐流冻结字节截点；每条记录均已复核原日志offset、bytes、SHA、JSON等值及显式唯一身份，拒绝正文提及作为归局。8274条记录核回；各流截点不是跨流原子快照。

| 流 | source_size | 本批行数 | 全源坏行 | 全源截断行 |
|---|---:|---:|---:|---:|
''')
for e in verified:report.append(f"| {e['stream']} | {e['source_size']} | {e['verified_rows']} | {e['invalid_lines']} | {e['incomplete_lines']} |\n")
report.append('''
states、decisions、brain各有2条全源坏行，保留原状；不能据此断言目标局丢帧。fight-plans在2233957字节截点选中0行，只表示该截点没有选中本批显式身份，不断言原日志缺失，也没有覆盖旧报告/初稿。原始抽取和逐流SHA见evidence/evidence-manifest.json；独立字节复核见verified-streams.json与verify-evidence-v2.log。

## 四组同指纹回合端点

| 局号/层/回合 | 决策原行 | 实际净损血 原/替 | 敌本体进度 原/替 | 失血差/进度差 |
|---|---|---|---|---|
''')
for q in pairs:
 a,b=q['members'];report.append(f"| {q['run_id']} F{q['floor']} T{q['turn']} | {a['decision']['line']}/{b['decision']['line']} | {a['observed_hp_loss']}/{b['observed_hp_loss']} | {a['observed_enemy_hp_progress']}/{b['observed_enemy_hp_progress']} | {b['observed_hp_loss']-a['observed_hp_loss']:+}/{b['observed_enemy_hp_progress']-a['observed_enemy_hp_progress']:+} |\n")
report.append('''
paired-endpoints.json保存原指纹对照、逐帧原引用、前后状态、完整候选执行=null和因果=null。上述数字覆盖后续抽弃牌与重问，不能归给最初候选或单牌，不能当整战胜线。YF全败/XP零胜并列不等同无当轮血价；8JRE当轮多输出亦未结束战斗。维持原探索及所有候选。

机制窗口共443帧，原引用见mechanism-frames.json、精简端点见mechanism-summary.json。重点核到棱柱火花与污染、蚌4/8力、23上限电击17/19攻、失落/遗忘负属性、沙虫22挡/5血/37攻击、实验体阶段重置与零毒触媒、双蟹镣铐/轮初14挡及57→38→28。GAME_OVER显示的后态意图/能力清理不冒当成伤前状态；YF死亡前44攻击/23挡/18HP与死亡页后来显示55分别保留，不用死亡页倒补伤前入伤。详细证据和局限逐项在proposal.md中列出。

## 源码及消费者边界

21组指定源码叶在基线与观测live提交按Git blob、SHA、原字节快照核回；工作叶等于基线。17组字节一致，4组差异完整保存在base-observed-live-source.diff.patch：passive-pieces/explore为历史署名注释，rollout/rollout-live另有既有女王整战模拟分支。没有把局部差异说成整仓等价，也未采用该女王分支学习本批机制。observed-live侧21个末改源码提交均已核为该观测live祖先；这些既有提交不算本批实现。

| 已有子路径 | 核实范围 | 仍缺 |
|---|---|---|
| silent-selection-audit / silent-selection-dispatch | 原答/SL前后预测、首动作请求、单步派发回执；实际整轮字段为未知 | 完整候选执行与重规划后归属 |
| silent-sl-comparison / silent-sl-resource-comparison / silent-hp-guard-audit | 同题候选HP/进度/格挡/成长比较，与实际分开 | 各来源实际HP及后继校准 |
| silent-phase-current / silent-phase-reference | 实验体当前阶段、持有组件、当前能力、阶段结束参考 | 每条候选的逐步施毒/结算与消耗附伤认证 |
| learner/lib/selection-execution、selection-observation、selection-turn、selection-terminal | 相邻观测/整轮窗口/终局端点；缺身份、帧或来源时保持null | 单卡/完整候选因果与逐来源资源消费 |
| monster-db / room-costs | 当前进阶有记录即用HP/攻击事实；房间代价仍五样本 | 历史实际加载DB/移动表与本案联合生产重放 |
| turn-solver / rollout / passive-pieces | 已有污染、增长、临时减力、船夹板等子路径 | 不等于十项原提案联合实现及全部消费者验证 |

本批仅阅读/核字节与日志材料，没有调用上述生产消费者执行、求解器、模拟器、LLM、网络或游戏，也没有运行源码测试。源码快照在source-pins/，完整40位既有live源码提交和每叶证明见source-pins.json。根请求、旧父请求、原提案原文和其他角色保持。

## 逐项处置

''')
for r in results:report.append(f"- `{r['id']}`：waiting。{r['reason']}\n")
report.append('''
## 登记、验证与失败材料

30个关联既有账本只通过根learner/ledger.py update追加本批proposal.md/report.md链接和note；未追加新support/repeat、未新增claim/首证/prior/状态/版本/effect，也不把既有shipped降为proposed。新建提案本应proposed，本批没有新建条目。CLI输入、退出及原追加行offset/bytes/SHA分别保存在ledger-updates.jsonl、ledger-update.log、ledger-append-receipts.json；check结果另存ledger-check.log。最终proposal_results供原调度器接续waiting，不自行改专用队列或learn.json。

无源码变更，撤源码失败/恢复通过、tsc、vitest和固定生产用例均未运行，全部记null；没有把材料断言通过当代码绿。task.diff.patch为空，HEAD保持完整base，tracked/index干净。没有源码提交，因此没有提交前扫描或合入测试成功可报告，也未进入live锁/知识刷新/版本分配/双上线通知流程。

过程失败保留：首次临时schema探针未兼容combat=null，退出1；改为只读非空combat后成功。初版verify_evidence.py报告汇总处括号写错，实际退出1，原脚本verify-evidence-v1.txt与verify-evidence.log保留；更正后verify-evidence-v2.log退出0，核回8274条与四组端点。另有三个只读路径探针找不到并不存在的loader.ts/controller.ts/silent-turn-resources.ts，已改用实际路径；不当成产品缺陷或源码红绿。这些失败未更改生产文件/知识。

silent-0016历史误链仍列运维交接事项：原提案金刚杵链接至护喉甲账本，已保原历史并在CLI note提示ops→watcher→Roy，本批未代填送达/确认。报告结束不关闭量化父要求，不声称学习已入live或大脑采用。

机器回报见final-report.json。
''')
(out/'report.md').write_text(''.join(report))
print(json.dumps({'report':str(out/'report.md'),'proposal':str(out/'proposal.md'),'proposal_results':len(results),'base':source['base']},ensure_ascii=False))

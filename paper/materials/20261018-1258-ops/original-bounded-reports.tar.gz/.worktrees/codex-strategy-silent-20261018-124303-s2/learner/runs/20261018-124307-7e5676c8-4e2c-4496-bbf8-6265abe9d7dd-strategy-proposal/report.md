# 静默猎手策略提案批次回报

本批十项均waiting；没有源码或知识改动、提交、live合入、版本发布或shipped。`fixes=[]`、`merged=null`，测试三项均null。完整基线`27e78f7a66078d981339eefde1ddf2ed2766a26f`；观测live参考提交`efd308ad4aa8ce78c590b8168edb2748163bb5fb`。工作树已按普通提案流程合main，结果Already up to date。

本次派发绑定、原提案指纹、证据局角色与实际源码范围均完成核对。详细逐项证据、反例、账本、等待条件和验证方法见本目录[proposal.md](proposal.md)，其绝对路径为`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-124303-s2/learner/runs/20261018-124307-7e5676c8-4e2c-4496-bbf8-6265abe9d7dd-strategy-proposal/proposal.md`。全部原派发ID均保留，未额外领取队列或进入其他专题。

## 证据范围

| 局号 | 角色 | 进阶 | 结束层 | 原运行代码 |
|---|---|---|---|---|
| CA5KE8GFJ9X2 | SILENT | 10 | 13 | 33f02a6f+dirty |
| 5PM6JAQG6FNQ | SILENT | 10 | 39 | f56da22b+dirty |
| DUZUBAJ3A8GP | SILENT | 10 | 30 | 93298980+dirty |
| 8JRE1C4H4Z2W | SILENT | 10 | 33 | b0f41f03+dirty |
| YF0LXT1QSTGG | SILENT | 10 | 48 | 91c1db90+dirty |
| XP2SL33HT0D9 | SILENT | 10 | 33 | 60685510+dirty |

原运行均为带dirty的历史记录；本批不冒称复原完整开局源码。原日志通过本工作树learner/extract_evidence.py抽取，实际八流输入逐流冻结字节截点；每条记录均已复核原日志offset、bytes、SHA、JSON等值及显式唯一身份，拒绝正文提及作为归局。8274条记录核回；各流截点不是跨流原子快照。

| 流 | source_size | 本批行数 | 全源坏行 | 全源截断行 |
|---|---:|---:|---:|---:|
| states | 14330177522 | 4062 | 2 | 0 |
| decisions | 2535297021 | 3941 | 2 | 0 |
| sl-attempts | 47936687 | 38 | 0 | 0 |
| run-config | 2092326 | 6 | 0 | 0 |
| run-plans | 9334419 | 33 | 0 | 0 |
| brain | 816566233 | 188 | 2 | 0 |
| runs | 372665 | 6 | 0 | 0 |
| fight-plans | 2233957 | 0 | 0 | 0 |

states、decisions、brain各有2条全源坏行，保留原状；不能据此断言目标局丢帧。fight-plans在2233957字节截点选中0行，只表示该截点没有选中本批显式身份，不断言原日志缺失，也没有覆盖旧报告/初稿。原始抽取和逐流SHA见evidence/evidence-manifest.json；独立字节复核见verified-streams.json与verify-evidence-v2.log。

## 四组同指纹回合端点

| 局号/层/回合 | 决策原行 | 实际净损血 原/替 | 敌本体进度 原/替 | 失血差/进度差 |
|---|---|---|---|---|
| 8JRE1C4H4Z2W F33 T2 | 270216/270282 | 3/15 | 10/17 | +12/+7 |
| YF0LXT1QSTGG F48 T1 | 271309/271348 | 0/9 | 45/38 | +9/-7 |
| XP2SL33HT0D9 F33 T3 | 271992/272040 | 9/14 | 24/27 | +5/+3 |
| XP2SL33HT0D9 F33 T1 | 271982/272195 | 2/10 | 25/34 | +8/+9 |

paired-endpoints.json保存原指纹对照、逐帧原引用、前后状态、完整候选执行=null和因果=null。上述数字覆盖后续抽弃牌与重问，不能归给最初候选或单牌，不能当整战胜线。YF全败/XP零胜并列不等同无当轮血价；8JRE当轮多输出亦未结束战斗。维持原探索及所有候选。

机制窗口共443帧，原引用见mechanism-frames.json、精简端点见mechanism-summary.json。重点核到棱柱火花与污染、蚌4/8力、23上限电击17/19攻、失落/遗忘负属性、沙虫22挡/5血/37攻击、实验体阶段重置与零毒触媒、双蟹镣铐/轮初14挡及57→38→28。GAME_OVER显示的后态意图/能力清理不冒当成伤前状态；YF死亡前44攻击/23挡/18HP与死亡页后来显示55分别保留，不用死亡页倒补伤前入伤。详细证据和局限逐项在proposal.md中列出。

## 源码及消费者边界

21组指定源码叶在基线与观测live提交按Git blob、SHA、原字节快照核回；工作叶等于基线。17组字节一致，4组差异完整保存在base-observed-live-source.diff.patch：passive-pieces/explore为历史署名注释，rollout/rollout-live另有既有女王整战模拟分支。没有把局部差异说成整仓等价，也未采用该女王分支学习本批机制。observed-live侧21个末改源码提交均已核为该观测live祖先；这些既有提交不算本批实现。

| 已有子路径 | 核实范围 | 仍缺 |
|---|---|---|
| silent-selection-audit / silent-selection-dispatch | 原答/SL前后预测、首动作请求、单步派发回执；实际整轮字段为未知 | 完整候选执行与重规划后归属 |
| silent-sl-comparison / silent-sl-resource-comparison / silent-hp-guard-audit | 同题候选HP/进度/格挡/成长比较，与实际分开 | 各来源实际HP及后继校准 |
| silent-phase-current / silent-phase-reference | 实验体当前阶段、持有组件、当前能力、阶段结束参考 | 每条候选的逐步施毒/结算与消耗附伤认证 |
| learner/lib/selection-execution、selection-observation、selection-turn、selection-terminal | 相邻观测/整轮窗口/终局端点；缺身份、帧或来源时保持null | 单卡/完整候选因果与逐来源资源消费 |
| monster-db / room-costs | 当前进阶有记录即用HP/攻击事实；房间代价仍五样本 | 历史实际加载DB/移动表与本案联合生产重放 |
| turn-solver / rollout / passive-pieces | 已有污染、增长、临时减力、船夹板等子路径 | 不等于十项原提案联合实现及全部消费者验证 |

本批仅阅读/核字节与日志材料，没有调用上述生产消费者执行、求解器、模拟器、LLM、网络或游戏，也没有运行源码测试。源码快照在source-pins/，完整40位既有live源码提交和每叶证明见source-pins.json。根请求、旧父请求、原提案原文和其他角色保持。

## 逐项处置

- `silent-proposal-c20b5139dd0dff71`：waiting。缺原运行实际DB/移动输入与污染、弱、毒、格挡、火花增长的联合生产重放校准；现有逐技能增污染子路径不足以登记整项完成。
- `silent-proposal-ae9e692d680e3819`：waiting。缺逐实体累计被夺量与其他属性来源的完整区分、遗忘退场返敏端点及联合候选校准；不设置固定击杀序。
- `silent-proposal-52f1e1bd2e7db0ed`：waiting。当前进阶首样本HP/攻击读取及房间代价五样本门槛已有；缺原实际移动输入、加压/弱/覆甲联合重放和完整减层条件，不能将局部已实现标为整项duplicate。
- `silent-proposal-6dd8bbff876be528`：waiting。HIGH_VOLTAGE增长路径已有；缺召唤代际持久身份、原实际移动输入及另一杀序完整后继，不规定先杀爪牙。
- `silent-proposal-578e415a259e6835`：waiting。缺跨抽弃牌、生成、用药和重规划的完整候选执行与分来源资源认证；金刚杵→silent-0016历史误链仍须ops→watcher→Roy追溯。
- `silent-proposal-c0767768bf6a7ab1`：waiting。同轮端点与候选预测比较已有；缺跨重规划完整候选归属、逐来源HP价及受控整战后继，不从全败样本拟惩罚系数或禁止探索。
- `silent-proposal-a46bdb7fe711d79a`：waiting。阶段/持有组件/已建能力快照已有；缺逐候选施毒、毒结算、消耗附伤与敏捷取得顺序的联合执行校准，不启用能力优先级。
- `silent-proposal-1044224808015e5c`：waiting。缺同抽序、随机药瓶落点和相同预算的完整替线、成长后继及独立验证；B2零胜并列不足以启用新保血门槛。
- `silent-proposal-7cbc6005db712ba9`：waiting。局部机制与只读参考已有；缺抽弃牌后完整候选的联合执行与分来源消费认证；本批未重新核原A1/A6早期历史分支，不把局部实现登记整项duplicate。
- `silent-proposal-c59f592f1427a67e`：waiting。缺逐来源HP/药/恢复账、完整候选执行及路线/休息/药水时机受控替线的联合认证；本批六局不能替代原101局历史审计。

## 登记、验证与失败材料

30个关联既有账本只通过根learner/ledger.py update追加本批proposal.md/report.md链接和note；未追加新support/repeat、未新增claim/首证/prior/状态/版本/effect，也不把既有shipped降为proposed。新建提案本应proposed，本批没有新建条目。CLI输入、退出及原追加行offset/bytes/SHA分别保存在ledger-updates.jsonl、ledger-update.log、ledger-append-receipts.json；check结果另存ledger-check.log。最终proposal_results供原调度器接续waiting，不自行改专用队列或learn.json。

无源码变更，撤源码失败/恢复通过、tsc、vitest和固定生产用例均未运行，全部记null；没有把材料断言通过当代码绿。task.diff.patch为空，HEAD保持完整base，tracked/index干净。没有源码提交，因此没有提交前扫描或合入测试成功可报告，也未进入live锁/知识刷新/版本分配/双上线通知流程。

过程失败保留：首次临时schema探针未兼容combat=null，退出1；改为只读非空combat后成功。初版verify_evidence.py报告汇总处括号写错，实际退出1，原脚本verify-evidence-v1.txt与verify-evidence.log保留；更正后verify-evidence-v2.log退出0，核回8274条与四组端点。另有三个只读路径探针找不到并不存在的loader.ts/controller.ts/silent-turn-resources.ts，已改用实际路径；不当成产品缺陷或源码红绿。这些失败未更改生产文件/知识。

silent-0016历史误链仍列运维交接事项：原提案金刚杵链接至护喉甲账本，已保原历史并在CLI note提示ops→watcher→Roy，本批未代填送达/确认。报告结束不关闭量化父要求，不声称学习已入live或大脑采用。

机器回报见final-report.json。

from pathlib import Path
import hashlib,json,subprocess,tarfile

r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0108';pub=r/'paper/materials/20261016-0108-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
transport=json.loads((pub/'watcher-reminder-transport.json').read_text());ident=transport['notice_id'];assert transport['actual_exit_code']==0 and transport['submission_only']
request=r/transport['request']['path'];assert sha(request.read_bytes())==transport['request']['sha256']
reply=json.loads(transport['stdout']);assert reply['result']['type']=='agent_prompted'
agent=reply['result']['agent'];assert agent['pane_id']=='wJ:pJT' and agent['workspace_id']=='wJ' and agent['agent_session']['value']=='01a13dcd-83d4-7c63-b233-f93cf878ecf4'
notice_path=r/'ops/codex-ops/learning-notices'/(ident+'.json');notice=json.loads(notice_path.read_text());proof=notice['ops_forwarded'];f=Path(proof['path']);assert sha(f.read_bytes())==proof['sha256'];receipt=json.loads(f.read_text());ef=Path(receipt['evidence']['path']);assert sha(ef.read_bytes())==receipt['evidence']['sha256'];delivery=json.loads(ef.read_text())
for path in delivery['destinations']:assert delivery['text'] in (r/path).read_text()
write(pub/'notice-status-readback.json',dict(notice_id=ident,original_notice=notice,original_ops_receipt=receipt,original_delivery=delivery,ops_receipt_and_actual_dual_inbox_verified=True,reminder_submission_only=True,watcher_received=bool(notice['watcher_received']),roy_notified=bool(notice['roy_notified']),no_duplicate_notice_ack_or_parent=True,no_new_session_or_experiment=True))
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0108处理既有08473b2ce666b35ebdaca530必要定位勘误事件，原f165普通提案来源/原ops_forwarded及收件箱和for-roy实际双写SHA复核，未新建通知/父项/重复CLI ACK。HERDR_ENV1/本wJ:p5核后，以实际agent get确认同space原wJ:pJT、cwd本仓库、线程01a13dcd-83d4-7c63-b233-f93cf878ecf4空闲；一次herdr agent prompt提交原文/证据/旧新差异/下一步返回rc0及agent_prompted，未等待/轮询、开新会话或改任何权限/任务。成功写入终端只记运输，不当实际开turn/已读/用户已知；watcher_received/roy_notified仍由其本人真实回执闭环，不代Roy ACK。旧RC61 F45支持定位与F33终局矛盾及原行保持，不改基础机制/经验/提案状态/版本或重复研究。仅本人运输记录提交，无代码/账本/论文刷新/测试/对局/账号home模型额度prompt操作。证据paper/materials/20261016-0108-ops/。\n'
note=f'\n- {at} [运维 codex/必要通知运输] 既有学习通知{ident}已向原watcher wJ:pJT/01a13dcd实际提醒一次，rc0/agent_prompted回执留盘；原双写和ops_forwarded保持，提交不等已读，watcher_received与roy_notified待本人回执。未另建父项、实验或会话。回执paper/materials/20261016-0108-ops/watcher-reminder-transport.json。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (r/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,notice_id=ident,ops_forwarded_verified=True,reminder_actual_exit=0,agent_prompted=True,watcher_received=bool(notice['watcher_received']),roy_notified=bool(notice['roy_notified']),only_transport_records=True))
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py']:
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
for f in pub.iterdir():
    if f.is_file():
        copy=p/'archive-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(f.read_bytes())
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(paths=len(entries),transport_only=True)))

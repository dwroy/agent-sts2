import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((HERE / 'dispatch.json').read_text())
runs = set(dispatch['runs'])
spec = importlib.util.spec_from_file_location('extractor', TREE / 'learner/extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks = []


def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})
    if not value:
        raise AssertionError(name)


def git(*args, cwd=TREE):
    return subprocess.check_output(['git', '-C', str(cwd), *args]).strip()


base = git('rev-parse', 'HEAD').decode()
check('本批普通提案身份', dispatch['character'] == 'silent' and dispatch['task'] == 'strategy-proposal'
      and dispatch['worktree'] == str(TREE) and not dispatch.get('research_request')
      and not dispatch.get('implementation_request') and len(runs) == 6)
originals = json.loads((HERE / 'proposal-originals.json').read_text())
check('十份原提案存在且SHA匹配', len(originals) == 10 and all(
    row['exists'] and row['sha256'] == row['expected'] for row in originals))
proposals = json.loads((HERE / 'proposals-input.json').read_text())['initial']
check('原提案角色及派发id一致', set(proposals) == set(dispatch['proposal_ids']) and all(
    row['character'] == 'silent' and set(row['runs']) <= runs for row in proposals.values()))
ledger = json.loads((HERE / 'ledger-input.json').read_text())
check('原账本链接全部属于silent', all(row['character'] == 'silent' for row in ledger.values())
      and {item for row in proposals.values() for item in row['ledger']} == set(ledger))

all_rows = {}
summaries = []
for directory in ['evidence-r2', 'evidence-extra']:
    for manifest in json.loads((HERE / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        digest = hashlib.sha256()
        counts = dict.fromkeys(dispatch['runs'], 0)
        rows = {}
        source = ROOT / 'logs' / (stream + '.jsonl')
        with source.open('rb') as raw_source, (HERE / directory / (stream + '.evidence.jsonl')).open('rb') as evidence:
            for encoded in evidence:
                digest.update(encoded)
                item = json.loads(encoded)
                raw_source.seek(item['offset'])
                raw = raw_source.read(item['bytes'])
                assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert module.run_identity(item['row']) == item['run_id'] in runs
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                assert item['line'] not in rows
                if stream == 'states':
                    run = item['row']['state'].get('run') or {}
                    assert str(run.get('character_id')).lower() == 'silent' and run.get('ascension') == 10
                if stream == 'runs':
                    assert str(item['row']['character']).lower() == 'silent' and item['row']['ascension'] == 10
                rows[item['line']] = item
                counts[item['run_id']] += 1
        check(stream + '原字节/身份/边界/计数', counts == manifest['counts']
              and digest.hexdigest() == manifest['output_sha256'])
        all_rows[stream] = rows
        summaries.append({**manifest, 'selected': sum(counts.values())})
check('八流证据共6995行', sum(len(rows) for rows in all_rows.values()) == 6995)


def state(line):
    return all_rows['states'][line]['row']['state']


def power(entity, key):
    return next((row['amount'] for row in entity.get('powers', []) if row['power_id'] == key), 0)


def enemy(line, name=None):
    enemies = state(line)['combat']['enemies']
    return next(row for row in enemies if name is None or row['enemy_id'] == name)


def player(line):
    return state(line)['combat']['player']


def hand(line, card):
    return next(row for row in state(line)['combat']['hand'] if row['card_id'] == card)


def criterion(line, key):
    return json.loads(all_rows['decisions'][line]['row']['questions']['plan']['criteria'][key])


def decision(line):
    return all_rows['decisions'][line]['row']


check('神化F35实付2能', player(275564)['energy'] - player(275565)['energy'] == 2)
check('神化F43原预测43伤14损', (criterion(269706, 'plan1')['damage_dealt'], criterion(269706, 'plan1')['hp_lost']) == (43, 14))
check('神化F43施放后预测51伤13损', (criterion(269707, 'plan1')['damage_dealt'], criterion(269707, 'plan1')['hp_lost']) == (51, 13))
check('神化F43实际净扣51后损13', enemy(275679)['current_hp'] - enemy(275686)['current_hp'] == 51
      and player(275686)['current_hp'] - player(275687)['current_hp'] == 13)
check('神化后F36后抽毒药已升级', hand(275604, 'DEADLY_POISON')['upgraded'] is True)
check('神化后F36毒药付1能加7毒未扣本体血', player(275604)['energy'] - player(275605)['energy'] == 1
      and enemy(275605)['current_hp'] == enemy(275604)['current_hp']
      and power(enemy(275605), 'POISON_POWER') - power(enemy(275604), 'POISON_POWER') == 7)
check('F45末轮32HP20挡完整需损39', player(275754)['current_hp'] == 32 and player(275754)['block'] == 20
      and sum(sum((intent.get('damage') or 0) * (intent.get('hits') or 1) for intent in row.get('intents', [])
                  if intent.get('intent_type') == 'Attack') for row in state(275754)['combat']['enemies']) == 59)
check('F45末轮三敌未退场', sorted(row['current_hp'] for row in state(275755)['combat']['enemies']) == [21, 77, 80])
check('F43触媒2下12毒结33', power(player(275699), 'ACCELERANT_POWER') == 2
      and enemy(275699)['current_hp'] - enemy(275700)['current_hp'] == 33)
check('8JRE同盘T2指纹一致', decision(270216)['fingerprint'] == decision(270282)['fingerprint'])
check('8JRE候选12血换7伤', criterion(270282, 'plan2')['hp_lost'] - criterion(270282, 'plan1')['hp_lost'] == 12
      and criterion(270282, 'plan2')['damage_dealt'] - criterion(270282, 'plan1')['damage_dealt'] == 7)
check('8JRE候选未来死亡数有别', 'this line 0/24' in criterion(270282, 'plan1')['rollout']
      and 'this line 5/24' in criterion(270282, 'plan2')['rollout'])
check('8JRE护栏候选省12血少18伤', criterion(270264, 'plan4')['hp_lost'] - criterion(270264, 'plan6')['hp_lost'] == 12
      and criterion(270264, 'plan4')['damage_dealt'] - criterion(270264, 'plan6')['damage_dealt'] == 18)
check('蚌力量0/4/8与喷水11/15/19', [power(enemy(line), 'STRENGTH_POWER') for line in [273238, 273252, 273263]] == [0, 4, 8]
      and [enemy(line)['intents'][0]['damage'] for line in [273238, 273252, 273263]] == [11, 15, 19])
check('蚌虚弱后仍成长', enemy(273254)['intents'][0]['damage'] == 11 and enemy(273268)['intents'][0]['damage'] == 14)
check('构筑F33确有雾3触媒1群蛇4', [power(player(274201), key) for key in ['NOXIOUS_FUMES_POWER', 'ACCELERANT_POWER', 'SERPENT_FORM_POWER']] == [3, 1, 4])
check('吸取后力量0敏捷负2敌力2', power(player(273504), 'STRENGTH_POWER') == 0
      and power(player(273504), 'DEXTERITY_POWER') == -2 and power(enemy(273504), 'STRENGTH_POWER') == 2)
check('负敏捷下双防御共6挡且17毒结33', player(273507)['block'] == 6
      and power(enemy(273507), 'POISON_POWER') == 17 and enemy(273507)['current_hp'] - enemy(273508)['current_hp'] == 33)
check('胧光幻象2血仍在场且下一轮成长', enemy(273595, 'PARAFRIGHT')['current_hp'] == 2
      and power(enemy(273595, 'PARAFRIGHT'), 'STRENGTH_POWER') == 3
      and power(enemy(273596, 'PARAFRIGHT'), 'STRENGTH_POWER') == 6)
check('甲虫睡眠3/2/1', [power(enemy(line, 'SLUMBERING_BEETLE'), 'SLUMBER_POWER') for line in [274907, 274914, 274919]] == [3, 2, 1])
check('甲虫醒后18/20/22与力0/2/4', [enemy(line, 'SLUMBERING_BEETLE')['intents'][0]['damage'] for line in [274923, 274929, 274934]] == [18, 20, 22]
      and [power(enemy(line, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER') for line in [274923, 274929, 274934]] == [0, 2, 4])

paths = [
    'agent/src/reflex/silent-apotheosis.ts', 'agent/src/reflex/silent-apotheosis-reference.ts',
    'agent/src/reflex/card-model.ts', 'agent/src/reflex/turn-solver.ts', 'agent/src/reflex/rollout.ts',
    'agent/src/reflex/rollout-live.ts', 'agent/src/reflex/combat-plan.ts',
    'agent/src/reflex/silent-selection-audit.ts', 'agent/src/reflex/silent-selection-dispatch.ts',
    'agent/src/reflex/silent-hp-guard-audit.ts', 'agent/src/reflex/silent-sl-comparison.ts',
    'agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/hand/loop.ts',
    'learner/lib/selection-execution.ts',
]
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode()
sources = []
for path in paths:
    raw = (TREE / path).read_bytes()
    live_raw = subprocess.check_output(['git', '-C', str(ROOT), 'show', live + ':' + path])
    sources.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(),
                    'live_sha256': hashlib.sha256(live_raw).hexdigest(),
                    'equal_bytes': raw == live_raw})
commits = [
    'ba23ca693151fa8c6f7fe035e640dc30f05ccd75',
    'b2805be4ba44b7375c7908d873889372cc3cfe6c',
    'fdaf787a372880b0438e73bcac7e6d2168b038ed',
    'a32050fbce4c2863f640468c2dbf378fc9157074',
]
ancestry = {commit: subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', commit, live]).returncode == 0 for commit in commits}
check('所引窄实现为实际live祖先', all(ancestry.values()))
check('工作树仍无受跟踪改动', not git('status', '--porcelain'))
output = {'base': base, 'live_readback': live, 'streams': summaries,
          'checks': checks, 'sources': sources, 'source_ancestor_checks': ancestry,
          'note': '材料断言和源码追溯，不是tsc/vitest、整战校准或生产消费者成功。'}
(HERE / 'verification.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(checks), 'rows': sum(len(rows) for rows in all_rows.values()),
                  'base': base, 'live': live, 'source_equal': sum(row['equal_bytes'] for row in sources)}, ensure_ascii=False))

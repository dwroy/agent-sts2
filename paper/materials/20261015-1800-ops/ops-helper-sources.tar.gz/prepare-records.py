from pathlib import Path
import subprocess, json, hashlib, re, os, tarfile, importlib.util
root = Path.cwd(); r = root
p = r / 'ops/codex-ops/record-staging/20261015-1800'
pub = r / 'paper/materials/20261015-1800-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-174302-strategy-proposal'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions'] == report['proposal_results']
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and all(x is None for x in report['tests'].values())
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
final = json.loads((s / 'delivery-verification.json').read_text())
assert final['ledger_readback'] == 26 and final['clean'] and final['dispatch_binding_unchanged'] and final['gitleaks_exit_code'] == 0
assert sha((s / 'report.md').read_bytes()) == final['report_sha256'] and sha((s / 'proposal.md').read_bytes()) == final['proposal_sha256']
ev = json.loads((s / 'verification.json').read_text())
assert sum(x['selected'] for x in ev['streams']) == 6995 and len(ev['checks']) == 36 and all(x['passed'] for x in ev['checks'])
assert len(ev['sources']) == 14
for x in ev['sources']:
    a = git('show', report['base'] + ':' + x['path']); z = git('show', ev['live_readback'] + ':' + x['path'])
    assert sha(a) == x['sha256'] and sha(z) == x['live_sha256']
for commit, passed in ev['source_ancestor_checks'].items():
    assert passed is True; git('merge-base', '--is-ancestor', commit, ev['live_readback'])
audit = json.loads((s / '8JRE-audit-summary.json').read_text())
assert audit['segments'] == 113 and audit['all_turn_windows'] == 111 and audit['f33_turn_windows'] == 50
assert audit['f33_status'] == {'unknown': 11, 'observed_turn_endpoints': 39} and audit['full_candidate_results'] == 0
inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]; owned = []
for raw in (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 26
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); seen = set(old.splitlines())
added = b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); before = fold(old); after = fold(old + added)
assert set(before) == set(after)
for ident in before:
    for k in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']: assert before[ident].get(k) == after[ident].get(k), (ident, k)
receipt = {'batch': bid, 'original_report': report, 'native': native, 'canonical_no_change_gate': b['no_change_proposals'], 'source14_sha_and_four_live_ancestors_verified': True, 'two_source_differences_preserved_not_rewritten': True, 'original_material_rows': 6995, 'original_material_assertions': 36, 'material_tests_or_audit_reexecuted': False, 'original_offline_audit': audit, 'owned_ledger_rows': 26, 'protected_fold_preserved': True, 'original_failure_history': ['First in-progress zero-row extraction retained; final first/r2 selected bytes identical, not missing-log evidence.', 'Uppercase SILENT identity comparison and nullable first combat probe failures retained.', 'Truncated tool output and two missing source-path probes preserved, not production failures.'], 'no_source_merge_version_checks_or_game_action': True}
(pub / 'batch-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 350000 and f.suffix in ['.json', '.jsonl', '.md', '.py', '.txt', '.patch'] and f.name not in ['ledger-snapshot.json', 'state-windows.jsonl']]
files += list((s / 'original-proposals').glob('*.md'))
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1800原174302策略rc0/done、十原ID继续waiting，无源码/经验/提交/合入/版本，149d干净WT与testsnull/mergednull门禁核，不重合/补测/重复派单。六Silent A10锚点6995原行/36材料断言与原固定离线消费者回执只读核，不重跑或当生产测试；8JRE原113段/111窗口、F33的50窗中39端点11未知、完整候选结果非null为0，不改护栏/SL/排序或将端点当整候选认证。14源码叶旧livefe646265逐SHA、四窄源真实祖先核；card-model与rollout-live差异保持，窄升级不关闭完整神化/复合提案。真实native Sol6.1/xhigh/input/lease、workspace-write/no-network核。26原CLI仅where/note，旧claim/首证/prior/evidence/status/version保护同验；原运行中零行中稿及r2最终一致、SILENT大小写/首帧combat-null/路径/截断工具错误均原件保留，不当产品bug。无复盘/新经验，不刷新论文；不改对局/账号/模型/额度队列prompt，P2/C2自然验收与宽父沿原归属、不等待未来事件。证据paper/materials/20261015-1800-ops/。\n'
note = f'\n- {at} [ops 策略处置] 原174302十项继续waiting，无源码/合入/版本/补测；26条CLI仅追溯，原6995行/36材料断言和离线审计原件留存。8JRE完整候选结果仍全null，端点/局部子公式不闭合整提案，原分析失败保留；无新增规则或对局操作。回执paper/materials/20261015-1800-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note}; (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in [p / 'prepare-records.py', p / 'seal-records.py', r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'batch': bid, 'waiting': 10, 'own_ledger_rows': 26, 'no_source_tests_merge_release_or_dataset': True, 'protected_fields_preserved': True, 'native_model_and_original_sandbox_verified': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}; values['paper/materials/learning/ledger.jsonl'] = old + added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; rows = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'waiting': 10, 'ledger_rows': 26, 'native_verified': True, 'ledger_check': 0, 'paths': len(rows)}))

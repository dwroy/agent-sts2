import hashlib
import importlib.util
import json
from collections import defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract_evidence', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}


def compact(item):
    s = item['row']['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {
        'source_line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
        'observed_ts': item['row'].get('observed_ts'), 'screen': s.get('screen'),
        'floor': s.get('run', {}).get('floor'), 'turn': s.get('turn'),
        'hp': p.get('current_hp'), 'max_hp': p.get('max_hp'), 'block': p.get('block'),
        'energy': p.get('energy'), 'played': p.get('cards_played_this_turn'),
        'powers': powers(p.get('powers')),
        'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id', 'intents']}
                    | {'powers': powers(e.get('powers'))} for e in c.get('enemies') or []],
        'hand': [{k: h.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'resolved_rules_text']}
                 | {'vars': {v['name']: [v.get('base_value'), v.get('current_value')] for v in h.get('dynamic_values') or []}}
                 for h in c.get('hand') or []],
        'deck_upgrade_count': sum(bool(h.get('upgraded')) for h in s.get('run', {}).get('deck') or []),
    }


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verified = []
streams = {}
for m in manifest:
    stream = m['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    raw = path.read_bytes()
    assert sha(raw) == m['output_sha256']
    rows = [json.loads(line) for line in raw.splitlines()]
    streams[stream] = rows
    counts = defaultdict(int)
    if rows:
        with Path(rows[0]['source']).open('rb') as source:
            for item in rows:
                assert item['offset'] + item['bytes'] <= m['source_size']
                source.seek(item['offset'])
                line = source.read(item['bytes'])
                assert sha(line) == item['sha256']
                row = json.loads(line)
                assert row == item['row']
                assert extractor.run_identity(row) == item['run_id']
                counts[item['run_id']] += 1
    assert all(counts[run] == n for run, n in m['counts'].items())
    verified.append({'stream': stream, 'verified_rows': len(rows), 'source_size': m['source_size'],
                     'output_sha256': m['output_sha256'], 'counts': m['counts'],
                     'invalid_lines_in_full_source': m['invalid_lines'],
                     'incomplete_lines_in_full_source': m['incomplete_lines']})
save('byte-verification.json', verified)

targets = {'VLZ6CCT8AQ0A': [35, 36, 43, 44, 45], '8JRE1C4H4Z2W': [17, 33],
           'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [33, 39],
           '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [30]}
groups = defaultdict(list)
all_states = {}
for item in streams['states']:
    all_states[item['line']] = item
    s = item['row']['state']
    if s.get('run', {}).get('floor') in targets[item['run_id']] and isinstance(s.get('turn'), int) and s.get('combat'):
        groups[(item['run_id'], s['run']['floor'])].append(item)

windows = []
for (run, floor), rows in groups.items():
    segments = []
    segment = []
    previous = None
    for item in rows:
        frame = compact(item)
        restart = previous and (frame['turn'] < previous['turn'] or
            (frame['turn'] == previous['turn'] == 1 and
             isinstance(frame['played'], int) and isinstance(previous['played'], int) and
             frame['played'] < previous['played']))
        if restart:
            segments.append(segment)
            segment = []
        segment.append(frame)
        previous = frame
    if segment:
        segments.append(segment)
    for n, segment in enumerate(segments, 1):
        by_turn = defaultdict(list)
        for frame in segment:
            by_turn[frame['turn']].append(frame)
        turns = list(by_turn)
        windows.append({'run_id': run, 'floor': floor, 'observed_segment': n,
                        'segment_note': '按回合回退/首轮手动计数回退分段，不代替原SL尝试身份',
                        'turns': [{'turn': turn, 'first': by_turn[turn][0], 'last': by_turn[turn][-1],
                                   'next_first': by_turn[turns[index + 1]][0] if index + 1 < len(turns) else None}
                                  for index, turn in enumerate(turns)]})
save('observed-windows.json', windows)

specific = [275564, 275565, 275594, 275595, 275604, 275605, 275679, 275680, 275687,
            275722, 275731, 275732, 275750]
save('apotheosis-fixed-frames.json', [compact(all_states[n]) for n in specific if n in all_states])
specific_decisions = {269706, 269707, 269748, 269754, 269755, 269770, 270216, 270282, 270264}
selected = []
for item in streams['decisions']:
    d = item['row']
    if item['line'] in specific_decisions:
        selected.append({k: item[k] for k in ['line', 'offset', 'bytes', 'sha256', 'run_id']} | {'row': d})
save('decision-fixed-frames.json', selected)

pair = {item['line']: item for item in selected}
save('paired-identity-checks.json', {
    'budget_269748_vs_269754_same_fingerprint': pair[269748]['row']['fingerprint'] == pair[269754]['row']['fingerprint'],
    'sl_270216_vs_270282_same_fingerprint': pair[270216]['row']['fingerprint'] == pair[270282]['row']['fingerprint'],
    'scope': '仅身份比较，不是同预算收益实验或完整候选执行证明',
})
save('sl-selected.json', [item for item in streams['sl-attempts']])
print(json.dumps({'verified_rows': sum(v['verified_rows'] for v in verified),
                  'streams': {v['stream']: v['verified_rows'] for v in verified},
                  'fight_segments': len(windows),
                  'identity_checks': json.loads((OUT / 'paired-identity-checks.json').read_text())}, ensure_ascii=False))

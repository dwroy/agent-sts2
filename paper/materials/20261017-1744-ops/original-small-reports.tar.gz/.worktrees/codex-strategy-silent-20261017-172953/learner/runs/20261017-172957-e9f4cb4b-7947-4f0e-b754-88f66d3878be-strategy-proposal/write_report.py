import json
from pathlib import Path

S = Path(__file__).resolve().parent
BASE = '191459a386eea6f91623b5430a97593850774fec'
BATCH = '20261017-172953-strategy-proposal'
dispatch = json.loads((S / 'dispatch.json').read_text())
adds = {x['row']['id']: x['row'] for x in json.loads((S / 'dispatched-proposal-rows.json').read_text())
        if x['row']['op'] == 'add'}
details = [
('89354805ee4d7e77', '神化升级传播与实际施放身份',
 'VLZ6CCT8AQ0A F35T1、F36T2、F37T5、F43T1—T5、F45T1；s275564→275565、s275679→275680、s275687；d269706/269707/269748/269754。',
 'F35能量7→5，手中防御5→8、打击7→10、匕首雨5→7、工具1费→0；F43后续同牌序43伤/损14与51伤/损13分开保留。现有转换函数对17种已支持卡的普通deck与升级手牌印刷值、费用读回均相符。',
 'F45未施放，生存者后手牌清空；场外deck不能据此记永久升级。F35有重问与改线，37→52伤不全归神化；F43已施放仍掉57血。',
 '已有静默A10已观察转换、同方案与已知后续抽牌传播及候选参考；actual_cast_this_fight仍明确为null。',
 '缺跨抽牌、选牌、药水重问、SL与换战的实际施放持续归属和生产消费者读回，以及未观察升级组合的校准；17种印刷配对不覆盖整个请求。',
 '取得可追溯的施放/重问/换战身份链，逐已见模板与未知组合分开核验；未知保持unknown，不能从持有或升级手牌反推所有后续执行。'),
('f2bfceddb1898dca', '三骑士全败候选与MC预算',
 'VLZ6CCT8AQ0A F43、F44、F45T1/T4/T5；d269748/269754/269770，F45T5开场s275749。',
 '原首问MC707ms、1/12，退化horizon1/samples1/best=null；后问12/12只是另一题的局部样本。F45T5开场三敌HP24/80/77，意图26+17+40，尖啸后的59攻击与20挡、32血缺7分别记账。',
 '攻击候选31损/32伤未实打，实际少损线13损/24伤；缺另一个focus、留药及修复覆盖后的同题完整结果。两次重问不构成同总预算对照。',
 '当前已有预算与候选事实；源码当前boss预算60秒，不沿用旧30秒描述。保留现有预算、护栏、药价和目标选项。',
 '缺模型覆盖充分后的同起点、同随机池、同总预算MC配对、样本成熟度曲线，以及另一focus与留药的完整后继；707ms和两次重问不能确定新预算或药价。',
 '在冻结同一输入与随机池、同总预算条件下比较现策略与分阶段MC，逐时间点保存样本/误差/覆盖；缺覆盖与真实预算耗尽分别判断，不先拟合常数。'),
('283a164780d11e69', '神化经验的同源实现链',
 'VLZ6CCT8AQ0A F35T1、F43T1—T5、F45T1；同原89354805提案证据，原经验silent-apotheosis-combat-upgrades。',
 '原经验提案SHA已核；现有17配对及其限制同89354805，账本0237/0238仍是原条目。',
 '这是同一问题的经验来源链；相同主题或经验已经发布不证明整个源码请求完成。',
 '复用89354805的窄实现与输入，保留原两个CLI id，不再新建重复提案。',
 '同源神化请求仍缺实际施放持续归属、生产读回与未知组合校准；已有窄live实现不足将整项登记duplicate。',
 '沿原id接续实际施放与完整消费验证；仅当整个范围有实际live祖先源码与固定校准证明时再登记完成。'),
('ebbfe3b97548756d', '十五项机制与资源分账',
 'VLZ6CCT8AQ0A F43T1—T5、F45T1—T5及F44；原14账本/15经验对应关系见原文，静默原局资源链保留。',
 'F43升级勒紧6、尖啸8、毒12+11+10/16+15+14；F45普通勒紧4、触媒1。F45T5已有3敏捷，后空翻8、防御12，覆甲后段已无；F44 33/99→67/104包含上限增长5。',
 '不得把临时减力预支到未来，不能把尚未施放毒雾或预计毒算已兑现；赢战掉血与火堆回复均不能省略。没有路线、休息、目标顺序的整战受控反事实。',
 '保留现有逐项机制与事实披露；本批未隔离出一个可凭保存输入确定复现的新源码数值失配。',
 '缺十五子项在同一冻结生产调用中的逐来源、期限、升级组合及战斗—路线—休息联合校准；局部印刷值或源码支持不能认证整项。',
 '逐子项建立真实调用输入与观测差值，分清卡牌、属性、被动、反伤、毒、回复；定位确定失配后才做窄修及撤源码失败/恢复通过。'),
('e5b87be50f28f311', 'SL换线血价与执行归属审计',
 '8JRE1C4H4Z2W F33首/第三试T2，第二试T5，末试T11及F17T6；d270216/270282/270264/270441→270442，s276433→276434。',
 '首/第三试T2原指纹逐字相同；消费者分别读回玩家−3/−15、敌−10/−17，单轮多付12血换7净扣。末试T11整轮敌166→130、玩家5→0；结束请求端点敌154→130、显示37−22=15另记，不能混为一种伤害。',
 '六次SL仍一局；末次防御替换延至T11仍败，不支持一律攻击或一律保血。原journal可能仍写换线前方案，必须优先读SL replacement。',
 '已有原答/护栏/SL/派发前缀与离线端点审计。本批该局66个候选片段全部保持actual_full_candidate_result=null；0/24和5/24不能说成同死率。',
 '缺跨抽牌、选牌、用药、重问及SL的完整候选持续归属与逐来源收益；可核单轮端点和派发前缀不足认证完整候选执行或拟合护栏/探索门槛。',
 '保留真实decision_id、原行号及重问边界，继续核持续归属和逐来源结果；终局实际截断5、显示参考15、未知完整入伤分别验收。'),
('49632bc4878fb597', '属性、虚弱与独立成长',
 'CA5KE8GFJ9X2 F13T1/T3/T5；s273239/273253/273264与d267361/267372/267381。',
 '下水道蚌力量0/4/8与喷水11/15/19逐帧核到；弱后11/14没有取消成长。末轮2血、10挡对14的完整需求4与零血截断2分别记录。',
 '本局关键战没有建立正敏捷；计划中的步法没有取得，不能把计划当实测或把弱当关闭成长。',
 '现有分项路径保留；本批原帧不足认证力量、正负敏捷、弱、独立成长四路径的同一生产调用校准。',
 '缺力量、正负敏捷、虚弱与独立成长四路径的冻结生产联合对照；本局缺正敏捷实测，未定位新的确定子公式失配。',
 '用已观察状态冻结各路径与组合，逐攻击段/逐挡牌核验；没有观察到的正敏捷条件保持缺口，不移用其他角色数据。'),
('66532328a585941f', '持有组件与实际启动',
 '5PM6JAQG6FNQ F33、F39末试T2；末试T2开场s274379/d268455。',
 'F39末试T2无已建立毒雾、目标失落无毒，手持冒泡；原局复盘确认空打付1能零效果。F33雾3/触媒1/群蛇4已建立并赢，属于不同资源与敌人条件。',
 '不能把拥有组件当启动可靠，也不能将F33与F39不同战斗当同盘换序对照。空打事实不提供构筑权重或早铺必胜证据。',
 '保留持有、计划、本战建立与实际结算的分列，不新增启动阈值或牌值。',
 '缺同起始HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照及收益函数；持有组件、跨战胜败或空打端点均不足拟合。',
 '先固定起始资源、抽序、所有重问和建立时点，再比较启动顺序全战结果；按run_id分组，SL不扩独立分母。'),
('43a76a31ba7bdcfa', '吸取、负敏捷、毒与SL范围',
 '61E2QS63Y9WU F17T5/T6/T7；d267610/267612/267616，s273502/273504/273508。',
 '玩家力量2→无列出、敏捷−2，敌力2；T6两防御牌面各3，毒17→15、敌67→34对应33净扣。未列出能力保持null含义，不伪造独立身份或来源。',
 '本场首试60血进入并胜，不是另一条同盘SL救活线；不能从负敏捷仍有毒输出推导新SL门槛或固定出牌偏好。',
 '保留分项观察及原SL规则，未改负敏捷、毒触发或换线权重。',
 '缺同起始HP、构筑及完整抽序的另一可核SL全战线路与生产配对；负敏捷和17+16毒端点不足改变SL范围、偏好或阈值。',
 '冻结吸取前后资源与毒触发端点，再对同盘完整线路做配对；本场仅作发现/回归，后续独立局验泛化。'),
('5264153a4a4b0e5c', '召唤、成长与目标退场',
 '61E2QS63Y9WU F23T1—T5，重点T4/T5；d267696/267699，s273593/273596。',
 'T4幻象14、本体76，实打后下一轮幻象2、本体41、玩家25→10，合47净扣/15血价；两敌力量3→6。幻象未退场，不能把主目标focus当减员。',
 '另一focus幻象的39伤/零损候选未实打；原召唤机制支持不等于航行、复现、退场全链或目标排序整战收益已校准。',
 '现有数据库按当前进阶读召唤及移动数据、源码有living summons与成长路径；保持全部合法目标、相同推演值并列。',
 '缺A10召唤、航行、复现和退场全链的冻结生产校准，以及另一focus完整后继；既有召唤支持与局部端点不证明目标排序整战收益。',
 '按真实当前进阶数据库冻结HP/伤害/移动与召唤输入，核全链实体和退场；比较另一目标序完整后继前不指定首杀。'),
('bddfa690a84e03d0', '睡眠、唤醒、眩晕与成长',
 'DUZUBAJ3A8GP F30四试，重点末试T3—T6；d269058/269062/269068/269073，s275003/275007/275013/275018。',
 '末试T3睡1、T4睡与覆甲不再列出、攻击18；T5力量2攻击20，尖啸后临时−4/14；T6力量4攻击22。末轮1血、16挡，对22显示完整缺口5。',
 '四试均败来自一局；T4多扣3敌血同时多损2玩家血不能只按净伤改全败排序。缺另一同抽顺序的整战胜线，不推固定杀序。',
 '源码已有睡眠与成长分项，保留未知的眩晕接续/组合，未修改血价、排序或SL规则。',
 '缺伤害唤醒、眩晕接续与A10成长的冻结生产全链校准及同抽换序完整后继；四试失败不足拟合血价、全败排序或固定杀序。',
 '冻结四试抽序和状态边界，分自然睡层、伤害唤醒、眩晕接续及成长验证；不能把不同尝试的前后帧拼成因果。'),
]

results = []
parts = ['# 本批十项策略提案复核', '',
         f'批次：{BATCH}；角色：silent；范围：六个派发锚点，均A10。基线：`{BASE}`。',
         '本批为普通已领取队列任务；无research_request/implementation_request，不承接其他专题或提案。',
         '十份原Markdown已按原CLI SHA验证并保存副本；原提案、原账本及复盘历史不覆盖。下面只记录本批核验与未闭合部分。',
         '没有新增游戏规则、源码或经验。各项状态均为waiting，不将局部已有实现冒称整项duplicate/implemented。', '']
for short, title, evidence, support, counter, current, reason, validation in details:
    id = 'silent-proposal-' + short
    item = adds[id]
    results.append({'id': id, 'state': 'waiting', 'reason': reason})
    parts.extend([f'## {id}：{title}', '',
                  '账本：' + '、'.join(item['ledger']) + '。来源任务：' + item['source_task'] + '；实现任务：strategy-proposal。',
                  '证据局/层/回合：' + evidence, '',
                  '支持与本批读回：' + support, '', '反例及边界：' + counter, '',
                  '既有行为与预期：' + current, '', '**waiting：**' + reason, '',
                  '后续验证方法：' + validation, ''])
parts.extend(['## 拟合、时间切分与回退', '',
              '本批六局属于已用于发现的历史A10样本；本次读回不是盲测。每个主题独立局数按run_id计，不将SL、回合或17个配对扩为独立胜负样本。',
              '不拟合预算常数、血价、药水持有价、SL阈值、构筑权重、终局价值或固定杀序。后续验证须先固定全部输入与生产调用，再使用时间后移的新独立静默局；模型覆盖不足保持未知。',
              '没有生产改动，故本批无需源码回退；全部失败记录和缺口保留。以后实现应逐项提交、固定数据撤源码失败/恢复通过、沙箱验证，并只凭实际live祖先源码登记implemented，由ops核实shipped。',
              '本批不新增CLI代码提案id、不重复写历史复盘；给既有账本追加本报告链接时只经根ledger CLI、只写where/note，不添support、不改claim/首证/prior/status/version。'])
(S / 'proposal.md').write_text('\n'.join(parts) + '\n')
(S / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

summary = json.loads((S / 'run-review-summary.json').read_text())
audit = json.loads((S / 'audit-summary.json').read_text())
source = json.loads((S / 'source-readback.json').read_text())
table = ['| 局号 | 死亡层 | 原状态/决策 | 审计楼层 | 审计决策/状态 | 片段/可核轮端点 |',
         '|---|---:|---:|---|---:|---:|']
for r in dispatch['runs']:
    x = summary[r]
    a = next(v for v in audit if v['run_id'] == r)
    table.append(f"| {r} | {x['run']['floor']} | {x['streams']['states']}/{x['streams']['decisions']} | "
                 + ','.join(map(str, x['audit_floors'])) + f" | {x['audit_decisions']}/{x['audit_states']} | {a['segments']}/{a['turn_endpoints']} |")
report = ['# 策略提案复核报告', '',
          f'批次：{BATCH}；角色：静默猎手silent；base：`{BASE}`。',
          '开工tracked/index干净，普通任务git merge --no-edit main返回Already up to date。没有专题绑定或冻结实现请求，逐一处理本批10个proposal_ids，未领取其他id。', '',
          '结论：10项全部waiting；有已实现子项和可核实盘数值，尚无足以完成整个原请求的新实现/全链验证。本批没有定位可凭冻结输入独立复现的新源码数值失配，不新增策略、源码、经验、提交、合入或版本。', '',
          '提案交运维路径：`' + str(S / 'proposal.md') + '`。逐项证据、账本、反例、既有行为、缺口和后续方法均在该文件；机器处置在proposal-results.json。', '',
          '## 身份、冻结与原行核验', '',
          '根learn.json只读本批行；根strategy-research-silent.json属于另一旧专题，条件不匹配，本批保持原队列范围。十份专用提案原文SHA逐项相符；26个关联账本均silent，未使用其他角色私有知识。',
          '共用extract_evidence.py抽取states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流。6995条选中原行逐offset/bytes/SHA及JSON回读相同，所有显式身份无冲突；各流source_size与计数保存在evidence/evidence-manifest.json及evidence-verification.json。',
          '3432状态、3306决策、29条SL流、6配置、33运行计划、183大脑行、6局记录。run-plans使用显式run身份；fight-plans此截点选中0，仅表明未选中，不断言原日志缺失。states/decisions/brain各有2条全流无效JSON；未将无效行拼为本局证据。',
          '六局的runs角色均SILENT、A10、失败；运行code均旧commit+dirty，不以本次base或读取时live替代历史运行树。独立复盘原段已冻结并带偏移/SHA。', '',
          *table, '',
          '## 本次离线消费者验证', '',
          '六份有界输入合计759决策、784状态，保留真实原行号、decision_id、fingerprint与原SHA；窗口内无缺decision_id的元数据排除。每个范围详见上表，不冒称全部历史/全部楼层的生产联合校准。',
          '现有learner/audit-selection.ts六次退出0，产生152个候选片段、141个轮窗口，其中76个轮端点可核。actual_full_candidate_result全部null是消费者的保守边界，不能据此断言没有实际出牌，也不当成新的失败测试或完整执行率0%。',
          '8JRE首/第三试F33T2指纹相同，实盘轮端点分别玩家−3/−15、敌−10/−17；同一局相关尝试，不把12血/7净扣推广为血价。末试T11整轮166→130，结束请求端点154→130、HP5→0与显示37−22=15各自保存；零血截断不冒称完整入伤。',
          'VLZ已有升级转换函数对17种普通deck/升级手牌的印刷值和费用读回相同；这是窄字段核验，未校准所有文本语义、属性组合、隐藏牌堆、实际施放持续身份或全战收益。输出upgrade-pair-readback.json保留逐配对原行。',
          '原帧与现有窄实现有对应，但没有另一目标、用药、启动或SL线路的受控整战结果，因此没有调整现规则。', '',
          '## 源码界限与已有实现', '',
          f"读取时live参考HEAD为`{source['live_readback_head']}`；共20个源码叶记录base blob/工作字节SHA/live字节SHA及最近源码commit祖先布尔。仅是所列叶的读回，不认证整个生产树或自然采用。",
          'silent-apotheosis.ts最近源码ba23ca693151fa8c6f7fe035e640dc30f05ccd75、reference源码30ec2425012eea75f41226b31d8180b1abb837bc均为所读live祖先；前者覆盖已支持17种转换，后者实际施放字段仍null。',
          '选线审计/单动作回执、端点与终局/整轮消费者源码祖先见source-readback.json；原答、替换、pending、重问、最终端点分别保留。已有这些子项不等于10个宽请求已全部实现，故没有将任何整项登记duplicate。',
          'base与最初live所列13叶差异已保存base-to-live-source.patch：两叶仅历史署名注释，rollout.ts另含已上线实验体阶段能力窄修；这些不作为本批六局其他机制的联合校准。当前decision-budget.ts已是boss60秒，仅作源码事实，不从旧局707ms再制定新预算。', '',
          '## 记录、检查与未完成边界', '',
          '没有生产源码变更。撤源码失败/恢复通过不适用；tsc、vitest、cases均null，不借已有测试绿作本批成功。离线数据核验退出0另列，不能替代生产测试。',
          '没有git commit或live合入，不分配release_id，不追加上线决定或规则变更通知，不登记implemented/shipped。其他角色、原对局、运行配置均未改。',
          '仅通过根learner/ledger.py update为26个原账本添加本批提案/报告的where/note追溯；保留原status（包括既有shipped）、claim、首证、prior、旧证据、version及effect，不重复增加support/反例。CLI实收与原行SHA复核另存ledger-cli-results/ledger-update-readback。',
          '原始命令失误及沙箱preflight失败见initial-command-issues.json：路径定位和首个非战斗null探测均已修正，未改产品代码；不把它们记作生产代码失败。',
          '最终HEAD、工作树清洁、纯空diff和敏感数据扫描见completion-verification.json；时间以同目录date记录为准。', '',
          '未闭合的宽请求均保持waiting供新证据接续；本报告不把排队当送达，不代ops/watcher/Roy确认，也不关闭学习父要求。']
(S / 'report.md').write_text('\n'.join(report) + '\n')
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
         'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
ledger = json.loads((S / 'ledger-before.folded.json').read_text())
updates = []
for id in sorted(ledger):
    related = [p for p in dispatch['proposal_ids'] if id in adds[p]['ledger']]
    updates.append({'id': id, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
                    'note': f'{BATCH}复核追溯；关联' + ','.join(related)
                    + '。本批waiting，逐项缺口见报告；6995原行已核，未新增support/反例、游戏结论、源码提交或上线状态；保留原claim/首证/prior/status/version/effect。'})
(S / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
assert set(final['code_proposals']) == {x['id'] for x in results}
print('proposal.md、report.md、result.json及26项仅追溯CLI输入已保存')

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
EVIDENCE = SCRATCH / 'evidence'
DISPATCH = json.loads((SCRATCH / 'dispatch.json').read_text())
RUNS = DISPATCH['runs']
FLOORS = {'VLZ6CCT8AQ0A': [35, 36, 37, 43, 44, 45],
          '8JRE1C4H4Z2W': [17, 33], 'CA5KE8GFJ9X2': [13],
          '5PM6JAQG6FNQ': [33, 39], '61E2QS63Y9WU': [17, 23],
          'DUZUBAJ3A8GP': [30]}


def write(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = None
    ids = [row.get('run_id'), row.get('run'), state.get('run_id'),
           fp.get('run') if isinstance(fp, dict) else None]
    values = {x for x in ids if isinstance(x, str) and x and x != 'run_unknown'}
    return next(iter(values)) if len(values) == 1 else None


manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
grouped = {stream['stream']: defaultdict(list) for stream in manifest}
verification = []
for stream in manifest:
    name = stream['stream']
    digest = hashlib.sha256()
    counts = Counter()
    with (EVIDENCE / (name + '.evidence.jsonl')).open('rb') as f:
        with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
            for line in f:
                digest.update(line)
                item = json.loads(line)
                assert identity(item['row']) == item['run_id']
                assert item['offset'] + item['bytes'] <= stream['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                grouped[name][item['run_id']].append(item)
                counts[item['run_id']] += 1
    assert digest.hexdigest() == stream['output_sha256']
    assert {r: counts[r] for r in RUNS} == stream['counts']
    verification.append({'stream': name, 'verified_raw_lines': sum(counts.values()),
                         'source_size': stream['source_size'], 'output_sha256': digest.hexdigest(),
                         'identity_conflicts_selected': 0, 'offset_hash_and_json_equal': True})
write('evidence-verification.json', verification)

summary = {}
key_states = []
key_lines = set([275564, 275565, 275594, 275595, 275604, 275605, 275639, 275640,
                 275679, 275680, 275687, 275722, 275731, 275732, 275753,
                 276217, 276226, 276433, 276434])
for run in RUNS:
    run_rows = grouped['runs'][run]
    assert len(run_rows) == 1
    info = dict(run_rows[0]['row'])
    assert info['character'].lower() == 'silent' and info['ascension'] == 10
    decisions = grouped['decisions'][run]
    states = grouped['states'][run]
    ds, ss, excluded = [], [], []
    for item in decisions:
        row = item['row']
        if row.get('floor') not in FLOORS[run]:
            continue
        if not row.get('decision_id'):
            excluded.append({k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256')})
            continue
        ds.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    for item in states:
        row = item['row']
        state = row.get('state') or {}
        if (state.get('run') or {}).get('floor') in FLOORS[run]:
            ss.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
        if item['line'] in key_lines:
            combat = state.get('combat') or {}
            key_states.append({'ref': {k: item[k] for k in ('run_id', 'line', 'offset', 'bytes', 'sha256')},
                               'turn': state.get('turn'), 'screen': state.get('screen'),
                               'floor': (state.get('run') or {}).get('floor'),
                               'player': combat.get('player'), 'hand': combat.get('hand'),
                               'enemies': combat.get('enemies'), 'piles': combat.get('piles')})
    ds.sort(key=lambda row: (row['observed_ts'], row['_line']))
    write(run + '.audit-input.json', {'run': info, 'decisions': ds, 'states': ss})
    write(run + '.audit-exclusions.json', excluded)
    summary[run] = {'run': info, 'streams': {name: len(items[run]) for name, items in grouped.items()},
                    'audit_floors': FLOORS[run], 'audit_decisions': len(ds), 'audit_states': len(ss),
                    'audit_excluded_metadata': len(excluded),
                    'decision_fields': dict(Counter(k for x in decisions for k in x['row'])),
                    'labels': dict(Counter(str(x['row'].get('label')) for x in decisions))}
write('key-states.json', key_states)
write('run-review-summary.json', summary)
print(json.dumps({'原行逐SHA复核': sum(x['verified_raw_lines'] for x in verification),
                  '逐局': {r: {k: summary[r][k] for k in ('streams', 'audit_decisions', 'audit_states', 'audit_excluded_metadata')}
                          for r in RUNS}}, ensure_ascii=False))

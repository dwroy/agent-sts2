import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const scratch = dirname(fileURLToPath(import.meta.url));
const { observedApotheosisUpgrade } = await import(pathToFileURL(resolve('agent/src/reflex/silent-apotheosis.ts')).href);
const input = JSON.parse(readFileSync(resolve(scratch, 'VLZ6CCT8AQ0A.audit-input.json'), 'utf8'));
const plain = new Map(), upgraded = new Map();
for (const frame of input.states) {
  const state = frame.state;
  for (const card of state.run?.deck ?? []) {
    if (!card.upgraded && !plain.has(card.card_id) && observedApotheosisUpgrade(card))
      plain.set(card.card_id, { card, source_line: frame._line });
  }
  if (![35, 36, 37, 43].includes(state.run?.floor)) continue;
  for (const card of state.combat?.hand ?? []) {
    if (card.upgraded && !upgraded.has(card.card_id)) upgraded.set(card.card_id, { card, source_line: frame._line });
  }
}
const signature = (card) => ({ cost: card.energy_cost,
  values: Object.fromEntries((card.dynamic_values ?? []).map((v) => [v.name, v.base_value])) });
const rows = [...plain].map(([id, before]) => {
  const predicted = observedApotheosisUpgrade(before.card), actual = upgraded.get(id);
  const a = signature(predicted), b = actual ? signature(actual.card) : null;
  return { card_id: id, plain_deck_source_line: before.source_line,
    upgraded_hand_source_line: actual?.source_line ?? null, predicted_printed: a, observed_printed: b,
    printed_match: b !== null && JSON.stringify(a) === JSON.stringify(b),
    text_before: id === 'MALAISE' ? before.card.resolved_rules_text : null,
    text_predicted: id === 'MALAISE' ? predicted.resolved_rules_text : null,
    text_observed: id === 'MALAISE' ? actual?.card.resolved_rules_text : null };
});
const output = { scope: '已支持转换函数与同局后续手牌印刷值读回；不是完整生产候选或整战校准', rows,
  limitations: ['来源局未提供隐藏牌堆的完整持续身份；普通deck配对与后续手牌不能认证所有抽牌及组合。',
    '字段仅比较印刷值和费用；实际伤害、格挡、文本语义、施放及胜负须单独核验。',
    '本次没有增加或修改转换；未接受的普通卡仍为未知，未用合成数字补覆盖。'] };
writeFileSync(resolve(scratch, 'upgrade-pair-readback.json'), JSON.stringify(output, null, 2) + '\n');
process.stdout.write(JSON.stringify({ pairs: rows.length, matched_printed: rows.filter((x) => x.printed_match).length,
  unmatched: rows.filter((x) => !x.printed_match).map((x) => x.card_id) }) + '\n');

"""Verify preserved evidence and summarize only this batch's observed frames."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extractor", ROOT / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
batch = json.loads((OUT / "batch.json").read_text())
expected_runs = set(batch["runs"])
rows = {}
receipts = []
for stream in manifest:
    name = stream["stream"]
    path = OUT / "evidence" / (name + ".evidence.jsonl")
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == stream["output_sha256"], name
    selected = [json.loads(line) for line in raw.splitlines()]
    counts = dict.fromkeys(batch["runs"], 0)
    with (Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")).open("rb") as source:
        for item in selected:
            assert item["run_id"] in expected_runs
            assert extractor.run_identity(item["row"]) == item["run_id"]
            assert item["offset"] + item["bytes"] <= stream["source_size"]
            source.seek(item["offset"])
            original = source.read(item["bytes"])
            assert original.endswith(b"\n")
            assert hashlib.sha256(original).hexdigest() == item["sha256"]
            assert json.loads(original) == item["row"]
            counts[item["run_id"]] += 1
    assert counts == stream["counts"]
    rows[name] = selected
    receipts.append({**stream, "verified_rows": len(selected), "raw_offsets_hashes_json_identity": True})
write("evidence-verification.json", receipts)

run_rows = {item["run_id"]: item["row"] for item in rows["runs"]}
assert set(run_rows) == expected_runs
assert all(row["character"].lower() == "silent" and row["ascension"] == 10 for row in run_rows.values())
write("run-identities.json", run_rows)


def reference(item):
    return {key: item[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}


def powers(actor):
    return {entry["power_id"]: entry["amount"] for entry in actor.get("powers", [])}


frames = []
by_observed = {}
attempts = {}
last_turns = {}
for item in rows["states"]:
    row = item["row"]
    state = row["state"]
    run = state.get("run") or {}
    if run:
        assert run["character_id"].lower() == "silent" and run["ascension"] == 10
    combat = state.get("combat")
    if not combat or not state.get("in_combat"):
        continue
    floor, turn = run["floor"], state["turn"]
    if not isinstance(turn, int):
        continue
    key = (item["run_id"], floor)
    if key not in attempts:
        attempts[key] = 1
    elif turn < last_turns[key]:
        attempts[key] += 1
    last_turns[key] = turn
    player = combat["player"]
    frame = {
        "ref": reference(item), "ts": row["ts"], "observed_ts": row.get("observed_ts"),
        "floor": floor, "turn": turn, "attempt_inferred_from_turn_reset": attempts[key],
        "player": {**{key: player.get(key) for key in ("current_hp", "max_hp", "block", "energy", "cards_played_this_turn", "attacks_played_this_turn", "skills_played_this_turn")}, "powers": powers(player)},
        "enemies": [{**{key: enemy.get(key) for key in ("index", "enemy_id", "current_hp", "max_hp", "block", "is_alive", "move_id", "intents")}, "powers": powers(enemy)} for enemy in combat["enemies"]],
        "hand": [{key: card.get(key) for key in ("index", "card_id", "upgraded", "card_type", "energy_cost")} for card in combat.get("hand", [])],
        "end_turn_will_kill_player": combat.get("end_turn_will_kill_player"),
    }
    frames.append(frame)
    if row.get("observed_ts"):
        by_observed[(item["run_id"], row["observed_ts"])] = frame

target_floors = {"DUZUBAJ3A8GP": {27}, "5PM6JAQG6FNQ": {38, 39}, "CA5KE8GFJ9X2": {13}, "8JRE1C4H4Z2W": {17, 33}, "YF0LXT1QSTGG": {33, 48}, "XP2SL33HT0D9": {33}}
selected_frames = [frame for frame in frames if frame["floor"] in target_floors[frame["ref"]["run_id"]]]
with (OUT / "key-frames.jsonl").open("w") as handle:
    for frame in selected_frames:
        handle.write(json.dumps(frame, ensure_ascii=False) + "\n")

decisions = {item["line"]: item for item in rows["decisions"]}
cases = [("沙虫T2", 270216, 270282, (3, 10), (15, 17)), ("实验体T1", 271309, 271348, (0, 45), (9, 38)), ("双蟹T3", 271992, 272040, (9, 24), (14, 27)), ("双蟹T1", 271982, 272195, (2, 25), (10, 34))]
paired = []
for label, original_line, replacement_line, expected_original, expected_replacement in cases:
    original, replacement = decisions[original_line], decisions[replacement_line]
    assert original["row"]["fingerprint"] == replacement["row"]["fingerprint"]
    pair = {"label": label, "same_full_fingerprint": True, "fingerprint_sha256": hashlib.sha256(original["row"]["fingerprint"].encode()).hexdigest(), "limitations": "同盘当轮实付对照；后续抽序、用药、成长与候选执行不受控，不证明整战因果或新规则收益。"}
    for side, item, expected in (("original", original, expected_original), ("replacement", replacement, expected_replacement)):
        row = item["row"]
        start = by_observed[(item["run_id"], row["observed_ts"])]
        assert start["attempt_inferred_from_turn_reset"] == row["sl_attempt"]
        endpoint = next(frame for frame in frames if frame["ref"]["run_id"] == item["run_id"] and frame["floor"] == row["floor"] and frame["attempt_inferred_from_turn_reset"] == row["sl_attempt"] and frame["turn"] == row["turn"] + 1 and frame["ref"]["line"] > start["ref"]["line"])
        hp_loss = start["player"]["current_hp"] - endpoint["player"]["current_hp"]
        enemy_progress = sum(enemy["current_hp"] for enemy in start["enemies"]) - sum(enemy["current_hp"] for enemy in endpoint["enemies"])
        assert (hp_loss, enemy_progress) == expected, (label, side, hp_loss, enemy_progress)
        actions = [{"ref": reference(action), "chosen": action["row"].get("chosen"), "result": action["row"].get("result"), "rationale": action["row"].get("rationale")} for action in rows["decisions"] if action["run_id"] == item["run_id"] and action["row"].get("floor") == row["floor"] and action["row"].get("turn") == row["turn"] and action["row"].get("sl_attempt") == row["sl_attempt"]]
        pair[side] = {"decision": reference(item), "attempt": row["sl_attempt"], "floor": row["floor"], "turn": row["turn"], "start": start, "next_turn": endpoint, "observed_player_hp_loss": hp_loss, "observed_enemy_hp_net_decrease": enemy_progress, "rationale": row.get("rationale"), "actions_this_turn": actions, "whole_candidate_execution_verified": False}
    pair["delta_replacement_minus_original"] = {"observed_player_hp_loss": pair["replacement"]["observed_player_hp_loss"] - pair["original"]["observed_player_hp_loss"], "observed_enemy_hp_net_decrease": pair["replacement"]["observed_enemy_hp_net_decrease"] - pair["original"]["observed_enemy_hp_net_decrease"]}
    paired.append(pair)
write("paired-observations.json", paired)

key_decisions = [270216, 270264, 270282, 271309, 271348, 271354, 271495, 271509, 271982, 271992, 272040, 272076, 272195]
write("key-decisions.json", [decisions[line] for line in key_decisions])
write("analysis-summary.json", {"verified_rows": sum(item["verified_rows"] for item in receipts), "streams": len(receipts), "key_frames": len(selected_frames), "independent_runs": len(run_rows), "paired_observations": [{"label": pair["label"], "delta": pair["delta_replacement_minus_original"]} for pair in paired], "source_cutoffs_are_atomic": False, "production_replay_or_tests": False})
print((OUT / "analysis-summary.json").read_text())

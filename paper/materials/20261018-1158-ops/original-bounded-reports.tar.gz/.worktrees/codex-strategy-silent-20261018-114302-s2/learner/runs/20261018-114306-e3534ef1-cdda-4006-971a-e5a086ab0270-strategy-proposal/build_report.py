"""Preserve this batch's disposition without changing production or proposal identities."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
PROJECT = Path('/home/dw/Projects/agent-sts2')
batch = json.loads((OUT / 'batch.json').read_text())
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert base == 'fcc2ec5e7ac6324cc9f2c0d40656de24975a71bf'

details = [
    ('c20b5139dd0dff71', '感染棱柱的技能污染与净收益',
     'DUZUBAJ3A8GP F27 T4—T6；states 274830—274839。T4技能污染0→3→6，能力勒紧不加；T5火花6、污染0→6→12→18，17挡对26攻击实损9，毒7→13并结算13，T6污染消失。',
     '技能同时提供格挡、虚弱和施毒；9血净损不能推出少打技能总是更好。当前turn-solver的vitalSpark/tainted以及rollout的火花增长已有接线。',
     '冻结技能即时毒/挡/污染逐击代价，保留选项，读取本进阶实际攻击输入。',
     '缺原运行实际DB/移动表字节，以及本案毒、虚弱、格挡、污染、火花增长的联合生产重放校准；当轮净损9不足以新增少打技能规则。',
     '固定274830—274839及对应实际动作前缀，联合校验污染、意图、挡和毒伤；审计字段验收无需赢局，改变出牌规则另需受控后继和后移独立局。'),
    ('ae9e692d680e3819', '失落／遗忘的被夺属性归源',
     '5PM6JAQG6FNQ F39 首试T4—T6、末试T4；states 274351—274362、274391—274397。首试力敏各−4，两步法恢复0敏；失落退场后力回0，T6再失2敏；末试一步法只至−2敏，仍败。',
     '当前总力敏含其他来源，不能视为累计被夺量。末试毒杀失落仍不能承受遗忘19攻击；没有遗忘退场返敏的完整本案端点。',
     '按可识别实体保存抢夺和返还事件，负属性按现场值计算，不规定击杀序。',
     '缺逐实体累计被夺量与其他属性来源的完整区分、遗忘退场返敏端点和联合候选校准；不能用当前总属性代替被夺量或设置固定击杀序。',
     '补齐带实体身份的抢夺／返还／其他增益事件，固定负力敏、两种退场顺序及后续再抢的消费者重放；缺分支继续未知。'),
    ('52f1e1bd2e7db0ed', '下水道蚌的加压、弱与覆甲',
     'CA5KE8GFJ9X2 F13 T1—T5；states 273237—273269。力量0/4/8，喷水11/15/19；虚弱15→11、19→14；末2HP+10挡对14攻击，死亡后敌16HP。',
     '轮初覆甲9/9/8/7/6只证层数，完整减层条件未知。monsterHpAt/moveDamageAt对本进阶已观测数无五样本限制；ROOM_COST_MIN_N和MEASURED_ROOM_MIN_N仍为5。',
     '首样本即读取当前进阶HP/攻击事实，联合核加压与弱；房间代价保持五样本门槛。',
     '首样本事实读取与房间代价五样本门槛已有；缺原实际移动输入、加压/弱/覆甲联合重放及完整减层条件，不新增固定房间成本。',
     '用本案实际DB快照与273237—273269固定输入验证11/15/19及11/14；覆甲缺分支不补公式，不能把单战死亡拟成房间成本。'),
    ('6dd8bbff876be528', '电击机器人逐实体成长',
     '5PM6JAQG6FNQ F38 T3—T4；states 274308—274317。同23上限电击高电压2，力量2→4、17→19攻击；戳刺退场时其index由4变3，T4才清掉电击。',
     'index会随其他敌人退场重排，不能当持久实体ID；题面的先杀爪牙35伤/损3没有完整实打后继。当前STRENGTH_GROWTH_POWERS包含HIGH_VOLTAGE_POWER并应用e.growth。',
     '分实体复核增长与召唤代际，使用本进阶移动表；新增者不承接旧实体计数。',
     'HIGH_VOLTAGE增长已有；缺召唤代际持久身份、原实际移动输入及另一杀序完整后继；index重排不足以认证新旧实体，不规定先杀爪牙。',
     '固定274308—274317的行动、毒与荆棘来源，并补召唤/退场持久身份和两代实体夹具；独立验证替线后继再讨论顺序规则。'),
    ('578e415a259e6835', '沙虫的原答、护栏、SL与实际执行',
     '8JRE1C4H4Z2W F33 首/三试T2 decisions270216/270282全指纹相同：实损3/15、敌净扣10/17。二试T5 decision270264护栏候选损16→4、伤43→25。末试T11 states276429—276434：5HP、22挡对37攻击，毒24结后敌130。',
     'T2多付12血只多7当轮净扣不证原线最终可赢；末试建立步法/余像仍败。candidate audit、护栏审计及single_action_receipt已有，但actual_turn仍null，不认证完整执行。原案把金刚杵链到silent-0016；该账本实际讲护喉甲，沿原文保留并明确不背书。',
     '对原答、护栏、SL、实际派发及重规划分段记账，能力实际建立与候选预期分开；保留原选择。',
     '缺跨抽弃牌、生成、用药和重规划的完整候选执行及分来源资源认证；原金刚杵→silent-0016误链须沿ops→watcher→Roy追溯，局部审计不能当整项完成。',
     '用首/三试T2、二试T5、F17 T6、末试T11校验候选谱系和实际状态，含中断/未知；事实审计不以受控赢局为前置，改变规则才需独立受控后继。'),
    ('c0767768bf6a7ab1', '实验体全败SL的同轮资源代价',
     'YF0LXT1QSTGG F48 二/三试T1 decisions271309/271348全指纹相同；271354把防御续步改为end_turn。实损0/9、敌净扣45/38；候选预测0/10与54/36分别保存。',
     '24/24全败是有限模拟；六次SL是同一局。原案另有F33重打成功反例；本批不做未选替线因果外推。当前candidate_comparison与resource_comparison只报模型预测。',
     '记录原线、替线、覆盖重放和抽牌后未执行续步，分列预测与同轮实际量。',
     '同轮端点与候选预测对照已有；缺跨重规划完整候选归属、逐来源HP价和受控整战后继，不从24/24全败拟惩罚系数或禁止探索。',
     '固定271309/271348/271354及实际后继，验证候选只执行前缀的中断标记；保留F33成功SL分支，完整归属经消费者核验后再讨论动作变化。'),
    ('a46bdb7fe711d79a', '实验体阶段与能力的实际兑现',
     'YF0LXT1QSTGG F48 末试T3—T5；states277512敌4HP/4毒，277513换212HP阶段且清旧毒/力；277518触媒2，277519零毒；277523已有23挡，277526敏5→6未倒补，末敌160、玩家死亡。',
     '零毒与组件持有不证后续无用；旧案有已建毒雾仍败反例，不把缺启动定为唯一死因。silentPhaseCurrentFacts已列当前阶段快照并将已兑现毒伤置null。',
     '分别记录当前阶段、持有组件、已建能力、施毒、已结算与耗尽附伤，敏捷按取得顺序核对。',
     '当前阶段/持有组件/已建能力快照已有；缺逐候选施毒、结算、消耗附伤与敏捷取得顺序的联合执行校准，不启用能力优先级。',
     '固定277512—277528验证阶段清毒、零毒触媒、23挡不倒补及197→160的逐步来源，抽弃牌后重新连接实际候选。'),
    ('1044224808015e5c', '双蟹零胜率并列的血价',
     'XP2SL33HT0D9 F33 首/二试T3 decisions271992/272040：损9/14、敌净扣24/27；首/末T1 decisions271982/272195：损2/10、敌净扣25/34。第三试T4 decision272076仅候选死亡21/24→23/24、当轮损8→16、伤11→23。',
     'B2均0胜不代表实际安全，也不能把272076的候选差当已实现损血差。末次T1还建立1力量；不能忽略成长只比较挡或净扣。',
     '并列原因、样本、当轮代价与成长条件分别展示；新保血策略仅在另有验证时启用。',
     '缺同抽序、随机药瓶落点和相同预算的完整替线、成长后继及独立验证；B2零胜并列不足以启用新保血门槛。',
     '保留四个完整指纹起点及行动/毒/力量后继，固定随机落点、抽序、预算再比较候选；未选线和单局SL不能冒后移独立验证。'),
    ('7cbc6005db712ba9', '双蟹的朝向、临时减力及兑现窗口',
     'XP2SL33HT0D9 F33 末试T2—T5；states278236轮初14挡，278237爪力0→−9、攻击4→0，278240加至20挡，278242恢复力0；278249/252/253火箭57→38→28；末6挡/11HP对17攻击死亡。',
     '局部14挡、临时减力、朝向/弱和苦无模型已有；不能以某个字段存在登记整项duplicate。原案早期K367/UAC不在本批六局中，未重做跨进阶/升级历史审计。',
     '缺项才补只读条件参考；当前已有挡、候选新增挡、临时减力和朝向/虚弱各自列明，出牌权重不改。',
     '局部机制已有；缺抽弃牌后完整候选的联合执行与分来源消费认证，本批未重做原早期历史分支，不能把局部实现登记整项duplicate。',
     '固定57→38→28、14+6=20、0→−9→0及末轮毒后153/125，按普通/升级和实测进阶分支核验消费者；缺分支继续未知。'),
    ('c59f592f1427a67e', '综合资源与机制的完整消费闭环',
     'YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1/T2/T3/T4/T5；关联决策与帧同上述四组配对和机制材料。来源含原101局历史统计，但本批只核派发六局。',
     '机制支持数、所有来源HP/药/恢复账和消费者采用不是同一指标；不把旧101局支持数搬成本批新增样本，不把SL恢复算回血。六局均失败不证路线、休息或留药另一方案必胜。',
     '原答/替换/重放/执行分段，按来源保存HP、药、恢复、即时伤害与成长；缺完整胜线保留既有规则。',
     '缺逐来源HP/药/恢复账、完整候选执行及路线/休息/药水时机受控替线的联合认证；本批未重做原101局历史审计，局部能力/血价记录不等于整项完成。',
     '固定本批两局关键机制和资源端点，逐项核实际消费者；原101局/22次镣铐/50帧船夹板的历史分母需要单独授权范围内逐局复核，不由六局代验。'),
]

sections = []
results = []
for suffix, title, evidence, counterexample, behavior, reason, validation in details:
    ident = 'silent-proposal-' + suffix
    item = assigned[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append('\n'.join([
        f'## {ident}：{title}', '',
        f'原提案：`{item["proposal"]}`；SHA256：`{item["proposal_sha256"]}`。本目录同名MD为原字节副本，未覆盖原文。',
        f'来源任务：{item["source_task"]}；实现任务：strategy-proposal；账本：'+ '、'.join(item['ledger'])+'。',
        f'证据局号/层/回合与原流定位：{evidence}',
        f'反例与现状边界：{counterexample}',
        f'预期行为：{behavior}',
        f'本批处置：waiting。{reason}',
        f'验证方法：{validation}',
        '若以后新增源码，固定夹具必须撤生产改动失败、恢复通过，并跑原沙箱入口；只做事实记录不要求证明赢局。选择规则、权重或阈值的改变另须独立数据与受控后继。',
        '拟合与时间切分：本批仅核已知Silent A10六局，未拟合参数；同一SL存档不跨训练/验证集。未来新完局按run_id和结束时间后移验证；未知条件、其他进阶及其他角色维持现状。',
        '预期影响与回退：本批仅保存核验及追溯，不宣称胜率提升；没有生产改动可回退。后续实现逐项提交、固定验证、实际live祖先及发布记录，规则变化依授权双通知Roy。',
    ]))

proposal = '\n'.join([
    '# 本批静默策略提案核验与逐项处置', '',
    f'批次：20261018-114302-s2-strategy-proposal；角色silent。base：`{base}`。',
    '本批绑定普通队列的10个既有ID，没有research_request、implementation_request或proposal_repair；普通专题请求绑定旧批次，不适用。本批不领取其他提案、不创建重复ID。',
    '初始HEAD a41c2bd8305c310fa0396a7f49e5c6d2e8ecc934且工作树干净；按普通流程git merge --no-edit main，fast-forward到本报告base，无冲突。',
    '结论：10项均waiting。六局足以复核若干局部机制和四组当轮实付差；没有新参数、强制规则或整项实现认证。已有事实记录不重复添加；本批不改源码/知识、不提交、不合live、不造版本。',
    '证据：共用extract_evidence.py选择八流8274条；逐条source/offset/bytes/SHA/JSON/显式身份核回，完整输入在evidence/及evidence-verification.json。1033个有界战斗帧在key-frames.jsonl，死亡端点另存terminal-observations.json。',
    '范围：只读本角色日志、复盘、账本与knowledge/characters/silent；未读取其他角色私有知识。six runs各一个独立来源局，重读旧局和SL均不增支持N。',
    *sections,
    '', '## 异议与未完成的告知链', '',
    '原578e提案把silent-vajra-opening-strength链接silent-0016，但该账本claim是护喉甲；这是既有追溯问题，本批不再追加支持或篡改原提案/历史账本。已在本报告和该账本CLI note明确保留，交ops按ops→watcher→Roy通知核实；未把排队或本报告当已送达，未代填任何角色ACK。',
    '原案中的机制asc=[0,20]和历史支持数不等于本批跨进阶验证。本批只核六局A10；未执行的替线、脏运行树与当时DB输入仍按未知处理。',
]) + '\n'
(OUT / 'proposal.md').write_text(proposal)

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
table = ['|流|source_size|选中行|坏JSON行|截断行|', '|---|---:|---:|---:|---:|']
for item in manifest:
    table.append(f'|{item["stream"]}|{item["source_size"]}|{sum(item["counts"].values())}|{item["invalid_lines"]}|{item["incomplete_lines"]}|')
run_table = ['|来源局|实际进阶|终层|state/decision行数|', '|---|---:|---:|---:|']
run_rows = json.loads((OUT / 'run-identities.json').read_text())
counts = {item['stream']: item['counts'] for item in manifest}
for run in batch['runs']:
    row = run_rows[run]
    run_table.append(f'|{run}|{row["ascension"]}|{row["floor"]}|{counts["states"][run]}/{counts["decisions"][run]}|')
source = json.loads((OUT / 'source-manifest.json').read_text())
live = source[0]['live_head']
report = '\n'.join([
    '# 本批静默策略任务报告', '',
    f'工作树：{Path.cwd()}；批次：20261018-114302-s2-strategy-proposal。',
    f'完整base/当前HEAD：`{base}`。派发原HEAD：`a41c2bd8305c310fa0396a7f49e5c6d2e8ecc934`；仅按普通流程fast-forward main，无冲突。',
    '结果：10个派发ID全部waiting；fixes=[]、merged=null、implementation_domains=[]。没有新源码、知识、经验、策略参数、源码提交、live合入、行为版本或shipped登记。',
    '逐项原提案、账本ID、局号/层/回合、反例、旧/拟行为、验证及缺证理由均在proposal.md，不能用本报告关闭未完成的父要求。',
    '', '## 身份与证据范围', '', *run_table, '',
    '六局runs.jsonl均SILENT/A10且victory=false；实际运行code均+dirty，仅保留版本标签，不冒重建当时dirty树。batch.json保存本次learn.json对应行，assigned-proposals.json仅保存领取的10项；10份原MD的SHA与专用队列一致。当前普通专题请求不匹配，不代入其他专题。',
    '', *table, '',
    '三流各2条坏JSON是各自全源截点内统计，不能归因于本批目标局。fight-plans在2233957字节截点选中0，不据此称原日志缺失。各流先各自冻结截点，再按显式run_id/state.run_id/fingerprint.run/run选择；不是跨流原子快照。旧报告及零行原稿均未覆盖。',
    '逐行offset/bytes/SHA/JSON/身份及输出文件SHA均核回：evidence-verification.json；此为材料核验，不能称tsc、vitest、生产重放、自然采用或胜率验证。分析脚本analyze.py的固定断言已过；原分析输出和脚本留存。',
    '', '## 已核实的当轮取舍及限制', '',
    '|对照|局号/层/回合|实际损血 原/替|敌本体净扣 原/替|替线差值 损血/净扣|',
    '|---|---|---:|---:|---:|',
    '|沙虫首/三试|8JRE1C4H4Z2W F33 T2|3/15|10/17|+12/+7|',
    '|实验体二/三试|YF0LXT1QSTGG F48 T1|0/9|45/38|+9/−7|',
    '|双蟹首/二试|XP2SL33HT0D9 F33 T3|9/14|24/27|+5/+3|',
    '|双蟹首/末试|XP2SL33HT0D9 F33 T1|2/10|25/34|+8/+9|',
    '',
    'paired-observations.json保存原全指纹相等、起点/次轮端点及每条实际chosen/result/rationale引用；该敌HP净差限本轮未换阶段/未召唤的四组，不能泛化为每张卡的直接伤害。长程全败/封顶不同于当轮无代价，也不证明原线完整后继会赢。',
    '实验体末试T3是敌剩4HP/4毒、玩家18HP；T4换212HP阶段清旧毒与力，T5已建触媒2但零毒；后取得敏捷不倒补已有23挡。双蟹末试T2临时减力0→−9→次轮恢复0，14+6=20挡；T4朝向和弱分别令57→38→28。棱柱T5的挡/弱/毒收益和18污染合并后实损9，不推出禁技能。细帧在mechanism-observations.json；末死亡帧单列在terminal-observations.json。',
    '', '## 当前源码边界与逐项状态', '',
    f'19份选定源叶按base Git blob/工作字节核对并保存.txt，记录source-manifest.json；取证时live HEAD为`{live}`。14叶同字节，5叶不同；base-live-source.patch完整保留，含署名注释及Queen相关实际代码差，未声称整文件/整树行为等价，也不把该差当本批新知识。',
    '19叶last-source均核为上述实际live祖先；它们只说明既有局部接线，不用于为10个宽提案填写implemented/duplicate。尤其silent-selection-audit、silent-sl-comparison、silent-sl-resource-comparison、silent-hp-guard-audit、silent-selection-dispatch已有候选/单次回执，actual_turn与whole_plan_executed仍未知；silent-phase-current已有当前阶段快照。',
    '怪HP/伤害首样本本进阶读取与房间代价5样本门槛已有，不重复实现。完整候选跨抽弃牌/生成/药水/重规划的归属、逐来源资源，以及机制联合消费者校准仍缺。纯事实审计的缺口与改变策略所需受控替线分列，未以缺赢局禁止事实记录。',
    '', *[f'- `{item["id"]}`：waiting。{item["reason"]}' for item in results],
    '', '## 账本、测试与交接', '',
    '只经根learner/ledger.py update，为这10项关联的30个既有Silent账本追加本批where.proposal与note；不新增发现、不追加旧局support/repeat、不改claim/first_run/prior/状态/版本/effect，不回退已shipped的旧经验，也不标本批shipped。输入ledger-updates.jsonl、CLI输出ledger-update.log、检查ledger-check.log及追加原字节/哈希回执ledger-receipt.json一并保留。',
    '原578e的金刚杵→silent-0016追溯异议沿原历史保留；该账本实际护喉甲，不据此背书金刚杵。请ops沿ops→watcher→Roy告知并核实原链；本批不代填通知ACK，六局重读不增加历史分母。',
    '无生产源码改动，因此撤源码失败/恢复通过、tsc、vitest、cases均未运行，tests固定三null；未借用历史绿色结果。未尝试live锁、合入或eval分号，没有规则上线的双通知需要。没有推送、play、联网、LLM请求、下级agent或其他角色知识改动。',
    '最终工作树及索引保持干净，HEAD=base；材料位于本批被忽略的learner/runs目录。所有既有ID按proposal_results交调度器保持waiting，缺证待后续新局或完整输入重派；无重复ID、无父要求完成或经验已入库/大脑已采用的声明。',
    f'提案绝对路径：{OUT / "proposal.md"}。报告绝对路径：{OUT / "report.md"}。',
]) + '\n'
(OUT / 'report.md').write_text(report)

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-114302-s2-strategy-proposal', 'base': base, 'runs': batch['runs'], 'fixes': [], 'skipped': ['10个领取提案逐项waiting，具体缺证条件见proposal_results；本批未新增生产实现。'], 'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': batch['proposal_ids'], 'implementation_domains': [], 'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

ids = sorted({ident for item in assigned.values() for ident in item['ledger']})
updates = []
for ident in ids:
    linked = [key for key, item in assigned.items() if ident in item['ledger']]
    note = '20261018-114302-s2-strategy-proposal：本批六个旧Silent A10局8274条原八流逐字节/归局核验；关联'+','.join(linked)+'均waiting，缺证条件见本批proposal.md/report.md。只补追溯where/note，不增加support/repeat，不改规则/claim/首证/prior/状态/版本/effect，不当implemented/shipped。'
    if ident == 'silent-0016':
        note += '特别保留原578e金刚杵误链异议：本账本claim实际为护喉甲，不据原提案关联背书金刚杵；交ops→watcher→Roy核实，未代填ACK。'
    updates.append({'id': ident, 'by': 'learner:strategy-proposal', 'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]}, 'note': note})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(item, ensure_ascii=False) + '\n' for item in updates))
ledger = PROJECT / 'paper/materials/learning/ledger.jsonl'
raw = ledger.read_bytes()
(OUT / 'ledger-prefix.json').write_text(json.dumps({'path': str(ledger), 'source_size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'line_count': len(raw.splitlines())}, ensure_ascii=False, indent=2)+'\n')
(OUT / 'baseline.json').write_text(json.dumps({'initial_head':'a41c2bd8305c310fa0396a7f49e5c6d2e8ecc934','base':base,'merge_main':'fast-forward','production_changes':False,'live_observed':live},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'base': base, 'proposal_results': len(results), 'ledger_metadata_updates': len(updates), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

from pathlib import Path
import hashlib, json, os, subprocess
root=Path.cwd(); private=root/'ops/codex-ops/record-staging/20261016-0311'; public=root/'paper/materials/20261016-0311-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,env=None,data=None):return subprocess.check_output(['git',*args],env=env,input=data,stderr=subprocess.PIPE)
assert json.loads((private/'gitleaks.json').read_text())==[]
manifest=json.loads((private/'record-manifest.json').read_text());base=manifest['base'];dest=private/'final-files'
assert git('rev-parse','HEAD').decode().strip()==base and not git('diff','--cached','--name-only').strip()
for entry in json.loads((public/'ops-helper-manifest.json').read_text()):assert sha((root/entry['path']).read_bytes())==entry['sha256']
for name in ['gitleaks.log','final-ledger-check.log']:
    source=public/name;raw=source.read_bytes();path=str(source.relative_to(root));saved=dest/path;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(raw)
    manifest['paths'].append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
index=private/'records.index';env={**os.environ,'GIT_INDEX_FILE':str(index)};git('read-tree',base,env=env)
for entry in manifest['paths']:
    raw=(dest/entry['path']).read_bytes();assert sha(raw)==entry['sha256'];oid=git('hash-object','-w','--stdin',data=raw).decode().strip()
    git('update-index','--add','--cacheinfo','100644',oid,entry['path'],env=env)
tree=git('write-tree',env=env).decode().strip();paths=git('diff','--name-only',base,tree).decode().splitlines()
assert set(paths)=={entry['path'] for entry in manifest['paths']}
assert all(path.startswith('paper/materials/20261016-0311-ops/') or path in ['paper/materials/decision-log.md','ops/inbox-dev.md','paper/materials/learning/ledger.jsonl'] for path in paths)
message='Record ten waiting strategy dispositions and owned provenance\n\nRetain original material assertion failure and corrected receipts, sixteen trace-only ledger updates and unchanged source. No production tests, merge, release or game action.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
commit=git('commit-tree',tree,'-p',base,data=message.encode()).decode().strip();indexpath=Path(git('rev-parse','--git-path','index').decode().strip()).resolve();lock=Path(str(indexpath)+'.lock');fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);published=False
try:
    assert git('rev-parse','HEAD').decode().strip()==base and not git('diff','--cached','--name-only').strip()
    with os.fdopen(fd,'wb') as handle:handle.write(index.read_bytes());handle.flush();os.fsync(handle.fileno())
    git('update-ref','-m','ops: record waiting strategy dispositions','HEAD',commit,base);published=True;os.replace(lock,indexpath)
finally:
    if lock.exists() and not published:lock.unlink()
for entry in manifest['paths']:assert sha(git('show',commit+':'+entry['path']))==entry['sha256']
assert not git('diff','--cached','--name-only').strip()
writeback=dict(commit=commit,parent=base,tree=tree,paths=paths,ordinary_index_empty=True,owned_blobs_verified=True)
(private/'commit-readback.json').write_text(json.dumps(writeback,ensure_ascii=False,indent=2)+'\n');print(json.dumps(writeback,ensure_ascii=False))

from pathlib import Path
import collections, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile
sys.dont_write_bytecode=True
root=Path.cwd(); p=root/'ops/codex-ops/record-staging/20261016-0311'; pub=root/'paper/materials/20261016-0311-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip()
assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-025902-strategy-proposal'; b=load(root/'ops/codex-ops/learn.json')['batches'][bid]; report=b['report']; s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'completion.json')
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and b['proposal_audit_errors']==[]
assert b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert set(report['code_proposals'])==set(report['skipped'])==set(b['proposal_ids'])=={x['id'] for x in report['proposal_results']}
assert report['fixes']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-integrity.json')
assert final['head']==report['base'] and final['tracked_worktree_clean'] and final['binary_diff_bytes']==final['index_diff_bytes']==0
assert final['all_ten_waiting'] and final['queue_unchanged'] and final['original_markdown_sha_unchanged'] and final['ledger_owned_rows']==16
assert final['new_source_commits']==[] and final['merged'] is final['version'] is None and final['production_tests']==report['tests']
assert final['gitleaks_exit']==0 and load(s/'gitleaks.json')==[] and (s/'gitleaks.rc').read_text().strip()=='0'
for x in final['artifacts']:assert Path(x['path']).is_relative_to(s) and sha(Path(x['path']).read_bytes())==x['sha256']
originals=load(s/'proposal-originals.json');assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    source=Path(x['source']);saved=Path(x['saved']);assert source.is_relative_to(root) and saved.is_relative_to(s)
    assert sha(source.read_bytes())==sha(saved.read_bytes())==x['sha256']
extract=module('original_extract',root/'learner/extract_evidence.py'); runs=load(s/'runs-verified.json')
assert len(runs)==6 and all(x['character']=='SILENT' and x['ascension']==10 for x in runs)
assert {x['run_id'] for x in runs}==set(report['runs']);counts={};receipts=[]
for directory in ['evidence','evidence-additional']:
    for x in load(s/directory/'evidence-manifest.json'):
        frozen=s/directory/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
        with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
            for line in selected:
                digest.update(line); e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
                assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row']
                assert extract.run_identity(row)==e['run_id'] in report['runs'] and e['offset']+e['bytes']<=x['source_size']
                if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
                if x['stream']=='runs':assert row==next(r for r in runs if r['run_id']==e['run_id'])
                seen[e['run_id']]+=1
        assert digest.hexdigest()==x['output_sha256'] and all(seen.get(run,0)==n for run,n in x['counts'].items())
        counts[x['stream']]=sum(seen.values());receipts.append(x)
assert sum(counts.values())==8444
audit=load(s/'audit.json');first=load(s/'audit.v1.json')
assert audit['raw_lines_verified']==8444 and len(audit['material_checks'])==45 and audit['all_material_checks_passed'] and not audit['production_tests_run']
assert all(x['passed'] and x['actual']==x['expected'] for x in audit['material_checks'])
failed=[x for x in first['material_checks'] if not x['passed']]
assert len(failed)==1 and failed[0]['actual']==[[13,12],[23,18]] and failed[0]['expected']==[[13,9],[23,15]]
assert b'AssertionError' in (s/'audit.v1.stderr.txt').read_bytes()
previous=[]
with (root/'paper/materials/decision-log.md').open('rb') as handle:
    for number,line in enumerate(handle,1):
        if b'2026-10-15 21:33:24 CST' in line and b'12/18' in line:
            previous.append(dict(path='paper/materials/decision-log.md',line=number,sha256=sha(line)))
assert len(previous)==1
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['leaves'])==14
assert git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_head']
for x in source['leaves']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (a==z)==x['same_bytes']
    assert (root/'.worktrees/live'/x['path']).read_bytes()==z and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
    assert x['source_is_live_ancestor'];git('merge-base','--is-ancestor',x['live_leaf_commit'],source['live_head'])
assert sum(x['same_bytes'] for x in source['leaves'])==12
for x in source['ancestry']:
    assert x['base_ancestor'] and x['live_ancestor']
    for head in [report['base'],source['live_head']]:git('merge-base','--is-ancestor',x['commit'],head)
receipt=load(s/'ledger-receipt.json');inputs=[json.loads(x) for x in (s/'ledger-update.jsonl').read_text().splitlines()]
assert receipt['cli_exit']==0 and receipt['prefix_unchanged'] and receipt['actual_fold_protected_readback']
assert len(inputs)==len(receipt['owned_rows'])==16 and set(receipt['input_ids'])==set((s/'ledger-cli.stdout.txt').read_text().split())=={x['id'] for x in inputs}
assert all(all(x.values()) for x in receipt['protected_fields_unchanged'].values());own=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    for entry in receipt['owned_rows']:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'}
        assert row['op']=='update' and row['by']=='learner:strategy-proposal' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs)
        own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==16 and all(raw.rstrip(b'\n') not in set(old.splitlines()) for raw in own);added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,scratch_result_difference='Original detailed waiting reasons are shortened in final stdout; all ten IDs, states, report and other fields agree. Neither original rewritten.',original_gate=b['no_change_proposals'],native=native,original_completion=final,stream_counts=counts,raw_receipts=receipts,original_rows_verified=8444,original_material_checks=45,first_material_failure=failed,prior_same_correction=previous,material_checks_not_reexecuted=True,source=source,owned_trace_rows=receipt['owned_rows'],protected_fields_and_prefixes_preserved=True,limits=['No full-candidate execution or controlled whole-fight/resource successors certified.','Same-run SL attempts are correlated; existing narrow implementations do not close broad proposals.','Earlier 020233 capacity failure retained; this is a distinct successful scheduler batch.','No production tests, merge, release, paper refresh, dispatch or game action.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',s/'evidence-additional/evidence-manifest.json',out,out.with_suffix('.err')]
    for sourcefile in sorted(files):
        raw=sourcefile.read_bytes();rel=str(sourcefile.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw)
        archive.add(sourcefile,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0311原025902策略done0/no-source核收，e018基线干净WT/HEAD不变；十项waiting及具体缺口、testsnull/mergednull保持，无合入受阻。六Silent A10八流8444原行逐offset/bytes/SHA/JSON/身份核；45原材料断言修正后通过，首版把751 T7题面9/15当整轮净扣的失败原件保留，实际12/18与旧21:33勘误一致，不当新机制反证或生产测试。十四源码叶12同2历史Roy/Dai注释差与七真实来源祖先核，窄实现不关闭完整候选/逐源归属/受控整战及路线留药后继缺口。16所属CLI仅where/note按原输入/回执/offset/SHA核，私有fold旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核；本批成功不改旧020233 capacity失败。仅本人记录/16追溯提交，保并行记录；不合入/发号/补测/刷新论文/另派或关闭宽父。证据paper/materials/20261016-0311-ops/。\n'
note=f'\n- {at} [运维 codex] 原025902策略十项继续waiting，无源码修改或合入受阻；六局8444原行、45原材料检查及16条所属追溯已核，首次口径失败保留。现有窄修复和宽父边界保持，不新增发布或补测。回执paper/materials/20261016-0311-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=16,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True)
(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=8444,owned_trace_rows=16,ledger_check=0,paths=len(entries))))

import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
DISPATCH = json.loads((HERE / 'dispatch.json').read_text())
RUNS = set(DISPATCH['runs'])
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        fp = json.loads(fp)
    values = {v for v in [row.get('run_id'), row.get('run'), state.get('run_id'),
                         (fp or {}).get('run')] if v and v != 'run_unknown'}
    return next(iter(values)) if len(values) == 1 else None


streams = {}
receipts = []
for directory in ('evidence', 'evidence-additional'):
    for manifest in json.loads((HERE / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        path = HERE / directory / (stream + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = collections.Counter()
        rows = []
        with path.open('rb') as handle, Path('/home/dw/Projects/agent-sts2/logs', stream + '.jsonl').open('rb') as source:
            for encoded in handle:
                digest.update(encoded)
                wrapper = json.loads(encoded)
                source.seek(wrapper['offset'])
                raw = source.read(wrapper['bytes'])
                assert len(raw) == wrapper['bytes']
                assert hashlib.sha256(raw).hexdigest() == wrapper['sha256']
                assert wrapper['offset'] + len(raw) <= manifest['source_size']
                assert json.loads(raw) == wrapper['row']
                assert identity(wrapper['row']) == wrapper['run_id'] in RUNS
                counts[wrapper['run_id']] += 1
                rows.append(wrapper)
        check(stream + '输出SHA', digest.hexdigest(), manifest['output_sha256'])
        check(stream + '逐局计数', {r: counts[r] for r in DISPATCH['runs']}, manifest['counts'])
        streams[stream] = rows
        receipts.append({**manifest, 'verified_raw_lines': len(rows)})

states = streams['states']
decisions = streams['decisions']
by_run = {r: [s for s in states if s['run_id'] == r] for r in RUNS}
state_lines = {x['line']: x for x in states}
decision_lines = {x['line']: x for x in decisions}
check('六局角色进阶', sorted({(x['row']['state']['run']['character_id'],
                             x['row']['state']['run']['ascension'])
                            for x in states if x['row']['state'].get('run')}), [('SILENT', 10)])


def brief(wrapper):
    s = wrapper['row']['state']
    c = s.get('combat') or {}
    run = s.get('run') or {}
    player = c.get('player') or {}
    return {'line': wrapper['line'], 'observed_ts': wrapper['row'].get('observed_ts'),
            'run': wrapper['run_id'], 'floor': run.get('floor'), 'turn': s.get('turn'),
            'in_combat': s.get('in_combat'), 'hp': run.get('current_hp'),
            'block': player.get('block'),
            'powers': {p['power_id']: p['amount'] for p in player.get('powers', [])},
            'hand': [{'id': p['card_id'], 'values': {v['name']: v['current_value']
                       for v in p.get('dynamic_values', [])}} for p in c.get('hand', [])],
            'enemies': [{'id': e['enemy_id'], 'hp': e['current_hp'], 'max_hp': e['max_hp'],
                         'alive': e.get('is_alive'), 'move': e.get('move_id'),
                         'powers': {p['power_id']: p['amount'] for p in e.get('powers', [])},
                         'intents': e.get('intents')} for e in c.get('enemies', [])],
            'potions': [{'index': p['index'], 'id': p.get('potion_id'), 'occupied': p.get('occupied')}
                        for p in run.get('potions', [])]}


def state_for(decision):
    r = decision['row']
    matching = [x for x in by_run[decision['run_id']]
                if x['row'].get('observed_ts') == r.get('observed_ts')
                and x['row'].get('fingerprint') == r.get('fingerprint')]
    if len(matching) != 1:
        raise ValueError(('观测身份不唯一', decision['line'], len(matching)))
    return matching[0]


def endpoint(decision):
    start = state_for(decision)
    s = brief(start)
    for next_state in by_run[decision['run_id']]:
        if next_state['line'] <= start['line']:
            continue
        nxt = brief(next_state)
        if nxt['floor'] != s['floor'] or not nxt['in_combat'] or nxt['turn'] < s['turn']:
            return {'start': s, 'end': nxt, 'known_turn_endpoint': False}
        if nxt['turn'] > s['turn']:
            same = [e['id'] for e in s['enemies']] == [e['id'] for e in nxt['enemies']]
            result = {'start': s, 'end': nxt, 'known_turn_endpoint': nxt['turn'] == s['turn'] + 1,
                      'net_hp_loss': s['hp'] - nxt['hp']}
            if same:
                result['net_enemy_hp_reduction'] = sum(e['hp'] for e in s['enemies']) - sum(e['hp'] for e in nxt['enemies'])
            return result
    return {'start': s, 'end': None, 'known_turn_endpoint': False}


def select(run, floor, attempt, turn):
    rows = [x for x in decisions if x['run_id'] == run and x['row'].get('floor') == floor
            and x['row'].get('sl_attempt') == attempt and x['row'].get('turn') == turn
            and 'plan' in (x['row'].get('questions') or {})]
    assert rows, (run, floor, attempt, turn)
    return rows[0]


pairs = []


def pair(name, a, b, expected):
    x, y = endpoint(a), endpoint(b)
    check(name + '同指纹', a['row']['fingerprint'], b['row']['fingerprint'])
    check(name + '相邻轮端点', [x['known_turn_endpoint'], y['known_turn_endpoint']], [True, True])
    check(name + '净损/净扣', [[x.get('net_hp_loss'), x.get('net_enemy_hp_reduction')],
                            [y.get('net_hp_loss'), y.get('net_enemy_hp_reduction')]], expected)
    pairs.append({'name': name, 'decisions': [a['line'], b['line']], 'original': x, 'replacement': y,
                  'sl_comparison': b['row'].get('sl_explore'),
                  'scope': '完整相邻轮净HP差；非逐来源毛伤、非受控整战因果、非全候选执行认证'})


pair('751 F17 T2 第1/3试', decision_lines[272434], decision_lines[272575], [[13, 9], [18, 18]])
pair('751 F17 T7 第2/4试', decision_lines[272531], decision_lines[272652], [[13, 12], [23, 18]])
pair('751 F17 T13 第1/6试', select('751FN9QM9MHQ', 17, 1, 13), select('751FN9QM9MHQ', 17, 6, 13), [[8, 17], [2, 11]])
pair('KV F33 T5 第4/5试', select('KV0JHNJCKXLS', 33, 4, 5), select('KV0JHNJCKXLS', 33, 5, 5), [[0, 36], [0, 29]])
pair('KEN F17 T10 第4/5试', decision_lines[274505], decision_lines[274568], [[15, 2], [21, 4]])
pair('KEN F17 T5 第4/6试', decision_lines[274484], decision_lines[274601], [[7, 1], [5, 2]])

drinks = []
for d in decisions:
    row = d['row']
    if d['run_id'] != 'KEN58SH9SLZ6' or (row.get('chosen') or {}).get('action') != 'use_potion':
        continue
    before = state_for(d)
    seq = by_run[d['run_id']]
    after = next(s for s in seq if s['line'] > before['line'])
    a, b = brief(before), brief(after)
    slot = row['chosen']['option_index']
    prev = next(p for p in a['potions'] if p['index'] == slot)
    post = next(p for p in b['potions'] if p['index'] == slot)
    drinks.append({'decision': d['line'], 'floor': row['floor'], 'turn': row['turn'], 'slot': slot,
                   'potion': prev['id'], 'receipt': row.get('result'), 'before': a, 'after': b,
                   'consumed_slot': prev['occupied'] is True and post['occupied'] is False,
                   'whole_plan_executed': None})
check('KEN七次耗药', [d['decision'] for d in drinks], [274131, 274156, 274185, 274235, 274237, 274267, 274272])
check('KEN七次槽位消费', [d['consumed_slot'] for d in drinks], [True] * 7)
check('KEN三原pending不改写', sum(str(d['receipt']).startswith('pending') for d in drinks), 3)

giant_before, giant_after = brief(state_lines[280160]), brief(state_lines[280161])
check('YQL残壳饮药前后HP挡来袭', [[s['hp'], s['block'], s['enemies'][0]['intents'][0]['damage']]
                                   for s in (giant_before, giant_after)], [[26, 13, 41], [26, 13, 41]])
check('YQL残壳毒层', [s['enemies'][0]['powers']['POISON_POWER'] for s in (giant_before, giant_after)], [2, 8])
check('YQL残壳占位血', [s['enemies'][0]['max_hp'] for s in (giant_before, giant_after)], [999999999, 999999999])

sl = []
for x in streams['sl-attempts']:
    row = x['row']
    sl.append({'line': x['line'], 'run': x['run_id'], 'floor': row.get('floor'),
               'attempt': row.get('attempt'), 'result': row.get('result'), 'turns': row.get('turns'),
               'end_hp': row.get('end_hp'), 'summary': row.get('summary'),
               'anchor': (row.get('explore') or {}).get('anchor')})
for run in ('751FN9QM9MHQ', 'YQL8RZ8BWN1E', 'KEN58SH9SLZ6'):
    rows = [x for x in sl if x['run'] == run and x['floor'] == 17]
    check(run + '六次无胜', [len(rows), sum(x['result'] == 'won' for x in rows)], [6, 0])
pu = [x for x in sl if x['run'] == 'PU80F84P6HPN' and x['floor'] == 17]
check('PU巨兽第5试已胜反例', [x['attempt'] for x in pu if x['result'] == 'won'], [5])

held_examples = [brief(state_lines[n]) for n in (278500, 278505, 280691, 280692, 280705, 280709, 280713, 280717)]
evidence = {'receipts': receipts, 'raw_lines_verified': sum(x['verified_raw_lines'] for x in receipts),
            'pairs': pairs, 'ken_drinks': drinks, 'giant_poison': [giant_before, giant_after],
            'held_examples': held_examples, 'attempts': sl,
            'material_checks': checks, 'all_material_checks_passed': all(x['passed'] for x in checks),
            'production_tests_run': False}
(HERE / 'audit.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'raw_lines_verified': evidence['raw_lines_verified'], 'material_checks': len(checks),
                  'passed': evidence['all_material_checks_passed'],
                  'failures': [x for x in checks if not x['passed']],
                  'pairs': [{'name': x['name'], 'lines': x['decisions'],
                             'net': [[x[y].get('net_hp_loss'), x[y].get('net_enemy_hp_reduction')]
                                     for y in ('original', 'replacement')]} for x in pairs]}, ensure_ascii=False, indent=2))
assert evidence['all_material_checks_passed']

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch.json').read_text())
queue = json.loads((HERE / 'queue-before.json').read_text())
audit = json.loads((HERE / 'audit.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
assert audit['all_material_checks_passed']
base = source['base']
report_path = str(HERE / 'report.md')
proposal_path = str(HERE / 'proposal.md')
reasons = {
    'silent-proposal-366288801d9150d9': '751 F17 T2/T7/T13的同盘血价已核；已有候选对照和单动作回执，仍缺抽弃重问后的逐来源实际结算、完整候选认证与受控整战后继，不拟5/10血阈值。',
    'silent-proposal-85929bdfc8a3fc1b': '751 F13T3无药参考与未知持药值已有源码；缺实际无药整战、留药后战和F17T7弃呼唤后的完整来源认证，不能调整饮用或持药价。',
    'silent-proposal-efd9f83ee9e1a6dc': '751六试同属一局且均失败；窄SL预测分账已上线，缺逐来源完整兑现、同随机条件后继和独立留出，不把窄实现当整项完成。',
    'silent-proposal-131042659448ae74': '未决弃牌、持牌失血和未知持药值已分列，actual_turn仍null；缺敏捷/毒/荆棘/呼唤完整收益及跨战留药对照，不能整项duplicate。',
    'silent-proposal-990f054036609447': 'KV F33T5第4/5试同指纹净扣36/29且均零损；缺敌回血毛伤逐源认证、重问后完整候选执行和路线/休息替代后继，不设SL或资源门槛。',
    'silent-proposal-e18d3f18e6cac2a0': '巨兽阶段、占位血说明和残壳用药观察已有源码；SL同轮参考仍按原始占位血排序，缺改序后的受控后继与结局校准，PU第5试已胜反例保持。',
    'silent-proposal-9733bb80f445aeae': 'YQL末试T10残壳毒2→8，HP26/挡13/自爆41均未变；缺提前喝、不喝、留药及改SL排序的受控整战分支，局部阶段展示不关闭整项。',
    'silent-proposal-c51468c5e8ba6668': 'KEN七次槽位消费全部核实，三原pending回执保持；缺随机选牌/发光水重问后的完整候选收益认证、F15不用药及留药到boss的受控结果。',
    'silent-proposal-86a7db08d1a31976': 'KEN F17T10第4/5试损15/21扣2/4，T5第4/6试省2血却延步法至T9；缺逐源完整兑现、受控整战和独立留出，不定6血/2伤阈值。',
    'silent-proposal-e282a9131b99129a': 'KEN同盘血价和能力窗口仅有局部端点支持；预测/单动作回执不能认证完整候选，缺保持后轮条件的反事实与独立新局，保留探索及HP护栏。',
}
assert set(reasons) == set(dispatch['proposal_ids'])
results = [{'id': i, 'state': 'waiting', 'reason': reasons[i]} for i in dispatch['proposal_ids']]
(HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

header = f'''# 静默猎手策略提案逐项复核

记录时间：2026-10-16 03:06:02 CST（落盘前已执行 date）。
本批：{dispatch['batch']}；角色 silent；任务 strategy-proposal；reason=proposal。
基线与最终源码 HEAD：`{base}`。初始工作树干净；核身份后 `git merge --no-edit main` 返回 Already up to date。
本批没有 research_request、implementation_request、proposal_repair；普通专题文件绑定另一个批次，不用于本批。严格只消费派发的十个原 id，不扩队列、不新增重复提案、不改原提案或历史复盘。
本批六个锚点：{', '.join(dispatch['runs'])}。runs.jsonl 逐一核为 SILENT/A10；对局代码均带 dirty，不能由提交还原当时全部源码。L9 的原摘要和实际战略来源为 DeepSeek，不能算纯 Codex 爬塔战绩；游戏证据仍可使用，不改其历史。

本批结论：十项均 waiting。诊断已有窄实现；本批没有足以支持新规则或关闭整个提案的受控完整后继。不修改源码、经验、策略参数、游戏版本或队列状态；没有新源码提交、live 合入或 shipped 登记。
'''

pair_table = '| 同盘对照 | 原始 decision 行 | 原线净损血／敌净扣 | 替线净损血／敌净扣 |\n|---|---|---|---|\n'
for p in audit['pairs']:
    a, b = p['original'], p['replacement']
    pair_table += f"| {p['name']} | {p['decisions'][0]} / {p['decisions'][1]} | {a['net_hp_loss']} / {a['net_enemy_hp_reduction']} | {b['net_hp_loss']} / {b['net_enemy_hp_reduction']} |\n"

evidence = '''
## 核实的局部观察及反例

下表按同一指纹和 observed_ts 匹配题目前状态，再取同场相邻下一轮的首个状态。只称净HP差，不冒充逐来源毛伤或完整候选认证；各端点原行号、字节/SHA和保留的完整选择见 audit.json、evidence/。

''' + pair_table + '''
751 T7：题面 damage_dealt=9/15，完整相邻轮敌HP由121→109/103，实际净扣12/18；玩家45→32/22，净损13/23。首次材料脚本误把原提案的9/15当相邻轮净扣，45项中1项失败；保留 audit.v1.py/.json/.stdout.json/.stderr.txt，修正后45项全部通过。旧decision-log 2026-10-15 21:33已记录同一口径勘误；本批不是新机制发现。差额仍为多损10、净扣多6，不因此设固定血价阈值。原提案文字不改写；本次报告和账本追溯注释明确两种口径，交ops沿原链读回，不冒称watcher或Roy已确认。

KEN T10：B2 .385→.127，配对差−.2583、SE .0132；五轮死亡6/24→12/24，不能称同死率。T5替线实际省2血且多1净扣，但第4试T5建立步法，第6试至T9才建立；T6端点敏捷分别2/0。这个反例不支持“只保血恒优”。省血、取消毒建立、能力延迟和后续抽牌必须分开，不由同局六次重打推独立胜率。

KV F33T5：两线均零损、净扣36/29，毒后继不同；敌回血、净扣和逐来源毛扣分开。F17首试胜余9不因最终F33失败而判升级或路线错误。未走的路线/休息不能记成已回血或零损。

YQL F17末试T10，states280160→280161：毒药水把残壳毒2→8，但HP26、挡13、自爆41未变，近十亿占位血不是仍待击杀本体。26+13−41=−2，至少还需3血才能在相同末态存活；“伤害超过现有HP2”与“活下来至少需额外3HP”不可混用。L9、PU亦有占位阶段；PU第5试实际已胜（2血），因此本体归零不能直接替代胜利或据此重排SL。YQL六试0胜是同局相关观察，不是六局独立校准。

KEN七次饮药：decisions274131/274156/274185/274235/274237/274267/274272，分别F3T2槽0攻击、F4T1槽0稳定、F5T2槽0速度、F11T1槽1虚弱、F11T2槽0攻击、F15T1槽1发光水、F15T1槽0技能。对应states280206→207、280232→233、280262→263、280313→314、280315→316、280348→349、280354→355，七个槽位实际变空。274131/274237/274272原回执为pending，保留原值；后帧槽位消费不把原回执改为completed，也不证明整条方案已执行。F17空药栏不能倒推留任一瓶必胜或拟持有价。

## 已有实现与源码边界

固定源码对照在 source-audit.json 和 source/（仅所需叶的 .txt 原字节，无整仓库副本），base.diff.patch为空。
live读取截点为 `''' + source['live_head'] + '''`；14叶逐SHA有12同，explore.ts和potion-cost.ts差异只为历史Roy/Dai注释称谓；保留原差异。没有运行转译检查，也不据此声称本批tsc通过。

- `silent-sl-comparison.ts`、`silent-sl-resource-comparison.ts`、`silent-selection-audit.ts`：预测原线/SL替线和差额；`actual_turn_result/actual_turn`仍null。`resource_comparison.execution=unverified`。
- `silent-selection-dispatch.ts`及hand/loop接线：单动作派发回执；`state_effect_verified=false`、`whole_plan_executed=null`。源码提交 fdaf787a372880b0438e73bcac7e6d2168b038ed 为base和live真实祖先。
- `silent-potion-reference.ts`：holdHp=null时给未知持药价和同题无药参考，未把模型比较当留药实盘。源码 c4670f4f416c7d93e192e889c5080e7e4e0e733f 为base/live祖先。
- `silent-held-loss.ts`：逐来源保守持牌损血、未决弃牌标志与actual_held_hp_loss=null；实际live来源05cd292c6f01bb31e406473d3a9843e659d62b93。
- `sl/attempts.ts`、`silent-giant-potion.ts`：限定Silent A10的blast_pending、body_hp=0、原始占位血及单次用药观察；实际live来源d5e20aa4dd44168ce30944dfcce74f8322144953。
- `sl/explore.ts:923/942`仍以原始末态enemyHpLeft参与同轮参考排序；`replacementAmong`仍在未强制notWorseOnly时允许全劣未试线探索。这是保留的现行规则，不作为新纯bug，也不拿其他角色经验改它。

上述窄源码来源及集成a8b1f8be153fe4f3a34146117546c2178f2e446b、bade647f9fe4c9103b40e2f26b26296692ad24b7、04921bd785ac6838066522f91ea0bb6ab95cb6a1均已核为实际live及本基线祖先。已有实现不等于宽提案全部交付，所以十项不登记implemented/duplicate，不用文档提交冒源码提交。
'''

sections = '\n## 十项处置、既有账本与待验证行为\n\n'
for i in dispatch['proposal_ids']:
    q = queue[i]
    sections += f'''### {i}

原提案：`{q['proposal']}`；SHA256 `{q['proposal_sha256']}`；原字节副本 `{i}.original.md`。
证据局：{', '.join(q['runs'])}；既有账本：{', '.join(q['ledger'])}；来源任务 {q['source_task']} → strategy-proposal。
原目标：{q['summary']}
处置：waiting。{reasons[i]}
预期新行为与验证：先获得该项缺少的完整同盘后继/实际来源，明确抽弃重问截断、用药及能力建立，再核现有字段是否足够。只有足证后才在已观察角色/进阶内实现原提案所述规则或诊断，用固定局面撤源码失败/恢复通过及沙箱检查验证。当前保留原行为、全部选项和HP护栏；不以另一个提案id已实现代本项关闭。
'''

validation = '''
## 验证、拟合及回退

采用共用extract_evidence.py，默认六流另加runs/fight-plans两流，显式run_id/state.run_id/run/fingerprint.run一致才收。八流共8444条，每条均重新seek原source核offset/bytes/SHA、JSON及所属局，全部与冻结输出SHA/计数吻合。states/decisions/brain原流分别2/2/1条无效JSON，不改原件；fight-plans在该2233957字节截点选中0行，只能表明本截点未选中，不据此断言原记录缺失。没有覆盖已有零行初稿。

六组局部对照、七次槽位消费与反例核验在audit.json。45项是材料断言，不是生产单测、收益检验或全候选执行认证。首次1项口径失败及修正均保存。没有源码改动，因此没有撤源码负控、恢复测试、tsc、vitest或沙箱全套；tests固定null，不能用45项材料核验填0或假称生产检查通过。

拟合方法：本批不拟任何权重、持药价、SL准入或终局阈值。若后续证据足够，按独立局和实际开始时间切分：更早Silent局仅作机制核验或调参，冻结六局作有界复核，后期新局再留出；同一局的SL尝试不得跨训练/验证分组。当前不存在保持抽序、预算和后轮动作不变的受控完整胜负对照。未证明改变排序、提前喝或留药的胜率收益。

回退：本批无行为改动可回退；保持原源码/经验/原始日志/失败材料。后续若实现则独立源码提交，按原沙箱/live/通知流程；本批不预造实现commit、发布号或shipped。其他角色及未观察进阶保持原行为；未读取其他角色私有知识。
'''

proposal = header + evidence + sections + validation
(HERE / 'proposal.md').write_text(proposal)

report = header + '''
## 交付与检查结果

运维交付入口为同目录 proposal.md、proposal-results.json、audit.json、source-audit.json；十份原提案SHA核验见proposal-originals.json。原六局复盘报告已只读核对，未重复追加复盘。没有新机制、策略反证或新代码提案；751T7材料口径勘误沿既有记录保留。

学习账本仅经根目录ledger.py追加本批追溯where/note；16个既有条目的claim、first_run、prior、evidence、status、version均保持，尤其不将已shipped经验降级proposed，不冒记新shipped。CLI原输入/输出、根账本逐行位置与前后保护核验见ledger-update.jsonl、ledger-cli.stdout.txt、ledger-receipt.json。未调用code_proposals add以制造重复id；最终code_proposals沿用本批十个已注册id。

不提交纯报告，不合入live，不发eval版本，不修改双通知文件、根请求、learn.json、任务模板、运维prompt或其他角色。没有新规则上线，故不触发规则上线通知。所有过程文件在本批scratch，工作树源码HEAD及tracked状态保持。
本会话未独立取得原生模型/effort请求元数据，不声称仅凭任务/默认配置已核实际切换；原普通模式/high任务文字及既有线程保持，未启动辅助模型。
''' + evidence + sections + validation + '''
## 完整性和限制

本批runs仅为派发的六个锚点，不冒称重新计算经验库中的全历史统计。8444条原行身份/字节核验不等于对每个决策进行因果分析；语义分析集中于派发十项相关的固定窗口。原dirty源码、未执行反事实、随机药水完整选择、毛伤逐源结算、路线/休息后继和完整候选归属仍有缺口。不能将自然败局或更多存活回合当新规则有效/无效的独立验证，也不关闭任何宽父要求。

gitleaks只扫描本批scratch材料，带redact并保存退出码；无源码提交，未把扫描写成生产测试。最终完整性读回及输出JSON见completion.json和final-integrity.json。
'''
(HERE / 'report.md').write_text(report)
completion = {'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'],
              'base': base, 'runs': dispatch['runs'], 'fixes': [],
              'skipped': dispatch['proposal_ids'], 'merged': None,
              'tests': {'tsc': None, 'vitest': None, 'cases': None},
              'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
              'proposal_results': results, 'report': report_path}
(HERE / 'completion.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2) + '\n')

updates = []
for ident in sorted({i for q in queue.values() for i in q['ledger']}):
    related = [i for i in dispatch['proposal_ids'] if ident in queue[i]['ledger']]
    note = (f"本批{dispatch['batch']}复核六个派发Silent A10锚点原始8444行；关联提案"
            + ','.join(related) + '均waiting，具体缺数据和反例见' + report_path
            + '。仅补追溯，不改旧claim/首证/prior/evidence/status/version，不新增或冒记实现/测试/shipped。'
            + ('751T7题面9/15与相邻轮实际净扣12/18分列；净损13/23、差6输出/10血不变，原文和首次材料失败保留。'
               if ident in ['silent-0079', 'silent-0176', 'silent-0021'] else ''))
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [proposal_path, report_path]}, 'note': note})
(HERE / 'ledger-update.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'report': report_path, 'proposal': proposal_path, 'results': len(results),
                  'ledger_trace_updates': len(updates)}, ensure_ascii=False))

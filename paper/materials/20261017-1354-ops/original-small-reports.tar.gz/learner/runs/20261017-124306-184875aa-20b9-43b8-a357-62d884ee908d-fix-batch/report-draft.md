## 修 bug 回报

- 合并基线：main → ed6d77cea7b5c7a4980888e9f5877b6e00be3d7e
- 修复：selection-hidden-daggers-conditional-followup-readback — 源码已完成，待完整自测及提交 — 测试 agent/tests/silent-hidden-daggers-selection.test.ts:delivers conditional facts / transports the real loop — 去掉修复时失败：是
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb9be14d620b368ec46974c1b57901ca
- 已被别人修掉的：核心通知失败日志 — 5c92f2aaf0b758a1a5e7d591745694004664f83a
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb61eef226eb7366f9612003480c83988
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7524bbb8e80a975f204f8d193657b46
- 已被别人修掉的：空产出补链误派 — 84366ad06ee4f978394c1b9489a82c83ea12bd36
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a826e94f9708af4b1a265e1892659f4e
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f
- 已被别人修掉的：纸鹤夹具 — befc39e5ca0105f8ff96d47f817df44f0b2760f1
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e5a0f234f082972d21b203dbf8229d7
- 已被别人修掉的：共享main启动冲突 — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2
- 已被别人修掉的：根事件通知路径 — 577f0bc424b7287910735cfdc86c253cc7ee8057
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe043cb8738cce57870354fa23fa84a1
- 已被别人修掉的：局间quiet误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d
- 已被别人修掉的：global-health异步测试 — d27df54f0651c4af84c6c12ceceec82a016f1142
- 已被别人修掉的：target-options固定预算 — 83a7f796c24eea8f16eb317bc70bfd832251ad27
- 已被别人修掉的：retention数字UUID — d91236326bc1af7a5417ce016c1a182f8084e7a3
- 已被别人修掉的：retention旧根scratch — 0699b05c436d3d51d00ee92f153d16d16e64bea4
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec5fc6eafe576a1296bbdadde43432ee
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ceeb81d534159b3516458521ad09bbed
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a5168d1a8cb456aed1c926b2d1b6c4488
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b7913a53b9e2645f40db1657eb5213c
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb12a1d4b2f34ee767bb2816a3a0b466
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537
- 已被别人修掉的：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70bfb2a91138ede0e1f6046927c116a4
- 已被别人修掉的：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66bd75c6d6952772dcf712399eda828b
- 已被别人修掉的：infra-test-rollout-ties-host-timeout-15000 — da08fcead2025c293140f1ba103d8efdbd39a4c3
- 已被别人修掉的：infra-test-build-facts-selection-remove-latency — e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0
- 已被别人修掉的：h1-budget-completion-health-contract — c40e43fd25c200a01f4da94a4dac8db1b34664a8
- 已被别人修掉的：h1-strict-pick-deadline-stall — b3b9734d85defbdbd1b73ab85fab9ea2f636affd
- 没修的：出牌、药水、SL、终局、路线及其他角色机制条目（含0308/0365/0481/0487/0496） — 策略类，保留原独立 strategy-proposal 链；本批只接通0499已有条件事实，不修改策略或机制。
- 没修的：silent-0332实际nonpositive-hp资源契约根因 — 证据不足，沿原0332/5aa2672专用owner；不把诊断接线或固定替身当根因已修。
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；启动租约/UUID/旧scratch窄修已存在，上游扫描竞态、删除归属和容量根因仍未核定。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查 — 独立架构、策略或归因任务，超出普通纯bug批次。
- 没修的：core-build-notify-222802-rc2旧原生通知恢复 — 旧失败缺stderr，不能确认未送达，保留原失败、不重发通知。
- 没修的：Codex缓存实测、DPR/B2性能及历史宿主超时根因 — 证据不足或独立性能任务；不用固定夹具结果声称自然性能或胜率改善。
- 测试：最终完整沙箱入口进行中；最终撤源码4项失败，恢复源码SHA一致，定向2文件21项通过。
- 合入：未合入；main/live基线预检有15处历史记录冲突，最终提交后还须锁内核实。
- 需要 Roy 定的事：无

边界与证据：只改四个生产叶及两份固定测试/夹具。原17帧已从只读logs逐offset/bytes核state并计算SHA，见evidence-and-owner-readback.json。来源2Q6ZYZ6JHM0M F5T1/F8T1,T5，账本0499/0205，原提案59b2e430bb7521d4已用CLI去重读回。
条件后继永不恢复为可执行memo；来源/预测缺失unknown，实际选择失去所需副本invalidated。升级、多敌、其它角色/进阶及既有T6单弃保持原边界，未添加卡牌机制/血价/药水/SL规则。
生产主循环固定替身只证明两道执行闸后的实际请求传输，暖缓存仍按既有代码选线；不冒称重放原完整dirty树、原局转胜、自然live采用或入库消费者已完成。
首轮源码与测试开发失败、旧完整检查、预检、所有patch及负控日志保留。最终完整检查以source-sandbox-final.log及最终输入SHA为准，不借旧运行或其它树结果。
尚未实际live，不分配release_id，不登记implemented/shipped，不写规则实际上线双通知。

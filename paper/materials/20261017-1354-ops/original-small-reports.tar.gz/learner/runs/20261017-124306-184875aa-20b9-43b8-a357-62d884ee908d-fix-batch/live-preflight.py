from pathlib import Path
import json,re,subprocess

root=Path('/home/dw/Projects/agent-sts2')
scratch=root/'learner/runs/20261017-124306-184875aa-20b9-43b8-a357-62d884ee908d-fix-batch'
live=root/'.worktrees/live'
source=(scratch/'source-commit.txt').read_text().strip()
assert re.fullmatch('[0-9a-f]{40}',source)

def git(*args,check=True):
    result=subprocess.run(['git','-C',str(live),*args],capture_output=True,text=True,timeout=120)
    if check and result.returncode: raise RuntimeError(result.stderr)
    return result

before=git('rev-parse','HEAD').stdout.strip()
base=json.loads((scratch/'already-fixed-audit.json').read_text())['base']
refresh=git('status','--porcelain','--untracked-files=no','--','notes/fight-value-backtest.md','knowledge').stdout.splitlines()
index=git('diff','--cached','--name-only').stdout.splitlines()
own=git('diff','--name-only',base,source,'--').stdout.splitlines()
previews={}
for label,args in [('default',[]),('no_directory_renames',['-c','merge.directoryRenames=false'])]:
    result=git(*args,'merge-tree','--write-tree',before,source,check=False)
    text=result.stdout+result.stderr
    (scratch/('final-live-preview-'+label+'.txt')).write_text(text)
    previews[label]={'rc':result.returncode,'conflicts':[line for line in text.splitlines() if line.startswith('CONFLICT')]}
after=git('rev-parse','HEAD').stdout.strip()
assert after==before
blocked=any(value['rc']!=0 for value in previews.values())
record={'status':'merge_conflicts' if blocked else 'preview_clean','locked':True,'source':source,'base_live':before,
    'live_after':after,'merged':None,'own_changed_paths':own,'own_knowledge_changes':[p for p in own if p.startswith('knowledge/')],
    'knowledge_refresh_status':refresh,'preexisting_index':index,'previews':previews,
    'boundary':'Read-only preflight under live-merge.lock; no live index, tracked file, refresh commit or branch update performed. The requested builder wait is namespace-local, not a host process absence proof.'}
(scratch/'publication.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':record['status'],'source':source,'base_live':before,
    'default_conflicts':len(previews['default']['conflicts']),
    'no_directory_rename_conflicts':len(previews['no_directory_renames']['conflicts']),
    'own_knowledge_changes':record['own_knowledge_changes'],'live_untouched':True},ensure_ascii=False))
raise SystemExit(3 if blocked else 0)

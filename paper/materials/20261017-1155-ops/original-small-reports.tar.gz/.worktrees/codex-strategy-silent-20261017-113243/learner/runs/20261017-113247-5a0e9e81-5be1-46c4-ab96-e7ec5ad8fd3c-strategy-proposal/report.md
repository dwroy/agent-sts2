# 策略批次回报

记录时间：2026-10-17 11:43:30 CST。

基线与最终HEAD：`d675d48f6f81d39ec1354e244dd69569b8be33ec`。本批仅10个派发ID；完整处置、证据局号/层/回合/账本与验收方法见 [proposal.md](proposal.md)。

结论：证据支持同轮资源差值和已观察机制；不足以新增选线规则或证明完整候选与后继执行。10项均waiting，未改源码、知识或现有规则，未合入live，无提交和发布号。

## 冻结输入与核验

身份/原稿：`dispatch.json`、`queue-snapshot.json`、`run-identities.json`、10份原稿副本；账本30项及本角色相关经验25项快照另存。共用extract_evidence.py抽取8流，保存每条source/line/offset/bytes/SHA及明确身份；`verify_evidence.py`再次按offset核原字节、完整JSON和身份，并核输出摘要及各局计数。

| 流 | source_size（字节） | 入选行数 |
|---|---:|---:|
| states | 13835520245 | 4062 |
| decisions | 2187200607 | 3941 |
| sl-attempts | 45017637 | 38 |
| run-config | 1933815 | 6 |
| run-plans | 8823594 | 33 |
| brain | 729383030 | 188 |
| runs | 355966 | 6 |
| fight-plans | 2233957 | 0 |

总计8274条封套逐字节一致；906个目标楼层状态整理为`observed-frames.jsonl`。该材料检查不是生产tsc/vitest或策略红绿测试。抽取期间初稿输出文件曾为0字节，完整抽取及manifest保持；没有用初稿0行断言缺日志。

四组同指纹配对见`paired-observations.json`。均以decision.observed_ts和完整日志fingerprint匹配唯一源状态，再读取实际下一轮首帧；敌实体列表/最大HP保持一致才计算本体净扣。

| 局/层/回合 | 决策行 | 原/替实际损血 | 原/替敌本体净扣 |
|---|---|---|---|
| 8JRE1C4H4Z2W F33 T2 | [270216, 270282] | 3/15 | 10/17 |
| YF0LXT1QSTGG F48 T1 | [271309, 271348] | 0/9 | 45/38 |
| XP2SL33HT0D9 F33 T3 | [271992, 272040] | 9/14 | 24/27 |
| XP2SL33HT0D9 F33 T1 | [271982, 272195] | 2/10 | 25/34 |

当前只确认端点差值，不把所有候选步骤当完整执行、不补未来毒伤或整战反事实。XP首试T1的278021仍是出牌末帧，核损血使用真正T2端点；YF末轮277528死亡帧55攻击不回填277527出牌末帧44攻击。

## 当前live窄实现范围

只读观察live：`f88c3ccde0fdb5019b117da9d8421e5c04d95518`；未写live。各叶HEAD/live blob、SHA与祖先核验见`source-coverage.json`。

| 源码 | 实际live祖先提交 | 已覆盖范围 |
|---|---|---|
| silent-selection-audit.ts | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 原答/护栏/SL候选预测，actual_turn仍null |
| silent-selection-dispatch.ts | fdaf787a372880b0438e73bcac7e6d2168b038ed | 单动作回执，whole_plan_executed仍null |
| silent-sl-resource-comparison.ts | 1698adc96ba434a46942321e0237b70657e625b2 | 同轮模型资源、污染和余毒差；execution仍unverified |
| silent-phase-current.ts | aad2700abed6dff1d66e87fb36aaa6fedb39adf3 | 现场阶段/毒/持有与已建能力，非完整候选执行 |

source-coverage中turn-solver最后触及的main集成commit 442d8c308adce9a69993a708359d917281d61dbe并非所读live祖先，文件blob相同也不能将其报作live源码提交；对应实际源7af803c06e82e2aafe6a595fab7a23e0f3f44fb3已另核为live祖先。此处只说明窄源码存在，不登记任何整提案duplicate。

## 逐项回报

| 提案ID | 状态 | 具体原因 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | waiting | 缺旧运行实际移动表与污染、挡、毒、成长的联合消费者校准；逐击污染已有模型，尚不能关闭整个提案。 |
| silent-proposal-ae9e692d680e3819 | waiting | 缺逐敌抢夺量真值、遗忘退场返敏与返还后续步；不能由玩家总属性反推出每个来源的返还量或固定击杀顺序。 |
| silent-proposal-52f1e1bd2e7db0ed | waiting | 缺原运行冻结移动表、覆甲完整减层条件及联合消费者校准；首样本DB入口存在不能替代旧dirty输入复原。 |
| silent-proposal-6dd8bbff876be528 | waiting | 缺新召唤或同名替换身份真值、冻结移动输入与完整后继校准；已有HIGH_VOLTAGE成长路径和新实体清零入口只覆盖子项。 |
| silent-proposal-578e415a259e6835 | waiting | 候选和单动作回执已有窄实现；完整执行分段、重规划归属、逐来源资源与整战后继仍未认证。 |
| silent-proposal-c0767768bf6a7ab1 | waiting | 缺整线执行与抽弃牌后继校准、独立整战反事实；全败封顶不足以拟血价常数或禁止探索。 |
| silent-proposal-a46bdb7fe711d79a | waiting | 当前阶段与零毒事实已有窄实现；完整候选施毒、额外扣血、增段攻击和重规划后继的联合消费者仍未认证。 |
| silent-proposal-1044224808015e5c | waiting | 缺同抽序完整替线后继及独立整战验证；不能拟新探索规则或禁止全部付血探索。 |
| silent-proposal-7cbc6005db712ba9 | waiting | 轮初挡、临减与朝向事实已核；条件组合和完整候选实际兑现的联合校准仍缺，单项模型不能代整项关闭。 |
| silent-proposal-c59f592f1427a67e | waiting | 两局局部事实已核；实际分段、逐来源资源与完整后继联合校准仍缺，不关闭宽项或任何量化父要求。 |

## 验证、记录与交接

fixes=[]，merged=null。未改生产源码，不运行tsc/vitest、源码撤回失败/恢复通过或合后测试；三项tests均null，不将材料核验0冒作测试成功。不创造源码commit、eval版本或shipped；保持铁甲及所有既有行为。

只使用既有根ledger.py update追加本批proposal/report链接与waiting限制，by=learner:strategy-proposal；不重复添加旧evidence/support/repeat，不改status/version/shipped/claim/first_run，根账本追加及回读凭据见`ledger-update-input.json`、`ledger-update.log`、`ledger-readback.json`。本批没有新代码提案，最终code_proposals沿用十原ID；implementation_domains为空。

命令定位期间若干猜测路径不存在，随后用rg --files定位真实silent-selection-dispatch.ts及hand/loop.ts；这是本次只读命令路径错误，不报生产bug。首次队列历史输出过长截断，后改为精确十ID的add/latest与十原稿逐项读取；未据截断输出推结论。

失败/初稿/原始材料保留；不删除自身工作树。运维沿原队列保留10个waiting，待有满足各项缺口的新A10证据再派；本报告不关闭学习量化父要求，也不冒称经验已入库或消费者自然采用。

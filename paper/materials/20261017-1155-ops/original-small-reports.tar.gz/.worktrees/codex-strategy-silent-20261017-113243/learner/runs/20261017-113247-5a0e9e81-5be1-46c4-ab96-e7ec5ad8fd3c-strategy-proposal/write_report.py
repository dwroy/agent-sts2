"""汇总本批已核材料；不修改队列、知识、源码或运行配置。"""
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip()
dispatch = json.loads((HERE / 'dispatch.json').read_text())
queue = json.loads((HERE / 'queue-snapshot.json').read_text())
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
verification = json.loads((HERE / 'evidence-verification.json').read_text())
pairs = json.loads((HERE / 'paired-observations.json').read_text())
coverage = json.loads((HERE / 'source-coverage.json').read_text())

facts = [
('棱柱技能污染与收益联合核验', 'DUZUBAJ3A8GP，F27 T4—T6；states 274830—274839。',
 'T4污染0→3→3→6，能力施放未加污染；T5火花3→6，三技能污染0→6→12→18，17挡对26攻击，46→37损9；T6污染消失。',
 '技能同时提供挡与施毒；不能从污染血价推出所有技能都不该打。',
 '缺旧运行实际移动表与污染、挡、毒、成长的联合消费者校准；逐击污染已有模型，尚不能关闭整个提案。',
 '冻结本局实际手牌、已见移动输入及动作前缀，逐步核玩家HP、毒、挡和火花；完整候选与抽弃牌后的新候选分段核对。'),
('逐来源抢夺及返还', '5PM6JAQG6FNQ，F39 T4—T6；states 274351—274362；末试T4另见274391以后。',
 'T4力敏各−4，两步法将敏捷恢复0；失落退场后力量恢复0，T6遗忘再夺使敏捷−2。',
 '末试一步法只有−2敏捷；死亡后清空能力的帧不能独立证明返还。',
 '缺逐敌抢夺量真值、遗忘退场返敏与返还后续步；不能由玩家总属性反推出每个来源的返还量或固定击杀顺序。',
 '新A10局冻结每次抢夺、每个来源退场与下一次出牌前后状态，核逐来源账和总属性；固定日志缺的来源不补默认值。'),
('下水道蚌加压与覆甲', 'CA5KE8GFJ9X2，F13 T1—T5；states 273239/273252/273263及相邻帧。',
 '喷水在0/4/8力量时为11/15/19；已见覆甲9/9/8/7/6。当前DB读取接口不对单项事实设置房间代价五样本门槛，ROOM_COST_MIN_N仍为5。',
 '现场覆甲序列不能独立识别所有减层触发；弱后的攻击不能当后轮停止成长。',
 '缺原运行冻结移动表、覆甲完整减层条件及联合消费者校准；首样本DB入口存在不能替代旧dirty输入复原。',
 '固定A10有效移动表及逐动作敌挡/覆甲/血/力量，分别验证事实读取与房间成本门槛；新增减层条件须有独立前后帧。'),
('电击成长与实体替换', '5PM6JAQG6FNQ，F38 T3—T4；states 274308/274313及相邻帧。',
 '连续帧中23上限电击的高电压均2，力量2→4、意图17→19；其他敌退场后index由4改3，不能以index等同稳定身份。',
 '未实打的先杀线只提供候选预测；同名、相同HP上限也不能无条件证明新召唤者继承状态。',
 '缺新召唤或同名替换身份真值、冻结移动输入与完整后继校准；已有HIGH_VOLTAGE成长路径和新实体清零入口只覆盖子项。',
 '冻结召唤前后连续帧及实际模板输入，区分实体退场、index重排与替换；核新建与存活实体各自的成长序列。'),
('沙虫护栏、SL及能力分账', '8JRE1C4H4Z2W，F33 T2/T5/T11；decisions 270216/270282；末轮states 276429—276434。',
 '同指纹T2原/替线实际损3/15、扣10/17；末T11五血22挡对37攻击，实际血归零，但完整需损15，毒另扣24至敌130。',
 'T2五轮死亡0/24与5/24不能称同死率；末轮实际损5是零血截断，不能当完整攻击只值5。原稿金刚杵→silent-0016链接与该账本护喉甲主题错配，保留原件并明记，不重复加支持。',
 '候选和单动作回执已有窄实现；完整执行分段、重规划归属、逐来源资源与整战后继仍未认证。',
 '按原指纹/attempt/decision_id核完整前缀、抽弃牌切断和后继重规划，分列实际血损、需要承受的血损、已建能力及未结算毒。'),
('实验体SL实际资源代价', 'YF0LXT1QSTGG，F48 第二/第三次T1；decisions 271309/271348；states 277327→277337、277366→277373。',
 '原/替线实际损0/9、敌本体净扣45/38；同题Jev原答相同而SL截断后续挡，差值为多损9且少扣7。',
 '整线可因抽弃牌重规划而未执行；原提案还保存F33 SL成功和末次恢复续步仍败的反例，本批不将其再计新独立样本。',
 '缺整线执行与抽弃牌后继校准、独立整战反事实；全败封顶不足以拟血价常数或禁止探索。',
 '用当前已存在的原答/护栏/SL/单动作字段做逐段核验；完整执行与重规划后替线分别比较，后置新局验证政策。'),
('实验体阶段与实际兑现', 'YF0LXT1QSTGG，F48末次T3—T5；states 277512—277528。',
 '4血4毒旧阶段变为212血无旧毒/力量；两尖啸33→15→0，次轮恢复44攻击；触媒2但零毒。T5先13+10成23挡，第三小刀才5→6敏捷，旧挡仍23；敌197→160的37含消耗额外扣血。',
 '死亡后显示下一段数55不能替代出牌结束时44攻击；持有组件、已建能力与已兑现伤害不同，不能从零毒认定唯一败因。',
 '当前阶段与零毒事实已有窄实现；完整候选施毒、额外扣血、增段攻击和重规划后继的联合消费者仍未认证。',
 '固定阶段切换、每次消耗、施毒、敏捷取得及格挡先后，逐步核完整候选，未知抽牌后继保留未知。'),
('双蟹SL并列血价', 'XP2SL33HT0D9，F33 T1/T3；decisions 271982/272195、271992/272040。',
 'T3原/替线实际损9/14、扣24/27；T1损2/10、扣25/34，末次另建1力量。均经同日志指纹和实际下一轮端点核对。',
 'T1成长收益须保留；T3当前差值不能说明后轮单变量因果，零胜率并列不等于安全。',
 '缺同抽序完整替线后继及独立整战验证；不能拟新探索规则或禁止全部付血探索。',
 '保留当前候选、永久成长、朝向、抽弃牌及药瓶随机落点，按独立run划分发现/验证，后置新A10局检验任何拟议窄规则。'),
('双蟹朝向、临减与能力窗口', 'XP2SL33HT0D9，F33末次T2—T5；states 278236—278258及后继。',
 'T2轮初14挡，镣铐爪力量0→−9、攻击4→0，斗篷另6成20；T3减力恢复。T4火箭57→38→28分别对应朝向与弱，4敏脆弱下偏折6挡，33→11实损22。',
 '船夹板不能当每轮固定挡，后取得力量/敏捷不倒补；不能以末局已铺能力但败推固定能力优先级。',
 '轮初挡、临减与朝向事实已核；条件组合和完整候选实际兑现的联合校准仍缺，单项模型不能代整项关闭。',
 '固定14+6=20、0→−9→0、57→38→28和脆弱挡的逐步联合消费者输出，抽弃牌切断后另建执行段。'),
('两局机制与SL资源合并审计', 'YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5；账本列表保持原提案。',
 '本批重新核两局三组同指纹血价和阶段/临减/朝向的局部事实；分列模型预测、实际HP净损、敌本体净扣及未结算毒。',
 '六次同存档尝试只属于一个局；多个窄入口不能拼成完整执行或策略胜率证明，其他原历史主题本批未重新全量研究。',
 '两局局部事实已核；实际分段、逐来源资源与完整后继联合校准仍缺，不关闭宽项或任何量化父要求。',
 '逐段复核两局消费者，绑定指纹/attempt/decision_id/实际派发，检查重规划和资源结转；缺帧写明，未来独立局后置验证。'),
]
assert len(queue) == len(facts) == 10
results = [{'id': q['id'], 'state': 'waiting', 'reason': f[4]} for q, f in zip(queue, facts)]
(HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

intro = [f'# 本批静默猎手策略提案核验\n\n记录时间：{stamp}。',
 f'批次：20261017-113243-strategy-proposal；base：`{base}`。',
 '本批为10个已领取的普通代码提案，无research_request、implementation_request或proposal_repair；根专题仍绑定旧批次，条件不匹配，本批不承接。开工tracked/index干净；按普通任务合并main返回Already up to date，HEAD未变。',
 '来源六局均由runs.jsonl确认SILENT/A10。当前经验只读本角色；不以未核的历史支持计数、当前刷新数据或预训练知识补机制。10份原稿逐SHA匹配，原始字节另存各`*.original.md`；原提案及队列均未修改。',
 '处置：10项均waiting；没有新源码、知识、测试或版本提交，没有live合并；不登记implemented/duplicate/shipped。现有窄实现保留，不能把它们作为整项完成证明。']
sections = list(intro)
for q, f in zip(queue, facts):
    title, location, observation, counter, reason, validation = f
    sections += [f'## {q["id"]}：{title}',
                 '关联既有账本：' + '、'.join(q['add']['ledger']) + '。',
                 '证据局/层/回合：' + location,
                 '本批核实：' + observation,
                 '反例与边界：' + counter,
                 '旧/新行为：保留现有选择、评分、药水与SL门槛，全部候选继续保留；本次不发布新规则。',
                 '**处置waiting：**' + reason,
                 '后续可验收方法：' + validation]
sections += ['## 样本与限制',
 '六局为本批发现/复核集，全部A10；每个同存档多尝试按run分组，不能增加独立样本数。没有新的时间后置验证局，不拟合HP惩罚、能力价值、固定杀序或房间代价。回退：本批无生产变更可回退，保留旧规则；材料或链接勘误只追加记录，不覆盖历史。',
 '本批核验的是原有观察，并未发现足以推翻旧知识的新证据。原稿silent-0016归属错配已明记；不静默迁移支持、不重复写历史复盘、不为原项再建代码提案ID。',
 '六局run-config均记录dirty，包含实际刷新知识；当前干净commit不能替代当时未保存的有效移动表或随机状态。日志指纹逐字相同也不证明完整RNG状态和后续抽序一致。',
 'fight-plans在本次截点对六局选到0行，仅表示该截点未选到，不断言源日志缺失。各流截点分别冻结，不冒称同一原子全局cut。原始states/decisions/brain各2条无效行由共用入口统计并排除；未将它们当本角色证据。']
(HERE / 'proposal.md').write_text('\n\n'.join(sections) + '\n')

report = ['# 策略批次回报', f'记录时间：{stamp}。',
          f'基线与最终HEAD：`{base}`。本批仅10个派发ID；完整处置、证据局号/层/回合/账本与验收方法见 [proposal.md](proposal.md)。',
          '结论：证据支持同轮资源差值和已观察机制；不足以新增选线规则或证明完整候选与后继执行。10项均waiting，未改源码、知识或现有规则，未合入live，无提交和发布号。',
          '## 冻结输入与核验',
          '身份/原稿：`dispatch.json`、`queue-snapshot.json`、`run-identities.json`、10份原稿副本；账本30项及本角色相关经验25项快照另存。共用extract_evidence.py抽取8流，保存每条source/line/offset/bytes/SHA及明确身份；`verify_evidence.py`再次按offset核原字节、完整JSON和身份，并核输出摘要及各局计数。',
          '| 流 | source_size（字节） | 入选行数 |\n|---|---:|---:|']
for m in manifest:
    report.append(f'| {m["stream"]} | {m["source_size"]} | {sum(m["counts"].values())} |')
report += [f'总计{verification["verified_rows"]}条封套逐字节一致；906个目标楼层状态整理为`observed-frames.jsonl`。该材料检查不是生产tsc/vitest或策略红绿测试。抽取期间初稿输出文件曾为0字节，完整抽取及manifest保持；没有用初稿0行断言缺日志。',
           '四组同指纹配对见`paired-observations.json`。均以decision.observed_ts和完整日志fingerprint匹配唯一源状态，再读取实际下一轮首帧；敌实体列表/最大HP保持一致才计算本体净扣。',
           '| 局/层/回合 | 决策行 | 原/替实际损血 | 原/替敌本体净扣 |\n|---|---|---|---|']
for p in pairs:
    a,b = p['outcomes']
    report.append(f'| {a["start"]["run_id"]} F{a["start"]["floor"]} T{a["start"]["turn"]} | {p["decision_lines"]} | {a["observed_hp_loss"]}/{b["observed_hp_loss"]} | {a["observed_enemy_body_net_loss"]}/{b["observed_enemy_body_net_loss"]} |')
report += ['当前只确认端点差值，不把所有候选步骤当完整执行、不补未来毒伤或整战反事实。XP首试T1的278021仍是出牌末帧，核损血使用真正T2端点；YF末轮277528死亡帧55攻击不回填277527出牌末帧44攻击。',
           '## 当前live窄实现范围',
           f'只读观察live：`{coverage["live_observed"]}`；未写live。各叶HEAD/live blob、SHA与祖先核验见`source-coverage.json`。',
           '| 源码 | 实际live祖先提交 | 已覆盖范围 |\n|---|---|---|',
           '| silent-selection-audit.ts | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 原答/护栏/SL候选预测，actual_turn仍null |',
           '| silent-selection-dispatch.ts | fdaf787a372880b0438e73bcac7e6d2168b038ed | 单动作回执，whole_plan_executed仍null |',
           '| silent-sl-resource-comparison.ts | 1698adc96ba434a46942321e0237b70657e625b2 | 同轮模型资源、污染和余毒差；execution仍unverified |',
           '| silent-phase-current.ts | aad2700abed6dff1d66e87fb36aaa6fedb39adf3 | 现场阶段/毒/持有与已建能力，非完整候选执行 |',
           'source-coverage中turn-solver最后触及的main集成commit 442d8c308adce9a69993a708359d917281d61dbe并非所读live祖先，文件blob相同也不能将其报作live源码提交；对应实际源7af803c06e82e2aafe6a595fab7a23e0f3f44fb3已另核为live祖先。此处只说明窄源码存在，不登记任何整提案duplicate。',
           '## 逐项回报', '| 提案ID | 状态 | 具体原因 |\n|---|---|---|']
for r in results:
    report.append(f'| {r["id"]} | waiting | {r["reason"]} |')
report += ['## 验证、记录与交接',
           'fixes=[]，merged=null。未改生产源码，不运行tsc/vitest、源码撤回失败/恢复通过或合后测试；三项tests均null，不将材料核验0冒作测试成功。不创造源码commit、eval版本或shipped；保持铁甲及所有既有行为。',
           '只使用既有根ledger.py update追加本批proposal/report链接与waiting限制，by=learner:strategy-proposal；不重复添加旧evidence/support/repeat，不改status/version/shipped/claim/first_run，根账本追加及回读凭据见`ledger-update-input.json`、`ledger-update.log`、`ledger-readback.json`。本批没有新代码提案，最终code_proposals沿用十原ID；implementation_domains为空。',
           '命令定位期间若干猜测路径不存在，随后用rg --files定位真实silent-selection-dispatch.ts及hand/loop.ts；这是本次只读命令路径错误，不报生产bug。首次队列历史输出过长截断，后改为精确十ID的add/latest与十原稿逐项读取；未据截断输出推结论。',
           '失败/初稿/原始材料保留；不删除自身工作树。运维沿原队列保留10个waiting，待有满足各项缺口的新A10证据再派；本报告不关闭学习量化父要求，也不冒称经验已入库或消费者自然采用。']
(HERE / 'report.md').write_text(('\n\n'.join(report) + '\n').replace('|\n\n|', '|\n|'))

response = {'task':'strategy-proposal','character':'silent','batch':'20261017-113243-strategy-proposal',
            'base':base,'runs':dispatch['runs'],'fixes':[],'skipped':[], 'merged':None,
            'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':dispatch['proposal_ids'],
            'implementation_domains':[],'proposal_results':results,'report':str(HERE/'report.md')}
(HERE / 'result.json').write_text(json.dumps(response, ensure_ascii=False, indent=2) + '\n')

linked = {}
for q, f in zip(queue, facts):
    for ledger_id in q['add']['ledger']:
        linked.setdefault(ledger_id, []).append(q['id'])
updates = [{'id':i,'by':'learner:strategy-proposal',
            'where':{'proposal':[str(HERE/'proposal.md'),str(HERE/'report.md')]},
            'note':'20261017-113243-strategy-proposal：仅复核原静默A10六局证据及既有窄源码，关联'+','.join(ids)+'；整项waiting，具体缺口见报告；无源码/知识/规则/版本/合入，不新增支持/重复证据，保留原发布状态。'}
           for i,ids in sorted(linked.items())]
(HERE / 'ledger-update-input.json').write_text(json.dumps(updates,ensure_ascii=False,indent=2)+'\n')
ledger = ROOT/'paper/materials/learning/ledger.jsonl'
data = ledger.read_bytes()
(HERE / 'ledger-prefix.json').write_text(json.dumps({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},indent=2)+'\n')
print(json.dumps({'base':base,'提案数量':len(results),'账本追加请求数':len(updates),'报告':str(HERE/'report.md')},ensure_ascii=False))

"""核对本批冻结封套与原字节；只生成研究材料，不运行生产测试。"""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
spec = importlib.util.spec_from_file_location("extract", WORKTREE / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
dispatch = json.loads((HERE / "dispatch.json").read_text())
allowed = set(dispatch["runs"])
streams = {}
checks = []
for item in manifest:
    path = HERE / "evidence" / (item["stream"] + ".evidence.jsonl")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item["output_sha256"]
    envelopes = [json.loads(line) for line in path.open()]
    counts = collections.Counter(e["run_id"] for e in envelopes)
    assert all(counts[r] == item["counts"][r] for r in allowed)
    if envelopes:
        with Path(envelopes[0]["source"]).open("rb") as source:
            for e in envelopes:
                assert e["offset"] + e["bytes"] <= item["source_size"]
                source.seek(e["offset"])
                raw = source.read(e["bytes"])
                assert raw.endswith(b"\n")
                assert hashlib.sha256(raw).hexdigest() == e["sha256"]
                assert json.loads(raw) == e["row"]
                assert extract.run_identity(e["row"]) == e["run_id"] in allowed
    streams[item["stream"]] = envelopes
    checks.append({"stream": item["stream"], "source_size": item["source_size"],
                   "verified_rows": len(envelopes), "all_bytes_and_identities_match": True})

states = streams["states"]
decisions = {e["line"]: e for e in streams["decisions"]}
by_line = {e["line"]: e for e in states}

def state(e):
    return e["row"]["state"]

def powers(raw):
    return {p["power_id"]: p["amount"] for p in raw.get("powers", [])}

def slim(e):
    s = state(e)
    c = s.get("combat") or {}
    p = c.get("player") or {}
    return {"line": e["line"], "offset": e["offset"], "bytes": e["bytes"], "sha256": e["sha256"],
            "run_id": e["run_id"], "floor": s.get("run", {}).get("floor"), "turn": s.get("turn"),
            "hp": p.get("current_hp"), "block": p.get("block"), "powers": powers(p),
            "enemies": [{"id": x["enemy_id"], "index": x["index"], "hp": x["current_hp"],
                         "max_hp": x["max_hp"], "block": x["block"], "powers": powers(x),
                         "move": x.get("move_id"), "intents": x.get("intents", [])}
                        for x in c.get("enemies", [])]}

def find_start(d):
    row = d["row"]
    matches = [e for e in states if e["run_id"] == d["run_id"]
               and e["row"].get("fingerprint") == row["fingerprint"]
               and e["row"].get("observed_ts") == row["observed_ts"]]
    assert len(matches) == 1, (d["line"], len(matches))
    return matches[0]

def turn_endpoint(start):
    s = state(start)
    for e in states:
        t = state(e)
        if e["line"] <= start["line"] or e["run_id"] != start["run_id"]:
            continue
        assert t.get("run", {}).get("floor") == s["run"]["floor"]
        if t.get("turn") != s["turn"]:
            assert t.get("turn") == s["turn"] + 1
            return e
    raise AssertionError("缺下一轮端点")

paired = []
for left, right, expected in [(270216, 270282, ((3, 10), (15, 17))),
                               (271309, 271348, ((0, 45), (9, 38))),
                               (271992, 272040, ((9, 24), (14, 27))),
                               (271982, 272195, ((2, 25), (10, 34)))]:
    a, b = decisions[left], decisions[right]
    assert a["row"]["fingerprint"] == b["row"]["fingerprint"]
    outcomes = []
    for d in (a, b):
        start = find_start(d)
        end = turn_endpoint(start)
        x, y = slim(start), slim(end)
        assert [(e["id"], e["max_hp"]) for e in x["enemies"]] == [(e["id"], e["max_hp"]) for e in y["enemies"]]
        loss = x["hp"] - y["hp"]
        damage = sum(e["hp"] for e in x["enemies"]) - sum(e["hp"] for e in y["enemies"])
        outcomes.append({"decision_line": d["line"], "start": x, "next_turn": y,
                         "observed_hp_loss": loss, "observed_enemy_body_net_loss": damage})
    assert tuple((o["observed_hp_loss"], o["observed_enemy_body_net_loss"]) for o in outcomes) == expected
    paired.append({"decision_lines": [left, right], "identical_logged_fingerprint": True,
                   "outcomes": outcomes,
                   "delta_hp_loss": outcomes[1]["observed_hp_loss"] - outcomes[0]["observed_hp_loss"],
                   "delta_enemy_body_net_loss": outcomes[1]["observed_enemy_body_net_loss"] - outcomes[0]["observed_enemy_body_net_loss"],
                   "limit": "仅同轮实际端点；日志指纹未覆盖全部随机状态，不证明完整候选执行或整战反事实。"})

floors = {"DUZUBAJ3A8GP": {27}, "5PM6JAQG6FNQ": {38, 39}, "CA5KE8GFJ9X2": {13},
          "8JRE1C4H4Z2W": {33}, "YF0LXT1QSTGG": {48}, "XP2SL33HT0D9": {33}}
selected = [slim(e) for e in states if state(e).get("run", {}).get("floor") in floors[e["run_id"]]]
(HERE / "observed-frames.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in selected))
(HERE / "paired-observations.json").write_text(json.dumps(paired, ensure_ascii=False, indent=2) + "\n")
(HERE / "evidence-verification.json").write_text(json.dumps({"streams": checks,
    "verified_rows": sum(c["verified_rows"] for c in checks), "selected_mechanism_frames": len(selected),
    "paired_observations": len(paired), "production_tests_run": False}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"逐字节核对封套": sum(c["verified_rows"] for c in checks), "机制帧": len(selected),
                  "同指纹配对": [{"决策": p["decision_lines"], "多损血": p["delta_hp_loss"],
                                   "多扣敌本体": p["delta_enemy_body_net_loss"]} for p in paired]}, ensure_ascii=False))

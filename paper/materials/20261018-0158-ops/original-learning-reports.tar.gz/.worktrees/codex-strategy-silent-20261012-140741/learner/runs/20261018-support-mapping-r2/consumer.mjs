import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {cpSync,mkdirSync,readFileSync,writeFileSync,readdirSync,statSync} from 'node:fs';
import {resolve,join,relative} from 'node:path';
import {pathToFileURL} from 'node:url';

const here=resolve('learner/runs/20261018-support-mapping-r2');
const [stage,repoArg,commit]=process.argv.slice(2),repo=resolve(repoArg),out=join(here,stage);
assert.match(commit,/^[a-f0-9]{40}$/);mkdirSync(out,{recursive:true});
const save=(name,data)=>writeFileSync(join(out,name),JSON.stringify(data,null,2)+'\n');
const sha=b=>createHash('sha256').update(b).digest('hex');
const mod=p=>import(pathToFileURL(join(repo,'agent/src',p+'.ts')).href);
process.env.CHARACTER='silent';
const {setKnowledgeCharacter}=await mod('knowledge/files');setKnowledgeCharacter('silent');
const {loadConstructionData}=await mod('construction/data');
const {loadConstructionSupport}=await mod('construction/support');
const {missingRequirements}=await mod('construction/planner');
const {evaluateCardShadow,askCardShadow}=await mod('sim/human-pace-card-shadow');
const {parseGameState}=await mod('hand/mod/schema');
const {makeKnowledge}=await mod('knowledge/index');
const {KnowledgePrompt}=await mod('brain/knowledge');
const {RunJournal}=await mod('memory/run-journal');
const kd=join(out,'knowledge');mkdirSync(kd,{recursive:true});
for(const path of ['common','characters/silent'])cpSync(join(repo,'knowledge',path),join(kd,path),{recursive:true});
if(stage==='negative-data') {
  cpSync(join(here,'experience-before.json'),join(kd,'characters/silent/experience.json'));
  writeFileSync(join(kd,'characters/silent/construction-support.json'),'null\n');
}
const templates=loadConstructionData('silent',kd).templates;
const support=loadConstructionSupport('silent',templates,kd);
const exp=JSON.parse(readFileSync(join(kd,'characters/silent/experience.json')));
const analysis=JSON.parse(readFileSync(join(here,'support-analysis.json')));
const cases=JSON.parse(readFileSync(join(here,'support-frames.json')));
const changes=JSON.parse(readFileSync(join(here,'changes.json')));
const indices={P:2,D:2,S:3,R:5};
const prompt=new KnowledgePrompt({postmortems:()=>({path:'fixed-consumer:case-title-enrichment-omitted',sections:new Map()})});
const inputs=[],outputs=[];
for(const sample of cases) {
  const frame=sample.frames[indices[sample.core]],raw=JSON.parse(readFileSync(frame.saved)).state;
  const parsed=parseGameState(raw),knowledge=makeKnowledge({cards:raw.run.deck.map(c=>({id:c.card_id,type:c.card_type,name:c.name}))},'cache');
  const current={cards:raw.run.deck.map(c=>({id:c.card_id,upgraded:c.upgraded})),relics:raw.run.relics.map(r=>r.relic_id),
    hp:raw.run.current_hp,maxHp:raw.run.max_hp,gold:raw.run.gold,floor:raw.run.floor,cap:null};
  const core=templates.find(t=>t.id===sample.core),coreCard=core.requirements.flatMap(r=>r.any).find(c=>c.kind==='card');
  assert(core);assert.equal(core.status,'candidate');assert.deepEqual(missingRequirements(current,core),[]);
  const option=(key,id,upgraded)=>({key,id,upgraded,state:id?{...current,cards:[...current.cards,{id,upgraded}]}:current});
  const input={current,priorPlan:null,options:[option('observed-support',sample.card,false),option('upgrade-unobserved',sample.card,true),
    option('unmapped','FIXED_UNOBSERVED_CARD',false),option('core-requirement',coreCard.id,false),option('skip',null,null)]};
  const plan={runId:raw.run_id,construction:{primary:sample.core},want:[],avoid:[]};
  const pool={character:'silent',ascension:10,unknown:['fixed-no-model'],stages:[],unit:'fixed_no_simulation',source:{path:'fixed',sha256:'0'.repeat(64),generated:null}};
  const args={input,env:{state:parsed,knowledge},cores:templates,plan,pool,originalB3:{},setup:null};
  const baseline=await evaluateCardShadow({...args,supportData:null});
  const facts=await evaluateCardShadow({...args,supportData:support});
  const calls=[];
  const shadow=await askCardShadow(facts,{ask:async(state,questions,timeout)=>{
    const response={model:'fixed-no-model',answers:{card:{type:'choice',choice:'skip',probabilities:{},confidence:1,raw:{}}},latencyMs:0,inputTokens:0,outputTokens:0,requestId:'fixed-consumer'};
    calls.push({state,questions,timeout,response});return response;
  }},null);
  const memory=new RunJournal().render(parsed,knowledge,{}, {label:'fixed-consumer/support',factsCovered:true,statsCovered:true});
  const request={label:'fixed-consumer/support',question:'fixed evidence readback',system:'fixed-consumer',payload:{state:raw},memory};
  const full=prompt.apply(request,{ascension:10,knowledgeDir:kd});
  const checks={mapping_loaded:support!==null,observed_support:facts.rows.find(r=>r.key==='observed-support').support_component===true,
    upgrade_unknown:facts.rows.find(r=>r.key==='upgrade-unobserved').support_component===null,
    unmapped_unknown:facts.rows.find(r=>r.key==='unmapped').support_component===null,
    core_separate:facts.rows.find(r=>r.key==='core-requirement').core_component===true&&facts.rows.find(r=>r.key==='core-requirement').support_component===false,
    skip_no_support:facts.rows.find(r=>r.key==='skip').support_component===false,
    ranking_unchanged:facts.module_first===baseline.module_first&&JSON.stringify(facts.module_order)===JSON.stringify(baseline.module_order),
    shadow_only:facts.mode==='shadow'&&facts.delivered===false&&shadow.delivered===false,
    jev_projection:calls.length===1&&calls[0].state.facts.find(r=>r.key==='observed-support').support===true,
    full_experience:full.knowledge?.mode==='full'&&changes.every(c=>full.system.includes(c.added_lesson))};
  inputs.push({core:sample.core,source:frame.source,state:raw,fixed_hypothetical_options:input,plan,pool,
    limit:'The four observed combat states supply inventories. These are hypothetical fixed offers, not historical reward questions. No simulation, model or game actions.',request});
  outputs.push({core:sample.core,checks,baseline,facts,shadow,fake_jev_calls:calls,full_request:full});
}
const files=[];
function walk(p){for(const n of readdirSync(p)){const f=join(p,n);if(statSync(f).isDirectory())walk(f);else files.push({path:relative(out,f),sha256:sha(readFileSync(f))});}}
walk(kd);
save('input.json',{stage,repo,code_commit:commit,experience_version:exp.version,knowledge_files:files,inputs});
save('output.json',{outputs,natural_consumer:false,model_calls:0,game_actions:0});
const passed=outputs.every(o=>Object.values(o.checks).every(Boolean));
save('verification.json',{status:passed?'passed':'failed',kind:'fixed-consumer',experience_version:exp.version,stage,checks:outputs.map(o=>({core:o.core,...o.checks})),natural_adoption:false});
assert(passed,'a production mapping, experience or projection was not read back');
console.log(JSON.stringify({stage,status:'passed',cores:outputs.length,checks:outputs.reduce((n,o)=>n+Object.keys(o.checks).length,0),model_calls:0,game_actions:0}));

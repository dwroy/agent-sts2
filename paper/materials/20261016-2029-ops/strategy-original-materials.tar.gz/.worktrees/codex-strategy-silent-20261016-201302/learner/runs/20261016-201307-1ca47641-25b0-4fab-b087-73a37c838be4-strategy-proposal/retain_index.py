"""Keep a compact raw-log index so evidence survives prior worktree recycling."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
audit = json.loads((HERE / 'evidence-reuse-audit.json').read_text())
digest = hashlib.sha256()
count = 0
with (HERE / 'raw-evidence-index.jsonl').open('wb') as output:
    for stream in audit:
        seen = hashlib.sha256()
        with open(stream['preserved_envelopes'], 'rb') as source:
            for line in source:
                seen.update(line)
                item = json.loads(line)
                index = {'stream': stream['stream'], **{k: item[k] for k in
                         ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}}
                raw = (json.dumps(index, ensure_ascii=False) + '\n').encode()
                output.write(raw)
                digest.update(raw)
                count += 1
        assert seen.hexdigest() == stream['output_sha256']
assert count == 19929
(HERE / 'raw-index-audit.json').write_text(json.dumps({'rows': count, 'sha256': digest.hexdigest(),
    'scope': '仅保存逐行索引，原始内容仍在只读logs；按offset/bytes取回并核SHA，不依赖前批工作树存续。'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'rows': count, 'sha256': digest.hexdigest()}))

"""Append provenance through the ledger CLI and verify this batch's exact records."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
updates = [json.loads(line) for line in (HERE / 'ledger-update-input.jsonl').read_text().splitlines()]
ids = {u['id'] for u in updates}
spec = importlib.util.spec_from_file_location('batch_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def snapshot():
    rows, digest = [], hashlib.sha256()
    with LEDGER.open('rb') as handle:
        limit = os.fstat(handle.fileno()).st_size
        offset = 0
        while offset < limit:
            raw = handle.readline(limit - offset)
            digest.update(raw)
            offset += len(raw)
            try:
                row = json.loads(raw)
            except ValueError:
                continue
            if row.get('id') in ids:
                rows.append((len(rows) + 1, row))
    return limit, digest.hexdigest(), ledger.fold(rows)


print(subprocess.check_output(['date'], text=True).strip())
before_size, before_sha, before = snapshot()
write('ledger-before.json', before)
env = dict(os.environ, LEDGER_FILE=str(LEDGER), LEDGER_RUNS=str(ROOT / 'logs/runs.jsonl'),
           LEDGER_VERSIONS=str(ROOT / 'eval/versions.json'))
command = [sys.executable, str(ROOT / 'learner/ledger.py'), 'update']
run = subprocess.run(command, input=(HERE / 'ledger-update-input.jsonl').read_text(),
                     capture_output=True, text=True, env=env)
(HERE / 'ledger-cli.stdout.txt').write_text(run.stdout)
(HERE / 'ledger-cli.stderr.txt').write_text(run.stderr)
assert run.returncode == 0, run.stderr
after_size, after_sha, after = snapshot()
write('ledger-after.json', after)
prefix = hashlib.sha256()
own_rows = []
with LEDGER.open('rb') as handle:
    remaining = before_size
    while remaining:
        raw = handle.read(min(1024 * 1024, remaining))
        assert raw
        prefix.update(raw)
        remaining -= len(raw)
    assert prefix.hexdigest() == before_sha
    offset = before_size
    while offset < after_size:
        raw = handle.readline(after_size - offset)
        start, offset = offset, offset + len(raw)
        try:
            row = json.loads(raw)
        except ValueError:
            continue
        if row.get('op') != 'update' or row.get('id') not in ids:
            continue
        item = {k: v for k, v in row.items() if k not in ('op', 'ts')}
        if item not in updates:
            continue
        own_rows.append({'source': str(LEDGER), 'offset': start, 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
assert len(own_rows) == len(updates) and {r['row']['id'] for r in own_rows} == ids
preserved = ['claim', 'character', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'shipped_at', 'effect']
for ident in ids:
    for field in preserved:
        assert before[ident].get(field) == after[ident].get(field), (ident, field)
    for field in ['notes', 'history']:
        previous = before[ident].get(field, [])
        assert after[ident].get(field, [])[:len(previous)] == previous
    for key, values in before[ident].get('where', {}).items():
        assert after[ident]['where'][key][:len(values)] == values
    assert str(HERE / 'report.md') in after[ident]['where']['proposal']
write('ledger-append-audit.json', {'command': command, 'exit_code': run.returncode,
    'before_size': before_size, 'before_sha256': before_sha, 'after_size': after_size, 'after_sha256': after_sha,
    'old_prefix_preserved': True, 'old_claim_evidence_status_preserved': True, 'own_rows': own_rows})
print(json.dumps({'cli_exit_code': run.returncode, 'own_rows_verified': len(own_rows),
                  'old_prefix_preserved': True, 'old_claim_evidence_status_preserved': True}, ensure_ascii=False))

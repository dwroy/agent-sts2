"""Correct the decision-field reader and preserve narrowly scoped extra references."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-183355-s2/learner/runs/20261016-183402-78b0a6f4-a001-4b68-96d7-c78e04d94be3-strategy-proposal')


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def load_raw(ref):
    with open(ref['source'], 'rb') as source:
        source.seek(ref['offset'])
        raw = source.read(ref['bytes'])
    assert hashlib.sha256(raw).hexdigest() == ref['sha256']
    return json.loads(raw)


original = HERE / 'bounded-observations.json'
(HERE / 'bounded-observations-r1.json').write_bytes(original.read_bytes())
data = json.loads(original.read_text())
refs = json.loads((OLD / 'potion-action-summary.json').read_text())['ken_refs']
actions = []
for ref in refs:
    row = load_raw(ref)
    assert row['run_id'] == 'KEN58SH9SLZ6'
    if row['chosen']['action'] == 'use_potion':
        actions.append({**ref, 'floor': row['floor'], 'turn': row['turn'],
                        'chosen': row['chosen'], 'result': row['result'], 'rationale': row['rationale']})
assert len(actions) == 7
data['ken_potion_actions'] = actions
data['reader_correction'] = 'r1错误查询action.type；原日志实际为chosen.action。r1零计数不是缺日志或游戏反例。'
write('bounded-observations.json', data)

lamp = []
for check in data['checks']:
    if not ('首毒' in check['label'] or '首次萎靡' in check['label']):
        continue
    for ref in check['evidence']:
        row = load_raw(ref)
        relics = [r for r in row['state']['run']['relics'] if r['relic_id'] == 'UNSETTLING_LAMP']
        assert len(relics) == 1
        lamp.append({'evidence': ref, 'relic': relics[0]})
write('lamp-observed-fields.json', lamp)

selected = {275383, 275385, 275894, 275960, 277248, 277250, 277272, 277274}
decisions = []
with (OLD / 'evidence/decisions.evidence.jsonl').open('rb') as source:
    for encoded in source:
        if not any(('"line": ' + str(n) + ',').encode() in encoded[:180] for n in selected):
            continue
        envelope = json.loads(encoded)
        if envelope['line'] not in selected:
            continue
        ref = {k: envelope[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}
        row = load_raw(ref)
        assert row == envelope['row']
        decisions.append({'evidence': ref, **{k: row.get(k) for k in
                          ('floor', 'turn', 'sl_attempt', 'decision_id', 'chosen', 'rationale', 'answers', 'result')}})
assert len(decisions) == len(selected)
write('selected-decisions.json', decisions)
print(json.dumps({'ken_uses': len(actions), 'pending_receipts': sum(a['result'].startswith('pending') for a in actions),
                  'lamp_observed_frames': len(lamp), 'selected_decisions': len(decisions)}, ensure_ascii=False))

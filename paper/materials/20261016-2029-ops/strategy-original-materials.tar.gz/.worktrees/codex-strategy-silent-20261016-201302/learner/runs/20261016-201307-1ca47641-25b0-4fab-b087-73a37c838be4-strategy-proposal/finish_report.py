"""Write this batch's dispositions without changing production inputs or queue state."""
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
proposals = json.loads((HERE / 'proposals-input.json').read_text())
dispatch = json.loads((HERE / 'dispatch.json').read_text())
audit = json.loads((HERE / 'source-audit.json').read_text())
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)

details = [
    ('silent-proposal-08eaa60bcc449852',
     'KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1、T2/F15T1共七次饮用请求，三次接口仍pending；实际药栏变化另核，不能由pending直接判断失败。F5 states280255→280280为53→16；F15 states280347→280376为46→46，同时两瓶变空。',
     '缺F15不饮用及相同入口、后继下留药至Boss的完整成对结果，零净损且耗两药不能拟合持药价。',
     'F15零损不构成不用药也零损；F5获胜仍损37。保持现持药和饮用价值。'),
    ('silent-proposal-92920295a648b540',
     'TXZ6RVMQA09D A10 F48第2/3次T6同48HP/敌460，实损3/0、敌净扣36/27；decisions275383、275385保留替换说明。第三次首胜剩4，F49 states281565→281566为4→0，敌111未伤、出牌0。',
     '缺保持抽序、生成牌、药栏和后续选择一致的连续两战替线与联合校准，少损3也少伤9不证明通关改善。',
     '当前连战已传递真实资源；原低可信1200样本不充必死证明，也不把F49没有SL认作违规。'),
    ('silent-proposal-a327449c331efbc1',
     'WQZVENQ7DTRP A10 F33第2/3次T9 states282075/282144指纹相同、26HP/敌184；相邻轮实损13/22、敌净扣24/39。第2/6次T7实损0/4、同净扣24，原提案沙坑4→5。',
     '缺攻击、格挡与沙坑两条边界的受控整战后继和独立验证，不能将9血换15伤拟成固定阈值或改SL门槛。',
     'T7额外付4血具有延时收益，是反对一律只保血的约束；内部先致死来源仍未知。'),
    ('silent-proposal-a099e89437e942bb',
     'WQZVENQ7DTRP A10 F33T11第五次8手连饮添2/0/0、末次5手添3/2/0。当前固定夹具十八次饮用的原始前后帧逐字节核，手位/生成/HP/能量吻合。其余八局均核角色，原九局42饮统计不冒称本批重新全量分析。',
     '生成及穿插子模型已有live源码祖先；缺计划妥当保留容量、跨重问完整候选派发及SL恢复的联合消费者校准，不能关闭整项。',
     '满手耗瓶不是生成反例；现模型限silent A7/A9/A10，未观察组合与未实打穿插胜线不外推。'),
    ('silent-proposal-47910f82a1fdd98f',
     'TXZ6RVMQA09D A10 F43/45/46/48/49五组原始前后帧均在出牌前净失4，F49为4→0；WQ F33T9攻防血价与T7沙坑反例分别保留。',
     '王室猛毒开场与连战传递已有受限实现；缺未知回血/复活组合顺序和留药、路线、SL受控整战后继及联合资源校准。',
     '旧小血瓶组合净2不能拆成单件规则；开场仅新模拟战扣，现场T1与SL恢复不再扣一次。'),
    ('silent-proposal-f1374df72d8e6a25',
     '1913SE84AXQF A10 F29 states282723→282744为61→46，F31 states282755以46入场、带虚弱及复制药，T4死亡。Q6M2Y34MWKRE A10 F8 states282872→282906为57→2，F9 states282913→282921为2→0。',
     '缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果，不能据低信心候选拟新权重。',
     'Q6已选择休息且最终喝药；F5/F6零损留药与F2早喝未执行候选分开，不推早喝必胜。'),
    ('silent-proposal-38a49e6c97f31eea',
     'Q6M2Y34MWKRE A10 F8T4 states282887—282892敌血103→95→85→85→83→80；选择页85，弃牌完成才83，再结3毒。1913 F31弃磨蚀/再生/反伤沿原证据，候选与实际结算分源。',
     '普通紧勒受限公式已有live源码祖先；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准及受控整战后继。',
     '已核普通无挡链不外推升级/叠层/有挡；当前求解器遇弃牌未决阻断续步，公式相符不等于候选完整执行。'),
    ('silent-proposal-ef0e38a5dbd3bc07',
     '1913SE84AXQF A10 F29胜后46进入F31，Q6M2Y34MWKRE A10 F8胜后2进入F9且死亡；原提案F24锻造、F28实际回血与未抵达F32未来火分开。',
     '缺另一营火、事件、路线及用药时机的受控完整结果，两条观察性失败链不足校准路线或终局权重。',
     '1913计划条件由回血变锻造，不作同条件模型误差；未抵达的火与未建能力不能当已到账资源。'),
    ('silent-proposal-7f820c02d39bfaea',
     'NHA2KW0RB7VP A10 F33第1/5/6次T1，以实际可操作30HP、敌总408为起点；相邻轮1/7/7损血、8/24/24敌净扣。decisions277248/277250/277272/277274显示弃牌后重新规划，首题含精确切击不能直接认证完整执行。',
     '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继，六次失败仅一个独立局。',
     '开场原始28HP/敌428是效果前帧；使用states283391可操作帧，不能将开场20敌净扣归牌伤。'),
    ('silent-proposal-04b6b430759815ed',
     'NHA2KW0RB7VP A10 F17T1 states283146→283147毒0→10；F33T1 states283395首次萎靡实−2力/2弱。本批三帧油灯对象仅index/id/name/description/stack/is_melted，未暴露首次消费标志。K367 A1、SADL A7仍只按原提案限定现场，不把三个局部帧冒称17窗口全核。',
     '蟹朝向取整子实现已有live源码祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入与未覆盖X值/升级组合、能力整战后继。',
     '仅持有油灯不足确定本题首次效果可用；本次不添加默认翻倍。数据库按当前进阶取基伤的既有朝向分支保持。'),
]
assert [d[0] for d in details] == dispatch['proposal_ids']

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-201302-strategy-proposal',
          'base': audit['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'],
          'implementation_domains': ['combat', 'potion', 'sl', 'terminal'],
          'proposal_results': [{'id': ident, 'state': 'waiting', 'reason': reason} for ident, _, reason, _ in details],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 静默猎手策略提案本批复核

记录：{stamp}；batch=20261016-201302-strategy-proposal。
完整基线：{audit['base']}。开工git status干净；普通任务执行git merge --no-edit main，结果Already up to date。
learn.json本批为task=strategy-proposal/character=silent/reason=proposal、十项proposal_ids，与本工作树精确匹配；没有research_request、implementation_request、proposal_repair，不承接其他专题。普通匹配文件绑定20261010-150327，故不满足本批条件，也未读取另一专题。原dispatch保存在dispatch.json。

本批结论：十项均waiting。局部已实现源码、原始观察和缺失的整项验证分别列出；没有新增策略规则或知识结论、源码提交、合入、行为版本或shipped。code_proposals沿十个原CLI id，不建立重复提案。implementation_domains表示本批评估范围，并非新增实现。

派发十局保留原顺序；原提案另含1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR五局，全部先核runs.jsonl为silent。A1/A7/A9/A10分开，同局SL不作独立样本；未读其他角色私有知识。

## 证据保存与本批检查

十份原Markdown的SHA均匹配专用队列，并按原字节保存为silent-proposal-*.md.txt；角色、证据局和账本链接见proposal-audit.json。账本只筛本批涉及的31个id；ledger-input.json保存原始相关行，原claim与历史保留。

复用同十项前批通过共用extract_evidence.py生成的冻结封套，不重新复制大日志。原位置与每流source_size、计数、输出SHA在evidence-reuse-audit.json；本批对全部19,929行逐一seek原日志，核offset/bytes/SHA/JSON/显式身份。states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、runs15、fight-plans0。fight-plans为该截点零选中，不声称原日志缺失；原提取无效行states2/decisions2/brain1未作本局证据。

run-plans另用本工作树共用CLI、原8607652字节截点重提取到本目录evidence/，77行计数及输出SHA与原件完全相同；命令和退出码见extraction-command.json。旧报告、旧零行/失败初稿均未覆盖。其余七流使用已逐字节核验的原封套，完整路径保留，报告未假称新全量提取。

本批37项固定材料检查全部通过：五组开场/第二Boss死亡、同盘指纹、九个相邻轮血价/敌净扣、十八次狡诈生成、紧勒分帧和油灯局部效应。另核KEN七饮请求、其中三次pending，以及八条换线决策原文。bounded-observations.json、selected-decisions.json和observed-windows.json含逐行证据；这些是材料检查，不是生产测试、完整候选认证或受控整战收益。三帧油灯字段保存在lamp-observed-fields.json。

材料读取首稿错误把决策动作读为action.type，KEN计数为0；原bounded-observations-r1.json保留，supplement.py改读chosen.action后得到7。零计数来自读取器，不能当日志缺失/产品bug/游戏反例。一次只读定位沿原提案旧模块路径未找到，已用真实reflex路径复核，无生产改动。前批失败原件保持原位置，不冒称本批新增失败或重新运行其消费者。

## 当前源码与live边界

本批19个相关源码/固定测试叶与前批a73af7b4ee4839cfd2f54677b86ff5d610e29936全部同字节。核验时live={audit['live_head']}，14叶同字节、5叶仅历史Roy/Dai署名注释差，差异在base-live-source.patch；源码和实际live物理文件SHA见source-audit.json。未据19叶推断全部知识数据或历史dirty运行输入已复原。

- 狡诈6403fdcdadc803a092beb5165a068e22bf51c412、普通紧勒5c7105ff0294466da8319f2934beda05c6040794、蟹朝向ec29ea34b919344b707e57ba472ea210f9c39d62均为本基线及实际live祖先。狡诈同名侧支15ea09ad75a421d4bd65a820c187c8ee188186c8不是祖先，不能冒用。
- 连战e1a467e18a0dfa8d99046a24ff4c0e1af59278c8及接续5b56a452bb9be14d620b368ec46974c1b57901ca、66283dd9982bdd7f480da7a4d9bfefea0572a9ac，开场扩展ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8均为实际live祖先。受限开场组合与真实样本HP/剩药/复活传递存在，不能据此关闭所有组合/整战校准。
- SL资源比较1698adc96ba434a46942321e0237b70657e625b2为实际live祖先；字段明确current_turn_prediction/execution=unverified，随机药中位/缺线的差值为null。探索仍按notWorse/deathShare与原排名，当前资料不足改筛选门槛。
- 10c53de98c54b118660b8a478bbdedba548dd1c8为经验发布合并；是祖先不能代替油灯源码实现和消费者验收。现有固定测试仅只读核范围，本批没有重跑或借旧绿报新测试。

## 十项处置
'''
sections = []
for ident, evidence, reason, constraint in details:
    p = proposals[ident]
    sections.append(f'''### {ident}

原提案：{p['proposal']}；SHA256：{p['proposal_sha256']}。
来源任务：{p['source_task']}；实现任务：strategy-proposal；关联账本：{', '.join(p['ledger'])}。

证据：{evidence}

反例/限制与预期行为：{constraint}

处置：waiting。{reason}

验证方法：只在原提案所列角色/进阶/组合内逐帧复算，记录完整动作、选择完成和资源接续；涉及新价值或排序参数，按独立run及开始时间前后切分，SL归同一run。需要的受控后继或新独立局仍缺，不从本批同时拟合并冒称样本外验证。证据充分后按原授权独立提交、自测与live流程；本批保留现行为，无实际变更可回退，后续回退仅撤对应源码提交并保留原日志/账本/失败历史。
''')
ending = '''
## 记录与交付

只经根learner/ledger.py update给31个既有id补本批proposal/report的where.proposal及note，by=learner:strategy-proposal；不重复写历史复盘，不新增support/repeat，不改claim、首证、prior、evidence、status/version/shipped，不把旧shipped条目降回proposed。没有新经验可新增为proposed，也不直接写专用队列；本批proposal_results交原调度器处理waiting。

无源码或知识数据修改，因此撤源码失败/恢复通过、tsc、vitest均未运行，tests三个值均null；37项材料检查不填生产cases。没有代码提交，提交前gitleaks及live合前/合后测试不适用；没有空合并、eval号、上线双通知或shipped。merge=live在没有源码改动时不执行，不冒报合入。

本批没有运行play、boss模拟、LLM、网络或安装依赖；没有修改其他角色、运维prompt、根请求、原提案或历史失败。历史dirty源码和全部knowledge未复原，原17油灯窗/9局42饮等只按原提案引用，不冒本批全量校准。运行模型、推理强度及服务档无法由本任务现有只读证据独立核实，未修改运行配置或另开会话。

未发现足以新增、推翻或强行支持旧游戏结论的本批反证；材料读取错误单列。本报告不关闭父学习要求，实际经验入库、消费者采用和收益仍沿原owner后续验收。

运维交付：本目录proposal.md、report.md、result.json。逐项waiting理由及完整40位base见result.json；实际已存在的窄源码祖先仅作范围核对，不登记本批implemented/duplicate/shipped。
'''
(HERE / 'report.md').write_text(intro + '\n'.join(sections) + ending)
(HERE / 'proposal.md').write_text('# 本批十项策略提案处置\n\n' + f'记录：{stamp}；角色silent；batch=20261016-201302-strategy-proposal。\n\n'
                                 + '原提案、证据、账本、反例、预期行为、验证与回退逐项如下；十项均waiting，不建立重复提案，不改生产规则。完整来源核验见report.md。\n\n'
                                 + '\n'.join(sections))
updates = []
for ident in sorted({i for p in proposals.values() for i in p['ledger']}):
    links = [p['id'] for p in proposals.values() if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261016-201302-strategy-proposal只补追溯：' + ','.join(links)
                            + '均waiting；原始证据封套19929行逐字节核验、37材料检查通过。完整候选及受控后继缺口见报告；不新增游戏结论、support/repeat、源码、测试或shipped。'})
(HERE / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates))
print(json.dumps({'proposal_results': len(details), 'ledger_links': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

"""Verify preserved evidence against raw bytes and derive bounded observations."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
OLD = ROOT / '.worktrees/codex-strategy-silent-20261016-183355-s2/learner/runs/20261016-183402-78b0a6f4-a001-4b68-96d7-c78e04d94be3-strategy-proposal'
sys.path.insert(0, str(WORK / 'learner'))
from extract_evidence import run_identity


def write(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])


def ref(envelope):
    return {k: envelope[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def compact(envelope):
    state = envelope['row']['state']
    run, combat = state.get('run') or {}, state.get('combat') or {}
    player = combat.get('player') or {}
    return {**ref(envelope), 'floor': run.get('floor'), 'screen': state.get('screen'),
            'turn': state.get('turn'), 'hp': player.get('current_hp', run.get('current_hp')),
            'energy': player.get('energy'), 'block': player.get('block'),
            'played': player.get('cards_played_this_turn'), 'powers': player.get('powers', []),
            'hand_count': len(combat.get('hand', [])), 'potions': run.get('potions', []),
            'enemies': [{k: e.get(k) for k in ('enemy_id', 'current_hp', 'powers', 'move_id', 'intents')}
                        for e in combat.get('enemies', [])]}


proposals = json.loads((HERE / 'proposals-input.json').read_text())
run_rows = json.loads((HERE / 'runs-identity.json').read_text())
runs = {r['run_id'] for r in run_rows}
for r in run_rows:
    assert str(r.get('character', '')).lower() == 'silent'
proposal_audit = []
for ident, p in proposals.items():
    path = Path(p['proposal'])
    raw = path.read_bytes()
    assert sha(raw) == p['proposal_sha256']
    (HERE / (ident + '.md.txt')).write_bytes(raw)
    proposal_audit.append({'id': ident, 'source': str(path), 'sha256': sha(raw),
                           'ledger': p['ledger'], 'runs': p['runs']})
write('proposal-audit.json', proposal_audit)

manifest = json.loads((OLD / 'evidence/evidence-manifest.json').read_text())
audit = []
states, by_time = {}, {}
decisions = []
for stream in manifest:
    name = stream['stream']
    source = ROOT / 'logs' / (name + '.jsonl')
    preserved = OLD / 'evidence' / (name + '.evidence.jsonl')
    digest, counts = hashlib.sha256(), collections.Counter()
    assert set(stream['counts']) == runs
    assert source.stat().st_size >= stream['source_size']
    with source.open('rb') as raw, preserved.open('rb') as envelopes:
        for encoded in envelopes:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['run_id'] in runs and run_identity(item['row']) == item['run_id']
            assert item['source'] == str(source)
            assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= stream['source_size']
            raw.seek(item['offset'])
            original = raw.read(item['bytes'])
            assert sha(original) == item['sha256'] and json.loads(original) == item['row']
            counts[item['run_id']] += 1
            if name == 'states':
                character = (item['row']['state'].get('run') or {}).get('character_id')
                assert character is None or character.lower() == 'silent'
                states[item['line']] = item
                for key in ('ts', 'observed_ts'):
                    if item['row'].get(key):
                        by_time[(item['run_id'], item['row'][key])] = item
            elif name == 'decisions':
                decisions.append(item)
    assert digest.hexdigest() == stream['output_sha256']
    assert {run: counts[run] for run in runs} == stream['counts']
    audit.append({**stream, 'preserved_envelopes': str(preserved), 'raw_rows_verified': sum(counts.values()),
                  'verification': 'offset/bytes/SHA256/JSON/explicit identity'})
write('evidence-reuse-audit.json', audit)

# Re-extract the original plan cutoff through the shared entry, preserving old output.
plan = next(s for s in manifest if s['stream'] == 'run-plans')
args = [sys.executable, str(WORK / 'learner/extract_evidence.py'), '--logs', str(ROOT / 'logs'),
        '--output', str(HERE / 'evidence'), '--runs', ','.join(sorted(runs)),
        '--streams', 'run-plans', '--source-size', str(plan['source_size'])]
result = subprocess.run(args, capture_output=True, text=True)
(HERE / 'extract-plans.stdout.json').write_text(result.stdout)
(HERE / 'extract-plans.stderr.txt').write_text(result.stderr)
assert result.returncode == 0
new_plan = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())[0]
assert new_plan == plan
write('extraction-command.json', {'argv': args, 'exit_code': result.returncode,
                                  'old_cutoff_and_envelopes_identical': True})

checks = []


def check(label, actual, expected, items):
    entry = {'label': label, 'actual': actual, 'expected': expected, 'pass': actual == expected,
             'evidence': [ref(item) for item in items]}
    checks.append(entry)
    assert entry['pass'], entry


def player(line):
    return states[line]['row']['state']['combat']['player']


def enemies(line):
    return states[line]['row']['state']['combat']['enemies']


def power(enemy, ident):
    return next((p['amount'] for p in enemy.get('powers', []) if p['power_id'] == ident), 0)


for floor, before, after in [(43, 281312, 281313), (45, 281338, 281339), (46, 281367, 281368),
                             (48, 281399, 281400), (49, 281565, 281566)]:
    check(f'TXZ F{floor} 出牌前净失4',
          [player(before)['current_hp'] - player(after)['current_hp'], player(after)['cards_played_this_turn']],
          [4, 0], [states[before], states[after]])
check('TXZ F49 开场归零且敌未伤', [player(281566)['current_hp'], enemies(281566)[0]['current_hp']],
      [0, 111], [states[281565], states[281566]])
check('WQ 第2/3次T9指纹同一', states[282075]['row']['fingerprint'] == states[282144]['row']['fingerprint'],
      True, [states[282075], states[282144]])

targets = {'KEN58SH9SLZ6': [5, 15, 17], 'TXZ6RVMQA09D': [48, 49], 'WQZVENQ7DTRP': [33],
           '1913SE84AXQF': [17, 29, 31], 'Q6M2Y34MWKRE': [2, 8, 9], 'NHA2KW0RB7VP': [17, 33]}
windows = []
for run, floors in targets.items():
    for floor in floors:
        rows = [compact(item) for item in states.values() if item['run_id'] == run]
        rows = [r for r in rows if r['floor'] == floor and r['enemies']
                and r['screen'] in ('COMBAT', 'CARD_SELECTION', 'GAME_OVER') and type(r['turn']) is int]
        attempts, last = [], None
        for row in rows:
            if last is None or row['turn'] < last:
                attempts.append({})
            attempts[-1].setdefault(row['turn'], {'first': row, 'last': row})['last'] = row
            last = row['turn']
        for number, turns in enumerate(attempts, 1):
            windows.append({'run_id': run, 'floor': floor, 'observed_attempt': number, 'turns': turns})
write('observed-windows.json', windows)

for run, floor, attempt, turn, expected in [
    ('TXZ6RVMQA09D', 48, 2, 6, [3, 36]), ('TXZ6RVMQA09D', 48, 3, 6, [0, 27]),
    ('WQZVENQ7DTRP', 33, 2, 9, [13, 24]), ('WQZVENQ7DTRP', 33, 3, 9, [22, 39]),
    ('WQZVENQ7DTRP', 33, 2, 7, [0, 24]), ('WQZVENQ7DTRP', 33, 6, 7, [4, 24]),
    ('NHA2KW0RB7VP', 33, 1, 1, [1, 8]), ('NHA2KW0RB7VP', 33, 5, 1, [7, 24]),
    ('NHA2KW0RB7VP', 33, 6, 1, [7, 24]),
]:
    window = next(w for w in windows if (w['run_id'], w['floor'], w['observed_attempt']) == (run, floor, attempt))
    start, end = window['turns'][turn]['first'], window['turns'][turn + 1]['first']
    if (run, floor, attempt, turn) == ('NHA2KW0RB7VP', 33, 1, 1):
        start = compact(states[283391])
    actual = [start['hp'] - end['hp'], sum(e['current_hp'] for e in start['enemies']) - sum(e['current_hp'] for e in end['enemies'])]
    check(f'{run} F{floor} 第{attempt}次T{turn} 相邻轮HP损/敌净扣', actual, expected,
          [states[start['line']], states[end['line']]])

for fixture in json.loads((WORK / 'agent/tests/silent-cunning-evidence.json').read_text()):
    a = by_time[(fixture['run'], fixture['before_ts'])]
    b = by_time[(fixture['run'], fixture['after_ts'])]
    ca, cb = a['row']['state']['combat'], b['row']['state']['combat']
    added = sum(c['card_id'] == 'SHIV' for c in cb['hand']) - sum(c['card_id'] == 'SHIV' for c in ca['hand'])
    check('狡诈实饮手位/生成/HP/能量',
          [len(ca['hand']), len(cb['hand']), added, cb['player']['current_hp'] - ca['player']['current_hp'],
           cb['player']['energy'] - ca['player']['energy']],
          [fixture['before'], fixture['after'], fixture['added'], 0, 0], [a, b])

q6 = [282887, 282888, 282889, 282890, 282891, 282892]
check('Q6 F8T4紧勒与弃牌完成顺序', [enemies(n)[0]['current_hp'] for n in q6],
      [103, 95, 85, 85, 83, 80], [states[n] for n in q6])
check('NHA F17首毒实建10', [power(enemies(n)[0], 'POISON_POWER') for n in [283146, 283147]],
      [0, 10], [states[283146], states[283147]])
check('NHA F33首次萎靡实减力2/弱2', [power(enemies(283395)[0], p) for p in ['STRENGTH_POWER', 'WEAK_POWER']],
      [-2, 2], [states[283395]])
ken_potions = [ref(d) | {'action': d['row'].get('action'), 'floor': d['row'].get('floor'),
                         'turn': d['row'].get('turn')} for d in decisions
               if d['run_id'] == 'KEN58SH9SLZ6' and d['row'].get('action', {}).get('type') == 'use_potion']
write('bounded-observations.json', {'checks': checks, 'ken_potion_actions': ken_potions,
                                  'scope': '原始状态及相邻轮端点；没有认证完整候选或受控整战收益'})

old_source = json.loads((OLD / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = subprocess.check_output(['git', '-C', str(ROOT / '.worktrees/live'), 'rev-parse', 'HEAD']).decode().strip()
source_audit = {'base': base, 'prior_base': old_source['base'], 'live_head': live, 'paths': [], 'ancestor_checks': []}
paths = [r['path'] for r in old_source['paths']]
for path in paths:
    ours = (WORK / path).read_bytes()
    before = git('show', old_source['base'] + ':' + path)
    live_commit = git('show', live + ':' + path)
    live_physical = (ROOT / '.worktrees/live' / path).read_bytes()
    source_audit['paths'].append({'path': path, 'base_sha256': sha(ours), 'prior_sha256': sha(before),
                                  'live_sha256': sha(live_commit), 'live_physical_sha256': sha(live_physical),
                                  'same_prior': ours == before, 'same_live': ours == live_commit,
                                  'live_physical_matches_head': live_commit == live_physical})
for item in old_source['ancestor_checks']:
    commit = item['commit']
    source_audit['ancestor_checks'].append({'commit': commit, 'subject': item['subject'],
        'base_ancestor': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
        'live_ancestor': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, live]).returncode == 0})
(HERE / 'prior-base-source.patch').write_bytes(git('diff', '--binary', old_source['base'], base, '--', *paths))
(HERE / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
write('source-audit.json', source_audit)
print(json.dumps({'verified_envelopes': sum(a['raw_rows_verified'] for a in audit),
                  'material_checks': len(checks), 'all_passed': all(c['pass'] for c in checks),
                  'source_leaves': len(paths), 'same_prior': sum(p['same_prior'] for p in source_audit['paths']),
                  'same_live': sum(p['same_live'] for p in source_audit['paths']), 'base': base, 'live': live}, ensure_ascii=False))

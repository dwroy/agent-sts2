import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WORKTREE = OUT.parents[2]
prefix = json.loads((OUT / 'ledger-prefix-before.json').read_text())
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
raw = ledger_path.read_bytes()
assert hashlib.sha256(raw[:prefix['bytes']]).hexdigest() == prefix['sha256']
requested = [json.loads(line) for line in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
by_id = {row['id']: row for row in requested}
appended = []
offset = prefix['bytes']
for line in raw[prefix['bytes']:].splitlines(keepends=True):
    row = json.loads(line)
    if row.get('id') in by_id and row.get('note') == by_id[row['id']]['note']:
        expected = by_id[row['id']]
        assert row['op'] == 'update'
        assert {key: row[key] for key in expected} == expected
        assert set(row) == set(expected) | {'op', 'ts'}
        appended.append({'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert len(appended) == len(requested) == 26
assert {row['row']['id'] for row in appended} == set(by_id)
(OUT / 'ledger-appended-rows.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in appended))

spec = importlib.util.spec_from_file_location('batch_ledger', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
fold = module.fold(module.read_rows(str(ledger_path)))
before = json.loads((OUT / 'ledger-immediate-before.json').read_text())
protected = ['character', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped', 'effect']
for ident in by_id:
    assert all(before[ident].get(key) == fold[ident].get(key) for key in protected), ident
    for where, paths in by_id[ident]['where'].items():
        assert all(path in fold[ident]['where'][where] for path in paths)
(OUT / 'ledger-update-readback.json').write_text(json.dumps({
    'cli_exit_code': 0, 'updates': len(appended), 'old_physical_prefix_unchanged': True,
    'protected_fields_unchanged': True, 'only_trace_links_and_notes': True,
}, ensure_ascii=False, indent=2) + '\n')

result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert result['base'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORKTREE, text=True)
assert not status
assert subprocess.check_output(['git', 'diff', '--binary', result['base']], cwd=WORKTREE) == b''
assert subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=WORKTREE) == b''
assert set(dispatch['proposal_ids']) == set(result['code_proposals']) == {row['id'] for row in result['proposal_results']}
assert all(row['state'] == 'waiting' and row['reason'] and 'commit' not in row for row in result['proposal_results'])
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == []
assert Path(result['report']) == OUT / 'report.md'
assert all((OUT / name).is_file() for name in ['report.md', 'proposal.md', 'gitleaks.json'])
assert json.loads((OUT / 'gitleaks.json').read_text()) == []
sources = json.loads((OUT / 'source-verification.json').read_text())
assert len(sources['paths']) == 20 and all(row['same_prior_base'] for row in sources['paths'])
live = subprocess.check_output(['git', '-C', str(ROOT / '.worktrees/live'), 'rev-parse', 'HEAD'], text=True).strip()
assert all(subprocess.run(['git', 'merge-base', '--is-ancestor', row['commit'], live], cwd=WORKTREE).returncode == 0 for row in sources['ancestry'])
verification = {
    'base': result['base'], 'head_equals_base': True, 'tracked_worktree_clean': True,
    'index_clean': True, 'source_and_knowledge_diff': False, 'all_ten_proposals_accounted_for': True,
    'original_proposals_sha256_matched': True, 'evidence_rows_verified': 6995, 'fact_checks_passed': 37,
    'ledger_updates_read_back': 26, 'gitleaks_exit_code': 0, 'production_tests': result['tests'],
    'current_live_snapshot': live, 'eight_existing_sources_still_live_ancestors': True,
    'report_sha256': hashlib.sha256((OUT / 'report.md').read_bytes()).hexdigest(),
    'proposal_sha256': hashlib.sha256((OUT / 'proposal.md').read_bytes()).hexdigest(),
    'result_sha256': hashlib.sha256((OUT / 'result.json').read_bytes()).hexdigest(),
}
(OUT / 'final-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(verification, ensure_ascii=False))

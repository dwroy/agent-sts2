# 本批十项策略复核与处置

记录时间：2026-10-16 15:11:00 CST。角色silent；已观察进阶A10；批次20261016-150316-strategy-proposal。

只处理本批十个原CLI id，不新增提案、不改原提案或经验。八流6995原行与上一批选中字节相同；本批37项原帧断言通过，不作为新独立支持或生产策略测试。

## silent-proposal-89354805ee4d7e77

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。
账本：silent-0237, silent-0238；来源任务：postmortem；实现任务：strategy-proposal。
证据局/层/回合：VLZ6CCT8AQ0A F35/F43 T1、F45 T1。
本批核验：F35神化7→5能量；已见防御5→8、打击7→10、匕首雨每段5→7、必备工具1→0费。F43同序列前后预测43伤/损14与51伤/损13；F45持有但未施放。
反例与限制：F43打出后仍损57；F45未施放不是升级机制反例，不能推出必打或整战胜线。
预期行为与验证：把持有、候选模拟与本战实际施放分列；按原动作和尝试身份追踪升级，未知组合保持未知。
处置：waiting。缺跨抽牌、选牌、药水、重规划、SL和换战的实际施放持续身份，以及剩余升级交互校准；已有升级传播不能关闭整项。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-f2bfceddb1898dca

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。
账本：silent-0106, silent-0019, silent-0201；来源任务：postmortem；实现任务：strategy-proposal。
证据局/层/回合：VLZ6CCT8AQ0A F45 T1/T4/T5、F43—44。
本批核验：F45首题药水MC 1/12样本、707ms；rollout horizon=1、samples=1、best=null。实用药能量1→2、HP67不变。末轮32血20挡对显示59攻击。
反例与限制：F17/F33首试获胜；T4未选攻击线未实打，全败并列不等于确定同死率或另一目标必胜。
预期行为与验证：先验证成熟度和资源事实；预算配对必须固定完整输入和相同资源约束，不拟合新常量。
处置：waiting。缺完整模型下同起点、同随机池、同总预算的MC分配配对、候选稳定性曲线及留药后继；不能由两次不同指纹题改预算或药价。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-283a164780d11e69

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。
账本：silent-0237, silent-0238；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：VLZ6CCT8AQ0A F35/F43 T1、F45 T1。
本批核验：与89354805ee4d7e77同源，原experience-update链保留；已见升级对及未施放边界不另计独立样本。
反例与限制：持有神化不等于本战已施放；不得用F35与F45不同敌人、牌序和资源比较证明胜负因果。
预期行为与验证：沿原神化提案去重核验，补实际施放归属及已覆盖/未知升级边界，不新建重复id。
处置：waiting。同源神化经验链仍缺本战实际施放持续身份和剩余升级交互校准；局部live实现不足以将整项标duplicate。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-ebbfe3b97548756d

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。
账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：VLZ6CCT8AQ0A F43 T1—5、F45 T3—5、F44。
本批核验：已证属性、升级、毒触发、现场覆甲分源；末轮PLATING为0，32血20挡对59；F43赢战资源消耗和F44净回必须接续记账。
反例与限制：胜局仍可大量耗血；未建两张毒雾不能预支为群体输出，未击杀目标不能算已退场。
预期行为与验证：在固定状态逐源验证机制与期限，再核消费者；不新增统一权重、固定路线或目标顺序。
处置：waiting。缺十五子项的属性/升级组合、状态期限以及战斗、路线、休息消费者的逐源联合校准；局部模型不能代替整项验收。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-e5b87be50f28f311

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。
账本：silent-0079, silent-0021, silent-0125, silent-0018；来源任务：postmortem；实现任务：strategy-proposal。
证据局/层/回合：8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11；F17 T6。
本批核验：d270216/270282指纹逐字相同；第三试原/替线死亡样本0/24与5/24有别。已保存消费者端点为损3/15、敌净扣10/17。护栏候选差与实际执行分列。
反例与限制：末试更防御的路径活至T11仍死，不能一律否定或赞成保血；六试只是一局。
预期行为与验证：保留原答、护栏、SL与派发阶段，实际端点和预测分列；抽牌或重规划后停止完整执行认证。
处置：waiting。缺跨重规划持续候选身份、完整执行认证及能力成长逐源归属；已有单动作回执和113候选段不能认证完整方案或改SL血价。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-49632bc4878fb597

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。
账本：silent-0005, silent-0231；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：CA5KE8GFJ9X2 F13 T1/T3/T5。
本批核验：蚌力量0/4/8、同招11/15/19；虚弱后显示11/14。末轮2血10挡对14，实际血量归零截断。
反例与限制：虚弱没有取消后续加压；计划中的步法未取得，不能把负面结果解释为已验证正敏捷收益。
预期行为与验证：冻结当前进阶HP/招式、属性与牌面输入逐步校准；保留未知覆甲减层条件。
处置：waiting。本局无正敏捷实测；缺逐击力量、正负敏捷、虚弱和独立成长四路径的同次冻结生产校准，不新增统一保血/输出权重。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-66532328a585941f

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。
账本：silent-0021, silent-0009；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：5PM6JAQG6FNQ F39 第二试T2；F33 T1—2。
本批核验：s274379→274380向无毒失落打冒泡能量5→4，敌HP35不变且仍0毒；玩家HP29。F33已建能力的胜战不是同起点对照。
反例与限制：同局F33与F39的敌人和组件不同，不把前者成功当作后者另一路线必胜。
预期行为与验证：保留持有/计划/建立三种事实；任何构筑或启动权重先做完整资源与后继对照。
处置：waiting。缺同HP、牌组、药水及完整抽序下不同启动顺序的受控整战结果和收益函数；无毒冒泡局部无效不足以拟合启动权重。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-43a76a31ba7bdcfa

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。
账本：silent-0030, silent-0027；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：61E2QS63Y9WU F17 T5—7。
本批核验：T6玩家DEXTERITY=-2，双防御显示各3；族母HP67→34端点包含17+16毒，吸取与覆甲现场分开。
反例与限制：本局首试七轮获胜；不能将别局重打结果搬成这局反事实，毒端点也不单独认证全部来源。
预期行为与验证：分项验证吸取、负敏捷、覆甲与毒，再独立验证换线规则，现有SL条件保持。
处置：waiting。缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继；首试胜利和毒端点不足以修改SL范围或阈值。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-5264153a4a4b0e5c

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。
账本：silent-0039, silent-0209；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：61E2QS63Y9WU F23 T3—5。
本批核验：两次航行后的实体力量3/3→6/6；T4本体/幻象HP76/14→41/2，玩家25→10，幻象仍未退场。
反例与限制：focus幻象的39伤零损线没有实打；已选本体线47伤/损15兑现不证明另一顺序整战更优。
预期行为与验证：逐实体核召唤、成长和退场，保留全部目标；相同推演值并列，不指定首杀。
处置：waiting。缺A10召唤、航行成长、退场和复现的全链冻结生产校准，以及另一focus的完整后继；局部源码不支持固定杀序。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。

## silent-proposal-bddfa690a84e03d0

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。
账本：silent-0128, silent-0079；来源任务：experience-update；实现任务：strategy-proposal。
证据局/层/回合：DUZUBAJ3A8GP F30 末试T4—6。
本批核验：末试T5力量2→尖啸后-4；下一轮恢复并成长至4，攻击20→14→22。睡眠、醒来、临时减力与成长分别记录。
反例与限制：末试T4相较首试多扣3敌血也多损2玩家血；不能只按敌血解释排序或推未选胜线。
预期行为与验证：按当前进阶与实测后继分别校准睡眠、眩晕、恢复和成长，不从四次SL推独立胜率。
处置：waiting。缺伤害唤醒、眩晕接续、当前进阶成长的全链生产校准和同抽换序后继；四次相关失败不足以拟合血价或固定杀序。
样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。
回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。


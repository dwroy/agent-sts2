import ast
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PRIOR = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-134302/learner/runs/20261016-134308-f93a11c6-33bb-43eb-8be9-dbc6ddc1ae6c-strategy-proposal')

# Reuse the preserved read-only audit, with this batch's explicit output root.
run_rows = [json.loads(line) for line in (OUT / 'evidence/runs.evidence.jsonl').read_text().splitlines()]
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert {row['run_id'] for row in run_rows} == set(dispatch['runs'])
identities = {row['run_id']: row['row'] for row in run_rows}
assert len(identities) == len(run_rows) == 6
assert all(row['character'] == 'SILENT' and row['ascension'] == 10 for row in identities.values())
(OUT / 'runs-identity.json').write_text(json.dumps(identities, ensure_ascii=False, indent=2) + '\n')
namespace = {'__file__': str(OUT / 'verify-materials.py'), '__name__': '__main__'}
source = (OUT / 'prior-verify-materials.original.txt').read_text()
exec(compile(source, str(OUT / 'prior-verify-materials.original.txt'), 'exec'), namespace)

# Derive every retained projection field again from the newly verified raw rows.
tree = ast.parse((OUT / 'prior-prior-verify-evidence.original.txt').read_text())
functions = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('power', 'snapshot')], type_ignores=[])
helpers = {}
exec(compile(functions, '<preserved-projection-functions>', 'exec'), helpers)
raw_rows = namespace['selected_rows']
projection_checks = []
keys = ['run_id', 'floor', 'turn', 'observed_ts', 'decision_id', 'label', 'sl_attempt', 'sl_reloads', 'chosen', 'expect', 'journal', 'result', 'answers', 'sl_explore', 'hp_guard', 'rationale']
for name, stream in [('selected-state-facts.json', 'states'), ('selected-decision-facts.json', 'decisions')]:
    values = json.loads((OUT / name).read_text())
    for value in values:
        item = raw_rows[stream][value['line']]
        if stream == 'states':
            actual = helpers['snapshot'](item)
        else:
            actual = {key: item['row'].get(key) for key in keys}
            actual.update({key: item[key] for key in ['line', 'offset', 'bytes', 'sha256']})
        assert actual == value, (name, value['line'])
    projection_checks.append({'path': name, 'fully_rederived_from_current_raw': True, 'records': len(values)})
(OUT / 'projection-verification.json').write_text(json.dumps(projection_checks, ensure_ascii=False, indent=2) + '\n')

# The factual checks read this batch's verified projections and preserved consumer material.
fact_source = (OUT / 'prior-check-facts.original.txt').read_text()
exec(compile(fact_source, str(OUT / 'prior-check-facts.original.txt'), 'exec'), {'__file__': str(OUT / 'check-facts.py'), '__name__': '__main__'})

current = json.loads((OUT / 'raw-readback-verification.json').read_text())
assert all(meta['same_selected_bytes_as_prior'] for meta in current['streams'])
old_meta = json.loads((PRIOR / 'evidence/evidence-manifest.json').read_text())
new_meta = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
for new, old in zip(new_meta, old_meta):
    assert new['stream'] == old['stream']
    assert new['output_sha256'] == old['output_sha256']
(OUT / 'verification-summary.json').write_text(json.dumps({
    'verified_rows': current['total_rows'],
    'all_selected_streams_same_as_prior': True,
    'fact_checks': len(json.loads((OUT / 'fact-checks.json').read_text())),
    'projection_checks': projection_checks,
    'production_tests_run': False,
    'consumers_rerun': False,
}, ensure_ascii=False, indent=2) + '\n')
print('本批原始证据、投影、固定事实、旧消费者材料读回完成；未运行生产测试。')

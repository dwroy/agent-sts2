import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'selected-proposals.json').read_text())
sources = json.loads((OUT / 'source-verification.json').read_text())
checks = json.loads((OUT / 'verification-summary.json').read_text())
assert checks['verified_rows'] == 6995 and checks['fact_checks'] == 37
assert checks['all_selected_streams_same_as_prior']
timestamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True, cwd=REPO).strip()
assert base == sources['base']

items = [
    ('VLZ6CCT8AQ0A F35/F43 T1、F45 T1',
     'F35神化7→5能量；已见防御5→8、打击7→10、匕首雨每段5→7、必备工具1→0费。F43同序列前后预测43伤/损14与51伤/损13；F45持有但未施放。',
     '缺跨抽牌、选牌、药水、重规划、SL和换战的实际施放持续身份，以及剩余升级交互校准；已有升级传播不能关闭整项。',
     'F43打出后仍损57；F45未施放不是升级机制反例，不能推出必打或整战胜线。',
     '把持有、候选模拟与本战实际施放分列；按原动作和尝试身份追踪升级，未知组合保持未知。'),
    ('VLZ6CCT8AQ0A F45 T1/T4/T5、F43—44',
     'F45首题药水MC 1/12样本、707ms；rollout horizon=1、samples=1、best=null。实用药能量1→2、HP67不变。末轮32血20挡对显示59攻击。',
     '缺完整模型下同起点、同随机池、同总预算的MC分配配对、候选稳定性曲线及留药后继；不能由两次不同指纹题改预算或药价。',
     'F17/F33首试获胜；T4未选攻击线未实打，全败并列不等于确定同死率或另一目标必胜。',
     '先验证成熟度和资源事实；预算配对必须固定完整输入和相同资源约束，不拟合新常量。'),
    ('VLZ6CCT8AQ0A F35/F43 T1、F45 T1',
     '与89354805ee4d7e77同源，原experience-update链保留；已见升级对及未施放边界不另计独立样本。',
     '同源神化经验链仍缺本战实际施放持续身份和剩余升级交互校准；局部live实现不足以将整项标duplicate。',
     '持有神化不等于本战已施放；不得用F35与F45不同敌人、牌序和资源比较证明胜负因果。',
     '沿原神化提案去重核验，补实际施放归属及已覆盖/未知升级边界，不新建重复id。'),
    ('VLZ6CCT8AQ0A F43 T1—5、F45 T3—5、F44',
     '已证属性、升级、毒触发、现场覆甲分源；末轮PLATING为0，32血20挡对59；F43赢战资源消耗和F44净回必须接续记账。',
     '缺十五子项的属性/升级组合、状态期限以及战斗、路线、休息消费者的逐源联合校准；局部模型不能代替整项验收。',
     '胜局仍可大量耗血；未建两张毒雾不能预支为群体输出，未击杀目标不能算已退场。',
     '在固定状态逐源验证机制与期限，再核消费者；不新增统一权重、固定路线或目标顺序。'),
    ('8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11；F17 T6',
     'd270216/270282指纹逐字相同；第三试原/替线死亡样本0/24与5/24有别。已保存消费者端点为损3/15、敌净扣10/17。护栏候选差与实际执行分列。',
     '缺跨重规划持续候选身份、完整执行认证及能力成长逐源归属；已有单动作回执和113候选段不能认证完整方案或改SL血价。',
     '末试更防御的路径活至T11仍死，不能一律否定或赞成保血；六试只是一局。',
     '保留原答、护栏、SL与派发阶段，实际端点和预测分列；抽牌或重规划后停止完整执行认证。'),
    ('CA5KE8GFJ9X2 F13 T1/T3/T5',
     '蚌力量0/4/8、同招11/15/19；虚弱后显示11/14。末轮2血10挡对14，实际血量归零截断。',
     '本局无正敏捷实测；缺逐击力量、正负敏捷、虚弱和独立成长四路径的同次冻结生产校准，不新增统一保血/输出权重。',
     '虚弱没有取消后续加压；计划中的步法未取得，不能把负面结果解释为已验证正敏捷收益。',
     '冻结当前进阶HP/招式、属性与牌面输入逐步校准；保留未知覆甲减层条件。'),
    ('5PM6JAQG6FNQ F39 第二试T2；F33 T1—2',
     's274379→274380向无毒失落打冒泡能量5→4，敌HP35不变且仍0毒；玩家HP29。F33已建能力的胜战不是同起点对照。',
     '缺同HP、牌组、药水及完整抽序下不同启动顺序的受控整战结果和收益函数；无毒冒泡局部无效不足以拟合启动权重。',
     '同局F33与F39的敌人和组件不同，不把前者成功当作后者另一路线必胜。',
     '保留持有/计划/建立三种事实；任何构筑或启动权重先做完整资源与后继对照。'),
    ('61E2QS63Y9WU F17 T5—7',
     'T6玩家DEXTERITY=-2，双防御显示各3；族母HP67→34端点包含17+16毒，吸取与覆甲现场分开。',
     '缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继；首试胜利和毒端点不足以修改SL范围或阈值。',
     '本局首试七轮获胜；不能将别局重打结果搬成这局反事实，毒端点也不单独认证全部来源。',
     '分项验证吸取、负敏捷、覆甲与毒，再独立验证换线规则，现有SL条件保持。'),
    ('61E2QS63Y9WU F23 T3—5',
     '两次航行后的实体力量3/3→6/6；T4本体/幻象HP76/14→41/2，玩家25→10，幻象仍未退场。',
     '缺A10召唤、航行成长、退场和复现的全链冻结生产校准，以及另一focus的完整后继；局部源码不支持固定杀序。',
     'focus幻象的39伤零损线没有实打；已选本体线47伤/损15兑现不证明另一顺序整战更优。',
     '逐实体核召唤、成长和退场，保留全部目标；相同推演值并列，不指定首杀。'),
    ('DUZUBAJ3A8GP F30 末试T4—6',
     '末试T5力量2→尖啸后-4；下一轮恢复并成长至4，攻击20→14→22。睡眠、醒来、临时减力与成长分别记录。',
     '缺伤害唤醒、眩晕接续、当前进阶成长的全链生产校准和同抽换序后继；四次相关失败不足以拟合血价或固定杀序。',
     '末试T4相较首试多扣3敌血也多损2玩家血；不能只按敌血解释排序或推未选胜线。',
     '按当前进阶与实测后继分别校准睡眠、眩晕、恢复和成长，不从四次SL推独立胜率。'),
]
assert len(items) == len(proposals) == 10
results = []
proposal_text = ['# 本批十项策略复核与处置', '', f'记录时间：{timestamp}。角色silent；已观察进阶A10；批次20261016-150316-strategy-proposal。', '',
                 '只处理本批十个原CLI id，不新增提案、不改原提案或经验。八流6995原行与上一批选中字节相同；本批37项原帧断言通过，不作为新独立支持或生产策略测试。', '']
for row, (where, evidence, reason, counter, expected) in zip(proposals, items):
    results.append({'id': row['id'], 'state': 'waiting', 'reason': reason})
    proposal_text += [f"## {row['id']}", '', f"原提案：{row['proposal']}；SHA256={row['proposal_sha256']}。",
                      f"账本：{', '.join(row['ledger'])}；来源任务：{row['source_task']}；实现任务：strategy-proposal。",
                      f'证据局/层/回合：{where}。', f'本批核验：{evidence}', f'反例与限制：{counter}',
                      f'预期行为与验证：{expected}', f'处置：waiting。{reason}',
                      '样本和验证：只作发现样本内事实回归；SL尝试不扩局数；未来独立同角色局才可作时间后移验证。缺失的原dirty运行输入和未选后继不补造。',
                      '回退：本批无新生产代码；后续实现若修改行为，须以自己的源码提交撤回并保留原证据、红绿、自测和上线记录。', '']
(OUT / 'proposal.md').write_text('\n'.join(proposal_text) + '\n')

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} | 是 |" for m in manifest)
dispositions = '\n'.join(f"| {r['id']} | waiting | {r['reason']} |" for r in results)
report = f'''# 静默猎手本批策略处置报告

记录时间：{timestamp}；task=strategy-proposal；character=silent；batch=20261016-150316-strategy-proposal。

十项全部waiting。没有新的可校准策略缺口可由本批六局输入单独实现；现有窄实现已在live，原提案剩余要求仍缺持续执行归属、联合生产校准或受控整战后继。本批无源码/知识修改、新id、源码提交、live合入、游戏版本或shipped。fixes=[]，merged=null。没有把本批报告当学习入库父要求完成。

## 身份与基线

初始git status干净，已读README、STATE-2026-10-16、decision-log末尾、learning-protocol及learning-code-proposals。根learn.json仅取本批行，角色、工作树、六局和十proposal_ids匹配；reason=proposal，没有research_request、implementation_request、proposal_repair。普通专题文件绑定另一个旧批次，不承接专题或扩展领取。git merge --no-edit main返回Already up to date。base={base}，HEAD保持该提交。

六局runs.jsonl和全部选中状态均核为SILENT/A10，局号为{','.join(dispatch['runs'])}。SL不扩大独立局数。没有下级agent、其他角色私有知识、联网、LLM或游戏API调用，没有运行play。未改账号、模型、推理配置或运维prompt；实际原生模型与推理强度本批工具未独立核实，交宿主按原线程核验，不冒称已切换。

## 原始证据与本次核验

使用本工作树共用extract_evidence.py提取八流。6995原行逐offset/bytes/SHA256/JSON与显式所属身份读回通过；run/run_id/state.run_id/fingerprint.run冲突不收，正文提及不作所属局。每流冻结source_size。八流选中封套SHA与上一批原提取全部相同；原日志变长不是本六局新证据。

| 流 | source_size字节 | 所属行数 | 选中字节与旧封套相同 |
|---|---:|---:|---|
{table}

fight-plans当前截点0行只说明未选中，不断言原日志不存在。全源states/decisions各2条、brain1条无效行不归入本六局，无截断行。详见evidence/evidence-manifest.json、raw-readback-verification.json。

718状态和696决策投影重新从本次原行逐字段推导一致；37项固定事实断言通过；六个神化固定状态夹具逐状态和SHA匹配。支持十项的局/层/回合、账本、反例、拟验证行为及缺口逐项写入proposal.md。这些是材料核验，未运行生产tsc/vitest或新实现红绿。

六份既有离线消费者输入逐字段与本次原行匹配，输入/输出压缩与解码SHA及计数已复核；本批没有重跑消费者或模拟。保留既有3301有ID动作、476候选段、121整轮端点、413未知窗口，全部actual_full_candidate_result=null。CA5一行、61E一行、DUZU三行缺decision_id的旧完整输入拒收仍保留，原有界输出不替完整局通过。不能把这些材料当本批重新验证了策略收益或完整候选执行。

## 源码和已有实现

只读live快照={sources['live_snapshot']}。核20个相关源码路径：16个与本base逐SHA相同，card-model.ts、rollout-live.ts、sl/explore.ts、knowledge/move-model.ts的差异仅为历史Roy/Dai署名注释。与上一批基线逐文件对照及精确差分保存在source-verification.json、source-since-prior.patch与base-live差分；不假设旧dirty运行源码/知识已完整恢复。

八个窄源码提交均核为本base和实际live祖先：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17、b2805be4ba44b7375c7908d873889372cc3cfe6c、05cd292c6f01bb31e406473d3a9843e659d62b93、a8b1f8be153fe4f3a34146117546c2178f2e446b、cf72bd21148059f111f760cc98a727369e34a47e、ba23ca693151fa8c6f7fe035e640dc30f05ccd75、1698adc96ba434a46942321e0237b70657e625b2、772b839f8ada31664cb764ea9ad3bdb03da27f64。已有致命毒药5→7神化传播和SL资源审计不再报未上线。

当前silent-apotheosis-reference仍明确actual_cast_this_fight=null；selection_audit和单动作dispatch均不认证整方案；SL资源差额仍为current_turn_prediction、execution=unverified。因此不能把窄实现或源码祖先当十项全部implemented/duplicate，也不能从此修改SL阈值、药价、启动权重或固定杀序。

## 逐项处置

| id | 状态 | 具体缺口 |
|---|---|---|
{dispositions}

## 记录与完成边界

只经根learner/ledger.py update追加本批proposal/report追溯和waiting说明，by=learner:strategy-proposal；不新增support/repeat、不改旧claim、首证、prior、进阶、evidence、status、version或shipped，不倒退已有shipped条目。输入、CLI返回和物理追加读回单独保留；由宿主消费最终proposal_results，不手改learn.json、根请求、专用队列或原提案。不新增重复CLI id，code_proposals为本批原十项，implementation_domains=[]。

没有源码修改，撤源码失败/恢复通过不适用；tsc、vitest、cases均null。没有源码提交或live合入，不进入live锁、刷新提交、版本登记或规则双通知流程。没有新机制反证或意见分歧，不重复发学习通知或代其他角色ACK。曾按简写尝试读取缺失的旧报告路径，随后从原账本链接定位真实保留报告；没有据缺路径认定证据丢失。所有本批材料仅保存于任务scratch；最终HEAD/base、源码/知识/index及gitleaks材料扫描由final-verification.json另存实际结果。

交运维提案：{OUT / 'proposal.md'}。
报告：{OUT / 'report.md'}。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-150316-strategy-proposal',
          'base': base, 'runs': dispatch['runs'], 'fixes': [],
          'skipped': [{'id': r['id'], 'reason': r['reason']} for r in results], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [r['id'] for r in results], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

links = {ident: [r for r in results if ident in next(p for p in proposals if p['id'] == r['id'])['ledger']]
         for ident in sorted({i for p in proposals for i in p['ledger']})}
updates = [{'id': ident, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': '20261016-150316-strategy-proposal：八流6995原行逐字节及显式身份读回，37原帧事实通过；与上一批选中字节相同。' +
                    '；'.join(r['id'] + '=waiting：' + r['reason'] for r in linked) +
                    ' 仅追加追溯，不重复support/repeat，不改claim/首证/prior/evidence/status/version/shipped；无新源码、生产测试或live合入。'}
           for ident, linked in links.items()]
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'proposals': len(results), 'ledger_links': len(updates), 'report': str(OUT / 'report.md'), 'base': base}, ensure_ascii=False))

from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0738';pub=r/'paper/materials/20261016-0738-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def load(f):return json.loads(f.read_text())
def write(f,v):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
x=load(pub/'publication.json');base=git('rev-parse','HEAD').decode().strip();assert base==x['main'];assert x['source_actual_main_live_ancestor'] and x['release_increment'] is False
assert not (p/'own-appends.json').exists();assert not git('diff','--cached','--name-only').strip()
assert git('rev-parse','HEAD',cwd=r/'.worktrees/live').decode().strip()==x['live'];assert git('rev-parse','HEAD^{tree}',cwd=r/'.worktrees/live').decode().strip()==x['tree']
for path in x['source_paths']:
 for cwd in [r,r/'.worktrees/live']:assert sha((cwd/path['path']).read_bytes())==path['source_sha256']
assert set(git('diff','--name-only',x['old_main'],x['main']).decode().splitlines())=={v['path'] for v in x['source_paths']}
assert set(git('diff','--name-only',x['knowledge_refresh_commit'],x['live'],cwd=r/'.worktrees/live').decode().splitlines())=={v['path'] for v in x['source_paths']}
for entry in x['knowledge_refresh']:
 f=r/'.worktrees/live'/entry['path'];assert sha(f.read_bytes())==entry['sha256'];assert sha(git('show',x['live']+':'+entry['path']))==entry['sha256']
for cwd,head in [(r,x['old_main']),(r/'.worktrees/live',x['old_live'])]:
 assert git('show',head+':eval/versions.json',cwd=cwd)==git('show','HEAD:eval/versions.json',cwd=cwd)
 assert not git('diff','--cached','--name-only',cwd=cwd).strip()
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
hostlog=r/('ops/codex-ops/learner/'+x['batch']+'.fallback-'+x['tree']+'.checks.log');assert hostlog.exists()
raw=hostlog.read_bytes();(pub/'host-start-log-prefix.txt').write_bytes(raw)
# A single broker request has been submitted. Capture the observed stage without claiming completion or waiting for it.
host=dict(at=at,batch=x['batch'],source=x['source'],live=x['live'],tree=x['tree'],request_command='bash ops/codex-ops-do.sh learner-recheck '+x['batch'],requested_once=True,actual_log=str(hostlog.relative_to(r)),start_prefix=ref(pub/'host-start-log-prefix.txt'),vitest_RUN_observed=b'RUN' in raw,complete_exit=None,stage='single original exact-tree host check started; result pending its learner-checks event',source_full_not_repeated=True)
write(pub/'host-start-receipt.json',host)
f=r/'ops/codex-ops/pending-integrations/20261016-064301-route-provenance.json';old=load(f)
update=dict(at=at,state='deployed immutable three source leaves; host running original channel, natural log consumer pending',source=x['source'],main=x['main'],live=x['live'],tree=x['tree'],knowledge_refresh_commit=x['knowledge_refresh_commit'],knowledge_refresh_paths=10,source_actual_main_live_ancestor=True,release_increment=False,existing_release='V5-R366 unchanged',original_failed_rc0_mergednull=True,original_conflicts=19,wide_proposals='all ten waiting, broad learning/resource parents remain open',host_requested=True,host_result=None,host_receipt='paper/materials/20261016-0738-ops/host-start-receipt.json',publication_receipt='paper/materials/20261016-0738-ops/publication.json',natural_consumer='pending next natural process/decision journal field readback; no current game restart',prior_blocked_guard_receipt='paper/materials/20261016-0729-ops/route-pending-readback.json',previous_guard_preserved=True,new_learner_or_research_dispatch=False)
old.update(update);old['blocker']='original builder962689/start99867788 absent at resume; current nonblocking original live lock acquired';write(f,old)
write(pub/'pending-integration-update.json',dict(pending_file=ref(f),status=update))
# Original source/rc0/mergednull/cases0 and prior blocked publication remain immutable.
previous=r/'paper/materials/20261016-0729-ops'
with tarfile.open(pub/'original-attempt-reference.tar.gz','w:gz') as tar:
 originals=[]
 for name in ['source-readback.json','route-pending-readback.json','route-fallback-event.log','ledger-provenance-readback.json']:
  f=previous/name;tar.add(f,arcname=name,recursive=False);originals.append(ref(f))
write(pub/'original-attempt-reference-manifest.json',originals)
# Keep the original native report states distinct from actual operational publication.
note=f'\n- {at} [ops 原064301-s2兜底已实际合入] 原manual codex-strategy-silent-20261016-064301-s2沿不可变source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a接续：原build-fight-value.py PID962689/start99867788已absent，原锁非阻塞取得，十份live既有知识刷新先保留为{x["knowledge_refresh_commit"]}，随后仅3叶路线投影来源诊断窄差合入main {x["main"]}/live {x["live"]}/tree{x["tree"]}；三叶逐blob同source且source为两HEAD真实祖先。旧题面/排序/模型输入及铁甲/未观察进阶保持，单纯日志诊断不新增行为号，V5-R366和live原storage5行差异/其他源码/知识/并行脏记录均保持。源原439文件4115项tsc0/vitest0、撤码1恢复0/定向5项及26材料检查12702行已核，不重复源full；原19记录冲突、canonical failed/rc0/mergednull、cases0占位及23原CLI where-note行历史保持，十项宽提案仍waiting，不冒整项实现/shipped或新自然消费。单次原learner-recheck {x["batch"]}已启动精确a850673f树，完整结果pending原learner-checks，不借251旧绿/新pipeline、不等待。仅此三叶诊断部署与live刷新保留，不改当前局/账号home模型prompt预算，不派学习者/研究。回执paper/materials/20261016-0738-ops/。\n'
decision=f'\n- {at} 运维codex：0738原manual兜底接原064301-s2 source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a，原构建器962689/start99867788已退出，锁内核实际live2806f8bd，十份已完成知识刷新先提交{x["knowledge_refresh_commit"]}保留、不带进main；原3诊断叶精确合main{x["main"]}/live{x["live"]}/tree{x["tree"]}，source为真实祖先、三叶同SHA，双方并行脏记录/其他源码与live storage既有差异保留。Silent A10路线计划只追加冻结起始HP/maxHP/costs/绝对arrival的可回放来源，旧决策题面/排序输入与其他角色进阶保持，不新行为编号、V5-R366/版本表各自原字节不动。原源439文件4115全0与撤码1恢复0/定向5/材料26项12702行按既有回执不重跑；原failed/rc0/mergednull/cases0占位/19记录冲突及前轮知识构建守卫拒绝原件不改，十宽提案继续waiting，23原CLI追溯行不重复登记/改状态。原唯一learner-recheck064301-s2已实际开始精确新树检查，完整结果pending其原事件；旧251通知树绿不冒充新树通过，新的自然日志消费者仍pending。无新模型/研究/实现、对局/home/账号模型prompt预算不动，不关闭0332/资源校准/学习入库宽父。资料paper/materials/20261016-0738-ops/。\n'
queue=f'\n- {at} [原silent-route-projection-provenance窄诊断部署] 原source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a已实际main{x["main"]}/live{x["live"]}/tree{x["tree"]}，3叶同source、十份live刷新保留于{x["knowledge_refresh_commit"]}。原439文件4115源绿不重跑，精确新树宿主已单次原通道启动/结果pending，新自然projection消费者pending，十项宽提案及资源/历史缺ID/联合消费者仍waiting。原19冲突/failed/rc0/mergednull及上轮builder守卫拒绝保留，无新行为号，V5-R366不动；只按原pending-integrations/20261016-064301-route-provenance.json接后续learner-checks，不复派/重做宽项。回执paper/materials/20261016-0738-ops/。\n'
handoff=f'\n- {at} 0738原manual兜底完成窄合：source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a→main{x["main"]}/live{x["live"]}/tree{x["tree"]}，3诊断叶同源，原知识构建器退出后十刷新先保留{x["knowledge_refresh_commit"]}，并行记录及storage差异不动，无新编号/V5-R366保持。原source439/4115自测0不重跑，原19冲突/failed/rc0/mergednull/cases0占位及十项waiting保持。原learner-recheck064301-s2已单次启动精确a850673f，后续只接原事件，不借251绿/重复host；新自然projection日志消费者仍pending，不重启旧局/改home账号模型。pending-integrations/20261016-064301-route-provenance.json与资料paper/materials/20261016-0738-ops/绑定实际部署/host；宽0332及原学习/校准父继续open。\n'
appends={'ops/inbox-dev.md':note,'paper/materials/decision-log.md':decision,'notes/fix-queue-v4.md':queue,'notes/ops-handoff.md':handoff};write(p/'own-appends.json',appends)
values={}
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
 values[path]=git('show',base+':'+path)+text.encode()
write(pub/'record-registration.json',dict(at=at,base=base,source=x['source'],main=x['main'],live=x['live'],tree=x['tree'],source_paths=3,knowledge_refresh_preserved=10,release_increment=False,existing_release='V5-R366',source_full='existing439files4115passed, not repeated',host_full='running once original064301-s2 exact-tree',natural_consumer='pending',wide_proposals='all ten waiting',other_actor_ACK_calls=0,new_learner_or_research_dispatches=0,game_actions=0))
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 helpers=[]
 for f in sorted(p.glob('*.py')):tar.add(f,arcname=f.name,recursive=False);helpers.append(ref(f))
write(pub/'ops-helper-manifest.json',helpers)
with tarfile.open(pub/'ops-attempt-logs.tar.gz','w:gz') as tar:tar.add(p/'publish.log',arcname='publish.log',recursive=False)
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
scan=p/'archive-scan';scan.mkdir(exist_ok=True)
for f in pub.glob('*.tar.gz'):
 out=scan/f.stem;out.mkdir(exist_ok=True)
 with tarfile.open(f) as tar:
  assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in tar.getmembers());tar.extractall(out,filter='data')
print(json.dumps(dict(record_paths=len(entries),actual_live=x['live'],tree=x['tree'],knowledge=10,source_leaves=3,host_vitest_RUN=host['vitest_RUN_observed'],full_result='pending')))

# 本批指定提案核验

批次：20261016-134302-s2-strategy-proposal。记录时间：2026-10-16 13:53:46 CST。
角色silent，已观察范围A10。基线完整提交：`2bfc03ceab52faac7aecb14ef4e781bba6f62345`。来源与实现任务均按各原提案保留，目标任务strategy-proposal；授权Roy-2026-10-07-learning不提供游戏事实。

本批只处理dispatch-row.json的10个已领取ID，没有research_request/implementation_request/proposal_repair，不承接根目录旧专题。开工git status为空，git merge --no-edit main返回Already up to date。本批不增加游戏规则、源码、知识、版本或提交；所有10项waiting，既有局部实现不冒充宽项全部完成。

本批只重核六个已派发静默局。每份原提案Markdown与专用队列保存的SHA一致，原字节副本为本目录对应ID.md；账本关联在assigned-proposals.json。未读其他角色私有知识，不从预训练知识补机制。本批现有证据全部为发现/回归证据，不当独立后置验证。

预期行为：保留所有候选、既有并列和探索规则，逐项写清已覆盖部分及缺口。当前没有足够数据拟合技能血价、SL惩罚、能力优先级或终局权重。后续若有明确差额，可在原提案下做窄实现；必须固定数据撤源码失败/恢复通过、原沙箱自测及实际live流程。回退：本批没有生产变更可回退，追溯记录按CLI追加保留，既有源码不动。

## 原始输入与来源检查

共核8274条封套，逐条seek原日志offset、bytes、SHA256、JSON与显式身份一致；八流各自source_size、逐局计数与封套SHA见evidence-audit.json和两个evidence-manifest.json。正文提及不作身份。六局runs.jsonl均SILENT/A10，原code均+dirty，当前生产模型未获得旧dirty源码和知识联合输入的精确重建，不能用当前源码功能存在宣称历史全模型正确。

| 流 | 原字节截点 | 本批选中且复核行数 |
|---|---:|---:|
| states | 13511653068 | 4062 |
| decisions | 1892586908 | 3941 |
| sl-attempts | 43199113 | 38 |
| run-config | 1856151 | 6 |
| run-plans | 8509269 | 33 |
| brain | 666611477 | 188 |
| runs | 347224 | 6 |
| fight-plans | 2233957 | 0 |

states/decisions全流分别有2条无效JSON，brain有1条；这些未选中为证据，不向其归属作推断。fight-plans该截点0行只表示未选到明确本批身份，不断言不存在原日志。run-plans以原run字段核到33行，没有沿用零行旧初稿。本批未覆盖或改写旧报告/旧截点。

## 当轮同指纹比较

| 原/替换决策原行 | 实际HP净损 | 敌本体净扣 |
|---|---:|---:|
| 270216 / 270282 | 3 / 15 | 10 / 17 |
| 271309 / 271348 | 0 / 9 | 45 / 38 |
| 271992 / 272040 | 9 / 14 | 24 / 27 |
| 271982 / 272195 | 2 / 10 | 25 / 34 |

paired-turn-endpoints.json保留原始指纹、原决策引用与端点offset/SHA。仅同轮端点观测，不能归因为完整候选执行或整场因果。8J的0/24和5/24死亡数不同；YF两个24/24全败候选的0/10与54/36预测不替换成实损0/9和实扣45/38。XP成长、药瓶随机和抽弃后的新问题不抹掉。

## 现有消费者实际读回

已使用node --import ./agent/node_modules/tsx/dist/loader.mjs运行consume.mjs，真实退出0，六局依次调用已有auditSelectionExecution；同一进程调用已有silentPhaseCurrentFacts并核阶段清毒、零毒触媒、5→6敏而23挡不变。没有调用LLM、游戏API、长程模拟或刷新的知识JSON。

| 局号 | 候选题段 | 动作 | 可核轮端点 | 未知轮窗 |
|---|---:|---:|---:|---:|
| DUZUBAJ3A8GP | 77 | 599 | 28 | 68 |
| 5PM6JAQG6FNQ | 83 | 638 | 25 | 76 |
| CA5KE8GFJ9X2 | 41 | 264 | 0 | 46 |
| 8JRE1C4H4Z2W | 113 | 659 | 44 | 67 |
| YF0LXT1QSTGG | 204 | 1065 | 54 | 106 |
| XP2SL33HT0D9 | 123 | 712 | 35 | 87 |

合计641段、3937动作、186可核轮端点、450未知窗口。缺decision_id的4条元数据单独保留于consumers/input-manifest.json（DUZ3、CA5 1），未补号/改号。输入JSON和输出JSON均gzip保留，压缩与解压SHA、真实exit见consumers/results.json；完整续步认证为0，actual_full_candidate_result/actual_rollout_best仍null。这个0表示现有审计没有认证，不证明所有线都未完整打出。

20项原帧事实断言真实通过，见findings-verification.json；它们是材料核验，不是生产tsc/vitest，也不是模型已校准。消费者保留8J末轮5→0与敌154→130，显示37−22=15只作算术参考；YF末轮44−23=21大于18血，零血截断不补造实受21。角色无关性/其他进阶未在本批推广。

## 源码与live范围

本批读取时live提交：`9afbe4075ac8d941da6f1a47020e046aa2d5d8be`。20个相关源码叶中17个逐字相同，3个只有既有Roy/Dai注释字差，详见source-audit.json和base-live-source-diff.patch；8个列出的功能提交均已验证为base及该live的真实祖先。纯“存在函数”不是完整消费者校准；只在本批直接运行的离线审计/当前阶段函数范围声称读回。没有注册整体duplicate、implemented或shipped。

原运行+dirty，不将上述祖先与当前源码当作复原历史实际输入；数据库第一样本与room-costs五样本门槛按源码分列，未新增任何数值。原101局/路线资源父请求不因六锚点或报告完成而关闭。

## 逐项结果与后续

全部10项的证据、账本、既有实现、具体缺口、反例和验法见proposal.md下列各节，原件副本SHA核保留。无新机制反证、没有与旧claim冲突的新结论；不重复追加support/repeat/首证或提案ID。只经根目录ledger.py追加本批where/note，保留原claim、status、version、shipped和历史，未把既有shipped降为proposed；没有新条目需要登记。

无源码变更，撤源码红/恢复绿不适用，未运行生产tsc/vitest/全套sandbox；tests三个字段均null。未提交、未合入、未分发布号，不造空合并、测试成功或上线通知。工作树HEAD保持完整base，git status应为空；scratch均在本任务learner/runs目录内。

本次核验脚本及输入/输出均保留。启动时对learn.json的首次路径定位命令意外打印过宽、第二次误取根key报KeyError，随后限定batches精确本行重核；这些操作错误未作为证据或修改任何调度数据。若干只读源码探针路径不存在，已按rg --files定位正确路径，没有当产品故障。当前模型/推理参数未从原生宿主自核，不声称已切换运行模型。

最终机器回报见result.json；未实现原因逐项保留waiting，待新证据重派，不另领取队列。

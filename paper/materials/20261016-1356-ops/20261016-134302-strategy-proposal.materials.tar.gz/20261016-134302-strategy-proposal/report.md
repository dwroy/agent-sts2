# 静默猎手本批十项策略处置报告

记录时间：2026-10-16T13:51:18+08:00；batch=20261016-134302-strategy-proposal；task=strategy-proposal；character=silent。

本批十项全部waiting。六局原证据没有新增；现有窄实现已在live，但没有完成原提案剩余的持续执行归属、全链生产校准或受控整战比较。没有源码/知识修改、新id、源码提交、live合入、版本或shipped，fixes=[]、merged=null。没有把报告、排队或局部源码当量化学习父要求完成。

## 身份和基线

先核git status干净，读取README、最新STATE-2026-10-16、decision-log末尾、learning-protocol和learning-code-proposals。只读根learn.json对应本批，task/character/worktree/runs及十proposal_ids匹配，reason=proposal；无research_request、implementation_request或proposal_repair。普通专题文件属于另一旧batch，不承接专题、不读取其他专题替代身份。git merge --no-edit main返回Already up to date，实际base=2bfc03ceab52faac7aecb14ef4e781bba6f62345，未出现冲突。

六局runs.jsonl均为SILENT/A10：CA5KE8GFJ9X2, 61E2QS63Y9WU, 5PM6JAQG6FNQ, DUZUBAJ3A8GP, VLZ6CCT8AQ0A, 8JRE1C4H4Z2W。独立局数6；SL不扩分母。没有下级agent，没有读取其他角色私有知识、联网或调用模型/游戏API，没有运行play。进程命名空间仅可见shell/python，不能自行核本原生模型/推理强度；未更改模型、账号、prompt或配置，待宿主独立核实际会话。

## 原始证据和材料复核

共用extract_evidence.py提取8流，逐流冻结source_size，6995条所属原行全部逐offset/bytes/SHA256/JSON/显式身份读回通过。所属身份使用run_id/state.run_id/run/fingerprint.run，正文提及不算所属，冲突身份不收。八流选中封套SHA与20261014-211320原报告全部一致；原日志截点增长不等新证据。fight-plans在本次截点0行只表示未选中，不断言历史缺失。全源states/decisions各2无效行、brain1无效行，不将其归入本六局。

| 流 | source_size字节 | 所属原行 | 选中字节与旧封套相同 |
|---|---:|---:|---|
| states | 13511721506 | 3432 | 是 |
| decisions | 1892787558 | 3306 | 是 |
| sl-attempts | 43199113 | 29 | 是 |
| run-config | 1856151 | 6 | 是 |
| run-plans | 8509269 | 33 | 是 |
| brain | 666783888 | 183 | 是 |
| runs | 347224 | 6 | 是 |
| fight-plans | 2233957 | 0 | 是 |

718状态和696决策投影逐字段从当前已核原行重算一致；37项固定原帧事实断言通过，六个神化夹具与原状态/SHA一致。此为材料核验，生产tests仍null，不算新增策略红绿或完整测试。保存raw-readback-verification.json、projection-verification.json、fact-checks.json、fixture-readback.json及原日志。

六份既有离线消费者输入逐字段与本批原行一致，输入gzip/解码SHA、输出gzip/解码SHA及计数均另存prior-consumer-readback.json。本批未重跑消费者、生产模拟或模型。原输入中CA5行267143、61E行267517、DUZU行268789/268818/268864缺decision_id，旧消费者完整输入真实拒收；原有界输出仅排除这些行，不补造ID、不当完整局输入通过。

| 局 | 有ID动作 | 候选段 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|
| 5PM6JAQG6FNQ | 638 | 83 | 25 | 76 |
| 61E2QS63Y9WU | 442 | 63 | 14 | 59 |
| 8JRE1C4H4Z2W | 659 | 113 | 44 | 67 |
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 46 |
| DUZUBAJ3A8GP | 599 | 77 | 28 | 68 |
| VLZ6CCT8AQ0A | 699 | 99 | 10 | 97 |

合计3301动作、476候选段、121整轮端点、413未知轮窗口，所有actual_full_candidate_result=null。这是消费者的认证边界，不证明从未完整执行候选，也不是策略失败或收益证明。8JRE同盘多12血换7敌净扣、5PM无毒冒泡零效果、族母负敏捷防御及毒端点、胧光未退场、甲虫临减恢复均保留原条件和未知，不将净端点当未选整场因果。

## 已有源码与实际live祖先

只读live快照=9afbe4075ac8d941da6f1a47020e046aa2d5d8be。15个相关源码路径13个与本base逐SHA一致，card-model.ts和rollout-live.ts两差异均为历史Roy/Dai注释文字；完整记录在source-verification.json。相较旧报告8路径相同、7路径已变，未假设旧整个执行模型等于当前模型。

新增神化致命毒药5→7传播ba23ca693151fa8c6f7fe035e640dc30f05ccd75、SL资源审计1698adc96ba434a46942321e0237b70657e625b2均已核为本base与实际live祖先，不再报为未上线；前者未补actual_cast_this_fight，后者仍是current_turn_prediction/execution=unverified，不扩为宽提案全部duplicate。原3aa6c03a、b2805be4、05cd292c、a8b1f8be、cf72bd21及772b839f窄实现也核真实祖先。相关新旧精确源码差分保存在related-source-since-prior.patch。没有重建旧+dirty知识联合输入，也未凭源码祖先推断生产校准或自然采用。

## 逐项处置

| id | 处置 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、药水、重规划、SL和换战的实际施放持续身份及未覆盖升级交互校准；窄传播和新增致命毒药升级不足以关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的MC分配配对、候选稳定性曲线及留药后继；两次不同指纹药水问不能据以改预算或药价。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化提案仍缺实际施放持续身份和剩余升级交互校准；实际live窄实现不能作为整项duplicate证明。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项的属性/升级组合、状态期限及战斗/路线/休息消费者逐源联合校准；六局原帧和局部实现不足以验收整项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨重规划的持续候选身份、完整执行认证和能力成长逐源归属；113个候选段与整轮净端点不能认证完整候选或改SL血价。 |
| silent-proposal-49632bc4878fb597 | waiting | 本局无正敏捷实测；缺逐击力量、正负敏捷、虚弱和独立成长四路径的同次冻结生产校准，不能新增统一保血/输出权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水、完整抽序下不同启动顺序的受控整战结果和收益函数；无毒冒泡的局部无效不足以拟合启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP、构筑、完整抽序的SL整战配对及另一条已核后继；首试胜利和毒端点不足以修改SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行成长、退场和复现的全链冻结生产校准及另一focus完整后继；局部源码不支持固定杀序。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续、当前进阶成长的全链生产校准和同抽换序后继；四次相关失败不足以拟合血价或固定杀序。 |

每项证据局/层/回合、原账本、反例、现状、预期行为、验证、样本切分和回退在同目录proposal.md。十个原Markdown已核队列指纹，原字节另存*.original.md。两个神化id同源也保留逐项waiting，不另建重复提案。code_proposals填写原十个CLI id，implementation_domains=[]，因为没有实际新实现。

## 记录和验证口径

只经根learner/ledger.py update追加本批追溯链接和说明，by=learner:strategy-proposal；不新增support/repeat证据、不改原claim/first_run/prior/asc/status/version/shipped或原提案。已有shipped状态不倒退为proposed；尚未实现提案继续waiting。CLI输入/输出和逐行读回保存在本目录，队列处置交最终proposal_results由既有调度器消费，不手改learn.json或专用队列。

没有生产源码改动，撤源码失败/恢复通过不适用，未运行tsc/vitest，tests固定为null。未进入live合入流程、没有eval编号、上线decision-log或规则双通知；没有可冒报的源码/合入提交。原日志、旧报告、scratch核验材料和失败均保留。只读夹具结构探针曾误将frames列表当字典，重读后纠正；不是生产测试失败或游戏反证。

最终核HEAD=base、工作树源码/知识和索引干净，材料通过gitleaks脱敏扫描；实际读回记录另存final-verification.json，不将材料核验当生产测试成功。没有新增机制异议或旧结论反证，不重复发学习通知或代其他角色确认。

交运维提案路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-134302/learner/runs/20261016-134308-f93a11c6-33bb-43eb-8be9-dbc6ddc1ae6c-strategy-proposal/proposal.md。报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-134302/learner/runs/20261016-134308-f93a11c6-33bb-43eb-8be9-dbc6ddc1ae6c-strategy-proposal/report.md。

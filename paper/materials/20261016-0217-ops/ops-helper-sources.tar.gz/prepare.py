from pathlib import Path
import collections, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0217';pub=root/'paper/materials/20261016-0217-ops';pub.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-020233-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
assert {k:v for k,v in scratch.items() if k!='proposal'}==report and scratch['proposal']==str(s/'proposal.md')
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['merged'] is None
assert b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'delivery-validation.json');assert final['base']==report['base'] and final['head_unchanged'] and not final['git_status_porcelain'] and final['tracked_diff_bytes']==0
assert final['proposal_count']==final['original_markdown_sha_verified']==10 and final['all_results_waiting'] and final['material_assertions']==38 and final['consumer_calls']==6 and final['consumer_full_candidate_results']==0 and final['ledger_owned_updates']==31
assert final['production_tests_run'] is False and final['source_commit'] is final['merged'] is final['release_id'] is None
for x in final['gitleaks']:assert x['returncode']==0 and sha(Path(x['path']).read_bytes())==x['sha256'] and load(Path(x['report']))==[]
proposals=load(s/'proposals-before.json');assert {x['id'] for x in proposals}==set(report['code_proposals'])==set(b['proposal_ids'])
for x in proposals:
    source=Path(x['proposal']);assert source.is_relative_to(root) and sha(source.read_bytes())==x['proposal_sha256']
    assert (s/(x['id']+'.original.md')).read_bytes()==source.read_bytes()
extract=module('original_extract',root/'learner/extract_evidence.py');runs=load(s/'verified-runs.json');assert len(runs)==15 and all(x['character']=='SILENT' for x in runs.values())
verification=load(s/'evidence-verification.json');counts={}
for x in verification:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');assert sha(frozen.read_bytes())==x['output_sha256'] and x['selected_bytes_verified'] and x['identity_verified'];seen=collections.Counter()
    with frozen.open() as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert sha(raw)==e['sha256'] and row==e['row'] and extract.run_identity(row)==e['run_id'] and e['run_id'] in runs
            assert e['offset']+e['bytes']<=x['source_size'];seen[e['run_id']]+=1
            if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==runs[e['run_id']]['ascension']
            if x['stream']=='runs':assert row==runs[e['run_id']]
    assert all(seen.get(run,0)==n for run,n in x['counts'].items());counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==19929
facts=load(s/'material-assertions.json');assert len(facts)==38 and all(x['passed'] and x['actual']==x['expected'] for x in facts)
source=load(s/'source-readback.json');assert source['base']==report['base'] and len(source['leaves'])==18
for x in source['leaves']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and sha((root/'.worktrees/live'/x['path']).read_bytes())==x['live_disk_sha256']
    assert (a==z)==x['base_equal_live'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai');git('merge-base','--is-ancestor',x['last_path_commit'],source['live_head'])
assert sum(x['base_equal_live'] for x in source['leaves'])==15
for x in source['existing_commits']:
    assert x['in_base'] and x['in_live'];git('merge-base','--is-ancestor',x['commit'],report['base']);git('merge-base','--is-ancestor',x['commit'],source['live_head'])
consumers=load(s/'consumer-receipts.json');assert len(consumers)==6 and all(x['returncode']==0 for x in consumers)
assert collections.Counter(x['scope'] for x in consumers)=={'complete':3,'bounded_without_idless_route_metadata':3}
totals=collections.Counter();excluded_count=0
for x in consumers:
    for path,key in [('complete_input','complete_input_sha256'),('input','input_sha256'),('output','output_sha256')]:assert Path(x[path]).is_relative_to(s) and sha(Path(x[path]).read_bytes())==x[key]
    assert sha((s/'audit-outputs'/(x['run_id']+'.stderr.txt')).read_bytes())==x['stderr_sha256']
    complete=load(Path(x['complete_input']));actual=load(Path(x['input']));audit=load(Path(x['output']))
    assert actual['states']==complete['states'] and actual['run']==complete['run'] and actual['run']['run_id']==x['run_id']
    if x['scope']=='complete':assert actual==complete and x['excluded']==[]
    else:
        missing=[d for d in complete['decisions'] if not d.get('decision_id')];assert len(missing)==len(x['excluded']) and all(d['label']=='map/route-change' and d['screen'] in ['REST','REWARD'] for d in missing)
        assert actual['decisions']==[d for d in complete['decisions'] if d.get('decision_id')];excluded_count+=len(missing)
    c=dict(segments=len(audit['segments']),actions=len(audit['observed_actions']),interval_endpoints=sum(a['observed_interval']['status']=='observed_endpoints' for a in audit['observed_actions']),turns=len(audit['observed_turns']),turn_endpoints=sum(t['status']=='observed_turn_endpoints' for t in audit['observed_turns']),full_candidate_results=sum(t['actual_full_candidate_result'] is not None for t in audit['segments']))
    assert c==x['counts'];totals.update(c)
assert excluded_count==4 and totals==dict(segments=654,actions=3185,interval_endpoints=1121,turns=556,turn_endpoints=188,full_candidate_results=0)
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];rows=load(s/'ledger-owned-events.json');receipt=load(s/'ledger-update-receipt.json')
assert len(inputs)==len(rows)==31 and receipt['returncode']==0 and sha((s/'ledger-updates.jsonl').read_bytes())==receipt['input_sha256']
assert set(receipt['stdout'].split())=={x['id'] for x in inputs};protection=load(s/'ledger-protection-check.json');assert protection['owned_event_count']==31 and protection['no_status_or_evidence_update'] and all(all(v for k,v in x.items() if k!='id') for x in protection['checks'])
own=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as ledger:
    for entry in rows:
        ledger.seek(entry['offset']);raw=ledger.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        assert any(all(row.get(k)==v for k,v in x.items()) for x in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==31 and all(raw.rstrip(b'\n') not in set(old.splitlines()) for raw in own);added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,scratch_only_extra_field='proposal points to original proposal.md; original failed strict-equality assertion preserved.',original_gate=b['no_change_proposals'],native=native,completion=final,source=source,original_rows_verified=19929,stream_counts=counts,material_assertions=38,original_consumer_receipts=consumers,consumer_totals=dict(totals),excluded_route_metadata=4,consumer_not_reexecuted=True,owned_trace_rows=31,protected_fields_and_old_prefixes_preserved=True,limits=['A1/A7/A9 and A10 remain separate; same-run SL is not an independent sample.','Three full and three bounded offline inputs do not certify whole-candidate execution, physical uncapped damage or controlled successors.','Original source dirty knowledge consumption, potion holding value, complete route/resource alternatives and joint calibration remain unknown.','Existing narrow shipped branches remain shipped; waiting broad proposals and learning parents remain open.','Original truncated display and outdated source-layout probes are preserved, not product failures or new counterevidence.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for sourcefile in sorted(files):
        raw=sourcefile.read_bytes();rel=str(sourcefile.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(sourcefile,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0217原020233-s2策略done0/no-source处置核，d523基线/干净WT/HEAD不变，十waiting逐项缺口/testsnull/域空/mergednull保持，无提交合入阻塞，不空合/发号/补测。十五Silent来源八流19929行原offset/bytes/SHA/JSON/身份逐核，A1/A7/A9与A10分列，38原材料断言通过不重跑或冒生产测试；六原离线input/output/stderr SHA核，3完整/3有界（四条无ID路线元数据原件保留且原编号不改），654段/3185动作/1121相邻端点/188轮端点/368未知，整候选认证0，不当整战/替线收益。18源码叶15同3历史Roy-Dai注释差，六旧来源base/live祖先保持，不以窄实现关闭联合提案或重复登记shipped；历史dirty消费、未截顶毛伤与完整资源/路线后继校准未知保持。31所属CLI纯where/note按输入/回执/原offset/bytes/SHA及私有fold核，旧claim/首证/prior/evidence/status/version/history前缀保持，不重复CLI。原宽打印截断及旧布局路径探针保，不当生产bug/新反证；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核，与原无法自省声明分列。仅本人记录/追溯提交，保并行脏记录；无源码/知识/版本/论文刷新/测试/派发/对局重启或账号home模型额度权限prompt操作，不关闭宽父。证据paper/materials/20261016-0217-ops/。\n'
note=f'\n- {at} [运维 codex] 原020233-s2策略十项继续waiting，无源码变更或合入受阻；38项材料检查、3完整/3有界离线调用及31条所属追溯已核，整候选认证仍0。既有窄修复与宽父状态保持。回执paper/materials/20261016-0217-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=31,old_fields_preserved=True,no_new_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=19929,owned_trace_rows=31,ledger_check=0,paths=len(entries))))

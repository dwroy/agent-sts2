import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
TARGETS = ['KEN58SH9SLZ6', 'TXZ6RVMQA09D', 'WQZVENQ7DTRP',
           '1913SE84AXQF', 'Q6M2Y34MWKRE', 'NHA2KW0RB7VP']


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


spec = importlib.util.spec_from_file_location('extract', WORKTREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
runs = json.loads((OUT / 'verified-runs.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verification = []
state_compact = collections.defaultdict(list)
decision_compact = collections.defaultdict(list)
excluded = collections.defaultdict(list)
audit_inputs = OUT / 'audit-inputs'
audit_outputs = OUT / 'audit-outputs'
audit_inputs.mkdir(exist_ok=True)
audit_outputs.mkdir(exist_ok=True)
handles = {}
for run in TARGETS:
    for stream in ['states', 'decisions']:
        handles[run, stream] = (audit_inputs / (run + '.' + stream + '.jsonl')).open('w')


def ref(item):
    return {key: item[key] for key in ['source', 'line', 'offset', 'bytes', 'sha256']}


for stream in manifest:
    path = OUT / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    assert sha(path) == stream['output_sha256']
    counts = collections.Counter()
    with path.open() as selected, (Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')).open('rb') as source:
        for line in selected:
            item = json.loads(line)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            row = json.loads(raw)
            assert row == item['row']
            run = extract.run_identity(row)
            assert run == item['run_id'] and run in runs
            assert item['offset'] + item['bytes'] <= stream['source_size']
            counts[run] += 1
            row['_line'] = item['line']
            if (run, stream['stream']) in handles:
                handles[run, stream['stream']].write(json.dumps(row, ensure_ascii=False) + '\n')
            if stream['stream'] == 'states':
                state = row['state']
                info = state.get('run') or {}
                assert info.get('character_id', '').lower() == 'silent'
                assert info.get('ascension') == runs[run]['ascension']
                combat = state.get('combat') or {}
                player = combat.get('player') or {}
                hand = combat.get('hand')
                state_compact[run].append({
                    **ref(item), 'observed_ts': row.get('observed_ts'),
                    'fingerprint_sha256': hashlib.sha256(row.get('fingerprint', '').encode()).hexdigest(),
                    'floor': info.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
                    'hp': player.get('current_hp', info.get('current_hp')), 'max_hp': info.get('max_hp'),
                    'block': player.get('block'), 'energy': player.get('energy'),
                    'powers': player.get('powers'), 'potions': info.get('potions'),
                    'hand': None if hand is None else [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'dynamic_values']} for c in hand],
                    'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'powers', 'intents', 'move_id', 'is_alive']} for e in combat.get('enemies', [])],
                })
            elif stream['stream'] == 'decisions':
                decision_compact[run].append({**ref(item), **{k: row.get(k) for k in ['decision_id', 'observed_ts', 'floor', 'turn', 'screen', 'label', 'chosen', 'result', 'sl_attempt', 'sl_reloads', 'journal', 'sl_explore', 'hp_guard']}})
                if not row.get('decision_id') and run in TARGETS:
                    assert row.get('label') == 'map/route-change'
                    assert row.get('screen') in ['REST', 'REWARD']
                    excluded[run].append({**ref(item), 'label': row['label'], 'screen': row['screen'], 'reason': '原路线元数据无decision_id；保留完整原件，离线消费者有界输入单列排除'})
    assert all(counts.get(run, 0) == count for run, count in stream['counts'].items())
    verification.append({**stream, 'selected_bytes_verified': True, 'identity_verified': True})
    print(stream['stream'], sum(counts.values()), flush=True)
for handle in handles.values():
    handle.close()
save(OUT / 'evidence-verification.json', verification)
save(OUT / 'states-compact.json', state_compact)
save(OUT / 'decisions-compact.json', decision_compact)
save(OUT / 'audit-exclusions.json', excluded)

receipts = []
for run in TARGETS:
    states = [json.loads(line) for line in (audit_inputs / (run + '.states.jsonl')).open()]
    decisions = [json.loads(line) for line in (audit_inputs / (run + '.decisions.jsonl')).open()]
    complete = {'run': runs[run], 'states': states, 'decisions': decisions}
    full_path = audit_inputs / (run + '.complete.json')
    save(full_path, complete)
    scope = 'complete' if not excluded[run] else 'bounded_without_idless_route_metadata'
    if excluded[run]:
        complete['decisions'] = [d for d in decisions if d.get('decision_id')]
        input_path = audit_inputs / (run + '.bounded.json')
        save(input_path, complete)
    else:
        input_path = full_path
    output_path = audit_outputs / (run + '.json')
    stderr_path = audit_outputs / (run + '.stderr.txt')
    with output_path.open('w') as stdout, stderr_path.open('w') as stderr:
        result = subprocess.run(['node', '--import', 'tsx', str(WORKTREE / 'learner/audit-selection.ts'), str(input_path)],
                                cwd=WORKTREE / 'agent', stdout=stdout, stderr=stderr)
    receipt = {'run_id': run, 'scope': scope, 'excluded': excluded[run], 'returncode': result.returncode,
               'complete_input': str(full_path), 'complete_input_sha256': sha(full_path),
               'input': str(input_path), 'input_sha256': sha(input_path),
               'output': str(output_path), 'output_sha256': sha(output_path), 'stderr_sha256': sha(stderr_path)}
    if result.returncode == 0:
        audit = json.loads(output_path.read_text())
        receipt['counts'] = {'segments': len(audit['segments']), 'actions': len(audit['observed_actions']),
                             'interval_endpoints': sum(x['observed_interval']['status'] == 'observed_endpoints' for x in audit['observed_actions']),
                             'turns': len(audit['observed_turns']),
                             'turn_endpoints': sum(t['status'] == 'observed_turn_endpoints' for t in audit['observed_turns']),
                             'full_candidate_results': sum(s['actual_full_candidate_result'] is not None for s in audit['segments'])}
    receipts.append(receipt)
    save(OUT / 'consumer-receipts.json', receipts)
    print(run, scope, result.returncode, receipt.get('counts'), flush=True)

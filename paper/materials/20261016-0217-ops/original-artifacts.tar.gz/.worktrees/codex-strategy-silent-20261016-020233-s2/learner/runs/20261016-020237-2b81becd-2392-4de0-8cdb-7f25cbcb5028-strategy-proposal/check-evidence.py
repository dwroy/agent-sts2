import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
S = json.loads((OUT / 'states-compact.json').read_text())
D = json.loads((OUT / 'decisions-compact.json').read_text())
frames = {x['line']: x for rows in S.values() for x in rows}
checks = []


def check(name, actual, expected, lines):
    item = {'name': name, 'actual': actual, 'expected': expected,
            'states': [{k: frames[n][k] for k in ['source', 'line', 'offset', 'bytes', 'sha256']} for n in lines],
            'passed': actual == expected}
    checks.append(item)
    (OUT / 'material-assertions.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    assert item['passed'], name


def hp(n):
    return frames[n]['hp']


def enemyhp(n):
    return sum(e['current_hp'] for e in frames[n]['enemies'])


def power(n, who, ident):
    raw = frames[n]['powers'] if who == 'player' else frames[n]['enemies'][who]['powers']
    return next((p['amount'] for p in raw if p['power_id'] == ident), 0)


check('KEN F5胜战净损', hp(280255) - hp(280284), 37, [280255, 280284])
check('KEN F15胜战净损', hp(280347) - hp(280380), 0, [280347, 280380])
check('KEN F12实际回血', hp(280337) - hp(280336), 27, [280336, 280337])
check('KEN F12生命上限', [frames[n]['max_hp'] for n in [280336, 280337]], [76, 81], [280336, 280337])
check('KEN F16实际回血', hp(280383) - hp(280382), 29, [280382, 280383])
check('TXZ F48 T6原线血价与净推进', [hp(281479)-hp(281484), enemyhp(281479)-enemyhp(281484)], [3, 36], [281479, 281484])
check('TXZ F48 T6替线血价与净推进', [hp(281535)-hp(281539), enemyhp(281535)-enemyhp(281539)], [0, 27], [281535, 281539])
check('TXZ F48首胜/F49初帧/最终生命', [hp(n) for n in [281563, 281565, 281566]], [4, 4, 0], [281563, 281565, 281566])
check('TXZ F49敌血未动', [enemyhp(n) for n in [281565, 281566]], [111, 111], [281565, 281566])
check('WQ T9两次题面指纹相同', frames[282075]['fingerprint_sha256'], frames[282144]['fingerprint_sha256'], [282075, 282144])
check('WQ T9原线血价与净推进', [hp(282075)-hp(282079), enemyhp(282075)-enemyhp(282079)], [13, 24], [282075, 282079])
check('WQ T9替线血价与净推进', [hp(282144)-hp(282148), enemyhp(282144)-enemyhp(282148)], [22, 39], [282144, 282148])
check('WQ末试T7延长线实际付血', hp(282330)-hp(282336), 4, [282330, 282336])
check('WQ末试T7出逃后/次轮沙坑分列', [power(n, 0, 'SANDPIT_POWER') for n in [282330, 282331, 282336]], [4, 5, 4], [282330, 282331, 282336])
check('Q6 F7实际回血', hp(282870)-hp(282869), 21, [282869, 282870])
check('Q6 F8胜后与F9生命链', [hp(n) for n in [282872, 282911, 282913, 282921]], [57, 2, 2, 0], [282872, 282911, 282913, 282921])
check('Q6紧勒逐牌及轮末毒端点', [enemyhp(n) for n in [282887, 282888, 282889, 282890, 282891, 282892]], [103, 95, 85, 85, 83, 80], [282887, 282888, 282889, 282890, 282891, 282892])
check('Q6紧勒建立与下轮撤层', [power(n, 0, 'STRANGLE_POWER') for n in [282888, 282891, 282892]], [2, 2, 0], [282888, 282891, 282892])
check('1913 F24锻造未回血', hp(282709)-hp(282706), 0, [282706, 282709])
check('1913 F28回复与F29胜战净损', [hp(282721)-hp(282720), hp(282723)-hp(282749)], [21, 15], [282720, 282721, 282723, 282749])
check('1913 F31实际入口', hp(282755), 46, [282755])
check('NHA原始未就绪与可操作基线分开', [hp(283390), enemyhp(283390), hp(283391), enemyhp(283391)], [28, 428, 30, 408], [283390, 283391])
check('NHA首试T1实际血价/敌净推进', [hp(283391)-hp(283397), enemyhp(283391)-enemyhp(283397)], [1, 8], [283391, 283397])
check('NHA第五试T1实际血价/敌净推进', [hp(283478)-hp(283483), enemyhp(283478)-enemyhp(283483)], [7, 24], [283478, 283483])
check('NHA末试T1实际血价/敌净推进', [hp(283502)-hp(283507), enemyhp(283502)-enemyhp(283507)], [7, 24], [283502, 283507])
check('NHA首试X1萎靡现场效果', [power(283395, 0, 'STRENGTH_POWER'), power(283395, 0, 'WEAK_POWER')], [-2, 2], [283395])
check('NHA首试T2实际末挡/次轮失血', [frames[283399]['block'], hp(283399)-hp(283400)], [15, 7], [283399, 283400])

potion_observations = []
indexes = {run: {(x['observed_ts'], x['fingerprint_sha256']): i for i, x in enumerate(rows)} for run, rows in S.items()}
with (OUT / 'evidence/decisions.evidence.jsonl').open() as handle:
    for line in handle:
        item = json.loads(line)
        row = item['row']
        chosen = row.get('chosen') or {}
        if chosen.get('action') != 'use_potion':
            continue
        run = item['run_id']
        key = row.get('observed_ts'), hashlib.sha256(row.get('fingerprint', '').encode()).hexdigest()
        index = indexes[run].get(key)
        if index is None or index + 1 >= len(S[run]):
            continue
        before, after = S[run][index:index+2]
        slot = chosen.get('option_index')
        bottle = next((x for x in before['potions'] or [] if x.get('index') == slot and x.get('occupied')), None)
        if not bottle:
            continue
        same_context = before['floor'] == after['floor'] and before['turn'] == after['turn']
        entry = {'run_id': run, 'decision_line': item['line'], 'decision_id': row.get('decision_id'),
                 'floor': before['floor'], 'turn': before['turn'], 'potion_id': bottle.get('potion_id'),
                 'original_result': row.get('result'), 'same_context': same_context,
                 'before': before, 'after': after,
                 'hand_delta': None if before['hand'] is None or after['hand'] is None else len(after['hand'])-len(before['hand'])}
        potion_observations.append(entry)
(OUT / 'potion-observations.json').write_text(json.dumps(potion_observations, ensure_ascii=False, indent=2) + '\n')
ken = [x for x in potion_observations if x['run_id'] == 'KEN58SH9SLZ6']
check('KEN七次饮药有相邻状态观察', len(ken), 7, [])
check('KEN原pending回执仍分列', sum(x['original_result'].startswith('pending') for x in ken), 3, [])
cunning = [x for x in potion_observations if x['potion_id'] == 'CUNNING_POTION']
check('已派狡诈原九局42次用药', len(cunning), 42, [])
check('狡诈新增手牌3/2/0分布', dict(collections.Counter(x['hand_delta'] for x in cunning)), {3: 37, 2: 2, 0: 3}, [])
check('狡诈均同层同轮相邻观察', all(x['same_context'] for x in cunning), True, [])
check('狡诈实际填位公式局部复核', all(x['hand_delta'] == min(3, 10-len(x['before']['hand'])) for x in cunning), True, [])
nonfull = [x for x in cunning if x['hand_delta'] < 3]
check('狡诈容量不足仅WQ一局', sorted({x['run_id'] for x in nonfull}), ['WQZVENQ7DTRP'], [])
generated = [c for x in cunning for c in x['after']['hand'][len(x['before']['hand']):]]
check('新增刀均升级且基础伤6', all(c['card_id'] == 'SHIV' and c['upgraded'] is True and
    any(v['name'] == 'Damage' and v['base_value'] == 6 for v in c['dynamic_values']) for c in generated), True, [])

receipts = json.loads((OUT / 'consumer-receipts.json').read_text())
check('六次现有离线消费者调用成功', [x['returncode'] for x in receipts], [0]*6, [])
check('完整输入与有界输入各三局', dict(collections.Counter(x['scope'] for x in receipts)),
      {'complete': 3, 'bounded_without_idless_route_metadata': 3}, [])
check('现有消费者未认证整候选结果', sum(x['counts']['full_candidate_results'] for x in receipts), 0, [])
print(json.dumps({'material_assertions': len(checks), 'passed': sum(c['passed'] for c in checks),
                  'observed_potion_actions': len(potion_observations), 'cunning': len(cunning)}, ensure_ascii=False))

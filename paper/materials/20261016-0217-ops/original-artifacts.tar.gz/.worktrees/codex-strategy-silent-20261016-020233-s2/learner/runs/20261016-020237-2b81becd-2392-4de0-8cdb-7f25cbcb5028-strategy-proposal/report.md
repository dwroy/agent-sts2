# 静默猎手策略提案处置报告

批次 `20261016-020233-s2-strategy-proposal`；记录时间2026-10-16T02:10:43+08:00。

十项已派提案全部复核并保留waiting；未改源码或知识。base=`d523c467cb0e00cfbf181f4490ba6a4d0fbf1ba1`，fixes=[]，merged=null。工作树HEAD保持原基线，未创建提交、未合live、未新增eval版本。

本批证据支持已观察的局部血价、生成容量及开场端点，但不足以推出新的SL门槛、持药价或终局权重。既有窄实现已进入live祖先，不把子项完成报成整项duplicate/implemented。逐项证据、反例、旧/期望行为、账本及验证方法见本目录proposal.md。

## 身份和输入

本批learn.json task=strategy-proposal、character=silent、reason=proposal，worktree精确匹配；proposal_ids恰为下表十项，无proposal_repair、research_request或implementation_request。普通专题候选notes/strategy-research-silent.json绑定的是其他旧批次，故未读取其work_spec/manifest、不将队列转专题。

先读README、STATE-2026-10-15、decision-log末尾、学习协议和代码提案闭环；再核runs.jsonl角色，提取本批十个锚点加原提案五个关联来源，不扩大到其他待办。原提案Markdown均实际存在且SHA匹配，31条关联账本均为silent；26个所关联经验条目只读核对，未以其后来的其他来源局替代本批原始验证。

运行模型/强度：本工具接口不提供当前模型请求参数自省；没有据仓库默认值或历史run-config冒称核实本会话原生设置，也没有改模型/预算/线程。

## 证据抽取和核验

共用extract_evidence.py冻结每流source_size，逐选中行保留source、line、offset、bytes、SHA256和显式所属身份。独立从只读原日志按offset重读全部选中行，逐字节SHA、JSON、身份及计数核对；states另核角色/进阶。详见evidence/evidence-manifest.json和evidence-verification.json。

| 流 | source_size字节 | 选中行 | 无效JSON | 截断行 |
|---|---:|---:|---:|---:|
| states | 13249591779 | 9815 | 2 | 0 |
| decisions | 1734215225 | 9448 | 2 | 0 |
| sl-attempts | 41811138 | 78 | 0 | 0 |
| run-config | 1801780 | 15 | 0 | 0 |
| run-plans | 8271446 | 77 | 0 | 0 |
| brain | 620209029 | 481 | 1 | 0 |
| runs | 340320 | 15 | 0 | 0 |
| fight-plans | 2233957 | 0 | 0 | 0 |

共19929条材料行。fight-plans为该冻结截点零行，不解释为源日志不存在；源文件和截点均已记录。无效JSON不补造。

逐局身份/进阶/胜负原行保存在verified-runs.json；以下各局均silent，原code含dirty的历史不能由当前源码完整还原，原统计引擎来源不冒作纯Codex战绩。

| 局号 | 进阶 | 结束层 | 原记录胜利 | 本批锚点 |
|---|---:|---:|---|---|
| K3676LU8B0UH | 1 | 48 | true | 原提案关联 |
| SADL3CGYTGSR | 7 | 48 | false | 原提案关联 |
| F4QKG4J1AJJZ | 9 | 38 | false | 是 |
| JLN5SK17W4FQ | 10 | 33 | false | 是 |
| 4D4J8USKCPAV | 10 | 17 | false | 是 |
| S9UZAK0JP0C0 | 10 | 33 | false | 是 |
| NB8KCF6HRGVF | 10 | 31 | false | 是 |
| LS8035TB32P3 | 10 | 42 | false | 是 |
| 02HB4L0C3C67 | 10 | 12 | false | 是 |
| KEN58SH9SLZ6 | 10 | 17 | false | 是 |
| TXZ6RVMQA09D | 10 | 49 | false | 是 |
| WQZVENQ7DTRP | 10 | 33 | false | 是 |
| 1913SE84AXQF | 10 | 31 | false | 原提案关联 |
| Q6M2Y34MWKRE | 10 | 9 | false | 原提案关联 |
| NHA2KW0RB7VP | 10 | 33 | false | 原提案关联 |

## 固定材料和消费者边界

material-assertions.json共38条材料断言通过，包括KEN七饮/三pending及两次回血、TXZ少损3少推进9与4→0入口、WQ多推进15多付9及沙坑4→5→4、Q6普通紧勒103→95→85→83→80、胜战57→2接后战死、1913锻造不回血、NHA可操作基线与多付6多推进16。166次饮药相邻观察和其中42次狡诈3/2/0生成详见potion-observations.json；不是重新建立所有历史经验分母或逐来源因果。

用当前learner/audit-selection.ts离线读取六个固定局。完整原输入均保存；KEN一行、1913两行、Q6一行map/route-change元数据缺decision_id，另存有界输入排除这四行后调用，不能称完整局通过。没有把原文件补id或改写原日志；其余三局直接调用完整输入。

| 局号 | 输入范围 | rc | 选择段 | 动作 | 轮窗 | 已核轮端点 | 未知轮窗 |
|---|---|---:|---:|---:|---:|---:|---:|
| KEN58SH9SLZ6 | 有界：排除无id路线元数据 | 0 | 96 | 547 | 112 | 70 | 42 |
| TXZ6RVMQA09D | 完整 | 0 | 147 | 762 | 135 | 29 | 106 |
| WQZVENQ7DTRP | 完整 | 0 | 243 | 766 | 127 | 63 | 64 |
| 1913SE84AXQF | 有界：排除无id路线元数据 | 0 | 45 | 396 | 65 | 6 | 59 |
| Q6M2Y34MWKRE | 有界：排除无id路线元数据 | 0 | 18 | 130 | 21 | 0 | 21 |
| NHA2KW0RB7VP | 完整 | 0 | 105 | 584 | 96 | 20 | 76 |

共654段/3185动作、556轮窗，其中188轮端点可核，368未知；相邻动作端点1121。整候选实际结果认证0。所有input/output/stderr SHA在consumer-receipts.json。轮端点、净HP差或单动作completed仍不能证明完整候选归属、未截顶来袭、逐实体毛伤或替线因果；本批没有撤源码负控。

这些是材料核验和离线消费者调用，非生产tsc/vitest测试、整战模型校准或实盘收益检验；无源码修改，tests固定为{"tsc":null,"vitest":null,"cases":null}。

## 当前实现读回

固定读取live提交 `cfa1c0be88147b4eac65c13d8c550b23ed4eef17`，18个相关源码叶中15个与base逐字节一致，3个仅历史Dai/Roy注释差异，原patch保存在base-vs-live-comment-differences.patch；未做转译等价/完整测试声称。18个叶的最后源码提交均为该live真实祖先，live磁盘叶与该提交叶SHA一致。逐叶SHA及祖先结果见source-readback.json。

| 已有实现范围 | 实际live祖先源码commit | 未覆盖范围 |
|---|---|---|
| 狡诈生成/容量 | 5b56a452bb9be14d620b368ec46974c1b57901ca | 保留、穿插、恢复、整战校准 |
| 普通紧勒及原传播 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 未覆盖模板和联合后继 |
| 选择审计及持牌损失事实 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 实际整轮actual_turn仍null |
| 单动作派发回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | whole_plan_executed仍null |
| 蟹朝向/虚弱取整限定分支 | 68711002f15b298b8863d2258ee5da236da151d2 | 油灯消费身份及未见组合 |
| 开场4血已观察组合 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 | 未见回血/复活顺序及完整资源替线 |

以上六源码均核为本批base与固定live提交祖先，属既有实现，不登记为本批fix或合入。新战开场、当前T1、SL恢复分支保持原边界；当前进阶数据库使用方式保持，未设新房间样本门槛。

## 十项最终处置

| 提案 | 状态 | 具体缺口 |
|---|---|---|
| silent-proposal-08eaa60bcc449852 | waiting | 缺F15未饮用及同入口、同后继留药至Boss的完整成对结果；七次实际饮药和回血端点不能校准持药价。 |
| silent-proposal-92920295a648b540 | waiting | 缺保持抽序、生成和药栏一致的两战完整替线；现有开场扣血及接续源码不覆盖SL资源比较和连续通关校准。 |
| silent-proposal-a327449c331efbc1 | waiting | 缺攻防与沙坑双边界的完整受控后继、候选跨重规划执行绑定及独立胜局；当前端点不能定新SL血价门槛。 |
| silent-proposal-a099e89437e942bb | waiting | 确定生成与容量已有live窄实现；仍缺计划妥当保留、穿插出刀、整候选实际派发和SL恢复的联合校准，不能关闭整项。 |
| silent-proposal-47910f82a1fdd98f | waiting | 开场4血窄分支已有live实现；缺留药、路线及SL完整后继对照和未知回血/复活组合的结算顺序，不能据子项关闭联合要求。 |
| silent-proposal-f1374df72d8e6a25 | waiting | 缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战及下一战后继，不能由已执行的两条失败链校准资源权重。 |
| silent-proposal-38a49e6c97f31eea | waiting | 普通紧勒已有live窄实现；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准和受控整战后继。 |
| silent-proposal-ef0e38a5dbd3bc07 | waiting | 缺另一营火、事件、路线和用药时机的受控完整结果；实际两条资源链只能复核兑现，不能拟合路线或终局权重。 |
| silent-proposal-7f820c02d39bfaea | waiting | 缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对完整后继；六次同局失败不足确定新SL阈值。 |
| silent-proposal-04b6b430759815ed | waiting | 蟹朝向窄分支已有live实现；缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及未覆盖X值、升级组合和能力整战后继。 |

## 记录与限制

通过根目录learner/ledger.py update为31条本角色既有账本追加本批proposal/report位置和复核说明，输入/CLI回执/写后读回保存在ledger-updates.jsonl、ledger-update-receipt.json、ledger-protection-check.json。没有新增重复提案或经验，没有改claim、首证、prior、evidence、status或version；既有shipped窄条目不降级，宽代码提案继续waiting，调度状态由原宿主接续。

未重建原105/107/109局路线统计，不借当前经验后来汇总扩大本批原始审计覆盖；十五来源局SL不增独立样本，A1/A7/A9与A10分列。没有完整受控留药/路线后继、跨抽弃牌候选身份或油灯恢复链，不造新打法、门槛、源码合入或shipped。没有需要新增通知的不同结论/反证，也不关闭学习入库父要求。

准备过程中一次过宽的账本打印被工具截断；完整ledger-before.json已保存，后续只读31条限定字段。两次源码/测试路径探针使用了旧布局，出现No such file；后按rg实际路径读取hand/loop与现有离线入口。没有据这些准备错误报告产品bug或测试失败。材料断言首轮38/38通过，未重跑；六次离线调用均成功，各自范围如上。

无源码更改，撤源码失败/恢复通过不适用，tsc/vitest未跑；没有源码提交、merge、版本、上线记录或规则变更双通知。gitleaks仅扫描本批新写报告、提案、结果及账本CLI输入；结果见delivery-validation.json，不能替代全仓扫描。工作树最终干净且HEAD保持base，交宿主核验；所有scratch和原件保留，不自行清理。

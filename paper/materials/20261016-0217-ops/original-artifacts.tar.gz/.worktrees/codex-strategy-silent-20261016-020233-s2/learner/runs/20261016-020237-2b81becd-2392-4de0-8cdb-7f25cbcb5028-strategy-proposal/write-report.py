import collections
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = 'd523c467cb0e00cfbf181f4490ba6a4d0fbf1ba1'
BATCH = '20261016-020233-s2-strategy-proposal'
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'proposals-before.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
receipts = json.loads((OUT / 'consumer-receipts.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
runs = json.loads((OUT / 'verified-runs.json').read_text())
rows = [
    ('赢战耗药及回血结转',
     'KEN58SH9SLZ6 A10：F3T2、F4T1、F5T2、F11T1/T2、F15T1共七次饮药；decisions 274131/274156/274185/274235/274237/274267/274272。F5 states 280255→280284为53→16，净损37；F12 280336→280337为26/76→53/81，实回27；F16 280382→280383实回29。',
     '现有持药价值暂保留。期望能比较前战实际耗药与下一战资源；本批只核相邻状态和实际已到达回复，不将SL恢复或未来营火记成新增资源。七次中三原pending回执保持原文；后帧有消费观察不把接口状态改称completed。',
     'F15零损但确实用两瓶药；未走路线、未饮药或留药至Boss均无同入口完整实打对照。',
     '缺F15未饮用及同入口、同后继留药至Boss的完整成对结果；七次实际饮药和回血端点不能校准持药价。',
     '固定回放七次槽位消费与两次真实回复；将用药/不用药/留药的同预算整战后继分组，并按独立局开始时间留出验证。'),
    ('SL首战改善与连续通关分开',
     'TXZ6RVMQA09D A10 F48T6：states 281479→281484原线48→45、敌460→424，替线281535→281539为48→48、敌460→433；少损3同时少推进9。F48T10/F49T1 281563→281565→281566为4→4→0；敌111未变化。',
     '首战和第二战资源接续已有接口；下一新战开场4血的已观察组合已建模。现有SL诊断仍区分候选预测与实际执行；原低可信模拟不作必死证明。期望验证完整两战替线及可操作入口，而非只验证首战胜率。',
     '第三尝试首战赢却后战开场死；后续生成/抽序/打法同时改变，一次局内三尝试不能当三个独立胜率样本。',
     '缺保持抽序、生成和药栏一致的两战完整替线；现有开场扣血及接续源码不覆盖SL资源比较和连续通关校准。',
     '固定两T6窗口及F49开场帧必须吻合；完整后继对照须隔离SL恢复，保留首胜但后败结果与低可信限制。'),
    ('沙虫SL血价与双截止边界',
     'WQZVENQ7DTRP A10 F33第2/3次T9，states 282075/282144指纹相同。原线至282079损13、推进24；替线至282148损22、推进39。末次T7 282330→282336损4，沙坑出牌前4、出逃后5、次轮4。',
     '既有SL候选比较和选择/派发审计已提供预测及单动作回执。期望跨重规划比较完整实际血价、输出和沙坑；不由全败率并列判为同等安全，不拟固定9血换15伤门槛。',
     '末次T7付4血确实延长沙坑，构成“所有多损换线都应禁止”的反例约束；本局六试均未通关，仍缺完整受控胜线。',
     '缺攻防与沙坑双边界的完整受控后继、候选跨重规划执行绑定及独立胜局；当前端点不能定新SL血价门槛。',
     '同时复现13/24与22/39、沙坑4→5→4，毒只计已结部分；补全重问后实打续步，不延长已验证SL前缀。'),
    ('狡诈生成容量及保留的联合路径',
     '02HB4L0C3C67、4D4J8USKCPAV、F4QKG4J1AJJZ、JLN5SK17W4FQ、LS8035TB32P3、NB8KCF6HRGVF、S9UZAK0JP0C0、SADL3CGYTGSR、WQZVENQ7DTRP九局42次饮用；37次添3、2次添2、3次添0，新刀均升级且基础6，缺容量只在WQ F33第5/6次T11。每次决策层/回合及原始引用在potion-observations.json。',
     '原文所称“未建模”已过时：当前狡诈模型与求解器已有确定生成、实际手位裁剪和未施放后缀。对应窄源码5b56a452bb9be14d620b368ec46974c1b57901ca在base/live均为祖先；完整保留/穿插/恢复的提案仍开放。',
     '满手续喝实际耗药却不增牌，不能把37次足位分支外推为永远加3；没有穿插用刀整战获胜的对照。',
     '确定生成与容量已有live窄实现；仍缺计划妥当保留、穿插出刀、整候选实际派发和SL恢复的联合校准，不能关闭整项。',
     '保持42次生成3/2/0及新增刀基础6夹具；对保留、先出刀再喝、重问和SL恢复逐步绑定实际牌身份与后继，未证组合留未知。'),
    ('开场血价与连续资源、SL联合验证',
     'TXZ6RVMQA09D F48T10→F49T1实际4→0；WQZVENQ7DTRP F33T9多推进15付9血、末T7延时付4血；具体原始行同第2/3项。',
     '已观察的开场4血限定组合和第二Boss资源接续已有实现；ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8为base/live祖先。保留原ROYAL_POISON+BLOOD_VIAL净值观察及未知内部顺序，不扩充未观察回血/复活组合。',
     'TXZ首胜留4不代表连续通关，WQ延时也不代表挡住攻击；缺资源组合不能从两个净值拆出通用结算顺序。',
     '开场4血窄分支已有live实现；缺留药、路线及SL完整后继对照和未知回血/复活组合的结算顺序，不能据子项关闭联合要求。',
     '先核入口与实际资源继承，再做同入口整战比较；不开泛化扣血、SL资格或药价的新分支。'),
    ('胜战退出资源与下一战价值',
     '1913SE84AXQF A10 F28 states 282720→282721回21到61，F29 282723→282749损15到46，F31入口282755为46；Q6M2Y34MWKRE F7 282869→282870回21到57，F8胜后282911为2，F9 282913→282921由2到0。',
     '期望将实际退出HP、药栏及临时/持续药效接入后继比较；现连战接口与药物模型不等于所有路线的整战资源估值已校准。当前血价/持药权重保留。',
     'Q6确实选择休息且最终用掉两瓶药，F5/F6零损留药不能用作“都应早喝”的证明；F2早用候选未完整实打。1913的锻造改变了原路线条件。',
     '缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战及下一战后继，不能由已执行的两条失败链校准资源权重。',
     '先核两条实际HP/药栏链及临时属性撤回，隔离紧勒等已修机制误差；较早独立局拟合、后移新局验证，局内SL同组。'),
    ('紧勒与属性、自动触发、恢复联合路径',
     'Q6M2Y34MWKRE A10 F8T4 states 282887—282892敌103→95→85→85→83→80，先攻击8、后攻击8+2、弃牌完成再2、轮末毒3；STRANGLE_POWER2下一轮消失。1913SE84AXQF F31T2—T4弃磨蚀、后继敏捷/荆棘与重接窗口保留在原始状态；不把净推进当毛伤。',
     '普通未升级紧勒在card-model/combat-plan/turn-solver已接线，覆盖条件有明确unknown分支，当前传播源码66283dd9982bdd7f480da7a4d9bfefea0572a9ac为base/live祖先。再生、速度及既有属性模型不能据此宣称所有组合均通过消费者校准。',
     '升级/叠层/自动出牌/有挡及减损不在本项已证普通无挡分支内；弃磨蚀建立不等于整战安全，死后未兑现能力不预支。',
     '普通紧勒已有live窄实现；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准和受控整战后继。',
     '普通链逐帧103/95/85/83/80固定；所有能力按实建、实际触发及毒结算分源，未知组合不按既有窄实现冒认证。'),
    ('营火和前序胜战的连续血价',
     '1913SE84AXQF A10 F24 states 282706—282709锻造前后40，F28回21、F29胜后46，F31死亡；Q6M2Y34MWKRE F7回21、F8赢损55到2、F9死亡，原始引用同第6项。',
     '期望只结转真实已完成回复，保留强制后继需求。当前路径事实与未来投影分开审计，不把未来第三火或未取得能力记入本战资源。',
     '1913后续营火未到达，不能据未实现计划说已有回血；Q6休息后仍死不证明改锻造会赢。原109局/69局等全史数字本批未重新建立，保持原报告范围。',
     '缺另一营火、事件、路线和用药时机的受控完整结果；实际两条资源链只能复核兑现，不能拟合路线或终局权重。',
     '固定实际休息/锻造/事件/幕间/SL分别核验，另路线结果需完整实打或经独立校准的条件模型；不扩大历史统计分母。'),
    ('全败排序与跨弃牌换线执行',
     'NHA2KW0RB7VP A10 F33首试可操作states 283391为30HP、敌408；到T2 283397为29HP、敌400。第五试283478→283483与末试283502→283507均为30→23、敌408→384。实际多推进16、多损6；decisions 277248/277250及277272/277274有替换/重放和弃牌重问。',
     '当前SL仍用B2 notWorse或rollout deathShare门槛，并已有候选差额、选择阶段、单动作派发与离线端点审计；期望绑定弃牌后整线实际结果再验证排序，当前保留生产门槛。',
     '原未就绪帧283390为28HP/敌428，不能替代可操作30HP/408基线；六次失败、无整轮击杀，不证明原答可赢，也不以预测21伤当跨轮实际净推进24。',
     '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对完整后继；六次同局失败不足确定新SL阈值。',
     '原答/SL替换/重问后实际动作分开，固定1→7损与8→24推进；抱抱先生轮初自动伤分列，不强认整个回合归某一候选。'),
    ('油灯首次消费、蟹取整与能力兑现',
     'NHA2KW0RB7VP A10 F33T1 states 283395实−2力/2弱；首试T2 283399末15挡、283400实际损7。K3676LU8B0UH A1 F30T2与SADL3CGYTGSR A7 F45首次施毒窗口保留原件，不能混作A10独立样本。原提案还含NHA F17、F19/F30/F33的手数、敏捷与能量条件。',
     '蟹已证虚弱/朝向小分支源码68711002f15b298b8863d2258ee5da236da151d2在base/live为祖先，当前读取对应进阶怪物数据库而非从低阶猜伤。油灯首次消费身份跨出牌、换战、SL的完整连续状态仍非该窄实现范围。',
     '首次翻倍不等于后续持续翻倍；已拥有步法/毒雾或第三轮能量不等于提前兑现。只见现场−2力/1弱取整不推出通用负力公式或未观察X/升级组合。',
     '蟹朝向窄分支已有live实现；缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及未覆盖X值、升级组合和能力整战后继。',
     '保持已证毒/萎靡首次效果及蟹1→2现场，不把显示已取整数再乘倍率；只有同输入同状态身份和实际触发齐全才扩分支。'),
]
assert len(rows) == len(proposals) == 10
parts = [f'# 本批静默猎手十项提案复核\n\n记录时间：2026-10-16T02:10:43+08:00。批次 `{BATCH}`。\n\n'
         f'基线 `{BASE}`，普通已派队列任务；没有research_request/implementation_request，不承接另一个专题。工作树开工干净，`git merge --no-edit main` 返回已最新，HEAD不变。\n\n'
         '只复核本批十个原CLI提案，保存原Markdown且十份SHA全部匹配。来源任务及实现任务链接沿各原提案；本批不新建重复id、不改原文。只使用核实为silent的15个关联局：A1一局、A7一局、A9一局、A10十二局；不合并进阶统计，不把SL当独立局。\n\n'
         '结果：十项均waiting。以下已存在窄源码仅说明部分实现；不把它们登记为本批实现，不关闭宽提案。\n']
results = []
for q, (title, evidence, behavior, counter, reason, validation) in zip(proposals, rows):
    ident = q['id']
    parts.append(f'## {title}\n\n提案：`{ident}`。账本：'+ '、'.join(q['ledger']) +
        f'。原件：`{q["proposal"]}`；SHA256 `{q["proposal_sha256"]}`。\n\n'
        f'证据与层/回合：{evidence}\n\n旧/当前与期望行为：{behavior}\n\n反例和未知：{counter}\n\n'
        f'处置：waiting。{reason}\n\n验证方法：{validation}\n')
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
parts.append('## 拟合、预期影响及回退\n\n本批没有拟合参数、修改策略或经验文本。只对既有主张做固定材料核验，不用候选模拟样本充当独立实盘样本。若后续实现，先隔离机制误差，按角色、已观察进阶、独立局和开始时间切分；同局SL同组，完整后继缺失保留unknown。预期仅改善追溯材料，未证策略收益。\n\n没有本批源码提交或行为变更，因而无源码回退、eval新版本、上线记录或Roy规则变更通知。将来实现按单项源码提交回退，不覆盖知识刷新、原日志和并行修改。账本只追加本批报告/提案位置及复核说明，不改claim、首证、prior、证据、状态或版本，不倒填shipped。\n')
(OUT / 'proposal.md').write_text('\n'.join(parts))

counts = {key: sum(r['counts'][key] for r in receipts) for key in receipts[0]['counts']}
report = [f'# 静默猎手策略提案处置报告\n\n批次 `{BATCH}`；记录时间2026-10-16T02:10:43+08:00。\n\n'
          f'十项已派提案全部复核并保留waiting；未改源码或知识。base=`{BASE}`，fixes=[]，merged=null。工作树HEAD保持原基线，未创建提交、未合live、未新增eval版本。\n\n'
          '本批证据支持已观察的局部血价、生成容量及开场端点，但不足以推出新的SL门槛、持药价或终局权重。既有窄实现已进入live祖先，不把子项完成报成整项duplicate/implemented。逐项证据、反例、旧/期望行为、账本及验证方法见本目录proposal.md。\n\n'
          '## 身份和输入\n\n本批learn.json task=strategy-proposal、character=silent、reason=proposal，worktree精确匹配；proposal_ids恰为下表十项，无proposal_repair、research_request或implementation_request。普通专题候选notes/strategy-research-silent.json绑定的是其他旧批次，故未读取其work_spec/manifest、不将队列转专题。\n\n'
          '先读README、STATE-2026-10-15、decision-log末尾、学习协议和代码提案闭环；再核runs.jsonl角色，提取本批十个锚点加原提案五个关联来源，不扩大到其他待办。原提案Markdown均实际存在且SHA匹配，31条关联账本均为silent；26个所关联经验条目只读核对，未以其后来的其他来源局替代本批原始验证。\n\n'
          '运行模型/强度：本工具接口不提供当前模型请求参数自省；没有据仓库默认值或历史run-config冒称核实本会话原生设置，也没有改模型/预算/线程。\n\n'
          '## 证据抽取和核验\n\n共用extract_evidence.py冻结每流source_size，逐选中行保留source、line、offset、bytes、SHA256和显式所属身份。独立从只读原日志按offset重读全部选中行，逐字节SHA、JSON、身份及计数核对；states另核角色/进阶。详见evidence/evidence-manifest.json和evidence-verification.json。\n\n'
          '| 流 | source_size字节 | 选中行 | 无效JSON | 截断行 |\n|---|---:|---:|---:|---:|']
for x in manifest:
    report.append(f'| {x["stream"]} | {x["source_size"]} | {sum(x["counts"].values())} | {x["invalid_lines"]} | {x["incomplete_lines"]} |')
report.append(f'\n共{sum(sum(x["counts"].values()) for x in manifest)}条材料行。fight-plans为该冻结截点零行，不解释为源日志不存在；源文件和截点均已记录。无效JSON不补造。\n\n'
              '逐局身份/进阶/胜负原行保存在verified-runs.json；以下各局均silent，原code含dirty的历史不能由当前源码完整还原，原统计引擎来源不冒作纯Codex战绩。\n\n'
              '| 局号 | 进阶 | 结束层 | 原记录胜利 | 本批锚点 |\n|---|---:|---:|---|---|')
for run, info in runs.items():
    report.append(f'| {run} | {info["ascension"]} | {info["floor"]} | {str(info["victory"]).lower()} | {"是" if run in dispatch["runs"] else "原提案关联"} |')
report.append('\n## 固定材料和消费者边界\n\nmaterial-assertions.json共38条材料断言通过，包括KEN七饮/三pending及两次回血、TXZ少损3少推进9与4→0入口、WQ多推进15多付9及沙坑4→5→4、Q6普通紧勒103→95→85→83→80、胜战57→2接后战死、1913锻造不回血、NHA可操作基线与多付6多推进16。166次饮药相邻观察和其中42次狡诈3/2/0生成详见potion-observations.json；不是重新建立所有历史经验分母或逐来源因果。\n\n'
              '用当前learner/audit-selection.ts离线读取六个固定局。完整原输入均保存；KEN一行、1913两行、Q6一行map/route-change元数据缺decision_id，另存有界输入排除这四行后调用，不能称完整局通过。没有把原文件补id或改写原日志；其余三局直接调用完整输入。\n\n'
              '| 局号 | 输入范围 | rc | 选择段 | 动作 | 轮窗 | 已核轮端点 | 未知轮窗 |\n|---|---|---:|---:|---:|---:|---:|---:|')
for x in receipts:
    c = x['counts']
    report.append(f'| {x["run_id"]} | {"完整" if x["scope"]=="complete" else "有界：排除无id路线元数据"} | {x["returncode"]} | {c["segments"]} | {c["actions"]} | {c["turns"]} | {c["turn_endpoints"]} | {c["turns"]-c["turn_endpoints"]} |')
report.append(f'\n共{counts["segments"]}段/{counts["actions"]}动作、{counts["turns"]}轮窗，其中{counts["turn_endpoints"]}轮端点可核，{counts["turns"]-counts["turn_endpoints"]}未知；相邻动作端点{counts["interval_endpoints"]}。整候选实际结果认证0。所有input/output/stderr SHA在consumer-receipts.json。轮端点、净HP差或单动作completed仍不能证明完整候选归属、未截顶来袭、逐实体毛伤或替线因果；本批没有撤源码负控。\n\n'
              '这些是材料核验和离线消费者调用，非生产tsc/vitest测试、整战模型校准或实盘收益检验；无源码修改，tests固定为{"tsc":null,"vitest":null,"cases":null}。\n\n'
              '## 当前实现读回\n\n'
              f'固定读取live提交 `{source["live_head"]}`，18个相关源码叶中15个与base逐字节一致，3个仅历史Dai/Roy注释差异，原patch保存在base-vs-live-comment-differences.patch；未做转译等价/完整测试声称。18个叶的最后源码提交均为该live真实祖先，live磁盘叶与该提交叶SHA一致。逐叶SHA及祖先结果见source-readback.json。\n\n'
              '| 已有实现范围 | 实际live祖先源码commit | 未覆盖范围 |\n|---|---|---|\n'
              '| 狡诈生成/容量 | 5b56a452bb9be14d620b368ec46974c1b57901ca | 保留、穿插、恢复、整战校准 |\n'
              '| 普通紧勒及原传播 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 未覆盖模板和联合后继 |\n'
              '| 选择审计及持牌损失事实 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 实际整轮actual_turn仍null |\n'
              '| 单动作派发回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | whole_plan_executed仍null |\n'
              '| 蟹朝向/虚弱取整限定分支 | 68711002f15b298b8863d2258ee5da236da151d2 | 油灯消费身份及未见组合 |\n'
              '| 开场4血已观察组合 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 | 未见回血/复活顺序及完整资源替线 |\n\n'
              '以上六源码均核为本批base与固定live提交祖先，属既有实现，不登记为本批fix或合入。新战开场、当前T1、SL恢复分支保持原边界；当前进阶数据库使用方式保持，未设新房间样本门槛。\n\n'
              '## 十项最终处置\n\n| 提案 | 状态 | 具体缺口 |\n|---|---|---|')
for x in results:
    report.append(f'| {x["id"]} | waiting | {x["reason"]} |')
report.append('\n## 记录与限制\n\n通过根目录learner/ledger.py update为31条本角色既有账本追加本批proposal/report位置和复核说明，输入/CLI回执/写后读回保存在ledger-updates.jsonl、ledger-update-receipt.json、ledger-protection-check.json。没有新增重复提案或经验，没有改claim、首证、prior、evidence、status或version；既有shipped窄条目不降级，宽代码提案继续waiting，调度状态由原宿主接续。\n\n'
              '未重建原105/107/109局路线统计，不借当前经验后来汇总扩大本批原始审计覆盖；十五来源局SL不增独立样本，A1/A7/A9与A10分列。没有完整受控留药/路线后继、跨抽弃牌候选身份或油灯恢复链，不造新打法、门槛、源码合入或shipped。没有需要新增通知的不同结论/反证，也不关闭学习入库父要求。\n\n'
              '准备过程中一次过宽的账本打印被工具截断；完整ledger-before.json已保存，后续只读31条限定字段。两次源码/测试路径探针使用了旧布局，出现No such file；后按rg实际路径读取hand/loop与现有离线入口。没有据这些准备错误报告产品bug或测试失败。材料断言首轮38/38通过，未重跑；六次离线调用均成功，各自范围如上。\n\n'
              '无源码更改，撤源码失败/恢复通过不适用，tsc/vitest未跑；没有源码提交、merge、版本、上线记录或规则变更双通知。gitleaks仅扫描本批新写报告、提案、结果及账本CLI输入；结果见delivery-validation.json，不能替代全仓扫描。工作树最终干净且HEAD保持base，交宿主核验；所有scratch和原件保留，不自行清理。\n')
(OUT / 'report.md').write_text('\n'.join(report))
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
          'base': BASE, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'proposal': str(OUT / 'proposal.md'), 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

ledger = json.loads((OUT / 'ledger-before.json').read_text())
with (OUT / 'ledger-updates.jsonl').open('w') as handle:
    for ident in ledger:
        links = [q['id'] for q in proposals if ident in q['ledger']]
        update = {'id': ident, 'by': 'learner:strategy-proposal',
                  'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                  'note': f'本批{BATCH}复核已派提案'+','.join(links)+'；逐项waiting原因见本批proposal.md。15个silent关联局按原字节核验，38条材料断言和六次有界/完整离线消费者调用不当整候选执行或整战校准。仅追加追溯；原主张、证据、状态、版本保持；无新源码/合入。'}
        handle.write(json.dumps(update, ensure_ascii=False) + '\n')
print(json.dumps({'proposal_results': len(results), 'ledger_updates_prepared': len(ledger), 'material_rows': sum(sum(x['counts'].values()) for x in manifest), 'audit_counts': counts}, ensure_ascii=False))

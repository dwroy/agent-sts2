# 静默策略批次回报

记录时间：2026-10-15 02:25:48 CST（写前已运行date），精确CLI时间另见ledger回执。

基线 `014e6dbd150d3323f61c8c00e52ea8174754ea38`；普通main合并已是最新。十个派发id及原文SHA均已核，全部waiting；没有源码改动、提交、live合入或新版本。逐项证据/账本/反例/旧行为/预期行为/验证和回退边界见 [proposal.md](proposal.md)，完整机器回报见 [report.json](report.json)。

共用抽取入口八流6995原行经原日志offset/bytes/SHA与角色身份复核；六局均SILENT/A10。限定消费者输入693决策、715状态；原行号未重编，缺decision_id元数据单独保存。现有离线审计六次退出0：139片段、505连续动作观测区间、76整轮窗口；完整候选实际结果仍null。42条材料事实断言通过。以上均不是生产tsc/vitest或新源码自测；tests={tsc:null,vitest:null,cases:null}，撤源码红绿不适用。

相关13源码叶与live对照：11同字节、2仅历史署名注释拼写差，每叶实际live祖先和SHA见source-live-proof.json。已有窄实现不能认证十宽提案全部交付。没有足够证据追加新规则；未拟合新血价/SL/药水/终局权重。

| 提案 | 结果 | 尚缺证据 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 已有窄神化传播；缺跨抽牌、选牌、药水、SL与换战的实际施放持续身份和未覆盖交互校准。 |
| silent-proposal-f2bfceddb1898dca | waiting | 707ms退化原帧已核；缺完整模型下同起点、同随机池、同总预算的分阶段MC配对和候选稳定性曲线。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化经验链已核；原提案持续身份及交互范围未完整交付，不能登记整项duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 局部升级及现场资源已核；缺十五条机制的属性组合、期限和战斗/路线/休息消费者联合校准。 |
| silent-proposal-e5b87be50f28f311 | waiting | 实损3/15血、扣敌10/17与末端截断已核；缺跨重规划候选持续身份及完整生产归属校准。 |
| silent-proposal-49632bc4878fb597 | waiting | 蚌力量4/8和喷水11/15/19已核；本局无正敏捷实测，缺逐击属性、虚弱及独立成长联合校准。 |
| silent-proposal-66532328a585941f | waiting | 无毒冒泡耗1能且目标35血不变已核；缺同HP、构筑、药水和完整抽序下不同启动顺序的整战对照。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 吸取后负敏捷和17毒原帧已核；缺同起点、同抽序的生产整战配对及另一可核SL线路。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 航行力量3/6及T4扣47仍留幻象2血已核；缺A10召唤、复现、退场全链校准和另一focus完整后继。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 睡层3/2/1、醒后力量2/4及攻击22已核；缺伤害唤醒/眩晕接续全链校准和同抽换序后继。 |

原26条账本只经根ledger CLI追加by/where/note追溯，保留全部claim/evidence/first_run/prior/status/version。输入ledger-updates.jsonl，实际回执ledger-update.log，语义保持复核ledger-trace-verification.json；不重复注册提案，不手改队列，不标implemented/duplicate/shipped。

限制：本批是六局旧A10证据复核，SL尝试不扩分母；旧dirty源码完整差异未知；原始日志未选中fight-plans仅表示本截点0行，不证明流缺失。固定消费者遇到缺尝试身份或模糊实体保持unknown，不能把净HP差当完整入伤、候选因果或胜率收益。其他进阶/角色不外推。

过程首败和限制保留于proposal.md末尾：一次沙箱准备拒止、一次scratch apply_patch失败、一次只读ledger折叠调用错误；均修正后继续，未冒记代码测试失败或成功。没有运行play、网络、LLM或安装依赖，不改运维prompt/账号/请求/源码/知识。

工作树HEAD与基线保持一致，最终状态与差异见final-verification.json；所有过程材料留在本批scratch，供运维按proposal_results登记和后续新局重派。

# 静默策略提案逐项复核

记录时间：2026-10-15 02:23:14 CST（写前已运行 date）。批次 `20261015-021302-strategy-proposal`；角色 silent；本批六局均为 A10。

基线为 `014e6dbd150d3323f61c8c00e52ea8174754ea38`。开工工作树干净，普通提案分支执行 `git merge --no-edit main`，结果 Already up to date。根 learn.json 本批为 task=strategy-proposal、reason=proposal，工作树与任务一致，明确派发十个 proposal_ids，无 proposal_repair、research_request 或 implementation_request。普通专题文件绑定另一旧批次，因此本批沿原十项提案消费，不切换专题，也不扩展队列。原始派发行保存在 dispatch.json。

## 证据边界与核验

原提案十份 Markdown 均按专用队列 SHA256 核对，原字节副本以 `<提案id>.md` 保存；未改原文、未注册重复 id。对应26个原账本的历史和正确折叠结果保存于 ledger-selected-history.json、ledger-selected-folded.json。账本 shipped 仅说明原窄经验/源码的历史状态，不能代替宽提案验收。

通过共用 `learner/extract_evidence.py` 从指定 logs 只读抽取八流，冻结 source_size 并逐行保留原行号、offset、bytes、SHA256与原文。prepare-evidence.py 再从原日志逐条寻址，复核内容、SHA、截点、唯一显式身份和计数；全部6995行通过。states=3432、decisions=3306、sl-attempts=29、run-config=6、run-plans=33、brain=183、runs=6、fight-plans=0。原流解析失败数（states2、decisions2、brain1）是整个扫描范围的计数，未据此推断属于本批。fight-plans 的0仅表示本截点没有按显式身份选中本批行，不能声称原日志不存在。

| 局号 | 原states | 原decisions | 离线消费者限定层 | 消费决策/状态 |
|---|---:|---:|---|---:|
| VLZ6CCT8AQ0A | 729 | 699 | F35、F43、F45 | 99/105 |
| 8JRE1C4H4Z2W | 676 | 659 | F17、F33 | 277/280 |
| CA5KE8GFJ9X2 | 282 | 265 | F13 | 26/33 |
| 5PM6JAQG6FNQ | 660 | 638 | F33、F39 | 114/116 |
| 61E2QS63Y9WU | 462 | 443 | F17、F23 | 60/63 |
| DUZUBAJ3A8GP | 623 | 602 | F30 | 117/118 |

本次只用以上六局的游戏事实；没有搬用其他角色知识，也不把同局SL尝试扩成独立局。六局 runs.code 均带 dirty，原运行树完整差异未冻结；目前源码可作现状对照，不能冒作完全重现2026-10-07的运行代码。没有把旧 deepseek_calls 记录归零或篡改引擎口径。

## 逐项处置

下列每项均为 **waiting**。这是原提案整体的处置；已存在的窄机制保留，不能因同源、已上线子项或一组快照而登记整项 duplicate。

### silent-proposal-89354805ee4d7e77：神化传播及实际施放身份

- 账本 silent-0237、silent-0238；来源 postmortem；目标 strategy-proposal。
- VLZ6CCT8AQ0A F35 T1，states275564→275565：神化施放后能量7→5，防御5→8、打击7→10、匕首雨每击5→7、必备工具1费→0。F43 T1 states275679→275687，90→77血、敌254→203；T2实际抽到升级毒雾，场外deck升级数仍4。F45 T1 states275731→275732，未升级神化与生存者同在手牌，随后手牌清空，没有神化升级兑现。
- 现状已有 `772b839f8ada31664cb764ea9ad3bdb03da27f64` 起的窄传播和后续观察对，`b2805be4ba44b7375c7908d873889372cc3cfe6c` 补萎靡；均为实际live祖先。`silent-apotheosis-reference.ts` 的 `actual_cast_this_fight` 仍明确为null；solver保留重放、自动出牌及未验证属性组合的unknown。
- 缺跨抽牌、选牌、药水、重问、SL与换战的实际施放持续身份和全部交互校准。本批不能安全把null改成true，也不能只扩大 known 覆盖。
- 反例/限制：F43打过神化仍整战损57；F45没打而失败，两场条件不同，无同盘转胜证明。预期行为仍是状态变换与持有/施放分账，不新增必打优先级。
- 后续验证：冻结本批实际动作身份及这些边界的生产读回，逐段对照升级卡字段和消费者；发现具体缺口才补窄实现。本批无源码回退项。

### silent-proposal-f2bfceddb1898dca：三骑士预算与药水

- 账本 silent-0106、silent-0019、silent-0201；来源 postmortem；目标 strategy-proposal。
- VLZ6CCT8AQ0A F45 T1 decisions269748：MC707ms、1/12样本，rollout horizon1/samples1/best=null。第二问269754虽12/12，起点已变。states275728→275729：HP67→67、能量1→2，实抽必备工具和生存者，不能从“痊愈”名称补造回血。
- F45 T4的保血/攻击线仅是当题预测，未选线没有整战实打。T1与第二问的用时不能组成同起点预算实验。
- 缺完整覆盖模型、同起点/同随机池/同总预算下的分阶段MC配对及候选稳定性曲线；未作此实验，不从707ms硬拟预算常量或留药价。现有成熟度和资源诊断保留，预期只在配对结果可复核时调整预算。
- 验证需固定全输入、完成样本和原始计时，神化缺口与预算效应分离；后续新局按结束时间留出。本批无新阈值及源码回退项。

### silent-proposal-283a164780d11e69：神化经验链

- 账本 silent-0237、silent-0238；来源 experience-update；经验 silent-apotheosis-combat-upgrades；目标 strategy-proposal。
- 证据同本批第一项 VLZ6CCT8AQ0A F35/F43/F45，不把两个提案当两局支持。原Markdown经验链接已核。
- 窄传播已有实际live源码，但第一项持续身份及交互范围仍未完整交付，不能登记整项 duplicate。同样等待跨重规划和换战的消费者验证，不创建重复代码提案或固定收益权重；反例、验证和回退边界沿第一项。

### silent-proposal-ebbfe3b97548756d：十五条机制与资源联合覆盖

- 账本 silent-0005、0016、0049、0071、0143、0046、0053、0027、0011、0021、0106、0204、0020、0019（各均有 silent- 前缀）；来源 experience-update；目标 strategy-proposal。
- 本批直接复核 VLZ6CCT8AQ0A F43 T1升级、T2后续毒雾，F45 T1普通卡及触媒现场。三骑士F45没有已兑现击杀，不能把focus当减员；前置胜局资源不能删去。
- 当前 card-model、turn-solver、rollout 等有逐牌属性、毒与持续状态实现；源码同值不代表十五条经验的全部属性组合、期限和路线/休息消费者均校准。原文引用的历史材料不在本批扩展研究范围，未借其宽分母扩大本批验收。
- 缺十五条机制的组合/升级/状态期限及战斗、路线、休息消费者联合校准。不能以一个神化或步法提交注销整项。
- 保留现有窄机制，不拟合统一保血、输出或休息权重。后续按子机制冻结输入逐项比对，毒的已结算与未来层数分账；本批不新增规则及回退项。

### silent-proposal-e5b87be50f28f311：沙虫SL与护栏实付血价

- 账本 silent-0079、silent-0021、silent-0125、silent-0018；来源 postmortem；目标 strategy-proposal。
- 8JRE1C4H4Z2W F33 首/三试T2 decisions270216/270282指纹相同。现有离线工具从原始连续决策核到首试玩家−3/敌−10、第三试玩家−15/敌−17；SL原日志保留0/24与5/24，不能因预期损血都封顶47便称同死亡率。第二试T5原答损16/伤43，护栏后整轮端点实损4/扣25；未选原线长程结果未知。
- 第六试T11，states **276433→276434**：玩家5→0、敌154→130，显示37攻−22挡=15仅算术参考，未截断实际伤害仍unknown。整轮另从276429起，敌166→130共36；不能把终结算24与整轮36混为同一窗口。
- 现有 silent-selection-audit / silent-hp-guard-audit 记录预测阶段；selection-observation / terminal / turn 已提供离线观测端点。`actual_full_candidate_result`、`actual_rollout_best`和因果归属仍为null，符合其限定合同。
- 缺跨抽牌、选牌、重问、药水、SL的候选持续身份，以及该局完整生产归属校准。离线端点不能冒称在线完整候选已执行或阈值收益。
- 不改SL范围、探索、血价和HP护栏。后续以本批连续原行及身份边界接线生产，再验证原答/护栏/SL/派发各阶段；无新胜线，不假称可救活。宽项保留waiting；本批不回退已上线窄审计。

### silent-proposal-49632bc4878fb597：力量、敏捷、虚弱与蚌成长

- 账本 silent-0005、silent-0231；来源 experience-update；目标 strategy-proposal。
- CA5KE8GFJ9X2 F13，states273237/273252/273263：喷水11→15→19；力量未列出→4→8。末态273268为2HP/10挡，后续零血不能还原未截断入伤。此局无步法建正敏捷事实。
- 原经验需要联合复核，当前属性运算和当前进阶怪物数据入口存在，不能用别局步法实现证明本局正敏捷组合已实证。
- 缺逐击力量、正负敏捷、虚弱及独立成长的同一冻结生产输入与联合校准；不把未列出的power伪造为已观测0值，不凭虚弱关闭成长。
- 保持当前分项计算，不新增统一保血/输出权重。后续按属性路径固定回放，不需要胜局才验机制，但不得缺机制实测而外推；本批无源码回退项。

### silent-proposal-66532328a585941f：持有、启动与已建立

- 账本 silent-0021、silent-0009；来源 experience-update；目标 strategy-proposal。
- 5PM6JAQG6FNQ F39第二试T2 decisions268455，states274379→274380：对无毒THE_LOST打冒泡，能量5→4，目标35血不变、未新增毒、当时未建立毒雾。保留原观察，不借手里有组件预支已建输出。
- F33已建组件的胜战与F39条件不同，不能据两战差异拟合启动权重或宣称先打毒雾必胜。
- 缺同起始HP、构筑、药水及完整抽序的不同启动顺序整战对照和可复现收益函数。当前候选事实/端点可审计，构筑因果未校准。
- 不增加能力固定加分或删掉合法选项；后续固定条件比较启动方案，按run留出验证。本批无新源码回退项。

### silent-proposal-43a76a31ba7bdcfa：族母吸取、毒及SL

- 账本 silent-0030、silent-0027；来源 experience-update；目标 strategy-proposal。
- 61E2QS63Y9WU F17 T5→T6 states273502→273504：玩家力量2后未列出、敏捷−2；敌力2，敌当前毒17。T6两防御的原手牌与后续状态保留，17+16结算与当时触媒1分项核查，不从负力量推断毒失效。
- 精确区分进场58血、随后回复到60；“60血七轮赢”不是原始进场58的替代值。本场获胜不能证明另一SL范围/换线策略。
- 缺同起始HP/牌组/抽序的生产整战配对及另一可核SL线路；没有据首试胜利修改SL名单、阈值或毒优先级。
- 后续固定当前进阶/招式表与原抽序校准吸取、格挡和毒结算；没有另一线结果仍不宣SL收益。本批无新源码回退项。

### silent-proposal-5264153a4a4b0e5c：胧光召唤与实体成长

- 账本 silent-0039、silent-0209；来源 experience-update；目标 strategy-proposal。
- 61E2QS63Y9WU F23 T2/4航行后，states273589/273596本体力量3/6。T4开始25HP、结束到10HP，本体76→41、幻象14→2；总扣47但幻象仍活着，下一轮才退场。本批保留当前A10实见意图，不拿早期召唤测试的16伤代替本局17/20/23。
- 已有 summonsAt/boardRolloutInput 与召唤模型窄实现；现成测试覆盖其他已观察进阶，不等于本批A10全链已经校准，也未证明另一focus优劣。
- 缺A10召唤、航行、复现和退场的生产全链校准及另一focus完整后继。保留全部目标选项，推演相同者并列，不硬定首杀。
- 后续用本局数据冻结当前进阶表逐步比对；未观察替代整战只记未知。本批无新源码回退项。

### silent-proposal-bddfa690a84e03d0：熟睡甲虫睡眠、眩晕和成长

- 账本 silent-0128、silent-0079；来源 experience-update；目标 strategy-proposal。
- DUZUBAJ3A8GP F30 states274906/274914/274919睡层3/2/1，T4醒来；T5/6力量2/4，T6攻击22。该局四次相关尝试不是四局独立样本。
- 已有未知眩晕后继闸与当前进阶数据入口，不能把旧进阶固定夹具代替本局伤害唤醒、眩晕接续及成长的全链校准。
- 缺A10伤害唤醒/眩晕接续的完整生产校准和同抽换序后继，四败不能拟合新血价、固定杀序或换线胜率。
- 后续冻结实际唤醒动作、状态及当前进阶后继，未知招式保持未知；不先规定目标顺序。本批无源码回退项。

## 现有消费者与源码核对

现有 `learner/audit-selection.ts` 六次均退出0，固定输入不读刷新知识、不调用LLM或网络。693个动作、139个候选片段；505个可核连续动作观测区间、76个可核整轮窗口。缺SL尝试身份时（如本批VLZ、CA5部分场景）工具保持unknown，未为得到更多端点填假身份。所有139片段的完整候选结果仍null。

check-facts.py 的42项断言只核原始观察、算术和既有审计输出；不是新增生产回归测试，也不把整轮净扣归给某个重规划候选。结果见 facts-checks.json、check-facts.initial.log 和 check-facts.final.log。初版36条通过，后加6条药水/冒泡事实后42条通过。

13个相关源码叶按实际live快照核对，11叶字节一致，card-model.ts与rollout-live.ts仅历史注释Roy/Dai拼写差，补丁原样保存。source-live-proof.json对每叶记录真实live祖先源码提交和双方SHA；source-audit.json保留初次main集成提交并非live祖先的结果，不将该失败条件掩盖为已部署源码证明。窄实现已存在，不为waiting重新制造代码提交。

本批没有新的游戏结论或相反机制证据，没有新代码提案id；不重复复盘，不改经验库，不修改原宽提案。需要补的仍是各项具体持续身份、组合或反事实数据，而非用无根据参数凑一个策略上线。

## 验证和交付口径

生产源码、知识、任务模板均无改动；未运行tsc/vitest，未作撤源码红绿（不适用），tests全部null。没有commit、live合入或eval新版本，未登记implemented/duplicate/shipped。原有角色行为保持等价。

账本仅经根 learner/ledger.py update 追加本报告/提案追溯，by=learner:strategy-proposal；不改claim、evidence、first_run、prior、version、status，尤其不把原shipped降级。原26条的既有状态和事实保留；十宽提案的waiting由最终proposal_results交调度器登记，不直接改队列。

过程失败保留：一次shell准备因bubblewrap扫描无关失效符号链接而拒止，原命令重试成功；apply_patch写scratch失败，检查目标不存在后按授权shell写入；一次本地ledger折叠调用误传dict数组而非(line,row)导致ValueError，只影响本地读，正确调用后保存折叠结果；若干试探性源码路径不存在，没有修改或材料恢复动作。不是生产测试失败。初次learn定位脚本错误输出父映射，后续严格按本批键取值，保存和分析对象只有本批；未扩展领取其他提案。

交付 report.md、proposal.md、report.json 以及全部冻结输入、原始逐行元数据、CLI输入回执、既有消费者输出和核验脚本。无源码提交，无需上线双通知或新版本；原始宽请求和待新局重派范围保持开放。

"""Check raw observed facts; this is not a production test suite."""
import json
from pathlib import Path
P = Path(__file__).resolve().parent
runs = json.loads((P / 'dispatch.json').read_text())['runs']
inputs = {r: json.loads((P / (r + '.input.json')).read_text()) for r in runs}
states = {x['_line']: x['state'] for d in inputs.values() for x in d['states']}
decisions = {x['_line']: x for d in inputs.values() for x in d['decisions']}
checks = []
def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})
    assert actual == expected, (name, actual, expected)
def player(line): return states[line]['combat']['player']
def enemy(line, ident): return next(e for e in states[line]['combat']['enemies'] if e['enemy_id'] == ident)
def power(entity, ident): return next((p['amount'] for p in entity['powers'] if p['power_id'] == ident), None)
def card(line, ident): return next(c for c in states[line]['combat']['hand'] if c['card_id'] == ident)
def value(line, ident, key): return next(v['current_value'] for v in card(line, ident)['dynamic_values'] if v['name'] == key)
check('F35神化前后能量', [player(n)['energy'] for n in [275564,275565]], [7,5])
for ident, key, a, b in [('DEFEND_SILENT','Block',5,8),('STRIKE_SILENT','Damage',7,10),('DAGGER_SPRAY','Damage',5,7)]:
    check('F35升级'+ident, [value(n,ident,key) for n in [275564,275565]], [a,b])
check('F35必备工具费用', [card(n,'TOOLS_OF_THE_TRADE')['energy_cost'] for n in [275564,275565]], [1,0])
check('F43神化后同轮玩家净损',player(275679)['current_hp']-player(275687)['current_hp'],13)
check('F43同轮敌本体净扣',enemy(275679,'SOUL_NEXUS')['current_hp']-enemy(275687,'SOUL_NEXUS')['current_hp'],51)
check('F43后续毒雾实抽升级',card(275687,'NOXIOUS_FUMES')['upgraded'],True)
check('F43场外升级张数', [sum(c['upgraded'] for c in states[n]['run']['deck']) for n in [275679,275687]], [4,4])
check('F45末神化持有未升',[card(275731,'APOTHEOSIS')['upgraded'],card(275731,'APOTHEOSIS')['energy_cost']],[False,2])
check('F45生存者后手牌',states[275732]['combat']['hand'],[])
check('F45首题MC样本与预算',[decisions[269748]['potions']['random'][0][k] for k in ['samples','requested','ms']],[1,12,707])
check('F45首题退化推演',[decisions[269748]['rollout'][k] for k in ['horizon','samples','best']],[1,1,None])
check('沙虫同盘指纹',decisions[270216]['fingerprint']==decisions[270282]['fingerprint'],True)
check('蚌力量成长',[power(enemy(n,'SEWER_CLAM'),'STRENGTH_POWER') for n in [273252,273263]],[4,8])
check('蚌喷水意图',[enemy(n,'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273237,273252,273263]],[11,15,19])
check('蚌末态玩家血挡',[player(273268)['current_hp'],player(273268)['block']],[2,10])
check('族母吸取前后玩家力敏',[power(player(273502),'STRENGTH_POWER'),power(player(273504),'STRENGTH_POWER'),power(player(273504),'DEXTERITY_POWER')],[2,None,-2])
check('族母吸取后敌力',power(enemy(273504,'LAGAVULIN_MATRIARCH'),'STRENGTH_POWER'),2)
check('族母T6毒',power(enemy(273504,'LAGAVULIN_MATRIARCH'),'POISON_POWER'),17)
check('胧光航行后力',[power(enemy(n,'THE_OBSCURA'),'STRENGTH_POWER') for n in [273589,273596]],[3,6])
check('胧光T4前后玩家血',[player(n)['current_hp'] for n in [273593,273596]],[25,10])
check('胧光T4后两体血',[enemy(273596,i)['current_hp'] for i in ['THE_OBSCURA','PARAFRIGHT']],[41,2])
check('甲虫睡层',[power(enemy(n,'SLUMBERING_BEETLE'),'SLUMBER_POWER') for n in [274906,274914,274919]],[3,2,1])
check('甲虫醒后成长',[power(enemy(n,'SLUMBERING_BEETLE'),'STRENGTH_POWER') for n in [274929,274934]],[2,4])
check('甲虫T6攻击',enemy(274934,'SLUMBERING_BEETLE')['intents'][0]['total_damage'],22)
check('痊愈药水实际血量能量', [player(n)[k] for k in ['current_hp','energy'] for n in [275728,275729]], [67,67,1,2])
check('痊愈药水实抽两牌', [c['card_id'] for c in states[275729]['combat']['hand']], ['APOTHEOSIS','TOOLS_OF_THE_TRADE','SURVIVOR'])
check('无毒冒泡实际能耗', [player(n)['energy'] for n in [274379,274380]], [5,4])
check('无毒冒泡目标血不变', [enemy(n,'THE_LOST')['current_hp'] for n in [274379,274380]], [35,35])
check('无毒冒泡目标未建毒', [power(enemy(n,'THE_LOST'),'POISON_POWER') for n in [274379,274380]], [None,None])
check('冒泡时尚未建毒雾', [power(player(n),'NOXIOUS_FUMES_POWER') for n in [274379,274380]], [None,None])
consumer = {}
for run in runs:
    audit = json.loads((P / (run + '.audit.json')).read_text())
    check(run+'完整候选保持未知', all(s['actual_full_candidate_result'] is None for s in audit['segments']), True)
    consumer[run] = {'segments':len(audit['segments']),'actions':len(audit['observed_actions']),
                    'observed_intervals':sum(x['observed_interval']['status']=='observed_endpoints' for x in audit['observed_actions']),
                    'observed_turns':sum(x['status']=='observed_turn_endpoints' for x in audit['observed_turns'])}
audit = json.loads((P/'8JRE1C4H4Z2W.audit.json').read_text())
for attempt,loss,damage in [(1,3,10),(3,15,17)]:
    t=next(t for t in audit['observed_turns'] if t['floor']==33 and t['turn']==2 and t['attempt']==attempt)
    f=t['facts'];check('沙虫第'+str(attempt)+'试T2实观净差',[f['player_hp_delta'],f['enemy_hp_changes'][0]['hp_delta']],[-loss,-damage])
terminal=next(a['terminal_observation']['facts'] for a in audit['observed_actions'] if a['terminal_observation'] and a['terminal_observation']['status']=='observed_terminal_endpoints')
check('沙虫末轮实损与显示算式分账',[terminal['player_hp_delta'],terminal['displayed_attack_reference']['attack_minus_block'],terminal['actual_uncapped_damage']],[-5,15,None])
check('沙虫末端敌血差',terminal['enemy_hp_changes'][0]['hp_delta'],-24)
(P/'facts-checks.json').write_text(json.dumps({'checks':checks,'consumer':consumer},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed_fact_assertions':len(checks),'consumer':consumer},ensure_ascii=False))

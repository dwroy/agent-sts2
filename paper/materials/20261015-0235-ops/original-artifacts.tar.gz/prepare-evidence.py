"""Validate this batch's preserved evidence and prepare bounded offline inputs."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((HERE / 'dispatch.json').read_text())
RUNS = dispatch['runs']
FLOORS = {
    'VLZ6CCT8AQ0A': [35, 43, 45], '8JRE1C4H4Z2W': [17, 33],
    'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [33, 39],
    '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [30],
}
selected = {run: {'states': [], 'decisions': [], 'excluded_metadata': []} for run in RUNS}
run_rows = {}
summaries = []
for stream in json.loads((HERE / 'evidence/evidence-manifest.json').read_text()):
    path = HERE / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    counts = Counter()
    with Path('/home/dw/Projects/agent-sts2/logs', stream['stream'] + '.jsonl').open('rb') as original:
        for line in path.open():
            item = json.loads(line)
            run, row = item['run_id'], item['row']
            assert run in RUNS and extract.run_identity(row) == run
            original.seek(item['offset'])
            raw = original.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == row
            assert item['offset'] + item['bytes'] <= stream['source_size']
            counts[run] += 1
            name = stream['stream']
            if name == 'runs':
                assert row['character'].lower() == 'silent' and row['ascension'] == 10
                run_rows[run] = row
            elif name in ('states', 'decisions'):
                if name == 'states':
                    assert row['state']['run']['character_id'].lower() == 'silent'
                    assert row['state']['run']['ascension'] == 10
                    floor = row['state']['run']['floor']
                else:
                    floor = row.get('floor')
                if floor not in FLOORS[run]:
                    continue
                prepared = dict(row, _line=item['line'], _source_sha256=item['sha256'])
                if name == 'decisions' and not row.get('decision_id'):
                    selected[run]['excluded_metadata'].append({'line': item['line'], 'keys': list(row),
                                                             'reason': 'no_decision_id'})
                else:
                    selected[run][name].append(prepared)
    assert {run: counts[run] for run in RUNS} == stream['counts']
    summaries.append({'stream': stream['stream'], 'source_size': stream['source_size'],
                      'verified_raw_lines': sum(counts.values()), 'counts': dict(counts)})
assert set(run_rows) == set(RUNS)
for run, data in selected.items():
    metadata = data.pop('excluded_metadata')
    data['run'] = run_rows[run]
    assert data['states'] and data['decisions']
    (HERE / (run + '.input.json')).write_text(json.dumps(data, ensure_ascii=False) + '\n')
    (HERE / (run + '.excluded-metadata.json')).write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
result = {'streams': summaries, 'inputs': {run: {
    'floors': FLOORS[run], 'decisions': len(data['decisions']), 'states': len(data['states'])
} for run, data in selected.items()}}
(HERE / 'evidence-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

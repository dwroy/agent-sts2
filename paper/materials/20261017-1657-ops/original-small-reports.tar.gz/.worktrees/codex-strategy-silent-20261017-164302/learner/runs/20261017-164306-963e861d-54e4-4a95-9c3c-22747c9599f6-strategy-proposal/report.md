# 静默猎手已领取策略提案复核报告

记录时间：2026-10-17T16:56:31+08:00。batch=20261017-164302-strategy-proposal，角色silent。

本批十项均waiting。六局原证据支持具体观测，但仍不足以确定新的策略参数、完整候选持续归属或整战因果。本批未修改生产源码、经验或对局参数，没有新源码提交、合入、行为版本或shipped。逐项提案、账本和后续验证见proposal.md。

## 身份、基线与范围

开工工作树干净。learn.json确认本批task=strategy-proposal／character=silent／reason=proposal及精确工作树，已领取原十proposal_ids，无proposal_repair、research_request或implementation_request。根普通专题绑定另一历史批次，不符合本批身份；未转成专题或领取其他队列条目。git merge --no-edit main返回Already up to date，最终HEAD与report.base均为完整40位0a57bd72967245aeb4b9a192e0abbed68db0ad5a。

runs.jsonl核六局均SILENT、A10；运行code分别为历史+dirty记录，未将当前干净源码当作历史dirty运行树。只核本批六局、对应静默复盘／原提案与knowledge/characters/silent的19条关联经验。没有读取其他角色经验、启动游戏、模型或网络。没有修改运维prompt、根研究请求或提案原文。

## 原始证据核验

经任务指定extract_evidence.py入口提取，保存逐流source_size和逐行offset／bytes／SHA。所有6995封套已逐一seek回原文件核SHA、原JSON和显式run身份，输出SHA与计数一致。run-plans按run，其他流按run_id／state.run_id／fingerprint.run核身份，不按正文提及归属。源日志只读。

| 流 | 冻结source_size（字节） | 本批封套 |
|---|---:|---:|
| states | 13948583553 | 3432 |
| decisions | 2273590675 | 3306 |
| sl-attempts | 45613764 | 29 |
| run-config | 1962296 | 6 |
| run-plans | 8955699 | 33 |
| brain | 752195338 | 183 |
| runs | 359159 | 6 |

states、decisions、brain入口各记录2条全流无效JSON行；未将无效行归属本批，未补造身份。所有流无未完成行。evidence-verification.json及原manifest保留范围；本批未以0行截点断言任何原流缺失。

从这些流选择323个有界状态快照，楼层／回合范围见review-scope.json；其中15组数值读回断言及8条原决策文本／同指纹核验通过。未声称所有状态、全部楼层或完整生产组合都已校准。

## 主要核实结果与限制

神化：VLZ F35 T1，能量7→5，防御5→8、打击（1力量）7→10、匕首雨逐击5→7、必备工具1→0费，场外升级数1不变；F43勒紧4→6、尖啸6→8、场外升级数4不变。旧题同后继预测43伤／损14，神化后重问51伤／损13，原帧到T2净扣51／损13。现有函数对9个同手配对读回一致，但实际施放跨重问／SL的持久身份与未知组合仍未由此认证。

三骑士：F45首题原文707毫秒药水MC／1样本，后问12样本，是不同决策输入，不能当同预算实验。T4已选24伤／13损与未选32伤／31损只作候选比较。T5显示威胁83→59，32血／20挡、终态三敌仍21／80／77（原数组顺序）；没有另一focus或留药的完整受控后继。

沙虫：8JRE F33首试与第三试T2 fingerprint逐字相同，玩家47→44／32，敌326→316／309，确为多12血换7伤。末试T11实际玩家5→0、敌154→130；37攻击−22挡=15仅为显示算式，不能将净扣5当完整入伤15的观测。本批不从这些端点认证原候选完整执行或拟合护栏。

其他四局：CA5 F13喷水显示11→15→19，末轮弱后14、10挡、2HP归零；本局没有正敏捷实测。5PM F39末试T2冒泡前后玩家29HP／0挡、两敌35／72HP及无毒均不变，能量5→4；沿用账本已有35为敌血的勘误，不重复新增support。61E F17 T6负2敏捷时双防御各3，敌67→34、玩家56→48；F23 T4幻象14→2仍攻击，到T5本体76→41、玩家25→10。DUZU F30末试T6显示22攻击，玩家1→0、甲虫59→32，四次失败来自同一局。

这些是已分析过的2026-10-07发现／回归材料，不是新的独立盲测；同局SL不扩大分母。未选线、持有未建立、死亡截断、不同战斗与资源变化均保留未知。没有新的机制反证或与旧经验冲突需通知；未将没有反证写成已经证明策略有效。

## 现有源码边界

冻结live只读快照为29f146292892704f618cda8f4db733f21f9cdb1f。15叶源码均保存原字节.txt及Git blob、SHA、last_path_commit和祖先判断；12叶base/live相同。card-model.ts与sl/explore.ts保留旧注释字节差异；rollout.ts另有既有Silent实验体阶段能力补丁，完整二进制diff保存在source-base-live.patch。本批未改写任何差异，也未借该补丁证明本批六局完整机制已通过。

existing-implementations.json逐核7个既有窄源码commit均为该实际live祖先；其具体范围见proposal.md。现有actual_cast_this_fight、actual_turn、actual_full_candidate_result仍有明确未知边界。已有配对／审计不是整个原宽请求完成，因此十项均不登记implemented或完整duplicate。

## 十项逐项处置

- silent-proposal-89354805ee4d7e77：waiting。缺跨抽牌、选牌、用药重问、SL及换战的实际施放持续身份与生产读回，以及未知升级组合的校准；9个已见配对不覆盖整个请求。

- silent-proposal-f2bfceddb1898dca：waiting。缺模型覆盖充分后的同起点、同随机池、同总预算MC配对与成熟度曲线，以及另一focus、留药的完整后继；不能从707毫秒或两次重问确定新预算和药价。

- silent-proposal-283a164780d11e69：waiting。同源神化经验仍缺实际施放持续归属和未知组合校准；已有窄live源码不能将整项登记duplicate。

- silent-proposal-ebbfe3b97548756d：waiting。缺十五子项在同一冻结生产调用中的逐来源、期限、升级组合与战斗—路线—休息联合校准；本批原帧和局部函数读回未隔离出新的确定源码数值失配。

- silent-proposal-e5b87be50f28f311：waiting。缺跨抽牌、选牌、用药、重问及SL的完整候选持续归属与逐来源收益；原答、SL替换、派发前缀和端点不能认证完整候选执行，也不足拟合护栏或探索门槛。

- silent-proposal-49632bc4878fb597：waiting。缺力量、正负敏捷、虚弱和独立成长四路径的冻结生产联合对照；本局没有正敏捷实测，本批未定位新的确定子公式失配。

- silent-proposal-66532328a585941f：waiting。缺同起始HP、牌组、药水及完整抽序下不同启动顺序的受控整战对照与收益函数；持有组件或空打端点不足拟合启动阈值和构筑权重。

- silent-proposal-43a76a31ba7bdcfa：waiting。缺同起始HP、构筑和完整抽序下另一可核SL全战线路及生产配对；负敏捷和毒端点不足改变SL范围、换线偏好或阈值。

- silent-proposal-5264153a4a4b0e5c：waiting。缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；局部端点和既有召唤支持不证明目标排序整战收益。

- silent-proposal-bddfa690a84e03d0：waiting。缺伤害唤醒、眩晕接续和A10成长的冻结生产全链校准及同抽换序完整后继；四试均败不足拟合血价、全败排序或固定杀序。

## 记录与验证

十份原提案均逐登记SHA一致，来源Markdown副本保存在original-proposals/；六段原静默复盘及19条经验快照仅用于核对，未修改原文、经验或队列。没有另建重复代码提案ID。

根learner/ledger.py update实际退出0，仅追加26条原账本的本批proposal／report和waiting追溯。ledger-verification.json保存各追加行offset／bytes／SHA；旧22852002字节前缀SHA fdc5ed42d7d593a47fc5a084796b9144642aa7d181658addacbca8ca417db1cc保持，3条其他并行追加原样保留。26条的claim、首证、进阶、prior、证据、status、version、shipped_at和effect逐项未变；不新增support／repeat，不降级shipped。没有源码改动，不新增游戏事实账本，也不将等待提案标shipped。

数值核验初稿因有界过滤未含T3后端点而出现KeyError:276212；review_evidence.initial.txt与numerical-review.initial.log保留。该初次shell随后cat日志导致wrapper为0，不能算核验成功；修正范围后两次独立运行实际退出0，最终15组通过。现有函数只读对照实际退出0、9配对一致。两者均属证据核查，不是新生产实现的红绿测试。

生产源码未改，撤源码失败／恢复通过不适用；tsc、vitest、cases固定为null，未运行沙箱全套或冒称成功。gitleaks dir对本批材料实际退出0，无泄漏。未创建源码提交、未合入live或main、未增加eval版本；merged=null。工作树tracked/index干净，HEAD保持base。

## 运维交接

提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-164302/learner/runs/20261017-164306-963e861d-54e4-4a95-9c3c-22747c9599f6-strategy-proposal/proposal.md

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-164302/learner/runs/20261017-164306-963e861d-54e4-4a95-9c3c-22747c9599f6-strategy-proposal/report.md

机器回执：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-164302/learner/runs/20261017-164306-963e861d-54e4-4a95-9c3c-22747c9599f6-strategy-proposal/result.json

原调度器依据proposal_results保留十项等待新证据重派；具体数据条件逐项写在proposal.md。本报告不关闭原宽提案或父学习要求，不冒称经验已实际入库／消费者自然采用或胜率改善。未来有源码实现时再按固定数据撤修红／恢复绿、沙箱测试、live锁流程与实际版本完成。

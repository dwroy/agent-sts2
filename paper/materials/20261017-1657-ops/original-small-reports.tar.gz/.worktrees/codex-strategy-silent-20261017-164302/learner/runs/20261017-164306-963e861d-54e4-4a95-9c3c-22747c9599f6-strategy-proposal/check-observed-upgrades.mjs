import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { deepStrictEqual } from 'node:assert';
import { observedApotheosisUpgrade } from '../../../agent/src/reflex/silent-apotheosis.ts';

const scratch = dirname(fileURLToPath(import.meta.url));
const rows = readFileSync(join(scratch, 'selected-frames.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
const frames = new Map(rows.map((row) => [row.line, row]));
const facts = [];
const values = (card) => ({ upgraded: card.upgraded, cost: card.energy_cost,
  values: card.dynamic_values.map(({ name, base_value, enchanted_value, current_value }) =>
    ({ name, base_value, enchanted_value, current_value })) });
for (const [beforeLine, afterLine] of [[275564, 275565], [275679, 275680]]) {
  const before = frames.get(beforeLine), after = frames.get(afterLine);
  const remaining = after.hand.slice();
  for (const card of before.hand) {
    const predicted = observedApotheosisUpgrade(card);
    if (!predicted) continue;
    const index = remaining.findIndex((other) => other.card_id === card.card_id);
    deepStrictEqual(index >= 0, true);
    const [actual] = remaining.splice(index, 1);
    deepStrictEqual(values(predicted), values(actual));
    facts.push({ before_line: beforeLine, after_line: afterLine, card: card.card_id,
      before: values(card), actual: values(actual), current_function_matches: true });
  }
}
deepStrictEqual(facts.length, 9);
writeFileSync(join(scratch, 'existing-upgrade-readback.json'), JSON.stringify({
  scope: '已观察同手配对与现有函数对照；未验证完整生产组合、未知升级或策略收益', facts,
}, null, 2) + '\n');
process.stdout.write(JSON.stringify({ paired_cards: facts.length, matched: true }) + '\n');

import hashlib
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
TARGETS = {
    'VLZ6CCT8AQ0A': {35: {1}, 43: {1, 2, 3, 4, 5}, 45: {1, 3, 4, 5}},
    '8JRE1C4H4Z2W': {33: {2, 3, 5, 11}},
    'CA5KE8GFJ9X2': {13: {1, 2, 3, 4, 5}},
    '5PM6JAQG6FNQ': {33: {1, 2}, 39: {2, 4}},
    '61E2QS63Y9WU': {17: {5, 6, 7}, 23: {3, 4, 5}},
    'DUZUBAJ3A8GP': {30: {3, 4, 5, 6}},
}


def reference(envelope):
    return {k: v for k, v in envelope.items() if k != 'row'}


def compact(envelope):
    row = envelope['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **reference(envelope), 'observed_ts': row.get('observed_ts'),
        'floor': state['run']['floor'], 'turn': state.get('turn'), 'screen': state['screen'],
        'player': player, 'run_hp': state['run'].get('current_hp'),
        'permanent_upgraded_count': sum(c.get('upgraded') is True for c in state['run'].get('deck', [])),
        'hand': combat.get('hand', []), 'enemies': combat.get('enemies', []),
        'potions': state['run'].get('potions'),
    }


def selected(envelope):
    state = envelope['row']['state']
    return state.get('turn') in TARGETS[envelope['run_id']].get(state['run']['floor'], set())


frames = []
with (SCRATCH / 'evidence/states.evidence.jsonl').open() as handle:
    for line in handle:
        envelope = json.loads(line)
        if selected(envelope):
            frames.append(compact(envelope))

# Keep complete references; the common extractor provides source identity and byte cutoffs.
with (SCRATCH / 'selected-frames.jsonl').open('w') as handle:
    for frame in frames:
        handle.write(json.dumps(frame, ensure_ascii=False) + '\n')

by_line = {frame['line']: frame for frame in frames}
checks = []


def card_value(line, card_id, name):
    card = next(c for c in by_line[line]['hand'] if c['card_id'] == card_id)
    return next(v['current_value'] for v in card['dynamic_values'] if v['name'] == name)


def card_cost(line, card_id):
    return next(c['energy_cost'] for c in by_line[line]['hand'] if c['card_id'] == card_id)


def check(label, lines, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'label': label, 'references': [
        {k: by_line[n][k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id', 'floor', 'turn']}
        for n in lines], 'actual': actual, 'expected': expected})


check('神化同手升级及费用', [275564, 275565], {
    'energy': [by_line[n]['player']['energy'] for n in [275564, 275565]],
    'defend': [card_value(n, 'DEFEND_SILENT', 'Block') for n in [275564, 275565]],
    'strike': [card_value(n, 'STRIKE_SILENT', 'Damage') for n in [275564, 275565]],
    'spray_per_hit': [card_value(n, 'DAGGER_SPRAY', 'Damage') for n in [275564, 275565]],
    'tools_cost': [card_cost(n, 'TOOLS_OF_THE_TRADE') for n in [275564, 275565]],
    'permanent_upgrades': [by_line[n]['permanent_upgraded_count'] for n in [275564, 275565]],
}, {'energy': [7, 5], 'defend': [5, 8], 'strike': [7, 10], 'spray_per_hit': [5, 7],
    'tools_cost': [1, 0], 'permanent_upgrades': [1, 1]})
check('神化勒紧与尖啸升级', [275679, 275680], {
    'fasten': [card_value(n, 'FASTEN', 'ExtraBlock') for n in [275679, 275680]],
    'wail': [card_value(n, 'PIERCING_WAIL', 'StrengthLoss') for n in [275679, 275680]],
}, {'fasten': [4, 6], 'wail': [6, 8]})
check('神化后至次轮净端点', [275679, 275687], {
    'player_hp': [by_line[n]['player']['current_hp'] for n in [275679, 275687]],
    'enemy_hp': [by_line[n]['enemies'][0]['current_hp'] for n in [275679, 275687]],
    'permanent_upgrades': [by_line[n]['permanent_upgraded_count'] for n in [275679, 275687]],
}, {'player_hp': [90, 77], 'enemy_hp': [254, 203], 'permanent_upgrades': [4, 4]})
for first, after, hp, enemy, label in [
    (276208, 276212, [47, 44], [326, 316], '沙虫首试T2'),
    (276274, 276278, [47, 32], [326, 309], '沙虫第三试T2'),
    (273504, 273508, [56, 48], [67, 34], '族母T6'),
]:
    check(label, [first, after], {
        'player_hp': [by_line[n]['player']['current_hp'] for n in [first, after]],
        'enemy_hp': [by_line[n]['enemies'][0]['current_hp'] for n in [first, after]],
    }, {'player_hp': hp, 'enemy_hp': enemy})
check('族母负敏捷下双防御牌面', [273504], [
    next(v['current_value'] for v in c['dynamic_values'] if v['name'] == 'Block')
    for c in by_line[273504]['hand'] if c['card_id'] == 'DEFEND_SILENT'], [3, 3])
check('末局零血截断与显示差值分开', [276433, 276434], {
    'player_hp': [by_line[n]['player']['current_hp'] for n in [276433, 276434]],
    'enemy_hp': [by_line[n]['enemies'][0]['current_hp'] for n in [276433, 276434]],
    'block': by_line[276433]['player']['block'],
    'displayed_attack': sum(i.get('total_damage') or 0 for e in by_line[276433]['enemies'] for i in e['intents']),
}, {'player_hp': [5, 0], 'enemy_hp': [154, 130], 'block': 22, 'displayed_attack': 37})
check('蚌成长后的显示攻击', [273237, 273252, 273263], [
    sum(i.get('total_damage') or 0 for e in by_line[n]['enemies'] for i in e['intents'])
    for n in [273237, 273252, 273263]], [11, 15, 19])
check('末次无毒目标冒泡观测端点', [274379, 274380], {
    'energy': [by_line[n]['player']['energy'] for n in [274379, 274380]],
    'hp': [by_line[n]['player']['current_hp'] for n in [274379, 274380]],
    'enemy_hp': [[e['current_hp'] for e in by_line[n]['enemies']] for n in [274379, 274380]],
    'poison_present': [any(p['power_id'] == 'POISON_POWER' for e in by_line[n]['enemies'] for p in e['powers'])
        for n in [274379, 274380]],
}, {'energy': [5, 4], 'hp': [29, 29], 'enemy_hp': [[35, 72], [35, 72]], 'poison_present': [False, False]})
check('幻象尚未退场', [273593, 273595], {
    'enemy_hp': [[e['current_hp'] for e in by_line[n]['enemies']] for n in [273593, 273595]],
    'illusion_attack': [by_line[n]['enemies'][0]['intents'][0]['total_damage'] for n in [273593, 273595]],
}, {'enemy_hp': [[14, 76], [2, 51]], 'illusion_attack': [15, 15]})
check('熟睡甲虫末次T6显示与终态', [275018, 275023], {
    'player_hp': [by_line[n]['player']['current_hp'] for n in [275018, 275023]],
    'enemy_hp': [by_line[n]['enemies'][0]['current_hp'] for n in [275018, 275023]],
    'displayed_attack': by_line[275018]['enemies'][0]['intents'][0]['total_damage'],
}, {'player_hp': [1, 0], 'enemy_hp': [59, 32], 'displayed_attack': 22})
check('蚌虚弱末轮与零血端点', [273268, 273269], {
    'hp': [by_line[n]['player']['current_hp'] for n in [273268, 273269]],
    'block_before_end': by_line[273268]['player']['block'],
    'attack_after_weak': by_line[273268]['enemies'][0]['intents'][0]['total_damage'],
    'enemy_hp': [by_line[n]['enemies'][0]['current_hp'] for n in [273268, 273269]],
}, {'hp': [2, 0], 'block_before_end': 10, 'attack_after_weak': 14, 'enemy_hp': [19, 16]})
check('胧光怪T4至T5局部净端点', [273593, 273596], {
    'hp': [by_line[n]['player']['current_hp'] for n in [273593, 273596]],
    'enemy_hp': [[e['current_hp'] for e in by_line[n]['enemies']] for n in [273593, 273596]],
}, {'hp': [25, 10], 'enemy_hp': [[14, 76], [2, 41]]})
check('三骑士末轮临减与未退场', [275752, 275754, 275755], {
    'displayed_attack': [sum(i.get('total_damage') or 0 for e in by_line[n]['enemies'] for i in e['intents'])
        for n in [275752, 275754]],
    'hp_before_end': by_line[275754]['player']['current_hp'],
    'block_before_end': by_line[275754]['player']['block'],
    'remaining_enemy_hp': [e['current_hp'] for e in by_line[275755]['enemies']],
}, {'displayed_attack': [83, 59], 'hp_before_end': 32, 'block_before_end': 20, 'remaining_enemy_hp': [21, 80, 77]})

(SCRATCH / 'numerical-review.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
summary = {run: {'frames': sum(f['run_id'] == run for f in frames),
    'scope': {str(k): sorted(v) for k, v in floors.items()}} for run, floors in TARGETS.items()}
(SCRATCH / 'review-scope.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'selected_frames': len(frames), 'checks': len(checks), 'scope': summary}, ensure_ascii=False))

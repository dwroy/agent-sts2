import hashlib
import importlib.util
import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extractor', scratch.parents[1] / 'extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((scratch / 'evidence/evidence-manifest.json').read_text())
checks = []
for item in manifest:
    counts = dict.fromkeys(item['counts'], 0)
    output = scratch / 'evidence' / (item['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    with output.open('rb') as handle, Path('/home/dw/Projects/agent-sts2/logs', item['stream'] + '.jsonl').open('rb') as source:
        for raw in handle:
            digest.update(raw)
            envelope = json.loads(raw)
            assert envelope['offset'] + envelope['bytes'] <= item['source_size']
            source.seek(envelope['offset'])
            original = source.read(envelope['bytes'])
            assert len(original) == envelope['bytes'] and hashlib.sha256(original).hexdigest() == envelope['sha256']
            assert json.loads(original) == envelope['row']
            assert extractor.run_identity(envelope['row']) == envelope['run_id']
            counts[envelope['run_id']] += 1
    assert counts == item['counts'] and digest.hexdigest() == item['output_sha256']
    checks.append({'stream': item['stream'], 'source_size': item['source_size'],
        'output_sha256': digest.hexdigest(), 'counts': counts, 'verified': True})

runs = [json.loads(line)['row'] for line in (scratch / 'evidence/runs.evidence.jsonl').read_text().splitlines()]
assert len(runs) == 6 and len({r['run_id'] for r in runs}) == 6
assert all(r['character'] == 'SILENT' and r['ascension'] == 10 for r in runs)
(scratch / 'evidence-verification.json').write_text(json.dumps({
    'streams': checks, 'total_envelopes': sum(sum(x['counts'].values()) for x in checks),
    'run_identity_verified': True, 'role': 'silent', 'ascension': 10,
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_envelopes': sum(sum(x['counts'].values()) for x in checks),
    'streams': len(checks), 'runs': len(runs)}, ensure_ascii=False))

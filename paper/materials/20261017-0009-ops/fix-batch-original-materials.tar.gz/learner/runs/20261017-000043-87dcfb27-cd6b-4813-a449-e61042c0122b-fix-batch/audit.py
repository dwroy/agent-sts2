import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261017-000038'
SCRATCH = ROOT / 'learner/runs/20261017-000043-87dcfb27-cd6b-4813-a449-e61042c0122b-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261016-211308-ec457cbf-29ac-45c7-adb5-67d9f654ce3b-fix-batch'
EXPECTED_BASE = 'add1a1f79c980d6e3737456ed2630a6c7f12b421'


def git(*args, binary=False):
    raw = subprocess.check_output(['git', '-C', str(TREE), *args])
    return raw if binary else raw.decode().strip()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, obj):
    (SCRATCH / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
base = git('rev-parse', 'HEAD')
assert base == EXPECTED_BASE
assert not git('status', '--porcelain=v1')
previous_raw = (PREVIOUS / 'audit.json').read_bytes()
previous = json.loads(previous_raw)
previous_result = json.loads((PREVIOUS / 'result.json').read_text())
live = git('rev-parse', 'live')
base_ancestors = set(git('rev-list', base).splitlines())
live_ancestors = set(git('rev-list', live).splitlines())

source_paths = ('agent', 'learner', 'ops', 'eval', 'knowledge/builders')
source_changes = git('diff', '--name-only', previous['base'], base, '--', *source_paths).splitlines()
published_sources = []
for short in ['a8b202e34', '8f02483ab', '32e47decd', '7ca593f9e']:
    commit = git('rev-parse', short)
    assert commit in base_ancestors and commit in live_ancestors, short
    published_sources.append({'commit': commit, 'subject': git('show', '-s', '--format=%s', commit),
                              'ancestor_in_base': True, 'ancestor_in_live': True})
(SCRATCH / 'prior-to-base-source.diff').write_bytes(
    git('diff', '--binary', previous['base'], base, '--', *source_paths, binary=True))

current_files = []
for old in previous['current_files']:
    path = Path(old['path'])
    assert not path.is_absolute() and '..' not in path.parts and '.env' not in path.name
    raw = (TREE / path).read_bytes()
    same = digest(raw) == old['sha256']
    assert same or str(path) in source_changes, path
    current_files.append({'path': str(path), 'sha256': digest(raw), 'same_as_prior': same,
                          'previous_sha256': old['sha256']})
known = {row['path'] for row in current_files}
for name in source_changes:
    assert '.env' not in Path(name).name
    if name not in known:
        current_files.append({'path': name, 'sha256': digest((TREE / name).read_bytes()),
                              'newly_reviewed': True})
existing_fixes = []
for row in previous['existing_fixes']:
    assert row['commit'] in base_ancestors and row['commit'] in live_ancestors, row
    existing_fixes.append({**row, 'ancestor_in_base': True, 'ancestor_in_live': True})

focused = []
for row in previous['focused_source_review']:
    lines = (TREE / row['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if row['anchor'] in line]
    assert found, row
    focused.append({'path': row['path'], 'anchor': row['anchor'], 'lines': found})

queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert digest(queue) == previous['queue_sha256']
unchecked = [(i + 1, line) for i, line in enumerate(queue.decode().splitlines()) if line.startswith('- [ ]')]
assert unchecked == [(row['line'], row['item']) for row in previous['queue_dispositions']]
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)
dispositions = []
for old in previous['queue_dispositions']:
    row = {**old, 'verification': '本轮重新核原文、当前源码SHA、定位锚点及base/live祖先；未关闭宽父项。'}
    if row['line'] == 959:
        row['disposition'] = '证据不足：B2/B3完整错误封套保留已上线；非正HP根因未修，仍由原0332 owner接续。'
    dispositions.append(row)

raw_refs = []
for row in previous['raw_original_references']:
    relative = Path(row['source'])
    assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'logs'
    with (ROOT / relative).open('rb') as source:
        source.seek(row['offset'])
        raw = source.read(row['bytes'])
    assert digest(raw) == row['sha256'], row
    json.loads(raw)
    raw_refs.append({**row, 'sha256_verified': True, 'json_parsed': True})

timeout = previous['new_timeout_review']
for row in timeout['original_logs']:
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    assert relative.parts[:3] == ('ops', 'codex-ops', 'learner')
    assert digest((ROOT / relative).read_bytes()) == row['sha256']
assert digest((TREE / 'agent/tests/rollout-ties.test.ts').read_bytes()) == timeout['test_sha256']
vitest_log = (SCRATCH / 'rollout-ties-baseline.log').read_text()
assert 'Test Files  1 passed (1)' in vitest_log and 'Tests  5 passed (5)' in vitest_log
assert (SCRATCH / 'tsc.log').read_bytes() == b''

skipped = previous_result['skipped']
for row in skipped:
    if row['item'].startswith('silent-0332'):
        row['reason'] = ('证据不足；本轮核B3源a8b202e34、B2源8f02483ab及集成32e47decd已为base/live祖先，'
                         '只保留完整异常封套，正HP契约仍拒绝非法成功样本；机制根因和自然消费者验收继续原owner，不重复派发。')
    if row['item'] == 'infra-test-rollout-ties-host-timeout-15000':
        row['reason'] = ('证据不足；当前固定文件单worker原时限5/5通过，2.85秒，未复现历史15秒超时。'
                         '保持原失败和全部断言/时限，不把本轮定向0当历史全套0或已修。')

audit = {
    'checked_at': checked_at, 'base': base, 'main_merge': 'Already up to date.',
    'prior_audit': str(PREVIOUS / 'audit.json'), 'prior_audit_sha256': digest(previous_raw),
    'live_read_only_snapshot': live, 'queue_sha256': digest(queue), 'queue_lines': len(queue.splitlines()),
    'unchecked_entries': len(unchecked), 'queue_dispositions': dispositions,
    'current_files': current_files, 'same_files': sum(row.get('same_as_prior', False) for row in current_files),
    'changed_prior_files': [row['path'] for row in current_files if row.get('same_as_prior') is False],
    'source_changes_since_prior': source_changes, 'published_sources': published_sources,
    'source_diff_sha256': digest((SCRATCH / 'prior-to-base-source.diff').read_bytes()),
    'existing_fixes': existing_fixes, 'focused_source_review': focused, 'raw_original_references': raw_refs,
    'new_timeout_review': {**timeout, 'current_reproduction': {'rc': 0, 'files': 1, 'cases': 5,
        'test_seconds': 2.85, 'duration_seconds': 4.59, 'retries': 0,
        'log': str(SCRATCH / 'rollout-ties-baseline.log'), 'log_sha256': digest(vitest_log.encode())},
        'disposition': '本轮原断言/原时限通过，未证根因；保持历史失败，不改源码或测试。'},
    'tests': {'tsc': 0, 'vitest': 0, 'files': 1, 'cases': 5, 'scope': 'tsc及rollout-ties固定文件；非全套'},
    'scope': '只读去重和有界固定测试；无新源码/测试改动、提交、账本状态、live或版本写入。',
}
result = {'task': 'fix-batch', 'base': base, 'fixes': [], 'skipped': skipped, 'merged': None,
          'tests': {'tsc': 0, 'vitest': 0, 'cases': 5}, 'code_proposals': [], 'implementation_domains': [],
          'report': str(SCRATCH / 'report.md')}
save('audit.json', audit)
save('result.json', result)
lines = [
    '## 修 bug 回报', '',
    f'- 合并基线：main → {base}（开工工作区干净，先merge main，无冲突，Already up to date.）',
    '- 修复（每条一行）：无新增修复；42条未勾选原文未变，83项既有窄修复仍是base/live祖先。'
    '本轮比对389个既有文件，380个SHA相同，9个变化来自已上线0332诊断与F48 shadow；完整增量23叶已保存二进制diff。'
    '没有源码或测试改动，撤修复红绿验证不适用。',
]
for row in existing_fixes:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['commit']}（只核已实现范围，宽父保持）")
lines.append('- 已被别人修掉的：silent-0332 B2/B3异常封套截断（仅诊断子项） — '
             'a8b202e34 / 8f02483ab，集成32e47decd（均核base/live祖先；nonpositive-hp根因仍未修）')
for row in skipped:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines.extend([
    '- 测试：tsc退出码0；vitest定向1文件 / 5用例 / 退出码0（rollout-ties.test.ts，测试2.85秒、总4.59秒）；无重跑。'
    '未改代码、无提交，未运行全套test-sandbox.sh；历史full失败原件保持。',
    f'- 合入：未合入（无新增提交）；只读live快照{live}；未做空合并、shipped或版本登记。',
    '- 需要 Roy 定的事（没有写「无」）：无。', '', '```json',
    json.dumps(result, ensure_ascii=False, indent=2), '```', '',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines))
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain=v1')
assert (ROOT / 'notes/fix-queue-v4.md').read_bytes() == queue
print(json.dumps({'base': base, 'live_read_only_snapshot': live, 'existing_fixes': len(existing_fixes),
    'unchecked': len(unchecked), 'same_files': audit['same_files'],
    'changed_prior_files': len(audit['changed_prior_files']), 'total_files': len(current_files),
    'raw_references': len(raw_refs), 'skipped': len(skipped), 'tests': result['tests'],
    'report': result['report']}, ensure_ascii=False))

import json,pathlib,collections
p=pathlib.Path(__file__).parent
def rows(name):
 with (p/(name+'.jsonl')).open() as f:
  for line in f:yield json.loads(line)
D=list(rows('decisions'));S=list(rows('states'));R=json.loads((p/'N9GKED3PMEV3-resources.json').read_text())
with (p/'brain-choices.txt').open('w') as f:
 for w in D:
  d=w['data']
  if d['decider']!='codex':continue
  f.write(f"d{w['line']} F{d['floor']} {d['label']} {d['ts']}\n选择 {json.dumps(d.get('chosen'),ensure_ascii=False)}\n理由 {d.get('rationale')}\n答案 {json.dumps(d.get('answers'),ensure_ascii=False)}\n")
with (p/'terminal-turns.txt').open('w') as f:
 for b in R['combats']:
  if b['floor'] not in [7,17,33,42,46,48]:continue
  f.write(f"\n战序{b['sequence']} F{b['floor']}\n")
  frames=[w for w in S if b['entry']['line']<=w['line']<=b['last']['line']]
  turns=collections.defaultdict(list)
  for w in frames:turns[w['data']['state'].get('turn')].append(w)
  for t,ws in turns.items():
   a,z=ws[0],ws[-1]
   def view(w):
    st=w['data']['state'];c=st['combat'];pl=c['player'];return {'s':w['line'],'ts':w['data']['ts'],'hp':pl['current_hp'],'block':pl['block'],'powers':[(q['power_id'],q['amount']) for q in pl.get('powers',[])],'enemies':[(e['enemy_id'],e['current_hp'],e.get('block'),e.get('is_alive'),[(q['power_id'],q['amount']) for q in e.get('powers',[])],e.get('move_id'),e.get('intents')) for e in c['enemies']], 'hand':[(x['name'],x['card_id'],x.get('resolved_rules_text')) for x in c.get('hand',[])]}
   f.write(json.dumps({'turn':t,'first':view(a),'last':view(z)},ensure_ascii=False)+'\n')
with (p/'resource-events.txt').open('w') as f:
 for ch in R['resource_changes']:
  a,z=ch['from'],ch['to'];near=[w for w in D if a['ts']<=w['data']['ts']<=z['ts']]
  f.write(f"s{a['line']}→s{z['line']} {z['ts']} F{z['floor']}T{z['turn']} {a['hp']}→{z['hp']} 药{a['potions']}→{z['potions']} seq{ch['combat_sequence']} restart{ch['restart_boundary']}\n")
  if a['potions']!=z['potions'] or ch['combat_sequence'] is None:
   for w in near:f.write(f" d{w['line']} {w['data']['label']} {json.dumps(w['data']['chosen'],ensure_ascii=False)} {w['data'].get('rationale')}\n")
summary={'decisions':len(D),'deciders':dict(collections.Counter(w['data']['decider'] for w in D)), 'jev_low':sum(1 for w in D if w['data']['decider']=='jev' and isinstance(w['data'].get('confidence'),(float,int)) and w['data']['confidence']<.35)}
choices=[w for w in D if w['data']['decider']=='jev' and w['data']['label'].startswith('combat/plan-choice')]
summary['plan_choices']=len(choices);summary['rollout_best_chosen']=dict(collections.Counter(str(w['data'].get('rollout_best_chosen')) for w in choices))
summary['rank1']=sum('; code rank 1' in w['data'].get('rationale','') for w in choices)
summary['code_combat_actions']=sum(w['data']['decider']=='code' and w['data']['label'].startswith('combat/') for w in D)
summary['code_combat_turns']=len({(w['data']['floor'],w['data'].get('sl_attempt'),w['data']['turn']) for w in D if w['data']['decider']=='code' and w['data']['label'].startswith('combat/')})
summary['jev_usage']={k:sum(w['data'].get('usage',{}).get(k,0) or 0 for w in D if w['data']['decider']=='jev' and isinstance(w['data'].get('usage'),dict)) for k in ['inputTokens','outputTokens','cacheHitTokens']}
summary['brain_usage']={k:sum(w['data'].get('usage',{}).get(k,0) or 0 for w in rows('brain')) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}
summary['brain_calls']=sum(1 for w in rows('brain'));summary['first_ts']=D[0]['data']['ts'];summary['last_ts']=D[-1]['data']['ts']
(p/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
with (p/'guards.txt').open('w') as f:
 for w in D:
  d=w['data'];ra=d.get('rationale','');roll=d.get('rollout')
  if 'guard' in ra.lower() or '护栏' in ra or d.get('selection_audit'):
   f.write(f"d{w['line']} F{d['floor']} T{d['turn']} try{d.get('sl_attempt')} {ra}\n审计{json.dumps(d.get('selection_audit'),ensure_ascii=False)}\n")

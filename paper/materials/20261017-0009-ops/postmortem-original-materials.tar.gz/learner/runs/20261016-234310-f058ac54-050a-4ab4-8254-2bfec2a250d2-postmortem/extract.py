import subprocess,json,pathlib,hashlib
root=pathlib.Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261016-234310-f058ac54-050a-4ab4-8254-2bfec2a250d2-postmortem'; run='N9GKED3PMEV3'
manifest={}
for name in ['runs','decisions','states','run-plans','sl-attempts','run-config','brain']:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists():continue
 n=0; first=None;last=None
 with (out/f'{name}.jsonl').open('w') as target:
  proc=subprocess.Popen(['rg','--text','-n','-b','-F',run,str(p)],stdout=subprocess.PIPE)
  for raw in proc.stdout:
   no,off,data=raw.split(b':',2)
   try: row=json.loads(data)
   except ValueError:continue
   wrapped={'line':int(no),'offset':int(off),'sha256':hashlib.sha256(data).hexdigest(),'data':row}
   target.write(json.dumps(wrapped,ensure_ascii=False)+'\n');n+=1
   ts=row.get('ts');first=first or ts;last=ts or last
  proc.wait()
 manifest[name]={'rows':n,'first':first,'last':last}
(out/'extract-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False,indent=2))

from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, tarfile

sys.dont_write_bytecode = True
root = Path.cwd()
p = root / 'ops/codex-ops/record-staging/20261016-0658'
pub = root / 'paper/materials/20261016-0658-ops'
pub.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda f: json.loads(f.read_text())
def write(f, value): f.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def git(*args, cwd=root): return subprocess.check_output(['git', '-C', str(cwd), *args], stderr=subprocess.PIPE)
assert not (p / 'own-appends.json').exists()
bid = '20261016-064301-strategy-proposal'
data = load(root / 'ops/codex-ops/learn.json')['batches'][bid]
report = data['report']
scratch = Path(report['report']).parent
wt = Path(data['worktree'])
assert data['state'] == 'done' and data['rc'] == 0 and data['merged'] is None and data['proposal_audit_errors'] == []
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' and x['reason'] for x in report['proposal_results'])
assert {x['id'] for x in report['proposal_results']} == set(data['proposal_ids'])
assert report['fixes'] == [] and report['implementation_domains'] == [] and report['tests'] == dict(tsc=None, vitest=None, cases=None)
assert git('rev-parse', 'HEAD', cwd=wt).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=wt).strip()
assert not git('diff', '--binary', report['base'], cwd=wt).strip()
exec((root / 'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text())
out = root / ('ops/codex-ops/learner/' + bid + '.out')
native = runtime(bid, report, out.read_text(), worktree=wt)
material = load(scratch / 'material-checks.stdout.json')
assert material == dict(checks=40, passed=40, failed=[])
raw_validation = load(scratch / 'raw-validation.json')
assert sum(x['verified_rows'] for x in raw_validation) == 38759 and all(x['raw_bytes_json_identity_verified'] for x in raw_validation)
audit = load(scratch / 'audit-receipts.json')
assert len(audit) == 5 and all(x['exit_code'] == 0 for x in audit)
for item in audit:
    for suffix, key in [('audit-input.json', 'input_sha256'), ('audit-output.json', 'output_sha256'), ('audit-stderr.txt', 'stderr_sha256')]:
        f = scratch / (item['run'] + '.' + suffix)
        h = hashlib.sha256()
        with f.open('rb') as handle:
            while chunk := handle.read(1024 * 1024): h.update(chunk)
        assert h.hexdigest() == item[key]
trace = load(scratch / 'ledger-trace-verification.json')
assert trace['exit_code'] == 0 and trace['expected_updates'] == 29 and trace['old_physical_prefix_unchanged'] and trace['protected_fields_unchanged'] and trace['report_links_present'] and trace['history_notes_prefix_preserved']
inputs = [json.loads(x) for x in (scratch / 'ledger-updates.jsonl').read_text().splitlines()]
assert len(inputs) == 29
owned = []
bindings = []
with (root / 'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(trace['prefix_bytes'])) == trace['prefix_sha256']
    for item in inputs:
        offset = handle.tell()
        raw = handle.readline()
        row = json.loads(raw)
        assert row['op'] == 'update' and set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'}
        assert all(row.get(k) == v for k, v in item.items())
        owned.append(raw)
        bindings.append(dict(offset=offset, bytes=len(raw), sha256=sha(raw), id=row['id'], trace_only=True))
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
write(pub / 'ledger-row-bindings.json', dict(original_receipt=str((scratch / 'ledger-trace-verification.json').relative_to(root)), original_receipt_sha256=sha((scratch / 'ledger-trace-verification.json').read_bytes()), rows=bindings))
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as archive:
    files = [f for f in scratch.iterdir() if f.is_file() and f.stat().st_size <= 500_000 and f.suffix in ['.md', '.json', '.jsonl', '.txt', '.patch']]
    files += list((scratch / 'original-proposals').glob('*.txt'))
    files += [out, out.with_suffix('.err')]
    for f in sorted(set(files)):
        raw = f.read_bytes()
        member = str(f.relative_to(scratch)) if f.is_relative_to(scratch) else f.name
        archive.add(f, arcname=member, recursive=False)
        manifest.append(dict(path=str(f.relative_to(root)), member=member, bytes=len(raw), sha256=sha(raw)))
write(pub / 'original-artifact-manifest.json', manifest)
write(pub / 'batch-readback.json', dict(batch=bid, canonical_report=report, native=native, source_unchanged=True, source_head=report['base'], material_checks=material, original_raw_validation=raw_validation, original_audit_receipts=audit, scoped_execution=dict(segments=336, actions=1620, turn_windows=297, verified_endpoints=202, unknown_turns=95, adjacent_intervals=1324, terminal_endpoints=3, full_candidate_results='null; zero full-candidate certifications'), evidence_scope='22 Silent runs; A1 one/A5 one/A6 four/A7 one/A8 one/A10 fourteen, separately bounded', consumer='Existing offline consumer only; no new natural adoption, calibration or game benefit', original_failures='39/40 blocked_by_hook case mismatch and nullable terminal summary probe retained; not product failures', historical_inputs='22 source commits exist; exact historic refreshed knowledge and joint inputs not reconstructed', source_audit='13 leaves: 11 equal, two historical Roy/Dai comment differences retained; scoped live ancestors do not close whole proposals', no_new_mechanism_counterevidence_notice=True, tests='not run: no source changes', merged=None, release=None))
base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(at, flush=True)
note = f'\n- {at} [ops 0658原策略接收] 20261016-064301-strategy-proposal done0，十原ID全waiting且具体证据缺口保留；WT HEAD仍84524bce1d7b57f42403b80e42082c62fc8cd158、无tracked差异/源码或知识提交、mergednull/testsnull，不补合入/版本/测试。原38759行材料核验、22 Silent局按A1/A5/A6/A7/A8/A10分列，5个限定层数离线消费者rc0/336段1620动作/202可核轮端点95未知，完整候选null不当整战或自然采用。40/40材料检查前39/40大小写误断言和可空终态探针失败保，均非产品错误。29原CLI仅where/note来源逐字节与输入匹配，旧claim/首证/prior/evidence/status/version保持；既有单弃/快照/双Boss资源接口只认证其窄子项，不关闭十宽提案、入库或其他父。原生实际gpt-6.1-sol/xhigh/原沙箱及input/lease核实，沿Roy2026-10-12统一要求，不把题面high文字当运行切换或修改prompt；历史源码提交可定位不等于旧刷新知识/联合输入已复原。未发现新游戏反证，不新增机制通知/角色ACK/研究；不改live/当前局/账号home模型预算。回执paper/materials/20261016-0658-ops/。\n'
decision = f'\n- {at} 运维codex：0658原064301主策略事件已实读，canonical done0/no source/mergednull；十提案waiting原因保留，源WT HEAD84524bce1未改、普通index无差异，原生Sol6.1/xhigh/default与原沙箱/no-network/input/lease核。38759原行/22角色内分阶材料、五限定层离线消费者rc0与40/40材料检查按原回执和输入输出SHA分账，不冒生产tsc/vitest、整候选认证、自然采用或收益；首轮39/40 blocked_by_hook大小写及nullable terminal探针失败原件保持。29所属根CLI追溯raw前缀/offset/bytes/SHA及输入逐条核，只纳where/note，不再调用CLI、不增重复support/repeat或改claim/首证/prior/evidence/status/version；已shipped窄子项保持原身份，宽提案/学习入库父不关闭。历史22源码commit存在而知识刷新/联合输入未复原，未知物理牌/复活逐击/未截断入伤/相关SL与缺decision_id边界保留；无新纯bug或游戏反证，无须live合入/编号/补测/规则双通知/新派研究。仅所属记录提交、保全部并行脏记录，不改对局或账号home模型prompt预算。回执paper/materials/20261016-0658-ops/。\n'
appends = {'ops/inbox-dev.md': note, 'paper/materials/decision-log.md': decision}
write(p / 'own-appends.json', appends)
values = {}
for path, text in appends.items():
    with (root / path).open('ab') as f: f.write(text.encode())
    values[path] = git('show', base + ':' + path) + text.encode()
old = git('show', base + ':paper/materials/learning/ledger.jsonl')
existing = set(old.splitlines())
added = b''.join(raw for raw in owned if raw.rstrip(b'\n') not in existing)
assert len(added.splitlines()) == 29
spec = importlib.util.spec_from_file_location('owned_ledger', root / 'learner/ledger.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x])
a, z = fold(old), fold(old + added)
assert set(a) == set(z)
for ident in a:
    assert all(a[ident].get(k) == z[ident].get(k) for k in ['claim', 'first_run', 'prior', 'evidence', 'status', 'version', 'shipped_at'])
values['paper/materials/learning/ledger.jsonl'] = old + added
write(pub / 'completion.json', dict(at=at, waiting=10, original_trace_rows=29, new_source_or_release=False, tests_not_run=True, no_new_task_or_game_action=True, wide_parents='remain open'))
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    helpers = []
    for f in sorted(p.glob('*.py')):
        archive.add(f, arcname=f.name, recursive=False)
        helpers.append(dict(path=str(f.relative_to(root)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
write(pub / 'ops-helper-manifest.json', helpers)
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(root))] = f.read_bytes()
entries = []
dest = p / 'final-files'
for path, raw in values.items():
    f = dest / path
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(p / 'record-manifest.json', dict(base=base, paths=entries))
check = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
print(json.dumps(dict(waiting=10, original_trace_rows=29, archive_members=len(manifest), record_paths=len(entries), ledger_check=0, no_source_change=True)))

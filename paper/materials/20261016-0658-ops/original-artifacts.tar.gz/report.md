# 静默猎手策略学习报告

本批十项提案逐项核查完成，**全部waiting，证据不足以实施新的整项策略或认证整项duplicate**。实际处置与继续条件保存在 [proposal.md](proposal.md) 和 [dispositions.json](dispositions.json)。无生产源码或知识变更，无提交、合入、行为版本或shipped；`fixes=[]`、`merged=null`。

## 身份与范围

- batch：20261016-064301-strategy-proposal；task：strategy-proposal；character：silent。
- 开工及最终基线：`84524bce1d7b57f42403b80e42082c62fc8cd158`，40位。工作树开工干净，普通批次按要求merge main，结果Already up to date。没有纯研究或implementation_request绑定，不适用冻结专题完成口径。
- 只处理dispatch.json的十个proposal_ids；原文及SHA全部核对，另存original-proposals/*.txt；未补写历史复盘、未注册重复提案。
- runs字段保留派发的十个锚点。提案直接引用的额外silent局只用于本十项证据核对：verified-runs.json共22局，A1一局/A5一局/A6四局/A7一局/A8一局/A10十四局，未混同统计或扩展选题。
- 实际原生事件证据见native-runtime.json：gpt-6.1-sol、xhigh；launch命令service_tier=default。题面要求high，实际为xhigh；未改启动器、账号、模型或线程，不声称已切换。原祖先进程查询只看到工具命令，不能用作模型证明，故以本线程原生请求/完成事件为准。

## 原日志与固定材料

共用extract_evidence.py提取八个流，逐流保存source_size与每行offset/bytes/SHA。review_evidence.py独立seek源文件，逐条核原字节SHA、原JSON相等、显式所属run和states角色；**38,759条全部通过**。manifest及raw-validation.json可复验。

| 流 | 所属行数 | 冻结字节截点 |
|---|---:|---:|
| states | 19036 | 13361128108 |
| decisions | 18398 | 1814217584 |
| sl-attempts | 161 | 42393585 |
| run-config | 22 | 1829166 |
| run-plans | 154 | 8391218 |
| brain | 966 | 643457971 |
| runs | 22 | 343717 |
| fight-plans | 0 | 2233957 |

源扫描中states/decisions各有2条无效JSON、brain有1条；这些是源流扫描计数，未将其认定为本角色所属或缺失证据。所有流不完整末行计数为0。fight-plans在本截点对这22局选中0行，仅说明此次选择为0，不推断原日志不存在；run-plans显式run身份实选154行，没有以正文提及冒认所属，也没有覆盖旧截点零行初稿。

dampen-windows.json保存8局11段连续可见抑制区间：ZE8 A5/F42、VN7 A6/F42、2PV A7/F42、DPY A10/F42、UMV/VLZ/YF0 A10/F45各一段，GXN A10/F45四段。GXN四段是同局重打，不当四个独立样本。这里验证现场牌面和观测区间，未认证完整物理牌身份/抽序。

## 实际执行消费者核查

现有learner/audit-selection.ts在五组限定层数固定输入上逐次调用，exit均0。audit-input-manifest.json、audit-receipts.json保存精确命令、input/output/stderr SHA；输入保留真实原行号和_source_sha256，decisions仅去掉agent_view。GXN原行283581、L2原行284801无decision_id，单列audit-input-exclusions.json，不补编号、不跨缺口拼连续性。保留全部同层原状态，无重新编号。

| 局号 | 限定层 | 选线题段 | 动作 | 轮窗 | 可核端点 | 未知 |
|---|---|---:|---:|---:|---:|---:|
| GXNKW8X1XYJP | 34,35,38,40,42,44,45 | 48 | 175 | 28 | 4 | 24 |
| PD9AYQVMLQW6 | 35,37,39,40,42,47,48,49 | 75 | 434 | 78 | 53 | 25 |
| L2TSFU62Z57Z | 6,8,11,13,14,15,16,17 | 84 | 348 | 70 | 51 | 19 |
| ZTRGYYMLR8SC | 11,17 | 105 | 428 | 85 | 69 | 16 |
| YF0LXT1QSTGG | 48 | 24 | 235 | 36 | 25 | 11 |

合计336题段、1620动作、297轮窗，202可核、95未知；1324个相邻观测区间、3个可核终态端点。工具的actual_full_candidate_result等字段按设计保持null，完整候选认证为0；这既不证明候选从未执行，也不证明其已经完整执行。不能把净HP端点、returned/completed接口回执或一轮含多次重问的结果归给原候选。离线消费者可用不等于在线新自然采用、模型校准或收益。

材料检查check_materials.py最终40/40通过（material-checks.json）。首轮39/40，原因是检查把原日志`blocked_by_hook`写成了`BlockedByHook`；first-material-checks.*原件保留，按实际值及playable=false更正后有限复验，不修改原日志。另有一次汇总探针误把可空terminal_observation当对象引发AttributeError，见本线程原工具输出和summary-probe-failure.txt；后续汇总正确保留absent/unknown。这些均为本批材料处理错误，不是生产代码失败或游戏反证。

## 关键支持、反例与未知

1. **PD9 F49第6次T10（0268；关联0049/0023/0005）**：states291336—291342及decisions284707—284711重新核。3血/8挡/两凋萎→防御18挡并新增第三张→打击19挡/敌250→生存者选择中31挡/三凋萎→实际弃完32挡/两凋萎。原牌面各12伤、敌攻23，完整需求15血，3血仍死，死亡实扣只剩3；不把12持伤差冒充实际多损12，不声称修后能赢。当前源码普通唯一单弃已修，但新增凋萎仍在终局用withersAdded汇总，需完整生产消费者重放才关闭该宽项。
2. **L2 F17末T6/T8（0133/0222/0049/0021）**：168→159跨阈值，再至145；decision285148结束原答plan3。打击/侧步线7伤/0损、结束0伤/0损；五轮死亡14/24对11/24，侧步未建模；三条整场各1200模拟样本均0胜。末T8真实昏眩1，一张PINPOINT使129→113、余1能，其他四张playable=false/reason=blocked_by_hook，17血0挡死亡。即时7伤不构成替线获胜证据，剩能量不构成额外出牌额度。
3. **GXN F45T2—3（0019/0020/0079/0243/0280）**：同盘低血与药栏变化可见，例290201为2血，290206为13血/7挡且抑制1；复活中间帧与逐击完整入伤缺失，净回血不等于少受伤。真实路线/提前饮药后继没有受控胜负，不拟血价或SL边界。
4. **PD9 F48→49与L2 F14→17（042ee/0019/0020/0090/0239等）**：PD9下一Boss首战斗帧291021实为10血、两槽空；L2 F17首帧65血、有稳定血清一瓶，未来能力/休息收益不能补成已得资源。双Boss接口已存在，但联合路线/休息价值仍缺匹配输入校准与消费者读回。
5. **ZTRG F11T3/F17T10/T13—14（0012/0046/0021/0125）**：末试开场states292332三活敌62/63/199合324，神官199另列；同型信徒缺稳定实例身份，不用index跨帧认证。末T14可见4血/6挡至0血，神官61→58，只保留端点；69可核轮窗不等于原候选整线收益，不能据局部10血/24伤拟8/24/0阈值。未取得、未支付、未建立的构筑组件不补成已兑现成长。

## 源码和历史输入边界

只读对照live `92c3d22f191f0a79a4f0c56d29b189bd7185fca0`；source-audit.json共13个相关生产/离线叶，11个完全一致，card-model.ts与sl/draws.ts仅历史Roy/Dai注释差，二者git diff --binary另存*.patch；保留差异、不覆盖live。

已核真实live祖先的子项包括：普通生存者/阶段审计66283dd9982bdd7f480da7a4d9bfefea0572a9ac；单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed；同族快照d1713559f2d237a04b681ec6497ce0c8798ae0f0；离线追踪07192e6faf1da89c2719e22b3e0c280617795f22、轮窗e75438488df159b2e8e9d3458cf219b39aadd933；双Boss资源接口e1a467e18a0dfa8d99046a24ff4c0e1af59278c8。它们只作为已完成子项来源，不登记十项整项implemented/duplicate或新合入。

historical-source-inputs.json重新核22份run-config：22个完整源码commit均在Git对象库，列出的dirty路径全部为knowledge/notes，无所列源码dirty路径。原提案“完整dirty源码缺失”原文不回写；当前精确缺口是当时刷新知识/移动表字节及联合输入尚未复原，不能笼统说源码commit无法定位，也不能以当前源码+当前知识冒充历史运行树。这里没有整仓归档或展开额外checkout，没有读取其他角色私有知识。

## 账本、交付与验证口径

十项原CLI提案ID复用，code_proposals为这十个ID，implementation_domains=[]表示本批没有源码实现。每项证据局/层/回合、账本、原/拟行为、反例、缺口、验证、回退和原提案路径见proposal.md。未发现足以改变旧游戏结论的新反证，因此没有新增机制/规则通知，也不代填其他角色ACK。

本批只经根learner/ledger.py update为29条原账本追加报告/提案追溯，by=learner:strategy-proposal，不新增support/repeat、不修改旧claim/首证/prior/evidence/status/version、不将已shipped旧子项降回proposed，也不把本批waiting标shipped。实际CLI回执和前后保护检查见ledger-update.stdout.txt、ledger-trace-verification.json。

无生产源码提交，tsc/vitest/cases均为null；未运行全套测试，撤源码失败/恢复通过不适用，不以材料检查或离线审计exit0冒作生产自测通过。无需合入live、分配eval版本或规则上线双通知；不会推送、运行play或停止对局。最终git-status.txt/head.txt保存工作树和HEAD核验。

最终机器回报见result.json。运维入口为本目录proposal.md、report.md；十项保留waiting及具体重派条件，不关闭其他学习父要求，不声称经验入库或大脑已采用。

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path('/home/dw/Projects/agent-sts2')
scratch = Path(__file__).resolve().parent
ledger_path = root / 'paper/materials/learning/ledger.jsonl'
assert (scratch / 'report.md').is_file() and (scratch / 'proposal.md').is_file()
spec = importlib.util.spec_from_file_location('batch_ledger', root / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
items = json.loads((scratch / 'dispositions.json').read_text())
identifiers = sorted({ident for x in items for ident in x['ledger']})
assert len(identifiers) == 24
before_raw = ledger_path.read_bytes()
before = module.fold(module.read_rows(str(ledger_path)))
selected = {ident: before[ident] for ident in identifiers}
assert all(x['character'] == 'silent' for x in selected.values())
(scratch / 'ledger-immediate-before.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in identifiers:
    linked = [x['id'] for x in items if ident in x['ledger']]
    updates.append({
        'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(scratch / 'proposal.md'), str(scratch / 'report.md')]},
        'note': '20261016-221302-s2-strategy-proposal：本批十项继续waiting；八流6060原帧逐字节重核，'
                '既有窄源码覆盖不代完整后继/执行归属/联合校准。只补追溯，不新增support/repeat、'
                '不改claim/首证/prior/evidence/status/version/shipped。关联：' + ','.join(linked),
    })
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates)
(scratch / 'ledger-updates.jsonl').write_text(payload)
result = subprocess.run([sys.executable, str(root / 'learner/ledger.py'), 'update'],
                        input=payload, text=True, capture_output=True)
(scratch / 'ledger-cli.stdout.txt').write_text(result.stdout)
(scratch / 'ledger-cli.stderr.txt').write_text(result.stderr)
(scratch / 'ledger-cli.rc.txt').write_text(str(result.returncode) + '\n')
assert result.returncode == 0, result.stderr
after_raw = ledger_path.read_bytes()
assert after_raw[:len(before_raw)] == before_raw
after = module.fold(module.read_rows(str(ledger_path)))
protected = ('character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'effect')
for ident in identifiers:
    old, new = before[ident], after[ident]
    for key in protected:
        assert old.get(key) == new.get(key), (ident, key)
    for key, values in old.get('where', {}).items():
        assert new['where'][key][:len(values)] == values
    for key in ('history', 'notes'):
        assert new.get(key, [])[:len(old.get(key, []))] == old.get(key, [])
    assert str(scratch / 'proposal.md') in new['where']['proposal']
    assert str(scratch / 'report.md') in new['where']['proposal']
offset = len(before_raw)
rows = []
for raw in after_raw[offset:].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('id') in identifiers and row.get('by') == 'learner:strategy-proposal' and \
            str(scratch / 'report.md') in row.get('where', {}).get('proposal', []):
        assert row in [{**u, 'op': row.get('op'), 'ts': row.get('ts')} for u in updates]
        rows.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                     'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert {x['id'] for x in rows} == set(identifiers) and len(rows) == 24
(scratch / 'ledger-after.json').write_text(json.dumps({i: after[i] for i in identifiers}, ensure_ascii=False, indent=2) + '\n')
receipt = {'exit_code': 0, 'rows': rows, 'prefix_bytes': len(before_raw),
           'prefix_sha256': hashlib.sha256(before_raw).hexdigest(), 'prefix_preserved': True,
           'protected_fields_preserved': list(protected), 'where_history_notes_prefix_preserved': True,
           'scope': '只追加本批where/note，不新增claim/evidence，不改发布状态'}
(scratch / 'ledger-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': 0, 'rows_verified': len(rows), 'prefix_preserved': True}, ensure_ascii=False))

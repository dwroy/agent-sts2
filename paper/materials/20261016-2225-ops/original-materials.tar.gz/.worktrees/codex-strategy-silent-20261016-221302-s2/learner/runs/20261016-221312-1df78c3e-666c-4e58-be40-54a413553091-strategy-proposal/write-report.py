import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
dispatch = json.loads((scratch / 'dispatch.json').read_text())
items = json.loads((scratch / 'dispositions.json').read_text())
audit = json.loads((scratch / 'source-audit.json').read_text())
integrity = json.loads((scratch / 'integrity.json').read_text())
checks = json.loads((scratch / 'evidence-checks.json').read_text())
consumer = json.loads((scratch / 'prior-consumer-receipt.json').read_text())
identities = json.loads((scratch / 'run-identities.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=workspace, text=True).strip()
assert base == audit['base'] == '59bab95ae7b62682793961bb4b7f643b7fbcc5d2'
assert [x['id'] for x in items] == dispatch['proposal_ids']
assert all(x['same_selected_bytes_as_prior'] for x in integrity)
assert sum(x['verified_rows'] for x in integrity) == 6060
assert checks['failed'] == 0
now = dt.datetime.now().astimezone().isoformat(timespec='seconds')

proposal = [
    '# 静默猎手本批十项策略提案复核\n',
    f'记录时间：{now}（写入前执行date）。批次20261016-221302-s2-strategy-proposal；来源与实现任务strategy-proposal；角色silent。\n',
    f'完整基线：`{base}`。只处理dispatch.json的十个原CLI ID；无research_request、implementation_request或proposal_repair，不扩展其他队列。\n',
    '本批十项均waiting。保留现有出牌、药水、SL、终局及路线/休息规则；无源码或知识修改，不新建重复提案。原提案正文和SHA见original-proposals/及original-proposal-index.json。\n',
    '方法：五个派发局由runs.jsonl核角色，ZE8为A5，其余A10；SL相关尝试不当独立局。共用提取入口冻结八流source_size，随后逐条核原始offset/bytes/SHA/JSON/显式身份。旧原日志/旧报告不覆盖。原消费者只读既有输入输出，本批不重跑模型、模拟或消费者。\n',
    '授权：Roy-2026-10-07-learning允许有证据的规则修改；该授权不是游戏事实。当前缺口不能由预训练知识、候选预测或相关性补齐。铁甲及其他角色、未观察进阶保持原行为。\n',
]
for x in items:
    proposal += [
        f"## {x['id']}：{x['summary']}\n",
        f"账本：{', '.join(x['ledger'])}。领域：{', '.join(x['domains'])}。状态：waiting。\n",
        f"证据局/层/回合：{x['evidence']}\n",
        f"核实结果：{x['finding']}\n",
        f"当前覆盖和真实既有源码：{x['existing']}\n",
        f"反例与未知：{x['counterexample']}\n",
        f"本批不实施原因：{x['reason']}\n",
        f"预期行为：{x['expected']}\n",
        f"验证方法：{x['validation']}\n",
        '样本与时间切分：本批固定原帧只作诊断/开发证据；未来独立结束的同角色、同观察条件局作时间后验证；不把同局SL拆独立训练/验证，不重算原提案的全史分母。\n',
        '回退：本批无改动可回退。后续证据足够才用独立源码提交及固定正反例验证，实际live后登记；保留原日志、刷新知识和所有历史失败记录。\n',
    ]
(scratch / 'proposal.md').write_text('\n'.join(proposal))

rows = '\n'.join(f"| {x['stream']} | {x['source_size']} | {x['verified_rows']} |" for x in integrity)
run_rows = '\n'.join(f"| {r} | SILENT/A{identities[r]['ascension']} | F{identities[r]['floor']} {'胜' if identities[r]['victory'] else '败'} |" for r in dispatch['runs'])
dispositions = '\n'.join(f"| {x['id']} | waiting | {x['reason']} |" for x in items)
consumer_rows = '\n'.join(f"| {x['run']} | {x['segments']} | {x['actions']} | {x['turns']['observed_turn_endpoints']} | {x['turns']['unknown']} | {x['certified_full_candidates']} |" for x in consumer['summary'])
report = f'''# 本批十项静默策略提案复核报告

记录时间：{now}（写入前执行date）。任务strategy-proposal，角色silent，批次20261016-221302-s2-strategy-proposal。

十项原提案均waiting。当前实盘和已有源码只能支持部分事实覆盖，完整后继、执行归属、逐源资源链及联合多轮校准仍缺。没有足够依据新增策略规则或安全恢复抽序；本批源码/知识零改动、fixes=[]、merged=null、无提交/发布号。

完整base/HEAD：`{base}`。开工git status为空，核普通批次身份后git merge --no-edit main返回Already up to date。没有专题/实现请求绑定，不承接其他请求，也不领取本批十ID以外提案。独立完成，无下级agent。

## 身份和输入

已读README、STATE-2026-10-16、decision-log末尾、learning-protocol、learning-code-proposals和learning-requests。learn.json仅取本批行，task/character/worktree/runs/十ID精确匹配。普通专题文件绑定另一旧批，不适用本批。

| 局号 | 角色/进阶 | 结束 |
|---|---|---|
{run_rows}

ZE8 A5仅用于抑制现场版本观察，不能混作A10策略验证。五局run-config完整提交及dirty_files保存在historical-source-limits.json；旧知识原字节/联合运行输入没有复原，不把当前源码或知识充作历史完整运行树。runs中的兼容计数字段不单独证明当时使用哪个引擎。本会话未修改模型/推理/服务档，实际原生请求配置留宿主独立核验，不凭游戏run-config认定本会话配置。

## 原始证据核验

所有原日志提取均经本树learner/extract_evidence.py，nice19、无并行子agent。六流在evidence/、states/decisions在combat-evidence/，各自原stdout/stderr保留。八流共6060封套逐行seek原源重核offset、bytes、SHA、JSON、截点及显式局身份；run-plans.run、run_id、state.run_id、fingerprint.run按共用入口识别，冲突身份拒收。结果见integrity.json。

| 流 | 本批source_size | 选中且核验行数 |
|---|---:|---:|
{rows}

八流选中封套SHA全部与既有061302-s2原封套相同。本批在重新提取的这五局范围内没有新增实盘输入；不据其他局的源文件增长外推结论。原run-plans字节截点8380258另用--streams run-plans --source-size复核并另存prior-run-plans-cutoff/，仍选30行且SHA同当前选中封套；未覆盖旧零行初稿/报告。fight-plans当前截点0行只表示本截点未选到。整流非法行不能归属本批，不补写内容。

本批{checks['passed']}项材料断言通过（evidence-checks.json），不是生产测试。十份原Markdown逐SHA核并保存原字节，24个所属账本及21个关联经验只读核对；不重复添加support/repeat或重写旧复盘。

关键原帧支持与限制：

- KFR F33T6两试同盘15血/228敌/36毒/3覆甲，实线损6/12、净扣83/93；两线未赢。F12斗篷生刀后重问改变实线，原完整0损候选不能算已实得收益，也不能与实际6损直接报模型误差。
- KFR F33末T7，手上技法7挡、防御后12挡，三手动动作后奇巧爆发仍被SLOTH锁且余1能量。毒药37→43、敌159当步未扣，随后43+42=85、敌余74；不证明改对象/顺序或早喝能赢。
- GX F45T2配对后3/13血、0/7带挡，保血线敌多8血；末13血+23挡+2覆甲对40仍需15，hpAfter−2与实死一致。缺复活瞬时逐击及前三次退出，不把净HP当未截断入伤。
- GX F33已建立触媒2层才有29+28+27=84；F45未建立不预支收益。四次SL确有普通键inserted、旧升级键离堆及clean19/18/19/18，但T2→T3同时抽牌；缺纯改标瞬时帧、唯一物理身份和次序。基ID守恒不足以安全延长已知前缀，A5普通现场牌与场外升级分账。
- MTQ F17→18实19→59、KFR实22→60，与休息、开场和SL恢复分账；未到节点不计已有资源。MTQ F23T3原/替线均24/24死亡，原记录是对已失败线探索，不等于认为替线安全或原线必胜。

## 现有实现及消费者边界

本批只读live提交`{audit['live_read_only']}`，不是merged。23个相关源码叶20个同原114302-s2基线，18个同当前live；其余5叶为已有Roy/Dai署名注释差，原样保留。相对旧基线的3个变化是已有SURVIVOR事实入口和R373故障封套接线，不补本十项所缺完整执行/联合校准。两份源码差分及8个既有提交的base/live祖先核验见source-audit.json、prior-source-differences.patch、source-live-differences.patch。

已有源码祖先覆盖限定恶魔毒药/奇巧事实、离线选线与逐槽/回合/终页观测、HP增加边界、敌HP观测和SL资源差。奇巧仍continuation_verified=false，selection_audit仍actual_turn=null，SL差值仍execution=unverified。这些既有窄子项不能把原宽提案整体登记duplicate/implemented，也不重复实现已存在入口。

仅重新读取核对20份原离线消费者输入/输出/stderr/退出码及资源链材料SHA，四局输入由本批原帧重构并逐字相等，六个learner消费者源码不变；没有重跑消费者或模拟。历史执行rc0保持历史归属，不冒本批测试或自然采用。

| A10局号 | 候选段 | 原动作 | 已核回合端点 | 未知回合窗 | 完整候选认证 |
|---|---:|---:|---:|---:|---:|
{consumer_rows}

合483段/2101带ID动作，352回合窗中70端点/282未知，完整候选认证0。KFR一条、GX三条无decision_id元数据原行保留，不补ID、不跨缺口认证连续性。原资源链84窗口包括重试/缺出口，不当独立完整战斗数。

## 逐项结果

| 原CLI ID | 状态 | 具体待补证据 |
|---|---|---|
{dispositions}

每项证据局/层/回合/账本、反例、已发布子项、预期行为及固定验证方法见proposal.md。没有新增机制冲突或需Roy决定的不同结论，不强行支持旧假设；所有原宽提案和学习入库/量化父要求保持。

## 记录和未执行项

只通过根learner/ledger.py update追加24个所属账本的本批proposal/report追溯和note；不变claim、首证、prior、evidence、status、version或shipped，不把旧shipped改回proposed。本批没有新经验或代码提案ID。实际写入与读回以ledger-receipt.json为准，无回执不声称成功。根专用代码队列/调度状态不手改。

源码撤除失败/恢复通过不适用；生产tests={{"tsc":null,"vitest":null,"cases":null}}。无代码提交，不运行tsc/vitest、不借旧绿、不造新通过；无提交前gitleaks步骤、live合入、知识重建、eval版本或规则双通知。原日志只读，不运行play、网络、LLM、游戏API或模拟，不读凭据、.env或游戏二进制，不改运维prompt/根请求。

工作树HEAD和git diff/status最终读回保存在final-validation.json。交付proposal.md、report.md和result.json；不宣称经验新入库、实际大脑采用、shipped或父要求完成。
'''
(scratch / 'report.md').write_text(report)
result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-221302-s2-strategy-proposal',
    'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': dispatch['proposal_ids'], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': [{'id': x['id'], 'state': 'waiting', 'reason': x['reason']} for x in items],
    'report': str(scratch / 'report.md'),
}
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposal': str(scratch / 'proposal.md'), 'report': result['report'], 'results': len(items)}, ensure_ascii=False))

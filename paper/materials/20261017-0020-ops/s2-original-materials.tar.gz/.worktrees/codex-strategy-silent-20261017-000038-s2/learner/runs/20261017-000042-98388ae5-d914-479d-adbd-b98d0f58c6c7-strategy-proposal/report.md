# 静默猎手策略队列本批报告

记录时间：2026-10-17T00:10:25+08:00。

十项原提案均waiting。已有受限模型已真实存在于live；本批没有新的独立后继对照，也没有隔离出可单独修复的新数值缺口，保留现有策略。没有源码/知识修改、提交、live合入、版本或shipped。

base：`add1a1f79c980d6e3737456ed2630a6c7f12b421`。开工git status干净，普通批执行git merge --no-edit main返回Already up to date；HEAD保持该完整40位提交。

batch=20261017-000038-s2-strategy-proposal、task=strategy-proposal、character=silent、reason=proposal、工作树及十个proposal_ids均匹配，无research_request/implementation_request/proposal_repair。普通专题请求绑定另一旧批，未转专题或扩大领取范围。

## 输入和证据

十份原Markdown的SHA256全部匹配，原文保存*.original.md，队列对应行及物理偏移见dispatch-proposals.json。只读关联31个Silent账本、26个相关本角色经验条目与本角色原复盘。经验中的后续案例未冒作本批新核对局，也不改其知识。

派发十锚点与原提案五个补充局合计15局均在runs.jsonl核为SILENT：K3676LU8B0UH A1、SADL3CGYTGSR A7、F4QKG4J1AJJZ A9，其余12局A10；进阶分开，不混用其他角色。TXZ旧runs摘要死因沿原复盘注明有历史漏战问题，本报告F49结论据实际状态，不据旧death_fight字段。

用本树learner/extract_evidence.py在nice19单进程重新提取八流；19,929行均由原日志按offset/bytes/SHA256和JSON逐行读回，并核run_id/state.run_id/run/fingerprint.run显式身份一致，冲突或正文提及不接纳。每流source_size、逐局计数和封套SHA保存在evidence/evidence-manifest.json，独立物理索引见raw-evidence-index.jsonl。

| 流 | 本次冻结source_size字节 | 核验行数 |
| --- | ---: | ---: |
| states | 13705940848 | 9815 |
| decisions | 2089541655 | 9448 |
| sl-attempts | 44303120 | 78 |
| run-config | 1906230 | 15 |
| run-plans | 8701716 | 77 |
| brain | 704874383 | 481 |
| runs | 353455 | 15 |
| fight-plans | 2233957 | 0 |

八流选中封套SHA与前批20261016-214302完全一致（prior-evidence-comparison.json），新增日志截点未增加本15局的证据。run-plans又按旧8664980字节截点独立重提取，77行与本次新截点相同；旧报告/初稿未覆盖。states2/decisions2/brain2条无效原行未选入，不能据其推断本批归属。fight-plans零行只表示该截点未选到，不断言原日志缺失。

43项材料复核含五组开场扣血、TXZ两线、WQ同指纹/双截止、NHA饱和替换、18个狡诈饮用窗口、紧勒弃牌时点、油灯实建及赢战退出端点。结果见bounded-checks.json、selected-decisions.json、ken-potion-actions.json和lamp-observed-fields.json。另将WQ沙坑行动末4/5与次轮3/4明确分时点保存sandpit-timing.json，未改变原延时结论。没有运行新模拟、LLM或play，也没有把材料重算当生产测试。

## 当前实现范围

只读核对live快照：`5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922`。20个相关源码/测试叶均与前批e609e003同字节，15个与此live同字节；另5叶仅既有Roy/Dai注释署名差。每叶本树与base一致，live物理文件与其HEAD一致，原SHA和完整差分保存在source-audit.json、base-live-source.patch，prior-base-source.patch为空。不能将这些叶的相等外推成全知识或旧dirty生产输入已复原。

| 已有覆盖 | 实际live祖先源码commit |
| --- | --- |
| 狡诈生成、容量及穿插 | 6403fdcdadc803a092beb5165a068e22bf51c412 |
| 普通无挡紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 |
| 蟹受限朝向取整 | ec29ea34b919344b707e57ba472ea210f9c39d62 |
| 连战资源模型及接续 | e1a467e18a0dfa8d99046a24ff4c0e1af59278c8；5b56a452bb9be14d620b368ec46974c1b57901ca；66283dd9982bdd7f480da7a4d9bfefea0572a9ac |
| 已观察开场组合 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 |
| SL当前轮资源诊断 | 1698adc96ba434a46942321e0237b70657e625b2 |
| 路线绝对HP/输入假设留证 | 7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a |

以上均核为本base及实际live祖先，不是本批新提交。同名侧支15ea09ad75a421d4bd65a820c187c8ee188186c8不是live祖先，不用它冒报实现；10c53de98c54b118660b8a478bbdedba548dd1c8是经验同步，不是油灯源码。已有固定题覆盖的局部数值与原提案剩余完整消费者/规则价值缺口分别验收；本批未重跑这些生产测试，也未据整战缺数据否认既有窄修复。

当前resource_comparison明示scope=current_turn_prediction和execution=unverified。路线projection也明示rests=heal假设，不能当实际已经回复。候选、覆盖、重问、动作完成和整战后继仍须分别认证；未认证不等于未执行。0332已有诊断及其他独立owner宽项不由本批关闭。

## 逐项处置

| 原提案 | 状态 | 具体缺口 |
| --- | --- | --- |
| silent-proposal-08eaa60bcc449852 | waiting | 缺F15不饮用及同入口、同后继下留药至Boss的完整成对结果；零净损但耗两药不能校准持药价格。 |
| silent-proposal-92920295a648b540 | waiting | 缺保持抽序、生成牌、药栏及后续选择一致的两战替线与联合资源校准；少损3同时少伤9不能证明通关改善。 |
| silent-proposal-a327449c331efbc1 | waiting | 缺攻击、格挡、沙坑两条边界的受控整战后继和独立验证，不能把9血换15伤拟成固定阈值或修改SL门槛。 |
| silent-proposal-a099e89437e942bb | waiting | 生成及穿插子模型已有实际live源码祖先；仍缺计划妥当保留容量、跨重问完整候选派发与SL恢复的联合消费者校准。 |
| silent-proposal-47910f82a1fdd98f | waiting | 王室猛毒开场和连战传递已有受限实现；缺未知回血/复活组合顺序及留药、路线、SL受控整战后继的联合校准。 |
| silent-proposal-f1374df72d8e6a25 | waiting | 缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果，不能据低信心候选拟新权重。 |
| silent-proposal-38a49e6c97f31eea | waiting | 普通紧勒受限公式已有实际live源码祖先；缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准和受控整战后继。 |
| silent-proposal-ef0e38a5dbd3bc07 | waiting | 缺另一营火、事件、路线和用药时机的受控完整结果，两条观察性失败链不足校准路线或终局权重。 |
| silent-proposal-7f820c02d39bfaea | waiting | 缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；六次失败不构成六个独立验证局。 |
| silent-proposal-04b6b430759815ed | waiting | 蟹朝向取整子实现已有实际live源码祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入，以及未覆盖X值/升级组合与能力整战后继。 |

每项局号、层、回合、账本、已有覆盖、反例、预期行为、验证与回退见proposal.md和dispositions.json。code_proposals沿用十个真实原CLI id；implementation_domains=[]表示本批无新增生产实现，不删除原提案领域或另造提案id。

## 记录与交付边界

账本仅经根learner/ledger.py update为31个已有条目追加本批proposal/report路径和note追溯，by=learner:strategy-proposal；不新增证据计数或游戏结论，不改旧claim/首证/prior/evidence/status/version/shipped。已有shipped子项不降回proposed，宽提案waiting保留待新数据。实际CLI和物理追加/前缀保护核验见ledger-link-receipt.json。专用队列处置交调用方读取result.json，本批不手写队列状态。

工作树和索引保持干净，HEAD保持base。没有源码撤除/恢复，tsc/Vitest/cases均为null；43项材料检查不填生产cases。无代码提交，故无提交前gitleaks或合前/合后测试，不造空提交/合入、eval版本、规则上线通知或shipped。所有角色生产行为不变，不关闭入库、自然采用或其他父要求。

旧运行记录含dirty输入，未完整恢复当时所有源码/知识/配置，当前树不能冒充历史精确模型；本批未全量重做9局42饮、三局17油灯窗或105/109局统计。没有新的科学冲突/规则异议；时点区分及已有缺证限制均保留。工具未提供本原生会话model/reasoning/service可独立核验回执，不凭任务文字或默认配置自证运行档切换，未改模型、账号、服务或权限。

没有委派下级agent、联网、安装依赖、读取key/.env/游戏二进制、修改运维prompt、停止对局或推送。临时材料仅在指定scratch。只读定位中两个旧路径探针未命中后已用rg找到真实文件，不视为生产失败或证据不存在。报告与证据保存完成，不自删工作树、不等待未来对局。

运维交付：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-000038-s2/learner/runs/20261017-000042-98388ae5-d914-479d-adbd-b98d0f58c6c7-strategy-proposal/proposal.md；本目录report.md和result.json。没有待兜底提交或合入补丁；逐项waiting及其缺口由原调度链保留。

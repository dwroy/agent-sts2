"""Write this batch's bounded findings without changing production files."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
data = json.loads((HERE / 'dispatch-proposals.json').read_text())
identity = json.loads((HERE / 'input-checks.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
materials = json.loads((HERE / 'material-summary.json').read_text())
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
recorded = (HERE / 'recorded-at.txt').read_text().strip()
batch = '20261017-000038-s2-strategy-proposal'

reviews = [
    ('08eaa60bcc449852',
     'KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1、T2/F15T1共7饮请求；F5 s280255→280280为53→16，F15 s280347→280376为46→46并耗两瓶。',
     '赢战退出HP和消耗必须一起核对；零净损的饮药战不能推断不用药也零损。SL恢复不是新得药或实际路线回复。',
     '资源估值已有实现；本批没有隔离出新机制差额，不修改现有持有价。',
     '缺F15不饮用及同入口、同后继下留药至Boss的完整成对结果；零净损但耗两药不能校准持药价格。',
     '冻结HP、药栏、抽序和后继，分别验不用、当场用和留至Boss的整战资源链；不能把本局六试作六个独立留出局。'),
    ('92920295a648b540',
     'TXZ6RVMQA09D A10 F48第2/3次T6 s281479→281484、s281535→281539：同48HP/敌460，损3扣36对损0扣27。F49 s281565→281566为4→0、敌111未伤、出牌0。',
     '少损3同时少扣9；后续抽牌和生成也改变。首战胜不等连战胜，未校准1200样本不能当必死/SL依据。',
     '连战接续与SL资源诊断已存在；1698adc96ba434a46942321e0237b70657e625b2只记当前轮预测、execution=unverified。',
     '缺保持抽序、生成牌、药栏及后续选择一致的两战替线与联合资源校准；少损3同时少伤9不能证明通关改善。',
     '逐尝试验首战退出HP/药/复活、次战开场和首次可操作帧，再验两战终局；SL恢复独立记账。'),
    ('a327449c331efbc1',
     'WQZVENQ7DTRP A10 F33第2/3次T9 s282075、282144同指纹26HP/敌184；次轮端点分别损13扣24、损22扣39。第2/6次T7均扣24而损0/4。',
     '9血换15伤并非同安全；T7额外4血又换到延时，不能统一禁止付血。沙坑在T7行动末为4/5，到T8轮初为3/4，时点分别记录（sandpit-timing.json）。',
     '既有SL诊断保存预测资源差；没有发现本批可单独修复的新算术差额，保留当前探索和必死规则。',
     '缺攻击、格挡、沙坑两条边界的受控整战后继和独立验证，不能把9血换15伤拟成固定阈值或修改SL门槛。',
     '同时核原答、覆盖、实打、当轮伤/损、已结毒和沙坑；同预算完整后继足够时再评排序。'),
    ('a099e89437e942bb',
     'WQZVENQ7DTRP A10 F33T11第五次八手添2/0/0、末次五手添3/2/0；18个原饮用窗口重核手位、生成、HP和能量。其余派发局及SADL3CGYTGSR A7均已核本角色身份并提取。',
     '满手饮用仍耗瓶；生成刀数不等于实际施放数或整战获胜。原9局42饮全史统计未在本批重新逐饮拟合。',
     '6403fdcdadc803a092beb5165a068e22bf51c412已在live，覆盖确定生成、容量和穿插；已有固定题同时覆盖18饮与穿插，但本批未重跑生产测试。',
     '生成及穿插子模型已有实际live源码祖先；仍缺计划妥当保留容量、跨重问完整候选派发与SL恢复的联合消费者校准。',
     '在冻结保留、选择、重问、SL边界逐步核饮用—出刀—饮用的实际完整派发与恢复，不据理论多刀宣称救局。'),
    ('47910f82a1fdd98f',
     'TXZ6RVMQA09D A10 F43/45/46/48/49五组出牌前均净扣4，最后4→0。WQZVENQ7DTRP F33T9攻防交换与T7延时反例同上。',
     '开场代价不能在live T1或SL恢复后再扣；未知回血/复活组合不按已观察净值外推，旧血瓶组合只保留原净值证据。',
     'e1a467e18a0dfa8d99046a24ff4c0e1af59278c8等连战与ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8受限开场源码已为live祖先。',
     '王室猛毒开场和连战传递已有受限实现；缺未知回血/复活组合顺序及留药、路线、SL受控整战后继的联合校准。',
     '对已观察组合按实际首战末HP、药和复活逐样本接续；未知开场组合保留未知，不预支空奖励或未来回血。'),
    ('f1374df72d8e6a25',
     '1913SE84AXQF A10 F29 s282723→282744为61→46，原复盘F31以46及虚弱/复制药入战后死。Q6M2Y34MWKRE A10 F8 s282872→282906为57→2，F9 s282913→282921为2→0。',
     'Q6已休息且最终饮药；F5/F6零损留药不支持一律早喝。F2早喝敏捷候选未完整实打，F8紧勒的机制误差须与药价分开。',
     '既有连续资源/临时敏捷/再生模型及普通紧勒窄修可定位；本批不从候选低信心或局部差额重设权重。',
     '缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果，不能据低信心候选拟新权重。',
     '先核临时/持续药效和胜战退出资源，再用独立后移局验证完整后继，不混用净损与毛伤。'),
    ('38a49e6c97f31eea',
     'Q6M2Y34MWKRE A10 F8T4 s282887—282892敌HP103→95→85→85→83→80，选择页仍85，弃牌完成才83，随后结3毒。1913SE84AXQF F31弃磨蚀/能力未兑现沿原复盘引用。',
     '拥有或已经建立能力不等于后继已兑现；弃牌选择未完成不能认证整候选。自动、升级、叠层、有挡及整战因果不由普通两局窄式外推。',
     '5c7105ff0294466da8319f2934beda05c6040794已覆盖普通无挡紧勒，现有固定题还明确未确定弃牌；源码已存在，不重复实现。',
     '普通紧勒受限公式已有实际live源码祖先；缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准和受控整战后继。',
     '按实际完成动作核属性、反伤、再生、复活与过轮清除；联合机制校准和规则价值的整战验证分别验收。'),
    ('ef0e38a5dbd3bc07',
     '1913SE84AXQF A10原复盘F24锻造、F28回血21至61，实帧F29胜后46、F31死；Q6M2Y34MWKRE F7休息至57，F8胜后2，F9死。',
     '1913原预计回血改锻造，条件变动不能当同条件预测误差；未来F32火未到。两条观察性失败链没有另一条实打路线。',
     '7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a已在live，保存Silent A10路线绝对HP与假设；assumptions.rests=heal是投影假设，不能当实际已回血。',
     '缺另一营火、事件、路线和用药时机的受控完整结果，两条观察性失败链不足校准路线或终局权重。',
     '以实际节点动作结转回复、事件、幕间和战内再生，SL另账；核投影假设与实际行为差，不预支未来火或未建能力。'),
    ('7f820c02d39bfaea',
     'NHA2KW0RB7VP A10 F33第1/5/6次T1 s283391→283397、283478→283483、283502→283507：同30HP/敌合408，次轮损1/7/7、敌净扣8/24/24；d277248/277250/277272/277274为覆盖及重问记录。',
     '多付6血多净扣16并未击杀一侧；含轮初自动伤的跨轮净扣不能全归当前卡牌。精确切击被弃后重问，初题不等整轮执行；六败只是一局。',
     '1698adc96ba434a46942321e0237b70657e625b2已记当前轮资源比较，明确execution=unverified；不能把诊断存在当排序收益已证。',
     '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；六次失败不构成六个独立验证局。',
     '完整追原答、替换、重问、实际执行与整战后继，分列即时血价/净扣/击杀和存活推进，再评notWorse/deathShare门槛。'),
    ('04b6b430759815ed',
     'NHA2KW0RB7VP A10 F17T1 s283146→283147首毒0→10、F33T1 s283395首次普通X1萎靡实−2力/2弱；油灯对象三帧均无首次消费字段。K3676LU8B0UH A1、SADL3CGYTGSR A7为原提案历史支持局。',
     '持有油灯不能确定跨动作/新战/SL后的首次效果是否可用。未见X值、升级和叠层不能默认翻倍；能力和毒也不提前记已兑现。',
     'ec29ea34b919344b707e57ba472ea210f9c39d62已覆盖受限蟹朝向取整；10c53de98c54b118660b8a478bbdedba548dd1c8属于经验同步，不是油灯模型源码。',
     '蟹朝向取整子实现已有实际live源码祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入，以及未覆盖X值/升级组合与能力整战后继。',
     '冻结可追溯的首次消费和恢复状态，按已见牌、目标、制品、实付X逐步回放；未观察状态保留未知。'),
]

dispositions = []
proposal_lines = [
    '# 静默猎手十项策略提案处置', '',
    f'记录时间：{recorded}。本批 `{batch}`，base=`{source["base"]}`。', '',
    '本文件消费本批十个原CLI提案id，不另建id或改原提案。十项均waiting；局部已有实现单列真实live祖先，不报整项duplicate。未改生产源码、知识或玩法。', '',
    '证据以本目录八流封套及raw-evidence-index.jsonl定位。43项固定材料复核重算通过，不是生产测试、完整候选消费者认证或因果收益验证。原复盘引用与本批直接复算范围分别注明。', '',
]
for suffix, evidence, counter, existing, reason, verification in reviews:
    ident = 'silent-proposal-' + suffix
    p = data['proposals'][ident]
    disposition = {'id': ident, 'state': 'waiting', 'reason': reason, 'ledger': p['ledger'],
                   'runs': p['runs'], 'evidence': evidence, 'counterexamples': counter,
                   'existing_implementation': existing, 'validation': verification}
    dispositions.append(disposition)
    proposal_lines += [f'## {ident}', '', f'账本：{", ".join(p["ledger"])}。原领域：{", ".join(p["domains"])}。', '',
                       f'证据：{evidence}', '', f'反例和限制：{counter}', '',
                       f'旧行为/已有覆盖：{existing}', '', f'处置：**waiting**。{reason}', '',
                       f'预期行为与验证：{verification}', '',
                       '拟合与切分：本批不拟合数值参数；SL尝试同局分组。将来先固定较早独立局，再按时间后移验证，不能把同局帧或模拟样本当独立实证。', '',
                       '回退：本批没有生产变更，无需回退。后续如据充分证据实现，以单独源码提交隔离已观察Silent分支；保留未观察分支、其他角色和全部历史。', '']
(HERE / 'proposal.md').write_text('\n'.join(proposal_lines))
(HERE / 'dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': source['base'],
          'runs': data['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': data['batch']['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{k: d[k] for k in ('id', 'state', 'reason')} for d in dispositions],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

lines = [
    '# 静默猎手策略队列本批报告', '',
    f'记录时间：{recorded}。', '',
    '十项原提案均waiting。已有受限模型已真实存在于live；本批没有新的独立后继对照，也没有隔离出可单独修复的新数值缺口，保留现有策略。没有源码/知识修改、提交、live合入、版本或shipped。', '',
    f'base：`{source["base"]}`。开工git status干净，普通批执行git merge --no-edit main返回Already up to date；HEAD保持该完整40位提交。', '',
    f'batch={batch}、task=strategy-proposal、character=silent、reason=proposal、工作树及十个proposal_ids均匹配，无research_request/implementation_request/proposal_repair。普通专题请求绑定另一旧批，未转专题或扩大领取范围。', '',
    '## 输入和证据', '',
    '十份原Markdown的SHA256全部匹配，原文保存*.original.md，队列对应行及物理偏移见dispatch-proposals.json。只读关联31个Silent账本、26个相关本角色经验条目与本角色原复盘。经验中的后续案例未冒作本批新核对局，也不改其知识。', '',
    '派发十锚点与原提案五个补充局合计15局均在runs.jsonl核为SILENT：K3676LU8B0UH A1、SADL3CGYTGSR A7、F4QKG4J1AJJZ A9，其余12局A10；进阶分开，不混用其他角色。TXZ旧runs摘要死因沿原复盘注明有历史漏战问题，本报告F49结论据实际状态，不据旧death_fight字段。', '',
    '用本树learner/extract_evidence.py在nice19单进程重新提取八流；19,929行均由原日志按offset/bytes/SHA256和JSON逐行读回，并核run_id/state.run_id/run/fingerprint.run显式身份一致，冲突或正文提及不接纳。每流source_size、逐局计数和封套SHA保存在evidence/evidence-manifest.json，独立物理索引见raw-evidence-index.jsonl。', '',
    '| 流 | 本次冻结source_size字节 | 核验行数 |',
    '| --- | ---: | ---: |',
]
for m in manifest:
    lines.append(f'| {m["stream"]} | {m["source_size"]} | {sum(m["counts"].values())} |')
lines += ['',
    '八流选中封套SHA与前批20261016-214302完全一致（prior-evidence-comparison.json），新增日志截点未增加本15局的证据。run-plans又按旧8664980字节截点独立重提取，77行与本次新截点相同；旧报告/初稿未覆盖。states2/decisions2/brain2条无效原行未选入，不能据其推断本批归属。fight-plans零行只表示该截点未选到，不断言原日志缺失。', '',
    '43项材料复核含五组开场扣血、TXZ两线、WQ同指纹/双截止、NHA饱和替换、18个狡诈饮用窗口、紧勒弃牌时点、油灯实建及赢战退出端点。结果见bounded-checks.json、selected-decisions.json、ken-potion-actions.json和lamp-observed-fields.json。另将WQ沙坑行动末4/5与次轮3/4明确分时点保存sandpit-timing.json，未改变原延时结论。没有运行新模拟、LLM或play，也没有把材料重算当生产测试。', '',
    '## 当前实现范围', '',
    f'只读核对live快照：`{source["live_head"]}`。20个相关源码/测试叶均与前批e609e003同字节，15个与此live同字节；另5叶仅既有Roy/Dai注释署名差。每叶本树与base一致，live物理文件与其HEAD一致，原SHA和完整差分保存在source-audit.json、base-live-source.patch，prior-base-source.patch为空。不能将这些叶的相等外推成全知识或旧dirty生产输入已复原。', '',
    '| 已有覆盖 | 实际live祖先源码commit |',
    '| --- | --- |',
    '| 狡诈生成、容量及穿插 | 6403fdcdadc803a092beb5165a068e22bf51c412 |',
    '| 普通无挡紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 |',
    '| 蟹受限朝向取整 | ec29ea34b919344b707e57ba472ea210f9c39d62 |',
    '| 连战资源模型及接续 | e1a467e18a0dfa8d99046a24ff4c0e1af59278c8；5b56a452bb9be14d620b368ec46974c1b57901ca；66283dd9982bdd7f480da7a4d9bfefea0572a9ac |',
    '| 已观察开场组合 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 |',
    '| SL当前轮资源诊断 | 1698adc96ba434a46942321e0237b70657e625b2 |',
    '| 路线绝对HP/输入假设留证 | 7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a |', '',
    '以上均核为本base及实际live祖先，不是本批新提交。同名侧支15ea09ad75a421d4bd65a820c187c8ee188186c8不是live祖先，不用它冒报实现；10c53de98c54b118660b8a478bbdedba548dd1c8是经验同步，不是油灯源码。已有固定题覆盖的局部数值与原提案剩余完整消费者/规则价值缺口分别验收；本批未重跑这些生产测试，也未据整战缺数据否认既有窄修复。', '',
    '当前resource_comparison明示scope=current_turn_prediction和execution=unverified。路线projection也明示rests=heal假设，不能当实际已经回复。候选、覆盖、重问、动作完成和整战后继仍须分别认证；未认证不等于未执行。0332已有诊断及其他独立owner宽项不由本批关闭。', '',
    '## 逐项处置', '',
    '| 原提案 | 状态 | 具体缺口 |',
    '| --- | --- | --- |',
]
for d in dispositions:
    lines.append(f'| {d["id"]} | waiting | {d["reason"]} |')
lines += ['',
    '每项局号、层、回合、账本、已有覆盖、反例、预期行为、验证与回退见proposal.md和dispositions.json。code_proposals沿用十个真实原CLI id；implementation_domains=[]表示本批无新增生产实现，不删除原提案领域或另造提案id。', '',
    '## 记录与交付边界', '',
    '账本仅经根learner/ledger.py update为31个已有条目追加本批proposal/report路径和note追溯，by=learner:strategy-proposal；不新增证据计数或游戏结论，不改旧claim/首证/prior/evidence/status/version/shipped。已有shipped子项不降回proposed，宽提案waiting保留待新数据。实际CLI和物理追加/前缀保护核验见ledger-link-receipt.json。专用队列处置交调用方读取result.json，本批不手写队列状态。', '',
    '工作树和索引保持干净，HEAD保持base。没有源码撤除/恢复，tsc/Vitest/cases均为null；43项材料检查不填生产cases。无代码提交，故无提交前gitleaks或合前/合后测试，不造空提交/合入、eval版本、规则上线通知或shipped。所有角色生产行为不变，不关闭入库、自然采用或其他父要求。', '',
    '旧运行记录含dirty输入，未完整恢复当时所有源码/知识/配置，当前树不能冒充历史精确模型；本批未全量重做9局42饮、三局17油灯窗或105/109局统计。没有新的科学冲突/规则异议；时点区分及已有缺证限制均保留。工具未提供本原生会话model/reasoning/service可独立核验回执，不凭任务文字或默认配置自证运行档切换，未改模型、账号、服务或权限。', '',
    '没有委派下级agent、联网、安装依赖、读取key/.env/游戏二进制、修改运维prompt、停止对局或推送。临时材料仅在指定scratch。只读定位中两个旧路径探针未命中后已用rg找到真实文件，不视为生产失败或证据不存在。报告与证据保存完成，不自删工作树、不等待未来对局。', '',
    f'运维交付：{HERE / "proposal.md"}；本目录report.md和result.json。没有待兜底提交或合入补丁；逐项waiting及其缺口由原调度链保留。', '',
]
(HERE / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'report': str(HERE / 'report.md'), 'proposal': str(HERE / 'proposal.md'), 'items': len(dispositions)}, ensure_ascii=False))

"""Append only this batch's trace links through the root ledger CLI and audit them."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PATH = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('bounded_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
dispatch = json.loads((HERE / 'dispatch-proposals.json').read_text())
ids = sorted({i for p in dispatch['proposals'].values() for i in p['ledger']})
raw = PATH.read_bytes()
before = {i: x for i, x in ledger.fold(ledger.read_rows(str(PATH))).items() if i in ids}
assert len(before) == len(ids) == 31
assert all(x['character'] == 'silent' for x in before.values())
(HERE / 'ledger-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = [{'id': i, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
            'note': '20261017-000038-s2-strategy-proposal：本批八流19929行及43项材料复核；关联原提案均waiting，具体缺数据见本批proposal/report。仅追加追溯，不新增证据计次、不改变原结论/首证/prior/状态/版本，不声称实现、合入或shipped。'}
           for i in ids]
encoded = ''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates)
(HERE / 'ledger-update-input.jsonl').write_text(encoded)
command = [sys.executable, str(ROOT / 'learner/ledger.py'), 'update']
result = subprocess.run(command, input=encoded, text=True, capture_output=True)
(HERE / 'ledger-cli.stdout.txt').write_text(result.stdout)
(HERE / 'ledger-cli.stderr.txt').write_text(result.stderr)
receipt = {'command': command, 'exit_code': result.returncode, 'ids': ids,
           'prefix_size': len(raw), 'prefix_sha256': hashlib.sha256(raw).hexdigest(),
           'input_sha256': hashlib.sha256(encoded.encode()).hexdigest()}
(HERE / 'ledger-link-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
assert result.returncode == 0, result.stderr
with PATH.open('rb') as handle:
    assert hashlib.sha256(handle.read(len(raw))).hexdigest() == receipt['prefix_sha256']
    appended = []
    while True:
        offset = handle.tell()
        line = handle.readline()
        if not line:
            break
        row = json.loads(line)
        if row.get('where', {}).get('proposal') == [str(HERE / 'proposal.md'), str(HERE / 'report.md')]:
            appended.append({'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
assert len(appended) == 31
assert [x['row']['id'] for x in appended] == ids
for actual, expected in zip(appended, updates):
    assert {k: v for k, v in actual['row'].items() if k not in ('op', 'ts')} == expected
after = {i: x for i, x in ledger.fold(ledger.read_rows(str(PATH))).items() if i in ids}
fields = ('claim', 'first_run', 'asc', 'prior', 'prior_note', 'evidence', 'status', 'version', 'shipped_at', 'effect')
for i, old in before.items():
    new = after[i]
    assert all(old.get(k) == new.get(k) for k in fields), i
    assert new['notes'][:len(old['notes'])] == old['notes'], i
    assert new['history'][:len(old['history'])] == old['history'], i
    for k, values in old['where'].items():
        assert new['where'][k][:len(values)] == values, (i, k)
receipt.update({'prefix_preserved': True, 'protected_fields_preserved': True,
                'notes_history_where_prefixes_preserved': True, 'appended': appended})
(HERE / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
(HERE / 'ledger-link-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': result.returncode, 'appended': len(appended), 'prefix_preserved': True, 'protected_fields_preserved': True}))

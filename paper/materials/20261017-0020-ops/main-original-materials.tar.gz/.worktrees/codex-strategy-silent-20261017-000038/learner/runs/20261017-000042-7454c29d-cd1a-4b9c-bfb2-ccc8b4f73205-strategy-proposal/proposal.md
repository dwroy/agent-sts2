# 本批十项策略提案的证据复核与处置

批次：20261017-000038-strategy-proposal；角色silent。仅消费dispatch.json绑定的十个原ID，不领取其他项，不新建重复ID。来源任务沿原postmortem／experience-update，实现任务strategy-proposal。授权Roy-2026-10-07-learning不构成游戏事实。

十份原Markdown均按专用队列SHA校验并保存*.original.md；本批没有足够新证据改变规则，十项均waiting。下表逐项关联证据、旧账本及具体缺口。

| 原CLI id | 证据局／层／回合 | 既有账本 | 处置与缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；d272434/272575、272531/272652、272483/272820 | silent-0079、silent-0176 | waiting：资源对照已有预测拆项，但缺抽弃、续问后的完整候选归属、逐来源实结算及受控整战后继。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3 d272361/272362；F17 T7/T13/T17 | silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176 | waiting：未决持牌失血与持药未知已有提示；缺F13不饮药和留药后战的完整对照，不能拟合持有价。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13；与366288同一局六试 | silent-0079、silent-0176 | waiting：与366288共享一局六试；缺完整执行归属和独立整战验证，不能由5/10血局部差额设探索门槛。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17 | silent-0019、silent-0020、silent-0021、silent-0005、silent-0006、silent-0007、silent-0046、silent-0129、silent-0176 | waiting：分项预测已有实现；缺攻击、毒、荆棘、持牌失血及敏捷的联合实结算校准和跨战用药对照。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 第4/5试T5 s279460—279465/279511—279515；末试T4 s279559/279560 | silent-0102、silent-0019、silent-0020 | waiting：同盘零净损、净扣36/29及毒20/13已核；缺毛伤回血逐来源归属与路线休息替代后继。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T10 s280160/280161；L9SGRBB5R698 F17 T14 sl681；PU80F84P6HPN F17 T17 sl717 | silent-0017、silent-0250、silent-0011、silent-0027、silent-0046 | waiting：巨兽阶段与残壳用毒提示已有实现；缺参考路径改序和提前喝、不喝、留药的受控完整后继。 |
| silent-proposal-9733bb80f445aeae | YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 s252435/252436 | silent-0017、silent-0019、silent-0020、silent-0250 | waiting：残壳毒2至8未改41自爆、PU过爆余2血已核；缺阶段估值与排序、用药时点的整战对照。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；d274131/274156/274185/274235/274237/274267/274272 | silent-0019 | waiting：七次请求和药栏消耗已核、三次回执pending；缺随机选牌及重问后的完整收益和留至Boss对照。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 第4/5试T10 d274505/274568；第4/6试T5 d274484/274601 | silent-0079、silent-0021、silent-0125、silent-0005、silent-0176 | waiting：T10多2净伤付6血、T5省2血延后敏捷均可核；缺逐来源兑现、保持后轮条件的对照和独立验证。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T2/T5/T10；d274354/274484/274601/274505/274568 | silent-0021、silent-0079、silent-0125、silent-0176 | waiting：持牌、无实体与能力窗口局部取舍已核；缺完整候选认证和受控后继，不设统一6血换2伤阈值。 |


## 已核事实、反例与未知

751同指纹的T2原／换线已观测净损13／18、敌净扣9／18；T7净损13／23、敌净扣12／18；T13净损8／2、敌净扣17／11。省血同样有输出代价，六次SL仍是一局；不能据局部差额设置统一门槛。T7的未决弃牌保守数值与两条实际线之间的10血差须分开，不能擅自把保守上界改成已确定失血。

751 F13 T3原题保留有药和无药候选；两者即时损血同8、原记录五轮均8/8胜，而用药与不用药的牌伤不同。那是模型参考，无药实打和保留到Boss的反事实没有得到验证。“成本记0”不证明持有价为0；本批不拟合药价，不规定一律喝或留。

KV第4/5试F33 T5同盘零净损，敌净扣36／29，下一轮毒20／13；删毒没有观察到当轮保血收益。末试T4至T5的敌HP327→342、毒15→14是可核端点；仅凭该净差不能把每一笔毛伤和回血的因果来源当直接观测。完整需求仍需逐来源核验及路线／休息替代后继。

YQL s280160→280161残壳毒2→8，玩家26血、13挡、来袭41均不变；这次局部观察不能推出提前喝必胜、持药价为0或整场已经结束。PU s252435→252436是24血20挡对42来袭、随后奖励页余2血；本体结束和整场胜利应分开。原提案也指出直接将占位残血归零可能换到自爆资源缺口更大的路径，因此没有足够受控后继时保留原参考路径排序。

KEN F17第4/5试T10同指纹，净损15／21、敌净扣2／4；第4/6试T5同指纹，净损7／5、敌净扣1／2，但末试能力延至T9建立。它反对只把当轮省血当作全部价值，也不证明原线整场能赢。七次用药请求逐一对应有药→空槽，d274131、274237、274272的回执仍为pending；槽位观察或单动作completed不能证明整条随机选牌／续问题面的收益兑现。

上述结论均限制在本角色已观察的A10与列明帧；不是六次SL六个独立样本，不从整局失败补写单项机制反例。本轮未发现需另报的新机制异议或旧知识冲突。旧提案及原失败历史保留，不添加预训练游戏事实。

## 当前行为、预期行为、验证和回退

当前silent-sl-resource-comparison只列current_turn_prediction，execution=unverified；silent-held-loss明确actual_held_hp_loss=null并保留未决弃牌。silent-potion-reference区分hold_hp=null与成本0，同时保留当前轮无药和整战抽样无药参考。silent-selection-dispatch只记录单动作回执，whole_plan_executed=null。巨兽阶段／残壳用毒已有事实提示，anchorRank仍按存活回合、原始enemyHpLeft等排序。

只读离线消费者selection-execution、selection-observation、selection-terminal和selection-turn；它们关联观测端点、重问、药槽及整轮窗口，仍将actual_full_candidate_result和causal_candidate_result保持未知。这是工具认证边界，不能倒推实际没有执行。当前源码存在、单步回执或观测净差均不能关闭十项完整要求；本批不再实现相同诊断，也不把局部功能登记为整项duplicate。

预期待验证行为：原答、护栏／SL候选与抽弃、生成、用药、重问后的实际续步有可核归属，分开攻击／毒／荆棘、持牌失血、敌回血和能力兑现。支持足够时可直接按既有授权修改本角色策略；授权不提供游戏事实。验证先固定本批指纹、原日志字节和动作边界，再比较完整同条件后继，模型抽样与实盘分列；若拟合参数，按独立局和真实时间切分调参与后期验证，相关SL不拆入两集合。本批不拟合数值，不把旧锚点当新局留出。

预期影响仅是后续可以据明确缺口补证，不承诺胜率提高。无源码／知识变化，没有行为回退项；未来实现按原提案撤独立源码提交并保留所有日志、反例和失败材料。其他角色没有行为变化。


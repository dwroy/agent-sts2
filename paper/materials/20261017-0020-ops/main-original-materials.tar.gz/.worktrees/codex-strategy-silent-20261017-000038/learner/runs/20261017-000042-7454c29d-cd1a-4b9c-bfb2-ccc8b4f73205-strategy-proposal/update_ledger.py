import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
scratch = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('ledger_root', root / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
originals = json.loads((scratch / 'proposals-original.json').read_text())['add']
result = json.loads((scratch / 'result.json').read_text())
ids = sorted({key for row in originals.values() for key in row['ledger']})
all_before = ledger.fold()
before = {key: all_before[key] for key in ids}
assert all(row['character'] == 'silent' for row in before.values())
(scratch / 'ledger-immediately-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for key in ids:
    related = [row for row in result['proposal_results'] if key in originals[row['id']]['ledger']]
    note = '20261017-000038-strategy-proposal：本批核八流8444封套及29项材料；无源码／知识修改，无测试或上线声称。'
    note += '；'.join(row['id'] + ' waiting：' + row['reason'] for row in related)
    note += '。仅补本批追溯，保留既有账本状态／版本／证据和所有历史，不重复登记support或repeat。'
    updates.append({'id': key, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(scratch / 'proposal.md'), str(scratch / 'report.md')]}, 'note': note})
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates)
(scratch / 'ledger-updates.jsonl').write_text(payload)
physical = root / 'paper/materials/learning/ledger.jsonl'
size_before = physical.stat().st_size


def prefix_hash(size):
    digest = hashlib.sha256()
    with physical.open('rb') as handle:
        remaining = size
        while remaining:
            raw = handle.read(min(1024 * 1024, remaining))
            assert raw
            digest.update(raw)
            remaining -= len(raw)
    return digest.hexdigest()


old_sha = prefix_hash(size_before)
proc = subprocess.run(['python3', str(root / 'learner/ledger.py'), 'update'], input=payload, text=True, capture_output=True)
(scratch / 'ledger-update.stdout.txt').write_text(proc.stdout)
(scratch / 'ledger-update.stderr.txt').write_text(proc.stderr)
(scratch / 'ledger-update.exit-code.txt').write_text(str(proc.returncode) + '\n')
assert proc.returncode == 0, proc.stderr
assert set(proc.stdout.split()) == set(ids)
after = ledger.fold()
protected = ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'version', 'status', 'shipped_at', 'effect']
checks = []
for old, update in zip((before[key] for key in ids), updates):
    current = after[update['id']]
    core = all(current.get(key) == old.get(key) for key in protected)
    history = current['history'][:len(old['history'])] == old['history']
    notes = current['notes'][:len(old['notes'])] == old['notes'] and update['note'] in current['notes']
    where = all(current['where'].get(key, [])[:len(values)] == values for key, values in old['where'].items())
    linked = all(path in current['where']['proposal'] for path in update['where']['proposal'])
    checks.append({'id': update['id'], 'protected_fields_unchanged': core, 'old_history_prefix': history,
                   'old_notes_prefix_and_new_note': notes, 'old_where_prefix': where, 'new_links_present': linked})
    assert core and history and notes and where and linked, checks[-1]
receipts = []
with physical.open('rb') as handle:
    handle.seek(size_before)
    offset = size_before
    for raw in handle:
        row = json.loads(raw)
        if row.get('id') in ids and row.get('by') == 'learner:strategy-proposal' and row.get('note') in {u['note'] for u in updates}:
            expected = next(u for u in updates if u['id'] == row['id'])
            assert all(row[key] == value for key, value in expected.items())
            receipts.append({'id': row['id'], 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        offset += len(raw)
assert len(receipts) == len(ids)
assert prefix_hash(size_before) == old_sha
readback = {'cli_exit': proc.returncode, 'appended_rows': len(receipts), 'old_source_size': size_before,
            'old_prefix_sha256': old_sha, 'physical_prefix_preserved': True, 'rows': receipts, 'fold_checks': checks}
(scratch / 'ledger-readback.json').write_text(json.dumps(readback, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit': proc.returncode, 'rows': len(receipts), 'old_prefix_preserved': True, 'protected_fields_unchanged': True}))

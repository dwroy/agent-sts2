from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,tarfile
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-2236';pub=r/'paper/materials/20261015-2236-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def load(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
bid='20261015-221302-strategy-proposal';b=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(row['state']=='waiting' for row in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(value is None for value in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text());native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
final=load(s/'final-verification.json');assert final['base']==report['base'] and final['git_status_porcelain']=='' and final['head_unchanged']
assert final['ledger_cli_exit_code']==0 and final['ledger_items']==31 and final['unchanged_non_trace_fields'] and final['ledger_prefix_preserved'] and final['status_free_history_entries_added']==31
assert final['evidence_rows_verified']==4489 and final['material_checks']==45 and final['narrow_input_readback']==12
for name,expected in final['files'].items():assert sha((s/('evidence/evidence-manifest.json' if name=='evidence-manifest.json' else name)).read_bytes())==expected
evidence=load(s/'evidence-validation.json');assert evidence['verified_original_rows']==4489 and sum(sum(row.values()) for row in evidence['streams'].values())==4489
checks=load(s/'material-checks.json');assert len(checks['checks'])==checks['passed']==45 and all(row['actual']==row['expected'] for row in checks['checks'])
narrow=load(s/'current-input-readback.json');assert len(narrow['records'])==12
originals=load(s/'proposal-fingerprints.json');assert len(originals)==10
for row in originals:
 assert row['exists'] and row['sha256']==row['expected_sha256'];path=Path(row['path']).resolve();assert path.is_relative_to(r);raw=path.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
source=load(s/'source-readback.json');assert len(source['paths'])==18 and source['base']==report['base'];equal=0
for row in source['paths']:
 a=git('show',report['base']+':'+row['path']);z=git('show',source['live']+':'+row['path']);assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256'];assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai');equal+=a==z
 for proof in row['creation_commits']:
  for target,key in [(report['base'],'base_ancestor'),(source['live'],'live_ancestor')]:
   result=subprocess.run(['git','merge-base','--is-ancestor',proof['commit'],target],capture_output=True);assert result.returncode in [0,1] and (result.returncode==0)==proof[key]
assert equal==15 and sha((s/'base-live-source.patch').read_bytes())==source['diff_sha256']
summary=load(s/'selection-audit-summary.json');assert len(summary)==8 and sum(row['segments'] for row in summary)==483 and sum(row['actions'] for row in summary)==2101 and sum(row['turns'] for row in summary)==352
assert all(row['whole_candidate_certified']==0 for row in summary) and sum(row['turn_status'].get('observed_turn_endpoints',0) for row in summary)==70 and sum(row['turn_status'].get('unknown',0) for row in summary)==282
inputs=load(s/'ledger-updates.json');assert len(inputs)==31;owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(key)==value for key,value in item.items()) for item in inputs):owned.append(raw)
assert len(owned)==31 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned)
assert [json.loads(raw) for raw in owned]==[json.loads(raw) for raw in (s/'ledger-appended-this-batch.jsonl').read_text().splitlines()]
readback=load(s/'ledger-cli-readback.json');assert readback['count']==31 and readback['unchanged_non_trace_fields'] and readback['prefix_preserved']
for row in readback['rows']:
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:handle.seek(row['offset']);raw=handle.read(row['bytes'])
 assert sha(raw)==row['sha256'] and raw in owned
assert set((s/'ledger-cli-output.json').read_text().split())=={json.loads(raw)['id'] for raw in owned}
assert final['gitleaks_exit_code']==final['ledger_gitleaks_exit_code']==0 and load(s/'gitleaks.json')==load(s/'ledger-gitleaks.json')==[]
old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('ops_owned_ledger',r/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);fold=lambda raw:module.fold([(i,json.loads(line)) for i,line in enumerate(raw.splitlines(),1) if line]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 assert {k:v for k,v in before[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in after[ident].items() if k not in ['where','history','notes']},ident
 assert after[ident]['history'][:len(before[ident]['history'])]==before[ident]['history']
 for key,values in before[ident]['where'].items():assert all(value in after[ident]['where'][key] for value in values)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,canonical_no_change_gate=b['no_change_proposals'],native=native,original_final_verification=final,original_evidence_rows=4489,original_material_checks=45,original_narrow_input_readbacks=12,original_partial_audit_summary=summary,source18_leaves_sha_and_ancestry_flags_verified=True,equal15_and_historical_comment_only3=True,learner_trace_only_rows=31,protected_fold_and_history_prefix_preserved=True,original_material_and_consumer_probes_not_reexecuted=True,limits=['KFR original missing decision_id failure and zero output preserved. Four original gaps cause six ordered parts; eight successful audits cover2101/2105 decisions, not full candidate execution.', '483 problem segments,352 turn windows:70 observed endpoints,282 unknown; no whole-candidate result certified.', 'Original hp_guard schema-zero draft corrected via rationale readback; initial ledger history-equality error corrected to prefix preservation without rewriting CLI.', '12 existing handTrickSloth/observedDemonPoison reads are fixed historical frames, not new natural consumers, complete fights or independent SL evidence.', 'No source, behavior release, new knowledge, parent closure, dataset generation or game operation from this strategy batch.']))
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();pending=load(r/'paper/materials/20261015-2226-ops/pending-live-handoff.json');pending['at']=at;pending['latest_guard']=dict(status='live_lock_acquired_but_new_knowledge_builders_active_no_mutation',attempt_at='2026-10-15 22:37:20 CST',builders=[dict(pid=3212455,birth='96696900',task='build-monster-db.py'),dict(pid=3212456,birth='96696900',task='build-fight-value.py all --character silent')],original_retention_released=True,repeat_attempts_or_new_queue_requests=0,host_started=False,release_id=None,receipt='paper/materials/20261015-2236-ops/pending-live-handoff.json');pending['block']=dict(kind='new_active_knowledge_refresh_cycle',previous_owner_retention_has_released=True);write(pub/'pending-live-handoff.json',pending)
for task in pending['batches']:write(r/'ops/codex-ops/pending-integrations'/(task+'.json'),pending)
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,own_ledger_rows=31,new_to_HEAD_rows=len(added.splitlines()),protected_ledger_fields_and_history_prefix_preserved=True,original_material_checks=45,old_live_sources_pending=['798af209','a78bb40e'],live_published=False,release_id=None,host_full_started=False,new_model_dispatch=False,no_dataset_or_game_changes=True))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[path for path in s.iterdir() if path.is_file() and path.stat().st_size<550000]+[s/'evidence/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+extension) for extension in ['.out','.err']]
 for path in sorted(files):
  raw=path.read_bytes();rel=str(path.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(path,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
line=f'\n- {at} 运维codex：2236原221302策略done0/no-source门禁核，十项waiting，fb291干净WT无新增提交/合入、testsnull/域空，不空合/补测/发号。四Silent A10原4489行/45材料断言/12限定入口读回为原学习者有限核验，不重跑或当自然消费者/完整模型；18叶旧livef926逐SHA与真实来源祖先标志核，15同3历史Roy-Dai注释差。31原CLI仅where/note逐输入及原offset/bytes/SHA核，私有fold全部非追溯字段/旧history前缀/旧where保持，不重复CLI；实际native Sol6.1/xhigh/input/lease/workspace-write/no-network核，原未独立读native边界保留。KFR空decision_id原失败/零输出及GXN另3缺ID保留，按原行缺口分6段、8成功审计仅2101/2105决策，483题段/352轮窗仅70端点282未知、整候选全未认证；原hp_guard假零初稿/更正、history误断言及未生成依赖未启动扫描原件不改，不当产品失败。原118/119全史与整战/分源/受控后继继续原宽父。接原两source798af/a78bb待live，本轮锁曾空闲并取得，但取锁后发现新刷新PID3212455/3212456（birth96696900）正在写live，前轮retention已释放，preflight写入前停止；无第二尝试/新排队/等待或live/版本/宿主动作，不把main源或源full当实际上线。两源原pending接续与WT保持，不改当前局/账号home模型权限prompt、不刷新论文。证据paper/materials/20261015-2236-ops/。\n'
note=f'\n- {at} [ops 策略处置及原待办] 原221302十项继续waiting，31条CLI只补追溯；4489原行/45材料检查、12窄入口和8分段审计的缺口/unknown已归档，不作完整候选或收益。旧两源live续办取锁后遇新知识刷新，仍未写live/发号或启动host；只保原pending，不等待或重复排队。回执paper/materials/20261015-2236-ops/。\n'
handoff=f'\n- {at} 原两源live待办最新事实：retention PID3183615锁已释放；2236原续办取得锁后，新刷新PID3212455/3212456/start96696900（monster-db/fight-value）活跃，故任何数据/源码/引用/index/版本写入前停止，锁已释放。798af注册3叶与a78bb耳环4叶仍只main，未分行为号/未启动host；下一既有事件按paper/materials/20261015-2236-ops/pending-live-handoff.json原窄差/知识刷新/实际编号/同树host/自然消费流程接续。busy保pending，不立即排队或等待；本轮221302策略十项waiting独立，不当新实现或原live验收。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note,'notes/ops-handoff.md':handoff};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as handle:handle.write(text.encode())
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for path in [p/'prepare-records.py',p/'seal-records.py',p/'publish.py',p/'publisher-builder-guard.log',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=path.read_bytes();copy=p/'helper-scan'/path.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(path,arcname=path.name);helpers.append(dict(path=str(path.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added;dest=p/'final-files';lp=dest/'paper/materials/learning/ledger.jsonl';lp.parent.mkdir(parents=True,exist_ok=True);lp.write_bytes(old+added)
check=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(lp)},capture_output=True);(pub/'final-ledger-check.log').write_bytes(check.stdout+check.stderr);assert check.returncode==0
for path in pub.iterdir():
 if path.is_file():values[str(path.relative_to(r))]=path.read_bytes()
entries=[]
for path,raw in values.items():
 copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(waiting=10,owned_cli_rows=31,ledger_check=0,native_verified=True,live_pending_new_builders=True,host_started=False,paths=len(entries))))

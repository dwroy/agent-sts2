# 静默策略批次核验报告

记录时间：2026-10-15T22:25:53+08:00（先date后写）。批次20261015-221302-strategy-proposal，角色silent。

本批十项均waiting，没有新增源码、知识条目、策略参数、提交、合入或行为发布。报告和原提案核验材料保存在本任务scratch。父学习要求、历史量化请求及自然消费者验收保持原归属，报告不等于入库或采用。

## 身份和范围

完整base为`fb2916e08ef6af82f0a7ed3ccf7af5437b3a7e84`。开工工作树干净，普通任务按要求merge main后仍为该HEAD。learn.json对应行task/character/worktree/runs均匹配；有十个proposal_ids，无research_request/implementation_request/proposal_repair，不退回普通自由选题或处理其他批次。没有读取另一专题替代身份，没有修改根请求、learn.json或原提案。十份Markdown字节及SHA均与原队列吻合，见proposal-fingerprints.json；31条既有silent账本项只补追溯链接，不更改claim/证据/首证/先验/status/版本，不新造经验或ID。

四局runs.jsonl均SILENT/A10：MTQ0EUBJ3R6T F23败、7X0W3U8TVA2A F31败、KFRDELW2TH2P F33败、GXNKW8X1XYJP F45败。原版本分别ceb74207+dirty、047c809e+dirty、a73ce7cc+dirty、b1714285+dirty，不能据此重建完整旧源码和知识输入。本批不声称核实了当前学习者的原生模型请求参数，也没有修改模型/账号/权限。

## 冻结原证据

使用任务指定extract_evidence.py，按显式run/run_id/state.run_id/fingerprint.run筛选，保存每流source_size、逐行offset/bytes/SHA及计数。随后独立从原文件按offset回读全部4,489行，逐字节SHA、JSON、身份及截点均相同，见evidence-validation.json和analyze_evidence.py。

| 流 | MTQ0 | 7X0 | KFR | GXN |
|---|---:|---:|---:|---:|
| states | 440 | 461 | 620 | 673 |
| decisions | 424 | 445 | 587 | 649 |
| sl-attempts | 5 | 1 | 8 | 7 |
| run-config | 1 | 1 | 1 | 1 |
| run-plans | 4 | 4 | 6 | 10 |
| brain | 23 | 31 | 35 | 48 |
| runs | 1 | 1 | 1 | 1 |
| fight-plans | 0 | 0 | 0 | 0 |

states/decisions各有2条、brain有1条全源不可解析记录，抽取器保留计数，未将其补为本角色事实。fight-plans本截点0行只表示未选到，不推断原流缺失。本次没有复用或覆盖旧截点输出。未重算原提案引用的118/119局机制全史及药水历史分母，只核本批四局与既有账本链接。

## 关键结果与限制

逐项证据、层/回合、账本、反例、预期行为和验证方法见[proposal.md](proposal.md)，对应最终proposal_results十项，均不冒称duplicate/implemented。

- MTQ0 F11护栏候选预测省8血、多2即时伤；实际生存者后选择连续反弹，随后重新选迷雾和中和，最终67→61、敌90→70并已有毒。原候选16伤与实际20不可直接作为模型误差；也不能把候选无毒套到重问实线。
- KFR F12生成小刀后重问。F33同盘T6的两条实线分别损6/12、净扣83/93，多扣10同时多损6，随后均败。六次奇巧均给爆发，末试三手动动作满、仍余1能量而锁牌；7+5牌挡已兑现，爆发收益未兑现。毒37→43时本体不变，之后两次结算85、敌仍74。
- GXN F45同盘T2后T3分别为3/13血、0/7带挡，替线敌多8血。末试13−(40−23−2)=−2与实际死亡一致，不认定least-loss负数bug。缺逐击复活帧，端点净HP变化不当完整敌伤。
- 7X0 F31活段初150、已见新增175、可见HP下降下界278、末仍47。它是生命周期与可见端点审计，不是完整攻击事件账或终局正确性的整战证明。
- 原资源链重新由本批原状态生成，保留重试/缺出口：MTQ0 F19/F20连续赢战入房59→46→8；KFR F30/F31净耗50，F33入房36/开场38；GXN后段胜利仍97→84→66→41，F44胜后5入F45。入房、可操作HP、回复及SL恢复分开，不推替路线因果或新的安全阈值。

## 已有源码核验

抽样实际live HEAD为`f92636aec0e099e656eb18d14ef73c7dc266ff55`；读取Git对象，比较18个相关源码叶，15个逐SHA相同，card-model.ts、run-journal.ts、build-facts.ts仅有已保存的Roy/Dai历史注释文字差异。原字节差异完整保留base-live-source.patch；没有编译后等价或整个live树一致的额外声称。实际创建/实现祖先及SHA见source-readback.json。

候选/护栏/SL差审计存在于live祖先66283dd9982bdd7f480da7a4d9bfefea0572a9ac，单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed，离线执行审计02c4e13ac8e159b82ee35a965ac788a0a029ce5a；奇巧/限定恶魔毒药入口c4a4f4a94b48dff9b30aaa7228624c1092150145已实际为live祖先。源码明确区分预测、单动作回执及未知完整执行；奇巧continuation_verified=false。这里仅引用既有窄项，不把这些提交登记为本批实现或整包完成。

## 材料验证

固定材料检查45项通过（见material-checks.json），不是生产tsc/vitest。调用当前原有handTrickSlothFacts与observedDemonPoison，六次选择均提供剩2手动名额/爆发还需后续技能且后继未知，六次药水输入识别6层；12个旧帧读回通过（current-input-readback.json）。这只验证限定入口，未重跑整战模拟、未使用刷新知识JSON、未调LLM或联网，未当新自然消费者或收益。

现有audit-selection.ts离线首批MTQ0/7X0成功，KFR因原decision 282561无decision_id返回1，原stderr/零输出原件保留。GXN另有283515/283525/283581三个空ID；未伪造ID、重排或拼接，按原行号在每个缺口断开，KFR两段、GXN四段各自通过。共8个成功审计输入包含2,101/2,105条决策，4条原行仍保留原抽取与完整input及问题清单。483个问题段、352个轮窗中70个有严格端点、282个unknown；候选全链结果字段设计上保持null，这不等于实盘候选全部未执行或审计覆盖完整真实动作。见audit-input-issues.json、audit-parts.json、selection-audit-summary.json与各原输出。

初始resource-summary.json按旧记录不存在的hp_guard结构字段统计，不能当护栏0次；resource-summary-corrected.json另以原rationale核出MTQ0/KFR各1次、7X0/GXN各0次，旧初稿保留。另有宿主bubblewrap瞬间缺路径、只读检索/源码比对误用不存在路径，均已纠正且写preparation-errors.txt；不当产品bug或测试结果。

本批没有源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试，不制造成功测试、空提交、空合并、eval版本或shipped。没有改规则，无规则上线双通知。输出gitleaks扫描及最终工作树/账本读回另存final-verification.json。

## 运维交付

提案路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-221302/learner/runs/20261015-221309-c92699f8-c712-4228-bdc7-4544a1f4f811-strategy-proposal/proposal.md`。

报告路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-221302/learner/runs/20261015-221309-c92699f8-c712-4228-bdc7-4544a1f4f811-strategy-proposal/report.md`。最终逐项处置保存在completion.json。本批只将两份材料追溯链接经根learner/ledger.py update追加到31个已有账本条目；没有对新结论强行support，没有把waiting排队或既有窄源码当完整学习入库。无源码合入，merged=null；后续仅按每项具体缺口等新证据，不重复登记原提案。

最终账本读回初次断言误把CLI自动追加的history操作轨迹也当成必须完全不变，故在silent-0005处失败；差异清单保存在ledger-verification-initial-failure.json。已按ledger.py真实fold语义改为逐项核原history前缀不变、只多1条无status的by/ts审计轨迹，所有非追溯字段精确不变。未重新写账本CLI或改变状态。首次追加行扫描依赖此读回产物，因文件尚未生成而未启动，非gitleaks扫描失败；依赖补齐后才实际扫描。

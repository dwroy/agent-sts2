import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
frames = {s['line']: s for s in json.loads((OUT / 'keyframes.json').read_text())}
decisions = {d['_line']: d for d in json.loads((OUT / 'keydecisions.json').read_text())}
checks = []


def equal(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'item': label, 'actual': actual, 'expected': expected})


def hp(line):
    return frames[line]['hp']


def enemy_hp(line):
    return sum(e['hp'] for e in frames[line]['enemies'] if e['alive'])


equal('MTQ0 F11实际净损', hp(288592) - hp(288597), 6)
equal('MTQ0 F11实际敌HP下降', enemy_hp(288592) - enemy_hp(288597), 20)
equal('MTQ0 F11实际已有毒，不能当原护栏无毒整线', frames[288595]['enemies'][0]['powers']['POISON_POWER'], 4)
mtq = json.loads((OUT / 'MTQ0EUBJ3R6T.input.json').read_text())
equal('MTQ0 F11重问实打迷雾', next(d for d in mtq['decisions'] if d['_line'] == 282140)['expect']['card']['id'], 'HAZE')
equal('MTQ0跨幕端点', [hp(288726), hp(288727)], [19, 59])
equal('MTQ0跨幕增加观测', hp(288727) - hp(288726), 40)
equal('MTQ0肉的三个轮初能量', [frames[i]['energy'] for i in [288751, 288757, 288760]], [3, 3, 4])
equal('MTQ0磨蚀后敏捷/荆棘', frames[288761]['powers'], {'DEXTERITY_POWER': 1, 'THORNS_POWER': 4})
equal('MTQ0磨蚀未追补格挡', frames[288761]['block'], 0)
equal('MTQ0速度末试牌挡', frames[288904]['block'], 19)
equal('MTQ0速度末试实损', hp(288904) - hp(288905), 8)
equal('MTQ0下一轮临时敏捷撤销', frames[288905]['powers'], {})
equal('KFR同盘玩家端点一致', hp(289339), hp(289414))
equal('KFR同盘敌端点一致', enemy_hp(289339), enemy_hp(289414))
equal('KFR同盘初毒36', frames[289339]['enemies'][0]['powers']['POISON_POWER'], 36)
equal('KFR原试当轮实损', hp(289339) - hp(289345), 6)
equal('KFR替试当轮实损', hp(289414) - hp(289420), 12)
equal('KFR原试当轮净扣', enemy_hp(289339) - enemy_hp(289345), 83)
equal('KFR替试当轮净扣', enemy_hp(289414) - enemy_hp(289420), 93)
equal('KFR奇巧六次选择均为爆发', [decisions[i]['expect']['option']['id'] for i in [282864,282899,282933,282968,283001,283035]], ['BURST'] * 6)
equal('KFR末试三手动动作', frames[289536]['cards_played'], 3)
equal('KFR末试剩余能量', frames[289536]['energy'], 1)
equal('KFR末试牌挡', frames[289536]['block'], 12)
equal('KFR末试爆发实际锁住', next(c for c in frames[289536]['hand'] if c['card_id'] == 'BURST')['unplayable_preventer_id'], 'SLOTH_POWER')
equal('KFR毒药饮用当步敌HP不变', enemy_hp(289536), enemy_hp(289537))
equal('KFR毒药施毒6', frames[289537]['enemies'][0]['powers']['POISON_POWER'] - frames[289536]['enemies'][0]['powers']['POISON_POWER'], 6)
equal('KFR末试结算85', enemy_hp(289537) - enemy_hp(289538), 85)
equal('KFR末试玩家死亡', hp(289538), 0)
equal('KFR末试敌未死', enemy_hp(289538), 74)
equal('GXN同盘玩家2血', [hp(290160), hp(290201)], [2, 2])
equal('GXN同盘三敌HP', [e['hp'] for e in frames[290160]['enemies']], [e['hp'] for e in frames[290201]['enemies']])
equal('GXN复活后可操作HP端点', [hp(290165), hp(290206)], [3, 13])
equal('GXN复活后带挡端点', [frames[290165]['block'], frames[290206]['block']], [0, 7])
equal('GXN替线敌多8血', enemy_hp(290206) - enemy_hp(290165), 8)
equal('GXN末轮牌/带挡23', frames[290213]['block'], 23)
equal('GXN末轮覆甲2', frames[290213]['powers']['PLATING_POWER'], 2)
equal('GXN末轮least-loss算式', hp(290213) - (40 - frames[290213]['block'] - 2), -2)
equal('GXN末轮实死', hp(290214), 0)

chain = json.loads((OUT / '7X0W3U8TVA2A.resources.json').read_text())
audit = next(c for c in chain['combats'] if c['floor'] == 31)['enemy_hp_audit']['turns']
equal('7X0首个活段HP总和', audit[0]['live_enemy_hp_start'], 150)
equal('7X0已见新增HP', sum(t['observed_hp_added'] for t in audit), 175)
equal('7X0可见HP下降下界', sum(t['visible_enemy_hp_loss_lower_bound'] for t in audit), 278)
equal('7X0末可见存活HP', audit[-1]['live_enemy_hp_end'], 47)
equal('GXN末试SL字段与旧journal不同', decisions[283680]['sl_explore']['replacement'] != decisions[283680]['journal']['choice'].replace(', then ', ', '), True)

summary = json.loads((OUT / 'selection-audit-summary.json').read_text())
equal('分段审计决策数，排除4条空id原记录', sum(r['actions'] for r in summary), 2101)
equal('全部来源决策数', sum(json.loads((OUT / (run + '.input.json')).read_text())['run']['decisions'] for run in ['MTQ0EUBJ3R6T','7X0W3U8TVA2A','KFRDELW2TH2P','GXNKW8X1XYJP']), 2105)
result = {'scope': 'evidence_material_checks_not_tsc_or_vitest', 'checks': checks, 'passed': len(checks)}
(OUT / 'material-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks_passed': len(checks)}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


extract = load_module('extract', ROOT / 'learner/extract_evidence.py')
resources = load_module('resources', ROOT / 'learner/resource_chain.py')
dispatch = json.loads((OUT / 'dispatch-proposals.json').read_text())
runs = dispatch['batch']['runs']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
checked = 0
for info in manifest:
    path = OUT / 'evidence' / (info['stream'] + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == info['output_sha256']
    selected = []
    source = Path('/home/dw/Projects/agent-sts2/logs') / (info['stream'] + '.jsonl')
    with path.open() as handle, source.open('rb') as original:
        for line in handle:
            item = json.loads(line)
            assert item['run_id'] in runs
            assert extract.run_identity(item['row']) == item['run_id']
            assert item['offset'] + item['bytes'] <= info['source_size']
            original.seek(item['offset'])
            raw = original.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            checked += 1
            selected.append(item)
    assert dict(Counter(item['run_id'] for item in selected)) == {k: v for k, v in info['counts'].items() if v}
    streams[info['stream']] = selected


def power_list(items):
    return {p['power_id']: p.get('amount') for p in (items or [])}


def frame(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'run': item['run_id'], 'floor': run.get('floor'),
            'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
            'block': player.get('block'), 'energy': player.get('energy'),
            'powers': power_list(player.get('powers')), 'cards_played': player.get('cards_played_this_turn'),
            'hand': [{k: c.get(k) for k in ('index', 'card_id', 'energy_cost', 'playable', 'unplayable_preventer_id')}
                     for c in combat.get('hand', [])],
            'potions': [{k: p.get(k) for k in ('index', 'potion_id', 'occupied')} for p in run.get('potions', [])],
            'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                         'max_hp': e.get('max_hp'), 'alive': e.get('is_alive'),
                         'powers': power_list(e.get('powers')), 'intents': e.get('intents')}
                        for e in combat.get('enemies', [])]}


key_state_lines = set(list(range(288592, 288598)) + [288726, 288727, 288751, 288757, 288760, 288761, 288762, 288763]
                      + list(range(288902, 288906)) + list(range(289533, 289539))
                      + [289339, 289345, 289414, 289420, 290160, 290165, 290201, 290206, 290212, 290213, 290214])
key_decision_lines = {282138, 282578, 282579, 282864, 282899, 282929, 282933, 282968, 283001, 283035,
                      283641, 283680, 283690, 283691}
keyframes = [frame(item) for item in streams['states'] if item['line'] in key_state_lines]
keydecisions = [{**item['row'], '_line': item['line']} for item in streams['decisions'] if item['line'] in key_decision_lines]
(OUT / 'keyframes.json').write_text(json.dumps(keyframes, ensure_ascii=False, indent=2) + '\n')
(OUT / 'keydecisions.json').write_text(json.dumps(keydecisions, ensure_ascii=False, indent=2) + '\n')

summary = []
for run_id in runs:
    run_rows = [i['row'] for i in streams['runs'] if i['run_id'] == run_id]
    assert len(run_rows) == 1
    run = run_rows[0]
    assert run['character'] == 'SILENT' and run['ascension'] == 10
    states = [{**i['row'], '_line': i['line']} for i in streams['states'] if i['run_id'] == run_id]
    decisions = [{**i['row'], '_line': i['line']} for i in streams['decisions'] if i['run_id'] == run_id]
    assert len(decisions) == run['decisions']
    assert all(s['state']['run']['character_id'] == 'SILENT' and s['state']['run']['ascension'] == 10 for s in states)
    (OUT / (run_id + '.input.json')).write_text(json.dumps({'run': run, 'states': states, 'decisions': decisions}, ensure_ascii=False) + '\n')
    starts = {}
    events = [i['row'] for i in streams['sl-attempts'] if i['run_id'] == run_id]
    for event in events:
        if event.get('attempt', 1) > 1 and event.get('started_at'):
            starts.setdefault(event.get('floor'), []).append(event['started_at'])
    chain = resources.resource_chain(states, run_id, 'silent', starts)
    chain['sl_events'] = events
    (OUT / (run_id + '.resources.json')).write_text(json.dumps(chain, ensure_ascii=False) + '\n')
    guard = [d for d in decisions if d.get('hp_guard') is not None]
    replaced = [d for d in decisions if (d.get('sl_explore') or {}).get('replacement')]
    summary.append({'run': run_id, 'states': len(states), 'decisions': len(decisions), 'sl_rows': len(events),
                    'guard_lines': [d['_line'] for d in guard], 'sl_replacement_lines': [d['_line'] for d in replaced],
                    'combat_windows': len(chain['combats']),
                    'combat_entries': [{k: c.get(k) for k in ('floor', 'sequence', 'entry', 'exit', 'end', 'observed_net_hp_loss')}
                                       for c in chain['combats']]})
(OUT / 'resource-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
validation = {'verified_original_rows': checked, 'streams': {m['stream']: m['counts'] for m in manifest},
              'key_state_lines': sorted(i['line'] for i in streams['states'] if i['line'] in key_state_lines),
              'key_decision_lines': sorted(d['_line'] for d in keydecisions),
              'unknowns': ['fight-plans 在本次截点未选到行，不推断整个原日志不存在',
                           '原 states/decisions 各有2行、brain有1行不可解析；不补写或当本角色事实',
                           '当前对局源码含 dirty 标记，完整旧源码及知识快照无法由版本字段重建']}
(OUT / 'evidence-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_original_rows': checked, 'runs': [{k: r[k] for k in ('run', 'states', 'decisions', 'sl_rows', 'guard_lines', 'sl_replacement_lines', 'combat_windows')} for r in summary]}, ensure_ascii=False))

import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
before = json.loads((OUT / 'ledger-exact-before.json').read_text())
prefix = json.loads((OUT / 'ledger-prefix-before.json').read_text())
raw = Path('/home/dw/Projects/agent-sts2/paper/materials/learning/ledger.jsonl').read_bytes()
assert hashlib.sha256(raw[:prefix['source_size']]).hexdigest() == prefix['sha256']
rows, own, metadata = [], [], []
offset = 0
for line_number, line in enumerate(raw.splitlines(keepends=True), 1):
    record = json.loads(line)
    if record.get('id') in before:
        rows.append((line_number, record))
    if str(OUT / 'report.md') in record.get('where', {}).get('proposal', []):
        own.append(line)
        metadata.append({'id': record['id'], 'line': line_number, 'offset': offset,
                         'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest()})
        assert set(record) == {'op', 'id', 'ts', 'by', 'where', 'note'}
        assert record['by'] == 'learner:strategy-proposal'
    offset += len(line)
spec = importlib.util.spec_from_file_location('task_ledger', '/home/dw/Projects/agent-sts2/learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
after = ledger.fold(rows)
assert len(own) == 31 and {item['id'] for item in metadata} == set(before)
for item_id, old in before.items():
    current = after[item_id]
    trace_fields = {'where', 'notes', 'history'}
    assert {k: v for k, v in old.items() if k not in trace_fields} == {
        k: v for k, v in current.items() if k not in trace_fields}, item_id
    assert current['history'][:len(old['history'])] == old['history']
    assert len(current['history']) == len(old['history']) + 1
    assert set(current['history'][-1]) == {'ts', 'by'}
    assert current['history'][-1]['by'] == 'learner:strategy-proposal'
    for key, values in old['where'].items():
        assert set(values) <= set(current['where'][key])
    assert str(OUT / 'proposal.md') in current['where']['proposal']
    assert str(OUT / 'report.md') in current['where']['proposal']
(OUT / 'ledger-appended-this-batch.jsonl').write_bytes(b''.join(own))
(OUT / 'ledger-cli-readback.json').write_text(json.dumps({
    'prefix_preserved': True, 'unchanged_non_trace_fields': True, 'count': 31,
    'history_delta': 'each item appends one status-free CLI audit entry', 'rows': metadata,
}, ensure_ascii=False, indent=2) + '\n')
completion = json.loads((OUT / 'completion.json').read_text())
dispatch = json.loads((OUT / 'dispatch-proposals.json').read_text())
assert [item['id'] for item in completion['proposal_results']] == dispatch['batch']['proposal_ids']
assert all(item['state'] == 'waiting' for item in completion['proposal_results'])
assert all(value is None for value in completion['tests'].values())
assert completion['fixes'] == [] and completion['merged'] is None
status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert status == '' and head == completion['base']
assert subprocess.run(['git', 'diff', '--exit-code', 'HEAD', '--'], stdout=subprocess.DEVNULL).returncode == 0
assert json.loads((OUT / 'gitleaks.json').read_text()) == []
result = {
    'base': head, 'git_status_porcelain': status, 'head_unchanged': True,
    'ledger_cli_exit_code': 0, 'ledger_items': 31, 'ledger_prefix_preserved': True,
    'unchanged_non_trace_fields': True, 'status_free_history_entries_added': 31,
    'gitleaks_exit_code': 0, 'gitleaks_findings': 0, 'evidence_rows_verified': 4489,
    'material_checks': json.loads((OUT / 'material-checks.json').read_text())['passed'],
    'narrow_input_readback': 12, 'production_tests': completion['tests'], 'merged': None,
    'files': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in [
        OUT / 'report.md', OUT / 'proposal.md', OUT / 'completion.json', OUT / 'ledger-updates.json',
        OUT / 'ledger-appended-this-batch.jsonl', OUT / 'source-readback.json', OUT / 'evidence/evidence-manifest.json',
    ]},
}
(OUT / 'final-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

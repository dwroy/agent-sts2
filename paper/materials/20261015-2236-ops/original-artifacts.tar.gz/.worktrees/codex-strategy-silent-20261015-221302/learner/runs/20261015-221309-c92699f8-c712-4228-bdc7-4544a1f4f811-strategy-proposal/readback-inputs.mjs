import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseGameState } from '../../../agent/src/hand/mod/schema.ts';
import { handTrickSlothFacts } from '../../../agent/src/hand/screens/silent-hand-trick-facts.ts';
import { observedDemonPoison } from '../../../agent/src/reflex/silent-demon-potion.ts';

const folder = fileURLToPath(new URL('.', import.meta.url));
const input = JSON.parse(readFileSync(folder + 'KFRDELW2TH2P.input.json', 'utf8'));
const records = [];
for (let at = 0; at < input.decisions.length; at++) {
  const decision = input.decisions[at];
  if (decision.floor !== 33 || decision.turn !== 7) continue;
  const selection = decision.label === 'selection/choose' && decision.expect?.option?.id === 'BURST';
  const potion = decision.chosen?.action === 'use_potion' && decision.expect?.potion?.id === 'POISON_POTION';
  if (!selection && !potion) continue;
  const matches = input.states.filter((row) => row.observed_ts === decision.observed_ts && row.fingerprint === decision.fingerprint);
  assert.equal(matches.length, 1);
  const state = parseGameState(matches[0].state);
  if (selection) {
    const previous = input.decisions[at - 1];
    assert.equal(previous.expect?.card?.id, 'HAND_TRICK');
    assert.equal(previous._line + 1, decision._line);
    const options = handTrickSlothFacts(state, true);
    assert.ok(options);
    const fact = options.get(decision.chosen.option_index);
    assert.ok(fact);
    assert.equal(fact.remaining_manual_plays_upper_bound, 2);
    assert.equal(fact.target_requires_later_skill, true);
    assert.equal(fact.continuation_verified, false);
    records.push({ line: decision._line, state_line: matches[0]._line, kind: 'hand_trick', fact });
  } else {
    const amount = observedDemonPoison(state);
    assert.equal(amount, 6);
    records.push({ line: decision._line, state_line: matches[0]._line, kind: 'poison', amount });
  }
}
assert.equal(records.filter((row) => row.kind === 'hand_trick').length, 6);
assert.equal(records.filter((row) => row.kind === 'poison').length, 6);
writeFileSync(folder + 'current-input-readback.json', JSON.stringify({ scope: 'existing_narrow_inputs_only',
  records, limitation: '六次相关读档，同局固定输入；没有完整合法后继、整战或自然消费者验收。' }, null, 2) + '\n');
process.stdout.write(JSON.stringify({ hand_trick: 6, poison: 6, status: 'passed' }) + '\n');

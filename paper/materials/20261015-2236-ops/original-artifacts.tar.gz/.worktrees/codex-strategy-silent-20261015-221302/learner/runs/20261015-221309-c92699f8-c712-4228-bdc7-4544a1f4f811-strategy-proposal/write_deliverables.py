import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch-proposals.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
stamp = (OUT / 'checked-time.txt').read_text().strip()
details = [
    ('护栏候选与实线归属',
     'MTQ0EUBJ3R6T F11T1：decisions 282138 原答plan6、护栏plan1；282139弃牌选择后282140重问并实打迷雾；states 288592—288597为67→61血、敌90→70、实际建立4毒。',
     '候选审计、单动作派发回执和离线关联已存在；F11弃牌后重问实打迷雾，缺完整候选执行归属及同窗口实线排名，不能将候选省8血/多2伤计作实际收益。',
     '原候选不建毒，实际后来建毒，不能由16对20伤定位模型错误；原线完整长期收益及整场结果没有配对。',
     '已有审计保持预测与观测分开；未来须用同一题候选标识绑定完整动作，选牌/重问处失效，缺唯一可比结果填未知。'),
    ('十四项时点机制组合',
     '7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T F17T4—T8、F20T3、F23T3。本批固定核F20轮初3/3/4能、磨蚀后1敏捷/4荆棘但0牌挡；F23速度后19挡、10→2血且下轮撤临时敏捷。',
     '普通机制已有局部处理，但十四项属性、持牌伤、能力与药效时点尚缺逐项到联合消费者的固定校准，不能整包登记duplicate或推新组合。',
     '额外能量与建立能力不等于即时挡；本批未独立重核原118局机制分母，不把本批四局替代历史全样本。',
     '逐项在原角色/已观察组合中比对即时值、撤销边界与持续效果；每一项的局部通过不能替代全包验收。'),
    ('持续敌血池与终局/SL价值',
     '7X0W3U8TVA2A F31T1—T13：活段初始HP合150、已见新增175、可见HP下降下界278、最后存活47；MTQ0EUBJ3R6T F23T3/T5，旧提案的四试边界。',
     '已有敌HP变化与终局端点审计；缺生命周期到实际终局的联合校准及冻结知识下同输入整战对照，不能由饱和死亡样本修改SL或终局权重。',
     '暂死活段清零不是整战结束；可见HP下降下界不是完整逐击伤害事件账；缺帧不能补毒结算。',
     '保留严格终局/必死边界，显式记录新增活体、复接和未知身份；先校准终局预测，再评估策略差异。'),
    ('连续赢战与资源来源',
     'MTQ0EUBJ3R6T F17→18为19→59；F19入房59→46、F20入房46→8；7X0W3U8TVA2A F17→18为28→61，F30胜后67进F31。入房与开场回血后的HP分开。',
     '赢战记录和HP增加边界已有；缺逐源恢复/药槽事件到完整路线、休息题面的固定消费者读回，不能整项duplicate或重定安全阈值。',
     '计划中的营火未到达时不能计入当前资源；路线非随机选择，胜败与回血不能给替路线因果。',
     '复用现有日记，分列已到节点、入房/可操作HP、来源未隔离、SL恢复；未来保存完整构筑题面与已发生事件的对应关系。'),
    ('奇巧后继与知识恶魔毒药',
     'KFRDELW2TH2P F33六次T7：选择行282864/282899/282933/282968/283001/283035均给爆发；末states289533—289538三牌满、余1能量爆发锁住，毒37→43、敌159保持，最后扣85到74且玩家0血。',
     '奇巧剩名额/能量与限定组合毒药6层入口已有，6次选择和6次药水输入固定读回通过；完整合法后继和目标收益兑现未认证，缺替目标/顺序整战证据。',
     '手上技法7挡有效，目标爆发未施放；不能以换目标可打替代完整收益或断言能赢；六次为同局相关重试。',
     '保持所有选择可选，提供已核剩余名额和成本；continuation_verified=false保留，条件外毒药仍未知，不设一律早喝或固定选防御。'),
    ('SL同盘血价与重问',
     'KFRDELW2TH2P F12T1 decisions282578→282579生成小刀后重问；F33首试/第三试T6，states289339/289414同为15血、敌228、36毒、3覆甲，下一轮9/3血、敌145/135；282929明确SL替换。',
     '候选和SL资源差审计已有；同盘多扣10/多损6仅为局部观测，缺完整候选执行归属和同输入整战校准，不调整探索排序或护栏阈值。',
     '两条实线都在T7失败，原线不是已知胜线；F12护栏候选0损后来不同实线损6，不构成候选预测错误证据。',
     '按预测阶段和实际动作分列当前资源差；生成/选择/重问后重读状态，同盘局部收益只作诊断，不当整战胜率。'),
    ('药效与能力的分时点覆盖',
     'KFRDELW2TH2P F28T2敏捷药；F33六次T2铁心、T5触媒、T6覆甲3、T7覆甲2与毒药6层。固定验证的药水入口仅为本局T7完整修饰条件组合。',
     '知识恶魔毒药6层入口已核为live祖先源码，旧的“只支持双boss”理由已不适用；其余药效/能力联合多轮校准及覆甲完整减层条件仍缺。',
     '覆甲7→2不能证明每轮固定减1；敏捷须由后续挡牌兑现，毒在实际结算前不能当本体伤；原历史药水分母本批未重算。',
     '只核已观察药效入口及实际修饰条件，逐时点标未知；不从持有、已饮或施毒推断留药价值、最佳时点或整战收益。'),
    ('奇巧、SL及终结全链',
     'KFRDELW2TH2P F33T4回血观察、T6同盘换线、六次T7奇巧和毒药；末试敌74仍活。原提案把完整终局需求与候选当前净扣分列。',
     '奇巧事实、毒药与阶段审计已有；合法后继到实际终结全链尚未验证，缺换对象/顺序/提前饮毒的完整对照，不可据窄入口关闭宽项。',
     '实际85毒伤仍未击杀；前三类未执行窗口不能补算为实际收益，历史平均三牌不证明本组合零血价。',
     '终局比较保留当前严格生存与未知抽牌；未来用完整后继/能力建立/伤害兑现/结局逐段验收，不把残血更低写成更安全。'),
    ('赢战血价和路线/休息消费',
     'KFRDELW2TH2P F30入房65→27、F31入房27→15，两场胜利净耗50；F33入房36、开场38。此前F17→18为22→60。',
     '赢战净耗和HP增加边界已有；缺分源事实到完整路线/休息消费者的固定对照，以及替路线/回血对锻造完整结果，不改安全节点或阈值。',
     '赢战也可显著消耗后续资源；六次回血仍败不证明回血错误。净HP差包括恢复/自损，不能统称敌伤。',
     '把已到回复、战斗开场、SL恢复、药槽变化和前序战斗端点分开；未隔离的来源保留未知，策略阈值须独立验证。'),
    ('复活后血价与逐槽资源链',
     'GXNKW8X1XYJP F35/38/40胜后入房HP97→84→66→41，F44入房71、胜后5；F45第二/末试T2同2血与三敌84/84/77，T3实为3血0挡与13血7挡、敌多8血；decisions283680/283691，states290160/290165/290201/290206/290213—290214。',
     '已有候选、SL差与单动作回执审计；缺逐击复活帧、完整候选归属和逐槽资源消费全链，两条实线均败，不能据多保10血修改SL或必死规则。',
     '末试13血、23牌/带挡、2覆甲对40，least-loss为13−(40−23−2)=−2，与实死一致，不是负数bug；瓶中精灵自动消耗不同于主动喝药。',
     '保留原评分和精灵语义，逐阶段记录可操作HP窗口与资源是否仍在原槽；缺完整复活帧就标缺失，不把端点恢复当敌伤或路线回血。'),
]

results = []
sections = []
for proposal, detail in zip(dispatch['proposals'], details, strict=True):
    title, evidence, reason, counter, expected = detail
    results.append({'id': proposal['id'], 'state': 'waiting', 'reason': reason})
    sections.append(f"## {proposal['id']}：{title}\n\n"
                    f"账本：{', '.join(proposal['ledger'])}。原任务：{proposal['source_task']} → strategy-proposal。\n\n"
                    f"证据：{evidence}\n\n反例与限制：{counter}\n\n"
                    f"现有行为与预期：{expected}\n\n处置：waiting。{reason}\n\n"
                    "验证：原字节、题面候选和观测端点分别核对；按本节缺口补固定状态与实际消费者，再用新的独立静默局留出验证。"
                    "旧dirty源码不能固定重现时保留未知；不把同局SL拆为独立训练/验证局，不使用其他角色数据。\n\n"
                    "本批未改源码、参数或知识，无新增提交及回退动作。后续若实现应独立提交，原阈值保留；回退该实现提交并保留原证据。\n")

proposal_text = (f"# 本批十项静默策略提案核验\n\n核验时间：{stamp}（写前已执行date）。\n\n"
                 f"批次：20261015-221302-strategy-proposal；基线：{source['base']}。\n\n"
                 "仅处理learn.json本批领取的十个ID。它们均为已有CLI提案，原文SHA全部匹配；不新建重复ID，不改原文。"
                 "本批没有research_request、implementation_request或proposal_repair，不承接任何专题；普通专题请求绑定其他旧批次，未读取其work_spec/manifest。"
                 "git status开工干净，git merge --no-edit main返回Already up to date。\n\n"
                 "以下是证据受限的逐项处置，全部waiting；已有窄实现不等于宽提案已完成。出牌、药水、SL和终局规则保持当前值，其他角色等价。\n\n"
                 + '\n'.join(sections))
(OUT / 'proposal.md').write_text(proposal_text)

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
table = '\n'.join('| ' + str(m['stream']) + ' | ' + ' | '.join(str(m['counts'][run]) for run in dispatch['batch']['runs']) + ' |' for m in manifest)
report = f"""# 静默策略批次核验报告

记录时间：{stamp}（先date后写）。批次20261015-221302-strategy-proposal，角色silent。

本批十项均waiting，没有新增源码、知识条目、策略参数、提交、合入或行为发布。报告和原提案核验材料保存在本任务scratch。父学习要求、历史量化请求及自然消费者验收保持原归属，报告不等于入库或采用。

## 身份和范围

完整base为`{source['base']}`。开工工作树干净，普通任务按要求merge main后仍为该HEAD。learn.json对应行task/character/worktree/runs均匹配；有十个proposal_ids，无research_request/implementation_request/proposal_repair，不退回普通自由选题或处理其他批次。没有读取另一专题替代身份，没有修改根请求、learn.json或原提案。十份Markdown字节及SHA均与原队列吻合，见proposal-fingerprints.json；31条既有silent账本项只补追溯链接，不更改claim/证据/首证/先验/status/版本，不新造经验或ID。

四局runs.jsonl均SILENT/A10：MTQ0EUBJ3R6T F23败、7X0W3U8TVA2A F31败、KFRDELW2TH2P F33败、GXNKW8X1XYJP F45败。原版本分别ceb74207+dirty、047c809e+dirty、a73ce7cc+dirty、b1714285+dirty，不能据此重建完整旧源码和知识输入。本批不声称核实了当前学习者的原生模型请求参数，也没有修改模型/账号/权限。

## 冻结原证据

使用任务指定extract_evidence.py，按显式run/run_id/state.run_id/fingerprint.run筛选，保存每流source_size、逐行offset/bytes/SHA及计数。随后独立从原文件按offset回读全部4,489行，逐字节SHA、JSON、身份及截点均相同，见evidence-validation.json和analyze_evidence.py。

| 流 | MTQ0 | 7X0 | KFR | GXN |
|---|---:|---:|---:|---:|
{table}

states/decisions各有2条、brain有1条全源不可解析记录，抽取器保留计数，未将其补为本角色事实。fight-plans本截点0行只表示未选到，不推断原流缺失。本次没有复用或覆盖旧截点输出。未重算原提案引用的118/119局机制全史及药水历史分母，只核本批四局与既有账本链接。

## 关键结果与限制

逐项证据、层/回合、账本、反例、预期行为和验证方法见[proposal.md](proposal.md)，对应最终proposal_results十项，均不冒称duplicate/implemented。

- MTQ0 F11护栏候选预测省8血、多2即时伤；实际生存者后选择连续反弹，随后重新选迷雾和中和，最终67→61、敌90→70并已有毒。原候选16伤与实际20不可直接作为模型误差；也不能把候选无毒套到重问实线。
- KFR F12生成小刀后重问。F33同盘T6的两条实线分别损6/12、净扣83/93，多扣10同时多损6，随后均败。六次奇巧均给爆发，末试三手动动作满、仍余1能量而锁牌；7+5牌挡已兑现，爆发收益未兑现。毒37→43时本体不变，之后两次结算85、敌仍74。
- GXN F45同盘T2后T3分别为3/13血、0/7带挡，替线敌多8血。末试13−(40−23−2)=−2与实际死亡一致，不认定least-loss负数bug。缺逐击复活帧，端点净HP变化不当完整敌伤。
- 7X0 F31活段初150、已见新增175、可见HP下降下界278、末仍47。它是生命周期与可见端点审计，不是完整攻击事件账或终局正确性的整战证明。
- 原资源链重新由本批原状态生成，保留重试/缺出口：MTQ0 F19/F20连续赢战入房59→46→8；KFR F30/F31净耗50，F33入房36/开场38；GXN后段胜利仍97→84→66→41，F44胜后5入F45。入房、可操作HP、回复及SL恢复分开，不推替路线因果或新的安全阈值。

## 已有源码核验

抽样实际live HEAD为`{source['live']}`；读取Git对象，比较18个相关源码叶，15个逐SHA相同，card-model.ts、run-journal.ts、build-facts.ts仅有已保存的Roy/Dai历史注释文字差异。原字节差异完整保留base-live-source.patch；没有编译后等价或整个live树一致的额外声称。实际创建/实现祖先及SHA见source-readback.json。

候选/护栏/SL差审计存在于live祖先66283dd9982bdd7f480da7a4d9bfefea0572a9ac，单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed，离线执行审计02c4e13ac8e159b82ee35a965ac788a0a029ce5a；奇巧/限定恶魔毒药入口c4a4f4a94b48dff9b30aaa7228624c1092150145已实际为live祖先。源码明确区分预测、单动作回执及未知完整执行；奇巧continuation_verified=false。这里仅引用既有窄项，不把这些提交登记为本批实现或整包完成。

## 材料验证

固定材料检查45项通过（见material-checks.json），不是生产tsc/vitest。调用当前原有handTrickSlothFacts与observedDemonPoison，六次选择均提供剩2手动名额/爆发还需后续技能且后继未知，六次药水输入识别6层；12个旧帧读回通过（current-input-readback.json）。这只验证限定入口，未重跑整战模拟、未使用刷新知识JSON、未调LLM或联网，未当新自然消费者或收益。

现有audit-selection.ts离线首批MTQ0/7X0成功，KFR因原decision 282561无decision_id返回1，原stderr/零输出原件保留。GXN另有283515/283525/283581三个空ID；未伪造ID、重排或拼接，按原行号在每个缺口断开，KFR两段、GXN四段各自通过。共8个成功审计输入包含2,101/2,105条决策，4条原行仍保留原抽取与完整input及问题清单。483个问题段、352个轮窗中70个有严格端点、282个unknown；候选全链结果字段设计上保持null，这不等于实盘候选全部未执行或审计覆盖完整真实动作。见audit-input-issues.json、audit-parts.json、selection-audit-summary.json与各原输出。

初始resource-summary.json按旧记录不存在的hp_guard结构字段统计，不能当护栏0次；resource-summary-corrected.json另以原rationale核出MTQ0/KFR各1次、7X0/GXN各0次，旧初稿保留。另有宿主bubblewrap瞬间缺路径、只读检索/源码比对误用不存在路径，均已纠正且写preparation-errors.txt；不当产品bug或测试结果。

本批没有源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试，不制造成功测试、空提交、空合并、eval版本或shipped。没有改规则，无规则上线双通知。输出gitleaks扫描及最终工作树/账本读回另存final-verification.json。

## 运维交付

提案路径：`{OUT / 'proposal.md'}`。

报告路径：`{OUT / 'report.md'}`。最终逐项处置保存在completion.json。本批只将两份材料追溯链接经根learner/ledger.py update追加到31个已有账本条目；没有对新结论强行support，没有把waiting排队或既有窄源码当完整学习入库。无源码合入，merged=null；后续仅按每项具体缺口等新证据，不重复登记原提案。
"""
(OUT / 'report.md').write_text(report)
completion = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-221302-strategy-proposal',
              'base': source['base'], 'runs': dispatch['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
              'tests': {'tsc': None, 'vitest': None, 'cases': None},
              'code_proposals': [p['id'] for p in dispatch['proposals']], 'implementation_domains': [],
              'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'completion.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2) + '\n')
updates = [{'id': id, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': '20261015-221302-strategy-proposal仅核本批十项原提案及四局原字节：全部waiting。已有窄实现与缺完整候选/联合校准/逐源消费者数据分别见报告；仅追加追溯，不新增证据、规则、实现、版本或更改原status。'}
           for id in sorted(json.loads((OUT / 'ledger-before.json').read_text()))]
(OUT / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal_results': len(results), 'ledger_updates': len(updates)}, ensure_ascii=False))

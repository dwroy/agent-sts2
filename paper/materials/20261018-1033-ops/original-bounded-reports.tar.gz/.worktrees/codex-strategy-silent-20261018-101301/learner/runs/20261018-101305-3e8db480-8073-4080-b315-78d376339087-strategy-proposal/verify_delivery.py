"""Verify the unchanged checkout and the exact metadata append owned by this batch."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261018-101301-strategy-proposal'
result = json.loads((OUT / 'result.json').read_text())
expected = json.loads((OUT / 'dispatch-identity.json').read_text())
assert result['code_proposals'] == expected['proposal_ids']
assert [x['id'] for x in result['proposal_results']] == expected['proposal_ids']
assert all(x['state'] == 'waiting' and x['reason'] for x in result['proposal_results'])
assert result['runs'] == expected['runs'] and len(set(result['runs'])) == 10
assert not result['fixes'] and result['merged'] is None and result['implementation_domains'] == []
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == result['base']
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True)
assert status == ''
assert subprocess.check_output(['git', 'diff', '--binary', head, '--', 'agent', 'learner', 'knowledge']) == b''
for item in json.loads((OUT / 'source-manifest.json').read_text()):
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
    assert Path(item['snapshot']).read_bytes() == Path(item['path']).read_bytes()
    assert item['latest_source_is_live_ancestor']
proposals = json.loads((OUT / 'selected-proposals.json').read_text())
for item in proposals:
    assert hashlib.sha256((OUT / (item['id'] + '.original.md')).read_bytes()).hexdigest() == item['proposal_sha256']

before = json.loads((OUT / 'ledger-prefix-before.json').read_text())
root_ledger = Path(before['source'])
digest = hashlib.sha256()
own = []
with root_ledger.open('rb') as handle:
    left = before['size_before']
    while left:
        raw = handle.read(min(left, 1024 * 1024))
        assert raw
        digest.update(raw)
        left -= len(raw)
    assert digest.hexdigest() == before['prefix_sha256']
    while True:
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        row = json.loads(raw)
        if row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith(BATCH + '：'):
            own.append({'source': str(root_ledger), 'offset': offset, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
requested = [json.loads(line) for line in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
assert len(own) == len(requested) == 29
for entry, original in zip(own, requested, strict=True):
    row = {key: value for key, value in entry['row'].items() if key not in ('op', 'ts')}
    assert row == original
    assert set(row) == {'id', 'by', 'where', 'note'}
assert (OUT / 'ledger-update.exitcode').read_text().strip() == '0'
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
now = ledger.fold(ledger.read_rows(str(root_ledger)))
initial = json.loads((OUT / 'selected-ledger-before.json').read_text())
protected = ('character', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'effect')
for ident, entry in initial.items():
    assert all(entry.get(key) == now[ident].get(key) for key in protected), ident
(OUT / 'ledger-append-proof.json').write_text(json.dumps({
    'prefix_before': before, 'prefix_unchanged': True, 'own_rows': own,
    'protected_fields': list(protected), 'protected_fields_unchanged': True,
}, ensure_ascii=False, indent=2) + '\n')
verification = {'base': head, 'tracked_status': status, 'source_knowledge_tasks_diff_empty': True,
                'original_proposal_hashes_verified': 10, 'pinned_source_leaves_verified': 17,
                'proposal_results': len(result['proposal_results']), 'all_waiting': True,
                'own_ledger_updates_verified': len(own), 'ledger_protected_fields_unchanged': True,
                'fixes': [], 'merged': None, 'tests': result['tests']}
(OUT / 'final-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(verification, ensure_ascii=False))

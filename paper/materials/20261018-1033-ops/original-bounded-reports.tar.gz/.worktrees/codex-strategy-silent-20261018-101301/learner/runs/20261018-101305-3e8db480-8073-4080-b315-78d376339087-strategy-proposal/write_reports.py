"""Prepare this batch's bounded review and append-only metadata request."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = 'e8e9c5753240fcd9ce203bcf1529c6dd8a9c7dc0'
LIVE = 'b155d00a36080418149e63d2f21b491d34d7f40a'
BATCH = '20261018-101301-strategy-proposal'
dispatched = json.loads((OUT / 'dispatch-identity.json').read_text())
proposals = json.loads((OUT / 'selected-proposals.json').read_text())
ledger = json.loads((OUT / 'selected-ledger-before.json').read_text())
identities = json.loads((OUT / 'run-identities.json').read_text())
streams = json.loads((OUT / 'evidence-verification.json').read_text())
consumer = json.loads((OUT / 'consumer-summary.json').read_text())
details = [
    ('抑制战内版本与抽序身份',
     'GXNKW8X1XYJP A10 F45 T2→T3；sl-attempts:1053—1056，clean=19/18/19/18；原提案另关联静默A5/A6/A7窗口。',
     '四次记录均把 BLADE_DANCE/OUTBREAK/SUCKER_PUNCH/ACCELERANT 普通键记为 inserted，同时把升级键记为离堆；原记录保存于 dampen-events.json。',
     '当前 sl/draws.ts 区分带升级标记的堆键；去升级标记的比较不能独自证明某个多副本实体的抽取次序。',
     '缺纯改标与同ID多副本、真插牌/洗牌同帧的消歧负例及 known-draw 消费者完整验证；本次四个旧事件不提供完整抽序，保留原行为。',
     '总数守恒不证明顺序；不能把所有同ID的普通/升级牌强行一一对应。',
     '冻结相邻完整牌区；用纯改标、同ID多副本、真插牌、洗牌和无抑制的正反例检查顺序消费者，未知时仍断序。'),
    ('赢战资源、复活与同盘血价',
     'GXNKW8X1XYJP A10 F44末帧 states:290128—290130 为5HP；F45第2/末次T2→T3；原账本 silent-0019/0020/0079/0243。',
     '原始F44胜后仅5HP，后续F45各次路线/复活资源由实际帧另列；现有离线消费者读回116个候选片段及646个动作，完整候选结果均未知。',
     'selection-observation 已保留药槽观测；silent-sl-resource-comparison 只标当前回合预测，execution=unverified。',
     '缺复活瞬时逐击入伤、前三试退出帧、逐药槽变化来源及替路线/提前用药的完整后继；端点净HP不能补成未截断完整血价。',
     '第2/末次T3的局部保血与少输出不能证明其中一条整场更好；自动消耗、主动饮药和SL恢复不能合计为新获药。',
     '核同入口/同预算完整后继、药槽来源与复活瞬时帧；接口完成、候选、观测净变化分别验收，不拟合药水或血量阈值。'),
    ('普通生存者单弃与持牌伤',
     'PD9AYQVMLQW6 A10 F49第6次T10；states:291336—291342，decisions:284707—284711；silent-0268。',
     '3HP/8挡、两WITHER开场；防御门槛新增一WITHER，18→19→31挡；弃一后32挡/两WITHER，末帧0HP、敌244。24持牌伤+23攻击−32挡=需损15，算术余HP−12，实扣HP被0截断。',
     'bf423c173d3be348a4ad714e1d26516df619ff41 是实际live祖先；当前 card-model.survivorDiscard 和 turn-solver 独立分支已将普通单弃与绷带收益解耦，未知选择留 pending。',
     '普通单弃已有实现；新增凋萎实体、弃牌完成时点、余像与终局消费者的联合校准余项未完成，不能把局部实现登记为整项duplicate。',
     '正确弃一后这一轮仍致死；36→24不是实际多损12，旧预测−1与完整算术−12也不是观测多损11。',
     '按固定T10帧联合验证新增WITHER可弃身份、选择完成后余像、持牌伤与敌击时序；再核无状态牌、唯一后继、有绷带与未知选择边界。'),
    ('Jev、支配、护栏、SL与药水链',
     'L2TSFU62Z57Z A10 F17 T2/T3；decisions:284918/284967/284971/285020/285024/285073/285077/285126/285130；silent-0125/0005/0044/0253。',
     '既有九条护栏原记录保留；离线读回93个候选片段/441个动作，能定位同题文字，但完整候选结果仍全为null。六条无decision_id的元数据在四局输入中单列排除，本局其中一条。',
     'silent-selection-audit 有 answer/before_sl/after_sl 和 pending_dispatch；silent-hp-guard-audit 有 before_guard/after_guard，但 actual_outcome=null；均已在live祖先链。',
     '缺跨抽牌/弃牌重问的完整父子候选归属和饮药、自动消耗、SL恢复的完整来源认证；现有预测阶段记录不等于实线完成。',
     '被SL撤回的护栏不能累计为实际保血；T3重问后的全轮输出不能归给重问前零伤候选。',
     '逐题保留父子身份和阶段来源，再以动作回执及实际状态校验前缀；完整线缺失保持未知，保留现有护栏、药水与SL参数。'),
    ('仪式兽阈值、一牌额度与全败并列',
     'L2TSFU62Z57Z A10 F17末试T6 decisions:285148；末T8 states:291790—291792；silent-0021/0133/0222/0049/0020。',
     'T6同题打击+侧步7伤线五轮死亡14/24，结束线11/24；三条整场模拟均0/1200赢且标并列，侧步标unmodelled。末T8精密瞄准实际扣16，17HP/0挡后死亡，敌113。',
     'combat-plan.playCap 读取 RINGING_POWER 后上限1；剩余能量并未解除这一上限。',
     '缺侧步完整可验证后继与同预算、同随机/抽序的候选整战对照；即时7伤不支持改变全败排序或SL边界。',
     '7伤线的短程死亡样本更多，整场皆无赢样本；不能由“还能付费”推出“还能出牌”或提前认定补打能胜。',
     '保留160阈值与一牌额度现场限制，按固定原题记录即时伤、抽牌/增能未知及完整后继；推演并列继续并列，不删选项。'),
    ('十五项能力、逐牌逐击与实际兑现',
     'PD9AYQVMLQW6 A10 F49 T10；L2TSFU62Z57Z A10 F6T2/T3、F14及F17；关联原提案15个账本ID，详见下方逐项链接。',
     'PD9末轮现场四敏的挡与凋萎结算可核；L2 states:291420—291423 速度药当步0挡、随后防御10且51HP保持，下一轮恢复正常状态。仅核本批相关局面，不重新声称原18局全史/十五入口全部通过。',
     'card-model/turn-solver/fight-plays 已有对应部分入口；单个公式、被动层与实际施放的区分不能替代所有生产消费者联合校准。',
     '缺十五机制逐入口至联合生产消费者的完整校准；覆甲减层、力量对滚石、换战能力边界未隔离，本批不补未观察组合或参数。',
     '持有未施能力和死亡后本应触发的滚石都不算已造成伤害；不同药水时点并非受控胜率比较。',
     '按每项原实盘阶级分别对入口、出牌/逐击时序、换战重建和终局累计做固定数据验证；不从字段存在宣称整项实现。'),
    ('连续Boss与路线、休息接续',
     'PD9AYQVMLQW6 A10 F48→F49；states:291018—291020 首Boss后10HP；L2TSFU62Z57Z A10 F14—17；silent-0019/0020/0021/0090/0228/0239/0243。',
     'PD9 F48末实际10HP；原提案的F49六次10HP空槽接续保留，不能套跨幕回复。L2药水与休息资源只认实际获得。',
     'bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07 为实际live祖先；continuous-boss-result明确same_sample，calibration/actualSecondOpening/rewardsBetweenFights均unknown，S=null。',
     '同样本资源诊断已有实现；奖励转移、真实次战开场及路线/休息消费者联合校准仍缺，不能把原始模拟率或框架视为已量化学习。',
     '第一Boss获胜不等于终战结束；未来营火、计划能力和未取奖励不等于当前可用HP/药水。',
     '核同样本首战实余血药/复活至次战实际入口、奖励/开场副作用和路线/休息读回；无受控数据不拟阈值、不重拟四局模型。'),
    ('有限推演与SL后实线分账',
     'PD9AYQVMLQW6 A10 F49末试T7→T10；L2TSFU62Z57Z A10 F17 T2/T3；silent-0021/0133/0222/0228/0239。',
     '四局离线消费者保持预测、接口回执、重问与观测区间分离；488个片段没有一个被认证为完整候选结果。PD9末实活到T10与旧有限推演不能在缺执行认证时拼成同一候选误差。',
     'silent-selection-audit、SL资源比较及离线 selection-execution 均保留unverified/null边界。',
     '缺原线/改线完整执行认证及同入口、同预算整战后继；观察端点不能补成原候选因果结果，不能据有限全败修改必死/SL。',
     '抽牌重问后的输出属于后续题目；相同SL存档的多次尝试不构成多局独立验证。',
     '冻结每题完整输入和候选，记录实际前缀、重问与出口，后期新局作独立验证；同局SL仅作相关诊断。'),
    ('同族群伤与逐目标退场进度',
     'ZTRGYYMLR8SC A10 F17第6试T1/T7/T8/T11/T14；states:292332/292363/292369/292384/292402；silent-0021/0012/0046。',
     '初始三敌62/63/199合324；T7剩37/154、T8剩20/142；末敌58。敌数组删员后序号会变，未补造T6击杀帧。',
     'd1713559f2d237a04b681ec6497ce0c8798ae0f0 为实际live祖先；silent-kin-progress提供当前hp_sum/priest_hp和暂减力事实，注释明确不是跨帧实例ID或精确击杀时间。',
     '当前总血与暂减力快照已有实现；缺稳定敌实例、精确退场边界，以及构筑能力实际取得/建立至输出兑现的完整链。',
     '两只同类型信徒不能按enemy_id或数组序号匹配稳定身份；目标/药物/抽序同时改变的尝试不能隔离集火收益。',
     '仅报告首次可见退场区间，核取得/建立/兑现事实链；继续提供所有目标，不加固定先杀对象或安全DPR阈值。'),
    ('HP护栏局部与整轮血价',
     'ZTRGYYMLR8SC A10 F11T3 d285301；F17首T10 d285405；末T13 d285745，末T14 s292402；silent-0125。',
     '三个原取舍与完整原决策已保存于key-decisions.json；离线读回130个候选片段/594个动作，9次同题文字歧义保留，完整候选与actual_rollout_best仍null。',
     'silent-hp-guard-audit 只提供预测节省，actual_outcome=null；完整回合净变化由独立observed_turns列出，不能直接归因护栏。',
     '缺跨重问完整归属与原线/替线同预算整战后继；局部端点能核不代表完整省血或输出收益，现有8/24/0参数不变。',
     '三个局部候选省血数不能直接合成全局实得；末轮额外7输出与多损2的胜负反事实未知。',
     '对每阶段单列局部预测、实际提交、重问边界及整轮观测，缺帧留unknown；不由说明次数替代最终执行分母。'),
]
reviews = []
for proposal, item in zip(proposals, details, strict=True):
    title, evidence, facts, current, reason, counter, validation = item
    reviews.append({'id': proposal['id'], 'title': title, 'ledger': proposal['ledger'],
                    'evidence': evidence, 'verified_facts': facts, 'current_implementation': current,
                    'state': 'waiting', 'reason': reason, 'counterexample_or_limit': counter,
                    'expected_behavior': '证据补足前保持现有策略；局部已实现不关闭原宽提案。',
                    'validation': validation, 'rollback': '本批无源码/知识改动，无需行为回退；原证据、失败与账本记录保留。'})
(OUT / 'proposal-review.json').write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
results = [{'id': row['id'], 'state': row['state'], 'reason': row['reason']} for row in reviews]
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatched['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [row['id'] for row in proposals], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

text = ['# 静默猎手本批十项已领取提案复核', '',
        f'批次：{BATCH}；角色：silent；基线：`{BASE}`。',
        '本批无research_request/implementation_request。普通任务按要求执行一次git merge --no-edit main，返回Already up to date；初始工作树干净。没有领取其他提案。',
        '来源/实现任务为本批strategy-proposal；沿用Roy-2026-10-07-learning授权。原提案Markdown全部保留为*.original.md，十份SHA与队列登记完全一致。',
        '本批仅在learner/runs内保存复核材料，根账本只通过既有ledger CLI补where/note；不新建重复提案，不重写原复盘，不新增游戏规则。',
        '']
for row in reviews:
    text += [f"## {row['id']}：{row['title']}", '',
             f"账本：{', '.join(row['ledger'])}。", f"证据局/层/回合：{row['evidence']}",
             f"核实：{row['verified_facts']}", f"现有实现/旧行为：{row['current_implementation']}",
             f"处置：waiting。{row['reason']}", f"反例与限制：{row['counterexample_or_limit']}",
             f"预期行为：{row['expected_behavior']}", f"验证方法：{row['validation']}",
             '拟合与切分：不拟合新权重/阈值；本局及相关SL只作固定诊断，新结束的本角色同进阶局另作后期验证。',
             f"回退：{row['rollback']}", '']
(OUT / 'proposal.md').write_text('\n'.join(text) + '\n')

report = ['# strategy-proposal 本批回报', '',
          f'基线：`{BASE}`；复核时实际live：`{LIVE}`。',
          '十项全部waiting，fixes=[]、merged=null、implementation_domains=[]。没有新增源码、知识、经验、任务模板或行为版本，没有提交或合入live；HEAD保持上述40位基线，工作树最终应保持干净。',
          '实际执行的是当前普通提案任务，不是纯研究或量化实现请求；不关闭任何原科学父要求。', '',
          '## 身份、原件和范围', '',
          'dispatch-identity.json保留本批唯一调度行；已核task/character/worktree及10个proposal_ids，未绑定research_request/implementation_request。专题根请求属于另一批，不套用。',
          '10份原始提案SHA全部匹配；selected-proposals.json、selected-ledger-before.json、run-identities.json保存本批输入。账本只使用所领提案关联ID；不拿其他角色知识。',
          '本批runs只填十个派发锚点；另按原提案43fe/3f5的直接关联补核ZTRGYYMLR8SC，补证不改派发身份。原机制宽提案另有11个同角色历史ID只核runs角色元数据，未重做全史，不计新支持样本。',
          '当前模型/强度未通过本任务工具独立核验原生会话请求，不因文档或默认配置填写“已切换”。无模型调用、联网、对局/模拟或子agent。', '',
          '| 本次抽取局号 | 进阶 | 终层 | 原始victory |', '|---|---:|---:|---|']
for run in dispatched['runs'] + ['ZTRGYYMLR8SC']:
    info = identities[run]
    report.append(f"| {run} | A{info['ascension']} | {info['floor']} | {info['victory']} |")
report += ['', '## 日志截点与核验', '',
           '使用共用learner/extract_evidence.py，一次提取十锚点加直接关联补证局的八个流；全部以显式run_id/state.run_id/run/fingerprint.run归局，冲突身份拒收。',
           'evidence/evidence-manifest.json记录每流source_size、每局计数、输出SHA；逐条证据保存原行号、offset、bytes、SHA和原JSON。audit_evidence.py实际从只读logs按偏移读回所有记录并核字节SHA/JSON/身份/截点/输出SHA。', '',
           '| 流 | source_size（字节） | 选中行数 | 全源前缀坏行 |', '|---|---:|---:|---:|']
for stream in streams:
    report.append(f"| {stream['stream']} | {stream['source_size']} | {stream['rows']} | {stream['invalid_lines_in_whole_source_prefix']} |")
report += ['', f"共{sum(x['rows'] for x in streams)}条逐行核回；各流截点分别在打开源时冻结，不冒称原子跨流快照。states/decisions/brain各2坏行只代表全源前缀异常，不能归到本批。全部incomplete=0。fight-plans本截点0行只说明此截点未选到，不能断言历史日志缺失。", '',
           '## 固定证据及消费者读回', '',
           '四局A10原样输入现有离线selection-execution消费者，保留原始行号和SHA，不调LLM、游戏或知识库。四份输出均gzip无损保存，解压后SHA与读回摘要一致。六条map/route-change原始元数据无decision_id，独立登记excluded-metadata.json；没有伪造ID或把过滤数组重编号。', '',
           '| 局号 | 候选片段 | 动作 | 唯一文字匹配 | 歧义匹配 | 完整候选认证 |', '|---|---:|---:|---:|---:|---:|']
for row in consumer:
    report.append(f"| {row['run_id']} | {row['segments']} | {row['observed_actions']} | {row['final_match_counts'].get('unique_logged_text', 0)} | {row['final_match_counts'].get('ambiguous_logged_text', 0)} | {row['certified_full_candidate_results']} |")
report += ['', '合计488片段、2696动作；所有actual_full_candidate_result和actual_rollout_best均null。这里只核到原消费者能保留的关联与限制，不能写成源码测试、完整候选执行、生产自然采用或胜率校准。',
           '159个关键状态压缩视图见focused-frames.json，25条关键决策原行见key-decisions.json；完整原件仍在evidence目录，可由offset/bytes/SHA重取。', '',
           '关键结论：PD9 F49末T10的3HP与32挡，对24持牌伤+23攻击仍需损15；修正单弃不能证明翻盘。L2 T6即时7伤与结束的短程死亡14/24及11/24不同，三条整场候选均0/1200且侧步未建模，不据此改排序。ZTR同族324总HP与末58HP可见，但删员后序号重排，不能补造稳定敌实例或精确击杀帧。GX F44胜后实5HP与F45净变化，不能反推复活逐击完整入伤。', '',
           '## 当前源码与已有局部实现', '',
           'source-manifest.json固定17份相关源码叶的base、blob、SHA、原字节副本和live祖先关系；不是整仓快照或历史dirty运行树复原。两份base/live差异（card-model、sl/draws）仅注释署名变化，原始两侧与binary diff均保留。其余选定叶相同；不据此声称全部live/基线等价。',
           '- 普通生存者单弃：bf423c173d3be348a4ad714e1d26516df619ff41，实际live祖先；余项仍缺联合校准。',
           '- 同族当前血量/暂减力：d1713559f2d237a04b681ec6497ce0c8798ae0f0，实际live祖先；不提供稳定实体或精确击杀时间。',
           '- 连续Boss原始阶段/同样本资源诊断：bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07，实际live祖先；actualSecondOpening和calibration仍unknown。',
           '- 候选/护栏/SL资源预测：66283dd9982bdd7f480da7a4d9bfefea0572a9ac及9d8278702dbc581b5015ba7ec9a70dc0fb94cccb均为实际live祖先，当前源码保持actual_outcome/null和execution/unverified边界。',
           '所有原局runs.code均带dirty，未获得原局完整dirty源码；当前源码只用于现状核对，不替换原运行身份。', '',
           '## 逐项处置', '',
           '| 原提案ID | 账本 | 处置 | 具体原因 |', '|---|---|---|---|']
for row in reviews:
    report.append(f"| {row['id']} | {', '.join(row['ledger'])} | waiting | {row['reason']} |")
report += ['', '每项证据局/层/回合、反例、旧行为、预期行为、切分、验证与回退完整列在proposal.md及proposal-review.json；没有忽略任何派发ID。waiting由原队列等待新增本角色证据后接续，不能用上述局部实现冒记整项implemented/duplicate/shipped。', '',
           '## 记录、测试与交付', '',
           '只通过根learner/ledger.py update补本批proposal/report追溯和逐项waiting说明；仅where/note，不写status/evidence/version/effect/claim，不新增支持或重复样本。旧条目既有shipped等状态属于历史，不倒退成proposed；本批无新知识提案。CLI输入、退出码、回执及追加行证明单独保存。',
           '没有源码改动，故撤源码失败/恢复通过不适用；tsc、vitest、cases均为null，没有运行生产自测或借用旧绿。没有提交，故无源码提交号/合入号/版本及上线通知。',
           'source输入空diff保存在unchanged-inputs.patch；最终工作树/HEAD及材料哈希核验见final-verification.json和artifact-manifest.json。凭据扫描结果见gitleaks.log；扫描结果以实际退出码记录。',
           f'交付提案：{OUT / "proposal.md"}', f'回报：{OUT / "report.md"}',
           '最终机器回报保存在result.json；这里的evidence及离线读回属于证据验证，不填成测试通过或实际采用。', '',
           '## 限制', '',
           '- 没有新独立对局、受控替路线/药水时点/目标或同预算完整后继，不拟合新阈值。',
           '- 六次SL属于一局相关尝试，重读原日志不增加支持局数；模拟样本数不是实盘局数。',
           '- 抽序总量、同题文字匹配、单动作接口完成及净HP端点，都不能替代完整实体/动作/因果认证。',
           '- 本批只复核十锚点和一直接关联补证局；没有重做宽提案原全部历史或声称十五机制已完整校准。',
           '- 不关闭Roy学习父要求，不冒称经验已入库、大脑已采用或线上效果已改善。', '']
(OUT / 'report.md').write_text('\n'.join(report) + '\n')
updates = []
for ident in sorted(ledger):
    linked = [row for row in reviews if ident in row['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': f'{BATCH}：仅补本批追溯，不新增证据或改历史状态；' +
                            '；'.join(row['id'] + '=waiting：' + row['reason'] for row in linked)})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'proposals': len(reviews), 'ledger_updates': len(updates), 'base': BASE,
                  'fixes': [], 'merged': None, 'report': str(OUT / 'report.md')}, ensure_ascii=False))

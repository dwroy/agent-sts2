# strategy-proposal 本批回报

基线：`e8e9c5753240fcd9ce203bcf1529c6dd8a9c7dc0`；复核时实际live：`b155d00a36080418149e63d2f21b491d34d7f40a`。
十项全部waiting，fixes=[]、merged=null、implementation_domains=[]。没有新增源码、知识、经验、任务模板或行为版本，没有提交或合入live；HEAD保持上述40位基线，工作树最终应保持干净。
实际执行的是当前普通提案任务，不是纯研究或量化实现请求；不关闭任何原科学父要求。

## 身份、原件和范围

dispatch-identity.json保留本批唯一调度行；已核task/character/worktree及10个proposal_ids，未绑定research_request/implementation_request。专题根请求属于另一批，不套用。
10份原始提案SHA全部匹配；selected-proposals.json、selected-ledger-before.json、run-identities.json保存本批输入。账本只使用所领提案关联ID；不拿其他角色知识。
本批runs只填十个派发锚点；另按原提案43fe/3f5的直接关联补核ZTRGYYMLR8SC，补证不改派发身份。原机制宽提案另有11个同角色历史ID只核runs角色元数据，未重做全史，不计新支持样本。
当前模型/强度未通过本任务工具独立核验原生会话请求，不因文档或默认配置填写“已切换”。无模型调用、联网、对局/模拟或子agent。

| 本次抽取局号 | 进阶 | 终层 | 原始victory |
|---|---:|---:|---|
| 2PVLGRBGUX9S | A7 | 48 | False |
| DPYF2BAA3DKT | A10 | 48 | False |
| GXNKW8X1XYJP | A10 | 45 | False |
| UMVLWER4CD98 | A10 | 48 | False |
| VLZ6CCT8AQ0A | A10 | 45 | False |
| VN7RQJMJEFMX | A6 | 42 | False |
| YF0LXT1QSTGG | A10 | 48 | False |
| ZE8F192FKX24 | A5 | 48 | True |
| PD9AYQVMLQW6 | A10 | 49 | False |
| L2TSFU62Z57Z | A10 | 17 | False |
| ZTRGYYMLR8SC | A10 | 17 | False |

## 日志截点与核验

使用共用learner/extract_evidence.py，一次提取十锚点加直接关联补证局的八个流；全部以显式run_id/state.run_id/run/fingerprint.run归局，冲突身份拒收。
evidence/evidence-manifest.json记录每流source_size、每局计数、输出SHA；逐条证据保存原行号、offset、bytes、SHA和原JSON。audit_evidence.py实际从只读logs按偏移读回所有记录并核字节SHA/JSON/身份/截点/输出SHA。

| 流 | source_size（字节） | 选中行数 | 全源前缀坏行 |
|---|---:|---:|---:|
| states | 14285619784 | 9626 | 2 |
| decisions | 2497501331 | 9264 | 2 |
| sl-attempts | 47706736 | 77 | 0 |
| run-config | 2074501 | 11 | 0 |
| run-plans | 9272480 | 73 | 0 |
| brain | 806135548 | 461 | 2 |
| runs | 371605 | 11 | 0 |
| fight-plans | 2233957 | 0 | 0 |

共19523条逐行核回；各流截点分别在打开源时冻结，不冒称原子跨流快照。states/decisions/brain各2坏行只代表全源前缀异常，不能归到本批。全部incomplete=0。fight-plans本截点0行只说明此截点未选到，不能断言历史日志缺失。

## 固定证据及消费者读回

四局A10原样输入现有离线selection-execution消费者，保留原始行号和SHA，不调LLM、游戏或知识库。四份输出均gzip无损保存，解压后SHA与读回摘要一致。六条map/route-change原始元数据无decision_id，独立登记excluded-metadata.json；没有伪造ID或把过滤数组重编号。

| 局号 | 候选片段 | 动作 | 唯一文字匹配 | 歧义匹配 | 完整候选认证 |
|---|---:|---:|---:|---:|---:|
| GXNKW8X1XYJP | 116 | 646 | 116 | 0 | 0 |
| PD9AYQVMLQW6 | 149 | 1015 | 142 | 7 | 0 |
| L2TSFU62Z57Z | 93 | 441 | 93 | 0 | 0 |
| ZTRGYYMLR8SC | 130 | 594 | 121 | 9 | 0 |

合计488片段、2696动作；所有actual_full_candidate_result和actual_rollout_best均null。这里只核到原消费者能保留的关联与限制，不能写成源码测试、完整候选执行、生产自然采用或胜率校准。
159个关键状态压缩视图见focused-frames.json，25条关键决策原行见key-decisions.json；完整原件仍在evidence目录，可由offset/bytes/SHA重取。

关键结论：PD9 F49末T10的3HP与32挡，对24持牌伤+23攻击仍需损15；修正单弃不能证明翻盘。L2 T6即时7伤与结束的短程死亡14/24及11/24不同，三条整场候选均0/1200且侧步未建模，不据此改排序。ZTR同族324总HP与末58HP可见，但删员后序号重排，不能补造稳定敌实例或精确击杀帧。GX F44胜后实5HP与F45净变化，不能反推复活逐击完整入伤。

## 当前源码与已有局部实现

source-manifest.json固定17份相关源码叶的base、blob、SHA、原字节副本和live祖先关系；不是整仓快照或历史dirty运行树复原。两份base/live差异（card-model、sl/draws）仅注释署名变化，原始两侧与binary diff均保留。其余选定叶相同；不据此声称全部live/基线等价。

- 普通生存者单弃：bf423c173d3be348a4ad714e1d26516df619ff41，实际live祖先；余项仍缺联合校准。
- 同族当前血量/暂减力：d1713559f2d237a04b681ec6497ce0c8798ae0f0，实际live祖先；不提供稳定实体或精确击杀时间。
- 连续Boss原始阶段/同样本资源诊断：bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07，实际live祖先；actualSecondOpening和calibration仍unknown。
- 候选/护栏/SL资源预测：66283dd9982bdd7f480da7a4d9bfefea0572a9ac及9d8278702dbc581b5015ba7ec9a70dc0fb94cccb均为实际live祖先，当前源码保持actual_outcome/null和execution/unverified边界。

所有原局runs.code均带dirty，未获得原局完整dirty源码；当前源码只用于现状核对，不替换原运行身份。

## 逐项处置

| 原提案ID | 账本 | 处置 | 具体原因 |
|---|---|---|---|
| silent-proposal-2631859b524e0652 | silent-0280 | waiting | 缺纯改标与同ID多副本、真插牌/洗牌同帧的消歧负例及 known-draw 消费者完整验证；本次四个旧事件不提供完整抽序，保留原行为。 |
| silent-proposal-b13fda1dfeb37927 | silent-0019, silent-0020, silent-0079, silent-0243 | waiting | 缺复活瞬时逐击入伤、前三试退出帧、逐药槽变化来源及替路线/提前用药的完整后继；端点净HP不能补成未截断完整血价。 |
| silent-proposal-d7b8d36cf3d0303d | silent-0268 | waiting | 普通单弃已有实现；新增凋萎实体、弃牌完成时点、余像与终局消费者的联合校准余项未完成，不能把局部实现登记为整项duplicate。 |
| silent-proposal-c873d6543c414f92 | silent-0125, silent-0005, silent-0044, silent-0253 | waiting | 缺跨抽牌/弃牌重问的完整父子候选归属和饮药、自动消耗、SL恢复的完整来源认证；现有预测阶段记录不等于实线完成。 |
| silent-proposal-dfbf51502f30c9b1 | silent-0021, silent-0133, silent-0222, silent-0049, silent-0020 | waiting | 缺侧步完整可验证后继与同预算、同随机/抽序的候选整战对照；即时7伤不支持改变全败排序或SL边界。 |
| silent-proposal-c2888032d1337388 | silent-0005, silent-0006, silent-0011, silent-0016, silent-0023, silent-0024, silent-0027, silent-0049, silent-0083, silent-0094, silent-0133, silent-0222, silent-0253, silent-0276, silent-0282 | waiting | 缺十五机制逐入口至联合生产消费者的完整校准；覆甲减层、力量对滚石、换战能力边界未隔离，本批不补未观察组合或参数。 |
| silent-proposal-042ee2299084b528 | silent-0019, silent-0020, silent-0021, silent-0090, silent-0228, silent-0239, silent-0243 | waiting | 同样本资源诊断已有实现；奖励转移、真实次战开场及路线/休息消费者联合校准仍缺，不能把原始模拟率或框架视为已量化学习。 |
| silent-proposal-8cd3db3bad5f34f1 | silent-0021, silent-0133, silent-0222, silent-0228, silent-0239 | waiting | 缺原线/改线完整执行认证及同入口、同预算整战后继；观察端点不能补成原候选因果结果，不能据有限全败修改必死/SL。 |
| silent-proposal-43fe170707574455 | silent-0021, silent-0012, silent-0046 | waiting | 当前总血与暂减力快照已有实现；缺稳定敌实例、精确退场边界，以及构筑能力实际取得/建立至输出兑现的完整链。 |
| silent-proposal-3f5a665dca133a8c | silent-0125 | waiting | 缺跨重问完整归属与原线/替线同预算整战后继；局部端点能核不代表完整省血或输出收益，现有8/24/0参数不变。 |

每项证据局/层/回合、反例、旧行为、预期行为、切分、验证与回退完整列在proposal.md及proposal-review.json；没有忽略任何派发ID。waiting由原队列等待新增本角色证据后接续，不能用上述局部实现冒记整项implemented/duplicate/shipped。

## 记录、测试与交付

只通过根learner/ledger.py update补本批proposal/report追溯和逐项waiting说明；仅where/note，不写status/evidence/version/effect/claim，不新增支持或重复样本。旧条目既有shipped等状态属于历史，不倒退成proposed；本批无新知识提案。CLI输入、退出码、回执及追加行证明单独保存。

实际CLI update退出0，共29条；逐行内容、offset/bytes/SHA与输入相同，原24,398,505字节前缀SHA不变，所有关联条目的claim/first_run/prior/evidence/status/version/effect等保护字段与批初一致。根账本check退出0：516条、0问题。final-verification.json核HEAD仍为基线、tracked status为空、源码/知识/任务diff为空。
没有源码改动，故撤源码失败/恢复通过不适用；tsc、vitest、cases均为null，没有运行生产自测或借用旧绿。没有提交，故无源码提交号/合入号/版本及上线通知。
source输入空diff保存在unchanged-inputs.patch；最终工作树/HEAD及材料哈希核验见final-verification.json和artifact-manifest.json。凭据扫描结果见gitleaks.log；扫描结果以实际退出码记录。

本批材料gitleaks dir（redact，含一层压缩材料）实际退出0，扫描约630.24MB，no leaks found；只扫描本批scratch，没有读取key文件或.env。撤源码/恢复及tsc/vitest均未执行、不填成功。
交付提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-101301/learner/runs/20261018-101305-3e8db480-8073-4080-b315-78d376339087-strategy-proposal/proposal.md
回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-101301/learner/runs/20261018-101305-3e8db480-8073-4080-b315-78d376339087-strategy-proposal/report.md
最终机器回报保存在result.json；这里的evidence及离线读回属于证据验证，不填成测试通过或实际采用。

## 限制

- 没有新独立对局、受控替路线/药水时点/目标或同预算完整后继，不拟合新阈值。
- 六次SL属于一局相关尝试，重读原日志不增加支持局数；模拟样本数不是实盘局数。
- 抽序总量、同题文字匹配、单动作接口完成及净HP端点，都不能替代完整实体/动作/因果认证。
- 本批只复核十锚点和一直接关联补证局；没有重做宽提案原全部历史或声称十五机制已完整校准。
- 不关闭Roy学习父要求，不冒称经验已入库、大脑已采用或线上效果已改善。


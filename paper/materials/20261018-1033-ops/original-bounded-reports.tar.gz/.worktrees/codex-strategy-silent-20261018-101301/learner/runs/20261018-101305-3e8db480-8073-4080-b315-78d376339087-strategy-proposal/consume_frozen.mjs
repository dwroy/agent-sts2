// Reuse the pinned offline consumer; no game, network, knowledge files, or LLM calls.
import { readFileSync, writeFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const out = dirname(fileURLToPath(import.meta.url));
const { auditSelectionExecution } = await import(pathToFileURL(resolve('learner/lib/selection-execution.ts')));
const summaries = [];
for (const run of ['GXNKW8X1XYJP', 'PD9AYQVMLQW6', 'L2TSFU62Z57Z', 'ZTRGYYMLR8SC']) {
  const input = readFileSync(resolve(out, `${run}.audit-input.json`));
  const audit = auditSelectionExecution(JSON.parse(input));
  const raw = JSON.stringify(audit, null, 2) + '\n';
  writeFileSync(resolve(out, `${run}.audit-output.json.gz`), gzipSync(raw));
  const segments = audit.segments ?? [];
  const actions = audit.observed_actions ?? [];
  summaries.push({ run_id: run, input_sha256: createHash('sha256').update(input).digest('hex'),
    output_uncompressed_sha256: createHash('sha256').update(raw).digest('hex'),
    top_level_keys: Object.keys(audit), segments: segments.length, observed_actions: actions.length,
    certified_full_candidate_results: segments.filter(row => row.actual_full_candidate_result != null).length,
    actual_rollout_best_values: segments.filter(row => row.actual_rollout_best != null).length,
    final_match_counts: Object.fromEntries([...new Set(segments.map(row => row.predictions.final_match))]
      .map(key => [key, segments.filter(row => row.predictions.final_match === key).length])),
    limitation: '离线读回仅核追溯；完整候选结果与因果收益仍未知，非生产测试或自然采用。' });
}
writeFileSync(resolve(out, 'consumer-summary.json'), JSON.stringify(summaries, null, 2) + '\n');
process.stdout.write(JSON.stringify(summaries, null, 2) + '\n');

"""Read frozen evidence only; keep original identities and byte provenance."""
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', Path.cwd() / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
identities = json.loads((OUT / 'run-identities.json').read_text())
selected = ['GXNKW8X1XYJP', 'PD9AYQVMLQW6', 'L2TSFU62Z57Z', 'ZTRGYYMLR8SC']
inputs = {run: {'run': identities[run], 'states': [], 'decisions': []} for run in selected}
focused, excluded, checks, sl_rows, plans = [], [], [], [], []

def compact(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    return {
        'source': {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')},
        'observed_ts': row.get('observed_ts'), 'floor': run.get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')),
        'max_hp': player.get('max_hp', run.get('max_hp')), 'block': player.get('block'),
        'energy': player.get('energy'), 'powers': player.get('powers'),
        'potions': run.get('potions'),
        'hand': [{k: card.get(k) for k in ('index', 'card_id', 'name', 'upgraded', 'resolved_rules_text', 'dynamic_values')}
                 for card in combat.get('hand', [])],
        'enemies': [{k: enemy.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'is_alive', 'powers', 'intents')}
                    for enemy in combat.get('enemies', [])],
    }

for entry in manifest:
    stream = entry['stream']
    target = OUT / 'evidence' / (stream + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = dict.fromkeys(entry['counts'], 0)
    prior_offset = -1
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source, target.open('rb') as handle:
        for encoded in handle:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['offset'] > prior_offset
            prior_offset = item['offset']
            assert item['offset'] + item['bytes'] <= entry['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            run = extract.run_identity(item['row'])
            assert run == item['run_id'] and run in counts
            counts[run] += 1
            row = item['row']
            if stream == 'states':
                state = row['state']
                info = state.get('run') or {}
                assert str(info.get('character_id')).lower() == 'silent'
                assert info.get('ascension') == identities[run]['ascension']
                floor, turn = info.get('floor'), state.get('turn')
                if (run == 'PD9AYQVMLQW6' and item['line'] in range(291336, 291343) or
                    run == 'GXNKW8X1XYJP' and floor in (44, 45) and turn in (None, 1, 2, 3) or
                    run == 'L2TSFU62Z57Z' and item['line'] in (291420, 291421, 291422, 291423, 291790, 291791, 291792) or
                    run == 'ZTRGYYMLR8SC' and item['line'] in (292332, 292363, 292369, 292384, 292395, 292402) or
                    run == 'YF0LXT1QSTGG' and floor == 48 and turn == 5):
                    focused.append(compact(item))
                if run in inputs:
                    inputs[run]['states'].append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
            elif stream == 'decisions' and run in inputs:
                if not row.get('decision_id'):
                    excluded.append({**{k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')},
                                     'reason': '原始元数据行无 decision_id，不是可认证的动作记录；原件保留。',
                                     'label': row.get('label'), 'type': row.get('type')})
                else:
                    inputs[run]['decisions'].append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
            elif stream == 'sl-attempts':
                sl_rows.append(item)
            elif stream == 'run-plans':
                plans.append(item)
    assert digest.hexdigest() == entry['output_sha256']
    assert counts == entry['counts']
    checks.append({'stream': stream, 'source_size': entry['source_size'], 'rows': sum(counts.values()),
                   'counts': counts, 'output_sha256': digest.hexdigest(), 'verified': True,
                   'invalid_lines_in_whole_source_prefix': entry['invalid_lines'],
                   'incomplete_lines_in_whole_source_prefix': entry['incomplete_lines']})

for run, data in inputs.items():
    assert data['run']['ascension'] == 10
    (OUT / (run + '.audit-input.json')).write_text(json.dumps(data, ensure_ascii=False) + '\n')
for filename, data in [('evidence-verification.json', checks), ('focused-frames.json', focused),
                       ('excluded-metadata.json', excluded), ('sl-selected.json', sl_rows), ('plans-selected.json', plans)]:
    (OUT / filename).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['rows'] for x in checks), 'streams': checks,
                  'focused_frames': len(focused), 'excluded_metadata': excluded,
                  'audit_inputs': {run: {key: len(value[key]) for key in ('states', 'decisions')} for run, value in inputs.items()}},
                 ensure_ascii=False))

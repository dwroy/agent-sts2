"""Verify frozen envelopes and produce small, referenced observations without simulating play."""
import bisect
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT / 'evidence'


def ref(item):
    return {k: item[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']}


def powers(raw):
    return {p['power_id']: p.get('amount') for p in raw.get('powers', [])}


def snapshot(item):
    r = item['row']; s = r['state']; run = s.get('run', {}); c = s.get('combat') or {}
    p = c.get('player') or {}
    return {
        'ref': ref(item), 'ts': r.get('observed_ts', r['ts']), 'screen': s['screen'],
        'floor': run.get('floor'), 'turn': s.get('turn'), 'hp': run.get('current_hp'),
        'max_hp': run.get('max_hp'), 'block': p.get('block'), 'energy': p.get('energy'),
        'powers': powers(p), 'hand': [v.get('card_id') for v in c.get('hand', [])],
        'hand_upgraded': [v.get('upgraded') for v in c.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'), 'powers': powers(e),
                     'move': e.get('move_id'), 'intents': e.get('intents')} for e in c.get('enemies', [])],
        'potions': [{'slot': i, 'id': v.get('potion_id'), 'occupied': v.get('occupied')}
                    for i, v in enumerate(run.get('potions', []))],
        'relics': [v.get('relic_id') for v in run.get('relics', [])],
        'ready': (c.get('action_readiness') or {}).get('can_use_combat_actions'),
        'fingerprint': r.get('fingerprint'),
    }


manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
verified = []
states = defaultdict(list)
decisions = defaultdict(list)
for stream in manifest:
    name = stream['stream']; file = EVIDENCE / f'{name}.evidence.jsonl'
    digest = hashlib.sha256(); counts = Counter()
    with file.open('rb') as handle, Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for raw in handle:
            digest.update(raw); item = json.loads(raw); run = item['run_id']; counts[run] += 1
            source.seek(item['offset']); original = source.read(item['bytes'])
            assert hashlib.sha256(original).hexdigest() == item['sha256'], (name, item['line'])
            assert json.loads(original) == item['row'], (name, item['line'])
            if name == 'states':
                assert item['row']['state']['run']['character_id'].lower() == 'silent'
                states[run].append(snapshot(item))
            elif name == 'decisions':
                decisions[run].append(item)
    assert digest.hexdigest() == stream['output_sha256'], name
    assert all(counts[k] == v for k, v in stream['counts'].items()), name
    verified.append({'stream': name, 'source_size': stream['source_size'], 'rows': sum(counts.values()),
                     'output_sha256': digest.hexdigest(), 'all_raw_offsets_sha_json_verified': True})

links = []
windows = []
for run, frames in states.items():
    frames.sort(key=lambda v: (v['ts'], v['ref']['line']))
    stamps = [v['ts'] for v in frames]
    for d in decisions[run]:
        r = d['row']; chosen = r.get('chosen') or {}
        if chosen.get('action') not in ['use_potion', 'discard_potion'] and not r.get('sl_explore'):
            continue
        ts = r.get('observed_ts', r['ts']); i = bisect.bisect_right(stamps, ts) - 1
        before = frames[max(0, i)]; after = frames[min(len(frames) - 1, i + 1)]
        links.append({'decision': ref(d), 'floor': r.get('floor'), 'turn': r.get('turn'),
                      'attempt': r.get('sl_attempt'), 'action': chosen, 'result': r.get('result'),
                      'sl_explore': r.get('sl_explore'), 'before': before, 'next_observed': after,
                      'limitation': '时间邻接仅供核帧；pending/重规划/下一帧不认证完整候选执行。'})
    attempt = defaultdict(lambda: 1); previous_turn = {}; groups = []
    for frame in frames:
        if frame['screen'] != 'COMBAT' or not frame['turn'] or frame['ready'] is False:
            continue
        f = frame['floor']; t = frame['turn']
        if f in previous_turn and t < previous_turn[f]:
            attempt[f] += 1
        previous_turn[f] = t
        key = (f, attempt[f], t)
        if not groups or groups[-1]['key'] != key:
            groups.append({'key': key, 'first': frame, 'last': frame, 'count': 1})
        else:
            groups[-1]['last'] = frame; groups[-1]['count'] += 1
    for i, group in enumerate(groups):
        f, a, t = group['key']; next_group = groups[i + 1] if i + 1 < len(groups) else None
        nxt = next_group['first'] if next_group and next_group['key'][:2] == (f, a) else None
        windows.append({'run': run, 'floor': f, 'observed_attempt': a, 'turn': t,
                        'first': group['first'], 'last': group['last'], 'next_turn': nxt,
                        'frames': group['count'],
                        'limitation': '尝试按同房turn回退分段；端点含所有可见效果，不当单牌归因或受控整战。'})

(OUT / 'envelope-verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'turn-windows.jsonl').open('w') as handle:
    for item in windows: handle.write(json.dumps(item, ensure_ascii=False) + '\n')
with (OUT / 'action-links.jsonl').open('w') as handle:
    for item in links: handle.write(json.dumps(item, ensure_ascii=False) + '\n')
print(json.dumps({'streams': verified, 'turn_windows': len(windows), 'action_links': len(links)}, ensure_ascii=False))

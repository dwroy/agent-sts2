"""Write this batch's report and prepare provenance-only ledger updates."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WT = OUT.parents[2]
dispatch = json.loads((OUT / 'dispatch.json').read_text())
items = json.loads((OUT / 'proposal-dispositions.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
streams = json.loads((OUT / 'envelope-verification.json').read_text())
checks = json.loads((OUT / 'observation-checks.json').read_text())
identities = json.loads((OUT / 'runs-identity.json').read_text())
stamp = (OUT / 'recorded-at.txt').read_text().strip()
assert all(v['pass'] for v in checks)
assert len(items) == 10 and {v['id'] for v in items} == set(dispatch['proposal_ids'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WT).decode().strip() == source['base']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WT)

leaf_diffs = []
for leaf in source['leaves']:
    if leaf['same_bytes_as_live']:
        continue
    a = (WT / leaf['path']).read_bytes()
    b = subprocess.check_output(['git','show',source['live_snapshot']+':'+leaf['path']],cwd=WT)
    assert re.sub(rb'\bRoy\b', b'Dai', a) == b, leaf['path']
    leaf_diffs.append({'path':leaf['path'],'difference':'历史注释署名Roy/Dai，规范化该名字后逐字一致'})
(OUT / 'source-leaf-differences.json').write_text(json.dumps(leaf_diffs,ensure_ascii=False,indent=2)+'\n')
diff = subprocess.check_output(['git','diff',source['base'],source['live_snapshot'],'--',
                                 *[v['path'] for v in source['leaves']]],cwd=WT)
(OUT / 'base-live-inspected-leaves.patch').write_bytes(diff)

header = f'''# 本批静默策略提案逐项复核

记录时间：{stamp}。批次：20261017-104302-strategy-proposal。独立完成，无下级agent。

本批10项均为 **waiting**。没有新源码、知识或行为规则改动，没有提交、live合入、行为版本或shipped登记。原提案的若干子公式和诊断已存在于live；其证据不能关闭含完整执行、整战后继或联合校准的宽提案。

## 身份与基线

- 开工tracked/index干净，初始HEAD为`e4582a3e4251ce5b79afae05a9a91d122e7ed915`。
- 只读取根learn.json本批行：task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配；有10个proposal_ids，没有research_request、implementation_request或proposal_repair。
- 普通专题请求只核身份：`roy-20261010-silent-deck-size-value`仍绑定另一批`20261010-150327-strategy-proposal`，本批不承接、不读取其work_spec或改根请求。
- 按普通任务`git merge --no-edit main`快进后，本批base/HEAD为完整40位`{source['base']}`；后续不改HEAD。无冲突，`baseline.patch`为空。
- 十份原Markdown逐字SHA全部符合队列保存值，原字节副本、来源路径与SHA见`proposal-input-manifest.json`；只处理这十项，不领取队列其他id、不重写旧复盘。

## 证据范围与方法

本批runs仅为10个派发锚点；另核原提案明确引用的SADL3CGYTGSR、1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、Y6GM2CHWJBEY，共16个独立静默局。Y6为A0、K367为A1、SADL为A7、F4Q为A9，其余12局A10。SL和同战多窗口不增加独立局数；没有借用其他角色知识。

使用本树`learner/extract_evidence.py`统一入口，显式选择八流。每流先冻结source_size；每个选中封套包含原source、line、offset、bytes、SHA256及唯一显式局身份。随后对每一封套seek原只读日志、核原字节SHA和JSON，核输出SHA/计数；所有state角色均为SILENT。共{sum(v['rows'] for v in streams)}个封套，原始截点/逐局计数在`evidence/evidence-manifest.json`，复核在`envelope-verification.json`。

| 流 | source_size字节 | 选中行 |
|---|---:|---:|
'''
for v in streams:
    header += f"| {v['stream']} | {v['source_size']} | {v['rows']} |\n"
header += '''
fight-plans本截点选中0行只表示统一身份入口未选到本范围，不断言源日志缺失。states/decisions/brain各2行无法解析，由入口计数保留；未将坏行补造或选入。没有以正文提及局号作为归属。未复核旧截点，也未覆盖原批次报告。

生成1648个按同房turn回退分段的观察轮窗、471个药水/SL动作邻接记录。时间邻接、queued/completed回执和单步状态均不认证完整候选执行；状态端点含卡牌、毒、自动伤害等全部可见效果，不把跨轮净扣全部归给单牌。NHA初题精确切击被弃后重规划，已明确与后续完整实际轮分开。

`observation-checks.json`的30项是冻结原帧算术/身份检查，修正稿全部通过；不是tsc、vitest或生产消费者验证。例：WQ同指纹13损24伤对22损39伤；反例T7同伤而付4血换沙坑一回合；NHA14挡/损1/净扣8对8挡/损7/净扣24；TXZ少损3同时少伤9、首胜4血再开场归零；九局42次狡诈手位分布37/2/3；Q6紧勒实际23、速度临时敏捷及精英胜后2血链；1913弃磨蚀前后能量均3与重接0→25。

31个既有账本与26个相关本角色经验条目仅做来源/边界核对（`ledger-scoped-evidence.json`、`experience-scoped-snapshot.json`）。没有重算旧105/109局全历史统计，没有将原文提及但未展开的其他历史局、旧support总数或其他进阶当本批验证集；silent-0198的旧组合净2仅保留原证据限制，本批不新核其单件结算顺序。

## 当前源码与live范围

只读核17个相关源码叶子；live冻结点与9个窄功能祖先详见`source-audit.json`。13叶逐字相同，4叶只有历史注释Roy/Dai署名差（`source-leaf-differences.json`与补丁）；没有将17叶等价推成整个运行树等价。历史对局code含dirty，不能由现源码重建当时所有执行字节。

'''
header += f"实际live冻结点：`{source['live_snapshot']}`。以下只证明窄功能源码已在其祖先，不作为本批实现或整项duplicate：\n\n"
for v in source['narrow_source_ancestry']:
    header += f"- {v['scope']}：`{v['commit']}`，live祖先核验exit 0。\n"
header += '''
已读调用点：combat-plan接SL资源/候选对比；selection-dispatch只认证单动作回执且whole_plan_executed=null；狡诈按角色/进阶生成再受每步手位限制；普通紧勒限制已观察模板并对未知组合记unknown；boss-sim按样本传递HP/余药/复活，boss-start只在已观察遗物组合扣开场HP；低可信连续模拟明确不作必死/SL判据。以上是源码核查，没有新运行生产消费者、模拟池、LLM、网络或play，也不借历史测试成功冒充本批测试。

## 十项处置、反例与后续验证

'''
for n, item in enumerate(items,1):
    header += f"### {n}. {item['id']} — {item['title']}\n\n"
    header += f"- 状态：waiting。既有账本：{', '.join(item['ledger'])}。\n"
    header += f"- 证据局/层/回合：{item['evidence']}。\n"
    header += f"- 本批核验：{item['finding']}\n"
    header += f"- 未实现原因：{item['reason']}\n"
    header += f"- 预期行为及验证：{item['expected_behavior_and_validation']}\n"
    header += f"- 已有窄源码范围：{', '.join(item['narrow_source_scopes'])}（完整commit见上，非整项完成）。\n\n"
header += '''## 拟合、限制和回退

不新增参数或固定交换率。本批旧局是发现/核帧资料；后续若改排序、持药价或终局曲线，先隔离确定机制误差，按独立run与开始时间划分更早训练、后移验证，SL同局同组，同入口/预算/后继条件列明；不把rollout样本或六次失败当独立实盘。未见完整受控替线胜果时保留现生产规则，不能写成换线/留药本可赢。

油灯现场relic.stack为null，单凭持有无法判断首次消费；需要跨动作、重问、新战与SL恢复的状态传递验证。弃磨蚀的弃牌实帧不等于卡牌直接施放分支被证明；朝向受限取整不等于通用取整次序；未知X/升级/自动触发仍未知。未来营火、未取得或未触发能力、SL恢复与实际回血分开。没有新增与旧经验冲突的机制结论，本批不重复旧科学通知，不关闭任何量化/完整候选/学习入库父要求。

若未来证据支持改动，按原任务每项单独源码提交、固定原帧/消费者验证、撤源失败/恢复通过、原沙箱检查及live锁流程上线；实际发布后再做唯一版本、双通知和运维shipped确认。当前没有新源码可回退；原日志、原提案和失败/初稿均保留，无其他角色行为变更。

## 验证、初稿与交付

- 开工大小写检查初稿把runs.jsonl的SILENT与小写silent直接比较而AssertionError；修正为规范化比较后16局全过，`identity-check.initial.txt`保留。
- 一次只读命令在执行前被bubblewrap包装器因另一批消失临时路径拒绝，原命令重试成功；`sandbox-preflight-failure.txt`保留，未放宽沙箱权限。
- 原材料检查稿30项返回0，但其中“弃磨蚀3能量”的名称错配为后续施毒2能量帧。已保留`validate-observations.initial.py.txt`、`observation-checks.initial.json`、`observation-validation.initial.log`；修正为原始282767→282768的3→3能量/1敏/4荆棘，修正后30项0见`observation-validation.corrected.log`。初稿0不充当修正前已核该时点。
- 报告生成的源码差异守卫初稿以子串替换Roy，误改Royal而拒绝boss-start叶子；未写报告/账本。改为独立单词后核通过，`write-report.initial.py.txt`及`source-comparison.initial-failure.txt`保留；不是产品源码失败。
- 无生产源码改动：撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行沙箱生产套件，不制造测试成功。没有提交，提交前gitleaks/Co-Authored-By及live合入步骤不触发。
- 专用code_proposals没有新建重复id或修改旧提案；最终code_proposals仅为这10个原CLI id。implementation_domains=[]表示本批没有实际实现。
- 仅经根ledger.py update为31个既有账本追加本报告/提案去处及复核说明；不追加support/repeat，不改claim/first_run/prior/status/version/effect/shipped。原已shipped经验不退回proposed；提案仍waiting，等待新证据重派。
- report与proposal位于本批scratch；过程材料保持，结束后由原调度器按门禁处理回收，当前不删自身工作树或旧日志。
'''
(OUT / 'report.md').write_text(header)
(OUT / 'proposal.md').write_text('# 本批既有策略提案处置与证据\n\n'+
    '本文件记录10个原提案的独立复核，不新建重复id。各项均waiting，无新源码、合入或版本。\n\n'+
    header[header.index('## 十项处置、反例与后续验证'):header.index('## 验证、初稿与交付')]+
    '\n原始帧SHA/offset、源码祖先及本批初稿/限制见同目录report.md与JSON材料。\n')
ledger_ids = sorted({i for v in items for i in v['ledger']})
updates = [{'id':i,'by':'learner:strategy-proposal',
            'where':{'proposal':[str(OUT/'proposal.md')],'changelog':[str(OUT/'report.md')]},
            'note':'20261017-104302-strategy-proposal：仅复核本批原提案已有静默证据和live窄源码祖先；十项waiting，详本批报告。此次是来源/处置链接，不新增独立局、support/repeat、阈值或实现/上线声明；保留原claim、首证、prior、status及version。'} for i in ledger_ids]
(OUT / 'ledger-updates.json').write_text(json.dumps(updates,ensure_ascii=False,indent=2)+'\n')
final = {'task':'strategy-proposal','character':'silent','batch':'20261017-104302-strategy-proposal',
         'base':source['base'],'runs':dispatch['runs'],'fixes':[],
         'skipped':[v['id'] for v in items],
         'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},
         'code_proposals':dispatch['proposal_ids'],'implementation_domains':[],
         'proposal_results':[{'id':v['id'],'state':'waiting','reason':v['reason']} for v in items],
         'report':str(OUT/'report.md')}
(OUT / 'result.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(OUT/'report.md'),'proposal':str(OUT/'proposal.md'),
                  'waiting':len(items),'ledger_updates_prepared':len(updates)},ensure_ascii=False))

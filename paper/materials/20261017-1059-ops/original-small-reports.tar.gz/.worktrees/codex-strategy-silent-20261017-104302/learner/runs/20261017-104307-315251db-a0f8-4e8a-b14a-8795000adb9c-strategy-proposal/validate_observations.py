"""Check observed arithmetic against frozen raw frames, not against production implementations."""
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
links = [json.loads(line) for line in (OUT / 'action-links.jsonl').open()]
windows = [json.loads(line) for line in (OUT / 'turn-windows.jsonl').open()]
checks = []


def check(name, actual, expected, references):
    record = {'name': name, 'actual': actual, 'expected': expected, 'pass': actual == expected,
              'references': references}
    checks.append(record)
    (OUT / 'observation-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    assert record['pass'], name


def w(run, floor, attempt, turn):
    return next(v for v in windows if (v['run'], v['floor'], v['observed_attempt'], v['turn']) ==
                (run, floor, attempt, turn))


def refs(*frames):
    return [f['ref'] for f in frames if f is not None]


def enemy_hp(frame):
    return sum(e['hp'] for e in frame['enemies'])


def result(window):
    before = window['first']; after = window['next_turn']
    return [before['hp'] - after['hp'], enemy_hp(before) - enemy_hp(after)]


ken = [v for v in links if v['decision']['run_id'] == 'KEN58SH9SLZ6']
drinks = [v for v in ken if v['action']['action'] == 'use_potion']
check('KEN七次实饮与零弃药', [len(drinks), sum(v['action']['action'] == 'discard_potion' for v in ken)],
      [7, 0], [v['decision'] for v in drinks])
check('KEN饮用的层回合', [[v['floor'], v['turn']] for v in drinks],
      [[3, 2], [4, 1], [5, 2], [11, 1], [11, 2], [15, 1], [15, 1]], [v['decision'] for v in drinks])

txz = [w('TXZ6RVMQA09D', 48, a, 6) for a in [2, 3]]
check('TXZ两尝试T6起点HP敌血及手牌一致',
      [txz[0]['first']['hp'], enemy_hp(txz[0]['first']),
       txz[0]['first']['hand'] == txz[1]['first']['hand'],
       txz[0]['first']['fingerprint'] == txz[1]['first']['fingerprint']],
      [48, 460, True, True], refs(*(v['first'] for v in txz)))
check('TXZ少损3同时少伤9', [result(v) for v in txz], [[3, 36], [0, 27]],
      refs(*(v[k] for v in txz for k in ['first', 'next_turn'])))

worm = [w('WQZVENQ7DTRP', 33, a, 9) for a in [2, 3]]
check('WQ两尝试T9相同指纹', worm[0]['first']['fingerprint'] == worm[1]['first']['fingerprint'],
      True, refs(*(v['first'] for v in worm)))
check('WQ同盘多15伤付9血', [result(v) for v in worm], [[13, 24], [22, 39]],
      refs(*(v[k] for v in worm for k in ['first', 'next_turn'])))
escape = [w('WQZVENQ7DTRP', 33, a, 7) for a in [2, 6]]
check('WQ逃离反例同伤付4血', [result(v) for v in escape], [[0, 24], [4, 24]],
      refs(*(v[k] for v in escape for k in ['first', 'next_turn'])))
check('WQ逃离后行动末沙坑4与5', [v['last']['enemies'][0]['powers']['SANDPIT_POWER'] for v in escape],
      [4, 5], refs(*(v['last'] for v in escape)))

cunning = []
for v in links:
    slot = v['action'].get('option_index')
    potion = next((p['id'] for p in v['before']['potions'] if p['slot'] == slot), None)
    if v['action']['action'] == 'use_potion' and potion == 'CUNNING_POTION':
        cunning.append(v)
delta = Counter(len(v['next_observed']['hand']) - len(v['before']['hand']) for v in cunning)
check('9局42饮手位分布', [len(set(v['decision']['run_id'] for v in cunning)), len(cunning), dict(delta)],
      [9, 42, {3: 37, 2: 2, 0: 3}], [v['decision'] for v in cunning])
for attempt, expected in [(5, [2, 0, 0]), (6, [3, 2, 0])]:
    selected = [v for v in cunning if v['decision']['run_id'] == 'WQZVENQ7DTRP' and
                v['attempt'] == attempt and v['turn'] == 11]
    check(f'WQ尝试{attempt}三饮容量', [len(v['next_observed']['hand']) - len(v['before']['hand']) for v in selected],
          expected, [v['decision'] for v in selected])
check('42次狡诈饮用当步HP与能量不变', all(v['before']['hp'] == v['next_observed']['hp'] and
      v['before']['energy'] == v['next_observed']['energy'] for v in cunning), True,
      [v['decision'] for v in cunning])

nha = [w('NHA2KW0RB7VP', 33, a, 1) for a in [1, 5, 6]]
check('NHA同盘原线与替线血价和跨轮推进', [result(v) for v in nha], [[1, 8], [7, 24], [7, 24]],
      refs(*(v[k] for v in nha for k in ['first', 'next_turn'])))
check('NHA原线14挡与替线8挡', [v['last']['block'] for v in nha], [14, 8, 8],
      refs(*(v['last'] for v in nha)))
check('NHA精确切击被弃而非完整执行初题候选', ['PRECISE_CUT' in v['last']['hand'] for v in nha],
      [False, False, False], refs(*(v['last'] for v in nha)))

q6 = w('Q6M2Y34MWKRE', 8, 1, 4)
check('Q6紧勒三牌及毒实际共扣23', result(q6), [1, 23], refs(q6['first'], q6['last'], q6['next_turn']))
check('Q6紧勒随后轮初已清', 'STRANGLE_POWER' in q6['next_turn']['enemies'][0]['powers'],
      False, refs(q6['next_turn']))
q6def = w('Q6M2Y34MWKRE', 2, 1, 3)
check('Q6持续敏捷双防御14挡且零损', [q6def['last']['block'], result(q6def)[0]], [14, 0],
      refs(q6def['first'], q6def['last'], q6def['next_turn']))
q6speed = w('Q6M2Y34MWKRE', 8, 1, 1)
check('Q6速度当轮敏捷5挡10下轮无敏捷',
      [q6speed['last']['powers'].get('DEXTERITY_POWER'), q6speed['last']['block'],
       q6speed['next_turn']['powers'].get('DEXTERITY_POWER', 0)], [5, 10, 0],
      refs(q6speed['first'], q6speed['last'], q6speed['next_turn']))

needed = {280336, 280337, 280382, 280383, 281563, 281564, 281565, 281566,
          282706, 282708, 282720, 282721, 282745, 282755, 282767, 282768, 282771, 282777, 282778, 282783,
          282869, 282870, 282907, 282914, 282921,
          283146, 283147, 283395, 217009, 217010}
raws = {}
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    item = json.loads(line)
    if item['line'] in needed:
        raws[item['line']] = item
assert set(raws) == needed


def s(n):
    return raws[n]['row']['state']


def power(n, id, enemy=None):
    c = s(n)['combat']; obj = c['player'] if enemy is None else c['enemies'][enemy]
    return next((v['amount'] for v in obj['powers'] if v['power_id'] == id), 0)


def raw_refs(*lines):
    return [{k: raws[n][k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']} for n in lines]


check('KEN两次真实营火及增上限', [[s(n)['run']['current_hp'], s(n)['run']['max_hp']] for n in [280336,280337,280382,280383]],
      [[26,76],[53,81],[46,81],[75,86]], raw_refs(280336,280337,280382,280383))
check('TXZ首胜4血接第二战4至0', [[s(n)['screen'], s(n)['run']['current_hp']] for n in [281563,281564,281565,281566]],
      [['REWARD',4],['MAP',4],['COMBAT',4],['GAME_OVER',0]], raw_refs(281563,281564,281565,281566))
check('1913锻造不回血而F28实际回21', [s(n)['run']['current_hp'] for n in [282706,282708,282720,282721]],
      [40,40,40,61], raw_refs(282706,282708,282720,282721))
check('1913赢战后46带至F31', [s(n)['run']['current_hp'] for n in [282745,282755]],
      [46,46], raw_refs(282745,282755))
check('1913弃磨蚀前后能量3建1敏4荆棘',
      [s(282767)['combat']['player']['energy'],s(282768)['combat']['player']['energy'],
       power(282768,'DEXTERITY_POWER'),power(282768,'THORNS_POWER')],
      [3,3,1,4], raw_refs(282767,282768))
check('1913中段死亡重接25不带旧毒力',
      [s(282771)['combat']['enemies'][1]['current_hp'],s(282777)['combat']['enemies'][1]['current_hp'],
       power(282777,'POISON_POWER',1),power(282777,'STRENGTH_POWER',1)], [0,25,0,0], raw_refs(282771,282777))
check('1913毒雾已建但无下一活轮', [power(282778,'NOXIOUS_FUMES_POWER'), s(282783)['run']['current_hp']],
      [3,0], raw_refs(282778,282783))
check('Q6休息57赢精英剩2接走廊死', [s(n)['run']['current_hp'] for n in [282869,282870,282907,282914,282921]],
      [36,57,2,2,0], raw_refs(282869,282870,282907,282914,282921))
check('NHA油灯首次毒药5实建10', [power(283146,'POISON_POWER',0),power(283147,'POISON_POWER',0)],
      [0,10], raw_refs(283146,283147))
check('K367油灯带毒刺击首次实建8', [power(217009,'POISON_POWER',1),power(217010,'POISON_POWER',1)],
      [0,8], raw_refs(217009,217010))
check('油灯原帧没有可读stack计数',
      [r['stack'] for r in s(283146)['run']['relics'] if r['relic_id']=='UNSETTLING_LAMP'], [None], raw_refs(283146))
(OUT / 'focused-raw-frames.json').write_text(json.dumps(raws, ensure_ascii=False) + '\n')
print(json.dumps({'checks': len(checks), 'all_pass': all(v['pass'] for v in checks),
                  'production_tests': None, 'note': '原始材料算术核验，不是生产源码或完整消费者测试。'}, ensure_ascii=False))

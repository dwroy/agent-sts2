# 本批静默策略提案逐项复核

记录时间：2026-10-17T10:57:48+08:00。批次：20261017-104302-strategy-proposal。独立完成，无下级agent。

本批10项均为 **waiting**。没有新源码、知识或行为规则改动，没有提交、live合入、行为版本或shipped登记。原提案的若干子公式和诊断已存在于live；其证据不能关闭含完整执行、整战后继或联合校准的宽提案。

## 身份与基线

- 开工tracked/index干净，初始HEAD为`e4582a3e4251ce5b79afae05a9a91d122e7ed915`。
- 只读取根learn.json本批行：task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配；有10个proposal_ids，没有research_request、implementation_request或proposal_repair。
- 普通专题请求只核身份：`roy-20261010-silent-deck-size-value`仍绑定另一批`20261010-150327-strategy-proposal`，本批不承接、不读取其work_spec或改根请求。
- 按普通任务`git merge --no-edit main`快进后，本批base/HEAD为完整40位`ed71989d443e9644850660e3a7b5b19cab0fce43`；后续不改HEAD。无冲突，`baseline.patch`为空。
- 十份原Markdown逐字SHA全部符合队列保存值，原字节副本、来源路径与SHA见`proposal-input-manifest.json`；只处理这十项，不领取队列其他id、不重写旧复盘。

## 证据范围与方法

本批runs仅为10个派发锚点；另核原提案明确引用的SADL3CGYTGSR、1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、Y6GM2CHWJBEY，共16个独立静默局。Y6为A0、K367为A1、SADL为A7、F4Q为A9，其余12局A10。SL和同战多窗口不增加独立局数；没有借用其他角色知识。

使用本树`learner/extract_evidence.py`统一入口，显式选择八流。每流先冻结source_size；每个选中封套包含原source、line、offset、bytes、SHA256及唯一显式局身份。随后对每一封套seek原只读日志、核原字节SHA和JSON，核输出SHA/计数；所有state角色均为SILENT。共21092个封套，原始截点/逐局计数在`evidence/evidence-manifest.json`，复核在`envelope-verification.json`。

| 流 | source_size字节 | 选中行 |
|---|---:|---:|
| states | 13818254763 | 10390 |
| decisions | 2171554269 | 10005 |
| sl-attempts | 44969488 | 84 |
| run-config | 1928062 | 16 |
| run-plans | 8794226 | 80 |
| brain | 724791850 | 501 |
| runs | 355475 | 16 |
| fight-plans | 2233957 | 0 |

fight-plans本截点选中0行只表示统一身份入口未选到本范围，不断言源日志缺失。states/decisions/brain各2行无法解析，由入口计数保留；未将坏行补造或选入。没有以正文提及局号作为归属。未复核旧截点，也未覆盖原批次报告。

生成1648个按同房turn回退分段的观察轮窗、471个药水/SL动作邻接记录。时间邻接、queued/completed回执和单步状态均不认证完整候选执行；状态端点含卡牌、毒、自动伤害等全部可见效果，不把跨轮净扣全部归给单牌。NHA初题精确切击被弃后重规划，已明确与后续完整实际轮分开。

`observation-checks.json`的30项是冻结原帧算术/身份检查，修正稿全部通过；不是tsc、vitest或生产消费者验证。例：WQ同指纹13损24伤对22损39伤；反例T7同伤而付4血换沙坑一回合；NHA14挡/损1/净扣8对8挡/损7/净扣24；TXZ少损3同时少伤9、首胜4血再开场归零；九局42次狡诈手位分布37/2/3；Q6紧勒实际23、速度临时敏捷及精英胜后2血链；1913弃磨蚀前后能量均3与重接0→25。

31个既有账本与26个相关本角色经验条目仅做来源/边界核对（`ledger-scoped-evidence.json`、`experience-scoped-snapshot.json`）。没有重算旧105/109局全历史统计，没有将原文提及但未展开的其他历史局、旧support总数或其他进阶当本批验证集；silent-0198的旧组合净2仅保留原证据限制，本批不新核其单件结算顺序。

## 当前源码与live范围

只读核17个相关源码叶子；live冻结点与9个窄功能祖先详见`source-audit.json`。13叶逐字相同，4叶只有历史注释Roy/Dai署名差（`source-leaf-differences.json`与补丁）；没有将17叶等价推成整个运行树等价。历史对局code含dirty，不能由现源码重建当时所有执行字节。

实际live冻结点：`1c8d6d2bd731514e5613ca63f46dc44fef2e59d5`。以下只证明窄功能源码已在其祖先，不作为本批实现或整项duplicate：

- cunning：`5b56a452bb9be14d620b368ec46974c1b57901ca`，live祖先核验exit 0。
- ordinary_strangle：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`，live祖先核验exit 0。
- sl_resource_audit：`1698adc96ba434a46942321e0237b70657e625b2`，live祖先核验exit 0。
- sl_candidate_audit：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`，live祖先核验exit 0。
- single_action_dispatch：`fdaf787a372880b0438e73bcac7e6d2168b038ed`，live祖先核验exit 0。
- unknown_potion_value：`c4670f4f416c7d93e192e889c5080e7e4e0e733f`，live祖先核验exit 0。
- royal_opening：`ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`，live祖先核验exit 0。
- crusher_weak_facing：`68711002f15b298b8863d2258ee5da236da151d2`，live祖先核验exit 0。
- continuation_failure_envelope：`8f02483abe28583a81f9c00e456be889353ffa47`，live祖先核验exit 0。

已读调用点：combat-plan接SL资源/候选对比；selection-dispatch只认证单动作回执且whole_plan_executed=null；狡诈按角色/进阶生成再受每步手位限制；普通紧勒限制已观察模板并对未知组合记unknown；boss-sim按样本传递HP/余药/复活，boss-start只在已观察遗物组合扣开场HP；低可信连续模拟明确不作必死/SL判据。以上是源码核查，没有新运行生产消费者、模拟池、LLM、网络或play，也不借历史测试成功冒充本批测试。

## 十项处置、反例与后续验证

### 1. silent-proposal-08eaa60bcc449852 — 赢战耗药与持药价值

- 状态：waiting。既有账本：silent-0019, silent-0020。
- 证据局/层/回合：KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1、T2/F15T1；F12、F16营火。
- 本批核验：七次实饮、零弃药；两次营火26/76→53/81、46/81→75/86已核。F15零净损仍实际花两药，不能写成不用药也零损。
- 未实现原因：缺KEN F15不饮用，以及同入口、同后继下留药至Boss的完整成对结果；七次实饮与零净损窗口只能核资源结转，不能校准持药价格。
- 预期行为及验证：继续展示当轮已建效果、实际饮用和未知持有价；获得不用/早用/留药完整后继前保留现价值规则。
- 已有窄源码范围：unknown_potion_value（完整commit见上，非整项完成）。

### 2. silent-proposal-92920295a648b540 — SL首战改善与连续通关

- 状态：waiting。既有账本：silent-0228, silent-0255。
- 证据局/层/回合：TXZ6RVMQA09D A10 F48第2/3试T6、第3试T10，F49开场。
- 本批核验：同48血/敌460/同手同指纹，原线损3扣36、替线损0扣27；首胜奖励帧4血，F49过渡4→0。后继抽牌不同，三试仍属同一局。
- 未实现原因：缺保持抽序、生成牌、药栏及后续选择一致的两战替线与联合资源校准；少损3同时少伤9不能证明连续通关改善。
- 预期行为及验证：保留首战/后战分账和低可信限制；用同样本完整两战资源结果验证，不能以低可信0%放宽SL。
- 已有窄源码范围：sl_resource_audit, sl_candidate_audit, continuation_failure_envelope（完整commit见上，非整项完成）。

### 3. silent-proposal-a327449c331efbc1 — 沙虫两条生存边界与SL血价

- 状态：waiting。既有账本：silent-0079, silent-0018。
- 证据局/层/回合：WQZVENQ7DTRP A10 F33第2/3试T9、第2/6试T7、末T11。
- 本批核验：T9同指纹：13损24伤对22损39伤；T7反例同扣24，0损对4损而行动末沙坑4对5。延时与HP两边界均须保留。
- 未实现原因：缺同时约束攻击、格挡、毒与沙坑截止线的受控整战后继和独立验证；9血换15伤不足拟固定交换率或修改SL准入。
- 预期行为及验证：保留原线与替线当前HP、毒和沙坑比较；获得受控整战结果前不改排序门槛、不笼统禁逃离。
- 已有窄源码范围：sl_resource_audit, sl_candidate_audit（完整commit见上，非整项完成）。

### 4. silent-proposal-a099e89437e942bb — 狡诈生成、保留容量与完整序列

- 状态：waiting。既有账本：silent-0030, silent-0257, silent-0258。
- 证据局/层/回合：九局已核42饮；WQZVENQ7DTRP A10 F33第5/6试T11为容量边界。
- 本批核验：42饮分布为37次添3、2次添2、3次添0；WQ三饮分别2/0/0与3/2/0，当步HP/能量不变。源码已建三升级小刀并按动态手位截断，固定测试已有穿插分支。
- 未实现原因：狡诈生成、手位截断与穿插子模型已有live祖先；原请求的计划妥当保留容量、跨重问完整派发及SL恢复联合消费者尚未核齐，不能整项duplicate。
- 预期行为及验证：保持现有容量模型；验证饮药—出刀—饮药、保留与SL恢复的完整消费者链，不能由固定子模型宣称整战获救。
- 已有窄源码范围：cunning, single_action_dispatch（完整commit见上，非整项完成）。

### 5. silent-proposal-47910f82a1fdd98f — 连战开场资源与双向血价

- 状态：waiting。既有账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。
- 证据局/层/回合：TXZ6RVMQA09D A10 F48T6/T10→F49；WQZVENQ7DTRP F33T7/T9。
- 本批核验：TXZ首胜4血后新战开场归零；WQ付血换伤及付血换沙坑两反例均成立。只读源码已有受限开场4血和实际剩余HP/药水/复活接续。
- 未实现原因：王室猛毒受限开场与同样本连战传递已有live祖先；缺未知回血/复活组合顺序，以及留药、路线和SL整战后继的联合校准。
- 预期行为及验证：现有已观察组合保持，未知回血/复活组合不外推；不预支未来能力、药效、空奖励或营火。
- 已有窄源码范围：royal_opening, sl_resource_audit, continuation_failure_envelope（完整commit见上，非整项完成）。

### 6. silent-proposal-f1374df72d8e6a25 — 持续/临时药效与连续退出价值

- 状态：waiting。既有账本：silent-0019, silent-0020, silent-0050, silent-0253。
- 证据局/层/回合：1913SE84AXQF A10 F29→F31；Q6M2Y34MWKRE A10 F2T1/T3、F8T1/T4/T7→F9T2。
- 本批核验：1913胜战46血带至F31；Q6 F2双防御14挡零损，速度当轮敏捷5/挡10，下轮撤去；F8赢只剩2血，F9仍2血进场后死亡。紧勒局部漏算已由现代码覆盖。
- 未实现原因：缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果；低信心答选和局部候选不能校准新药价或终局权重。
- 预期行为及验证：保留实际退出资源、临时/持续药效与未执行候选的区分；整战受控结果到齐后再拟价值。
- 已有窄源码范围：ordinary_strangle, unknown_potion_value（完整commit见上，非整项完成）。

### 7. silent-proposal-38a49e6c97f31eea — 紧勒、弃磨蚀及分源机制联合核验

- 状态：waiting。既有账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。
- 证据局/层/回合：Q6M2Y34MWKRE A10 F8T4；Y6GM2CHWJBEY A0 F4T1旧固定帧；1913SE84AXQF A10 F31T2—T4。
- 本批核验：Q6普通紧勒三牌加毒实扣23，下一轮层已清；1913弃磨蚀前后均3能量、建立1敏4荆棘；中段0→25重接不带旧毒力；毒雾已建但死亡前无下一轮。普通紧勒已有受限源码及固定测试。
- 未实现原因：普通紧勒已观察子公式已有live祖先；缺弃磨蚀、增益分源、再生/自动触发及SL恢复的联合消费者校准和受控整战后继。
- 预期行为及验证：只在已观察模板核逐牌时点；未知升级、叠层、重放、自动触发保留未知，不能用卡牌施放分支证明弃牌分支已实现。
- 已有窄源码范围：ordinary_strangle, single_action_dispatch（完整commit见上，非整项完成）。

### 8. silent-proposal-ef0e38a5dbd3bc07 — 路线实际动作与后继资源

- 状态：waiting。既有账本：silent-0019, silent-0020, silent-0021。
- 证据局/层/回合：1913SE84AXQF A10 F24/F28/F29/F31；Q6M2Y34MWKRE A10 F7/F8/F9。
- 本批核验：1913 F24锻造40→40，F28休息40→61，F29赢剩46而F31仍46；Q6唯一火36→57，精英赢剩2、走廊死。条件变化不能充同条件路线模型误差。
- 未实现原因：缺另一营火动作、事件、路线及用药时机的受控完整结果；两条观察性失败链不足校准路线或终局权重。
- 预期行为及验证：只计实际完成的回复/锻造及真实后继，不给未抵达营火收益；保留当前路线和终局参数。
- 已有窄源码范围：unknown_potion_value（完整commit见上，非整项完成）。

### 9. silent-proposal-7f820c02d39bfaea — 饱和SL候选与实际执行归属

- 状态：waiting。既有账本：silent-0079。
- 证据局/层/回合：NHA2KW0RB7VP A10 F33第1/5/6试T1；decisions 277248/277250/277272/277274。
- 本批核验：相同30血起点，原线14挡/损1/跨轮扣8，替线8挡/损7/跨轮扣24；原题精确切击被生存者弃掉并重规划，不能把整份初题候选称为执行完成。
- 未实现原因：缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；同一局六败不能当六个独立验证局或新血价门槛。
- 预期行为及验证：继续显示原答/护栏/SL替换及首次派发回执，完整执行须接后续帧；保持现生产SL门槛。
- 已有窄源码范围：sl_resource_audit, sl_candidate_audit, single_action_dispatch（完整commit见上，非整项完成）。

### 10. silent-proposal-04b6b430759815ed — 油灯首次消费、朝向与能力兑现

- 状态：waiting。既有账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。
- 证据局/层/回合：NHA2KW0RB7VP A10 F17T1/F33T1—T4；K3676LU8B0UH A1 F30T2；SADL3CGYTGSR A7原提案窗口。
- 本批核验：原帧确认NHA首次毒药0→10，K367首次带毒刺击0→8；NHA油灯relic.stack为null，不能由拥有遗物判断首次是否已消费。蟹朝向/虚弱取整已有受限源码祖先；不能据此推油灯全程已接线。
- 未实现原因：蟹朝向受限取整已有live祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入，以及未覆盖X值/升级组合和能力整战后继。
- 预期行为及验证：保留已证朝向子公式；油灯需验证首次消费状态传递和新战/SL重置，再覆盖完整候选，不以17局部窗口外推所有负面。
- 已有窄源码范围：crusher_weak_facing, single_action_dispatch（完整commit见上，非整项完成）。

## 拟合、限制和回退

不新增参数或固定交换率。本批旧局是发现/核帧资料；后续若改排序、持药价或终局曲线，先隔离确定机制误差，按独立run与开始时间划分更早训练、后移验证，SL同局同组，同入口/预算/后继条件列明；不把rollout样本或六次失败当独立实盘。未见完整受控替线胜果时保留现生产规则，不能写成换线/留药本可赢。

油灯现场relic.stack为null，单凭持有无法判断首次消费；需要跨动作、重问、新战与SL恢复的状态传递验证。弃磨蚀的弃牌实帧不等于卡牌直接施放分支被证明；朝向受限取整不等于通用取整次序；未知X/升级/自动触发仍未知。未来营火、未取得或未触发能力、SL恢复与实际回血分开。没有新增与旧经验冲突的机制结论，本批不重复旧科学通知，不关闭任何量化/完整候选/学习入库父要求。

若未来证据支持改动，按原任务每项单独源码提交、固定原帧/消费者验证、撤源失败/恢复通过、原沙箱检查及live锁流程上线；实际发布后再做唯一版本、双通知和运维shipped确认。当前没有新源码可回退；原日志、原提案和失败/初稿均保留，无其他角色行为变更。

## 验证、初稿与交付

- 开工大小写检查初稿把runs.jsonl的SILENT与小写silent直接比较而AssertionError；修正为规范化比较后16局全过，`identity-check.initial.txt`保留。
- 一次只读命令在执行前被bubblewrap包装器因另一批消失临时路径拒绝，原命令重试成功；`sandbox-preflight-failure.txt`保留，未放宽沙箱权限。
- 原材料检查稿30项返回0，但其中“弃磨蚀3能量”的名称错配为后续施毒2能量帧。已保留`validate-observations.initial.py.txt`、`observation-checks.initial.json`、`observation-validation.initial.log`；修正为原始282767→282768的3→3能量/1敏/4荆棘，修正后30项0见`observation-validation.corrected.log`。初稿0不充当修正前已核该时点。
- 报告生成的源码差异守卫初稿以子串替换Roy，误改Royal而拒绝boss-start叶子；未写报告/账本。改为独立单词后核通过，`write-report.initial.py.txt`及`source-comparison.initial-failure.txt`保留；不是产品源码失败。
- 无生产源码改动：撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行沙箱生产套件，不制造测试成功。没有提交，提交前gitleaks/Co-Authored-By及live合入步骤不触发。
- 专用code_proposals没有新建重复id或修改旧提案；最终code_proposals仅为这10个原CLI id。implementation_domains=[]表示本批没有实际实现。
- 仅经根ledger.py update为31个既有账本追加本报告/提案去处及复核说明；不追加support/repeat，不改claim/first_run/prior/status/version/effect/shipped。原已shipped经验不退回proposed；提案仍waiting，等待新证据重派。
- report与proposal位于本批scratch；过程材料保持，结束后由原调度器按门禁处理回收，当前不删自身工作树或旧日志。

最终账本回执：根CLI退出0，31条原账本仅追加where/note；物理旧前缀与31项保护字段均保持。回执及逐行offset/bytes/SHA见`ledger-link-receipt.json`。最终HEAD仍等于base，tracked/index/可见未跟踪均干净。

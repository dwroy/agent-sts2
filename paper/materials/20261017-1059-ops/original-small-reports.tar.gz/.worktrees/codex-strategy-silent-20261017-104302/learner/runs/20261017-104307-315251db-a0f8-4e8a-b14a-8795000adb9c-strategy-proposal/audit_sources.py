"""Freeze the exact source leaves inspected for this batch; do not claim whole-task coverage."""
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WT = OUT.parents[2]


def git(*args, cwd=WT):
    return subprocess.check_output(['git', *args], cwd=cwd)


paths = [
    'agent/src/reflex/card-model.ts',
    'agent/src/reflex/turn-solver.ts',
    'agent/src/reflex/combat-plan.ts',
    'agent/src/reflex/rollout.ts',
    'agent/src/reflex/silent-sl-resource-comparison.ts',
    'agent/src/reflex/silent-sl-comparison.ts',
    'agent/src/reflex/silent-selection-dispatch.ts',
    'agent/src/reflex/silent-potion-reference.ts',
    'agent/src/reflex/silent-crusher-facing.ts',
    'agent/src/reflex/continuation-value.ts',
    'agent/src/sim/silent-opening.ts',
    'agent/src/sim/boss-start.ts',
    'agent/src/sim/boss-lines.ts',
    'agent/src/sim/boss-sim.ts',
    'agent/src/sim/continuation-failure.ts',
    'agent/src/sl/explore.ts',
    'agent/src/sl/judge.ts',
]
commits = {
    'cunning': '5b56a452bb9be14d620b368ec46974c1b57901ca',
    'ordinary_strangle': '66283dd9982bdd7f480da7a4d9bfefea0572a9ac',
    'sl_resource_audit': '1698adc96ba434a46942321e0237b70657e625b2',
    'sl_candidate_audit': '66283dd9982bdd7f480da7a4d9bfefea0572a9ac',
    'single_action_dispatch': 'fdaf787a372880b0438e73bcac7e6d2168b038ed',
    'unknown_potion_value': 'c4670f4f416c7d93e192e889c5080e7e4e0e733f',
    'royal_opening': 'ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8',
    'crusher_weak_facing': '68711002f15b298b8863d2258ee5da236da151d2',
    'continuation_failure_envelope': '8f02483abe28583a81f9c00e456be889353ffa47',
}
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode().strip()
leaves = []
for path in paths:
    raw = (WT / path).read_bytes()
    live_raw = git('show', f'{live}:{path}')
    leaves.append({
        'path': path, 'sha256': hashlib.sha256(raw).hexdigest(),
        'base_blob': git('rev-parse', f'{base}:{path}').decode().strip(),
        'live_blob': git('rev-parse', f'{live}:{path}').decode().strip(),
        'live_sha256': hashlib.sha256(live_raw).hexdigest(),
        'same_bytes_as_live': raw == live_raw,
        'last_base_commit': git('log', '-1', '--format=%H', '--', path).decode().strip(),
    })
ancestry = []
for name, commit in commits.items():
    status = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live], cwd=WT).returncode
    ancestry.append({'scope': name, 'commit': commit, 'live_ancestor': status == 0, 'exit': status})
    assert status == 0, (name, commit, live)
result = {'base': base, 'live_snapshot': live, 'leaves': leaves, 'narrow_source_ancestry': ancestry,
          'limitation': '逐叶字节与窄功能祖先核验；不表示宽提案、历史dirty运行树或整战消费者已经完成。'}
(OUT / 'source-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'baseline.patch').write_bytes(git('diff', '--binary', 'HEAD'))
print(json.dumps({'base': base, 'live': live, 'leaves': len(leaves),
                  'same_bytes': sum(v['same_bytes_as_live'] for v in leaves),
                  'ancestors': len(ancestry)}, ensure_ascii=False))

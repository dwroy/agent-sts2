"""Append report links via the authorized root CLI; preserve all scientific/status fields."""
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
updates = json.loads((OUT / 'ledger-updates.json').read_text())
ids = {v['id'] for v in updates}
assert len(ids) == 31
assert all(set(v) == {'id','by','where','note'} for v in updates)
protected_keys = ['claim','first_run','prior','asc','status','version','effect','shipped_at']


def snapshot(raw):
    items = {}
    for line in raw.splitlines():
        v = json.loads(line)
        if v.get('id') not in ids:
            continue
        obj = items.setdefault(v['id'], {'evidence': []})
        for key in protected_keys:
            if key in v:
                obj[key] = v[key]
        obj['evidence'].extend(v.get('evidence', []))
    assert set(items) == ids
    return items


before = LEDGER.read_bytes()
before_state = snapshot(before)
(OUT / 'ledger-before-protected.json').write_text(json.dumps(before_state,ensure_ascii=False,indent=2)+'\n')
result = subprocess.run(['python3',str(ROOT/'learner/ledger.py'),'update','--character','silent'],
                        input=json.dumps(updates,ensure_ascii=False),capture_output=True,text=True,cwd=ROOT)
(OUT / 'ledger-cli.stdout.txt').write_text(result.stdout)
(OUT / 'ledger-cli.stderr.txt').write_text(result.stderr)
assert result.returncode == 0, result.stderr
after = LEDGER.read_bytes()
assert after[:len(before)] == before
appended = []
offset = len(before)
for raw in after[len(before):].splitlines(keepends=True):
    v = json.loads(raw)
    if v.get('id') in ids and v.get('by') == 'learner:strategy-proposal' and v.get('where') == updates[0]['where']:
        assert set(v) == {'op','id','ts','by','where','note'}
        appended.append({'offset':offset,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'row':v})
    offset += len(raw)
assert len(appended) == 31
after_state = snapshot(after)
assert after_state == before_state, 'protected scientific/status fields changed'
receipt = {'cli_exit':result.returncode,'ids':sorted(ids),'before_bytes':len(before),
           'before_sha256':hashlib.sha256(before).hexdigest(),'after_bytes':len(after),
           'prefix_preserved':True,'protected_fields_preserved':True,'appended':appended,
           'limitation':'保护字段比较只覆盖本次CLI完成截点；后续其他角色追加不属于本批。'}
(OUT / 'ledger-link-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cli_exit':result.returncode,'linked_ids':len(appended),
                  'prefix_preserved':True,'protected_fields_preserved':True},ensure_ascii=False))

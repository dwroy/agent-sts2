import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extractor', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
batch = json.loads((OUT / 'dispatch.json').read_text())['entry']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
runs = set(batch['runs'])
windows = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39],
           'CA5KE8GFJ9X2': [13], '8JRE1C4H4Z2W': [33],
           'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [33]}
state_lines = {277327, 277337, 277366, 277373, 277512, 277513, 277518,
               277519, 277524, 277526, 278017, 278021, 278231, 278236,
               278237, 278242, 278249, 278251, 278252, 278253, 278254, 278261}
decision_lines = {270216, 270282, 270264, 271309, 271348, 271354,
                  271495, 271509, 271982, 272195, 271992, 272040, 272076}


def powers(row):
    return {p['power_id']: p.get('amount') for p in row.get('powers', [])}


def compact_state(envelope):
    state = envelope['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': envelope['line'], 'run': envelope['run_id'],
            'floor': state.get('run', {}).get('floor'), 'turn': state.get('turn'),
            'observed_ts': envelope['row'].get('observed_ts'), 'screen': state.get('screen'),
            'player': {'hp': player.get('current_hp'), 'block': player.get('block'),
                       'powers': powers(player)},
            'hand': [c.get('card_id') for c in combat.get('hand', [])],
            'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'),
                         'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                         'block': e.get('block'), 'alive': e.get('is_alive'),
                         'powers': powers(e), 'move': e.get('move_id'),
                         'attack': [(i.get('damage'), i.get('hits'))
                                    for i in e.get('intents', []) if i.get('damage') is not None]}
                        for e in combat.get('enemies', [])]}


verified = []
frames = []
fixed_states = {}
fixed_decisions = {}
decisions = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    counts = dict.fromkeys(batch['runs'], 0)
    digest = hashlib.sha256()
    source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
    with path.open('rb') as selected, source.open('rb') as raw_source:
        for encoded in selected:
            digest.update(encoded)
            envelope = json.loads(encoded)
            assert envelope['run_id'] in runs
            assert envelope['source'] == str(source)
            assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
            raw_source.seek(envelope['offset'])
            raw = raw_source.read(envelope['bytes'])
            assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
            assert raw.endswith(b'\n') and json.loads(raw) == envelope['row']
            assert extractor.run_identity(envelope['row']) == envelope['run_id']
            counts[envelope['run_id']] += 1
            if name == 'states':
                state = envelope['row']['state']
                if state.get('combat') and state.get('run', {}).get('floor') in windows[envelope['run_id']]:
                    frames.append(compact_state(envelope))
                if envelope['line'] in state_lines:
                    fixed_states[str(envelope['line'])] = state
            elif name == 'decisions':
                row = envelope['row']
                if envelope['line'] in decision_lines:
                    fixed_decisions[str(envelope['line'])] = row
                    decisions.append({'line': envelope['line'], 'run': envelope['run_id'],
                                      'keys': list(row), 'chosen': row.get('chosen'),
                                      'sl_explore': row.get('sl_explore'), 'hp_guard': row.get('hp_guard'),
                                      'fingerprint_sha256': hashlib.sha256(row.get('fingerprint', '').encode()).hexdigest()})
    assert digest.hexdigest() == stream['output_sha256']
    assert counts == stream['counts']
    verified.append({'stream': name, 'source_size': stream['source_size'],
                     'counts': counts, 'total': sum(counts.values()),
                     'output_sha256': digest.hexdigest(), 'all_selected_bytes_and_identity_verified': True})

assert set(fixed_states) == {str(n) for n in state_lines}
assert set(fixed_decisions) == {str(n) for n in decision_lines}
for name, value in [('evidence-verification.json', verified), ('window-states.json', frames),
                    ('fixed-states.json', fixed_states), ('fixed-decisions.json', fixed_decisions),
                    ('decision-summary.json', decisions)]:
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_lines': sum(v['total'] for v in verified),
                  'streams': {v['stream']: v['total'] for v in verified},
                  'window_states': len(frames), 'fixed_states': len(fixed_states),
                  'fixed_decisions': len(fixed_decisions)}, ensure_ascii=False))

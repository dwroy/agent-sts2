import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
frames = {row['line']: row for row in json.loads((OUT / 'window-states.json').read_text())}
decisions = json.loads((OUT / 'fixed-decisions.json').read_text())
checks = []


def check(name, observed, expected, lines):
    assert observed == expected, (name, observed, expected)
    checks.append({'check': name, 'observed': observed, 'evidence_lines': lines})


def power(line, who, key, index=0):
    frame = frames[line]
    row = frame['player'] if who == 'player' else frame['enemies'][index]
    return row['powers'].get(key, 0)


def price(start, end):
    a, b = frames[start], frames[end]
    assert a['run'] == b['run'] and a['floor'] == b['floor']
    return [a['player']['hp'] - b['player']['hp'],
            sum(e['hp'] for e in a['enemies']) - sum(e['hp'] for e in b['enemies'])]


pairs = [
    ('沙虫T2', [270216, 270282], [276208, 276212, 276274, 276278], [[3, 10], [15, 17]]),
    ('实验体T1', [271309, 271348], [277327, 277337, 277366, 277373], [[0, 45], [9, 38]]),
    ('双蟹T1', [271982, 272195], [278017, 278023, 278231, 278236], [[2, 25], [10, 34]]),
    ('双蟹T3', [271992, 272040], [278028, 278031, 278076, 278079], [[9, 24], [14, 27]]),
]
for name, ds, ss, expected in pairs:
    check(name + '完整指纹相同', decisions[str(ds[0])]['fingerprint'], decisions[str(ds[1])]['fingerprint'], ds)
    # Store the digest instead of another copy of a long fingerprint.
    checks[-1]['observed'] = __import__('hashlib').sha256(checks[-1]['observed'].encode()).hexdigest()
    check(name + '实际当轮[损血,敌本体净扣]', [price(*ss[:2]), price(*ss[2:])], expected, ss)

check('污染T4逐步', [power(n, 'player', 'TAINTED_POWER') for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6], [274830, 274831, 274832, 274833])
check('火花3至6', [power(n, 'enemy', 'VITAL_SPARK_POWER') for n in [274833, 274834]], [3, 6], [274833, 274834])
check('污染T5逐步及次轮清空', [power(n, 'player', 'TAINTED_POWER') for n in [274835, 274836, 274837, 274838, 274839]], [0, 6, 12, 18, 0], [274835, 274836, 274837, 274838, 274839])
check('迷雾毒与污染血价分别保留', [price(274830, 274834), price(274834, 274839)], [[3, 8], [9, 13]], [274830, 274834, 274839])
check('加压力0/4/8', [power(n, 'enemy', 'STRENGTH_POWER') for n in [273238, 273252, 273263]], [0, 4, 8], [273238, 273252, 273263])
check('无弱及弱后意图', [frames[n]['enemies'][0]['attack'] for n in [273238, 273252, 273254, 273263, 273268]], [[[11, 1]], [[15, 1]], [[11, 1]], [[19, 1]], [[14, 1]]], [273238, 273252, 273254, 273263, 273268])
check('覆甲轮初现场', [power(n, 'enemy', 'PLATING_POWER') for n in [273238, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273238, 273247, 273252, 273258, 273263])
zap = lambda line: next(e for e in frames[line]['enemies'] if e['id'] == 'ZAPBOT' and e['max_hp'] == 23)
check('电击索引重排与增长端点', [[zap(n)['index'], zap(n)['powers']['STRENGTH_POWER'], zap(n)['attack']] for n in [274308, 274312, 274313]], [[4, 2, [[17, 1]]], [3, 2, [[17, 1]]], [3, 4, [[19, 1]]]], [274308, 274312, 274313])
check('抢夺两次与两步法', [[power(n, 'player', 'STRENGTH_POWER'), power(n, 'player', 'DEXTERITY_POWER')] for n in [274341, 274351, 274352, 274354]], [[-2, -2], [-4, -4], [-4, -2], [-4, 0]], [274341, 274351, 274352, 274354])
check('失落退场及再次抢敏现场', [[power(n, 'player', 'STRENGTH_POWER'), power(n, 'player', 'DEXTERITY_POWER'), len(frames[n]['enemies'])] for n in [274358, 274362]], [[0, 0, 1], [0, -2, 1]], [274358, 274362])
check('实验体阶段现场', [[frames[n]['enemies'][0]['hp'], frames[n]['enemies'][0]['max_hp'], power(n, 'enemy', 'POISON_POWER')] for n in [277512, 277513]], [[4, 111, 4], [212, 212, 0]], [277512, 277513])
check('零毒触媒', [power(277519, 'player', 'ACCELERANT_POWER'), power(277519, 'enemy', 'POISON_POWER')], [2, 0], [277519])
check('后得敏捷未倒补挡', [[power(n, 'player', 'DEXTERITY_POWER'), frames[n]['player']['block']] for n in [277524, 277526]], [[5, 23], [6, 23]], [277524, 277526])
check('船夹板与新增格挡', [frames[n]['player']['block'] for n in [278236, 278240]], [14, 20], [278236, 278240])
check('普通镣铐临减与恢复', [power(n, 'enemy', 'STRENGTH_POWER') for n in [278236, 278237, 278242]], [0, -9, 0], [278236, 278237, 278242])
check('朝向与虚弱分列', [frames[n]['enemies'][1]['attack'] for n in [278249, 278252, 278253]], [[[57, 1]], [[38, 1]], [[28, 1]]], [278249, 278252, 278253])
check('脆弱四敏现场6挡', [frames[n]['player']['block'] for n in [278255, 278260]], [6, 6], [278255, 278260])
check('实验体末轮扣血与完整需损', [197 - frames[277527]['enemies'][0]['hp'], 44 - frames[277527]['player']['block'], frames[277527]['player']['hp']], [37, 21, 18], [277519, 277527])
check('双蟹末轮毒扣及实死', [frames[278260]['enemies'][0]['hp'] - frames[278261]['enemies'][0]['hp'], frames[278260]['enemies'][1]['hp'] - frames[278261]['enemies'][1]['hp'], frames[278261]['player']['hp']], [3, 7, 0], [278260, 278261])

(OUT / 'facts-verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks_passed': len(checks), 'note': '仅原帧与同轮端点，不是源码测试或整战反事实'}, ensure_ascii=False))

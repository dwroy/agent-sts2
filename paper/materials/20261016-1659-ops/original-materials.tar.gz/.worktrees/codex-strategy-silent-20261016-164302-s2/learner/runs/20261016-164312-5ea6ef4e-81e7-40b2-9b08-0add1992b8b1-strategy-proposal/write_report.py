import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
base = dispatch['base']
details = [
    ('感染棱柱污染', 'DUZUBAJ3A8GP F27 T4—T6；states 274830—274839',
     '污染0→3→3→6，能力勒紧一步不增加；火花3→6后污染0→6→12→18，下一轮清空。T4/T5实际损血3/9、敌本体净扣8/13，技能收益和血价同时保留。',
     'turn-solver.ts:2125/2950已有技能叠污染及意图调整；rollout.ts:2391已有火花增长接线，1698adc96ba434a46942321e0237b70657e625b2为实际live祖先且含当前求解源码。',
     '缺同次冻结的实际移动表、火花增长与污染撤除/虚弱/毒/格挡的联合生产重放校准；旧dirty运行输入未复原，尚未确认可唯一归责的新计算差额。',
     '保留逐击血价和毒/挡收益，全部候选仍可选。以原帧、原出牌前缀及同一来源移动表同时重放solver与rollout；发现具体差额再做修正，不据9损强制少打技能。'),
    ('失落/遗忘抢夺返还', '5PM6JAQG6FNQ F39 T2/T4—T6；states 274341/274351/274352/274354/274358/274362',
     '玩家力敏−2/−2至−4/−4；两次步法使敏捷−4→−2→0；失落退场后力量回0，遗忘下一轮再抢使敏捷0→−2。末试单步法回−2，最后死亡，未观察另一杀序获胜。',
     '当前求解/推演读取现场力量、敏捷和负属性；这只能证明现场值被消费，不能证明逐来源返还模型及所有后继已经校准。',
     '缺逐来源累计抢夺、稳定实体连续身份和毒杀退场返还后再次抢夺的完整生产输入对账；没有另一杀序的受控整战后继。',
     '继续分别保留负属性、建立步法、毒杀与返还端点；不得预设击杀序。未来固定每来源账与实体代际，逐步核对返还，不由当前负属性公式宣称已经完整实现。'),
    ('下水道蚌当前进阶事实', 'CA5KE8GFJ9X2 F13 T1—T5；states 273238/273247/273252/273254/273258/273263/273268/273269',
     '同招力量0/4/8时意图11/15/19，弱后15→11、19→14；轮初覆甲9/9/8/7/6。末轮2血10挡对14，实际血量截到0，不把2实扣当完整需损4。',
     'monster-db.ts:711/843直接读取已有当前进阶伤害/HP，未设五样本门槛；roomHpCost:1442仍受ROOM_COST_MIN_N=5。当前文件4ed3c72df30f27b881da637aebf528b97440e0bb是live祖先。',
     '首样本事实接口已有实现；缺旧局实际调用移动表与加压、覆甲、虚弱的联合生产重放校准，完整覆甲减层条件仍未证。',
     '沿用首样本HP/攻击事实和房间成本五样本门槛；冻结原移动表与逐步状态后验证联合效果，不从层数序列新增减层规则。'),
    ('电击高电压增长', '5PM6JAQG6FNQ F38 T3/T4；states 274308/274312/274313/274317',
     '23上限电击索引4→3，力量2→4、攻击17→19，T3仍提供17攻击，T4才退场。类型、HP上限和索引变化本身不能提供全局唯一实体身份。',
     'rollout.ts:526/2374/2763有HIGH_VOLTAGE_POWER增长；spawnedEnemy初始化growth=0。当前rollout源码f3dea91880600bc2e7228268a110a644531738f7为live祖先；这不是本次跨代校准证明。',
     '缺稳定召唤代际身份、该次实际A10移动表和跨代重置的冻结校准；未打的先杀爪牙线没有完整后继，不能承诺救后场。',
     '保留现有增长和新实体初始化；有明确实体/代际证据后，用固定召唤、退场、再召唤序列校准，不按重排index搬旧计数。'),
    ('沙虫护栏与SL资源审计', '8JRE1C4H4Z2W F33 首/第三试T2、第二试T5、末试T11；decisions 270216/270282/270264',
     'T2两题完整指纹相同；实损3→15、净扣10→17，付12血多7伤。270282明列五轮0/24→5/24死亡，不是相同死率。第二试T5实际21血/224敌血接续，候选省血不能移用于抽牌后未完成线。',
     '66283dd9982bdd7f480da7a4d9bfefea0572a9ac已有护栏/候选快照；1698adc96ba434a46942321e0237b70657e625b2扩展替线资源；bade647f9fe4c9103b40e2f26b26296692ad24b7与fdaf787a372880b0438e73bcac7e6d2168b038ed已有单动作回执。均为实际live祖先。',
     '缺抽弃、生成、用药或重问后整候选的连续身份、逐来源能力兑现和联合路线/药水/SL恢复消费者；单动作返回和轮端点不等于完整候选已执行。',
     '保留原答/护栏/SL后方案与预测差；完整执行、净血量和能力建立另核。补齐跨重规划归属后再验证原提案，当前不改探索或护栏系数。'),
    ('实验体全败SL替换代价', 'YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348/271354；states 277327—277373',
     '完整指纹相同，实际损0→9、净扣45→38；当题候选预测0/10损、54/36伤，与实际值分列。271354确实改end_turn；同局F33后继REWARD 20血（277086—277090）保留为成功SL反例。',
     'silent-sl-comparison、silent-sl-resource-comparison、silent-selection-audit及selection-dispatch已有预测/派发分账，来源祖先同上一项；execution=unverified、whole_plan_executed=null是源码明确边界。',
     '缺被截断续步的完整候选归属与独立受控获胜后继；全败并列和当轮少伤多失血不足以拟惩罚系数或禁止探索。',
     '保留覆盖重放原因和未证完整执行状态；以同指纹原/替线逐段比对，并保留F33成功反例，不把有限样本全败解释成安全。'),
    ('实验体阶段/毒/敏捷兑现', 'YF0LXT1QSTGG F48 末试T3—T5；states 277512/277513/277519/277524/277526/277527',
     '4血4毒的111上限阶段转212上限、毒0；T5触媒2而毒0。敏捷5→6时既有挡保持23；末轮197→160净扣37、18血对44−23需损21，缺3。',
     'silent-phase-current.ts已提供现场阶段、零毒、已建能力与持有组件区别；8698c581dac6c7e957f50a381586960a6d0c9b57及aad2700abed6dff1d66e87fb36aaa6fedb39adf3均为live祖先，当前文件与live逐字相同。',
     '缺逐候选跨阶段完整执行、施毒与结算逐来源对账、格挡前后取得敏捷顺序的联合生产校准；现场快照不能认证后继收益。',
     '沿用本帧事实、不预支零毒触媒收益或倒补挡；先补完整前缀/能力建立/毒结算归属，暂不改排名或强制毒能力先手。'),
    ('双蟹零胜SL血价', 'XP2SL33HT0D9 F33 首/末试T1、首/第二试T3；decisions 271982/272195/271992/272040/272076',
     'T1同指纹实损2→10、净扣25→34；T3同指纹实损9→14、净扣24→27。272076 B2同为0却五轮21/24→23/24死亡，仅为候选事实，不能冒记实损8。手里剑成长保留。',
     '既有候选/资源/选择/派发审计为部分覆盖；它们不提供独立整战胜率或未选线后继。相关祖先66283dd9982bdd7f480da7a4d9bfefea0572a9ac、1698adc96ba434a46942321e0237b70657e625b2。',
     '缺同抽序、药瓶随机落点后继及成长兑现的受控整战比较；B2零胜并列和单轮血价不足以拟探索门槛。',
     '继续分列当轮HP、输出、力量成长和采样未知；不填全局血价常数，不由多打9伤或少损血单独认定整战策略优劣。'),
    ('双蟹朝向/临减/轮初挡', 'XP2SL33HT0D9 F33 末试T2/T4/T5；states 278236/278237/278240/278242/278249/278252/278253/278255/278260/278261',
     '轮初14挡、斗篷后20；普通镣铐力0→−9→0；激光57→转向38→虚弱28；四敏脆弱下偏折/防御各6；末轮毒净扣3+7，玩家0血，两敌153/125存活。',
     'passive-pieces有HORN_CLEAT_BLOCK=14/T2，card-model读StrengthLoss、solver/rollout有临时力量恢复和朝向/虚弱路径。当前源码已核祖先；三份live字节差仅历史Roy/Dai注释，详source-live.diff.txt。',
     '缺全部修饰组合的同次冻结生产回放、抽弃重规划后完整执行及未选后继；现有窄覆盖不代表全部组合校准或整战因果。',
     '保留朝向/虚弱/临减/轮初挡分别可核验的贡献；后得敏捷和临时减力不延长到未证窗口，当前不改能力优先级或护栏。'),
    ('综合机制与联合资源消费者', 'YF0LXT1QSTGG F48与XP2SL33HT0D9 F33；以上三组同指纹对照及各机制端点',
     '六锚点支持本批端点与四组配对；原综合提案提及101局、1499房与其他角色无关机制条件，本批没有重跑其全历史分母。尝试数不扩作独立局数。',
     '复用已核实的候选/护栏/阶段事实/派发窄模块；不把这些模块存在或单帧读值当作联合资源消费者已经交付。',
     '本批六局不能替代原101局的联合资源重建；完整候选、路线、休息、实际用药及SL恢复的逐来源联合消费未闭合。',
     '保留父提案与原证据范围，后续按run分组及时间后移验证完整链；本次不关闭经验入库、量化学习或其他父要求。'),
]

items = []
for (ident, proposal), detail in zip(assigned.items(), details, strict=True):
    title, evidence, finding, existing, reason, method = detail
    items.append({'id': ident, 'state': 'waiting', 'reason': reason, 'title': title,
                  'ledger': proposal['ledger'], 'evidence': evidence, 'finding': finding,
                  'existing': existing, 'expected_and_validation': method})
(OUT / 'dispositions.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 本批策略提案核验

本批 `{dispatch['batch']}`，角色silent，完整基线 `{base}`。开工工作树干净，`git merge --no-edit main` 返回Already up to date。根learn.json对应行task/character/worktree及十个proposal_ids已核；没有research_request、implementation_request或proposal_repair。普通专题请求绑定的是其他旧批次，本批不套用纯研究或冻结实现身份。

本批逐项处理原十提案，无新增提案id、无源码/知识修改、无提交/合入/版本。十项均waiting：现有窄实现和已观察事实已确认，剩余范围未满足，不冒标整提案duplicate/implemented。十份原提案副本各自与登记SHA一致，已逐字保存到本目录；原文及历史不改。

只分析派发六个silent A10局：{', '.join(dispatch['entry']['runs'])}。共用提取入口输出8,274条（states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0），每条回原文件seek核offset/bytes/SHA/JSON及显式身份，结果见evidence-verification.json。各流source_size和产物SHA见evidence/evidence-manifest.json；截点各流独立，不冒称同一物理时间快照。fight-plans零条仅表示此截点未选到；不据此声称原日志缺失。全源前缀坏行计数不是本六局的错误计数，已选行全部可解析。

从已核原流保留1,014个限定房间快照、22个固定原状态与13条关键决策。27项材料断言通过；四组完整fingerprint逐字相同并核实际当轮端点。它们是发现/核验材料，不是生产源码测试或独立胜率验证。

'''
parts = [intro]
for item in items:
    parts.append(f'''## {item['id']}：{item['title']}

账本：{', '.join(item['ledger'])}。证据：{item['evidence']}。

已核实：{item['finding']}

现有代码/边界：{item['existing']}

处置：waiting。{item['reason']}

预期行为与验证：{item['expected_and_validation']}

''')
parts.append('''## 共同限制、反例、后续验证与回退

本批六局都为A10；不读取其他角色私有知识、不由预训练知识补结论。旧经验宽进阶和历史支持数只作为原文范围，不冒称本批已验证。SL同存档尝试相关，不能扩作独立局或跨训练/验证。固定端点确认可以先做，不要求每个事实必须有获胜对照；改变长期排名、探索阈值或药水价值则需对应受控后继和后移独立局，目前缺失。

YF F33成功SL且20血、XP付血同时有力量收益、8J更防御线延至T11仍败、零毒能力和已建能力仍败这些反例均保留。不由一次死亡认定强制输出/格挡/能力顺序，不将候选损血差当实际保血或将活敌净差一律当牌本体伤害。DU本批F27 T4是PULSATE_MOVE单击端点，不搬账本其他来源的三连击条件到本局。

既有源码14叶与实际live核SHA及祖先，见source-audit.json；11叶逐字相同，3叶仅历史署名注释差，完整差值见source-live.diff.txt。源码存在证明局部接线，不复原旧dirty运行树、完整移动表或生产校准。无新增实证异议/机制反例；不强行强化旧假设，不替其他角色作确认。

本批没有拟合新系数/阈值。后续先固定同次执行源码、当前进阶知识输入、手牌及候选/派发/重规划身份，逐步对账血量、格挡、毒、力量、敏捷、退场与SL恢复；具体差额才构成修改依据。策略验证按独立run和时间顺序留后验样本，不混同SL存档。未来代码提交须撤源码失败/恢复通过、自测、gitleaks、实际live合入及规则双通知；本批没有代码可撤或回退，不修改原上线行为。

材料核验首稿把船夹板斗篷后端点误写成278239（实为出牌前14挡），原脚本check_facts-v1.py.txt与失败facts-verification-v1.log保留；回原帧确认278240才为20挡，修正材料定位后27项通过。不是生产代码失败或机制反证。只读定位还曾探测不存在的agent/src/hand/execute.ts与agent/src/sim/route-hp.ts，后已用实际文件hand/loop.ts和monster-db.ts定位，无产品故障或源码变化。

''')
proposal_text = ''.join(parts)
(OUT / 'proposal.md').write_text(proposal_text)
report = proposal_text + '''## 交付与测试口径

proposal.md为本批十项完整处置，dispositions.json为机器可读细节；code_proposals沿原十个CLI id，不另建重复项。学习账本只经根ledger.py追加本批proposal/report追溯where/note，不重复support/repeat、不改claim、first_run、prior、evidence、status、version，不将原已shipped条目倒退proposed；无新条目需要定proposed。CLI输入/输出与前后受保护字段校验留本目录。队列的waiting处置交完成事件，不直接改队列或根learn.json。

未改源码：tsc=null、vitest=null、cases=null，未运行生产测试；撤源码失败/恢复通过不适用，不借既有绿色测试冒本批通过。fixes=[]，merged=null，无提交、eval版本、上线、shipped或规则双通知。无需执行live合入章节，也未写live知识刷新。工作树最终HEAD应等于基线且tracked/index干净，核验见final-integrity.json；过程材料位于忽略的本批learner/runs目录，保留原失败和数据。

交运维：本目录proposal.md、report.md、result.json及各原提案id逐项waiting理由。实际上线/经验消费者和宽父闭环仍由各原任务继续，报告不代替入库或采用证明。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'],
          'base': base, 'runs': dispatch['entry']['runs'], 'fixes': [],
          'skipped': [],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': list(assigned), 'implementation_domains': [],
          'proposal_results': [{'id': i['id'], 'state': 'waiting', 'reason': i['reason']} for i in items],
          'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
subprocess.run(['git', 'diff', '--binary', base], stdout=(OUT / 'source.diff.patch').open('wb'), check=True)
print(json.dumps({'proposals': len(items), 'waiting': len(items), 'base': base,
                  'report': str(OUT / 'report.md'), 'ledger_ids': len({i for p in assigned.values() for i in p['ledger']})}, ensure_ascii=False))

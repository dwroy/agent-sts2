from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261016-0256';pub=r/'paper/materials/20261016-0256-ops';pub.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
state=load(r/'ops/codex-ops/learn.json');deployment=load(r/'paper/materials/20261016-0240-ops/publication.json');host_batch='20261016-021301-strategy-proposal'
original=state['batches'][host_batch];check=[x for x in original['fallback_checks'] if x['tree']==deployment['tree']];assert len(check)==1;check=check[0]
assert check['rc']==0 and check['merged']==deployment['actual_live'] and check['commits']==[deployment['source']]
assert original['state']=='failed' and original['rc']==0 and original['merged'] is None
rawlog=Path(check['log']).read_bytes();plain=re.sub(r'\x1b\[[0-9;]*m','',rawlog.decode());assert re.search(r'Test Files\s+488 passed\s+\(488\)',plain) and re.search(r'Tests\s+4915 passed\s+\|\s+2 skipped\s+\(4917\)',plain) and '615.86s' in plain
assert git('rev-parse','HEAD',cwd=r/'.worktrees/live').decode().strip()==deployment['actual_live'] and git('rev-parse','HEAD^{tree}',cwd=r/'.worktrees/live').decode().strip()==deployment['tree']
for cwd in [r,r/'.worktrees/live']:git('merge-base','--is-ancestor',deployment['source'],'HEAD',cwd=cwd)
for cwd in [r,r/'.worktrees/live']:
    versions=load(cwd/'eval/versions.json');mapped=[x for x in versions['release_numbering']['releases'] if x['commit']==deployment['behavior_commit']];assert len(mapped)==1 and mapped[0]['release_id']==deployment['release_id']=='V5-R365'
(pub/'original-host-full.log').write_bytes(rawlog)
closure=dict(batch=host_batch,actual_live=check['merged'],tree=check['tree'],release_id=deployment['release_id'],source=deployment['source'],original_check=check,log_bytes=len(rawlog),log_sha256=sha(rawlog),tsc=0,vitest=0,files_passed=488,cases_passed=4915,cases_skipped=2,duration_seconds=615.86,original_failed_rc0_mergednull_preserved=True,only_host_pending_closed=True,natural_consumer='pending',no_new_test_or_request=True)
write(pub/'host-closure.json',closure)
extract=module('raw_identity',r/'learner/extract_evidence.py');batches=[];owned=[];artifacts=[]
ids=['20261016-024301-strategy-proposal','20261016-024301-s2-strategy-proposal']
exec((p/'readonly-runtime.py').read_text())
for index,bid in enumerate(ids):
    b=state['batches'][bid];report=b['report'];s=Path(report['report']).parent;out=r/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'completion.json')
    assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
    assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
    assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
    assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
    assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
    if index==0:
        assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
        assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
        final=load(s/'final-validation.json');assert final['工作树干净'] and final['全部waiting'] and final['账本追加']==26 and final['gitleaks_exit']==0 and load(s/'gitleaks.json')==[]
        assert sha((s/'report.md').read_bytes())==final['report_sha256'] and sha((s/'proposal.md').read_bytes())==final['proposal_sha256'] and sha((s/'completion.json').read_bytes())==final['completion_sha256']
        inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];receipt=load(s/'ledger-append-receipt.json');assert receipt['cli_exit_code']==0 and receipt['updates']==26;rows=receipt['physical_rows']
        assert all(x['保护字段同一'] for x in receipt['protected']);assert set((s/'ledger-cli.stdout.txt').read_text().split())=={x['id'] for x in inputs}
        facts=load(s/'material-checks.json');assert facts['检查数']==len(facts['checks'])==55 and all(x['实际']==x['期望'] for x in facts['checks'])
        proposals=load(s/'proposals-folded.json');source=load(s/'source-readback.json');sourceleaves=source['paths']+[load(s/'source-readback-supplement.json')];live=source['live']
    else:
        assert {k:v for k,v in scratch.items() if k!='evidence_runs'}==report and scratch['evidence_runs']==report['runs']
        final=load(s/'final-readback.json');assert final['task_identity_unchanged'] and final['all_ten_ids_accounted'] and final['original_proposals_unchanged'] and final['git_clean'] and final['ledger_own_rows']==30 and final['material_checks']==56 and final['production_tests_executed'] is False
        assert sha((s/'report.md').read_bytes())==final['report_sha256'] and sha((s/'proposal.md').read_bytes())==final['proposal_sha256'] and (s/'final-worktree.patch').read_bytes()==b''
        inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()];receipt=load(s/'ledger-write-readback.json');assert receipt['cli_exit_code']==0 and receipt['protected_fields_unchanged'] and receipt['existing_where_notes_history_prefix_preserved'];rows=receipt['appended_own_rows'];assert len(rows)==30
        assert set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs}
        facts=load(s/'material-verification.json');assert facts['count']==len(facts['checks'])==56 and all(x['实际']==x['预期'] for x in facts['checks'])
        proposals=list(load(s/'assigned-proposals.json').values());source=load(s/'source-readback.json');sourceleaves=source['files'];live=source['live_head']
    assert {x['id'] for x in proposals}==set(report['code_proposals'])==set(b['proposal_ids'])
    for x in proposals:
        originalfile=Path(x['proposal']);assert originalfile.is_relative_to(r) and sha(originalfile.read_bytes())==x['proposal_sha256']
    with (r/'paper/materials/learning/ledger.jsonl').open('rb') as ledger:
        for entry in rows:
            ledger.seek(entry['offset']);raw=ledger.read(entry['bytes']);row=json.loads(raw);assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
            assert any(all(row.get(k)==v for k,v in item.items()) for item in inputs);owned.append(raw)
    manifest=load(s/'evidence/evidence-manifest.json');counts={}
    for stream in manifest:
        frozen=s/'evidence'/(stream['stream']+'.evidence.jsonl');assert sha(frozen.read_bytes())==stream['output_sha256'];seen=collections.Counter()
        with frozen.open() as selected,(r/'logs'/(stream['stream']+'.jsonl')).open('rb') as originalfile:
            for line in selected:
                e=json.loads(line);originalfile.seek(e['offset']);raw=originalfile.read(e['bytes']);row=json.loads(raw)
                assert sha(raw)==e['sha256'] and row==e['row'] and extract.run_identity(row)==e['run_id'] and e['run_id'] in report['runs'] and e['offset']+e['bytes']<=stream['source_size'];seen[e['run_id']]+=1
                if stream['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
        assert all(seen.get(run,0)==count for run,count in stream['counts'].items());counts[stream['stream']]=sum(seen.values())
    assert sum(counts.values())==[6995,8274][index]
    differences=[];absent=[]
    for x in sourceleaves:
        path=x['path']
        if x.get('present') is False:absent.append(path);continue
        a=git('show',report['base']+':'+path);z=git('show',live+':'+path);assert sha(a)==x.get('base_sha256',x.get('sha256')) and sha(z)==x.get('live_sha256',x.get('live_head_sha256'))
        assert (a==z)==x.get('equal',x.get('live_head_matches'));commit=x.get('source_commit',x.get('last_source_commit'));git('merge-base','--is-ancestor',commit,report['base']);git('merge-base','--is-ancestor',commit,live)
        if a!=z:differences.append(path)
    assert len(differences)==[2,6][index]
    consumers=None
    if index==0:
        consumers=load(s/'audit-results.json');assert len(consumers)==6 and all(x['returncode']==0 for x in consumers);totals=collections.Counter()
        assert load(s/'audit-input-manifest.json')['excluded_metadata']==[]
        for x in consumers:
            run=x['run_id']
            for suffix,key in [('input.json','input_sha256'),('output.json','output_sha256'),('stderr.txt','stderr_sha256')]:assert sha((s/f'audit-{run}-{suffix}').read_bytes())==x[key]
            audit=load(s/f'audit-{run}-output.json');actual=dict(segments=len(audit['segments']),actions=len(audit['observed_actions']),endpoints=sum(a['observed_interval']['status']=='observed_endpoints' for a in audit['observed_actions']),turn_endpoints=sum(t['status']=='observed_turn_endpoints' for t in audit['observed_turns']),unknown_turns=sum(t['status']=='unknown' for t in audit['observed_turns']),certified_candidates=sum(t['actual_full_candidate_result'] is not None for t in audit['segments']))
            assert all(x[k]==v for k,v in actual.items());totals.update(actual)
        assert totals==dict(segments=139,actions=693,endpoints=505,turn_endpoints=76,unknown_turns=55,certified_candidates=0)
    native=runtime(bid,report,output,b['worktree']);detail=dict(batch=bid,original_report=report,original_scratch_report=scratch,source=source,native=native,final=final,stream_counts=counts,original_rows=sum(counts.values()),material_assertions=[55,56][index],owned_trace_rows=[26,30][index],different_source_paths=differences,missing_source_probe=absent,original_consumers=consumers,consumers_not_reexecuted=True,limits=['Actual source differences include R365 Paper Krane implementation as well as historical comments; no byte/behavior equivalence claim.','No production tests, new source, merge or release; original material/consumer checks are not natural consumption or calibration.','Incomplete candidate attribution, controlled successors, consumed dirty knowledge and wide parents remain open.','Original preparation errors and the known old evidence-link/erratum boundaries are retained; no new game counterevidence or other-role ACK is created.'])
    write(pub/f'batch{index+1}-readback.json',detail);batches.append(detail)
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(r));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
assert len(owned)==len(set(owned))==56
old=git('show',base+':paper/materials/learning/ledger.jsonl');existing=set(old.splitlines());assert all(raw.rstrip(b'\n') not in existing for raw in owned);added=b''.join(owned)
ledger=module('owned_ledger',r/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert all(value in z[ident]['where'][key] for value in values)
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for entry in artifacts:archive.add(r/entry['path'],arcname=entry['path'])
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
closure['at']=at;write(pub/'host-closure.json',closure)
pending=r/f'ops/codex-ops/pending-integrations/{host_batch}.json';handoff=load(pending);assert handoff['tree']==check['tree'];handoff.update(host_result='passed exact b7c5dff8 tree, tsc/vitest0; 488 files4915 passed2skipped',host_closure='paper/materials/20261016-0256-ops/host-closure.json',host_closed_at=at,natural_consumer='pending next natural matching Silent A10 beam/Paper Krane/plain Sucker Punch; no forced model/game request');write(pending,handoff)
decision=f'\n- {at} 运维codex：0256三事件核收。原024301/024301-s2策略均done0/no-source，各十waiting具体缺口/testsnull/域空/mergednull、36aab干净WT/HEAD不变，无合入受阻，不空合/发号/补测。两组6局Silent A10八流6995/8274原offset/bytes/SHA/JSON/身份核，55/56材料断言及第一批六指定层离线IO/stderr SHA核，139段/693动作/505相邻端点/76轮端点/55未知/整候选0，无丢无ID元数据；不是整局/生产测试/自然消费者或独立校准。第一批12实际源码+selection-turn补核、第二批17源码SHA及真实祖先核，live已有R365实现差异（两批差2/6叶）与历史注释并存，不归一成仅注释等价；路径探针/初稿/旧复盘勘误/账本读回首错原件保，不当新产品故障/反证。26+30所属CLI只where/note，私有fold旧claim/首证/prior/evidence/status/version与旧history/notes/where前缀全保，不重复CLI或降级shipped；当前两native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核，旧脑high历史不改。原021301策略R365/livee716bd28/treeb7c5dff8精确宿主tsc/vitest0，488文件4915过2跳/615.86秒，唯一fallback0及日志SHA核，source8d386真实main/live祖先与唯一号不变；只关闭该树宿主pending，原failed/rc0/mergednull/18冲突、下一自然匹配消费者与宽量化/学习父保持。仅所属记录与56追溯提交，无源码/知识/版本/论文刷新/测试重跑/请求/派发/对局重启或账号home模型额度权限prompt操作。证据paper/materials/20261016-0256-ops/。\n'
note=f'\n- {at} [运维 codex] V5-R365精确b7c5dff8宿主完整tsc/vitest0：488文件4915过2跳，原单次检查结案；自然消费者仍pending。另两批各十项waiting，55/56材料检查及56所属追溯核同，无源码改动或合入受阻，不借检查关闭宽父。回执paper/materials/20261016-0256-ops/。\n'
ops_handoff=f'\n- {at} V5-R365原021301策略精确livee716bd28/treeb7c5dff8完整宿主tsc/vitest0（488文件4915过2跳/615.86秒），原唯一fallback及日志SHA收尾；宿主pending关闭，不重复请求/重测不变树，failed-rc0-mergednull及18冲突保持。0489已独立shipped，原0469/0070/代码提案/宽父与下一自然匹配纸鹤光束消费者仍pending；源WT按既有retention门槛，不造自然接受或强开局。两新024301策略仅原材料处置，不能当R365自然消费者。回执paper/materials/20261016-0256-ops/host-closure.json。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note,'notes/ops-handoff.md':ops_handoff};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (r/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batches=ids,waiting=20,owned_trace_rows=56,old_fields_and_prefixes_preserved=True,host_closed=closure,natural_consumer='pending',no_new_source_tests_merge_or_release=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=20,owned_trace_rows=56,ledger_check=0,host_closed=True,paths=len(entries))))

# 本批十项策略提案复核


批次：20261016-024301-s2-strategy-proposal；角色 silent；基线 `36aab69ff879442cc6d492b2ab99b8b6bbd8853b`。

本批普通消费队列；无 research_request / implementation_request，未匹配其他请求。初始工作树干净，合并main返回Already up to date。只处理dispatch.json保存的十个id；不扩队列、不重写旧提案和复盘。

八流抽取共8274行逐原日志offset/bytes/SHA/JSON与显式身份复核，重点读回1062状态帧、267条问题或SL记录；这些是材料核验而非生产自测。六局均为SILENT A10，六个独立局，SL尝试不扩分母。

四组同指纹对照（损血/敌本体净扣）：8JRE F33T2 3/10→15/17；YF F48T1 0/45→9/38；XP F33T3 9/24→14/27；XP F33T1 2/25→10/34。只是已执行轮窗口，不证明最初候选完整执行或独立整战反事实。

没有新的充分证据支持修改出牌、药水、SL或终局参数。本批未修改源码、知识、规则、阈值；无新增提案id、源码提交、撤源码负控、tsc/vitest、live合入或eval版本。全部十项waiting保持，已有窄实现不替整项关闭。


## 1. silent-proposal-c20b5139dd0dff71


冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。

证据位置：DUZUBAJ3A8GP / F27 / T4–6；原日志引用：states 274830–274839。

关联原账本：silent-0168。

污染0→3→6，能力勒紧不加；次轮火花3→6，三技能污染6/12/18，实损9；再轮污染消失。

旧规则/当前实现：turn-solver.ts:2123/2947；rollout.ts:2391；combat-plan.ts:850。原文保存于 original-proposals/silent-proposal-c20b5139dd0dff71.md；SHA256 `bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c`。

预期行为及验证方法：冻结当轮每个技能、毒与弱的先后及当前进阶移动表，对比逐击血价和下一轮撤污染；不得据单局9损设置少打技能规则。

反例/未知与本次处置：waiting。缺原dirty运行实际消费的A10完整移动表，以及毒、虚弱、格挡、污染跨轮的联合消费者固定输入；本批未发现当前污染接线的新确定性差异。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 2. silent-proposal-ae9e692d680e3819


提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。

证据位置：5PM6JAQG6FNQ / F39 / T2、4–6；原日志引用：states 274341/274351/274352/274354/274358/274362/274391–274397。

关联原账本：silent-0183, silent-0005。

两次抢夺使力敏各−4，两步法只把敏捷−4→−2→0；失落退场后力量归0，遗忘后轮再夺敏；末试仅一步法仍−2敏且死亡。

旧规则/当前实现：combat-plan.ts:131–133，enemySims读取现场力敏；原提案完整分源未验收。原文保存于 original-proposals/silent-proposal-ae9e692d680e3819.md；SHA256 `b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5`。

预期行为及验证方法：须分开玩家总属性和每个实体实际夺取的量，覆盖毒死、非抢夺增减及index重排，不拟固定击杀顺序。

反例/未知与本次处置：waiting。缺逐实体累计被夺量、非抢夺属性来源与死亡返还的冻结模型输入；总负属性不能反推返还量，另一杀序的完整后继未执行。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 3. silent-proposal-52f1e1bd2e7db0ed


第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。

证据位置：CA5KE8GFJ9X2 / F13 / T1–5；原日志引用：states 273239/273252/273263/273268/273269。

关联原账本：silent-0231。

当前场敌58HP；两次加压力0/4/8，喷11/15/19；末次弱后14、挡10、HP2，完整需损4而实扣截顶2。

旧规则/当前实现：monster-db.ts:712/844；room-costs.ts:51/62。原文保存于 original-proposals/silent-proposal-52f1e1bd2e7db0ed.md；SHA256 `651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376`。

预期行为及验证方法：首样本保留exact读值，房间代价继续五样本门槛；按加压、弱、覆甲逐步核验，不把现场层数当完整减层规则。

反例/未知与本次处置：waiting。当前进阶首样本HP/攻击读取已存在；仍缺原dirty运行实际消费的A10移动表字节，以及覆甲完整减层条件的独立联合输入。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 4. silent-proposal-6dd8bbff876be528


复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。

证据位置：5PM6JAQG6FNQ / F38 / T3–4；原日志引用：states 274308/274312/274313。

关联原账本：silent-0233, silent-0209。

唯一23上限电击存活跨轮，力2→4、同招17→19；同轮其他敌退场后index4→3，不能把index当稳定代际。

旧规则/当前实现：rollout.ts:526/2374/2763；spawnedEnemy:1649。原文保存于 original-proposals/silent-proposal-6dd8bbff876be528.md；SHA256 `48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5`。

预期行为及验证方法：固定已存活与新召唤两类实体，覆盖index重排及同类替换，当前进阶攻击仍读DB；未执行先杀线不算27保血实得。

反例/未知与本次处置：waiting。HIGH_VOLTAGE_POWER成长接线已存在；缺稳定召唤代际、新同类替换与累计量归属的冻结输入，连续存活窗口不足验证新实体边界。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 5. silent-proposal-578e415a259e6835


核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则

证据位置：8JRE1C4H4Z2W / F33 / T2、5、11；F17 / T6；原日志引用：decisions 270216/270282/270264；states 276433/276434。

关联原账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。

同指纹T2原/换实损3/15、敌净扣10/17；原题0/24与5/24死亡不能说同死率。护栏T5预测省12血少18伤；末T11需损15但只实扣5。

旧规则/当前实现：silent-selection-audit / silent-selection-dispatch / silent-hp-guard-audit。原文保存于 original-proposals/silent-proposal-578e415a259e6835.md；SHA256 `e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a`。

预期行为及验证方法：必须连后续状态核执行，抽弃牌即结束原候选完整性证明；保持防御换线延至T11仍失败的反例，不拟新护栏阈值。

反例/未知与本次处置：waiting。原答、护栏、SL候选快照及单动作回执已有live窄实现；仍缺跨抽弃牌、护栏与SL的完整候选执行绑定、逐来源兑现及独立后继联合校准。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 6. silent-proposal-c0767768bf6a7ab1


全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。

证据位置：YF0LXT1QSTGG / F48 / T1、5；F33成功SL反例；原日志引用：decisions 271309/271348/271354；states 277327–277373。

关联原账本：silent-0079。

同指纹原/换实损0/9、敌净扣45/38；题面预测0/10与54/36另列。换线后重问可结束回合，不把最初候选当完整实打。

旧规则/当前实现：silent-sl-comparison / silent-sl-resource-comparison / silent-selection-dispatch。原文保存于 original-proposals/silent-proposal-c0767768bf6a7ab1.md；SHA256 `28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb`。

预期行为及验证方法：固定原题、重问、被截断续步和实际净差；保留本局F33第二次SL实胜的反例，不禁止所有探索。

反例/未知与本次处置：waiting。同题预测资源差已有live展示；缺未执行续步、完整替代线资源与胜负对照及跨重问执行归属，不能由多9血少7伤校准SL惩罚。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 7. silent-proposal-a46bdb7fe711d79a


实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。

证据位置：YF0LXT1QSTGG / F48 / 末试T3–5；原日志引用：states 277512–277528；decisions 271495/271509。

关联原账本：silent-0021, silent-0027, silent-0028, silent-0085。

阶段111→212清旧毒与敌力；T5触媒2已建但毒0；5敏时已得23挡，第三小刀敏5→6不倒补；敌197→160包含消耗额外来源。

旧规则/当前实现：silent-phase-current.ts（poison_damage_already_dealt=null）；rollout阶段处理。原文保存于 original-proposals/silent-proposal-a46bdb7fe711d79a.md；SHA256 `eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6`。

预期行为及验证方法：先核本帧、已建能力与持有牌组分离；未来毒、后得敏捷和后续阶段不能记已兑现；保留已建毒雾仍败的反例。

反例/未知与本次处置：waiting。当前阶段快照和零毒说明已有live实现；缺下一轮增段、逐阶段逐来源收益及完整候选执行的联合校准，本批未找到新确定性错算。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 8. silent-proposal-1044224808015e5c


核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。

证据位置：XP2SL33HT0D9 / F33 / T1、3、第三试T4；原日志引用：decisions 271992/272040、271982/272195、272076。

关联原账本：silent-0079。

T3同指纹实损9/14、敌净扣24/27；T1实损2/10、敌净扣25/34且永久力另列。第三试T4候选21/24→23/24不是同死率。

旧规则/当前实现：sl/explore.ts现有探索规则；silent-sl-comparison已有预测快照。原文保存于 original-proposals/silent-proposal-1044224808015e5c.md；SHA256 `4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5`。

预期行为及验证方法：按独立局切分，固定相同抽牌、药瓶落点、朝向及成长；全败同局只验当轮血价，不拟全局HP惩罚常数。

反例/未知与本次处置：waiting。缺原线与换线的独立完整后继、受控随机池和整战结果；B2零胜并列不能证明低当轮损失优先的新排序更好。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 9. silent-proposal-7cbc6005db712ba9


用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。

证据位置：XP2SL33HT0D9 / F33 / 末试T2–5；原日志引用：states 278236–278261。

关联原账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。

船夹板轮初14，斗篷后20；镣铐0→−9→0；火箭57→38→28；四敏脆弱下6挡；末11HP被17−6耗尽，两敌仍153/125。

旧规则/当前实现：passive-pieces.ts:107/108；turn-solver朝向/临减力；silent-selection-audit。原文保存于 original-proposals/silent-proposal-7cbc6005db712ba9.md；SHA256 `f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291`。

预期行为及验证方法：核普通镣铐与轮初赠挡，不把当前现场值外推未见叠层；朝向/弱分别归源；需要候选级分源与执行后比对才能关闭宽项。

反例/未知与本次处置：waiting。现场值、局部公式和条件参考已有；缺逐候选贡献拆分、完整执行绑定及条件联合校准，局部实现不足以将整项登记duplicate。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 10. silent-proposal-c59f592f1427a67e


核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证

证据位置：YF0LXT1QSTGG / F48；XP2SL33HT0D9 / F33；两局前段资源链；原日志引用：四组同指纹对照，focus-state-snapshots与原复盘及18:38勘误。

关联原账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。

本批六锚点只重核本批帧；原101局统计及22次镣铐、50帧船夹板的历史结论保留为原报告，未冒称本批重验。

旧规则/当前实现：已有候选/首次回执/阶段窄模块；不等于历史分母或联合要求完成。原文保存于 original-proposals/silent-proposal-c59f592f1427a67e.md；SHA256 `81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2`。

预期行为及验证方法：不以活敌净血差代毛伤，不以SL恢复代回血；原历史分母须独立有界核验，路线/留药需完整受控后继。

反例/未知与本次处置：waiting。六锚点不覆盖原101局历史分母；仍缺逐来源资源、完整候选归属、受控路线与留药后继及独立联合校准。

回退：本批无生产更改可回退；仅CLI追加追溯，旧claim、首证、prior、证据、状态及version保留。后续代码必须单独固定数据负控/恢复与沙箱检查，再核实际live源码祖先；不从本材料推定成功上线。


## 现有实现的范围


只读live HEAD：`e716bd28fd8eca9e4d76d066680304fd11935e37`。17个所查源码文件来源均是该live祖先；11叶与live提交及工作树逐字节相同，6叶有差异。turn-solver/card-model/combat-plan还存在另批纸鹤窄规则的源码差异，rollout-live/passive-pieces/sl-explore为历史注释文字差；完整git diff --binary保存在live-base-source-diff.patch。不能因来源是祖先而声称当前整树全等。

候选快照 silent-selection-audit 的actual_turn=null，silent-selection-dispatch只有single_action_receipt且whole_plan_executed=null；HP护栏actual_outcome=null，SL比较actual_turn_result=null。silent-phase-current的poison_damage_already_dealt=null。这些明确未知保持，不填成0或已执行。

已存在阶段快照、临时减力、轮初挡、污染和成长接线，且HP/攻击按当前进阶首样本读值，房间代价门槛仍5。本批没有将这些窄接线登记成宽提案duplicate。


## 证据边界


六局run-config均记录dirty=true，变更包含当时生成知识。run-config-own.json保留实际源码commit、dirty文件清单及知识前缀指纹；前缀指纹不等于完整移动表字节。当前表不能倒充历史消费表。所有游戏断言来自本角色所列实盘帧，未读其他角色知识或游戏二进制，未使用预训练事实补缺口。

原提案中的98/99/101局、22次镣铐与50帧船夹板为原历史材料范围；本批未重验这些分母。原复盘18:38勘误单独保存在own-postmortem-correction.txt：召唤/复活下活敌净血差不能当毛伤；SL恢复不算回血，死亡实扣与完整需损分列。

全源无效JSON计数为states2/decisions2/brain1，抽取器跳过；未将无效行归因本批六局。fight-plans在当前2233957字节截点为0行，仅说明该截点没有所选局，不断言日志历史缺失。

初始派发查询误输出上层对象后已改为精确本批查询，未将其他批次内容当证据；宽输出截断和源码旧路径探针失败为材料准备记录，不登记产品bug。

旧原文及源码差异完整保留。未新增经验/结论或关闭学习父要求；经验入库、实际消费者及策略收益均未因此验收。

import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
base = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
assert not (base / 'ledger-update.stderr.txt').read_text().strip()
inputs = [json.loads(line) for line in (base / 'ledger-update-input.jsonl').read_text().splitlines()]
printed = (base / 'ledger-update.stdout.txt').read_text().split()
assert set(printed) == {i['id'] for i in inputs} and len(printed) == 30
boundary = json.loads((base / 'ledger-append-boundary.json').read_text())
path = Path(boundary['path'])
observed = path.stat().st_size
own = []
others = []
with path.open('rb') as handle:
    handle.seek(boundary['size_before'])
    offset = boundary['size_before']
    while offset < observed:
        raw = handle.readline(observed - offset)
        row = json.loads(raw)
        if '批次20261016-024301-s2-strategy-proposal，仅追加追溯；' in row.get('note', ''):
            expected = next(i for i in inputs if i['id'] == row['id'])
            assert {k: v for k, v in row.items() if k not in ('op', 'ts')} == expected
            assert row['op'] == 'update' and set(row) == {'op', 'id', 'ts', 'by', 'where', 'note'}
            own.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        else:
            others.append({'id': row.get('id'), 'offset': offset, 'sha256': hashlib.sha256(raw).hexdigest()})
        offset += len(raw)
assert len(own) == 30 and {r['row']['id'] for r in own} == set(printed)
spec = importlib.util.spec_from_file_location('own_ledger', root / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
before = json.loads((base / 'ledger-before.json').read_text())
after = copy.deepcopy(before)
for item in own:
    module.apply(after, item['row'])
for ident, entry in before.items():
    result = after[ident]
    assert {k: v for k, v in entry.items() if k not in ('notes', 'history', 'where')} == {
        k: v for k, v in result.items() if k not in ('notes', 'history', 'where')}
    assert result['notes'][:len(entry['notes'])] == entry['notes']
    assert result['history'][:len(entry['history'])] == entry['history']
    for key, paths in entry['where'].items():
        assert result['where'][key][:len(paths)] == paths
(base / 'ledger-private-fold-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
(base / 'ledger-write-readback.json').write_text(json.dumps({
    'cli_exit_code': 0, 'appended_own_rows': own, 'source_size_after': observed,
    'concurrent_other_rows': others, 'protected_fields_unchanged': True,
    'existing_where_notes_history_prefix_preserved': True,
    'scope': '只对本批所属原始CLI行作私有fold，不覆盖并行追加，不改变或重记原知识。',
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'CLI追加条数': len(own), '受保护字段不变': True, '并行其他行': len(others)}, ensure_ascii=False))

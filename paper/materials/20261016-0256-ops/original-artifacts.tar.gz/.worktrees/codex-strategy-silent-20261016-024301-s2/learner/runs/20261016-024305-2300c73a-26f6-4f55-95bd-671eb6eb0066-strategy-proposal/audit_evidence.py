import collections
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
EVIDENCE = BASE / 'evidence'


def save(name, data):
    (BASE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def explicit_identity(row):
    state = row.get('state') or {}
    fingerprint = row.get('fingerprint')
    if isinstance(fingerprint, str):
        try:
            fingerprint = json.loads(fingerprint)
        except ValueError:
            fingerprint = None
    identities = {v for v in [row.get('run_id'), row.get('run'), state.get('run_id'),
                             (fingerprint or {}).get('run') if isinstance(fingerprint, dict) else None]
                  if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(identities)) if len(identities) == 1 else None


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}


def compact(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'run': item['run_id'], 'observed_ts': row.get('observed_ts'),
            'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': run.get('current_hp'), 'combat_hp': player.get('current_hp'),
            'block': player.get('block'), 'energy': player.get('energy'),
            'played': player.get('cards_played_this_turn'), 'powers': powers(player.get('powers')),
            'enemies': [{'index': e['index'], 'id': e['enemy_id'], 'hp': e['current_hp'],
                         'max_hp': e['max_hp'], 'alive': e['is_alive'], 'block': e['block'],
                         'move': e.get('move_id'), 'powers': powers(e.get('powers')),
                         'attack': sum((a.get('damage') or 0) * (a.get('hits') or 1)
                                       for a in e.get('intents', []) if a.get('intent_type') == 'Attack')}
                        for e in combat.get('enemies') or []]}


manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
runs = json.loads((BASE / 'dispatch.json').read_text())['runs']
streams = {}
verification = []
for stream in manifest:
    name = stream['stream']
    path = EVIDENCE / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    items = []
    counts = collections.Counter()
    with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for raw in path.open():
            item = json.loads(raw)
            source.seek(item['offset'])
            original = source.read(item['bytes'])
            assert item['offset'] + item['bytes'] <= stream['source_size']
            assert hashlib.sha256(original).hexdigest() == item['sha256']
            assert json.loads(original) == item['row']
            assert explicit_identity(item['row']) == item['run_id'] in runs
            counts[item['run_id']] += 1
            items.append(item)
    assert all(counts[r] == stream['counts'][r] for r in runs)
    streams[name] = items
    verification.append({'stream': name, 'verified_rows': len(items), 'counts': dict(counts),
                         'source_size': stream['source_size'], 'output_sha256': stream['output_sha256']})
save('byte-verification.json', {'streams': verification, 'total_verified_rows': sum(len(v) for v in streams.values()),
                                 'limitations': ['仅逐字节核验所选六局；全源无效JSON计数不是六局内错误归属。',
                                                 'fight-plans零行只适用于当前截点，不推断历史日志不存在。']})

states = streams['states']
by_line = {s['line']: s for s in states}
decisions = {d['line']: d for d in streams['decisions']}
save('run-config-own.json', streams['run-config'])
save('sl-attempts-own.json', streams['sl-attempts'])

windows = {'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39}, 'CA5KE8GFJ9X2': {13},
           '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}
selected_states = [s for s in states if (s['row']['state'].get('run') or {}).get('floor') in windows[s['run_id']]]
save('focus-state-snapshots.json', [compact(s) for s in selected_states])

pairs = [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]
turn_windows = {}
for line in [v for pair in pairs for v in pair] + [270264, 272076, 271495, 271509]:
    decision = decisions[line]
    row = decision['row']
    matches = [i for i, s in enumerate(states) if s['run_id'] == decision['run_id'] and
               s['row'].get('observed_ts') == row.get('observed_ts')]
    assert len(matches) == 1, (line, matches)
    start_index = matches[0]
    start = states[start_index]
    relevant = []
    end = None
    for item in states[start_index:]:
        state = item['row']['state']
        run = state.get('run') or {}
        if item['run_id'] != decision['run_id'] or run.get('floor') != row['floor']:
            break
        relevant.append(item)
        if item != start and ((state.get('combat') or {}).get('player') or {}).get('current_hp') == 0:
            end = item
            break
        if item != start and state.get('turn') != row['turn']:
            if state.get('turn') == row['turn'] + 1 and state.get('in_combat'):
                end = item
            break
    a = compact(start)
    b = compact(end) if end else None
    enemy_before = {(e['index'], e['id'], e['max_hp']): e['hp'] for e in a['enemies']}
    enemy_after = {(e['index'], e['id'], e['max_hp']): e['hp'] for e in b['enemies']} if b else {}
    same_entities = b is not None and set(enemy_before) == set(enemy_after)
    turn_windows[str(line)] = {'decision_line': line, 'run': decision['run_id'], 'floor': row['floor'],
                              'turn': row['turn'], 'attempt': row.get('sl_attempt'),
                              'start': a, 'end': b,
                              'net_hp_loss': a['hp'] - b['hp'] if b else None,
                              'enemy_body_hp_difference': sum(enemy_before.values()) - sum(enemy_after.values()) if same_entities else None,
                              'same_entities_at_end': same_entities,
                              'full_candidate_execution_verified': None,
                              'state_lines': [s['line'] for s in relevant],
                              'sl': row.get('sl_explore'), 'answer': row.get('answers'),
                              'rationale': row.get('rationale'), 'chosen': row.get('chosen')}
save('paired-turn-windows.json', turn_windows)
comparison = []
for left, right in pairs:
    l = turn_windows[str(left)]
    r = turn_windows[str(right)]
    assert decisions[left]['row']['fingerprint'] == decisions[right]['row']['fingerprint']
    comparison.append({'decision_lines': [left, right], 'run': l['run'], 'floor': l['floor'], 'turn': l['turn'],
                       'same_fingerprint': True, 'hp_loss': [l['net_hp_loss'], r['net_hp_loss']],
                       'enemy_body_hp_difference': [l['enemy_body_hp_difference'], r['enemy_body_hp_difference']],
                       'delta_hp_loss': r['net_hp_loss'] - l['net_hp_loss'],
                       'delta_enemy_body_hp_difference': r['enemy_body_hp_difference'] - l['enemy_body_hp_difference'],
                       'sl_forecasts': r['sl'].get('numbers'),
                       'independent_complete_counterfactual': False})
save('same-fingerprint-comparisons.json', comparison)

endpoint_lines = list(range(277512, 277529)) + list(range(278236, 278261))
save('phase-crab-endpoints.json', [compact(by_line[n]) for n in endpoint_lines if n in by_line])
questions = []
for d in streams['decisions']:
    row = d['row']
    if row.get('floor') not in windows[d['run_id']]:
        continue
    if not row.get('questions') and not row.get('sl_explore'):
        continue
    questions.append({k: v for k, v in d.items() if k != 'row'} | {'row': {
        k: v for k, v in row.items() if k in ['decision_id', 'floor', 'turn', 'sl_attempt', 'questions',
                                            'answers', 'chosen', 'sl_explore', 'rationale', 'result', 'observed_ts']}})
save('focus-decisions.json', questions)
summary = {'verified_rows': sum(len(v) for v in streams.values()), 'focus_states': len(selected_states),
           'focus_decisions': len(questions), 'comparisons': comparison}
save('audit-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))

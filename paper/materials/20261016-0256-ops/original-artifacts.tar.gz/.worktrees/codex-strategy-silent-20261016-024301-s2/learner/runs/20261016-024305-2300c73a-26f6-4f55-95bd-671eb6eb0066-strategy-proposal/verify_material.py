import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
states = {s['line']: s for s in json.loads((BASE / 'focus-state-snapshots.json').read_text())}
checks = []


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'核验项': label, '实际': actual, '预期': expected})


def player(line, power):
    return states[line]['powers'].get(power, 0)


def enemy(line, ident):
    matches = [e for e in states[line]['enemies'] if e['id'] == ident]
    assert len(matches) == 1
    return matches[0]


check('八流逐字节行数', json.loads((BASE / 'byte-verification.json').read_text())['total_verified_rows'], 8274)
for pair, hp, damage in zip(json.loads((BASE / 'same-fingerprint-comparisons.json').read_text()),
                            [[3, 15], [0, 9], [9, 14], [2, 10]],
                            [[10, 17], [45, 38], [24, 27], [25, 34]]):
    check(str(pair['decision_lines']) + '指纹相同', pair['same_fingerprint'], True)
    check(str(pair['decision_lines']) + '实扣血', pair['hp_loss'], hp)
    check(str(pair['decision_lines']) + '本体净扣', pair['enemy_body_hp_difference'], damage)

check('火花3下技能/能力/技能污染', [player(n, 'TAINTED_POWER') for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6])
check('次轮火花为6', enemy(274834, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'], 6)
check('三技能污染', [player(n, 'TAINTED_POWER') for n in [274836, 274837, 274838]], [6, 12, 18])
check('下一轮污染撤除', player(274839, 'TAINTED_POWER'), 0)
check('三技能轮实际失血', states[274834]['hp'] - states[274839]['hp'], 9)
check('电击连续跨轮力量', [enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'] for n in [274308, 274313]], [2, 4])
check('电击连续跨轮攻击', [enemy(n, 'ZAPBOT')['attack'] for n in [274308, 274313]], [17, 19])
check('电击存活期间索引已重排', [enemy(n, 'ZAPBOT')['index'] for n in [274308, 274312]], [4, 3])
check('玩家总敏捷含步法来源', [player(n, 'DEXTERITY_POWER') for n in [274351, 274352, 274354]], [-4, -2, 0])
check('抢夺与失落退场后的力量', [player(n, 'STRENGTH_POWER') for n in [274351, 274358]], [-4, 0])
check('遗忘次轮又夺敏', player(274362, 'DEXTERITY_POWER'), -2)
check('末试单步法敏捷仍负', player(274392, 'DEXTERITY_POWER'), -2)
check('蚌进阶当前HP', enemy(273239, 'SEWER_CLAM')['max_hp'], 58)
check('蚌两次加压力量', [enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0) for n in [273239, 273252, 273263]], [0, 4, 8])
check('蚌喷水随现场力量', [enemy(n, 'SEWER_CLAM')['attack'] for n in [273239, 273252, 273263]], [11, 15, 19])
check('蚌最后弱攻击/挡/HP', [enemy(273268, 'SEWER_CLAM')['attack'], states[273268]['block'], states[273268]['hp']], [14, 10, 2])
check('蚌实死后敌16HP', enemy(273269, 'SEWER_CLAM')['hp'], 16)
check('沙虫死亡截顶与完整需损分开', [states[276433]['hp'], states[276433]['block'], enemy(276433, 'THE_INSATIABLE')['attack']], [5, 22, 37])
check('实验体换阶段HP', [enemy(n, 'TEST_SUBJECT')['max_hp'] for n in [277512, 277513]], [111, 212])
check('实验体换阶段清毒清力量', [enemy(277513, 'TEST_SUBJECT')['powers'].get(p, 0) for p in ['POISON_POWER', 'STRENGTH_POWER']], [0, 0])
check('零毒触媒已建', [player(277519, 'ACCELERANT_POWER'), enemy(277519, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)], [2, 0])
check('先得格挡后苦无敏捷不倒补', [[states[n]['block'], player(n, 'DEXTERITY_POWER')] for n in [277525, 277526]], [[23, 5], [23, 6]])
check('实验体整轮本体净扣37', enemy(277519, 'TEST_SUBJECT')['hp'] - enemy(277527, 'TEST_SUBJECT')['hp'], 37)
check('船夹板与斗篷格挡分列', [states[n]['block'] for n in [278236, 278240]], [14, 20])
check('普通镣铐当前与到期力量', [enemy(n, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) for n in [278236, 278237, 278242]], [0, -9, 0])
check('朝向与虚弱分开', [enemy(n, 'ROCKET')['attack'] for n in [278249, 278252, 278253]], [57, 38, 28])
check('四敏脆弱6挡', [player(278256, 'DEXTERITY_POWER'), states[278256]['block']], [4, 6])
check('蟹末轮血/挡/攻', [states[278260]['hp'], states[278260]['block'], enemy(278260, 'CRUSHER')['attack']], [11, 6, 17])
check('蟹最后两敌仍活', [e['hp'] for e in states[278261]['enemies']], [153, 125])

proposals = json.loads((BASE / 'assigned-proposals.json').read_text())
dispositions = json.loads((BASE / 'dispositions.json').read_text())
check('十个已派ID均有处置', sorted(proposals), sorted(d['id'] for d in dispositions))
for ident, proposal in proposals.items():
    raw = (BASE / 'original-proposals' / (ident + '.md')).read_bytes()
    check(ident + '原提案SHA', hashlib.sha256(raw).hexdigest(), proposal['proposal_sha256'])

source = json.loads((BASE / 'source-readback.json').read_text())
check('源码读回数量', len(source['files']), 17)
check('现有源码来源确为live祖先', all(f['source_is_live_ancestor'] for f in source['files']), True)
check('现有源码仅11叶与live同字节', sum(f['live_head_matches'] for f in source['files']), 11)
result = {'status': '通过', 'count': len(checks), 'checks': checks,
          'scope': '材料与已抽取固定帧核验，未执行生产源码、tsc或vitest，不证明整候选执行或策略收益。'}
(BASE / 'material-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'核验项数': len(checks), '结果': '通过', '生产测试': None}, ensure_ascii=False))

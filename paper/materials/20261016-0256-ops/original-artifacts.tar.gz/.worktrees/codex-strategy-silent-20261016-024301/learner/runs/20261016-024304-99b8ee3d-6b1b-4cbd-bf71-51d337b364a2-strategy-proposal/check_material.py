import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {e['line']: e['row']['state'] for e in map(json.loads, (OUT / 'evidence/states.evidence.jsonl').open())}
decisions = {e['line']: e['row'] for e in map(json.loads, (OUT / 'evidence/decisions.evidence.jsonl').open())}
checks = []


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'项目': label, '实际': actual, '期望': expected})


def player(line):
    return states[line]['combat']['player']


def enemy(line, ident):
    return next(e for e in states[line]['combat']['enemies'] if e['enemy_id'] == ident)


def power(entity, ident):
    return next((p['amount'] for p in entity['powers'] if p['power_id'] == ident), None)


def criteria(line, key):
    return json.loads(decisions[line]['questions']['plan']['criteria'][key])


check('六局身份', len(json.loads((OUT / 'run-identities.json').read_text())), 6)
check('神化前后能量', [player(n)['energy'] for n in [275679, 275680]], [7, 5])
for card in ['SUCKER_PUNCH', 'STRIKE_SILENT', 'FASTEN', 'PIERCING_WAIL']:
    check('神化后手牌升级 ' + card, all(c['upgraded'] for c in states[275680]['combat']['hand'] if c['card_id'] == card), True)
check('神化后已知抽牌升级', all(c['upgraded'] for c in states[275687]['combat']['hand']), True)
check('神化场外deck未改写', states[275679]['run']['deck'], states[275687]['run']['deck'])
check('原候选43伤14损', [criteria(269706, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']], [43, 14])
check('重问候选51伤13损', [criteria(269707, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']], [51, 13])
check('F43实盘净变化', [player(275679)['current_hp'] - player(275687)['current_hp'], enemy(275679, 'SOUL_NEXUS')['current_hp'] - enemy(275687, 'SOUL_NEXUS')['current_hp']], [13, 51])
check('F45药水后的HP未变', [player(n)['current_hp'] for n in [275728, 275731]], [67, 67])
check('F45末手牌清空', states[275732]['combat']['hand'], [])
check('SL同盘fingerprint', decisions[270216]['fingerprint'], decisions[270282]['fingerprint'])
check('SL原预测', decisions[270282]['sl_explore']['numbers']['original'], 'rollout dead 0/24, further loss 47, win ~36%; whole-fight sim win 0%; this turn hp -3, dmg 10')
check('SL替换预测', decisions[270282]['sl_explore']['numbers']['replacement'], 'rollout dead 5/24, further loss 47, win ~22%; whole-fight sim win 0%; this turn hp -15, dmg 17')
check('原首试为8样本', '8 samples' in criteria(270216, 'plan1')['rollout'], True)
audit = json.loads((OUT / 'audit-8JRE1C4H4Z2W-output.json').read_text())
for attempt, hp, damage in [(1, -3, -10), (3, -15, -17)]:
    turn = next(t for t in audit['observed_turns'] if (t['floor'], t['turn'], t['attempt']) == (33, 2, attempt))
    check('T2实盘血价 ' + str(attempt), turn['facts']['player_hp_delta'], hp)
    check('T2实盘敌血 ' + str(attempt), turn['facts']['enemy_hp_changes'][0]['hp_delta'], damage)
terminal = next(a for a in audit['observed_actions'] if a['source_line'] == 270441)['terminal_observation']
check('末轮终局端点', terminal['status'], 'observed_terminal_endpoints')
check('终局实际HP', [player(n)['current_hp'] for n in [276433, 276434]], [5, 0])
check('终局显示攻击与挡', [sum(i['total_damage'] or 0 for i in enemy(276433, 'THE_INSATIABLE')['intents']), player(276433)['block']], [37, 22])
check('终局毒后敌血', enemy(276434, 'THE_INSATIABLE')['current_hp'], 130)
for line, strength, attack in [(273237, None, 11), (273252, 4, 15), (273263, 8, 19), (273268, 8, 14)]:
    e = enemy(line, 'SEWER_CLAM')
    check('蚌成长力量 ' + str(line), power(e, 'STRENGTH_POWER'), strength)
    check('蚌意图 ' + str(line), sum(i['total_damage'] or 0 for i in e['intents']), attack)
check('蚌末帧挡与血', [player(273268)['block'], player(273268)['current_hp']], [10, 2])
check('吸取后负敏捷', power(player(273504), 'DEXTERITY_POWER'), -2)
check('负敏捷两防御', [player(n)['block'] for n in [273504, 273505, 273506, 273507]], [0, 3, 3, 6])
check('吸取后毒净扣', [enemy(n, 'LAGAVULIN_MATRIARCH')['current_hp'] for n in [273507, 273508]], [67, 34])
check('冒泡耗能', [player(n)['energy'] for n in [274379, 274380]], [5, 4])
check('冒泡未改变无毒目标', enemy(274379, 'THE_LOST'), enemy(274380, 'THE_LOST'))
check('胧光残幻象仍攻击', [enemy(273595, 'PARAFRIGHT')['current_hp'], player(273593)['current_hp'] - player(273596)['current_hp']], [2, 15])
check('胧光两实体增力', [power(enemy(273596, ident), 'STRENGTH_POWER') for ident in ['PARAFRIGHT', 'THE_OBSCURA']], [6, 6])
check('甲虫末次死亡截顶', [player(n)['current_hp'] for n in [275022, 275023]], [1, 0])
check('甲虫末次意图和挡', [sum(i['total_damage'] or 0 for i in enemy(275022, 'SLUMBERING_BEETLE')['intents']), player(275022)['block']], [22, 16])
for result in json.loads((OUT / 'audit-results.json').read_text()):
    check('离线工具退出 ' + result['run_id'], result['returncode'], 0)
    check('未认证完整候选 ' + result['run_id'], result['certified_candidates'], 0)
(OUT / 'material-checks.json').write_text(json.dumps({'检查数': len(checks), '性质': '原始材料与现有离线输出的一致性核对，不是生产测试或撤源码负控', 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'材料核对': len(checks), '全部通过': True}, ensure_ascii=False))

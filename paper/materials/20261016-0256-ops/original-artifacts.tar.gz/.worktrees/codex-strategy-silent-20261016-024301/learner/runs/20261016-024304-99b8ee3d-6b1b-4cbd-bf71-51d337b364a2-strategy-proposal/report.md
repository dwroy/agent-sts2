# 静默猎手策略提案批次报告

本批十项均waiting，未修改源码或知识，未提交、未合入live、未发布版本；fixes=[]、merged=null。逐项证据、反例、预期行为和验证要求见本目录proposal.md，原提案字节副本及SHA全部保存。没有把既有窄实现冒报为完整提案implemented或duplicate，没有新增重复id，也没有标shipped。

## 身份与范围

- batch：20261016-024301-strategy-proposal；task=strategy-proposal；character=silent。
- base/HEAD：36aab69ff879442cc6d492b2ab99b8b6bbd8853b。初始git status干净，普通任务按要求merge main返回Already up to date；没有绑定research_request或implementation_request。本批reason=proposal且明确有十个proposal_ids，根普通专题文件绑定另一旧批次，因此保持原队列任务，没有读取其他专题来代替身份。
- 六个runs均由原runs流核为SILENT/A10/败局；本批锚点没有增加新的独立对局。原日志运行代码均有dirty标记，run-config-selected.json保留当时源提交与dirty_files，不能用当前知识JSON重现旧dirty消费。
- 仅本角色原日志、关联账本、原提案及silent经验条目用于游戏结论。源码/测试只用于确认现状，不作为新增游戏事实。未启动对局、未联网、未读key/.env或游戏二进制，未另派agent。
- 当前模型原生请求未在本任务内独立核验，不凭文档配置报告切换成功；六局run-config中的历史high设置保留原状。

## 原始证据与完整性

通过共用extract_evidence.py读取显式run_id/state.run_id/fingerprint.run及run-plans.run。共8流6,995条所属记录，逐条回读source offset/bytes，核对原行SHA、JSON和唯一显式身份，另核各流输出SHA与计数，结果byte-verification.json。source_size是各流独立冻结截点，不冒称同一时刻的全日志快照。

下表列顺序为本批派发runs：VLZ6CCT8AQ0A、8JRE1C4H4Z2W、CA5KE8GFJ9X2、5PM6JAQG6FNQ、61E2QS63Y9WU、DUZUBAJ3A8GP。

| 流 | source_size字节 | VLZ | 8JRE | CA5 | 5PM | 61E | DUZ |
|---|---:|---:|---:|---:|---:|---:|---:|
| states | 13264623285 | 729 | 676 | 282 | 660 | 462 | 623 |
| decisions | 1744359882 | 699 | 659 | 265 | 638 | 443 | 602 |
| sl-attempts | 41867473 | 2 | 7 | 0 | 7 | 7 | 6 |
| run-config | 1807323 | 1 | 1 | 1 | 1 | 1 | 1 |
| run-plans | 8289102 | 8 | 6 | 2 | 7 | 4 | 6 |
| brain | 623118451 | 46 | 31 | 11 | 39 | 27 | 29 |
| runs | 340831 | 1 | 1 | 1 | 1 | 1 | 1 |
| fight-plans | 2233957 | 0 | 0 | 0 | 0 | 0 | 0 |

扫描范围内states/decisions各有2条无效JSON、brain有1条；无法据无效正文判局，不将其归给本批，也不作产品新bug。fight-plans在该截点0行只说明该截点未选中六局，不断言原日志缺失。run-plans实际33行不是0行；没有覆盖旧截点或旧零行初稿。

## 逐项处置

| 序号 | 提案 | 关联账本 | 本批处置与具体缺口 |
|---|---|---|---|
| 1 | silent-proposal-89354805ee4d7e77 | silent-0237, silent-0238 | waiting：已证升级传播已有live源码；仍缺跨重问、选牌、药水、SL与换战的实际施放持续归属，以及未覆盖属性组合的固定消费者校准，不能认证整项完成。 |
| 2 | silent-proposal-f2bfceddb1898dca | silent-0106, silent-0019, silent-0201 | waiting：缺模型覆盖完整后同起点、同随机池、同总预算的配对结果和候选稳定性曲线；707毫秒与1/12样本不足以确定新预算、药水价格或目标顺序。 |
| 3 | silent-proposal-283a164780d11e69 | silent-0237, silent-0238 | waiting：与89354805ee4d7e77共用神化证据；现有升级及参考字段未补齐实际施放持续归属和未覆盖组合，不以窄源码将该完整请求登记duplicate。 |
| 4 | silent-proposal-ebbfe3b97548756d | silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019 | waiting：当前攻防、毒与临时减力端点可核；缺十五经验全部组合及状态期限在战斗、路线、休息消费者中的冻结联合校准，未选路线与留药后继未知。 |
| 5 | silent-proposal-e5b87be50f28f311 | silent-0079, silent-0021, silent-0125, silent-0018 | waiting：已有三阶段预测、动作回执、相邻观测与整轮端点工具；本批139片段均未认证完整候选，跨重规划的持续候选归属、完整执行及成长分源仍未覆盖。 |
| 6 | silent-proposal-49632bc4878fb597 | silent-0005, silent-0231 | waiting：已核蚌力量0→4→8及喷水11→15→19、虚弱后的11/14；缺力量、正负敏捷、虚弱和独立成长四路径的冻结生产调用联合校准，本局没有正敏捷实测。 |
| 7 | silent-proposal-66532328a585941f | silent-0021, silent-0009 | waiting：已核无毒目标冒泡耗1能量且未加毒；缺同HP、构筑、药水和完整抽序下不同启动顺序的受控整战配对及可复现收益函数，不拟合启动权重。 |
| 8 | silent-proposal-43a76a31ba7bdcfa | silent-0030, silent-0027 | waiting：已核吸取、负敏捷下双防御各3挡和毒净扣33；缺A10同起始HP、构筑、药水、完整抽序的SL整战配对，首试获胜不能确定新SL范围。 |
| 9 | silent-proposal-5264153a4a4b0e5c | silent-0039, silent-0209 | waiting：已有召唤窄实现，已核两实体增力及2血幻象仍攻击；缺A10召唤、退场、再现和成长全链的冻结联合调用，以及另一focus的完整后继。 |
| 10 | silent-proposal-bddfa690a84e03d0 | silent-0128, silent-0079 | waiting：已核睡层倒计时、醒来、临减恢复和后续成长；缺伤害唤醒、眩晕、恢复成长全链的冻结联合校准及同抽换序完整后继，四次失败不确定输出血价。 |

完整证据局/层/回合及原行号见proposal.md，机器结果proposal-results.json。共用证据的两神化提案仍分别处置；已有代码和经验入库不等于这两个完整实现请求已经完成。未扩展到未派发提案或整条队列，未改根请求或旧父请求。

## 现有源码和live核验

只读live已提交HEAD截点（git show读取其提交树；不据此声称物理live工作树无dirty）：e716bd28fd8eca9e4d76d066680304fd11935e37。source-readback.json逐叶记录本树/该live提交SHA与最近含源码变更的祖先提交，并核实际base/live祖先。12个实际存在叶中10个SHA相同；card-model.ts、turn-solver.ts不同，差异同时含live已有的Paper Krane范围扩充和历史Roy/Dai注释，不能宣称只差注释、生成代码等价或整个运行树一致。原查询selection-turns.ts不存在，保留原回执并以实际selection-turn.ts补核（source-readback-supplement.json，完整源码提交e75438488df159b2e8e9d3458cf219b39aadd933、base/live均为祖先且叶SHA相同）；这是路径探针，不是产品缺陷。

已读实现包括神化已证配对、同方案与后续抽牌升级、未知保留；候选神化参考的actual_cast_this_fight仍null；三阶段选线审计与单动作回执的actual_turn/whole_plan_executed仍null；SL比较与预算成熟度字段，以及离线相邻观测/终局/整轮工具。以上只能证明对应已实现子功能，不能代替实际施放跨边界追踪、完整候选归属或策略校准。

固定源对照限定于相关路径，记录完整Git提交、叶SHA和必要binary diff；未保存整仓归档或完整checkout副本。未重跑历史源码的tsc/vitest，也不把祖先关系当作当前dirty部署全量等价。

## 离线消费者复核

使用现有learner/audit-selection.ts，输入仅为指定层冻结原行，保留真实原行号/指纹/观测时间，不重新编号。每个输入/输出/stderr SHA与退出码见audit-results.json，输入清单audit-input-manifest.json。六次工具退出均0，无被静默丢弃的无decision_id元数据。

| 局号 | 指定层 | 选线片段 | 动作 | 相邻端点 | 整轮端点 | 未知轮 | 完整候选认证 |
|---|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 35,43,45 | 14 | 99 | 0 | 0 | 15 | 0 |
| 8JRE1C4H4Z2W | 17,33 | 66 | 277 | 264 | 44 | 13 | 0 |
| CA5KE8GFJ9X2 | 13 | 4 | 26 | 0 | 0 | 5 | 0 |
| 5PM6JAQG6FNQ | 33,39 | 21 | 114 | 102 | 10 | 8 | 0 |
| 61E2QS63Y9WU | 17,23 | 12 | 60 | 27 | 5 | 7 | 0 |
| DUZUBAJ3A8GP | 30 | 22 | 117 | 112 | 17 | 7 | 0 |

总计139片段、693动作、505相邻端点、76整轮端点、55未知轮、完整候选认证0。这是有界离线消费，不是六局全历史复盘、自然live消费者验收或胜率证据。VLZ/CA5及61E部分房间的sl_attempt原为null，现有工具保守要求已知尝试号，因此端点为unknown；不填造尝试号，不由0端点断言原帧不存在。工具按设计不认证完整候选结果，0不是“所有候选实际都未执行”的证明。

本批55项材料一致性检查全过，详见material-checks.json及stdout/stderr；仅核原帧及现有离线输出，不是生产测试或撤源码负控。重点复核：神化7→5能量与F43净51伤/13损；同盘SL多付12HP只多7本轮伤且0/24≠5/24；末轮整轮敌净扣36与结束回合毒净扣24分列；玩家5→0不冒充完整15入伤；无毒冒泡耗1能量而目标状态不变；负敏捷两防御各3；残血幻象继续攻击；甲虫倒计时/临减恢复与四次尝试的predicted_death/died分列。

## 未知、拟合与下一次验证所需数据

这些发现样本不独立于原提案，没有新时间后移验证局。同盘MC预算实验尚缺固定随机池和候选稳定性曲线；15条经验的联合消费者校准、跨重规划候选持续归属、逐源成长、未选focus/路线/留药后继及完整抽序仍缺。未来应据对应缺口提供新的本角色证据或冻结生产调用，不因为队列再次派发就改阈值。保持旧策略及其他角色等价，不新增固定神化优先、SL禁线、启动权重、药水价格或集火顺序。

## 账本与交付

只经根目录learner/ledger.py update追加本批proposal/report追溯及note；既有claim、first_run、prior、evidence、status、version保留，尤其不把旧shipped窄经验降回proposed。本批没有新知识结论，不重复添加同局support/repeat，也不另建代码提案id。CLI输入、原行偏移/SHA与输出回执落本目录，最终核对保护字段。

无源码改动：tsc=null、vitest=null、cases=null；撤源码失败/恢复通过不适用。六次离线工具rc0和55项材料检查不能冒报为生产测试通过。没有源码commit、merge commit或release_id；未执行live合入章节，不制造空合入/版本/上线通知。父要求和十项waiting保留，由调度器按原队列等待后续证据；账本shipped仅由ops核实实际上线后登记。

过程保留：focused-state-endpoints-preliminary.json是在抽取完成前查看的初稿，不能用于最终计数；最终完整证据和断言以manifest/byte-verification/material-checks为准。早期宽输出截断、错误猜测core/loop.ts和selection-turns.ts路径保留为操作限制，没有据此修改产品。

账本实际回执：ledger.py update退出0，26条CLI更新已逐原行offset/bytes/SHA核实；ledger-append-receipt.json确认所有保护字段及旧追溯前缀相同。completion.json为本批机器回报。

最终检查：当前工作树git status --porcelain为空，HEAD仍为36aab69ff879442cc6d492b2ab99b8b6bbd8853b；gitleaks dir --redact扫描本批材料退出0、报告无泄漏（gitleaks.json为空数组）。本批没有生产测试、提交、合入或行为发布。

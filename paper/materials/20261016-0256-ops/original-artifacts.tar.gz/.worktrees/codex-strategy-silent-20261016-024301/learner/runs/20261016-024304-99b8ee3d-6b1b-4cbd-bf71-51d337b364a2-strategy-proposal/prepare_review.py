import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('evidence_identity', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
verified = []
for item in manifest:
    name = item['stream']
    path = OUT / f'evidence/{name}.evidence.jsonl'
    rows = []
    with path.open('rb') as selected, (Path('/home/dw/Projects/agent-sts2/logs') / f'{name}.jsonl').open('rb') as original:
        digest = hashlib.sha256()
        for raw in selected:
            digest.update(raw)
            row = json.loads(raw)
            original.seek(row['offset'])
            source = original.read(row['bytes'])
            assert row['offset'] + row['bytes'] <= item['source_size']
            assert source.endswith(b'\n')
            assert hashlib.sha256(source).hexdigest() == row['sha256']
            assert json.loads(source) == row['row']
            assert extractor.run_identity(row['row']) == row['run_id']
            rows.append(row)
        assert digest.hexdigest() == item['output_sha256']
    counts = Counter(row['run_id'] for row in rows)
    assert all(counts[run] == n for run, n in item['counts'].items())
    verified.append({'stream': name, 'rows': len(rows), 'source_size': item['source_size'], 'sha256': digest.hexdigest()})
    streams[name] = rows
save('byte-verification.json', {'verified': verified, 'total_rows': sum(r['rows'] for r in verified)})

floors = {'VLZ6CCT8AQ0A': [35, 43, 45], '8JRE1C4H4Z2W': [17, 33],
          'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [33, 39],
          '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [30]}
run_rows = {e['run_id']: e['row'] for e in streams['runs']}
excluded = []
inputs = []
for run, selected_floors in floors.items():
    assert run_rows[run]['character'] == 'SILENT' and run_rows[run]['ascension'] == 10
    decisions, states = [], []
    for e in streams['decisions']:
        r = e['row']
        if e['run_id'] != run or r.get('floor') not in selected_floors:
            continue
        if not r.get('decision_id'):
            excluded.append({'run_id': run, 'line': e['line'], 'sha256': e['sha256'], 'reason': '无decision_id的元数据，保留原证据，不送执行审计'})
            continue
        decisions.append({**r, '_line': e['line'], '_source_sha256': e['sha256']})
    for e in streams['states']:
        r = e['row']
        if e['run_id'] == run and (r['state'].get('run') or {}).get('floor') in selected_floors:
            states.append({**r, '_line': e['line'], '_source_sha256': e['sha256']})
    decisions.sort(key=lambda r: r['observed_ts'])
    name = f'audit-{run}-input.json'
    save(name, {'run': run_rows[run], 'decisions': decisions, 'states': states})
    inputs.append({'run_id': run, 'floors': selected_floors, 'decisions': len(decisions), 'states': len(states),
                   'path': str(OUT / name), 'sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()})
save('audit-input-manifest.json', {'inputs': inputs, 'excluded_metadata': excluded, 'scope': '仅指定层，不是全历史或完整实战复现'})

focused = []
for e in streams['decisions']:
    r = e['row']
    if r.get('floor') not in floors[e['run_id']]:
        continue
    if not str(r.get('label', '')).startswith('combat/plan-choice') and not r.get('sl_explore') and not r.get('hp_guard'):
        continue
    focused.append({'run_id': e['run_id'], 'source_line': e['line'], 'sha256': e['sha256'],
                    **{k: r.get(k) for k in ['decision_id', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'observed_ts', 'label',
                      'answers', 'chosen', 'expect', 'result', 'journal', 'hp_guard', 'sl_explore', 'rationale', 'questions']}})
save('focused-decisions.json', focused)
save('run-config-selected.json', [{k: e['row'].get(k) for k in ['run_id', 'code', 'brain', 'character', 'ascension']} for e in streams['run-config']])
print(json.dumps({'total_verified': sum(r['rows'] for r in verified), 'inputs': inputs, 'excluded_metadata': excluded}, ensure_ascii=False))

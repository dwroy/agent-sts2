# 静默猎手十项策略提案核验

本批只消费已领取的十个id，未扩展队列或承接其他专题。逐项证据、账本、反例、旧行为、已有覆盖与等待条件如下；本批没有证据支持新增策略参数，保留现有出牌、药水、SL、终局及路线/休息行为。

诊断事实和策略效果分别验收：现有诊断能读到局部状态，并不意味着每个原宽提案全部实现。此处没有把缺完整反事实说成诊断软件本身无法实现；本批核验的窄事实入口已经存在，新增逐来源实际归属仍需可验证的观测边界。

## silent-proposal-366288801d9150d9

处置：waiting。来源：postmortem；原领域：sl/combat；账本：silent-0079, silent-0176。

证据位置：751FN9QM9MHQ F17 T2/T7/T13。同盘T2净扣敌9→18、损血13→18；T7净扣敌12→18、损血13→23；T13扣敌17→11、损血8→2。T7双方未决弃牌的保守多计6与实际换线多付10分开。

现有覆盖：预测三阶段审计、持牌失血提示及原sl_explore.b2已在live；完整候选实际归属仍为空。

未完成与再派条件：缺SL候选实际逐来源成本、保持后继一致的整战对照及独立局验证；三组局部血价不能确定探索准入阈值。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md；SHA256：`0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`。本批已按原字节保存到`original-proposals/silent-proposal-366288801d9150d9.md`，未重写原文或新建同义id。

## silent-proposal-85929bdfc8a3fc1b

处置：waiting。来源：postmortem；原领域：combat/potion；账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。

证据位置：751FN9QM9MHQ F13 T3、F17 T7/T13/T17。F13原题选择肌肉药水线；未执行的无药抽样不当实盘。异鱼持牌惩罚与攻击分项已有提示，未决弃牌不预扣6。

现有覆盖：silent-potion-reference已标未知持有价值、无药当轮与无药整战抽样的不同范围；silent-held-loss不把模型剩余差额认作确定敌伤。

未完成与再派条件：缺无药或留至后战的完整实际分支，以及已确定敌伤与持牌损血的实际逐来源结算；成本缺表记0不等于持有价值0。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md；SHA256：`d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`。本批已按原字节保存到`original-proposals/silent-proposal-85929bdfc8a3fc1b.md`，未重写原文或新建同义id。

## silent-proposal-efd9f83ee9e1a6dc

处置：waiting。来源：experience-update；原领域：sl/combat；账本：silent-0079, silent-0176。

证据位置：751FN9QM9MHQ F17 T2/T7/T13；关联两经验。与366288同源配对，经验及复盘不是两个独立支持样本；同局六次重打仍是一局。

现有覆盖：同盘预测、持牌损血和单动作回执是现有局部覆盖；没有完整成本归属或已验证探索新规则。

未完成与再派条件：缺完整候选实际成本归属、受控整战及后期独立验证；同源经验和已上线诊断不能证明整项已实现。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md；SHA256：`0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`。本批已按原字节保存到`original-proposals/silent-proposal-efd9f83ee9e1a6dc.md`，未重写原文或新建同义id。

## silent-proposal-131042659448ae74

处置：waiting。来源：experience-update；原领域：combat/potion；账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。

证据位置：751FN9QM9MHQ F13 T3、F17 T3/T5/T7/T13/T17。九类经验分别涉及敏捷、力量/虚弱、毒、荆棘、呼唤、临时减力与资源；不能共享一个整战因果分母。

现有覆盖：已有各机制模型、持牌提示及药水未知价值说明；本批861个选线段的完整候选实际结果全部为null。

未完成与再派条件：缺敏捷、毒、荆棘及未决弃牌的完整联合消费者实际结算，以及跨战留药对照；局部组件不覆盖九类经验整项。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md；SHA256：`b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`。本批已按原字节保存到`original-proposals/silent-proposal-131042659448ae74.md`，未重写原文或新建同义id。

## silent-proposal-990f054036609447

处置：waiting。来源：experience-update；原领域：combat/sl；账本：silent-0102, silent-0019, silent-0020。

证据位置：KV0JHNJCKXLS F33 第4/5试T5及T6。决策273400/273450同指纹，均30血/敌334；原帧敌到298/305、玩家仍30，后轮毒20/13。273451另有SL阻止补打，不能把旧journal原线当最终执行。

现有覆盖：离线审计保留SL替换和续问；该两轮严格完整窗口因turn_end_unverified留未知，direct-state-cases另存真实端点，不补造候选归属。

未完成与再派条件：缺毛伤、回血与成长的完整归属、保持后继不变的整战胜线及独立验证；删输出而同零损不构成已证保血收益。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md；SHA256：`c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`。本批已按原字节保存到`original-proposals/silent-proposal-990f054036609447.md`，未重写原文或新建同义id。

## silent-proposal-e18d3f18e6cac2a0

处置：waiting。来源：postmortem；原领域：combat/potion/sl/terminal；账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。

证据位置：YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17。YQL原帧280160/280161：毒2→8，HP26/挡13/自爆41不变。巨兽本体结束与占位血、末轮死亡截断分别保留。

现有覆盖：giantPhaseAtTurnStart和silentGiantPotionFacts已分列本体0/残壳血/待自爆；enemyHpLeft与anchorRank仍按原始末轮HP破同轮平局。

未完成与再派条件：缺改序后的受控整战、完整最终资源及提前饮药结果；直接归零占位HP会改变同轮排序，阶段说明不证明排序收益。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md；SHA256：`3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`。本批已按原字节保存到`original-proposals/silent-proposal-e18d3f18e6cac2a0.md`，未重写原文或新建同义id。

## silent-proposal-9733bb80f445aeae

处置：waiting。来源：experience-update；原领域：combat/potion/sl/terminal；账本：silent-0017, silent-0019, silent-0020, silent-0250。

证据位置：YQL8RZ8BWN1E F17 T10及两旧局巨兽；关联阶段/路线/休息经验。与e18d3同源巨兽阶段证据；已有PU80过本体后存活案例，也不能把另一次胜线当新排序受控结果。

现有覆盖：阶段/毒水事实及实际最终资源的窄守卫已在live；原始路径排名保持。已存在经验的发布不是本次策略实现。

未完成与再派条件：缺阶段改序、提前用药及路线的受控验证；现有阶段子实现与同源经验不能登记整项duplicate。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md；SHA256：`c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`。本批已按原字节保存到`original-proposals/silent-proposal-9733bb80f445aeae.md`，未重写原文或新建同义id。

## silent-proposal-c51468c5e8ba6668

处置：waiting。来源：postmortem；原领域：potion；账本：silent-0019。

证据位置：KEN58SH9SLZ6 F3 T2/F4 T1/F5 T2/F11 T1/T2/F15 T1。七条use_potion请求和七组相邻原状态槽位有药→空均核回；三条请求为pending回执，另有槽位观测，不将其冒认completed。六次boss入口75/86空药栏。

现有覆盖：单动作派发审计和离线药槽观测已有；普通非SL房间因attempt为空，本入口的严格连续观测留unknown，直接药槽原帧另存。

未完成与再派条件：缺随机选牌、发光水重问后的完整候选收益归属，以及不饮用或留到Boss的完整分支；七次消耗不足拟合持有价值与跨战预算。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md；SHA256：`168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`。本批已按原字节保存到`original-proposals/silent-proposal-c51468c5e8ba6668.md`，未重写原文或新建同义id。

## silent-proposal-86a7db08d1a31976

处置：waiting。来源：postmortem；原领域：combat/sl；账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。

证据位置：KEN58SH9SLZ6 F17 第4/5试T10、第4/6试T5、第2试T2。T10同盘原/换整轮损15/21、扣敌2/4，B2 .385/.127；T5同盘省2血但步法延到T9，末线追加小刀造成重问，不能把整轮2伤当原候选1伤错误。

现有覆盖：已存在持牌预测拆项、SL前后候选和单动作回执；现有离线消费者核出整轮端点，但不认证候选或单步因果。

未完成与再派条件：缺能力建立后的完整后继、逐来源实际归属、同后轮整战对照及独立验证；不能拟统一6血/2伤准入阈值。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md；SHA256：`10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`。本批已按原字节保存到`original-proposals/silent-proposal-86a7db08d1a31976.md`，未重写原文或新建同义id。

## silent-proposal-e282a9131b99129a

处置：waiting。来源：experience-update；原领域：combat/sl；账本：silent-0021, silent-0079, silent-0125, silent-0176。

证据位置：KEN58SH9SLZ6 F17 T2/T5/T10；关联异鱼/构筑/呼唤经验。与86a7同源两组配对；省血延能力反例阻止只按最少失血排序，多付血只增2伤也不单独证明应关闭所有探索。

现有覆盖：实际整轮观测与预测分账已可消费；完整反事实与能力长期归属仍为空，不把相关重打拆成独立训练/验证局。

未完成与再派条件：缺续问后完整执行归属、受控整战和后期独立验证；省血或未试线均不足直接关闭探索、改变HP护栏。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md；SHA256：`a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`。本批已按原字节保存到`original-proposals/silent-proposal-e282a9131b99129a.md`，未重写原文或新建同义id。

## 支持、反例、未知与验证

751的T2/T7多输出付血，与T13省血少输出及KEN的T5省血却延迟步法一起看，不能从这些相关样本推出通用血价、只保血或停止更差线探索。巨兽残壳用毒只支持该帧已观察事实；提前喝药、留药或新排名的整场结果仍未知。原规则不是不可改，限制来自本批证据。

24项冻结证据一致性断言、六局现有离线入口及8,444条原字节引用校验见报告和各JSON。它们没有训练/校准新参数，没有生产源码撤除/恢复测试，没有自然采用或通关率验证。未来实现应冻结源、输入、完整后继与训练/留出局，按任务要求撤源码失败/恢复通过及原沙箱入口验证。

预期影响仅为这次证据处置可追溯；没有发布或可回退的新源码。若后续实际上线，按既有授权和live流程记录独立源码提交、版本、账本及Roy双通知。

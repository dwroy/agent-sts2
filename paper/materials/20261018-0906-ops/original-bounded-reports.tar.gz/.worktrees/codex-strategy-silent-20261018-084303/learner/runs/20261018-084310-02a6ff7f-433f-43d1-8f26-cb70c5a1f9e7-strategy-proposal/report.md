# 20261018-084303 静默猎手策略提案回报

记录时间：2026-10-18T08:55:04+08:00。

十项均为waiting。本工作树跟踪文件未变；根学习账本只经CLI补本批链接。未修改源码或知识，未提交或合入live，无新游戏版本或shipped；`fixes=[]`、`merged=null`。原提案及账本已有发布状态均保留。本批完成处置核验，不关闭任何原宽提案或科学父要求。

## 身份与基线

- task=strategy-proposal，character=silent，batch=20261018-084303-strategy-proposal，reason=proposal；工作树与本批learn.json精确相同。
- 开工git status干净；按普通批次执行`git merge --no-edit main`返回Already up to date，无冲突。
- 完整base/HEAD：`fbb38ad23ac566333b4fb664699ac34f2a0c8885`。
- learn.json明确列十个proposal_ids，无research_request、implementation_request或proposal_repair；普通专题文件绑定另一旧批，本批不符合专题，未读取其work_spec/manifest或借用另一请求。
- 取证时实际live：`cacff7cd8e8013d95aca4dffa8e791a0c3f60df1`。本批不取得live锁、不合入、不覆盖其并行统计刷新。源码身份只针对此pin；不把后续live变化当已经验证。
- 当前工具不提供原生模型/推理配置变更入口；本报告不宣称已切换或独立核实原生会话模型设置。没有子agent。

本批锚点六局：751FN9QM9MHQ、KV0JHNJCKXLS、YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN、KEN58SH9SLZ6。runs.jsonl逐行核实均为SILENT A10，均整局失败；PU80的F17局部获胜与F33整局败区分，不把六局都写成F17败。开局code均含dirty，不宣称恢复完整开局树。

## 原始证据与消费者读回

通过仓库共用extract_evidence.py抽取八流，按显式run_id/state.run_id/fingerprint.run及run-plans.run归属；冲突身份拒收，不靠正文提及。结果8444条：states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、runs6、fight-plans0。

`evidence/evidence-manifest.json`保存各流冻结source_size、计数与输出SHA；每条封套保存源路径、原行、offset、bytes和SHA。`prepare_evidence.py`再次seek原文件逐条验证字节、SHA、JSON、显式身份和计数，结果`evidence-verification.json`全真。全源有states/decisions/brain各2条坏行，不能归给本批；fight-plans在本次2233957字节截点选中0，只表示该截点没有选中本批，不断言日志缺失。未覆盖任何旧初稿或抽取报告。

冻结单局输入保留原行号与原SHA，4071条决策中6条缺decision_id或observed_ts的元数据另列排除原因，4065条动作进入现有`learner/audit-selection.ts`，不重新编号；全部4167条状态输入。各输入/输出SHA和六次实际exit0见`audit-input-manifest.json`、`audit-execution.json`。入口及所依赖四个审计库与pin live逐字相同；没有调用模型、游戏或网络，也没有读动态知识来生成计算结果。

| 局号 | 选线段 | 可核整轮端点 | 未知整轮窗口 |
|---|---:|---:|---:|
| 751FN9QM9MHQ | 96 | 83 | 46 |
| PU80F84P6HPN | 136 | 103 | 80 |
| YQL8RZ8BWN1E | 213 | 63 | 51 |
| KEN58SH9SLZ6 | 96 | 70 | 42 |
| KV0JHNJCKXLS | 92 | 31 | 83 |
| L9SGRBB5R698 | 228 | 65 | 60 |

共861个选线段，其`actual_full_candidate_result`全部null；415个窗口有整轮观测，362个窗口保持未知。已观测净变化不等于单动作因果或完整候选收益。KV F33第4/5试T5严格窗口为turn_end_unverified，另保存其可核原始状态端点334→298/305与玩家30不变；不能因通用入口保守拒绝就声称原帧不存在。KEN七次主动药水请求的7组相邻药槽变化也单独核回；其中3条pending仍原样保留，不借槽位变化冒称接口completed或完整随机药水收益。

`case-decisions.json`保留同题指纹SHA、原答、SL最终替换、B2配对值及原journal；`direct-state-cases.json`保留KV、七组药槽和巨兽用药前后原帧事实。24项材料一致性断言全通过，见`evidence-assertions.json`。特别是751 T7预测卡牌伤9/15与整轮净扣12/18分别保留，原荆棘3不混成新增6伤或保守弃牌误差。

## 逐项结论

完整逐项内容在[proposal.md](proposal.md)，每项均列源局/层/轮、原账本、支持与反例、已有覆盖、具体缺口和下一次验证条件。机器处置保存在`proposal-results.json`。两组postmortem/experience-update同源条目保留各自id，不把同源关系登记成整项duplicate，也不新建重复提案。

## silent-proposal-366288801d9150d9

处置：waiting。来源：postmortem；原领域：sl/combat；账本：silent-0079, silent-0176。

证据位置：751FN9QM9MHQ F17 T2/T7/T13。同盘T2净扣敌9→18、损血13→18；T7净扣敌12→18、损血13→23；T13扣敌17→11、损血8→2。T7双方未决弃牌的保守多计6与实际换线多付10分开。

现有覆盖：预测三阶段审计、持牌失血提示及原sl_explore.b2已在live；完整候选实际归属仍为空。

未完成与再派条件：缺SL候选实际逐来源成本、保持后继一致的整战对照及独立局验证；三组局部血价不能确定探索准入阈值。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md；SHA256：`0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`。本批已按原字节保存到`original-proposals/silent-proposal-366288801d9150d9.md`，未重写原文或新建同义id。

## silent-proposal-85929bdfc8a3fc1b

处置：waiting。来源：postmortem；原领域：combat/potion；账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。

证据位置：751FN9QM9MHQ F13 T3、F17 T7/T13/T17。F13原题选择肌肉药水线；未执行的无药抽样不当实盘。异鱼持牌惩罚与攻击分项已有提示，未决弃牌不预扣6。

现有覆盖：silent-potion-reference已标未知持有价值、无药当轮与无药整战抽样的不同范围；silent-held-loss不把模型剩余差额认作确定敌伤。

未完成与再派条件：缺无药或留至后战的完整实际分支，以及已确定敌伤与持牌损血的实际逐来源结算；成本缺表记0不等于持有价值0。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md；SHA256：`d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`。本批已按原字节保存到`original-proposals/silent-proposal-85929bdfc8a3fc1b.md`，未重写原文或新建同义id。

## silent-proposal-efd9f83ee9e1a6dc

处置：waiting。来源：experience-update；原领域：sl/combat；账本：silent-0079, silent-0176。

证据位置：751FN9QM9MHQ F17 T2/T7/T13；关联两经验。与366288同源配对，经验及复盘不是两个独立支持样本；同局六次重打仍是一局。

现有覆盖：同盘预测、持牌损血和单动作回执是现有局部覆盖；没有完整成本归属或已验证探索新规则。

未完成与再派条件：缺完整候选实际成本归属、受控整战及后期独立验证；同源经验和已上线诊断不能证明整项已实现。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md；SHA256：`0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`。本批已按原字节保存到`original-proposals/silent-proposal-efd9f83ee9e1a6dc.md`，未重写原文或新建同义id。

## silent-proposal-131042659448ae74

处置：waiting。来源：experience-update；原领域：combat/potion；账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。

证据位置：751FN9QM9MHQ F13 T3、F17 T3/T5/T7/T13/T17。九类经验分别涉及敏捷、力量/虚弱、毒、荆棘、呼唤、临时减力与资源；不能共享一个整战因果分母。

现有覆盖：已有各机制模型、持牌提示及药水未知价值说明；本批861个选线段的完整候选实际结果全部为null。

未完成与再派条件：缺敏捷、毒、荆棘及未决弃牌的完整联合消费者实际结算，以及跨战留药对照；局部组件不覆盖九类经验整项。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md；SHA256：`b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`。本批已按原字节保存到`original-proposals/silent-proposal-131042659448ae74.md`，未重写原文或新建同义id。

## silent-proposal-990f054036609447

处置：waiting。来源：experience-update；原领域：combat/sl；账本：silent-0102, silent-0019, silent-0020。

证据位置：KV0JHNJCKXLS F33 第4/5试T5及T6。决策273400/273450同指纹，均30血/敌334；原帧敌到298/305、玩家仍30，后轮毒20/13。273451另有SL阻止补打，不能把旧journal原线当最终执行。

现有覆盖：离线审计保留SL替换和续问；该两轮严格完整窗口因turn_end_unverified留未知，direct-state-cases另存真实端点，不补造候选归属。

未完成与再派条件：缺毛伤、回血与成长的完整归属、保持后继不变的整战胜线及独立验证；删输出而同零损不构成已证保血收益。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md；SHA256：`c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`。本批已按原字节保存到`original-proposals/silent-proposal-990f054036609447.md`，未重写原文或新建同义id。

## silent-proposal-e18d3f18e6cac2a0

处置：waiting。来源：postmortem；原领域：combat/potion/sl/terminal；账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。

证据位置：YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17。YQL原帧280160/280161：毒2→8，HP26/挡13/自爆41不变。巨兽本体结束与占位血、末轮死亡截断分别保留。

现有覆盖：giantPhaseAtTurnStart和silentGiantPotionFacts已分列本体0/残壳血/待自爆；enemyHpLeft与anchorRank仍按原始末轮HP破同轮平局。

未完成与再派条件：缺改序后的受控整战、完整最终资源及提前饮药结果；直接归零占位HP会改变同轮排序，阶段说明不证明排序收益。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md；SHA256：`3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`。本批已按原字节保存到`original-proposals/silent-proposal-e18d3f18e6cac2a0.md`，未重写原文或新建同义id。

## silent-proposal-9733bb80f445aeae

处置：waiting。来源：experience-update；原领域：combat/potion/sl/terminal；账本：silent-0017, silent-0019, silent-0020, silent-0250。

证据位置：YQL8RZ8BWN1E F17 T10及两旧局巨兽；关联阶段/路线/休息经验。与e18d3同源巨兽阶段证据；已有PU80过本体后存活案例，也不能把另一次胜线当新排序受控结果。

现有覆盖：阶段/毒水事实及实际最终资源的窄守卫已在live；原始路径排名保持。已存在经验的发布不是本次策略实现。

未完成与再派条件：缺阶段改序、提前用药及路线的受控验证；现有阶段子实现与同源经验不能登记整项duplicate。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md；SHA256：`c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`。本批已按原字节保存到`original-proposals/silent-proposal-9733bb80f445aeae.md`，未重写原文或新建同义id。

## silent-proposal-c51468c5e8ba6668

处置：waiting。来源：postmortem；原领域：potion；账本：silent-0019。

证据位置：KEN58SH9SLZ6 F3 T2/F4 T1/F5 T2/F11 T1/T2/F15 T1。七条use_potion请求和七组相邻原状态槽位有药→空均核回；三条请求为pending回执，另有槽位观测，不将其冒认completed。六次boss入口75/86空药栏。

现有覆盖：单动作派发审计和离线药槽观测已有；普通非SL房间因attempt为空，本入口的严格连续观测留unknown，直接药槽原帧另存。

未完成与再派条件：缺随机选牌、发光水重问后的完整候选收益归属，以及不饮用或留到Boss的完整分支；七次消耗不足拟合持有价值与跨战预算。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md；SHA256：`168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`。本批已按原字节保存到`original-proposals/silent-proposal-c51468c5e8ba6668.md`，未重写原文或新建同义id。

## silent-proposal-86a7db08d1a31976

处置：waiting。来源：postmortem；原领域：combat/sl；账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。

证据位置：KEN58SH9SLZ6 F17 第4/5试T10、第4/6试T5、第2试T2。T10同盘原/换整轮损15/21、扣敌2/4，B2 .385/.127；T5同盘省2血但步法延到T9，末线追加小刀造成重问，不能把整轮2伤当原候选1伤错误。

现有覆盖：已存在持牌预测拆项、SL前后候选和单动作回执；现有离线消费者核出整轮端点，但不认证候选或单步因果。

未完成与再派条件：缺能力建立后的完整后继、逐来源实际归属、同后轮整战对照及独立验证；不能拟统一6血/2伤准入阈值。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md；SHA256：`10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`。本批已按原字节保存到`original-proposals/silent-proposal-86a7db08d1a31976.md`，未重写原文或新建同义id。

## silent-proposal-e282a9131b99129a

处置：waiting。来源：experience-update；原领域：combat/sl；账本：silent-0021, silent-0079, silent-0125, silent-0176。

证据位置：KEN58SH9SLZ6 F17 T2/T5/T10；关联异鱼/构筑/呼唤经验。与86a7同源两组配对；省血延能力反例阻止只按最少失血排序，多付血只增2伤也不单独证明应关闭所有探索。

现有覆盖：实际整轮观测与预测分账已可消费；完整反事实与能力长期归属仍为空，不把相关重打拆成独立训练/验证局。

未完成与再派条件：缺续问后完整执行归属、受控整战和后期独立验证；省血或未试线均不足直接关闭探索、改变HP护栏。 新局须有同角色、可核原答/最终动作/续问和真实后继；改变参数时按独立局和真实时间切分，不拆SL为独立样本。当前维持规则，不新增阈值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md；SHA256：`a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`。本批已按原字节保存到`original-proposals/silent-proposal-e282a9131b99129a.md`，未重写原文或新建同义id。

## 实际live源码覆盖

以下每个last_source_commit均经`git merge-base --is-ancestor <commit> cacff7cd8e8013d95aca4dffa8e791a0c3f60df1`返回0，源blob、SHA256、字节及材料副本见`source-manifest.json`。这些是局部覆盖证明，不是本批implemented/duplicate提交。仅两个文件存在Roy/Dai归属注释差；实际逻辑相同，差异保存到`base-live-comments.patch`。其余14叶逐字相同。

| 文件 | pin live最后修改提交 | 本批base对照 |
|---|---|---|
| agent/src/reflex/silent-selection-audit.ts | `05cd292c6f01bb31e406473d3a9843e659d62b93` | 相同 |
| agent/src/reflex/silent-selection-dispatch.ts | `bade647f9fe4c9103b40e2f26b26296692ad24b7` | 相同 |
| agent/src/reflex/silent-held-loss.ts | `05cd292c6f01bb31e406473d3a9843e659d62b93` | 相同 |
| agent/src/reflex/silent-potion-reference.ts | `04921bd785ac6838066522f91ea0bb6ab95cb6a1` | 相同 |
| agent/src/reflex/silent-giant-potion.ts | `d5e20aa4dd44168ce30944dfcce74f8322144953` | 相同 |
| agent/src/reflex/potion-cost.ts | `e1a467e18a0dfa8d99046a24ff4c0e1af59278c8` | 仅Roy/Dai归属注释差 |
| agent/src/reflex/combat-plan.ts | `d959e176af7338ea2bca6f4ff9a39673b80e5fdf` | 相同 |
| agent/src/reflex/turn-solver.ts | `d959e176af7338ea2bca6f4ff9a39673b80e5fdf` | 相同 |
| agent/src/sl/attempts.ts | `0d092f6b928a6221eabf3516abad25c48ceaac9c` | 相同 |
| agent/src/sl/explore.ts | `0d092f6b928a6221eabf3516abad25c48ceaac9c` | 仅Roy/Dai归属注释差 |
| agent/src/hand/loop.ts | `ef092f1c9189bdbb549e46fd604eb342cb025bdf` | 相同 |
| learner/audit-selection.ts | `6f3f783941270ac182237c46068097ff67e85907` | 相同 |
| learner/lib/selection-execution.ts | `cf72bd21148059f111f760cc98a727369e34a47e` | 相同 |
| learner/lib/selection-observation.ts | `cf72bd21148059f111f760cc98a727369e34a47e` | 相同 |
| learner/lib/selection-turn.ts | `9b87d54f097d84521152e6cca8d6072af8140394` | 相同 |
| learner/lib/selection-terminal.ts | `04921bd785ac6838066522f91ea0bb6ab95cb6a1` | 相同 |

已有关联经验仅抽取silent自身12个条目作追溯读回，见`linked-experience.json`；其历史局数不是本批重新验证的支持样本，不由该快照新增结论或经验。根CLI只追加本批报告/提案链接与处置note，不新增support/repeat，不修改claim、first_run、asc、prior、原evidence、status、version、effect。具体回执与保护字段对照见`ledger-link-result.json`、`ledger-protected-check.json`。

## 验证、交付与限制

- 无生产源码或知识改动，tsc/vitest/cases均null；没有源码撤除/恢复过程，不冒报失败或成功。六次离线材料消费和24项材料断言单列，不充当生产测试。
- 没有新提交、merge、eval版本、行为规则通知或shipped；无新代码的merge=live条件不触发。根学习账本只经CLI追加链接，交运维后按真实处置继续等待。
- 输入覆盖本批六局，SL相关尝试不作为独立局或拆分训练/验证；没有拟合数值阈值，没有受控整战反事实或独立时间留出验证，没有自然采用/实际胜率收益断言。
- 未读其他角色知识、key、.env、游戏二进制，不联网、不运行play、不停止对局或修改调度状态/运维prompt，不提交或推送。
- 过程中的两次只读检索因假设的jev.ts/silent-selection-execution.ts路径不存在返回2；随后以rg定位真实文件，未执行任何源码修改或测试，不把它们记作产品失败。
- 保留原提案、坏行计数、严格审计未知、旧waiting历史和所有过程材料；本批重读旧局不增加独立支持N。没有发现需新登记的机制反证，原提案的双向成本反例与未知保持。

运维接收：提案`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-084303/learner/runs/20261018-084310-02a6ff7f-433f-43d1-8f26-cb70c5a1f9e7-strategy-proposal/proposal.md`；报告`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-084303/learner/runs/20261018-084310-02a6ff7f-433f-43d1-8f26-cb70c5a1f9e7-strategy-proposal/report.md`；逐项处置`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-084303/learner/runs/20261018-084310-02a6ff7f-433f-43d1-8f26-cb70c5a1f9e7-strategy-proposal/proposal-results.json`。本批无需回退新源码，后续有足够数据可沿Roy既有授权实现，不另设人定规则审批。

最终材料验收：`final-validation.json`核对本批十id、HEAD/base相等、工作树clean、输入/输出SHA和CLI保护字段；根ledger check=0，材料gitleaks exit=0/发现0。密钥扫描不代替生产测试。

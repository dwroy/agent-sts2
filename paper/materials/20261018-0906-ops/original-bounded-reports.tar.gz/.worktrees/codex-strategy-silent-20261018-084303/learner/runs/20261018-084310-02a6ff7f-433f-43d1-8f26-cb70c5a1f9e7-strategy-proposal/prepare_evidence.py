import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extractor', Path.cwd() / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
records = {}
verification = []
for entry in manifest:
    stream = entry['stream']
    file = OUT / 'evidence' / (stream + '.evidence.jsonl')
    counts = collections.Counter()
    digest = hashlib.sha256()
    rows = []
    with file.open('rb') as handle, (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as original:
        for line in handle:
            digest.update(line)
            item = json.loads(line)
            assert item['source'] == str(ROOT / 'logs' / (stream + '.jsonl'))
            assert item['offset'] + item['bytes'] <= entry['source_size']
            original.seek(item['offset'])
            raw = original.read(item['bytes'])
            assert raw.endswith(b'\n') and len(raw) == item['bytes']
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extractor.run_identity(item['row']) == item['run_id']
            assert item['run_id'] in runs
            counts[item['run_id']] += 1
            rows.append(item)
    assert digest.hexdigest() == entry['output_sha256']
    assert {run: counts[run] for run in runs} == entry['counts']
    verification.append({'stream': stream, 'selected': len(rows), 'source_size': entry['source_size'],
                         'counts': dict(counts), 'byte_sha_identity_verified': True,
                         'output_sha256': digest.hexdigest()})
    records[stream] = rows

(OUT / 'evidence-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
input_dir = OUT / 'audit-inputs'
input_dir.mkdir(exist_ok=True)
inputs = []
for run_id in runs:
    run_rows = [item for item in records['runs'] if item['run_id'] == run_id]
    assert len(run_rows) == 1
    run = run_rows[0]['row']
    assert run['character'].lower() == 'silent' and run['ascension'] == 10
    decisions = []
    states = []
    exclusions = []
    for item in records['decisions']:
        if item['run_id'] != run_id:
            continue
        row = item['row']
        if not row.get('decision_id') or not row.get('observed_ts'):
            exclusions.append({'stream': 'decisions', 'source_line': item['line'], 'sha256': item['sha256'],
                               'reason': '非动作元数据或缺少decision_id/observed_ts，保留抽取原行，不输入动作审计'})
            continue
        decisions.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    for item in records['states']:
        if item['run_id'] != run_id:
            continue
        states.append({**item['row'], '_line': item['line'], '_source_sha256': item['sha256']})
    assert len({row['decision_id'] for row in decisions}) == len(decisions)
    assert all(a['observed_ts'] <= b['observed_ts'] for a, b in zip(decisions, decisions[1:]))
    path = input_dir / (run_id + '.json')
    data = json.dumps({'run': run, 'decisions': decisions, 'states': states}, ensure_ascii=False).encode() + b'\n'
    path.write_bytes(data)
    inputs.append({'run_id': run_id, 'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(),
                   'decisions': len(decisions), 'states': len(states), 'exclusions': exclusions})
(OUT / 'audit-input-manifest.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_references': sum(x['selected'] for x in verification),
                  'inputs': [{k: v for k, v in x.items() if k != 'exclusions'} for x in inputs],
                  'excluded_metadata': sum(len(x['exclusions']) for x in inputs)}, ensure_ascii=False))

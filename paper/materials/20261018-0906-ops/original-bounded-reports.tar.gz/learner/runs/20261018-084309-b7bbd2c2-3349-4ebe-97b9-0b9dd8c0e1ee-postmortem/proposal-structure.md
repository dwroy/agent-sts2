# 宝箱接口矛盾与实际遗物确认

记录时间：2026-10-18T09:02:30+08:00。来源任务：20261018-084309-b7bbd2c2-3349-4ebe-97b9-0b9dd8c0e1ee-postmortem；实现任务：strategy-proposal；账本：silent-0516，kind=bug-infra、observed。角色／已观察范围：SILENT，A10，单人宝箱；其他角色及无矛盾状态保持原行为。

问题是接口事实相互矛盾时，代码用其中一项直接宣布处理完毕。9S9U3YSYEPK1 F10，00:22:02.927Z，states:446116：is_opened和has_relic_been_claimed均true，开心小花HAPPY_FLOWER仍在唯一relic_options，choose_treasure_relic仍可用，run.relics没有它。d157实际只发proceed，states:446117地图和后续战斗都未持有。此前NRZAYVRMM7M0 F10 20:56:17.828Z的弹珠袋BAG_OF_MARBLES（s443979→443980）及KCA04Q3SEYTF F10 21:50:31.877Z的手里剑SHURIKEN（s444419→444420）同样未发领取、离开后无遗物。时间为原日志UTC，历史两局日期为2026-10-17，本局日期为2026-10-18。首证NRZ；登记前两次同签名均直接离开，prior=no。对应原始字节/SHA和下一帧在chest-history.json、silent-chest-conflict-frames.jsonl、chest-prior-decision-refs.json和chest-prior.txt。

旧行为：取证live 9d9f5adb00766a6a3865c46b301bfd62c7ddd7da，agent/src/hand/screens/chest.ts:21的!has_relic_been_claimed将整个选遗物分支关闭，:64转proceed。源码见live-chest.ts及chest-source-manifest.json；该叶git diff为0。本局开局run-config是4eaad4c+dirty、runs.code=current，不能以后来整树替代完整开局源码。

建议的新行为：先把已持有遗物、可用领取动作和奖励选项关联，显式识别这种矛盾；在唯一未持有选项经接口契约核实仍可领取时进入既有领取流程，随后以实际持有／状态变化确认。禁止只删一个布尔守卫后无限重试；已持有不重复领，实际接口拒绝或状态仍矛盾时保留诊断和原帧，不能继续写已处理。是否需要mod适配必须由实现者核源码/固定输入，不在本任务改第三方文件。不加入遗物价值、拿牌、药水、SL或战斗策略规则。

方法、样本与时间切分：这是接口状态机修复，不拟合游戏数值。前两局作诊断输入，本局作时间上较晚的固定验证输入；三局不是三种游戏机制，更不是胜率样本。新增固定夹具覆盖正常未开箱、正常未领取、已持有、无选项、无领取动作，以及本次矛盾和领取拒绝；确认正常分支不变、不会重复或无限领取。不要运行play或联网试领。若不能证明领取动作合法，应只实现矛盾诊断与明确保留，报告限制，不能声称已补回遗物。

缺数据／反例：没有任一矛盾现场choose_treasure_relic的实际请求结果；没有拿到这三件遗物后整战实盘。不知道标记为何变true，也不能证明修后9S9U3YSYEPK1获胜。反例边界是正常已领取并实际持有的宝箱，不能由可用动作列表单独推断可以再拿一次。

验证与预期影响：固定重放应复现旧版直接proceed，新版应经过确认路径或明确诊断；不把未入包预览写成已获得。代码改动须按仓库沙箱入口tsc/vitest及gitleaks验证，再由独立实现任务走既有live流程。回退只撤该叶及其适配／夹具变更，保留账本、原始矛盾与失败日志；未知组合和其他角色保持等价。此提案仅pending，未实现、未合入、未shipped，无implemented_commit。

import json,subprocess
from pathlib import Path
p=Path(__file__).parent.resolve();root=Path('/home/dw/Projects/agent-sts2');result=json.loads((p/'ledger-result.json').read_text());bug=result['added'][0];stamp=subprocess.check_output(['date','-Iseconds'],text=True).strip()
structure=f'''# 宝箱接口矛盾与实际遗物确认

记录时间：{stamp}。来源任务：20261018-084309-b7bbd2c2-3349-4ebe-97b9-0b9dd8c0e1ee-postmortem；实现任务：strategy-proposal；账本：{bug}，kind=bug-infra、observed。角色／已观察范围：SILENT，A10，单人宝箱；其他角色及无矛盾状态保持原行为。

问题是接口事实相互矛盾时，代码用其中一项直接宣布处理完毕。9S9U3YSYEPK1 F10，00:22:02.927Z，states:446116：is_opened和has_relic_been_claimed均true，开心小花HAPPY_FLOWER仍在唯一relic_options，choose_treasure_relic仍可用，run.relics没有它。d157实际只发proceed，states:446117地图和后续战斗都未持有。此前NRZAYVRMM7M0 F10 20:56:17.828Z的弹珠袋BAG_OF_MARBLES（s443979→443980）及KCA04Q3SEYTF F10 21:50:31.877Z的手里剑SHURIKEN（s444419→444420）同样未发领取、离开后无遗物。时间为原日志UTC，历史两局日期为2026-10-17，本局日期为2026-10-18。首证NRZ；登记前两次同签名均直接离开，prior=no。对应原始字节/SHA和下一帧在chest-history.json、silent-chest-conflict-frames.jsonl、chest-prior-decision-refs.json和chest-prior.txt。

旧行为：取证live 9d9f5adb00766a6a3865c46b301bfd62c7ddd7da，agent/src/hand/screens/chest.ts:21的!has_relic_been_claimed将整个选遗物分支关闭，:64转proceed。源码见live-chest.ts及chest-source-manifest.json；该叶git diff为0。本局开局run-config是4eaad4c+dirty、runs.code=current，不能以后来整树替代完整开局源码。

建议的新行为：先把已持有遗物、可用领取动作和奖励选项关联，显式识别这种矛盾；在唯一未持有选项经接口契约核实仍可领取时进入既有领取流程，随后以实际持有／状态变化确认。禁止只删一个布尔守卫后无限重试；已持有不重复领，实际接口拒绝或状态仍矛盾时保留诊断和原帧，不能继续写已处理。是否需要mod适配必须由实现者核源码/固定输入，不在本任务改第三方文件。不加入遗物价值、拿牌、药水、SL或战斗策略规则。

方法、样本与时间切分：这是接口状态机修复，不拟合游戏数值。前两局作诊断输入，本局作时间上较晚的固定验证输入；三局不是三种游戏机制，更不是胜率样本。新增固定夹具覆盖正常未开箱、正常未领取、已持有、无选项、无领取动作，以及本次矛盾和领取拒绝；确认正常分支不变、不会重复或无限领取。不要运行play或联网试领。若不能证明领取动作合法，应只实现矛盾诊断与明确保留，报告限制，不能声称已补回遗物。

缺数据／反例：没有任一矛盾现场choose_treasure_relic的实际请求结果；没有拿到这三件遗物后整战实盘。不知道标记为何变true，也不能证明修后9S9U3YSYEPK1获胜。反例边界是正常已领取并实际持有的宝箱，不能由可用动作列表单独推断可以再拿一次。

验证与预期影响：固定重放应复现旧版直接proceed，新版应经过确认路径或明确诊断；不把未入包预览写成已获得。代码改动须按仓库沙箱入口tsc/vitest及gitleaks验证，再由独立实现任务走既有live流程。回退只撤该叶及其适配／夹具变更，保留账本、原始矛盾与失败日志；未知组合和其他角色保持等价。此提案仅pending，未实现、未合入、未shipped，无implemented_commit。
'''
combat=f'''# 9S9U3YSYEPK1 条件选线与实盘后继的固定复核

记录时间：{stamp}。来源任务：20261018-084309-b7bbd2c2-3349-4ebe-97b9-0b9dd8c0e1ee-postmortem；实现任务：strategy-proposal。范围：SILENT A10；账本silent-0020、0407、0262、0410、0011、0005。本轮只追加support，保留旧状态／首证／prior，不登记重犯或实现。

证据链：
- F6 T1预判ANTICIPATE临时2敏、双防御DEFEND_SILENT各7，14挡对16净损2，与候选一致。T3/T4/T7双尾鼠TWO_TAILED_RAT呼援后分别出现18/20/18血新体；T7候选28伤，实际血池54→44净少10含新增18，不能当单一伤害误差。全场42→12仍胜。
- F7潜水付7至5并取103金，F8实回21至26，F9胜损3、F11胜损17，F12仍只6血。HP、金币、药水、SL分别记，不能从另一未走路线或未到营火借资源。路线及用药替线未实打，不改它们的规则。
- F11 T5，10力量噬尸蛞蝓CORPSE_SLUG吞噬意图19，中和NEUTRALIZE后14，脆弱下防御3挡；实际17→6、敌27→15，候选损11/伤12兑现。T4击杀前体后余体曾STUNNED；那一轮实损0与T5意图19分开，不将新力量回推成前轮已执行攻击。
- F12 T2烟雾弥漫SMOGGY_POWER1下打NOXIOUS_FUMES能力后可打一防御，后续ANTICIPATE被该增益禁止；T4突然一拳SUCKER_PUNCH＋防御后尚余1能量，第二技能不可打。当前combat-plan.ts:3029已传maxSkills，不能冒称这条接线尚未实现。
- F12 T4 d200，60HP活雾LIVING_FOG上实际扣11、玩家零损，与即时模型一致；但模型五轮8/8结束、预计进一步损1.4，实际下一T5阵亡。T5手牌没有挡；SUCKER_PUNCH和NEUTRALIZE分别使活雾和气态炸弹GAS_BOMB9攻降6，BOUNCING_FLASK实9毒全给活雾，41→28结13毒。候选已明示未计随机新增毒，条件需损12被6HP截断，不是实际只少算／多算6；敌池净减29含退场，不等29点卡牌伤害。

原始输入与代码：207决策、214状态、11真实Codex脑、3 run-plans和资源抽取已按原字节/SHA核；参见extract-manifest.json、*-refs.jsonl、9S9U3YSYEPK1-resources.json、metrics.json和verification-after.json。当前相关源码固定live 9d9f5adb00766a6a3865c46b301bfd62c7ddd7da，五叶快照与Git blob/SHA在source-manifest.json，差分0；开局完整dirty内容未存。所有窗口按decision_id／原始时间／同局层回合关联，不能以pending_dispatch当整线成功。

旧行为与拟议新工作：既有推演选线继续保留。实现者先以固定原帧和已观察后继核同轮精确结果，再用已记录T5手牌／补体检查T4长程样本的假设；将条件数值、随机分布、实际动作、净血池变化及逐击缺口分别输出到可审计结果。核实已有吸取/敏捷/技能限额接线，无新缺口不重复实现；若发现可复现源码因果，再提出最窄修复并验证。不能仅以8/8预测后单局失败调整排序、采样常量、药水价格、SL或终局权重，也不强制先杀某目标。此提案属于combat核验，不宣称需要新游戏参数。

拟合、样本与切分：只有一个独立SILENT A10 run；同一局各回合互相关，不能作独立胜率样本。先固定本局已观察同轮作为复现集，机制排查使用账本已有本角色原局；后续新增且不用于拟合的本角色完局作为时间上向前验证。未收集受控同入口／同抽序／同预算的另一出牌顺序、早晚用药或路线结果，当前不拟合新参数，不补零或编造反例。

验证／预期影响：输出应能同时解释F6召唤补体、F11意图与实损、F12技能禁令和T5截断，且与原字节相符；若仅是随机后继差，明确记录未知并保持行为。生产代码变更必须固定夹具通过既有沙箱tsc/vitest；其他角色及未观察进阶保持等价。回退仅撤本提案实现差分，原规则保留；所有失败输入、原候选及错误抽取保留。当前未实现、未合live、未shipped，缺反事实不以旧窄实现当整项完成，无implemented_commit。
'''
items=[]
for name,md,ids,runs,domains,summary in [('structure',structure,[bug],['NRZAYVRMM7M0','KCA04Q3SEYTF','9S9U3YSYEPK1'],['structure'],'核对宝箱claimed标记、仍可领取动作与实际持有矛盾，修复直接proceed且不确认遗物的接口路径；三局首证追溯NRZ。'),('combat',combat,result['updated'],['9S9U3YSYEPK1'],['combat'],'以本局固定帧核召唤新增体、力量与烟雾技能限额、条件选线和实际后继；即时值多处兑现，单局T4预测8/8后T5死亡不足改排序或药价。')]:
 path=p/f'proposal-{name}.md';path.write_text(md);item={'character':'silent','ledger':ids,'runs':runs,'source_task':'postmortem','target_task':'strategy-proposal','domains':domains,'summary':summary,'proposal':str(path),'rule_changes':False};(p/f'proposal-{name}.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n');items.append((name,item))
proposals=[]
for name,item in items:
 print(subprocess.check_output(['date','-Iseconds'],text=True).strip(),flush=True);r=subprocess.run(['python3',str(root/'learner/code_proposals.py'),'add','--character','silent'],input=json.dumps(item,ensure_ascii=False),capture_output=True,text=True);(p/f'proposal-{name}.stdout').write_text(r.stdout);(p/f'proposal-{name}.stderr').write_text(r.stderr);print(name,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 data=json.loads(r.stdout);proposals.append(data)
(p/'proposals-result.json').write_text(json.dumps(proposals,ensure_ascii=False,indent=2)+'\n')

from pathlib import Path
import json,subprocess,hashlib,re,collections,ast,tarfile,sys,importlib.util
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261015-1612';pub=root/'paper/materials/20261015-1612-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
exec((root/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text());sys.path.insert(0,str(root/'learner'));import code_proposals
queue=code_proposals.fold(root/'paper/materials/learning/code-proposals.jsonl');batches=json.loads((root/'ops/codex-ops/learn.json').read_text())['batches'];archives=[];allowned=[]
# Original postmortem evidence and its exact append, including the learner's correction.
bid='20261015-154301';run='HLAWCGM3KHVB';out=(root/'ops/codex-ops/learner'/f'{bid}.out').read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);s=Path(report['report']).parent;b=batches[bid];assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and report['appended']==[run];assert len(report['bugs'])==1 and report['bugs'][0]['new'] is False;native=runtime(bid,report,out);counts={};refs=[];brain=[];configs=[]
for name in ['runs','decisions','states','run-plans','sl-attempts','brain','run-config']:
 n=0
 with (root/'logs'/f'{name}.jsonl').open('rb') as original,(s/f'{name}.jsonl').open() as frozen:
  for line in frozen:
   e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw);assert row==e['row'];fp=row.get('fingerprint') or {};fp=json.loads(fp) if isinstance(fp,str) else fp;ids=[v for v in [row.get('run_id'),row.get('run') if isinstance(row.get('run'),str) else None,(row.get('state') or {}).get('run_id'),((row.get('state') or {}).get('run') or {}).get('run_id'),fp.get('run')] if v is not None];assert ids and all(v==run for v in ids),(name,ids)
   if name=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
   if name=='brain':assert row['engine']=='codex' and row['model']=='gpt-6.1-sol' and row['effort']=='xhigh';brain.append(row)
   if name=='run-config':configs.append(row)
   refs.append({'stream':name,'line':e['line'],'offset':e['offset'],'bytes':e['bytes'],'sha256':sha(raw)});n+=1
 counts[name]=n
assert sum(counts.values())==1942 and counts['brain']==67 and sum(x.get('accepted') is True for x in brain)==57 and len(configs)==2
assert [x['code']['commit'] for x in configs]==['fba193dfe31844e1dbde9f2ad7174427fcd446dc','efed9b0a105c2f2c0d59089c8e938121f5ea8fc1'];assert all(x['brain']['engine']=='codex' and x['brain']['codex']['service_tier']=='default' for x in configs)
class ReadOnly(ast.NodeTransformer):
 def visit_Expr(self,node):
  call=node.value
  if isinstance(call,ast.Call) and ((isinstance(call.func,ast.Attribute) and call.func.attr=='write_text') or (isinstance(call.func,ast.Name) and call.func.id=='print')):return None
  return self.generic_visit(node)
 def visit_Try(self,node):
  self.generic_visit(node)
  if not node.handlers and not node.finalbody:node.finalbody=[ast.Pass()]
  return node
node=ReadOnly().visit(ast.parse((s/'verify.py').read_text()));ast.fix_missing_locations(node);scope={'__file__':str(s/'verify.py')};exec(compile(node,str(s/'verify.py'),'exec'),scope);old=json.loads((s/'verification.json').read_text());assert scope['checks']==old['checks'] and old['passed'] and len(old['checks'])==1999
prefix=json.loads((s/'lessons-before.json').read_text());physical=(root/'notes/lessons.md').read_bytes();part=(s/'lesson-final.md').read_bytes();assert sha(physical[:prefix['bytes']])==prefix['sha256'] and physical.count(part)==1 and part.count(b'## HLAWCGM3KHVB')==1 and len(part)==21830 and '### 勘误（2026-10-15 16:00:11 CST，learner）'.encode() in part;(p/'owned-lessons.md').write_bytes(part)
physical_rows=(root/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True);postrows=[]
for raw in physical_rows:
 v=json.loads(raw)
 if v.get('by')=='learner:postmortem' and (run in json.dumps(v,ensure_ascii=False) or str(s) in json.dumps(v,ensure_ascii=False)):
  assert v['id'] in report['ledger']['updated'] and v['op']=='update' and set(v)<=set(['op','id','ts','by','evidence','where','note']);assert all(e['run']==run for e in v.get('evidence',[]));postrows.append(raw)
assert len(postrows)==9 and sum('evidence' in json.loads(x) for x in postrows)==5;allowned+=postrows
proposals=[]
for ident in report['code_proposals']:
 v=queue[ident];assert v['character']=='silent' and v['source_task']=='postmortem' and v['runs']==[run] and sha(Path(v['proposal']).read_bytes())==v['proposal_sha256'];proposals.append({k:v.get(k) for k in ['id','state','proposal','proposal_sha256']})
queue_text=(root/'notes/fix-queue-v4.md').read_text();assert 'silent-0469' in queue_text and '聚合体' in queue_text;assert (s/'ledger-check-exit.txt').read_text().strip()=='0';post={'batch':bid,'report':report,'native':native,'stream_counts':counts,'original_rows_verified':1942,'material_assertions_reexecuted_read_only':1999,'accepted_codex_rows':57,'failed_brain_records':10,'actual_process_codes':[x['code'] for x in configs],'brain_model':'all recorded codex/gpt-6.1-sol/xhigh/default; no model substitution claimed','controlled_account_resume':'original same HLAW save at13:25, mixed account full run excluded from V5-S natural gate; original pre/post account receipts remain authoritative','old0469':'known Amalgam extension outside original Knight narrow scope, not a new blocking bug or proof of old Knight regression','new_queue_item_or_duplicate_fix':False,'proposals':proposals,'original_lesson_bytes':21830,'original_lesson_prefix':prefix,'original_ledger_rows':9,'original_T9_correction':'five following Shiv hits3 each=15 plus hook6; old draft retained; total turn29 unchanged','uncertainties':'full candidate execution, future alternatives, dirty knowledge, comparable boss clocks, pure game time, invoices remain unrecorded'};(pub/'postmortem-readback.json').write_text(json.dumps(post,ensure_ascii=False,indent=2)+'\n');(pub/'postmortem-original-references.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
for f in s.iterdir():
 if f.is_file() and f.stat().st_size<300000 and f.suffix in ['.json','.md','.py','.txt','.log','.patch'] and not f.name.startswith('ledger-'):archives.append((f,'postmortem/'+f.name))
for ext in ['out','err']:archives.append((root/'ops/codex-ops/learner'/f'{bid}.{ext}','outputs/'+bid+'.'+ext))
# No-source ordinary strategy dispositions; do not promote partial consumers to implementation.
bid='20261015-154303-s2-strategy-proposal';out=(root/'ops/codex-ops/learner'/f'{bid}.out').read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);s=Path(report['report']).parent;b=batches[bid];assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results'];assert report['fixes']==[] and report['merged'] is None and report['tests']==dict(tsc=None,vitest=None,cases=None) and report['implementation_domains']==[];assert git('-C',b['worktree'],'rev-parse','HEAD').decode().strip()==report['base'] and not git('-C',b['worktree'],'status','--porcelain','--untracked-files=all').strip();native=runtime(bid,report,out,b['worktree'])
for row in report['proposal_results']:
 v=queue[row['id']];assert row['state']==v['state']=='waiting' and sha(Path(v['proposal']).read_bytes())==v['proposal_sha256']
n=0;rawrefs=[]
for m in json.loads((s/'evidence/evidence-manifest.json').read_text()):
 count=0;digest=hashlib.sha256();by=collections.Counter()
 with (root/'logs'/f"{m['stream']}.jsonl").open('rb') as original,(s/'evidence'/f"{m['stream']}.evidence.jsonl").open('rb') as frozen:
  for raw in frozen:
   digest.update(raw);e=json.loads(raw);assert e['offset']+e['bytes']<=m['source_size'];original.seek(e['offset']);rowraw=original.read(e['bytes']);row=json.loads(rowraw);assert sha(rowraw)==e['sha256'] and row==e['row']
   if m['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
   count+=1;by[e['run_id']]+=1
 assert digest.hexdigest()==m['output_sha256'] and count==sum(m['counts'].values());n+=count;rawrefs.append({'stream':m['stream'],'rows':count,'frozen_sha256':digest.hexdigest(),'source_size':m['source_size'],'by_run':dict(by)})
assert n==8274
v=json.loads((s/'source-readback.json').read_text());assert v['base']==report['base'] and len(v['files'])==18
for row in v['files']:
 a=git('show',report['base']+':'+row['path']);z=git('show',v['live']+':'+row['path']);assert sha(a)==row['sha256'] and sha(z)==row['live_sha256'];assert (a==z)==row['same_as_live'];git('merge-base','--is-ancestor',row['live_source_commit'],v['live'])
 if a!=z:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
strategyrows=[]
for raw in physical_rows:
 row=json.loads(raw)
 if str(s) in json.dumps(row,ensure_ascii=False):assert row['op']=='update' and row['by']=='learner:strategy-proposal' and set(row)<=set(['op','id','ts','by','where','note']);strategyrows.append(raw)
assert len(strategyrows)==30;allowned+=strategyrows;(pub/'strategy-readback.json').write_text(json.dumps({'batch':bid,'report':report,'native':native,'no_change_gate_verified':True,'original_rows_verified':8274,'raw_streams':rawrefs,'source_leaf_sha_verified':18,'actual_old_source_ancestors_verified':18,'recorded_live_snapshot':v['live'],'history_comments_preserved':True,'ledger_original_rows':30,'all_ten_original_waiting':True,'no_new_source_or_version_or_production_tests':True,'partial_consumer_and_prism_material_checks_not_full_candidate_or_payoff_calibration':True,'old101_denominator_not_researched_by_six_anchors':True,'initial_schema_probes_and_TS_require_failure_preserved':True},ensure_ascii=False,indent=2)+'\n')
for f in s.iterdir():
 if f.is_file() and f.stat().st_size<300000 and f.suffix in ['.json','.md','.py','.txt','.log','.patch','.mjs','.err'] and not f.name.startswith(('ledger-before','ledger-critical-before','assigned-proposals')):archives.append((f,'strategy/'+f.name))
archives.append((s/'evidence/evidence-manifest.json','strategy/evidence/evidence-manifest.json'))
for ext in ['out','err']:archives.append((root/'ops/codex-ops/learner'/f'{bid}.{ext}','outputs/'+bid+'.'+ext))
selected=set(allowned);ordered=[x for x in physical_rows if x in selected];assert len(ordered)==39;(p/'owned-ledger.jsonl').write_bytes(b''.join(ordered));rows=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tf:
 for f,name in archives:
  raw=f.read_bytes();dest=p/'archive-scan'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tf.add(f,arcname=name);rows.append({'source':str(f.relative_to(root)),'archive':name,'bytes':len(raw),'sha256':sha(raw)})
with tarfile.open(pub/'original-artifacts.tar.gz','r:gz') as tf:
 for row in rows:assert sha(tf.extractfile(row['archive']).read())==row['sha256']
(pub/'original-artifact-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'postmortem_rows':1942,'numeric_assertions':1999,'lesson_bytes':21830,'strategy_rows':8274,'ledger_owned':39,'strategy_waiting':10,'small_artifacts':len(rows)}))

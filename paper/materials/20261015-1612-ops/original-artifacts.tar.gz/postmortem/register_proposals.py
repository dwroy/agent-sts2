import json,pathlib,subprocess
p=pathlib.Path(__file__).parent;root=pathlib.Path('/home/dw/Projects/agent-sts2');res=[]
items=[('paperkrane',['silent-0469','silent-0070'],['combat'],'纸鹤在聚合体普通突然一拳新施虚弱的A10多击/玩家易伤窗口：完整线预测18实12，扩既有骑士窄修复。',False),('finale',['silent-0110'],['combat'],'核HLAW收场F14/F16模拟优势与实际合法施放窗口，先查具名轨迹/消费者；缺证不改拿牌与估值。',False),('resources',['silent-0228'],['combat','potion','terminal'],'核HLAW首王84→77空药接第二王的联合资源及能力重置消费，缺同盘留喝后继不改药价或终局权重。',True)]
for name,ledger,domains,summary,changes in items:
 item={'character':'silent','ledger':ledger,'runs':['HLAWCGM3KHVB'],'source_task':'postmortem','target_task':'strategy-proposal','domains':domains,'summary':summary,'proposal':str((p/f'proposal-{name}.md').resolve()),'experience':[],'rule_changes':changes,'authorization':'Roy-2026-10-07-learning'}
 (p/f'proposal-{name}.json').write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n')
 r=subprocess.run(['python3',str(root/'learner/code_proposals.py'),'add','--character','silent'],input=json.dumps(item,ensure_ascii=False),text=True,capture_output=True)
 res.append({'name':name,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(p/'proposal-write-results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(name,r.returncode,r.stdout[:600],r.stderr[:500],flush=True)
 if r.returncode:raise SystemExit(r.returncode)

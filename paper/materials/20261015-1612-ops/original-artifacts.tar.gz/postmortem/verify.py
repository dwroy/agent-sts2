import json,pathlib,hashlib,collections,re,datetime
root=pathlib.Path('/home/dw/Projects/agent-sts2');p=pathlib.Path(__file__).parent;R=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
checks=[]
def ck(name,condition):
 checks.append({'check':name,'ok':bool(condition)})
 if not condition:raise AssertionError(name)
try:
 total=0
 for name,count in [('runs',1),('decisions',902),('states',953),('run-plans',13),('sl-attempts',4),('brain',67),('run-config',2)]:
  rows=R(name);ck(name+'抽取行数',len(rows)==count)
  with (root/'logs'/f'{name}.jsonl').open('rb') as f:
   for w in rows:
    f.seek(w['offset']);raw=f.read(w['bytes']);ck(name+'原字节定位'+str(w['line']),json.loads(raw)==w['row']);total+=1
 ds=R('decisions');ss=R('states');res=json.loads((p/'HLAWCGM3KHVB-resources.json').read_text());S={x['line']:x['row']['state'] for x in ss};D={x['line']:x['row'] for x in ds}
 expected=[(2,56,56,70,70),(5,42,40,70,71),(6,40,41,71,72),(7,41,26,72,73),(9,47,53,73,74),(12,53,54,74,75),(14,75,76,75,76),(15,76,77,76,77),(17,77,9,77,78),(19,64,61,78,79),(23,49,50,79,80),(24,50,41,80,81),(27,65,36,81,82),(30,60,61,82,83),(33,80,71,83,84),(35,81,77,84,85),(40,62,7,85,86),(45,57,58,86,87),(48,84,77,87,88),(49,77,0,88,88)]
 ck('20场覆盖',len(res['combats'])==20)
 for c,e in zip(res['combats'],expected):
  a,b=c['entry'],c['exit'];ck('F'+str(c['floor'])+'资源表',(c['floor'],a['hp'],b['hp'],a['max_hp'],b['max_hp'])==e and c['entry_is_turn_one'] and c['observed_net_hp_loss']==a['hp']-b['hp'])
 need={17:[324,283,262,220,181,156,145,132,110,82,53,48,22],33:[341,268,253,225,170,166,127,108,10],40:[294,224,195,182,114,74,40,29,17],48:[111,36,7,212,183,110,18,313,307,239,236,169,164,94,92,49,43],49:[630,544,509,491,487,451,403,395,381,352]}
 for f,values in need.items():
  turns={}
  for x in ss:
   st=x['row']['state'];c=st.get('combat') or {}
   if st['run']['floor']==f and c.get('enemies') and st['turn'] not in turns:turns[st['turn']]=sum(e['current_hp'] for e in c['enemies'] if e['is_alive'])
  ck('F'+str(f)+'逐轮需伤',list(turns.values())==values)
 ck('末战损41',S[410844]['run']['current_hp']-S[410845]['run']['current_hp']==41 and S[410844]['combat']['player']['block']==22)
 ck('末战入77末轮9归零',S[410788]['run']['current_hp']==77 and S[410846]['run']['current_hp']==9 and S[410847]['run']['current_hp']==0)
 ck('末战死亡前34与17挡',S[410846]['combat']['player']['block']==17 and S[410846]['combat']['enemies'][0]['intents'][0]['total_damage']==34)
 ck('末敌真实残血',[(e['enemy_id'],e['current_hp']) for e in S[410847]['combat']['enemies']]==[('TORCH_HEAD_AMALGAM',40),('QUEEN',308)])
 ck('纸鹤三步完整实际损12对预测18',D[398069]['selection_audit']['after_sl']['turn']['hp_loss']==18 and S[410807]['run']['current_hp']-S[410808]['run']['current_hp']==12 and S[410806]['combat']['enemies'][0]['intents'][0]['total_damage']==21)
 ck('收场空堆扣75',S[410460]['agent_view']['combat']['draw']==[] and S[410460]['combat']['enemies'][0]['current_hp']-S[410461]['combat']['enemies'][0]['current_hp']==75)
 ck('五刀勘误15加锁镰6',S[410839]['combat']['enemies'][0]['current_hp']==70 and [S[i]['combat']['enemies'][0]['current_hp'] for i in range(410840,410845)]==[67,58,55,52,49])
 drinks=[x['row'] for x in ds if (x['row'].get('chosen') or {}).get('action')=='use_potion'];discards=[x for x in ds if (x['row'].get('chosen') or {}).get('action')=='discard_potion'];ck('12饮0弃',len(drinks)==12 and len(discards)==0)
 gains=sum(len(set(map(tuple,x['to']['potions']))-set(map(tuple,x['from']['potions']))) for x in res['resource_changes']);ck('12瓶独立取得',gains==12)
 ck('仅一次HP护栏',len([x for x in ds if x['row'].get('hp_guard')])==1 and 'hp_guard' in D[397731])
 ck('四场首试零SL重载',all(w['row']['attempt']==1 and w['row']['reload'] is None for w in R('sl-attempts')))
 jev=[x['row'] for x in ds if x['row']['decider']=='jev'];comb=[x for x in jev if x['label'].startswith('combat/')];ck('Jev192战斗170低15',len(jev)==192 and len(comb)==170 and sum(x.get('confidence',1)<.35 for x in jev)==15)
 ck('Jev选最优双分母',collections.Counter(str(x.get('rollout_best_chosen')) for x in comb)=={'True':150,'False':10,'None':10} and sum(x.get('rollout_best_chosen') is True for x in comb if x.get('rollout',{}).get('best') is not None)==127 and len([x for x in comb if x.get('rollout',{}).get('best') is not None])==134)
 parse=lambda t:datetime.datetime.fromisoformat(t.replace('Z','+00:00'));ck('时间差',(parse(ds[-1]['row']['ts'])-parse(ds[0]['row']['ts'])).total_seconds()==12371.024)
 ck('代码自主85回合',len(set((x['row']['floor'],x['row'].get('sl_reloads'),x['row']['turn']) for x in ds if x['row']['decider']=='code' and x['row']['label'] in ['combat/plan','combat/lethal','combat/end_turn','combat/least-loss']))==85)
 before=json.loads((p/'lessons-before.json').read_text());data=(root/'notes/lessons.md').read_bytes();ck('旧复盘前缀未变',hashlib.sha256(data[:before['bytes']]).hexdigest()==before['sha256']);section=data[before['bytes']:].decode();ck('唯一标题及勘误',section.count('## HLAWCGM3KHVB')==1 and '### 勘误（2026-10-15 16:00:11 CST，learner）' in section);(p/'lesson-final.md').write_text(section)
 final={x['id']:x for x in json.loads((p/'ledger-final.json').read_text())};old=json.loads((p/'ledger-before-selected.json').read_text());ck('五个账本都有本局',set(old)<=set(final))
 for i in old:
  ck(i+'保留声明首证先验状态版本',all(old[i].get(k)==final[i].get(k) for k in ['claim','first_run','prior','status','version']))
 ck('账本check退出0',(p/'ledger-check-exit.txt').read_text().strip()=='0')
 print(json.dumps({'checks':len(checks),'all_passed':True,'original_rows_verified':total},ensure_ascii=False))
finally:
 (p/'verification.json').write_text(json.dumps({'checks':checks,'passed':all(x['ok'] for x in checks)},ensure_ascii=False,indent=2)+'\n')

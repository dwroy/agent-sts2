import json, pathlib
root=pathlib.Path('/home/dw/Projects/agent-sts2'); out=pathlib.Path(__file__).parent; run='HLAWCGM3KHVB'
for name in ['runs','decisions','run-plans','states','sl-attempts','brain','run-config']:
 p=root/'logs'/f'{name}.jsonl'
 if not p.exists(): continue
 cutoff=p.stat().st_size; offset=0; count=0
 with p.open('rb') as f, (out/f'{name}.jsonl').open('w') as dst:
  for n,line in enumerate(f,1):
   start=offset; offset+=len(line)
   if offset>cutoff: break
   if run.encode() not in line: continue
   try: row=json.loads(line)
   except ValueError: continue
   if name=='states' and (row.get('state') or {}).get('run_id',row.get('run_id'))!=run: continue
   dst.write(json.dumps({'line':n,'offset':start,'bytes':len(line),'row':row},ensure_ascii=False)+'\n'); count+=1
 print(name,count,flush=True)
dec=[json.loads(x)['row'] for x in (out/'decisions.jsonl').open()]; times=[x['ts'] for x in dec]
lo,hi=min(times),max(times); print('window',lo,hi,flush=True)
p=root/'logs/deepseek-reasoning.jsonl'; count=0
with p.open('rb') as f, (out/'deepseek-reasoning.jsonl').open('w') as dst:
 offset=0
 for n,line in enumerate(f,1):
  start=offset; offset+=len(line)
  try: row=json.loads(line)
  except ValueError: continue
  if lo<=row.get('ts','')<=hi:
   dst.write(json.dumps({'line':n,'offset':start,'bytes':len(line),'row':row},ensure_ascii=False)+'\n'); count+=1
print('reasoning',count,flush=True)

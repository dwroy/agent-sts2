import json,pathlib,collections,datetime,re
p=pathlib.Path(__file__).parent; R=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]; ds=R('decisions'); ss=R('states'); bs=R('brain')
for w in ss:
 st=w['row']['state']; c=st.get('combat') or {}; f=st['run']['floor']; t=st['turn']; av=st.get('agent_view') or {}
 cards=[x for x in c.get('hand',[]) if x['card_id']=='GRAND_FINALE'];
 if cards and f in [17,33,48,49]: print('FINALE',w['line'],f,t,[(x['playable'],x.get('unplayable_preventer_id')) for x in cards],'AV',str(av.get('draw'))[:180], 'avkeys',list(av.keys()) if f==17 and t==1 else '')
focusoffers=[]; focuses=[]
for w in ds:
 r=w['row'];
 if r['decider']!='jev' or not r['label'].startswith('combat/'):continue
 cr=(r.get('questions',{}).get('plan') or {}).get('criteria') or {}; opts={}
 for k,v in cr.items():
  try: v=json.loads(v) if isinstance(v,str) else v
  except ValueError: pass
  opts[k]=v
 if any('focus' in str(v).lower() for v in opts.values()):
  choice=(r.get('answers',{}).get('plan') or {}).get('choice'); val=opts.get(choice)
  focusoffers.append(w['line']); print('FOCUSOFFER',w['line'],r['floor'],r['turn'],choice,[(k,v.get('plays')) for k,v in opts.items() if isinstance(v,dict)],'CHOSEN',str(val)[:200])
  if 'focus' in str(val).lower(): focuses.append(w['line'])
print('FOCUSCOUNTS',len(focusoffers),len(focuses))
print('BRAIN SUM',len(bs),sum(w['row']['accepted'] for w in bs),{k:sum(w['row'].get('usage',{}).get(k,0) for w in bs) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']})
for w in bs:
 r=w['row']
 if (r['label']=='rest/plan' and r['ts']>'2026-10-15T06:20') or r['label']=='map/route-plan' or (r['label']=='event/act-plan' and r['ts']>'2026-10-15T05:50'):
  print('BRAINDETAIL',w['line'],r['label'],'qkeys',r.get('question',{}).keys(),'opttype',type(r.get('options')).__name__,'payloadkeys',r.get('payload',{}).keys() if isinstance(r.get('payload'),dict) else '', 'memkeys',r.get('memory',{}).keys() if isinstance(r.get('memory'),dict) else '')
  print('FACTS',str(r.get('payload'))[:1000])
first=ds[0]['row']['ts'];last=ds[-1]['row']['ts'];parse=lambda t:datetime.datetime.fromisoformat(t.replace('Z','+00:00'))
print('WALL',first,last,(parse(last)-parse(first)).total_seconds());print('CONFIGWALL',(parse(last)-parse(R('run-config')[0]['row']['ts'])).total_seconds())

import json,pathlib,sys,collections
p=pathlib.Path(__file__).parent
R=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=R('decisions'); s=R('states'); mode=sys.argv[1]
if mode=='keys':
 for w in [next(x for x in d if x['row']['label']=='combat/plan-choice'),next(x for x in d if x['row']['floor']==49 and x['row']['turn']==10)]:
  r=w['row']; print(w['line'],{k:v for k,v in r.items() if k!='questions'}); print('questions',list((r.get('questions') or {}).keys()));
  for k,v in (r.get('questions') or {}).items(): print(k,list(v.keys()),'state keys',list((v.get('state') or {}).keys()))
 print('state combat',s[-3]['row']['state']['combat']); print('state run',s[-3]['row']['state']['run'])
if mode=='plans':
 for w in R('run-plans'): print(w['line'],json.dumps(w['row'],ensure_ascii=False))
if mode=='turns':
 floor=int(sys.argv[2]); frames=[x for x in s if x['row']['state']['run']['floor']==floor]
 by=collections.defaultdict(list)
 for w in frames:
  st=w['row']['state']; c=st.get('combat');
  if c and c.get('enemies'): by[st['turn']].append(w)
 for turn,rows in by.items():
  for label,w in [('START',rows[0]),('END',rows[-1])]:
   st=w['row']['state']; c=st['combat']; r=st['run'];
   print(label,w['line'],w['row']['ts'],'T',turn,'hp',r['current_hp'],'player',c.get('player'),'enemies',c.get('enemies'))
  for w in d:
   r=w['row'];
   if r['floor']==floor and r['turn']==turn: print('D',w['line'],r['ts'],r['label'],r['chosen'],r['rationale'], 'journal',r.get('journal'))
if mode=='changes':
 res=json.loads((p/'HLAWCGM3KHVB-resources.json').read_text())
 for x in res['resource_changes']:
  a,b=x['from'],x['to']; print('C',a['line'],b['line'],'F',b['floor'],'T',b['turn'], 'hp',a['hp'],b['hp'],'max',a['max_hp'],b['max_hp'],'pot',a['potions'],b['potions'])
if mode=='brain':
 for w in d:
  r=w['row']
  if r['decider']=='codex': print(w['line'],'F',r['floor'],r['label'],r['chosen'],r['rationale'])
if mode=='sl':
 for w in R('sl-attempts'):
  r=w['row']; print(w['line'],{k:v for k,v in r.items() if k not in ['summary','draw_trace','draw_knowledge','state','decisions','turns']}); print('summary',r.get('summary'))

import json,pathlib,collections,re,datetime
p=pathlib.Path(__file__).parent; R=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]; ds=R('decisions'); ss=R('states')
d=[w['row'] for w in ds]; jev=[r for r in d if r['decider']=='jev']; combat=[r for r in jev if r['label'].startswith('combat/')]
print('JEV',len(jev),'combat',len(combat),'low',sum(isinstance(r.get('confidence'),(float,int)) and r['confidence']<.35 for r in jev),'lowcombat',sum(isinstance(r.get('confidence'),(float,int)) and r['confidence']<.35 for r in combat))
print('BEST',collections.Counter(str(r.get('rollout_best_chosen')) for r in combat)); ranks=[int(m.group(1)) for r in combat if (m:=re.search(r'code rank (\d+)',r['rationale']))]; print('RANK1',ranks.count(1),len(ranks))
for f in [17,33,40,48,49]:
 rows=[r for r in combat if r['floor']==f];print('BEST FLOOR',f,collections.Counter(str(r.get('rollout_best_chosen')) for r in rows),'low',sum(r.get('confidence',1)<.35 for r in rows))
print('ALLDEC',collections.Counter(r['decider'] for r in d)); print('JEVPLAN',sum('Jev-chosen' in r['rationale'] for r in d))
auto=[r for r in d if r['decider']=='code' and r['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]; print('AUTO',len(auto),collections.Counter(r['label'] for r in auto),'turnwindows',len(set((r['floor'],r.get('sl_reloads'),r['turn']) for r in auto)))
for w in ds:
 r=w['row'];
 if any(k in r for k in ['hp_guard','hp_guard_replacement']) or re.search(r'HP.guard|hp.guard|血量护栏|保血',r['rationale'],re.I): print('GUARD',w['line'],r['rationale'],r.get('hp_guard'))
 if (r.get('expect') or {}).get('card',{}).get('id')=='GRAND_FINALE': print('FINALEPLAY',w['line'],r['floor'],r['turn'],r['chosen'],r['rationale'])
 if r['chosen'] and (r['chosen'].get('action') in ['use_potion','discard_potion']): print('POTION',w['line'],r['floor'],r['turn'],r['chosen'],r.get('expect'),r['result'])
 if 'focus' in r['rationale'].lower(): print('FOCUS',w['line'],r['floor'],r['turn'],r['rationale'])
print('TOK JEV', {k:sum(r.get('usage',{}).get(k,0) for r in jev) for k in ['input_tokens','output_tokens']})
print('BRAIN example',[(w['line'],list(w['row'].keys())) for w in R('brain')[:2]])
for f in [17,33,40,48,49]:
 by=collections.defaultdict(list)
 for w in ss:
  st=w['row']['state'];
  if st['run']['floor']==f and (st.get('combat') or {}).get('enemies'): by[st['turn']].append(w)
 for t,ws in by.items():
  st=ws[0]['row']['state'];end=ws[-1]['row']['state']; hp=lambda s:sum(e['current_hp'] for e in s['combat']['enemies'] if e['is_alive']); print('TURN',f,t,'need',hp(st),'lastenemy',hp(end),'hp',st['run']['current_hp'],end['run']['current_hp'],'piles', {k:len(st['combat'].get(k,[])) for k in ['draw_pile','discard_pile','hand']})

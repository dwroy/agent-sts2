import json,pathlib,collections
p=pathlib.Path(__file__).parent
read=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=read('decisions'); s=read('states'); res=json.loads((p/'HLAWCGM3KHVB-resources.json').read_text())
print('DEC EXAMPLE',json.dumps(d[0],ensure_ascii=False)[:4500])
print('STATE KEYS',s[0]['row'].keys(),s[0]['row']['state'].keys())
print('COUNTS',collections.Counter((x['row'].get('label'),x['row'].get('decider')) for x in d))
for c in res['combats']:
 print('COMBAT',c['sequence'],c['floor'],c['enemies'],'entry',c['entry'],'last',c['last'],'exit',c['exit'],'loss',c['observed_net_hp_loss'])
for f in ['run-config','run-plans','sl-attempts']:
 for w in read(f):
  r=w['row']; print(f,w['line'],json.dumps(r,ensure_ascii=False)[:(3500 if f=='run-plans' else 1300)])
for name in ['queen','knight','clock']:
 rows=json.loads((p/('ledger-'+name+'.json')).read_text()); print('LEDGER',name,len(rows))
 for r in rows: print(r['id'],r['status'],r.get('version'),r['claim'][:450])

import json,pathlib,collections,re,datetime,hashlib,subprocess
p=pathlib.Path(__file__).parent;R=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
ds=R('decisions');ss=R('states');bs=R('brain')
for w in bs:
 r=w['row'];pay=r.get('payload') or {};f=(pay.get('situation') or {}).get('floor') or (pay.get('run_brief') or {}).get('floor')
 if r['label'] in ['map/route-plan','event/act-plan','rest/plan'] and str(f) in ['1','16','34','42','44','47']:
  facts=pay.get('facts') or {};print('FACTS',w['line'],f,r['label'],'keys',list(facts.keys()))
  for k,v in facts.items():
   if 'clock' in k or 'route' in k: print(k,str(v)[:2400])
  for k,v in (r.get('options') or {}).items():
   try:v=json.loads(v) if isinstance(v,str) else v
   except:continue
   if isinstance(v,dict) and v.get('kind')=='HEAL': print('HEAL',k,v.get('boss_sim_hp_reference'))
for w in ds:
 if w['line'] in [397392,397420,397731,398069]:
  r=w['row'];print('D',w['line'])
  if w['line']==397731:print('GUARD',r['hp_guard'])
  for k,v in (r.get('questions',{}).get('pick') or {}).get('criteria',{}).items():
   v=json.loads(v)
   if '华丽收场' not in str(v):continue
   q=v.get('quantitative_fight',{});print('FINALEOPT',k,'boss_sim',v.get('boss_sim'),'DPR',q.get('effective_damage_per_turn'),'core',q.get('core_window',{}).get('valid'))
for f in [17,33,48,49]:
 rows=[w for w in ss if w['row']['state']['run']['floor']==f];fin=[(w, c) for w in rows for c in (w['row']['state'].get('combat') or {}).get('hand',[]) if c['card_id']=='GRAND_FINALE'];print('FINFRAMES',f,len(fin),sum(c['playable'] for w,c in fin))
combat=[w['row'] for w in ds if w['row']['decider']=='jev' and w['row']['label'].startswith('combat/')];valid=[r for r in combat if r.get('rollout',{}).get('best') is not None];print('BEST_DEFINED',len(valid),sum(r.get('rollout_best_chosen') is True for r in valid))
for w in ss:
 if w['line'] in [410133,410149,410458,410808,410826]:
  arr=w['row']['state']['agent_view']['combat']['draw'];n=sum(int(m.group(1)) if (m:=re.search(r'\*(\d+)',x['line'].split(' [')[0])) else 1 for x in arr);print('DRAW',w['line'],n)
print('CACHE_PERCENT',5197056/11618785*100)

import json,pathlib,sys,collections
p=pathlib.Path(__file__).parent; floor=int(sys.argv[1]); read=lambda n:[json.loads(l) for l in (p/(n+'.jsonl')).open()]
s=read('states'); d=read('decisions'); by=collections.defaultdict(list)
for w in s:
 st=w['row']['state'];
 if st['run']['floor']==floor and (st.get('combat') or {}).get('enemies'): by[st['turn']].append(w)
for t,rs in by.items():
 for label,w in [('START',rs[0]),('END',rs[-1])]:
  st=w['row']['state']; c=st['combat']; print(label,'s'+str(w['line']),w['row']['ts'],'T'+str(t),'HP',st['run']['current_hp'],'B/E',c['player']['block'],c['player']['energy'],'P',[(x['power_id'],x['amount']) for x in c['player']['powers']]);
  for e in c['enemies']: print(' enemy',e['index'],e.get('name'),e['enemy_id'],e['current_hp'],e['max_hp'],'block',e.get('block'),'powers',[(x['power_id'],x['amount']) for x in e.get('powers',[])],'intent',e.get('intents'),e.get('move_id'))
 for w in d:
  r=w['row']
  if r['floor']==floor and r['turn']==t:
   a=r.get('selection_audit') or {}; v=(a.get('after_sl') or {}).get('turn'); print(' d'+str(w['line']),r['label'],r.get('expect'),r['rationale'],'PRED',v)

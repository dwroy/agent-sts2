import json,pathlib,subprocess
p=pathlib.Path(__file__).parent;run='HLAWCGM3KHVB';root=pathlib.Path('/home/dw/Projects/agent-sts2'); entries={}
for name in ['finale-cn','weak','queen','footwork','paperkrane']:
 for row in json.loads((p/f'ledger-{name}.json').read_text()): entries[row['id']]=row
ids=['silent-0110','silent-0469','silent-0228','silent-0005','silent-0070'];(p/'ledger-before-selected.json').write_text(json.dumps({i:entries[i] for i in ids},ensure_ascii=False,indent=2)+'\n')
E=lambda floor,turn,note,role='support':{'run':run,'floor':floor,'turn':turn,'role':role,'note':note}
updates=[
 {'id':'silent-0110','evidence':[E(17,4,'F14拿收场、F16升级后，F17共19个持牌帧均不可打；s410133/T1与410149/T4抽堆13/15张，13轮77→9；F14 1000样本core_window有效125，不等完整成型或施放率。'),E(33,8,'全局唯一收场施放d397740，s410460→410461空抽堆，沙虫104→29实75伤；F48/F49持收场帧17/6均不可打。')]},
 {'id':'silent-0469','evidence':[E(49,3,'纸鹤在场，d398069狩猎→女王/突然一拳→聚合体/致命毒药→女王三步完整执行；s410805→410806新虚弱使12×3→7×3，轮末9挡，s410807→410808实71→59损12，模型18高报6。现有骑士窄修复不涵盖此多击/玩家易伤/突然一拳组合，属原缺口扩展而非已修骑士回归；current turn-solver.ts:2966、:2956，combat-plan.ts:776与efed续跑分支同。','repeat')]},
 {'id':'silent-0228','evidence':[E(40,5,'三骑士虽赢62/85→7/86；T5 52总攻18挡损34，后续三营火实回25/25/26，不能把赢战略去或反事实留药当胜局。'),E(48,1,'84/87带槽0再生和槽1虚弱进场，d397928/397929均T1实饮；再生实际HP增量T1+3/T5+1，T4损12、芝士+1，17轮后77/88空药。'),E(49,10,'s410788以77/88空药直接接第二王，首王已建6敏捷不继承；T9损41至9，T10防御后17挡对34攻实死，毒后女王308/419、聚合体40/211；无留药或另一杀序受控后场实果。')]},
 {'id':'silent-0005','evidence':[E(49,9,'s410836→410837第二步法+使敏捷3→6，脆弱93时斗篷+现场挡6→9，s410838→410839实8→17；之后五小刀各触发1挡到22，对63攻仍损41。不是已持有等于已建立。')]},
 {'id':'silent-0070','evidence':[E(49,3,'普通突然一拳新施1虚弱使聚合体12×3→7×3，纸鹤实少15来袭；9挡实损12。T4尖啸临时力量1→−5、攻击25→16，T5力量恢复并到2，不能预支后轮减力。')]}
]
results=[]
for u in updates:
 u.update(by='learner:postmortem',where={'lessons':[run]},note='本次只追加HLAWCGM3KHVB直接证据及复盘去向；原claim、首证、prior、status、version保持。单局、条件模型与受控胜负分账，T9逐刀数字以追加勘误为准。')
 (p/(u['id']+'-update.json')).write_text(json.dumps(u,ensure_ascii=False,indent=2)+'\n')
 r=subprocess.run(['python3',str(root/'learner/ledger.py'),'update'],input=json.dumps(u,ensure_ascii=False),text=True,capture_output=True)
 results.append({'id':u['id'],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});print(u['id'],r.returncode,r.stdout[:300],flush=True)
 (p/'ledger-write-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)

import json,pathlib
p=pathlib.Path(__file__).parent.resolve(); ids=[x['stdout'].strip() for x in json.loads((p/'proposal-write-results.json').read_text())];updated=['silent-0110','silent-0469','silent-0228','silent-0005','silent-0070'];v=json.loads((p/'verification.json').read_text());assert v['passed'];check=int((p/'ledger-check-exit.txt').read_text());assert check==0
result={'task':'postmortem','appended':['HLAWCGM3KHVB'],'skipped':[],'bugs':[{'run':'HLAWCGM3KHVB','where':'agent/src/reflex/turn-solver.ts:2966','what':'已有纸鹤新施虚弱模型缺口扩展至聚合体：F49T3完整线预测损18，实际损12；原骑士窄修复没有覆盖该组合。','new':False}],'ledger':{'added':[],'updated':updated,'repeats':['silent-0469'],'check':check},'code_proposals':ids,'implementation_domains':['combat','potion','terminal'],'report':str(p/'report.md')}
(p/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
body='''## 复盘回报
- 已追加：HLAWCGM3KHVB（A10，第49层，女王／聚合体T10阵亡；已补T9伤害勘误）
- 新的纯 bug（file:line，每条一行；没有写「无」）：
  - 无。已有silent-0469补证：纸鹤聚合体新施虚弱场景预测损18、实损12 — agent/src/reflex/turn-solver.ts:2966（fix-queue-v4.md:1256已有根因，原骑士窄修复之外）。
- 写成「未记录」的项：HLAWCGM3KHVB：完整候选兑现率、逐击毛伤／过量伤、末轮水盆独立触发帧、留药／另一杀序的受控后场实果、校准boss时钟与可比时钟比、纯游戏耗时、Jev缓存／实付账单、开局动态知识完整字节。
- 学习账本：HLAWCGM3KHVB：新增无；更新silent-0110、silent-0469、silent-0228、silent-0005、silent-0070（老错silent-0469）；ledger.py check退出码0。
- 代码提案（来源均postmortem，实现均独立strategy-proposal）：
  - '''+ids[0]+'''：F49T3／silent-0469、0070；纸鹤窄场景扩展，有完整同线证据，无独立留出或整场转胜证据。
  - '''+ids[1]+'''：F14／16／17／33／silent-0110；收场合法施放轨迹与消费核验，未定位新bug，不强改拿牌。
  - '''+ids[2]+'''：F40→F48→F49／silent-0228；两战资源与能力重置消费，缺同盘留／喝后场对照，保持原药价与终局权重。

```json
'''+json.dumps(result,ensure_ascii=False)+'''
```

原件与核验：runs:784；两原配置fba193dfe31844e1dbde9f2ad7174427fcd446dc／efed9b0a105c2f2c0d59089c8e938121f5ea8fc1分列，引用源码冻结于live9de6d107c5dad20095a37e33695f8c18a963d081。1942原行逐offset/bytes/JSON读回相同，1999项材料核验全通过，见verification.json。resource-summary.json与HLAWCGM3KHVB-resources.json覆盖全部20战；五条账本保留原claim、first_run、prior、status、version。gitleaks目录扫描退出0、未见泄漏。仅修改授权记录与本scratch，不改代码、不提交、不推送，不登记implemented/shipped。

勘误说明：复盘先追加正文，再按规则只追加勘误；F49T9后五刀实际各3，共15，另锁镰6，总推进21，第一刀另3、轮末毒5使全轮推进29。原五刀各4写法错误已勘误；总推进29、损41与死亡回合仍正确。125/1000只是core_window有效兑现审计数，不是完整成型或收场施放率。旧正文前缀SHA验证保持不变。

材料限制与保留：extract.py按原始日志流式筛本局；inspect-overview.py保留了早期草稿，原名inspect.py曾与Python标准库模块同名导致审计输出混入概览，已改名保留原稿；audit.txt的早期局部输出和其余初稿均保留。最终判断以compact_audit.txt、原JSON、verification.json及lesson-final.md为准，不把草稿重复输出当额外样本。本复盘没有运行模型或实盘、没有改学习要求父项状态。
'''
(p/'report.md').write_text(body)
print(json.dumps({'report':str(p/'report.md'),'code_proposals':ids,'ledger_check':check,'verification_checks':len(v['checks'])},ensure_ascii=False))

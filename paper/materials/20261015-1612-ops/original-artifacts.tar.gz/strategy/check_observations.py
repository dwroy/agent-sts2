import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
data = json.loads((OUT / 'relevant-state-summaries.json').read_text())
frames = {r['line']: r for rows in data.values() for r in rows}
checks = []


def record(name, lines, check, result):
    assert check, name
    checks.append({'name': name, 'source_state_lines': lines, 'matches': True,
                   'observations': result})


def enemy(line, id=None):
    values = frames[line]['enemies']
    return values[0] if id is None else next(e for e in values if e['id'] == id)


def attack(e):
    return sum(i.get('total_damage') or 0 for i in e['intents'] or [])


prism_lines = [274830, 274831, 274832, 274833, 274834, 274836, 274837, 274838, 274839]
tainted = [frames[n]['player_powers'].get('TAINTED_POWER', 0) for n in prism_lines]
record('感染棱柱污染、能力不重复污染及下一轮重读', prism_lines,
       tainted == [0, 3, 3, 6, 0, 6, 12, 18, 0], tainted)
clam_lines = [273237, 273252, 273254, 273263, 273268, 273269]
clam_attacks = [attack(enemy(n)) for n in clam_lines]
record('喷水成长与虚弱现场数值、末帧死亡截断', clam_lines,
       clam_attacks == [11, 15, 11, 19, 14, 14] and frames[273269]['hp'] == 0,
       {'attacks': clam_attacks, 'last_positive_hp': frames[273268]['hp'],
        'last_block': frames[273268]['block'], 'uncapped_actual_loss': None})
zap_lines = [274308, 274312, 274313]
zap = [enemy(n, 'ZAPBOT') for n in zap_lines]
record('高电压观测数值与索引变化分别保存', zap_lines,
       [attack(e) for e in zap] == [17, 17, 19] and
       [e['powers']['STRENGTH_POWER'] for e in zap] == [2, 2, 4],
       {'indexes': [e['index'] for e in zap], 'max_hp': [e['max_hp'] for e in zap],
        'native_instance_id': None, 'summon_generation_verified': False})
lost_lines = [274351, 274352, 274354, 274357, 274358, 274362]
lost = [frames[n]['player_powers'] for n in lost_lines]
record('抢夺、两步法、失落退出和后续负敏分列', lost_lines,
       [p.get('STRENGTH_POWER', 0) for p in lost] == [-4, -4, -4, -4, 0, 0] and
       [p.get('DEXTERITY_POWER', 0) for p in lost] == [-4, -2, 0, 0, 0, -2],
       {'strength': [p.get('STRENGTH_POWER', 0) for p in lost],
        'dexterity': [p.get('DEXTERITY_POWER', 0) for p in lost],
        'possession_power_amount_at_274351': enemy(274351, 'THE_LOST')['powers']['POSSESS_STRENGTH_POWER'],
        'per_source_return_ownership': None})
phase_lines = [277512, 277513, 277518, 277524, 277526]
record('实验体阶段、触媒零毒和后来敏捷不倒补既有挡', phase_lines,
       enemy(277512)['hp'] == 4 and enemy(277513)['max_hp'] == 212 and
       enemy(277513)['powers'].get('POISON_POWER', 0) == 0 and
       frames[277518]['player_powers']['ACCELERANT_POWER'] == 2 and
       frames[277524]['block'] == frames[277526]['block'] == 23 and
       [frames[n]['player_powers']['DEXTERITY_POWER'] for n in [277524, 277526]] == [5, 6],
       {'phase_hp': [enemy(n)['hp'] for n in [277512, 277513]],
        'block': [frames[n]['block'] for n in [277524, 277526]],
        'dexterity': [frames[n]['player_powers']['DEXTERITY_POWER'] for n in [277524, 277526]]})
crab_lines = [278236, 278237, 278242, 278249, 278252, 278254]
record('双蟹船夹板、临时减力和朝向虚弱现场', crab_lines,
       frames[278236]['block'] == 14 and
       enemy(278237, 'CRUSHER')['powers']['STRENGTH_POWER'] == -9 and
       enemy(278242, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) == 0 and
       [attack(enemy(n, 'ROCKET')) for n in [278249, 278252, 278254]] == [57, 38, 28],
       {'block_opening': frames[278236]['block'], 'temporary_strength': -9,
        'restored_strength': enemy(278242, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0),
        'rocket_attacks': [attack(enemy(n, 'ROCKET')) for n in [278249, 278252, 278254]]})
record('实验体两次T1手动端点；不填补工具未核回合开场', [277327, 277337, 277366, 277373],
       [frames[n]['hp'] for n in [277327, 277337, 277366, 277373]] == [27, 27, 27, 18] and
       [enemy(n)['hp'] for n in [277327, 277337, 277366, 277373]] == [111, 66, 111, 73],
       {'observed_hp_loss': [0, 9], 'enemy_net_hp_loss': [45, 38],
        'audit_turn_opening_status': 'unknown', 'causal_full_candidate_result': None})
record('双蟹两次T1手动端点；不将索引重排当实体证明', [278017, 278023, 278231, 278236],
       [frames[n]['hp'] for n in [278017, 278023, 278231, 278236]] == [47, 45, 47, 37] and
       [sum(e['hp'] for e in frames[n]['enemies']) for n in [278017, 278023, 278231, 278236]] == [428, 403, 428, 394],
       {'observed_hp_loss': [2, 10], 'enemy_net_hp_loss': [25, 34],
        'audit_turn_opening_status': 'unknown', 'causal_full_candidate_result': None})
record('沙虫末轮零血截断和显示算式分别保存', [276433, 276434],
       frames[276433]['hp'] == 5 and frames[276434]['hp'] == 0 and
       frames[276433]['block'] == 22 and attack(enemy(276433)) == 37 and
       enemy(276433)['hp'] - enemy(276434)['hp'] == 24,
       {'observed_player_net_loss': 5, 'enemy_net_hp_loss': 24,
        'displayed_attack_minus_block': 15, 'actual_uncapped_loss': None})

pair_checks = []
for run, pair, expected in [
    ('8JRE1C4H4Z2W', [270216, 270282], [[3, 10], [15, 17]]),
    ('XP2SL33HT0D9', [271992, 272040], [[9, 24], [14, 27]]),
]:
    inputs = json.loads((OUT / (run + '.audit-input.json')).read_text())
    audit = json.loads((OUT / (run + '.audit.json')).read_text())
    decisions = {r['_line']: r for r in inputs['decisions']}
    assert decisions[pair[0]]['fingerprint'] == decisions[pair[1]]['fingerprint']
    values = []
    for line in pair:
        row = decisions[line]
        turn = next(t for t in audit['observed_turns'] if
                    (t['floor'], t['turn'], t['attempt'], t['reloads']) ==
                    (row['floor'], row['turn'], row['sl_attempt'], row['sl_reloads']))
        assert turn['status'] == 'observed_turn_endpoints'
        f = turn['facts']
        values.append([-f['player_hp_delta'], -sum(e['hp_delta'] for e in f['enemy_hp_changes'])])
        assert f['actual_full_candidate_result'] is None
    assert values == expected
    pair_checks.append({'run': run, 'source_decision_lines': pair, 'same_fingerprint': True,
                        'observed_hp_loss_and_enemy_net_hp_loss': values,
                        'causal_full_candidate_result': None})

result = {'observation_checks': checks, 'paired_turn_checks': pair_checks,
          'scope': '材料核验，不是新增生产测试、候选因果或胜率校准'}
(OUT / 'observation-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'observation_checks': len(checks), 'paired_turn_checks': len(pair_checks)}, ensure_ascii=False))

# 策略复核报告

记录时间：2026-10-15T15:59:58+08:00。批次：20261015-154303-s2-strategy-proposal。结论：十个原提案均已复核，均为waiting；没有新增源码、提交、合入、版本或测试通过声明。

## 身份、范围和基线

根learn.json只读本批，task=strategy-proposal、character=silent、reason=proposal、工作树及六局集合匹配，恰有十个proposal_ids；没有research_request、implementation_request或proposal_repair。本批不是手动专题，不读取其他专题请求。普通专题入口文件属于旧批绑定，未按它开展研究。

开工git status干净；原HEAD为55533ec07a3fe8349fb5764005c2e502ac339095。按任务无冲突快进main，report.base为ac7dc94915cfc25ea6bd3db16de821b4db4a0c89。此后不改源码/知识/模板，工作树保持干净。日志只读，没有运行play或联网，没有下派agent。

启动器回执指定gpt-6.1-sol / xhigh / default，thread_id=01a13e84-18d1-7cb0-9f50-07fcabffade1；任务正文写high，宿主实际启动参数为xhigh。本任务未更改运行配置，不把启动参数当作独立核实了原生请求。

六个来源局均在runs.jsonl核为SILENT、A10，均已结束。原code分别带dirty，当前main/live源码不能冒称完整恢复旧运行树。六次SL是同一局相关尝试，不能按六个独立构筑样本拟胜率。只使用本批原提案、本角色原日志、账本及当前源码定位，不引入其他角色私有知识或预训练游戏结论。

## 原始证据和材料核验

使用共用extract_evidence.py抽取八流，总计8274条所属记录，source_size、每条源行号/offset/bytes/SHA和输出SHA保存在evidence/evidence-manifest.json。随后analyze_evidence.py逐条seek回原文件核字节SHA和JSON正文，结果raw-verification.json。

| 流 | 所属记录 | 固定源字节截点 |
| --- | ---: | ---: |
| states | 4062 | 13045148276 |
| decisions | 3941 | 1591550188 |
| sl-attempts | 38 | 40510364 |
| run-config | 6 | 1758260 |
| run-plans | 33 | 8044989 |
| brain | 188 | 578341252 |
| runs | 6 | 334478 |
| fight-plans | 0 | 2233957 |

fight-plans在本截点选到0条，只报告该截点未选到；不推断历史流缺失。源流的invalid_lines是全流扫描计数，不冒认是本角色已接纳证据。run-plans按显式run身份接收，不把正文提到局号当所属。

限定窗口：DUZU F27；5PM F38/F39；CA F13；8JRE F17/F33；YF F33/F48；XP F33。完整抽取保存六局原证据；离线消费者只分析这些提案窗口，保留原行号和时间，不重编号，不补尝试号。

复用现有learner/audit-selection.ts，以node --import tsx loader运行六个冻结输入，全部exit0，不调用LLM或游戏。audit-results.json分列：

| 局号 | 问题分段 | 可关联相邻观测/输入决策 | 可关联整轮端点/轮窗口 | 已认证完整候选 |
| --- | ---: | ---: | ---: | ---: |
| 5PM6JAQG6FNQ | 18 | 67/108 | 7/15 | 0 |
| 8JRE1C4H4Z2W | 66 | 264/277 | 44/57 | 0 |
| CA5KE8GFJ9X2 | 4 | 0/26 | 0/5 | 0 |
| DUZUBAJ3A8GP | 8 | 0/45 | 0/8 | 0 |
| XP2SL33HT0D9 | 58 | 237/244 | 28/45 | 0 |
| YF0LXT1QSTGG | 52 | 328/343 | 40/55 | 0 |

CA和DUZU的普通关联为0，原因分别为25/44条room_or_attempt_changed_or_unknown和末条input_exhausted；这是旧日志缺尝试身份时的消费者边界，不是这些局没有状态或没有行动。YF/XP的T1缺前轮结束证据，工具仍unknown；手动原帧端点另列，不改输入以让工具通过。

check_observations.py最终9项观察检查、2组同指纹整轮检查通过；prism-replay.mjs的2段固定当轮回放吻合，未触发知识JSON读取。它们属于材料/当前模型核验，不是新增生产测试或实盘独立留出。T4回放覆盖迷雾→勒紧→防御；T5只从生存者已经完成且弃牌结束后的状态回放防御→迷雾，不把跨弃牌续步认证成原完整候选。

关键结果：沙虫T2损3/15、敌净扣10/17；实验体T1手动端点损0/9、净扣45/38；双蟹T3损9/14、净扣24/27，T1手动端点损2/10、净扣25/34。它们是已观测窗口净值，不是未选线反事实或整场因果。

## 十项处置

逐项证据局号/层/回合、账本、支持、反例、旧/预期行为、验证要求、回退和原稿SHA完整见proposal.md；机器处置见proposal-results.json。

- silent-proposal-c20b5139dd0dff71：waiting；当轮两段回放已吻合；缺旧运行实际消费的A10移动表、跨轮联合输入及未选线后继结果，不能将部分模型覆盖登记为整项duplicate。
- silent-proposal-ae9e692d680e3819：waiting；缺逐来源已夺累计数和返还所有权的完整生产输入；amount=1不能替代返还4，另一杀序后继结果未知。
- silent-proposal-52f1e1bd2e7db0ed：waiting；缺原dirty运行实际A10移动表与覆甲减层条件的独立输入；现场成长数值已核，未发现可新增的确定性当轮差异。
- silent-proposal-6dd8bbff876be528：waiting；缺稳定实体/召唤代际和新同类连续出现的冻结输入；索引4→3不能充当身份或计数不继承证明。
- silent-proposal-578e415a259e6835：waiting；已有预测与端点审计不能认证完整候选；缺原答/护栏/SL/重规划之后的逐来源兑现和独立后继对照。
- silent-proposal-c0767768bf6a7ab1：waiting；T1手动端点已核，但完整候选与未执行续步仍未知；缺整条替代线的资源/胜负对照，不改探索惩罚或准入。
- silent-proposal-a46bdb7fe711d79a：waiting；阶段快照、零毒和23挡子项已有；缺下一轮增段、逐阶段收益与候选完整执行的联合校准，不能整项duplicate。
- silent-proposal-1044224808015e5c：waiting；同盘血价已核；缺原线继续与换线的独立后继整战结果，无法验证新的低损优先策略。
- silent-proposal-7cbc6005db712ba9：waiting；已核14挡、减力恢复及57→38→28；缺逐候选贡献拆分和完整执行绑定，不能据现场片段改优先级或宣称整项完成。
- silent-proposal-c59f592f1427a67e：waiting；六锚点不覆盖原101局分母；缺逐来源资源、完整候选归属及独立后继联合校准，宽项继续waiting。

本批没有证据支持设置统一血价系数、固定击杀序、强制技能/能力优先级或修改SL/药水/终局权重。已完成部分也不反证剩余提案无价值；保持原提案以待缺失的生产输入/独立后继证据，不新增重复ID。

## 实际live源码读回

只读核验live=1e3f8d10bddc7bb97acad87cf37238490c4cfc5c，18个相关源/测试叶中17个逐字节相同；card-model.ts仅两处Roy/Dai历史注释名称差，按这两处规范化后全文字节相等。source-readback.json保存各叶SHA、Git blob、实际live祖先源提交及祖先检查；live-comment-difference.patch和live-comment-equivalence.json保存差异范围。以下是已有部分实现的源码定位，不是这些宽提案完整implemented/duplicate的证明。

| 路径 | 实际live祖先源提交 | 与本树关系 |
| --- | --- | --- |
| agent/src/reflex/turn-solver.ts | 8c1935b9c672c5e9fdd676371e16988a8f0bc714 | 相同 |
| agent/src/reflex/card-model.ts | 8c1935b9c672c5e9fdd676371e16988a8f0bc714 | 仅两处历史注释名差，单独规范化字节核同 |
| agent/src/reflex/combat-plan.ts | 0bf701b583e905fcde2bc6d9b5ec1bc0d1131332 | 相同 |
| agent/src/reflex/rollout.ts | 0944cf8cfd06d345548f5271f1e6521b0cd46656 | 相同 |
| agent/src/reflex/silent-sl-resource-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 相同 |
| agent/src/reflex/silent-hp-guard-audit.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |
| agent/src/reflex/silent-phase-current.ts | 8698c581dac6c7e957f50a381586960a6d0c9b57 | 相同 |
| agent/src/reflex/silent-phase-reference.ts | 1d57f9d0dbbb63603e9ce9768e74cb2021478464 | 相同 |
| agent/src/knowledge/monster-db.ts | 4ed3c72df30f27b881da637aebf528b97440e0bb | 相同 |
| learner/lib/selection-execution.ts | cf72bd21148059f111f760cc98a727369e34a47e | 相同 |
| learner/lib/selection-observation.ts | cf72bd21148059f111f760cc98a727369e34a47e | 相同 |
| learner/lib/selection-turn.ts | 9b87d54f097d84521152e6cca8d6072af8140394 | 相同 |
| learner/lib/selection-terminal.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | 相同 |
| learner/audit-selection.ts | 6f3f783941270ac182237c46068097ff67e85907 | 相同 |
| agent/tests/silent-observed-intervals.test.ts | 80308cd88457ea2d9559a3ebfa41527265c361d2 | 相同 |
| agent/tests/silent-phase-current.test.ts | 8698c581dac6c7e957f50a381586960a6d0c9b57 | 相同 |
| agent/tests/silent-sl-resource-comparison.test.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |

现有selection_audit保留原答/护栏后/SL后预测和首个请求；silentSlResourceComparison标execution=unverified；phase快照区分持有/已建/现毒；离线工具的actual_full_candidate_result仍空。字段存在、观察区间和原完整候选执行分别验收，不以字段空值冒充实现。

## 记录、验证边界及未实施原因

已只经根learner/ledger.py update给本批30个既有账本追加proposal/report追溯，CLI exit0；没有新增游戏结论。ledger-verification.json确认30项链接均可读回，claim/证据/首证/prior/status/经验版本等关键字段前后相同，不标shipped。请求和回执见ledger-updates.jsonl、ledger-update.out/err。既有shipped条目不会为一次复核降级为proposed；本批无新账本项需要设proposed。

生产源码变更为空，fixes=[]，merged=null。没有新提交、撤生产源码负控、tsc/vitest、live合后检查或eval版本；对应结果全部null。已有提交只用于限定范围读回，未登记为本批实现。没有规则上线，因此没有制造上线通知或release_id。

失败及初稿保留：若干先按猜测路径sed定位失败，后用rg找到真实路径；材料检查v1保留，v2补上朝向中间帧278252与手动T1/终态检查；可选TypeScript transpileModule等价探针因本机typescript包无该require入口报MODULE_NOT_FOUND，保存在live-comment-equivalence-first-error.txt，未安装依赖，最终只做两处注释规范化的精确字节核验，不宣称编译等价。没有将这些工具定位问题当游戏源码或生产自测失败。

限制：旧dirty树未完整重建；原实际消费DB/召唤稳定身份/逐来源返还不齐；SL尝试相关、未选线和未派发续步没有完整后继结果；六锚点不代替原101局历史分母；离线字段与固定样本吻合不证明自然采用、胜率收益或父学习要求已闭合。

本报告和proposal路径均在本批scratch，原提案Markdown副本及SHA保留；交运维按proposal_results续办。没有把排队或文件落盘说成运维/Roy已读。

最终验收：completion-verification.json确认HEAD仍等于完整base、tracked diff为0且git status干净；十个原稿SHA全匹配，本批绑定未变。全scratch的gitleaks dir --redact扫描exit0，findings为空；无源码提交需要额外提交前检查。

import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BATCH = '20261015-154303-s2-strategy-proposal'
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
audits = json.loads((OUT / 'audit-results.json').read_text())
manifest = json.loads((OUT / 'raw-verification.json').read_text())

details = [
    ('c20b5139dd0dff71', '感染棱柱技能与污染',
     'DUZUBAJ3A8GP / F27 / T4—T6；states 274830—274839。',
     '污染为0→3→3→6；勒紧能力没有再加污染。T5改为火花6，污染6→12→18，下一轮消失。两段固定当前源码回放分别吻合损3/毒伤8与损9/毒伤13，unknown_cards均空，未触发知识文件读取。',
     '原提案的技能收益不能只按污染判亏。现有代码已覆盖本次当轮组合，但两段手工构成的SolverInput不是旧dirty运行时消费的A10移动表或跨轮完整生产输入，未选线的后继结果仍未知。',
     '当轮两段回放已吻合；缺旧运行实际消费的A10移动表、跨轮联合输入及未选线后继结果，不能将部分模型覆盖登记为整项duplicate。'),
    ('ae9e692d680e3819', '抢夺与逐来源返还',
     '5PM6JAQG6FNQ / F39 / T4—T6；states 274351—274362、274396—274397。',
     '两次步法使敏捷−4→−2→0；失落退出前力量−4，次轮为0，随后遗忘再夺2敏。POSSESS_STRENGTH_POWER现场amount=1，不能将它直接解释为累计返还4。末试失落中毒退场，玩家仍由8血到0。',
     '负属性和死亡后恢复不是固定击杀序的获胜证明。当前端点审计遇减员不会认定稳定实体归属；普通负力量公式也不等于逐来源返还已实现。',
     '缺逐来源已夺累计数和返还所有权的完整生产输入；amount=1不能替代返还4，另一杀序后继结果未知。'),
    ('52f1e1bd2e7db0ed', '下水道蚌加压与覆甲',
     'CA5KE8GFJ9X2 / F13 / T1—T5；states 273237—273269。',
     '已见喷水11/15/19、敌力量0/4/8；虚弱后分别11/14；轮初覆甲9/9/8/7/6。末正血2、挡10对显示14，实际零血截断，不能将2净损说成完整入伤。',
     'moveDamageAt读取当前进阶观测时没有五样本门槛，房间代价仍ROOM_COST_MIN_N=5。现有接线不是旧dirty局实际DB快照；已见覆甲层序不能确定全部减层条件。',
     '缺原dirty运行实际A10移动表与覆甲减层条件的独立输入；现场成长数值已核，未发现可新增的确定性当轮差异。'),
    ('6dd8bbff876be528', '高电压与召唤代际',
     '5PM6JAQG6FNQ / F38 / T3—T4；states 274308、274312—274314。',
     '唯一ZAPBOT的最大HP为23，力量2→4、攻击17→19；索引4→3随名单变化。T3仍有攻击，不能把主怪毒进度记成爪牙已退场。',
     'rollout已有HIGH_VOLTAGE_POWER增长与fresh spawn独立初始化；原日志没有稳定实例ID，唯一类型和相同最大HP不足以验证全部召唤代际。未执行先杀线的后续结果仍未知。',
     '缺稳定实体/召唤代际和新同类连续出现的冻结输入；索引4→3不能充当身份或计数不继承证明。'),
    ('578e415a259e6835', '沙虫SL、护栏和已建能力',
     '8JRE1C4H4Z2W / F33 / 首/第三试T2、第二试T5、末试T11；decisions 270216/270282；states 276433—276434。',
     'T2两题fingerprint逐字相等，原审计消费者核整轮端点损3/15、敌净扣10/17；末轮5→0为截断净损，显示37−22=15单列，敌154→130。',
     '原案已有保挡替换延长到T11仍败的反例，不能从少挡或全败模拟单独判断规则。selection_audit、hp_guard、离线端点/整轮工具都已有部分覆盖，但actual_full_candidate_result仍空。',
     '已有预测与端点审计不能认证完整候选；缺原答/护栏/SL/重规划之后的逐来源兑现和独立后继对照。'),
    ('c0767768bf6a7ab1', '全败SL资源代价',
     'YF0LXT1QSTGG / F48 / 第二/第三试T1；decisions 271309/271348；states 277327/277337、277366/277373。',
     '同指纹手动端点玩家27→27/27→18、敌111→66/111→73，即损0/9、敌净扣45/38。工具对T1仍报turn_opening_unverified，未为通过审计补前轮结束证据。sl-attempts 929核同局F33第二试won、end_hp20。',
     '六次F48失败不能否定同局F33成功SL；未执行的斗篷/防御续步没有整战结果。silentSlResourceComparison只列预测，原/替线execution=unverified。',
     'T1手动端点已核，但完整候选与未执行续步仍未知；缺整条替代线的资源/胜负对照，不改探索惩罚或准入。'),
    ('a46bdb7fe711d79a', '实验体分阶段毒与敏捷兑现',
     'YF0LXT1QSTGG / F48 / 末试T3—T5；states 277512—277526。',
     '敌HP4/最大111变212，旧毒清空；触媒2建立时现毒0。敏捷5→6时既有23挡不变，不能倒补；当前快照和离线observed_intervals源码均已有覆盖。',
     '持有毒雾/毒性爆发与已施放不等价，旧提案保留已建毒能力仍失败的反例。现有快照并未完整关联下一轮增段、阶段分账与实际完整候选。',
     '阶段快照、零毒和23挡子项已有；缺下一轮增段、逐阶段收益与候选完整执行的联合校准，不能整项duplicate。'),
    ('1044224808015e5c', '双蟹零胜率SL血价',
     'XP2SL33HT0D9 / F33 / 首/第二试T3、首/末试T1；decisions 271992/272040、271982/272195。',
     '两组各自同指纹。原工具核T3损9/14、两敌净扣24/27；T1手动端点47→45/47→37、敌合计428→403/428→394，即损2/10、净扣25/34；T1工具开场仍未知。',
     '换线还涉及手里剑、抽弃牌、药瓶随机和后轮变化，不能将全败排名差0当安全，也不能由本局拟统一低损优先规则。',
     '同盘血价已核；缺原线继续与换线的独立后继整战结果，无法验证新的低损优先策略。'),
    ('7cbc6005db712ba9', '双蟹朝向、临时减力与能力',
     'XP2SL33HT0D9 / F33 / 末试T2—T5；states 278236—278242、278249/278252/278254。',
     '轮初14挡，普通镣铐爪力量0→−9，下一轮恢复0；火箭显示57→38→28，朝向与弱两个观察步骤分列。',
     '现场值、临时减力、既有敏捷与出牌后新增收益已有若干模型；本轮没有据当前已知范围定位新增确定性差异。未来贡献拆分不能用持有或总输出替代，末战仍未减员。',
     '已核14挡、减力恢复及57→38→28；缺逐候选贡献拆分和完整执行绑定，不能据现场片段改优先级或宣称整项完成。'),
    ('c59f592f1427a67e', '合并经验的资源与SL宽项',
     'YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1—T5；对应以上原帧。',
     '复核上述同盘血价、23挡不倒补、14挡、临时减力和阶段重读。原提案列出的101局/1499房/机制支持数是原批范围，本批只重新分析六个派发锚点，未借锚点充当全历史重算。',
     '原宽项还含路线/休息/药水、逐来源收益和完整执行。本轮没有新增独立构筑或资源受控结果；原账本和经验claim、首证、prior、status、版本不重写。',
     '六锚点不覆盖原101局分母；缺逐来源资源、完整候选归属及独立后继联合校准，宽项继续waiting。'),
]

results = []
sections = []
for suffix, title, evidence, support, counter, reason in details:
    id = 'silent-proposal-' + suffix
    original = assigned[id]
    assert original['character'] == 'silent'
    results.append({'id': id, 'state': 'waiting', 'reason': reason})
    sections.append('\n'.join([
        '## ' + id + '：' + title,
        '', '关联账本：' + '、'.join(original['ledger']) + '。',
        '证据：' + evidence, '', '支持及本次核验：' + support,
        '', '反例、边界与当前实现：' + counter,
        '', '处置：waiting。' + reason,
        '', '预期行为：' + original['summary'],
        '验证要求：只用本角色固定输入，逐步核玩家HP/挡、敌本体HP/毒和能力建立/消失；后继比较按独立局、结束时间后移，SL不扩独立样本数。需要策略改动时先有可解释差异，再做撤源码失败/恢复通过与原沙箱入口；本批无此类源码改动。',
        '回退：本批无生产变更可回退，原提案及证据保留；后续若实现，按独立实际源码提交回退并遵守既有授权通知。',
        '原提案路径：' + original['proposal'],
        '原提案SHA256：' + original['proposal_sha256'], '',
    ]))

assert {r['id'] for r in results} == set(dispatch['proposal_ids'])
proposal = '\n'.join([
    '# 本批十个静默策略提案的证据复核', '',
    '批次：' + BATCH + '。来源任务及实现任务：strategy-proposal。角色：silent；本批重新核验的进阶均为A10。',
    '没有承接其他专题、扩领队列或新增提案ID；既有Roy-2026-10-07-learning仅是规则修改权限。以下十项均保留waiting，不将已有部分模块覆盖说成整项duplicate。', '',
    *sections,
])
(OUT / 'proposal.md').write_text(proposal)
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

counts = '\n'.join('| ' + r['stream'] + ' | ' + str(r['rows']) + ' | ' + str(r['source_size']) + ' |' for r in manifest)
audit_table = '\n'.join('| ' + r['run'] + ' | ' + str(r['segments']) + ' | ' + str(r['observed_intervals']) + '/' + str(r['intervals']) + ' | ' + str(r['observed_turns']) + '/' + str(r['turns']) + ' | 0 |' for r in audits)
source_table = '\n'.join('| ' + r['path'] + ' | ' + r['live_source_commit'] + ' | ' + ('相同' if r['same_as_live'] else '仅两处历史注释名差，单独规范化字节核同') + ' |' for r in source['files'])
time = (OUT / 'report-time.txt').read_text().strip()
report = f'''# 策略复核报告

记录时间：{time}。批次：{BATCH}。结论：十个原提案均已复核，均为waiting；没有新增源码、提交、合入、版本或测试通过声明。

## 身份、范围和基线

根learn.json只读本批，task=strategy-proposal、character=silent、reason=proposal、工作树及六局集合匹配，恰有十个proposal_ids；没有research_request、implementation_request或proposal_repair。本批不是手动专题，不读取其他专题请求。普通专题入口文件属于旧批绑定，未按它开展研究。

开工git status干净；原HEAD为55533ec07a3fe8349fb5764005c2e502ac339095。按任务无冲突快进main，report.base为{source['base']}。此后不改源码/知识/模板，工作树保持干净。日志只读，没有运行play或联网，没有下派agent。

启动器回执指定gpt-6.1-sol / xhigh / default，thread_id=01a13e84-18d1-7cb0-9f50-07fcabffade1；这是实际宿主启动参数，未将任务旧文字的high冒报为已切换，也不把启动参数当作独立核实了原生请求。任务内未更改运行配置。

六个来源局均在runs.jsonl核为SILENT、A10，均已结束。原code分别带dirty，当前main/live源码不能冒称完整恢复旧运行树。六次SL是同一局相关尝试，不能按六个独立构筑样本拟胜率。只使用本批原提案、本角色原日志、账本及当前源码定位，不引入其他角色私有知识或预训练游戏结论。

## 原始证据和材料核验

使用共用extract_evidence.py抽取八流，总计8274条所属记录，source_size、每条源行号/offset/bytes/SHA和输出SHA保存在evidence/evidence-manifest.json。随后analyze_evidence.py逐条seek回原文件核字节SHA和JSON正文，结果raw-verification.json。

| 流 | 所属记录 | 固定源字节截点 |
| --- | ---: | ---: |
{counts}

fight-plans在本截点选到0条，只报告该截点未选到；不推断历史流缺失。源流的invalid_lines是全流扫描计数，不冒认是本角色已接纳证据。run-plans按显式run身份接收，不把正文提到局号当所属。

限定窗口：DUZU F27；5PM F38/F39；CA F13；8JRE F17/F33；YF F33/F48；XP F33。完整抽取保存六局原证据；离线消费者只分析这些提案窗口，保留原行号和时间，不重编号，不补尝试号。

复用现有learner/audit-selection.ts，以node --import tsx loader运行六个冻结输入，全部exit0，不调用LLM或游戏。audit-results.json分列：

| 局号 | 问题分段 | 可关联相邻观测/输入决策 | 可关联整轮端点/轮窗口 | 已认证完整候选 |
| --- | ---: | ---: | ---: | ---: |
{audit_table}

CA和DUZU的普通关联为0，原因分别为25/44条room_or_attempt_changed_or_unknown和末条input_exhausted；这是旧日志缺尝试身份时的消费者边界，不是这些局没有状态或没有行动。YF/XP的T1缺前轮结束证据，工具仍unknown；手动原帧端点另列，不改输入以让工具通过。

check_observations.py最终9项观察检查、2组同指纹整轮检查通过；prism-replay.mjs的2段固定当轮回放吻合，未触发知识JSON读取。它们属于材料/当前模型核验，不是新增生产测试或实盘独立留出。T4回放覆盖迷雾→勒紧→防御；T5只从生存者已经完成且弃牌结束后的状态回放防御→迷雾，不把跨弃牌续步认证成原完整候选。

关键结果：沙虫T2损3/15、敌净扣10/17；实验体T1手动端点损0/9、净扣45/38；双蟹T3损9/14、净扣24/27，T1手动端点损2/10、净扣25/34。它们是已观测窗口净值，不是未选线反事实或整场因果。

## 十项处置

逐项证据局号/层/回合、账本、支持、反例、旧/预期行为、验证要求、回退和原稿SHA完整见proposal.md；机器处置见proposal-results.json。

''' + '\n'.join(f"- {r['id']}：waiting；{r['reason']}" for r in results) + f'''

本批没有证据支持设置统一血价系数、固定击杀序、强制技能/能力优先级或修改SL/药水/终局权重。已完成部分也不反证剩余提案无价值；保持原提案以待缺失的生产输入/独立后继证据，不新增重复ID。

## 实际live源码读回

只读核验live={source['live']}，18个相关源/测试叶中17个逐字节相同；card-model.ts仅两处Roy/Dai历史注释名称差，按这两处规范化后全文字节相等。source-readback.json保存各叶SHA、Git blob、实际live祖先源提交及祖先检查；live-comment-difference.patch和live-comment-equivalence.json保存差异范围。以下是已有部分实现的源码定位，不是这些宽提案完整implemented/duplicate的证明。

| 路径 | 实际live祖先源提交 | 与本树关系 |
| --- | --- | --- |
{source_table}

现有selection_audit保留原答/护栏后/SL后预测和首个请求；silentSlResourceComparison标execution=unverified；phase快照区分持有/已建/现毒；离线工具的actual_full_candidate_result仍空。字段存在、观察区间和原完整候选执行分别验收，不以字段空值冒充实现。

## 记录、验证边界及未实施原因

只经根learner/ledger.py update给本批既有账本追加proposal/report追溯；不新增游戏结论，不修改claim/证据/首证/prior/status/经验版本，不标shipped。请求和回执见ledger-updates.jsonl、ledger-update.out/err，保留前后关键字段核验。既有shipped条目不会为一次复核降级为proposed；本批无新账本项需要设proposed。

生产源码变更为空，fixes=[]，merged=null。没有新提交、撤生产源码负控、tsc/vitest、live合后检查或eval版本；对应结果全部null。已有提交只用于限定范围读回，未登记为本批实现。没有规则上线，因此没有制造上线通知或release_id。

失败及初稿保留：若干先按猜测路径sed定位失败，后用rg找到真实路径；材料检查v1保留，v2补上朝向中间帧278252与手动T1/终态检查；可选TypeScript transpileModule等价探针因本机typescript包无该require入口报MODULE_NOT_FOUND，保存在live-comment-equivalence-first-error.txt，未安装依赖，最终只做两处注释规范化的精确字节核验，不宣称编译等价。没有将这些工具定位问题当游戏源码或生产自测失败。

限制：旧dirty树未完整重建；原实际消费DB/召唤稳定身份/逐来源返还不齐；SL尝试相关、未选线和未派发续步没有完整后继结果；六锚点不代替原101局历史分母；离线字段与固定样本吻合不证明自然采用、胜率收益或父学习要求已闭合。

本报告和proposal路径均在本批scratch，原提案Markdown副本及SHA保留；交运维按proposal_results续办。没有把排队或文件落盘说成运维/Roy已读。
'''
(OUT / 'report.md').write_text(report)

ledger_ids = sorted({id for original in assigned.values() for id in original['ledger']})
updates = [{'id': id, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': BATCH + '：仅复核本批六个Silent A10锚点和原已领取提案，逐项waiting及证据边界见报告；追加追溯，不改原claim/证据/首证/prior/status/经验版本，不标shipped。'}
           for id in ledger_ids]
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
         'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [],
         'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposal_results': len(results), 'ledger_links': len(updates),
                  'report': str(OUT / 'report.md')}, ensure_ascii=False))

import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Prevent these material probes from consulting refreshed knowledge data.
const originalRead = fs.readFileSync;
const blocked = [];
fs.readFileSync = function (file, ...args) {
  if (String(file).includes('/knowledge/') && String(file).endsWith('.json')) {
    blocked.push(String(file));
    throw Object.assign(new Error('Frozen observations only'), { code: 'ENOENT' });
  }
  return originalRead.call(this, file, ...args);
};
syncBuiltinESMExports();
const moduleAt = (path) => import(pathToFileURL(resolve(path)).href);
const { makeKnowledge } = await moduleAt('agent/src/knowledge/index.ts');
const { setCardUpgradesForTests } = await moduleAt('agent/src/knowledge/card-upgrades.ts');
const { modelHandCard } = await moduleAt('agent/src/reflex/card-model.ts');
const { replaySteps } = await moduleAt('agent/src/reflex/turn-solver.ts');
setCardUpgradesForTests({});
const input = JSON.parse(fs.readFileSync(new URL('./DUZUBAJ3A8GP.audit-input.json', import.meta.url), 'utf8'));
const power = (holder, id) => holder.powers.find((item) => item.power_id === id)?.amount ?? 0;
const results = [];
for (const [line, ids, expected] of [
  [274830, ['HAZE', 'FASTEN', 'DEFEND_SILENT'], { hpLoss: 3, blockGained: 9, damageDealt: 8 }],
  [274836, ['DEFEND_SILENT', 'HAZE'], { hpLoss: 9, blockGained: 9, damageDealt: 13 }],
]) {
  const raw = input.states.find((row) => row._line === line).state;
  const combat = raw.combat, p = combat.player;
  const knowledge = makeKnowledge({ cards: raw.run.deck.map((card) => ({
    id: card.card_id, name: card.name, type: card.card_type,
  })) }, 'frozen');
  const hand = combat.hand.map((card, index) => modelHandCard(card, index, knowledge, 'silent', 10));
  const player = { hp: p.current_hp, maxHp: p.max_hp, energy: p.energy, block: p.block,
    strengthNow: power(p, 'STRENGTH_POWER'), dexterityNow: power(p, 'DEXTERITY_POWER'),
    weak: power(p, 'WEAK_POWER') > 0, vulnerable: power(p, 'VULNERABLE_POWER') > 0,
    intangible: power(p, 'INTANGIBLE_POWER') > 0, frail: power(p, 'FRAIL_POWER') > 0 };
  const enemies = combat.enemies.map((enemy) => ({
    index: enemy.index, name: enemy.name, hp: enemy.current_hp, maxHp: enemy.max_hp,
    block: enemy.block, vulnerable: power(enemy, 'VULNERABLE_POWER'), weak: power(enemy, 'WEAK_POWER'),
    artifact: power(enemy, 'ARTIFACT_POWER'), intangible: false,
    vitalSpark: power(enemy, 'VITAL_SPARK_POWER'), poison: power(enemy, 'POISON_POWER'),
    attacks: enemy.intents.filter((item) => typeof item.damage === 'number').map((item) => ({ damage: item.damage, hits: item.hits })),
  }));
  const steps = ids.map((id) => {
    const card = hand.find((entry) => entry.cardId === id);
    if (!card) throw new Error('Missing observed card ' + id);
    return { cardIndex: card.index, cardId: card.cardId, name: card.name, upgraded: card.upgraded, target: null };
  });
  const played = replaySteps({ hand, player, enemies, turn: raw.turn, fightKind: 'elite' }, steps);
  if (!played) throw new Error('Observed prefix could not be replayed');
  const actual = Object.fromEntries(Object.keys(expected).map((key) => [key, played.outcome[key]]));
  const matches = JSON.stringify(actual) === JSON.stringify(expected);
  results.push({ source_state_line: line, cards: ids, expected, actual, matches,
    enemies_after: played.outcome.enemyHpAfter, unknown_cards: played.outcome.unknownCards,
    scope: 'fixed_current_turn_prefix_not_live_input_or_full_candidate_certification' });
}
console.log(JSON.stringify({ results, blocked_knowledge_reads: blocked }, null, 2));
if (results.some((row) => !row.matches)) process.exitCode = 1;

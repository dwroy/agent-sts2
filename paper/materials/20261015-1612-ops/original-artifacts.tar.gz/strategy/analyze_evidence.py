import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
SCOPES = {
    'DUZUBAJ3A8GP': {27},
    '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48},
    'XP2SL33HT0D9': {33},
}


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(holder):
    return {p['power_id']: p.get('amount') for p in holder.get('powers', [])}


def snapshot(row, line):
    s = row['state']
    c, r = s.get('combat') or {}, s.get('run') or {}
    p = c.get('player') or {}
    return {
        'line': line, 'observed_ts': row.get('observed_ts'),
        'run': s.get('run_id'), 'floor': r.get('floor'),
        'turn': s.get('turn'), 'screen': s.get('screen'),
        'hp': p.get('current_hp', r.get('current_hp')), 'block': p.get('block'),
        'player_powers': powers(p),
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'),
                     'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                     'alive': e.get('is_alive'), 'block': e.get('block'),
                     'move': e.get('move_id'), 'powers': powers(e),
                     'intents': e.get('intents')} for e in c.get('enemies', [])],
    }


def main():
    streams = {}
    verification = []
    for manifest in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
        stream = manifest['stream']
        rows = []
        path = OUT / 'evidence' / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
        with Path('/home/dw/Projects/agent-sts2/logs', stream + '.jsonl').open('rb') as source:
            for line in path.open():
                item = json.loads(line)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                rows.append(item)
        streams[stream] = rows
        verification.append({'stream': stream, 'rows': len(rows), 'verified': True,
                             'source_size': manifest['source_size'], 'counts': manifest['counts']})
    dump('raw-verification.json', verification)
    run_rows = {item['run_id']: item['row'] for item in streams['runs']}
    assert set(run_rows) == set(SCOPES)
    assert all(r['character'] == 'SILENT' and r['ascension'] == 10 for r in run_rows.values())
    dump('run-identities.json', run_rows)
    relevant_states = collections.defaultdict(list)
    summary = collections.defaultdict(list)
    for item in streams['states']:
        row = item['row']
        s = row['state']
        r = s.get('run') or {}
        assert r.get('character_id', '').lower() == 'silent'
        assert r.get('ascension') == 10
        if r.get('floor') in SCOPES[item['run_id']]:
            copied = dict(row, _line=item['line'], _source_sha256=item['sha256'])
            relevant_states[item['run_id']].append(copied)
            summary[item['run_id']].append(snapshot(row, item['line']))
    dump('relevant-state-summaries.json', summary)
    decisions = collections.defaultdict(list)
    exclusions = []
    for item in streams['decisions']:
        row = item['row']
        if row.get('floor') not in SCOPES[item['run_id']]:
            continue
        if not row.get('decision_id'):
            exclusions.append({'run': item['run_id'], 'line': item['line'],
                               'reason': '没有 decision_id 的元数据行，保留原证据但不进入动作审计'})
            continue
        decisions[item['run_id']].append(dict(row, _line=item['line'], _source_sha256=item['sha256']))
    dump('audit-input-exclusions.json', exclusions)
    selected_decisions = {}
    for run in SCOPES:
        rows = sorted(decisions[run], key=lambda r: r['observed_ts'])
        dump(run + '.audit-input.json', {'run': run_rows[run], 'decisions': rows,
                                        'states': relevant_states[run]})
        selected_decisions[run] = [{k: r.get(k) for k in (
            '_line', 'decision_id', 'observed_ts', 'floor', 'turn', 'sl_attempt',
            'sl_reloads', 'label', 'chosen', 'expect', 'result', 'journal',
            'sl_explore', 'hp_guard', 'selection_audit', 'questions', 'answers',
            'fingerprint')} for r in rows]
    dump('relevant-decisions.json', selected_decisions)
    openings = {}
    for run, rows in summary.items():
        groups = []
        for row in rows:
            key = (row['floor'], row['turn'], row['screen'])
            if not groups or groups[-1]['key'] != list(key):
                groups.append({'key': list(key), 'first': row, 'last': row})
            else:
                groups[-1]['last'] = row
        openings[run] = groups
    dump('turn-state-boundaries.json', openings)
    print(json.dumps({'verification': verification,
                      'scoped_states': {k: len(v) for k, v in relevant_states.items()},
                      'scoped_decisions': {k: len(v) for k, v in decisions.items()},
                      'audit_exclusions': exclusions}, ensure_ascii=False))


if __name__ == '__main__':
    main()

## 修 bug 回报
- 合并基线：main → 0052edea183041950e5d16356a0040925f1b39cc
- 修复：infra-target-options-fixed-fixture-timeout：EZ2L标注候选固定夹具超时 — bae9c45ccffefb284a1c6634526c8768a9f5f7a8 — 测试 agent/tests/target-options.test.ts:bounds the target-label fixture work independently of host pauses and restores its clock — 去掉修复时失败：是
- 修复：infra-legacy-continuation-notice-ack-identity：合法旧续跑通知身份被拒 — 368fccabd42eb72ffcea9a2fe6cbbb7c149326be — 测试 agent/tests/legacy-continuation-notice-ack.test.ts:binds legacy continuation notices to registered parent/thread/input and preserves independent actor ACK guards — 去掉修复时失败：是
- 修复：silent-0459：独立run-plan请求成本漏计 — 799a5cd0caf9329b43c32376079218a9bd0c3e9e — 测试 agent/tests/report-plan-costs.test.ts:includes fixed independent run-plan cost once while preserving actions, Jev totals and historical logs — 去掉修复时失败：是
- 已被别人修掉的：infra-learner-event-log-second-collision — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f；infra-paper-krane-recorded-line-timeout — befc39e5ca0105f8ff96d47f817df44f0b2760f1；额度基线恢复 — e5e2995d6；实际进阶通知 — 8045d9fbf；silent-0254死亡战斗统计 — 3b48088de；silent-0338终轮格挡诊断 — c1d848049；silent-0367已耗尾巴事实 — 5baf663d7；宿主定向续验入口 — 24c2e3a75；旧eval/神化夹具超时 — d9881ba59 / 9e8c93555
- 没修的：未结机制/打法（含silent-0481）— 策略类，沿原独立提案；core-build-notify原失败 — 投递证据不足；调度公平性 — 未证永久饥饿；独立架构/缓存/DPR任务 — 太大，保留原owner。
- 测试：tsc退出码0；沙箱vitest 411文件 / 3945用例 / 退出码0；三次提交前全套均0，无超时重跑。报表首次无效负对照已保留并更正。
- 合入：未合入；22个记录文件冲突，已abort，保留刷新提交fd0e9c3fa68e9c34a48e7149865c16eaf3465cef；live合后测试未执行。
- 需要 Roy 定的事：无

```json
{
  "task": "fix-batch",
  "base": "0052edea183041950e5d16356a0040925f1b39cc",
  "fixes": [
    {
      "item": "infra-target-options-fixed-fixture-timeout：EZ2L标注候选固定夹具超时",
      "commit": "bae9c45ccffefb284a1c6634526c8768a9f5f7a8",
      "test": "agent/tests/target-options.test.ts",
      "test_name": "bounds the target-label fixture work independently of host pauses and restores its clock",
      "fails_without_fix": true
    },
    {
      "item": "infra-legacy-continuation-notice-ack-identity：合法旧续跑通知身份被拒",
      "commit": "368fccabd42eb72ffcea9a2fe6cbbb7c149326be",
      "test": "agent/tests/legacy-continuation-notice-ack.test.ts",
      "test_name": "binds legacy continuation notices to registered parent/thread/input and preserves independent actor ACK guards",
      "fails_without_fix": true
    },
    {
      "item": "silent-0459：独立run-plan请求成本漏计",
      "commit": "799a5cd0caf9329b43c32376079218a9bd0c3e9e",
      "test": "agent/tests/report-plan-costs.test.ts",
      "test_name": "includes fixed independent run-plan cost once while preserving actions, Jev totals and historical logs",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "infra-learner-event-log-second-collision",
      "reason": "已修，提交 b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f"
    },
    {
      "item": "infra-paper-krane-recorded-line-timeout",
      "reason": "已修，提交 befc39e5ca0105f8ff96d47f817df44f0b2760f1"
    },
    {
      "item": "额度基线恢复",
      "reason": "已修，提交 e5e2995d6"
    },
    {
      "item": "实际进阶通知",
      "reason": "已修，提交 8045d9fbf"
    },
    {
      "item": "silent-0254死亡战斗统计",
      "reason": "已修，提交 3b48088de"
    },
    {
      "item": "silent-0338终轮格挡诊断",
      "reason": "已修，提交 c1d848049"
    },
    {
      "item": "silent-0367已耗尾巴事实",
      "reason": "已修，提交 5baf663d7"
    },
    {
      "item": "宿主定向续验入口",
      "reason": "已修，提交 24c2e3a75"
    },
    {
      "item": "旧eval/神化夹具超时",
      "reason": "已修，提交 d9881ba59 / 9e8c93555"
    },
    {
      "item": "其余未结游戏机制/打法项（含silent-0481选牌生命周期提示）",
      "reason": "策略类；保留原行为和已注册独立strategy-proposal，不另派同题、不补游戏知识。"
    },
    {
      "item": "core-build-notify-222802-rc2",
      "reason": "证据不足：原herdr失败原因及是否已投递未知；诊断保存已由5c92f2aaf修复，不重发或把失败改成成功。"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：队列插入顺序不等于已证明永久饥饿，保留原框架核查请求。"
    },
    {
      "item": "arch-*、回退归因、缓存和DPR/校准独立功能",
      "reason": "太大且有独立原任务/owner，不混入普通纯bug批次，不关闭父要求。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "files": 411,
    "cases": 3945
  },
  "code_proposals": [
    "silent-proposal-6a39ea0a435755c5"
  ],
  "implementation_domains": [
    "structure"
  ],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-044315-fix-batch/report.md",
  "merge_attempt": {
    "exit": 4,
    "conflicts": [
      "notes/fix-queue-v4.md",
      "notes/for-dai.md",
      "notes/for-roy.md",
      "notes/lessons.md",
      "ops/inbox-dev.md",
      "paper/data/README.md",
      "paper/data/commits.csv",
      "paper/data/cost-curve-silent.csv",
      "paper/data/cost-silent.csv",
      "paper/data/cost-sources.json",
      "paper/data/cost-unattributed.csv",
      "paper/data/decisions_by_label.csv",
      "paper/data/learning-curve-silent.csv",
      "paper/data/runs.csv",
      "paper/data/summary.json",
      "paper/data/verification.json",
      "paper/materials/20261014-s-decision/progress.json",
      "paper/materials/20261014-v5-boss-margin/ops-binding.json",
      "paper/materials/20261014-v5-boss-revalidation/ops-binding.json",
      "paper/materials/20261014-v5-jev-ablation/ops-binding.json",
      "paper/materials/decision-log.md",
      "paper/materials/learning/ledger.jsonl"
    ],
    "aborted": true,
    "preserved_refresh_commit": "fd0e9c3fa68e9c34a48e7149865c16eaf3465cef",
    "live_after_abort": "fd0e9c3fa68e9c34a48e7149865c16eaf3465cef",
    "live_tests_run": false
  },
  "ledger": {
    "silent-0459": "proposed；where.commits已由CLI追加；未标shipped"
  },
  "proposal_status": "只引用原CLI已注册结构提案；未登记implemented，源码尚非live祖先",
  "negative_controls": {
    "target": "fixture-red.log：退回原无限预算/主机时钟时失败；final-negative-controls-green.log恢复通过",
    "legacy": "event-legacy-red.log：撤ops源码时有效正向身份例失败；report-legacy-restored-green.log恢复通过",
    "report": "report-red.log首次相对路径错误、源码未撤，不能作负对照；report-red-corrected.log还原ops源码后完整报告31对预期32失败；report-legacy-restored-green.log恢复通过"
  },
  "source_checks": [
    "precommit-target.log：410文件3944项exit0",
    "precommit-legacy.log：410文件3944项exit0",
    "precommit-report.log：411文件3945项exit0"
  ],
  "limits": "未执行live合后测试或宿主完整检查；无超时重跑、无游戏源码/规则/知识提案改动。原c1角色ACK及failed/rc0/null保持，旧超时CPU根因未据本批推定。"
}
```

from pathlib import Path
import collections, gzip, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0326';pub=root/'paper/materials/20261016-0326-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-031302-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']] and all(x['reason'] for x in scratch['proposal_results'])
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions']==report['proposal_results'] and len(report['proposal_results'])==10
assert all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
registration=load(s/'ledger-registration-verification.json');assert registration['base']==report['base'] and registration['trace_updates']==26 and all(registration[x] for x in ['ledger_prefix_unchanged','protected_fields_unchanged','previous_where_history_notes_preserved','proposal_results_complete','worktree_clean'])
for x in load(s/'delivery-file-hashes.json'):assert len((s/x['file']).read_bytes())==x['bytes'] and sha((s/x['file']).read_bytes())==x['sha256']
assert load(s/'gitleaks.json')==[]
originals=load(s/'original-proposal-index.json');assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    source=Path(x['path']);saved=s/(x['id']+'.original.md');assert source.is_relative_to(root) and x['exists'] and sha(source.read_bytes())==sha(saved.read_bytes())==x['sha256']==x['expected']
extract=module('original_extract',root/'learner/extract_evidence.py');runs=load(s/'verified-runs.json')
assert len(runs)==6 and set(runs)==set(report['runs']) and all(x['character']=='SILENT' and x['ascension']==10 for x in runs.values())
counts={};manifests=[];raw_input_rows={stream:{} for stream in ['states','decisions']}
for directory in ['evidence','evidence-extra']:
    for x in load(s/directory/'evidence-manifest.json'):
        digest=hashlib.sha256();seen=collections.Counter();frozen=s/directory/(x['stream']+'.evidence.jsonl')
        with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
            for line in selected:
                digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
                assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size']
                assert extract.run_identity(row)==e['run_id'] in runs
                if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10
                if x['stream']=='runs':assert row==runs[e['run_id']]
                if x['stream'] in raw_input_rows:raw_input_rows[x['stream']][e['line']]=dict(run=e['run_id'],sha256=e['sha256'],row=row)
                seen[e['run_id']]+=1
        assert digest.hexdigest()==x['output_sha256'] and all(seen.get(run,0)==n for run,n in x['counts'].items())
        counts[x['stream']]=sum(seen.values());manifests.append(x)
assert manifests==load(s/'evidence-manifest.json') and sum(counts.values())==6995
for x in load(s/'source-byte-verification.json'):assert x['verified_rows']==counts[x['stream']]
facts=load(s/'fact-checks.json');assert len(facts)==48 and all(x['passed'] and x['observed']==x['expected'] for x in facts)
source=load(s/'source-verification.json');assert source['base']==report['base'] and len(source['paths'])==14
assert git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_snapshot']
for x in source['paths']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_snapshot']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (root/'.worktrees/live'/x['path']).read_bytes()==z
    assert (a==z)==x['same'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and x['commit_live_ancestor']
    git('merge-base','--is-ancestor',x['last_base_path_commit'],source['live_snapshot'])
assert sum(x['same'] for x in source['paths'])==12
narrow=load(s/'narrow-source-ancestors.json')
for x in narrow:
    assert x['live_ancestor'];git('merge-base','--is-ancestor',x['commit'],source['live_snapshot'])
for x in load(s/'offline-file-hashes.json'):
    raw=(s/'offline'/x['file']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
consumers=load(s/'offline-receipts.json');summary=load(s/'offline-summary.json');assert len(consumers)==len(summary)==6
assert sum(x['fullError'] is None for x in consumers)==3 and sum(len(x['excluded']) for x in consumers)==5;totals=collections.Counter();consumer_readbacks=[]
for x in consumers:
    path=Path(x['inputPath']);assert path==s/'offline'/(x['run']+'.input.json.gz')
    full=json.loads(gzip.decompress(path.read_bytes()));assert full['run']==runs[x['run']]
    for stream in ['states','decisions']:
        for row in full[stream]:
            original=raw_input_rows[stream][row['_line']]
            assert original['run']==x['run'] and row['_source_sha256']==original['sha256'] and {k:v for k,v in row.items() if k not in ['_line','_source_sha256']}==original['row']
        assert len(full[stream])==next(m['counts'][x['run']] for m in manifests if m['stream']==stream)
    missing=[row for row in full['decisions'] if not row.get('decision_id')]
    if x['fullError']:
        assert 'decision_id' in x['fullError'] and missing==[item['row'] for item in x['excluded']]
        assert all(row['label']=='map/route-change' and not row.get('chosen') for row in missing)
        bounded=json.loads(gzip.decompress((s/'offline'/(x['run']+'.bounded.input.json.gz')).read_bytes()))
        assert bounded['run']==full['run'] and bounded['states']==full['states'] and bounded['decisions']==[row for row in full['decisions'] if row.get('decision_id')]
        del bounded
    else:assert not missing and x['excluded']==[]
    audit=json.loads(gzip.decompress((s/'offline'/(x['run']+'.output.json.gz')).read_bytes()))
    status=collections.Counter(row['status'] for row in audit['observed_turns']);interval=collections.Counter(row['observed_interval']['status'] for row in audit['observed_actions'])
    c=dict(run=x['run'],segments=len(audit['segments']),actions=len(audit['observed_actions']),adjacent_action_endpoints=interval['observed_endpoints'],terminal_endpoints=sum(isinstance(row['terminal_observation'],dict) and row['terminal_observation'].get('status')=='observed_terminal_endpoints' for row in audit['observed_actions']),turn_endpoints=status['observed_turn_endpoints'],unknown_turns=status['unknown'],full_input_accepted=x['fullError'] is None,excluded_rows=len(missing))
    recorded=next(v for v in summary if v['run']==x['run']);assert c==recorded,(c,recorded,dict(interval))
    assert all(row['actual_full_candidate_result'] is None for row in audit['segments'])
    totals.update({k:c[k] for k in ['segments','actions','adjacent_action_endpoints','terminal_endpoints','turn_endpoints','unknown_turns']});consumer_readbacks.append(c)
    del full,audit
assert totals==dict(segments=476,actions=3301,adjacent_action_endpoints=859,terminal_endpoints=4,turn_endpoints=121,unknown_turns=413)
inputs=[json.loads(line) for line in (s/'ledger-updates.jsonl').read_text().splitlines()];assert len(inputs)==26 and {x['id'] for x in inputs}==set((s/'ledger-cli.stdout').read_text().split());assert (s/'ledger-cli.stderr').read_bytes()==b''
prefix=load(s/'ledger-prefix-before.json');own=[];rows=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    frozen=handle.read(prefix['bytes']);assert sha(frozen)==prefix['sha256'];line_number=frozen.count(b'\n')
    while True:
        offset=handle.tell();raw=handle.readline()
        if not raw:break
        line_number+=1;row=json.loads(raw)
        if row.get('by')!='learner:strategy-proposal' or not row.get('note','').startswith(bid+'：'):continue
        assert set(row)<={'op','id','ts','by','where','note'} and row['op']=='update'
        assert {k:v for k,v in row.items() if k not in ['op','ts']}==inputs[len(own)]
        own.append(raw);rows.append(dict(line=line_number,offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
assert len(own)==len(set(own))==26
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert all(raw.rstrip(b'\n') not in set(old.splitlines()) for raw in own);added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
for failure in p.glob('ops-*-failure.log'):(pub/failure.name).write_bytes(failure.read_bytes())
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,scratch_result_difference='Detailed scratch waiting reasons are shortened in final stdout; all ten IDs and states and every other field agree. Initial ops strict-equality failure preserved; neither original rewritten.',original_gate=b['no_change_proposals'],native=native,original_registration=registration,source=source,narrow_sources=narrow,stream_counts=counts,raw_receipts=manifests,original_rows_verified=6995,original_material_checks=48,material_checks_not_reexecuted=True,original_consumers=consumers,offline_totals=dict(totals),consumer_readbacks=consumer_readbacks,consumers_not_reexecuted=True,owned_trace_rows=rows,protected_fields_and_prefixes_preserved=True,limits=['Three complete and three bounded offline inputs do not certify whole-candidate execution or controlled whole-fight/resource successors.','Five idless route metadata rows, complete-input rejection receipts and original physical line numbers retained.','Original path probes and truncated display are not product failures or new counterevidence.','Same-run SL is correlated; historical dirty inputs and incomplete attribution/calibration remain unknown.','Existing narrow shipped implementations and broad waiting proposals remain distinct.','No production tests, merge, release, paper refresh, dispatch or game action.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',s/'evidence-extra/evidence-manifest.json',out,out.with_suffix('.err')]
    for sourcefile in sorted(files):
        raw=sourcefile.read_bytes();rel=str(sourcefile.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(sourcefile,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0326原031302策略done0/no-source核收，193350基线干净WT/HEAD不变；十waiting及具体缺口/testsnull/mergednull保持，无合入受阻。六Silent A10八流6995原行逐offset/bytes/SHA/JSON/身份核，48原材料断言首跑通过，不重跑或冒生产测试；十四源码叶12同2历史Roy/Dai注释差与五窄来源/十四路径真实live祖先核，不以局部升级传播或候选诊断关闭宽请求。六原离线gzip input/output SHA及逐输入原行绑定核，三完整/三有界（五无ID路线元数据原件及拒收保留、不重编号），476片段/3301动作/859相邻端点/4终态端点/121轮端点/413未知；完整候选结果全null不等没有执行或没有收益，不当受控整战/后置盲测。26所属CLI只where/note，原真实前缀/offset/SHA及私有fold核，旧claim/首证/prior/evidence/status/version和history/notes/where前缀保持，不重复CLI。原路径猜测和宽输出截断不当产品故障/反证；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核，历史dirty消费/成长分源/换序后继未知保持。仅本人记录/26追溯提交，保并行记录；不合入/发号/补测/刷新论文/复派或关闭宽父。证据paper/materials/20261016-0326-ops/。\n'
note=f'\n- {at} [运维 codex] 原031302十项继续waiting，无源码修改或合入受阻；6995原行、48原材料检查及26所属追溯已核。三完整/三有界离线读回保留拒收与未知，不作整战或生产测试通过；无新发布或补测。回执paper/materials/20261016-0326-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=26,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True)
(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=6995,owned_trace_rows=26,ledger_check=0,paths=len(entries))))

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
path = ROOT / 'paper/materials/learning/ledger.jsonl'
prefix = json.loads((S / 'ledger-prefix-before.json').read_text())
with path.open('rb') as handle:
    assert hashlib.sha256(handle.read(prefix['bytes'])).hexdigest() == prefix['sha256']
    tail = handle.read().decode()
rows = [json.loads(x) for x in tail.splitlines() if x]
ours = [x for x in rows if x.get('by') == 'learner:strategy-proposal' and
        x.get('note', '').startswith('20261016-031302-strategy-proposal：')]
inputs = [json.loads(x) for x in (S / 'ledger-updates.jsonl').read_text().splitlines()]
assert len(ours) == len(inputs) == 26
for expected, actual in zip(inputs, ours):
    assert {k: v for k, v in actual.items() if k not in ('op', 'ts')} == expected
    assert actual['op'] == 'update'

spec = importlib.util.spec_from_file_location('ledger_registration_verification', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
before = json.loads((S / 'ledger-before-registration.json').read_text())
after = ledger.fold(ledger.read_rows(str(path)))
private = json.loads(json.dumps(before))
for row in ours:
    ledger.apply(private, row)
protected = [key for key in next(iter(before.values())) if key not in ('where', 'history', 'notes')]
for ident in before:
    assert all(private[ident].get(key) == before[ident].get(key) for key in protected)
    assert all(after[ident].get(key) == before[ident].get(key) for key in protected), ident
    assert after[ident]['history'][:len(before[ident]['history'])] == before[ident]['history']
    assert after[ident]['notes'][:len(before[ident]['notes'])] == before[ident]['notes']
    for key, values in before[ident]['where'].items():
        assert all(value in after[ident]['where'][key] for value in values)
    assert str(S / 'proposal.md') in after[ident]['where']['proposal']
    assert str(S / 'report.md') in after[ident]['where']['proposal']

result = json.loads((S / 'result.json').read_text())
result['skipped'] = []
(S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
assigned = json.loads((S / 'dispatch.json').read_text())
assert set(assigned['proposal_ids']) == {x['id'] for x in result['proposal_results']}
assert all(x['state'] == 'waiting' and x['reason'] for x in result['proposal_results'])
assert len(result['proposal_results']) == len(set(assigned['proposal_ids'])) == 10
assert result['fixes'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['implementation_domains'] == []
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == result['base']
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True) == ''
assert subprocess.check_output(['git', 'diff', '--binary', result['base']], text=True) == ''
receipt = {'ledger_prefix_unchanged': True, 'trace_updates': len(ours),
           'protected_fields_unchanged': True, 'previous_where_history_notes_preserved': True,
           'proposal_results_complete': True, 'base': result['base'], 'worktree_clean': True}
(S / 'ledger-registration-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

import gzip
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
RUNS = json.loads((S / 'dispatch.json').read_text())['runs']
FLOORS = dict(zip(RUNS, [{35, 36, 37, 43, 44, 45}, {17, 33}, {13}, {33, 39}, {17, 23}, {30}]))

def save(name, value):
    (S / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def identity(row):
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = None
    vals = [row.get('run_id'), row.get('run'), row.get('state', {}).get('run_id'),
            fp.get('run') if isinstance(fp, dict) else None]
    ids = {v for v in vals if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(ids)) if len(ids) == 1 else None

data, verification, manifests = {}, [], []
for folder in ('evidence', 'evidence-extra'):
    for manifest in json.loads((S / folder / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        data[stream] = []
        output = S / folder / (stream + '.evidence.jsonl')
        assert hashlib.sha256(output.read_bytes()).hexdigest() == manifest['output_sha256']
        counts = dict.fromkeys(RUNS, 0)
        with Path('/home/dw/Projects/agent-sts2/logs', stream + '.jsonl').open('rb') as source:
            for line in output.open():
                item = json.loads(line)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                assert identity(item['row']) == item['run_id'] in RUNS
                counts[item['run_id']] += 1
                data[stream].append(item)
        assert counts == manifest['counts']
        verification.append({'stream': stream, 'verified_rows': sum(counts.values()), 'counts': counts})
        manifests.append(manifest)
save('evidence-manifest.json', manifests)
save('source-byte-verification.json', verification)

runrows = {x['run_id']: x['row'] for x in data['runs']}
assert set(runrows) == set(RUNS)
assert all(x['character'] == 'SILENT' and x['ascension'] == 10 for x in runrows.values())
save('verified-runs.json', runrows)

def input_row(item):
    return {**item['row'], '_line': item['line'], '_source_sha256': item['sha256']}

for run in RUNS:
    payload = {'run': runrows[run],
               'decisions': [input_row(x) for x in data['decisions'] if x['run_id'] == run],
               'states': [input_row(x) for x in data['states'] if x['run_id'] == run]}
    (S / 'offline').mkdir(exist_ok=True)
    with gzip.open(S / 'offline' / (run + '.input.json.gz'), 'wt') as handle:
        json.dump(payload, handle, ensure_ascii=False)

def powers(values):
    return {x.get('power_id', x.get('id')): x.get('amount', x.get('stacks')) for x in values or []}

facts = []
for item in data['states']:
    row = item['row']; state = row['state']; run = state.get('run') or {}; combat = state.get('combat') or {}
    if run.get('floor') not in FLOORS[item['run_id']]:
        continue
    player = combat.get('player') or {}
    facts.append({'run': item['run_id'], 'line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
                  'ts': row.get('observed_ts'), 'floor': run.get('floor'), 'turn': state.get('turn'),
                  'screen': state.get('screen'), 'hp': player.get('current_hp', run.get('current_hp')),
                  'block': player.get('block'), 'energy': player.get('energy'), 'powers': powers(player.get('powers')),
                  'enemies': [{'id': x.get('enemy_id'), 'hp': x.get('current_hp'), 'block': x.get('block'),
                               'powers': powers(x.get('powers')), 'intents': x.get('intents'),
                               'move': x.get('move_id')} for x in combat.get('enemies') or []],
                  'hand': [{'id': x.get('card_id'), 'upgraded': x.get('upgraded'), 'cost': x.get('energy_cost'),
                            'values': x.get('dynamic_values')} for x in combat.get('hand') or []],
                  'deck_upgraded': sum(bool(x.get('upgraded')) for x in run.get('deck') or [])})
save('selected-state-facts.json', facts)
selected = [x for x in data['decisions'] if x['row'].get('floor') in FLOORS[x['run_id']]]
save('selected-decisions.json', selected)
save('sl-attempt-facts.json', data['sl-attempts'])
print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in verification),
                  'selected_states': len(facts), 'selected_decisions': len(selected)}, ensure_ascii=False))

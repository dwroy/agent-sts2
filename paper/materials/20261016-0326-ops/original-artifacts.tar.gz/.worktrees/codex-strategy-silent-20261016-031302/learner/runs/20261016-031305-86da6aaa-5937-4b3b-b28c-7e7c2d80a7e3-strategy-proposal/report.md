# 静默策略队列：十项证据复核报告

记录时间：2026-10-16T03:23:33+08:00。task=strategy-proposal，character=silent，batch=20261016-031302-strategy-proposal。

## 结果

十项均waiting，逐项具体缺口见下表和proposal.md。没有新的可据实实施的机制缺口或足以制定策略常数的受控数据；已有窄源码不关闭宽请求。无源码/知识修改、源码提交、live合入、eval版本或新shipped；fixes=[]、merged=null、implementation_domains=[]。

## 身份与基线

开工git status干净，HEAD=193350090b1ffba613c52d80c759f82ad378b8a3；普通批按任务执行git merge --no-edit main，结果Already up to date。只读根learn.json本批task/character/worktree/runs/proposal_ids，绑定十项、reason=proposal、state=running，无research_request、implementation_request或proposal_repair。普通专题根请求绑定其他旧batch，不承接专题、不读另一个专题替代身份。独立完成，没有下级agent。

已读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol、learning-code-proposals和相关fix-queue-v4定位。十份原提案SHA逐项匹配，并核对26个原账本和19个关联的本角色经验条目；原文及历史复盘保持。本批未独立读取原生会话请求以证明模型/推理强度，不能从模板文字或旧对局run-config推定本会话实际配置。

六局runs原行均SILENT/A10；历史运行码全部带dirty，不能靠当前Git恢复完整旧源码/知识/RNG。六独立局与同局SL尝试分开。

## 原始证据与材料核验

只用共用extract_evidence.py抽取八流，逐流冻结source_size；再次按每条offset/bytes读取原字节、复核SHA256、JSON对象、所属身份及逐局计数，共6995条。身份核run_id/state.run_id/run/fingerprint.run，冲突或仅正文提及不接收。两个manifest合并索引见evidence-manifest.json，原manifest分别保留；source-byte-verification.json保存实际读回计数。

| 流 | source_size字节 | 本六局行数 |
|---|---:|---:|
| states | 13277522540 | 3432 |
| decisions | 1751459213 | 3306 |
| sl-attempts | 42034540 | 29 |
| run-config | 1812708 | 6 |
| run-plans | 8294380 | 33 |
| brain | 623766210 | 183 |
| runs | 341549 | 6 |
| fight-plans | 2233957 | 0 |

fight-plans此截点0行只表示未选到，不能断言原日志缺失。全源states/decisions各2条、brain1条无效JSON，不据全源计数归因本六局。没有复核旧run-plans截点或覆盖原零行报告。

784个相关状态、759个相关决策的事实投影另存；48项固定原帧材料断言通过，见fact-checks.json/check-facts.log。这是材料核验，不是生产测试、策略收益或红绿负控。

重新核实：VLZ F43同序列43伤/14损→51伤/13损，实端点51/13；F45实际痊愈药水+1能/+2牌而HP不变。F45末32血/20挡对59攻击，完整需损39、实际死亡只扣32，三敌仍21/77/80。8JRE第三试T2原预测0/24与5/24并非同死率，进一步损失饱和值均47；首/第三试整轮−3/−15玩家HP、−10/−17敌HP，明确多付12血只多净扣7。末T11单次结束端点只实扣5，37−22=15是显示需求，不冒已观测完整伤害。

CA5蚌力0→4→8，喷水15→11及19→14弱后仍成长；本局关键盘面无正敏捷。5PM无毒冒泡5→4能而目标35血/0毒不变，玩家29血不误作35。61E吸取后力2→0、敏0→−2，两防御各3，毒17+16净扣33；F23T4净扣47仍实损15，幻象2血未退场。DUZU末试甲虫力2→−4→4与攻击20→14→22，不将临减当成长关闭；1血16挡对22的完整需求6与实扣1分列。

## 当前离线消费者读回

以六局全部冻结原状态/决策构造gzip输入，保留原_line/decision_id/observed_ts/fingerprint/SHA。调用本基线learner/lib/selection-execution.ts，单进程nice19，无LLM/网络、刷新知识或游戏。VLZ、8JRE、5PM完整输入实际接受；另三局完整输入因无decision_id元数据行被严格拒收，保留原输入与异常回执。只为有界读回剔除CA5一条、61E一条、DUZU三条，原行与原物理行号保留，未重新编号。该拒收是输入契约，不是生产故障。

| 局 | 有ID动作 | 候选片段 | 相邻动作端点 | 终态端点 | 整轮端点 | 未知轮窗 |
|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |

合计3301有ID动作、476片段、859相邻动作端点、4终态端点、121整轮端点、413未知轮窗。所有完整候选结果仍null；有端点不等完整方案已执行，也不等没有执行过或没有收益。敌唯一类型端点不是召唤实例身份。输入/输出字节与SHA见offline-file-hashes.json；原完整拒收与有界范围见offline-receipts.json。

## 当前源码及实际上线边界

只读live快照=e716bd28fd8eca9e4d76d066680304fd11935e37。14精确路径中12与base字节一致，card-model.ts和rollout-live.ts仅有历史Roy/Dai注释差，差异原字节保留于source-live-diff.patch，未归一化。14条最近路径变更提交均核实际live祖先，明细source-verification.json；这不是本批源码提交、合入或完整实现证明。

独立核实的窄源码祖先含3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化事实参考）、05cd292c6f01bb31e406473d3a9843e659d62b93（候选事实）、a8b1f8be153fe4f3a34146117546c2178f2e446b（有限接续）、cf72bd21148059f111f760cc98a727369e34a47e（离线药槽观测）和ba23ca693151fa8c6f7fe035e640dc30f05ccd75（致命毒药升级），见narrow-source-ancestors.json。实际神化施放字段仍明确null；候选审计actual_turn、单动作whole_plan_executed、护栏actual_outcome也未认证。已有升卡白名单/同线/后抽路径及未知标记保留，无理由用局部成功把宽提案置implemented/duplicate。

## 逐项处置

| id | 账本 | 处置及缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | silent-0237, silent-0238 | waiting：已有同线及后抽升级传播；actual_cast_this_fight仍为null，缺跨重问、选牌、药水、SL与换战的持续施放归属，以及未覆盖升级组合的生产校准。 |
| silent-proposal-f2bfceddb1898dca | silent-0106, silent-0019, silent-0201 | waiting：缺完整模型下同起点、同随机池、同总预算的分阶段MC配对与候选稳定性曲线；单题707ms和1/12样本不能确定新预算、留药或目标规则。 |
| silent-proposal-283a164780d11e69 | silent-0237, silent-0238 | waiting：与原神化提案同源；仍缺实际施放持续归属和未覆盖交互校准，已有窄实现不足以将整个提案登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019 | waiting：缺十五经验全部组合、属性期限、升级联动及战斗/路线/休息消费者的冻结联合校准；局部数值核对不证明完整覆盖。 |
| silent-proposal-e5b87be50f28f311 | silent-0079, silent-0021, silent-0125, silent-0018 | waiting：已有预测、单动作回执及离线观测端点；113个本局候选片段均未认证完整执行，仍缺跨重规划的持续候选归属及成长分源。 |
| silent-proposal-49632bc4878fb597 | silent-0005, silent-0231 | waiting：蚌增力与虚弱端点已核，但本局关键盘面没有正敏捷实测；缺力量、正负敏捷、虚弱和独立成长的联合生产调用校准。 |
| silent-proposal-66532328a585941f | silent-0021, silent-0009 | waiting：无毒冒泡确实耗1能且不施毒；仍缺同HP/牌组/药水/完整抽序下不同启动顺序的受控整战配对与可复现收益函数。 |
| silent-proposal-43a76a31ba7bdcfa | silent-0030, silent-0027 | waiting：吸取、负敏捷双防御和毒端点已核；缺同起始资源与完整抽序的SL整战配对，首试胜利不足以改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | silent-0039, silent-0209 | waiting：已有召唤局部实现；缺A10召唤、退场、再现和成长全链联合生产校准及另一目标顺序的完整后继，不能指定统一首杀。 |
| silent-proposal-bddfa690a84e03d0 | silent-0128, silent-0079 | waiting：醒来、临减恢复与成长端点已核；缺伤害唤醒/眩晕全链联合校准和同抽换序完整后继，四次相关失败不能确定血价或杀序。 |

证据局号/层/回合、反例、预期行为、验证与回退逐项见/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-031302/learner/runs/20261016-031305-86da6aaa-5937-4b3b-b28c-7e7c2d80a7e3-strategy-proposal/proposal.md。不新增重复提案id、不改原提案/根请求/队列/learn.json，不关闭学习父要求。code_proposals使用这十个真实原CLI id。

## 验证与交接

没有生产代码提交，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试、未借用历史绿。无需运行live合入流程、知识刷新提交、版本或上线通知。材料脚本都只放本批scratch，没有可执行.ts源码副本；没有npm install、联网、play、推送、读取key/.env/游戏二进制或改其他角色知识。

本批只经根ledger.py update追加by=learner:strategy-proposal的提案/报告追溯链接与说明；不重复证据，不设置status、不把shipped降为proposed。没有新增待设proposed的知识条目。实际CLI读回另附ledger-registration-verification.json。

读取过程有过旧路径猜测失败（selection.ts、enemy-turn.ts、replay_selection_audit.py、eye/loop.ts、lessons-silent.md不存在）及宽输出截断；已按rg --files定位真实入口并从已存原件缩窄读取，不当证据缺失或产品bug，不宣称对应生产测试失败。完整输入缺ID拒收原件保留；48材料断言首跑通过，没有源码负控。

冻结六局均为历史发现样本；没有受控替线路线/留药/完整候选因果、独立后置盲测或胜率提升证据。具体未知保留waiting；经验入库与实际消费者采用不因本报告完成而关闭。

交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-031302/learner/runs/20261016-031305-86da6aaa-5937-4b3b-b28c-7e7c2d80a7e3-strategy-proposal/proposal.md
报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-031302/learner/runs/20261016-031305-86da6aaa-5937-4b3b-b28c-7e7c2d80a7e3-strategy-proposal/report.md

最终读回：根ledger.py update实际退出0、stderr空，26条本角色追溯追加逐输入/实际存储行核对；原物理前缀SHA不变，原claim/status/version/evidence/first_run/asc/prior等保护字段及旧where/history/notes均保持。10个proposal_results完整匹配派发集合。HEAD仍为base、git status与diff均为空。最终四份交付文本的gitleaks redacted stdin扫描结果见gitleaks.log/gitleaks.json；未创建提交。

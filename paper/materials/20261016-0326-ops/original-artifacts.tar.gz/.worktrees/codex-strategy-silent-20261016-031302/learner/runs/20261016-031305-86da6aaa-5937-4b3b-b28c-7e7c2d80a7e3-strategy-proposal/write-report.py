import datetime
import json
from pathlib import Path

S = Path(__file__).resolve().parent
dispatch = json.loads((S / 'dispatch.json').read_text())
proposals = json.loads((S / 'assigned-proposals.json').read_text())
base = json.loads((S / 'source-verification.json').read_text())['base']
live = json.loads((S / 'source-verification.json').read_text())['live_snapshot']
stamp = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
reasons = [
    '已有同线及后抽升级传播；actual_cast_this_fight仍为null，缺跨重问、选牌、药水、SL与换战的持续施放归属，以及未覆盖升级组合的生产校准。',
    '缺完整模型下同起点、同随机池、同总预算的分阶段MC配对与候选稳定性曲线；单题707ms和1/12样本不能确定新预算、留药或目标规则。',
    '与原神化提案同源；仍缺实际施放持续归属和未覆盖交互校准，已有窄实现不足以将整个提案登记duplicate。',
    '缺十五经验全部组合、属性期限、升级联动及战斗/路线/休息消费者的冻结联合校准；局部数值核对不证明完整覆盖。',
    '已有预测、单动作回执及离线观测端点；113个本局候选片段均未认证完整执行，仍缺跨重规划的持续候选归属及成长分源。',
    '蚌增力与虚弱端点已核，但本局关键盘面没有正敏捷实测；缺力量、正负敏捷、虚弱和独立成长的联合生产调用校准。',
    '无毒冒泡确实耗1能且不施毒；仍缺同HP/牌组/药水/完整抽序下不同启动顺序的受控整战配对与可复现收益函数。',
    '吸取、负敏捷双防御和毒端点已核；缺同起始资源与完整抽序的SL整战配对，首试胜利不足以改变SL范围或阈值。',
    '已有召唤局部实现；缺A10召唤、退场、再现和成长全链联合生产校准及另一目标顺序的完整后继，不能指定统一首杀。',
    '醒来、临减恢复与成长端点已核；缺伤害唤醒/眩晕全链联合校准和同抽换序完整后继，四次相关失败不能确定血价或杀序。',
]
evidence = [
    'VLZ6CCT8AQ0A F35T1 s275564→275565；F43T1 d269706/269707、s275679→275687；F45T1 s275722→275732。',
    'VLZ6CCT8AQ0A F45T1 d269748/269754；F45T4 d269770；F45T5 s275752/275754/275755。',
    'VLZ6CCT8AQ0A F35T1、F43T1、F45T1，同第一项；另核F36/F37已有限定5→7毒升级来源。',
    'VLZ6CCT8AQ0A F43T1—T5、F45T1—T5；当前3敏捷、4勒紧、20挡、0覆甲和59攻击分列。',
    '8JRE1C4H4Z2W F33首/第三试T2 d270216/270282；第二试T5 d270264；末试T11 s276433→276434。',
    'CA5KE8GFJ9X2 F13T1/T3/T5 s273238/273252/273254/273263/273268/273269。',
    '5PM6JAQG6FNQ F39末试T2 s274379→274380；F33已建立能力的胜局与F39不作受控比较。',
    '61E2QS63Y9WU F17T5—T7 s273503→273508；吸取后力量2→0、敏捷0→−2、两防御各3。',
    '61E2QS63Y9WU F23T4—T5 s273593→273598；净扣47、损15，幻象仍2血；T5才退场。',
    'DUZUBAJ3A8GP F30末试T4—T6 s275007→275023；T5/T6敌力2→−4→4，攻击20→14→22。',
]
counterexamples = [
    'F43实际施放仍损57，F45未施放而败；不同盘面不能证明必打神化或胜率因果。',
    'F17/F33首试赢；F45T4另一攻击候选未执行。不能由全败推演或退化推出固定focus、必喝或必留。',
    '与第一项相同，同局多次施放不增加独立局数；未知升级保持未知。',
    '机制兑现仍可能死亡；当前毒/覆甲/临时减力和未来资源分别记账，不能预支能力或永久减伤。',
    '末试T2防御替换延至T11仍败，反对一律取消防御；首/第三试T2相同指纹不等后续抽序已完全受控。',
    '虚弱没有取消加压；计划中的步法没有取得，不补正敏捷，也不据败局重设血价。',
    'F33能力已建立并赢，但敌人与资源不同；空打无效只支持本步条件，不能证明提前启动足够获胜。',
    '本局族母首试七轮赢，没有未选整战线；不搬其他局SL失败制定本局或统一规则。',
    '另一39伤零损focus幻象候选未实打；enemy_id是类型，同类型比较不认证召唤代际。',
    '末试T4比首试多扣3敌血也多损2血；四试同源，不当四个独立训练样本或胜线。',
]
validation = [
    '冻结F35升级前后和F43同序列夹具；逐牌覆盖、后抽传播、能耗/消耗及场外deck不变；持续身份须跨各重规划边界并有独立实盘消费者。',
    '在模型覆盖已核的同盘输入上冻结RNG、知识、总预算和候选集合，配对现策略与分阶段MC；记录原始时钟、样本与排序稳定性，不由预算截断拟合常数。',
    '沿第一项同源夹具与原id去重接续，不新建重复id；未知属性/自动出牌/重放组合须另有本角色数据。',
    '逐条冻结十五经验的状态来源、属性修正、到期/结算和三个消费者入口；相同推演值并列，保留全部选项和未知。',
    '冻结原答、护栏后、SL后、派发和重问边界；观察端点与候选因果分离；持续身份不足时不能把整轮差值归给原候选。',
    '冻结同一生产调用的手牌、当前力量/敏捷/弱与敌成长表；按已观察进阶查HP/伤害，逐击和逐牌核对，缺正敏捷部分不补推断。',
    '相同起始资源与完整抽序下配对不同建立时点；持有/计划/已建立/结算分账，至少取得完整后继后才评估收益函数。',
    '同起始资源和完整抽序的整场SL线路配对，保留吸取、临时减力恢复、负敏捷及毒逐次结算，不由首试胜利扩大SL范围。',
    '固定A10召唤/航行/退场/再现及实体身份全链；比较另一个完整目标顺序前，保留合法目标和并列排名。',
    '分别冻结自然倒计时、伤害唤醒、眩晕、临时减力到期和成长；在同抽完整后继上验证换序，不从全败样本拟合权重。',
]
head = f'''# 本批静默十项策略提案复核

记录时间：{stamp}。batch=20261016-031302-strategy-proposal；来源/实现任务均沿各原提案，当前消费者为strategy-proposal。

本批只处理十个已领取id，全部waiting。无新增游戏结论、源码/知识修改或新id。授权Roy-2026-10-07-learning提供修改权限，不提供游戏事实。基线为{base}；merge main结果Already up to date。

六局均已从runs原字节核实SILENT/A10；SL不扩大独立局数。原提案Markdown十份均实际存在且SHA与注册一致，原文副本与索引保留于本目录。不读取其他角色私有知识，不将旧经验的广范围/历史支持数冒成本批验证。

当前源码已有窄实现，原请求仍缺的范围在各项明确列出。旧行为保持；拟实现行为沿原提案的状态变换/事实参考或审计要求，不新增必打、必喝、固定首杀、血价或SL阈值。生产变更须有新证据、固定夹具、撤源码失败/恢复通过及原沙箱自测；这里只核材料，无生产测试或发布。
'''
parts = [head]
for index, p in enumerate(proposals):
    parts.append(f'''\n## {index + 1}. {p['id']}

原摘要：{p['summary']}

来源：{p['source_task']}；实现任务：strategy-proposal；角色/进阶：silent/A10。
账本：{', '.join(p['ledger'])}。原经验：{', '.join(p.get('experience', [])) or '沿原账本；本批没有新增经验'}。
证据：{evidence[index]}

反例/限制：{counterexamples[index]}

处置：waiting。{reasons[index]}

预期行为与验证：{validation[index]} 本批不拟合新系数；六局都是历史发现/回归输入，不称盲测。若以后拟合，以run_id分组并用时间后置同角色局检验，不能以SL次数拆训练/验证。

预期影响：补足可核的模型或审计边界；整战/路线/留药收益未知。没有源码可回退；未来实现按各自独立源码提交回退，保留原日志、账本、提案、反例和失败记录。窄源码的live祖先不能替代整个请求的实现证明。
''')
(S / 'proposal.md').write_text(''.join(parts))
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(proposals, reasons)]
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-031302-strategy-proposal',
         'base': base, 'runs': dispatch['runs'], 'fixes': [],
         'skipped': [],
         'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': [p['id'] for p in proposals], 'implementation_domains': [],
         'proposal_results': results, 'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
manifests = json.loads((S / 'evidence-manifest.json').read_text())
summary = json.loads((S / 'offline-summary.json').read_text())
report = f'''# 静默策略队列：十项证据复核报告

记录时间：{stamp}。task=strategy-proposal，character=silent，batch=20261016-031302-strategy-proposal。

## 结果

十项均waiting，逐项具体缺口见下表和proposal.md。没有新的可据实实施的机制缺口或足以制定策略常数的受控数据；已有窄源码不关闭宽请求。无源码/知识修改、源码提交、live合入、eval版本或新shipped；fixes=[]、merged=null、implementation_domains=[]。

## 身份与基线

开工git status干净，HEAD={base}；普通批按任务执行git merge --no-edit main，结果Already up to date。只读根learn.json本批task/character/worktree/runs/proposal_ids，绑定十项、reason=proposal、state=running，无research_request、implementation_request或proposal_repair。普通专题根请求绑定其他旧batch，不承接专题、不读另一个专题替代身份。独立完成，没有下级agent。

已读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol、learning-code-proposals和相关fix-queue-v4定位。十份原提案SHA逐项匹配，并核对26个原账本和19个关联的本角色经验条目；原文及历史复盘保持。本批未独立读取原生会话请求以证明模型/推理强度，不能从模板文字或旧对局run-config推定本会话实际配置。

六局runs原行均SILENT/A10；历史运行码全部带dirty，不能靠当前Git恢复完整旧源码/知识/RNG。六独立局与同局SL尝试分开。

## 原始证据与材料核验

只用共用extract_evidence.py抽取八流，逐流冻结source_size；再次按每条offset/bytes读取原字节、复核SHA256、JSON对象、所属身份及逐局计数，共6995条。身份核run_id/state.run_id/run/fingerprint.run，冲突或仅正文提及不接收。两个manifest合并索引见evidence-manifest.json，原manifest分别保留；source-byte-verification.json保存实际读回计数。

| 流 | source_size字节 | 本六局行数 |
|---|---:|---:|
'''
for m in manifests:
    report += f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} |\n"
report += '''
fight-plans此截点0行只表示未选到，不能断言原日志缺失。全源states/decisions各2条、brain1条无效JSON，不据全源计数归因本六局。没有复核旧run-plans截点或覆盖原零行报告。

784个相关状态、759个相关决策的事实投影另存；48项固定原帧材料断言通过，见fact-checks.json/check-facts.log。这是材料核验，不是生产测试、策略收益或红绿负控。

重新核实：VLZ F43同序列43伤/14损→51伤/13损，实端点51/13；F45实际痊愈药水+1能/+2牌而HP不变。F45末32血/20挡对59攻击，完整需损39、实际死亡只扣32，三敌仍21/77/80。8JRE第三试T2原预测0/24与5/24并非同死率，进一步损失饱和值均47；首/第三试整轮−3/−15玩家HP、−10/−17敌HP，明确多付12血只多净扣7。末T11单次结束端点只实扣5，37−22=15是显示需求，不冒已观测完整伤害。

CA5蚌力0→4→8，喷水15→11及19→14弱后仍成长；本局关键盘面无正敏捷。5PM无毒冒泡5→4能而目标35血/0毒不变，玩家29血不误作35。61E吸取后力2→0、敏0→−2，两防御各3，毒17+16净扣33；F23T4净扣47仍实损15，幻象2血未退场。DUZU末试甲虫力2→−4→4与攻击20→14→22，不将临减当成长关闭；1血16挡对22的完整需求6与实扣1分列。

## 当前离线消费者读回

以六局全部冻结原状态/决策构造gzip输入，保留原_line/decision_id/observed_ts/fingerprint/SHA。调用本基线learner/lib/selection-execution.ts，单进程nice19，无LLM/网络、刷新知识或游戏。VLZ、8JRE、5PM完整输入实际接受；另三局完整输入因无decision_id元数据行被严格拒收，保留原输入与异常回执。只为有界读回剔除CA5一条、61E一条、DUZU三条，原行与原物理行号保留，未重新编号。该拒收是输入契约，不是生产故障。

| 局 | 有ID动作 | 候选片段 | 相邻动作端点 | 终态端点 | 整轮端点 | 未知轮窗 |
|---|---:|---:|---:|---:|---:|---:|
'''
for x in summary:
    report += f"| {x['run']} | {x['actions']} | {x['segments']} | {x['adjacent_action_endpoints']} | {x['terminal_endpoints']} | {x['turn_endpoints']} | {x['unknown_turns']} |\n"
report += f'''
合计3301有ID动作、476片段、859相邻动作端点、4终态端点、121整轮端点、413未知轮窗。所有完整候选结果仍null；有端点不等完整方案已执行，也不等没有执行过或没有收益。敌唯一类型端点不是召唤实例身份。输入/输出字节与SHA见offline-file-hashes.json；原完整拒收与有界范围见offline-receipts.json。

## 当前源码及实际上线边界

只读live快照={live}。14精确路径中12与base字节一致，card-model.ts和rollout-live.ts仅有历史Roy/Dai注释差，差异原字节保留于source-live-diff.patch，未归一化。14条最近路径变更提交均核实际live祖先，明细source-verification.json；这不是本批源码提交、合入或完整实现证明。

独立核实的窄源码祖先含3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化事实参考）、05cd292c6f01bb31e406473d3a9843e659d62b93（候选事实）、a8b1f8be153fe4f3a34146117546c2178f2e446b（有限接续）、cf72bd21148059f111f760cc98a727369e34a47e（离线药槽观测）和ba23ca693151fa8c6f7fe035e640dc30f05ccd75（致命毒药升级），见narrow-source-ancestors.json。实际神化施放字段仍明确null；候选审计actual_turn、单动作whole_plan_executed、护栏actual_outcome也未认证。已有升卡白名单/同线/后抽路径及未知标记保留，无理由用局部成功把宽提案置implemented/duplicate。

## 逐项处置

| id | 账本 | 处置及缺口 |
|---|---|---|
'''
for p, reason in zip(proposals, reasons):
    report += f"| {p['id']} | {', '.join(p['ledger'])} | waiting：{reason} |\n"
report += f'''
证据局号/层/回合、反例、预期行为、验证与回退逐项见{S / 'proposal.md'}。不新增重复提案id、不改原提案/根请求/队列/learn.json，不关闭学习父要求。code_proposals使用这十个真实原CLI id。

## 验证与交接

没有生产代码提交，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试、未借用历史绿。无需运行live合入流程、知识刷新提交、版本或上线通知。材料脚本都只放本批scratch，没有可执行.ts源码副本；没有npm install、联网、play、推送、读取key/.env/游戏二进制或改其他角色知识。

本批只经根ledger.py update追加by=learner:strategy-proposal的提案/报告追溯链接与说明；不重复证据，不设置status、不把shipped降为proposed。没有新增待设proposed的知识条目。实际CLI读回另附ledger-registration-verification.json。

读取过程有过旧路径猜测失败（selection.ts、enemy-turn.ts、replay_selection_audit.py、eye/loop.ts、lessons-silent.md不存在）及宽输出截断；已按rg --files定位真实入口并从已存原件缩窄读取，不当证据缺失或产品bug，不宣称对应生产测试失败。完整输入缺ID拒收原件保留；48材料断言首跑通过，没有源码负控。

冻结六局均为历史发现样本；没有受控替线路线/留药/完整候选因果、独立后置盲测或胜率提升证据。具体未知保留waiting；经验入库与实际消费者采用不因本报告完成而关闭。

交运维提案：{S / 'proposal.md'}
报告：{S / 'report.md'}
'''
(S / 'report.md').write_text(report)
updates = []
for ident in sorted({i for p in proposals for i in p['ledger']}):
    linked = [p for p in proposals if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
                    'note': '20261016-031302-strategy-proposal：仅原提案证据/源码边界复核追溯；' +
                            '、'.join(p['id'] for p in linked) + '均waiting。6995原字节行、48材料断言、六局离线有界读回；不新增机制/证据/源码/测试/版本，不关闭原宽请求，保留原状态与已交付历史。'})
(S / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'proposals': len(results), 'ledger_trace_updates': len(updates), 'base': base, 'report': str(S / 'report.md')}, ensure_ascii=False))

import gzip
import json
from pathlib import Path

S = Path(__file__).resolve().parent
states = {x['line']: x for x in json.loads((S / 'selected-state-facts.json').read_text())}
decisions = {x['line']: x['row'] for x in json.loads((S / 'selected-decisions.json').read_text())}
checks = []

def check(name, observed, expected, lines):
    result = {'name': name, 'observed': observed, 'expected': expected, 'lines': lines, 'passed': observed == expected}
    checks.append(result)
    assert result['passed'], result

def enemy(line, ident=None):
    rows = states[line]['enemies']
    if ident is not None:
        rows = [x for x in rows if x['id'] == ident]
    assert len(rows) == 1
    return rows[0]

def attack(line, ident=None):
    return sum(x.get('total_damage') or 0 for x in enemy(line, ident)['intents'] or [])

def hand(line, ident):
    return next(x for x in states[line]['hand'] if x['id'] == ident)

def value(line, ident, name):
    return next(x['current_value'] for x in hand(line, ident)['values'] if x['name'] == name)

def candidate(line, key=None):
    row = decisions[line]
    key = key or row['answers']['plan']['choice']
    return json.loads(row['questions']['plan']['criteria'][key])

check('F35神化实际能耗', [states[x]['energy'] for x in (275564, 275565)], [7, 5], [275564, 275565])
for card, field, expected in [('DEFEND_SILENT', 'Block', [5, 8]), ('STRIKE_SILENT', 'Damage', [7, 10]),
                              ('DAGGER_SPRAY', 'Damage', [5, 7])]:
    check('F35升级' + card, [value(x, card, field) for x in (275564, 275565)], expected, [275564, 275565])
check('必备工具费用', [hand(x, 'TOOLS_OF_THE_TRADE')['cost'] for x in (275564, 275565)], [1, 0], [275564, 275565])
check('场外升级数未被神化永久改写', [states[x]['deck_upgraded'] for x in (275564, 275565, 275679, 275680, 275687)],
      [1, 1, 4, 4, 4], [275564, 275565, 275679, 275680, 275687])
for card, field, expected in [('SUCKER_PUNCH', 'Damage', [9, 11]), ('SUCKER_PUNCH', 'WeakPower', [1, 2]),
                              ('FASTEN', 'ExtraBlock', [4, 6]), ('PIERCING_WAIL', 'StrengthLoss', [6, 8])]:
    check('F43升级' + card + '/' + field, [value(x, card, field) for x in (275679, 275680)], expected, [275679, 275680])
check('F43前后题预测', [(candidate(n)['damage_dealt'], candidate(n)['hp_lost']) for n in (269706, 269707)],
      [(43, 14), (51, 13)], [269706, 269707])
check('F43当轮端点净变化', [states[275679]['hp'] - states[275687]['hp'], enemy(275679)['hp'] - enemy(275687)['hp']],
      [13, 51], [275679, 275687])
check('F45首题推演成熟度', [decisions[269748]['rollout'][k] for k in ('horizon', 'samples', 'best')], [1, 1, None], [269748])
check('707ms只是题面已报告值', '707 ms' in candidate(269748, 'plan1')['rollout'], True, [269748])
check('药水MC首题1样本被预算截断', '1 sample (cut from 12' in candidate(269748, 'p0')['simulated'], True, [269748])
check('药水MC重问12样本', '12 samples' in candidate(269754, 'p0')['simulated'], True, [269754])
check('药水实际加能量未回血', [(states[x]['hp'], states[x]['energy']) for x in (275728, 275729)], [(67, 1), (67, 2)], [275728, 275729])
check('药水实际两张抽牌', [x['id'] for x in states[275729]['hand']], ['APOTHEOSIS', 'TOOLS_OF_THE_TRADE', 'SURVIVOR'], [275729])
check('神化最终未兑现且被弃', [x['id'] for x in states[275732]['hand']], [], [275731, 275732])
check('骑士四攻击段减力', [sum(attack(275752, e['id']) for e in states[275752]['enemies']),
                            sum(attack(275754, e['id']) for e in states[275754]['enemies'])], [83, 59], [275752, 275754])
check('末轮实际属性和挡', [states[275754]['hp'], states[275754]['block'], states[275754]['powers'].get('DEXTERITY_POWER'),
                         states[275754]['powers'].get('PLATING_POWER', 0)], [32, 20, 3, 0], [275754])
check('完整需损39与实扣32分列', [59 - states[275754]['block'], states[275754]['hp'] - states[275755]['hp']], [39, 32], [275754, 275755])
check('三敌末轮仍未退场', sorted(x['hp'] for x in states[275755]['enemies']), [21, 77, 80], [275755])
check('8JRE首第三试同盘指纹', decisions[270216]['fingerprint'] == decisions[270282]['fingerprint'], True, [270216, 270282])
numbers = decisions[270282]['sl_explore']['numbers']
check('第三试原线0/24与替线5/24', ['dead 0/24' in numbers['original'], 'dead 5/24' in numbers['replacement']], [True, True], [270282])
check('护栏保留原预测差', [(candidate(270264, p)['hp_lost'], candidate(270264, p)['damage_dealt']) for p in ('plan4', 'plan6')],
      [(16, 43), (4, 25)], [270264])
audit = json.loads(gzip.decompress((S / 'offline/8JRE1C4H4Z2W.output.json.gz').read_bytes()))
turns = [x for x in audit['observed_turns'] if x['floor'] == 33 and x['turn'] == 2 and x['attempt'] in (1, 3)]
check('同盘实付12血换7净扣', [(x['facts']['player_hp_delta'], x['facts']['enemy_hp_changes'][0]['hp_delta']) for x in turns],
      [(-3, -10), (-15, -17)], [270216, 270282])
check('沙虫终局实扣5完整显示需求15', [states[276433]['hp'] - states[276434]['hp'], attack(276433) - states[276433]['block']],
      [5, 15], [276433, 276434])
check('沙虫已结24毒与剩余130血', [enemy(276433)['hp'] - enemy(276434)['hp'], enemy(276434)['hp']], [24, 130], [276433, 276434])
check('蚌独立增力', [enemy(n)['powers'].get('STRENGTH_POWER', 0) for n in (273238, 273252, 273263)], [0, 4, 8], [273238, 273252, 273263])
check('蚌虚弱前后攻击', [attack(n) for n in (273252, 273254, 273263, 273268)], [15, 11, 19, 14], [273252, 273254, 273263, 273268])
check('蚌完整需损4死亡实扣2', [attack(273268) - states[273268]['block'], states[273268]['hp'] - states[273269]['hp']], [4, 2], [273268, 273269])
check('蚌现场没有正敏捷', any(x['powers'].get('DEXTERITY_POWER', 0) > 0 for x in states.values() if x['run'] == 'CA5KE8GFJ9X2'), False, [273238, 273268])
check('空打冒泡耗1能', [states[n]['energy'] for n in (274379, 274380)], [5, 4], [274379, 274380])
check('空打冒泡两敌不掉血', [[e['hp'] for e in states[n]['enemies']] for n in (274379, 274380)], [[35, 72], [35, 72]], [274379, 274380])
check('空打冒泡目标仍无毒', [enemy(n, 'THE_LOST')['powers'].get('POISON_POWER', 0) for n in (274379, 274380)], [0, 0], [274379, 274380])
check('吸取玩家属性实际削减', [(states[n]['powers'].get('STRENGTH_POWER', 0), states[n]['powers'].get('DEXTERITY_POWER', 0)) for n in (273503, 273504)],
      [(2, 0), (0, -2)], [273503, 273504])
check('负敏捷双防御各3', [states[n]['block'] for n in (273504, 273505, 273507)], [0, 3, 6], [273504, 273505, 273507])
check('毒两触发净扣33', [enemy(273507)['hp'] - enemy(273508)['hp'], enemy(273507)['powers']['POISON_POWER']], [33, 17], [273507, 273508])
check('临时减力恢复不掩盖属性成长', [enemy(n)['powers']['STRENGTH_POWER'] for n in (273504, 273506, 273508)], [2, -4, 2], [273504, 273506, 273508])
check('胧光怪47输出仍付15血', [sum(x['hp'] for x in states[273593]['enemies']) - sum(x['hp'] for x in states[273596]['enemies']),
                                 states[273593]['hp'] - states[273596]['hp']], [47, 15], [273593, 273596])
check('幻象未退场', [enemy(n, 'PARAFRIGHT')['hp'] for n in (273593, 273595, 273596, 273598)], [14, 2, 2, 0], [273593, 273595, 273596, 273598])
check('双方航行增力3到6', [enemy(n, 'THE_OBSCURA')['powers']['STRENGTH_POWER'] for n in (273593, 273596)], [3, 6], [273593, 273596])
check('甲虫临减与独立成长', [enemy(n, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'] for n in (275013, 275016, 275018)], [2, -4, 4], [275013, 275016, 275018])
check('甲虫对应攻击20/14/22', [attack(n, 'SLUMBERING_BEETLE') for n in (275013, 275016, 275018)], [20, 14, 22], [275013, 275016, 275018])
check('甲虫完整需损6与实扣1', [attack(275022) - states[275022]['block'], states[275022]['hp'] - states[275023]['hp']], [6, 1], [275022, 275023])
check('甲虫死亡前敌43到32含已结毒与荆棘', [enemy(275022)['hp'], enemy(275023)['hp']], [43, 32], [275022, 275023])
check('消费者不认证完整候选', all(x.get('actual_full_candidate_result') is None for x in audit['segments']), True, [])
(S / 'fact-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks': len(checks), 'passed': len(checks), 'production_tests': False}, ensure_ascii=False))

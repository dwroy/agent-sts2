import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const directory = fileURLToPath(new URL('.', import.meta.url));
const { auditSelectionExecution } = await import(pathToFileURL(resolve('learner/lib/selection-execution.ts')));
const runs = JSON.parse(readFileSync(resolve(directory, 'dispatch.json'), 'utf8')).runs;
const receipts = [];
for (const run of runs) {
  const inputPath = resolve(directory, 'offline', `${run}.input.json.gz`);
  const input = JSON.parse(gunzipSync(readFileSync(inputPath)));
  let output, fullError = null;
  const excluded = input.decisions.filter(row => !row.decision_id)
    .map(row => ({ line: row._line, reason: 'missing_decision_id', row }));
  try { output = auditSelectionExecution(input); }
  catch (error) {
    fullError = String(error);
    if (!excluded.length) throw error;
    const bounded = { ...input, decisions: input.decisions.filter(row => row.decision_id) };
    writeFileSync(resolve(directory, 'offline', `${run}.bounded.input.json.gz`), gzipSync(JSON.stringify(bounded)));
    output = auditSelectionExecution(bounded);
  }
  writeFileSync(resolve(directory, 'offline', `${run}.output.json.gz`), gzipSync(JSON.stringify(output)));
  receipts.push({ run, inputPath, fullError, excluded,
    outputKeys: Object.keys(output), counts: output.counts ?? null });
}
writeFileSync(resolve(directory, 'offline-receipts.json'), JSON.stringify(receipts, null, 2) + '\n');
process.stdout.write(JSON.stringify(receipts.map(({ excluded, ...row }) => ({ ...row, excluded_count: excluded.length })), null, 2) + '\n');

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
SCRATCH = ROOT / 'learner/runs/20261018-052915-c759eb68-e3f8-411d-abdd-c614cf965d31-fix-batch'
BRANCH = 'codex-fix-silent-20261018-052912'
receipt = {'branch': BRANCH, 'merged': None}

def git(*args, check=True):
    r = subprocess.run(['git', '-C', str(LIVE), *args], text=True, capture_output=True)
    if r.stdout: print(r.stdout, end='', flush=True)
    if r.stderr: print(r.stderr, end='', file=sys.stderr, flush=True)
    if check and r.returncode: raise RuntimeError(f'git {args}: exit {r.returncode}')
    return r

def save():
    (SCRATCH / 'merge-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')

try:
    with (ROOT / 'ops/codex-ops/report-run.lock').open('a') as report_lock:
        try:
            fcntl.flock(report_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            receipt['blocked'] = 'report-run.lock is busy'
            save()
            sys.exit(75)
        while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
            print('waiting for knowledge builders', flush=True)
            time.sleep(10)
        receipt['initial_live'] = git('rev-parse', 'HEAD').stdout.strip()
        receipt['initial_status'] = git('status', '--short').stdout
        if git('diff', '--cached', '--quiet', check=False).returncode:
            raise RuntimeError('live already has staged changes; preserve the index')
        if git('rev-parse', '-q', '--verify', 'MERGE_HEAD', check=False).returncode == 0:
            raise RuntimeError('live already has a merge in progress')
        receipt['source'] = git('rev-parse', BRANCH).stdout.strip()
        merge_base = git('merge-base', 'HEAD', BRANCH).stdout.strip()
        branch_paths = set(git('diff', '--name-only', merge_base, BRANCH).stdout.splitlines())
        refresh_paths = set(git('diff', '--name-only', '--', 'notes/fight-value-backtest.md', 'knowledge').stdout.splitlines())
        receipt['refresh_paths'] = sorted(refresh_paths)
        receipt['refresh_overlap'] = sorted(branch_paths & refresh_paths)
        if receipt['refresh_overlap']:
            receipt['blocked'] = 'knowledge refresh overlaps source branch; no changes staged'
            save()
            sys.exit(75)
        git('add', 'notes/fight-value-backtest.md', 'knowledge')
        if git('diff', '--cached', '--quiet', check=False).returncode:
            scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'protect', '--staged', '--redact', '--no-banner'], cwd=LIVE, text=True, capture_output=True)
            (SCRATCH / 'gitleaks-live-refresh.log').write_text(scan.stdout + scan.stderr)
            if scan.returncode: raise RuntimeError('live refresh gitleaks failed; preserve staged data')
            subprocess.run(['date'], check=True)
            git('commit', '-m', 'Refresh knowledge data', '-m', 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
        receipt['pre_merge'] = git('rev-parse', 'HEAD').stdout.strip()
        save()
        result = git('merge', '--no-edit', BRANCH, check=False)
        (SCRATCH / 'live-merge.log').write_text(result.stdout + result.stderr)
        receipt['merge_exit'] = result.returncode
        if result.returncode:
            receipt['conflicts'] = git('diff', '--name-only', '--diff-filter=U').stdout.splitlines()
            if git('rev-parse', '-q', '--verify', 'MERGE_HEAD', check=False).returncode == 0:
                receipt['abort_exit'] = git('merge', '--abort', check=False).returncode
            receipt['final_live'] = git('rev-parse', 'HEAD').stdout.strip()
            receipt['final_status'] = git('status', '--short').stdout
            save()
            sys.exit(2)
        receipt['merged'] = git('rev-parse', 'HEAD').stdout.strip()
        save()
        with (SCRATCH / 'live-sandbox.log').open('w') as output:
            test = subprocess.run(['nice', '-n', '19', 'bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', stdout=output, stderr=subprocess.STDOUT)
        receipt['sandbox_exit'] = test.returncode
        if test.returncode:
            git('reset', '--merge', receipt['pre_merge'])
            receipt['merged'] = None
            receipt['final_live'] = git('rev-parse', 'HEAD').stdout.strip()
        save()
        sys.exit(test.returncode)
except Exception as error:
    receipt['error'] = str(error)
    save()
    raise

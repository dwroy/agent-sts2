"""Check observed endpoints; this is evidence validation, not a production-code test."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = [json.loads(line) for line in (OUT / "state-projections.jsonl").open()]
by_line = {s["line"]: s for s in states}
decisions = {x["line"]: x["row"] for x in map(json.loads, (OUT / "selected-decisions.jsonl").open())}
checks = []
pairs = []


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({"label": label, "actual": actual, "expected": expected})


def enemy(line, id=None):
    values = by_line[line]["enemies"]
    return values[0] if id is None else next(e for e in values if e["id"] == id)


for original, replacement, losses, damage in [
    (270216, 270282, [3, 15], [10, 17]),
    (271309, 271348, [0, 9], [45, 38]),
    (271992, 272040, [9, 14], [24, 27]),
    (271982, 272195, [2, 10], [25, 34]),
]:
    check(f"同指纹 {original}/{replacement}", decisions[original]["fingerprint"], decisions[replacement]["fingerprint"])
    observed = []
    for n in [original, replacement]:
        decision = decisions[n]
        start = next(s for s in states if s["ts"] == decision["observed_ts"] and s["run"] == decision["run_id"])
        end = next(s for s in states if s["line"] > start["line"] and s["run"] == start["run"] and
                   s["floor"] == start["floor"] and s["turn"] and s["turn"] > start["turn"])
        # These four windows have neither summons nor a phase transition; do not generalize the net HP sum.
        check(f"实体集合不变 {n}", [e["id"] for e in start["enemies"]], [e["id"] for e in end["enemies"]])
        observed.append({"decision": n, "run": start["run"], "floor": start["floor"], "turn": start["turn"],
                         "start_line": start["line"], "end_line": end["line"],
                         "hp_loss": start["hp"] - end["hp"],
                         "enemy_net_hp_loss": sum(e["hp"] for e in start["enemies"]) - sum(e["hp"] for e in end["enemies"])})
    check(f"实付血价 {original}/{replacement}", [x["hp_loss"] for x in observed], losses)
    check(f"敌本体净扣 {original}/{replacement}", [x["enemy_net_hp_loss"] for x in observed], damage)
    pairs.append(observed)

check("蚌加压后力量", [enemy(n)["powers"].get("STRENGTH_POWER", 0) for n in [273238, 273252, 273263]], [0, 4, 8])
check("蚌无弱喷水", [enemy(n)["attack"] for n in [273238, 273252, 273263]], [11, 15, 19])
check("蚌弱后喷水", [enemy(n)["attack"] for n in [273254, 273268]], [11, 14])
check("蚌轮初覆甲", [enemy(n)["powers"]["PLATING_POWER"] for n in [273238, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6])
check("火花跨轮增长", [enemy(n)["powers"]["VITAL_SPARK_POWER"] for n in [274830, 274834]], [3, 6])
check("T4污染增量与能力间不变", [by_line[n]["powers"].get("TAINTED_POWER", 0) for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6])
check("T5污染累积", [by_line[n]["powers"].get("TAINTED_POWER", 0) for n in [274834, 274836, 274837, 274838]], [0, 6, 12, 18])
check("电击力量增长", [enemy(n, "ZAPBOT")["powers"]["STRENGTH_POWER"] for n in [274308, 274313]], [2, 4])
check("电击攻击增长", [enemy(n, "ZAPBOT")["attack"] for n in [274308, 274313]], [17, 19])
check("电击index重排", [enemy(n, "ZAPBOT")["index"] for n in [274308, 274313]], [4, 3])
check("失落退场前后力量", [by_line[n]["powers"].get("STRENGTH_POWER", 0) for n in [274357, 274358]], [-4, 0])
check("遗忘再夺敏捷", by_line[274362]["powers"]["DEXTERITY_POWER"], -2)
check("实验体新相清毒清力", [enemy(277513)["hp"], enemy(277513)["powers"].get("POISON_POWER", 0), enemy(277513)["powers"].get("STRENGTH_POWER", 0)], [212, 0, 0])
check("触媒建成后仍零毒", [by_line[277519]["powers"]["ACCELERANT_POWER"], enemy(277519)["powers"].get("POISON_POWER", 0)], [2, 0])
check("后取得敏捷不倒补挡", [[by_line[n]["powers"]["DEXTERITY_POWER"], by_line[n]["block"]] for n in [277523, 277526]], [[5, 23], [6, 23]])
check("双蟹轮初与新增挡", [by_line[n]["block"] for n in [278236, 278240]], [14, 20])
check("镣铐临减到期", [enemy(n, "CRUSHER")["powers"].get("STRENGTH_POWER", 0) for n in [278236, 278237, 278242]], [0, -9, 0])
check("朝向与弱分步", [enemy(n, "ROCKET")["attack"] for n in [278249, 278252, 278253]], [57, 38, 28])
check("脆弱下牌挡", [by_line[n]["block"] for n in [278255, 278258]], [6, 6])
sl = [x["row"] for x in map(json.loads, (OUT / "selected-sl.jsonl").open())]
check("SL获胜反例保留", [(x["attempt"], x["result"], x["end_hp"]) for x in sl if x["run_id"] == "YF0LXT1QSTGG" and x["floor"] == 33 and x["attempt"] == 2], [(2, "won", 20)])
(OUT / "facts-verification.json").write_text(json.dumps({"scope": "原日志事实核验，非源码红绿/tsc/vitest", "checks": checks, "pairs": pairs, "count": len(checks), "passed": True}, ensure_ascii=False, indent=2) + "\n")
print(f"{len(checks)} 项原日志事实核验通过；不是生产代码测试。")

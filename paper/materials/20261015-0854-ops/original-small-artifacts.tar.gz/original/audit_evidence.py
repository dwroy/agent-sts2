"""Verify frozen evidence bytes and prepare bounded, character-scoped projections."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / "dispatch.json").read_text())
RUNS = set(dispatch["row"]["runs"])
FLOORS = {"DUZUBAJ3A8GP": {27}, "5PM6JAQG6FNQ": {38, 39}, "CA5KE8GFJ9X2": {13},
          "8JRE1C4H4Z2W": {17, 33}, "YF0LXT1QSTGG": {33, 48}, "XP2SL33HT0D9": {33}}
DECISIONS = {270216, 270264, 270282, 271309, 271348, 271354, 271992, 272040,
             271982, 272195, 272076, *range(271495, 271510)}


def powers(entries):
    return {p["power_id"]: p["amount"] for p in entries or []}


def compact(item):
    row = item["row"]
    state = row["state"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {"line": item["line"], "offset": item["offset"], "bytes": item["bytes"],
            "sha256": item["sha256"], "run": item["run_id"], "floor": state["run"]["floor"],
            "turn": state.get("turn"), "ts": row.get("observed_ts", row.get("ts")),
            "observed": row.get("observed"), "actions": state.get("available_actions"),
            "screen": state.get("screen"), "hp": player.get("current_hp"), "block": player.get("block"),
            "energy": player.get("energy"), "powers": powers(player.get("powers")),
            "enemies": [{"index": e["index"], "id": e["enemy_id"], "hp": e["current_hp"],
                         "max_hp": e["max_hp"], "block": e["block"], "alive": e["is_alive"],
                         "move": e.get("move_id"), "powers": powers(e.get("powers")),
                         "attack": sum((i.get("total_damage") or 0) for i in e.get("intents", []))}
                        for e in combat.get("enemies", [])],
            "hand": [{"index": c["index"], "id": c["card_id"], "upgraded": c.get("upgraded"),
                      "type": c.get("card_type"), "text": c.get("resolved_rules_text")}
                     for c in combat.get("hand", [])]}


results = []
projections = []
selected_decisions = []
selected_sl = []
for directory in ["evidence", "evidence-extra"]:
    manifests = json.loads((OUT / directory / "evidence-manifest.json").read_text())
    for manifest in manifests:
        stream = manifest["stream"]
        path = OUT / directory / f"{stream}.evidence.jsonl"
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest["output_sha256"]
        counts = collections.Counter()
        with (Path('/home/dw/Projects/agent-sts2/logs') / f"{stream}.jsonl").open("rb") as source:
            for line in path.open():
                item = json.loads(line)
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert raw.endswith(b"\n") and hashlib.sha256(raw).hexdigest() == item["sha256"]
                row = json.loads(raw)
                assert row == item["row"]
                assert extractor.run_identity(row) == item["run_id"] in RUNS
                assert item["offset"] + item["bytes"] <= manifest["source_size"]
                counts[item["run_id"]] += 1
                if stream == "states":
                    state = row["state"]
                    run = state.get("run") or {}
                    assert run.get("character_id") == "SILENT" and run.get("ascension") == 10
                    if run.get("floor") in FLOORS[item["run_id"]] and state.get("combat"):
                        projections.append(compact(item))
                elif stream == "decisions" and item["line"] in DECISIONS:
                    selected_decisions.append(item)
                elif stream == "sl-attempts":
                    selected_sl.append(item)
        assert {run: counts[run] for run in RUNS} == manifest["counts"]
        results.append({"stream": stream, "rows": sum(counts.values()), "counts": manifest["counts"],
                        "source_size": manifest["source_size"], "output_sha256": manifest["output_sha256"],
                        "raw_bytes_sha_identity_verified": True})

for name, values in [("state-projections.jsonl", projections), ("selected-decisions.jsonl", selected_decisions),
                     ("selected-sl.jsonl", selected_sl)]:
    with (OUT / name).open("w") as handle:
        for value in values:
            handle.write(json.dumps(value, ensure_ascii=False) + "\n")
(OUT / "evidence-verification.json").write_text(json.dumps({"streams": results,
    "total_rows": sum(r["rows"] for r in results), "target_state_rows": len(projections),
    "selected_decision_rows": len(selected_decisions), "sl_rows": len(selected_sl)}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"streams": [(r["stream"], r["rows"]) for r in results],
                  "total_rows": sum(r["rows"] for r in results), "target_state_rows": len(projections)}, ensure_ascii=False))

import bisect
import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT / 'evidence'
ASSIGNED = json.loads((OUT / 'assigned-proposals.json').read_text())
RUNS = set(json.loads((OUT / 'run-identities.json').read_text())['runs'])


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = {}
    fields = [row.get('run_id'), row.get('run'), state.get('run_id'), (fp or {}).get('run')]
    ids = {v for v in fields if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(ids)) if len(ids) == 1 else None


def ref(item):
    return {k: item[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


verified = []
for manifest in json.loads((EVIDENCE / 'evidence-manifest.json').read_text()):
    stream = manifest['stream']
    file = EVIDENCE / (stream + '.evidence.jsonl')
    counts = collections.Counter()
    output_digest = hashlib.sha256()
    with file.open('rb') as selected, (Path('/home/dw/Projects/agent-sts2/logs') / (stream + '.jsonl')).open('rb') as source:
        for encoded in selected:
            output_digest.update(encoded)
            item = json.loads(encoded)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            row = json.loads(raw)
            assert row == item['row']
            assert identity(row) == item['run_id'] and item['run_id'] in RUNS
            if stream == 'states':
                assert row['state']['run']['character_id'].lower() == 'silent'
            counts[item['run_id']] += 1
    assert output_digest.hexdigest() == manifest['output_sha256']
    assert all(counts[run] == count for run, count in manifest['counts'].items())
    verified.append({**manifest, 'verified_rows': sum(counts.values()), 'offset_bytes_sha_json_identity': True})
save('evidence-verification.json', verified)

attempts = collections.defaultdict(list)
sl = []
for line in (EVIDENCE / 'sl-attempts.evidence.jsonl').open():
    item = json.loads(line)
    row = item['row']
    entry = {k: row.get(k) for k in ['run_id', 'floor', 'attempt', 'started_at', 'ended_at', 'result', 'turns', 'end_hp', 'reload', 'give_up_reason']}
    entry['ref'] = ref(item)
    sl.append(entry)
    attempts[(item['run_id'], row['floor'])].append(entry)
save('attempts.json', sl)


def powers(raw):
    return {p.get('power_id'): p.get('amount') for p in raw or []}


def compact(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    ts = row['ts']
    attempt = [a['attempt'] for a in attempts[(item['run_id'], run.get('floor'))]
               if a.get('started_at') and a['started_at'] <= ts <= a['ended_at']]
    hand = [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'dynamic_values']}
            for c in combat.get('hand') or []]
    return {'ref': ref(item), 'ts': ts, 'fingerprint': row.get('fingerprint'), 'screen': state.get('screen'),
            'floor': run.get('floor'), 'turn': state.get('turn'), 'asc': run.get('ascension'),
            'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'), 'block': player.get('block'),
            'energy': player.get('energy'), 'cards_played': player.get('cards_played_this_turn'),
            'attempt': attempt[0] if len(attempt) == 1 else None, 'in_combat': state.get('in_combat'),
            'readiness': combat.get('action_readiness'), 'hand': hand, 'powers': powers(player.get('powers')),
            'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id', 'intents', 'powers']}
                        for e in combat.get('enemies') or []],
            'potions': [{k: p.get(k) for k in ['index', 'potion_id', 'occupied', 'usage']} for p in run.get('potions') or []],
            'relic_ids': [r.get('relic_id') for r in run.get('relics') or []],
            'lamp': [r for r in run.get('relics') or [] if r.get('relic_id') == 'UNSETTLING_LAMP'],
            'selection': {k: (state.get('selection') or {}).get(k) for k in ['kind', 'prompt', 'min', 'max', 'selected']}}


states = collections.defaultdict(list)
with (OUT / 'states-summary.jsonl').open('w') as output:
    for line in (EVIDENCE / 'states.evidence.jsonl').open():
        entry = compact(json.loads(line))
        states[entry['ref']['run_id']].append(entry)
        output.write(json.dumps(entry, ensure_ascii=False) + '\n')

state_index = {}
for run, entries in states.items():
    entries.sort(key=lambda s: (s['ts'], s['ref']['offset']))
    for i, entry in enumerate(entries):
        state_index.setdefault((run, entry['fingerprint']), []).append((entry['ts'], i))

drinks, rests, special_plays, linked_decisions = [], [], [], []
special_ids = {'STRANGLE', 'ABRASIVE', 'MALAISE', 'PRECISE_CUT', 'POISONED_STAB', 'DEADLY_POISON',
               'FRANTIC_ESCAPE', 'WELL_LAID_PLANS'}
for line in (EVIDENCE / 'decisions.evidence.jsonl').open():
    item = json.loads(line)
    row = item['row']
    run = item['run_id']
    positions = state_index.get((run, row.get('fingerprint')), [])
    ix = bisect.bisect_right(positions, (row['ts'], 10**12)) - 1
    chosen = row.get('chosen') or {}
    action = chosen.get('action')
    before = states[run][positions[ix][1]] if ix >= 0 else None
    successors = states[run][positions[ix][1] + 1:positions[ix][1] + 4] if ix >= 0 else []
    entry = {'ref': ref(item), 'ts': row['ts'], 'floor': row.get('floor'), 'turn': row.get('turn'),
             'attempt': row.get('sl_attempt'), 'label': row.get('label'), 'chosen': chosen,
             'journal': row.get('journal'), 'result': row.get('result'),
             'before': before, 'after': successors[0] if successors else None,
             'successors': successors}
    if before:
        assert before['ts'] <= row['ts']
    if action in {'use_potion', 'drink_potion', 'discard_potion'}:
        entry['potion'] = next((p for p in before['potions'] if p['index'] == chosen.get('potion_index')), None) if before else None
        drinks.append(entry)
    if row.get('label', '').startswith('rest/'):
        rests.append(entry)
    if action == 'play_card' and before:
        card = next((c for c in before['hand'] if c['index'] == chosen.get('card_index')), None)
        if card and card['card_id'] in special_ids:
            entry['card'] = card
            special_plays.append(entry)
    linked_decisions.append({'ref': ref(item), 'label': row.get('label'), 'floor': row.get('floor'),
                             'turn': row.get('turn'), 'attempt': row.get('sl_attempt'),
                             'before': before['ref'] if before else None,
                             'after': successors[0]['ref'] if successors else None})
save('decision-state-links.json', linked_decisions)
save('potion-transitions.json', drinks)
save('rest-transitions.json', rests)
save('mechanism-transitions.json', special_plays)

windows = [('TXZ6RVMQA09D', 48, [6, 8, 9, 10]), ('TXZ6RVMQA09D', 49, [1]),
           ('WQZVENQ7DTRP', 33, [7, 9, 10, 11]), ('NHA2KW0RB7VP', 33, [1, 2, 3, 4]),
           ('NHA2KW0RB7VP', 17, [1]), ('Q6M2Y34MWKRE', 8, [4, 5, 7, 8]),
           ('Q6M2Y34MWKRE', 9, [1, 2]), ('1913SE84AXQF', 31, [2, 3, 4])]
for run, floor, turns in windows:
    save('window-' + run + '-F' + str(floor) + '.json',
         [s for s in states[run] if s['floor'] == floor and s['turn'] in turns])

summary = {}
for run, entries in states.items():
    floors = []
    for floor in sorted({s['floor'] for s in entries if isinstance(s['floor'], int)}):
        ss = [s for s in entries if s['floor'] == floor]
        combat = [s for s in ss if s['in_combat'] and s['enemies']]
        if combat:
            rewards = [s for s in ss if s['ts'] >= combat[-1]['ts'] and s['screen'] in ['REWARDS', 'REWARD', 'MAP', 'GAME_OVER']]
            last = rewards[-1] if rewards else combat[-1]
            floors.append({'floor': floor, 'first_hp': combat[0]['hp'], 'last_observed_hp': last['hp'],
                           'last_screen': last['screen'], 'first_ref': combat[0]['ref'], 'last_ref': last['ref'],
                           'enemy_ids': sorted({e['enemy_id'] for s in combat for e in s['enemies']}),
                           'attempts': [a['attempt'] for a in attempts[(run, floor)]],
                           'last_potions': last['potions']})
    ds = [d for d in drinks if d['ref']['run_id'] == run]
    summary[run] = {'asc': entries[0]['asc'], 'state_rows': len(entries), 'floors': floors,
                    'potion_actions': len(ds), 'potion_labels': dict(collections.Counter(d['chosen']['action'] for d in ds))}
save('resource-summary.json', summary)
print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in verified), 'states': sum(len(v) for v in states.values()),
                  'linked_decisions': sum(x['before'] is not None for x in linked_decisions),
                  'decisions': len(linked_decisions), 'potion_actions': len(drinks), 'rests': len(rests),
                  'mechanism_actions': len(special_plays)}, ensure_ascii=False))

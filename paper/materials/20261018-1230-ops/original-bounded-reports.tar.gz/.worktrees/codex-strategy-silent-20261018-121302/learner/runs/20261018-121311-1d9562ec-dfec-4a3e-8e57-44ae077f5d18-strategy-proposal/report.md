# 静默猎手已领取策略提案逐项复核

记录时间：2026-10-18T12:27:05+08:00。批次：20261018-121302-strategy-proposal。

基线与当前HEAD：`7c27a19ac73ea6f5920b41d42689896f9996be44`；开工tracked/index干净，普通批次`git merge --no-edit main`返回Already up to date。本批没有research_request或implementation_request；根专题文件绑定另一旧批次，未承接其work_spec或扩展选题。

结论：10个已领取提案全部保留waiting。确定机制中的若干窄分支已经存在；本批没有足够的新证据支持补齐组合提案或改变排序/药价/SL/终局规则。未改生产源码、知识或任务模板；fixes=[]、merged=null，无提交、版本、shipped、源码撤回红绿或生产测试成绩。取证脚本仅存本批忽略的scratch。

## 身份与输入

已保存dispatch.json、assigned-proposals.json、10份原提案逐字副本及SHA核验，31个相关账本完整折叠快照和26个相关Silent经验。只消费本批10个ID，不增领/新增重复代码提案；原提案和父请求不修改。运行参数由宿主控制，本批未修改模型/强度/权限；未独立读取原生运行请求，不能以默认配置冒称实际运行参数核验。

runs.jsonl逐行核角色，15局全为SILENT。10个派发锚点保留原顺序；额外5局仅因这10个提案已保存的证据链接而复核：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。其中K367为A1、SAD为A7、F4Q为A9，其余A10。不能把这些混成单一进阶分母，也不把旧混合引擎局当纯Codex成绩。

## 原日志与复核范围

使用指定learner/extract_evidence.py抽取8流，逐流先冻结source_size；各流截点并非原子快照。evidence-manifest.json保存逐局计数和输出SHA；每行保存source/line/offset/bytes/SHA/显式身份。独立audit_evidence.py逐行seek原日志核字节、SHA、JSON、归属与角色，全部19929行通过；9448个决策均按同局fingerprint及不晚于决策的时间连到状态。此为材料校验，不是产品单元测试或生产消费者验收。

| 流 | 本批选中行 | 源字节截点 | 全源坏行 |
|---|---:|---:|---:|
| states | 9815 | 14323706114 | 2 |
| decisions | 9448 | 2529589919 | 2 |
| sl-attempts | 78 | 47922841 | 0 |
| run-config | 15 | 2086430 | 0 |
| run-plans | 77 | 9323912 | 0 |
| brain | 481 | 814848988 | 2 |
| runs | 15 | 372114 | 0 |
| fight-plans | 0 | 2233957 | 0 |

三个流各2条坏行是该源截点全体扫描统计，不能归因到目标局。fight-plans选中0只表示这个截点和显式身份筛选未选到，不断言原日志缺失。run-plans以run识别，其余流同时检查run_id/state.run_id/fingerprint.run，冲突身份不接收。原始日志只读，抽取和引用均在本批scratch。

states-summary/resource-summary是索引材料，last_observed_hp不自动等于战斗退出HP；同层后续回复/升级及过渡帧须另核。尝试号只使用明确SL区间，区间外保持null，不能默认归首试。原记录的dirty执行树没有完整冻结，本批当前源码不能冒充历史执行源码。

## 支持、反例与参数限制

paired-local-outcomes.json保存4组相同起始fingerprint的局部比较：TXZ T6 (3损/36净扣) 对 (0损/27净扣)，WQZ T9 (13/24) 对 (22/39)，WQZ T7 (0/24) 对 (4/24)并多一轮沙坑，NHA T1 (1/8) 对 (7/24)。这里的敌净扣跨到下一玩家轮，NHA含轮初自动伤，不能全算作卡牌伤。后续抽序/生成/选择并未受控，失败尝试不拆独立局。WQZ T7反例尤其不支持统一拒绝额外付血的延时方案。

cunning-42-validation.json逐饮核9局42次3/2/0、升级状态、基础6、HP与能量未变。它验证确定生成窗口，不能证明完整穿插已实际派发或改善整战。royal-opening-observations.json保留5个新战4血成本与56血SL恢复，不把恢复当再次扣费/回血。selected-mechanisms与extra-windows保留紧勒选择完成时点、弃磨蚀及油灯导出状态。

未重新拟合任何血价、持药价、房间代价、SL门槛或终局曲线。原105/109局统计只作为原提案历史陈述，本批未重新分析其全部局，不能拿15局复核声称全史重算。未来训练/验证按独立run和开始时间分组，同战SL同组；须先隔离机制误差，再校准完整后继。

## 当前源码与实际live祖先

取证时live HEAD：`e713f211362f23e21102c63cd9a5e0195833021c`。20个相关生产/固定测试文件中14个与本基线字节相同，6个不同；每个live工作文件与其已提交blob相同，最后源码提交均核为该live HEAD的祖先。source-audit.json保存base blob、SHA、live SHA及完整提交，源码原字节用.txt保存、差异用.patch保存，未归档整树。

6处差异中card-model/potion-cost/sl-explore/boss-start为已见署名注释差，rollout/rollout-live还包含live并行Queen行为接线。此事实仅用于限定当前叶，不能声明整树等价、复原旧dirty运行或用别批测试作本批测试。

| 路径 | 实际live该叶最后源码提交（均为祖先） |
|---|---|
| agent/src/reflex/card-model.ts | `649f820249874f42d6035091ed8de2e709ebb8da` |
| agent/src/reflex/combat-plan.ts | `d959e176af7338ea2bca6f4ff9a39673b80e5fdf` |
| agent/src/reflex/turn-solver.ts | `d959e176af7338ea2bca6f4ff9a39673b80e5fdf` |
| agent/src/reflex/silent-sl-resource-comparison.ts | `0e4fe4df89a06682468e0e4716c12126e76369d5` |
| agent/src/reflex/continuation-value.ts | `c09762601e54bfc1ef7a1a8ee50e3285a4fd1e5c` |
| agent/src/sim/silent-opening.ts | `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8` |
| agent/src/sim/boss-sim.ts | `a8b202e34e94b11a340a8733800f7018688371b8` |
| agent/src/sim/double-boss-start.ts | `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8` |

这些是现有子实现的源码归属快照，不是本批源码提交，也不证明整个父提案已实现；本批不登记implemented/duplicate。

## 逐项处置

### silent-proposal-08eaa60bcc449852

原题：核赢战耗药与真实回复到boss入口的资源结转；缺未饮用/留药整战对照保留现价值规则。账本：silent-0019,silent-0020。

证据：KEN58SH9SLZ6 A10：F3 T2攻击药、F4 T1稳定、F5 T2速度、F11 T1虚弱/T2攻击、F15 T1发光/技能，decisions 274131/274156/274185/274235/274237/274267/274272。F12 26/76→53/81、F16 46/81→75/86；六个赢战净损0/3/0/37/6/0，F17六试全部失败。

现有覆盖：现有药价按角色适用表及连战reserve取值；药水槽位和SL剩余资源有对应实现。原提案不要求从本局直接拟合固定留药阈值。

处置：waiting。7饮和两次真实回复可核；缺同预算不饮用、早用、留用的完整战斗及后继对照，不能由F15零损推出可省药或留药能过Boss。

后续验证：先重放7个实际饮用、两次封顶/增上限回复和6次空药入口；独立run按时间留出比较完整后继，SL复原不计新回血/获药。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-92920295a648b540

原题：固定核对SL T6少损3也少伤9、首战赢后4血与F49开场死；三尝试按同局资源链验收，禁止将首胜/低可信0%当连战改善或SL依据，缺通关对照时保留原规则并等待新局。。账本：silent-0228,silent-0255。

证据：TXZ6RVMQA09D A10 F48 T6：第2/3试起始fingerprint一致，48血、敌460；states 281479→281484为损3/扣36，281535→281539为损0/扣27。第3试T10首胜4血，F49 T1 states 281565→281566为4→0、出牌0。sl-attempts保存三试及实际后战失败。

现有覆盖：continuationInput传同一样本剩余HP、药水和复活；fightSample覆盖已观察开场HP耗尽的零动作死亡，resource_comparison明确只属当前轮预测。

处置：waiting。局部少损3同时少打9，后续生成/抽序也改变；缺固定后继及相同预算的两战成对校准，三试不能拆独立局，未校准0%不能作为放宽必死/SL证据。

后续验证：保留三试首战结果和F49可操作前死亡，原答/替线/实打分别归属；补同条件两战完整后继及时间后移独立局验证。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-a327449c331efbc1

原题：复验沙虫全败探索同盘面9血换15伤与4血换沙坑一轮，保留血价、毒、沙坑两边界比较；缺独立胜局及完整反事实，不拟固定阈值，不放宽必死SL，行为证据不足部分保留waiting。。账本：silent-0079,silent-0018。

证据：WQZVENQ7DTRP A10 F33 T9第2/3试同fingerprint：states 282075→282079损13/扣24，282144→282148损22/扣39。T7第2/6试也同fingerprint：282066→282072损0/扣24，282330→282336损4/扣24，沙坑下一轮3→4。六试均失败。

现有覆盖：silent-sl-resource-comparison已列HP、伤害、剩余毒、沙坑、是否赢战及execution=unverified；explore仍按原B2/rollout门槛和排名筛选。

处置：waiting。已核9血换15伤及4血换一轮沙坑两种边界；缺同抽序、同预算完整执行及独立run排序校准，不能拟统一血伤交换阈值或笼统禁止延时线。

后续验证：两个同盘局部差额同时作约束；追踪换线后选择/抽牌/饮用的新题与完整执行，不能拿饱和模拟并列代替同安全。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-a099e89437e942bb

原题：狡诈药水确定生成与剩余手位、计划妥当保留容量及出刀穿插完整序列核验。账本：silent-0030,silent-0257,silent-0258。

证据：9局42饮全部重核：37次添3、2次添2、3次添0；新增均SHIV/upgraded=true/基础Damage6。WQZ F33第5试T11 decisions 276102/276103/276104手8→10→10→10，第6试276161/276162/276163手5→8→10→10，HP/能量不变。其余8局为02HB4L0C3C67、4D4J8USKCPAV、F4QKG4J1AJJZ、JLN5SK17W4FQ、LS8035TB32P3、NB8KCF6HRGVF、S9UZAK0JP0C0、SADL3CGYTGSR；较早A7/A9与A10分列。

现有覆盖：modelPotion已限定Silent A7/A9/A10生成3张基础6升级刀，turn-solver按手位加入并可穿插，rollout保留未打的生成刀。既有silent-cunning.test.ts包含容量和穿插夹具，本批仅读源码，未运行或宣称通过。

处置：waiting。3/2/0生成及局部穿插模型已有覆盖；原案要求的计划妥当保留、新题重读、SL恢复与完整穿插实际派发联合验收仍不齐，不能以局部模型关闭整项。

后续验证：以42饮确定窗口为固定输入，联合复核保留生效、生成后实际索引/重读、饮用—出刀—再饮与SL恢复；不要求胜局才能验证生成公式，也不声称穿插可救原败局。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-47910f82a1fdd98f

原题：无小血瓶王室猛毒开场4血续战入口、SL同盘攻防/沙坑代价与真实资源结转。账本：silent-0018,silent-0019,silent-0020,silent-0021,silent-0025,silent-0079,silent-0198,silent-0228,silent-0255。

证据：TXZ A10 F43/F45/F46/F48/F49开场分别70→66、52→48、62→58、60→56、4→0（states 281312/313、281338/339、281367/368、281399/400、281565/566）。F48第2/3试恢复已扣费后的56，不能再扣一次。另含上述TXZ T6、WQZ T7/T9血价窗口。

现有覆盖：silent-opening明确只给观察遗物组合、新建模拟开场扣4；真实T1和SL恢复不再扣。double-boss-start、boss-sim和continuation-value已有窄子实现。

处置：waiting。已观察的4血入口窄分支有真实live祖先；组合提案仍缺两战同预算完整后继校准、SL双向血价与持药价值的联合验证，未知回血/复活组合顺序不外推。

后续验证：开场成本只算一次，零HP在可出牌前终止；资源来自首战真实剩余样本，实回复和SL分账，同时验证WQZ攻击/沙坑两边界。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-f1374df72d8e6a25

原题：将胜战退出HP与药栏接入下一战评估，核对低置信选线和持续/临时药价；证据不足先保留阈值。账本：silent-0019,silent-0020,silent-0050,silent-0253。

证据：1913SE84AXQF A10 F17赢后14、幕间补44至58；F19/F23后44/40，F24锻造不回、F28回21至61、F29赢后46、F31入口46死亡。Q6M2Y34MWKRE A10 F2损12至44、F3事件付8、F7休息36→57、F8赢后2、F9 T2死亡；F2敏捷药实际T3才用，F8速度药只当轮+5。

现有覆盖：现有solver/rollout消费continuationValue，药价接口接受后战reserve；严格存活不因未来能力或毒进度补命。下一战资源估值不能只由接口存在判断已校准。

处置：waiting。原答的用药和后继链已核，但早喝/留药候选没有同预算整战实打对照；路线条件也曾改为锻造，不能把相关损血拟成新终局曲线或持药门槛。

后续验证：先隔离机制误差，分别验临时/持续药效、实际退出HP及药栏，再按run和时间留出完整后继比较，不将候选少损血写成实际收益。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-38a49e6c97f31eea

原题：第83批静默经验：紧勒逐牌失血与增益分源固定帧闭环。账本：silent-0006,silent-0011,silent-0025,silent-0044,silent-0050,silent-0064,silent-0133,silent-0253,silent-0259,silent-0261,silent-0262。

证据：Q6 A10 F8 T4 states 282887→282892：紧勒103→95建2，突然一拳→85，生存者选择中仍85、选择完成→83，轮末毒→80。1913 A10 F31 T2 282767→282768弃磨蚀后能量3不变，建立1敏/4荆棘；T3/T4的承伤、反伤、接续与新毒雾未兑现分别核。

现有覆盖：普通紧勒当轮、无挡已观察分支已接card-model/combat-plan/turn-solver，后轮清除；普通磨蚀手动施放已建模，但该事实不等同弃牌自动建立。再生5与临时敏捷5也有原模型。

处置：waiting。普通紧勒和若干子公式已覆盖；弃磨蚀、增益分源、自动效果、再生时点、SL恢复及完整后继的联合验收不足，不能以某一窄子修关闭组合提案。

后续验证：紧勒19→23只验已完成牌/选择时点；弃磨蚀与手动施放分开，逐击反伤不提前取消已发动攻击，重接不沿用旧毒/力量，净损与总伤分账。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-ef0e38a5dbd3bc07

原题：第83批静默经验：精英胜后连续血价与实际回复/能力资源链核验。账本：silent-0019,silent-0020,silent-0021。

证据：1913 A10 F24实际锻造不回血，F28回21至61，F29赢后46、F31死亡，未来F32营火未到。Q6 A10 F7回21至57，F8骇鳗赢损55至2，F9走廊死亡。两局资源链见resource-summary、rest-transitions及原八流引用。

现有覆盖：路线投影已有死亡不被未来休息抬回、回复受上限约束等接口；投影明确带假设，不能把未来默认休息当实际完成动作。

处置：waiting。缺另一事件/路线/休息或锻造选择及用药时点的完整成对后继；本批只核15个关联局，未重做原109局统计，不把相关性写为改线因果。

后续验证：按真实节点动作重建资源，精英赢后仍检查强制走廊；未来火、幕间、事件、战内回复和SL单列，参数须独立局按时间切分。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-7f820c02d39bfaea

原题：死亡统计饱和的SL替换须显式比较即时血价与击杀、存活推进，门槛等待固定验证。账本：silent-0079。

证据：NHA2KW0RB7VP A10 F33 T1第1/5/6试可操作起点fingerprint相同，均30血、敌总408；states 283391→283397损1/净扣8，283478→283483及283502→283507损7/净扣24。第1试过渡空手帧283390为28血，不能误当可操作起点；跨轮净扣含抱抱先生自动伤。六次SL尝试全败。

现有覆盖：原答和替线当轮资源预测已有日志；抽牌/选择后续步骤标未证实。notWorse筛选和实际执行归属并非同一件事。

处置：waiting。6血换16跨轮净扣可重核，但跨弃牌后完整计划归属、同预算排序校准与成对整战后继不足；第5/6次是同局重复，不能当独立成功或改全局阈值。

后续验证：原答、最初候选、弃牌后重规划及实际派发分别留痕；自动轮初伤与卡牌伤分源，不用初题候选充当已打出的完整计划。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

### silent-proposal-04b6b430759815ed

原题：按静默实帧核油灯首次放大、当前手数/脆弱/能量、蟹朝向取整及能力兑现；只修已观察子公式和估值窗口。账本：silent-0005,silent-0006,silent-0021,silent-0011,silent-0065,silent-0264,silent-0079,silent-0133,silent-0169,silent-0189,silent-0013,silent-0053,silent-0162,silent-0265。

证据：NHA A10 F17 T1普通毒药5→10（states 283146/147）；F33 T1六试X1萎靡均−2力/2弱（如283394/395、283505/506）。油灯对象前后相同且stack=null。更早K3676LU8B0UH A1 F30 T2带毒刺击4→8、SADL3CGYTGSR A7 F45毒药5→10按本批原流复核。NHA F33 T2朝向1→2及22总攻击，首试15挡损7；手数、敏捷、脆弱、第三轮能量等按已观察窗口保留。

现有覆盖：普通精确切击手数、已观察碾碎爪朝向底值、已建立能力/新轮能量等已有窄模型及固定夹具；油灯没有可直接复用的通用首次减益模型。

处置：waiting。油灯前后导出对象没有首次减益已消费标志；持有遗物或敌方当前无减益不能证明仍可翻倍，跨动作重读、新战与SL恢复的消费状态缺可追溯联合验证，其他子公式覆盖不能关闭整项。

后续验证：先建立有证据的首次消费状态及生命周期读回，再验证观察过的毒牌/普通X1萎靡；不推广零X、升级、叠层、其他状态或全局取整顺序，也不预支未建立能力。

预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。

## 记录、初稿与验收

potion-transitions.json初稿错误地按potion_index查槽，原动作实际用option_index，因此名称为null；初稿保留，potion-transitions-v2.json按实际schema修正并断言166个饮用均对应已占槽。19,929行原始抽取和校验不变，42饮统计用v2。NHA最早空手过渡帧28血与可操作30血分开；paired-local-outcomes明确从有手牌同fingerprint起点算，不将过渡回复或轮初自动伤混入战术差额。一次只读工具预检遇并行树目录消失而未执行，原错误属于工具运行限制，重试只读后成功，不列产品测试失败。

既有ledger仅通过根目录CLI追加where/note追溯本报告及逐项waiting；不重复补证或创建claim，不改31条既有claim/first_run/prior/evidence/status/version/effect，已经shipped的历史经验不降为proposed，也不将本批waiting误作新shipped。原10个代码提案ID直接引用，不重新add制造重复ID；队列最终处置由正常完成事件消费proposal_results。

生产源码无变更：tsc=null、vitest=null、cases=null。未跑LLM、网络、boss模拟池、play或完整/定向产品测试；不存在本批撤源码失败/恢复通过、源码提交、live合入、版本分配或规则上线双通知。固定取证脚本通过不填为tests.cases成功。未修改铁甲或其他角色知识/行为。

供运维交接的提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-121302/learner/runs/20261018-121311-1d9562ec-dfec-4a3e-8e57-44ae077f5d18-strategy-proposal/proposal.md；本报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-121302/learner/runs/20261018-121311-1d9562ec-dfec-4a3e-8e57-44ae077f5d18-strategy-proposal/report.md；机器结果：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-121302/learner/runs/20261018-121311-1d9562ec-dfec-4a3e-8e57-44ae077f5d18-strategy-proposal/report.json。最终现场核对与CLI回执见final-verification.json、ledger-link-receipt.json、ledger-check.log及artifact-manifest.json。

最终核验（2026-10-18T12:30:09+08:00）：原10份提案SHA保持一致，20个本基线源码/测试快照原字节不变，10项waiting覆盖完整；HEAD仍为7c27a19ac73ea6f5920b41d42689896f9996be44，tracked/index干净。根ledger CLI追加31条均仅where/note，原字节前缀不变，全账本516项/0问题。gitleaks扫描约498008139字节、返回0、未发现泄露；本批无源码测试、提交、合入或版本。

import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
STAMP = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
PROPOSALS = json.loads((OUT / 'assigned-proposals.json').read_text())
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
SOURCES = json.loads((OUT / 'source-audit.json').read_text())
MANIFEST = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())

details = [
    {
        'evidence': 'KEN58SH9SLZ6 A10：F3 T2攻击药、F4 T1稳定、F5 T2速度、F11 T1虚弱/T2攻击、F15 T1发光/技能，decisions 274131/274156/274185/274235/274237/274267/274272。F12 26/76→53/81、F16 46/81→75/86；六个赢战净损0/3/0/37/6/0，F17六试全部失败。',
        'covered': '现有药价按角色适用表及连战reserve取值；药水槽位和SL剩余资源有对应实现。原提案不要求从本局直接拟合固定留药阈值。',
        'reason': '7饮和两次真实回复可核；缺同预算不饮用、早用、留用的完整战斗及后继对照，不能由F15零损推出可省药或留药能过Boss。',
        'validation': '先重放7个实际饮用、两次封顶/增上限回复和6次空药入口；独立run按时间留出比较完整后继，SL复原不计新回血/获药。',
    },
    {
        'evidence': 'TXZ6RVMQA09D A10 F48 T6：第2/3试起始fingerprint一致，48血、敌460；states 281479→281484为损3/扣36，281535→281539为损0/扣27。第3试T10首胜4血，F49 T1 states 281565→281566为4→0、出牌0。sl-attempts保存三试及实际后战失败。',
        'covered': 'continuationInput传同一样本剩余HP、药水和复活；fightSample覆盖已观察开场HP耗尽的零动作死亡，resource_comparison明确只属当前轮预测。',
        'reason': '局部少损3同时少打9，后续生成/抽序也改变；缺固定后继及相同预算的两战成对校准，三试不能拆独立局，未校准0%不能作为放宽必死/SL证据。',
        'validation': '保留三试首战结果和F49可操作前死亡，原答/替线/实打分别归属；补同条件两战完整后继及时间后移独立局验证。',
    },
    {
        'evidence': 'WQZVENQ7DTRP A10 F33 T9第2/3试同fingerprint：states 282075→282079损13/扣24，282144→282148损22/扣39。T7第2/6试也同fingerprint：282066→282072损0/扣24，282330→282336损4/扣24，沙坑下一轮3→4。六试均失败。',
        'covered': 'silent-sl-resource-comparison已列HP、伤害、剩余毒、沙坑、是否赢战及execution=unverified；explore仍按原B2/rollout门槛和排名筛选。',
        'reason': '已核9血换15伤及4血换一轮沙坑两种边界；缺同抽序、同预算完整执行及独立run排序校准，不能拟统一血伤交换阈值或笼统禁止延时线。',
        'validation': '两个同盘局部差额同时作约束；追踪换线后选择/抽牌/饮用的新题与完整执行，不能拿饱和模拟并列代替同安全。',
    },
    {
        'evidence': '9局42饮全部重核：37次添3、2次添2、3次添0；新增均SHIV/upgraded=true/基础Damage6。WQZ F33第5试T11 decisions 276102/276103/276104手8→10→10→10，第6试276161/276162/276163手5→8→10→10，HP/能量不变。其余8局为02HB4L0C3C67、4D4J8USKCPAV、F4QKG4J1AJJZ、JLN5SK17W4FQ、LS8035TB32P3、NB8KCF6HRGVF、S9UZAK0JP0C0、SADL3CGYTGSR；较早A7/A9与A10分列。',
        'covered': 'modelPotion已限定Silent A7/A9/A10生成3张基础6升级刀，turn-solver按手位加入并可穿插，rollout保留未打的生成刀。既有silent-cunning.test.ts包含容量和穿插夹具，本批仅读源码，未运行或宣称通过。',
        'reason': '3/2/0生成及局部穿插模型已有覆盖；原案要求的计划妥当保留、新题重读、SL恢复与完整穿插实际派发联合验收仍不齐，不能以局部模型关闭整项。',
        'validation': '以42饮确定窗口为固定输入，联合复核保留生效、生成后实际索引/重读、饮用—出刀—再饮与SL恢复；不要求胜局才能验证生成公式，也不声称穿插可救原败局。',
    },
    {
        'evidence': 'TXZ A10 F43/F45/F46/F48/F49开场分别70→66、52→48、62→58、60→56、4→0（states 281312/313、281338/339、281367/368、281399/400、281565/566）。F48第2/3试恢复已扣费后的56，不能再扣一次。另含上述TXZ T6、WQZ T7/T9血价窗口。',
        'covered': 'silent-opening明确只给观察遗物组合、新建模拟开场扣4；真实T1和SL恢复不再扣。double-boss-start、boss-sim和continuation-value已有窄子实现。',
        'reason': '已观察的4血入口窄分支有真实live祖先；组合提案仍缺两战同预算完整后继校准、SL双向血价与持药价值的联合验证，未知回血/复活组合顺序不外推。',
        'validation': '开场成本只算一次，零HP在可出牌前终止；资源来自首战真实剩余样本，实回复和SL分账，同时验证WQZ攻击/沙坑两边界。',
    },
    {
        'evidence': '1913SE84AXQF A10 F17赢后14、幕间补44至58；F19/F23后44/40，F24锻造不回、F28回21至61、F29赢后46、F31入口46死亡。Q6M2Y34MWKRE A10 F2损12至44、F3事件付8、F7休息36→57、F8赢后2、F9 T2死亡；F2敏捷药实际T3才用，F8速度药只当轮+5。',
        'covered': '现有solver/rollout消费continuationValue，药价接口接受后战reserve；严格存活不因未来能力或毒进度补命。下一战资源估值不能只由接口存在判断已校准。',
        'reason': '原答的用药和后继链已核，但早喝/留药候选没有同预算整战实打对照；路线条件也曾改为锻造，不能把相关损血拟成新终局曲线或持药门槛。',
        'validation': '先隔离机制误差，分别验临时/持续药效、实际退出HP及药栏，再按run和时间留出完整后继比较，不将候选少损血写成实际收益。',
    },
    {
        'evidence': 'Q6 A10 F8 T4 states 282887→282892：紧勒103→95建2，突然一拳→85，生存者选择中仍85、选择完成→83，轮末毒→80。1913 A10 F31 T2 282767→282768弃磨蚀后能量3不变，建立1敏/4荆棘；T3/T4的承伤、反伤、接续与新毒雾未兑现分别核。',
        'covered': '普通紧勒当轮、无挡已观察分支已接card-model/combat-plan/turn-solver，后轮清除；普通磨蚀手动施放已建模，但该事实不等同弃牌自动建立。再生5与临时敏捷5也有原模型。',
        'reason': '普通紧勒和若干子公式已覆盖；弃磨蚀、增益分源、自动效果、再生时点、SL恢复及完整后继的联合验收不足，不能以某一窄子修关闭组合提案。',
        'validation': '紧勒19→23只验已完成牌/选择时点；弃磨蚀与手动施放分开，逐击反伤不提前取消已发动攻击，重接不沿用旧毒/力量，净损与总伤分账。',
    },
    {
        'evidence': '1913 A10 F24实际锻造不回血，F28回21至61，F29赢后46、F31死亡，未来F32营火未到。Q6 A10 F7回21至57，F8骇鳗赢损55至2，F9走廊死亡。两局资源链见resource-summary、rest-transitions及原八流引用。',
        'covered': '路线投影已有死亡不被未来休息抬回、回复受上限约束等接口；投影明确带假设，不能把未来默认休息当实际完成动作。',
        'reason': '缺另一事件/路线/休息或锻造选择及用药时点的完整成对后继；本批只核15个关联局，未重做原109局统计，不把相关性写为改线因果。',
        'validation': '按真实节点动作重建资源，精英赢后仍检查强制走廊；未来火、幕间、事件、战内回复和SL单列，参数须独立局按时间切分。',
    },
    {
        'evidence': 'NHA2KW0RB7VP A10 F33 T1第1/5/6试可操作起点fingerprint相同，均30血、敌总408；states 283391→283397损1/净扣8，283478→283483及283502→283507损7/净扣24。第1试过渡空手帧283390为28血，不能误当可操作起点；跨轮净扣含抱抱先生自动伤。六次SL尝试全败。',
        'covered': '原答和替线当轮资源预测已有日志；抽牌/选择后续步骤标未证实。notWorse筛选和实际执行归属并非同一件事。',
        'reason': '6血换16跨轮净扣可重核，但跨弃牌后完整计划归属、同预算排序校准与成对整战后继不足；第5/6次是同局重复，不能当独立成功或改全局阈值。',
        'validation': '原答、最初候选、弃牌后重规划及实际派发分别留痕；自动轮初伤与卡牌伤分源，不用初题候选充当已打出的完整计划。',
    },
    {
        'evidence': 'NHA A10 F17 T1普通毒药5→10（states 283146/147）；F33 T1六试X1萎靡均−2力/2弱（如283394/395、283505/506）。油灯对象前后相同且stack=null。更早K3676LU8B0UH A1 F30 T2带毒刺击4→8、SADL3CGYTGSR A7 F45毒药5→10按本批原流复核。NHA F33 T2朝向1→2及22总攻击，首试15挡损7；手数、敏捷、脆弱、第三轮能量等按已观察窗口保留。',
        'covered': '普通精确切击手数、已观察碾碎爪朝向底值、已建立能力/新轮能量等已有窄模型及固定夹具；油灯没有可直接复用的通用首次减益模型。',
        'reason': '油灯前后导出对象没有首次减益已消费标志；持有遗物或敌方当前无减益不能证明仍可翻倍，跨动作重读、新战与SL恢复的消费状态缺可追溯联合验证，其他子公式覆盖不能关闭整项。',
        'validation': '先建立有证据的首次消费状态及生命周期读回，再验证观察过的毒牌/普通X1萎靡；不推广零X、升级、叠层、其他状态或全局取整顺序，也不预支未建立能力。',
    },
]

results = [{'id': proposal['id'], 'state': 'waiting', 'reason': detail['reason']}
           for proposal, detail in zip(PROPOSALS, details)]
report_json = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-121302-strategy-proposal',
    'base': BASE, 'runs': DISPATCH['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [p['id'] for p in PROPOSALS], 'implementation_domains': [],
    'proposal_results': results, 'report': str(OUT / 'report.md'),
}
(OUT / 'report.json').write_text(json.dumps(report_json, ensure_ascii=False, indent=2) + '\n')
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

lines = [
    '# 静默猎手已领取策略提案逐项复核', '',
    f'记录时间：{STAMP}。批次：20261018-121302-strategy-proposal。', '',
    f'基线与当前HEAD：`{BASE}`；开工tracked/index干净，普通批次`git merge --no-edit main`返回Already up to date。本批没有research_request或implementation_request；根专题文件绑定另一旧批次，未承接其work_spec或扩展选题。', '',
    '结论：10个已领取提案全部保留waiting。确定机制中的若干窄分支已经存在；本批没有足够的新证据支持补齐组合提案或改变排序/药价/SL/终局规则。未改生产源码、知识或任务模板；fixes=[]、merged=null，无提交、版本、shipped、源码撤回红绿或生产测试成绩。取证脚本仅存本批忽略的scratch。', '',
    '## 身份与输入', '',
    '已保存dispatch.json、assigned-proposals.json、10份原提案逐字副本及SHA核验，31个相关账本完整折叠快照和26个相关Silent经验。只消费本批10个ID，不增领/新增重复代码提案；原提案和父请求不修改。运行参数由宿主控制，本批未修改模型/强度/权限；未独立读取原生运行请求，不能以默认配置冒称实际运行参数核验。', '',
    'runs.jsonl逐行核角色，15局全为SILENT。10个派发锚点保留原顺序；额外5局仅因这10个提案已保存的证据链接而复核：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。其中K367为A1、SAD为A7、F4Q为A9，其余A10。不能把这些混成单一进阶分母，也不把旧混合引擎局当纯Codex成绩。', '',
    '## 原日志与复核范围', '',
    '使用指定learner/extract_evidence.py抽取8流，逐流先冻结source_size；各流截点并非原子快照。evidence-manifest.json保存逐局计数和输出SHA；每行保存source/line/offset/bytes/SHA/显式身份。独立audit_evidence.py逐行seek原日志核字节、SHA、JSON、归属与角色，全部19929行通过；9448个决策均按同局fingerprint及不晚于决策的时间连到状态。此为材料校验，不是产品单元测试或生产消费者验收。', '',
    '| 流 | 本批选中行 | 源字节截点 | 全源坏行 |',
    '|---|---:|---:|---:|',
]
for m in MANIFEST:
    lines.append(f"| {m['stream']} | {sum(m['counts'].values())} | {m['source_size']} | {m['invalid_lines']} |")
lines += [
    '', '三个流各2条坏行是该源截点全体扫描统计，不能归因到目标局。fight-plans选中0只表示这个截点和显式身份筛选未选到，不断言原日志缺失。run-plans以run识别，其余流同时检查run_id/state.run_id/fingerprint.run，冲突身份不接收。原始日志只读，抽取和引用均在本批scratch。', '',
    'states-summary/resource-summary是索引材料，last_observed_hp不自动等于战斗退出HP；同层后续回复/升级及过渡帧须另核。尝试号只使用明确SL区间，区间外保持null，不能默认归首试。原记录的dirty执行树没有完整冻结，本批当前源码不能冒充历史执行源码。', '',
    '## 支持、反例与参数限制', '',
    'paired-local-outcomes.json保存4组相同起始fingerprint的局部比较：TXZ T6 (3损/36净扣) 对 (0损/27净扣)，WQZ T9 (13/24) 对 (22/39)，WQZ T7 (0/24) 对 (4/24)并多一轮沙坑，NHA T1 (1/8) 对 (7/24)。这里的敌净扣跨到下一玩家轮，NHA含轮初自动伤，不能全算作卡牌伤。后续抽序/生成/选择并未受控，失败尝试不拆独立局。WQZ T7反例尤其不支持统一拒绝额外付血的延时方案。', '',
    'cunning-42-validation.json逐饮核9局42次3/2/0、升级状态、基础6、HP与能量未变。它验证确定生成窗口，不能证明完整穿插已实际派发或改善整战。royal-opening-observations.json保留5个新战4血成本与56血SL恢复，不把恢复当再次扣费/回血。selected-mechanisms与extra-windows保留紧勒选择完成时点、弃磨蚀及油灯导出状态。', '',
    '未重新拟合任何血价、持药价、房间代价、SL门槛或终局曲线。原105/109局统计只作为原提案历史陈述，本批未重新分析其全部局，不能拿15局复核声称全史重算。未来训练/验证按独立run和开始时间分组，同战SL同组；须先隔离机制误差，再校准完整后继。', '',
    '## 当前源码与实际live祖先', '',
    f"取证时live HEAD：`{SOURCES[0]['live_head']}`。20个相关生产/固定测试文件中14个与本基线字节相同，6个不同；每个live工作文件与其已提交blob相同，最后源码提交均核为该live HEAD的祖先。source-audit.json保存base blob、SHA、live SHA及完整提交，源码原字节用.txt保存、差异用.patch保存，未归档整树。", '',
    '6处差异中card-model/potion-cost/sl-explore/boss-start为已见署名注释差，rollout/rollout-live还包含live并行Queen行为接线。此事实仅用于限定当前叶，不能声明整树等价、复原旧dirty运行或用别批测试作本批测试。', '',
    '| 路径 | 实际live该叶最后源码提交（均为祖先） |', '|---|---|',
]
for r in SOURCES:
    if r['path'] in ['agent/src/reflex/card-model.ts', 'agent/src/reflex/combat-plan.ts', 'agent/src/reflex/turn-solver.ts',
                     'agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/sim/silent-opening.ts',
                     'agent/src/sim/boss-sim.ts', 'agent/src/sim/double-boss-start.ts', 'agent/src/reflex/continuation-value.ts']:
        lines.append(f"| {r['path']} | `{r['live_last_source_commit']}` |")
lines += ['', '这些是现有子实现的源码归属快照，不是本批源码提交，也不证明整个父提案已实现；本批不登记implemented/duplicate。', '', '## 逐项处置', '']
for proposal, detail in zip(PROPOSALS, details):
    lines += [f"### {proposal['id']}", '',
              f"原题：{proposal['summary']}。账本：{','.join(proposal['ledger'])}。", '',
              f"证据：{detail['evidence']}", '', f"现有覆盖：{detail['covered']}", '',
              f"处置：waiting。{detail['reason']}", '', f"后续验证：{detail['validation']}", '',
              '预期行为：证据齐备前保留当前生产规则；若后续实现，只改变已观察的Silent分支，固定数据先撤源失败/恢复通过并经沙箱入口验证。回退仅撤该单项源码提交，保留原证据/账本及失败历史；实际上线后按既有授权通知Roy，不预记shipped。', '']
lines += [
    '## 记录、初稿与验收', '',
    'potion-transitions.json初稿错误地按potion_index查槽，原动作实际用option_index，因此名称为null；初稿保留，potion-transitions-v2.json按实际schema修正并断言166个饮用均对应已占槽。19,929行原始抽取和校验不变，42饮统计用v2。NHA最早空手过渡帧28血与可操作30血分开；paired-local-outcomes明确从有手牌同fingerprint起点算，不将过渡回复或轮初自动伤混入战术差额。一次只读工具预检遇并行树目录消失而未执行，原错误属于工具运行限制，重试只读后成功，不列产品测试失败。', '',
    '既有ledger仅通过根目录CLI追加where/note追溯本报告及逐项waiting；不重复补证或创建claim，不改31条既有claim/first_run/prior/evidence/status/version/effect，已经shipped的历史经验不降为proposed，也不将本批waiting误作新shipped。原10个代码提案ID直接引用，不重新add制造重复ID；队列最终处置由正常完成事件消费proposal_results。', '',
    '生产源码无变更：tsc=null、vitest=null、cases=null。未跑LLM、网络、boss模拟池、play或完整/定向产品测试；不存在本批撤源码失败/恢复通过、源码提交、live合入、版本分配或规则上线双通知。固定取证脚本通过不填为tests.cases成功。未修改铁甲或其他角色知识/行为。', '',
    f'供运维交接的提案：{OUT / "proposal.md"}；本报告：{OUT / "report.md"}；机器结果：{OUT / "report.json"}。最终现场核对与CLI回执见final-verification.json、ledger-link-receipt.json、ledger-check.log及artifact-manifest.json。', '',
]
(OUT / 'report.md').write_text('\n'.join(lines))
proposal_text = [
    '# 本批已领取提案与验证边界', '', f'基线：{BASE}；批次：20261018-121302-strategy-proposal。记录：{STAMP}。', '',
    '本批处理以下10个原ID，不另建重复提案。完整证据、源码祖先及局限见report.md；原Markdown逐字保存为对应ID.md。全部waiting，未改策略。', '',
]
for proposal, detail in zip(PROPOSALS, details):
    proposal_text += [f"## {proposal['id']}", '', f"账本：{','.join(proposal['ledger'])}；来源任务：{proposal['source_task']}；实现任务：strategy-proposal。", '',
                      f"证据：{detail['evidence']}", '', f"现有规则/覆盖：{detail['covered']}", '',
                      f"结论与缺数据：{detail['reason']}", '', f"验证方法：{detail['validation']}", '',
                      '反例/限制：局部公式与整战因果分开，同局SL不当独立样本；未知组合保持未知。当前预期行为保持原规则。无新增参数拟合；未来按独立局和时间切分。回退仅撤后续实际单项源码提交，保留原日志/初稿/账本；授权Roy-2026-10-07-learning不提供游戏事实。', '']
(OUT / 'proposal.md').write_text('\n'.join(proposal_text))
print(json.dumps({'base': BASE, 'report': str(OUT / 'report.md'), 'proposals': len(results)}, ensure_ascii=False))

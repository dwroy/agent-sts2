from pathlib import Path
import datetime, hashlib, importlib.util, json, os, re, subprocess, sys, tarfile

sys.dont_write_bytecode = True
root = Path.cwd()
private = root / 'ops/codex-ops/record-staging/20261016-0214'
public = root / 'paper/materials/20261016-0214-ops'
public.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def git(*args):
    return subprocess.check_output(['git', *args], stderr=subprocess.PIPE)

assert not (private / 'record-manifest.json').exists()
batch_id = '20261016-020233-strategy-proposal'
state = json.loads((root / 'ops/codex-ops/learn.json').read_text())
batch = state['batches'][batch_id]
assert batch['state'] == 'failed' and batch['rc'] == 1 and batch['merged'] is None
assert batch['report'] == {} and batch['proposal_audit_errors'] == []
assert batch['completion_failure']['reason'] == 'learner exited without a completion report'
prior = [dict(id=k, state=v['state'], rc=v.get('rc'), retry_at=v.get('retry_at'))
         for k, v in state['batches'].items() if v.get('key') == batch['key']]
assert len(prior) == 1 and prior[0]['id'] == batch_id
out = root / f'ops/codex-ops/learner/{batch_id}.out'
err = out.with_suffix('.err')
output = out.read_text()
thread = re.search(r'会话：([^\n]+)', output).group(1)
log = Path(re.search(r'^日志：([^\n]+)', output, re.M).group(1))
events = []
with log.open('rb') as handle:
    while True:
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        events.append(dict(offset=offset, bytes=len(raw), sha256=sha(raw), value=json.loads(raw)))
launches = [e for e in events if e['value'].get('type') == 'learner_launch']
assert len(launches) == 1
launch = launches[0]['value']
tree = Path(batch['worktree'])
scratch = Path(launch['params']['scratch'])
assert launch['cwd'] == str(tree) and launch['task'] == 'strategy-proposal'
assert launch['params']['batch'] == batch_id and scratch.is_relative_to(tree)
starts = [e for e in events if e['value'].get('type') == 'learner_startup_attempt']
exits = [e for e in events if e['value'].get('type') == 'learner_startup_exit']
threads = [e for e in events if e['value'].get('type') == 'thread.started']
assert len(starts) == len(exits) == len(threads) == 1
assert starts[0]['value']['batch'] == exits[0]['value']['batch'] == batch_id
assert starts[0]['value']['input_sha256'] == exits[0]['value']['input_sha256']
assert starts[0]['value']['command_sha256'] == exits[0]['value']['command_sha256']
assert starts[0]['value']['lease'] == exits[0]['value']['lease']
assert threads[0]['value']['thread_id'] == thread
native = list((root / 'ops/codex-ops/accounts/codex1/learner/sessions').glob('**/*' + thread + '.jsonl'))
assert len(native) == 1
context = None
user_input = None
with native[0].open('rb') as handle:
    for _ in range(512):
        offset = handle.tell()
        raw = handle.readline()
        if not raw:
            break
        event = json.loads(raw)
        payload = event.get('payload', {})
        if event.get('type') == 'turn_context':
            assert payload['cwd'] == str(tree) and payload['model'] == 'gpt-6.1-sol' and payload['effort'] == 'xhigh'
            assert payload['sandbox_policy']['type'] == 'workspace-write'
            assert payload['sandbox_policy'].get('network_access') is False and payload['approval_policy'] == 'never'
            context = dict(source=str(native[0].relative_to(root)), offset=offset, bytes=len(raw), sha256=sha(raw),
                           model=payload['model'], effort=payload['effort'], sandbox=payload['sandbox_policy'], approval_policy=payload['approval_policy'])
        if event.get('type') == 'response_item' and payload.get('role') == 'user':
            text = ''.join(item.get('text', '') for item in payload.get('content', []) if item.get('type') == 'input_text')
            if sha(text.encode()) == starts[0]['value']['input_sha256']:
                user_input = dict(offset=offset, bytes=len(raw), sha256=sha(raw), input_sha256=sha(text.encode()))
        if context and user_input:
            break
assert context and user_input
failed = [e for e in events if e['value'].get('type') == 'turn.failed']
assert len(failed) == 1 and failed[0]['value']['error']['message'] == 'Selected model is at capacity. Please try a different model.'
commands = [e for e in events if e['value'].get('type') == 'item.completed' and e['value'].get('item', {}).get('type') == 'command_execution']
assert len(commands) == 5 and all(e['value']['item']['exit_code'] == 0 for e in commands)
assert all(any(phrase in e['value']['item']['command'] for phrase in ['rg --files paper/materials', 'git status --short', "sed -n '1,220p' README.md", "sed -n '1,240p' docs/learning-protocol.md", "p='/home/dw/Projects/agent-sts2/ops/codex-ops/learn.json'"]) for e in commands)
assert git('-C', str(tree), 'status', '--porcelain', '--untracked-files=all') == b''
worktree_head = git('-C', str(tree), 'rev-parse', 'HEAD').decode().strip()
assert worktree_head == 'd523c467cb0e00cfbf181f4490ba6a4d0fbf1ba1'
assert scratch.exists() and not any(scratch.rglob('*'))
spec = importlib.util.spec_from_file_location('original_proposals', root / 'learner/code_proposals.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
queue = module.fold(root / 'paper/materials/learning/code-proposals.jsonl')
proposals = []
for ident in batch['proposal_ids']:
    item = queue[ident]
    source = Path(item['proposal'])
    assert item['character'] == 'silent' and item['state'] == 'waiting'
    assert source.is_relative_to(root) and sha(source.read_bytes()) == item['proposal_sha256']
    proposals.append({key: item.get(key) for key in ['id', 'character', 'state', 'batch', 'proposal', 'proposal_sha256', 'reason']})
assert len(proposals) == 10
retry = datetime.datetime.fromtimestamp(batch['retry_at'], datetime.timezone.utc).astimezone().isoformat()
originals = []
for source in [out, err, log]:
    raw = source.read_bytes()
    saved = public / 'originals' / source.name
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(raw)
    originals.append(dict(source=str(source.relative_to(root)), copy=str(saved.relative_to(root)), bytes=len(raw), sha256=sha(raw)))
selected = []
for entry in events:
    event = entry['value']
    if event.get('type') in ['learner_launch', 'learner_startup_attempt', 'learner_startup_exit', 'thread.started', 'error', 'turn.failed']:
        selected.append({key: value for key, value in entry.items() if key != 'value'} | dict(event=event))
write(public / 'failure-readback.json', dict(batch=batch_id, original_batch=batch, original_same_key_attempts=prior,
    classification='Provider 503/capacity interruption after read-only initialization; not a proposal rejection, missing proposal, quota denial or successful empty result.',
    runtime=dict(thread=thread, native_context=context, native_user_input=user_input, original_lease=starts[0]['value']['lease'],
                 startup_attempts=1, original_failure_exit_preserved=True), original_selected_events=selected,
    completed_read_only_commands=[dict(offset=e['offset'], bytes=e['bytes'], sha256=e['sha256'], command=e['value']['item']['command'], exit_code=0) for e in commands],
    worktree_head=worktree_head, all_files_clean=True, scratch_empty=True, original_proposals=proposals, retry_not_before=retry,
    retry_scope='Existing scheduler key and cooldown, subject to original three-attempt and free-slot gates. No dispatch or state edit by ops.',
    source_outputs=False, completion_accepted=False, tests=None, merge=None, ledger_updates=0, original_artifacts=originals))
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(at, flush=True)
decision = f'\n- {at} 运维codex：0214原020233策略failed/rc1/mergednull中断核；原stdout/stderr/161914字节事件SHA及实际线程{thread}/Sol6.1-xhigh/input/lease/workspace-write/no-network核。原503重连4次、进入线程完成5条只读初始化命令后Selected model is at capacity，不当额度耗尽、提案缺失/拒绝或正常空产出；原空report/completion_failure保留，scratch空、WT全部干净/HEADd523c467不变，无可兜底源码或合入受阻。十原提案文件SHA及既有waiting保持，当前key311仅一次失败，旧queue key310不冒本轮新处置；原retry_at={retry}、三次上限/空闲门槛沿调度器，不立即重派/切模型/改状态或重复登记台账。原失败原件归档，宽父保持；仅本人记录提交，无源码/知识/版本/论文刷新/测试/对局重启/账号home额度权限prompt操作。证据paper/materials/20261016-0214-ops/。\n'
note = f'\n- {at} [运维 codex] 原020233策略因503/模型容量中断，已核原失败、干净工作树与十原提案，未取得完成回报，不记提案缺失/成功；原调度器不早于03:03:24 CST按既有门槛重试，本轮不重复派发或切模型。回执paper/materials/20261016-0214-ops/failure-readback.json。\n'
appends = {'paper/materials/decision-log.md': decision, 'ops/inbox-dev.md': note}
write(private / 'own-appends.json', appends)
base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
values = {}
for path, text in appends.items():
    values[path] = git('show', base + ':' + path) + text.encode()
    with (root / path).open('ab') as handle:
        handle.write(text.encode())
helpers = []
with tarfile.open(public / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    for source in sorted(private.glob('*.py')):
        raw = source.read_bytes()
        archive.add(source, arcname=source.name)
        helpers.append(dict(path=str(source.relative_to(root)), bytes=len(raw), sha256=sha(raw)))
write(public / 'ops-helper-manifest.json', helpers)
write(public / 'completion.json', dict(at=at, batch=batch_id, status='failure preserved; existing delayed retry', new_dispatch=False,
    proposal_count=10, ledger_updates=0, source_or_live_changes=False, tests_rerun=False, wide_parents='unchanged'))
for source in public.rglob('*'):
    if source.is_file():
        values[str(source.relative_to(root))] = source.read_bytes()
entries = []
for path, raw in values.items():
    saved = private / 'final-files' / path
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(private / 'record-manifest.json', dict(base=base, paths=entries))
print(json.dumps(dict(proposals=10, commands=5, failed=True, retry_not_before=retry, paths=len(entries))))

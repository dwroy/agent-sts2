import json
import re
from pathlib import Path

SCRATCH = Path('/home/dw/Projects/agent-sts2/learner/runs/20261016-021305-766207d6-5101-44f3-aab1-d54eeb714401-fix-batch')
audit = json.loads((SCRATCH / 'audit.json').read_text())
assert (SCRATCH / 'tsc.exit').read_text().strip() == '0'
assert (SCRATCH / 'vitest.exit').read_text().strip() == '0'
log = (SCRATCH / 'vitest.log').read_text()
assert re.search(r'Test Files\s+9 passed \(9\)', log)
assert re.search(r'Tests\s+69 passed \(69\)', log)
names = {
    810: 'silent-0271：毒必胜提前返回遗漏连战保血候选',
    817: 'silent-0272：商店移除预览误报现场可选卡',
    831: 'silent-0279：SL抽序升级改标误判插牌',
    900: 'rollout最佳线路补入题面的固定夹具确定性',
    964: 'silent-0334：升级隐秘匕首模型',
    1034: 'ascension-up：请求目标进阶误报为实际进阶',
    1040: '框架/测试收尾：外层时限与分段续验',
    1041: '调度公平性核查',
    1110: 'host-fixed-test-timeouts-010547：eval/Apotheosis固定夹具',
}


def label(item):
    if item['line'] in names:
        return names[item['line']]
    match = re.search(r'\*\*(.*?)\*\*', item['item'])
    assert match, item['line']
    return match[1]


skipped = [
    {'item': label(item), 'reason': item['disposition']}
    for item in audit['queue_dispositions']
    if not item.get('commit') and not item.get('commits')
]
result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [],
    'skipped': skipped, 'merged': None,
    'tests': {'tsc': 0, 'vitest': 0, 'cases': 69},
    'code_proposals': [], 'implementation_domains': [],
    'report': str(SCRATCH / 'report.md'),
}
verification = {
    'tsc_command': 'nice -n 19 npx tsc -p tsconfig.json --noEmit',
    'tsc': 0,
    'vitest_command': 'nice -n 19 npx vitest run --pool=threads --maxWorkers=1 tests/learner-startup-recovery.test.ts tests/learner-launch-failures.test.ts tests/learner-entry.test.ts tests/learner-registration-barrier.test.ts tests/ledger-publication-baseline.test.ts tests/silent-paper-krane.test.ts tests/target-options.test.ts tests/feature-notice-registration.test.ts tests/boss-sim-notice-registration.test.ts',
    'vitest': 0, 'files': 9, 'cases': 69, 'retried': False,
    'full_sandbox_suite_run': False,
    'reason': '本批无源码变更及新提交，运行类型检查与既有修复定向固定回归；未运行完整沙箱/宿主套件。',
    'environment': 'TMPDIR仅本任务scratch；PATH本地Node；npm离线；不继承CHARACTER；nice19、单worker；Python字节码仅scratch。',
    'without_fix_check': '不适用：没有新增修复，未撤掉已有修复，历史红绿不冒作本批结果。',
    'preparation_errors': '一次只读rg使用错误路径learner/startup-recovery.ts与ops/learner_registration.py；后用rg --files定位实际文件。未改源码，不是测试失败。',
}
(SCRATCH / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
active_fixed = [i for i in audit['queue_dispositions'] if i.get('commit') or i.get('commits')]
out = [
    '## 修 bug 回报',
    f"- 合并基线：main → {audit['base']}（开工工作区干净，git merge --no-edit main 返回 Already up to date）",
    '- 修复（每条一行）：无新增纯 bug 修复；fixes=[]，未创建提交。',
    '- 已被别人修掉的：当前42条未勾选项中16条已有修复或限定子项覆盖，逐条提交见下表；另核74个既有修复/子项的来源和当前源码。',
    '- 没修的：26条策略/架构/证据不足条目逐条列于下表；已有自动策略链保持，不新建重复提案或派下级。',
    '- 测试：tsc退出码0；vitest定向9文件/69用例/退出码0；无重跑。没有源码变更或提交，未运行完整test-sandbox.sh，不声称全量套件通过。',
    '- 合入：未合入（merged=null）；无新增源码，未空合并、未改live刷新数据。',
    '- 需要 Roy 定的事（没有写「无」）：无。',
    '',
    '本批产物只写指定scratch；另按需展开一个已提交历史材料，未改其内容。未改修复队列、学习账本、代码提案队列、版本或上线记录。无实际上线，不登记shipped。技能药水生命周期文字与MAD_SCIENCE三段攻击均保留原独立策略提案；没有将游戏模型问题转成普通基础设施实现。',
    '',
    '逐条未勾选项核查（有提交仅指已实现的限定范围，不关闭宽父）：',
    '',
    '| 队列行 | 条目 | 处置/源码提交 |',
    '|---|---|---|',
]
for item in audit['queue_dispositions']:
    commits = item.get('commits') or ([item['commit']] if item.get('commit') else [])
    detail = ('已修/限定子项；' + '、'.join(commits)) if commits else item['disposition']
    out.append(f"| {item['line']} | {label(item)} | {detail} |")
out += [
    '',
    f"既有修复追溯：74个来源提交均为本基线及只读live快照 {audit['live_read_only_snapshot']} 的祖先；381个唯一源码路径逐字节与上一已核基线和HEAD一致。live存在136个历史叶差与4个缺少路径，未覆盖、未修饰为等同，逐项见audit.json。队列前1342行的SHA与上一核验一致，仅新增第1344行silent-0487；当前队列1344行、42个未勾选项全部有处置。",
    '',
    '| 既有修复/子项 | 源码提交 |',
    '|---|---|',
]
for fix in audit['existing_fixes']:
    out.append(f"| {fix['item']} | {fix['source_commit']} |")
out += [
    '',
    '证据与限制：',
    '',
    '- 本批通过上一已归档核验记录的精确路径按需恢复，并独立核对队列前缀SHA、来源祖先、源码SHA和当前工作区；原记录仍保留，未当作本批测试结果。来源、恢复提交/blob与逐叶数据见audit.json。',
    '- silent-0487当前card-model.ts读取CalculatedHits/Repeat并识别两次文字，未读取ViolenceHits；该项基于JWK2C8LE4SFV/A10/F48首试T5、末试T8，按原silent-proposal-0a0b31e284e6793e交独立策略链。本批未重做对局语义研究，原证据局号/回合来自队列，不冒称已独立核完整原日志。',
    '- silent-0481题面仍写only for this turn，按原silent-proposal-686d4e759478eebb接续；普通刀舞生成模型修复不等于该措辞已修。',
    '- silent-0332 nonpositive-hp的完整资源/steps和机制根因、原core-build-notify发送事实、调度永久饥饿与上游目录生命周期仍缺充分证据；不猜游戏规则，不重复已上线的窄防护。',
    '- sandbox-glob-startup-race的父注册保存屏障798af209、会话前恢复bc2c40e31、复盘租约绑定d9983263已在base/live祖先；不据此断言所有历史null租约与目录删除者已查明。',
    '- 失败准备记录：只读rg曾使用两个不存在路径，随后用文件清单定位实际路径；未撤修复、未重跑测试、未产生产品变更。',
    '- 测试详情与完整日志：verification.json、tsc.log、tsc.exit、vitest.log、vitest.exit。audit.py和source.diff保存本批可复查输入与零源码差异。',
    '',
    '```json',
    json.dumps(result, ensure_ascii=False, indent=2),
    '```',
]
(SCRATCH / 'report.md').write_text('\n'.join(out) + '\n')
print(json.dumps({'report': result['report'], 'existing_active_items': len(active_fixed), 'skipped': len(skipped), 'tests': result['tests']}, ensure_ascii=False))

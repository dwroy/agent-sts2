import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261016-021301'
SCRATCH = ROOT / 'learner/runs/20261016-021305-766207d6-5101-44f3-aab1-d54eeb714401-fix-batch'
PRIOR = WORK / 'paper/materials/20261016-0119-ops/batch-readback.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, head):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', commit, head], cwd=WORK).returncode == 0


prior = json.loads(PRIOR.read_text())
old = prior['original_audit']
base = git('rev-parse', 'HEAD').decode().strip()
live = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / '.worktrees/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
lines = queue.splitlines(keepends=True)
assert sha(b''.join(lines[:old['queue_lines']])) == old['queue_sha256']
paths = sorted({f['path'] for fix in old['existing_fixes'] for f in fix['files']})
assert not any(Path(p).name == '.env' or p.endswith('.env') for p in paths)
changed = git('diff', '--name-only', old['base'], base, '--', *paths).decode().splitlines()
assert not changed, changed
assert not git('diff', '--name-only', 'HEAD', '--', *paths).strip()
files = {}
for path in paths:
    current = (WORK / path).read_bytes()
    committed = git('show', f'{base}:{path}')
    assert current == committed, path
    result = subprocess.run(['git', 'show', f'{live}:{path}'], cwd=WORK, capture_output=True)
    files[path] = {
        'path': path,
        'sha256': sha(current),
        'same_as_committed_base': True,
        'present_in_live': result.returncode == 0,
        'same_as_live': result.returncode == 0 and current == result.stdout,
        'live_sha256': sha(result.stdout) if result.returncode == 0 else None,
    }
fixes = []
for fix in old['existing_fixes']:
    commit = fix['source_commit']
    in_base, in_live = ancestor(commit, base), ancestor(commit, live)
    assert in_base and in_live, (fix['item'], commit, in_base, in_live)
    for previous in fix['files']:
        assert files[previous['path']]['sha256'] == previous['sha256'], previous['path']
    fixes.append({
        'item': fix['item'], 'source_commit': commit,
        'ancestor_in_base': in_base, 'ancestor_in_live': in_live,
        'files': [files[p['path']] for p in fix['files']],
    })
dispositions = []
for item in prior['original_queue_dispositions']:
    assert lines[item['line'] - 1].decode().rstrip('\r\n') == item['item'], item['line']
    item = dict(item)
    item['verification'] = '本批核对原队列字节、当前源码与提交内容及来源提交的base/live祖先；仅确认既有窄范围。'
    dispositions.append(item)
new_line = next(i for i, line in enumerate(lines, 1) if i > old['queue_lines'] and line.startswith(b'- [ ]'))
assert 'silent-0487' in lines[new_line - 1].decode()
dispositions.append({
    'line': new_line,
    'item': lines[new_line - 1].decode().rstrip('\r\n'),
    'disposition': '策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。',
    'verification': '本批读取card-model.ts当前命中次数仅CalculatedHits/Repeat/两次文字，未读取ViolenceHits；普通fix批不实现游戏模型。',
})
assert len(dispositions) == sum(line.startswith(b'- [ ]') for line in lines)
out = {
    'base': base, 'live_read_only_snapshot': live,
    'prior_readback': str(PRIOR), 'prior_readback_sha256': sha(PRIOR.read_bytes()),
    'prior_base': old['base'], 'queue_sha256': sha(queue), 'queue_lines': len(lines),
    'prior_queue_prefix_unchanged': True,
    'new_queue_lines': [line.decode().rstrip('\r\n') for line in lines[old['queue_lines']:]],
    'unchecked_entries': len(dispositions), 'existing_fixes': fixes,
    'unique_source_paths': len(paths), 'changed_source_paths_since_prior_base': changed,
    'queue_dispositions': dispositions,
    'limits': [
        '无新增源码，不空提交、不空合入，不补造发布号或shipped。',
        '保留既有live知识刷新及源码差异；祖先不等于当前live逐叶等同，差异逐项另列。',
        '历史目录删除者、原通知发送事实、调度永久饥饿及nonpositive-hp根因仍未知。',
        '模型命中次数与技能药水措辞等游戏知识均留原独立策略提案，不关闭宽父或自然消费。',
    ],
}
(SCRATCH / 'audit.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
(SCRATCH / 'queue-snapshot.md').write_bytes(queue)
(SCRATCH / 'source.diff').write_bytes(git('diff', '--binary', old['base'], base, '--', *paths))
print(json.dumps({
    'base': base, 'live_snapshot': live, 'existing_fixes': len(fixes),
    'source_paths': len(paths), 'unchanged_sources': not changed,
    'queue_entries': len(dispositions), 'new_entries': 1,
    'live_absent_paths': [p for p, v in files.items() if not v['present_in_live']],
    'live_different_paths': sum(v['present_in_live'] and not v['same_as_live'] for v in files.values()),
}, ensure_ascii=False))

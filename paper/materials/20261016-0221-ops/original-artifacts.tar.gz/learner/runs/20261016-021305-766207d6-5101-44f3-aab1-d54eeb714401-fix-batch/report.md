## 修 bug 回报
- 合并基线：main → d523c467cb0e00cfbf181f4490ba6a4d0fbf1ba1（开工工作区干净，git merge --no-edit main 返回 Already up to date）
- 修复（每条一行）：无新增纯 bug 修复；fixes=[]，未创建提交。
- 已被别人修掉的：当前42条未勾选项中16条已有修复或限定子项覆盖，逐条提交见下表；另核74个既有修复/子项的来源和当前源码。
- 没修的：26条策略/架构/证据不足条目逐条列于下表；已有自动策略链保持，不新建重复提案或派下级。
- 测试：tsc退出码0；vitest定向9文件/69用例/退出码0；无重跑。没有源码变更或提交，未运行完整test-sandbox.sh，不声称全量套件通过。
- 合入：未合入（merged=null）；无新增源码，未空合并、未改live刷新数据。
- 需要 Roy 定的事（没有写「无」）：无。

本批产物只写指定scratch；另按需展开一个已提交历史材料，未改其内容。未改修复队列、学习账本、代码提案队列、版本或上线记录。无实际上线，不登记shipped。技能药水生命周期文字与MAD_SCIENCE三段攻击均保留原独立策略提案；没有将游戏模型问题转成普通基础设施实现。

逐条未勾选项核查（有提交仅指已实现的限定范围，不关闭宽父）：

| 队列行 | 条目 | 处置/源码提交 |
|---|---|---|
| 784 | silent-0254：无出牌决策的死亡战斗漏记，death_fight误用上一胜战 | 已修/限定子项；3b48088dec5fc6eafe576a1296bbdadde43432ee |
| 789 | silent-0256：狡诈药水确定生成未建模，容量及出刀顺序未参与方案比较 | 已修/限定子项；6403fdcdadc803a092beb5165a068e22bf51c412 |
| 793 | silent-0260：普通紧勒后续逐牌失血漏模 | 已修/限定子项；5c7105ff0294466da8319f2934beda05c6040794 |
| 797 | silent-0263：已有虚弱的意图转向后少算1伤 | 已修/限定子项；ec29ea34b919344b707e57ba472ea210f9c39d62 |
| 801 | silent-0266：SL已尝试键排序整轮牌，丢失投斧首牌身份 | 已修/限定子项；e784dd9f043bf87c29109573f48975f9903280d3 |
| 810 | silent-0271：毒必胜提前返回遗漏连战保血候选 | 策略类/沿原独立提案，宽父保持 |
| 817 | silent-0272：商店移除预览误报现场可选卡 | 已修/限定子项；db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26 |
| 831 | silent-0279：SL抽序升级改标误判插牌 | 策略类/沿原独立提案，宽父保持 |
| 900 | rollout最佳线路补入题面的固定夹具确定性 | 已修/限定子项；bbc5b993a7524bbb8e80a975f204f8d193657b46 |
| 912 | silent-0308 | 策略类/沿原独立提案，宽父保持 |
| 918 | silent-0311 | 策略类/沿原独立提案，宽父保持 |
| 923 | silent-0317 | 策略类/沿原独立提案，宽父保持 |
| 929 | silent-0319 | 策略类/沿原独立提案，宽父保持 |
| 930 | silent-0320 | 策略类/沿原独立提案，宽父保持 |
| 935 | silent-0322 | 策略类/沿原独立提案，宽父保持 |
| 940 | silent-0324 | 已修/限定子项；66c22ba7d87b8748690a4183fff838acd346bd3e |
| 945 | silent-0329 | 策略类/沿原独立提案，宽父保持 |
| 952 | arch-funnel-guard | 策略类/沿原独立提案，宽父保持 |
| 953 | arch-learning-priority | 策略类/沿原独立提案，宽父保持 |
| 954 | arch-unified-resource-value | 策略类/沿原独立提案，宽父保持 |
| 955 | inv-f33-regression | 策略类/沿原独立提案，宽父保持 |
| 959 | silent-0332 | 证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知 |
| 964 | silent-0334：升级隐秘匕首模型 | 策略类/沿原独立提案，宽父保持 |
| 968 | silent-0338 | 已修/限定子项；c1d84804956bedbd29a7f0e81294114e18415b9d |
| 980 | silent-0339 | 策略类/沿原独立提案，宽父保持 |
| 992 | silent-0344，坚韧之环延迟格挡未接入推演 | 策略类/沿原独立提案，宽父保持 |
| 1001 | silent-0347 | 策略类/沿原独立提案，宽父保持 |
| 1005 | silent-0349 | 策略类/沿原独立提案，宽父保持 |
| 1009 | core-build-notify-222802-rc2 | 证据不足：后续诊断已修，原历史发送事实未知 |
| 1020 | silent-0362 | 策略类/沿原独立提案，宽父保持 |
| 1022 | silent-0365 | 策略类/沿原独立提案，宽父保持 |
| 1024 | silent-0367 | 已修/限定子项；5baf663d7e6678efa3690e5a48329c4f8baee109 |
| 1029 | codex-usage-credit-baseline-recovery | 已修/限定子项；5b56a452bb9be14d620b368ec46974c1b57901ca |
| 1034 | ascension-up：请求目标进阶误报为实际进阶 | 已修/限定子项；8045d9fbf0a12523b1dbe39bbed8af06c7497b09 |
| 1040 | 框架/测试收尾：外层时限与分段续验 | 太大/独立框架：精确续验入口已实现，宿主收尾范围继续 |
| 1041 | 调度公平性核查 | 证据不足：未证明永久饥饿，沿原框架核查 |
| 1110 | host-fixed-test-timeouts-010547：eval/Apotheosis固定夹具 | 已修/限定子项；d9881ba593b0b8d701ebbe1c95626c0ebdd554c7、9e8c93555131c3347f9e809d9722a848a75c2692 |
| 1294 | silent-0481 | 策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项 |
| 1304 | infra-target-options-fixed-fixture-timeout | 已修/限定子项；bae9c45ccffefb284a1c6634526c8768a9f5f7a8 |
| 1308 | infra-ledger-status-prefix-git-divergence | 已修/限定子项；dd478f0b3e5a0f234f082972d21b203dbf8229d7 |
| 1322 | infra-learner-launch-shared-main-config-race | 已修/限定子项；22efae55484bc2bdcc54e847a8dc40bb4888c4e2 |
| 1344 | silent-0487：非阻塞三段攻击模型缺口，仅转录学习者证据 | 策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。 |

既有修复追溯：74个来源提交均为本基线及只读live快照 cfa1c0be88147b4eac65c13d8c550b23ed4eef17 的祖先；381个唯一源码路径逐字节与上一已核基线和HEAD一致。live存在136个历史叶差与4个缺少路径，未覆盖、未修饰为等同，逐项见audit.json。队列前1342行的SHA与上一核验一致，仅新增第1344行silent-0487；当前队列1344行、42个未勾选项全部有处置。

| 既有修复/子项 | 源码提交 |
|---|---|
| silent-0254：无动作死亡战斗归因 | 3b48088dec5fc6eafe576a1296bbdadde43432ee |
| codex-usage-credit-baseline-recovery：额度窗口恢复基线 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| ascension-up：请求进阶误报为实际进阶 | 8045d9fbf0a12523b1dbe39bbed8af06c7497b09 |
| infra-target-options-fixed-fixture-timeout | bae9c45ccffefb284a1c6634526c8768a9f5f7a8 |
| infra-ledger-status-prefix-git-divergence | dd478f0b3e5a0f234f082972d21b203dbf8229d7 |
| infra-legacy-continuation-notice-ack-identity | 368fccabd42eb72ffcea9a2fe6cbbb7c149326be |
| infra-paper-krane-recorded-line-timeout | befc39e5ca0105f8ff96d47f817df44f0b2760f1 |
| infra-learner-event-log-second-collision | b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f |
| strategy-proposal：报告 scratch 归属 | 5f04139cefe5c651dd5bf62f7e164014dbf5f23b |
| silent-0459：独立 run-plan 请求成本漏计 | 799a5cd0caf9329b43c32376079218a9bd0c3e9e |
| run-plan 证据提取未识别 run 字段 | 78e9b05929366d097a728761d693d790ff16ac87 |
| postmortem-capacity-failure-proposal-repair-20261013 | 3fdcd77927f01b35c20c6c5c1fcfd790676032d2 |
| blocked-experience-proposal-repair-dispatch | 84366ad06ee4f978394c1b9489a82c83ea12bd36 |
| learning-notice-ordinary-ack-registry-20261013：普通 ACK | 672e198a4730012330f599068a0ef1efadb02002 |
| learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 | 1594def2e1b65b665d3b345f31444194eb4d09e6 |
| learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 | 15eb85e2934e428c5e299fc4a1aba456d92fd685 |
| feature 通知来源身份校验 | 38b2f572d90b3b97a23f9eae983f583287492f9a |
| feature/B4 通知来源桥接 | 1dd4d434aef67f1d065dbdba23a875ae82741a88 |
| batch-f：包装/参数化测试超时静态解析 | 56c256dad0d33b231b82b53113d3bdd84f9bfa20 |
| unassigned-strategy-proposal-resolution | 3a98e213a826e94f9708af4b1a265e1892659f4e |
| host-fixed-test-timeouts-010547：eval 固定历史输入 | d9881ba593b0b8d701ebbe1c95626c0ebdd554c7 |
| host-fixed-test-timeouts-010547：Apotheosis 有界夹具 | 9e8c93555131c3347f9e809d9722a848a75c2692 |
| compute-memo-worker-data-signature | 8fbb441eb61eef226eb7366f9612003480c83988 |
| rollout-live-best-test-determinism | bbc5b993a7524bbb8e80a975f204f8d193657b46 |
| host-targeted-check-continuation：已过覆盖的精确续验入口 | 24c2e3a75b5db6bac76d6c924f86b7fcd9438316 |
| sandbox-glob-startup-race：会话前有界恢复 | bc2c40e313cc36682196277c53c50e30744b88c5 |
| sandbox-glob-startup-race：复盘租约绑定 | d9983263ffecea1bed4e29d65e7f854a3d2e33d7 |
| core-cycle-implementation-binding-entry | fc95760d4ff8a9cbd45577efdd79b1215bd2cb92 |
| ops-20261012-quantitative-continuation | b408252f87a77ee5389c4d90e52a9831c0873348 |
| named-card-facts-transport：已批准的事件入口子项 | 42c920f34d9dc1c783ce894659849ab37ed6fd1b |
| core-build-notify-222802-rc2：保留原生失败诊断子项 | 5c92f2aaf0b758a1a5e7d591745694004664f83a |
| paper-dataset-git-consistency-race | 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f |
| boss-sim-codex-home-preflight | 5921f8cd045853182c867a6430e75c3fcde00a87 |
| shared-experience-fixed-filesystem-snapshot-20261013 | 8390c62d76fc8c7d7b6b7292121a621f4666d39c |
| silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） | ec8c578b66bf5498372f1b779ae58a766dff8112 |
| ops-stall-recovery-test-subprocess-timeout：首项异步夹具 | 95e7f050ef2abe5c85a0367555392652ad73fbfe |
| ops-stall-recovery-test-subprocess-timeout：固定失败诊断 | 9b6459fd99f26b17689134e33aa85d6190e71d7d |
| batch-c-fixed-fixture-timeout | 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff |
| 晚写复盘误计为上线后重犯 | 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39 |
| 学习账本 first_run/asc/prior_note 追加更正 | 87c89b7aea90c7275e0fbb04b1e4148a4209630c |
| subscription-usage：未设置 TMPDIR | 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a |
| deepseek-prompt-dump：状态日志反向流式扫描 | 6ee8e2a2c1edc31492962137b96af8c6e1d12093 |
| 固定药水测试隔离 | e78352f784d39cf25671446348daaada6ef2060b |
| 单次 mod 超时 stall 误报 | a4f4ec868d122dc92af510862c6240cf2eaff2b6 |
| 学习状态锁被完整检查阻塞 | 233ede56047274ba53a4e1191a245fac816c37a8 |
| 学习者受阻后兜底完整检查入口 | f670884a188a047bbd3f7f007c260ade62fae36a |
| 策略任务及自动派发入口 | afd652a3f75df6e7403439f01c565220327884da |
| 旧事件选项重复问大脑 | 25ce09bee5576b1adff8baf196fbe8b197a5ef11 |
| silent-0153：普通隐秘匕首生成分支 | b7f081fcc26da4506cb775739bb118cb6cbe4ecc |
| silent-0256：已观察的狡诈药水容量子项（实际源码提交） | 6403fdcdadc803a092beb5165a068e22bf51c412 |
| silent-0260：普通紧勒逐牌失血 | 5c7105ff0294466da8319f2934beda05c6040794 |
| silent-0263：已观察的碾碎爪转向取整子项 | ec29ea34b919344b707e57ba472ea210f9c39d62 |
| silent-0266：SL 首牌身份 | e784dd9f043bf87c29109573f48975f9903280d3 |
| silent-0272：商店移除预览与真实选牌页核对 | db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26 |
| silent-0324：普通刀舞生成小刀 | 66c22ba7d87b8748690a4183fff838acd346bd3e |
| silent-0338：回合末防御事实来源注记 | c1d84804956bedbd29a7f0e81294114e18415b9d |
| silent-0367：已用蜥蜴尾巴事实接线 | 5baf663d7e6678efa3690e5a48329c4f8baee109 |
| infra-learner-launch-shared-main-config-race | 22efae55484bc2bdcc54e847a8dc40bb4888c4e2 |
| host-loop-time-cap-wall-clock-061301：固定时间夹具 | b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa |
| host-loop-time-cap-wall-clock-061301：续验拒绝诊断 | 63f656fb07a21a7496353234269901a832eae497 |
| ops-worktree-history-disk-pressure：broker容量/回执失败隔离 | a136ddc4b5b0a8696f10b2fae3073322d57e724c |
| ops-worktree-history-disk-pressure：无终态标记退出 | db072ddab47ba94efb46dce2913927f936ecb97e |
| ops-worktree-history-disk-pressure：JSONL追加边界 | 9b07240b18f862efdbe630889ade04e8976eaace |
| ops-worktree-history-disk-pressure：历史副本/按需恢复 | c7a6efb1e15ed6c5f31a35ae3ee9833863340393 |
| tracked-source Python缓存回收认定 | 1e8af775f6b90f100f20ff7c4a08dfddaba893a9 |
| 完成报告裸JSON兼容 | 6f86ff6b6b971fb38b96308ebdd34dec574e5b13 |
| autoplay安全热交接动作 | 71b835a3150704548fab2ad46e74bde240ccf1f9 |
| 历史测试入口漏传日志回调 | ccd8bb8e017da9c30b408138d04e6d2bc985836d |
| 额度警告固定测试契约 | 1cf0490492bd8a430b85f95f3fdee91eba251191 |
| 有限结束报告与补验交接 | 2c4ce406c9ae598835f22292e52cfd936ac10b14 |
| host-checks-broker-push-registration | c519952b31e3a0bb3acdd2115883ae8671b8a090 |
| host-checks-session-exit-fixture | 874ae603b3927173f805e0b2fe789330bab710c7 |
| v5-dpr-health：明确不支持的候选被误计为DPR交付失败（仅分类子项） | 9e6dd82a34fb8c14e012be68fd0b632544f1459f |
| sandbox-glob-startup-race：父注册事务保存屏障 | 798af209b9a268b7dafab1440150f1b39cd5595d |

证据与限制：

- 本批通过上一已归档核验记录的精确路径按需恢复，并独立核对队列前缀SHA、来源祖先、源码SHA和当前工作区；原记录仍保留，未当作本批测试结果。来源、恢复提交/blob与逐叶数据见audit.json。
- silent-0487当前card-model.ts读取CalculatedHits/Repeat并识别两次文字，未读取ViolenceHits；该项基于JWK2C8LE4SFV/A10/F48首试T5、末试T8，按原silent-proposal-0a0b31e284e6793e交独立策略链。本批未重做对局语义研究，原证据局号/回合来自队列，不冒称已独立核完整原日志。
- silent-0481题面仍写only for this turn，按原silent-proposal-686d4e759478eebb接续；普通刀舞生成模型修复不等于该措辞已修。
- silent-0332 nonpositive-hp的完整资源/steps和机制根因、原core-build-notify发送事实、调度永久饥饿与上游目录生命周期仍缺充分证据；不猜游戏规则，不重复已上线的窄防护。
- sandbox-glob-startup-race的父注册保存屏障798af209、会话前恢复bc2c40e31、复盘租约绑定d9983263已在base/live祖先；不据此断言所有历史null租约与目录删除者已查明。
- 失败准备记录：只读rg曾使用两个不存在路径，随后用文件清单定位实际路径；未撤修复、未重跑测试、未产生产品变更。
- 测试详情与完整日志：verification.json、tsc.log、tsc.exit、vitest.log、vitest.exit。audit.py和source.diff保存本批可复查输入与零源码差异。

```json
{
  "task": "fix-batch",
  "base": "d523c467cb0e00cfbf181f4490ba6a4d0fbf1ba1",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0271：毒必胜提前返回遗漏连战保血候选",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0279：SL抽序升级改标误判插牌",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0308",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0311",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0317",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0319",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0320",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0322",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0329",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-funnel-guard",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-learning-priority",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-unified-resource-value",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "inv-f33-regression",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0332",
      "reason": "证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知"
    },
    {
      "item": "silent-0334：升级隐秘匕首模型",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0339",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0344，坚韧之环延迟格挡未接入推演",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0347",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0349",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "core-build-notify-222802-rc2",
      "reason": "证据不足：后续诊断已修，原历史发送事实未知"
    },
    {
      "item": "silent-0362",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0365",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "框架/测试收尾：外层时限与分段续验",
      "reason": "太大/独立框架：精确续验入口已实现，宿主收尾范围继续"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：未证明永久饥饿，沿原框架核查"
    },
    {
      "item": "silent-0481",
      "reason": "策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项"
    },
    {
      "item": "silent-0487：非阻塞三段攻击模型缺口，仅转录学习者证据",
      "reason": "策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 69
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-021305-766207d6-5101-44f3-aab1-d54eeb714401-fix-batch/report.md"
}
```

from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0221';pub=root/'paper/materials/20261016-0221-ops';pub.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],input=data,stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-021301-fix-batch';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='skipped'}=={k:v for k,v in report.items() if k!='skipped'}
assert len(scratch['skipped'])==len(report['skipped'])==26 and all(a['item'].startswith(z['item']) for a,z in zip(scratch['skipped'],report['skipped']))
assert b['state']=='failed' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors']
assert report['fixes']==report['code_proposals']==report['implementation_domains']==[] and report['merged'] is None and report['tests']==dict(tsc=0,vitest=0,cases=69)
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
assert (s/'source.diff').read_bytes()==b''
verification=load(s/'verification.json');assert verification['tsc']==verification['vitest']==0 and verification['files']==9 and verification['cases']==69 and verification['retried'] is False and verification['full_sandbox_suite_run'] is False
assert (s/'tsc.exit').read_text().strip()==(s/'vitest.exit').read_text().strip()==(s/'gitleaks.exit').read_text().strip()=='0'
assert 'Test Files  9 passed (9)' in (s/'vitest.log').read_text() and 'Tests  69 passed (69)' in (s/'vitest.log').read_text()
audit=load(s/'audit.json');prior_path=Path(audit['prior_readback']).relative_to(Path(b['worktree']));prior_raw=git('show',report['base']+':'+str(prior_path));assert sha(prior_raw)==audit['prior_readback_sha256'];prior= json.loads(prior_raw);previous=prior['original_audit']
assert audit['base']==report['base'] and audit['prior_queue_prefix_unchanged'] and audit['changed_source_paths_since_prior_base']==[]
queue=(s/'queue-snapshot.md').read_bytes();lines=queue.splitlines(keepends=True);assert sha(queue)==audit['queue_sha256'] and len(lines)==audit['queue_lines']==1344
assert sha(b''.join(lines[:previous['queue_lines']]))==previous['queue_sha256'] and previous['queue_lines']==1342
assert audit['new_queue_lines']==[x.decode().rstrip('\r\n') for x in lines[previous['queue_lines']:]] and len(audit['new_queue_lines'])==2 and audit['new_queue_lines'][0]==''
assert 'silent-0487' in audit['new_queue_lines'][1] and 'silent-proposal-0a0b31e284e6793e' in audit['new_queue_lines'][1]
assert (root/'notes/fix-queue-v4.md').read_bytes().startswith(queue)
dispositions=audit['queue_dispositions'];assert audit['unchecked_entries']==len(dispositions)==42 and sum(x.startswith(b'- [ ]') for x in lines)==42
for x in dispositions:assert lines[x['line']-1].decode().rstrip('\r\n')==x['item']
assert len(audit['existing_fixes'])==74
leaves={}
for fix in audit['existing_fixes']:
    assert fix['ancestor_in_base'] and fix['ancestor_in_live'];git('merge-base','--is-ancestor',fix['source_commit'],report['base']);git('merge-base','--is-ancestor',fix['source_commit'],audit['live_read_only_snapshot'])
    for row in fix['files']:
        if row['path'] in leaves:assert row==leaves[row['path']]
        leaves[row['path']]=row
assert len(leaves)==audit['unique_source_paths']==381
assert all(not x.endswith(('.env','.dll','.pck')) and 'auth.json' not in x and not x.startswith('third_party/') for x in leaves)
assert not git('diff','--name-only',audit['prior_base'],report['base'],'--',*sorted(leaves)).strip()
requests=[(commit,path) for path in sorted(leaves) for commit in [report['base'],audit['live_read_only_snapshot']]]
raw=git('cat-file','--batch',data=''.join(commit+':'+path+'\n' for commit,path in requests).encode());handle=io.BytesIO(raw);blobs={}
for key in requests:
    header=handle.readline().rstrip(b'\n').split()
    if header[-1:]==[b'missing']:blobs[key]=None;continue
    assert header[1]==b'blob';size=int(header[2]);value=handle.read(size);assert len(value)==size and handle.read(1)==b'\n';blobs[key]=value
assert handle.read()==b''
absent=[];different=[]
for path,row in leaves.items():
    a=blobs[(report['base'],path)];z=blobs[(audit['live_read_only_snapshot'],path)];assert a is not None and sha(a)==row['sha256'] and row['same_as_committed_base']
    assert (z is not None)==row['present_in_live'] and (a==z)==row['same_as_live'] and (sha(z) if z is not None else None)==row['live_sha256']
    if z is None:absent.append(path)
    elif a!=z:different.append(path)
assert len(absent)==4 and len(different)==136
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
write(pub/'batch-readback.json',dict(batch=bid,original_state=b['state'],original_rc=b['rc'],original_report=report,original_scratch_report=scratch,stdout_skips_abbreviated=True,native=native,unchanged_clean_worktree=True,no_new_fix_or_merge_block=True,original_audit=audit,prior_readback=dict(original_path=audit['prior_readback'],committed_ref=report['base']+':'+str(prior_path),sha256=sha(prior_raw),note='Historical expanded file no longer exists at the old worktree path; exact committed bytes independently read without restoring or editing old evidence.'),source381_base_shas_and_live_equalities_verified=True,live_absent_paths=absent,live_different_paths=different,original_queue_dispositions=dispositions,original_verification=verification,no_production_tests_reexecuted=True,limits=['Original failed/rc0/mergednull is preserved; no new source, commit or merge is claimed.','Existing scoped source ancestry does not imply equality with all current live leaves or wide-parent completion.','silent-0487 remains on its original strategy chain; no new game-model implementation or duplicate dispatch.','Resources/steps truncation, notification history, directory lifecycle, other leases and fairness remain unresolved.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([x for x in s.iterdir() if x.is_file()]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in sorted(p.glob('*.py')):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0221原021301-fix空修复回报核，原failed/rc0/mergednull保持，d523干净WT/HEAD不变，无新增源码或提交合入受阻，不空合/发号/再派。42未勾队列逐项处置核，旧1342行SHA保持，仅新增0487与原0a0b31e2策略链，不复派/改游戏模型或关闭宽父。74既有窄修复来源base/live祖先、381当前base叶SHA及相对旧基线无变核，live缺叶4/差叶136原样分列，不把祖先当逐叶全等。原tsc0、9文件69定向0/nice19单worker/未重跑/未full及原件SHA保，不冒完整套件绿。历史0119展开文件现旧路径缺失，仅从d523提交按精确path/blob独立读回原SHA，不修改/恢复旧材料；首次路径探针失败不当产品bug。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核，原0332完整resources/steps/机制根因、目录生命周期/租约与通知发送事实仍未知沿原owner。仅本人记录提交，无代码/知识/账本/队列状态/论文刷新/补测/对局重启或账号home模型额度权限prompt操作。证据paper/materials/20261016-0221-ops/。\n'
note=f'\n- {at} [运维 codex] 原021301修复批次无新增源码或待兜底合入，原failed/rc0保留；tsc和9文件69项定向通过，未跑完整套件。既有窄修复与42项队列边界已核，0487沿原策略链，不重复合入/发号/补测。回执paper/materials/20261016-0221-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,original_state=b['state'],rc=0,existing_sources=74,base_source_leaves=381,queue_entries=42,original_tsc=0,original_targeted_files=9,original_targeted_cases=69,original_targeted_exit=0,no_new_fix_commit_merge_release=True,no_tests_reexecuted=True,record_only=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(paths=len(entries),sources=74,leaves=381,no_new_source=True)))

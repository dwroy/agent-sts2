import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FLOORS = {
    "VLZ6CCT8AQ0A": {35, 36, 37, 43, 45},
    "8JRE1C4H4Z2W": {17, 33},
    "CA5KE8GFJ9X2": {13},
    "5PM6JAQG6FNQ": {33, 39},
    "61E2QS63Y9WU": {17, 23},
    "DUZUBAJ3A8GP": {30},
}


def powers(raw):
    return {p["power_id"]: p["amount"] for p in raw or []}


def reference(item):
    return {k: item[k] for k in ("source", "line", "offset", "bytes", "sha256", "run_id")}


def compact(item):
    state = item["row"]["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        **reference(item),
        "observed_ts": item["row"].get("observed_ts"),
        "floor": run.get("floor"), "turn": state.get("turn"),
        "in_combat": state.get("in_combat"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "energy": player.get("energy"), "block": player.get("block"),
        "powers": powers(player.get("powers")),
        "hand": [{k: c.get(k) for k in ("index", "card_id", "upgraded", "energy_cost", "resolved_rules_text", "dynamic_values")}
                 for c in combat.get("hand", [])],
        "enemies": [{k: e.get(k) for k in ("index", "enemy_id", "current_hp", "max_hp", "block", "move_id", "intents")}
                    | {"powers": powers(e.get("powers"))} for e in combat.get("enemies", [])],
    }


def main():
    counts = collections.Counter()
    turns = {}
    firsts = {}
    selected = []
    segments = {}
    prior_turn = {}
    for raw in (HERE / "evidence/states.evidence.jsonl").open():
        item = json.loads(raw)
        state = item["row"]["state"]
        run = state.get("run") or {}
        assert run.get("character_id", "").lower() == "silent"
        assert run.get("ascension") == 10
        ident = item["run_id"]
        assert ident in FLOORS
        counts[ident] += 1
        if run.get("floor") not in FLOORS[ident]:
            continue
        frame = compact(item)
        fight = (ident, frame["floor"])
        turn = frame["turn"]
        segments.setdefault(fight, 1)
        if frame["in_combat"] and isinstance(turn, int):
            if turn < prior_turn.get(fight, turn):
                segments[fight] += 1
            prior_turn[fight] = turn
        # This is an observation segment, not an inferred official SL attempt.
        frame["observation_segment"] = segments[fight]
        selected.append(frame)
        key = (ident, frame["floor"], segments[fight], frame["turn"])
        firsts.setdefault(key, frame)
        turns[key] = frame
    (HERE / "critical-frames.segmented.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in selected))
    summary = {"counts": dict(counts), "selected_frames": len(selected), "turns": [
        {"run_id": k[0], "floor": k[1], "observation_segment": k[2], "turn": k[3], "first": firsts[k], "last": turns[k]}
        for k in turns
    ]}
    (HERE / "states-analysis.segmented.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "turns"}, ensure_ascii=False))


if __name__ == "__main__":
    main()

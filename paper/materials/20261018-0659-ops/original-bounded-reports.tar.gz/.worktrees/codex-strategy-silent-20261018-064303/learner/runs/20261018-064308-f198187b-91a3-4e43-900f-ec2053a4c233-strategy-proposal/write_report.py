import datetime
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WORKTREE = HERE.parents[2]
BASE = 'd7e908c260678770d2878362b2ae295e2d0839f3'

DETAILS = [
    ('89354805ee4d7e77', '神化升级与实际施放',
     'VLZ6CCT8AQ0A，F35 T1、F43 T1–T2、F45 T1；states275564/275565、275679/275680/275687、275722–275732；decisions269706/269707、269748/269754/269755。',
     'F35施放后能量7→5；F43同序候选43伤/14损变51伤/13损，敌254→203、玩家90→77可核。F45持有但未施放，不能算升级兑现。',
     '已有观察配对表、同线升级及后继牌堆传播；silent-apotheosis-reference.ts仍将actual_cast_this_fight保留为null，模拟应用与实打分列。',
     '已有神化局部升级传播；缺跨抽牌、重规划、SL与换战的实际施放归属及完整消费者校准，不能登记整项完成。',
     '冻结本角色实际普通/升级卡、未知边界与实际动作链；验证同线、已知后抽、换战、重问和SL均不把持有或模拟施放当实际施放，未知卡保持未知；新增源码须撤修失败/恢复通过。',
     'F35/36/37/43施放后获胜，F43仍损57；F45未施放而败。这些敌人、牌序与资源不同，不能推固定必打或整战因果。'),
    ('f2bfceddb1898dca', '三骑士预算与药水成熟度',
     'VLZ6CCT8AQ0A，F43–F45；decisions269748、269754、269770；states275717–275755。',
     '269748题面明确707ms花于随机药水MC且退化为无rollout；269754有12个药水样本，但两问fingerprint不同。T4已选线13损/24伤，三条未选攻击线31损/32伤，各8样本全败。',
     '现源码已提供预算、样本、当前候选及药水中位样本等信息；这些诊断与原候选数据不是同盘预算实验结果。',
     '缺同起点、同随机池、同总预算的配对实验和候选稳定性曲线；原两问题面指纹不同，不能据707ms设新预算或留药规则。',
     '先冻结当前进阶数据库、完整输入、随机池/种子及总预算，比较预算方案和样本成熟度；明确退化、best不可比与真正全败并列的区别；药水实抽后另核实际牌与资源。',
     '第二问局部采样改善不证明预算调整有收益；F43胜战损57，F44补34至67/104仍在F45失败，不能只看末战资源。'),
    ('283a164780d11e69', '神化经验消费补链',
     'VLZ6CCT8AQ0A，F35 T1、F43 T1–T2、F45 T1；与89354805ee4d7e77共享上述原帧。',
     '原经验silent-apotheosis-combat-upgrades与silent-0237/0238有真实CLI链接；本次没有增加独立支持局。',
     '源码存在神化窄实现和分列字段；原postmortem与experience-update两条请求的消费证明仍未完整。',
     '与原神化提案共享证据，但实际施放和后继消费未闭环；同主题及局部代码相同不足以登记duplicate。',
     '沿原两个id共享固定证据与实现，不另建同题id；逐一核真实live祖先源码和实际消费者，对全部职责完成后才给implemented/duplicate。',
     '知识条目存在或已被发布不证明本次提案所要求的所有执行路径已实现。当前经验中的其他同角色支持局没有在本批独立重放，不扩本批样本。'),
    ('ebbfe3b97548756d', '十五项攻防、持续资源与消费校准',
     'VLZ6CCT8AQ0A，F43 T2–T5、F45 T3–T5及F44休息；states275687–275720、275738–275755。',
     'F43毒12/16在两层触媒下实际扣33/45；F45三敏使后空翻8、防御含勒紧12；尖啸使四段来袭83→59，32血20挡完整需损39、少7血，全部敌仍未退出。',
     '逐牌/逐击、现场能力与临时减力等已有多个子路径。十五子项关联的14个账本保留原归属：护喉甲0016、金刚杵0049等不得互换。',
     '缺十五子项按来源、持续期限、属性组合及战斗、路线、休息消费者联合冻结的生产校准；已有窄公式不能关闭整项。',
     '逐子项固定来源、实际持续期限、当前进阶输入和消费者，验证属性、升级、普通/升级触媒、现场覆甲及临减恢复；房间代价保留5样本门槛，不拟合统一血线。',
     '机制成立而整战失败不是机制反例；不同属性/敌人/火堆选择并非同起点实验。不可把十五项的支持分母合为同一种联合实验。'),
    ('e5b87be50f28f311', 'SL、HP护栏与实际执行审计',
     '8JRE1C4H4Z2W，F33第1/3试T2、第2试T5、第6试T11；decisions270216/270282/270264；states276208→276212、276274→276278、276429–276434；sl-attempts921–926。',
     '270216与270282指纹逐字相同。原线T2实际损3/扣10，第三试替换线损15/扣17，差12血/7伤；第三试题面死亡0/24和5/24不能合写同死率。末试5血截断死亡不等于完整需损15。',
     'silent-selection-audit保存原答/SL前后预测，HP护栏审计单列；silent-selection-dispatch只认证单次派发，state_effect_verified=false、whole_plan_executed=null。loop已有拒派、SL重载、动作返回/错误接线。',
     '已有候选与单次派发审计；缺跨抽牌、选择、重问、用药及SL的连续执行认证和能力实际建立归属，不能用单动作回执关闭整线审计。',
     '固定首/三试同盘、护栏T5、F17重规划及末试T11，连通原答、护栏、SL、指纹、实际派发和后继观测；在抽牌/重问/SL边界终止旧线认证，保留未知/截断及实体重排。',
     '末试延长至T11仍败，防御改线不全是错；六试同属一局。前五试末尾预测判死未完整执行，不能补造其终局伤害或反事实胜利。'),
    ('49632bc4878fb597', '属性、虚弱与独立成长',
     'CA5KE8GFJ9X2，F13 T1–T5；states273237–273269，尤其273252/273263及后续虚弱帧；silent-0231原证。',
     '下水道蚌力量0→4→8，同招11→15→19；虚弱后11/14仍继续成长。末轮2血10挡对14完整需损4，不是实际扣4。',
     '当前模型有逐击力量、牌挡敏捷和移动模型，但本局未建立正敏捷；不能凭单一步法或荆棘修复证明所有组合。',
     '缺力量逐击、正负敏捷、虚弱与独立成长的联合生产校准；本局没有正敏捷实建证据，不能据此增加统一保血或输出权重。',
     '冻结实际调用、当前进阶数据库和同轮前后状态，分项核数值及期限；正敏捷只能由已核本角色额外证据支撑，不用本局计划中的步法代替取得。',
     '虚弱有效不等于消除下次成长；死亡前2血截断和荆棘后敌16血不得当作所有模型误差。'),
    ('66532328a585941f', '持有、启动与实际成长',
     '5PM6JAQG6FNQ，F39末试T2，states274379–274383；反照同局F33，sl-attempts909–911。',
     '末试毒雾未建立，面对零毒失落打冒泡耗1能量而无毒收益；同局F33建立雾3/触媒1/群蛇4后获胜，场景和生存资源同时变化。',
     '原经验已有持有/到手/实付/建立/后继分账文字及部分场景字段；它们不构成任意构筑启动的已验证收益函数。',
     '缺同起始HP、构筑、资源及完整抽序下不同启动顺序的受控整战结果与可复现收益函数，不能从F33/F39异场输赢拟合启动权重。',
     '保留所有合法选择，只列本帧已建能力和已施毒目标；任何启动权重先按同起点、同抽序、同策略比较整场后继，按run而非尝试分样本。',
     'F33与F39不具备单变量条件；末试无毒只支持当步缺兑现，不证明所有冒泡/启动线都无价值。'),
    ('43a76a31ba7bdcfa', '吸取、负敏捷与毒的SL边界',
     '61E2QS63Y9WU，F17 T5–T7；states273502–273513；sl-attempts898。',
     '吸取后玩家力2→0、敏0→−2，敌力0→2；T6双防各3，敌67→34的毒17+16继续结算；该场attempt1、won、7轮。',
     '当前存在负属性与毒路径；本场没有另一条实际SL线路。',
     '该战只有首试获胜，缺同起始HP、构筑和完整抽序下另一完整SL线路，不能据首试胜利改变SL范围或换线偏好。',
     '固定吸取前后属性、双防、毒分项；若改SL必须另有同盘完整后继，保留原阈值直到完成可重现比较。',
     '负敏捷压牌挡不否定毒；获胜局仍需分资源和最后退出，不能由胜利倒推任意SL都安全。'),
    ('5264153a4a4b0e5c', '召唤、航行与退场窗口',
     '61E2QS63Y9WU，F23 T1–T5，尤其T4；states273577–273605，decisions对应F23 T4题。',
     '召唤后幻象21，航行后两实体各3→6力；T4本体线47伤/15损，幻象14→2仍攻击15，本体经毒76→41；另一focus39伤/零损候选未实打。',
     'monster-db.summonsAt和rollout已有活体召唤路径及固定测试源码；当前进阶的HP来自数据库，不由本报告补常量。',
     '已有召唤子实现；缺A10召唤、航行、幻象复现与退场的全链生产校准，以及另一focus的完整后继，不能据未选候选强制首杀。',
     '同一当前进阶数据库输入下逐步核召唤、实体成长、复现和主体退出；所有focus保留，推演值相同标并列，未实打线不算实际省血。',
     '当轮毛伤47不等于幻象退出；不能把旧召唤测试当本次A10全部成长/目标排序的通过证明。'),
    ('bddfa690a84e03d0', '睡眠、唤醒与持续成长',
     'DUZUBAJ3A8GP，F30 T1–T6，末试states274991–275023；sl-attempts914–917。',
     '睡3/2/1后T4醒，T5力量2、T6恢复并成长至4；四试依次predicted_death三次、died一次，均无胜利。',
     '现有求解/整战路径包含睡眠与移动状态，尚不能仅据本局观察确认不同损血唤醒、眩晕和成长的完整组合。',
     '缺伤害唤醒、睡眠/眩晕接续及当前进阶成长的完整生产校准和同抽换序后继；四试失败不足拟合固定杀序或输出血价。',
     '逐试冻结当前进阶敌人脚本、力量恢复、睡层与攻击；先核全链再比较同抽换序整场，不以不同试次同轮编号拼接状态。',
     '首三次在判死处截断，不能把predicted_death写实际完整结算；末试只有1血入T6，不能和首试3血混算。'),
]


def main():
    timestamp = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip() == BASE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORKTREE, text=True).strip()
    batch = json.loads((HERE / 'dispatch.json').read_text())
    originals = json.loads((HERE / 'original-proposals.json').read_text())
    assert ['silent-proposal-' + d[0] for d in DETAILS] == batch['proposal_ids']
    results = [{'id': 'silent-proposal-' + d[0], 'state': 'waiting', 'reason': d[5]} for d in DETAILS]
    (HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
    proposal = [
        '# 静默猎手本批十项提案核验与待补证方案',
        f'记录时间：{timestamp}。batch：20261018-064303-strategy-proposal。角色：silent；本批六局均A10。',
        f'基线：{BASE}。普通队列批次，reason=proposal；没有research_request、implementation_request或proposal_repair。第1.2节根专题绑定的是旧批次，不承接该专题。已执行git merge --no-edit main，结果Already up to date。',
        '结论：本批十项均waiting。没有新增源码、知识规则或提案id；已存在的窄实现保留，但不冒整项implemented/duplicate。本批不是新的独立验证局，不增加支持/反例计数。',
        '原十份Markdown逐字保存为silent-proposal-<id>.original.md，SHA与专用队列原add一致；original-proposals.json保存原任务/经验/账本链接，assigned-proposals.json保存本批领取时的现状态。',
        '## 证据与核验范围',
        '按共用extract_evidence.py冻结八流，各流source_size、计数、输出SHA在evidence/evidence-manifest.json；6995条记录全部逐offset/bytes/SHA/JSON/显式归局读回，见material-verification.json。run-plans按run归属，其余流核run_id/state.run_id/fingerprint.run，冲突身份不接收。fight-plans在2233957字节截点选中0行，只代表该截点没有本批记录，不表示原日志不存在。',
        '原始states/decisions/brain全流各记录2条无效JSON；不是本批归局缺失证明。角色来自runs.jsonl及各状态character_id交叉核对，不借正文提及归局。完整抽取约136MiB，未复制整个仓库。',
        '## 逐项提案',
    ]
    for suffix, title, evidence, facts, source, reason, validation, counter in DETAILS:
        ident = 'silent-proposal-' + suffix
        item = originals[ident]
        proposal.extend([
            f'### {ident}：{title}',
            '原任务：' + item['source_task'] + ' → strategy-proposal；账本：' + '、'.join(item['ledger']) + '。',
            '原Markdown：' + item['proposal'] + '；SHA256：' + item['proposal_sha256'] + '。',
            '证据局/层/回合及原行：' + evidence,
            '本次从原帧核实：' + facts,
            '旧规则及当前源码：' + source,
            '预期行为与验证方法：' + validation,
            '反例、限制与因果边界：' + counter,
            '处置：waiting。' + reason,
        ])
    proposal.extend([
        '## 拟合、切分与回退',
        '本批不拟合新权重、阈值、固定目标顺序或最优牌数。六个来源局已被历史复盘和提案使用，所有帧属于发现/回归材料；SL试次不作独立局或盲测。不同运行标有dirty，不能只凭Git提交重建开局的全部输入。未来比较必须冻结实际执行源码与当前进阶数据、完整资源、抽序和消费者，并保持无关角色与未观察范围等价。',
        '没有生产行为变更，当前无需代码回退。后续若经足够证据实现，用其实际源码提交回退，保留本批证据、原提案、失败回执和账本；实际上线后才通知Roy并由ops核号、登记shipped。不得把这份waiting报告当经验已入库、live已消费或父要求已完成。',
    ])
    (HERE / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    sources = json.loads((HERE / 'source-manifest.json').read_text())
    report = [
        '# 20261018-064303 静默策略提案批次回报',
        f'记录时间：{timestamp}。base：{BASE}；本批没有源码或知识修改，fixes=[]、merged=null。十个已领取id均waiting，不冒造源码提交、合入、发布号或成功测试。',
        f'完整提案：{HERE / "proposal.md"}。逐项处置机器文件：proposal-results.json；最终字段：result.json。',
        '## 派发与角色核验',
        '根learn.json仅本批记录已保存dispatch.json。task=strategy-proposal、character=silent、worktree匹配，reason=proposal且有10个proposal_ids。未承接任何research/implementation专题；没有读取其他专题替代身份。初始工作树干净，merge main结果Already up to date；HEAD保持本报告base。未派下级agent、联网、运行play或更改运维prompt。',
        '## 逐项结果',
        '| 提案id | 账本 | 本批结论 |\n|---|---|---|',
    ]
    report.append('\n'.join('| ' + x['id'] + ' | ' + '、'.join(originals[x['id']]['ledger']) + ' | waiting：' + x['reason'] + ' |' for x in results))
    report.extend([
        '## 原始证据',
        '| 局号 | states | decisions | SL记录 | run-plans | brain |\n|---|---:|---:|---:|---:|---:|',
        '\n'.join('| ' + run + ' | ' + ' | '.join(str(next(m for m in manifest if m['stream'] == s)['counts'][run]) for s in ['states', 'decisions', 'sl-attempts', 'run-plans', 'brain']) + ' |' for run in batch['runs']),
        '每局另有run-config和runs各1行；fight-plans在本截点各0行；合计6995。六局runs行575–580均SILENT/A10，均已结束；代码分别ac321b1f、b0f41f03、33f02a6f、f56da22b、03d50f0b、93298980并带dirty，不将当前固定源码冒作当时完整运行树。',
        '共用入口一次完整抽取，extract.log保留原输出；未覆盖旧报告或零行初稿，也未把0行当日志缺失。verify_materials.py逐行读回6995条并核10份原提案SHA成功，material-verification.json为材料核验结果，不是生产测试结果。',
        '## 主要核回及反证',
        'VLZ F43同序43/14→51/13的模型差与实际兑现可核；F45的持有不等施放。F45 T4未选攻击候选与已选线不是完整反事实；T5 83来袭经四段尖啸变59，20挡/32血需损39。预算两问指纹不同，不据局部样本改707ms预算。',
        '8JRE F33原/第三试T2指纹相同，states276208→276212实际损3/扣10，276274→276278损15/扣17，paired-observations.json保存差；第三试题内0/24和5/24死亡仍区分。末试T11从5血被截断至0，实际5血与完整需损15分列，未补记前五试未执行的末轮结果。',
        'CA5 F13力量0/4/8及虚弱后的11/14并未取消独立成长；本局无正敏捷实建。5PM F39末试零毒冒泡与同局F33已建组件胜战不是同起点比较。61E F17只有首试获胜，F23另一focus未实打；DUZ F30四试仍无胜线，前三试predicted_death与末试died分列。',
        '## 源码与实际live谱系',
        f'固定只读live提交：{sources[0]["live_commit"]}。source-manifest.json保存16条base Git blob、原字节SHA、最后源码提交及其live祖先核验；16条最后源码提交均为该live祖先。11个文件字节相同，5个不同的patch另存，不能由局部相同宣称整树等价；本批未修改live。',
        '\n'.join('- `' + x['path'] + '`：`' + x['last_source_commit'] + '`；固定live字节' + ('相同' if x['same_live_bytes'] else '不同，差异已保留') + '。' for x in sources),
        '已有神化传播表ba23ca693151fa8c6f7fe035e640dc30f05ccd75、事实分列30ec2425012eea75f41226b31d8180b1abb837bc、候选审计9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed与护栏审计66283dd9982bdd7f480da7a4d9bfefea0572a9ac只是已核局部源码祖先，不作为十项整项duplicate/implemented的commit。',
        '## 验证、账本与交付边界',
        '没有生产源码修改，不运行撤源码红/恢复绿、tsc或vitest，三项固定为null；没有新提交、live合入、eval版本或shipped。原历史测试结果不借用为本批成功。本次只追加已有关联账本的报告链接/处置说明，不新增经验或代码提案、不改claim/first_run/prior/evidence/status/version/effect，不把旧局重复登记为新支持。具体CLI输入/回执保存在ledger-updates.jsonl、ledger-update.stdout.txt、ledger-update.stderr.txt；完成复核补充见completion-check.json。',
        '无代码回退项；原行为保持。后续数据足够时沿原id重派，不另建重复id、不关闭量化父请求。实际上线才由ops核live、分配release_id并登记shipped。',
        '## 过程限制与更正',
        '首次派发定位脚本错误地把包含batch key的容器作为命中，导致过宽输出；后续改为batches[本批]精确读取，未使用其他批次作为证据或改写其状态。首次自制账本摘要错误覆盖了累积字段，保留ledger-context.initial-naive-fold.json，最终改用根ledger.py的fold得到ledger-context.json；没有据初稿写账本。',
        '首次状态摘要仅以局/层/轮聚合，可能混入不同SL试次，states-analysis.json与critical-frames.jsonl初稿保留；最终states-analysis.segmented.json、critical-frames.segmented.jsonl按回合回退切分观测段，并用SL原记录、决策指纹和原行核对重点试次。观测段不是自动认证的SL身份。决策摘录首次假定每条均有questions，遇代码续步KeyError后保留错误转录并改为可选字段读取；最终critical-decisions.json和sl-summary.json完整保存。',
        '未发现与既有知识相矛盾的新游戏结论。本批只有六个旧锚点、单局各帧相关，没有新的独立时间后置验证；新增局部持牌观察不等同完整升级或后继消费者校准。',
    ])
    (HERE / 'report.md').write_text('\n\n'.join(report) + '\n')
    payload = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch.get('batch', '20261018-064303-strategy-proposal'),
               'base': BASE, 'runs': batch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
               'tests': {'tsc': None, 'vitest': None, 'cases': None},
               'code_proposals': batch['proposal_ids'], 'implementation_domains': [],
               'proposal_results': results, 'report': str(HERE / 'report.md')}
    (HERE / 'result.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    by_ledger = {}
    for r in results:
        for ident in originals[r['id']]['ledger']:
            by_ledger.setdefault(ident, []).append(r)
    updates = [{'id': ident, 'by': 'learner:strategy-proposal', 'where': {'proposal': [str(HERE / 'proposal.md')]},
                'note': '20261018-064303-strategy-proposal原六局复核；' + '；'.join(x['id'] + '=waiting：' + x['reason'] for x in rows) + '。本批无源码/知识修改和新独立局；不改变原状态、不记shipped。详见' + str(HERE / 'report.md')}
               for ident, rows in sorted(by_ledger.items())]
    (HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
    (HERE / 'analysis-errors.md').write_text('# 过程错误人工转录\n\n首次decisions摘录读取269755代码续步时：\n\n```text\nTraceback (most recent call last):\n  File "<stdin>", line 8, in <module>\nKeyError: \'questions\'\n```\n\n该命令退出1，尚未写critical-decisions.json或sl-summary.json；已改可选字段重读全部9条，成功产物保留。它是材料分析错误，不是生产测试失败。两处不存在的猜测路径combat-execution-audit.ts、hand/silent-selection-execution.ts的sed查询失败后，已改读rg实际找到的reflex/silent-selection-dispatch.ts；没有创建生产文件。\n')
    print(json.dumps({'report': str(HERE / 'report.md'), 'proposal': str(HERE / 'proposal.md'),
                      'waiting': len(results), 'ledger_updates_prepared': len(updates)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

# 静默猎手本批十项提案核验与待补证方案

记录时间：2026-10-18T06:57:32+08:00。batch：20261018-064303-strategy-proposal。角色：silent；本批六局均A10。

基线：d7e908c260678770d2878362b2ae295e2d0839f3。普通队列批次，reason=proposal；没有research_request、implementation_request或proposal_repair。第1.2节根专题绑定的是旧批次，不承接该专题。已执行git merge --no-edit main，结果Already up to date。

结论：本批十项均waiting。没有新增源码、知识规则或提案id；已存在的窄实现保留，但不冒整项implemented/duplicate。本批不是新的独立验证局，不增加支持/反例计数。

原十份Markdown逐字保存为silent-proposal-<id>.original.md，SHA与专用队列原add一致；original-proposals.json保存原任务/经验/账本链接，assigned-proposals.json保存本批领取时的现状态。

## 证据与核验范围

按共用extract_evidence.py冻结八流，各流source_size、计数、输出SHA在evidence/evidence-manifest.json；6995条记录全部逐offset/bytes/SHA/JSON/显式归局读回，见material-verification.json。run-plans按run归属，其余流核run_id/state.run_id/fingerprint.run，冲突身份不接收。fight-plans在2233957字节截点选中0行，只代表该截点没有本批记录，不表示原日志不存在。

原始states/decisions/brain全流各记录2条无效JSON；不是本批归局缺失证明。角色来自runs.jsonl及各状态character_id交叉核对，不借正文提及归局。完整抽取约136MiB，未复制整个仓库。

## 逐项提案

### silent-proposal-89354805ee4d7e77：神化升级与实际施放

原任务：postmortem → strategy-proposal；账本：silent-0237、silent-0238。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256：ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。

证据局/层/回合及原行：VLZ6CCT8AQ0A，F35 T1、F43 T1–T2、F45 T1；states275564/275565、275679/275680/275687、275722–275732；decisions269706/269707、269748/269754/269755。

本次从原帧核实：F35施放后能量7→5；F43同序候选43伤/14损变51伤/13损，敌254→203、玩家90→77可核。F45持有但未施放，不能算升级兑现。

旧规则及当前源码：已有观察配对表、同线升级及后继牌堆传播；silent-apotheosis-reference.ts仍将actual_cast_this_fight保留为null，模拟应用与实打分列。

预期行为与验证方法：冻结本角色实际普通/升级卡、未知边界与实际动作链；验证同线、已知后抽、换战、重问和SL均不把持有或模拟施放当实际施放，未知卡保持未知；新增源码须撤修失败/恢复通过。

反例、限制与因果边界：F35/36/37/43施放后获胜，F43仍损57；F45未施放而败。这些敌人、牌序与资源不同，不能推固定必打或整战因果。

处置：waiting。已有神化局部升级传播；缺跨抽牌、重规划、SL与换战的实际施放归属及完整消费者校准，不能登记整项完成。

### silent-proposal-f2bfceddb1898dca：三骑士预算与药水成熟度

原任务：postmortem → strategy-proposal；账本：silent-0106、silent-0019、silent-0201。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256：fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。

证据局/层/回合及原行：VLZ6CCT8AQ0A，F43–F45；decisions269748、269754、269770；states275717–275755。

本次从原帧核实：269748题面明确707ms花于随机药水MC且退化为无rollout；269754有12个药水样本，但两问fingerprint不同。T4已选线13损/24伤，三条未选攻击线31损/32伤，各8样本全败。

旧规则及当前源码：现源码已提供预算、样本、当前候选及药水中位样本等信息；这些诊断与原候选数据不是同盘预算实验结果。

预期行为与验证方法：先冻结当前进阶数据库、完整输入、随机池/种子及总预算，比较预算方案和样本成熟度；明确退化、best不可比与真正全败并列的区别；药水实抽后另核实际牌与资源。

反例、限制与因果边界：第二问局部采样改善不证明预算调整有收益；F43胜战损57，F44补34至67/104仍在F45失败，不能只看末战资源。

处置：waiting。缺同起点、同随机池、同总预算的配对实验和候选稳定性曲线；原两问题面指纹不同，不能据707ms设新预算或留药规则。

### silent-proposal-283a164780d11e69：神化经验消费补链

原任务：experience-update → strategy-proposal；账本：silent-0237、silent-0238。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256：78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。

证据局/层/回合及原行：VLZ6CCT8AQ0A，F35 T1、F43 T1–T2、F45 T1；与89354805ee4d7e77共享上述原帧。

本次从原帧核实：原经验silent-apotheosis-combat-upgrades与silent-0237/0238有真实CLI链接；本次没有增加独立支持局。

旧规则及当前源码：源码存在神化窄实现和分列字段；原postmortem与experience-update两条请求的消费证明仍未完整。

预期行为与验证方法：沿原两个id共享固定证据与实现，不另建同题id；逐一核真实live祖先源码和实际消费者，对全部职责完成后才给implemented/duplicate。

反例、限制与因果边界：知识条目存在或已被发布不证明本次提案所要求的所有执行路径已实现。当前经验中的其他同角色支持局没有在本批独立重放，不扩本批样本。

处置：waiting。与原神化提案共享证据，但实际施放和后继消费未闭环；同主题及局部代码相同不足以登记duplicate。

### silent-proposal-ebbfe3b97548756d：十五项攻防、持续资源与消费校准

原任务：experience-update → strategy-proposal；账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256：08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。

证据局/层/回合及原行：VLZ6CCT8AQ0A，F43 T2–T5、F45 T3–T5及F44休息；states275687–275720、275738–275755。

本次从原帧核实：F43毒12/16在两层触媒下实际扣33/45；F45三敏使后空翻8、防御含勒紧12；尖啸使四段来袭83→59，32血20挡完整需损39、少7血，全部敌仍未退出。

旧规则及当前源码：逐牌/逐击、现场能力与临时减力等已有多个子路径。十五子项关联的14个账本保留原归属：护喉甲0016、金刚杵0049等不得互换。

预期行为与验证方法：逐子项固定来源、实际持续期限、当前进阶输入和消费者，验证属性、升级、普通/升级触媒、现场覆甲及临减恢复；房间代价保留5样本门槛，不拟合统一血线。

反例、限制与因果边界：机制成立而整战失败不是机制反例；不同属性/敌人/火堆选择并非同起点实验。不可把十五项的支持分母合为同一种联合实验。

处置：waiting。缺十五子项按来源、持续期限、属性组合及战斗、路线、休息消费者联合冻结的生产校准；已有窄公式不能关闭整项。

### silent-proposal-e5b87be50f28f311：SL、HP护栏与实际执行审计

原任务：postmortem → strategy-proposal；账本：silent-0079、silent-0021、silent-0125、silent-0018。

原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256：5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。

证据局/层/回合及原行：8JRE1C4H4Z2W，F33第1/3试T2、第2试T5、第6试T11；decisions270216/270282/270264；states276208→276212、276274→276278、276429–276434；sl-attempts921–926。

本次从原帧核实：270216与270282指纹逐字相同。原线T2实际损3/扣10，第三试替换线损15/扣17，差12血/7伤；第三试题面死亡0/24和5/24不能合写同死率。末试5血截断死亡不等于完整需损15。

旧规则及当前源码：silent-selection-audit保存原答/SL前后预测，HP护栏审计单列；silent-selection-dispatch只认证单次派发，state_effect_verified=false、whole_plan_executed=null。loop已有拒派、SL重载、动作返回/错误接线。

预期行为与验证方法：固定首/三试同盘、护栏T5、F17重规划及末试T11，连通原答、护栏、SL、指纹、实际派发和后继观测；在抽牌/重问/SL边界终止旧线认证，保留未知/截断及实体重排。

反例、限制与因果边界：末试延长至T11仍败，防御改线不全是错；六试同属一局。前五试末尾预测判死未完整执行，不能补造其终局伤害或反事实胜利。

处置：waiting。已有候选与单次派发审计；缺跨抽牌、选择、重问、用药及SL的连续执行认证和能力实际建立归属，不能用单动作回执关闭整线审计。

### silent-proposal-49632bc4878fb597：属性、虚弱与独立成长

原任务：experience-update → strategy-proposal；账本：silent-0005、silent-0231。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256：aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。

证据局/层/回合及原行：CA5KE8GFJ9X2，F13 T1–T5；states273237–273269，尤其273252/273263及后续虚弱帧；silent-0231原证。

本次从原帧核实：下水道蚌力量0→4→8，同招11→15→19；虚弱后11/14仍继续成长。末轮2血10挡对14完整需损4，不是实际扣4。

旧规则及当前源码：当前模型有逐击力量、牌挡敏捷和移动模型，但本局未建立正敏捷；不能凭单一步法或荆棘修复证明所有组合。

预期行为与验证方法：冻结实际调用、当前进阶数据库和同轮前后状态，分项核数值及期限；正敏捷只能由已核本角色额外证据支撑，不用本局计划中的步法代替取得。

反例、限制与因果边界：虚弱有效不等于消除下次成长；死亡前2血截断和荆棘后敌16血不得当作所有模型误差。

处置：waiting。缺力量逐击、正负敏捷、虚弱与独立成长的联合生产校准；本局没有正敏捷实建证据，不能据此增加统一保血或输出权重。

### silent-proposal-66532328a585941f：持有、启动与实际成长

原任务：experience-update → strategy-proposal；账本：silent-0021、silent-0009。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256：56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。

证据局/层/回合及原行：5PM6JAQG6FNQ，F39末试T2，states274379–274383；反照同局F33，sl-attempts909–911。

本次从原帧核实：末试毒雾未建立，面对零毒失落打冒泡耗1能量而无毒收益；同局F33建立雾3/触媒1/群蛇4后获胜，场景和生存资源同时变化。

旧规则及当前源码：原经验已有持有/到手/实付/建立/后继分账文字及部分场景字段；它们不构成任意构筑启动的已验证收益函数。

预期行为与验证方法：保留所有合法选择，只列本帧已建能力和已施毒目标；任何启动权重先按同起点、同抽序、同策略比较整场后继，按run而非尝试分样本。

反例、限制与因果边界：F33与F39不具备单变量条件；末试无毒只支持当步缺兑现，不证明所有冒泡/启动线都无价值。

处置：waiting。缺同起始HP、构筑、资源及完整抽序下不同启动顺序的受控整战结果与可复现收益函数，不能从F33/F39异场输赢拟合启动权重。

### silent-proposal-43a76a31ba7bdcfa：吸取、负敏捷与毒的SL边界

原任务：experience-update → strategy-proposal；账本：silent-0030、silent-0027。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256：f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。

证据局/层/回合及原行：61E2QS63Y9WU，F17 T5–T7；states273502–273513；sl-attempts898。

本次从原帧核实：吸取后玩家力2→0、敏0→−2，敌力0→2；T6双防各3，敌67→34的毒17+16继续结算；该场attempt1、won、7轮。

旧规则及当前源码：当前存在负属性与毒路径；本场没有另一条实际SL线路。

预期行为与验证方法：固定吸取前后属性、双防、毒分项；若改SL必须另有同盘完整后继，保留原阈值直到完成可重现比较。

反例、限制与因果边界：负敏捷压牌挡不否定毒；获胜局仍需分资源和最后退出，不能由胜利倒推任意SL都安全。

处置：waiting。该战只有首试获胜，缺同起始HP、构筑和完整抽序下另一完整SL线路，不能据首试胜利改变SL范围或换线偏好。

### silent-proposal-5264153a4a4b0e5c：召唤、航行与退场窗口

原任务：experience-update → strategy-proposal；账本：silent-0039、silent-0209。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256：b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。

证据局/层/回合及原行：61E2QS63Y9WU，F23 T1–T5，尤其T4；states273577–273605，decisions对应F23 T4题。

本次从原帧核实：召唤后幻象21，航行后两实体各3→6力；T4本体线47伤/15损，幻象14→2仍攻击15，本体经毒76→41；另一focus39伤/零损候选未实打。

旧规则及当前源码：monster-db.summonsAt和rollout已有活体召唤路径及固定测试源码；当前进阶的HP来自数据库，不由本报告补常量。

预期行为与验证方法：同一当前进阶数据库输入下逐步核召唤、实体成长、复现和主体退出；所有focus保留，推演值相同标并列，未实打线不算实际省血。

反例、限制与因果边界：当轮毛伤47不等于幻象退出；不能把旧召唤测试当本次A10全部成长/目标排序的通过证明。

处置：waiting。已有召唤子实现；缺A10召唤、航行、幻象复现与退场的全链生产校准，以及另一focus的完整后继，不能据未选候选强制首杀。

### silent-proposal-bddfa690a84e03d0：睡眠、唤醒与持续成长

原任务：experience-update → strategy-proposal；账本：silent-0128、silent-0079。

原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256：b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。

证据局/层/回合及原行：DUZUBAJ3A8GP，F30 T1–T6，末试states274991–275023；sl-attempts914–917。

本次从原帧核实：睡3/2/1后T4醒，T5力量2、T6恢复并成长至4；四试依次predicted_death三次、died一次，均无胜利。

旧规则及当前源码：现有求解/整战路径包含睡眠与移动状态，尚不能仅据本局观察确认不同损血唤醒、眩晕和成长的完整组合。

预期行为与验证方法：逐试冻结当前进阶敌人脚本、力量恢复、睡层与攻击；先核全链再比较同抽换序整场，不以不同试次同轮编号拼接状态。

反例、限制与因果边界：首三次在判死处截断，不能把predicted_death写实际完整结算；末试只有1血入T6，不能和首试3血混算。

处置：waiting。缺伤害唤醒、睡眠/眩晕接续及当前进阶成长的完整生产校准和同抽换序后继；四试失败不足拟合固定杀序或输出血价。

## 拟合、切分与回退

本批不拟合新权重、阈值、固定目标顺序或最优牌数。六个来源局已被历史复盘和提案使用，所有帧属于发现/回归材料；SL试次不作独立局或盲测。不同运行标有dirty，不能只凭Git提交重建开局的全部输入。未来比较必须冻结实际执行源码与当前进阶数据、完整资源、抽序和消费者，并保持无关角色与未观察范围等价。

没有生产行为变更，当前无需代码回退。后续若经足够证据实现，用其实际源码提交回退，保留本批证据、原提案、失败回执和账本；实际上线后才通知Roy并由ops核号、登记shipped。不得把这份waiting报告当经验已入库、live已消费或父要求已完成。

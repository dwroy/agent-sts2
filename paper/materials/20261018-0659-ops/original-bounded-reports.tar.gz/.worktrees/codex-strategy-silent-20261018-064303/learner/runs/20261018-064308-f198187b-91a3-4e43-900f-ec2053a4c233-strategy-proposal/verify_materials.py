import collections
import hashlib
import json
import runpy
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
identity = runpy.run_path(str(WORKTREE / "learner/extract_evidence.py"))["run_identity"]


def main():
    manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
    results = []
    for stream in manifest:
        name = stream["stream"]
        target = HERE / "evidence" / (name + ".evidence.jsonl")
        source = Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")
        counts = collections.Counter()
        digest = hashlib.sha256()
        with source.open("rb") as handle, target.open("rb") as saved:
            for encoded in saved:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item["source"] == str(source)
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                handle.seek(item["offset"])
                raw = handle.read(item["bytes"])
                assert raw.endswith(b"\n")
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                assert identity(item["row"]) == item["run_id"]
                counts[item["run_id"]] += 1
        assert digest.hexdigest() == stream["output_sha256"]
        assert all(counts[k] == v for k, v in stream["counts"].items())
        assert set(counts) <= set(stream["counts"])
        results.append({"stream": name, "verified_records": sum(counts.values()),
                        "source_size": stream["source_size"], "counts": dict(counts),
                        "output_sha256": digest.hexdigest()})
    originals = json.loads((HERE / "original-proposals.json").read_text())
    for ident, row in originals.items():
        assert row["character"] == "silent"
        assert hashlib.sha256((HERE / (ident + ".original.md")).read_bytes()).hexdigest() == row["proposal_sha256"]
    output = {"streams": results, "verified_records": sum(x["verified_records"] for x in results),
              "original_markdowns_verified": len(originals), "production_tests_run": False}
    (HERE / "material-verification.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in output.items() if k != "streams"}, ensure_ascii=False))


if __name__ == "__main__":
    main()

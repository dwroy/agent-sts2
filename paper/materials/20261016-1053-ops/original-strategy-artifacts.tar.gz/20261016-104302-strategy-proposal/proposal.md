# 本批十项静默策略提案核验与处置

记录时间：2026-10-16T10:50:51+08:00。角色silent，已核来源六局均A10；batch=20261016-104302-strategy-proposal；base=15aa330a851086c77b40492228813fd756f6904a。

本批仅消费十个已领取CLI提案。全部保留waiting，原行为保持；本次没有源码或知识修改。原提案中的窄实现已存在，尚缺的执行归属、联合校准与受控后继须继续保留。

证据抽取与逐行读回见evidence/evidence-manifest.json和evidence-verification.json；44项材料断言见fact-checks.json。八流选中证据SHA与上一批相同，相关16源码路径也相同，旧离线消费者输入/解码/输出SHA六份读回通过。本次没有重跑旧消费者或生产测试。

## silent-proposal-89354805ee4d7e77

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。来源任务=postmortem；实现任务=strategy-proposal。

账本：silent-0237、silent-0238。

证据局号/层/回合：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1。s275564→275565能量7→5，防御5→8、打击7→10、匕首雨5→7、必备工具1→0；F43同后续牌序实扣51、损13，F45未施放。

反例与限制：F43施放后仍净损57；F45不施放而败，敌人、牌序、资源不同，不能归因胜负。

原行为与预期：按已观测牌传播升级并分列持有、候选、实际施放及未知覆盖。窄传播和参考字段已有live源码。

本次处置：waiting。缺跨抽牌、药水、重规划及SL的本战实际施放持续归属；actual_cast_this_fight仍为null，未覆盖升级交互尚未校准。

后续验证：待有持续执行证据时核能量、升级、后抽牌、场外deck不变与未知保留；复合交互需固定生产输入。

## silent-proposal-f2bfceddb1898dca

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。来源任务=postmortem；实现任务=strategy-proposal。

账本：silent-0106、silent-0019、silent-0201。

证据局号/层/回合：VLZ6CCT8AQ0A F43—45，F45 T1/T4/T5。F43获胜90→33，F44补到67/104；F45 T1药水题707ms、1/12样本、best=null，第二题12/12但指纹不同；T4题面13损/24伤与31损/32伤。

反例与限制：F17/F33首试赢，F45未实打攻击候选；痊愈药水实际加能抽牌，不能按名称记回血或以707ms拟预算。

原行为与预期：成熟度、并列、未比较和药水样本分列；预算/留药规则维持现状。

本次处置：waiting。缺同起点、同随机池、同总预算的完整模型MC配对、候选稳定性曲线及留药后继；两个药水题指纹不同。

后续验证：冻结状态、知识与随机池后比较分阶段MC和原预算；分别核实际药效、抽牌重算及未选线后继。

## silent-proposal-283a164780d11e69

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0237、silent-0238。

证据局号/层/回合：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1。与89354805ee4d7e77同源，关联silent-apotheosis-combat-upgrades；四次施放属于一局。

反例与限制：与原复盘共用证据；重复经验链不增加独立支持局数，持有不能证明施放。

原行为与预期：沿原神化实现核验经验到代码链，不新增重复提案。

本次处置：waiting。同源神化经验链仍缺实际施放持续归属及升级交互校准；已有窄传播不足以认定整项duplicate。

后续验证：共用神化固定夹具和原账本，待持续归属/未知组合齐备后验收整项。

## silent-proposal-ebbfe3b97548756d

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。

证据局号/层/回合：VLZ6CCT8AQ0A F43 T1—5、F45 T3—5及本局9次火房。F43升级/敏捷/毒分源；F45末轮覆甲0、四段减力后59攻，32HP+20挡完整需损39，三敌未退场。原提案列十五经验，保持逐项账本。

反例与限制：休息8次合回242与三骑士败局共存；成长、减力和单回合数值不能替代全战或路线收益。

原行为与预期：逐源核攻防、毒、期限、开场/当前资源及战斗/路线/休息消费者；保留全部合法选择。

本次处置：waiting。缺十五经验子项的联合生产校准、状态期限和战斗/路线/休息消费者逐源归属；六局原帧不足以验收整项。

后续验证：将十五子项分别映射原帧、实际生产函数和消费者；动态知识/移动表字节未冻结处保留未知。

## silent-proposal-e5b87be50f28f311

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。来源任务=postmortem；实现任务=strategy-proposal。

账本：silent-0079、silent-0021、silent-0125、silent-0018。

证据局号/层/回合：8JRE1C4H4Z2W F33首/三试T2、第二试T5、末试T11；F17 T6。d270216/d270282指纹相同，预测死亡0/24与5/24；观测轮端点分别玩家−3/−15、敌−10/−17，确证多12血换7净扣。

反例与限制：末试T2省3血少10伤后延至T11仍死；F17抽牌后重规划，候选省血不能全记实际收益。

原行为与预期：复用原答/护栏/SL/派发及观测轮端点审计，完整候选结果继续保留未知。

本次处置：waiting。缺跨重规划持续候选身份、完整执行认证和成长逐源兑现；现有净端点不足以改变SL血价或HP护栏。

后续验证：连接候选阶段、派发、抽弃牌和重规划边界，分别核预测、净端点、未结算毒及SL恢复。

## silent-proposal-49632bc4878fb597

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0005、silent-0231。

证据局号/层/回合：CA5KE8GFJ9X2 F13 T1—5。力量0→4→8，喷水11→15→19，虚弱后11/14；末轮2HP、10挡对14攻，完整需损4而实死截顶2。

反例与限制：本战没有正敏捷，计划中的步法未取得；虚弱没有停止下一次加压。

原行为与预期：按当前进阶数据库与现场属性核每击力量、敏捷、虚弱、独立成长，不添加统一权重。

本次处置：waiting。蚌战未观察正敏捷；缺力量、正负敏捷、虚弱与独立成长的联合冻结生产校准，历史dirty输入不能仅凭提交复原。

后续验证：冻结实际调用、知识和移动表，逐步核修正及期限；怪物首样本接口与房间五样本门槛分开。

## silent-proposal-66532328a585941f

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0021、silent-0009。

证据局号/层/回合：5PM6JAQG6FNQ F39第二试T2；反例F33。d268455、s274379→274380：无毒失落35HP，冒泡能量5→4、敌帧完全相同；末试未建立毒雾。

反例与限制：同局F33已有雾3/触媒1/群蛇4并赢，但组件、敌人和存活资源同时改变。

原行为与预期：持有、计划、已建立分别记录；启动或构筑权重需整场兑现验证。

本次处置：waiting。缺同起始HP、牌组、药水及完整抽序下不同启动顺序的整战对照与收益函数；无毒冒泡局部无效不能拟合启动权重。

后续验证：先核能力建立时点、目标毒状态与真实能量，再在受控整场比较不同启动顺序。

## silent-proposal-43a76a31ba7bdcfa

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0030、silent-0027。

证据局号/层/回合：61E2QS63Y9WU F17 T5/T6。吸取后玩家0力量/−2敏捷，敌2力量；双防御各3；17+16毒对应敌67→34。

反例与限制：本局首试60血七轮赢；缺另一条完整同抽SL线路，不能把其他局失败归因固定顺序。

原行为与预期：分列吸取、负敏捷、毒与即时生存；SL范围及换线偏好保持原行为。

本次处置：waiting。缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继；首试胜利不足以修改SL范围或阈值。

后续验证：固定属性、毒、挡及实际前缀逐步重放；按run而非SL尝试分组验证。

## silent-proposal-5264153a4a4b0e5c

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0039、silent-0209。

证据局号/层/回合：61E2QS63Y9WU F23 T4/T5。T4幻象14→2仍攻击，玩家25→10；当轮两实体力量均6，T5幻象才退场。

反例与限制：focus幻象39伤零损仅是候选，未实打为完整替线；净扣血不能替实际退场。

原行为与预期：核召唤/成长/退场和复现；保留目标选项，相同推演值并列。

本次处置：waiting。缺A10召唤、成长、退场与复现的全链生产校准及另一focus完整后继；现有召唤源码不足以证明固定杀序收益。

后续验证：冻结移动表、实体身份与候选输入，分别核本体/幻象成长和召唤后继；不从单帧补随机概率。

## silent-proposal-bddfa690a84e03d0

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。来源任务=experience-update；实现任务=strategy-proposal。

账本：silent-0128、silent-0079。

证据局号/层/回合：DUZUBAJ3A8GP F30首试T5/T6及四次尝试。s274929/274932/274934力量2/−4/4、意图20/14/22；四次相关失败，前三次判死停止和末次实际死亡分列。

反例与限制：末试T4相较首试多扣3敌血、多付2玩家血；没有同抽换序的完整胜利。

原行为与预期：按进阶分别核睡眠、伤害唤醒、眩晕和后续成长，保持血价和目标选择。

本次处置：waiting。缺伤害唤醒、眩晕接续与成长全链生产校准及同抽换序后继；四次相关失败不足以拟合血价或固定杀序。

后续验证：冻结完整成长脚本和状态转换，核临减恢复与真实结算；已停止与实际死亡独立记。

## 共用验证、样本与回退

以上帧均为发现/回归样本；六局各计一个独立局，SL不扩分母。本次不拟合血价、留药、启动、目标、SL或终局参数。未来独立本角色完局作时间后置验证；缺失随机池、dirty知识/移动表和未选线后继均保留未知。历史支持与本批逐帧验证分开。

有证据支持的新实现须固定生产输入、撤源码失败/恢复通过，再跑原沙箱入口；当前无源码更改，撤换负控与tsc/vitest均不适用。无关角色行为保持。怪物HP/伤害按当前进阶数据库从首样本使用，房间代价五样本门槛保持。

回退：本次无生产改动需要回退。后续实际源码上线按自己的commit撤回，保留证据、原提案、失败记录及账本；授权Roy-2026-10-07-learning不提供游戏事实。

根账本仅经learner/ledger.py update追加本报告链接及核验说明；原claim、证据、首证、prior、状态、版本和shipped历史保留。原队列状态由调度器消费proposal_results处理，本次不新建重复ID，不改learn.json或原提案。

import hashlib
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
WT = P.parents[2]
Q = json.loads((P / 'queue-original.json').read_text())
STAMP = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True, cwd=WT).strip()
BATCH = '20261016-104302-strategy-proposal'

details = [
    ('89354805ee4d7e77', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1',
     's275564→275565能量7→5，防御5→8、打击7→10、匕首雨5→7、必备工具1→0；F43同后续牌序实扣51、损13，F45未施放。',
     'F43施放后仍净损57；F45不施放而败，敌人、牌序、资源不同，不能归因胜负。',
     '按已观测牌传播升级并分列持有、候选、实际施放及未知覆盖。窄传播和参考字段已有live源码。',
     '缺跨抽牌、药水、重规划及SL的本战实际施放持续归属；actual_cast_this_fight仍为null，未覆盖升级交互尚未校准。',
     '待有持续执行证据时核能量、升级、后抽牌、场外deck不变与未知保留；复合交互需固定生产输入。'),
    ('f2bfceddb1898dca', 'VLZ6CCT8AQ0A F43—45，F45 T1/T4/T5',
     'F43获胜90→33，F44补到67/104；F45 T1药水题707ms、1/12样本、best=null，第二题12/12但指纹不同；T4题面13损/24伤与31损/32伤。',
     'F17/F33首试赢，F45未实打攻击候选；痊愈药水实际加能抽牌，不能按名称记回血或以707ms拟预算。',
     '成熟度、并列、未比较和药水样本分列；预算/留药规则维持现状。',
     '缺同起点、同随机池、同总预算的完整模型MC配对、候选稳定性曲线及留药后继；两个药水题指纹不同。',
     '冻结状态、知识与随机池后比较分阶段MC和原预算；分别核实际药效、抽牌重算及未选线后继。'),
    ('283a164780d11e69', 'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1',
     '与89354805ee4d7e77同源，关联silent-apotheosis-combat-upgrades；四次施放属于一局。',
     '与原复盘共用证据；重复经验链不增加独立支持局数，持有不能证明施放。',
     '沿原神化实现核验经验到代码链，不新增重复提案。',
     '同源神化经验链仍缺实际施放持续归属及升级交互校准；已有窄传播不足以认定整项duplicate。',
     '共用神化固定夹具和原账本，待持续归属/未知组合齐备后验收整项。'),
    ('ebbfe3b97548756d', 'VLZ6CCT8AQ0A F43 T1—5、F45 T3—5及本局9次火房',
     'F43升级/敏捷/毒分源；F45末轮覆甲0、四段减力后59攻，32HP+20挡完整需损39，三敌未退场。原提案列十五经验，保持逐项账本。',
     '休息8次合回242与三骑士败局共存；成长、减力和单回合数值不能替代全战或路线收益。',
     '逐源核攻防、毒、期限、开场/当前资源及战斗/路线/休息消费者；保留全部合法选择。',
     '缺十五经验子项的联合生产校准、状态期限和战斗/路线/休息消费者逐源归属；六局原帧不足以验收整项。',
     '将十五子项分别映射原帧、实际生产函数和消费者；动态知识/移动表字节未冻结处保留未知。'),
    ('e5b87be50f28f311', '8JRE1C4H4Z2W F33首/三试T2、第二试T5、末试T11；F17 T6',
     'd270216/d270282指纹相同，预测死亡0/24与5/24；观测轮端点分别玩家−3/−15、敌−10/−17，确证多12血换7净扣。',
     '末试T2省3血少10伤后延至T11仍死；F17抽牌后重规划，候选省血不能全记实际收益。',
     '复用原答/护栏/SL/派发及观测轮端点审计，完整候选结果继续保留未知。',
     '缺跨重规划持续候选身份、完整执行认证和成长逐源兑现；现有净端点不足以改变SL血价或HP护栏。',
     '连接候选阶段、派发、抽弃牌和重规划边界，分别核预测、净端点、未结算毒及SL恢复。'),
    ('49632bc4878fb597', 'CA5KE8GFJ9X2 F13 T1—5',
     '力量0→4→8，喷水11→15→19，虚弱后11/14；末轮2HP、10挡对14攻，完整需损4而实死截顶2。',
     '本战没有正敏捷，计划中的步法未取得；虚弱没有停止下一次加压。',
     '按当前进阶数据库与现场属性核每击力量、敏捷、虚弱、独立成长，不添加统一权重。',
     '蚌战未观察正敏捷；缺力量、正负敏捷、虚弱与独立成长的联合冻结生产校准，历史dirty输入不能仅凭提交复原。',
     '冻结实际调用、知识和移动表，逐步核修正及期限；怪物首样本接口与房间五样本门槛分开。'),
    ('66532328a585941f', '5PM6JAQG6FNQ F39第二试T2；反例F33',
     'd268455、s274379→274380：无毒失落35HP，冒泡能量5→4、敌帧完全相同；末试未建立毒雾。',
     '同局F33已有雾3/触媒1/群蛇4并赢，但组件、敌人和存活资源同时改变。',
     '持有、计划、已建立分别记录；启动或构筑权重需整场兑现验证。',
     '缺同起始HP、牌组、药水及完整抽序下不同启动顺序的整战对照与收益函数；无毒冒泡局部无效不能拟合启动权重。',
     '先核能力建立时点、目标毒状态与真实能量，再在受控整场比较不同启动顺序。'),
    ('43a76a31ba7bdcfa', '61E2QS63Y9WU F17 T5/T6',
     '吸取后玩家0力量/−2敏捷，敌2力量；双防御各3；17+16毒对应敌67→34。',
     '本局首试60血七轮赢；缺另一条完整同抽SL线路，不能把其他局失败归因固定顺序。',
     '分列吸取、负敏捷、毒与即时生存；SL范围及换线偏好保持原行为。',
     '缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继；首试胜利不足以修改SL范围或阈值。',
     '固定属性、毒、挡及实际前缀逐步重放；按run而非SL尝试分组验证。'),
    ('5264153a4a4b0e5c', '61E2QS63Y9WU F23 T4/T5',
     'T4幻象14→2仍攻击，玩家25→10；当轮两实体力量均6，T5幻象才退场。',
     'focus幻象39伤零损仅是候选，未实打为完整替线；净扣血不能替实际退场。',
     '核召唤/成长/退场和复现；保留目标选项，相同推演值并列。',
     '缺A10召唤、成长、退场与复现的全链生产校准及另一focus完整后继；现有召唤源码不足以证明固定杀序收益。',
     '冻结移动表、实体身份与候选输入，分别核本体/幻象成长和召唤后继；不从单帧补随机概率。'),
    ('bddfa690a84e03d0', 'DUZUBAJ3A8GP F30首试T5/T6及四次尝试',
     's274929/274932/274934力量2/−4/4、意图20/14/22；四次相关失败，前三次判死停止和末次实际死亡分列。',
     '末试T4相较首试多扣3敌血、多付2玩家血；没有同抽换序的完整胜利。',
     '按进阶分别核睡眠、伤害唤醒、眩晕和后续成长，保持血价和目标选择。',
     '缺伤害唤醒、眩晕接续与成长全链生产校准及同抽换序后继；四次相关失败不足以拟合血价或固定杀序。',
     '冻结完整成长脚本和状态转换，核临减恢复与真实结算；已停止与实际死亡独立记。'),
]

assert {'silent-proposal-' + x[0] for x in details} == set(Q)
results = []
manifest = []
sections = [
    '# 本批十项静默策略提案核验与处置',
    f'记录时间：{STAMP}。角色silent，已核来源六局均A10；batch={BATCH}；base={BASE}。',
    '本批仅消费十个已领取CLI提案。全部保留waiting，原行为保持；本次没有源码或知识修改。原提案中的窄实现已存在，尚缺的执行归属、联合校准与受控后继须继续保留。',
    '证据抽取与逐行读回见evidence/evidence-manifest.json和evidence-verification.json；44项材料断言见fact-checks.json。八流选中证据SHA与上一批相同，相关16源码路径也相同，旧离线消费者输入/解码/输出SHA六份读回通过。本次没有重跑旧消费者或生产测试。',
]
for suffix, where, facts, counter, expected, reason, validation in details:
    ident = 'silent-proposal-' + suffix
    q = Q[ident]
    original = P / (ident + '.original.md')
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    assert digest == q['proposal_sha256']
    manifest.append({'id': ident, 'original': q['proposal'], 'copy': str(original), 'sha256': digest})
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.extend([
        f'## {ident}',
        f'原提案：{q["proposal"]}；SHA256={digest}。来源任务={q["source_task"]}；实现任务=strategy-proposal。',
        '账本：' + '、'.join(q['ledger']) + '。',
        f'证据局号/层/回合：{where}。{facts}',
        f'反例与限制：{counter}',
        f'原行为与预期：{expected}',
        f'本次处置：waiting。{reason}',
        f'后续验证：{validation}',
    ])
sections.extend([
    '## 共用验证、样本与回退',
    '以上帧均为发现/回归样本；六局各计一个独立局，SL不扩分母。本次不拟合血价、留药、启动、目标、SL或终局参数。未来独立本角色完局作时间后置验证；缺失随机池、dirty知识/移动表和未选线后继均保留未知。历史支持与本批逐帧验证分开。',
    '有证据支持的新实现须固定生产输入、撤源码失败/恢复通过，再跑原沙箱入口；当前无源码更改，撤换负控与tsc/vitest均不适用。无关角色行为保持。怪物HP/伤害按当前进阶数据库从首样本使用，房间代价五样本门槛保持。',
    '回退：本次无生产改动需要回退。后续实际源码上线按自己的commit撤回，保留证据、原提案、失败记录及账本；授权Roy-2026-10-07-learning不提供游戏事实。',
    '根账本仅经learner/ledger.py update追加本报告链接及核验说明；原claim、证据、首证、prior、状态、版本和shipped历史保留。原队列状态由调度器消费proposal_results处理，本次不新建重复ID，不改learn.json或原提案。',
])
(P / 'proposal.md').write_text('\n\n'.join(sections) + '\n')
(P / 'original-proposals-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': json.loads((P / 'runs.json').read_text()), 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': list(Q),
          'implementation_domains': [], 'proposal_results': results, 'report': str(P / 'report.md')}
(P / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

streams = json.loads((P / 'evidence-verification.json').read_text())
table = '\n'.join(f'| {s["stream"]} | {s["source_size"]} | {s["verified_rows"]} |' for s in streams['streams'])
outcomes = '\n'.join(f'| {r["id"]} | waiting | {r["reason"]} |' for r in results)
source = json.loads((P / 'source-verification.json').read_text())
report = f'''# 静默策略学习本批报告

记录时间：{STAMP}。task=strategy-proposal；character=silent；batch={BATCH}。

十个派发提案全部保留waiting，具体缺数据理由逐项见下表和proposal.md。六局证据支持局部机制、候选差额和真实净端点；持续执行归属、联合生产校准及受控整战后继仍有缺口。本次没有源码/知识修改、源码提交、live合入、eval版本或新shipped。

## 身份、范围和基线

开工git status干净；已读README、最新STATE-2026-10-15及其追加、decision-log末尾、learning-protocol、learning-code-proposals和AGENTS。根learn.json本批task/character/worktree/runs及十proposal_ids一致，reason=proposal，没有proposal_repair、research_request或implementation_request。普通专题请求绑定20261010旧batch，本批按普通已领取提案处理。dispatch.json保存本批对应行，没有修改调度或根请求。

普通分支执行git merge --no-edit main，结果Already up to date。完整base={BASE}，HEAD保持该值。六局runs原行均SILENT/A10、victory=false，角色与偏移/SHA见runs-verification.json。全程自行完成，没有下级agent；没有读取其他角色私有知识，不从预训练游戏知识补结论。

## 本批原始证据与核验

通过共用extract_evidence.py抽取八流，每流冻结source_size，保留显式run身份、逐行offset/bytes/SHA、原行号和计数。随后按offset读回原日志，核SHA、JSON对象、顺序和角色身份，合计{streams['total_verified']}行通过。run-plans识别run，其他流识别run_id/state.run_id/fingerprint.run，冲突身份拒收。fight-plans为本截点未选到0行，不推断历史日志缺失。全源无效JSON不认定属于本六局。

| 流 | 本次冻结source_size字节 | 已核所属行 |
|---|---:|---:|
{table}

prior-evidence-comparison.json证明八流选中封套的输出SHA与上一100139批完全相同。源文件增长没有带来本六局新增证据。没有覆盖旧报告、零行初稿或旧截点。

复用原材料断言脚本在本批新抽取/读回的数据上检查，44/44通过，fact-checks.stdout.txt退出0。原六份离线消费者的压缩输入、解码输入与输出SHA逐份核对，输出中完整候选归属仍为null；16条相关源码路径与其已检来源相同。prior-audit-readback.json保存引用和SHA，本批没有重跑这六消费者、旧模拟或生产全检；既有首次loader解析失败仍在原目录，后续成功仅作历史结果读回。

## 关键事实和可得结论

- VLZ F35神化施放使能量7→5，已观察卡升级与场外deck不变成立；F43同后续牌序51净扣、13损血成立。F45持有未施放，不能从败局倒推必打规则。当前actual_cast_this_fight仍为null。
- VLZ F45两个药水题指纹不同；707ms不是同盘预算比较。T4的13损/24伤与31损/32伤为题面候选差，没有攻击替线完整实打后继。
- 8JRE F33首/三试T2指纹相同，预测死亡0/24与5/24不同；历史观测整轮玩家−3/−15、敌−10/−17，多12血换7净扣成立。后续至胜利的反事实缺失，不能据此拟SL血价。
- CA5 F13力量0/4/8、喷水11/15/19，弱后11/14仍成长；末轮完整需损4而只有2HP，实际死亡截顶不能代完整需求。该战没有正敏捷。
- 5PM F39第二试T2无毒冒泡耗1能、敌帧不变，只支持局部无效事实；F33毒组件已建立并赢，起点条件不同。
- 61E F17吸取后0力/−2敏、双防御各3、毒17+16端点67→34；F23 T4幻象余2仍攻击，玩家25→10，T5才退场。实际退场与净伤分列。
- DUZU F30甲虫临减/恢复成长力量2/−4/4、意图20/14/22；四次相关失败中，判死停止与实际死亡分开。缺同抽换序整场胜线。

这些结论与反例沿原账本保留，不增加支持/重犯计数，不拟新权重，不把无未知标记或样本完成当完整机制/胜率校准。

## 现有源码及live边界

只读live快照={source['live_snapshot']}。source-verification.json逐条核16源码路径：均与上一批已检base路径相同；其中14条与live逐字节同，card-model.ts和rollout-live.ts的两处历史姓名注释差异保存在source-base-live.patch。没有改动历史注释或假称历史dirty树完整输入可复原。

七个既有源码commit均重核为实际live祖先，包括772b839f8ada31664cb764ea9ad3bdb03da27f64（神化传播）、3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（候选神化参考）、b2805be4ba44b7375c7908d873889372cc3cfe6c（萎靡升级）、ba23ca693151fa8c6f7fe035e640dc30f05ccd75（毒药升级），完整清单见源码回执。这些是已实现的窄子项，未覆盖整项缺口；本批没有将宽提案冒记duplicate或implemented。

## 十项处置

| 派发CLI提案ID | 结果 | 具体缺口 |
|---|---|---|
{outcomes}

proposal.md逐项给出局号/层/回合、原账本、原提案路径及SHA、反例、预期行为、验证和回退。十原Markdown均核对队列SHA且保存副本。code_proposals沿用十既有CLI ID；implementation_domains=[]表示本批无实际实现。最终proposal_results交既有调度器消费，保留waiting待新证据，不重建重复ID。

## 记录和交付

仅经根learner/ledger.py update向26个本角色相关账本追加by=learner:strategy-proposal与proposal/report追溯；保留原claim、first_run、prior、evidence、status、version、shipped、history和where前缀。无新知识提案，不将旧shipped状态退成proposed，不直接写账本或队列。CLI输入、输出及追加后保护字段核验单独保存。

无源码变更，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，没有冒报生产测试成功。merged=null；无源码提交，跳过live合入、上线decision/eval编号及规则变更双通知。原宽学习入库要求继续保留，当前报告不宣称经验已新入库或大脑采用。

本批只读定位时两次rg/sed命中不存在的旧路径，后按真实路径读取；没有影响原证据或产品文件。原工具转录保留。没有运行play、网络、LLM、npm安装或修改运维prompt，日志只读，临时材料全在本批scratch。

运维提案路径：{P / 'proposal.md'}。
报告路径：{P / 'report.md'}。
最终HEAD/干净树、账本保护、材料指纹和扫描结果见final-verification.json。
'''
(P / 'report.md').write_text(report)

updates = []
for ident in sorted({i for q in Q.values() for i in q['ledger']}):
    related = [r for r in results if ident in Q[r['id']]['ledger']]
    note = f'{BATCH}：八流6995原行逐字节核验、选中证据与上一批SHA相同、16相关源码未变；44材料断言通过，六旧消费者仅核输入/输出SHA未重跑。仅补追溯，不新增支持/重犯、源码或改变原状态。' + '；'.join(r['id'] + '=waiting：' + r['reason'] for r in related)
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(P / 'proposal.md'), str(P / 'report.md')]}, 'note': note})
(P / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'proposal_results': len(results), 'ledger_updates_prepared': len(updates), 'base': BASE}, ensure_ascii=False))

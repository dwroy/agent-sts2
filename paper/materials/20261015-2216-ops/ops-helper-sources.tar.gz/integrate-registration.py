from pathlib import Path
import fcntl
import hashlib
import json
import os
import re
import subprocess

root = Path.cwd()
private = root / 'ops/codex-ops/record-staging/20261015-2216'
public = root / 'paper/materials/20261015-2216-ops'
live = root / '.worktrees/live'
source = '798af209b9a268b7dafab1440150f1b39cd5595d'
batch_id = '20261015-214302-fix-batch'
footer = 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def git(*args, cwd=root, env=None, data=None):
    return subprocess.check_output(['git', '-C', str(cwd), *args], input=data, env=env, stderr=subprocess.PIPE)


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


batch = json.loads((root / 'ops/codex-ops/learn.json').read_text())['batches'][batch_id]
report = batch['report']
scratch = Path(report['report']).parent
assert batch['state'] == 'failed' and batch['rc'] == 0 and report['merged'] is None
assert report['fixes'][0]['commit'] == source and report['tests'] == dict(tsc=0, vitest=0, cases=4093)
assert git('rev-parse', 'HEAD', cwd=batch['worktree']).decode().strip() == source
assert not git('status', '--porcelain', '--untracked-files=no', cwd=batch['worktree']).strip()
for name, ref in json.loads((scratch / 'artifact-manifest.json').read_text()).items():
    raw = (scratch / name).read_bytes()
    assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256']
for name in ['source-sandbox', 'gitleaks', 'registration-positive']:
    assert (scratch / (name + '.exit')).read_text().strip() == '0'
assert (scratch / 'registration-negative.exit').read_text().strip() == '1'
assert json.loads((scratch / 'gitleaks.json').read_text()) == []
assert json.loads((private / 'source-gitleaks.json').read_text()) == []
full_log = (scratch / 'source-sandbox.log').read_text()
assert '434 passed (434)' in full_log and '4082 passed (4082)' in full_log and '11 passed (11)' in full_log
exec((root / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(batch_id, report, (root / 'ops/codex-ops/learner' / (batch_id + '.out')).read_text(), batch['worktree'])
paths = git('diff', '--name-only', source + '^', source).decode().splitlines()
assert paths == ['agent/tests/learner-registration-barrier.test.ts', 'ops/codex-ops-learner.sh', 'ops/tests/test_learner_registration_barrier.py']
assert not (public / 'integration.json').exists()
receipt = dict(at=subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip(),
    batch=batch_id, source=source, native=native, original_report=report,
    original_failed_rc0_and_merged_null_preserved=True,
    source_checks=dict(tsc=0, sandbox_files=434, sandbox_cases=4082, paths_files=1, paths_cases=11, combined_cases=4093, rc=0, reruns=[]),
    source_full_log_sha256=sha((scratch / 'source-sandbox.log').read_bytes()),
    source_negative_and_positive_log_sha256={name:sha((scratch/name).read_bytes()) for name in ['registration-negative.log','registration-positive.log']},
    original_conflict_receipt=json.loads((scratch / 'live-publication-result.json').read_text()),
    source_context_difference='Live launcher retains its existing task/storage and Git metadata grant differences from main. Those unrelated leaves are deliberately preserved, not declared equivalent; the final live tree needs its own original host check.',
    no_new_game_behavior_release=True, no_ledger_or_knowledge_change=True,
    old_null_leases_and_upstream_directory_lifecycle_remain_unknown=True,
    natural_future_learner_consumer='pending; no new model or experiment dispatched', checkouts={},
    host_check=dict(status='pending_original_batch_request', rc=None))

with (root / 'ops/live-merge.lock').open('a') as lock:
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        receipt['status'] = 'lock_busy_not_integrated'
        write(public / 'integration.json', receipt)
        print(json.dumps(dict(status=receipt['status'])))
        raise SystemExit(0)
    active = subprocess.run(['pgrep', '-f', '/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'], capture_output=True)
    assert active.returncode in [0, 1]
    targets = [(root, 'main')] if active.returncode == 0 else [(root, 'main'), (live, 'live')]
    receipt['active_knowledge_builder_pids'] = active.stdout.decode().split()
    receipt['live_integration_deferred_for_active_builder'] = active.returncode == 0
    preflight = {}
    for checkout, label in targets:
        assert not git('diff', '--cached', '--name-only', cwd=checkout).strip()
        assert not git('diff', '--name-only', '--', *paths, cwd=checkout).strip()
        head = git('rev-parse', 'HEAD', cwd=checkout).decode().strip()
        assert not Path(git('rev-parse', '--git-path', 'MERGE_HEAD', cwd=checkout).decode().strip()).exists()
        for path in paths:
            old = subprocess.run(['git', 'show', source + '^:' + path], capture_output=True)
            current = subprocess.run(['git', 'show', head + ':' + path], capture_output=True)
            assert old.returncode == current.returncode
            assert old.stdout == current.stdout
            if old.returncode:
                assert not (checkout / path).exists()
        preflight[label] = head
    for checkout, label in targets:
        head = preflight[label]
        index = private / (label + '-source.index')
        env = {**os.environ, 'GIT_INDEX_FILE': str(index)}
        git('read-tree', head, cwd=checkout, env=env)
        leaves = []
        for path in paths:
            mode, _, oid, _ = git('ls-tree', source, '--', path).decode().split(None, 3)
            git('update-index', '--add', '--cacheinfo', mode, oid, path, cwd=checkout, env=env)
            leaves.append(dict(path=path, mode=mode, blob=oid, sha256=sha(git('show', source + ':' + path))))
        tree = git('write-tree', cwd=checkout, env=env).decode().strip()
        assert set(git('diff', '--name-only', head, tree).decode().splitlines()) == set(paths)
        message = 'Integrate tested learner registration transaction barrier\n\nApply exactly the three checked source leaves and bind original source ' + source + '. Preserve every other target leaf, live knowledge refresh, runtime and parallel records. Upstream directory lifecycle and historical null-lease causes remain unresolved. No game behavior release.\n\n' + footer + '\n'
        commit = git('commit-tree', tree, '-p', head, '-p', source, data=message.encode()).decode().strip()
        real_index = Path(git('rev-parse', '--git-path', 'index', cwd=checkout).decode().strip()).resolve()
        index_lock = Path(str(real_index) + '.lock')
        fd = os.open(index_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        published = False
        try:
            assert git('rev-parse', 'HEAD', cwd=checkout).decode().strip() == head
            assert not git('diff', '--cached', '--name-only', cwd=checkout).strip()
            with os.fdopen(fd, 'wb') as handle:
                handle.write(index.read_bytes())
                handle.flush()
                os.fsync(handle.fileno())
            git('update-ref', '-m', 'ops: integrate original registration barrier source', 'HEAD', commit, head, cwd=checkout)
            published = True
            for leaf in leaves:
                target = checkout / leaf['path']
                temporary = private / (label + '-' + Path(leaf['path']).name + '.leaf')
                temporary.write_bytes(git('show', source + ':' + leaf['path']))
                os.chmod(temporary, 0o755 if leaf['mode'] == '100755' else 0o644)
                os.replace(temporary, target)
            os.replace(index_lock, real_index)
        finally:
            if index_lock.exists() and not published:
                index_lock.unlink()
        git('merge-base', '--is-ancestor', source, commit)
        assert not git('diff', '--cached', '--name-only', cwd=checkout).strip()
        assert not git('diff', '--name-only', '--', *paths, cwd=checkout).strip()
        for leaf in leaves:
            assert sha((checkout / leaf['path']).read_bytes()) == leaf['sha256']
        assert git('rev-parse', head + ':knowledge', cwd=checkout) == git('rev-parse', commit + ':knowledge', cwd=checkout)
        assert git('rev-parse', head + ':eval/versions.json', cwd=checkout) == git('rev-parse', commit + ':eval/versions.json', cwd=checkout)
        receipt['checkouts'][label] = dict(before=head, commit=commit, tree=tree, source_ancestor=True, leaves=leaves,
            only_three_checked_leaves_changed=True, knowledge_and_versions_exactly_preserved=True, parallel_worktree_files_not_written=True)
        write(public / 'integration.json', receipt)
    if receipt['live_integration_deferred_for_active_builder']:
        receipt['status'] = 'main_integrated_live_pending_active_knowledge_builder'
        receipt['live_current_read_only'] = git('rev-parse', 'HEAD', cwd=live).decode().strip()
        receipt['live_current_knowledge_dirty_paths'] = git('diff', '--name-only', '--', 'knowledge', cwd=live).decode().splitlines()
        write(public / 'integration.json', receipt)
        pending = root / 'ops/codex-ops/pending-integrations' / (batch_id + '.json')
        pending.parent.mkdir(parents=True, exist_ok=True)
        write(pending, receipt)
        print(json.dumps(dict(status=receipt['status'], source=source, main=receipt['checkouts']['main']['commit'], live=receipt['live_current_read_only'], active_builder_pids=receipt['active_knowledge_builder_pids'], host_full='not_started_until_live_integration')))
        raise SystemExit(0)
    environment = {**os.environ, 'TMPDIR': str(private), 'PYTHONDONTWRITEBYTECODE': '1'}
    with (public / 'live-registration-targeted.log').open('wb') as output:
        check = subprocess.run(['nice', '-n', '19', 'python3', '-B', 'ops/tests/test_learner_registration_barrier.py'], cwd=live,
            env=environment, stdout=output, stderr=subprocess.STDOUT, timeout=60)
    receipt['live_targeted_check'] = dict(rc=check.returncode, scope='2 fixed registration fixtures only; not a full suite', log='paper/materials/20261015-2216-ops/live-registration-targeted.log')
    assert check.returncode == 0
    receipt['status'] = 'precisely_integrated_original_host_full_and_natural_consumer_pending'
    write(public / 'integration.json', receipt)
    print(json.dumps(dict(status=receipt['status'], source=source, main=receipt['checkouts']['main']['commit'], live=receipt['checkouts']['live']['commit'], tree=receipt['checkouts']['live']['tree'], live_fixed_fixture_rc=check.returncode)))

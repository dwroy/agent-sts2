from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path.cwd()
private = root / 'ops/codex-ops/record-staging/20261015-2216'
public = root / 'paper/materials/20261015-2216-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], stderr=subprocess.PIPE)


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
batch_id = '20261015-214302-fix-batch'
batch = json.loads((root / 'ops/codex-ops/learn.json').read_text())['batches'][batch_id]
report = batch['report']
scratch = Path(report['report']).parent
integration = json.loads((public / 'integration.json').read_text())
assert integration['status'] == 'main_integrated_live_pending_active_knowledge_builder'
assert base == integration['checkouts']['main']['commit'] == '09cecbe8b28f1885a4800c009a8717eb9c33caed'
assert batch['state'] == 'failed' and batch['rc'] == 0 and report['merged'] is None
assert report['fixes'][0]['commit'] == integration['source']
assert json.loads((private / 'source-gitleaks.json').read_text()) == []
request = (public / 'live-continuation-request.log').read_text()
assert '已发送合入兜底事件' in request
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
pending = dict(at=at, batch=batch_id, source=integration['source'], main_integrated=base,
    live_observed=integration['live_current_read_only'], source_paths=integration['checkouts']['main']['leaves'],
    block='Original full branch preflight conflicted in10 knowledge JSONs. Ops preserved it and integrated only3 checked source leaves into main. Live build-fight-value.py PID3127135 was active, with8 live knowledge files being refreshed; no live writes or waiting loop.',
    request=dict(action='learner-merge', argument='codex-fix-silent-20261015-214302', rc=0,
        receipt='paper/materials/20261015-2216-ops/live-continuation-request.log', state='queued_original_manual_continuation_not_live_acceptance'),
    next_steps=['On the original continuation, acquire ops/live-merge.lock nonblockingly. If a builder is still active, preserve pending; do not enqueue another immediate retry loop.',
        'Inspect actual current live/index and knowledge refresh; preserve all new data and parallel records. Never rerun the old full-branch merge or the already-completed main integration helper.',
        'Integrate only the original3 source leaves with a fresh three-way preflight against source798af209 parent; retain all other live leaves. Bind original source ancestry as in the established narrow integration flow.',
        'Run the2 fixed registration fixtures on the actual new live composition, then request one original learner-recheck20261015-214302-fix-batch pinned host full. Preserve failures and exact tree; do not borrow source full as live success.',
        'Only later natural learner launches can validate saved registration/lease consumption. Do not start a model just for this. Keep upstream directory lifecycle, original null leases, 0332 and wider parents open.'],
    host_full=dict(started=False, rc=None), live_fixture_check='not_started_no_live_integration', natural_consumer='pending',
    release_id=None, release_reason='Infrastructure registration sequencing only; no game behavior change.',
    source_workspace='retained_for_original_live_and_host_closure; no cleanup attempted')
write(public / 'pending-live-handoff.json', pending)
write(root / 'ops/codex-ops/pending-integrations' / (batch_id + '.json'), pending)

manifest = []
with tarfile.open(public / 'original-artifacts.tar.gz', 'w:gz') as archive:
    paths = [path for path in scratch.iterdir() if path.is_file()]
    paths += [root / 'ops/codex-ops/learner' / (batch_id + extension) for extension in ['.out', '.err']]
    for path in sorted(paths):
        raw = path.read_bytes()
        relative = str(path.relative_to(root))
        archived = len(raw) < 1000000
        manifest.append(dict(path=relative, bytes=len(raw), sha256=sha(raw), archived=archived))
        if archived:
            copy = private / 'archive-scan' / relative
            copy.parent.mkdir(parents=True, exist_ok=True)
            copy.write_bytes(raw)
            archive.add(path, arcname=relative)
write(public / 'original-artifact-manifest.json', manifest)
write(public / 'completion.json', dict(at=at, batch=batch_id, source=integration['source'],
    main=base, live=integration['live_current_read_only'], main_source_ancestor_verified=True,
    original_source_checks=dict(tsc=0, sandbox_files=435, cases=4093, rc=0),
    actual_live_publication=False, actual_host_full_started=False, live_and_natural_consumers_pending=True,
    original_failure_and_conflicts_preserved=True, source_workspace_retained=True,
    one_original_manual_request=True, no_model_dispatch_or_game_action=True))

decision = f'\n- {at} 运维codex：2216原214302-fix source798af209新增父注册保存前租约捕获竞态修复，固定撤码底层2红/恢复27绿，源SANDBOX_WORKERS1完整435文件4093例tsc/vitest0无重跑、gitleaks0及原件SHA核，native Sol6.1/xhigh/input/lease/workspace-write/no-network核。原failed/rc0/mergednull与10知识JSON预检冲突保留；只取3源叶精确集成main09cecbe8并绑定原source祖先，其余知识/版本/并行记录不动。live仍f92636ae：原build-fight-value.py PID3127135正在刷新，8知识文件脏，首ops预检在写入前拦下并保留辅助脚本/失败，不等待或盲覆盖；本轮未合live、未执行live定向或宿主full。一次原broker learner-merge codex-fix-silent-20261015-214302实rc0仅排队原manual续办，queued不作实际部署或检查启动；待原通道空闲后窄集成、原批精确树完整补验及自然lease消费者。当前源码可复现注册竞态不同于历史所有null租约已归因；上游目录删除/ENOENT及0332完整resources/steps仍未知、其他策略父保持，不越租约重放。不改游戏/账号home模型权限预算prompt，不新增行为号/ledger/论文刷新；原WT保留待发布/检查闭环。证据paper/materials/20261015-2216-ops/。\n'
notice = f'\n- {at} [ops 启动注册修复/main已集成、live待续] 旧：父调度器尚未save_state时，普通learner包装器可能先捕获空租约；新：入口先经既有learn.lock事务屏障，释放后才捕获，120秒锁失败rc75且不启动模型。证据：原191301/RQ启动记录、source798af209固定交错撤码2红/恢复27绿及源435文件4093例通过；仅证明该代码竞态，不确定历史全部空租约或上游ENOENT原因。预期减少保存注册前的提前启动；回退只撤本3叶补丁，保其他更新。当前main09cecbe8已精确集成，live因知识构建器活动保留f92636ae/刷新数据；原manual续办已请求，live/宿主full/自然消费者均pending，不发游戏行为号、不重启对局。回执paper/materials/20261015-2216-ops/pending-live-handoff.json。\n'
handoff = f'\n- {at} 原214302-fix待live接续：source798af209b9a268b7dafab1440150f1b39cd5595d的3文件注册屏障已main09cecbe8b28f1885a4800c009a8717eb9c33caed；源完整435/4093绿。live f92636ae有知识构建器PID3127135及8知识刷新，ops未写live/未启动host。一次learner-merge原分支manual已排队，不能整枝重跑原10知识冲突merge，也不能重跑已完成main helper；下一原事件按paper/materials/20261015-2216-ops/pending-live-handoff.json非阻塞锁/当前builder/当前3叶三方核，保知识刷新后窄集成并绑定原source，随后同原批learner-recheck单次精确树宿主full及自然lease读回。若仍busy只留pending不即时重复排队；不重启局/新派学习者/改权限，原历史失败及上游目录unknown保持，WT先保留。\n'
queue = f'\n- {at} [sandbox-glob-startup-race窄修复接收] source798af209固定复现父learn.lock事务未保存即捕获租约并添加保存屏障；已通过源完整435文件4093例、main09cecbe8实际集成，仅3叶。live知识刷新活跃故本轮不写live，原manual续办/精确宿主检查和自然消费pending。只修可复现注册交错，不把历史null租约/ENOENT、目录删除者或上游生命周期一律记已修；原宽父继续。回执paper/materials/20261015-2216-ops/pending-live-handoff.json。\n'
appends = {'paper/materials/decision-log.md': decision, 'ops/inbox-dev.md': notice,
    'notes/for-roy.md': notice, 'notes/ops-handoff.md': handoff, 'notes/fix-queue-v4.md': queue}
write(private / 'own-appends.json', appends)
for path, text in appends.items():
    with (root / path).open('ab') as handle:
        handle.write(text.encode())

helpers = []
with tarfile.open(public / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    paths = [private / name for name in ['integrate-registration.py', 'integrate-first-builder-guard.py', 'integrate-first-builder-guard.log', 'prepare-records.py', 'seal-records.py']]
    paths.append(root / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py')
    for path in paths:
        raw = path.read_bytes()
        copy = private / 'helper-scan' / path.name
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        archive.add(path, arcname=path.name)
        helpers.append(dict(path=str(path.relative_to(root)), bytes=len(raw), sha256=sha(raw)))
write(public / 'ops-helper-manifest.json', helpers)
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}
for path in public.iterdir():
    if path.is_file():
        values[str(path.relative_to(root))] = path.read_bytes()
entries = []
for path, raw in values.items():
    copy = private / 'final-files' / path
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(private / 'record-manifest.json', dict(base=base, paths=entries))
print(json.dumps(dict(main_integrated=base, live_pending=True, original_source_full_cases=4093,
    actual_host_started=False, one_original_manual_request=True, paths=len(entries))))

import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-214302'
OUT = ROOT / 'learner/runs/20261015-214306-c1fbbfac-f9e0-42d8-a5ef-51eedcffc4f9-fix-batch'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args]).decode().strip()


assert (OUT / 'source-sandbox.exit').read_text().strip() == '0'
assert (OUT / 'registration-negative.exit').read_text().strip() == '1'
assert (OUT / 'registration-positive.exit').read_text().strip() == '0'
assert (OUT / 'gitleaks.exit').read_text().strip() == '0'
log = (OUT / 'source-sandbox.log').read_text()
files = sum(map(int, re.findall(r'Test Files\s+(\d+) passed', log)))
cases = sum(map(int, re.findall(r'Tests\s+(\d+) passed', log)))
assert files > 400 and cases > 3900
commit = git('rev-parse', 'HEAD')
audit = json.loads((OUT / 'audit.json').read_text())
skipped = json.loads((OUT / 'skipped.json').read_text())
merged = (OUT / 'live-final.txt').read_text().strip() if (OUT / 'live-final.txt').exists() else None
fix = {'item': 'sandbox-glob-startup-race：父注册事务尚未保存即捕获启动租约', 'commit': commit,
       'test': 'agent/tests/learner-registration-barrier.test.ts', 'fails_without_fix': True}
report = {'task': 'fix-batch', 'base': audit['base'], 'fixes': [fix], 'skipped': skipped,
          'merged': merged, 'tests': {'tsc': 0, 'vitest': 0, 'cases': cases},
          'code_proposals': [], 'implementation_domains': [], 'report': str(OUT / 'report.md')}
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
merge_result = '未合入'
if merged:
    merge_result = merged
elif (OUT / 'live-merge-tree.exit').exists() and (OUT / 'live-merge-tree.exit').read_text().strip() != '0':
    merge_result += '（live锁内三方预检有10个知识JSON内容冲突；本次数据已由他方刷新提交，无额外刷新提交，live仍为f92636aec0e099e656eb18d14ef73c7dc266ff55。未执行实际merge、合后测试或上线记录；详见live-publication-result.json）'
lines = ['## 修 bug 回报', '', f"- 合并基线：main → {audit['base']}",
         f"- 修复（每条一行）：{fix['item']} — {commit} — 测试 {fix['test']}:waits for saved scheduler registration before starting a learner and stops on lock timeout — 去掉修复时失败：是（Vitest 1失败，内含Python 2失败；恢复后3文件27项通过）。来源191301/RQCHNN0W72KF，离线启动层/回合不适用。"]
for r in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{r['item']} — {r['source_commit']}（已核来源祖先及当前源码；不关闭宽父）")
for r in skipped:
    lines.append(f"- 没修的：{r['item']} — {r['reason']}")
lines.extend([f'- 测试：tsc退出码0；Vitest沙箱合计{files}文件/{cases}用例/退出码0，无重跑；实际命令bash tools/test-sandbox.sh（SANDBOX_WORKERS=1，既有排除名单不变）。另定向3文件27项0，撤源码1文件1项失败（底层两项），恢复通过；gitleaks0。',
              '- 合入：' + merge_result,
              '- 需要 Roy 定的事（没有写「无」）：无。', '',
              '```json', json.dumps(report, ensure_ascii=False, indent=2), '```', ''])
(OUT / 'report.md').write_text('\n'.join(lines))
# Record exact artifact identities without archiving a checkout or copying mutable knowledge.
paths = ['source.diff', 'source-context.json', 'startup-evidence.json', 'native-model-readback.json',
         'audit.json', 'queue-snapshot.md', 'queue-dispositions.json', 'source-sandbox.log',
         'registration-negative.log', 'registration-positive.log', 'ledger-find.json', 'gitleaks.log', 'report.md', 'report.json']
manifest = {p: {'bytes': (OUT / p).stat().st_size, 'sha256': hashlib.sha256((OUT / p).read_bytes()).hexdigest()} for p in paths}
(OUT / 'artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'commit': commit, 'merged': merged, 'files': files, 'cases': cases, 'report': report['report']}, ensure_ascii=False))

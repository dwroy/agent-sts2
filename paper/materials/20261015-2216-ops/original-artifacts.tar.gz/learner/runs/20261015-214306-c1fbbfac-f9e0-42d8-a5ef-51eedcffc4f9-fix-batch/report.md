## 修 bug 回报

- 合并基线：main → a24ab305b337de84344000190c7f06c1ad8d59ed
- 修复（每条一行）：sandbox-glob-startup-race：父注册事务尚未保存即捕获启动租约 — 798af209b9a268b7dafab1440150f1b39cd5595d — 测试 agent/tests/learner-registration-barrier.test.ts:waits for saved scheduler registration before starting a learner and stops on lock timeout — 去掉修复时失败：是（Vitest 1失败，内含Python 2失败；恢复后3文件27项通过）。来源191301/RQCHNN0W72KF，离线启动层/回合不适用。
- 已被别人修掉的：silent-0254：无动作死亡战斗归因 — 3b48088dec5fc6eafe576a1296bbdadde43432ee（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：codex-usage-credit-baseline-recovery：额度窗口恢复基线 — 5b56a452bb9be14d620b368ec46974c1b57901ca（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ascension-up：请求进阶误报为实际进阶 — 8045d9fbf0a12523b1dbe39bbed8af06c7497b09（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout — bae9c45ccffefb284a1c6634526c8768a9f5f7a8（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：infra-ledger-status-prefix-git-divergence — dd478f0b3e5a0f234f082972d21b203dbf8229d7（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：infra-legacy-continuation-notice-ack-identity — 368fccabd42eb72ffcea9a2fe6cbbb7c149326be（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：infra-paper-krane-recorded-line-timeout — befc39e5ca0105f8ff96d47f817df44f0b2760f1（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：infra-learner-event-log-second-collision — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：strategy-proposal：报告 scratch 归属 — 5f04139cefe5c651dd5bf62f7e164014dbf5f23b（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0459：独立 run-plan 请求成本漏计 — 799a5cd0caf9329b43c32376079218a9bd0c3e9e（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：run-plan 证据提取未识别 run 字段 — 78e9b05929366d097a728761d693d790ff16ac87（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：postmortem-capacity-failure-proposal-repair-20261013 — 3fdcd77927f01b35c20c6c5c1fcfd790676032d2（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：blocked-experience-proposal-repair-dispatch — 84366ad06ee4f978394c1b9489a82c83ea12bd36（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：普通 ACK — 672e198a4730012330f599068a0ef1efadb02002（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 — 1594def2e1b65b665d3b345f31444194eb4d09e6（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 — 15eb85e2934e428c5e299fc4a1aba456d92fd685（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：feature 通知来源身份校验 — 38b2f572d90b3b97a23f9eae983f583287492f9a（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：feature/B4 通知来源桥接 — 1dd4d434aef67f1d065dbdba23a875ae82741a88（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：batch-f：包装/参数化测试超时静态解析 — 56c256dad0d33b231b82b53113d3bdd84f9bfa20（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：unassigned-strategy-proposal-resolution — 3a98e213a826e94f9708af4b1a265e1892659f4e（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval 固定历史输入 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-fixed-test-timeouts-010547：Apotheosis 有界夹具 — 9e8c93555131c3347f9e809d9722a848a75c2692（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：compute-memo-worker-data-signature — 8fbb441eb61eef226eb7366f9612003480c83988（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：rollout-live-best-test-determinism — bbc5b993a7524bbb8e80a975f204f8d193657b46（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-targeted-check-continuation：已过覆盖的精确续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：sandbox-glob-startup-race：会话前有界恢复 — bc2c40e313cc36682196277c53c50e30744b88c5（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：sandbox-glob-startup-race：复盘租约绑定 — d9983263ffecea1bed4e29d65e7f854a3d2e33d7（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：core-cycle-implementation-binding-entry — fc95760d4ff8a9cbd45577efdd79b1215bd2cb92（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-20261012-quantitative-continuation — b408252f87a77ee5389c4d90e52a9831c0873348（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：named-card-facts-transport：已批准的事件入口子项 — 42c920f34d9dc1c783ce894659849ab37ed6fd1b（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：core-build-notify-222802-rc2：保留原生失败诊断子项 — 5c92f2aaf0b758a1a5e7d591745694004664f83a（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：paper-dataset-git-consistency-race — 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：boss-sim-codex-home-preflight — 5921f8cd045853182c867a6430e75c3fcde00a87（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：shared-experience-fixed-filesystem-snapshot-20261013 — 8390c62d76fc8c7d7b6b7292121a621f4666d39c（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） — ec8c578b66bf5498372f1b779ae58a766dff8112（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：首项异步夹具 — 95e7f050ef2abe5c85a0367555392652ad73fbfe（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：固定失败诊断 — 9b6459fd99f26b17689134e33aa85d6190e71d7d（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：batch-c-fixed-fixture-timeout — 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：晚写复盘误计为上线后重犯 — 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：学习账本 first_run/asc/prior_note 追加更正 — 87c89b7aea90c7275e0fbb04b1e4148a4209630c（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：subscription-usage：未设置 TMPDIR — 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：deepseek-prompt-dump：状态日志反向流式扫描 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：固定药水测试隔离 — e78352f784d39cf25671446348daaada6ef2060b（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：单次 mod 超时 stall 误报 — a4f4ec868d122dc92af510862c6240cf2eaff2b6（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：学习状态锁被完整检查阻塞 — 233ede56047274ba53a4e1191a245fac816c37a8（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：学习者受阻后兜底完整检查入口 — f670884a188a047bbd3f7f007c260ade62fae36a（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：策略任务及自动派发入口 — afd652a3f75df6e7403439f01c565220327884da（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：旧事件选项重复问大脑 — 25ce09bee5576b1adff8baf196fbe8b197a5ef11（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0153：普通隐秘匕首生成分支 — b7f081fcc26da4506cb775739bb118cb6cbe4ecc（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0256：已观察的狡诈药水容量子项（实际源码提交） — 6403fdcdadc803a092beb5165a068e22bf51c412（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0260：普通紧勒逐牌失血 — 5c7105ff0294466da8319f2934beda05c6040794（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0263：已观察的碾碎爪转向取整子项 — ec29ea34b919344b707e57ba472ea210f9c39d62（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0266：SL 首牌身份 — e784dd9f043bf87c29109573f48975f9903280d3（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0272：商店移除预览与真实选牌页核对 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0324：普通刀舞生成小刀 — 66c22ba7d87b8748690a4183fff838acd346bd3e（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0338：回合末防御事实来源注记 — c1d84804956bedbd29a7f0e81294114e18415b9d（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：silent-0367：已用蜥蜴尾巴事实接线 — 5baf663d7e6678efa3690e5a48329c4f8baee109（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：infra-learner-launch-shared-main-config-race — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：固定时间夹具 — b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：续验拒绝诊断 — 63f656fb07a21a7496353234269901a832eae497（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-worktree-history-disk-pressure：broker容量/回执失败隔离 — a136ddc4b5b0a8696f10b2fae3073322d57e724c（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-worktree-history-disk-pressure：无终态标记退出 — db072ddab47ba94efb46dce2913927f936ecb97e（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-worktree-history-disk-pressure：JSONL追加边界 — 9b07240b18f862efdbe630889ade04e8976eaace（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：ops-worktree-history-disk-pressure：历史副本/按需恢复 — c7a6efb1e15ed6c5f31a35ae3ee9833863340393（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：tracked-source Python缓存回收认定 — 1e8af775f6b90f100f20ff7c4a08dfddaba893a9（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：完成报告裸JSON兼容 — 6f86ff6b6b971fb38b96308ebdd34dec574e5b13（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：autoplay安全热交接动作 — 71b835a3150704548fab2ad46e74bde240ccf1f9（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：历史测试入口漏传日志回调 — ccd8bb8e017da9c30b408138d04e6d2bc985836d（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：额度警告固定测试契约 — 1cf0490492bd8a430b85f95f3fdee91eba251191（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：有限结束报告与补验交接 — 2c4ce406c9ae598835f22292e52cfd936ac10b14（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-checks-broker-push-registration — c519952b31e3a0bb3acdd2115883ae8671b8a090（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：host-checks-session-exit-fixture — 874ae603b3927173f805e0b2fe789330bab710c7（已核来源祖先及当前源码；不关闭宽父）
- 已被别人修掉的：v5-dpr-health：明确不支持的候选被误计为DPR交付失败（仅分类子项） — 9e6dd82a34fb8c14e012be68fd0b632544f1459f（已核来源祖先及当前源码；不关闭宽父）
- 没修的：silent-0481：技能药水选牌生命周期措辞 — 策略类/题面知识：selection.ts 两处旧措辞仍在；已有 silent-proposal-686d4e759478eebb，按独立 strategy-proposal 实现，本普通批不重复登记。
- 没修的：silent-0311：库存后继血量预算 — 策略类/模型：现有 enemyDown 仍按旧 maxHp 恢复；已有 silent-proposal-d2f24919ee64b90b。2LZHP9BYFTHE 正确定位为 A10 F37 T1/4/10，保留原策略链，不加固定倍率。
- 没修的：silent-0332：成功首战资源 nonpositive-hp — 证据不足：原RQCHNN0W72KF F40/F48 resources/steps仍截断，nonpositive-hp根因未知；沿原5aa2672及f4e0f382提案，不改变正HP资源契约。
- 没修的：silent-0469：聚合体纸鹤组合 — 策略类：HLAWCGM3KHVB F49T3 多击/玩家易伤/突然一拳超出已发布骑士窄范围；沿 silent-proposal-0cce435d0d61ac93，不关闭宽父。
- 没修的：rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构：hand/loop.ts 仍在 dispatch 成功后 applyResolved；沿 silent-proposal-2d3aa8dfb27dbe3f 验证动作确认与路线提交，不无条件提交未确认动作。
- 没修的：其余出牌、机制、药水、SL、终局、路线、休息未闭合范围 — 策略类：沿各条原账本与独立strategy-proposal；41条未勾选记录逐行见queue-dispositions.json，已修窄范围不关闭宽父项。
- 没修的：codex 大脑缓存命中偏低 — 证据不足：缺当前原生请求的受控同题比较；本离线任务不调用真实 LLM 或网络，不凭历史命中率判断源码缺陷。
- 没修的：调度公平性核查 — 证据不足：原观察未证明永久饥饿，沿原框架任务核 dispatch/seen_runs，不改变并发、优先级或队列状态。
- 没修的：sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因 — 证据不足：当前源码允许父注册尚未保存即捕获租约的竞态已由本批固定交错复现并修复；目录删除者、具体历史注册时序及其他租约拒绝原因仍未知。原ENOENT/空租约/次数与冷却不改写，不越租约重放。
- 没修的：core-build-notify-222802-rc2：历史发送事实 — 证据不足：后续原生失败诊断已有5c92f2aaf；原rc2无stderr，无法事后还原是否发送，保留原回执，不重发。
- 没修的：named-card-facts-transport：事件入口之外的范围 — 太大/独立功能：事件入口42c920f34已实现，其他入口/跨局及P1/P2范围沿原架构owner，不混入普通修复。
- 没修的：boss模拟样本/性能、v5-dpr-health宽范围 — 太大/独立专项：保持原冻结输入和验收链；固定回归不代替校准，不减样本、扩预算或删候选。
- 没修的：arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression — 策略类/独立架构与归因研究：沿既有批准任务，不在普通批改变资源价值、玩法或派发规则。
- 没修的：框架外层总时限收尾 — 太大/独立框架：精确分段续验入口24c2e3a75已实现；剩余包装器与宿主收尾沿原owner，保留历史失败和覆盖。
- 测试：tsc退出码0；Vitest沙箱合计435文件/4093用例/退出码0，无重跑；实际命令bash tools/test-sandbox.sh（SANDBOX_WORKERS=1，既有排除名单不变）。另定向3文件27项0，撤源码1文件1项失败（底层两项），恢复通过；gitleaks0。
- 合入：未合入（live锁内三方预检有10个知识JSON内容冲突；本次数据已由他方刷新提交，无额外刷新提交，live仍为f92636aec0e099e656eb18d14ef73c7dc266ff55。未执行实际merge、合后测试或上线记录；详见live-publication-result.json）
- 需要 Roy 定的事（没有写「无」）：无。

```json
{
  "task": "fix-batch",
  "base": "a24ab305b337de84344000190c7f06c1ad8d59ed",
  "fixes": [
    {
      "item": "sandbox-glob-startup-race：父注册事务尚未保存即捕获启动租约",
      "commit": "798af209b9a268b7dafab1440150f1b39cd5595d",
      "test": "agent/tests/learner-registration-barrier.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "silent-0481：技能药水选牌生命周期措辞",
      "reason": "策略类/题面知识：selection.ts 两处旧措辞仍在；已有 silent-proposal-686d4e759478eebb，按独立 strategy-proposal 实现，本普通批不重复登记。"
    },
    {
      "item": "silent-0311：库存后继血量预算",
      "reason": "策略类/模型：现有 enemyDown 仍按旧 maxHp 恢复；已有 silent-proposal-d2f24919ee64b90b。2LZHP9BYFTHE 正确定位为 A10 F37 T1/4/10，保留原策略链，不加固定倍率。"
    },
    {
      "item": "silent-0332：成功首战资源 nonpositive-hp",
      "reason": "证据不足：原RQCHNN0W72KF F40/F48 resources/steps仍截断，nonpositive-hp根因未知；沿原5aa2672及f4e0f382提案，不改变正HP资源契约。"
    },
    {
      "item": "silent-0469：聚合体纸鹤组合",
      "reason": "策略类：HLAWCGM3KHVB F49T3 多击/玩家易伤/突然一拳超出已发布骑士窄范围；沿 silent-proposal-0cce435d0d61ac93，不关闭宽父。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构：hand/loop.ts 仍在 dispatch 成功后 applyResolved；沿 silent-proposal-2d3aa8dfb27dbe3f 验证动作确认与路线提交，不无条件提交未确认动作。"
    },
    {
      "item": "其余出牌、机制、药水、SL、终局、路线、休息未闭合范围",
      "reason": "策略类：沿各条原账本与独立strategy-proposal；41条未勾选记录逐行见queue-dispositions.json，已修窄范围不关闭宽父项。"
    },
    {
      "item": "codex 大脑缓存命中偏低",
      "reason": "证据不足：缺当前原生请求的受控同题比较；本离线任务不调用真实 LLM 或网络，不凭历史命中率判断源码缺陷。"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：原观察未证明永久饥饿，沿原框架任务核 dispatch/seen_runs，不改变并发、优先级或队列状态。"
    },
    {
      "item": "sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因",
      "reason": "证据不足：当前源码允许父注册尚未保存即捕获租约的竞态已由本批固定交错复现并修复；目录删除者、具体历史注册时序及其他租约拒绝原因仍未知。原ENOENT/空租约/次数与冷却不改写，不越租约重放。"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足：后续原生失败诊断已有5c92f2aaf；原rc2无stderr，无法事后还原是否发送，保留原回执，不重发。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外的范围",
      "reason": "太大/独立功能：事件入口42c920f34已实现，其他入口/跨局及P1/P2范围沿原架构owner，不混入普通修复。"
    },
    {
      "item": "boss模拟样本/性能、v5-dpr-health宽范围",
      "reason": "太大/独立专项：保持原冻结输入和验收链；固定回归不代替校准，不减样本、扩预算或删候选。"
    },
    {
      "item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression",
      "reason": "策略类/独立架构与归因研究：沿既有批准任务，不在普通批改变资源价值、玩法或派发规则。"
    },
    {
      "item": "框架外层总时限收尾",
      "reason": "太大/独立框架：精确分段续验入口24c2e3a75已实现；剩余包装器与宿主收尾沿原owner，保留历史失败和覆盖。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4093
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-214306-c1fbbfac-f9e0-42d8-a5ef-51eedcffc4f9-fix-batch/report.md"
}
```

#!/usr/bin/env bash
set -eu
root=/home/dw/Projects/agent-sts2
work="$root/.worktrees/codex-fix-silent-20261015-214302"
live="$root/.worktrees/live"
out="$root/learner/runs/20261015-214306-c1fbbfac-f9e0-42d8-a5ef-51eedcffc4f9-fix-batch"
export TMPDIR="$out"
export PATH="$HOME/.local/node/bin:$PATH"
export SANDBOX_WORKERS=1
branch=$(git -C "$work" branch --show-current)
exec 9> "$root/ops/live-merge.lock"
flock -w 50 9 || exit 75
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
cd "$live"
git rev-parse HEAD > "$out/live-before-refresh.txt"
git status --porcelain > "$out/live-status-before.txt"
if ! git diff --cached --quiet; then
  echo 'live index already has staged changes; preserve the other owner' >&2
  exit 3
fi
git add knowledge
if git ls-files --error-unmatch notes/fight-value-backtest.md >/dev/null 2>&1; then
  git add notes/fight-value-backtest.md
fi
if ! git diff --cached --quiet; then
  gitleaks git --staged --redact --no-banner --report-format json --report-path "$out/live-refresh-gitleaks.json" > "$out/live-refresh-gitleaks.log" 2>&1
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
git rev-parse HEAD > "$out/live-before-merge.txt"
git diff --name-only "$(cat "$out/live-before-refresh.txt")" HEAD -- knowledge notes/fight-value-backtest.md | sort > "$out/live-refresh-paths.txt"
merge_base=$(git merge-base HEAD "$branch")
git diff --name-only "$merge_base" "$branch" | sort > "$out/source-merge-paths.txt"
comm -12 "$out/live-refresh-paths.txt" "$out/source-merge-paths.txt" > "$out/live-refresh-overlap.txt"
set +e
git merge-tree --write-tree --messages --name-only HEAD "$branch" > "$out/live-merge-tree.txt" 2> "$out/live-merge-tree.err"
preflight=$?
set -e
printf '%s\n' "$preflight" > "$out/live-merge-tree.exit"
if [ "$preflight" != 0 ]; then
  echo 'merge preflight has conflicts; live refs and working files are preserved after the knowledge refresh' >&2
  exit 3
fi
git merge --no-edit "$branch"
git rev-parse HEAD > "$out/live-merged-source.txt"
set +e
(cd agent && bash tools/test-sandbox.sh) > "$out/live-sandbox.log" 2>&1
checked=$?
set -e
printf '%s\n' "$checked" > "$out/live-sandbox.exit"
if [ "$checked" != 0 ]; then
  git reset --merge "$(cat "$out/live-before-merge.txt")"
  echo 'live checks failed; reverted the merge and retained the knowledge refresh' >&2
  exit "$checked"
fi
date > "$out/live-publication-date.txt"
python3 - "$out" <<'PY'
from pathlib import Path
import subprocess, sys
out = Path(sys.argv[1])
source = subprocess.check_output(['git', '-C', '/home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261015-214302', 'rev-parse', 'HEAD']).decode().strip()
merged = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
stamp = subprocess.check_output(['date', '+%F %T %Z']).decode().strip()
with Path('paper/materials/decision-log.md').open('a') as f:
    f.write(f'\n- {stamp} 学习者 codex：fix-batch 20261015-214302 将 sandbox-glob-startup-race 的父注册事务屏障实际合入live {merged}，source {source}；来源队列1061/1067/1334与复盘191301/RQCHNN0W72KF（离线启动，层/回合不适用），无对应bug-infra账本。固定交错证明子入口不得早于父save_state捕获租约，锁超时rc75且不启动；撤源码底层2失败/恢复定向27过，源与合后沙箱均0。只修通用启动注册竞态，不改变游戏规则/角色估值/模型/权限/重试门槛，不造行为版本；历史null租约/ENOENT原件及上游目录根因、0332资源契约和各策略父项保持。\n')
PY
git add paper/materials/decision-log.md
gitleaks git --staged --redact --no-banner > "$out/live-record-gitleaks.log" 2>&1
git commit -m 'Record learner registration barrier deployment' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
git rev-parse HEAD > "$out/live-final.txt"

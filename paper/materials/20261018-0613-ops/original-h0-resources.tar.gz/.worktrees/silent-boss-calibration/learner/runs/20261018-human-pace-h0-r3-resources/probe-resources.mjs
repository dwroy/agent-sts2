/** Observe only the first transition and next-turn resource construction of the frozen qualified closure. */
import assert from 'node:assert/strict';
import{readFileSync,writeFileSync}from'node:fs';import{resolve}from'node:path';import{pathToFileURL}from'node:url';import{createHash}from'node:crypto';
const here=resolve(process.argv[2]),prior=resolve(here,'../20261018-human-pace-h0-r3-followup'),old=resolve(here,'../20261017-human-pace-h0-r1');
const sha=x=>createHash('sha256').update(x).digest('hex');const source=resolve(prior,'compiled/agent/src/reflex/rollout.js');const raw=readFileSync(source,'utf8');
const endNeedle='  const drunk = plan.steps.filter(isPotion).map(';const drawNeedle='    const started = budget.now();';
assert.equal(raw.split(endNeedle).length,2);assert.equal(raw.split(drawNeedle).length,2);
const endHook='  globalThis.__H0_RESOURCE__?.({endpoint:"after-first-command-before-draw",turn,player,piles,enemies});\n';
const drawHook='    globalThis.__H0_RESOURCE__?.({endpoint:"next-player-before-solver",h,player,piles,hand,handBase,pSim,sims});\n';
const moduleFile=resolve(prior,'compiled/agent/src/reflex/rollout-resource-observer.js');const observed=raw.replace(endNeedle,endHook+endNeedle).replace(drawNeedle,drawHook+drawNeedle);writeFileSync(moduleFile,observed);
writeFileSync(resolve(here,'observer-manifest.json'),JSON.stringify({source,source_sha256:sha(raw),module:moduleFile,module_sha256:sha(observed),insertions:[endHook,drawHook],scope:'Read-only deep-cloned diagnostic callbacks; unchanged canonical prediction module and RNG/inputs. Only first transition and next solver construction inspected; second simulated player turn is not an observed trajectory.'},null,2)+'\n');
const load=p=>import(pathToFileURL(resolve(prior,'compiled',p)).href);
const{makeKnowledge}=await load('agent/src/knowledge/index.js');const{parseGameState}=await load('agent/src/hand/mod/schema.js');const{boardOf}=await load('agent/tools/boss-sim/backtest-board.js');const{readMonsterDbJson}=await load('agent/src/knowledge/monster-db.js');const{solveTurn}=await load('agent/src/reflex/turn-solver.js');const{rolloutLiveOptions}=await load('agent/src/reflex/rollout-live.js');const{simulateFight}=await import(pathToFileURL(moduleFile));rolloutLiveOptions.enabled=false;
const knowledge=makeKnowledge(JSON.parse(readFileSync(resolve(old,'frozen-model/data/game-data.json'))).collections,'cache');const mm=JSON.parse(readFileSync(resolve(old,'frozen-model/knowledge/common/move-model.json')));
const windows=JSON.parse(readFileSync(resolve(here,'resource-windows.json'))).rows;const rawStates=JSON.parse(readFileSync(resolve(here,'endpoint-raw-states.json')));const rows=[];
for(const w of windows){
 const row={boss:w.item.boss,run:w.item.run,turn:w.item.turn,key:w.item.key,pre:w.item.pre,next:w.endpoint,actual_hook_commands:w.hook_commands.map(x=>x.raw.chosen)};
 try{
  const state=rawStates[w.item.pre.offset].state;const b=boardOf(parseGameState(structuredClone(state)),knowledge,w.item.boss,readMonsterDbJson().monsters,mm,{randomPotions:false});
  const input={...b.input,solver:{...b.solver,hand:b.solver.hand.map(c=>({...c,playable:false}))}};
  const plan=solveTurn(input.solver).plans.find(p=>p.steps.length===0);if(!plan)throw Error('no end-turn plan');
  const captures=[];globalThis.__H0_RESOURCE__=v=>captures.push(JSON.parse(JSON.stringify(v)));
  const result=simulateFight(input,plan,2,7,true,null);delete globalThis.__H0_RESOURCE__;
  row.status='observed';row.board={meta:input.meta,piles:b.piles,hand:input.solver.hand,player:input.solver.player,playerPowers:input.playerPowers,enemies:input.enemies,tables:input.tables,options:input.options,statusCards:input.statusCards,fightRelics:input.fightRelics};row.captures=captures;row.result=result;
 }catch(error){delete globalThis.__H0_RESOURCE__;row.status='unavailable';row.error=String(error);if(!['Error: no solve','Error: no end-turn plan'].includes(row.error))throw error;}
 rows.push(row);writeFileSync(resolve(here,'resource-probe-output.json'),JSON.stringify({model_sha256:'7508685dee238304a6457b0686a5af51fa865191390d6a0691257c39b684e84f',seed:7,rows},null,2)+'\n');
 console.log(JSON.stringify({boss:row.boss,status:row.status,captures:row.captures?.length,error:row.error,player:row.captures?.[0]?.player.hp,next:row.captures?.[1]?.pSim&&{hp:row.captures[1].pSim.hp,block:row.captures[1].pSim.block,energy:row.captures[1].pSim.energy},withers:row.board?.hand.filter(c=>c.cardId==='WITHER')}));
}

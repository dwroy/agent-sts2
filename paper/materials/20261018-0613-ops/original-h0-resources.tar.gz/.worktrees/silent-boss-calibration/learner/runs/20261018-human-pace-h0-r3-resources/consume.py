"""Execute the unchanged production experience loader/render/query probe on an actual tree."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SOURCES = ['agent/src/knowledge/files.ts', 'agent/src/knowledge/experience.ts',
           'agent/src/knowledge/render/data.ts', 'agent/src/knowledge/render/experience-text.ts']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def observe(root):
    return {'root': str(root), 'head': git(root, 'rev-parse', 'HEAD'), 'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
            'experience_sha256': sha(root / 'knowledge/characters/silent/experience.json'),
            'source_files': [{'path': p, 'sha256': sha(root / p)} for p in SOURCES]}


def main():
    root = Path(sys.argv[1]).resolve()
    label = sys.argv[2]
    assert '/' not in label
    before = observe(root)
    before_file = HERE / f'{label}-observation-before.json'
    save(before_file, before)
    payload = json.loads((HERE / 'candidate-experience-objects.json').read_text())
    payload.update(request_id='roy-20261017-human-pace-h0', revision=3,
                   input_sha256='1e1c259a15f1824119d0009747a89a60f60171705cb051b6c627597804bceea7',
                   expected_head=before['head'], expected_tree=before['tree'],
                   observation_file=str(before_file), observation_sha256=sha(before_file))
    input_file = HERE / f'{label}-input.json'
    save(input_file, payload)
    output_file = HERE / f'{label}-output.json'
    read_guard = HERE / f'{label}-read-guard.json'
    argv = ['nice', '-n', '19', str(Path.home() / '.local/node/bin/node'),
            '--import', str(root / 'agent/node_modules/tsx/dist/loader.mjs'),
            '--import', str(HERE / 'input-read-guard.mjs'), str(HERE / 'consumer.mts'),
            str(root), str(input_file), str(output_file)]
    env = {**os.environ, 'PATH': str(Path.home() / '.local/node/bin') + ':' + os.environ['PATH'],
           'TMPDIR': str(HERE), 'CHARACTER': 'silent', 'H0_READ_GUARD_OUT': str(read_guard)}
    with (HERE / f'{label}.log').open('w') as log:
        result = subprocess.run(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    save(HERE / f'{label}-command.json', {'argv': argv, 'cwd': str(root), 'exit_code': result.returncode,
                                         'at': dt.datetime.now(dt.timezone.utc).isoformat()})
    after = observe(root)
    save(HERE / f'{label}-observation-after.json', after)
    assert result.returncode == 0 and before == after, 'Consumer failed or its actual source/data changed'
    output = json.loads(output_file.read_text())
    assert output['status'] == 'passed' and len(output['checks']) == len(payload['entries'])
    for item in output['checks']:
        canonical = json.dumps(item['entry'], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
        assert hashlib.sha256(canonical).hexdigest() == item['sha256']
    guard = json.loads(read_guard.read_text())
    assert any(r['path'] == str(root / 'knowledge/characters/silent/experience.json') and r['status'] == 'read'
               and r['sha256'] == after['experience_sha256'] for r in guard)
    names = [f'{label}{suffix}' for suffix in ['-input.json', '-output.json', '-command.json',
             '-observation-before.json', '-observation-after.json', '-read-guard.json', '.log']]
    names += ['consumer.mts', 'consume.py', 'input-read-guard.mjs']
    receipt = {'request_id': 'roy-20261017-human-pace-h0', 'revision': 3, 'character': 'silent',
               'experience_version': output['experience_version'], 'kind': 'fixed-consumer', 'status': 'passed',
               'live_commit': after['head'], 'tested_tree': after['tree'],
               'entries': [{'id': r['id'], 'sha256': r['sha256']} for r in output['checks']],
               'evidence': [{'path': str(HERE / name), 'sha256': sha(HERE / name)} for name in names],
               'scope': 'Actual production loader/render/query input and output; fixed readability, no natural adoption or win improvement claim.'}
    save(HERE / f'{label}-receipt.json', receipt)
    print(json.dumps({'status': 'passed', 'entries': len(output['checks']), 'head': after['head'],
                      'receipt': str(HERE / f'{label}-receipt.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()

# H0/r3：六资源窗口与凋萎文本轨迹，数据源待合 live

request_id=roy-20261017-human-pace-h0；revision=3；input_sha256=1e1c259a15f1824119d0009747a89a60f60171705cb051b6c627597804bceea7。

本阶段 outcome=blocked。10条现有经验已去重更新，源 8fb2f481e7a68fc3707ccfcf9b25c5abc0577801；只改 knowledge/characters/silent/experience.json。code-proposals检查0，固定候选production loader/render/query十二对象passed。两次原live-merge.lock非阻塞取锁均exit3，均在live写入前退出，source不是live祖先，merged=null。本轮未分配行为版本、未写live eval/versions、未代记0513 shipped。旧女王源e2b0ea2cfdccba26e917bb72728f65049158fe4a及R392仍保留；正式号/宿主/0509/0510 shipped也仍待运维。

## 新结果与范围

原日志cut、原6指定窗口/4 Silent A10局。取下一真实play_card/use_potion/end_turn的同fingerprint原帧；6窗分别保留Tools选牌与敌方诅咒选择。抽弃耗牌堆按压缩行*数量展开，不把显示列表当隐藏抽牌序。只读旁路观察固定750模型的首命令后状态及下一轮solver构造，seed7不是实际抽牌轨迹；不再把next-player-end快照错当next-player-start。六窗的HP/格挡及未消耗卡牌ID总量全部相符；身份/升级/费用/附魔和选牌策略不因此等价。

| Boss；真实局/层/试/原回合 | 正确后继实HP/挡/能 vs模型 | 资源与实际动作 |
|---|---|---|
| TEST_SUBJECT；YZWV37N2MU6N/48/1/T1 | 63/7/3 = 63/7/3 | Tools实选弃笨拙后手9，样本手10；保留5张的Equilibrium轨迹不等实际抽序复现。原T1毒药completed、能力药pending后库存变化保留原件，不将排队回执当完成；本窗无再喝药。R386保留。 |
| AEONGLASS；25226ZFLNR1J/48/6/T6 | 9/0/3 = 9/0/3 | 末持1张6伤凋萎不造成净HP差，不等其无伤；总5→7与模型相符。实际所有可见凋萎文本6→9，模型牌堆模板3；实手7/样本手5，持Fiddle。金1→1无供能差。R392仅力量，不包含这些资源。 |
| QUEEN；ZVYUL2YP3518/48/1/T9 | 49/7/4 = 49/7/4 | 前缀首见聚合体于T9消失，女王仍在；本窗Enrage→Off With Your Head，女王HP139→46/力量0→2相符。后继首动作end_turn；不触发活盟友窄修，不证明全战kill-order因果优势。 |
| KAISER_CRAB；ZVYUL2YP3518/33/1/T9 | 42/0/4 = 42/0/4 | Rocket于T10首见死亡/移除，Crusher留存，力量3→12与原模型Adapt3+死亡Rage6相符。按唯一enemy_id保持身份；本窗零损不认证所有方向倍率。 |
| KNOWLEDGE_DEMON；JMH5C51RLN4E/33/1/T1 | 70/0/5 = 70/0/5 | 两条相同fingerprint的select均标T1，第一条wait超时、第二条completed；实MindRot1/手4，与模型同。无状态牌入堆，不加第二次诅咒。 |
| THE_INSATIABLE；25226ZFLNR1J/33/1/T1 | 67/0/4 vs 67/0/3 | 实6逃离牌：手1/抽2/弃3；模型抽前3/3，总量同。沙坑4。实际金159→156、持Seal of Gold且无其他动作，下一能量差1；先核逐轮金币/调用方配置，不从HP相符冒充资源等价。 |

actual-prefix-traces.json额外保存六场原前缀160帧/155命令，全部命令均找到原同fingerprint帧；失败/排队命令原样保留，不按“非completed”直接当失败或成功。可见actor移除只是首观察时点，不冒内部全序、未选顺序或胜因。无新自然局/模型服务/对局命令。

另复核已冻结82个Intensity窗口：67个双方ready且前后均有唯一可见凋萎文本的窗口/32局；T3/6/9/12为30/25/10/2窗，伤害文本3→6、6→9、9→12、12→15。14未就绪和1先无凋萎窗均完整保留。该轨迹不要求临时力量恢复无混杂，因此独立局数32与原力量轨迹31不同，不能混用统计。旧WITHER和Fiddle经验去重补充，不扩大观察等级/改写旧证据。

## 冻结与质量闸

复用7508685dee238304a6457b0686a5af51fa865191390d6a0691257c39b684e84f，241个canonical编译模块和原校准8文件逐SHA核同。新observer是独立模块，不进入校准闭包。原107调参/481验证、每对象200样本、1+原588行索引*101的seed、训练集Platt及四闸不变。本阶段源码/模拟输入均未变，新增预测行0，不重跑原66新/1110复用的上一阶段计算或已通过的源码测试。原6错误完整保留；生产boss-trust未替换。

复用原逐Boss/阶段/进阶结果：TestSubject T1失败Brier/gap/leak、pre gap/leak；Aeonglass T1 Brier/leak、pre Brier/gap/leak；Queen T1 Brier/gap/leak、pre Brier/leak；Crab两端Brier/leak；Knowledge两端leak；Insatiable两端Brier/leak。原最少10、Brier≤整体1.25倍（原round4）、gap±.15、leak[.7,1.3]保持；unknown/失败不删。阶段/进阶154分层及124无验证分层仍见上一阶段calibration-slices.json。六目标、0332及宽父均未关闭，未开展自然验收/H2on/H3+。

## 逐项验收

| requirement | 方法/证据 | 当前结果与限制 |
|---|---|---|
| h0-target-boss-mechanism-evidence | 六原命令至真实后继动作、实际前缀和82旧Intensity窗；source-byte-refs/原SHA | 新支持/反证已成候选经验；只A10所见端点，内部全序/未选策略未知。 |
| h0-frozen-inputs-and-residual-diagnosis | provenance-and-ownership、reuse-and-live-audit及resource-comparison | 原源/切分/缓存保留；定位卡面/起手/金币差，不由leak反推倍率。 |
| h0-evidence-backed-model-repair | 保R386/R388/R392/女王窄修；本轮只数据 | 未伪造资源源码已修；后续独立源码增量仍未实施。 |
| h0-fixed-split-recalibration-and-gates | 原750固定表和6错误逐SHA复用 | 当前无新源/预测，故不重校准；六目标仍有失败。 |
| h0-live-experience-source-consumer | 候选12对象真实production读回；新源一叶；实际旧live10对象另行读回 | 新源被原锁两次拒绝，未进入live；coverage只能沿用旧live10对象，不能计新候选。 |
| h0-limitations-and-objections | questions.json四项原观点/发现/证据/旧ID/建议；根双通知 | 卡面轨迹、零损反证、压缩牌/选择重试反证及Fiddle边界；不代填ops/watcher/Roy ACK。 |

## 上线阻塞和可执行下一步

固定一叶源 8fb2f481e7a68fc3707ccfcf9b25c5abc0577801，parent624e135f2337aab123ade42e9d104296d6e2a131，patch见source-delivery.patch。两次错误原件publication-20261018-060119/publication.json和publication-20261018-060335/publication.json，exit3/live-merge.lock busy，live文件均未变。publish-data.py保存原锁内逐entry合并预检，保其他刷新，实际读回后才写唯一版本；不可强占原锁或把排队当合入。运维在原锁释放后可沿原owner窄合该固定源，重核10个拥有entry与base/source等式，不覆盖并行知识；data-only无源码测试要求，再实际运行生产12对象读回，分配正式号/host边界并CLI shipped0513。

后续源码范围已在next-repair-impact-plan.json冻结“候选影响对象”，尚非重算列表：凋萎A10单沙漏2train/35val，Fiddle1/3，Seal5/35。先核实际wrapper是否已传handSize和金币预算，再冻结实际新源及精确影响；按750缓存重算必要T1/pre、train-only Platt与原闸。对凋萎要分别验证模板/既有牌/新生牌的伤害文本与已见绝对回合，不把upgraded布尔当+1/+2级，不扩T15+。金印/完整资源跨0332先交ops协调，本树无第二owner/无同slot写入。0332原缺真实失败封套的问题与这些局部残差不同，不另造失败或抢其owner。

回退仅撤本源对10经验的追加，不撤旧机制，不动其他刷新。新版本/新live回执未产生；根通知是实际追加回执，不等Roy已收。固定消费者不是自然采用/胜率改善。

## 材料

全部中间结果在本目录。科学材料及精确SHA见scientific-evidence-manifest.json；四项问题全文questions.json；账本silent-0513，提案silent-proposal-79324b20e05b791e。已冻结输入及历史报告不重写。

## 交付协议补充

当前原H0 batch的runs=[]、没有派发proposal_ids，所以proposal_results=[]。新登记的79324b20e05b791e保留pending，源8fb2f481尚未live，不用无派发任务的implemented/duplicate/waiting处置关闭它；实际证据局另见evidence_runs和上文。原报告report.md及已双通知的7274791d原SHA保持，下面绑定实际源身份。

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "base": "624e135f2337aab123ade42e9d104296d6e2a131",
  "fixes": [
    {
      "kind": "experience-data",
      "source": "8fb2f481e7a68fc3707ccfcf9b25c5abc0577801",
      "paths": [
        "knowledge/characters/silent/experience.json"
      ],
      "changed_entries": 10,
      "ledger": "silent-0513",
      "status": "qualified-source-live-merge-blocked",
      "summary": "六窗资源/实际策略前缀核查及67可见ready凋萎文本轨迹；10既有经验去重，新增模型修复未实现。",
      "commit": "8fb2f481e7a68fc3707ccfcf9b25c5abc0577801"
    }
  ],
  "merged": null,
  "tests": {
    "source_tests": {
      "status": "not_required",
      "reason": "Data and records only; no deployed source changes. Prior passed source tests not rerun or borrowed for this tree."
    },
    "check_experience": 0,
    "gitleaks": 0,
    "candidate_fixed_consumer": {
      "status": "passed",
      "entries": 12,
      "receipt": {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/source-consumer-receipt.json",
        "sha256": "6e249fbf2acd83ab8a5582f61dfcd4c0ca20f01a9e9764367dd70e80c62a6b93"
      }
    },
    "prior_live_fixed_consumer": {
      "status": "passed",
      "entries": 10,
      "receipt": {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/live-prior-consumer/prior-live-consumer-receipt.json",
        "sha256": "700157799c45a0c7f4fc90be406a1503b4d63e194e63858d98e8daa54af89b5e"
      }
    },
    "frozen_calibration": {
      "status": "reused-sha-verified",
      "model_sha256": "7508685dee238304a6457b0686a5af51fa865191390d6a0691257c39b684e84f",
      "compiled_modules": 241,
      "tune_keys": 107,
      "validation_keys": 481,
      "new_prediction_rows": 0,
      "errors_retained": 6,
      "all_six_targets_still_fail_quality_gates": true
    },
    "publication_attempts": [
      {
        "exit_code": 3,
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/publication-20261018-060119/publication.json"
      },
      {
        "exit_code": 3,
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/publication-20261018-060335/publication.json"
      }
    ]
  },
  "code_proposals": [
    "silent-proposal-79324b20e05b791e"
  ],
  "implementation_domains": [
    "combat",
    "structure"
  ],
  "proposal_results": [],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/delivery-report.md",
  "learning_result": {
    "request_id": "roy-20261017-human-pace-h0",
    "revision": 3,
    "input_sha256": "1e1c259a15f1824119d0009747a89a60f60171705cb051b6c627597804bceea7",
    "outcome": "blocked",
    "coverage": {
      "h0-target-boss-mechanism-evidence": [
        {
          "id": "silent-g1a-test-subject-calibration-boundary",
          "sha256": "7700b3765cb14e1aaf8423bc2d0f9bd8e37b8b7792b769ec04e63deee3a2df6c"
        },
        {
          "id": "silent-g1a-aeonglass-calibration-boundary",
          "sha256": "10b53601085980c15f6a1d4d9e7b582af4c2af04a39d35da564c3c8e099cc426"
        },
        {
          "id": "silent-g1a-queen-calibration-boundary",
          "sha256": "f9e7767b620a15c2660c750bb209a58fc1531dfebdafef0393306c9f920078c4"
        },
        {
          "id": "silent-h0-kaiser-crab-calibration-boundary",
          "sha256": "d3785486571315933215d6a88e5306147e68390fe28425309eed1915b23d5302"
        },
        {
          "id": "silent-h0-knowledge-demon-calibration-boundary",
          "sha256": "29b2e9762aa713892bb18d463b3f9f77382e6614109bfd40e96b0150e97e3fcb"
        },
        {
          "id": "silent-h0-insatiable-calibration-boundary",
          "sha256": "f6a98e2ef5006650eab774d30458c85493b8f8630e1450b62ea6205ef3810dc1"
        },
        {
          "id": "silent-aeonglass-intensity-observed-turns",
          "sha256": "fd25b18427cd78e2e871ef767dc023d8c3a04d78af67ac49c0ec33c52a4d60df"
        },
        {
          "id": "silent-queen-burn-bright-ally-strength",
          "sha256": "4adab537ad1b38f4b78e3d001b23c18e4adcaeacba84e4708ebc98726c3a51a9"
        }
      ],
      "h0-frozen-inputs-and-residual-diagnosis": [
        {
          "id": "silent-g1a-fixed-production-boundary",
          "sha256": "3fc26736077d06ad9d29fbd0dc7892bf35b7ad91de98d1d35ea81c19c86cf4e7"
        },
        {
          "id": "silent-h0-end-turn-measurement-boundary",
          "sha256": "b88e52056a5246fa9a0ed204b44b657cf57eee0c7c0df1159a39455dda743704"
        }
      ],
      "h0-evidence-backed-model-repair": [
        {
          "id": "silent-aeonglass-intensity-observed-turns",
          "sha256": "fd25b18427cd78e2e871ef767dc023d8c3a04d78af67ac49c0ec33c52a4d60df"
        },
        {
          "id": "silent-queen-burn-bright-ally-strength",
          "sha256": "4adab537ad1b38f4b78e3d001b23c18e4adcaeacba84e4708ebc98726c3a51a9"
        }
      ],
      "h0-fixed-split-recalibration-and-gates": [
        {
          "id": "silent-g1a-fixed-production-boundary",
          "sha256": "3fc26736077d06ad9d29fbd0dc7892bf35b7ad91de98d1d35ea81c19c86cf4e7"
        },
        {
          "id": "silent-g1a-test-subject-calibration-boundary",
          "sha256": "7700b3765cb14e1aaf8423bc2d0f9bd8e37b8b7792b769ec04e63deee3a2df6c"
        },
        {
          "id": "silent-g1a-aeonglass-calibration-boundary",
          "sha256": "10b53601085980c15f6a1d4d9e7b582af4c2af04a39d35da564c3c8e099cc426"
        },
        {
          "id": "silent-g1a-queen-calibration-boundary",
          "sha256": "f9e7767b620a15c2660c750bb209a58fc1531dfebdafef0393306c9f920078c4"
        },
        {
          "id": "silent-h0-kaiser-crab-calibration-boundary",
          "sha256": "d3785486571315933215d6a88e5306147e68390fe28425309eed1915b23d5302"
        },
        {
          "id": "silent-h0-knowledge-demon-calibration-boundary",
          "sha256": "29b2e9762aa713892bb18d463b3f9f77382e6614109bfd40e96b0150e97e3fcb"
        },
        {
          "id": "silent-h0-insatiable-calibration-boundary",
          "sha256": "f6a98e2ef5006650eab774d30458c85493b8f8630e1450b62ea6205ef3810dc1"
        }
      ],
      "h0-live-experience-source-consumer": [
        {
          "id": "silent-g1a-aeonglass-calibration-boundary",
          "sha256": "10b53601085980c15f6a1d4d9e7b582af4c2af04a39d35da564c3c8e099cc426"
        },
        {
          "id": "silent-g1a-queen-calibration-boundary",
          "sha256": "f9e7767b620a15c2660c750bb209a58fc1531dfebdafef0393306c9f920078c4"
        },
        {
          "id": "silent-g1a-test-subject-calibration-boundary",
          "sha256": "7700b3765cb14e1aaf8423bc2d0f9bd8e37b8b7792b769ec04e63deee3a2df6c"
        },
        {
          "id": "silent-g1a-fixed-production-boundary",
          "sha256": "3fc26736077d06ad9d29fbd0dc7892bf35b7ad91de98d1d35ea81c19c86cf4e7"
        },
        {
          "id": "silent-h0-kaiser-crab-calibration-boundary",
          "sha256": "d3785486571315933215d6a88e5306147e68390fe28425309eed1915b23d5302"
        },
        {
          "id": "silent-h0-knowledge-demon-calibration-boundary",
          "sha256": "29b2e9762aa713892bb18d463b3f9f77382e6614109bfd40e96b0150e97e3fcb"
        },
        {
          "id": "silent-h0-insatiable-calibration-boundary",
          "sha256": "f6a98e2ef5006650eab774d30458c85493b8f8630e1450b62ea6205ef3810dc1"
        },
        {
          "id": "silent-h0-end-turn-measurement-boundary",
          "sha256": "b88e52056a5246fa9a0ed204b44b657cf57eee0c7c0df1159a39455dda743704"
        },
        {
          "id": "silent-aeonglass-intensity-observed-turns",
          "sha256": "fd25b18427cd78e2e871ef767dc023d8c3a04d78af67ac49c0ec33c52a4d60df"
        },
        {
          "id": "silent-queen-burn-bright-ally-strength",
          "sha256": "4adab537ad1b38f4b78e3d001b23c18e4adcaeacba84e4708ebc98726c3a51a9"
        }
      ],
      "h0-limitations-and-objections": [
        {
          "id": "silent-g1a-fixed-production-boundary",
          "sha256": "3fc26736077d06ad9d29fbd0dc7892bf35b7ad91de98d1d35ea81c19c86cf4e7"
        },
        {
          "id": "silent-h0-end-turn-measurement-boundary",
          "sha256": "b88e52056a5246fa9a0ed204b44b657cf57eee0c7c0df1159a39455dda743704"
        }
      ]
    },
    "coverage_scope": "Only the prior ten actual live entries; none of this phase’s ten candidate updates is credited as live coverage. Coverage references do not mean the six requirements are complete.",
    "consumer_receipt": {
      "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/live-prior-consumer/prior-live-consumer-receipt.json",
      "sha256": "700157799c45a0c7f4fc90be406a1503b4d63e194e63858d98e8daa54af89b5e"
    },
    "candidate_experience_version": "2026-10-18.h0-r3-resources1",
    "actual_live_experience_version": "2026-10-18.h0-r3-queen1",
    "questions": [
      {
        "claim": "固定7508685d的牌堆WITHER模板heldPenalty=3；R392只修已见力量轨迹。不是Roy提出的固定伤害结论。",
        "finding": "25226ZFLNR1J A10 F48第6试T6→7，实际可见凋萎6→9而模型牌堆仍3；复核67个ready且前后唯一可见文本窗/32局，T3/6/9/12分别3→6/6→9/9→12/12→15。力量修正没有覆盖该资源轨迹，不能称六目标可信度已修。",
        "evidence": [
          "25226ZFLNR1J F48 a6 T6；resource-comparison.json、resource-probe-output.json保存实际原offset/len/SHA与固定probe输入输出",
          "67窗/32 Silent A10局的逐局原ref、14unready及1先无牌见wither-pool-evidence.json"
        ],
        "existing_entry_ids": [
          "silent-wither-end-turn-loss",
          "silent-aeonglass-intensity-observed-turns",
          "silent-g1a-aeonglass-calibration-boundary"
        ],
        "recommendation": "按可见文本和已见A10签名冻结独立凋萎源码增量，先核模板/新生牌/增强轨迹的资源契约，再只重算实际影响对象、train-only Platt及原四闸；不改倍率解释高leak，不扩T15+。"
      },
      {
        "claim": "本轮排查假设：首命令后HP/挡和按ID卡牌总量相符，可能足以认证整条资源轨迹；不是旧经验或Roy断言。",
        "finding": "六窗HP/挡及ID总量全相符，仍只有5窗下一轮能量相符。25226ZFLNR1J F33 T1→2实4能/金159→156，750模型3能；同局F48 T6→7持Fiddle实起手7而固定样本5。隐藏顺序、费用和资源预算不可由HP相符推出。",
        "evidence": [
          "25226ZFLNR1J F33 a1 T1、F48 a6 T6；resource-windows.json、resource-comparison.json",
          "原750冻结输入及源码身份见provenance-and-ownership.json；后续可能影响对象见next-repair-impact-plan.json"
        ],
        "existing_entry_ids": [
          "silent-h0-insatiable-calibration-boundary",
          "silent-fiddle-draw-lock",
          "silent-g1a-fixed-production-boundary"
        ],
        "recommendation": "先核真实调用方handSize和Seal金币预算配置，区分局部probe/固定校准/当前H1契约；涉及0332封套/资源槽先由ops协调，本阶段未改其源码或宣称根失败解决。"
      },
      {
        "claim": "本轮候选排查：Liquify似乎只生成三张牌，或Curse of Knowledge应向牌堆加状态牌/两次选择等于两次诅咒；均为待检假设。",
        "finding": "压缩行展开后，Liquify新增6张逃离牌：实手1/抽2/弃3，模型抽前3/3，总量一致。知识恶魔两条同fingerprint选择请求首wait超时、后completed，最终仅MindRot1/实手4；没有状态牌入堆。原模型在这些数量/层数上已相符，反驳据此修改生成数或再加诅咒。",
        "evidence": [
          "25226ZFLNR1J F33 a1 T1，JMH5C51RLN4E F33 a1 T1；resource-windows.json原chosen/result及resource-comparison.json"
        ],
        "existing_entry_ids": [
          "silent-h0-insatiable-calibration-boundary",
          "silent-h0-knowledge-demon-calibration-boundary",
          "silent-h0-end-turn-measurement-boundary"
        ],
        "recommendation": "保留现有六张/单层状态，不把超时重试计成功或SL窗口充n；同attempt时间区间收齐仍标T1的敌方选择，压缩牌数与实际隐藏顺序分开。"
      },
      {
        "claim": "silent-fiddle-draw-lock原文把轮初额外2列为仅文本。",
        "finding": "同一原支持局25226ZFLNR1J A10 F48第6试T6→7新增实际七张起手证据，与额外2一致；本窗无中间出牌/喝药，但无移除Fiddle或隐藏抽序反事实。",
        "evidence": [
          "25226ZFLNR1J F48 a6 T6原end_turn与下一首play_card的同fingerprint帧，见resource-windows.json、resource-comparison.json"
        ],
        "existing_entry_ids": [
          "silent-fiddle-draw-lock"
        ],
        "recommendation": "合并到既有条目，保留轮中禁抽知识；把这一个A10实窗的支持与其因果/外阶限制同时说明，不虚增独立支持局或宣称胜率改善。"
      }
    ],
    "reason": "新数据源8fb2f481e7a68fc3707ccfcf9b25c5abc0577801已固定且候选12对象production读回通过；两次原live-merge.lock取锁忙exit3，均无live写入，source非live祖先，merged=null。新经验未上线；已根双追加固定源、错误和四项异议，未代填ACK。六目标质量失败、后续凋萎/起手/金印资源修复及0332协调、0509/0510正式验收仍未完成。",
    "new_artifacts": [
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/report.md",
        "sha256": "7274791d2a1ee952779a5d9c7f02b36b6b9d200714fcf386bef99fdefe210fd6"
      },
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/resource-comparison.json",
        "sha256": "08746b633ccc046ce66e2dfa479a6bca138dde462fc02d6cc057050100901a91"
      },
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/wither-pool-evidence.json",
        "sha256": "329e708a5a777f9309a34051d4f4d400a60bf2fce3937a24163eeb95589d8eca"
      },
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/actual-prefix-traces.json",
        "sha256": "f2cfc0f7b9e5d932b9e9082dfb0a7940bb810f5666c7777eab68c83eea833509"
      },
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/next-repair-impact-plan.json",
        "sha256": "d7bb041005b2b57ab4991604b35623a885a4abe974f8bd3d400cad3c05e99381"
      },
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/source-delivery.patch",
        "sha256": "97f0079296da322c423363d2b1bdabc6819199f52252cb5ac669636742c0f084"
      },
      {
        "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/learner-dual-notification.json",
        "sha256": "d0eb675e871f7d668b61f62812ec20c99084b8d89d4d38f6745417e618076e59"
      }
    ],
    "next": "ops在原锁释放后按固定一叶源逐entry保刷新窄合，并实际读回新12对象、统一版本/host边界/0513 shipped；沿原H0 owner按影响计划先核调用配置与0332资源边界，再冻结必要源码增量/重算必要对象/原四闸，不改生产trust或关闭父项。",
    "notification_receipt": {
      "path": "/home/dw/Projects/agent-sts2/.worktrees/silent-boss-calibration/learner/runs/20261018-human-pace-h0-r3-resources/learner-dual-notification.json",
      "sha256": "d0eb675e871f7d668b61f62812ec20c99084b8d89d4d38f6745417e618076e59"
    }
  },
  "evidence_runs": [
    "YZWV37N2MU6N",
    "25226ZFLNR1J",
    "ZVYUL2YP3518",
    "JMH5C51RLN4E"
  ],
  "runs": []
}
```

## 探针元数据更正（保留原输出）

末次交叉核对发现resource-probe-output.json的actual_hook_commands标注沿用了首版turn+1过滤，漏了知识恶魔仍标T1的两条诅咒选择；原输出保留，正确请求/结果/ref见probe-hook-metadata-correction.json。实际端点、原始输入、seed、模拟数值均未改变；resource-windows.json、resource-comparison.json和actual-prefix-traces.json已使用正确同attempt时间区间，以上经验与异议依据这些已更正原件。没有重跑固定模拟或把重试计成两次成功。

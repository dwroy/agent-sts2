# H0/r3：六资源窗口与凋萎文本轨迹，数据源待合 live

request_id=roy-20261017-human-pace-h0；revision=3；input_sha256=1e1c259a15f1824119d0009747a89a60f60171705cb051b6c627597804bceea7。

本阶段 outcome=blocked。10条现有经验已去重更新，源 8fb2f481e7a68fc3707ccfcf9b25c5abc0577801；只改 knowledge/characters/silent/experience.json。code-proposals检查0，固定候选production loader/render/query十二对象passed。两次原live-merge.lock非阻塞取锁均exit3，均在live写入前退出，source不是live祖先，merged=null。本轮未分配行为版本、未写live eval/versions、未代记0513 shipped。旧女王源e2b0ea2cfdccba26e917bb72728f65049158fe4a及R392仍保留；正式号/宿主/0509/0510 shipped也仍待运维。

## 新结果与范围

原日志cut、原6指定窗口/4 Silent A10局。取下一真实play_card/use_potion/end_turn的同fingerprint原帧；6窗分别保留Tools选牌与敌方诅咒选择。抽弃耗牌堆按压缩行*数量展开，不把显示列表当隐藏抽牌序。只读旁路观察固定750模型的首命令后状态及下一轮solver构造，seed7不是实际抽牌轨迹；不再把next-player-end快照错当next-player-start。六窗的HP/格挡及未消耗卡牌ID总量全部相符；身份/升级/费用/附魔和选牌策略不因此等价。

| Boss；真实局/层/试/原回合 | 正确后继实HP/挡/能 vs模型 | 资源与实际动作 |
|---|---|---|
| TEST_SUBJECT；YZWV37N2MU6N/48/1/T1 | 63/7/3 = 63/7/3 | Tools实选弃笨拙后手9，样本手10；保留5张的Equilibrium轨迹不等实际抽序复现。原T1毒药completed、能力药pending后库存变化保留原件，不将排队回执当完成；本窗无再喝药。R386保留。 |
| AEONGLASS；25226ZFLNR1J/48/6/T6 | 9/0/3 = 9/0/3 | 末持1张6伤凋萎不造成净HP差，不等其无伤；总5→7与模型相符。实际所有可见凋萎文本6→9，模型牌堆模板3；实手7/样本手5，持Fiddle。金1→1无供能差。R392仅力量，不包含这些资源。 |
| QUEEN；ZVYUL2YP3518/48/1/T9 | 49/7/4 = 49/7/4 | 前缀首见聚合体于T9消失，女王仍在；本窗Enrage→Off With Your Head，女王HP139→46/力量0→2相符。后继首动作end_turn；不触发活盟友窄修，不证明全战kill-order因果优势。 |
| KAISER_CRAB；ZVYUL2YP3518/33/1/T9 | 42/0/4 = 42/0/4 | Rocket于T10首见死亡/移除，Crusher留存，力量3→12与原模型Adapt3+死亡Rage6相符。按唯一enemy_id保持身份；本窗零损不认证所有方向倍率。 |
| KNOWLEDGE_DEMON；JMH5C51RLN4E/33/1/T1 | 70/0/5 = 70/0/5 | 两条相同fingerprint的select均标T1，第一条wait超时、第二条completed；实MindRot1/手4，与模型同。无状态牌入堆，不加第二次诅咒。 |
| THE_INSATIABLE；25226ZFLNR1J/33/1/T1 | 67/0/4 vs 67/0/3 | 实6逃离牌：手1/抽2/弃3；模型抽前3/3，总量同。沙坑4。实际金159→156、持Seal of Gold且无其他动作，下一能量差1；先核逐轮金币/调用方配置，不从HP相符冒充资源等价。 |

actual-prefix-traces.json额外保存六场原前缀160帧/155命令，全部命令均找到原同fingerprint帧；失败/排队命令原样保留，不按“非completed”直接当失败或成功。可见actor移除只是首观察时点，不冒内部全序、未选顺序或胜因。无新自然局/模型服务/对局命令。

另复核已冻结82个Intensity窗口：67个双方ready且前后均有唯一可见凋萎文本的窗口/32局；T3/6/9/12为30/25/10/2窗，伤害文本3→6、6→9、9→12、12→15。14未就绪和1先无凋萎窗均完整保留。该轨迹不要求临时力量恢复无混杂，因此独立局数32与原力量轨迹31不同，不能混用统计。旧WITHER和Fiddle经验去重补充，不扩大观察等级/改写旧证据。

## 冻结与质量闸

复用7508685dee238304a6457b0686a5af51fa865191390d6a0691257c39b684e84f，241个canonical编译模块和原校准8文件逐SHA核同。新observer是独立模块，不进入校准闭包。原107调参/481验证、每对象200样本、1+原588行索引*101的seed、训练集Platt及四闸不变。本阶段源码/模拟输入均未变，新增预测行0，不重跑原66新/1110复用的上一阶段计算或已通过的源码测试。原6错误完整保留；生产boss-trust未替换。

复用原逐Boss/阶段/进阶结果：TestSubject T1失败Brier/gap/leak、pre gap/leak；Aeonglass T1 Brier/leak、pre Brier/gap/leak；Queen T1 Brier/gap/leak、pre Brier/leak；Crab两端Brier/leak；Knowledge两端leak；Insatiable两端Brier/leak。原最少10、Brier≤整体1.25倍（原round4）、gap±.15、leak[.7,1.3]保持；unknown/失败不删。阶段/进阶154分层及124无验证分层仍见上一阶段calibration-slices.json。六目标、0332及宽父均未关闭，未开展自然验收/H2on/H3+。

## 逐项验收

| requirement | 方法/证据 | 当前结果与限制 |
|---|---|---|
| h0-target-boss-mechanism-evidence | 六原命令至真实后继动作、实际前缀和82旧Intensity窗；source-byte-refs/原SHA | 新支持/反证已成候选经验；只A10所见端点，内部全序/未选策略未知。 |
| h0-frozen-inputs-and-residual-diagnosis | provenance-and-ownership、reuse-and-live-audit及resource-comparison | 原源/切分/缓存保留；定位卡面/起手/金币差，不由leak反推倍率。 |
| h0-evidence-backed-model-repair | 保R386/R388/R392/女王窄修；本轮只数据 | 未伪造资源源码已修；后续独立源码增量仍未实施。 |
| h0-fixed-split-recalibration-and-gates | 原750固定表和6错误逐SHA复用 | 当前无新源/预测，故不重校准；六目标仍有失败。 |
| h0-live-experience-source-consumer | 候选12对象真实production读回；新源一叶；实际旧live10对象另行读回 | 新源被原锁两次拒绝，未进入live；coverage只能沿用旧live10对象，不能计新候选。 |
| h0-limitations-and-objections | questions.json四项原观点/发现/证据/旧ID/建议；根双通知 | 卡面轨迹、零损反证、压缩牌/选择重试反证及Fiddle边界；不代填ops/watcher/Roy ACK。 |

## 上线阻塞和可执行下一步

固定一叶源 8fb2f481e7a68fc3707ccfcf9b25c5abc0577801，parent624e135f2337aab123ade42e9d104296d6e2a131，patch见source-delivery.patch。两次错误原件publication-20261018-060119/publication.json和publication-20261018-060335/publication.json，exit3/live-merge.lock busy，live文件均未变。publish-data.py保存原锁内逐entry合并预检，保其他刷新，实际读回后才写唯一版本；不可强占原锁或把排队当合入。运维在原锁释放后可沿原owner窄合该固定源，重核10个拥有entry与base/source等式，不覆盖并行知识；data-only无源码测试要求，再实际运行生产12对象读回，分配正式号/host边界并CLI shipped0513。

后续源码范围已在next-repair-impact-plan.json冻结“候选影响对象”，尚非重算列表：凋萎A10单沙漏2train/35val，Fiddle1/3，Seal5/35。先核实际wrapper是否已传handSize和金币预算，再冻结实际新源及精确影响；按750缓存重算必要T1/pre、train-only Platt与原闸。对凋萎要分别验证模板/既有牌/新生牌的伤害文本与已见绝对回合，不把upgraded布尔当+1/+2级，不扩T15+。金印/完整资源跨0332先交ops协调，本树无第二owner/无同slot写入。0332原缺真实失败封套的问题与这些局部残差不同，不另造失败或抢其owner。

回退仅撤本源对10经验的追加，不撤旧机制，不动其他刷新。新版本/新live回执未产生；根通知是实际追加回执，不等Roy已收。固定消费者不是自然采用/胜率改善。

## 材料

全部中间结果在本目录。科学材料及精确SHA见scientific-evidence-manifest.json；四项问题全文questions.json；账本silent-0513，提案silent-proposal-79324b20e05b791e。已冻结输入及历史报告不重写。

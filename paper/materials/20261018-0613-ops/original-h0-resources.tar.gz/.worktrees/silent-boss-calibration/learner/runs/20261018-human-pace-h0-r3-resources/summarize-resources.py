"""Compare only observables; unordered sampled piles are never an observed draw trajectory."""
from pathlib import Path
import json,re,collections,hashlib
H=Path(__file__).resolve().parent
w=json.loads((H/'resource-windows.json').read_text())['rows']; raw=json.loads((H/'endpoint-raw-states.json').read_text());m=json.loads((H/'resource-probe-output.json').read_text())['rows']
def cards(s,k):
 if k=='hand':return [{'id':x['card_id'],'count':1,'text':x['resolved_rules_text'],'name':x['name'],'cost':x['energy_cost']} for x in s['combat']['hand']]
 rows=[]
 for x in s['agent_view']['combat'][k]:
  assert len(x['card_ids'])==1, 'ambiguous pile ID, do not invent multiplicity'
  n=int((re.search(r'^[^\[：:]*?\*(\d+)\s*\[',x['line']) or [None,'1'])[1]);rows.append({'id':x['card_ids'][0],'count':n,'text':x['line']})
 return rows

def counter(cs):
 c=collections.Counter()
 for x in cs:c[x['id']]+=x['count']
 return c

def dif(a,b):return {k:{'observed':a[k],'model':b[k]} for k in sorted(a.keys()|b.keys()) if a[k]!=b[k]}
rows=[]
for a,b in zip(w,m):
 s=raw[str(a['item']['pre']['offset'])]['state'];t=raw[str(a['endpoint']['offset'])]['state'];first=b['captures'][0];nxt=b['captures'][1]
 pre={k:cards(s,k) for k in ['hand','draw','discard','exhaust']};post={k:cards(t,k) for k in pre}
 expected={k:t['combat']['player'][k] for k in ['current_hp','block','energy']};pred={'current_hp':first['player']['hp'],'block':first['player']['block'],'energy':nxt['pSim']['energy']}
 act=counter(sum((post[k] for k in ['hand','draw','discard']),[]));mod=collections.Counter(x['cardId'] for x in first['piles']['draw']+first['piles']['discard']+first['player']['retained'])
 status={id:{'pre':{k:counter(v)[id] for k,v in pre.items()},'observed':{k:counter(v)[id] for k,v in post.items()},'model_before_draw':{'draw':sum(x['cardId']==id for x in first['piles']['draw']),'discard':sum(x['cardId']==id for x in first['piles']['discard']),'retained':sum(x['cardId']==id for x in first['player']['retained'])}} for id in ['WITHER','FRANTIC_ESCAPE'] if any(x['id']==id for v in pre.values() for x in v) or any(x['id']==id for v in post.values() for x in v)}
 row={'boss':a['item']['boss'],'run':a['item']['run'],'asc':10,'turn':a['item']['turn'],'key':a['item']['key'],'pre':a['item']['pre'],'next':a['endpoint'],'command':a['item']['command'],'hook_commands':[{'ref':x['ref'],'ts':x['raw']['ts'],'turn':x['raw']['turn'],'chosen':x['raw']['chosen']} for x in a['hook_commands']], 'player_observed':expected,'player_model':pred,'different_player_fields':[k for k in expected if expected[k]!=pred[k]],'gold_observed':{'pre':s['run']['gold'],'next':t['run']['gold']},'potions_observed':{'pre':s['run']['potions'],'next':t['run']['potions']},'expanded_pile_counts':{'pre':{k:sum(x['count'] for x in v) for k,v in pre.items()},'next':{k:sum(x['count'] for x in v) for k,v in post.items()}},'nonexhaust_supply_difference':dif(act,mod),'status_cards':status,'wither_lines':{tag:[x for k in ['hand','draw','discard'] for x in v[k] if x['id']=='WITHER'] for tag,v in [('pre',pre),('next',post)]},'model_wither_penalties':{k:[{'heldPenalty':x['heldPenalty'],'text':x.get('text'),'name':x.get('name')} for x in first['piles'][k] if x['cardId']=='WITHER'] for k in ['draw','discard']},'mind_rot':{'observed':next((p['amount'] for p in t['combat']['player']['powers'] if p['power_id']=='MIND_ROT_POWER'),0),'model':first['player']['mindRot']},'observed_first_action':a['first_player_action']['raw']['chosen'],'sampled_next_hand':[x['cardId'] for x in nxt['hand']],'scope':'Raw actual next-action fingerprint and all same-attempt intervening decisions; seed7 sampled hand is diagnostic only, not actual unobserved order. Pool counts compare IDs only, not upgrades/cost/enchantment identity. No quality denominator change.'}
 rows.append(row)
(H/'resource-comparison.json').write_text(json.dumps({'request_id':'roy-20261017-human-pace-h0','revision':3,'model_sha256':'7508685dee238304a6457b0686a5af51fa865191390d6a0691257c39b684e84f','rows':rows},ensure_ascii=False,indent=2)+'\n')
for r in rows:print(r['boss'],r['player_observed'],r['player_model'],'supply_diff',r['nonexhaust_supply_difference'],'status',r['status_cards'],'mindrot',r['mind_rot'])

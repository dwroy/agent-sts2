"""Extract six original Silent resource windows without extending the frozen cut."""
import json,hashlib,sys,collections,datetime,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent; WORK=HERE.parents[2]; ROOT=Path('/home/dw/Projects/agent-sts2'); OLD=HERE.parent/'20261017-human-pace-h0-r1'; PRIOR=HERE.parent/'20261018-human-pace-h0-r3-followup'
sys.path.insert(0,str(WORK/'agent/tools/logdb'));import query,sync
cuts=json.loads((OLD/'extraction-summary.json').read_text())['cuts']
items=json.loads((PRIOR/'residual-next-windows.json').read_text())['items'];attempts={x['key']:x for x in map(json.loads,(OLD/'all-target-attempts-summary.jsonl').read_text().splitlines())}
refs={};raws={}
def read(stream,off,size):
 assert off+size<=cuts['logs/'+stream+'.jsonl']
 with (ROOT/('logs/'+stream+'.jsonl')).open('rb') as h:h.seek(off);b=h.read(size)
 assert len(b)==size and b.endswith(b'\n')
 ref={'path':str(ROOT/('logs/'+stream+'.jsonl')),'offset':off,'len':size,'sha256':hashlib.sha256(b).hexdigest()};refs[(stream,off)]=ref
 return json.loads(b),ref

def summary(raw):
 s=raw['state']; c=s['combat']; a=s['agent_view']['combat'];p=c['player']
 def card(x):return {k:x.get(k) for k in ['card_ids','line','i','card_id','name','upgraded','energy_cost','cost','index','card_type','pile_index','uuid','instance_id','description','text'] if k in x}
 return {'ts':raw['ts'],'turn':s['turn'],'screen':s['screen'],'readiness':c['action_readiness'],'selection':s['selection'],'player':{k:p.get(k) for k in ['current_hp','max_hp','block','energy','powers','cards_played_this_turn']},'piles':{k:[card(x) for x in a[k]] for k in ['hand','draw','discard','exhaust']},'enemies':c['enemies'],'potions':s['run']['potions'],'relics':s['run']['relics']}
rows=[]
with sync.read_lock(str(ROOT/'data/logdb'),shared=True):
 con=query.connect(str(ROOT/'data/logdb'),threads=1)
 for item in items:
  f=attempts[item['key']];pre,pr=read('states',item['pre']['offset'],item['pre']['len']);end,er=read('decisions',item['command']['offset'],item['command']['len']);assert pr['sha256']==item['pre']['sha256'] and er['sha256']==item['command']['sha256']
  frames=con.execute('SELECT off,len,ts,fingerprint,turn FROM frames WHERE run_id=? AND off>=? AND off<=? ORDER BY off',[f['run'],f['first_off'],f['last_off']]).fetchall()
  commands=[]
  for off,size in con.execute('SELECT off,len FROM decisions WHERE run_id=? AND floor=? AND off+len<=? ORDER BY off',[f['run'],f['floor'],cuts['logs/decisions.jsonl']]).fetchall():
   raw,ref=read('decisions',off,size)
   if raw.get('sl_attempt')!=f['attempt'] or not (str(frames[0][2]).replace(' ','T')[:19]<=raw['ts'][:19]<=str(frames[-1][2]).replace(' ','T')[:19]):continue
   commands.append({'ref':ref,'raw':raw})
  after=[r for r in commands if r['raw']['ts']>end['ts'] and r['raw'].get('turn')==item['turn']+1]
  major=next((r for r in after if r['raw'].get('chosen',{}).get('action') in ['play_card','use_potion','end_turn']),None)
  assert major,(item['boss'],'missing next player action')
  candidates=[f for f in frames if f[4]==item['turn']+1 and f[3]==major['raw']['fingerprint'] and f[2].isoformat(timespec='milliseconds')+'Z'<=major['raw']['ts']]
  assert candidates,(item['boss'],'missing exact next action frame')
  endpoint=candidates[-1]
  sequence=[]
  for off,size,ts,fp,t in frames:
   if item['pre']['offset']<=off<=endpoint[0]:
    raw,ref=read('states',off,size);assert raw['state']['run_id']==f['run'] and raw['state']['run']['character_id']=='SILENT';sequence.append({'ref':ref,'summary':summary(raw)});raws[str(off)]=raw
  raw,ref=read('states',endpoint[0],endpoint[1]);assert raw['state']['combat']['player']['cards_played_this_turn']==0
  row={'item':item,'attempt':{k:f[k] for k in ['key','run','asc','floor','attempt','outcome','split','first_off','last_off']},'end_turn':{'ref':er,'raw':end},'endpoint':ref,'first_player_action':major,'hook_commands':[r for r in commands if end['ts']<r['raw']['ts']<major['raw']['ts']], 'frames':sequence,'fight_command_prefix':[r for r in commands if r['raw']['ts']<=major['raw']['ts']]}
  rows.append(row)
 con.close()
(HERE/'resource-windows.json').write_text(json.dumps({'request_id':'roy-20261017-human-pace-h0','revision':3,'cuts':cuts,'rows':rows},ensure_ascii=False,indent=2)+'\n')
(HERE/'endpoint-raw-states.json').write_text(json.dumps(raws,ensure_ascii=False,separators=(',',':'))+'\n')
(HERE/'source-byte-refs.json').write_text(json.dumps(list(refs.values()),indent=2)+'\n')
for r in rows:
 print(r['item']['boss'],'frames',len(r['frames']),'hooks',[x['raw']['chosen']['action'] for x in r['hook_commands']],'first',r['first_player_action']['raw']['chosen'])
 for f in [r['frames'][0],r['frames'][-1]]:
  s=f['summary'];print(s['ts'],{k:s['player'][k] for k in ['current_hp','block','energy']},'piles',{k:collections.Counter(x.get('card_id') or '/'.join(x.get('card_ids',[])) for x in v) for k,v in s['piles'].items()},'enemy',[(e['enemy_id'],e['move_id'],e['current_hp'],{p['power_id']:p['amount'] for p in e['powers']}) for e in s['enemies']])

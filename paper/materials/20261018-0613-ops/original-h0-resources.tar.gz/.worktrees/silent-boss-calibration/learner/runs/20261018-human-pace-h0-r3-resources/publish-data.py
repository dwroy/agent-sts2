"""Integrate only this phase's data entries under the existing live lock and read them back."""
import datetime,fcntl,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
H=Path(__file__).resolve().parent;W=H.parents[2];R=Path('/home/dw/Projects/agent-sts2');L=R/'.worktrees/live';S=json.loads((H/'source-commit.json').read_text())['source'];E='knowledge/characters/silent/experience.json';A=H/('publication-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));A.mkdir();env={**os.environ,'PATH':str(Path.home()/'.local/node/bin')+':'+os.environ['PATH']};env.pop('GIT_INDEX_FILE',None)
state={'source':S,'merged':None,'publication':None,'kind':'data-only','attempt':str(A),'release_id':None};co='\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
def run(args,check=True,data=None,cwd=L,e=env):
 p=subprocess.run(args,cwd=cwd,env=e,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if check and p.returncode:raise RuntimeError(str(args[:4])+': '+p.stderr.decode(errors='replace')[-1400:])
 return p

def git(*args,**kw):return run(['git',*args],**kw).stdout.decode().strip()
def save():(H/'publication.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');(A/'publication.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def commit(msg,label):
 p=run(['nice','-n','19','gitleaks','git','--pre-commit','--staged','--redact','--no-banner'],check=False);(A/(label+'-gitleaks.log')).write_bytes(p.stdout+p.stderr);state[label+'_gitleaks_exit']=p.returncode;assert p.returncode==0
 git('commit','-m',msg+co);return git('rev-parse','HEAD')
def signature():return {str(p.relative_to(L)):(p.stat().st_size,p.stat().st_mtime_ns) for d in ['knowledge/common','knowledge/characters/silent'] for p in (L/d).glob('*.json') if p.is_file()}
assert json.loads((H/'source-consumer-receipt.json').read_text())['status']=='passed'
assert json.loads((H/'check-experience.json').read_text())['missing']==[]
base=git('rev-parse',S+'^',cwd=W);assert git('diff','--name-only',base,S,cwd=W)==E
lock=(R/'ops/live-merge.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:state['error']='live-merge.lock busy; no live mutation';save();raise SystemExit(3)
try:
 assert run(['git','rev-parse','--verify','MERGE_HEAD'],check=False).returncode!=0
 assert run(['git','diff','--cached','--quiet'],check=False).returncode==0
 state['initial_live']=git('rev-parse','HEAD');sig=signature();time.sleep(30);assert sig==signature(),'Knowledge refresh moving'
 status=run(['git','status','--porcelain','--untracked-files=all']).stdout.decode().rstrip('\n');(A/'live-status-before.txt').write_text(status+'\n');dirty=[a[3:] for a in status.splitlines()]
 assert not any(p.startswith(('agent/','learner/','eval/','ops/')) and p.endswith(('.ts','.py','.js','.mts','.mjs')) for p in dirty)
 refresh=[p for p in dirty if p.endswith('.json') and p.startswith(('knowledge/common/','knowledge/characters/silent/')) or p in ['notes/fight-value-backtest-silent.md','notes/monster-db-check.md']]
 state['refresh_files']=refresh;state['refresh_sha256']={p:sha(L/p) for p in refresh}
 for p in refresh:
  if p.endswith('.json'):json.loads((L/p).read_text())
 if refresh:git('add','--sparse','--',*refresh);state['refresh_commit']=commit('Preserve live knowledge before H0 resource observations','refresh')
 before=git('rev-parse','HEAD');state['before_data']=before
 b=json.loads(run(['git','show',base+':'+E],cwd=W).stdout);o=json.loads(run(['git','show',S+':'+E],cwd=W).stdout);c=json.loads((L/E).read_text())
 bm={a['id']:a for a in b['entries']};om={a['id']:a for a in o['entries']};cm={a['id']:a for a in c['entries']};owned=set(json.loads((H/'candidate-experience-objects.json').read_text())['owned_ids']);assert {i for i in om if bm.get(i)!=om[i]}==owned
 for i in owned:assert cm.get(i) in [bm.get(i),om[i]],'Parallel same-entry overlap: '+i
 c['entries']=[om[a['id']] if a['id'] in owned else a for a in c['entries']];c['version']=o['version'];raw=(json.dumps(c,ensure_ascii=False,indent=2)+'\n').encode();state['experience_version']=c['version'];state['owned_ids']=sorted(owned)
 idx={**env,'GIT_INDEX_FILE':str(A/'preflight.index')};git('read-tree','HEAD',e=idx);blob=run(['git','hash-object','-w','--stdin'],data=raw).stdout.decode().strip();git('update-index','--add','--cacheinfo','100644,'+blob+','+E,e=idx);tree=git('write-tree',e=idx);state['preflight_tree']=tree;save()
 assert set(git('diff','--name-only',before,tree).splitlines())=={E}
 git('merge','--no-ff','--no-commit','-s','ours',S);git('read-tree',tree);git('restore','--source',tree,'--worktree','--ignore-skip-worktree-bits','--',E);state['merged']=commit('Publish Silent H0 resource evidence and unresolved model limits','data');assert git('rev-parse','HEAD^{tree}')==tree;save()
 p=run(['nice','-n','19','python3',str(H/'consume.py'),str(L),'live-consumer'],check=False);(A/'consumer-wrapper.log').write_bytes(p.stdout+p.stderr);state['consumer_exit']=p.returncode;save();assert p.returncode==0,'Actual live consumer failed'
 receipt=H/'live-consumer-receipt.json';state['consumer_receipt']={'path':str(receipt),'sha256':sha(receipt)}
 at=run(['date','+%Y-%m-%d %H:%M:%S %Z']).stdout.decode().strip();v=L/'eval/versions.json';versions=json.loads(v.read_text());items=versions.get('versions',[]) if isinstance(versions,dict) else versions;state['version']='S1.silent-h0-resources-evidence1';assert not any(a['name']==state['version'] for a in items)
 items.append({'name':state['version'],'family':'V5','character':'SILENT','commit':state['merged'],'release_status':'pending-primary-ops','source':at+'; H0/r3 data-only source '+S+'; ledger silent-0513. Six original A10 resource windows/four runs and67 visible ready Wither transitions/32 runs;10 existing entries merged,12 actual production loader/render/query entries passed. HP/block and ID supply match but Wither pile damage/next hand size/Seal gold energy differ; false missing-status/double-curse hypotheses refuted. Original750 full-model/107train/481val/200/seed/Platt/gates and6errors unchanged, no new predictions. No code/policy/0332 repair, production trust or natural benefit claim; all six targets and parents remain open. Formal release/host/shipped by ops.'});v.write_text(json.dumps(versions,ensure_ascii=False,indent=2)+'\n')
 with (L/'paper/materials/decision-log.md').open('a') as f:f.write('\n- '+at+' H0/r3资源证据入库：source '+S+' → live '+state['merged']+'；六原窗/4 Silent A10局的HP/挡及按ID未消耗牌量相符，沙漏凋萎模板/抽牌与金印供能仍有差；67可见ready窗/32局支持T3/6/9/12凋萎文本逐增3，14unready/1先无牌保留。10既有经验去重合并，12对象真实production fixed-consumer passed；只数据，不造源码测试/校准行，原750/107/481/200/seed/Platt/四闸/6错误及R386/R388/R392/女王窄修保持。源码资源修复/0332协调/六目标低可信/生产trust/F49/自然/H2与宽父均未关闭。正式编号/精确宿主/0513 shipped由ops核。证据 '+str(H/'report.md')+'。\n')
 git('add','--sparse','--','eval/versions.json','paper/materials/decision-log.md');state['publication']=commit('Register H0 resource experience and fixed readback','publication');assert run(['git','merge-base','--is-ancestor',S,'HEAD']).returncode==0;assert git('diff','--name-only',before,state['merged'])==E;save();print(json.dumps(state,ensure_ascii=False))
except BaseException as error:
 state['error']=str(error)
 if run(['git','rev-parse','--verify','MERGE_HEAD'],check=False).returncode==0:git('merge','--abort')
 if state['merged'] and not state['publication'] and git('rev-parse','HEAD')==state['merged']:
  p=run(['git','revert','--no-commit','-m','1',state['merged']],check=False);state['rollback_exit']=p.returncode
  if p.returncode==0:state['failed_merge']=state['merged'];state['rollback_commit']=commit('Revert unqualified H0 resource data, preserving live refresh','rollback');state['merged']=None
 save();raise
finally:fcntl.flock(lock,fcntl.LOCK_UN)

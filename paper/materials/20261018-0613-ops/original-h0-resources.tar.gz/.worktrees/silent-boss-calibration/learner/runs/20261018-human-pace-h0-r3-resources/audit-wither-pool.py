"""Read visible Wither quantities/texts at the previously retained Intensity windows, including unknowns."""
from pathlib import Path
import json,re,hashlib,collections
H=Path(__file__).resolve().parent;P=H.parent/'20261018-human-pace-h0-r3';old=H.parent/'20261017-human-pace-h0-r1';cuts=json.loads((old/'extraction-summary.json').read_text())['cuts'];e=json.loads((P/'intensity-evidence.json').read_text());rows=[]
def read(r):
 assert r['offset']+r['len']<=cuts['logs/states.jsonl']
 with open(r['path'],'rb') as f:f.seek(r['offset']);b=f.read(r['len'])
 assert hashlib.sha256(b).hexdigest()==r['sha256'];return json.loads(b)['state']
def visible(s):
 v=[]
 for c in s['combat']['hand']:
  if c['card_id']=='WITHER':v.append({'pile':'hand','count':1,'text':c['resolved_rules_text']})
 for k in ['draw','discard','exhaust']:
  for x in s['agent_view']['combat'][k]:
   if 'WITHER' in x['card_ids']:
    assert x['card_ids']==['WITHER'];n=int((re.search(r'^[^\[：:]*?\*(\d+)\s*\[',x['line'])or[None,'1'])[1]);v.append({'pile':k,'count':n,'text':x['line']})
 for c in v:
  a=re.search(r'受到(\d+)点伤害',c['text']);c['damage']=int(a[1]) if a else None
 return v
for r in e['rows']:
 a,b=read(r['pre']),read(r['next']);ready=lambda s:s['combat']['action_readiness'].get('can_use_combat_actions')and s['combat']['action_readiness'].get('actions_settled')
 va,vb=visible(a),visible(b);da=set(x['damage'] for x in va);db=set(x['damage'] for x in vb)
 rows.append({'run':r['run'],'key':r['key'],'turn':r['turn'],'pre':r['pre'],'next':r['next'],'command':r['command'],'both_ready':bool(ready(a) and ready(b)),'before':va,'after':vb,'before_damage':sorted(da,key=lambda x:x or -1),'after_damage':sorted(db,key=lambda x:x or -1),'status':'both-visible-single-damage' if len(da)==len(db)==1 and None not in da|db else 'unknown-or-conflicting','scope':'Visible text at retained endpoints, not hook completion/full-order or counterfactual certification.'})
g={}
for r in rows:
 k=str(r['turn']);a=g.setdefault(k,collections.Counter());a['windows']+=1;a['ready']+=r['both_ready'];a['unknown_or_conflicting']+=r['status']!='both-visible-single-damage'
 if r['status']=='both-visible-single-damage':a[str((r['before_damage'][0],r['after_damage'][0]))]+=1
x={'request_id':'roy-20261017-human-pace-h0','revision':3,'source':str(P/'intensity-evidence.json'),'source_sha256':hashlib.sha256((P/'intensity-evidence.json').read_bytes()).hexdigest(),'rows':rows,'summary':g,'missing_original':e['missing'],'counts_are_windows_not_new_independent_calibration_samples':True}
(H/'wither-pool-evidence.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps(g))

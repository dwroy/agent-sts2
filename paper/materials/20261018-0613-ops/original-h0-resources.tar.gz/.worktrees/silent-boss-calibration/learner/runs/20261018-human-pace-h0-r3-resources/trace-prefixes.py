"""Map the six actual observed prefixes, preserving failed commands and actor identities."""
import json,sys,hashlib,collections,re
from pathlib import Path
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;W=H.parents[2];R=Path('/home/dw/Projects/agent-sts2');sys.path.insert(0,str(W/'agent/tools/logdb'));import query,sync
windows=json.loads((H/'resource-windows.json').read_text());cuts=windows['cuts'];rows=[]
with sync.read_lock(str(R/'data/logdb'),shared=True):
 con=query.connect(str(R/'data/logdb'),threads=1)
 for r in windows['rows']:
  f=r['attempt'];frames=[]
  for off,size,ts,fp,t in con.execute('SELECT off,len,ts,fingerprint,turn FROM frames WHERE run_id=? AND off>=? AND off<=? ORDER BY off',[f['run'],f['first_off'],r['endpoint']['offset']]).fetchall():
   assert off+size<=cuts['logs/states.jsonl']
   with (R/'logs/states.jsonl').open('rb') as h:h.seek(off);b=h.read(size)
   raw=json.loads(b);s=raw['state'];assert s['run_id']==f['run'] and s['run']['character_id']=='SILENT'
   frames.append({'ref':{'path':str(R/'logs/states.jsonl'),'offset':off,'len':size,'sha256':hashlib.sha256(b).hexdigest()},'ts':raw['ts'],'fingerprint':fp,'turn':t,'hp':s['combat']['player']['current_hp'],'block':s['combat']['player']['block'],'energy':s['combat']['player']['energy'],'gold':s['run']['gold'],'potions':s['run']['potions'],'hand':[{k:a.get(k) for k in ['index','card_id','upgraded','energy_cost','playable','unplayable_reason']} for a in s['combat']['hand']],'enemies':[{k:a[k] for k in ['index','enemy_id','current_hp','max_hp','is_alive','move_id','powers']} for a in s['combat']['enemies']]})
  commands=[]
  for a in r['fight_command_prefix']:
   d=a['raw'];cs=d['chosen'];matches=[s for s in frames if s['fingerprint']==d['fingerprint'] and s['ts']<=d['ts']];s=matches[-1] if matches else None
   row={'ref':a['ref'],'ts':d['ts'],'turn':d['turn'],'chosen':cs,'result':d.get('result'),'expect':d.get('expect'),'state_ref':s['ref'] if s else None}
   if s and cs['action']=='play_card':row['played_card']=next((c for c in s['hand'] if c['index']==cs['card_index']),None);row['selected_target']=next((e['enemy_id'] for e in s['enemies'] if e['index']==cs.get('target_index')),None)
   if s and cs['action']=='use_potion':row['selected_potion']=next((p for p in s['potions'] if p['index']==cs['option_index']),None)
   commands.append(row)
  events=[];prior=set()
  for i,a in enumerate(frames):
   live={e['enemy_id'] for e in a['enemies'] if e['is_alive']}
   if i and prior-live:events.append({'ref':a['ref'],'turn':a['turn'],'removed_or_dead_ids':sorted(prior-live),'survivor_ids':sorted(live),'scope':'First observed disappearance/death only; not internal timing, unchosen order or causal advantage.'})
   prior=live
  rows.append({'key':f['key'],'boss':r['item']['boss'],'run':f['run'],'attempt':f['attempt'],'floor':f['floor'],'outcome':f['outcome'],'frames':frames,'commands':commands,'observed_actor_removals':events,'scope':'Actual original prefix through the investigated next action; failures remain. No full-fight counterfactual replay or natural improvement claim.'})
 con.close()
(H/'actual-prefix-traces.json').write_text(json.dumps({'request_id':'roy-20261017-human-pace-h0','revision':3,'rows':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'boss':r['boss'],'frames':len(r['frames']),'commands':len(r['commands']),'missing_exact_frames':sum(a['state_ref']is None for a in r['commands']),'removals':r['observed_actor_removals']} for r in rows],ensure_ascii=False))

import hashlib
import json
import subprocess
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((BASE / 'dispatch.json').read_text())
queue = json.loads((BASE / 'queue-snapshot.json').read_text())
sources = json.loads((BASE / 'source-manifest.json').read_text())
verification = json.loads((BASE / 'material-verification.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)

details = [
    {
        'title': '神化升级传播与实际施放归属', 'run': 'VLZ6CCT8AQ0A', 'floor_turn': 'F35 T1；F43 T1—T2；F45 T1',
        'evidence': 's275564→275565：能量7→5、防御5→8，已升级牌不叠加；s275679→275687：同线51伤/13损，T2抽入牌升级。s275728→275730：药水后HP仍67，能量1→2，抽入必备工具/生存者；s275732神化已离手，未建立本战升级。',
        'counterexample': 'F43实际神化后仍全战损57；F45没有施放，不能由持有推出已兑现，也不能由两战胜负推出必打。',
        'covered': 'card-model/turn-solver/rollout已有条件受限的升级传播；silent-apotheosis-reference分列持有与模拟，actual_cast_this_fight仍为null。',
        'reason': '已有神化升级传播；尚缺跨抽牌、选择、用药、重问、SL及换战边界的实际施放归属与完整消费者校准，不能把现有窄实现当整项完成。',
        'next': '用本次固定帧校准已覆盖变换，另需能连接实际派发、状态效果、重问终止与换战重置的固定执行事件；未知升级保持未知，不设必打规则。',
    },
    {
        'title': '三骑士药水预算与全败候选成熟度', 'run': 'VLZ6CCT8AQ0A', 'floor_turn': 'F45 T1/T4/T5',
        'evidence': 'd269748：MC 707ms、1/12，rollout horizon1/samples1/best=null；d269754：MC 12/12、11ms，已是仅剩神化、1能18挡的新指纹，不是同盘预算对照。d269770：攻击候选31损/32伤；实际所选13损/24伤。s275754：32HP/20挡，尖啸后59攻击，完整需损39、差7。',
        'counterexample': 'F45 T4高伤候选没有实打；不能把少8伤认定败因。药水抽样增多与换盘同时发生，不能归因给预算方案。',
        'covered': 'runRandomPotions共享剩余预算，rollout-live已区分退化时钟、抽样死亡与损失封顶；没有据此证明另一预算分配更好。',
        'reason': '缺同起始盘面、同随机池、同总预算的配对实验及候选稳定性曲线；d269748与d269754指纹不同，不能据707ms或样本数直接改预算、护栏或留药。',
        'next': '固定模型覆盖、种子及总计算配额后比较现方案与分阶段方案，记录样本/缺覆盖/退化边界；只在稳定对照支持时改预算。',
    },
    {
        'title': '神化经验来源补链项', 'run': 'VLZ6CCT8AQ0A', 'floor_turn': 'F35 T1；F43 T1—T2；F45 T1',
        'evidence': '与第一项共享原局、账本0237/0238和神化配对；本次核对原经验silent-apotheosis-combat-upgrades与队列Markdown SHA，未增加独立样本。',
        'counterexample': '原Markdown注明与postmortem为同一问题，但同主题关系不证明当前全部验收已在live完成。',
        'covered': '共享第一项已存在的升级传播及参考字段；保留两个原id和各自来源任务。',
        'reason': '与89354805共享原神化证据及已有子实现，但实际施放/后续消费仍未闭环；不能仅因同主题把本id登记duplicate。',
        'next': '沿第一项的实际执行与消费校准补齐，并分别给两个原id关联同一真实live实现依据；不新建重复id。',
    },
    {
        'title': '十五类攻防机制与持续资源分账', 'run': 'VLZ6CCT8AQ0A', 'floor_turn': 'F43 T1—T5；F45 T3—T5及营火资源',
        'evidence': 'F43 T3口红后1敏、步法后合4敏；T4 s275699有12挡/触媒2，下一帧敌177→144，毒实结33；T5直接23与毒45分源。F45后空翻s275751→275752给8挡，防御s275753→275754给12挡，覆甲0；三敌死亡帧仍21/80/77血。',
        'counterexample': '能力层数、未来毒与当前扣血不同；神化、覆甲、敏捷和勒紧不能统一加分，也不能由休息后的败局反推休息错误。',
        'covered': '已有逐击伤害、现场属性、毒触发、临时减力和通用观察数据库入口；不存在本次核实的新公式缺口。原Markdown的strength条目映射0005较宽/不精确，保留原文，未改写原claim。',
        'reason': '本批帧可复核部分即时数值，尚缺十五子项按来源、持续期限、属性组合及战斗/路线/休息消费者共同冻结的生产校准；局部公式正确不证明整项完成。',
        'next': '按十五子项分别列固定输入/输出与实际调用者，避免把同一宽经验支持数当同一公式的样本量；保持当前进阶取值和房间五样本门槛。',
    },
    {
        'title': 'SL与HP护栏候选及执行审计', 'run': '8JRE1C4H4Z2W', 'floor_turn': 'F33首/三试T2，第二试T5，末试T11；F17 T6',
        'evidence': 'd270216/d270282观测指纹相同。首/三试下一轮s276212/s276278为44/32HP、敌316/309，即多损12仅多扣7；d270282的预测死亡是0/24对5/24。d270264护栏候选16→4损，原答43→替线25伤；末试s276433为5HP/22挡，死亡后敌130。',
        'counterexample': '六试都未胜；末试T2防御换线省3少10仍延至T11，反对一概认定防御替换错误。d270264是在后空翻抽牌后的新问题，不能把最初整线当完整执行。',
        'covered': 'silent-selection-audit保存answer/before_sl/after_sl，silent-selection-dispatch保存单动作回执；后者state_effect_verified=false、whole_plan_executed=null，未宣称整线已执行。',
        'reason': '已有候选、差值和单次派发回执；仍缺跨抽牌、选择、重问、用药和SL边界的完整执行认证及成长实际兑现，不把候选预测当已发生收益。',
        'next': '连接同一观测/尝试的实际状态前后帧与重规划截断，固定复核原答、护栏、SL、首次动作和结束原因；无对照不改探索阈值。',
    },
    {
        'title': '力量、弱、敏捷与独立成长联合验证', 'run': 'CA5KE8GFJ9X2', 'floor_turn': 'F13 T2—T5',
        'evidence': 's273252与s273263敌力量4/8、喷水15/19，弱后11/14；s273267玩家2HP/10挡，末轮完整需损4，实损2是零血截断。',
        'counterexample': '本局没有建立计划中的正敏捷；不能拿蚌加压样本同时认证正敏捷或别的属性交互。',
        'covered': '现有伤害逐击/属性与数据库成长路径分开；未发现本批可直接修复并保证联合路径正确的新源码缺口。',
        'reason': '缺力量逐击、正负敏捷、虚弱和独立成长共同覆盖的生产调用校准；CA5本局没有建立正敏捷，不能把单个属性子实现当整条复合经验duplicate。',
        'next': '冻结四类路径各自实见范围和消费者，正敏捷只能使用之后另行核实的本角色证据；不改统一保血/输出权重。',
    },
    {
        'title': '持有、计划与已建立组件分账', 'run': '5PM6JAQG6FNQ', 'floor_turn': 'F39末试T2；F33 T2—T8',
        'evidence': 's274379→s274380：无毒失落35HP、遗忘72HP/8挡完全不变，冒泡耗1能。F33 T2已建立雾3/触媒1/群蛇4，T8获胜。',
        'counterexample': 'F33与F39初始敌人、HP、抽牌和资源不同；已有组件的胜局不能证明F39换启动顺序可胜。',
        'covered': '现有模型区分毒的现有条件及能力建立；计划字段不构成当前战斗已经具备能力的证据。',
        'reason': '已核实无毒空打和持有/建立分离；缺同起始HP、构筑、资源及完整抽序下不同启动顺序的受控整战结果和可复现收益函数，不能拟合启动权重。',
        'next': '保留当前条件检查，固定相同起点/抽序比较启动顺序；未控制的跨战胜负只作限制，不作为胜率提升。',
    },
    {
        'title': '族母吸取、负敏捷、毒与SL边界', 'run': '61E2QS63Y9WU', 'floor_turn': 'F17 T5—T7',
        'evidence': 's273503→s273504：玩家力2→0、敏0→-2，敌力0→2；T6两防御共6牌挡、覆甲3另记，尖啸临减力后17攻击；s273507→s273508敌67→34，17+16毒实结33，玩家56→48。',
        'counterexample': 'sl-attempts本战仅一条attempt1/won/7轮，60血进、48血出；本局没有另一条完整SL胜线可供选择偏好拟合。',
        'covered': '当前属性、临减到期、逐次毒和SL入口均有现存路径，不等于本提案的SL范围收益已校准。',
        'reason': '本战只有首试获胜；缺同起始HP、构筑、资源及完整抽序下另一条完整SL线路和策略比较，不能据首试胜利修改SL阈值或换线偏好。',
        'next': '先固定校准吸取/负敏捷/毒三个分项；若改SL选择，另需完整同盘对照，保留现有阈值。',
    },
    {
        'title': '胧光召唤、航行成长与目标顺序', 'run': '61E2QS63Y9WU', 'floor_turn': 'F23 T1—T5',
        'evidence': 's273582召出21HP幻象；T2/T3/T5幻象力量0/3/6、撞击17/20/23。T4本体和幻象合净扣47，s273595幻象仍2HP；s273593→s273596玩家25→10，T5才退场。',
        'counterexample': 'T4另一focus幻象候选39伤/0损没有实打，不能当后续获胜线路；A0的旧召唤夹具不能冒充本局A10全链。',
        'covered': 'summonsAt/boardRolloutInput/simulateFight已有召唤路径，HP/伤害读取当前进阶首样本；现有测试只是对应子功能。',
        'reason': '已有召唤子实现；尚缺A10召唤、两实体航行成长、幻象复现与退场的完整生产校准，以及另一focus完整后继，不能用旧召唤提交证明排序收益。',
        'next': '按实体id与当前进阶冻结全链，保留全部目标和真实并列；不强制首杀。',
    },
    {
        'title': '熟睡甲虫睡眠、唤醒、眩晕与成长', 'run': 'DUZUBAJ3A8GP', 'floor_turn': 'F30四试T1—T6',
        'evidence': '首试s274906/274914/274919睡3/2/1，s274923醒来；T5力2、尖啸后-4，T6 s274934恢复并成长至4、滚动22。末试s275018初1HP，末轮完整需损6，实损1是截断。',
        'counterexample': '前三试predicted_death，末试died；末试T4相对首试多扣3却多损2，没有受控获胜对照，不能按敌剩血固定改全败排序。',
        'covered': 'turn-solver有slumber逐击唤醒；rollout有asleep状态及后继移动，laterTurnSim去除部分现场标记。源码存在不等于所有sleep/stun边界已对本局校准。',
        'reason': '缺伤害唤醒、睡眠/眩晕接续和当前进阶成长的完整生产校准，以及同抽换序的完整可比较后继；四次失败记录不足拟合固定杀序或输出血价。',
        'next': '分别校准sleep/slumber、受伤唤醒与到期成长，不用通用睡眠分支覆盖未见机制；原失败与截断保持。',
    },
]
assert len(details) == len(queue) == 10
results = []
proposal = [f'# 本批十项策略提案逐项核验\n\n记录时间：{stamp}。\n',
            f'任务 strategy-proposal / silent / 20261018-055621-strategy-proposal；基线 `{base}`。\n',
            '普通队列批；learn.json未带research_request/implementation_request/proposal_repair，research专题身份不匹配，未借用专题请求。原十id、原Markdown和账本都保留，不领取其他提案。\n',
            '证据：八流6995条原始引用；逐行offset/bytes/SHA/JSON/显式归局与输出SHA已校验。六局均silent A10。SL尝试和重复摘取不增加独立局数。\n',
            '以下s/d分别是原logs/states.jsonl与decisions.jsonl的一基行号；完整字节引用见state-facts.jsonl、decision-facts.jsonl与evidence/。\n']
for number, (item, detail) in enumerate(zip(queue, details), 1):
    original = item['original']
    results.append({'id': original['id'], 'state': 'waiting', 'reason': detail['reason']})
    proposal.extend([
        f"\n## {number}. {detail['title']}\n\n",
        f"- 原id：`{original['id']}`；来源任务 `{original['source_task']}`，独立实现任务 `strategy-proposal`。\n",
        f"- 角色/范围：silent A10；证据局 `{detail['run']}`，{detail['floor_turn']}。\n",
        f"- 原账本：{', '.join(original['ledger'])}；原经验：{', '.join(original.get('experience', [])) or '原postmortem提案'}。\n",
        f"- 原Markdown：`{original['proposal']}`；SHA256 `{original['proposal_sha256']}`；逐字保存 `original-proposal-{number:02d}.md`。\n",
        f"- 本批核实：{detail['evidence']}\n",
        f"- 支持范围/反例：{detail['counterexample']}\n",
        f"- 旧规则/当前覆盖：{detail['covered']}\n",
        f"- 处置：**waiting**。{detail['reason']}\n",
        f"- 预期行为与验证：{detail['next']}\n",
        '- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。\n',
        '- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。\n',
        '- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。\n',
    ])
(BASE / 'proposal.md').write_text(''.join(proposal))

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261018-055621-strategy-proposal',
          'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(BASE / 'report.md')}
(BASE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

report = [f'# 本批策略任务报告\n\n记录时间：{stamp}。\n\n',
          '**结果：十项全部waiting；无源码、经验库或对局行为修改，无提交、无合入、无新版本。** 原提案未完成的范围继续等待相应数据/验证，未标implemented、duplicate或shipped。\n\n',
          f'- batch：20261018-055621-strategy-proposal；task/character：strategy-proposal/silent。\n- 初始工作树干净；普通批按要求执行 `git merge --no-edit main`，返回Already up to date。base与最终HEAD均 `{base}`。\n',
          f"- 实际读取live冻结提交 `{sources[0]['live']}`，只读；20个相关源文件的最后改动提交均为其祖先，8个文件与本分支字节不同，未把祖先关系当成整树等价。源码原字节及blob/SHA在source-manifest.json与source/*.txt；initial-diff.patch为空。\n",
          '- learn.json只读本批行：reason=proposal，十个proposal_ids，工作树/角色/runs一致，无proposal_repair/research_request/implementation_request。普通专题文件绑定旧批，故保留普通提案任务；不修改根请求或调度记录。\n',
          '- README、最新STATE-2026-10-18、decision-log末尾、learning-protocol、learning-code-proposals及相关原复盘/本角色经验已读取；未使用其他角色私有知识。\n\n',
          '## 证据与材料核验\n\n',
          '- 六局：' + '、'.join(dispatch['runs']) + '；runs.jsonl全部确认SILENT/A10。逐局身份原件见run-identities.json及evidence/runs.evidence.jsonl。\n',
          '- 共用extract_evidence.py提取八流，原始引用合6995条；每流保存source_size、每行line/offset/bytes/SHA/显式归局和输出SHA。states/decisions/brain各有2条全局无效JSON，均原样记在manifest，不能断言属于本六局。fight-plans在本截点选中0条，只表示未选到；不推断源不存在。\n',
          '- 提取期间另存evidence-small/先核五个小流；其输出SHA与最终主提取相同，不叠加样本。所有引用已按原offset读回、字节SHA/JSON/显式身份核对，输出SHA和计数吻合。\n',
          '- 关键层保存778个状态事实、141个回合首末窗口、693个决策事实。尝试号先按turn回落推断，再与原sl-attempts核对；8JRE F33六试、DUZU F30四试，前三/前五预测死亡截断与最终实际死亡分开；61E F17只有首试实胜。\n',
          '- 15项证据核算通过（material-verification.json）：神化2能/5→8挡/F43同线51伤13损；药水1/12与12/12及不同指纹；SL同指纹的12血/7伤与0/24对5/24；护栏候选16→4；负敏捷与33毒；无毒冒泡空打；蚌成长；幻象未退场；甲虫临减到期后成长。**这些不是生产代码测试，也不是胜率/整战校准。**\n\n',
          '## 逐项处置\n\n| 原id | 证据局/层/回合；账本 | 结果与待补条件 |\n|---|---|---|\n']
for item, detail in zip(queue, details):
    original = item['original']
    report.append(f"| {original['id']} | {detail['run']} {detail['floor_turn']}；{', '.join(original['ledger'])} | waiting：{detail['reason']} |\n")
report.extend([
    '\n逐项证据、反例、既有覆盖、下一验证步骤和回退方法见同目录proposal.md。相同神化主题保留两个原id；没有以同主题或局部提交冒充整项duplicate。\n\n',
    '## 当前源码能证明什么\n\n',
    '- 神化配对表当前提交ba23ca693151fa8c6f7fe035e640dc30f05ccd75、持有/模拟参考字段30ec2425012eea75f41226b31d8180b1abb837bc均为冻结live祖先；字段actual_cast_this_fight=null，不能证明实际施放追溯完整。\n',
    '- 选择候选审计9d8278702dbc581b5015ba7ec9a70dc0fb94cccb及单动作回执fdaf787a372880b0438e73bcac7e6d2168b038ed为冻结live祖先且字节一致；后者state_effect_verified=false、whole_plan_executed=null。它们明确保留未知，不能填成整线兑现。\n',
    '- 召唤/属性/睡眠/成长等已有通用路径；源码存在、历史固定测试存在和本次材料核算均不能替代本批完整生产联合校准。未修改当前进阶首样本HP/伤害规则、房间5样本门槛或任何角色行为。\n\n',
    '## 记录、失败与验证边界\n\n',
    '- 未新增游戏知识或代码提案id，沿用十个CLI登记的原id。账本只通过根learner/ledger.py update追加本报告where/note追溯，不改claim、evidence、prior、first_run、asc、status、version或effect；结果与逐项回执见ledger-update输入/输出及ledger-semantic-check.json。\n',
    '- 无源码修改，撤源码失败/恢复通过不适用；tsc、vitest、cases均null。未运行npm install、游戏/play、LLM、网络、发布或完整生产套件。没有源码提交可登记implemented，没有新版本或shipped；因此跳过live合入和规则双通知。\n',
    '- 材料核验初次运行因scratch脚本错误定位extract_evidence.py而退出1；保留material-verification-initial.log及verify-materials-initial.txt，修正导入路径后r2退出0。初始探索另有误猜源码路径的rg/sed退出2和非战斗combat=null的TypeError，均属只读材料命令，不记成生产测试失败/通过。\n',
    '- 原草稿ledger-before的浅层行合并只供初查，另存ledger-last-row-fields-initial.json；正式账本对照采用ledger.py的真实fold结果，不用浅合并统计支持数或状态。历史复盘、原提案和失败记录没有改写。\n',
    '- 同局重复检查不增加support/repeat或独立样本，不关闭任何学习入库父要求。原映射宽窄差异保持原文，不据此替其他角色确认通知/ACK。gitleaks和最终完整性结果见final-validation.json与gitleaks.log；这是材料检查，不是行为发布验收。\n\n',
    f'交运维：proposal `{BASE / "proposal.md"}`；report `{BASE / "report.md"}`；机器结果 `{BASE / "result.json"}`。十项waiting需保留待新证据/固定校准，不得凭本批结束将父请求关闭。\n',
])
(BASE / 'report.md').write_text(''.join(report))

payloads = []
for ledger_id in sorted({i for entry in queue for i in entry['original']['ledger']}):
    linked = [r['id'] for entry, r in zip(queue, results) if ledger_id in entry['original']['ledger']]
    payloads.append({'id': ledger_id, 'by': 'learner:strategy-proposal',
                     'where': {'proposal': [str(BASE / 'proposal.md'), str(BASE / 'report.md')]},
                     'note': f'20261018-055621-strategy-proposal：原六局同源证据核回；关联原提案{",".join(linked)}本批均waiting，具体缺数据/未完生产校准见report。只补追溯，不新增support/repeat、claim、策略规则或shipped。'})
(BASE / 'ledger-update.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in payloads))
print(json.dumps({'base': base, 'proposal_results': len(results), 'ledger_metadata_updates': len(payloads)}, ensure_ascii=False))

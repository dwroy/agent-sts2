import collections
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
FLOORS = {
    'VLZ6CCT8AQ0A': {35, 36, 37, 43, 45},
    '8JRE1C4H4Z2W': {17, 33},
    'CA5KE8GFJ9X2': {13},
    '5PM6JAQG6FNQ': {33, 39},
    '61E2QS63Y9WU': {17, 23},
    'DUZUBAJ3A8GP': {30},
}


def powers(items):
    return {p['power_id']: p.get('amount') for p in items or []}


def reference(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def state_fact(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    return {
        'ref': reference(item), 'ts': row.get('observed_ts', row.get('ts')),
        'fingerprint': row.get('fingerprint'), 'floor': run.get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'player': {k: player.get(k) for k in ('current_hp', 'max_hp', 'block', 'energy')},
        'powers': powers(player.get('powers')),
        'hand': [{**{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost')},
                  'values': {v['name']: v.get('current_value') for v in c.get('dynamic_values', [])}}
                 for c in combat.get('hand', [])],
        'enemies': [{**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'block', 'is_alive', 'move_id')},
                     'powers': powers(e.get('powers')),
                     'attacks': [{k: i.get(k) for k in ('damage', 'hits', 'total_damage')}
                                 for i in e.get('intents', []) if i.get('damage') is not None]}
                    for e in combat.get('enemies', [])],
        'deck_upgraded': sum(c.get('upgraded') is True for c in run.get('deck', [])),
        'potions': [{k: p.get(k) for k in ('index', 'potion_id')} for p in run.get('potions', [])],
    }


def analyze_states():
    groups = {}
    attempts = collections.defaultdict(lambda: 1)
    previous = {}
    selected = 0
    anchors = {}
    with (BASE / 'state-facts.jsonl').open('w') as out:
        for line in (BASE / 'evidence/states.evidence.jsonl').open():
            if not line.endswith('\n'):
                continue
            item = json.loads(line)
            state = item['row']['state']
            run = item['run_id']
            floor = (state.get('run') or {}).get('floor')
            combat = state.get('combat')
            turn = state.get('turn')
            if floor not in FLOORS[run] or not isinstance(combat, dict) or not isinstance(turn, int) or turn < 1:
                continue
            key = (run, floor)
            if key in previous and turn < previous[key]:
                attempts[key] += 1
            previous[key] = turn
            fact = state_fact(item)
            fact['attempt_inferred_from_turn_reset'] = attempts[key]
            out.write(json.dumps(fact, ensure_ascii=False) + '\n')
            selected += 1
            key = (run, floor, attempts[key], turn)
            if key not in groups:
                groups[key] = {'run': run, 'floor': floor, 'attempt': attempts[(run, floor)],
                               'turn': turn, 'first': fact, 'last': fact, 'frames': 0}
            groups[key]['last'] = fact
            groups[key]['frames'] += 1
            if (275560 <= item['line'] <= 275570 or 275675 <= item['line'] <= 275690
                    or 275720 <= item['line'] <= 275735):
                anchors[str(item['line'])] = fact
    (BASE / 'turn-endpoints.json').write_text(json.dumps(list(groups.values()), ensure_ascii=False, indent=2) + '\n')
    (BASE / 'apotheosis-anchors.json').write_text(json.dumps(anchors, ensure_ascii=False, indent=2) + '\n')
    return {'selected_frames': selected, 'turn_groups': len(groups),
            'attempts_inferred': {f'{r}/F{f}': n for (r, f), n in attempts.items()}}


def analyze_attempts():
    result = []
    for line in (BASE / 'evidence-small/sl-attempts.evidence.jsonl').open():
        item = json.loads(line)
        row = item['row']
        if row.get('floor') not in FLOORS[item['run_id']]:
            continue
        result.append({'ref': reference(item), **{k: row.get(k) for k in
                       ('floor', 'attempt', 'result', 'turns', 'end_hp', 'end_block', 'incoming', 'encounter')},
                       'draws': row.get('draws'), 'explore': row.get('explore'), 'summary': row.get('summary')})
    (BASE / 'attempt-facts.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return [{k: r[k] for k in ('floor', 'attempt', 'result', 'turns', 'encounter')} |
            {'run': r['ref']['run_id']} for r in result]


def main():
    result = {'states': analyze_states(), 'attempts': analyze_attempts()}
    (BASE / 'analysis-summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extractor', BASE.parents[1] / 'extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def verify_extract(directory):
    report = []
    for record in json.loads((directory / 'evidence-manifest.json').read_text()):
        output = directory / (record['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = collections.Counter()
        with (Path('/home/dw/Projects/agent-sts2/logs') / (record['stream'] + '.jsonl')).open('rb') as source:
            for raw in output.open('rb'):
                digest.update(raw)
                item = json.loads(raw)
                assert item['offset'] + item['bytes'] <= record['source_size']
                source.seek(item['offset'])
                original = source.read(item['bytes'])
                assert original.endswith(b'\n')
                assert hashlib.sha256(original).hexdigest() == item['sha256']
                row = json.loads(original)
                assert row == item['row']
                assert extractor.run_identity(row) == item['run_id']
                counts[item['run_id']] += 1
        assert digest.hexdigest() == record['output_sha256']
        assert all(counts[run] == n for run, n in record['counts'].items())
        report.append({'stream': record['stream'], 'source_size': record['source_size'],
                       'rows': sum(counts.values()), 'output_sha256': digest.hexdigest(), 'verified': True})
    return report


def verify_facts():
    states = {r['ref']['line']: r for r in map(json.loads, (BASE / 'state-facts.jsonl').open())}
    decisions = {r['ref']['line']: r for r in map(json.loads, (BASE / 'decision-facts.jsonl').open())}
    endpoints = json.loads((BASE / 'turn-endpoints.json').read_text())
    groups = {(r['run'], r['floor'], r['attempt'], r['turn']): r for r in endpoints}
    checks = []

    def check(name, passed, detail):
        assert passed, name
        checks.append({'name': name, 'passed': True, 'detail': detail})

    def values(line, card_id):
        return next(c['values'] for c in states[line]['hand'] if c['card_id'] == card_id)

    check('神化F35能量', states[275564]['player']['energy'] - states[275565]['player']['energy'] == 2,
          's275564→s275565，7→5；只验证可见支付')
    check('神化F35防御', values(275564, 'DEFEND_SILENT')['Block'] == 5 and values(275565, 'DEFEND_SILENT')['Block'] == 8,
          '同手5→8；不推未知牌升级')
    check('神化F43即时兑现', states[275679]['enemies'][0]['current_hp'] - states[275687]['enemies'][0]['current_hp'] == 51
          and states[275679]['player']['current_hp'] - states[275687]['player']['current_hp'] == 13,
          's275679→s275687同线含直接伤害与敌方结算；51伤/13损，不当整战胜因')
    check('药水题面不同', decisions[269748]['fingerprint'] != decisions[269754]['fingerprint'],
          'd269748与d269754不能当相同起点预算实验')
    first = decisions[269748]['potions']['random'][0]
    second = decisions[269754]['potions']['random'][0]
    check('药水抽样成熟度', (first['samples'], first['requested'], first['ms'], second['samples'], second['requested']) == (1, 12, 707, 12, 12),
          '首问1/12、707ms；后问12/12；不据样本量拟合新预算')
    check('SL同题面', decisions[270216]['fingerprint'] == decisions[270282]['fingerprint'],
          '8JRE首/三试T2观测指纹相同')
    first = groups[('8JRE1C4H4Z2W', 33, 1, 3)]['first']
    third = groups[('8JRE1C4H4Z2W', 33, 3, 3)]['first']
    check('SL实际血价', first['player']['current_hp'] - third['player']['current_hp'] == 12
          and first['enemies'][0]['current_hp'] - third['enemies'][0]['current_hp'] == 7,
          's276212/s276278：44/32HP、敌316/309；同起点47/326，实多损12、多扣7')
    numbers = decisions[270282]['sl_explore']['numbers']
    check('SL预测死亡数不并列', '0/24' in numbers['original'] and '5/24' in numbers['replacement'],
          '同题0/24与5/24不能说成同死亡率；都是预测')
    check('护栏候选血价', decisions[270264]['options']['plan4']['hp_lost'] == 16
          and decisions[270264]['options']['plan6']['hp_lost'] == 4,
          '后空翻抽牌后重问，d270264护栏候选16→4；不能预支全线执行')
    check('族母负敏捷', states[273504]['powers'].get('DEXTERITY_POWER') == -2
          and states[273504]['powers'].get('STRENGTH_POWER', 0) == 0
          and states[273507]['player']['block'] == 6,
          's273504→s273507，两防御合6；覆甲3另列')
    check('族母毒结算', states[273507]['enemies'][0]['current_hp'] - states[273508]['enemies'][0]['current_hp'] == 33,
          '67→34，对应17+16；当前敌方伤害和毒分源')
    check('无毒空打冒泡', states[274379]['player']['energy'] - states[274380]['player']['energy'] == 1
          and states[274379]['enemies'] == states[274380]['enemies'],
          '5PM F39末试T2，s274379→s274380，耗1能，敌状态不变')
    check('蚌成长', states[273252]['enemies'][0]['powers']['STRENGTH_POWER'] == 4
          and states[273263]['enemies'][0]['powers']['STRENGTH_POWER'] == 8,
          'CA5 F13 T3/T5当前力量4/8，不把弱当成长停止')
    check('幻象仍在', states[273595]['enemies'][0]['current_hp'] == 2
          and states[273596]['player']['current_hp'] == 10
          and states[273593]['player']['current_hp'] == 25,
          '61E F23 T4→T5，幻象余2，实损15；未选focus没有后继实打')
    check('甲虫成长接续', states[274929]['enemies'][-1]['powers']['STRENGTH_POWER'] == 2
          and states[274934]['enemies'][-1]['powers']['STRENGTH_POWER'] == 4,
          'DUZU F30首试T5/T6，尖啸到期后继续成长；不造另一排序胜线')
    return checks


report = {'kind': '证据与材料核验，非生产测试',
          'extracts': verify_extract(BASE / 'evidence'),
          'early_small_extracts': verify_extract(BASE / 'evidence-small'),
          'facts': verify_facts()}
(BASE / 'material-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'raw_rows': sum(r['rows'] for r in report['extracts']),
                  'fact_checks': len(report['facts']), 'production_tests': None}, ensure_ascii=False))

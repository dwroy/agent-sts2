# 本批十项策略提案逐项核验

记录时间：2026-10-18 06:11:08 CST。
任务 strategy-proposal / silent / 20261018-055621-strategy-proposal；基线 `22c092400efa0d34c85aebbd1b85ae10db52b5a8`。
普通队列批；learn.json未带research_request/implementation_request/proposal_repair，research专题身份不匹配，未借用专题请求。原十id、原Markdown和账本都保留，不领取其他提案。
证据：八流6995条原始引用；逐行offset/bytes/SHA/JSON/显式归局与输出SHA已校验。六局均silent A10。SL尝试和重复摘取不增加独立局数。
以下s/d分别是原logs/states.jsonl与decisions.jsonl的一基行号；完整字节引用见state-facts.jsonl、decision-facts.jsonl与evidence/。

## 1. 神化升级传播与实际施放归属

- 原id：`silent-proposal-89354805ee4d7e77`；来源任务 `postmortem`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `VLZ6CCT8AQ0A`，F35 T1；F43 T1—T2；F45 T1。
- 原账本：silent-0237, silent-0238；原经验：原postmortem提案。
- 原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md`；SHA256 `ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d`；逐字保存 `original-proposal-01.md`。
- 本批核实：s275564→275565：能量7→5、防御5→8，已升级牌不叠加；s275679→275687：同线51伤/13损，T2抽入牌升级。s275728→275730：药水后HP仍67，能量1→2，抽入必备工具/生存者；s275732神化已离手，未建立本战升级。
- 支持范围/反例：F43实际神化后仍全战损57；F45没有施放，不能由持有推出已兑现，也不能由两战胜负推出必打。
- 旧规则/当前覆盖：card-model/turn-solver/rollout已有条件受限的升级传播；silent-apotheosis-reference分列持有与模拟，actual_cast_this_fight仍为null。
- 处置：**waiting**。已有神化升级传播；尚缺跨抽牌、选择、用药、重问、SL及换战边界的实际施放归属与完整消费者校准，不能把现有窄实现当整项完成。
- 预期行为与验证：用本次固定帧校准已覆盖变换，另需能连接实际派发、状态效果、重问终止与换战重置的固定执行事件；未知升级保持未知，不设必打规则。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 2. 三骑士药水预算与全败候选成熟度

- 原id：`silent-proposal-f2bfceddb1898dca`；来源任务 `postmortem`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `VLZ6CCT8AQ0A`，F45 T1/T4/T5。
- 原账本：silent-0106, silent-0019, silent-0201；原经验：原postmortem提案。
- 原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md`；SHA256 `fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26`；逐字保存 `original-proposal-02.md`。
- 本批核实：d269748：MC 707ms、1/12，rollout horizon1/samples1/best=null；d269754：MC 12/12、11ms，已是仅剩神化、1能18挡的新指纹，不是同盘预算对照。d269770：攻击候选31损/32伤；实际所选13损/24伤。s275754：32HP/20挡，尖啸后59攻击，完整需损39、差7。
- 支持范围/反例：F45 T4高伤候选没有实打；不能把少8伤认定败因。药水抽样增多与换盘同时发生，不能归因给预算方案。
- 旧规则/当前覆盖：runRandomPotions共享剩余预算，rollout-live已区分退化时钟、抽样死亡与损失封顶；没有据此证明另一预算分配更好。
- 处置：**waiting**。缺同起始盘面、同随机池、同总预算的配对实验及候选稳定性曲线；d269748与d269754指纹不同，不能据707ms或样本数直接改预算、护栏或留药。
- 预期行为与验证：固定模型覆盖、种子及总计算配额后比较现方案与分阶段方案，记录样本/缺覆盖/退化边界；只在稳定对照支持时改预算。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 3. 神化经验来源补链项

- 原id：`silent-proposal-283a164780d11e69`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `VLZ6CCT8AQ0A`，F35 T1；F43 T1—T2；F45 T1。
- 原账本：silent-0237, silent-0238；原经验：silent-apotheosis-combat-upgrades。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md`；SHA256 `78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637`；逐字保存 `original-proposal-03.md`。
- 本批核实：与第一项共享原局、账本0237/0238和神化配对；本次核对原经验silent-apotheosis-combat-upgrades与队列Markdown SHA，未增加独立样本。
- 支持范围/反例：原Markdown注明与postmortem为同一问题，但同主题关系不证明当前全部验收已在live完成。
- 旧规则/当前覆盖：共享第一项已存在的升级传播及参考字段；保留两个原id和各自来源任务。
- 处置：**waiting**。与89354805共享原神化证据及已有子实现，但实际施放/后续消费仍未闭环；不能仅因同主题把本id登记duplicate。
- 预期行为与验证：沿第一项的实际执行与消费校准补齐，并分别给两个原id关联同一真实live实现依据；不新建重复id。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 4. 十五类攻防机制与持续资源分账

- 原id：`silent-proposal-ebbfe3b97548756d`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `VLZ6CCT8AQ0A`，F43 T1—T5；F45 T3—T5及营火资源。
- 原账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019；原经验：silent-strength-weak-observation, silent-footwork-block, silent-gorget-plating, silent-vajra-opening-strength, silent-sparkling-rouge-turn-three, silent-fasten-defend-extra-block, silent-piercing-wail-temporary-strength, silent-malaise-x-debuff, silent-accelerant-triggers, silent-noxious-fumes-growth, silent-deck-burst-observation, silent-three-knights-output-buffer-observation, silent-stone-humidifier-rest-growth, silent-rest-buffer-observation, silent-route-hp-observation。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md`；SHA256 `08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2`；逐字保存 `original-proposal-04.md`。
- 本批核实：F43 T3口红后1敏、步法后合4敏；T4 s275699有12挡/触媒2，下一帧敌177→144，毒实结33；T5直接23与毒45分源。F45后空翻s275751→275752给8挡，防御s275753→275754给12挡，覆甲0；三敌死亡帧仍21/80/77血。
- 支持范围/反例：能力层数、未来毒与当前扣血不同；神化、覆甲、敏捷和勒紧不能统一加分，也不能由休息后的败局反推休息错误。
- 旧规则/当前覆盖：已有逐击伤害、现场属性、毒触发、临时减力和通用观察数据库入口；不存在本次核实的新公式缺口。原Markdown的strength条目映射0005较宽/不精确，保留原文，未改写原claim。
- 处置：**waiting**。本批帧可复核部分即时数值，尚缺十五子项按来源、持续期限、属性组合及战斗/路线/休息消费者共同冻结的生产校准；局部公式正确不证明整项完成。
- 预期行为与验证：按十五子项分别列固定输入/输出与实际调用者，避免把同一宽经验支持数当同一公式的样本量；保持当前进阶取值和房间五样本门槛。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 5. SL与HP护栏候选及执行审计

- 原id：`silent-proposal-e5b87be50f28f311`；来源任务 `postmortem`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `8JRE1C4H4Z2W`，F33首/三试T2，第二试T5，末试T11；F17 T6。
- 原账本：silent-0079, silent-0021, silent-0125, silent-0018；原经验：原postmortem提案。
- 原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md`；SHA256 `5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709`；逐字保存 `original-proposal-05.md`。
- 本批核实：d270216/d270282观测指纹相同。首/三试下一轮s276212/s276278为44/32HP、敌316/309，即多损12仅多扣7；d270282的预测死亡是0/24对5/24。d270264护栏候选16→4损，原答43→替线25伤；末试s276433为5HP/22挡，死亡后敌130。
- 支持范围/反例：六试都未胜；末试T2防御换线省3少10仍延至T11，反对一概认定防御替换错误。d270264是在后空翻抽牌后的新问题，不能把最初整线当完整执行。
- 旧规则/当前覆盖：silent-selection-audit保存answer/before_sl/after_sl，silent-selection-dispatch保存单动作回执；后者state_effect_verified=false、whole_plan_executed=null，未宣称整线已执行。
- 处置：**waiting**。已有候选、差值和单次派发回执；仍缺跨抽牌、选择、重问、用药和SL边界的完整执行认证及成长实际兑现，不把候选预测当已发生收益。
- 预期行为与验证：连接同一观测/尝试的实际状态前后帧与重规划截断，固定复核原答、护栏、SL、首次动作和结束原因；无对照不改探索阈值。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 6. 力量、弱、敏捷与独立成长联合验证

- 原id：`silent-proposal-49632bc4878fb597`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `CA5KE8GFJ9X2`，F13 T2—T5。
- 原账本：silent-0005, silent-0231；原经验：silent-strength-weak-observation。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md`；SHA256 `aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2`；逐字保存 `original-proposal-06.md`。
- 本批核实：s273252与s273263敌力量4/8、喷水15/19，弱后11/14；s273267玩家2HP/10挡，末轮完整需损4，实损2是零血截断。
- 支持范围/反例：本局没有建立计划中的正敏捷；不能拿蚌加压样本同时认证正敏捷或别的属性交互。
- 旧规则/当前覆盖：现有伤害逐击/属性与数据库成长路径分开；未发现本批可直接修复并保证联合路径正确的新源码缺口。
- 处置：**waiting**。缺力量逐击、正负敏捷、虚弱和独立成长共同覆盖的生产调用校准；CA5本局没有建立正敏捷，不能把单个属性子实现当整条复合经验duplicate。
- 预期行为与验证：冻结四类路径各自实见范围和消费者，正敏捷只能使用之后另行核实的本角色证据；不改统一保血/输出权重。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 7. 持有、计划与已建立组件分账

- 原id：`silent-proposal-66532328a585941f`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `5PM6JAQG6FNQ`，F39末试T2；F33 T2—T8。
- 原账本：silent-0021, silent-0009；原经验：silent-deck-burst-observation。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md`；SHA256 `56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831`；逐字保存 `original-proposal-07.md`。
- 本批核实：s274379→s274380：无毒失落35HP、遗忘72HP/8挡完全不变，冒泡耗1能。F33 T2已建立雾3/触媒1/群蛇4，T8获胜。
- 支持范围/反例：F33与F39初始敌人、HP、抽牌和资源不同；已有组件的胜局不能证明F39换启动顺序可胜。
- 旧规则/当前覆盖：现有模型区分毒的现有条件及能力建立；计划字段不构成当前战斗已经具备能力的证据。
- 处置：**waiting**。已核实无毒空打和持有/建立分离；缺同起始HP、构筑、资源及完整抽序下不同启动顺序的受控整战结果和可复现收益函数，不能拟合启动权重。
- 预期行为与验证：保留当前条件检查，固定相同起点/抽序比较启动顺序；未控制的跨战胜负只作限制，不作为胜率提升。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 8. 族母吸取、负敏捷、毒与SL边界

- 原id：`silent-proposal-43a76a31ba7bdcfa`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `61E2QS63Y9WU`，F17 T5—T7。
- 原账本：silent-0030, silent-0027；原经验：silent-lagavulin-siphon-poison-sl。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md`；SHA256 `f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c`；逐字保存 `original-proposal-08.md`。
- 本批核实：s273503→s273504：玩家力2→0、敏0→-2，敌力0→2；T6两防御共6牌挡、覆甲3另记，尖啸临减力后17攻击；s273507→s273508敌67→34，17+16毒实结33，玩家56→48。
- 支持范围/反例：sl-attempts本战仅一条attempt1/won/7轮，60血进、48血出；本局没有另一条完整SL胜线可供选择偏好拟合。
- 旧规则/当前覆盖：当前属性、临减到期、逐次毒和SL入口均有现存路径，不等于本提案的SL范围收益已校准。
- 处置：**waiting**。本战只有首试获胜；缺同起始HP、构筑、资源及完整抽序下另一条完整SL线路和策略比较，不能据首试胜利修改SL阈值或换线偏好。
- 预期行为与验证：先固定校准吸取/负敏捷/毒三个分项；若改SL选择，另需完整同盘对照，保留现有阈值。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 9. 胧光召唤、航行成长与目标顺序

- 原id：`silent-proposal-5264153a4a4b0e5c`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `61E2QS63Y9WU`，F23 T1—T5。
- 原账本：silent-0039, silent-0209；原经验：silent-obscura-summon-growth。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md`；SHA256 `b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02`；逐字保存 `original-proposal-09.md`。
- 本批核实：s273582召出21HP幻象；T2/T3/T5幻象力量0/3/6、撞击17/20/23。T4本体和幻象合净扣47，s273595幻象仍2HP；s273593→s273596玩家25→10，T5才退场。
- 支持范围/反例：T4另一focus幻象候选39伤/0损没有实打，不能当后续获胜线路；A0的旧召唤夹具不能冒充本局A10全链。
- 旧规则/当前覆盖：summonsAt/boardRolloutInput/simulateFight已有召唤路径，HP/伤害读取当前进阶首样本；现有测试只是对应子功能。
- 处置：**waiting**。已有召唤子实现；尚缺A10召唤、两实体航行成长、幻象复现与退场的完整生产校准，以及另一focus完整后继，不能用旧召唤提交证明排序收益。
- 预期行为与验证：按实体id与当前进阶冻结全链，保留全部目标和真实并列；不强制首杀。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

## 10. 熟睡甲虫睡眠、唤醒、眩晕与成长

- 原id：`silent-proposal-bddfa690a84e03d0`；来源任务 `experience-update`，独立实现任务 `strategy-proposal`。
- 角色/范围：silent A10；证据局 `DUZUBAJ3A8GP`，F30四试T1—T6。
- 原账本：silent-0128, silent-0079；原经验：silent-slumbering-beetle-wake-growth。
- 原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md`；SHA256 `b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780`；逐字保存 `original-proposal-10.md`。
- 本批核实：首试s274906/274914/274919睡3/2/1，s274923醒来；T5力2、尖啸后-4，T6 s274934恢复并成长至4、滚动22。末试s275018初1HP，末轮完整需损6，实损1是截断。
- 支持范围/反例：前三试predicted_death，末试died；末试T4相对首试多扣3却多损2，没有受控获胜对照，不能按敌剩血固定改全败排序。
- 旧规则/当前覆盖：turn-solver有slumber逐击唤醒；rollout有asleep状态及后继移动，laterTurnSim去除部分现场标记。源码存在不等于所有sleep/stun边界已对本局校准。
- 处置：**waiting**。缺伤害唤醒、睡眠/眩晕接续和当前进阶成长的完整生产校准，以及同抽换序的完整可比较后继；四次失败记录不足拟合固定杀序或输出血价。
- 预期行为与验证：分别校准sleep/slumber、受伤唤醒与到期成长，不用通用睡眠分支覆盖未见机制；原失败与截断保持。
- 拟合/切分：本批原局用于发现与回归，不冒充盲测；按run_id分组，若拟合新规则需后续独立同角色局作时间后移验证。未拟合任何参数。
- 预期影响：只增加可复核的完成边界；实际策略效果未知。后续源码实现须固定数据、撤源码红/恢复绿、原沙箱入口和实际live验收；本批未执行这些生产测试。
- 回退/授权：本批没有源码或规则变更，无需回退。Roy-2026-10-07-learning提供规则修改权限，不提供游戏事实；不能补预训练机制、未知抽牌或整战胜线。

# 本批策略提案核验

记录时间：2026-10-15T04:57:29+08:00。角色 silent；批次 20261015-044302-s2-strategy-proposal；基线 `d0e39af3eba0362213063e14442d77e0bb17968b`。

本批只有10个已领取提案，无research_request、implementation_request或proposal_repair。普通专题文件绑定另一批，未代用；git merge --no-edit main返回Already up to date。原提案SHA逐项一致，原件保存在本scratch的*.original.md；本报告不是原提案改写。

只读取本角色对局和账本；所派十局均由runs.jsonl确认SILENT，进阶为A3、A4、A7、A10，按局分开。UJ0K3G10609Y仅因原提案引用核角色/结束元数据，未把该局未分析机制当本批新增证明。

没有新增源码或经验库变更。以下waiting针对完整提案尚未覆盖的字段、组合或校准范围；已有窄字段与机制不重复实现。缺整战反事实不作为所有纯记录工作的前提，但也不能把已有局部记录冒称完整归属链。

## silent-proposal-43fe170707574455

为群伤与构筑计划提供逐目标退场进度及临时减力边界，避免把群伤存在当已兑现长战输出

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-combat-progress.md
原SHA：`6998cd559e0899056005231af7bbadd3d271513733f6ca28a5f65638e9a9f122`。
账本：silent-0021、silent-0012、silent-0046；来源局：ZTRGYYMLR8SC。
证据定位：ZTRGYYMLR8SC A10 F17末试T1/T5–T9/T14；s292332、292356–292376、292401–292402。
本批处置：**waiting**。已上线同族当前快照与候选血量汇总；原帧退场后序号重排，缺稳定跨帧实体标识及构筑组件从取得到兑现的完整关联，不能把快照登记为全部退场追踪已实现。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`d1713559f2d237a04b681ec6497ce0c8798ae0f0`（kin_snapshot）。该commit不用于关闭其余范围。

## silent-proposal-3f5a665dca133a8c

追踪Jev原答、HP护栏替换与SL最终执行，按局部及整轮分别计算血价和输出代价

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-guard-sl-trace.md
原SHA：`223f0fdd623ff185e4b476a528e5a70a3ce5e99d5733ae5354139ffcd9ac5523`。
账本：silent-0125；来源局：ZTRGYYMLR8SC。
证据定位：ZTRGYYMLR8SC A10 F11T3/F17首试T10/末试T13；d285301、285405、285745。
本批处置：**waiting**。已有护栏、SL前后候选和单动作回执；本批旧日志只有原答、替换说明及局部动作，缺整轮完成状态与方案归属的可靠关联，原候选整战反事实也未执行；单动作回执仍将actual_turn留空。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`（hp_guard）。该commit不用于关闭其余范围。
已覆盖部分的实际live祖先：`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`（selection_audit）。该commit不用于关闭其余范围。
已覆盖部分的实际live祖先：`fdaf787a372880b0438e73bcac7e6d2168b038ed`（selection_dispatch）。该commit不用于关闭其余范围。

## silent-proposal-0b8ef30de463f317

分列药水新增与SL恢复、现场覆甲与后段脆弱，不把早段挡或前战力量当持续战力

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-potion-plating.md
原SHA：`ac20c158f9134f0c139a7a3886d3c26fbb542517b3ebf2e1c2c8078e228cbeb8`。
账本：silent-0013、silent-0277；来源局：ZTRGYYMLR8SC。
证据定位：ZTRGYYMLR8SC A10 F6T3/F17末试T2/T14；d285252、s292342–292344、292401–292402。
本批处置：**waiting**。已有未知持有值及牌挡/覆甲分源；新获、实饮、弃药与SL恢复缺联合生产记录，六次同局SL不提供晚喝或留药对照，不能补持有价或时点阈值。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`c4670f4f416c7d93e192e889c5080e7e4e0e733f`（potion_unknown）。该commit不用于关闭其余范围。

## silent-proposal-5367449b857450a7

核验同族临时减力、脆弱、覆甲与铜钹/刀扇分源覆盖

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-mechanisms.md
原SHA：`2bbe2e854ce6bdb95609f800eb8434cdb05b6be963cfc8ec1870d81d65aee062`。
账本：silent-0012、silent-0013、silent-0046、silent-0149、silent-0277、silent-0284；来源局：ZTRGYYMLR8SC、1LMBFGSMCWKU、9YT51CK8RC39、25226ZFLNR1J、TCFAHJ9K19VY、ULP4TN1GNHMK、61E2QS63Y9WU。
证据定位：ZTRGYYMLR8SC A10 F17末试T5/T6/T14；s292356–292359、292398–292401；原队列另列1LMB/9YT/252/TCF/ULP/61E机制证据。
本批处置：**waiting**。减力、脆弱、覆甲已有部分计算；刀扇本批新证为单敌，铜钹包含滑溜同现的1伤反例，缺多目标/多弃及联合修饰条件的完整调用校准，不能把整组机制标成重复完成。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`d1713559f2d237a04b681ec6497ce0c8798ae0f0`（kin_snapshot）。该commit不用于关闭其余范围。

## silent-proposal-9b8890c2649a2734

保留候选护栏血价、真实执行与同族重打/路线资源链

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-trace.md
原SHA：`ddafc2fed623f77ca9c28eff1309aedb8f1f746e3714756f5b71ee5eb1d97f57`。
账本：silent-0012、silent-0019、silent-0020、silent-0021、silent-0125；来源局：ZTRGYYMLR8SC。
证据定位：ZTRGYYMLR8SC A10 F11T3/F17T10/T13及六次SL；d285301、285405、285745，SL1074–1079。
本批处置：**waiting**。候选护栏与SL阶段记录已有，但原线整战、未走路线及晚喝铁心均无执行证据；当前所选局缺将整轮出口、资源来源与原候选贯通的可靠标识，局部合省10血不能记作整场实得。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`（hp_guard）。该commit不用于关闭其余范围。
已覆盖部分的实际live祖先：`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`（selection_audit）。该commit不用于关闭其余范围。
已覆盖部分的实际live祖先：`fdaf787a372880b0438e73bcac7e6d2168b038ed`（selection_dispatch）。该commit不用于关闭其余范围。

## silent-proposal-645ff7b72e0b9991

按已观察静默A10状态核对零毒蜃景与短推演收益，保留感染先于毒的结算边界；未知收益不得写成已兑现格挡或实赢。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-combat-observed-payoff.md
原SHA：`55cd7445ba3ac32ef6bff153a908a5b729ea6dc7939b84be7ba6712080cd5ace`。
账本：silent-0010、silent-0106、silent-0021、silent-0286；来源局：K2JAGKVJAWZJ、79UCJ0K6R9C1。
证据定位：K2JAGKVJAWZJ A10 F46T1/T6；79UCJ0K6R9C1 A10 F14T3/T6/T10/T11；s293158–293159、293196–293197、293442–293465，d286684。
本批处置：**waiting**。零毒升级蜃景已有窄实现，感染持牌伤已计；79UCJ0K6R9C1 F14T3三案五轮均0/8赢而约76%仅尾端估计，缺估计校准及替代整战胜负，不能据即时伤害改排名。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`5dbb47bfb48d652adfcda2e62c166a804098b6c3`（mirage_zero）。该commit不用于关闭其余范围。

## silent-proposal-68ef2857229d1287

独立核验将静默A10无加量/阻挡条件下毒药水实观加6传播到已观察非双boss战，按感染先于毒结算比较，保留未核组合与饮用时机限制。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-potion-observed-scope.md
原SHA：`f30a8d0b9964ccf0009478cb80065bb5fafc8d6cce81b760bafc7aace1848d6f`。
账本：silent-0278、silent-0286；来源局：K2JAGKVJAWZJ、79UCJ0K6R9C1。
证据定位：K2JAGKVJAWZJ A10 F33首试T10与重开T1；79UCJ0K6R9C1 A10 F14T11；s292940–292942、293463–293465，d286255、286715–286716。
本批处置：**waiting**。两局只实证药水当步加6毒且HP不变；K2同时有包围、弱/脆弱、暗影及后轮格挡，79有感染/扭动虫成长。现有恶魔及蟹的完整条件闸均不匹配，缺这些组合整轮后继校准，保持饮后重读。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`154c9542711a4daf17bfa0b97eaa1ca81dc3d385`（crab_facts）。该commit不用于关闭其余范围。

## silent-proposal-9edfef7a6b2873c2

给路线HP投影保留计划时最大生命、节点与预测来源，逐场关联实盘进出资源、SL恢复及新增敌血池，区别boss时钟与整场模拟。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-resource-projection-provenance.md
原SHA：`d920109bd6d754df32fa941dc4404e979dbcfaaf48db906b85cbc9d77a45cc96`。
账本：silent-0020、silent-0019、silent-0021；来源局：K2JAGKVJAWZJ、79UCJ0K6R9C1。
证据定位：K2JAGKVJAWZJ A10 F31–F46；79UCJ0K6R9C1 A10 F8–F14；bounded-resource-facts.json与run-plans-selected.json。
本批处置：**waiting**。现有路线计划保存比例及节点，但旧日志没有逐节点绝对HP/maxHP与房间成本、休息假设的完整快照；K2上限75→95→91和79实际51血不能从旧比例唯一反推。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。


## silent-proposal-ff1d168227e369e0

核验零毒蜃景升级版与重放/格挡倍率、临时减力和逐击减损分源

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-mechanisms.md
原SHA：`b69ab5987f7e058572c2e42190046ab1f4806712d9939f55db969342df3a34e1`。
账本：silent-0010、silent-0012、silent-0013、silent-0046、silent-0077、silent-0115、silent-0178；来源局：K2JAGKVJAWZJ、10GPK5XGHCK3、UJ0K3G10609Y。
证据定位：K2JAGKVJAWZJ A10 F46T1/T6/T9；s293158–293159、293196–293197、293215–293219；10GPK5XGHCK3为A3背景，UJ0仅核队列角色身份。
本批处置：**waiting**。升级蜃景零毒已有覆盖，爆发重放及逐击减损有局部实帧；缺升级正毒、暗影/重放混合条件的隔离验证，K2三骑士T7额外2损伤源缺帧，不能强行拟合所有回合。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`5dbb47bfb48d652adfcda2e62c166a804098b6c3`（mirage_zero）。该commit不用于关闭其余范围。

## silent-proposal-c64bdd50a949d16f

核验实际能力、药水来源与跨幕回复，保留时点和终局反事实限制

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-resources.md
原SHA：`979e5eb65499c91eed763906c40aa0b50a42b598925021c83c220bef3e7bc658`。
账本：silent-0021、silent-0243、silent-0276、silent-0277、silent-0278；来源局：K2JAGKVJAWZJ。
证据定位：K2JAGKVJAWZJ A10 F15T2/F27T2/F33T10/F17→18；s292584–292585、292788–292789、292940–292942、292656–292657，d286123。
本批处置：**waiting**。能力实建、跨幕回复和药水局部机制有证据，缺持续资源到终局消费者的联合归属与时点反事实；另核实原提案F27T2“已有16挡”与原帧0→0矛盾，勘误待ops→watcher→Roy转交。

旧/新行为：保留现有规则；独立实现目标仍以原提案限定为准，不增统一目标顺序、早喝/留药阈值、SL条件或尾端权重。
验证方法：固定实帧与动作配对、offset/bytes/SHA、角色/进阶和同局SL边界；完整组合与整轮归属须补相应证据，新增源码再作撤源码失败/恢复通过及项目自测。
预期影响及回退：本批只纠正证据范围和追溯，未发布行为变更；无源码回退对象，原文/失败/SL历史保留。

已覆盖部分的实际live祖先：`c4670f4f416c7d93e192e889c5080e7e4e0e733f`（potion_unknown）。该commit不用于关闭其余范围。

## 反例和限制

ZTRG末试T5尖啸后力量0/−3/−3，T6恢复6/3/3；第一信徒在s292362仍1血、下一帧T7已离场且余者重排。仅能给最后存在/首次缺席边界，不能生成T6精确零血帧。末T14玩家4血6挡、神官58血，随后实际死；同局六试不是六局。

K2 F46T1蜃景+耗1能，旧挡16→16，敌血108/97/89不变；T6普通蜃景8毒+2敏实增10挡，反对整类零价值。79 F14T3空过与另两候选五轮均0/8实赢，尾端约76%不等实赢。F14T11先药水4→10毒但敌8血不变，三感染先耗7挡及2HP，GAME_OVER敌仍8血10毒，反对施毒即杀。

K2 F33首试毒42→48、目标54血不变，下一帧SL回62血且原瓶恢复；末试未饮原瓶仍赢，不能推必须喝或必须留。K2跨幕13/70→58/70与SL10→62分列；上限75→95→91不能拿当前分母回填旧路线。

没有拟合新的策略参数。旧局只作事实/边界检查，同局SL同组；后续有完整条件或整轮归属的新同角色完局再时间留出验证。观察记录和候选数不当独立因果样本，未知组合保持现状。

## 必须转告的数字勘误

原第94批资源提案写：K2JAGKVJAWZJ F27T2铁心已有16挡，药后仍16、覆甲0→7。

本批重读s292785–292789与d286120–286124，饮用为d286123；s292788→292789实际格挡0→0、覆甲0→7、HP57→57。原文16挡的数字不受该动作实帧支持。

这是原提案案例数字勘误，不否定铁心建立7覆甲且当步不追补旧挡的限定机制；不改原Markdown、旧复盘、账本claim/first_run/prior或经验。原s292788/s292789已另seek验证SHA，动作d286123与原时间配对；完整五帧五动作保存在k2-f27-contradiction-check.json。

questions.json和notice-source.json保存原观点、不同结论、影响经验/账本、原提案SHA及下一步。交ops沿普通提案来源注册/转发，watcher本人读回后告知Roy；当前仅pending_ops_forwarding，未宣称已送达或代填ACK。


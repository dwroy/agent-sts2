# 静默策略消费回报

时间：2026-10-15T05:01:45+08:00。批次：20261015-044302-strategy-proposal。角色：silent。

完整 base：`d0e39af3eba0362213063e14442d77e0bb17968b`。开工工作树干净，普通批次 `git merge --no-edit main` 返回 Already up to date；没有专题/冻结实现绑定。HEAD保持该base。

结论：已逐项核十份原提案及关联31账本，十项全部 waiting。没有源码/知识修改、提交、live合入、发布版本或shipped。不是纯研究专题，不宣称research_complete，不关闭任何量化父要求。

## 可复核证据

来源局与进阶见 verified-runs.json；本批只统计这十局的silent数据。来源均dirty，不能用当前源码复原历史整树。原提案SHA全部匹配，原文完整留存 original-proposals/。提取由共用 learner/extract_evidence.py 完成，八流各自冻结source_size；manifest、逐行offset/bytes/SHA及计数保存 evidence/。

| 流 | 选中行数 |
|---|---:|
| states | 9019 |
| decisions | 8670 |
| sl-attempts | 71 |
| run-config | 10 |
| run-plans | 70 |
| brain | 445 |
| runs | 10 |
| fight-plans | 0 |

18,295行的原字节SHA、明确局身份、角色、进阶、输出SHA和计数逐项核过。状态/决策/brain原流分别有2/2/1条不可解析行，不把无法定位身份的坏行补成事实；所选行均已回源核。fight-plans选中0行只表示本截点未选到。

## 主要独立核验

- 八局11个抑制窗口基础ID总数均守恒，但全部从T2到T3，缺纯改标瞬时身份/顺序证明。原SL1053—1056四次假插入与clean19/18/19/18保持原记录，不改写它们。详见dampen-windows.json、selected-sl-attempts.json。
- GXN F33 T5 s289986→289987敌214→130、毒29→26且触媒2，局部结84；下一轮毒26→31与另一个HP变化同帧，不能把全部扣血归为毒雾。未建立或未结算收益仍未知。
- PD9 F49末T10 s291336—291342核8→18→19→31→32挡、凋萎2→3→2，23攻击与24持牌伤对32挡需15血，实际3→0。普通单弃已有窄修复，但新增状态实体和选择完成的生产组合回放仍未满足原提案。
- L2九条护栏中只有T2四条SL实际替换；T3三条非空SL记录明确replay.overridden=false。v1误计7、v2纠正4，原失败脚本/JSON不覆盖。末T6 7伤/侧步线五轮死14/24，结束11/24；1200整战样本各零胜，侧步标未建模。末T8有1能但四牌blocked_by_hook，17血对17攻实死；没有可据此新设的攻击优先规则。
- PD9 F48首帧58HP、胜后10、F49首帧仍10；不是跨幕回血样本，也不是不知道连战的源码bug。资源接口存在不代表路线/休息消费者完成校准。

## 现有源码与消费者读回

核定live参考提交为28bec4afac5c6d51e5f1c30de277c1c6575c188b。live-source-ancestry.json确认bf423c173d3be348a4ad714e1d26516df619ff41（普通单弃）、fdaf787a372880b0438e73bcac7e6d2168b038ed（单动作回执）、9d8278702dbc581b5015ba7ec9a70dc0fb94cccb（持牌预测事实）均为live祖先；只承认其实际窄范围，不登记本批任何整项duplicate。source-comparison.json保存九个相关源码blob；draws/card-model与live的差异只有Roy/Dai注释姓名，相关运行逻辑相同，其余七文件逐字节相同。

既有 learner/lib/selection-execution.ts 通过固定输入读回 GXN/YF0L/PD9/L2 四局562片段（116/204/149/93）。共194个轮端点可核，320个未知；完整候选结果字段全为未知。这是消费者的保守契约及观测界限，不把null本身当成游戏机制失败，也不把端点差值当原候选的因果收益。见 execution-consumer-readback.json。

原全流消费者首次拒收6条没有decision_id的map/route-change非动作记录。精确核它们chosen为空且result=route plan changed (no game action)后，仅在消费者视图排除这6条，保存逐行清单execution-consumer-exclusions.json；原八流/原行号及所有实际动作不变，没有排序、补id或删除战斗行。第二次读取exit0。tsx CLI首先因IPC EPERM失败，改用node --import tsx离线loader；两个失败stderr与v1脚本保留。这些均非tsc/vitest或源码撤除测试。

## 逐项处置

| id | 账本 | 处置与缺项 |
|---|---|---|
| silent-proposal-51fa8bc34774f72d | silent-0279, silent-0280 | waiting：八局11窗口均跨T2→T3，只证基础ID总数守恒；缺纯改标瞬时帧、唯一副本身份及同时抽牌/插入/洗牌的抽序证明，不能安全延长SL前缀。 |
| silent-proposal-29b7b36dffbcb017 | silent-0005, silent-0006, silent-0011, silent-0016, silent-0021, silent-0027, silent-0030, silent-0087, silent-0278 | waiting：毒雾/触媒等局部结算已核；覆甲完整减层、阻毒/加量条件和未结算能力的联合消费者回放未齐，提前用药或先能力缺同输入整战对照。 |
| silent-proposal-2631859b524e0652 | silent-0280 | waiting：战内普通文本与场外升级分账成立；11跨轮守恒窗口仍缺物理身份、完整抽序和恢复链，当前普通版本读取不能关闭SL身份修复。 |
| silent-proposal-b13fda1dfeb37927 | silent-0019, silent-0020, silent-0079, silent-0243 | waiting：已有候选快照及单动作回执不足以认证完整资源替线；缺复活逐击未截断损伤、原候选全线执行链及替路线/提前用药整场实果。 |
| silent-proposal-d7b8d36cf3d0303d | silent-0268 | waiting：普通单弃bf423c173d3be348a4ad714e1d26516df619ff41已是live祖先；新增凋萎仍只在终局计数，多选保留未知，缺原开场贯通新实体/选择完成/32挡24持伤23攻击的生产固定回放，整项不能duplicate。 |
| silent-proposal-c873d6543c414f92 | silent-0125, silent-0005, silent-0044, silent-0253 | waiting：九护栏中四次SL撤回已按字段核实；现有单动作回执及四局562片段读回未认证在线候选持续身份、真实前缀/重问父子链与饮药/恢复全链。 |
| silent-proposal-dfbf51502f30c9b1 | silent-0021, silent-0133, silent-0222, silent-0049, silent-0020 | waiting：7伤线五轮死亡14/24高于结束11/24，侧步未建模且三条整战均零胜；缺同抽序完整替线、侧步兑现观测和后期独立验证，不据即时伤害改排序。 |
| silent-proposal-c2888032d1337388 | silent-0005, silent-0006, silent-0011, silent-0016, silent-0023, silent-0024, silent-0027, silent-0049, silent-0083, silent-0094, silent-0133, silent-0222, silent-0253, silent-0276, silent-0282 | waiting：现场力敏/余像/仪式/荆棘等局部证据保留；十五账本全部入口仍缺覆甲完整减层、力量/滚石及换战未结算组合的生产固定消费者回放，不能以子模型存在关闭整项。 |
| silent-proposal-042ee2299084b528 | silent-0019, silent-0020, silent-0021, silent-0090, silent-0228, silent-0239, silent-0243 | waiting：PD9首Boss58→10且下一Boss10血接续已核；现有接口仍缺真实血药/复活全链到路线与休息消费者的联合校准，以及未选整场路线/用药对照。 |
| silent-proposal-8cd3db3bad5f34f1 | silent-0021, silent-0133, silent-0222, silent-0228, silent-0239 | waiting：四局562片段有观测端点但完整候选实果保持未知；缺在线候选持续身份、重问后全线执行和原线整场反事实，有限全死不足以放宽SL必死边界。 |

每项的证据局号/层/回合、原行号、反例、旧/拟议行为、预期影响、验证与回退方法见同目录proposal.md；原来源任务保留，不另建重复提案。

## 账本、测试和交接

只通过根目录learner/ledger.py update追加31条by=learner:strategy-proposal的本批提案/报告链接，原proposed保持proposed，已shipped经验原状态保持，不替ops登记shipped、不覆盖原where/evidence。CLI回执及逐条读回见ledger-update-receipts.txt / ledger-update-readback.json；全账本check为482项、0问题。未调用新提案add，code_proposals沿用十个真实CLI id。

无源码提交，tsc/vitest/cases及撤源码失败/恢复通过均为null/不适用；没有运行完整测试，也没有借用历史测试成功。无提交，提交前gitleaks不适用。未执行live锁/合并/版本/上线双通知，不运行play、不联网、不推送。源码和全部knowledge相对base零差异，最终git status为空，scratch均在本批learner/runs下。根账本31条追溯追加由ops按既有流程封存。

过程限制：第一次角色核对误用小写精确比较，按实际SILENT只规范大小写后十局通过；一次过宽夹具rg返回了其他角色的片段，未进入本批证据或结论，随后严格限定具体文件，原始证据与统计全部经过silent身份验证。宿主bubblewrap两次因并行回收工作树的全局glob失败，在命令实际执行前拒绝；未改权限或环境。所有初稿、错误、原件留存。

本批无新规则、无与旧知识冲突的新结论；现有不足不能变成收益证明。下一步须补各项具体缺帧/条件/消费者输入与独立验证，不把批次完成当父要求完成。

交运维：proposal.md、report.md、result.json；根队列/learn.json未修改，由调用方消费proposal_results。

## 最终JSON

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261015-044302-strategy-proposal",
  "base": "d0e39af3eba0362213063e14442d77e0bb17968b",
  "runs": [
    "GXNKW8X1XYJP",
    "ZE8F192FKX24",
    "2PVLGRBGUX9S",
    "DPYF2BAA3DKT",
    "UMVLWER4CD98",
    "VLZ6CCT8AQ0A",
    "VN7RQJMJEFMX",
    "YF0LXT1QSTGG",
    "PD9AYQVMLQW6",
    "L2TSFU62Z57Z"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-51fa8bc34774f72d",
    "silent-proposal-29b7b36dffbcb017",
    "silent-proposal-2631859b524e0652",
    "silent-proposal-b13fda1dfeb37927",
    "silent-proposal-d7b8d36cf3d0303d",
    "silent-proposal-c873d6543c414f92",
    "silent-proposal-dfbf51502f30c9b1",
    "silent-proposal-c2888032d1337388",
    "silent-proposal-042ee2299084b528",
    "silent-proposal-8cd3db3bad5f34f1"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-51fa8bc34774f72d",
      "state": "waiting",
      "reason": "八局11窗口均跨T2→T3，只证基础ID总数守恒；缺纯改标瞬时帧、唯一副本身份及同时抽牌/插入/洗牌的抽序证明，不能安全延长SL前缀。"
    },
    {
      "id": "silent-proposal-29b7b36dffbcb017",
      "state": "waiting",
      "reason": "毒雾/触媒等局部结算已核；覆甲完整减层、阻毒/加量条件和未结算能力的联合消费者回放未齐，提前用药或先能力缺同输入整战对照。"
    },
    {
      "id": "silent-proposal-2631859b524e0652",
      "state": "waiting",
      "reason": "战内普通文本与场外升级分账成立；11跨轮守恒窗口仍缺物理身份、完整抽序和恢复链，当前普通版本读取不能关闭SL身份修复。"
    },
    {
      "id": "silent-proposal-b13fda1dfeb37927",
      "state": "waiting",
      "reason": "已有候选快照及单动作回执不足以认证完整资源替线；缺复活逐击未截断损伤、原候选全线执行链及替路线/提前用药整场实果。"
    },
    {
      "id": "silent-proposal-d7b8d36cf3d0303d",
      "state": "waiting",
      "reason": "普通单弃bf423c173d3be348a4ad714e1d26516df619ff41已是live祖先；新增凋萎仍只在终局计数，多选保留未知，缺原开场贯通新实体/选择完成/32挡24持伤23攻击的生产固定回放，整项不能duplicate。"
    },
    {
      "id": "silent-proposal-c873d6543c414f92",
      "state": "waiting",
      "reason": "九护栏中四次SL撤回已按字段核实；现有单动作回执及四局562片段读回未认证在线候选持续身份、真实前缀/重问父子链与饮药/恢复全链。"
    },
    {
      "id": "silent-proposal-dfbf51502f30c9b1",
      "state": "waiting",
      "reason": "7伤线五轮死亡14/24高于结束11/24，侧步未建模且三条整战均零胜；缺同抽序完整替线、侧步兑现观测和后期独立验证，不据即时伤害改排序。"
    },
    {
      "id": "silent-proposal-c2888032d1337388",
      "state": "waiting",
      "reason": "现场力敏/余像/仪式/荆棘等局部证据保留；十五账本全部入口仍缺覆甲完整减层、力量/滚石及换战未结算组合的生产固定消费者回放，不能以子模型存在关闭整项。"
    },
    {
      "id": "silent-proposal-042ee2299084b528",
      "state": "waiting",
      "reason": "PD9首Boss58→10且下一Boss10血接续已核；现有接口仍缺真实血药/复活全链到路线与休息消费者的联合校准，以及未选整场路线/用药对照。"
    },
    {
      "id": "silent-proposal-8cd3db3bad5f34f1",
      "state": "waiting",
      "reason": "四局562片段有观测端点但完整候选实果保持未知；缺在线候选持续身份、重问后全线执行和原线整场反事实，有限全死不足以放宽SL必死边界。"
    }
  ],
  "proposal": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-044302/learner/runs/20261015-044311-strategy-proposal/proposal.md",
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-044302/learner/runs/20261015-044311-strategy-proposal/report.md"
}
```

from pathlib import Path
import json,subprocess,hashlib,sys,fcntl
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1547';pub=r/'paper/materials/20261015-1547-publication';d=json.loads((pub/'publication.json').read_text());at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True);updates=[]
for item,ids in [(d['flask'],['silent-0295','silent-0007']),(d['opening'],['silent-0255','silent-0228'])]:
 for ident in ids:
  updates.append({'id':ident,'by':'ops:codex','where':{'commits':[item['source'],item['behavior_commit'],d['actual_live']]},'note':f'{at} {item["release_id"]}/{item["name"]}原source子项已实际main/live祖先并在ops/live-merge.lock核号；实际live{d["actual_live"]}/tree{d["tree"]}。仅补代码实际发布来源，不改已有经验status/version/claim/证据或support/repeat；药瓶原整套exit1的两15s超时同精确树定向2过/tsc0，开场源完整4069过/撤码3失败恢复8过。新组合原144302宿主一次已请求、结果与自然消费者待验，宽提案/学习父不关闭，保原失败和所有并行知识。回执paper/materials/20261015-1547-publication/。'})
ledger=r/'paper/materials/learning/ledger.jsonl';before=ledger.stat().st_size;(pub/'ledger-input.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in updates));rc=subprocess.run(['python3','learner/ledger.py','update','--character','silent'],input=(pub/'ledger-input.jsonl').read_text(),text=True,capture_output=True);(pub/'ledger-update.log').write_text(rc.stdout+rc.stderr);assert rc.returncode==0;rows=[]
for raw in ledger.read_bytes()[before:].splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('by')=='ops:codex' and 'paper/materials/20261015-1547-publication/' in row.get('note',''):rows.append(raw)
assert len(rows)==4 and all(set(json.loads(x))<=set(['op','id','ts','by','where','note']) for x in rows);(p/'owned-ledger.jsonl').write_bytes(b''.join(rows))
original=json.loads((r/'paper/materials/20261015-1538-opening-combo/batch-readback.json').read_text())['original_report'];follow=json.loads(json.dumps(original));follow['merged']=d['actual_live'];follow['version']=d['opening']['release_id'];follow['ops_actual_publication']=str((pub/'publication.json').relative_to(r))
for row in follow['proposal_results']:
 if row['id']=='silent-proposal-1f34e9d37b21ba71':row['reason']=f'原ebf8c57e开场完整组合子项已实际live并登记{d["opening"]["release_id"]}，源自测4069与负控3失败恢复8过；原宽项留药/休息/路线联合结局仍缺受控样本，保持waiting。精确新组合宿主和自然消费者独立待验，不以窄子项关闭宽父。'
(pub/'ops-publication-followup.json').write_text(json.dumps(follow,ensure_ascii=False,indent=2)+'\n');sys.path.insert(0,str(r/'ops'));import proposal_dispatch
with (r/'ops/codex-ops/learn.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);state=json.loads((r/'ops/codex-ops/learn.json').read_text());bid=original['batch'];b=state['batches'][bid];ids=set(b['proposal_ids']);owners=[key for key,v in state['batches'].items() if key!=bid and v.get('state')=='running' and ids & set(v.get('proposal_ids',[]))];core={k:b.get(k) for k in ['state','rc','merged','report','finished','pid']}
 if not owners:assert not proposal_dispatch.links(follow,b,str(r),str(r/'ops'));proposal_dispatch.resolve(follow,b,str(r),str(r/'ops'));stage='original four old duplicate/six waiting mechanical resolution, broad1f34 kept waiting with actual narrow publication linked'
 else:stage='same original resolution pending overlapping active owner; input not hot-replaced'
 actual=json.loads((r/'ops/codex-ops/learn.json').read_text())['batches'][bid];assert {k:actual.get(k) for k in core}==core
(pub/'registration-followup.json').write_text(json.dumps({'at':at,'actual_official_releases':[d['flask']['release_id'],d['opening']['release_id']],'ledger_cli_rows':4,'only_where_note':True,'old_status_and_experience_versions_preserved':True,'original_batch_completion_unchanged':core,'queue_stage':stage,'overlapping_running_owners':owners,'no_new_parent_task_or_model':True,'wide_original_proposal':'waiting, not closed by narrow source','natural_consumer':'pending'},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'releases':[d['flask']['release_id'],d['opening']['release_id']],'ledger_rows':4,'queue':stage}))

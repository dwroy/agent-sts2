from pathlib import Path
import json,subprocess,hashlib,os,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1547';pub=r/'paper/materials/20261015-1547-publication';d=json.loads((pub/'publication.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE).decode().strip()
assert git('rev-parse','HEAD')==d['main'];assert git('rev-parse','HEAD',cwd=r/'.worktrees/live')==d['actual_live'];assert git('rev-parse','HEAD^{tree}',cwd=r/'.worktrees/live')==d['tree'];assert git('diff','--name-only',d['old_live'],d['actual_live'],'--','knowledge',cwd=r/'.worktrees/live')=='';assert git('diff','--name-only',d['old_main'],d['main'])=='eval/versions.json';changes=git('diff','--name-only',d['old_live'],d['actual_live'],cwd=r/'.worktrees/live').splitlines();assert set(changes)=={'eval/versions.json',*[x['path'] for x in d['opening']['source_leaves']]}
for checkout in [r,r/'.worktrees/live']:
 q=json.loads((checkout/'eval/versions.json').read_text())
 for item in [d['flask'],d['opening']]:
  entry=[x for x in q['versions'] if x['name']==item['name']];mapping=[x for x in q['release_numbering']['releases'] if x['commit']==item['behavior_commit']];assert len(entry)==len(mapping)==1 and entry[0]['release_id']==mapping[0]['release_id']==item['release_id'];git('merge-base','--is-ancestor',item['source'],'HEAD',cwd=checkout)
now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();req=json.loads((pub/'new-host-request.json').read_text());inode=str((r/'ops/live-merge.lock').stat().st_ino);holders=[]
for line in Path('/proc/locks').read_text().splitlines():
 fields=line.split()
 for i,x in enumerate(fields):
  if x.count(':')==2 and x.split(':')[-1]==inode:
   pid=int(fields[i-1]);proc=Path('/proc')/str(pid);v={'pid':pid,'waiting':'->' in fields}
   try:
    raw=(proc/'stat').read_text();v.update(birth=raw[raw.rfind(')')+2:].split()[19],comm=(proc/'comm').read_text().strip(),cwd=os.readlink(proc/'cwd'));paths=[]
    for fd in (proc/'fd').iterdir():
     try:path=os.readlink(fd)
     except FileNotFoundError:continue
     if path in [str(r/'ops/live-merge.lock'),req['expected_log']]:paths.append(path)
    v['exact_open_paths']=paths
   except FileNotFoundError:v['exited_during_readback']=True
   holders.append(v)
log=Path(req['expected_log']);actual=[x for x in holders if not x['waiting'] and req['expected_log'] in x.get('exact_open_paths',[])];stage='actual host owns original live lock and exact combined-tree log; result pending' if actual else 'actual broker request started, host start still pending';started={'at':now,'actual_live':d['actual_live'],'exact_tree':d['tree'],'original_batch':req['original_batch'],'request':req,'lock_readback':holders,'stage':stage,'vitest_RUN_observed':log.exists() and ' RUN ' in log.read_text(),'new_full_requests':1,'result':'pending; no prior-tree full pass borrowed'};(pub/'new-host-start.json').write_text(json.dumps(started,ensure_ascii=False,indent=2)+'\n')
files=list(p.glob('*.py'));rows=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tf:
 for f in files:
  raw=f.read_bytes();dest=p/'helper-scan'/f.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tf.add(f,arcname=f.name);rows.append({'source':str(f.relative_to(r)),'archive':f.name,'sha256':sha(raw)})
(pub/'ops-helper-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(pub/'actual-deployment-readback.json').write_text(json.dumps({'at':now,'main':d['main'],'live':d['actual_live'],'tree':d['tree'],'source_ancestors_main_live':True,'exact_live_changes':changes,'main_changed_only_version_registry':True,'knowledge_refresh_preserved':True,'P2_C2_on_not_deployed':True,'registry_names_ids_and_commit_match':True,'original_flask_full_failure_and_supplement':'separate, unchanged','old_canonical_reports':'unchanged','natural_consumers':'pending; current game not restarted','final_host':started},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'at':now,'live_verified':True,'releases':[d['flask']['release_id'],d['opening']['release_id']],'new_host_stage':stage,'RUN_observed':started['vitest_RUN_observed']}))

from pathlib import Path
import subprocess,json,hashlib,os,re,fcntl
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261015-1547';pub=r/'paper/materials/20261015-1547-publication';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r,env=None,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],env=env,input=data,stderr=subprocess.PIPE)
def blob(head,path,cwd=r):
 v=subprocess.run(['git','-C',str(cwd),'show',head+':'+path],capture_output=True);assert v.returncode in [0,128];return v.stdout if v.returncode==0 else None
def stage(path,raw,env,cwd):
 oid=git('hash-object','-w','--stdin',cwd=cwd,data=raw).decode().strip();git('update-index','--add','--cacheinfo','100644',oid,path,cwd=cwd,env=env)
def commit(tree,parents,title,cwd):
 args=['commit-tree',tree]
 for parent in dict.fromkeys(parents):args+=['-p',parent]
 return git(*args,cwd=cwd,data=(title+'\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n').encode()).decode().strip()
def install(cwd,path,raw):
 f=cwd/path;tmp=f.with_name(f.name+'.ops-publication.tmp');assert not tmp.exists();tmp.write_bytes(raw);os.replace(tmp,f)
assert not (pub/'publication.json').exists();opening=json.loads((r/'paper/materials/20261015-1538-opening-combo/batch-readback.json').read_text());source=opening['source'];flask='8c1935b9c672c5e9fdd676371e16988a8f0bc714';flasksource='0bf701b583e905fcde2bc6d9b5ec1bc0d1131332';h=(p/'manifest-sha.txt').read_text().strip();suppath=r/'ops/codex-ops/learner'/f'20261015-141302-strategy-proposal.supplement-{h}.json';supp=json.loads(suppath.read_text());assert supp['state']=='completed';assert opening['source_checks']['retry']['exit']==0 and opening['source_checks']['retry']['vitest_tests']==4069
with (r/'ops/live-merge.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(now,flush=True);mh=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip();assert lh==supp['live']['commit'];git('merge-base','--is-ancestor',flask,lh);git('merge-base','--is-ancestor',source,mh);git('merge-base','--is-ancestor',flasksource,mh)
 for cwd in [r,live]:assert not git('diff','--cached','--name-only',cwd=cwd).strip() and not git('ls-files','-u',cwd=cwd).strip()
 values={}
 for row in opening['leaves']:
  path=row['path'];old=blob(lh,path,live);assert old==blob(opening['parent'],path);assert ((live/path).read_bytes() if (live/path).exists() else None)==old;desired=blob(source,path);assert sha(desired)==row['sha256'] and (r/path).read_bytes()==desired;values[path]=desired;dest=p/'composition-scan'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(desired)
 refresh={}
 for path in git('diff','--name-only','HEAD','--','knowledge',cwd=live).decode().splitlines():
  raw=(live/path).read_bytes();refresh[path]=raw;dest=p/'composition-scan'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 with (pub/'composition-gitleaks.log').open('wb') as log:rc=subprocess.run(['nice','-n','19','gitleaks','dir',str(p/'composition-scan'),'--redact','--no-banner','--report-format','json','--report-path',str(p/'composition-gitleaks.json')],env={**os.environ,'GOMAXPROCS':'2'},stdout=log,stderr=subprocess.STDOUT).returncode
 assert rc==0 and json.loads((p/'composition-gitleaks.json').read_text())==[]
 datasets={};mapping={};sequence={}
 for cwd,head in [(r,mh),(live,lh)]:
  raw=blob(head,'eval/versions.json',cwd);physical=(cwd/'eval/versions.json').read_bytes()
  if physical!=raw:
   # Adopt only the already-live learner's exact pending row; preserve every other byte/value.
   assert cwd==r
   expected=json.loads(raw);actual_live=json.loads(blob(lh,'eval/versions.json',live));pending=[x for x in actual_live['versions'] if x['name']=='V5.silent-flask-certainty1'];assert len(pending)==1 and pending[0]['commit']==flask and pending[0].get('release_id') is None;assert not any(x['name']==pending[0]['name'] for x in expected['versions']);expected['versions'].append(pending[0]);assert json.loads(physical)==expected and physical==(json.dumps(expected,ensure_ascii=False,indent=2)+'\n').encode();raw=physical
  data=json.loads(raw);datasets[str(cwd)]=data
  for row in data['release_numbering']['releases']:
   n=int(re.fullmatch(r'V\d+-R(\d+)',row['release_id'])[1]);assert n not in sequence or sequence[n]==row['commit'];sequence[n]=row['commit']
   if row['commit'] in mapping:assert mapping[row['commit']]['release_id']==row['release_id'];mapping[row['commit']]['aliases']=list(dict.fromkeys(mapping[row['commit']]['aliases']+row['aliases']))
   else:mapping[row['commit']]=json.loads(json.dumps(row))
 assert set(sequence)==set(range(max(sequence)+1)) and flask not in mapping;flask_id=f'V5-R{max(sequence)+1:03d}';opening_id=f'V5-R{max(sequence)+2:03d}';flaskname='V5.silent-flask-certainty1';openingname='V5.silent-opening-combinations1';mapping[flask]={'release_id':flask_id,'commit':flask,'aliases':[flaskname]}
 le={**os.environ,'GIT_INDEX_FILE':str(p/'live.index')};git('read-tree',lh,cwd=live,env=le)
 for path,raw in refresh.items():stage(path,raw,le,live)
 rt=git('write-tree',cwd=live,env=le).decode().strip();fresh=commit(rt,[lh],'Preserve live knowledge refresh before observed opening combination',live) if refresh else lh
 for path,raw in values.items():stage(path,raw,le,live)
 bt=git('write-tree',cwd=live,env=le).decode().strip();assert set(git('diff','--name-only',rt,bt,cwd=live).decode().splitlines())==set(values);behavior=commit(bt,[fresh,source],'Publish bounded observed Silent opening combinations',live);mapping[behavior]={'release_id':opening_id,'commit':behavior,'aliases':[openingname]};ordered=sorted(mapping.values(),key=lambda x:int(x['release_id'].split('-R')[1]));entry={'name':openingname,'family':'V5','character':'SILENT','commit':behavior,'release_id':opening_id,'release_status':'registered-primary-ops','source':f'{now}; original strategy20261015-144302 source {source}, original wide proposal1f34e9d37b21ba71 opening-combination subitem only, ledger silent-0255/0228. AD3QSC3P41JU Silent A10 F39/45/46/48/49 pre-action observed4HP loss; admit only the two exact observed complete11/13 relic sets for fresh fight and same-sample continuation. Preserve original TXZ branch, observed/SL boards not charged again, other roles/ascensions/missing/extra/duplicate/melted/automatic combinations unchanged. No potion/HP/SL/route/terminal weight change. Source tsc0/sandbox432files4069 and same fixed withdrawal3fail/restored8pass; first parallel tmp ENOENT and fixture error retained. Four exact leaves applied with all parallel knowledge/main P2/C2-on preparation preserved outside live. Exact final combined host and natural consumer pending; no victory/independent holdout or broad proposal/parent closure. Rollback only these four source/test leaves; preserve other releases and refreshed knowledge. Evidence paper/materials/20261015-1547-publication/.'};versionbytes={}
 for key,data in datasets.items():
  oldversions=json.loads(json.dumps(data['versions']));matches=[x for x in data['versions'] if x['name']==flaskname];assert len(matches)==1 and matches[0]['commit']==flask and matches[0].get('release_id') is None;matches[0]['release_id']=flask_id;matches[0]['release_status']='registered-primary-ops';assert not any(x['name']==openingname for x in data['versions']);data['versions'].append(entry);data['release_numbering']['releases']=ordered
  for old,new in zip(oldversions,data['versions']):
   for field in ['name','family','commit','source']:assert old.get(field)==new.get(field)
  versionbytes[key]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
 stage('eval/versions.json',versionbytes[str(live)],le,live);ft=git('write-tree',cwd=live,env=le).decode().strip();final=commit(ft,[behavior],f'Register {flask_id} and bind opening combination to {opening_id}',live);me={**os.environ,'GIT_INDEX_FILE':str(p/'main.index')};git('read-tree',mh,env=me);stage('eval/versions.json',versionbytes[str(r)],me,r);mt=git('write-tree',env=me).decode().strip();mn=commit(mt,[mh],f'Record actual Flask and opening releases {flask_id}/{opening_id}',r)
 intended={'at':now,'source':source,'old_main':mh,'main':mn,'old_live':lh,'refresh_commit':fresh,'refresh':[{ 'path':path,'sha256':sha(raw)} for path,raw in refresh.items()],'flask':{'source':flasksource,'behavior_commit':flask,'release_id':flask_id,'name':flaskname,'original_full_rc':1,'supplement_rc':supp['rc'],'supplement_exact_tree':supp['live']['tree']},'opening':{'source':source,'behavior_commit':behavior,'behavior_tree':bt,'release_id':opening_id,'name':openingname,'source_full':4069,'source_leaves':opening['leaves']},'actual_live':final,'tree':ft,'main_tree':mt,'current_game_restart':False,'P2_C2_prepared_on_main_only':True,'old_registry_names_source_history_and_order_preserved':True,'host_final_combination':'not requested yet; must use original144302 channel once','natural_consumer':'pending, no restart','original_reports_and_canonical_failures':'preserved'};(p/'intended-publication.json').write_text(json.dumps(intended,ensure_ascii=False,indent=2)+'\n');locks=[]
 try:
  for cwd,env in [(r,me),(live,le)]:
   idx=Path(git('rev-parse','--git-path','index',cwd=cwd).decode().strip()).resolve();lp=Path(str(idx)+'.lock');fd=os.open(lp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
   with os.fdopen(fd,'wb') as out:out.write(Path(env['GIT_INDEX_FILE']).read_bytes());out.flush();os.fsync(out.fileno())
   locks.append((idx,lp))
  assert git('rev-parse','HEAD').decode().strip()==mh and git('rev-parse','HEAD',cwd=live).decode().strip()==lh
  for path,raw in refresh.items():assert (live/path).read_bytes()==raw
  git('update-ref','-m','ops: register actual Flask and publish bounded opening combination','HEAD',final,lh,cwd=live)
  for path,raw in values.items():install(live,path,raw)
  install(live,'eval/versions.json',versionbytes[str(live)]);git('update-ref','-m','ops: register actual live release ids only','HEAD',mn,mh);install(r,'eval/versions.json',versionbytes[str(r)])
  for idx,lp in locks:os.replace(lp,idx)
 finally:
  for idx,lp in locks:
   if lp.exists():lp.unlink()
 for cwd in [r,live]:
  assert not git('diff','--cached','--name-only',cwd=cwd).strip()
  for src in [source,flasksource]:git('merge-base','--is-ancestor',src,'HEAD',cwd=cwd)
 for path,raw in values.items():assert (live/path).read_bytes()==raw
 (pub/'publication.json').write_text(json.dumps(intended,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'published':True,'flask_id':flask_id,'opening_id':opening_id,'live':final,'tree':ft,'main':mn,'refresh_files':len(refresh)}),flush=True)

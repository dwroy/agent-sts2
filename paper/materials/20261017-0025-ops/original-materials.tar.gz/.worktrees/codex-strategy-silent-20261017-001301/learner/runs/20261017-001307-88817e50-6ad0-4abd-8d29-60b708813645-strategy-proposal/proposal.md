# 静默猎手十项已派提案复核

记录：2026-10-17 00:23:03 CST；batch=20261017-001301-strategy-proposal。

基线：7504ec5dc74cc1758de390ae40a48b5602a867ce。本批仅消费已领取的十个原ID，全部waiting；没有新的游戏规则、源码或知识修改。这是逐项保留原提案及缺口的报告，不将局部已实现功能登记成整项完成。原始Markdown均按原SHA保存为各ID的.md.txt。

## silent-proposal-9952ee8e8df9a0fe

SL零胜率换线须显式核即时血价和击杀推进，路线/营火实际回复与存档恢复分账；证据不足保留门槛

来源任务：experience-update；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0019, silent-0020, silent-0065, silent-0264, silent-0079。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-resources.md；SHA256：4641badee4b0dfb956e91f12e20e20a5ecbc5c31905f8e0c84da1429de4d9800。

证据：NHA2KW0RB7VP，A10 F33第1/6试T1—T2；sl-attempts:987/992。同30血入口，斗篷线实损1、敌净扣8；回响线实损7、敌净扣24，即多损6血、多输出16。F33T2六次同条件转向的取整观察归silent-0264，不外推通用取整公式。

处置：waiting。即时损血及SL资源比较已有live子实现；缺同抽序、同预算、同后继的整战对照和路线、留药受控后继，不足修改SL门槛或终局权重。

反例与限制：增加输出和增加损血同时发生，六次均属同一局；全败不证明替线一般劣于原线，也不证明能力无价值。未走路线、保药和营火选择没有同条件结局。

旧/预期行为：保持原门槛，将当前血价、已结输出、击杀、能力建立及未来收益分账；未抵达营火和SL存档恢复不当已兑现治疗。

验证方法：固定同指纹两线并统一预算，保存真实动作、抽弃及整战后继；按原局分组、按结束时间留出独立验证。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:283390；offset=8742837488；bytes=38108；SHA256=453d854a6774d8752d888698b34064ac8508d6123ca8d7f8d0572173dc9c1ac8
- states:283409；offset=8743657393；bytes=43264；SHA256=55cb76f7dc2a50ac21c7d72350aedc478d64d0862352fcb5d0a6b663f9435c01

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-47be799a87af03be

静默已观察单张弃牌题核对正在执行计划、逐敌来袭和每个合法弃牌分支，保留未实打的反事实限制

来源任务：postmortem；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0205。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-011301-postmortem/proposal-discard-plan.md；SHA256：25870eb9a6d5482193ebe5f06d7071794e13bc8a43f293d8bcdfb7700377b6e1。

证据：P74C04AEPL1F，A10 F23第4试T3；decisions:278542—278546，states:284817/284818/284821。生存者后1血16挡，Jev以0.52信心弃精确切击，重算预计余血−7，卵毒后剩2、玩家归零。

处置：waiting。弃牌计划提示和候选手牌快照已有live子实现；缺动态牌面、弃牌触发、目标和续步剩血的完整合法分支核证，未隔离新数值失配。

反例与限制：首/第三试T3卵已经离场，第四试仍3血；不是同盘面对照。保留精确切击的整条分支未实打，其手牌依赖伤害不能按弃牌前7点常数延用。

旧/预期行为：全部合法选项继续供Jev选择，明确删除原后继的影响；弃牌后重新读取费用、牌面和目标，未知分支保留未知。

验证方法：逐候选核当前费用、触发、动态牌面、逐敌来袭和剩血；保留精确切击的替代线只可标模拟，不声称转胜。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:284817；offset=8793375668；bytes=43511；SHA256=ad5e11a024408f863152dd11a2e801a40c1153e08d434dfbc15f0034e00c80ed
- states:284818；offset=8793419179；bytes=39015；SHA256=de72a2f359bd539b45c3ce0852e8d158cf67c11066b94d6c19650b8b52eacdce
- states:284821；offset=8793533365；bytes=36574；SHA256=30b5d31b9746f289d03799080464ea9037fc018ef23a00e96646c0b42ad1f5d2

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-3a5274da3c42672a

核证多敌失衡与召唤复活、一次格挡翻倍、滑溜下火焰／毒与普通触媒兑现，保留获胜战到下一战的真实资源和缺帧限制

来源任务：postmortem；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-011301-postmortem/proposal-group-resource.md；SHA256：6ae654a5dabe769d49545bf1f10fb61e82539939c4cca5acfa20e518cf19cf05。

证据：P74C04AEPL1F，A10 F17T1火焰只扣1且滑溜8→7（states:284630/631）；T2的12毒两结只扣2、滑溜6→4（284635/636）。F22T2/T4实损20/24；寄生0→21（284748/749），53血进战、奖励9血、下场F23仍9（284730/761/766）。F23末T3石虫眩晕与卵杀掉玩家同时成立。

处置：waiting。已有局部模型；缺主怪最后死亡中间来源帧及药水、复活、逐敌失衡到下战资源的联合消费者核证，未定位新源码差额。

反例与限制：284760主怪尚15血，284761奖励帧仅剩归零寄生，缺主怪末次归零的来源中间帧；净血差不是完整需伤。赢战后低血不证明杀序错误，全场受伤也不否定石虫失衡。

旧/预期行为：逐敌、逐来源核一次触发、毒结算和下战真实入口；药面值与实际扣血分列，缺失死亡来源不补写。

验证方法：固定复算火焰/滑溜/触媒、F22复活与两轮损血、F23逐敌失衡，补完整来源及联合消费者后再认证整项。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:284630；offset=8786693552；bytes=33269；SHA256=dba2e6f0ec51cd2418d53cccab9c715238fcbd08476cb3d210d745580f8c9868
- states:284631；offset=8786726821；bytes=33020；SHA256=291b55fa1221a6ed68a25c0fe3492f53f8de4e8f2b437ae4bb7663d6b1fe5b2a
- states:284635；offset=8786858370；bytes=31472；SHA256=dc8c4310b457676a735c026cb83309e98e29beb04bb2b3de340c9a3462a8e428
- states:284636；offset=8786889842；bytes=33729；SHA256=bee2a939fc076cb636c1491f0b386015a6f894e6924d45456b2012fe7e331876
- states:284748；offset=8790670724；bytes=35613；SHA256=3336e663f6400fa3f53bce301deff74d4cf47157dd90bdf9c6edc3ff8810fd37
- states:284749；offset=8790706337；bytes=38511；SHA256=4041f0eb51dfa56657191446b4b3833ed3a764869d4cef69a94c21f1c5aca182
- states:284760；offset=8791110150；bytes=39802；SHA256=56b02d6ea3d7f2555aad78338b98c0b3f0aab0f6ed363b00de5ba18f26d91dfb
- states:284761；offset=8791149952；bytes=27717；SHA256=9e4bd7e2990295f54f50a83acefbe4c02042260438a59301776a841695b63365

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-bc4b92d590f2c4ce

保留投斧首牌顺序身份、弃牌后重核计划和能力实际兑现；候选与完整实线分账

来源任务：experience-update；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-014012-experience-update/proposal-replay.md；SHA256：d99922d67f03f38fdf7a3df2a604a1be63a3d0bf1b98f3f2f4d6d42e58f29725。

证据：G33HU22H2543，A10 F48T1，decisions:277909/277954/278032，投斧首牌余像/闪亮登场候选的旧键相同而挡/伤不同；silent-0266首证保留。F48末T8两敌毒实扣22/42（states:284407/408）。P74C04AEPL1F F23末T3弃精确切击后原后继取消。

处置：waiting。投斧首牌身份、普通单弃和计划提示已有live窄实现；跨重规划执行归属、余像累计收益与动态弃牌的联合验证仍缺，不能整项duplicate。

反例与限制：余像先的候选未完整实打，补能力层数不等于补回首牌机会；不能由候选差异推出必先能力或整战必胜。

旧/预期行为：保留已观察的首牌身份；分别核已执行前缀、重问后继、实际能力建层和兑现。

验证方法：覆盖首牌未消费/已消费/缺前缀、药水及宽松判重，再将能力和弃牌的完整真实后继配对。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:284407；offset=8781012914；bytes=48737；SHA256=81c524705ac0b486fb00caac52ec619a84f2df050540fb16c0b3d556077f543b
- states:284408；offset=8781061651；bytes=44201；SHA256=fb18c71d7430b749989d9aa041fa393f4bcf4aafe22cffa58b689f7f23ab44bb

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-f52fbbab4dccc3b4

按赢战资源消耗与下一场实入口核路线/SL/終局价值，存档恢复与真实回复分账

来源任务：experience-update；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-014012-experience-update/proposal-resources.md；SHA256：f6212ce1983f6d534fde0e56f7d3151fd4cb248a5413e4abdfdd9125421ed630。

证据：P74C04AEPL1F，A10 F22T1—T6由53到9，F23仍9血空药（states:284730/761/766）。G33HU22H2543 F48末T8毒扣22/42后仍死；F31千足虫、F32休息、F33赢战、F47休息的原资源链按原提案引用，未重算全历史。

处置：waiting。缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的受控后继；赢战耗血成立，不能据此拟合新HP价格或留药阈值。

反例与限制：未到F24营火不算治疗；F22虽赢不代表消耗合理，但也不能由F23失败倒推另一路线可赢。没有保药/另路线完整胜局。

旧/预期行为：保持当前路线/资源规则；实际治疗、事件付血、开场、饮药、复活及SL恢复逐笔分别核账。

验证方法：连续两战真实入口与消耗配对，补同入口同后继的路线、休息或用药对照，不把观察分档当因果血价。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:284730；offset=8789987459；bytes=32994；SHA256=8187931ac7ec6056bae0066c3750ccbbf98107b47e4954accd6776a2ff8424db
- states:284761；offset=8791149952；bytes=27717；SHA256=9e4bd7e2990295f54f50a83acefbe4c02042260438a59301776a841695b63365
- states:284766；offset=8791308002；bytes=35841；SHA256=4f15770460288179d78d9c09f11e0dbabb7b1d9968f1ed94c4b76e949b76bfb6

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-10f37c0edd3d24a6

逐来源核临时减力、双重毒结算、牌挡/被动挡/翻倍、开场遗物及实际回复

来源任务：experience-update；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-014012-experience-update/proposal-mechanisms.md；SHA256：705dcdc07bf49426c7a645ce77875e8526cccca1e059eb1561472617611b8e52。

证据：P74C04AEPL1F，A10 F17T2尖啸敌力−6、T3恢复0（states:284634/636），12毒在滑溜下两结只扣2；F23T3生存者16挡未挡卵8，石仍眩晕。G33HU22H2543 F48T8两敌毒扣22/42。开场遗物、实际休息总额沿原提案已分项保存的证据引用。

处置：waiting。缺当时dirty知识及移动表原字节，也缺临时减力、毒多结算、一次格挡、开场和回复的完整组合联合回放及独立校准；未发现新可隔离失配。

反例与限制：run-config有完整源码commit、dirty_files及知识前缀SHA，不等于保存了当时dirty数据；当前知识不能替代旧运行输入。临时负力和未来毒雾不能提前计入。

旧/预期行为：保留局部已实现模型及未知边界；一次翻倍、被动挡、临时力量和未执行能力不重复或提前计价。

验证方法：冻结真实运行源码和知识/移动表输入，再逐来源对齐当轮和后续轮；未知组合不由预训练知识补齐。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:284634；offset=8786826190；bytes=32180；SHA256=55659327397563f7dc69cf5a209dd8b8b2c3321bd5e70b92d1eaec2dc644926f
- states:284635；offset=8786858370；bytes=31472；SHA256=dc8c4310b457676a735c026cb83309e98e29beb04bb2b3de340c9a3462a8e428
- states:284636；offset=8786889842；bytes=33729；SHA256=bee2a939fc076cb636c1491f0b386015a6f894e6924d45456b2012fe7e331876
- states:284817；offset=8793375668；bytes=43511；SHA256=ad5e11a024408f863152dd11a2e801a40c1153e08d434dfbc15f0034e00c80ed
- states:284821；offset=8793533365；bytes=36574；SHA256=30b5d31b9746f289d03799080464ea9037fc018ef23a00e96646c0b42ad1f5d2
- states:284407；offset=8781012914；bytes=48737；SHA256=81c524705ac0b486fb00caac52ec619a84f2df050540fb16c0b3d556077f543b
- states:284408；offset=8781061651；bytes=44201；SHA256=fb18c71d7430b749989d9aa041fa393f4bcf4aafe22cffa58b689f7f23ab44bb

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-3f82387e2e179703

双蟹同盘SL用触媒替打击实少7伤、多损4HP，全败推演并列不当同安全；先核弃牌后可达朝向与能力兑现，缺整战控制及独立验证时保留旧排序、等待新证据。

来源任务：postmortem；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0079, silent-0027, silent-0065, silent-0080, silent-0088。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-014304-postmortem/proposal-sl-power-cost.md；SHA256：8bdf5f3c4ef752be9a4d494397f8214fc58e524f6a8c682c1a3be41bb791eab3。

证据：RC61MFQM63Y6，A10 F33首/末T1，sl-attempts:1007/1012，decisions:279021/279197。同指纹52血，喝同一格挡药；原实损4/净扣30，触媒替线实损8/净扣23，少7输出、多损4血。实际首/末题推演预算分别3轮2样本、5轮24样本。

处置：waiting。同盘即时少7输出、多损4血已核；缺同预算整战、累计能力收益和受控后继，不足修改全败SL排序或增加固定HP惩罚。

反例与限制：触媒3+2毒确有兑现；同题候选均24/24死亡不能扩大成两次真实决策同预算。后轮抽弃和动作不同，无整战受控胜线。

旧/预期行为：保持SL门槛；分别展示当前血价、输出和能力已建/已结收益，死亡统计饱和不当即时等价。

验证方法：统一同指纹、同预算及后继条件再核完整执行；先移除生存者实际弃掉的后继攻击，再比较朝向。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:285314；offset=8807031421；bytes=32686；SHA256=ec59ffd31a05c8abf852b60d27ea7bec6fca2c9a8442018e8f726572eaca4589
- states:285321；offset=8807299168；bytes=38156；SHA256=96b238e5d19240b383a0be1a15790b805fc73e07e266bd5154abf89e8f1b89ff
- states:285491；offset=8813669317；bytes=41053；SHA256=4c76021c76c407b01d65f9274af021403644853c4f2b4270237d6ee4a890eb83
- states:285497；offset=8813904745；bytes=38055；SHA256=0e866abce9b6b2d1ccfbf49632c072998216149b9165f8164d488e2a3f01d38a

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-aee21084c991abd3

核对醒虫力量、临时虚弱、覆甲及抽弃后实际执行线的长程推演；单局3/4样本线死亡不足校准权重或规定焦点，保留原行为并交独立任务验证。

来源任务：postmortem；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0128。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-024302-postmortem/proposal-awake-beetle-validation.md；SHA256：b5cb54be4191c956c90c7604bd5180350c139bb8c2bab3e035f8104277186d78。

证据：BTSRF7JL1W1Y，A10 F31T3—T4；decisions:279852/279854为抽弃前/后两个不同目标计划，分别3轮4样本和5轮4样本。states:286164/286170甲虫力量2→4；286173为14血、5牌挡、1覆甲对22，286174毒后甲虫13血、玩家0。

处置：waiting。缺逐样本轨迹与最终执行线的配对校准；抽弃前后状态和目标已变，一条3/4样本候选发生死亡不足证明模型错误或调整权重。

反例与限制：末轮1覆甲不能漏计，5牌挡不是全部防护；本战未建立灵动步法。一次死亡不证明75%纯bug，也不支持固定先杀甲虫。

旧/预期行为：保持既有成长及排序；原候选、抽弃后候选、实际执行、醒后力量与防护分别核对。

验证方法：按实体身份核睡层、醒后力量、虚弱恢复、覆甲和毒，再保存最终执行线的逐样本轨迹并按独立局校准。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:286164；offset=8834597902；bytes=43477；SHA256=2ca3427ed2174dc572b813a28ab85675c7f01b4f70630508e6241e92320f9cc8
- states:286170；offset=8834855098；bytes=41863；SHA256=bba04d8248dd7b04cfabc07f03561147dc5e294a8876bf3c0054bdb6aa479af5
- states:286173；offset=8834981179；bytes=41116；SHA256=4d9c6799915f698fa6bfd29dc6797c3c77f75048049b813e4f335c26a77b95cf
- states:286174；offset=8835022295；bytes=36563；SHA256=f365c7845109492851c1bc31a24fc708f6689b4d2667bcb40ace35fb4f1bd731

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-df37594e9b12debf

强制单弃后取消后继攻击/转向；SL能力换线同时核即时血价与实际结算窗口

来源任务：experience-update；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-replay.md；SHA256：cee2c39a9643248c6df74fbaade8613c2b9fb8fb57952fa060311b7edb98fc44。

证据：RC61MFQM63Y6，A10 F33第3试T4；states:285414只生存者/打击，285415手空，45血7挡对57激光，原后继朝火箭攻击没执行。首/末T1血价差额另见t1-comparisons.json。F17T11呼唤自损按原提案引用，未冒本批新增该窗口核算。

处置：waiting。普通生存者唯一后继取消已有live祖先覆盖；跨选择整线归属、累计能力与呼唤自损的联合消费者仍未验收，不能用窄修复关闭整项。

反例与限制：第3试T4判死后未执行末攻击，不能写成真实损50；没有可保留的第二张牌时不虚构弃牌选择。持牌自损与毒终结必须分来源。

旧/预期行为：保留唯一单弃消费及多选未知；实际持牌损血、候选成长与真正结算分开，取消不能兑现的攻击/朝向。

验证方法：先核普通单弃删除攻击和转向，再配对跨选择完整真实动作、呼唤持牌及毒终结的先后来源。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:285414；offset=8810794180；bytes=35691；SHA256=84b3997ed3b4051b8c353d847922d19be9c4441e26718426cea246c311a5868a
- states:285415；offset=8810829871；bytes=34063；SHA256=4e43fcb163847f6e6d495fb292115012436e83854094a559fb8f1afc10509bee

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

## silent-proposal-42e81c83b2e1e56b

路线/休息按已兑现回复与赢战耗血核血价；存档恢复不等真实回血

来源任务：experience-update；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。账本：silent-0019, silent-0020。授权Roy-2026-10-07-learning不提供游戏事实。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-resources.md；SHA256：9c9880e7b14f3e685556000992e98c20627afc63b12e7b1a359a82367c6a0a01。

证据：RC61MFQM63Y6，A10 F33首/末T1实际入口52血，states:285314/285491及sl-attempts:1007/1012。F27投影与实入口、五火105/餐券30/幕间54/SL197按原保存提案引用，本批未重算这些全局金额。

处置：waiting。缺同条件路线、休息、后战对照及逐来源消费者验收；52血实入口与原回复账不足建立新安全血线或终局HP价格。

反例与限制：投影和实入口不同不自动定位模型缺陷，途中的构筑和事件条件可能变化；五次SL恢复同瓶药不能当新得药，其他路线没有实打结局。

旧/预期行为：保持当前路线、休息及HP价；只有实际完成的回复计到账，未来营火与存档恢复另列。

验证方法：按同构筑、敌人、间隔和资源条件逐来源核入口，另取路线/休息/留药完整后继，不用不同局观察拟因果阈值。 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。

代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：

- states:285314；offset=8807031421；bytes=32686；SHA256=ec59ffd31a05c8abf852b60d27ea7bec6fca2c9a8442018e8f726572eaca4589
- states:285491；offset=8813669317；bytes=41053；SHA256=4c76021c76c407b01d65f9274af021403644853c4f2b4270237d6ee4a890eb83

回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。

import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261017-001301-strategy-proposal'
BASE = '7504ec5dc74cc1758de390ae40a48b5602a867ce'
assigned = json.loads((HERE / 'assigned-proposals.json').read_text())
dispatch = json.loads((HERE / 'dispatch.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
audit = json.loads((HERE / 'evidence-audit.json').read_text())
assert source['base'] == BASE
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE).decode().strip() == BASE
assert subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=WORKTREE) == b''
timestamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z']).decode().strip()

items = [
    {
        'id': 'silent-proposal-9952ee8e8df9a0fe',
        'evidence': 'NHA2KW0RB7VP，A10 F33第1/6试T1—T2；sl-attempts:987/992。同30血入口，斗篷线实损1、敌净扣8；回响线实损7、敌净扣24，即多损6血、多输出16。F33T2六次同条件转向的取整观察归silent-0264，不外推通用取整公式。',
        'reason': '即时损血及SL资源比较已有live子实现；缺同抽序、同预算、同后继的整战对照和路线、留药受控后继，不足修改SL门槛或终局权重。',
        'counterexamples': '增加输出和增加损血同时发生，六次均属同一局；全败不证明替线一般劣于原线，也不证明能力无价值。未走路线、保药和营火选择没有同条件结局。',
        'expected': '保持原门槛，将当前血价、已结输出、击杀、能力建立及未来收益分账；未抵达营火和SL存档恢复不当已兑现治疗。',
        'validation': '固定同指纹两线并统一预算，保存真实动作、抽弃及整战后继；按原局分组、按结束时间留出独立验证。',
        'lines': [283390,283409],
    },
    {
        'id': 'silent-proposal-47be799a87af03be',
        'evidence': 'P74C04AEPL1F，A10 F23第4试T3；decisions:278542—278546，states:284817/284818/284821。生存者后1血16挡，Jev以0.52信心弃精确切击，重算预计余血−7，卵毒后剩2、玩家归零。',
        'reason': '弃牌计划提示和候选手牌快照已有live子实现；缺动态牌面、弃牌触发、目标和续步剩血的完整合法分支核证，未隔离新数值失配。',
        'counterexamples': '首/第三试T3卵已经离场，第四试仍3血；不是同盘面对照。保留精确切击的整条分支未实打，其手牌依赖伤害不能按弃牌前7点常数延用。',
        'expected': '全部合法选项继续供Jev选择，明确删除原后继的影响；弃牌后重新读取费用、牌面和目标，未知分支保留未知。',
        'validation': '逐候选核当前费用、触发、动态牌面、逐敌来袭和剩血；保留精确切击的替代线只可标模拟，不声称转胜。',
        'lines': [284817,284818,284821],
    },
    {
        'id': 'silent-proposal-3a5274da3c42672a',
        'evidence': 'P74C04AEPL1F，A10 F17T1火焰只扣1且滑溜8→7（states:284630/631）；T2的12毒两结只扣2、滑溜6→4（284635/636）。F22T2/T4实损20/24；寄生0→21（284748/749），53血进战、奖励9血、下场F23仍9（284730/761/766）。F23末T3石虫眩晕与卵杀掉玩家同时成立。',
        'reason': '已有局部模型；缺主怪最后死亡中间来源帧及药水、复活、逐敌失衡到下战资源的联合消费者核证，未定位新源码差额。',
        'counterexamples': '284760主怪尚15血，284761奖励帧仅剩归零寄生，缺主怪末次归零的来源中间帧；净血差不是完整需伤。赢战后低血不证明杀序错误，全场受伤也不否定石虫失衡。',
        'expected': '逐敌、逐来源核一次触发、毒结算和下战真实入口；药面值与实际扣血分列，缺失死亡来源不补写。',
        'validation': '固定复算火焰/滑溜/触媒、F22复活与两轮损血、F23逐敌失衡，补完整来源及联合消费者后再认证整项。',
        'lines': [284630,284631,284635,284636,284748,284749,284760,284761],
    },
    {
        'id': 'silent-proposal-bc4b92d590f2c4ce',
        'evidence': 'G33HU22H2543，A10 F48T1，decisions:277909/277954/278032，投斧首牌余像/闪亮登场候选的旧键相同而挡/伤不同；silent-0266首证保留。F48末T8两敌毒实扣22/42（states:284407/408）。P74C04AEPL1F F23末T3弃精确切击后原后继取消。',
        'reason': '投斧首牌身份、普通单弃和计划提示已有live窄实现；跨重规划执行归属、余像累计收益与动态弃牌的联合验证仍缺，不能整项duplicate。',
        'counterexamples': '余像先的候选未完整实打，补能力层数不等于补回首牌机会；不能由候选差异推出必先能力或整战必胜。',
        'expected': '保留已观察的首牌身份；分别核已执行前缀、重问后继、实际能力建层和兑现。',
        'validation': '覆盖首牌未消费/已消费/缺前缀、药水及宽松判重，再将能力和弃牌的完整真实后继配对。',
        'lines': [284407,284408],
    },
    {
        'id': 'silent-proposal-f52fbbab4dccc3b4',
        'evidence': 'P74C04AEPL1F，A10 F22T1—T6由53到9，F23仍9血空药（states:284730/761/766）。G33HU22H2543 F48末T8毒扣22/42后仍死；F31千足虫、F32休息、F33赢战、F47休息的原资源链按原提案引用，未重算全历史。',
        'reason': '缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的受控后继；赢战耗血成立，不能据此拟合新HP价格或留药阈值。',
        'counterexamples': '未到F24营火不算治疗；F22虽赢不代表消耗合理，但也不能由F23失败倒推另一路线可赢。没有保药/另路线完整胜局。',
        'expected': '保持当前路线/资源规则；实际治疗、事件付血、开场、饮药、复活及SL恢复逐笔分别核账。',
        'validation': '连续两战真实入口与消耗配对，补同入口同后继的路线、休息或用药对照，不把观察分档当因果血价。',
        'lines': [284730,284761,284766],
    },
    {
        'id': 'silent-proposal-10f37c0edd3d24a6',
        'evidence': 'P74C04AEPL1F，A10 F17T2尖啸敌力−6、T3恢复0（states:284634/636），12毒在滑溜下两结只扣2；F23T3生存者16挡未挡卵8，石仍眩晕。G33HU22H2543 F48T8两敌毒扣22/42。开场遗物、实际休息总额沿原提案已分项保存的证据引用。',
        'reason': '缺当时dirty知识及移动表原字节，也缺临时减力、毒多结算、一次格挡、开场和回复的完整组合联合回放及独立校准；未发现新可隔离失配。',
        'counterexamples': 'run-config有完整源码commit、dirty_files及知识前缀SHA，不等于保存了当时dirty数据；当前知识不能替代旧运行输入。临时负力和未来毒雾不能提前计入。',
        'expected': '保留局部已实现模型及未知边界；一次翻倍、被动挡、临时力量和未执行能力不重复或提前计价。',
        'validation': '冻结真实运行源码和知识/移动表输入，再逐来源对齐当轮和后续轮；未知组合不由预训练知识补齐。',
        'lines': [284634,284635,284636,284817,284821,284407,284408],
    },
    {
        'id': 'silent-proposal-3f82387e2e179703',
        'evidence': 'RC61MFQM63Y6，A10 F33首/末T1，sl-attempts:1007/1012，decisions:279021/279197。同指纹52血，喝同一格挡药；原实损4/净扣30，触媒替线实损8/净扣23，少7输出、多损4血。实际首/末题推演预算分别3轮2样本、5轮24样本。',
        'reason': '同盘即时少7输出、多损4血已核；缺同预算整战、累计能力收益和受控后继，不足修改全败SL排序或增加固定HP惩罚。',
        'counterexamples': '触媒3+2毒确有兑现；同题候选均24/24死亡不能扩大成两次真实决策同预算。后轮抽弃和动作不同，无整战受控胜线。',
        'expected': '保持SL门槛；分别展示当前血价、输出和能力已建/已结收益，死亡统计饱和不当即时等价。',
        'validation': '统一同指纹、同预算及后继条件再核完整执行；先移除生存者实际弃掉的后继攻击，再比较朝向。',
        'lines': [285314,285321,285491,285497],
    },
    {
        'id': 'silent-proposal-aee21084c991abd3',
        'evidence': 'BTSRF7JL1W1Y，A10 F31T3—T4；decisions:279852/279854为抽弃前/后两个不同目标计划，分别3轮4样本和5轮4样本。states:286164/286170甲虫力量2→4；286173为14血、5牌挡、1覆甲对22，286174毒后甲虫13血、玩家0。',
        'reason': '缺逐样本轨迹与最终执行线的配对校准；抽弃前后状态和目标已变，一条3/4样本候选发生死亡不足证明模型错误或调整权重。',
        'counterexamples': '末轮1覆甲不能漏计，5牌挡不是全部防护；本战未建立灵动步法。一次死亡不证明75%纯bug，也不支持固定先杀甲虫。',
        'expected': '保持既有成长及排序；原候选、抽弃后候选、实际执行、醒后力量与防护分别核对。',
        'validation': '按实体身份核睡层、醒后力量、虚弱恢复、覆甲和毒，再保存最终执行线的逐样本轨迹并按独立局校准。',
        'lines': [286164,286170,286173,286174],
    },
    {
        'id': 'silent-proposal-df37594e9b12debf',
        'evidence': 'RC61MFQM63Y6，A10 F33第3试T4；states:285414只生存者/打击，285415手空，45血7挡对57激光，原后继朝火箭攻击没执行。首/末T1血价差额另见t1-comparisons.json。F17T11呼唤自损按原提案引用，未冒本批新增该窗口核算。',
        'reason': '普通生存者唯一后继取消已有live祖先覆盖；跨选择整线归属、累计能力与呼唤自损的联合消费者仍未验收，不能用窄修复关闭整项。',
        'counterexamples': '第3试T4判死后未执行末攻击，不能写成真实损50；没有可保留的第二张牌时不虚构弃牌选择。持牌自损与毒终结必须分来源。',
        'expected': '保留唯一单弃消费及多选未知；实际持牌损血、候选成长与真正结算分开，取消不能兑现的攻击/朝向。',
        'validation': '先核普通单弃删除攻击和转向，再配对跨选择完整真实动作、呼唤持牌及毒终结的先后来源。',
        'lines': [285414,285415],
    },
    {
        'id': 'silent-proposal-42e81c83b2e1e56b',
        'evidence': 'RC61MFQM63Y6，A10 F33首/末T1实际入口52血，states:285314/285491及sl-attempts:1007/1012。F27投影与实入口、五火105/餐券30/幕间54/SL197按原保存提案引用，本批未重算这些全局金额。',
        'reason': '缺同条件路线、休息、后战对照及逐来源消费者验收；52血实入口与原回复账不足建立新安全血线或终局HP价格。',
        'counterexamples': '投影和实入口不同不自动定位模型缺陷，途中的构筑和事件条件可能变化；五次SL恢复同瓶药不能当新得药，其他路线没有实打结局。',
        'expected': '保持当前路线、休息及HP价；只有实际完成的回复计到账，未来营火与存档恢复另列。',
        'validation': '按同构筑、敌人、间隔和资源条件逐来源核入口，另取路线/休息/留药完整后继，不用不同局观察拟因果阈值。',
        'lines': [285314,285491],
    },
]
assert [x['id'] for x in items] == dispatch['proposal_ids']
write = lambda name, obj: (HERE / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
write('dispositions.json', items)
index = [json.loads(line) for line in (HERE / 'raw-evidence-index.jsonl').open()]
state_refs = {e['line']: e for e in index if Path(e['source']).stem == 'states'}
proposal_text = [f'# 静默猎手十项已派提案复核\n\n记录：{timestamp}；batch={BATCH}。\n',
    f'基线：{BASE}。本批仅消费已领取的十个原ID，全部waiting；没有新的游戏规则、源码或知识修改。'
    '这是逐项保留原提案及缺口的报告，不将局部已实现功能登记成整项完成。原始Markdown均按原SHA保存为各ID的.md.txt。\n']
for item, original in zip(items, assigned):
    refs = [state_refs[n] for n in item['lines']]
    proposal_text.append(f"## {item['id']}\n\n{original['summary']}\n\n"
        f"来源任务：{original['source_task']}；实现任务：strategy-proposal；已观察角色/进阶：silent/A10。"
        f"账本：{', '.join(original['ledger'])}。授权Roy-2026-10-07-learning不提供游戏事实。\n\n"
        f"原提案：{original['proposal']}；SHA256：{original['proposal_sha256']}。\n\n"
        f"证据：{item['evidence']}\n\n处置：waiting。{item['reason']}\n\n"
        f"反例与限制：{item['counterexamples']}\n\n旧/预期行为：{item['expected']}\n\n"
        f"验证方法：{item['validation']} 本批不拟合新参数；同局SL按原局分组，不作独立训练/验证样本。\n\n"
        '代表原帧（其余完整引用见raw-evidence-index.jsonl及observed-windows.json）：\n\n' +
        '\n'.join(f"- states:{r['line']}；offset={r['offset']}；bytes={r['bytes']}；SHA256={r['sha256']}" for r in refs) +
        '\n\n回退：本批没有行为变更可回退；后续如有实现，只逆向撤销对应真实源码提交，保留原日志、失败、账本及并行刷新。\n')
(HERE / 'proposal.md').write_text('\n'.join(proposal_text))

stream_table = '| 流 | source_size字节 | 本批行数 | 与前批六流封套相同 |\n|---|---:|---:|---|\n' + '\n'.join(
    f"| {e['stream']} | {e['source_size']} | {e['verified_lines']} | {str(e['same_previous_envelopes']).lower()} |" for e in audit['streams'])
commits = '\n'.join(f"- {c['commit']}：{c['subject']}；base祖先={str(c['base_ancestor']).lower()}，实际live祖先={str(c['live_ancestor']).lower()}。" for c in source['commits'])
report = f'''# 静默猎手十项策略提案复核报告

记录：{timestamp}；batch={BATCH}。

本批十项全部waiting。没有新增源码/知识修改、源码提交、live合入、行为版本或shipped。现有局部实现保留，未把子实现、报告完成或派发锚点当整项验收。

## 派发与基线

开工git status干净，实际HEAD={BASE}。根ops/codex-ops/learn.json本批task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配，十个proposal_ids与本报告逐项一致；没有research_request、implementation_request或proposal_repair。普通专题匹配文件绑定20261010-150327其他批次，故未承接专题、未读其他专题正文或领取新队列。按任务git merge --no-edit main返回Already up to date；完整base保持实际HEAD。

五个派发局NHA2KW0RB7VP、P74C04AEPL1F、G33HU22H2543、RC61MFQM63Y6、BTSRF7JL1W1Y均经runs.jsonl确认为SILENT/A10。32个原账本全部silent；十份原Markdown与注册SHA256一致并留原字节副本。未读取或搬用其他角色知识，没有下级agent。

## 冻结证据与原字节验证

本批实际运行本工作树learner/extract_evidence.py，以显式run_id/state.run_id/run/fingerprint.run身份选取八流，冲突身份拒收，不把正文提及当所属局。每流冻结source_size、逐行offset/bytes/SHA256/原JSON、各局计数和封套SHA保存在evidence/与raw-evidence-index.jsonl。之后对全部6606行seek原日志核字节、JSON、身份和截点界限，通过；没有用当前知识替代原日志。

{stream_table}

前批20261016-204302六流的封套SHA和各局计数与本批完全相同。新source_size代表扫描边界推进，不增加这五局的独立样本或SL分母。runs新增本批独立提取的五条身份；fight-plans在该2233957字节截点对本批选到0行，仅说明该流截点未选到，不能据此断言原日志不存在。

另用共用CLI的--streams run-plans --source-size 8577226独立重提取旧截点，26行与当前封套SHA/计数一致，保存evidence-old-plans/和old-plans-audit.json，未覆盖旧报告或零行初稿。全源扫描states/decisions/brain各有2条无效行，均未作为本批证据；这不是本批局的产品故障结论。八流扫描不是同一墙钟瞬间，实际边界各自保留。

## 本批实际核算及限制

audit_materials.py退出0：16项关键帧事实、两组T1四个实际分支均通过；另有5项决策绑定检查。材料输出见material-checks.json、t1-comparisons.json、decision-binding-checks.json和discard-counterexamples.json。它们是日志材料核算，不是tsc/vitest或生产cases，也不是独立胜率校准。

- NHA2KW0RB7VP F33首/末T1，同30血由损1/净扣8变为损7/净扣24，即多损6、多输出16。没有受控整战胜线，不推出固定SL血价。
- RC61MFQM63Y6 F33首/末T1，同指纹52血，损4/净扣30变为损8/净扣23。decisions279021和279197实际预算分别3轮2样本、5轮24样本；同题候选24/24死亡不能扩大成两次真实决策同预算。当前对照只支持即时差额。
- P74C04AEPL1F F23末T3，1血16挡、弃精确切击后卵毒后仍2血并杀玩家，石虫照样眩晕。首/第三试T3卵已经离场，明确保留反例。动态精确切击替代分支没有完整实打。
- P74C04AEPL1F F17火焰扣1、普通触媒下12毒两结只扣2；F22寄生0→21，两轮实损20/24，53→9赢战后F23仍9血空药。284760主怪仍15，284761奖励只留归零寄生，主怪末次伤害来源中间帧仍缺。
- BTSRF7JL1W1Y F31抽弃前后decisions279852/279854为3轮/5轮各4样本，并换了攻击目标。末次14血、5牌挡+1覆甲对22，毒后甲虫13血而玩家0。单条3/4样本线的一次死亡不能证明纯bug、调权或固定击杀顺序。

原config确有完整源码commit、dirty_files及知识前缀SHA，但当时dirty知识和移动表原字节没有在本批重建，不声称已复原历史运行输入。原提案所列全历史营火、餐券、幕间、SL和药水总额仅作为已有记录引用，本批未重新全量计算。没有做未走路线、保药、替代休息或未执行候选的因果结论。

## 当前源码与实际live的有限覆盖

本批核验实际live={source['live']}。14个相关源码叶中12个与前批base={source['previous_base']}同字节；新增差异只在combat-plan.ts传failureDirectory、boss-sim.ts捕获continuation失败封套/轨迹及传递诊断参数，原nonpositive-HP拒绝仍保留。源码补丁分别保存previous-base-source.patch和base-live-source.patch。

14叶中10叶与实际live物理文件相同；card-model.ts、passive-pieces.ts、sl/explore.ts、sl/controller.ts四叶的差异仅历史Roy/Dai署名注释，不归为游戏机制修改，也未重写。没有由少数源码叶相同推断全量运行知识或旧dirty输入相同。

{commits}

六个实用窄覆盖的实际live祖先为：1dab14da（并列组即时损血参考）、e784dd9f（投斧首牌身份）、bf423c17（普通生存者唯一单弃）、97efc061（暂停计划及条件预测）、4b0823f5（弃牌手牌/费用独立快照）、1698adc9（SL资源比较）。2a62f327仅为局部事实通道；5d7f9e6a与f3470087不是实际live祖先，不拿侧支登记实现。

直接读回确认：turn-solver只在已观察普通生存者且唯一可弃牌时确定移除，多个选择仍留未知；silent-discard-facts明确不解弃后动态牌面、触发与结果；discard_plan显示条件后继且保留全部候选。silent-sl-resource-comparison标scope=current_turn_prediction、execution=unverified；随机药中位/缺线不计算成对差。SL explore仍按B2/notWorse或rollout deathShare及原排名选择。已有信息通道不能替代完整执行归属、组合来源或独立校准。

没有新的可隔离源码失配，故没有再次实现这些子功能，也没有用固定惩罚或游戏先验补缺口。铁甲及其他角色行为未变化，未改知识构建脚本、未重建知识、未调用LLM/网络/模拟池或play。

## 逐项处置

完整证据局号/层/回合、账本、原Markdown/SHA、代表原帧offset/bytes/SHA、旧/预期行为、反例、验证和回退逐项在proposal.md。以下十项没有忽略或只作整批泛化处置。

'''
for item, original in zip(items, assigned):
    report += (f"### {item['id']}\n\n账本：{', '.join(original['ledger'])}。\n\n"
               f"证据：{item['evidence']}\n\n处置：waiting。{item['reason']}\n\n"
               f"反例/限制：{item['counterexamples']}\n\n"
               f"预期行为：{item['expected']}\n\n验证：{item['validation']}\n\n")
report += f'''## 记录、测试和交付

只经根learner/ledger.py update向32个既有id追加by=learner:strategy-proposal的where.proposal和note，链接本批proposal.md/report.md及逐项处置；CLI输入/退出与逐物理追加审核将在ledger-update-input.jsonl、ledger-cli.*、ledger-append-audit.json保留。没有新发现需要add为proposed；既有shipped/accepted/proposed状态均保持，不降级、不冒shipped，也不重复写support/repeat或历史复盘。原claim、first_run、prior、evidence、version、effect及旧前缀不改。没有新代码提案，因此不另造CLI id；最终code_proposals沿用十个已派原id，由调度器登记proposal_results，不直接改队列状态。

无源码/知识改动，撤源码失败/恢复通过、tsc、vitest均不适用且未运行；tests为{{"tsc":null,"vitest":null,"cases":null}}。21项材料检查及4个T1分支不填生产cases，不借旧绿报告成功。没有提交、live合并、eval版本、decision-log上线行或规则双通知；没有父学习要求或自然采用/胜率改进的完成声明。

启动日志白名单参数读回为gpt-6.1-sol、xhigh、default；任务正文要求high，实际宿主传入xhigh。本模型没有切换配置或降低强度，启动参数不等同本原生请求的独立运行证明；原生请求及服务档未独立核实，见runtime-readback.json。全程一个学习者，未修改调度状态、模型、账号或运维prompt。

本批无新科学异议或与旧知识冲突的结论；旧报告已经指出的预算/执行归属限制继续保留，不新造通知或代填ops/watcher/Roy ACK。未实现的具体缺数据理由均保留waiting，待新局重派；已有局部源码不能关闭其余宽项。

回退：本批没有行为差量可回退；只追加的追溯记录保留。完成时须核HEAD等于base且tracked/index干净、source-worktree.patch为空；不删除仍在运行的自身工作树或原日志。

运维交付：{HERE / 'proposal.md'}。完整报告：{HERE / 'report.md'}；机器回报：{HERE / 'result.json'}。
'''
(HERE / 'report.md').write_text(report)
result = {'task':'strategy-proposal','character':'silent','batch':BATCH,'base':BASE,
          'runs':dispatch['runs'],'fixes':[],'skipped':[],'merged':None,
          'tests':{'tsc':None,'vitest':None,'cases':None},
          'code_proposals':dispatch['proposal_ids'],'implementation_domains':[],
          'proposal_results':[{'id':x['id'],'state':'waiting','reason':x['reason']} for x in items],
          'report':str(HERE / 'report.md')}
write('result.json', result)
ledger_ids = sorted({ident for p in assigned for ident in p['ledger']})
before = json.loads((HERE / 'ledger-before.json').read_text())
assert len(ledger_ids) == 32 and all(before[i]['character'] == 'silent' for i in ledger_ids)
with (HERE / 'ledger-update-input.jsonl').open('w') as handle:
    for ident in ledger_ids:
        related = [item for item,original in zip(items,assigned) if ident in original['ledger']]
        row = {'id':ident,'by':'learner:strategy-proposal',
               'where':{'proposal':[str(HERE/'proposal.md'),str(HERE/'report.md')]},
               'note':BATCH+'：复核既有派发提案；'+ '；'.join(x['id']+' waiting：'+x['reason'] for x in related)+
                      '。仅追加追溯，不改claim/首证/prior/evidence/status/version/shipped；无新源码、合入或参数。'}
        handle.write(json.dumps(row,ensure_ascii=False)+'\n')
print(json.dumps({'proposal_count':len(items),'ledger_links_prepared':len(ledger_ids),
                  'report':str(HERE/'report.md'),'base':BASE},ensure_ascii=False))

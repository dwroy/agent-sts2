import hashlib
import importlib.util
import json
import re
import subprocess
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
PREVIOUS = ROOT / '.worktrees/codex-strategy-silent-20261016-204302/learner/runs/20261016-204309-f8856630-8982-4157-8c69-91f3af244b03-strategy-proposal'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(*args, cwd=WORKTREE):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


dispatch = json.loads((HERE / 'dispatch.json').read_text())
assigned = json.loads((HERE / 'assigned-proposals.json').read_text())
assert [p['id'] for p in assigned] == dispatch['proposal_ids']
proposals = []
for proposal in assigned:
    path = Path(proposal['proposal'])
    data = path.read_bytes()
    assert digest(data) == proposal['proposal_sha256']
    assert proposal['character'] == 'silent'
    (HERE / (proposal['id'] + '.md.txt')).write_bytes(data)
    proposals.append({'id': proposal['id'], 'path': str(path), 'sha256': digest(data),
                      'bytes': len(data), 'ledger': proposal['ledger'], 'runs': proposal['runs']})
write('proposal-audit.json', proposals)

prior_source = json.loads((PREVIOUS / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
leaves = [entry['path'] for entry in prior_source['leaves']]
source = {'base': base, 'live': live, 'previous_base': prior_source['base'], 'commits': [], 'leaves': []}
for entry in prior_source['commits']:
    commit = entry['commit']
    source['commits'].append({'commit': commit,
        'base_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, base], cwd=WORKTREE).returncode == 0,
        'live_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live], cwd=WORKTREE).returncode == 0,
        'subject': git('show', '-s', '--format=%s', commit).decode().strip()})
for path in leaves:
    current = (WORKTREE / path).read_bytes()
    physical = (LIVE / path).read_bytes()
    previous = git('show', prior_source['base'] + ':' + path)
    source['leaves'].append({'path': path, 'base_sha256': digest(current),
        'live_physical_sha256': digest(physical), 'previous_base_sha256': digest(previous),
        'equal_live': current == physical, 'equal_previous_base': current == previous})
write('source-audit.json', source)
(HERE / 'previous-base-source.patch').write_bytes(git('diff', '--binary', prior_source['base'], base, '--', *leaves))
(HERE / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *leaves))
(HERE / 'source-worktree.patch').write_bytes(git('diff', '--binary', 'HEAD'))

spec = importlib.util.spec_from_file_location('extractor', WORKTREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest_path = HERE / 'evidence/evidence-manifest.json'
manifest = json.loads(manifest_path.read_text())
prior_manifest = json.loads((PREVIOUS / 'evidence-reuse-audit.json').read_text())
prior_streams = {entry['stream']: entry for entry in prior_manifest['streams']}
states = {}
decisions = {}
windows = []
audits = []
state_ranges = [(283390, 283409), (283653, 283671), (284626, 284660),
                (284730, 284821), (285314, 285321), (285411, 285415),
                (285491, 285497), (285544, 285562), (286148, 286180),
                (283850, 283873), (284175, 284208), (284400, 284408)]
decision_lines = {277248, 277250, 277272, 277274, 277909, 277954, 278032,
                  278542, 278543, 278544, 278545, 278546, 279021, 279117,
                  279197, 279852, 279854}
with (HERE / 'raw-evidence-index.jsonl').open('w') as index:
    for entry in manifest:
        stream = entry['stream']
        source_path = ROOT / 'logs' / (stream + '.jsonl')
        envelope_path = HERE / 'evidence' / (stream + '.evidence.jsonl')
        sha = hashlib.sha256()
        counts = Counter()
        assert source_path.stat().st_size >= entry['source_size']
        with envelope_path.open('rb') as envelopes, source_path.open('rb') as raw_source:
            for encoded in envelopes:
                sha.update(encoded)
                envelope = json.loads(encoded)
                assert envelope['source'] == str(source_path)
                assert 0 <= envelope['offset'] < envelope['offset'] + envelope['bytes'] <= entry['source_size']
                raw_source.seek(envelope['offset'])
                raw = raw_source.read(envelope['bytes'])
                assert raw.endswith(b'\n') and digest(raw) == envelope['sha256']
                row = json.loads(raw)
                assert row == envelope['row']
                assert extractor.run_identity(row) == envelope['run_id'] in dispatch['runs']
                counts[envelope['run_id']] += 1
                ref = {k: v for k, v in envelope.items() if k != 'row'}
                index.write(json.dumps(ref, ensure_ascii=False) + '\n')
                selected = ((stream == 'states' and any(lo <= envelope['line'] <= hi for lo, hi in state_ranges))
                            or (stream == 'decisions' and envelope['line'] in decision_lines)
                            or stream in ('sl-attempts', 'run-config', 'run-plans', 'runs'))
                if selected:
                    windows.append(envelope)
                    if stream == 'states':
                        states[envelope['line']] = envelope
                    if stream == 'decisions':
                        decisions[envelope['line']] = envelope
        assert sha.hexdigest() == entry['output_sha256']
        assert {run: counts[run] for run in dispatch['runs']} == entry['counts']
        previous = prior_streams.get(stream)
        audits.append({**entry, 'verified_lines': sum(counts.values()),
                       'raw_bytes_verified': True, 'explicit_identity_verified': True,
                       'previous_source_size': previous['source_size'] if previous else None,
                       'same_previous_envelopes': entry['output_sha256'] == previous['output_sha256'] if previous else None})
write('evidence-audit.json', {'streams': audits, 'total': sum(e['verified_lines'] for e in audits),
                            'manifest_sha256': digest(manifest_path.read_bytes())})
write('observed-windows.json', windows)


def state(line):
    return states[line]['row']['state']


def player(line):
    return state(line)['combat']['player']


def enemy(line, ident):
    return next(e for e in state(line)['combat']['enemies'] if e['enemy_id'] == ident)


def power(obj, ident):
    return next((p['amount'] for p in obj.get('powers', []) if p['power_id'] == ident), 0)


checks = []


def check(label, actual, expected, lines):
    assert actual == expected, (label, actual, expected)
    checks.append({'结论': label, '实际值': actual, '引用': [
        {k: v for k, v in states[line].items() if k != 'row'} for line in lines]})


check('弃牌前1血16挡', [player(284817)['current_hp'], player(284817)['block']], [1, 16], [284817])
check('精确切击实际离手', ['PRECISE_CUT' in [c['card_id'] for c in state(n)['combat']['hand']] for n in [284817, 284818]], [True, False], [284817, 284818])
check('卵毒后剩2血、玩家归零', [enemy(284821, 'BOWLBUG_EGG')['current_hp'], player(284821)['current_hp']], [2, 0], [284820, 284821])
check('石虫退出帧眩晕', enemy(284821, 'BOWLBUG_ROCK')['intents'][0]['intent_type'], 'Stun', [284821])
# Resolve the same entity by identity rather than by an array slot that can shrink.
vant_id = state(284630)['combat']['enemies'][0]['enemy_id']
check('火焰兑现1血、消耗1滑溜', [enemy(284630, vant_id)['current_hp']-enemy(284631, vant_id)['current_hp'], power(enemy(284630, vant_id), 'SLIPPERY_POWER')-power(enemy(284631, vant_id), 'SLIPPERY_POWER')], [1, 1], [284630, 284631])
check('12毒两结仅扣2血、毒12到10、滑溜6到4', [enemy(284635, vant_id)['current_hp']-enemy(284636, vant_id)['current_hp'], power(enemy(284635, vant_id), 'POISON_POWER'), power(enemy(284636, vant_id), 'POISON_POWER'), power(enemy(284635, vant_id), 'SLIPPERY_POWER'), power(enemy(284636, vant_id), 'SLIPPERY_POWER')], [2, 12, 10, 6, 4], [284635, 284636])
check('尖啸临时负力次轮消失', [power(enemy(n, vant_id), 'STRENGTH_POWER') for n in [284634, 284636]], [-6, 0], [284634, 284636])
check('赢战53到9、下战9血', [player(n)['current_hp'] for n in [284730, 284761, 284766]], [53, 9, 9], [284730, 284761, 284766])
check('F22两攻击轮实际损20和24', [player(a)['current_hp']-player(b)['current_hp'] for a,b in [(284743,284744),(284753,284754)]], [20, 24], [284743,284744,284753,284754])
minion_id = state(284748)['combat']['enemies'][0]['enemy_id']
check('幻象寄生归零后恢复21', [enemy(n, minion_id)['current_hp'] for n in [284748,284749]], [0, 21], [284748,284749])
check('普通生存者后唯一打击被弃', [[c['card_id'] for c in state(n)['combat']['hand']] for n in [285414,285415]], [['SURVIVOR','STRIKE_SILENT'],[]], [285414,285415])
rocket_id = state(285415)['combat']['enemies'][1]['enemy_id']
check('取消转向后45血7挡、来袭57', [player(285415)['current_hp'],player(285415)['block'],enemy(285415,rocket_id)['intents'][0]['total_damage']], [45,7,57], [285415])
check('末轮两敌毒兑现22和42', [e['current_hp']-enemy(284408,e['enemy_id'])['current_hp'] for e in state(284407)['combat']['enemies']], [22,42], [284407,284408])
check('醒虫末段力量2到4', [power(enemy(n,'SLUMBERING_BEETLE'),'STRENGTH_POWER') for n in [286164,286170]], [2,4], [286164,286170])
check('末次14血5牌挡、1覆甲对22', [player(286173)['current_hp'],player(286173)['block'],power(player(286173),'PLATING_POWER'),enemy(286173,'SLUMBERING_BEETLE')['intents'][0]['total_damage']], [14,5,1,22], [286173])
check('甲虫毒后13血、玩家死亡', [enemy(286174,'SLUMBERING_BEETLE')['current_hp'],player(286174)['current_hp']], [13,0], [286174])
write('material-checks.json', checks)

comparisons = []
for envelope in windows:
    row = envelope['row']
    if Path(envelope['source']).stem != 'sl-attempts' or row['floor'] != 33 or row['attempt'] not in (1,6) or envelope['run_id'] not in ('NHA2KW0RB7VP','RC61MFQM63Y6'):
        continue
    t1,t2 = row['summary']['turns'][:2]
    hp_sum = lambda text: sum(int(x) for x in re.findall(r' (\d+)/\d+', text))
    comparisons.append({'run':envelope['run_id'],'attempt':row['attempt'],'hp_before':t1['hp'],'hp_next':t2['hp'],
        'hp_lost':t1['hp']-t2['hp'],'enemy_hp_net':hp_sum(t1['enemies'])-hp_sum(t2['enemies']),
        'plays':t1['plays'],'reference':{k:v for k,v in envelope.items() if k!='row'}})
assert sorted((x['run'],x['attempt'],x['hp_lost'],x['enemy_hp_net']) for x in comparisons) == sorted([
    ('NHA2KW0RB7VP',1,1,8),('NHA2KW0RB7VP',6,7,24),('RC61MFQM63Y6',1,4,30),('RC61MFQM63Y6',6,8,23)])
write('t1-comparisons.json', comparisons)
write('decision-readback.json', list(decisions.values()))
identities = [e['row'] for e in windows if Path(e['source']).stem == 'runs']
assert len(identities) == 5 and {r['run_id'] for r in identities} == set(dispatch['runs'])
assert all(r['character'] == 'SILENT' and r['ascension'] == 10 for r in identities)
write('run-identities.json', identities)
print(json.dumps({'raw_lines_verified': sum(e['verified_lines'] for e in audits),
                  'material_checks':len(checks),'t1_branches':len(comparisons),
                  'source_leaves':len(leaves),'same_previous_source':sum(e['equal_previous_base'] for e in source['leaves']),
                  'same_live_source':sum(e['equal_live'] for e in source['leaves'])},ensure_ascii=False))

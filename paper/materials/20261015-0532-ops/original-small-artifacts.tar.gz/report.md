# 静默猎手策略批次回报

记录切点：2026-10-15T05:21:44+08:00（生成前已执行date）。

本批为普通提案消费任务，batch=20261015-051302-strategy-proposal。learn.json对应行task=strategy-proposal、character=silent、reason=proposal，工作树匹配；有10个proposal_ids，无research_request、implementation_request、proposal_repair。旧专题绑定其他batch，不适用本批。仅处理派来的10项，不领取其他队列。开工git status干净，git merge --no-edit main返回Already up to date，完整base为`0052edea183041950e5d16356a0040925f1b39cc`。

10份原Markdown均存在、SHA与专用队列保存值逐项相同，见proposal-integrity.json；原提案、旧失败及历史口径不覆盖，不新造重复id。25个关联账本全部为silent，仅通过根目录ledger CLI补本批追溯，不标shipped。未读取其他角色私有知识。

**本批未改生产源码。** 只读合入预检`git merge-tree --write-tree ffb51b0bf12b3b49e30ec5b8c689550616d30981 0052edea183041950e5d16356a0040925f1b39cc`退出1，有22处真实冲突，完整原输出保存live-merge-preflight.txt，结构化结果见live-merge-preflight.json。依任务冲突停止要求，不实际merge、不解决或覆盖并行复盘/账本、不提交刷新知识、不修改live。螺线窄机制证据充分但因合并受阻未实施；它与仍缺策略校准的项分别记录。

## 证据冻结与实际复核范围

派发runs：9R916WW0V65N,JMH5C51RLN4E,9TG1RP5LFAAK,ZVYUL2YP3518,TDLBRNA0R05B,TXZ6RVMQA09D,XTSV1U9JD34T,PD9AYQVMLQW6,T0DGVABPV60U,ZE8F192FKX24。runs.jsonl确认9局A10、ZE8F192FKX24为A5，全部SILENT，见verified-runs.json。角色及进阶分账，不把A5套用到A10策略校准。

共用extract_evidence.py本次实际执行退出0。六流合计**20020行**，逐行重新seek只读原日志，核offset/bytes/SHA、显式身份和完整JSON一致，逐流重算输出SHA与计数；9989个state逐帧核角色，结果见evidence-verification.json。身份由run_id/state.run_id/fingerprint.run及run字段解析，正文提及不作所属局。source_size及逐行定位均保留在evidence/。全源已有无效JSON：states 2、decisions 2、brain 1；不计选中证据，不改原行。没有据零行或正文提及断言缺失。

|流|冻结原文件字节截点|选中/原字节复核行数|
|---|---:|---:|
|states|12891426862|9989|
|decisions|1471958660|9344|
|sl-attempts|39737053|104|
|run-config|1711099|11|
|run-plans|7870763|83|
|brain|537405580|489|


数值独立细核为螺线22帧、7条T0原决策及八局F48→49边界；其他机制引用已核SHA的原提案与既有本角色账本，不冒称本批重新完成全部历史机制校准或全部尝试整战反事实。当前knowledge只读silent选中5条，冻结在selected-silent-experience.json；后续27支持局知识不替代旧13局分母。

### 螺线已证窄范围

T0DGVABPV60U A10 F48末试T2 s296633—296641：一张普通SHIV加三张SHIV+令DEXTERITY_POWER与HELICAL_DART_POWER各0→4，已有挡仍0；s296642 T3两项清除。T3末s296654为永久3+临时4=7，T4 s296655仅永久3；s296656手动小刀后4敏/临时1，s296659偏折挡8，s296660防御+使总挡20；s296661次轮回3敏。22帧均已对原日志seek并核SHA，见helical-verified-frames.json。此前摘要读取误用了combat.turn得到null，已核回合实际字段为state.turn；最终层/轮来自真实字段，不将null当缺帧。

账本silent-0293已有F48T2/T4精确证据；silent-0104/0105为既有机制。当前base/live的combat-plan、turn-solver、rollout三文件字节相同；入口仅读现敏捷，同线无HELICAL_DART新增传播，TEMP_DEXTERITY_POWERS仅SPEED_POTION_POWER/ANTICIPATE_POWER。silent-kunai明确在持HELICAL_DART时不启用苦无模型，不能把苦无修复当螺线已实现。source-audit.json记录完整文件SHA及行号。未实施不是缺少该窄机制证据；自动、重放、多敌及未见交互仍未知。

d289605原线报15挡；实打偏折8+防御+12=20还含后继抽牌后换升级防御的3点差。遗物在两张挡牌各多1，共2，不归全部5挡。T5有敏无挡牌不能预支挡，也不声称修模型能让本局获胜。

### 策略与资源限制

八局最后F48边界HP与第一帧F49HP相同：9R=12、JMH=8、9TG=17、ZVY=50、TDL=2、TXZ=4、XTS=23、PD9=10，逐帧定位及药栏见resource-boundaries.json。T0未进入F49；ZE8 A5的胜负以runs原始记录为准，非战斗GAME_OVER中的通用HP字段不当伤害或死亡证据。全批不拟合持药价、终局权重、休息/锻造价值或SL阈值。

T0 F48T2 d289584/289585确有SL覆盖扫腿，末条含known to fail；T4 d289475/289479/289562有护栏取舍，d289562再被SL覆盖、d289563继续实际炼制。原答案、护栏、SL及实际动作必须分层；同局六试不作六局，未知后继抽弃/生成药和早期截断不能补成胜线。selected-decisions.json保留七条完整原件。

## 逐项结果

|提案|处置|主要原因|
|---|---|---|
|silent-proposal-9e5d50fdd7bf1fbd|waiting|八局连王交接已复核；缺固定两战血药/复活充能配对与按局留出校准，不能由首战胜后八场后战败拟合终局或持药权重；另有22处main/live合并冲突。|
|silent-proposal-20b9df170d51b280|waiting|六类机制已有部分源码，缺原提案全范围的同条件消费者验证；实验体早期尝试/女王截断与替代整战胜线仍不全，不将局部实现冒作整项duplicate；合并预检冲突停止实施。|
|silent-proposal-91cc7fd647077569|waiting|该项是原13支持局55试/5赢、真正重打12场54试/4赢的冻结分母勘误；本批锚点未覆盖原13局全集，未定位需修改该分母的生产消费者，不能用现27局知识或数据提交冒作源码duplicate。|
|silent-proposal-9c3554ff02a3119c|waiting|T0DGVABPV60U F48T2/T4原帧已支持手动普通/升级小刀增临时敏捷、后继挡兑现和次轮清除；当前同线/rollout仍缺传播。本项因22处main/live冲突停止源码实施，并非机制证据不足。|
|silent-proposal-f35a311b35f2b12a|waiting|缺固定狡诈药时点、后继抽弃及正确螺线模型的扫腿/速行者整战配对；首试也失败，不能由末试当轮多损12HP推出整战收益，且base/live的explore源码不同并存在合并冲突。|
|silent-proposal-4f7d4e424337cb58|waiting|护栏取舍原决策已复核；缺固定药产物/后继抽弃的完整配对、产物分布及独立留出，不能将未饮稳定血清计即时生存，也不能由重问差值拟持药价；合并预检冲突停止实施。|
|silent-proposal-9e77e1e88c0cecd4|waiting|与9c3554共享已证螺线缺口；永久/临时敏捷分账已有窄证据，但整项还包含覆甲/脆弱/钨棍组合消费者验证，不能整体duplicate。合并冲突阻止本批实施已证窄部分。|
|silent-proposal-e406c9312e1c329a|waiting|滚石轮初已有源码；本次未找到IRON_CLUB/SPEEDSTER的显式生产传播，不能以滚石局部实现标整项duplicate。铁棒抽入牌和速行者触发链仍需固定候选验证，合并冲突停止实施。|
|silent-proposal-6f660733c357cfe0|waiting|与f35a共享T0 F48T2局部反例，缺固定后继抽弃、技能激怒/阶段清除与正确螺线的整战对照；无新增可拟探索血价参数，保留现规则；合并冲突停止实施。|
|silent-proposal-e6559caa25d704e3|waiting|本批可复核T0及ZE8的炼制/资源事实，但未重核原提案另三局和完整随机产物分布；缺同板面补药与两战资源配对及时间留出，不调HP护栏、持药或终局权重；合并冲突停止实施。|


每项原提案、层/轮、账本、反例、预期行为、验证与回退见同目录proposal.md。原队列不直接编辑；proposal_results由本次真实JSON交调度器处理，10项全部waiting而非implemented/duplicate。无新code_proposals CLI add调用，因为所有处理项均已有真实id。

## 合入与验证真值

无生产源码、知识数据、任务模板或执行输入修改；HEAD保持完整base，fixes=[]、merged=null，无提交、合入提交、release_id或新版本。22冲突主要落在notes/fix-queue-v4.md、for-dai/for-roy、lessons、ops/inbox-dev、paper数据/绑定记录、decision-log与学习账本，具体逐条见预检。live当时另有两份并行运维报告脏文件，未碰其内容。预检不是实际merge失败，也没有live回滚。

tsc、vitest、固定策略cases、撤源码失败及恢复通过均**未运行/不适用**，JSON tests全部null，不填0或借旧批绿。本批仅运行材料抽取及原字节核验；gitleaks记录扫描另记record-scan-result.json，不冒称沙箱源码自测。没有新增游戏行为，不造eval版本、不写上线双通知或shipped；本报告交ops核实合并阻塞并继续原提案，不关闭任何父学习要求。临时产物都在本批scratch，不清理仍运行工作树或原日志。

账本实际结果：根目录ledger.py update退出0，共25个本角色既有id补本批报告/提案链接；silent-0293由observed推进proposed，其他状态保持，没有降级原shipped项或改claim/历史证据。CLI输入、stdout/stderr及读回分别见ledger-updates.jsonl、ledger-cli-result.json、ledger-readback.json。

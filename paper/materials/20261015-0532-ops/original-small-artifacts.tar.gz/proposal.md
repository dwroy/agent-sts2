# 本批10项静默猎手提案处置

本批为普通提案消费任务，batch=20261015-051302-strategy-proposal。learn.json对应行task=strategy-proposal、character=silent、reason=proposal，工作树匹配；有10个proposal_ids，无research_request、implementation_request、proposal_repair。旧专题绑定其他batch，不适用本批。仅处理派来的10项，不领取其他队列。开工git status干净，git merge --no-edit main返回Already up to date，完整base为`0052edea183041950e5d16356a0040925f1b39cc`。

10份原Markdown均存在、SHA与专用队列保存值逐项相同，见proposal-integrity.json；原提案、旧失败及历史口径不覆盖，不新造重复id。25个关联账本全部为silent，仅通过根目录ledger CLI补本批追溯，不标shipped。未读取其他角色私有知识。

**本批未改生产源码。** 只读合入预检`git merge-tree --write-tree ffb51b0bf12b3b49e30ec5b8c689550616d30981 0052edea183041950e5d16356a0040925f1b39cc`退出1，有22处真实冲突，完整原输出保存live-merge-preflight.txt，结构化结果见live-merge-preflight.json。依任务冲突停止要求，不实际merge、不解决或覆盖并行复盘/账本、不提交刷新知识、不修改live。螺线窄机制证据充分但因合并受阻未实施；它与仍缺策略校准的项分别记录。

## 1. silent-proposal-9e5d50fdd7bf1fbd

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-120901-experience-update/proposal-resources.md；原SHA：`b9f51c867eb26ec7a5cda61c3104ca8692673077bbfd24539a1ed634ada62057`。
账本：silent-0228, silent-0020, silent-0019, silent-0021, silent-0243, silent-0259, silent-0276；领域：combat, potion, sl, terminal。

状态：**waiting**。八局连王交接已复核；缺固定两战血药/复活充能配对与按局留出校准，不能由首战胜后八场后战败拟合终局或持药权重；另有22处main/live合并冲突。

证据：9R916WW0V65N F48末试T15至F49T1：12血空药接续；JMH5C51RLN4E、9TG1RP5LFAAK、ZVYUL2YP3518、TDLBRNA0R05B、TXZ6RVMQA09D、XTSV1U9JD34T、PD9AYQVMLQW6同幕F48→49分别为8/17/50/2/4/23/10HP。

反例与限制：大脑已有连王备战规划；观察到后战失败不等于忘记后王，也不证明留药或另一条路线会赢。

预期行为：保持当前权重；后续仅按实际出口HP、药栏、可核复活充能及新战能力清空接续，不将缺失充能填成0。

验证办法：固定两战牌序与种子，逐样本核HP、药槽和复活来源；按局时间切分验证校准，另列保药和改线整战对照。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 2. silent-proposal-20b9df170d51b280

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-120901-experience-update/proposal-mechanisms.md；原SHA：`b9ee24a27c6c049c6e4ed550fddfbe09e4a13e5270c626eb1dda196b203f6c2f`。
账本：silent-0023, silent-0094, silent-0054, silent-0173, silent-0028, silent-0069, silent-0079；领域：combat, sl。

状态：**waiting**。六类机制已有部分源码，缺原提案全范围的同条件消费者验证；实验体早期尝试/女王截断与替代整战胜线仍不全，不将局部实现冒作整项duplicate；合并预检冲突停止实施。

证据：9R916WW0V65N F48末试T2技能加力、T15首王胜后12血空药；F49末试T1步法/冰晶/后继挡牌分源，T2精准三刀各8、当轮无可兑现挡而死。账本0023/0094/0054/0173/0028/0069/0079。

反例与限制：前两实验体尝试和前五女王尝试缺完整退出/结算；末试实验体抽弃与出牌同变，不归单项转胜。

预期行为：仅补已观察而当前确实遗漏的传播，保持杀序选择及未验证自动/重放边界；源码已有余像、轮初滚石、冰晶及阶段入口不代表完整联动已验收。

验证办法：六类机制逐项固定原板面，核技能与能力差异、逐牌被动挡、阶段清除及魂缚后的真实合法牌，不以整场未执行原计划检验预测。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 3. silent-proposal-91cc7fd647077569

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-120901-experience-update/proposal-mechanisms-denominator-correction.md；原SHA：`ff4643d2d2b04a8583be8e691cf439f4074b9563137e13cd955416869a430cf2`。
账本：silent-0023, silent-0094, silent-0054, silent-0173, silent-0028, silent-0069, silent-0079；领域：combat, sl。

状态：**waiting**。该项是原13支持局55试/5赢、真正重打12场54试/4赢的冻结分母勘误；本批锚点未覆盖原13局全集，未定位需修改该分母的生产消费者，不能用现27局知识或数据提交冒作源码duplicate。

证据：原勘误Markdown的SHA匹配，明确旧12支持局52试4赢加9R916WW0V65N三试1赢；新局F48仅末试T15有实胜。

反例与限制：原20b9提案正文的13局62试/真正重打13场60试属于已保留旧错误；当前知识的27支持局又是后续扩展集合，均不能替代冻结13局。

预期行为：保留勘误原件及来源范围；报告引用13/55/5与12/54/4时必须注明仅为原提案冻结集合，不扩写到当前全角色或全部历史。

验证办法：若后续授权补齐原13局，逐尝试核所属局、首试/重打及真实结算，并明确口径的实际消费者；本批不扩到该全集。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 4. silent-proposal-9c3554ff02a3119c

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-124302-postmortem/proposal-helical.md；原SHA：`2c2730c4fe101218da4c0fd7fb97d698827c2308e49ea323dc8579b98b935d3f`。
账本：silent-0293；领域：combat。

状态：**waiting**。T0DGVABPV60U F48T2/T4原帧已支持手动普通/升级小刀增临时敏捷、后继挡兑现和次轮清除；当前同线/rollout仍缺传播。本项因22处main/live冲突停止源码实施，并非机制证据不足。

证据：silent-0293：s296633—296641末试T2四刀使DEXTERITY/HELICAL_DART 0→4，s296642 T3清除；s296655—296660 T4永久3敏、小刀新增1、偏折8挡、防御+12挡；s296661 T5回到永久3敏。

反例与限制：d289605原计划普通防御报15挡，实执行后换成防御+另增3；小刀仅为两张后继挡各加1，共2，不能将全部5挡差归螺线。T5有敏无挡牌不产生格挡。

预期行为：仅静默已见A10、持有效螺线、显式手动SHIV/SHIV+后临时+1敏；不倒补已有挡，次轮只撤HELICAL_DART临时量而保留步法永久量；自动/重放/未见组合保持未知。

验证办法：冲突由ops协调后，在当前树建立同牌序固定候选、先刀后挡/先挡后刀、普通与升级牌、次轮清除/永久量保留及真实planner消费者；撤源码须失败、恢复须通过，再跑规定沙箱。尚未执行。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 5. silent-proposal-f35a311b35f2b12a

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-124302-postmortem/proposal-sl.md；原SHA：`406a8bcbd5bc5ded5888e2ce5e64760ba8c8ff41d8e86fad9a8f4c45ec3ac810`。
账本：silent-0079；领域：combat, sl。

状态：**waiting**。缺固定狡诈药时点、后继抽弃及正确螺线模型的扫腿/速行者整战配对；首试也失败，不能由末试当轮多损12HP推出整战收益，且base/live的explore源码不同并存在合并冲突。

证据：silent-0079：T0DGVABPV60U F48末试T2 d289584/289585两次覆盖Jev扫腿选择，后一理由含known to fail；s296633—296642 HP38→26、0挡。

反例与限制：首试扫腿当轮零损但后续也判死；末试狡诈药提前及后续抽弃变化，敌血净扣23→43不是纯换线效果。

预期行为：保留真正必死才SL规则；展示即时血价、虚弱/挡与未知抽牌，不据一个全败板面调整探索权重或新阈值。

验证办法：同盘冻结药水与后继抽弃，先修并验证螺线，再逐层核原答→护栏→SL→抽牌重问→实际行动；需要时间后验而非将六试当六局。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 6. silent-proposal-4f7d4e424337cb58

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-124302-postmortem/proposal-potion.md；原SHA：`cd9c9205a9bf3c963b11acd06855d347c0dd832e1da1c334f1cf3e5c02ad0da3`。
账本：silent-0125；领域：combat, potion。

状态：**waiting**。护栏取舍原决策已复核；缺固定药产物/后继抽弃的完整配对、产物分布及独立留出，不能将未饮稳定血清计即时生存，也不能由重问差值拟持药价；合并预检冲突停止实施。

证据：silent-0125：T0DGVABPV60U F48T4 d289475/289562含炼制候选损17→护栏损10；d289479单炼制损21→护栏损10；d289562又被SL覆盖、d289563实际继续炼制。

反例与限制：第3/5试实际回合损血与抽弃不同，生成血清未实饮；SL恢复旧瓶不是新生成，预测差值不是独立实测节血。

预期行为：维持护栏/药水持有阈值；将已生成、已喝、保留、SL撤销和未执行机会分账，随机产物不得预选为救命药。

验证办法：固定真实候选与已记录产物分别重放即时HP、药槽和可用效用，按局留出校准后才拟合窄例外；没有充分分布不改参数。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 7. silent-proposal-9e77e1e88c0cecd4

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-130540-experience-update/proposal-dexterity.md；原SHA：`95d2c21f41e94501cc67e7ca27374bf699415186cb744472f92b4ba3c3cf0493`。
账本：silent-0012, silent-0005, silent-0104, silent-0105, silent-0016, silent-0178, silent-0293；领域：combat。

状态：**waiting**。与9c3554共享已证螺线缺口；永久/临时敏捷分账已有窄证据，但整项还包含覆甲/脆弱/钨棍组合消费者验证，不能整体duplicate。合并冲突阻止本批实施已证窄部分。

证据：silent-0012/0005/0104/0105/0016/0178/0293；T0DGVABPV60U F48末T4偏折8+防御+12，T5永久步法与临时螺线共8敏仍无挡。

反例与限制：钨棍逐次减损不能给总伤只减1；已有挡、覆甲、脆弱与敏捷收益必须分源；自动/重放及未知减损交互未隔离。

预期行为：实施螺线窄部分时复用原9c3554 id，不新建重复提案；保留当前已实现钨棍/覆甲，不因一个主题部分完成宣告整项实现。

验证办法：固定同线比较敏捷逐牌兑现、跨轮只撤临时量与步法保留，再独立核已见逐击/覆甲/脆弱组合，不把知识库后续统计当固定夹具。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 8. silent-proposal-e406c9312e1c329a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-130540-experience-update/proposal-draw-growth.md；原SHA：`c1231fa4c71075903e37234f58c181f34bb2547e298d9afb71fc7a8d33536168`。
账本：silent-0045, silent-0122, silent-0094；领域：combat。

状态：**waiting**。滚石轮初已有源码；本次未找到IRON_CLUB/SPEEDSTER的显式生产传播，不能以滚石局部实现标整项duplicate。铁棒抽入牌和速行者触发链仍需固定候选验证，合并冲突停止实施。

证据：silent-0045/0122/0094：T0DGVABPV60U F48末T2建立速行者2，T3步法附魔两抽额外扣4，T4偏折后铁棒一抽额外扣2；滚石T1建5、后轮5/10/15/20，死亡前25未兑现。

反例与限制：偏折/能力的抽牌触发伤不等于其牌型变攻击；多体/自动/重放未知，持有滚石25层不等于已打25伤。

预期行为：仅按已核时点和来源传递实际抽牌/额外伤，不预定未来抽入牌；无实体单次上限只按已见单目标范围。

验证办法：固定牌序与铁棒计数，分别核牌自身抽牌、遗物抽牌、速行者每抽伤和滚石轮初；给planner实际消费者同线验证，未知多体不推广。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 9. silent-proposal-6f660733c357cfe0

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-130540-experience-update/proposal-phase-sl.md；原SHA：`c354d466aa1db11c9e8ffee7528e93d3190ef3eb3e10eec3db814cb61c7ce3c1`。
账本：silent-0028, silent-0079；领域：combat, sl。

状态：**waiting**。与f35a共享T0 F48T2局部反例，缺固定后继抽弃、技能激怒/阶段清除与正确螺线的整战对照；无新增可拟探索血价参数，保留现规则；合并冲突停止实施。

证据：silent-0028/0079：T0DGVABPV60U F48末T2 d289584/289585覆盖扫腿后损12；末T3技能逐次激怒，能力步法不增敌力；阶段清敌状态而保留已建玩家能力。

反例与限制：六次同局探索均未赢，前五次判死截断不是五次实际结算死亡；0赢的有限模拟不构成所有可选行动必死证明。

预期行为：只按实际原答、护栏、SL覆盖和重问分层审计，待完整固定对照再提参数候选；不改真正必死/SL阈值。

验证办法：冻结全链路候选及实际资源，分别验证技能/能力、阶段清除和临时敏捷，新增同角色时间后验才评价策略收益。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

## 10. silent-proposal-e6559caa25d704e3

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-130540-experience-update/proposal-resources.md；原SHA：`7c5e84ba38573b47949fafb4c0c134b97f29946011a961a814d4e58d4f562cdb`。
账本：silent-0125, silent-0294, silent-0276, silent-0259, silent-0243, silent-0020, silent-0019, silent-0021；领域：combat, potion, sl, terminal。

状态：**waiting**。本批可复核T0及ZE8的炼制/资源事实，但未重核原提案另三局和完整随机产物分布；缺同板面补药与两战资源配对及时间留出，不调HP护栏、持药或终局权重；合并冲突停止实施。

证据：silent-0125/0294/0276/0259/0243/0020/0019/0021；T0DGVABPV60U F35T2/F45T3/F46T2实际炼制及F48第五试T4，ZE8F192FKX24为A5、F48T3炼制；A5与A10分开。

反例与限制：原提案另列6EV5V6PJJS9D/VLV17NUSFS61/7ZUC4VPMDS41不在本批锚点，本次不冒称重核五局27次；九回血仍败不证明锻造更好，低胜率不证明必死。

预期行为：已执行生成、未执行窗口、实饮和SL恢复分账；保持现权重和阈值，联合两战只用明确可观测资源。

验证办法：后续按授权补齐原范围，固定药产物/后继牌序/两战资源并按局留出；缺后战或替代整战胜线时不拟参数。

回退边界：本批没有行为改动，无源码可回退；后续实现须独立源码提交、撤码失败/恢复通过及规定沙箱检查，实际live祖先核实后才可写implemented，只有ops可登记shipped。

from pathlib import Path
import json,hashlib,gzip,subprocess,urllib.request,os
root=Path.cwd();pub=root/'paper/materials/20261015-silent-codex1-controlled-resume';private=root/'ops/codex-ops/record-staging/20261015-1322';sha=lambda b:hashlib.sha256(b).hexdigest();now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(now)
def process(pid):
 p=Path('/proc')/str(pid);fields=(p/'stat').read_text().split(') ')[1].split();cmd=(p/'cmdline').read_bytes();env=dict(x.split(b'=',1) for x in (p/'environ').read_bytes().split(b'\0') if b'=' in x);allow=['BRAIN_CODEX_HOME','BRAIN_CODEX_MODEL','BRAIN_CODEX_EFFORT','BRAIN_CODEX_SERVICE_TIER','BRAIN_CODEX_PAID_CREDITS','STS2_WORKSPACE','STS2_BASE_URL','STS2_EXPECTED_PROCESS_ID','STS2_EXPECTED_NATIVE_PROFILE_ID','LOGS'];return {'pid':pid,'birth':fields[19],'ppid':int(fields[1]),'state':fields[0],'cwd':str((p/'cwd').resolve()),'cmdline_sha256':sha(cmd),'environment':{k:env[k.encode()].decode() for k in allow if k.encode() in env}}
old=process(952170);auto=process(1738396);assert old['birth']=='92801432' and old['cwd']==str(root/'.worktrees/live/agent') and old['environment']['BRAIN_CODEX_HOME']=='/home/dw/.codex-brain';assert b'index.ts\0play' in Path('/proc/952170/cmdline').read_bytes();assert Path('ops/codex-ops/autoplay.pid').read_text().strip()=='1738396' and b'ops/autoplay.sh' in Path('/proc/1738396/cmdline').read_bytes()
marker=root/'logs/brain-wait.json';raw=marker.read_bytes();wait=json.loads(raw);assert wait['run_id']=='HLAWCGM3KHVB' and wait['question_id']=='mv8zzy2h-952170-24' and wait['pid']==952170 and wait['state'] in ['paused','heartbeat'];(pub/'old-brain-wait.json').write_bytes(raw)
response=urllib.request.urlopen('http://127.0.0.1:8080/state',timeout=10).read();mod=json.loads(response)['data'];assert mod['run_id']=='HLAWCGM3KHVB' and mod['run']['character_id']=='SILENT' and mod['run']['floor']==22 and mod['screen']=='EVENT';(pub/'mod-before.json').write_bytes(response)
assert not (root/'ops/STOP').exists() and not (root/'ops/codex-ops/LLM_DRAIN').exists()
files={};frozen=[]
for stream in ['states','decisions','brain','codex-calls','brain-wait','run-config','run-plans','sl-attempts']:
 f=root/'logs'/f'{stream}.jsonl';files[stream]={'bytes':f.stat().st_size}
 with f.open('rb') as h:
  start=max(0,f.stat().st_size-8*1024*1024);h.seek(start)
  if start:h.readline()
  chosen=[]
  while True:
   offset=h.tell();line=h.readline()
   if not line:break
   if b'HLAWCGM3KHVB' not in line:continue
   try:json.loads(line)
   except ValueError:continue
   chosen.append((offset,line))
 for offset,line in chosen[-2:]:
  name=f'original/{stream}-{offset}.jsonl.gz';dest=pub/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(line,mtime=0));assert gzip.decompress(dest.read_bytes())==line
  plain=private/'original-scan'/f'{stream}-{offset}.jsonl';plain.parent.mkdir(parents=True,exist_ok=True);plain.write_bytes(line)
  frozen.append({'stream':stream,'offset':offset,'bytes':len(line),'sha256':sha(line),'frozen':name})
thread='01a13dac-84b3-7d52-b045-64d5dc65cf32';native=sorted(Path('/home/dw/.codex-brain/sessions/2026/10/15').glob('*'+thread+'*.jsonl'));native_refs=[]
for f in native:
 raw=f.read_bytes();first=json.loads(raw.splitlines()[0]);payload=first.get('payload',{});assert payload.get('id')==thread and '/952170-' in payload.get('cwd','');native_refs.append({'source':str(f),'bytes':len(raw),'sha256':sha(raw),'thread':thread,'cwd':payload['cwd'],'source_untouched':True})
assert native_refs
for f in {native[0],native[-1]}:
 raw=f.read_bytes();name='old-native-thread/'+f.name+'.gz';dest=pub/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
 dest=private/'original-scan'/f.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 for ref in native_refs:
  if ref['source']==str(f):ref['frozen']=name
console=(root/'logs/console/current').resolve();raw=console.read_bytes();(pub/'old-console.log.gz').write_bytes(gzip.compress(raw,mtime=0));files['console']={'source':str(console),'bytes':len(raw),'sha256':sha(raw)}
(private/'original-scan/old-console.log').write_bytes(raw)
record={'at':now,'authorization':'Roy2026-10-15 13:22 via Claude; supersedes earlier no-controlled-resume instruction for this run only','run':'HLAWCGM3KHVB','source_question':wait['question_id'],'old_controller':old,'original_autoplay':auto,'mod_instance':{'process_id':34676,'native_profile_id':1,'base_url':'http://127.0.0.1:8080'},'mod_before_sha256':sha(response),'wait_sha256':sha(marker.read_bytes()),'log_cutoffs_before':files,'original_rows':frozen,'old_thread':thread,'old_native_thread_sources':native_refs,'live_before':subprocess.check_output(['git','-C',str(root/'.worktrees/live'),'rev-parse','HEAD'],text=True).strip(),'selector':(root/'ops/codex-ops/brain-home').read_text().strip(),'operations_not_performed':['game action','save reload','SL','new run','other lane signal','account queue/model change'],'V5S_natural_admission':'excluded: this whole run crosses account and controller boundaries; next natural codex1 run counted separately'}
(pub/'controller-before.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'before_frozen':True,'run':record['run'],'old_pid':old['pid'],'old_birth':old['birth'],'autoplay':auto['pid'],'native_sources':len(native_refs),'raw_rows':len(frozen)}))

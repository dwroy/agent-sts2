from pathlib import Path
import subprocess,json,re,hashlib,sys,tarfile
root=Path.cwd();private=root/'ops/codex-ops/record-staging/20261015-1322';pub=root/'paper/materials/20261015-1322-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
exec((root/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
bid='20261015-131302-fix-batch';out=(root/'ops/codex-ops/learner'/f'{bid}.out').read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);s=Path(report['report']).parent;batch=json.loads((root/'ops/codex-ops/learn.json').read_text())['batches'][bid];wt=Path(batch['worktree']);live=root/'.worktrees/live';native=runtime(bid,report,out,wt);q=json.loads((s/'audit.json').read_text());assert report['fixes']==[] and report['code_proposals']==[] and report['implementation_domains']==[] and report['merged'] is None;assert report['tests']=={'tsc':0,'vitest':0,'cases':86};assert not q['new_fixes'] and q['source_diff']==q['worktree_status']=='';assert git('rev-parse','HEAD',cwd=wt).decode().strip()==report['base'];assert not git('status','--porcelain','--untracked-files=all',cwd=wt);assert not git('diff',report['base'],'HEAD','--',cwd=wt)
head=git('rev-parse','HEAD',cwd=live).decode().strip();existing=[]
for v in q['existing_fixes']:
 commit=v['source_commit'];git('merge-base','--is-ancestor',commit,report['base']);git('merge-base','--is-ancestor',commit,q['live_read_only_snapshot']);git('merge-base','--is-ancestor',commit,head)
 assert sha(git('show',report['base']+':'+v['path']))==v['current_source_sha256'];assert sha(git('show',commit+':'+v['original_source_path']))==v['original_source_sha256'];present=subprocess.run(['git','cat-file','-e',head+':'+v['path']],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE).returncode==0
 if not present:
  assert v['path'].startswith('ops/') and (root/v['path']).is_file() and sha((root/v['path']).read_bytes())==v['current_source_sha256']
 existing.append(v|{'path_present_in_live_tree':present,'root_ops_consumer_current_sha_verified_when_no_live_leaf':not present})
assert len(existing)==72
for name,digest in q['tests']['logs'].items():assert sha((s/name).read_bytes())==digest
assert '10 passed (10)' in (s/'vitest-infra.log').read_text() and '81 passed (81)' in (s/'vitest-infra.log').read_text();assert '2 passed (2)' in (s/'vitest-fixtures.log').read_text() and '5 passed | 33 skipped (38)' in (s/'vitest-fixtures.log').read_text();assert not q['tests']['full_suite_run'] and q['tests']['reruns']==[]
sys.path.insert(0,str(root/'ops'));import learner_checks
verify=learner_checks.verify_empty_fix(report,batch,str(root));differences=git('diff','--name-only',report['base'],head,'--',*learner_checks.SOURCE_PATHS).decode().splitlines();assert verify is None and differences and batch['state']=='failed' and batch['rc']==0 and batch['merged'] is None and batch['proposal_audit_errors']==[]
receipt={'batch':bid,'report':report,'runtime':native,'queue_snapshot':{'sha256':q['queue_sha256'],'lines':q['queue_lines'],'same_as_previous_input':q['queue_identical_to_previous_audit']},'actual_live_at_readback':head,'base_unchanged_worktree_clean':True,'existing_sources':existing,'tsc_exit':0,'original_selected_vitest':{'files':12,'passed':86,'filtered_not_run':33,'full_suite':False,'reruns':[],'logs':q['tests']['logs']},'no_source_completion':{'canonical_state':batch['state'],'canonical_rc':batch['rc'],'canonical_merged':batch['merged'],'verify_empty_fix':None,'base_live_source_diff_paths':differences,'interpretation':'no new code delivered; exact-source no-change gate remains failed/rc0/mergednull because main baseline differs from live; preserve scheduler original retry state without inventing code failure, deployment, new release or broad closure'},'skipped_original_scopes':q['skipped'],'new_bug_or_counterevidence':False,'new_merge_version_host_full_or_learner_dispatch':False,'existing_original_owner_and_parent_scopes_preserved':True}
(pub/'empty-fix-readback.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');archive=[(f,'original/'+f.name) for f in s.iterdir() if f.is_file() and f.stat().st_size<1000000]
for ext in ['out','err']:
 f=root/'ops/codex-ops/learner'/f'{bid}.{ext}'
 if f.exists():archive.append((f,'outputs/'+f.name))
scan=private/'fix-archive-scan';manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as target:
 for f,name in archive:
  b=f.read_bytes();dest=scan/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);target.add(f,arcname=name);manifest.append({'source':str(f.relative_to(root)),'archive':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(pub/'original-artifacts.tar.gz','r:gz') as target:
 for v in manifest:assert sha(target.extractfile(v['archive']).read())==v['sha256']
(pub/'original-artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'existing_ancestries':72,'tsc':0,'selected':86,'filtered':33,'source_diff_paths':len(differences),'no_new_code':True,'artifact_count':len(manifest)}))

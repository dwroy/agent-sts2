from pathlib import Path
import json,subprocess,hashlib,gzip,urllib.request
r=Path.cwd();pub=r/'paper/materials/20261015-silent-codex1-controlled-resume';private=r/'ops/codex-ops/record-staging/20261015-1322';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((pub/'controller-before.json').read_text());now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(now,flush=True)
rows={};refs=[]
for stream in ['run-config','brain','codex-calls','decisions','states']:
 f=r/'logs'/f'{stream}.jsonl';selected=[]
 with f.open('rb') as h:
  h.seek(before['log_cutoffs_before'][stream]['bytes'])
  while True:
   off=h.tell();raw=h.readline()
   if not raw:break
   try:v=json.loads(raw)
   except ValueError:continue
   if b'HLAWCGM3KHVB' not in raw:continue
   selected.append((off,raw,v))
 rows[stream]=selected
config=rows['run-config'][0][2];brain=next(v for _,_,v in rows['brain'] if v.get('accepted') is True and v['label']=='event/choose');qid=brain['question_id'];trace=next(v for _,_,v in rows['codex-calls'] if v.get('question_id')==qid and v.get('outcome')=='answered');decision=next(v for _,_,v in rows['decisions'] if v['label']=='event/choose' and v['ts']>=brain['ts'])
pid=config['process']['pid'];assert pid==1296366 and config['restart'] is True and config['floor']==22 and config['code']['commit']==before['live_before'];assert config['codex_usage']['paid_credits']=='main-silent-codex1-20261015' and config['codex_usage']['start']['credits']>0 and config['codex_check']['ok']
assert brain['engine']=='codex' and brain['model']==trace['model']=='gpt-6.1-sol' and brain['effort']==trace['effort']=='xhigh' and trace['cache_request']['service_tier']=='default' and trace.get('reverted') is True
assert decision['decider']=='codex' and decision['fallback'] is False and decision['result']=='completed: Action completed.' and decision['chosen']=={'action':'choose_event_option','option_index':1} and brain['answer']['choice']=='o1'
oldmod=json.loads((pub/'mod-before.json').read_text())['data'];assert brain['payload']['event']['title']==oldmod['event']['title'] and brain['payload']['event']['text']==oldmod['event']['description'] and brain['payload']['situation']['gold']==oldmod['run']['gold'] and brain['payload']['situation']['hp']=='58/79 (73%)'
for _,_,row in rows['states']:
 if row.get('ts','')>=decision['ts']:
  post=row;break
else:raise AssertionError('POST_ACTION_STATE_NOT_YET_RECORDED')
proc=Path('/proc')/str(pid);fields=(proc/'stat').read_text().split(') ')[1].split();env=dict(x.split(b'=',1) for x in (proc/'environ').read_bytes().split(b'\0') if b'=' in x);assert fields[19]=='93390965' and proc.joinpath('cwd').resolve()==r/'.worktrees/live/agent';assert env[b'BRAIN_CODEX_HOME'].decode()==before['selector'] and env[b'BRAIN_CODEX_PAID_CREDITS']==b'main-silent-codex1-20261015' and env[b'BRAIN_CODEX_MODEL']==b'gpt-6.1-sol' and env[b'BRAIN_CODEX_EFFORT']==b'xhigh'
thread=trace['thread_id'];assert thread!=before['old_thread'];native=sorted((r/'ops/codex-ops/accounts/codex1/brain/sessions/2026/10/15').glob('*'+thread+'.jsonl'));assert len(native)==1;source=native[0];raw=source.read_bytes();meta=json.loads(raw.splitlines()[0]);assert meta['payload']['id']==thread and '/'+str(pid)+'-' in meta['payload']['cwd'];context=None
for line in raw.splitlines():
 v=json.loads(line)
 if v.get('type')=='turn_context':context=v['payload'];break
assert context and context['model']=='gpt-6.1-sol' and context['effort']=='xhigh'
name='new-native-thread/'+source.name+'.gz';dest=pub/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));(private/'original-scan'/source.name).write_bytes(raw)
native_ref={'source':str(source.relative_to(r)),'frozen':name,'bytes':len(raw),'sha256':sha(raw),'thread_id':thread,'session_cwd':meta['payload']['cwd'],'actual_model':context['model'],'actual_effort':context['effort'],'actual_tier':trace['cache_request']['service_tier'],'account_home_from_verified_controller':env[b'BRAIN_CODEX_HOME'].decode(),'account_identity_sha256':json.loads((pub/'account-preflight.json').read_text())['actual_native_account']['identity_sha256'],'old_cross_account_thread_not_reused':True}
chosen={'run-config':[config],'brain':[brain],'codex-calls':[trace],'decisions':[decision],'states':[rows['states'][0][2],post]}
for stream,values in chosen.items():
 for off,raw,value in rows[stream]:
  if value not in values:continue
  name=f'accepted-account-proofs/{stream}-{off}.jsonl.gz';dest=pub/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));plain=private/'original-scan'/f'{stream}-{off}.jsonl';plain.write_bytes(raw);refs.append({'stream':stream,'offset':off,'bytes':len(raw),'sha256':sha(raw),'frozen':name});assert gzip.decompress(dest.read_bytes())==raw
mod=urllib.request.urlopen('http://127.0.0.1:8080/state',timeout=10).read();assert json.loads(mod)['data']['run_id']==before['run'];(pub/'mod-after-resume.json').write_bytes(mod)
record={'at':now,'state':'controlled_same_save_resume_verified','run':'HLAWCGM3KHVB','release_id':'V5-R355','actual_live_code':config['code'],'restart':True,'same_floor_and_original_event_verified':True,'old_controller':before['old_controller'],'original_autoplay':before['original_autoplay'],'new_controller':{'pid':pid,'birth':fields[19],'ppid':int(fields[1]),'cwd':str(proc.joinpath('cwd').resolve()),'started':config['process']['started'],'home':env[b'BRAIN_CODEX_HOME'].decode(),'explicit_paid_credit_scope':env[b'BRAIN_CODEX_PAID_CREDITS'].decode()},'quota_admission_from_actual_new_run_config':config['codex_usage'],'codex_check':config['codex_check'],'original_question':before['source_question'],'new_question':qid,'first_accepted_at':brain['ts'],'first_accepted_label':brain['label'],'first_accepted_choice':brain['answer']['choice'],'first_decision':{'decision_id':decision['decision_id'],'ts':decision['ts'],'observed_ts':decision['observed_ts'],'chosen':decision['chosen'],'result':decision['result'],'decider':decision['decider'],'fallback':decision['fallback']},'actual_new_native_session':native_ref,'raw_refs':refs,'native_reverted_field':{'value':trace['reverted'],'meaning':'original session thread successfully reverted to base after the answered turn; not a rejected game decision','source':'agent/src/brain/engines/codex-session.ts SessionTurn.reverted and ask()'},'mode_switch_or_alternate_brain':False,'whole_run_V5S_natural_admission':False,'exclusion_reason':'mixed-account controlled continuation; raw outcomes and Codex engine provenance retained','next_whole_codex1_run':'pending ordinary autoplay after this saved run ends; not claimed started','current_run_game_result':'ongoing, not claimed won or ended','source_or_behavior_number_change':False}
(pub/'recovery-result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
segments=json.loads((pub/'account-segments.json').read_text());segments['new_segment'].update({'start':config['process']['started'],'controller_pid':pid,'birth':fields[19],'new_question':qid,'native_thread':thread,'first_accepted_at':brain['ts'],'actual_action_completed':decision['decision_id'],'source':'recovery-result.json'});(pub/'account-segments.json').write_text(json.dumps(segments,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'accepted_at':brain['ts'],'pid':pid,'question':qid,'thread':thread,'action':decision['chosen'],'result':decision['result'],'natural_admission':False}))

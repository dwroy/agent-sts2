import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261017-204302'
SCRATCH = ROOT / 'learner/runs/20261017-204308-eec5578a-eb10-44e3-8842-c84c7ddcdb00-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261017-201307-2ca0c0c5-48a3-4d4a-8717-f1f9b09f8586-fix-batch'


def git(*args, cwd=WORK):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


def ancestor(commit, head):
    result = subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, head])
    if result.returncode not in (0, 1):
        raise RuntimeError('Unable to verify ancestry')
    return result.returncode == 0


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


previous = json.loads((PREVIOUS / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
main = git('rev-parse', 'main').decode().strip()
live = git('rev-parse', 'HEAD', cwd=ROOT / '.worktrees/live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
snapshot = (SCRATCH / 'fix-queue-snapshot.md').read_bytes()
old_queue = (PREVIOUS / 'fix-queue-v4.snapshot.md').read_bytes()
assert queue == snapshot
assert queue.startswith(old_queue)
appendix = queue[len(old_queue):].decode()
assert appendix.count('\n- ') == 1 and appendix.lstrip().startswith('- [ ] **silent-0339续证')

source_paths = ['agent/src', 'agent/tools', 'agent/tests', 'agent/package*.json', 'agent/tsconfig*.json',
                'agent/vitest*', 'learner/*.ts', 'learner/*.py', 'learner/lib', 'learner/tasks', 'ops/*.sh',
                'ops/*.py', 'ops/codex', 'ops/tests', 'eval/*.py', 'eval/*.ts', 'eval/cost-config.json', 'knowledge/builders']
source_diff = git('diff', '--binary', previous['base'], base, '--', *source_paths)
(SCRATCH / 'source-since-previous.diff').write_bytes(source_diff)
assert not source_diff

paths = sorted(previous['source_blobs'])
trees = {}
for label, ref in [('base', base), ('live', live)]:
    rows = {}
    for entry in git('ls-tree', '-r', '-z', ref, '--', *paths).split(b'\0'):
        if entry:
            metadata, path = entry.split(b'\t', 1)
            rows[path.decode()] = metadata.split()[2].decode()
    trees[label] = rows

source_blobs = {}
for path in paths:
    assert path.startswith(('agent/', 'ops/', 'learner/', 'eval/', 'knowledge/builders/'))
    assert not Path(path).name.endswith('.env')
    content = (WORK / path).read_bytes()
    working_blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    assert working_blob == trees['base'][path] == previous['source_blobs'][path]['blob'], path
    source_blobs[path] = {'blob': working_blob, 'sha256': hashlib.sha256(content).hexdigest(),
                          'live_blob': trees['live'].get(path)}

fixed = []
for row in previous['already_fixed']:
    entry = {'item': row['item'], 'commit': row['commit']}
    for label, ref in [('base', base), ('main', main), ('live', live)]:
        entry[label + '_ancestor'] = ancestor(row['commit'], ref)
        assert entry[label + '_ancestor'], (row['commit'], label)
    entry['commit_files'] = git('show', '--format=', '--name-only', row['commit']).decode().splitlines()
    fixed.append(entry)

live_source_diff = git('diff', '--name-only', base, live, '--', *source_paths).decode().splitlines()
save('preexisting-main-live-source-differences.json', {
    'base': base, 'live': live, 'paths': live_source_diff,
    'note': '既有main/live差异；本批无新源码，不合并旧差异，不伪造检查或merged。',
})

fixed_lines = {
    784: '3b48088dec5fc6eafe576a1296bbdadde43432ee',
    817: 'db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26',
    900: 'bbc5b993a7524bbb8e80a975f204f8d193657b46',
    968: 'c1d84804956bedbd29a7f0e81294114e18415b9d',
    1024: '5baf663d7e6678efa3690e5a48329c4f8baee109',
    1029: '5b56a452bb9be14d620b368ec46974c1b57901ca',
    1034: '5b56a452bb9be14d620b368ec46974c1b57901ca',
    1040: '24c2e3a75b5db6bac76d6c924f86b7fcd9438316',
    1304: 'c57105ca66bd75c6d6952772dcf712399eda828b',
    1308: 'dd478f0b3e5a0f234f082972d21b203dbf8229d7',
    1322: '22efae55484bc2bdcc54e847a8dc40bb4888c4e2',
    1401: 'a473263eb35ce5bea8e06f1ee94f4da1ba880bc3',
    1403: 'c40e43fd25c200a01f4da94a4dac8db1b34664a8',
    1415: '660b194c950f017e356a4b3da952e127c7e5c768',
    1420: '660b194c950f017e356a4b3da952e127c7e5c768',
    1427: 'd959e176af7338ea2bca6f4ff9a39673b80e5fdf',
}
fixed_commits = {row['commit'] for row in fixed}
unchecked = []
for number, line in enumerate(queue.decode().splitlines(), 1):
    if not line.startswith('- [ ]'):
        continue
    entry = {'line': number, 'original': line}
    if number in fixed_lines:
        entry.update(disposition='已修窄范围；保留原宽项和历史失败', commit=fixed_lines[number])
        assert entry['commit'] in fixed_commits
    elif number in (952, 953, 954, 955, 1041):
        entry.update(disposition='独立架构或归因任务；超出普通纯bug批次')
    elif number == 959:
        entry.update(disposition='证据不足；原0332专用owner链，资源契约根因未修')
    elif number == 1009:
        entry.update(disposition='证据不足；stdout/stderr持久化已修，但不重发可能已送达的历史通知')
    elif number == 1110:
        entry.update(disposition='历史完整检查失败保持；固定测试确定性窄修已存在，负载/性能根因未证')
    else:
        entry.update(disposition='角色机制或打法策略；沿原独立strategy-proposal链，不新增重复提案')
    unchecked.append(entry)
save('unchecked-items-disposition.json', unchecked)

proposal_ids = {'silent-proposal-58ab473f6c814061', 'silent-proposal-c232010cd405fe44', 'silent-proposal-72e0c8b41d2f5ab8', 'silent-proposal-59b2e430bb7521d4',
                'silent-proposal-5aa2672bd7cd1bf4', 'silent-proposal-686d4e759478eebb',
                'silent-proposal-0a0b31e284e6793e'}
proposals = []
with (ROOT / 'paper/materials/learning/code-proposals.jsonl').open() as stream:
    for line in stream:
        row = json.loads(line)
        if row.get('id') in proposal_ids:
            proposals.append(row)
save('existing-proposals-readback.json', proposals)

(SCRATCH / 'working-tree.diff').write_bytes(git('diff', '--binary', base))
dirty = git('status', '--porcelain', '--untracked-files=all').decode().splitlines()
assert not dirty
audit = {
    'base': base, 'main': main, 'live': live, 'previous_base': previous['base'],
    'previous_audit': str(PREVIOUS / 'source-audit.json'),
    'queue_sha256': hashlib.sha256(queue).hexdigest(), 'previous_queue_sha256': hashlib.sha256(old_queue).hexdigest(),
    'queue_only_added_existing_strategy_evidence': True,
    'all_source_unchanged_since_previous': not source_diff,
    'already_fixed': fixed, 'source_paths_checked': len(source_blobs), 'source_blobs': source_blobs,
    'unchecked_items': len(unchecked), 'dirty_paths': dirty,
    'existing_live_source_diff_count': len(live_source_diff),
    'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
    'note': '本批未改源码、未提交、未合入；不借历史检查作为本批绿色结果，不关闭0332/自然效果/性能等宽父。',
}
save('source-audit.json', audit)
print(json.dumps({key: audit[key] for key in ['base', 'main', 'live', 'queue_sha256',
    'queue_only_added_existing_strategy_evidence', 'all_source_unchanged_since_previous',
    'source_paths_checked', 'unchecked_items', 'existing_live_source_diff_count', 'dirty_paths']}, ensure_ascii=False, indent=2))
print('既有修复提交均为base/main/live祖先：', len(fixed))

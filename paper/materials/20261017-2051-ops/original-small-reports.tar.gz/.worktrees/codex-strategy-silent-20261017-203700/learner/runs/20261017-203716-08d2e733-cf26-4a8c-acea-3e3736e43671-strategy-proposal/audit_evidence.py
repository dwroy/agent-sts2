"""核验本批原始证据封套，保存有边界的局部事实，不作策略拟合。"""
import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = json.loads((OUT / "dispatch.json").read_text())["runs"]


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def identity(row):
    values = [row.get("run_id"), row.get("run"), (row.get("state") or {}).get("run_id")]
    fp = row.get("fingerprint")
    if isinstance(fp, str):
        try:
            fp = json.loads(fp)
        except ValueError:
            fp = None
    if isinstance(fp, dict):
        values.append(fp.get("run"))
    found = {x for x in values if isinstance(x, str) and x and x != "run_unknown"}
    return next(iter(found)) if len(found) == 1 else None


streams = {}
checks = []
for directory in [OUT / "evidence", OUT / "evidence-extra"]:
    manifest = json.loads((directory / "evidence-manifest.json").read_text())
    for item in manifest:
        name = item["stream"]
        path = directory / (name + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = dict.fromkeys(RUNS, 0)
        rows = []
        with Path("/home/dw/Projects/agent-sts2/logs", name + ".jsonl").open("rb") as source:
            with path.open("rb") as selected:
                for encoded in selected:
                    digest.update(encoded)
                    envelope = json.loads(encoded)
                    source.seek(envelope["offset"])
                    raw = source.read(envelope["bytes"])
                    assert raw.endswith(b"\n")
                    assert hashlib.sha256(raw).hexdigest() == envelope["sha256"]
                    assert json.loads(raw) == envelope["row"]
                    assert identity(envelope["row"]) == envelope["run_id"]
                    assert envelope["offset"] + envelope["bytes"] <= item["source_size"]
                    counts[envelope["run_id"]] += 1
                    rows.append(envelope)
        assert counts == item["counts"]
        assert digest.hexdigest() == item["output_sha256"]
        streams[name] = rows
        checks.append({**item, "raw_offset_hash_verified": len(rows), "manifest_verified": True})
save("evidence-verification.json", checks)

states = streams["states"]
decisions = streams["decisions"]
by_line = {e["line"]: e for e in states}
dec_line = {e["line"]: e for e in decisions}


def snapshot(envelope):
    s = envelope["row"]["state"]
    run = s.get("run") or {}
    c = s.get("combat") or {}
    return {
        "line": envelope["line"], "run_id": envelope["run_id"], "ts": envelope["row"].get("ts"),
        "screen": s.get("screen"), "floor": run.get("floor"), "turn": s.get("turn"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "block": (c.get("player") or {}).get("block"),
        "potions": [{k: p.get(k) for k in ["index", "potion_id", "name"]} for p in run.get("potions", [])],
        "powers": (c.get("player") or {}).get("powers"),
        "hand": [{k: x.get(k) for k in ["index", "card_id", "upgraded", "resolved_rules_text"]}
                 for x in c.get("hand", [])],
        "enemies": [{k: x.get(k) for k in ["index", "enemy_id", "current_hp", "max_hp", "is_alive", "move_id", "powers", "intents"]}
                    for x in c.get("enemies", [])],
    }


# 原提案中明确指定的两帧，分别保存饮用、阶段及末轮边界。
important = [278577, 278578, 278579, 278580, 278581, 278402, 278403, 278404, 278405,
             278406, 278407, 280156, 280157, 280158, 280159, 280160, 280161, 280162,
             280206, 280207, 280232, 280233, 280262, 280263, 280313, 280314,
             280315, 280316, 280348, 280349, 280354, 280355]
assert all(n in by_line for n in important)
save("key-states.json", [snapshot(by_line[n]) for n in important])

pairs = [(272434, 272575), (272531, 272652), (272483, 272820),
         (273400, 273450), (274505, 274568), (274484, 274601)]
pair_facts = []
for a, b in pairs:
    left, right = dec_line[a]["row"], dec_line[b]["row"]
    assert dec_line[a]["run_id"] == dec_line[b]["run_id"]
    assert left.get("fingerprint") == right.get("fingerprint")
    pair_facts.append({"lines": [a, b], "run_id": dec_line[a]["run_id"],
                       "fingerprint_equal": True, "floor": left.get("floor"), "turn": left.get("turn"),
                       "rows": [left, right]})
save("paired-decisions.json", pair_facts)

# 各次重打只按一次局的相关轨迹记录，以可见的跨轮端点核净血差。
turns = []
for run_id in RUNS:
    attempt_by_floor = collections.Counter()
    previous = None
    grouped = []
    for envelope in states:
        if envelope["run_id"] != run_id:
            continue
        s = envelope["row"]["state"]
        r = s.get("run") or {}
        floor, turn = r.get("floor"), s.get("turn")
        if not s.get("in_combat") or not s.get("combat") or turn is None:
            previous = None
            continue
        if floor not in (17, 33):
            continue
        if previous is None or previous[0] != floor or turn < previous[1]:
            attempt_by_floor[floor] += 1
        key = (floor, attempt_by_floor[floor], turn)
        if not grouped or grouped[-1][0] != key:
            grouped.append((key, []))
        grouped[-1][1].append(envelope)
        previous = (floor, turn)
    for i, (key, rows) in enumerate(grouped):
        nxt = grouped[i + 1] if i + 1 < len(grouped) else None
        first, last = snapshot(rows[0]), snapshot(rows[-1])
        endpoint = snapshot(nxt[1][0]) if nxt and nxt[0][:2] == key[:2] and nxt[0][2] == key[2] + 1 else None
        same_enemies = endpoint is not None and [(x["index"], x["enemy_id"], x["max_hp"]) for x in first["enemies"]] == [(x["index"], x["enemy_id"], x["max_hp"]) for x in endpoint["enemies"]]
        turns.append({"run_id": run_id, "floor": key[0], "attempt_observed": key[1], "turn": key[2],
                      "first": first, "last": last, "next_turn": endpoint,
                      "net_hp_loss": first["hp"] - endpoint["hp"] if endpoint else None,
                      "net_enemy_hp_drop": sum(x["current_hp"] for x in first["enemies"]) - sum(x["current_hp"] for x in endpoint["enemies"]) if same_enemies else None,
                      "scope": "observed_net_endpoint_change; not complete damage attribution or a controlled counterfactual"})
save("boss-turn-endpoints.json", turns)

expected = [
    ("751FN9QM9MHQ", 17, 1, 2, 13, 9), ("751FN9QM9MHQ", 17, 3, 2, 18, 18),
    ("751FN9QM9MHQ", 17, 2, 7, 13, 12), ("751FN9QM9MHQ", 17, 4, 7, 23, 18),
    ("751FN9QM9MHQ", 17, 1, 13, 8, 17), ("751FN9QM9MHQ", 17, 6, 13, 2, 11),
    ("KV0JHNJCKXLS", 33, 4, 5, 0, 36), ("KV0JHNJCKXLS", 33, 5, 5, 0, 29),
    ("KEN58SH9SLZ6", 17, 4, 10, 15, 2), ("KEN58SH9SLZ6", 17, 5, 10, 21, 4),
    ("KEN58SH9SLZ6", 17, 4, 5, 7, 1), ("KEN58SH9SLZ6", 17, 6, 5, 5, 2),
]
for run, floor, attempt, turn, loss, damage in expected:
    selected = [x for x in turns if (x["run_id"], x["floor"], x["attempt_observed"], x["turn"]) == (run, floor, attempt, turn)]
    assert len(selected) == 1
    assert (selected[0]["net_hp_loss"], selected[0]["net_enemy_hp_drop"]) == (loss, damage)
save("observed-endpoint-checks.json", {"matched": len(expected), "expected": expected,
     "scope": "原字节端点核算，不是完整候选执行认证、生产测试或整战策略验证。"})

drink_lines = [274131, 274156, 274185, 274235, 274237, 274267, 274272]
assert all(n in dec_line for n in drink_lines)
save("ken-drink-decisions.json", [{"line": n, "row": dec_line[n]["row"]} for n in drink_lines])

sl = []
for e in streams["sl-attempts"]:
    r = e["row"]
    sl.append({"line": e["line"], "run_id": e["run_id"], **{k: r.get(k) for k in ["floor", "attempt", "turns", "result", "start_hp", "end_hp", "end_block", "incoming"]},
               "summary_last": ((r.get("summary") or {}).get("turns") or [None])[-1],
               "anchor": ((r.get("explore") or {}).get("target") or {}).get("anchor")})
save("sl-summary.json", sl)

summary = {"envelopes_verified": sum(x["raw_offset_hash_verified"] for x in checks),
           "streams": len(checks), "pairs_verified": len(pair_facts), "boss_turn_groups": len(turns),
           "runs": {run: {k: sum(e["run_id"] == run for e in rows) for k, rows in streams.items()} for run in RUNS},
           "production_tests": {"tsc": None, "vitest": None, "cases": None},
           "limitations": ["净HP变化不等于完整敌伤或毛输出；跨阶段和截断回合不填零。", "观察到的同指纹不同后继不是固定其余后续的整战反事实。", "同局SL尝试不独立计作验证局。"]}
save("audit-summary.json", summary)
print(json.dumps(summary, ensure_ascii=False))

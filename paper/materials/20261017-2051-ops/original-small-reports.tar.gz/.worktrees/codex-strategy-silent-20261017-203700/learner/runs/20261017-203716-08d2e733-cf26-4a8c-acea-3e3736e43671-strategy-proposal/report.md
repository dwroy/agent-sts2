# 静默猎手策略提案核验：20261017-203700

记录时间：2026-10-17T20:47:46+08:00。角色silent，新增核验范围仅六个派发的A10局。基线及最终HEAD：`94108ba3795a8a9774aff923aff71ba0771ed074`。初始工作树/index干净；普通任务已执行`git merge --no-edit main`，返回Already up to date。

## 身份和范围

根learn.json本批task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配，领取十个proposal_ids；没有research_request、implementation_request或proposal_repair。普通专题条件不成立（根deck-size请求绑定旧批20261010-150327），未读取该专题正文/manifest，也未转成纯研究。未领取队列其他id。身份与原提案快照见dispatch.json、proposals-original.json；十份原Markdown均逐字节SHA匹配，副本以.original.md保留。

派发局：751FN9QM9MHQ, KV0JHNJCKXLS, YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN, KEN58SH9SLZ6。runs.jsonl逐局核实均SILENT/A10；均为已结束局，失败不等于每场战斗失败。未读取其他角色知识，没有用预训练游戏结论补数据。

## 证据抽取和校验

使用本树learner/extract_evidence.py共用入口，默认六流与补充runs/fight-plans各自输出到evidence/及evidence-extra/，未覆盖原报告或旧截点。八流共8444原行；每行重新seek原日志offset，核bytes、含换行原字节SHA、JSON等值、显式身份唯一、source_size边界、逐局计数及输出SHA。run-plans用run字段收取，不把正文提及当所属局。两个manifest、evidence-verification.json和audit-evidence.log完整保存。fight-plans在本截点选中0，只说明这个截点无匹配，不断言原日志缺失。没有复写历史零行初稿。

| 局号 | 状态 | 决策 | SL记录 | 配置 | run-plans | brain | runs |
|---|---:|---:|---:|---:|---:|---:|---:|
| 751FN9QM9MHQ | 624 | 615 | 6 | 1 | 2 | 15 | 1 |
| KV0JHNJCKXLS | 686 | 669 | 7 | 1 | 5 | 32 | 1 |
| YQL8RZ8BWN1E | 582 | 571 | 6 | 1 | 3 | 18 | 1 |
| L9SGRBB5R698 | 653 | 635 | 6 | 1 | 3 | 16 | 1 |
| PU80F84P6HPN | 1064 | 1033 | 12 | 1 | 5 | 31 | 1 |
| KEN58SH9SLZ6 | 558 | 548 | 6 | 1 | 3 | 18 | 1 |

六组决策同指纹已核，十二个跨轮净资源端点与原提案数值一致；见paired-decisions.json、observed-endpoint-checks.json。另保存481个F17/F33观察轮组及其端点（boss-turn-endpoints.json）；这只是帧归组和端点核算，不是481个独立样本、完整候选认证或生产消费者成功。

## 支持、反例及未知

1. **751FN9QM9MHQ，F17，T2/T7/T13**。决策272434/272575、272531/272652、272483/272820各自同指纹。T2首/第三试净扣敌9→18、净损13→18；T7第二/第四试净扣12→18、净损13→23；T13首/末试净扣17→11、净损8→2。T7未决弃牌保守计入的绝对失血不等于新增实际血价，实际差10血仍成立。六试全败，后续抽牌与动作改变；不能从局部换线推整战因果，也不能拟固定5、6或10血门槛。账本silent-0079、0176。
2. **751FN9QM9MHQ，F13，T3**。决策272361的用药plan2、当前轮不喝plan3和整战无药plan5均即时损8，五轮均8/8结束。plan3后轮7/8样本仍喝药；plan5才是明确整战无药参考，平均存活结束回合约2.9，对用药约2.3。实际执行用药（272362及278403—278407），不是两条实盘对照。缺表成本0不等持有价值0；缺留到Boss的支线，不能从Boss空栏失败倒推持有价或断言本次饮用错误。账本0019、0021、0005、0007、0129、0176；经验扩展另含0020、0006、0046。
3. **KV0JHNJCKXLS，F33，T5**。决策273400/273450同指纹，第四/第五试实际跨轮净扣敌36→29、玩家均零净损，下一轮毒20→13。第五试273451又阻止补打。候选B2均0，不能把删输出叫已观察保血收益。T4存在毒后敌回血，净血差不能当毛伤害。首试T1从最早开场帧44到下一轮46包含开场+2，必须与敌方损伤分账；本报告不把它写成净损0，也不否定无攻击损血的原说法。账本0102、0019、0020。仍缺保持后续不变的整战验证。
4. **YQL8RZ8BWN1E，F17，T9/T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17**。YQL末次states280160→280161毒药使占位体毒2→8，HP26、挡13、来袭41、占位HP999999999均未变，26+13−41=−2只是当下资源不足，不是完整候选结算。YQL六试均未赢；L9/PU的旧SL参考仍列近十亿占位血。PU第五试有真实won/2血，但既有路线与后续动作也变，不能证明某种新排序的因果收益。原记录大血不能独立表示胜负。账本0017、0250、0011、0027、0046、0019、0020。没有提前用药或改序受控胜负。
5. **KEN58SH9SLZ6，F3 T2/F4 T1/F5 T2/F11 T1、T2/F15 T1**。七个use_potion请求决策274131、274156、274185、274235、274237、274267、274272分别与280206→280207、280232→280233、280262→280263、280313→280314、280315→280316、280348→280349、280354→280355的槽位变化对应。两次攻击药和技能药的即时回执为pending，后帧是CARD_SELECTION；不能把该回执写成完整效果已经认证。其余四个请求completed。进入Boss75/86空栏属于实际入口，不给出七瓶保留价值。账本0019；缺随机选牌和重问后整条收益的归属及不喝支线。
6. **KEN58SH9SLZ6，F17，T10/T5**。决策274505/274568同指纹，第4/5试T10净扣敌2→4、净损15→21；对应states280588—280592与280651—280655。决策274484/274601同指纹，第4/6试T5净损7→5，但步法敏捷从T5延至T9，追加小刀后净扣1→2。T8双防御10挡、无敏捷，反驳“省即时血必然更好”。同局六试不是六个独立验证局；完整后续不同，不把T15/T13差异归给单步。账本0079、0021、0125、0005、0176。

以上都是原样本复核，未新增独立支持局、未改历史claim/首证/先验/经验版本。没有新的机制异议或与既有游戏知识相反的结论；开场回血和pending状态是范围澄清。缺失的受控支线保持未知。

## 当前源码覆盖和实际live祖先

源码快照见source-audit.json：15个相关生产文件逐blob/SHA核对；live读取快照为`3d691cff96dedd19855b00f4e9d448c43fe1d219`。9文件字节相同，6文件仅历史Roy/Dai署名注释不同，完整binary diff保留base-vs-live-source.patch；source-scope-verification.json另列限定等价范围。没有声称六局的+dirty执行树被完整重建，当前源码核验也不是原运行版本验证。

以下实际源码提交均已单独核为该live快照祖先，只作已完成子项的证据，不登记整项duplicate：

| 源码提交 | 已有覆盖 | 尚未交付的本批要求 |
|---|---|---|
| be69855995737d6f381adb10bf248964832da24b | Silent候选answer/before_sl/after_sl和请求动作审计 | execution_status=pending_dispatch、actual_turn=null，不给完整实际收益归属 |
| 1a00f10af95c78dfbf75de318a0083256110cf8a | 异鱼持牌失血及弃牌未决提示 | 模型预测不等实际持牌结算或完整候选认证 |
| c4670f4f416c7d93e192e889c5080e7e4e0e733f | 未知持有价值、当轮无药与整战无药抽样范围 | 不给跨战留药实际反事实或持有价拟合 |
| b14880d1b1780d03e4c1c87b5afdc2a1e08fd456 | 巨兽当前自爆阶段及一次毒药观察 | 不改死亡闸、SL参考顺序或认证改序收益 |

silent-hp-guard-audit.ts的actual_outcome也为空；sl/explore.ts的anchorRank仍先存活轮再原enemyHp排序，阶段解释另列；未因读到body_hp=0就声称占位血排序已修。原SL在未强制notWorseOnly时仍允许更差未试线，这是现行规则；本次没有新的受控数据去改它。没有任何一个宽提案可以仅凭上述子项完整登记implemented/duplicate。

## 十项处置

| 提案ID | 账本 | 证据局/层/回合 | 结果与等待条件 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | silent-0079, silent-0176 | 751 F17 T2/T7/T13 | waiting：751 F17 T2/T7/T13配对净血差已核；现有候选审计actual_turn仍为空，缺逐来源兑现、完整候选归属及固定后续的整战对照，不能拟SL探索血价门槛。 |
| silent-proposal-85929bdfc8a3fc1b | silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176 | 751 F13 T3、F17 T7/T13/T17 | waiting：751 F13 T3用药与整战无药参考均为8/8模拟胜，实盘只执行用药；缺不喝/留药后战实果及弃牌后的联合校准，已有持牌/未知持有价提示不关闭整项。 |
| silent-proposal-efd9f83ee9e1a6dc | silent-0079, silent-0176 | 751 F17 T2/T7/T13 | waiting：与366288801d9150d9共享751同一局三组对照；尚缺完整执行成本归属和受控整战后继，经验来源重复不增加独立验证局。 |
| silent-proposal-131042659448ae74 | silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176 | 751 F13 T3、F17 T5/T7/T13/T17 | waiting：751敏捷、毒、荆棘、呼唤等分项事实有据，已有两个诊断子项；缺多来源联合实际校准、完整候选归属和跨战留药对照，不能以局部实现关闭宽项。 |
| silent-proposal-990f054036609447 | silent-0102, silent-0019, silent-0020 | KV F33 T1/T4/T5 | waiting：KV F33第4/5试T5同指纹净扣36→29且当轮均零净损，毒20→13；缺敌回血/能力逐来源完整结算、受控胜线和独立验证，不改SL或路线门槛。 |
| silent-proposal-e18d3f18e6cac2a0 | silent-0017, silent-0250, silent-0011, silent-0027, silent-0046 | YQL F17 T9/T10；L9 T14；PU T17 | waiting：YQL F17 T10残壳毒2→8而26血/13挡/41来袭未变，L9/PU证实占位血；阶段提示已存在，缺同轮自爆末态及完整后继的受控排序验证，不直接归零占位HP改序。 |
| silent-proposal-9733bb80f445aeae | silent-0017, silent-0019, silent-0020, silent-0250 | YQL F17 T9/T10；L9/PU F17 | waiting：与e18d3f18e6cac2a0共享YQL/L9/PU阶段证据；PU已有赢尝试但未隔离策略和后续，缺改序/提前用药/路线的受控验证，阶段说明不等终局目标交付。 |
| silent-proposal-c51468c5e8ba6668 | silent-0019 | KEN F3 T2/F4 T1/F5 T2/F11 T1/T2/F15 T1 | waiting：KEN七次用药请求及逐槽有药→空已核，三次回执pending后进入选牌；缺随机选牌/发光水重问的完整收益归属、同题不喝与留至Boss支线，不拟持有价。 |
| silent-proposal-86a7db08d1a31976 | silent-0079, silent-0021, silent-0125, silent-0005, silent-0176 | KEN F17 T2/T5/T10 | waiting：KEN F17第4/5试T10净损15→21、净扣2→4，第4/6试T5净损7→5但敏捷延至T9；缺完整候选/能力收益归属、固定后续整战和独立验证，保留排序与护栏。 |
| silent-proposal-e282a9131b99129a | silent-0021, silent-0079, silent-0125, silent-0176 | KEN F17 T5/T10 | waiting：与86a7db08d1a31976共享KEN两组同指纹对照；六试只是一局，局部血价不足认证后续胜因，缺受控整战及后期独立局，不拟统一6血/2伤阈值。 |

## 预期行为和可验证的下一步

当前保留既有候选、排名、药水价、HP护栏、SL探索和终局规则。诊断子项已有实现，不再重写或生成重复提案id。后续按每项现有id补足完整候选与实际动作绑定、抽牌/选牌/重问后的逐来源兑现；SL比较需共同冻结底板、候选、随机输入和完整后继，同时保存原线失败的不确定性。巨兽比较还须同轮最终血挡/来袭及可靠阶段，不能仅把占位血归零后看测试通过。药水比较要完整不喝及保留后战的分支，不能以模拟8/8或空栏入口代替实盘收益。

本批不拟合门槛；六局只能作既有事实的固定核验，相关SL不拆成训练/验证集。若后续拟合，使用更早独立silent局，按真实时间留后期独立局验证，并报告反例、未知和适用进阶。只复核数据，不增加模型、求解器、模拟或游戏请求。

预期影响仅是保留可靠证据和明确等待条件，不承诺胜率变化。回退不涉及生产代码；所有原提案/原日志及本次过程材料保留。

## 账本、检查和合入

只经根learner/ledger.py update给现有相关账本追加本批proposal/report路径与waiting说明，by=learner:strategy-proposal；不增加重复证据或新claim，不降级既有shipped状态、不填写新shipped/version。ledger-update-input.jsonl和ledger-update.log保存实际CLI输入/结果，ledger-readback.json保存读回保护字段核验。十个原代码提案id继续保留，未向code_proposals.py另建重复id；队列处置由proposal_results交调度器，不直接写队列或learn.json。

本次生产源码、知识、任务模板及Git index零改动。没有代码提交或合入，不新增eval版本或规则上线双通知；无阻塞的源码提交需ops兜底。fixes=[]、merged=null，implementation_domains=[]。未做撤源码失败/恢复通过，也未跑tsc/vitest：源码无改动，三个tests字段均null。8,444行封套、六组同指纹与十二端点是证据校验，不能冒作生产测试绿色或消费者认证。提交前扫描不适用（无提交），仍对本批材料执行脱敏gitleaks扫描并保留实际结果。

探索过程中首次只读首帧检查因combat为null发生TypeError；后续脚本显式处理null并完整成功。另一次旧衍生文件resources-audited-entities.json原路径不存在，未将其当成原日志缺失，直接按共用入口核原件。两点保留在回报，不作生产bug或本批测试失败。v1四组同指纹核验及其脚本/日志/结果保留，最终新增T13和KV两组后为六组，无历史失败被改写。

运维交付：本目录proposal.md、report.md、report.json、proposal-results.json和两份证据manifest。每项waiting都有具体缺口，不关闭学习父要求、不声称经验新入库或大脑自然采用。未运行play，不联网、不推送、不修改其他角色知识或运维prompt。最终工作树检查及材料清单见completion-check.json、artifact-manifest.json。

最终核验：gitleaks实际退出0、0泄漏（扫描约168.05 MB）；16条CLI追溯已实际读回，claim/首证/进阶/prior/evidence/status/version均保持。十项结果与派发id集合精确相同。HEAD保持完整base，工作树及index干净，无源码/知识提交、合入或新增发布。

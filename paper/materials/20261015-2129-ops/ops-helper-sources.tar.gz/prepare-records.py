from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import tarfile

root = Path.cwd()
stage = root / 'ops/codex-ops/record-staging/20261015-2129'
public = root / 'paper/materials/20261015-2129-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def git(*args, cwd=root):
    return subprocess.check_output(['git', '-C', str(cwd), *args], stderr=subprocess.PIPE)


def load(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


exec((root / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
batches = load(root / 'ops/codex-ops/learn.json')['batches']
ledger_path = root / 'paper/materials/learning/ledger.jsonl'
global_rows = [(raw, json.loads(raw)) for raw in ledger_path.read_bytes().splitlines(keepends=True) if raw.strip()]
all_owned = []
archive_paths = []
source_manifest = []
receipts = []
for suffix, owned_count, raw_count, check_count in [('', 16, 8444, 68), ('-s2', 31, 19929, 38)]:
    batch_id = '20261015-211145' + suffix + '-strategy-proposal'
    batch = batches[batch_id]
    report = batch['report']
    scratch = Path(report['report']).parent
    assert batch['state'] == 'done' and batch['rc'] == 0 and batch['proposal_audit_errors'] == []
    assert batch['no_change_proposals']['dispositions'] == report['proposal_results']
    assert len(report['proposal_results']) == 10 and all(row['state'] == 'waiting' for row in report['proposal_results'])
    assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == []
    assert all(value is None for value in report['tests'].values())
    assert git('rev-parse', 'HEAD', cwd=batch['worktree']).decode().strip() == report['base']
    assert not git('status', '--porcelain', '--untracked-files=no', cwd=batch['worktree']).strip()
    native = runtime(batch_id, report, (root / 'ops/codex-ops/learner' / (batch_id + '.out')).read_text(), batch['worktree'])
    evidence_manifest = load(scratch / 'evidence/evidence-manifest.json')
    assert sum(sum(row['counts'].values()) for row in evidence_manifest) == raw_count
    if not suffix:
        completion = load(scratch / 'completion-readback.json')
        assert completion['base'] == report['base'] and completion['git_clean']
        assert completion['tracked_diff_bytes'] == 0 and completion['proposal_results'] == 10
        assert completion['evidence_rows'] == raw_count and completion['material_checks'] == check_count
        assert completion['ledger_updates'] == owned_count
        for path, expected in completion['files'].items():
            assert sha((scratch / path).read_bytes()) == expected
        checks = load(scratch / 'verification.json')
        assert checks['raw_rows_verified'] == raw_count and checks['passed']
        assert len(checks['checks']) == checks['check_count'] == check_count
        assert all(row['passed'] for row in checks['checks'])
        source = load(scratch / 'source-readback.json')
        inputs = [json.loads(raw) for raw in (scratch / 'ledger-updates.jsonl').read_text().splitlines()]
        cli_ids = (scratch / 'ledger-cli.log').read_text().split()
    else:
        completion = load(scratch / 'completion-validation.json')
        assert completion['valid_result'] and completion['base'] == report['base']
        assert completion['working_tree_clean'] and not completion['production_tests_run']
        assert completion['new_commits'] == [] and completion['merged'] is None
        assert completion['proposal_count'] == 10 and completion['ledger_links'] == owned_count
        assert sha((scratch / 'report.md').read_bytes()) == completion['report_sha256']
        assert sha((scratch / 'proposal.md').read_bytes()) == completion['proposal_sha256']
        checks = load(scratch / 'material-checks.json')
        assert checks['count'] == len(checks['checks']) == check_count
        assert all(row['actual'] == row['expected'] for row in checks['checks'])
        verification = load(scratch / 'byte-verification.json')
        assert verification['total_rows'] == raw_count and all(row['byte_checks'] for row in verification['streams'])
        assert load(scratch / 'material-audit-result.json')['verified_rows'] == raw_count
        identities = load(scratch / 'run-identities.json')
        assert len(identities) == 15 and all(row['character'] == 'SILENT' for row in identities.values())
        assert sorted(row['ascension'] for row in identities.values()) == [1, 7, 9] + [10] * 12
        source = load(scratch / 'source-audit.json')
        inputs = [json.loads(raw) for raw in (scratch / 'ledger-update.jsonl').read_text().splitlines()]
        cli_ids = (scratch / 'ledger-update.stdout').read_text().split()

    equal = 0
    for row in source['files']:
        original = git('show', report['base'] + ':' + row['path'])
        old_live = git('show', source['live'] + ':' + row['path'])
        assert sha(original) == row['head_sha256'] and sha(old_live) == row['live_sha256']
        assert original.replace(b'Roy', b'Dai') == old_live.replace(b'Roy', b'Dai')
        equal += original == old_live
        commit = row['last_source'] if suffix else row['last_commit']
        git('merge-base', '--is-ancestor', commit, source['live'])
    assert len(source['files']) == (16 if suffix else 12) and equal == (10 if suffix else 11)
    for row in source.get('narrow_source_commits', []):
        for target in [report['base'], source['live']]:
            git('merge-base', '--is-ancestor', row['commit'], target)

    owned = [raw for raw, row in global_rows if row.get('op') == 'update' and any(all(row.get(key) == value for key, value in item.items()) for item in inputs)]
    assert len(inputs) == len(owned) == owned_count
    assert all(set(json.loads(raw)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for raw in owned)
    assert len(cli_ids) == owned_count and set(cli_ids) == {json.loads(raw)['id'] for raw in owned}
    if not suffix:
        original_owned = [json.loads(raw) for raw in (scratch / 'ledger-own-events.jsonl').read_text().splitlines()]
        assert original_owned == [json.loads(raw) for raw in owned]
        readback = load(scratch / 'ledger-readback.json')
        assert readback['own_cli_events'] == owned_count and readback['protected_fields_preserved']
        assert readback['original_prefix_preserved'] and readback['links_and_notes_verified']
    else:
        readback = load(scratch / 'ledger-readback.json')
        assert readback['returncode'] == 0 and readback['count'] == owned_count
        assert readback['protected_fields_unchanged'] and readback['existing_where_preserved']
        for row in readback['rows']:
            with ledger_path.open('rb') as handle:
                handle.seek(row['offset'])
                raw = handle.read(row['bytes'])
            assert sha(raw) == row['sha256'] and raw in owned
    all_owned.extend(owned)
    receipt = dict(batch=batch_id, original_report=report, native=native,
        canonical_no_change_gate=batch['no_change_proposals'], original_completion=completion,
        original_evidence_rows=raw_count, original_material_assertions=check_count,
        original_evidence_manifest_sha256=sha((scratch / 'evidence/evidence-manifest.json').read_bytes()),
        original_pinned_live=source['live'], source_leaves=len(source['files']), equal_leaves=equal,
        historical_name_comment_differences=len(source['files']) - equal,
        source_base_and_old_live_leaf_shas_and_ancestors_verified=True,
        no_transpilation_or_current_deployment_equivalence_claim=True,
        trace_only_cli_rows=owned_count, original_cli_ids_verified=True,
        original_material_checks_not_reexecuted=True, production_tests_not_run=True,
        native_gap='Learner did not independently verify native model/effort. Ops now verified actual Sol6.1/xhigh, input/lease and original workspace-write/no-network; no runtime settings changed.',
        original_failures_and_limits=('Original T7 draft confused question damage9/15 with whole-turn12/18; delta6 unchanged. Original failure/v1 and corrected v2 retained. Actual turn/full follow-up, potion holding value and independent whole-fight comparisons remain unknown.' if not suffix else 'Original EPERM and missing TypeScript7 transpile API attempts retained; no transpiled equivalence or product failure claim. Mixed ascensions, pending versus completed, first snapshots versus actionable/terminal frames and current-turn versus future sandpit windows remain separate. Full candidate execution and controlled potion/route follow-ups unknown.'),
        no_new_source_merge_release_game_actions_or_learning_parent=True)
    write(public / ('s2-batch-readback.json' if suffix else 'batch-readback.json'), receipt)
    originals = [path for path in scratch.iterdir() if path.is_file()]
    originals += [scratch / 'evidence/evidence-manifest.json']
    originals += [root / 'ops/codex-ops/learner' / (batch_id + extension) for extension in ['.out', '.err']]
    for path in originals:
        raw = path.read_bytes()
        archived = len(raw) < 350000
        source_manifest.append(dict(path=str(path.relative_to(root)), bytes=len(raw), sha256=sha(raw), archived=archived))
        if archived:
            archive_paths.append(path)

assert len(all_owned) == len(set(all_owned)) == 47
old = git('show', base + ':paper/materials/learning/ledger.jsonl')
seen = set(old.splitlines())
added = b''.join(raw for raw in all_owned if raw.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('ops_owned_ledger', root / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
fold = lambda raw: module.fold([(number, json.loads(line)) for number, line in enumerate(raw.splitlines(), 1) if line])
before, after = fold(old), fold(old + added)
assert set(before) == set(after)
for ident in before:
    assert {key: value for key, value in before[ident].items() if key not in ['where', 'notes', 'history']} == {key: value for key, value in after[ident].items() if key not in ['where', 'notes', 'history']}, ident
    for key, values in before[ident]['where'].items():
        assert all(value in after[ident]['where'][key] for value in values)
write(public / 'completion.json', dict(batches=[row['batch'] for row in receipts], waiting_proposals=20,
    trace_only_cli_rows=47, newly_committed_cli_rows=len(added.splitlines()), protected_fold_preserved=True,
    original_rows_by_batch=[8444, 19929], original_material_checks_by_batch=[68, 38],
    overlaps_not_independent_samples=True, no_source_tests_merge_release_dataset_or_runtime_changes=True))
write(public / 'original-artifact-manifest.json', source_manifest)
with tarfile.open(public / 'original-artifacts.tar.gz', 'w:gz') as archive:
    for path in sorted(set(archive_paths)):
        relative = str(path.relative_to(root))
        copy = stage / 'archive-scan' / relative
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(path.read_bytes())
        archive.add(path, arcname=relative)

at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
decision = f'\n- {at} 运维codex：2129原211145两策略批次done0/no-source门禁核，各十项共20项waiting；f328干净WT无新增提交/合入，testsnull/mergednull/域空，不空合/发号/补测或复派。六A10原8444行/68材料检查与另15局（A1/A7/A9各1及A10十二）19929行/38检查为原学习者材料读回，不重跑/合计独立样本或当生产全检/收益；旧livefe646265的12/16叶逐SHA和真实源祖先核，11同1注释差/10同6注释差保留，仅Roy-Dai历史文本差不冒转译或当前部署等价。47原CLI仅where/note，逐输入/输出ID及s2原offset/bytes/SHA核；私有待提交fold的claim/首证/prior/evidence/status/version等所有非追溯字段不变，既有where保留，不重复CLI。实际native Sol6.1/xhigh/input/lease及workspace-write/no-network核，原学习者未独立读native与模板high边界不改。首批T7题面9/15误当整轮净扣的原失败/v1及12/18修正保留，delta6不变；s2的Node EPERM与TS7缺转译API原失败不当产品bug或tsc成功。候选预测/首动作回执/持有值未知/整轮归属、巨兽占位HP排序及受控整战/路线留药后继继续原链，窄源码不关闭宽父。无新知识/反证/复盘/源码，不刷新论文、不改当前局/账号home模型预算队列prompt，不等待未来事件；仅提交本人回执及47所属追溯行，保并行脏记录。证据paper/materials/20261015-2129-ops/。\n'
note = f'\n- {at} [ops 策略处置] 原211145两批共20项继续waiting，47条CLI仅补提案追溯，原知识/状态/版本保护同验；材料首失败与修正保留。无新源码/合入/行为号，不重派或补测；实际原生Sol6.1/xhigh和隔离身份已核。回执paper/materials/20261015-2129-ops/。\n'
appends = {'paper/materials/decision-log.md': decision, 'ops/inbox-dev.md': note}
write(stage / 'own-appends.json', appends)
for path, text in appends.items():
    with (root / path).open('ab') as handle:
        handle.write(text.encode())

helper_manifest = []
with tarfile.open(public / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    for path in [stage / 'prepare-records.py', stage / 'seal-records.py', root / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = path.read_bytes()
        copy = stage / 'helper-scan' / path.name
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        archive.add(path, arcname=path.name)
        helper_manifest.append(dict(path=str(path.relative_to(root)), bytes=len(raw), sha256=sha(raw)))
write(public / 'ops-helper-manifest.json', helper_manifest)
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}
values['paper/materials/learning/ledger.jsonl'] = old + added
for path in public.iterdir():
    if path.is_file():
        values[str(path.relative_to(root))] = path.read_bytes()
entries = []
for path, raw in values.items():
    copy = stage / 'final-files' / path
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(stage / 'record-manifest.json', dict(base=base, paths=entries))
check = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(stage / 'final-files/paper/materials/learning/ledger.jsonl')}, capture_output=True)
(public / 'final-ledger-check.log').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
print(json.dumps(dict(waiting=20, owned_cli_rows=47, newly_committed_cli_rows=len(added.splitlines()), ledger_check=0, native_verified=True, source_leaves_verified=28)))

"""Write this batch's evidence-qualified dispositions and ledger link requests."""
import json
import subprocess
from pathlib import Path

P = Path(__file__).resolve().parent
D = json.loads((P / "dispatch.json").read_text())
Q = json.loads((P / "proposals.json").read_text())
BASE = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
WHEN = (P / "recorded-at.txt").read_text().strip()
REASONS = [
    "KEN七饮均有后帧耗瓶证据，含三条原pending；缺F15不饮用及同入口同后继留药至Boss的完整成对结果，无法校准持药价。",
    "TXZ第二/三试T6少损3也少扣敌9，首胜4血仍在F49开场死亡；缺保持抽序、生成、药栏一致的两战通关替线，开场扣血旧实现不关闭连战/SL宽项。",
    "WQ同盘T9多付9血换15伤，末试T7付4血换沙坑一轮；缺攻防与沙坑双边界的完整受控后继及独立胜局，不拟新SL血价门槛。",
    "42饮的3/2/0生成分支与现有6403fdcd源码相符；缺计划妥当保留、穿插出刀、整候选实际派发及SL恢复的联合校准，整项不足duplicate。",
    "王室猛毒开场4血子项已有实际live祖先e8b4bb32及ebf8c57e；缺留药、路线和SL完整后继对照与未知回血/复活组合顺序，资源价值宽项继续等待。",
    "Q6早喝敏捷少损候选没有完整实打后继，1913路线的实际锻造条件也变；缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战，不能校准终局或持药权重。",
    "Q6普通紧勒103→95→85→85→83→80已由5c7105ff限定实现；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准，普通子公式不关闭整项。",
    "1913 F29胜后46接F31精英死亡、Q6 F8胜后2接F9死亡均实证；缺另一营火、事件、路线和用药时机的受控完整结果，不由失败链拟合资源权重。",
    "NHA可操作30血下首试1损/8敌净扣、第五试7损/24敌净扣且第六试重放；缺同预算饱和排序校准、跨弃牌整候选归属及成对完整后继，六败不足确定新SL阈值。",
    "NHA首次X1萎靡−2力/2弱及三局毒窗口仍成立，蟹朝向窄分支已有ec29ea34/f2c7cc1a；缺油灯首次消费身份、跨动作/新战/SL恢复联合输入，以及其他X值/升级组合与能力整战后继。",
]
EVIDENCE = [
    "KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1–2/F15T1；d274131/274156/274185/274235/274237/274267/274272；F12 s280336–337、F16 s280382–383，F17六试入口。",
    "TXZ6RVMQA09D A10 F48第二/三试T6，s281479–484/281535–539；F48T10→F49T1 s281563–566。",
    "WQZVENQ7DTRP A10 F33第二/三试T9 s282075–079/282144–148；末试T7 s282330–336，对照第二试s282066–072；末态s282367。",
    "本提案原9局/42饮，角色与进阶均核；WQZVENQ7DTRP A10 F33第五/六试T11 d276102–104/276161–163，s282292–296/282352–357。",
    "TXZ6RVMQA09D A10 F43/45/46/48/49开场、F48T10后4血与F49T1死亡；WQZVENQ7DTRP F33T7/T9双向血价。",
    "Q6M2Y34MWKRE A10 F2T1候选、T3实饮、F8T1速度药/F8T8赢后2血/F9T2死（s282907/282913/282921）；1913SE84AXQF F24/F28/F29/F31资源链（s282745/282755）。",
    "Q6M2Y34MWKRE A10 F8T4 s282887–892；1913SE84AXQF A10 F17再生/F31T2弃磨蚀、T3/T4残杀千足虫；旧低阶公式不在本批重验全历史。",
    "1913SE84AXQF A10 F17胜后14、F19/F23/F24/F28/F29至F31；Q6M2Y34MWKRE A10 F3事件/F7休息/F8赢损55/F9T2死。",
    "NHA2KW0RB7VP A10 F33首试T1→T2 s283391–397、第五试s283478–483、第六试s283502–507；s283390空手28血不冒可操作30血。",
    "NHA2KW0RB7VP A10 F17T1 s283147首次毒10、F33T1 s283395萎靡−2力/2弱及T2朝向；K3676LU8B0UH A1 F30T2 s217009–010毒8；SADL3CGYTGSR A7 F45T1 s232562–563毒10。",
]

results = [{"id": ident, "state": "waiting", "reason": REASONS[i]} for i, ident in enumerate(D["proposal_ids"])]
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261015-211145-s2-strategy-proposal",
          "base": BASE, "runs": D["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None}, "code_proposals": D["proposal_ids"],
          "implementation_domains": [], "proposal_results": results, "report": str(P / "report.md")}
(P / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

intro = f"""# 本批静默策略提案逐项复核

记录时间：{WHEN}（写前已运行date）。批次：20261015-211145-s2-strategy-proposal。
base：`{BASE}`。开始git status干净，普通任务按要求执行git merge --no-edit main，返回Already up to date。
本批reason=proposal、task=strategy-proposal、character=silent，精确工作树绑定；有10个proposal_ids，无research_request/implementation_request，不承接其他专题或队列。

结论：10项全部waiting。没有新增足以修改策略的受控后继证据，部分子项已有源码但不覆盖宽提案。没有新源码/知识修改、提交、测试套件或live合入；fixes=[]、merged=null、tsc/vitest/cases均null，不制造版本或shipped。
仅复核既有提案，原文按队列SHA256逐一核对并以各ID.md保存在本目录；不另建重复提案、不重写复盘、不关闭学习父要求。

## 逐项处置

"""
sections = []
for i, ident in enumerate(D["proposal_ids"]):
    q = Q[ident]
    sections.append(f"""### {i + 1}. {ident}

原摘要：{q['summary']}。
原提案：[冻结原文]({ident}.md)，SHA256 `{q['proposal_sha256']}`。
原账本：{', '.join(q['ledger'])}。来源任务：{q['source_task']} → strategy-proposal。
本批核实证据：{EVIDENCE[i]}

处置：waiting。{REASONS[i]}

旧规则/新行为：本批保留现行生产行为；原提案设想及其限制保持，未将未实现宽项当作已启用。以后只有该缺口的本角色固定输入与完整后继可复核后，再实现独立提交及撤源码失败/恢复通过，按原沙箱和live流程验收。此项无新commit。

""")
common = """## 证据、反例与验证边界

原始日志仅通过本树learner/extract_evidence.py共用入口抽取，15个关联局（10个派发锚点加原提案的5个关联局）全部用runs.jsonl核角色，A1一局、A7一局、A9一局、A10十二局分列。未展开其他角色知识，没有把正文提及作为所属局。

抽取总19,929行：states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、runs15、fight-plans0。evidence/evidence-manifest.json保存每流source_size/计数/输出SHA，每行保留原source/line/offset/bytes/SHA；byte-verification.json逐行seek原只读日志复核字节、JSON、显式身份和冻结范围通过。源全文件扫描中states与decisions各2条无效JSON、brain1条，保留计数，不当作所选局缺证；无不完整尾行。fight-plans在2233957字节截点选中0行，只说明该截点未选到，不宣称原日志缺失。

audit_evidence.py只生成材料摘要和动作前后帧链接；combat-observation-segments.json是观测片段，不保证每个first是可操作入口、last是战斗最终结算。判断赢战退出采用实际reward/后帧，死亡不以last正HP冒充剩命；动作回执pending和completed分开。

validate_materials.py的38项断言通过（material-checks.json/log），只检查冻结实帧事实，不调用LLM、网络、boss模拟池或刷新知识，不是tsc/vitest或生产撤码负控。具体反例约束如下：

- KEN七饮均耗瓶，原4completed/3pending原样保留；F15零净损已经花两瓶，不能推未喝也零损。两次真实回复27/29含上限变化；五次SL恢复348分列，六次Boss空栏只算一个局。原提案105局历史分母本批未重新全量分析。
- TXZ同盘局部少损3同时少扣9；第三次首场赢后4血、下一房开场死支持连战成本，不能证明某留药/换线可通关。未校准1200样本首胜/后败不作为放宽必死SL的依据。
- WQ T9原线13损/24敌净扣、替线22损/39敌净扣；末试T7同扣24但付4血多一沙坑回合，反对一概禁止付血或只比较伤害。沙坑当轮末4/5与次轮3/4分开。末态敌56与HP0可核，攻击/沙坑内部先致死来源仍未知。
- 狡诈42饮/9局：37次添3、2次添2、3次添0，符合现场剩余手位。第五/六次连续添2/0/0和3/2/0是实证，穿插顺序的离线可行性不等于整候选已实盘执行或可救本局。
- Q6 F2早喝敏捷的少损候选没有完整后继；F5/F6已经零损是反例约束。F8胜损55至2再接走廊死，与1913前战胜后46接精英死支持资源审计，不给可赢的反事实。净损不替毛伤，再生/重接/荆棘及死亡截顶另核。
- 普通紧勒103→95→85→85（待弃牌）→83（完成）→80（结毒）成立，只覆盖普通已见分支。新建雾/步法不倒算已挡/已结毒，牌组持有不等于本战已兑现。
- NHA空手开场28血/敌428与可操作30血/敌408分开。原线当轮损1、跨轮敌净扣8；替线损7、净扣24，其中次轮自动扣4不全归卡牌。第五/六试不是独立胜例；六试全败不拟合新的SL成本阈值。
- NHA/K367/SAD三局首次油灯窗口成立，但总负属性或首次看见不等于已建立可靠的逐源消费身份。已有蟹朝向局部1/2修正不覆盖油灯/跨新战/SL联合模型，更不说明早建能力整战可赢。

## 源码、记录及后续

source-audit.json核16个相关源码/测试叶及最后源码commit均为实际live祖先，live快照fe6462651b593b9831581c088deface9957a404f。10叶字节相同，6叶为历史Roy/Dai注释差，完整diff分别保存；source-comment-audit.json逐变更行核实仅注释替换，未覆盖并行历史差异。

已有窄实现：6403fdcdadc803a092beb5165a068e22bf51c412狡诈生成/容量；5c7105ff0294466da8319f2934beda05c6040794普通紧勒；e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a开场扣血与ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8后续组合；ec29ea34b919344b707e57ba472ea210f9c39d62/f2c7cc1a7288893bceae0f0b20304a2b1fae5f57蟹转向取整。它们均为本批base及实际live祖先，不是本批提交，不能替整项登记implemented/duplicate。

两次额外只读转译尝试未形成结果：第一次Node子进程git返回EPERM（会话原输出及transpile-attempt1.txt现象记录保留，后者不是原stderr副本）；第二次本机TypeScript7的默认导出没有ScriptTarget/transpileModule（transpile-attempt2.log保留），不将其当代码失败或声称转译/tsc成功。未更改权限、安装依赖或改生产代码。最终用固定原字节diff证明六项差异限于注释，没有声称完整程序已编译验证。

队列定位首轮关键词检索过宽，带出混合历史条目；该输出没有纳入证据或策略结论，随后按本批局号收窄，仅核0254/0256/0260/0263的既有链接，不领取其他项。未读取其他角色knowledge目录，不重建旧dirty运行树、不冒充历史源码完整还原。历史brain标签/引擎未重新核成纯Codex成绩，本学习者实际原生模型/强度未独立读回，不将任务模板文字当运行核验。

仅经根learner/ledger.py update追加原31账本的本批proposal/report链接与note，不改claim/首证/prior/证据/status/version，不将已shipped窄经验降回proposed。此处是已有提案的追溯登记，没有新学习条目或新游戏事实。ledger-update.jsonl与CLI输出保留，最终保护字段复核记录于ledger-readback.json。

没有源码修改，撤源码失败/恢复通过不适用，未运行tsc/vitest；没有新提交所以无提交前gitleaks声明；未执行第4节live锁/刷新/合入/版本步骤，未发规则更改通知，不标shipped。无源码/知识新增，铁甲及其他角色行为没有本批变化。工作树最终保持干净，HEAD保持base；原队列状态由调度器按result.json逐项处置，waiting保留待新本角色完局，宽父和学习入库消费者要求继续开放。
"""
proposal = intro + "\n".join(sections) + common
(P / "proposal.md").write_text(proposal)
(P / "report.md").write_text(proposal + "\n## 机器回报\n\n```json\n" + json.dumps(result, ensure_ascii=False, indent=2) + "\n```\n")

updates = []
for ledger in sorted({l for q in Q.values() for l in q["ledger"]}):
    ids = [i for i in D["proposal_ids"] if ledger in Q[i]["ledger"]]
    updates.append({"id": ledger, "by": "learner:strategy-proposal", "where": {"proposal": [str(P / "proposal.md"), str(P / "report.md")]},
                    "note": "本批20261015-211145-s2-strategy-proposal逐项核证：" + ",".join(ids) +
                    "均waiting；19929行原字节核验/38项材料断言，非生产测试；无源码/合入/新版本，宽项缺完整受控后继。理由见本批报告；保留旧claim/首证/prior/evidence/status/version。"})
(P / "ledger-update.jsonl").write_text("".join(json.dumps(u, ensure_ascii=False) + "\n" for u in updates))
print(json.dumps({"report": str(P / "report.md"), "proposals": len(results), "ledger_links": len(updates)}, ensure_ascii=False))

"""Check run-specific recorded observations, independently of production scoring code."""
import collections
import json
from pathlib import Path

P = Path(__file__).resolve().parent
S = {s["line"]: s for s in map(json.loads, (P / "compact-states.jsonl").open())}
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected})


def enemy_hp(line):
    return sum(e["hp"] for e in S[line]["enemies"])


def potion_id(action):
    return next(p["potion_id"] for p in action["before"]["potions"]
                if p["index"] == action["chosen"]["option_index"])


actions = json.loads((P / "potion-action-links.json").read_text())
ken = [a for a in actions if a["run"] == "KEN58SH9SLZ6"]
check("KEN实际饮用动作数", len(ken), 7)
check("KEN保留原pending回执数", sum(a["result"].startswith("pending") for a in ken), 3)
check("KEN饮用种类和次序", [potion_id(a) for a in ken],
      ["ATTACK_POTION", "STABLE_SERUM", "SPEED_POTION", "WEAK_POTION", "ATTACK_POTION", "GLOWWATER_POTION", "SKILL_POTION"])
check("KEN七次后帧槽位均空", all(not next(p["occupied"] for p in a["after"]["potions"]
      if p["index"] == a["chosen"]["option_index"]) for a in ken), True)
for label, before, after, expected in [("F12回复", 280336, 280337, 27), ("F16回复", 280382, 280383, 29)]:
    check(label, S[after]["hp"] - S[before]["hp"], expected)
check("KEN六次Boss入口均空药栏", sum(s["run"] == "KEN58SH9SLZ6" and s["line"] in
      [280385, 280434, 280488, 280551, 280614, 280668] and not any(p["occupied"] for p in s["potions"])
      for s in S.values()), 6)
check("KEN六次入口均75HP", [S[n]["hp"] for n in [280385, 280434, 280488, 280551, 280614, 280668]], [75] * 6)
check("KEN五次SL复原单列", sum(75 - S[n]["hp"] for n in [280433, 280487, 280550, 280613, 280667]), 348)
check("TXZ第二次T6损血", S[281479]["hp"] - S[281484]["hp"], 3)
check("TXZ第三次T6损血", S[281535]["hp"] - S[281539]["hp"], 0)
check("TXZ第二次T6敌净扣", enemy_hp(281479) - enemy_hp(281484), 36)
check("TXZ第三次T6敌净扣", enemy_hp(281535) - enemy_hp(281539), 27)
check("TXZ首胜和下房开场HP", [S[n]["hp"] for n in [281563, 281565, 281566]], [4, 4, 0])
check("TXZ下房敌血未扣", [enemy_hp(n) for n in [281565, 281566]], [111, 111])
check("WQ原线/换线同入口", [S[n]["hp"] for n in [282075, 282144]], [26, 26])
check("WQ原线/换线损血", [S[282075]["hp"] - S[282079]["hp"], S[282144]["hp"] - S[282148]["hp"]], [13, 22])
check("WQ原线/换线敌净扣", [enemy_hp(282075) - enemy_hp(282079), enemy_hp(282144) - enemy_hp(282148)], [24, 39])
check("WQ T7原线/逃离线损血", [S[282066]["hp"] - S[282072]["hp"], S[282330]["hp"] - S[282336]["hp"]], [0, 4])
check("WQ T7原线/逃离线净扣相同", [enemy_hp(282066) - enemy_hp(282072), enemy_hp(282330) - enemy_hp(282336)], [24, 24])
check("WQ T7末沙坑4/5与次轮3/4分开", [S[n]["enemies"][0]["powers"]["SANDPIT_POWER"] for n in [282071, 282335, 282072, 282336]], [4, 5, 3, 4])
cunning = [a for a in actions if potion_id(a) == "CUNNING_POTION"]
distribution = collections.Counter(len(a["after"]["hand"]) - len(a["before"]["hand"]) for a in cunning)
check("42次狡诈新增分布", dict(distribution), {3: 37, 2: 2, 0: 3})
check("狡诈仅9个独立局", len({a["run"] for a in cunning}), 9)
check("狡诈42次符合现场剩余容量", all(len(a["after"]["hand"]) - len(a["before"]["hand"]) ==
      min(3, 10 - len(a["before"]["hand"])) for a in cunning), True)
for label, lines, expected in [("WQ第五试连续饮用", [276102, 276103, 276104], [2, 0, 0]),
                                ("WQ第六试连续饮用", [276161, 276162, 276163], [3, 2, 0])]:
    check(label, [len(a["after"]["hand"]) - len(a["before"]["hand"]) for a in cunning if a["line"] in lines], expected)
check("Q6骇鳗胜后和后战入口", [S[n]["hp"] for n in [282907, 282913, 282921]], [2, 2, 0])
check("1913前战胜后与精英入口", [S[n]["hp"] for n in [282745, 282755]], [46, 46])
check("Q6紧勒逐阶段敌血", [enemy_hp(n) for n in [282887, 282888, 282889, 282890, 282891, 282892]], [103, 95, 85, 85, 83, 80])
check("NHA开场空手和可操作HP分开", [S[n]["hp"] for n in [283390, 283391]], [28, 30])
check("NHA首试/第五试即时付血", [S[283391]["hp"] - S[283397]["hp"], S[283478]["hp"] - S[283483]["hp"]], [1, 7])
check("NHA首试/第五试跨轮敌净扣", [enemy_hp(283391) - enemy_hp(283397), enemy_hp(283478) - enemy_hp(283483)], [8, 24])
check("NHA第六试重放同样付血", S[283502]["hp"] - S[283507]["hp"], 7)
check("NHA普通X1萎靡实际力弱", [S[283395]["enemies"][0]["powers"][k] for k in ["STRENGTH_POWER", "WEAK_POWER"]], [-2, 2])
check("NHA F17首次毒", S[283147]["enemies"][0]["powers"]["POISON_POWER"], 10)
check("K367 A1带毒刺击窗口", S[217010]["enemies"][1]["powers"]["POISON_POWER"], 8)
check("SAD A7毒药窗口", S[232563]["enemies"][1]["powers"]["POISON_POWER"], 10)
check("原字节核验总行数", json.loads((P / "byte-verification.json").read_text())["total_rows"], 19929)
(P / "material-checks.json").write_text(json.dumps({"count": len(checks), "checks": checks}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"material_assertions": len(checks), "passed": True, "production_tests": False}, ensure_ascii=False))

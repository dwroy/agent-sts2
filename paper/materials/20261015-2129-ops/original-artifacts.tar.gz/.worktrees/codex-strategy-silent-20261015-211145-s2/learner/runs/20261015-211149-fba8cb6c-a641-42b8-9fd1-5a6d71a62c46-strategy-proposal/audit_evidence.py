"""Verify frozen evidence bytes and retain compact observations without gameplay inference."""
import collections
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def save(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def power_list(raw):
    return {p["power_id"]: p.get("amount") for p in raw or []}


def compact(item):
    s = item["row"]["state"]
    r, c = s.get("run") or {}, s.get("combat") or {}
    p = c.get("player") or {}
    return {
        "line": item["line"], "run": item["run_id"], "ts": item["row"]["ts"],
        "floor": r.get("floor"), "turn": s.get("turn"), "screen": s.get("screen"),
        "in_combat": s.get("in_combat"), "hp": r.get("current_hp"), "max_hp": r.get("max_hp"),
        "energy": p.get("energy"), "block": p.get("block"), "powers": power_list(p.get("powers")),
        "hand": [{k: v for k, v in card.items() if k in
                  ("index", "card_id", "upgraded", "energy_cost", "dynamic_values")}
                 for card in c.get("hand", [])],
        "enemies": [{"id": e.get("enemy_id"), "index": e.get("index"), "hp": e.get("current_hp"),
                     "block": e.get("block"), "alive": e.get("is_alive"),
                     "powers": power_list(e.get("powers")), "intents": e.get("intents")}
                    for e in c.get("enemies", [])],
        "potions": [{k: v for k, v in potion.items() if k in ("index", "potion_id", "occupied")}
                    for potion in r.get("potions", [])],
        "readiness": c.get("action_readiness"),
    }


manifest = json.loads((BASE / "evidence/evidence-manifest.json").read_text())
identities = json.loads((BASE / "run-identities.json").read_text())
verified, states, decisions, configs, plans, sl = [], [], [], [], [], []
for stream in manifest:
    name = stream["stream"]
    evidence_file = BASE / "evidence" / (name + ".evidence.jsonl")
    digest = hashlib.sha256()
    counts = collections.Counter()
    source_path = Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")
    with source_path.open("rb") as source, evidence_file.open("rb") as evidence:
        for encoded in evidence:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item["source"] == str(source_path)
            assert item["offset"] + item["bytes"] <= stream["source_size"]
            source.seek(item["offset"])
            raw = source.read(item["bytes"])
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            row = json.loads(raw)
            assert row == item["row"]
            nested = row.get("state") or {}
            fp = row.get("fingerprint")
            if isinstance(fp, str):
                try:
                    fp = json.loads(fp)
                except ValueError:
                    fp = None
            ids = {x for x in [row.get("run"), row.get("run_id"), nested.get("run_id"),
                              fp.get("run") if isinstance(fp, dict) else None]
                   if isinstance(x, str) and x and x != "run_unknown"}
            assert ids == {item["run_id"]}
            assert identities[item["run_id"]]["character"] == "SILENT"
            counts[item["run_id"]] += 1
            if name == "states":
                assert nested["run"]["character_id"] == "SILENT"
                states.append(({"row": {"fingerprint": item["row"]["fingerprint"]}}, compact(item)))
            elif name == "decisions":
                decisions.append(item)
            elif name == "run-config":
                configs.append(item)
            elif name == "run-plans":
                plans.append(item)
            elif name == "sl-attempts":
                sl.append(item)
    assert digest.hexdigest() == stream["output_sha256"]
    assert all(counts[run] == n for run, n in stream["counts"].items())
    verified.append({"stream": name, "rows": sum(counts.values()), "source_size": stream["source_size"],
                     "counts": dict(counts), "sha256": digest.hexdigest(), "byte_checks": True})

save("byte-verification.json", {"streams": verified, "total_rows": sum(x["rows"] for x in verified)})
by_run = collections.defaultdict(list)
fingerprints = collections.defaultdict(list)
with (BASE / "compact-states.jsonl").open("w") as out:
    for item, frame in states:
        by_run[frame["run"]].append(frame)
        fingerprints[item["row"]["fingerprint"]].append(frame)
        out.write(json.dumps(frame, ensure_ascii=False) + "\n")

potions, rests, selected = [], [], []
for item in decisions:
    row = item["row"]
    chosen = row.get("chosen") or {}
    action = chosen.get("action")
    if action in ("use_potion", "discard_potion"):
        matches = fingerprints.get(row.get("fingerprint"), [])
        before = None
        if matches:
            earlier = [s for s in matches if s["ts"] <= row["ts"]]
            before = max(earlier, key=lambda s: s["ts"]) if earlier else matches[0]
        after = None
        if before:
            after = next((s for s in by_run[item["run_id"]] if s["line"] > before["line"]), None)
        potions.append({"line": item["line"], "run": item["run_id"], "floor": row.get("floor"),
                        "turn": row.get("turn"), "chosen": chosen, "result": row.get("result"),
                        "before": before, "after": after})
    if row.get("label", "").startswith("rest/"):
        rests.append({"line": item["line"], "run": item["run_id"], "floor": row.get("floor"),
                      "label": row.get("label"), "chosen": chosen, "result": row.get("result")})
    run, floor, turn = item["run_id"], row.get("floor"), row.get("turn")
    if ((run == "TXZ6RVMQA09D" and floor in [48, 49] and turn in [6, 8, 10]) or
        (run == "WQZVENQ7DTRP" and floor == 33 and turn in [7, 9, 11]) or
        (run == "NHA2KW0RB7VP" and floor == 33 and turn in [1, 2]) or
        (run == "Q6M2Y34MWKRE" and floor in [2, 8, 9] and turn in [1, 2, 3, 4])):
        selected.append({"line": item["line"], **row})
save("potion-action-links.json", potions)
save("rest-actions.json", rests)
save("selected-decisions.json", selected)
save("run-configs.json", configs)
save("run-plans.json", plans)
save("sl-attempts.json", sl)

episodes = []
for run, frames in by_run.items():
    active = None
    for frame in frames:
        if frame["in_combat"]:
            if active is None or active["floor"] != frame["floor"] or (
                frame["turn"] is not None and active["last"]["turn"] is not None and
                frame["turn"] < active["last"]["turn"]):
                if active:
                    episodes.append(active)
                active = {"run": run, "floor": frame["floor"], "first": frame, "last": frame, "exit": None}
            active["last"] = frame
        elif active:
            active["exit"] = frame
            episodes.append(active)
            active = None
    if active:
        episodes.append(active)
save("combat-observation-segments.json", episodes)
print(json.dumps({"verified_rows": sum(x["rows"] for x in verified), "states": len(states),
                  "decisions": len(decisions), "potion_actions": len(potions), "rest_actions": len(rests),
                  "selected_decisions": len(selected), "observation_segments": len(episodes)}, ensure_ascii=False))

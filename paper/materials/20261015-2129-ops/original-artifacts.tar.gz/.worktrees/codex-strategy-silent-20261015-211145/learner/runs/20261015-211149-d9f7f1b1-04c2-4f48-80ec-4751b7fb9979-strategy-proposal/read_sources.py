import hashlib
import json
import subprocess
from pathlib import Path

scratch = Path(__file__).resolve().parent
live = subprocess.check_output(['git', 'rev-parse', 'live']).decode().strip()
names = ['silent-held-loss', 'silent-potion-reference', 'silent-sl-comparison',
         'silent-sl-resource-comparison', 'silent-selection-audit',
         'silent-selection-dispatch', 'silent-hp-guard-audit', 'silent-giant-potion']
paths = ['agent/src/reflex/' + name + '.ts' for name in names]
paths += ['agent/src/sl/attempts.ts', 'agent/src/sl/explore.ts',
          'agent/src/reflex/combat-plan.ts', 'agent/src/hand/loop.ts']
rows = []
for path in paths:
    head_bytes = Path(path).read_bytes()
    live_bytes = subprocess.check_output(['git', 'show', live + ':' + path])
    commit = subprocess.check_output(['git', 'log', '-1', '--format=%H', '--', path]).decode().strip()
    ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live]).returncode == 0
    rows.append({'path': path, 'head_sha256': hashlib.sha256(head_bytes).hexdigest(),
                 'live_sha256': hashlib.sha256(live_bytes).hexdigest(),
                 'same_bytes': head_bytes == live_bytes, 'last_commit': commit,
                 'last_commit_is_live_ancestor': ancestor})
    if head_bytes != live_bytes:
        diff = subprocess.check_output(['git', 'diff', '--binary', live, 'HEAD', '--', path])
        (scratch / (Path(path).name + '.live-main.patch')).write_bytes(diff)
(scratch / 'source-readback.json').write_text(json.dumps({'live': live, 'files': rows}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'live': live, 'files': len(rows), 'same_bytes': sum(r['same_bytes'] for r in rows),
                  'all_last_commits_live_ancestors': all(r['last_commit_is_live_ancestor'] for r in rows)}, ensure_ascii=False))

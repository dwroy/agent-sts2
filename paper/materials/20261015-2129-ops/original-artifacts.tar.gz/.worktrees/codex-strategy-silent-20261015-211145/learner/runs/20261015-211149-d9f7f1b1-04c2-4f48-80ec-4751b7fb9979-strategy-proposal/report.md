# 静默猎手策略批次报告

时间：2026-10-15T21:22:38+08:00。task=strategy-proposal；character=silent；batch=20261015-211145-strategy-proposal。

结论：十个派发提案全部waiting。本批没有证据足够支持的新策略参数或未覆盖纯bug；未改源码/知识，未提交，未合入，未新增版本，未登记shipped。已读README、最新STATE、decision-log末尾及学习/代码提案协议。普通任务身份与工作树匹配，main已合并检查且无新增，HEAD仍为`f32876369a61ee7ead8193a53dcd652837060c6a`，git状态干净。

## 实际证据范围

六锚点：751FN9QM9MHQ, KV0JHNJCKXLS, YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN, KEN58SH9SLZ6。runs.jsonl逐局均SILENT/A10；状态角色与进阶也逐行核验。全部冻结输入8444行，68项材料检查通过；逐流输出SHA和逐局计数见`evidence/evidence-manifest.json`，逐行索引含原日志绝对路径、行号、offset/bytes/SHA。全源非法行计数为states2/decisions2/brain1，不归为本批目标局缺失，未将非法行用于结论；fight-plans为本截点未选到0行，不宣称日志不存在。

|流|冻结source_size|本批行数|
|---|---:|---:|
|states|13152135857|4167|
|decisions|1668855944|4071|
|sl-attempts|41010045|43|
|run-config|1779978|6|
|run-plans|8175240|21|
|brain|603350373|130|
|runs|337609|6|
|fight-plans|2233957|0|

## 逐项结果及限制

完整十项证据局号/层/回合、既有账本、原文指纹、反例、预期行为、验证和回退说明见[proposal.md](proposal.md)，机器结果见`proposal-results.json`。六局是冻结观察集，SL不算独立局；未拟合门槛，未做未来独立验证。751/KEN两向成本、KV回血与净伤、YQL毒水与自爆、PU局部胜利而整局失败均分列，不能凭最长存活或首动作回执推定整场收益。留药、改路线/休息和未执行选项没有受控整战结果。

现有live `fe6462651b593b9831581c088deface9957a404f`的12叶核查保存在`source-readback.json`，11同字节、explore.ts仅三历史注释差异。最近提交均实为live祖先，但完整回合实果仍未知、巨兽参考排序仍沿原规则，因此没有将宽提案整体标duplicate。未改铁甲或其他未观察角色/进阶。

## 验证、记录与交接

`verification.json`：8444原行字节/JSON/身份及68项材料检查通过。`additional-readback.json`保存步法T5/T9、巨兽占位体首次出现轮和原anchor证据。`verification.log`与`verify_evidence.v1.txt`保留材料初稿失败：误把751 T7题面伤9/15当整轮净扣；原摘要实际12/18，已更正，差值仍6；后续`verification-v2.log`通过。不存在的源码猜测路径和一次bubblewrap只读启动失败不当产品失败或新修复。旧dirty源码及旧历史统计未重建。

本批没有生产源码改动，tests={"tsc":null,"vitest":null,"cases":null}；没有撤源码失败/恢复通过、自测成功、提交/合入提交或发布号可报告。无需走live合入锁、版本、上线双通知或提交前扫描；未运行play、网络、LLM或模拟池，未动运维prompt。本次仅将报告/提案和具体waiting理由经既有ledger CLI回链，保持原状态、原经验版本与全部历史；CLI输入、输出及读回在本目录留存。未新建代码提案ID，不重复写历史复盘。宽父要求与实际live消费者验证保持开放。

交运维的提案绝对路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-211145/learner/runs/20261015-211149-d9f7f1b1-04c2-4f48-80ec-4751b7fb9979-strategy-proposal/proposal.md`。最终JSON见`result.json`，每个派发ID都有waiting原因；源码/知识/任务模板均零修改，报告保存在本批ignored scratch，工作树保持干净。当前沙箱仅见pid1进程名codex，未取得可信原生模型/推理强度元数据；不拿默认配置或旧对局run-config冒称本次原生会话已核验，也未改会话设置。

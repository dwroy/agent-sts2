import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
scratch = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
path = root / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger', root / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
updates = [json.loads(line) for line in (scratch / 'ledger-updates.jsonl').read_text().splitlines()]
ids = {row['id'] for row in updates}
raw = path.read_bytes()
rows = [(n, row) for n, line in enumerate(raw.splitlines(), 1) if (row := json.loads(line)).get('id') in ids]
items = module.fold(rows)
assert len(items) == len(ids) and all(item['character'] == 'silent' for item in items.values())
protected = {key: {field: value for field, value in item.items() if field not in ['where', 'history', 'notes']}
             for key, item in items.items()}
if sys.argv[1] == 'before':
    (scratch / 'ledger-before-folded.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
    before = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'protected': protected}
    (scratch / 'ledger-before-protected.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
    print('账本写前快照', len(items), len(raw))
else:
    before = json.loads((scratch / 'ledger-before-protected.json').read_text())
    assert hashlib.sha256(raw[:before['bytes']]).hexdigest() == before['sha256']
    assert before['protected'] == protected
    appended = [json.loads(line) for line in raw[before['bytes']:].splitlines()]
    owned = [row for row in appended if row.get('by') == 'learner:strategy-proposal'
             and row.get('note', '').startswith('20261015-211145-strategy-proposal：')]
    assert len(owned) == len(updates) and {row['id'] for row in owned} == ids
    for update in updates:
        item = items[update['id']]
        assert update['note'] in item['notes']
        assert all(p in item['where']['proposal'] for p in update['where']['proposal'])
        assert any({key: value for key, value in row.items() if key not in ['op', 'ts']} == update for row in owned)
    (scratch / 'ledger-own-events.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in owned))
    (scratch / 'ledger-after-folded.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
    receipt = {'own_cli_events': len(owned), 'original_prefix_preserved': True,
               'protected_fields_preserved': True, 'links_and_notes_verified': True,
               'protected_fields': '原claim/证据/首证/prior/status/version/effect及其他非where/history/notes字段'}
    (scratch / 'ledger-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False))

import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
rows = []
for line in (scratch / 'evidence/states.evidence.jsonl').open():
    entry = json.loads(line)
    state = entry['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    enemies = [{k: enemy.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'powers', 'move_id', 'intents', 'is_alive']}
               for enemy in combat.get('enemies', [])]
    rows.append({'line': entry['line'], 'run_id': entry['run_id'], 'turn': state.get('turn'),
                 'floor': run.get('floor'), 'screen': state.get('screen'), 'in_combat': state.get('in_combat'),
                 'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
                 'block': player.get('block'), 'powers': player.get('powers'),
                 'potions': run.get('potions'), 'enemies': enemies,
                 'hand': [{k: card.get(k) for k in ['card_id', 'upgraded', 'resolved_rules_text']} for card in combat.get('hand', [])]})
(scratch / 'states-index.json').write_text(json.dumps(rows, ensure_ascii=False) + '\n')
targets = {280160, 280161, 280206, 280207, 280232, 280233, 280262, 280263,
           280313, 280314, 280315, 280316, 280348, 280349, 280354, 280355}
for row in rows:
    if row['line'] in targets:
        print(json.dumps({k: row[k] for k in ['line', 'run_id', 'floor', 'turn', 'hp', 'block', 'potions', 'enemies']}, ensure_ascii=False))
print('状态数量', len(rows))

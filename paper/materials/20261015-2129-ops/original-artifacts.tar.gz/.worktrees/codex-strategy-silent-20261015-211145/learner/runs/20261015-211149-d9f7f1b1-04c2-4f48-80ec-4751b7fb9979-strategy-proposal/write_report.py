import hashlib
import json
import subprocess
from pathlib import Path

scratch = Path(__file__).resolve().parent
dispatch = json.loads((scratch / 'dispatch.json').read_text())
proposals = json.loads((scratch / 'proposals-before.json').read_text())
verification = json.loads((scratch / 'verification.json').read_text())
sources = json.loads((scratch / 'source-readback.json').read_text())
manifest = json.loads((scratch / 'evidence/evidence-manifest.json').read_text())
base = (scratch / 'base.txt').read_text().strip()
timestamp = subprocess.check_output(['date', '-Iseconds']).decode().strip()
assert verification['passed'] and verification['raw_rows_verified'] == 8444
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == base
assert subprocess.check_output(['git', 'status', '--porcelain']).decode() == ''

reasons = [
    '751 F17 T2/T7/T13同盘净变化已核；候选成本与单动作回执已有live实现，但完整回合执行归属、抽弃续问后的逐源实果及受控整战后继未闭合，不能据5/10血差设置额外失血门槛。',
    '751 F13 T3有药plan2和整战无药模型plan5同损8、抽样均8/8结束；plan3后轮仍7/8喝药。缺实际无药整战、留药至boss分支及弃呼唤后的逐源结算，不能将持有值未知置零或改喝药规则。',
    '751 T2多9净扣付5血、T7多6净扣付10血、T13省6少6均复核；六试同局均败。已有预测分账未证明整轮兑现，缺保持后轮条件的完整反事实与独立后期验证，不改SL排序。',
    '持牌保守损血、未决弃牌和未知持药价值已有窄展示；751 T7题面伤9/15与整轮敌净扣12/18须分列。actual_turn仍null，逐源伤害、能力后继兑现和跨战无药结果未闭合，不整体记duplicate。',
    'KV F33第4/5试T5同指纹、同零损，去掉致命毒药后整轮敌净扣36→29；后轮出牌不同。缺受控整战后继、回血逐源和未走路线/未选休息实果，不能据全败推演拟合SL或终局权重。',
    '巨兽本体/占位体与末态资源已有实际live祖先源码；anchorRank仍按原始占位HP作同轮tie-break。L9/YQL失败及PU第五试F17胜均保留，缺改序后的受控完整后继与结局校准，不关闭宽提案。',
    'YQL F17末试T10毒药水使残壳毒2→8，26血/13挡/41自爆不变；现有代码已展示该局部观察。缺提前喝、不喝、留药与改变SL排序的受控整战分支，不能把新增毒当已减伤或胜率收益。',
    'KEN七次use_potion均有后帧槽位消耗，三次原回执pending；六次75/86空药栏进F17。缺随机选牌/发光水重问后的完整收益归属、F15不喝及留到boss的完整对照，不能量化跨战持药值。',
    'KEN第4/5试T10同盘多损6仅多净扣2；第4/6试T5省2却将步法T5延至T9，另有小刀续问。缺完整逐源归属、受控整战及独立留出，不能设置统一6血/2伤探索阈值。',
    'KEN双向取舍支持现有条件性经验，六次SL仍为同一局且均未胜；候选预测/单动作回执不能闭合能力后继或整轮实果。缺受控胜线与后期独立验证，保留探索与HP护栏。',
]
evidence = [
    '751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652；sl-attempts 945—950。',
    '751FN9QM9MHQ F13 T3；decisions 272361/272362；F17 T7/T13/T17。',
    '751FN9QM9MHQ F17 T2/T7/T13；sl-attempts 945—950。',
    '751FN9QM9MHQ F13 T3、F17 T7/T13/T17；decisions 272361、272531/272652。',
    'KV0JHNJCKXLS F33 T5；替线decisions 273450及同指纹第4试；sl-attempts 955/956。',
    'YQL8RZ8BWN1E F17 T10、L9SGRBB5R698 F17 T14、PU80F84P6HPN F17 T17；sl-attempts 681/717/958—963。',
    'YQL8RZ8BWN1E F17末试T10；states 280160→280161；L9SGRBB5R698/PU80F84P6HPN为阶段历史对照。',
    'KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1、T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272。',
    'KEN58SH9SLZ6 F17 T10第4/5试、T5第4/6试；decisions 274505/274568、274484/274601。',
    'KEN58SH9SLZ6 F17 T5/T10；sl-attempts 967—969，T13末试实死。',
]
results = [{'id': pid, 'state': 'waiting', 'reason': reason} for pid, reason in zip(dispatch['proposal_ids'], reasons)]
(scratch / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

sections = []
for index, pid in enumerate(dispatch['proposal_ids']):
    item = proposals[pid]
    raw = (scratch / (pid + '.original.md')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item['proposal_sha256']
    sections.append(f'''## {index + 1}. {pid}

原提案：{item['summary']}

证据：{evidence[index]}

既有账本：{', '.join(item['ledger'])}。原件SHA256：`{item['proposal_sha256']}`；原Markdown逐字节保存在`{pid}.original.md`。

本批处置：waiting。{reasons[index]}

预期行为：保留现行出牌、药水、HP护栏、SL与终局权重；已有事实展示继续适用。验证条件：补足上述缺口，再按独立局的真实开始时间划分历史核验/调参与后期留出；相关SL尝试不跨训练与验证集合。未来若实现，固定数据应覆盖原始输入、续问和后续状态，并通过撤源码失败/恢复通过及项目沙箱检查。当前没有新增实现，回退不适用。
''')

proposal_text = f'''# 本批十项静默猎手策略提案复核

记录时间：{timestamp}。来源任务及实现任务：strategy-proposal；batch={scratch.name.split('-d9f7')[0]}的实际派发批次为20261015-211145-strategy-proposal。角色silent；六局均由runs.jsonl核为A10。只处理本批十原ID，不新建重复ID。

基线：`{base}`。开工git status干净，普通任务合main返回Already up to date；本批没有research_request/implementation_request，也不匹配旧牌数专题，未承接其他专题。

授权依据为Roy-2026-10-07-learning；授权不是游戏事实。以下结论仅来自本批六局的状态、动作与SL记录及本角色既有提案/账本/经验，未读取其他角色经验。当前证据支持核对事实，不支持新的固定血价、持药值、SL准入或终局权重。

## 共同证据和边界

- 公共入口冻结八流，逐行source_size、offset、bytes、SHA及所属局保存在`evidence/`；共8444行，所有原字节和身份复核通过。68项检查是离线材料核验，不是生产tsc/vitest或策略收益验证。
- 751 F17 T2第1/3试：损13→18、敌净扣9→18；T7第2/4试：损13→23、敌净扣12→18；T13第1/6试：损8→2、敌净扣17→11。净扣包含整轮已发生事件，不能直接当候选牌伤或逐源毛伤。
- KEN F17 T10第4/5试：损15→21、敌净扣2→4，B2预测.385→.127（差−.2583、SE .0132）；T5第4/6试：损7→5、敌净扣1→2，步法T5延至T9且小刀续问另计。两种方向的取舍均保留，不推出只保血或只抢伤害的规则。
- KV F33第4/5试T5：同指纹、同零损，敌净扣36→29；后轮动作不同，不能将全败推演的并列视为真实等价或将整战结果归因于一张牌。
- YQL末试F17T10：毒药水前后毒2→8，26血、13挡及41自爆相同。显示血挡差额为−2，死亡HP截断0另列；新增毒不当已兑现6伤、减伤6或本体推进。L9/YQL失败及PU第五试F17胜同时保留，PU整局仍败在F33。
- KEN七次实际耗药均有后帧槽位核验，三次API回执为pending；本轮不喝、整战无药和跨战留药不同，缺失反事实不填零。

## 现有源码核查

实际live参照为`{sources['live']}`。12个相关叶的最近提交均为该live祖先，11个逐字节相同；explore.ts只保留三处Roy/Dai历史注释差异，patch已留档。候选成本、未决弃牌、未知持药值、选择审计、单动作派发回执和巨兽阶段均有接线。`actual_turn`、`actual_turn_result`、`whole_plan_executed`或`actual_outcome`仍明确未知。`anchorRank`依然使用原占位血作同轮排序；指标说明不等于排序已经修改。详见`source-readback.json`。

不把这些窄实现覆盖误作全部十项提案完成，不登记implemented/duplicate或shipped。没有发现本批证据足够支持的新纯bug或新阈值。

''' + '\n'.join(sections) + '''
## 验证与后续

没有源码改动、提交、合入或版本；tsc/vitest/cases均null，未做撤生产源码负控，不冒称测试成功。经验库本次未改。只经ledger CLI追加本批报告/提案链接与waiting原因，不新增支持样本、不改既有claim/首证/prior/status/版本；原提案队列由调度器按最终proposal_results机械回填。本批报告不关闭Roy的学习入库、量化校准或后续实际消费者要求。

原始失败保留：`verify_evidence.v1.txt`和`verification.log`曾将751 T7候选伤害9/15误用作整轮净扣期望；查原SL摘要纠正为12/18，差值仍6。修订后`verification-v2.log`的68项材料检查通过。这是材料脚本口径修正，不是产品缺陷/回归或新游戏规则。先前猜测不存在的源码路径、一次bubblewrap只读启动失败均未用于游戏结论；实际路径后来由rg定位。未恢复六局历史dirty源码、未重跑旧101/102/103/104局统计，不借原提案历史分母作为本批验证。
'''
(scratch / 'proposal.md').write_text(proposal_text)

table = ['|流|冻结source_size|本批行数|', '|---|---:|---:|']
for item in manifest:
    table.append(f"|{item['stream']}|{item['source_size']}|{sum(item['counts'].values())}|")
report_text = f'''# 静默猎手策略批次报告

时间：{timestamp}。task=strategy-proposal；character=silent；batch=20261015-211145-strategy-proposal。

结论：十个派发提案全部waiting。本批没有证据足够支持的新策略参数或未覆盖纯bug；未改源码/知识，未提交，未合入，未新增版本，未登记shipped。已读README、最新STATE、decision-log末尾及学习/代码提案协议。普通任务身份与工作树匹配，main已合并检查且无新增，HEAD仍为`{base}`，git状态干净。

## 实际证据范围

六锚点：{', '.join(dispatch['runs'])}。runs.jsonl逐局均SILENT/A10；状态角色与进阶也逐行核验。全部冻结输入8444行，68项材料检查通过；逐流输出SHA和逐局计数见`evidence/evidence-manifest.json`，逐行索引含原日志绝对路径、行号、offset/bytes/SHA。全源非法行计数为states2/decisions2/brain1，不归为本批目标局缺失，未将非法行用于结论；fight-plans为本截点未选到0行，不宣称日志不存在。

''' + '\n'.join(table) + f'''

## 逐项结果及限制

完整十项证据局号/层/回合、既有账本、原文指纹、反例、预期行为、验证和回退说明见[proposal.md](proposal.md)，机器结果见`proposal-results.json`。六局是冻结观察集，SL不算独立局；未拟合门槛，未做未来独立验证。751/KEN两向成本、KV回血与净伤、YQL毒水与自爆、PU局部胜利而整局失败均分列，不能凭最长存活或首动作回执推定整场收益。留药、改路线/休息和未执行选项没有受控整战结果。

现有live `{sources['live']}`的12叶核查保存在`source-readback.json`，11同字节、explore.ts仅三历史注释差异。最近提交均实为live祖先，但完整回合实果仍未知、巨兽参考排序仍沿原规则，因此没有将宽提案整体标duplicate。未改铁甲或其他未观察角色/进阶。

## 验证、记录与交接

`verification.json`：8444原行字节/JSON/身份及68项材料检查通过。`additional-readback.json`保存步法T5/T9、巨兽占位体首次出现轮和原anchor证据。`verification.log`与`verify_evidence.v1.txt`保留材料初稿失败：误把751 T7题面伤9/15当整轮净扣；原摘要实际12/18，已更正，差值仍6；后续`verification-v2.log`通过。不存在的源码猜测路径和一次bubblewrap只读启动失败不当产品失败或新修复。旧dirty源码及旧历史统计未重建。

本批没有生产源码改动，tests={{"tsc":null,"vitest":null,"cases":null}}；没有撤源码失败/恢复通过、自测成功、提交/合入提交或发布号可报告。无需走live合入锁、版本、上线双通知或提交前扫描；未运行play、网络、LLM或模拟池，未动运维prompt。本次仅将报告/提案和具体waiting理由经既有ledger CLI回链，保持原状态、原经验版本与全部历史；CLI输入、输出及读回在本目录留存。未新建代码提案ID，不重复写历史复盘。宽父要求与实际live消费者验证保持开放。

交运维的提案绝对路径：`{scratch / 'proposal.md'}`。最终JSON见`result.json`，每个派发ID都有waiting原因；源码/知识/任务模板均零修改，报告保存在本批ignored scratch，工作树保持干净。当前沙箱仅见pid1进程名codex，未取得可信原生模型/推理强度元数据；不拿默认配置或旧对局run-config冒称本次原生会话已核验，也未改会话设置。
'''
(scratch / 'report.md').write_text(report_text)

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-211145-strategy-proposal',
          'base': base, 'runs': dispatch['runs'], 'fixes': [],
          'skipped': ['十项原提案均有具体缺数据范围；已有窄实现不关闭宽提案，详见proposal_results。'],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(scratch / 'report.md')}
(scratch / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

updates = []
for ledger in sorted({ledger for item in proposals.values() for ledger in item['ledger']}):
    related = [r for r in results if ledger in proposals[r['id']]['ledger']]
    note = '20261015-211145-strategy-proposal：本批六Silent A10局8444原行复核、68项材料检查通过；无源码/测试/合入，不新增支持样本。'
    note += '；'.join(r['id'] + ' waiting：' + r['reason'] for r in related)
    updates.append({'id': ledger, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(scratch / 'proposal.md'), str(scratch / 'report.md')]}, 'note': note})
(scratch / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
print(json.dumps({'report': str(scratch / 'report.md'), 'proposals': len(results), 'ledger_updates': len(updates),
                  'base': base}, ensure_ascii=False))

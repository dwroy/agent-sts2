import hashlib
import importlib.util
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
scratch = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract_evidence', Path.cwd() / 'learner/extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
manifest = json.loads((scratch / 'evidence/evidence-manifest.json').read_text())
dispatch = json.loads((scratch / 'dispatch.json').read_text())
runs = set(dispatch['runs'])
checks = []
data = {}


def check(name, condition, value=None):
    checks.append({'name': name, 'passed': bool(condition), 'value': value})
    if not condition:
        raise AssertionError(name)


for item in manifest:
    stream = item['stream']
    entries = []
    digest = hashlib.sha256()
    counts = Counter()
    handles = {}
    for encoded in (scratch / 'evidence' / (stream + '.evidence.jsonl')).open('rb'):
        digest.update(encoded)
        entry = json.loads(encoded)
        path = entry['source']
        handle = handles.setdefault(path, None)
        if handle is None:
            handle = handles[path] = open(path, 'rb')
        handle.seek(entry['offset'])
        original = handle.read(entry['bytes'])
        assert entry['offset'] + entry['bytes'] <= item['source_size']
        assert hashlib.sha256(original).hexdigest() == entry['sha256']
        assert json.loads(original) == entry['row']
        assert module.run_identity(entry['row']) == entry['run_id']
        assert entry['run_id'] in runs
        entries.append(entry)
        counts[entry['run_id']] += 1
    for handle in handles.values():
        handle.close()
    check(stream + '：全部原行offset/bytes/SHA/正文/所属局', True, len(entries))
    check(stream + '：输出SHA及逐局计数', digest.hexdigest() == item['output_sha256']
          and all(counts[r] == item['counts'][r] for r in runs), dict(counts))
    data[stream] = entries

for entry in data['runs']:
    row = entry['row']
    check(row['run_id'] + '：Silent A10身份', row['character'] == 'SILENT' and row['ascension'] == 10)
check('六局runs身份无重复且精确覆盖', {x['run_id'] for x in data['runs']} == runs and len(data['runs']) == 6)
check('所有状态角色与进阶', all(x['row']['state']['run']['character_id'] == 'SILENT'
      and x['row']['state']['run']['ascension'] == 10 for x in data['states']))

decisions = {x['line']: x['row'] for x in data['decisions']}
states = {x['line']: x['row']['state'] for x in data['states']}
attempts = {(x['run_id'], x['row']['floor'], x['row']['attempt']): x['row'] for x in data['sl-attempts']}
pairs = []


def turn_delta(run, floor, attempt, turn):
    turns = {x['turn']: x for x in attempts[(run, floor, attempt)]['summary']['turns']}
    start, end = turns[turn], turns[turn + 1]
    hp = lambda value: int(re.search(r' (\d+)/(\d+)$', value['enemies']).group(1))
    return {'hp_loss': start['hp'] - end['hp'], 'enemy_net_loss': hp(start) - hp(end),
            'start_hp': start['hp'], 'enemy_start_hp': hp(start), 'plays': start['plays']}


configurations = [
    ('751FN9QM9MHQ', 17, 2, 1, 3, 272434, 272575, (13, 9), (18, 18)),
    ('751FN9QM9MHQ', 17, 7, 2, 4, 272531, 272652, (13, 12), (23, 18)),
    ('KEN58SH9SLZ6', 17, 10, 4, 5, 274505, 274568, (15, 2), (21, 4)),
    ('KEN58SH9SLZ6', 17, 5, 4, 6, 274484, 274601, (7, 1), (5, 2)),
]
for run, floor, turn, a, b, da, db, expected_a, expected_b in configurations:
    left, right = turn_delta(run, floor, a, turn), turn_delta(run, floor, b, turn)
    check(f'{run} F{floor} T{turn}：题面指纹一致', decisions[da]['fingerprint'] == decisions[db]['fingerprint'])
    check(f'{run} F{floor} T{turn}：原线下一轮净变化', (left['hp_loss'], left['enemy_net_loss']) == expected_a, left)
    check(f'{run} F{floor} T{turn}：替线下一轮净变化', (right['hp_loss'], right['enemy_net_loss']) == expected_b, right)
    pairs.append({'run': run, 'floor': floor, 'turn': turn, 'attempts': [a, b], 'decision_lines': [da, db],
                  'original': left, 'replacement': right, 'sl_prediction': decisions[db].get('sl_explore')})

for attempt, expected in [(1, (8, 17)), (6, (2, 11))]:
    value = turn_delta('751FN9QM9MHQ', 17, attempt, 13)
    check(f'751 T13 第{attempt}试净变化', (value['hp_loss'], value['enemy_net_loss']) == expected, value)

kv = decisions[273450]
kv_original = [(line, row) for line, row in decisions.items() if row['run_id'] == 'KV0JHNJCKXLS'
               and row.get('sl_attempt') == 4 and row.get('floor') == 33 and row.get('turn') == 5
               and row.get('fingerprint') == kv['fingerprint']]
check('KV F33 T5：第4/5试同指纹', len(kv_original) == 1, [x[0] for x in kv_original])
for attempt, expected in [(4, (0, 36)), (5, (0, 29))]:
    value = turn_delta('KV0JHNJCKXLS', 33, attempt, 5)
    check(f'KV F33 T5 第{attempt}试净变化', (value['hp_loss'], value['enemy_net_loss']) == expected, value)

criteria = {k: json.loads(v) for k, v in decisions[272361]['questions']['plan']['criteria'].items() if k.startswith('plan')}
check('751 F13 T3：有药/本轮无药/整战无药同损8', all(criteria[k]['hp_lost'] == 8 for k in ['plan2', 'plan3', 'plan5']))
check('751 F13 T3：整战无药plan5单列', 'no_potion_fight' in criteria['plan5'] and decisions[272361]['rollout']['no_potion']['key'] == 'plan5')
check('751 F13 T3：本轮无药plan3后续仍饮7/8', '7/8 samples' in criteria['plan3']['potion_cost'])
check('751 F13 T3：缺药表并非实测零值', 'potion table did not load' in criteria['plan2']['potion_cost'])

before, after = states[280160], states[280161]
def giant_values(state):
    player = state['combat']['player']
    enemy = state['combat']['enemies'][0]
    poison = next(p['amount'] for p in enemy['powers'] if p['power_id'] == 'POISON_POWER')
    return player['current_hp'], player['block'], enemy['intents'][0]['damage'], poison
check('YQL F17 T10：毒水前26血13挡41来袭2毒', giant_values(before) == (26, 13, 41, 2))
check('YQL F17 T10：毒水后26血13挡41来袭8毒', giant_values(after) == (26, 13, 41, 8))
check('YQL F17 T10：末态显示血挡差额−2不当死亡实扣', 26 + 13 - 41 == -2)

potions = []
for line in [274131, 274156, 274185, 274235, 274237, 274267, 274272]:
    row = decisions[line]
    check(f'KEN药水动作{line}', row['run_id'] == 'KEN58SH9SLZ6' and row['chosen']['action'] == 'use_potion')
    potions.append({'line': line, 'floor': row['floor'], 'turn': row['turn'], 'chosen': row['chosen'], 'result': row.get('result')})
for a, b, slot in [(280206, 280207, 0), (280232, 280233, 0), (280262, 280263, 0),
                   (280313, 280314, 1), (280315, 280316, 0), (280348, 280349, 1), (280354, 280355, 0)]:
    get = lambda line: next(p for p in states[line]['run']['potions'] if p['index'] == slot)
    check(f'KEN槽位状态{a}→{b}', get(a)['occupied'] is True and get(b)['occupied'] is False)
check('KEN六次F17入口75血且零药', all(a['summary']['turns'][0]['hp'] == 75 and a['summary']['turns'][0]['turn'] == 1
      for (r, f, _), a in attempts.items() if r == 'KEN58SH9SLZ6' and f == 17)
      and all(not any(p['occupied'] for p in x['row']['state']['run']['potions'])
                  for x in data['states'] if x['run_id'] == 'KEN58SH9SLZ6' and x['row']['state']['run']['floor'] == 17))
for run in ['751FN9QM9MHQ', 'KEN58SH9SLZ6', 'YQL8RZ8BWN1E', 'L9SGRBB5R698']:
    rows = [a for (r, f, _), a in attempts.items() if r == run and f == 17]
    check(run + '：六试均未胜，末试实死', len(rows) == 6 and all(a['result'] != 'won' for a in rows)
          and attempts[(run, 17, 6)]['result'] == 'died')
check('PU F17第五试获胜但整局非胜', attempts[('PU80F84P6HPN', 17, 5)]['result'] == 'won'
      and not next(x['row']['victory'] for x in data['runs'] if x['run_id'] == 'PU80F84P6HPN'))

result = {'raw_rows_verified': sum(len(rows) for rows in data.values()), 'checks': checks,
          'check_count': len(checks), 'passed': all(c['passed'] for c in checks),
          'pairs': pairs, 'potions': potions,
          'limits': ['下一轮净HP变化不等于逐源毛伤害；抽牌与续问已包含在实盘整轮，不能当单候选完整兑现。',
                     '同局SL不作为独立训练/验证；未运行模拟池或新规则反事实。']}
(scratch / 'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['raw_rows_verified', 'check_count', 'passed']}, ensure_ascii=False))

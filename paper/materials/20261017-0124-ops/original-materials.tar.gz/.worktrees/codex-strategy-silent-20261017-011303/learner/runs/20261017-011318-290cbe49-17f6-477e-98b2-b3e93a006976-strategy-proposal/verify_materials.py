import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extract", HERE.parents[1] / "extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((HERE / "dispatch.json").read_text())
runs = dispatch["runs"]
states = collections.defaultdict(list)
decisions = []
run_rows = {}
verified = []
for directory in ["evidence"]:
    manifest = json.loads((HERE / directory / "evidence-manifest.json").read_text())
    for entry in manifest:
        stream = entry["stream"]
        path = HERE / directory / (stream + ".evidence.jsonl")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["output_sha256"]
        counts = dict.fromkeys(runs, 0)
        last_offset = -1
        with (Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")).open("rb") as source:
            with path.open() as selected:
                for line in selected:
                    envelope = json.loads(line)
                    assert envelope["offset"] > last_offset
                    last_offset = envelope["offset"]
                    assert envelope["offset"] + envelope["bytes"] <= entry["source_size"]
                    source.seek(envelope["offset"])
                    raw = source.read(envelope["bytes"])
                    assert hashlib.sha256(raw).hexdigest() == envelope["sha256"]
                    assert json.loads(raw) == envelope["row"]
                    assert extract.run_identity(envelope["row"]) == envelope["run_id"]
                    counts[envelope["run_id"]] += 1
                    if stream == "states":
                        state = envelope["row"]["state"]
                        assert state["run"]["character_id"].lower() == "silent"
                        states[envelope["run_id"]].append(envelope)
                    elif stream == "decisions":
                        decisions.append(envelope)
                    elif stream == "runs":
                        assert envelope["row"]["character"].lower() == "silent"
                        run_rows[envelope["run_id"]] = envelope["row"]
        assert counts == entry["counts"]
        verified.append({"stream": stream, "source_size": entry["source_size"], "counts": counts,
                         "rows": sum(counts.values()), "output_sha256": entry["output_sha256"]})

assert set(run_rows) == set(runs)
assert run_rows["7ZUC4VPMDS41"]["ascension"] == 10


def compact(envelope):
    state = envelope["row"]["state"]
    run = state["run"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {"line": envelope["line"], "run": envelope["run_id"], "floor": run["floor"],
            "turn": state.get("turn"), "hp": run["current_hp"], "block": player.get("block", 0),
            "powers": {p["power_id"]: p["amount"] for p in player.get("powers", [])},
            "potions": [{"index": p["index"], "id": p["potion_id"]} for p in run.get("potions", []) if p.get("occupied")],
            "enemies": [{"id": e["enemy_id"], "hp": e["current_hp"], "max_hp": e["max_hp"],
                         "powers": {p["power_id"]: p["amount"] for p in e.get("powers", [])},
                         "incoming": sum((i.get("damage") or 0) * (i.get("hits") or 0) for i in e.get("intents", []))}
                        for e in combat.get("enemies", []) if e.get("is_alive")]}


by_line = {x["line"]: x for seq in states.values() for x in seq}
observations = []


def check(label, condition, lines):
    observations.append({"label": label, "passed": bool(condition), "states_lines": lines})
    assert condition, label


def at(number):
    return compact(by_line[number])


check("螺线四刀临时敏捷0到4", at(296633)["powers"].get("DEXTERITY_POWER", 0) == 0 and
      at(296641)["powers"]["DEXTERITY_POWER"] == 4 and at(296641)["powers"]["HELICAL_DART_POWER"] == 4,
      [296633, 296641])
check("次轮清除螺线临时量", not at(296642)["powers"].get("DEXTERITY_POWER") and
      not at(296642)["powers"].get("HELICAL_DART_POWER"), [296641, 296642])
check("同线小刀只增后继牌挡", at(296655)["powers"]["DEXTERITY_POWER"] == 3 and
      at(296656)["powers"]["DEXTERITY_POWER"] == 4 and at(296656)["block"] == 0 and
      at(296659)["block"] == 8 and at(296660)["block"] == 20, [296655, 296656, 296659, 296660])
check("永久敏捷保留临时量撤回", at(296660)["powers"]["DEXTERITY_POWER"] == 4 and
      at(296661)["powers"]["DEXTERITY_POWER"] == 3 and not at(296661)["powers"].get("HELICAL_DART_POWER"),
      [296660, 296661])
check("敏捷层数不等于实挡", at(296669)["powers"]["DEXTERITY_POWER"] == 8 and at(296669)["block"] == 0,
      [296669])
check("速度前反伤与后敌伤分开", at(297349)["hp"] == 52 and at(297350)["hp"] == 47 and
      at(297351)["hp"] == 47 and at(297351)["powers"]["DEXTERITY_POWER"] == 5 and
      at(297352)["block"] == 9 and at(297353)["hp"] == 31, [297349, 297350, 297351, 297352, 297353])
check("巨兽本体结束仍有自爆", at(297245)["enemies"][0]["max_hp"] == 999999999 and
      at(297245)["enemies"][0]["incoming"] == 56 and at(297247)["enemies"][0]["incoming"] == 42 and
      at(297249)["hp"] == 34 and at(297249)["block"] == 9 and at(297250)["hp"] == 1,
      [297245, 297247, 297249, 297250])

alchemize = []
index = {}
for run_id, seq in states.items():
    by_fp = collections.defaultdict(list)
    for position, env in enumerate(seq):
        by_fp[env["row"]["fingerprint"]].append(position)
    index[run_id] = by_fp
for envelope in decisions:
    row = envelope["row"]
    if (row.get("chosen") or {}).get("action") != "play_card" or (row.get("expect") or {}).get("card", {}).get("id") != "ALCHEMIZE":
        continue
    if not str(row.get("result", "")).startswith("completed:"):
        continue
    seq = states[envelope["run_id"]]
    candidates = index[envelope["run_id"]].get(row["fingerprint"], [])
    eligible = [i for i in candidates if seq[i]["row"]["observed_ts"] <= row["ts"]]
    assert eligible, ("missing matching before state", envelope["line"])
    position = max(eligible, key=lambda i: seq[i]["row"]["observed_ts"])
    before, after = compact(seq[position]), compact(seq[position + 1])
    assert before["floor"] == after["floor"] == row["floor"]
    assert before["turn"] == after["turn"] == row["turn"]
    record = {"decision_line": envelope["line"], "sl_attempt": row.get("sl_attempt"),
              "before": before, "after": after, "hp_delta": after["hp"] - before["hp"],
              "occupied_delta": len(after["potions"]) - len(before["potions"])}
    alchemize.append(record)
check("五来源局炼制27次实际执行", len(alchemize) == 27 and len({r["before"]["run"] for r in alchemize}) == 5,
      [r["before"]["line"] for r in alchemize])
check("已见空槽炼制均当步加一瓶且不回血", all(r["hp_delta"] == 0 and r["occupied_delta"] == 1 for r in alchemize),
      [r["after"]["line"] for r in alchemize])

check("末试T2局部实损12", at(296633)["hp"] == 38 and at(296642)["hp"] == 26,
      [296633, 296642])
check("第三第五试T4同血同敌血", at(296521)["hp"] == at(296610)["hp"] == 38 and
      at(296521)["enemies"][0]["hp"] == at(296610)["enemies"][0]["hp"] == 197,
      [296521, 296610])
check("炼制血清并未立即回血", at(296612)["hp"] == 38 and
      any(p["id"] == "STABLE_SERUM" for p in at(296612)["potions"]), [296610, 296612])
check("速度临时量次轮撤回", not at(297353)["powers"].get("DEXTERITY_POWER") and
      not at(297353)["powers"].get("SPEED_POTION_POWER"), [297351, 297353])
check("末试尖啸现场来袭23到2", sum(e["incoming"] for e in at(297404)["enemies"]) == 23 and
      sum(e["incoming"] for e in at(297405)["enemies"]) == 2, [297404, 297405])
check("尖啸负力次轮撤回", all(e["powers"].get("STRENGTH_POWER", 0) == 0 for e in at(297411)["enemies"]),
      [297405, 297411])
check("已建速行者的两牌抽入伤害单列", at(296650)["enemies"][0]["hp"] == 13 and
      at(296651)["enemies"][0]["hp"] == 9 and at(296658)["enemies"][0]["hp"] == 184 and
      at(296659)["enemies"][0]["hp"] == 182, [296650, 296651, 296658, 296659])

selected_lines = [296521, 296610, 296612, 296633, 296641, 296642, 296650, 296651,
                  296655, 296656, 296658, 296659, 296660, 296661, 296669, 297245,
                  297247, 297249, 297250, 297349, 297350, 297351, 297352, 297353,
                  297404, 297405, 297411]
(HERE / "frame-anchors.json").write_text(json.dumps(
    [{"compact": at(n), "envelope": by_line[n]} for n in selected_lines],
    ensure_ascii=False, indent=2) + "\n")
selected_decisions = [289475, 289562, 289563, 289584, 289585, 289605]
(HERE / "decision-anchors.json").write_text(json.dumps(
    [d for d in decisions if d["line"] in selected_decisions],
    ensure_ascii=False, indent=2) + "\n")

boundaries = []
for run_id, seq in states.items():
    windows = []
    active = []
    for env in seq:
        state = env["row"]["state"]
        is_combat = state.get("in_combat") is True
        if active:
            previous = active[-1]["row"]["state"]
            restarted = (state["run"]["floor"] != previous["run"]["floor"] or
                         (state.get("turn") or 0) < (previous.get("turn") or 0))
            if not is_combat or restarted:
                windows.append({"entry": compact(active[0]), "last_combat": compact(active[-1]),
                                "next_observation": compact(env), "restarted": restarted,
                                "next_screen": state.get("screen"),
                                "outcome": "后继观察，非独立候选因果结果"})
                active = []
        if is_combat:
            active.append(env)
    if active:
        windows.append({"entry": compact(active[0]), "last_combat": compact(active[-1]),
                        "next_observation": None, "outcome": "无下一观察，结算未知"})
    boundaries.append({"run": run_id, "windows": windows})
(HERE / "resource-boundaries.json").write_text(json.dumps(boundaries, ensure_ascii=False, indent=2) + "\n")

result = {"verified_streams": verified, "verified_raw_rows": sum(s["rows"] for s in verified),
          "run_metadata": run_rows, "material_checks": observations,
          "alchemize_count_by_run": dict(collections.Counter(r["before"]["run"] for r in alchemize)),
          "tests_are_production_checks": False}
(HERE / "materials-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
(HERE / "alchemize-observations.json").write_text(json.dumps(alchemize, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_raw_rows": result["verified_raw_rows"], "material_checks": len(observations),
                  "alchemize_count_by_run": result["alchemize_count_by_run"]}, ensure_ascii=False))

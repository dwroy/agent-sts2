import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
load = lambda name: json.loads((HERE / name).read_text())
dispatch = load("dispatch.json")
proposals = load("assigned-proposals.json")
verification = load("materials-verification.json")
audit = load("source-audit.json")
base = audit["head"]
reasons = [
    "T0 F48T2同38血入口末试多损12血，但狡诈药时点及后继抽弃同变、首试也败；缺正确螺线模型和固定条件整战配对，不能拟探索血价。合前预检另有冲突。",
    "T0 F48T4炼制补稳定血清已核；缺固定产物/后继抽弃整战配对及产物分布，未饮血清不能计即时救命或以损5/15差拟药价。合前预检冲突。",
    "螺线显式普通/升级小刀的同线增敏和次轮撤回已有充分证据，当前生产传播仍遗漏，集成预检冲突阻塞窄实现；整项还缺永久/临时敏捷、覆甲、脆弱及钨棍组合消费者验收，不能整体duplicate。",
    "T0 F48T3/T4抽牌触发速行者伤害已核，滚石已有实现，铁棒/速行者显式传播仍遗漏；集成预检冲突阻塞窄实现，未知抽入牌边界和完整重规划消费者尚未验收。",
    "T0 F48技能激怒、阶段清除及局部换线血价可核；缺固定药时点、抽弃及正确螺线模型的整战配对，不调整探索或必死门槛。合前预检冲突。",
    "原五来源局27次空槽炼制均净添一瓶且当步HP不变，7Z实际A10；缺补药整战受控配对、两战联合资源后继及按局时间留出，不能拟护栏/持药/终局值。合前预检冲突。",
    "G8 F23反伤5与敌伤16、速度9挡、F17自爆34血加9挡对42剩1均核；缺临时属性/自爆/SL恢复的完整候选消费者配对及保药替代整战，现有资源审计仅局部覆盖。合前预检冲突。",
    "G8 F23速度与荆棘、F24尖啸来袭23到2及次轮撤回已核；缺五机制组合的完整固定消费者校准，不能凭局部模型整项duplicate。合前预检冲突。",
    "G8 F17本体结束后自爆实际结算，阶段/资源审计已有真实live源码祖先；前三试判死后结算缺失且抽牌/药时点/换线同变，缺完整同条件阶段SL配对。合前预检冲突。",
    "G8 F19/F20胜战耗血及F23赢到22空药接F24均可核；缺保药、替代路线、后置营火实到及路线/休息消费者的完整对照，不能标定持有价或安全血线。合前预检冲突。",
]
contexts = [
    ("T0DGVABPV60U F48首/末试T2", "s296633→296642，d289584/289585", "首试后来仍失败；药水时点和后继抽弃同时改变。"),
    ("T0DGVABPV60U F48第3/5试T4", "s296521/296610/296612，d289475/289562/289563", "血清未实饮，后续抽弃不同；10血差不是单牌价格。"),
    ("T0DGVABPV60U F48末试T2/T4/T5", "s296633—296642、296655—296661、296669", "原15挡至实20挡另含防御升级多3；8敏捷无挡牌仍0挡而死。"),
    ("T0DGVABPV60U F48末试T2—T5", "s296650/296651、296658/296659", "偏折不是攻击；滚石死前显示25层并未触发，不预支未知抽入牌或多敌收益。"),
    ("T0DGVABPV60U F48末试T2—T4", "s296633—296661，d289584/289585", "全败探索不等新线安全；六试同局，不当六个独立样本。"),
    ("T0/ZE8/6EV/VLV/7Z原五局；T0 F35T2/F45T3/F46T2/F48T4", "alchemize-observations.json逐次列层/回合/原行", "SL恢复原瓶不是新药；未到F49，无实际次Boss入口；随机产物与整战取舍未控。"),
    ("G8NHLL09DLBX F17末T14/T15、F23T2→F24", "s297245/297247/297249/297250、297349—297353", "前三次巨兽判死截断，F23用两药仍耗30血；没有保药完整胜线。"),
    ("G8NHLL09DLBX F23T2/F24末T3—T4", "s297349—297353、297404/297405/297411", "速度不补先前5反伤；尖啸到期恢复，首末试步法/后空翻及牌序也变。"),
    ("G8NHLL09DLBX F17四试；末T14/T15", "s297245/297247/297249/297250；sl-attempts所属原行", "999999999残壳不是新本体需伤；前三试未结算，不计三次实死或单步胜因。"),
    ("G8NHLL09DLBX F17→F18、F19/F20/F23→F24", "resource-boundaries.json；s297349—297353及逐场端点", "末战22血空药两试失败，F25后未到；不能由另路线/留药反事实称可赢。"),
]
results = [{"id": ident, "state": "waiting", "reason": reason}
           for ident, reason in zip(dispatch["proposal_ids"], reasons)]
assert len(results) == 10 and len(set(dispatch["proposal_ids"])) == 10
result = {
    "task": "strategy-proposal", "character": "silent",
    "batch": "20261017-011303-strategy-proposal", "base": base,
    "runs": dispatch["runs"], "fixes": [],
    "skipped": ["live合前预检返回1，存在记录/账本/论文材料冲突；遵照任务停止源码实施。",
                "宽SL、药水和资源价值提案仍缺具体整战对照；已证螺线/铁棒/速行者窄机制不归为证据不足。"],
    "merged": None, "tests": {"tsc": None, "vitest": None, "cases": None},
    "code_proposals": dispatch["proposal_ids"], "implementation_domains": [],
    "proposal_results": results, "report": str(HERE / "report.md"),
}
(HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
(HERE / "proposal-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")

intro = f"""# 本批静默策略提案复核

本批只处理派发的十个原CLI提案；十项均waiting。源码、经验库与游戏规则未改，未提交或合入，无新版本。基线为 `{base}`；实际live预检对象为 `{audit['live']}`。

身份已核：本批task=strategy-proposal、character=silent、reason=proposal、worktree及六锚点一致；有十个proposal_ids，无proposal_repair/research_request/implementation_request。普通专题文件绑定另一旧批次，因此不承接专题，也不读取其work_spec/manifest。开工git status干净，git merge --no-edit main返回Already up to date。未派下级agent。

当前源码仍没有螺线新触发/次轮清除以及铁棒/速行者显式传播；该窄范围已有证据，不要求重新证明已核触发。`git merge-tree --write-tree HEAD live`实际退出1；完整诊断在live-merge-preflight.txt，涉及并行记录、账本、论文表及材料modify/delete。它是合前预检，未实际合并、持live锁、提交刷新数据或操作live工作副本。遵照任务“冲突就停下回报”，未自行覆盖历史、解决记录冲突或绕道集成。

## 证据及样本边界

六局runs原行均SILENT：ZE8 A5胜/F48、6EV A6败/F39、VLV A7败/F48、7Z A10败/F17、T0 A10败/F48、G8 A10败/F24。原历史配置和混合/未知大脑来源不倒写成纯Codex成绩。同局SL只是一局的重复尝试。

原提案多份共同正文将7ZUC4VPMDS41写在A7组，runs与本批全部所属状态帧实为A10；五局炼制实际分组是A5/A6/A7/A10/A10。原Markdown原字节及SHA保留，不覆盖原文，不把来源勘误当新机制反例。此勘误已见旧批报告，本批只再确认，不代ops/watcher/Roy确认传达。

按题面共用extract_evidence.py抽八流，保存每流source_size、选中计数、封套SHA以及每条原offset/bytes/SHA。材料核验逐行回只读原日志复核JSON、显式身份和角色。fight-plans零匹配只限相应字节截点，不据此宣称原日志缺失。原源无效/不完整行计数留在manifest，不混进选中证据。所有结论仅来自六局、本角色原复盘/经验及已领取账本。

"""
stream_table = "|流|本批选中行|冻结source_size|\n|---|---:|---:|\n"
for row in verification["verified_streams"]:
    stream_table += f"|{row['stream']}|{row['rows']}|{row['source_size']}|\n"
intro += stream_table
intro += f"\n共{verification['verified_raw_rows']}条原记录、{len(verification['material_checks'])}项固定材料核验；材料核验不是生产测试或完整候选消费者验收。旧同范围批次材料以路径/字节/SHA登记在prior-materials.json；新截点不增加独立局或SL样本。\n\n"

facts = """## 已核事实与限制

- T0 F48末T2四刀临时敏捷0→4，次轮撤回；T4永久3敏经小刀到4，既有挡仍0，后继偏折8、防御+12合20，次轮只留永久3。遗物对这两牌各贡献1挡；其余3挡来自升级差异。T5八敏无挡牌、0挡死亡，不称修后可赢。
- T0 F48首/末T2同38血入口，末SL把Jev扫腿改速行者后实38→26；首试该轮零损但后来仍失败。狡诈时点、后继抽弃也变，12血只属局部观察，不拟整战探索权重。
- T0 F48第3/5试T4同38血、敌197；护栏题面含炼制损17/伤13与挡线损10/伤13。第5试改回炼制，添稳定血清，当步HP未变，后继携药判死；血清未实饮，不计即时回复/挡。整轮损5/15并非受控单牌价。
- 五局27次实际完成空槽炼制：ZE8=1、6EV=3、VLV=14、7Z=5、T0=4；均当步净添1瓶、HP不变。逐次匹配决策fingerprint与实际前后帧见alchemize-observations.json，不以27次动作当27个独立局或随机产物分布。
- T0 F48末T3步法附魔抽2令敌13→9；T4偏折/铁棒额外抽牌令184→182，非偏折牌面伤。滚石末试已实触发5/10/15/20，死前25未触发。未知抽入牌、多敌、重放、自动触发不补公式。
- G8 F23T2先反伤52→47，速度实加5临时敏捷、后偏折9挡，25来袭再损16至31；全轮损21=5+16，次轮临时量撤回。F23赢到22且空药接F24，前胜仍消耗下一战缓冲。
- G8 F24末T3尖啸令三幼虫各5→0、母体8→2，来袭23→2，次轮负力撤回。首试建立步法、末试没建立且牌序不同，不能把整轮差额全归一项属性。
- G8 F17末T14本体8毒结束，T15残壳仍56自爆，突然一拳弱成42，34血与9挡实剩1；前三试为判死截断而非三次实际死亡。占位999999999不是新本体需伤，换线、抽牌和药时点同变，单因胜利未知。

完整历史dirty源码未保存，当前源码不能冒充当时逐字重放；未选候选整战结算、截断后事件、替路线、保药后继及独立时间留出仍缺。资源链观察与完整候选认证分别记录，不能以未认证称实际未执行。

"""
detail = "## 十项处置\n\n"
for i, (row, context) in enumerate(zip(results, contexts), 1):
    original = proposals[row["id"]]["original"]["row"]
    detail += f"### {i}. {row['id']}\n\n"
    detail += f"原主题：{original['summary']}\n\n"
    detail += f"账本：{', '.join(original['ledger'])}；证据：{context[0]}；原行/材料：{context[1]}。\n\n"
    detail += f"处置：waiting。{row['reason']}\n\n反例/限制：{context[2]}\n\n"
    detail += "预期及验证：仅实现或核验原提案已证范围；固定原帧、牌序、已知抽牌、药产物与来源，在相关消费者间对照。未控制完整后继时不拟策略权重，不承诺转胜。实际代码须撤源码失败、恢复通过，再跑原沙箱入口；本批未运行这些检查。回退仅相应独立实现提交，原证据和账本保留。\n\n"

ending = """## 源码、验证与交接

八相关生产叶中五叶与实际live逐字同SHA，另card-model/explore/judge差异只有历史Roy/Dai注释署名；逐SHA与实际diff见source-audit.json/source-vs-live.patch。此有限叶检查不宣称两整树等价，也不认证所有机制组合。

已核实际base/live祖先源码：1698adc96ba434a46942321e0237b70657e625b2（SL资源比较审计）、a83d9ab675560a177249aa638e99df40bcfb5553（巨兽阶段记录）、0bf701b583e905fcde2bc6d9b5ec1bc0d1131332（随机毒确定性边界）。它们只覆盖原宽提案的局部，不将任何本批原id整体标duplicate/implemented，也不冒用数据提交作源码证明。

固定后续验证：螺线先刀后挡/先挡后刀、普通与升级小刀、已有挡不补、永久敏捷保留及临时量撤回、无挡牌不增挡、其他角色/无遗物等价；铁棒/速行者核真实已知抽入牌及抽后重规划，不预支未知牌；属性/自爆/资源核当前消费者完整链。改护栏/探索/持药/终局权重前须补同条件整战及可观察次战入口，按局分组、按时间留出。已证窄触发在冲突协调后应直接接续，不等待新局重复证明。

无生产源码改动：未提交，未运行撤源码/恢复回归、tsc、vitest或沙箱入口，tests三项均null；无合入、版本、shipped、规则双通知或消费者收益声明。材料脚本只读固定日志作事实核验，不能填生产cases。无需制造提交或提交前gitleaks成功记录。

原十个CLI id继续沿用，无新提案id。根账本只经ledger.py update追加本批proposal/report追溯及处置note，by=learner:strategy-proposal，不重复追加支持/重犯，不改旧claim/first_run/asc/prior/evidence/status/version/shipped_at/effect，不把旧shipped降为proposed。CLI和实际逐行追加读回另存，历史前缀保留。

运维需协调main/live冲突后接续已证螺线、铁棒/速行者窄实现；其余项按具体缺口补完整后继及消费者校准。不能把排队当送达、框架完成当量化学习完成，父学习入库和消费者收益要求保持未完。

"""
proposal_text = intro + facts + detail + ending
(HERE / "proposal.md").write_text(proposal_text)
report_text = intro + facts + detail + ending
report_text += f"提案交接路径：{HERE / 'proposal.md'}。最终机器回报：同目录result.json；完成检查：completion-verification.json。\n\n"
report_text += "```json\n" + json.dumps(result, ensure_ascii=False, indent=2) + "\n```\n"
(HERE / "report.md").write_text(report_text)
print(json.dumps({"report": result["report"], "proposal": str(HERE / "proposal.md"),
                  "base": base, "proposal_count": len(results)}, ensure_ascii=False))

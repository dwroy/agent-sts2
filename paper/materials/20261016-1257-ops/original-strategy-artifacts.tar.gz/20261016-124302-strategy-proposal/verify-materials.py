import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {r['line']: r for r in json.loads((OUT / 'selected-state-observations.json').read_text())}
checks = []


def check(name, condition):
    assert condition, name
    checks.append(name)


integrity = json.loads((OUT / 'evidence-integrity.json').read_text())
check('十个派发锚点和十三个原提案引用局的十六流逐字节复核', len(integrity['streams']) == 16 and integrity['total_rows'] == 40855)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
counts = {m['stream']: m['counts']['K2JAGKVJAWZJ'] for m in manifest}
check('K2实际脑调用48、决策722、状态814、计划7', all(counts[k] == n for k, n in [('brain', 48), ('decisions', 722), ('states', 814), ('run-plans', 7)]))
check('K2含计划复用的Codex决策71', integrity['K2_deciders']['codex'] == 71)
check('铁心不即时补挡，覆甲0到7', states[292788]['block'] == states[292789]['block'] == 0 and states[292788]['powers'].get('PLATING_POWER', 0) == 0 and states[292789]['powers']['PLATING_POWER'] == 7)
for start, end in [(294063, 294068), (294106, 294111)]:
    check(f'棱柱原线{start}损3扣30挡11', states[start]['hp'] - states[end]['hp'] == 3 and states[start]['enemies'][0]['hp'] - states[end]['enemies'][0]['hp'] == 30 and states[end - 1]['block'] == 11)
check('棱柱替线损8扣23挡4', states[294131]['hp'] - states[294135]['hp'] == 8 and states[294131]['enemies'][0]['hp'] - states[294135]['enemies'][0]['hp'] == 23 and states[294134]['block'] == 4)
check('棱柱原线和替线污染分账', states[294067]['powers']['TAINTED_POWER'] == 6 and states[294134]['powers']['TAINTED_POWER'] == 3)
check('棱柱结算后毒10和3', states[294068]['enemies'][0]['powers']['POISON_POWER'] == 10 and states[294135]['enemies'][0]['powers']['POISON_POWER'] == 3)
check('感染T10先付6挡后实际损11', states[293460]['hp'] - states[293461]['hp'] == 11 and states[293460]['block'] == 13 and sum(c['id'] == 'INFECTION' for c in states[293460]['hand']) == 2)
check('感染T11三张9伤越过7挡杀死2血', states[293464]['hp'] == 2 and states[293464]['block'] == 7 and sum(c['id'] == 'INFECTION' for c in states[293464]['hand']) == 3 and states[293465]['hp'] == 0)
check('玩家已死而敌8血10毒均未结算', states[293464]['enemies'][0]['hp'] == states[293465]['enemies'][0]['hp'] == 8 and states[293464]['enemies'][0]['powers']['POISON_POWER'] == states[293465]['enemies'][0]['powers']['POISON_POWER'] == 10)
check('坚韧之环临时6敏施放11挡，后轮2敏仍11挡', states[257821]['powers']['DEXTERITY_POWER'] == 6 and states[257821]['block'] == 11 and states[257823]['powers']['DEXTERITY_POWER'] == states[257828]['powers']['DEXTERITY_POWER'] == 2 and states[257823]['block'] == states[257828]['block'] == 11)
check('坚韧之环原始层数2到1，非11挡额度', states[257821]['powers']['TORIC_TOUGHNESS_POWER'] == 2 and states[257823]['powers']['TORIC_TOUGHNESS_POWER'] == 1)
boundaries = json.loads((OUT / 'floor-boundaries.json').read_text())
for run in ['9R916WW0V65N', 'JMH5C51RLN4E', '9TG1RP5LFAAK', 'ZVYUL2YP3518', 'TDLBRNA0R05B', 'TXZ6RVMQA09D', 'XTSV1U9JD34T', 'PD9AYQVMLQW6']:
    a, b = boundaries[run + ':48']['last'], boundaries[run + ':49']['first']
    check(run + '前后战实际血与逐槽药水连续', a['hp'] == b['hp'] and a['max_hp'] == b['max_hp'] and a['potions'] == b['potions'])
check('9R实际12血空槽且新战能力清空', states[295423]['hp'] == states[295424]['hp'] == 12 and all(p['id'] is None for p in states[295424]['potions']) and not states[295424]['powers'])
check('9R最后三刀后敌仍568血，新增敏捷不倒补挡', sum(e['hp'] for e in states[295550]['enemies']) == 568 and states[295547]['powers']['DEXTERITY_POWER'] == 5 and states[295549]['powers']['DEXTERITY_POWER'] == 6 and states[295547]['block'] == states[295549]['block'] == 0)
consumer = json.loads((OUT / 'existing-consumer-result.json').read_text())
check('现有消费者真实固定调用通过', consumer['assertions_passed'] and (OUT / 'existing-consumer.exit').read_text().strip() == '0')
source = json.loads((OUT / 'source-audit.json').read_text())
check('六个窄实现均为实际base与live祖先', all(c['exists'] and c['base_ancestor'] and c['live_ancestor'] for c in source['commits']))
check('核查的十六源码或fixture与live相同或仅历史署名注释差', all(f['matches_live'] or f.get('only_historical_author_name_difference') for f in source['files']))
projection = json.loads((OUT / 'fixture-source-verification.json').read_text())
check('固定盘面所有保留字段精确来自原日志，只省略agent_view', projection['source_bytes_sha_match'] and projection['board_all_preserved_fields_exact'] and projection['omitted_top_level_fields'] == ['agent_view'])
(OUT / 'material-checks.json').write_text(json.dumps({'scope': '固定证据材料断言，不是生产tsc/vitest、整战校准或自然验收', 'passed': len(checks), 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(checks)}, ensure_ascii=False))

import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve, dirname } from 'node:path';
import assert from 'node:assert/strict';

const output = dirname(fileURLToPath(import.meta.url));
const root = resolve(output, '../../..');
const load = async (name) => import(resolve(root, 'agent/src', name));
const { parseGameState } = await load('hand/mod/schema.ts');
const { makeKnowledge } = await load('knowledge/index.ts');
const { setMonsterDbForTests } = await load('knowledge/monster-db.ts');
const { setMoveModelForTests } = await load('knowledge/move-model.ts');
const { enemySims } = await load('reflex/combat-plan.ts');
const { modelHandCard } = await load('reflex/card-model.ts');
const { replaySteps } = await load('reflex/turn-solver.ts');
const { silentSlResourceComparison } = await load('reflex/silent-sl-resource-comparison.ts');

// Freeze all external knowledge used by these calls; do not consult refreshed JSON.
setMonsterDbForTests({ monsters: {}, bosses: {}, encounters: {} });
setMoveModelForTests({});
const fixturePath = resolve(root, 'agent/tests/silent-sl-prism-resource-evidence.json');
const fixtureBytes = readFileSync(fixturePath);
const fixture = JSON.parse(fixtureBytes);
const raw = fixture.board;
const knowledge = makeKnowledge({ cards: raw.run.deck.map((card) => ({ id: card.card_id, type: card.card_type })) }, 'cache');
const player = raw.combat.player;
const input = {
  hand: raw.combat.hand.map((card) => modelHandCard(card, card.index, knowledge, 'silent', 10)),
  player: { hp: player.current_hp, maxHp: player.max_hp, block: player.block, energy: player.energy,
    weak: false, vulnerable: false, intangible: false },
  enemies: enemySims(raw.combat, 10, 'silent'), fightKind: 'elite', turn: 2,
};
const sequence = (ids) => ids.map((id) => {
  const card = input.hand.find((entry) => entry.cardId === id);
  assert(card);
  return { cardIndex: card.index, cardId: card.cardId, name: card.name, upgraded: card.upgraded, target: card.target === 'single' ? 0 : null };
});
const original = replaySteps(input, sequence(['SLICE', 'STRIKE_SILENT', 'DEADLY_POISON', 'MIRAGE']));
const replacement = replaySteps(input, sequence(['MIRAGE', 'SLICE', 'STRIKE_SILENT']));
assert(original && replacement);
const before = JSON.stringify([original, replacement]);
const record = silentSlResourceComparison(parseGameState(raw), original, replacement, { original: false, replacement: false, saturated: true });
assert.deepEqual(record.resource_comparison.delta, { hp_loss: 5, damage_dealt: -7, block_gained: -7,
  strength_gained: 0, tainted_gained_during_plays: -3, enemy_poison_after_turn: { 0: -7 } });
assert.equal(record.resource_comparison.rollout_saturated, true);
assert.equal(record.resource_comparison.original.execution, 'unverified');
assert.equal(record.resource_comparison.replacement.execution, 'unverified');
assert.equal(JSON.stringify([original, replacement]), before);
const median = silentSlResourceComparison(parseGameState(raw), original, replacement, { original: false, replacement: true, saturated: true });
assert(Object.values(median.resource_comparison.delta).every((entry) => entry === null));
const missing = silentSlResourceComparison(parseGameState(raw), original, null, { original: false, replacement: false });
assert.equal(missing.resource_comparison.replacement, null);
assert.equal(missing.resource_comparison.delta.hp_loss, null);
writeFileSync(resolve(output, 'existing-consumer-result.json'), JSON.stringify({
  scope: '固定原盘面调用现有模型及日志消费者，不是历史dirty源码重建、整战模拟或自然消费者验收',
  fixture: fixturePath, fixture_sha256: createHash('sha256').update(fixtureBytes).digest('hex'),
  fixture_metadata: Object.fromEntries(Object.entries(fixture).filter(([key]) => key !== 'board')),
  original_outcome: original.outcome, replacement_outcome: replacement.outcome,
  record, median_record: median, missing_record: missing, assertions_passed: true,
}, null, 2) + '\n');
console.log(JSON.stringify({ assertions_passed: true, delta: record.resource_comparison.delta }));

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract_evidence', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def powers(value):
    return {p.get('power_id'): p.get('amount') for p in value or []}


def compact(entry):
    state = entry['row']['state']
    run, combat = state.get('run') or {}, state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'run': entry['run_id'], 'line': entry['line'], 'offset': entry['offset'], 'bytes': entry['bytes'], 'sha256': entry['sha256'],
        'screen': state.get('screen'), 'in_combat': state.get('in_combat'), 'floor': run.get('floor'), 'turn': state.get('turn'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'), 'combat_hp': player.get('current_hp'),
        'block': player.get('block'), 'energy': player.get('energy'), 'powers': powers(player.get('powers')),
        'potions': [{'slot': p.get('index'), 'id': p.get('potion_id')} for p in run.get('potions', [])],
        'relics': [{'id': p.get('relic_id'), 'stack': p.get('stack')} for p in run.get('relics', []) if p.get('relic_id') == 'LIZARD_TAIL'],
        'hand': [{'index': c.get('index'), 'id': c.get('card_id'), 'upgraded': c.get('upgraded'), 'text': c.get('description') or c.get('resolved_description') or c.get('resolved_rules_text')} for c in combat.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                     'block': e.get('block'), 'powers': powers(e.get('powers')), 'intents': e.get('intents')} for e in combat.get('enemies', [])],
    }


handles = {}
audit, selected, boundaries, decisions = [], [], {}, []
deciders = collections.Counter()
fixture = json.loads((ROOT / 'agent/tests/silent-sl-prism-resource-evidence.json').read_text())['board']
fixture_matches = []
target_decisions = {287298, 287341, 287366, 288467, 288468}
for directory in ['evidence', 'evidence-linked']:
    manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
    for stream in manifest:
        path = OUT / directory / (stream['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = collections.Counter()
        for encoded in path.open('rb'):
            digest.update(encoded)
            entry = json.loads(encoded)
            source = entry['source']
            if source not in handles:
                handles[source] = open(source, 'rb')
            handle = handles[source]
            handle.seek(entry['offset'])
            raw = handle.read(entry['bytes'])
            assert len(raw) == entry['bytes'] and raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == entry['sha256']
            assert json.loads(raw) == entry['row']
            assert extract.run_identity(entry['row']) == entry['run_id']
            assert entry['offset'] + entry['bytes'] <= stream['source_size']
            counts[entry['run_id']] += 1
            if stream['stream'] == 'states':
                state = entry['row']['state']
                run = state.get('run') or {}
                assert not run or run.get('character_id') == 'SILENT'
                floor, turn, ident = run.get('floor'), state.get('turn'), entry['run_id']
                if floor is not None:
                    key = ident + ':' + str(floor)
                    c = compact(entry)
                    if key not in boundaries:
                        boundaries[key] = {'first': c}
                    boundaries[key]['last'] = c
                wanted = (
                    (ident == '79UCJ0K6R9C1' and floor == 14 and turn in [2, 3, 4, 10, 11]) or
                    (ident == 'NEWRFAYKTQHR' and ((floor == 31) or (floor in [17, 28] and turn == 7))) or
                    (ident == 'K2JAGKVJAWZJ' and ((floor == 27 and turn == 2) or (floor == 46 and turn in [1, 9]))) or
                    (ident == '10GPK5XGHCK3' and floor == 17 and turn == 5) or
                    (ident == 'UJ0K3G10609Y' and floor == 33 and turn == 7) or
                    (ident == 'ZVYUL2YP3518' and floor == 33 and turn in [6, 7, 8]) or
                    (ident == '9R916WW0V65N' and floor is not None and floor >= 42)
                )
                if wanted:
                    selected.append(compact(entry))
                if ident == 'NEWRFAYKTQHR' and state == fixture:
                    fixture_matches.append({k: entry[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']})
            if stream['stream'] == 'decisions':
                if entry['run_id'] == 'K2JAGKVJAWZJ':
                    deciders[entry['row'].get('decider')] += 1
                if entry['line'] in target_decisions:
                    decisions.append(entry)
        assert digest.hexdigest() == stream['output_sha256']
        assert all(counts[ident] == count for ident, count in stream['counts'].items())
        audit.append({'directory': directory, 'stream': stream['stream'], 'rows': sum(counts.values()),
                      'source_size': stream['source_size'], 'output_sha256': digest.hexdigest(),
                      'verified_offset_bytes_sha_json_identity': True})
for handle in handles.values():
    handle.close()
(OUT / 'evidence-integrity.json').write_text(json.dumps({'streams': audit, 'total_rows': sum(s['rows'] for s in audit),
    'fixture_exact_state_matches': fixture_matches, 'K2_deciders': dict(deciders)}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'selected-state-observations.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
(OUT / 'floor-boundaries.json').write_text(json.dumps(boundaries, ensure_ascii=False, indent=2) + '\n')
(OUT / 'selected-decisions.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'total_rows': sum(s['rows'] for s in audit), 'selected_states': len(selected),
    'fixture_exact_state_matches': fixture_matches, 'K2_deciders': dict(deciders)}, ensure_ascii=False))

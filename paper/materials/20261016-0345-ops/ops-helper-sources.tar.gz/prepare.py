from pathlib import Path
import collections,gzip,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0345';pub=root/'paper/materials/20261016-0345-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,value):f.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
extract=module('original_extract',root/'learner/extract_evidence.py');batches=load(root/'ops/codex-ops/learn.json')['batches'];all_owned=[];artifacts=[];readbacks=[]
pub.mkdir(parents=True,exist_ok=True)
for number,bid in enumerate(['20261016-033017-s2-strategy-proposal','20261016-033017-strategy-proposal'],1):
    b=batches[bid];report=b['report'];s=Path(report['report']).parent;scratch=load(s/'result.json');out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text()
    assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
    assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
    assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
    assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
    assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
    assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
    assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
    if number==1:
        originals=load(s/'original-proposals.json');runs={x['row']['run_id']:x['row'] for x in load(s/'runs-identity.json')['records']};manifest=load(s/'evidence/evidence-manifest.json')
        facts=load(s/'fact-checks.json');assert facts['passed']==len(facts['checks'])==185 and all(x['passed'] and x['actual']==x['expected'] for x in facts['checks'])
        assert load(s/'fact-checks-before-lamp.json')['passed']==176 and b'AssertionError' in (s/'fact-check-with-lamp.stderr.txt').read_bytes() and (s/'fact-check-corrected.stderr.txt').read_bytes()==b''
        completed=load(s/'completion-verification.json');assert completed['base']==report['base'] and completed['worktree_clean'] and completed['source_diff_bytes']==0 and completed['raw_evidence_rows']==19929 and completed['ledger_links_read_back']==31 and completed['new_source_commits']==[] and completed['merged'] is completed['release'] is None
        for x in load(s/'artifact-manifest.json'):assert len((s/x['path']).read_bytes())==x['bytes'] and sha((s/x['path']).read_bytes())==x['sha256']
        source=load(s/'source-readback.json');leaves=source['paths'];live=source['live_head'];same_expected=10;expected_rows=19929;expected_ledger=31
    else:
        records=load(s/'proposal-records.json');originals=[rows[0]['row'] for rows in records.values()];manifest=load(s/'evidence/evidence-manifest.json');runs={}
        for line in (s/'identity/runs.evidence.jsonl').read_text().splitlines():
            item=json.loads(line);runs[item['run_id']]=item['row']
        completed=load(s/'validation.json');assert completed['material_assertions']==len(completed['checks'])==136 and completed['passed'] and completed['ledger_updates_verified']==30 and completed['production_tests'] is None and completed['worktree_clean']
        for x in load(s/'completion-files.json'):assert len((s/x['path']).read_bytes())==x['bytes'] and sha((s/x['path']).read_bytes())==x['sha256']
        source=load(s/'source-audit.json');leaves=source['entries'];live=source['live'];same_expected=12;expected_rows=8274;expected_ledger=30
    assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals']) and set(report['runs'])<=set(runs)
    assert all(x['character']=='SILENT' for x in runs.values())
    cohorts=collections.Counter(x['ascension'] for x in runs.values());assert cohorts==({1:1,7:1,9:1,10:12} if number==1 else {10:6})
    original_readbacks=[]
    for x in originals:
        copy=s/(x['id']+'.md') if number==1 else s/'originals'/(x['id']+'.md');assert sha(copy.read_bytes())==x['proposal_sha256']
        original=Path(x['proposal']);assert original.is_relative_to(root)
        if original.exists():assert sha(original.read_bytes())==x['proposal_sha256']
        original_readbacks.append(dict(id=x['id'],path=x['proposal'],original_available=original.exists(),frozen_copy=str(copy.relative_to(root)),sha256=x['proposal_sha256']))
    counts={};input_rows={stream:{} for stream in ['states','decisions']}
    for x in manifest:
        frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
        with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
            for line in selected:
                digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
                assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in runs
                if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==runs[e['run_id']]['ascension']
                if x['stream']=='runs':assert row==runs[e['run_id']]
                if number==2 and x['stream'] in input_rows:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row)
                seen[e['run_id']]+=1
        assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
    assert sum(counts.values())==expected_rows and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==live
    assert len(leaves)==(14 if number==1 else 17)
    for x in leaves:
        a=git('show',report['base']+':'+x['path']);z=git('show',live+':'+x['path']);assert sha(a)==x['base_sha256'] and sha(z)==x.get('live_sha256',x.get('live_worktree_sha256'))
        assert (root/'.worktrees/live'/x['path']).read_bytes()==z and (a==z)==x.get('same',x.get('same_bytes')) and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
        ancestor=x.get('commit_is_live_ancestor',x.get('ancestor'));commit=x.get('last_base_path_commit',x.get('last_live_path_commit'));assert ancestor;git('merge-base','--is-ancestor',commit,live)
    assert sum(x.get('same',x.get('same_bytes')) for x in leaves)==same_expected
    consumers=None
    if number==1:
        for x in load(s/'partial-source-ancestry.json'):
            assert x['is_base_ancestor'] and x['is_live_ancestor']
            for head in [report['base'],live]:git('merge-base','--is-ancestor',x['commit'],head)
    else:
        old_receipts=load(s/'audit-receipts.json');new_receipts=load(s/'audit-retry-receipts.json');assert len(old_receipts)==len(new_receipts)==6;totals=collections.Counter()
        for old,new in zip(old_receipts,new_receipts):
            assert old['run']==new['run'] and old['exit_code']==1 and new['exit_code']==0 and old['input_sha256']==new['input_sha256']
            prefix=s/'audits'/new['run'];inp=gzip.decompress(Path(str(prefix)+'.input.json.gz').read_bytes());first=gzip.decompress(Path(str(prefix)+'.output.json.gz').read_bytes());output_raw=gzip.decompress(Path(str(prefix)+'.retry.output.json.gz').read_bytes())
            assert sha(inp)==new['input_sha256'] and first==b'' and sha(first)==old['output_sha256'] and sha(output_raw)==new['output_sha256']
            for suffix,entry in [('.stderr.log',old),('.retry.stderr.log',new)]:assert sha(Path(str(prefix)+suffix).read_bytes())==entry['stderr_sha256']
            payload=json.loads(inp);audit=json.loads(output_raw);assert payload['run']==runs[new['run']]
            for stream in ['states','decisions']:
                assert len(payload[stream])==new[stream]
                for row in payload[stream]:
                    reference=input_rows[stream][row['_line']];assert reference['run']==new['run'];expected={**reference['row'],'_line':row['_line']}
                    if stream=='states':expected['state']={k:v for k,v in expected['state'].items() if k!='agent_view'}
                    assert row==expected
            status=collections.Counter(x['status'] for x in audit['observed_turns']);assert dict(status)==new['turn_status']
            assert len(audit['segments'])==new['segments'] and len(audit['observed_actions'])==new['actions'] and new['full_candidates_certified']==0 and all(x['actual_full_candidate_result'] is None for x in audit['segments'])
            totals.update(dict(segments=len(audit['segments']),actions=len(audit['observed_actions']),turns=len(audit['observed_turns']),turn_endpoints=status['observed_turn_endpoints'],turn_unknown=status['unknown']))
            scan=p/'consumer-scan'/new['run'];scan.parent.mkdir(parents=True,exist_ok=True);Path(str(scan)+'.input.json').write_bytes(inp);Path(str(scan)+'.output.json').write_bytes(output_raw)
        assert totals==dict(segments=170,actions=890,turns=159,turn_endpoints=99,turn_unknown=60);consumers=dict(original_failed_receipts=old_receipts,original_retry_receipts=new_receipts,counts=dict(totals),not_reexecuted=True)
    inputs=[json.loads(line) for line in (s/'ledger-updates.jsonl').read_text().splitlines()];assert len(inputs)==expected_ledger
    if number==1:
        ledger_receipt=load(s/'ledger-append-verification.json');assert ledger_receipt['updates']==31 and ledger_receipt['prefix_unchanged'] and ledger_receipt['protected_fields_unchanged'] and ledger_receipt['old_history_notes_where_prefix_preserved'];owned=ledger_receipt['events'];prefix=load(s/'ledger-prefix-before.json');prefix_digest=prefix['sha256']
        assert set((s/'ledger-update.stdout.txt').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.stderr.txt').read_bytes()==b''
    else:
        owned=[];prefix=load(s/'ledger-before-boundary.json');prefix_digest=prefix['prefix_sha256'];assert set((s/'ledger-cli-receipt.log').read_text().split())=={x['id'] for x in inputs}
    with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
        assert sha(handle.read(prefix['bytes']))==prefix_digest
        if number==2:
            while True:
                offset=handle.tell();raw=handle.readline()
                if not raw:break
                row=json.loads(raw)
                if row.get('by')=='learner:strategy-proposal' and row.get('note','').startswith(bid):owned.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row))
        assert len(owned)==expected_ledger
        for entry in owned:
            handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw);assert sha(raw)==entry['sha256'] and row==entry['row']
            assert set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal' and any(all(row.get(k)==v for k,v in item.items()) for item in inputs)
            all_owned.append((entry['offset'],raw))
    exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
    readback=dict(batch=bid,original_report=report,original_scratch_result=scratch,reason_abbreviation_only=(scratch!=report),original_gate=b['no_change_proposals'],native=native,source=source,original_proposals=original_readbacks,evidence_rows=expected_rows,stream_counts=counts,cohorts=dict(cohorts),material_assertions=185 if number==1 else 136,original_completion=completed,owned_ledger_rows=owned,consumers=consumers,material_checks_not_reexecuted=True,limits=['Mixed ascensions remain separate; same-run SL is not an independent sample.','Existing narrow source and endpoints do not close whole-candidate execution, attribution, controlled successor or calibration gaps.','Original lamp-index assertion/loader/path/probe failures retained; no product regression or new mechanism counterevidence inferred.','No source, merge, release, production tests, duplicate dispatch, paper refresh or game action.'])
    write(pub/f'batch{number}-readback.json',readback);readbacks.append(readback)
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    if number==2:files.extend(f for f in (s/'originals').iterdir() if f.is_file());files.extend(f for f in (s/'audits').iterdir() if f.is_file())
    for f in sorted(set(files)):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
old=git('show',base+':paper/materials/learning/ledger.jsonl');all_owned.sort();rows=[raw for offset,raw in all_owned]
assert len(rows)==len(set(rows))==61 and all(raw.rstrip(b'\n') not in set(old.splitlines()) for raw in rows);added=b''.join(rows)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert z[ident]['where'][key][:len(items)]==items
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for entry in artifacts:archive.add(p/'archive-scan'/entry['path'],arcname=entry['path'])
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0345原033017-s2/033017两策略done0/no-source核收，各十waiting具体缺口/testsnull/mergednull保持，222d干净WT/HEAD不变，无合入受阻。s2十五Silent来源A1/A7/A9各一及A10十二，八流19929原行；另六A10八流8274原行，分别逐offset/bytes/SHA/JSON/显式身份核，不混进阶/合计独立样本。原185/136材料检查核，s2首次176绿后补油灯错用首敌的217009断言失败及按target_index修正、另一批六根tsx加载失败/同输入绝对loader后六0均保留，不重跑或当生产回归/策略收益。六指定层窗口input/output/stderr原SHA及去agent_view原行绑定核，170问题段/890动作/159轮窗、99端点/60未知、完整候选认证0；限定窗口非全局或整战。s2十四源码叶10同4历史注释差/五来源双祖先，另一十七叶12同5历史注释差/真实live祖先核，不以窄实现关闭联合提案。31+30所属CLI只where/note，物理原前缀/offset/SHA与私有fold按原物理序核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI或新增反证；原scratch详细/最终短理由分列，不改原文。两native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核；dirty消费者、实体代际/返还、完整替线/资源/油灯身份和联合校准未知沿原owner。仅本人记录/61追溯提交，保并行记录；不合入/发号/补测/刷新论文/复派/重启对局或变更账号home模型额度权限prompt，不关闭宽父。证据paper/materials/20261016-0345-ops/。\n'
note=f'\n- {at} [运维 codex] 两策略批次共20项继续waiting，无源码修改或合入阻塞；原185/136材料检查、六有界离线读回和61条所属追溯已核，原油灯断言与tsx加载失败保留。未知与宽父沿原链，无新增发布或补测。回执paper/materials/20261016-0345-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batches=[x['batch'] for x in readbacks],waiting=20,owned_trace_rows=61,protected_fields_and_prefixes_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=20,owned_trace_rows=61,ledger_check=0,paths=len(entries))))

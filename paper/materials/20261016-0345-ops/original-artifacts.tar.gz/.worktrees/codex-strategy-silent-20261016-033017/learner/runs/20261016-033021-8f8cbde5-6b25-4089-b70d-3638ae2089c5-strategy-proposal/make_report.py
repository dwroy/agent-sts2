import json
from pathlib import Path
import subprocess
from datetime import datetime

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
originals = json.loads((OUT / 'proposal-records.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
specs = [
('c20b5139dd0dff71', 'DUZUBAJ3A8GP F27 T4—5，states274830—274839、decisions268889—268898',
 '火花3→6，污染按技能3/6及6/12/18累积；迷雾施毒和格挡各有实际帧。',
 '现有污染/迷雾接线已存在；缺原dirty运行实际消费的A10移动表及毒、弱、挡、污染跨轮联合消费者固定重放，未找到本批新确定性差异。',
 '冻结实际移动表、火花建立/增长、污染消失、迷雾施毒，每击伤害及轮后HP共同回放；未执行完整替线不作胜利实证。'),
('ae9e692d680e3819', '5PM6JAQG6FNQ F39 首试T4—6/末试T4，states274351—274358、274362、274391—274397',
 '首试两次抢夺后−4力/敏；两步法回0敏，失落退场后T5力回0，T6又−2敏；末试GAME_OVER能力清空。',
 '缺逐实体累计被夺量、非抢夺属性来源及死亡返还的完整冻结模型输入；总负属性不能反推返还量，末试清场不证明死前返还，另一杀序完整后继未执行。',
 '冻结来源累计量、非终结返还前后帧、返还后继续打牌和重新抢夺；不设固定杀序。'),
('52f1e1bd2e7db0ed', 'CA5KE8GFJ9X2 F13 T1—5，states273239—273269、decisions267361—267386',
 '力量0/4/8，喷水11/15/19、弱后11/14；轮初覆甲9/9/8/7/6；末14−10需损4，现HP2而实扣封顶2。',
 '当前进阶首样本HP/攻击读取已存在，房间代价仍5样本；缺原dirty消费者A10移动表字节及覆甲完整减层条件的独立联合输入。',
 '冻结数据库读取输入，分攻击/破挡/轮边界验证覆甲；不新增房间血价常数，不混用完整需损与死亡截断净损。'),
('6dd8bbff876be528', '5PM6JAQG6FNQ F38 T3—4，states274308—274317、decisions268385—268394',
 '23上限电击机器人仍活到T4，力2→4、意图17→19；T3玩家61→31，T4才结束该爪牙。',
 'HIGH_VOLTAGE_POWER逐存活实体growth接线已存在；缺稳定召唤代际、新同类替换及累计量归属的冻结输入，连续窗口不足验证新实体建立时点。',
 '保存召唤前后名单、代际及实际模板，验证新实体不继承旧累计；未执行先杀爪牙损3候选不作多保27血的实证。'),
('578e415a259e6835', '8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11，decisions270216/270282、states276429—276434',
 'T2同指纹实损3→15、净扣10→17；末T11能力已建、22挡对37且5HP，24毒只结一次至敌130。',
 '原答/护栏/SL预测和单动作回执已有live窄实现；缺跨抽弃牌、护栏及SL的完整候选执行绑定、逐来源兑现与独立后继联合校准。',
 '固定首/三试T2、护栏T5和末T11核预测/派发/整轮，分列能力、沙坑、药水、已结算毒；不拟SL禁用或HP权重。'),
('c0767768bf6a7ab1', 'YF0LXT1QSTGG F48 第二/三试T1、第四试T5，decisions271309/271348/271354、states277327—277337及277366—277373',
 '同指纹预测两线24/24死亡、后损27；整轮损0→9、净扣45→38。F33第二试SL实胜及第四试T5替线未完成为原反例。',
 '同题预测资源差已有live展示；缺未执行续步、完整替代线资源/胜负对照及跨重问执行归属，不能由多9血少7伤拟SL惩罚或禁止探索。',
 '保留回执、重问及候选终止点；按run和时间后移核完整整战，单一同盘配对不作独立收益样本。'),
('a46bdb7fe711d79a', 'YF0LXT1QSTGG F48 末试T3—5，states277512—277528、decisions271494—271509',
 '111→212换阶段清旧毒/力；T5触媒2但零毒。五敏先成23挡、第三小刀才六敏；197→160净扣37，44−23需损21而18HP死亡。',
 '当前阶段快照和零毒说明已有live实现；缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准，本批未发现新确定性错算。',
 '区分持有/已建/即时/结算，先挡后加敏不倒补；结束页后继55不替代本轮44，不强制毒牌或能力先手。'),
('1044224808015e5c', 'XP2SL33HT0D9 F33 首/二试T3、首/末试T1，decisions271992/272040、271982/272195',
 'T3同指纹实损9→14、净扣24→27；T1实损2→10、净扣25→34并建1力。B2零胜并列但当轮资源不同。',
 '缺原线与换线的独立完整后继、受控随机池及整战结果；有限样本零胜并列不足以证明低当轮损失优先的新排序更好。',
 '保留手里剑成长、朝向与临时减力；控制抽序/生成池完整后继，按独立run及时间切分，保留现有探索排序和选项。'),
('7cbc6005db712ba9', 'XP2SL33HT0D9 F33 末试T2—5，states278236—278261、decisions272200—272225',
 'T2轮初14挡，斗篷另6成20；镣铐力0→−9→0；火箭57→38→28；四敏脆弱下单牌6挡；末17−6=11耗尽11HP。',
 '现场值、局部公式及条件参考已有；缺逐候选贡献拆分、完整执行绑定与条件联合校准，局部接线不足将整项记duplicate。',
 '固定57/38/28、14+6、减力恢复、两敌直伤16/20和末轮3+7毒，逐步核力/敏建立顺序，不从净差推单卡因果。'),
('c59f592f1427a67e', 'YF0LXT1QSTGG F48 T1/T3—5、XP2SL33HT0D9 F33 T1—5，关联上述源行',
 '原综合提案涉及101局、路线/休息/药水及机制；本批只独立核六锚点和指定战斗窗口，不自称重验101局。',
 '缺逐来源资源、完整候选归属、受控路线/留药后继与独立联合校准；六锚点不覆盖原101局历史分母，不以局部相符关闭综合请求。',
 '沿原提案验证冻结历史及逐来源账本；子公式分别计独立run，SL不扩分母，未执行路线/留药后继保持未知。'),
]
results = []
sections = [f'# 本批十项策略提案复核\n\n批次20261016-033017-strategy-proposal；silent，仅本批已观察A10。\n记录时间：{datetime.now().astimezone().isoformat(timespec="seconds")}。\n完整基线：{base}。开工干净，普通批次合main返回Already up to date。\n没有research_request/implementation_request，仅消费派发十ID，不另领取或重复登记。\n\n八流8274条原字节、身份与截点均核实，见evidence-verification.json；十原文SHA均核。所有游戏结论只来自本角色实盘，以下为旧事实有限复核，不新增支持计数。\n']
for suffix, evidence, fact, reason, validation in specs:
    pid = 'silent-proposal-' + suffix
    orig = originals[pid][0]['row']
    results.append({'id': pid, 'state': 'waiting', 'reason': reason})
    sections.append(f'\n## {pid}\n\n来源任务：{orig["source_task"]} → strategy-proposal；账本：{"、".join(orig["ledger"])}。\n原文：{orig["proposal"]}；原SHA256：{orig["proposal_sha256"]}；原字节保留originals/{pid}.md。\n证据：{evidence}。\n核实事实：{fact}\n旧行为/预期行为：依原提案区分预测、派发、已兑现及未知；本轮保持所有选项、现有排序和规则。\n处置：waiting。{reason}\n验证方法与下一步条件：{validation}\n反例/限制：SL同盘不计独立局，能力已建仍可能失败；未执行后继不补成胜线，未发现需要新增登记的机制反证。\n拟合/切分：本轮仅固定原帧复核，不拟新系数；未来按独立run_id及结束时间后移，不把发现样本当盲测。\n预期影响/回退：本轮不改行为，无源码需要回退；后续实现须固定撤码失败/恢复通过，按原live流程记录，Roy授权不提供游戏事实。\n')
(OUT / 'proposal.md').write_text(''.join(sections))
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-033017-strategy-proposal',
         'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': [r['id'] for r in results],
         'implementation_domains': [], 'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
report = f'''# 静默猎手策略提案批次回报

十项全部waiting；六局证据不足以支持新的策略修改，未定位本批新确定性错算。不以局部实现冒称完整提案完成。

完整基线：{base}。开工git status为空，按普通批次合main，Already up to date。根派发行的task/character/worktree及十ID已核，无research_request/implementation_request；普通专题请求属于旧批次，不承接或读另一专题正文。

派发及十项原队列行见dispatch.json、proposal-records.json；原Markdown逐SHA核实并原字节保留originals/。每项的证据局/层/回合、30个旧账本ID、反例、旧/新行为、验证和回退见proposal.md。

## 证据与有界分析

六局均SILENT/A10，runs均dirty源码标记；不能用现在clean树/刷新知识复原原消费者。八流8274条source_size、offset/bytes/SHA、JSON和显式所属局逐行复核：states4062、decisions3941、sl-attempts38、run-config6、run-plans33、brain188、runs6、fight-plans0。fight-plans零行仅指本截点未选到，不断言原流缺失；源全文件另有states2/decisions2/brain1条无效行，不能归属本批。未复用旧截点或覆盖零行初稿。

四组完整指纹相同的整轮观测：

|局/层/回合|原/换线实损|原/换线本体净扣|原decision行|
|---|---|---|---|
|8JRE F33 T2 首/三试|3/15|10/17|270216/270282|
|YF0L F48 T1 二/三试|0/9|45/38|271309/271348|
|XP2S F33 T3 首/二试|9/14|24/27|271992/272040|
|XP2S F33 T1 首/末试|2/10|25/34|271982/272195|

这些是端点观测，不认证完整候选或单卡因果。来源和前后帧见paired-observations.json。加压/覆甲、火花/污染、持续电击增长、负属性返还、零毒触媒、先挡后加敏和船夹板/朝向/临时减力的逐帧复核见mechanism-windows.json和mechanism-selected.json。死亡净损与完整需损分列；YF结束页55是后继显示，不替代最后可操作帧44。原101局综合分母未独立全量核，不关闭原父。

已有离线审计限定DUZ F27、5PM F38/39、CA F13、8J F33、YF F48、XP F33，去除冗余agent_view而保留原行号/身份/时间，原字节另存八流。首轮六份根目录解析tsx失败，stderr/零输出及旧receipt保留；同输入改已安装绝对loader后六份exit0，无联网或装依赖。压缩输入/输出、SHA与stderr在audits/及audit-retry-receipts.json。最终170问题段/890动作/159轮窗，99轮端点可核、60未知；完整候选认证0为工具保守语义，不等于没有执行、没有收益或原日志必然缺失。不能将材料处理成功当生产测试或收益。

## 当前源码与实际live边界

只读核live e716bd28fd8eca9e4d76d066680304fd11935e37。17相关源码叶12同SHA，5差异仅Roy/Dai历史注释；完整binary差异保留base-live-source.diff.patch，逐叶SHA/最后live源码提交/祖先核在source-audit.json。

阶段快照8698c581dac6c7e957f50a381586960a6d0c9b57；候选预测05cd292c6f01bb31e406473d3a9843e659d62b93；单动作回执bade647f9fe4c9103b40e2f26b26296692ad24b7；护栏/SL资源比较a8b1f8be153fe4f3a34146117546c2178f2e446b均核为该live祖先，仅代表局部功能。当前HP/攻击读取有当前进阶观测即用；房间代价门槛仍5。本批无implemented/duplicate整项声明。

## 逐项处置

'''
for r in results:
    report += f'- {r["id"]}：waiting；{r["reason"]}\n'
report += '''
## 验证、记录与交付

无源码修改、提交或撤码红绿；tsc/vitest/cases均null，未跑生产套件。材料核验不填为生产测试通过。无本批合入、版本、上线记录或shipped；没有代码提交/合入受阻需要兜底。工作树源码/知识干净，HEAD保持原base。30个旧账本仅经根ledger CLI补本批proposal追溯，不新增支持/反证，不改claim/first_run/prior/evidence/status/version，不降级旧shipped；追加与回执见ledger-*材料。

限制：仅六锚点及指定战斗窗；同存档SL相关，其他角色/未观察进阶不外推。原dirty输入、稳定召唤代际、完整替代线、逐来源归属和独立后移校准仍缺。首轮根tsx路径失败保留；宽队列回显截断、个别文件猜测不存在、非战斗combat为null探针异常及报告生成工具调用语法失败均无生产或原日志变更，后续按实际文件/类型修正，不当新产品bug或游戏反证。

交运维：本目录proposal.md、report.md与result.json。十项保留具体waiting，沿原队列等待新局重派；不自行修改learn.json、原提案或父请求，不重复登记代码提案。
'''
(OUT / 'report.md').write_text(report)
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal': str(OUT / 'proposal.md'), 'base': base,
                  'proposal_results': len(results)}, ensure_ascii=False))

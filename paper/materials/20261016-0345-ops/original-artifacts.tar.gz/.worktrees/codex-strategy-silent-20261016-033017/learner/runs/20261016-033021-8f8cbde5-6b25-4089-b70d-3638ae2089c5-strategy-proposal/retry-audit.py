import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]
env = dict(os.environ, TMPDIR=str(OUT), PATH=str(Path.home() / '.local/node/bin') + ':' + os.environ['PATH'])
receipts = []
frames = {}
for old in json.loads((OUT / 'audit-receipts.json').read_text()):
    run = old['run']
    path = OUT / 'audits' / (run + '.retry.input.json')
    raw = gzip.decompress((OUT / 'audits' / (run + '.input.json.gz')).read_bytes())
    assert hashlib.sha256(raw).hexdigest() == old['input_sha256']
    path.write_bytes(raw)
    with open(OUT / 'audits' / (run + '.retry.stderr.log'), 'wb') as errors:
        result = subprocess.run(['node', '--import', str(TREE / 'agent/node_modules/tsx/dist/loader.mjs'),
                                 'learner/audit-selection.ts', str(path)], cwd=TREE, env=env,
                                stdout=subprocess.PIPE, stderr=errors)
    path.unlink()
    with gzip.open(OUT / 'audits' / (run + '.retry.output.json.gz'), 'wb') as f:
        f.write(result.stdout)
    receipt = dict(old)
    receipt.update({'exit_code': result.returncode, 'output_sha256': hashlib.sha256(result.stdout).hexdigest(),
                    'stderr_sha256': hashlib.sha256((OUT / 'audits' / (run + '.retry.stderr.log')).read_bytes()).hexdigest(),
                    'retry_reason': '首轮根目录不能解析tsx；使用已安装的agent/node_modules绝对loader路径，冻结输入字节不变。'})
    if result.returncode == 0:
        audit = json.loads(result.stdout)
        receipt.update({'segments': len(audit['segments']), 'actions': len(audit['observed_actions']),
                        'turn_status': dict(collections.Counter(t['status'] for t in audit['observed_turns'])),
                        'turn_unknown_reason': dict(collections.Counter(t['reason'] for t in audit['observed_turns'] if t['reason'])),
                        'full_candidates_certified': sum(s['actual_full_candidate_result'] is not None for s in audit['segments'])})
    receipts.append(receipt)
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    inp = json.loads(raw)
    states = {(v['observed_ts'], v['fingerprint']): v for v in inp['states']}
    windows = collections.defaultdict(list)
    for d in inp['decisions']:
        row = states.get((d['observed_ts'], d['fingerprint']))
        if row is None:
            continue
        s = row['state']
        c = s.get('combat') or {}
        p = c.get('player') or {}
        if not c.get('enemies'):
            continue
        windows[(d['floor'], d.get('sl_attempt'), d['turn'])].append({
            'decision_line': d['_line'], 'state_line': row['_line'], 'ts': row['observed_ts'],
            'chosen': d.get('chosen'), 'result': d.get('result'), 'hp': p.get('current_hp'), 'block': p.get('block'),
            'player_powers': {x['power_id']: x['amount'] for x in p.get('powers', [])},
            'enemies': [{'id': e.get('enemy_id'), 'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                         'block': e.get('block'), 'powers': {x['power_id']: x['amount'] for x in e.get('powers', [])},
                         'intents': e.get('intents'), 'move': e.get('move_id')} for e in c['enemies']]})
    frames[run] = [{'floor': k[0], 'attempt': k[1], 'turn': k[2], 'observations': v} for k, v in windows.items()]
(OUT / 'audit-retry-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
(OUT / 'mechanism-windows.json').write_text(json.dumps(frames, ensure_ascii=False, indent=2) + '\n')

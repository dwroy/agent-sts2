import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]
EVIDENCE = OUT / 'evidence'
manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['runs']
data = {}
checks = []

for item in manifest:
    path = EVIDENCE / (item['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    rows = []
    counts = collections.Counter()
    with open('/home/dw/Projects/agent-sts2/logs/' + item['stream'] + '.jsonl', 'rb') as source:
        for line in path.open('rb'):
            digest.update(line)
            v = json.loads(line)
            source.seek(v['offset'])
            raw = source.read(v['bytes'])
            assert hashlib.sha256(raw).hexdigest() == v['sha256']
            assert json.loads(raw) == v['row']
            assert v['offset'] + v['bytes'] <= item['source_size']
            row = v['row']
            identities = [row.get('run_id'), (row.get('state') or {}).get('run_id'), row.get('run')]
            fp = row.get('fingerprint')
            if isinstance(fp, str):
                try:
                    fp = json.loads(fp)
                except ValueError:
                    fp = None
            if isinstance(fp, dict):
                identities.append(fp.get('run'))
            identities = {x for x in identities if isinstance(x, str) and x and x != 'run_unknown'}
            assert identities == {v['run_id']} and v['run_id'] in runs
            counts[v['run_id']] += 1
            rows.append(v)
    assert digest.hexdigest() == item['output_sha256']
    assert dict(counts) == {k: n for k, n in item['counts'].items() if n}
    checks.append({'stream': item['stream'], 'rows': len(rows), 'source_size': item['source_size'],
                   'raw_offsets_bytes_sha_json_identity': True, 'output_sha_verified': True})
    data[item['stream']] = rows

assert all(v['row']['character'] == 'SILENT' and v['row']['ascension'] == 10 for v in data['runs'])
state_index = collections.defaultdict(list)
for v in data['states']:
    r = v['row']
    state_index[(r['observed_ts'], r['fingerprint'])].append(v)
decisions = {v['line']: v for v in data['decisions']}

def state_for(v):
    r = v['row']
    matches = state_index[(r['observed_ts'], r['fingerprint'])]
    assert len(matches) == 1
    return matches[0]

def powers(holder):
    return {p['power_id']: p['amount'] for p in (holder.get('powers') or [])}

def snapshot(v):
    s = v['row']['state']
    c = s.get('combat') or {}
    player = c.get('player') or {}
    return {'line': v['line'], 'offset': v['offset'], 'bytes': v['bytes'], 'sha256': v['sha256'],
            'observed_ts': v['row']['observed_ts'], 'run': v['run_id'], 'floor': s['run']['floor'],
            'turn': s['turn'], 'screen': s['screen'], 'hp': player.get('current_hp', s['run']['current_hp']),
            'block': player.get('block'), 'powers': powers(player),
            'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block',
                                             'is_alive', 'powers', 'intents', 'move_id']} for e in (c.get('enemies') or [])]}

pairs = []
for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    assert decisions[a]['row']['fingerprint'] == decisions[b]['row']['fingerprint']
    pair = {'decision_lines': [a, b], 'same_fingerprint': True, 'observations': []}
    for line in [a, b]:
        v = decisions[line]
        row = v['row']
        following = next(x for x in data['decisions'] if x['line'] > line and x['run_id'] == v['run_id']
                         and x['row'].get('floor') == row['floor'] and x['row'].get('turn') == row['turn'] + 1
                         and x['row'].get('sl_attempt') == row['sl_attempt'])
        before, after = snapshot(state_for(v)), snapshot(state_for(following))
        hp_loss = before['hp'] - after['hp']
        body_loss = sum(e['current_hp'] for e in before['enemies']) - sum(e['current_hp'] for e in after['enemies'])
        pair['observations'].append({'decision_line': line, 'attempt': row['sl_attempt'], 'before': before,
                                     'after': after, 'hp_loss': hp_loss, 'body_net_loss': body_loss,
                                     'sl_explore': row.get('sl_explore'), 'candidate_attribution': None})
    pairs.append(pair)
(OUT / 'paired-observations.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')

key_floors = {'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39], 'CA5KE8GFJ9X2': [13],
              '8JRE1C4H4Z2W': [33], 'YF0LXT1QSTGG': [48], 'XP2SL33HT0D9': [33]}
(OUT / 'audits').mkdir(exist_ok=True)
receipts = []
env = dict(os.environ, TMPDIR=str(OUT), PATH=str(Path.home() / '.local/node/bin') + ':' + os.environ['PATH'])
for run, floors in key_floors.items():
    ds = [dict(v['row'], _line=v['line']) for v in data['decisions']
          if v['run_id'] == run and v['row'].get('floor') in floors]
    ss = []
    for v in data['states']:
        if v['run_id'] == run and (v['row']['state'].get('run') or {}).get('floor') in floors:
            row = dict(v['row'], _line=v['line'])
            row['state'] = {k: val for k, val in row['state'].items() if k != 'agent_view'}
            ss.append(row)
    inp = {'run': next(v['row'] for v in data['runs'] if v['run_id'] == run), 'decisions': ds, 'states': ss}
    path = OUT / 'audits' / (run + '.input.json')
    raw = (json.dumps(inp, ensure_ascii=False) + '\n').encode()
    path.write_bytes(raw)
    with open(OUT / 'audits' / (run + '.stderr.log'), 'wb') as errors:
        result = subprocess.run(['node', '--import', 'tsx', 'learner/audit-selection.ts', str(path)],
                                cwd=TREE, env=env, stdout=subprocess.PIPE, stderr=errors)
    with gzip.open(str(path) + '.gz', 'wb') as f:
        f.write(raw)
    path.unlink()
    with gzip.open(OUT / 'audits' / (run + '.output.json.gz'), 'wb') as f:
        f.write(result.stdout)
    receipt = {'run': run, 'floors': floors, 'decisions': len(ds), 'states': len(ss), 'exit_code': result.returncode,
               'input_sha256': hashlib.sha256(raw).hexdigest(), 'output_sha256': hashlib.sha256(result.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256((OUT / 'audits' / (run + '.stderr.log')).read_bytes()).hexdigest(),
               'input_transform': '保留原行号、原身份；仅去除冗余state.agent_view，原字节另存八流证据。'}
    if result.returncode == 0:
        audit = json.loads(result.stdout)
        receipt.update({'segments': len(audit['segments']), 'actions': len(audit['observed_actions']),
                        'turn_status': dict(collections.Counter(t['status'] for t in audit['observed_turns'])),
                        'turn_unknown_reason': dict(collections.Counter(t['reason'] for t in audit['observed_turns'] if t['reason'])),
                        'full_candidates_certified': sum(s['actual_full_candidate_result'] is not None for s in audit['segments'])})
    receipts.append(receipt)
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
(OUT / 'audit-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
(OUT / 'evidence-verification.json').write_text(json.dumps({'streams': checks, 'total_rows': sum(x['rows'] for x in checks),
    'all_selected_rows_verified': True, 'invalid_source_lines': {m['stream']: m['invalid_lines'] for m in manifest},
    'pairs': [{'lines': p['decision_lines'], 'hp_loss': [o['hp_loss'] for o in p['observations']],
               'body_net_loss': [o['body_net_loss'] for o in p['observations']]} for p in pairs]}, ensure_ascii=False, indent=2) + '\n')

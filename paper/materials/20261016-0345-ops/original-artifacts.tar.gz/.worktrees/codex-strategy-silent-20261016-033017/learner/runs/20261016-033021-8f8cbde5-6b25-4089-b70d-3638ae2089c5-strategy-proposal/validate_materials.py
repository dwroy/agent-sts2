import hashlib
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
checks = []

def check(name, value):
    assert value, name
    checks.append(name)

def read(name):
    return json.loads((OUT / name).read_text())

result = read('result.json')
dispatch = read('dispatch.json')
check('逐项覆盖派发十ID且无额外项', len(result['proposal_results']) == 10 and
      {v['id'] for v in result['proposal_results']} == set(dispatch['proposal_ids']))
check('全waiting且有具体原因', all(v['state'] == 'waiting' and len(v['reason']) > 30 for v in result['proposal_results']))
check('提案链接准确无重复ID', len(result['code_proposals']) == 10 and set(result['code_proposals']) == set(dispatch['proposal_ids']))
check('无虚构源码合入与生产测试', result['fixes'] == [] and result['merged'] is None and
      result['implementation_domains'] == [] and result['tests'] == {'tsc': None, 'vitest': None, 'cases': None})
check('报告绝对路径及存在', result['report'] == str(OUT / 'report.md') and (OUT / 'report.md').stat().st_size > 1000)
check('基线保持', subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == result['base'])
check('工作树干净', subprocess.check_output(['git', 'status', '--porcelain'], text=True) == '')
check('原工作diff为空', (OUT / 'base-working.diff.patch').read_bytes() == b'')
check('八流8274原行独立复核已通过', read('evidence-verification.json')['all_selected_rows_verified'] and
      read('evidence-verification.json')['total_rows'] == 8274)
for pid, records in read('proposal-records.json').items():
    check(pid + '原文SHA', hashlib.sha256((OUT / 'originals' / (pid + '.md')).read_bytes()).hexdigest() == records[0]['row']['proposal_sha256'])

pairs = read('paired-observations.json')
for pair, hp, damage in zip(pairs, [[3, 15], [0, 9], [9, 14], [2, 10]], [[10, 17], [45, 38], [24, 27], [25, 34]]):
    check(str(pair['decision_lines']) + '同指纹及实损净扣', pair['same_fingerprint'] and
          [o['hp_loss'] for o in pair['observations']] == hp and [o['body_net_loss'] for o in pair['observations']] == damage)

windows = read('mechanism-windows.json')
def window(run, floor, attempt, turn):
    return next(v['observations'] for v in windows[run] if
                [v['floor'], v['attempt'], v['turn']] == [floor, attempt, turn])
duz4 = window('DUZUBAJ3A8GP', 27, None, 4)
duz5 = window('DUZUBAJ3A8GP', 27, None, 5)
check('污染T4为0/3/3/6，能力不加', [o['player_powers'].get('TAINTED_POWER', 0) for o in duz4] == [0, 3, 3, 6])
check('火花T4到T5从3增6', duz4[0]['enemies'][0]['powers']['VITAL_SPARK_POWER'] == 3 and duz5[0]['enemies'][0]['powers']['VITAL_SPARK_POWER'] == 6)
check('污染T5为0/0/6/12/18', [o['player_powers'].get('TAINTED_POWER', 0) for o in duz5] == [0, 0, 6, 12, 18])
check('迷雾施毒T4的2到8及T5的7到13', [duz4[0]['enemies'][0]['powers']['POISON_POWER'], duz4[-1]['enemies'][0]['powers']['POISON_POWER'], duz5[0]['enemies'][0]['powers']['POISON_POWER'], duz5[-1]['enemies'][0]['powers']['POISON_POWER']] == [2, 8, 7, 13])
clam = [window('CA5KE8GFJ9X2', 13, None, t)[0] for t in range(1, 6)]
check('蚌轮初覆甲9/9/8/7/6', [o['enemies'][0]['powers']['PLATING_POWER'] for o in clam] == [9, 9, 8, 7, 6])
check('蚌力量0/0/4/4/8', [o['enemies'][0]['powers'].get('STRENGTH_POWER', 0) for o in clam] == [0, 0, 4, 4, 8])
check('蚌末未结算帧需求4且HP2', any(o['hp'] == 2 and o['block'] == 10 and o['enemies'][0]['intents'][0]['total_damage'] == 14 for o in window('CA5KE8GFJ9X2', 13, None, 5)))
zap = []
for t in [3, 4]:
    zap.append(next(e for e in window('5PM6JAQG6FNQ', 38, None, t)[0]['enemies'] if e['id'] == 'ZAPBOT'))
check('电击跨轮2到4力量且17到19意图', [e['powers']['STRENGTH_POWER'] for e in zap] == [2, 4] and [e['intents'][0]['total_damage'] for e in zap] == [17, 19])
yf4, yf5 = window('YF0LXT1QSTGG', 48, 6, 4), window('YF0LXT1QSTGG', 48, 6, 5)
check('阶段二212HP清旧毒', yf4[0]['enemies'][0]['max_hp'] == 212 and yf4[0]['enemies'][0]['powers'].get('POISON_POWER', 0) == 0)
check('触媒已建2但下轮零毒', yf5[0]['player_powers']['ACCELERANT_POWER'] == 2 and yf5[0]['enemies'][0]['powers'].get('POISON_POWER', 0) == 0)
check('先23挡五敏，后六敏不倒补', any(o['block'] == 23 and o['player_powers']['DEXTERITY_POWER'] == 5 for o in yf5) and yf5[-1]['block'] == 23 and yf5[-1]['player_powers']['DEXTERITY_POWER'] == 6)
check('末轮净扣37及44攻击需求21大于18HP', yf5[0]['enemies'][0]['hp'] - yf5[-1]['enemies'][0]['hp'] == 37 and yf5[-1]['enemies'][0]['intents'][0]['total_damage'] - yf5[-1]['block'] == 21 and yf5[-1]['hp'] == 18)
xp2, xp3, xp4, xp5 = [window('XP2SL33HT0D9', 33, 6, t) for t in [2, 3, 4, 5]]
check('船夹板14加6成20', xp2[0]['block'] == 14 and xp2[-1]['block'] == 20)
check('镣铐负9及下一轮恢复', xp2[1]['enemies'][0]['powers']['STRENGTH_POWER'] == -9 and xp3[0]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) == 0)
check('火箭57到38到28', [xp4[k]['enemies'][1]['intents'][0]['total_damage'] for k in [0, 3, 4]] == [57, 38, 28])
check('四敏6挡末17攻击11HP', xp5[-1]['player_powers']['DEXTERITY_POWER'] == 4 and xp5[-1]['block'] == 6 and xp5[-1]['enemies'][0]['intents'][0]['total_damage'] == 17 and xp5[-1]['hp'] == 11)

audits = read('audit-retry-receipts.json')
check('六个冻结窗口处理成功且均不认证完整候选', len(audits) == 6 and all(a['exit_code'] == 0 and a['full_candidates_certified'] == 0 for a in audits))
check('首轮六失败原件保留', all(a['exit_code'] == 1 for a in read('audit-receipts.json')))
check('审计输入重试字节不变', [a['input_sha256'] for a in audits] == [a['input_sha256'] for a in read('audit-receipts.json')])
check('窗口170段890动作99已知60未知', sum(a['segments'] for a in audits) == 170 and sum(a['actions'] for a in audits) == 890 and sum(a['turn_status'].get('observed_turn_endpoints', 0) for a in audits) == 99 and sum(a['turn_status'].get('unknown', 0) for a in audits) == 60)

diff = (OUT / 'base-live-source.diff.patch').read_text().splitlines()
removed = [s[1:] for s in diff if s.startswith('-') and not s.startswith('---')]
added = [s[1:] for s in diff if s.startswith('+') and not s.startswith('+++')]
check('源码叶差异仅历史称呼', len(removed) == len(added) and all(a.replace('Roy', 'Dai') == b and a.lstrip().startswith(('*', '//')) for a, b in zip(removed, added)))
source = read('source-audit.json')
check('17叶及真实live祖先核', len(source['entries']) == 17 and all(v['ancestor'] for v in source['entries']))

sys.path.insert(0, '/home/dw/Projects/agent-sts2/learner')
import ledger
before = read('ledger-before-append.json')
after = {}
boundary = read('ledger-before-boundary.json')
with open(ledger.LEDGER, 'rb') as f:
    check('账本旧物理前缀保持', hashlib.sha256(f.read(boundary['bytes'])).hexdigest() == boundary['prefix_sha256'])
    appended = [json.loads(line) for line in f]
with open(ledger.LEDGER) as f:
    for line in f:
        v = json.loads(line)
        if v.get('id') in before:
            ledger.apply(after, v)
requests = [json.loads(line) for line in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
for row in requests:
    check(row['id'] + 'CLI确有对应追加行', any(all(actual.get(k) == value for k, value in row.items()) for actual in appended))
for pid, old in before.items():
    new = after[pid]
    check(pid + '非追溯字段不变', {k: v for k, v in old.items() if k not in ['history', 'notes', 'where']} ==
          {k: v for k, v in new.items() if k not in ['history', 'notes', 'where']})
    check(pid + '旧历史与where前缀保留', new['history'][:len(old['history'])] == old['history'] and
          new['notes'][:len(old['notes'])] == old['notes'] and
          all(new['where'][k][:len(v)] == v for k, v in old['where'].items()))
(OUT / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
summary = {'material_assertions': len(checks), 'checks': checks, 'passed': True,
           'production_tests': None, 'ledger_updates_verified': len(requests), 'head': result['base'],
           'worktree_clean': True}
(OUT / 'validation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'checks'}, ensure_ascii=False))

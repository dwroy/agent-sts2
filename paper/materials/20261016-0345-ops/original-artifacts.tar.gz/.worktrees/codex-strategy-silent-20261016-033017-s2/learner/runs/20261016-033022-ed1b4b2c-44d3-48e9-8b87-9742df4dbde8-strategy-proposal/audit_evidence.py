import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('extract_evidence', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def powers(items):
    return {x.get('power_id'): x.get('amount') for x in items or []}


def compact_state(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    assert str(run.get('character_id', '')).lower() == 'silent'
    return {
        'line': item['line'], 'run_id': item['run_id'], 'ts': row['ts'],
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'in_combat': state.get('in_combat'), 'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'energy': player.get('energy'), 'block': player.get('block'), 'powers': powers(player.get('powers')),
        'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'dynamic_values']}
                 for c in combat.get('hand') or []],
        'potions': [{k: p.get(k) for k in ['slot_index', 'potion_id', 'occupied']} for p in run.get('potions') or []],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'), 'move': e.get('move_id'),
                     'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                    for e in combat.get('enemies') or []],
    }


manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
results = []
for entry in manifest:
    stream = entry['stream']
    path = HERE / 'evidence' / (stream + '.evidence.jsonl')
    count = Counter()
    digest = hashlib.sha256()
    with path.open('rb') as f, (HERE / (stream + '-compact.jsonl')).open('w') as out, \
            Path('/home/dw/Projects/agent-sts2/logs', stream + '.jsonl').open('rb') as source:
        for encoded in f:
            digest.update(encoded)
            item = json.loads(encoded)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256'], (stream, item['line'])
            assert json.loads(raw) == item['row'], (stream, item['line'])
            assert item['offset'] + item['bytes'] <= entry['source_size']
            assert extractor.run_identity(item['row']) == item['run_id'], (stream, item['line'])
            count[item['run_id']] += 1
            if stream == 'states':
                value = compact_state(item)
            elif stream == 'decisions':
                r = item['row']
                value = {k: v for k, v in r.items() if k not in ['options', 'state', 'request', 'response', 'usage']}
                value['line'] = item['line']
                value['option_count'] = len(r.get('options') or [])
            else:
                value = {'line': item['line'], 'run_id': item['run_id'], 'row': item['row']}
            out.write(json.dumps(value, ensure_ascii=False) + '\n')
    assert digest.hexdigest() == entry['output_sha256'], stream
    assert all(count[run] == n for run, n in entry['counts'].items()), stream
    results.append({'stream': stream, 'verified_rows': sum(count.values()), 'counts': dict(count),
                    'source_size': entry['source_size'], 'output_sha256': digest.hexdigest()})
(HERE / 'evidence-verification.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in results), 'streams': results}, ensure_ascii=False))

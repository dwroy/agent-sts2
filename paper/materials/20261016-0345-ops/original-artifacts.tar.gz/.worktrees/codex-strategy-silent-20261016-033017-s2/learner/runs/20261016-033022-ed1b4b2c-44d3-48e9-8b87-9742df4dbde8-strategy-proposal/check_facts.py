import bisect
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = [json.loads(line) for line in (HERE / 'states-compact.jsonl').open()]
decisions = [json.loads(line) for line in (HERE / 'decisions-compact.jsonl').open()]
S = {s['line']: s for s in states}
D = {d['line']: d for d in decisions}
by_run = defaultdict(list)
for state in states:
    by_run[state['run_id']].append(state)
times = {run: [s['ts'] for s in rows] for run, rows in by_run.items()}
checks = []
facts = {}


def check(label, actual, expected):
    checks.append({'label': label, 'actual': actual, 'expected': expected, 'passed': actual == expected})
    assert actual == expected, checks[-1]


def window(line):
    decision = D[line]
    rows = by_run[decision['run_id']]
    i = bisect.bisect_right(times[decision['run_id']], decision['ts']) - 1
    first = rows[i]
    j = i + 1
    while j < len(rows) and (rows[j]['floor'], rows[j]['turn']) == (first['floor'], first['turn']):
        j += 1
    assert j < len(rows)
    final, after = rows[j - 1], rows[j]
    return {'decision': line, 'pre': first['line'], 'last': final['line'], 'post': after['line'],
            'hp_loss': first['hp'] - after['hp'],
            'enemy_net_hp_loss': sum(e['hp'] for e in first['enemies']) - sum(e['hp'] for e in after['enemies']),
            'last_block': final['block'], 'last_sandpit': [e['powers'].get('SANDPIT_POWER') for e in final['enemies']],
            'scope': 'observed_turn_boundary; whole_candidate_execution_unverified'}


identity = json.loads((HERE / 'runs-identity.json').read_text())
for item in identity['records']:
    run = item['row']
    check('decision_count:' + run['run_id'], sum(d['run_id'] == run['run_id'] for d in decisions), run['decisions'])

ken = [d for d in decisions if d['run_id'] == 'KEN58SH9SLZ6']
potions = [d for d in ken if d.get('chosen', {}).get('action') == 'use_potion']
check('KEN seven potion uses', len(potions), 7)
check('KEN no potion discard actions', sum(d.get('chosen', {}).get('action') == 'discard_potion' for d in ken), 0)
check('KEN potion floor/turn', [(d['floor'], d['turn']) for d in potions], [(3, 2), (4, 1), (5, 2), (11, 1), (11, 2), (15, 1), (15, 1)])
facts['ken_potions'] = [{k: d[k] for k in ['line', 'floor', 'turn', 'expect']} for d in potions]
rooms = []
for floor in [2, 3, 4, 5, 11, 15]:
    rows = [s for s in by_run['KEN58SH9SLZ6'] if s['floor'] == floor]
    first = next(s for s in rows if s['in_combat'])
    after = next(s for s in rows if s['line'] > first['line'] and not s['in_combat'])
    rooms.append({'floor': floor, 'entry_line': first['line'], 'exit_line': after['line'], 'net_loss': first['hp'] - after['hp']})
check('KEN won-room net losses', [r['net_loss'] for r in rooms], [0, 3, 0, 37, 6, 0])
facts['ken_won_rooms'] = rooms
for floor, before, after in [(12, (26, 76), (53, 81)), (16, (46, 81), (75, 86))]:
    rows = [s for s in by_run['KEN58SH9SLZ6'] if s['floor'] == floor]
    check('KEN rest before F' + str(floor), any((s['hp'], s['max_hp']) == before for s in rows), True)
    check('KEN rest after F' + str(floor), any((s['hp'], s['max_hp']) == after for s in rows), True)

for line, expected in [(275342, (3, 36)), (275383, (0, 27)), (275894, (13, 24)), (275960, (22, 39)), (275885, (0, 24)), (276139, (4, 24))]:
    value = window(line)
    check('turn boundary ' + str(line), (value['hp_loss'], value['enemy_net_hp_loss']), expected)
    facts[str(line)] = value
check('WQZ T9 same explicit fingerprint', D[275894]['fingerprint'], D[275960]['fingerprint'])
check('WQZ T7 baseline sandpit', facts['275885']['last_sandpit'], [4])
check('WQZ T7 changed sandpit', facts['276139']['last_sandpit'], [5])
check('TXZ first boss exit', S[281563]['hp'], 4)
check('TXZ second boss entry', (S[281565]['floor'], S[281565]['hp']), (49, 4))
check('TXZ second boss pre-action death', S[281566]['hp'], 0)
check('TXZ enemy unchanged on opening death', [e['hp'] for e in S[281565]['enemies']], [e['hp'] for e in S[281566]['enemies']])

cunning = json.loads((HERE / 'cunning-observed-windows.json').read_text())
check('Cunning number of observed uses', len(cunning), 42)
check('Cunning capacity histogram', dict(Counter(x['gained'] for x in cunning)), {3: 37, 2: 2, 0: 3})
for item in cunning:
    check('Cunning capacity decision ' + str(item['decision']), item['gained'], min(3, 10 - item['before']))
    check('Cunning generated upgraded shivs ' + str(item['decision']),
          all(c['card_id'] == 'SHIV' and c['upgraded'] is True and
              next(v['base_value'] for v in c['dynamic_values'] if v['name'] == 'Damage') == 6 for c in item['new']), True)
    a, b = S[item['pre']], S[item['post']]
    check('Cunning current action no HP/energy/enemy HP change ' + str(item['decision']),
          (a['hp'], a['energy'], [e['hp'] for e in a['enemies']]),
          (b['hp'], b['energy'], [e['hp'] for e in b['enemies']]))
facts['cunning'] = {'uses': len(cunning), 'runs': sorted({x['run'] for x in cunning}), 'histogram': dict(Counter(x['gained'] for x in cunning))}

check('Q6 ordinary strangle sequence HP', [S[n]['enemies'][0]['hp'] for n in [282887, 282888, 282889, 282890, 282891, 282892]], [103, 95, 85, 85, 83, 80])
check('1913 discard abrasive same energy', (S[282767]['energy'], S[282768]['energy']), (3, 3))
check('1913 discard abrasive dexterity/thorns', (S[282768]['powers'].get('DEXTERITY_POWER'), S[282768]['powers'].get('THORNS_POWER')), (1, 4))
check('NHA preliminary non-operable state', (S[283390]['hp'], sum(e['hp'] for e in S[283390]['enemies'])), (28, 428))
check('NHA operative baseline', (S[283391]['hp'], sum(e['hp'] for e in S[283391]['enemies'])), (30, 408))
check('NHA original observed boundary', (S[283391]['hp'] - S[283397]['hp'], sum(e['hp'] for e in S[283391]['enemies']) - sum(e['hp'] for e in S[283397]['enemies'])), (1, 8))
check('NHA changed observed boundary', (S[283479]['hp'] - S[283483]['hp'], sum(e['hp'] for e in S[283479]['enemies']) - sum(e['hp'] for e in S[283483]['enemies'])), (7, 24))
check('NHA displayed facing pair', (S[283398]['enemies'][0]['intents'][0]['damage'], S[283399]['enemies'][0]['intents'][0]['damage']), (1, 2))
for decision, before, after, amount in [(212867, 217009, 217010, 8), (227928, 232562, 232563, 10), (276925, 283146, 283147, 10)]:
    target = D[decision]['chosen']['target_index']
    start = next(e for e in S[before]['enemies'] if e['index'] == target)
    final = next(e for e in S[after]['enemies'] if e['index'] == target)
    check('lamp observed first poison ' + str(before), final['powers'].get('POISON_POWER', 0) - start['powers'].get('POISON_POWER', 0), amount)
for before, after in [(283394, 283395), (283415, 283416), (283437, 283438), (283459, 283460), (283481, 283482), (283505, 283506)]:
    check('lamp observed X1 malaise ' + str(before),
          (S[before]['energy'], S[after]['energy'], S[after]['enemies'][0]['powers'].get('STRENGTH_POWER'), S[after]['enemies'][0]['powers'].get('WEAK_POWER')),
          (1, 0, -2, 2))

for run, floor, entry_hp, exit_hp in [('Q6M2Y34MWKRE', 8, 57, 2), ('Q6M2Y34MWKRE', 9, 2, 0), ('1913SE84AXQF', 29, 61, 46), ('1913SE84AXQF', 31, 46, 0)]:
    rows = [s for s in by_run[run] if s['floor'] == floor]
    first = next(s for s in rows if s['in_combat'])
    after = next(s for s in rows if s['line'] > first['line'] and not s['in_combat'])
    check('resource chain ' + run + ' F' + str(floor), (first['hp'], after['hp']), (entry_hp, exit_hp))
    facts[run + ':F' + str(floor)] = {'entry': first['line'], 'exit': after['line'], 'entry_hp': first['hp'], 'exit_hp': after['hp']}

(HERE / 'facts.json').write_text(json.dumps(facts, ensure_ascii=False, indent=2) + '\n')
(HERE / 'fact-checks.json').write_text(json.dumps({'checks': checks, 'passed': len(checks), 'kind': 'material_assertions_only; no production test or source withdrawal'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed_material_assertions': len(checks), 'facts': facts}, ensure_ascii=False))

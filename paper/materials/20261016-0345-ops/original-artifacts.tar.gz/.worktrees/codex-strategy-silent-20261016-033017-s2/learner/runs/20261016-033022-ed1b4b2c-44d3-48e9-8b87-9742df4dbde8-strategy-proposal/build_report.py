import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = '222d38ef529551be316900c72c955a88654c151d'
BATCH = '20261016-033017-s2-strategy-proposal'
ROOT = Path('/home/dw/Projects/agent-sts2')
originals = json.loads((HERE / 'original-proposals.json').read_text())
dispatch = json.loads((HERE / 'dispatch-row.json').read_text())
assert [p['id'] for p in originals] == dispatch['proposal_ids']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
data = [
    ('赢战耗药与真实回复', 'KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1–2/F15T1，decisions 274131/274156/274185/274235/274237/274267/274272；states 280169–280377。',
     '七次饮药、六赢战净损0/3/0/37/6/0合46；F12实际26/76→53/81、F16实际46/81→75/86。',
     '现有药水候选、当前HP与路线投影仍沿用原规则；已执行资源消耗与未来留药价值分开。',
     '缺F15未饮用及同入口、同后继留药至Boss的完整成对结果；七次实际饮药与两次回复端点不足校准持药价。',
     'F15零损时实际已喝两瓶，不能推未喝亦零损；六次Boss尝试属于同一局。未来按独立局和时间留出核完整后继。'),
    ('SL首战与连续通关', 'TXZ6RVMQA09D A10 F48T6，decisions 275342/275383–275385；states 281563–281566。',
     '原线当轮损3/伤36，替线损0/伤27；第三次首Boss赢后4HP，F49入口4→0且敌111HP未变。',
     '已有连续Boss目标与新战入口扣血分支；当轮模型诊断只记录预测，完整实盘接续另验。',
     '缺保持抽序、生成和药栏一致的两战完整替线；开场扣血与连续Boss源码不覆盖SL资源比较和连续通关校准。',
     '少损3亦少扣9，后续抽牌已变，首胜不能证明两战改善；原1200样本首胜/后败仍非校准后的实盘概率。'),
    ('沙虫的血量和沙坑两条边界', 'WQZVENQ7DTRP A10 F33第2/3次T9，decisions 275894/275960，states 282075–282079/282144–282148；第2/6次T7，275885/276139。',
     '同显式指纹26HP/敌184HP，损13/伤24→损22/伤39，多付9血多打15；T7损0/伤24→损4/伤24、沙坑4→5。',
     '现有SL诊断列当前轮预测与沙坑；替换门槛保持，整轮端点与完整候选执行身份分账。',
     '缺攻防与沙坑双边界的完整受控后继、跨重规划候选执行绑定及独立胜局；当前端点不能确定新SL血价门槛。',
     '支付4血也延长沙坑一轮，不能统一禁止多损血换线；六次尝试不拆为独立胜率样本。'),
    ('狡诈药水的生成、容量与穿插', '02HB4L0C3C67/4D4J8USKCPAV/F4QKG4J1AJJZ/JLN5SK17W4FQ/LS8035TB32P3/NB8KCF6HRGVF/S9UZAK0JP0C0/SADL3CGYTGSR/WQZVENQ7DTRP；WQZ F33第5/6次T11 decisions 276102–276104/276161–276163。',
     '九局42次饮用：37次添3、2次添2、3次添0；新刀均升级且基础6；8手三饮添2/0/0、5手三饮添3/2/0，当步HP/能量/敌HP不变。',
     '生成与容量已有5b56a452bb9be14d620b368ec46974c1b57901ca，当前模型限定silent A7/A9/A10。',
     '确定生成与容量已有live窄实现；仍缺计划妥当保留、穿插出刀、整候选实际派发和SL恢复的联合校准，不能关闭整项。',
     '满手耗瓶不等于药水不消耗，也不能假设穿插多刀能救败局；容量不足只有WQZ这一局。'),
    ('开场资源、连续战与SL联合要求', 'TXZ6RVMQA09D A10 F43/45/46/48/49及F48T6；WQZVENQ7DTRP A10 F33T7/T9，原提案关联账本逐项保留。',
     'TXZ F49实见4→0；WQZ T9多9血换15伤，T7付4血换沙坑一轮。',
     '已观察的王室猛毒组合新战扣4，live T1/SL恢复不再扣；未知回血和自动复活组合沿未建模路径。',
     '开场4血窄分支已有live实现；缺留药、路线和SL完整后继对照，以及未知回血/复活组合结算顺序，不能据子项关闭联合要求。',
     '有小血瓶的旧组合净2不在本批15局中重验，不反推遗物内部顺序；不预支空奖励或尚未执行的用药。'),
    ('胜战退出HP、持续药和下一战', '1913SE84AXQF A10 F29→31；Q6M2Y34MWKRE A10 F2T1/T3、F8T1/T4、F9T2，decisions 276596/276665，states 282723–282783/282872–282921。',
     '1913 F29 61→46、F31入口46后死；Q6 F8 57→2后F9入口2并死。Q6两瓶和1913八瓶均饮用。',
     '保留既有药价、护栏和终局权重；普通紧勒已接线，低可信候选仍不能替代真实退出资源。',
     '缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战和下一战后继，不能由两条失败链校准资源权重。',
     'Q6 F5/F6实际零损留药；F2早喝线未完整执行，不能据单题推出总应早喝。未来先固定模型再按run隔离时间验证。'),
    ('普通紧勒与增益分源联合验收', 'Q6M2Y34MWKRE A10 F8T4 states 282887–282892；1913SE84AXQF A10 F31T2 states 282767–282768及T3/T4；原提案其他历史样本限原文。',
     '普通紧勒103→95→85→85→83→80，弃牌完成才扣2；1913弃磨蚀能量3→3，建立1敏/4荆棘。',
     '普通无挡紧勒已有66283dd9982bdd7f480da7a4d9bfefea0572a9ac；源码将升级、叠层、自动重放等未验分支标未知。',
     '普通紧勒已有live窄实现；缺弃磨蚀、增益分源、再生、自动触发和SL恢复的联合消费者校准及受控整战后继。',
     '当前资源快照不说明完整触发全序，反杀不代付已发动攻击，死亡实扣有余血截顶；不据整战失败否定已核子公式。'),
    ('路线、休息和未触发能力兑现', '1913SE84AXQF A10 F24/F28/F29/F31；Q6M2Y34MWKRE A10 F3/F7/F8/F9，states 282723/282745/282755/282783及282872/282907/282913/282921。',
     '1913 F24锻造后未回血、F28回21后F29损15，F31以46进战；Q6 F7回血后57，赢精英余2，后走廊死。',
     '路线模型含条件性未来休息投影；保持按现场重规划，未抵达营火和未触发能力不记为当前实际收入。',
     '缺另一营火、事件、路线和用药时机的受控完整结果；实际两条资源链只能复核兑现，不能拟合路线或终局权重。',
     '1913原路线预期后来改锻造，不能把全部差额当同条件误差；原109局统计未在本任务重新全量核验。'),
    ('死亡饱和时的SL替换', 'NHA2KW0RB7VP A10 F33第1/5/6次T1，decisions 277248/277250/277272/277274；states 283390–283397/283479–283483。',
     '准备帧28HP/敌428与可操作30HP/敌408分列；原轮损1/净伤8，换线轮损7/净伤24，多6血换16伤；含轮初自动伤。',
     'SL资源与选择审计已有预测及首动作记录，execution=unverified、actual_turn=null；弃牌后的重新规划另验。',
     '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对完整后继；六次同局失败不足确定新SL阈值。',
     '精确切击在弃牌中离手，不能将初案全当已执行；更高输出与所有尝试失败都不能证明换线改善或原答必胜。'),
    ('油灯、朝向取整与能力兑现', 'K3676LU8B0UH A1 F30T2 states 217009–217010；SADL3CGYTGSR A7 F45T1 232562–232563；NHA2KW0RB7VP A10 F17T1/F33六次T1/T2，283146–283147/283394–283506。',
     '按真实目标索引复核毒0→8/0→10/0→10；NHA六试普通X1萎靡均减2力/施2弱；T2朝向显示1→2。',
     '蟹朝向窄修68711002f15b298b8863d2258ee5da236da151d2已在live祖先；当前模块限定A10、招式、力量、虚弱及数据库现场基值。',
     '蟹朝向窄分支已有live实现；缺油灯首次消费身份跨动作/新战/SL恢复联合输入，以及未覆盖X值、升级组合和能力整战后继。',
     '毒三直接窗口加六萎靡窗口属于本次语义核验；原文三局17窗口不冒称全部重新分析。其他负面/零X/叠层与早建能力胜因仍未知。'),
]
items = []
for original, row in zip(originals, data):
    title, evidence, verified, current, reason, limit = row
    items.append({'id': original['id'], 'title': title, 'state': 'waiting', 'evidence': evidence,
                  'verified': verified, 'current': current, 'reason': reason, 'limitations': limit,
                  'ledger': original['ledger'], 'original_proposal': original['proposal'],
                  'original_sha256': original['proposal_sha256']})
(HERE / 'dispositions.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
header = f'''# 本批十项静默策略提案处置

记录时间：2026-10-16T03:39:38+08:00（写入前已运行date）。
task=strategy-proposal；character=silent；batch={BATCH}。
基线：`{BASE}`。初始工作树干净，`git merge --no-edit main` 返回Already up to date。
派发行reason=proposal，有十个proposal_ids，无research_request/implementation_request/proposal_repair；普通专题条件不匹配，继续原队列职责。

结论：十项均waiting，原生产行为保留。没有足够证据新增留药价格、统一血价、SL门槛或终局权重，也未发现本批可独立定位的新纯bug。既有子项的live源码祖先不代表整项联合要求已完成。无源码修改、无提交、无live合入、无版本或shipped登记。

提案原文逐份SHA核同，副本保存本目录对应id.md，原文不改。只处理本批十个id，原文的其他局号只用于它们的证据补核。

## 证据边界

本批十锚点加五个原提案来源局，共15个SILENT局：A1一局、A7一局、A9一局、A10十二局。`runs-identity.json`保留原runs行和offset/bytes/SHA。未读取其他角色知识。
共用extract_evidence.py冻结八流：states 9815、decisions 9448、sl-attempts 78、run-config 15、run-plans 77、brain 481、runs 15、fight-plans 0，共19929条。每流source_size、计数、产物SHA及逐行原字节SHA均已复核，显式run_id/state.run_id/fingerprint.run/run冲突不接收，正文提及不作身份。
fight-plans的0仅是该截点未选中所属行，不断言原日志不存在；全源扫描有5个无效JSON行（states2/decisions2/brain1），这些行不进入证据。没有重写旧截点或零行初稿。
字节核验覆盖全部所属行；机制和资源结论只限下列明确窗口。旧105/109/112局统计、原树dirty内容、未执行替线与完整未来结果没有在这里重建。SL多次尝试和同轮抽样不计为独立局。

## 已有实现核对

核查时live HEAD为`e716bd28fd8eca9e4d76d066680304fd11935e37`。14个相关源码叶已保存SHA，10个字节相同；4个叶仅见Roy/Dai历史注释差异，原diff保存base-live-source.patch。本批未做转译或用测试证明这些树整体等价。
以下5个提交均已核为本批base及该live的祖先，详情见partial-source-ancestry.json及blame材料：

- `5b56a452bb9be14d620b368ec46974c1b57901ca`：狡诈确定生成/容量及王室猛毒原观察分支。
- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：普通紧勒窄分支、当前轮SL资源对照；后者execution=unverified。
- `68711002f15b298b8863d2258ee5da236da151d2`：已观察蟹招式的虚弱/朝向取整。
- `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`：扩展已观察王室猛毒组合，未扩到未知复活/回血组合。
- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`：选择审计及当前预测事实；pending_dispatch与actual_turn=null保留。

当前代码已展示事实和参考候选，本任务没有删选项或修改出牌执行、药水、SL或终局规则。铁甲与其他角色执行代码零差异。

## 逐项处置

'''
sections = []
for n, item in enumerate(items, 1):
    sections.append(f'''### {n}. {item['title']}

ID：`{item['id']}`；处置：waiting。
账本：{', '.join(item['ledger'])}。
原文：{item['original_proposal']}；SHA256=`{item['original_sha256']}`。

证据：{item['evidence']}
核实：{item['verified']}
旧/现规则与本批预期行为：{item['current']} 本批继续现行为；已有实现范围以源码门禁为准。
未实现原因：{item['reason']}
反例和限制：{item['limitations']}
验证方法：facts.json引用的原行动、结算端点和逐行来源，结合当前源码检查；后续满足上述缺口后再作固定输入验证，按独立局时间划分回放与新局验证。不会把局部已观测端点认证成完整候选执行。
预期影响与回退：本批对局行为不变，无待撤源码；未来如实现策略，以独立提交撤回对应规则，保留本批原证据、失败、提案与账本，不覆盖并行改动。既有Roy-2026-10-07-learning授权不提供游戏事实。

''')
footer = f'''## 验证、账本和交付

全部原字节/身份核验通过。材料断言首次176项通过；增补油灯窗口时脚本误将目标设为首敌，217009断言失败，原脚本check-facts-lamp-initial.py.txt及fact-check-with-lamp.stderr.txt保留。按真实decision.target_index修正后185项材料断言通过，最终stderr为空。该失败属于本批审计脚本，未据此登记产品bug或新机制反证。

这些是材料核验，不是生产tsc/vitest或撤源码负控。无源码修改，tests={{"tsc":null,"vitest":null,"cases":null}}；撤源码失败/恢复通过不适用。无测试成功、合入成功或收益声称。原始提取和检查回执、初稿全部保留。

仅经根learner/ledger.py update为原31个账本项补本报告/提案追溯链接和note；不重复旧evidence或repeat，不改旧claim/first_run/prior/status/version。最终CLI核验回执见ledger-append-verification.json。没有新增代码提案id，原十个CLI id继续；尚未完成的要求和原owner保持。

本批实际未改源码，不进入live发布流程，不刷新知识/版本/decision-log，不启动play。经验库发布、自然消费者读回和整体收益未由本批完成。

运维交付：`{HERE / 'proposal.md'}`、`{HERE / 'report.md'}`、result.json；每个派发id均有waiting和具体缺口。运维按原调度链保留待新局复审，不将本次报告等同学习入库完成。
'''
(HERE / 'proposal.md').write_text(header + ''.join(sections) + footer)
report = header + '| 提案id | 处置 | 缺口 |\n|---|---|---|\n'
for item in items:
    report += f"| {item['id']} | waiting | {item['reason']} |\n"
report += '\n逐项证据局号、层、回合、账本、旧/新行为、反例、验证和回退见同目录proposal.md逐项段落。\n\n' + footer
(HERE / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{'id': item['id'], 'state': 'waiting', 'reason': item['reason']} for item in items],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposal_count': len(items), 'result': str(HERE / 'result.json'), 'base': BASE}, ensure_ascii=False))

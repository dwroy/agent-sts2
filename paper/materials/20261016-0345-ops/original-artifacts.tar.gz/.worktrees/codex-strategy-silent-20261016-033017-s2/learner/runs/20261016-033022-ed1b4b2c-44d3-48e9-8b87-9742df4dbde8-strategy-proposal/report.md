# 本批十项静默策略提案处置

记录时间：2026-10-16T03:39:38+08:00（写入前已运行date）。
task=strategy-proposal；character=silent；batch=20261016-033017-s2-strategy-proposal。
基线：`222d38ef529551be316900c72c955a88654c151d`。初始工作树干净，`git merge --no-edit main` 返回Already up to date。
派发行reason=proposal，有十个proposal_ids，无research_request/implementation_request/proposal_repair；普通专题条件不匹配，继续原队列职责。

结论：十项均waiting，原生产行为保留。没有足够证据新增留药价格、统一血价、SL门槛或终局权重，也未发现本批可独立定位的新纯bug。既有子项的live源码祖先不代表整项联合要求已完成。无源码修改、无提交、无live合入、无版本或shipped登记。

提案原文逐份SHA核同，副本保存本目录对应id.md，原文不改。只处理本批十个id，原文的其他局号只用于它们的证据补核。

## 证据边界

本批十锚点加五个原提案来源局，共15个SILENT局：A1一局、A7一局、A9一局、A10十二局。`runs-identity.json`保留原runs行和offset/bytes/SHA。未读取其他角色知识。
共用extract_evidence.py冻结八流：states 9815、decisions 9448、sl-attempts 78、run-config 15、run-plans 77、brain 481、runs 15、fight-plans 0，共19929条。每流source_size、计数、产物SHA及逐行原字节SHA均已复核，显式run_id/state.run_id/fingerprint.run/run冲突不接收，正文提及不作身份。
fight-plans的0仅是该截点未选中所属行，不断言原日志不存在；全源扫描有5个无效JSON行（states2/decisions2/brain1），这些行不进入证据。没有重写旧截点或零行初稿。
字节核验覆盖全部所属行；机制和资源结论只限下列明确窗口。旧105/109/112局统计、原树dirty内容、未执行替线与完整未来结果没有在这里重建。SL多次尝试和同轮抽样不计为独立局。

## 已有实现核对

核查时live HEAD为`e716bd28fd8eca9e4d76d066680304fd11935e37`。14个相关源码叶已保存SHA，10个字节相同；4个叶仅见Roy/Dai历史注释差异，原diff保存base-live-source.patch。本批未做转译或用测试证明这些树整体等价。
以下5个提交均已核为本批base及该live的祖先，详情见partial-source-ancestry.json及blame材料：

- `5b56a452bb9be14d620b368ec46974c1b57901ca`：狡诈确定生成/容量及王室猛毒原观察分支。
- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：普通紧勒窄分支、当前轮SL资源对照；后者execution=unverified。
- `68711002f15b298b8863d2258ee5da236da151d2`：已观察蟹招式的虚弱/朝向取整。
- `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`：扩展已观察王室猛毒组合，未扩到未知复活/回血组合。
- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`：选择审计及当前预测事实；pending_dispatch与actual_turn=null保留。

当前代码已展示事实和参考候选，本任务没有删选项或修改出牌执行、药水、SL或终局规则。铁甲与其他角色执行代码零差异。

## 逐项处置

| 提案id | 处置 | 缺口 |
|---|---|---|
| silent-proposal-08eaa60bcc449852 | waiting | 缺F15未饮用及同入口、同后继留药至Boss的完整成对结果；七次实际饮药与两次回复端点不足校准持药价。 |
| silent-proposal-92920295a648b540 | waiting | 缺保持抽序、生成和药栏一致的两战完整替线；开场扣血与连续Boss源码不覆盖SL资源比较和连续通关校准。 |
| silent-proposal-a327449c331efbc1 | waiting | 缺攻防与沙坑双边界的完整受控后继、跨重规划候选执行绑定及独立胜局；当前端点不能确定新SL血价门槛。 |
| silent-proposal-a099e89437e942bb | waiting | 确定生成与容量已有live窄实现；仍缺计划妥当保留、穿插出刀、整候选实际派发和SL恢复的联合校准，不能关闭整项。 |
| silent-proposal-47910f82a1fdd98f | waiting | 开场4血窄分支已有live实现；缺留药、路线和SL完整后继对照，以及未知回血/复活组合结算顺序，不能据子项关闭联合要求。 |
| silent-proposal-f1374df72d8e6a25 | waiting | 缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战和下一战后继，不能由两条失败链校准资源权重。 |
| silent-proposal-38a49e6c97f31eea | waiting | 普通紧勒已有live窄实现；缺弃磨蚀、增益分源、再生、自动触发和SL恢复的联合消费者校准及受控整战后继。 |
| silent-proposal-ef0e38a5dbd3bc07 | waiting | 缺另一营火、事件、路线和用药时机的受控完整结果；实际两条资源链只能复核兑现，不能拟合路线或终局权重。 |
| silent-proposal-7f820c02d39bfaea | waiting | 缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对完整后继；六次同局失败不足确定新SL阈值。 |
| silent-proposal-04b6b430759815ed | waiting | 蟹朝向窄分支已有live实现；缺油灯首次消费身份跨动作/新战/SL恢复联合输入，以及未覆盖X值、升级组合和能力整战后继。 |

逐项证据局号、层、回合、账本、旧/新行为、反例、验证和回退见同目录proposal.md逐项段落。

## 验证、账本和交付

全部原字节/身份核验通过。材料断言首次176项通过；增补油灯窗口时脚本误将目标设为首敌，217009断言失败，原脚本check-facts-lamp-initial.py.txt及fact-check-with-lamp.stderr.txt保留。按真实decision.target_index修正后185项材料断言通过，最终stderr为空。该失败属于本批审计脚本，未据此登记产品bug或新机制反证。

这些是材料核验，不是生产tsc/vitest或撤源码负控。无源码修改，tests={"tsc":null,"vitest":null,"cases":null}；撤源码失败/恢复通过不适用。无测试成功、合入成功或收益声称。原始提取和检查回执、初稿全部保留。

仅经根learner/ledger.py update为原31个账本项补本报告/提案追溯链接和note；不重复旧evidence或repeat，不改旧claim/first_run/prior/status/version。最终CLI核验回执见ledger-append-verification.json。没有新增代码提案id，原十个CLI id继续；尚未完成的要求和原owner保持。

本批实际未改源码，不进入live发布流程，不刷新知识/版本/decision-log，不启动play。经验库发布、自然消费者读回和整体收益未由本批完成。

运维交付：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-033017-s2/learner/runs/20261016-033022-ed1b4b2c-44d3-48e9-8b87-9742df4dbde8-strategy-proposal/proposal.md`、`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-033017-s2/learner/runs/20261016-033022-ed1b4b2c-44d3-48e9-8b87-9742df4dbde8-strategy-proposal/report.md`、result.json；每个派发id均有waiting和具体缺口。运维按原调度链保留待新局复审，不将本次报告等同学习入库完成。

完成读回：根账本31项均实际包含本批proposal.md链接，31项状态与CLI前一致；旧保护字段及历史前缀保留。git status --porcelain为空，HEAD仍为本报告base。gitleaks与生产测试未运行，本批无提交。

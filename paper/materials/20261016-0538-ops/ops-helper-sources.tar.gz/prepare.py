from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0538';pub=root/'paper/materials/20261016-0538-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-052701-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'report.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in report.items() if k!='proposal_results'}=={k:v for k,v in scratch.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in report['proposal_results']]==[(x['id'],x['state']) for x in scratch['proposal_results']] and all(x['reason'] for x in scratch['proposal_results'])
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-state.json');assert final['base']==final['head']==report['base'] and final['status_porcelain']=='' and final['source_unchanged'] and final['knowledge_unchanged'] and final['ledger_owned_update_count']==30
assert (s/'source-baseline.patch').read_bytes()==b'' and final['diff_binary_sha256']==sha(b'') and final['report_sha256']==sha((s/'report.md').read_bytes()) and final['proposal_sha256']==sha((s/'proposal.md').read_bytes())
originals=load(s/'original-proposal-check.json');assigned=load(s/'assigned-proposals.json');assert len(originals)==len(assigned)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    original=Path(x['path']);queued=next(y for y in assigned if y['id']==x['id']);assert original.is_relative_to(root) and sha(original.read_bytes())==x['sha256']==queued['proposal_sha256'] and len(original.read_bytes())==x['bytes']
extract=module('original_extract',root/'learner/extract_evidence.py');receipts=load(s/'offline-audit-results.json');assert len(receipts)==6 and all(x['exit_code']==0 for x in receipts)
needed={stream:set() for stream in ['states','decisions']}
for x in receipts:
    data=load(s/('audit-'+x['run']+'.input.json'))
    for stream in needed:needed[stream].update(row['_line'] for row in data[stream])
facts=load(s/'material-verification.json');assert len(facts['assertions'])==41 and all(x['actual']==x['expected'] for x in facts['assertions']) and (s/'verify-materials.stderr').read_bytes()==b''
needed['decisions'].update(line for pair in facts['pair_endpoints'] for line in pair['decisions'])
counts={};runs={};configs={};input_rows={stream:{} for stream in needed};manifests=[]
for folder in ['evidence','evidence-extra']:
    for x in load(s/folder/'evidence-manifest.json'):
        manifests.append(dict(folder=folder,**x));frozen=s/folder/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
        with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
            for line in selected:
                digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
                assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in report['runs']
                if x['stream']=='states':assert (row['state']['run']['character_id'],row['state']['run']['ascension'])==('SILENT',10)
                if x['stream']=='runs':assert (row['character'],row['ascension'],row['victory'])==('SILENT',10,False);runs[e['run_id']]=row
                if x['stream']=='run-config':configs[e['run_id']]=row
                if x['stream'] in needed and e['line'] in needed[x['stream']]:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row,sha256=e['sha256'])
                seen[e['run_id']]+=1
        assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=counts.get(x['stream'],0)+sum(seen.values())
assert sum(counts.values())==8274 and len(runs)==len(configs)==6
assert {k:v for k,v in counts.items() if v}==facts['verified_rows']
for pair in facts['pair_endpoints']:
    a,z=pair['decisions'];assert input_rows['decisions'][a]['row']['fingerprint']==input_rows['decisions'][z]['row']['fingerprint']
additional=load(s/'additional-evidence.json')
for x in additional['runtime_code_scope']:
    assert configs[x['run']]['code']==x['code'] and configs[x['run']]['knowledge']==x['knowledge'] and all(path.startswith(('knowledge/','notes/')) for path in x['code']['dirty_files'])
source=load(s/'source-readback.json');assert source['base']==report['base'] and len(source['files'])==20 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['live_observed']
for x in source['files']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live_observed']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (root/'.worktrees/live'/x['path']).read_bytes()==z
    assert (a==z)==x['same_bytes'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and x['last_commit_live_ancestor'];git('merge-base','--is-ancestor',x['last_path_commit'],source['live_observed'])
assert sum(x['same_bytes'] for x in source['files'])==16
totals=collections.Counter();consumers=[]
for x in receipts:
    run=x['run'];ip=s/('audit-'+run+'.input.json');op=s/('audit-'+run+'.output.json');err=s/('audit-'+run+'.stderr')
    assert sha(ip.read_bytes())==x['input_sha256'] and sha(op.read_bytes())==x['output_sha256'] and sha(err.read_bytes())==x['stderr_sha256']
    data=load(ip);audit=load(op);assert data['run']==runs[run]
    for stream in needed:
        for row in data[stream]:
            reference=input_rows[stream][row['_line']];assert reference['run']==run and row['_source_sha256']==reference['sha256']
            expected={**reference['row'],'_line':row['_line'],'_source_sha256':reference['sha256']}
            if stream=='decisions':expected.pop('agent_view',None);assert row.get('decision_id')
            assert row==expected
    status=collections.Counter(row['status'] for row in audit['observed_turns']);assert all(row['actual_full_candidate_result'] is None for row in audit['segments'])
    actions=audit['observed_actions'];c=dict(segments=len(audit['segments']),actions=len(actions),turn_windows=len(audit['observed_turns']),turn_endpoints=status['observed_turn_endpoints'],turn_unknown=status['unknown'],interval_endpoints=sum((row.get('observed_interval') or {}).get('status')=='observed_endpoints' for row in actions),terminal_endpoints=sum((row.get('terminal_observation') or {}).get('status')=='observed_terminal_endpoints' for row in actions))
    assert all(c[k]==x[k] for k in c);totals.update(c);consumers.append(dict(run=run,**c))
assert totals==dict(segments=266,actions=1361,turn_windows=244,turn_endpoints=136,turn_unknown=108,interval_endpoints=1008,terminal_endpoints=5)
for entry in load(s/'artifact-manifest.json'):
    f=s/entry['path'];assert f.is_relative_to(s);raw=f.read_bytes();assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
receipt=load(s/'ledger-update-receipt.json');rows=load(s/'ledger-owned-appends.json');inputs=[json.loads(line) for line in (s/'ledger-update-input.jsonl').read_text().splitlines()]
assert receipt['exit_code']==0 and len(rows)==len(inputs)==receipt['count']==30 and receipt['root_prefix_preserved'] and receipt['original_claim_identity_prior_status_version_preserved'] and receipt['old_evidence_and_where_prefix_preserved']
assert set((s/'ledger-update.stdout').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-update.stderr').read_bytes()==b'' and sha((s/'ledger-update-input.jsonl').read_bytes())==receipt['input_sha256']
own=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(receipt['root_before_bytes']))==receipt['root_before_prefix_sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        assert any(all(row.get(k)==v for k,v in item.items()) for item in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==30 and not set(raw.rstrip(b'\n') for raw in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
assert final['gitleaks_exit_code']==0 and load(s/'gitleaks-report.json')==[]
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_report=scratch,report_reason_scope='Stdout/learn use shorter waiting reasons; scratch retains the longer original reasons. Identity, disposition and other fields match; initial overstrict whole-object equality failure is retained in the ops log.',original_gate=b['no_change_proposals'],native=native,original_completion=final,original_proposals=originals,stream_counts=counts,original_rows_verified=8274,ascension_cohorts={10:6},material_assertions=41,source=source,additional_evidence=additional,original_consumers=receipts,consumer_counts=dict(totals),consumer_summaries=consumers,owned_trace_rows=rows,protected_fields_and_prefixes_preserved=True,no_checks_reexecuted=True,limits=['Source commits are identifiable; listed dirty files are knowledge/notes, not changed tracked source. Missing historical refreshed knowledge bytes and full joint consumer calibration remain distinct limitations.','Four equal-fingerprint pairs certify local net endpoints only; correlated SL and different sampling cannot certify complete candidate execution or controlled full fights.','CA twelve windows remain unknown; hand-read states do not override tool checks or fill zero.','Capped actual death loss5 and arithmetic displayed deficit15 differ; end-turn enemy loss24 and whole-turn net36 are separate windows.','Original null-combat/path guesses/output truncation retained; no new gameplay counterevidence or notice acknowledgment claimed. No source, merge, release, production tests, paper refresh, dispatch or game restart; wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/folder/'evidence-manifest.json' for folder in ['evidence','evidence-extra']]+[out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0538原052701-s2策略done0/no-source核收，94dc基线干净WT/HEAD不变，十waiting具体缺口/testsnull/mergednull保持，无合入受阻。六Silent A10八流8274原行逐offset/bytes/SHA/JSON/显式身份核，41原材料断言首次通过；四同指纹配对仅局部净端点，六有界离线input/output/stderr与原行去decisions.agent_view/真实_line及_source_sha256绑定核，266题段/1361动作/244轮窗（136可核108未知）、1008相邻端点/5终态端点，整候选全null，不作生产测试/自然采用/完整后继。CA十二窗unknown不补0；沙虫死亡截顶5与显示差15、结束回合扣24与整轮扣36分列不混窗。20源码叶16同4历史Roy/Dai注释差及真实live祖先核；六run-config原code/dirty范围核，列出脏叶仅knowledge/notes，准确缺口为当时刷新知识/移动表字节和联合消费者校准，不笼统称源码commit不可定位，不改写此前报告或把范围澄清作新游戏反证。30所属CLI只where/note，原物理前缀/offset/SHA和私有fold核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI/证据。原null-combat查看/猜路径/输出截断保持；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核，原报告未自证运行模型分列。仅本人记录/30追溯提交，保并行记录，无源码/合入/发号/补测/论文刷新/复派/重启对局或账号home模型额度权限prompt变更，不关闭宽父。证据paper/materials/20261016-0538-ops/。\n'
note=f'\n- {at} [运维 codex] 原052701-s2十项继续waiting，无源码修改或合入阻塞；8274原行、41原材料断言、六有界离线及30条所属追溯已核。历史source可定位与当时刷新知识未复原的边界已澄清；unknown及宽父保持，无新发布、补测或论文刷新。回执paper/materials/20261016-0538-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=30,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=8274,owned_trace_rows=30,ledger_check=0,paths=len(entries))))

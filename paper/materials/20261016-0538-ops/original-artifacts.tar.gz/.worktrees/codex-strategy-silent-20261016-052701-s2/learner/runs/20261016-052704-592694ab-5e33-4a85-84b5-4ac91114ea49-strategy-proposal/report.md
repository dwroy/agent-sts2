# 静默策略提案处置报告

时间：2026-10-16T05:36:20+08:00。task=strategy-proposal；character=silent；batch=20261016-052701-s2-strategy-proposal。

本批十项均waiting。已验证的局部机制及窄审计已有代码；本批没有发现足以按原提案全部范围改策略或认证duplicate的证据。不新增源码、知识、版本或提案ID，不合入live。后续需要的具体数据逐项列于proposal.md及proposal-dispositions.json。

## 身份、基线与范围

- 初始git status干净，HEAD `94dc14d3046fb899b8027a40b82bb9fda5464062`；按普通任务执行git merge --no-edit main，返回Already up to date。
- 根learn.json对应行task/character/worktree及六runs匹配，有十proposal_ids；没有research_request、implementation_request或proposal_repair。本批reason=proposal，故不匹配手动专题的reason=ops/无proposal_ids条件；只核普通专题请求身份，不读取其他专题材料。
- 根notes/strategy-research-silent.json绑定旧20261010-150327专题，本批不承接，不修改根请求/learn.json/旧父要求。
- 原提案十份Markdown均存在且字节SHA与队列一致。30项账本均为silent，保留原claim/首证/prior/evidence/status/version；仅经根ledger CLI追加本批报告/提案追溯，不把旧shipped降为proposed、不新增重复support/repeat。
- 六runs.jsonl记录均silent A10、整局失败。派发锚点为DUZUBAJ3A8GP、5PM6JAQG6FNQ、CA5KE8GFJ9X2、8JRE1C4H4Z2W、YF0LXT1QSTGG、XP2SL33HT0D9；不取其他角色知识，不把六局称101局全史重验。
- 全程无子agent、网络或play。没有改运行模型/强度设置；本会话原生模型/推理配置未由本报告独立取证，不将文档默认值当实际运行证明。

## 原始证据与确定性核验

使用本树learner/extract_evidence.py，共用入口默认六流另加runs/fight-plans；各流source_size、逐原行line/offset/bytes/SHA和计数保留在evidence*/。八流合计8274条选中原行；verify_materials.py重新seek原日志，逐条比对字节SHA、JSON及显式身份，全部通过。41项材料断言通过，详见material-verification.json，属于材料核验，不是tsc/vitest或策略收益测试。

states 4062、decisions 3941、sl-attempts 38、run-config 6、run-plans 33、brain 188、runs 6、fight-plans 0。run-plans由显式run认领，不按正文提及归属。fight-plans零行仅说明该冻结截点未选中本六局。扫描全源的非JSON行计数states=2、decisions=2、brain=1，与选中证据行分列；不据此诊断本局缺帧原因。

| 同指纹来源 | 层/回合 | 原/替当轮净失血 | 原/替敌净扣HP | 限制 |
|---|---|---|---|---|
| 8JRE1C4H4Z2W，decisions 270216/270282 | F33 T2 | 3/15 | 10/17 | 0/24与5/24不同；后损均47封顶 |
| YF0LXT1QSTGG，271309/271348 | F48 T1 | 0/9 | 45/38 | 24/24全败；抽弃牌及续步分列 |
| XP2SL33HT0D9，271992/272040 | F33 T3 | 9/14 | 24/27 | B2零胜，药瓶和后期未受控 |
| XP2SL33HT0D9，271982/272195 | F33 T1 | 2/10 | 25/34 | 替线建立1力量，不能抹去成长 |

原/替只指同盘起点的实盘当轮净端点；完整指纹匹配不等于相同未来抽牌/随机结果、完整候选执行认证或整战单变量因果。四组pair_endpoints保存真实observed_ts匹配、原行与尝试号；不把预测数字或净HP写成毛伤。

其余复核：DU F27火花3→6与污染逐技能增量；5PM F39负属性/退场恢复/再抢及F38现存电击2→4力、17→19攻击；CA F13喷水11/15/19、弱后11/14与覆甲9/9/8/7/6；YF F48阶段4→212与触媒2但本帧无毒；XP末T2轮初14、镣铐临减、14+6=20和T4意图57→38→28。能力列表未列出记None，不伪造实测零层。原101局机制/路线统计及额外进阶未由本批扩证重建。

沙虫末次T11结束前5血22挡、显示攻击37，终态实际5→0、敌154→130；显示差15仅为算式，零血截断实际5不能冒充完整入伤。整轮工具的166→130含此前动作，结束回合端点154→130另列，不把24与36混为同口径。

## 现有离线消费者实际读回

按learner/selection-execution.md准备六份固定单局、限定层输入，保留原_line及_source_sha256，不重编号、不造尝试号，不依赖刷新知识JSON、LLM或网络。每份仅去除决策顶层agent_view并加入追溯字段；状态保留原字节解析内容。无缺decision_id元数据需要排除。全部通过已存在的learner/audit-selection.ts一次顺序调用，nice19且TMPDIR固定本批scratch。原输入/输出/stderr与SHA见offline-audit-results.json。

| run | 题段 | 动作 | 轮窗 | 可核端点 | 未知 |
|---|---:|---:|---:|---:|---:|
| DUZUBAJ3A8GP | 30 | 162 | 32 | 17 | 15 |
| 5PM6JAQG6FNQ | 18 | 108 | 15 | 7 | 8 |
| CA5KE8GFJ9X2 | 16 | 65 | 12 | 0 | 12 |
| 8JRE1C4H4Z2W | 92 | 439 | 85 | 44 | 41 |
| YF0LXT1QSTGG | 52 | 343 | 55 | 40 | 15 |
| XP2SL33HT0D9 | 58 | 244 | 45 | 28 | 17 |

合计266题段、1361动作、244轮窗，其中136可核、108未知；相邻观测端点1008、终态端点5，完整候选认证0。CA旧行未具备工具所需完整尝试上下文等条件，所选12窗均unknown；手工现场读数不覆盖或改写工具unknown。不能把开场首个输入动作冒认轮初，不跨缺行、尝试或选牌重问拼完整候选。离线消费者正常读回仅证明有限审计路径可用，不是自然大脑采用、新源码上线、机制联合校准或策略获益。

## 当前源码覆盖与部署边界

只读捕获live `e716bd28fd8eca9e4d76d066680304fd11935e37`。source-readback.json记录20个相关源码叶及各自最后路径提交，均核该提交为实际live祖先；16叶字节一致，4叶差异仅为Roy/Dai历史注释，完整差异另存source-live-comment-differences.patch。不改这些历史差异，不宣称整棵main/live树或历史dirty知识等价。

- turn-solver已有技能触发污染及当轮攻击换算；rollout有火花selfPowers和HIGH_VOLTAGE成长路径。它们不能单独证明本提案所要求的当时知识输入、所有联合条件和新召唤代际已校准。
- monster-db的monsterHpAt/moveDamageAt读取当前进阶已有数据，不设房间代价的五样本门槛；ROOM_COST_MIN_N=5用于房间代价。本批没有修改任何数据库/样本门槛。
- silent-selection-audit/sl-comparison/sl-resource-comparison/hp-guard-audit分列原答/护栏/SL候选预测；silent-selection-dispatch记录单动作回执，whole_plan_executed/actual_turn保持null。hand/loop及combat-plan的接线存在，不冒称执行全部续步。
- silent-phase-current分列持有组件、已建能力、当前毒/挡/敏捷，poison_damage_already_dealt为null；离线工具也不认证跨阶段逐击伤害。
- passive-pieces已有HORN_CLEAT_BLOCK=14/TURN=2，move-model已有临时减力后续恢复。窄机制实现不关闭逐候选朝向/弱/临减/伤害/重规划联合对账或宽资源要求。

本批run-config逐项显示dirty_files均为knowledge和notes文件，源码commit身份仍可追溯。因此不沿用笼统的“缺dirty源码”说法；准确缺口是未复原当时刷新的知识/移动表字节及联合消费者校准。配置短SHA不能还原全部知识字节；现有源码可定位也不证明当时完整输入等价。该说明是证据范围澄清，不是新的游戏反证。

## 十项处置

| 提案ID | 结果 | 具体未完成原因 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | waiting | 现有技能污染和火花增长路径已存在；缺当时刷新过的移动表/知识字节与毒、挡、弱、逐击污染的联合固定重放，未选线后继亦未知。 |
| silent-proposal-ae9e692d680e3819 | waiting | 缺逐实体来源账和退场返还/再次抢夺的联合模型消费者验证；现帧总负属性不能补成该来源账，也缺另一杀序完整后继。 |
| silent-proposal-52f1e1bd2e7db0ed | waiting | 当前源码已支持当前进阶首样本读取；缺当时刷新移动表字节及加压、弱、覆甲的联合回放，覆甲全部触发条件仍不足。 |
| silent-proposal-6dd8bbff876be528 | waiting | 连续现存电击证据不能独立证明新召唤实体的代际初始化/不继承处理；缺稳定实体身份、生成后连续轨迹、当时移动表和联合校准。 |
| silent-proposal-578e415a259e6835 | waiting | 当前原答/护栏/SL/首次动作字段及离线端点已存在；缺跨抽弃牌后的完整候选归属、逐能力兑现和全资源链的联合消费者读回，不以窄审计替代整项完成。 |
| silent-proposal-c0767768bf6a7ab1 | waiting | 现有字段把预测和单动作回执分开；缺覆盖重放、抽弃牌重规划后的完整候选执行归属、未选线后继和独立胜局校准，不能拟全败惩罚。 |
| silent-proposal-a46bdb7fe711d79a | waiting | 已有silent-phase-current现场快照和离线相邻端点；缺候选逐步施毒、已结毒伤及跨阶段实际执行的完整联合对账，不调整排序。 |
| silent-proposal-1044224808015e5c | waiting | 两组当轮配对不足以校准血价与永久成长的整战价值；缺相同抽序/药瓶后继受控的整场胜线和独立留出，不能设HP惩罚或封禁付血探索。 |
| silent-proposal-7cbc6005db712ba9 | waiting | 轮初挡、临减恢复和部分朝向已有源码；缺逐候选朝向/弱/恢复/伤害与抽弃牌后继的联合执行记录，不能把单帧参考认作整项已完成。 |
| silent-proposal-c59f592f1427a67e | waiting | 缺候选实际执行与路线/休息/喝药/SL恢复的完整联合消费者、留药及替线独立验证；六派发锚点不能替代原101局统计重建或完成宽父要求。 |

逐项局号/层/回合、全部账本、反例、旧规则/预期行为、验证和回退见[proposal.md](proposal.md)。code_proposals沿用派发原十ID，无新ID；implementation_domains=[]，因为本批没有实际实现任何领域。

## 验证、提交与合入

源码/knowledge/任务模板均无修改，fixes=[]，merged=null；没有源码提交、撤源码红绿、tsc或vitest运行，也没有新eval版本、shipped或实际上线规则通知。tests固定为{"tsc":null,"vitest":null,"cases":null}。41条材料断言及六次离线退出0与生产测试结果分列；不据此报告生产测试成功。

原失败/输出截断及探针问题未当游戏结论：准备阶段一次对非战斗combat=null调用keys失败；若干猜测源码路径不存在/rg退出2；长输出被截断时后续缩小范围，原提案SHA已核。这些不会改生产代码或排队修复。所有过程文件在本批scratch，原日志只读。没有发现新的游戏机制反证，不制造新通知或代任何角色ACK。

后续由调度器保存各ID的waiting处置，待有针对性的新完整证据再派；本报告没有关闭学习入库父要求。运维交付入口为本目录proposal.md、report.md、report.json、proposal-dispositions.json及ledger-update-receipt.json。最终git检查另存final-state.json，要求HEAD仍等于上述40位base、git status干净；报告和证据为被忽略的scratch文件。

最终核验：30条所属CLI追加行按原offset/bytes/SHA保存于ledger-owned-appends.json；无状态/证据修改字段，旧物理前缀和折叠字段保持。gitleaks仅扫描本批scratch，退出0、报告空数组、no leaks found。git status --porcelain=v1 --untracked-files=all为空，HEAD仍为94dc14d3046fb899b8027a40b82bb9fda5464062，git diff --binary为空。附加原帧/SL成功反例及运行dirty范围实核见additional-evidence.json。

import hashlib
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = json.loads((OUT / 'runs-identity.json').read_text())
FLOORS = {'DUZUBAJ3A8GP': {27, 30}, '5PM6JAQG6FNQ': {38, 39},
          'CA5KE8GFJ9X2': {9, 13}, '8JRE1C4H4Z2W': {17, 19, 20, 21, 29, 30, 33},
          'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

streams = {}
verified = Counter()
for folder in ['evidence', 'evidence-extra']:
    for entry in json.loads((OUT / folder / 'evidence-manifest.json').read_text()):
        path = OUT / folder / (entry['stream'] + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['output_sha256']
        rows = []
        with Path('/home/dw/Projects/agent-sts2/logs', entry['stream'] + '.jsonl').open('rb') as source:
            for line in path.open():
                item = json.loads(line)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                row = item['row']
                fp = row.get('fingerprint')
                if isinstance(fp, str):
                    fp = json.loads(fp)
                state = row.get('state') or {}
                ids = {v for v in [row.get('run_id'), row.get('run'), state.get('run_id'),
                                   (fp or {}).get('run')] if isinstance(v, str) and v and v != 'run_unknown'}
                assert ids == {item['run_id']} and item['run_id'] in RUNS
                if entry['stream'] == 'states':
                    assert state['run']['character_id'].lower() == 'silent'
                    assert state['run']['ascension'] == 10
                verified[entry['stream']] += 1
                rows.append(item)
        assert dict(Counter(x['run_id'] for x in rows)) == {k: v for k, v in entry['counts'].items() if v}
        streams[entry['stream']] = rows

states = {x['line']: x for x in streams['states']}
decisions = {x['line']: x for x in streams['decisions']}
checks = []

def check(name, actual, expected, refs):
    assert actual == expected, (name, actual, expected)
    checks.append({'check': name, 'actual': actual, 'expected': expected, 'references': refs})

def s(line):
    return states[line]['row']['state']

def player(line):
    return (s(line).get('combat') or {}).get('player') or {}

def hp(line):
    return player(line).get('current_hp', s(line)['run']['current_hp'])

def enemy(line, ident=None):
    values = s(line)['combat']['enemies']
    return next(e for e in values if ident is None or e['enemy_id'] == ident)

def power(holder, ident):
    values = [p['amount'] for p in holder['powers'] if p['power_id'] == ident]
    assert len(values) <= 1
    return values[0] if values else None

def attack(holder):
    return sum(i.get('total_damage') or 0 for i in holder['intents'])

def php(line, ident):
    return power(player(line), ident)

def ehp(line):
    return sum(e['current_hp'] for e in s(line)['combat']['enemies'])

check('污染逐技能与能力间隔', [php(i, 'TAINTED_POWER') for i in [274830, 274831, 274832, 274833]], [None, 3, 3, 6], [274830, 274831, 274832, 274833])
check('火花增长', [power(enemy(i), 'VITAL_SPARK_POWER') for i in [274830, 274834]], [3, 6], [274830, 274834])
check('火花6的技能增量', [php(i, 'TAINTED_POWER') for i in [274834, 274836, 274837, 274838]], [None, 6, 12, 18], [274834, 274836, 274837, 274838])
check('污染轮后未列出', php(274839, 'TAINTED_POWER'), None, [274839])
check('污染两轮净失血', [hp(274830)-hp(274834), hp(274834)-hp(274839)], [3, 9], [274830, 274834, 274839])
check('抢夺后负属性', [php(274351, 'STRENGTH_POWER'), php(274351, 'DEXTERITY_POWER')], [-4, -4], [274351])
check('两步法敏捷变化', [php(i, 'DEXTERITY_POWER') for i in [274351, 274352, 274354]], [-4, -2, None], [274351, 274352, 274354])
check('退场后力量未列出', php(274358, 'STRENGTH_POWER'), None, [274358])
check('剩遗忘且再夺敏捷', [[e['enemy_id'] for e in s(274358)['combat']['enemies']], php(274362, 'DEXTERITY_POWER')], [['THE_FORGOTTEN'], -2], [274358, 274362])
check('蚌无弱喷水', [attack(enemy(i)) for i in [273237, 273252, 273263]], [11, 15, 19], [273237, 273252, 273263])
check('蚌成长力量', [power(enemy(i), 'STRENGTH_POWER') for i in [273237, 273252, 273263]], [None, 4, 8], [273237, 273252, 273263])
check('蚌弱后喷水', [attack(enemy(i)) for i in [273254, 273268]], [11, 14], [273254, 273268])
check('蚌覆甲现场', [power(enemy(i), 'PLATING_POWER') for i in [273237, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273237, 273247, 273252, 273258, 273263])

pair_specs = [(270216, 270282, [3, 15], [10, 17]), (271309, 271348, [0, 9], [45, 38]),
              (271992, 272040, [9, 14], [24, 27]), (271982, 272195, [2, 10], [25, 34])]
pairs = []
for a, b, losses, damage in pair_specs:
    da, db = decisions[a]['row'], decisions[b]['row']
    check('同指纹配对' + str(a), da['fingerprint'], db['fingerprint'], [a, b])
    endpoints = []
    for line in [a, b]:
        d = decisions[line]['row']
        matches = [x for x in streams['states'] if x['row']['observed_ts'] == d['observed_ts'] and x['row']['fingerprint'] == d['fingerprint']]
        assert len(matches) == 1
        first = matches[0]
        following = [x for x in streams['states'] if x['run_id'] == first['run_id'] and x['line'] > first['line']
                     and x['row']['state']['run']['floor'] == d['floor'] and x['row']['state']['turn'] == d['turn'] + 1]
        end = min(following, key=lambda x: x['line'])
        endpoints.append({'decision_line': line, 'before': first['line'], 'after': end['line'],
                          'player_net_loss': hp(first['line'])-hp(end['line']),
                          'enemy_net_hp_decrease': ehp(first['line'])-ehp(end['line']),
                          'attempt': d.get('sl_attempt'), 'reloads': d.get('sl_reloads')})
    check('配对净失血' + str(a), [x['player_net_loss'] for x in endpoints], losses, endpoints)
    check('配对敌净扣血' + str(a), [x['enemy_net_hp_decrease'] for x in endpoints], damage, endpoints)
    pairs.append({'decisions': [a, b], 'endpoints': endpoints, 'limit': '同盘当轮净端点；不认证候选完整执行、毛伤或整战反事实'})

check('实验体换阶段前后', [enemy(277512)['current_hp'], enemy(277513)['current_hp'], enemy(277513)['max_hp']], [4, 212, 212], [277512, 277513])
check('实验体新阶段旧毒未列出', power(enemy(277513), 'POISON_POWER'), None, [277513])
check('触媒已建2且敌毒未列出', [php(277518, 'ACCELERANT_POWER'), power(enemy(277518), 'POISON_POWER')], [2, None], [277518])
check('尖啸当轮显示攻击', attack(enemy(277518)), 0, [277518])
check('末试船夹板轮初', player(278236)['block'], 14, [278236])
check('镣铐临时力量', [power(enemy(i, 'CRUSHER'), 'STRENGTH_POWER') for i in [278236, 278237, 278242]], [None, -9, None], [278236, 278237, 278242])
check('镣铐同招意图', [attack(enemy(i, 'CRUSHER')) for i in [278236, 278237]], [4, 0], [278236, 278237])
check('现场14加6挡', player(278240)['block'], 20, [278236, 278240])
check('双蟹第二轮净失血', hp(278236)-hp(278242), 0, [278236, 278242])
check('转向与弱分步意图', [attack(enemy(i, 'ROCKET')) for i in [278249, 278252, 278253]], [57, 38, 28], [278249, 278252, 278253])
check('沙虫终态净失血', hp(276433)-hp(276434), 5, [276433, 276434])
check('沙虫显示攻击减挡参考', attack(enemy(276433))-player(276433)['block'], 15, [276433])
check('沙虫末次未建触媒', php(276433, 'ACCELERANT_POWER'), None, [276433])
check('沙虫末毒净扣', enemy(276433)['current_hp']-enemy(276434)['current_hp'], 24, [276433, 276434])

zap = []
for x in streams['states']:
    st = x['row']['state']
    if x['run_id'] != '5PM6JAQG6FNQ' or st['run']['floor'] != 38 or st['turn'] not in [3, 4]:
        continue
    for e in (st.get('combat') or {}).get('enemies', []):
        if e['enemy_id'] == 'ZAPBOT' and e['current_hp'] > 0:
            zap.append({'line': x['line'], 'turn': st['turn'], 'max_hp': e['max_hp'],
                        'strength': power(e, 'STRENGTH_POWER'), 'voltage': power(e, 'HIGH_VOLTAGE_POWER'), 'attack': attack(e)})
check('电击现存实体观测T3', any(z['turn']==3 and z['max_hp']==23 and z['strength']==2 and z['voltage']==2 and z['attack']==17 for z in zap), True, zap)
check('电击现存实体观测T4', any(z['turn']==4 and z['max_hp']==23 and z['strength']==4 and z['voltage']==2 and z['attack']==19 for z in zap), True, zap)

prepared = []
for run in RUNS:
    dec = []
    excluded = []
    for item in streams['decisions']:
        row = item['row']
        if item['run_id'] != run or row.get('floor') not in FLOORS[run]:
            continue
        if not row.get('decision_id') or not row.get('observed_ts'):
            excluded.append({'line': item['line'], 'sha256': item['sha256'], 'reason': '无唯一动作标识或观测时间的元数据，不补号'})
            continue
        dec.append({k:v for k,v in row.items() if k != 'agent_view'} | {'_line': item['line'], '_source_sha256': item['sha256']})
    frames = [item['row'] | {'_line': item['line'], '_source_sha256': item['sha256']} for item in streams['states']
              if item['run_id'] == run and item['row']['state']['run']['floor'] in FLOORS[run]]
    path = 'audit-' + run + '.input.json'
    save(path, {'run': RUNS[run], 'decisions': dec, 'states': frames})
    prepared.append({'run': run, 'floors': sorted(FLOORS[run]), 'decisions': len(dec), 'states': len(frames),
                     'excluded': excluded, 'path': path, 'sha256': hashlib.sha256((OUT/path).read_bytes()).hexdigest()})

save('material-verification.json', {'verified_rows': dict(verified), 'assertions': checks, 'pair_endpoints': pairs,
                                    'audit_inputs': prepared, 'warning': '材料核验不是生产测试；缺字段不补零，净变化不作逐击因果'})
print(json.dumps({'verified_rows': dict(verified), 'assertions': len(checks), 'inputs': prepared}, ensure_ascii=False))

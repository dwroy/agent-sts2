# 本批策略学习报告

记录时间：2026-10-17T08:28:40+08:00。task=strategy-proposal；character=silent；batch=20261017-081302-strategy-proposal。

十个原提案全部waiting，已逐项保留具体缺口、反例和验证方法，见[proposal.md](proposal.md)。本批无源码/知识改动，无代码提交、live合入或新版本；fixes=[]，merged=null。未受阻于合入冲突，没有待合补丁。

## 身份与基线

初始git status干净；开工merge main后Already up to date；完整base及HEAD为ac451784ffebed27097bf261bbfaa5ee69c5d4d5。本批实际learn.json含十proposal_ids，reason=proposal，worktree和五runs精确匹配。它不满足纯研究的reason=ops/无proposal_ids条件；未冒用其他研究或实现任务，也未读取其他角色私有知识。

|局号|进阶|终层|原代码标记|结束UTC|
|---|---|---|---|---|
|NHA2KW0RB7VP|A10|F33|b8ca9311+dirty|2026-10-07T15:19:58.532Z|
|G33HU22H2543|A10|F48|710dc4dc+dirty|2026-10-07T16:20:52.860Z|
|P74C04AEPL1F|A10|F23|fd4c8e52+dirty|2026-10-07T16:43:50.303Z|
|RC61MFQM63Y6|A10|F33|0d6c1a82+dirty|2026-10-07T17:26:17.487Z|
|BTSRF7JL1W1Y|A10|F31|6ad5584f+dirty|2026-10-07T18:15:04.461Z|

上表来自原runs.jsonl；不根据历史deepseek_calls字段单独断言大脑来源或纯Codex战绩。本批仅核游戏证据，原引擎/费用数据不改。

## 冻结证据与核证边界

已使用共用extract_evidence.py单进程nice提取八流；身份由run/run_id/state.run_id/fingerprint.run确定，不用正文提及纳入。逐流固定source_size，选中全部6606行已逐行回读源字节并核SHA、身份、JSON内容和截点，详细raw-integrity.json及material-verification.stdout.json。
表内五列计数顺序为NHA2KW0RB7VP / P74C04AEPL1F / G33HU22H2543 / RC61MFQM63Y6 / BTSRF7JL1W1Y。

|日志流|冻结源字节数|五局各自行数|
|---|---:|---|
|states|13755250865|602 / 410 / 879 / 694 / 653|
|decisions|2130918368|584 / 395 / 850 / 674 / 635|
|sl-attempts|44623961|7 / 5 / 8 / 7 / 4|
|run-config|1916880|1 / 1 / 1 / 1 / 1|
|run-plans|8753512|5 / 3 / 6 / 7 / 5|
|brain|714638926|34 / 23 / 45 / 33 / 28|
|runs|354231|1 / 1 / 1 / 1 / 1|
|fight-plans|2233957|0 / 0 / 0 / 0 / 0|

states/decisions/brain源分别有2条无效JSON行，由共用入口排除；不能为无身份损坏行补认所属局。fight-plans在此截点对本批选中0行，只表示未选到，不证明旧日志缺失或从未执行计划。run-plans有26条，未采用正文搜索或把旧零行初稿当缺失证据。

原十Markdown已按队列SHA核真；32个原账本的本批前快照和物理行定位在ledger-before.json与ledger-physical-before.json。原样本/反例仍按进阶及原局身份保留，未把旧复盘再写一遍。旧机制材料只筛本批五局15/58/70行，非143个新独立样本，未重跑全历史统计。

## 关键结论

1. NHA F33首轮以开场后可操作30血比较，斗篷线14挡/损1/扣8，回响线8挡/损7/扣24；房间过渡28血、开场补2及敌各扣10分开。多16输出、多损6血是局部差额，不能推出整战替线胜率。
2. P74 F23末T3生存者后1血16挡，精确切击当前牌面5→7；弃后原后继取消，末卵毒后2血仍攻击，实际归零。首试卵此前已结束与第三次原线不同，不能做统一弃牌禁令；保留分支未实打，动态牌面与触发不补猜。
3. RC61 F33首末两条同首手/同药槽的实线分别16/12挡、损4/8、扣敌30/23。末次279197的当前Jev原答模型却是损21、替线8，目标和用药也不同；跨尝试实线差额不能当该次SL覆盖的成对因果效果。原始两种身份均保存，不据任一推出固定SL参数。
4. BTS F31抽弃前279852与之后279854是两个局面；最终实际选plan2，五轮4样本3胜1死。末轮14血、5牌挡、1覆甲对22攻击需损16，存活差3，甲虫毒后13仍攻击。未持逐样本轨迹与执行配对，单次实死不反证75%或支持改权重。
5. G33 F31为83→46赢、F33为76→17赢；P74 F22为53→9赢、下战9血。端点和实回补核证不代逐来源消费者账、未走路线/保药/休息受控后继，不能拟合通用HP价格或安全血线。

上述固定证据引用和复算保存在evidence-conclusions.json；完整状态事实及战斗/回合窗口分别为state-facts.json和combat-turn-windows.json。后者是离线原帧分段，退出null表示重试或截断，不冒称敌方末攻击实死；也不表示完整候选线已经派发。

## 当前源码及已有窄实现

只读live快照为08e9a15b79882302eb7bfe38e7ddddc2e40b2dbd。本树16个相关源码叶都与base一致，其中10个与该live逐字一致，另6个仅历史Roy/Dai署名文字差，原git diff --binary见source-live.diff.patch；work相对base的source-work.diff.patch为空。此对照不重建任何原局dirty树。

|窄范围|实际源码commit|对该live快照|
|---|---|---|
|投斧首牌身份|e784dd9f043bf87c29109573f48975f9903280d3|已核祖先|
|普通生存者单弃|bf423c173d3be348a4ad714e1d26516df619ff41|已核祖先|
|弃牌手牌快照|4b0823f519f1b724d6cff2b1cd50b74146dc4a9d|已核祖先|
|弃牌计划与条件预测|97efc0618936c6d7783fbf36e79b056b90d65589|已核祖先|
|SL当前轮资源比较|5604982e13890e0e2bc8bf8246272e8267321c0b|已核祖先|
|SL资源比较后续核证|1698adc96ba434a46942321e0237b70657e625b2|已核祖先|
|live保留依赖的实际集成|a8b1f8be153fe4f3a34146117546c2178f2e446b|已核祖先|

历史源5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56不是实际live祖先，不能用作实现凭据。首次对它的祖先断言失败保存在source-origin-ancestry.json；改查97efc061和实际集成a8b1f8be后核真。另一个只读fold调用曾误传容器，修正为(line,row)后成功；沙箱准备阶段曾遇并行路径消失，原命令重试成功。相关限制/失败记录material-errors.txt，不是生产代码失败，也不造补测成功。

discardPlanFacts只展示已选后继/条件预测；survivorDiscardFacts明确是移除当前副本后的保留手牌快照，后续费用/触发/伤害/剩血未知；普通生存者只在已观察A6/A10范围消费唯一后继；silentSlResourceComparison的scope=current_turn_prediction，execution=unverified。上述源码存在不能代完整分支、跨选择执行、整战校准或资源连续消费者验收，所以十个父提案均未整项duplicate。

## 逐项处置

|原提案ID|状态|具体剩余缺口|
|---|---|---|
|silent-proposal-9952ee8e8df9a0fe|waiting|已有SL当前轮资源差额实现；NHA同首手实线差额成立，但缺同抽序、同预算的整战对照及路线/留药受控后继，不能调整SL门槛或终局HP权重。|
|silent-proposal-47be799a87af03be|waiting|弃牌计划提示和保留手牌快照已有live实现；仍缺动态牌面、弃牌触发、目标和续步剩血的完整合法分支核证，不能把快照当分支求解。|
|silent-proposal-3a5274da3c42672a|waiting|局部机制已有模型；缺F22主怪最后死亡的中间来源帧及药水、复活、逐敌失衡到下战资源的联合核证，当前未定位新增可隔离差额。|
|silent-proposal-bc4b92d590f2c4ce|waiting|投斧首牌身份、普通单弃及计划提示已有live窄实现；跨重规划完整执行归属、余像累计收益和动态弃牌的联合证据仍缺，不能整项duplicate。|
|silent-proposal-f52fbbab4dccc3b4|waiting|缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的受控后继；赢战耗血与实际入口不能直接拟合新HP价格或留药阈值。|
|silent-proposal-10f37c0edd3d24a6|waiting|缺当时dirty源码、知识和移动表的完整输入及多组件联合回放、独立校准；逐来源局部观察成立，未发现可据此新增的确定源码修正。|
|silent-proposal-3f82387e2e179703|waiting|RC61同盘两条实打首轮的少7输出、多损4血已核；缺同预算整战、累计能力收益与受控后继，不能修改全败SL排序或固定HP惩罚。|
|silent-proposal-aee21084c991abd3|waiting|缺逐样本轨迹与最终执行线的配对校准；抽弃前后状态和目标改变，一条3/4样本候选发生死亡不足证明模型错误或调整权重。|
|silent-proposal-df37594e9b12debf|waiting|普通生存者唯一后继取消已有live祖先覆盖；跨选择整线归属、累计能力收益和呼唤自损的联合消费者仍未验收，不能用窄修复关闭整项。|
|silent-proposal-42e81c83b2e1e56b|waiting|缺同条件路线、休息及后战对照和逐来源消费者验收；实际52血入口与既有回复账不足建立新安全血线或终局HP价格。|

各项来源任务、局号/层/回合、完整账本ID、反例、预期行为、验证/回退和窄提交见proposal.md及dispositions.json。没有漏派发ID、领取新项或创建重复提案。

## 测试、合入与账本

本批无生产源码修改，撤源失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试、模拟池、LLM或网络。不借原固定测试文件的历史通过声称本批检查成功。无提交，因此提交前gitleaks不适用；未合入live，无新eval版本、上线/双通知/shipped或retention完成登记。
仅经根learner/ledger.py update追加32个原条目的proposal.md追溯，状态不写，不新增evidence/support/repeat，不改claim/首证/prior/status/version/shipped；CLI及前缀/保护字段核验另存ledger-cli.stdout.txt、ledger-cli.stderr.txt和ledger-append-verification.json。本批未宣称新经验发布或大脑已采用。

所有临时材料仅在本批scratch；日志只读，其他角色/未观察机制保持原字节。无待Roy审批的架构方案或新机制异议。本批已完成有界审查；十项等待缺失的本角色新证据，不由本模型继续开局或另派任务。

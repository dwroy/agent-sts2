import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys

sys.dont_write_bytecode = True
SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
RUNS = set(json.loads((SCRATCH / 'dispatch.json').read_text())['runs'])
spec = importlib.util.spec_from_file_location('extractor', WORKTREE / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(items):
    return {p.get('power_id'): p.get('amount') for p in items or []}


def reference(env):
    return {k: env[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
integrity = []
states = []
decisions = []
plans = []
configs = []
for stream in manifest:
    path = SCRATCH / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    counts = Counter()
    output_digest = hashlib.sha256()
    with Path('/home/dw/Projects/agent-sts2/logs', stream['stream'] + '.jsonl').open('rb') as source:
        for encoded in path.open('rb'):
            output_digest.update(encoded)
            env = json.loads(encoded)
            assert env['run_id'] in RUNS
            assert extractor.run_identity(env['row']) == env['run_id']
            assert env['offset'] + env['bytes'] <= stream['source_size']
            source.seek(env['offset'])
            raw = source.read(env['bytes'])
            assert len(raw) == env['bytes'] and raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == env['sha256']
            assert json.loads(raw) == env['row']
            counts[env['run_id']] += 1
            if stream['stream'] == 'states':
                state = env['row']['state']
                run = state.get('run') or {}
                assert str(run.get('character_id')).lower() == 'silent'
                combat = state.get('combat') or {}
                player = combat.get('player') or {}
                facts = {
                    **reference(env), 'ts': env['row'].get('ts'), 'floor': run.get('floor'),
                    'turn': state.get('turn'), 'screen': state.get('screen'),
                    'in_combat': state.get('in_combat'), 'hp': run.get('current_hp'),
                    'max_hp': run.get('max_hp'), 'block': player.get('block'),
                    'energy': player.get('energy'), 'powers': powers(player.get('powers')),
                    'potions': run.get('potions'), 'rest': state.get('rest'),
                    'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost', 'resolved_rules_text')}
                             for c in combat.get('hand', [])],
                    'enemies': [{**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'block', 'is_alive', 'move_id')},
                                 'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                                for e in combat.get('enemies', [])],
                    'selection': state.get('selection'),
                }
                states.append(facts)
            elif stream['stream'] == 'decisions':
                row = env['row']
                if ((env['run_id'] == 'P74C04AEPL1F' and row.get('floor') == 23)
                        or (env['run_id'] == 'RC61MFQM63Y6' and row.get('floor') == 33)
                        or (env['run_id'] == 'G33HU22H2543' and row.get('floor') == 48 and row.get('turn') == 1)
                        or (env['run_id'] == 'BTSRF7JL1W1Y' and row.get('floor') == 31)):
                    decisions.append({**reference(env), **row})
            elif stream['stream'] == 'run-plans':
                plans.append({**reference(env), 'row': env['row']})
            elif stream['stream'] == 'run-config':
                configs.append({**reference(env), 'row': env['row']})
    assert output_digest.hexdigest() == stream['output_sha256']
    assert all(counts[run] == stream['counts'][run] for run in RUNS)
    integrity.append({'stream': stream['stream'], 'verified_raw_rows': sum(counts.values()),
                      'counts': dict(counts), 'source_size': stream['source_size'],
                      'output_sha256': output_digest.hexdigest()})

save('state-facts.json', states)
save('selected-decisions.json', decisions)
save('run-plans-selected.json', plans)
save('run-config-selected.json', configs)
save('raw-integrity.json', integrity)

windows = []
for run in sorted(RUNS):
    seq = 0
    active = None
    previous = None
    for frame in [s for s in states if s['run_id'] == run]:
        if frame['in_combat']:
            if (active is None or frame['floor'] != active['floor']
                    or (previous and isinstance(frame['turn'], int) and isinstance(previous['turn'], int)
                        and frame['turn'] < previous['turn'])):
                if active:
                    windows.append(active)
                seq += 1
                active = {'run_id': run, 'sequence': seq, 'floor': frame['floor'],
                          'entry': frame, 'turns': {}, 'exit': None}
            turn = str(frame['turn'])
            if turn not in active['turns']:
                active['turns'][turn] = {'first': frame, 'last': frame}
            active['turns'][turn]['last'] = frame
            previous = frame
        elif active:
            active['exit'] = frame
            windows.append(active)
            active = None
            previous = None
    if active:
        windows.append(active)
save('combat-turn-windows.json', windows)
summary = []
for w in windows:
    if w['floor'] in ({'NHA2KW0RB7VP': [33], 'P74C04AEPL1F': [17, 22, 23],
                      'G33HU22H2543': [31, 33, 48], 'RC61MFQM63Y6': [17, 33],
                      'BTSRF7JL1W1Y': [31]}[w['run_id']]):
        def small(f):
            if not f:
                return None
            return {k: f[k] for k in ('line', 'floor', 'turn', 'screen', 'hp', 'block', 'powers', 'enemies')}
        summary.append({'run_id': w['run_id'], 'sequence': w['sequence'], 'floor': w['floor'],
                        'entry': small(w['entry']), 'exit': small(w['exit']),
                        'turns': {k: {p: small(f) for p, f in v.items()} for k, v in w['turns'].items()}})
save('critical-windows.json', summary)
print(json.dumps({'streams': integrity, 'states': len(states), 'selected_decisions': len(decisions),
                  'combat_segments': len(windows), 'critical_segments': len(summary)}, ensure_ascii=False))

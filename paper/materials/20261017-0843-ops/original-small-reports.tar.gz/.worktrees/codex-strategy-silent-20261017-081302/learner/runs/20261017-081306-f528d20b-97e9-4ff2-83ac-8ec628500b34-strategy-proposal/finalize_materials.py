import hashlib
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
load = lambda name: json.loads((S / name).read_text())
save = lambda name, obj: (S / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
queue = load('queue-selected.json')['items']
dispositions = load('dispositions.json')
dispatch = load('dispatch.json')
source = load('source-readback.json')
states = {f['line']: f for f in load('state-facts.json')}
rows = {f['line']: f for f in load('selected-decisions.json')}
assert [d['id'] for d in dispositions] == dispatch['proposal_ids']
assert set(queue) == {d['id'] for d in dispositions}
assert all(d['state'] == 'waiting' for d in dispositions)


def enemy(line, ident):
    return next(e for e in states[line]['enemies'] if e['enemy_id'] == ident)


def hp_sum(line):
    return sum(e['current_hp'] for e in states[line]['enemies'])


def ref(line):
    return {k: states[line][k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


facts = []
def fact(name, lines, value):
    facts.append({'项目': name, '原帧': [ref(n) for n in lines], '复核结果': value})

assert states[285315]['hand'] == states[285491]['hand']
assert states[285315]['hp'] == states[285491]['hp'] == 52
assert states[285315]['potions'] == states[285491]['potions']
rc = {'首试损血': 52 - states[285321]['hp'], '末试损血': 52 - states[285497]['hp'],
      '首试扣敌': hp_sum(285315) - hp_sum(285321), '末试扣敌': hp_sum(285491) - hp_sum(285497),
      '首试挡': states[285320]['block'], '末试挡': states[285496]['block']}
assert rc == {'首试损血': 4, '末试损血': 8, '首试扣敌': 30, '末试扣敌': 23, '首试挡': 16, '末试挡': 12}
fact('RC61同首手同药槽的两次已执行首轮，不是当前SL原答与替线的一对', [285315, 285320, 285321, 285491, 285496, 285497], rc)
assert rows[279197]['sl_explore']['numbers']['original'].endswith('this turn hp -21, dmg 30')
assert rows[279197]['sl_explore']['numbers']['replacement'].endswith('this turn hp -8, dmg 23')
facts.append({'项目': '末次SL原答与替线另列', '决策原帧': {k: rows[279197][k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')},
              '复核结果': rows[279197]['sl_explore'], '限制': '两个数字是该题模型预测；不能改称实盘损21→8或把首末实线4→8当该覆盖的因果代价。'})
nha = {'可操作首手血': states[283391]['hp'], '前线挡': states[283396]['block'],
       '后线挡': states[283506]['block'], '前线损血': states[283396]['hp'] - states[283397]['hp'],
       '后线损血': states[283506]['hp'] - states[283507]['hp'],
       '前线扣敌': hp_sum(283391) - hp_sum(283397), '后线扣敌': hp_sum(283502) - hp_sum(283507)}
assert nha == {'可操作首手血': 30, '前线挡': 14, '后线挡': 8, '前线损血': 1, '后线损血': 7, '前线扣敌': 8, '后线扣敌': 24}
fact('NHA首轮必须从开场效果之后比较', [283390, 283391, 283396, 283397, 283502, 283506, 283507], nha)
assert states[284817]['hp'] == 1 and states[284817]['block'] == 16
assert states[284821]['hp'] == 0 and enemy(284821, 'BOWLBUG_EGG')['current_hp'] == 2
assert next(c for c in states[284816]['hand'] if c['card_id'] == 'PRECISE_CUT')['resolved_rules_text'].startswith('造成5点伤害')
assert next(c for c in states[284817]['hand'] if c['card_id'] == 'PRECISE_CUT')['resolved_rules_text'].startswith('造成7点伤害')
assert not any(c['card_id'] == 'PRECISE_CUT' for c in states[284818]['hand'])
fact('P74动态牌面及末次弃牌后的实死', list(range(284816, 284822)),
     {'选择前血': 1, '选择前挡': 16, '精确切击牌面': [5, 7], '弃后精确切击': False, '末血': 0, '卵末血': 2,
      '限制': '无保留该牌并完成整战的实打分支；7是当前牌面，不是替代整线固定伤害。'})
assert states[286173]['hp'] == 14 and states[286173]['block'] == 5
assert states[286173]['powers']['PLATING_POWER'] == 1
assert enemy(286173, 'SLUMBERING_BEETLE')['intents'][0]['total_damage'] == 22
assert enemy(286174, 'SLUMBERING_BEETLE')['current_hp'] == 13 and states[286174]['hp'] == 0
candidate = json.loads(rows[279854]['questions']['plan']['criteria']['plan2'])
assert '3/4' in candidate['rollout'] and '1/4' in candidate['rollout']
fact('BTS实际末轮死亡与非零死亡概率分列', [286170, 286173, 286174],
     {'血': 14, '牌挡': 5, '覆甲': 1, '攻击': 22, '完整需损': 22-5-1, '存活差': (22-5-1)+1-14,
      '抽弃后实际选线': rows[279854]['journal'], '该线推演': candidate['rollout'], '限制': '缺逐样本轨迹；单局死亡不能反证75%或拟合新权重。'})
for start, end, expected in [(283916, 283958, (83,46)), (283967,284007,(76,17)), (284730,284761,(53,9))]:
    assert (states[start]['hp'],states[end]['hp']) == expected
    fact('获胜战的真实血量端点', [start,end], {'进场血':expected[0], '出场血':expected[1], '限制':'端点核证不等于逐来源消费者账或路线/保药因果对照。'})
assert states[284766]['hp'] == 9
fact('P74下战实际入口', [284761,284766], {'前战出血':9,'后战入血':9})
save('evidence-conclusions.json', facts)

at = (S / 'recorded-at.txt').read_text().strip()
base = source['base']
header = f'''# 静默猎手策略提案逐项处置

记录时间：{at}（写入前已运行date）。本批：20261017-081302-strategy-proposal；角色：silent。
基线：{base}；HEAD未变，普通批次开工已执行git merge --no-edit main，结果Already up to date。

仅消费派发的十个原ID。没有research_request或implementation_request；普通专题请求的batch不匹配，未读取其冻结任务或借用其他专题。原提案SHA全部相符，原Markdown字节保存在original-proposals/。
结论：十项全部waiting。本批无新增游戏规则、源码、知识变更、代码提交或live合入；不把已有局部实现登记为整项完成，不创建重复ID。

证据范围为五个已核实Silent A10原局。原局均带dirty代码标记；完整运行时源码、知识及移动输入没有冻结齐，当前树不能冒作原dirty输入。SL重打和同局多个窗口都不增加独立局分母。
本次不重新全量统计、拟合参数或运行模拟；只复核原提案、原账本、当前源码及固定原帧，候选与实盘分账。八流6606行的source_size/offset/bytes/SHA见evidence/evidence-manifest.json与raw-integrity.json。

'''
sections = []
for i,d in enumerate(dispositions,1):
    q=queue[d['id']]
    sections.append(f'''## {i}. {d['id']}

原提案：{q['summary']}。原文：{q['proposal']}；SHA256：{q['proposal_sha256']}。
证据局：{','.join(q['runs'])}；账本：{','.join(q['ledger'])}；原声明领域：{','.join(q['domains'])}。

本批核证：{d['evidence']}

当前处置：waiting。{d['reason']}

反例及限制：{d['counterexample']}

预期行为：{d['expected']}

后续验证：{d['validation']}

已核实际live祖先的窄源码：{','.join(d['partial_commits']) if d['partial_commits'] else '本项未据单一窄提交声明覆盖'}。这些均非本批新提交，覆盖范围不能扩到完整父提案。
''')
tail='''
## 验证与回退

固定原始材料复核结果在evidence-conclusions.json；这是证据和算术核证，不是生产测试、消费者运行或胜率验证。
本批未改生产源码，无可撤源码，因此撤源失败/恢复通过、tsc、vitest、cases均不适用，机器字段全部null。没有提交，未执行提交前gitleaks或live合入测试，也没有借用历史测试成功。
保持原行为，不需要生产回退。后续若实现，应按原提案固定夹具先撤源失败再恢复通过，运行原沙箱入口，再锁内核知识冲突、真实合入并通知运维核号。现有经验shipped或窄源码祖先都不能代替本批提案完整验收。
学习账本只经根目录learner/ledger.py update追加本批追溯链接；不新增support/repeat、不改变claim/首证/prior/evidence/status/version/shipped，不降级旧shipped条目，不将等待标成上线。无新的机制反证或规则异议；当前SL原答与跨尝试比较的身份边界明确保留，不重写旧原件或把样本差额归成因果收益。
'''
(S/'proposal.md').write_text(header+'\n'.join(sections)+tail)

manifest=load('evidence/evidence-manifest.json')
counts='\n'.join(f"|{m['stream']}|{m['source_size']}|"+' / '.join(str(m['counts'][r]) for r in dispatch['runs'])+'|' for m in manifest)
run_table='\n'.join(f"|{r}|A{q['ascension']}|F{q['floor']}|{q['code']}|{q['ended']}|" for r,q in load('run-identities.json').items())
summary='\n'.join(f"|{d['id']}|waiting|{d['reason']}|" for d in dispositions)
ancestors=load('live-ancestor-checks.json')
source_table='\n'.join(f"|{c['scope']}|{c['commit']}|已核祖先|" for c in ancestors['checks'])
report=f'''# 本批策略学习报告

记录时间：{at}。task=strategy-proposal；character=silent；batch=20261017-081302-strategy-proposal。

十个原提案全部waiting，已逐项保留具体缺口、反例和验证方法，见[proposal.md](proposal.md)。本批无源码/知识改动，无代码提交、live合入或新版本；fixes=[]，merged=null。未受阻于合入冲突，没有待合补丁。

## 身份与基线

初始git status干净；开工merge main后Already up to date；完整base及HEAD为{base}。本批实际learn.json含十proposal_ids，reason=proposal，worktree和五runs精确匹配。它不满足纯研究的reason=ops/无proposal_ids条件；未冒用其他研究或实现任务，也未读取其他角色私有知识。

|局号|进阶|终层|原代码标记|结束UTC|
|---|---|---|---|---|
{run_table}

上表来自原runs.jsonl；不根据历史deepseek_calls字段单独断言大脑来源或纯Codex战绩。本批仅核游戏证据，原引擎/费用数据不改。

## 冻结证据与核证边界

已使用共用extract_evidence.py单进程nice提取八流；身份由run/run_id/state.run_id/fingerprint.run确定，不用正文提及纳入。逐流固定source_size，选中全部6606行已逐行回读源字节并核SHA、身份、JSON内容和截点，详细raw-integrity.json及material-verification.stdout.json。
表内五列计数顺序为NHA2KW0RB7VP / P74C04AEPL1F / G33HU22H2543 / RC61MFQM63Y6 / BTSRF7JL1W1Y。

|日志流|冻结源字节数|五局各自行数|
|---|---:|---|
{counts}

states/decisions/brain源分别有2条无效JSON行，由共用入口排除；不能为无身份损坏行补认所属局。fight-plans在此截点对本批选中0行，只表示未选到，不证明旧日志缺失或从未执行计划。run-plans有26条，未采用正文搜索或把旧零行初稿当缺失证据。

原十Markdown已按队列SHA核真；32个原账本的本批前快照和物理行定位在ledger-before.json与ledger-physical-before.json。原样本/反例仍按进阶及原局身份保留，未把旧复盘再写一遍。旧机制材料只筛本批五局15/58/70行，非143个新独立样本，未重跑全历史统计。

## 关键结论

1. NHA F33首轮以开场后可操作30血比较，斗篷线14挡/损1/扣8，回响线8挡/损7/扣24；房间过渡28血、开场补2及敌各扣10分开。多16输出、多损6血是局部差额，不能推出整战替线胜率。
2. P74 F23末T3生存者后1血16挡，精确切击当前牌面5→7；弃后原后继取消，末卵毒后2血仍攻击，实际归零。首试卵此前已结束与第三次原线不同，不能做统一弃牌禁令；保留分支未实打，动态牌面与触发不补猜。
3. RC61 F33首末两条同首手/同药槽的实线分别16/12挡、损4/8、扣敌30/23。末次279197的当前Jev原答模型却是损21、替线8，目标和用药也不同；跨尝试实线差额不能当该次SL覆盖的成对因果效果。原始两种身份均保存，不据任一推出固定SL参数。
4. BTS F31抽弃前279852与之后279854是两个局面；最终实际选plan2，五轮4样本3胜1死。末轮14血、5牌挡、1覆甲对22攻击需损16，存活差3，甲虫毒后13仍攻击。未持逐样本轨迹与执行配对，单次实死不反证75%或支持改权重。
5. G33 F31为83→46赢、F33为76→17赢；P74 F22为53→9赢、下战9血。端点和实回补核证不代逐来源消费者账、未走路线/保药/休息受控后继，不能拟合通用HP价格或安全血线。

上述固定证据引用和复算保存在evidence-conclusions.json；完整状态事实及战斗/回合窗口分别为state-facts.json和combat-turn-windows.json。后者是离线原帧分段，退出null表示重试或截断，不冒称敌方末攻击实死；也不表示完整候选线已经派发。

## 当前源码及已有窄实现

只读live快照为{source['live_snapshot']}。本树16个相关源码叶都与base一致，其中10个与该live逐字一致，另6个仅历史Roy/Dai署名文字差，原git diff --binary见source-live.diff.patch；work相对base的source-work.diff.patch为空。此对照不重建任何原局dirty树。

|窄范围|实际源码commit|对该live快照|
|---|---|---|
{source_table}

历史源5d7f9e6a21c1485b8c34c11c4dafd220f98c3c56不是实际live祖先，不能用作实现凭据。首次对它的祖先断言失败保存在source-origin-ancestry.json；改查97efc061和实际集成a8b1f8be后核真。另一个只读fold调用曾误传容器，修正为(line,row)后成功；沙箱准备阶段曾遇并行路径消失，原命令重试成功。相关限制/失败记录material-errors.txt，不是生产代码失败，也不造补测成功。

discardPlanFacts只展示已选后继/条件预测；survivorDiscardFacts明确是移除当前副本后的保留手牌快照，后续费用/触发/伤害/剩血未知；普通生存者只在已观察A6/A10范围消费唯一后继；silentSlResourceComparison的scope=current_turn_prediction，execution=unverified。上述源码存在不能代完整分支、跨选择执行、整战校准或资源连续消费者验收，所以十个父提案均未整项duplicate。

## 逐项处置

|原提案ID|状态|具体剩余缺口|
|---|---|---|
{summary}

各项来源任务、局号/层/回合、完整账本ID、反例、预期行为、验证/回退和窄提交见proposal.md及dispositions.json。没有漏派发ID、领取新项或创建重复提案。

## 测试、合入与账本

本批无生产源码修改，撤源失败/恢复通过不适用；tsc/vitest/cases均null，未运行生产测试、模拟池、LLM或网络。不借原固定测试文件的历史通过声称本批检查成功。无提交，因此提交前gitleaks不适用；未合入live，无新eval版本、上线/双通知/shipped或retention完成登记。
仅经根learner/ledger.py update追加32个原条目的proposal.md追溯，状态不写，不新增evidence/support/repeat，不改claim/首证/prior/status/version/shipped；CLI及前缀/保护字段核验另存ledger-cli.stdout.txt、ledger-cli.stderr.txt和ledger-append-verification.json。本批未宣称新经验发布或大脑已采用。

所有临时材料仅在本批scratch；日志只读，其他角色/未观察机制保持原字节。无待Roy审批的架构方案或新机制异议。本批已完成有界审查；十项等待缺失的本角色新证据，不由本模型继续开局或另派任务。
'''
(S/'report-draft.md').write_text(report)
result={'task':'strategy-proposal','character':'silent','batch':'20261017-081302-strategy-proposal','base':base,
        'runs':dispatch['runs'],'fixes':[],'skipped':[],
        'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':dispatch['proposal_ids'],
        'implementation_domains':[],'proposal_results':[{k:d[k] for k in ('id','state','reason')} for d in dispositions],
        'report':str(S/'report.md')}
save('report.json',result)
print(json.dumps({'proposal':str(S/'proposal.md'),'draft':str(S/'report-draft.md'),'proposal_count':len(dispositions),'material_conclusions':len(facts)},ensure_ascii=False))

import hashlib
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/dw/Projects/agent-sts2')
S = Path(__file__).resolve().parent
queue = json.loads((S / 'queue-selected.json').read_text())['items']
ids = sorted({i for p in queue.values() for i in p['ledger']})
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)


def selected(data):
    rows = []
    for number, raw in enumerate(data.splitlines(), 1):
        try:
            row = json.loads(raw)
        except ValueError:
            continue
        if row.get('id') in ids:
            rows.append((number, row))
    result = ledger.fold(rows)
    assert set(result) == set(ids) and all(v['character'] == 'silent' for v in result.values())
    return result


def read_ledger():
    with ledger_path.open('rb') as handle:
        fcntl.flock(handle, fcntl.LOCK_SH)
        return handle.read()


before = read_ledger()
fold_before = selected(before)
(S / 'ledger-immediate-before.json').write_text(json.dumps(fold_before, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in ids:
    proposals = [k for k,p in queue.items() if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(S / 'proposal.md')]},
                    'note': '本批20261017-081302-strategy-proposal追溯：' + ','.join(proposals)
                            + '均waiting；本批6606原日志封套与固定窗口/源码范围核证见' + str(S / 'report.md')
                            + '；未改源码/知识，无提交/合入/版本，生产测试null；只加where/note，'
                            + '不新增support/repeat，不改claim/首证/prior/evidence/status/version/shipped。'
                            + (' RC61首末实线损4/8与末次覆盖原答预测21/替线8分属不同配对，保留归属边界，不作因果推断。'
                               if ident == 'silent-0079' else '')})
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates)
(S / 'ledger-update-input.jsonl').write_text(payload)
# Read the clock immediately before the authorized CLI append.
clock = subprocess.check_output(['date', '-Iseconds']).decode().strip()
result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'], input=payload,
                        text=True, capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
(S / 'ledger-cli.stdout.txt').write_text(result.stdout)
(S / 'ledger-cli.stderr.txt').write_text(result.stderr)
if result.returncode:
    (S / 'ledger-cli-failure.json').write_text(json.dumps({'at': clock, 'exit_code': result.returncode}, indent=2) + '\n')
    raise SystemExit(result.returncode)
after = read_ledger()
assert after[:len(before)] == before
fold_after = selected(after)
protected = ['claim', 'first_run', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect', 'asc']
for ident in ids:
    old, new = fold_before[ident], fold_after[ident]
    assert all(old.get(k) == new.get(k) for k in protected)
    assert new['history'][:len(old['history'])] == old['history']
    assert new['notes'][:len(old['notes'])] == old['notes']
    assert str(S / 'proposal.md') in new['where']['proposal']
    for key, values in old['where'].items():
        assert new['where'][key][:len(values)] == values
own_rows = []
offset = len(before)
for raw in after[len(before):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and '20261017-081302-strategy-proposal' in row.get('note', ''):
        assert set(row) <= {'op', 'id', 'ts', 'by', 'where', 'note'}
        own_rows.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(own_rows) == len(ids) and {row['row']['id'] for row in own_rows} == set(ids)
proof = {'at': clock, 'cli_exit_code': result.returncode, 'ids': ids, 'appended_own_rows': own_rows,
         'prefix_bytes': len(before), 'prefix_sha256': hashlib.sha256(before).hexdigest(),
         'prefix_preserved': True, 'protected_fields_preserved': protected, 'where_notes_history_prefixes_preserved': True}
(S / 'ledger-append-verification.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
(S / 'ledger-after.json').write_text(json.dumps(fold_after, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'cli_exit_code': 0, 'linked_original_entries': len(ids), 'prefix_preserved': True,
                  'protected_fields_preserved': True}, ensure_ascii=False))

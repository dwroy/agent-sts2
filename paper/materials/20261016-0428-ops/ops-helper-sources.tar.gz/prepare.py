from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0428';pub=root/'paper/materials/20261016-0428-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-041302-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();scratch=load(s/'result.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(report['code_proposals'])==set(b['proposal_ids'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'completion-validation.json');assert final['base']==report['base'] and all(final[k] for k in ['dispatch_identity_unchanged','worktree_clean','head_unchanged','tracked_diff_empty'])
assert final['original_proposal_hashes_valid']==10 and final['production_source_hashes_unchanged']==16 and final['ledger_trace_updates']==24 and final['production_tests'] is None
assert (s/'source.diff.patch').read_bytes()==b''
originals=load(s/'assigned-proposals.json');assert len(originals)==10 and {x['id'] for x in originals}==set(report['code_proposals'])
for x in originals:
    original=Path(x['proposal']);copy=s/(x['id']+'.original.md');assert original.is_relative_to(root)
    assert sha(copy.read_bytes())==x['proposal_sha256']
    if original.exists():assert sha(original.read_bytes())==x['proposal_sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');runs={x['run_id']:x for x in load(s/'runs-verified.json')}
assert set(report['runs'])==set(runs) and len(runs)==5 and all(x['character']=='SILENT' for x in runs.values())
assert collections.Counter(x['ascension'] for x in runs.values())=={5:1,10:4}
receipts=load(s/'offline-audit-results.json');assert len(receipts)==4 and all(x['exit_code']==0 for x in receipts)
needed={stream:set() for stream in ['states','decisions']}
for x in receipts:
    data=load(s/(x['name']+'.input.json'))
    for stream in needed:needed[stream].update(row['_line'] for row in data[stream])
counts={};input_rows={stream:{} for stream in needed};manifest=load(s/'evidence/evidence-manifest.json');verification=load(s/'evidence-verification.json')
for x in manifest:
    frozen=s/'evidence'/(x['stream']+'.evidence.jsonl');digest=hashlib.sha256();seen=collections.Counter()
    with frozen.open('rb') as selected,(root/'logs'/(x['stream']+'.jsonl')).open('rb') as original:
        for line in selected:
            digest.update(line);e=json.loads(line);original.seek(e['offset']);raw=original.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=x['source_size'] and extract.run_identity(row)==e['run_id'] in runs
            if x['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==runs[e['run_id']]['ascension']
            if x['stream']=='runs':assert row==runs[e['run_id']]
            if x['stream'] in needed and e['line'] in needed[x['stream']]:input_rows[x['stream']][e['line']]=dict(run=e['run_id'],row=row,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert digest.hexdigest()==x['output_sha256'] and dict(seen)=={k:v for k,v in x['counts'].items() if v};counts[x['stream']]=sum(seen.values())
assert sum(counts.values())==6060
for x in verification:assert counts[x['stream']]==x['lines'] and x['sha256']==next(y['output_sha256'] for y in manifest if y['stream']==x['stream']) and x['byte_identity_checks_passed']
facts=load(s/'material-checks.json');assert len(facts['checks'])==facts['passed']==13 and all(x['passed'] for x in facts['checks'])
consumer=load(s/'consumer-readback.json');assert consumer['checks_passed']==4
assert next(x for x in consumer['output'] if x['line']==289533)['hand_trick_facts'][0]['remaining_manual_plays_upper_bound']==2
assert next(x for x in consumer['output'] if x['line']==289536)['observed_demon_poison']==6
tracker=load(s/'dampen-current-tracker.json');assert [x['clean'] for x in tracker['records']]==[19,18,19,18]
assert all(x['inserted'][0]['cards']==['OUTBREAK','SUCKER_PUNCH'] and x['inserted'][0]['turn']==3 for x in tracker['records'])
brain=load(s/'brain-summary.json');assert sum(x['count'] for x in brain)==183 and all((x['engine'],x['model'],x['effort'])==('codex','gpt-6.1-sol','high') for x in brain)
source=load(s/'source-live-audit.json');assert source['base']==report['base'] and len(source['paths'])==16 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==source['observed_live_head']
for x in source['paths']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['observed_live_head']+':'+x['path']);c=git('show',x['actual_live_source_commit']+':'+x['path'])
    assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and x['live_bytes_match_commit'] and (root/'.worktrees/live'/x['path']).read_bytes()==z==c
    assert (a==z)==x['equal'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai') and x['live_ancestor'];git('merge-base','--is-ancestor',x['actual_live_source_commit'],source['observed_live_head'])
assert sum(x['equal'] for x in source['paths'])==12
totals=collections.Counter();summaries=[]
for x in receipts:
    input_path=s/(x['name']+'.input.json');output_path=s/(x['name']+'.output.json');stderr=s/(x['name']+'.stderr.txt')
    assert sha(input_path.read_bytes())==x['input_sha256'] and sha(output_path.read_bytes())==x['output_sha256'] and sha(stderr.read_bytes())==x['stderr_sha256']
    data=load(input_path);audit=load(output_path);assert data['run']==runs[x['run_id']]
    for stream in needed:
        for row in data[stream]:
            reference=input_rows[stream][row['_line']];assert reference['run']==x['run_id'] and row['_source_sha256']==reference['sha256']
            assert row=={**reference['row'],'_line':row['_line'],'_source_sha256':reference['sha256']}
    status=collections.Counter(row['status'] for row in audit['observed_turns']);assert all(row['actual_full_candidate_result'] is None for row in audit['segments'])
    actions=audit['observed_actions'];c=dict(segments=len(audit['segments']),actions=len(actions),intervals=sum((r.get('observed_interval') or {}).get('status')=='observed_endpoints' for r in actions),terminal_intervals=sum((r.get('terminal_observation') or {}).get('status')=='observed_terminal_endpoints' for r in actions),turns=len(audit['observed_turns']),observed_turns=status['observed_turn_endpoints'],unknown_turns=status['unknown'])
    assert all(c[k]==x[k] for k in c);totals.update(c);summaries.append(dict(run=x['run_id'],**c))
assert totals==dict(segments=198,actions=597,intervals=406,terminal_intervals=1,turns=112,observed_turns=34,unknown_turns=78)
art=load(s/'artifact-manifest.json')
for entry in art:
    f=s/entry['path'];raw=f.read_bytes();assert f.is_relative_to(s) and len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
receipt=load(s/'ledger-cli-validation.json');prefix=load(s/'ledger-prefix.json');rows=receipt['receipts'];inputs=[json.loads(line) for line in (s/'ledger-cli-input.jsonl').read_text().splitlines()]
assert receipt['cli_exit_code']==0 and len(rows)==len(inputs)==receipt['updates']==24 and receipt['physical_prefix_preserved'] and receipt['all_non_trace_fields_preserved']
assert set((s/'ledger-cli.stdout.txt').read_text().split())=={x['id'] for x in inputs} and (s/'ledger-cli.stderr.txt').read_bytes()==b''
own=[];owned_receipts=[]
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(prefix['bytes']))==prefix['sha256']
    for entry in rows:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row['id']==entry['id'] and row['ts']==entry['ts'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal'
        matched=[v for v in inputs if (v['id'],v['note'])==(row['id'],row['note'])];assert len(matched)==1 and all(row.get(k)==v for k,v in matched[0].items());own.append(raw);owned_receipts.append(dict(**entry,row=row))
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==24 and not set(raw.rstrip(b'\n') for raw in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,original_final_validation=final,original_proposals=originals,stream_counts=counts,original_rows_verified=6060,ascension_cohorts={5:1,10:4},material_assertions=13,existing_pure_fact_checks=4,source=source,original_consumers=receipts,consumer_counts=dict(totals),consumer_summaries=summaries,owned_trace_rows=owned_receipts,protected_fields_and_prefixes_preserved=True,original_artifact_manifest_verified=len(art),no_checks_reexecuted=True,limits=['ZE A5 is descriptive only; four A10 runs and SL attempts remain distinct. Historical183 brain calls high are not relabelled xhigh.','Bounded four windows,34 observed/78 unknown turns and no certified complete candidates do not close broad strategy proposals or original118/119/120-run studies.','Historical/current tracker insertion differences retained; both clean prefixes19/18/19/18, missing stable-copy/ordering evidence remains unknown. No historical dirty source reconstruction or known-prefix extension.','Original local note-only index assertion failure and corrected id+note validation retained; no duplicate ledger CLI, product failure or new gameplay counterevidence.','No source, merge, release, production tests, paper refresh, new dispatch or game action; wide parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0428原041302-s2策略done0/no-source核收，5b86基线干净WT/HEAD不变，十waiting逐项缺口/testsnull/mergednull保持，无合入受阻。五Silent四A10/ZE一A5分列，八流6060原行逐offset/bytes/SHA/JSON/显式身份核；历史183脑请求Sol6.1/high原样保留，当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核。13原材料断言/4既有纯事实读回与四有界离线input/output/stderr及原帧绑定核，198题段/597动作/406相邻端点/1终态端点/112轮窗（34可核78未知），完整候选全null，不当自然消费者或完整策略收益。净回血72边界source=null保持；GXN当前与历史追踪clean均19/18/19/18但插入时点/两键与四键差保留，不复原dirty源码、推断根因或延长已知前缀，仍缺稳定副本/纯改标/同窗先后。16相关源码叶12同4历史Roy/Dai注释差及真实live祖先/blob核，窄功能不关闭宽组合。24所属CLI只where/note，原物理前缀/offset/SHA和私有fold核，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持；本地首跑note非唯一键错配断言与改id+note后绿原件留存，不重复CLI、不当产品故障或游戏反证。仅本人记录/24追溯提交，保并行记录；无源码/合入/发号/补测/论文刷新/复派/重启对局或账号home模型额度权限prompt变更，不关闭宽父。证据paper/materials/20261016-0428-ops/。\n'
note=f'\n- {at} [运维 codex] 原041302-s2十项继续waiting，无源码修改或合入阻塞；6060原行、13原材料检查、4既有纯事实读回、四有界离线回执及24条所属追溯已核。材料首跑索引失败与更正原件保留，缺失后继与宽父保持。回执paper/materials/20261016-0428-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=24,old_fields_preserved=True,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=6060,owned_trace_rows=24,ledger_check=0,paths=len(entries))))

"""Read frozen own-character evidence; never infer action causality from endpoints."""
import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
runs = {r["run_id"]: r for r in json.loads((OUT / "runs-verified.json").read_text())}
rows = {}
verification = []
for manifest in json.loads((OUT / "evidence/evidence-manifest.json").read_text()):
    stream = manifest["stream"]
    path = OUT / "evidence" / (stream + ".evidence.jsonl")
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == manifest["output_sha256"]
    selected = [json.loads(line) for line in data.splitlines()]
    counts = Counter()
    with Path(selected[0]["source"]).open("rb") if selected else (ROOT / "README.md").open("rb") as source:
        for e in selected:
            assert e["offset"] + e["bytes"] <= manifest["source_size"]
            source.seek(e["offset"])
            raw = source.read(e["bytes"])
            assert raw.endswith(b"\n") and hashlib.sha256(raw).hexdigest() == e["sha256"]
            assert json.loads(raw) == e["row"]
            assert extract.run_identity(e["row"]) == e["run_id"] and e["run_id"] in runs
            if stream == "states":
                info = e["row"]["state"]["run"]
                assert info["character_id"].lower() == "silent"
                assert info["ascension"] == runs[e["run_id"]]["ascension"]
            counts[e["run_id"]] += 1
    assert all(counts[r] == n for r, n in manifest["counts"].items())
    verification.append({"stream": stream, "lines": len(selected), "counts": dict(counts),
                         "source_size": manifest["source_size"], "sha256": manifest["output_sha256"],
                         "byte_identity_checks_passed": True})
    rows[stream] = selected
(OUT / "evidence-verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2) + "\n")

states = {e["line"]: e for e in rows["states"]}
decisions = {e["line"]: e for e in rows["decisions"]}

def powers(items):
    return {p["power_id"]: p["amount"] for p in items or []}

def frame(line):
    s = states[line]["row"]["state"]
    c = s.get("combat") or {}
    p = c.get("player") or {}
    return {"source_line": line, "run_id": s["run_id"], "floor": s["run"]["floor"],
            "turn": s.get("turn"), "screen": s["screen"], "hp": p.get("current_hp", s["run"]["current_hp"]),
            "block": p.get("block"), "energy": p.get("energy"), "powers": powers(p.get("powers")),
            "played": p.get("cards_played_this_turn"), "potions": s["run"].get("potions"),
            "hand": [{k: card.get(k) for k in ("card_id", "upgraded", "playable", "unplayable_preventer_id")}
                     for card in c.get("hand", [])],
            "enemies": [{"id": e["enemy_id"], "hp": e["current_hp"], "max_hp": e["max_hp"],
                         "alive": e["is_alive"], "powers": powers(e.get("powers")),
                         "intents": e.get("intents")} for e in c.get("enemies", [])]}

checks = []
def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})
    assert condition, name

check("五局角色核实且只有ZE为A5", all(r["character"].lower() == "silent" for r in runs.values())
      and runs["ZE8F192FKX24"]["ascension"] == 5 and all(r["ascension"] == 10 for k, r in runs.items() if k != "ZE8F192FKX24"))
for line in (289339, 289414):
    f = frame(line)
    check(f"KFR同盘T6原行{line}", (f["hp"], f["enemies"][0]["hp"], f["enemies"][0]["powers"]["POISON_POWER"],
                               f["powers"]["PLATING_POWER"]) == (15, 228, 36, 3))
check("KFR末毒药施毒6且当步不扣敌HP", frame(289537)["enemies"][0]["powers"]["POISON_POWER"] - frame(289536)["enemies"][0]["powers"]["POISON_POWER"] == 6
      and frame(289536)["enemies"][0]["hp"] == frame(289537)["enemies"][0]["hp"] == 159)
check("KFR末轮实扣85后敌仍74", frame(289537)["enemies"][0]["hp"] - frame(289538)["enemies"][0]["hp"] == 85
      and frame(289538)["enemies"][0]["hp"] == 74 and frame(289538)["hp"] == 0)
check("KFR三手动后奇巧爆发锁住", frame(289537)["played"] == 3 and frame(289537)["energy"] == 1
      and any(c["card_id"] == "BURST" and c["unplayable_preventer_id"] == "SLOTH_POWER" for c in frame(289537)["hand"]))
check("GXN末T2与T3血挡", (frame(290201)["hp"], frame(290206)["hp"], frame(290206)["block"]) == (2, 13, 7))
f = frame(290212)
attack = sum(i.get("total_damage") or 0 for e in f["enemies"] for i in e["intents"])
check("GXN13血23挡2覆甲对40算术差2并非已测毛伤", attack == 40 and f["hp"] == 13 and f["block"] == 23
      and f["powers"]["PLATING_POWER"] == 2 and f["hp"] - (attack-f["block"]-f["powers"]["PLATING_POWER"]) == -2)
check("GXN抑制出现", "DAMPEN_POWER" not in frame(290201)["powers"] and frame(290206)["powers"]["DAMPEN_POWER"] == 1)
check("ZE A5已有抑制", frame(223268)["powers"]["DAMPEN_POWER"] == frame(223272)["powers"]["DAMPEN_POWER"] == 1)
check("MTQ末T3到T4净损8", frame(288899)["hp"] - frame(288905)["hp"] == 8)
check("MTQ跨幕19到59", states[288726]["row"]["state"]["run"]["current_hp"] == 19 and states[288727]["row"]["state"]["run"]["current_hp"] == 59)
check("7X跨幕28到61", states[288236]["row"]["state"]["run"]["current_hp"] == 28 and states[288237]["row"]["state"]["run"]["current_hp"] == 61)

keylines = [223268, 223272, 288236, 288237, 288404, 288470, 288472, 288726, 288727, 288899, 288905,
            289231, 289232, 289237, 289339, 289345, 289414, 289420, 289533, 289536, 289537, 289538,
            290160, 290165, 290201, 290206, 290212, 290213, 290214]
(OUT / "frame-facts.json").write_text(json.dumps([frame(line) for line in keylines if line in states], ensure_ascii=False, indent=2) + "\n")
keydecisions = [282138, 282434, 282578, 282579, 282864, 282929, 282933, 283035, 283641, 283680, 283690, 283691]
facts = []
for line in keydecisions:
    e = decisions[line]
    r = e["row"]
    facts.append({"line": line, "offset": e["offset"], "sha256": e["sha256"],
                  **{k: r.get(k) for k in ("run_id", "decision_id", "floor", "turn", "sl_attempt", "label", "answers", "chosen", "result", "journal", "hp_guard", "sl_explore", "rollout_best_chosen")},
                  "criteria": ((r.get("questions") or {}).get("plan") or {}).get("criteria")})
(OUT / "decision-facts.json").write_text(json.dumps(facts, ensure_ascii=False, indent=2) + "\n")

recoveries = []
previous = {}
for e in rows["states"]:
    s = e["row"]["state"]; r = s["run"]; run = e["run_id"]; old = previous.get(run)
    if old and r["current_hp"] > old["row"]["state"]["run"]["current_hp"]:
        a = old["row"]["state"]; ar = a["run"]
        recoveries.append({"run_id": run, "before_line": old["line"], "after_line": e["line"],
                           "before_floor": ar["floor"], "floor": r["floor"], "before_screen": a["screen"], "screen": s["screen"],
                           "before_turn": a.get("turn"), "turn": s.get("turn"), "before_hp": ar["current_hp"], "hp": r["current_hp"],
                           "net_increase": r["current_hp"]-ar["current_hp"], "source": None})
    previous[run] = e
(OUT / "observed-recovery-boundaries.json").write_text(json.dumps(recoveries, ensure_ascii=False, indent=2)+"\n")

windows = {"7X0W3U8TVA2A": [31], "MTQ0EUBJ3R6T": [11, 23], "KFRDELW2TH2P": [12, 28, 33], "GXNKW8X1XYJP": [33, 45]}
inputs = []
excluded = []
for run, floors in windows.items():
    ds = [e for e in rows["decisions"] if e["run_id"] == run and e["row"].get("floor") in floors]
    ss = [dict(e["row"], _line=e["line"], _source_sha256=e["sha256"]) for e in rows["states"]
          if e["run_id"] == run and e["row"]["state"]["run"]["floor"] in floors]
    chunks = [[]]
    for e in ds:
        if not e["row"].get("decision_id"):
            excluded.append({"run_id": run, "line": e["line"], "sha256": e["sha256"], "reason": "原decision_id缺失，不补号、不跨缺口连接"})
            if chunks[-1]: chunks.append([])
        else:
            chunks[-1].append(dict(e["row"], _line=e["line"], _source_sha256=e["sha256"]))
    for i, chunk in enumerate(chunks):
        if not chunk: continue
        name = f"audit-{run}-{i+1}"
        path = OUT / (name + ".input.json")
        path.write_text(json.dumps({"run": runs[run], "decisions": chunk, "states": ss}, ensure_ascii=False)+"\n")
        inputs.append({"name": name, "run_id": run, "floors": floors, "decisions": len(chunk), "states": len(ss),
                       "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
(OUT / "audit-input-manifest.json").write_text(json.dumps({"inputs": inputs, "excluded_metadata": excluded}, ensure_ascii=False, indent=2)+"\n")
(OUT / "material-checks.json").write_text(json.dumps({"checks": checks, "passed": len(checks), "meaning": "原证材料断言；不是生产tsc/vitest或收益验收"}, ensure_ascii=False, indent=2)+"\n")
print(json.dumps({"verified_rows": sum(v["lines"] for v in verification), "material_checks": len(checks), "inputs": inputs,
                  "metadata_exclusions": excluded}, ensure_ascii=False))

"""Verify trace-only ledger appends and preserve the unchanged production tree."""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

ROOT = Path("/home/dw/Projects/agent-sts2")
OUT = Path(__file__).resolve().parent
BATCH = "20261016-041302-s2-strategy-proposal"
spec = importlib.util.spec_from_file_location("ledger", ROOT / "learner/ledger.py")
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
raw = (ROOT / "paper/materials/learning/ledger.jsonl").read_bytes()
prefix = json.loads((OUT / "ledger-prefix.json").read_text())
assert hashlib.sha256(raw[:prefix["bytes"]]).hexdigest() == prefix["sha256"]
inputs = [json.loads(line) for line in (OUT / "ledger-cli-input.jsonl").read_text().splitlines()]
# Several items share a proposal and therefore the same note. The item id remains part of the identity.
expected = {(row["id"], row["note"]): row for row in inputs}
receipts = []
offset = prefix["bytes"]
for line in raw[offset:].splitlines(keepends=True):
    row = json.loads(line)
    inp = expected.get((row.get("id"), row.get("note")))
    if inp:
        assert all(row.get(k) == value for k, value in inp.items())
        receipts.append({"id": row["id"], "offset": offset, "bytes": len(line),
                         "sha256": hashlib.sha256(line).hexdigest(), "ts": row.get("ts")})
    offset += len(line)
assert sorted(row["id"] for row in receipts) == sorted(row["id"] for row in inputs)
before = json.loads((OUT / "ledger-before-cli.json").read_text())
after = ledger.fold(ledger.read_rows(str(ROOT / "paper/materials/learning/ledger.jsonl")))
for ident, old in before.items():
    new = after[ident]
    omitted = {"history", "notes", "where"}
    assert {k: v for k, v in old.items() if k not in omitted} == {k: v for k, v in new.items() if k not in omitted}
    assert new["history"][:len(old["history"])] == old["history"]
    assert new["notes"][:len(old["notes"])] == old["notes"]
    assert all(new["where"][key][:len(values)] == values for key, values in old["where"].items())
ledger_result = {"cli_exit_code": 0, "updates": len(receipts), "physical_prefix_preserved": True,
                 "protected_items": sorted(before), "all_non_trace_fields_preserved": True, "receipts": receipts}
(OUT / "ledger-cli-validation.json").write_text(json.dumps(ledger_result, ensure_ascii=False, indent=2) + "\n")

def locate(value):
    if isinstance(value, dict):
        if BATCH in value:
            return value[BATCH]
        if value.get("batch") == BATCH or value.get("id") == BATCH:
            return value
        for child in value.values():
            found = locate(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = locate(child)
            if found:
                return found

props = json.loads((OUT / "assigned-proposals.json").read_text())
dispatch = json.loads((OUT / "dispatch.json").read_text())
current = locate(json.loads((ROOT / "ops/codex-ops/learn.json").read_text()))
for field in ("task", "character", "worktree", "proposal_ids", "runs"):
    assert current[field] == dispatch[field], field
assert not current.get("research_request") and not current.get("implementation_request")
for prop in props:
    assert hashlib.sha256((OUT / (prop["id"] + ".original.md")).read_bytes()).hexdigest() == prop["proposal_sha256"]
base = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert base == "5b86d4856c057827a5642639ed69dd2143ce0fef"
assert not subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], text=True).strip()
assert not subprocess.check_output(["git", "diff", "--binary", base])
for row in json.loads((OUT / "source-live-audit.json").read_text())["paths"]:
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["base_sha256"]
assert all(row["exit_code"] == 0 for row in json.loads((OUT / "offline-audit-results.json").read_text()))
assert json.loads((OUT / "material-checks.json").read_text())["passed"] == 13
assert not (OUT / "consumer-readback.stderr.txt").stat().st_size
assert not (OUT / "consumer-readback-with-tracker.stderr.txt").stat().st_size
result = {"task": "strategy-proposal", "character": "silent", "batch": BATCH, "base": base,
          "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": [row["id"] for row in props], "implementation_domains": [],
          "proposal_results": json.loads((OUT / "proposal-results.json").read_text()), "report": str(OUT / "report.md")}
assert [row["id"] for row in result["proposal_results"]] == dispatch["proposal_ids"]
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
validation = {"base": base, "dispatch_identity_unchanged": True, "worktree_clean": True,
              "head_unchanged": True, "tracked_diff_empty": True, "original_proposal_hashes_valid": 10,
              "production_source_hashes_unchanged": 16, "ledger_trace_updates": len(receipts),
              "production_tests": None, "proposal_results": len(result["proposal_results"])}
(OUT / "completion-validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(validation, ensure_ascii=False))

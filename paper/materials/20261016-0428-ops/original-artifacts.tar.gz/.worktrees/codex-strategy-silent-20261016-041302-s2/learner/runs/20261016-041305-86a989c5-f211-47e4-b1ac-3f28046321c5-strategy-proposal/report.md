# 静默猎手本批策略复核报告

基线：`5b86d4856c057827a5642639ed69dd2143ce0fef`；批次：`20261016-041302-s2-strategy-proposal`。

## 结论与任务身份

本批10个指定提案均为waiting，各项缺口在proposal.md和proposal-results.json中逐项保存。没有新增源码、参数或知识规则；fixes=[]、merged=null；没有实现提交、合入提交、发布版本或shipped登记。现有窄实现已核实际live祖先，但不覆盖原宽提案的全部要求。

learn.json对应行的task、character、五局集合和worktree已核；存在proposal_ids，未带research_request、implementation_request或proposal_repair。仅核普通任务要求的notes/strategy-research-silent.json：其绑定其他批次，本批不承接该专题，不读取其他专题代替身份。原10份提案Markdown均与队列保存的SHA一致。dispatch.json及assigned-proposals.json保存本批副本。

开工git status为空；按普通任务执行git merge --no-edit main，返回Already up to date，HEAD保持上述40位基线。没有子agent、网络、play、LLM调用或游戏二进制读取。历史运行均带dirty，完整运行树不能由当前源码复原。

## 原始证据与范围

共用extract_evidence.py提取8流，随后逐行seek原日志核offset、bytes、LF、SHA、JSON和显式所属身份；共6060行通过。runs.jsonl核实五局均SILENT：四局A10，ZE8F192FKX24为A5且只用于已观察抑制现象，不混入A10策略/阈值分母。没有重算原提案118/119/120局历史统计，也不把原报告分母当本批新验收。

|日志流|本批条数|source_size字节截点|
|---|---:|---:|
|states|2965|13306264012|
|decisions|2846|1773340892|
|sl-attempts|26|42174928|
|run-config|5|1812708|
|run-plans|30|8329675|
|brain|183|630484484|
|runs|5|341549|
|fight-plans|0|2233957|

各流逐局计数见evidence/evidence-manifest.json，逐行证据在*.evidence.jsonl，复核在evidence-verification.json。fight-plans为该冻结截点按显式身份未选到，不能据此声称历史原日志不存在；本批run-plans实际选到30行（含run身份）。提取初期states文件尚为0字节只属运行中，不作为缺证结论。

183条原brain记录均engine=codex、model=gpt-6.1-sol、effort=high，按五局分列在brain-summary.json；兼容ds_*计数不当成DeepSeek实际调用。它们是历史运行设置，不是本次学习者原生请求的独立核验；本批未读取原生凭据或改运行配置。

## 有界离线消费者读回

使用基线现有learner/audit-selection.ts，只读冻结单局输入；4次均退出0，无知识库、模拟器重跑或LLM。输入保留原行号、原SHA及agent_view，窗口固定如下；本批窗口没有无decision_id元数据行，不补号、不跨过滤缺口认证连续性。

|局号/层|输入动作|输入状态|题目段|可核动作端点|终态端点|轮窗（可核/未知）|
|---|---:|---:|---:|---:|---:|---:|
|7X0W3U8TVA2A / 31|71|72|32|0|0|0/13|
|MTQ0EUBJ3R6T / 11,23|152|158|33|115|1|16/13|
|KFRDELW2TH2P / 12,28,33|256|277|100|187|0|12/39|
|GXNKW8X1XYJP / 33,45|118|126|33|104|0|6/13|

合计198题段、597动作、406个相邻观测端点、1个单列终态端点、112轮窗（34可核、78未知）；完整候选认证为0。未知不等于未执行或没有收益；7X的0端点来自工具的严格尝试/连接条件，原帧仍在。窗口有限，不声称全局、全部候选、整战受控校准或自然采用。所有输入/输出/stderr及SHA留在audit-*.input/output.json、offline-audit-results.json。

consumer-readback.mjs另外对原始KFR选牌与毒药帧调用既有纯事实函数：原行289533读回剩2个手动名额上界、后继未验证；289536读回6毒；GXN含头骨组合和ZE A5没有被窄恶魔入口接管。4个材料读回断言通过。这是已存在源码的固定输入有限消费，不是新规则验收或新自然消费者。

13个原证材料断言首跑通过，见material-checks.json（非tsc/vitest）；原始净回血72个边界独立落盘且source=null，不把净增量分配给具体回血源。GXN-F33-mechanism-facts.json另保留触媒实际建立、毒结算和既有挡未追补：T5敌214→130实扣84；T6至T7敌107→10净扣97含其他轮初输出，不把97全归毒。

## 关键核实与限制

- KFR F33首/第3试T6同15血、敌228、36毒、覆甲3。原行289339→289345为玩家15→9、敌228→145；289414→289420为玩家15→3、敌228→135。多10输出伴随多6损血，两线均失败；旧稿35毒不再沿用。F12原护栏完整0损候选在斗篷生小刀后重问，不能将旧预测与新实线拼成误差或保血收益。

- KFR末T7三手动已满、爆发余1能仍由SLOTH_POWER锁住；7+5牌挡确实生效。毒药37→43当步敌159不变，后实扣85至74仍败；不能由此规定先喝或固定改奇巧目标。

- GXN第2/末试T2同2血和同五手牌，T3分别3血0挡/13血7挡，敌连枷64/72。末T3为13血23挡2覆甲对显示40，算术完整需15、差2；该算式不冒充逐击毛伤，实际两线均失败。精灵自动耗槽、主动毒药请求和SL恢复分别保留。

- GXN历史sl-attempts1053—1056为T2四个普通键inserted、旧+键离堆，clean19/18/19/18。基线当前追踪器用原帧与明确五个开关重读四试，仍clean19/18/19/18，但在T3仅记录OUTBREAK/SUCKER_PUNCH两个留堆普通键为新增；另两张已入手牌的结果分开。dampen-current-tracker.json保留该差别，不覆写历史、不假称复原dirty代码或已证明变化原因。缺纯改标瞬时帧、稳定物理副本ID和并发动作先后，不能安全延长抽序前缀。ZE A5是战内文本机制证据，不是A10跟踪器已正确或同bug重现的证据。

## 每项处置

原始10项均列出原ledger id、局号/层/回合、支持、反例、旧/新行为、范围、验证和回退。详细内容以proposal.md为准：

|提案ID|账本|处置与待补数据|
|---|---|---|
|silent-proposal-19a5cff2094e2d8f|silent-0021, silent-0064, silent-0079, silent-0133, silent-0125|waiting：缺敌段生命周期至真实终局的联合校准，以及冻结输入下原线/替线整战比较；本批没有可证明更安全的胜线。|
|silent-proposal-3540bf4360bf80af|silent-0019, silent-0020, silent-0243|waiting：缺逐源恢复和逐槽事件到路线/休息完整消费者的固定对照；替路线/锻造完整结果未记录。|
|silent-proposal-0ea5c0b9c030fdd6|silent-0274, silent-0247, silent-0027, silent-0016|waiting：名额提示和限定毒药入口已经存在；缺奇巧完整合法后继、收益兑现以及换顺序/提前喝药的整战对照，原宽提案不能整体登记duplicate。|
|silent-proposal-f915ec544ab94b6e|silent-0079, silent-0125|waiting：现有候选/回执/离线关联仅覆盖追溯子项；缺重问后完整候选归属与同输入整战校准，不能据局部差改SL排序或保血阈值。|
|silent-proposal-8fb51933639faf90|silent-0005, silent-0006, silent-0027, silent-0189, silent-0276, silent-0277, silent-0278|waiting：限定恶魔毒药已有；其余药效/能力尚缺联合多轮消费者校准，覆甲完整减层条件未隔离；没有提前饮用整场胜线。|
|silent-proposal-b3bc0eb09211af6c|silent-0021, silent-0079, silent-0102, silent-0247, silent-0274|waiting：缺合法后继到实际终结全链、换目标/顺序或提前饮毒的完整比较；名额上界和预测血价不是原提案整体完成。|
|silent-proposal-fdc3a505fe5e1a55|silent-0019, silent-0020, silent-0243|waiting：已有净回血边界记录仍未隔离逐源归属；缺完整路线/休息消费者固定对照和替路线/锻造完整结果。|
|silent-proposal-5a95725089f53cd8|silent-0019, silent-0079, silent-0005, silent-0016, silent-0087, silent-0027, silent-0030|waiting：现有药槽端点及请求追溯已覆盖子项；缺逐击复活瞬时帧、未截断入伤、完整候选到逐源资源消耗归属和替路线整战比较。|
|silent-proposal-51fa8bc34774f72d|silent-0279, silent-0280|waiting：缺仅改标瞬时帧、稳定副本身份及同窗口改标/抽牌/真实插入的可核顺序；不能因基ID总数守恒安全延长已知前缀。当前有限重读不是历史dirty源码复原。|
|silent-proposal-29b7b36dffbcb017|silent-0005, silent-0006, silent-0011, silent-0016, silent-0021, silent-0027, silent-0030, silent-0087, silent-0278|waiting：既有毒雾/触媒/力敏等局部模型不能代替头骨、阻毒、多次结算及覆甲的联合消费者校准；缺提前喝药/先打能力同输入整战对照。|

没有为既有条目再创建重复代码提案；最终code_proposals沿用本批10个真实CLI id。没有新增实现领域，implementation_domains=[]。

## 已有源码与实际live祖先

只读观察live HEAD为`e716bd28fd8eca9e4d76d066680304fd11935e37`。以下提交均核为该实际live祖先，并核对应工作文件与提交blob一致；不将main祖先当live部署，也不将以下子项当原宽提案整体implemented：

|已覆盖子项|实际live源码提交|
|---|---|
|奇巧名额提示、限定恶魔毒药6|8bb53d6342b7e9a2adf96de231b53c36eaa943de|
|护栏候选、SL预测资源差|a8b1f8be153fe4f3a34146117546c2178f2e446b|
|当前候选审计|05cd292c6f01bb31e406473d3a9843e659d62b93|
|单动作派发回执|bade647f9fe4c9103b40e2f26b26296692ad24b7|
|HP恢复边界历史|52d7f343f5f183670dc9d0c0d847bf6a15420aae|
|离线候选/药槽观测|cf72bd21148059f111f760cc98a727369e34a47e|
|离线终态端点|04921bd785ac6838066522f91ea0bb6ab95cb6a1|
|离线整轮端点|9b87d54f097d84521152e6cca8d6072af8140394|

source-live-audit.json逐叶记录16条SHA、祖先与blob核对：12叶字节同、4叶仅历史Roy/Dai注释差，原diff在source-live-differences.patch。没有为一致性而改注释。source.diff.patch为空；这也不复原五局各自dirty知识或全运行源码。

## 验证、提交与上线口径

本批没有源码修改；撤源码失败/恢复通过不适用，未执行。tsc、vitest、cases均为null，未运行生产套件、未请求宿主补测、未制造测试成功。有限材料断言和既有工具退出0单列，不能替代代码提交要求的原沙箱测试。

未创建git提交，故没有新增Co-Authored-By或提交前gitleaks扫描结果；没有合入live、知识刷新提交、决策日志上线行、eval版本或Roy双规则上线通知。只读live核对未持合入锁，因为本批没有要合入的变更。

原任务要求的账本追加只使用根目录learner/ledger.py update，by=learner:strategy-proposal，仅补本批提案/报告追溯和waiting限制，不改变旧claim、first_run、prior、evidence、status或version，不重复复盘，不标shipped；真实CLI与保护结果将在下方验收记录。

全部材料限本工作树的指定learner/runs目录；其他角色、未观察进阶以及既有在线行为保持原样。根专用账本追加属于任务明确例外。自动调度器保留waiting待后续新局重派，本批报告不关闭宽父或学习入库要求。


## 最终验收记录

根账本CLI实际退出0，24项只追加where/note。逐行offset/bytes/SHA及输入核验通过；追加前物理字节前缀SHA保持；24项所有非追溯字段、旧history/notes及where前缀保持，未改旧状态或新增shipped。实际回执见ledger-cli-validation.json及原stdout/stderr。

首次本地保护核验误用note作为唯一键：多个账本项共用同组提案而备注相同，索引覆盖造成错配断言失败。completion-first-failure.txt保留首跑失败；改为id+note复核后通过，没有重跑或重复追加CLI，也不是产品故障或游戏反证。

最终派发身份及10项集合未变，10份原Markdown SHA、16个生产源码叶SHA保持；HEAD仍5b86d4856c057827a5642639ed69dd2143ce0fef，工作树干净、tracked diff为空。见completion-validation.json；最终JSON在result.json。未运行生产tsc/vitest，未合入或发版。

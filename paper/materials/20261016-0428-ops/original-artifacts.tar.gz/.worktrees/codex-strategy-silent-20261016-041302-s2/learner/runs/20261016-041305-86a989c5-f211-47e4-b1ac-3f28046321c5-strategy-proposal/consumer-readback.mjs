import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

const scratch = process.argv[2];
const load = (path) => import(pathToFileURL(resolve(path)).href);
const { parseGameState } = await load("agent/src/hand/mod/schema.ts");
const { handTrickSlothFacts } = await load("agent/src/hand/screens/silent-hand-trick-facts.ts");
const { observedDemonPoison } = await load("agent/src/reflex/silent-demon-potion.ts");
const { DrawTracker } = await load("agent/src/sl/draws.ts");
const frames = JSON.parse(readFileSync(resolve(scratch, "consumer-input.json"), "utf8"));
const output = frames.map(({ line, state }) => {
  const parsed = parseGameState(state);
  const facts = handTrickSlothFacts(parsed, true);
  return { line, run_id: state.run_id, floor: state.run.floor, turn: state.turn,
    observed_demon_poison: observedDemonPoison(parsed),
    hand_trick_facts: facts ? [...facts].map(([index, value]) => ({ index, ...value })) : null };
});
const selection = output.find((row) => row.line === 289533);
if (!selection.hand_trick_facts?.length || selection.hand_trick_facts.some((row) =>
  row.remaining_manual_plays_upper_bound !== 2 || row.continuation_verified !== false)) {
  throw new Error("原奇巧选牌帧未保留2名额上界和后继未知");
}
const poison = output.find((row) => row.line === 289536);
if (poison.observed_demon_poison !== 6) throw new Error("原无加量恶魔毒药窗口未读回6");
if (output.find((row) => row.line === 290212).observed_demon_poison !== null ||
    output.find((row) => row.line === 223268).observed_demon_poison !== null) {
  throw new Error("本批其他已观察组合不应被当成窄恶魔入口");
}
writeFileSync(resolve(scratch, "consumer-readback.json"), JSON.stringify({
  scope: "固定原帧对现有纯事实入口的有限读回；不是自然消费者、完整策略或收益验收",
  checks_passed: 4, output,
}, null, 2) + "\n");

const input = JSON.parse(readFileSync(resolve(scratch, "audit-GXNKW8X1XYJP-1.input.json"), "utf8"));
const records = [];
let tracker = null;
let previousTurn = null;
for (const row of input.states) {
  const state = parseGameState(row.state);
  if (state.run?.floor !== 45 || state.turn === null || !["COMBAT", "CARD_SELECTION"].includes(state.screen)) continue;
  if (tracker === null || previousTurn !== null && state.turn < previousTurn) {
    tracker = new DrawTracker({ inserts: true, tops: true, picks: true, offTop: true, handOrder: true });
    records.push(tracker.record);
  }
  tracker.observe(state);
  previousTurn = state.turn;
}
writeFileSync(resolve(scratch, "dampen-current-tracker.json"), JSON.stringify({
  scope: "当前追踪器在GXN/F45原帧的有限离线重读；不延长抽序、不改原日志",
  options: { inserts: true, tops: true, picks: true, offTop: true, handOrder: true },
  records,
}, null, 2) + "\n");

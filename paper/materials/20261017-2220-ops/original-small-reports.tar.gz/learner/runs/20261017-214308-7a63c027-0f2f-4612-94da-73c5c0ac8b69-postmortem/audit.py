import json,collections,re
from pathlib import Path
p=Path(__file__).parent
D=list(map(json.loads,(p/'decisions.jsonl').open())); S=list(map(json.loads,(p/'states.jsonl').open())); R=json.load((p/'U5W7NUE925NK-resources.json').open()); SL=list(map(json.loads,(p/'sl-attempts.jsonl').open()))
def pw(a):return [(x.get('power_id'),x.get('amount')) for x in a or []]
def brief(x):
 s=x['state']; c=s.get('combat')or{};pl=c.get('player')or{}
 return dict(line=x['_line'],ts=x['ts'],turn=s['turn'],hp=s['run']['current_hp'],player={k:v for k,v in pl.items() if k in ['block','energy','powers','cards_played_this_turn','attacks_played_this_turn']},enemies=[{k:e.get(k) for k in ['index','enemy_id','name','current_hp','max_hp','block','powers','intents','move_id']} for e in c.get('enemies',[])])
with (p/'turn-audit.txt').open('w') as h:
 for w in R['combats']:
  h.write('\nWINDOW '+str(w['sequence'])+' F'+str(w['floor'])+'\n')
  ss=[x for x in S if w['entry']['line']<=x['_line']<=(w.get('exit')or w['last'])['line']]
  for t,items in __import__('itertools').groupby(ss,key=lambda x:x['state']['turn']):
   items=list(items);h.write('START '+json.dumps(brief(items[0]),ensure_ascii=False)+'\nEND '+json.dumps(brief(items[-1]),ensure_ascii=False)+'\n')
   ds=[x for x in D if items[0]['ts']<=x['ts']<=items[-1]['ts']]
   for x in ds:h.write('D '+str(x['_line'])+' '+x['label']+' '+x['decider']+' '+str(x.get('chosen'))+' '+x['rationale']+'\n')
print('STATS',collections.Counter(x['decider'] for x in D))
print('LOW',sum(x['decider']=='jev' and x.get('confidence')is not None and x['confidence']<.35 for x in D))
plans=[x for x in D if x['decider']=='jev' and x['label'].startswith('combat/plan-choice')]
ranks=collections.Counter(int(m.group(1)) for x in plans if (m:=re.search(r'code rank (\d+)',x['rationale'])))
print('PLAN',len(plans),'ranks',ranks,'potion',sum('to drink' in x['rationale'] for x in plans))
for x in D:
 if re.search(r'guard|护栏|replac|focus|保血',x['rationale'],re.I): print('SPECIAL',x['_line'],'F',x['floor'],'T',x['turn'],x['rationale'][:1100])
for x in S[-4:]:print('FINAL',json.dumps(brief(x),ensure_ascii=False))
print('PLAYER FIELDS',list((S[-2]['state'].get('combat')or{}).keys()))
for name in ['ledger-guard','ledger-shuriken','ledger-wail']:
 data=json.load((p/f'{name}.json').open());print(name)
 for x in data:print(x['id'],x['status'],x.get('version'),x['claim'][:550])

import json, subprocess
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261017-214308-7a63c027-0f2f-4612-94da-73c5c0ac8b69-postmortem'
run='U5W7NUE925NK'
for name in ('decisions','run-plans','states','sl-attempts','runs'):
    count=0
    proc=subprocess.Popen(['rg','-n','-b','-F',run,str(root/'logs'/f'{name}.jsonl')],stdout=subprocess.PIPE)
    with (out/f'{name}.jsonl').open('w') as dest:
        for raw in proc.stdout:
            num,offset,body=raw.split(b':',2)
            try: row=json.loads(body)
            except ValueError: continue
            row['_line']=int(num); row['_offset']=int(offset)
            dest.write(json.dumps(row,ensure_ascii=False)+'\n'); count+=1
    proc.wait()
    print(name,count,flush=True)
rows=[json.loads(x) for x in (out/'decisions.jsonl').open()]
lo=min(x['ts'] for x in rows); hi=max(x['ts'] for x in rows)
count=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as src,(out/'deepseek-window.jsonl').open('w') as dest:
    for n,raw in enumerate(src,1):
        try: row=json.loads(raw)
        except ValueError: continue
        ts=row.get('ts','')
        if lo<=ts<=hi:
            row['_line']=n;dest.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
print('window',lo,hi,'deepseek',count,flush=True)
print('decision schema',list(rows[0]),flush=True)
for x in (rows[0],rows[-1]): print(json.dumps(x,ensure_ascii=False)[:3200],flush=True)

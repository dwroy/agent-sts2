import json,collections,datetime,hashlib
from pathlib import Path
p=Path(__file__).parent;root=p.parents[2]
D=list(map(json.loads,(p/'decisions.jsonl').open()));S=list(map(json.loads,(p/'states.jsonl').open()));R=json.load((p/'U5W7NUE925NK-resources.json').open())
B=[json.loads(l.split(':',2)[2]) for l in (p/'brain-matches.txt').open()]
print('BRAIN TOTAL',len(B),{k:sum((x.get('usage')or{}).get(k,0)or 0 for x in B)for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']})
for x in B:
 task=(x.get('payload')or{}).get('run_plan_task')or{}
 # The task is normally under facts, so search by exact key and print only its clock.
 def clocks(o):
  if isinstance(o,dict):
   for k,v in o.items():
    if k=='act_boss_clock':yield v
    elif k not in ['memory','system']:yield from clocks(v)
  elif isinstance(o,list):
   for v in o:yield from clocks(v)
 for c in clocks(x):print('CLOCK',x['label'],x['ts'],{k:c.get(k)for k in ['boss','boss_hp','deck_damage_per_turn_estimate','hp_loss_per_turn','survivable_turns','gap_per_turn','estimate_note']})
ss=[x for x in S if 440098<=x['_line']<=440170]
def power(e,k):return next((x['amount']for x in e.get('powers',[])if x['power_id']==k),0)
turns={t:dict(direct=0,poison=0,healing=0,net=0,evidence=[])for t in range(1,14)}
for a,b in zip(ss,ss[1:]):
 x=a['state']['combat']['enemies'][0];y=b['state']['combat']['enemies'][0];t=a['state']['turn'];delta=x['current_hp']-y['current_hp'];p0=power(x,'POISON_POWER');p1=power(y,'POISON_POWER');v=turns[t];v['net']+=delta
 if p0>=2 and (p1==p0-2 or (b['state']['turn']!=a['state']['turn'] and p1==p0 and delta!=0 and any(z['power_id']=='NOXIOUS_FUMES_POWER' and z['amount']==2 for z in a['state']['combat']['player']['powers']))):
  poison=p0+p0-1;heal=poison-delta;v['poison']+=poison;v['healing']+=heal;v['evidence'].append([a['_line'],b['_line'],p0,p1,delta,poison,heal])
 elif delta>0:v['direct']+=delta
 elif delta<0:v['healing']-=delta
for t,v in turns.items():v['damage']=v['direct']+v['poison'];print('TURN',t,v)
print('SUM',{k:sum(v[k]for v in turns.values())for k in ['direct','poison','healing','net','damage']})
first=datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'));last=datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'));print('DURATION',(last-first).total_seconds(),(last-first).total_seconds()/60)
print('JEVUSAGE',{k:sum((x.get('usage')or{}).get(k,0)or 0 for x in D if x['decider']=='jev')for k in ['input_tokens','output_tokens']})
(p/'derived-corrected.json').write_text(json.dumps(dict(boss_turns=turns,decision_duration_seconds=(last-first).total_seconds(),brain_usage={k:sum((x.get('usage')or{}).get(k,0)or 0 for x in B)for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']}),ensure_ascii=False,indent=2)+'\n')

import json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2');draft=(p/'lesson-draft.md').read_text();section=[];on=False;heads=0
for line in(root/'notes/lessons.md').open():
 if line.startswith('## U5W7NUE925NK'):
  heads+=1;on=True
 elif on and line.startswith('## '):on=False
 if on:section.append(line)
assert heads==1
assert ''.join(section).strip()==draft.strip(),'追加正文与已核草稿不一致'
records=json.load((p/'evidence-index.json').open());extra=[]
for name in ['brain','config']:
 source=root/'logs'/('brain.jsonl'if name=='brain'else'run-config.jsonl')
 with source.open('rb')as h:
  for l in(p/(name+'-matches.txt')).open():
   n,off,body=l.split(':',2);h.seek(int(off));raw=h.readline();assert json.loads(raw)==json.loads(body)
   extra.append(dict(stream=source.name,line=int(n),offset=int(off),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
for name in {x['stream']for x in records}:
 with(root/'logs'/f'{name}.jsonl').open('rb')as h:
  for r in records:
   if r['stream']!=name:continue
   h.seek(r['offset']);raw=h.read(r['bytes']);assert hashlib.sha256(raw).hexdigest()==r['sha256']
ledger=json.load((p/'ledger-final.json').open());ids={x['id']for x in ledger};expected={'silent-0079','silent-0102','silent-0020','silent-0125','silent-0418','silent-0044','silent-0023','silent-0011','silent-0351'};assert expected<=ids
for x in ledger:
 ev=[e for e in x.get('evidence',[])if e['run']=='U5W7NUE925NK'];assert ev
 assert all(e['role']==('repeat'if x['id']=='silent-0079'else'support')for e in ev)
prior={}
for f in ['ledger-guard.json','ledger-accelerant.json','ledger-footwork.json']:
 for x in json.load((p/f).open()):prior.setdefault(x['id'],x)
for x in ledger:
 if x['id']not in expected:continue
 for key in ['claim','first_run','prior','status','version']:assert x.get(key)==prior[x['id']].get(key),(x['id'],key)
proposal_id=(p/'proposal-cli-id.txt').read_text().strip();assert proposal_id.startswith('silent-proposal-')
found=None
with(root/'paper/materials/learning/code-proposals.jsonl').open()as h:
 for line in h:
  if proposal_id not in line:continue
  x=json.loads(line)
  if x.get('id')==proposal_id and x.get('op')=='add':found=x
assert found and found['state']=='pending'and found['target_task']=='strategy-proposal'
(p/'additional-evidence-index.json').write_text(json.dumps(extra,ensure_ascii=False,indent=2)+'\n')
source_commit='72ce99f6ddc37bfe30af8082b0f8f32027ec95d0';startup='3d691cff96dedd19855b00f4e9d448c43fe1d219';sources=['agent/src/reflex/combat-plan.ts','agent/src/sl/explore.ts'];meta=dict(reference_commit=source_commit,run_config_commit=startup,source_files={})
for path in sources:
 data=subprocess.check_output(['git','-C',str(root/'.worktrees/live'),'show',source_commit+':'+path]);(p/Path(path).name).write_bytes(data);meta['source_files'][path]=hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(['git','-C',str(root/'.worktrees/live'),'diff','--binary',startup,source_commit,'--',*sources]);(p/'startup-to-reference.patch').write_bytes(patch)
(p/'source-references.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
result=dict(section_matches_draft=True,sections=1,original_records_rechecked=len(records)+len(extra),ledger_ids=sorted(expected),protected_ledger_fields_unchanged=True,code_proposal=proposal_id,code_proposal_state='pending',numeric_errata_required=False)
(p/'final-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

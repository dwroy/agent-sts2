import json
from pathlib import Path
p=Path(__file__).parent;S=list(map(json.loads,(p/'states.jsonl').open()));R=json.load((p/'U5W7NUE925NK-resources.json').open())
def belt(a):return '、'.join(f'{i}:{v}'for i,v in a)or'空'
lines=['|层／尝试／敌人中文名及ID|HP入口→退出或截断；净变化（上限均70）|药槽入口→退出或截断|states行；UTC起→止|','|---|---|---|---|']
for w in R['combats']:
 ss=[x for x in S if w['entry']['line']<=x['_line']<=(w.get('exit')or w['last'])['line']]
 names={}
 for x in ss:
  for e in(x['state'].get('combat')or{}).get('enemies',[]):
   names.setdefault(e['enemy_id'],set()).add(e['name'].split(' #')[0])
 enemies='、'.join('/'.join(sorted(v))+' '+k for k,v in names.items())
 a=w['entry'];b=w.get('exit')or w['last'];at=w['sequence']-13 if w['floor']==33 else 1;end='截断'if not w.get('exit')else'死亡'if w['floor']==33 else'赢';net=b['hp']-a['hp']
 lines.append(f"|F{w['floor']}／{at}／{enemies}|{a['hp']}→{b['hp']}；{net:+}（{end}）|{belt(a['potions'])}→{belt(b['potions'])}|s{a['line']}→s{b['line']}；{a['ts'][11:-1]}→{b['ts'][11:-1]}|")
(p/'resources-table.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))

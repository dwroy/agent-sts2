import json,hashlib,re,datetime
from pathlib import Path
p=Path(__file__).parent;root=Path('/home/dw/Projects/agent-sts2');records=[]
for name in ['decisions','states','run-plans','runs','sl-attempts']:
 with (root/'logs'/f'{name}.jsonl').open('rb') as src:
  for x in map(json.loads,(p/f'{name}.jsonl').open()):
   src.seek(x['_offset']);raw=src.readline();actual=json.loads(raw);expected={k:v for k,v in x.items()if k not in ['_line','_offset']};assert actual==expected,(name,x['_line'])
   records.append(dict(stream=name,line=x['_line'],offset=x['_offset'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
D={x['_line']:x for x in map(json.loads,(p/'decisions.jsonl').open())};S={x['_line']:x for x in map(json.loads,(p/'states.jsonl').open())};R=json.load((p/'U5W7NUE925NK-resources.json').open());derived=json.load((p/'derived-corrected.json').open())
assert D[425517]['fingerprint']==D[425616]['fingerprint']
assert [x['entry']['hp']for x in R['combats'][-6:]]==[36]*6
assert [x['entry']['potions']for x in R['combats'][-6:]]==[[[0,'BLOCK_POTION']]]*6
assert len(R['combats'])==19 and all(x['entry_is_turn_one']for x in R['combats'])
assert len([x for x in D.values()if (x.get('chosen')or{}).get('action')=='use_potion'])==12
assert not any((x.get('chosen')or{}).get('action')in ['discard_potion','buy_potion']for x in D.values())
assert [S[n]['state']['run']['current_hp']for n in [440045,440050,440051,440059,440161,440165,440169,440170]]==[8,8,8,4,8,4,4,0]
assert S[440169]['state']['combat']['player']['block']==23
assert S[440169]['state']['combat']['enemies'][0]['intents'][0]['total_damage']==27
assert S[440170]['state']['combat']['enemies'][0]['current_hp']==107
assert sum(x['direct']for x in derived['boss_turns'].values())==134
assert sum(x['poison']for x in derived['boss_turns'].values())==248
assert sum(x['healing']for x in derived['boss_turns'].values())==90
assert 399+90-134-248==107
assert [D[n]['hp_guard']['predicted_hp_saved']for n in [425252,425362]]==[6,6]
assert [D[n]['hp_guard']['predicted_damage_change']for n in [425252,425362]]==[0,-8]
assert S[439551]['state']['run']['current_hp']==32
assert sum((x.get('confidence')is not None and x['confidence']<.35)for x in D.values()if x['decider']=='jev')==29
assert len([x for x in D.values()if x['decider']=='jev'and x['label'].startswith('combat/plan-choice')and x.get('rollout_best_chosen')is True])==110
(p/'evidence-index.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
result=dict(raw_records_verified=len(records),checks='通过',boss_damage=382,boss_healing=90,final_hp=0,enemy_remaining=107,sl_same_fingerprint=True)
(p/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
draft=(p/'lesson-draft.md').read_text();assert draft.count('## U5W7NUE925NK')==1
if any(l.startswith('## U5W7NUE925NK')for l in(root/'notes/lessons.md').open()):raise SystemExit('已存在复盘，停止追加')
(p/'append-lessons.sh').write_text("#!/bin/bash\nset -e\ndate '+%Y-%m-%d %H:%M:%S %z'\nif rg -q '^## U5W7NUE925NK' /home/dw/Projects/agent-sts2/notes/lessons.md; then exit 3; fi\ncat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+draft+"EOF\n")

# 本批十项策略提案复核

批次：20261017-220433-s2-strategy-proposal。角色：silent。基线：`179ed1c628ad25c8cafecae60222b8edf1eafdf2`。

本批不改源码、经验数据或策略参数。旧行为以本批base实际源码为准，不把原局dirty运行树重建为当前源码。验证建议只用冻结实帧，保持其他角色及未观察进阶等价；后续如实施，需撤源码失败/恢复通过与原sandbox检查，再按live流程交付。没有本批源码提交，无实际回退对象。已有原提案ID保持，不另建重复ID。

拟合与时间切分：本次只是冻结证据与已有实现的审计读回，所有相关SL按原局相关样本处理；未拟合新数值。后续行为校准必须另有按时间留出的本角色实盘，不能把本批既有日志同时作为训练与独立验证。

## 1. silent-proposal-03754e1265894000

牌挡敏捷/脆弱/柔嫩逐张核；折扇被动挡、触发时点与持有能力分源

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-mechanisms.md`；SHA256 `518c139723decc4238c7ea5641e671c8738ec240118ff5140ca503612295599f`。本批原字节副本：`silent-proposal-03754e1265894000.original.md`。

账本：silent-0006, silent-0011, silent-0013, silent-0080, silent-0088, silent-0101, silent-0232, silent-0253。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：RC61MFQM63Y6 F17 T2/T11、F23 T3/T4（states 285222—285235）、F29 T3/T4、F33 T1/T3/T4。F23预判后敏捷1、速度后6，斗篷12挡、防御9挡、第三攻击小刀直伤0但折扇4挡，末25挡；T4临时层撤回。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：局部公式可由实帧核对，但无独立胜线、自由参数拟合或整包消费者校准。不能从六次相关SL或整战失败推导单个机制/时点优劣。

处置与下次验证所需：**waiting**。已核RC F23逐牌敏捷/柔嫩与折扇局部帧，首刀和临时敏捷已有窄实现；尚缺原八组件全部适用窗口的联合消费者回放及未见倍率/首刀组合，未定位可新增修改的确定失配。

## 2. silent-proposal-ab055ef7dfbb44e5

验证夜魇收益的存活兑现条件，并只建模本局已观察的幽灵一层无实体；延后饮用整场效果不足，保留旧时点与药价规则。

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-survival-and-ghost.md`；SHA256 `c5490a44836c3900e1d03b59370dea8c076a8b5435236f7a5e575e4c0b516b17`。本批原字节副本：`silent-proposal-ab055ef7dfbb44e5.original.md`。

账本：silent-0140, silent-0069, silent-0005, silent-0206。来源任务 `postmortem`，实现任务 `strategy-proposal`。

证据：XTSV1U9JD34T F49 T1 states 286897→286899：幽灵新增无实体1、攻击26→1、16挡覆盖，次轮10挡；末试T3/T4 states 286978→286987：23→1血，尖啸25→16，夜魇标记3，防御6后死亡。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：T1早喝已经兑现零损；后面失败不证明延后可赢。死亡前复制未兑现不证明禁用夜魇能活。当前末轮致死数值相符。

处置与下次验证所需：**waiting**。幽灵单层已有live祖先96f17377a331e50ea5b6a3fe8d2b605932ed1bd4；夜魇复制未兑现前即死，缺改变复制对象或延后饮药的同条件完整后继，不能判整项duplicate或拟合时点。

## 3. silent-proposal-0129c465c6f5bd79

强制弃牌后候选重核、毒胜保血候选及夜魇/接管首轮兑现边界

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-replay.md`；SHA256 `bf425049a5868e3bec28ff845f0dcc2f5560594b3b85b4380a378ab2295bdcdc`。本批原字节副本：`silent-proposal-0129c465c6f5bd79.original.md`。

账本：silent-0009, silent-0021, silent-0024, silent-0057, silent-0079, silent-0090, silent-0140, silent-0164, silent-0205, silent-0268, silent-0271。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：BTSRF7JL1W1Y F17四试、F31 T2/T3；XTSV1U9JD34T F48 T8 states 286893→286896：32血/5能量/54毒，凋萎9先扣，23血入F49。F49 T4复制标记不等于下一轮到手，耳环接管内部过程仍未知。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：已实现两个窄子项不覆盖所有抽弃、接管和后继。未执行保血线不是真实F49赢线。

处置与下次验证所需：**waiting**。普通生存者弃牌及毒胜保血已有live祖先bf423c173d3be348a4ad714e1d26516df619ff41、222445a9bb6bf56cb4f3ceea2cc8b20fba54128f；接管内部动作、夜魇后继与跨抽弃候选完整执行归属仍未齐。

## 4. silent-proposal-abe9d5d0be109a9f

赢战血价、真实回复与存档恢复接续，连王剩血按实到资源

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-resources.md`；SHA256 `21263e5782fa17b030141cf5d79a9968115beeb1a99dc66f6309cbac9b51957b`。本批原字节副本：`silent-proposal-abe9d5d0be109a9f.original.md`。

账本：silent-0019, silent-0020。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：BTSRF7JL1W1Y F30胜战消耗与F31入场；XTSV1U9JD34T F48 T8 32→23及F49 T1仍23，未见中间回复。胜战消耗、营火/事件回复、同瓶SL恢复须分源，局部窗口不代替115局模型。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：敌人、牌组、幕、路线与抽序同时变化；缺同条件路线/锻造/留药反事实，不设安全血线。

处置与下次验证所需：**waiting**。已核BTS F30/F31及XTS F48/F49真实入血接续；原115局完整分源资源模型和路线/休息消费者校准、同条件改线/留药/锻造后继及独立留出未齐，不制定新阈值。

## 5. silent-proposal-f16527e59b5cc1e0

敏捷/脆弱/覆甲分源、毒与临时减力时点及留挡上限按实帧核

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-mechanisms.md`；SHA256 `a71d6c87441d33115c5a8f4d3e0103673fd07798805978646f3a3961fb749079`。本批原字节副本：`silent-proposal-f16527e59b5cc1e0.original.md`。

账本：silent-0005, silent-0006, silent-0011, silent-0013, silent-0016, silent-0027, silent-0046, silent-0069, silent-0095, silent-0128, silent-0196, silent-0241。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：BTSRF7JL1W1Y F17 T5、F31 T2/T3；XTSV1U9JD34T F48 T8、F49 T1—T4。幽灵后钳子留10；T2末余挡只留5到T3，末试T3 23→1，T4 1血6挡对16仍死。54毒三结159按132HP截断，不当未截断毛伤。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：多来源同时变化且有截断；不能由HP净差识别全部毛伤、取整次序或机制组合。

处置与下次验证所需：**waiting**。局部留挡、减力、毒结算有实帧支持且部分已有实现；尚缺毒触发、临时属性撤回、留挡上限及敌成长在共同输入下的完整联合消费者回放，未发现新的可复现源码失配。

## 6. silent-proposal-7a8e9ccb7e646538

毒/倍率挡/持牌伤及荆棘按实结算，SL换线预测与整轮实差分账

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-combat.md`；SHA256 `e365da8858d06c845b8f83b662fad011721eeab59fd4e0dce4c46aa3925b640f`。本批原字节副本：`silent-proposal-7a8e9ccb7e646538.original.md`。

账本：silent-0005, silent-0006, silent-0011, silent-0021, silent-0024, silent-0027, silent-0034, silent-0077, silent-0079, silent-0123, silent-0129, silent-0180, silent-0221。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：9Z9H2EXKLF3T F48 T2/T3/T4/T7/T8/T10/T11。states 288006—288008：39毒两结77，荆棘3，敌112→32；玩家死亡，不预支未执行第二击的反伤。T7换线和熔炉时点共同变化，不形成单因素整战因果。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：全败抽样不是实盘必死证明；没有受控整战胜线，不将局部换伤差当胜率提升。

处置与下次验证所需：**waiting**。已核9Z末轮77毒加3反伤的80净扣血；死亡截断仍缺逐击毛伤事件、完整候选执行归属与同条件整战后继，不能用局部净差改SL血价或判定必死。

## 7. silent-proposal-cd9f76184de6e29a

跨幕缺血80%回复与营火/胜战消耗/SL资源接续按实到节点分账

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-resources.md`；SHA256 `54f562100db0a2dbc72c07a5b1411e42838e3370221a23ea4b769795196c66aa`。本批原字节副本：`silent-proposal-cd9f76184de6e29a.original.md`。

账本：silent-0019, silent-0020, silent-0243。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：HMVJKM56S4Q8、F4QKG4J1AJJZ、G403VCZ3BH1B（三局A9）；25226ZFLNR1J、JLN5SK17W4FQ、JMH5C51RLN4E、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、9Z9H2EXKLF3T（七局A10）。F17→18/F33→34，共16对，属节点无回合；9Z states 287266→287267的24/70→60/70，287574→287575的23/77→66/77。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：仅A9/A10这些同上限先古节点转换成立；不外推低阶或未观察遗物/先古交互。其他资源流和消费者验收仍缺。

处置与下次验证所需：**waiting**。已重核原十局16对先古节点回复均为floor(缺失HP×80%)；原116局完整资源输入、逐来源路线/休息消费者校准及独立收益验证未齐，限定公式支持不足认证整个资源模型。

## 8. silent-proposal-292f6731bdb9b669

核对静默A10头骨组合毒药水实加7毒与现有窄范围上下文，未知持有价不当已校准零值，不拟合早喝规则

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-044302-postmortem/proposal-poison-potion.md`；SHA256 `2f943d1aee2e7ed6d1ddfa07b469a4488d27525bad4714cec58f6a94917a8c63`。本批原字节副本：`silent-proposal-292f6731bdb9b669.original.md`。

账本：silent-0087, silent-0020。来源任务 `postmortem`，实现任务 `strategy-proposal`。

证据：7X0W3U8TVA2A A10 F31 T13 states 288470→288472，decisions 282021：后段零毒→7，饮用当步HP25不变，结算后18；前段12→4、中段0→25。玩家1血14挡，对5+8×2仍需损7，实际死亡。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：单次组合总增量7不隔离基础药效，也不覆盖其他目标和叠毒。死亡反驳该轮7毒足以救场，不反驳早喝可能有价值。

处置与下次验证所需：**waiting**。仅核7X F31T13头骨组合对零毒后段实加7；未分离基础药效/头骨贡献，其他目标、叠毒和重接组合及持有价/时点无可比验证，现有observedPoison单数入口不能据此向所有候选目标赋7。

## 9. silent-proposal-0802f69b28d25079

静默A10同盘SL少一防御以8血换6即时伤；固定核对速度药/毒素/资源链，验证饱和探索血价并保留缺反事实限制

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-sl.md`；SHA256 `79e1696de63d19810eb442ee3afa83dd5795f1693f4c9f4a48433fef014e3596`。本批原字节副本：`silent-proposal-0802f69b28d25079.original.md`。

账本：silent-0079, silent-0019, silent-0044, silent-0080, silent-0253, silent-0011, silent-0214, silent-0189, silent-0046, silent-0222, silent-0243, silent-0262。来源任务 `postmortem`，实现任务 `strategy-proposal`。

证据：MTQ0EUBJ3R6T A10 F23 T3，states 288806—288812、288899—288905，decisions 282434。相同10HP/敌61和41：原线29挡，替线19挡；两毒素10加弱后攻击17共需27，次轮10与2HP，敌净扣13与19。四试是一个相关样本。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：原线也未赢，替线后抽序和毒雾建立有变化；即时多6伤不等于整战改善，更不能由24/24饱和学出新阈值。

处置与下次验证所需：**waiting**。已核MT F23T3同盘少一防御多损8血、多伤6；资源差值审计已有live祖先1698adc96ba434a46942321e0237b70657e625b2，缺独立A10留出及固定抽弃/用药时点完整后继，不能拟新排序门槛或药价。

## 10. silent-proposal-763a4b9d9f17b815

逐牌敏捷、临时减力、持牌伤和已建立能力的时间边界

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-mechanisms.md`；SHA256 `989dcea2a0dd5cad05d276157131dec57fdb9d17b2bdab66cbd25f32e0e9ad39`。本批原字节副本：`silent-proposal-763a4b9d9f17b815.original.md`。

账本：silent-0005, silent-0006, silent-0011, silent-0013, silent-0044, silent-0046, silent-0053, silent-0080, silent-0087, silent-0189, silent-0214, silent-0222, silent-0235, silent-0253。来源任务 `experience-update`，实现任务 `strategy-proposal`。

证据：7X0W3U8TVA2A F31 T1/T2/T13；MTQ0EUBJ3R6T F17 T8、F20 T3、F23 T3/T5/T6。F23速度药+5敏捷须经两防御/妙计兑现；少一防御实损8，不能预支旧能力或把一层昏眩推广所有未知层数。

旧规则与预期行为：原提案的旧/新行为全文保持；只核实际效果、执行归属、收益时点及缺数据，不新增优先级或参数。

反例与限制：跨14项的完整联合覆盖不足；能力持有与实际建立分开，不以局部机制一致证明整包排序、药价或生存后继正确。

处置与下次验证所需：**waiting**。已核7X/MT临时属性、持牌伤和能力建立时点；十四项仍缺全部联合生产消费者回放及部分能力/昏眩/后继证据，不能把经验文字与窄组件实现当整包完成。

# 静默猎手十项已领取提案核验报告

本批完成十项消费复核，十项均为 waiting；没有发现足以新增策略修改、且能由本批冻结证据确立的源码失配。部分子项已有实际live祖先实现，但整项范围尚未覆盖，不能登记整项 implemented/duplicate。未修改源码/知识、未提交、未合入、未分配版本，未登记 shipped。

## 身份与基线

- task=strategy-proposal；character=silent；batch=20261017-220433-s2-strategy-proposal。
- 开工工作树干净；HEAD与 `git merge --no-edit main` 后均为 `179ed1c628ad25c8cafecae60222b8edf1eafdf2`（Already up to date）。本批没有 research_request/implementation_request，reason=proposal，proposal_ids恰为本报告十项；普通专题旧绑定与本批不匹配，未承接其他专题或队列项。
- `runs` 只填本批十个派发锚点。原提案直接关联的另外五局9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0/7X0W3U8TVA2A/MTQ0EUBJ3R6T单独核runs身份后补链，共15局，全部SILENT，A9三局/A10十二局；不是全历史复算。原提案中的112/115/116/118全史口径没有由本批重新完成。
- 十份原Markdown的实际SHA全部等于队列保存SHA，副本保持原字节。46个关联账本均核silent；只通过根ledger CLI追加本批追溯，不新增游戏结论/支持数或更改旧claim、首证、prior、status、version、effect。

## 原日志和数值读回

共用extract_evidence入口八流冻结，22,424封套逐条从根原日志seek原offset、读原bytes、验证原SHA256/JSON/显式身份，states再核角色和进阶；输出流SHA与manifest一致。源日志只读，15局分流计数见evidence-verification.json和audit-summary.json。

| 流 | 选中原行 | 冻结source_size | 原流不可解析行 |
|---|---:|---:|---:|
| states | 11008 | 14072759653 | 2 |
| decisions | 10609 | 2360207036 | 2 |
| sl-attempts | 109 | 46268911 | 0 |
| run-config | 16 | 1992475 | 0 |
| run-plans | 97 | 9069145 | 0 |
| brain | 570 | 774257835 | 2 |
| runs | 15 | 362905 | 0 |
| fight-plans | 0 | 2233957 | 0 |

fight-plans为该截点选中0条，只说明未选到；不断言原日志缺失。states/decisions/brain各有2条不可解析原行，未分配到任何局，原流保持；不把它们当本角色证据。没有身份冲突行混入，未把正文提及当所属局。

779个关键帧、7组原帧事实检查及22对先古实际入场配对落盘；数值检查是证据审计，未执行生产消费者、生产测试、模拟校准或新对局。

- RC F23T3：预判后敏捷1、速度后6；斗篷12、防御9、折扇4，末25挡；T4临时层撤回。RC F33首题原rollout是3轮/2样本，后续题5轮/24样本，不能写成各试同预算全为24/24。该既有口径异议已在原4fc1006000c71a8e0eed8b1c通知链记录，本批不代任何角色ACK或重复通知。
- XTS F48T8：54毒三结理论159按132HP截断，凋萎实耗9血，32→23；F49仍23。F49T1幽灵26→1、16挡覆盖，次轮钳子只留10。末T4夜魇标记3后死亡，1血+6挡对16，预计HP为−9；没有下一轮复制兑现，亦无“去夜魇即可活”的证据。
- 7X F31T13：仅后段零毒→7，饮用当步25HP不变，结算后18；前段12→4、中段0→25。1血14挡对21攻仍死。未隔离基础药效/头骨贡献，不向其他目标或叠毒推7。
- MT F23T3同盘：原29挡与替19挡，对两毒素10+攻击17共27，次轮10HP/2HP；敌净扣13/19，即多损8、多伤6。四次尝试是一局相关证据；不能用后续不同动作的敌残倒定门槛。
- 9Z F48末T11：39+38毒=77，加实见3反伤，敌112→32共80；死亡截断后的未执行反伤不预支。
- 原cd9提案十局16对F17→18/F33→34先古节点回复全部满足floor(缺失HP×80%)；见act-transitions.json。幕号变化本身发生在仍未回血的MAP，初次按幕号配对的摘要、脚本和错误口径已保留为.initial.txt，修正说明见analysis-corrections.md；这些零回血中间帧不是公式反例。其他六对仅本批同角色审计读回，不外推新进阶或未知交互。

## 当前源码和已有窄实现

只读固定base及实际live快照 `deb9135b8c8e63080beae091b959a04738c64587`。13个相关生产文件保存base字节txt、Git blob/SHA和live工作树/提交逐项布尔；8文件字节相同，另5文件差异仅Roy/Dai注释署名，原diff完整留存，不宣称所有13叶SHA一致。实际live可能继续前进，该哈希只代表本批取样时点，未把它当原局dirty完整运行树。

| 限定子项 | 实际live祖先源码commit |
|---|---|
| Consume observed Silent Survivor discards without Tough Bandages | `bf423c173d3be348a4ad714e1d26516df619ff41` |
| Preserve HP before observed Silent poison victories | `222445a9bb6bf56cb4f3ceea2cc8b20fba54128f` |
| Model observed Silent Ghost in a Jar protection | `96f17377a331e50ea5b6a3fe8d2b605932ed1bd4` |
| Fix Phantom Blades first-Shiv damage in plans | `d65609ff2bc98ec5ec2e06b558159aba89d93032` |
| Fix upgraded Anticipate temporary Dexterity in plans | `d91f9600286a67480b5044e019dbb1041e2239af` |
| Complete Silent SL resource comparison audit | `1698adc96ba434a46942321e0237b70657e625b2` |
| Expose unknown Silent potion value beside dry-plan forecasts | `c4670f4f416c7d93e192e889c5080e7e4e0e733f` |

上述七提交均核为本批base和该live快照的祖先。源码入口显示普通单弃、毒胜保血、幽灵单层、首刀增伤、临时敏捷及审计文字已有具体处理；不能把七个窄实现拼成十个宽请求完成。observedPoison仍有连王和限定知识恶魔组合入口，本批7X后段零毒的一个组合样本不能证明向所有候选目标统一建模7正确；未知持有价已有null和独立参考展示，未学出新的HP价格。

## 逐项处置

| 提案 | 处置及具体缺口 |
|---|---|
| `silent-proposal-03754e1265894000` | waiting；已核RC F23逐牌敏捷/柔嫩与折扇局部帧，首刀和临时敏捷已有窄实现；尚缺原八组件全部适用窗口的联合消费者回放及未见倍率/首刀组合，未定位可新增修改的确定失配。 |
| `silent-proposal-ab055ef7dfbb44e5` | waiting；幽灵单层已有live祖先96f17377a331e50ea5b6a3fe8d2b605932ed1bd4；夜魇复制未兑现前即死，缺改变复制对象或延后饮药的同条件完整后继，不能判整项duplicate或拟合时点。 |
| `silent-proposal-0129c465c6f5bd79` | waiting；普通生存者弃牌及毒胜保血已有live祖先bf423c173d3be348a4ad714e1d26516df619ff41、222445a9bb6bf56cb4f3ceea2cc8b20fba54128f；接管内部动作、夜魇后继与跨抽弃候选完整执行归属仍未齐。 |
| `silent-proposal-abe9d5d0be109a9f` | waiting；已核BTS F30/F31及XTS F48/F49真实入血接续；原115局完整分源资源模型和路线/休息消费者校准、同条件改线/留药/锻造后继及独立留出未齐，不制定新阈值。 |
| `silent-proposal-f16527e59b5cc1e0` | waiting；局部留挡、减力、毒结算有实帧支持且部分已有实现；尚缺毒触发、临时属性撤回、留挡上限及敌成长在共同输入下的完整联合消费者回放，未发现新的可复现源码失配。 |
| `silent-proposal-7a8e9ccb7e646538` | waiting；已核9Z末轮77毒加3反伤的80净扣血；死亡截断仍缺逐击毛伤事件、完整候选执行归属与同条件整战后继，不能用局部净差改SL血价或判定必死。 |
| `silent-proposal-cd9f76184de6e29a` | waiting；已重核原十局16对先古节点回复均为floor(缺失HP×80%)；原116局完整资源输入、逐来源路线/休息消费者校准及独立收益验证未齐，限定公式支持不足认证整个资源模型。 |
| `silent-proposal-292f6731bdb9b669` | waiting；仅核7X F31T13头骨组合对零毒后段实加7；未分离基础药效/头骨贡献，其他目标、叠毒和重接组合及持有价/时点无可比验证，现有observedPoison单数入口不能据此向所有候选目标赋7。 |
| `silent-proposal-0802f69b28d25079` | waiting；已核MT F23T3同盘少一防御多损8血、多伤6；资源差值审计已有live祖先1698adc96ba434a46942321e0237b70657e625b2，缺独立A10留出及固定抽弃/用药时点完整后继，不能拟新排序门槛或药价。 |
| `silent-proposal-763a4b9d9f17b815` | waiting；已核7X/MT临时属性、持牌伤和能力建立时点；十四项仍缺全部联合生产消费者回放及部分能力/昏眩/后继证据，不能把经验文字与窄组件实现当整包完成。 |

每项的局号/层/回合、账本、反例、原提案、预期行为和后续验证要求详见proposal.md；最终机器处置见proposal-results.json。原队列历史和proposal原文不修改，新提案ID为零。

## 验证、提交与交付

生产源码撤除/恢复检查：不适用（本批无源码变更）。tsc、vitest、cases均null，未冒用其他批次绿灯。未执行play、网络、LLM调用、npm install、全史新模拟或后台模型；由本学习者独立完成。后台抽取和审计均nice10单进程。

fixes=[]，merged=null，release=null；没有源码提交或合入阻塞需兜底。各项保留waiting，等待具体缺少的新局/执行后继或消费者校准；不关闭量化学习、资源或其他父要求。其他角色行为未改。

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-220433-s2/learner/runs/20261017-220439-e97a70bb-f8b1-408b-bd7b-bddac2a2aa59-strategy-proposal/report.md
提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-220433-s2/learner/runs/20261017-220439-e97a70bb-f8b1-408b-bd7b-bddac2a2aa59-strategy-proposal/proposal.md

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', SCRATCH.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def write(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def ref(item):
    return {key: item[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def compact(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'ref': ref(item), 'ts': item['row'].get('ts'),
        'floor': run.get('floor'), 'act': run.get('act_id'), 'turn': state.get('turn'),
        'screen': state.get('screen'), 'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': player.get('powers'),
        'potions': [{k: p.get(k) for k in ('index', 'potion_id', 'occupied')} for p in run.get('potions', [])],
        'hand': [{k: card.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost', 'playable',
                  'playability_reason', 'resolved_rules_text', 'dynamic_values')} for card in combat.get('hand', [])],
        'enemies': [{k: enemy.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block',
                     'is_alive', 'powers', 'move_id', 'intents')} for enemy in combat.get('enemies', [])],
    }


def selected(state):
    run = state.get('run') or {}
    name, floor, turn = state.get('run_id'), run.get('floor'), state.get('turn')
    windows = {
        'RC61MFQM63Y6': {17: {2, 3, 11}, 23: {3, 4}, 29: {3, 4}, 33: {1, 3, 4}},
        'XTSV1U9JD34T': {48: {8}, 49: {1, 2, 3, 4}},
        'BTSRF7JL1W1Y': {17: {5}, 30: None, 31: None},
        '9Z9H2EXKLF3T': {35: None, 38: None, 39: None, 42: None, 45: None, 47: None,
                           48: {1, 2, 3, 4, 7, 8, 10, 11}},
        '7X0W3U8TVA2A': {30: None, 31: {1, 2, 13}},
        'MTQ0EUBJ3R6T': {17: {8}, 20: {3}, 23: {3, 5, 6}},
    }
    w = windows.get(name, {})
    return floor in w and (w[floor] is None or turn in w[floor])


manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
identities = json.loads((SCRATCH / 'all-run-identities.json').read_text())
counts = collections.defaultdict(collections.Counter)
checks, frames, transitions, headers, decisions, attempts = [], [], [], [], [], []
last_state = {}
for stream in manifest:
    path = SCRATCH / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    with Path(ROOT / 'logs' / (stream['stream'] + '.jsonl')).open('rb') as source, path.open('rb') as evidence:
        for encoded in evidence:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['run_id'] in identities
            assert extract.run_identity(item['row']) == item['run_id']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert item['offset'] + item['bytes'] <= stream['source_size']
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            counts[stream['stream']][item['run_id']] += 1
            row = item['row']
            if stream['stream'] == 'states':
                state = row['state']
                run = state.get('run') or {}
                assert run.get('character_id') == 'SILENT'
                assert run.get('ascension') == identities[item['run_id']]['ascension']
                curr = compact(item)
                previous = last_state.get(item['run_id'])
                if previous and curr['act'] != previous['act'] and previous['act'] is not None and curr['act'] is not None:
                    headers.append({'run_id': item['run_id'], 'before': previous, 'after': curr})
                if (previous and previous['floor'] in (17, 33) and curr['floor'] == previous['floor'] + 1
                        and previous['screen'] == 'MAP' and curr['screen'] == 'EVENT'
                        and previous['act'] == curr['act']):
                    before, after, maximum = previous['hp'], curr['hp'], curr['max_hp']
                    predicted = (maximum - before) * 4 // 5 if previous['max_hp'] == maximum else None
                    transitions.append({'run_id': item['run_id'], 'before': previous, 'after': curr,
                                        'observed_heal': after - before, 'formula_heal': predicted})
                last_state[item['run_id']] = curr
                if selected(state):
                    frames.append(curr)
            elif stream['stream'] == 'decisions':
                if item['run_id'] in ('RC61MFQM63Y6', 'XTSV1U9JD34T', 'BTSRF7JL1W1Y',
                                      '9Z9H2EXKLF3T', '7X0W3U8TVA2A', 'MTQ0EUBJ3R6T'):
                    decisions.append({'ref': ref(item), **{k: row.get(k) for k in
                        ('ts', 'floor', 'turn', 'label', 'decider', 'chosen', 'rationale', 'facts')}})
            elif stream['stream'] == 'sl-attempts':
                attempts.append({'ref': ref(item), 'row': row})
    assert digest.hexdigest() == stream['output_sha256']
    assert dict(counts[stream['stream']]) == {k: v for k, v in stream['counts'].items() if v}
    checks.append({'stream': stream['stream'], 'source_size': stream['source_size'],
                   'output_sha256': digest.hexdigest(), 'rows_checked': sum(counts[stream['stream']].values()),
                   'counts': dict(counts[stream['stream']]), 'offset_bytes_sha_json_identity': True})
write('evidence-verification.json', checks)
write('key-state-frames.json', frames)
write('act-header-transitions.json', headers)
write('act-transitions.json', transitions)
write('key-decisions.json', decisions)
write('sl-attempts-verified.json', attempts)
write('audit-summary.json', {'rows_checked': sum(c['rows_checked'] for c in checks),
                            'key_frames': len(frames), 'transitions': len(transitions),
                            'transition_formula_mismatches': sum(t['observed_heal'] != t['formula_heal'] for t in transitions),
                            'counts': {k: dict(v) for k, v in counts.items()}})
print(json.dumps({'rows_checked': sum(c['rows_checked'] for c in checks), 'key_frames': len(frames),
                  'transitions': len(transitions), 'streams': len(checks)}, ensure_ascii=False))

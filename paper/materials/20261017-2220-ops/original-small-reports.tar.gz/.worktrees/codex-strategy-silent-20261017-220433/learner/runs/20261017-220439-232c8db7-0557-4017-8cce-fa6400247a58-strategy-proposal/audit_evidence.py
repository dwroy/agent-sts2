import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
SPEC = importlib.util.spec_from_file_location("extract_evidence", OUT.parents[1] / "extract_evidence.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
RUNS = set(json.loads((OUT / "dispatch.json").read_text())["runs"])
stream_audits = []
streams = {}
for folder in ["evidence", "evidence-small"]:
    for manifest in json.loads((OUT / folder / "evidence-manifest.json").read_text()):
        name = manifest["stream"]
        path = OUT / folder / (name + ".evidence.jsonl")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest["output_sha256"]
        counts = Counter()
        envelopes = []
        source = Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")
        with source.open("rb") as handle:
            for line in path.open():
                item = json.loads(line)
                assert item["run_id"] in RUNS
                assert MODULE.run_identity(item["row"]) == item["run_id"]
                assert item["offset"] + item["bytes"] <= manifest["source_size"]
                handle.seek(item["offset"])
                raw = handle.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                counts[item["run_id"]] += 1
                envelopes.append(item)
        assert {run: counts[run] for run in RUNS} == manifest["counts"]
        stream_audits.append({**manifest, "verified_lines": len(envelopes), "raw_bytes_verified": True})
        streams[name] = envelopes

states = streams["states"]
decisions = {item["line"]: item for item in streams["decisions"]}
for item in streams["runs"]:
    assert item["row"]["character"] == "SILENT" and item["row"]["ascension"] == 10
for item in states:
    run = item["row"]["state"]["run"]
    assert run["character_id"] == "SILENT" and run["ascension"] == 10


def compact(item):
    state = item["row"]["state"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {"state_line": item["line"], "turn": state["turn"], "hp": player.get("current_hp"),
            "enemies": [{"id": enemy["enemy_id"], "hp": enemy["current_hp"], "powers": enemy["powers"]}
                        for enemy in combat.get("enemies", [])]}


def window(number):
    item = decisions[number]
    row = item["row"]
    candidates = [state for state in states if state["run_id"] == item["run_id"]
                  and state["row"]["fingerprint"] == row["fingerprint"]
                  and state["row"]["ts"] <= row["ts"]]
    start = max(candidates, key=lambda state: state["row"]["ts"])
    later = [state for state in states if state["run_id"] == item["run_id"] and state["line"] > start["line"]]
    end = next(state for state in later if state["row"]["state"]["turn"] != row["turn"])
    assert end["row"]["state"]["turn"] == row["turn"] + 1
    assert end["row"]["state"]["run"]["floor"] == row["floor"]
    a, b = compact(start), compact(end)
    return {"decision_line": number, "run_id": item["run_id"], "floor": row["floor"], "turn": row["turn"],
            "attempt": row["sl_attempt"], "before": a, "next_turn": b,
            "observed_net_hp_loss": a["hp"] - b["hp"],
            "observed_enemy_net_hp_reduction": sum(enemy["hp"] for enemy in a["enemies"]) - sum(enemy["hp"] for enemy in b["enemies"]),
            "scope": "observed_question_to_next_turn_not_isolated_action_effect",
            "sl_explore": row.get("sl_explore")}


pairs = []
for first, second in [(272434, 272575), (272531, 272652), (272483, 272820),
                      (273400, 273450), (273242, 273474), (274505, 274568), (274484, 274601)]:
    assert decisions[first]["row"]["fingerprint"] == decisions[second]["row"]["fingerprint"]
    pairs.append({"same_fingerprint": True, "original": window(first), "replacement": window(second)})

potion_pairs = [(274131, 280206, 280207, 0, "ATTACK_POTION"),
                (274156, 280232, 280233, 0, "STABLE_SERUM"),
                (274185, 280262, 280263, 0, "SPEED_POTION"),
                (274235, 280313, 280314, 1, "WEAK_POTION"),
                (274237, 280315, 280316, 0, "ATTACK_POTION"),
                (274267, 280348, 280349, 1, "GLOWWATER_POTION"),
                (274272, 280354, 280355, 0, "SKILL_POTION")]
by_line = {item["line"]: item for item in states}
potions = []
for number, before, after, slot, potion in potion_pairs:
    row = decisions[number]["row"]
    assert row["chosen"]["action"] == "use_potion" and row["chosen"]["option_index"] == slot
    a, b = [by_line[line]["row"]["state"]["run"]["potions"][slot] for line in [before, after]]
    assert a["index"] == b["index"] == slot and a["potion_id"] == potion and b["occupied"] is False
    potions.append({"decision_line": number, "before_state": before, "after_state": after,
                    "floor": row["floor"], "turn": row["turn"], "slot": slot, "potion_id": potion,
                    "result": row["result"], "slot_consumption_verified": True, "whole_plan_benefit": None})

attempts = []
for item in streams["sl-attempts"]:
    row = item["row"]
    last = row["summary"]["turns"][-1]
    attempts.append({"source_line": item["line"], "run_id": item["run_id"],
                     **{key: row[key] for key in ["floor", "attempt", "result", "turns", "end_hp", "incoming"]},
                     "last_turn": last})

result = {"streams": stream_audits, "verified_lines": sum(x["verified_lines"] for x in stream_audits),
          "identity_verified": True, "pairs": pairs, "potion_consumption": potions,
          "attempts": attempts, "production_tests_run": False}
(OUT / "evidence-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_lines": result["verified_lines"], "pairs": len(pairs), "potion_consumptions": len(potions),
                  "stream_counts": {x["stream"]: x["verified_lines"] for x in stream_audits}}, ensure_ascii=False))
for pair in pairs:
    a, b = pair["original"], pair["replacement"]
    print(json.dumps({"decisions": [a["decision_line"], b["decision_line"]],
                      "net_hp_loss": [a["observed_net_hp_loss"], b["observed_net_hp_loss"]],
                      "enemy_net_hp_reduction": [a["observed_enemy_net_hp_reduction"], b["observed_enemy_net_hp_reduction"]]}, ensure_ascii=False))

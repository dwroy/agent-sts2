# 静默猎手策略批次完成报告

批次：20261017-220433-strategy-proposal。角色：silent，证据限已核实 A10 六局。基线：`179ed1c628ad25c8cafecae60222b8edf1eafdf2`。
本批是普通已领取提案任务，无 research_request、implementation_request 或 proposal_repair；普通专题请求绑定另一批，不转入专题。原十项 id 和 Markdown SHA 全部逐项核同，不新建提案 id。

## 证据与边界

原件经共用 extract_evidence.py 抽取，八流共 8,444 行逐 offset/bytes/SHA/JSON 与明确局身份读回。状态 4,167、决策 4,071、SL 43、run-config 6、run-plans 21、brain 130、runs 6；fight-plans 在本次 source_size 截点选中 0，不推断原日志缺失。states/decisions/brain 全流各有 2 条非法行，未归属、未修复，不声称覆盖无法识别的原行。
日志状态直接读取本局血量和来袭，不新增怪物数值或房间代价参数。没有重新运行模拟器、LLM、网络或 play。

| 证据局 / 层 / 回合 | 同指纹原决策→替线决策 | 实际净损血 | 敌实际净扣血 |
|---|---|---|---|
| 751FN9QM9MHQ F17 T2 | 272434→272575 | 13→18 | 9→18 |
| 751FN9QM9MHQ F17 T7 | 272531→272652 | 13→23 | 12→18 |
| 751FN9QM9MHQ F17 T13 | 272483→272820 | 8→2 | 17→11 |
| KV0JHNJCKXLS F33 T5 | 273400→273450 | 0→0 | 36→29 |
| KV0JHNJCKXLS F33 T1 | 273242→273474 | 0→0 | 28→14 |
| KEN58SH9SLZ6 F17 T10 | 274505→274568 | 15→21 | 2→4 |
| KEN58SH9SLZ6 F17 T5 | 274484→274601 | 7→5 | 1→2 |

这些是从题面观测帧至下一回合的净变化，含后续动作及敌方阶段，不是隔离单动作的因果收益或毛伤害。抽牌、弃牌及额外小刀后的重问另属后继。七组来自三个独立局，不能按七局或多次 SL 拆训练/验证。

## 逐项处置与待验证行为

### silent-proposal-366288801d9150d9

账本：silent-0079, silent-0176。来源任务：postmortem；实现任务：strategy-proposal。领域：sl, combat。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md`；原文 SHA256 `0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`，本批保存 `silent-proposal-366288801d9150d9.original.md`。
预期行为：保存原答、护栏前后、SL最终候选、B2差与误差，并核持牌、弃牌及实损来源；新门槛仅在独立验证充分时考虑。
处置：waiting。751 F17 T2/T7/T13同指纹局部成本已核；现有候选、B2差及派发审计未认证逐来源实际结算和完整候选执行。缺固定后续的整战对照及独立验证，不能拟SL探索门槛。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-85929bdfc8a3fc1b

账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。来源任务：postmortem；实现任务：strategy-proposal。领域：combat, potion。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md`；原文 SHA256 `d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`，本批保存 `silent-proposal-85929bdfc8a3fc1b.original.md`。
预期行为：分列未知持有价、当前回合不喝与整战无药参考、未决弃牌的保守损血；不设一律留药或改弃牌固定规则。
处置：waiting。751 F13 T3有药plan2与整战无药plan5均报8/8胜，但实际只走用药支线；未决弃牌损血已有保守来源提示，缺实际联合校准及不喝、留至后战的完整对照，不能改弃牌或持有价。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-efd9f83ee9e1a6dc

账本：silent-0079, silent-0176。来源任务：experience-update；实现任务：strategy-proposal。领域：sl, combat。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md`；原文 SHA256 `0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`，本批保存 `silent-proposal-efd9f83ee9e1a6dc.original.md`。
预期行为：沿同一SL成本审计，保留真实血价与后继归属，不将同一751证据重复计数。
处置：waiting。与366288801d9150d9共用751同局三组对照；现有预测及单动作回执不等逐来源实际兑现。缺完整候选归属、固定后续整战和独立验证，不追加重复实现或独立样本。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-131042659448ae74

账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。来源任务：experience-update；实现任务：strategy-proposal。领域：combat, potion。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md`；原文 SHA256 `b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`，本批保存 `silent-proposal-131042659448ae74.original.md`。
预期行为：联合核实敏捷后继挡、攻击/毒/反伤、临时减力、持牌和药水成本；缺项保持未知。
处置：waiting。751的持牌失血、未知持有价及无药参考已有窄实现；敏捷、毒、荆棘和弃牌的完整候选实际收益尚未联合认证，亦缺跨战留药对照，不能以诊断子项关闭整项。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-990f054036609447

账本：silent-0102, silent-0019, silent-0020。来源任务：experience-update；实现任务：strategy-proposal。领域：combat, sl。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md`；原文 SHA256 `c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`，本批保存 `silent-proposal-990f054036609447.original.md`。
预期行为：将敌回血、实际净扣、毒结算及已建能力分账，营火/幕间/血瓶/SL恢复分开；不预支未走路线收益。
处置：waiting。KV F33 T5同指纹实扣敌36→29、均零净损，下一轮毒20→13；T1扣敌28→14也未省血。缺敌回血与能力的逐来源完整归属、受控胜线及独立验证，不改SL或路线门槛。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-e18d3f18e6cac2a0

账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。来源任务：postmortem；实现任务：strategy-proposal。领域：combat, potion, sl, terminal。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md`；原文 SHA256 `3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`，本批保存 `silent-proposal-e18d3f18e6cac2a0.original.md`。
预期行为：分列巨兽本体0血、blast_pending、原占位HP及最终玩家资源；完整后继未验证前保留原参考排序。
处置：waiting。YQL F17 T10残壳毒2→8而血26、挡13及41来袭不变；现有阶段事实已上线，但占位HP仍进原排序。缺最终资源与完整后继的受控改序、用药时点验证，不能直接归零HP改序。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-9733bb80f445aeae

账本：silent-0017, silent-0019, silent-0020, silent-0250。来源任务：experience-update；实现任务：strategy-proposal。领域：combat, potion, sl, terminal。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md`；原文 SHA256 `c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`，本批保存 `silent-proposal-9733bb80f445aeae.original.md`。
预期行为：沿已有阶段事实说明残壳施毒不等当步减自爆，核真实爆时资源；不外推提前饮用必胜。
处置：waiting。与e18d3f18e6cac2a0共享YQL/L9/PU阶段证据；PU第五试胜余2但多处动作同变，缺改序、提前用药和路线的受控后继，阶段说明与局部资源不能代完整交付。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-c51468c5e8ba6668

账本：silent-0019。来源任务：postmortem；实现任务：strategy-proposal。领域：potion。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md`；原文 SHA256 `168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`，本批保存 `silent-proposal-c51468c5e8ba6668.original.md`。
预期行为：逐槽位核饮用前后、随机选择、生成、重问及后继执行；只有完整实际结果才能归属收益。
处置：waiting。KEN七次用药均有请求和对应槽位消耗，其中两攻击药、技能药为pending回执；缺随机选牌及发光水重问后的完整收益归属、不喝及留至Boss的整战支线，75/86空栏入口不能拟持有价。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-86a7db08d1a31976

账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。来源任务：postmortem；实现任务：strategy-proposal。领域：combat, sl。
原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md`；原文 SHA256 `10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`，本批保存 `silent-proposal-86a7db08d1a31976.original.md`。
预期行为：核呼唤血价、无实体逐段输出和步法建立时点，分别保留Jev原答、护栏、SL与实际动作。
处置：waiting。KEN F17 T10实损15→21、扣敌2→4；T5省2血而步法由T5延到T9，均已核原帧。缺完整候选及能力收益归属、固定后续整战及独立验证，保留排序与HP护栏。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

### silent-proposal-e282a9131b99129a

账本：silent-0021, silent-0079, silent-0125, silent-0176。来源任务：experience-update；实现任务：strategy-proposal。领域：combat, sl。
原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md`；原文 SHA256 `a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`，本批保存 `silent-proposal-e282a9131b99129a.original.md`。
预期行为：沿同一KEN证据核实际血价与能力窗口；不将即时最少失血或更久存活当作整战最优。
处置：waiting。与86a7db08d1a31976共用KEN同局两组对照；六次SL仍是一局。缺受控整战及后期独立验证，不拟统一6血/2伤阈值，也不把省血或未试线当整战更优。
验证：固定上述原帧与完整动作链、原/替候选分别核兑现；若拟新规则，按独立局及开始时间切分较早调参与较晚验证，不在同局多次SL间拆分。保留所有合法候选与原行为。
回退：本批没有源码或经验库改动，无需代码回退；保留本提案、原失败及缺证材料。

## 已有实现与本次未完成范围

只读 live 快照 `deb9135b8c8e63080beae091b959a04738c64587`。基线为该 live 祖先。14 源码叶中 12 叶工作字节相同；explore.ts 和 potion-cost.ts 的差异仅 Roy/Dai 历史署名注释，二进制差异补丁另存，不覆盖任何一边。

| 已有子项 | 实际 live 祖先源码提交 | 当前限制 |
|---|---|---|
| 未决持牌失血与原答/前后候选审计 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | actual_held_hp_loss / actual_turn 仍为 null |
| 未知持有价与无药参考 | c4670f4f416c7d93e192e889c5080e7e4e0e733f | 同题模型对照，不认证未执行留药分支 |
| 巨兽阶段与毒药水观察 | 40168f4a903ae1d8c48bd03006f8fea19fd3aa3c | 不改死亡判定或参考排序 |
| SL候选预测对照 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | actual_turn_result=null |
| SL资源预测对照 | 0e4fe4df89a06682468e0e4716c12126e76369d5 | execution=unverified |
| 单动作派发回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | state_effect_verified=false，whole_plan_executed=null |
| 巨兽结束前限定资源 | b01edf46b4b619f217d070a196e161df9fe716a0 | 限定修饰签名；enemyHpLeft/anchorRank仍保留原占位血输入 |

提交祖先与逐叶 blob/SHA 见 source-audit.json。只证明这些子项存在；十项宽提案均不标 duplicate/implemented/shipped。当前 ledger silent-0250 已是 shipped，这属于此前交付状态，本批不将它外推成宽请求完成，也不回写或重置旧状态。

## 反例、限制和结论

KEN同盘T5省2血却延后步法：第4试决策274485、states280568→280569在T5建2敏；第6试决策274618、states280701→280702到T9才建2敏。这支持同时核启动窗口，反驳“当轮省血恒优”，不证明任一替线整战可胜。
751 F13 T3有药plan2、当前回合不喝plan3、整战无药plan5均5轮8/8胜、预计再损8；plan3后轮7/8喝药，不能冒充整战无药。实际只执行plan2，缺不喝/留药实盘。
YQL states280160→280161只见毒2→8，HP26、block13、incoming41不变。PU F17第5试T15余2胜是多动作变化的一条胜线，不是改SL排序或提前用药的受控实证；L9/YQL的相关失败不拆独立局。
KEN七用药逐槽消耗已核；三条pending仅由后续状态确认槽空，不把pending等同错误或把槽空等同完整药效收益。六次F17初帧均75/86、空药；缺留任意瓶到Boss的分支。
结论：本批数据复核支持成本与阶段必须分账，现有源码已实现多项诊断。剩余需求包含完整执行收益归属及受控整战/跨战验证，本批六局不足新增统一血价、留药或SL排序门槛；十项保留waiting，等待明确缺失的本角色新证据。无新机制异议，与现有经验的“单因未控/未知”限制一致，不新增重复通知。

## 交付和检查

本批只产研究材料与根账本CLI追溯，不改源码、任务模板、生成知识、经验或运维prompt。无源码提交、live合入或版本；无需撤源码红绿、tsc/vitest或生产用例执行，tests三项均null。原完整自测不挪用为本批成功。
离线证据核验不是生产测试：首次audit-evidence.log因scratch路径导入错误退出1，修正后audit-evidence.v2.log退出0，8444行/7组同指纹/7槽位核验通过。slot初稿错误读取slot字段为null；原fixed-state-facts.json保留，fixed-state-facts.v2.json改读原index字段，生产证据和原日志未改。
没有代码提交，不触发提交前gitleaks和live发布流程。没有把任何已有release_id当作本批新版本。根账本只经ledger.py update追加本批提案/报告去向及缺证备注，不新增support，不修改claim/首证/prior/status/version。
最终状态与根CLI追溯读回见report.md、ledger-update-receipt.json。运维接收本proposal.md与report.md；如未来实际实现，只可据真实live祖先代码登记implemented，再由ops核实际部署登记shipped。

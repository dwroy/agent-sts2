# 静默猎手策略提案消费复核

批次：20261017-214302-s2-strategy-proposal；角色：silent；记录时间：2026-10-17 21:56:28 +08:00。
完整基线：`1a677fd8b16bcd538f36a64554b7393b3be6f9e0`。初始工作树干净，`git merge --no-edit main`返回Already up to date。
本批只消费派发的十个原ID，无proposal_repair、research_request或implementation_request；普通专题身份与本批不匹配，未进入专题。

结论：十项均waiting。没有新发现的确定源码失配或充分证据支持的新策略参数，不新增源码、经验、代码提案ID、提交、合入或eval版本。保留原提案及宽缺口，不把已存在的窄实现拼作整项完成。

游戏事实只来自本批六局silent A10的原始日志。知识参照仅使用knowledge/characters/silent中关联条目；不搬用其他角色知识、不使用预训练事实补未知。

## 输入、拟合与验证边界

七流8274条原行均核对原字节offset/bytes/SHA、JSON和唯一显式所属局；正文提及不参与筛选，冲突身份不接收。各流source_size及计数见evidence/evidence-manifest.json与evidence-runs/evidence-manifest.json；逐行回执见envelope-verification.json。
其中4062条状态、3941条决策、38条SL事件、6条run-config、33条run-plans、188条brain及6条runs。全源扫描states/decisions/brain各有2条无效JSON，不能把未选择或无效行解释为本角色不存在证据。CA5在sl-attempts本截点选中0行也不作原流缺失结论。没有复核旧截点或覆盖旧报告。
六局均为2026-10-07已结束的A10失败局，运行code均带dirty；当前源码不冒称复原当时dirty树。SL尝试按run_id归组；本批没有拟合参数、独立后移验证集或受控整战反事实。

状态窗口与四组配对是证据数字核验，未调用生产模拟器，不构成生产固定重放、tsc/Vitest、消费者验证或源码撤除红/恢复绿。没有生产源码修改，后两项不适用，tests三项均null。

## 当前源码限定核查

实际live快照：`72ce99f6ddc37bfe30af8082b0f8f32027ec95d0`。14叶基线/现场字节一致；12叶与live快照字节一致，另外rollout-live.ts与passive-pieces.ts仅注释人名不同，精确diff另存base-live-comment-diff.patch。各叶最后源提交均为该live祖先，见source-receipts.json；源码只保存本批需要的14份.txt，不展开整仓库。
候选预测、护栏记录、SL资源比较、当前阶段/零毒说明、单动作回执已有接线。selection_dispatch明确state_effect_verified=false、whole_plan_executed=null、actual_turn=null，不代表跨重规划完整执行已认证。
monster-db当前按进阶取HP/招式且ROOM_COST_MIN_N=5；保留该门槛，不用当前刷新数据库充当旧运行输入。

已有窄源码祖先（仅说明其范围，不作本批新实现）：

- SL分段候选：`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`。
- 单动作回执：`fdaf787a372880b0438e73bcac7e6d2168b038ed`。
- SL资源比较：`1698adc96ba434a46942321e0237b70657e625b2`、沙坑补充`0e4fe4df89a06682468e0e4716c12126e76369d5`。
- 当前阶段毒事实：`aad2700abed6dff1d66e87fb36aaa6fedb39adf3`；阶段参考`1d57f9d0dbbb63603e9ce9768e74cb2021478464`。

## 同指纹配对实付代价

以下“净扣”是敌本体HP净差，可能含已结毒或其他来源，不当单牌直伤。完整fingerprint逐字相等；端点和原行SHA见paired-turns.json及状态封套。

| 局/层/回合 | 原线损血/净扣 | 替线损血/净扣 | 替线减原线 |
|---|---:|---:|---:|
| 8JRE1C4H4Z2W F33 T2 | 3/10 | 15/17 | +12/+7 |
| YF0LXT1QSTGG F48 T1 | 0/45 | 9/38 | +9/-7 |
| XP2SL33HT0D9 F33 T3 | 9/24 | 14/27 | +5/+3 |
| XP2SL33HT0D9 F33 T1 | 2/25 | 10/34 | +8/+9 |

只证明当轮成本，后续抽序/选择不同，没有独立整战因果。8J的0/24与5/24不同；XP的B2零胜也不覆盖21/24与23/24五轮死亡差别。

## 逐项处置及后续验证

## silent-proposal-c20b5139dd0dff71

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；原文SHA256：`bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c`，本批逐字节核同。
来源任务：experience-update；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0168。
证据：DUZUBAJ3A8GP / F27 / T4—T6。

states 274830—274838：火花3→6，污染6在次轮清除，T5三技能累计18；T4为49→46HP。既有毒、弱和挡收益必须保留。

反例及限制：技能的挡、毒收益同时存在，不能按污染代价禁用全部技能；没有另一线的受控完整胜局。

旧规则与本批处置：waiting。当前已有技能加污染、逐击计伤及火花增长路径。本批没有发现新的确定源码失配；尚未认证火花增长、污染清除、弱、毒、挡的完整生产联合重放，不能把局部接线判为整项duplicate，也不足以改成少打技能规则。

预期行为与验证：冻结实际手牌、现场火花/污染、A10移动输入和出牌前缀，逐动作核毒、挡、玩家血、敌本体血；仅有明确失配时修相应接线。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-ae9e692d680e3819

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；原文SHA256：`b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5`，本批逐字节核同。
来源任务：experience-update；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0183, silent-0005。
证据：5PM6JAQG6FNQ / F39 / 首试T4—T6、末试T4。

states 274351—274362：玩家力敏各−4，两步法后敏0，失落毒杀后力量回0，T6敏再到−2；274391—274397末试仍死亡。

反例及限制：步法取得不等于已正敏捷；毒杀一敌返力后仍可被另一敌打死，不支持固定杀序。

旧规则与本批处置：waiting。现帧负属性及POSSESS层数不足以恢复逐实体累计抢夺来源；缺遗忘退场返敏的完整本批后继和完整目标顺序对照。不能用失落一次返力推全套返还及固定杀序。

预期行为与验证：补足逐实体抢夺来源、退场、返还和后续重抢链；按实际来源核验累计返还，未知代际及来源保留未知。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-52f1e1bd2e7db0ed

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；原文SHA256：`651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376`，本批逐字节核同。
来源任务：experience-update；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0231。
证据：CA5KE8GFJ9X2 / F13 / T1—T5。

states 273237—273269：58上限、喷水11/15/19，力量0/4/8；T3弱后11、T5弱后14；轮初覆甲9/9/8/7/6。

反例及限制：覆甲层数变化没有隔离所有减层条件；只有一场失败不能给房间代价或必休血线拟新阈值。

旧规则与本批处置：waiting。当前已按进阶读取怪物数据且房间代价仍保留5样本门槛，另有覆甲路径；未发现新的确定源码失配。旧dirty运行输入不能由当前库冒充，尚无加压/覆甲/弱联合的完整生产重放认证或未观察减层条件的独立证据。

预期行为与验证：使用冻结的A10 HP/招式输入，从首样本读取数值，固定重放加压与弱的逐步变化；保持房间代价5样本门槛，不添加未观察覆甲条件。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-6dd8bbff876be528

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；原文SHA256：`48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5`，本批逐字节核同。
来源任务：experience-update；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0233, silent-0209。
证据：5PM6JAQG6FNQ / F38 / T3—T4。

states 274308—274317：23上限电击机器人T3力2/攻17，T4力4/攻19，T4内才退场；T3玩家61→31不能只计主怪13。

反例及限制：先杀爪牙的候选不是实打后继；同enemy_id、index或上限不构成跨召唤代际的唯一身份。

旧规则与本批处置：waiting。已有HIGH_VOLTAGE_POWER持续增长及新召唤初始化路径；原日志没有足以认证所有召唤代际的稳定身份，亦缺本次实际旧移动输入及另一目标顺序整战后继。两个增长端点不能认证整项重置与固定杀序。

预期行为与验证：按同一已观察实体连续核增长，并用新召唤者独立输入核初始化；缺唯一身份时不沿用旧实体计数，不给固定击杀序。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-578e415a259e6835

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；原文SHA256：`e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a`，本批逐字节核同。
来源任务：experience-update；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。
证据：8JRE1C4H4Z2W / F33 / 首试与三试T2、二试T5、末试T11。

decisions 270216/270282完整指纹相同；states 276208→276212及276274→276278：当轮损3/15、敌净扣10/17。270282五轮24样本原线0死、替线5死，二者不是同死率。270264候选省12血少18伤只为候选比较。

反例及限制：防御换线可省血但仍失败；候选没有完整派发时不能把预测保血记成实际收益；SL尝试不扩独立局分母。

旧规则与本批处置：waiting。已有Jev/护栏/SL分段候选及单动作派发回执，但缺完整续步归属、沙坑逐来源和路线资源链的联合认证；没有同抽序完整替线后继，不能关闭原审计宽请求或改护栏/探索参数。

预期行为与验证：核对Jev原答→护栏→SL→闸门实际动作→后继状态，抽牌/选择/生成/药水切断处标未完成；分别记录沙坑、毒、能力、净HP和路线资源。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-c0767768bf6a7ab1

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；原文SHA256：`28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb`，本批逐字节核同。
来源任务：postmortem；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0079。
证据：YF0LXT1QSTGG / F48 / 二试与三试T1、第四试T5；F33二试。

decisions 271309/271348同指纹；states 277327→277337与277366→277373：实损0/9、敌净扣45/38。271354实际结束回合；271348候选为损0/10、伤54/36，不能替代实际净值。

反例及限制：F33第二次SL实际通过；第四次T5的替换被弃牌重规划切断。F48失败不能推全部SL有害或候选全轮已执行。

旧规则与本批处置：waiting。当前单动作回执明确state_effect_verified=false、whole_plan_executed=null；尚缺完整候选执行及逐来源实际血价归属认证。没有同抽序完整替线及独立胜线，不拟惩罚系数或禁探索。

预期行为与验证：保持全败预测和当前血价分列，连后续实际状态认证执行前缀/未执行续步；不把单动作成功回应当成整轮完成。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-a46bdb7fe711d79a

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；原文SHA256：`eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6`，本批逐字节核同。
来源任务：postmortem；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0021, silent-0027, silent-0028, silent-0085。
证据：YF0LXT1QSTGG / F48 / 末试T3—T5。

states 277512→277513：111血阶段4HP/4毒→212血新阶段无旧毒/力；277518触媒2建立，277519仍零毒。277520/277523挡13→23，277526才敏5→6，277527敌197→160；18HP+23挡不足44，缺3。

反例及限制：前五次建立毒雾或余像仍失败；不能以零毒为唯一死因，也不能将后来敏捷倒补已得挡。

旧规则与本批处置：waiting。已有当前阶段快照、零毒说明及阶段参考，尚缺逐候选施毒、已结毒伤、额外扣血和敏捷取得顺序的完整执行归属。不能把当前快照或窄换相修复等同原宽请求完成，亦无新排序证据。

预期行为与验证：分当前阶段、持有组件、已建能力、现存毒、已结算/未来毒伤；以动作顺序核已有挡，验证抽弃牌后的候选截断，保持原排序。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-1044224808015e5c

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；原文SHA256：`4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5`，本批逐字节核同。
来源任务：postmortem；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0079。
证据：XP2SL33HT0D9 / F33 / 首/二试T3、首/末试T1、三试T4。

decisions 271992/272040同指纹，实损9/14、敌净扣24/27；271982/272195同指纹，实损2/10、敌净扣25/34。272076 B2均零胜但五轮死亡21/24→23/24，只是候选差额。

反例及限制：末试T2零损、T3损4，说明朝向/临减/抽弃牌共同影响；第三攻击带来的永久力量也不能抹去。

旧规则与本批处置：waiting。当轮血价已明确，缺同抽序完整替线、成长兑现的受控后继及独立整战胜线。多5血换3净扣、多8血换9净扣不能拟全局HP系数或证明新并列规则更好；本批保持原探索行为。

预期行为与验证：逐候选比较损血、净进度、成长和真实样本预算；如将来拟新并列规则，按独立run_id、时间后移验证，不将同存档尝试分到训练/验证两边。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-7cbc6005db712ba9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；原文SHA256：`f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291`，本批逐字节核同。
来源任务：postmortem；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。
证据：XP2SL33HT0D9 / F33 / 末试T2—T5。

states 278236—278242：轮初14挡、镣铐爪力0→−9后恢复；278249→278252→278253：火箭57→38→28；278254四敏、脆弱，末挡6。末T5为11HP/6挡/17攻击。

反例及限制：能力已建立仍无减员；既有挡、朝向、虚弱、直伤和已结毒是不同来源，不给固定能力/目标优先级。

旧规则与本批处置：waiting。当前已有相关机制与参考，尚未认证逐候选既有/新增挡、朝向/虚弱、已结毒和生存HP的统一来源及完整后继；不能用零散已实现机制冒称整项duplicate或新增出牌权重。

预期行为与验证：固定核57→38→28、14+6=20、0→−9→0，按现场已有挡和后来新增挡分账；未知条件保留未知，不改变权重。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## silent-proposal-c59f592f1427a67e

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；原文SHA256：`81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2`，本批逐字节核同。
来源任务：experience-update；本批实现任务：strategy-proposal / 20261017-214302-s2-strategy-proposal。
账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。
证据：YF0LXT1QSTGG / F48 / T1、末试T4—T5；XP2SL33HT0D9 / F33 / T1—T5。

合并读取上述YF与XP三组同指纹当轮净差和实际阶段/挡/毒/临减时序；全部明细保存在paired-turns.json与state-windows.json。

反例及限制：YF F33成功SL及护栏/防御换线的局部省血保留；两局末Boss各六试均是相关尝试，不能合成12个独立胜率样本。

旧规则与本批处置：waiting。已有候选与单动作分账，但逐来源资源账及完整候选执行归属尚未联合认证；缺路线、药水时机受控替线及独立整战后继。不能由部分字段存在关闭综合请求或更改资源规则。

预期行为与验证：复用原提案ID，统一串接候选/实际动作/资源变化及SL恢复来源；保留药水恢复、取得、消耗和SL重置的区分，不新拟路线或终局权重。

预期影响：让事实与真实执行可追溯；本批不宣称新的胜率、自然收益或大脑消费者验收。回退：本批无生产改动；后续如实施，只回退相应独立源码提交，保留原日志与CLI历史。

## 记录与执行结果

已通过根目录ledger.py update为30条关联既有账本追加本批proposal/report追溯；仅where/note/by，不追加支持/反例计数，不更改claim、首证、prior、status或version。无新学习claim，原有proposed/shipped状态保留，不因本批waiting倒退，也不登记本批shipped。CLI输入、输出和旧前缀哈希另存ledger-updates.jsonl、ledger-cli.log、ledger-append-verification.json。
十项队列处置交由调度器消费proposal_results，本批不手改队列或learn.json；code_proposals使用派发的真实原CLI ID，不新增重复ID。无规则实际上线，不触发双通知或发布编号。

生产源码撤除失败/恢复通过：不适用；tsc、Vitest、cases均null，未运行生产测试。证据SHA核验及数字复算不记生产测试成功。没有源码提交、合入提交、版本或回退动作。

过程失败保留：首次证据形状探查把非战斗combat=null当字典，TypeError后改为只看战斗帧；未改变证据。首次封套核验脚本误解析extract_evidence.py父路径，真实rc1日志envelope-verification.log保留，修正路径后v2真实rc0、8274行通过；不把初次失败覆盖成成功。原提案引用的部分旧验证文件未在原路径找到，本批直接从原日志重抽，未据此称证据不存在。未修改其他角色规则或知识。

最终HEAD、干净状态、完整JSON和产物SHA见final-check.json、result.json、artifact-manifest.json。报告与提案均位于本批ignored learner/runs目录，不制造文档提交。

import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path

OUT = Path(__file__).parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
receipts = []
for directory in ['evidence', 'evidence-runs']:
    manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
    for entry in manifest:
        path = OUT / directory / (entry['stream'] + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = Counter()
        with path.open('rb') as data, Path('/home/dw/Projects/agent-sts2/logs', entry['stream'] + '.jsonl').open('rb') as source:
            for encoded in data:
                digest.update(encoded)
                env = json.loads(encoded)
                assert env['offset'] + env['bytes'] <= entry['source_size']
                source.seek(env['offset'])
                raw = source.read(env['bytes'])
                assert raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == env['sha256']
                row = json.loads(raw)
                assert row == env['row']
                assert extract.run_identity(row) == env['run_id']
                counts[env['run_id']] += 1
        assert digest.hexdigest() == entry['output_sha256']
        assert {run: counts[run] for run in entry['counts']} == entry['counts']
        receipts.append({'directory': directory, 'stream': entry['stream'], 'rows': sum(counts.values()),
                         'counts': dict(counts), 'source_size': entry['source_size'],
                         'offset_bytes_sha_identity_verified': True, 'output_sha256': digest.hexdigest()})
(OUT / 'envelope-verification.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'streams': len(receipts), 'rows': sum(r['rows'] for r in receipts),
                  'verified': True}, ensure_ascii=False))

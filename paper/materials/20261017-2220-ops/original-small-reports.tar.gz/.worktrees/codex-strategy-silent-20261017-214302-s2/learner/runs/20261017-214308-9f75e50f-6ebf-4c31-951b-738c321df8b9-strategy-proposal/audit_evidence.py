import hashlib
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).parent
WINDOWS = {
    'DUZUBAJ3A8GP': {27: {4, 5, 6}},
    '5PM6JAQG6FNQ': {38: {3, 4}, 39: {4, 5, 6}},
    'CA5KE8GFJ9X2': {13: set(range(1, 7))},
    '8JRE1C4H4Z2W': {33: {1, 2, 3, 5, 6, 11}},
    'YF0LXT1QSTGG': {48: {1, 2, 3, 4, 5}},
    'XP2SL33HT0D9': {33: {1, 2, 3, 4, 5}},
}


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw or []}


def summarize(env, attempt):
    row = env['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'run': env['run_id'], 'line': env['line'], 'offset': env['offset'],
        'bytes': env['bytes'], 'sha256': env['sha256'], 'ts': row['ts'],
        'observed_ts': row.get('observed_ts'),
        'fingerprint_sha256': hashlib.sha256(row['fingerprint'].encode()).hexdigest(),
        'floor': (state.get('run') or {}).get('floor'), 'turn': state.get('turn'),
        'attempt': attempt, 'screen': state.get('screen'),
        'hp': player.get('current_hp'), 'block': player.get('block'),
        'energy': player.get('energy'), 'powers': powers(player.get('powers')),
        'cards_played': player.get('cards_played_this_turn'),
        'enemies': [{
            'index': e.get('index'), 'id': e.get('enemy_id'),
            'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
            'block': e.get('block'), 'alive': e.get('is_alive'),
            'powers': powers(e.get('powers')), 'move': e.get('move_id'),
            'intents': e.get('intents'),
        } for e in combat.get('enemies') or []],
    }


def main():
    records = []
    counts = Counter()
    last = {}
    attempts = Counter()
    with (OUT / 'evidence/states.evidence.jsonl').open() as stream:
        for line in stream:
            if not line.endswith('\n'):
                continue
            env = json.loads(line)
            state = env['row']['state']
            counts[env['run_id']] += 1
            assert (state.get('run') or {}).get('character_id', 'SILENT') == 'SILENT'
            floor = (state.get('run') or {}).get('floor')
            turn = state.get('turn')
            if floor not in WINDOWS[env['run_id']] or not state.get('combat') or not isinstance(turn, int) or turn < 1:
                continue
            key = (env['run_id'], floor)
            if key not in last or turn < last[key]:
                attempts[key] += 1
            last[key] = turn
            if turn in WINDOWS[env['run_id']][floor]:
                records.append(summarize(env, attempts[key]))
    (OUT / 'state-windows.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'state-counts.json').write_text(json.dumps(dict(counts), ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'states': dict(counts), 'windows': len(records),
                      'attempts': {str(k): v for k, v in attempts.items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()

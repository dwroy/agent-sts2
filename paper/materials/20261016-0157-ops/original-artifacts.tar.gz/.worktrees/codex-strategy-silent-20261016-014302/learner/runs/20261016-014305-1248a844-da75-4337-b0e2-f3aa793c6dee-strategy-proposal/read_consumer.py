import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH.parents[2]
dispatch = json.loads((SCRATCH / 'dispatch.json').read_text())
streams = {name: [json.loads(line) for line in (SCRATCH / 'evidence' / (name + '.evidence.jsonl')).open()]
           for name in ('states', 'decisions', 'runs')}
consumer = SCRATCH / 'consumer'
consumer.mkdir(exist_ok=True)
node_code = '''import { readFileSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import { auditSelectionExecution } from "./learner/lib/selection-execution.ts";
const input = JSON.parse(gunzipSync(readFileSync(process.argv[1])).toString("utf8"));
process.stdout.write(JSON.stringify(auditSelectionExecution(input)) + "\\n");'''
receipts = []
child_env = dict(os.environ)
child_env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + child_env.get('PATH', '')
child_env['TMPDIR'] = str(SCRATCH)

def execute(run, mode, input_data):
    target = consumer / (run + '.' + mode)
    compressed = gzip.compress(json.dumps(input_data, ensure_ascii=False).encode(), mtime=0)
    input_path = Path(str(target) + '.input.json.gz')
    input_path.write_bytes(compressed)
    output = Path(str(target) + '.output.json')
    error = Path(str(target) + '.stderr.txt')
    command = ['nice', '-n', '19', 'node', '--import', './agent/node_modules/tsx/dist/loader.mjs',
               '--input-type=module', '-e', node_code, str(input_path)]
    with output.open('wb') as stdout, error.open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=child_env, stdout=stdout, stderr=stderr)
    receipt = {'run_id': run, 'mode': mode, 'input': str(input_path), 'output': str(output),
               'stderr': str(error), 'exit_code': result.returncode,
               'input_sha256': hashlib.sha256(compressed).hexdigest(),
               'output_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
               'stderr_sha256': hashlib.sha256(error.read_bytes()).hexdigest(),
               'decisions': len(input_data['decisions']), 'states': len(input_data['states'])}
    if result.returncode == 0:
        decoded = json.loads(output.read_text())
        assert all(seg['actual_full_candidate_result'] is None for seg in decoded['segments'])
        receipt['segments'] = len(decoded['segments'])
        receipt['actual_full_candidate_result_certified'] = 0
        receipt['observed_actions'] = len(decoded['observed_actions'])
        receipt['observed_turns'] = len(decoded['observed_turns'])
    else:
        receipt['error'] = error.read_text()[-1600:]
    receipts.append(receipt)
    (consumer / 'receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
    return receipt

for run in dispatch['runs']:
    record = next(row['row'] for row in streams['runs'] if row['run_id'] == run)
    decisions = [{**row['row'], '_line': row['line']} for row in streams['decisions'] if row['run_id'] == run]
    states = [{**row['row'], '_line': row['line']} for row in streams['states'] if row['run_id'] == run]
    data = {'run': record, 'decisions': decisions, 'states': states}
    missing = [row['_line'] for row in decisions if not row.get('decision_id')]
    receipt = execute(run, 'complete', data)
    receipt['missing_decision_id_lines'] = missing
    if missing:
        assert receipt['exit_code'] != 0
        assert 'decision_id' in receipt['error']
        subset = {**data, 'decisions': [row for row in decisions if row.get('decision_id')]}
        bounded = execute(run, 'bounded', subset)
        bounded['excluded_lines'] = missing
        assert bounded['exit_code'] == 0
    else:
        assert receipt['exit_code'] == 0
    (consumer / 'receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
print(json.dumps([{'run_id': row['run_id'], 'mode': row['mode'], 'exit_code': row['exit_code'],
                   'decisions': row['decisions'], 'segments': row.get('segments'),
                   'excluded_lines': row.get('excluded_lines', row.get('missing_decision_id_lines', []))}
                  for row in receipts], ensure_ascii=False))

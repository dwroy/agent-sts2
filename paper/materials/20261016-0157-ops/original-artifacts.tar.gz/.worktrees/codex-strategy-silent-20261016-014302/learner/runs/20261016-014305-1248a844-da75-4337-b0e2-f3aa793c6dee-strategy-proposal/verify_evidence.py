import collections
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((SCRATCH / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
streams = {}
verification = []
for entry in manifest:
    name = entry['stream']
    path = SCRATCH / 'evidence' / (name + '.evidence.jsonl')
    encoded = path.read_bytes()
    assert hashlib.sha256(encoded).hexdigest() == entry['output_sha256']
    rows = [json.loads(line) for line in encoded.splitlines()]
    counts = collections.Counter()
    with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for row in rows:
            assert row['offset'] + row['bytes'] <= entry['source_size']
            source.seek(row['offset'])
            raw = source.read(row['bytes'])
            assert hashlib.sha256(raw).hexdigest() == row['sha256']
            decoded = json.loads(raw)
            assert decoded == row['row']
            assert extract.run_identity(decoded) == row['run_id'] in runs
            counts[row['run_id']] += 1
    assert all(counts[run] == entry['counts'][run] for run in runs)
    streams[name] = rows
    verification.append({'stream': name, 'verified_lines': len(rows), 'source_size': entry['source_size'],
                         'output_sha256': entry['output_sha256'], 'counts': entry['counts']})

def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

save('raw-verification.json', verification)
states = {row['line']: row['row']['state'] for row in streams['states']}
decisions = {row['line']: row['row'] for row in streams['decisions']}
windows = {'VLZ6CCT8AQ0A': {35, 36, 37, 43, 44, 45}, '8JRE1C4H4Z2W': {17, 33},
           'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 39}, '61E2QS63Y9WU': {17, 23},
           'DUZUBAJ3A8GP': {30}}

def ref(row):
    return {key: row[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}

def project_state(row):
    state = row['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    return {**ref(row), 'observed_ts': row['row']['observed_ts'], 'floor': run.get('floor'),
            'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
            'energy': player.get('energy'), 'block': player.get('block'), 'powers': player.get('powers'),
            'potions': run.get('potions'), 'deck_size': len(run.get('deck', [])),
            'deck_upgraded': sum(bool(card.get('upgraded')) for card in run.get('deck', [])),
            'hand': [{k: card.get(k) for k in ('card_id', 'index', 'upgraded', 'energy_cost', 'dynamic_values')}
                     for card in combat.get('hand', [])],
            'enemies': [{k: enemy.get(k) for k in ('enemy_id', 'index', 'current_hp', 'max_hp', 'block',
                                                   'is_alive', 'powers', 'intents', 'move_id')}
                        for enemy in combat.get('enemies', [])]}

def criteria(row):
    values = ((row.get('questions') or {}).get('plan') or {}).get('criteria') or {}
    return {key: json.loads(value) if isinstance(value, str) else value for key, value in values.items()}

def project_decision(row):
    raw = row['row']
    return {**ref(row), **{k: raw.get(k) for k in ('observed_ts', 'decision_id', 'floor', 'turn', 'label',
            'sl_attempt', 'sl_reloads', 'chosen', 'result', 'answers', 'journal', 'rationale', 'timing',
            'rollout', 'sl_explore', 'hp_guard')}, 'criteria': criteria(raw)}

selected_states = [project_state(row) for row in streams['states']
                   if (row['row']['state'].get('run') or {}).get('floor') in windows[row['run_id']]]
selected_decisions = [project_decision(row) for row in streams['decisions']
                      if row['row'].get('floor') in windows[row['run_id']]]
save('selected-states.json', selected_states)
save('selected-decisions.json', selected_decisions)
save('attempts.json', [{**ref(row), 'row': row['row']} for row in streams['sl-attempts']])

checks = []

def check(name, actual, expected, references):
    result = {'name': name, 'actual': actual, 'expected': expected, 'references': references,
              'passed': actual == expected}
    checks.append(result)
    save('fact-checks.json', checks)
    assert result['passed'], json.dumps(result, ensure_ascii=False)

def player(line):
    return states[line]['combat']['player']

def enemy(line, id=None):
    enemies = states[line]['combat']['enemies']
    return next(e for e in enemies if e['enemy_id'] == id) if id else enemies[0]

def power(subject, id):
    return next((p['amount'] for p in subject['powers'] if p['power_id'] == id), 0)

def damage(subject):
    return sum(i.get('total_damage') or 0 for i in subject['intents'])

def card(line, id):
    return next(card for card in states[line]['combat']['hand'] if card['card_id'] == id)

def value(line, id, name):
    return next(v['current_value'] for v in card(line, id)['dynamic_values'] if v['name'] == name)

def answer(line):
    row = decisions[line]
    return criteria(row)[row['answers']['plan']['choice']]

for row in streams['runs']:
    check(row['run_id'] + '角色进阶', [row['row']['character'], row['row']['ascension']], ['SILENT', 10],
          ['runs:' + str(row['line'])])
check('F35神化实付能量', [player(n)['energy'] for n in (275564, 275565)], [7, 5], ['states:275564/275565'])
for id, field, expected in [('DEFEND_SILENT', 'Block', [5, 8]), ('STRIKE_SILENT', 'Damage', [7, 10]),
                            ('DAGGER_SPRAY', 'Damage', [5, 7])]:
    check('F35' + id, [value(n, id, field) for n in (275564, 275565)], expected, ['states:275564/275565'])
check('F35工具费用', [card(n, 'TOOLS_OF_THE_TRADE')['energy_cost'] for n in (275564, 275565)], [1, 0], ['states:275564/275565'])
check('F35场外升级数', [sum(bool(c['upgraded']) for c in states[n]['run']['deck']) for n in (275564, 275565)], [1, 1], ['states:275564/275565'])
check('F43原答与重问预测', [[answer(n)['damage_dealt'], answer(n)['hp_lost']] for n in (269706, 269707)], [[43, 14], [51, 13]], ['decisions:269706/269707'])
check('F43后继净端点', [enemy(275679)['current_hp'] - enemy(275687)['current_hp'], player(275679)['current_hp'] - player(275687)['current_hp']], [51, 13], ['states:275679/275687'])
check('F43勒紧升级', [value(n, 'FASTEN', 'ExtraBlock') for n in (275679, 275680)], [4, 6], ['states:275679/275680'])
check('F43尖啸升级', [value(n, 'PIERCING_WAIL', 'StrengthLoss') for n in (275679, 275680)], [6, 8], ['states:275679/275680'])
check('F45预算退化', [decisions[269748]['timing']['mc_ms'], decisions[269748]['rollout']['horizon'], decisions[269748]['rollout']['samples'], decisions[269748]['rollout']['best']], [707, 1, 1, None], ['decisions:269748'])
check('F45未兑现神化', [power(player(275731), 'FASTEN_POWER'), power(player(275731), 'ACCELERANT_POWER'), card(275731, 'APOTHEOSIS')['upgraded'], len(states[275732]['combat']['hand'])], [4, 1, False, 0], ['states:275731/275732'])
check('F45T4当轮预测取舍', [answer(269770)['damage_dealt'], answer(269770)['hp_lost']], [24, 13], ['decisions:269770'])
check('8JRE同盘指纹', decisions[270216]['fingerprint'] == decisions[270282]['fingerprint'], True, ['decisions:270216/270282'])
check('8JRE同盘SL差价', [[criteria(decisions[270282])[k]['hp_lost'], criteria(decisions[270282])[k]['damage_dealt']] for k in ('plan1', 'plan2')], [[3, 10], [15, 17]], ['decisions:270282'])
check('8JRE末态HP', [player(n)['current_hp'] for n in (276433, 276434)], [5, 0], ['states:276433/276434'])
check('8JRE末态敌血', [enemy(n)['current_hp'] for n in (276433, 276434)], [154, 130], ['states:276433/276434'])
check('蚌当前力量', [power(enemy(n), 'STRENGTH_POWER') for n in (273237, 273252, 273263)], [0, 4, 8], ['states:273237/273252/273263'])
check('蚌当前攻击', [damage(enemy(n)) for n in (273237, 273252, 273263)], [11, 15, 19], ['states:273237/273252/273263'])
check('蚌虚弱后的攻击', damage(enemy(273268)), 14, ['states:273268'])
check('蚌死亡截断与显示参考', [player(273268)['current_hp'], player(273268)['block'], player(273269)['current_hp']], [2, 10, 0], ['states:273268/273269'])
check('族母吸取前后玩家', [[power(player(n), 'STRENGTH_POWER'), power(player(n), 'DEXTERITY_POWER')] for n in (273502, 273504)], [[2, 0], [0, -2]], ['states:273502/273504'])
check('族母吸取后敌力', power(enemy(273504), 'STRENGTH_POWER'), 2, ['states:273504'])
check('族母毒净端点', [enemy(n)['current_hp'] for n in (273504, 273508)], [67, 34], ['states:273504/273508'])
check('族母负敏捷双防御', [player(n)['block'] for n in (273504, 273505, 273506, 273507)], [0, 3, 3, 6], ['states:273504-273507'])
check('无毒冒泡实付', [player(n)['energy'] for n in (274379, 274380)], [5, 4], ['states:274379/274380', 'decisions:268455'])
check('无毒冒泡目标端点', [[enemy(n, 'THE_LOST')['current_hp'], power(enemy(n, 'THE_LOST'), 'POISON_POWER')] for n in (274379, 274380)], [[35, 0], [35, 0]], ['states:274379/274380'])
check('无毒冒泡未建立雾', power(player(274379), 'NOXIOUS_FUMES_POWER'), 0, ['states:274379'])
check('胧光召唤名单', [len(states[n]['combat']['enemies']) for n in (273577, 273583)], [1, 2], ['states:273577/273583'])
check('胧光成长', [power(enemy(n, 'THE_OBSCURA'), 'STRENGTH_POWER') for n in (273577, 273589, 273596)], [0, 3, 6], ['states:273577/273589/273596'])
check('幻象残血仍有攻击', [enemy(273596, 'PARAFRIGHT')['current_hp'], damage(enemy(273596, 'PARAFRIGHT'))], [2, 23], ['states:273596'])
check('甲虫睡眠层', [power(enemy(n, 'SLUMBERING_BEETLE'), 'SLUMBER_POWER') for n in (274906, 274914, 274919)], [3, 2, 1], ['states:274906/274914/274919'])
check('甲虫醒后攻击', [damage(enemy(n, 'SLUMBERING_BEETLE')) for n in (274923, 274929, 274934)], [18, 20, 22], ['states:274923/274929/274934'])
check('甲虫醒后力量', [power(enemy(n, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER') for n in (274923, 274929, 274934)], [0, 2, 4], ['states:274923/274929/274934'])
check('甲虫临时减力及恢复', [power(enemy(n, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER') for n in (274929, 274932, 274934)], [2, -4, 4], ['states:274929/274932/274934'])
check('甲虫临减不关闭成长', [damage(enemy(n, 'SLUMBERING_BEETLE')) for n in (274929, 274932, 274934)], [20, 14, 22], ['states:274929/274932/274934'])
check('甲虫四试结果分列', [r['row']['result'] for r in streams['sl-attempts'] if r['run_id'] == 'DUZUBAJ3A8GP' and r['row']['floor'] == 30], ['predicted_death', 'predicted_death', 'predicted_death', 'died'], ['sl-attempts:DUZUBAJ3A8GP/F30'])
summary = {'verified_lines': sum(len(rows) for rows in streams.values()), 'fact_checks': len(checks),
           'selected_states': len(selected_states), 'selected_decisions': len(selected_decisions)}
save('verification-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))

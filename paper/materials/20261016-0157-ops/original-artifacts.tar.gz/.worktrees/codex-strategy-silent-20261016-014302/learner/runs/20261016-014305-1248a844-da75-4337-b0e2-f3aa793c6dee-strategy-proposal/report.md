# 静默策略学习本批报告

本批 task=strategy-proposal；character=silent；batch=20261016-014302-strategy-proposal。
记录时间：2026-10-16T01:54:39+08:00。base=0a16b254ef91be2e7bab9bfc12a2a92d15f58028。本批独立完成，无下级agent。

本批仅处理派来的十个既有CLI id；没有新增提案id、源码或知识修改。每项保留waiting，现有窄实现不代替宽项验收。原提案Markdown字节SHA全部一致，原账本状态/claim/首证/版本和既有证据保持，不重复写历史复盘或新加相同证据。实际支持局只限本批六个SILENT/A10，SL相关尝试不增独立局数。


## 身份与授权范围

开工git status为空，HEAD=0a16b254ef91be2e7bab9bfc12a2a92d15f58028。已读README、STATE-2026-10-15、decision-log末尾、learning-protocol和learning-code-proposals。本批learn.json行task/character/worktree/runs/十proposal_ids一致，state=running、reason=proposal；无research_request、implementation_request或proposal_repair。普通专题请求绑定另一旧batch，本批不承接专题，不读其他专题代替身份。执行git merge --no-edit main返回Already up to date，base未变。

根dispatch.json只保存本批行；原提案逐项SHA核验见proposal-input-audit.json。26个关联账本全部silent，既有shipped不降级；后续仅CLI补本批追溯where/note，无新游戏结论或新反证需要通知。未读取其他角色私有知识，不运行对局、不调用LLM/网络、不改运行配置。未独立读取原生会话模型设置，不把任务正文当原生核验。

## 原始证据与限定结论

共用extract_evidence.py提取八流后，对6995条所属记录逐项按原offset/bytes/SHA256重新读回并核JSON及显式run身份；source_size与逐局计数、产物SHA见evidence/evidence-manifest.json和raw-verification.json。身份包括run_id/state.run_id/run/fingerprint.run，不使用正文提及。全源states/decisions各2行、brain1行无效JSON，不据此推断属于本六局；fight-plans本截点0行仅说明未选到，不断言原日志不存在。未覆盖或重写旧截点报告。

| 流 | source_size字节 | 所属行数 |
|---|---:|---:|
| states | 13241146130 | 3432 |
| decisions | 1727870452 | 3306 |
| sl-attempts | 41792493 | 29 |
| run-config | 1801780 | 6 |
| run-plans | 8262450 | 33 |
| brain | 618331628 | 183 |
| runs | 340320 | 6 |
| fight-plans | 2233957 | 0 |

本批六局原runs行均SILENT/A10、失败，运行版本均带dirty；提交号不足以还原当时完整源码、知识与随机池。只读本角色证据和适用的silent经验，不将经验宽进阶/历史支持数当本批新样本。

选取784个相关状态和759个决策投影，保留完整原行引用；43项固定材料断言通过（verification-expanded.log、fact-checks.json）。这是材料核验，不是生产tsc/vitest或撤源码负控。

- VLZ F35/F43神化已证配对、真实费用和场外deck不变可核；F43同序51伤/13损端点兑现。F45持有未施放，不将其记作升级效果反例或必打证明。
- VLZ F45首题MC707ms、horizon1/sample1/best=null，后续中位样本与真实抽牌分列；缺同预算随机池配对，不设新预算常量。F43胜后90→33、F44回血67是已付资源链，不能只分析末战。
- 8JRE F33首/第三试T2同盘，SL原/换线0/24与5/24预测不同，整轮玩家−3/−15、敌−10/−17，实付多12血多7敌净扣。第六试T11整轮敌166→130与最后结束回合154→130分开；实际玩家−5被零血截断，37攻击−22挡=15只是显示算式，不称完整实伤。
- CA5 F13蚌力量0/4/8、攻击11/15/19，虚弱后14；2血10挡实际截断扣2与完整需损4分开。不能预支未取得的正敏捷。
- 5PM F39末试T2无毒冒泡实际5→4能、目标35血/0毒保持；F33胜场组件建立是另一局面，不作为相同抽序启动因果对照。
- 61E F17吸取后力0/敏−2、双防御各3、毒敌67→34；该场首试赢，缺另一同盘SL全线。F23召唤和力0/3/6可核，幻象残2血仍有攻击，不能据本体伤害认证全体退场。
- DUZU F30睡3/2/1与醒后力0/2/4、攻击18/20/22可核；临减力2→−4→4、意图20→14→22。前三次predicted_death与末次died分开，四试不算四独立局。

## 当前离线消费者读回

复用当前基线learner/lib/selection-execution.ts，经node/tsx独立离线读取六局冻结gzip输入，无刷新知识或在线模型。输入保留真实decision_id、observed_ts、fingerprint与原日志_line，SHA及失败stderr保存consumer/receipts.json。

VLZ、8JRE、5PM完整输入实际接受；CA5原267143、61E原267517、DUZU原268789/268818/268864缺decision_id，完整输入返回1，错误为身份校验拒收。仅剔除这五行的bounded输入返回0，原行仍保留，行号缺口不重编号。不把这些有界结果说成完整局接受，也不把拒收当产品代码测试失败。

| 局号 | 输入范围 | 有ID动作 | 候选片段 | 相邻观测端点 | 整轮端点 | 未知轮窗 |
|---|---|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | complete | 699 | 99 | 77 | 10 | 97 |
| 8JRE1C4H4Z2W | complete | 659 | 113 | 264 | 44 | 67 |
| CA5KE8GFJ9X2 | bounded | 264 | 41 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | complete | 638 | 83 | 202 | 25 | 76 |
| 61E2QS63Y9WU | bounded | 442 | 63 | 127 | 14 | 59 |
| DUZUBAJ3A8GP | bounded | 599 | 77 | 189 | 28 | 68 |

合计3301有ID动作、476候选片段、859相邻端点、121整轮端点、413未知轮窗。全部actual_full_candidate_result仍为null，既不认证整候选，也不从null断言动作无收益或策略失败。8JRE整轮与终局端点读回见8JRE-turn-readback.json。旧日志缺持续身份与未选路线，单靠工具不能补造归属/因果。

## 已有实现与本次源码边界

只读live快照=cfa1c0be88147b4eac65c13d8c550b23ed4eef17。17个选定源码叶13个字节相同，card-model.ts、rollout-live.ts、sl/explore.ts、sl/judge.ts的4个差异为历史Roy/Dai注释；base/live SHA及原diff保存source-audit.json与base-live-leaf-diff.patch。没有把注释差异当新机制缺陷，也没有把Git祖先当dirty运行树还原。

已核实际base/live祖先：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化参考）、b2805be4ba44b7375c7908d873889372cc3cfe6c（已证萎靡升级）、ba23ca693151fa8c6f7fe035e640dc30f05ccd75（已证致命毒药升级）、05cd292c6f01bb31e406473d3a9843e659d62b93（三阶段快照）、a8b1f8be153fe4f3a34146117546c2178f2e446b（护栏/SL局部审计）、fdaf787a372880b0438e73bcac7e6d2168b038ed（单动作回执）、cf72bd21148059f111f760cc98a727369e34a47e（离线端点工具）。它们是旧窄实现来源，本批没有implemented_commit或duplicate整项声明。

本次源码检查确认cost已在已证神化差值传播字段内，不照抄旧waiting理由中的笼统“费用未传播”。当前actual_cast_this_fight=null，弱/脆弱/缩小/暗影/重放组合仍显式未验证；单动作回执whole_plan_executed=null，离线整候选结果仍留空。因此已有局部代码不足以关闭原宽提案。

## 逐项处置

| 原id | 结果 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 已有已证升级传播及参考字段；仍缺跨重问/选牌/药水/SL/换战的实际施放持续归属与未覆盖属性组合校准，不能认证整项完成。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺模型覆盖完整后的同起点、同随机池、同总预算配对及候选稳定性曲线；707ms和1/12局部样本不足以确定新预算或药水价格。 |
| silent-proposal-283a164780d11e69 | waiting | 与原神化提案共用证据，仍缺实际施放持续归属及未覆盖组合验证；现有窄live源码不等于该宽请求完整实现。 |
| silent-proposal-ebbfe3b97548756d | waiting | 本批可复核部分现场攻防/毒/临减端点；缺十五经验全部组合、状态期限以及战斗/路线/休息消费者的冻结联合校准。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有三阶段预测、单动作和整轮观测工具；仍缺跨重规划的持续候选归属、完整执行及成长分源，476片段均未认证完整候选结果。 |
| silent-proposal-49632bc4878fb597 | waiting | 蚌力量/喷水/虚弱端点已核；缺力量、正负敏捷、虚弱及独立成长四路径的冻结生产调用联合校准，本局无正敏捷实测。 |
| silent-proposal-66532328a585941f | waiting | 无毒冒泡局部耗能无效已核；缺同HP/构筑/药水/完整抽序下不同启动顺序的受控整战配对及可复现收益函数。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 已核吸取、双防御3挡和毒端点；缺A10同起始HP/构筑/药水/完整抽序下的可核SL整战配对，不能据首试胜利改SL规则。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 已有召唤窄实现及本批成长/残血威胁端点；缺A10逐实体召唤、复现、退场、成长全链的冻结联合调用和另一focus完整后继。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 已核倒计时、临减恢复及18/20/14/22意图；缺伤害唤醒/眩晕/恢复成长全链的冻结联合校准和同抽换序完整后继。 |

各项证据局/层/回合、账本id、反例、旧/预期行为、验证、样本/时间切分及回退均详见本目录proposal.md和proposal-dispositions.json。十个code_proposals均为已存在的CLI id，未新造id、不改原提案正文。implementation_domains=[]表示本批无实际新实现，不表示原提案领域为空。未来新局由原调度链重派，不在本任务等待未来事件。

## 检查、失败与交付口径

无源码/知识改动，无新提交或合入，fixes=[]、merged=null；不进入live锁/知识刷新/测试/版本流程，不空merge、不发号、不标shipped。撤源码失败/恢复通过不适用，tsc/vitest/cases固定为null；43材料断言和离线CLI返回码不替代生产测试。无对局行为变化，铁甲及其他角色保持原行为。

只经根ledger.py update追加26个相关silent条目的where.proposal及by=learner:strategy-proposal核验note；输入、stdout、前后读回另存本目录。保持原status/version/claim/first_run/asc/prior/evidence及旧历史，不重复证据、不将既有shipped降为proposed。队列proposal_results交既有完成消费者，不手改learn.json/专用队列或其他父请求。报告完成不等于学习入库、实际大脑采用或父要求关闭。

保留现场：源码定位最初猜测jev.ts/index.ts/controller.ts及learner/selection-execution.ts路径不存在，后用rg --files定位实际文件；一次宽输出被截断，后用限定投影读回。consumer-summary首版误按terminal.after统计为0，实际字段在terminal.facts.after；首版保存，最终按observed_terminal_endpoints修正。以上不作为产品故障、新反证或撤源码失败；三份完整输入的缺decision_id拒收及有界后续原件均保留。

临时材料仅存本批scratch，根目录仅有获准CLI账本追加；不提交过程脚本、不推送、不运行play、不停止对局。最终工作树/HEAD与追溯核验、gitleaks结果以同目录final-verification.json及日志为准。交运维proposal路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-014302/learner/runs/20261016-014305-1248a844-da75-4337-b0e2-f3aa793c6dee-strategy-proposal/proposal.md；report路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-014302/learner/runs/20261016-014305-1248a844-da75-4337-b0e2-f3aa793c6dee-strategy-proposal/report.md。

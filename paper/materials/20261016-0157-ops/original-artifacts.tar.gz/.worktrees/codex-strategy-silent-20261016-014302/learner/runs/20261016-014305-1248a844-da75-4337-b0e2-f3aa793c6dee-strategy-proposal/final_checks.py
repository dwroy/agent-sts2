import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
REPO = Path('/home/dw/Projects/agent-sts2')
updates = json.loads((S / 'ledger-updates.json').read_text())
before = json.loads((S / 'ledger-append-before.json').read_text())
prefix = json.loads((S / 'ledger-prefix.json').read_text())
spec = importlib.util.spec_from_file_location('ledger_cli', REPO / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
items = module.fold()
after = {id: items[id] for id in before}
protected = ('id', 'character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note',
             'prior_runs', 'status', 'version', 'shipped_at', 'evidence', 'effect')
for id, old in before.items():
    assert all(old.get(k) == after[id].get(k) for k in protected), id
    assert after[id]['history'][:len(old['history'])] == old['history'], id
    assert after[id]['notes'][:len(old['notes'])] == old['notes'], id
    assert all(all(v in after[id]['where'].get(k, []) for v in values) for k, values in old['where'].items()), id
    assert str(S / 'report.md') in after[id]['where']['proposal'], id
assert set((S / 'ledger-cli.log').read_text().split()) == set(before)
assert (S / 'ledger-cli.stderr.txt').stat().st_size == 0
ledger = REPO / 'paper/materials/learning/ledger.jsonl'
owned = []
by_id = {row['id']: row for row in updates}
with ledger.open('rb') as handle:
    assert hashlib.sha256(handle.read(prefix['source_size'])).hexdigest() == prefix['sha256']
    offset = prefix['source_size']
    for raw in handle:
        row = json.loads(raw)
        id = row.get('id')
        if id in by_id and row.get('by') == 'learner:strategy-proposal' and row.get('note') == by_id[id]['note']:
            assert {k: v for k, v in row.items() if k not in ('ts', 'op')} == by_id[id]
            owned.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        offset += len(raw)
assert len(owned) == len(updates) == 26
(S / 'ledger-owned-readback.json').write_text(json.dumps(owned, ensure_ascii=False, indent=2) + '\n')
(S / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
result = json.loads((S / 'result.json').read_text())
dispatch = json.loads((S / 'dispatch.json').read_text())
current = json.loads((REPO / 'ops/codex-ops/learn.json').read_text())['batches'][result['batch']]
for field in ('task', 'character', 'worktree', 'runs', 'proposal_ids'):
    assert current[field] == dispatch[field]
assert not any(field in current for field in ('research_request', 'implementation_request', 'proposal_repair'))
assert current['state'] == 'running'
assert set(result['code_proposals']) == set(dispatch['proposal_ids']) == {v['id'] for v in result['proposal_results']}
assert len(result['proposal_results']) == len(set(result['code_proposals'])) == 10
assert all(row['state'] == 'waiting' and row['reason'] for row in result['proposal_results'])
assert result['fixes'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['implementation_domains'] == []
assert Path(result['report']).is_file() and Path(result['report']).parent == S
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()
assert git('rev-parse', 'HEAD') == result['base']
assert git('status', '--porcelain=v1') == ''
assert git('diff', '--binary', 'HEAD') == ''
source = json.loads((S / 'source-audit.json').read_text())
for row in source['leaves']:
    if row['equal']:
        continue
    a = subprocess.check_output(['git', 'show', result['base'] + ':' + row['path']], cwd=ROOT)
    b = subprocess.check_output(['git', 'show', source['live'] + ':' + row['path']], cwd=ROOT)
    assert a.replace(b'Roy', b'Dai') == b.replace(b'Roy', b'Dai')
summary = {'at': datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
           'base': result['base'], 'head': git('rev-parse', 'HEAD'), 'worktree_clean': True,
           'proposal_results_complete': True, 'owned_ledger_updates': len(owned),
           'ledger_protected_fields_unchanged': True, 'old_ledger_prefix_unchanged': True,
           'raw_evidence_lines': 6995, 'material_assertions': 43, 'consumer_assertions': 2,
           'source_leaves_equal': 13, 'comment_only_different_leaves': 4,
           'tests': result['tests'], 'source_commit': None, 'merged': None, 'release_id': None,
           'gitleaks_exit_code': None}
(S / 'final-verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))

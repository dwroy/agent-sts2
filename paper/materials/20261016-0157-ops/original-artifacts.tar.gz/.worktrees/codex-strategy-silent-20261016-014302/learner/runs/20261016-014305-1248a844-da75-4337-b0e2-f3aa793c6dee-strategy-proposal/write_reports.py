import datetime
import json
from pathlib import Path

S = Path(__file__).resolve().parent
D = json.loads((S / 'dispatch.json').read_text())
P = json.loads((S / 'proposals-folded.json').read_text())
A = json.loads((S / 'source-audit.json').read_text())
V = json.loads((S / 'verification-summary.json').read_text())
M = json.loads((S / 'evidence/evidence-manifest.json').read_text())
C = json.loads((S / 'consumer-summary.json').read_text())
now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
items = [
    {'id': D['proposal_ids'][0], 'title': '神化传播与施放身份',
     'evidence': 'VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1。states275564→275565实付7→5能，防御5→8、打击7→10、匕首雨5→7、工具1→0费；states275679→275687同序端点扣51/损13。decisions269706/269707原预测43/14、重问51/13。',
     'counterexample': 'F43打出神化仍净损57；F45持有但未施放。跨场敌人、资源与牌序不同，不能证明必打或整战转胜。',
     'behavior': '现有已证普通版配对与cost差值传播保留。实际施放身份须由已核动作及本战范围证据建立，不能由持有或模拟apotheosisApplied代填；未知牌和未核属性组合继续unknown。',
     'reason': '已有已证升级传播及参考字段；仍缺跨重问/选牌/药水/SL/换战的实际施放持续归属与未覆盖属性组合校准，不能认证整项完成。',
     'validation': '冻结F35/F43/F45原帧和A10输入，核手牌/后抽/已升级幂等/场外deck不变；另核动作到施放身份的全链及跨战/SL边界。不得以模拟字段认证实打。'},
    {'id': D['proposal_ids'][1], 'title': '三骑士预算与即时血价',
     'evidence': 'VLZ6CCT8AQ0A A10 F45 T1/T4/T5；decisions269748的mc_ms=707、rollout horizon1/samples1/best=null，269754药水候选为12个中位样本；269770原选24伤/损13，与32伤/损31的未选候选区分。',
     'counterexample': '同局F17/F33首试赢；退化题不是完整必死推演。未实打的高伤候选不证明低伤线导致失败，药水中位抽牌不是实际到手牌。',
     'behavior': '保留当前预算、药价、护栏及目标选择；诊断中分列成熟度、原选、预测差和现场资源。拟改预算必须在同盘、同随机池及同总预算下比较。',
     'reason': '缺模型覆盖完整后的同起点、同随机池、同总预算配对及候选稳定性曲线；707ms和1/12局部样本不足以确定新预算或药水价格。',
     'validation': '先冻结模型及知识输入，再记录现行与分阶段MC的同池预算曲线、可比best/并列/缺覆盖；原六局只作发现/回归，独立后移局验证。'},
    {'id': D['proposal_ids'][2], 'title': '经验任务的同源神化补链',
     'evidence': '同上VLZ6CCT8AQ0A F35/F43/F45，经验silent-apotheosis-combat-upgrades；与89354805ee4d7e77共用silent-0237/0238及同一来源局，不增加独立样本。',
     'counterexample': 'F45 FASTEN_POWER4、ACCELERANT_POWER1，未施放神化；不能按持有升级组件预支战力。',
     'behavior': '沿原神化提案联合实现，经验链接保留；不新建重复id，不因题目同源就把尚未完成的宽项标duplicate。',
     'reason': '与原神化提案共用证据，仍缺实际施放持续归属及未覆盖组合验证；现有窄live源码不等于该宽请求完整实现。',
     'validation': '与原神化项同一组冻结夹具及边界，保留两来源任务/经验链接，去重实现且不重复计算支持局。'},
    {'id': D['proposal_ids'][3], 'title': '十五条机制及资源消费者联合校准',
     'evidence': 'VLZ6CCT8AQ0A A10 F43 T1—T5、F45 T1—T5，神化、属性、临减、毒、格挡逐源。F43勒紧4→6/尖啸6→8；F45未施放神化的普通能力与现场覆甲单独记录，F43→F44资源端点90→33→67。',
     'counterexample': '本局多场已胜战斗仍耗大量血量；F44实际回血到67后下一场仍败，不能拟合火堆/路线硬阈值。十五经验的历史宽进阶与支持数不是本批逐组合试验分母。',
     'behavior': '已有逐击力量、逐牌敏捷、临时减力、已建立能力与资源的窄路径保留；新缺口须用现场证据验证，不能把局部公式或整战相关性当完整联合实现。',
     'reason': '本批可复核部分现场攻防/毒/临减端点；缺十五经验全部组合、状态期限以及战斗/路线/休息消费者的冻结联合校准。',
     'validation': '按原经验分别冻结输入、期限、消费者与已观察进阶，不混用历史支持数；神化由专属项处理。缺联合覆盖时保持waiting，不由窄源码关闭宽父项。'},
    {'id': D['proposal_ids'][4], 'title': '原答、护栏、SL与真实执行审计',
     'evidence': '8JRE1C4H4Z2W A10 F33首/第三试T2，decisions270216/270282指纹相同，第三试SL原/替换预测3损10伤与15损17伤，rollout死数0/24与5/24；本批消费者整轮端点核玩家−3/−15、敌−10/−17。第二试T5 decisions270264原答16损43伤、护栏后4损25伤；第六试T11末端states276433/276434为5→0HP、敌154→130。',
     'counterexample': '第六试更长到T11仍败；原未选线无完整获胜反事实。T11整轮敌166→130净扣36与结束回合后154→130扣24属于不同窗口，不可混记。',
     'behavior': '沿现有三阶段快照、单动作派发、相邻及整轮端点审计，保留预测与实付分账；持久候选/施放归属尚不能用completed或端点净差替代。',
     'reason': '已有三阶段预测、单动作和整轮观测工具；仍缺跨重规划的持续候选归属、完整执行及成长分源，476片段均未认证完整候选结果。',
     'validation': '同起点保存原答/护栏/SL/派发及每次重问，核本局首/三试T2、第二试T5和末T11；截断、净HP、显示攻击参考分别留存，后置独立局才能校准新规则。'},
    {'id': D['proposal_ids'][5], 'title': '当前力量、敏捷、虚弱与独立成长',
     'evidence': 'CA5KE8GFJ9X2 A10 F13 T1/T3/T5，states273237/273252/273263蚌力0/4/8、喷水11/15/19；273268虚弱后14，玩家2血10挡，273269实际0HP。',
     'counterexample': '虚弱未关闭后续加压；本局没有正敏捷建立证据。显示14−10=4的完整需求与实际截断扣2不同；计划中的步法不能补作已取得。',
     'behavior': '四路径分别按实际属性与状态期限核验，保留现有输出/保血权重；不因蚌的单独成长验证就宣称正负敏捷和力量组合均已校准。',
     'reason': '蚌力量/喷水/虚弱端点已核；缺力量、正负敏捷、虚弱及独立成长四路径的冻结生产调用联合校准，本局无正敏捷实测。',
     'validation': '冻结已观察进阶敌人数据及原手牌/前缀，分别比较四路径；能借本批其他局核负敏捷事实，但不能冒称CA5同局正敏捷或完整联合调用已验证。'},
    {'id': D['proposal_ids'][6], 'title': '构筑持有与组件实际启动',
     'evidence': '5PM6JAQG6FNQ A10 F39第二/末试T2，decisions268455、states274379/274380：冒泡目标THE_LOST35血/0毒保持，能量5→4，玩家未建立NOXIOUS_FUMES_POWER。同局F33首试胜利是另一盘面。',
     'counterexample': '同局F33建立组件后赢，但敌人、血量、牌序与资源一起变化；F39首试后续也有雾建立，不能把末试未建立说成全局从未建立。',
     'behavior': '持有、计划、已付费、已建立及后续兑现分账；不从单次空打引入固定能力优先级、启动血价或构筑权重。',
     'reason': '无毒冒泡局部耗能无效已核；缺同HP/构筑/药水/完整抽序下不同启动顺序的受控整战配对及可复现收益函数。',
     'validation': '冻结原局面与全抽序后比较启动次序、费用和可活窗口，按run_id分组；同局F33/F39不是控制变量配对。'},
    {'id': D['proposal_ids'][7], 'title': '族母吸取、负敏捷与毒的SL边界',
     'evidence': '61E2QS63Y9WU A10 F17 T5/T6/T7，states273502→273504玩家力2→0、敏0→−2，敌力0→2；273504—273507双防御各加3，毒后继敌67→34。sl-attempts本场attempt1结果won。',
     'counterexample': '本场首试获胜，不支持“同抽重打固定顺序导致必败”；出场与开场治疗/资源变化分开，单一牌或毒端点不代表全部整战收益。',
     'behavior': '保留吸取、负敏捷牌挡与毒来源分账，SL范围及阈值保持；原首试胜利不能替代另一同盘SL路径。',
     'reason': '已核吸取、双防御3挡和毒端点；缺A10同起始HP/构筑/药水/完整抽序下的可核SL整战配对，不能据首试胜利改SL规则。',
     'validation': '冻结F17完整已知抽序、状态、药水及资源，逐段核吸取/毒/挡；改变SL或换线偏好须另外的完整可比路径及独立留出。'},
    {'id': D['proposal_ids'][8], 'title': '胧光召唤、成长与实际退场',
     'evidence': '61E2QS63Y9WU A10 F23 T1—T5；states273577/273583一敌→两敌，273589/273596主体力3→6；T5幻象仍2血并有23攻击，尚未退场。原T4本体候选47伤/损15与另39伤/0损候选分列。',
     'counterexample': '另一个focus候选未实打，不能称整战胜线；enemy_id是类型，不足单独认证召唤、复现的物理实体。',
     'behavior': '保留目标选项，相同推演值并列；按主体/幻象各自现场血量、意图与成长核验，不按累计总伤替代退场，也不强制首杀。',
     'reason': '已有召唤窄实现及本批成长/残血威胁端点；缺A10逐实体召唤、复现、退场、成长全链的冻结联合调用和另一focus完整后继。',
     'validation': '冻结当前进阶脚本、原前缀与召唤/复现/退场链，比较各实体HP和意图；端点相同不认证稳定实例或目标排序整战收益。'},
    {'id': D['proposal_ids'][9], 'title': '熟睡甲虫唤醒与临减恢复成长',
     'evidence': 'DUZUBAJ3A8GP A10 F30 T1—T6；states274906/274914/274919睡3/2/1，274923/274929/274934攻击18/20/22；274929→274932→274934力量2→−4→4、攻击20→14→22。四次尝试前三predicted_death、末次died。',
     'counterexample': '四次属同一局；前三预测截断不是四次都实际受完整攻击死亡。末次T4敌血更低同时玩家血损更大，不能据敌血单独选新杀序。',
     'behavior': '倒计时、伤害唤醒、眩晕、成长及临减恢复分别验证，按本进阶现场数据推演；不把未知换线胜率写成确定规则。',
     'reason': '已核倒计时、临减恢复及18/20/14/22意图；缺伤害唤醒/眩晕/恢复成长全链的冻结联合校准和同抽换序完整后继。',
     'validation': '冻结本场各尝试手牌、进阶、状态和抽序，区分自然醒与伤害触发，再核眩晕及成长接续；全败相关样本不拟合新血价常数。'},
]
assert [item['id'] for item in items] == D['proposal_ids']
for item in items:
    item['state'] = 'waiting'
    item['ledger'] = P[item['id']]['ledger']
    item['runs'] = P[item['id']]['runs']
(S / 'proposal-dispositions.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')

common = f'''本批 task=strategy-proposal；character=silent；batch=20261016-014302-strategy-proposal。
记录时间：{now}。base={A['base']}。本批独立完成，无下级agent。

本批仅处理派来的十个既有CLI id；没有新增提案id、源码或知识修改。每项保留waiting，现有窄实现不代替宽项验收。原提案Markdown字节SHA全部一致，原账本状态/claim/首证/版本和既有证据保持，不重复写历史复盘或新加相同证据。实际支持局只限本批六个SILENT/A10，SL相关尝试不增独立局数。
'''
proposal = '# 静默策略提案逐项核验与处置\n\n' + common
for item in items:
    proposal += f'''\n## {item['id']}：{item['title']}

- 来源：{P[item['id']]['source_task']} → strategy-proposal；原文件：{P[item['id']]['proposal']}。
- 账本：{'、'.join(item['ledger'])}。原授权Roy-2026-10-07-learning仅提供权限，不提供游戏事实。
- 已核证据：{item['evidence']}
- 反例与限制：{item['counterexample']}
- 现有/预期行为：{item['behavior']}
- 本次处置：waiting；{item['reason']}
- 后续验证：{item['validation']}
- 拟合与切分：不拟合新常量。六局已有历史用途，本次为发现样本回归；未来独立局按时间后移及进阶分层，不将同局SL当留出。
- 预期影响与回退：本批对局行为不变；无新源码可回退。未来实现须用固定夹具验证真实缺口，撤源码失败/恢复通过、原沙箱检查后再按live流程上线并保留原记录。
'''
(S / 'proposal.md').write_text(proposal)

stream_table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} |" for m in M)
consumer_table = '\n'.join(f"| {r['run_id']} | {r['mode']} | {r['actions']} | {r['segments']} | {r['observed_intervals']} | {r['turn_statuses'].get('observed_turn_endpoints', 0)} | {r['turn_statuses'].get('unknown', 0)} |" for r in C)
disposition_table = '\n'.join(f"| {item['id']} | waiting | {item['reason']} |" for item in items)
report = f'''# 静默策略学习本批报告

{common}

## 身份与授权范围

开工git status为空，HEAD={A['base']}。已读README、STATE-2026-10-15、decision-log末尾、learning-protocol和learning-code-proposals。本批learn.json行task/character/worktree/runs/十proposal_ids一致，state=running、reason=proposal；无research_request、implementation_request或proposal_repair。普通专题请求绑定另一旧batch，本批不承接专题，不读其他专题代替身份。执行git merge --no-edit main返回Already up to date，base未变。

根dispatch.json只保存本批行；原提案逐项SHA核验见proposal-input-audit.json。26个关联账本全部silent，既有shipped不降级；后续仅CLI补本批追溯where/note，无新游戏结论或新反证需要通知。未读取其他角色私有知识，不运行对局、不调用LLM/网络、不改运行配置。未独立读取原生会话模型设置，不把任务正文当原生核验。

## 原始证据与限定结论

共用extract_evidence.py提取八流后，对{V['verified_lines']}条所属记录逐项按原offset/bytes/SHA256重新读回并核JSON及显式run身份；source_size与逐局计数、产物SHA见evidence/evidence-manifest.json和raw-verification.json。身份包括run_id/state.run_id/run/fingerprint.run，不使用正文提及。全源states/decisions各2行、brain1行无效JSON，不据此推断属于本六局；fight-plans本截点0行仅说明未选到，不断言原日志不存在。未覆盖或重写旧截点报告。

| 流 | source_size字节 | 所属行数 |
|---|---:|---:|
{stream_table}

本批六局原runs行均SILENT/A10、失败，运行版本均带dirty；提交号不足以还原当时完整源码、知识与随机池。只读本角色证据和适用的silent经验，不将经验宽进阶/历史支持数当本批新样本。

选取{V['selected_states']}个相关状态和{V['selected_decisions']}个决策投影，保留完整原行引用；{V['fact_checks']}项固定材料断言通过（verification-expanded.log、fact-checks.json）。这是材料核验，不是生产tsc/vitest或撤源码负控。

- VLZ F35/F43神化已证配对、真实费用和场外deck不变可核；F43同序51伤/13损端点兑现。F45持有未施放，不将其记作升级效果反例或必打证明。
- VLZ F45首题MC707ms、horizon1/sample1/best=null，后续中位样本与真实抽牌分列；缺同预算随机池配对，不设新预算常量。F43胜后90→33、F44回血67是已付资源链，不能只分析末战。
- 8JRE F33首/第三试T2同盘，SL原/换线0/24与5/24预测不同，整轮玩家−3/−15、敌−10/−17，实付多12血多7敌净扣。第六试T11整轮敌166→130与最后结束回合154→130分开；实际玩家−5被零血截断，37攻击−22挡=15只是显示算式，不称完整实伤。
- CA5 F13蚌力量0/4/8、攻击11/15/19，虚弱后14；2血10挡实际截断扣2与完整需损4分开。不能预支未取得的正敏捷。
- 5PM F39末试T2无毒冒泡实际5→4能、目标35血/0毒保持；F33胜场组件建立是另一局面，不作为相同抽序启动因果对照。
- 61E F17吸取后力0/敏−2、双防御各3、毒敌67→34；该场首试赢，缺另一同盘SL全线。F23召唤和力0/3/6可核，幻象残2血仍有攻击，不能据本体伤害认证全体退场。
- DUZU F30睡3/2/1与醒后力0/2/4、攻击18/20/22可核；临减力2→−4→4、意图20→14→22。前三次predicted_death与末次died分开，四试不算四独立局。

## 当前离线消费者读回

复用当前基线learner/lib/selection-execution.ts，经node/tsx独立离线读取六局冻结gzip输入，无刷新知识或在线模型。输入保留真实decision_id、observed_ts、fingerprint与原日志_line，SHA及失败stderr保存consumer/receipts.json。

VLZ、8JRE、5PM完整输入实际接受；CA5原267143、61E原267517、DUZU原268789/268818/268864缺decision_id，完整输入返回1，错误为身份校验拒收。仅剔除这五行的bounded输入返回0，原行仍保留，行号缺口不重编号。不把这些有界结果说成完整局接受，也不把拒收当产品代码测试失败。

| 局号 | 输入范围 | 有ID动作 | 候选片段 | 相邻观测端点 | 整轮端点 | 未知轮窗 |
|---|---|---:|---:|---:|---:|---:|
{consumer_table}

合计3301有ID动作、476候选片段、859相邻端点、121整轮端点、413未知轮窗。全部actual_full_candidate_result仍为null，既不认证整候选，也不从null断言动作无收益或策略失败。8JRE整轮与终局端点读回见8JRE-turn-readback.json。旧日志缺持续身份与未选路线，单靠工具不能补造归属/因果。

## 已有实现与本次源码边界

只读live快照={A['live']}。17个选定源码叶13个字节相同，card-model.ts、rollout-live.ts、sl/explore.ts、sl/judge.ts的4个差异为历史Roy/Dai注释；base/live SHA及原diff保存source-audit.json与base-live-leaf-diff.patch。没有把注释差异当新机制缺陷，也没有把Git祖先当dirty运行树还原。

已核实际base/live祖先：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化参考）、b2805be4ba44b7375c7908d873889372cc3cfe6c（已证萎靡升级）、ba23ca693151fa8c6f7fe035e640dc30f05ccd75（已证致命毒药升级）、05cd292c6f01bb31e406473d3a9843e659d62b93（三阶段快照）、a8b1f8be153fe4f3a34146117546c2178f2e446b（护栏/SL局部审计）、fdaf787a372880b0438e73bcac7e6d2168b038ed（单动作回执）、cf72bd21148059f111f760cc98a727369e34a47e（离线端点工具）。它们是旧窄实现来源，本批没有implemented_commit或duplicate整项声明。

本次源码检查确认cost已在已证神化差值传播字段内，不照抄旧waiting理由中的笼统“费用未传播”。当前actual_cast_this_fight=null，弱/脆弱/缩小/暗影/重放组合仍显式未验证；单动作回执whole_plan_executed=null，离线整候选结果仍留空。因此已有局部代码不足以关闭原宽提案。

## 逐项处置

| 原id | 结果 | 具体缺口 |
|---|---|---|
{disposition_table}

各项证据局/层/回合、账本id、反例、旧/预期行为、验证、样本/时间切分及回退均详见本目录proposal.md和proposal-dispositions.json。十个code_proposals均为已存在的CLI id，未新造id、不改原提案正文。implementation_domains=[]表示本批无实际新实现，不表示原提案领域为空。未来新局由原调度链重派，不在本任务等待未来事件。

## 检查、失败与交付口径

无源码/知识改动，无新提交或合入，fixes=[]、merged=null；不进入live锁/知识刷新/测试/版本流程，不空merge、不发号、不标shipped。撤源码失败/恢复通过不适用，tsc/vitest/cases固定为null；43材料断言和离线CLI返回码不替代生产测试。无对局行为变化，铁甲及其他角色保持原行为。

只经根ledger.py update追加26个相关silent条目的where.proposal及by=learner:strategy-proposal核验note；输入、stdout、前后读回另存本目录。保持原status/version/claim/first_run/asc/prior/evidence及旧历史，不重复证据、不将既有shipped降为proposed。队列proposal_results交既有完成消费者，不手改learn.json/专用队列或其他父请求。报告完成不等于学习入库、实际大脑采用或父要求关闭。

保留现场：源码定位最初猜测jev.ts/index.ts/controller.ts及learner/selection-execution.ts路径不存在，后用rg --files定位实际文件；一次宽输出被截断，后用限定投影读回。consumer-summary首版误按terminal.after统计为0，实际字段在terminal.facts.after；首版保存，最终按observed_terminal_endpoints修正。以上不作为产品故障、新反证或撤源码失败；三份完整输入的缺decision_id拒收及有界后续原件均保留。

临时材料仅存本批scratch，根目录仅有获准CLI账本追加；不提交过程脚本、不推送、不运行play、不停止对局。最终工作树/HEAD与追溯核验、gitleaks结果以同目录final-verification.json及日志为准。交运维proposal路径：{S / 'proposal.md'}；report路径：{S / 'report.md'}。
'''
(S / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-014302-strategy-proposal',
          'base': A['base'], 'runs': D['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': D['proposal_ids'],
          'implementation_domains': [], 'proposal_results': [{'id': item['id'], 'state': 'waiting', 'reason': item['reason']} for item in items],
          'report': str(S / 'report.md')}
(S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
ids = sorted({id for item in items for id in item['ledger']})
updates = [{'id': id, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
            'note': f"本批20261016-014302-strategy-proposal仅复核既有提案：6995条所属原字节/身份核、43项材料断言；六局限定离线读回及十项waiting详见报告。只追加追溯，不重复证据或改变原claim/status/version/首证；无新源码、合入、版本或shipped。相关原提案：{'、'.join(item['id'] for item in items if id in item['ledger'])}。"}
           for id in ids]
(S / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'proposal': str(S / 'proposal.md'), 'proposal_results': len(items), 'ledger_updates_prepared': len(updates)}, ensure_ascii=False))

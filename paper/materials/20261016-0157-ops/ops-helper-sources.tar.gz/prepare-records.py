from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,tarfile

root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0157';pub=root/'paper/materials/20261016-0157-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-014302-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent;out=root/'ops/codex-ops/learner'/(bid+'.out');output=out.read_text()
assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'result.json');assert {k:v for k,v in scratch.items() if k!='proposal_results'}=={k:v for k,v in report.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in scratch['proposal_results']]==[(x['id'],x['state']) for x in report['proposal_results']]
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
final=load(s/'final-verification.json');assert final['head']==final['base']==report['base'] and final['worktree_clean'] and final['proposal_results_complete'] and final['owned_ledger_updates']==26 and final['ledger_protected_fields_unchanged'] and final['old_ledger_prefix_unchanged']
assert final['raw_evidence_lines']==6995 and final['material_assertions']==43 and final['consumer_assertions']==2 and final['source_commit'] is final['merged'] is final['release_id'] is None
assert sha((s/'report.md').read_bytes())==final['report_sha256'] and sha((s/'proposal.md').read_bytes())==final['proposal_sha256'] and final['gitleaks_exit_code']==0 and load(s/'gitleaks.json')==[]
proposals=load(s/'proposal-input-audit.json');assert {x['id'] for x in proposals}==set(report['code_proposals'])
for x in proposals:
    f=Path(x['path']);assert f.resolve().is_relative_to(root) and sha(f.read_bytes())==x['sha256'] and x['matches'] and x['exists']
verification=load(s/'raw-verification.json');assert sum(x['verified_lines'] for x in verification)==6995
for row in verification:assert sha((s/'evidence'/(row['stream']+'.evidence.jsonl')).read_bytes())==row['output_sha256']
facts=load(s/'fact-checks.json');consumer_facts=load(s/'consumer-fact-checks.json');assert len(facts)==43 and len(consumer_facts)==2 and all(x['passed'] and x['actual']==x['expected'] for x in facts+consumer_facts)
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['leaves'])==17
for x in source['leaves']:
    a=git('show',report['base']+':'+x['path']);z=git('show',source['live']+':'+x['path']);assert sha(a)==x['base_sha256'] and sha(z)==x['live_sha256'] and (a==z)==x['equal'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['equal'] for x in source['leaves'])==13
for x in source['commits']:
    assert x['base_ancestor'] and x['live_ancestor'];git('merge-base','--is-ancestor',x['commit'],report['base']);git('merge-base','--is-ancestor',x['commit'],source['live'])
consumers=load(s/'consumer/receipts.json');assert len(consumers)==9 and sum(x['exit_code']==0 for x in consumers)==6 and sum(x['exit_code']==1 for x in consumers)==3
for x in consumers:
    for path,key in [('input','input_sha256'),('output','output_sha256'),('stderr','stderr_sha256')]:
        f=Path(x[path]);assert f.resolve().is_relative_to(s) and sha(f.read_bytes())==x[key]
    if x['exit_code']==1:assert x['mode']=='complete' and 'decision_id' in Path(x['stderr']).read_text()
summary=load(s/'consumer-summary.json');assert len(summary)==6 and sum(x['mode']=='complete' for x in summary)==sum(x['mode']=='bounded' for x in summary)==3
totals={key:sum(x[key] for x in summary) for key in ['actions','segments','observed_intervals','full_candidate_certified']};totals.update(observed_turns=sum(x['turn_statuses'].get('observed_turn_endpoints',0) for x in summary),unknown_turns=sum(x['turn_statuses'].get('unknown',0) for x in summary))
assert totals==dict(actions=3301,segments=476,observed_intervals=859,full_candidate_certified=0,observed_turns=121,unknown_turns=413)
inputs=load(s/'ledger-updates.json');rows=load(s/'ledger-owned-readback.json');assert len(inputs)==len(rows)==26 and set((s/'ledger-cli.log').read_text().split())=={x['id'] for x in inputs}
ledger=root/'paper/materials/learning/ledger.jsonl';own=[]
for entry in rows:
    with ledger.open('rb') as handle:handle.seek(entry['offset']);raw=handle.read(entry['bytes'])
    row=json.loads(raw);assert sha(raw)==entry['sha256'] and row==entry['row'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs);own.append(raw)
old=git('show',base+':paper/materials/learning/ledger.jsonl');existing=set(old.splitlines());assert len(set(own))==26 and all(raw.rstrip(b'\n') not in existing for raw in own);added=b''.join(own)
spec=importlib.util.spec_from_file_location('owned_ledger',root/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,items in a[ident]['where'].items():assert all(x in z[ident]['where'][key] for x in items)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree'])
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_scratch_result=scratch,original_gate=b['no_change_proposals'],native=native,completion=final,source=source,evidence_output_shas_verified=True,original_rows=6995,original_material_assertions=43,original_consumer_assertions=2,original_consumer_receipts=consumers,original_consumer_summary=summary,consumer_totals=totals,consumer_not_reexecuted=True,owned_trace_rows=26,protected_fields_and_old_prefixes_preserved=True,limits=['Historical dirty Silent A10 runs do not reconstruct consumed source/knowledge/random pools; same-run SL does not add independent samples.','Three complete inputs rejected missing decision IDs. Subsequent bounded inputs exclude only the five identified metadata rows without renumbering; they are not full-run acceptance.','All full-candidate results remain null. Adjacent and turn/terminal endpoints do not establish stable cross-question cast/candidate attribution or full controlled successors.','Cost is already included in the observed Apotheosis delta propagation; old generic missing-cost wording is not repeated. Actual cast persistence and unobserved modifier combinations remain unresolved.','Original consumer-summary-v1 terminal schema mistake and path/truncated-output probes are preserved; no new mechanism counterevidence, source/test failure, budget/price or wide-parent completion is claimed.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',s/'consumer/receipts.json',out,out.with_suffix('.err')]
    for f in sorted(files):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0157原014302策略done0/no-source处置核，0a16干净WT/HEAD不变、十waiting具体缺口/testsnull/域空/mergednull保持，无提交或合入阻塞，不空合/发号/补测。六Silent A10八流6995材料行产物SHA及43材料/2消费者断言核，不重跑或当生产测试；九原离线请求输入输出stderr SHA核，三完整输入原rc1缺decision_id拒收及剔五元数据后的bounded rc0原件并存，最终3complete/3bounded共3301动作/476段/859相邻端点/121整轮端点/413未知，完整候选认证0，不把有界接受冒完整局。17源码叶13同4历史Roy-Dai注释差及七旧来源main/live祖先核；已证神化费用已在传播字段，旧笼统缺cost理由不复用，实际施放持续归属/未覆盖组合与同输入同预算整战仍缺，不按707ms或1/12设新预算药价。26所属CLI纯where/note按输入/输出ID/offset/bytes/SHA及私有fold核，旧claim/首证/prior/证据/状态/版本和history/notes/where保、不重复CLI或降级shipped；原summary-v1误读terminal字段及原路径/截断探针保，不当产品故障或新反证。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network与原未独立核原生说明分列；历史dirty消费/受控替线与完整成长归属未知保。仅本人记录/追溯提交，保并行脏记录；无新源码/知识/版本/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261016-0157-ops/。\n'
note=f'\n- {at} [运维 codex] 原014302策略十项继续waiting，无源码变更或合入受阻；43项材料检查与2项离线消费者断言分列，完整输入缺ID拒收及后续有界结果均保留，生产tests仍null。26所属追溯已核，宽父不关闭。回执paper/materials/20261016-0157-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=26,protected_fields_preserved=True,no_new_source_tests_merge_or_release=True,wide_parents='remain open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,owned_trace_rows=26,ledger_check=0,paths=len(entries))))

import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'proposals.snapshot.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
audit = json.loads((OUT / 'evidence-audit.json').read_text())
created = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()

SPECS = {
    '0b8ef30de463f317': (
        'ZTRGYYMLR8SC A10 F6T3/F11T1/F14T1/F17六试；末试F17T2 s292343→292344、T14 s292396—292402。',
        '末试7牌挡和7覆甲分列，T2实损4、次轮覆甲6；同局17次饮药请求含SL恢复后的重复饮用。',
        '已有覆甲、药槽端点和饮药请求记录；当前消费者的来源因果字段仍为null，不以药栏消失自动分类。',
        '缺新获/实饮/弃用/SL恢复至消费者的完整联合归属，以及同资源晚饮或留药的整战对照；现有覆甲路径不重复修改。',
        '两瓶原药的每次恢复单列，建立覆甲与即时牌挡分列；持有价加载缺数据明确未知，不从0回退拟合新药价。',
        '以已核药槽、显式动作、SL事件和出口做守恒核对，完整字段接入须固定原帧消费者；时点规则需同条件后继和时间留出。'),
    '5367449b857450a7': (
        'ZTRGYYMLR8SC A10 F11T1 d285287—285294、F17末T5/T14；1LMBFGSMCWKU A4、9YT51CK8RC39 A7及其余四个原提案A10来源分列。',
        '末T14 s292398→292399神官64→61是弃牌后附伤，后中和才到58；刀扇本局是单敌和手位约束观察。',
        '现有攻击、牌挡、覆甲与临时能力路径已有覆盖，弃牌附伤观测工具已有；不把所有机制描述为未建模。',
        '原七局单弃和本局单敌刀扇不足认证多敌随机分配、混合修饰及完整后继；后续经验所提单敌多弃摘要未在本批核原帧，不能代替消费者校准。',
        '仅按现场力/弱/敏/脆弱和已完成弃牌分源，补丁只覆盖确已隔离的缺口；不把单敌伤害当多敌分配规律。',
        '单弃/多弃、单敌/多敌、手牌容量及混合修饰分组固定回放，复核既有实现后才增加最小范围；不拟整战权重。'),
    '9b8890c2649a2734': (
        'ZTRGYYMLR8SC A10 F11T3、F17首T10/末T13—T14及全局资源链。',
        '原提案三个护栏的局部差额不等整战收益；末T13仍4HP/神官73，末T14实际失败。',
        '原答、护栏/SL替线、相邻动作和整轮端点已有离线追溯；完整候选字段按契约保留null。',
        '缺原线与替线的完整执行及连续资源联合归属；未走路线、晚饮铁心的整战后继未执行，局部省血不能累加成整场收益。',
        '按层/尝试/回合/指纹保留回答、替换、重问与出口；真实与预测分开，暂不改护栏、路线或SL边界。',
        '固定同题回答和动作端点，仅在完整连续且可唯一归属时作执行结论；不填未执行反事实，SL整组留出。'),
    '645ff7b72e0b9991': (
        'K2JAGKVJAWZJ A10 F46T1/T6；79UCJ0K6R9C1 A10 F14T3/T10/T11，d286684及s293158→293159、s293463—293465。',
        '升级零毒蜃景16→16；普通8毒+2敏实增10挡是整类归零反例。空过原题0/8已赢、尾端约76%，不等8次死亡。',
        '零毒升级蜃景5dbb47及普通蜃景cf0f249、持牌伤先于毒2e6fa2均在实际live祖先；现有rollout分列已赢/死亡/尾端估计。',
        '窄零毒与感染路径已有实现；原范围仍缺尾端估计校准和替代整战实结，不能由0/8或即时伤害调权、禁空过或关闭整项。',
        '保持已核零毒分支及普通正毒机制；未知长期收益不冒当已兑现挡，保留已赢、死亡和估计的不同口径。',
        '本批原帧核零毒0挡、普通10挡、感染先付；尾端校准需独立新完局，不能按帧随机拆分或偷看未来抽牌。'),
    '68ef2857229d1287': (
        'K2JAGKVJAWZJ A10 F33首试T10 s292940→292941；79UCJ0K6R9C1 A10 F14T11 s293463→293465。',
        '两次施毒42→48/4→10，敌54/8HP均不变；79随后2HP/7挡先死，毒仍10。K2重打未饮原瓶获胜，不能推必须饮药。',
        '当前observedPoison有双Boss和恶魔特定组合入口，另有其他蟹局当步事实；它们不等本批两局完整短推演认证。',
        '这两次只直接支持饮用当步加6；缺各自完整修饰组合、感染等先付代价与整轮后继的联合消费者校准，不能扩大成通用非双Boss药水模型。',
        '若后续原帧和消费者补足，只在角色/进阶/全部修饰条件相符时传播已证施毒；未知组合保持饮后读回，药价与SL不变。',
        '固定当步不扣HP、感染先死、SL恢复原瓶与62HP；药水题面和未来推演准入范围一致，未核组合显式未知。'),
    '9edfef7a6b2873c2': (
        'K2JAGKVJAWZJ A10 F31—F46，F34计划p2644；79UCJ0K6R9C1 A10 F8—F14；旧d285853/F7、d285888/F11为无decision_id路线元数据。',
        'K2 F34按75上限投影、后来实际最大HP91/入场86；79投影70/实到51的方向相反，不支持统一加减常数。',
        '7c43bbbb已在live保存路线起点、绝对HP/maxHP、当前节点、成本快照和假设，旧比例消费保持；资源链与新增敌血池审计已有。',
        '路线绝对来源子项已实现；宽资源链仍缺药水/SL/整战消费者联合归属，旧两条无decision_id元数据和归一化记录不能唯一补回。',
        '保留新投影来源，实际与计划同节点对齐，SL恢复、缺出口、新敌血池和模拟入口各自标明；不改路线消费或血线。',
        '固定K2/79正负误差链并核最大HP分母、每场胜战和缺出口；旧缺字段不补造，不用事后实扣替代预先时钟。'),
    'ff1d168227e369e0': (
        'K2JAGKVJAWZJ A10 F46T1/T2/T6/T7/T9；10GPK5XGHCK3 A3 F17T5；UJ0K3G10609Y A10 F33T7 s248044→248045。',
        'K2末T9生存者重放10+10挡、13HP仍死，不能用死亡截断实扣13替完整伤害；UJ端点56→48不是移除遗物对照。',
        '零毒蜃景、普通正毒、重放/暗影和逐击减损已有各自路径；不能把已有普通路径删除或把本批未核组合称已认证。',
        '所列臂甲/重放/暗影/临时减力与钨棍的完整组合消费者尚未核齐；K2三骑士T7额外2损伤来源未隔离，后续经验摘要不替本批原帧控制。',
        '已建立、已触发和本回合新增收益分别计入，临时层撤回与成长不混用；未核组合保持未知，不指定固定目标顺序。',
        '逐项固定重放计数、旧挡不补、首触发消费、到期与逐击/死亡截断；只有真实来源齐才扩展对应消费者。'),
    'c64bdd50a949d16f': (
        'K2JAGKVJAWZJ A10 F15T2/F27T2/F33首T10/F45/F46及跨幕F17→18、F33→34。',
        '旧稿F27的16挡已由9c3纠正：s292788→292789实际0→0挡、覆甲0→7；旧稿保留，不再用16计算。',
        '当前已建能力/药槽端点与跨幕事实已有；纠正旧数字属于证据勘误，不代表完整生产资源消费者已实现。',
        '沿9c3纠正F27零即时挡，保留旧稿；宽项仍缺持续能力、取得/实饮/SL恢复至终局的联合消费者和早饮/换瓶整战对照。',
        '只计本战已建立能力与实际药水变化；SL恢复不记新获或回血，不从持有毒雾/暗影预支战力。',
        '固定原稿与纠正版SHA及F27原帧；以源节点、药槽、跨幕和SL四类记录核联合消费者，未执行时点保持未知。'),
    '243ad8dd038a4ff6': (
        'K2JAGKVJAWZJ A10 F33两试T1—T11、F46T1—T9及前后资源链。',
        'F33首试判死10HP、重载62HP与原瓶；次试赢剩28。首29抽相同不控制之后洗牌，多回合目标、出牌和饮药同时变化。',
        '现有SL资源差额、候选审计和资源链是局部追溯；它们不认证单动作胜因、未走路线或另一休息后继。',
        '缺洗牌后同条件与单动作整战对照；替目标、替路线和另一休息后继未执行，不能从同首抽获胜归因固定杀序或改SL边界。',
        '保留实到资源与尝试差异，首抽一致范围写明；预测、已执行和失败截断分开，不将高血或前四轮少伤当后段安全。',
        '两试按完整局分组，核初始资源、已知抽序终点和实际动作差异；新条件不明留未知，不拟血线或目标规则。'),
    '9c3ff04261867dd2': (
        'K2JAGKVJAWZJ A10 F27T2 s292788→292789、F33首T10 s292940—292942、F45/F46以及两次跨幕。',
        '铁心实际只增覆甲7；首试毒瓶经SL恢复，不是新取得或最终路径消耗。另一构筑/提前能力/早饮的整战胜线未执行。',
        '本稿取代c64的一处数字；旧提案指纹和原账本保留，不登记为新的重复源码实现。',
        '勘误已核，但实际能力、药水取得/弃用/恢复与终局消费者完整联结及饮药时点整战对照仍缺；不把纠正稿当整项源码完成。',
        '按本稿的0挡事实核资源，保持原规则；持有、实际建立、实饮、弃药、跨幕及SL恢复各自追溯。',
        '固定原帧与勘误链，消费者必须同时保留来源及未知出口；没有完整后继不改药水或终局阈值。'),
}

entries = []
for p in proposals:
    key = p['id'].split('proposal-')[1]
    evidence, support, current, reason, expected, validation = SPECS[key]
    entries.append({**p, 'state': 'waiting', 'reason': reason, 'evidence_location': evidence,
                    'support_and_counterexample': support, 'current_scope': current,
                    'expected_behavior': expected, 'validation': validation})
(OUT / 'dispositions.json').write_text(json.dumps(entries, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 静默猎手本批十项策略提案复核

批次：20261016-231302-strategy-proposal。记录时间：{created}。
来源任务保留各原提案source_task，处理任务strategy-proposal；授权Roy-2026-10-07-learning。
本批只处理已领取十ID；未承接research_request/implementation_request，没有领取其他提案或派下级agent。
本次没有新源码或知识改动；以下新行为是仍待满足条件的原提案目标，不能冒称已实现。

原文已逐一核SHA并保存为本目录各ID.original.md。原账本首证、claim、prior、evidence、status、version保持；旧同局SL不增加独立样本。
证据只来自本角色日志、相关复盘/原提案和knowledge/characters/silent的相关条目。当前经验中的后续样本摘要不充当本批已核原帧，不用它宣称全史缺样本或本批已认证组合。

'''
sections = []
for e in entries:
    sections.append(f'''## {e['id']}：{e['summary']}

来源任务：{e['source_task']}；原账本：{', '.join(e['ledger'])}；领域：{', '.join(e['domains'])}。
原提案：{e['proposal']}；SHA256：{e['proposal_sha256']}。

证据局号/层/回合：{e['evidence_location']}

支持、反例和未知：{e['support_and_counterexample']}

旧行为与当前覆盖：{e['current_scope']}

拟新行为及预期：{e['expected_behavior']} 预期仅提高事实可核对性，不承诺通关率；缺证时本批保持现有行为。

处置：waiting。{e['reason']}

验证：{e['validation']} 新代码若有充分原帧支持，需源码撤除红/恢复绿、项目沙箱检查及实际live合入后才能登记实现；本批未执行这些生产检查。

回退：本项本批无新源码，无需回退；未来只逆向独立净补丁，保留原日志、失败材料、账本和并行知识。角色/进阶范围以已核证据为限，其他角色行为不变。

''')
(OUT / 'proposal.md').write_text(intro + ''.join(sections))

stream_table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} | {m['invalid_lines']} |" for m in audit['streams'])
disposition_table = '\n'.join(f"| {e['id']} | {', '.join(e['ledger'])} | {e['reason']} |" for e in entries)
commits = '\n'.join(f"- {c}：{v['subject']}；本基线祖先={v['base_ancestor']}，live祖先={v['live_ancestor']}。" for c, v in source['existing_source_commits'].items())
report = f'''# 静默猎手策略批次回报

本批十个原提案均waiting；本次没有新的源码、知识改动、提交、live合入、发布编号或shipped登记。已有窄实现已经核实，未将其扩大登记为整条宽提案完成。具体层/回合、原账本、反例、旧新行为及验证逐项保存于proposal.md。

## 基线与任务身份

记录时间：{created}。task=strategy-proposal，character=silent，batch=20261016-231302-strategy-proposal。
工作树：{ROOT}。
开工git status干净，合main为Already up to date；base和最终HEAD保持完整40位`{source['base']}`。
learn.json本批reason=proposal、十proposal_ids/角色/工作树匹配；没有research_request/implementation_request/proposal_repair。普通专题根请求绑定别批，不套用专题报告口径或其他请求；仅处理本批已领取十项。
没有运行play、游戏API、联网/LLM、安装依赖、推送或下级agent。没有修改账号、模型配置、运维prompt、key/.env或其他角色知识。本会话没有读取原生运行请求元数据，因此不冒称已经核实或切换实际运行模型/推理档；任务文字high与仓库xhigh规定的实际宿主差异交调用方原生回执核实。

## 原始证据与限制

十派发锚点全部SILENT：10GPK5XGHCK3为A3，1LMBFGSMCWKU为A4，9YT51CK8RC39为A7，其余七局A10；ff1d原提案另引UJ0K3G10609Y，补核SILENT/A10，未将补充局冒称派发锚点。
共用learner/extract_evidence.py八流提取`{audit['rows']}`封套，source_size和逐行原offset/bytes/SHA/JSON/显式身份均核；每流封套与前121302-s2同十一局逐字一致，新增截点不是新增游戏样本。静态材料45项、证据材料41项检查通过，不是生产tsc/vitest或机制全组合认证。

| 流 | 冻结source_size字节 | 选中行数（十一局） | 全源坏JSON行 |
| --- | ---: | ---: | ---: |
{stream_table}

fight-plans零行只表示本截点未选到显式归属行，不证明原日志缺失。全源坏JSON行未归本批或当机制证据；各流独立冻结，后续追加不进入本批结论。
十一局run-config的完整源码commit均存在；当时dirty知识/记录联合输入未全部恢复，不用当前代码/知识冒认原始整战重现。

## 已核实的事实及反例

- K2 F46T1升级蜃景全敌零毒时1能换16→16挡；同局T6普通蜃景8毒+2敏实增10挡。零毒局部不能将整类牌归零，原长期value10不是已得挡。
- 79 F14T3 d286684空过原题已赢0/8、尾端约76%；原答选plan5/confidence0.89。缺替代整场实结，0/8不等八死，不能据此拟禁空过或新终局权重。
- K2 F33首T10毒42→48/敌54HP不变；79 F14T11毒4→10/敌8HP不变，三感染先耗7挡及2HP，终局仍8HP/10毒。K2次试未喝原瓶仍胜，不证明喝药/不喝药独立导致结果。
- K2 F27T2 s292788→292789原挡0→0、覆甲0→7，采用9c3纠正版；c64旧16挡原文保留，仅该处由纠正版取代。该旧勘误不是本批新发现的经验冲突。
- ZTR六次同层尝试是同一局，17饮药请求不等17新瓶。资源工具固定输入重算保留12窗/5缺出口；K2为18窗/1缺出口，79为7窗/0缺出口，逐对象等于旧结果。净HP差不等毛伤，SL恢复不等回血或新获。
- ZTR末T14 s292398→292399神官64→61是弃牌后附伤，后中和到58仍败。K2末T9生存者10+10挡后13血归零，死亡截断不证明完整伤害只有13；三骑士T7多2损伤未隔离。
- UJ补充F33T7 s248044→248045，12挡/HP56→48，只核原端点，不是移除遗物反事实。当前经验所列后续升级正毒、单敌五弃等摘要不冒称本批已核原帧；缺口是限定组合/消费者和因果，不笼统声称全历史没有样本。

## 消费者与已有源码

本次复用并核SHA读取旧121302-s2的三份冻结消费者输入、gzip输出和解码输出，未重新运行消费者、模型、模拟或自然对局。共134候选段、489动作；ZTR F17为101段/395动作、69可核整轮端点和12未知窗；K2 F46为12段/51动作、9未知窗；79 F14为21段/43动作、11未知窗。
完整候选字段actual_full_candidate_result按工具契约为null，不能从该字段的零认证数量断言实盘从未完整执行，也不能把已核整轮端点归因某一候选/护栏/SL的整战收益。旧输入输出SHA、退出码与覆盖来自历史回执，本次仅作读回核验；见consumer-reuse.json与prior-artifacts.json。

只读核实际live`{source['live_head']}`，19个相关叶15个SHA同live；四个差异均原有Roy/Dai署名注释，净diff另存，不冒称完整dirty运行树相同。对旧121302-s2的18个可比叶16个SHA相同，另加恶魔药水来源叶；既有R373诊断变化不当新游戏规则。
实际祖先来源如下，均只作窄覆盖追溯：

{commits}

特别是7c43bbbb的绝对路线投影来源已经在live：起始HP/maxHP、节点、成本与假设快照已有，不重复实现。零毒蜃景、普通蜃景、感染先于毒、药水/敌血池/整轮与SL资源审计也已有各自范围；原药水当前题面和未来推演入口不因这些子项自动扩大。
K2旧路线d285853/F7、d285888/F11无decision_id，明确作为元数据边界；不能为送进严格消费者而补造身份或重编号原行。

## 十个派发ID逐项处置

| 原提案 | 原账本 | waiting具体原因 |
| --- | --- | --- |
{disposition_table}

所有ID都保留proposal_results，不领取其他批次或另建重复代码提案；code_proposals沿用这十个真实CLI ID，implementation_domains=[]表示本批没有生产实现，不删除原提案领域。

## 验证、记录和交接

源码和全部knowledge无改动，baseline-diff.patch为空，工作树与index保持干净。没有源码撤除/恢复测试，本批tsc/vitest/cases均null，没有借用旧绿或制造测试成功。无提交，因而没有提交前gitleaks、合后测试、eval版本、规则上线双通知或decision-log上线行。
只经根learner/ledger.py update给20个既有本角色条目追加本目录proposal.md/report.md及waiting追溯note，不增加support/repeat或重写claim、首证、先验、证据、状态和版本；不标shipped。CLI回执、旧物理前缀SHA和本批逐行归属审计另存ledger-audit.json。未手写专用提案队列、根请求或复盘，不更改其他角色。

运维读取本目录proposal.md、report.md、result.json、dispositions.json以及两份材料检查。完整十项仍需上述具体同角色新证据或有界消费者验证，等待不等实现/入库或自然采用；原父要求和旧失败回执保持。没有未提交源码补丁、提交阻塞或合入冲突；本批没有尝试合入，不把证据不足描述成merge失败。
只读路径探针曾误写core/types.ts、material-checks.json、check-evidence.py、consumer-receipts.json、potion_observation.py而报不存在；已按实际rg/目录改读正确文件，见tool-diagnostics.md。这些是本会话工具路径错误，不是生产失败、机制反例或原材料丢失。
所有临时材料、原稿和原始提取保留本批指定scratch；不删除自身工作树。
'''
(OUT / 'report.md').write_text(report)
results = [{'id': e['id'], 'state': 'waiting', 'reason': e['reason']} for e in entries]
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-231302-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [],
          'skipped': [],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': result['report'], 'proposal_results': len(results), 'base': result['base']}, ensure_ascii=False))

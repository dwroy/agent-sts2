# 静默猎手策略批次回报

本批十个原提案均waiting；本次没有新的源码、知识改动、提交、live合入、发布编号或shipped登记。已有窄实现已经核实，未将其扩大登记为整条宽提案完成。具体层/回合、原账本、反例、旧新行为及验证逐项保存于proposal.md。

## 基线与任务身份

记录时间：2026-10-16 23:24:31 CST。task=strategy-proposal，character=silent，batch=20261016-231302-strategy-proposal。
工作树：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-231302。
开工git status干净，合main为Already up to date；base和最终HEAD保持完整40位`8bddfe5370bf734afc0bae2e311a96da0f7e5c90`。
learn.json本批reason=proposal、十proposal_ids/角色/工作树匹配；没有research_request/implementation_request/proposal_repair。普通专题根请求绑定别批，不套用专题报告口径或其他请求；仅处理本批已领取十项。
没有运行play、游戏API、联网/LLM、安装依赖、推送或下级agent。没有修改账号、模型配置、运维prompt、key/.env或其他角色知识。本会话没有读取原生运行请求元数据，因此不冒称已经核实或切换实际运行模型/推理档；任务文字high与仓库xhigh规定的实际宿主差异交调用方原生回执核实。

## 原始证据与限制

十派发锚点全部SILENT：10GPK5XGHCK3为A3，1LMBFGSMCWKU为A4，9YT51CK8RC39为A7，其余七局A10；ff1d原提案另引UJ0K3G10609Y，补核SILENT/A10，未将补充局冒称派发锚点。
共用learner/extract_evidence.py八流提取`14636`封套，source_size和逐行原offset/bytes/SHA/JSON/显式身份均核；每流封套与前121302-s2同十一局逐字一致，新增截点不是新增游戏样本。静态材料45项、证据材料41项检查通过，不是生产tsc/vitest或机制全组合认证。

| 流 | 冻结source_size字节 | 选中行数（十一局） | 全源坏JSON行 |
| --- | ---: | ---: | ---: |
| states | 13696418264 | 7230 | 2 |
| decisions | 2082125872 | 6936 | 2 |
| sl-attempts | 44263058 | 58 | 0 |
| run-config | 1900688 | 11 | 0 |
| run-plans | 8686761 | 52 | 0 |
| brain | 702413241 | 338 | 1 |
| runs | 352719 | 11 | 0 |
| fight-plans | 2233957 | 0 | 0 |

fight-plans零行只表示本截点未选到显式归属行，不证明原日志缺失。全源坏JSON行未归本批或当机制证据；各流独立冻结，后续追加不进入本批结论。
十一局run-config的完整源码commit均存在；当时dirty知识/记录联合输入未全部恢复，不用当前代码/知识冒认原始整战重现。

## 已核实的事实及反例

- K2 F46T1升级蜃景全敌零毒时1能换16→16挡；同局T6普通蜃景8毒+2敏实增10挡。零毒局部不能将整类牌归零，原长期value10不是已得挡。
- 79 F14T3 d286684空过原题已赢0/8、尾端约76%；原答选plan5/confidence0.89。缺替代整场实结，0/8不等八死，不能据此拟禁空过或新终局权重。
- K2 F33首T10毒42→48/敌54HP不变；79 F14T11毒4→10/敌8HP不变，三感染先耗7挡及2HP，终局仍8HP/10毒。K2次试未喝原瓶仍胜，不证明喝药/不喝药独立导致结果。
- K2 F27T2 s292788→292789原挡0→0、覆甲0→7，采用9c3纠正版；c64旧16挡原文保留，仅该处由纠正版取代。该旧勘误不是本批新发现的经验冲突。
- ZTR六次同层尝试是同一局，17饮药请求不等17新瓶。资源工具固定输入重算保留12窗/5缺出口；K2为18窗/1缺出口，79为7窗/0缺出口，逐对象等于旧结果。净HP差不等毛伤，SL恢复不等回血或新获。
- ZTR末T14 s292398→292399神官64→61是弃牌后附伤，后中和到58仍败。K2末T9生存者10+10挡后13血归零，死亡截断不证明完整伤害只有13；三骑士T7多2损伤未隔离。
- UJ补充F33T7 s248044→248045，12挡/HP56→48，只核原端点，不是移除遗物反事实。当前经验所列后续升级正毒、单敌五弃等摘要不冒称本批已核原帧；缺口是限定组合/消费者和因果，不笼统声称全历史没有样本。

## 消费者与已有源码

本次复用并核SHA读取旧121302-s2的三份冻结消费者输入、gzip输出和解码输出，未重新运行消费者、模型、模拟或自然对局。共134候选段、489动作；ZTR F17为101段/395动作、69可核整轮端点和12未知窗；K2 F46为12段/51动作、9未知窗；79 F14为21段/43动作、11未知窗。
完整候选字段actual_full_candidate_result按工具契约为null，不能从该字段的零认证数量断言实盘从未完整执行，也不能把已核整轮端点归因某一候选/护栏/SL的整战收益。旧输入输出SHA、退出码与覆盖来自历史回执，本次仅作读回核验；见consumer-reuse.json与prior-artifacts.json。

只读核实际live`5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922`，19个相关叶15个SHA同live；四个差异均原有Roy/Dai署名注释，净diff另存，不冒称完整dirty运行树相同。对旧121302-s2的18个可比叶16个SHA相同，另加恶魔药水来源叶；既有R373诊断变化不当新游戏规则。
实际祖先来源如下，均只作窄覆盖追溯：

- 7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a：Preserve Silent route projection audit inputs；本基线祖先=True，live祖先=True。
- 5dbb47bfb48d652adfcda2e62c166a804098b6c3：Sync tested learner Mirage zero-poison scope to main；本基线祖先=True，live祖先=True。
- cf0f2495354d9cf5dcb96dc31a2de0f4c53f441a：Model observed Mirage Block from current poison in Silent A10；本基线祖先=True，live祖先=True。
- a32050fbce4c2863f640468c2dbf378fc9157074：Integrate checked offline Silent potion observation tool；本基线祖先=True，live祖先=True。
- 3f69541b5d3259dac94d3395bfe3da47936b4de9：Audit observed enemy HP changes in Silent replays；本基线祖先=True，live祖先=True。
- 154c9542711a4daf17bfa0b97eaa1ca81dc3d385：Expose observed Silent crab potion application facts；本基线祖先=True，live祖先=True。
- e75438488df159b2e8e9d3458cf219b39aadd933：Apply tested offline observed-turn audit and explicit unsupported-DPR diagnostics；本基线祖先=True，live祖先=True。
- 2e6fa2e5c68be70efb2ee87bee58f2cb3128bfb2：Fix held-card damage before enemy-turn poison finishes；本基线祖先=True，live祖先=True。
- 1698adc96ba434a46942321e0237b70657e625b2：Complete Silent SL resource comparison audit；本基线祖先=True，live祖先=True。

特别是7c43bbbb的绝对路线投影来源已经在live：起始HP/maxHP、节点、成本与假设快照已有，不重复实现。零毒蜃景、普通蜃景、感染先于毒、药水/敌血池/整轮与SL资源审计也已有各自范围；原药水当前题面和未来推演入口不因这些子项自动扩大。
K2旧路线d285853/F7、d285888/F11无decision_id，明确作为元数据边界；不能为送进严格消费者而补造身份或重编号原行。

## 十个派发ID逐项处置

| 原提案 | 原账本 | waiting具体原因 |
| --- | --- | --- |
| silent-proposal-0b8ef30de463f317 | silent-0013, silent-0277 | 缺新获/实饮/弃用/SL恢复至消费者的完整联合归属，以及同资源晚饮或留药的整战对照；现有覆甲路径不重复修改。 |
| silent-proposal-5367449b857450a7 | silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284 | 原七局单弃和本局单敌刀扇不足认证多敌随机分配、混合修饰及完整后继；后续经验所提单敌多弃摘要未在本批核原帧，不能代替消费者校准。 |
| silent-proposal-9b8890c2649a2734 | silent-0012, silent-0019, silent-0020, silent-0021, silent-0125 | 缺原线与替线的完整执行及连续资源联合归属；未走路线、晚饮铁心的整战后继未执行，局部省血不能累加成整场收益。 |
| silent-proposal-645ff7b72e0b9991 | silent-0010, silent-0106, silent-0021, silent-0286 | 窄零毒与感染路径已有实现；原范围仍缺尾端估计校准和替代整战实结，不能由0/8或即时伤害调权、禁空过或关闭整项。 |
| silent-proposal-68ef2857229d1287 | silent-0278, silent-0286 | 这两次只直接支持饮用当步加6；缺各自完整修饰组合、感染等先付代价与整轮后继的联合消费者校准，不能扩大成通用非双Boss药水模型。 |
| silent-proposal-9edfef7a6b2873c2 | silent-0020, silent-0019, silent-0021 | 路线绝对来源子项已实现；宽资源链仍缺药水/SL/整战消费者联合归属，旧两条无decision_id元数据和归一化记录不能唯一补回。 |
| silent-proposal-ff1d168227e369e0 | silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178 | 所列臂甲/重放/暗影/临时减力与钨棍的完整组合消费者尚未核齐；K2三骑士T7额外2损伤来源未隔离，后续经验摘要不替本批原帧控制。 |
| silent-proposal-c64bdd50a949d16f | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | 沿9c3纠正F27零即时挡，保留旧稿；宽项仍缺持续能力、取得/实饮/SL恢复至终局的联合消费者和早饮/换瓶整战对照。 |
| silent-proposal-243ad8dd038a4ff6 | silent-0019, silent-0020, silent-0065, silent-0106 | 缺洗牌后同条件与单动作整战对照；替目标、替路线和另一休息后继未执行，不能从同首抽获胜归因固定杀序或改SL边界。 |
| silent-proposal-9c3ff04261867dd2 | silent-0021, silent-0243, silent-0276, silent-0277, silent-0278 | 勘误已核，但实际能力、药水取得/弃用/恢复与终局消费者完整联结及饮药时点整战对照仍缺；不把纠正稿当整项源码完成。 |

所有ID都保留proposal_results，不领取其他批次或另建重复代码提案；code_proposals沿用这十个真实CLI ID，implementation_domains=[]表示本批没有生产实现，不删除原提案领域。

## 验证、记录和交接

源码和全部knowledge无改动，baseline-diff.patch为空，工作树与index保持干净。没有源码撤除/恢复测试，本批tsc/vitest/cases均null，没有借用旧绿或制造测试成功。无提交，因而没有提交前gitleaks、合后测试、eval版本、规则上线双通知或decision-log上线行。
只经根learner/ledger.py update给20个既有本角色条目追加本目录proposal.md/report.md及waiting追溯note，不增加support/repeat或重写claim、首证、先验、证据、状态和版本；不标shipped。CLI回执、旧物理前缀SHA和本批逐行归属审计另存ledger-audit.json。未手写专用提案队列、根请求或复盘，不更改其他角色。

运维读取本目录proposal.md、report.md、result.json、dispositions.json以及两份材料检查。完整十项仍需上述具体同角色新证据或有界消费者验证，等待不等实现/入库或自然采用；原父要求和旧失败回执保持。没有未提交源码补丁、提交阻塞或合入冲突；本批没有尝试合入，不把证据不足描述成merge失败。
只读路径探针曾误写core/types.ts、material-checks.json、check-evidence.py、consumer-receipts.json、potion_observation.py而报不存在；已按实际rg/目录改读正确文件，见tool-diagnostics.md。这些是本会话工具路径错误，不是生产失败、机制反例或原材料丢失。
所有临时材料、原稿和原始提取保留本批指定scratch；不删除自身工作树。

import collections
import gzip
import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LIVE = pathlib.Path('/home/dw/Projects/agent-sts2/.worktrees/live')
OLD = pathlib.Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-121302-s2/learner/runs/20261016-121311-d2894caa-0f98-4eb1-aa5e-277335985df2-strategy-proposal')
checks = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    write('static-progress.json', checks)
    assert value, name


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'proposals.snapshot.json').read_text())
check('十项派发唯一且逐项存在', len(proposals) == len(dispatch['proposal_ids']) == 10 and
      {p['id'] for p in proposals} == set(dispatch['proposal_ids']))
for p in proposals:
    raw = pathlib.Path(p['proposal']).read_bytes()
    check(p['id'] + ':原文SHA', sha(raw) == p['proposal_sha256'])
    (OUT / (p['id'] + '.original.md')).write_bytes(raw)

old_source = json.loads((OLD / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
check('基线未变', base == (OUT / 'base.txt').read_text().strip())
source = {'base': base, 'live_head': live, 'leaves': {}, 'existing_source_commits': {}}
leaves = list(old_source['leaves']) + ['agent/src/reflex/silent-demon-potion.ts']
snapshot = OUT / 'source-snapshots'
snapshot.mkdir(exist_ok=True)
for leaf in leaves:
    raw = (ROOT / leaf).read_bytes()
    live_raw = (LIVE / leaf).read_bytes()
    recorded = git('show', base + ':' + leaf)
    check(leaf + ':本树等基线', raw == recorded)
    source['leaves'][leaf] = {
        'base_sha256': sha(raw), 'live_sha256': sha(live_raw), 'equal_live': raw == live_raw,
        'old_base_sha256': old_source['leaves'].get(leaf, {}).get('base_sha256'),
        'equal_old_base': sha(raw) == old_source['leaves'].get(leaf, {}).get('base_sha256'),
    }
    safe = leaf.replace('/', '__')
    (snapshot / (safe + '.base.txt')).write_bytes(raw)
    if live_raw != raw:
        (snapshot / (safe + '.live.txt')).write_bytes(live_raw)

commits = list(old_source['existing_source_commits']) + ['2e6fa2', '1698adc96ba434a46942321e0237b70657e625b2']
for short in commits:
    commit = git('rev-parse', short + '^{commit}').decode().strip()
    source['existing_source_commits'][commit] = {
        'base_ancestor': subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
        'live_ancestor': subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', commit, live]).returncode == 0,
        'subject': git('show', '-s', '--format=%s', commit).decode().strip(),
    }
check('七项旧窄来源在本基线及live祖先', all(source['existing_source_commits'][i]['base_ancestor'] and
      source['existing_source_commits'][i]['live_ancestor'] for i in old_source['existing_source_commits']))
source['live_head_end'] = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
source['limitations'] = ['逐叶SHA和祖先不代表全部dirty知识输入或自然收益认证。',
                         '保存当前源码对照，不用它替代历史运行dirty源码。']
write('source-audit.json', source)
(OUT / 'baseline-diff.patch').write_bytes(git('diff', '--binary', base))

receipts = json.loads((OLD / 'consumer-audit-receipts.json').read_text())
reuse = []
for r in receipts:
    inp = pathlib.Path(r['input']).read_bytes()
    packed = pathlib.Path(r['output']).read_bytes()
    decoded = gzip.decompress(packed)
    check(r['run'] + ':旧消费者输入输出SHA', sha(inp) == r['input_sha256'] and
          sha(packed) == r['gzip_sha256'] and sha(decoded) == r['decoded_sha256'] and len(decoded) == r['decoded_bytes'])
    x = json.loads(decoded)
    check(r['run'] + ':旧消费者角色局号', x['character'] == 'silent' and x['ascension'] == 10 and x['run_id'] == r['run'])
    turn_counts = dict(collections.Counter(t['status'] for t in x['observed_turns']))
    check(r['run'] + ':旧消费者计数', len(x['segments']) == r['segments'] and len(x['observed_actions']) == r['actions'] and
          turn_counts == r['turn_status'])
    check(r['run'] + ':完整候选字段仍未知', all(s['actual_full_candidate_result'] is None for s in x['segments']))
    reuse.append({**r, 'rerun': False, 'turn_status_readback': turn_counts,
                  'limitations': '完整候选字段为null是该消费者契约，不能据此断言实盘从未执行完整候选。'})
write('consumer-reuse.json', reuse)
artifacts = {}
for name in ['report.md', 'proposal.md', 'source-audit.json', 'consumer-audit-receipts.json', 'consumer-summary.json',
             'evidence-check.json', 'evidence-retry/evidence-manifest.json', 'verify-evidence.py',
             'ZTRGYYMLR8SC-resources.json', 'K2JAGKVJAWZJ-resources.json', '79UCJ0K6R9C1-resources.json']:
    path = OLD / name
    artifacts[name] = {'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
write('prior-artifacts.json', artifacts)
experience = json.loads((ROOT / 'knowledge/characters/silent/experience.json').read_text())
ids = {i for p in proposals for i in p.get('experience', [])}
selected = [e for e in experience['entries'] if e['id'] in ids]
check('只保留本批相关静默经验', {e['id'] for e in selected} == ids)
write('experience.selected.json', {'source_sha256': sha((ROOT / 'knowledge/characters/silent/experience.json').read_bytes()), 'entries': selected})
write('static-checks.json', checks)
print(json.dumps({'checks': len(checks), 'source_leaves': len(leaves), 'equal_live': sum(v['equal_live'] for v in source['leaves'].values()),
                  'equal_old_base': sum(v['equal_old_base'] for v in source['leaves'].values()),
                  'commits': source['existing_source_commits'], 'consumer_segments': sum(r['segments'] for r in receipts)}, ensure_ascii=False))

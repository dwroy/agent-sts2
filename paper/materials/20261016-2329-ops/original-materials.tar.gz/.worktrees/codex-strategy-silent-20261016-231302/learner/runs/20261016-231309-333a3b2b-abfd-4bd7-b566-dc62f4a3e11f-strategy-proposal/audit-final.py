import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
CANONICAL = pathlib.Path('/home/dw/Projects/agent-sts2')


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


prefix = json.loads((OUT / 'ledger-prefix.json').read_text())
raw = (CANONICAL / 'paper/materials/learning/ledger.jsonl').read_bytes()
assert sha(raw[:prefix['size']]) == prefix['sha256']
inputs = [json.loads(line) for line in (OUT / 'ledger-links-input.jsonl').read_text().splitlines()]
by_id = {row['id']: row for row in inputs}
own, other, offset = [], [], prefix['size']
for line in raw[prefix['size']:].splitlines(keepends=True):
    row = json.loads(line)
    if str(row.get('note', '')).startswith('20261016-231302-strategy-proposal 逐项复核：'):
        expected = by_id[row['id']]
        assert {k: v for k, v in row.items() if k not in ['op', 'ts']} == expected
        assert row['op'] == 'update'
        own.append({'offset': offset, 'bytes': len(line), 'sha256': sha(line), 'row': row})
    else:
        other.append({'offset': offset, 'bytes': len(line), 'sha256': sha(line)})
    offset += len(line)
assert len(own) == len(inputs) == 20
assert len({r['row']['id'] for r in own}) == 20
spec = importlib.util.spec_from_file_location('ledger', CANONICAL / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
prefix_rows = [(i, json.loads(line)) for i, line in enumerate(raw[:prefix['size']].decode().splitlines(), 1) if line.strip()]
private = ledger.fold(prefix_rows + [(len(prefix_rows) + i, item['row']) for i, item in enumerate(own, 1)])
before = json.loads((OUT / 'ledger-before-links.json').read_text())
protected = []
for ident, old in before.items():
    new = private[ident]
    for key in set(old) | set(new):
        if key in ['notes', 'history', 'where']:
            continue
        assert old.get(key) == new.get(key), (ident, key)
    for key in ['notes', 'history']:
        assert new[key][:len(old[key])] == old[key]
    for key, values in old.get('where', {}).items():
        assert new['where'][key][:len(values)] == values
    assert new['where']['proposal'][-2:] == by_id[ident]['where']['proposal']
    protected.append(ident)
write('ledger-audit.json', {'old_prefix_unchanged': True, 'prefix': prefix, 'own_rows': own,
                           'other_concurrent_rows': other, 'protected_entries': protected,
                           'preserved_fields': '除本批where/note/history追加以外的全部字段均不变；原三列表前缀保留。'})

result_path = OUT / 'result.json'
result = json.loads(result_path.read_text())
if result['skipped']:
    (OUT / 'result.initial.json').write_bytes(result_path.read_bytes())
    result['skipped'] = []
    write('result.json', result)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert base == result['base'] == (OUT / 'base.txt').read_text().strip()
assert subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT) == b''
assert subprocess.check_output(['git', 'diff', '--binary', base], cwd=ROOT) == b''
assert subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=ROOT) == b''
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert set(result['code_proposals']) == set(dispatch['proposal_ids'])
assert set(r['id'] for r in result['proposal_results']) == set(dispatch['proposal_ids'])
assert len(result['proposal_results']) == len(set(r['id'] for r in result['proposal_results'])) == 10
assert all(r['state'] == 'waiting' and r['reason'].strip() and not r.get('commit') for r in result['proposal_results'])
assert result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == []
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['report'] == str(OUT / 'report.md') and (OUT / 'proposal.md').is_file()

state = json.loads((CANONICAL / 'ops/codex-ops/learn.json').read_text())
batch = '20261016-231302-strategy-proposal'


def find(value):
    if isinstance(value, dict):
        if value.get('batch') == batch or value.get('id') == batch:
            return [value]
        found = []
        for key, item in value.items():
            found.extend([item] if key == batch else find(item))
        return found
    if isinstance(value, list):
        return [item for nested in value for item in find(nested)]
    return []


current = find(state)
assert len(current) == 1
assert all(current[0].get(k) == dispatch.get(k) for k in ['task', 'character', 'worktree', 'runs', 'proposal_ids', 'proposal_repair',
                                                        'research_request', 'implementation_request'])
write('dispatch-final.json', current[0])
spec = importlib.util.spec_from_file_location('proposals', CANONICAL / 'learner/code_proposals.py')
proposals = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proposals)
queue = proposals.fold(CANONICAL / 'paper/materials/learning/code-proposals.jsonl')
assert proposals.report_links(result, queue, 'silent') == []

artifacts = {}
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name not in ['final-artifacts.json', 'final-audit.stdout.json', 'final-audit.stderr.txt']:
        artifacts[str(path.relative_to(OUT))] = {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
write('final-artifacts.json', artifacts)
print(json.dumps({'base': base, 'clean_worktree': True, 'source_and_knowledge_diff': False,
                  'proposal_results': 10, 'ledger_rows': 20, 'artifacts': len(artifacts), 'tests': result['tests']}, ensure_ascii=False))

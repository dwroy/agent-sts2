import collections
import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LOGS = pathlib.Path('/home/dw/Projects/agent-sts2/logs')
OLD = pathlib.Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-121302-s2/learner/runs/20261016-121311-d2894caa-0f98-4eb1-aa5e-277335985df2-strategy-proposal')
checks, rows, critical = [], {}, []


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    write('evidence-progress.json', checks)
    assert value, name


def identity(row):
    values = [row.get('run'), row.get('run_id'), (row.get('state') or {}).get('run_id')]
    fingerprint = row.get('fingerprint')
    if isinstance(fingerprint, str):
        fingerprint = json.loads(fingerprint)
    if isinstance(fingerprint, dict):
        values.append(fingerprint.get('run'))
    return {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}


dispatch = json.loads((OUT / 'dispatch.json').read_text())
selected = set(dispatch['runs']) | {'UJ0K3G10609Y'}
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
for meta in manifest:
    stream = meta['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    check(stream + ':封套SHA', hashlib.sha256(path.read_bytes()).hexdigest() == meta['output_sha256'])
    entries = []
    with (LOGS / (stream + '.jsonl')).open('rb') as source:
        for line in path.open():
            e = json.loads(line)
            source.seek(e['offset'])
            raw = source.read(e['bytes'])
            assert hashlib.sha256(raw).hexdigest() == e['sha256']
            assert json.loads(raw) == e['row']
            assert e['offset'] + e['bytes'] <= meta['source_size']
            assert identity(e['row']) == {e['run_id']} and e['run_id'] in selected
            entries.append(e)
    check(stream + ':原字节身份计数', dict(collections.Counter(e['run_id'] for e in entries)) ==
          {r: n for r, n in meta['counts'].items() if n})
    old = OLD / 'evidence-retry' / path.name
    check(stream + ':与前批同局封套一致', hashlib.sha256(path.read_bytes()).hexdigest() == hashlib.sha256(old.read_bytes()).hexdigest())
    rows[stream] = entries

runs = {e['run_id']: e['row'] for e in rows['runs']}
check('十一局角色且无重复', len(rows['runs']) == len(runs) == 11 and all(r['character'] == 'SILENT' for r in runs.values()))
write('runs-identity.json', runs)
check('每状态角色进阶一致', all(e['row']['state']['run']['character_id'] == 'SILENT' and
      e['row']['state']['run']['ascension'] == runs[e['run_id']]['ascension'] for e in rows['states']))
states = {e['line']: e for e in rows['states']}


def state(line):
    critical.append(states[line])
    return states[line]['row']['state']


def player(line):
    return state(line)['combat']['player']


def enemy(line, at=0):
    return state(line)['combat']['enemies'][at]


def power(body, name):
    return next((p['amount'] for p in body.get('powers', []) if p['power_id'] == name), 0)


check('K2F46T1零毒升级蜃景付一能零挡', player(293158)['block'] == player(293159)['block'] == 16 and
      player(293158)['energy'] - player(293159)['energy'] == 1 and
      all(power(e, 'POISON_POWER') == 0 for e in state(293158)['combat']['enemies']))
check('K2F46T6普通正毒蜃景反例十挡', player(293196)['block'] == 10 and player(293197)['block'] == 20 and
      power(enemy(293196, 2), 'POISON_POWER') == 8 and power(player(293196), 'DEXTERITY_POWER') == 2)
check('K2F33T10毒42到48敌血54不变', power(enemy(292940), 'POISON_POWER') == 42 and
      power(enemy(292941), 'POISON_POWER') == 48 and enemy(292940)['current_hp'] == enemy(292941)['current_hp'] == 54)
check('79F14T11毒4到10敌血8不变', power(enemy(293463), 'POISON_POWER') == 4 and
      power(enemy(293464), 'POISON_POWER') == 10 and enemy(293463)['current_hp'] == enemy(293464)['current_hp'] == 8)
check('79F14T11先死毒未结算', state(293464)['run']['current_hp'] == 2 and player(293464)['block'] == 7 and
      state(293465)['run']['current_hp'] == 0 and enemy(293465)['current_hp'] == 8 and power(enemy(293465), 'POISON_POWER') == 10)
check('79F14T10完整失11', state(293460)['run']['current_hp'] - state(293461)['run']['current_hp'] == 11)
check('K2F27T2铁心勘误零挡覆甲增7', player(292788)['block'] == player(292789)['block'] == 0 and
      power(player(292789), 'PLATING_POWER') - power(player(292788), 'PLATING_POWER') == 7)
check('ZTR末T2覆甲非即时挡', player(292343)['block'] == 7 and power(player(292343), 'PLATING_POWER') == 7 and
      state(292343)['run']['current_hp'] - state(292344)['run']['current_hp'] == 4 and power(player(292344), 'PLATING_POWER') == 6)
check('UJ补充端点不是移除遗物对照', state(248044)['run']['current_hp'] == 56 and
      state(248045)['run']['current_hp'] == 48 and player(248044)['block'] == 12)
check('ZTR17饮药请求', sum(e['run_id'] == 'ZTRGYYMLR8SC' and
      (e['row'].get('chosen') or {}).get('action') == 'use_potion' for e in rows['decisions']) == 17)
check('ZTR同层六次尝试不是六局', len([e for e in rows['sl-attempts'] if e['run_id'] == 'ZTRGYYMLR8SC' and e['row']['floor'] == 17]) == 6)

spec = importlib.util.spec_from_file_location('resource_chain', ROOT / 'learner/resource_chain.py')
resource = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resource)
resource_summary = {}
for run in ['ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1']:
    frames = [{**e['row'], '_line': e['line']} for e in rows['states'] if e['run_id'] == run]
    starts = collections.defaultdict(list)
    for e in rows['sl-attempts']:
        s = e['row']
        if e['run_id'] == run and s.get('attempt', 1) > 1 and s.get('started_at'):
            starts[s['floor']].append(s['started_at'])
    result = resource.resource_chain(frames, run, 'silent', starts)
    write(run + '-resources.json', result)
    check(run + ':资源结果与旧固定输入一致', result == json.loads((OLD / (run + '-resources.json')).read_text()))
    resource_summary[run] = {'combats': len(result['combats']), 'missing_exits': sum(c['exit'] is None for c in result['combats'])}

configs = {}
for e in rows['run-config']:
    code = e['row'].get('code') or {}
    commit = code.get('commit')
    exists = bool(commit) and subprocess.run(['git', 'cat-file', '-e', commit + '^{commit}'], cwd=ROOT,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    configs[e['run_id']] = {'commit': commit, 'commit_exists': exists, 'dirty': code.get('dirty'), 'dirty_files': code.get('dirty_files')}
check('十一局原提交存在而dirty联合输入未复原', set(configs) == selected and all(c['commit_exists'] for c in configs.values()))
write('historical-code.json', configs)
unique = {e['line']: e for e in critical}
write('critical-frames.json', list(unique.values()))
summary = {'checks': checks, 'rows': sum(len(r) for r in rows.values()), 'streams': manifest,
           'resource_summary': resource_summary, 'critical_frames': len(unique),
           'limitations': ['原材料断言不等于生产测试或受控整战效果。', 'fight-plans零行只说明本截点未选中。',
                          '相同封套并非新增对局样本；原SL重打不增加独立局数。']}
write('evidence-audit.json', summary)
print(json.dumps({k: v for k, v in summary.items() if k not in ['checks', 'streams']}, ensure_ascii=False))

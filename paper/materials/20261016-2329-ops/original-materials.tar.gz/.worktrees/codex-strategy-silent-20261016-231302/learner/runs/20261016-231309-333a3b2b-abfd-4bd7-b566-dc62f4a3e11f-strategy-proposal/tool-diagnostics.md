# 本会话工具诊断

以下只读路径探针报不存在，未修改生产文件，后续均通过目录或rg定位正确入口；不将这些错误当产品失败、日志缺失或机制反例。

- `agent/src/core/types.ts`：实际类型入口不是此路径。已继续读取实际`agent/src/hand/screens/route-plan.ts`及相关调用方。
- 原121302-s2的`material-checks.json`：实际为`material-check-progress.json`、`evidence-check.json`与`verify-evidence.py`，后续已经读取实际文件。
- 原121302-s2的`check-evidence.py`：实际为`verify-evidence.py`。
- 原121302-s2的`consumer-receipts.json`：实际为`consumer-audit-receipts.json`，本批已按其真实路径逐份核输入/gzip/解码SHA。
- `learner/potion_observation.py`：不存在此独立脚本；`a32050fb`实际提交路径为`learner/lib/selection-execution.ts`、`selection-observation.ts`与文档/固定题。后续已按真实源码读取，不声称存在另一个已实现工具。

工具聚合输出曾因输出预算截断；需要的原提案已分段补读并逐SHA保存，三消费者输入/输出、原始日志和源码快照均通过本批材料脚本直接核验，不从截断输出补造结论。

初始读取广泛账本链接时，有两份旧报告并非本批相同十ID，后续以十原Markdown和确实同十ID的121302-s2报告核范围；未据其他提案代办本批任务，没有领取其他ID。

本批`audit-static.py`与`audit-evidence.py`均第一次运行退出0，无生产源码或测试夹具修改。所有生产检查都未运行，tsc/vitest/cases为null。

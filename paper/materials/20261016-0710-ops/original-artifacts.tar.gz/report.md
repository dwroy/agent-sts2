## 修 bug 回报
- 合并基线：main → 84524bce1d7b57f42403b80e42082c62fc8cd158
- 修复（每条一行）：infra-feature-root-event-notice-path：合法根目录事件日志通知注册 — 577f0bc424b7287910735cfdc86c253cc7ee8057 — 测试 agent/tests/feature-root-event-notice.test.ts:registers bound root event logs and rejects wrong launch ownership, paths, SHA and delivery proofs — 去掉修复时失败：是（exit1；恢复后exit0）
- 已被别人修掉的：18个未勾选条目已修或已有窄范围覆盖，提交逐条列于下表；另77项既有来源引用已核本批base和原live祖先。
- 没修的：24个未勾选策略/框架/证据不足条目，另6个非勾选宽范围；见下表及JSON，不重复登记或派发原提案。
- 测试：源tsc退出码0；vitest 439文件/4111通过/退出码0；合入预检冲突，未运行合后测试。未重跑；均nice19、单worker。
- 合入：未合入；持live-merge.lock预检19个记录/账本/生成表冲突，未执行实际合并。
- 需要 Roy 定的事（没有写「无」）：无。

修复仅涉及离线通知协议；不改游戏知识、对局行为或现有发布V5-R366，不新增eval版本。实际学习通知注册/发送/ACK未执行，676bee9f38912ae4c39c596a及watcher/Roy分角色回执仍由原owner续办；本批源码已提交、尚未上线。

原始证据：20261016-050119-fix-batch，thread01a1415e-a511-7131-be7c-a2dc691c847f；paper/materials/20261016-0625-ops/counterevidence-source.json、notice-registration-result.json。原register-feature exit2拒根learner/runs布局；已核原日志/消息SHA与真实注册报告路径，并只读调用新ack_feature验证通过。这是纯工具缺陷，没有对应对局run/floor/turn。CLI按feature、root-event、根目录查询bug-infra无对应条目，不新建或改shipped。

新增固定Python四用例覆盖注册幂等、各角色独立ACK、错误scratch/owner/task/cwd/thread、跨scratch报告/日志/消息、SHA、传输和符号链接负控；沿用旧worktree布局、普通proposal、B4/legacy通知测试。只撤ops/learning_requests.py源码，新增测试因feature original log outside registered worktree失败；恢复补丁后六个相关vitest文件通过。两次日志为without-fix.log/with-fix.log。

本批队列快照1346行，SHA256 46b389e2fd601f069b6cb15b40666c8839d0046a43b2af1db69d8bc53bffc673；旧1344行前缀完全保持。381个既有路径中，核基线仅eval/versions.json发布记录变化；ops/learning_requests.py差异是本批修复。其余源码与固定测试保持。来源祖先检查仅证明原范围，不把窄实现扩成宽父完成。

收尾读回队列1348行：仅在本批1346行快照后追加silent-0332的DHYFWEN40SJ7/F48重复补证，完整resources/steps与机制根因仍未知；原记录明确沿后续消费、不热注入本任务。没有新增纯bug或新的修复范围。原始快照保留，结束读回与差异为queue-final-readback.md/queue-final.diff；本任务没有编辑队列。

| 队列行 | 当前处置 | 已有提交 |
|---|---|---|
| 784 | 已修或已覆盖窄子项；不关闭更宽父项 | 3b48088dec5fc6eafe576a1296bbdadde43432ee |
| 789 | 已修或已覆盖窄子项；不关闭更宽父项 | 6403fdcdadc803a092beb5165a068e22bf51c412 |
| 793 | 已修或已覆盖窄子项；不关闭更宽父项 | 5c7105ff0294466da8319f2934beda05c6040794 |
| 797 | 已修或已覆盖窄子项；不关闭更宽父项 | ec29ea34b919344b707e57ba472ea210f9c39d62 |
| 801 | 已修或已覆盖窄子项；不关闭更宽父项 | e784dd9f043bf87c29109573f48975f9903280d3 |
| 810 | 策略类/沿原独立提案，宽父保持 | — |
| 817 | 已修：移除预览核对实际选牌页 | db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26 |
| 831 | 策略类/沿原独立提案，宽父保持 | — |
| 900 | 已修：rollout最佳线固定夹具确定性 | bbc5b993a7524bbb8e80a975f204f8d193657b46 |
| 912 | 策略类/沿原独立提案，宽父保持 | — |
| 918 | 策略类/沿原独立提案，宽父保持 | — |
| 923 | 已覆盖已观察A10升级手牌模板子项；其他输入沿原策略链 | b49112dbc106e315bd7156361d290fc4c73d29e2 |
| 929 | 已覆盖已观察A10两费十毒模板子项；A6及未知组合保持原边界 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| 930 | 策略类/沿原独立提案，宽父保持 | — |
| 935 | 策略类/沿原独立提案，宽父保持 | — |
| 940 | 已修或已覆盖窄子项；不关闭更宽父项 | 66c22ba7d87b8748690a4183fff838acd346bd3e |
| 945 | 策略类/沿原独立提案，宽父保持 | — |
| 952 | 策略类/沿原独立提案，宽父保持 | — |
| 953 | 策略类/沿原独立提案，宽父保持 | — |
| 954 | 策略类/沿原独立提案，宽父保持 | — |
| 955 | 策略类/沿原独立提案，宽父保持 | — |
| 959 | 证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知 | — |
| 964 | 策略类/沿原独立提案，宽父保持 | — |
| 968 | 已修或已覆盖窄子项；不关闭更宽父项 | c1d84804956bedbd29a7f0e81294114e18415b9d |
| 980 | 策略类/沿原独立提案，宽父保持 | — |
| 992 | 策略类/沿原独立提案，宽父保持 | — |
| 1001 | 策略类/沿原独立提案，宽父保持 | — |
| 1005 | 策略类/沿原独立提案，宽父保持 | — |
| 1009 | 证据不足：后续诊断已修，原历史发送事实未知 | — |
| 1020 | 策略类/沿原独立提案，宽父保持 | — |
| 1022 | 策略类/沿原独立提案，宽父保持 | — |
| 1024 | 已修或已覆盖窄子项；不关闭更宽父项 | 5baf663d7e6678efa3690e5a48329c4f8baee109 |
| 1029 | 已修或已覆盖窄子项；不关闭更宽父项 | 5b56a452bb9be14d620b368ec46974c1b57901ca |
| 1034 | 已修：目标/实际进阶分开 | 8045d9fbf0a12523b1dbe39bbed8af06c7497b09 |
| 1040 | 太大/独立框架：精确续验入口已实现，宿主收尾范围继续 | — |
| 1041 | 证据不足：未证明永久饥饿，沿原框架核查 | — |
| 1110 | 已修：eval/Apotheosis固定输入及有界夹具 | d9881ba593b0b8d701ebbe1c95626c0ebdd554c7, 9e8c93555131c3347f9e809d9722a848a75c2692 |
| 1294 | 策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项 | — |
| 1304 | 已修或已覆盖窄子项；不关闭更宽父项 | bae9c45ccffefb284a1c6634526c8768a9f5f7a8 |
| 1308 | 已修或已覆盖窄子项；不关闭更宽父项 | dd478f0b3e5a0f234f082972d21b203dbf8229d7 |
| 1322 | 已修或已覆盖窄子项；不关闭更宽父项 | 22efae55484bc2bdcc54e847a8dc40bb4888c4e2 |
| 1344 | 策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。 | — |

未修范围逐项：
- silent-0271：毒必胜提前返回遗漏保血候选 — 策略类/沿原独立提案，宽父保持
- silent-0279：SL抽序升级改标 — 策略类/沿原独立提案，宽父保持
- silent-0308：沙坑截止结束题面 — 策略类/沿原独立提案，宽父保持
- silent-0311：库存恢复血量预算 — 策略类/沿原独立提案，宽父保持
- silent-0320：同线新建UNMOVABLE — 策略类/沿原独立提案，宽父保持
- silent-0322：升级神化同线升级 — 策略类/沿原独立提案，宽父保持
- silent-0329：饮药临时力量接线 — 策略类/沿原独立提案，宽父保持
- arch-funnel-guard — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- arch-learning-priority — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- arch-unified-resource-value — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- inv-f33-regression — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- silent-0332：成功首战接续nonpositive-hp — 证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知
- silent-0334：升级隐秘匕首模型 — 策略类/沿原独立提案，宽父保持
- silent-0339：尾巴误核销 — 策略类/沿原独立提案，宽父保持
- silent-0344：坚韧之环延迟格挡 — 策略类/沿原独立提案，宽父保持
- silent-0347：组装师攻击召唤 — 策略类/沿原独立提案，宽父保持
- silent-0349：已有虚弱后的减力 — 策略类/沿原独立提案，宽父保持
- core-build-notify-222802-rc2：历史发送事实 — 证据不足：后续诊断已修，原历史发送事实未知
- silent-0362：背向攻击减力倍率 — 策略类/沿原独立提案，宽父保持
- silent-0365：未建模药水目标可达性 — 策略类/沿原独立提案，宽父保持
- 框架外层时限与分段续验收尾 — 太大/独立框架：精确续验入口已实现，宿主收尾范围继续
- 调度公平性核查 — 证据不足：未证明永久饥饿，沿原框架核查
- silent-0481：技能药水生命周期措辞 — 策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项
- silent-0487：MAD_SCIENCE三段攻击模型 — 策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。
- codex大脑缓存命中偏低 — 证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。
- sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因 — 证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。
- named-card-facts-transport：事件入口之外范围 — 太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。
- boss模拟样本性能及v5-dpr-health宽范围 — 太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。
- rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。
- silent-0469：纸鹤其他未知组合/整战收益 — 策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。
- live合入 — 持锁合并预检发现19个记录/账本/生成表冲突，按要求停止；源码已提交，未启动实际合并或合后测试。

持锁预检冲突文件（实际merge未启动，live HEAD保持92c3d22f191f0a79a4f0c56d29b189bd7185fca0）：
- notes/fix-queue-v4.md
- notes/for-roy.md
- notes/lessons.md
- notes/ops-handoff.md
- ops/inbox-dev.md
- paper/data/README.md
- paper/data/commits.csv
- paper/data/cost-curve-silent.csv
- paper/data/cost-silent.csv
- paper/data/cost-sources.json
- paper/data/cost-unattributed.csv
- paper/data/decisions_by_label.csv
- paper/data/learning-curve-silent.csv
- paper/data/runs.csv
- paper/data/summary.json
- paper/data/verification.json
- paper/materials/decision-log.md
- paper/materials/learning/ledger.jsonl
- paper/materials/silent/cost.md

完整逐条原文与代码SHA/来源祖先见audit.json；合入刷新重叠检查与提交见merge-result.json。原文队列未修改。gitleaks-source.log无泄漏；fix.diff保存固定源码与测试差异。无真实LLM/网络调用，无play、推送、停止对局或清理原工作树/日志。

```json
{
  "task": "fix-batch",
  "base": "84524bce1d7b57f42403b80e42082c62fc8cd158",
  "fixes": [
    {
      "item": "infra-feature-root-event-notice-path：合法根目录事件日志被通知注册拒绝",
      "commit": "577f0bc424b7287910735cfdc86c253cc7ee8057",
      "test": "agent/tests/feature-root-event-notice.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "silent-0271：毒必胜提前返回遗漏保血候选",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0279：SL抽序升级改标",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0308：沙坑截止结束题面",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0311：库存恢复血量预算",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0320：同线新建UNMOVABLE",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0322：升级神化同线升级",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0329：饮药临时力量接线",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-funnel-guard",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-learning-priority",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-unified-resource-value",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "inv-f33-regression",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "silent-0332：成功首战接续nonpositive-hp",
      "reason": "证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知"
    },
    {
      "item": "silent-0334：升级隐秘匕首模型",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0339：尾巴误核销",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0344：坚韧之环延迟格挡",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0347：组装师攻击召唤",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0349：已有虚弱后的减力",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足：后续诊断已修，原历史发送事实未知"
    },
    {
      "item": "silent-0362：背向攻击减力倍率",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0365：未建模药水目标可达性",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "框架外层时限与分段续验收尾",
      "reason": "太大/独立框架：精确续验入口已实现，宿主收尾范围继续"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：未证明永久饥饿，沿原框架核查"
    },
    {
      "item": "silent-0481：技能药水生命周期措辞",
      "reason": "策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项"
    },
    {
      "item": "silent-0487：MAD_SCIENCE三段攻击模型",
      "reason": "策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。"
    },
    {
      "item": "codex大脑缓存命中偏低",
      "reason": "证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。"
    },
    {
      "item": "sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因",
      "reason": "证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外范围",
      "reason": "太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。"
    },
    {
      "item": "boss模拟样本性能及v5-dpr-health宽范围",
      "reason": "太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。"
    },
    {
      "item": "silent-0469：纸鹤其他未知组合/整战收益",
      "reason": "策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。"
    },
    {
      "item": "live合入",
      "reason": "持锁合并预检发现19个记录/账本/生成表冲突，按要求停止；源码已提交，未启动实际合并或合后测试。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4111
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-064305-b38320f4-a88d-4543-abcd-2e5b154d3fbb-fix-batch/report.md"
}
```

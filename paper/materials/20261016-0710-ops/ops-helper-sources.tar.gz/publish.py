from pathlib import Path
import fcntl, hashlib, json, os, re, subprocess, tarfile

r = root = Path.cwd()
live = r / '.worktrees/live'
p = r / 'ops/codex-ops/record-staging/20261016-0710'
pub = r / 'paper/materials/20261016-0710-ops'
pub.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = '577f0bc424b7287910735cfdc86c253cc7ee8057'
base = '84524bce1d7b57f42403b80e42082c62fc8cd158'
template = (r / 'ops/codex-ops/record-staging/20261016-0240/publish.py').read_text()
exec(template[template.index('def git('):template.index('assert not (pub/')].replace('.ops-poison.tmp', '.ops-feature-root.tmp'))
def write(file, value): file.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
bid = '20261016-064301-fix-batch'
batch = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = batch['report']
scratch = Path(report['report']).parent
wt = Path(batch['worktree'])
checks = json.loads((scratch / 'verification.json').read_text())
assert checks['source_commit'] == source and checks['source']['exit'] == checks['source']['tsc'] == 0
assert checks['red_exit'] == 1 and checks['green_exit'] == 0 and (scratch / 'without-fix.exit').read_text().strip() == '1' and (scratch / 'with-fix.exit').read_text().strip() == '0'
assert sha((scratch / 'source-sandbox.log').read_bytes()) == checks['source']['sha256']
assert git('rev-parse', 'HEAD', cwd=wt).decode().strip() == source and not git('status', '--porcelain', '--untracked-files=no', cwd=wt).strip()
assert batch['rc'] == 0 and batch['merged'] is None and batch['state'] == 'failed'
exec((r / 'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text())
out = r / ('ops/codex-ops/learner/' + bid + '.out')
native = runtime(bid, report, out.read_text(), worktree=wt)
paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', source).decode().splitlines()
assert set(paths) == {'ops/learning_requests.py', 'ops/tests/test_feature_root_event_notice.py', 'agent/tests/feature-root-event-notice.test.ts'}
conflicts = json.loads((scratch / 'merge-result.json').read_text())
assert conflicts['merge_not_started'] and len(conflicts['conflicts']) == 19
write(pub / 'source-readback.json', dict(batch=bid, source=source, source_parent=base, source_checks=checks, native=native, original_failed_state_preserved=True, original_merge_result=conflicts, original_report=report, source_paths=paths, classification='Offline authenticated notice-path compatibility, no game behavior or release increment.'))
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as archive:
    manifest = []
    for f in sorted(scratch.iterdir()):
        if not f.is_file() or f.stat().st_size > 200_000 or f.suffix not in ['.json', '.md', '.log', '.exit', '.patch', '.diff']: continue
        archive.add(f, arcname=f.name, recursive=False)
        manifest.append(dict(path=str(f.relative_to(r)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
    for f in [out, out.with_suffix('.err')]:
        archive.add(f, arcname=f.name, recursive=False)
        manifest.append(dict(path=str(f.relative_to(r)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
write(pub / 'original-artifact-manifest.json', manifest)
assert not (pub / 'publication.json').exists()
with (r / 'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    print(at, flush=True)
    mh = git('rev-parse', 'HEAD').decode().strip()
    lh = git('rev-parse', 'HEAD', cwd=live).decode().strip()
    assert lh == '92c3d22f191f0a79a4f0c56d29b189bd7185fca0'
    active = subprocess.run(['pgrep', '-f', '/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'], capture_output=True)
    assert active.returncode == 1
    for cwd in [r, live]: assert not git('diff', '--cached', '--name-only', cwd=cwd).strip() and not git('ls-files', '-u', cwd=cwd).strip()
    before = {}
    for cwd in [r, live]:
        before[str(cwd)] = {x: sha((cwd / x).read_bytes()) for x in git('diff', '--name-only', 'HEAD', cwd=cwd).decode().splitlines() if x not in paths}
    values = {}
    livevalues = {}
    preserved_difference = None
    for path in paths:
        old = blob(base, path)
        raw = blob(source, path)
        oldlive = blob(lh, path, live)
        assert blob(mh, path) == old, path
        for cwd, prior in [(r, old), (live, oldlive)]: assert ((cwd / path).read_bytes() if (cwd / path).exists() else None) == prior, path
        values[path] = raw
        if oldlive == old:
            livevalues[path] = raw
        else:
            assert path == 'ops/learning_requests.py'
            stanza = b'        if (Path(root) / "ops/worktree_storage.py").is_file():\n            import worktree_storage\n            original = req["original_batch"]\n            if (Path(state_dir) / "retention/storage/source-copies" / (original + ".manifest.json")).is_file():\n                worktree_storage.restore_copies(Path(root), Path(state_dir), original)\n'
            assert old.count(stanza) == raw.count(stanza) == 1 and old.replace(stanza, b'') == oldlive
            merge = p / 'merge-input'
            merge.mkdir(exist_ok=True)
            for name, content in [('live', oldlive), ('base', old), ('source', raw)]: (merge / name).write_bytes(content)
            result = subprocess.run(['git', 'merge-file', '--stdout', str(merge / 'live'), str(merge / 'base'), str(merge / 'source')], capture_output=True)
            assert result.returncode == 0 and result.stdout == raw.replace(stanza, b'')
            livevalues[path] = result.stdout
            preserved_difference = dict(path=path, classification='Preserve the existing live absence of the unrelated five-line worktree-storage restore block; do not import it from main.', old_main_sha256=sha(old), old_live_sha256=sha(oldlive), new_source_sha256=sha(raw), new_live_sha256=sha(result.stdout), three_way_merge_clean=True)
        for lane, content in [('main', raw), ('live', livevalues[path])]:
            scan = p / 'source-scan' / lane / path
            scan.parent.mkdir(parents=True, exist_ok=True)
            scan.write_bytes(content)
    with (pub / 'source-composition-gitleaks.log').open('wb') as outscan:
        scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', str(p / 'source-scan'), '--redact', '--no-banner', '--report-format', 'json', '--report-path', str(p / 'source-gitleaks.json')], stdout=outscan, stderr=subprocess.STDOUT, env={**os.environ, 'GOMAXPROCS': '1'})
    assert scan.returncode == 0 and json.loads((p / 'source-gitleaks.json').read_text()) == []
    staged = []
    for cwd, head, label in [(r, mh, 'main'), (live, lh, 'live')]:
        env = {**os.environ, 'GIT_INDEX_FILE': str(p / (label + '.index'))}
        git('read-tree', head, env=env, cwd=cwd)
        for path, raw in (values if cwd == r else livevalues).items(): stage(path, raw, env, cwd)
        tree = git('write-tree', env=env, cwd=cwd).decode().strip()
        assert set(git('diff', '--name-only', head, tree, cwd=cwd).decode().splitlines()) == set(paths)
        new = commit(tree, [head, source], 'Integrate authenticated root-event feature notice compatibility', cwd)
        staged.append((cwd, head, env, new, tree))
    locks = locks_for([(x[0], x[2]) for x in staged])
    try:
        for cwd, head, env, new, tree in staged:
            assert git('rev-parse', 'HEAD', cwd=cwd).decode().strip() == head
            assert all(sha((cwd / path).read_bytes()) == value for path, value in before[str(cwd)].items())
        for cwd, head, env, new, tree in staged:
            git('update-ref', '-m', 'ops: exact three-leaf authenticated feature-notice fallback', 'HEAD', new, head, cwd=cwd)
            for path, raw in (values if cwd == r else livevalues).items(): install(cwd, path, raw)
        for index, lp in locks: os.replace(lp, index)
    finally:
        for _, lp in locks:
            if lp.exists(): lp.unlink()
    for cwd, head, env, new, tree in staged:
        assert not git('diff', '--cached', '--name-only', cwd=cwd).strip()
        git('merge-base', '--is-ancestor', source, 'HEAD', cwd=cwd)
        assert blob(head, 'eval/versions.json', cwd) == blob(new, 'eval/versions.json', cwd)
        assert git('rev-parse', head + ':agent/src', cwd=cwd) == git('rev-parse', new + ':agent/src', cwd=cwd)
        assert all(sha((cwd / path).read_bytes()) == value for path, value in before[str(cwd)].items())
    rec = dict(at=at, batch=bid, source=source, source_parent=base, old_main=mh, main=staged[0][3], old_live=lh, live=staged[1][3], tree=staged[1][4], source_paths=[dict(path=path, source_sha256=sha(raw), live_sha256=sha(livevalues[path])) for path, raw in values.items()], preserved_existing_script_difference=preserved_difference, source_actual_main_live_ancestor=True, unrelated_dirty_preserved=before, source_checks=checks, original_merge_conflicts_preserved=conflicts, release_id=None, release_increment=False, existing_behavior_release='V5-R366 unchanged', game_behavior_or_account_home_model_prompt_changed=False, host='pending single original064301-fix-batch request')
    write(pub / 'publication.json', rec)
    print(json.dumps({k: rec[k] for k in ['main', 'live', 'tree', 'release_id', 'source_actual_main_live_ancestor']}), flush=True)

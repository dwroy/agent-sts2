from pathlib import Path
import hashlib, json, os, subprocess, tarfile

r = Path.cwd()
p = r / 'ops/codex-ops/record-staging/20261016-0710'
pub = r / 'paper/materials/20261016-0710-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda f: json.loads(f.read_text())
def write(f, value): f.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], stderr=subprocess.PIPE)
assert not (p / 'own-appends.json').exists()
deployment = load(pub / 'publication.json')
registration = load(pub / 'formal-notice-registration.json')
delivery = load(pub / 'watcher-registration-native-send.json')
assert registration['register_exit'] == 0 and registration['own_ack'] == 'ops_forwarded' and registration['other_actor_CLI_calls'] == 0
assert delivery['transport_exit'] == 0 and delivery['transport_response']['result']['type'] == 'agent_prompted'
assert b'RUN' in (pub / 'host-start-log-prefix.txt').read_bytes()
base = git('rev-parse', 'HEAD').decode().strip()
assert base == deployment['main'] and not git('diff', '--cached', '--name-only').strip()
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(at, flush=True)
host = dict(at=at, batch=deployment['batch'], live=deployment['live'], tree=deployment['tree'], requested_once=True, request_command='bash ops/codex-ops-do.sh learner-recheck 20261016-064301-fix-batch', actual_log='ops/codex-ops/learner/20261016-064301-fix-batch.fallback-' + deployment['tree'] + '.checks.log', saved_start_prefix=dict(path='paper/materials/20261016-0710-ops/host-start-log-prefix.txt', sha256=sha((pub / 'host-start-log-prefix.txt').read_bytes())), vitest_RUN_observed=True, full_exit=None, stage='running; await original learner-checks event', source_full_not_repeated=True)
write(pub / 'host-start-receipt.json', host)
pending_dir = r / 'ops/codex-ops/pending-integrations'
pending_dir.mkdir(exist_ok=True)
write(pending_dir / '20261016-064301-notice-root-event.json', dict(at=at, batch=deployment['batch'], source=deployment['source'], main=deployment['main'], live=deployment['live'], tree=deployment['tree'], merge='complete precise3leaves', release='no new game behavior; V5-R366 unchanged', notice='676bee9f38912ae4c39c596a registered; ops_forwarded complete', watcher_stage_CLI='pending actual watcher execution; no other actor calls by ops', host='running single original pipeline; no repeat request', receipt='paper/materials/20261016-0710-ops/publication.json'))
note = f'\n- {at} [ops 0710原064301-fix窄差兜底] source577f0bc424b7287910735cfdc86c253cc7ee8057仅3叶已实际main {deployment["main"]}/live {deployment["live"]}/tree{deployment["tree"]}祖先：ops/learning_requests.py及两固定测试；原19记录/账本/生成表冲突不带入，live原缺少的5行storage恢复块精确保留，所有并行脏记录/知识与game源码逐SHA保持。纯离线通知兼容，不新增行为号，V5-R366/账号home模型预算/当前局不动。源原439文件4111项tsc0/vitest0/撤源码1恢复0、六定向绿已核原日志，未重跑源full；原宿主learner-recheck 064301-fix仅请求一次，精确251b0c366ffc51f54aaa8e3f1e0b8658d0b9d8ac已实际Vitest RUN，完整结果pending，不能借旧6f绿。原676bee9f38912ae4c39c596a register-feature现exit0，沿真实旧原生发送回执仅本人ops_forwarded exit0；源原文/日志/旧拒绝与watcher06:31实际告知字节保持，无新父/普通提案/重发Roy通知。新认证封套只追加旧真实native_delivery绑定，不改旧source文件。现有wJ:pJT/01a13dcd watcher已通过Herdr实际text+Enter提醒本人沿两旧receipt执行其两个阶段（transport0/agent_prompted），发送不当已读/CLI完成，ops未代填。0332资源尾部/steps与根因仍未知，18旧窄子项、24未修及6宽项保原范围，不新派研究。回执paper/materials/20261016-0710-ops/。\n'
decision = f'\n- {at} 运维codex：0710原064301-fix因19记录冲突实际merge未启动，canonical failed/rc0/mergednull原件保持；源码577f0bc4自测439文件4111全0与原撤码1恢复0、六定向/扫描0实核，原生Sol6.1/xhigh/原沙箱/input/lease核，按原兜底职责只3源码/测试叶绑定source真实main/live祖先。原首次严格叶相等预检发现live另缺既有storage恢复5行，未写入；清晰三方只合本修复并精确保留该差异，后继一次锁占用保原拒绝，实际无锁占用读回后完成窄差，全部19并行记录/表/知识及其他源码保持。main {deployment["main"]}/live {deployment["live"]}/tree{deployment["tree"]}；不加行为版本或修改eval列表，原V5-R366保留。单次原064301宿主请求已Vitest RUN，结果留待原learner-checks，不等待或重复源full/新pipeline。原root-event缺陷现用实际源/原日志/线程/消息SHA/原生运输封套注册676bee9f…成功，正式ops_forwarded仅本角色原真实receipt；原失败/原文/source字节不改，不新学习父/普通提案/伪ACK。经Herdr送同一既有watcher原生会话登记状态和两原回执路径，不再通知Roy、未代其CLI/用户ACK，不把运输作已执行。原0332及18已覆盖子项/24未修/6宽项按原回报继续，不把本通知修复称资源契约已修或宽父完成。当前局/模型账号home/prompt/预算不动；资料paper/materials/20261016-0710-ops/。\n'
queue = f'\n- {at} [原 **infra-feature-root-event-notice-path** 窄修复实际部署] 原064301-fix/source577f0bc424b7287910735cfdc86c253cc7ee8057已main {deployment["main"]}/live {deployment["live"]}，仅3叶、保live storage差异及并行记录；439文件4111源全检0/撤码1恢复0，宿主精确251b0c366ffc51f54aaa8e3f1e0b8658d0b9d8ac完整RUN待原事件。原676实际register-feature/ops_forwarded均exit0，只允许原注册batch/feature/character/worktree/launch.task/cwd/scratch/thread/SHA与真实运输，旧工作树布局与各角色独立ACK保持；旧source/报告/日志/失败不改，无新父/普通提案。现有watcher已原生收到登记提醒，用其两原receipt本人续CLI，不重复Roy通知、不代角色ACK。仅此路径缺陷源/实用登记闭环，宿主和后两CLI仍待验；0332/性能/其他宽父不关闭。证据paper/materials/20261016-0710-ops/。\n'
handoff = f'\n- {at} 原064301-fix兜底完成：source577f0bc4精确3叶main {deployment["main"]}/live {deployment["live"]}/tree251b0c366ffc51f54aaa8e3f1e0b8658d0b9d8ac，保19记录冲突和live5行storage差异、不带其他改动；无新行为号，V5-R366同。原唯一宿主064301-fix已RUN/结果pending，后继按pending-integrations/20261016-064301-notice-root-event.json接原learner-checks，不重复check。原676 registry及本ops_forwarded已0，冻结源封套绑定原真实运输、旧拒绝/原文/source保持；同wJ:pJT/01a13dcd已原生送登记提示，两watcher角色CLI需本人沿原watcher_received.receipt.json/roy_notified.receipt.json执行，不重发Roy/不代ACK。原0332及其DHY补证/各宽父继续待证，当前局和账号home模型prompt/预算不动。回执paper/materials/20261016-0710-ops/。\n'
appends = {'ops/inbox-dev.md': note, 'paper/materials/decision-log.md': decision, 'notes/fix-queue-v4.md': queue, 'notes/ops-handoff.md': handoff}
write(p / 'own-appends.json', appends)
values = {}
for path, text in appends.items():
    with (r / path).open('ab') as f: f.write(text.encode())
    values[path] = git('show', base + ':' + path) + text.encode()
write(pub / 'record-registration.json', dict(at=at, base=base, source=deployment['source'], actual_main=deployment['main'], actual_live=deployment['live'], tree=deployment['tree'], behavior_version_increment=False, source_full='original439files4111passed', host_full='running original unique064301 channel', registered_notice='676bee9f38912ae4c39c596a', own_formal_ack='ops_forwarded only', other_role_CLI='pending actual watcher execution', existing_watcher_transport='actual text+Enter; not read/ACK', new_research_or_implementation_dispatches=0, game_actions=0, wide_parents='remain open'))
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    helpers = []
    for f in sorted(p.glob('*.py')):
        archive.add(f, arcname=f.name, recursive=False)
        helpers.append(dict(path=str(f.relative_to(r)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
write(pub / 'ops-helper-manifest.json', helpers)
with tarfile.open(pub / 'ops-attempt-logs.tar.gz', 'w:gz') as archive:
    for f in sorted(p.iterdir()):
        if f.is_file() and f.suffix in ['.stdout', '.stderr']: archive.add(f, arcname=f.name, recursive=False)
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'
entries = []
for path, raw in values.items():
    f = dest / path
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(p / 'record-manifest.json', dict(base=base, paths=entries))
print(json.dumps(dict(record_paths=len(entries), source_paths=3, notice_registered=True, own_ack_only=True, host_full='running', release_increment=False)))

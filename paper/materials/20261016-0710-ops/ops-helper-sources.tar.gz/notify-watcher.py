from pathlib import Path
import hashlib, json, os, subprocess

r = Path.cwd()
pub = r / 'paper/materials/20261016-0710-ops'
assert os.environ.get('HERDR_ENV') == '1'
assert not (pub / 'watcher-registration-native-send.json').exists()
assert json.loads((pub / 'formal-notice-registration.json').read_text())['register_exit'] == 0
get = subprocess.run(['herdr', 'agent', 'get', 'wJ:pJT'], capture_output=True)
assert get.returncode == 0
agent = json.loads(get.stdout)['result']['agent']
assert agent['agent_session']['value'] == '01a13dcd-83d4-7c63-b233-f93cf878ecf4' and agent['cwd'] == str(r)
assert agent['agent_status'] in ['done', 'idle']
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
text = f'【原676bee9f38912ae4c39c596a程序登记接续，非新研究/实现】{at} 原064301普通fix的root-event路径修复source577f0bc424b7287910735cfdc86c253cc7ee8057已三叶窄合live2806f8bd8376e9e6e83c296226d9209b386d7292/tree251b0c366ffc51f54aaa8e3f1e0b8658d0b9d8ac，保既有storage差异/知识/记录，不加行为号、不动现局。原676实际register-feature exit0，ops本人仅沿原真实发送回执登记ops_forwarded exit0；正式notice在ops/codex-ops/learning-notices/676bee9f38912ae4c39c596a.json，原文/旧失败/源与原生消息不改。请本人沿既有paper/materials/20261016-watcher-notice-676bee9f38912ae4c39c596a/watcher_received.receipt.json及roy_notified.receipt.json执行你两个分角色CLI阶段；原06:31用户可见通知证据继续用，不需再次通知Roy，不代其他角色ACK。程序注册回执paper/materials/20261016-0710-ops/formal-notice-registration.json。原064301精确树唯一宿主full已实际RUN，结果pending，0332/宽父及原70输入差保持；不新派任务、模型、实验或重启。此运输不冒认你已读或CLI已执行。'
message = pub / 'watcher-registration-message.txt'
message.write_text(text)
sent = subprocess.run(['herdr', 'agent', 'prompt', 'wJ:pJT', text], capture_output=True)
(pub / 'watcher-registration-transport.stdout').write_bytes(sent.stdout)
(pub / 'watcher-registration-transport.stderr').write_bytes(sent.stderr)
response = json.loads(sent.stdout) if sent.returncode == 0 else None
receipt = dict(at=at, notice_id='676bee9f38912ae4c39c596a', purpose='Existing watcher submits its two original independent role receipts; no second Roy notification', target_pane='wJ:pJT', existing_agent=agent, message_sha256=hashlib.sha256(message.read_bytes()).hexdigest(), transport_exit=sent.returncode, transport_response=response, no_new_task_or_actor_ack=True, watcher_role_CLI_completion='pending actual watcher execution')
(pub / 'watcher-registration-native-send.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
assert sent.returncode == 0 and response['result']['type'] == 'agent_prompted'
print(json.dumps(dict(transport_exit=0, existing_native_session=agent['agent_session']['value'], watcher_role_cli='pending; no wait')))

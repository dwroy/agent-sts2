from pathlib import Path
import hashlib, json, subprocess

r = Path.cwd()
p = r / 'ops/codex-ops/record-staging/20261016-0710'
pub = r / 'paper/materials/20261016-0710-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def ref(path):
    f = r / path
    return dict(path=path, sha256=sha(f.read_bytes()))
def write(f, value): f.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
deployment = json.loads((pub / 'publication.json').read_text())
assert deployment['source'] == '577f0bc424b7287910735cfdc86c253cc7ee8057' and deployment['release_increment'] is False
notice_id = '676bee9f38912ae4c39c596a'
destination = r / ('ops/codex-ops/learning-notices/' + notice_id + '.json')
original_source = json.loads((r / 'paper/materials/20261016-0625-ops/counterevidence-source.json').read_text())
source = dict(original_source)
source['native_delivery'] = dict(message=ref('paper/materials/20261016-0625-ops/counterevidence-native-message.txt'), receipt=ref('paper/materials/20261016-0625-ops/ops-forwarded-receipt.json'))
source_file = pub / 'authenticated-original-feature-source.json'
write(source_file, source)
if destination.exists():
    existing = json.loads(destination.read_text())
    frozen = json.loads((r / existing['source_evidence']['path']).read_text())
    assert existing['source_kind'] == 'feature' and existing['request_id'] == source['feature_request']
    assert frozen['original_message'] == original_source['original_message'] and frozen['original_log'] == original_source['original_log']
    source_file = r / existing['source_evidence']['path']
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(at, flush=True)
register = subprocess.run(['nice', '-n', '19', 'python3', 'ops/learning_requests.py', 'register-feature', '--notice', notice_id, '--source', str(source_file)], capture_output=True)
(pub / 'notice-register.stdout').write_bytes(register.stdout)
(pub / 'notice-register.stderr').write_bytes(register.stderr)
assert register.returncode == 0 and register.stdout.decode().strip() == notice_id
notice = json.loads(destination.read_text())
assert notice['notification_only'] and notice['registered_learning_request'] is False
receipt = 'paper/materials/20261016-0625-ops/ops-forwarded-receipt.json'
if not notice['ops_forwarded']:
    ack = subprocess.run(['nice', '-n', '19', 'python3', 'ops/learning_requests.py', 'ack', '--notice', notice_id, '--stage', 'ops_forwarded', '--receipt', receipt], capture_output=True)
    (pub / 'ops-ack.stdout').write_bytes(ack.stdout)
    (pub / 'ops-ack.stderr').write_bytes(ack.stderr)
    assert ack.returncode == 0
else:
    (pub / 'ops-ack.stdout').write_text('Original ops receipt already registered; no duplicate ACK.\n')
    (pub / 'ops-ack.stderr').write_bytes(b'')
notice = json.loads(destination.read_text())
assert notice['ops_forwarded'] and notice['ops_forwarded']['sha256'] == sha((r / receipt).read_bytes())
write(pub / 'formal-notice-registration.json', dict(at=at, notice_id=notice_id, source=ref(str(source_file.relative_to(r))), notice_snapshot=notice, original_producer_source_unchanged=ref('paper/materials/20261016-0625-ops/counterevidence-source.json'), original_failed_registration_preserved='paper/materials/20261016-0625-ops/notice-registration-result.json', register_exit=0, own_ack='ops_forwarded', original_ops_receipt=ref(receipt), other_actor_CLI_calls=0, prior_independent_role_evidence='paper/materials/20261016-0637-ops/ops-independent-role-evidence-readback.json', no_resend_or_new_parent=True, publication=deployment['live']))
pending_file = r / ('ops/codex-ops/pending-deliveries/' + notice_id + '.json')
pending = json.loads(pending_file.read_text())
pending.update(registration='registered original feature notice', ops_forwarded='registered from original actual receipt', formal_receipt=str((pub / 'formal-notice-registration.json').relative_to(r)), role_CLI_registration='watcher to submit its two original independent receipts; ops has not submitted them')
write(pending_file, pending)
print(json.dumps(dict(notice_id=notice_id, registered=True, ops_forwarded=True, watcher_formal=bool(notice['watcher_received']), Roy_notification_formal=bool(notice['roy_notified']), other_actor_CLI_calls=0)))

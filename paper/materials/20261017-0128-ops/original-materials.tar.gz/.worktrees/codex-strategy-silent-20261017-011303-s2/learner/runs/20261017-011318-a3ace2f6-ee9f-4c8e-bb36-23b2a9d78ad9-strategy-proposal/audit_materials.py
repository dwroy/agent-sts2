import hashlib
import importlib.util
import json
from pathlib import Path

out = Path(__file__).resolve().parent
workspace = out.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
batch = json.loads((out / 'batch.json').read_text())
runs = batch['runs']

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

extractor = module('evidence', workspace / 'learner/extract_evidence.py')
resources = module('resources', workspace / 'learner/resource_chain.py')
streams = {}
verified = []
for directory in ['evidence', 'evidence-streams']:
    for info in json.loads((out / directory / 'evidence-manifest.json').read_text()):
        name = info['stream']
        path = out / directory / (name + '.evidence.jsonl')
        assert name not in streams
        assert hashlib.sha256(path.read_bytes()).hexdigest() == info['output_sha256']
        rows = [json.loads(line) for line in path.open()]
        counts = dict.fromkeys(runs, 0)
        with (root / 'logs' / (name + '.jsonl')).open('rb') as source:
            for item in rows:
                assert item['offset'] + item['bytes'] <= info['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert extractor.run_identity(item['row']) == item['run_id']
                counts[item['run_id']] += 1
        assert counts == info['counts']
        streams[name] = rows
        verified.append(info)
assert set(streams) == set(extractor.STREAMS)
for item in streams['runs']:
    assert item['row']['character'] == 'SILENT' and item['row']['ascension'] == 10
for item in streams['states']:
    assert item['row']['state']['run']['character_id'] == 'SILENT'
    assert item['row']['state']['run']['ascension'] == 10

proposals = json.loads((out / 'assigned-proposals.json').read_text())
assert list(proposals) == batch['proposal_ids']
for ident, history in proposals.items():
    original = history[0]['row']
    assert original['character'] == 'silent' and set(original['runs']) <= set(runs)
    assert hashlib.sha256(Path(original['proposal']).read_bytes()).hexdigest() == original['proposal_sha256']
    assert hashlib.sha256((out / (ident + '.md')).read_bytes()).hexdigest() == original['proposal_sha256']

fixtures = []
by_line = {item['line']: item for item in streams['states']}
for name in ['silent-survivor-sandpit-evidence.json', 'silent-serpent-mirage-replay-evidence.json', 'silent-wither-visible-state.json']:
    path = workspace / 'agent/tests' / name
    count = 0
    for item in json.loads(path.read_text()):
        if item.get('run_id') not in runs:
            continue
        actual = by_line[item['line']]
        for key in ['line', 'offset', 'bytes', 'sha256', 'run_id', 'row']:
            assert item[key] == actual[key], (name, item['line'], key)
        count += 1
    fixtures.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'matching_frames': count})

chains = {}
inputs = []
for run in runs:
    starts = {}
    for item in streams['sl-attempts']:
        row = item['row']
        if item['run_id'] == run and row.get('attempt', 1) > 1 and row.get('started_at'):
            starts.setdefault(row.get('floor'), []).append(row['started_at'])
    entries = [{**i['row'], '_line': i['line']} for i in streams['states'] if i['run_id'] == run]
    chain = resources.resource_chain(entries, run, 'silent', starts)
    (out / (run + '-resource-chain.json')).write_text(json.dumps(chain, ensure_ascii=False, indent=2) + '\n')
    chains[run] = [{'sequence': c['sequence'], 'floor': c['floor'], 'entry': c['entry'],
                    'last': c['last'], 'exit': c['exit'], 'end': c['end'],
                    'observed_net_hp_loss': c['observed_net_hp_loss']} for c in chain['combats']]
    decisions = [{**i['row'], '_line': i['line']} for i in streams['decisions'] if i['run_id'] == run]
    excluded = [d for d in decisions if not d.get('decision_id')]
    consumer = {'run': next(i['row'] for i in streams['runs'] if i['run_id'] == run),
                'states': entries, 'decisions': [d for d in decisions if d.get('decision_id')]}
    target = out / (run + '-selection-input.json')
    target.write_text(json.dumps(consumer, ensure_ascii=False) + '\n')
    inputs.append({'run': run, 'states': len(entries), 'decisions': len(consumer['decisions']),
                   'excluded_missing_id': [{'line': d['_line'], 'label': d.get('label')} for d in excluded],
                   'input': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})

selected = {}
for item in streams['decisions']:
    if item['line'] in {290765, 291285, 291333, 291334, 291596, 291646}:
        selected[str(item['line'])] = item
(out / 'selected-decisions.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
result = {'streams': verified, 'total_verified_rows': sum(sum(s['counts'].values()) for s in verified),
          'proposal_count': len(proposals), 'fixtures': fixtures, 'resource_chains': chains, 'consumer_inputs': inputs}
(out / 'evidence-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': result['total_verified_rows'], 'fixtures': fixtures,
                  'combat_windows': {run: len(cs) for run, cs in chains.items()},
                  'consumer_inputs': inputs}, ensure_ascii=False))

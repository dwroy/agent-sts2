# 本批策略提案回报

本批十个原提案均完成逐项核验，最终全部waiting。已覆盖的子实现均核到实际live源码祖先；没有足够证据新增策略或重新拟定终局、药水、SL参数。本批无源码/知识改动、提交或live合入，不造版本或shipped。

基线和最终HEAD均为 `426bce8f82c455cf22facd70c80133a4d2d6f9b1`；起始工作树干净，同步main返回Already up to date，最终tracked/index/untracked状态仍干净。本批普通提案队列，无research_request/implementation_request，未读取其他专题替代身份；十ID与宿主原行终核一致。

## 证据与材料核验

两局均runs.jsonl已核SILENT/A10：LYBHQ1X230ZB F30负局，旧执行5925a43d+dirty；H1T1F8ML9FUE F48负局，旧执行1a0adbaa+dirty。完整当时dirty源码/知识输入缺失，当前基线不当历史执行树。SL尝试不增加独立局数；旧deepseek_calls计数字段不作为实际脑引擎证据。

共用extractor冻结八流，2815选中原行逐offset/bytes/SHA/JSON/显式身份回读通过；10原Markdown逐SHA与队列匹配。3个生存者固定夹具帧、2个群蛇蜃景固定夹具帧与本批原行逐字段一致。凋萎旧夹具无本批局号，只核其源祖先，不据0匹配推断证据不存在。

|流|独立冻结source_size字节|LYB行数|H1行数|全源坏JSON行|
|---|---:|---:|---:|---:|
|runs|353455|1|1|0|
|states|13720925986|478|930|2|
|decisions|2104136014|455|844|2|
|sl-attempts|44333229|5|9|0|
|run-config|1906230|1|1|0|
|run-plans|8723742|4|9|0|
|brain|709741394|28|49|2|
|fight-plans|2233957|0|0|0|

fight-plans在本截点选中0，不声称原日志不存在；各流截点独立，坏JSON为整条源流计数。run-plans另按旧截点8498804只提本两局，4/9行及选中输出SHA与新截点8723742完全相同；原目录和新目录分别保留，没有覆盖初稿。

现有resource_chain在固定封套重算17/28战斗窗口。LYB F22/F23出口65→36→6、F28到火先回15至42后锻造、F29胜42→4、F30前三试无出口末试4→0；H1 F35 max70→64、F46 33/64无净损、F48六试同52/64空药进入，前五无退出末试实死，F49未到。HP净损不等敌人毛伤，SL恢复不算回血或新药。

30项原帧事实/算术核验通过（material-checks.json），包括LYB两候选损12/18、伤22/31及H1同12伤却损0/3、弃逃离后续沙坑1、T9延坑、蜃景重放8挡和盾/本体各4变化、纸伤max变化与无损反方向。这些不是生产回归用例，不计为tsc/vitest/cases成功。

## 当前离线消费者与失败原件

同一冻结输入通过现有learner/audit-selection.ts和八个递归源码依赖，仅关联日志观察，不跑模型/网络/战斗模拟。两局478/930状态、455/844带ID决策全部可入；无需排除缺ID行。当前输出分别65/122片段、78/137轮窗口，共1299动作、187片段和215轮窗口。完整候选结果字段全为null（认证0），是工具契约边界，不证明实际未执行，也不把片段净HP归给整条候选。

tsx CLI首次两局均exit1，只因沙箱禁止IPC listen（EPERM），原空输出/stderr及consumer-results.json保留。改用node --import ./agent/node_modules/tsx/dist/loader.mjs运行同一未变工具/输入，两局均exit0，stderr空；consumer-node-import-results.json保存命令/输出SHA。本次原帧校验与离线消费者是材料审计，不是生产测试或上线收益。

## 已有源码与发布边界

只读核实际live HEAD=`5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922`。19引用源码叶18与live逐字节相同；card-model.ts两处仅历史Roy/Dai注释署名差，原patch保留。没有将有限叶SHA当整棵历史dirty源码或生产联合校准。

- `39a3bdb948c13f4d84e2c644c9a08a9a3543c16b`：Expose Silent Sandpit facts during Survivor discards；base祖先=True，实际live祖先=True。
- `be9577c81a003aff0e69968c928e264f5173da7c`：Model observed Silent Mirage replay Serpent triggers；base祖先=True，实际live祖先=True。
- `9b65f1bee0f26ced606ec256fc3d173db48caa3e`：Fix Silent Wither damage from visible combat piles；base祖先=True，实际live祖先=True。
- `1698adc96ba434a46942321e0237b70657e625b2`：Complete Silent SL resource comparison audit；base祖先=True，实际live祖先=True。
- `608478393b0491c9d77441d06b7a402994987f42`：Expose Silent Sandpit escape facts during Prepared discards；base祖先=True，实际live祖先=True。

外部发布引用：可见凋萎文本同步V4-R324、群蛇蜃景重放V5-R356、生存者沙坑事实V5-R370。它们是旧上线的窄范围，不是本批新增发布；旧源码报告当时未live的事实保留，本批按现已live更新追溯。其他修饰组合/整战/受控后继缺口仍在。

## 十项最终处置

证据局号、层、回合、原账本、反例、预期行为和验证方法逐项见proposal.md及原Markdown；此处列最终原因。

|原ID|状态|具体缺口|
|---|---|---|
|silent-proposal-8e9beeee55eac364|waiting|LYB F29T6损12留10的候选没有实际执行至下一房；已选损18留4线T7赢、F30败，不能由6HP差拟终局权重，缺替线完整资源后继。|
|silent-proposal-ce75cb821e8f2610|waiting|LYB步法、臂甲首次挡、暗影和柔嫩已有局部模型；缺本盘完整修饰组合、首次消费与次轮复原的联合消费者校准，未定位新的可隔离数值失配。|
|silent-proposal-6ba977a3f01df016|waiting|LYB F30前三试截断、末试结15毒后仍有两敌；缺替代目标及抽序的完整执行、召唤与重放的整线误差校准，不改SL判据。|
|silent-proposal-2097f02b69dacfff|waiting|LYB F29石虫眩晕及甲虫弱后15/16/18攻击可核；缺双敌成长、弱化和眩晕跨轮的完整消费者校准与可比后继，不拟固定击杀序。|
|silent-proposal-49bb659734d555e3|waiting|LYB F29T6少损6HP线未实打；缺该线后场资源、F28休息替代及未到营火的受控结局，保留终局、持药与SL权重。|
|silent-proposal-2ae7436286228166|waiting|H1 F48T3同12伤而替线多付3HP可核，生存者沙坑事实子项39a3bdb948c13f4d84e2c644c9a08a9a3543c16b已是live祖先；仍缺完整候选未来收益及同入口整战对照。|
|silent-proposal-de26499e8385f25b|waiting|H1 F48未赢、F49未到；饮用、主动丢弃、交换与SL恢复须分账，缺留药或换饮时点的受控后继及完整资源消费者误差归因。|
|silent-proposal-c888545b80180da7|waiting|H1 F45T5群蛇蜃景重放窄子项be9577c81a003aff0e69968c928e264f5173da7c已是live祖先；其他敏捷、脆弱、临时力量撤回和组合消费尚未联合核齐，不能整体implemented。|
|silent-proposal-3b37b520b22f0eaf|waiting|H1末T4建毒雾和触媒时敌仍0毒、未到下一玩家轮；已有制品和毒基础路径，缺匹配后继及后期完整误差校准，不预支未来结毒。|
|silent-proposal-b259f9956e08088a|waiting|H1凋萎可见缓存9b65f1bee0f26ced606ec256fc3d173db48caa3e及生存者沙坑提示已live；仍缺饱和换线完整收益、纸伤逐击消费者和独立整战验证，宽项保留。|

## 记录、测试与交接

仅经根learner/ledger.py update一次追加30条本角色where/note追溯，CLI exit0；输入、stdout/stderr、逐物理offset/bytes/SHA和保护核验保留。旧物理前缀SHA、30条账本claim/首证/prior/evidence/status/version/shipped/effect及history/notes/where前缀均保持。不重复登记support/repeat，不另造提案ID或历史复盘；既有shipped不代表本批宽项已实现。

无新增源码，撤源码负控/恢复测试不适用，tsc、vitest、cases均null；没有运行生产测试、gitleaks或git commit，也无本批合入提交、版本及待回退新补丁。工作树保持base、干净；源码/知识及其他角色行为未变，未推送、运行play、联网、改prompt/凭据或派下级agent。本会话未独立读取原生请求model/effort，不把启动默认值冒作实际模型核验。

交运维：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-011303-s2/learner/runs/20261017-011318-a3ace2f6-ee9f-4c8e-bb36-23b2a9d78ad9-strategy-proposal/proposal.md`、`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-011303-s2/learner/runs/20261017-011318-a3ace2f6-ee9f-4c8e-bb36-23b2a9d78ad9-strategy-proposal/report.md`及result.json。十个waiting项保留待新证据重派；已有窄源不关闭更宽父要求。本批没有待兜底的源码提交或合入阻塞。所有原日志、初稿、失败回执与现场保留，不自行回收。

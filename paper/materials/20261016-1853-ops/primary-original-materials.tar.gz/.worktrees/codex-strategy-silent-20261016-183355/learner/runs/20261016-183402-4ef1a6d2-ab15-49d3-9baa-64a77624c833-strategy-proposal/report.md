# 静默猎手策略消费批次 20261016-183355-strategy-proposal

本批逐项复核十个已领取提案，结果全部为 `waiting`。没有新增源码、知识、参数、提交或 live 合入；已有诊断仅计为原提案的局部实现，没有把它们登记为整项 duplicate/implemented。等待原因是下列具体执行归属与后继数据缺口，不是因规则由人制定而要求重新审批。

基线：`a73af7b4ee4839cfd2f54677b86ff5d610e29936`；`git status --short` 开工为空，普通提案按要求执行 `git merge --no-edit main`，返回 Already up to date。当前 live 只读核对提交为 `c0cab0352b6c1a487e116d845350bf483dc60c9c`。本批 root learn.json 的 task/character/worktree/runs/proposal_ids 已核，reason=proposal；没有 research_request、implementation_request 或 proposal_repair。普通专题配置绑定的是另一批，条件不匹配，因此本批保持原十项消费任务。未写根请求、调度状态或旧提案。

本批仅使用以下六局；runs.jsonl 原始身份逐行保存在 run-identity.json，均为 SILENT A10。日志中的 +dirty 代码标识原样保留，未假称已复原当时的完整源码、移动表和知识输入。任务文字要求普通/high；可访问的本批原生错误日志未提供可独立核实的 model/reasoning/service-tier 字段，未以默认配置冒称运行模型已核，未改模型、账号、权限或线程。全程独立完成，未派子 agent，未联网、调模型、运行 play 或模拟池。

| 局号 | states | decisions | SL行 | run-plans |
|---|---:|---:|---:|---:|
| 751FN9QM9MHQ | 624 | 615 | 6 | 2 |
| KV0JHNJCKXLS | 686 | 669 | 7 | 5 |
| YQL8RZ8BWN1E | 582 | 571 | 6 | 3 |
| L9SGRBB5R698 | 653 | 635 | 6 | 3 |
| PU80F84P6HPN | 1064 | 1033 | 12 | 5 |
| KEN58SH9SLZ6 | 558 | 548 | 6 | 3 |

共用 extract_evidence.py 实际提取八流，固定各流 source_size；8,444 行全部重读源 offset/bytes/SHA256、JSON 与显式身份并匹配计数及输出 SHA。完整封套和 evidence-manifest.json 均保留。states/decisions 各2、brain 1条无效行属于全源扫描统计，不据此断言本批缺帧或补造行。fight-plans 在本截点匹配0行，仅说明此流此截点未选到，不能证明不存在其他证据。没有复用旧截点或覆盖旧报告。

以下十项均保留原 CLI id；每份原 Markdown 先核 proposal_sha256，再按原字节保存在本批 *.original.md。关联账本共16项均为本角色既有条目；不新增 support/repeat，不改首证、先验、结论或已上线状态。

| 提案 id | 证据局/层/回合/原行 | 原账本 id | 本批处置及缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820 | silent-0079, silent-0176 | waiting：缺抽弃/重问后的完整候选身份、逐来源实结算与同后轮整战对照；已有SL预测/单动作回执不闭合实际资源归属。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3；F17 T7/T13/T17；decisions 272361；states 278500—278505 | silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176 | waiting：未决弃牌及持药未知已有窄字段；缺751 F13不饮药的实际整战、留药后战与完整候选执行对照，不从缺表0拟持有价。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13；同366288原帧 | silent-0079, silent-0176 | waiting：与366288同源六试相关；缺完整后继和独立验证，现有预测拆项未认证整条候选，不据局部5/10血差关掉探索。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17；decisions 272361，states 278500—278505 | silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176 | waiting：已有持牌/药水诊断与分项模型；缺攻击、毒、荆棘、持牌损血和敏捷的联合逐来源校准及跨战用药对照。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 第4/5试T5；states 279460—279465/279511—279515；末试T4 279559—279560 | silent-0102, silent-0019, silent-0020 | waiting：KV F33T5敌净扣36/29、后轮毒20/13得到复核；缺毛伤/回血的逐来源完整执行与路线休息替代后继，不能把删毒称保血。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T10 states 280160/280161；L9 F17 T14 sl 681；PU F17 T17 sl 717 | silent-0017, silent-0250, silent-0011, silent-0027, silent-0046 | waiting：本体/自爆与毒水事实已有实现；SL参考排序仍保留原占位HP，缺新旧排序完整后继及提前喝/不喝/留药受控分支。 |
| silent-proposal-9733bb80f445aeae | YQL8RZ8BWN1E F17 T10；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 第5试T15 states 252435/252436 | silent-0017, silent-0019, silent-0020, silent-0250 | waiting：残壳毒2→8未变41自爆及PU余2血胜反例成立；缺改序与用药时点的受控整战，不用阶段展示替代完整阶段估值。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272 | silent-0019 | waiting：七次用药请求和槽位变化已核，三次接口仍pending；缺随机选牌/发光水重问后的完整方案归属及保留至Boss的对照。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 第4/5试T10 decisions 274505/274568，states 280588—280592/280651—280655；第4/6试T5 274484/274601 | silent-0079, silent-0021, silent-0125, silent-0005, silent-0176 | waiting：KEN T10同盘多2敌净损付6血、T5省2血但未建敏捷均复现；缺逐来源兑现、相同后轮及时间靠后的独立验证。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T2/T5/T10；decisions 274354/274484/274601/274505/274568 | silent-0021, silent-0079, silent-0125, silent-0176 | waiting：血价与能力窗口双向取舍有证据；已有预测与观测工具仍不认证完整候选，缺受控后继，不拟通用6血/2伤阈值。 |

## 固定证据与反例

1. 751FN9QM9MHQ F17：T2首/第三试同指纹，states 278479→278483 与278620→278623，净损13→18、敌净扣9→18；T7第二/第四试278576→278581 与278697→278702，净损13→23、敌净扣12→18；T13首/末试278528→278532 与278865→278869，净损8→2、敌净扣17→11。三组都只有局部取舍，六试全败仍是一局。decisions 272575/272652/272820保留原答、SL替换、B2配对差/误差及允许更差未试线的原理由。未决弃牌引入的保守绝对误差和换线差额分开。
2. 751 F13T3 decisions 272361：plan2有药预测损8/伤26，plan3与plan5均损8/伤16；plan3的后续样本7/8仍饮药，只有plan5明确整战不饮药。不能把当轮不喝当整战不用，也不能将药表未加载时成本0当实测持有价值0。无药完整实盘与留到后战的收益未知。
3. KV0JHNJCKXLS F33第四/五试T5：states 279460→279465 /279511→279515，均零净损、敌净扣36/29，随后毒20/13。末试279559→279560由327血/15毒变342血/14毒，与原毒结15后回30的观察一致。净血差本身不是逐来源毛伤记录；不把未打输出写成保血，也不补齐前五试被SL截断的轮末结算。路线/营火替代分支仍未执行。
4. YQL8RZ8BWN1E F17T10：states 280160/280161，毒药使残壳毒2→8，玩家26血/13挡、自爆41均未变，槽0由POISON_POTION变空。阶段上本体已结束，但战斗未赢。L9SGRBB5R698 F17T14和PU80F84P6HPN F17T17的旧anchor仍有近十亿占位HP。跨本体到残壳的净HP差不当伤害或回血。反例PU同局F17第5试T15：252435为24血/20挡对42，252436实际奖励页2血；这排除“本体结束即胜利”，也不能证明提前喝药或新排序必胜。
5. KEN58SH9SLZ6 F17第四/五试T10：274505/274568同指纹，280588→280592 /280651→280655实净损15/21、敌净扣2/4；B2差−0.2583、SE0.0132来自原日志，不当观测胜率。反向例第4/6试T5同指纹，280567→280572 /280684→280689净损7/5、敌净扣1/2；280572已建2敏捷，280689未建该能力，省血不等于保留能力收益。后续动作、抽序及重问同时变化，不能单步归因整战。
6. KEN七次用药：F3T2、F4T1、F5T2、F11T1/T2、F15T1，七个原请求与相应槽位由有药变空均核；274131/274237/274272的接口仍是pending。完整请求、槽位、receipt逐项在 fixed-facts.json；不把pending改成completed，不以空栏认证整条候选或随机选牌收益。未饮药、留药至Boss及后战分支未知。

这些结论与旧账本的限定观察一致，未发现新的机制反证或需要改写的旧claim。反例和未知如上保留，不能把普通负局当公式反例，也不能用没有执行的分支支持原假设。未拟合权重、留药价或6血/2伤等门槛；六局及同局SL不能同时拆作训练和独立验证。更早局只作原发现，新局验证须有真实后续独立证据，本批没有将旧锚点冒称新后期样本。

## 现有源码与消费者

19个相关源码叶已按基线与指定live提交核SHA及最近源码提交祖先关系；16叶字节相同，potion-cost.ts、explore.ts、controller.ts仅历史Roy/Dai注释署名差，完整选定差异保存在base-live-selected.patch。关键已有实际live祖先源码：

| 已有子项 | 实际源码 commit | 本批核到的边界 |
|---|---|---|
| SL资源预测 | 1698adc96ba434a46942321e0237b70657e625b2 | current_turn_prediction，execution=unverified，不是实际扣血或完整后继 |
| 持牌失血/候选阶段 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | total/held/incoming和未决弃牌单列；actual_held_hp_loss及actual_turn仍null |
| 持药未知/无药参考 | c4670f4f416c7d93e192e889c5080e7e4e0e733f | hold_hp=null，当前不喝/抽样整战无药分开；不提供留药真实价值 |
| 单动作回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | single_action_receipt，state_effect_verified=false，whole_plan_executed=null |
| 巨兽毒水阶段说明 | 40168f4a903ae1d8c48bd03006f8fea19fd3aa3c | 保存280160/280161原事实，不改必死、排序或强迫用药 |
| 巨兽阶段/末态资源 | b01edf46b4b619f217d070a196e161df9fe716a0 | giant_phase与特定已核末态预算分开；anchorRank仍沿enemyHpLeft原始显示HP平局排序 |

本批实际调用当前learner/lib/selection-execution.ts消费六局冻结输入；read_consumers.mjs保留原物理行号和SHA，只将缺decision_id/observed_ts的6条map/route-change元数据从消费者输入排除，封套原件完整。未给这些行补ID。单局输入SHA可由原封套、排序规则及helper重建；压缩/展开输出SHA逐局保留。

消费者共4,065条带ID决策、4,167状态、861个选线片段、2,336个相邻观测端点、5个终局端点、415个回合端点窗口和362个未知窗口。完整候选认证为0是该工具明确不做归因的契约，**不是零执行率、缺失全部日志或已证线上故障**。窗口含重问后的动作，敌人类型/索引不能作持久实例身份；净HP、能力变化、药栏端点不能代替逐来源结算。未运行新模型、模拟或线上消费者，不宣称实际大脑已采用本报告。

## 预期行为、验证与回退

当前行为保留。原提案已完成的窄诊断不重复实现；未完成的执行归属、联合校准、完整后继和跨战比较继续沿原id等待。若取得数据，依各原提案固定原题/最终线/续问动作，保持同后轮或明确分开模拟与实际反事实；按独立局真实时间切分调参与留出验证，再判断是否改探索、持药或排序。无关角色及未观察进阶不外推。

本批逐源封套16项一致性检查和固定端点59项材料核验均通过，六个现有离线消费者调用退出0。这些是证据核验，**不充作tsc/vitest/cases或生产校准通过**。无源码撤除/恢复测试，理由为没有源码改动；未运行生产测试，不借历史通过。不提交、不合入、不建eval版本、不标shipped，不需回退行为。原始失败、SL截断、未知与旧提案均保留。

账本只经根learner/ledger.py update追加本批proposal/report位置及具体waiting备注，by=learner:strategy-proposal；16个旧条目原状态/版本/首证/先验/claim/evidence保持。不重复登记support/repeat，不将已shipped历史条目退成proposed，不生成重复代码提案id。实际物理追加与私有fold保全检查见ledger-readback.json。根learn.json/专用提案队列由调度器消费最终proposal_results，本模型不直接改状态。

实际回报见result.json；源码及知识零差异、HEAD仍等于base，材料保存在git忽略的本批learner/runs内。proposal.md为本批逐项提案汇总，应交运维；本批没有已上线规则通知或游戏版本。

最终验收：ledger.py check退出0；16条本批CLI追加逐物理offset/bytes/SHA读回，原物理前缀与私有fold关键字段保持。gitleaks dir退出0（扫描175.85 MB，无泄露）；HEAD/base相同，git status为空，源码/知识零差异。详见completion-check.json。

# 只读探索中的限制与失败

本文件保存探索失误，不将其登记为产品缺陷或游戏机制反例。

- 首次源码路径定位误猜了 agent/src/combat、agent/src/loop.ts、agent/src/core/loop.ts、agent/src/sl/giant.ts、agent/src/reflex/potion-facts.ts；命令返回不存在。后续以 rg --files 定位实际 hand/loop.ts、sl/attempts.ts 和 silent-giant-potion.ts，最终引用及SHA审计全部使用真实路径。
- 原YQL复盘目录的 verification.json 探测返回不存在，未据此否定证据；本批重新通过共用提取器生成封套并逐源校验。
- 第一个临时摘要把非战斗帧 combat=null 交给 list，工具回执 chunk d74de0 返回如下错误。没有写生产文件，未据此推断原state缺失；之后统一使用 combat or {}，审计脚本及59项固定核验均通过。

```text
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
TypeError: 'NoneType' object is not iterable
```

- 两次较长的临时stdout摘要未保存执行会话编号，未将其输出列作验证依据。最终所有结论只使用本批已保存的 evidence-audit.json、fixed-facts.json、六个消费者压缩输出及对应日志。
- 初步逐轮打印曾显示本体转残壳时约负十亿的敌净血差；这仅说明跨阶段相减不适用，不解释为回血或伤害。固定事实核验要求端点敌人类型与最大HP相同，巨兽阶段转换单列。
- 原始日志的全源无效行计数及fight-plans本截点0行均原样保留。未覆盖零行初稿、旧失败、原Markdown或旧复盘；没有由这些现象补造游戏结论。

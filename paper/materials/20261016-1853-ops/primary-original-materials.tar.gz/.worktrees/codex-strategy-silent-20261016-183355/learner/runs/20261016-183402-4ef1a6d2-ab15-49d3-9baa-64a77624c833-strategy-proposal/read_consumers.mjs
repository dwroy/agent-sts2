import { createReadStream, writeFileSync } from "node:fs";
import { createInterface } from "node:readline";
import { createHash } from "node:crypto";
import { gzipSync } from "node:zlib";
import { fileURLToPath } from "node:url";
import { auditSelectionExecution } from "../../lib/selection-execution.ts";

const out = fileURLToPath(new URL(".", import.meta.url));
const groups = new Map();
const excluded = [];
for (const stream of ["runs", "states", "decisions"]) {
  const lines = createInterface({ input: createReadStream(`${out}evidence/${stream}.evidence.jsonl`), crlfDelay: Infinity });
  for await (const line of lines) {
    const item = JSON.parse(line);
    const input = groups.get(item.run_id) ?? { run: null, states: [], decisions: [] };
    groups.set(item.run_id, input);
    const row = { ...item.row, _line: item.line, _source_sha256: item.sha256 };
    if (stream === "runs") input.run = row;
    else if (stream === "decisions" && (!row.decision_id || !row.observed_ts)) {
      excluded.push({ run_id: item.run_id, source_line: item.line, sha256: item.sha256,
        label: row.label ?? null, reason: "缺 decision_id 或 observed_ts；保留原行，不造身份" });
    } else input[stream].push(row);
  }
}

const summaries = [];
for (const [run, input] of groups) {
  input.decisions.sort((a, b) => a.observed_ts.localeCompare(b.observed_ts) || a._line - b._line);
  const inputText = JSON.stringify(input);
  const result = auditSelectionExecution(input);
  const outputText = JSON.stringify(result);
  const zipped = gzipSync(outputText);
  writeFileSync(`${out}${run}.consumer.json.gz`, zipped);
  summaries.push({ run, input_decisions: input.decisions.length, input_states: input.states.length,
    input_sha256: createHash("sha256").update(inputText).digest("hex"),
    output_sha256: createHash("sha256").update(outputText).digest("hex"),
    compressed_sha256: createHash("sha256").update(zipped).digest("hex"),
    segments: result.segments.length, observed_actions: result.observed_actions.length,
    adjacent_observed_endpoints: result.observed_actions.filter((a) => a.observed_interval.status === "observed_endpoints").length,
    terminal_observed_endpoints: result.observed_actions.filter((a) => a.terminal_observation?.status === "observed_terminal_endpoints").length,
    observed_turn_endpoints: result.observed_turns.filter((a) => a.status === "observed_turn_endpoints").length,
    unknown_turn_windows: result.observed_turns.filter((a) => a.status === "unknown").length,
    certified_full_candidates: result.segments.filter((a) => a.actual_full_candidate_result !== null).length });
}
writeFileSync(`${out}consumer-summary.json`, JSON.stringify({ summaries, excluded }, null, 2) + "\n");
console.log(JSON.stringify({ summaries, excluded }));

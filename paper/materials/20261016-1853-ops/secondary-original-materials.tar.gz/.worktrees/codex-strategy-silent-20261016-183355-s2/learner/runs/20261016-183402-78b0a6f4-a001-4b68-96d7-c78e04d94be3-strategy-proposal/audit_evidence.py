"""Audit frozen evidence bytes and retain bounded, own-character observations."""
import hashlib
import json
from collections import Counter
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
from extract_evidence import run_identity


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def reference(envelope):
    return {key: envelope[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def summary(envelope):
    row = envelope['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **reference(envelope), 'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'), 'screen': state.get('screen'),
        'floor': run.get('floor'), 'turn': state.get('turn'),
        'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': player.get('max_hp', run.get('max_hp')),
        'block': player.get('block'), 'energy': player.get('energy'),
        'played': player.get('cards_played_this_turn'), 'powers': player.get('powers', []),
        'hand': [dict(card_id=c.get('card_id'), upgraded=c.get('upgraded'), values=c.get('dynamic_values'))
                 for c in combat.get('hand', [])],
        'potions': run.get('potions', []),
        'enemies': [{key: e.get(key) for key in ('index', 'enemy_id', 'current_hp', 'block', 'powers', 'move_id', 'intents')}
                    for e in combat.get('enemies', [])],
    }


def main():
    manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
    expected_runs = set(json.loads((HERE / 'verified-runs.json').read_text()))
    output = {'streams': [], 'checks': []}
    states = {}
    by_timestamp = {}
    compact = []
    for stream in manifest:
        name = stream['stream']
        counts = Counter()
        digest = hashlib.sha256()
        source = ROOT / 'logs' / (name + '.jsonl')
        with source.open('rb') as raw, (HERE / 'evidence' / (name + '.evidence.jsonl')).open('rb') as evidence:
            for encoded in evidence:
                digest.update(encoded)
                envelope = json.loads(encoded)
                assert envelope['run_id'] in expected_runs
                assert run_identity(envelope['row']) == envelope['run_id']
                assert envelope['source'] == str(source)
                assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
                raw.seek(envelope['offset'])
                original = raw.read(envelope['bytes'])
                assert hashlib.sha256(original).hexdigest() == envelope['sha256']
                assert json.loads(original) == envelope['row']
                counts[envelope['run_id']] += 1
                if name == 'states':
                    state = envelope['row']['state']
                    character = (state.get('run') or {}).get('character_id')
                    assert character is None or character.lower() == 'silent'
                    states[envelope['line']] = envelope
                    for key in ('ts', 'observed_ts'):
                        timestamp = envelope['row'].get(key)
                        if timestamp:
                            by_timestamp[(envelope['run_id'], timestamp)] = envelope
                    compact.append(summary(envelope))
        assert digest.hexdigest() == stream['output_sha256']
        assert {run: counts[run] for run in expected_runs} == stream['counts']
        output['streams'].append({'stream': name, 'source_size': stream['source_size'], 'rows': sum(counts.values()),
                                  'counts': stream['counts'], 'output_sha256': digest.hexdigest(),
                                  'invalid_lines': stream['invalid_lines'], 'incomplete_lines': stream['incomplete_lines']})
    write('states-summary.json', compact)
    write('evidence-byte-audit.json', output)

    def check(label, condition, lines):
        output['checks'].append({'label': label, 'pass': bool(condition),
                                 'evidence': [reference(states[line]) for line in lines]})
        assert condition, label

    def player(line):
        return states[line]['row']['state']['combat']['player']

    def enemies(line):
        return states[line]['row']['state']['combat']['enemies']

    def power(enemy, ident):
        return next((p['amount'] for p in enemy.get('powers', []) if p['power_id'] == ident), 0)

    for floor, before, after in [(43, 281312, 281313), (45, 281338, 281339), (46, 281367, 281368),
                                (48, 281399, 281400), (49, 281565, 281566)]:
        check(f'TXZ F{floor} 新战开场净失4', player(before)['current_hp'] - player(after)['current_hp'] == 4
              and player(after)['cards_played_this_turn'] == 0, [before, after])
    check('TXZ F49 可操作前HP归零，敌仍111', player(281566)['current_hp'] == 0
          and enemies(281566)[0]['current_hp'] == 111, [281565, 281566])
    check('WQ 第2/3次T9 同指纹26HP/敌184',
          states[282075]['row']['fingerprint'] == states[282144]['row']['fingerprint']
          and player(282075)['current_hp'] == player(282144)['current_hp'] == 26
          and enemies(282075)[0]['current_hp'] == enemies(282144)[0]['current_hp'] == 184, [282075, 282144])

    cunning = json.loads((Path.cwd() / 'agent/tests/silent-cunning-evidence.json').read_text())
    for i, item in enumerate(cunning):
        a = by_timestamp[(item['run'], item['before_ts'])]
        b = by_timestamp[(item['run'], item['after_ts'])]
        before = a['row']['state']['combat']; after = b['row']['state']['combat']
        added = sum(c['card_id'] == 'SHIV' for c in after['hand']) - sum(c['card_id'] == 'SHIV' for c in before['hand'])
        check(f'WQ 固定狡诈饮用{i+1}: {item["before"]}手添{item["added"]}',
              len(before['hand']) == item['before'] and len(after['hand']) == item['after'] and added == item['added']
              and before['player']['current_hp'] == after['player']['current_hp']
              and before['player']['energy'] == after['player']['energy'], [a['line'], b['line']])
    q6 = [282887, 282888, 282889, 282890, 282891, 282892]
    hp = [enemies(line)[0]['current_hp'] for line in q6]
    check('Q6 F8 T4 紧勒/后续牌/弃牌完成/毒分帧', hp == [103, 95, 85, 85, 83, 80], q6)
    check('Q6 紧勒建立2，过轮消失', power(enemies(282888)[0], 'STRANGLE_POWER') == 2
          and power(enemies(282892)[0], 'STRANGLE_POWER') == 0, [282888, 282892])
    check('NHA F17 首毒5实建10', power(enemies(283146)[0], 'POISON_POWER') == 0
          and power(enemies(283147)[0], 'POISON_POWER') == 10, [283146, 283147])
    check('NHA F33 首次萎靡实际-2力/2弱',
          power(enemies(283395)[0], 'STRENGTH_POWER') == -2
          and power(enemies(283395)[0], 'WEAK_POWER') == 2, [283395])
    write('evidence-audit.json', output)
    print(json.dumps({'streams': [{'stream': s['stream'], 'rows': s['rows']} for s in output['streams']],
                      'material_checks': len(output['checks']), 'passed': all(c['pass'] for c in output['checks'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()

"""Describe observed turn boundaries without certifying candidate execution."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
rows = json.loads((HERE / 'states-summary.json').read_text())
targets = {'KEN58SH9SLZ6': [5, 15, 17], 'TXZ6RVMQA09D': [48, 49], 'WQZVENQ7DTRP': [33],
           '1913SE84AXQF': [17, 29, 31], 'Q6M2Y34MWKRE': [2, 8, 9], 'NHA2KW0RB7VP': [17, 33]}
windows = []
checks = []


def brief(row):
    return {key: row[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id', 'floor', 'turn',
                                     'hp', 'max_hp', 'block', 'energy', 'played', 'powers', 'enemies')}


for run, floors in targets.items():
    for floor in floors:
        selected = [r for r in rows if r['run_id'] == run and r['floor'] == floor and r['enemies']
                    and r['screen'] in ('COMBAT', 'CARD_SELECTION', 'GAME_OVER') and isinstance(r['turn'], int)]
        attempts = []
        last_turn = None
        for row in selected:
            if last_turn is None or row['turn'] < last_turn:
                attempts.append({})
            attempts[-1].setdefault(row['turn'], {'first': row, 'last': row})['last'] = row
            last_turn = row['turn']
        for number, turns in enumerate(attempts, 1):
            windows.append({'run_id': run, 'floor': floor, 'observed_attempt': number,
                            'turns': [{'turn': t, 'first': brief(v['first']), 'last': brief(v['last'])} for t, v in turns.items()]})


def edge(run, floor, attempt, turn):
    found = next(w for w in windows if w['run_id'] == run and w['floor'] == floor and w['observed_attempt'] == attempt)
    turns = {v['turn']: v for v in found['turns']}
    start, end = turns[turn]['first'], turns[turn+1]['first']
    # NHA's first raw snapshot precedes opening HP/enemy effects; use the observed actionable board.
    if (run, floor, attempt, turn) == ('NHA2KW0RB7VP', 33, 1, 1):
        start = brief(next(row for row in rows if row['line'] == 283391))
    enemy_before = sum(e['current_hp'] for e in start['enemies'])
    enemy_after = sum(e['current_hp'] for e in end['enemies'])
    return {'hp_loss': start['hp'] - end['hp'], 'enemy_net_loss': enemy_before - enemy_after,
            'start': start, 'next_turn': end, 'last_action_state': turns[turn]['last']}


for run, floor, attempt, turn, expected in [
    ('TXZ6RVMQA09D', 48, 2, 6, (3, 36)), ('TXZ6RVMQA09D', 48, 3, 6, (0, 27)),
    ('WQZVENQ7DTRP', 33, 2, 9, (13, 24)), ('WQZVENQ7DTRP', 33, 3, 9, (22, 39)),
    ('WQZVENQ7DTRP', 33, 2, 7, (0, 24)), ('WQZVENQ7DTRP', 33, 6, 7, (4, 24)),
    ('NHA2KW0RB7VP', 33, 1, 1, (1, 8)), ('NHA2KW0RB7VP', 33, 5, 1, (7, 24)),
    ('NHA2KW0RB7VP', 33, 6, 1, (7, 24)),
]:
    result = edge(run, floor, attempt, turn)
    passed = (result['hp_loss'], result['enemy_net_loss']) == expected
    checks.append({'run_id': run, 'floor': floor, 'observed_attempt': attempt, 'turn': turn,
                   'expected_hp_loss_and_enemy_net_loss': expected, 'pass': passed, 'result': result})

report = {'scope': '实际相邻回合端点；不是完整候选执行认证，也不是受控整战因果比较',
          'windows': windows, 'checks': checks}
(HERE / 'window-review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks': len(checks), 'passed': sum(c['pass'] for c in checks),
                  'windows': len(windows), 'checks': [{k: c[k] for k in ('run_id', 'observed_attempt', 'turn', 'pass')} for c in checks]}, ensure_ascii=False))
assert all(c['pass'] for c in checks)

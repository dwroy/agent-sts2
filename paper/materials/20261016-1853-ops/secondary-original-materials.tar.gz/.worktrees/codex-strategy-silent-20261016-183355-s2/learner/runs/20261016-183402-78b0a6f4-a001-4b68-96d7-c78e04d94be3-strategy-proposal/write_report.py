"""Write the bounded proposal review and its machine-readable disposition."""
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
proposals = json.loads((HERE / 'selected-proposals.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)
reasons = [
    'KEN F15零净损同时耗两药已核；缺F15不饮用及相同入口/后继下将药留到Boss的完整成对结果，不能校准持药价值。',
    'TXZ F48 T6少损3同时少伤9、F49开场4→0已核；缺保持抽序、生成牌、药栏和后续选择一致的连续两战替线与联合校准。',
    'WQ T9多15伤付9血、T7付4血延长沙坑的相邻回合端点已核；缺攻防/沙坑两边界的受控整战后继和独立验证，不拟固定血伤交换或SL门槛。',
    '狡诈3/2/0生成及穿插子模型已有live祖先；缺计划妥当保留容量、跨重问完整候选派发与SL恢复的联合消费者校准，不能关闭整项。',
    '王室猛毒开场4血与连战传递已有受限实现；缺未知回血/复活组合顺序、留药/路线/SL完整受控后继及联合资源校准。',
    '1913/Q6的胜战退出与下一战入口支持资源链风险；缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果，不能拟新权重。',
    '普通紧勒受限公式已有live祖先，弃牌完成后触发已核；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准和受控后继。',
    '1913/Q6实际回复与后战血价仍是观察链；缺另一营火、事件、路线及用药时机的受控完整结果，不能由两败校准路线或终局权重。',
    'NHA六次同局的1/7损血与8/24敌净扣端点已核，精确切击被弃后重规划；缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继。',
    '蟹朝向取整子实现已有live祖先，首毒/萎靡局部实效已核；缺油灯首次消费跨动作、新战/SL恢复的联合输入，未覆盖X值/升级组合及能力整战后继。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': r} for p, r in zip(proposals, reasons)]
result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-183355-s2-strategy-proposal',
    'base': base, 'runs': json.loads((HERE / 'dispatch-row.json').read_text())['runs'],
    'fixes': [], 'skipped': [],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [p['id'] for p in proposals], 'implementation_domains': [],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

intro = f"""# 本批策略提案逐项复核

本批：20261016-183355-s2-strategy-proposal；角色：静默猎手；记录时间：{stamp}。
基线：{base}。普通十项消费队列；dispatch行没有research_request、implementation_request或proposal_repair。专题请求绑定别批，未读取另一专题。工作树开工干净，git merge --no-edit main为Already up to date。

结论：本批未发现足以调整现有规则的完整对照，十项均waiting。已经上线的子实现只作范围核对，不代替宽提案全部验收。fixes=[]、merged=null；没有本批源码提交、行为版本、shipped、撤源码测试或生产tsc/vitest成功声明。其他角色行为保持。

依据只取本角色证据；派发十局保留原顺序。原提案另外明确引用的1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR五局也先从runs.jsonl验角色后提取，不是扩领其他提案。共十五局，A1/A7/A9/A10分开，同局重复尝试不当独立局。

## 固定材料与核验

十份原Markdown的保存SHA全部匹配队列，原字节副本为silent-proposal-*.md.txt，来源与账本见selected-proposals.json；31个相关账本原快照为ledger-before.json。来源任务仍为各原postmortem/experience-update，实现任务为本strategy-proposal。

使用共用learner/extract_evidence.py，八流共19,929行：states 9815、decisions 9448、sl-attempts 78、run-config 15、run-plans 77、brain 481、runs 15、fight-plans 0。每流source_size、逐局计数及输出SHA在evidence/evidence-manifest.json；每行source/line/offset/bytes/SHA在对应evidence.jsonl。所有选中行均按原offset seek复核字节SHA、JSON和显式身份，拒绝冲突身份。fight-plans为本截点零选中，不据此判断原日志缺失。原全流无效行states 2、decisions 2、brain 1，其余0；未把它们当本角色证据或生产故障。

audit_evidence.py r2为29/29固定材料检查；review_windows.py r2为9/9相邻回合检查，保存31个有界尝试/战斗窗口。前者逐字节审计19,929行；后者只核真实端点，均不是生产测试、模型模拟或完整候选执行认证。结果分别为evidence-audit.json、window-review.json；源码/固定测试19叶SHA在source-audit.json。

材料首稿按ts查旧夹具的observed_ts而KeyError，原脚本及audit.stderr.log保留；修正同时读取两字段后完成。窗口首稿误把NHA首战开场效果前的原始帧283390当可操作帧，得到-1HP/28净扣而非1/8；原window-review-r1.json、脚本及失败日志保留，改用有据的283391再核后9/9。原始首帧28HP、两敌219/209，效果后30HP、209/199；不推断缺分项的开场20伤来源，也不把核验错误当游戏反例。另一次只读探查猜错silent-first-debuff.ts路径，实际不存在。一次生成报告工具调用因JS语法错误未执行，后改为本目录脚本生成；没有生产文件变化。

## 现有live范围

只读快照live：{source['live_head']}。19叶中14叶字节相同，5叶仅历史Roy/Dai署名注释差；完整差异在base-live-source.patch。不由这些叶推断全知识输入相同。

- 狡诈生成/手位：6403fdcdadc803a092beb5165a068e22bf51c412是实际live祖先；同名侧支15ea09ad75a421d4bd65a820c187c8ee188186c8不是祖先。当前modelPotion限silent A7/A9/A10，基础6、现场力/弱、手位与锁定牌分账；固定测试包含3/2/0及穿插，未在本批重跑。
- 普通紧勒：5c7105ff0294466da8319f2934beda05c6040794是live祖先；当前仅已观察普通A0/A10、无挡/无特殊交互分支，弃牌未决会阻断续步，不把符合单次公式说成整场联合校准。
- 朝向取整：ec29ea34b919344b707e57ba472ea210f9c39d62是live祖先；当前silent-crusher-facing从同进阶数据库读取已观察基伤，保留弱的分数后再核朝向；2f775是合并祖先记录，不单当新实现。
- 连战：e1a467e18a0dfa8d99046a24ff4c0e1af59278c8、5b56a452bb9be14d620b368ec46974c1b57901ca、66283dd9982bdd7f480da7a4d9bfefea0572a9ac是实际live祖先；样本HP/剩药/复活传递、无复活观察分支开场血价均存在。未知回血/自动复活组合不由本证据补齐。
- SL对比：1698adc96ba434a46942321e0237b70657e625b2是live祖先；当前字段scope=current_turn_prediction、execution=unverified，delta对随机药中位线或缺线为null。explore仍按B2 notWorse/deathShare及既有排名取未试线，本批没有充分证据改门槛。
- 10c53de98c54b118660b8a478bbdedba548dd1c8为经验发布合并，不能仅因其是祖先就称油灯源码已完成。

"""
evidence = [
    'KEN58SH9SLZ6 A10：F3T2/F4T1/F5T2/F11T1、T2/F15T1七次use_potion；F5赢战53→16、F15两饮后零净损。账本silent-0019/0020。决策原字节在potion-action-summary.json所列ken_refs，赢战窗口在window-review.json。',
    'TXZ6RVMQA09D A10 F48第2/3次T6：同48HP、敌460，下一轮实损3/0、敌净扣36/27；第三次首胜剩4，F49 states281565→281566为4→0、敌111未伤且出牌0。账本silent-0228/0255。',
    'WQZVENQ7DTRP A10 F33第2/3次T9：states282075/282144同指纹26HP/敌184，下一轮13/22损、24/39敌净扣；第2/6次T7为0/4损、同净扣24。账本silent-0079/0018；沙坑延长是反对一律只保血的约束，内部先致死原因仍未知。',
    'WQZVENQ7DTRP A10 F33 T11：第五次8手连饮添2/0/0，末次5手添3/2/0；29项检查含18次原夹具饮用的原始前后状态，HP/能量不变。其余8个提案引用局的角色均核实，原9局42饮统计本批不重新宣称全量复算。账本silent-0030/0257/0258。',
    'TXZ6RVMQA09D A10 F43/45/46/48/49开场五组逐帧净失4；WQ同盘攻防与沙坑两边界见上。账本silent-0018/0019/0020/0021/0025/0079/0198/0228/0255；未知小血瓶/复活顺序不外推。',
    '1913SE84AXQF A10 F17/F29/F31与Q6M2Y34MWKRE A10 F2/F8/F9的原始窗口已保存；Q6 F8T4紧勒输出23、下一轮HP33，最后精英赢仅剩2接F9。早喝候选非完整实打，不能据低置信候选认定可救局。账本silent-0019/0020/0050/0253。',
    'Q6M2Y34MWKRE A10 F8T4 states282887—282892：敌103→95→85→85→83→80，CARD_SELECTION阶段85不提前扣，完成弃牌才83、下轮层消失。1913SE84AXQF F31弃磨蚀原提案保留，普通施放模型不能代替弃牌效果全链。账本见原提案11项，特别silent-0261/0044/0259/0253。',
    '1913SE84AXQF A10 F29胜后46进F31、Q6M2Y34MWKRE A10 F8胜后2进F9的真实窗口；原提案F24实际锻造、未来火未抵达，事件/幕间/战内再生与SL仍分账，未从两个失败链拟合新参数。账本silent-0019/0020/0021。',
    'NHA2KW0RB7VP A10 F33第1/5/6次T1，实际可操作30HP/敌总408；相邻轮原线损1/净扣8、替线损7/净扣24。decisions277248/277250/277272/277274显示原含精确切击的计划经生存者弃牌后重问，不能把首题四牌认证为整轮执行。账本silent-0079。',
    'NHA2KW0RB7VP A10 F17T1 states283146→283147毒0→10，F33T1 states283395首次萎靡实际−2力/2弱；K3676LU8B0UH A1与SADL3CGYTGSR A7原提案支持窗仍保留，但不把本批2个局部检查冒称原17窗全核。账本原14项，特别silent-0264/0265/0169/0053。',
]
sections = []
for number, (p, r, e) in enumerate(zip(proposals, results, evidence), 1):
    ledgers = ', '.join(p['ledger'])
    sections.append(f"""## {number}. {p['id']}

原提案：{p['proposal']}；原SHA：{p['proposal_sha256']}。

{e}

全部关联账本：{ledgers}。

现规则/建议：沿原提案要求比较当步事实、已兑现资源与真实后继；有界子公式按上列源码保持，完整候选与整场收益分开。

处置：**waiting**。{r['reason']}

下一步验证：仅在新增本角色完整证据可覆盖此缺口时继续；机制按冻结原帧验证，参数按独立run和开始时间前后切分，同一局SL同组。保留反例和缺帧；没有完整已执行替线就不将模型输出当实盘获益。预期影响、回退仍沿原提案；本批没有实际变更可回退。

""")
ending = """## 验证、记账与交付限制

本批不改agent/learner/eval/ops/knowledge生产源码或知识数据；scratch中的Python仅为保留的离线材料分析。没有需要提交或合入live的源码，因此生产tsc、vitest、撤源码失败/恢复通过、gitleaks提交扫描均未运行，tests三项null。无新git提交、eval版本或上线通知；merge=live流程不为纯waiting造空合并。

本批只经根learner/ledger.py update为31个既有条目补where.proposal及note，by=learner:strategy-proposal。未新增claim/evidence、重复support/repeat或改status/version/shipped。CLI输入、标准输出、物理逐行offset/bytes/SHA以及私有fold核对另存ledger-*；原提案id继续使用，不另建重复id或直接改队列。

未重放历史dirty源码/完整knowledge输入，未运行boss模拟、LLM或网络；现有固定测试只读源码，不能借它们声明本批消费者通过或生产校准完成。当前29+9材料检查不覆盖原提案全部历史样本、不提供胜率提升证据。运行模型/服务档/推理强度无法由本任务可用只读证据独立核实，本批未改运行配置或另开会话。

以上未发现需要新增或强行改写旧机制结论的反证；材料核验的两次首稿失败明确保留，不当游戏反例。缺证项目维持waiting，父学习要求和后续实际live经验/消费者验收不因本报告关闭。

运维交付：本目录proposal.md、report.md、result.json；逐项proposal_results以result.json为准。已存在的live子实现及非祖先侧支在source-audit.json分列，不登记本批implemented/shipped。
"""
body = intro + ''.join(sections) + ending
(HERE / 'proposal.md').write_text(body)
(HERE / 'report.md').write_text(body + '\n最终机器回报见同目录result.json。\n')
print(json.dumps({'base': base, 'report': str(HERE / 'report.md'), 'proposal_count': len(results)}, ensure_ascii=False))

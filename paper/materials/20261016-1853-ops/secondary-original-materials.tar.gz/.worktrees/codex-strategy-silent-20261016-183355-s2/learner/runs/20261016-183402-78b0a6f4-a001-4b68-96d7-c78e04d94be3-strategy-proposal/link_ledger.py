"""Append trace links through the ledger CLI without changing learned claims."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
import ledger

proposals = json.loads((HERE / 'selected-proposals.json').read_text())
results = {r['id']: r for r in json.loads((HERE / 'result.json').read_text())['proposal_results']}
identifiers = sorted({i for p in proposals for i in p['ledger']})
path = ROOT / 'paper/materials/learning/ledger.jsonl'
prefix = path.read_bytes()
before = ledger.fold(ledger.read_rows(str(path)))
changes = []
for ident in identifiers:
    own = [p for p in proposals if ident in p['ledger']]
    note = '20261016-183355-s2-strategy-proposal：' + '；'.join(p['id'] + ' waiting：' + results[p['id']]['reason'] for p in own)
    note += '。本批仅where/note追溯；未新增证据、支持/重犯计数、状态或源码。'
    changes.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]}, 'note': note})
payload = ''.join(json.dumps(c, ensure_ascii=False) + '\n' for c in changes)
(HERE / 'ledger-update-input.jsonl').write_text(payload)
(HERE / 'ledger-cli-before.json').write_text(json.dumps({i: before[i] for i in identifiers}, ensure_ascii=False, indent=2) + '\n')
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)
environment = dict(os.environ)
environment['TMPDIR'] = str(HERE)
execution = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'],
                           input=payload, text=True, capture_output=True, env=environment)
(HERE / 'ledger-cli.stdout.log').write_text(execution.stdout)
(HERE / 'ledger-cli.stderr.log').write_text(execution.stderr)
assert execution.returncode == 0, execution.stderr
current = path.read_bytes()
assert current[:len(prefix)] == prefix
tail = current[len(prefix):]
offset = len(prefix)
records = []
rows = []
for raw in tail.splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and row.get('note', '').startswith('20261016-183355-s2-strategy-proposal：'):
        assert set(row) <= {'id', 'op', 'by', 'ts', 'where', 'note'}
        records.append({'id': row['id'], 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
        rows.append(row)
    offset += len(raw)
assert len(records) == len(identifiers) and sorted(r['id'] for r in records) == identifiers
private = {i: json.loads(json.dumps(before[i])) for i in identifiers}
for row in rows:
    ledger.apply(private, row)
protected = ('claim', 'first_run', 'prior', 'prior_note', 'prior_runs', 'asc', 'evidence', 'status', 'version', 'shipped_at', 'effect')
for ident in identifiers:
    assert all(private[ident].get(k) == before[ident].get(k) for k in protected)
    assert private[ident]['notes'][:-1] == before[ident]['notes']
    assert private[ident]['history'][:-1] == before[ident]['history']
audit = {'timestamp': stamp, 'cli_exit_code': execution.returncode, 'updates': len(records),
         'prefix_bytes': len(prefix), 'prefix_sha256': hashlib.sha256(prefix).hexdigest(),
         'observed_size_after': len(current), 'observed_tail_sha256': hashlib.sha256(tail).hexdigest(),
         'prefix_preserved': True, 'protected_fields_unchanged_in_private_fold': True, 'records': records}
(HERE / 'ledger-append-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in audit.items() if k != 'records'}, ensure_ascii=False))

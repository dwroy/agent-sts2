import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
FOCUS = {
    'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13}, '8JRE1C4H4Z2W': {33},
    'YF0LXT1QSTGG': {48}, 'XP2SL33HT0D9': {33},
}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(entity):
    return {p['power_id']: p['amount'] for p in entity.get('powers', [])}


def reference(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def compact(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        **reference(item), 'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
        'floor': state['run']['floor'], 'turn': state.get('turn'), 'screen': state['screen'],
        'fingerprint': row.get('fingerprint'), 'hp': player.get('current_hp'),
        'block': player.get('block'), 'played': player.get('cards_played_this_turn'),
        'player_powers': powers(player),
        'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'resolved_rules_text')}
                 for c in combat.get('hand', [])],
        'enemies': [{**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id')},
                     'powers': powers(e), 'intents': e.get('intents')} for e in combat.get('enemies', [])],
    }


def main():
    spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
    extractor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(extractor)
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    verified = []
    focuses = []
    decisions = {}
    anchors = {270216, 270282, 270264, 271309, 271348, 271354, 271982, 271992, 272040, 272195, 272076}
    for stream in manifest:
        path = OUT / 'evidence' / (stream['stream'] + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
        counts = collections.Counter()
        with path.open() as src, (Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')).open('rb') as raw:
            for line in src:
                item = json.loads(line)
                raw.seek(item['offset'])
                original = raw.read(item['bytes'])
                assert hashlib.sha256(original).hexdigest() == item['sha256']
                assert json.loads(original) == item['row']
                assert extractor.run_identity(item['row']) == item['run_id']
                assert item['run_id'] in FOCUS
                counts[item['run_id']] += 1
                if stream['stream'] == 'states':
                    state = item['row']['state']
                    assert state['run']['character_id'] == 'SILENT'
                    assert state['run']['ascension'] == 10
                    if state['run']['floor'] in FOCUS[item['run_id']] and state.get('combat'):
                        focuses.append(compact(item))
                elif stream['stream'] == 'decisions' and item['line'] in anchors:
                    decisions[str(item['line'])] = item
        assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
        verified.append({**stream, 'raw_references_verified': sum(counts.values())})
    save('byte-verification.json', verified)
    save('focus-frames.json', focuses)
    save('anchor-decisions.json', decisions)
    by_line = {x['line']: x for x in focuses}
    pairs = []
    for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
        left, right = decisions[str(a)], decisions[str(b)]
        assert left['run_id'] == right['run_id']
        assert left['row']['fingerprint'] == right['row']['fingerprint']
        pairs.append({'run': left['run_id'], 'left': reference(left), 'right': reference(right), 'fingerprints_equal': True})
    save('paired-fingerprints.json', pairs)
    summary = []
    for frame in focuses:
        if frame['screen'] == 'COMBAT' and frame['played'] == 0:
            v = {k: frame[k] for k in ('run_id', 'line', 'floor', 'turn', 'hp', 'block', 'player_powers', 'enemies')}
            if not summary or any(v[k] != summary[-1][k] for k in v if k != 'line'):
                summary.append(v)
    save('turn-starts.json', summary)
    print(json.dumps({'verified': sum(x['raw_references_verified'] for x in verified), 'focus_frames': len(focuses),
                      'anchors': len(decisions), 'fingerprint_pairs': len(pairs), 'turn_start_snapshots': len(summary)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

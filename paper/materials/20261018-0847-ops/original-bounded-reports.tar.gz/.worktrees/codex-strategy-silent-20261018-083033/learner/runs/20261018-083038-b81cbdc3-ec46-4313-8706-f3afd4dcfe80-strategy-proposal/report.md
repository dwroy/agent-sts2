# 静默猎手策略提案逐项复核

记录时间：2026-10-18T08:42:21+08:00（写入前已运行date）。
批次：20261018-083033-strategy-proposal；来源任务strategy-proposal；角色silent、六局均实核A10。
工作树：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-083033。
base/HEAD：bea43799c5d3a8d9fc10a99fd41ae387154f59b7；开工干净，git merge --no-edit main 返回 Already up to date。

本批完成10个已领取提案的逐项复核，全部waiting。没有足够依据新增策略参数或关闭完整提案。源码、测试、知识和任务模板未改；fixes=[]、merged=null，无源码提交/上线版本/shipped；生产tests三项均null，撤源码失败/恢复通过不适用。

## 批次和证据身份

dispatch.json只保存learn.json本批行，精确10个proposal_ids、六个runs及worktree；reason=proposal，没有research_request/implementation_request。普通专题文件仍绑定旧20261010批次，依任务继续本批消费队列，没有读取其他专题代替身份。
10份原Markdown复制到original-proposals，SHA全部匹配队列add记录；未覆盖原文或新建重复id。原始行及折叠结果见proposal-inputs.json。根账本中30个本批既有id的claim和本批证据见ledger-batch-evidence.json；没有把旧shipped机制降级成新proposed，也没有重复加support/repeat。

共用extract_evidence.py冻结八流，8274条原引用逐offset/bytes/SHA、JSON相等和显式run身份重核，输出整体SHA核回；states角色/进阶逐条为SILENT/A10。详细逐局计数见evidence/evidence-manifest.json、byte-verification.json。

| 流 | 冻结字节截点 | 本批原引用数 | 全源坏行 |
|---|---:|---:|---:|
| states | 14233898089 | 4062 | 2 |
| decisions | 2469217829 | 3941 | 2 |
| sl-attempts | 47407254 | 38 | 0 |
| run-config | 2074501 | 6 | 0 |
| run-plans | 9238064 | 33 | 0 |
| brain | 800339886 | 188 | 2 |
| runs | 370870 | 6 | 0 |
| fight-plans | 2233957 | 0 | 0 |

全源坏行未归入六局。fight-plans该截点选中0条，只表示本次未选到，不断言旧日志不存在；run-plans按独立run字段选中33条。抽取进行中首次探针读取尚未写出的states而报StopIteration，完整manifest落盘后重读成功，没有把暂时零行当缺失。报告生成的第一次工具请求因JavaScript字符串转义在文件写入前失败，改用带引号heredoc写入，未改任务输入或源码。

## 源码与运行输入

观测live固定cacff7cd8e8013d95aca4dffa8e791a0c3f60df1；14个base/live源叶逐blob/SHA保存到source-pins及source-pins.json，11个逐字相同、3个有差异。base-live-source.patch保存精确差异，不能称两树全等。所有所列live最后修改提交均核为该live祖先。另5个既有离线审计源叶保存在audit-tool-pins.json及source-pins。
六局run-config均dirty，但dirty_files是知识/统计/文档，没有列本次核对的TS源；六局记录的完整Git提交和24个历史源码blob均可读，见runtime-source-identities.json，不能笼统说源码不存在。缺的是运行实际刷新的DB/移动JSON原字节与逐候选执行归属，当前知识JSON/短prefix_sha不能代替实际旧输入。未读其他角色知识，没有用刷新数据假装复原旧输入。

局部实现的实际live祖先源码：
- selection审计05cd292c6f01bb31e406473d3a9843e659d62b93；单动作回执bade647f9fe4c9103b40e2f26b26296692ad24b7。
- SL资源对照0e4fe4df89a06682468e0e4716c12126e76369d5；HP护栏/SL比较a8b1f8be153fe4f3a34146117546c2178f2e446b。
- 当前阶段快照8698c581dac6c7e957f50a381586960a6d0c9b57；阶段参考1d57f9d0dbbb63603e9ce9768e74cb2021478464。
这些祖先性与源码SHA只证明所述局部字段，不关闭完整提案。monster-db.ts的moveDamageAt/monsterHpAt直接使用当前进阶已有观测、不设五样本事实门槛；roomHpCost的ROOM_COST_MIN_N仍5。本批没有改门槛。

## 材料计算与执行审计

focus-frames.json保存906个目标战斗帧，paired-fingerprints.json保存四组完整指纹相等及原字节引用；material-derivations.json保存19项确定性材料核对。四对端点“替换减原线”净差：8JRE多12HP下降/多7敌HP下降；YF多9HP下降/少7敌HP下降；XP T3多5/多3；XP T1多8/多9。它们是观测区间净变化，不能直接归为单一候选或单牌因果。

复用未修改learner/audit-selection.ts处理六局选定楼层完整冻结数组：170候选段、159回合窗，99个observed_turn_endpoints、60个unknown。严格工具要求前轮end_turn入口，T1仍unknown，原帧到次轮端点另列，不篡改工具标完整。完整候选结果全部null是工具保守输出，不能由此证明原日志绝对没有完整动作；本批尚无可交付的联合执行认证。
初次tsx CLI六次均因沙箱listen EPERM退出1；完整stderr和零行初稿在audit-output。随后同源Node --import loader入口不监听socket，六局均退出0，完整结果在audit-output-loader，摘要audit-summary.json。这是离线材料处理成功，不能报tsc/vitest、自然采用或胜率收益。

## 逐项处置、反例与验证

### silent-proposal-c20b5139dd0dff71 — waiting

证据：DUZUBAJ3A8GP F27 T4/T5；states 274830—274839。账本：silent-0168。
已核支持：污染0→3→3→6、次轮0→6→12→18→0；火花3→6。技能同时兑现施毒、弱与挡，能力勒紧不增加污染。
保留原因和反例限制：已有技能污染与逐击计算；缺原运行实际DB/移动表字节及毒、弱、挡、污染/火花联合校准，不能由净损9建立少打技能规则。
预期行为和验证：逐技能列效果与污染逐击代价，保留选项；冻结原帧手牌及可追溯移动输入，核联合输出和时序。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；SHA256 bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。

### silent-proposal-ae9e692d680e3819 — waiting

证据：5PM6JAQG6FNQ F39 T2/T4—T6；states 274341、274351—274362、274391。账本：silent-0183、silent-0005。
已核支持：两次抢夺后力敏各−4；首试两步法使敏捷−4→−2→0，失落退场后力量−4→0。末试单步法只到−2；遗忘后续再抢夺。
保留原因和反例限制：缺逐实体累计被夺来源与其他力敏来源的完整区分、遗忘退场返敏端点及联合候选校准；不以现帧总值冒充被夺量，不设固定击杀序。
预期行为和验证：保留现场负属性计算；后续分别核被夺来源、建立能力、退场返还及再次抢夺，不能预支持有步法。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；SHA256 b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。

### silent-proposal-52f1e1bd2e7db0ed — waiting

证据：CA5KE8GFJ9X2 F13 T1/T3/T5；states 273238、273252、273263—273268。账本：silent-0231。
已核支持：喷水11/15/19对应力量0/4/8；末轮虚弱后14攻，玩家2血10挡仍不足。覆甲轮初9/9/8/7/6仅为观察。
保留原因和反例限制：当前进阶首样本事实读取与房间代价五样本门槛已有；缺原实际移动输入、加压/弱/覆甲联合重放及完整减层条件，不新增固定房间成本。
预期行为和验证：沿当前进阶数据库接口取HP/攻击；覆甲减层未知保持未知，固定输入验证加压与弱的时序。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；SHA256 651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。

### silent-proposal-6dd8bbff876be528 — waiting

证据：5PM6JAQG6FNQ F38 T3/T4；states 274308、274313。账本：silent-0233、silent-0209。
已核支持：23上限电击index4→3、力量2→4、攻击17→19，高电压均2；T3仍贡献17攻击，T4才退场。
保留原因和反例限制：HIGH_VOLTAGE增长已有；缺召唤代际持久身份、原实际移动输入及另一杀序完整后继；index重排不能认证新旧实体，不规定先杀爪牙。
预期行为和验证：保持逐实体现场增长参考；固定夹具须覆盖旧体退场、新体出现和不继承旧计数的可核边界。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；SHA256 48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。

### silent-proposal-578e415a259e6835 — waiting

证据：8JRE1C4H4Z2W F33 首/第三试T2、第二试T5、末试T11；decisions 270216/270282/270264。账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。
已核支持：首/第三试T2指纹相同，端点损3/15、扣敌10/17；五轮预测0/24与5/24死亡有差异。第二试T5护栏预测省12血少18伤，原候选未完整执行。
保留原因和反例限制：原答/护栏/SL预测与单动作回执已有；缺跨抽弃牌、生成、用药和重规划的完整执行及分来源资源认证；金刚杵误链0016保留原异议。
预期行为和验证：复用候选及端点审计；新增认证先逐段核派发和状态，不把候选差额当实际保血，不拟护栏或探索阈值。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；SHA256 e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。

### silent-proposal-c0767768bf6a7ab1 — waiting

证据：YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348/271354。账本：silent-0079。
已核支持：同指纹题面至下一轮端点实损0/9、扣敌45/38，两候选24/24全败；第三试多9血价、少7净扣。严格整轮工具T1入口仍unknown。
保留原因和反例限制：预测对照已有；缺动作段完整执行认证、逐来源HP价和受控整战后继，不从24/24全败拟惩罚系数或禁止探索。
预期行为和验证：保留原答与探索；分别核预测、单次派发、可观察端点和完整候选；F33成功SL反对否定全部SL。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；SHA256 28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。

### silent-proposal-a46bdb7fe711d79a — waiting

证据：YF0LXT1QSTGG F48 末试T3—T5；states 277512—277528。账本：silent-0021、silent-0027、silent-0028、silent-0085。
已核支持：111血阶段4毒后换212血零毒；T5触媒2但零毒；先23挡后敏5→6仍23挡；小刀/消耗整步净扣37不能全记小刀本体。
保留原因和反例限制：当前阶段/持有组件/已建能力快照已有；缺逐候选施毒、结算、消耗附伤与敏捷顺序的联合执行校准，不启用能力优先级。
预期行为和验证：区分持有、建立、已结算和条件收益；逐步核毒/消耗来源，换相重读现场，后取敏捷不倒补旧挡。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；SHA256 eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。

### silent-proposal-1044224808015e5c — waiting

证据：XP2SL33HT0D9 F33 首/第二试T3、首/末试T1；decisions 271992/272040、271982/272195。账本：silent-0079。
已核支持：两对指纹分别相同；T3端点损9/14、扣敌24/27，T1端点损2/10、扣敌25/34；末试另建1力量。T1严格入口未知。
保留原因和反例限制：缺同抽序、随机药瓶落点和相同预算的完整替线、成长后继及独立验证；B2零胜并列不足以启用新保血门槛。
预期行为和验证：分别列本轮血价、净扣、成长；按独立run和结束时间切分验证，本局六SL只作一个发现/回归样本。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；SHA256 4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。

### silent-proposal-7cbc6005db712ba9 — waiting

证据：XP2SL33HT0D9 F33 末试T2—T5；states 278236—278255。账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。
已核支持：船夹板轮初14挡、斗篷后20；镣铐爪力0→−9→次轮0；火箭57→转向38→虚弱28；4敏且脆弱下偏折实6挡。
保留原因和反例限制：局部机制已有；缺抽弃牌后完整候选的联合执行与分来源消费认证，不将局部实现登记整项duplicate。
预期行为和验证：朝向、弱、临减、现挡/新增挡分别展示；条件只用本批已核范围，不改出牌权重，不把T2赠挡续到T3。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；SHA256 f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。

### silent-proposal-c59f592f1427a67e — waiting

证据：YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5。账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。
已核支持：上述阶段、能力、临时减力、船夹板及SL端点复核相符；候选、实建能力与资源净变化分账，零血截断不当完整入伤。
保留原因和反例限制：缺逐来源HP/药/恢复账、完整候选执行及路线/休息/药水时机受控替线联合认证；本批未重做原101局历史审计。
预期行为和验证：沿已有账本和本批两局端点接续；区分SL恢复/回血/实际用药，不拟必休、避战、药水持有阈值，不复制旧宽分母。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；SHA256 81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。

## 样本、异议与限制

每个来源局是独立局分母，六次SL仍一局。本批只核六局和既有账本关联，没有重做原99/101局宽审，不复制其分母当本批支持。没有拟新权重、血价、必杀序或能力优先级。触媒已建零毒、后取敏捷不补旧挡、不同防御替换结果不一致等反例均保留；路线/休息/留药没有受控替线，未执行后继保持未知。
未来策略验证按独立run划发现/验证、时间后移，固定反事实须同抽序、随机落点、预算与可追溯DB输入。先验收事实字段和执行边界，再评估策略参数；并不要求必须有胜局才允许修已证确定性错误，本批没有发现足以据此新增源码的确定性差异。

578e原文把金刚杵关联silent-0016，而该claim属于护喉甲覆甲；本批明确保留异议，不把力量帧当覆甲支持，不改原文/旧claim。根现有通知b07c96b10b1facb9f887a710有ops_forwarded、watcher_received、roy_notified的各角色回执路径/SHA，inbox有10月13日转达与10月17日去重记录；本批只读，不新造或代填ACK，不重复创建相同异议。

## 验证与交付

本批无源码/知识/测试修改，git diff HEAD -- agent learner eval ops knowledge为零，scratch受gitignore排除。tests={"tsc":null,"vitest":null,"cases":null}；未做撤源码/恢复试验、未运行沙箱生产套件、未创建源码commit/live合并/eval版本。19项材料核对和六次既有审计成功不充生产测试数。无源码时merge=live不触发合入，不冒造提交或shipped；未推送、play、LLM或联网。
首轮scratch全目录gitleaks退出0，扫描约258.48MB、no leaks found；最终交付材料另做末次扫描保日志。

学习账本只通过根learner/ledger.py追加本轮proposal/report追溯和waiting原因，by=learner:strategy-proposal；claim、首证、prior、evidence、status/version/effect保持。无新经验/重复提案；code_proposals填本批原10个CLI id，implementation_domains=[]。逐项结果交proposal_results，不手改专用队列、learn.json或其他角色回执。
运维入口是本目录proposal.md、report.md和result.json；原失败日志、初稿、源快照及缺证据保留。

最终读回：根账本CLI追加30条追溯成功(exit0)，30条claim/首证/prior/evidence/status/version/effect与追加前完全相同，note及proposal/report链接逐项读回；根ledger.py check退出0。最终10个id与learn.json本批仍一致，HEAD=base、git status --porcelain为空、生产源码/知识diff为零。详细回执见ledger-readback.json、ledger-check.log、final-readback.json。

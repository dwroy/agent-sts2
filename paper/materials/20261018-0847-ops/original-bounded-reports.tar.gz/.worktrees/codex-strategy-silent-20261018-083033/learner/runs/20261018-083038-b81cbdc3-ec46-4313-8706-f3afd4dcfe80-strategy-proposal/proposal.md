# 本批10项策略提案复核

只消费已领取id；以下逐项列原提案、证据、账本、反例、预期行为、验证和waiting理由。完整溯源见report.md，无新增源码或重复提案。

### silent-proposal-c20b5139dd0dff71 — waiting

证据：DUZUBAJ3A8GP F27 T4/T5；states 274830—274839。账本：silent-0168。
已核支持：污染0→3→3→6、次轮0→6→12→18→0；火花3→6。技能同时兑现施毒、弱与挡，能力勒紧不增加污染。
保留原因和反例限制：已有技能污染与逐击计算；缺原运行实际DB/移动表字节及毒、弱、挡、污染/火花联合校准，不能由净损9建立少打技能规则。
预期行为和验证：逐技能列效果与污染逐击代价，保留选项；冻结原帧手牌及可追溯移动输入，核联合输出和时序。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md；SHA256 bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c。

### silent-proposal-ae9e692d680e3819 — waiting

证据：5PM6JAQG6FNQ F39 T2/T4—T6；states 274341、274351—274362、274391。账本：silent-0183、silent-0005。
已核支持：两次抢夺后力敏各−4；首试两步法使敏捷−4→−2→0，失落退场后力量−4→0。末试单步法只到−2；遗忘后续再抢夺。
保留原因和反例限制：缺逐实体累计被夺来源与其他力敏来源的完整区分、遗忘退场返敏端点及联合候选校准；不以现帧总值冒充被夺量，不设固定击杀序。
预期行为和验证：保留现场负属性计算；后续分别核被夺来源、建立能力、退场返还及再次抢夺，不能预支持有步法。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md；SHA256 b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5。

### silent-proposal-52f1e1bd2e7db0ed — waiting

证据：CA5KE8GFJ9X2 F13 T1/T3/T5；states 273238、273252、273263—273268。账本：silent-0231。
已核支持：喷水11/15/19对应力量0/4/8；末轮虚弱后14攻，玩家2血10挡仍不足。覆甲轮初9/9/8/7/6仅为观察。
保留原因和反例限制：当前进阶首样本事实读取与房间代价五样本门槛已有；缺原实际移动输入、加压/弱/覆甲联合重放及完整减层条件，不新增固定房间成本。
预期行为和验证：沿当前进阶数据库接口取HP/攻击；覆甲减层未知保持未知，固定输入验证加压与弱的时序。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md；SHA256 651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376。

### silent-proposal-6dd8bbff876be528 — waiting

证据：5PM6JAQG6FNQ F38 T3/T4；states 274308、274313。账本：silent-0233、silent-0209。
已核支持：23上限电击index4→3、力量2→4、攻击17→19，高电压均2；T3仍贡献17攻击，T4才退场。
保留原因和反例限制：HIGH_VOLTAGE增长已有；缺召唤代际持久身份、原实际移动输入及另一杀序完整后继；index重排不能认证新旧实体，不规定先杀爪牙。
预期行为和验证：保持逐实体现场增长参考；固定夹具须覆盖旧体退场、新体出现和不继承旧计数的可核边界。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md；SHA256 48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5。

### silent-proposal-578e415a259e6835 — waiting

证据：8JRE1C4H4Z2W F33 首/第三试T2、第二试T5、末试T11；decisions 270216/270282/270264。账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。
已核支持：首/第三试T2指纹相同，端点损3/15、扣敌10/17；五轮预测0/24与5/24死亡有差异。第二试T5护栏预测省12血少18伤，原候选未完整执行。
保留原因和反例限制：原答/护栏/SL预测与单动作回执已有；缺跨抽弃牌、生成、用药和重规划的完整执行及分来源资源认证；金刚杵误链0016保留原异议。
预期行为和验证：复用候选及端点审计；新增认证先逐段核派发和状态，不把候选差额当实际保血，不拟护栏或探索阈值。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md；SHA256 e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a。

### silent-proposal-c0767768bf6a7ab1 — waiting

证据：YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348/271354。账本：silent-0079。
已核支持：同指纹题面至下一轮端点实损0/9、扣敌45/38，两候选24/24全败；第三试多9血价、少7净扣。严格整轮工具T1入口仍unknown。
保留原因和反例限制：预测对照已有；缺动作段完整执行认证、逐来源HP价和受控整战后继，不从24/24全败拟惩罚系数或禁止探索。
预期行为和验证：保留原答与探索；分别核预测、单次派发、可观察端点和完整候选；F33成功SL反对否定全部SL。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md；SHA256 28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb。

### silent-proposal-a46bdb7fe711d79a — waiting

证据：YF0LXT1QSTGG F48 末试T3—T5；states 277512—277528。账本：silent-0021、silent-0027、silent-0028、silent-0085。
已核支持：111血阶段4毒后换212血零毒；T5触媒2但零毒；先23挡后敏5→6仍23挡；小刀/消耗整步净扣37不能全记小刀本体。
保留原因和反例限制：当前阶段/持有组件/已建能力快照已有；缺逐候选施毒、结算、消耗附伤与敏捷顺序的联合执行校准，不启用能力优先级。
预期行为和验证：区分持有、建立、已结算和条件收益；逐步核毒/消耗来源，换相重读现场，后取敏捷不倒补旧挡。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md；SHA256 eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6。

### silent-proposal-1044224808015e5c — waiting

证据：XP2SL33HT0D9 F33 首/第二试T3、首/末试T1；decisions 271992/272040、271982/272195。账本：silent-0079。
已核支持：两对指纹分别相同；T3端点损9/14、扣敌24/27，T1端点损2/10、扣敌25/34；末试另建1力量。T1严格入口未知。
保留原因和反例限制：缺同抽序、随机药瓶落点和相同预算的完整替线、成长后继及独立验证；B2零胜并列不足以启用新保血门槛。
预期行为和验证：分别列本轮血价、净扣、成长；按独立run和结束时间切分验证，本局六SL只作一个发现/回归样本。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md；SHA256 4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5。

### silent-proposal-7cbc6005db712ba9 — waiting

证据：XP2SL33HT0D9 F33 末试T2—T5；states 278236—278255。账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。
已核支持：船夹板轮初14挡、斗篷后20；镣铐爪力0→−9→次轮0；火箭57→转向38→虚弱28；4敏且脆弱下偏折实6挡。
保留原因和反例限制：局部机制已有；缺抽弃牌后完整候选的联合执行与分来源消费认证，不将局部实现登记整项duplicate。
预期行为和验证：朝向、弱、临减、现挡/新增挡分别展示；条件只用本批已核范围，不改出牌权重，不把T2赠挡续到T3。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md；SHA256 f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291。

### silent-proposal-c59f592f1427a67e — waiting

证据：YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5。账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。
已核支持：上述阶段、能力、临时减力、船夹板及SL端点复核相符；候选、实建能力与资源净变化分账，零血截断不当完整入伤。
保留原因和反例限制：缺逐来源HP/药/恢复账、完整候选执行及路线/休息/药水时机受控替线联合认证；本批未重做原101局历史审计。
预期行为和验证：沿已有账本和本批两局端点接续；区分SL恢复/回血/实际用药，不拟必休、避战、药水持有阈值，不复制旧宽分母。
回退：本批无生产改动；未来实现按独立源码commit回退，保留日志、原提案、账本和反例。
原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md；SHA256 81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2。

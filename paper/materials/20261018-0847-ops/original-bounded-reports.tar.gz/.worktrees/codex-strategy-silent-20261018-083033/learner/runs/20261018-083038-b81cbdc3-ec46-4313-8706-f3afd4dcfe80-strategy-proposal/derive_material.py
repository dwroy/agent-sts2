import json
from pathlib import Path

OUT = Path(__file__).parent
frames = json.loads((OUT / 'focus-frames.json').read_text())
by_line = {x['line']: x for x in frames}
decisions = json.loads((OUT / 'anchor-decisions.json').read_text())
checks = []


def check(name, actual, expected, lines):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'observed': actual, 'expected': expected,
                   'source_state_lines': lines, 'kind': 'frozen_material_arithmetic'})


def power(line, key):
    return by_line[line]['player_powers'].get(key, 0)


def enemy(line, ident):
    return next(e for e in by_line[line]['enemies'] if e['enemy_id'] == ident)


def attack(line, ident):
    return sum(i.get('total_damage') or 0 for i in enemy(line, ident)['intents'])


def endpoint(decision_line):
    decision = decisions[str(decision_line)]
    raw = decision['row']
    matching = [s for s in frames if s['run_id'] == decision['run_id'] and
                s['fingerprint'] == raw['fingerprint'] and s['observed_ts'] == raw['observed_ts']]
    assert len(matching) == 1
    before = matching[0]
    after = next(s for s in frames if s['run_id'] == before['run_id'] and s['line'] > before['line'] and
                 s['floor'] == before['floor'] and s['turn'] != before['turn'])
    assert after['turn'] == before['turn'] + 1
    a = {e['enemy_id']: e for e in before['enemies']}
    b = {e['enemy_id']: e for e in after['enemies']}
    assert len(a) == len(before['enemies']) and a.keys() == b.keys()
    assert all(a[k]['max_hp'] == b[k]['max_hp'] for k in a)
    return {'decision_line': decision_line, 'before_line': before['line'], 'after_line': after['line'],
            'observed_hp_decrease': before['hp'] - after['hp'],
            'observed_enemy_hp_decrease': sum(a[k]['current_hp'] - b[k]['current_hp'] for k in a),
            'whole_candidate_executed': None,
            'scope': 'matched_question_to_next_turn_observations_not_causal_candidate_result'}


pair_endpoints = []
for left, right, expected in [(270216, 270282, [[3, 10], [15, 17]]),
                              (271309, 271348, [[0, 45], [9, 38]]),
                              (271992, 272040, [[9, 24], [14, 27]]),
                              (271982, 272195, [[2, 25], [10, 34]])]:
    a, b = endpoint(left), endpoint(right)
    check(f'成对端点 {left}/{right}', [[a['observed_hp_decrease'], a['observed_enemy_hp_decrease']],
                                   [b['observed_hp_decrease'], b['observed_enemy_hp_decrease']]],
          expected, [a['before_line'], a['after_line'], b['before_line'], b['after_line']])
    pair_endpoints.append({'left': a, 'right': b, 'hp_decrease_delta': b['observed_hp_decrease'] - a['observed_hp_decrease'],
                           'enemy_hp_decrease_delta': b['observed_enemy_hp_decrease'] - a['observed_enemy_hp_decrease']})

check('棱柱T4污染', [power(n, 'TAINTED_POWER') for n in range(274830, 274834)], [0, 3, 3, 6], list(range(274830, 274834)))
check('棱柱T5污染', [power(n, 'TAINTED_POWER') for n in (274834, 274836, 274837, 274838, 274839)], [0, 6, 12, 18, 0], [274834, 274836, 274837, 274838, 274839])
check('棱柱火花跨轮', [enemy(n, 'INFESTED_PRISM')['powers']['VITAL_SPARK_POWER'] for n in (274833, 274834)], [3, 6], [274833, 274834])
check('抢夺负属性与两步法', [power(n, 'DEXTERITY_POWER') for n in (274351, 274352, 274354)], [-4, -2, 0], [274351, 274352, 274354])
check('失落退场端点力量', [power(n, 'STRENGTH_POWER') for n in (274357, 274358)], [-4, 0], [274357, 274358])
check('喷水成长', [[enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0), attack(n, 'SEWER_CLAM')] for n in (273238, 273252, 273263)], [[0, 11], [4, 15], [8, 19]], [273238, 273252, 273263])
check('蚌末轮虚弱及已挡', [attack(273268, 'SEWER_CLAM'), by_line[273268]['block'], by_line[273268]['hp']], [14, 10, 2], [273268])
check('电击成长与index重排', [[enemy(n, 'ZAPBOT')['index'], enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'], attack(n, 'ZAPBOT')] for n in (274308, 274313)], [[4, 2, 17], [3, 4, 19]], [274308, 274313])
check('阶段换血与清毒', [[enemy(n, 'TEST_SUBJECT')['max_hp'], enemy(n, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)] for n in (277512, 277513)], [[111, 4], [212, 0]], [277512, 277513])
check('零毒已建触媒', [power(277519, 'ACCELERANT_POWER'), enemy(277519, 'TEST_SUBJECT')['powers'].get('POISON_POWER', 0)], [2, 0], [277519])
check('敏捷后取不倒补', [[power(n, 'DEXTERITY_POWER'), by_line[n]['block']] for n in (277523, 277526)], [[5, 23], [6, 23]], [277523, 277526])
check('小刀与消耗整步净扣', enemy(277519, 'TEST_SUBJECT')['current_hp'] - enemy(277527, 'TEST_SUBJECT')['current_hp'], 37, [277519, 277527])
check('镣铐临减与恢复', [enemy(n, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) for n in (278236, 278237, 278242)], [0, -9, 0], [278236, 278237, 278242])
check('船夹板与后施牌挡', [by_line[n]['block'] for n in (278236, 278240)], [14, 20], [278236, 278240])
check('朝向与虚弱分步', [attack(n, 'ROCKET') for n in (278249, 278252, 278253)], [57, 38, 28], [278249, 278252, 278253])

(OUT / 'material-derivations.json').write_text(json.dumps({'checks': checks, 'paired_endpoints': pair_endpoints,
    'limitation': '这是原帧与既有报告的确定性核对，不是生产源码测试、完整候选执行认证、反事实整战或新增独立样本。'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks': len(checks), 'fingerprint_pairs': len(pair_endpoints)}, ensure_ascii=False))

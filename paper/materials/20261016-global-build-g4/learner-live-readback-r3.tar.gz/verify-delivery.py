import pathlib,json,hashlib,sys,importlib.util,subprocess
p=pathlib.Path(__file__).resolve().parent;w=p.parents[2];r=pathlib.Path('/home/dw/Projects/agent-sts2');sha=lambda b:hashlib.sha256(b).hexdigest();sys.path.insert(0,str(r/'ops'))
spec=importlib.util.spec_from_file_location('learning_requests_delivery_readonly',r/'ops/learning_requests.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
req=json.load(open(r/'notes/learning-requests/roy-20261012-concrete-core-decklists.json'));report=json.load(open(p/'result.json'));verified=module.verify_experience(r,req,report);assert verified['outcome']=='complete'
import proposal_dispatch
state=json.load(open(r/'ops/codex-ops/learn.json'));batch=state['batches'][report['continuation_batch']];errors=proposal_dispatch.links(report,batch,str(r),str(r/'ops'));assert errors==[],errors;assert proposal_dispatch.results(report,batch)==[];assert state['batches']['20261016-075639-strategy-proposal']==json.load(open(p/'original-blocked-record.json'))
for ref in json.load(open(p/'preserved-inputs.json')):assert sha(pathlib.Path(ref['path']).read_bytes())==ref['sha256']
for n in ['live/input.json','live/output.json','live/inventory-output.json','live/verification.json']:assert (p/n).is_file()
inputs=json.load(open(p/'live/input.json'));outputs=json.load(open(p/'live/output.json'));assert inputs['repo']==str(r/'.worktrees/live')and inputs['code_commit']==report['merged'];assert inputs['experience_version']==report['experience_version'];assert all(a['request']['knowledge']['mode']=='full'for a in outputs['outputs'])
for ref in inputs['knowledge_files']:assert sha((p/'live'/ref['path']).read_bytes())==ref['sha256']
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=w)==b''
assert subprocess.check_output(['git','-C',str(r/'.worktrees/live'),'status','--porcelain=v1','--','agent/src','knowledge/common','knowledge/characters/silent'])==b''
assert sha((r/'.worktrees/live/knowledge/characters/silent/experience.json').read_bytes())==inputs['experience_sha256']
final={'request_id':req['id'],'revision':req['revision'],'mechanical_live_experience_verifier':'passed','proposal_links':'passed','source_worktree_clean':True,'source_head_unchanged':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'original_075639_record_unchanged':True,'original_source_and_r2_inputs_unchanged':True,'actual_live_commit':report['merged'],'actual_live_tree':json.load(open(p/'live-execution.json'))['tree'],'live_consumer_invocations':1,'production_inventory_checks':231,'new_text_checks':12,'prior_requirement_checks':15,'frozen_knowledge_files_verified':len(inputs['knowledge_files']),'coverage_keys':list(report['learning_result']['coverage']),'consumer_receipt':report['learning_result']['consumer_receipt'],'report_sha256':sha((p/'report.md').read_bytes()),'no_request_state_or_ACK_mutation':True,'natural_adoption_or_effect_claimed':False};p.joinpath('final-verification.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
files=[]
for f in sorted(p.rglob('*')):
 if f.is_file()and f.name!='artifact-manifest.json':files.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
p.joinpath('artifact-manifest.json').write_text(json.dumps({'files':files},ensure_ascii=False,indent=2)+'\n');print(json.dumps(final,ensure_ascii=False,indent=2));print('artifact count',len(files),'bytes',sum(f['bytes']for f in files))

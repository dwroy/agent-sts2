import pathlib,json,hashlib,subprocess,fcntl,time,os
p=pathlib.Path(__file__).resolve().parent;w=p.parents[2];r=pathlib.Path('/home/dw/Projects/agent-sts2');live=r/'.worktrees/live';old=w/'learner/runs/20261016-global-build-g4-r3';publication=json.load(open(r/'paper/materials/20261016-global-build-g4/ops-publication/publication.json'));sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git','-C',str(live),*args],text=True).strip();leaf='knowledge/characters/silent/experience.json';consumer=old/'consumer.mjs'
inputs=[consumer,old/'changes.json',old/'plan-states.json',old/'plan-inventory-audit.json',old/'result.json',old/'report.md',old/'final-verification.json',w/'learner/runs/20261013-core-decklists-live-readback/consumer-frames.json',w/'learner/runs/20261013-core-decklists-live-readback/report.md',w/'learner/runs/20261013-core-decklists-live-readback/consumer-receipt.json'];frozen=[{'path':str(f),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size}for f in inputs];(p/'preserved-inputs.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n')
with (r/'ops/live-merge.lock').open('r')as lock:
 lock_mode='shared-read-lock'
 try:fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
 except BlockingIOError:
  lock_mode='read-only optimistic snapshot; complete source/knowledge fingerprints and HEAD verified before/after'
 head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert head==publication['actual_live']and tree==publication['tree'],(head,tree)
 assert subprocess.run(['git','merge-base','--is-ancestor',publication['source'],head],cwd=w).returncode==0
 assert git('status','--porcelain=v1','--','agent/src','knowledge/common','knowledge/characters/silent')==''
 before=(live/leaf).read_bytes();exp=json.loads(before);assert exp['version']=='2026-10-16.2';source_exp=json.loads(subprocess.check_output(['git','show',publication['source']+':'+leaf],cwd=w));by={e['id']:e for e in exp['entries']};src={e['id']:e for e in source_exp['entries']};changes=json.load(open(old/'changes.json'));assert all(by[c['id']]==src[c['id']]==c['after']for c in changes)
 files=[]
 for base in [live/'agent/src',live/'knowledge/common',live/'knowledge/characters/silent']:
  for file in sorted(base.rglob('*')):
   if file.is_file():files.append({'path':str(file.relative_to(live)),'sha256':sha(file.read_bytes())})
 (p/'live-source-knowledge-manifest.json').write_text(json.dumps({'commit':head,'tree':tree,'files':files},ensure_ascii=False,indent=2)+'\n');(p/'experience-live.json').write_bytes(before)
 stage='../'+p.name+'/live';assert (old/stage).resolve()==(p/'live').resolve();assert not (p/'live').exists(),'Do not overwrite an earlier actual consumer run'
 command=['nice','-n','19',str(pathlib.Path.home()/'.local/node/bin/node'),'--import',str(w/'agent/node_modules/tsx/dist/loader.mjs'),str(consumer),stage,str(live),head];start=time.time();env=os.environ.copy();env['TMPDIR']=str(p)
 with (p/'live-consumer.log').open('w')as log:rc=subprocess.run(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 elapsed=time.time()-start;after=(live/leaf).read_bytes();stable=before==after and git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree
 assert stable,'Live changed during fixed readback'
 for f in files:assert sha((live/f['path']).read_bytes())==f['sha256'],f['path']
 for f in frozen:assert sha(pathlib.Path(f['path']).read_bytes())==f['sha256']
 execution={'command':command,'exit':rc,'elapsed_seconds':elapsed,'code_commit':head,'tree':tree,'source_commit':publication['source'],'original_consumer_sha256':sha(consumer.read_bytes()),'experience_version':exp['version'],'experience_sha256':sha(before),'live_code_and_knowledge_stable':stable,'preserved_inputs_unchanged':True,'lock_mode':lock_mode,'live_mutation':False,'model_calls':0,'game_actions':0};(p/'live-execution.json').write_text(json.dumps(execution,ensure_ascii=False,indent=2)+'\n');print(json.dumps(execution,ensure_ascii=False,indent=2));assert rc==0

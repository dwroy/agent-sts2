import json,pathlib,collections,hashlib
p=pathlib.Path(__file__).resolve().parent;work=p.parents[2];plans=json.load(open(p/'plans-231-frozen.json'))['rows'];frames=json.load(open(p/'plan-states.json'));templates=json.load(open(work/'knowledge/characters/silent/construction-templates.json'))['templates'];counts=collections.Counter();cross=collections.Counter();alternatives=collections.Counter();keywords=collections.Counter();r_payoff=collections.Counter();qualified=[];audit=[]
for i,(x,f)in enumerate(zip(plans,frames)):
 rec=x['record'];c=rec['plan']['construction'];alternatives.update(c['alternatives']);txt=(c['reason']+' '+c['pivot_if']).lower();keywords['explicit_relic_condition']+=any(k in txt for k in ['tingsha','bandage','discard relic','discard-relic','discard payoff relic','discard-payoff relic']);keywords['R_alternative_or_discard_mention']+=('R'in c['alternatives']or any(k in txt for k in ['discard','tingsha','bandage']))
 if 'state'not in f:audit.append({'index':i,'unknown':f['missing']});continue
 s=f['state']['run'];cards=[a['card_id']for a in s['deck']];relics=[a['relic_id']for a in s['relics']];missing={}
 for t in templates:
  m=[]
  for req in t['requirements']:
   found=[('card',a)for a in cards if any(v['kind']=='card'and v['id']==a for v in req['any'])]+[('relic',a)for a in relics if any(v['kind']=='relic'and v['id']==a for v in req['any'])];n=len(set(found))if req['distinct']else len(found)
   if n<req['count']:m.append({'id':req['id'],'count':req['count']-n})
  missing[t['id']]=m;counts[t['id']]+=not m
 cross[c['primary']+'|'+('signature_held'if c['primary']in missing and not missing[c['primary']]else 'signature_not_held')]+=1
 payoff=[a for a in relics if a in ['TINGSHA','TOUGH_BANDAGES']];r_payoff['present'if payoff else 'missing']+=1
 if not missing['R']:qualified.append({'index':i,'run':rec['run'],'floor':rec['floor'],'primary':c['primary'],'reason':c['reason'],'pivot_if':c['pivot_if'],'state_ref':f['source'],'plan_ref':{k:x[k]for k in ['offset','bytes','sha256']},'cards':cards,'payoff':payoff})
 audit.append({'index':i,'run':rec['run'],'floor':rec['floor'],'observed_ts':f['observed_ts'],'matches_plan_observation':f['observed_ts']==rec['observed_ts'],'primary':c['primary'],'missing':missing,'payoff':payoff})
summary={'plans':len(plans),'independent_runs':len({r['record']['run']for r in plans}),'primary':dict(collections.Counter(r['record']['plan']['construction']['primary']for r in plans)),'alternatives':dict(alternatives),'descriptive_keywords':dict(keywords),'known_states':sum('state'in f for f in frames),'unknown_states':sum('state'not in f for f in frames),'inventory_signature_counts':dict(counts),'primary_vs_inventory':dict(cross),'R_payoff':dict(r_payoff),'R_signature_observations':qualified,'limits':['231 plans in 30 runs, repeated plan observations not independent game tests; 29 ended at cutoff, 9KP active','Same observed_ts input; inventory signature does not certify casting, function, survival, victory or causal value','Reason/pivot words express stated decisions; no counterfactual R-vs-P choice or unrecorded reasons inferred','Frozen231 end offset fixed, later suffix plans excluded; template rules unchanged from approved base']}
(p/'plan-inventory-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');(p/'plan-analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='R_signature_observations'},ensure_ascii=False,indent=2))

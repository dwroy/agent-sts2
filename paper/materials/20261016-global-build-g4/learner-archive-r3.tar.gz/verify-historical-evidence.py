import pathlib,re,json,hashlib
r=pathlib.Path('/home/dw/Projects/agent-sts2');p=pathlib.Path(__file__).resolve().parent;txt=(p.parents[2]/'paper/materials/silent/20261009-2335-events/core-builds/report.md').read_text();ids={f'E{x:03d}'for x in [22,25,27,31,33,46,48,52,54,55,57,58,60,61,63,87,88,90,91,115,116,124]};refs=[]
for line in txt.splitlines():
 m=re.match(r'\| (E\d+) \| (\w+) / F(\d+) / T([^|]+) \| ([\w.-]+) @(\d+) \+(\d+) \| ([a-f0-9]+) \|',line)
 if not m or m[1]not in ids:continue
 eid,run,fl,t,source,off,n,sha=m.groups();off=int(off);n=int(n)
 with (r/'logs'/source).open('rb')as f:f.seek(off);b=f.read(n)
 assert hashlib.sha256(b).hexdigest()==sha,eid
 x=json.loads(b);s=x.get('state',{});assert s.get('run_id',x.get('run_id',x.get('run')))==run,eid
 refs.append({'id':eid,'run':run,'floor':int(fl),'turn':t.strip(),'source':str(r/'logs'/source),'offset':off,'bytes':n,'sha256':sha});(p/('historical-'+eid+'.txt')).write_bytes(b)
assert len(refs)==len(ids)
(p/'historical-evidence-verification.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n');print('verified',len(refs),'raw refs, bytes',sum(v['bytes']for v in refs))
for eid in ['E025','E058','E052','E061','E055']:
 x=json.loads((p/('historical-'+eid+'.txt')).read_bytes());print(eid,'keys',list(x), 'summary', str(x.get('summary'))[:250])

import pathlib,subprocess,json,os
p=pathlib.Path(__file__).resolve().parent;w=p.parents[2];cmd0=[str(pathlib.Path.home()/'.local/node/bin/node'),'--import',str(w/'agent/node_modules/tsx/dist/loader.mjs'),str(p/'consumer.mjs')];base=subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=w).strip();out=[]
for stage,expected in [('negative',1),('source',0)]:
 cmd=['nice','-n','19',*cmd0,stage,str(w),base]
 with(p/(stage+'-consumer.log')).open('w')as log:rc=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT).returncode
 out.append({'stage':stage,'command':cmd,'actual_exit':rc,'expected_exit':expected});assert rc==expected,(stage,rc)
(p/'source-execution.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

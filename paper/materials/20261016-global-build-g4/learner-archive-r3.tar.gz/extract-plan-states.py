import duckdb,json,pathlib,hashlib,collections
r=pathlib.Path('/home/dw/Projects/agent-sts2');o=pathlib.Path(__file__).resolve().parent;plans=json.load(open(o/'plans-231-frozen.json'))['rows'];runs=sorted({x['record']['run'] for x in plans}); con=duckdb.connect();con.execute('SET threads=1'); marks=','.join('?' for _ in runs); sql=f'SELECT run_id,floor,coalesce(observed_ts,ts),off,len FROM read_parquet(?) WHERE run_id IN ({marks}) ORDER BY coalesce(observed_ts,ts),off';rows=con.execute(sql,[str(r/'data/logdb/frames/*.parquet'),*runs]).fetchall(); grouped={}
for run,fl,ts,off,n in rows: grouped.setdefault((run,fl),[]).append((ts.isoformat(timespec='milliseconds')+'Z',off,n))
frames=[]; failures=[]
with (r/'logs/states.jsonl').open('rb') as f:
 for i,p in enumerate(plans):
  rec=p['record']; c=grouped.get((rec['run'],rec['floor']),[]); upto=rec.get('observed_ts',rec['ts']); a=[v for v in c if v[0]<=upto]
  if not a: frames.append({'plan_index':i,'missing':'No indexed prior observed state in same run/floor'});continue
  ts,off,n=a[-1];f.seek(off);b=f.read(n);x=json.loads(b);s=x['state'];assert s.get('run_id')==rec['run'];assert str(s.get('run',{}).get('character_id')).lower()=='silent';assert s['run']['ascension']==10
  frames.append({'plan_index':i,'source':{'path':str(r/'logs/states.jsonl'),'offset':off,'bytes':n,'sha256':hashlib.sha256(b).hexdigest()},'observed_ts':ts,'state':s})
(o/'plan-states.json').write_text(json.dumps(frames,ensure_ascii=False,indent=2)+'\n');(o/'plan-frame-query.json').write_text(json.dumps({'sql':sql,'runs':runs,'rule':'Last indexed state in same run/floor by observed_ts <= plan observed_ts, otherwise missing; never future state','index_paths':str(r/'data/logdb/frames/*.parquet')},indent=2)+'\n');print('frames',len(frames),'missing',sum('missing'in f for f in frames)); print('missing indices',[f['plan_index'] for f in frames if 'missing'in f]);print('sample relics',frames[0]['state']['run']['relics'][:2])

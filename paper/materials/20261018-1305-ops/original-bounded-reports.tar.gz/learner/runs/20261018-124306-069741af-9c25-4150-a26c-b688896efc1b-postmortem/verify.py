import collections,hashlib,json,pathlib,subprocess,re
p=pathlib.Path(__file__).parent
names=['runs','decisions','states','run-plans','sl-attempts','brain','run-config','fight-plans']
data={};checks={}
for name in names:
 rows=[json.loads(l)for l in(p/(name+'.jsonl')).open()];data[name]=rows
 with (pathlib.Path('logs')/(name+'.jsonl')).open('rb')as src:
  for x in rows:
   src.seek(x['source_offset']);raw=src.readline()
   assert hashlib.sha256(raw).hexdigest()==x['sha256'],(name,x['source_line'])
   assert json.loads(raw)==x['row'],(name,x['source_line'])
 checks[name]=len(rows)
s={x['source_line']:x['row']['state']for x in data['states']};d={x['source_line']:x['row']for x in data['decisions']}
for line,hp in[(448526,73),(448535,36),(448546,36),(448576,7),(448620,7),(448630,4),(448635,4),(448636,0)]:assert s[line]['run']['current_hp']==hp
last=s[448635]['combat'];assert last['player']['block']==16
assert sum(v.get('total_damage')or 0 for e in last['enemies']for v in e['intents'])==36
assert [e['current_hp']for e in s[448636]['combat']['enemies']]==[18,66,70]
assert s[448623]['run']['potions'][0]['valid_target_indices']==[0,1,2]
assert s[448624]['run']['potions'][0]['can_use']is True
for ln in [433691,433731]:
 opts=d[ln]['questions']['plan']['criteria'];assert 'p0->e0'in opts and 'p0->e1'in opts and 'p0->e2'not in opts
# 逐帧核对临时力量与本轮格挡。
powers=lambda e:{v['power_id']:v['amount']for v in e['powers']}
assert powers(s[448563]['combat']['enemies'][0])['STRENGTH_POWER']==18
assert powers(s[448567]['combat']['enemies'][0])['STRENGTH_POWER']==6
assert powers(s[448568]['combat']['enemies'][0])['STRENGTH_POWER']==27
assert [s[ln]['combat']['enemies'][0]['intents'][0]['total_damage']for ln in [448565,448566,448567]]==[24,20,15]
assert s[448633]['combat']['player']['block']==16 and s[448634]['combat']['player']['block']==16
assert powers(s[448634]['combat']['enemies'][0])['POISON_POWER']==6 and powers(s[448635]['combat']['enemies'][0])['POISON_POWER']==12
assert s[448634]['combat']['enemies'][0]['current_hp']==34==s[448635]['combat']['enemies'][0]['current_hp']
brains=collections.Counter((x['row'].get('engine'),x['row'].get('model'),x['row'].get('effort'))for x in data['brain'])
assert len(brains)==1 and next(iter(brains))==('codex','gpt-6.1-sol','xhigh')
metrics={'raw_rows_verified':checks,'brain_engine_model_effort':{str(k):v for k,v in brains.items()},'brain_accepted':collections.Counter(str(x['row'].get('accepted'))for x in data['brain']), 'key_numeric_assertions':'passed','target_option_assertions':'passed','known_extraction_failure':'第一次辅助抽取用a[chosen]处理无chosen的map/route-change，KeyError；后改用get，保留失败说明，不是产品bug。'}
(p/'verification.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(metrics,ensure_ascii=False))

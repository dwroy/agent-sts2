import json,pathlib,collections,re,datetime
p=pathlib.Path(__file__).parent
def rows(n):return [json.loads(l) for l in (p/(n+'.jsonl')).open()]
d=rows('decisions');ss=rows('states');report=[]
for x in d:
 a=x['row']; ln=x['source_line']; f=a.get('floor');t=a.get('turn')
 if a.get('decider')=='codex':
  qs=a.get('questions') or {}; facts=next(iter(qs.values()),{}).get('facts',{})
  report.append({'line':ln,'f':f,'t':t,'label':a.get('label'),'chosen':a.get('chosen'),'reason':a.get('rationale'),'facts_keys':list(facts),'journal':a.get('journal')})
(p/'brain-choices.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
with (p/'combat-choices.txt').open('w') as out:
 for x in d:
  a=x['row']
  if a.get('floor') in [13,17,33,35,37,38] and a.get('screen')=='COMBAT':
   out.write(json.dumps({'line':x['source_line'],**{k:a.get(k) for k in ['ts','floor','turn','sl_attempt','sl_reloads','label','decider','chosen','rationale','confidence','result']}},ensure_ascii=False)+'\n')
with (p/'key-states.jsonl').open('w') as out:
 for x in ss:
  a=x['row'];st=a['state'];run=st['run'];c=st.get('combat') or {}
  if run.get('floor') in [13,17,33,35,37,38] and st['in_combat']:
   out.write(json.dumps({'line':x['source_line'],'ts':a['ts'],'floor':run['floor'],'turn':st.get('turn'),'hp':run['current_hp'],'max_hp':run['max_hp'],'p':c.get('player'),'e':c.get('enemies'),'hand':[{k:v for k,v in z.items() if k in ['index','card_id','name','description','cost','is_playable']} for z in c.get('hand',[])],'potions':run['potions']},ensure_ascii=False)+'\n')
lo=d[0]['row']['ts'];hi=d[-1]['row']['ts']; n=0;off=0;cutoff=pathlib.Path('logs/deepseek-reasoning.jsonl').stat().st_size
with open('logs/deepseek-reasoning.jsonl','rb') as src,(p/'deepseek-reasoning.jsonl').open('w') as out:
 for ln,line in enumerate(src,1):
  start=off;off+=len(line)
  if off>cutoff:break
  m=re.search(rb'"ts"\s*:\s*"([^\"]+)"',line)
  if not m or not lo<=m[1].decode()<=hi:continue
  try:a=json.loads(line)
  except ValueError:continue
  out.write(json.dumps({'source_line':ln,'source_offset':start,'row':a},ensure_ascii=False)+'\n');n+=1
print('reasoning窗口',lo,hi,'条数',n)
print('脑决定数',len(report))
for z in report:
 if z['f']>=28 or z['label'].startswith(('rest/','map/')):print(json.dumps(z,ensure_ascii=False))
for x in d:
 a=x['row']
 if a.get('floor')==35 and a.get('questions'):
  print('F35问题结构',x['source_line'],json.dumps(a['questions'],ensure_ascii=False)[:7500]); print('其他字段',list(a));break

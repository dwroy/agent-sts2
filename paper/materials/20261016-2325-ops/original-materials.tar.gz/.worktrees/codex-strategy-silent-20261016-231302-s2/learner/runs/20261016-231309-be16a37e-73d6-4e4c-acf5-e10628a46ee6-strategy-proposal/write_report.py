import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
inputs = json.loads((OUT / 'proposal-inputs.json').read_text())
preflight = json.loads((OUT / 'live-merge-preflight.json').read_text())
audit = json.loads((OUT / 'evidence-audit.json').read_text())
handoffs = json.loads((OUT / 'eight-handoffs.json').read_text())
provenance = json.loads((OUT / 'provenance-audit.json').read_text())
timestamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
(OUT / 'report-date.txt').write_text(timestamp + '\n')

details = {
    '650ea306e8627f9e': {
        'reason': 'K2局48次脑调用与71次含计划复用决策已核；未定位消费错误计数的生产源码，原关联宽机制缺历史dirty源码与知识联合快照，不能登记源码duplicate。',
        'evidence': 'K2JAGKVJAWZJ A10：F27T2、F33、F46；本批核其全局流计数：states814、decisions722、brain48、run-plans7、SL3。48/71只属于K2局。10GPK5XGHCK3 A3与UJ0K3G10609Y A10为原提案补充来源，不能把三局流计数混算。',
        'behavior': '保持机制行为；调用次数与含复用的决策次数分列。没有发现需改生产源码的固定错误分母。',
        'validation': 'provenance-audit.json按engine/decider分别计数；K2为48/71，10G为50/71，UJ为45条DeepSeek脑记录及65个deepseek (for codex)决策。游戏证据与纯Codex战绩口径分开。',
    },
    '60e68d681e861d1c': {
        'reason': '感染先于毒结算已有窄实现；毒瓶多入口及头骨、制品等条件缺完整同盘消费者对照，不能将原宽项整体判为已实现；本批另有合入冲突。',
        'evidence': '79UCJ0K6R9C1 A10 F14T10/T11，s293457—293465：T10由13HP/13挡到T11的2HP/7挡；T11饮毒后目标8HP/10毒，结束时玩家0HP而目标仍8HP/10毒。补充NEWRFAYKTQHR A10 F17T7/F28T7/F31的原提案限制保留。',
        'behavior': '先付已核持牌伤，再判毒结算；不把加毒当即时伤害，不改变药水时点门槛。turn-solver.ts:3305以后已有diesBeforePoison分支，不能称全面漏算。',
        'validation': '九个感染窗口原帧逐offset/bytes/SHA与JSON回读一致；此为材料核验，没有执行求解器、rollout或药水多入口的消费者认证。',
    },
    '9aa48a84227bcdb5': {
        'reason': '缺未执行路线、饮药时点与完整战斗结果的同条件配对和独立留出；实际回复、SL恢复及预测不能互作替代，不能据旧失败记录拟合路线或药价。',
        'evidence': '79UCJ0K6R9C1 A10 F14T10/T11；原资源链另含雕像47→7、再生实回15、三次营火各21。NEWRFAYKTQHR A10 F24/F28/F29/F31原提案已记录实际血药与SL恢复；本批不重算整条历史资源统计。',
        'behavior': '维持现有路线、休息、喝留药参数；实际血价、普通回复与SL恢复分列，不预支未到达营火。',
        'validation': '原Markdown及账本39项范围内的链接核验，感染关键帧直接复核；另一条路线与另一饮药时点的整战反事实仍未知。',
    },
    '7cfd0f9b6b0fbbda': {
        'reason': '坚韧之环施放11挡且敏捷回落后仍续11挡已核；缺跨重问/SL恢复可用的施放额度与剩余轮次联合入口，升级、叠层、重放组合仍未知；合入预检亦冲突。',
        'evidence': 'ZVYUL2YP3518 A10 F33T6—T8，s257820/257821/257823/257828：敏捷6时施放得11挡、power2；敏捷回2后两轮初仍11挡，power1→消失。79UCJ0K6R9C1 F14T10得7挡、T11仍7挡却被持牌感染杀死。',
        'behavior': '保存施放额度与剩余轮次，不能用当前敏捷重算历史额度，也不能将power层数直接当挡量。当前没有可靠恢复入口时维持原行为与未知边界。',
        'validation': '15个坚韧之环窗口及九个感染窗口原字节核验；可靠恢复、升级、叠层、重放的消费者验证未执行。',
    },
    'e6f9cb57c1204036': {
        'reason': '已遵循原感染提案的combat/potion领域勘误；该勘误不能关闭60e68d681e861d1c的多入口/组合消费者缺口，也没有可指认的独立源码实现提交。',
        'evidence': '同79UCJ0K6R9C1 A10 F14T10/T11，账本silent-0286/0278；原修订Markdown SHA一致。',
        'behavior': '感染/毒药水仅归combat与potion；不借此调整terminal规则。原文件及队列id全部保留。',
        'validation': '逐原文核对领域更正，复用本批已核原帧；不另建重复提案id、不把领域文字修订冒称源码duplicate。',
    },
    '6353ffbadaaac619': {
        'reason': '9R局12HP空药连续交接已核；缺独立复活充能真值、固定种子两战配对及按局留出校准，不能把已有禁抽/苦无局部实现当作整个资源提案完成。',
        'evidence': '9R916WW0V65N A10 F48末试T15→F49T1，s295422/295423/295424：12/74HP、四空槽，F49入口无前战能力；F49末T2 s295551玩家实死，敌207+361=568。F42—F47资源明细只引用已校验原提案，不冒称本批重算全部饮药。',
        'behavior': '保留连续Boss模型及当前留药/终局权重；独立记录真实HP、逐槽药水与未知复活充能，不人为补尾巴可用状态。',
        'validation': '交接/末局关键帧与原日志回读，八局交接16帧另核；禁抽/苦无源码覆盖存在不代替固定两战消费者认证。',
    },
    '9e5d50fdd7bf1fbd': {
        'reason': '八局F48→F49血量及逐槽药水连续已核；缺保药/改线的受控两战结果、复活充能真值与独立留出，不能由后战失败拟留药或终局权重。',
        'evidence': '9R916WW0V65N、JMH5C51RLN4E、9TG1RP5LFAAK、ZVYUL2YP3518、TDLBRNA0R05B、TXZ6RVMQA09D、XTSV1U9JD34T、PD9AYQVMLQW6，均A10，分别以12/8/17/50/2/4/23/10HP进入F49；每局前后逐槽药水相同。',
        'behavior': '维持既有连续Boss联合模型，血药按实际样本接续、能力按新战建立；不把八个失败样本拟成价格或安全血线。',
        'validation': 'eight-handoffs.json保存八对原行、offset/bytes/SHA与逐槽值；本批只验证交接端点，不重跑模拟、不补反事实、不新增独立局。',
    },
    '20b9df170d51b280': {
        'reason': '部分机制已有源码，但原六类机制及其组合缺完整同条件消费者认证；实验体早期尝试和女王判死出口截断，后续手牌/动作同变，不支持单因转胜或固定杀序。',
        'evidence': '9R916WW0V65N A10 F48末试T14/T15、F49末试T1/T2：前战余像1/精准4等在交接后不继承；末T2精准4后三刀各8，最终玩家实死、敌仍568。完整六类原证据与限制见原Markdown，账本0023/0094/0054/0173/0028/0069/0079。',
        'behavior': '只补有直接证据的传播缺口，不固定击杀序；已有局部入口与旧经验发布不等于完整候选或整战消费者验证。',
        'validation': '原机制Markdown与勘误均完整保留；本批核交接及末轮原帧与现有源码，不执行六类联合候选，不声称模型已校准。',
    },
    '91cc7fd647077569': {
        'reason': '原13支持局55试5赢、真正重打12场54试4赢的冻结勘误保留；本批未重算完整13局且未定位消费该固定分母的生产源码，不能用当前知识或数据提交冒作源码duplicate。',
        'evidence': '原勘误Markdown与SHA已核；新增支持9R916WW0V65N A10 F48三试仅末试T15实赢。原提案记录旧12支持局52试4赢、重打11场51试3赢，加本局后55/5与54/4；这些历史分母本批仅按原文保存，不当重新估计。',
        'behavior': '原13局冻结集合独立于当前全部静默Boss统计，SL同局归组；保留原20b9稿与后续勘误，不扩成全历史重算任务。',
        'validation': '两份原文均与登记SHA一致，当前原帧能支持新增9R末试结局；未消费原13局全集、无生产固定错误分母定位。',
    },
    '9c3554ff02a3119c': {
        'reason': 'T0局F48T2/T4已充分支持螺线飞镖同线增敏与次轮撤回，当前相关源码仍遗漏；本批main/live十处历史文件冲突阻止实施，属于合入受阻，不是机制证据不足。',
        'evidence': 'T0DGVABPV60U A10 F48末试T2 s296633—296642：四次显式小刀使敏捷/临时标记0→4，T3两者撤回；T3的7敏/4临时量到T4剩3敏。T4 s296655—296660：小刀使3→4，偏折8、防御+12合20；同一新增敏捷在两张后继挡牌各+1，换升级另+3。T5 s296668/296669八敏仍0挡，s296670实死。',
        'behavior': '仅在已核Silent A10显式普通/升级小刀完成后新增1临时敏捷，使后继挡牌兑现，既有挡不倒补；下一轮撤临时量、保留常驻量。自动、重放、随机/多敌和苦无联合触发未获本批验证。',
        'validation': '39个原窗口加T5末帧直接核字节；现combat-plan/turn-solver无该入口/触发，rollout.ts:1338临时敏捷列表仅SPEED_POTION_POWER和ANTICIPATE_POWER。后续应做先刀后挡/先挡后刀、同牌升级分列、入口与新生临时量跨轮撤回固定题；本批因冲突停止，未写源码、未做撤源码失败/恢复通过或消费者测试。',
    },
}

checks = []


def check(name, value):
    assert value, name
    checks.append({'name': name, 'passed': True})


check('ten_original_markdown_hashes', len(inputs['proposals']) == 10 and all(p.get('sha_matches') for p in inputs['proposals']))
check('ordinary_batch_identity', inputs['batch']['task'] == 'strategy-proposal' and inputs['batch']['character'] == 'silent' and inputs['batch']['worktree'] == str(OUT.parents[2]))
check('all_24_run_characters', len(json.loads((OUT / 'verified-runs.json').read_text())) == 24 and all(r['character'].lower() == 'silent' for r in json.loads((OUT / 'verified-runs.json').read_text())))
check('eight_stream_integrity', len(audit['artifact_checks']) == 8 and all(x['passed'] for x in audit['artifact_checks']))
check('merge_conflicts_preserved', preflight['returncode'] == 1 and len(preflight['conflicts']) == 10)
check('k2_call_and_reuse_counts', provenance['runs']['K2JAGKVJAWZJ']['brain:codex'] == 48 and provenance['runs']['K2JAGKVJAWZJ']['decisions:codex'] == 71)
frames = {r['line']: r for items in audit['windows'].values() for r in items}
check('helical_new_and_expired_amounts', frames[296633]['powers'].get('DEXTERITY_POWER', 0) == 0 and frames[296641]['powers']['DEXTERITY_POWER'] == 4 and frames[296642]['powers'].get('DEXTERITY_POWER', 0) == 0)
check('helical_permanent_remainder', frames[296654]['powers']['DEXTERITY_POWER'] == 7 and frames[296654]['powers']['HELICAL_DART_POWER'] == 4 and frames[296655]['powers']['DEXTERITY_POWER'] == 3)
check('helical_block_realization', frames[296656]['powers']['DEXTERITY_POWER'] == 4 and frames[296659]['block'] == 8 and frames[296660]['block'] == 20)
check('helical_attribute_without_block', frames[296668]['powers']['DEXTERITY_POWER'] == 8 and frames[296668]['block'] == 0)
check('infection_death_precedes_poison', frames[293464]['hp'] == 2 and frames[293465]['hp'] == 0 and frames[293464]['enemies'][0]['hp'] == frames[293465]['enemies'][0]['hp'] == 8 and frames[293465]['enemies'][0]['powers']['POISON_POWER'] == 10)
check('toric_cast_snapshot', frames[257821]['block'] == frames[257823]['block'] == frames[257828]['block'] == 11 and frames[257821]['powers']['DEXTERITY_POWER'] == 6 and frames[257823]['powers']['DEXTERITY_POWER'] == frames[257828]['powers']['DEXTERITY_POWER'] == 2)
check('eight_handoff_resource_pairs', len(handoffs) == 8 and all(x['hp_and_potions_equal'] for x in handoffs))
source = json.loads((OUT / 'source-audit.json').read_text())
check('source_unchanged_from_base', all(x['worktree_equals_base'] for x in source['files']))
check('head_and_index_unchanged', subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == preflight['base'] and subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True) == '')
(OUT / 'material-checks.json').write_text(json.dumps({'scope': '证据材料一致性，非生产测试或消费者验证', 'checks': checks}, ensure_ascii=False, indent=2) + '\n')

sections = []
results = []
for item in inputs['proposals']:
    p = item['original']
    key = p['id'].removeprefix('silent-proposal-')
    d = details[key]
    results.append({'id': p['id'], 'state': 'waiting', 'reason': d['reason']})
    sections.append('\n'.join([
        '## ' + p['id'], '',
        '- 原提案：' + p['proposal'],
        '- 原SHA256：' + item['actual_sha256'] + '；与CLI登记一致。',
        '- 来源任务：' + p['source_task'] + '；实现任务：strategy-proposal / 20261016-231302-s2-strategy-proposal。',
        '- 既有账本：' + ', '.join(p['ledger']) + '。',
        '- 证据局／层／回合：' + d['evidence'],
        '- 既有行为／预期行为：' + d['behavior'],
        '- 验证及限制：' + d['validation'],
        '- 本批处置：waiting；' + d['reason'],
        '- 拟合／反例边界：不新增权重、阈值或胜率；原提案反例保留，同局SL不当独立局，不用未执行分支补反事实。',
        '- 回退：本批无源码/知识补丁，无需程序回退；后续只逆向本项净源码提交，保留原日志、账本与并行知识刷新。',
    ]))

header = f'''# 静默猎手本批十项策略提案核验

生成前已执行date：{timestamp}。

批次：20261016-231302-s2-strategy-proposal。角色：silent。普通队列批次，无research_request/implementation_request/proposal_repair；仅处理已领取十个proposal_ids。普通专题请求绑定另一旧批次，不适用于本批。未领取其他提案、不修改根请求，不关闭学习父要求。

开工工作树干净，HEAD及main为{preflight['base']}；git merge --no-edit main返回Already up to date。本批没有源码、知识、任务模板、版本或运维prompt变更，也没有提交或合入。

结论：十项均waiting。螺线飞镖原帧足够支持限定实现，合入预检冲突阻止本批实施；其他项的具体缺数据、局部已实现范围或分母消费者定位缺口逐项列在下文。没有把waiting改写为implemented/duplicate/shipped。

## 证据口径

派发锚点仍为10局：{', '.join(inputs['batch']['runs'])}。另14局均来自本批十项原提案runs字段，合计24局；runs.jsonl逐局核静默身份，A3/A4/A6/A7/A8各1局、A10共19局。不混其他角色统计。十份原Markdown复制原字节且SHA均匹配；39个关联账本保留旧claim、首证、prior、evidence、status和version。

原日志只读，使用本工作树learner/extract_evidence.py共同入口，逐流先固定source_size，再保留每行offset/bytes/SHA。八流共43112个封套：states21415、decisions20231、sl-attempts194、run-config25、run-plans175、brain1048、runs24、fight-plans0。完整截点及SHA见evidence/evidence-manifest.json。fight-plans的0只表示本截点未选中，不能推断原日志不存在；没有复核旧截点或覆盖旧报告。

八个输出流的哈希与计数一致；133个关键窗口帧、额外3帧、八局交接16帧均回到只读原日志核offset/bytes/SHA及JSON。不同检查集合可能重叠，不将相加值冒称独立游戏样本。{len(checks)}项材料断言仅验证保存材料一致性，不等同生产测试、模型校准或消费者认证。

K2局48/71属于不同分母：48次Codex脑调用、71次含复用决策；不能推广为三原来源局合计。UJ补充局实际是DeepSeek脑来源，不能计纯Codex战绩，本批仍按原提案保存其角色内机制证据。

## 合入预检与实施边界

只读git merge-tree --write-tree对照base={preflight['base']}与live={preflight['live']}，退出1，10个历史文件冲突；未在live启动真实merge、未改index或刷新数据，未自行解决并行记录。完整输出见live-merge-preflight.txt。

冲突原文：

''' + '\n'.join('- ' + x for x in preflight['conflicts']) + '''

12个相关源码叶与本批base全相同，其中9个与上述live快照相同；另三个差异限既有Roy/Dai历史注释（card-model.ts 2行、potion-cost.ts 3行、judge.ts 10行），精确SHA和净差分别在source-audit.json、base-live-source.patch。这里只覆盖这12叶，不能据此宣称全源码/全知识相同，更不能代替原运行dirty源码与知识联合快照。

本批不做任何参数拟合。机制建立样本与后验仍按原局分组、时间留出；同局重复/SL不得跨组。药水/终局提案仍缺固定两战配对及独立验证；六类机制宽项不因局部源码或旧知识已发布而关闭。螺线提案后续须先由运维处理合法合入基线，再按原限定范围实现、做撤源码失败/恢复通过和沙箱验证。

## 验证、记录与交接

无源码修改，tsc/vitest/cases均null，未运行生产测试或网络/模型/模拟，也未运行play。撤源码失败及恢复通过均未执行，不能填成功。无提交、无live合入、无发布编号、无shipped；不以旧测试结果代替本批结果。

仅通过根learner/ledger.py update追加现有账本的proposal/report去向与本批限制说明；不改游戏claim、prior、首证或历史evidence，不把原shipped经验降级为proposed，不代运维标shipped。没有新的代码提案，code_proposals使用本批十个原CLI id，不另建重复id。消费队列状态由调用方根据proposal_results登记，本模型不直接改专用队列。追加输入、stdout、物理行与保护字段核验保存在ledger-update*及ledger-append-audit.json；若这些文件缺失或回执失败，则不能声称CLI追溯完成。

最初身份探测将SILENT与silent作了大小写敏感比较而退出，规范化后24局通过；早期源码路径探测有不存在路径返回2，后用rg --files定位实际路径；空fight-plans首行探测触发StopIteration，随后按manifest处理。均为本批材料探测错误，原工具失败保留，不当游戏反例或生产缺陷。audit_evidence.py中的decision_sources因旧字段兼容返回unknown，不用于结论；脑来源统计以另按实际decider字段计算的provenance-audit.json为准。

任务要求普通/high；本工具接口没有本原生运行模型、推理强度与服务档的独立回执，因此不声称已核实际运行档，也未改任何运行配置。未派下级agent。没有新增科学冲突或与旧机制相反的结论；原有未知与原提案反例保留。

提案交运维路径为本目录proposal.md，完整报告为report.md。全部证据、失败和补充稿保留；自身运行中不回收工作树。

'''

text = header + '\n\n'.join(sections) + '\n'
(OUT / 'proposal.md').write_text(text)
(OUT / 'report.md').write_text(text + '\n## 最终机器回报\n\n完整对象另存result.json，十项proposal_results均有具体waiting理由。\n')
result = {
    'task': 'strategy-proposal', 'character': 'silent',
    'batch': '20261016-231302-s2-strategy-proposal', 'base': preflight['base'],
    'runs': inputs['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [p['original']['id'] for p in inputs['proposals']],
    'implementation_domains': ['combat', 'potion', 'sl', 'terminal'],
    'proposal_results': results, 'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'report.md'), 'proposals': len(results), 'material_checks': len(checks)}, ensure_ascii=False))

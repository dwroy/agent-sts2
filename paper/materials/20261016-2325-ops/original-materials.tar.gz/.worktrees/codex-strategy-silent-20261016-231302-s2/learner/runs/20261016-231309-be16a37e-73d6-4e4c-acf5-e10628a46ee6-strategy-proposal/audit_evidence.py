import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT / 'evidence'
manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
checks = []
counts = {}
windows = collections.defaultdict(list)
brain_sources = collections.defaultdict(collections.Counter)
decision_sources = collections.defaultdict(collections.Counter)
anchors = json.loads((OUT / 'proposal-inputs.json').read_text())['batch']['runs']


def compact(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    return {
        'line': item['line'], 'run': item['run_id'], 'floor': run.get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'block': player.get('block'),
        'powers': {p['power_id']: p.get('amount') for p in player.get('powers', [])},
        'potions': [p.get('potion_id') for p in run.get('potions', [])],
        'hand': [{'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                  'text': c.get('resolved_rules_text')} for c in combat.get('hand', [])],
        'enemies': [{'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'),
                     'powers': {p['power_id']: p.get('amount') for p in e.get('powers', [])}}
                    for e in combat.get('enemies', [])],
        'source': item['source'], 'offset': item['offset'], 'bytes': item['bytes'],
        'sha256': item['sha256'],
    }


for entry in manifest:
    name = entry['stream']
    path = EVIDENCE / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    counter = collections.Counter()
    with path.open('rb') as handle:
        for raw in handle:
            digest.update(raw)
            item = json.loads(raw)
            run, row = item['run_id'], item['row']
            counter[run] += 1
            if name == 'states':
                state = row['state']
                floor = (state.get('run') or {}).get('floor')
                turn = state.get('turn')
                if run == 'T0DGVABPV60U' and 296630 <= item['line'] <= 296668:
                    windows['helical'].append(item)
                if run == '79UCJ0K6R9C1' and floor == 14 and turn in (10, 11):
                    windows['infection'].append(item)
                if run == 'ZVYUL2YP3518' and floor == 33 and turn in (6, 7, 8):
                    windows['toric'].append(item)
                if run == '9R916WW0V65N' and floor in (48, 49):
                    windows['handoff' if floor == 48 else 'queen'].append(item)
            if name == 'brain':
                brain_sources[run][str(row.get('engine', row.get('provider', 'unknown')))] += 1
            if name == 'decisions':
                decision_sources[run][str(row.get('source', row.get('engine', 'unknown')))] += 1
    assert digest.hexdigest() == entry['output_sha256'], name
    assert all(counter[r] == n for r, n in entry['counts'].items()), name
    checks.append({'name': name + '_output_sha_and_counts', 'passed': True})
    counts[name] = dict(counter)

limits = {'helical': 50, 'infection': 40, 'toric': 60, 'handoff': 35, 'queen': 35}
selected = {}
raw_checks = []
with (OUT / 'selected-frames.jsonl').open('w') as destination:
    for key, items in windows.items():
        selected[key] = items[-limits[key]:]
        with Path(items[0]['source']).open('rb') as source:
            for item in selected[key]:
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                raw_checks.append({'window': key, 'line': item['line'], 'offset': item['offset'],
                                   'bytes': item['bytes'], 'sha256': item['sha256'], 'passed': True})
                destination.write(json.dumps({'window': key, **compact(item)}, ensure_ascii=False) + '\n')

summary = {'counts': counts, 'brain_sources': {k: dict(v) for k, v in brain_sources.items()},
           'decision_sources': {k: dict(v) for k, v in decision_sources.items()},
           'windows': {k: [compact(x) for x in v] for k, v in selected.items()},
           'artifact_checks': checks, 'raw_frame_checks': raw_checks,
           'anchor_runs': anchors,
           'production_tests': {'tsc': None, 'vitest': None, 'cases': None}}
(OUT / 'evidence-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'streams': len(checks), 'envelopes': sum(sum(c.values()) for c in counts.values()),
                  'raw_frame_checks': len(raw_checks), 'windows': {k: len(v) for k, v in selected.items()}},
                 ensure_ascii=False))

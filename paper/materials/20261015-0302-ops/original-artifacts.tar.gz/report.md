# 静默猎手策略提案批次报告

记录时间：2026-10-15T02:53:24+08:00。task=strategy-proposal；character=silent；batch=20261015-023619-strategy-proposal。

本批十项均为 waiting，没有新增源码、知识、提案 id、提交或 live 合入。已有若干事实与审计子项不能代表整个原提案已实现。没有从败局拟血价系数、固定杀序、能力优先级、禁探索或终局权重。

## 身份与基线

- learn.json 只保存本批对应行到 dispatch.json，核 task、character、worktree、六个派发 runs 及十个 proposal_ids；登记前再次核同。reason=proposal，没有 research_request、implementation_request 或 proposal_repair。
- 普通专题请求 notes/strategy-research-silent.json 的 batch 属于另批，与本批不匹配；没有读取其他专题代替身份，也没有退入其他队列选题。
- 初始工作树干净，git merge --no-edit main 返回 Already up to date。完整 base/最终 HEAD 均为 `642ed80619aef49e194e2eb1e686a801b80e58f5`。production-diff.patch 为0字节，worktree-readback.json 核 tracked clean；scratch 位于本批 learner/runs 并被 Git 忽略。
- 本批自己执行，没有下级 agent。当前运行模型/强度的原生请求元数据未在本任务中核验，不能拿历史六局run-config当本会话模型证明；未修改模型配置、权限或账号。

## 原始证据与核验范围

只用派发的六个静默A10完局：DUZUBAJ3A8GP、5PM6JAQG6FNQ、CA5KE8GFJ9X2、8JRE1C4H4Z2W、YF0LXT1QSTGG、XP2SL33HT0D9。runs.jsonl、选中state.run.character_id/ascension逐条核同。历史run-config的源码均标dirty，所列未提交项主要为当时知识/数据库；当前刷新数据不能冒充当时输入。历史配置显示Codex大脑gpt-6.1-sol/high，旧ds_*计数字段不据以推定实际引擎。

用任务规定的 learner/extract_evidence.py 入口提取八流，evidence/evidence-manifest.json 保存各流独立冻结的 source_size、计数和输出SHA；每条保存source/line/offset/bytes/SHA及原JSON。verify_evidence.py 对全部8274条选中原行重新seek原日志，核字节SHA、正文、显式身份、字节截点及每流输出SHA/计数。run-plans的run字段、其他流run_id/state.run_id/fingerprint.run均由共用入口核；选中行没有冲突身份，不把正文提及当所属局。各流截点是依次冻结，不冒称同一时刻全局快照。

| 流 | 选中行 | 冻结 source_size（bytes） |
|---|---:|---:|
| states | 4062 | 12847715296 |
| decisions | 3941 | 1452036417 |
| sl-attempts | 38 | 39478354 |
| run-config | 6 | 1711099 |
| run-plans | 33 | 7841127 |
| brain | 188 | 531873223 |
| runs | 6 | 329966 |
| fight-plans | 0 | 2233957 |

run-plans选中33行。fight-plans为0行只表示该截点未选到六局显式身份行，不断言原日志缺失。原源流出现的2/2/1条非法JSON（states/decisions/brain）由入口计数并跳过，不混入选中证据；不宣称整个源文件没有损坏。

25项限定材料断言、四组完整fingerprint相等和六处生产夹具原始来源核验均通过，见observation-checks.json、verified-pairs.json、fixture-provenance.json。113个可见相邻轮端点仅提供净血/同阶段敌本体净差；跨阶段进度、末轮未完成、未封顶敌伤与整候选执行归属保留未知。这些是材料校验，不是生产模拟器校准、tsc或Vitest。

## 发现、支持与反例

- DUZUBAJ3A8GP F27 T4—6，账本silent-0168：火花3→6；T5三技能污染0/6/12/18，26攻击对17挡、净损9，次轮污染消失。技能同时兑现毒/挡，不支持统一少打技能。
- 5PM6JAQG6FNQ F39 T2—6，silent-0183/0005：两次抢夺后力敏各−4；两步法逐次回敏到−2/0，失落退场返力到0，遗忘继续抢敏。没有混合来源返还与遗忘非清场死亡的完整端点，不能把敌当前全部属性返还玩家。
- CA5KE8GFJ9X2 F13 T1/3/5，silent-0231：加压力0/4/8、喷水11/15/19，弱后11/14；覆甲只记所见序列，不补完整触发规则。
- 5PM6JAQG6FNQ F38 T3/4，silent-0233/0209：23上限电击机器人力2/4、攻击17/19；index随退场重排，不能拿另一个新实体继承旧增长，另一杀序没有实际后继。
- 8JRE1C4H4Z2W F33首/三试T2，silent-0079：同指纹，净损3→15、本体净扣10→17；题面死亡样本0/24→5/24并不相同。末试T11实建敏捷/余像、22挡仍只有5血对37；毒只兑现24，不能预支未来。
- YF0LXT1QSTGG F48第二/三试T1，silent-0079：同指纹净损0→9、净扣45→38。候选预测是0/10、54/36，不能与实盘数字混写；本局F33确曾SL成功，末试恢复防御的F48 T1仍不足整战取胜。
- YF0LXT1QSTGG F48末T3—5，silent-0021/0027/0028/0085：111→212新阶段清旧毒/力；触媒2而零毒；后得敏捷5→6不倒补已生成23挡。四刀/消耗遗物和阶段变化必须另源分账，净敌HP差不代替所有攻击输出。
- XP2SL33HT0D9 F33首/二试T3与首/末试T1，silent-0079：同指纹净损9→14、净扣24→27；净损2→10、净扣25→34。B2零胜、差0、标准误0不证明实际安全；末试T2零损/T3损4是反对统一禁付血探索的边界。
- XP2SL33HT0D9 F33末T2—5，silent-0241/0242及其他原账本：T2轮初14挡而T3不重复；临减力0→−9→0；火箭57→38→28分别对应朝向与弱；四敏脆弱6挡仍末轮死亡。未减员/能力已建不证明固定能力或目标优先级。

所有逐项账本、证据层/回合、反例、预期行为、验证方法、回退和原Markdown链接在proposal.md。十份原文按队列保存SHA核同后原字节复制到original-proposals/，没有改旧提案或重写历史复盘。

## 当前源码实际覆盖的范围

source-audit.json 保存冻结live HEAD、12个文件的base/live Git blob、SHA256与实际live祖先提交。11叶完全同blob；sl/explore.ts只有三处Roy/Dai历史署名注释差异，已精确验证替换后逐字相同，不能据此称运行行为不同。部分main整合提交不是live祖先，报告使用另核的live源码提交，不冒用main提交作为implemented证明。

- `agent/src/reflex/silent-sl-comparison.ts`：实际live祖先 `a8b1f8be153fe4f3a34146117546c2178f2e446b`。
- `agent/src/reflex/silent-sl-resource-comparison.ts`：实际live祖先 `a8b1f8be153fe4f3a34146117546c2178f2e446b`。
- `agent/src/reflex/silent-selection-audit.ts`：实际live祖先 `05cd292c6f01bb31e406473d3a9843e659d62b93`。
- `agent/src/reflex/silent-selection-dispatch.ts`：实际live祖先 `bade647f9fe4c9103b40e2f26b26296692ad24b7`。
- `agent/src/reflex/silent-hp-guard-audit.ts`：实际live祖先 `a8b1f8be153fe4f3a34146117546c2178f2e446b`。
- `agent/src/reflex/silent-phase-current.ts`：实际live祖先 `8698c581dac6c7e957f50a381586960a6d0c9b57`。
- `agent/src/reflex/silent-phase-reference.ts`：实际live祖先 `1d57f9d0dbbb63603e9ce9768e74cb2021478464`。

SL comparison/resource comparison只列预测；selection audit分Jev原答/护栏后/SL后方案，dispatch receipt只认单步派发，actual_turn与whole_plan_executed仍为null。phase-current只列当前阶段、持有/已建组件与实毒，已兑现毒伤为null。combat-plan.ts与hand/loop.ts已调用这些模块，不能因另有当前空值就用推测填实果。

怪物moveDamageAt/monsterHpAt已按当前进阶事实读取，不设五样本怪物门槛；roomHpCost仍由ROOM_COST_MIN_N=5控制。污染、火花与高电压有现存求解/推演路径。以上只核结构存在及实际live源码，不冒称在六局原dirty输入上完成联合重放或自然消费者验收；因此十个宽请求不整体duplicate。

## 逐项处置

- silent-proposal-c20b5139dd0dff71：waiting。已核F27 T4/T5火花3→6、污染撤除与9净血价；缺当时dirty移动数据库和覆盖技能/虚弱/毒挡收益的生产多步配对校准，不能据单线设少打技能规则。
- silent-proposal-ae9e692d680e3819：waiting。已核F39两次抢夺和失落退场返力；缺混合增益的逐来源借还账、遗忘非清场死亡返敏端点及候选整线校准，不能返还敌当前全部属性或固定杀序。
- silent-proposal-52f1e1bd2e7db0ed：waiting。已核F13加压后力量0/4/8及攻击11/15/19、弱后11/14；当前DB按进阶首样本读取已存在，缺历史dirty移动表与覆甲触发隔离的生产多步重放，不能据此改房间成本。
- silent-proposal-6dd8bbff876be528：waiting。已核F38同23上限电击机器人连续帧力2→4、攻17→19；缺跨召唤稳定实例身份、当时模板和增长重置的联合生产校准及替代杀序后继，通用growth接线不等于整项完成。
- silent-proposal-578e415a259e6835：waiting。已核沙虫同指纹T2净血价3→15、本体净扣10→17；候选分阶段审计和单步回执已有live源码，缺整候选执行归属、重规划边界及独立完整胜线，保留探索与护栏规则。
- silent-proposal-c0767768bf6a7ab1：waiting。已核实验体同指纹T1净血价0→9、本体净扣45→38；现有原/替线预测及派发回执不证明候选完整执行，缺弃牌后续步归属与受控成功整战，不能拟惩罚系数或禁止探索。
- silent-proposal-a46bdb7fe711d79a：waiting。已核F48阶段111→212清旧毒力、触媒2零毒和敏捷5→6不倒补23挡；现场快照已有live实现，缺阶段/消耗遗物/随机抽弃牌的逐候选联合归因与完整消费者校准，不改能力排序。
- silent-proposal-1044224808015e5c：waiting。已核双蟹T3换线多损5多扣3、T1多损8多扣9；缺完整候选执行、配对随机池和独立双蟹整战胜线，B2零差/零标准误不足以修改探索优先级。
- silent-proposal-7cbc6005db712ba9：waiting。已核双蟹T2轮初14、镣铐临减9恢复、朝向57→38→28及四敏脆弱6挡；缺这些来源在整候选中联合传播和实际消费者校准，局部模型/参考已存在不能冒认整个提案duplicate。
- silent-proposal-c59f592f1427a67e：waiting。已核两局同指纹代价、阶段和能力兑现的限定实帧；缺各子域完整候选实果、联合校准、受控路线/留药后继与独立策略分母，不据历史支持总数改成长或终局权重。

## 账本、验证与交付

只用根目录learner/ledger.py update追加30个原账本的本批proposal/report追溯链接，by=learner:strategy-proposal；CLI返回0，输入/回执/逐项读回保存ledger-updates.jsonl、ledger-update-receipt.json、ledger-readback.json。claim/status/首证/asc/prior/evidence/version全部与本批之前相同；已有shipped不降级，新证据不冒充新规则或再标shipped。本批没有新增结论/经验规则，未重复code_proposals add、未造id或直接改队列。

固定材料核验成功；没有修改生产源码或生成器，撤源码失败/恢复通过均不适用，tsc/vitest/cases固定为null。未运行任何生产源码检查，不沿用历史测试成功，未发布eval版本、合入live、修改Roy双通知/运维prompt或启动对局。merge=live仅在有经过验证的新源码时执行，本批没有可合入内容。

首次gitleaks对本批scratch约188.42MB扫描返回0、无泄漏；最终报告生成后另作增量扫描，真实结果见gitleaks-final.log/json。production-diff.patch与worktree-readback.json保留源码零差异证据。本批未提交/推送，root账本CLI记录由调用方按原入库流程归档。

## 限制和保留的失败记录

1. 同一SL存档是相关尝试，不能当独立胜率样本；四组配对只证同题当轮代价。其余未选整线、抽序/随机池、路线/留药后继与受控完整胜线没有补齐。
2. 所有来源局仅A10；原经验中的更宽范围/支持数不当本批跨进阶机制或策略分母。没有分析其他角色来补事实。
3. 原运行dirty知识/移动表未恢复为精确输入；当前源码字段存在不等于模型物理正确、实际已消费或有策略收益。
4. 初次fixture核验误要求完整原行与投影完全相同，因原fixture有意省略agent_view/无关决策字段而失败。initial源码txt及失败log保留；修正为每个保留字段与原行精确相等，同时仍核原字节SHA，最终通过，不把该失败称生产代码失败或删掉。
5. 一次只读工具在沙箱准备时遇并行材料回收路径消失，未执行命令；相同命令重试成功。另两次定向rg含已迁移路径/不存在glob报错，随后按实际hand/loop及明确文件定位，不据搜索失败断言功能不存在。
6. 早期定位命令误输出了fix-queue-v4.md中的历史跨角色段；该段未用于游戏结论、统计、提案、代码或经验，此后只消费已派发十项和静默证据。本报告的每个游戏判断均链接本批静默原字节；保留这项范围失误，不把工具读取范围写成完全无误。
7. 未核本会话原生模型参数；不把请求配置或过去日志当成实际运行模型切换证明。

后续经验入库及大脑消费者读回不在本批冒称完成；学习父要求、十个原waiting提案及未知机制保持开放。报告和proposal路径供运维核验，逐项机器结果见result.json。

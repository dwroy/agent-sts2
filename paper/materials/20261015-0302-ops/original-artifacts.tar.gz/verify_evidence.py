"""Verify preserved evidence bytes and derive bounded, own-character snapshots."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
LOGS = Path('/home/dw/Projects/agent-sts2/logs')
BATCH = json.loads((OUT / 'dispatch.json').read_text())
RUNS = set(BATCH['runs'])
TARGETS = {
    'DUZUBAJ3A8GP': [27], '5PM6JAQG6FNQ': [38, 39],
    'CA5KE8GFJ9X2': [13], '8JRE1C4H4Z2W': [17, 33],
    'YF0LXT1QSTGG': [33, 48], 'XP2SL33HT0D9': [33],
}
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(raw):
    return {p['power_id']: p['amount'] for p in raw.get('powers', [])}


def compact(item):
    row = item['row']
    state = row['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'run': item['run_id'], 'line': item['line'], 'offset': item['offset'],
        'bytes': item['bytes'], 'sha256': item['sha256'],
        'ts': row.get('observed_ts', row.get('ts')), 'screen': state.get('screen'),
        'floor': state.get('run', {}).get('floor'), 'turn': state.get('turn'),
        'ready': combat.get('action_readiness', {}).get('can_use_combat_actions'),
        'hp': player.get('current_hp'), 'block': player.get('block'),
        'energy': player.get('energy'), 'played': player.get('cards_played_this_turn'),
        'player_powers': powers(player),
        'hand': [c.get('card_id') for c in combat.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'),
                     'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'),
                     'move': e.get('move_id'), 'powers': powers(e),
                     'attacks': [(a.get('damage'), a.get('hits')) for a in e.get('intents', [])
                                 if a.get('damage') is not None]}
                    for e in combat.get('enemies', [])],
    }


def main():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    results = []
    frames = []
    decisions = {}
    selected = {}
    for stream in manifest:
        name = stream['stream']
        counts = Counter()
        digest = hashlib.sha256()
        path = OUT / 'evidence' / (name + '.evidence.jsonl')
        with (LOGS / (name + '.jsonl')).open('rb') as raw_source, path.open('rb') as evidence:
            for encoded in evidence:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['run_id'] in RUNS
                assert extract.run_identity(item['row']) == item['run_id']
                assert item['offset'] + item['bytes'] <= stream['source_size']
                raw_source.seek(item['offset'])
                raw = raw_source.read(item['bytes'])
                assert raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                counts[item['run_id']] += 1
                row = item['row']
                if name == 'states':
                    state = row['state']
                    run = state.get('run') or {}
                    if run:
                        assert run.get('character_id', '').lower() == 'silent'
                        assert run.get('ascension') == 10
                    if run.get('floor') in TARGETS[item['run_id']] and state.get('combat'):
                        frames.append(compact(item))
                elif name == 'decisions':
                    decisions[item['line']] = item
                elif name in ['runs', 'run-config', 'sl-attempts', 'run-plans', 'fight-plans']:
                    selected.setdefault(name, []).append(item)
        assert dict(counts) == {r: n for r, n in stream['counts'].items() if n}
        assert digest.hexdigest() == stream['output_sha256']
        results.append({'stream': name, 'verified_lines': sum(counts.values()),
                        'counts': dict(counts), 'source_size': stream['source_size'],
                        'output_sha256': digest.hexdigest()})
    save('verified-streams.json', results)
    save('target-snapshots.json', frames)
    save('run-metadata.json', selected)
    wanted = [270216, 270282, 270264, 271309, 271348, 271354,
              271495, 271509, 271982, 272195, 271992, 272040, 272076]
    save('target-decisions.json', {str(n): decisions[n] for n in wanted if n in decisions})
    pairs = []
    for a, b in [(270216, 270282), (271309, 271348), (271982, 272195), (271992, 272040)]:
        first, second = decisions[a], decisions[b]
        assert first['run_id'] == second['run_id']
        assert first['row']['fingerprint'] == second['row']['fingerprint']
        pairs.append({'run': first['run_id'], 'first': a, 'second': b,
                      'same_fingerprint': True,
                      'first_sha256': first['sha256'], 'second_sha256': second['sha256']})
    save('verified-pairs.json', pairs)
    fixture_checks = []
    fixtures = json.loads((ROOT / 'agent/tests/silent-sl-comparison-evidence.json').read_text())
    for fixture in fixtures:
        assert fixture['run'] in RUNS
        for key, payload in [('state_source', 'board'), ('decision_source', 'decision')]:
            ref = fixture[key]
            with (LOGS / (ref['source'] + '.jsonl')).open('rb') as handle:
                handle.seek(ref['off'])
                raw = handle.read(ref['size'])
            assert hashlib.sha256(raw).hexdigest() == ref['sha256']
            row = json.loads(raw)
            assert extract.run_identity(row) == fixture['run']
            original = row['state'] if payload == 'board' else row
            projected = fixture[payload]
            # The preserved fixture intentionally omits agent_view and unrelated decision metadata.
            assert all(key in original and original[key] == value for key, value in projected.items())
            fixture_checks.append({'run': fixture['run'], 'stream': ref['source'],
                                   'offset': ref['off'], 'bytes': ref['size'],
                                   'sha256': ref['sha256'], 'included_fields_match_raw': True,
                                   'included_keys': sorted(projected),
                                   'omitted_keys': sorted(set(original) - set(projected))})
    save('fixture-provenance.json', fixture_checks)
    print(json.dumps({'verified_lines': sum(s['verified_lines'] for s in results),
                      'target_frames': len(frames), 'fingerprint_pairs': len(pairs),
                      'fixture_raw_checks': len(fixture_checks)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

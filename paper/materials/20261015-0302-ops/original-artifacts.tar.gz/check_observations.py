"""Check bounded observations against byte-verified snapshots; no game simulation."""
import json
from collections import defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
frames = json.loads((OUT / 'target-snapshots.json').read_text())
by_line = {s['line']: s for s in frames}
checks = []


def check(name, lines, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'claim': name, 'state_lines': lines, 'value': actual,
                   'sources': [{k: by_line[n][k] for k in ['run', 'line', 'offset', 'bytes', 'sha256']}
                               for n in lines]})


def player(n, power):
    return by_line[n]['player_powers'].get(power, 0)


def enemy(n, ident=None):
    es = by_line[n]['enemies']
    return next(e for e in es if ident is None or e['id'] == ident)


def amount(n, power, ident=None):
    return enemy(n, ident)['powers'].get(power, 0)


check('棱柱T4火花为3', [274830], amount(274830, 'VITAL_SPARK_POWER'), 3)
check('T4污染在技能后0/3/6', [274830, 274831, 274833],
      [player(n, 'TAINTED_POWER') for n in [274830, 274831, 274833]], [0, 3, 6])
check('T5火花为6', [274834], amount(274834, 'VITAL_SPARK_POWER'), 6)
check('T5污染0/6/12/18', [274834, 274836, 274837, 274838],
      [player(n, 'TAINTED_POWER') for n in [274834, 274836, 274837, 274838]], [0, 6, 12, 18])
check('T5三技能后26攻击/17挡，下一轮净损9且污染消失', [274838, 274839],
      [enemy(274838)['attacks'], by_line[274838]['block'], by_line[274838]['hp'] - by_line[274839]['hp'],
       player(274839, 'TAINTED_POWER')], [[[26, 1]], 17, 9, 0])
check('抢夺后负力量/敏捷与两次步法兑现', [274351, 274352, 274354],
      [(player(n, 'STRENGTH_POWER'), player(n, 'DEXTERITY_POWER')) for n in [274351, 274352, 274354]],
      [(-4, -4), (-4, -2), (-4, 0)])
check('失落退场后力量恢复0，遗忘仍有敏捷4', [274358],
      [player(274358, 'STRENGTH_POWER'), [e['id'] for e in by_line[274358]['enemies']],
       amount(274358, 'DEXTERITY_POWER')], [0, ['THE_FORGOTTEN'], 4])
check('遗忘后续再抢敏捷', [274362], player(274362, 'DEXTERITY_POWER'), -2)
check('蚌力量0/4/8', [273237, 273252, 273263],
      [amount(n, 'STRENGTH_POWER') for n in [273237, 273252, 273263]], [0, 4, 8])
check('蚌无弱攻击11/15/19', [273237, 273252, 273263],
      [enemy(n)['attacks'] for n in [273237, 273252, 273263]], [[[11, 1]], [[15, 1]], [[19, 1]]])
check('蚌后两次虚弱攻击11/14', [273254, 273268],
      [enemy(n)['attacks'] for n in [273254, 273268]], [[[11, 1]], [[14, 1]]])
check('电击机器人23上限连续帧力量2/4，攻击17/19', [274308, 274313],
      [(enemy(n, 'ZAPBOT')['max_hp'], amount(n, 'STRENGTH_POWER', 'ZAPBOT'), enemy(n, 'ZAPBOT')['attacks'])
       for n in [274308, 274313]], [(23, 2, [[17, 1]]), (23, 4, [[19, 1]])])

turns = []
for run, floor in [('8JRE1C4H4Z2W', 33), ('YF0LXT1QSTGG', 48), ('XP2SL33HT0D9', 33)]:
    seq = sorted([s for s in frames if s['run'] == run and s['floor'] == floor and isinstance(s['turn'], int)],
                 key=lambda s: (s['ts'], s['line']))
    attempt, previous = 1, 1
    groups = defaultdict(list)
    for s in seq:
        if s['turn'] < previous:
            attempt += 1
        previous = s['turn']
        groups[(attempt, s['turn'])].append(s)
    for (attempt, turn), group in groups.items():
        starts = [s for s in group if s['ready'] and s['played'] == 0]
        if not starts:
            continue
        first = starts[0]
        later = groups.get((attempt, turn + 1))
        last = later[0] if later else None
        same_phase = last is not None and [(e['id'], e['max_hp']) for e in first['enemies']] == [
            (e['id'], e['max_hp']) for e in last['enemies']]
        turns.append({'run': run, 'floor': floor, 'attempt': attempt, 'turn': turn,
                      'start_line': first['line'], 'next_turn_line': last['line'] if last else None,
                      'net_player_hp_loss': first['hp'] - last['hp'] if last else None,
                      'enemy_body_net_hp_drop': sum(e['hp'] for e in first['enemies']) - sum(e['hp'] for e in last['enemies']) if same_phase else None,
                      'body_progress_status': 'same_phase_net_observation' if same_phase else 'unknown_terminal_or_phase_transition',
                      'uncapped_enemy_damage': None, 'whole_candidate_executed': None})

for run, a, b, t, expected in [
    ('8JRE1C4H4Z2W', 1, 3, 2, [3, 15, 10, 17]),
    ('YF0LXT1QSTGG', 2, 3, 1, [0, 9, 45, 38]),
    ('XP2SL33HT0D9', 1, 2, 3, [9, 14, 24, 27]),
    ('XP2SL33HT0D9', 1, 6, 1, [2, 10, 25, 34]),
]:
    x, y = [next(s for s in turns if s['run'] == run and s['attempt'] == a0 and s['turn'] == t) for a0 in [a, b]]
    lines = [x['start_line'], x['next_turn_line'], y['start_line'], y['next_turn_line']]
    check('同指纹对应尝试的当轮净血价/敌本体净扣：' + run + '/T' + str(t), lines,
          [x['net_player_hp_loss'], y['net_player_hp_loss'], x['enemy_body_net_hp_drop'], y['enemy_body_net_hp_drop']], expected)

check('实验体阶段边界不得把净HP差计成伤害', [277512, 277513],
      [(enemy(n)['hp'], enemy(n)['max_hp'], amount(n, 'POISON_POWER'), amount(n, 'STRENGTH_POWER'))
       for n in [277512, 277513]], [(4, 111, 4, 15), (212, 212, 0, 0)])
check('触媒2已建且新阶段零毒', [277519],
      [player(277519, 'ACCELERANT_POWER'), amount(277519, 'POISON_POWER')], [2, 0])
check('后取得敏捷5到6不倒补23挡', [277523, 277526],
      [(player(n, 'DEXTERITY_POWER'), by_line[n]['block']) for n in [277523, 277526]], [(5, 23), (6, 23)])
check('实验体末轮活帧攻击44/格挡23/HP18', [277527],
      [enemy(277527)['attacks'], by_line[277527]['block'], by_line[277527]['hp']], [[[11, 4]], 23, 18])
check('双蟹T2轮初14挡，T3未重复给挡', [278236, 278242],
      [by_line[n]['block'] for n in [278236, 278242]], [14, 0])
check('镣铐本轮临时负9力量/攻击0，次轮恢复', [278237, 278242],
      [(amount(n, 'STRENGTH_POWER', 'CRUSHER'), enemy(n, 'CRUSHER')['attacks']) for n in [278237, 278242]],
      [(-9, [[0, 1]]), (0, [[10, 2]])])
check('双蟹朝向与虚弱分步57/38/28', [278249, 278252, 278253],
      [enemy(n, 'ROCKET')['attacks'] for n in [278249, 278252, 278253]], [[[57, 1]], [[38, 1]], [[28, 1]]])
check('四敏脆弱下6挡，净损22进入11血', [278255, 278257],
      [player(278255, 'DEXTERITY_POWER'), by_line[278255]['block'], by_line[278255]['hp'] - by_line[278257]['hp'], by_line[278257]['hp']],
      [4, 6, 22, 11])
check('沙虫末轮22挡/5血/37攻击，毒只扣24', [276433, 276434],
      [by_line[276433]['block'], by_line[276433]['hp'], enemy(276433)['attacks'],
       enemy(276433)['hp'] - enemy(276434)['hp']], [22, 5, [[37, 1]], 24])

(OUT / 'observation-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
(OUT / 'turn-endpoints.json').write_text(json.dumps(turns, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_assertions': len(checks), 'turn_endpoint_pairs': sum(t['next_turn_line'] is not None for t in turns),
                  'whole_candidate_outcome_verified': 0, 'scope': '材料核验，不是tsc/vitest或生产模型校准'}, ensure_ascii=False))

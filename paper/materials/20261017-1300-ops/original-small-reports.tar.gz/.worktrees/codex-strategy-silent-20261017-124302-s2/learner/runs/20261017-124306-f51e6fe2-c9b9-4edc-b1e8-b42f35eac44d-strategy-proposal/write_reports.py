import collections
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BATCH = '20261017-124302-s2-strategy-proposal'
stamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
audit = json.loads((OUT / 'source-audit.json').read_text())
validation = json.loads((OUT / 'material-validation.json').read_text())
specs = [
    {
        'evidence': 'RC61MFQM63Y6 A10 F23 T3/T4，states 285222—285230；F17/F29/F33范围仍按原提案保留。',
        'finding': '预判后敏捷1，速度药后6；斗篷实加12挡，后续防御9挡，第三攻击零直伤仍加4挡；下一轮临时属性消失。原帧支持这些局部结算。',
        'counter': '本次没有隔离柔嫩/脆弱/翻倍/首刀的所有联合条件，也没有移去组件后的受控整战；原提案六次SL属于同一相关局。',
        'expected': '继续按逐牌和实际已建立能力核验；不把知识文本或某个现存公式当八组件已全部兑现。',
        'validation': '冻结285222起的原手牌、药槽、柔嫩及攻击计数，逐步重放到285230；还须分别补F17/F29/F33的生产消费者输出及未见组合拒绝边界。',
        'reason': '局部敏捷/柔嫩/折扇帧已复核；八组件的联合生产消费者校准及首刀/脆弱/倍率边界仍未完成，不能整包duplicate或扩展未见组合。',
    },
    {
        'evidence': 'XTSV1U9JD34T A10 F49 T1/T3/T4，states 286897—286899、286978/286982/286986/286987；decisions 280550、280631、280635—280639。',
        'finding': '幽灵0→1层、16挡保23血、下轮留10挡；末次T3实损22到1血，T4建立NIGHTMARE_POWER3仍当轮归零。单层幽灵已有live源码96f17377a331e50ea5b6a3fe8d2b605932ed1bd4。',
        'counter': 'T1用药确实零损；未到下一轮不能据此认定复制牌在存活后仍不可兑现，也不能认定延后喝药有整战优势。',
        'expected': '保留已实现的单层幽灵比较；复制收益须有合法复制对象和存活后继，不增加晚喝或禁夜魇规则。',
        'validation': '单层效果与死亡前复制标记分开核；补同抽序的合法复制/存活后继及饮药时点的完整结果，再验证评价器。',
        'reason': '单层幽灵已存在真实live祖先实现；夜魇合法复制后的存活兑现与延后饮药受控后继仍缺，不能用单层子项关闭整个存活/时点提案。',
    },
    {
        'evidence': 'BTSRF7JL1W1Y A10 F31 T2，states 286158—286162；XTSV1U9JD34T A10 F48 T8/F49 T4，286893/286894/286896/286986/286987。',
        'finding': '生存者前仅剩生存者/突然一拳，出牌后两牌离手、末挡13；X首王32→23并以23进入F49。单弃bf423c173d3be348a4ad714e1d26516df619ff41及限定毒胜保血222445a9bb6bf56cb4f3ceea2cc8b20fba54128f均为真实live祖先。',
        'counter': '原日志不能把重规划前的所有候选续步都认证为实际执行；耳环接管内部动作缺失，夜魇后继未到，子修复不覆盖这三项联合要求。',
        'expected': '保持单弃及毒胜保血子修复；不预支接管动作或未生存到的复制收益。',
        'validation': '分别回放强制弃牌、抽牌重问、接管状态边界与毒终局资源；每条完整候选须用decision/fingerprint/attempt及真实动作链认证。',
        'reason': '单弃与限定毒胜保血已有实际live源码；接管内部动作、夜魇存活后继及跨抽弃牌完整候选执行归属未齐，整项继续waiting。',
    },
    {
        'evidence': 'BTSRF7JL1W1Y A10 F30/F31，states 286112/286141/286147；XTSV1U9JD34T A10 F48 T8/F49 T1，286842/286894/286896。',
        'finding': 'B F30实到70、赢后42、F31入42；X F48实到97、赢后23、F49仍23。resource-chains按每次重打分段，缺失出口保留unknown。',
        'counter': '净血差混有回血/自损，不能当敌人毛伤；未到的营火或未走路线不是已可用资源，没有同条件改线/留药/锻造胜负对照。',
        'expected': '资源接续按实到血量/药栏，SL恢复与新获得分账；不添加安全血线或路线机会成本参数。',
        'validation': '逐源对齐用药、恢复、SL与出入战帧；把这些输入交路线/休息消费者，并以独立本角色时间留出检验，不以端点代替消费者校准。',
        'reason': '资源端点与SL分段可追溯；仍缺逐来源路线/休息消费者校准及同条件改线、留药、锻造后继和独立留出，不拟合安全血线或药价。',
    },
    {
        'evidence': 'BTSRF7JL1W1Y A10 F31 T2，286158—286162；XTSV1U9JD34T A10 F49 T1/T3/T4，286897—286899、286978/286982/286986/286987。',
        'finding': 'B镣铐后石虫力量−9，生存者后13挡另有覆甲3；X幽灵、留挡和临时降力均有局部帧。步法建立后已有旧挡不自动补量，末T4有3敏与脆弱时防御6。',
        'counter': '覆甲/临时属性/留挡/敌成长的多源效果没有在本批做共同输入生产回放；旧挡、下轮留挡与本轮牌挡不能相加为新能力的直接收益。',
        'expected': '仅保留已观察的实际来源与时点；不把留挡上限当每轮保底，不按未验证成长或毒触发新增规则。',
        'validation': '在固定原手牌上分解牌挡、覆甲、临时减力撤回、毒触发与下一轮留挡，要求共同消费者输出逐步对齐。',
        'reason': '局部覆甲、药层与临时减力已核；毒触发/属性撤回/留挡/敌成长的逐源联合消费者回放仍缺，局部模型不能认证整包实现。',
    },
    {
        'evidence': '9Z9H2EXKLF3T A10 F48末试T8/T10/T11，states 287989—287991、288000/288003—288008；三次SL分段见resource-chains。',
        'finding': '首挡32仍归零后复活20；末T10挡18→27→37仍损15；末T11敌112→32、毒39→37。敌血净降80与39+38毒77的差不能单靠端点当完整逐击事件账。',
        'counter': '两次致死截断、复活中间状态与换线后抽牌/熔炉时点改变；预测“多损7换16伤”不是完整实盘收益。',
        'expected': '继续分列预测/实线、持牌伤/毒/荆棘与复活，不由有限全败样本新增SL血价或持有价。',
        'validation': '完整候选逐步执行归属、逐击未截断毛伤及同条件完整后继，固定倍率首张状态；缺帧仍unknown。',
        'reason': '倍率挡、复活及毒结算局部帧可核；未截断逐击毛伤、完整候选执行归属和同条件整战后继仍缺，不能校准联合模型或SL血价。',
    },
    {
        'evidence': '原提案十局：HMVJKM56S4Q8/F4QKG4J1AJJZ/G403VCZ3BH1B A9；25226ZFLNR1J/JLN5SK17W4FQ/JMH5C51RLN4E/9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0/9Z9H2EXKLF3T A10；F17→18或F33→34共16对。9Z另核F35/38/39/45/48资源。',
        'finding': '原十局16对跨幕转换全部匹配floor(缺血×80%)；本批其他五局再有6对，总22对（A9为5对，A10为17对）。9Z实战66→30、30→19、19→11，后续31→7，F48实到27。',
        'counter': '22对不是22个独立对局，其他五局不冒原十局输入；本批未重做原116局资源模型，跨幕限定公式不等于路线/休息/SL整包通过。',
        'expected': '保留A9/A10同上限已观察的回复边界；营火、精灵复活、SL药栏恢复分别记，不外推更低进阶或未知交互。',
        'validation': '逐对原字节校验已做；还需原116局完整冻结输入、路线/休息生产消费者及独立路线后继的校准。',
        'reason': '原十局16对及本批其他五局6对仅支持限定跨幕公式；原116局完整资源输入、路线/休息消费者校准和独立路线收益仍未交齐。',
    },
    {
        'evidence': '7X0W3U8TVA2A A10 F31 T13，states 288470—288472、decision 282021；F31早段decision 281953。',
        'finding': '后段零毒→7，当步敌25血/玩家1血均不变，结算后段18且玩家0；同盘前段已有8毒。未知持有价与计费0的区别已有源码c4670f4f416c7d93e192e889c5080e7e4e0e733f。',
        'counter': '只观察后段零毒一次，无其他目标/既有毒/重接的同条件饮药对照；7是组合总增量，不能再额外叠头骨1，也不能据死亡推出早喝无效或必优。',
        'expected': '保留独立饮药选项及未知药价；不把标量observedPoison上下文统一扩为所有目标7毒。',
        'validation': '需把具体目标、已有毒、重接与原遗物/能力组合限定进共同推演，完整候选要保留未知目标分支；分别验证实际18血与不重复加头骨。',
        'reason': '实加7仅证后段零毒单次；现有observedPoison是对候选目标共用的标量，本盘前段另有8毒，缺其他目标/叠毒/重接校准，不能统一赋7或拟早喝/持有价。',
    },
    {
        'evidence': 'MTQ0EUBJ3R6T A10 F23四试T3/T5，decision 282434；states 288806—288812、288899—288905、288910—288915；F19/F20资源段。',
        'finding': '首试原线29挡/零损；第四试19挡/损8，多6即时伤；次轮速度层撤回。末T5两毒素逐张付能离手，不能继续计10持牌伤。SL差值审计1698adc96ba434a46942321e0237b70657e625b2已在live祖先。',
        'counter': '原线也未见胜利，四试是一个相关局；改出牌影响后续抽牌。预测24/24全败不是实盘必死证明，敌残29对37也不是独立胜率比较。',
        'expected': '保留现有探索排序与药价，模型差值与实血分账；不新增8点HP阈值或权重。',
        'validation': '锁原题、药水、抽弃序，先还原当轮0/8损与毒素离手，再用独立A10留出和受控完整后继评估探索排序。',
        'reason': '多损8/多伤6及临时药层已核、差值审计已有live源码；独立A10留出与固定抽弃/药时点的完整后继不足，不能拟饱和探索HP门槛或药价。',
    },
    {
        'evidence': '7X0W3U8TVA2A A10 F30 T3/F31 T1/T2/T13，states 288388/288389/288404/288405/288470—288472；MTQ0EUBJ3R6T A10 F20 T3/F23 T3/T5，288806—288812、288899—288915。',
        'finding': '已核蛇咬/头骨施毒局部帧、速度+5后由实际牌兑现、次轮撤回，及两毒素主动离手；已有能力不能替代当步格挡。十四组件原文和经验id完整保留。',
        'counter': '逐帧观察不是十四组件联合生产消费者验证；毛伤事件、昏眩单牌、敌临时属性/能力后继与未知抽牌仍有未校准边界。',
        'expected': '保留逐牌、已建立能力与临时层边界；不外推基础药效、持有价或完整组合价值。',
        'validation': '逐项固定输入到共同生产消费者的回放、联合交互与未知分支拒绝；已实现组件按真实源码祖先登记，整包须满足全部范围。',
        'reason': '十四项已有局部观察与若干源码组件；仍缺完整联合生产消费者校准、部分能力/昏眩/临时属性后继，不把经验入库当整包源码兑现。',
    },
]
assert len(specs) == len(assigned) == 10
proposal = [f'# 本批十项策略提案复核\n\n记录时间：{stamp}\n\n批次：{BATCH}；角色silent；基线`{audit["base"]}`。\n',
    '只处理dispatch.json里的十个ID。非专题、非implementation_request，不改调度绑定。所有旧Markdown均按保存的SHA核对并复制为*.original.md，既有id不重建。\n',
    '方法：只用原提案明确引用的15个静默局（A9三局、A10十二局），十个派发锚点另保留。SL是相关重打；不跨进阶拟合参数。本批无新参数训练或模型收益检验；未来本角色独立完局才可作时间留出。本批不读取其他角色私有知识。\n',
    '共同源码与回退边界：未改任何生产源码/经验/生成数据；铁甲与其他未观察进阶无本批行为变化。若以后实现，应每项独立提交、固定原输入做撤源红/恢复绿、跑沙箱入口、锁内合live并双通知；仅逆向该项真实实现，保留并行知识和历史。本批无可回退的行为补丁。\n']
results = []
for i, (p, s) in enumerate(zip(assigned, specs), 1):
    results.append({'id': p['id'], 'state': 'waiting', 'reason': s['reason']})
    proposal.append(f'## {i}. {p["id"]}\n\n原题：{p["summary"]}\n\n来源任务：{p["source_task"]}；实现任务：strategy-proposal/{BATCH}。原文：`{p["proposal"]}`；SHA256：`{p["proposal_sha256"]}`。\n\n账本：'+ '、'.join(p['ledger'])+'。\n\n')
    for key, title in [('evidence', '证据局/层/回合'), ('finding', '本批核实与已有实现'), ('counter', '反例与未知'), ('expected', '预期行为/旧新边界'), ('validation', '验证方法'), ('reason', '处置waiting')]:
        proposal.append(f'{title}：{s[key]}\n\n')
(OUT / 'proposal.md').write_text(''.join(proposal))

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
stream_table = '\n'.join(f'|{m["stream"]}|{m["source_size"]}|{sum(m["counts"].values())}|{m["invalid_lines"]}|{m["incomplete_lines"]}|' for m in manifest)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': audit['base'],
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [p['id'] for p in assigned], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
rows = []
for ident in sorted({ident for p in assigned for ident in p['ledger']}):
    ids = [p['id'] for p in assigned if ident in p['ledger']]
    rows.append({'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
        'note': f'{BATCH}：仅复核既有提案'+','.join(ids)+'；全部waiting，详本批报告；未新增支持/重复证据、状态、版本或shipped，未改claim/首证/先验。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows))
report = f'''# 静默策略提案批次报告

时间：{stamp}。批次：{BATCH}。

十项均waiting；本批没有实现、重复完成或上线声明。完整逐项证据、账本、反例、预期行为和验证条件见[proposal.md](proposal.md)，机械结果见[result.json](result.json)。没有源码、知识、版本提交，fixes=[]、merged=null。原报告/失败/日志均保留。

## 身份与基线

首次git status --short为空，HEAD={audit['base']}；按要求git merge --no-edit main返回Already up to date，基线未动。dispatch.json只保存根learn.json本batch行：reason=proposal、character=silent、工作树匹配、十proposal_ids齐全，无research_request/implementation_request/proposal_repair。普通专题请求另绑定20261010批次，不匹配本批，未读取其work_spec或改写身份。未读取其他批队列/领取新ID。

十份原Markdown的保存SHA全部匹配；assigned-proposals.json保留队列原折叠状态与原因，*.original.md保留原字节。不会把队列旧seen_runs或waiting原因直接当本批证据。

## 原始证据与范围

用本工作树learner/extract_evidence.py按显式run/run_id/state.run_id/fingerprint.run抽取；runs.jsonl核15局全为SILENT，A9三局、A10十二局。十个派发锚点保留在最终runs；额外五局7X0W3U8TVA2A、MTQ0EUBJ3R6T、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0都是本批原提案明确证据，不是额外选题。所有运行code均带dirty，不能恢复当时完整生产树。

|流|冻结source_size字节|本角色入选行|坏JSON行|不完整行|
|---|---:|---:|---:|---:|
{stream_table}

共22424条封套。evidence/evidence-manifest.json记录逐流截点、逐局计数及输出SHA，每行封套保留原offset/bytes/SHA和line。坏行归属不明，不把它们当任一局缺失证据；fight-plans零行只说明该字节截点未选到，不说明原流缺失。run-plans有97行，不把正文提及当身份。本批未复核旧source-size截点、未覆盖旧批报告或零行初稿。

analysis.stdout.txt与compact-states.json覆盖11008观测状态；resource-chains.json按重打分成282战斗片段，不称282独立战斗或样本。入口/出口缺帧保持unknown，净HP变化不当毛伤或分源伤害；未消费药栏变动不能单凭状态称为饮用/弃药。

## 可支持的限定结论

RC61MFQM63Y6 F23T3显示临时敏捷、柔嫩与实际逐牌格挡：预判后1敏、速度后6敏、斗篷12挡、防御9挡、零直伤第三攻击触发折扇4挡；下轮临时属性归零。不能外推所有脆弱/倍率/首刀联合条件。

XTSV1U9JD34T F48T8胜后32→23且原样23进F49；F49T1幽灵新增一层、16挡下保23血，次轮留10挡。末T3损22、T4夜魇建立3标记后仍死亡。早喝有本轮兑现，延后是否改善整场及合法复制存活收益未知，不推出晚喝或禁用规则。

7X0W3U8TVA2A F31T13零毒后段实加7，施毒当步敌HP与玩家HP不变，结算后段25→18且玩家死亡。本盘前段已有8毒；现有observedPoison是标量，不能仅据后段一次饮用给所有目标/既有毒/重接组合统一赋7。未知持有价已由现存源码区分，仍不是已校准的早喝/留药价值。

MTQ0EUBJ3R6T F23T3原线29挡零损、替线19挡损8，多6即时伤；四试是一个相关局，全部有限推演败不等实盘必死。末T5两毒素已付能离手，不继续计留手10伤。没有独立A10后继可拟新的血价阈值。

跨幕22对均匹配原提案限定的floor(缺血×80%)：A9五对/A10十七对；其中cd9f原十局为16对，其余五局6对分列在act-transition-pairs.json。上限相同的观察支持不等于已跑原116局资源模型、路线/休息消费者或独立改线因果。

9Z9H2EXKLF3T的倍率挡/持牌伤/复活与毒结算已核：末T8首挡32仍死后复活20；T10挡37仍损15；T11敌112→32、毒39→37。净敌血差80不是未截断毛伤事件；不能把预测换线血价当实际收益。

以上没有新机制反证或对原经验的异议；保持原有限结论，不生成重复科学通知或代填任何角色ACK。宽父要求和未满足验证条件继续保留。

## 现有实现与生产边界

只读live快照`{audit['live_snapshot']}`，不是本批合入。material-validation.json逐项证明以下源码commit为该live真实祖先：

''' + '\n'.join(f'- {a["scope"]}：`{a["commit"]}`。' for a in validation['narrow_anchors']) + f'''

这些只认证对应子功能，不给十个宽提案整项duplicate。source-audit.json比较16个相关叶：10字节相同，4仅历史署名，rollout.ts及rollout-live.ts有真实H0代码差异，入口源码明确限定Silent A2。保存base-to-live-audited-leaves.patch与每叶SHA；不将该局部源码检查说成全live树等价、原dirty运行树或A9/A10生产校准。

## 验证与记录

本批verify_material.py退出0：48项材料断言通过，124条原始引用按offset/bytes/SHA及显式身份独立读回全部通过。不是生产消费者、模型校准、tsc或vitest结果。analyze_evidence.py退出0；原stdout/stderr和验证JSON保留。

无生产源码修改，所以不做撤源码红/恢复绿，不跑tsc/vitest/沙箱整套，不生成代码提交、eval发布号或live merge；最终tests三项均null。未发布、不推送、不运行play，未改其他角色知识或对局行为。回退不适用。

探索中几条rg/sed命令因猜测不存在的旧路径返回2；后续用rg --files定位真实路径。一次账本输出过大被工具截断，已从保存的ledger-before.json改为限定局号与有限字段重读；没有据截断输出作结论。这些不是生产测试失败，未覆盖原工具历史。

ledger-updates.jsonl共{len(rows)}条，只链接既有本角色条目与本proposal/report，by=learner:strategy-proposal；不写新claim/evidence、状态、版本或shipped。根账本只经CLI update执行，实际退出与物理前缀/逐行核见ledger-cli及ledger-write-audit.json；不将准备输入冒已追加成功。既有提案ID直接用于code_proposals，不重复add或修改队列原文。

运维交接：[proposal.md](proposal.md)、[result.json](result.json)、[material-validation.json](material-validation.json)。十项waiting理由逐项在proposal与JSON中，待具体缺失输入/新局补齐重派；本批报告不关闭父要求、不冒称经验已入live或大脑已采用。完成后保留原日志/账本/产物，由原调度器验收回收，不删除自身工作树。
'''
(OUT / 'report.md').write_text(report)
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal': str(OUT / 'proposal.md'), 'proposal_results': len(results), 'ledger_rows_prepared': len(rows)}, ensure_ascii=False))

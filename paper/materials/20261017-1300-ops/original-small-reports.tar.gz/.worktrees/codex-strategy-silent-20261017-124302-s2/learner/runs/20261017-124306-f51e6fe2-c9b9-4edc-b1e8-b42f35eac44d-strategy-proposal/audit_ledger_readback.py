import copy
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROJECT = Path('/home/dw/Projects/agent-sts2')
old = json.loads((OUT / 'ledger-write-audit.json').read_text())
before = json.loads((OUT / 'ledger-immediate-before.json').read_text())
after = json.loads((OUT / 'ledger-after.json').read_text())
spec = importlib.util.spec_from_file_location('ledger', PROJECT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
expected = copy.deepcopy(before)
assert old['cli_exit'] == 0 and old['own_row_count'] == 46
ledger = PROJECT / 'paper/materials/learning/ledger.jsonl'
with ledger.open('rb') as handle:
    prefix = handle.read(old['prefix_size'])
assert hashlib.sha256(prefix).hexdigest() == old['prefix_sha256']
for row in old['own_rows']:
    with ledger.open('rb') as handle:
        handle.seek(row['offset'])
        raw = handle.read(row['bytes'])
    assert hashlib.sha256(raw).hexdigest() == row['sha256'] and json.loads(raw) == row['row']
    assert set(row['row']) == {'op', 'id', 'ts', 'by', 'where', 'note'}
    module.apply(expected, row['row'])
assert expected == after
protected_keys = ('claim', 'character', 'kind', 'evidence', 'first_run', 'asc', 'prior', 'prior_note',
                  'prior_runs', 'status', 'version', 'effect', 'shipped_at')
for ident in before:
    assert all(before[ident].get(k) == after[ident].get(k) for k in protected_keys)
    assert after[ident]['history'][:-1] == before[ident]['history']
    assert set(after[ident]['history'][-1]) == {'ts', 'by'}
    assert after[ident]['notes'][:-1] == before[ident]['notes']
    assert all(set(values) <= set(after[ident]['where'][key]) for key, values in before[ident]['where'].items())
stamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
result = {'recorded_at': stamp, 'read_only': True, 'cli_invocations': 1, 'cli_exit': 0, 'rows': 46,
          'physical_rows_verified': 46, 'root_prefix_unchanged': True, 'expected_fold_equals_saved_after': True,
          'all_protected_fields_equal': True, 'all_old_history_notes_where_preserved': True,
          'correction': '原附加审计误将CLI正常追加的history/notes作为不可变字段；仅history/notes/where变化。原失败文件与日志保留，未重复CLI或改写根账本。'}
(OUT / 'ledger-readback-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

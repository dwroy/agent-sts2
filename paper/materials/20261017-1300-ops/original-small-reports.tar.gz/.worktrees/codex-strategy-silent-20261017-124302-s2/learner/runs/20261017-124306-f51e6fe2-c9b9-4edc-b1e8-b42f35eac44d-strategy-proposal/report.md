# 静默策略提案批次报告

时间：2026-10-17T12:54:43+08:00。批次：20261017-124302-s2-strategy-proposal。

十项均waiting；本批没有实现、重复完成或上线声明。完整逐项证据、账本、反例、预期行为和验证条件见[proposal.md](proposal.md)，机械结果见[result.json](result.json)。没有源码、知识、版本提交，fixes=[]、merged=null。原报告/失败/日志均保留。

## 身份与基线

首次git status --short为空，HEAD=ed6d77cea7b5c7a4980888e9f5877b6e00be3d7e；按要求git merge --no-edit main返回Already up to date，基线未动。dispatch.json只保存根learn.json本batch行：reason=proposal、character=silent、工作树匹配、十proposal_ids齐全，无research_request/implementation_request/proposal_repair。普通专题请求另绑定20261010批次，不匹配本批，未读取其work_spec或改写身份。未读取其他批队列/领取新ID。

十份原Markdown的保存SHA全部匹配；assigned-proposals.json保留队列原折叠状态与原因，*.original.md保留原字节。不会把队列旧seen_runs或waiting原因直接当本批证据。

## 原始证据与范围

用本工作树learner/extract_evidence.py按显式run/run_id/state.run_id/fingerprint.run抽取；runs.jsonl核15局全为SILENT，A9三局、A10十二局。十个派发锚点保留在最终runs；额外五局7X0W3U8TVA2A、MTQ0EUBJ3R6T、9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0都是本批原提案明确证据，不是额外选题。所有运行code均带dirty，不能恢复当时完整生产树。

|流|冻结source_size字节|本角色入选行|坏JSON行|不完整行|
|---|---:|---:|---:|---:|
|states|13860619081|11008|2|0|
|decisions|2202306684|10609|2|0|
|sl-attempts|45176181|109|0|0|
|run-config|1939174|16|0|0|
|run-plans|8841929|97|0|0|
|brain|732394150|570|2|0|
|runs|356728|15|0|0|
|fight-plans|2233957|0|0|0|

共22424条封套。evidence/evidence-manifest.json记录逐流截点、逐局计数及输出SHA，每行封套保留原offset/bytes/SHA和line。坏行归属不明，不把它们当任一局缺失证据；fight-plans零行只说明该字节截点未选到，不说明原流缺失。run-plans有97行，不把正文提及当身份。本批未复核旧source-size截点、未覆盖旧批报告或零行初稿。

analysis.stdout.txt与compact-states.json覆盖11008观测状态；resource-chains.json按重打分成282战斗片段，不称282独立战斗或样本。入口/出口缺帧保持unknown，净HP变化不当毛伤或分源伤害；未消费药栏变动不能单凭状态称为饮用/弃药。

## 可支持的限定结论

RC61MFQM63Y6 F23T3显示临时敏捷、柔嫩与实际逐牌格挡：预判后1敏、速度后6敏、斗篷12挡、防御9挡、零直伤第三攻击触发折扇4挡；下轮临时属性归零。不能外推所有脆弱/倍率/首刀联合条件。

XTSV1U9JD34T F48T8胜后32→23且原样23进F49；F49T1幽灵新增一层、16挡下保23血，次轮留10挡。末T3损22、T4夜魇建立3标记后仍死亡。早喝有本轮兑现，延后是否改善整场及合法复制存活收益未知，不推出晚喝或禁用规则。

7X0W3U8TVA2A F31T13零毒后段实加7，施毒当步敌HP与玩家HP不变，结算后段25→18且玩家死亡。本盘前段已有8毒；现有observedPoison是标量，不能仅据后段一次饮用给所有目标/既有毒/重接组合统一赋7。未知持有价已由现存源码区分，仍不是已校准的早喝/留药价值。

MTQ0EUBJ3R6T F23T3原线29挡零损、替线19挡损8，多6即时伤；四试是一个相关局，全部有限推演败不等实盘必死。末T5两毒素已付能离手，不继续计留手10伤。没有独立A10后继可拟新的血价阈值。

跨幕22对均匹配原提案限定的floor(缺血×80%)：A9五对/A10十七对；其中cd9f原十局为16对，其余五局6对分列在act-transition-pairs.json。上限相同的观察支持不等于已跑原116局资源模型、路线/休息消费者或独立改线因果。

9Z9H2EXKLF3T的倍率挡/持牌伤/复活与毒结算已核：末T8首挡32仍死后复活20；T10挡37仍损15；T11敌112→32、毒39→37。净敌血差80不是未截断毛伤事件；不能把预测换线血价当实际收益。

以上没有新机制反证或对原经验的异议；保持原有限结论，不生成重复科学通知或代填任何角色ACK。宽父要求和未满足验证条件继续保留。

## 现有实现与生产边界

只读live快照`6fbbd82abd6d407dbaf93f82639b7f927efa54a0`，不是本批合入。material-validation.json逐项证明以下源码commit为该live真实祖先：

- 单层幽灵：`96f17377a331e50ea5b6a3fe8d2b605932ed1bd4`。
- 限定毒胜保血：`222445a9bb6bf56cb4f3ceea2cc8b20fba54128f`。
- 生存者单弃：`bf423c173d3be348a4ad714e1d26516df619ff41`。
- SL差值审计：`1698adc96ba434a46942321e0237b70657e625b2`。
- 未知持有价可见性：`c4670f4f416c7d93e192e889c5080e7e4e0e733f`。

这些只认证对应子功能，不给十个宽提案整项duplicate。source-audit.json比较16个相关叶：10字节相同，4仅历史署名，rollout.ts及rollout-live.ts有真实H0代码差异，入口源码明确限定Silent A2。保存base-to-live-audited-leaves.patch与每叶SHA；不将该局部源码检查说成全live树等价、原dirty运行树或A9/A10生产校准。

## 验证与记录

本批verify_material.py退出0：48项材料断言通过，124条原始引用按offset/bytes/SHA及显式身份独立读回全部通过。不是生产消费者、模型校准、tsc或vitest结果。analyze_evidence.py退出0；原stdout/stderr和验证JSON保留。

无生产源码修改，所以不做撤源码红/恢复绿，不跑tsc/vitest/沙箱整套，不生成代码提交、eval发布号或live merge；最终tests三项均null。未发布、不推送、不运行play，未改其他角色知识或对局行为。回退不适用。

探索中几条rg/sed命令因猜测不存在的旧路径返回2；后续用rg --files定位真实路径。一次账本输出过大被工具截断，已从保存的ledger-before.json改为限定局号与有限字段重读；没有据截断输出作结论。这些不是生产测试失败，未覆盖原工具历史。

ledger-updates.jsonl共46条，只链接既有本角色条目与本proposal/report，by=learner:strategy-proposal；不写新claim/evidence、状态、版本或shipped。根账本只经CLI update执行，实际退出与物理前缀/逐行核见ledger-cli及ledger-write-audit.json；不将准备输入冒已追加成功。既有提案ID直接用于code_proposals，不重复add或修改队列原文。

运维交接：[proposal.md](proposal.md)、[result.json](result.json)、[material-validation.json](material-validation.json)。十项waiting理由逐项在proposal与JSON中，待具体缺失输入/新局补齐重派；本批报告不关闭父要求、不冒称经验已入live或大脑已采用。完成后保留原日志/账本/产物，由原调度器验收回收，不删除自身工作树。

## 最终账本读回与初稿审计修正

2026-10-17T12:57:14+08:00：根CLI实际仅执行一次，退出0，46条原行已逐offset/bytes/SHA读回；22602805字节旧前缀SHA不变。独立只读审计按ledger.apply重建预期折叠，与保存的after完整相同；claim/evidence/首证/进阶/prior/status/version/effect/shipped_at全部不变，旧history/notes/where前缀保留。

link_ledger.py附加审计曾退出1：错误地把正常追加history/notes也放入不可变字段；该失败、ledger-write-audit.json和日志原样保留，未重跑CLI。audit_ledger_readback.py仅只读，退出0，修正回执见ledger-readback-audit.json；不是账本写失败、并行冲突或生产源码错误。

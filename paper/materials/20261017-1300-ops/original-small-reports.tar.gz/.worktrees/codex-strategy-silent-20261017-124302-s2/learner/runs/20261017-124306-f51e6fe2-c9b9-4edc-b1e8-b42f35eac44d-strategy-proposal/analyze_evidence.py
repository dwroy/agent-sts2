import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def ref(item):
    return {key: item[key] for key in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def powers(body):
    return {p.get('power_id'): p.get('amount') for p in body.get('powers', [])}


def compact(item):
    row = item['row']
    state = row.get('state', row)
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'ref': ref(item), 'ts': row.get('ts'), 'screen': state.get('screen'),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'in_combat': state.get('in_combat'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'), 'powers': powers(player),
        'relics': [r.get('relic_id') for r in run.get('relics', [])],
        'potions': [{k: p.get(k) for k in ('index', 'potion_id', 'occupied')} for p in run.get('potions', [])],
        'hand': [{**{k: c.get(k) for k in ('index', 'card_id', 'name', 'upgraded', 'energy_cost', 'playable', 'resolved_rules_text')},
                  'values': {v.get('name'): {'base': v.get('base_value'), 'current': v.get('current_value')} for v in c.get('dynamic_values', [])}}
                 for c in combat.get('hand', [])],
        'enemies': [{**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive')},
                     'powers': powers(e), 'intents': e.get('intents')} for e in combat.get('enemies', [])],
    }


def main():
    verified = json.loads((OUT / 'all-verified-runs.json').read_text())
    counts = {}
    state_rows = collections.defaultdict(list)
    frame_index = {}
    for stream in ('states', 'decisions', 'sl-attempts', 'run-config', 'run-plans', 'brain', 'runs', 'fight-plans'):
        tally = collections.Counter()
        with (OUT / 'evidence' / (stream + '.evidence.jsonl')).open() as handle:
            for line in handle:
                item = json.loads(line)
                ident = item['run_id']
                assert ident in verified
                tally[ident] += 1
                if stream == 'states':
                    run = item['row']['state'].get('run') or {}
                    assert run.get('character_id', '').lower() == 'silent'
                    frame = compact(item)
                    frame_index[item['line']] = frame
                    row = item['row']
                    row['_line'] = item['line']
                    state_rows[ident].append(row)
        counts[stream] = dict(tally)
    save('stream-counts.json', counts)
    save('compact-states.json', frame_index)
    spec = importlib.util.spec_from_file_location('resource_chain', ROOT / 'learner/resource_chain.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    chains = {}
    transitions = []
    for ident, rows in state_rows.items():
        chains[ident] = module.resource_chain(rows, ident, 'silent')
        for before, after in zip(rows, rows[1:]):
            a, b = compact_from_row(before, frame_index), compact_from_row(after, frame_index)
            if a['floor'] in (17, 33) and b['floor'] == a['floor'] + 1 and a['max_hp'] == b['max_hp']:
                if isinstance(a['hp'], int) and isinstance(b['hp'], int):
                    transitions.append({'run': ident, 'ascension': verified[ident]['ascension'],
                        'before': a['ref'], 'after': b['ref'], 'from_hp': a['hp'], 'to_hp': b['hp'],
                        'max_hp': a['max_hp'], 'observed_gain': b['hp'] - a['hp'],
                        'formula_gain': (a['max_hp'] - a['hp']) * 4 // 5})
    save('resource-chains.json', chains)
    save('act-transition-pairs.json', transitions)
    selected = [286893, 286894, 286896, 286897, 286898, 286899, 286978, 286982, 286986, 286987,
                288388, 288389, 288404, 288405, 288469, 288470, 288471, 288472,
                *range(288806, 288813), *range(288899, 288906), *range(288910, 288916)]
    save('key-frames.json', {n: frame_index[n] for n in selected if n in frame_index})
    print(json.dumps({'counts': counts, 'frames': len(frame_index), 'transition_pairs': len(transitions),
        'transition_matches': sum(t['observed_gain'] == t['formula_gain'] for t in transitions),
        'combat_windows': sum(len(c['combats']) for c in chains.values())}, ensure_ascii=False))
    for n in selected:
        if n not in frame_index:
            print('MISSING', n)
            continue
        f = frame_index[n]
        print(json.dumps({'line': n, 'run': f['ref']['run_id'], 'floor': f['floor'], 'turn': f['turn'],
            'hp': f['hp'], 'block': f['block'], 'energy': f['energy'], 'powers': f['powers'],
            'hand': [c['card_id'] for c in f['hand']],
            'enemies': [{'id': e['enemy_id'], 'hp': e['current_hp'], 'block': e['block'], 'powers': e['powers']} for e in f['enemies']]}, ensure_ascii=False))


def compact_from_row(row, index):
    return index[row['_line']]


if __name__ == '__main__':
    main()

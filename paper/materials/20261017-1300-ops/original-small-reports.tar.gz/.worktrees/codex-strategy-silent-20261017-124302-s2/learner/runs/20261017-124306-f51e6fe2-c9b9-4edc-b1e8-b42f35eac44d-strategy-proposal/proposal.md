# 本批十项策略提案复核

记录时间：2026-10-17T12:54:43+08:00

批次：20261017-124302-s2-strategy-proposal；角色silent；基线`ed6d77cea7b5c7a4980888e9f5877b6e00be3d7e`。
只处理dispatch.json里的十个ID。非专题、非implementation_request，不改调度绑定。所有旧Markdown均按保存的SHA核对并复制为*.original.md，既有id不重建。
方法：只用原提案明确引用的15个静默局（A9三局、A10十二局），十个派发锚点另保留。SL是相关重打；不跨进阶拟合参数。本批无新参数训练或模型收益检验；未来本角色独立完局才可作时间留出。本批不读取其他角色私有知识。
共同源码与回退边界：未改任何生产源码/经验/生成数据；铁甲与其他未观察进阶无本批行为变化。若以后实现，应每项独立提交、固定原输入做撤源红/恢复绿、跑沙箱入口、锁内合live并双通知；仅逆向该项真实实现，保留并行知识和历史。本批无可回退的行为补丁。
## 1. silent-proposal-03754e1265894000

原题：牌挡敏捷/脆弱/柔嫩逐张核；折扇被动挡、触发时点与持有能力分源

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-024302-experience-update/proposal-mechanisms.md`；SHA256：`518c139723decc4238c7ea5641e671c8738ec240118ff5140ca503612295599f`。

账本：silent-0006、silent-0011、silent-0013、silent-0080、silent-0088、silent-0101、silent-0232、silent-0253。

证据局/层/回合：RC61MFQM63Y6 A10 F23 T3/T4，states 285222—285230；F17/F29/F33范围仍按原提案保留。

本批核实与已有实现：预判后敏捷1，速度药后6；斗篷实加12挡，后续防御9挡，第三攻击零直伤仍加4挡；下一轮临时属性消失。原帧支持这些局部结算。

反例与未知：本次没有隔离柔嫩/脆弱/翻倍/首刀的所有联合条件，也没有移去组件后的受控整战；原提案六次SL属于同一相关局。

预期行为/旧新边界：继续按逐牌和实际已建立能力核验；不把知识文本或某个现存公式当八组件已全部兑现。

验证方法：冻结285222起的原手牌、药槽、柔嫩及攻击计数，逐步重放到285230；还须分别补F17/F29/F33的生产消费者输出及未见组合拒绝边界。

处置waiting：局部敏捷/柔嫩/折扇帧已复核；八组件的联合生产消费者校准及首刀/脆弱/倍率边界仍未完成，不能整包duplicate或扩展未见组合。

## 2. silent-proposal-ab055ef7dfbb44e5

原题：验证夜魇收益的存活兑现条件，并只建模本局已观察的幽灵一层无实体；延后饮用整场效果不足，保留旧时点与药价规则。

来源任务：postmortem；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-031301-postmortem/proposal-survival-and-ghost.md`；SHA256：`c5490a44836c3900e1d03b59370dea8c076a8b5435236f7a5e575e4c0b516b17`。

账本：silent-0140、silent-0069、silent-0005、silent-0206。

证据局/层/回合：XTSV1U9JD34T A10 F49 T1/T3/T4，states 286897—286899、286978/286982/286986/286987；decisions 280550、280631、280635—280639。

本批核实与已有实现：幽灵0→1层、16挡保23血、下轮留10挡；末次T3实损22到1血，T4建立NIGHTMARE_POWER3仍当轮归零。单层幽灵已有live源码96f17377a331e50ea5b6a3fe8d2b605932ed1bd4。

反例与未知：T1用药确实零损；未到下一轮不能据此认定复制牌在存活后仍不可兑现，也不能认定延后喝药有整战优势。

预期行为/旧新边界：保留已实现的单层幽灵比较；复制收益须有合法复制对象和存活后继，不增加晚喝或禁夜魇规则。

验证方法：单层效果与死亡前复制标记分开核；补同抽序的合法复制/存活后继及饮药时点的完整结果，再验证评价器。

处置waiting：单层幽灵已存在真实live祖先实现；夜魇合法复制后的存活兑现与延后饮药受控后继仍缺，不能用单层子项关闭整个存活/时点提案。

## 3. silent-proposal-0129c465c6f5bd79

原题：强制弃牌后候选重核、毒胜保血候选及夜魇/接管首轮兑现边界

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-replay.md`；SHA256：`bf425049a5868e3bec28ff845f0dcc2f5560594b3b85b4380a378ab2295bdcdc`。

账本：silent-0009、silent-0021、silent-0024、silent-0057、silent-0079、silent-0090、silent-0140、silent-0164、silent-0205、silent-0268、silent-0271。

证据局/层/回合：BTSRF7JL1W1Y A10 F31 T2，states 286158—286162；XTSV1U9JD34T A10 F48 T8/F49 T4，286893/286894/286896/286986/286987。

本批核实与已有实现：生存者前仅剩生存者/突然一拳，出牌后两牌离手、末挡13；X首王32→23并以23进入F49。单弃bf423c173d3be348a4ad714e1d26516df619ff41及限定毒胜保血222445a9bb6bf56cb4f3ceea2cc8b20fba54128f均为真实live祖先。

反例与未知：原日志不能把重规划前的所有候选续步都认证为实际执行；耳环接管内部动作缺失，夜魇后继未到，子修复不覆盖这三项联合要求。

预期行为/旧新边界：保持单弃及毒胜保血子修复；不预支接管动作或未生存到的复制收益。

验证方法：分别回放强制弃牌、抽牌重问、接管状态边界与毒终局资源；每条完整候选须用decision/fingerprint/attempt及真实动作链认证。

处置waiting：单弃与限定毒胜保血已有实际live源码；接管内部动作、夜魇存活后继及跨抽弃牌完整候选执行归属未齐，整项继续waiting。

## 4. silent-proposal-abe9d5d0be109a9f

原题：赢战血价、真实回复与存档恢复接续，连王剩血按实到资源

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-resources.md`；SHA256：`21263e5782fa17b030141cf5d79a9968115beeb1a99dc66f6309cbac9b51957b`。

账本：silent-0019、silent-0020。

证据局/层/回合：BTSRF7JL1W1Y A10 F30/F31，states 286112/286141/286147；XTSV1U9JD34T A10 F48 T8/F49 T1，286842/286894/286896。

本批核实与已有实现：B F30实到70、赢后42、F31入42；X F48实到97、赢后23、F49仍23。resource-chains按每次重打分段，缺失出口保留unknown。

反例与未知：净血差混有回血/自损，不能当敌人毛伤；未到的营火或未走路线不是已可用资源，没有同条件改线/留药/锻造胜负对照。

预期行为/旧新边界：资源接续按实到血量/药栏，SL恢复与新获得分账；不添加安全血线或路线机会成本参数。

验证方法：逐源对齐用药、恢复、SL与出入战帧；把这些输入交路线/休息消费者，并以独立本角色时间留出检验，不以端点代替消费者校准。

处置waiting：资源端点与SL分段可追溯；仍缺逐来源路线/休息消费者校准及同条件改线、留药、锻造后继和独立留出，不拟合安全血线或药价。

## 5. silent-proposal-f16527e59b5cc1e0

原题：敏捷/脆弱/覆甲分源、毒与临时减力时点及留挡上限按实帧核

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-033315-experience-update/proposal-mechanisms.md`；SHA256：`a71d6c87441d33115c5a8f4d3e0103673fd07798805978646f3a3961fb749079`。

账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0016、silent-0027、silent-0046、silent-0069、silent-0095、silent-0128、silent-0196、silent-0241。

证据局/层/回合：BTSRF7JL1W1Y A10 F31 T2，286158—286162；XTSV1U9JD34T A10 F49 T1/T3/T4，286897—286899、286978/286982/286986/286987。

本批核实与已有实现：B镣铐后石虫力量−9，生存者后13挡另有覆甲3；X幽灵、留挡和临时降力均有局部帧。步法建立后已有旧挡不自动补量，末T4有3敏与脆弱时防御6。

反例与未知：覆甲/临时属性/留挡/敌成长的多源效果没有在本批做共同输入生产回放；旧挡、下轮留挡与本轮牌挡不能相加为新能力的直接收益。

预期行为/旧新边界：仅保留已观察的实际来源与时点；不把留挡上限当每轮保底，不按未验证成长或毒触发新增规则。

验证方法：在固定原手牌上分解牌挡、覆甲、临时减力撤回、毒触发与下一轮留挡，要求共同消费者输出逐步对齐。

处置waiting：局部覆甲、药层与临时减力已核；毒触发/属性撤回/留挡/敌成长的逐源联合消费者回放仍缺，局部模型不能认证整包实现。

## 6. silent-proposal-7a8e9ccb7e646538

原题：毒/倍率挡/持牌伤及荆棘按实结算，SL换线预测与整轮实差分账

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-combat.md`；SHA256：`e365da8858d06c845b8f83b662fad011721eeab59fd4e0dce4c46aa3925b640f`。

账本：silent-0005、silent-0006、silent-0011、silent-0021、silent-0024、silent-0027、silent-0034、silent-0077、silent-0079、silent-0123、silent-0129、silent-0180、silent-0221。

证据局/层/回合：9Z9H2EXKLF3T A10 F48末试T8/T10/T11，states 287989—287991、288000/288003—288008；三次SL分段见resource-chains。

本批核实与已有实现：首挡32仍归零后复活20；末T10挡18→27→37仍损15；末T11敌112→32、毒39→37。敌血净降80与39+38毒77的差不能单靠端点当完整逐击事件账。

反例与未知：两次致死截断、复活中间状态与换线后抽牌/熔炉时点改变；预测“多损7换16伤”不是完整实盘收益。

预期行为/旧新边界：继续分列预测/实线、持牌伤/毒/荆棘与复活，不由有限全败样本新增SL血价或持有价。

验证方法：完整候选逐步执行归属、逐击未截断毛伤及同条件完整后继，固定倍率首张状态；缺帧仍unknown。

处置waiting：倍率挡、复活及毒结算局部帧可核；未截断逐击毛伤、完整候选执行归属和同条件整战后继仍缺，不能校准联合模型或SL血价。

## 7. silent-proposal-cd9f76184de6e29a

原题：跨幕缺血80%回复与营火/胜战消耗/SL资源接续按实到节点分账

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-044250-experience-update/proposal-resources.md`；SHA256：`54f562100db0a2dbc72c07a5b1411e42838e3370221a23ea4b769795196c66aa`。

账本：silent-0019、silent-0020、silent-0243。

证据局/层/回合：原提案十局：HMVJKM56S4Q8/F4QKG4J1AJJZ/G403VCZ3BH1B A9；25226ZFLNR1J/JLN5SK17W4FQ/JMH5C51RLN4E/9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0/9Z9H2EXKLF3T A10；F17→18或F33→34共16对。9Z另核F35/38/39/45/48资源。

本批核实与已有实现：原十局16对跨幕转换全部匹配floor(缺血×80%)；本批其他五局再有6对，总22对（A9为5对，A10为17对）。9Z实战66→30、30→19、19→11，后续31→7，F48实到27。

反例与未知：22对不是22个独立对局，其他五局不冒原十局输入；本批未重做原116局资源模型，跨幕限定公式不等于路线/休息/SL整包通过。

预期行为/旧新边界：保留A9/A10同上限已观察的回复边界；营火、精灵复活、SL药栏恢复分别记，不外推更低进阶或未知交互。

验证方法：逐对原字节校验已做；还需原116局完整冻结输入、路线/休息生产消费者及独立路线后继的校准。

处置waiting：原十局16对及本批其他五局6对仅支持限定跨幕公式；原116局完整资源输入、路线/休息消费者校准和独立路线收益仍未交齐。

## 8. silent-proposal-292f6731bdb9b669

原题：核对静默A10头骨组合毒药水实加7毒与现有窄范围上下文，未知持有价不当已校准零值，不拟合早喝规则

来源任务：postmortem；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-044302-postmortem/proposal-poison-potion.md`；SHA256：`2f943d1aee2e7ed6d1ddfa07b469a4488d27525bad4714cec58f6a94917a8c63`。

账本：silent-0087、silent-0020。

证据局/层/回合：7X0W3U8TVA2A A10 F31 T13，states 288470—288472、decision 282021；F31早段decision 281953。

本批核实与已有实现：后段零毒→7，当步敌25血/玩家1血均不变，结算后段18且玩家0；同盘前段已有8毒。未知持有价与计费0的区别已有源码c4670f4f416c7d93e192e889c5080e7e4e0e733f。

反例与未知：只观察后段零毒一次，无其他目标/既有毒/重接的同条件饮药对照；7是组合总增量，不能再额外叠头骨1，也不能据死亡推出早喝无效或必优。

预期行为/旧新边界：保留独立饮药选项及未知药价；不把标量observedPoison上下文统一扩为所有目标7毒。

验证方法：需把具体目标、已有毒、重接与原遗物/能力组合限定进共同推演，完整候选要保留未知目标分支；分别验证实际18血与不重复加头骨。

处置waiting：实加7仅证后段零毒单次；现有observedPoison是对候选目标共用的标量，本盘前段另有8毒，缺其他目标/叠毒/重接校准，不能统一赋7或拟早喝/持有价。

## 9. silent-proposal-0802f69b28d25079

原题：静默A10同盘SL少一防御以8血换6即时伤；固定核对速度药/毒素/资源链，验证饱和探索血价并保留缺反事实限制

来源任务：postmortem；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-sl.md`；SHA256：`79e1696de63d19810eb442ee3afa83dd5795f1693f4c9f4a48433fef014e3596`。

账本：silent-0079、silent-0019、silent-0044、silent-0080、silent-0253、silent-0011、silent-0214、silent-0189、silent-0046、silent-0222、silent-0243、silent-0262。

证据局/层/回合：MTQ0EUBJ3R6T A10 F23四试T3/T5，decision 282434；states 288806—288812、288899—288905、288910—288915；F19/F20资源段。

本批核实与已有实现：首试原线29挡/零损；第四试19挡/损8，多6即时伤；次轮速度层撤回。末T5两毒素逐张付能离手，不能继续计10持牌伤。SL差值审计1698adc96ba434a46942321e0237b70657e625b2已在live祖先。

反例与未知：原线也未见胜利，四试是一个相关局；改出牌影响后续抽牌。预测24/24全败不是实盘必死证明，敌残29对37也不是独立胜率比较。

预期行为/旧新边界：保留现有探索排序与药价，模型差值与实血分账；不新增8点HP阈值或权重。

验证方法：锁原题、药水、抽弃序，先还原当轮0/8损与毒素离手，再用独立A10留出和受控完整后继评估探索排序。

处置waiting：多损8/多伤6及临时药层已核、差值审计已有live源码；独立A10留出与固定抽弃/药时点的完整后继不足，不能拟饱和探索HP门槛或药价。

## 10. silent-proposal-763a4b9d9f17b815

原题：逐牌敏捷、临时减力、持牌伤和已建立能力的时间边界

来源任务：experience-update；实现任务：strategy-proposal/20261017-124302-s2-strategy-proposal。原文：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-mechanisms.md`；SHA256：`989dcea2a0dd5cad05d276157131dec57fdb9d17b2bdab66cbd25f32e0e9ad39`。

账本：silent-0005、silent-0006、silent-0011、silent-0013、silent-0044、silent-0046、silent-0053、silent-0080、silent-0087、silent-0189、silent-0214、silent-0222、silent-0235、silent-0253。

证据局/层/回合：7X0W3U8TVA2A A10 F30 T3/F31 T1/T2/T13，states 288388/288389/288404/288405/288470—288472；MTQ0EUBJ3R6T A10 F20 T3/F23 T3/T5，288806—288812、288899—288915。

本批核实与已有实现：已核蛇咬/头骨施毒局部帧、速度+5后由实际牌兑现、次轮撤回，及两毒素主动离手；已有能力不能替代当步格挡。十四组件原文和经验id完整保留。

反例与未知：逐帧观察不是十四组件联合生产消费者验证；毛伤事件、昏眩单牌、敌临时属性/能力后继与未知抽牌仍有未校准边界。

预期行为/旧新边界：保留逐牌、已建立能力与临时层边界；不外推基础药效、持有价或完整组合价值。

验证方法：逐项固定输入到共同生产消费者的回放、联合交互与未知分支拒绝；已实现组件按真实源码祖先登记，整包须满足全部范围。

处置waiting：十四项已有局部观察与若干源码组件；仍缺完整联合生产消费者校准、部分能力/昏眩/临时属性后继，不把经验入库当整包源码兑现。


import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROJECT = Path('/home/dw/Projects/agent-sts2')
ledger = PROJECT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('ledger', PROJECT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
updates = [json.loads(line) for line in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
assert len(updates) == len({u['id'] for u in updates}) == 46
assert all(set(u) == {'id', 'by', 'where', 'note'} and set(u['where']) == {'proposal'} for u in updates)
fold = module.fold(module.read_rows(str(ledger)))
before = {u['id']: fold[u['id']] for u in updates}
assert all(e['character'] == 'silent' for e in before.values())
(OUT / 'ledger-immediate-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
with ledger.open('rb') as handle:
    prefix = handle.read()
prefix_sha = hashlib.sha256(prefix).hexdigest()
stamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
with (OUT / 'ledger-updates.jsonl').open() as source, (OUT / 'ledger-cli.stdout.txt').open('w') as stdout, (OUT / 'ledger-cli.stderr.txt').open('w') as stderr:
    run = subprocess.run(['python3', '-B', str(PROJECT / 'learner/ledger.py'), 'update'], stdin=source, stdout=stdout, stderr=stderr)
(OUT / 'ledger-cli.exit.txt').write_text(str(run.returncode) + '\n')
assert run.returncode == 0
with ledger.open('rb') as handle:
    now_prefix = handle.read(len(prefix))
    delta = handle.read()
assert hashlib.sha256(now_prefix).hexdigest() == prefix_sha
offset = len(prefix)
own = []
for raw in delta.splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('where', {}).get('proposal') == [str(OUT / 'proposal.md'), str(OUT / 'report.md')] and row.get('by') == 'learner:strategy-proposal':
        expected = next(u for u in updates if u['id'] == row['id'])
        assert set(row) == {'op', 'ts', *expected} and row['op'] == 'update'
        assert all(row[k] == v for k, v in expected.items())
        own.append({'id': row['id'], 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(own) == len(updates)
after_fold = module.fold(module.read_rows(str(ledger)))
after = {u['id']: after_fold[u['id']] for u in updates}
(OUT / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
protected = lambda e: {k: v for k, v in e.items() if k not in ('op', 'ts', 'by', 'note', 'where')}
changes = [i for i in before if protected(before[i]) != protected(after[i])]
readback = all(str(OUT / 'proposal.md') in after[i]['where']['proposal'] and str(OUT / 'report.md') in after[i]['where']['proposal'] for i in before)
assert readback
audit = {'recorded_at': stamp, 'cli_exit': run.returncode, 'prefix_size': len(prefix), 'prefix_sha256': prefix_sha,
         'prefix_unchanged': True, 'own_row_count': len(own), 'own_rows': own,
         'all_own_rows_only_where_note': True, 'all_links_read_back': readback, 'protected_field_changes': changes}
(OUT / 'ledger-write-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in audit.items() if k != 'own_rows'}, ensure_ascii=False))
assert not changes, 'Concurrent protected-field changes require an explicit separate audit'

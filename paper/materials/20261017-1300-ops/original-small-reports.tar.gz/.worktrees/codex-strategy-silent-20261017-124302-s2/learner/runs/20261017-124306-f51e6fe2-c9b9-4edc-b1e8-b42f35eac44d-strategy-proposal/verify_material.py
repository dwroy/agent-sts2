import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
frames = json.loads((OUT / 'compact-states.json').read_text())
pairs = json.loads((OUT / 'act-transition-pairs.json').read_text())
cases = []


def check(name, actual, expected, lines):
    cases.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected,
                  'refs': [frames[str(n)]['ref'] for n in lines]})


def f(n):
    return frames[str(n)]


check('预判后柔嫩净敏捷', f(285223)['powers']['DEXTERITY_POWER'], 1, [285222, 285223])
check('速度药加五临时敏捷', f(285224)['powers']['DEXTERITY_POWER'] - f(285223)['powers']['DEXTERITY_POWER'], 5, [285223, 285224])
check('斗篷本步十二挡', f(285225)['block'] - f(285224)['block'], 12, [285224, 285225])
check('柔嫩后防御九挡', f(285227)['block'] - f(285226)['block'], 9, [285226, 285227])
check('零直伤第三攻击折扇四挡', [f(285229)['block'] - f(285228)['block'], f(285228)['enemies'][0]['current_hp'] - f(285229)['enemies'][0]['current_hp']], [4, 0], [285228, 285229])
check('下轮临时属性不保留', [f(285230)['powers'].get(k, 0) for k in ('DEXTERITY_POWER', 'STRENGTH_POWER', 'SPEED_POTION_POWER', 'ANTICIPATE_POWER')], [0, 0, 0, 0], [285229, 285230])
check('单弃后唯一后继已离手', [len(f(286161)['hand']), len(f(286162)['hand']), f(286162)['block']], [2, 0, 13], [286161, 286162])
check('幽灵层数0到1', [f(286897)['powers'].get('INTANGIBLE_POWER', 0), f(286898)['powers']['INTANGIBLE_POWER']], [0, 1], [286897, 286898])
check('幽灵次轮血量与留挡', [f(286899)['hp'], f(286899)['block']], [23, 10], [286897, 286898, 286899])
check('女王末次T3实损22', f(286978)['hp'] - f(286982)['hp'], 22, [286978, 286982])
check('夜魇建立标记仍死', [f(286986)['powers']['NIGHTMARE_POWER'], f(286986)['hp'], f(286987)['hp']], [3, 1, 0], [286986, 286987])
check('首王毒胜仍耗9血', f(286893)['hp'] - f(286894)['hp'], 9, [286893, 286894])
check('连王无恢复实到23血', [f(286894)['hp'], f(286896)['hp']], [23, 23], [286894, 286896])
check('毒药水后段0到7', [f(288470)['enemies'][2]['powers'].get('POISON_POWER', 0), f(288471)['enemies'][2]['powers']['POISON_POWER']], [0, 7], [288470, 288471])
check('毒药水当步不直接扣血', [f(288471)['enemies'][2]['current_hp'], f(288471)['hp']], [25, 1], [288470, 288471])
check('后段结算7仍败', [f(288472)['enemies'][2]['current_hp'], f(288472)['hp']], [18, 0], [288471, 288472])
check('后段已喝时前段另有8毒', f(288470)['enemies'][0]['powers']['POISON_POWER'], 8, [288470])
check('SL原线29挡零损', [f(288811)['block'], f(288806)['hp'] - f(288812)['hp']], [29, 0], [288806, 288811, 288812])
check('SL替线19挡损8', [f(288904)['block'], f(288899)['hp'] - f(288905)['hp']], [19, 8], [288899, 288904, 288905])
check('SL当轮实伤差6', sum(e['current_hp'] for e in f(288812)['enemies']) - sum(e['current_hp'] for e in f(288905)['enemies']), 6, [288806, 288899, 288812, 288905])
check('SL次轮临时药层撤回', f(288905)['powers'].get('SPEED_POTION_POWER', 0), 0, [288904, 288905])
check('末T5两毒素逐张主动离手', [sum(c['card_id'] == 'TOXIC' for c in f(n)['hand']) for n in (288910, 288911, 288912)], [2, 1, 0], [288910, 288911, 288912])
check('倍率首挡32但随后仍死并复活20', [f(287989)['block'], f(287990)['hp'], f(287991)['hp']], [32, 0, 20], [287989, 287990, 287991])
check('末T10挡37仍损15', [f(288004)['block'], f(288004)['hp'] - f(288005)['hp']], [37, 15], [288004, 288005])
check('末T11净敌血112到32', [f(288006)['enemies'][0]['current_hp'], f(288008)['enemies'][0]['current_hp']], [112, 32], [288006, 288008])
check('末T11仅两次毒递减', [f(288006)['enemies'][0]['powers']['POISON_POWER'], f(288008)['enemies'][0]['powers']['POISON_POWER']], [39, 37], [288006, 288008])
for pair in pairs:
    check('跨幕限定公式:' + pair['run'] + ':' + str(pair['after']['line']), pair['observed_gain'], pair['formula_gain'], [pair['before']['line'], pair['after']['line']])

refs = {('states', c['line']): c for case in cases for c in case['refs']}
for frame in json.loads((OUT / 'mechanism-window-frames.json').read_text()):
    refs['states', frame['ref']['line']] = frame['ref']
for line in (OUT / 'evidence/decisions.evidence.jsonl').open():
    e = json.loads(line)
    if e['line'] in (280547, 280550, 280631, 280635, 280636, 280637, 280638, 280639, 281953, 282021, 282434):
        refs['decisions', e['line']] = {k: e[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}
physical = []
for (_, _), r in sorted(refs.items()):
    with Path(r['source']).open('rb') as handle:
        handle.seek(r['offset'])
        raw = handle.read(r['bytes'])
    row = json.loads(raw)
    identities = [row.get('run_id'), row.get('run'), (row.get('state') or {}).get('run_id')]
    fingerprint = row.get('fingerprint')
    if isinstance(fingerprint, str):
        fingerprint = json.loads(fingerprint)
    if isinstance(fingerprint, dict):
        identities.append(fingerprint.get('run'))
    observed = {i for i in identities if isinstance(i, str) and i and i != 'run_unknown'}
    passed = len(raw) == r['bytes'] and hashlib.sha256(raw).hexdigest() == r['sha256'] and observed == {r['run_id']}
    physical.append({**r, 'passed': passed})

live = json.loads((OUT / 'source-audit.json').read_text())['live_snapshot']
anchors = []
for commit, scope in [('96f17377a331e50ea5b6a3fe8d2b605932ed1bd4', '单层幽灵'),
                      ('222445a9bb6bf56cb4f3ceea2cc8b20fba54128f', '限定毒胜保血'),
                      ('bf423c173d3be348a4ad714e1d26516df619ff41', '生存者单弃'),
                      ('1698adc96ba434a46942321e0237b70657e625b2', 'SL差值审计'),
                      ('c4670f4f416c7d93e192e889c5080e7e4e0e733f', '未知持有价可见性')]:
    ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live]).returncode == 0
    anchors.append({'commit': commit, 'scope': scope, 'live_ancestor': ancestor,
        'source_files': subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit, '--', 'agent/src'], text=True).splitlines()})

result = {'kind': '材料一致性核验；不是生产源码测试或完整消费者校准', 'cases': cases,
          'case_count': len(cases), 'failed_cases': [c['name'] for c in cases if not c['passed']],
          'physical_refs': physical, 'physical_count': len(physical),
          'physical_failures': sum(not x['passed'] for x in physical), 'live_snapshot': live, 'narrow_anchors': anchors}
(OUT / 'material-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('kind', 'case_count', 'failed_cases', 'physical_count', 'physical_failures', 'live_snapshot')}, ensure_ascii=False))
assert not result['failed_cases'] and not result['physical_failures']
assert all(a['live_ancestor'] and a['source_files'] for a in anchors)

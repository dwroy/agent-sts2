# 静默猎手策略提案批次报告

报告时间：2026-10-17T12:53:54+08:00。本批 `20261017-124302-strategy-proposal`。

结论：十项已领取提案全部 waiting；没有证据充分的新源码差额或参数改动。`base=HEAD=ed6d77cea7b5c7a4980888e9f5877b6e00be3d7e`，`fixes=[]`、`merged=null`，无新提交、live合入、版本、规则通知或shipped登记。

本批为普通队列复核，没有research_request或implementation_request。初始git status干净，按任务合main返回Already up to date。独立完成，无下级agent。

## 证据与处置

五局均由runs.jsonl核为Silent A10：NHA2KW0RB7VP F33、P74C04AEPL1F F23、G33HU22H2543 F48、RC61MFQM63Y6 F33、BTSRF7JL1W1Y F31，均失败，运行code均带dirty。仅使用这五局原帧、对应原提案及本角色账本；没有读取其他角色私有知识或重新宣称全历史统计。

十份原Markdown实际SHA与专用队列登记逐项相符，副本在original-proposals/。逐项旧/新行为、层/回合/账本、反例、预期验证及回退边界见 [proposal.md](proposal.md)，运维应保留该路径与 [proposal-results.json](proposal-results.json)。

| 派发提案 | 来源局 / 层回合 | 处置与缺数据 |
|---|---|---|
| `silent-proposal-9952ee8e8df9a0fe` | NHA2KW0RB7VP F33 T1；F24/27/32休息 | waiting：已核实NHA F33 T1同首手14/8挡、损1/7、净扣8/24；live已有当轮资源差额，仍缺同抽序、同预算整战对照和路线/留药受控后继，不能调整SL门槛或终局HP权重。 |
| `silent-proposal-47be799a87af03be` | P74C04AEPL1F F23末T3 | waiting：已核实P74 F23末T3弃精确切击、原零损后继失效并死亡；live已有计划取消提示与保留手牌快照，仍缺动态牌面、弃牌触发、目标和续步剩血的完整合法分支核证。 |
| `silent-proposal-3a5274da3c42672a` | P74C04AEPL1F F17 T1/2/8，F22 T1—6，F23 T1/3 | waiting：已核实P74 F17火焰扣1、毒扣2/23，F22召唤复活及53至9，F23逐敌伤害；缺主怪最后归零中间帧及这些来源与下一战的联合消费者验证，未定位新增可隔离源码差额。 |
| `silent-proposal-bc4b92d590f2c4ce` | G33HU22H2543 F48 T1/8；P74C04AEPL1F F23 T3 | waiting：投斧首牌身份修复e784dd9f043bf87c29109573f48975f9903280d3和弃牌提示均为live祖先；仍缺跨重规划的完整实线归属、余像累计收益及动态弃牌联合验证，局部覆盖不能整项duplicate。 |
| `silent-proposal-f52fbbab4dccc3b4` | G33HU22H2543 F31—33/47；P74C04AEPL1F F22—23 | waiting：已核实G33 F31赢后46、休至76、F33赢后17，P74 F22赢后9接F23；缺逐来源连续资源消费者账和同条件路线/休息/SL/保药的受控后继，不能拟合新HP价格或留药阈值。 |
| `silent-proposal-10f37c0edd3d24a6` | P74C04AEPL1F F17/23；G33HU22H2543 F32/47/48 | waiting：已核实普通触媒、临时减力、滑溜、牌挡/余像和实际休息的局部窗口；缺原dirty运行全树/知识/移动表完整输入与多组件联合回放及独立校准，未发现新的确定源码修正。 |
| `silent-proposal-3f82387e2e179703` | RC61MFQM63Y6 F33首/末T1及第三试T4 | waiting：RC F33同指纹T1两实打线损4/8、扣30/23已核；首末原题推演预算还分别为3轮2样本与5轮24样本，缺同预算整战、累计能力收益和受控后继，不能修改全败SL排序。 |
| `silent-proposal-aee21084c991abd3` | BTSRF7JL1W1Y F31 T1—4 | waiting：BTS F31抽弃前后实际换线、最终候选4样本3胜1死及醒虫力量/覆甲/末死均已核；缺逐样本轨迹与完整执行线的配对校准，单次死亡不能证明概率错误或调整权重。 |
| `silent-proposal-df37594e9b12debf` | RC61MFQM63Y6 F33第三试T4；原F17自损部分未做联合消费者验证 | waiting：普通生存者唯一后继取消修复bf423c173d3be348a4ad714e1d26516df619ff41为live祖先，RC F33 T4确实手空；跨选择整线归属、累计能力和呼唤自损的联合消费者仍未验收，不能整项duplicate。 |
| `silent-proposal-42e81c83b2e1e56b` | RC61MFQM63Y6 F24/27/32休息及F33 T1 | waiting：已核实RC F24/F27/F32三火各回21、F33实际52血入口；缺同条件路线/休息/后战对照及逐来源消费者验收，不能用本局回复账设新安全血线或终局HP价格。 |

各项既有账本ID见proposal.md；完整原投影在ledger-before.json。本次没有创建重复代码提案，最终code_proposals列的是十个已领取CLI ID。

## 核验的实际范围

共用入口抽取八流，manifest保存冻结source_size、逐行offset/bytes/SHA与计数。6,606条选中原行已全部按offset回读核对SHA、JSON和显式身份，见raw-readback-audit.json；37项材料断言全部通过，见material-checks.json与material-verification.log。这是日志材料核验，没有运行生产求解器、候选消费者、LLM、网络或游戏。

流计数：states 3,238、decisions 3,138、sl-attempts 31、run-config 5、run-plans 26、brain 163、runs 5、fight-plans 0。states/decisions/brain全源各2条无效行不推断归属；fight-plans零行只说明本截点未选中。未覆盖历史统计，不把SL重试当独立局。

直接读回：NHA双蟹首轮14/8挡、损1/7、净扣8/24；RC同指纹首轮16/12挡、损4/8、净扣30/23。RC首末题预算分别3轮2样本、5轮24样本，不等于受控整战。P74末T3弃精确后原零损后继未执行，1血16挡仍死且卵剩2；BTS抽弃后换为另一最终线，4样本3胜1死不排除实际死亡。两局资源/概率事实不能直接给出新的固定SL、药水或终局权重。

源码快照：base见上，比较live `6fbbd82abd6d407dbaf93f82639b7f927efa54a0` 的14叶；7叶字节相同、5叶仅Roy/Dai历史署名单词差异，2叶另有已发布Silent A2虚弱窄修。真实差量见base-vs-live-source.patch，SHA、最后源码提交及live祖先性见source-audit.json。没有把A2新范围当本批A10校准，没有以当前树重构历史dirty树。

已核实的局部祖先：生存者唯一后继取消 `bf423c173d3be348a4ad714e1d26516df619ff41`；投斧首牌身份 `e784dd9f043bf87c29109573f48975f9903280d3`。弃牌提示/快照、SL资源差额与候选audit源码也已存在；audit实际仍为pending_dispatch/actual_turn=null，快照明确不做完整分支求解。因此不据这些子项把任何宽提案登记implemented/duplicate。

## 记录和验证结果

只经根learner/ledger.py update给原32账本追加where/note追溯。没有新增support/repeat、没有新增游戏claim，也没有改旧claim/首证/prior/evidence/status/version/shipped；旧shipped不降级。本批无新提案需要设proposed，最终仍由调用方依据逐项waiting保留重派。CLI和原字节前缀/保护字段核验见ledger-cli.log、ledger-prefix-before.json、ledger-append-audit.json。

未改生产源码或知识，撤源码失败/恢复通过均不适用；tsc=null、vitest=null、cases=null。没有代码提交，未运行提交前gitleaks或生产整套；没有伪报绿色结果。最终HEAD及干净工作树见final-validation.json。未做live合入，无回退代码动作；原失败和全部材料保留，父要求没有因本批报告而关闭。

材料脚本初稿曾对combat=null调用get而退出1，记录preliminary-analysis-error.txt；已改为兼容空combat，后续37项核验退出0。此错误属于材料处理，不是产品缺陷或生产测试结果。没有新的机制异议，不重复发旧科学通知或代填ops/watcher/Roy确认。

本批没有修改经验库，也不声称大脑已经读取或自然采用。后续只有补齐各项指定的完整分支/逐来源消费者/受控整战与独立校准输入，才有依据实施或验收相应宽项。

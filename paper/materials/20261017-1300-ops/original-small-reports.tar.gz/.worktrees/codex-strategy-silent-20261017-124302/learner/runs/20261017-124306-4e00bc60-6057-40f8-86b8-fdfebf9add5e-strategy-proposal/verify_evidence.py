"""Verify frozen materials without the production solver, LLM, network, or game."""
import collections
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[1]))
from extract_evidence import run_identity


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
tables = {}
audit = []
for item in manifest:
    stream = item["stream"]
    path = OUT / "evidence" / f"{stream}.evidence.jsonl"
    digest = hashlib.sha256()
    counts = collections.Counter()
    entries = {}
    with Path(f"/home/dw/Projects/agent-sts2/logs/{stream}.jsonl").open("rb") as source:
        for encoded in path.open("rb"):
            digest.update(encoded)
            entry = json.loads(encoded)
            assert entry["source"] == str(Path(source.name))
            assert entry["offset"] + entry["bytes"] <= item["source_size"]
            source.seek(entry["offset"])
            raw = source.read(entry["bytes"])
            assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
            row = json.loads(raw)
            assert row == entry["row"]
            assert run_identity(row) == entry["run_id"]
            counts[entry["run_id"]] += 1
            assert entry["line"] not in entries
            entries[entry["line"]] = entry
    assert digest.hexdigest() == item["output_sha256"]
    assert all(counts[run] == n for run, n in item["counts"].items())
    tables[stream] = entries
    audit.append({"stream": stream, "checked": sum(counts.values()), "source_size": item["source_size"],
                  "output_sha256": digest.hexdigest(), "counts": dict(counts)})
save("raw-readback-audit.json", {"streams": audit, "total": sum(x["checked"] for x in audit)})

states = {n: e["row"]["state"] for n, e in tables["states"].items()}
decisions = {n: e["row"] for n, e in tables["decisions"].items()}
checks = []


def player(n):
    return states[n]["combat"]["player"]


def enemy(n, name):
    return next(e for e in states[n]["combat"]["enemies"] if e["enemy_id"] == name)


def power(value, key):
    return next((p["amount"] for p in value["powers"] if p["power_id"] == key), 0)


def hand(n):
    return [c["card_id"] for c in states[n]["combat"]["hand"]]


def hp(n):
    return states[n]["run"]["current_hp"]


def enemy_hp(n):
    return sum(e["current_hp"] for e in states[n]["combat"]["enemies"])


def check(label, actual, expected, state_lines=(), decision_lines=()):
    refs = [{k: tables[s][n][k] for k in ("source", "line", "offset", "bytes", "sha256", "run_id")}
            for s, ns in [("states", state_lines), ("decisions", decision_lines)] for n in ns]
    row = {"label": label, "actual": actual, "expected": expected, "passed": actual == expected, "references": refs}
    checks.append(row)
    save("material-checks.json", checks)
    assert row["passed"], label


check("NHA首/末首手同身份", [(c["card_id"], c["upgraded"]) for c in states[283391]["combat"]["hand"]],
      [(c["card_id"], c["upgraded"]) for c in states[283502]["combat"]["hand"]], [283391, 283502])
check("NHA首/末起血", [hp(283391), hp(283502)], [30, 30], [283391, 283502])
check("NHA首/末T1挡", [player(283396)["block"], player(283506)["block"]], [14, 8], [283396, 283506])
check("NHA首/末T1损血", [30-hp(283397), 30-hp(283507)], [1, 7], [283397, 283507])
check("NHA首/末T1净扣敌血", [enemy_hp(283391)-enemy_hp(283397), enemy_hp(283502)-enemy_hp(283507)], [8, 24], [283391, 283397, 283502, 283507])
check("RC两T1指纹相同", decisions[279021]["fingerprint"] == decisions[279197]["fingerprint"], True, decision_lines=[279021, 279197])
check("RC原/替T1挡", [player(285320)["block"], player(285496)["block"]], [16, 12], [285320, 285496])
check("RC原/替T1损血", [52-hp(285321), 52-hp(285497)], [4, 8], [285321, 285497])
check("RC原/替T1净扣敌血", [enemy_hp(285315)-enemy_hp(285321), enemy_hp(285491)-enemy_hp(285497)], [30, 23], [285315, 285321, 285491, 285497])
check("RC原/替触媒层", [power(player(285321), "ACCELERANT_POWER"), power(player(285497), "ACCELERANT_POWER")], [0, 1], [285321, 285497])
check("RC首末题推演预算不同", [(decisions[n]["rollout"]["horizon"], decisions[n]["rollout"]["samples"]) for n in [279021, 279197]], [(3, 2), (5, 24)], decision_lines=[279021, 279197])
check("RC强制单弃清空唯一后继", [hand(285414), hand(285415)], [["SURVIVOR", "STRIKE_SILENT"], []], [285414, 285415])
check("RC后继未转向时57来袭", [hp(285415), player(285415)["block"], enemy(285415,"ROCKET")["intents"][0]["total_damage"]], [45, 7, 57], [285415])
check("P74原整线报零损", "hp -0" in decisions[278542]["rationale"], True, decision_lines=[278542])
check("P74实际弃精确切击", ["PRECISE_CUT" in hand(284817), "PRECISE_CUT" in hand(284818)], [True, False], [284817, 284818])
check("P74弃后重算报负7", "(-7)" in decisions[278544]["rationale"], True, decision_lines=[278544])
check("P74末轮血挡", [hp(284820), player(284820)["block"]], [1, 16], [284820])
check("P74石眩晕但卵仍存活/玩家死", [enemy(284821,"BOWLBUG_ROCK")["move_id"], enemy(284821,"BOWLBUG_EGG")["current_hp"], hp(284821)], ["STUNNED", 2, 0], [284821])
check("P74首/末T1实20挡仍损4", [player(284769)["block"], player(284809)["block"], 9-hp(284771), 9-hp(284811)], [20,20,4,4], [284769,284809,284771,284811])
check("P74主怪召唤/复活", [enemy(284730,"THE_OBSCURA")["current_hp"], enemy(284748,"PARAFRIGHT")["current_hp"], enemy(284749,"PARAFRIGHT")["current_hp"]], [129,0,21], [284730,284748,284749])
check("P74赢战损44接下战9血", [hp(284730)-hp(284761), hp(284766)], [44,9], [284730,284761,284766])
check("P74T2/T4各损20/24", [53-hp(284744),33-hp(284754)], [20,24], [284744,284754])
check("P74滑溜火焰净扣1", [enemy(284630,"VANTOM")["current_hp"]-enemy(284631,"VANTOM")["current_hp"], power(enemy(284630,"VANTOM"),"SLIPPERY_POWER")-power(enemy(284631,"VANTOM"),"SLIPPERY_POWER")], [1,1], [284630,284631])
check("P74双毒结算滑溜下仅扣2", [enemy(284635,"VANTOM")["current_hp"]-enemy(284636,"VANTOM")["current_hp"],power(enemy(284636,"VANTOM"),"SLIPPERY_POWER"),power(enemy(284636,"VANTOM"),"POISON_POWER")], [2,4,10], [284635,284636])
check("P74无滑溜12毒结算23", [power(enemy(284658,"VANTOM"),"POISON_POWER"),enemy(284658,"VANTOM")["current_hp"]-enemy(284659,"VANTOM")["current_hp"]], [12,23], [284658,284659])
check("G余像两层与两步各5/2挡", [power(player(284405),"AFTERIMAGE_POWER"),player(284406)["block"]-player(284405)["block"],player(284407)["block"]-player(284406)["block"]], [2,5,2], [284405,284406,284407])
check("G末轮仍死/双敌存活", [hp(284408),[e["current_hp"] for e in states[284408]["combat"]["enemies"]]], [0,[29,148]], [284408])
check("G千足虫赢后46/下一boss76至17", [hp(283962),hp(283968),hp(284007)], [46,76,17], [283962,283968,284007])
check("G休息增加实际血/上限", [hp(283965)-hp(283964),states[283965]["run"]["max_hp"]-states[283964]["run"]["max_hp"],hp(284159)-hp(284158)], [30,5,32], [283964,283965,284158,284159])
check("RC三火各21至实际入口52", [hp(285250)-hp(285249),hp(285261)-hp(285260),hp(285312)-hp(285311),hp(285315)], [21,21,21,52], [285249,285250,285260,285261,285311,285312,285315])
check("NHA三火各24", [hp(283285)-hp(283284),hp(283323)-hp(283322),hp(283388)-hp(283387)], [24,24,24], [283284,283285,283322,283323,283387,283388])
check("BTS睡层实减至眩晕", [power(enemy(n,"SLUMBERING_BEETLE"),"SLUMBER_POWER") for n in [286148,286149,286150,286152]], [3,2,1,0], [286148,286149,286150,286152])
check("BTS醒后T3/T4力量2/4", [power(enemy(n,"SLUMBERING_BEETLE"),"STRENGTH_POWER") for n in [286163,286170]], [2,4], [286163,286170])
candidate=json.loads(decisions[279854]["questions"]["plan"]["criteria"]["plan2"])
check("BTS最终线四样本三胜一死", "in 3/4" in candidate["rollout"] and "dead within 5 turns in 1/4" in candidate["rollout"], True, decision_lines=[279854])
check("BTS原/后选整线不同", decisions[279852]["rationale"] != decisions[279854]["rationale"], True, decision_lines=[279852,279854])
check("BTS末T4覆甲/牌挡/来袭", [power(player(286173),"PLATING_POWER"),player(286173)["block"],enemy(286173,"SLUMBERING_BEETLE")["intents"][0]["total_damage"]], [1,5,22], [286173])
check("BTS末T4毒后敌13玩家死", [enemy(286174,"SLUMBERING_BEETLE")["current_hp"],hp(286174)], [13,0], [286174])
print(json.dumps({"raw_rows":sum(x["checked"] for x in audit),"material_checks":len(checks),"all_passed":all(c["passed"] for c in checks)},ensure_ascii=False))

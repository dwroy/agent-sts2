"""Preserve per-proposal outcomes without claiming implementation or publication."""
import datetime
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
proposals = json.loads((out / "proposals.json").read_text())
dispatch = json.loads((out / "dispatch.json").read_text())
source = json.loads((out / "source-audit.json").read_text())
summary = json.loads((out / "consumer-summary.json").read_text())
base = source["base"]
details = [
    ("751 F17 T2/T7/T13，decisions 272434↔272575、272531↔272652、272483↔272820",
     "原帧及消费者均复核三组同指纹：净损13→18/13→23/8→2，敌净扣9→18/12→18/17→11。已有SL候选及持牌预测诊断，缺抽弃重问后完整候选执行归属、逐来源实际结算与受控整战后继；不能拟合5/10血探索门槛。",
     "先保持更差未试线的现准入；后续比较同种子完整后继及独立后期局，分别核持牌失血、已结算输出、能力建立与B2误差。"),
    ("751 F13 T3 decisions 272361/272362；F17 T7/T13/T17，states 278500—278505、278887/278888",
     "F13用药plan2与真正整战无药plan5预测均损8；plan3后续7/8样本仍用药。已有未知持有价和未决弃牌诊断，缺实际无药完整分支、留药后战及逐来源兑现；不能把缺表成本0当持有价0或改弃牌排序。",
     "保留hold_hp=null、缺表原因、合法药水及原保守损血边界；新局核同题无药/留药实际后继，未决弃牌须按选择后的真实手牌重算。"),
    ("同366288801d9150d9；来源任务为experience-update，六次SL仍属751同一局",
     "与366288801d9150d9复用751同局三组端点，不能新增独立分母。现有候选预测和单动作回执未认证整条候选，缺真实成本归属、受控整战后继和独立验证；保留waiting。",
     "沿原经验与0079/0176链接补完整执行链；与复盘来源同题去重，不把两份Markdown或六次SL当独立验证。"),
    ("751 F13 T3、F17 T3/T5/T7/T13/T17；账本0005/0006/0007/0046/0129/0176",
     "751敏捷、毒、荆棘和持牌失血的局部观测与原提案相符。现有单项事实未完成联合逐来源实际校准，缺完整候选归属、无药及留药跨战对照；不能以单项诊断祖先关闭整项。",
     "按原候选的攻击、毒、反伤、能力建立及已确认弃牌分别核源；不把净HP差统归单牌或未执行后续。"),
    ("KV F33第4/5试T5 decisions 273400/273450；第5试另有273451重问",
     "同指纹原帧净扣36→29、当轮净损均0。第5试后续重问保留在消费者输入；两轮严格消费者均turn_end_unverified。缺敌回血/毛伤逐来源完整归属、受控整战及路线休息替代后继，不能定探索或资源门槛。",
     "保留原探索规则；补T5结束后诅咒选牌及下一轮的已知尝试身份，毛伤/回血与净扣分列，再核完整后继而非只看活到T10。"),
    ("YQL F17 T10 states 280160/280161；L9 F17 T14 sl-attempts 681；PU F17 T17 sl-attempts 717",
     "巨兽阶段及残壳毒药事实已有live诊断；YQL毒2→8而血26/挡13/来袭41不变。enemyHpLeft/anchorRank仍用原占位血作平局排序。缺新旧排序、提前喝/不喝/留药的受控完整后继，PU胜线未隔离因素；不关闭宽提案。",
     "保留本体0与仍待自爆的事实，保留原排序；固定比较原/新参考路径、最终血挡与阶段，不由占位血差或早清体推导获胜。"),
    ("与e18d3f18e6cac2a0共享L9、PU、YQL三局；来源任务为experience-update",
     "三局阶段和药水端点支持分账，但已有阶段提示不是阶段估值或排序收益的验证。原占位血平局输入仍保留，缺新旧参考路径和用药时点完整受控比较，不能以PU过爆余2将整项标duplicate。",
     "沿原0017/0019/0020/0250链接等待阶段估值和完整后继；不重复发布已有阶段/药水提示，也不预设自爆缺口权重。"),
    ("KEN F3T2/F4T1/F5T2/F11T1/T2/F15T1，decisions 274131/274156/274185/274235/274237/274267/274272",
     "七次用药请求和逐槽有药→空均复核；两攻击药及技能药共三条回执为pending。缺随机选牌、发光水重问后的完整收益归属，以及同题不喝/留至Boss分支；不能由75/86空栏Boss入口拟合持有价。",
     "保留原持有价/饮用规则；后续逐槽关联请求、选牌、重问、实际牌与增益，再按独立局时间切分验证跨战价值。"),
    ("KEN F17第4/5试T10 274505/274568；第4/6试T5 274484/274601；第二试T2 274354",
     "同指纹T10净损15→21、敌净扣2→4；T5净损7→5、敌净扣1→2，但步法延后。现有预测/端点不足认证完整候选与逐来源能力收益，缺受控整战后继及独立验证；保留排序和HP护栏。",
     "并核无实体实扣、呼唤失血、步法建立窗口与原题B2差/误差；不拟合固定6血/2伤准入，也不因省2血认作完整收益更优。"),
    ("与86a7db08d1a31976共享KEN F17 T2/T5/T10及六次相关SL",
     "KEN局部配对与复盘一致，六次SL仍只一局。缺完整执行归属、受控整战后继和独立后期验证，不能拟合6血/2伤固定门槛或关闭探索；已有诊断只计子项。",
     "沿原经验和0021/0079/0125/0176补链，保留单动作与整轮/候选的边界；未来按独立局和开始时间切分，避免同局训练验证。"),
]
assert len(details) == len(proposals) == 10
results = []
sections = []
for p, (evidence, reason, expected) in zip(proposals, details):
    original = out / ("original-" + p["id"] + ".md")
    assert hashlib.sha256(original.read_bytes()).hexdigest() == p["proposal_sha256"]
    results.append({"id": p["id"], "state": "waiting", "reason": reason})
    sections.append(f"""## {p['id']}

原提案：{p['proposal']}；SHA256 `{p['proposal_sha256']}`（本批逐字保存）。来源任务 `{p['source_task']}` → `strategy-proposal`。角色silent，证据限已核A10。账本：{', '.join(p['ledger'])}；原领域：{', '.join(p['domains'])}。

证据：{evidence}。

处置：**waiting**。{reason}

预期行为及验证：{expected} 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。
""")

proposal = """# 本批十项既有提案的证据核验与处置

批次：20261017-151301-strategy-proposal。本批为普通已领取队列，不承接另一批的研究或实现请求；只处理dispatch.json中的十个ID。不另建提案ID，不改原文/根请求/调度状态。十项全部核过原提案、账本、本角色原日志及当前消费者，均为waiting；已有窄诊断不重复实现或冒认完整duplicate。

基线：`""" + base + """`；main合并检查为Already up to date。适用范围仅本批六个silent A10来源局。报告及逐字提案、原帧引用和消费者产物均在本目录。

当前已有实现的实际live祖先见source-audit.json，原始字节差见base-live-source-differences.patch。游戏结论只由本角色证据形成；现有经验只是待核参照，不把其其他局的分母计入本批。

""" + "\n".join(sections) + """
## 共同边界

原规则与候选排序、药水成本、HP护栏、必死/SL开关保持现状。证据支持局部代价及未知边界，不足支持新的血价/药价或通用准入规则。没有新增科学反证或与旧知识冲突，本批不重复发已有异议通知；没有上线通知、版本或shipped登记。

没有源码改动，无源码撤下/恢复实验；tsc/vitest/cases均未运行，记null。六个既有离线消费者运行是证据读回，不是生产测试或完整候选执行认证。将来若实施策略，按原提案的固定题、撤源码失败/恢复通过、沙箱完整入口与live合入流程验证，并可独立回退实际实现提交；本批没有可回退的新源码提交。
"""
(out / "proposal.md").write_text(proposal)
totals = summary["totals"]
source_table = "\n".join(f"| {p['path']} | {p['live_last_path_commit']} | {'相同' if p['same_bytes'] else '有差异，见补丁'} |" for p in source["paths"])
pair_table = "\n".join(f"| {p['original']['decision']['run_id']} F{p['original']['floor']} T{p['original']['turn']} | {p['original']['decision']['line']} / {p['alternative']['decision']['line']} | {p['original']['net_hp_loss']} → {p['alternative']['net_hp_loss']} | {p['original']['enemy_net_hp_reduction']} → {p['alternative']['enemy_net_hp_reduction']} |" for p in json.loads((out / "paired-observations.json").read_text()))
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261017-151301-strategy-proposal",
          "base": base, "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": [p["id"] for p in proposals], "implementation_domains": [],
          "proposal_results": results, "report": str(out / "report.md")}
(out / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
report = f"""# 静默猎手策略队列核验报告

记录时间：{datetime.datetime.now().astimezone().isoformat(timespec='seconds')}。批次20261017-151301-strategy-proposal。**十项全部waiting；本批没有源码、知识、参数或在线行为修改，没有新提交、live合入、版本或shipped。**

基线完整40位：`{base}`；工作树初始化干净，`git merge --no-edit main` 为Already up to date。dispatch.json保存根learn.json本批实际行：task=strategy-proposal、character=silent、reason=proposal、十个proposal_ids、工作树一致，无research_request/implementation_request。普通专题根文件仍绑定另一旧批次，未读取其work_spec或改换题目。本批不领取其他队列或其他角色。

最终逐项机器结果在result.json；完整提案与证据/账本/验证要求在proposal.md（绝对路径：{out / 'proposal.md'}）。code_proposals沿用十个真实既有CLI ID，没有新增或伪造ID；implementation_domains=[]表示本批没有实际实现，原提案领域仍逐项保存。

## 输入与原始引用

已读README、STATE-2026-10-17、decision-log末尾、learning-protocol及learning-code-proposals。六局身份逐条核自runs.jsonl，均silent A10；runs.json和identity-evidence保存真实行与offset/bytes/SHA。六局只作冻结证据，不外推角色/未观察进阶，不把多次SL或复盘/经验两份提案叠成独立样本。

统一extract_evidence入口提取states/decisions/sl-attempts/run-config/run-plans/brain；run-plans按run、其他流按显式身份且冲突拒收。默认六流8,438条，加runs六条，共8,444条，已逐条回原文件按offset/bytes重读、校验SHA和身份；evidence/evidence-manifest.json、identity-evidence/evidence-manifest.json及evidence-verification.json保存各流source_size、逐局计数和输出SHA。没有以零行报告推断日志缺失，没有覆盖旧截点报告。

十份原Markdown的登记SHA均匹配，逐字副本为original-<id>.md。ledger-before.json为官方fold的16条关联账本快照；relevant-experience.json仅本角色12条相关条目，版本2026-10-17.h0-r1，未修改经验或将其其他来源局计入本批统计。

## 原帧局部对照

| 同指纹题面 | decisions原行 | 玩家净损 | 敌净HP扣减 |
|---|---|---|---|
{pair_table}

paired-observations.json保存每组原状态及引用。这些是直到下一轮的观测端点，不能单独认证完整候选、毛伤或单步整战因果。751 T7第二/第四试多付10血多扣6，T13保6血少扣6；KEN T10多付6血仅多扣2，T5少损2血却推迟步法建立（原T5、末次T9），相反取舍保留。KV T5同指纹的36/29净扣、0/0净损与原提案相符，但第五试有第二次重问，诅咒选牌及转轮身份边界使严格整轮消费者保持unknown。

751 F13 T3的plan2用药与plan5真正整战无药在原模型中同为损8、8/8胜，伤26/16；plan3本轮无药却后续7/8样本仍饮用。缺表成本0不等持有价0；这些是原模型结果，未实打的无药/留药支线不当反事实。target-decisions.json保存原题及药水成本原因，未重跑模拟或借另一角色定价。

YQL F17 T10 states280160→280161：占位体毒2→8，HP26、挡13、来袭41不变，26+13−41=−2仅是末态算术；280162为死亡页，零血截断不能还原完整入伤。L9 sl-attempts681和PU717原参考路径的近十亿HP确实是占位血。PU第五次T15胜是实盘事实，但其他后轮/清体时点同变，未隔离新排序或单瓶药收益。

KEN七次用药逐槽由有药变空均核过，potion-observations.json保存请求/前后帧；274131/274237/274272三条接口回执仍pending，保留原样。其余四条completed也不独立证明整条方案或每张生成牌的收益；六次Boss入口75/86空药栏不能给出留药反事实。

## 当前代码与消费者

核实实际live快照：`{source['live_head']}`。下列源码提交均验证为该live快照祖先；表中提交为对应路径最近的真实live提交，不把main同步提交冒认live祖先。source-audit.json保存20叶的base/live SHA；差异补丁仅保留核实到的原字节差，未修改任何源码。

| 路径 | 实际live祖先源码commit | base/live字节 |
|---|---|---|
{source_table}

已有持牌损血、未知药价/无药参考、SL候选预测、单动作回执和巨兽阶段/毒药事实只是窄子项。SL实际整条候选结果仍null；巨兽enemyHpLeft/anchorRank仍保留旧占位血平局排序，阶段提示没有改变它。上述祖先证明子项已在live，不证明十个宽提案已完整兑现或规则收益，故不登记implemented/duplicate。

已有learner/audit-selection.ts离线消费者仅读冻结输入，六局各运行一次，均exit0；不接游戏、LLM、网络或刷新知识。输入共{totals['decisions']}个动作决策、{totals['states']}状态；另{totals['metadata_exclusions']}条map/route-change元数据缺decision_id，各自原行、SHA和排除原因明确保存在consumer-input-manifest.json，未静默删动作、重排行号或丢失重问。

六局共{totals['segments']}个候选片段、{totals['turn_windows']}个回合窗口，其中{totals['observed_turn_endpoints']}个可核轮端点；完整候选认证{totals['full_candidate_certificates']}。consumer-summary.json逐局计数；consumer-target-turns.json保留重点题目/重问/边界和状态路径；所有consumer-output原件及returncode在本目录。null表示消费者没有认证，并不说明候选未被实际执行。也不从端点净差推完整入伤、逐来源收益或胜率。

## 逐项结论与后续条件

""" + "\n".join(sections) + """
## 验证、失败历史与记录边界

verify_evidence.py首稿误假设KV第4/5试T5仅有两条plan-choice，实际第五试还有一次重问，断言失败。原脚本verify_evidence.py.initial.txt及verification.stderr/stdout初稿保留；修正为每试首次同指纹题面配对，所有重问仍完整保留于消费者输入。verification.r2为后续独立通过结果，不改旧失败，也不是产品源码的红绿测试。

本批未改源码，无源码撤下/恢复测试，无生产tsc/vitest/cases，全部null；六个离线消费者exit0仅指证据读回。无修复提交、合入提交或新eval版本；不运行play，不停局、不推送、不装依赖、不动运维prompt。未给出新游戏规则、持有价、样本外胜率或泛化结论。

账本只经根learner/ledger.py update追加本批proposal.md/report.md及waiting理由的追溯链接，不增加support/repeat，不改claim、证据、首证、prior、进阶、status/version/effect，已有shipped不降级。CLI回执与前缀/逐行验证见ledger-update.*及ledger-link-verification.json；队列状态交原调度器按result.json处理，本批不写learn.json或专用队列，不代ops登记shipped。

没有新科学异议、反证或与旧知识冲突；旧提案自身的相反取舍和未知已保留，不重复发通知或代填其他角色ACK。缺完整受控后继、逐来源实际归属或跨战留药分支的项目仍待有针对性的新局/回放证据。工程诊断存在、消费者exit0与原局局部对照均不足以关闭这些宽提案。
"""
(out / "report.md").write_text(report)
updates = []
for ident in sorted({i for p in proposals for i in p["ledger"]}):
    linked = [p["id"] for p in proposals if ident in p["ledger"]]
    updates.append({"id": ident, "by": "learner:strategy-proposal",
                    "where": {"proposal": [str(out / "proposal.md"), str(out / "report.md")]},
                    "note": "本批20261017-151301-strategy-proposal追溯：" + ",".join(linked) +
                    "均waiting；本角色六局原始引用及既有消费者已核，缺口逐项见报告；仅追加链接，不新增支持/反例、游戏结论、状态或上线声明。"})
(out / "ledger-update.jsonl").write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in updates))
print(json.dumps({"report": str(out / "report.md"), "proposal": str(out / "proposal.md"), "ledger_updates": len(updates),
                  "proposal_results": results, "totals": totals}, ensure_ascii=False))

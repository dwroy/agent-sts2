"""Verify frozen citations and prepare exact single-run offline consumer inputs."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
runs = json.loads((OUT / "runs.json").read_text())
streams = {}
verification = []
for directory in ("evidence", "identity-evidence"):
    manifest = json.loads((OUT / directory / "evidence-manifest.json").read_text())
    for entry in manifest:
        path = OUT / directory / (entry["stream"] + ".evidence.jsonl")
        data = path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == entry["output_sha256"]
        rows = [json.loads(line) for line in data.splitlines()]
        counts = collections.Counter()
        with Path(rows[0]["source"]).open("rb") if rows else open("/dev/null", "rb") as source:
            for envelope in rows:
                assert envelope["offset"] + envelope["bytes"] <= entry["source_size"]
                source.seek(envelope["offset"])
                raw = source.read(envelope["bytes"])
                assert hashlib.sha256(raw).hexdigest() == envelope["sha256"]
                row = json.loads(raw)
                assert row == envelope["row"]
                assert extract.run_identity(row) == envelope["run_id"] in runs
                if entry["stream"] == "states":
                    assert row["state"]["run"]["character_id"].lower() == "silent"
                    assert row["state"]["run"]["ascension"] == 10
                counts[envelope["run_id"]] += 1
        assert dict(counts) == {k: v for k, v in entry["counts"].items() if v}
        streams[entry["stream"]] = rows
        verification.append({"stream": entry["stream"], "source_size": entry["source_size"],
                             "verified_rows": len(rows), "counts": dict(counts),
                             "output_sha256": entry["output_sha256"]})

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")

def ref(envelope):
    return {key: envelope[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}

def raw_state(envelope):
    return envelope["row"]["state"]

def project(envelope):
    state = raw_state(envelope)
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {"ref": ref(envelope), "turn": state["turn"], "screen": state["screen"],
            "hp": player.get("current_hp", state["run"].get("current_hp")),
            "block": player.get("block"), "powers": player.get("powers"),
            "hand": combat.get("hand"), "potions": state["run"].get("potions"),
            "enemies": combat.get("enemies")}

input_manifest = []
for run_id, run in runs.items():
    assert run["character"].lower() == "silent" and run["ascension"] == 10
    identities = [r for r in streams["runs"] if r["run_id"] == run_id]
    assert identities and identities[-1]["row"] == run
    decisions = []
    excluded = []
    for envelope in streams["decisions"]:
        if envelope["run_id"] != run_id:
            continue
        row = envelope["row"]
        if not row.get("decision_id") or not row.get("observed_ts"):
            excluded.append({"ref": ref(envelope), "reason": "缺动作 decision_id 或 observed_ts 的元数据，原行保留在 evidence"})
            continue
        decisions.append({**row, "_line": envelope["line"], "_source_sha256": envelope["sha256"]})
    states = [{**e["row"], "_line": e["line"], "_source_sha256": e["sha256"]}
              for e in streams["states"] if e["run_id"] == run_id]
    path = f"consumer-input-{run_id}.json"
    save(path, {"run": run, "decisions": decisions, "states": states})
    input_manifest.append({"run_id": run_id, "input": path, "decisions": len(decisions),
                           "states": len(states), "exclusions": excluded,
                           "sha256": hashlib.sha256((OUT / path).read_bytes()).hexdigest()})

state_by_key = collections.defaultdict(list)
for e in streams["states"]:
    row = e["row"]
    state_by_key[(row.get("observed_ts"), row.get("fingerprint"))].append(e)
decisions_by_line = {e["line"]: e for e in streams["decisions"]}
states_by_line = {e["line"]: e for e in streams["states"]}

def decision_interval(line):
    decision = decisions_by_line[line]
    row = decision["row"]
    matches = state_by_key[(row.get("observed_ts"), row.get("fingerprint"))]
    assert len(matches) == 1
    before = matches[0]
    candidates = [e for e in streams["states"] if e["run_id"] == decision["run_id"]
                  and e["line"] > before["line"]]
    after = None
    for e in candidates:
        state = raw_state(e)
        if state["run"]["floor"] != row["floor"] or state["turn"] < row["turn"]:
            break
        if state["turn"] > row["turn"] or state["screen"] == "GAME_OVER":
            after = e
            break
    a = project(before)
    b = project(after) if after else None
    a_enemy = a["enemies"] or []
    b_enemy = b["enemies"] or [] if b else []
    comparable = len(a_enemy) == len(b_enemy) == 1 and all(
        a_enemy[0][key] == b_enemy[0][key] for key in ("enemy_id", "max_hp"))
    return {"decision": ref(decision), "floor": row["floor"], "turn": row["turn"],
            "attempt": row.get("sl_attempt"), "before": a, "after": b,
            "net_hp_loss": a["hp"] - b["hp"] if b else None,
            "enemy_net_hp_reduction": a_enemy[0]["current_hp"] - b_enemy[0]["current_hp"] if comparable else None,
            "scope": "原帧端点的观测净变化；不认证完整候选执行、逐来源毛伤或单动作因果"}

pairs = []
for a, b in [(272434, 272575), (272531, 272652), (272483, 272820), (274505, 274568), (274484, 274601)]:
    left, right = decisions_by_line[a]["row"], decisions_by_line[b]["row"]
    assert left["fingerprint"] == right["fingerprint"]
    pairs.append({"same_fingerprint": True, "original": decision_interval(a), "alternative": decision_interval(b)})
kv = [e for e in streams["decisions"] if e["run_id"] == "KV0JHNJCKXLS"
      and e["row"].get("floor") == 33 and e["row"].get("turn") == 5
      and e["row"].get("sl_attempt") in (4, 5)
      and str(e["row"].get("label", "")).startswith("combat/plan-choice")]
kv = [min((e for e in kv if e["row"]["sl_attempt"] == attempt), key=lambda e: e["line"])
      for attempt in (4, 5)]
assert kv[0]["row"]["fingerprint"] == kv[1]["row"]["fingerprint"]
pairs.append({"same_fingerprint": True, "original": decision_interval(kv[0]["line"]),
              "alternative": decision_interval(kv[1]["line"])})
save("paired-observations.json", pairs)

potions = []
for decision_line, before_line, after_line, potion in [
    (274131, 280206, 280207, "ATTACK_POTION"), (274156, 280232, 280233, "STABLE_SERUM"),
    (274185, 280262, 280263, "SPEED_POTION"), (274235, 280313, 280314, "WEAK_POTION"),
    (274237, 280315, 280316, "ATTACK_POTION"), (274267, 280348, 280349, "GLOWWATER_POTION"),
    (274272, 280354, 280355, "SKILL_POTION")]:
    decision = decisions_by_line[decision_line]
    row = decision["row"]
    assert row["chosen"]["action"] == "use_potion"
    a, b = project(states_by_line[before_line]), project(states_by_line[after_line])
    slot = row["chosen"]["option_index"]
    get = lambda snapshot: next(p for p in snapshot["potions"] if p["index"] == slot)
    before_potion, after_potion = get(a), get(b)
    assert before_potion["potion_id"] == potion and after_potion["occupied"] is False
    potions.append({"decision": ref(decision), "floor": row["floor"], "turn": row["turn"],
                    "slot": slot, "potion": potion, "result": row.get("result"), "before": a, "after": b,
                    "scope": "用药请求与同槽由有药变空的观测；不认证完整收益或未饮用反事实"})
save("potion-observations.json", potions)
save("phase-observations.json", [project(states_by_line[i]) for i in (280160, 280161, 280162)])
save("consumer-input-manifest.json", input_manifest)
save("evidence-verification.json", {"streams": verification, "verified_rows": sum(x["verified_rows"] for x in verification),
                                   "all_citations_verified": True, "same_fingerprint_pairs": len(pairs),
                                   "potion_slot_observations": len(potions)})
print(json.dumps({"verified_rows": sum(x["verified_rows"] for x in verification),
                  "pairs": len(pairs), "potion_observations": len(potions), "inputs": input_manifest}, ensure_ascii=False))

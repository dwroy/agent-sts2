"""Append only provenance links through the authorized CLI and verify each own row."""
import copy
import fcntl
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

out = Path(__file__).resolve().parent
root = Path("/home/dw/Projects/agent-sts2")
path = root / "paper/materials/learning/ledger.jsonl"
spec = importlib.util.spec_from_file_location("ledger", root / "learner/ledger.py")
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
with path.open("rb") as handle:
    fcntl.flock(handle, fcntl.LOCK_SH)
    prefix = handle.read()
before = {"source_size": len(prefix), "sha256": hashlib.sha256(prefix).hexdigest()}
(out / "ledger-prefix-before.json").write_text(json.dumps(before, indent=2) + "\n")
requests = [json.loads(line) for line in (out / "ledger-update.jsonl").read_text().splitlines()]
with (out / "ledger-update.jsonl").open() as stdin, (out / "ledger-update.stdout").open("w") as stdout, (out / "ledger-update.stderr").open("w") as stderr:
    result = subprocess.run([sys.executable, str(root / "learner/ledger.py"), "update"], stdin=stdin, stdout=stdout, stderr=stderr)
(out / "ledger-update.process.json").write_text(json.dumps({"returncode": result.returncode, "command": [sys.executable, str(root / "learner/ledger.py"), "update"]}, indent=2) + "\n")
assert result.returncode == 0
with path.open("rb") as handle:
    fcntl.flock(handle, fcntl.LOCK_SH)
    after = handle.read()
assert hashlib.sha256(after[:len(prefix)]).hexdigest() == before["sha256"]
items = {}
receipts = []
offset = 0
for number, raw in enumerate(after.splitlines(keepends=True), 1):
    row = json.loads(raw)
    own = str(row.get("note", "")).startswith("本批20261017-151301-strategy-proposal追溯：")
    prior = copy.deepcopy(items.get(row.get("id"))) if own else None
    if row.get("op") in ("add", "update") and (row["op"] == "add" or row.get("id") in items):
        ledger.apply(items, row)
    if own:
        assert offset >= len(prefix)
        assert set(row) == {"id", "by", "where", "note", "op", "ts"}
        assert row["by"] == "learner:strategy-proposal" and row["op"] == "update"
        assert set(row["where"]) == {"proposal"}
        request = next(r for r in requests if r["id"] == row["id"])
        assert {k: row[k] for k in request} == request
        current = items[row["id"]]
        protected = lambda obj: {k: v for k, v in obj.items() if k not in ("where", "history", "notes")}
        assert protected(prior) == protected(current)
        assert current["history"][:-1] == prior["history"]
        assert current["notes"][:-1] == prior["notes"]
        for key, values in prior["where"].items():
            assert current["where"][key][:len(values)] == values
        receipts.append({"id": row["id"], "line": number, "offset": offset, "bytes": len(raw),
                         "sha256": hashlib.sha256(raw).hexdigest(), "protected_fields_unchanged": True,
                         "status_preserved": current["status"], "only_provenance_appended": True})
    offset += len(raw)
assert len(receipts) == len(requests) == 16
assert {r["id"] for r in receipts} == {r["id"] for r in requests}
(out / "ledger-link-verification.json").write_text(json.dumps({"returncode": 0, "prefix": before,
                                                              "prefix_unchanged": True, "own_rows": receipts}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"returncode": 0, "links": len(receipts), "prefix_unchanged": True, "protected_fields_unchanged": True}, ensure_ascii=False))

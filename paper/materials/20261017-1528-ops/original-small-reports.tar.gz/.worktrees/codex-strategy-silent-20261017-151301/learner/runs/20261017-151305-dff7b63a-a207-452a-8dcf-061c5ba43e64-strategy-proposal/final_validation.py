"""Validate the unchanged worktree, complete per-ID report and preserved artifacts."""
import hashlib
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[2]
result = json.loads((out / "result.json").read_text())
dispatch = json.loads((out / "dispatch.json").read_text())
current = json.loads(Path("/home/dw/Projects/agent-sts2/ops/codex-ops/learn.json").read_text())["batches"][result["batch"]]
for key in ("task", "character", "worktree", "proposal_ids", "runs"):
    assert current[key] == dispatch[key]
assert result["code_proposals"] == dispatch["proposal_ids"]
assert [p["id"] for p in result["proposal_results"]] == dispatch["proposal_ids"]
assert all(p["state"] == "waiting" and p["reason"] for p in result["proposal_results"])
assert result["fixes"] == [] and result["merged"] is None and result["implementation_domains"] == []
assert result["tests"] == {"tsc": None, "vitest": None, "cases": None}
assert Path(result["report"]) == out / "report.md" and (out / "proposal.md").is_file()
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip() == result["base"]
status = subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=root)
patch = subprocess.check_output(["git", "diff", "--binary", result["base"]], cwd=root)
index = subprocess.check_output(["git", "diff", "--cached", "--binary"], cwd=root)
assert status == patch == index == b""
(out / "final-worktree.patch").write_bytes(patch)
(out / "final-index.patch").write_bytes(index)
source = json.loads((out / "source-audit.json").read_text())
assert all(hashlib.sha256((root / p["path"]).read_bytes()).hexdigest() == p["base_sha256"] for p in source["paths"])
ledger = json.loads((out / "ledger-link-verification.json").read_text())
assert ledger["returncode"] == 0 and ledger["prefix_unchanged"] and len(ledger["own_rows"]) == 16
assert all(r["protected_fields_unchanged"] and r["only_provenance_appended"] for r in ledger["own_rows"])
assert json.loads((out / "evidence-verification.json").read_text())["verified_rows"] == 8444
summary = json.loads((out / "consumer-summary.json").read_text())
assert summary["totals"]["full_candidate_certificates"] == 0
assert len(summary["runs"]) == 6 and all(r["returncode"] == 0 for r in summary["runs"])
assert "AssertionError" in (out / "verification.stderr.initial.txt").read_text()
assert not (out / "verification.r2.stderr").read_text()
receipt = {"base": result["base"], "dispatch_still_bound": True, "worktree_clean": True,
           "tracked_diff_bytes": len(patch), "index_diff_bytes": len(index),
           "source_paths_unchanged": len(source["paths"]), "proposal_results": 10,
           "waiting": 10, "ledger_provenance_rows": 16, "evidence_citations": 8444,
           "consumer_processes_passed": 6, "production_tests_run": False,
           "source_commits_created": [], "merged": None}
(out / "final-validation.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
artifacts = []
for path in sorted(out.rglob("*")):
    if path.is_file() and path.name != "artifact-manifest.json":
        data = path.read_bytes()
        artifacts.append({"path": str(path.relative_to(out)), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
(out / "artifact-manifest.json").write_text(json.dumps(artifacts, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({**receipt, "artifacts": len(artifacts)}, ensure_ascii=False))

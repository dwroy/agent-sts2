"""Summarize existing consumers without turning endpoint observations into causality."""
import collections
import hashlib
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[2]
inputs = json.loads((out / "consumer-input-manifest.json").read_text())
processes = json.loads((out / "consumer-processes.json").read_text())
assert all(p["returncode"] == 0 for p in processes)
summaries = []
targets = []
for item in inputs:
    run = item["run_id"]
    data = json.loads((out / f"consumer-output-{run}.json").read_text())
    assert data["run_id"] == run
    assert len(data["observed_actions"]) == item["decisions"]
    assert all(segment["actual_full_candidate_result"] is None for segment in data["segments"])
    assert all(t["facts"] is None or t["facts"]["actual_full_candidate_result"] is None for t in data["observed_turns"])
    summaries.append({"run_id": run, "returncode": 0, "decisions": item["decisions"],
                      "states": item["states"], "explicit_metadata_exclusions": item["exclusions"],
                      "segments": len(data["segments"]), "turn_windows": len(data["observed_turns"]),
                      "observed_turn_endpoints": sum(t["status"] == "observed_turn_endpoints" for t in data["observed_turns"]),
                      "unknown_turn_reasons": dict(collections.Counter(t["reason"] for t in data["observed_turns"] if t["reason"])),
                      "full_candidate_certificates": 0})
    for t in data["observed_turns"]:
        wanted = (run == "751FN9QM9MHQ" and t["floor"] == 17 and (t["turn"], t["attempt"]) in [(2, 1), (2, 3), (7, 2), (7, 4), (13, 1), (13, 6)]) or \
                 (run == "KEN58SH9SLZ6" and t["floor"] == 17 and (t["turn"], t["attempt"]) in [(5, 4), (5, 6), (10, 4), (10, 5)]) or \
                 (run == "KV0JHNJCKXLS" and t["floor"] == 33 and t["turn"] == 5 and t["attempt"] in [4, 5])
        if wanted:
            targets.append({"run_id": run, **t})
totals = {key: sum(row[key] for row in summaries) for key in
          ("decisions", "states", "segments", "turn_windows", "observed_turn_endpoints", "full_candidate_certificates")}
totals["metadata_exclusions"] = sum(len(r["explicit_metadata_exclusions"]) for r in summaries)
(out / "consumer-summary.json").write_text(json.dumps({"runs": summaries, "totals": totals}, ensure_ascii=False, indent=2) + "\n")
(out / "consumer-target-turns.json").write_text(json.dumps(targets, ensure_ascii=False, indent=2) + "\n")

source = json.loads((out / "source-audit.json").read_text())
for path in ["learner/audit-selection.ts", "learner/lib/selection-execution.ts", "learner/lib/selection-observation.ts",
             "learner/lib/selection-terminal.ts", "learner/lib/selection-turn.ts", "agent/src/reflex/silent-selection-dispatch.ts",
             "agent/src/hand/loop.ts", "agent/src/reflex/potion-cost.ts", "agent/src/reflex/turn-solver.ts"]:
    a = subprocess.check_output(["git", "show", source["base"] + ":" + path], cwd=root)
    b = subprocess.check_output(["git", "show", source["live_head"] + ":" + path], cwd=root)
    commit = subprocess.check_output(["git", "log", "-1", "--format=%H", source["live_head"], "--", path], cwd=root, text=True).strip()
    source["paths"].append({"path": path, "base_sha256": hashlib.sha256(a).hexdigest(),
                            "live_sha256": hashlib.sha256(b).hexdigest(), "same_bytes": a == b,
                            "live_last_path_commit": commit,
                            "is_live_ancestor": subprocess.run(["git", "merge-base", "--is-ancestor", commit, source["live_head"]], cwd=root).returncode == 0})
assert len(source["paths"]) == len({p["path"] for p in source["paths"]})
(out / "source-audit.json").write_text(json.dumps(source, indent=2) + "\n")
patch = subprocess.check_output(["git", "diff", "--binary", source["base"], source["live_head"], "--",
                                 *[p["path"] for p in source["paths"] if not p["same_bytes"]]], cwd=root)
(out / "base-live-source-differences.patch").write_bytes(patch)
print(json.dumps({"totals": totals, "source_paths": len(source["paths"]), "source_differences_bytes": len(patch)}, ensure_ascii=False))

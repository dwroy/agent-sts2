"""Run existing offline consumers on verified inputs, at most two child processes."""
import concurrent.futures
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[2]
manifest = json.loads((out / "consumer-input-manifest.json").read_text())

def run_one(item):
    run = item["run_id"]
    command = ["nice", "-n", "15", "node", "--import", "./agent/node_modules/tsx/dist/loader.mjs",
               "learner/audit-selection.ts", str(out / item["input"])]
    with (out / f"consumer-output-{run}.json").open("w") as stdout, (out / f"consumer-{run}.stderr").open("w") as stderr:
        result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
    return {"run_id": run, "returncode": result.returncode, "command": command}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run_one, manifest))
(out / "consumer-processes.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(results, ensure_ascii=False))
raise SystemExit(1 if any(row["returncode"] for row in results) else 0)

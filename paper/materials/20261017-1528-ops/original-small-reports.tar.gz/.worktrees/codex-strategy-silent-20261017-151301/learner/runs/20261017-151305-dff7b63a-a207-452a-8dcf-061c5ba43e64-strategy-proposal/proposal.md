# 本批十项既有提案的证据核验与处置

批次：20261017-151301-strategy-proposal。本批为普通已领取队列，不承接另一批的研究或实现请求；只处理dispatch.json中的十个ID。不另建提案ID，不改原文/根请求/调度状态。十项全部核过原提案、账本、本角色原日志及当前消费者，均为waiting；已有窄诊断不重复实现或冒认完整duplicate。

基线：`5bd559de30f6a23739f3748426ab5be2321ecd0c`；main合并检查为Already up to date。适用范围仅本批六个silent A10来源局。报告及逐字提案、原帧引用和消费者产物均在本目录。

当前已有实现的实际live祖先见source-audit.json，原始字节差见base-live-source-differences.patch。游戏结论只由本角色证据形成；现有经验只是待核参照，不把其其他局的分母计入本批。

## silent-proposal-366288801d9150d9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md；SHA256 `0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0079, silent-0176；原领域：sl, combat。

证据：751 F17 T2/T7/T13，decisions 272434↔272575、272531↔272652、272483↔272820。

处置：**waiting**。原帧及消费者均复核三组同指纹：净损13→18/13→23/8→2，敌净扣9→18/12→18/17→11。已有SL候选及持牌预测诊断，缺抽弃重问后完整候选执行归属、逐来源实际结算与受控整战后继；不能拟合5/10血探索门槛。

预期行为及验证：先保持更差未试线的现准入；后续比较同种子完整后继及独立后期局，分别核持牌失血、已结算输出、能力建立与B2误差。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-85929bdfc8a3fc1b

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md；SHA256 `d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176；原领域：combat, potion。

证据：751 F13 T3 decisions 272361/272362；F17 T7/T13/T17，states 278500—278505、278887/278888。

处置：**waiting**。F13用药plan2与真正整战无药plan5预测均损8；plan3后续7/8样本仍用药。已有未知持有价和未决弃牌诊断，缺实际无药完整分支、留药后战及逐来源兑现；不能把缺表成本0当持有价0或改弃牌排序。

预期行为及验证：保留hold_hp=null、缺表原因、合法药水及原保守损血边界；新局核同题无药/留药实际后继，未决弃牌须按选择后的真实手牌重算。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-efd9f83ee9e1a6dc

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md；SHA256 `0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0079, silent-0176；原领域：sl, combat。

证据：同366288801d9150d9；来源任务为experience-update，六次SL仍属751同一局。

处置：**waiting**。与366288801d9150d9复用751同局三组端点，不能新增独立分母。现有候选预测和单动作回执未认证整条候选，缺真实成本归属、受控整战后继和独立验证；保留waiting。

预期行为及验证：沿原经验与0079/0176链接补完整执行链；与复盘来源同题去重，不把两份Markdown或六次SL当独立验证。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-131042659448ae74

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md；SHA256 `b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176；原领域：combat, potion。

证据：751 F13 T3、F17 T3/T5/T7/T13/T17；账本0005/0006/0007/0046/0129/0176。

处置：**waiting**。751敏捷、毒、荆棘和持牌失血的局部观测与原提案相符。现有单项事实未完成联合逐来源实际校准，缺完整候选归属、无药及留药跨战对照；不能以单项诊断祖先关闭整项。

预期行为及验证：按原候选的攻击、毒、反伤、能力建立及已确认弃牌分别核源；不把净HP差统归单牌或未执行后续。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-990f054036609447

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md；SHA256 `c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0102, silent-0019, silent-0020；原领域：combat, sl。

证据：KV F33第4/5试T5 decisions 273400/273450；第5试另有273451重问。

处置：**waiting**。同指纹原帧净扣36→29、当轮净损均0。第5试后续重问保留在消费者输入；两轮严格消费者均turn_end_unverified。缺敌回血/毛伤逐来源完整归属、受控整战及路线休息替代后继，不能定探索或资源门槛。

预期行为及验证：保留原探索规则；补T5结束后诅咒选牌及下一轮的已知尝试身份，毛伤/回血与净扣分列，再核完整后继而非只看活到T10。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-e18d3f18e6cac2a0

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md；SHA256 `3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046；原领域：combat, potion, sl, terminal。

证据：YQL F17 T10 states 280160/280161；L9 F17 T14 sl-attempts 681；PU F17 T17 sl-attempts 717。

处置：**waiting**。巨兽阶段及残壳毒药事实已有live诊断；YQL毒2→8而血26/挡13/来袭41不变。enemyHpLeft/anchorRank仍用原占位血作平局排序。缺新旧排序、提前喝/不喝/留药的受控完整后继，PU胜线未隔离因素；不关闭宽提案。

预期行为及验证：保留本体0与仍待自爆的事实，保留原排序；固定比较原/新参考路径、最终血挡与阶段，不由占位血差或早清体推导获胜。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-9733bb80f445aeae

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md；SHA256 `c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0017, silent-0019, silent-0020, silent-0250；原领域：combat, potion, sl, terminal。

证据：与e18d3f18e6cac2a0共享L9、PU、YQL三局；来源任务为experience-update。

处置：**waiting**。三局阶段和药水端点支持分账，但已有阶段提示不是阶段估值或排序收益的验证。原占位血平局输入仍保留，缺新旧参考路径和用药时点完整受控比较，不能以PU过爆余2将整项标duplicate。

预期行为及验证：沿原0017/0019/0020/0250链接等待阶段估值和完整后继；不重复发布已有阶段/药水提示，也不预设自爆缺口权重。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-c51468c5e8ba6668

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md；SHA256 `168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0019；原领域：potion。

证据：KEN F3T2/F4T1/F5T2/F11T1/T2/F15T1，decisions 274131/274156/274185/274235/274237/274267/274272。

处置：**waiting**。七次用药请求和逐槽有药→空均复核；两攻击药及技能药共三条回执为pending。缺随机选牌、发光水重问后的完整收益归属，以及同题不喝/留至Boss分支；不能由75/86空栏Boss入口拟合持有价。

预期行为及验证：保留原持有价/饮用规则；后续逐槽关联请求、选牌、重问、实际牌与增益，再按独立局时间切分验证跨战价值。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-86a7db08d1a31976

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md；SHA256 `10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176；原领域：combat, sl。

证据：KEN F17第4/5试T10 274505/274568；第4/6试T5 274484/274601；第二试T2 274354。

处置：**waiting**。同指纹T10净损15→21、敌净扣2→4；T5净损7→5、敌净扣1→2，但步法延后。现有预测/端点不足认证完整候选与逐来源能力收益，缺受控整战后继及独立验证；保留排序和HP护栏。

预期行为及验证：并核无实体实扣、呼唤失血、步法建立窗口与原题B2差/误差；不拟合固定6血/2伤准入，也不因省2血认作完整收益更优。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-e282a9131b99129a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md；SHA256 `a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0021, silent-0079, silent-0125, silent-0176；原领域：combat, sl。

证据：与86a7db08d1a31976共享KEN F17 T2/T5/T10及六次相关SL。

处置：**waiting**。KEN局部配对与复盘一致，六次SL仍只一局。缺完整执行归属、受控整战后继和独立后期验证，不能拟合6血/2伤固定门槛或关闭探索；已有诊断只计子项。

预期行为及验证：沿原经验和0021/0079/0125/0176补链，保留单动作与整轮/候选的边界；未来按独立局和开始时间切分，避免同局训练验证。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## 共同边界

原规则与候选排序、药水成本、HP护栏、必死/SL开关保持现状。证据支持局部代价及未知边界，不足支持新的血价/药价或通用准入规则。没有新增科学反证或与旧知识冲突，本批不重复发已有异议通知；没有上线通知、版本或shipped登记。

没有源码改动，无源码撤下/恢复实验；tsc/vitest/cases均未运行，记null。六个既有离线消费者运行是证据读回，不是生产测试或完整候选执行认证。将来若实施策略，按原提案的固定题、撤源码失败/恢复通过、沙箱完整入口与live合入流程验证，并可独立回退实际实现提交；本批没有可回退的新源码提交。

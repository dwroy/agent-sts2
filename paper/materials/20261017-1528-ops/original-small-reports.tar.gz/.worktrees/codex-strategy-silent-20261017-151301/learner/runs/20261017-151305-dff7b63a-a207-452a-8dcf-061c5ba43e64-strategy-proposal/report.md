# 静默猎手策略队列核验报告

记录时间：2026-10-17T15:25:40+08:00。批次20261017-151301-strategy-proposal。**十项全部waiting；本批没有源码、知识、参数或在线行为修改，没有新提交、live合入、版本或shipped。**

基线完整40位：`5bd559de30f6a23739f3748426ab5be2321ecd0c`；工作树初始化干净，`git merge --no-edit main` 为Already up to date。dispatch.json保存根learn.json本批实际行：task=strategy-proposal、character=silent、reason=proposal、十个proposal_ids、工作树一致，无research_request/implementation_request。普通专题根文件仍绑定另一旧批次，未读取其work_spec或改换题目。本批不领取其他队列或其他角色。

最终逐项机器结果在result.json；完整提案与证据/账本/验证要求在proposal.md（绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-151301/learner/runs/20261017-151305-dff7b63a-a207-452a-8dcf-061c5ba43e64-strategy-proposal/proposal.md）。code_proposals沿用十个真实既有CLI ID，没有新增或伪造ID；implementation_domains=[]表示本批没有实际实现，原提案领域仍逐项保存。

## 输入与原始引用

已读README、STATE-2026-10-17、decision-log末尾、learning-protocol及learning-code-proposals。六局身份逐条核自runs.jsonl，均silent A10；runs.json和identity-evidence保存真实行与offset/bytes/SHA。六局只作冻结证据，不外推角色/未观察进阶，不把多次SL或复盘/经验两份提案叠成独立样本。

统一extract_evidence入口提取states/decisions/sl-attempts/run-config/run-plans/brain；run-plans按run、其他流按显式身份且冲突拒收。默认六流8,438条，加runs六条，共8,444条，已逐条回原文件按offset/bytes重读、校验SHA和身份；evidence/evidence-manifest.json、identity-evidence/evidence-manifest.json及evidence-verification.json保存各流source_size、逐局计数和输出SHA。没有以零行报告推断日志缺失，没有覆盖旧截点报告。

十份原Markdown的登记SHA均匹配，逐字副本为original-<id>.md。ledger-before.json为官方fold的16条关联账本快照；relevant-experience.json仅本角色12条相关条目，版本2026-10-17.h0-r1，未修改经验或将其其他来源局计入本批统计。

## 原帧局部对照

| 同指纹题面 | decisions原行 | 玩家净损 | 敌净HP扣减 |
|---|---|---|---|
| 751FN9QM9MHQ F17 T2 | 272434 / 272575 | 13 → 18 | 9 → 18 |
| 751FN9QM9MHQ F17 T7 | 272531 / 272652 | 13 → 23 | 12 → 18 |
| 751FN9QM9MHQ F17 T13 | 272483 / 272820 | 8 → 2 | 17 → 11 |
| KEN58SH9SLZ6 F17 T10 | 274505 / 274568 | 15 → 21 | 2 → 4 |
| KEN58SH9SLZ6 F17 T5 | 274484 / 274601 | 7 → 5 | 1 → 2 |
| KV0JHNJCKXLS F33 T5 | 273400 / 273450 | 0 → 0 | 36 → 29 |

paired-observations.json保存每组原状态及引用。这些是直到下一轮的观测端点，不能单独认证完整候选、毛伤或单步整战因果。751 T7第二/第四试多付10血多扣6，T13保6血少扣6；KEN T10多付6血仅多扣2，T5少损2血却推迟步法建立（原T5、末次T9），相反取舍保留。KV T5同指纹的36/29净扣、0/0净损与原提案相符，但第五试有第二次重问，诅咒选牌及转轮身份边界使严格整轮消费者保持unknown。

751 F13 T3的plan2用药与plan5真正整战无药在原模型中同为损8、8/8胜，伤26/16；plan3本轮无药却后续7/8样本仍饮用。缺表成本0不等持有价0；这些是原模型结果，未实打的无药/留药支线不当反事实。target-decisions.json保存原题及药水成本原因，未重跑模拟或借另一角色定价。

YQL F17 T10 states280160→280161：占位体毒2→8，HP26、挡13、来袭41不变，26+13−41=−2仅是末态算术；280162为死亡页，零血截断不能还原完整入伤。L9 sl-attempts681和PU717原参考路径的近十亿HP确实是占位血。PU第五次T15胜是实盘事实，但其他后轮/清体时点同变，未隔离新排序或单瓶药收益。

KEN七次用药逐槽由有药变空均核过，potion-observations.json保存请求/前后帧；274131/274237/274272三条接口回执仍pending，保留原样。其余四条completed也不独立证明整条方案或每张生成牌的收益；六次Boss入口75/86空药栏不能给出留药反事实。

## 当前代码与消费者

核实实际live快照：`5782a41c4b1db735e3eba8e769e0ad52c356f136`。下列源码提交均验证为该live快照祖先；表中提交为对应路径最近的真实live提交，不把main同步提交冒认live祖先。source-audit.json保存20叶的base/live SHA；差异补丁仅保留核实到的原字节差，未修改任何源码。

| 路径 | 实际live祖先源码commit | base/live字节 |
|---|---|---|
| agent/src/reflex/silent-held-loss.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 相同 |
| agent/src/reflex/silent-potion-reference.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | 相同 |
| agent/src/reflex/silent-giant-potion.ts | d5e20aa4dd44168ce30944dfcce74f8322144953 | 相同 |
| agent/src/reflex/silent-sl-resource-comparison.ts | 1698adc96ba434a46942321e0237b70657e625b2 | 相同 |
| agent/src/reflex/silent-sl-comparison.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b | 相同 |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 | 相同 |
| agent/src/reflex/combat-plan.ts | a473263eb35ce5bea8e06f1ee94f4da1ba880bc3 | 相同 |
| agent/src/reflex/jev/decision-projection.ts | 10dabfd5b81c88b6c29d1e5ddb349631cb0f2c43 | 相同 |
| agent/src/sl/attempts.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 相同 |
| agent/src/sl/explore.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 有差异，见补丁 |
| agent/src/sl/controller.ts | 0d092f6b928a6221eabf3516abad25c48ceaac9c | 有差异，见补丁 |
| learner/audit-selection.ts | 6f3f783941270ac182237c46068097ff67e85907 | 相同 |
| learner/lib/selection-execution.ts | cf72bd21148059f111f760cc98a727369e34a47e | 相同 |
| learner/lib/selection-observation.ts | cf72bd21148059f111f760cc98a727369e34a47e | 相同 |
| learner/lib/selection-terminal.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 | 相同 |
| learner/lib/selection-turn.ts | 9b87d54f097d84521152e6cca8d6072af8140394 | 相同 |
| agent/src/reflex/silent-selection-dispatch.ts | bade647f9fe4c9103b40e2f26b26296692ad24b7 | 相同 |
| agent/src/hand/loop.ts | a473263eb35ce5bea8e06f1ee94f4da1ba880bc3 | 相同 |
| agent/src/reflex/potion-cost.ts | e1a467e18a0dfa8d99046a24ff4c0e1af59278c8 | 有差异，见补丁 |
| agent/src/reflex/turn-solver.ts | 0e2f10cc7cc043035eafc1785667b630eb335a35 | 相同 |

已有持牌损血、未知药价/无药参考、SL候选预测、单动作回执和巨兽阶段/毒药事实只是窄子项。SL实际整条候选结果仍null；巨兽enemyHpLeft/anchorRank仍保留旧占位血平局排序，阶段提示没有改变它。上述祖先证明子项已在live，不证明十个宽提案已完整兑现或规则收益，故不登记implemented/duplicate。

已有learner/audit-selection.ts离线消费者仅读冻结输入，六局各运行一次，均exit0；不接游戏、LLM、网络或刷新知识。输入共4065个动作决策、4167状态；另6条map/route-change元数据缺decision_id，各自原行、SHA和排除原因明确保存在consumer-input-manifest.json，未静默删动作、重排行号或丢失重问。

六局共861个候选片段、777个回合窗口，其中415个可核轮端点；完整候选认证0。consumer-summary.json逐局计数；consumer-target-turns.json保留重点题目/重问/边界和状态路径；所有consumer-output原件及returncode在本目录。null表示消费者没有认证，并不说明候选未被实际执行。也不从端点净差推完整入伤、逐来源收益或胜率。

## 逐项结论与后续条件

## silent-proposal-366288801d9150d9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md；SHA256 `0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0079, silent-0176；原领域：sl, combat。

证据：751 F17 T2/T7/T13，decisions 272434↔272575、272531↔272652、272483↔272820。

处置：**waiting**。原帧及消费者均复核三组同指纹：净损13→18/13→23/8→2，敌净扣9→18/12→18/17→11。已有SL候选及持牌预测诊断，缺抽弃重问后完整候选执行归属、逐来源实际结算与受控整战后继；不能拟合5/10血探索门槛。

预期行为及验证：先保持更差未试线的现准入；后续比较同种子完整后继及独立后期局，分别核持牌失血、已结算输出、能力建立与B2误差。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-85929bdfc8a3fc1b

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md；SHA256 `d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176；原领域：combat, potion。

证据：751 F13 T3 decisions 272361/272362；F17 T7/T13/T17，states 278500—278505、278887/278888。

处置：**waiting**。F13用药plan2与真正整战无药plan5预测均损8；plan3后续7/8样本仍用药。已有未知持有价和未决弃牌诊断，缺实际无药完整分支、留药后战及逐来源兑现；不能把缺表成本0当持有价0或改弃牌排序。

预期行为及验证：保留hold_hp=null、缺表原因、合法药水及原保守损血边界；新局核同题无药/留药实际后继，未决弃牌须按选择后的真实手牌重算。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-efd9f83ee9e1a6dc

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md；SHA256 `0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0079, silent-0176；原领域：sl, combat。

证据：同366288801d9150d9；来源任务为experience-update，六次SL仍属751同一局。

处置：**waiting**。与366288801d9150d9复用751同局三组端点，不能新增独立分母。现有候选预测和单动作回执未认证整条候选，缺真实成本归属、受控整战后继和独立验证；保留waiting。

预期行为及验证：沿原经验与0079/0176链接补完整执行链；与复盘来源同题去重，不把两份Markdown或六次SL当独立验证。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-131042659448ae74

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md；SHA256 `b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176；原领域：combat, potion。

证据：751 F13 T3、F17 T3/T5/T7/T13/T17；账本0005/0006/0007/0046/0129/0176。

处置：**waiting**。751敏捷、毒、荆棘和持牌失血的局部观测与原提案相符。现有单项事实未完成联合逐来源实际校准，缺完整候选归属、无药及留药跨战对照；不能以单项诊断祖先关闭整项。

预期行为及验证：按原候选的攻击、毒、反伤、能力建立及已确认弃牌分别核源；不把净HP差统归单牌或未执行后续。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-990f054036609447

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md；SHA256 `c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0102, silent-0019, silent-0020；原领域：combat, sl。

证据：KV F33第4/5试T5 decisions 273400/273450；第5试另有273451重问。

处置：**waiting**。同指纹原帧净扣36→29、当轮净损均0。第5试后续重问保留在消费者输入；两轮严格消费者均turn_end_unverified。缺敌回血/毛伤逐来源完整归属、受控整战及路线休息替代后继，不能定探索或资源门槛。

预期行为及验证：保留原探索规则；补T5结束后诅咒选牌及下一轮的已知尝试身份，毛伤/回血与净扣分列，再核完整后继而非只看活到T10。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-e18d3f18e6cac2a0

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md；SHA256 `3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046；原领域：combat, potion, sl, terminal。

证据：YQL F17 T10 states 280160/280161；L9 F17 T14 sl-attempts 681；PU F17 T17 sl-attempts 717。

处置：**waiting**。巨兽阶段及残壳毒药事实已有live诊断；YQL毒2→8而血26/挡13/来袭41不变。enemyHpLeft/anchorRank仍用原占位血作平局排序。缺新旧排序、提前喝/不喝/留药的受控完整后继，PU胜线未隔离因素；不关闭宽提案。

预期行为及验证：保留本体0与仍待自爆的事实，保留原排序；固定比较原/新参考路径、最终血挡与阶段，不由占位血差或早清体推导获胜。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-9733bb80f445aeae

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md；SHA256 `c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0017, silent-0019, silent-0020, silent-0250；原领域：combat, potion, sl, terminal。

证据：与e18d3f18e6cac2a0共享L9、PU、YQL三局；来源任务为experience-update。

处置：**waiting**。三局阶段和药水端点支持分账，但已有阶段提示不是阶段估值或排序收益的验证。原占位血平局输入仍保留，缺新旧参考路径和用药时点完整受控比较，不能以PU过爆余2将整项标duplicate。

预期行为及验证：沿原0017/0019/0020/0250链接等待阶段估值和完整后继；不重复发布已有阶段/药水提示，也不预设自爆缺口权重。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-c51468c5e8ba6668

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md；SHA256 `168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0019；原领域：potion。

证据：KEN F3T2/F4T1/F5T2/F11T1/T2/F15T1，decisions 274131/274156/274185/274235/274237/274267/274272。

处置：**waiting**。七次用药请求和逐槽有药→空均复核；两攻击药及技能药共三条回执为pending。缺随机选牌、发光水重问后的完整收益归属，以及同题不喝/留至Boss分支；不能由75/86空栏Boss入口拟合持有价。

预期行为及验证：保留原持有价/饮用规则；后续逐槽关联请求、选牌、重问、实际牌与增益，再按独立局时间切分验证跨战价值。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-86a7db08d1a31976

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md；SHA256 `10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`（本批逐字保存）。来源任务 `postmortem` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176；原领域：combat, sl。

证据：KEN F17第4/5试T10 274505/274568；第4/6试T5 274484/274601；第二试T2 274354。

处置：**waiting**。同指纹T10净损15→21、敌净扣2→4；T5净损7→5、敌净扣1→2，但步法延后。现有预测/端点不足认证完整候选与逐来源能力收益，缺受控整战后继及独立验证；保留排序和HP护栏。

预期行为及验证：并核无实体实扣、呼唤失血、步法建立窗口与原题B2差/误差；不拟合固定6血/2伤准入，也不因省2血认作完整收益更优。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## silent-proposal-e282a9131b99129a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md；SHA256 `a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`（本批逐字保存）。来源任务 `experience-update` → `strategy-proposal`。角色silent，证据限已核A10。账本：silent-0021, silent-0079, silent-0125, silent-0176；原领域：combat, sl。

证据：与86a7db08d1a31976共享KEN F17 T2/T5/T10及六次相关SL。

处置：**waiting**。KEN局部配对与复盘一致，六次SL仍只一局。缺完整执行归属、受控整战后继和独立后期验证，不能拟合6血/2伤固定门槛或关闭探索；已有诊断只计子项。

预期行为及验证：沿原经验和0021/0079/0125/0176补链，保留单动作与整轮/候选的边界；未来按独立局和开始时间切分，避免同局训练验证。 无新参数拟合；缺失后继保持未知，同一局的SL不拆进训练/验证。原提案中的支持、相反取舍、授权和回退保留，未添加预训练游戏事实。

## 验证、失败历史与记录边界

verify_evidence.py首稿误假设KV第4/5试T5仅有两条plan-choice，实际第五试还有一次重问，断言失败。原脚本verify_evidence.py.initial.txt及verification.stderr/stdout初稿保留；修正为每试首次同指纹题面配对，所有重问仍完整保留于消费者输入。verification.r2为后续独立通过结果，不改旧失败，也不是产品源码的红绿测试。

本批未改源码，无源码撤下/恢复测试，无生产tsc/vitest/cases，全部null；六个离线消费者exit0仅指证据读回。无修复提交、合入提交或新eval版本；不运行play，不停局、不推送、不装依赖、不动运维prompt。未给出新游戏规则、持有价、样本外胜率或泛化结论。

账本只经根learner/ledger.py update追加本批proposal.md/report.md及waiting理由的追溯链接，不增加support/repeat，不改claim、证据、首证、prior、进阶、status/version/effect，已有shipped不降级。CLI回执与前缀/逐行验证见ledger-update.*及ledger-link-verification.json；队列状态交原调度器按result.json处理，本批不写learn.json或专用队列，不代ops登记shipped。

没有新科学异议、反证或与旧知识冲突；旧提案自身的相反取舍和未知已保留，不重复发通知或代填其他角色ACK。缺完整受控后继、逐来源实际归属或跨战留药分支的项目仍待有针对性的新局/回放证据。工程诊断存在、消费者exit0与原局局部对照均不足以关闭这些宽提案。

"""Read the recorded chosen action, retaining the first empty projection separately."""
from pathlib import Path
import bisect
import json
import runpy
from collections import defaultdict, Counter

BASE = Path(__file__).resolve().parent
helpers = runpy.run_path(str(BASE / "audit_evidence.py"))
states = defaultdict(list)
observations = {}
for raw in (BASE / "evidence/states.evidence.jsonl").open():
    item = json.loads(raw)
    row = item["row"]
    key = (item["run_id"], row.get("ts"), row.get("observed_ts"), row.get("fingerprint"))
    assert key not in observations
    observations[key] = len(states[item["run_id"]])
    states[item["run_id"]].append(helpers["slim"](item))
actions = []
for raw in (BASE / "evidence/decisions.evidence.jsonl").open():
    item = json.loads(raw)
    row = item["row"]
    chosen = row.get("chosen") or {}
    if chosen.get("action") not in ("use_potion", "discard_potion"):
        continue
    r = item["run_id"]
    key = (r, row.get("ts"), row.get("observed_ts"), row.get("fingerprint"))
    i = observations[key]
    assert i + 1 < len(states[r])
    actions.append({**helpers["ref"](item), "decision": row,
                    "match": "run_id + ts + observed_ts + fingerprint",
                    "before": states[r][i], "after": states[r][i + 1]})
(BASE / "potion-actions-matched.json").write_text(json.dumps(actions, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"actions": len(actions), "counts": dict(Counter((x["run_id"] + ":" + x["decision"]["chosen"]["action"]) for x in actions))}, ensure_ascii=False))
for x in actions:
    if x["run_id"] == "KEN58SH9SLZ6":
        print(json.dumps({"line": x["line"], "floor": x["decision"]["floor"], "turn": x["decision"]["turn"],
                          "chosen": x["decision"]["chosen"], "before_potions": x["before"]["potions"],
                          "before_line": x["before"]["line"], "after_line": x["after"]["line"]}, ensure_ascii=False))

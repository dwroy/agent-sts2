"""Verify arithmetic on recorded observations; this does not run the gameplay models."""
from pathlib import Path
from collections import Counter
import json

BASE = Path(__file__).resolve().parent
windows = json.loads((BASE / "state-windows.json").read_text())
boundaries = json.loads((BASE / "state-boundaries.json").read_text())
frames = {x["line"]: x for xs in boundaries.values() for x in xs}
frames.update({x["line"]: x for x in windows})
actions = json.loads((BASE / "potion-actions-matched.json").read_text())
checks = []


def check(name, actual, expected, lines=()):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "observed": actual, "expected": expected, "state_lines": list(lines)})


def enemy_hp(line):
    return sum(e["hp"] for e in frames[line]["enemies"])


def same_fingerprint(a, b):
    def read(line):
        frame = frames[line]
        with Path(frame["source"]).open("rb") as f:
            f.seek(frame["offset"])
            return json.loads(f.read(frame["bytes"]))["fingerprint"]
    return read(a) == read(b)


check("沙虫T9两尝试入口指纹", same_fingerprint(282075, 282144), True, [282075, 282144])
check("沙虫T9原线/替线损血", [frames[282075]["hp"] - frames[282079]["hp"],
      frames[282144]["hp"] - frames[282148]["hp"]], [13, 22], [282075, 282079, 282144, 282148])
check("沙虫T9原线/替线伤害", [enemy_hp(282075) - enemy_hp(282079),
      enemy_hp(282144) - enemy_hp(282148)], [24, 39], [282075, 282079, 282144, 282148])
check("沙虫T7延时线付血/伤害", [frames[282330]["hp"] - frames[282336]["hp"],
      enemy_hp(282330) - enemy_hp(282336)], [4, 24], [282330, 282336])
check("沙漏T6原线/替线损血", [frames[281479]["hp"] - frames[281484]["hp"],
      frames[281535]["hp"] - frames[281539]["hp"]], [3, 0], [281479, 281484, 281535, 281539])
check("沙漏T6原线/替线伤害", [enemy_hp(281479) - enemy_hp(281484),
      enemy_hp(281535) - enemy_hp(281539)], [36, 27], [281479, 281484, 281535, 281539])
for a, b in [(281312, 281313), (281338, 281339), (281367, 281368), (281399, 281400), (281565, 281566)]:
    check("王室猛毒新战开场血价", frames[a]["hp"] - frames[b]["hp"], 4, [a, b])
check("后场开场未出牌即归零", [frames[281563]["hp"], frames[281566]["hp"], frames[281566]["cards_played"]],
      [4, 0, 0], [281563, 281565, 281566])
check("紧勒完整逐帧敌血", [enemy_hp(line) for line in range(282887, 282893)],
      [103, 95, 85, 85, 83, 80], range(282887, 282893))
check("紧勒次轮不保留", frames[282892]["enemies"][0]["powers"].get("STRANGLE_POWER"), None, [282892])
check("油灯普通毒药实际建毒", frames[283147]["enemies"][0]["powers"].get("POISON_POWER"), 10, [283146, 283147])
check("帝王蟹首试T2实际损血", frames[283398]["hp"] - frames[283400]["hp"], 7, [283398, 283399, 283400])
check("帝王蟹第二试T2实际损血", frames[283418]["hp"] - frames[283422]["hp"], 6, [283418, 283422])
check("KEN实饮/实弃", [sum(x["run_id"] == "KEN58SH9SLZ6" and x["decision"]["chosen"]["action"] == "use_potion" for x in actions),
      sum(x["run_id"] == "KEN58SH9SLZ6" and x["decision"]["chosen"]["action"] == "discard_potion" for x in actions)], [7, 0])
check("KEN两次营火实际回复", [frames[280338]["hp"] - frames[280336]["hp"],
      frames[280384]["hp"] - frames[280382]["hp"]], [27, 29], [280336, 280338, 280382, 280384])
check("Q6赢精英后接续", [frames[282872]["hp"], frames[282907]["hp"], frames[282913]["hp"], frames[282921]["hp"]],
      [57, 2, 2, 0], [282872, 282907, 282913, 282921])
check("1913精英入口", frames[282755]["hp"], 46, [282755])
cunning = []
for x in actions:
    slot = x["decision"]["chosen"].get("option_index")
    potion = next((p for p in x["before"]["potions"] if p.get("index") == slot), {})
    if potion.get("potion_id") != "CUNNING_POTION":
        continue
    b, a = x["before"], x["after"]
    old = sum(c["id"] == "SHIV" for c in b["hand"])
    shivs = [c for c in a["hand"] if c["id"] == "SHIV"]
    delta = len(shivs) - old
    check("狡诈现场手位新增数", delta, min(3, 10 - len(b["hand"])), [b["line"], a["line"]])
    added = shivs[-delta:] if delta else []
    check("狡诈新增升级状态", [c["upgraded"] for c in added], [True] * delta, [b["line"], a["line"]])
    check("狡诈新增基础伤", [next(d["base_value"] for d in c["values"] if d["name"] == "Damage") for c in added],
          [6] * delta, [b["line"], a["line"]])
    cunning.append({"run": x["run_id"], "floor": x["decision"]["floor"], "turn": x["decision"]["turn"],
                    "before": b["line"], "after": a["line"], "hand_before": len(b["hand"]), "added": delta})
check("狡诈饮用数/独立局数", [len(cunning), len({x["run"] for x in cunning})], [42, 9])
check("狡诈新增分支计数", dict(Counter(x["added"] for x in cunning)), {3: 37, 2: 2, 0: 3})
(BASE / "observations-verified.json").write_text(json.dumps({"scope": "recorded_observation_arithmetic_only",
    "checks": checks, "cunning": cunning}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"observation_checks": len(checks), "cunning_drinks": len(cunning),
                  "cunning_runs": len({x["run"] for x in cunning}), "result": "passed"}, ensure_ascii=False))

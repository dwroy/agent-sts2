"""Write the bounded proposal disposition and reviewable no-source-change report."""
from pathlib import Path
import json

BASE = Path(__file__).resolve().parent
dispatch = json.loads((BASE / "dispatch.json").read_text())
proposals = json.loads((BASE / "dispatched-proposals.json").read_text())["items"]
pins = json.loads((BASE / "source-pins.json").read_text())
components = json.loads((BASE / "subimplementation-commits.json").read_text())
raw = json.loads((BASE / "raw-integrity.json").read_text())
observations = json.loads((BASE / "observations-verified.json").read_text())
batch = "20261018-070101-s2-strategy-proposal"

assessments = [
    {
        "name": "赢战耗药与下一战资源",
        "evidence": "KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1共7次实饮、0次实弃；F5从53到16，F15从46到46；F12 26→53、F16 46→75，分别实际回复27和29。首个Boss入口75，后续恢复不记新药或路线回复。",
        "positions": "decisions 274131/274156/274185/274235/274237/274267/274272；states 280255→280281、280336→280338、280347→280377、280382→280385。",
        "counterexample": "F15实饮两药且零净损，不能据零损推未饮也零损；六次Boss尝试不是六局独立留药实验。",
        "reason": "缺同入口、牌组、后续动作和预算下不用/早用/留至Boss的成对整战结果；7次实际饮用和两次真实回复只能核资源流水，不能校准持药价。",
        "expected": "保持现持药/饮用规则；后续对照须分别报告敌方伤害、实际回复、药栏与Boss入口，不能把SL恢复当新资源。",
        "verification": "用本批7条精确配对动作及营火端点核资源；未来独立新局按时间留出，整战对照齐备后才验证价值参数。",
    },
    {
        "name": "SL首战改善与连续通关",
        "evidence": "TXZ6RVMQA09D A10 F48第2/3试T6均48血、敌460；原线至T7为45血/敌424，替线48血/敌433，即少损3同时少伤9。第三试T10首胜余4，F49出牌数0时4→0。",
        "positions": "states 281479→281484、281535→281539、281563→281566；decisions 275383—275385。",
        "counterexample": "第三试首战转胜而两战仍失败；后续抽牌和生成已改变，不能将T6局部保血当连续通关收益。",
        "reason": "缺保持后续抽牌、生成、选择、药栏及复活资源的两战成对结果；同样本资源接续已有实现，不能据此证明SL新线或新终局权重更优。",
        "expected": "保持严格必死/SL和两战目标；分别保留首战资源、后战入口、条件胜负和低可信限制。",
        "verification": "固定核对3/0损、36/27伤和4→0入口；新规则还须同预算完整两战对照，不能用旧未校准模拟替代实证。",
    },
    {
        "name": "沙虫全败探索的血价与沙坑",
        "evidence": "WQZVENQ7DTRP A10 F33第2/3试T9入口指纹完全相同，26血/敌184；下一轮13血/敌160与4血/敌145，分别损13/22、伤24/39。末试T7为26→22、敌245→221，延时线多付4血且未多伤。",
        "positions": "states 282075→282079、282144→282148、282330→282336；同指纹核验直接读原字节。",
        "counterexample": "T7花血可延长沙坑，不能将一切多损血探索定为错误；本局无受控整战胜线，末轮死亡先后也未明确。",
        "reason": "当轮损血、伤害、毒、沙坑差额诊断已有实现；缺固定后继、同预算整战胜负和独立胜局，不能把9血/15伤或4血/1轮拟成排序阈值。",
        "expected": "保留现探索门槛；同时读血价、伤害、沙坑和未知，保持预测/实际执行分账。",
        "verification": "固定重现13/22损、24/39伤及T7付血；后续固定后继和独立新局才检验探索筛选收益。",
    },
    {
        "name": "狡诈药水生成、手位与完整穿插",
        "evidence": "原提案九局均核为silent：A7 SADL、A9 F4及其余A10。本批直接复核42次饮用：37次添3、2次添2、3次添0；所有实际新增刀均升级、基础伤6。WQZ F33第5试T11为2/0/0，第6试T11为3/2/0。",
        "positions": "states 282292→282296、282352→282357；42组精确动作/状态出处在observations-verified.json及potion-actions-matched.json。",
        "counterexample": "满手饮用消耗瓶但未增加刀；WQZ两容量组最终都未获胜，不能把枚举的穿插多刀当实际救局。",
        "reason": "生成3/2/0、手位截断、固定穿插枚举已有实现；仍缺计划妥当保留、跨抽牌重问、SL恢复及候选到实际完整穿插派发的联合验证。",
        "expected": "保留已实现生成/容量分支；本次不增加通用生成牌规则、保留规则或留药阈值。",
        "verification": "42次原始新增数、升级、基础6逐项核算；完整验收还须串联保留选择、实手牌、出刀、再饮、重问与恢复，不能只用solver枚举代替消费者。",
    },
    {
        "name": "王室猛毒开场与SL双向血价",
        "evidence": "TXZ6RVMQA09D A10 F43/45/46/48/49开场各失4：70→66、52→48、62→58、60→56、4→0；F49没有出牌。SL局部取舍另由TXZ T6和WQZ F33 T7/T9窗口核实。",
        "positions": "states 281312→281313、281338→281339、281367→281368、281399→281400、281565→281566；相关SL窗口同上。",
        "counterexample": "SL恢复不能重复扣开场4；没有核实的回复/复活组合不能沿用这一顺序。原提案更早小血瓶组合净值不在本批扩展学习。",
        "reason": "受限王室猛毒开场和同样本HP/药水/复活接续已有实现；未知回血/复活组合时序、留药与SL完整后继及两战联合校准仍缺证。",
        "expected": "保持已观察组合的开场模型，不扩展未知组合，不放宽必死SL、不新增留药参数。",
        "verification": "五组开场端点和cards_played=0已核；新增组合必须提供结算中间帧、实际消费者和完整两战结果。",
    },
    {
        "name": "连续战斗退出价值与用药时点",
        "evidence": "1913SE84AXQF A10 F29 61→46、F31入口46后死亡；Q6M2Y34MWKRE A10 F7休36→57、F8精英胜57→2，F9以2入场并死。Q6 F2T3敏捷药建2、双防御14；F8速度药当轮5敏而次轮撤层。",
        "positions": "states 282723/282745/282755、282869/282871/282872/282907/282913/282921、282804—282809；两局共8/2次实饮由精确动作配对。",
        "counterexample": "Q6已休息且药最终喝掉，F5/F6零损留药；F2早喝候选未完整实打，不能据此归因或判定应全局早喝。普通紧勒的旧局部误差已另有子实现。",
        "reason": "缺隔离机制误差后、同入口同预算下不用/早用/留药的整战及下一战成对结果；局部候选和当前资源模型不足支持药价或终局权重更改。",
        "expected": "保留价值权重、药价与护栏；审计按实际退出HP和药栏传递，不预支下一轮能力或未来营火。",
        "verification": "用真实入口46和2及药效期限核资源链；时间留出的独立新局与完整替线作为下一验收条件。",
    },
    {
        "name": "紧勒与永久/临时增益分源",
        "evidence": "Q6M2Y34MWKRE A10 F8T4敌血103→95→85→85（弃牌选择中）→83→80（下轮），普通紧勒本体8、后续两次各2、毒3，次轮无紧勒。1913 F31T2弃磨蚀前后能量3，建立1敏/4荆棘。",
        "positions": "states 282887—282892、282767→282768；相关普通属性源码边界见source-pins.json。",
        "counterexample": "弃牌选择未完成时85不变；普通磨蚀付费出牌模型不代表免费弃牌路径已闭环，短战也不能补记完整再生15。",
        "reason": "普通紧勒和普通磨蚀付费出牌属性已有受限子实现；弃磨蚀、永久/临时增益、再生/自动触发与SL恢复的联合输入、消费者和完整后继未齐。",
        "expected": "保持受限已证子公式；不把普通未升级分支扩到叠层、重放、弃牌或未观察组合。",
        "verification": "固定核紧勒六帧及选择完成边界；免费弃牌须进一步覆盖选择器→模型属性→后续多段攻击/反伤→恢复输入，不能拿付费测试代替。",
    },
    {
        "name": "路线真实回复与胜后连续血价",
        "evidence": "1913SE84AXQF A10 F24实际锻造仍40血，F28实际休到61，F29胜余46，F31以46死亡，未来F32营火未到；Q6 A10 F7休到57、F8胜余2、F9死亡。",
        "positions": "states 282706→282709、282720→282722、282723→282745、282755/282783；Q6端点同上一项。run-plans已有该15局共77行，不将正文提及当所属局。",
        "counterexample": "1913实际动作由原预计回血改锻造，计划条件变化不能全记同条件预测误差；Q6已选休息却仍失败，不能证明换线/增加营火必胜。",
        "reason": "缺另一营火动作、事件/路线及用药时点的受控完整结果；现有敌人、构筑和计划条件混杂不能支持路线或终局参数拟合。",
        "expected": "保留路线/休息及价值参数；只按实际完成动作结转，不把未抵达营火和未取得能力记为资源。",
        "verification": "固定实际节点和动作条件；不在15局子集重报原109局或69局全量统计，新路线规则需独立局与时间后移验证。",
    },
    {
        "name": "死亡统计饱和的SL替换",
        "evidence": "NHA2KW0RB7VP A10 F33首四试T1为14挡、损1、跨轮净扣8；第5/6试换线为8挡、损7、净扣24。首试T2入口29，末试T1结束仍30血/8挡对15，原答与替线多付6血换16净伤。六次均败。",
        "positions": "decisions 277248/277250/277272/277274；states 283391—283397、283478起、283506起；不能把后轮自动扣血混作卡牌伤。",
        "counterexample": "临时朝向和初题威胁不等完整回合；第3/4试后续换线仍死，不能据全败认原答必胜或新线等安全。",
        "reason": "当轮原答/替线资源诊断已有实现；缺同预算饱和排序校准、跨弃牌完整执行归属和成对整战后继，不能由同局六次失败确定新SL门槛。",
        "expected": "保持生产探索筛选；当前差额继续作为未证执行的预测展示，不关闭探索或拟固定付血上限。",
        "verification": "原答、覆盖和最终执行分别核对；后续须有可重放完整后继和独立新局，不能把第6试重放当新增成功样本。",
    },
    {
        "name": "油灯首次消费、朝向取整和能力兑现",
        "evidence": "NHA2KW0RB7VP A10 F17T1普通毒药实建10；F33T1 X1萎靡实−2力/2弱。F33首试T2爪显示1→2、火箭30→20，15挡后29→22；第二试16挡后29→23。油灯在施用前后原始遗物对象相同、stack=null，不提供已消费状态。",
        "positions": "states 283146→283147、283395、283398→283400、283418→283422、283506；原提案K367 A1 F30T2及SADL A7 F45保留各自进阶，不用A10覆盖。",
        "counterexample": "已取整显示1不能再乘1.5当实2；已持有毒雾、步法不等已经兑现，末轮建能力却没有下一轮。原dirty运行源码不能由当前提交伪还原。",
        "reason": "蟹朝向和普通精确切击已有受限实现；油灯首次消费跨动作、新战/SL恢复缺联合状态与消费者验证，零X、升级、叠层及能力完整后继仍未覆盖。",
        "expected": "保留已实现子公式和其适用边界；首次消费状态不从持有油灯或当前毒层猜测，不外推其他负面状态。",
        "verification": "三进阶原窗口分别核固定数值；后续须验证首次前后、跨动作重问、新战重置与SL恢复输入，再检验模型和消费者一致性。",
    },
]

assert len(assessments) == len(proposals) == len(dispatch["proposal_ids"]) == 10
for a, p in zip(assessments, proposals):
    a.update(id=p["id"], ledger=p["ledger"], runs=p["runs"], state="waiting", original=p["proposal"],
             original_sha256=p["proposal_sha256"])
(BASE / "proposal-assessment.json").write_text(json.dumps(assessments, ensure_ascii=False, indent=2) + "\n")

proposal_text = [
    "# 静默猎手指定10提案逐项复核与待证计划\n",
    f"批次：{batch}。来源/执行任务：strategy-proposal；仅处理本批proposal_ids。角色silent；授权Roy-2026-10-07-learning不提供游戏事实。\n",
    f"基线：`{pins['base']}`（开工干净，普通批次merge main为仅记录快进）；未绑定research_request/implementation_request。\n",
    "本批不提出新的游戏规则、参数或提案ID。以下10项全部waiting；已完成子实现保留实际live祖先源码链，不把子实现冒报整项duplicate/implemented。\n",
]
for i, a in enumerate(assessments, 1):
    proposal_text.extend([
        f"\n## {i}. {a['name']}\n",
        f"- ID：{a['id']}；账本：{','.join(a['ledger'])}。\n",
        f"- 证据：{a['evidence']}\n- 出处：{a['positions']}\n",
        f"- 反例与未知：{a['counterexample']}\n- 原行为/新行为：{a['expected']}\n",
        f"- 验证：{a['verification']}\n- waiting原因：{a['reason']}\n",
        f"- 原提案：{a['original']}；SHA256 `{a['original_sha256']}`，本批保留原字节副本。\n",
    ])
proposal_text.extend([
    "\n## 统一切分、适用范围与回退\n",
    "只使用核实的本角色15局；A1/A7/A9/A10分列，不从预训练知识补结论。本批均属历史回查，不增加独立support/repeat计数。SL和相邻帧同局成组。机制确定窗口可核公式，不能代替整战价值因果；未来参数验证按独立局和时间后移，训练集与留出集不重复。\n",
    "无源码/知识/参数改动，无须回退源码；保留全部失败、中间稿、原提案与证据。后续真正实现仍须单项提交、固定夹具撤源码失败/恢复通过、沙箱tsc/vitest、live祖先核验及实际上线双通知；其他角色和未观察进阶保持等价。\n",
])
(BASE / "proposal.md").write_text("".join(proposal_text))

report = [
    "# 静默策略批次报告：10项等待补证，无源码修改\n\n",
    f"批次 `{batch}`，task=strategy-proposal，character=silent。\n\n",
    f"报告基线 `{pins['base']}`；开工HEAD为a7de24b635e93a1dee8ccf80cbbe91935c4264eb，工作树干净；执行`git merge --no-edit main`后快进至上述完整40位基线，无冲突。该快进只有运维/台账记录，不是本任务源码合入。\n\n",
    "根learn.json本批角色/工作树/10个proposal_ids已核；无research_request、implementation_request或proposal_repair。普通专题根请求绑定其他批次，因此按指定队列处理，没有转题、领取其他ID或更改派发身份。\n\n",
    "## 结果\n\n",
    "10项全部waiting。无源码、知识、策略参数、任务模板或版本修改；fixes=[]、merged=null；没有新commit、live合入、release_id、shipped或大脑自然采用结论。原提案全部找到并逐SHA匹配，31个关联账本均核为silent。只经根ledger CLI追加本次报告链接和处置说明，不新增support/repeat、不改历史claim/首证/prior/状态/版本/效果，不另建重复提案ID。\n\n",
    "逐项证据、层/回合、账本、反例、期望行为与验收方法见同目录proposal.md和proposal-assessment.json。\n\n",
    "| 提案 | 主题 | 处置与具体缺口 |\n|---|---|---|\n",
]
for a in assessments:
    report.append(f"| {a['id']} | {a['name']} | waiting：{a['reason']} |\n")
report.extend([
    "\n## 原始证据及核验\n\n",
    "派发锚点为dispatch.json的10局。仅因原提案直接关联，补核1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR共5局；runs.jsonl明确均为SILENT。未以这15局冒称原105/109局全历史，原提案旧汇总不由本批子集重报为已重新统计。\n\n",
    "按任务共用extract_evidence.py抽取8流，冻结每流source_size；每行源路径、line、offset、bytes、SHA及所属局保留。随后逐行seek原日志重读，确认SHA、JSON等价、显式身份和全部state角色。未将正文提及当归局。\n\n",
    "| 日志流 | 冻结source_size（字节） | 选中行数 |\n|---|---:|---:|\n",
])
for stream in raw:
    report.append(f"| {stream['stream']} | {stream['source_size']} | {stream['rows']} |\n")
report.extend([
    f"\n合计{sum(x['rows'] for x in raw)}行全部回读通过；清单见evidence/evidence-manifest.json及raw-integrity.json。全源states/decisions/brain各有2条无法解析的行，保留该计数，不据此认定本批缺帧或补造记录。fight-plans在本次2233957字节截点选中0行，只说明该截点未选到本批，不声称原始日志不存在。run-plans按run字段选中77行，保留原字节截点和来源。\n\n",
    "药水动作读取chosen.action，按run_id+ts+observed_ts+fingerprint精确绑定当前状态，再读取其下一观测帧；166次实际use_potion均完成配对，本批未见discard_potion动作。149项原始记录算术核验通过，涵盖狡诈42次/9局、升级/基础6、王室猛毒5组入口、TXZ/WQZ血伤差额、紧勒、蟹现场取整及实际营火回复。它们是证据算术审计，不是实现测试、随机模拟或收益验证；正式tests仍全null。\n\n",
    "关键结论：TXZ F48胜余4而F49出牌前归零；WQZ T9同指纹多付9血/多15伤，T7延时多付4血；狡诈42饮为37次添3、2次添2、3次添0。持有资源、预测候选、实际执行与整战胜因始终分列。\n\n",
    "## 现有子实现与实际live祖先\n\n",
    f"读取时实际live HEAD `{pins['live_head']}`。以下均逐条git merge-base核为该live祖先；仅证明子实现源码已在live，不代表宽父提案全部实现或自然消费者已完成。21个相关源码/测试叶的Git blob、SHA、最后修改commit及live blob保存source-pins.json。\n\n",
    "| 子实现 | 实际live祖先源码commit |\n|---|---|\n",
])
for c in components:
    report.append(f"| {c['component']} | {c['source_commit']} |\n")
report.extend([
    "\n生成3/2/0与固定穿插枚举不覆盖保留/抽牌/SL完整派发；普通磨蚀付费出牌不覆盖免费弃牌消费者；SL诊断标记execution=unverified，保留未知而非实际收益；同样本接续和受限开场并不证明留药或SL新线更优。油灯施用前后遗物对象不变、stack=null，不能仅从当前持有判断首次消费状态。\n\n",
    "source-vs-live.patch保留基线与所读live的相关叶差异，包括既有注释署名及并行Queen行为叶；没有整仓等价断言，也未覆盖或移植这些并行改动。旧对局含dirty版本，当前固定源码仅用于核实现边界，不能伪还原旧运行树。\n\n",
    "## 验证、失败材料与发布\n\n",
    "没有生产源码修改，未运行tsc、vitest、test-sandbox或源码消融；三项tests为null，不填0。没有可撤的新源码，撤源码失败/恢复通过为不适用。149项算术审计不替代这些检查。无合入，无版本及规则上线双通知，无shipped。铁甲和所有角色行为均未修改。\n\n",
    "保留两类分析中间错误：初稿按不存在的intent字段得到0个药水动作；随后读取chosen但用时间前驱误将上一输入与当前输入配对。potion-actions.json、potion-actions-verified.json、cunning-drinks.json及原out均保留且不作为证据结论；最终只采用potion-actions-matched.json、observations-verified.json及精确指纹配对。两次只读小检查还分别遇到空combat、enemy_id字段名称误用，修正后核实；这些分析错误不当产品失败或新游戏反证。\n\n",
    "审计脚本及所有中间材料只放本批learner/runs目录，不提交或导入生产代码；不启动play、模拟池、网络、下级agent或清理。无新增经验结论，所以沿用原10个CLI提案ID，没有调用add制造重复ID。\n\n",
    "## 后续交付边界\n\n",
    "本批完成的是10个指定ID的证据复核与处置。每项waiting保留，缺口见表及proposal.md；后续由原调度器在有对应本角色新证据时重派，不关闭量化父要求或学习入库父要求。不把排队、源端存在或模型枚举当作实际live消费者已读回。\n\n",
    f"运维入口：{BASE / 'proposal.md'}；机器回报：{BASE / 'result.json'}。\n",
])
(BASE / "report.md").write_text("".join(report))

result = {"task": "strategy-proposal", "character": "silent", "batch": batch,
          "base": pins["base"], "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": dispatch["proposal_ids"], "implementation_domains": [],
          "proposal_results": [{"id": a["id"], "state": "waiting", "reason": a["reason"]} for a in assessments],
          "report": str(BASE / "report.md")}
(BASE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

updates = []
for ident in sorted({i for a in assessments for i in a["ledger"]}):
    related = [a for a in assessments if ident in a["ledger"]]
    updates.append({"id": ident, "by": "learner:strategy-proposal",
                    "where": {"proposal": [str(BASE / "proposal.md"), str(BASE / "report.md")]},
                    "note": f"{batch}：复核原提案及本角色冻结原件；" +
                            "；".join(a["id"] + " waiting：" + a["reason"] for a in related) +
                            "。仅追加处置/报告链接，旧局重查不增加support/repeat；无源码/新参数/版本/合入，不改历史状态或登记shipped。"})
(BASE / "ledger-updates.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in updates))
print(json.dumps({"proposal_results": len(assessments), "ledger_links": len(updates),
                  "report": str(BASE / "report.md"), "observation_checks": len(observations["checks"])}, ensure_ascii=False))

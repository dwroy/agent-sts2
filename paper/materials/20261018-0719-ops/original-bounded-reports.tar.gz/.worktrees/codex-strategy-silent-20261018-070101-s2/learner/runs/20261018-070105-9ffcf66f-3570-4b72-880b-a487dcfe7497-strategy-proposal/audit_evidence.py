"""Recheck frozen evidence and retain compact, source-addressed observations."""
from pathlib import Path
import hashlib
import json
import runpy
from collections import Counter, defaultdict

BASE = Path(__file__).resolve().parent
IDENTITY = runpy.run_path(str(BASE.parents[1] / "extract_evidence.py"))["run_identity"]


def write(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def ref(item):
    return {key: item[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}


def powers(values):
    return {p.get("power_id"): p.get("amount") for p in values or []}


def slim(item):
    state = item["row"]["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        **ref(item), "ts": item["row"].get("ts"), "screen": state.get("screen"),
        "floor": run.get("floor"), "turn": state.get("turn"),
        "hp": player.get("current_hp", run.get("current_hp")),
        "max_hp": player.get("max_hp", run.get("max_hp")),
        "block": player.get("block"), "energy": player.get("energy"),
        "cards_played": player.get("cards_played_this_turn"),
        "powers": powers(player.get("powers")),
        "readiness": combat.get("action_readiness"),
        "potions": [{k: p.get(k) for k in ("slot", "index", "potion_id", "occupied")} for p in run.get("potions") or []],
        "relics": [{k: r.get(k) for k in ("relic_id", "stack", "is_melted")} for r in run.get("relics") or []],
        "hand": [{"id": c.get("card_id"), "index": c.get("index"), "upgraded": c.get("upgraded"),
                  "values": c.get("dynamic_values"), "cost": c.get("energy_cost")} for c in combat.get("hand") or []],
        "enemies": [{"id": e.get("enemy_id"), "index": e.get("index"), "hp": e.get("current_hp"),
                     "block": e.get("block"), "powers": powers(e.get("powers")),
                     "move": e.get("move_id"), "intents": e.get("intents")} for e in combat.get("enemies") or []],
    }


def main():
    manifest = json.loads((BASE / "evidence/evidence-manifest.json").read_text())
    identities = json.loads((BASE / "runs-identity.json").read_text())
    wanted = {r["run_id"] for r in identities}
    assert len(wanted) == 15 and all(r["character"] == "SILENT" for r in identities)
    integrity = []
    windows = []
    boundaries = defaultdict(list)
    previous = {}
    run_states = defaultdict(list)
    ranges = [(281312, 281314), (281338, 281340), (281367, 281369), (281399, 281401),
              (281563, 281566), (282075, 282083), (282144, 282152), (282280, 282300),
              (282330, 282338), (282352, 282367), (282804, 282809), (282887, 282892),
              (283146, 283150), (283389, 283400), (283418, 283422), (283500, 283515),
              (217008, 217011)]
    for stream in manifest:
        path = BASE / "evidence" / (stream["stream"] + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        source = Path("/home/dw/Projects/agent-sts2/logs") / (stream["stream"] + ".jsonl")
        with source.open("rb") as original, path.open("rb") as extracted:
            for raw in extracted:
                digest.update(raw)
                item = json.loads(raw)
                assert item["source"] == str(source)
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                original.seek(item["offset"])
                source_raw = original.read(item["bytes"])
                assert hashlib.sha256(source_raw).hexdigest() == item["sha256"]
                assert json.loads(source_raw) == item["row"]
                assert IDENTITY(item["row"]) == item["run_id"] in wanted
                counts[item["run_id"]] += 1
                if stream["stream"] == "states":
                    state = item["row"]["state"]
                    run = state.get("run") or {}
                    assert run.get("character_id") == "SILENT"
                    summary = slim(item)
                    run_id = item["run_id"]
                    run_states[run_id].append(summary)
                    key = (summary["floor"], summary["screen"], summary["turn"])
                    if previous.get(run_id) != key:
                        boundaries[run_id].append({k: v for k, v in summary.items() if k not in ("hand", "relics")})
                        previous[run_id] = key
                    if any(a <= item["line"] <= b for a, b in ranges):
                        windows.append(summary)
        assert digest.hexdigest() == stream["output_sha256"]
        assert all(counts[r] == stream["counts"][r] for r in wanted)
        integrity.append({"stream": stream["stream"], "source_size": stream["source_size"],
                          "rows": sum(counts.values()), "counts": dict(counts),
                          "sha256": digest.hexdigest(), "verified": True})
    write("raw-integrity.json", integrity)
    write("state-windows.json", windows)
    write("state-boundaries.json", boundaries)
    # Actual recorded drink actions, matched with the nearest observed frames on both sides.
    import bisect
    timestamps = {r: [x["ts"] for x in xs] for r, xs in run_states.items()}
    drinks = []
    selected_decisions = []
    for raw in (BASE / "evidence/decisions.evidence.jsonl").open():
        item = json.loads(raw)
        row = item["row"]
        intent = row.get("intent") or {}
        action = intent.get("action", "")
        if "potion" in str(action).lower():
            r = item["run_id"]
            i = bisect.bisect_left(timestamps[r], row["ts"])
            drinks.append({**ref(item), "decision": row,
                           "before": run_states[r][max(0, i - 1)],
                           "after": run_states[r][min(i, len(run_states[r]) - 1)]})
        if row.get("run_id") in {"TXZ6RVMQA09D", "WQZVENQ7DTRP", "NHA2KW0RB7VP"} and any(
                a <= item["line"] <= b for a, b in [(275383, 275385), (275894, 275895),
                    (275960, 275961), (277248, 277250), (277272, 277274)]):
            selected_decisions.append(item)
    write("potion-actions.json", drinks)
    write("decision-windows.json", selected_decisions)
    print(json.dumps({"streams": integrity, "windows": len(windows), "potion_actions": len(drinks),
                      "selected_decisions": len(selected_decisions)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

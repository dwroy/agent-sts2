# 静默猎手本批十项策略处置

记录时间：2026-10-16 17:20:46 CST；batch=20261016-171301-strategy-proposal；base=60dc9008b5b7e256d7f50dbbe8aa36945a3dcc12。

十项均waiting。本批未修改源码、知识、任务模板或验证输入，不拟新策略参数。

范围：只处理派发十个ID；十锚点之外仅使用原提案直接关联的1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。runs.jsonl核十五局全部SILENT；K367=A1、SADL=A7、F4Q=A9，其余A10。

## 1. 赢战耗药与后战资源 — waiting

原ID：`silent-proposal-08eaa60bcc449852`；来源任务：experience-update；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0019, silent-0020。原文SHA256：`4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1两饮共七饮；关键decisions行274131/274156/274185/274235/274237/274267/274272。原提案记六胜战净损46、F12补27和F16补29，后两数沿原提案观察保留。

反例、限制：F15零损时已喝两药，不证明不喝也零损；SL复原不算新获药或路线回复。

旧行为及预期行为：核真实HP、药栏及后战入口资源，保持现有饮用/持有价值。

本批处置及缺数据：缺F15不饮用，以及相同入口和后继下留药到Boss的完整成对结果，无法校准持药价值。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 2. SL首战与连续通关 — waiting

原ID：`silent-proposal-92920295a648b540`；来源任务：postmortem；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0228, silent-0255。原文SHA256：`f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：TXZ6RVMQA09D A10 F48第二/三试T6，同指纹states281480/281536：实损3/敌净扣36与实损0/敌净扣27；states281563/281565/281566为首胜余4、下一房4、开场0，敌111不变。

反例、限制：少失3血也少扣9，后续抽序和生成牌不一致；首胜不证明两战改善，未校准1200样本不作必死依据。

旧行为及预期行为：已有连战、四血开场与raw continuous结果；资源按同样本接续，联合校准和实际第二开场仍unknown。

本批处置及缺数据：缺保持抽序、生成牌、药栏和后续选择一致的两战完整替线及联合校准，不能据首战改善改SL规则。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 3. 沙坑与攻击的双向血价 — waiting

原ID：`silent-proposal-a327449c331efbc1`；来源任务：postmortem；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0079, silent-0018。原文SHA256：`e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：WQZVENQ7DTRP A10 F33第二/三试T9，同指纹states282075/282144：损13/敌净扣24与损22/敌净扣39；T7 states282066/282330：损0/4、同净扣24，原提案沙坑末4/5。

反例、限制：T7付4血换沙坑延长有收益，不能概括为总保血；T9全败也不证明血价相等，末T11先致死来源未知。

旧行为及预期行为：保留既有探索资格，现有资源比较列预测HP/输出；整候选及毒/沙坑实际兑现须由后帧逐项核。

本批处置及缺数据：缺攻防/沙坑两边界的受控完整后继、跨重规划整候选执行归属和独立验证，不能拟固定9血换15伤门槛。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 4. 狡诈生成、保留与穿插 — waiting

原ID：`silent-proposal-a099e89437e942bb`；来源任务：experience-update；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0030, silent-0257, silent-0258。原文SHA256：`e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：SADL3CGYTGSR A7 F8T1、NB8KCF6HRGVF A10 F31T5及原提案直接九局42饮：37次加3、2次加2、3次加0，均升级小刀；WQZVENQ7DTRP A10 F33第五/六试T11分别2/0/0与3/2/0。

反例、限制：满手仍耗瓶；现场4/7/8等显示伤害受增益影响，不推翻原已核基础6。添刀不等于整候选已执行或整战可赢。

旧行为及预期行为：确定生成及手位模型已有live实现，不重复加入；保留容量、出刀后喝和SL恢复需要联合验收。

本批处置及缺数据：缺计划妥当保留容量、出刀穿插、跨重问完整派发与SL恢复的联合校准；生成子实现不足关闭整项。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 5. 连战开场与真实资源结转 — waiting

原ID：`silent-proposal-47910f82a1fdd98f`；来源任务：experience-update；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。原文SHA256：`d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：TXZ6RVMQA09D A10 F48T10首胜留4，F49T1可操作前4→0、敌111未变；同局F43/45/46/48各净扣4为原提案观察。WQZVENQ7DTRP F33T7/T9双向血价已复核。

反例、限制：王室猛毒与小血瓶旧组合净2不拆成单件顺序；未知回血/复活组合不外推，SL不再次扣开场价。

旧行为及预期行为：已观察遗物/药栏组合的四血开场已有live分支；实际路线回复、药栏和可操作入口分账。

本批处置及缺数据：缺留药、路线和SL的受控完整后继，以及未知回血/复活组合的结算顺序，联合资源要求仍未完成。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 6. 连续战斗资源与退出价值 — waiting

原ID：`silent-proposal-f1374df72d8e6a25`；来源任务：postmortem；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0019, silent-0020, silent-0050, silent-0253。原文SHA256：`df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：1913SE84AXQF A10 F29胜61→46、F31入口46后死；Q6M2Y34MWKRE A10 F2T1早喝敏捷候选未完整执行、T3实际饮用，F8T1速度当轮兑现/T2撤层，F8胜57→2、F9T2死（原提案及已核原帧）。

反例、限制：Q6确实休息且药最终喝掉，F5/F6零损留药不是丢药；1913 F24锻造使路线条件改变，紧勒漏算不能当价值参数误差。

旧行为及预期行为：先核临时/持续药效、实际退出资源及后继需求；保留现有药价、HP护栏及终局权重。

本批处置及缺数据：缺隔离机制误差后的同入口、同预算不用/早用/留药整战和下一战成对结果，不能据两条失败链拟新权重。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 7. 逐牌紧勒与增益分源 — waiting

原ID：`silent-proposal-38a49e6c97f31eea`；来源任务：experience-update；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。原文SHA256：`6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：Q6M2Y34MWKRE A10 F8T4，states282887—282891敌HP103→95→85→85→83，包含弃牌完成后的2失血；1913SE84AXQF F31T2—4弃磨蚀、荆棘及重接观察见原提案。

反例、限制：只用本批已核普通无挡紧勒端点，不外推升级/叠层/重放；毛伤、复活与轮间净扣不同，反伤不能提前删掉已发动攻击。

旧行为及预期行为：普通紧勒已有live窄实现；再生/临时敏捷等已有模型需与实际来源、阶段及兑现窗口联合验收。

本批处置及缺数据：缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准和受控完整后继，不能由单公式关闭整项。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 8. 真实回复与路线后继 — waiting

原ID：`silent-proposal-ef0e38a5dbd3bc07`；来源任务：experience-update；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0019, silent-0020, silent-0021。原文SHA256：`d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：1913SE84AXQF A10 F24锻造不回血、F28实回21、F29胜后46、F31死且F32未来营火未到；Q6M2Y34MWKRE A10 F7回36→57、F8胜至2、F9T2死（原提案资源链）。

反例、限制：未来营火不是已到账HP；不同构筑/敌人/间隔的休息存活与事件死亡不能当改线因果。

旧行为及预期行为：按实际动作传递资源，持有、已建和死前未兑现能力分开，不重复拟合已存在的字段。

本批处置及缺数据：缺另一营火、事件、路线和用药时机的受控完整结果；两败不能校准路线或终局权重。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 9. 死亡统计饱和的SL替换 — waiting

原ID：`silent-proposal-7f820c02d39bfaea`；来源任务：postmortem；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0079。原文SHA256：`bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：NHA2KW0RB7VP A10 F33第一/五/六试T1，states283391/283397、283478/283483、283502/283507：各损1/7/7，跨轮敌净扣8/24/24；原决策277248/277250、277272/277274。

反例、限制：后两次仍败，不是独立成功样本；跨轮净扣含自动伤，原精确切击经生存者弃掉后的初题不是最终完整执行。

旧行为及预期行为：现有SL资源对照是current_turn_prediction且execution=unverified；单动作回执的whole_plan_executed=null，继续分开模型差与实际结果。

本批处置及缺数据：缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继，不能由1/7血价差定新SL门槛。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 10. 油灯首次消费、取整与能力兑现 — waiting

原ID：`silent-proposal-04b6b430759815ed`；来源任务：experience-update；实现任务：strategy-proposal/20261016-171301-strategy-proposal。

账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。原文SHA256：`188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。

证据局号/层/回合：K3676LU8B0UH A1 F30T2带毒刺击4→8；SADL3CGYTGSR A7 F45毒药5→10；NHA2KW0RB7VP A10 F17T1毒药5→10、F33六试T1普通X1萎靡实建−2力/2弱，合九目标端点。本局F33T2蟹正/背显示1/2的原六窗口见原提案。

反例、限制：九端点不替代原17窗口或首次消费的跨动作身份；不外推其他状态/零X/升级/叠层或未知取整顺序。拥有能力不等于已兑现。

旧行为及预期行为：蟹朝向取整已有live窄实现；油灯模型须明确每战首次消费、目标和SL恢复的身份，不从端点倒填通用持久状态。

本批处置及缺数据：缺油灯首次消费跨动作、新战和SL恢复的联合输入，以及未覆盖X值、升级组合与能力整战后继。

验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。

## 共同实现、验证与回退边界

旧局仅为发现及固定回放集；不把同局SL、轮数或模拟样本充作独立对局。新价值/排名参数必须按本角色已观察进阶、独立局及时间向前切分；没有完整替线不猜固定血价、药价或胜率。Roy-2026-10-07-learning是改规则授权，不提供游戏事实。其他角色及未观察组合保持等价。

本批实际核19929条原始记录，186项关键材料检查，九油灯目标端点与十五原run-config；详evidence-verification.json、supplemental-verification.json。大流复用旧共用提取器原封套和原截点，小流由本批共用入口重提；保存全部定位于evidence-index.jsonl。fight-plans零行只说明该截点未选到。旧六消费者只核输入/输出SHA和原回执，未重跑消费者/模拟/模型，不将旧exit0记为本批生产测试。历史dirty知识/移动表字节不全，不冒称原生产全量复原。

源码核对见source-audit.json和两份binary patch：22叶与前批相同，18叶与live字节相同，四叶只差历史署名注释。七个原源码提交均实核base/live祖先。已实现子项不冒称整个宽提案duplicate/implemented。当前SL comparison仍预测且execution=unverified；单动作回执actual_turn/whole_plan_executed=null；continuous-boss-result仍raw_simulation且calibration/actualSecondOpening=unknown。

无新增机制反证或与旧经验冲突；原双向取舍、失败和未知保留，不强行支持原假设。没有新增知识入库、消费者采用或实盘收益声称，不关闭学习入库/量化父要求。

本批无源码提交、撤源码/恢复试验、tsc/vitest、live合入或eval版本；tests三个字段均null。若未来实现，按每项隔离提交和原沙箱/live流程验证，失败撤回该实现并保留原始证据与并行数据；实际上线后由原链登记版本及双通知，账本shipped交运维核实。当前仅CLI追加既有账本追溯，不降级旧shipped状态、不重复support或新建提案ID。

已有源码祖先（均实际核live祖先，仅说明各自范围）：

- `5b56a452bb9be14d620b368ec46974c1b57901ca`：Integrate verified live dependencies into main while retaining main-only fixes。
- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：Sync repaired legacy learning and continuation adapter to main。
- `68711002f15b298b8863d2258ee5da236da151d2`：Sync tested Silent Crusher facing rounding from live。
- `fdaf787a372880b0438e73bcac7e6d2168b038ed`：Record Silent candidate dispatch receipts separately from forecasts。
- `1698adc96ba434a46942321e0237b70657e625b2`：Complete Silent SL resource comparison audit。
- `bca06096b08b1e9bf0e11fda3e1f87fe4d83ec07`：Record raw continuous boss stages and per-sample resource diagnostics。
- `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`：Extend observed Silent opening HP combinations。

import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-091304-s2/learner/runs/20261016-091314-3038fabf-057d-4ffa-8440-ced1808388f5-strategy-proposal')
origins = json.loads((HERE / 'evidence-origins.json').read_text())
source = Path(next(v['path'] for v in origins if v['manifest']['stream'] == 'states'))
lamp_path = OLD / 'lamp-nine-observations.json'
lamp = json.loads(lamp_path.read_text())
wanted = {n for v in lamp['observations'] for n in [v['before_line'], v['after_line']]}
states = {}
for line in source.open():
    v = json.loads(line)
    if v['line'] in wanted:
        states[v['line']] = v
checks = []
for item in lamp['observations']:
    a, b = (states[item[key]] for key in ['before_line', 'after_line'])
    assert a['run_id'] == b['run_id'] == item['run']
    sa, sb = a['row']['state'], b['row']['state']
    assert [sa['run']['floor'], sa['turn']] == [item['floor'], item['turn']]
    assert [sb['run']['floor'], sb['turn']] == [item['floor'], item['turn']]
    assert sa['combat']['player']['energy'] == item['energy_before']
    for s, key in [(sa, 'powers_before'), (sb, 'powers_after')]:
        enemy = next(e for e in s['combat']['enemies'] if e['index'] == item['target_index'])
        assert enemy['enemy_id'] == item['target_enemy_id']
        powers = {p['power_id']: p['amount'] for p in enemy['powers']}
        observed = {k: powers.get(k, 0) for k in item[key]}
        assert observed == item[key]
        if not item[key]:
            assert not any(powers.get(k, 0) for k in item['powers_after'])
    checks.append(item)
configs = json.loads((HERE / 'run-config-records.json').read_text())
code = []
for v in configs:
    cfg = v['row']; run = v['run_id']; c = cfg['code']; commit = c['commit']
    assert cfg['character'].lower() == 'silent'
    assert len(commit) == 40
    subprocess.run(['git', 'cat-file', '-e', commit + '^{commit}'], check=True)
    dirty = c.get('dirty_files', [])
    assert all(not path.startswith(('agent/', 'learner/', 'ops/', 'eval/')) for path in dirty)
    code.append({'run': run, 'commit': commit, 'dirty': c['dirty'], 'dirty_files': dirty,
                 'limitation': '原提交存在；刷新知识的具体字节未全部冻结，不称完整历史生产重放。'})
output = {'lamp_endpoints_verified': len(checks), 'lamp_source': str(lamp_path),
          'lamp_source_sha256': hashlib.sha256(lamp_path.read_bytes()).hexdigest(),
          'observations': checks, 'historical_configs': code,
          'limitations': ['只核九目标端点，不能替代原十七窗口或油灯首次消费的持续身份。',
                         '十五份代码提交存在，不代表dirty知识输入已复原。']}
(HERE / 'supplemental-verification.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'lamp_endpoints': len(checks), 'historical_configs': len(code)}, ensure_ascii=False))

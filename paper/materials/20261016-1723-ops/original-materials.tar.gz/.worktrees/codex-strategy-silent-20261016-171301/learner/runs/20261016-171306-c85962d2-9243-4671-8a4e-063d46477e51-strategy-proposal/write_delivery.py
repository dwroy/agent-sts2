import datetime
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BATCH = '20261016-171301-strategy-proposal'
BASE = '60dc9008b5b7e256d7f50dbbe8aa36945a3dcc12'
history = json.loads((HERE / 'assigned-proposals-history.json').read_text())
dispatch = json.loads((HERE / 'dispatch.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
checks = json.loads((HERE / 'evidence-verification.json').read_text())
supplement = json.loads((HERE / 'supplemental-verification.json').read_text())
assert checks['verified_lines'] == 19929 and checks['material_checks'] == 186
assert supplement['lamp_endpoints_verified'] == 9
assert len(source['paths']) == 22 and all(v['same_previous'] for v in source['paths'])
stamp = datetime.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')

details = [
    ('赢战耗药与后战资源',
     'KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1两饮共七饮；关键decisions行274131/274156/274185/274235/274237/274267/274272。原提案记六胜战净损46、F12补27和F16补29，后两数沿原提案观察保留。',
     'F15零损时已喝两药，不证明不喝也零损；SL复原不算新获药或路线回复。',
     '核真实HP、药栏及后战入口资源，保持现有饮用/持有价值。',
     '缺F15不饮用，以及相同入口和后继下留药到Boss的完整成对结果，无法校准持药价值。'),
    ('SL首战与连续通关',
     'TXZ6RVMQA09D A10 F48第二/三试T6，同指纹states281480/281536：实损3/敌净扣36与实损0/敌净扣27；states281563/281565/281566为首胜余4、下一房4、开场0，敌111不变。',
     '少失3血也少扣9，后续抽序和生成牌不一致；首胜不证明两战改善，未校准1200样本不作必死依据。',
     '已有连战、四血开场与raw continuous结果；资源按同样本接续，联合校准和实际第二开场仍unknown。',
     '缺保持抽序、生成牌、药栏和后续选择一致的两战完整替线及联合校准，不能据首战改善改SL规则。'),
    ('沙坑与攻击的双向血价',
     'WQZVENQ7DTRP A10 F33第二/三试T9，同指纹states282075/282144：损13/敌净扣24与损22/敌净扣39；T7 states282066/282330：损0/4、同净扣24，原提案沙坑末4/5。',
     'T7付4血换沙坑延长有收益，不能概括为总保血；T9全败也不证明血价相等，末T11先致死来源未知。',
     '保留既有探索资格，现有资源比较列预测HP/输出；整候选及毒/沙坑实际兑现须由后帧逐项核。',
     '缺攻防/沙坑两边界的受控完整后继、跨重规划整候选执行归属和独立验证，不能拟固定9血换15伤门槛。'),
    ('狡诈生成、保留与穿插',
     'SADL3CGYTGSR A7 F8T1、NB8KCF6HRGVF A10 F31T5及原提案直接九局42饮：37次加3、2次加2、3次加0，均升级小刀；WQZVENQ7DTRP A10 F33第五/六试T11分别2/0/0与3/2/0。',
     '满手仍耗瓶；现场4/7/8等显示伤害受增益影响，不推翻原已核基础6。添刀不等于整候选已执行或整战可赢。',
     '确定生成及手位模型已有live实现，不重复加入；保留容量、出刀后喝和SL恢复需要联合验收。',
     '缺计划妥当保留容量、出刀穿插、跨重问完整派发与SL恢复的联合校准；生成子实现不足关闭整项。'),
    ('连战开场与真实资源结转',
     'TXZ6RVMQA09D A10 F48T10首胜留4，F49T1可操作前4→0、敌111未变；同局F43/45/46/48各净扣4为原提案观察。WQZVENQ7DTRP F33T7/T9双向血价已复核。',
     '王室猛毒与小血瓶旧组合净2不拆成单件顺序；未知回血/复活组合不外推，SL不再次扣开场价。',
     '已观察遗物/药栏组合的四血开场已有live分支；实际路线回复、药栏和可操作入口分账。',
     '缺留药、路线和SL的受控完整后继，以及未知回血/复活组合的结算顺序，联合资源要求仍未完成。'),
    ('连续战斗资源与退出价值',
     '1913SE84AXQF A10 F29胜61→46、F31入口46后死；Q6M2Y34MWKRE A10 F2T1早喝敏捷候选未完整执行、T3实际饮用，F8T1速度当轮兑现/T2撤层，F8胜57→2、F9T2死（原提案及已核原帧）。',
     'Q6确实休息且药最终喝掉，F5/F6零损留药不是丢药；1913 F24锻造使路线条件改变，紧勒漏算不能当价值参数误差。',
     '先核临时/持续药效、实际退出资源及后继需求；保留现有药价、HP护栏及终局权重。',
     '缺隔离机制误差后的同入口、同预算不用/早用/留药整战和下一战成对结果，不能据两条失败链拟新权重。'),
    ('逐牌紧勒与增益分源',
     'Q6M2Y34MWKRE A10 F8T4，states282887—282891敌HP103→95→85→85→83，包含弃牌完成后的2失血；1913SE84AXQF F31T2—4弃磨蚀、荆棘及重接观察见原提案。',
     '只用本批已核普通无挡紧勒端点，不外推升级/叠层/重放；毛伤、复活与轮间净扣不同，反伤不能提前删掉已发动攻击。',
     '普通紧勒已有live窄实现；再生/临时敏捷等已有模型需与实际来源、阶段及兑现窗口联合验收。',
     '缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准和受控完整后继，不能由单公式关闭整项。'),
    ('真实回复与路线后继',
     '1913SE84AXQF A10 F24锻造不回血、F28实回21、F29胜后46、F31死且F32未来营火未到；Q6M2Y34MWKRE A10 F7回36→57、F8胜至2、F9T2死（原提案资源链）。',
     '未来营火不是已到账HP；不同构筑/敌人/间隔的休息存活与事件死亡不能当改线因果。',
     '按实际动作传递资源，持有、已建和死前未兑现能力分开，不重复拟合已存在的字段。',
     '缺另一营火、事件、路线和用药时机的受控完整结果；两败不能校准路线或终局权重。'),
    ('死亡统计饱和的SL替换',
     'NHA2KW0RB7VP A10 F33第一/五/六试T1，states283391/283397、283478/283483、283502/283507：各损1/7/7，跨轮敌净扣8/24/24；原决策277248/277250、277272/277274。',
     '后两次仍败，不是独立成功样本；跨轮净扣含自动伤，原精确切击经生存者弃掉后的初题不是最终完整执行。',
     '现有SL资源对照是current_turn_prediction且execution=unverified；单动作回执的whole_plan_executed=null，继续分开模型差与实际结果。',
     '缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继，不能由1/7血价差定新SL门槛。'),
    ('油灯首次消费、取整与能力兑现',
     'K3676LU8B0UH A1 F30T2带毒刺击4→8；SADL3CGYTGSR A7 F45毒药5→10；NHA2KW0RB7VP A10 F17T1毒药5→10、F33六试T1普通X1萎靡实建−2力/2弱，合九目标端点。本局F33T2蟹正/背显示1/2的原六窗口见原提案。',
     '九端点不替代原17窗口或首次消费的跨动作身份；不外推其他状态/零X/升级/叠层或未知取整顺序。拥有能力不等于已兑现。',
     '蟹朝向取整已有live窄实现；油灯模型须明确每战首次消费、目标和SL恢复的身份，不从端点倒填通用持久状态。',
     '缺油灯首次消费跨动作、新战和SL恢复的联合输入，以及未覆盖X值、升级组合与能力整战后继。'),
]
assert len(details) == len(dispatch['proposal_ids']) == 10
proposal_results = []
parts = [f'# 静默猎手本批十项策略处置\n\n记录时间：{stamp}；batch={BATCH}；base={BASE}。\n\n十项均waiting。本批未修改源码、知识、任务模板或验证输入，不拟新策略参数。\n\n范围：只处理派发十个ID；十锚点之外仅使用原提案直接关联的1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。runs.jsonl核十五局全部SILENT；K367=A1、SADL=A7、F4Q=A9，其余A10。\n']
for number, (id, detail) in enumerate(zip(dispatch['proposal_ids'], details), 1):
    original = history[id][0]
    title, evidence, counter, behavior, reason = detail
    proposal_results.append({'id': id, 'state': 'waiting', 'reason': reason})
    parts.append(f'\n## {number}. {title} — waiting\n\n原ID：`{id}`；来源任务：{original["source_task"]}；实现任务：strategy-proposal/{BATCH}。\n\n账本：{", ".join(original["ledger"])}。原文SHA256：`{original["proposal_sha256"]}`；原路径与只读副本见proposal-source-checks.json及本目录同ID.md。\n\n证据局号/层/回合：{evidence}\n\n反例、限制：{counter}\n\n旧行为及预期行为：{behavior}\n\n本批处置及缺数据：{reason}\n\n验证方法：用冻结共用提取封套逐原offset/bytes/SHA/JSON/显式身份复核，关键当轮端点实际重核；不能由端点认证完整候选、整战胜因或未走分支。将来实现须冻结原生产输入、核重问/抽弃牌/药水后的整候选派发和后继，再做撤源码失败/恢复通过及规定沙箱测试。\n')
parts.append('''
## 共同实现、验证与回退边界

旧局仅为发现及固定回放集；不把同局SL、轮数或模拟样本充作独立对局。新价值/排名参数必须按本角色已观察进阶、独立局及时间向前切分；没有完整替线不猜固定血价、药价或胜率。Roy-2026-10-07-learning是改规则授权，不提供游戏事实。其他角色及未观察组合保持等价。

本批实际核19929条原始记录，186项关键材料检查，九油灯目标端点与十五原run-config；详evidence-verification.json、supplemental-verification.json。大流复用旧共用提取器原封套和原截点，小流由本批共用入口重提；保存全部定位于evidence-index.jsonl。fight-plans零行只说明该截点未选到。旧六消费者只核输入/输出SHA和原回执，未重跑消费者/模拟/模型，不将旧exit0记为本批生产测试。历史dirty知识/移动表字节不全，不冒称原生产全量复原。

源码核对见source-audit.json和两份binary patch：22叶与前批相同，18叶与live字节相同，四叶只差历史署名注释。七个原源码提交均实核base/live祖先。已实现子项不冒称整个宽提案duplicate/implemented。当前SL comparison仍预测且execution=unverified；单动作回执actual_turn/whole_plan_executed=null；continuous-boss-result仍raw_simulation且calibration/actualSecondOpening=unknown。

无新增机制反证或与旧经验冲突；原双向取舍、失败和未知保留，不强行支持原假设。没有新增知识入库、消费者采用或实盘收益声称，不关闭学习入库/量化父要求。

本批无源码提交、撤源码/恢复试验、tsc/vitest、live合入或eval版本；tests三个字段均null。若未来实现，按每项隔离提交和原沙箱/live流程验证，失败撤回该实现并保留原始证据与并行数据；实际上线后由原链登记版本及双通知，账本shipped交运维核实。当前仅CLI追加既有账本追溯，不降级旧shipped状态、不重复support或新建提案ID。
''')
parts.append('\n已有源码祖先（均实际核live祖先，仅说明各自范围）：\n\n' + '\n'.join(f'- `{v["commit"]}`：{v["subject"]}。' for v in source['commits']) + '\n')
(HERE / 'proposal.md').write_text(''.join(parts))
(HERE / 'dispositions.json').write_text(json.dumps(proposal_results, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': proposal_results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposal_results': len(proposal_results), 'waiting': len(proposal_results), 'base': BASE}, ensure_ascii=False))

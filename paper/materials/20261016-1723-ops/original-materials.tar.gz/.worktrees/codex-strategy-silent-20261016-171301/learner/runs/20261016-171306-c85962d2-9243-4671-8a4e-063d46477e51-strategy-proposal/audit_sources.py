import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREVIOUS = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-160244-s2/learner/runs/20261016-160248-2b61d1de-d1ad-4f5e-bf79-1bd4394f1c3c-strategy-proposal')


def git(*args):
    return subprocess.check_output(['git', *args])


old_path = PREVIOUS / 'source-audit.json'
old = json.loads(old_path.read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = git('-C', '/home/dw/Projects/agent-sts2/.worktrees/live', 'rev-parse', 'HEAD').decode().strip()
paths = [v['path'] for v in old['paths']]
records = []
for entry in old['paths']:
    path = entry['path']
    current = Path(path).read_bytes()
    deployed = git('show', f'{live}:{path}')
    sha = hashlib.sha256(current).hexdigest()
    records.append({'path': path, 'sha256': sha, 'previous_sha256': entry['sha256'],
                    'same_previous': sha == entry['sha256'],
                    'live_sha256': hashlib.sha256(deployed).hexdigest(), 'same_live': current == deployed})
commits = []
for entry in old['commits']:
    commit = entry['commit']
    commits.append({'commit': commit, 'subject': entry['subject'],
                    'base_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
                    'live_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, live]).returncode == 0})
for name, before, after in [('source-live.patch', base, live), ('source-since-previous.patch', old['base'], base)]:
    (HERE / name).write_bytes(git('diff', '--binary', before, after, '--', *paths))
output = {'base': base, 'live_snapshot': live, 'previous_audit': str(old_path),
          'previous_audit_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
          'paths': records, 'commits': commits,
          'preparation_error': '首稿将旧paths键误写为files，KeyError后未生成源码结论；本脚本按实际schema重新核验。'}
(HERE / 'source-audit.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'paths': len(records), 'same_previous': sum(v['same_previous'] for v in records),
                  'same_live': sum(v['same_live'] for v in records), 'commits': len(commits),
                  'all_ancestors': all(v['base_ancestor'] and v['live_ancestor'] for v in commits)}, ensure_ascii=False))

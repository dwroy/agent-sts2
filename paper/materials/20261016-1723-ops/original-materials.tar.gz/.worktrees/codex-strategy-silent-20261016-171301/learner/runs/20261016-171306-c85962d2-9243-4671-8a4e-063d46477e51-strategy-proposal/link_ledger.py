import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
import ledger

history = json.loads((HERE / 'assigned-proposals-history.json').read_text())
results = json.loads((HERE / 'dispositions.json').read_text())
linked = {}
for result in results:
    original = history[result['id']][0]
    for item in original['ledger']:
        linked.setdefault(item, []).append(result)
before_all = ledger.fold()
before = {key: before_all[key] for key in sorted(linked)}
assert len(before) == 31 and all(item['character'] == 'silent' for item in before.values())
(HERE / 'ledger-immediate-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for id, associated in sorted(linked.items()):
    updates.append({'id': id, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md')], 'changelog': [str(HERE / 'report.md')]},
                    'note': '20261016-171301-strategy-proposal逐项复核；' + '；'.join(
                        result['id'] + '=waiting：' + result['reason'] for result in associated) +
                    '。本批只追加追溯，保留旧claim/首证/prior/evidence/status/version，不新增support、不标shipped。'})
encoded = ''.join(json.dumps(update, ensure_ascii=False) + '\n' for update in updates).encode()
(HERE / 'ledger-updates.jsonl').write_bytes(encoded)
source = ROOT / 'paper/materials/learning/ledger.jsonl'
prefix = source.read_bytes()
prefix_receipt = {'source': str(source), 'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest()}
(HERE / 'ledger-prefix-before.json').write_text(json.dumps(prefix_receipt, ensure_ascii=False, indent=2) + '\n')
completed = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], input=encoded, capture_output=True)
(HERE / 'ledger-cli.stdout.txt').write_bytes(completed.stdout)
(HERE / 'ledger-cli.stderr.txt').write_bytes(completed.stderr)
assert completed.returncode == 0, completed.stderr.decode()
after_bytes = source.read_bytes()
assert after_bytes[:len(prefix)] == prefix
rows = []
offset = len(prefix)
for line in after_bytes[offset:].splitlines(keepends=True):
    row = json.loads(line)
    if row.get('by') == 'learner:strategy-proposal' and any(str(HERE) in path for path in row.get('where', {}).get('proposal', [])):
        expected = next(update for update in updates if update['id'] == row['id'])
        assert all(row.get(key) == value for key, value in expected.items())
        rows.append({'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert sorted(row['row']['id'] for row in rows) == sorted(linked)
after_all = ledger.fold()
protected = ['claim', 'character', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at']
for key, item in before.items():
    assert all(item.get(field) == after_all[key].get(field) for field in protected), key
    for field, values in item.get('where', {}).items():
        assert after_all[key].get('where', {}).get(field, [])[:len(values)] == values
receipt = {'exit_code': completed.returncode, 'updates': len(rows), 'protected_fields': protected,
           'old_prefix_unchanged': True, 'protected_fields_unchanged': True,
           'source': str(source), 'prefix': prefix_receipt, 'rows': rows,
           'stdout_sha256': hashlib.sha256(completed.stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(completed.stderr).hexdigest(),
           'input_sha256': hashlib.sha256(encoded).hexdigest()}
(HERE / 'ledger-update-audit.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': completed.returncode, 'updates': len(rows), 'old_prefix_unchanged': True,
                  'protected_fields_unchanged': True}, ensure_ascii=False))

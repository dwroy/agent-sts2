# 过程限制与原失败保留

- 初次定向命令在 agent/ 中用 $PWD 拼 TMPDIR，指到不存在的 agent/learner/runs 路径；重定向失败，vitest 未启动。之后使用题面绝对scratch，原命令/错误在本批原native和launcher日志保留。
- 共用证据提取尚未完成时，首次端点采集读到空的states输出并在不存在的decisions输出报FileNotFoundError。提取随后正常完成，逐行offset/bytes/SHA/角色/JSON读回2481行；早先失败不当原日志缺失。
- 初次宽范围rg命中历史公共测试fixture的巨大单行输出，未将其作为本批机制/数值/结论输入；后续检索限源码和本角色固定材料。实现与证据来自本批Silent原帧。
- 带status=proposed的20行账本追加被CLI整体拒绝：silent-0295 physical/committed status divergence，nothing written。原JSONL/stdout/stderr保留；随后仅where/note追加20行成功，20条claim/evidence/first_run/prior/status/version/asc读回未变。不自行协调旧发布历史。
- 第一轮13项定向：撤源码3失败/10过，恢复13过。补齐随机边界/候选保留后，最终14项定向：撤源码4失败/10过，恢复14过。原日志全部保留。
- sandbox-first在最后两处边界和测试冻结之前启动，并与源码撤回核验窗口重叠，只保留其过程结果，不作为最终源码全量证明。sandbox-final在六文件清单冻结且源码恢复后启动，验收时须核六SHA不变。
- 原生会话01a13e31-8390-7f40-a86c-41f83a36f11a确认为gpt-6.1-sol/xhigh；launcher service_tier=default。题面high与宿主实启xhigh不同，未自行改模型、线程、账号或改写旧记录，也不冒称已切high。
- 64种分配是一个固定盘的模型分支，不是64实盘样本或实盘概率；24项材料断言也不是生产测试。两源局同场SL不当独立样本；替代留药、路线与终局权重反事实仍未知。

- sandbox-first最终exit1：430文件通过，新增随机续步中断测试1项失败（4053过）；该轮启动于14:24，跨后续源码/测试修改与撤回窗口，不作为最终冻结源码证明。最终六SHA冻结轮431文件4054项及paths11均exit0，保留两轮各自日志，不改旧结果。

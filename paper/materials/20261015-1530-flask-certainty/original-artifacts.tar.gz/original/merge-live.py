import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
SCRATCH = Path(__file__).resolve().parent
SOURCE = '0bf701b583e905fcde2bc6d9b5ec1bc0d1131332'
EXPECTED = {item['path'] for item in json.loads((SCRATCH / 'final-source-manifest.json').read_text())}
result = {'source_commit': SOURCE, 'lock_acquired': True, 'actual_merge': None,
          'refresh_commit': None, 'live_checks': []}


def git(*args):
    return subprocess.run(['git', '-C', str(LIVE), *args], text=True, capture_output=True)


def record(stage):
    result['stage'] = stage
    result['recorded_at'] = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
    (SCRATCH / 'merge-live-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'stage': stage, 'live': result.get('actual_merge'), 'at': result['recorded_at']}, ensure_ascii=False), flush=True)


record('lock_acquired')
subprocess.run(['bash', '-c', "while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done"], check=True)
staged = git('diff', '--cached', '--name-only').stdout.splitlines()
if any(path != 'notes/fight-value-backtest.md' and not path.startswith('knowledge/') for path in staged):
    result['staged_paths'] = staged
    record('blocked_existing_staged_paths')
    raise SystemExit(1)
refresh = git('status', '--porcelain', '--', 'notes/fight-value-backtest.md', 'knowledge').stdout
if refresh or staged:
    added = git('add', 'notes/fight-value-backtest.md', 'knowledge')
    if added.returncode:
        result['refresh_error'] = added.stderr
        record('blocked_refresh_add')
        raise SystemExit(1)
    with (SCRATCH / 'live-refresh-gitleaks.log').open('w') as log:
        checked = subprocess.run(['gitleaks', 'protect', '--staged', '--redact', '--no-banner',
                                  '--report-format', 'json', '--report-path', str(SCRATCH / 'live-refresh-gitleaks.json')],
                                 cwd=LIVE, stdout=log, stderr=subprocess.STDOUT)
    if checked.returncode:
        record('blocked_refresh_secret_scan')
        raise SystemExit(1)
    if git('diff', '--cached', '--quiet').returncode:
        subprocess.check_call(['date', '-Iseconds'])
        committed = git('commit', '-m', 'Refresh knowledge data', '-m',
                        'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>')
        (SCRATCH / 'live-refresh-commit.log').write_text(committed.stdout + committed.stderr)
        if committed.returncode:
            record('blocked_refresh_commit')
            raise SystemExit(1)
        result['refresh_commit'] = git('rev-parse', 'HEAD').stdout.strip()

before = git('rev-parse', 'HEAD').stdout.strip()
result['live_before'] = before
result['dirty_before'] = git('status', '--short').stdout.splitlines()
preflight = git('merge-tree', '--write-tree', '--messages', before, SOURCE)
(SCRATCH / 'locked-merge-tree.out').write_text(preflight.stdout)
(SCRATCH / 'locked-merge-tree.err').write_text(preflight.stderr)
result['preflight_exit'] = preflight.returncode
if preflight.returncode:
    result['conflicts'] = [line for line in preflight.stdout.splitlines() if line.startswith('CONFLICT')]
    record('blocked_merge_conflict')
    raise SystemExit(1)
tree = preflight.stdout.splitlines()[0]
paths = git('diff', '--name-only', before, tree).stdout.splitlines()
result['candidate_paths'] = paths
if set(paths) - EXPECTED:
    record('blocked_unrelated_base_changes')
    raise SystemExit(1)
dirty = set(git('diff', '--name-only').stdout.splitlines())
if dirty.intersection(paths):
    result['dirty_overlap'] = sorted(dirty.intersection(paths))
    record('blocked_dirty_overlap')
    raise SystemExit(1)

if git('merge-base', '--is-ancestor', SOURCE, 'HEAD').returncode:
    subprocess.check_call(['date', '-Iseconds'])
    merged = git('merge', '--no-edit', '-m',
                 "Merge observed Silent Flask certainty fix into live\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>", SOURCE)
    (SCRATCH / 'live-merge.log').write_text(merged.stdout + merged.stderr)
    if merged.returncode:
        if git('rev-parse', '--verify', 'MERGE_HEAD').returncode == 0:
            aborted = git('merge', '--abort')
            (SCRATCH / 'live-merge-abort.log').write_text(aborted.stdout + aborted.stderr)
        record('blocked_actual_merge')
        raise SystemExit(1)
result['actual_merge'] = git('rev-parse', 'HEAD').stdout.strip()
result['merged_tree'] = git('rev-parse', 'HEAD^{tree}').stdout.strip()
record('merged_testing')
test_env = dict(os.environ, TMPDIR=str(SCRATCH), SANDBOX_WORKERS='4', npm_config_offline='true', PYTHONDONTWRITEBYTECODE='1')
test_env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + test_env.get('PATH', '')
for attempt in range(2):
    log_path = SCRATCH / ('live-sandbox-first.log' if attempt == 0 else 'live-sandbox-retry.log')
    with log_path.open('wb') as log:
        tested = subprocess.run(['bash', 'tools/test-sandbox.sh', '--reporter=verbose'],
                                cwd=LIVE / 'agent', env=test_env, stdout=log, stderr=subprocess.STDOUT)
    result['live_checks'].append({'attempt': attempt + 1, 'exit': tested.returncode, 'log': str(log_path)})
    if tested.returncode == 0:
        break
    if attempt == 0 and re.search(r'(Test|Hook) timed out in', log_path.read_text()):
        record('retry_timeout_once')
        continue
    rolled_back = git('reset', '--merge', before)
    (SCRATCH / 'live-rollback.log').write_text(rolled_back.stdout + rolled_back.stderr)
    result['rollback_exit'] = rolled_back.returncode
    result['live_after'] = git('rev-parse', 'HEAD').stdout.strip()
    record('live_checks_failed_rollback')
    raise SystemExit(1)
result['live_after'] = git('rev-parse', 'HEAD').stdout.strip()
result['source_is_live_ancestor'] = git('merge-base', '--is-ancestor', SOURCE, 'HEAD').returncode == 0
result['dirty_after'] = git('status', '--short').stdout.splitlines()
record('live_checks_passed')

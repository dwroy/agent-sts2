# 静默猎手策略实现与live交付报告

本批10项已逐项处理：2项共享同一限定源码修复，已实际合入live并通过组合自测；其余8项waiting，具体缺口逐项保留。正式发布号待ops按实际live祖先统一核定，未代标账本shipped、未代填watcher/Roy确认，未声称自然局已消费或胜率改善。

- task/character/batch：strategy-proposal / silent / 20261015-141302-strategy-proposal。
- 原基线：`e3ffc2301d9eb25a0fedf874d56710b938dc41a3`；开工干净，初次merge main为Already up to date。普通领取10项，无专题/implementation绑定，不合并其他专题范围。
- 源码：`0bf701b583e905fcde2bc6d9b5ec1bc0d1131332`（父提交即上述基线）；源码工作树仍干净。
- 实际live合入：`8c1935b9c672c5e9fdd676371e16988a8f0bc714`；前置live `d488d29a09677776a6e7b419156e2fad17b70aa3`；精确受检组合树 `7e9b21378fb803dec3bf586d1f6e9be20b160008`。
- 上线记录提交：`534c3140f2e3a98fcd6380ce4447b00592cba026`。该提交不改agent源码，旧版本行/顺序/编号映射逐项读回不变；仅追加本次内部版本条目。正式release_id目前null，由ops登记，不另造号。
- 提案总稿：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-141302/learner/runs/20261015-141310-fb218adb-2faf-4bc0-a8aa-4ac943287bbb-strategy-proposal/proposal.md；机器回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-141302/learner/runs/20261015-141310-fb218adb-2faf-4bc0-a8aa-4ac943287bbb-strategy-proposal/final-report.json。

## 证据与结论

两锚点在runs.jsonl第610/611行均为SILENT A10：G8NHLL09DLBX F24败、LYBHQ1X230ZB F30败。共用入口冻结8流，按offset/bytes/SHA、JSON及身份逐行读回2481条：状态1225、决策1181、SL11、配置2、计划7、脑请求53、runs2；fight-plans在所选截点0行仅说明该截点未选到。状态全部显式silent。原10篇Markdown逐SHA核同并留副本，原20条相关账本只CLI追加追溯，未增加证据计数或改写claim/first_run/prior/status/version。24项原材料断言通过，材料断言不冒作生产测试。

G8NHLL09DLBX F24末试T5，s297418为玩家1HP/0挡/2费，母体29血20毒；药瓶实际在s297419给三幼虫各3毒，母体不变；s297420母体结毒后仍9、玩家0。旧模型会将9毒全给最高血母体并判赢，直接违反这一实盘反例。固定同帧64种三次分配仅一模型分支结束战斗，64不是独立实盘样本，也不据此给实际命中概率。账本silent-0295/0007，原提案982c99080350f43e与eb6e17529c0f8cde。

新规则仅在silent A10、普通未附魔已见2费3毒×3预览、手动单次且实际支付2费、多敌时生效：随机新增毒不预支到任何敌人，保留合法条件参考候选，明确损血/击杀/存活非保证；在真实落点前暂停续牌，不自动确定斩杀，也不因未计毒的死亡参考删除药瓶候选或引出新的必死保证。沿用原随机性SL否决，不改变药水持有价、路线血线、SL阈值或终局权重；单敌与其他角色/进阶、未观察升级/费用变体/重放/自动施放保持旧模型。未计新增毒是条件参考，不是对全部阶段交互的最坏界。

LYBHQ1X230ZB F29T6 d290765实际选择损18/伤31、8/8模型候选并实损18；另一损12/伤22、7/8模型候选未执行接续。F29实到4HP，F30四试未赢，前三试截断未结毒。不能用少6血反事实拟合终局权重或断言可救本局。其他八项保留完整缺数据理由。

## 自测、反转与交付

| 检查 | 实际结果 |
|---|---|
| 最终固定回归 | 14项过；实际planner题面、离线resolve合法意图、随机边界停止续步、单敌/其他角色进阶/未观察预览、64模型分支、SL原机会否决 |
| 最终撤源码 | 4失败、10通过，exit1；四个源码恢复后14通过、exit0 |
| 源分支沙箱 | 生产tsc0；主suite431文件4054项，paths另1文件11项；合432文件4065项，退出0 |
| 实际live组合沙箱 | 生产tsc0；主suite431文件4067项，paths另1文件11项；合432文件4078项，退出0，无重试 |
| 秘密扫描 | 暂存源码及上线记录均gitleaks0，使用redact；未推送、未运行play、未读key/.env/游戏二进制、未安装依赖 |
| 真实交付读回 | source与merge均为实际live祖先；记录提交未改agent源码；原两份未提交知识报告保留 |

实际planner测试使用冻结最小卡牌cache、空monster-db并关闭rollout/boss-lines以隔离本项，不称线上完整dirty输入逐字重放，也不称离线resolve为真实游戏执行。原运行只保存源提交和知识dirty清单，完整dirty知识快照不足；自然局实际消费者仍待ops接续。

最早13项反转（撤源码3失败/恢复13过）保留。第一轮全套启动过早，跨后续边界/测试修改与源码撤回窗口，最终430文件4053项过、新增续步中断1项失败；原件保留，不用它证明最终源码。随后六文件SHA冻结轮及实际live组合均全过。首次账本status追加因物理/已提交状态分歧整体拒绝且未写入，改仅where/note后成功；不自行协调旧发布历史。上线note曾将含paths的总文件数432写在主suite前，已CLI追加精确分母勘误，旧行保留。详见operational-failures.md。

首次发布锁20秒等待exit75，未更改live；只读预检退出0、仅6文件。次轮等待于15:07:09取得原锁，15:07:11合入并持锁完成组合检查，15:16:12退出0；没有知识刷新数据需提交，不重建未修改的生成器。源提交、合入及记录均使用全局身份并带实际Codex gpt-6.1-sol署名。原生会话模型/effort已核为gpt-6.1-sol/xhigh；题面high与宿主实际xhigh不同，launcher普通default，未自行切线程/账号或改写旧记录。

## 十项处置

| 提案 | 账本 | 状态 | 证据与理由 |
|---|---|---|---|
| silent-proposal-982c99080350f43e | silent-0295 | implemented | G8NHLL09DLBX F24末试T5；states 297416–297420，decisions 290345–290348；同一限定修复已实际合入live；静默A10已见普通2费3毒×3的手动多敌窗口不再预支随机落点保证斩杀，保留条件参考并在真实施毒后重规划。单敌及未观察预览/升级/重放/其他角色进阶保旧；实际live祖先与组合自测均已核。 |
| silent-proposal-aaefd918a706de14 | silent-0019, silent-0017, silent-0005, silent-0046, silent-0253, silent-0007, silent-0021 | waiting | G8NHLL09DLBX F17四试T1–T21、F23T2、F24两试；F23先受荆棘5、速度后9挡再受16，速度次轮撤回；F17本体后仍有自爆，SL恢复单列。当前只有逐段事实及局部模型，缺临时属性/阶段/SL资源的完整同帧组合验证与保药替代整战结果；随机毒修复不关闭此宽项。 |
| silent-proposal-eb6e17529c0f8cde | silent-0007, silent-0295 | implemented | G8NHLL09DLBX F24末试T5；states 297418→297419→297420；同一限定修复已实际合入live；静默A10已见普通2费3毒×3的手动多敌窗口不再预支随机落点保证斩杀，保留条件参考并在真实施毒后重规划。单敌及未观察预览/升级/重放/其他角色进阶保旧；实际live祖先与组合自测均已核。 |
| silent-proposal-10c5c87568dcded1 | silent-0012, silent-0005, silent-0046, silent-0253 | waiting | G8NHLL09DLBX F23T2→T3、F24首试T1→T2及末试T3→T4；已有步法、临时敏捷、减力、弱化自爆及荆棘局部处理，原帧支持17挡、23→2来袭和速度撤回；未完成五机制组合及速度/尖啸跨轮的完整消费者校准，不把局部源码存在登记为整项duplicate。 |
| silent-proposal-72e211c844b4564e | silent-0017 | waiting | G8NHLL09DLBX F17四试，末试T14→T15；本体8毒结算后仍需56自爆，弱化为42、9挡、34→1；前三次判死前截断，没有其末次结算。当前阶段处理存在，但缺完整阶段/SL配对与替代换线整场轨迹，不能拟合SL成功率或把本体死当胜。 |
| silent-proposal-1481fe327a22ddeb | silent-0243, silent-0020, silent-0019, silent-0021 | waiting | G8NHLL09DLBX F17→18、F19→20→22→23→24；F23确实52→22并消耗火焰/速度，F24以22空药入场；无保药、改路线或后置营火实到对照，不能标定持有价值/安全血线。独立取得、SL恢复和治疗继续分账。 |
| silent-proposal-8e9beeee55eac364 | silent-0019, silent-0039, silent-0005, silent-0013, silent-0077, silent-0196, silent-0128, silent-0049, silent-0232, silent-0115, silent-0007, silent-0142 | waiting | LYBHQ1X230ZB F29T6，decision 290765；states 297854–297864及F30；plan2预测损18/伤31、8/8，实际损18且T7赢；plan1损12/伤22、7/8未执行。缺该保6血候选到F30的真实接续及时间留出，不能由单次比较重估终局血权重或药水规则。 |
| silent-proposal-ce75cb821e8f2610 | silent-0012, silent-0005, silent-0013, silent-0077, silent-0049, silent-0232 | waiting | LYBHQ1X230ZB F22T2/T5、F29T1/T3、F30T1/T2；已见臂甲首挡16、步法+与暗影两防御32、柔嫩逐牌变化；当前对应处理存在，但未完成全修正组合、首次消费与次轮复原的固定消费者回放；未知叠加/自动出牌不补公式。 |
| silent-proposal-6ba977a3f01df016 | silent-0039, silent-0115, silent-0007 | waiting | LYBHQ1X230ZB F23T1、F30四试T1/T2；爆发迷雾+两次各6毒、活体召唤21HP及28→20攻、末试6+9毒后仍15/87。前三试截断未结毒；缺替代目标序/抽序完整执行及当前召唤/重放/SL整线对照，不修改必死门槛。 |
| silent-proposal-2097f02b69dacfff | silent-0128, silent-0196 | waiting | LYBHQ1X230ZB F29T1→T2、T3→T4、T3–T6；16挡完整吸石虫16后T2眩晕，32挡盖29后T4再眩晕；甲虫醒后力量2/4/6、弱后15/16/18，末次实损18。源码已有自身完整格挡眩晕及逐轮推进，但缺该双敌盘成长/弱化/眩晕接续的完整当前固定回放与校准；不据局部存在冒报整个提案duplicate，也不设固定目标序。 |

## 通知、回退与接续

实际规则变更已先date，再在根目录notes/for-roy.md与ops/inbox-dev.md双写旧规则、新规则、证据/账本/任务、影响及回退；根目录和live的decision-log均追加一行，eval两个检出保留旧值仅追加本次条目。双写只表示通知已落盘，未声称watcher/Roy已读。正式编号交ops持原锁核实际live祖先后登记，账本shipped也由ops核实。

回退只逆向source `0bf701b583e905fcde2bc6d9b5ec1bc0d1131332`，或对live合入 `8c1935b9c672c5e9fdd676371e16988a8f0bc714`作首父回退，保留R356等其他发布、刷新、日志和历史记录；实际回退另由ops登记新编号。当前无回退、无停止/重启对局。

自然消费者、无排除宿主全套、宽量化/学习父要求和八项waiting均未关闭；本次没有新增经验JSON或冒称大脑已采用，后续入库/消费者读回沿原调度器。

import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
SCRATCH = Path(__file__).resolve().parent
SOURCE = '0bf701b583e905fcde2bc6d9b5ec1bc0d1131332'
NAME = 'V5.silent-flask-certainty1'
run = json.loads((SCRATCH / 'merge-live-result.json').read_text())
assert run['stage'] == 'live_checks_passed'
MERGED = run['actual_merge']
assert subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', SOURCE, 'HEAD']).returncode == 0
assert subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', MERGED, 'HEAD']).returncode == 0
now = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()


def append(path, content):
    with path.open('a', encoding='utf8') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        handle.write(content)
        handle.flush()


release_id = None
version_paths = [LIVE / 'eval/versions.json', ROOT / 'eval/versions.json']
for path in version_paths:
    data = json.loads(path.read_text())
    for item in data['versions']:
        if item.get('commit') == MERGED and item.get('release_id'):
            release_id = item['release_id']
entry = {'name': NAME, 'family': 'V5', 'character': 'SILENT', 'commit': MERGED,
         'release_id': release_id, 'release_status': 'pending-primary-ops-registration' if release_id is None else 'registered-primary-ops',
         'source': f'{now}; strategy-proposal 20261015-141302-strategy-proposal; source {SOURCE}; '
                   'silent-proposal-982c99080350f43e / silent-proposal-eb6e17529c0f8cde; ledger silent-0295 / silent-0007; '
                   'G8NHLL09DLBX Silent A10 F24末试T5 states297418-297420。仅已见普通未附魔2费3毒×3、手动单次且实际支付2费、多敌窗口：'
                   '不把随机毒全给最高HP目标预支确定斩杀；保留条件参考候选，施毒后真实重规划，不以未计毒的死亡参考移除候选。'
                   '单敌、其他角色/进阶、升级/费用变体/重放/自动施放沿旧模型。未改药水持有价、SL判据、终局权重。'
                   '固定14过，撤源码4失败/恢复14过；源生产tsc0、431文件4054项+paths11，实际live组合沙箱检查0，暂存源码gitleaks0。'
                   '64分配仅固定模型分支，不是实盘概率或胜率收益；自然消费者及无排除宿主全套仍待原调度器。'
                   f'实际live祖先已核，正式release_id由ops持原锁统一分配；材料 {SCRATCH}。回退逆向本源码或首父回退此合入，保留其他发布、刷新及历史记录。'}
for path in version_paths:
    data = json.loads(path.read_text())
    existing = [item for item in data['versions'] if item.get('name') == NAME]
    if existing:
        assert len(existing) == 1 and existing[0].get('commit') == MERGED
    else:
        data['versions'].append(entry)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

decision = (f'\n- {now} 学习者 codex：20261015-141302-strategy-proposal 已将静默A10普通弹跳药瓶随机施毒确定性边界实际合入live '
            f'{MERGED}（source {SOURCE}；两个原提案982c99080350f43e/eb6e17529c0f8cde；账本silent-0295/0007；'
            'G8NHLL09DLBX F24末试T5 s297418–297420）。不预支最高血母体9毒作确定斩杀，保留未计新增毒的条件参考并在真实落点后重规划；'
            '单敌、无关角色/进阶及未观察预览保持，药水/SL阈值/终局权重未改。固定14过、撤源码4失败/恢复14过；'
            '源tsc0/沙箱431文件4054项+paths11、实际live组合沙箱0、gitleaks0；原跨修改窗口1失败及全部初稿保留。'
            f'内部版本条目{NAME}已追加，正式编号待ops按实际祖先核定；未标账本shipped，不声称自然消费者或收益，其他八原提案waiting，宽父要求保持。\n')
for path in [LIVE / 'paper/materials/decision-log.md', ROOT / 'paper/materials/decision-log.md']:
    append(path, decision)

notice = (f'\n### {now} 学习者规则变更已实际合入：静默随机施毒确定性边界\n\n'
          '- 旧规则：多敌弹跳药瓶复用最高HP+挡目标，将三次3毒集中母体并可自动combat/lethal。\n'
          '- 新规则：仅silent A10已见普通未附魔2费3毒×3、手动单次且支付2费的多敌窗口，随机新增毒不预支到任何目标；'
          '保留合法条件参考候选，损血/击杀/存活均非保证，暂停未定落点后的续牌并在真实状态重规划。单敌、其他角色/进阶、升级/费用变体/重放/自动施放保留原模型；药水持有价、SL判据和终局权重未改。\n'
          '- 证据与账本：G8NHLL09DLBX A10 F24末试T5，s297418母体29血20毒，s297419三幼虫各获3毒且母体不变，s297420母体仍9而玩家死；silent-0295/0007。'
          '原提案silent-proposal-982c99080350f43e / silent-proposal-eb6e17529c0f8cde；任务20261015-141302-strategy-proposal。\n'
          f'- 实际提交与验证：source {SOURCE}，live {MERGED}；固定14过/撤源码4失败/恢复14过，源tsc0/431文件4054项+paths11，实际live组合沙箱0，gitleaks0。'
          '原非冻结轮1失败保留；无排除宿主全套交原调度器，正式编号待ops持原锁核实际live祖先分配，账本shipped仍由ops核实。\n'
          '- 预期影响与限制：减少已见伪确定斩杀，未计毒是条件参考而非最坏界；不承诺挽救原局或胜率提升。64分配是同盘模型分支，不是64实盘或实盘概率。自然局实际消费仍待核，不关闭宽量化/学习父要求。\n'
          f'- 回退：逆向source {SOURCE}或对live合入{MERGED}作首父回退，只撤本次六文件差异；保留R356及其他并行发布、刷新、原始证据与历史记录，由ops为实际回退另登记编号。\n'
          f'- 材料：{SCRATCH / "proposal.md"}；{SCRATCH / "report.md"}。双写仅表示已落通知，未代填watcher/Roy确认。\n')
for path in [ROOT / 'notes/for-roy.md', ROOT / 'ops/inbox-dev.md']:
    append(path, notice)

added = subprocess.run(['git', '-C', str(LIVE), 'add', 'eval/versions.json', 'paper/materials/decision-log.md'], capture_output=True, text=True)
assert added.returncode == 0, added.stderr
staged = subprocess.check_output(['git', '-C', str(LIVE), 'diff', '--cached', '--name-only'], text=True).splitlines()
assert set(staged) <= {'eval/versions.json', 'paper/materials/decision-log.md'}, staged
with (SCRATCH / 'gitleaks-publication.log').open('w') as log:
    scanned = subprocess.run(['gitleaks', 'protect', '--staged', '--redact', '--no-banner', '--report-format', 'json',
                              '--report-path', str(SCRATCH / 'gitleaks-publication.json')], cwd=LIVE, stdout=log, stderr=subprocess.STDOUT)
assert scanned.returncode == 0
subprocess.check_call(['date', '-Iseconds'])
committed = subprocess.run(['git', '-C', str(LIVE), 'commit', '-m', 'Record observed Silent Flask certainty publication', '-m',
                            'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'], text=True, capture_output=True)
(SCRATCH / 'publication-commit.log').write_text(committed.stdout + committed.stderr)
assert committed.returncode == 0, committed.stderr
out = {'source_commit': SOURCE, 'merged': MERGED, 'tested_tree': run['merged_tree'],
       'record_commit': subprocess.check_output(['git', '-C', str(LIVE), 'rev-parse', 'HEAD'], text=True).strip(),
       'version_entry': NAME, 'release_id': release_id, 'release_registration': 'pending_ops' if release_id is None else 'registered',
       'dual_notice_written': True, 'notice_acknowledged_by_watcher_or_roy': False, 'gitleaks': 0}
(SCRATCH / 'publication.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(out, ensure_ascii=False, indent=2))

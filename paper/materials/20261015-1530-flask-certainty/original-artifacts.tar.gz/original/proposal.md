# 静默猎手策略提案：随机施毒不能成为确定斩杀

本批：20261015-141302-strategy-proposal。来源任务：已领取10项专用队列提案；实现任务：本批 strategy-proposal。角色 silent，已观察 A10。授权 Roy-2026-10-07-learning 仅是实施权限，不是机制证据。

## 身份和范围

开工 git status 干净，HEAD/base 为 `e3ffc2301d9eb25a0fedf874d56710b938dc41a3`，`git merge --no-edit main` 返回 Already up to date。本批 reason=proposal，明确有10个 proposal_ids，没有 research_request、proposal_repair 或 implementation_request；普通专题身份与本批不符，未承接/读取其他专题工作规格。根队列只折叠这10项，原Markdown逐SHA相等并保存到 original-proposals/，账本只读取其角色条目。两局在 runs.jsonl 第610/611行均为 SILENT A10，不能把同局SL当独立样本。

## 证据和反例

G8NHLL09DLBX F24末试T5：s297418玩家1/76、0挡、2费，母体29/132、20毒；三幼虫12/7/13，其中第二只已有7毒。s297419普通药瓶实际给三幼虫各3毒，母体仍29血20毒；s297420母体结毒后9血，玩家0。d290345–290348此前按combat/lethal执行。旧当前模型将三份毒全部给最高血母体，补至29毒并给 winsFight=true；固定输入删除新标记即可复现。

单个确定分配不能证明随机结果保证。固定同帧列举4^3=64种三次分配，仅全落母体这一种在现有局部模型中结束战斗。64是同盘模型分支数，不是独立实盘样本，不报告1/64实盘概率。真实三幼虫各3是直接反例。源局运行源码只记录提交及知识dirty清单，未保存完整dirty知识快照，本批核对的是固定帧与当前源码，不冒称复现历史完整运行树。

## 旧规则、新行为与实现

旧行为：施毒复用随机直伤的最高HP+挡目标，三次可集中于母体；模型可自动执行combat/lethal。新行为：仅 silent A10、普通未附魔、已见2费/3毒×3预览、手动单次、实际支付2费且存活敌人数大于1时，不提前给任何目标加这9毒。保留合法药瓶候选并明确“未计新增毒、损血/击杀/存活非保证”；暂停该随机边界后的续牌，等待真实后继帧。携带未定标记的线路不能成为确定获胜，不能被结果合并或死亡过滤吞掉；普通自动选线改为Jev选择，数值只作条件参考。

当前回合 describePlan 与 rollout T1 文本均携带条件参考；SL沿用现有随机卡机会否决，不修改SL门槛或药水/终局参数。未展开完整随机分布和阶段/制品/重放组合，不把“未计新增毒”称为最坏界；这不是拟合概率或新的蒙特卡洛系统。其他角色、未观察进阶/预览、升级/重放/自动施放与单敌路径保持旧行为。

源码：agent/src/reflex/card-model.ts、turn-solver.ts、combat-plan.ts、rollout-live.ts。固定材料：agent/tests/silent-random-poison-evidence.json；验证：agent/tests/silent-random-poison.test.ts。没有知识库数据或生成器改动。

## 拟合、验证与限制

一局直接反例用于修正确定性声明，不拟合策略权重；LYB另一局用于独立资源审计，不充当药瓶留出胜局。固定测试包含原反例、64分支核对、真实planner题面及离线resolve合法派发、随机边界后停止续牌、单敌对照、SL现有机会否决、其他角色/进阶和未观察预览。撤掉四个源码改动后测试必须失败，恢复后通过。完整沙箱检查、秘密扫描、提交和live状态以 report.md 实际回执为准。

可能减少错误自动斩杀，但本局其他可选线是否能救活未知，不承诺胜率改善。未模拟的随机毒会使参考数值偏低；文字明确条件性，实际结算后重规划。未知修正组合仍等新证据，不以本次代码关闭宽量化或消费父要求。回退只逆向本批独立源码提交，保留日志、学习材料和刷新知识。

## 十项逐项处理

### silent-proposal-982c99080350f43e

账本：silent-0295。

证据：G8NHLL09DLBX F24末试T5；states 297416–297420，decisions 290345–290348。

处置：与 eb6e17529c0f8cde 共用本批限定修复：把未展开随机毒保留为条件参考，停止未定落点后的续步，不再自动确定斩杀。完成状态以实际 live 祖先为准。

### silent-proposal-aaefd918a706de14

账本：silent-0019, silent-0017, silent-0005, silent-0046, silent-0253, silent-0007, silent-0021。

证据：G8NHLL09DLBX F17四试T1–T21、F23T2、F24两试。

处置：waiting：F23先受荆棘5、速度后9挡再受16，速度次轮撤回；F17本体后仍有自爆，SL恢复单列。当前只有逐段事实及局部模型，缺临时属性/阶段/SL资源的完整同帧组合验证与保药替代整战结果；随机毒修复不关闭此宽项。

### silent-proposal-eb6e17529c0f8cde

账本：silent-0007, silent-0295。

证据：G8NHLL09DLBX F24末试T5；states 297418→297419→297420。

处置：与 982c99080350f43e 共用本批限定修复。仅普通、已观察预览、A10、手动单次、支付2费、多敌；升级、重放、自动施放及其他角色/进阶保留原模型。

### silent-proposal-10c5c87568dcded1

账本：silent-0012, silent-0005, silent-0046, silent-0253。

证据：G8NHLL09DLBX F23T2→T3、F24首试T1→T2及末试T3→T4。

处置：waiting：已有步法、临时敏捷、减力、弱化自爆及荆棘局部处理，原帧支持17挡、23→2来袭和速度撤回；未完成五机制组合及速度/尖啸跨轮的完整消费者校准，不把局部源码存在登记为整项duplicate。

### silent-proposal-72e211c844b4564e

账本：silent-0017。

证据：G8NHLL09DLBX F17四试，末试T14→T15。

处置：waiting：本体8毒结算后仍需56自爆，弱化为42、9挡、34→1；前三次判死前截断，没有其末次结算。当前阶段处理存在，但缺完整阶段/SL配对与替代换线整场轨迹，不能拟合SL成功率或把本体死当胜。

### silent-proposal-1481fe327a22ddeb

账本：silent-0243, silent-0020, silent-0019, silent-0021。

证据：G8NHLL09DLBX F17→18、F19→20→22→23→24。

处置：waiting：F23确实52→22并消耗火焰/速度，F24以22空药入场；无保药、改路线或后置营火实到对照，不能标定持有价值/安全血线。独立取得、SL恢复和治疗继续分账。

### silent-proposal-8e9beeee55eac364

账本：silent-0019, silent-0039, silent-0005, silent-0013, silent-0077, silent-0196, silent-0128, silent-0049, silent-0232, silent-0115, silent-0007, silent-0142。

证据：LYBHQ1X230ZB F29T6，decision 290765；states 297854–297864及F30。

处置：waiting：plan2预测损18/伤31、8/8，实际损18且T7赢；plan1损12/伤22、7/8未执行。缺该保6血候选到F30的真实接续及时间留出，不能由单次比较重估终局血权重或药水规则。

### silent-proposal-ce75cb821e8f2610

账本：silent-0012, silent-0005, silent-0013, silent-0077, silent-0049, silent-0232。

证据：LYBHQ1X230ZB F22T2/T5、F29T1/T3、F30T1/T2。

处置：waiting：已见臂甲首挡16、步法+与暗影两防御32、柔嫩逐牌变化；当前对应处理存在，但未完成全修正组合、首次消费与次轮复原的固定消费者回放；未知叠加/自动出牌不补公式。

### silent-proposal-6ba977a3f01df016

账本：silent-0039, silent-0115, silent-0007。

证据：LYBHQ1X230ZB F23T1、F30四试T1/T2。

处置：waiting：爆发迷雾+两次各6毒、活体召唤21HP及28→20攻、末试6+9毒后仍15/87。前三试截断未结毒；缺替代目标序/抽序完整执行及当前召唤/重放/SL整线对照，不修改必死门槛。

### silent-proposal-2097f02b69dacfff

账本：silent-0128, silent-0196。

证据：LYBHQ1X230ZB F29T1→T2、T3→T4、T3–T6。

处置：waiting：16挡完整吸石虫16后T2眩晕，32挡盖29后T4再眩晕；甲虫醒后力量2/4/6、弱后15/16/18，末次实损18。源码已有自身完整格挡眩晕及逐轮推进，但缺该双敌盘成长/弱化/眩晕接续的完整当前固定回放与校准；不据局部存在冒报整个提案duplicate，也不设固定目标序。


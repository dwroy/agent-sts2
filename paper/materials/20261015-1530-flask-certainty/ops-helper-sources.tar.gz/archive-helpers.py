from pathlib import Path
import tarfile,json,hashlib
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1530';pub=r/'paper/materials/20261015-1530-flask-certainty';files=list(p.glob('*.py'))+[r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py'];rows=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tf:
 for f in files:
  raw=f.read_bytes();d=p/'helper-scan'/f.name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw);tf.add(f,arcname=f.name);rows.append({'source':str(f.relative_to(r)),'archive':f.name,'sha256':hashlib.sha256(raw).hexdigest()})
(pub/'ops-helper-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')

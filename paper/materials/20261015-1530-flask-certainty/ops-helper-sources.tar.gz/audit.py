from pathlib import Path
import subprocess,json,re,hashlib,sys,importlib.util,tarfile,collections,os
root=Path.cwd();private=root/'ops/codex-ops/record-staging/20261015-1530';pub=root/'paper/materials/20261015-1530-flask-certainty';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
exec((root/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
bid='20261015-141302-strategy-proposal';out=(root/'ops/codex-ops/learner'/f'{bid}.out').read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);s=Path(report['report']).parent;b=json.loads((root/'ops/codex-ops/learn.json').read_text())['batches'][bid];native=runtime(bid,report,out,b['worktree']);source=report['fixes'][0]['commit'];assert source=='0bf701b583e905fcde2bc6d9b5ec1bc0d1131332' and report['merged']=='8c1935b9c672c5e9fdd676371e16988a8f0bc714';assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['merged']==report['merged'];assert git('-C',b['worktree'],'rev-parse','HEAD').decode().strip()==source and not git('-C',b['worktree'],'status','--porcelain','--untracked-files=all').strip()
paths=json.loads((s/'final-source-manifest.json').read_text());assert len(paths)==6
for row in paths:assert sha(git('show',source+':'+row['path']))==row['sha256']==sha((Path(b['worktree'])/row['path']).read_bytes())
final=json.loads((s/'verification-final.json').read_text());assert final['tsc']==final['vitest']==final['gitleaks']==0 and final['targeted_tests']==final['restored_passed_tests']==14 and final['withdrawn_failed_tests']==4
for name,expected in [('sandbox-final.log',[(431,4054),(1,11)]),('live-sandbox-first.log',[(431,4067),(1,11)])]:
 plain=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(s/name).read_text());assert all(f'Test Files  {a} passed ({a})' in plain and f'Tests  {z} passed ({z})' in plain for a,z in expected)
assert (s/'sandbox-final.exit').read_text().strip()=='0';negative=json.loads((s/'reversal-final-results.json').read_text());assert negative['without_source']==1 and negative['restored']==0
for f in ['gitleaks-source.json','gitleaks-publication.json']:assert json.loads((s/f).read_text())==[]
for row in json.loads((s/'proposal-integrity.json').read_text()):assert sha(Path(row['path']).read_bytes())==row['sha256']
rawrefs=[];identities={};total=0
for m in json.loads((s/'evidence/evidence-manifest.json').read_text()):
 f=s/'evidence'/f"{m['stream']}.evidence.jsonl";count=0;by=collections.Counter();digest=hashlib.sha256()
 with (root/'logs'/f"{m['stream']}.jsonl").open('rb') as sourcefile,f.open('rb') as frozen:
  for line in frozen:
   digest.update(line);e=json.loads(line);assert e['offset']+e['bytes']<=m['source_size'];sourcefile.seek(e['offset']);raw=sourcefile.read(e['bytes']);row=json.loads(raw);assert sha(raw)==e['sha256'] and row==e['row']
   if m['stream']=='states':assert row['state']['run']['character_id']=='SILENT' and row['state']['run']['ascension']==10;identities[e['run_id']]=10
   count+=1;by[e['run_id']]+=1
 assert digest.hexdigest()==m['output_sha256'] and count==sum(m['counts'].values());total+=count;rawrefs.append({'stream':m['stream'],'rows':count,'source_size':m['source_size'],'frozen_sha256':digest.hexdigest(),'by_run':dict(by),'invalid_lines':m['invalid_lines']})
assert total==2481 and set(identities)==set(report['runs'])
physical=(root/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True);payloads=[]
for name in ['ledger-update-links-only.jsonl','ledger-source-commit.jsonl','ledger-live-publication.jsonl','ledger-check-count-clarification.jsonl']:payloads += [json.loads(x) for x in (s/name).read_text().splitlines() if x]
owned=[]
for payload in payloads:
 assert set(payload)<=set(['id','by','where','note']);matches=[x for x in physical if all(json.loads(x).get(k)==v for k,v in payload.items())];assert len(matches)==1,(payload['id'],len(matches));owned.append(matches[0])
assert len(owned)==26 and len(set(owned))==26;order={raw:i for i,raw in enumerate(physical)};owned.sort(key=lambda raw:order[raw]);(private/'original-owned-ledger.jsonl').write_bytes(b''.join(owned))
artifacts=[(f,'original/'+f.name) for f in s.iterdir() if f.is_file() and f.stat().st_size<1000000 and '.before.' not in f.name and '.after.' not in f.name and not f.name.startswith('jev-sts2-settle-')];artifacts.append((s/'evidence/evidence-manifest.json','original/evidence/evidence-manifest.json'))
for ext in ['out','err']:
 f=root/'ops/codex-ops/learner'/f'{bid}.{ext}'
 if f.exists():artifacts.append((f,'outputs/'+f.name))
rows=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tf:
 for f,name in artifacts:
  raw=f.read_bytes();dest=private/'archive-scan'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tf.add(f,arcname=name);rows.append({'source':str(f.relative_to(root)),'archive':name,'bytes':len(raw),'sha256':sha(raw)})
with tarfile.open(pub/'original-artifacts.tar.gz','r:gz') as tf:
 for row in rows:assert sha(tf.extractfile(row['archive']).read())==row['sha256']
(pub/'original-artifact-manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');receipt={'batch':bid,'original_report':report,'native':native,'canonical_state_preserved':{k:b.get(k) for k in ['state','rc','merged','proposal_audit_errors']},'source':source,'parent':git('rev-parse',source+'^').decode().strip(),'source_paths':paths,'source_checks':final,'live_sandbox_cases':4078,'raw_rows_verified':total,'state_identities':identities,'raw_streams':rawrefs,'original_cli_rows':26,'no_original_claim_evidence_first_run_prior_status_version_changes':True,'old_physical_0295_proposed_vs_committed_shipped_divergence':'preserved, not reconciled by adopting successful where/note-only updates','two_narrow_implemented_eight_waiting':True,'original_failed_checks_and_rejected_status_request_preserved':True,'natural_consumer':'pending, not provided by fixed tests','new_learning_or_model_experiment':False};(pub/'batch-readback.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':2481,'owned_cli':26,'source_leaves':6,'source_full':4065,'live_sandbox':4078,'original_artifacts':len(rows)}))

from pathlib import Path
import json,subprocess,hashlib,os,sys,ast
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1530';pub=r/'paper/materials/20261015-1530-flask-certainty';sha=lambda b:hashlib.sha256(b).hexdigest();q=json.loads((pub/'batch-readback.json').read_text());main=json.loads((pub/'main-integration.json').read_text());source=q['source'];bid=q['batch'];s=Path(q['original_report']['report']).parent;now=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(now,flush=True)
ledger=r/'paper/materials/learning/ledger.jsonl';before=ledger.stat().st_size;updates=[]
for ident in ['silent-0295','silent-0007']:updates.append({'id':ident,'by':'ops:codex','where':{'commits':[source,q['original_report']['merged'],main['main']]},'note':f'{now} 原{bid}药瓶随机施毒边界source0bf701b58已实际live8c1935b9，并只六叶同步main{main["main"]}；源tsc/沙箱4065与live沙箱4078过、最终固定14/撤源码4失败恢复14过，实际宿主原worker1625656正持锁检查be679d7e。正式release_id待原锁释放按实际registry核号，不预分配；只补代码子项追溯，既有经验status/版本、首证与证据计数保持，0295物理proposed/HEAD旧shipped分歧原样保留；八项waiting、自然消费者与宽父不关闭。见paper/materials/20261015-1530-flask-certainty/。'})
(pub/'ops-ledger-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates));result=subprocess.run(['python3','learner/ledger.py','update','--character','silent'],input=(pub/'ops-ledger-input.jsonl').read_text(),text=True,capture_output=True);(pub/'ops-ledger.log').write_text(result.stdout+result.stderr);assert result.returncode==0
rows=[]
for raw in ledger.read_bytes()[before:].splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('by')=='ops:codex' and str(pub.relative_to(r)) in row.get('note',''):rows.append(raw)
assert len(rows)==2 and all(set(json.loads(x))<=set(['op','id','ts','by','where','note']) for x in rows);(p/'ops-owned-ledger.jsonl').write_bytes(b''.join(rows))
sys.path.insert(0,str(r/'learner'));import code_proposals
proposals=code_proposals.fold(r/'paper/materials/learning/code-proposals.jsonl');states={}
for row in q['original_report']['proposal_results']:
 actual=proposals[row['id']];assert actual['state']==row['state'];states[row['id']]=actual['state']
assert list(states.values()).count('implemented')==2 and list(states.values()).count('waiting')==8
holder=1625656;proc=Path('/proc')/str(holder);hostlog=r/'ops/codex-ops/learner'/f'{bid}.fallback-be679d7e446c1ed5397ed7f683a1c1e7de8e42f3.checks.log';host={'at':now,'original_batch':bid,'already_dispatched_by':'original scheduler finish --batch, not a new ops request','expected_live':'1e3f8d10bddc7bb97acad87cf37238490c4cfc5c','exact_tree':'be679d7e446c1ed5397ed7f683a1c1e7de8e42f3','expected_log':str(hostlog.relative_to(r)),'additional_full_check_requests':0,'formal_release_registration':'deferred until this existing live lock is released, no speculative number'}
if proc.exists():
 raw=(proc/'stat').read_text();paths=[]
 for f in (proc/'fd').iterdir():
  try:t=os.readlink(f)
  except FileNotFoundError:continue
  if t in [str(r/'ops/live-merge.lock'),str(hostlog)]:paths.append(t)
 host.update(pid=holder,birth=raw[raw.rfind(')')+2:].split()[19],cwd=os.readlink(proc/'cwd'),comm=(proc/'comm').read_text().strip(),actual_open_paths=paths)
 assert str(r/'ops/live-merge.lock') in paths and str(hostlog) in paths and host['birth']=='94133040'
 host['state']='actual host process owns original lock and exact log; result pending';host['vitest_RUN_observed']=hostlog.exists() and ' RUN ' in hostlog.read_text();host['current_log_bytes']=hostlog.stat().st_size
else:host['state']='original host process exited before this readback; preserve and consume its original scheduler completion event, no redispatch'
(pub/'host-start-readback.json').write_text(json.dumps(host,ensure_ascii=False,indent=2)+'\n');deferred={'at':now,'batch':bid,'source':source,'actual_behavior_commit':q['original_report']['merged'],'existing_version_name':'V5.silent-flask-certainty1','existing_release_id':None,'registration_stage':'pending original live host lock','next_owner':'same primary ops on original learner-checks completion','next_actions':['take existing ops/live-merge.lock after current host returns','re-read current live ancestry and both registries; allocate only actual existing behavior commit using then-current cumulative maximum','preserve existing name/family/commit/source/order and knowledge refresh; do not merge entire main with prepared P2/C2-on','record actual number, host scope and natural consumer separately; no duplicate full for metadata-only code-equivalent binding'],'new_task_or_learner_or_controller':False,'game_restart':False,'source_test_and_error_artifacts':'preserved','automatic_number_or_user_ACK_claimed':False};(pub/'release-registration-pending.json').write_text(json.dumps(deferred,ensure_ascii=False,indent=2)+'\n')
# Recover only the original pure strings; never execute the learner publication script.
tree=ast.parse((s/'record-publication.py').read_text());ctx={'now':'2026-10-15 15:16:53 CST','SOURCE':source,'MERGED':q['original_report']['merged'],'SCRATCH':s};strings={}
for node in tree.body:
 if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ['notice','decision']:
  assert isinstance(node.value,(ast.JoinedStr,ast.Constant));strings[node.targets[0].id]=eval(compile(ast.Expression(node.value),'<original-publication-text>','eval'),{'__builtins__':{}},ctx)
assert set(strings)=={'notice','decision'}
for rel,key in [('notes/for-roy.md','notice'),('ops/inbox-dev.md','notice'),('paper/materials/decision-log.md','decision')]:assert (r/rel).read_bytes().count(strings[key].encode())==1
(p/'original-publication-appends.json').write_text(json.dumps(strings,ensure_ascii=False,indent=2)+'\n');(pub/'completion.json').write_text(json.dumps({'at':now,'source_main_live_ancestors_actual':True,'main_integration':main['main'],'source_test_cases':4065,'live_sandbox_cases':4078,'original_raw_rows_verified':2481,'original_cli_rows':26,'ops_where_note_rows':2,'two_implemented_eight_waiting':states,'full_host':host,'formal_release':deferred,'original_dual_rule_notice_strings_verified':True,'natural_consumers':'pending; no restart; fixed tests are not natural usage','existing_experience_versions':'preserved S1.exp141 / S1.exp203; no status rewrite','P2_C2_on_main_only_and_wide_parents':'preserved, not deployed or closed','no_additional_full_suite_or_API_or_model_or_parent_dispatch':True},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'source_main':main['main'],'ledger_rows':2,'original_notices_recovered':True,'host_stage':host['state'],'formal_release':'pending same original lock'}))

from pathlib import Path
import json,subprocess,hashlib,os
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1530';pub=r/'paper/materials/20261015-1530-flask-certainty';live=r/'.worktrees/live';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r,env=None,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],env=env,input=data,stderr=subprocess.PIPE)
def blob(head,path):
 v=subprocess.run(['git','show',head+':'+path],capture_output=True);assert v.returncode in [0,128];return v.stdout if v.returncode==0 else None
q=json.loads((pub/'batch-readback.json').read_text());source=q['source'];base=q['parent'];head=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip();assert not git('diff','--cached','--name-only').strip();git('merge-base','--is-ancestor',source,lh);assert not (pub/'main-integration.json').exists();values={};rows=[]
for row in q['source_paths']:
 path=row['path'];old=blob(base,path);current=blob(head,path);desired=blob(source,path);assert sha(desired)==row['sha256'];f=r/path;assert (f.read_bytes() if f.exists() else None)==current
 if current==old:value=desired
 elif current==desired:value=current
 else:
  assert old is not None and current is not None
  folder=p/'three-way'/path;folder.parent.mkdir(parents=True,exist_ok=True);a=folder.with_suffix(folder.suffix+'.current');b=folder.with_suffix(folder.suffix+'.base');c=folder.with_suffix(folder.suffix+'.source');a.write_bytes(current);b.write_bytes(old);c.write_bytes(desired);result=subprocess.run(['git','merge-file','-p',str(a),str(b),str(c)],capture_output=True);assert result.returncode==0,('preserved selected conflict, no mutation',path);value=result.stdout
 dest=p/'composed-scan'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(value);actual=git('show',lh+':'+path,cwd=live);equal=value==actual;code_sha=None
 if not equal:
  assert path.endswith('.ts');v=p/'live-compare'/path;v.parent.mkdir(parents=True,exist_ok=True);v.write_bytes(actual);code="const fs=require('fs'),es=require(process.argv[1]);for(const p of process.argv.slice(2))process.stdout.write(JSON.stringify(es.transformSync(fs.readFileSync(p,'utf8'),{loader:'ts',format:'esm',target:'es2022',legalComments:'none'}).code)+'\\n');";js=subprocess.check_output(['/home/dw/.local/node/bin/node','-e',code,str(r/'agent/node_modules/esbuild'),str(dest),str(v)]).splitlines();assert len(js)==2 and json.loads(js[0])==json.loads(js[1]),('main/source/live composition differs semantically',path);code_sha=sha(json.loads(js[0]).encode())
 values[path]=value;rows.append({'path':path,'main_before_sha256':sha(current) if current is not None else None,'source_sha256':sha(desired),'composed_sha256':sha(value),'actual_live_sha256':sha(actual),'main_live_bytes_equal':equal,'generated_js_sha256_if_comments_differ':code_sha})
with (pub/'composition-gitleaks.log').open('wb') as log:rc=subprocess.run(['nice','-n','19','gitleaks','dir',str(p/'composed-scan'),'--redact','--no-banner','--report-format','json','--report-path',str(p/'composition-gitleaks.json')],env={**os.environ,'GOMAXPROCS':'2'},stdout=log,stderr=subprocess.STDOUT).returncode
assert rc==0 and json.loads((p/'composition-gitleaks.json').read_text())==[];env={**os.environ,'GIT_INDEX_FILE':str(p/'main-source.index')};git('read-tree',head,env=env)
for path,value in values.items():
 oid=git('hash-object','-w','--stdin',data=value).decode().strip();git('update-index','--add','--cacheinfo','100644',oid,path,env=env)
tree=git('write-tree',env=env).decode().strip();assert set(git('diff-tree','--no-commit-id','--name-only','-r',head,tree).decode().splitlines())==set(values);at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True);msg='Integrate already-live bounded Silent Flask certainty fix\n\nBring only the six tested source leaves to main and retain all prepared P2/C2 changes. Live is untouched while its original full check holds the publication lock.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n';new=git('commit-tree',tree,'-p',head,'-p',source,data=msg.encode()).decode().strip();idx=Path(git('rev-parse','--git-path','index').decode().strip()).resolve();lock=Path(str(idx)+'.lock');fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);published=False
try:
 assert git('rev-parse','HEAD').decode().strip()==head and not git('diff','--cached','--name-only').strip()
 with os.fdopen(fd,'wb') as f:f.write(Path(env['GIT_INDEX_FILE']).read_bytes());f.flush();os.fsync(f.fileno())
 git('update-ref','-m','ops: integrate only tested already-live Flask leaves','HEAD',new,head);published=True
 for path,value in values.items():
  f=r/path;tmp=f.with_name(f.name+'.flask-main.tmp');assert not tmp.exists();tmp.write_bytes(value);os.replace(tmp,f)
 os.replace(lock,idx)
finally:
 if lock.exists() and not published:lock.unlink()
assert not git('diff','--cached','--name-only').strip();git('merge-base','--is-ancestor',source,new)
for path,value in values.items():assert (r/path).read_bytes()==value
receipt={'at':at,'old_main':head,'main':new,'main_tree':tree,'source':source,'source_actual_main_ancestor':True,'live_at_comparison':lh,'source_leaves':rows,'source_full':4065,'live_sandbox_full':4078,'generated_code_equivalence_to_already_tested_live':True,'all_other_main_blobs_unchanged':True,'P2_C2_prepared_on_changes_kept_main_only':True,'live_written':False,'account_model_game_knowledge_refresh_changed':False,'formal_release_id':'pending original live lock; no speculative allocation','reason':'original scheduler host full already holds live lock; preserve and await original learner-checks event without duplicate checks','secret_scan':0};(pub/'main-integration.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'main':new,'six_leaves':6,'source_main_ancestor':True,'live_untouched':True,'release_pending_existing_host_lock':True}))

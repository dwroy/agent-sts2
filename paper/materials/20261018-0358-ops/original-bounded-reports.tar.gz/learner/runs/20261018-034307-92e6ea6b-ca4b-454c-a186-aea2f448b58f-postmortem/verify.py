import json,pathlib,hashlib,collections,subprocess
P=pathlib.Path('/home/dw/Projects/agent-sts2');O=pathlib.Path(__file__).parent
A={};refs={}
for name in ['runs','decisions','states','run-plans','run-config','brain','sl-attempts']:
 rows=[json.loads(l) for l in (O/(name+'.jsonl')).open()];A[name]=rows
 with (P/'logs'/(name+'.jsonl')).open('rb') as f:
  for r in rows:
   f.seek(r['_offset']);raw=f.read(r['_bytes']);assert hashlib.sha256(raw).hexdigest()==r['_sha256'],(name,r['_line'])
   original=json.loads(raw);assert original=={k:v for k,v in r.items() if k not in ['_line','_offset','_bytes','_sha256']}
 refs[name]=len(rows)
S={s['_line']:s for s in A['states']};D=A['decisions'];J=[d for d in D if d['decider']=='jev'];B=A['brain'];R=json.loads((O/'U6JELGQTBMHN-resources.json').read_text())
assert refs=={'runs':1,'decisions':453,'states':472,'run-plans':6,'run-config':1,'brain':29,'sl-attempts':1}
expected=[(2,56,70,52,70),(3,52,70,39,70),(4,39,70,35,70),(5,35,70,22,70),(8,48,75,39,75),(9,46,82,38,82),(13,67,87,55,87),(15,60,92,56,92),(17,88,97,57,97),(19,89,97,89,97),(20,89,97,89,97),(22,89,97,82,97),(23,82,97,66,97),(28,82,102,0,102)]
for c,e in zip(R['combats'],expected):
 x=c['entry'];y=c['exit'];assert c['entry_is_turn_one'] and y is not None
 assert (c['floor'],x['hp'],x['max_hp'],y['hp'],y['max_hp'])==e
 assert S[x['line']]['ts']==x['ts'] and S[y['line']]['ts']==y['ts']
assert len(R['combats'])==len(expected)
f28=R['combats'][-1]['enemy_hp_audit']['turns'];assert [t['live_enemy_hp_start'] for t in f28]==[150,140,133,80,48,54,73];assert [t['visible_enemy_hp_loss_lower_bound'] for t in f28]==[10,7,53,32,19,6,37];assert sum(t['observed_hp_added'] for t in f28)==50
assert [S[n]['state']['run']['current_hp'] for n in [443294,443300,443304,443307,443314,443320,443324,443330]]==[82,78,59,27,7,7,6,0]
assert [e['current_hp'] for e in S[443330]['state']['combat']['enemies']]==[0,13,23]
assert sum(i['total_damage'] for e in S[443329]['state']['combat']['enemies'] for i in e['intents'] if i['intent_type']=='Attack')==18
assert len(J)==137 and sum(d['confidence']<.35 for d in J)==12 and sum(d['confidence']<.55 for d in J)==21
assert collections.Counter(d.get('rollout_best_chosen') for d in J)=={True:119,None:16,False:2}
assert sum(bool(d.get('focus')) for d in J)==45
assert sum(bool(d.get('focus',{}).get(d.get('answers',{}).get('plan',{}).get('choice'))) for d in J)==28
C=[d for d in D if d['decider']=='code' and d['label'].startswith('combat/') and d['label']!='combat/plan-continue'];assert len(C)==34 and len(set((d['floor'],d['turn']) for d in C))==27
assert len(set((d['floor'],d['turn']) for d in C)-set((d['floor'],d['turn']) for d in J if d['label'].startswith('combat/')))==15
assert len([d for d in D if (d.get('chosen') or {}).get('action')=='use_potion'])==8
assert len([d for d in D if (d.get('chosen') or {}).get('action')=='discard_potion'])==0
assert sum((d.get('usage') or {}).get('input_tokens',0) for d in J)==938743
assert sum((d.get('usage') or {}).get('output_tokens',0) for d in J)==8213
assert sum(b['usage']['inputTokens'] for b in B)==5650786
assert sum(b['usage']['outputTokens'] for b in B)==30425
assert sum(b['usage']['cacheHitTokens'] for b in B)==146560
assert all((b['engine'],b['model'],b['effort'])==('codex','gpt-6.1-sol','xhigh') for b in B)
assert next(d for d in D if d['_line']==428646)['expect']['card']['id']=='PRECISE_CUT'
assert S[443295]['state']['run']['potions'][1]['valid_target_indices']==[0,1,2]
q=next(d for d in D if d['_line']==428625)['questions']['plan']['criteria'];assert 'p1->e0' in q and 'p1->e1' in q and 'p1->e2' not in q
section=[];active=False
with (P/'notes/lessons.md').open() as f:
 for line in f:
  if line.startswith('## U6JELGQTBMHN'):active=True
  elif active and line.startswith('## '):break
  if active:section.append(line)
text=''.join(section);assert sum(line.startswith('- [') for line in section)==4
for needle in ['82/102','18攻击','13／23','T1—T7','946956','silent-0365','PRECISE_CUT']:
 assert needle in text,needle
(O/'lessons-final-section.md').write_text(text)
result={'原始字节引用':refs,'复盘关键数字核验':'通过','战斗窗口':14,'纯bug新增':0,'旧bug重复':'silent-0365','勘误':'精确切击ID已以追加段改为PRECISE_CUT'}
(O/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

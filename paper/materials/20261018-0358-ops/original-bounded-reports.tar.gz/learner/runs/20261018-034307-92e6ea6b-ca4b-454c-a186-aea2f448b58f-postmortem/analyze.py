import json,pathlib,collections,datetime
P=pathlib.Path(__file__).parent
def load(n):return [json.loads(l) for l in (P/(n+'.jsonl')).open()]
D=load('decisions');S=load('states');B=load('brain');R=json.loads((P/'U6JELGQTBMHN-resources.json').read_text())
def compact(d):return {'line':d['_line'],'floor':d.get('floor'),'turn':d.get('turn'),'label':d.get('label'),'decider':d.get('decider'),'chosen':d.get('chosen'),'reason':d.get('rationale'),'conf':d.get('confidence'),'journal':d.get('journal')}
(P/'decisions-summary.json').write_text(json.dumps([compact(d) for d in D],ensure_ascii=False,indent=2)+'\n')
with (P/'f28-decisions.txt').open('w') as f:
 for d in D:
  if d.get('floor')!=28:continue
  x=compact(d);x.pop('boss_sim',None);x.pop('deepseek',None)
  f.write(json.dumps(x,ensure_ascii=False)+'\n')
  if d.get('questions'):f.write('问题 '+json.dumps(d['questions'],ensure_ascii=False)+'\n')
with (P/'noncombat.txt').open('w') as f:
 for d in D:
  if d['decider']=='codex':f.write(json.dumps(compact(d),ensure_ascii=False)+'\n')
with (P/'f28-states.txt').open('w') as f:
 for r in S:
  s=r['state'];run=s.get('run') or {};c=s.get('combat') or {}
  if run.get('floor')!=28:continue
  x={'line':r['_line'],'ts':r['ts'],'turn':s.get('turn'),'screen':s['screen'],'hp':run.get('current_hp'),'player':c.get('player'),'potions':[[p['index'],p['potion_id']] for p in run.get('potions',[]) if p.get('occupied')],'hand':[(p['index'],p['card_id'],p.get('energy_cost'),p.get('upgraded')) for p in c.get('hand',[])],'enemies':[{k:e.get(k) for k in ['index','enemy_id','current_hp','is_alive','powers','intents']} for e in c.get('enemies',[])]};f.write(json.dumps(x,ensure_ascii=False)+'\n')
print('jev',len([d for d in D if d['decider']=='jev']),'deciders',collections.Counter(d['decider'] for d in D))
J=[d for d in D if d['decider']=='jev'];print('low',[(k,len([d for d in J if isinstance(d.get('confidence'),(float,int)) and d['confidence']<k])) for k in [.35,.55]])
print('journal example',J[0]['journal']); print('top-level extra',list(J[0].get('deepseek') or {}))
for d in D:
 if d['label'].startswith('combat/') and d['decider']=='code' and d['label']!='combat/plan-continue':print('autocode',d['_line'],d['floor'],d['turn'],d['label'],d.get('rationale'))
for d in D:
 if 'guard' in json.dumps(d,ensure_ascii=False).lower() or '护栏' in json.dumps(d,ensure_ascii=False):print('guard',d['_line'],d.get('rationale'))
print('tokens jev', {k:sum((d.get('usage') or {}).get(k,0) or 0 for d in J) for k in set().union(*(d.get('usage') or {} for d in J))})
print('tokens brain',{k:sum((b.get('usage') or {}).get(k,0) or 0 for b in B) for k in set().union(*(b.get('usage') or {} for b in B))})
print('brain eng/model',collections.Counter((b.get('engine'),b.get('model')) for b in B))
print('seconds',(datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'))).total_seconds())

import json, pathlib, hashlib, subprocess
p=pathlib.Path('/home/dw/Projects/agent-sts2'); out=p/'learner/runs/20261018-034307-92e6ea6b-ca4b-454c-a186-aea2f448b58f-postmortem'; run='U6JELGQTBMHN'
for name in ['runs','decisions','states','run-plans','run-config','brain','sl-attempts']:
    path=p/'logs'/f'{name}.jsonl'; count=0; first=last=None
    with path.open('rb') as src, (out/f'{name}.jsonl').open('w') as dst:
        offset=0
        for no,line in enumerate(src,1):
            if run.encode() in line:
                row=json.loads(line)
                if row.get('run_id',row.get('run',(row.get('state') or {}).get('run_id'))) == run:
                    row['_line']=no;row['_offset']=offset;row['_bytes']=len(line);row['_sha256']=hashlib.sha256(line).hexdigest()
                    dst.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
                    first=first or row.get('ts'); last=row.get('ts')
            offset+=len(line)
    print(name,count,first,last,flush=True)
d=[json.loads(l) for l in (out/'decisions.jsonl').open()]; lo=min(x['ts'] for x in d); hi=max(x['ts'] for x in d)
path=p/'logs/deepseek-reasoning.jsonl'; start=max(0,path.stat().st_size-64*1024*1024); count=0
with path.open('rb') as src,(out/'deepseek-reasoning.jsonl').open('w') as dst:
    src.seek(start)
    if start:src.readline()
    while True:
        off=src.tell(); line=src.readline()
        if not line:break
        try: row=json.loads(line)
        except ValueError:continue
        if lo<=row.get('ts','')<=hi:
            row['_offset']=off;row['_bytes']=len(line);row['_sha256']=hashlib.sha256(line).hexdigest();dst.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
print('reasoning',count,'window',lo,hi,'seek',start)

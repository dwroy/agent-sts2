from pathlib import Path
import json,hashlib,subprocess,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-v5s-on';pub=r/'paper/materials/20261015-v5-s-completion/resume-1615';sha=lambda b:hashlib.sha256(b).hexdigest();assert not (p/'record-manifest.json').exists()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();receipt=json.loads((pub/'ops-publication-receipt.json').read_text());receipt['publication_return']={'path':str((pub/'ops-publication-send.json').relative_to(r)),'status':'actual Herdr transport rc0 to original watcher; receiver ACK not claimed'};receipt['next_natural_on_consumer']='pending original watcher on next natural run; current 2LZ remains shadow and is not an on consumer';(pub/'ops-publication-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
firsterror={'first_host_readback_failure':'AssertionError: existing worker argv contained absolute /home/dw/Projects/agent-sts2/ops/codex-ops-learn.py while readback helper expected literal relative ops/codex-ops-learn.py','actual_worker':1838232,'birth':'94547365','cwd':str(r),'bound_expected_log_fd':'5','correction':'Only helper path identity check normalized to absolute suffix; lock owner/cwd/log fd/exact tree/RUN unchanged. No restart, additional full request, source or assertion-budget relaxation.','accepted_readback':'ops-host-start-readback.json'};(pub/'ops-readback-script-history.json').write_text(json.dumps(firsterror,ensure_ascii=False,indent=2)+'\n')
appends=json.loads((p/'own-appends.json').read_text());more={'ops/inbox-dev.md':f'\n- {at}｜原V5-S接续实际发布回报：P2-on V5-R359 / C2-on V5-R360，最终live {receipt["final_live"]} / tree {receipt["final_tree"]}；原051302-s2宿主full worker1838232已实启，仅本最终组合一份，结果pending。原watcher wJ:pJT/01a13dcd已通过Herdr实际发送rc0（不冒称本人已读/用户ACK）。当前2LZHP9BYFTHE/PID1815776原shadow继续，下一自然on消费者/理由/complete_adaptive/health/p50/p90及eval由原watcher接续；P4/P5和宽父保持。回执paper/materials/20261015-v5-s-completion/resume-1615/ops-publication-receipt.json。\n','paper/materials/decision-log.md':f'\n- {at}｜V5-R359/R360最终组合24de68ae5宿主full实际启动worker1838232/原051302-s2，原watcher实际运输rc0、接收ACK未代填；当前2LZ旧shadow局不重启。两次规则双通知保留，最终host结果与下一自然on消费者由原链分别闭环；记录提交只收本人增量。\n'}
for path,text in more.items():
 with (r/path).open('ab') as out:out.write(text.encode())
 appends.append({'path':path,'text':text,'phase':'host/send','at':at})
(p/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip();dest=p/'final-files';values={}
for row in appends:
 path=row['path'];b=row['text'].encode();assert (r/path).read_bytes().count(b)==1
 values.setdefault(path,git('show',base+':'+path));values[path]+=b
names=['ops-received.json','ops-code-preflight.json','ops-code-gitleaks.log','ops-p2-publication.json','ops-c2-publication.json','ops-publication-receipt.json','ops-host-request.json','ops-host-start-readback.json','ops-current-run-readback.json','ops-readback-script-history.json','ops-publication-return.txt','ops-return-gitleaks.log','ops-publication-send.json']
for name in names:values[str((pub/name).relative_to(r))]=(pub/name).read_bytes()
helper_names=['preflight.py','publish.py','host-readback.py','prepare-records.py','seal-records.py'];manifest=[]
with tarfile.open(pub/'ops-publication-helpers.tar.gz','w:gz') as tar:
 for name in helper_names:
  f=p/name;b=f.read_bytes();manifest.append({'path':str(f.relative_to(r)),'bytes':len(b),'sha256':sha(b)});tar.add(f,arcname=name)
(pub/'ops-publication-helper-manifest.json').write_text(json.dumps({'scope':'ops publication/readback/record helpers only; tested production source reused unchanged','files':manifest},ensure_ascii=False,indent=2)+'\n')
for name in ['ops-publication-helpers.tar.gz','ops-publication-helper-manifest.json']:values[str((pub/name).relative_to(r))]=(pub/name).read_bytes()
rows=[]
for path,b in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);rows.append({'path':path,'bytes':len(b),'sha256':sha(b)})
(p/'record-manifest.json').write_text(json.dumps({'base':base,'paths':rows},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'record_paths':len(rows),'base':base,'owned_appends':len(appends)}))

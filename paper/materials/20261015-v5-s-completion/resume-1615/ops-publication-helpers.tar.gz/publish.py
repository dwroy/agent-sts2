from pathlib import Path
import json,hashlib,subprocess,fcntl,os,re
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261015-v5s-on';pub=r/'paper/materials/20261015-v5-s-completion/resume-1615';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r,env=None,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],env=env,input=data,stderr=subprocess.PIPE)
def blob(rev,path,cwd=r):return git('show',rev+':'+path,cwd=cwd)
def stage(path,raw,env,cwd):
 oid=git('hash-object','-w','--stdin',cwd=cwd,data=raw).decode().strip();git('update-index','--add','--cacheinfo','100644',oid,path,cwd=cwd,env=env)
def commit(tree,parents,title,cwd):
 args=['commit-tree',tree]
 for parent in dict.fromkeys(parents):args+=['-p',parent]
 return git(*args,cwd=cwd,data=(title+'\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n').encode()).decode().strip()
def install(cwd,path,raw):
 f=cwd/path;tmp=f.with_name(f.name+'.ops-v5s.tmp');assert not tmp.exists();tmp.write_bytes(raw);os.replace(tmp,f)
def date():return subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
def install_refs(mh,lh,mn,ln,me,le,values,versions):
 locks=[]
 try:
  for cwd,env in [(r,me),(live,le)]:
   idx=Path(git('rev-parse','--git-path','index',cwd=cwd).decode().strip());idx=idx if idx.is_absolute() else cwd/idx;lp=Path(str(idx)+'.lock');fd=os.open(lp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
   with os.fdopen(fd,'wb') as out:out.write(Path(env['GIT_INDEX_FILE']).read_bytes());out.flush();os.fsync(out.fileno())
   locks.append((idx,lp))
  assert git('rev-parse','HEAD').decode().strip()==mh and git('rev-parse','HEAD',cwd=live).decode().strip()==lh
  for cwd in [r,live]:assert not git('diff','--cached','--name-only',cwd=cwd).strip() and (cwd/'eval/versions.json').read_bytes()==blob('HEAD','eval/versions.json',cwd)
  git('update-ref','-m','ops: publish original gated V5-S stage','HEAD',ln,lh,cwd=live)
  for path,b in values.items():install(live,path,b)
  install(live,'eval/versions.json',versions[str(live)]);git('update-ref','-m','ops: register actual gated V5-S live stage','HEAD',mn,mh);install(r,'eval/versions.json',versions[str(r)])
  for idx,lp in locks:os.replace(lp,idx)
 finally:
  for idx,lp in locks:
   if lp.exists():lp.unlink()
assert not (pub/'ops-publication-receipt.json').exists();assert json.loads((p/'code-gitleaks.json').read_text())==[]
pre=json.loads((pub/'ops-code-preflight.json').read_text());sources=pre['sources'];releases=[];appends=[]
with (r/'ops/live-merge.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 mh=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip();assert mh==pre['main'] and lh==pre['live']
 for lane in ['P2','C2']:
  at=date();print(at,lane,flush=True)
  mh=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip()
  for cwd in [r,live]:assert not git('diff','--cached','--name-only',cwd=cwd).strip() and not git('ls-files','-u',cwd=cwd).strip()
  values={x['path']:(r/x['prepared_file']).read_bytes() for x in pre['phases'][lane]}
  for row in pre['phases'][lane]:
   path=row['path'];assert sha(values[path])==row['sha256'];old=blob(lh,path,live);assert (live/path).read_bytes()==old
   expected=next(x['sha256'] for x in pre['phases']['P2'] if x['path']==path) if lane=='C2' and path=='agent/src/core/config.ts' else row['old_live_sha256'];assert sha(old)==expected
  datasets={}
  for cwd,head in [(r,mh),(live,lh)]:
   raw=blob(head,'eval/versions.json',cwd);assert (cwd/'eval/versions.json').read_bytes()==raw;datasets[str(cwd)]=json.loads(raw)
  a=datasets[str(r)]['release_numbering']['releases'];b=datasets[str(live)]['release_numbering']['releases'];assert a==b
  nums=[int(re.fullmatch(r'V\d+-R(\d+)',x['release_id'])[1]) for x in a];assert nums==list(range(max(nums)+1));rid=f'V5-R{max(nums)+1:03d}'
  le={**os.environ,'GIT_INDEX_FILE':str(p/f'{lane}-live.index')};git('read-tree',lh,env=le,cwd=live);refresh={}
  if lane=='P2':
   current=git('diff','--name-only','HEAD','--','knowledge',cwd=live).decode().splitlines();assert set(current)=={x['path'] for x in pre['knowledge_refresh']}
   for row in pre['knowledge_refresh']:
    path=row['path'];raw=(live/path).read_bytes();assert sha(raw)==row['sha256'];refresh[path]=raw;stage(path,raw,le,live)
  rt=git('write-tree',env=le,cwd=live).decode().strip();fresh=commit(rt,[lh],'Preserve natural live knowledge before gated V5-S activation',live) if refresh else lh
  for path,raw in values.items():stage(path,raw,le,live)
  bt=git('write-tree',env=le,cwd=live).decode().strip();assert set(git('diff','--name-only',rt,bt,cwd=live).decode().splitlines())==set(values)
  behavior=commit(bt,[fresh,sources[lane]],f'Activate gated Silent {lane}-on under original V5-S parent',live)
  name='V5.s-build-rank-on1' if lane=='P2' else 'V5.sim-adaptive-on1'
  detail=('Silent S_BUILD_RANK default shadow -> on; send existing compact ranking and enforce existing override reason/reask. C2 remains shadow/pending at this independent release.' if lane=='P2' else 'Silent SIM_ADAPTIVE default shadow -> on, requested mode now honored with accepted admission; actual segmented candidate sampling/complete_adaptive health enabled. Explicit off/shadow and other-role off remain. Existing maxima/seeds/paired-prefix/low-trust/HP/SL/potion/C1 guards preserved; no unexecuted full-run agreement invented.')
  evidence='Original roy-20261014-s-decision; source '+sources[lane]+'. Source-composition tsc0/431files4058+paths11, health3/gitleaks0 already verified, not rerun. Owner accepted WJ0LTVSSDY61 and DUB5VQQ6D6D1 full natural shadow gates; HLAW mixed-account excluded. DUB5 P2 19/19 completed choices, C2 30/30 final-group agreement; WJ P2 19/19 and C2 27/27. Offline C2 complete fixed set8/8 final-group match, no missing/unresolved. No measured on-mode game benefit or runtime saving asserted. Final actual combined host full and next natural on consumers pending. Rollback corresponding explicit shadow/off next run or exact source delta, preserving other releases and knowledge. Materials paper/materials/20261015-v5-s-completion/resume-1615/.'
  entry={'name':name,'family':'V5','character':'SILENT','commit':behavior,'release_id':rid,'release_status':'registered-primary-ops','source':at+'; '+detail+' '+evidence};versions={}
  for key,data in datasets.items():
   prior=json.loads(json.dumps(data['versions']));assert not any(x['name']==name for x in prior);data['versions'].append(entry);data['release_numbering']['releases'].append({'release_id':rid,'commit':behavior,'aliases':[name]});assert data['versions'][:-1]==prior;versions[key]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
  stage('eval/versions.json',versions[str(live)],le,live);ft=git('write-tree',env=le,cwd=live).decode().strip();final=commit(ft,[behavior],f'Register actual {lane}-on behavior as {rid}',live)
  me={**os.environ,'GIT_INDEX_FILE':str(p/f'{lane}-main.index')};git('read-tree',mh,env=me);stage('eval/versions.json',versions[str(r)],me,r);mt=git('write-tree',env=me).decode().strip();mn=commit(mt,[mh],f'Record actual {lane}-on live release {rid}',r)
  rec={'at':at,'phase':lane+'-on','name':name,'release_id':rid,'source':sources[lane],'old_live':lh,'knowledge_refresh_commit':fresh,'knowledge_refresh':[{ 'path':path,'sha256':sha(raw)} for path,raw in refresh.items()],'behavior_commit':behavior,'behavior_tree':bt,'live':final,'tree':ft,'main':mn,'code_leaves':pre['phases'][lane],'source_ancestor_verified':False,'host':'final combination pending one original-channel full','natural_on_consumer':'pending original watcher; no restart','current_game_account_home_model_prompt_changed':False,'other_roles_P4_P5_wide_parents':'unchanged'}
  (p/f'{lane}-intended-publication.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
  for path,raw in refresh.items():assert (live/path).read_bytes()==raw
  install_refs(mh,lh,mn,final,me,le,values,versions)
  for cwd in [r,live]:
   assert not git('diff','--cached','--name-only',cwd=cwd).strip();git('merge-base','--is-ancestor',sources[lane],'HEAD',cwd=cwd)
  assert git('rev-parse','HEAD','HEAD^{tree}',cwd=live).decode().splitlines()==[final,ft]
  for path,raw in values.items():assert (live/path).read_bytes()==raw==blob(final,path,live)
  cfg=blob(final,'agent/src/core/config.ts',live).decode();assert 'S_BUILD_RANK"]?.trim().toLowerCase() ?? "on"' in cfg
  if lane=='P2':assert 'SIM_ADAPTIVE"]?.trim().toLowerCase() ?? "shadow"' in cfg and 'admission: "pending"' in cfg
  else:assert 'SIM_ADAPTIVE"]?.trim().toLowerCase() ?? "on"' in cfg and 'admission: "accepted"' in cfg
  rec['source_ancestor_verified']=True;rec['live_readback_verified']=True;notice_at=date()
  old='构筑排序仅shadow记录、不入脑、不要求偏离理由' if lane=='P2' else '完整样本后shadow诊断；显式on也退shadow/pending'
  new='Silent默认S_BUILD_RANK=on，既有紧凑排序入脑，偏离既有最佳组须理由并沿原补问校验；C2仍shadow/pending' if lane=='P2' else 'Silent默认SIM_ADAPTIVE=on，启用既有分段/活跃子集与complete_adaptive验证；保样本上限/种子/可信度/HP/SL/药水/C1；其他角色off，显式off/shadow可回退'
  impact='预期使已验收排序实际送达并留选择/理由；没有独立游戏收益声明' if lane=='P2' else '预期在可区分题上减少实际采样工作，未测on耗时或收益；自然p50/p90/health消费者另验'
  text=f'\n- {notice_at}｜规则实际上线 {rid} / {name}：旧：{old}。新：{new}。证据：原父roy-20261014-s-decision，同源{sources[lane]}，WJ+DUB5两自然局完整shadow，P2共38实际选择/C2共57最终组一致；C2离线8/8；HLAW混合账号排除。{impact}。实际behavior={behavior}，live={final}，tree={ft}；保R355/R356–R358/live知识/历史注释，当前局不重启、不切账号。回退：对应开关shadow/off下一局生效，或精确撤本增量保其他发布。原源全检不重跑，最终组合宿主及下一自然on消费者pending；P4/P5和宽学习父不关闭。回执paper/materials/20261015-v5-s-completion/resume-1615/。\n'
  changes={'notes/for-roy.md':text,'ops/inbox-dev.md':text,'paper/materials/decision-log.md':f'\n- {notice_at}｜{rid} 实际窄发布 {lane}-on：source {sources[lane]} → live {final} / behavior {behavior} / tree {ft}，原父roy-20261014-s-decision；WJ+DUB5完整门槛2/2及C2离线8/8已读回，HLAW排除；独立编号，保当前局/账号/R355及并行修复知识。最终组合宿主一次/下一自然消费者待验，未关闭宽父或P4/P5；回执paper/materials/20261015-v5-s-completion/resume-1615/。\n'}
  for path,text in changes.items():
   with (r/path).open('ab') as out:out.write(text.encode())
   appends.append({'path':path,'text':text,'phase':lane,'at':notice_at})
  (p/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n');rec['rule_notifications']=[{'path':x,'at':notice_at,'own_append_sha256':sha(t.encode())} for x,t in changes.items()];(pub/f'ops-{lane.lower()}-publication.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');releases.append(rec);print(json.dumps({'phase':lane,'release_id':rid,'live':final,'tree':ft,'readback':True}),flush=True)
 d={'at':date(),'actor':'original main ops','parent':'roy-20261014-s-decision','original_owner':'01a139d6-cfec-78e1-8739-e21ac426a354','watcher':'01a13dcd-83d4-7c63-b233-f93cf878ecf4','releases':releases,'final_live':releases[-1]['live'],'final_tree':releases[-1]['tree'],'gates':pre['gates'],'offline_gate':pre['offline_gate'],'host_status':'not requested yet; exact final combined full required once','next_natural_on_consumer':'pending original watcher','no_game_restart_or_hot_injection':True,'no_account_home_model_prompt_changes':True,'P4_P5_and_wide_learning_parents':'unchanged/open','other_role_ACK_or_Roy_ACK':'not claimed'};(pub/'ops-publication-receipt.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

from pathlib import Path
import json,hashlib,subprocess,re
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261015-v5s-on';pub=r/'paper/materials/20261015-v5-s-completion/resume-1615';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def blob(rev,path):return git('show',rev+':'+path)
def block(raw,name):
 s=raw.decode();m=re.search(r'/\*\*[^\n]*\*/\nexport function '+name+r'\([\s\S]*?\n}\n',s);assert m,name;return m.group().encode()
def replace(raw,name,value):
 old=block(raw,name);assert raw.count(old)==1;return raw.replace(old,value)
def ref(path):b=(r/path).read_bytes();return {'path':path,'sha256':sha(b)}
now=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip();sources={'P2':git('rev-parse','d3208ee214').decode().strip(),'C2':git('rev-parse','8c6f294171').decode().strip()}
assert not (pub/'ops-publication-receipt.json').exists()
for root in [r,live]:assert not git('diff','--cached','--name-only',cwd=root).strip() and not git('ls-files','-u',cwd=root).strip()
for s in sources.values():git('merge-base','--is-ancestor',s,now)
gates=[]
for run in ['WJ0LTVSSDY61','DUB5VQQ6D6D1']:
 path=f'paper/materials/20261015-v5-s-completion/natural-{run}/complete-shadow-owner-receipt.json';d=json.loads((r/path).read_text());assert 'accepted' in d['status'];assert d['P2']['expected']==d['P2']['produced']==d['P2']['actual_choices_verified']==19 and d['P2']['target_pending']==0
 c=d['C2'];assert c['expected']==c['produced'] and not c['mismatches'];assert c.get('agreement',c.get('final_group_agreement'))==1.0
 for key in ['audit_ref','account_model_admission_ref']:
  if key in d:assert sha((r/d[key]['path']).read_bytes())==d[key]['sha256']
 gates.append(ref(path))
adm=json.loads((pub.parent/'natural-DUB5VQQ6D6D1/codex1-admission.json').read_text());assert adm['accepted'] is True and not adm['issues'] and len(adm['fixed_rejection_checks'])==8 and all(x['rejected'] for x in adm['fixed_rejection_checks']);assert len(adm['all_run_native_traces'])==23 and all(x['model']=='gpt-6.1-sol' and x['effort']=='xhigh' for x in adm['all_run_native_traces'])
offpath='paper/materials/20261015-s-adaptive-on/offline/final-admission-report.json';off=json.loads((r/offpath).read_text());assert off['offline_threshold_met'] and off['coverage_complete'] and off['expected_questions']==off['evaluated_questions']==8 and off['observed_agreement']>=.95 and not off['missing'] and not off['unresolved']
combo=json.loads((r/'paper/materials/20261015-main-merge-codex1/completion.json').read_text());assert combo['checks']=={'tsc':0,'sandbox_vitest':0,'files':431,'passed':4058,'paths_passed':11,'python_health_passed':3,'gitleaks':0}
config='agent/src/core/config.ts';old=blob(lh,config);assert (live/config).read_bytes()==old;first=replace(old,'sBuildRankMode',block(blob(sources['P2'],config),'sBuildRankMode'));final=replace(first,'simAdaptivePolicy',block(blob(sources['C2'],config),'simAdaptivePolicy'))
assert block(first,'simAdaptivePolicy')==block(old,'simAdaptivePolicy') and b'"pending"' in block(first,'simAdaptivePolicy');assert b'?? "on"' in block(final,'simAdaptivePolicy')
assert final.decode().replace('Dai','Roy')==blob(now,config).decode().replace('Dai','Roy');assert (r/config).read_bytes()==blob(now,config)
sets={'P2':{config:first},'C2':{config:final}}
for lane,paths in [('P2',['agent/tests/build-rank.test.ts']),('C2',['agent/tests/adaptive-shadow.test.ts','agent/tests/adaptive-wiring.test.ts','agent/tests/adaptive_health_test.py','agent/tests/computation-failure-b3.test.ts','agent/tests/required-boss-lines.test.ts','ops/adaptive_health.py'])]:
 for path in paths:
  raw=blob(sources[lane],path);assert (r/path).read_bytes()==blob(now,path)==raw;assert (live/path).read_bytes()==blob(lh,path)==blob(sources[lane]+'^',path);sets[lane][path]=raw
manifest={}
for lane,values in sets.items():
 manifest[lane]=[]
 for path,b in values.items():
  out=p/'code-scan'/lane/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);manifest[lane].append({'path':path,'sha256':sha(b),'old_live_sha256':sha(blob(lh,path)),'prepared_file':str(out.relative_to(r))})
refresh=[]
for path in git('diff','--name-only','HEAD','--','knowledge',cwd=live).decode().splitlines():
 b=(live/path).read_bytes();out=p/'code-scan'/'knowledge-refresh'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);refresh.append({'path':path,'sha256':sha(b),'prepared_file':str(out.relative_to(r))})
d={'at':subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(),'main':now,'live':lh,'old_tree':git('rev-parse',lh+'^{tree}').decode().strip(),'sources':sources,'phases':manifest,'knowledge_refresh':refresh,'gates':gates,'offline_gate':ref(offpath),'combined_source_checks':ref('paper/materials/20261015-main-merge-codex1/completion.json'),'DUB_codex1_admission':ref('paper/materials/20261015-v5-s-completion/natural-DUB5VQQ6D6D1/codex1-admission.json'),'P2_intermediate_C2_shadow_verified':True,'config_outside_two_blocks':'unchanged including R355 and live Dai comments; final equivalent to main except historical comment names','HLAW_natural_excluded':True,'current_game_account_home_model_prompt_changed':False,'source_full_repeated':False};(pub/'ops-code-preflight.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'gates':len(gates),'offline':'8/8','leaves':8,'refresh':len(refresh),'live':lh,'source_full':'not repeated'}))

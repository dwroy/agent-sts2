"""Supplement the raw-byte review with the four observed T3 endpoints."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
frames = {r['line']: r for r in json.loads((HERE / 'focused-state-windows.json').read_text())}
starts = [288806, 288837, 288868, 288899]
ends = [288812, 288843, 288874, 288905]
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'matches': True})


check('MTQ四次T3玩家HP变化', [frames[b]['hp'] - frames[a]['hp'] for a, b in zip(starts, ends)], [0, 0, 0, -8])
check('MTQ四次T3敌HP净扣',
      [sum(e['current_hp'] for e in frames[a]['enemies']) - sum(e['current_hp'] for e in frames[b]['enemies'])
       for a, b in zip(starts, ends)], [13, 13, 13, 19])
check('MTQ末次T3少挡仍留一张防御', [c['card_id'] for c in frames[288904]['hand']],
      ['TOXIC', 'TOXIC', 'DEFEND_SILENT', 'PREDATOR'])
all_checks = json.loads((HERE / 'material-checks.json').read_text())
all_checks = [c for c in all_checks if c['name'] not in {x['name'] for x in checks}] + checks
(HERE / 'material-checks.json').write_text(json.dumps(all_checks, ensure_ascii=False, indent=2) + '\n')
(HERE / 't3-supplemental-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
summary = json.loads((HERE / 'verification-summary.json').read_text())
summary['material_checks'] = len(all_checks)
(HERE / 'verification-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'supplemental_checks': len(checks), 'total': len(all_checks)}))

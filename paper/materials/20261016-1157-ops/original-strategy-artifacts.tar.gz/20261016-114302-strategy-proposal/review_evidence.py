"""Verify only the assigned Silent evidence; keep production files untouched."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261016-061302/learner/runs/20261016-061312-21ce0b22-e1f9-4ee8-9f36-ce721c073548-strategy-proposal'


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load(name):
    return json.loads((HERE / name).read_text())


spec = importlib.util.spec_from_file_location('batch_extract', TREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
runs = {r['run_id']: r for r in load('verified-runs.json')}
records = collections.defaultdict(list)
verification = []
raw_signatures = {}
for manifest in load('evidence/evidence-manifest.json'):
    stream = manifest['stream']
    path = HERE / 'evidence' / (stream + '.evidence.jsonl')
    assert digest(path) == manifest['output_sha256']
    counts = collections.Counter()
    signatures = []
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source, path.open() as handle:
        for line in handle:
            item = json.loads(line)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id']
            assert item['run_id'] in runs
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            if stream == 'states':
                state = item['row']['state']
                assert state['run']['character_id'] == 'SILENT'
                assert state['run']['ascension'] == runs[item['run_id']]['ascension']
            counts[item['run_id']] += 1
            signatures.append((item['offset'], item['bytes'], item['sha256']))
            if stream in ('states', 'decisions', 'run-config'):
                records[stream].append(item)
    assert {r: counts[r] for r in runs} == manifest['counts']
    old_signatures = []
    for old_dir in ('evidence', 'evidence-proposal-sources'):
        with (PRIOR / old_dir / (stream + '.evidence.jsonl')).open() as handle:
            for line in handle:
                item = json.loads(line)
                old_signatures.append((item['offset'], item['bytes'], item['sha256']))
    assert sorted(signatures) == sorted(old_signatures), (stream, 'changed assigned evidence')
    verification.append({**manifest, 'verified_rows': sum(counts.values()),
                         'same_prior_selected_raw_rows': True})
    raw_signatures[stream] = signatures
save('raw-verification.json', verification)


def frame(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
            'sha256': item['sha256'], 'run_id': item['run_id'],
            'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
            'block': player.get('block'), 'energy': player.get('energy'),
            'powers': player.get('powers') or [], 'potions': run.get('potions') or [],
            'enemies': combat.get('enemies') or [],
            'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost',
                                          'playable', 'dynamic_values', 'resolved_rules_text')}
                     for c in combat.get('hand', [])]}


by_line = {i['line']: frame(i) for i in records['states']}
transitions = []
previous = {}
for item in records['states']:
    f = by_line[item['line']]
    p = previous.get(f['run_id'])
    if p and (p['floor'], f['floor']) in ((17, 18), (33, 34)):
        if p['max_hp'] == f['max_hp'] and isinstance(p['hp'], int) and isinstance(f['hp'], int):
            actual = f['hp'] - p['hp']
            expected = (p['max_hp'] - p['hp']) * 80 // 100
            transitions.append({'run_id': f['run_id'], 'ascension': runs[f['run_id']]['ascension'],
                                'before': p, 'after': f, 'actual': actual,
                                'formula': expected, 'matches': actual == expected})
    previous[f['run_id']] = f
assert len(transitions) == 22 and all(t['matches'] for t in transitions)
save('cross-act-transitions.json', transitions)

important = {
    'RC61MFQM63Y6': {17: {2, 11}, 23: {3, 4}, 29: {3, 4}, 33: {1, 4}},
    'BTSRF7JL1W1Y': {17: {5, 6, 13}, 30: None, 31: {1, 2, 3}},
    'XTSV1U9JD34T': {48: {8}, 49: {1, 2, 3, 4}},
    '9Z9H2EXKLF3T': {35: None, 38: None, 39: None, 42: None, 45: None, 47: None,
                    48: {2, 3, 4, 7, 8, 10, 11}},
    '7X0W3U8TVA2A': {30: {3}, 31: {1, 2, 5, 6, 11, 13}},
    'MTQ0EUBJ3R6T': {11: {1}, 17: {4, 7, 8}, 19: None, 20: {3}, 23: {2, 3, 4, 5, 6}},
}
focused = [f for f in by_line.values() if f['floor'] in important.get(f['run_id'], {})
           and (important[f['run_id']][f['floor']] is None
                or f['turn'] in important[f['run_id']][f['floor']])]
save('focused-state-windows.json', focused)
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'matches': actual == expected})
    assert actual == expected, checks[-1]


def power(line, ident):
    return next((p['amount'] for p in by_line[line]['powers'] if p['power_id'] == ident), 0)


for line, ident, amount in [(285223, 'DEXTERITY_POWER', 1), (285224, 'DEXTERITY_POWER', 6),
                             (285230, 'DEXTERITY_POWER', 0), (286897, 'INTANGIBLE_POWER', 0),
                             (286898, 'INTANGIBLE_POWER', 1), (286910, 'NIGHTMARE_POWER', 3),
                             (288808, 'DEXTERITY_POWER', 5), (288902, 'DEXTERITY_POWER', 5)]:
    check(f'state{line} {ident}', power(line, ident), amount)
for line, block in [(285225, 12), (285227, 21), (285229, 25), (286897, 16), (286911, 6),
                    (288811, 29), (288842, 29), (288873, 29), (288904, 19),
                    (287989, 32), (288000, 18), (288003, 27), (288004, 37)]:
    check(f'state{line} 格挡', by_line[line]['block'], block)
for line, hp in [(286911, 1), (288470, 1), (288471, 1), (288472, 0),
                 (287990, 0), (287991, 20), (288005, 3), (288008, 0)]:
    check(f'state{line} HP', by_line[line]['hp'], hp)


def enemy(line, ident):
    return next(e for e in by_line[line]['enemies'] if e['enemy_id'] == ident)


def enemy_power(line, ident, power_id):
    return next((p['amount'] for p in enemy(line, ident)['powers'] if p['power_id'] == power_id), 0)


check('7X0 饮前后段零毒', enemy_power(288470, 'DECIMILLIPEDE_SEGMENT_BACK', 'POISON_POWER'), 0)
check('7X0 饮后后段毒7', enemy_power(288471, 'DECIMILLIPEDE_SEGMENT_BACK', 'POISON_POWER'), 7)
check('7X0 饮用当步本体HP不变', enemy(288471, 'DECIMILLIPEDE_SEGMENT_BACK')['current_hp'], 25)
check('7X0 后段结算后18HP', enemy(288472, 'DECIMILLIPEDE_SEGMENT_BACK')['current_hp'], 18)
check('7X0 前段既有毒另计', enemy_power(288471, 'DECIMILLIPEDE_SEGMENT_FRONT', 'POISON_POWER'), 8)
check('7X0 中段重新接续25HP', enemy(288472, 'DECIMILLIPEDE_SEGMENT_MIDDLE')['current_hp'], 25)
for t in transitions:
    check(f"{t['run_id']} F{t['before']['floor']}跨幕回复", t['actual'], t['formula'])
save('material-checks.json', checks)

configs = []
for item in records['run-config']:
    row = item['row']
    code = row.get('code') or {}
    commit = code.get('commit') if isinstance(code, dict) else None
    exists = bool(commit) and subprocess.run(['git', 'cat-file', '-e', commit + '^{commit}'],
                                             cwd=TREE, capture_output=True).returncode == 0
    configs.append({'run_id': item['run_id'], 'line': item['line'], 'sha256': item['sha256'],
                    'code': code, 'git_object_exists': exists, 'restart': row.get('restart')})
save('historical-source-configs.json', configs)

# Reuse the unchanged offline consumer and archived outputs; do not rerun it on identical inputs.
artifacts = json.loads((PRIOR / 'artifact-sha256.json').read_text())
execution = json.loads((PRIOR / 'consumer-execution.json').read_text())
receipts = []
for old in artifacts:
    p = Path(old['path'])
    if p.name.startswith(('audit-input-', 'audit-output-')):
        sha = digest(p)
        assert sha == old['sha256'] and p.stat().st_size == old['bytes']
        receipts.append({**old, 'verified': True})
assert len(execution) == 12 and all(r['returncode'] == 0 for r in execution)
for result in execution:
    assert all(any(a['path'] == result[k] for a in receipts) for k in ('input', 'output', 'stderr'))
summary = json.loads((PRIOR / 'consumer-summary.json').read_text())
save('prior-consumer-artifacts-verified.json', receipts)
save('prior-consumer-summary-readback.json', summary)
save('verification-summary.json', {
    'runs': len(runs), 'rows': sum(v['verified_rows'] for v in verification),
    'streams': {v['stream']: v['verified_rows'] for v in verification},
    'same_prior_selected_evidence': True, 'material_checks': len(checks),
    'cross_act_transitions': len(transitions), 'focused_frames': len(focused),
    'historical_configs': len(configs), 'historical_commits_exist': all(c['git_object_exists'] for c in configs),
    'prior_consumer_runs': len(execution), 'prior_consumer_artifacts': len(receipts),
    'consumer_rerun': False,
})
print((HERE / 'verification-summary.json').read_text())

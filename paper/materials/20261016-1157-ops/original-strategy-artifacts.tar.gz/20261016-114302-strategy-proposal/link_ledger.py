"""Append provenance through the canonical CLI and verify only this batch's events."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LEDGER = ROOT / 'paper/materials/learning/ledger.jsonl'
spec = importlib.util.spec_from_file_location('canonical_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


proposals = json.loads((HERE / 'assigned-proposals.json').read_text())
ids = list(dict.fromkeys(i for p in proposals for i in p['ledger']))
assert len(ids) == 46
folded = ledger.fold(ledger.read_rows(str(LEDGER)))
before = {i: folded[i] for i in ids}
assert all(e['character'] == 'silent' for e in before.values())
save('ledger-cli-before.json', before)
updates = []
for ident in ids:
    related = [p['id'] for p in proposals if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261016-114302-strategy-proposal：核22,424条同角色原行与原提案SHA，'
                            '本批关联提案仍waiting；局部已有模型不认证完整消费者或受控整战后继。'
                            '仅补追溯，不添加重复证据或变更既有状态/规则；关联' + ','.join(related)})
payload = ''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates)
(HERE / 'ledger-updates.jsonl').write_text(payload)
prefix = LEDGER.read_bytes()
result = subprocess.run([sys.executable, str(ROOT / 'learner/ledger.py'), 'update'], input=payload,
                        text=True, capture_output=True, cwd=ROOT)
(HERE / 'ledger-cli.stdout.txt').write_text(result.stdout)
(HERE / 'ledger-cli.stderr.txt').write_text(result.stderr)
assert result.returncode == 0, 'ledger CLI failed; see preserved stderr'
after_bytes = LEDGER.read_bytes()
assert after_bytes[:len(prefix)] == prefix
owned = []
offset = len(prefix)
for raw in after_bytes[len(prefix):].splitlines(keepends=True):
    row = json.loads(raw)
    if str(HERE / 'report.md') in row.get('where', {}).get('proposal', []):
        owned.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row})
    offset += len(raw)
assert len(owned) == len(ids)
assert {r['row']['id'] for r in owned} == set(ids)
private = copy.deepcopy(before)
for event in owned:
    row = event['row']
    expected = next(u for u in updates if u['id'] == row['id'])
    assert all(row[k] == v for k, v in expected.items())
    assert set(row) <= set(expected) | {'op', 'ts'}
    ledger.apply(private, row)
protected = ('character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs',
             'evidence', 'status', 'version', 'effect', 'shipped_at')
for ident in ids:
    for field in protected:
        assert before[ident].get(field) == private[ident].get(field), (ident, field)
    for field in ('history', 'notes'):
        assert private[ident][field][:len(before[ident][field])] == before[ident][field]
    for field, values in before[ident]['where'].items():
        assert private[ident]['where'][field][:len(values)] == values
save('ledger-owned-events.json', owned)
save('ledger-private-fold.json', private)
receipt = {'returncode': result.returncode, 'updates': len(owned), 'by': 'learner:strategy-proposal',
           'prefix_bytes': len(prefix), 'prefix_sha256': hashlib.sha256(prefix).hexdigest(),
           'prefix_preserved': True, 'protected_fields_unchanged': True,
           'history_notes_where_prefixes_preserved': True,
           'concurrent_suffix_rows': len(after_bytes[len(prefix):].splitlines()) - len(owned)}
save('ledger-cli-receipt.json', receipt)
print(json.dumps(receipt, ensure_ascii=False))

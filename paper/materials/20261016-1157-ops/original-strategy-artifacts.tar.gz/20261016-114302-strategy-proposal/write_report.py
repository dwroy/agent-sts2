"""Write the assigned proposal dispositions and their evidence links."""
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
TREE = HERE.parents[2]


def load(name):
    return json.loads((HERE / name).read_text())


def save(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


proposals = load('assigned-proposals.json')
dispatch = load('dispatch.json')
verification = load('verification-summary.json')
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TREE, text=True).strip()
notes = [
    {
        'evidence': 'RC61MFQM63Y6 A10 F17T2/T11、F23T3/T4、F29T3/T4、F33T1/T4；重点原状态285223—285230。',
        'finding': 'F23T3预判后敏捷1、速度药后6；斗篷12挡、防御后21、第三攻击折扇补4到25；T4敏捷归0。原提案八组件的局部观察成立，未在同窗同时隔离脆弱、翻倍和所有触发组合。',
        'counter': 'F33各失败尝试不能当敏捷/折扇机制反例，也不能证明改变药水时点会赢；持有而未建立的幻影或毒雾没有本场既成收益。',
        'reason': '缺八组件逐项至联合生产消费者的完整固定校准；当前局部帧未补齐柔嫩、脆弱、翻倍和触发时点的全部组合，不能整项认定duplicate。',
        'validation': '锁定F23原手牌、柔嫩、药敏、攻击计数与被动挡来源，分别验证逐牌属性消费及T4撤回；F17毒雾和F29幻影另设固定输入，未知叠层保留。',
    },
    {
        'evidence': 'XTSV1U9JD34T A10 F49六试T1/T3/T4；原状态286897→286898、286910—286911及末试286986—286987。',
        'finding': '实际饮幽灵后新增无实体1，23HP/16挡不变；一层模型已有live源码96f17377a331e50ea5b6a3fe8d2b605932ed1bd4。T4夜魇建立3复制标记，但没有活到后轮兑现。当前源码无专属夜魇复制模型，不能把未知技能的一般估值当已验证复制价值。',
        'counter': '六试均T1饮用，当轮零损有已兑现价值；另两条T3换猎杀者的后继仍判死，没有去掉夜魇或延后饮药的整场胜线。',
        'reason': '幽灵单层为已有live子项；缺夜魇可执行复制后继、存活条件消费者及延后饮药整战对照，保留宽提案waiting。',
        'validation': '固定原T1输入核无药损10/一层零损；复制须核实际目标、到手轮与死亡截断，不补未知复制规则，不拟延后时点/持有价。',
    },
    {
        'evidence': 'BTSRF7JL1W1Y A10 F17四试/F31T2；XTSV1U9JD34T A10 F33两试、F48T8/F49T1/T4。',
        'finding': 'B F31生存者后唯一后继牌被强制弃去；普通单弃已有bf423c173d3be348a4ad714e1d26516df619ff41。X F48获胜97→23，末轮32→23支付9凋萎后才毒胜；保血搜索已有222445a9bb6bf56cb4f3ceea2cc8b20fba54128f及固定夹具。',
        'counter': '保血模型能生成候选，不证明F49获胜；耳环接管首题已仅剩不可打牌，中间内部动作未知，不能反推应主动启动接管。',
        'reason': '单弃和毒胜保血已有live子项；接管内部执行、夜魇复制后继及抽弃牌重问后的完整联合候选归属仍缺证。',
        'validation': '分别冻结单弃与毒胜前持牌伤输入，核普通单弃后不可执行续步被移除、合法保血候选可生成；接管和复制须补真实动作序列，不将端点当整候选认证。',
    },
    {
        'evidence': 'BTSRF7JL1W1Y A10 F30/F31；XTSV1U9JD34T A10 F47/F48T8/F49T1。',
        'finding': 'B F30虽赢仍70→42，F31实际42入场；X F47回满97，F48虽赢仍97→23，F49无恢复以23入场。赢战血价与真实回复、SL恢复应按实际来源分别核。',
        'counter': '药水重复SL消费不等于新获得，未来营火未到不当现有缓冲；没有同条件路线/留药/锻造结果，不能给出新安全血线。',
        'reason': '缺逐源资源消费者校准和同条件路线、留药、锻造完整后继；已观察资源端点不能拟安全血线或药价。',
        'validation': '用胜战出血与下一战入血连结真实恢复、药槽及SL恢复，核不重复记药；留出未来同角色同进阶完整后继再评估策略。',
    },
    {
        'evidence': 'BTSRF7JL1W1Y A10 F17T5/F31T2/T3；XTSV1U9JD34T A10 F48T8/F49T1—T4。',
        'finding': 'B步法、覆甲、石虫减力/眩晕及其他敌入伤分账；X末T4为1HP+6挡仍不足16来袭。F49幽灵后留挡与后来损22不证明药水应固定延后。',
        'counter': '前场毒雾、触媒、敏捷不作为后场已建立能力；已建立步法不追补旧挡，钳子上限不是每轮固定10挡。',
        'reason': '临时属性撤回、毒触发、留挡及敌成长的联合分源生产回放未齐；不将若干已有机制整包duplicate。',
        'validation': '按原临时减力/恢复、虚弱、覆甲、钳子现值逐步回放，核首个受击与其他敌伤分别结算；需补完整输入及联合消费者输出。',
    },
    {
        'evidence': '9Z9H2EXKLF3T A10 F35、F48第2/3试T7及末试T8/T10/T11；状态287989—288008。',
        'finding': '末T8第一张卡挡32；末T10三张挡18+9+10=37；末T11敌112→32与两结毒39+38及已发生3反伤相符。末T8实0→20复活单列；T7两试整轮净差省2血/多扣22不等同原预测多损7/换16伤。',
        'counter': '死亡后未发生的第二击不预支反伤；F35最大HP77→69与当前HP66→30不相加。两试含重问、药水与后继时点变化，整场仍失败。',
        'reason': '缺逐击未截断伤害、完整候选归属及受控整战后继；不能由同盘局部净差修改SL规则或持有价。',
        'validation': '固定逐张首次翻倍消费、凋萎、实际毒结算、复活及每击反伤；SL原线/替线分账并补受控后继，不以净HP替代毛伤。',
    },
    {
        'evidence': '十派发锚点及原提案引用9TG1RP5LFAAK/JQPT83P8KDSZ/S9UZAK0JP0C0；9Z9H2EXKLF3T F35/F38/F39/F42/F45/F47/F48。',
        'finding': '本次15局共22对同上限跨幕转换：A9五对、A10十七对，全部实回floor(缺HP×80%)。仅核这些真实到达的节点，没有重新研究原116局总体。9Z F47只回到27，不能预支原规划61。',
        'counter': '原投影在不同层已有新牌、上限及路线条件，不能当同条件模型误差；SL复药/复活与营火、幕间回复分别算，没有改线或锻造胜线。',
        'reason': '22对跨幕回复已核；原116局资源模型的完整历史输入、路线/休息消费者校准及独立路线收益仍缺，不能关闭整项资源请求。',
        'validation': '固定跨幕前后同上限端点及非回复控制，审计只计实际抵达节点；路线收益与房间代价仍须满足原样本门槛，不用本批22对替代完整资源校准。',
    },
    {
        'evidence': '7X0W3U8TVA2A A10 F31T13，decisions282021；states288470→288471→288472，目标后段index2。',
        'finding': '头骨组合下零毒后段实际加7毒、本体25HP保持；结束后毒结算到18HP。前段既有8毒另结、中段重接25另计；玩家1HP/14挡仍死。当前observedPoison还含恶魔完整组合入口，不能沿用“只有双Boss入口”的旧笼统表述。',
        'counter': '7毒不是即时7本体伤，更不能重复加头骨到8；没有无头骨、其他目标既有毒或人工制品对照。现有scalar入口会作用到其所有有效目标，不能用单个后段零毒观察认证全场全部目标。',
        'reason': '后段零毒实加7已核；缺其他目标、既有毒、重接组合共同推演及持有价/时点证据，不能将当前scalar入口统一扩成全局7毒。',
        'validation': '若后续扩展，必须保留目标级适用范围并冻结本组合；本体25→25→18、玩家仍死为固定核验，未知组合回未模拟选项；不反推基础药效和全局持有价。',
    },
    {
        'evidence': 'MTQ0EUBJ3R6T A10 F23四试T3及末试T5；状态288806—288812、288837—288843、288868—288874、288899—288905；资源F19/F20。',
        'finding': '四次相同T3开场10HP、敌61/41。前三次29挡/损0/净扣13；末次19挡/损8/净扣19且仍留一张防御。只证明该局少挡换出即时6伤并多损8血。',
        'counter': '原线T6判死、末线T5实死，后续抽牌/出牌已变；24/24模型死亡不是独立胜率或实盘必死证明。不能从一局设8点惩罚或禁止探索。',
        'reason': '多损8血、多扣6伤已核；缺独立A10留出和受控完整后继，不足以修改饱和探索、必死或药价门槛。',
        'validation': '固定四试原帧与药水、两毒素持牌伤及可执行牌，分别核T3和后轮；新增独立结束局作时间留出，原局不同时训练和验证权重。',
    },
    {
        'evidence': '7X0W3U8TVA2A A10 F31T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T A10 F11T1、F17T4—T8、F20T3、F23T2—T5。',
        'finding': '同局速度临时敏捷与后继挡、毒素持牌伤、实际建立能力均按原帧分源。当前蛇咬8毒预览已有固定夹具；它是卡牌观察，不能代替7X0的毒药水目标/组合校准。',
        'counter': '持有磨蚀不等于已建立；建立后不能追补旧挡或预支整战胜利。仪式兽单牌限制和药水动作分开，未见叠层不补齐。',
        'reason': '十四项机制缺逐项至联合生产消费者的完整校准；局部既有模型/夹具不足认证整个组合，保留waiting。',
        'validation': '分别冻结十四项已观察状态、属性/毒的时点及药水与卡牌来源，再接生产消费者；未知组合和其他角色维持原行为，整战收益另验。',
    },
]
assert len(proposals) == len(notes) == 10
results = [{'id': p['id'], 'state': 'waiting', 'reason': n['reason']} for p, n in zip(proposals, notes)]
save('dispositions.json', results)

header = f'''# 静默猎手派发策略提案逐项复核

记录时间：{(HERE / 'recorded-time.txt').read_text().strip()}。批次：20261016-114302-strategy-proposal。base：`{base}`。

本批仅消费learn.json派发的十个原ID。task=strategy-proposal、character=silent、reason=proposal、工作树与十锚点均匹配；没有research_request/implementation_request/proposal_repair。普通专题入口绑定另一历史批次，不套用专题身份。git status初始为空；git merge --no-edit main返回Already up to date。未派下级agent。

结论：十项均waiting；没有源码/知识改动、提交、live合入或新版本。证据支持既有窄机制及局部血价，但未补齐各原提案剩余消费者或受控后继。本报告不是新的游戏规则，也不将宽要求降成只完成一个局部实现。

## 证据方法与共同边界

共用extract_evidence.py提取十派发锚点及五个原提案引用来源。15局先逐局核runs.jsonl为SILENT；A9三局和A10十二局分开。八流共22,424条逐一seek原日志，核offset/bytes/SHA、JSON、显式所属身份、state角色/进阶和source_size；拒绝冲突身份，不把正文提及当所属局。选中原行与061302同范围两份证据集合完全一致；日志截点增大没有产生本范围新证据。fight-plans本截点0行只说明未选到，不断言日志缺失。旧截点、旧报告和失败历史保持。

原十Markdown均SHA匹配，按原字节另存`<id>.original.md`；46关联账本均本角色，linked-experience.json仅保留原提案链接的静默条目。本批不重算116局总体、不添加重复support/repeat，不借当前经验库支持计数冒充亲核局数。当前知识文本只作链接/边界对照，不作为新游戏事实来源。

材料核验57项及T3补充3项共60项通过（material-checks.json、t3-supplemental-checks.json），只验证证据端点/算式。22跨幕转换均匹配原限定公式。原源码副本仅保存必要Git提交/blob、SHA及patch，没有全仓归档。

此前12个A10离线消费者的37份输入/输出/stderr及排除材料按原artifact-sha256.json复核SHA/字节，原退出码均0；本次未重跑。六个消费者源码叶与原基线相同。本材料的原8622动作、1883题段、3109相邻端点、431可核/974未知整轮读回不等同本次生产测试；actual_full_candidate_result=null是工具保守合同，不是没有执行或策略无效的证据。

16条run-config均可定位真实源码commit；dirty_files是知识/记录，不能笼统声称源码完全不可知。冻结当时全部知识字节与联合消费者输入仍未齐，当前源码/知识不代历史完整运行输入。唯一胜局G403VCZ3BH1B属于A9，不能当A10策略验证胜线；同局SL是相关样本，不扩大独立分母。

与原结论相比，本批未发现新的机制反证。当前有污染增量、剩余毒、饱和推演的新增审计字段，仍明示current_turn_prediction和execution=unverified；不能用新增字段关闭原实际执行/逐源/联合校准要求。Roy授权允许证据充分时改规则，本次限制来自实际证据而非旧规则不可修改。

'''
sections = []
for p, n in zip(proposals, notes):
    sections.append(f'''## {p['id']}

主题：{p['summary']}。领域：{','.join(p['domains'])}。

原提案：{p['proposal']}；SHA256：`{p['proposal_sha256']}`。
账本：{','.join(p['ledger'])}。来源任务：{p['source_task']}；实现任务：strategy-proposal；授权：Roy-2026-10-07-learning。

证据局/层/回合：{n['evidence']}

支持及现有实现：{n['finding']}

反例/限定：{n['counter']}

旧规则/预期新行为：沿原提案限定的模型及事实参考范围，不固定删除选项或替Jev作喝药选择。本批保留当前行为；只有补齐以下验证才评估相应差量，不承诺胜率提升。

验证方法：{n['validation']} 若后续改源码，必须有固定夹具撤源码失败/恢复通过及原沙箱自测，并核其他角色等价；本批未实施这些源码测试。

处置：**waiting**。{n['reason']}

回退：本批没有行为差量可回退；后续实现只逆向其实际差量，保留并行知识、原记录与所有失败证据，不恢复整个旧live树。

''')
(HERE / 'proposal.md').write_text(header + '\n'.join(sections))

report = {
    'task': 'strategy-proposal', 'character': 'silent',
    'batch': '20261016-114302-strategy-proposal', 'base': base,
    'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [p['id'] for p in proposals], 'implementation_domains': [],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
save('report.json', report)
table = '\n'.join(f"| {s} | {n} |" for s, n in verification['streams'].items())
disposition_table = '\n'.join(f"| {p['id']} | {n['reason']} |" for p, n in zip(proposals, notes))
ancestor_table = '\n'.join(f"| `{a['commit']}` | {a['subject']} |" for a in load('source-audit.json')['scoped_ancestors'])
text = f'''# 静默猎手策略提案回报

本批十个派发提案均为waiting；未修改源码或知识，没有提交、live合入、新版本或shipped。完整逐项证据、账本、反例、预期行为、验证与回退见 [proposal.md](proposal.md)。

记录时间：{(HERE / 'recorded-time.txt').read_text().strip()}。批次20261016-114302-strategy-proposal，完整base/HEAD：`{base}`。初始工作树干净；普通批次合main返回Already up to date。派发身份、十ID、十锚点和工作树匹配，无research_request或implementation_request，不承接其他专题或队列。未派下级agent，未发起网络、额外LLM或游戏调用，未运行play。

## 证据与复核

共用入口提取15个本角色局，A9三局/A10十二局分列；十锚点之外五局仅来自原十提案引用。原Markdown逐份SHA匹配并保留原字节。八流共22,424条均核原offset/bytes/SHA/JSON/显式身份；state逐条核SILENT与进阶。每流source_size与产物SHA见evidence/evidence-manifest.json；raw-verification.json为实际读回回执。

| 流 | 核验条数 |
|---|---:|
{table}

选中原始行集合与061302相同；本批没把新日志截点当新证据。全源states/decisions各2条、brain1条解析失败不归到本角色选中局；fight-plans选中0行不据此断言日志缺失。旧报告和失败/零行初稿保持。

原帧材料共60项核验通过：57项端点/算式及3项T3补充，不计作生产代码测试。重点如下：

- RC61MFQM63Y6 F23T3敏捷1→6，格挡12→21→25，T4敏归0；只支持该实际触发窗，不认证八组件所有联合条件。
- XTSV1U9JD34T F49T1幽灵实际新增无实体1；T4夜魇3复制标记仍死，没有去掉夜魇/延后喝药的已核整场胜线。幽灵单层已有live实现。
- BTSRF7JL1W1Y F30赢仍70→42、F31入42；XTSV1U9JD34T F48赢仍97→23、F49实际23入场。普通单弃和毒胜前保血搜索已有live实现，完整候选/资源因果仍未闭合。
- 9Z9H2EXKLF3T F48末T8真实0→20复活，T10挡18+9+10=37，T11敌112→32与已结39+38毒和3反伤相符；死亡后的未执行击不预支，T7净差不认单因SL收益。
- 7X0W3U8TVA2A F31T13后段零毒→7，本体25保持后才结算到18，玩家仍死；既有8毒前段与中段重接25另算。仅一目标/组合实测，不反推基础药效、全局7毒或持有价。
- MTQ0EUBJ3R6T F23四试T3同10HP及敌61/41：前三次29挡/损0/净扣13，末次19挡/损8/净扣19；末次仍留防御。原线T6判死、末线T5实死，同局四试不能拟8血惩罚或独立胜率。
- 15局22对同上限跨幕转换（A9五/A10十七）均符合floor(缺HP×80%)；没有重算116局总体、校准房间/路线收益或将A9唯一胜局充作A10胜线。

此前12个A10离线消费者输入/输出/错误流等37份材料按原SHA和字节验证，原返回0；本次不重跑。消费者六源码叶与前次相同。原8622动作/1883题段/3109相邻端点及431可核、974未知整轮仅作既有材料读回；完整候选认证null不证明零执行，也不代替自然采用/联合校准。receipt见prior-consumer-artifacts-verified.json、prior-consumer-summary-readback.json。

## 当前实现边界

source-audit.json核实际live切点`{load('source-audit.json')['live_head']}`。17叶中13叶与原061302基线相同、14叶与live相同；三个不同live叶均为Roy/Dai历史注释差，保留live-source-differences.patch。相较原基线，四叶新增污染/余毒/饱和状态审计及无效果药水的审计字段排除；source-since-prior.patch保留差异，仍是预测/未验证执行，不认证新整战策略。

| 已有窄实现真实live祖先 | 范围 |
|---|---|
{ancestor_table}

这五个commit均已核本base与live祖先；只列现有子项，不能将其作为本批新增提交或全部提案duplicate。observedPoison还含恶魔组合入口，不沿用“只有双Boss”笼统缺模理由；其修饰组合不覆盖7X0后段/其他目标。未知持有价已有silent-potion-reference区分，显示成本0不等于学得留药价0。

16条run-config源码commit均存在，dirty_files为知识/记录，历史源码不是完全不可定位；但冻结全部实际知识字节和联合输入仍缺，不把当前树当当时完整运行输入。没有新增机制反经验；局部支持与整战失败分别记录，不强行支持宽策略假设。

## 十项处置

| 提案ID | waiting的具体原因 |
|---|---|
{disposition_table}

逐项账本ID、原提案SHA、局号/层/回合、反例、验证及回退均在proposal.md，本批不另建重复提案ID。code_proposals沿十个已有CLI ID，implementation_domains=[]表示没有本批实现，不丢弃原领域或待办。

## 账本、验证和交付

46个既有账本仅经根learner/ledger.py update追加本批proposal/report与复核note，by=learner:strategy-proposal；不增加重复support/repeat，不改旧claim、首证、prior、evidence、status、version、shipped/effect，不将已shipped条目降为proposed。真实CLI输入/退出与原字节读回见ledger-updates.jsonl、ledger-cli-receipt.json；队列状态由宿主消费proposal_results，本模型不手改。

没有源码修改；撤源码失败/恢复通过及tsc、vitest、sandbox均不适用、未运行，tests三个字段均null。材料核验/原消费者退出码不填为生产测试成功。fixes=[]、merged=null，没有合入提交/版本，无需空合并或上线双通知。最终clean/base与secret扫描以completion-validation.json为准；过程材料留在本scratch，不删除自身树、不归档全仓。本报告不关闭学习入库、量化或原宽父要求，不冒称已入库或大脑已采用。

运维提案路径：{HERE / 'proposal.md'}

运维报告路径：{HERE / 'report.md'}

## 最终机器回报

```json
{json.dumps(report, ensure_ascii=False, indent=2)}
```
'''
(HERE / 'report.md').write_text(text)
print(json.dumps({'report': report['report'], 'base': base, 'waiting': len(results)}, ensure_ascii=False))

import json,pathlib,collections,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(l) for l in (P/'decisions.jsonl').open()]
S=[json.loads(l) for l in (P/'states.jsonl').open()]
B=[json.loads(l) for l in (P/'brain.jsonl').open()]
def dump(v):return json.dumps(v,ensure_ascii=False)
with (P/'decision-compact.txt').open('w') as o:
 for d in D:
  x={k:d.get(k) for k in ['_line','ts','observed_ts','floor','turn','label','decider','chosen','rationale','confidence','sl_attempt','sl_reloads','journal','result']}
  o.write(dump(x)+'\n')
with (P/'brain-compact.txt').open('w') as o:
 for b in B:
  o.write(dump({k:b.get(k) for k in ['_line','ts','label','engine','model','effort','answer','usage']})+'\n')
with (P/'state-compact.txt').open('w') as o:
 for x in S:
  s=x['state'];r=s['run'];c=s.get('combat') or {}
  z={'s':x['_line'],'ts':x['ts'],'obs':x.get('observed_ts'),'f':r['floor'],'t':s['turn'],'screen':s['screen'],'hp':r['current_hp'],'max':r['max_hp'],'pot':[(p['index'],p.get('potion_id')) for p in r['potions'] if p['occupied']],'player':c.get('player'),'enemies':c.get('enemies'),'hand':c.get('hand')}
  o.write(dump(z)+'\n')
print('决策时间',D[0]['ts'],D[-1]['ts']);print('brain',collections.Counter((b['engine'],b['model'],b['effort']) for b in B))
print('journal keys',collections.Counter(k for d in D for k in (d.get('journal') or {})))
for d in D:
 if d['decider']=='codex':print(d['_line'],d['floor'],d['label'],dump(d.get('chosen')),d.get('rationale'))
for x in S[:2]: print('combat keys',list((x['state'].get('combat') or {})))
for x in S:
 if x['state'].get('combat'):
  c=x['state']['combat'];print('combat keys',list(c));print('player',dump(c.get('player')));print('enemy',dump(c.get('enemies')));break
print('brain options',str(B[-1]['options'])[:3500]);print('questions keys',D[-20]['questions'].keys())
for l in (P/'sl-attempts.jsonl').open():
 x=json.loads(l);print('SL',dump({k:x.get(k) for k in ['_line','attempt','started_at','ended_at','result','turns','end_hp','end_block','incoming','judge','reload','give_up_reason']}))

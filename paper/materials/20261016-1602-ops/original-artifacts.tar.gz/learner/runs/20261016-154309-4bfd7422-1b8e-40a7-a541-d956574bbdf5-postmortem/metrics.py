import json,pathlib,collections,datetime
P=pathlib.Path(__file__).parent
D=[json.loads(l) for l in (P/'decisions.jsonl').open()];S=[json.loads(l) for l in (P/'states.jsonl').open()];B=[json.loads(l) for l in (P/'brain.jsonl').open()]
R=json.loads((P/'DYB7KFG723QM-resources.json').read_text()); bys={x['_line']:x for x in S}
def hp(s): return s['run']['current_hp']
def eh(s): return sum(e['current_hp'] for e in (s.get('combat') or {}).get('enemies',[]) if e['is_alive'] and e['current_hp']<999999999)
def enemies(s):return [(e['name'],e['enemy_id'],e['current_hp'],e.get('powers'),e.get('move_id'),e.get('intents')) for e in (s.get('combat') or {}).get('enemies',[])]
out=[]
for c in R['combats']:
 a=c['entry']['line'];b=(c['exit'] or c['last'])['line'];rows=[x for x in S if a<=x['_line']<=b];turns=collections.OrderedDict()
 for row in rows:
  s=row['state']
  if s['in_combat']:turns.setdefault(s['turn'],[]).append(row)
 z={'seq':c['sequence'],'floor':c['floor'],'enemies':enemies(rows[0]['state']),'turns':[]}
 for t,rs in turns.items():
  first,last=rs[0],rs[-1];nxt=next((x for x in rows if x['_line']>last['_line']),None)
  isend=nxt is not None
  en0=(first['state'].get('combat') or {}).get('enemies',[]);en1=(last['state'].get('combat') or {}).get('enemies',[])
  it={'turn':t,'start_s':first['_line'],'last_s':last['_line'],'hp_start':hp(first['state']),'hp_end':hp(nxt['state']) if nxt else hp(last['state']),'hp_loss':hp(first['state'])-(hp(nxt['state']) if nxt else hp(last['state'])),'need':eh(first['state']),'last_enemy':[(e['index'],e['enemy_id'],e['current_hp']) for e in en1], 'end_observed':isend,'net_enemy_drop':eh(first['state'])-eh(nxt['state']) if nxt and nxt['state']['in_combat'] else None,'within_visible_drop':0,'observed_heal':0,'gaps':[]}
  for bef,aft in zip(rs,rs[1:]+([nxt] if nxt else [])):
   le=(bef['state'].get('combat') or {}).get('enemies',[]);re=(aft['state'].get('combat') or {}).get('enemies',[])
   for e in le:
    if sum(e['enemy_id']==q['enemy_id'] for q in le)>1:it['gaps'].append('重复ID');continue
    match=[q for q in re if q['enemy_id']==e['enemy_id']]
    if len(match)!=1:it['gaps'].append('退场缺归零');continue
    q=match[0]
    if e['max_hp']!=q['max_hp']:it['gaps'].append('阶段变更');continue
    v=e['current_hp']-q['current_hp'];it['within_visible_drop']+=max(0,v);it['observed_heal']+=max(0,-v)
  it['gaps']=sorted(set(it['gaps']));z['turns'].append(it)
 out.append(z)
(P/'turn-metrics.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for z in out:
 print('序',z['seq'],'F',z['floor'],'需',[t['need'] for t in z['turns']],'净损',[t['hp_loss'] for t in z['turns']],'净扣',[t['net_enemy_drop'] for t in z['turns']],'可见扣',[t['within_visible_drop'] for t in z['turns']],'回血',[t['observed_heal'] for t in z['turns']],'末敌',z['turns'][-1]['last_enemy'])
print('用量',{k:sum((b.get('usage') or {}).get(k,0) or 0 for b in B) for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens']},'latency',sum(b.get('latency_ms',0) for b in B))
print('时长', (datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'))).total_seconds())
auto=[d for d in D if d['decider']=='code' and not d['rationale'].startswith('continuing the Jev-chosen plan:')]
combat=[d for d in auto if d['label'].startswith('combat/') and d.get('result','').startswith('completed:')]
keys=lambda d:(d['floor'],d.get('sl_reloads',0),d['turn'])
turns=set(map(keys,combat));plans=set(map(keys,(d for d in D if d['decider']=='jev' and d['label'].startswith('combat/plan'))));alljev=set(map(keys,(d for d in D if d['decider']=='jev' and d['label'].startswith('combat/'))))
print('自主代码',len(auto),'自主战斗completed',len(combat),'回合',len(turns),'无jev选线',len(turns-plans),'无jev战斗题',len(turns-alljev),'keys',sorted(turns));print('未派发',[(d['_line'],d['result']) for d in D if not d.get('result','').startswith('completed:')])
print('F14逐帧')
for x in S:
 if 425102<=x['_line']<=425134:
  s=x['state'];c=s.get('combat') or {};print(x['_line'],'T',s['turn'],'HP',hp(s),'B',(c.get('player') or {}).get('block'),'en',[(e['index'],e['current_hp'],e.get('move_id'),e.get('powers'),e.get('intents')) for e in c.get('enemies',[])])

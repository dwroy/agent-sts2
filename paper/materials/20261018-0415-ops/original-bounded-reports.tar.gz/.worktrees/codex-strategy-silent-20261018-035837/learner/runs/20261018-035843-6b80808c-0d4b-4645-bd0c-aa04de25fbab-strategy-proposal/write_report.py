import datetime
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch.json').read_text())
items = json.loads((HERE / 'assigned-proposals.json').read_text())
source = json.loads((HERE / 'source-manifest.json').read_text())
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
details = [
    {
        'id': 'silent-proposal-c20b5139dd0dff71',
        'title': '感染棱柱技能污染与逐击血价',
        'evidence': 'DUZUBAJ3A8GP F27 T4—T6，states 274830—274839：火花3→6；T4技能污染3→6，勒紧能力不增加；T5轮初污染清空，三技能6→12→18，17挡对26意图，46→37实损9。',
        'counterexample': '技能同时施毒、施弱或给挡。该轮9损并不证明少打任意技能更优，也没有受控替线胜局。',
        'existing': 'turn-solver.ts已有技能按存活火花来源累加tainted、逐段攻击计价；rollout.ts已有selfPowers增长vitalSpark；0e4fe4df89a06682468e0e4716c12126e76369d5的资源比较会分列污染和轮末余毒，但其execution仍为unverified。',
        'reason': '已确认实盘火花/污染时点；缺历史实际移动表及火花增长、污染清空、弱、毒、格挡与迷雾收益的联合生产重放认证，尚未核出新的源码失配，不能改为强制少打技能。',
        'validation': '冻结原手牌、当前进阶移动输入和实际前缀，逐步比对污染、敌意图、毒、挡及HP；已有局部公式与日志字段不能代替整条联合链。',
    },
    {
        'id': 'silent-proposal-ae9e692d680e3819',
        'title': '失落与遗忘的抢夺来源及返还',
        'evidence': '5PM6JAQG6FNQ F39 T4—T6，states 274351—274366：首试两次步法将敏捷−4→−2→0；失落毒死前力量−4，T5只剩遗忘且力量回0；T6遗忘再夺使敏捷−2。末试274391—274397单步法仅回−2敏，失落退场仍实死。',
        'counterexample': '失落退场返力端点存在；遗忘退场返敏端点没有在本批证据中得到独立观测。玩家死亡后清空能力不能用来补该端点。',
        'existing': '当前模型读取现场负力量/敏捷参与出牌计算。这个通用路径并不认证逐来源抢夺账、死亡返还和重抢；当前没有可覆盖本提案全部职责的live源码证明。',
        'reason': '缺逐实体抢夺来源的完整归属、遗忘退场返敏端点及另一击杀顺序的整战后继；现场负属性和失落返力片段不足以实现全套返还或固定击杀序。',
        'validation': '补充活实体跨轮身份、每次夺取/返还与临时玩家增益分账；先逐步重放已观察返力，未见返敏分支保持未知，另用完整后继比较杀序。',
    },
    {
        'id': 'silent-proposal-52f1e1bd2e7db0ed',
        'title': '下水道蚌加压、弱与覆甲',
        'evidence': 'CA5KE8GFJ9X2 F13 T1—T5，states 273238—273269：加压后力量0→4→8，同喷水11→15→19，弱后15→11、19→14；轮初覆甲9/9/8/7/6，末2血10挡面对14，实死。',
        'counterexample': '现场覆甲层序不提供全部条件的受控验证；末需损4而实有2血不能归因于某张未选牌，也不能拟一个房间固定成本。',
        'existing': 'monster-db.ts的monsterHpAt读取当前进阶记录，不设五样本门槛；boss-clock.ts的silentBossFacts分列当前进阶HP/攻击与来源；room-costs.ts的MEASURED_ROOM_MIN_N仍为5。该事实读取子项已有实现。',
        'reason': '当前进阶第一观测取数已有实现且房间代价五样本门槛保留；缺加压、弱、覆甲的联合生产重放及完整减层条件，不能把已有读取子项记为整项duplicate。',
        'validation': '用该局冻结现场和实际移动输入检验连续加压/弱化；额外独立观测验证覆甲边界，不修改房间代价样本门槛。',
    },
    {
        'id': 'silent-proposal-6dd8bbff876be528',
        'title': '电击机器人的逐实体高电压成长',
        'evidence': '5PM6JAQG6FNQ F38 T2—T4，states 274307—274317：23上限ZAPBOT出现，T3力量2/意图17，T4力量4/意图19；中间STABBOT退场使index从4变3，T3该机器人仍活着参与攻击，T4群伤后才退场。',
        'counterexample': 'index重排不是新召唤代次；同类id和max_hp也不是唯一实例GUID。另一杀序35伤/损3只是未实打候选，不能推能救下一场。',
        'existing': 'rollout.ts的STRENGTH_GROWTH_POWERS包含HIGH_VOLTAGE_POWER，按每个模拟实体e.growth增力；已有召唤模板接线，但本批没有原实际移动输入的完整联合认证。',
        'reason': '现有逐实体高电压增长路径已在；缺可靠召唤代际身份、历史实际移动输入及另一目标顺序的完整后继，不能从index变化新增继承或清零规则。',
        'validation': '冻结连续原帧及召唤/退场输入，按真实代次核对index重排和新实体初始值；完整比较召唤者/爪牙杀序，不仅看当轮候选。',
    },
    {
        'id': 'silent-proposal-578e415a259e6835',
        'title': '沙虫SL、护栏与已兑现资源',
        'evidence': '8JRE1C4H4Z2W F33首/第三试T2，decisions 270216/270282完整fingerprint相同；states 276208→276212和276274→276278，实损3→15、本体净进度10→17。第二试T5 decision270264候选16/43被护栏换为4/25，后续实际执行需另连；末T11 states276429—276434仍死亡。',
        'counterexample': '首试题面rollout为8样本，第三试24样本；第三试同题原/替线0/24与5/24死亡可核，不是两个尝试都0/24。候选护栏差不是实际保血收益，末次延至T11仍非胜局。',
        'existing': '9d8278702dbc581b5015ba7ec9a70dc0fb94cccb保留选择阶段，66283dd9982bdd7f480da7a4d9bfefea0572a9ac保留护栏/SL候选差，0e4fe4df89a06682468e0e4716c12126e76369d5保留血价/沙坑；actual_turn/actual_outcome仍null。',
        'reason': '已有选择阶段、护栏和资源预测局部审计；缺跨抽弃牌重规划的完整候选执行归属、沙坑与路线资源链联合认证；当前同盘材料不支持修改探索或血价系数。',
        'validation': '把answer→guard→SL→首次派发→重规划逐段关联到原观测和尝试身份；预测、完整需损、零血截断、SL恢复及真实回血分列，再做后移独立局校准。',
    },
    {
        'id': 'silent-proposal-c0767768bf6a7ab1',
        'title': '实验体全败SL替换与续步截断',
        'evidence': 'YF0LXT1QSTGG F48第二/第三试T1，decisions 271309/271348同指纹。原/替候选预测HP损0/10、伤54/36；states277327→277337与277366→277373实损0/9、本体净进度45/38。271354还把抽牌后可打挡的续步替成end_turn。',
        'counterexample': '本局F33第二试SL实际胜利；F48第六试恢复挡续步后T1零损仍失败，不能禁止全部SL或把当前多9血写成独立整战胜因。',
        'existing': 'silent-sl-comparison.ts和silent-sl-resource-comparison.ts已分列预测差、抽牌重规划、未知项，明确actual_turn_result=null、execution=unverified；不能用这两个字段存在认证候选已完整执行。',
        'reason': '当轮实际0/9与45/38已核，预测事实已有窄实现；缺原线/替线完整执行归属、逐来源血价认证与独立受控整战胜线，保留探索和惩罚参数。',
        'validation': '固定原答、替换、抽牌后avoid与实际动作；同时核候选0/10、54/36和实际0/9、45/38，保留成功SL反例，未执行续步不补记收益。',
    },
    {
        'id': 'silent-proposal-a46bdb7fe711d79a',
        'title': '实验体分阶段毒与敏捷收益',
        'evidence': 'YF0LXT1QSTGG F48末试T3—T5，states277512→277513从4/111HP、4毒换成212/212HP、0毒。277519触媒2而0毒；277524在5敏时23挡，277526加至6敏仍23挡；197→160净扣37，末18血面对44攻/23挡，完整需损21、缺3。',
        'counterexample': '前五试有已建毒雾/余像仍失败，不能把未启动毒写成唯一死因。实际37净扣含消耗额外扣血，不全归小刀牌面。',
        'existing': 'aad2700abed6dff1d66e87fb36aaa6fedb39adf3已向真实问题接入当前阶段HP/毒、持有组件及已建触媒/毒雾快照，poison_damage_already_dealt仍null；1d57f9d0dbbb63603e9ce9768e74cb2021478464提供阶段结束参考。',
        'reason': '当前阶段/持有/已建能力快照已有live实现；逐候选施毒、毒结算、遗忘之魂额外扣血及敏捷取得顺序尚缺完整执行归属，不能据持有组件或零毒末态调整排序。',
        'validation': '逐阶段建立候选前缀到实际动作的来源账；分列直接伤害、额外扣血、已结算毒和未来毒，后取得敏捷不回填旧挡；保持其他角色/未观察阶段等价。',
    },
    {
        'id': 'silent-proposal-1044224808015e5c',
        'title': '双蟹B2零胜并列的SL血价',
        'evidence': 'XP2SL33HT0D9 F33首/第二试T3，decisions271992/272040同指纹，实损9→14、净扣24→27。首/第六试T1 decisions271982/272195同指纹，实损2→10、净扣25→34；T1替线同时取得手里剑力量，不能只计HP。',
        'counterexample': '同指纹的T3题面rollout样本8→24，B2分别459/600和199/1200且超时，不是同预算完整配对。两线均没有整战实胜；末试T2/T3借减力、朝向和挡降低损血，不能一律否定付血探索。',
        'existing': '当前explore.ts仍按B2不更差集合和既有排名探索，rankByOrder保留并列后rollout分辨；现有资源/选择审计已有当前代价字段，实际结果不冒填。',
        'reason': '当轮+5血/+3进度与+8血/+9进度已核；缺同抽序/随机/预算的完整替线、成长兑现后继和独立整战胜线，B2的0差不能当作风险相同或据此拟新优先级。',
        'validation': '固定同题所有候选及原B2预算/样本，控制随机和后续抽序，保留成长与临时防御收益；本局只作发现/固定复核，后移独立局验证选线规则。',
    },
    {
        'id': 'silent-proposal-7cbc6005db712ba9',
        'title': '双蟹朝向、临时减力与能力兑现窗口',
        'evidence': 'XP2SL33HT0D9 F33末试T2 states278236—278242：船夹板14挡、镣铐0→−9力且下一轮回0，斗篷再6成20且零损；T4 278249→278252→278253激光57→38→28；4敏脆弱下偏折给6挡，T5 3+7毒后仍死。',
        'counterexample': '已建立两步法和手里剑成长仍未减员，不提供能力强制优先级；本批只直接核末试普通镣铐，不借原提案引用的更早角色局宣称本批重新覆盖升级全条件。',
        'existing': '现场格挡、临时减力恢复、朝向/弱、遗物轮初挡已有求解/推演路径；passive-pieces.ts记录HORN_CLEAT_BLOCK=14、TURN=2。本批未发现一个有完整实盘输入、能证当前生产输出错误的新失配。',
        'reason': '朝向/弱、临时减力、轮初挡与后取得成长的局部事实已核且已有窄实现；缺逐候选完整联合执行及消费者认证，不能把公式/字段存在记成整项duplicate或改持续价值权重。',
        'validation': '冻结57→38→28、14+6、0→−9→0和脆弱4敏6挡的联合前缀；分开当前挡与新增挡、抽牌重规划、已结算毒和未来毒，不重拟权重。',
    },
    {
        'id': 'silent-proposal-c59f592f1427a67e',
        'title': '两局综合资源、临时防御与SL分账',
        'evidence': 'YF0LXT1QSTGG F48 T1/T4/T5及XP2SL33HT0D9 F33 T1—T5。四组本批同盘对照分别为沙虫+12血/+7进度、实验体+9血/−7进度、双蟹T3+5血/+3进度、双蟹T1+8血/+9进度；其中本综合提案原证据仅后两局，沙虫只归578e提案，不扩大本条runs。',
        'counterexample': '两局有成功前段战斗和SL，也有已建能力仍死亡、候选抽弃牌后未完成；不能把SL重置算回血、把恢复药水算新取得，或用两局全败拟留药/路线固定阈值。',
        'existing': '既有30个关联账本、25个选定Silent经验条目与上述窄源码共同提供局部证据；经验status=shipped不等于综合代码提案implemented。当前没有覆盖所有资源来源及完整候选寿命的源码认证。',
        'reason': '缺逐来源资源账、完整候选执行、路线/休息和药水时机的受控替线联合认证；本批仅重新核原两局关键资源窗，未重做原101局历史机制审计，不以旧宽支持数冒覆盖。',
        'validation': '按run/尝试/观测分账胜战损血、回血、SL恢复、用药与药水恢复，再连候选到实际前缀；只有受控独立后继支持时另实现规则，不关闭路线/药水宽父。',
    },
]
assert {x['id'] for x in details} == {x['id'] for x in items}
by_id = {x['id']: x for x in items}
now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
results = [{'id': x['id'], 'state': 'waiting', 'reason': x['reason']} for x in details]
(HERE / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
(HERE / 'proposal-analysis.json').write_text(json.dumps(details, ensure_ascii=False, indent=2) + '\n')

report = [
    '# 静默策略提案批次核验报告',
    f'记录时间：{now}。batch：20261018-035837-strategy-proposal；角色silent；独立完成，无下级agent。',
    f'结论：派发10项全部waiting。未发现足以支持新增策略源码的已核实失配；无源码/知识修改、无提交、无合入、无行为发布号。base={dispatch["base"]}，fixes=[]，merged=null。',
    '## 身份、边界与输入',
    '已先核干净工作树，读取README、STATE-2026-10-18、decision-log末尾、learning-protocol及learning-code-proposals。根learn.json本批为task=strategy-proposal、character=silent、reason=proposal，工作树及六局精确匹配；有10个proposal_ids，无proposal_repair、research_request或implementation_request。根notes/strategy-research-silent.json绑定旧批20261010-150327，故不承接专题、不读其他专题、不扩队列。普通流程git merge --no-edit main返回Already up to date，HEAD保持base。',
    '只分析本角色六局、其原提案、30个关联账本和knowledge/characters/silent中25个提案所链经验；不读其他角色知识，不使用预训练游戏知识。六局runs.jsonl均SILENT/A10，均非胜利；六次同存档SL不扩成独立局。旧原提案的跨进阶/支持次数只作原范围说明，本批未复做全历史审计。',
    '十份原Markdown全部存在，逐份SHA与专用队列一致，保存在original-proposals/及original-proposal-manifest.json；未改写原提案、复盘、claim、首证、历史或专用队列。dispatch.json、assigned-proposals.json、run-identities.json、ledger-before.json、selected-experience.json保存身份和读取快照。',
    '## 原始证据提取与复核',
    '按任务指定共用learner/extract_evidence.py提取八流：4062 states、3941 decisions、38 sl-attempts、6 run-config、33 run-plans、188 brain、6 runs、0 fight-plans，共8274条。evidence/evidence-manifest.json逐流保存冻结source_size、计数和输出SHA；每条保存物理行号/offset/bytes/SHA及原JSON。analyze_evidence.py verify已逐条回读原日志核bytes、SHA、JSON、归局无冲突、截点和输出SHA，见raw-verification.json。',
    '各源流独立在开始读取时冻结截点，未声称八流同一原子时刻。states、decisions、brain源流各有2条JSON坏行，未被接纳到本批；不推断它们属于六局。fight-plans只表示当前冻结截点选中0行，不表示历史缺失。run-plans按run字段归局，不以正文提及当归属；其余按明确run_id/state.run_id/fingerprint.run，冲突拒收。',
    'focused-states.jsonl含1060个关键层战斗状态；turn-segments.json按连续run/floor/turn分185段，仅用于定位，不将连续段自动当SL尝试。key-decisions.json保存16个关键决策的原答/候选/替换/动作及时间。check_observations.py的29项材料复算全部通过，见material-checks.json；这不是生产源码红绿测试、模拟器整战或自然消费者验收。',
    '## 配对事实及推断限制',
    '| 本批来源 | 层/回合、决策 | 实际当轮损血 原→替 | 本体净进度 原→替 |',
    '|---|---|---|---|',
    '| 8JRE1C4H4Z2W | F33 T2；270216/270282 | 3→15 | 10→17 |',
    '| YF0LXT1QSTGG | F48 T1；271309/271348 | 0→9 | 45→38 |',
    '| XP2SL33HT0D9 | F33 T3；271992/272040 | 9→14 | 24→27 |',
    '| XP2SL33HT0D9 | F33 T1；271982/272195 | 2→10 | 25→34 |',
    '四对完整fingerprint各自相同，逐帧计算和精确来源在paired-observations.json。净进度包括该轮已结算毒和其他扣血，不等于纯卡牌直伤；配对只认证当轮两次实际状态差。原/替整段候选会在抽牌、弃牌、用药、SL/护栏后重规划，未认证全部续步执行，未来抽序/随机/计算预算也未控制。',
    '新增明确限制：沙虫首试T2题面为8样本，第三试24；第三试同题原/替候选才是0/24与5/24死亡。双蟹T3首/第二试题面rollout 8/24，B2完成459/600与199/1200且均标time limit。同指纹不代表同推演预算或完整受控配对；不能把B2显示0和标准误0解读为风险相同。',
    '## 当前源码与live祖先',
    f'固定比较base={source["base"]}、只读live={source["live_at_read"]}。source/保存15个相关生产源码原字节.txt，source-manifest.json保存SHA256、Git blob、最后来源commit及live祖先核验；另存3个不同叶的live原字节和base-live.patch。三叶差异逐字仅Roy→Dai名称替换，未把字节不同冒称完全同树。',
    '所有15个最后来源commit均为该live提交祖先。这只认证相关源码来源，不认证各宽提案完整实现。主要局部来源：9d8278702dbc581b5015ba7ec9a70dc0fb94cccb（选择阶段）；66283dd9982bdd7f480da7a4d9bfefea0572a9ac（护栏/SL预测）；0e4fe4df89a06682468e0e4716c12126e76369d5（SL资源/沙坑）；aad2700abed6dff1d66e87fb36aaa6fedb39adf3（阶段当前快照）；1d57f9d0dbbb63603e9ce9768e74cb2021478464（阶段结束参考）。均不据此将整项置duplicate/implemented。',
    '怪物当前进阶事实读取无需房间五样本门槛；room-costs.ts保留MEASURED_ROOM_MIN_N=5。没有读取或冻结当时dirty运行树的完整实际数据库/模型输入，不能以当前刷新数据替代历史运行输入。',
    '## 逐项处置',
]
for n, detail in enumerate(details, 1):
    item = by_id[detail['id']]
    report.extend([
        f'### {n}. {detail["id"]}：{detail["title"]}',
        f'账本：{", ".join(item["ledger"])}。原提案：{item["proposal"]}。原链接经验：{", ".join(item.get("experience", [])) or "见账本关联"}。',
        '本次核实：' + detail['evidence'],
        '反例/未知：' + detail['counterexample'],
        '既有源码范围：' + detail['existing'],
        '**waiting：**' + detail['reason'],
        '预期行为与验证：保留原选择、排序、选项及未观察条件。' + detail['validation'],
    ])
report.extend([
    '## 记录、测试及上线状态',
    '未新增代码提案id、不重写原提案、不重复复盘或新增support/repeat。只经根learner/ledger.py update为本批30个关联账本追加本批proposal.md/report.md链接与waiting说明，by=learner:strategy-proposal；原status（含既有shipped）、claim、证据、首证、prior、版本和effect保持，不能将旧经验shipped当本提案实现。CLI输入/输出和保护字段复核见ledger-updates.jsonl、ledger-update-result.txt、ledger-link-check.json。专用队列的10项最终处置由原调度器消费proposal_results，不手改队列状态。',
    '没有生产源码/知识变更，故不运行tsc、vitest或撤源码试验，不造红绿结果；tests固定为{"tsc":null,"vitest":null,"cases":null}。29项为材料校验，不能填进tests.cases。无提交，提交前gitleaks要求不触发；未为合法waiting冒造提交、merge、eval版本、shipped或规则通知。',
    '未执行live合入流程，merged=null，无合入提交/版本。各角色行为保持原样。base-working-tree.patch为空；最终HEAD和git状态核回保存在final-verification.json。原证据、脚本、报告和失败/未知均保留，不清理自身工作树。',
    '后续只在获得各条具体缺口的新数据或完整认证后沿原id接续；本批报告、waiting和排队不关闭学习父要求，也不等于经验已入库或大脑已采用。预期影响仅为真实处置/证据/源码范围可追溯，无胜率提升断言；本批没有行为提交可回退，若未来实现则回退其真实源码commit并按授权双通知Roy。',
    f'运维交付：{HERE / "proposal.md"}；完整回报：{HERE / "report.json"}。',
])
(HERE / 'report.md').write_text('\n\n'.join(report) + '\n')

proposal = ['# 本批十项既有策略提案的证据与处置',
            f'batch=20261018-035837-strategy-proposal；silent/A10；base={dispatch["base"]}。',
            '本次没有新提案或源码修改。十份原提案原字节保存在original-proposals/，SHA逐项匹配。完整原行为/预期行为、账本、局号/层/回合、反例、限制及验证见report.md逐项章节及proposal-analysis.json。',
            '本次结论全部waiting；不把局部公式/审计已有实现冒称整项完成，不新增策略参数、固定击杀序、探索限制或药水/路线阈值。']
for x in details:
    item = by_id[x['id']]
    proposal.extend([f'## {x["id"]}：{x["title"]}',
                     f'账本：{", ".join(item["ledger"])}。来源局：{", ".join(item["runs"])}。',
                     x['evidence'], '反例：' + x['counterexample'],
                     'waiting：' + x['reason'], '验证：' + x['validation']])
proposal.extend(['材料校验：八流8274条原引用逐offset/bytes/SHA/归局核回，29项材料复算通过；生产tsc/vitest/撤源码红绿均未运行、无合入/版本。',
                 '不改变游戏行为，无源码回退项。后续实现沿原id补齐固定输入、负控与生产验证；真正上线才登记版本/通知并由ops核shipped。'])
(HERE / 'proposal.md').write_text('\n\n'.join(proposal) + '\n')

ledger_ids = list(dict.fromkeys(i for p in items for i in p['ledger']))
with (HERE / 'ledger-updates.jsonl').open('w') as handle:
    for ident in ledger_ids:
        linked = [d['id'] for d in details if ident in by_id[d['id']]['ledger']]
        update = {'id': ident, 'by': 'learner:strategy-proposal',
                  'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                  'note': '20261018-035837-strategy-proposal核回：' + ','.join(linked) +
                          '均waiting。原提案SHA、本角色六局八流8274行和29项材料复算已核；局部源码祖先不当整项实现，具体缺口见本批逐项报告。仅补追溯，不新增support/repeat，不改变claim/首证/prior/status/version/effect。'}
        handle.write(json.dumps(update, ensure_ascii=False) + '\n')
final = {
    'task': 'strategy-proposal', 'character': 'silent',
    'batch': '20261018-035837-strategy-proposal', 'base': dispatch['base'],
    'runs': dispatch['dispatch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [p['id'] for p in items],
    'implementation_domains': ['combat', 'sl', 'structure'],
    'proposal_results': results, 'report': str(HERE / 'report.md'),
}
(HERE / 'report.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(HERE / 'report.md'), 'proposal_results': len(results), 'ledger_links': len(ledger_ids)}, ensure_ascii=False))

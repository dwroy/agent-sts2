import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
states = {x['line']: x for x in map(json.loads, (HERE / 'focused-states.jsonl').open())}
decisions = {x['line']: x for x in json.loads((HERE / 'key-decisions.json').read_text())}
checks = []


def check(name, actual, expected, lines, stream='states'):
    checks.append({'name': name, 'actual': actual, 'expected': expected,
                   'passed': actual == expected, 'stream': stream, 'lines': lines})


def ep(line, key, index=0):
    return states[line]['enemies'][index]['powers'].get(key, 0)


def pp(line, key):
    return states[line]['powers'].get(key, 0)


def body(line):
    return sum(e['hp'] for e in states[line]['enemies'])


pairs = []
for name, ds, start_a, next_a, start_b, next_b, expected in [
    ('沙虫T2首试与第三试', [270216, 270282], 276208, 276212, 276274, 276278, [12, 7]),
    ('实验体T1第二与第三试', [271309, 271348], 277327, 277337, 277366, 277373, [9, -7]),
    ('双蟹T3首试与第二试', [271992, 272040], 278028, 278031, 278076, 278079, [5, 3]),
    ('双蟹T1首试与第六试', [271982, 272195], 278017, 278023, 278231, 278236, [8, 9]),
]:
    check(name + '完整日志指纹相同', decisions[ds[0]]['fingerprint'] == decisions[ds[1]]['fingerprint'], True, ds, 'decisions')
    for start, end in [(start_a, next_a), (start_b, next_b)]:
        assert states[start]['run_id'] == states[end]['run_id']
        assert states[start]['floor'] == states[end]['floor']
        assert states[start]['turn'] + 1 == states[end]['turn']
        assert [(e['id'], e['max_hp']) for e in states[start]['enemies']] == [(e['id'], e['max_hp']) for e in states[end]['enemies']]
    a = {'hp_loss': states[start_a]['hp'] - states[next_a]['hp'], 'body_progress': body(start_a) - body(next_a)}
    b = {'hp_loss': states[start_b]['hp'] - states[next_b]['hp'], 'body_progress': body(start_b) - body(next_b)}
    delta = [b['hp_loss'] - a['hp_loss'], b['body_progress'] - a['body_progress']]
    check(name + '实际当轮血价与本体净进度差', delta, expected, [start_a, next_a, start_b, next_b])
    pairs.append({'name': name, 'run': states[start_a]['run_id'], 'floor': states[start_a]['floor'],
                  'turn': states[start_a]['turn'], 'decision_lines': ds,
                  'state_lines': [start_a, next_a, start_b, next_b],
                  'original': a, 'replacement': b, 'delta': delta,
                  'limit': '本体净进度包含该轮已结算毒等来源；未认证整个候选持续执行、未控制后续抽序，不估计整战因果。'})

check('棱柱火花3到6', [ep(274830, 'VITAL_SPARK_POWER'), ep(274834, 'VITAL_SPARK_POWER')], [3, 6], [274830, 274834])
check('污染按技能累积且能力不加', [pp(n, 'TAINTED_POWER') for n in [274831, 274832, 274833, 274834, 274836, 274837, 274838]], [3, 3, 6, 0, 6, 12, 18], [274831, 274832, 274833, 274834, 274836, 274837, 274838])
check('棱柱该轮实损9', states[274834]['hp'] - states[274839]['hp'], 9, [274834, 274839])
check('失落毒退场时玩家返力', [pp(274357, 'STRENGTH_POWER'), pp(274358, 'STRENGTH_POWER')], [-4, 0], [274357, 274358])
check('遗忘后续重夺敏捷', [pp(274358, 'DEXTERITY_POWER'), pp(274362, 'DEXTERITY_POWER')], [0, -2], [274358, 274362])
check('蚌两次加压', [ep(n, 'STRENGTH_POWER') for n in [273247, 273252, 273263]], [0, 4, 8], [273247, 273252, 273263])
check('蚌喷水现场与虚弱', [states[n]['enemies'][0]['attacks'] for n in [273238, 273252, 273254, 273263, 273268]], [[11], [15], [11], [19], [14]], [273238, 273252, 273254, 273263, 273268])
check('蚌覆甲已观察轮初序列', [ep(n, 'PLATING_POWER') for n in [273238, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273238, 273247, 273252, 273258, 273263])
check('电击机器人连续帧力量与意图', [(ep(n, 'STRENGTH_POWER', i), states[n]['enemies'][i]['attacks']) for n,i in [(274308,4),(274313,3)]], [(2,[17]),(4,[19])], [274308, 274313])
check('敌人退场后index重排', [states[n]['enemies'][i]['index'] for n,i in [(274308,4),(274313,3)]], [4,3], [274308,274313])
check('实验体阶段血量和毒重置', [(states[n]['enemies'][0]['hp'], states[n]['enemies'][0]['max_hp'], ep(n,'POISON_POWER')) for n in [277512,277513]], [(4,111,4),(212,212,0)], [277512,277513])
check('零毒与已建触媒分列', [ep(277519,'POISON_POWER'), pp(277519,'ACCELERANT_POWER')], [0,2], [277519])
check('敏捷后取得没有补既有挡', [(pp(n,'DEXTERITY_POWER'),states[n]['block']) for n in [277524,277526]], [(5,23),(6,23)], [277524,277526])
check('实验体末轮净扣37与生存缺3', [body(277519)-body(277527),44-states[277527]['block']-states[277527]['hp']], [37,3], [277519,277527])
check('船夹板轮初与本轮挡分列', [states[278236]['block'],states[278240]['block']], [14,20], [278236,278240])
check('镣铐临时减力并恢复', [ep(278236,'STRENGTH_POWER'),ep(278237,'STRENGTH_POWER'),ep(278242,'STRENGTH_POWER')], [0,-9,0], [278236,278237,278242])
check('双蟹朝向和虚弱分别减伤', [states[n]['enemies'][1]['attacks'][0] for n in [278249,278252,278253]], [57,38,28], [278249,278252,278253])
check('双蟹脆弱下4敏捷与6挡', [pp(278255,'DEXTERITY_POWER'),pp(278255,'FRAIL_POWER'),states[278255]['block']], [4,2,6], [278255])
check('双蟹末轮毒扣与实际死亡', [body(278260)-body(278261),states[278261]['hp']], [10,0], [278260,278261])
check('沙虫第三试同题两候选死亡数分列', ['rollout dead 0/24' in decisions[270282]['sl_explore']['numbers']['original'], 'rollout dead 5/24' in decisions[270282]['sl_explore']['numbers']['replacement']], [True,True], [270282], 'decisions')
check('沙虫相同指纹题目预算不同', [int(re.search(r'\((\d+) samples\)', decisions[n]['plans']['plan1']['rollout']).group(1)) for n in [270216,270282]], [8,24], [270216,270282], 'decisions')

proposals = json.loads((HERE / 'assigned-proposals.json').read_text())
originals = []
for p in proposals:
    data = (HERE / 'original-proposals' / (p['id'] + '.md')).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == p['proposal_sha256']
    originals.append({'id': p['id'], 'source': p['proposal'], 'sha256': digest, 'bytes': len(data)})
(HERE / 'original-proposal-manifest.json').write_text(json.dumps(originals, ensure_ascii=False, indent=2) + '\n')
(HERE / 'paired-observations.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
result = {'scope': '仅材料复算；没有运行生产模拟器、tsc或vitest，不是消费者/整战认证',
          'checks': checks, 'passed': sum(x['passed'] for x in checks), 'total': len(checks)}
(HERE / 'material-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'total': result['total'], 'failures': [x for x in checks if not x['passed']]}, ensure_ascii=False))
assert result['passed'] == result['total']

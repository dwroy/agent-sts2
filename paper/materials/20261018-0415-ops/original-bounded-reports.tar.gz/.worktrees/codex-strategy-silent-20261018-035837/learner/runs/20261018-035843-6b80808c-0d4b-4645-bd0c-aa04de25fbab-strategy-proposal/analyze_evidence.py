import argparse
import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FOCUS = {
    'DUZUBAJ3A8GP': {27},
    '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48},
    'XP2SL33HT0D9': {33},
}


def rows(name):
    with (HERE / 'evidence' / f'{name}.evidence.jsonl').open() as handle:
        for line in handle:
            yield json.loads(line)


def powers(raw):
    return {p['power_id']: p.get('amount') for p in raw or []}


def compact_states():
    selected = []
    for item in rows('states'):
        row = item['row']
        state = row.get('state') or {}
        run = state.get('run') or {}
        if run.get('floor') not in FOCUS[item['run_id']]:
            continue
        combat = state.get('combat') or {}
        player = combat.get('player') or {}
        if not player:
            continue
        selected.append({
            'line': item['line'], 'run_id': item['run_id'], 'floor': run['floor'],
            'turn': state.get('turn'), 'screen': state.get('screen'),
            'in_combat': state.get('in_combat'),
            'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
            'hp': player.get('current_hp'), 'block': player.get('block'),
            'energy': player.get('energy'),
            'cards_played': player.get('cards_played_this_turn'),
            'powers': powers(player.get('powers')),
            'enemies': [{
                'index': e.get('index'), 'id': e.get('enemy_id'),
                'hp': e.get('current_hp'), 'max_hp': e.get('max_hp'),
                'block': e.get('block'), 'alive': e.get('is_alive'),
                'move': e.get('move_id'), 'powers': powers(e.get('powers')),
                'attacks': [i.get('total_damage') for i in e.get('intents', [])
                            if i.get('total_damage') is not None],
            } for e in combat.get('enemies', [])],
            'hand': [c.get('card_id') + ('+' if c.get('is_upgraded') else '')
                     for c in combat.get('hand', [])],
        })
    with (HERE / 'focused-states.jsonl').open('w') as handle:
        for item in selected:
            handle.write(json.dumps(item, ensure_ascii=False) + '\n')
    groups = []
    for item in selected:
        key = (item['run_id'], item['floor'], item['turn'])
        if groups and groups[-1]['key'] == key:
            groups[-1]['last'] = item
            groups[-1]['count'] += 1
        else:
            groups.append({'key': key, 'first': item, 'last': item, 'count': 1})
    (HERE / 'turn-segments.json').write_text(json.dumps(groups, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'focused_states': len(selected), 'contiguous_turn_segments': len(groups)}))


def verify():
    manifest = json.loads((HERE / 'evidence' / 'evidence-manifest.json').read_text())
    verified = []
    for stream in manifest:
        name = stream['stream']
        counts = collections.Counter()
        digest = hashlib.sha256()
        handles = {}
        try:
            for encoded in (HERE / 'evidence' / f'{name}.evidence.jsonl').open('rb'):
                digest.update(encoded)
                item = json.loads(encoded)
                path = item['source']
                if path not in handles:
                    handles[path] = open(path, 'rb')
                handle = handles[path]
                handle.seek(item['offset'])
                raw = handle.read(item['bytes'])
                assert len(raw) == item['bytes']
                assert raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                row = item['row']
                fp = row.get('fingerprint')
                if isinstance(fp, str):
                    try:
                        fp = json.loads(fp)
                    except ValueError:
                        fp = None
                values = [row.get('run_id'), row.get('run'),
                          (row.get('state') or {}).get('run_id'),
                          fp.get('run') if isinstance(fp, dict) else None]
                identities = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
                assert identities == {item['run_id']}
                assert item['run_id'] in FOCUS
                assert item['offset'] + item['bytes'] <= stream['source_size']
                counts[item['run_id']] += 1
        finally:
            for handle in handles.values():
                handle.close()
        assert digest.hexdigest() == stream['output_sha256']
        assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
        verified.append({'stream': name, 'verified_rows': sum(counts.values()),
                         'counts': dict(counts), 'source_size': stream['source_size'],
                         'output_sha256': digest.hexdigest()})
    result = {'scope': '材料逐行校验，不是生产源码测试或消费者认证',
              'verified_rows': sum(s['verified_rows'] for s in verified), 'streams': verified}
    (HERE / 'raw-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['states', 'verify'])
    args = parser.parse_args()
    compact_states() if args.mode == 'states' else verify()

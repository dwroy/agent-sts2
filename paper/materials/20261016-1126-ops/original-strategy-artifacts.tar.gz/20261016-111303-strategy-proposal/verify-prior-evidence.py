import hashlib
import importlib.util
import json
import subprocess
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261016-093211/learner/runs/20261016-093215-c42c868a-6fea-42b0-aef4-0752dcda9190-strategy-proposal'
RUNS = set(json.loads((HERE / 'dispatch.json').read_text())['entry']['runs'])


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def git(*args, cwd=WORKTREE):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()


spec = importlib.util.spec_from_file_location('extract', WORKTREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
verified = []
states = {}
decisions = {}
for path in sorted((PRIOR / 'evidence').glob('*.evidence.jsonl')):
    stream = path.name.removesuffix('.evidence.jsonl')
    source = ROOT / 'logs' / (stream + '.jsonl')
    counts = Counter()
    with source.open('rb') as original, path.open() as records:
        for line in records:
            envelope = json.loads(line)
            assert envelope['source'] == str(source)
            original.seek(envelope['offset'])
            raw = original.read(envelope['bytes'])
            assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
            row = json.loads(raw)
            assert row == envelope['row']
            identity = extract.run_identity(row)
            assert identity == envelope['run_id'] and identity in RUNS
            counts[identity] += 1
            if stream == 'states':
                states[envelope['line']] = envelope
            if stream == 'decisions':
                decisions[envelope['line']] = envelope
    verified.append({'stream': stream, 'source': str(source), 'counts': dict(counts),
                     'selected_rows': sum(counts.values()), 'prior_envelope_path': str(path),
                     'prior_envelope_sha256': sha(path), 'raw_offset_bytes_sha_json_identity': True})
save('raw-prior-verification.json', verified)

paths = [item['path'] for item in json.loads((PRIOR / 'source-audit.json').read_text())['files']]
paths += ['agent/src/reflex/silent-sl-resource-comparison.ts', 'agent/src/reflex/silent-sl-comparison.ts',
          'agent/src/reflex/silent-selection-dispatch.ts', 'agent/src/reflex/silent-held-loss.ts',
          'agent/src/hand/loop.ts', 'agent/src/sim/route-projection.ts']
source_facts = []
live = ROOT / '.worktrees/live'
for path in paths:
    source_facts.append({'path': path, 'base_blob': git('rev-parse', 'HEAD:' + path),
                         'sha256': sha(WORKTREE / path), 'prior_working_sha256': sha(PRIOR.parents[2] / path),
                         'live_blob': git('rev-parse', 'HEAD:' + path, cwd=live),
                         'live_working_sha256': sha(live / path)})
commits = [item['commit'] for item in json.loads((PRIOR / 'source-audit.json').read_text())['commits']]
commits += ['1698adc96ba434a46942321e0237b70657e625b2', '66283dd9982bdd7f480da7a4d9bfefea0572a9ac']
ancestor_facts = []
for commit in dict.fromkeys(commits):
    ancestor_facts.append({'commit': commit,
                          'base_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, 'HEAD'], cwd=WORKTREE).returncode == 0,
                          'live_ancestor': subprocess.run(['git', 'merge-base', '--is-ancestor', commit, 'HEAD'], cwd=live).returncode == 0})
save('source-audit.json', {'base': git('rev-parse', 'HEAD'), 'live_head': git('rev-parse', 'HEAD', cwd=live),
                          'files': source_facts, 'commits': ancestor_facts})

receipts = json.loads((PRIOR / 'offline-consumer-results.json').read_text())
reused = []
for item in receipts:
    name = item['name']
    files = []
    for suffix, field in [('.input.json', 'input_sha256'), ('.audit.json', 'output_sha256'), ('.audit.stderr.txt', 'stderr_sha256')]:
        path = PRIOR / (name + suffix)
        actual = sha(path)
        assert actual == item[field]
        files.append({'path': str(path), 'sha256': actual, 'bytes': path.stat().st_size})
    reused.append({'name': name, 'prior_exit_code': item['exit_code'], 'rerun_this_batch': False, 'files': files})
save('prior-consumer-readback.json', {'source_task': str(PRIOR), 'checks': reused,
                                    'current_audit_source_matches_prior': all(i['sha256'] == i['prior_working_sha256'] for i in source_facts if i['path'].startswith('learner/')),
                                    'summary': json.loads((PRIOR / 'offline-summary.json').read_text())})

want = [283391, 283396, 283397, 283502, 283506, 283507, 285315, 285320, 285321,
        285491, 285496, 285497, 284817, 284821, 284743, 284744, 284753, 284754,
        284748, 284749, 284730, 284761, 284766, 284630, 284631, 286163, 286170,
        286173, 286174, 284407, 284408]
save('key-state-envelopes.json', [states[i] for i in want])
save('key-decision-envelopes.json', [decisions[i] for i in [279021, 279197, 279852, 279854]])
print(json.dumps({'verified_original_rows': sum(i['selected_rows'] for i in verified),
                  'source_files': len(source_facts), 'prior_consumer_artifacts_verified': len(reused) * 3,
                  'new_consumer_runs': 0}, ensure_ascii=False))

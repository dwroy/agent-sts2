# 静默猎手策略提案处置报告

记录时间：2026-10-16T11:23:39+08:00（写前实际执行 date -Is）。批次20261016-111303-strategy-proposal。

十项均 waiting：未隔离新的确定源码失配，现有证据不足以推出新策略参数。无源码/知识修改、无源码提交、无合入、无新版本；不登记 implemented 或 shipped。原提案的窄修复和已证机制保留，父要求不因本报告关闭。

初始工作树干净，执行 git merge --no-edit main 返回 Already up to date。基线与最终HEAD为 `5e7bfdf8586d641cdb69d5fb6101c32bed15f9d6`。learn.json 对应行核实task=strategy-proposal、character=silent、reason=proposal、工作树及五局集合一致，恰有十个 proposal_ids，无 proposal_repair/research_request/implementation_request。普通专题入口绑定旧20261010-150327，不匹配本批，未扩展其他选题。

## 逐项处置

| 提案 | 证据窗口 | 账本 | 处置及缺数据 |
|---|---|---|---|
| silent-proposal-9952ee8e8df9a0fe | NHA2KW0RB7VP F33 T1；states 283391/283396/283397、283502/283506/283507 | silent-0019, silent-0020, silent-0065, silent-0264, silent-0079 | waiting：同指纹T1多16净扣、多损6血成立；当前已有候选即时血价诊断，仍缺同抽序同预算整战、能力累计兑现及路线/留药对照，不能确定新SL或终局参数。 |
| silent-proposal-47be799a87af03be | P74C04AEPL1F F23 末次T3；states 284817、284821 | silent-0205 | waiting：计划后继提示及四个弃后手牌快照已有live实现；动态牌面、弃牌触发、目标和续步剩血尚未形成完整分支验证，未隔离新的数值失配。 |
| silent-proposal-3a5274da3c42672a | P74C04AEPL1F F17 T1–T9、F22 T1–T6、F23 T3 | silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006 | waiting：火焰扣1、逐敌失衡及寄生复活实帧成立；主怪死亡中间来源缺帧，缺药水/复活/下战资源的联合消费者回放，未隔离新源码差额。 |
| silent-proposal-bc4b92d590f2c4ce | G33HU22H2543 F48 T1/末T8；P74C04AEPL1F F23末T3 | silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266 | waiting：投斧首牌身份和普通单弃已由live祖先窄修复覆盖；跨重规划执行归属、余像累计收益和动态弃牌联合验收仍缺，不能关闭整项。 |
| silent-proposal-f52fbbab4dccc3b4 | P74C04AEPL1F F22→F23；G33HU22H2543 F48末T8 | silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064 | waiting：53→9赢战及下战9血空药入口成立；缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的后继对照，不能推出新血价。 |
| silent-proposal-10f37c0edd3d24a6 | P74C04AEPL1F F17/F22/F23；G33HU22H2543 F48末T7–T8 | silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069 | waiting：历史源码提交可定位，局部机制窗口仍与旧证据一致；缺历史刷新知识/移动表原字节及完整组合联合回放和独立校准，没有新确定失配。 |
| silent-proposal-3f82387e2e179703 | RC61MFQM63Y6 F33 首/末T1、第三试T4；decisions 279021/279197 | silent-0079, silent-0027, silent-0065, silent-0080, silent-0088 | waiting：同指纹T1少7净扣、多损4血成立；首/末题预算分别3轮2样本、5轮24样本，缺同预算整战及累计能力收益，不据此修改SL排序。 |
| silent-proposal-aee21084c991abd3 | BTSRF7JL1W1Y F31 T1–T4；decisions 279852/279854、states 286163/286170/286173/286174 | silent-0128 | waiting：甲虫力量2→4和末轮覆甲1实帧成立；抽弃前后是不同题面，预算3轮/5轮各4样本，缺逐样本轨迹与最终实线配对，一次死亡不足调权。 |
| silent-proposal-df37594e9b12debf | RC61MFQM63Y6 F33 首/末T1、第三试T4；F17 T11呼唤沿原提案出处，本批未重做该联合消费者 | silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268 | waiting：生存者取消唯一后继已在live实现；跨选择整线归属、累计能力与呼唤自损联合消费者仍未验收，不能把窄修复当整项duplicate。 |
| silent-proposal-42e81c83b2e1e56b | RC61MFQM63Y6 F33 T1；F18/F27及全局回复账沿原提案出处，本批未重算总体统计 | silent-0019, silent-0020 | waiting：52血实入口及原提案回复账有出处；缺同条件路线/休息/后战对照和逐来源消费者验收，不新增安全血线或终局HP价格。 |

逐项旧/新行为、支持、反例、验证及来源任务见 [proposal.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/proposal.md)；十份原Markdown逐字节SHA核对保存于本批，未改原文或另造id。

## 本批独立核验及结论边界

共用 learner/extract_evidence.py 完成六默认流，并另提取 runs/fight-plans。八流共6,606原行：states3238、decisions3138、SL31、run-config5、run-plans26、brain163、runs5、fight-plans0。source_size、逐行offset/bytes/SHA和每局计数均保存；合并索引见 evidence-manifest-combined.json。fight-plans为0只说明该截点未选到，不宣称源文件缺失。源日志无效JSON计数为states2/decisions2/brain1，均未纳入证据。五局均SILENT/A10，结束于2026-10-07、均负局；没有混用其他角色知识。

新抽取八流的选中字节SHA全部等于093211批次的冻结输入。对旧封套从原logs逐条seek回读并核bytes、SHA、JSON和显式身份，共6,606行全部通过；因选中字节相同，该核查同时覆盖本次封套。新源截点增长不构成这五局新增证据；未把正文提及当归属。旧报告不能替代原帧，本批另保存31关键状态和4关键决策，并重新进行19项固定材料断言，全部通过。

NHA F33首/末T1同指纹，分别30→29/23，14/8挡、净扣8/24；替线多16净扣、多损6血。RC F33首/末T1同指纹，52→48/44、16/12挡、净扣30/23；替线少7净扣、多损4血且确建触媒1层。净扣是同名单观测端点，不是逐卡伤害或完整候选因果收益。RC两个题预算实际为3轮2样本与5轮24样本，不能混称同预算受控整战。两组局部代价支持分账，没有控制后轮抽序/动作或证明一条整战更优。

P74 F23末T3为1HP/16挡对24攻击，紧勒/毒雾+/精确切击/贪婪四选项在；精确切击当时0费7伤且受手牌数量影响。实终态石眩晕、卵2HP、玩家0HP。首试/第三试卵较早结束，未执行保留精确分支不能写必胜。F17滑溜下火焰182→181、滑溜8→7；F22寄生0→21复活、T2/T4实损20/24、53→9赢战，F23实入口仍9HP空药。死亡归属缺帧及联合药水/下战资源未知保留。

G33末T8余像已建2层、12血12挡对31攻，完整显示入伤19而死亡封顶只扣12，不能将封顶扣血当完整需求；未施放或未完整执行的能力不算实绩。BTS F31甲虫T3/T4力量2/4、末轮14血5挡+1覆甲仍死；抽弃前后为不同指纹、3轮/5轮各4样本。一次死亡不证明75%模型错误或支持强制目标。路线/休息/保药没有同条件完整后继；原总体统计本批未重算，不新增血线/路线禁令/HP价格。

## 现有实现及消费者范围

只读live冻结为 `0e7998bfa8df267dcf8835a57949bdb982c9feb0`。14个相关源码叶与093211核验工作树全部相同；其中13个与live原字节同，sl/explore.ts仅3处既有Roy/Dai注释差，差分存source-live-explore.diff.txt。不因此称完整运行输入相同。

- `e784dd9f043bf87c29109573f48975f9903280d3` 是实际base/live祖先，覆盖投斧首牌顺序身份。
- `bf423c173d3be348a4ad714e1d26516df619ff41` 是实际base/live祖先，覆盖普通生存者唯一弃牌及取消虚构后继；多选仍保留未知。
- `4b0823f519f1b724d6cff2b1cd50b74146dc4a9d` 覆盖弃后手牌和单卡费用快照；函数明确不推演动态牌面/弃牌触发/伤害/格挡/剩血。
- 暂停计划提示按真实祖先 `5b56a452bb9be14d620b368ec46974c1b57901ca` 追溯；旧侧支 `f34700874c9f48b614991f769532115a0f24f27b` 非实际祖先，不能冒认上线。
- 资源比较 `1698adc96ba434a46942321e0237b70657e625b2` 与现有候选/派发诊断均有实际祖先；预测仍不是已执行整轮，actual_turn和完整候选实绩保持未知。

source-audit.json保存14叶SHA/blob及9提交祖先核验。五份run-config源码commit在Git存在，dirty仅knowledge/notes的既有事实见原冻结材料；缺口是历史刷新知识/移动表原字节，不是无法定位源码。本批未用当前刷新表伪造历史联合输入、未重跑模型/整战模拟。

七个现有离线窗口的输入、输出和stderr共21原件SHA重新核过，相关工具源码相同，故本批没有重跑或宣称新测试通过。旧七窗口共170题段、735动作、642相邻端点、2终态端点、140整轮窗口（86可核、54unknown）；整条候选认证0。原日志P74 F22与BTS F31的归属unknown仍保留。prior-consumer-readback.json记录出处、SHA和rerun_this_batch=false，不把旧exit0当本批tsc/vitest、自然消费或收益。

## 验证、台账和交付

19/19为固定证据材料断言，见material-checks.json；不是生产测试。无源码修改，tests固定tsc/vitest/cases均null，撤源码失败/恢复通过不适用，fixes=[]、merged=null。无新提交、行为发布号或上线双通知；无需执行live合入。其他角色行为等价，无新参数拟合，SL按原局分组。

账本仅用根目录learner/ledger.py追加本批proposal/report链接和核查说明，按32个既有ID去重。不新增support/repeat、不改旧claim/first_run/prior/evidence/status/version、不把已shipped窄子项重置为proposed，不新建重复代码提案。CLI输入、退出码及物理前缀/字段读回另存本目录。本批仅保存研究材料，未更改请求或调度状态，不关闭学习入库宽父。没有新的机制反证或不同结论；上述限制沿原提案保留。

运维交付：proposal.md、report.md、result.json及相应证据索引。十项保留具体waiting原因，由原队列待新的本角色证据；不标implemented/shipped、不分配版本、不补无源码改动的生产测试。无LLM/网络/play、无下级agent、无推送、未读取凭据/.env/游戏二进制。读取探针曾使用不存在的reflex/selection.ts、core/loop.ts和silent-discard-branches.ts，后由rg定位到实际文件；只是路径读取失败，未当作产品缺陷或游戏反证，工具转录保留。

最终验收：2026-10-16T11:25:41+08:00（先运行date）。根账本CLI退出0，32条追加均按offset/bytes/SHA读回，物理旧前缀与保护字段、notes/history/where旧前缀保持。材料断言19/19；过程材料gitleaks退出0、0命中。HEAD仍为5e7bfdf8586d641cdb69d5fb6101c32bed15f9d6，git status干净、tracked diff为0；本批派发绑定再次核对一致。

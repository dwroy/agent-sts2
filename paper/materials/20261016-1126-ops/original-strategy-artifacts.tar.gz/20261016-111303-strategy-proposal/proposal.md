# 静默猎手十项派发提案核验

记录时间：2026-10-16T11:23:39+08:00（先运行 date -Is）。批次：20261016-111303-strategy-proposal。

本批为普通代码提案消费任务，仅处理 learn.json 的十个 proposal_ids；不承接其他专题、父请求或队列。五局均已核为静默猎手A10。授权 Roy-2026-10-07-learning 只授权学习流程，不提供游戏事实。

本批未发现可隔离的新确定源码差额；十项 waiting。下列“预期行为”是原提案待验范围，不表示本次已经实现。既有源码、账本状态及已上线窄子项保持。

## 1. silent-proposal-9952ee8e8df9a0fe

SL零胜率换线须显式核即时血价和击杀推进，路线/营火实际回复与存档恢复分账；证据不足保留门槛

证据：NHA2KW0RB7VP F33 T1；states 283391/283396/283397、283502/283506/283507。账本：silent-0019, silent-0020, silent-0065, silent-0264, silent-0079。

旧行为：死亡频率不更差再按候选排序换线。 预期行为：保留现有排序；即时HP、净扣和能力已兑现收益分别显示并核实。

本批处置：waiting。同指纹T1多16净扣、多损6血成立；当前已有候选即时血价诊断，仍缺同抽序同预算整战、能力累计兑现及路线/留药对照，不能确定新SL或终局参数。

反例与限制：两线没有杀敌，后轮抽牌/动作未控制，无整战胜线对照；同局SL不是独立局。

原始提案：[silent-proposal-9952ee8e8df9a0fe.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-9952ee8e8df9a0fe.original.md)；保留来源任务 experience-update → strategy-proposal。

## 2. silent-proposal-47be799a87af03be

静默已观察单张弃牌题核对正在执行计划、逐敌来袭和每个合法弃牌分支，保留未实打的反事实限制

证据：P74C04AEPL1F F23 末次T3；states 284817、284821。账本：silent-0205。

旧行为：弃牌前整线预测有完成后继的条件。 预期行为：保留所有合法弃牌；逐支重算需覆盖动态牌面和目标，不把快照当生存证明。

本批处置：waiting。计划后继提示及四个弃后手牌快照已有live实现；动态牌面、弃牌触发、目标和续步剩血尚未形成完整分支验证，未隔离新的数值失配。

反例与限制：首试/第三试卵较早已结束；保留精确切击分支未实打，不能指定永远弃贪婪。

原始提案：[silent-proposal-47be799a87af03be.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-47be799a87af03be.original.md)；保留来源任务 postmortem → strategy-proposal。

## 3. silent-proposal-3a5274da3c42672a

核证多敌失衡与召唤复活、一次格挡翻倍、滑溜下火焰／毒与普通触媒兑现，保留获胜战到下一战的真实资源和缺帧限制

证据：P74C04AEPL1F F17 T1–T9、F22 T1–T6、F23 T3。账本：silent-0039, silent-0196, silent-0013, silent-0180, silent-0224, silent-0227, silent-0027, silent-0011, silent-0006。

旧行为：逐敌攻击/复活/毒与药水模型已有局部实现。 预期行为：按已观察来源与时点核兑现，不将召唤初始血或药面值当全部收益。

本批处置：waiting。火焰扣1、逐敌失衡及寄生复活实帧成立；主怪死亡中间来源缺帧，缺药水/复活/下战资源的联合消费者回放，未隔离新源码差额。

反例与限制：局部石眩晕与卵继续攻击可同时发生；未见保药或另一杀序完整胜局。

原始提案：[silent-proposal-3a5274da3c42672a.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-3a5274da3c42672a.original.md)；保留来源任务 postmortem → strategy-proposal。

## 4. silent-proposal-bc4b92d590f2c4ce

保留投斧首牌顺序身份、弃牌后重核计划和能力实际兑现；候选与完整实线分账

证据：G33HU22H2543 F48 T1/末T8；P74C04AEPL1F F23末T3。账本：silent-0092, silent-0023, silent-0021, silent-0057, silent-0205, silent-0079, silent-0266。

旧行为：原SL键曾丢失投斧首牌身份；原普通单弃曾保留虚构续步。 预期行为：现有窄修复保持；首牌身份、实际执行前缀和累计能力收益分别验收。

本批处置：waiting。投斧首牌身份和普通单弃已由live祖先窄修复覆盖；跨重规划执行归属、余像累计收益和动态弃牌联合验收仍缺，不能关闭整项。

反例与限制：另一首牌顺序未完整实打；药水补余像层不证明恢复首牌机会或必胜。

原始提案：[silent-proposal-bc4b92d590f2c4ce.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-bc4b92d590f2c4ce.original.md)；保留来源任务 experience-update → strategy-proposal。

## 5. silent-proposal-f52fbbab4dccc3b4

按赢战资源消耗与下一场实入口核路线/SL/終局价值，存档恢复与真实回复分账

证据：P74C04AEPL1F F22→F23；G33HU22H2543 F48末T8。账本：silent-0019, silent-0020, silent-0090, silent-0069, silent-0039, silent-0064。

旧行为：未来营火和平均血价属于路线预测。 预期行为：已兑现回复、赢战消耗、实际下战入口和SL恢复分账；预测不能写实绩。

本批处置：waiting。53→9赢战及下战9血空药入口成立；缺逐来源连续资源消费者账及同条件路线、休息、SL或保药的后继对照，不能推出新血价。

反例与限制：赢战净损不等每来源伤害；未来营火未到，不能用死亡反推路线必错。

原始提案：[silent-proposal-f52fbbab4dccc3b4.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-f52fbbab4dccc3b4.original.md)；保留来源任务 experience-update → strategy-proposal。

## 6. silent-proposal-10f37c0edd3d24a6

逐来源核临时减力、双重毒结算、牌挡/被动挡/翻倍、开场遗物及实际回复

证据：P74C04AEPL1F F17/F22/F23；G33HU22H2543 F48末T7–T8。账本：silent-0006, silent-0011, silent-0027, silent-0046, silent-0013, silent-0180, silent-0196, silent-0255, silent-0198, silent-0204, silent-0069。

旧行为：临时力量、触媒、牌挡、被动挡与开场净值已有条件模型。 预期行为：逐来源校核当前组合，保留未观察组合和不明内部顺序。

本批处置：waiting。历史源码提交可定位，局部机制窗口仍与旧证据一致；缺历史刷新知识/移动表原字节及完整组合联合回放和独立校准，没有新确定失配。

反例与限制：临时负力恢复不是机制反例；历史dirty仅知识/记录，不表示原源码提交缺失。

原始提案：[silent-proposal-10f37c0edd3d24a6.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-10f37c0edd3d24a6.original.md)；保留来源任务 experience-update → strategy-proposal。

## 7. silent-proposal-3f82387e2e179703

双蟹同盘SL用触媒替打击实少7伤、多损4HP，全败推演并列不当同安全；先核弃牌后可达朝向与能力兑现，缺整战控制及独立验证时保留旧排序、等待新证据。

证据：RC61MFQM63Y6 F33 首/末T1、第三试T4；decisions 279021/279197。账本：silent-0079, silent-0027, silent-0065, silent-0080, silent-0088。

旧行为：全败样本不区分当前资源代价。 预期行为：保留排序；用现有资源诊断显示血价，不据单局加能力惩罚或固定目标。

本批处置：waiting。同指纹T1少7净扣、多损4血成立；首/末题预算分别3轮2样本、5轮24样本，缺同预算整战及累计能力收益，不据此修改SL排序。

反例与限制：触媒毒实际有兑现，但后轮行动不同；不能把少7伤全归触媒一般价值。

原始提案：[silent-proposal-3f82387e2e179703.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-3f82387e2e179703.original.md)；保留来源任务 postmortem → strategy-proposal。

## 8. silent-proposal-aee21084c991abd3

核对醒虫力量、临时虚弱、覆甲及抽弃后实际执行线的长程推演；单局3/4样本线死亡不足校准权重或规定焦点，保留原行为并交独立任务验证。

证据：BTSRF7JL1W1Y F31 T1–T4；decisions 279852/279854、states 286163/286170/286173/286174。账本：silent-0128。

旧行为：抽弃后重新规划，旧候选可被替换。 预期行为：仅评价最终实际执行线；醒虫成长和当前覆甲不与未施放步法混用。

本批处置：waiting。甲虫力量2→4和末轮覆甲1实帧成立；抽弃前后是不同题面，预算3轮/5轮各4样本，缺逐样本轨迹与最终实线配对，一次死亡不足调权。

反例与限制：F17实际步法+与F31未施放情况不同；3/4抽样线一次死亡不构成概率bug。

原始提案：[silent-proposal-aee21084c991abd3.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-aee21084c991abd3.original.md)；保留来源任务 postmortem → strategy-proposal。

## 9. silent-proposal-df37594e9b12debf

强制单弃后取消后继攻击/转向；SL能力换线同时核即时血价与实际结算窗口

证据：RC61MFQM63Y6 F33 首/末T1、第三试T4；F17 T11呼唤沿原提案出处，本批未重做该联合消费者。账本：silent-0021, silent-0027, silent-0057, silent-0065, silent-0079, silent-0176, silent-0205, silent-0268。

旧行为：普通单弃可达性已修复，预测和派发分开记录。 预期行为：联合核对弃牌取消后继、朝向及持牌自损，不把单动作回执当整线完成。

本批处置：waiting。生存者取消唯一后继已在live实现；跨选择整线归属、累计能力与呼唤自损联合消费者仍未验收，不能把窄修复当整项duplicate。

反例与限制：唯一余牌必弃与多选未知应区分；毒杀不自动免除已观察持牌自损。

原始提案：[silent-proposal-df37594e9b12debf.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-df37594e9b12debf.original.md)；保留来源任务 experience-update → strategy-proposal。

## 10. silent-proposal-42e81c83b2e1e56b

路线/休息按已兑现回复与赢战耗血核血价；存档恢复不等真实回血

证据：RC61MFQM63Y6 F33 T1；F18/F27及全局回复账沿原提案出处，本批未重算总体统计。账本：silent-0019, silent-0020。

旧行为：路线/休息可带未来HP投影。 预期行为：保留规则；以实际入口与真实回复核账，SL恢复同瓶药不算新得资源。

本批处置：waiting。52血实入口及原提案回复账有出处；缺同条件路线/休息/后战对照和逐来源消费者验收，不新增安全血线或终局HP价格。

反例与限制：原全历史统计本批未重算；没有同条件锻造、另路线或保药胜线。

原始提案：[silent-proposal-42e81c83b2e1e56b.original.md](/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-111303/learner/runs/20261016-111314-d498a312-53d4-428f-a783-461776b4b775-strategy-proposal/silent-proposal-42e81c83b2e1e56b.original.md)；保留来源任务 experience-update → strategy-proposal。

## 验证、拟合及回退

共用提取器按显式 run/run_id/state.run_id/fingerprint.run 归属抽取；八流6,606原行已按offset、bytes、SHA256和JSON逐条核验。新抽取选中内容与旧冻结输入逐流SHA一致，没有新独立局。31关键状态及4关键决策重新核对，19项固定材料断言通过，见 material-checks.json。

没有拟合新参数。五局仅为同角色A10固定回归；旧总体统计仅保留原文出处，本批不重算、不当新校准；同局SL按原局分组。新排序或阈值须增加本角色时间后置数据及可比较完整轨迹；确定源码错误不以必须出现获胜反事实为修复前提，本批尚未隔离这种新错误。

现有离线消费者七窗口的输入、输出、stderr共21个原件SHA已读回，相关源码未变，本批未重跑。旧结果的整条候选认证为0，不能证明自然采用、整线完成或胜率收益。动态弃牌、逐来源跨战资源及历史刷新知识输入继续待证。

无源码修改，tsc/vitest/cases均null，无撤源码失败/恢复通过试验、提交、合入或发布号。无需代码回退；后续若实现，按各原提案的实际源码差量回退，保留并行发布、全部证据和失败历史。当前仅CLI追加账本追溯，不新增提案id、不重复support/repeat、不改claim/首证/状态/版本、不登记shipped。

from pathlib import Path
import subprocess, json, hashlib, re, os, tarfile, importlib.util
root = Path.cwd(); r = root
p = r / 'ops/codex-ops/record-staging/20261015-1818'
pub = r / 'paper/materials/20261015-1818-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-180124-s2-strategy-proposal'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions'] == report['proposal_results']
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and all(x is None for x in report['tests'].values())
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
final = json.loads((s / 'final-checks.json').read_text())
assert final['base'] == report['base'] and final['clean'] and final['diff_bytes'] == 0 and final['proposal_results_complete']
assert final['ledger_rows'] == 31 and final['ledger_protected'] and not final['source_changes'] and not final['tests_run']
ev = json.loads((s / 'raw-verification.json').read_text()); win = json.loads((s / 'window-verification.json').read_text())
assert ev['total_rows'] == 19929 and sum(x['rows'] for x in ev['streams']) == 19929 and ev['thin_matches_final']
assert all(x['offset_bytes_sha_json_identity'] for x in ev['streams'])
assert win['check_count'] == len(win['checks']) == 75 and all(x['passed'] and x['actual'] == x['expected'] for x in win['checks'])
source = json.loads((s / 'source-readback.json').read_text()); assert len(source['leaves']) == 11 and source['base'] == report['base']
for x in source['leaves']:
    a = git('show', report['base'] + ':' + x['path']); z = git('show', source['live'] + ':' + x['path'])
    assert sha(a) == x['base_sha256'] and sha(z) == x['live_sha256']
    assert a == z or a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
for x in source['commits']:
    assert x['live_ancestor']; git('merge-base', '--is-ancestor', x['commit'], source['live'])
inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]; owned = []
for raw in (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 31
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
assert b''.join(owned) == (s / 'ledger-appended-rows.jsonl').read_bytes()
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); seen = set(old.splitlines())
added = b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); before = fold(old); after = fold(old + added)
assert set(before) == set(after)
for ident in before:
    for k in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']: assert before[ident].get(k) == after[ident].get(k), (ident, k)
receipt = {'batch': bid, 'original_report': report, 'native': native, 'canonical_no_change_gate': b['no_change_proposals'], 'source11_sha_and_seven_live_ancestors_verified': True, 'source6_equal5_historical_comment_differences_preserved': True, 'original_material_rows': 19929, 'original_material_assertions': 75, 'material_tests_reexecuted': False, 'owned_ledger_rows': 31, 'protected_fold_preserved': True, 'original_model_task_text_high_launcher_actual_xhigh_difference_preserved': True, 'scope': '15 Silent runs; A1/A7/A9/A10 remain separate; same-run SL is not an independent run; no complete counterfactual or new holdout result.', 'original_failure_history': json.loads((s / 'material-probe-corrections.json').read_text()), 'original_evidence_boundaries': 'fight-plans selected zero rows at original 2233957-byte cut only; raw source invalid JSON counts preserved; original gitleaks scope limited, no full raw-evidence scan claimed.', 'no_source_merge_version_checks_or_game_action': True}
(pub / 'batch-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 350000 and f.suffix in ['.json', '.jsonl', '.md', '.py', '.txt', '.patch'] and f.name not in ['ledger-snapshot.json', 'state-windows.jsonl', 'ledger-before.json', 'scan-input.txt', 'final-scan-input.txt']]
files += list((s / 'original-proposals').glob('*.md'))
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1818原180124-s2策略rc0/done、十项waiting/no-source门禁实核，3e1d干净WT无新增提交，testsnull/mergednull/implementation_domains空，不重合/发号/补测或重复派单。15个Silent原局19929行身份/字节及75固定帧材料断言为原学习者结果读回，不重复跑或冒生产测试；A1/A7/A9/A10分列，同局SL不当独立样本，原105/109分母不重算。11源码叶旧livefe646265逐SHA/七窄源祖先核，6同/5历史Roy-Dai注释差保持；窄子项不关闭完整候选、成对后继/资源校准宽项。31原CLI只where/note，旧claim/首证/prior/evidence/status/version保护同验。实际native Sol6.1/xhigh/input/lease及workspace-write/no-network核，原正文high差异保留。辅助决策无chosen、缺源码路径、工具截断及原JSON异常/零fight-plans截点与原扫描范围均原件留盘，不当生产bug或全证据已扫描。无新反证/经验/源码/复盘，不刷新论文、不改当前局/账号模型额度队列prompt，原P2/C2及宽父继续原链，不等待未来事件。证据paper/materials/20261015-1818-ops/。\n'
note = f'\n- {at} [ops 策略处置] 原180124-s2十项继续waiting，无源码/提交/合入/版本；31条原CLI仅补追溯，15局原材料核验及其限制、探针失败原件归档。ops核实际Sol6.1/xhigh与原隔离权限，不关闭宽项或重复派单/补测。回执paper/materials/20261015-1818-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note}; (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in [p / 'prepare-records.py', p / 'seal-records.py', r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'batch': bid, 'waiting': 10, 'own_ledger_rows': 31, 'no_source_tests_merge_release_or_dataset': True, 'protected_fields_preserved': True, 'native_model_and_original_sandbox_verified': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}; values['paper/materials/learning/ledger.jsonl'] = old + added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; rows = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'waiting': 10, 'ledger_rows': 31, 'native_verified': True, 'ledger_check': 0, 'paths': len(rows)}))

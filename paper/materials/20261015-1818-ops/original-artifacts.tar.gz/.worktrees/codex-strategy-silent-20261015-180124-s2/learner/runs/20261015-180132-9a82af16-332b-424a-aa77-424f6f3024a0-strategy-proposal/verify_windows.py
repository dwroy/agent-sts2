import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).parent
states = [json.loads(line) for line in (OUT / 'states-thin.jsonl').open()]
by_line = {s['line']: s for s in states}
observed = {(s['run_id'], s['observed_ts']): i for i, s in enumerate(states)}
decisions = [json.loads(line) for line in (OUT / 'evidence/decisions.evidence.jsonl').open()]
sl = [json.loads(line) for line in (OUT / 'evidence/sl-attempts.evidence.jsonl').open()]
checks = []


def check(label, actual, expected, lines):
    entry = dict(label=label, actual=actual, expected=expected, states=lines, passed=actual == expected)
    checks.append(entry)
    assert entry['passed'], entry


def hp(line):
    return by_line[line]['hp']


def enemy(line, index=0):
    return by_line[line]['enemies'][index]


drinks = []
cunning = []
for x in decisions:
    d = x['row']
    action = d.get('chosen') or {}
    if action.get('action') != 'use_potion':
        continue
    i = observed.get((x['run_id'], d.get('observed_ts')))
    assert i is not None, x['line']
    before, after = states[i:i + 2]
    assert after['run_id'] == before['run_id']
    slot = action['option_index']
    name = before['potions'][slot]
    if x['run_id'] == 'KEN58SH9SLZ6':
        drinks.append(dict(decision=x['line'], floor=d['floor'], turn=d['turn'], potion=name,
                           before=before['line'], after=after['line']))
        check('KEN饮用后槽位清空', after['potions'][slot], None, [before['line'], after['line']])
    if name == 'CUNNING_POTION':
        count = len(after['hand']) - len(before['hand'])
        entry = dict(run=x['run_id'], floor=d['floor'], turn=d['turn'], decision=x['line'],
                     before=before['line'], after=after['line'], hand_before=len(before['hand']),
                     added=count, hp_delta=after['hp']-before['hp'], energy_delta=after['energy']-before['energy'])
        cunning.append(entry)
        check('狡诈观察容量', count, min(3, 10 - len(before['hand'])), [before['line'], after['line']])

check('KEN七次饮用', [d['potion'] for d in drinks],
      ['ATTACK_POTION', 'STABLE_SERUM', 'SPEED_POTION', 'WEAK_POTION', 'ATTACK_POTION', 'GLOWWATER_POTION', 'SKILL_POTION'], [])
check('KEN两次实际回复', [hp(280337)-hp(280336), hp(280383)-hp(280382)], [27, 29], [280336, 280337, 280382, 280383])
check('KEN回复伴随上限增加', [by_line[280337]['max_hp'], by_line[280383]['max_hp']], [81, 86], [280337, 280383])
check('狡诈样本分布', dict(Counter(x['added'] for x in cunning)), {3: 37, 2: 2, 0: 3}, [])
check('狡诈满手不变血能', [(x['hp_delta'], x['energy_delta']) for x in cunning if x['added'] == 0], [(0, 0)] * 3, [])

check('TXZ原线损血和敌扣血', [hp(281479)-hp(281484), enemy(281479)['hp']-enemy(281484)['hp']], [3, 36], [281479, 281484])
check('TXZ替线损血和敌扣血', [hp(281535)-hp(281539), enemy(281535)['hp']-enemy(281539)['hp']], [0, 27], [281535, 281539])
check('TXZ连续入口', [hp(281563), hp(281565), hp(281566)], [4, 4, 0], [281563, 281565, 281566])
check('TXZ后战无可操作首帧', (by_line[281565]['ready'] or {}).get('can_use_combat_actions'), False, [281565])
check('TXZ敌未受伤', [enemy(281565)['hp'], enemy(281566)['hp']], [111, 111], [281565, 281566])

check('WQ两次同盘入口', [(hp(n), enemy(n)['hp']) for n in [282075, 282144]], [(26, 184), (26, 184)], [282075, 282144])
check('WQ原线血价及伤害', [hp(282075)-hp(282079), enemy(282075)['hp']-enemy(282079)['hp']], [13, 24], [282075, 282079])
check('WQ替线血价及伤害', [hp(282144)-hp(282148), enemy(282144)['hp']-enemy(282148)['hp']], [22, 39], [282144, 282148])
check('WQ延时线血价及伤害', [hp(282330)-hp(282336), enemy(282330)['hp']-enemy(282336)['hp']], [4, 24], [282330, 282336])
check('WQ延时能力即时增加', [enemy(282330)['powers']['SANDPIT_POWER'], enemy(282331)['powers']['SANDPIT_POWER']], [4, 5], [282330, 282331])

check('Q6紧勒逐帧敌血', [enemy(n)['hp'] for n in range(282887, 282893)], [103, 95, 85, 85, 83, 80], list(range(282887, 282893)))
check('Q6胜战不等后战存活', [hp(n) for n in [282872, 282911, 282913, 282921]], [57, 2, 2, 0], [282872, 282911, 282913, 282921])
check('1913前序退出资源', [hp(n) for n in [282600, 282637, 282723, 282749, 282755, 282783]], [58, 14, 61, 46, 46, 0], [282600, 282637, 282723, 282749, 282755, 282783])

check('NHA首试即时挡与损', [by_line[283396]['block'], hp(283391)-hp(283397)], [14, 1], [283391, 283396, 283397])
check('NHA末试即时挡与损', [by_line[283506]['block'], hp(283502)-hp(283507)], [8, 7], [283502, 283506, 283507])
check('NHA两线跨轮敌净扣', [sum(e['hp'] for e in by_line[a]['enemies'])-sum(e['hp'] for e in by_line[b]['enemies']) for a,b in [(283391, 283397), (283502, 283507)]], [8, 24], [283391, 283397, 283502, 283507])
check('NHA末试油灯萎靡', [enemy(283506)['powers']['STRENGTH_POWER'], enemy(283506)['powers']['WEAK_POWER']], [-2, 2], [283506])
check('油灯三局已见施毒', [enemy(217010, 1)['powers']['POISON_POWER'], enemy(232563, 1)['powers']['POISON_POWER'], enemy(283147)['powers']['POISON_POWER']], [8, 10, 10], [217010, 232563, 283147])

attempts = {}
for run, floor in [('TXZ6RVMQA09D', 48), ('WQZVENQ7DTRP', 33), ('NHA2KW0RB7VP', 33)]:
    rows = [x for x in sl if x['run_id'] == run and x['row'].get('floor') == floor]
    attempts[run] = [dict(line=x['line'], attempt=x['row'].get('attempt'), result=x['row'].get('result'),
                          end_hp=x['row'].get('end_hp')) for x in rows]
    expected = 3 if run == 'TXZ6RVMQA09D' else 6
    check('尝试数量' + run, len(rows), expected, [])

result = dict(check_count=len(checks), checks=checks, ken_drinks=drinks, cunning=cunning, attempts=attempts,
              interpretation='只验证冻结原始帧及已实际执行分支；不是生产代码测试或受控整战反事实。')
(OUT / 'window-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
selected = set(n for c in checks for n in c['states'])
(OUT / 'selected-state-windows.json').write_text(json.dumps([by_line[n] for n in sorted(selected)], ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(check_count=len(checks), cunning_count=len(cunning), attempts=attempts), ensure_ascii=False))

# Silent 本批十项策略提案核验

本批10项均为waiting；没有新增源码、知识规则、提交、live合入或发布号。已有窄子项不能代替整项的联合验证。结论只来自本角色原始对局，本批未发现需要改写旧结论的新反证，不将原有反例重复登记为新学习。

批次：`20261015-180124-s2-strategy-proposal`。派发起点 `de83b8eadbba3de9de0993a7397c454de6ed37e3`，按普通提案流程无冲突快进main后，实际base为 `3e1d6d5405fc9cbf6cea7858dfe79f7e49c88ccb`。导入只有13个记录叶，无源码/知识变化；此后HEAD不变。learn.json对应行task/character/worktree及十项id已核对；无research_request、implementation_request或proposal_repair。普通deck-size请求绑定旧批，不适用于本批，没有读取其他专题。未领取其他提案。

`native-session-readback.json`从实际原生conversation_starts核到gpt-6.1-sol/xhigh，线程`01a13f02-8fb6-70f1-a15b-841406c00795`。xhigh与任务正文high存在差异，本会话没有切换或降低强度，也不冒称已按high运行。全程独立，无下级agent、网络、LLM调用或play。

## 输入和核验

dispatch的十个锚点按原顺序保留；仅补入原提案明确关联的1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR。全部15局runs.jsonl角色为SILENT，其中K367为A1、SADL为A7、F4Q为A9，其余A10；进阶不混算，SL不是独立局。不读取或搬用其他角色的私有知识。

统一extract_evidence.py已提取states 9815、decisions 9448、sl-attempts 78、run-config 15、run-plans 77、brain 481、runs 15，共19929行。每个流保存source_size、逐行offset/bytes/SHA256与计数，全部回查原文件字节、JSON及显式run身份通过；冲突身份未收录。run-plans采用run，不用正文提及作为身份。fight-plans在本次2233957字节截点选中0行，只表明该截点无所属行，不断言历史文件缺失。未覆盖旧报告或旧零行初稿。

本批固定原帧75项材料断言通过，见window-verification.json及所引原始s/d行；它们没有运行生产求解器，不是tsc/vitest、代码回归或完整反事实。states-thin输入SHA与最终提取manifest一致。完整证据保留在evidence/，选择窗口及原提案原字节另存；旧105/109局统计只属于原提案背景，本批未重做全史统计或当作新增独立样本。

## 已有源码与实际live边界

只读核验时实际live为 `fe6462651b593b9831581c088deface9957a404f`。11个相关源码叶6个字节相同，5个仅历史Roy/Dai注释署名不同，精确差异保存base-live-source-differences.patch，不覆盖任何live叶。source-readback.json保存全部SHA和源码祖先检查。

- `5b56a452bb9be14d620b368ec46974c1b57901ca`：狡诈生成/容量、受限中段重接、原TXZ开场等窄子项。
- `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`：普通紧勒和已观察精确切击手数等窄分支。
- `68711002f15b298b8863d2258ee5da236da151d2`：蟹虚弱与朝向取整接线。
- `ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`：后来扩充的开场白名单；原TXZ窄分支仍保留。
- explore现存notWorse/deathShare来源adb1e129b11f0ba3e4d68c41b763f0576dd5f581、ae04fc3582680eb856177d720f2ef30b8339517a与23b3d62370a7bf206ec239b4fe3fc8e9385bbe50也均是上述live祖先。不把它们重报本批实现。

这些是实际源码覆盖证据，不是当前自然消费者完整执行、游戏胜率提高或整项duplicate的证据。以下每项都保留具体余项。

## silent-proposal-08eaa60bcc449852：waiting

角色/进阶/窗口：KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1—2/F15T1；F12/F16。

账本：silent-0019, silent-0020。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md`；SHA256 `4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`。

核实证据：7次实际饮用后对应槽位清空；F12实回27、F16实回29且上限分别增至81/86，不能记成SL恢复。固定帧见window-verification.json的ken_drinks及s280336—338、s280382—384。

处置及缺数据：缺同入口、同后续抽牌和药栏下不饮用或留到Boss的成对整战结果；七次实饮及两次真实回复不足重拟持药价。

预期行为、反例与验证：当前角色药水表/后继reserve的消费路径已存在；本项没有新价值参数或更早喝药规则。下一次需未用/已用的完整后继链与按独立局后移的验证，保持原规则。

来源任务 `experience-update` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-92920295a648b540：waiting

角色/进阶/窗口：TXZ6RVMQA09D A10 F48第2/3试T6，F49T1。

账本：silent-0228, silent-0255。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md`；SHA256 `f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`。

核实证据：s281479→281484为损3/扣敌36，s281535→281539为损0/扣敌27；s281563—566核首胜4HP、后战入口4→0且敌111HP未变，首帧不可操作。sl972/973/974是同局三试。

处置及缺数据：缺保持后续抽牌、生成及药栏一致的两战通关替线；开场扣血子项已实现，不能关闭连战/SL资源校准宽项。

预期行为、反例与验证：不把首场胜利、低可信0%或同局重试记成新独立胜样本；现有连战与开场模型保留。后续比较须同时给首战退出和第二战可操作后的实际结局。

来源任务 `postmortem` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-a327449c331efbc1：waiting

角色/进阶/窗口：WQZVENQ7DTRP A10 F33第2/3试T9及末试T7。

账本：silent-0079, silent-0018。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md`；SHA256 `e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`。

核实证据：s282075→282079为26→13HP、敌184→160；s282144→282148为26→4HP、敌184→145，多15伤付9血。s282330→282336损4/扣24，沙坑当步4→5（s282330/331），不能单向禁止付血换延时。

处置及缺数据：缺攻防与沙坑两边界的完整受控后继和独立胜局；现有局部差额及六次失败不能校准新探索排序或固定血价阈值。

预期行为、反例与验证：全败死亡率并列不代表血价相同；现行探索门槛保留。验证应在同预算、同后续条件下记录原答/替换/完整执行，再检验实际存活推进，不能只比较单步伤害。

来源任务 `postmortem` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-a099e89437e942bb：waiting

角色/进阶/窗口：02HB4L0C3C67等九局；重点WQZVENQ7DTRP A10 F33第5/6试T11。

账本：silent-0030, silent-0257, silent-0258。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md`；SHA256 `e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`。

核实证据：九局42次狡诈饮用复核37次添3、两次添2、三次满手添0。WQ末两组为s282292—296的2/0/0与s282352—357的3/2/0；满手三次HP/能量均不变。生成和容量子项已有真实live源码。

处置及缺数据：确定生成和容量已覆盖；仍缺计划妥当保留选择、出刀穿插、整候选派发与SL恢复的联合消费者校准，不能将整项登记duplicate。

预期行为、反例与验证：不重写已正确的确定生成。继续验证各阶段候选身份及完整动作序列；无穿插整战胜局，不声称多刀必能救局，未观察组合保持原路径。

来源任务 `experience-update` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-47910f82a1fdd98f：waiting

角色/进阶/窗口：TXZ6RVMQA09D A10 F48T10→F49T1；WQZVENQ7DTRP A10 F33T7/T9。

账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md`；SHA256 `d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`。

核实证据：复核TXZ的4→0入口和WQ双向血价；observedRoyalPoisonOpeningLoss只在已观察Silent A10遗物/药栏分支对新模拟战扣4，live T1及SL恢复不重复扣。

处置及缺数据：开场子项已有actual live祖先源码；仍缺留药、路线及SL的完整后继对照，以及未知回血/复活组合结算顺序，资源价值宽项未验证。

预期行为、反例与验证：不再报告漏认双Boss，不用旧小血瓶组合净值拆成单件。维持窄开场规则，新的组合和路线价值仍待本角色实盘。

来源任务 `experience-update` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-f1374df72d8e6a25：waiting

角色/进阶/窗口：1913SE84AXQF A10 F17/F29/F31；Q6M2Y34MWKRE A10 F2/F8/F9。

账本：silent-0019, silent-0020, silent-0050, silent-0253。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md`；SHA256 `df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`。

核实证据：1913的s282600/637为58→14、s282723/749为61→46、s282755为F31入口46；Q6的s282872/911/913/921为57→2、接2→0。F2早喝候选未完整执行，F8紧勒误差须与价值判断隔离。

处置及缺数据：缺隔离机制误差后同入口、同预算、同后续的未用、早用和留药成对整战结果，单题候选不足校准持药价或终局权重。

预期行为、反例与验证：当前后继reserve/终局目标并非只看单场；不能由两条失败链推出新权重。固定回放和后移独立局分开，原阈值保持。

来源任务 `postmortem` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-38a49e6c97f31eea：waiting

角色/进阶/窗口：Q6M2Y34MWKRE A10 F8T4、F9T2；1913SE84AXQF A10 F17/F31T2—4。

账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md`；SHA256 `6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`。

核实证据：Q6 s282887—892敌血103/95/85/85/83/80，普通紧勒后续每次完成触发与毒分账；F9最终2血仍死。普通紧勒和25HP中段重接清毒/旧力已有受限源码。

处置及缺数据：缺弃磨蚀、增益分源、再生、自动触发与SL恢复的完整联合消费者校准；普通紧勒/中段重接的局部公式覆盖不能关闭整项。

预期行为、反例与验证：不外推紧勒升级/重放/叠层或未知目标分支；先按完整固定帧复核消费者误差，再谈持有价值或SL排序，不新增未经验证的参数。

来源任务 `experience-update` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-ef0e38a5dbd3bc07：waiting

角色/进阶/窗口：1913SE84AXQF A10 F24/F28/F29/F31；Q6M2Y34MWKRE A10 F7/F8/F9。

账本：silent-0019, silent-0020, silent-0021。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md`；SHA256 `d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`。

核实证据：1913赢F29以46HP进入F31后死，Q6赢F8只剩2进入F9后死；原提案F24实际锻造导致后续条件变化，不能把计划投影差额全当同条件模型误差。本文未重算其109局历史统计。

处置及缺数据：缺另一营火、事件、路线及药时的完整受控结果；两条实际失败链及条件改变不足拟合资源权重或保证未来营火可达。

预期行为、反例与验证：区分真实回复与尚未抵达营火，不由两败强制更保守路线。验证应保存休息/锻造/事件选择和每个后继入口，按局和时间留出。

来源任务 `experience-update` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-7f820c02d39bfaea：waiting

角色/进阶/窗口：NHA2KW0RB7VP A10 F33第1/5/6试T1及弃牌重规划。

账本：silent-0079。原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md`；SHA256 `bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`。

核实证据：s283391→283397首试14挡/损1、敌跨轮净扣8；s283502→283507末试8挡/损7、敌净扣24（含下一轮自动伤，非全部牌伤）。sl987—992六次均未通关。

处置及缺数据：缺同预算饱和排序校准、跨弃牌重规划的整候选执行归属和成对完整后继；六次失败不足确定新SL成本阈值。

预期行为、反例与验证：现有notWorse/deathShare候选池和排名路径仍在；不把初案中后来被弃的精确切击算成整轮执行。后续须保存完整候选身份和重规划前后兑现，现门槛保持。

来源任务 `postmortem` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## silent-proposal-04b6b430759815ed：waiting

角色/进阶/窗口：NHA2KW0RB7VP A10 F17T1/F33T1—2；K3676LU8B0UH A1 F30T2；SADL3CGYTGSR A7 F45T1。

账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md`；SHA256 `188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`。

核实证据：s217010建8毒、s232563建10毒、s283147建10毒；NHA s283506首次普通X1萎靡建−2力/2弱。现有蟹朝向子公式按当前进阶数据库取原始基伤并保留虚弱小数，不能将显示1再次取整当实际2。

处置及缺数据：蟹取整和已观察手数子公式已实现；油灯仍缺可靠首次消费来源及跨动作、新战与SL恢复的联合输入校准，其他X值/升级组合及能力整战后继未知。

预期行为、反例与验证：不以单帧拥有油灯推定首次尚未用；其他状态、升级与零X不外推。仅原已证分支继续有效，联合状态接口和全战兑现待实盘验证。

来源任务 `experience-update` → 本批 `strategy-proposal/silent`。本批无新增实现；原始提案原文不覆盖。

## 参数、验证、回退与交付

无新参数、固定阈值、候选删减或架构调整；其他角色及未观察分支均未改。需要数值拟合时按独立run及开始时间切分，旧失败/SL同组保留，新局后移验证；不将rollout样本、局内多帧或同局六试当独立胜率证据。

无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均为null；没有执行沙箱生产测试，也不借历史绿记录。无新增commit、merged=null、无eval版本、未登记implemented/shipped。根账本仅经ledger.py为31个既有条目追加本批where/note追溯，保持claim/evidence/first_run/prior/status/version，不新增无证经验、不代ops标shipped；CLI输入/回执与保护字段复核另存。不重复登记十个既有code_proposals id，调度器按proposal_results保留waiting，等具体新数据再派。

本批没有上线需回退的行为；若未来实现，仅回退对应独立源码提交并保留原失败、刷新数据与证据。原有Roy授权不提供游戏事实。没有规则实际发布，因此不造上线记录、版本或已通知消费者的声明。

保留的材料适配错误见material-probe-corrections.json：一次辅助决策缺chosen字段的KeyError、两处不存在源码路径探针、早期过长输出截断；之后按实际schema和精确文件复核，完整材料检查通过，不当产品失败。原始工具转录保留于宿主本批jsonl。

运维交付提案路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-180124-s2/learner/runs/20261015-180132-9a82af16-332b-424a-aa77-424f6f3024a0-strategy-proposal/proposal.md`。最终报告：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-180124-s2/learner/runs/20261015-180132-9a82af16-332b-424a-aa77-424f6f3024a0-strategy-proposal/report.md`；机器处置：result.json、proposal-results.json。工作树HEAD=3e1d6d5405fc9cbf6cea7858dfe79f7e49c88ccb、git diff --binary为空，git status应为空。全部过程文件仅在本批忽略的learner/runs目录，根CLI账本追加在许可例外内。未推送、未改ops prompt、未读key/.env/游戏二进制、未操作对局。

最终验收补记：31条根账本CLI更新已成功，ledger-protection.json确认所有受保护字段相等。11个live源码叶的磁盘SHA均与固定live提交blob一致。新写报告、CLI输入、核验脚本与来源摘要共23文件/198421字节，经gitleaks 8.30.1扫描退出0、无泄漏；该范围不包括只读原日志证据全量。最终工作树clean、HEAD及空diff核验见final-checks.json。

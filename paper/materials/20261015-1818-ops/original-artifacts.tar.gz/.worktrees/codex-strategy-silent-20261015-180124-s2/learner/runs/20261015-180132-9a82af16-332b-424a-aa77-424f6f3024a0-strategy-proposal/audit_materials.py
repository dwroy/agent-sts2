import hashlib
import json
import sys
from pathlib import Path

OUT = Path(__file__).parent


def powers(items):
    return {p['power_id']: p['amount'] for p in items or []}


def refs(row):
    return {k: row[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def slim_states():
    digest = hashlib.sha256()
    count = 0
    with (OUT / 'evidence/states.evidence.jsonl').open('rb') as source, (OUT / 'states-thin.jsonl').open('w') as target:
        for raw in source:
            digest.update(raw)
            x = json.loads(raw)
            r = x['row']
            s = r['state']
            run = s.get('run') or {}
            assert run.get('character_id', '').lower() == 'silent'
            c = s.get('combat') or {}
            p = c.get('player') or {}
            row = dict(refs(x), ts=r['ts'], observed_ts=r.get('observed_ts'), screen=s.get('screen'),
                       floor=run.get('floor'), turn=s.get('turn'), hp=run.get('current_hp'),
                       max_hp=run.get('max_hp'), energy=p.get('energy'), block=p.get('block'),
                       powers=powers(p.get('powers')), ready=c.get('action_readiness'),
                       hand=[{k: card.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost', 'dynamic_values')}
                             for card in c.get('hand', [])],
                       enemies=[dict(index=e['index'], id=e['enemy_id'], hp=e.get('current_hp'),
                                     block=e.get('block'), alive=e.get('is_alive'), move=e.get('move_id'),
                                     powers=powers(e.get('powers')), intents=e.get('intents'))
                                for e in c.get('enemies', [])],
                       potions=[p.get('potion_id') if p.get('occupied') else None for p in run.get('potions', [])],
                       relics=[p.get('relic_id') for p in run.get('relics', [])])
            target.write(json.dumps(row, ensure_ascii=False) + '\n')
            count += 1
    (OUT / 'thin-source.json').write_text(json.dumps({'rows': count, 'input_sha256': digest.hexdigest()}, indent=2) + '\n')
    print(json.dumps({'states': count, 'input_sha256': digest.hexdigest()}))


def verify_sources():
    manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
    results = []
    for stream in manifest:
        count = 0
        digest = hashlib.sha256()
        with (OUT / 'evidence' / (stream['stream'] + '.evidence.jsonl')).open('rb') as selected:
            with Path('/home/dw/Projects/agent-sts2/logs', stream['stream'] + '.jsonl').open('rb') as original:
                for raw in selected:
                    digest.update(raw)
                    x = json.loads(raw)
                    assert x['offset'] + x['bytes'] <= stream['source_size']
                    original.seek(x['offset'])
                    source = original.read(x['bytes'])
                    assert hashlib.sha256(source).hexdigest() == x['sha256']
                    assert json.loads(source) == x['row']
                    r = x['row']
                    fp = r.get('fingerprint')
                    if isinstance(fp, str):
                        fp = json.loads(fp)
                    s = r.get('state') or {}
                    identities = {v for v in [r.get('run_id'), r.get('run'), s.get('run_id'),
                                              (fp or {}).get('run')]
                                  if isinstance(v, str) and v and v != 'run_unknown'}
                    assert identities == {x['run_id']}
                    count += 1
        assert count == sum(stream['counts'].values())
        assert digest.hexdigest() == stream['output_sha256']
        results.append({'stream': stream['stream'], 'rows': count, 'source_size': stream['source_size'],
                        'offset_bytes_sha_json_identity': True, 'sha256': digest.hexdigest()})
    thin = json.loads((OUT / 'thin-source.json').read_text())
    assert thin['input_sha256'] == results[0]['sha256']
    result = {'total_rows': sum(r['rows'] for r in results), 'streams': results, 'thin_matches_final': True}
    (OUT / 'raw-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    verify_sources() if len(sys.argv) > 1 and sys.argv[1] == 'verify' else slim_states()

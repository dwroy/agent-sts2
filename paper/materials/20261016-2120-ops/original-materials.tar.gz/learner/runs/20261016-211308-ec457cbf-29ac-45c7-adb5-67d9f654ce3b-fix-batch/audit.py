import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-211301'
SCRATCH = ROOT / 'learner/runs/20261016-211308-ec457cbf-29ac-45c7-adb5-67d9f654ce3b-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261016-204311-be49f09c-e819-4b99-ab6e-f807a25cb527-fix-batch'
EXPECTED_BASE = 'e207d1db4222f6e66d4cccc31ad6a6c3bc3aca23'
SHADOW_SOURCE = '70c61acfb'


def git(*args, tree=TREE, binary=False):
    value = subprocess.check_output(['git', '-C', str(tree), *args])
    return value if binary else value.decode().strip()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


# Reuse earlier conclusions only after checking the current source and queue bytes.
checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
base = git('rev-parse', 'HEAD')
assert base == EXPECTED_BASE, base
assert not git('status', '--porcelain=v1')
prior_raw = (PREVIOUS / 'audit.json').read_bytes()
prior = json.loads(prior_raw)
prior_result = json.loads((PREVIOUS / 'result.json').read_text())
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live')
base_ancestors = set(git('rev-list', base).splitlines())
live_ancestors = set(git('rev-list', live).splitlines())
shadow_source = git('rev-parse', SHADOW_SOURCE)
assert shadow_source in base_ancestors and shadow_source in live_ancestors

source_changes = git('diff', '--name-only', prior['base'], base, '--',
                     'agent', 'learner', 'ops', 'eval', 'knowledge/builders').splitlines()
expected_changes = {
    'agent/src/core/config.ts', 'agent/tests/build-rank-integration.test.ts',
    'agent/tests/build-rank.test.ts', 'agent/tests/s-decision.test.ts',
    'eval/versions.json', 'ops/inbox-dev.md',
}
assert set(source_changes) == expected_changes, source_changes
files = []
for old in prior['current_files']:
    relative = Path(old['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    assert '.env' not in relative.name
    raw = (TREE / relative).read_bytes()
    current_sha = digest(raw)
    same = current_sha == old['sha256']
    assert same or str(relative) in ('agent/src/core/config.ts', 'eval/versions.json'), str(relative)
    files.append({'path': str(relative), 'sha256': current_sha, 'same_as_prior': same,
                  'previous_sha256': old['sha256']})

# The intervening P1/P2 change is an already published default, not a new batch fix.
shadow_files = []
for name in sorted(expected_changes - {'eval/versions.json', 'ops/inbox-dev.md'}):
    raw = (TREE / name).read_bytes()
    source_raw = git('show', f'{shadow_source}:{name}', binary=True)
    assert raw == source_raw, name
    shadow_files.append({'path': name, 'sha256': digest(raw), 'same_as_published_source': True})

fixed = []
for row in prior['existing_fixes']:
    assert row['commit'] in base_ancestors and row['commit'] in live_ancestors, row
    fixed.append({**row, 'ancestor_in_base': True, 'ancestor_in_live': True,
                  'subject': git('show', '-s', '--format=%s', row['commit'])})

focused = []
for row in prior['focused_source_review']:
    lines = (TREE / row['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if row['anchor'] in line]
    assert found, row
    focused.append({'path': row['path'], 'anchor': row['anchor'], 'lines': found})

queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
old_queue = (PREVIOUS / 'queue-readonly-snapshot.md').read_bytes()
assert digest(old_queue) == prior['queue_sha256']
assert queue.startswith(old_queue)
added = queue[len(old_queue):].decode()
assert 'infra-test-rollout-ties-host-timeout-15000' in added
assert all(not line.startswith('- ') or 'infra-test-rollout-ties-host-timeout-15000' in line
           for line in added.splitlines()), added
unchecked = [(i + 1, line) for i, line in enumerate(queue.decode().splitlines()) if line.startswith('- [ ]')]
assert unchecked == [(row['line'], row['item']) for row in prior['queue_dispositions']]
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)

original_refs = []
for row in prior['raw_original_references'] + prior['new_0332_original_references']:
    relative = Path(row['source'])
    assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'logs'
    with (ROOT / relative).open('rb') as source:
        source.seek(row['offset'])
        raw = source.read(row['bytes'])
    assert digest(raw) == row['sha256'], row
    json.loads(raw)
    original_refs.append({**row, 'sha256_verified': True, 'json_parsed': True})

ops_dir = ROOT / 'paper/materials/20261016-2042-ops'
failure_raw = (ops_dir / 'host-failure-disposition.json').read_bytes()
failure = json.loads(failure_raw)
supplement_raw = (ops_dir / 'accepted-host-supplement.json').read_bytes()
supplement = json.loads(supplement_raw)
receipt = supplement['receipt']
assert failure['original_full_rc'] == 1 and supplement['original_full_rc'] == 1
assert failure['coverage']['failed'] == ['tests/rollout-ties.test.ts']
assert receipt['live']['commit'] == failure['original_check']['merged']
assert receipt['live']['tree'] == failure['original_check']['tree']
assert receipt['rc'] == 0 and not receipt['full_suite']
assert [row['rc'] for row in receipt['results']] == [0, 0]
assert receipt['results'][1]['counts'] == {
    'numTotalTests': 5, 'numPassedTests': 1, 'numFailedTests': 0, 'numPendingTests': 4,
}
test_name = 'agent/tests/rollout-ties.test.ts'
test_raw = (TREE / test_name).read_bytes()
original_test = git('show', f"{receipt['live']['commit']}:{test_name}", binary=True)
assert original_test.count(b'(Dai 2026-09-29;') == 1
assert test_raw == original_test.replace(b'(Dai 2026-09-29;', b'(Roy 2026-09-29;', 1)
(SCRATCH / 'rollout-ties-original-to-base.diff').write_bytes(
    git('diff', '--binary', receipt['live']['commit'], base, '--', test_name, binary=True))
log_refs = []
for path, expected in [(failure['original_check']['log'], failure['log_sha256']),
                       (receipt['log'], receipt['log_sha256'])]:
    path = Path(path)
    path.relative_to(ROOT / 'ops/codex-ops/learner')
    raw = path.read_bytes()
    assert digest(raw) == expected
    log_refs.append({'path': str(path.relative_to(ROOT)), 'sha256': expected, 'bytes': len(raw)})
assert 'Test timed out in 15000ms' in (ROOT / log_refs[0]['path']).read_text()

assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain=v1')
assert (ROOT / 'notes/fix-queue-v4.md').read_bytes() == queue
audit = {
    'checked_at': checked_at, 'base': base, 'main_merge': 'Already up to date.',
    'prior_audit': str(PREVIOUS / 'audit.json'), 'prior_audit_sha256': digest(prior_raw),
    'live_read_only_snapshot': live, 'source_changes_since_prior': source_changes,
    'published_shadow_source': shadow_source, 'published_shadow_files': shadow_files,
    'current_files': files, 'existing_fixes': fixed, 'focused_source_review': focused,
    'queue_sha256': digest(queue), 'queue_lines': len(queue.splitlines()), 'queue_append': added,
    'unchecked_entries': len(unchecked), 'queue_dispositions': prior['queue_dispositions'],
    'raw_original_references': original_refs,
    'new_timeout_review': {
        'item': 'infra-test-rollout-ties-host-timeout-15000',
        'failure_receipt_sha256': digest(failure_raw),
        'supplement_receipt_sha256': digest(supplement_raw),
        'test_sha256': digest(test_raw), 'original_test_sha256': digest(original_test),
        'same_as_original_failed_tree': False,
        'test_difference': '仅文件首部Dai→Roy历史署名注释差；其余字节完全相同，原用例/断言/时限保持。',
        'original_full_rc': 1, 'historical_supplement_tsc': 0,
        'historical_supplement_vitest': 0, 'historical_supplement_counts': receipt['results'][1]['counts'],
        'original_logs': log_refs, 'root_cause': 'unknown',
        'disposition': '证据不足；沿原普通fix链待充分复现，不改时限/断言，不将定向通过冒报全套绿。',
    },
    'scope': '只读去重；无新源码/测试/提交/账本状态/live改动；历史结果不当本批生产测试。',
}
save('audit.json', audit)
result = {**prior_result, 'base': base, 'fixes': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0},
          'code_proposals': [], 'implementation_domains': [], 'report': str(SCRATCH / 'report.md')}
result['skipped'].append({
    'item': 'infra-test-rollout-ties-host-timeout-15000',
    'reason': '证据不足；原同树单题3256.179ms通过，当前测试仅历史署名注释差；根因仍未知，按队列要求待充分复现，不调时限/弱化断言或冒称已修。',
})
save('result.json', result)
lines = [
    '## 修 bug 回报', '',
    f'- 合并基线：main → {base}（开工干净，先合main，无冲突，Already up to date.）',
    '- 修复（每条一行）：无新增纯bug修复；42条未勾选原文未变，83项既有窄修复仍是base及所核live祖先。'
    '387个已核文件SHA不变；另2个已核文件变化来自既有P1/P2 shadow发布及版本登记，其4叶与实际发布源一致。'
    '无新增源码或测试，撤源码红绿验证不适用。',
]
for row in fixed:
    lines.append(f"- 已被别人修掉的：{row['item']} — {row['commit']}（仅已核窄子项，更宽父项保留）")
for row in result['skipped']:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines.extend([
    '- 测试：tsc未运行，退出码null；vitest未运行，0文件 / 0用例 / 退出码null；本批无重跑。'
    '无源码改动/提交/合入，不重复跑未变源；原日志SHA/JSON核验不是生产测试。',
    f'- 合入：未合入（无新增提交）；live只读快照 {live}；未执行空合并、版本登记、shipped或回收。',
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
])
(SCRATCH / 'report.md').write_text('\n'.join(lines))
print(json.dumps({'base': base, 'live_snapshot': live, 'unchanged_files': sum(r['same_as_prior'] for r in files),
                  'verified_existing_fixes': len(fixed), 'unchecked_entries': len(unchecked),
                  'original_rows_verified': len(original_refs), 'skipped': len(result['skipped']),
                  'source_changes_this_batch': [], 'report': result['report']}, ensure_ascii=False))

/**
 * B2 (Roy 2026-09-30, docs/boss-sim.md §11): in a boss fight, every line Jev is shown (plan lines, potion lines, the
 * random potions' "drink now" lines) is played to the fight's end by the whole-fight simulator (boss-sim.ts), all on the
 * same seeds, each under its best kill order. The question then carries each line's calibrated win rate, its paired
 * difference to the best line (± standard error), the HP lost in the samples won, the turns to the end and the turn the
 * losing samples die on; the best line (rollout_best) is the one with the highest simulated win rate (lines within
 * BOSS_LINES_TIE_SE standard errors tied), then admitted paired S for Silent's P3 path, then the least HP lost in the
 * samples won (median; V4.2). Other roles and failed S gates retain the V4.2 ranking. Jev still picks the
 * line each turn: the simulation only
 * adds numbers and, every few turns, a fight plan summarised from the best line's winning samples; code never plays the
 * plan. Bosses the simulator is known to get wrong (LOW_TRUST_BOSSES) keep the 5-turn rollout's ranking, and their
 * numbers and plan go to the decision log only, not to Jev's question (V4.2, Roy 2026-10-01).
 *
 * Time: the planner is synchronous, so the samples run on a pool of worker threads (BossLinesPool) that the planner's
 * thread waits on (Atomics.wait on a shared counter; replies read with receiveMessageOnPort). The pool is built at the
 * fight's first question and kept for the fight. Each question gets a deadline (BOSS_LINES_DEADLINE_MS, and what is left
 * of the turn's BOSS_LINES_TURN_BUDGET_MS); past it the samples every line has finished are used and their count shown.
 *
 * Switch: BOSS_SIM_LINES=off (bossLinesOptions.enabled) leaves the question and its ranking as they were before B2.
 */

import { ADAPTIVE_RULE, safeAdaptiveShadow } from "./adaptive-shadow.js";
import { simAdaptivePolicy, sCombatRankEnabled, sCombatRankMode } from "../core/config.js";
import { rankByBossMargin, type CombatSRanking } from "./s-combat-rank.js";
import { auditSigns } from "./s-sign.js";
import { AdaptiveSampler, isAdaptiveComplete } from "./adaptive-sampler.js";
import { sampleSchedule, type SampleRange } from "./sample-range.js";
import { beginComputation, type SimAttempt, type SimCompletion } from "./computation-failure.js";
import { ContinuationSampleError, continuationFailureOf, preserveContinuationFailure, type ContinuationFailure } from "./continuation-failure.js";
import type { SimProgress, SimWait } from "./computation-wait.js";
import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { availableParallelism } from "node:os";
import { MessageChannel, receiveMessageOnPort, Worker, type MessagePort } from "node:worker_threads";

import type { Knowledge } from "../knowledge/index.js";
import type { GameState } from "../hand/mod/schema.js";
import type { ScreenMemory } from "../memory/types.js";
import { asArray, asRecord, toJsonValue, type JsonValue } from "../core/util/json.js";
import { summarizeBossMargin } from "./boss-margin.js";
import { quantitativeEnabled } from "./quantitative-facts.js";
import type { CardModel } from "../reflex/card-model.js";
import type { PotionMcSource } from "../reflex/potion-mc.js";
import type { KillOrder, RolloutInput } from "../reflex/rollout.js";
import { boardRolloutInput, fightMetaOf, fightRelicsOf } from "../reflex/rollout-live.js";
import type { Plan, SolverInput } from "../reflex/turn-solver.js";
import {
  BOSS_SIM_DAMAGE_SCALE,
  BOSS_SIM_HP_SCALE,
  BOSS_SIM_MAX_TURNS,
  BOSS_SIM_MAX_WORKERS,
  BOSS_SIM_POLICY_NODES,
  BOSS_SIM_POTION_HOLD,
  BOSS_SIM_THREAT,
  calibratedWinProb,
  compareLines,
  fightOrders,
  fightSample,
  quantile,
  sampleSeed,
  slimInput,
  summarizeLine,
  tableHoldHp,
  type BossSimLineResult,
  type FightSampleResult,
  type LineComparison,
} from "./boss-sim.js";
import { knowledgeDataDirs } from "../knowledge/files.js";
import { LOW_TRUST_B2, bossTrustReason } from "./boss-trust.js";
import { identityToken, memoKey, type ComputeMemo } from "./compute-memo.js";
import { claimSimCores, leaveSimCores } from "./sim-pools.js";
import { withDoubleBossStart } from "./double-boss-start.js";
import { firstDoubleBoss } from "../knowledge/double-boss.js";
import { f48JointScope, f48JointShadow } from "./f48-joint-shadow.js";

/** Samples per line (docs/boss-sim.md §8: 600 give a paired win-rate standard error of ~1-2 points). */
export const BOSS_LINES_SAMPLES = 600;
/** One question's wall-clock limit for the samples. */
export const BOSS_LINES_DEADLINE_MS = 25_000;
/** A turn's limit over its questions (a re-plan after a draw asks again): Roy's 20-30 s a boss turn. */
export const BOSS_LINES_TURN_BUDGET_MS = 30_000;
/** Less than this left of the turn's budget: no simulation for this question. */
export const BOSS_LINES_MIN_MS = 3_000;
/**
 * Worker threads (BOSS_SIM_WORKERS; V4.2: 20, was 12; the live runs keep the other cores). A boss fight's questions
 * never run with B3's build questions, and the two pools never hold workers at once (sim-pools.ts).
 */
export const BOSS_LINES_WORKERS = 20;
export const BOSS_LINES_SEED = 7;
/** Win rates within this many paired standard errors of the top one are tied (then the least HP lost when won decides). */
export const BOSS_LINES_TIE_SE = 2;

/**
 * The ranking's second criterion (V4.2, Roy 2026-10-01): the median HP lost in the samples won, the number the question
 * shows (it was the mean over every sample, a death counting all our HP). A line with no winning sample comes last.
 */
export function wonLoss(line: BossSimLineResult): number {
  return line.hpLossWon?.median ?? Infinity;
}
/** The fight plan is shown on turn 1 and every this many turns after. */
export const BOSS_LINES_PLAN_EVERY = 3;
/** An action goes into the fight plan when at least this share of the best line's winning samples take it. */
export const BOSS_LINES_PLAN_SHARE = 0.5;

function envWorkers(): number | null {
  const n = Number(process.env["BOSS_SIM_WORKERS"]);
  return Number.isFinite(n) && n >= 1 ? Math.floor(n) : null;
}

/** The switch (BOSS_SIM_LINES=off) and test hooks. `serial`: run the samples in this thread (tests; no deadline inside a sample). */
export const bossLinesOptions: {
  enabled: boolean;
  /**
   * BOSS_SIM_LOW_TRUST: when a low-trust boss's fight is simulated. "retry" (default, Roy 2026-10-02): only on an SL retry,
   * where SL_RETRY_SHOW_SIM shows its numbers; on a first attempt its numbers only went to the decision log, at up to 25 s
   * a question and most of the machine's cores (Kaiser Crab 80-150 s a fight before it was trusted), which cut the same
   * question's rollout. "always": as before (simulated for the log on every question).
   */
  lowTrust: "retry" | "always";
  samples: number;
  deadlineMs: number;
  turnBudgetMs: number;
  minMs: number;
  workers: number;
  seed: number;
  serial: boolean;
  now: (() => number) | null;
  /** Called with every question's result (tools/boss-sim/b2-lines.ts reads the lines' samples). */
  onSim: ((sim: BossLineSim) => void) | null;
  /** The potions' held value for the sim policy's hold (default: the potion table, boss-sim tableHoldHp). */
  holdHp: ((potionId: string, input: RolloutInput) => number | null) | null;
} = {
  enabled: process.env["BOSS_SIM_LINES"] !== "off",
  lowTrust: process.env["BOSS_SIM_LOW_TRUST"] === "always" ? "always" : "retry",
  samples: BOSS_LINES_SAMPLES,
  deadlineMs: BOSS_LINES_DEADLINE_MS,
  turnBudgetMs: BOSS_LINES_TURN_BUDGET_MS,
  minMs: BOSS_LINES_MIN_MS,
  workers: envWorkers() ?? BOSS_LINES_WORKERS,
  seed: BOSS_LINES_SEED,
  serial: false,
  now: null,
  onSim: null,
  holdHp: null,
};

/**
 * Bosses whose simulated numbers stay out of Jev's question (the 5-turn rollout keeps ranking the lines; the decision
 * log keeps the numbers), and why: B4's criteria on each boss's validation numbers from turn 1 (docs/boss-sim.md §13),
 * the data file knowledge/characters/ironclad/boss-trust.json that tools/boss-sim/trust.py writes (boss-trust.ts LOW_TRUST_B2).
 */
export const LOW_TRUST_BOSSES: Record<string, string> = LOW_TRUST_B2;

/** The boss of a fight by its enemies' ids (the encounter's key in LOW_TRUST_BOSSES and the monster DB's bosses). */
export function bossKeyOf(enemyIds: string[]): string | null {
  const ids = new Set(enemyIds);
  if (ids.has("CRUSHER") || ids.has("ROCKET")) return "KAISER_CRAB";
  if (ids.has("KIN_PRIEST")) return "THE_KIN";
  if (ids.has("QUEEN")) return "QUEEN";
  const known = ["AEONGLASS", "CEREMONIAL_BEAST", "KNOWLEDGE_DEMON", "LAGAVULIN_MATRIARCH", "SOUL_FYSH", "TEST_SUBJECT", "THE_INSATIABLE", "VANTOM", "WATERFALL_GIANT"];
  return known.find((id) => ids.has(id)) ?? null;
}

/** A live fight's low-trust reason by the state's enemies (null: a boss the simulator is trusted on, or no known boss). */
export function lowTrustOfState(state: GameState): string | null {
  const enemies = (state.raw["combat"] as { enemies?: unknown } | null | undefined)?.enemies;
  const ids = Array.isArray(enemies) ? enemies.map((e) => String((e as Record<string, unknown> | null)?.["enemy_id"] ?? "")) : [];
  const boss = bossKeyOf(ids);
  return boss ? bossTrustReason(boss, "b2", state.run?.ascension, state.run?.floor) : null;
}

// ---------------------------------------------------------------- input

export interface BossSimInputArgs {
  state: GameState;
  knowledge: Knowledge;
  memory: ScreenMemory;
  /** This turn's solver input as the rollout gets it (the random potions' expected-value cards in the hand). */
  solver: SolverInput;
  /**
   * Base draw and discard piles (rollout-live's); `drawTop` (SL_RETRY_KNOWN_DRAWS): the pile's known top cards in draw order,
   * as indices into `draw` (RolloutInput.piles.drawTop: every sample draws them first); `drawAdded` (SL_RETRY_KNOWN_INSERTS):
   * cards added to the pile at random places (RolloutInput.piles.drawAdded).
   */
  piles: { draw: CardModel[]; discard: CardModel[]; drawTop?: number[]; drawAdded?: number[] };
  /** The random potions held (potion-mc sources): sampled anew each later turn. */
  randomPotions: PotionMcSource[];
}

/** The whole-fight input of a live board: the rollout's (rollout-live boardRolloutInput, fightMetaOf) plus the turn relics and random potions. */
export function bossSimInput(args: BossSimInputArgs): RolloutInput {
  const meta = fightMetaOf(args.state, args.knowledge, args.memory);
  const { handBase, ...board } = boardRolloutInput(args.state, args.knowledge, args.solver, meta.asc);
  const runRaw = (args.state.run?.raw ?? {}) as Record<string, unknown>;
  const input: RolloutInput = {
    ...board,
    ...(quantitativeEnabled(args.state) ? { captureBossMargin: true } : {}),
    plans: [],
    piles: { draw: args.piles.draw, discard: args.piles.discard, handBase, ...(args.piles.drawTop && args.piles.drawTop.length > 0 ? { drawTop: args.piles.drawTop, ...(args.piles.drawAdded && args.piles.drawAdded.length > 0 ? { drawAdded: args.piles.drawAdded } : {}) } : {}) },
    meta: { ...meta, kind: "boss" },
    mm: {},
    model: null,
    gates: null,
    fightRelics: fightRelicsOf(runRaw, args.solver.turn ?? meta.t),
    ...(args.randomPotions.length > 0 ? { randomPotions: args.randomPotions.map((source) => ({ ...source, cost: args.solver.continuationValue ? source.cost ?? 0 : 0 })) } : {}),
  };
  const model = firstDoubleBoss(args.state);
  return model ? withDoubleBossStart(args.state, args.knowledge, input, model) : input;
}

// ---------------------------------------------------------------- the synchronous worker pool

export interface LinesPair {
  plan: Plan | null;
  order: KillOrder | null;
  /** Diagnostic identity in runLines' flattened line/order list; absent for direct pool callers. */
  lineIndex?: number;
  orderIndex?: number;
}

/** Messages to a worker (boss-lines-worker.ts). */
export type LinesWorkerRequest =
  | { type: "input"; job: number; input: RolloutInput; pairs: LinesPair[]; maxTurns: number }
  | { type: "run"; job: number; tasks: [pair: number, sample: number, seed: number][] }
  | { type: "drop"; job: number };
export type LinesWorkerReply = { job: number; results: [pair: number, sample: number, result: FightSampleResult][] }
  | { job: number; error: string; continuationFailure?: ContinuationFailure };

export interface PairsRun {
  /** outcomes[pair][sample]: undefined for a sample not finished by the deadline. */
  outcomes: (FightSampleResult | undefined)[][];
  /** Sample indices every pair finished (the common random numbers the lines are compared on). */
  complete: number[];
  timedOut: boolean;
  elapsedMs: number;
  workers: number;
  /**
   * (pair, sample) fights whose results came back (of samples x pairs): more than complete x pairs when the deadline cut
   * samples some pairs had finished (their work is not used). A chunk still running at the deadline is not counted.
   */
  done: number;
}

export interface PairWork {
  range?: SampleRange;
  activePairs?: readonly number[];
}

/**
 * The data files a pool's workers load when they start (the knowledge JSON files: knowledge/files.ts knowledgeDataDirs; the refresh job rewrites some
 * between runs), by content: the SL retry compute memo keys a pool's runs by it (BossLinesPool.data), so a pool rebuilt
 * on the same data finds its predecessor's runs and one on new data does not. null when they cannot be read.
 */
export function workerDataSignature(): string | null {
  try {
    const hash = createHash("sha256");
    for (const dir of knowledgeDataDirs()) {
      // A character with no knowledge yet has no characters/<id>/ directory: nothing of its own to sign.
      if (!existsSync(dir)) continue;
      for (const name of readdirSync(dir).filter((f) => f.endsWith(".json")).sort()) hash.update(name).update("\u0000").update(readFileSync(join(dir, name))).update("\u0000");
    }
    return hash.digest("hex").slice(0, 32);
  } catch {
    return null;
  }
}

interface PoolWorker {
  worker: Worker;
  port: MessagePort;
  busy: boolean;
}

/**
 * Worker threads the planner's (synchronous) thread waits on. Built once for a fight (a worker loads the solver in
 * ~0.4 s) and reused; close() when the fight is over. One run at a time. Starting its workers releases B3's build pool
 * (sim-pools.ts); a build pool starting releases this one.
 */
export class BossLinesPool {
  readonly size: number;
  private workers: PoolWorker[] = [];
  private readonly signal = new SharedArrayBuffer(8);
  private readonly flag = new Int32Array(this.signal);
  private job = 0;
  /** The data its workers loaded (workerDataSignature at their start; null: not started, or unreadable). */
  data: string | null = null;

  constructor(size = bossLinesOptions.workers) {
    this.size = Math.max(1, Math.min(BOSS_SIM_MAX_WORKERS, availableParallelism() - 2, Math.floor(size)));
  }

  private start(): PoolWorker[] {
    if (this.workers.length > 0) return this.workers;
    // TypeScript when this module is (tsx, vitest): the worker loads through tsx too.
    const ts = import.meta.url.endsWith(".ts");
    const url = new URL(ts ? "./boss-lines-worker.ts" : "./boss-lines-worker.js", import.meta.url);
    claimSimCores(this, "boss-lines", () => {
      if (shared === this) shared = null;
      void this.close();
    });
    this.data = workerDataSignature();
    for (let k = 0; k < this.size; k += 1) {
      const { port1, port2 } = new MessageChannel();
      const worker = new Worker(url, { workerData: { port: port2, signal: this.signal }, transferList: [port2], ...(ts ? { execArgv: ["--import", "tsx"] } : {}) });
      worker.unref();
      port1.unref();
      this.workers.push({ worker, port: port1, busy: false });
    }
    return this.workers;
  }

  /** Every (pair, sample) to the fight's end, sample-major, until done or `deadlineMs` of wall clock. */
  run(input: RolloutInput, pairs: LinesPair[], samples: number, seed: number, deadlineMs: number, now: () => number = () => performance.now(), onProgress?: SimProgress, work?: PairWork): PairsRun {
    const started = now();
    const schedule = sampleSchedule(samples, pairs.length, work?.range, work?.activePairs);
    if (!schedule.indices.length || schedule.from === schedule.to) return {
      outcomes: pairs.map(() => new Array<FightSampleResult | undefined>(samples)), complete: [], timedOut: false,
      elapsedMs: Math.round(now() - started), workers: 0, done: 0,
    };
    const workers = this.start();
    const job = (this.job += 1);
    Atomics.store(this.flag, 1, job);
    const tasks: [number, number, number][] = [];
    for (let i = schedule.from; i < schedule.to; i += 1) for (const pair of schedule.indices) tasks.push([pair, i, sampleSeed(seed, i)]);
    const chunk = Number.isFinite(deadlineMs) ? Math.max(1, Math.ceil(tasks.length / (workers.length * 8))) : 8;
    const chunks: [number, number, number][][] = [];
    for (let k = 0; k < tasks.length; k += chunk) chunks.push(tasks.slice(k, k + chunk));
    const outcomes: (FightSampleResult | undefined)[][] = pairs.map(() => new Array<FightSampleResult | undefined>(samples));
    for (const w of workers) w.worker.postMessage({ type: "input", job, input, pairs, maxTurns: BOSS_SIM_MAX_TURNS } satisfies LinesWorkerRequest);
    let pending = chunks.length;
    let done = 0;
    let error: string | null = null;
    let failure: ContinuationFailure | undefined;
    const give = (w: PoolWorker) => {
      const next = chunks.shift();
      if (!next) return;
      w.busy = true;
      w.worker.postMessage({ type: "run", job, tasks: next } satisfies LinesWorkerRequest);
    };
    for (const w of workers) if (!w.busy) give(w);
    let timedOut = false;
    let lastReply = Date.now();
    while (pending > 0 && error === null) {
      const seen = Atomics.load(this.flag, 0);
      let got = false;
      for (const w of workers) {
        for (let msg = receiveMessageOnPort(w.port); msg; msg = receiveMessageOnPort(w.port)) {
          got = true;
          lastReply = Date.now();
          w.busy = false;
          const reply = msg.message as LinesWorkerReply;
          if (reply.job === job) {
            if ("error" in reply) {
              error = reply.error;
              failure = reply.continuationFailure;
            }
            else {
              for (const [pair, i, result] of reply.results) outcomes[pair]![i] = result;
              done += reply.results.length;
              onProgress?.(done, tasks.length);
              pending -= 1;
            }
          }
          if (error === null) give(w);
        }
      }
      if (pending === 0 || error !== null) break;
      if (!Number.isFinite(deadlineMs) && Date.now() - lastReply > 120_000) {
        error = "required evaluation worker made no progress for 120 seconds; no partial result accepted";
        break;
      }
      const left = deadlineMs - (now() - started);
      if (left <= 0) {
        timedOut = true;
        break;
      }
      if (!got) Atomics.wait(this.flag, 0, seen, Math.min(left, 250));
    }
    // Done or given up: the workers skip what is left of this job (they check the job slot between samples).
    Atomics.store(this.flag, 1, 0);
    for (const w of workers) w.worker.postMessage({ type: "drop", job } satisfies LinesWorkerRequest);
    if (error !== null) {
      const message = `boss-lines worker: ${error}`;
      throw failure ? new ContinuationSampleError(message, failure) : new Error(message);
    }
    const complete: number[] = [];
    for (let i = schedule.from; i < schedule.to; i += 1) if (schedule.indices.every((pair) => outcomes[pair]![i] !== undefined)) complete.push(i);
    return { outcomes, complete, timedOut, elapsedMs: Math.round(now() - started), workers: workers.length, done };
  }

  /** Workers running now (0 before the first run and after close()). */
  get live(): number {
    return this.workers.length;
  }

  async close(): Promise<void> {
    const workers = this.workers;
    this.workers = [];
    leaveSimCores(this);
    await Promise.all(workers.map((w) => w.worker.terminate()));
  }
}

let shared: BossLinesPool | null = null;

/** The fight's pool (built on the first boss question). */
export function bossLinesPool(): BossLinesPool {
  return (shared ??= new BossLinesPool());
}

/** The data signature of the fight's pool when its workers run (null: no pool running, or its data unreadable). */
export function bossLinesPoolData(): string | null {
  return shared && shared.live > 0 ? shared.data : null;
}

/** Out of the boss fight: the workers go (a no-op without a pool). */
export function releaseBossLinesPool(): void {
  const pool = shared;
  shared = null;
  if (pool) void pool.close();
}

/** The same runs in this thread (tests, tools): a deadline is checked between samples. */
export function runPairsSerial(input: RolloutInput, pairs: { plan: Plan | null; order: KillOrder | null }[], samples: number, seed: number, deadlineMs = Infinity, now: () => number = () => performance.now(), onProgress?: SimProgress, work?: PairWork): PairsRun {
  const started = now();
  const schedule = sampleSchedule(samples, pairs.length, work?.range, work?.activePairs);
  const outcomes: (FightSampleResult | undefined)[][] = pairs.map(() => new Array<FightSampleResult | undefined>(samples));
  let timedOut = false;
  let done = 0;
  for (let i = schedule.from; i < schedule.to && !timedOut; i += 1) {
    for (const pair of schedule.indices) {
      if (now() - started > deadlineMs) {
        timedOut = true;
        break;
      }
      outcomes[pair]![i] = fightSampleOf(input, pairs[pair]!, sampleSeed(seed, i));
      done += 1;
      onProgress?.(done, (schedule.to - schedule.from) * schedule.indices.length);
    }
  }
  const complete: number[] = [];
  for (let i = schedule.from; i < schedule.to; i += 1) if (schedule.indices.length && schedule.indices.every((pair) => outcomes[pair]![i] !== undefined)) complete.push(i);
  return { outcomes, complete, timedOut, elapsedMs: Math.round(now() - started), workers: 0, done };
}

/** One (line, order) sample, as the worker runs it. */
function fightSampleOf(input: RolloutInput, pair: { plan: Plan | null; order: KillOrder | null }, seed: number): FightSampleResult {
  return fightSample(input, pair.plan, seed, BOSS_SIM_MAX_TURNS, true, pair.order);
}

// ---------------------------------------------------------------- lines, best orders, ranking

export interface LinesResult {
  adaptive?: JsonValue;
  continuation?: { source: string; limitation: string };
  /** Per line (the order given): its numbers under its best kill order. */
  lines: (BossSimLineResult & { order: string | null })[];
  /** Samples every line finished, and how many were asked for. */
  samples: number;
  requested: number;
  timedOut: boolean;
  elapsedMs: number;
  workers: number;
  /** Kill orders compared per line (besides the solver's own targets). */
  orders: number;
  /** (line, order) pairs run, and their fights whose results came back (PairsRun.done; samples x pairs used). */
  pairs?: number;
  done?: number;
  /**
   * The SL retry compute memo handed this run back (src/sim/compute-memo.ts): `elapsedMs` is then the stored run's time
   * (charged to the turn's budget and shown as if run), `wallMs` this question's own.
   */
  memo?: { wallMs: number };
}

/** Validate the actual per-line prefix counts before accepting a shortened computation. */
export function completeAdaptiveLines(run: LinesResult): boolean {
  return !run.timedOut && run.lines.length > 0 && run.samples === Math.min(...run.lines.map((line) => line.samples))
    && isAdaptiveComplete(run.adaptive, "b2", run.requested, new Map(run.lines.map((line, i) => [`line:${i}`, line.samples])));
}

/** The sim's input for these options (boss-sim slimInput at the B1.5 settings). */
export function linesInput(input: RolloutInput, holdHp = bossLinesOptions.holdHp ?? tableHoldHp): RolloutInput {
  return slimInput(input, BOSS_SIM_POLICY_NODES, BOSS_SIM_DAMAGE_SCALE, BOSS_SIM_HP_SCALE, BOSS_SIM_THREAT, BOSS_SIM_POTION_HOLD, holdHp);
}

/**
 * Every line under the solver's own targets and each kill order (fightOrders), on the same seeds, in one run; per line
 * the numbers of its best order (win rate, then the least HP lost when won, as the ranking). Only the samples
 * every (line, order) finished count, so all lines are compared on the same samples.
 */
export function runLines(
  input: RolloutInput,
  lines: Plan[],
  opts: { samples: number; seed: number; deadlineMs: number; serial?: boolean; now?: () => number; adaptive?: { allowS: boolean; mode?: "shadow" | "on"; rankS?: boolean }; onProgress?: SimProgress; holdHp?: (potionId: string, input: RolloutInput) => number | null },
): LinesResult {
  const orders = fightOrders(input);
  const pairs = lines.flatMap((plan, lineIndex) => [null, ...orders].map((order, orderIndex) => ({ plan, order, lineIndex, orderIndex })));
  const slim = linesInput(input, opts.holdHp);
  const now = opts.now ?? (() => performance.now());
  const per = orders.length + 1;
  let actualAdaptive: ReturnType<AdaptiveSampler["result"]> | null = null;
  let ownSamples: number[] | null = null;
  let run: PairsRun;
  if (opts.adaptive?.mode === "on") {
    if (Number.isFinite(opts.deadlineMs)) throw new Error("adaptive B2 requires the complete-computation path");
    const began = now();
    const sampler = new AdaptiveSampler(lines.map((_, i) => ({ key: `line:${i}` })),
      { lane: "b2", requested: opts.samples, allowS: opts.adaptive.allowS });
    const outcomes: PairsRun["outcomes"] = pairs.map(() => new Array<FightSampleResult | undefined>(opts.samples));
    let done = 0, workers = 0;
    for (let request = sampler.next(); request; request = sampler.next()) {
      const indices = request.active.map((key) => Number(key.slice("line:".length)));
      const activePairs = indices.flatMap((i) => Array.from({ length: per }, (_, order) => i * per + order));
      const work: PairWork = { range: { from: request.from, to: request.to }, activePairs };
      const progress: SimProgress = (completed) => opts.onProgress?.(done + completed, opts.samples * pairs.length);
      const round = opts.serial ? runPairsSerial(slim, pairs, opts.samples, opts.seed, Infinity, now, progress, work)
        : bossLinesPool().run(slim, pairs, opts.samples, opts.seed, Infinity, now, progress, work);
      if (round.timedOut || round.complete.length !== request.to - request.from
          || round.complete.some((sample, i) => sample !== request!.from + i)) throw new Error("adaptive B2 round incomplete");
      for (const pair of activePairs) for (const sample of round.complete) outcomes[pair]![sample] = round.outcomes[pair]![sample]!;
      done += round.done;
      workers = Math.max(workers, round.workers);
      sampler.observe(indices.map((i) => ({ key: `line:${i}`,
        samples: outcomes[i * per]!.slice(0, request!.to) as FightSampleResult[],
        orders: Array.from({ length: per }, (_, k) => outcomes[i * per + k]!.slice(0, request!.to) as FightSampleResult[]) })));
    }
    actualAdaptive = sampler.result();
    ownSamples = actualAdaptive.candidates.map((candidate) => candidate.samples);
    const common = Math.min(...ownSamples);
    run = { outcomes, complete: Array.from({ length: common }, (_, i) => i), timedOut: false,
      elapsedMs: Math.round(now() - began), workers, done };
    actualAdaptive.work.full *= per;
    actualAdaptive.work.actual *= per;
    actualAdaptive.work.unit = "fight-sample-outcomes";
  } else run = opts.serial ? runPairsSerial(slim, pairs, opts.samples, opts.seed, opts.deadlineMs, now, opts.onProgress)
    : bossLinesPool().run(slim, pairs, opts.samples, opts.seed, opts.deadlineMs, now, opts.onProgress);
  const out = lines.map((_, li) => {
    const ids = ownSamples ? Array.from({ length: ownSamples[li]! }, (_, i) => i) : run.complete;
    let pick: (BossSimLineResult & { order: string | null }) | null = null;
    for (let k = 0; k < per; k += 1) {
      const pair = li * per + k;
      const res = { ...summarizeLine(li, ids.map((i) => run.outcomes[pair]![i]!), ownSamples?.[li] ?? opts.samples), order: k === 0 ? null : orders[k - 1]!.label };
      if (!pick || res.winProb > pick.winProb || (res.winProb === pick.winProb && wonLoss(res) < wonLoss(pick))) pick = res;
    }
    return pick!;
  });
  const adaptive = !actualAdaptive && opts.adaptive && !run.timedOut && run.complete.length === opts.samples ? safeAdaptiveShadow(
    out.map((line, i) => ({ key: `line:${i}`, samples: line.outcomes,
      orders: Array.from({ length: per }, (_, k) => run.complete.map((id) => run.outcomes[i * per + k]![id]!)) })),
    { lane: "b2", requested: opts.samples, allowS: opts.adaptive.allowS }) : null;
  if (adaptive && "work" in adaptive) {
    adaptive.work.full *= per;
    adaptive.work.shadow *= per;
    adaptive.work.unit = "fight-sample-outcomes";
  }
  let productionComparison: JsonValue | undefined;
  if (adaptive && "candidates" in adaptive) {
    try {
      const prefix = adaptive.candidates.map((candidate, li) => {
        let pick: BossSimLineResult | null = null;
        for (let order = 0; order < per; order++) {
          const line = summarizeLine(li, run.outcomes[li * per + order]!.slice(0, candidate.samples) as FightSampleResult[]);
          if (!pick || line.winProb > pick.winProb || (line.winProb === pick.winProb && wonLoss(line) < wonLoss(pick))) pick = line;
        }
        return pick!;
      });
      const policy = opts.adaptive?.rankS ? { lowTrust: opts.adaptive.allowS ? null : "original_trust_gate", allowPrefixes: true } : undefined;
      const group = (rows: BossSimLineResult[]) => {
        const ranked = rankLines(rows, BOSS_LINES_TIE_SE, () => true, wonLoss, policy);
        return (ranked.tied.length ? ranked.tied : [ranked.best]).map((i) => `line:${i}`).sort();
      };
      const full = group(out), partial = group(prefix);
      productionComparison = { metric: "deployed-ranking-first-group", full, partial, agreement: JSON.stringify(full) === JSON.stringify(partial) };
    } catch (error) {
      productionComparison = { metric: "deployed-ranking-first-group", agreement: null, error: String(error).slice(0, 180) };
    }
  }
  return { ...(actualAdaptive || adaptive ? { adaptive: toJsonValue({ ...(actualAdaptive ?? adaptive), ...(productionComparison ? { production_comparison: productionComparison } : {}), input_key: linesMemoKey(input, lines, opts.samples, "adaptive-record", opts.adaptive) }) } : {}), lines: out, samples: run.complete.length, requested: opts.samples, timedOut: run.timedOut, elapsedMs: run.elapsedMs, workers: run.workers, orders: orders.length, pairs: pairs.length, done: run.done,
    ...(input.continuation ? { continuation: { source: input.continuation.source, limitation: input.continuation.limitation } } : {}) };
}

export interface LinesRank {
  order?: number[];
  sRanking?: CombatSRanking;
  /** Index of the best line: the top win rate's tie group (within tieSe paired standard errors), then the least HP lost when won. */
  best: number;
  /** Lines whose numbers are the best's (win % and median HP lost when won, to one decimal): two or more, no single best. */
  tied: number[];
  /** Each line against the best (paired), null for the best itself. */
  vsBest: (LineComparison | null)[];
  /** Each line's win rate tied with the top one (within tieSe standard errors). */
  winTied: boolean[];
}

/**
 * B2's ranking (Roy): the whole-fight win rate first, ties within `tieSe` standard errors, then the least `second`
 * (wonLoss, the HP lost when won; the acceptance tool also ranks by the pre-V4.2 mean HP lost to compare).
 */
export function rankLines(lines: BossSimLineResult[], tieSe = BOSS_LINES_TIE_SE, eligible: (i: number) => boolean = () => true, second: (line: BossSimLineResult) => number = wonLoss, sPolicy?: { lowTrust: string | null; allowPrefixes?: boolean; mode?: "shadow" }): LinesRank {
  if (sPolicy) {
    const previous = rankLines(lines, tieSe, eligible, second);
    const diagnostic = rankByBossMargin(lines, previous, tieSe, sPolicy.lowTrust, second, sPolicy.allowPrefixes);
    if (sPolicy.mode === "shadow" && diagnostic.sRanking) return { ...previous,
      sRanking: { ...diagnostic.sRanking, mode: "shadow", shadow_best: diagnostic.best,
        shadow_used: diagnostic.sRanking.used, best: previous.best, used: false } };
    return diagnostic;
  }
  const idx = lines.map((_, i) => i).filter(eligible);
  if (idx.length === 0) return { best: -1, tied: [], vsBest: lines.map(() => null), winTied: lines.map(() => false) };
  let top = idx[0]!;
  for (const i of idx) {
    const a = lines[i]!;
    const b = lines[top]!;
    if (a.winProb > b.winProb || (a.winProb === b.winProb && second(a) < second(b))) top = i;
  }
  const winTied = lines.map((line, i) => {
    if (!idx.includes(i)) return false;
    if (i === top) return true;
    const c = compareLines(line, lines[top]!);
    return c.winDiff >= -tieSe * c.winSe && !(c.winSe === 0 && c.winDiff < 0);
  });
  let best = top;
  for (const i of idx) {
    if (!winTied[i]) continue;
    const a = lines[i]!;
    const b = lines[best]!;
    if (second(a) < second(b) || (second(a) === second(b) && a.winProb > b.winProb)) best = i;
  }
  const shown = (line: BossSimLineResult) => `${Math.round(line.winProb * 1000)}|${Math.round(second(line) * 10)}`;
  const tied = idx.filter((i) => winTied[i] && shown(lines[i]!) === shown(lines[best]!));
  return { best, tied: tied.length >= 2 ? tied : [], vsBest: lines.map((line, i) => (i === best ? null : compareLines(line, lines[best]!))), winTied };
}

// ---------------------------------------------------------------- texts

const pct = (x: number) => Math.round(x * 100);
const pts = (x: number) => `${x > 0 ? "+" : x < 0 ? "−" : "±"}${Math.abs(Math.round(x * 100))}`;

/** The most common value of a count table (the earliest on ties). */
function modeOf(counts: Record<number, number>): number | null {
  let best: number | null = null;
  for (const [key, n] of Object.entries(counts)) if (best === null || n > (counts[best] ?? 0) || (n === counts[best] && Number(key) < best)) best = Number(key);
  return best;
}

/** One line's whole-fight fact, e.g. "win 62% (vs the best line −3 ± 2 pts), HP lost when won median 18, ~6 turns to win; ...; 600 samples". */
export function lineSimText(line: BossSimLineResult, calibrated: number, vs: LineComparison | null, run: Pick<LinesResult, "samples" | "requested" | "timedOut" | "adaptive">, turnNow: number, flags: { best: boolean; winTied: boolean; lowTrust: string | null }): string {
  if (line.sequence) return `低可信连战模拟：F48→F49连续通关 ${pct(line.winProb)}%（原始、未校准）；胜F48 ${line.sequence.firstWins}/${line.samples}，其中死F49 ${line.sequence.firstWinSecondDeaths}、未完成F49 ${line.sequence.secondUnfinished}；每条样本传递实际剩余HP/药水，${line.samples}样本；不是必死或SL判据。`;
  const vsText = vs === null ? (flags.lowTrust ? "the simulation's best line" : "the best line") : `vs the ${flags.lowTrust ? "simulation's " : ""}best line ${pts(vs.winDiff)} ± ${Math.max(1, Math.round(vs.winSe * 100))} pts${flags.winTied ? ", tied on win rate" : ""}`;
  const won = line.hpLossWon ? `HP lost when won median ${Math.round(line.hpLossWon.median)}` : "no winning sample";
  const turns = line.turnsWon ? `, ~${Math.round(line.turnsWon.median)} turn${Math.round(line.turnsWon.median) === 1 ? "" : "s"} to win (this one included)` : "";
  const death = modeOf(line.deathTurns);
  const dies = line.deaths > 0 && death !== null ? `; the losing samples die most often on T${turnNow + death - 1} (dead in ${pct(line.deaths / Math.max(1, line.samples))}%)` : "";
  const capped = line.capped > 0 ? `; ${line.capped} unfinished after ${BOSS_SIM_MAX_TURNS} turns` : "";
  const sampling = asArray(asRecord(run.adaptive)["candidates"]).map(asRecord).find((c) => c["key"] === `line:${line.line}`);
  const n = asRecord(run.adaptive)["mode"] === "on" ? `${line.samples} samples (adaptive ${String(sampling?.["stop"] ?? "unknown")})`
    : run.timedOut ? `${run.samples} of ${run.requested} samples (time limit)` : `${run.samples} samples`;
  const order = "order" in line && typeof (line as { order?: unknown }).order === "string" ? `; later turns kill ${(line as unknown as { order: string }).order}` : "";
  return `${flags.lowTrust ? "low confidence: " : ""}win ${pct(calibrated)}% (${vsText}), ${won}${turns}${dies}${capped}${order}; ${n}`;
}

/** Names for card ids in a plan (the input's own cards; a potion by its id). */
function namesOf(input: RolloutInput): { card: (id: string) => string } {
  const cards = new Map<string, string>();
  for (const card of [...input.solver.hand, ...input.piles.draw, ...input.piles.discard]) if (!cards.has(card.cardId)) cards.set(card.cardId, card.name);
  const potion = (id: string) => input.solver.hand.find((card) => card.cardId.startsWith(`${id}:`))?.name.replace(/^potion /, "") ?? id.split(":")[1]!.toLowerCase().replace(/_/g, " ");
  return { card: (id) => cards.get(id) ?? (id.startsWith("POTION:") ? potion(id) : id) };
}

/**
 * The fight plan from the best line's winning samples (all samples when fewer than 10 won): what at least
 * BOSS_LINES_PLAN_SHARE of them do, in fight turns. Powers played by then (the median turn), the turns the enemies hit
 * hardest and their incoming damage (V4.2: not the block the samples put up, which Jev read as advice), the enemies'
 * kill turns (several enemies), the potions drunk (median turn), and the turn the fight ends. One sentence; information
 * only.
 */
export function fightPlanText(input: RolloutInput, line: BossSimLineResult, turnNow: number): string | null {
  if (line.sequence) return null;
  const won = line.outcomes.filter((o) => o.won);
  const base = won.length >= 10 ? won : line.outcomes;
  if (base.length === 0) return null;
  const share = (n: number) => n / base.length >= BOSS_LINES_PLAN_SHARE;
  const names = namesOf(input);
  const T = (rel: number) => `T${turnNow + rel - 1}`;
  const median = (xs: number[]) => Math.round(quantile(xs.slice().sort((a, b) => a - b), 0.5));
  const parts: string[] = [];
  // Powers: played in most samples, at their median turn.
  const powerTurns = new Map<string, number[]>();
  for (const o of base) {
    const firsts = new Map<string, number>();
    for (const [t, id] of o.powers ?? []) if (!firsts.has(id)) firsts.set(id, t);
    for (const [id, t] of firsts) powerTurns.set(id, [...(powerTurns.get(id) ?? []), t]);
  }
  const powers = [...powerTurns.entries()].filter(([, ts]) => share(ts.length)).map(([id, ts]) => ({ id, t: median(ts) })).sort((a, b) => a.t - b.t);
  if (powers.length > 0) {
    const last = powers[powers.length - 1]!.t;
    parts.push(`${powers[0]!.t === last ? T(last) : `${T(powers[0]!.t)}–${T(last)}`} play ${powers.map((p) => names.card(p.id)).join(", ")}`);
  }
  // The hardest hits: a turn whose mean attack (samples still fighting it) is at least 1.5x the fight's median turn
  // and a quarter of our HP now; only the incoming damage (the simulated play blocks less than ours on them, §6.2).
  const byTurn = new Map<number, number[]>();
  for (const o of base) o.incomingByTurn.forEach((inc, k) => byTurn.set(k + 1, [...(byTurn.get(k + 1) ?? []), inc]));
  const turns = [...byTurn.entries()].filter(([, inc]) => share(inc.length)).map(([t, inc]) => ({ t, inc: inc.reduce((s, x) => s + x, 0) / inc.length }));
  const typical = quantile(turns.map((x) => x.inc).sort((a, b) => a - b), 0.5);
  const hp = input.solver.player.hp;
  const big = turns.filter((x) => x.t > 1 && x.inc >= Math.max(1.5 * typical, 0.25 * hp) && x.inc >= 10).slice(0, 3);
  if (big.length > 0) parts.push(`${big.map((x) => T(x.t)).join(", ")} the enemies hit hardest (incoming ~${big.map((x) => Math.round(x.inc)).join(", ~")})`);
  // Kill turns, when there are several enemies (by board index: The Kin's two Followers apart).
  if (input.solver.enemies.filter((e) => e.hp > 0).length >= 2) {
    const killT = new Map<number, number[]>();
    for (const o of base) for (const [t, , index] of o.kills ?? []) killT.set(index, [...(killT.get(index) ?? []), t]);
    const kills = [...killT.entries()].filter(([, ts]) => share(ts.length)).map(([index, ts]) => ({ index, t: median(ts) })).sort((a, b) => a.t - b.t);
    const nameOf = (index: number) => input.solver.enemies.find((e) => e.index === index)?.name ?? `enemy ${index}`;
    if (kills.length > 0) parts.push(`kill ${kills.map((k) => `${nameOf(k.index)} ~${T(k.t)}`).join(", then ")}`);
  }
  // Potions drunk by most samples.
  const drinkT = new Map<string, number[]>();
  for (const o of base) {
    const firsts = new Map<string, number>();
    for (const [t, id] of o.drinks ?? []) if (!firsts.has(id)) firsts.set(id, t);
    for (const [id, t] of firsts) drinkT.set(id, [...(drinkT.get(id) ?? []), t]);
  }
  const drinks = [...drinkT.entries()].filter(([, ts]) => share(ts.length)).map(([id, ts]) => ({ id, t: median(ts), n: ts.length }));
  if (drinks.length > 0) parts.push(`drink ${drinks.map((d) => `${names.card(`POTION:${d.id}`)} ~${T(d.t)}`).join(", ")}`);
  const end = median(base.map((o) => o.turns));
  parts.push(won.length >= 10 ? `the boss dies ~${T(end)} (median of ${won.length} winning samples)` : `no plan wins in most samples: ${won.length}/${line.outcomes.length} won, the fight ends ~${T(end)}`);
  return parts.join("; ");
}

// ---------------------------------------------------------------- the live question

export interface LineSim {
  bossMargin?: ReturnType<typeof summarizeBossMargin>;
  result: BossSimLineResult & { order: string | null };
  calibrated: number;
  vsBest: LineComparison | null;
  winTied: boolean;
  text: string;
}

export type BossLineSim = { completion?: SimCompletion; resourceFailure?: Record<string, JsonValue>; f48JointShadow?: Record<string, unknown> } & (
  | { available: false; reason: string; ms: number }
  | {
      available: true;
      byPlan: Map<Plan, LineSim>;
      /** The ranking's best line and the lines tied for it (null / empty for a low-trust boss: information only). */
      best: Plan | null;
      tied: Plan[];
      /** Code's fallback: the best line drinking no potion, by the same ranking (null: none, or low trust). */
      bestDry: Plan | null;
      boss: string | null;
      lowTrust: string | null;
      run: LinesResult;
      plan: string | null;
      /** The lines in the ranking's order (the tied-on-win-rate group by HP lost, then the rest by win rate), for the log. */
      order: Plan[];
      sRanking?: CombatSRanking;
    });

export interface BossLineSimArgs extends BossSimInputArgs {
  /** Full failure envelopes are separate from model facts and the bounded unavailable reason. */
  failureDirectory?: string;
  /** Live Silent controller policy; historical replays retain their frozen budgets unless explicitly opted in. */
  requiredComplete?: boolean;
  simWait?: SimWait;
  /** Every line shown (plan lines, then the random potions' median lines). */
  lines: Plan[];
  /** Lines the ranking may pick (a line code added is shown; a random potion's line is Jev's to drink). */
  eligible?: (plan: Plan) => boolean;
  turn: number | null;
  drinks: (plan: Plan) => boolean;
  /** SL_RETRY_COMPUTE (docs/sl.md §10): the samples per line on a retried fight's question (default bossLinesOptions.samples). */
  samples?: number;
  /**
   * The SL retry compute memo (src/sim/compute-memo.ts; the planner passes the fight's on a retried fight): a run of the
   * same input and samples that finished every sample is handed back when this question's deadline is at least its time.
   */
  memo?: ComputeMemo | null;
}

/**
 * Questions in a row whose run gave no sample (a worker pool that died: its workers never answer, so every question
 * would wait out its deadline): at this many the simulation is off for the rest of the fight.
 */
export const BOSS_LINES_MAX_FAILURES = 2;
let failed: { fight: string; count: number } = { fight: "", count: 0 };

/** The whole-fight numbers of a boss question's lines (never throws: unavailable with a reason). */
export function bossLineSim(args: BossLineSimArgs): BossLineSim {
  const now = bossLinesOptions.now ?? (() => performance.now());
  const started = now();
  const ms = () => Math.round(now() - started);
  const required = args.requiredComplete === true && quantitativeEnabled(args.state);
  let attempt: SimAttempt | undefined;
  let wait: ReturnType<SimWait["start"]> | undefined;
  let sampled = 0;
  const samples = args.samples ?? bossLinesOptions.samples;
  const jointScope = f48JointScope(args.state);
  const unavailable = (reason: string): BossLineSim => ({ available: false, reason, ms: ms(),
    ...(jointScope ? { f48JointShadow: f48JointShadow(jointScope, [], undefined, { reason }) } : {}),
    ...(attempt ? { completion: attempt.finish(sampled, samples, reason) } : {}) });
  try {
    if (args.lines.length === 0) return unavailable("no line");
    // The turn's budget over its questions (a re-plan after a draw asks again).
    const fight = `${String(args.state.raw["run_id"] ?? "")}:${args.state.run?.floor ?? "?"}`;
    if (!required && failed.fight === fight && failed.count >= BOSS_LINES_MAX_FAILURES) return unavailable(`off for this fight: ${failed.count} questions in a row got no sample from the worker pool`);
    const turnKey = `${fight}:${args.turn ?? "?"}`;
    const memo = args.memory.bossLines?.turn === turnKey ? args.memory.bossLines : { turn: turnKey, spentMs: 0 };
    let left = required ? Infinity : Math.min(bossLinesOptions.deadlineMs, bossLinesOptions.turnBudgetMs - memo.spentMs);
    if (left < bossLinesOptions.minMs) return unavailable(`this turn's ${Math.round(bossLinesOptions.turnBudgetMs / 1000)} s for the simulation is spent`);
    const input = bossSimInput(args);
    const boss = bossKeyOf(input.enemies.map((e) => e.id));
    const lowTrust = input.continuation?.limitation ?? (boss ? bossTrustReason(boss, "b2", args.state.run?.ascension, args.state.run?.floor) : null);
    const adaptiveMode = simAdaptivePolicy(String(args.state.run?.raw["character_id"] ?? "")).mode;
    const configuredAdaptive = required && adaptiveMode !== "off" ? { mode: adaptiveMode, allowS: !lowTrust, rankS: sCombatRankEnabled(String(args.state.run?.raw["character_id"] ?? "")) } : undefined;
    if (required) {
      attempt = beginComputation(args.memory, args.state, "boss-lines", linesMemoKey(input, args.lines, samples, linesWhere() ?? "unknown", configuredAdaptive));
      if (attempt.degraded) left = bossLinesOptions.deadlineMs;
      wait = args.simWait?.start({ run: String(args.state.raw["run_id"] ?? ""), floor: args.state.run?.floor ?? null, label: "boss-lines" });
    }
    const adaptive = attempt?.degraded ? undefined : configuredAdaptive;
    const memoed = args.memo ? recallLines(args.memo, input, args.lines, samples, left, adaptive) : null;
    let run: LinesResult;
    if (memoed) run = { ...memoed, memo: { wallMs: ms() } };
    else {
      try {
        run = runLines(input, args.lines, { samples, seed: bossLinesOptions.seed, deadlineMs: left, serial: bossLinesOptions.serial, now, ...(wait ? { onProgress: wait.progress } : {}), ...(adaptive ? { adaptive } : {}) });
      } catch (error) {
        // A worker's error: the next question starts a new pool.
        releaseBossLinesPool();
        failed = { fight, count: failed.fight === fight ? failed.count + 1 : 1 };
        throw error;
      }
      if (args.memo) storeLines(args.memo, input, args.lines, samples, run, adaptive);
    }
    args.memory.bossLines = { turn: turnKey, spentMs: memo.spentMs + run.elapsedMs };
    sampled = run.samples;
    const adaptiveComplete = completeAdaptiveLines(run);
    if (required && !attempt?.degraded && (run.timedOut || (run.samples !== samples && !adaptiveComplete))) return unavailable(`required paired computation incomplete: ${run.samples}/${samples}`);
    if (run.samples === 0) {
      releaseBossLinesPool();
      failed = { fight, count: failed.fight === fight ? failed.count + 1 : 1 };
      return unavailable(`no sample finished within ${Math.round(left / 1000)} s`);
    }
    if (attempt?.degraded && run.samples < 300) return unavailable(`不完整（故障降级，n=${run.samples}）；不足 300 次，不给数字，按原 rollout 继续`);
    failed = { fight, count: 0 };
    const eligible = (i: number) => (args.eligible ? args.eligible(args.lines[i]!) : true);
    const sPolicy = sCombatRankMode(String(args.state.run?.raw["character_id"] ?? "")) === "shadow"
      ? { lowTrust, allowPrefixes: adaptiveComplete, mode: "shadow" as const } : undefined;
    const rank = rankLines(run.lines, BOSS_LINES_TIE_SE, eligible, wonLoss, sPolicy);
    const dryRank = rankLines(run.lines, BOSS_LINES_TIE_SE, (i) => eligible(i) && !args.drinks(args.lines[i]!), wonLoss, sPolicy);
    const turnNow = args.turn ?? 1;
    const start = turnNow <= 1 ? "start" : "mid";
    const byPlan = new Map<Plan, LineSim>();
    run.lines.forEach((line, i) => {
      const calibrated = line.sequence ? line.winProb : calibratedWinProb(line.winProb, line.samples, start, args.state.run?.ascension ?? 0);
      const vsBest = rank.vsBest[i] ?? null;
      const winTied = rank.winTied[i] ?? false;
      const reference = run.lines[rank.best >= 0 ? rank.best : 0]!;
      const margin = input.captureBossMargin ? summarizeBossMargin(line.outcomes, reference.outcomes, line.outcomes.map((_, at) => at), ...(adaptiveComplete ? [reference.outcomes.map((_, at) => at)] : [])) : null;
      byPlan.set(args.lines[i]!, { result: line, calibrated, vsBest, winTied,
        ...(margin ? { bossMargin: { ...margin, rankingEligible: margin.rankingEligible && !lowTrust && (!sPolicy || auditSigns(line.outcomes).rankingEligible) } } : {}),
        text: (attempt?.degraded ? `不完整（故障降级，n=${run.samples}）；` : "") + lineSimText(line, calibrated, rank.best === i ? null : vsBest, run, turnNow, { best: rank.best === i, winTied, lowTrust }) });
    });
    // P3 supplies its complete anchored order; the legacy path keeps its exact original comparator.
    const key = (i: number): [number, number, number] => (rank.winTied[i] ? [0, wonLoss(run.lines[i]!), -run.lines[i]!.winProb] : [1, -run.lines[i]!.winProb, wonLoss(run.lines[i]!)]);
    const cmp = (x: number, y: number) => (x === y ? 0 : x < y ? -1 : 1);
    const order = (rank.order ?? run.lines.map((_, i) => i).sort((a, b) => cmp(key(a)[0], key(b)[0]) || cmp(key(a)[1], key(b)[1]) || cmp(key(a)[2], key(b)[2]) || a - b)).map((i) => args.lines[i]!);
    const showPlan = args.turn === null || args.turn <= 1 || (args.turn - 1) % BOSS_LINES_PLAN_EVERY === 0;
    const plan = showPlan && rank.best >= 0 ? fightPlanText(input, run.lines[rank.best]!, turnNow) : null;
    const sim: BossLineSim = {
      ...(jointScope ? { f48JointShadow: f48JointShadow(jointScope, run.lines.map((line, i) => ({
        key: `line:${i}`, input: args.lines[i], outcomes: line.outcomes, requested: samples, order: line.order,
      })), input) } : {}),
      ...(attempt ? { completion: attempt.finish(run.samples, samples, undefined, adaptiveComplete) } : {}),
      available: true,
      byPlan,
      best: lowTrust || rank.best < 0 || rank.tied.length > 0 ? null : args.lines[rank.best]!,
      tied: lowTrust ? [] : rank.tied.map((i) => args.lines[i]!),
      bestDry: lowTrust || dryRank.best < 0 ? null : args.lines[dryRank.best]!,
      boss,
      lowTrust,
      run,
      plan,
      order,
      ...(rank.sRanking ? { sRanking: rank.sRanking } : {}),
    };
    bossLinesOptions.onSim?.(sim);
    return sim;
  } catch (error) {
    const sim = unavailable(`error: ${String(error).slice(0, 160)}`);
    const failure = continuationFailureOf(error);
    if (failure && String(args.state.run?.raw["character_id"] ?? "").toLowerCase() === "silent") {
      sim.resourceFailure = preserveContinuationFailure(failure, {
        run: String(args.state.raw["run_id"] ?? ""), character: "silent", floor: args.state.run?.floor ?? null,
        turn: args.turn, label: "combat/plan", lane: "boss-lines",
        question_key: sim.completion?.key ?? memoKey("continuation-b2-question", { state: args.state.raw, lines: args.lines, turn: args.turn }),
        state: toJsonValue(args.state.raw),
        question: toJsonValue({ solver: args.solver, piles: args.piles, randomPotions: args.randomPotions, lines: args.lines, samples, turn: args.turn }),
        completion: toJsonValue(sim.completion),
      }, args.failureDirectory);
      if (jointScope) sim.f48JointShadow = f48JointShadow(jointScope, [], undefined,
        { reason: `resource_contract_failure:${failure.reason}`, reference: sim.resourceFailure });
    }
    return sim;
  } finally {
    wait?.finish();
  }
}

// ---------------------------------------------------------------- the SL retry compute memo (src/sim/compute-memo.ts)

/**
 * Where a run's samples run: this thread (its data loaded once, at the process's start), or the fight's pool by the data
 * its workers loaded (no pool running: the data a pool started now would load). A pool released after a question with
 * no sample and built again on the same data finds the runs before it; null: the data files cannot be read (no memo).
 */
function linesWhere(): string | null {
  if (bossLinesOptions.serial) return "main";
  const data = bossLinesPoolData() ?? workerDataSignature();
  return data ? `pool:${data}` : null;
}

/** The memo key of a B2 run: everything runLines reads (the input, the lines, samples, seed, hold values, turns) and where it ran. */
function linesMemoKey(input: RolloutInput, lines: Plan[], samples: number, where: string, adaptive?: { allowS: boolean; mode?: "shadow" | "on"; rankS?: boolean }): string | null {
  return memoKey("b2", { input, lines, samples, seed: bossLinesOptions.seed, holdHp: identityToken(bossLinesOptions.holdHp ?? tableHoldHp), maxTurns: BOSS_SIM_MAX_TURNS, where, ...(adaptive ? { adaptive: { ...ADAPTIVE_RULE, ...adaptive } } : {}) });
}

/** A stored run of this input that finished every sample, when `left` (this question's deadline) is at least its time; else null. */
function recallLines(memo: ComputeMemo, input: RolloutInput, lines: Plan[], samples: number, left: number, adaptive?: { allowS: boolean; mode?: "shadow" | "on"; rankS?: boolean }): LinesResult | null {
  try {
    const where = linesWhere();
    const key = where ? linesMemoKey(input, lines, samples, where, adaptive) : null;
    const hit = key ? memo.get<LinesResult, { elapsedMs: number }>(key) : null;
    if (!hit || hit.value.timedOut || hit.meta.elapsedMs > left
        || (hit.value.samples !== samples && !completeAdaptiveLines(hit.value))) return null;
    memo.took();
    return hit.value;
  } catch {
    return null;
  }
}

/** Keeps a run that finished every sample (none cut by the deadline). */
function storeLines(memo: ComputeMemo, input: RolloutInput, lines: Plan[], samples: number, run: LinesResult, adaptive?: { allowS: boolean; mode?: "shadow" | "on"; rankS?: boolean }): void {
  try {
    if (run.timedOut || (run.samples < samples && !completeAdaptiveLines(run)) || run.samples === 0) return;
    const where = linesWhere();
    const key = where ? linesMemoKey(input, lines, samples, where, adaptive) : null;
    if (key) memo.set(key, run, { elapsedMs: run.elapsedMs });
  } catch {
    // not kept
  }
}

/** `plan` against `than` on the simulation's samples (paired; null: no numbers for one of them). SL_RETRY_EXPLORE_B2's row. */
export function simCompare(sim: BossLineSim | null, plan: Plan, than: Plan): LineComparison | null {
  const a = sim?.available ? sim.byPlan.get(plan) : undefined;
  const b = sim?.available ? sim.byPlan.get(than) : undefined;
  return a && b ? compareLines(a.result, b.result) : null;
}

/** The HP guard's check (B2): `plan` wins less than `pick` in the simulation, beyond BOSS_LINES_TIE_SE standard errors. */
export function simWinsLess(sim: BossLineSim | null, plan: Plan, pick: Plan): boolean {
  const a = sim?.available ? sim.byPlan.get(plan) : undefined;
  const b = sim?.available ? sim.byPlan.get(pick) : undefined;
  if (!a || !b) return false;
  const c = compareLines(a.result, b.result);
  return c.winDiff < -BOSS_LINES_TIE_SE * c.winSe;
}

/** The question's note on the numbers (state.whole_fight_sim; a low-trust boss's question has none). */
export function simNote(sim: BossLineSim): string {
  if (!sim.available) return `whole-fight simulation unavailable (${sim.reason})`;
  if (sim.run.continuation) return `F48→F49连续通关模拟：每条第一战胜利样本以实际剩余HP、药水和复活资源进入第二战，第二boss按已观察分布抽样；${sim.run.samples}配对样本，未经两战校准。${sim.run.continuation.limitation}；不是必死或SL判据。证据：${sim.run.continuation.source}`;
  if (completeAdaptiveLines(sim.run)) return `Each option uses its own recorded sample count (adaptive-v1, cap ${sim.run.requested}); paired differences use only shared seed prefixes. Eliminated means sampling stopped, not an unavailable action. Whole-fight model estimates remain conditional and calibrated under the original trust gate.`;
  const how = `each option's whole_fight_sim: that line this turn, then the simulator's own play to the fight's end, ${sim.run.samples} samples per line on the same random numbers (${sim.run.timedOut ? `cut from ${sim.run.requested} by the time limit, ` : ""}${(sim.run.elapsedMs / 1000).toFixed(1)} s); the win rate is calibrated on logged boss fights, the difference to the best line is paired (± standard error)`;
  if (sim.sRanking?.used) return `${how}. rollout_best uses simulated win rate first (ties within ${BOSS_LINES_TIE_SE} paired standard errors), then S within that group (ties within ${BOSS_LINES_TIE_SE} paired standard errors), then median HP lost when won; attribution and sign checks passed for the whole win-rate tie group. S is conditional model margin, not real win probability; the 5-turn rollout's numbers stay for reference`;
  return `${how}. rollout_best is the line with the highest simulated win rate (lines within ${BOSS_LINES_TIE_SE} standard errors of it count as tied), then the least HP lost when won (median); the 5-turn rollout's numbers stay for reference`;
}

/** The decision log's record (log.boss_sim). */
export function simLog(sim: BossLineSim, keyOf: (plan: Plan) => string | null, extra: Record<string, JsonValue> = {}): Record<string, JsonValue> {
  const completion: Record<string, JsonValue> = { ...(sim.completion ? { completion: { ...sim.completion } } : {}),
    ...(sim.f48JointShadow ? { f48_joint_shadow: toJsonValue(sim.f48JointShadow) } : {}) };
  if (!sim.available) return { available: false, reason: sim.reason, ms: sim.ms, ...completion,
    ...(sim.resourceFailure ? { resource_failure: sim.resourceFailure } : {}), ...extra };
  const lines: Record<string, JsonValue> = {};
  for (const [plan, line] of sim.byPlan) {
    const key = keyOf(plan);
    if (!key) continue;
    lines[key] = {
      ...(line.bossMargin ? { boss_relative_margin: toJsonValue(line.bossMargin) } : {}),
      win: Math.round(line.result.winProb * 1000) / 1000,
      cal: Math.round(line.calibrated * 1000) / 1000,
      d: line.vsBest ? Math.round(line.vsBest.winDiff * 1000) / 1000 : 0,
      se: line.vsBest ? Math.round(line.vsBest.winSe * 1000) / 1000 : 0,
      ...(completeAdaptiveLines(sim.run) ? { samples: line.result.samples, paired_samples: line.vsBest?.samples ?? line.result.samples } : {}),
      loss: line.result.hpLoss.mean,
      won_loss: line.result.hpLossWon?.median ?? null,
      order: line.result.order,
      ...(line.result.sequence ? { sequence: { first_wins: line.result.sequence.firstWins, won_first_died_second: line.result.sequence.firstWinSecondDeaths, second_unfinished: line.result.sequence.secondUnfinished } } : {}),
      ...(line.result.continuous ? { continuous: toJsonValue(line.result.continuous) } : {}),
    };
  }
  return {
    available: true,
    ...completion,
    ...(sim.sRanking ? { s_ranking: toJsonValue({ ...sim.sRanking, candidate_keys:
      [...sim.byPlan.keys()].map((plan) => keyOf(plan)) }) } : {}),
    ...(sim.run.adaptive ? { adaptive: toJsonValue({ ...asRecord(sim.run.adaptive), candidate_keys:
      Object.fromEntries([...sim.byPlan.keys()].map((plan, i) => [`line:${i}`, keyOf(plan)])) }) } : {}),
    ...(sim.run.continuation ? { objective: "F48_F49_continuous", calibration: "none", continuation: { source: sim.run.continuation.source, limitation: sim.run.continuation.limitation } } : {}),
    // The question's own wall clock (an SL retry memo hit: the lookup's; the decision row's timing.memo has the stored run's).
    ms: sim.run.memo ? sim.run.memo.wallMs : sim.run.elapsedMs,
    samples: sim.run.samples,
    requested: sim.run.requested,
    timed_out: sim.run.timedOut,
    orders: sim.run.orders,
    workers: sim.run.workers,
    boss: sim.boss,
    low_trust: sim.lowTrust !== null,
    best: sim.best ? keyOf(sim.best) : null,
    tied: sim.tied.map((plan) => keyOf(plan) ?? "?"),
    ranked: sim.order.map((plan) => keyOf(plan) ?? "?"),
    lines,
    ...(sim.plan ? { plan: sim.plan } : {}),
    ...extra,
  };
}

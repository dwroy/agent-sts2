from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();pub=r/'paper/materials/20261015-1650-ops';req=json.loads((pub/'new-host-request.json').read_text());inode=str((r/'ops/live-merge.lock').stat().st_ino);rows=[x for x in Path('/proc/locks').read_text().splitlines() if x.split()[5].split(':')[-1]==inode];owners=[]
for row in rows:
 pid=int(row.split()[4]);p=Path('/proc')/str(pid);st=(p/'stat').read_text();fds=[]
 for f in (p/'fd').iterdir():
  try:
   if str(f.resolve())==str(r/req['expected_log']):fds.append(f.name)
  except FileNotFoundError:pass
 owners.append({'pid':pid,'birth':st[st.rfind(')')+2:].split()[19],'argv':[x.decode() for x in (p/'cmdline').read_bytes().split(b'\0') if x],'cwd':str((p/'cwd').resolve()),'expected_log_fds':fds})
assert any(x['expected_log_fds'] and any(a.endswith('/ops/codex-ops-learn.py') for a in x['argv']) and 'recheck' in x['argv'] for x in owners),owners
assert subprocess.check_output(['git','-C','.worktrees/live','rev-parse','HEAD','HEAD^{tree}'],text=True).splitlines()==[req['exact_live'],req['exact_tree']]
raw=(r/req['expected_log']).read_bytes();assert b' RUN ' in raw
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();d={'at':at,'request':req,'lock_rows':rows,'owners':owners,'actually_started':True,'exact_live_readback':req['exact_live'],'exact_tree_readback':req['exact_tree'],'log_prefix_bytes':len(raw),'log_prefix_sha256':hashlib.sha256(raw).hexdigest(),'full_result':'pending; RUN is not full success','R359_R360_old_tree_full_passed':'24de only; not borrowed for new R361 tree','one_final_combination_request':True,'old_failures_and_source_full':'preserved/not rerun','current_game':'not restarted or changed by ops; current natural identity belongs actual run-config'};(pub/'new-host-start-readback.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');a=json.loads((pub/'publication.json').read_text());a['new_host']='actually started exact new R361 tree; full result pending';a['new_host_start_receipt']='paper/materials/20261015-1650-ops/new-host-start-readback.json';(pub/'publication.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'host_started':True,'worker_pids':[x['pid'] for x in owners],'tree':req['exact_tree'],'full_result':'pending'}))

from pathlib import Path
import json,hashlib,subprocess,tarfile,os,importlib.util
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1650';pub=r/'paper/materials/20261015-1650-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
assert not (p/'record-manifest.json').exists();base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip();at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();d=json.loads((pub/'publication.json').read_text());appends=json.loads((p/'own-appends.json').read_text());line=f'\n- {at} [ops 实际验收回报] V5-R359/R360最终24de树完整宿主0：483文件4891过2跳/697.69s；仅该树绿，中间571及后继R361新6a55树不借用。原watcher wJ:pJT已实际运输rc0，未代填其读回或Roy ACK；下一自然on消费者/health/p50/p90/eval仍原owner。原154303四叶受阻修复已兜底{d["release_id"]}，新6a55宿主worker1917254实启结果pending；两个宽神化ID保持waiting，当前已有交叠策略owner，机械resolve暂保pending不热换输入。160652十项waiting及164301无新增源码/72旧修复祖先核，均无新版本/补测；原failed/rc0/mergednull与全部证据边界保持。回执paper/materials/20261015-1650-ops/。\n'
for path in ['ops/inbox-dev.md','notes/for-roy.md']:
 with (r/path).open('ab') as out:out.write(line.encode())
 appends.append({'path':path,'text':line,'at':at})
(p/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n')
values={}
for row in appends:
 path=row['path'];raw=row['text'].encode();assert (r/path).read_bytes().count(raw)==1;values.setdefault(path,git('show',base+':'+path));values[path]+=raw
old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());rows=(p/'owned-learner-ledger.jsonl').read_bytes().splitlines(keepends=True)+(p/'owned-ops-ledger.jsonl').read_bytes().splitlines(keepends=True);assert len(rows)==44;new=b''.join(x for x in rows if x.rstrip(b'\n') not in seen);spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);fold=lambda raw:mod.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);before=fold(old);after=fold(old+new);assert set(before)==set(after)
for ident in before:
 for field in ['claim','first_run','asc','prior','prior_note','prior_runs','status','version','shipped_at','effect']:assert before[ident].get(field)==after[ident].get(field),(ident,field)
 a=before[ident].get('evidence',[]);assert after[ident].get('evidence',[])[:len(a)]==a
values['paper/materials/learning/ledger.jsonl']=old+new
resume=r/'paper/materials/20261015-v5-s-completion/resume-1615'
for name in ['ops-host-completion.json','ops-publication-receipt.json']:values[str((resume/name).relative_to(r))]=(resume/name).read_bytes()
# Freeze the completed old host log, preserving exact bytes and all skips.
h=json.loads((pub/'v5s-host-full-completion.json').read_text());log=r/h['log']['path'];raw=log.read_bytes();assert sha(raw)==h['log']['sha256'];scan=p/'archive-scan';scan.mkdir(exist_ok=True);(scan/'host-full-original.log').write_bytes(raw)
import gzip
with gzip.open(pub/'v5s-host-full-original.log.gz','wb') as out:out.write(raw)
(pub/'v5s-host-log-manifest.json').write_text(json.dumps({'source':h['log'],'gzip':{'path':str((pub/'v5s-host-full-original.log.gz').relative_to(r)),'sha256':sha((pub/'v5s-host-full-original.log.gz').read_bytes())},'raw_readback_equal':gzip.decompress((pub/'v5s-host-full-original.log.gz').read_bytes())==raw},ensure_ascii=False,indent=2)+'\n')
with tarfile.open(pub/'original-batch-artifacts.tar.gz') as tar:
 for item in tar.getmembers():
  assert item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts;out=scan/item.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(tar.extractfile(item).read())
helpers=['readbacks.py','readbacks-first-ledger-input-guard.py','publish.py','request-host.py','register-and-notify.py','host-readback.py','prepare-records.py','seal-records.py'];helperrows=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for name in helpers:
  f=p/name;b=f.read_bytes();(hs/name).write_bytes(b);tar.add(f,arcname=name);helperrows.append({'path':str(f.relative_to(r)),'bytes':len(b),'sha256':sha(b)})
(pub/'ops-helper-manifest.json').write_text(json.dumps({'files':helperrows,'readback_helper_first_failure':'No-source ledger-updates.jsonl is raw CLI input without op/ts; initial helper wrongly required op=update and stopped before any mutation. Corrected only to select exact matching real CLI appended rows from root ledger. Original helper retained; original inputs/logs/tests unchanged.','source_full_not_repeated':True},ensure_ascii=False,indent=2)+'\n')
completion={'at':at,'old_R359_R360_exact_host_full':0,'old_tree':'24de68ae5d7c329dc445f48451fff885ce1c43c2','old_host_files':483,'old_host_passed':4891,'old_host_skipped':2,'actual_new_release':d['release_id'],'new_live':d['actual_live'],'new_tree':d['tree'],'source_actual_main_live_ancestor':True,'new_exact_host':'actually started/pending event','natural_consumers':'pending original watcher','no_source_strategy_waiting':10,'empty_fix':'72 old fix ancestors verified; tsc0/63 selected not full; canonicalfailed/rc0 preserved','owned_ledger_rows':44,'protected_ledger_fold_preserved':True,'no_postmortem_or_paper_refresh':True,'no_new_learning_or_current_game_account_model_prompt_change':True,'all_parallel_physical_records_preserved':True};(pub/'completion.json').write_text(json.dumps(completion,ensure_ascii=False,indent=2)+'\n')
for f in pub.iterdir():
 if f.is_file() and f.name not in ['new-host-request.log']:values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';manifest=[]
for path,b in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);manifest.append({'path':path,'bytes':len(b),'sha256':sha(b)})
(p/'record-manifest.json').write_text(json.dumps({'base':base,'paths':manifest,'owned_ledger_rows':44},ensure_ascii=False,indent=2)+'\n');check=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(check.stdout+check.stderr);assert check.returncode==0;print(json.dumps({'paths':len(manifest),'owned_ledger':44,'ledger_check':0,'base':base}))

from pathlib import Path
import json,subprocess,re,hashlib,tarfile
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-1650';pub=r/'paper/materials/20261015-1650-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def ref(f):f=Path(f);b=f.read_bytes();return {'path':str(f.relative_to(r)),'bytes':len(b),'sha256':sha(b)}
state=json.loads((r/'ops/codex-ops/learn.json').read_text());namespace={'root':r,'Path':Path,'json':json,'re':re,'sha':sha};exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text(),namespace);artifacts=[];summaries=[];owned=[]
for bid in ['20261015-154303-strategy-proposal','20261015-160652-strategy-proposal','20261015-164301-fix-batch']:
 b=state['batches'][bid];report=b['report'];out=(r/'ops/codex-ops/learner'/f'{bid}.out').read_text();scratch=Path(report['report']).parent;rt=namespace['runtime'](bid,report,out,worktree=b['worktree']);wt=Path(b['worktree']);assert not git('status','--porcelain','--untracked-files=no',cwd=wt).strip();assert report['merged'] is None
 summary={'batch':bid,'original_completion':{k:b.get(k) for k in ['state','rc','merged']},'original_report':report,'native':rt,'report_ref':ref(scratch/'report.md'),'worktree_clean':True,'new_learning_or_model':False};files=[r/'ops/codex-ops/learner'/f'{bid}.out',r/'ops/codex-ops/learner'/f'{bid}.err',scratch/'report.md']
 if report['task']=='strategy-proposal':
  assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results']);summary['ten_original_waiting_preserved']=True
  for name in ['result.json','proposal.md','source-checks.json','source-commit.json','final-verification.json','negative-control.json','merge-attempt.json','sandbox-source.log','deadly-poison-fixed.log','deadly-poison-withdrawn.log','deadly-poison-restored.log','final-integrity.json','evidence-verification.json','evidence-verification-run1.json','evidence-verification-run1.log','evidence-verification-run2.log','gitleaks.log','gitleaks-source.log','gitleaks-final.log','raw-readback-verification.json','deadly-poison-action-readback.json','run-identities.json','verified-runs.json','live-source-manifest.json','proposal-source-manifest.json','source-verification.json']:
   if (scratch/name).exists():files.append(scratch/name)
  for name in ['ledger-appended-rows.jsonl','ledger-source-rows.json']:
   f=scratch/name
   if f.exists() and name.endswith('jsonl'):
    rows=f.read_bytes().splitlines(keepends=True);owned+=rows;summary['owned_ledger_rows']=len(rows)
  if bid=='20261015-154303-strategy-proposal':
   checks=json.loads((scratch/'source-checks.json').read_text());assert checks['exit_code']==checks['tsc']==checks['vitest']==0 and checks['sandbox_passed']==4081 and checks['paths_passed']==11;neg=json.loads((scratch/'negative-control.json').read_text());assert neg['withdrawn_exit']==1 and neg['restored_exit']==0 and neg['production_bytes_restored'];summary.update(source='ba23ca693151fa8c6f7fe035e640dc30f05ccd75',source_checks=checks,negative_control=neg,original_conflicts=json.loads((scratch/'merge-attempt.json').read_text()))
   fixture=json.loads(git('show',summary['source']+':agent/tests/silent-apotheosis-deadly-poison-evidence.json'));rawrefs=[]
   with (r/'logs/states.jsonl').open('rb') as handle:
    for x in fixture['source']:
     handle.seek(x['offset']);raw=handle.read(x['bytes']);assert sha(raw)==x['sha256'];v=json.loads(raw);rawrefs.append(x)
   summary['six_fixed_original_state_byte_refs_verified']=rawrefs
  else:
   assert not report['fixes'] and all(v is None for v in report['tests'].values());assert git('rev-parse','HEAD',cwd=wt).decode().strip()==report['base'];summary.update(source_changes=False,reported_raw_rows=8444,reported_material_checks=45,verification_boundary='read original learner artifacts and native isolation; no redundant material or source tests rerun')
   inputs=[json.loads(x) for x in (scratch/'ledger-updates.jsonl').read_bytes().splitlines()];actual=[]
   for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    v=json.loads(raw)
    if v.get('op')=='update' and any(all(v.get(k)==x.get(k) for k in x) for x in inputs):actual.append(raw)
   assert len(actual)==len(inputs);owned+=actual;summary['owned_ledger_rows']=len(actual)
 else:
  assert not report['fixes'] and report['tests']['cases']==63;a=json.loads((scratch/'audit.json').read_text());assert len(a['existing_fixes'])==72 and not a['new_fixes'];assert not (scratch/'source.diff').read_bytes()
  for x in a['existing_fixes']:
   git('merge-base','--is-ancestor',x['source_commit'],report['base']);git('merge-base','--is-ancestor',x['source_commit'],'live')
  summary.update(existing_fix_ancestors_verified=72,source_changes=False,tests_boundary='learner tsc0 and 10-file63 selected pass; 33 name-filtered not executed, not full; no redundant checks',state_failed_rc0_preserved=True)
  files += [scratch/n for n in ['audit.json','report.json','source.diff','tsc.log','tsc.exit','vitest-core.log','vitest-core.exit','vitest-fixtures.log','vitest-fixtures.exit']]
 for f in files:
  artifacts.append(ref(f))
 summaries.append(summary)
 (pub/(bid+'-readback.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
# Freeze only exact original artifacts; no transient test folders or credentials.
with tarfile.open(pub/'original-batch-artifacts.tar.gz','w:gz') as tar:
 for row in artifacts:tar.add(r/row['path'],arcname=row['path'])
(pub/'original-artifact-manifest.json').write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n');(p/'owned-learner-ledger.jsonl').write_bytes(b''.join(owned))
bid='20261015-051302-s2-strategy-proposal';tree='24de68ae5d7c329dc445f48451fff885ce1c43c2';rows=[x for x in state['batches'][bid]['fallback_checks'] if x.get('tree')==tree];assert len(rows)==1 and rows[0]['rc']==0 and rows[0]['merged']=='fad271855a515e229c7022f5049cc870f95a8d69';log=Path(rows[0]['log']);text=re.sub(r'\x1b\[[0-9;]*m','',log.read_text());assert 'Test Files  483 passed (483)' in text and 'Tests  4891 passed | 2 skipped (4893)' in text
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();d={'at':at,'batch':bid,'canonical_fallback_check':rows[0],'log':ref(log),'tsc':0,'vitest':0,'test_files':483,'passed':4891,'skipped':2,'duration_s':697.69,'exact_live':'fad271855a515e229c7022f5049cc870f95a8d69','exact_tree':tree,'release_ids':['V5-R359','V5-R360'],'intermediate_P2_only_tree':'not a full check of571bd2d0; no green borrowed','next_on_natural_consumer':'pending original watcher','old_failures_and_other_trees':'preserved','new_request_for_this_unchanged_tree':False};(pub/'v5s-host-full-completion.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');dest=r/'paper/materials/20261015-v5-s-completion/resume-1615';(dest/'ops-host-completion.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');a=json.loads((dest/'ops-publication-receipt.json').read_text());(p/'prior-publication-receipt.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');a['host_status']='completed exact final tree tsc0/vitest0; 483 files4891 passed2 skipped';a['host_completion_receipt']=str((dest/'ops-host-completion.json').relative_to(r));a['next_natural_on_consumer']='pending original watcher; current old shadow run not an on consumer';(dest/'ops-publication-receipt.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'batches':3,'ledger_rows':len(owned),'source_ready':1,'empty_batches':2,'R359_R360_exact_host':'0;483files4891pass2skip'}))

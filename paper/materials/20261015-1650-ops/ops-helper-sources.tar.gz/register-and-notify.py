from pathlib import Path
import json,subprocess,sys,hashlib,fcntl
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1650';pub=r/'paper/materials/20261015-1650-ops';d=json.loads((pub/'publication.json').read_text());assert not (p/'own-appends.json').exists();at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True);bid='20261015-154303-strategy-proposal';updates=[]
for ident in ['silent-0237','silent-0238']:
 updates.append({'id':ident,'by':'ops:codex','where':{'commits':[d['source'],d['behavior_commit'],d['actual_live']]},'note':f'{at} {d["release_id"]}/{d["name"]}原神化宽提案89354805/283a1647仅致命毒药5→7子项已实际main/live祖先；四叶窄差保R355–R360/旧注释，source固定6过/撤5失败1过/恢复6过、完整433文件4081+paths11/tsc0。VLZ F36发现及F37同局重复不是独立验证；未知组合和HP/SL/药价/排序均不改。仅补发布来源，不改旧claim/证据/首证/prior/status/经验version/support/repeat；原failed/rc0/mergednull与四记录冲突保留，10宽项waiting。新组合tree{d["tree"]}原154303一次宿主已请求，结果/自然消费者待验。回执paper/materials/20261015-1650-ops/。'})
ledger=r/'paper/materials/learning/ledger.jsonl';before=ledger.stat().st_size;(pub/'ledger-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates));run=subprocess.run(['python3','learner/ledger.py','update','--character','silent'],input=(pub/'ledger-input.jsonl').read_text(),capture_output=True,text=True);(pub/'ledger-update.log').write_text(run.stdout+run.stderr);assert run.returncode==0;rows=[]
for raw in ledger.read_bytes()[before:].splitlines(keepends=True):
 v=json.loads(raw)
 if v.get('by')=='ops:codex' and 'paper/materials/20261015-1650-ops/' in v.get('note',''):rows.append(raw)
assert len(rows)==2 and all(set(json.loads(x))<=set(['op','id','ts','by','where','note']) for x in rows);(p/'owned-ops-ledger.jsonl').write_bytes(b''.join(rows))
original=json.loads((pub/(bid+'-readback.json')).read_text())['original_report'];follow=json.loads(json.dumps(original));follow['merged']=d['actual_live'];follow['version']=d['release_id'];follow['ops_actual_publication']=str((pub/'publication.json').relative_to(r))
for x in follow['proposal_results']:
 if x['id'] in ['silent-proposal-89354805ee4d7e77','silent-proposal-283a164780d11e69']:x['reason']=f'原source ba23ca693致命毒药神化5→7窄子项已实际live并登记{d["release_id"]}；其余持续施放身份/升级交互/完整校准仍缺，保持原宽waiting。新组合宿主/自然消费者独立待验，不以子项关闭父项。'
(pub/'ops-publication-followup.json').write_text(json.dumps(follow,ensure_ascii=False,indent=2)+'\n');sys.path.insert(0,str(r/'ops'));import proposal_dispatch
with (r/'ops/codex-ops/learn.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);state=json.loads((r/'ops/codex-ops/learn.json').read_text());batch=state['batches'][bid];ids=set(batch['proposal_ids']);owners=[key for key,v in state['batches'].items() if key!=bid and v.get('state')=='running' and ids & set(v.get('proposal_ids',[]))];core={k:batch.get(k) for k in ['state','rc','merged','report','finished','pid']}
 if not owners:
  assert not proposal_dispatch.links(follow,batch,str(r),str(r/'ops'));proposal_dispatch.resolve(follow,batch,str(r),str(r/'ops'));stage='mechanical original10waiting followup; two narrow source publication links appended'
 else:stage='followup pending existing overlapping owner; frozen inputs not hot-replaced'
 actual=json.loads((r/'ops/codex-ops/learn.json').read_text())['batches'][bid];assert {k:actual.get(k) for k in core}==core
(pub/'registration-followup.json').write_text(json.dumps({'at':at,'ledger_cli_rows':2,'only_where_note':True,'old_status_experience_version_preserved':True,'original_batch_completion_preserved':core,'queue_stage':stage,'overlapping_running_owners':owners,'new_learning_parent':False,'wide10proposals':'waiting','natural_consumer':'pending'},ensure_ascii=False,indent=2)+'\n')
notice=f'\n- {at}｜规则实际上线 {d["release_id"]} / {d["name"]}：旧：已见普通致命毒药不在神化配对中，模拟后仍5毒/未知。新：仅Silent A10已核1能/零星费/普通5毒精确预览、无附魔/重放模板，沿原升级传播为7毒并同步文字；未施放神化仍5、已升不叠、未知修正/角色/进阶维持旧分支。证据/账本：VLZ6CCT8AQ0A F36T1神化、F36T2及F37T5升级施放毒0→7/HP不变，0237/0238；F37仅同局重复，不是盲测或独立收益。source{d["source"]}，固定6过/撤5失败恢复6过，源完整4081+paths11/tsc0；预期修正此窄候选少算2毒与虚假未知，不承诺整战胜率。实际behavior{d["behavior_commit"]}→live{d["actual_live"]}/tree{d["tree"]}；保R355–R360/知识/注释及全部并行记录，不重启当前局、不改账号模型prompt/药价/HP/SL/排序。回退精确撤此四叶/发布增量保其他发布及刷新。原failed/rc0/mergednull/四记录冲突与10宽项waiting保留，原154303新组合一次host及自然消费者pending。回执paper/materials/20261015-1650-ops/。\n'
changes={'notes/for-roy.md':notice,'ops/inbox-dev.md':notice,'paper/materials/decision-log.md':f'\n- {at} 运维codex：1650四事件核；R359/R360精确fad271/24de宿主tsc/vitest0、483文件4891过2跳/697.69s，仅收尾该组合，不倒填P2-only571或借给后继树；原watcher自然on消费者另验。原154303-strategy source ba23ca693神化致命毒药窄四叶自测4081+paths11/6固定/撤5败恢复6过已核，锁/四记录冲突阻塞由ops精确兜底实际发布{d["release_id"]}，live{d["actual_live"]}/tree{d["tree"]}，source main/live真实祖先，根双通知；保R355–R360、知识/历史注释和原failed/rc0/mergednull，两个窄子项补追溯/10宽waiting不关闭。原154303单次新组合宿主已请求，结果/自然消费者pending，不重跑源full。160652策略10waiting无源码/testsnull；164301空fix原failed/rc0/mergednull保持，72旧修复祖先核，原tsc0/仅10文件63定向过33过滤不当full，不新增发布/检查或派修。原三native模型Sol6.1/xhigh、workspace-write/no-network与input/租约核。非复盘不刷新论文；当前对局/账号/模型/额度队列prompt不改。证据paper/materials/20261015-1650-ops/。\n'}
appends=[]
for path,text in changes.items():
 with (r/path).open('ab') as out:out.write(text.encode())
 appends.append({'path':path,'text':text,'at':at})
(p/'own-appends.json').write_text(json.dumps(appends,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'release':d['release_id'],'ledger_rows':2,'dual_rule_notifications':True,'queue':stage}))

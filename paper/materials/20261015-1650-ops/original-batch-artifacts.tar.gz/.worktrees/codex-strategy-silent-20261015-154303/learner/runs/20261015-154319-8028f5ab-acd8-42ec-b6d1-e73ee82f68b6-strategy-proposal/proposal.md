# 静默猎手十项提案核对与致命毒药升级窄修复

本批：20261015-154303-strategy-proposal。角色silent；6个派发来源局均A10。基线ac7dc94915cfc25ea6bd3db16de821b4db4a0c89。仅处理已领取十id；不承接另一批专题，不改原提案Markdown或旧复盘。授权Roy-2026-10-07-learning；实现任务strategy-proposal。

## 本批实现范围

沿silent-proposal-89354805ee4d7e77与silent-proposal-283a164780d11e69，实现已观察普通致命毒药的神化升级5→7传播；原账本silent-0237/0238。F36T1 s275594→275595证实普通2能神化施放；F36T2 s275604→275605、d269634证实后续升级毒药实付1能并加7毒；F37T5 s275639→275640、d269668重复同一动作效果。全部期间run.deck该牌仍未升级。

原行为：该普通牌没有apotheosisUpgrade，模拟神化后仍5毒且标未验证。新行为：仅silent/A10、精确普通1费/零星费/5毒/无附魔与重放/原模板及效果预览，传播为7毒，升级显示文字一致；同手、具体后续抽牌及跨轮牌堆沿现有状态变换生效。普通牌未施放神化时仍5毒。未知输入、修正及未观察角色/进阶维持原行为。

以F36配对和动作作发现/固定回归，F37只作同局重复核验，不称独立盲测。F43该牌已经场外锻造，不能作为神化效果的新证；PREPARED的抽弃牌效果和PREDATOR的后继收益未在本次完整校准，未顺手扩展。这里不拟合收益常数或优先级，不改变药水、SL阈值、终局权重、选项集合或铁甲行为。

固定测试6项覆盖原始动作差、配对/文字、同手、具体后抽、跨轮牌堆、幂等/源输入不变、角色进阶与修正隔离；撤两叶生产改动5失败1通过，恢复6通过。规定沙箱整套结果与源码/live提交以report.md最终实际回执为准。

预期减少神化后已证致命毒药少算2毒与虚假未知，未承诺整战转胜。回退本批单个源码提交及部署补丁；保留固定夹具、原日志、失败、自测与台账。窄实现不把两个宽提案登记成完整implemented/duplicate；没有新重复id。

## silent-proposal-89354805ee4d7e77

按静默已观测帧补齐神化在同线及后续抽牌中的升级传播，并区分持有、施放与模型覆盖；无整场转胜保证。

- 账本：silent-0237, silent-0238。
- 证据：VLZ6CCT8AQ0A A10 F35T1/F36T1–2/F37T5/F43T1–2/F45T1；新增s275594–595、275604–605、275639–640，d269634/269668。
- 当前/本批行为：现有神化手牌/牌堆传播保持；本批补普通致命毒药5→7的已见配对与升级显示文字。
- 反例与限制：F43同序多8伤少1损是即时差；F45未施放失败不是必打神化或整场转胜的因果证据。
- 处置：waiting。宽项仍缺跨抽牌、选牌、药水、SL的实际施放持续身份、未覆盖卡/属性组合及完整生产校准；本次致命毒药窄修复不关闭原项。
- 预期与验证：同手与具体后续抽牌/跨轮牌堆的5→7、1能量、文本7、幂等与输入不变；未知修正和其他角色/进阶保留。
- 原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；本批original.md副本及队列SHA相同。

## silent-proposal-f2bfceddb1898dca

核验三骑士全败候选的即时血价、击杀缺口与药水MC预算成熟度；先做同盘预算实验，缺对照时保留原护栏、留药与目标规则。

- 账本：silent-0106, silent-0019, silent-0201。
- 证据：VLZ6CCT8AQ0A A10 F45T1 d269748：药水1/12、707ms，rollout horizon1/samples1/best=null；F45T4–5。
- 当前/本批行为：不改总预算、药水价格、留药、HP护栏或固定集火；本批仅复核原题成熟度与真实效果。
- 反例与限制：第二题12/12样本与首题1/12不可当整战对照；药水+1能/+2手牌而HP不变。
- 处置：waiting。缺完整模型、同起点/随机池/总预算的分阶段MC配对、候选稳定性曲线及独立验证；单题707ms不足定新预算。
- 预期与验证：后续须冻结模型/种子与全部输入，按run分组比较同预算候选稳定性；不调用在线模型补反事实。
- 原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；本批original.md副本及队列SHA相同。

## silent-proposal-283a164780d11e69

神化已观察升级进入同方案与后续抽牌，保留未知边界，不定必打规则

- 账本：silent-0237, silent-0238。
- 证据：VLZ6CCT8AQ0A A10 F36T2/F37T5；同第一项证据及silent-apotheosis-combat-upgrades关联。
- 当前/本批行为：与89354805ee4d7e77共用一次致命毒药窄修复，不新增重复代码提案id。
- 反例与限制：F36/F37是同一局的相关观察，不是两局独立泛化；保留普通/升级与永久锻造的区别。
- 处置：waiting。同源宽项仍缺持续施放身份及未覆盖升级交互；不能因题意重复或同一窄提交改记整项duplicate。
- 预期与验证：同第一项固定测试；原经验保持，由后续experience-update再沉淀本次新核定配对。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；本批original.md副本及队列SHA相同。

## silent-proposal-ebbfe3b97548756d

逐源验证当前攻防、毒触发与持续资源，不从持有或单轮减力预支整场收益

- 账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。
- 证据：VLZ6CCT8AQ0A A10 F43T3–5/F45T3–5；F43s275695敏4，F45s275754血32/挡20/来袭59/覆甲0。
- 当前/本批行为：十五条原经验逐源分账；现有敏捷、毒、临减力与资源计算不重设统一权重。
- 反例与限制：当轮减力不取消后轮成长；持有两雾不等建立群毒，0覆甲不补成开场4，死亡不反推另一focus必胜。
- 处置：waiting。缺十五条全部属性组合/升级联动/期限及战斗、路线、休息消费者的联合固定校准；本批部分端点不足认证整项。
- 预期与验证：后续按原条目逐路径固定校准，不以经验总支持数代替每个子式的验证分母。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；本批original.md副本及队列SHA相同。

## silent-proposal-e5b87be50f28f311

静默A10同盘SL以12血换7伤重犯：补齐Jev原答、HP护栏、SL换线及重规划的候选代价与实际成长兑现审计；单局不足以改阈值，保留现行为并独立验证。

- 账本：silent-0079, silent-0021, silent-0125, silent-0018。
- 证据：8JRE1C4H4Z2W A10 F33首/三试T2 d270216/270282，第二试T5 d270264；F17T6。
- 当前/本批行为：已有三阶段预测审计、单动作回执与离线端点；本批重新调用当前消费者核44个整轮端点。
- 反例与限制：同盘原/换线本轮损3/15、敌净扣10/17；0/24与5/24并非同死率。末试更保血仍败，不规定一律进攻或保血。
- 处置：waiting。原帧足以确认审计需求；仍缺跨重规划/选牌/药水/SL的候选持续归属与全过程生产读回，旧快照不能追补未记录身份。
- 预期与验证：须保原答、护栏、SL、实际派发及中断原因；连续候选生产身份另验，端点不归作整条候选实际收益。
- 原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；本批original.md副本及队列SHA相同。

## silent-proposal-49632bc4878fb597

把当前属性、每击修正、弱与成长分项验证，不增加统一保血或输出权重。

- 账本：silent-0005, silent-0231。
- 证据：CA5KE8GFJ9X2 A10 F13T1/3/5，s273237/273252/273263与弱后273257/273268。
- 当前/本批行为：核蚌当前力量0/4/8、同招11/15/19、弱后11/14；不加统一输出或保血权重。
- 反例与限制：虚弱没有取消下一次加压；不能把未取得步法当已建立，或以一个步法源码关闭整个复合项。
- 处置：waiting。本局没有正敏捷实测；缺力量、正负敏捷、虚弱与蚌独立成长四路径的联合生产调用校准。
- 预期与验证：后续冻结同角色调用和逐击/逐牌属性输入，保留独立成长；先校准而后评估权重。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；本批original.md副本及队列SHA相同。

## silent-proposal-66532328a585941f

持有/计划/已建立分账；如提构筑或启动权重，先做实盘兑现与受控整场验证。

- 账本：silent-0021, silent-0009。
- 证据：5PM6JAQG6FNQ A10 F39末试T2 s274379→274380、d268455；F33为对照观察。
- 当前/本批行为：持有、计划与已建立分开；空打冒泡能5→4、目标35血不变/毒0，局部事实保持。
- 反例与限制：F33已建能力且赢，但敌人/资源也不同；F39局部空打不足证明某启动或构筑顺序必胜。
- 处置：waiting。缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整场对照及可复现收益函数。
- 预期与验证：按完整run分组冻结启动顺序实验；不把尝试数当独立局数，不由零效果拟统一权重。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；本批original.md副本及队列SHA相同。

## silent-proposal-43a76a31ba7bdcfa

冻结吸取、负敏捷与毒的分项事实；任何SL范围或换线偏好需完整同盘验证。

- 账本：silent-0030, silent-0027。
- 证据：61E2QS63Y9WU A10 F17T5–6，s273504双防各3、敏−2，s273504→273508敌67→34。
- 当前/本批行为：吸取、负敏捷与毒各自核实；不改SL敌人范围、换线偏好或门槛。
- 反例与限制：该局首试七轮胜，不支持把别局重打失败归于固定顺序；未执行后继保持未知。
- 处置：waiting。缺同起始HP/牌组/完整抽序的整战生产配对与另一可核完整SL线路；首试胜利和毒端点不足改阈值。
- 预期与验证：按相同起点整战验证SL与不SL线路，记录缺帧和未选线，不能从本次毒端点填反事实。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；本批original.md副本及队列SHA相同。

## silent-proposal-5264153a4a4b0e5c

复验已有召唤和各实体成长；保留所有目标选项，相同推演值并列，不强制首杀。

- 账本：silent-0039, silent-0209。
- 证据：61E2QS63Y9WU A10 F23T3–5，s273589/273596两实体力3→6；s273593→273596敌76/14→41/2、玩家25→10。
- 当前/本批行为：当前召唤与实体成长参考保留全部目标；相同推演并列，不强制首杀。
- 反例与限制：T4幻象余2并攻击，T5才退；未选幻象39伤/零损候选不等实打整战胜线。
- 处置：waiting。缺A10召唤/航行/复现/退场全链的冻结生产校准及另一focus完整后继；已有召唤源码不证明目标排序收益。
- 预期与验证：须按实体和攻击来源核召唤、复活及成长；不按enemy_id类型或index臆造跨帧唯一实例。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；本批original.md副本及队列SHA相同。

## silent-proposal-bddfa690a84e03d0

按当前进阶、睡眠/眩晕/成长分别验证；不把未知换线胜率或固定杀序写成规则。

- 账本：silent-0128, silent-0079。
- 证据：DUZUBAJ3A8GP A10 F30T1–6，s274929/274932/274934力2/−4/4、意图20/14/22。
- 当前/本批行为：睡眠、醒来、眩晕和成长分源；不修改全败血价排序或固定杀序。
- 反例与限制：前三次predicted_death截断不能当已执行死亡；末试实际死亡，多3伤多2损不证整战优劣。
- 处置：waiting。缺伤害唤醒/眩晕期限/恢复成长全链生产校准及同抽换序完整后继；四次相关失败不足拟合输出血价。
- 预期与验证：冻结当前进阶完整输入、不同排序后继与原始移动链；未知唤醒条件保留，单轮尖啸不当停成长。
- 原文：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；本批original.md副本及队列SHA相同。


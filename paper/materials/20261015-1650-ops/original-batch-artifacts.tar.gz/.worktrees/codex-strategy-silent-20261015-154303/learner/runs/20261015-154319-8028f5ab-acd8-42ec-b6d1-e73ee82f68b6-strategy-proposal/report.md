# 静默策略学习：致命毒药升级窄修复与十项处置

记录时间：2026-10-15T16:09:26+08:00。本批20261015-154303-strategy-proposal，角色silent。

## 交付结论

已实现并提交普通致命毒药的神化升级5→7窄修复，源码ba23ca693151fa8c6f7fe035e640dc30f05ccd75。规定沙箱检查退出0，固定6项通过，撤生产源码5失败/1通过，恢复6通过。live锁被占用，未进入发布事务；独立只读提交合并预检确认内容冲突（notes/for-roy.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl）。按任务停止，不覆盖并行记录，未实际合入；待ops沿已测源码提交窄差兜底；merged=null。

本次沿两个原神化id完成一个有证据的子项，不建立重复提案id；十个原提案均保留waiting，宽项未完成部分逐项列明。未把子项框架、静态源码、单动作回执或报告完成称为完整提案实现、经验已入库、大脑已消费或父要求关闭。

## 派发与基线

初始HEAD=55533ec07a3fe8349fb5764005c2e502ac339095，git status干净；必读材料已读。普通批次按要求git merge --no-edit main快进至完整base=ac7dc94915cfc25ea6bd3db16de821b4db4a0c89，源码提交父提交仍为该base。learn.json本批task/角色/工作树/六runs与十proposal_ids匹配，无research_request/implementation_request/proposal_repair；另一批纯研究请求未承接。独立完成，没有下级agent。

6局runs原行均SILENT/A10；不读其他角色私有知识，不用预训练事实填结论，不把同局重打或两次动作当独立局。本批六局的状态/决策冻结输入SHA与20261014-211320旧批一致（prior-input-comparison.json）；本批重新提取、核原行并执行当前消费者，不借旧绿。

## 实盘证据与新实现

VLZ6CCT8AQ0A：F36T1 s275594→275595，普通神化实能量7→5；F36T2 s275604→275605、d269634，后续致命毒药升级版实付1能，炮塔操控员毒0→7、HP51不变。F37T5 s275639→275640、d269668同样付1能、方盒构造体毒0→7、HP4不变。这些帧run.deck该牌始终普通5毒。原动作decision_id/observed_ts/fingerprint、卡与目标身份、offset/bytes/SHA均核实，见deadly-poison-action-readback.json和固定evidence JSON。

旧行为：普通毒药没有神化升级配对，模拟施放神化后仍按5毒并标未知。新行为：只在silent/A10、已见1能/零星费/5毒原模板及精确预览、无附魔和重放的输入中，沿原升级状态传播为7毒并同步显示文字；普通牌未施放神化仍5毒，已升级不再累加，源牌组/快照不变。其他角色、进阶和未验证修正保持原行为。没有修改药水价格、预算、SL/HP护栏、终局权重、选项集合或固定目标/必打规则。

F36用于发现与固定回归，F37只作同局重复核验，不冒称盲测或独立后置验证。F43该牌已场外锻造，不能作为神化因果新证。早有准备的可见升级对没有在本次校准完整抽弃效果，未扩展；猎杀者后继收益也未在本次扩展。预期减少已证候选少算2毒及虚假未知，不承诺实盘整战转胜或胜率。

## 原日志与离线消费者

共用extract_evidence.py抽取8类流，逐行读回6995行，校验显式所属局、原offset/bytes/SHA与JSON。六主流和runs/fight-plans附加流分别保存原manifest；身份取run_id/state.run_id/run/fingerprint.run，冲突不收、正文提及不算身份。states/decisions全源各有2无效JSON、brain1行，不能据此归到本六局。fight-plans在所核截点六局均0，只表示该截点未选到。

| 流 | source_size字节 | 所属核验行 |
|---|---:|---:|
| states | 13045703216 | 3432 |
| decisions | 1591550188 | 3306 |
| sl-attempts | 40510364 | 29 |
| run-config | 1758260 | 6 |
| run-plans | 8044989 | 33 |
| brain | 578341252 | 183 |
| runs | 334478 | 6 |
| fight-plans | 2233957 | 0 |

原帧事实37项通过；现有神化参考夹具6帧与本批原字节相同。这些是材料核验，不是新增生产测试或历史测试结果复用。

| 局 | 有ID动作 | 候选片段 | 相邻端点 | 终页端点 | 整轮端点 | 未知轮窗口 |
|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |

当前基线消费者重新离线执行，没有LLM/网络。三局完整输入通过；CA5第267143行、61E第267517行、DUZU第268789/268818/268864行没有decision_id，完整输入真实拒收保留；仅删除这五个无ID行后得到有界子集，保留原物理行号/缺口，不伪造ID或冒称完整输入通过。3301有ID动作、476片段、859相邻观测端点、4终页、121整轮与413未知窗口分开。所有actual_full_candidate_result仍null；这是工具认证边界，不是策略失败证明。

8JRE F33首/三试T2同指纹本轮分别损3/15、敌净扣10/17，差12血/7伤；0/24与5/24不等死率。原HP护栏270264只在rationale，结构字段为null不能说没有护栏。候选、真实派发、中断和观测端点不作整战因果归属。

## 源码与验证

只改四个明确文件：agent/src/reflex/silent-apotheosis.ts、card-model.ts及新固定测试/evidence JSON。source-change.patch、前/后原字节.txt、固定夹具SHA、负控与完整日志均保存在本目录。提交前git diff --check及gitleaks-source均0；无依赖安装、对局/play、网络或凭据读取。

规定入口：agent/ 内bash tools/test-sandbox.sh；exit=0，tsc=0，vitest=0。实际摘要：433文件4081项通过；独立1文件paths11项通过，总4092项；tsc0，完整入口exit0。没有把固定排除文件或宿主全套说成已跑；本批未自行请求宿主检查。

固定测试包含5→7与显示文字、两真实施放增毒/能量而无即时HP伤、同手/具体后抽/跨轮牌堆传播、幂等与输入不变、其他角色/未观察进阶/修正隔离。撤两叶生产源码exit1（5失败1通过），原字节恢复exit0（6通过）；两次日志与negative-control.json保留。37项原帧事实检查不能代替这次生产回归。

修改前live只读快照1e3f8d10bddc7bb97acad87cf37238490c4cfc5c：15相关路径13个blob相同，另card-model/rollout-live仅历史注释文字差。现有神化参考、三阶段审计/单动作回执、离线端点工具的实际live祖先逐项核实于source-verification.json；这些是旧窄实现来源，不能冒称本批新部署或十项全实现。

## live结果与交接

live锁被占用，未进入发布事务；独立只读提交合并预检确认内容冲突（notes/for-roy.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl）。按任务停止，不覆盖并行记录，未实际合入；待ops沿已测源码提交窄差兜底

实际操作和原输出见merge-attempt.json及对应日志。没有实际上线就不制造eval版本、release_id、shipped、上线decision-log或Roy规则双通知；原调度完成事件将源码和本报告交ops沿原链处理。本批回退方法为回退该单个源码提交/部署补丁，保留原证据、测试、提案和台账。

## 十项处置

| 原id | 处置 | 未完成原因 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 宽项仍缺跨抽牌、选牌、药水、SL的实际施放持续身份、未覆盖卡/属性组合及完整生产校准；本次致命毒药窄修复不关闭原项。 本批窄修复源码ba23ca693151fa8c6f7fe035e640dc30f05ccd75已提交；live锁被占用，未进入发布事务；独立只读提交合并预检确认内容冲突（notes/for-roy.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl）。按任务停止，不覆盖并行记录，未实际合入；待ops沿已测源码提交窄差兜底。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型、同起点/随机池/总预算的分阶段MC配对、候选稳定性曲线及独立验证；单题707ms不足定新预算。 |
| silent-proposal-283a164780d11e69 | waiting | 同源宽项仍缺持续施放身份及未覆盖升级交互；不能因题意重复或同一窄提交改记整项duplicate。 本批窄修复源码ba23ca693151fa8c6f7fe035e640dc30f05ccd75已提交；live锁被占用，未进入发布事务；独立只读提交合并预检确认内容冲突（notes/for-roy.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl）。按任务停止，不覆盖并行记录，未实际合入；待ops沿已测源码提交窄差兜底。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五条全部属性组合/升级联动/期限及战斗、路线、休息消费者的联合固定校准；本批部分端点不足认证整项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 原帧足以确认审计需求；仍缺跨重规划/选牌/药水/SL的候选持续归属与全过程生产读回，旧快照不能追补未记录身份。 |
| silent-proposal-49632bc4878fb597 | waiting | 本局没有正敏捷实测；缺力量、正负敏捷、虚弱与蚌独立成长四路径的联合生产调用校准。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、牌组、药水和完整抽序下不同启动顺序的受控整场对照及可复现收益函数。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP/牌组/完整抽序的整战生产配对与另一可核完整SL线路；首试胜利和毒端点不足改阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤/航行/复现/退场全链的冻结生产校准及另一focus完整后继；已有召唤源码不证明目标排序收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒/眩晕期限/恢复成长全链生产校准及同抽换序完整后继；四次相关失败不足拟合输出血价。 |

每项证据局/层/回合、账本、原文SHA、反例、当前/预期行为、验证和回退见proposal.md。未领取新id、未改专用队列或learn.json、未重写原提案/复盘。账本只经根CLI追加，本批新核定致命毒药帧关联0237/0238，其他条目只追加本报告链接和核验说明；不重置旧claim/状态/首证/先验/版本或代记shipped。经验库沉淀由后续experience-update处理，未声称消费者已自然使用本次修复。

提案交ops：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-154303/learner/runs/20261015-154319-8028f5ab-acd8-42ec-b6d1-e73ee82f68b6-strategy-proposal/proposal.md。最终机器结果：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-154303/learner/runs/20261015-154319-8028f5ab-acd8-42ec-b6d1-e73ee82f68b6-strategy-proposal/result.json。

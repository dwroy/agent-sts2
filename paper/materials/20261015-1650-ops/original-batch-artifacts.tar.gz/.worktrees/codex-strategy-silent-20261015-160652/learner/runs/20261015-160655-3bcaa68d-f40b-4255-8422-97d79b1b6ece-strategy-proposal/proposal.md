# 本批十项静默猎手策略提案核证与处置

批次：20261015-160652-strategy-proposal。来源任务及实现任务：strategy-proposal。角色：silent，直接核实范围仅 A10。基线：7459f1425ca012a6c6a228a2838fea05f4cb98ad。工作树开工干净，合并 main 返回 Already up to date。本批无 research_request / implementation_request，普通专题文件绑定其他批次，不构成本批专题身份；仅处理实际领取的十个原提案，不新增重复 id。

结论：十项均 waiting。现有证据支持局部资源事实，不能支持新的留药血价、SL额外损血门槛、HP护栏或终局排序权重。已有窄诊断功能不等于全部原提案完成；本批没有源码实现、提交、合入、版本或 shipped 登记。

## 已核实材料与可复查范围

六局均经原 runs.jsonl 核为 SILENT A10：751FN9QM9MHQ、KV0JHNJCKXLS、YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN、KEN58SH9SLZ6。六局整局最终均未通关；PU 的 F17 第五试过关与最终 F33 失败分别记，不把整局失败当 F17 六败。L9 的大脑来源另列，未将其纳入纯 Codex 战绩或因果比较。

八流共 8,444 条所属原行：states 4,167、decisions 4,071、sl-attempts 43、run-config 6、run-plans 21、brain 130、runs 6、fight-plans 0。使用本树 learner/extract_evidence.py 抽取；逐行回读只读原日志，核 offset/bytes/SHA/JSON/显式身份和各流 source_size 截点。八流计数、抽取文件 SHA 及原行校验均通过。run-plans 的 run 字段正常取到21行；fight-plans 在本次截点选到0行，不据此断言历史原日志不存在。源流全文件中的无效行计数为 states 2、decisions 2、brain 1，其所属不可由本次抽取认定，未作为本角色游戏证据。

完整清单见 evidence/evidence-manifest.json、evidence-extra/evidence-manifest.json；原提案路径和 SHA 见 proposal-source-manifest.json，十份原文副本 original-proposal-01.md 至 original-proposal-10.md。原复盘和提案未改写。

## 支持事实、反向取舍及未知

1. 751 F17 T2（decisions 272434/272575）同指纹，第1/3试同轮起始至下一轮起始：敌净扣9→18、玩家净损13→18；T7（272531/272652）第2/4试敌净扣12→18、净损13→23；T13第1/6试敌净扣17→11、净损8→2。前两组支持额外输出有血价，后一组说明省血也付输出代价。六试皆未胜，不能把六次相关重打当六个独立验证样本。这些数字是净差，不是毒/攻击/荆棘的逐源毛伤害。
2. 751 F13 T3（272361）原答 plan2 用药，和明确全程无药的 plan5 均为模型8/8在五轮内结束、即时8损；牌伤26与16不同。plan3虽当轮不喝，后轮7/8样本仍喝，不能当完整无药对照。原题明确 potion table did not load，0成本不能当已学得0持有值。缺无药实打整战和留至boss结果，不认定实际饮用错误。
3. KV F33第4/5试T5（sl-attempts 955/956）同30血、敌334血；删除致命毒药后敌净扣36→29、双方当轮均零损，均T10判死但后轮动作亦变。没有可记录的当轮保血收益，也不能把整体失败归于这一动作。敌回血和未走路线不能用净血差或预测回血代替实际结算。
4. YQL F17末试T10（states 280160/280161，decisions 274087）毒药使占位体毒2→8，玩家仍26血/13挡，DeathBlow仍41，敌 max_hp 999999999。局部加毒不是当前自爆减6或即时回血。缺提前喝、不喝、留药的受控整战。L9 F17首试T14的占位血999999999仍在原summary；PU F17首/次试T17分别999999989/999999981，第五试T15获胜余2血，构成不能只凭最长存活或占位残血判优的限制案例，不证明替代排序可获胜。
5. KEN F17第4/5试T10（decisions 274505/274568）同37血、敌82血指纹：敌净扣2→4、玩家净损15→21；多付6血只多2净扣。第4/6试T5（274484/274601）同指纹而步法由T5延至T9；反驳只以当轮少失血断言优越。六试未胜，缺其他后继条件固定的受控比较。
6. KEN七次饮用（decisions 274131/274156/274185/274235/274237/274267/274272）对应 states 280206→280207、280232→280233、280262→280263、280313→280314、280315→280316、280348→280349、280354→280355，逐组核实对应槽位消耗。槽位消耗能证明实际耗药，不证明随机选牌、重问、后继执行已完成收益归属，更不证明不喝同样零损。缺F15不喝及留至boss完整分支。

本轮未新增策略权重、阈值或训练样本。旧源提案中的更早角色局仅作为历史引用，本批没有将其追加为已亲自分析的新支持局。拟合须以后续独立局按真实时间留出，不能拆分同局SL充作训练与验证。

## 当前实际 live 的覆盖与缺口

只读固定 live HEAD：9de6d107c5dad20095a37e33695f8c18a963d081。以下源码 commit 均已核为该 HEAD 的实际祖先，文件原字节与 SHA 保存在 live-source-manifest.json 及 .txt 副本；这些是既有实现，不是本批提交。

| 实际源码祖先 commit | 覆盖 | 未覆盖部分 |
|---|---|---|
| a8b1f8be153fe4f3a34146117546c2178f2e446b | SL原线与替换线的候选预测及差额 | actual_turn_result 明确 null；不是完整执行归属 |
| 05cd292c6f01bb31e406473d3a9843e659d62b93 | 原答/护栏前后/SL候选分阶段，持牌模型损血、弃牌未决和来源 | actual_held_hp_loss 与 actual_turn 均 null；未兑现能力或逐源实果不能由差额补齐 |
| bade647f9fe4c9103b40e2f26b26296692ad24b7 | 单动作派发身份和返回状态 | state_effect_verified=false、whole_plan_executed=null；重问后完整方案未知 |
| 0d092f6b928a6221eabf3516abad25c48ceaac9c | 巨兽本体/自爆阶段及限定条件下最终资源诊断 | enemyHpLeft/anchorRank仍保留原始占位血同轮tie-break，不声称新排序已实现 |
| e1a467e18a0dfa8d99046a24ff4c0e1af59278c8 | 药水成本与缺表/无值来源保留，holdHp可为null | 不据来源说明校准跨战持有值，缺可归因的未饮用后继 |

live 的 potion-cost.ts、explore.ts 与本批 main 基线存在字节差，未以本树源码假代 live。上表依保存的 live 原件核对，不改 live，也不拿旧源码测试绿替代本批检查。

## 十项逐项处置

| 原CLI提案id | 已有账本id | 处置与具体等待条件 |
|---|---|---|
| silent-proposal-366288801d9150d9 | silent-0079、0176 | waiting；751 F17 T2/T7/T13已核，等完整执行归属、受控整战后继；不定额外损血门槛 |
| silent-proposal-85929bdfc8a3fc1b | silent-0019、0021、0005、0007、0129、0176 | waiting；751 F13 T3已有无药模型，等无药实打/留至boss及弃牌后逐源实果 |
| silent-proposal-efd9f83ee9e1a6dc | silent-0079、0176 | waiting；751双向血价已核，等单因后继和后期独立验证；不改探索排序 |
| silent-proposal-131042659448ae74 | silent-0019、0020、0021、0005、0006、0007、0046、0129、0176 | waiting；已有预测拆项，等毒/荆棘/攻击与能力兑现完整归属及无药跨战校准 |
| silent-proposal-990f054036609447 | silent-0102、0019、0020 | waiting；KV F33 T5删输出无当轮保血，等完整后继、回血毛净分账及路线休息未执行分支 |
| silent-proposal-e18d3f18e6cac2a0 | silent-0017、0250、0011、0027、0046 | waiting；巨兽已有阶段诊断，等新参考排序完整后继及资源/结局校准 |
| silent-proposal-9733bb80f445aeae | silent-0017、0019、0020、0250 | waiting；YQL末试T10局部药效已核，等提前喝/不喝/留药及新排序受控整战 |
| silent-proposal-c51468c5e8ba6668 | silent-0019 | waiting；KEN七次耗药已核，等随机选牌/重问完整收益与F15不喝/保留药分支 |
| silent-proposal-86a7db08d1a31976 | silent-0079、0021、0125、0005、0176 | waiting；KEN T10和T5反向取舍已核，等逐源实果、整战后继和新局留出 |
| silent-proposal-e282a9131b99129a | silent-0021、0079、0125、0176 | waiting；KEN六试同局且双向代价明确，等完整能力后继、受控胜线及后期验证 |

机器可读逐项理由见 proposal-results.json。不调用 add 制造重复提案；保留原CLI id与原经验/复盘链。账本仅经根 learner/ledger.py update 追加本批报告/提案去处及说明，不重复证据，不改旧claim、首证、prior、status或版本。

## 验证与后续实施边界

verify_evidence.py 是本批 scratch 材料核验脚本，不进入生产源码。最终45项材料核验通过；证据8444行原字节逐一校验。首轮40过1失败：本脚本将PU首/次试T17占位血预期顺序写反；按原sl-attempts 715/716核正，保留 evidence-verification-run1.json/.log，再跑45项全部通过（evidence-verification-run2.log），没有修改游戏证据或策略。

无源码改动，不执行撤源码/恢复试验，不运行tsc/vitest，不报成功退出码；不合入、不发行为版本、不标shipped。预期行为保持当前版本；若未来证据支持改规则，单独实施并做固定数据撤码失败/恢复通过、沙箱完整检查、实际live祖先核验和规则双通知。回退本次材料无需游戏回退；保留全部原日志、初稿、失败及提案链。

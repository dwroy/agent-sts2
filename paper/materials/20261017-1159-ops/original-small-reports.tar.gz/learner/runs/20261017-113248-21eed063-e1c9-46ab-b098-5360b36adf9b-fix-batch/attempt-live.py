import json
from pathlib import Path
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent
live = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
source, branch = sys.argv[1:]

def git(*args):
    return subprocess.run(['git', '-C', str(live), *args], text=True, capture_output=True)

def checked(*args):
    result = git(*args)
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout.strip()

receipt = {'source': source, 'branch': branch, 'merged': None, 'lock_held_by_flock': True}
while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
    time.sleep(10)
receipt['before_refresh'] = checked('rev-parse', 'HEAD')
receipt['status_before_refresh'] = checked('status', '--short')
if git('diff', '--cached', '--quiet').returncode:
    receipt['blocked'] = 'preexisting_live_index'
else:
    checked('add', 'notes/fight-value-backtest.md', 'knowledge')
    if git('diff', '--cached', '--quiet').returncode:
        diff = git('diff', '--cached', '--binary').stdout
        scan = subprocess.run(['gitleaks', 'stdin', '--redact', '--no-banner'], input=diff,
                              text=True, capture_output=True)
        (scratch / 'live-refresh-gitleaks.log').write_text(scan.stdout + scan.stderr)
        receipt['refresh_gitleaks'] = scan.returncode
        if scan.returncode:
            receipt['blocked'] = 'knowledge_refresh_scan_failed'
        else:
            checked('commit', '-m', 'Refresh knowledge data', '-m',
                    'Co-Authored-By: Codex GPT-6.1 Sol <noreply@openai.com>')
    if 'blocked' not in receipt:
        receipt['before_merge'] = checked('rev-parse', 'HEAD')
        receipt['source_files'] = checked('diff-tree', '--no-commit-id', '--name-only', '-r', source).splitlines()
        receipt['refreshed_files'] = checked('diff', '--name-only', receipt['before_refresh'], 'HEAD').splitlines()
        receipt['source_refresh_overlap'] = sorted(set(receipt['source_files']) & set(receipt['refreshed_files']))
        preview = git('merge-tree', '--write-tree', 'HEAD', source)
        (scratch / 'locked-live-merge-preview.log').write_text(preview.stdout + preview.stderr)
        receipt['preview_exit'] = preview.returncode
        receipt['conflicts'] = sorted({line.split('\t', 1)[1] for line in preview.stdout.splitlines()
                                       if '\t' in line and len(line.split('\t', 1)[0].split()) == 3})
        if preview.returncode:
            receipt['blocked'] = 'live_history_merge_conflicts'
        else:
            # Tests and release records are handled only after a conflict-free actual merge.
            merged = git('merge', '--no-edit', branch)
            (scratch / 'live-merge.log').write_text(merged.stdout + merged.stderr)
            receipt['merge_exit'] = merged.returncode
            if merged.returncode:
                receipt['blocked'] = 'actual_merge_failed'
            else:
                receipt['merged'] = checked('rev-parse', 'HEAD')
receipt['final_live'] = checked('rev-parse', 'HEAD')
receipt['final_status'] = checked('status', '--short')
(scratch / 'live-attempt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))
sys.exit(3 if receipt.get('blocked') else 0)

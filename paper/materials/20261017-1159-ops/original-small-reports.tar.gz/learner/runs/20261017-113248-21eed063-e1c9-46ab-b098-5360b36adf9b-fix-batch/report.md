## 修 bug 回报

- 合并基线：main → d675d48f6f81d39ec1354e244dd69569b8be33ec
- 修复（每条一行）：h1-budget-completion-health-contract：限时前缀被C2/G2误报为错误及缓存完成身份混用 — c40e43fd25c200a01f4da94a4dac8db1b34664a8 — 测试 agent/tests/global-build.test.ts:preserves a budgeted 838-pair prefix as incomplete shadow data, not a service failure — 去掉修复时失败：是
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb9be14d620b368ec46974c1b57901ca（实际live祖先；main亦包含）
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0b758a1a5e7d591745694004664f83a（实际live祖先；main亦包含）
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb61eef226eb7366f9612003480c83988（实际live祖先；main亦包含）
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7524bbb8e80a975f204f8d193657b46（实际live祖先；main亦包含）
- 已被别人修掉的：空产出补链误派 — 84366ad06ee4f978394c1b9489a82c83ea12bd36（实际live祖先；main亦包含）
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1（实际live祖先；main亦包含）
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a826e94f9708af4b1a265e1892659f4e（实际live祖先；main亦包含）
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（实际live祖先；main亦包含）
- 已被别人修掉的：纸鹤夹具 — befc39e5ca0105f8ff96d47f817df44f0b2760f1（实际live祖先；main亦包含）
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e5a0f234f082972d21b203dbf8229d7（实际live祖先；main亦包含）
- 已被别人修掉的：共享main启动冲突 — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2（实际live祖先；main亦包含）
- 已被别人修掉的：根事件通知路径 — 577f0bc424b7287910735cfdc86c253cc7ee8057（实际live祖先；main亦包含）
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe043cb8738cce57870354fa23fa84a1（实际live祖先；main亦包含）
- 已被别人修掉的：局间quiet误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d（实际live祖先；main亦包含）
- 已被别人修掉的：global-health异步测试 — d27df54f0651c4af84c6c12ceceec82a016f1142（实际live祖先；main亦包含）
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径本批另补） — 83a7f796c24eea8f16eb317bc70bfd832251ad27（实际live祖先；main亦包含）
- 已被别人修掉的：retention数字UUID — d91236326bc1af7a5417ce016c1a182f8084e7a3（实际live祖先；main亦包含）
- 已被别人修掉的：retention旧根scratch — 0699b05c436d3d51d00ee92f153d16d16e64bea4（实际live祖先；main亦包含）
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec5fc6eafe576a1296bbdadde43432ee（实际live祖先；main亦包含）
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b（实际live祖先；main亦包含）
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ceeb81d534159b3516458521ad09bbed（实际live祖先；main亦包含）
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a5168d1a8cb456aed1c926b2d1b6c4488（实际live祖先；main亦包含）
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（实际live祖先；main亦包含）
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d（实际live祖先；main亦包含）
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093（实际live祖先；main亦包含）
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7（实际live祖先；main亦包含）
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b7913a53b9e2645f40db1657eb5213c（实际live祖先；main亦包含）
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb12a1d4b2f34ee767bb2816a3a0b466（实际live祖先；main亦包含）
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537（实际live祖先；main亦包含）
- 已被别人修掉的：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70bfb2a91138ede0e1f6046927c116a4（实际live祖先；main尚未包含，本批未重复修改）
- 已被别人修掉的：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420（实际live祖先；main尚未包含，本批未重复修改）
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66bd75c6d6952772dcf712399eda828b（实际live祖先；main尚未包含，本批未重复修改）
- 已被别人修掉的：infra-test-rollout-ties-host-timeout-15000 — da08fcead2025c293140f1ba103d8efdbd39a4c3（实际live祖先；main尚未包含，本批未重复修改）
- 已被别人修掉的：infra-test-build-facts-selection-remove-latency — e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0（实际live祖先；main尚未包含，本批未重复修改）
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。
- 没修的：selection-hidden-daggers-conditional-followup-readback — 策略链；已有独立提案silent-proposal-59b2e430bb7521d4，注册记录仍为pending，按任务1.4沿独立strategy-proposal处理，未重复领取或实现。
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496） — 策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。
- 没修的：silent-0332实际nonpositive-hp资源契约根因 — 证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。
- 没修的：arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查 — 独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。
- 没修的：core-build-notify-222802-rc2原生通知恢复 — 旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。
- 没修的：codex缓存实测、DPR性能及历史宿主超时根因 — 证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。
- 测试：本分支 tsc 退出码0；沙箱vitest 469文件 / 4311用例 / 退出码0；定向5文件29项0。补缓存完成身份修复后重跑整套，前一版469文件4310例亦0；无超时补验。
- 合入：未合入；锁内merge-tree预检21处历史记录冲突，未执行实际merge。已保存知识刷新 53f2217cc83c4f31f43af0ecec7035e874c84028，源码与刷新文件无重叠。
- 需要 Roy 定的事：无

验证与合入边界：

- 原证据：5H83F3J0XSTE / Silent A10，F8火堆与F12商店回合字段为空，F19/T3、F20/T5。四条原decisions按offset/length/SHA256读回，838/260/103/504实际配对样本均budgeted=true、status=partial、failure=false；固定协议投影见agent/tests/fixtures/h1-budget-completion.json，来源引用见original-prefix-readback.json。
- 旧行为：C2健康检查只接受complete_adaptive；G2先拒timedOut，丢弃实际前缀并包装为global_computation_failed。新行为：显式预算前缀单列budgeted_partial，保实际n与配对误差；不计完整完成、不进入G2完整汇总。n<2数值未知，非预算不完整、显式worker/resource/C1错误仍拒绝。缓存键保存预算完成身份，保持原memo时间字段复用。
- 这是完成状态/审计协议修复；未改采样、300/1000门槛、期限、C2淘汰、游戏决策或角色知识。globalReadinessHistory没有生产读取方，G2仍shadow/delivered=false/s_sort=false，不新增行为版本、游戏代码提案或规则双通知。原自然验收、0332根因和其他宽父未关闭。
- 保留新测试、仅撤四个主要源码文件时4文件9失败/15通过（targeted-without-fix.log）；恢复后4文件24项0（targeted-restored.log）。追加缓存负控、仅撤缓存键源码时1失败/4通过（memo-without-fix.log）；恢复后最终5文件29项0（final-targeted.log）。最终完整沙箱检查包含tsc，输出见final-sandbox.log，来源状态见validation-summary.json。
- 账本CLI按bug-infra和h1-budget/5H83F3J0XSTE查询无匹配，故未新建、未追加提交链接或标shipped；详见ledger-lookup.json。
- 已修34项逐提交核实实际live祖先；与上一批基线相比，上述纯运维源码文件没有新的提交差异。上一批五个夹具修复仅在live为祖先，不将其冒称本批已合main。队列未修改，原输入及SHA保存在fix-queue-input.md和queue-previous-fixes-audit.json。
- 初次相对路径编辑错误和一次只读工具bubblewrap/rg扫描ENOENT原件分别保存在initial-test-edit-path-error.txt、read-preflight-race.json；未当产品回归或放宽沙箱。
- 实际flock锁内：等待知识builder、仅提交刷新knowledge/characters/silent/fight-value.json；刷新扫描0，保留原两份notes未提交变更。随后预检出现21个历史记录冲突，未实际merge、未写上线日志或版本、未运行live合后检查。锁内原件见live-attempt.json和locked-live-merge-preview.log；本分支干净。
- 原日志只读，未调用模型/网络，未运行play、推送或修改运维prompt；未删除工作树、失败现场和原始证据。

冲突文件：

- docs/human-pace-plan.md
- notes/fix-queue-v4.md
- notes/for-roy.md
- notes/lessons.md
- notes/ops-handoff.md
- ops/inbox-dev.md
- paper/data/README.md
- paper/data/commits.csv
- paper/data/cost-curve-silent.csv
- paper/data/cost-silent.csv
- paper/data/cost-sources.json
- paper/data/cost-unattributed.csv
- paper/data/decisions_by_label.csv
- paper/data/learning-curve-silent.csv
- paper/data/runs.csv
- paper/data/summary.json
- paper/data/verification.json
- paper/materials/decision-log.md
- paper/materials/learning/code-proposals.jsonl
- paper/materials/learning/ledger.jsonl
- paper/materials/silent/cost.md

```json
{
  "task": "fix-batch",
  "base": "d675d48f6f81d39ec1354e244dd69569b8be33ec",
  "fixes": [
    {
      "item": "h1-budget-completion-health-contract：限时前缀被C2/G2误报为错误及缓存完成身份混用",
      "commit": "c40e43fd25c200a01f4da94a4dac8db1b34664a8",
      "test": "agent/tests/global-build.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；已修启动租约和retention窄项不代表删除归属、扫描竞态或整体容量根因已解决，沿原链保留失败，不放松隔离或回收守卫。"
    },
    {
      "item": "selection-hidden-daggers-conditional-followup-readback",
      "reason": "策略链；已有独立提案silent-proposal-59b2e430bb7521d4，注册记录仍为pending，按任务1.4沿独立strategy-proposal处理，未重复领取或实现。"
    },
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（含silent-0308/0365/0481/0487/0496）",
      "reason": "策略类；保留既有strategy-proposal链和限定范围，不在普通纯bug批次补游戏知识或重复派发。"
    },
    {
      "item": "silent-0332实际nonpositive-hp资源契约根因",
      "reason": "证据不足，沿原0332/5aa2672 owner；本批的合成测试回执不代表真实根因已修，不改正HP或300样本门槛。"
    },
    {
      "item": "arch-funnel-guard/arch-learning-priority/arch-unified-resource-value/inv-f33-regression及调度公平性调查",
      "reason": "独立策略、架构及归因任务，沿原任务；本普通批次不扩功能或调整规则。"
    },
    {
      "item": "core-build-notify-222802-rc2原生通知恢复",
      "reason": "旧失败回执缺stderr，当前CLI参数合法，不能确认未送达；证据不足，保留旧失败且未重发通知。"
    },
    {
      "item": "codex缓存实测、DPR性能及历史宿主超时根因",
      "reason": "证据不足/独立性能调查；离线不调用真实模型，不将固定夹具改进或单项补验当产品性能根因闭环。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4311
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261017-113248-21eed063-e1c9-46ab-b098-5360b36adf9b-fix-batch/report.md"
}
```

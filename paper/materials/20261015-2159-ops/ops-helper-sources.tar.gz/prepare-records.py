from pathlib import Path
import json,hashlib,subprocess,tarfile,re,os,importlib.util
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-2159';pub=r/'paper/materials/20261015-2159-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def load(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
bid='20261015-214302-strategy-proposal';b=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[]
assert b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(row['state']=='waiting' for row in report['proposal_results'])
assert report['fixes']==report['implementation_domains']==report['skipped']==[] and report['merged'] is None and all(value is None for value in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
final=load(s/'completion-validation.json');assert final['base']==report['base'] and final['tracked_status']=='' and final['source_diff_bytes']==0
assert final['proposal_results']==10 and final['all_waiting'] and final['ledger_trace_items']==32 and final['ledger_protected_fields_unchanged']
assert final['consumer_cli_exit_codes']==[0]*5 and final['material_assertions']==61 and all(final[key] is None for key in ['tsc','vitest','cases'])
for name,key in [('report.md','report_sha256'),('proposal.md','proposal_sha256'),('final.json','final_json_sha256')]:assert sha((s/name).read_bytes())==final[key]
assert (s/'source-diff.patch').read_bytes()==b''
originals=load(s/'proposal-original-check.json');assert len(originals)==10 and {row['id'] for row in originals}==set(report['code_proposals'])
for row in originals:
 path=Path(row['path']).resolve();assert path.is_relative_to(r);raw=path.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
evidence=load(s/'evidence-review.json');assert evidence['source_rows_verified']==6606 and evidence['six_stream_rows']==6601
assert sum(row['rows'] for row in evidence['streams'])==6606 and all(sum(row['counts'].values())==row['rows'] for row in evidence['streams'])
supplement=load(s/'supplemental-review.json');checks=evidence['checks']+supplement['material_checks'];assert len(checks)==61 and all(row['actual']==row['expected'] for row in checks)
identities=[row for row in checks if row['name'].startswith('角色进阶:')];assert len(identities)==5 and all(row['actual']==['SILENT',10] for row in identities)
consumers=load(s/'consumer/results.json');summary=load(s/'consumer/summary.json');assert len(consumers)==len(summary)==5 and all(row['exit_code']==0 for row in consumers)
for row in consumers:assert sha((s/'consumer'/(row['run']+'.audit.json')).read_bytes())==row['output_sha256']
for row in evidence['consumer_inputs']:assert sha((s/'consumer'/(row['run']+'.input.json')).read_bytes())==row['input_sha256']
assert sum(row['segments'] for row in summary)==255 and sum(row['turns'] for row in summary)==218 and all(row['actual_full_known']==0 for row in summary)
assert sum(row['turn_status'].get('observed_turn_endpoints',0) for row in summary)==135 and sum(row['turn_status'].get('unknown',0) for row in summary)==83
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['files'])==21;equal=0
for row in source['files']:
 a=git('show',report['base']+':'+row['path']);z=git('show',source['live']+':'+row['path']);assert sha(a)==row['base_sha256'] and sha(z)==row['live_sha256']
 assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai');assert row['live_worktree_equals_commit'];equal+=a==z
assert equal==18
ancestry=[(commit,row) for commit,row in source['narrow_sources'].items()]
ancestry += [(row['commit'],row) for rows in source['live_blame_sources'].values() for row in rows]
for commit,row in ancestry:
 for target,key in [(report['base'],'base_ancestor'),(source['live'],'live_ancestor')]:
  result=subprocess.run(['git','merge-base','--is-ancestor',commit,target],capture_output=True);assert result.returncode in [0,1] and (result.returncode==0)==row[key]
assert source['narrow_sources']['f34700874c9f48b614991f769532115a0f24f27b']['live_ancestor'] is False
inputs=[json.loads(raw) for raw in (s/'ledger-updates.jsonl').read_text().splitlines()];owned=[];owned_refs=[];offset=0
for number,raw in enumerate((r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True),1):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(key)==value for key,value in item.items()) for item in inputs):owned.append(raw);owned_refs.append(dict(id=row['id'],line=number,offset=offset,bytes=len(raw),sha256=sha(raw)))
 offset+=len(raw)
assert len(inputs)==len(owned)==32 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned)
readback=load(s/'ledger-readback.json');assert readback['cli_exit_code']==0 and readback['protected_fields_unchanged'] and readback['trace_links_read_back']==32 and len(readback['rows'])==32
for row in readback['rows']:
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as handle:handle.seek(row['offset']);raw=handle.read(row['bytes'])
 assert sha(raw)==row['sha256'] and raw in owned
ids=(s/'ledger-update.stdout.log').read_text().split();assert len(ids)==32 and set(ids)=={json.loads(raw)['id'] for raw in owned}
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('ops_owned_ledger',r/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fold=lambda raw:module.fold([(i,json.loads(line)) for i,line in enumerate(raw.splitlines(),1) if line]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 assert {k:v for k,v in before[ident].items() if k not in ['where','notes','history']}=={k:v for k,v in after[ident].items() if k not in ['where','notes','history']},ident
 for key,values in before[ident]['where'].items():assert all(value in after[ident]['where'][key] for value in values)
assert load(s/'gitleaks.json')==load(s/'gitleaks-final.json')==[] and final['gitleaks_exit_code']==0 and load(s/'gitleaks-result.json')['exit_code']==0
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,native=native,canonical_no_change_gate=b['no_change_proposals'],original_completion=final,ten_original_proposal_shas_verified=True,source21_base_and_pinned_live_sha_verified=True,source18_equal3_historical_name_comments=True,original_source_ancestry_flags_verified_including_nonancestor_branch=True,original_evidence_rows=6606,original_six_stream_rows=6601,original_material_assertions=61,original_offline_consumers=consumers,original_consumer_summary=summary,original_consumer_input_output_shas_verified=True,material_probes_reexecuted=False,owned_trace_only_ledger_rows=32,owned_ledger_byte_refs=owned_refs,protected_fold_preserved=True,native_gap='Ops verified actual Sol6.1/xhigh/input/lease/workspace-write/no-network. Original learner did not independently read native context; historical records unchanged.',limits=['Original255 segments/218 turn windows:135 observed endpoints and83 unknown, full candidate results all uncertified.','Question279852 superseded by279854 after draw/discard; no whole-plan attribution.','RC first3-turn2-sample plan4 and last5-turn24-sample originalplan10/SLplan1 remain separate; plan1/4 saturation belongs only to the last question.','Original initial/final report and process logs retained; no current source, transpilation, product test, controlled calibration, whole-fight benefit or broad-parent completion claim.','Resource sources and generation/temporary effects remain incomplete; five observed runs do not revalidate original112/73-run historical denominators.'],no_source_tests_merge_release_dataset_or_game_actions=True))
files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<350000 and f.suffix in ['.json','.jsonl','.md','.py','.patch','.txt','.stdout','.stderr','.exit','.log']];files+=[Path(row['path']) for row in originals]+[s/'evidence/evidence-manifest.json',s/'consumer/results.json',s/'consumer/summary.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']];refs=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted(files):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);refs.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',refs)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
line=f'\n- {at} 运维codex：2159原214302策略done0/no-source处置核，十项waiting，a24干净WT无新源码提交/合入、testsnull/mergednull/域空，不空合/发号/补测。原五Silent A10六流6601行另5runs身份共6606、61材料断言与五次既有离线审计为原学习者读回，输入输出SHA核，不重跑或当生产测试/策略收益。21叶旧livefe646265逐SHA核18同3历史Roy-Dai注释差，三窄源与实际blame祖先核；f347旧分支真实非base/live祖先保持，不拿它作上线凭据。32原CLI仅where/note，逐原输入/输出ID及offset/bytes/SHA核，私有fold全部非追溯字段不变/旧where保留，不重复CLI。实际native Sol6.1/xhigh/input/lease与workspace-write/no-network补核，原未读native及历史high文字不改。原255问题段/218轮窗仅135已知端点83未知、完整候选全未认证；BTS抽弃重问不沿用旧best，RC首3轮2样本plan4、末5轮24样本原Jevplan10与SLplan1分列，不作同预算整战。原initial/final及准备日志留史，受控后继/能力累计/逐源资源与旧112/73局范围仍缺，不据窄修关闭宽父。无新知识/反证/源码/复盘，不刷新论文、不改当前局/账号home模型预算队列prompt；仅提交本人记录及32所属追溯行，保并行脏记录，不等待未来事件。证据paper/materials/20261015-2159-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原214302十项继续waiting，32条CLI仅补追溯且保护原知识/状态/版本；原6606行、61材料断言及五次有限离线审计已读回。无源码/合入/行为号，不重复研究或补测，原宽父继续。回执paper/materials/20261015-2159-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'prepare-records.py',p/'make-helper.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers);write(pub/'completion.json',{'at':at,'batch':bid,'waiting':10,'own_ledger_rows':32,'new_to_HEAD_rows':len(added.splitlines()),'protected_ledger_fields_preserved':True,'no_source_tests_merge_release_or_dataset':True,'native_model_and_original_sandbox_verified':True,'parallel_records_preserved':True})
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
entries=[];dest=p/'final-files'
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':entries})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
print(json.dumps({'waiting':10,'owned_ledger_rows':32,'native_verified':True,'ledger_check':0,'paths':len(entries)}))

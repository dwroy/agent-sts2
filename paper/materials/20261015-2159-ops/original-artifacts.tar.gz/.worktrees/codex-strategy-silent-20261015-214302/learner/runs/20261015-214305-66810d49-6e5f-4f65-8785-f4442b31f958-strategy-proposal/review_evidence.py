"""Verify frozen evidence bytes and prepare bounded offline consumer inputs."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location('evidence_reader', WORKTREE / 'learner/extract_evidence.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
runs = json.loads((OUT / 'dispatch.json').read_text())['runs']
streams = {}
verification = []
for folder in ('evidence', 'run-identity'):
    for manifest in json.loads((OUT / folder / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        path = OUT / folder / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
        rows = []
        counts = dict.fromkeys(runs, 0)
        with open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as source:
            for encoded in path.open():
                item = json.loads(encoded)
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert reader.run_identity(item['row']) == item['run_id'] in runs
                counts[item['run_id']] += 1
                rows.append(item)
        assert counts == manifest['counts']
        streams[stream] = rows
        verification.append({'stream': stream, 'rows': len(rows), 'source_size': manifest['source_size'],
                             'counts': counts, 'output_sha256': manifest['output_sha256'],
                             'source_invalid_lines': manifest['invalid_lines'],
                             'source_incomplete_lines': manifest['incomplete_lines']})

states = {item['line']: item['row']['state'] for item in streams['states']}
decisions = {item['line']: item['row'] for item in streams['decisions']}
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})


def hp(line):
    return states[line]['run']['current_hp']


def block(line):
    return states[line]['combat']['player']['block']


def enemy(line, ident):
    return next(e for e in states[line]['combat']['enemies'] if e['enemy_id'] == ident)


def power(entity, ident):
    return next((p['amount'] for p in entity.get('powers', []) if p['power_id'] == ident), None)


def enemy_total(line):
    return sum(e['current_hp'] for e in states[line]['combat']['enemies'])


for row in streams['runs']:
    r = row['row']
    check('角色进阶:' + r['run_id'], [r['character'], r['ascension']], ['SILENT', 10])
for row in streams['states']:
    r = row['row']['state']['run']
    assert r['character_id'] == 'SILENT' and r['ascension'] == 10

check('NHA入房空手基线', [hp(283390), enemy_total(283390)], [28, 428])
check('NHA首可操作基线', [hp(283391), enemy_total(283391)], [30, 408])
check('NHA原T1挡及下轮血', [block(283396), hp(283397)], [14, 29])
check('NHA替T1挡及下轮血', [block(283506), hp(283507)], [8, 23])
check('NHA替线多损血', hp(283397) - hp(283507), 6)
check('NHA原线净扣敌血', enemy_total(283391) - enemy_total(283397), 8)
check('NHA替线净扣敌血', enemy_total(283502) - enemy_total(283507), 24)
check('NHA替线多扣敌血', enemy_total(283397) - enemy_total(283507), 16)
check('P74赢战耗血', hp(284730) - hp(284761), 44)
check('P74下战入口', hp(284766), 9)
check('P74单弃四合法项', [c['card_id'] for c in states[284817]['selection']['cards']],
      ['STRANGLE', 'NOXIOUS_FUMES', 'PRECISE_CUT', 'GREED'])
check('P74弃牌时当前资源', [hp(284817), block(284817)], [1, 16])
check('P74弃精确选择槽', decisions[278543]['chosen'], {'action': 'select_deck_card', 'option_index': 2})
check('P74精确确已离手', any(c['card_id'] == 'PRECISE_CUT' for c in states[284818]['combat']['hand']), False)
check('P74卵存活终态', [hp(284821), enemy(284821, 'BOWLBUG_EGG')['current_hp']], [0, 2])
check('RC首末同首手', states[285315]['combat']['hand'], states[285491]['combat']['hand'])
check('RC原T1资源', [hp(285315), block(285320), hp(285321)], [52, 16, 48])
check('RC替T1资源', [hp(285491), block(285496), hp(285497)], [52, 12, 44])
check('RC原净伤', enemy_total(285315) - enemy_total(285321), 30)
check('RC替净伤', enemy_total(285491) - enemy_total(285497), 23)
check('RC替多损血', hp(285321) - hp(285497), 4)
check('RC普通触媒建立', power(states[285496]['combat']['player'], 'ACCELERANT_POWER'), 1)
check('RC毒两结可见净扣', enemy(285496, 'CRUSHER')['current_hp'] - enemy(285497, 'CRUSHER')['current_hp'], 5)
check('BTS甲虫睡层', [power(enemy(i, 'SLUMBERING_BEETLE'), 'SLUMBER_POWER') for i in (286148, 286149, 286150, 286152)], [3, 2, 1, None])
check('BTS醒后成长', [power(enemy(i, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER') for i in (286163, 286170)], [2, 4])
check('BTS实际T4血挡覆甲', [hp(286173), block(286173), power(states[286173]['combat']['player'], 'PLATING_POWER')], [14, 5, 1])
check('BTS终态血与敌血', [hp(286174), enemy(286174, 'SLUMBERING_BEETLE')['current_hp']], [0, 13])
check('BTS显示入伤参考', 22 - 5 - 1, 16)

floors = {'NHA2KW0RB7VP': [33], 'P74C04AEPL1F': [17, 22, 23], 'G33HU22H2543': [31, 33, 48],
          'RC61MFQM63Y6': [17, 29, 33], 'BTSRF7JL1W1Y': [17, 31]}
inputs = []
(OUT / 'consumer').mkdir(exist_ok=True)
for run in runs:
    state_rows = [q for q in streams['states'] if q['run_id'] == run and q['row']['state']['run']['floor'] in floors[run]]
    selected = [q for q in streams['decisions'] if q['run_id'] == run and q['row'].get('floor') in floors[run]]
    good = [q for q in selected if q['row'].get('decision_id')]
    excluded = [{'line': q['line'], 'sha256': q['sha256'], 'reason': '无decision_id的元数据行'}
                for q in selected if not q['row'].get('decision_id')]
    decorated = lambda q: {**q['row'], '_line': q['line'], '_source_sha256': q['sha256']}
    item = {'run': next(q['row'] for q in streams['runs'] if q['run_id'] == run),
            'decisions': [decorated(q) for q in good], 'states': [decorated(q) for q in state_rows]}
    path = OUT / 'consumer' / (run + '.input.json')
    path.write_text(json.dumps(item, ensure_ascii=False) + '\n')
    inputs.append({'run': run, 'floors': floors[run], 'states': len(state_rows), 'decisions': len(good),
                   'excluded': excluded, 'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})

snapshots = []
for line in (283390, 283391, 283396, 283397, 283502, 283506, 283507, 284730, 284761, 284766,
             284817, 284818, 284821, 285315, 285320, 285321, 285491, 285496, 285497,
             286148, 286152, 286163, 286170, 286173, 286174):
    st = states[line]
    combat = st.get('combat') or {}
    snapshots.append({'source_line': line, 'run': st['run_id'], 'floor': st['run']['floor'],
                      'turn': st['turn'], 'hp': hp(line), 'player': combat.get('player'),
                      'hand': combat.get('hand'), 'enemies': combat.get('enemies')})
result = {'streams': verification, 'checks': checks, 'consumer_inputs': inputs,
          'source_rows_verified': sum(r['rows'] for r in verification),
          'six_stream_rows': sum(r['rows'] for r in verification if r['stream'] != 'runs')}
(OUT / 'evidence-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'key-frames.json').write_text(json.dumps(snapshots, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': result['source_rows_verified'], 'six_stream_rows': result['six_stream_rows'],
                  'material_checks': len(checks), 'consumer_inputs': inputs}, ensure_ascii=False))

"""Preserve this batch's bounded findings without changing production sources."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
batch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'assigned-proposals.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
review = json.loads((OUT / 'evidence-review.json').read_text())
more = json.loads((OUT / 'supplemental-review.json').read_text())
consumer = json.loads((OUT / 'consumer/summary.json').read_text())
details = [
    (
        '9952ee8e8df9a0fe',
        'NHA2KW0RB7VP F33 T1：states 283391–283397原线30→29、14挡、净扣敌8；283502–283507替线30→23、8挡、净扣敌24。即时多16伤且多损6血。F24/F27/F32实际回血各24；全局5次回血120。',
        '首入房283390为空手28血、敌428；首可操作283391为30血、敌408，不能混用。六次为同一局，前五为predicted_death、末次died。后轮抽牌/目标有变化，缺同条件整战胜线和能力累计回报。',
        'NHA同首手换线多16伤、多损6血已核；缺同条件整战分支、累计能力兑现及路线/休息/保药反事实，不能确定新SL或终局HP门槛。',
        '保留当前SL门槛及终局权重；将当轮模型资源差额与已结实值分列。未来用同首手、同预算、同后续条件的完整分支验证，再作独立时间后置检验。',
    ),
    (
        '47be799a87af03be',
        'P74C04AEPL1F F23末试T3：state284817为1血16挡，石16＋卵8；四合法项紧勒/毒雾+/精确切击/贪婪。decision278543选槽2，284818确认精确切击离手，284821玩家0、卵仍2血。silent-0205原repeat保留。',
        '精确切击当时显示7伤且依赖手牌；不能固定7伤推算保留分支。首试卵已提前死亡，第三试原计划不同。没有四个弃牌分支的完整实打，更没有保留贪婪后的胜局。',
        '已有后继计划失效提示和弃后手牌/费用快照；缺四个合法分支的动态伤害、逐敌目标、续步与生存结果联合回放，宽提案继续等待。',
        '保留全部合法选项及现有事实提示；不新增固定弃牌偏好。后续固定该帧核动态手牌读数、逐敌来袭和原计划取消，未实打分支始终注明反事实。',
    ),
    (
        '3a5274da3c42672a',
        'P74 F22 T1–T6：284738召21血寄生，284748为0、284749恢复21；T2/T4真实损20/24，53→9赢后F23仍9血。F17 T1火焰使182→181、滑溜8→7；T2普通触媒下12毒仅实扣2，T8滑溜清空后12毒实扣23。F23末T1首防御20挡，末T3生存者16挡。',
        '主怪末次归零中间动作缺帧；实体索引与净HP差不能复原完整需伤。石完整受挡后眩晕与卵仍攻击可同时发生；该局不提供固定击杀优先或跨战留药收益。',
        '局部召唤复活、逐敌失衡、一次翻倍和滑溜兑现已核；缺完整来源/代际、翻倍与连续用药的联合消费者验证，主怪终结中间来源缺帧。',
        '保留现有模型和药水持有规则。未来核逐敌顺序、复活代际、每次翻倍消费和用药实值；缺失阶段留未知，不以赢战净HP差拟合完整伤害。',
    ),
    (
        'bc4b92d590f2c4ce',
        'G33HU22H2543 F48 T1 decision277909：余像先/闪亮先候选分别伤75/107、挡18/10；原实线选择闪亮先。末T8 states284404–284407已建余像2层，后空翻/防御/毒药后总挡5/10/12。P74末试弃精确证据同上。',
        '六次同局SL没有实际先余像的完整胜战；药水建立能力不恢复首牌机会。候选的18挡或长期能力分数不等于实线累计收益。',
        '投斧首牌身份、普通单弃及弃牌事实已有实际live祖先源码；宽项仍缺跨重规划完整归属、余像累计兑现和动态弃牌分支联合验证。',
        '沿用现有身份修复，不重复提交。完整执行审计已读回但仍明确不认证整条候选；下一阶段须用可配对的真实续步与累计能力账核验。',
    ),
    (
        'f52fbbab4dccc3b4',
        'G33 F31 states283916→283962为83→46，耗37；F32实际46→76，F33 76→17耗59；F47 49→81，F48出牌前81→77。P74 F22赢战53→9耗44、F23以9血接战。',
        'G33六次女王只有末试实死，前五判死截断；未走路线、保留药或改休息没有同条件完整结果。当前五局不重验原提案112局历史统计分母。',
        '赢战耗血和实际下一战入口已核；缺分源资源消费者账及同条件路线/休息/SL/保药整战分支，不能从净血差拟合因果HP价格。',
        '以已发生回复和真实入口解释路线，不预支未来营火；保留现有路线和终局定价。未来分开幕间、事件、主动药水、自动回复和SL恢复后再验证。',
    ),
    (
        '10f37c0edd3d24a6',
        'P74 F17 T2尖啸使力量−6、意图14→2；下轮负力消失。F22 T4普通触媒10毒实结19、下轮雾补至11。G33 F48末T8余像2，脆弱94下两牌各总挡5，再一牌被动2；两敌各实际结毒22/42。G33全局五次实休回复133、最大血+25，四锻造不回复。',
        '当前已建能力、卡牌挡、被动挡和一次触发必须分源，不能从总挡反推每张预览持续倍数。完整遗物组合、原dirty源码和缺失中间帧未被当前树复原；同局多重打不能充作独立校准。',
        '临时减力、毒、被动挡和开场净扣有局部实帧；缺完整遗物集合、持续能力、牌挡/被动挡/翻倍与回复的联合生产回放及独立校准。',
        '不从本局重设机制参数或药水门槛；先固定逐来源消费者回放，明确未施放、未触发与未观察组合，再用新局校准。',
    ),
    (
        '3f82387e2e179703',
        'RC61MFQM63Y6 F33首/末试T1：states285315/285491同手牌，decisions279021/279197同fingerprint；原线52→48、16挡、净扣30，替线52→44、12挡、净扣23。末试触媒建1，3毒结3+2=5、余1毒。',
        '首试题面为3轮/2样本，末试为5轮/24样本；末题plan1/plan4均24/24死只成立在该题。末试Jev原答plan10并非首试plan4，SL后为plan1；原回答、替线与首试实线必须分开。后轮与抽牌未控制，无受控整战或独立胜局。',
        'RC同首手替线少7伤、多损4血成立；首末推演预算不同，缺同抽序同预算整战对照及累计能力收益，不调整保血/铺能力排序。',
        '保留现有排序；读回已有资源差额和执行审计。后续同时冻结原答、护栏后、SL后、实际动作、推演预算及后轮结果，禁止把全败并列当同资源价。',
    ),
    (
        'aee21084c991abd3',
        'BTSRF7JL1W1Y F31 T1睡层3→2→1→消失；T3/T4力量2/4、攻击20/22。decision279852原线经抽弃后在279854重问；后者plan2五轮4样本3胜1死。末T4 state286173为14HP、5挡、覆甲1，286174为0血、甲虫13。显示需损16，至少额外3血才活。',
        '3/4预测与一次死亡可并存，不能据此证明模型错误或设新保血权重。原选线在抽弃后被新题替代，不能把先前最优标签沿用到完整实线。工具未保留原逐样本抽序与动作，缺同轨迹配对。',
        '醒虫成长、覆甲和末轮资源已核；缺逐样本抽序/动作与实际最终线路配对，一次死亡不足证明模型偏差或校准权重。',
        '保持当前权重，不指定固定焦点。用新的角色内同盘、完整执行线和独立时间留出检查成长/抽弃/防御，再决定是否需要模型修正。',
    ),
    (
        'df37594e9b12debf',
        'RC F33第三试T4 states285411–285415原生存者后唯一打击离手、手空，实际朝向未按后继改变。普通单弃已有live源码修复。F17 T11 state285095持呼唤，8血、敌2血、31毒、无敌攻击；285096胜后2血，实失6。F33首末T1差额同上。',
        '普通单弃修复只覆盖已见普通版本及唯一可弃牌；多选不猜Jev。当前held_loss预测和单动作回执不认证整线。持牌失血不能仅用敌攻击解释，也不能因随后毒杀删掉。',
        '普通单弃取消唯一后继已有live源码；宽项仍缺跨重规划完整执行归属、累计能力及呼唤自损的联合消费者验收。',
        '沿用普通单弃与未知选择边界，不重复实现。后续将实际持牌、源动作、结算时点和重规划边界联合核验，未核能力不预支收益。',
    ),
    (
        '42e81c83b2e1e56b',
        'RC F24/F27/F32真实回血各21，二幕合63；F29 states285266→285303为62→31，赢战耗31；F32 31→52后进F33。全局5回血合105，两锻造不回血；五次读档恢复与真实回血分账。',
        'F27原投影不能替代F32真实52血；未来营火不计已经兑现。同存档恢复药瓶不算新得药，没有另路线/休息/保药的受控结局；本次未重算原73局房间价格统计。',
        'RC三火回63、赢战耗31与boss入口52已核；缺回复/药槽/存档事件完整分源消费者账和同条件后战反事实，不能确定新路线或终局HP价格。',
        '保留路线/休息和HP定价规则。只用实付与实回解释当前入口；将五样本房间门槛和进阶取值原样保留，待完整分源与后战配对再提改动。',
    ),
]

results = []
sections = []
for suffix, evidence, limits, reason, next_step in details:
    ident = 'silent-proposal-' + suffix
    p = proposals[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append('\n'.join([
        '## ' + ident,
        '',
        '主题：' + p['summary'] + '。处置：waiting；没有本批源码提交。',
        '',
        '账本：' + '、'.join(p['ledger']) + '。证据锚点：' + '、'.join(p['runs']) + '；直接观察均为静默A10。',
        '',
        '支持与原帧：' + evidence,
        '',
        '反例／未知：' + limits,
        '',
        '既有行为与拟议验证：' + next_step,
        '',
        '未实现原因：' + reason,
        '',
        '原件：' + p['proposal'] + '；SHA256=' + p['proposal_sha256'] + '（本批已实读同验，不覆盖）。',
    ]))

body = '\n\n'.join(sections)
intro = f'''# 静默策略批次逐项提案处置

批次：20261015-214302-strategy-proposal。来源任务为本批 strategy-proposal，实现目标仍为 strategy-proposal；已有授权 Roy-2026-10-07-learning 不提供游戏事实。

本次10项均waiting。没有足够的新隔离差额和联合消费者证据支持进一步改变策略；不新增提案id，不重复旧实现，不把窄子项完成当作宽项已完成。

身份：本批根 learn.json 为task=strategy-proposal、character=silent、reason=proposal，精确绑定当前工作树和五锚点，含原10个proposal_ids，无research_request/implementation_request/proposal_repair。普通专题文件绑定另一批次，不读取其正文研究输入、不承接专题。本批先核干净，git merge --no-edit main 返回 Already up to date。base/HEAD={source['base']}。

冻结证据：六流6601行＋runs独立5行，共6606行，逐行核原offset/bytes/SHA/JSON/显式局身份；states角色/进阶均SILENT/A10。run-plans用run字段，其他流核run_id/state.run_id/fingerprint.run，不以正文提及归属。本次各流source_size及逐局计数见evidence/evidence-manifest.json与run-identity/evidence-manifest.json。源整流无效JSON为states2/decisions2/brain1，报告保留计数，不将其推断为本批证据缺失。无截点零行缺失结论。

分析只覆盖本批五局与明确标明的战斗窗口；旧提案中的109/110/112/113局统计保持原出处，本批不冒称重验历史全量或提供独立量化校准。
'''
(OUT / 'proposal.md').write_text(intro + '\n' + body + '\n')

table = ['| 局号 | 已核身份 | 完局层 | 六流行数 |', '|---|---|---:|---:|']
run_end = {}
for line in (OUT / 'run-identity/runs.evidence.jsonl').open():
    q = json.loads(line)
    run_end[q['run_id']] = q['row']
for run in batch['runs']:
    n = sum(v['counts'].get(run, 0) for v in review['streams'] if v['stream'] != 'runs')
    table.append(f'| {run} | SILENT A10、失败 | {run_end[run]["floor"]} | {n} |')

summary = f'''# 本批策略回报

结论：10项逐项复核后全部waiting；源码和知识均未改动，未提交、未合入、未新增eval版本，未登记implemented或shipped。完整处置见[proposal.md](proposal.md)。

base/HEAD：`{source['base']}`。实际只读live快照：`{source['live']}`。本批无research/implementation请求，不使用纯研究完成字段。

{chr(10).join(table)}

原始证据总计6601行六流、另5条runs身份；偏移、字节数、逐行SHA和各流截点已保留。详细逐行复核与61项材料断言见[evidence-review.json](evidence-review.json)、[supplemental-review.json](supplemental-review.json)，不是生产单元测试或策略收益验证。game-over零血只表示实际扣血受生命上限截断，显示算式另列；同局SL不作独立样本。

## 源码与实际live边界

本批只读比较21个源码叶，18叶与live字节相同，3叶差量仅为历史Roy/Dai注释文字，patch原样保存。未为此重写源码或转译，不冒称当前组合整套测试通过；21叶live物理文件均等于该live提交中的blob。

已核本基线和实际live共同祖先：投斧首牌身份e784dd9f043bf87c29109573f48975f9903280d3；普通单弃bf423c173d3be348a4ad714e1d26516df619ff41；弃牌手牌/费用事实4b0823f519f1b724d6cff2b1cd50b74146dc4a9d。后继计划事实以实际live blame源码5b56a452bb9be14d620b368ec46974c1b57901ca核定，候选/SL资源审计以a8b1f8be153fe4f3a34146117546c2178f2e446b核定。搜索到的旧分支f34700874c9f48b614991f769532115a0f24f27b不是当前base/live祖先，不拿它作为上线凭据。各祖先查询与文件SHA见[source-audit.json](source-audit.json)。

窄修复及既有离线审计不关闭这十个宽提案，因此没有把任何一项标duplicate，也不为旧实现重复发号。silentSelectionAudit.actual_turn、single_action_receipt.whole_plan_executed以及离线actual_full_candidate_result依然保留未知，不冒称已完成归属。

## 既有消费者实际读回

用原learner/audit-selection.ts、原tsx loader在nice进程中离线读取本次冻结输入，五次均exit0，无LLM/网络/游戏调用。每份输入的原始局号、floor、decision_id、observed_ts、fingerprint、_line和_source_sha256保留；没有按过滤数组重编号，也没有无decision_id元数据需要排除。输入/输出SHA及退出码见[consumer/results.json](consumer/results.json)和evidence-review.json。

限定12个层窗口：NHA F33；P74 F17/22/23；G33 F31/33/48；RC F17/29/33；BTS F17/31。1183状态、1164决策形成255个问题段与218个轮窗口，135个轮窗口有已核端点、83个未知；255个问题段的完整候选结果均未认证。这些是既有审计的读回，不是新增源码测试或在线采用证明。

BTS decision279852经抽弃后被279854重问题替代，原最优不能沿用为整线归属。RC首试279021为3轮/2样本，末试279197为5轮/24样本；末题plan1/plan4同为24/24死，只能说明该题饱和。首试实线为plan4，末试Jev原答plan10、SL后plan1；同首手真实资源差额仍成立，但预算与后轮未控制，不能当同预算整战对照。详细summary见[consumer/summary.json](consumer/summary.json)。

实际营火回复独立核：NHA五回血120；P74两回血42；G33五回血133/上限+25；RC五回血105（其中F24/27/32合63）；BTS两回血42。原帧与choice见rest-observations.json。SL恢复、药瓶恢复不计新增治疗或新得药；不从这些观察重设路线价格。

## 验证、记录和完成边界

没有生产源码改动：tsc/vitest/cases均null，未运行生产测试，不做撤源码负控或声称红绿。本批61项固定材料断言和5次既有离线消费者读回只核证据与已有工具；不借旧批测试绿。

已有32个账本条目只经根learner/ledger.py update补本批proposal/report追溯和waiting理由；不创建重复经验或提案，不重复复盘，不改旧claim/evidence/首证/prior/status/version，不将旧shipped退回proposed。CLI原输入、输出、退出码和保护字段核验单独保留。代码提案队列由完成事件逐项消费本报告，不手写状态、不另建重复id。

没有实际上线，因此不新增decision-log部署行、eval版本或Roy规则双通知；不触碰live知识刷新、合并锁、运维prompt与其他角色行为。未独立读取当前原生运行会话元数据，不据历史run-config声称本会话模型/强度；未改模型设置。

报告和所有初稿/原件留在本批scratch；工作树应保持干净且HEAD等于上述完整base。终态以completion-validation.json和final.json为准。所有waiting继续保留，等待具体缺失的后继/分源/独立校准证据，不能以本报告关闭学习父要求。

## 逐项依据与验证要求

{body}
'''
(OUT / 'report.md').write_text(summary)

final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-214302-strategy-proposal',
         'base': source['base'], 'runs': batch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': batch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'final.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
ledgers = json.loads((OUT / 'ledger-before.json').read_text())
updates = []
for ident in sorted(ledgers):
    related = [r for r in results if ident in proposals[r['id']]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261015-214302-strategy-proposal：原提案逐项核证，未改源码/知识，tests=null、merged=null；'
                            + '；'.join(r['id'] + '=waiting：' + r['reason'] for r in related)
                            + '。只补追溯，不新增游戏claim/evidence/status、实现或shipped。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in updates))
assert len(results) == len(batch['proposal_ids']) == 10
assert len(updates) == 32
assert sum(v['states'] for v in review['consumer_inputs']) == 1183
print(json.dumps({'report': str(OUT / 'report.md'), 'proposals': len(results), 'ledger_updates_prepared': len(updates)}, ensure_ascii=False))

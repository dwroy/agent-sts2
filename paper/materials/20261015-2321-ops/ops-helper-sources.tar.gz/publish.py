from pathlib import Path
import json,hashlib,subprocess,os,fcntl,re
r=Path.cwd();live=r/'.worktrees/live';p=r/'ops/codex-ops/record-staging/20261015-2321';pub=r/'paper/materials/20261015-2321-ops';sha=lambda b:hashlib.sha256(b).hexdigest();source='d3e57c77ef32346af9f59494914bcf2bce2de4ec';base='7f6646a68cf8be641e0abfe93d4987e8ef610f98'
def git(*a,cwd=r,env=None,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],env=env,input=data,stderr=subprocess.PIPE)
def blob(head,path,cwd=r):
 v=subprocess.run(['git','-C',str(cwd),'show',head+':'+path],capture_output=True);assert v.returncode in [0,128];return v.stdout if v.returncode==0 else None
def stage(path,raw,env,cwd):
 oid=git('hash-object','-w','--stdin',cwd=cwd,data=raw).decode().strip();git('update-index','--add','--cacheinfo','100644',oid,path,cwd=cwd,env=env)
def commit(tree,parents,title,cwd):
 args=['commit-tree',tree]
 for parent in dict.fromkeys(parents):args+=['-p',parent]
 return git(*args,cwd=cwd,data=(title+'\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n').encode()).decode().strip()
def install(cwd,path,raw):
 f=cwd/path;f.parent.mkdir(parents=True,exist_ok=True);tmp=f.with_name(f.name+'.ops-poison.tmp');assert not tmp.exists();tmp.write_bytes(raw);os.replace(tmp,f)
def locks_for(items):
 locks=[]
 try:
  for cwd,env in items:
   idx=Path(git('rev-parse','--git-path','index',cwd=cwd).decode().strip());idx=idx if idx.is_absolute() else cwd/idx;lp=Path(str(idx)+'.lock');fd=os.open(lp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
   with os.fdopen(fd,'wb') as out:out.write(Path(env['GIT_INDEX_FILE']).read_bytes());out.flush();os.fsync(out.fileno())
   locks.append((idx,lp))
  return locks
 except:
  for _,lp in locks:lp.unlink()
  raise
assert not (pub/'publication.json').exists();readback=json.loads((pub/'strategy-readback.json').read_text());assert readback['source_checks']['exit_code']==0
paths=git('diff-tree','--no-commit-id','--name-only','-r',source).decode().splitlines();assert set(paths)==set(['agent/src/reflex/card-model.ts','agent/tests/silent-pounce-coverage-evidence.json','agent/tests/silent-pounce-coverage.test.ts'])
with (r/'ops/live-merge.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True);mh=git('rev-parse','HEAD').decode().strip();lh=git('rev-parse','HEAD',cwd=live).decode().strip();assert lh=='e1e7ee853b627919a6d1eab51c0cdf263b0bb852'
 active=subprocess.run(['pgrep','-f','/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'],capture_output=True);assert active.returncode==1
 for cwd in [r,live]:assert not git('diff','--cached','--name-only',cwd=cwd).strip() and not git('ls-files','-u',cwd=cwd).strip()
 rootvalues={};livevalues={};leaves=[]
 for path in paths:
  parent=blob(base,path);desired=blob(source,path);oldmain=blob(mh,path);oldlive=blob(lh,path,live);assert oldmain==parent;assert ((r/path).read_bytes() if (r/path).exists() else None)==oldmain;assert ((live/path).read_bytes() if (live/path).exists() else None)==oldlive
  rootvalues[path]=desired
  if parent is None:assert oldlive is None;new=desired
  elif oldlive==parent:new=desired
  else:
   assert path=='agent/src/reflex/card-model.ts' and oldlive.decode().replace('Dai','Roy')==parent.decode().replace('Dai','Roy');folder=p/'merge-input';folder.mkdir(exist_ok=True)
   for n,b in [('live',oldlive),('base',parent),('source',desired)]:(folder/n).write_bytes(b)
   merged=subprocess.run(['git','merge-file','--stdout',str(folder/'live'),str(folder/'base'),str(folder/'source')],capture_output=True);assert merged.returncode==0;new=merged.stdout;assert new.decode().replace('Dai','Roy')==desired.decode().replace('Dai','Roy')
  livevalues[path]=new;leaves.append({'path':path,'source_sha256':sha(desired),'live_sha256':sha(new),'main_exact_source':True,'historical_comment_difference_only':new!=desired})
  for lane,raw in [('main',desired),('live',new)]:f=p/'composition-scan'/lane/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
 refresh={}
 for path in git('diff','--name-only','HEAD','--','knowledge',cwd=live).decode().splitlines():
  raw=(live/path).read_bytes();refresh[path]=raw;f=p/'composition-scan'/'knowledge'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
 with (pub/'composition-gitleaks.log').open('wb') as out:scan=subprocess.run(['nice','-n','19','gitleaks','dir',str(p/'composition-scan'),'--redact','--no-banner','--report-format','json','--report-path',str(p/'composition-gitleaks.json')],stdout=out,stderr=subprocess.STDOUT,env={**os.environ,'GOMAXPROCS':'1'}).returncode
 assert scan==0 and json.loads((p/'composition-gitleaks.json').read_text())==[]
 datasets={}
 for cwd,head in [(r,mh),(live,lh)]:
  raw=blob(head,'eval/versions.json',cwd);assert (cwd/'eval/versions.json').read_bytes()==raw;datasets[str(cwd)]=json.loads(raw)
 assert datasets[str(r)]['release_numbering']['releases']==datasets[str(live)]['release_numbering']['releases'];previous=datasets[str(r)]['release_numbering']['releases'];nums=[int(re.fullmatch(r'V\d+-R(\d+)',x['release_id'])[1]) for x in previous];assert nums==list(range(max(nums)+1));rid=f'V5-R{max(nums)+1:03d}';name='V5.silent-pounce-coverage1'
 le={**os.environ,'GIT_INDEX_FILE':str(p/'live.index')};git('read-tree',lh,env=le,cwd=live)
 for path,raw in refresh.items():stage(path,raw,le,live)
 rt=git('write-tree',env=le,cwd=live).decode().strip();fresh=commit(rt,[lh],'Preserve live knowledge refresh before observed Pounce coverage disclosure',live) if refresh else lh
 for path,raw in livevalues.items():stage(path,raw,le,live)
 bt=git('write-tree',env=le,cwd=live).decode().strip();assert set(git('diff','--name-only',rt,bt,cwd=live).decode().splitlines())==set(paths);behavior=commit(bt,[fresh,source],'Publish observed Silent Pounce coverage disclosure',live)
 entry={'name':name,'family':'V5','character':'SILENT','commit':behavior,'release_id':rid,'release_status':'registered-primary-ops','source':at+'; original20261015-224302-strategy-proposal source '+source+'; silent-proposal-89354805ee4d7e77/283a164780d11e69; ledger silent-0237/0238. VLZ6CCT8AQ0A Silent A10 F35T2/F37T3/F43T5 observed upgraded Pounce exact previews21/23/16,2energy,unmodified template. Old damage-only known flag hid unmodelled FREE_SKILL_POWER; new matching model retains attack numbers/cost and flags coverage unknown. No free-cost propagation implementation or game-benefit claim; three pairs in one run are not independent samples. Other roles/ascensions/unobserved previews and existing HP/SL/potion/ranking rules retained. Fixed withdrawn3fail1pass/restored4pass, source tsc0/sandbox436files4093+paths11/gitleaks0; source full not rerun. Original failed/rc0/mergednull and six record conflicts retained. Three source leaves narrowly integrated, current live knowledge/configuration/historical comments and R363 retained. Actual new-tree host once and natural consumer pending; all ten wide proposals remain waiting. Rollback only these three source leaves with a current-context inverse patch, preserving other releases and knowledge. Evidence paper/materials/20261015-2321-ops/.'};versions={}
 for key,data in datasets.items():
  before=json.loads(json.dumps(data['versions']));assert not any(x['name']==name for x in before);data['versions'].append(entry);data['release_numbering']['releases'].append({'release_id':rid,'commit':behavior,'aliases':[name]});assert data['versions'][:-1]==before;versions[key]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
 stage('eval/versions.json',versions[str(live)],le,live);ft=git('write-tree',env=le,cwd=live).decode().strip();final=commit(ft,[behavior],f'Register observed Pounce coverage as {rid}',live)
 me={**os.environ,'GIT_INDEX_FILE':str(p/'main.index')};git('read-tree',mh,env=me)
 for path,raw in rootvalues.items():stage(path,raw,me,r)
 stage('eval/versions.json',versions[str(r)],me,r);mt=git('write-tree',env=me).decode().strip();mn=commit(mt,[mh,source],f'Integrate exact observed Pounce coverage and record {rid}',r)
 rec={'at':at,'source':source,'source_parent':base,'source_checks':readback['source_checks'],'old_main':mh,'main':mn,'old_live':lh,'knowledge_refresh_commit':fresh,'knowledge_refresh':[{ 'path':path,'sha256':sha(raw)} for path,raw in refresh.items()],'name':name,'release_id':rid,'behavior_commit':behavior,'behavior_tree':bt,'actual_live':final,'tree':ft,'leaves':leaves,'original_completion_preserved':readback['original_completion'],'original_conflicts_preserved':readback['original_conflicts']['conflicts'],'original10wideproposals':'waiting; narrow source publication does not close them','R359_R360_full':'passed exact24de only; not proof for this new tree','new_host':'pending single original224302-strategy-proposal channel request','natural_consumer':'pending','current_game_account_home_model_prompt_changed':False};(p/'intended-publication.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');locks=locks_for([(r,me),(live,le)])
 try:
  assert git('rev-parse','HEAD').decode().strip()==mh and git('rev-parse','HEAD',cwd=live).decode().strip()==lh
  for path,raw in refresh.items():assert (live/path).read_bytes()==raw
  git('update-ref','-m','ops: exact bounded learner source fallback','HEAD',final,lh,cwd=live)
  for path,raw in livevalues.items():install(live,path,raw)
  install(live,'eval/versions.json',versions[str(live)]);git('update-ref','-m','ops: integrate original tested Pounce coverage','HEAD',mn,mh)
  for path,raw in rootvalues.items():install(r,path,raw)
  install(r,'eval/versions.json',versions[str(r)])
  for idx,lp in locks:os.replace(lp,idx)
 finally:
  for _,lp in locks:
   if lp.exists():lp.unlink()
 for cwd in [r,live]:
  assert not git('diff','--cached','--name-only',cwd=cwd).strip();git('merge-base','--is-ancestor',source,'HEAD',cwd=cwd)
 for path in ['agent/src/core/config.ts','agent/src/reflex/combat-plan.ts','agent/src/reflex/turn-solver.ts','agent/src/sim/silent-opening.ts']:assert blob(lh,path,live)==blob(final,path,live)
 rec['source_actual_main_live_ancestor']=True;rec['R355_R360_and_other_live_source_preserved']=True;(pub/'publication.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'published':True,'release_id':rid,'live':final,'tree':ft,'main':mn,'source_ancestor':True,'refresh':len(refresh)}),flush=True)

from pathlib import Path
import hashlib, json, re, subprocess
root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2321'; pub=r/'paper/materials/20261015-2321-ops'; pub.mkdir(exist_ok=True); sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=r): return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
bid='20261015-224302-strategy-proposal'; b=load(r/'ops/codex-ops/learn.json')['batches'][bid]; report=b['report']; s=Path(report['report']).parent; source=report['fixes'][0]['commit']; parent=report['fixes'][0]['source_parent']
assert b['state']=='failed' and b['rc']==0 and b['proposal_audit_errors']==[] and report['merged'] is None
assert len(report['fixes'])==1 and len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==source and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
assert git('rev-parse',source+'^').decode().strip()==parent==report['base']
paths=git('diff','--name-only',parent,source).decode().splitlines(); assert set(paths)=={'agent/src/reflex/card-model.ts','agent/tests/silent-pounce-coverage-evidence.json','agent/tests/silent-pounce-coverage.test.ts'}
checks=load(s/'source-checks.json'); log=(s/'source-sandbox.log').read_bytes(); assert checks['exit_code']==checks['tsc']==checks['vitest']==0 and checks['sandbox_workers']==1 and sha(log)==checks['log_sha256']
assert b'436 passed (436)' in log and b'4093 passed (4093)' in log and b'11 passed (11)' in log
assert sha(git('show',source+':agent/src/reflex/card-model.ts'))==checks['red_green']['source_restored_sha256']
assert checks['red_green']['withdrawn']==1 and checks['red_green']['restored']==0
assert '3 failed' in (s/'pounce-withdrawn.log').read_text() and '4 passed (4)' in (s/'pounce-restored.log').read_text()
assert load(s/'gitleaks-staged.json')==[] and load(s/'gitleaks-staged-exit.json')['exit_code']==0
manifest=load(s/'artifact-manifest.json'); refs={x['path']:x for x in manifest}; verified=[]
for name in ['source-checks.json','source-sandbox.log','pounce-withdrawn.log','pounce-restored.log','proposal.md','report.md','ledger-updates.jsonl','ledger-verification.json','evidence-verification.json','material-checks.json','source-readback.json']:
 if name in refs:
  raw=(s/name).read_bytes(); x=refs[name]; assert len(raw)==x['bytes'] and sha(raw)==x['sha256']; verified.append(name)
for x in load(s/'original-proposal-manifest.json'):
 for key in ['original_path','copy']:
  f=Path(x[key]); assert f.resolve().is_relative_to(r); raw=f.read_bytes(); assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
fixture=json.loads(git('show',source+':agent/tests/silent-pounce-coverage-evidence.json')); assert fixture['run']=='VLZ6CCT8AQ0A' and fixture['character']=='silent' and fixture['ascension']==10 and len(fixture['cases'])==3; rawrefs=[]
for case in fixture['cases']:
 for key,x in zip(['before','after'],case['source']):
  assert x['stream']=='states'
  with (r/'logs/states.jsonl').open('rb') as f: f.seek(x['offset']); raw=f.read(x['bytes'])
  assert sha(raw)==x['sha256']; row=json.loads(raw); state=row['state']; assert state['run_id']==fixture['run'] and state['run']['character_id']=='SILENT' and state['run']['ascension']==10 and state['combat']==case[key]; rawrefs.append(x)
evidence=load(s/'evidence-verification.json'); assert evidence['verified_source_rows']==sum(evidence['stream_counts'].values())==6995 and not evidence['decision_state_missing']; assert load(s/'material-checks.json')['count']==20
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()]; owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 x=json.loads(raw)
 if x.get('op')=='update' and any(all(x.get(k)==v for k,v in update.items()) for update in inputs): owned.append(raw)
assert len(inputs)==len(owned)==26 and all(set(json.loads(raw))<={'op','id','ts','by','where','note','status'} and ('status' not in json.loads(raw) or (json.loads(raw)['id'] in ['silent-0237','silent-0238'] and json.loads(raw)['status']=='proposed')) for raw in owned); (p/'owned-learner-ledger.jsonl').write_bytes(b''.join(owned))
assert set((s/'ledger-cli.log').read_text().split())=={x['id'] for x in inputs}; lv=load(s/'ledger-verification.json'); assert lv['updates']==26 and lv['cli_exit']==0 and lv['non_trace_fields_unchanged'] and lv['shipped_updates']==0
conflicts=load(s/'live-merge-receipt.json'); assert len(conflicts['conflicts'])==6 and conflicts['abort_exit']==0 and conflicts['initial_head']==conflicts['final_head'] and conflicts['initial_status']==conflicts['final_status'] and conflicts['merged'] is None
readback=dict(batch=bid,original_report=report,source=source,source_parent=parent,source_checks=dict(tsc=0,sandbox_files=436,sandbox_cases=4093,paths_cases=11,total=4104,exit_code=0),original_checks=checks,native=native,source_three_leaves=paths,raw_fixture_refs_verified=rawrefs,verified_material_artifact_names=verified,original_artifact_manifest_sha256=sha((s/'artifact-manifest.json').read_bytes()),artifact_manifest_scope='Selected original reports, proofs and logs only; unrelated generated sandbox credential-shaped fixtures were not read.',original_evidence_rows=6995,original_material_checks=20,owned_learner_trace_rows=26,original_conflicts=conflicts,original_completion=load(s/'final-verification.json'),limits=['Only observed Silent A10 upgraded Pounce exact previews16/21/23 are marked unmodelled; damage/cost/rollout and legal candidates are retained. No missing free-cost behavior implementation or game-benefit claim.', 'Three frames are one VLZ run; not independent calibration. Other characters/ascensions and unobserved previews keep original source behavior.', 'Historical183 accepted Codex brain requests used high; current learner native context is xhigh. Neither history nor permissions changed.', 'Ten wide original proposals remain waiting. Existing Apotheosis/SL/source-identity/sampling calibration gaps are not closed by this disclosure.', 'Original noncombat TypeError, wrong relative path with shell-tail masking exit, obsolete paths, red fixtures and six record conflicts retained.'])
write(pub/'strategy-readback.json',readback); print(json.dumps(dict(source=source,full_source=4104,raw_frames=6,learner_rows=26,conflicts=6,native_verified=True)))

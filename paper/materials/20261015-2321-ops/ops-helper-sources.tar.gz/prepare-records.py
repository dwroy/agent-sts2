from pathlib import Path
import fcntl, hashlib, importlib.util, json, os, subprocess, sys, tarfile
r=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261015-2321'; pub=r/'paper/materials/20261015-2321-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],stderr=subprocess.PIPE)
assert not (p/'own-appends.json').exists(); base=git('rev-parse','HEAD').decode().strip(); d=load(pub/'publication.json'); readback=load(pub/'strategy-readback.json'); assert base==d['main'] and not git('diff','--cached','--name-only').strip()
bid=readback['batch']; original=readback['original_report']; s=Path(original['report']).parent; at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
updates=[{'id':ident,'by':'ops:codex','where':{'commits':[d['source'],d['behavior_commit'],d['actual_live']]},'note':f'{at} {d["release_id"]}/{d["name"]}原神化宽提案89354805/283a1647仅猛扑+覆盖未知提示窄子项已实际main/live源祖先；三叶保现有知识/R363/历史注释，VLZ同局三对原帧，Silent A10精确21/23/16预览标FREE_SKILL_POWER未建模，伤害与2能成本不变，不实现免费传播或改玩法。原撤3红1绿/恢复4绿、源4093+paths11/tsc0及合后4固定0；新树原通道一次host已请求、结果与自然消费者pending。只补where/note，不改旧claim/证据/首证/prior/status/经验version，原failed/rc0/mergednull和六冲突保留、十宽项waiting。回执paper/materials/20261015-2321-ops/。'} for ident in ['silent-0237','silent-0238']]
ledger=r/'paper/materials/learning/ledger.jsonl'; before=ledger.stat().st_size; (pub/'ledger-input.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates)); result=subprocess.run(['python3','learner/ledger.py','update','--character','silent'],input=(pub/'ledger-input.jsonl').read_text(),capture_output=True,text=True); (pub/'ledger-update.log').write_text(result.stdout+result.stderr); assert result.returncode==0
opsrows=[raw for raw in ledger.read_bytes()[before:].splitlines(keepends=True) if any(all(json.loads(raw).get(k)==v for k,v in x.items()) for x in updates)]; assert len(opsrows)==2; (p/'owned-ops-ledger.jsonl').write_bytes(b''.join(opsrows))
follow=json.loads(json.dumps(original)); follow['merged']=d['actual_live']; follow['version']=d['release_id']; follow['ops_actual_publication']='paper/materials/20261015-2321-ops/publication.json'
for x in follow['proposal_results']:
 if x['id'] in ['silent-proposal-89354805ee4d7e77','silent-proposal-283a164780d11e69']: x['reason']=f'原source d3e57c77猛扑+未建模覆盖提示窄子项已实际live并登记{d["release_id"]}；仍缺持续施放身份、免费技能费用传播及未覆盖升级/后继校准，原宽waiting保留。新树宿主/下一自然消费者独立待验，不以此关闭父项。'
write(pub/'ops-publication-followup.json',follow); sys.path.insert(0,str(r/'ops')); import proposal_dispatch
with (r/'ops/codex-ops/learn.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); state=load(r/'ops/codex-ops/learn.json'); batch=state['batches'][bid]; ids=set(batch['proposal_ids']); owners=[k for k,v in state['batches'].items() if k!=bid and v.get('state')=='running' and ids & set(v.get('proposal_ids',[]))]; core={k:batch.get(k) for k in ['state','rc','merged','report','finished','pid']}
 if owners: queue_stage='publication followup pending existing overlapping owner; no frozen input changed'
 else:
  errors=proposal_dispatch.links(follow,batch,str(r),str(r/'ops')); assert errors==[],errors; proposal_dispatch.resolve(follow,batch,str(r),str(r/'ops')); queue_stage='original ten waiting dispositions kept; two narrow publication provenance reasons appended'
 actual=load(r/'ops/codex-ops/learn.json')['batches'][bid]; assert {k:actual.get(k) for k in core}==core
write(pub/'registration-followup.json',dict(at=at,ledger_cli_rows=2,only_where_note=True,original_batch_completion_preserved=core,queue_stage=queue_stage,overlapping_running_owners=owners,wide10proposals='waiting',natural_consumer='pending',new_parent_or_other_role_ack=False))
old=git('show',base+':paper/materials/learning/ledger.jsonl'); learnerrows=(p/'owned-learner-ledger.jsonl').read_bytes().splitlines(keepends=True); rows=learnerrows+opsrows; existing=set(old.splitlines()); added=b''.join(raw for raw in rows if raw.rstrip(b'\n') not in existing); assert len(learnerrows)==26 and len(added.splitlines())==28
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(a)==set(z)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
 assert z[ident]['history'][:len(a[ident]['history'])]==a[ident]['history']
 for key,items in a[ident]['where'].items(): assert all(x in z[ident]['where'][key] for x in items)
readback.update(ops_initial_guard_failure='Initial guard rejected two explicit status=proposed rows. Both exact IDs0237/0238 remain proposed before/after fold; all other protected fields and old histories/where preserved. Original26 CLI rows and failed guard retained without rewriting or duplicate CLI.',learner_row_scope='24 where/note rows plus2 where/note/status=proposed idempotent rows; not falsely described as26 status-free rows',ops_publication_provenance_rows=2,protected_fold_verified=True); write(pub/'strategy-readback.json',readback)
req=load(pub/'new-host-request.json'); checklog=Path(req['expected_log']); host=dict(request=req,stage='original request launched; full result pending')
if checklog.exists():
 logs=subprocess.check_output(['lslocks','--noheadings','--output','PID,COMMAND,PATH'],text=True).splitlines(); workers=[line.split()[0] for line in logs if line.endswith(str(r/'ops/live-merge.lock'))]
 if len(workers)==1:
  worker=workers[0]; stat=Path('/proc',worker,'stat').read_text(); raw=checklog.read_bytes(); assert b' RUN ' in raw; host.update(stage='actual original host full running; result pending',worker_pid=int(worker),birth=stat[stat.rfind(')')+2:].split()[19],log_prefix_bytes=len(raw),log_prefix_sha256=sha(raw),live_lock_owned=True)
write(pub/'host-start.json',host)
pending=dict(at=at,batch=bid,source=d['source'],main=d['main'],actual_live=d['actual_live'],tree=d['tree'],release_id=d['release_id'],behavior_commit=d['behavior_commit'],three_leaves=d['leaves'],original_completion='failed/rc0/mergednull and six-record conflicts preserved',host='paper/materials/20261015-2321-ops/host-start.json',host_result='pending',targeted=load(pub/'live-targeted.json'),natural_consumers='pending next natural matching Silent A10 Pounce coverage payload; no forced model/game requests',wide10proposals='waiting',worktree='retained until original checks/retention gates; no forced deletion'); write(pub/'publication-handoff.json',pending); write(r/'ops/codex-ops/pending-integrations'/f'{bid}.json',pending)
notice=f'\n- {at}｜规则实际上线 {d["release_id"]} / {d["name"]}：旧：已见静默A10猛扑+只因伤害已建模而known=true，免费技能效果缺口未标。新：仅VLZ原已观察升级/无附魔/2能/零星费/精确模板和21/23/16预览置known=false、记录unknownCards，伤害/成本仍按旧模型；其他角色/进阶/未观察预览维持现行行为，不新增免费传播、数值、禁选、HP/SL/药价或排序规则。证据/账本：VLZ6CCT8AQ0A F35T2、F37T3、F43T5三对原帧及0237/0238、89354805/283a1647；同局非独立校准。source{d["source"]}，原撤3红1绿/恢复4绿、源436文件4093+paths11/tsc0/gitleaks0；预期提高未建模效果可见性，不宣称策略收益或整条神化已实现。实际behavior{d["behavior_commit"]}→live{d["actual_live"]}/tree{d["tree"]}，三叶源祖先main/live绑定；回退仅这三叶当前上下文逆补丁、保现有知识/注释/R363及其他发布。原六记录冲突/failed/rc0/mergednull与十宽waiting保留。合后1文件4固定0，原224302策略通道单次宿主full已请求，结果/下一自然消费者pending；不重跑源full/当前局、不改账号home模型权限prompt。回执paper/materials/20261015-2321-ops/。\n'
decision=f'\n- {at} 运维codex：2321原224302策略source d3e57c77猛扑+未建模覆盖提示三叶自测436文件4093+paths11/tsc0/固定撤3败1过恢复4过与6原帧offset/SHA核；原六并行记录冲突已abort，failed/rc0/mergednull和初稿/探针失败原件保留，ops仅窄三叶main/live兜底并绑source真实祖先，实际{d["release_id"]}/behavior{d["behavior_commit"]}/live{d["actual_live"]}/tree{d["tree"]}，根双旧新/证据/预期/回退通知。原6995行/20材料断言为学习者有限核验，183旧脑high与本native实际Sol6.1/xhigh/default/input/lease/workspace-write/no-network分列，不重写历史或重跑材料。26原CLI含24纯追溯及0237/0238两条显式同值proposed；初ops状态字段guard误拒保留，私有fold所有非追溯字段/旧history及where全保，另原CLI补2发布来源，不伪称26均无status、不重复CLI/标shipped；十宽神化/配对/联合/整候选/SL/召唤等waiting。保所有当前配置/战斗源/知识与R363，未刷新知识或论文。合后1文件4固定0，原224302单通道一次新组合宿主请求，实际启动证据与结果pending分开、不借旧94a022绿；下一自然匹配猛扑消费者pending，不重启局/新派学习/改账号模型额度队列prompt或关闭宽父。回执paper/materials/20261015-2321-ops/。\n'
handoff=f'\n- {at} 原224302-strategy d3e57c77三叶记录冲突已由ops窄合main/live，实际{d["release_id"]}/live{d["actual_live"]}/tree{d["tree"]}，source祖先/原六冲突保留、1文件4定向0、双通知及2发布追溯齐。原通道单次宿主已请求，按后继learner-checks核精确f7335686树，不重复请求或借R363的94a绿；下一自然匹配Silent A10 Pounce未知效果payload仍pending，不人为开局/调用模型或改其他角色/账号，十宽waiting/原sourceWT继续既有检查及retention门槛。回执paper/materials/20261015-2321-ops/publication-handoff.json。\n'
appends={'notes/for-roy.md':notice,'ops/inbox-dev.md':notice,'paper/materials/decision-log.md':decision,'notes/ops-handoff.md':handoff}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<300000 and not f.name.startswith('jev-sts2-settle-')]+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); manifest.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',manifest); helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in list(p.glob('*.py'))+list(p.glob('*guard.log'))+[r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); write(pub/'completion.json',dict(at=at,batch=bid,source=d['source'],actual_release=d['release_id'],actual_live=d['actual_live'],exact_tree=d['tree'],learner_rows=26,ops_provenance_rows=2,protected_fields_preserved=True,wide10proposals='waiting',source_full=4104,live_targeted=4,host_full='single original request; result pending',natural_consumers='pending',no_source_full_rerun_or_current_game_account_prompt_change=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(paths=len(entries),ledger_rows=28,ledger_check=0,release_id=d['release_id'],queue=queue_stage,host=host['stage'])))

import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')
SOURCE = 'd3e57c77ef32346af9f59494914bcf2bce2de4ec'
BASE = '7f6646a68cf8be641e0abfe93d4987e8ef610f98'
env = os.environ.copy()
env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + env['PATH']
env['TMPDIR'] = str(OUT)
env['SANDBOX_WORKERS'] = '4'
env['npm_config_offline'] = 'true'
receipt = {'source': SOURCE, 'base': BASE, 'merged': None, 'phase': 'lock_acquired'}


def save():
    (OUT / 'live-merge-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')


def run(args, name, cwd=LIVE):
    with (OUT / (name + '.log')).open('w') as f:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT)
    return result.returncode


def git(*args):
    return subprocess.check_output(['git', *args], cwd=LIVE).decode().strip()


def scan_staged(name):
    patch = subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=LIVE)
    (OUT / (name + '.patch')).write_bytes(patch)
    with (OUT / (name + '-gitleaks.log')).open('w') as f:
        return subprocess.run(['gitleaks', 'stdin', '--redact', '--no-banner'], input=patch,
                              cwd=LIVE, env=env, stdout=f, stderr=subprocess.STDOUT).returncode


try:
    save()
    assert run(['bash', '-c', "while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done"], 'builder-wait') == 0
    receipt['initial_head'] = git('rev-parse', 'HEAD')
    receipt['initial_status'] = git('status', '--short')
    assert not git('diff', '--cached', '--name-only'), 'live已有暂存内容，保留并停止'
    own = set(git('diff', '--name-only', BASE, SOURCE).splitlines())
    refreshed = set(git('diff', '--name-only', '--', 'knowledge', 'notes/fight-value-backtest.md').splitlines())
    receipt['refreshed_overlap'] = sorted(own & refreshed)
    assert not receipt['refreshed_overlap'], '刷新知识与本批改动重叠'
    paths = ['knowledge']
    if (LIVE / 'notes/fight-value-backtest.md').exists():
        paths.append('notes/fight-value-backtest.md')
    assert run(['git', 'add', '--', *paths], 'refresh-add') == 0
    if git('diff', '--cached', '--name-only'):
        assert scan_staged('refresh') == 0, '刷新数据扫描未通过'
        assert run(['git', 'commit', '-m', 'Refresh knowledge data', '-m',
                    'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'], 'refresh-commit') == 0
    receipt['premerge'] = git('rev-parse', 'HEAD')
    receipt['phase'] = 'merge'
    save()
    receipt['merge_exit'] = run(['git', 'merge', '--no-edit', SOURCE], 'live-merge')
    if receipt['merge_exit']:
        receipt['conflicts'] = git('diff', '--name-only', '--diff-filter=U').splitlines()
        receipt['failed_status'] = git('status', '--short')
        if subprocess.run(['git', 'rev-parse', '--verify', 'MERGE_HEAD'], cwd=LIVE,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            receipt['abort_exit'] = run(['git', 'merge', '--abort'], 'live-merge-abort')
        receipt['phase'] = 'merge_blocked'
    else:
        receipt['behavior_commit'] = git('rev-parse', 'HEAD')
        receipt['behavior_tree'] = git('rev-parse', 'HEAD^{tree}')
        receipt['phase'] = 'testing'
        save()
        receipt['sandbox_exit'] = run(['bash', 'tools/test-sandbox.sh'], 'live-sandbox', LIVE / 'agent')
        if receipt['sandbox_exit']:
            receipt['rollback_exit'] = run(['git', 'reset', '--merge', receipt['premerge']], 'live-rollback')
            receipt['phase'] = 'test_failed'
        else:
            receipt['merged'] = receipt['behavior_commit']
            receipt['phase'] = 'tested_live'
    receipt['final_head'] = git('rev-parse', 'HEAD')
    receipt['final_status'] = git('status', '--short')
except Exception as exc:
    receipt['error'] = str(exc)
    receipt['phase'] = 'blocked'
finally:
    save()
    print(json.dumps(receipt, ensure_ascii=False))

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
checked = 0
for m in manifest:
    path = OUT / 'evidence' / (m['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    rows = []
    counts = dict.fromkeys(m['counts'], 0)
    with Path('/home/dw/Projects/agent-sts2/logs', m['stream'] + '.jsonl').open('rb') as source:
        for encoded in path.open('rb'):
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['offset'] + item['bytes'] <= m['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extract.run_identity(item['row']) == item['run_id']
            counts[item['run_id']] += 1
            if m['stream'] == 'states':
                assert item['row']['state']['run']['character_id'] == 'SILENT'
                assert item['row']['state']['run']['ascension'] == 10
            if m['stream'] in ['runs', 'run-config']:
                assert item['row']['character'] == 'SILENT'
                assert item['row']['ascension'] == 10
            rows.append(item)
            checked += 1
    assert digest.hexdigest() == m['output_sha256']
    assert counts == m['counts']
    streams[m['stream']] = rows


def powers(entries):
    return {p['power_id']: p['amount'] for p in entries or []}


def frame(item):
    row = item['row']
    state = row['state']
    run = state['run']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'], 'floor': run['floor'],
        'turn': state.get('turn'), 'screen': state['screen'], 'ts': row['observed_ts'],
        'hp': run['current_hp'], 'max_hp': run['max_hp'], 'energy': player.get('energy'),
        'block': player.get('block'), 'powers': powers(player.get('powers')),
        'enemies': [{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'block', 'is_alive', 'move_id', 'intents']} |
                    {'powers': powers(e.get('powers'))} for e in combat.get('enemies') or []],
        'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'resolved_rules_text', 'dynamic_values']}
                 for c in combat.get('hand') or []],
        'upgraded_deck': sum(c.get('upgraded', False) for c in run.get('deck') or []),
    }


targets = {
    'VLZ6CCT8AQ0A': {35, 36, 37, 43, 44, 45}, '8JRE1C4H4Z2W': {17, 33},
    'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {33, 39},
    '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30},
}
frames = [frame(i) for i in streams['states'] if i['row']['state']['run']['floor'] in targets[i['run_id']]]
(OUT / 'target-frames.json').write_text(json.dumps(frames, ensure_ascii=False, indent=2) + '\n')
by_line = {i['line']: i for i in streams['states']}
state_index = collections.defaultdict(list)
for i in streams['states']:
    r = i['row']
    state_index[(i['run_id'], r['observed_ts'], r['fingerprint'])].append(i)
decisions = []
ends = []
for item in streams['decisions']:
    r = item['row']
    if r['floor'] not in targets[item['run_id']]:
        continue
    states = state_index.get((item['run_id'], r.get('observed_ts', r['ts']), r['fingerprint']), [])
    assert len(states) <= 1
    chosen = r.get('chosen') or {}
    card = None
    if states and chosen.get('action') == 'play_card':
        hand = (states[0]['row']['state'].get('combat') or {}).get('hand') or []
        card = next((c['card_id'] for c in hand if c['index'] == chosen['card_index']), None)
    rec = {k: r.get(k) for k in ['run_id', 'floor', 'turn', 'sl_attempt', 'label', 'decision_id', 'observed_ts', 'ts', 'answers', 'chosen', 'result', 'rollout', 'timing', 'potions', 'hp_guard', 'sl_explore']}
    rec.update(line=item['line'], state_line=states[0]['line'] if states else None, card=card)
    decisions.append(rec)
    if states and chosen.get('action') == 'end_turn':
        end = frame(states[0])
        end.update(decision_line=item['line'], attempt=r.get('sl_attempt'))
        ends.append(end)
(OUT / 'target-decisions.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'end-turn-frames.json').write_text(json.dumps(ends, ensure_ascii=False, indent=2) + '\n')
brain = collections.defaultdict(collections.Counter)
for item in streams['brain']:
    r = item['row']
    brain[item['run_id']][f"{r.get('engine')}/{r.get('model')}/{r.get('effort')}/accepted={r.get('accepted')}"] += 1
receipt = {'verified_source_rows': checked, 'stream_counts': {m['stream']: sum(m['counts'].values()) for m in manifest},
           'brain_rows': {k: dict(v) for k, v in brain.items()},
           'decision_state_missing': [d['line'] for d in decisions if d['state_line'] is None]}
(OUT / 'evidence-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))
for r in ends:
    if r['run'] == 'VLZ6CCT8AQ0A' and r['floor'] not in [43, 45]:
        continue
    print(json.dumps({k: v for k, v in r.items() if k not in ['hand', 'ts', 'upgraded_deck', 'max_hp', 'screen']}, ensure_ascii=False))

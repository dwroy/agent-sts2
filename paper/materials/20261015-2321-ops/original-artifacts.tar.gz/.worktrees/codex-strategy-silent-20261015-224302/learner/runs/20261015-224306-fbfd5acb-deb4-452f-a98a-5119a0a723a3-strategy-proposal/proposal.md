# 本批静默策略核验与猛扑覆盖提示提案

记录时间：2026-10-15T22:58:28+08:00。batch：20261015-224302-strategy-proposal。base：7f6646a68cf8be641e0abfe93d4987e8ef610f98。

本批仅消费已派10个原id，不是专题研究；无 research_request/implementation_request，普通专题文件绑定另一个batch，未读取其work_spec。开工工作树干净，git merge --no-edit main为Already up to date。原10份Markdown均存在且SHA256与队列一致。未领取其他提案，未改原稿或历史复盘。

## 本次窄代码改动

关联原id：silent-proposal-89354805ee4d7e77、silent-proposal-283a164780d11e69；账本silent-0237/0238；领域combat/structure；授权Roy-2026-10-07-learning。

证据仅VLZ6CCT8AQ0A A10：F35 T2 d269607/s275575→275576、F37 T3 d269660/s275631→275632、F43 T5 d269728/s275701→275702。三次猛扑+实打均消耗2能并建立FREE_SKILL_POWER 1；伤害预览分别21/23/16。F35后续技能在手牌确实变0费。它们来自同一局，不增加独立样本分母。

旧行为：通用牌模型因有Damage字段即标known=true，但本批核对turn-solver/rollout/live输入没有FREE_SKILL_POWER或猛扑后免费技能的状态传播；因此伤害计算不能证明整张牌已覆盖。

新行为：只在Silent A10、已观察的升级/2能/零星费/原模板/无附魔/20基础伤害且现场21、23或16的预览，保留原伤害、费用、选项和零固定加分，将known标false；现有求解器会把该候选列入未建模项，并保留有缺口的候选不作完整支配断言。不加入普通/升级对的已知升级列表，不实现或预支免费技能收益，不改变HP、药水持价、SL或终局权重。其他角色、进阶和未观察预览保持原行为。

固定验证：agent/tests/silent-pounce-coverage-evidence.json保存上述六个原combat帧及每行offset/bytes/SHA；测试禁止读取刷新knowledge，验证实际建立免费技能、2能成本、伤害保留、候选未知标记和角色/进阶/预览隔离。源码撤掉3失败1通过，恢复4通过；详情pounce-withdrawn.log、pounce-restored.log与pounce-red-green.json。完整沙箱另记，不能把材料断言当生产测试。

反例与未知：发现了猛扑14→20、猎杀者15→20、本能反应2→3的额外配对预览；猛扑免费技能、猎杀者后续抽牌以及本能反应临时费用/奇巧尚无本批完整模型验证，不能只增加数字并宣称全部已覆盖。本次只修覆盖声明。没有同盘整战反事实或胜率收益；后续需验证免费技能消费/延续/抽牌/选择/SL边界后另行实现。完整神化追踪和两原提案仍waiting。

预期：让消费者看到猛扑候选有未计入的效果，减少把只有伤害的模型当完整比较依据。describePlan会将unknownCards写入unmodelled_cards，现有Silent决策投影保留该字段，静态读回见consumer-static-readback.json。实际自然题面和选择读回需上线后单独核；固定测试不代替自然消费者。回退：仅撤本批card-model覆盖判断和两个固定测试材料文件，保留其余发布、证据、账本和原提案。

## 证据完整性与范围

共用extract_evidence.py提取八流；按显式run/run_id/state.run_id/fingerprint.run拒绝冲突身份。逐字节重新读取验证6995行：states3432、decisions3306、SL29、run-config6、run-plans33、brain183、runs6、fight-plans0。每流source_size、计数和输出SHA见evidence/evidence-manifest.json；逐行offset/bytes/SHA在各evidence.jsonl。fight-plans零行只指该冻结截点无选中行，不推断日志历史缺失。原大流外部坏行计数不混入本批证据。

六局runs均Silent A10；本批183条brain原行均engine=codex/model=gpt-6.1-sol/effort=high/accepted=true，不用runs里的旧deepseek_calls载荷字段推断大脑引擎。六局均dirty代码记录，实际dirty知识字节不完整，不能把这些历史结果当当前模型生产校准。

只读15个相关源码叶与live快照f92636aec0e099e656eb18d14ef73c7dc266ff55核对：12个字节相同，card-model/rollout-live/explore三叶只有历史Roy/Dai注释差；各叶最近提交均为该live祖先。见source-readback.json。神化候选的actual_cast_this_fight=null，selection_audit.actual_turn=null，单动作回执whole_plan_executed=null；首动作离线校准不代替整候选轨迹。20项材料断言通过，仅为本批证据核验。

启动器实际参数记录为gpt-6.1-sol/xhigh/default，本题文字要求high；本会话已按原thread独立读取原生turn_context第8行，核实model=gpt-6.1-sol、effort=xhigh、approval_policy=never及本工作树cwd；没有修改启动配置、重启原线程或冒称已切换high。见runtime-identity.json。已核上述历史局的大脑请求为high，二者口径分开。

## silent-proposal-89354805ee4d7e77

来源：postmortem → strategy-proposal；角色silent，已观察A10。账本：silent-0237, silent-0238。证据：VLZ6CCT8AQ0A F35 T1/T2、F37 T3、F43 T1/T5、F45 T1。原文SHA与路径见 original-proposal-manifest.json。

已核：神化已观察普通升级传播已有live子项；本批补猛扑+含未建模免费技能的覆盖提示。完整施放身份、未知升级及后置消费者仍不完整。

反例/限制：F35/43打神化后获胜而F43损57；F45未打而败，构筑、敌人、资源不同，不能当因果对照。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：持续施放追踪及未覆盖升级/费用传播，不能用本次覆盖提示关闭原请求。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-f2bfceddb1898dca

来源：postmortem → strategy-proposal；角色silent，已观察A10。账本：silent-0106, silent-0019, silent-0201。证据：VLZ6CCT8AQ0A F45 T1/T4/T5。原文SHA与路径见 original-proposal-manifest.json。

已核：269748为MC707ms、horizon1/samples1；269754为MC11ms、horizon5/samples3；指纹不同，不是同盘预算试验。

反例/限制：F17/F33首试胜；局部12/12药水样本不等于整战完整模型。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：模型覆盖完整后的同起点、同随机池、同总预算配对与稳定性曲线，不能拟合预算或留药价。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-283a164780d11e69

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0237, silent-0238。证据：VLZ6CCT8AQ0A F35 T1/T2、F37 T3、F43 T1/T5、F45 T1。原文SHA与路径见 original-proposal-manifest.json。

已核：同源神化经验有独立代码提案链接；与893共享本批猛扑覆盖提示，不新建重复id。

反例/限制：已观察升级子项为live祖先，并非未观察的组合、完整施放身份和整战兑现均已完成。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：同893的完整施放身份、未知升级及后续交互；不可仅同源就标整项duplicate。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-ebbfe3b97548756d

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。证据：VLZ6CCT8AQ0A F43 T1–T6、F45 T1–T5。原文SHA与路径见 original-proposal-manifest.json。

已核：升级、敏捷、临时减力、毒结算和现场覆甲可逐项核；F45末32血20挡、四段总59需损39。

反例/限制：F43已建立能力仍损57；F44回34后F45仍败，不支持统一回血安全线。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：十五条经验各自组合、期限及战斗/路线/休息消费者的联合校准。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-e5b87be50f28f311

来源：postmortem → strategy-proposal；角色silent，已观察A10。账本：silent-0079, silent-0021, silent-0125, silent-0018。证据：8JRE1C4H4Z2W F33 首试/第三试T2、第二试T5、末试T11。原文SHA与路径见 original-proposal-manifest.json。

已核：270216/270282指纹相同；47HP/敌326起点，首试实损3/扣10，三试实损15/扣17，多12血只多7伤。

反例/限制：末试更防御延到T11仍死，不证明一律保血或一律增伤；原答与替换的0/24和5/24不同。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：跨重规划持续候选身份、整候选执行及成长分源；现有单动作回执和首动作校准不能认证整回合。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-49632bc4878fb597

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0005, silent-0231。证据：CA5KE8GFJ9X2 F13 T1–T5。原文SHA与路径见 original-proposal-manifest.json。

已核：两加压力0→4→8，无弱喷水11/15/19，弱后11/14仍成长；本战无正敏捷帧。

反例/限制：其他本批局出现敏捷不等于同一起点四条属性路径受控联合验证。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：力量、正负敏捷、虚弱与独立成长四路径的冻结联合调用校准。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-66532328a585941f

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0021, silent-0009。证据：5PM6JAQG6FNQ F33、F39末试T2。原文SHA与路径见 original-proposal-manifest.json。

已核：268455/s274379→274380：向无毒失落施放冒泡，能量5→4，敌HP及能力不变。

反例/限制：F33已建毒雾3/触媒1/群蛇4并胜，组件、资源和敌人均不同。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：同HP、构筑、药水和完整抽序的启动次序整战配对、收益函数。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-43a76a31ba7bdcfa

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0030, silent-0027。证据：61E2QS63Y9WU F17 T5–T7。原文SHA与路径见 original-proposal-manifest.json。

已核：T5吸取后玩家力量2→0、敏0→−2；T6两防御各3，17毒两结算净33，首试七轮赢。

反例/限制：首试胜利没有提供同起点另一条SL整战后继；不外推固定换线偏好。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：同起始血量、构筑、完整抽序下另一条可核SL整战线路。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-5264153a4a4b0e5c

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0039, silent-0209。证据：61E2QS63Y9WU F23 T1–T5。原文SHA与路径见 original-proposal-manifest.json。

已核：T4幻象仍2血且有攻击，T5才0血；两实体航行后力量0/3/6。旧活体召唤子项源码是live祖先。

反例/限制：另一focus的39伤零损只是未实打候选，不可当完整胜线或规定首杀。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：A10逐实体召唤、复现、退场及成长完整校准，另一focus的整战后继。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

## silent-proposal-bddfa690a84e03d0

来源：experience-update → strategy-proposal；角色silent，已观察A10。账本：silent-0128, silent-0079。证据：DUZUBAJ3A8GP F30四次尝试，T1–T6。原文SHA与路径见 original-proposal-manifest.json。

已核：睡层3/2/1后T4醒，临时减力恢复后末试T6力4、攻22；四试均未胜。

反例/限制：末试T4比首试多扣3敌血、多损2玩家血；不能只按敌血拟合全败排序。

拟实现及验证：保留原提案的条件和选项；本批只有神化两个同源提案的窄覆盖提示实现，其余不设新参数。缺口：伤害唤醒、眩晕期限及恢复成长全链校准，同抽不同顺序的完整后继。 后续须冻结对应原状态与完整后继，按run_id作时间后移独立验证；当前同局帧均为发现/回归，不能称盲测。

处置：waiting。现有子项不替代整项实现；回退本批窄源码提交可移除覆盖提示，其余各项本批无代码需回退。

import hashlib
import json
import pathlib
import subprocess

scratch = pathlib.Path(__file__).resolve().parent
workspace = scratch.parents[2]
live = pathlib.Path('/home/dw/Projects/agent-sts2/.worktrees/live')


def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args])


base = git(workspace, 'rev-parse', 'HEAD').decode().strip()
live_head = git(live, 'rev-parse', 'HEAD').decode().strip()
features = {
    'agent/src/reflex/silent-held-loss.ts': 'export function silentHeldLossFacts',
    'agent/src/reflex/silent-potion-reference.ts': 'export function silentPotionReference',
    'agent/src/reflex/silent-sl-resource-comparison.ts': 'export function silentSlResourceComparison',
    'agent/src/reflex/silent-sl-comparison.ts': 'export function silentSlComparison',
    'agent/src/reflex/silent-selection-audit.ts': 'export function silentSelectionAudit',
    'agent/src/reflex/silent-selection-dispatch.ts': 'export function silentSelectionDispatch',
    'agent/src/reflex/silent-giant-potion.ts': 'export function silentGiantPotionFacts',
    'agent/src/sl/attempts.ts': 'export function giantPhaseAtTurnStart',
    'agent/src/sl/explore.ts': 'Raw displayed HP on the last turn',
    'agent/src/reflex/combat-plan.ts': 'silentSlResourceComparison(state',
    'agent/src/hand/loop.ts': 'silentSelectionDispatch(state',
    'learner/lib/selection-execution.ts': 'actual_full_candidate_result',
    'learner/audit-selection.ts': 'auditSelectionExecution',
}
rows = []
for path, needle in features.items():
    before = git(workspace, 'show', base + ':' + path)
    deployed = git(live, 'show', live_head + ':' + path)
    assert needle.encode() in before
    origin = git(workspace, 'log', '-1', '--format=%H', '-S' + needle, base, '--', path).decode().strip()
    assert len(origin) == 40
    ancestors = {}
    for name, tree, head in [('base', workspace, base), ('live', live, live_head)]:
        ancestors[name] = subprocess.run(['git', '-C', str(tree), 'merge-base', '--is-ancestor', origin, head]).returncode == 0
    patch = git(workspace, 'diff', '--binary', base, live_head, '--', path)
    if patch:
        (scratch / (path.replace('/', '__') + '.live-difference.patch')).write_bytes(patch)
    rows.append({'path': path, 'feature_needle': needle, 'base_sha256': hashlib.sha256(before).hexdigest(),
                 'live_sha256': hashlib.sha256(deployed).hexdigest(), 'same_bytes': before == deployed,
                 'feature_source_commit': origin, 'ancestor': ancestors})
proposals = []
for item in json.loads((scratch / 'dispatched-proposals.json').read_text()):
    raw = pathlib.Path(item['proposal']).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == item['proposal_sha256']
    proposals.append({'id': item['id'], 'path': item['proposal'], 'bytes': len(raw), 'sha256': digest})
result = {'base': base, 'live_head': live_head, 'sources': rows, 'original_proposals': proposals,
          'scope': 'Feature ancestry and current file bytes only; no new implementation or production validation.'}
(scratch / 'source-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'live_head': live_head, 'files': len(rows),
                  'same_bytes': sum(r['same_bytes'] for r in rows),
                  'all_feature_ancestors': all(all(r['ancestor'].values()) for r in rows),
                  'proposals_sha_verified': len(proposals)}, ensure_ascii=False))

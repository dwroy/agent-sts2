import collections
import hashlib
import json
import pathlib

scratch = pathlib.Path(__file__).resolve().parent
dispatch = json.loads((scratch / 'dispatch.json').read_text())
runs = dispatch['runs']
grouped = {run: collections.defaultdict(list) for run in runs}
manifests = []
verified = 0
for directory in ['evidence', 'evidence-extra']:
    manifests.extend(json.loads((scratch / directory / 'evidence-manifest.json').read_text()))
    for manifest in json.loads((scratch / directory / 'evidence-manifest.json').read_text()):
        stream = manifest['stream']
        path = scratch / directory / (stream + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
        counts = collections.Counter()
        with path.open() as handle, open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as source:
            for line in handle:
                item = json.loads(line)
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                row = item['row']
                fp = row.get('fingerprint')
                if isinstance(fp, str):
                    fp = json.loads(fp)
                state = row.get('state') or {}
                identities = {x for x in [row.get('run_id'), row.get('run'), state.get('run_id'),
                                          fp.get('run') if isinstance(fp, dict) else None]
                              if isinstance(x, str) and x and x != 'run_unknown'}
                assert identities == {item['run_id']} and item['run_id'] in runs
                if stream == 'states':
                    assert state['run']['character_id'] == 'SILENT' and state['run']['ascension'] == 10
                grouped[item['run_id']][stream].append(item)
                counts[item['run_id']] += 1
                verified += 1
        assert dict((run, counts[run]) for run in runs) == manifest['counts']


def dump(name, obj):
    (scratch / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def state_summary(item):
    st = item['row']['state']
    combat = st.get('combat') or {}
    return {'line': item['line'], 'run_id': item['run_id'], 'floor': st['run']['floor'], 'turn': st.get('turn'),
            'hp': st['run']['current_hp'], 'max_hp': st['run']['max_hp'], 'screen': st['screen'],
            'player': combat.get('player'), 'potions': st['run'].get('potions'),
            'enemies': combat.get('enemies'),
            'hand': [{k: c.get(k) for k in ['card_id', 'name', 'upgraded', 'index', 'description']}
                     for c in combat.get('hand') or []]}


references = {278403, 278404, 278405, 278406, 278407, 278500, 278501, 278502, 278503, 278504, 278505,
              278816, 278817, 278820, 278824, 278825, 278834, 278837, 278842, 278882, 278884, 278887, 278888,
              280160, 280161, 280162, 280206, 280207, 280232, 280233, 280262, 280263,
              280313, 280314, 280315, 280316, 280348, 280349, 280354, 280355,
              280564, 280684, 280691, 280692, 280697, 280705, 280709, 280713, 280717, 280718, 280723}
selected = []
pairs = []
excluded = []
run_summaries = []
for run in runs:
    streams = grouped[run]
    assert len(streams['runs']) == 1
    actual_run = streams['runs'][0]['row']
    decisions = []
    for item in streams['decisions']:
        row = dict(item['row'])
        if not row.get('decision_id'):
            excluded.append({'run_id': run, 'line': item['line'], 'sha256': item['sha256'],
                             'reason': '原始元数据行没有 decision_id，审计输入拒收，保留原证据与原行号。'})
            continue
        row.pop('agent_view', None)
        row.update(_line=item['line'], _source_sha256=item['sha256'])
        decisions.append(row)
    states = [{**item['row'], '_line': item['line'], '_source_sha256': item['sha256']} for item in streams['states']]
    dump(run + '.audit-input.json', {'run': actual_run, 'decisions': decisions, 'states': states})
    by_fp = collections.defaultdict(list)
    for item in streams['decisions']:
        row = item['row']
        explore = row.get('sl_explore')
        if explore and explore.get('original') != explore.get('replacement'):
            old = by_fp[row['fingerprint']]
            if old:
                pairs.append({'run_id': run, 'floor': row.get('floor'), 'turn': row.get('turn'),
                              'replacement_line': item['line'], 'original_lines': [x['line'] for x in old],
                              'same_fingerprint': True, 'sl_explore': explore,
                              'replacement_attempt': row.get('sl_attempt'), 'row_sha256': item['sha256']})
        if row.get('fingerprint'):
            by_fp[row['fingerprint']].append(item)
    selected.extend(state_summary(item) for item in streams['states'] if item['line'] in references)
    attempts = [{'line': item['line'], 'attempt': item['row'].get('attempt'), 'floor': item['row'].get('floor'),
                 'result': item['row'].get('result'), 'turns': item['row'].get('turns'),
                 'target': item['row'].get('target')} for item in streams['sl-attempts']]
    run_summaries.append({'run_id': run, 'character': actual_run['character'], 'ascension': actual_run['ascension'],
                          'ended': actual_run['ended'], 'victory': actual_run['victory'], 'floor': actual_run['floor'],
                          'counts': {stream: len(items) for stream, items in streams.items()}, 'attempts': attempts})
dump('selected-states.json', selected)
dump('paired-candidates.json', pairs)
dump('audit-input-exclusions.json', excluded)
dump('run-summary.json', run_summaries)
dump('evidence-review.json', {'verified_raw_lines': verified, 'streams': manifests,
                            'runs': runs, 'excluded_audit_metadata': excluded,
                            'same_fingerprint_replacements': len(pairs),
                            'scope': '原字节、显式所属身份和材料端点核对，不是生产测试或候选收益认证。'})
print(json.dumps({'verified_raw_lines': verified, 'pairs': len(pairs), 'selected_states': len(selected),
                  'excluded_metadata': excluded, 'counts': [{x['run_id']: x['counts']} for x in run_summaries]}, ensure_ascii=False))

import json
import pathlib
import subprocess

scratch = pathlib.Path(__file__).resolve().parent
stamp = subprocess.check_output(['date', '-Is'], text=True).strip()
dispatch = json.loads((scratch / 'dispatch.json').read_text())
proposals = json.loads((scratch / 'dispatched-proposals.json').read_text())
sources = json.loads((scratch / 'source-review.json').read_text())
review = json.loads((scratch / 'evidence-review.json').read_text())
facts = json.loads((scratch / 'facts-review.json').read_text())
reasons = [
    '751 F17 T2/T7/T13同指纹血价已核；已有SL候选预测拆项，仍缺抽弃重问后的完整候选认证、逐来源实得与受控整战后继，不能设固定SL血价。',
    '751 F13 T3持药未知及同题无药参考、F17未决弃牌提示已有窄实现；缺真实无药整战、留药后战对照及重问后的完整候选收益，不能以提示关闭整项。',
    '751六次尝试同属一局；局部血价与配对B2不认证改变探索准入后的整战结局，缺同后轮条件的完整对照与独立后期验证。',
    '751敏捷/毒/荆棘/呼唤的分项证据不等于联合收益；缺逐来源累计、抽弃后的完整执行与跨战留药反事实，不能借旧101局声明关闭宽提案。',
    'KV F33 T5净扣36/29、T1净扣28/14且各零损已由原帧复核；工具仍为turn_end_unverified，缺回血毛伤逐来源、完整候选认证和路线/休息替代后继。',
    '三局巨兽阶段已有提示；同存活轮仍以原始占位HP排序，缺新排序的受控后继。PU F17末次24血20挡对42自爆后剩2血获胜，不能直接归零改序。',
    'YQL F17 T10毒水使残壳毒2→8而26血/13挡/41来袭不变；缺提前喝、不喝、留药及新排序完整分支，不外推统一药水或终局规则。',
    'KEN七次用药请求及同槽变空已核，三次原回执pending保留；缺随机选牌/发光水重问后的完整收益认证与任一留药到后战的受控对照。',
    'KEN F17 T10损15→21/敌净扣2→4及T5省2血但步法延至T9的反向取舍已核；缺完整逐来源兑现、保持后轮条件的对照与独立后期验证。',
    'KEN同指纹血价与步法窗口只支持局部取舍；缺完整候选及同后轮反事实，不能拟合统一6血/2伤门槛，保留当前探索与护栏。',
]
evidence = [
    '751FN9QM9MHQ，F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820；states 278479→278483、278620→278623、278576→278581、278697→278702、278528→278532、278865→278869。',
    '751FN9QM9MHQ，F13 T3 decisions 272361/272362、states 278403—278407；F17 T7/T13/T17，states 278500—278505、278884—278888。',
    '同第1项的751FN9QM9MHQ F17三组同指纹；六次SL仅一个独立局。',
    '751FN9QM9MHQ，F13 T3及F17 T3/T5/T7/T13/T17；states 278820—278834、278837—278842、278882—278888；不将原历史101局当本批重验。',
    'KV0JHNJCKXLS，F33 T5 decisions 273400/273450、T1 273242/273474；人工端点与工具unknown并列见facts-review.json的kv_manual_endpoints。',
    'YQL8RZ8BWN1E F17 T10/T13，L9SGRBB5R698 F17 T14，PU80F84P6HPN F17 T17/T15；sl-attempts 681/717/960—963；PU states 252429—252436。',
    'YQL8RZ8BWN1E，F17 T10 decisions 274087，states 280160→280161；另两巨兽局同第6项。',
    'KEN58SH9SLZ6，F3T2/F4T1/F5T2/F11T1,T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272及各前后药槽见facts-review.json。',
    'KEN58SH9SLZ6，F17 T10 decisions 274505/274568，states 280588→280592、280651→280655；T5 decisions 274484/274601，states 280567→280572、280684→280689。',
    '同第9项KEN58SH9SLZ6 F17 T5/T10，末试T6/T10/T12/T13 states 280691—280723；能力延迟、追加小刀和后轮改线分别核。',
]
expected = [
    '保留原答、护栏后与SL后预测及实际重问链；完整后继可核后再研究血价准入，不按5/10血写常数。',
    '保守持牌失血与未决弃牌、hold_hp=null与收费0分别展示；无药参考只作为模拟，不直接调药水权重。',
    '完整对照同随机条件下原/替线与后续；报告负结果，不把六次重打拆成独立训练和验证。',
    '先验证逐牌敏捷、已结毒/反伤、呼唤自损及能力建立的联合来源；不预支未来挡/毒。',
    '单列敌回血、可见净扣和实际路线回复；毛伤来源不全继续未知，休息假设不计已回血。',
    '保留原summary及阶段提示；本体0与自爆未结分列。改变排序须逐分支记录存活/缺口/药水与结局。',
    '只陈述本次残壳饮药的局部结果；不删除合法药水，不把新增毒层当已结伤或减自爆。',
    '核药槽、选择事件、后续重问与真实效应；pending与槽变空并列，完整药线及后战持有收益仍未知。',
    '同时核自损、无实体下已兑现攻击与步法时点；不把单轮少失血或多输出当整战优势。',
    '沿原提案等待完整后继及时间靠后独立验证；不因原线已失败就把未试线称更安全。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(proposals, reasons)]
base = sources['base']
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-054302-strategy-proposal',
         'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
         'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(scratch / 'report.md')}
(scratch / 'final.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
lines = ['# 本批指定提案处置', '', f'记录时间：{stamp}。任务 strategy-proposal；角色 silent；批次 20261016-054302-strategy-proposal。', '',
         '10项均为waiting；不新增提案id、不修改原提案、不改策略源码或知识数据。已有诊断仅覆盖窄子项，不能据此将宽提案登记duplicate/implemented。', '',
         '## 身份、证据与实现边界', '',
         f'合main前工作树干净，HEAD c53d98a4b5e07eb99c42da4c20fc63c0095104c5；按普通任务快进main后base为 `{base}`。本批无research_request/implementation_request，具有10个指定proposal_ids，未领取其他id。根notes/strategy-research-silent.json绑定另一批，未承接其专题。', '',
         '六局全部从runs.jsonl核实为Silent A10；不读其他角色知识。10份原Markdown逐SHA与派发队列一致，详见source-review.json。使用共用extract_evidence.py冻结默认六流，并另存runs/fight-plans两流；source_size、offset、bytes、SHA与计数全部保存。8,444条原行逐seek复核原字节、JSON及所有显式所属字段一致。fight-plans本次截点0条只说明该截点未选到，不断言原日志缺失；不以正文提及定所属。全源未选中损坏行计数不当本角色错误。', '',
         '## 固定证据与反例', '',
         '- 751 F17 T2原/替整轮净损13/18、敌净扣9/18；T7净损13/23、净扣12/18，多6净扣需多10血。题面预测损19/29与实际13/23各差6，不能把共同保守差额当换线收益。T13净损8/2、净扣17/11，是反向的6血/6输出取舍。题面牌伤与含已结毒/反伤的整轮净扣分列。',
         '- KV F33 T5人工净扣36/29、T1净扣28/14，均零损；工具严格回合认证仍unknown/turn_end_unverified，保留人工端点、不改工具结果，不冒称完整毛伤或完整候选。',
         '- KEN F17 T10同指纹净损15/21、敌净扣2/4；B2原38.5%、替12.7%，五轮死亡6/24与12/24不同。T5替线省2血，整轮净扣1/2包含后续另问追加小刀；步法由T5延至T9，不能把整轮结果全归初始候选。',
         '- YQL F17 T10残壳用毒水前后毒2/8、玩家26血13挡及41来袭不变；本体结束与整场胜利分开。sl-attempts681/717/960—963原始近十亿占位血确实进入参考记录。PU F17 states252435→252436中24血20挡面对42自爆后进奖励剩2血，是不能将本体结束当整场胜负或直接归零改序的边界案例。',
         '- KEN七次请求对应同槽药物→空槽；三条原回执pending仍保留。末试F17T13最后可操作帧280722为6血0挡对9来袭、手无呼唤，280723死亡实扣仅6；死亡页显示来袭6不能回填为结束前9的替代，也不能将截顶实扣当完整入伤。', '',
         '本批只重核上述六局；原提案中101/102/103/104局历史统计及其他支持局仍为原工作边界，不冒称重新全历史校准。局内重打相关，未拆为独立样本；没有调参、收益/胜率结论或新通用机制。', '']
for index, (p, reason, ev, exp) in enumerate(zip(proposals, reasons, evidence, expected), 1):
    lines += [f'## {index}. {p["id"]}', '', f'原提案：{p["proposal"]}。', '',
              f'账本：{", ".join(p["ledger"])}。来源任务：{p["source_task"]}；实现任务：strategy-proposal。已观察范围：silent A10。', '',
              f'证据：{ev}', '', f'处置：waiting。{reason}', '', f'预期行为与验证：{exp}', '',
              '旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。', '']
(scratch / 'proposal.md').write_text('\n'.join(lines) + '\n')
total = lambda key: sum(a[key] for a in facts['audits'])
header = ['# 策略提案批次报告', '', f'记录时间：{stamp}。', '',
          '本批10项均waiting，证据尚不足以制定新策略。未修改源码/知识、未提交、未合入live、未新增发布号；无合入受阻。详细逐项提案、账本、反例和验证要求见本目录proposal.md。', '',
          f'base：`{base}`；只读核对的live HEAD：`{sources["live_head"]}`。根学习队列只读本批行，不改变派发状态、父请求或原提案正文。', '',
          '## 验证结果', '',
          f'原字节/身份核验8,444行；10份提案SHA一致；固定材料断言{facts["assertions_passed"]}项通过。六次既有audit-selection.ts有限离线调用退出0、stderr空，各自TMPDIR均显式限定为本批scratch。输入输出SHA见facts-review.json；未调用LLM、网络或游戏。', '',
          f'六局审计合计{total("segments")}个题段、{total("observed_actions")}个已记录动作、{total("observed_intervals")}个相邻观测、{total("observed_turns")}个回合窗：415个可核端点，362个unknown。actual_full_candidate_result/actual_rollout_best全为null。777个窗口不是777次独立实验，也不能把415个端点当415个完整候选或因果收益。', '',
          '准备输入时6条无decision_id的路线元数据行单独记录在audit-input-exclusions.json；原行保留，不补号，不把过滤后的行重新编号或跨缺行认证连续性。7组指定决策指纹配对断言通过；paired-candidates.json另存24条有旧同指纹的SL替换供追溯，不将其一律解释为受控配对。', '',
          'tsc=null、vitest=null、cases=null。未改源码，所以未跑生产测试和撤源码负控；材料断言与审计退出0不填成生产测试成功。未提交，因此无提交号、无gitleaks提交门禁成功或eval行为版本声明。实际执行引擎/推理设置没有从原生宿主会话独立核实，本报告不把仓库默认或历史run-config当本学习者实际设置证明。', '',
          '## 已有源码子项与live核对', '',
          '逐文件base/live字节及真实功能来源祖先见source-review.json。13叶中12叶相同；explore.ts只有3处Roy/Dai历史注释文字差，patch原样保存，没有据此改写旧来源。下列提交全部为本次base及读取的live祖先，仅表明已有子项，绝不作为本批实现提交或整个提案关闭凭据。', '',
          '| 文件 | 已有功能来源提交 | base/live同字节 |', '|---|---|---|']
for row in sources['sources']:
    header.append(f'| {row["path"]} | {row["feature_source_commit"]} | {"是" if row["same_bytes"] else "否，历史注释差见patch"} |')
header += ['', '候选预测、hold_hp=null、保守持牌来源、首动作回执、巨兽阶段提示已有窄实现；actual_turn/whole_plan_executed仍未认证。参考anchorRank仍沿原始enemyHpLeft排序。原始dirty对局代码/知识快照未恢复，当前源码祖先不能冒当历史消费者或策略效果。', '',
           '## 记录与下一步', '',
           '本批不新建经验/提案id，不重复历史复盘或support/repeat。只经根learner/ledger.py update为16个既有silent账本追加本报告和proposal路径、waiting原因追溯；不改claim/首证/prior/evidence/status/version，不将旧shipped降级为proposed，不新增shipped。实际CLI输入输出与前后保护字段核验将另存ledger-*材料。', '',
           '缺口逐项保留在final.json的proposal_results；等待后续由原调度器在新证据满足时续派。本批不等待未来对局、不启动额外模型/对局、不另建清理任务。所需验证是完整后继、逐来源兑现与按独立局/时间切分的验证；不是重新要求Roy授权既有人定规则。', '',
           '过程限制：最初状态结构探查遇combat=null而TypeError，后续改为显式空值处理；部分猜测源码/旧报告路径不存在，改用rg发现真实路径。首轮SL anchor探查误取顶层target，后从explore.target.anchor读回原记录；这些是材料准备问题，不当产品bug或游戏反证。未覆盖/改写旧失败。', '',
           f'完整提案绝对路径：{scratch / "proposal.md"}', '',
           '```json', json.dumps(final, ensure_ascii=False, indent=2), '```', '']
(scratch / 'report.md').write_text('\n'.join(header))
print(json.dumps({'report': str(scratch / 'report.md'), 'base': base, 'waiting': len(results)}, ensure_ascii=False))

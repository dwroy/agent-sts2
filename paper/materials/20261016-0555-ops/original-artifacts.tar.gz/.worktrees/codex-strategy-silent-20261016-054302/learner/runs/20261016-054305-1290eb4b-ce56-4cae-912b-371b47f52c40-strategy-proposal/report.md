# 策略提案批次报告

记录时间：2026-10-16T05:53:15+08:00。

本批10项均waiting，证据尚不足以制定新策略。未修改源码/知识、未提交、未合入live、未新增发布号；无合入受阻。详细逐项提案、账本、反例和验证要求见本目录proposal.md。

base：`e9b5316c63f2362e728e060cdb56b43123c6ffb8`；只读核对的live HEAD：`e716bd28fd8eca9e4d76d066680304fd11935e37`。根学习队列只读本批行，不改变派发状态、父请求或原提案正文。

## 验证结果

原字节/身份核验8,444行；10份提案SHA一致；固定材料断言77项通过。六次既有audit-selection.ts有限离线调用退出0、stderr空，各自TMPDIR均显式限定为本批scratch。输入输出SHA见facts-review.json；未调用LLM、网络或游戏。

六局审计合计861个题段、4065个已记录动作、4065个相邻观测、777个回合窗：415个可核端点，362个unknown。actual_full_candidate_result/actual_rollout_best全为null。777个窗口不是777次独立实验，也不能把415个端点当415个完整候选或因果收益。

准备输入时6条无decision_id的路线元数据行单独记录在audit-input-exclusions.json；原行保留，不补号，不把过滤后的行重新编号或跨缺行认证连续性。7组指定决策指纹配对断言通过；paired-candidates.json另存24条有旧同指纹的SL替换供追溯，不将其一律解释为受控配对。

tsc=null、vitest=null、cases=null。未改源码，所以未跑生产测试和撤源码负控；材料断言与审计退出0不填成生产测试成功。未提交，因此无提交号、无gitleaks提交门禁成功或eval行为版本声明。实际执行引擎/推理设置没有从原生宿主会话独立核实，本报告不把仓库默认或历史run-config当本学习者实际设置证明。

## 已有源码子项与live核对

逐文件base/live字节及真实功能来源祖先见source-review.json。13叶中12叶相同；explore.ts只有3处Roy/Dai历史注释文字差，patch原样保存，没有据此改写旧来源。下列提交全部为本次base及读取的live祖先，仅表明已有子项，绝不作为本批实现提交或整个提案关闭凭据。

| 文件 | 已有功能来源提交 | base/live同字节 |
|---|---|---|
| agent/src/reflex/silent-held-loss.ts | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 是 |
| agent/src/reflex/silent-potion-reference.ts | c4670f4f416c7d93e192e889c5080e7e4e0e733f | 是 |
| agent/src/reflex/silent-sl-resource-comparison.ts | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 是 |
| agent/src/reflex/silent-sl-comparison.ts | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 是 |
| agent/src/reflex/silent-selection-audit.ts | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 是 |
| agent/src/reflex/silent-selection-dispatch.ts | fdaf787a372880b0438e73bcac7e6d2168b038ed | 是 |
| agent/src/reflex/silent-giant-potion.ts | 40168f4a903ae1d8c48bd03006f8fea19fd3aa3c | 是 |
| agent/src/sl/attempts.ts | 5b56a452bb9be14d620b368ec46974c1b57901ca | 是 |
| agent/src/sl/explore.ts | 5b56a452bb9be14d620b368ec46974c1b57901ca | 否，历史注释差见patch |
| agent/src/reflex/combat-plan.ts | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 是 |
| agent/src/hand/loop.ts | fdaf787a372880b0438e73bcac7e6d2168b038ed | 是 |
| learner/lib/selection-execution.ts | 07192e6faf1da89c2719e22b3e0c280617795f22 | 是 |
| learner/audit-selection.ts | 02c4e13ac8e159b82ee35a965ac788a0a029ce5a | 是 |

候选预测、hold_hp=null、保守持牌来源、首动作回执、巨兽阶段提示已有窄实现；actual_turn/whole_plan_executed仍未认证。参考anchorRank仍沿原始enemyHpLeft排序。原始dirty对局代码/知识快照未恢复，当前源码祖先不能冒当历史消费者或策略效果。

## 记录与下一步

本批不新建经验/提案id，不重复历史复盘或support/repeat。只经根learner/ledger.py update为16个既有silent账本追加本报告和proposal路径、waiting原因追溯；不改claim/首证/prior/evidence/status/version，不将旧shipped降级为proposed，不新增shipped。实际CLI输入输出与前后保护字段核验已另存ledger-*材料；16条update退出0，旧where/notes/history前缀保持，全部非追溯字段相同。

缺口逐项保留在final.json的proposal_results；等待后续由原调度器在新证据满足时续派。本批不等待未来对局、不启动额外模型/对局、不另建清理任务。所需验证是完整后继、逐来源兑现与按独立局/时间切分的验证；不是重新要求Roy授权既有人定规则。

过程限制：最初状态结构探查遇combat=null而TypeError，后续改为显式空值处理；部分猜测源码/旧报告路径不存在，改用rg发现真实路径。首轮SL anchor探查误取顶层target，后从explore.target.anchor读回原记录；这些是材料准备问题，不当产品bug或游戏反证。未覆盖/改写旧失败。

完整提案绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-054302/learner/runs/20261016-054305-1290eb4b-ce56-4cae-912b-371b47f52c40-strategy-proposal/proposal.md

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261016-054302-strategy-proposal",
  "base": "e9b5316c63f2362e728e060cdb56b43123c6ffb8",
  "runs": [
    "751FN9QM9MHQ",
    "KV0JHNJCKXLS",
    "YQL8RZ8BWN1E",
    "L9SGRBB5R698",
    "PU80F84P6HPN",
    "KEN58SH9SLZ6"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-366288801d9150d9",
    "silent-proposal-85929bdfc8a3fc1b",
    "silent-proposal-efd9f83ee9e1a6dc",
    "silent-proposal-131042659448ae74",
    "silent-proposal-990f054036609447",
    "silent-proposal-e18d3f18e6cac2a0",
    "silent-proposal-9733bb80f445aeae",
    "silent-proposal-c51468c5e8ba6668",
    "silent-proposal-86a7db08d1a31976",
    "silent-proposal-e282a9131b99129a"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-366288801d9150d9",
      "state": "waiting",
      "reason": "751 F17 T2/T7/T13同指纹血价已核；已有SL候选预测拆项，仍缺抽弃重问后的完整候选认证、逐来源实得与受控整战后继，不能设固定SL血价。"
    },
    {
      "id": "silent-proposal-85929bdfc8a3fc1b",
      "state": "waiting",
      "reason": "751 F13 T3持药未知及同题无药参考、F17未决弃牌提示已有窄实现；缺真实无药整战、留药后战对照及重问后的完整候选收益，不能以提示关闭整项。"
    },
    {
      "id": "silent-proposal-efd9f83ee9e1a6dc",
      "state": "waiting",
      "reason": "751六次尝试同属一局；局部血价与配对B2不认证改变探索准入后的整战结局，缺同后轮条件的完整对照与独立后期验证。"
    },
    {
      "id": "silent-proposal-131042659448ae74",
      "state": "waiting",
      "reason": "751敏捷/毒/荆棘/呼唤的分项证据不等于联合收益；缺逐来源累计、抽弃后的完整执行与跨战留药反事实，不能借旧101局声明关闭宽提案。"
    },
    {
      "id": "silent-proposal-990f054036609447",
      "state": "waiting",
      "reason": "KV F33 T5净扣36/29、T1净扣28/14且各零损已由原帧复核；工具仍为turn_end_unverified，缺回血毛伤逐来源、完整候选认证和路线/休息替代后继。"
    },
    {
      "id": "silent-proposal-e18d3f18e6cac2a0",
      "state": "waiting",
      "reason": "三局巨兽阶段已有提示；同存活轮仍以原始占位HP排序，缺新排序的受控后继。PU F17末次24血20挡对42自爆后剩2血获胜，不能直接归零改序。"
    },
    {
      "id": "silent-proposal-9733bb80f445aeae",
      "state": "waiting",
      "reason": "YQL F17 T10毒水使残壳毒2→8而26血/13挡/41来袭不变；缺提前喝、不喝、留药及新排序完整分支，不外推统一药水或终局规则。"
    },
    {
      "id": "silent-proposal-c51468c5e8ba6668",
      "state": "waiting",
      "reason": "KEN七次用药请求及同槽变空已核，三次原回执pending保留；缺随机选牌/发光水重问后的完整收益认证与任一留药到后战的受控对照。"
    },
    {
      "id": "silent-proposal-86a7db08d1a31976",
      "state": "waiting",
      "reason": "KEN F17 T10损15→21/敌净扣2→4及T5省2血但步法延至T9的反向取舍已核；缺完整逐来源兑现、保持后轮条件的对照与独立后期验证。"
    },
    {
      "id": "silent-proposal-e282a9131b99129a",
      "state": "waiting",
      "reason": "KEN同指纹血价与步法窗口只支持局部取舍；缺完整候选及同后轮反事实，不能拟合统一6血/2伤门槛，保留当前探索与护栏。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-054302/learner/runs/20261016-054305-1290eb4b-ce56-4cae-912b-371b47f52c40-strategy-proposal/report.md"
}
```

## 最终读回

2026-10-16T05:54:38+08:00：工作树git status --porcelain为空，HEAD保持上述base；10项waiting覆盖派发集合且无遗漏。16条根账本CLI追溯追加已验证，未改变原证据/结论/状态。材料gitleaks扫描退出0、no leaks found；这不是源码提交门禁或生产测试。没有提交、合并、发布或等待未来事件。

# 本批指定提案处置

记录时间：2026-10-16T05:53:15+08:00。任务 strategy-proposal；角色 silent；批次 20261016-054302-strategy-proposal。

10项均为waiting；不新增提案id、不修改原提案、不改策略源码或知识数据。已有诊断仅覆盖窄子项，不能据此将宽提案登记duplicate/implemented。

## 身份、证据与实现边界

合main前工作树干净，HEAD c53d98a4b5e07eb99c42da4c20fc63c0095104c5；按普通任务快进main后base为 `e9b5316c63f2362e728e060cdb56b43123c6ffb8`。本批无research_request/implementation_request，具有10个指定proposal_ids，未领取其他id。根notes/strategy-research-silent.json绑定另一批，未承接其专题。

六局全部从runs.jsonl核实为Silent A10；不读其他角色知识。10份原Markdown逐SHA与派发队列一致，详见source-review.json。使用共用extract_evidence.py冻结默认六流，并另存runs/fight-plans两流；source_size、offset、bytes、SHA与计数全部保存。8,444条原行逐seek复核原字节、JSON及所有显式所属字段一致。fight-plans本次截点0条只说明该截点未选到，不断言原日志缺失；不以正文提及定所属。全源未选中损坏行计数不当本角色错误。

## 固定证据与反例

- 751 F17 T2原/替整轮净损13/18、敌净扣9/18；T7净损13/23、净扣12/18，多6净扣需多10血。题面预测损19/29与实际13/23各差6，不能把共同保守差额当换线收益。T13净损8/2、净扣17/11，是反向的6血/6输出取舍。题面牌伤与含已结毒/反伤的整轮净扣分列。
- KV F33 T5人工净扣36/29、T1净扣28/14，均零损；工具严格回合认证仍unknown/turn_end_unverified，保留人工端点、不改工具结果，不冒称完整毛伤或完整候选。
- KEN F17 T10同指纹净损15/21、敌净扣2/4；B2原38.5%、替12.7%，五轮死亡6/24与12/24不同。T5替线省2血，整轮净扣1/2包含后续另问追加小刀；步法由T5延至T9，不能把整轮结果全归初始候选。
- YQL F17 T10残壳用毒水前后毒2/8、玩家26血13挡及41来袭不变；本体结束与整场胜利分开。sl-attempts681/717/960—963原始近十亿占位血确实进入参考记录。PU F17 states252435→252436中24血20挡面对42自爆后进奖励剩2血，是不能将本体结束当整场胜负或直接归零改序的边界案例。
- KEN七次请求对应同槽药物→空槽；三条原回执pending仍保留。末试F17T13最后可操作帧280722为6血0挡对9来袭、手无呼唤，280723死亡实扣仅6；死亡页显示来袭6不能回填为结束前9的替代，也不能将截顶实扣当完整入伤。

本批只重核上述六局；原提案中101/102/103/104局历史统计及其他支持局仍为原工作边界，不冒称重新全历史校准。局内重打相关，未拆为独立样本；没有调参、收益/胜率结论或新通用机制。

## 1. silent-proposal-366288801d9150d9

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md。

账本：silent-0079, silent-0176。来源任务：postmortem；实现任务：strategy-proposal。已观察范围：silent A10。

证据：751FN9QM9MHQ，F17 T2/T7/T13；decisions 272434/272575、272531/272652、272483/272820；states 278479→278483、278620→278623、278576→278581、278697→278702、278528→278532、278865→278869。

处置：waiting。751 F17 T2/T7/T13同指纹血价已核；已有SL候选预测拆项，仍缺抽弃重问后的完整候选认证、逐来源实得与受控整战后继，不能设固定SL血价。

预期行为与验证：保留原答、护栏后与SL后预测及实际重问链；完整后继可核后再研究血价准入，不按5/10血写常数。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 2. silent-proposal-85929bdfc8a3fc1b

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md。

账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。来源任务：postmortem；实现任务：strategy-proposal。已观察范围：silent A10。

证据：751FN9QM9MHQ，F13 T3 decisions 272361/272362、states 278403—278407；F17 T7/T13/T17，states 278500—278505、278884—278888。

处置：waiting。751 F13 T3持药未知及同题无药参考、F17未决弃牌提示已有窄实现；缺真实无药整战、留药后战对照及重问后的完整候选收益，不能以提示关闭整项。

预期行为与验证：保守持牌失血与未决弃牌、hold_hp=null与收费0分别展示；无药参考只作为模拟，不直接调药水权重。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 3. silent-proposal-efd9f83ee9e1a6dc

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md。

账本：silent-0079, silent-0176。来源任务：experience-update；实现任务：strategy-proposal。已观察范围：silent A10。

证据：同第1项的751FN9QM9MHQ F17三组同指纹；六次SL仅一个独立局。

处置：waiting。751六次尝试同属一局；局部血价与配对B2不认证改变探索准入后的整战结局，缺同后轮条件的完整对照与独立后期验证。

预期行为与验证：完整对照同随机条件下原/替线与后续；报告负结果，不把六次重打拆成独立训练和验证。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 4. silent-proposal-131042659448ae74

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md。

账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。来源任务：experience-update；实现任务：strategy-proposal。已观察范围：silent A10。

证据：751FN9QM9MHQ，F13 T3及F17 T3/T5/T7/T13/T17；states 278820—278834、278837—278842、278882—278888；不将原历史101局当本批重验。

处置：waiting。751敏捷/毒/荆棘/呼唤的分项证据不等于联合收益；缺逐来源累计、抽弃后的完整执行与跨战留药反事实，不能借旧101局声明关闭宽提案。

预期行为与验证：先验证逐牌敏捷、已结毒/反伤、呼唤自损及能力建立的联合来源；不预支未来挡/毒。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 5. silent-proposal-990f054036609447

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md。

账本：silent-0102, silent-0019, silent-0020。来源任务：experience-update；实现任务：strategy-proposal。已观察范围：silent A10。

证据：KV0JHNJCKXLS，F33 T5 decisions 273400/273450、T1 273242/273474；人工端点与工具unknown并列见facts-review.json的kv_manual_endpoints。

处置：waiting。KV F33 T5净扣36/29、T1净扣28/14且各零损已由原帧复核；工具仍为turn_end_unverified，缺回血毛伤逐来源、完整候选认证和路线/休息替代后继。

预期行为与验证：单列敌回血、可见净扣和实际路线回复；毛伤来源不全继续未知，休息假设不计已回血。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 6. silent-proposal-e18d3f18e6cac2a0

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md。

账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。来源任务：postmortem；实现任务：strategy-proposal。已观察范围：silent A10。

证据：YQL8RZ8BWN1E F17 T10/T13，L9SGRBB5R698 F17 T14，PU80F84P6HPN F17 T17/T15；sl-attempts 681/717/960—963；PU states 252429—252436。

处置：waiting。三局巨兽阶段已有提示；同存活轮仍以原始占位HP排序，缺新排序的受控后继。PU F17末次24血20挡对42自爆后剩2血获胜，不能直接归零改序。

预期行为与验证：保留原summary及阶段提示；本体0与自爆未结分列。改变排序须逐分支记录存活/缺口/药水与结局。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 7. silent-proposal-9733bb80f445aeae

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md。

账本：silent-0017, silent-0019, silent-0020, silent-0250。来源任务：experience-update；实现任务：strategy-proposal。已观察范围：silent A10。

证据：YQL8RZ8BWN1E，F17 T10 decisions 274087，states 280160→280161；另两巨兽局同第6项。

处置：waiting。YQL F17 T10毒水使残壳毒2→8而26血/13挡/41来袭不变；缺提前喝、不喝、留药及新排序完整分支，不外推统一药水或终局规则。

预期行为与验证：只陈述本次残壳饮药的局部结果；不删除合法药水，不把新增毒层当已结伤或减自爆。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 8. silent-proposal-c51468c5e8ba6668

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md。

账本：silent-0019。来源任务：postmortem；实现任务：strategy-proposal。已观察范围：silent A10。

证据：KEN58SH9SLZ6，F3T2/F4T1/F5T2/F11T1,T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272及各前后药槽见facts-review.json。

处置：waiting。KEN七次用药请求及同槽变空已核，三次原回执pending保留；缺随机选牌/发光水重问后的完整收益认证与任一留药到后战的受控对照。

预期行为与验证：核药槽、选择事件、后续重问与真实效应；pending与槽变空并列，完整药线及后战持有收益仍未知。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 9. silent-proposal-86a7db08d1a31976

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md。

账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。来源任务：postmortem；实现任务：strategy-proposal。已观察范围：silent A10。

证据：KEN58SH9SLZ6，F17 T10 decisions 274505/274568，states 280588→280592、280651→280655；T5 decisions 274484/274601，states 280567→280572、280684→280689。

处置：waiting。KEN F17 T10损15→21/敌净扣2→4及T5省2血但步法延至T9的反向取舍已核；缺完整逐来源兑现、保持后轮条件的对照与独立后期验证。

预期行为与验证：同时核自损、无实体下已兑现攻击与步法时点；不把单轮少失血或多输出当整战优势。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。

## 10. silent-proposal-e282a9131b99129a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md。

账本：silent-0021, silent-0079, silent-0125, silent-0176。来源任务：experience-update；实现任务：strategy-proposal。已观察范围：silent A10。

证据：同第9项KEN58SH9SLZ6 F17 T5/T10，末试T6/T10/T12/T13 states 280691—280723；能力延迟、追加小刀和后轮改线分别核。

处置：waiting。KEN同指纹血价与步法窗口只支持局部取舍；缺完整候选及同后轮反事实，不能拟合统一6血/2伤门槛，保留当前探索与护栏。

预期行为与验证：沿原提案等待完整后继及时间靠后独立验证；不因原线已失败就把未试线称更安全。

旧/新规则：本批不更改原规则。若后续补齐证据，按原提案固定输入验证，撤源码负控须失败、恢复须通过，再跑规定沙箱入口；改变规则后按原live流程及双通知执行。当前没有独立新验证局或受控完整分支，不拟合阈值。回退：本批无源码可回退，保留原日志、失败历史和所有材料。


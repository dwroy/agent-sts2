import hashlib
import importlib.util
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
scratch = pathlib.Path(__file__).resolve().parent
root = pathlib.Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '-Is'], text=True).strip()
spec = importlib.util.spec_from_file_location('batch_ledger', root / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
proposals = json.loads((scratch / 'dispatched-proposals.json').read_text())
ids = sorted({ident for proposal in proposals for ident in proposal['ledger']})
before = ledger.fold(ledger.read_rows(str(root / 'paper/materials/learning/ledger.jsonl')))
before = {ident: before[ident] for ident in ids}
assert all(x['character'] == 'silent' for x in before.values())
(scratch / 'ledger-immediate-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in ids:
    related = [proposal['id'] for proposal in proposals if ident in proposal['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(scratch / 'proposal.md'), str(scratch / 'report.md')]},
                    'note': '20261016-054302-strategy-proposal：核六局Silent A10原证据及已有live窄源码；本批派发项仍waiting。'
                            '逐项缺完整候选/逐来源/受控整战/留药后继见报告；不新增support或repeat，不改规则及原状态。关联：' + ','.join(related)})
encoded = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates)
(scratch / 'ledger-update-input.jsonl').write_text(encoded)
result = subprocess.run([sys.executable, str(root / 'learner/ledger.py'), 'update'], input=encoded, text=True, capture_output=True)
(scratch / 'ledger-update.stdout').write_text(result.stdout)
(scratch / 'ledger-update.stderr').write_text(result.stderr)
assert result.returncode == 0, result.stderr
after = ledger.fold(ledger.read_rows(str(root / 'paper/materials/learning/ledger.jsonl')))
after = {ident: after[ident] for ident in ids}
for ident in ids:
    a, b = before[ident], after[ident]
    protected = lambda row: {key: value for key, value in row.items() if key not in ['where', 'notes', 'history']}
    assert protected(a) == protected(b), ident
    assert b['notes'][:-1] == a['notes'] and b['history'][:-1] == a['history'], ident
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values, (ident, key)
    assert str(scratch / 'report.md') in b['where']['proposal']
(scratch / 'ledger-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
receipt = {'time': stamp, 'exit_code': result.returncode, 'ids': ids, 'updates': len(updates),
           'protected_fields_unchanged': True, 'old_where_notes_history_prefixes_preserved': True,
           'input_sha256': hashlib.sha256(encoded.encode()).hexdigest(), 'no_new_evidence_or_status': True}
(scratch / 'ledger-link-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

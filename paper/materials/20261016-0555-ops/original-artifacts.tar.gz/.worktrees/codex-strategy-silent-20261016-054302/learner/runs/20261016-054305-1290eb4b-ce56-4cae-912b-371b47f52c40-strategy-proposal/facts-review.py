import collections
import hashlib
import json
import pathlib

scratch = pathlib.Path(__file__).resolve().parent
runs = json.loads((scratch / 'dispatch.json').read_text())['runs']
states = {x['line']: x for x in map(json.loads, (scratch / 'evidence/states.evidence.jsonl').open())}
decisions = {x['line']: x for x in map(json.loads, (scratch / 'evidence/decisions.evidence.jsonl').open())}
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'check': name, 'actual': actual, 'expected': expected})


def compact_turn(t):
    result = {key: t[key] for key in ['floor', 'turn', 'attempt', 'status', 'reason']}
    f = t.get('facts')
    if f:
        a, b = f['before'], f['after']
        result.update(state_lines=[a['source_line'], b['source_line']],
                      hp=[a['hp'], b['hp']], hp_net_loss=a['hp'] - b['hp'],
                      enemy_hp=[[e['hp'] for e in endpoint['enemies']] for endpoint in [a, b]])
    return result


audit_summary = []
turns = {}
for run in runs:
    raw = (scratch / (run + '.audit-output.json')).read_bytes()
    out = json.loads(raw)
    assert out['run_id'] == run
    assert all(s['actual_full_candidate_result'] is None and s['actual_rollout_best'] is None for s in out['segments'])
    turns[run] = {(t['floor'], t['turn'], t['attempt']): t for t in out['observed_turns']}
    audit_summary.append({'run_id': run, 'exit_code': 0, 'input_sha256': hashlib.sha256((scratch / (run + '.audit-input.json')).read_bytes()).hexdigest(),
                          'output_sha256': hashlib.sha256(raw).hexdigest(), 'segments': len(out['segments']),
                          'observed_actions': len(out['observed_actions']), 'observed_intervals': len(out['observed_intervals']),
                          'observed_turns': len(out['observed_turns']),
                          'turn_status_counts': dict(collections.Counter(t['status'] for t in out['observed_turns'])),
                          'full_candidate_certified': 0})

pairs = [(272434, 272575), (272531, 272652), (272483, 272820), (273400, 273450),
         (273242, 273474), (274505, 274568), (274484, 274601)]
for a, b in pairs:
    check(f'同指纹 decisions {a}/{b}', decisions[a]['row']['fingerprint'], decisions[b]['row']['fingerprint'])

selected_turns = {}
for run, floor, turn, attempt, loss, damage in [
    ('751FN9QM9MHQ', 17, 2, 1, 13, 9), ('751FN9QM9MHQ', 17, 2, 3, 18, 18),
    ('751FN9QM9MHQ', 17, 7, 2, 13, 12), ('751FN9QM9MHQ', 17, 7, 4, 23, 18),
    ('751FN9QM9MHQ', 17, 13, 1, 8, 17), ('751FN9QM9MHQ', 17, 13, 6, 2, 11),
    ('KEN58SH9SLZ6', 17, 10, 4, 15, 2), ('KEN58SH9SLZ6', 17, 10, 5, 21, 4),
    ('KEN58SH9SLZ6', 17, 5, 4, 7, 1), ('KEN58SH9SLZ6', 17, 5, 6, 5, 2)]:
    t = turns[run][(floor, turn, attempt)]
    f = t['facts']
    name = f'{run} F{floor} T{turn} attempt{attempt}'
    check(name + '端点', t['status'], 'observed_turn_endpoints')
    check(name + '净损血', f['before']['hp'] - f['after']['hp'], loss)
    check(name + '敌人净扣', sum(e['hp'] for e in f['before']['enemies']) - sum(e['hp'] for e in f['after']['enemies']), damage)
    selected_turns[name] = compact_turn(t)

# Manual endpoints remain separate from the audit tool's stricter window certification.
manual = []
for line, expected_damage in [(273400, 36), (273450, 29), (273242, 28), (273474, 14)]:
    d = decisions[line]['row']
    matched = [item for item in states.values() if item['row'].get('observed_ts') == d.get('observed_ts') and item['row'].get('fingerprint') == d['fingerprint']]
    check(f'KV decisions {line}唯一前帧', len(matched), 1)
    a = matched[0]
    later = [item for item in states.values() if item['run_id'] == 'KV0JHNJCKXLS' and item['line'] > a['line']
             and item['row']['state'].get('turn') == d['turn'] + 1 and item['row']['state']['run']['floor'] == 33]
    b = min(later, key=lambda item: item['line'])
    st_a, st_b = a['row']['state'], b['row']['state']
    hp = [s['run']['current_hp'] for s in [st_a, st_b]]
    enemy = [sum(e['current_hp'] for e in s['combat']['enemies'] if e['is_alive']) for s in [st_a, st_b]]
    check(f'KV decisions {line}手工净扣', enemy[0] - enemy[1], expected_damage)
    check(f'KV decisions {line}手工零损', hp[0] - hp[1], 0)
    manual.append({'decision_line': line, 'state_lines': [a['line'], b['line']], 'hp': hp, 'enemy_hp': enemy,
                   'audit_status': compact_turn(turns['KV0JHNJCKXLS'][(33, d['turn'], d['sl_attempt'])]),
                   'scope': '人工端点净差；不改工具unknown，不认证毛伤、逐来源或完整候选。'})

potions = []
for decision, before, after, slot, potion in [
    (274131, 280206, 280207, 0, 'ATTACK_POTION'), (274156, 280232, 280233, 0, 'STABLE_SERUM'),
    (274185, 280262, 280263, 0, 'SPEED_POTION'), (274235, 280313, 280314, 1, 'WEAK_POTION'),
    (274237, 280315, 280316, 0, 'ATTACK_POTION'), (274267, 280348, 280349, 1, 'GLOWWATER_POTION'),
    (274272, 280354, 280355, 0, 'SKILL_POTION')]:
    d = decisions[decision]['row']
    check(f'药水{decision}请求', d['chosen']['action'], 'use_potion')
    a = next(x for x in states[before]['row']['state']['run']['potions'] if x['index'] == slot)
    b = next(x for x in states[after]['row']['state']['run']['potions'] if x['index'] == slot)
    check(f'药水{decision}前槽', a['potion_id'], potion)
    check(f'药水{decision}后槽空', b['occupied'], False)
    potions.append({'decision_line': decision, 'state_lines': [before, after], 'slot': slot,
                    'potion': potion, 'result': d['result'], 'after_occupied': b['occupied'],
                    'full_candidate_verified': None})
check('KEN七次中pending原回执', sum('pending' in p['result'] for p in potions), 3)

blast = []
for line, poison in [(280160, 2), (280161, 8)]:
    s = states[line]['row']['state']
    c = s['combat']; e = c['enemies'][0]
    values = [s['run']['current_hp'], c['player']['block'], e['intents'][0]['damage'], e['max_hp']]
    check(f'巨兽{line}血挡来袭占位', values, [26, 13, 41, 999999999])
    check(f'巨兽{line}毒层', next(x['amount'] for x in e['powers'] if x['power_id'] == 'POISON_POWER'), poison)
    blast.append({'state_line': line, 'hp': 26, 'block': 13, 'incoming': 41, 'poison': poison})
check('KEN末回合结束前9攻击', states[280722]['row']['state']['combat']['enemies'][0]['intents'][0]['damage'], 9)
check('KEN末回合死亡截断实扣', [states[x]['row']['state']['run']['current_hp'] for x in [280722, 280723]], [6, 0])
result = {'scope': '固定材料核验；不属于tsc/vitest/撤源码负控，不证明自然消费者或整战因果。',
          'assertions_passed': len(checks), 'checks': checks, 'audits': audit_summary, 'selected_turns': selected_turns,
          'kv_manual_endpoints': manual, 'ken_potions': potions, 'giant_potion_observation': blast}
(scratch / 'facts-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_assertions': len(checks), 'audits': audit_summary}, ensure_ascii=False))

from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0555';pub=root/'paper/materials/20261016-0555-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda path:json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-054302-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();original=load(s/'final.json')
assert report==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert {k:v for k,v in report.items() if k!='proposal_results'}=={k:v for k,v in original.items() if k!='proposal_results'}
assert [(x['id'],x['state']) for x in report['proposal_results']]==[(x['id'],x['state']) for x in original['proposal_results']] and all(x['reason'] for x in original['proposal_results'])
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(b['proposal_ids'])==set(report['code_proposals'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'final-validation.json');assert final['base']==report['base'] and final['clean_worktree'] and final['new_source_commits']==[] and final['ledger_updates']==16 and final['gitleaks']==0
assert final['report_sha256']==sha((s/'report.md').read_bytes()) and final['proposal_sha256']==sha((s/'proposal.md').read_bytes())
source=load(s/'source-review.json');live=source['live_head'];assert source['base']==report['base'] and len(source['sources'])==13 and git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip()==live
for item in source['sources']:
    a=git('show',report['base']+':'+item['path']);z=git('show',live+':'+item['path'])
    assert sha(a)==item['base_sha256'] and sha(z)==item['live_sha256'] and (a==z)==item['same_bytes'] and (root/'.worktrees/live'/item['path']).read_bytes()==z and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
    assert item['ancestor']==dict(base=True,live=True);git('merge-base','--is-ancestor',item['feature_source_commit'],report['base']);git('merge-base','--is-ancestor',item['feature_source_commit'],live)
assert sum(x['same_bytes'] for x in source['sources'])==12
assigned=load(s/'dispatched-proposals.json');assert len(assigned)==10 and {x['id'] for x in assigned}==set(report['code_proposals'])
for item in source['original_proposals']:
    f=Path(item['path']);raw=f.read_bytes();proposal=next(x for x in assigned if x['id']==item['id']);assert f.is_relative_to(root) and len(raw)==item['bytes'] and sha(raw)==item['sha256']==proposal['proposal_sha256']
extract=module('original_extract',root/'learner/extract_evidence.py');review=load(s/'evidence-review.json');counts={};runs={};rows={key:{} for key in ['states','decisions']}
for entry in review['streams']:
    stream=entry['stream'];folder=s/('evidence-extra' if stream in ['runs','fight-plans'] else 'evidence');h=hashlib.sha256();seen=collections.Counter()
    with (folder/(stream+'.evidence.jsonl')).open('rb') as selected,(root/'logs'/(stream+'.jsonl')).open('rb') as sourcefile:
        for line in selected:
            h.update(line);e=json.loads(line);sourcefile.seek(e['offset']);raw=sourcefile.read(e['bytes']);r=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and r==e['row'] and e['offset']+e['bytes']<=entry['source_size'] and extract.run_identity(r)==e['run_id'] in report['runs']
            if stream=='states':assert (r['state']['run']['character_id'],r['state']['run']['ascension'])==('SILENT',10)
            if stream=='runs':assert (r['character'],r['ascension'],r['victory'])==('SILENT',10,False);runs[e['run_id']]=r
            if stream in rows:rows[stream][e['line']]=dict(run=e['run_id'],row=r,sha256=e['sha256'])
            seen[e['run_id']]+=1
    assert h.hexdigest()==entry['output_sha256'] and dict(seen)=={k:v for k,v in entry['counts'].items() if v};counts[stream]=sum(seen.values())
assert sum(counts.values())==review['verified_raw_lines']==8444 and len(runs)==6
facts=load(s/'facts-review.json');assert facts['assertions_passed']==len(facts['checks'])==77 and all(x['actual']==x['expected'] for x in facts['checks'])
totals=collections.Counter();audits=facts['audits'];assert len(audits)==6
for item in audits:
    run=item['run_id'];ip=s/(run+'.audit-input.json');op=s/(run+'.audit-output.json');assert item['exit_code']==0 and sha(ip.read_bytes())==item['input_sha256'] and sha(op.read_bytes())==item['output_sha256'] and (s/(run+'.audit-stderr.txt')).read_bytes()==b''
    data=load(ip);audit=load(op);assert data['run']==runs[run]
    for stream in rows:
        selected={line:x for line,x in rows[stream].items() if x['run']==run and (stream!='decisions' or x['row'].get('decision_id'))};assert {x['_line'] for x in data[stream]}==set(selected)
        for row in data[stream]:
            ref=selected[row['_line']];expected={**ref['row'],'_line':row['_line'],'_source_sha256':ref['sha256']}
            if stream=='decisions':expected.pop('agent_view',None)
            assert row==expected
    turns=collections.Counter(x['status'] for x in audit['observed_turns']);assert turns==item['turn_status_counts'] and len(audit['segments'])==item['segments'] and len(audit['observed_actions'])==item['observed_actions'] and len(audit['observed_turns'])==item['observed_turns']
    assert item['full_candidate_certified']==0 and all(x['actual_full_candidate_result'] is None for x in audit['segments'])
    totals.update(segments=len(audit['segments']),actions=len(audit['observed_actions']),turn_windows=len(audit['observed_turns']),known=turns['observed_turn_endpoints'],unknown=turns['unknown'])
assert totals==dict(segments=861,actions=4065,turn_windows=777,known=415,unknown=362)
link=load(s/'ledger-link-verification.json');inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()];assert link['exit_code']==0 and len(inputs)==link['updates']==16 and link['protected_fields_unchanged'] and link['old_where_notes_history_prefixes_preserved'] and link['no_new_evidence_or_status']
assert sha((s/'ledger-update-input.jsonl').read_bytes())==link['input_sha256'] and (s/'ledger-update.stderr').read_bytes()==b'' and set((s/'ledger-update.stdout').read_text().split())=={x['id'] for x in inputs}==set(link['ids'])
owned=[];offset=0
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    for raw in handle:
        row=json.loads(raw)
        if any(all(row.get(k)==v for k,v in item.items()) for item in inputs):
            assert set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal';owned.append(dict(offset=offset,bytes=len(raw),sha256=sha(raw),row=row,raw=raw))
        offset+=len(raw)
assert len(owned)==16
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert not {x['raw'].rstrip(b'\n') for x in owned}&set(old.splitlines());added=b''.join(x['raw'] for x in owned)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
owned_receipt=[{k:v for k,v in x.items() if k!='raw'} for x in owned]
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,longer_original_report=original,report_reason_scope='Stdout/learn shorten waiting reasons; full original reasons remain unchanged.',native=native,final=final,source=source,stream_counts=counts,original_rows_verified=8444,material_assertions=77,offline_receipts=audits,consumer_counts=dict(totals),owned_trace_rows=owned_receipt,protected_old_fields_and_prefixes_preserved=True,limits=['Seven specified fingerprint pairs and24historical SL replacements are not controlled full-fight comparisons.','KV manual net endpoints do not override strict tool unknown. KEN seven requests include three pending; empty slots do not certify full benefit.','PU F17 win with2HP retained; no uniform giant/exploration/HP price rules inferred.','Original null-combat/path/anchor probes remain. No new gameplay contradiction or other role acknowledgment.','No source, merge blockage, release, production test, audit rerun, paper refresh, dispatch or game restart. Broad parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<600000]+[s/folder/'evidence-manifest.json' for folder in ['evidence','evidence-extra']]+[Path(x['path']) for x in source['original_proposals']]+[out,out.with_suffix('.err')]
    for f in sorted(set(files)):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0555原054302策略done0/no-source核收，e9b5基线干净工作树/HEAD不变，十waiting短/长原理由并留/testsnull/mergednull，无提交或合入受阻。六Silent A10八流8444原行逐offset/bytes/SHA/JSON/显式身份核，77原材料断言与六原有界离线input/output/SHA/原始投影核，861题段/4065动作/777轮窗（415可核362未知）、整候选全null；六无id路线元数据不补号/跨缺口认证，7指定同指纹组与24旧SL替换不当受控实验。KV人工净扣端点不覆盖工具unknown；KEN七饮请求三pending/空槽与完整收益分列；PU F17实际余2血胜战边界保，不拟统一6血/2伤、SL血价、留药或新排序规则。13相关源码12同1历史Roy/Dai注释差及真实base/live子项来源祖先核，历史dirty完整输入和消费者未复原，窄提示不关闭十宽项。16所属CLI只where/note追溯，原行offset/bytes/SHA及私有fold旧claim/首证/prior/evidence/status/version和history/notes/where前缀保持，不重复CLI/support/repeat。原null-combat/猜路径/误读anchor探针保留；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network另核。仅所属记录/16追溯提交，保并行记录；无源码/合入/发号/补测/论文刷新/复派/对局或账号home模型权限prompt改变，不关闭宽父。证据paper/materials/20261016-0555-ops/。\n'
note=f'\n- {at} [运维 codex] 原054302策略十项均waiting，无源码修改或合入阻塞；原证据和16条所属追溯核收，unknown/pending及完整后继缺口保持。仅记录提交，无新发布或补测。回执paper/materials/20261016-0555-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=16,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=8444,owned_trace_rows=16,ledger_check=0,paths=len(entries))))

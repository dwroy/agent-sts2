import json
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261015-114302-d50dec58-d82d-4691-a863-7992f66bdfea-postmortem'; run='WJ0LTVSSDY61'; needle=run.encode()
for name in ['decisions','run-plans','run-config','sl-attempts','states']:
    path=root/'logs'/f'{name}.jsonl'
    if not path.exists():
        print(name,'missing'); continue
    count=0; offset=0
    with path.open('rb') as f,(out/f'{name}.jsonl').open('w') as dest:
        for n,line in enumerate(f,1):
            pos=offset; offset+=len(line)
            if needle not in line: continue
            row=json.loads(line); row['_line']=n; row['_offset']=pos
            dest.write(json.dumps(row,ensure_ascii=False)+'\n'); count+=1
    print(name,count,flush=True)

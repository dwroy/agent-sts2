import json,re,collections,datetime
from pathlib import Path
p=Path(__file__).parent; D=[json.loads(l) for l in (p/'decisions.jsonl').open()]; S=[json.loads(l) for l in (p/'states.jsonl').open()]; R=json.loads((p/'WJ0LTVSSDY61-resources.json').read_text())
j=[r for r in D if r['decider']=='jev']; combat=[r for r in j if r['label'].startswith('combat/')]; low=lambda rs:[r['_line'] for r in rs if isinstance(r.get('confidence'),(int,float)) and r['confidence']<.35]
print('COUNT',len(j),len(combat),'LOW',low(j),'COMBATLOW',low(combat),'BEST',dict(collections.Counter(r.get('rollout_best_chosen') for r in combat)))
ranks=[re.search(r'code rank (\d+)',r['rationale']) for r in combat]; ranks=[int(r[1]) for r in ranks if r];print('rank1',ranks.count(1),'denom',len(ranks))
aut=[r for r in D if r['decider']=='code' and r['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]; windows={(r['floor'],r.get('sl_reloads'),r['turn']) for r in aut};print('AUTO',len(aut),collections.Counter(r['label'] for r in aut),'windows',len(windows),'notcompleted',[(r['_line'],r['result']) for r in aut if 'completed' not in r['result'].lower()])
print('rawcode',sum(r['decider']=='code' for r in D),'jevcontinuations',sum(r['decider']=='code' and 'continuing the Jev-chosen plan' in r['rationale'] for r in D))
for r in D:
 if 'HP guard:' in r['rationale']:print('HPGUARD',r['_line'],r['rationale'])
focus=[]
for r in combat:
 criteria=r['questions']['plan'].get('criteria') or {}; parsed={}
 for k,v in criteria.items():
  try:parsed[k]=json.loads(v) if isinstance(v,str) else v
  except:pass
 opts={k:{a:b for a,b in v.items() if 'focus' in a.lower()} for k,v in parsed.items() if isinstance(v,dict) and any('focus' in a.lower() for a in v)}
 if opts:focus.append({'line':r['_line'],'f':r['floor'],'t':r['turn'],'opts':opts,'answers':r.get('answers')})
print('FOCUS',len(focus),focus[:6]); (p/'focus.json').write_text(json.dumps(focus,ensure_ascii=False,indent=2))
print('USAGE Jev', {k:sum((r.get('usage') or {}).get(k,0) or 0 for r in D if r['decider']=='jev') for k in ['input_tokens','output_tokens']});print('DURATION',(datetime.datetime.fromisoformat(D[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(D[0]['ts'].replace('Z','+00:00'))).total_seconds())
for r in [r for r in D if r['decider']=='codex' and r.get('questions') and r['label'] in ['rest/plan','event/act-plan']]:
 print('BOSS/ROUTE',r['_line'],r['floor'],'questionkeys',list(r['questions']))
 for q in r['questions'].values():
  if not isinstance(q,dict):continue
  facts=q.get('facts') or {}; print('FACTKEYS',list(facts));
  for k,v in facts.items():
   if any(w in k for w in ['clock','route','projection','boss_sim']):print(k,json.dumps(v,ensure_ascii=False)[:5000])
  for k,v in (q.get('criteria') or {}).items():
   try:v=json.loads(v) if isinstance(v,str) else v
   except:continue
   if isinstance(v,dict):print('OPT',k,{a:b for a,b in v.items() if any(w in a for w in ['hp','route','boss','action','name'])})
print('ENEMY_NAMES')
seen={}
for r in S:
 for e in (r['state'].get('combat') or {}).get('enemies',[]):seen[e['enemy_id']]=e['name']
print(seen)

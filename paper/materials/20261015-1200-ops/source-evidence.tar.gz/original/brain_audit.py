import json
from pathlib import Path
p=Path(__file__).parent; path=Path('/home/dw/Projects/agent-sts2/logs/brain.jsonl'); run='WJ0LTVSSDY61'; rows=[]
with path.open('rb') as f:
 f.seek(max(0,path.stat().st_size-64*1024*1024)); f.readline()
 while True:
  off=f.tell(); l=f.readline()
  if not l:break
  if run.encode() not in l:continue
  r=json.loads(l)
  if r.get('run_id')==run:r['_offset']=off;rows.append(r)
with (p/'brain-run.jsonl').open('w') as f:
 for r in rows:f.write(json.dumps(r,ensure_ascii=False)+'\n')
print('brain count',len(rows),'model',set((r.get('model'),r.get('effort')) for r in rows),'accept',sum(r.get('accepted') is True for r in rows))
print('USAGE',{k:sum((r.get('usage') or {}).get(k,0) or 0 for r in rows) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']})
for r in rows:
 if r['label'] in ['rest/plan','event/act-plan','map/route-plan']:
  print('ROW',r['ts'],r['label'],'question',type(r['question']).__name__,'payloadkeys',list(r.get('payload') or {}),'memorykeys',list(r.get('memory') or {}))
  q=r['question']; payload=r.get('payload') or {}
  def scan(obj,path=''):
   if isinstance(obj,dict):
    for k,v in obj.items():
     if k in ['act_boss_clock','route_hp_projection','route_projections','projected_route','boss_entry_hp','route_hp','boss_readiness']:
      print(path+'.'+k,json.dumps(v,ensure_ascii=False)[:5000])
     else:scan(v,path+'.'+k)
   elif isinstance(obj,list):
    for i,v in enumerate(obj):scan(v,path+f'[{i}]')
  scan(payload)

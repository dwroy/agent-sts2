import json
from pathlib import Path
p=Path(__file__).parent; logs=Path('/home/dw/Projects/agent-sts2/logs')
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]; start=D[0]['ts']; end=D[-1]['ts']
for name in ['deepseek-reasoning','brain']:
 path=logs/f'{name}.jsonl'; size=path.stat().st_size; span=64*1024*1024
 while True:
  offset=max(0,size-span)
  with path.open('rb') as f:
   f.seek(offset)
   if offset: f.readline()
   first=f.readline(); row=json.loads(first)
  if row.get('ts','')<=start or offset==0: break
  span*=2
 count=0
 with path.open('rb') as f,(p/f'{name}-window.jsonl').open('w') as out:
  f.seek(offset)
  if offset: f.readline()
  while True:
   pos=f.tell(); line=f.readline()
   if not line: break
   row=json.loads(line)
   if start<=row.get('ts','')<=end:
    row['_offset']=pos; out.write(json.dumps(row,ensure_ascii=False)+'\n'); count+=1
 print(name,'offset',offset,'first_ts',json.loads(first).get('ts'),'matches',count)

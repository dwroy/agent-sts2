import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(x) for x in (p/'decisions.jsonl').open()]; S=[json.loads(x) for x in (p/'states.jsonl').open()]; R=json.loads((p/'WJ0LTVSSDY61-resources.json').read_text())
with (p/'state-audit.txt').open('w') as out:
 for r in S:
  s=r['state']; run=s.get('run') or {}; f=run.get('floor')
  if f not in [12,15,17,19,21,22,23]: continue
  c=s.get('combat') or {}; player=c.get('player') or {}
  row={'line':r['_line'],'ts':r['ts'],'f':f,'t':s.get('turn'),'screen':s.get('screen'),'hp':run.get('current_hp'),'max':run.get('max_hp'),'combat_keys':list(c),'player':player,'hand':c.get('hand'),'enemies':c.get('enemies'),'potions':run.get('potions')}
  print(json.dumps(row,ensure_ascii=False),file=out)
with (p/'decision-audit.txt').open('w') as out:
 for r in D:
  if r['floor'] not in [17,19,21,22,23]: continue
  keys=['_line','ts','floor','turn','decider','label','sl_attempt','sl_reloads','chosen','rationale','confidence','rollout_best_chosen','rollout','selection_audit','journal','result']
  print(json.dumps({k:r[k] for k in keys if k in r},ensure_ascii=False),file=out)
print('Jev',len([r for r in D if r['decider']=='jev']),'rawcode',sum(r['decider']=='code' for r in D))
j=[r for r in D if r['decider']=='jev']; print('confidence',collections.Counter(r.get('confidence') for r in j)); print('best',collections.Counter(r.get('rollout_best_chosen') for r in j));
for r in D:
 if any(w in json.dumps({k:r.get(k) for k in ['rationale','journal','selection_audit']},ensure_ascii=False).lower() for w in ['guard','护栏','hp-','hp guard']): print('GUARD',r['_line'],r['floor'],r['turn'],r['rationale'],r.get('selection_audit'))
print('changes')
for r in R['resource_changes']:
 a,b=r['from'],r['to']; print(a['line'],b['line'],'F',a['floor'],b['floor'],'T',a['turn'],b['turn'],'HP',a['hp'],b['hp'],'POT',a['potions'],b['potions'],'SL',r['restart_boundary'])
print('sample combat keys',S[4]['state'].keys())
for r in S:
 if (r['state'].get('run') or {}).get('floor')==23:
  print('state combat first',json.dumps(r,ensure_ascii=False)[:7000]); break

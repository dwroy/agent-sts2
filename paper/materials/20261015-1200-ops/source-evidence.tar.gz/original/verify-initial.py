import json,subprocess,re,hashlib
from pathlib import Path
p=Path(__file__).parent; root=Path('/home/dw/Projects/agent-sts2'); run='WJ0LTVSSDY61'
D=[json.loads(l) for l in (p/'decisions.jsonl').open()]; S=[json.loads(l) for l in (p/'states.jsonl').open()]; R=json.loads((p/f'{run}-resources.json').read_text()); sd={r['_line']:r for r in S}; dd={r['_line']:r for r in D}
expected=[(2,56,56),(3,56,52),(5,52,52),(6,52,52),(7,52,38),(11,66,66),(12,66,28),(14,51,43),(15,43,16),(17,64,20),(19,65,59),(21,59,43),(22,43,18),(23,18,2),(23,18,8),(23,18,2),(23,18,0)]
for b,(f,a,z) in zip(R['combats'],expected):
 assert b['floor']==f and b['entry']['hp']==a and (b.get('exit') or b['last'])['hp']==z
 assert b['entry_is_turn_one']
assert len(R['combats'])==17 and len(D)==472 and len(S)==489
assert sd[409890]['state']['run']['current_hp']==4
c=sd[409890]['state']['combat']; assert c['player']['block']==13 and [x['current_hp'] for x in c['enemies']]==[40,57]
assert c['enemies'][1]['intents'][0]['damage']==9 and c['enemies'][1]['intents'][0]['hits']==2
assert sd[409891]['state']['run']['current_hp']==0
assert dd[397173]['selection_audit']['answer']['turn']['cards_drawn']==1
before=sd[409886]['state']['combat']; after=sd[409887]['state']['combat']
assert before['player']['energy']==3 and after['player']['energy']==2 and after['player']['block']==6
assert [x['card_id'] for x in after['hand']]==[x['card_id'] for x in before['hand'] if x['card_id']!='CLOAK_AND_DAGGER']+['SHIV']
a=dd[397195]['selection_audit']; assert a['answer']['turn']['hp_loss']==9 and a['after_sl']['turn']['hp_loss']==14 and a['sl_delta']=={'hp_loss':5,'damage':21,'strength_gained':0,'lasting_value':8}
for k,v in [('plan5',(9,28)),('plan6',(14,28))]:
 x=json.loads(dd[397195]['questions']['plan']['criteria'][k]); assert (x['hp_lost'],x['damage_dealt'])==v and '24/24' in x['rollout']
assert sum(r['chosen']['action']=='use_potion' for r in D)==8
assert sum(r['chosen']['action']=='discard_potion' for r in D)==0
assert not any('HP guard:' in r['rationale'] for r in D)
j=[r for r in D if r['decider']=='jev'];assert len(j)==92 and sum((r.get('confidence') or 0)<.35 for r in j)==11
assert sum((r.get('usage') or {}).get('input_tokens',0) for r in j)==617078
assert sum((r.get('usage') or {}).get('output_tokens',0) for r in j)==4992
B=[json.loads(l) for l in (p/'brain-run.jsonl').open()]; assert len(B)==22 and all(r['model']=='gpt-6.1-sol' and r['effort']=='xhigh' and r['accepted'] for r in B)
commit='ec74a49ce41370c10540c795338cbe5eecb78846'; live=root/'.worktrees/live'
ancestor=subprocess.run(['git','-C',str(live),'merge-base','--is-ancestor',commit,'HEAD'],capture_output=True)
assert ancestor.returncode==0
changes=subprocess.run(['git','-C',str(live),'show','--pretty=format:','--name-only',commit],capture_output=True,text=True,check=True).stdout.splitlines()
assert all(x in changes for x in ['agent/src/reflex/card-model.ts','agent/src/reflex/combat-plan.ts','agent/src/reflex/turn-solver.ts'])
report={'run':run,'checked':'资源链、死亡端点、生成语义、SL同题差、药水动作、Jev计数与token、原生模型、既有修复源码祖先','ok':True,'implemented_source':commit,'live_source':subprocess.run(['git','-C',str(live),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip(),'source_dirty_diff_bytes':(p/'live-uncommitted-source.diff').stat().st_size,'draft_sha256':hashlib.sha256((p/'lesson-section.md').read_bytes()).hexdigest()}
(p/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))

from pathlib import Path
import json,subprocess,hashlib,importlib.util,os,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-1926';pub=r/'paper/materials/20261015-1926-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip();old=git('show',base+':paper/materials/learning/ledger.jsonl');owned=(p/'owned-ledger.jsonl').read_bytes();assert owned.strip() not in old.splitlines();row=json.loads(owned);assert set(row)<={'op','id','ts','by','note','where'};new=old+owned
spec=importlib.util.spec_from_file_location('ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1)])
a=fold(old);b=fold(new);assert set(a)==set(b)
for ident in a:
 for k in ['claim','first_run','asc','prior','prior_note','prior_runs','evidence','status','version','shipped_at','effect']:assert a[ident].get(k)==b[ident].get(k),(ident,k)
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'fix-readback.py',p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
(pub/'ops-helper-manifest.json').write_text(json.dumps(helpers,ensure_ascii=False,indent=2)+'\n')
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();(pub/'completion.json').write_text(json.dumps({'at':at,'batch':'20261015-191301-fix-batch','canonical':'failed/rc0/mergednull','no_new_source_commit_or_merge_blocker':True,'selected_original_cases':12,'filtered_unrun':0,'full_suite_or_checks_repeated':False,'owned_trace_ledger_rows':1,'protected_ledger_fields_preserved':True,'source_ancestry_verified':73,'native_model_and_input_and_original_sandbox_verified':True,'V5_S_owner_final_material_actually_received':True,'old_0332_F48_recurring_groups_added':2,'no_other_role_ACK':True,'no_release_dataset_runtime_or_duplicate_task':True},ensure_ascii=False,indent=2)+'\n')
values={path:git('show',base+':'+path)+text.encode() for path,text in json.loads((p/'own-appends.json').read_text()).items()};values['paper/materials/learning/ledger.jsonl']=new
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
rows=[];dest=p/'final-files'
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);rows.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
(p/'record-manifest.json').write_text(json.dumps({'base':base,'paths':rows},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'base':base,'paths':len(rows),'ledger_check':0,'own_ledger_rows':1}))

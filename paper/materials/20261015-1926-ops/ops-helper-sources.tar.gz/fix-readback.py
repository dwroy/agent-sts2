from pathlib import Path
import json, subprocess, hashlib, re, tarfile
root = Path.cwd(); r = root; p = r / 'ops/codex-ops/record-staging/20261015-1926'; pub = r / 'paper/materials/20261015-1926-ops'; sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-191301-fix-batch'; b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]; report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'failed' and b['rc'] == 0 and not b['proposal_audit_errors']
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and report['code_proposals'] == []
assert report['tests'] == {'tsc': 0, 'vitest': 0, 'cases': 12}
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
audit = json.loads((s / 'audit.json').read_text()); assert len(audit['existing_fixes']) == 73 and audit['new_fixes'] == [] and audit['merge_performed'] is False
assert sha((s / 'queue-snapshot.md').read_bytes()) == audit['queue_sha256']
assert sha(Path(audit['prior_audit']).read_bytes()) == audit['prior_audit_sha256']
for row in audit['existing_fixes']:
    for target in [report['base'], audit['live_read_only_snapshot']]: git('merge-base', '--is-ancestor', row['source_commit'], target)
    assert sha(git('show', report['base'] + ':' + row['path'])) == row['current_source_sha256']
coverage = audit['verification']; assert coverage['files'] == 7 and coverage['cases'] == 12 and coverage['full_test_sandbox_run'] is False and coverage['reruns'] == []
for ref in coverage['logs'].values(): assert sha(Path(ref['path']).read_bytes()) == ref['sha256']
assert (s / 'tsc.exit').read_text().strip() == (s / 'vitest.exit').read_text().strip() == '0'
assert audit['source_change_bytes'] == 0 and audit['ledger_updates'] == 0 and audit['code_proposals'] == audit['implementation_domains'] == []
for ref in audit['record_readbacks']: assert sha(Path(ref['path']).read_bytes()) == ref['sha256']
receipt = {'batch':bid,'canonical_state':b['state'],'canonical_rc':b['rc'],'original_report':report,'native':native,'original_73_ancestors_and_base_source_hashes_verified':True,'original_source_review':audit['source_review'],'original_queue_snapshot':{'lines':audit['queue_lines'],'sha256':audit['queue_sha256']},'original_coverage':coverage,'coverage_interpretation':'tsc0 and7 selected files/12 cases passed, no reruns. No full-suite pass asserted.','prior_0311_correction_and_0332_triage_hashes_verified':audit['record_readbacks'],'source_preparation_error':audit['preparation_note'],'no_new_commit_or_merge_blocker':True,'canonical_failed_rc0_mergednull_preserved':True,'no_repeated_checks_full_release_dataset_or_ledger_mutation':True,'wide_items_and_original_owners_unchanged':True}
(pub / 'fix-readback.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
manifest = []
with tarfile.open(pub / 'fix-original-artifacts.tar.gz', 'w:gz') as tar:
    for f in list(s.iterdir()) + [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]:
        if not f.is_file(): continue
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'fix-original-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'existing_fixes': 73, 'no_new_commit': True, 'canonical': 'failed/rc0/mergednull', 'selected_checks_only': 12, 'reruns': 0}))

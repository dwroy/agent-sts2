import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-191301'
OUT = ROOT / 'learner/runs/20261015-191308-f6b1a413-b614-4a6d-a0ca-e940f9d1a805-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-184313-e4988612-605c-4fbd-85c7-1abb985854ab-fix-batch/audit.json'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, ref):
    result = subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, ref], capture_output=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr.decode())
    return result.returncode == 0


previous = json.loads(PRIOR.read_bytes())
base = git('rev-parse', 'HEAD').decode().strip()
live = subprocess.check_output(['git', '-C', str(ROOT / '.worktrees/live'), 'rev-parse', 'HEAD']).decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
(OUT / 'queue-snapshot.md').write_bytes(queue)
(OUT / 'baseline-change.diff').write_bytes(git('diff', '--binary', previous['base'], base))
source_diff = git('diff', '--binary', previous['base'], base, '--', 'agent', 'learner', 'ops', 'knowledge/builders', ':!ops/inbox-dev.md')
(OUT / 'source-change.diff').write_bytes(source_diff)
(OUT / 'source.diff').write_bytes(git('diff', '--binary', 'HEAD'))
queue_diff = git('diff', '--binary', previous['base'], base, '--', 'notes/fix-queue-v4.md')
(OUT / 'queue-change.diff').write_bytes(queue_diff)
fixes = []
for entry in previous['existing_fixes']:
    data = (WORK / entry['path']).read_bytes()
    sha = digest(data)
    checked = {
        'item': entry['item'], 'source_commit': entry['source_commit'], 'path': entry['path'],
        'current_source_sha256': sha,
        'same_as_prior_audit': sha == entry['current_source_sha256'],
        'ancestor_in_base': ancestor(entry['source_commit'], base),
        'ancestor_in_live_snapshot': ancestor(entry['source_commit'], live),
    }
    fixes.append(checked)

if source_diff or any(not (row['same_as_prior_audit'] and row['ancestor_in_base'] and row['ancestor_in_live_snapshot']) for row in fixes):
    raise RuntimeError('Source or ancestry changed; independent review required')

skipped = previous['skipped']
for item in skipped:
    if item['item'].startswith('silent-0311'):
        item['reason'] = '策略类/模型：已有 silent-proposal-d2f24919ee64b90b，沿独立 strategy-proposal 处理。最新队列已追加更正：2LZHP9BYFTHE 的 s412004/412017/412046 为 A10 F37 T1/4/10；不补固定倍率，不把旧 F38 定位当新证据。'
    elif item['item'].startswith('silent-0332'):
        item['reason'] = '证据不足：RQCHNN0W72KF A10 F40 的 seed607614716 已定位 nonpositive-hp 分支，但完整末资源/steps 与机制根因仍未知；当前 continuationInput 保留正 HP 资源契约。已有 silent-proposal-5aa2672bd7cd1bf4 沿独立 structure 实现链，不猜造成功资源或降低样本门槛。'

audit = {
    'base': base, 'live_read_only_snapshot': live,
    'queue_sha256': digest(queue), 'queue_lines': len(queue.splitlines()),
    'prior_audit': str(PRIOR), 'prior_audit_sha256': digest(PRIOR.read_bytes()),
    'existing_fixes': fixes, 'new_fixes': [], 'skipped': skipped,
    'source_change_bytes': len(source_diff),
    'source_review': '73项当前源码逐SHA相同，全部来源均为base/live祖先；与前批基线相比无源码/测试变化，只有队列旧项补证、定位勘误与ops收件箱记录。',
    'unchecked_items': [{'line': n, 'text': line} for n, line in enumerate(queue.decode().splitlines(), 1) if line.startswith('- [ ]')],
    'worktree_status': git('status', '--short').decode(),
    'ledger_updates': 0, 'merge_performed': False,
    'code_proposals': [], 'implementation_domains': [],
}
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'live': live, 'existing_fixes': len(fixes), 'source_change_bytes': len(source_diff), 'unchecked': len(audit['unchecked_items']), 'worktree_clean': audit['worktree_status'] == ''}, ensure_ascii=False))

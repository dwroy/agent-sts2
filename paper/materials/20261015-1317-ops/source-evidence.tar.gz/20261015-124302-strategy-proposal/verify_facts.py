"""Verify observed endpoints, without claiming production-model validation."""
import json
from pathlib import Path

S = Path(__file__).resolve().parent
rows = [json.loads(x) for x in (S / 'state-projection.jsonl').open()]
by_line = {r['line']: r for r in rows}
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


def at(line):
    return by_line[line]


def attack(row):
    return sum(i.get('total_damage') or 0 for e in row['enemies'] if e['is_alive'] for i in e['intents'] or [])


def poison(line, index):
    return at(line)['enemies'][index]['powers'].get('POISON_POWER', 0)


# An act-id change is an unhealed MAP frame, before the next floor settles healing.
settled = []
for run in json.loads((S / 'verified-runs.json').read_text())['runs']:
    game = [r for r in rows if r['run_id'] == run]
    for floor in [18, 34]:
        after = next((r for r in game if r['floor'] == floor), None)
        if after is None:
            continue
        before = next((r for r in reversed(game) if r['floor'] == floor-1 and r['line'] < after['line']), None)
        if before is None:
            continue
        item = {'run_id':run, 'ascension':after['ascension'],
            'before':{k:before[k] for k in ['line','offset','sha256','floor','screen','hp','max_hp']},
            'after':{k:after[k] for k in ['line','offset','sha256','floor','screen','hp','max_hp']},
            'actual_heal':after['hp']-before['hp'],
            'observed_formula':(before['max_hp']-before['hp'])*4//5}
        settled.append(item)
        check(run+f' F{floor} max HP unchanged', after['max_hp'], before['max_hp'])
        check(run+f' F{floor} settled healing', item['actual_heal'], item['observed_formula'])
check('settled transition pairs across the fifteen selected games',len(settled),22)

check('RC F23 speed adds temporary Dexterity',at(285224)['powers']['DEXTERITY_POWER']-at(285223)['powers']['DEXTERITY_POWER'],5)
check('RC F23 card and passive Block sequence',[at(n)['block'] for n in [285224,285225,285227,285229]],[0,12,21,25])
check('RC F23 next-turn temporary powers clear',[at(285230)['powers'].get(p,0) for p in ['DEXTERITY_POWER','ANTICIPATE_POWER','SPEED_POTION_POWER']],[0,0,0])
check('RC F29 Phantom Blades established at nine',at(285281)['powers']['PHANTOM_BLADES_POWER'],9)
check('RC F29 establishing Phantom Blades does not add existing Block',at(285281)['block'],at(285280)['block'])
check('RC F29 observed first Shiv HP delta',at(285291)['enemies'][0]['current_hp']-at(285292)['enemies'][0]['current_hp'],14)
check('RC F33 Survivor actually consumes the remaining hand',[c['card_id'] for c in at(285415)['hand']],[])
check('B F31 Survivor starts with one other card',[c['card_id'] for c in at(286161)['hand']],['SURVIVOR','SUCKER_PUNCH'])
check('B F31 Survivor consumes that hand',[c['card_id'] for c in at(286162)['hand']],[])
check('B F31 actual HP loss',at(286158)['hp']-at(286163)['hp'],14)
check('B F31 observed card Block',at(286162)['block'],13)

check('X F48 poison victory costs HP',[at(n)['hp'] for n in [286893,286894,286896]],[32,23,23])
check('X F49 first stable hand',[c['card_id'] for c in at(286897)['hand']],['ASCENDERS_BANE'])
check('X F49 first stable energy and Block',[at(286897)['energy'],at(286897)['block']],[3,16])
check('X F49 Ghost adds one observed layer',at(286898)['powers'].get('INTANGIBLE_POWER'),1)
check('X F49 Ghost changes incoming attack',[attack(at(286897)),attack(at(286898))],[26,1])
check('X F49 observed Ghost turn costs no HP',[at(286897)['hp'],at(286899)['hp']],[23,23])
check('X F49 Clamp carryover',at(286899)['block'],10)
check('X F49 T3 actual HP loss',at(286978)['hp']-at(286982)['hp'],22)
check('X F49 T3 actual enemy HP delta',sum(e['current_hp'] for e in at(286978)['enemies'])-sum(e['current_hp'] for e in at(286982)['enemies']),32)
check('X F49 T4 pending copies',at(286986)['powers'].get('NIGHTMARE_POWER'),3)
check('X F49 T4 terminal HP before truncation',at(286986)['hp']-max(0,attack(at(286986))-at(286986)['block']),-9)
check('X F49 T4 actual HP is truncated at zero',at(286987)['hp'],0)

check('9Z F48 T10 first and later Block gains',[at(288000)['block'],at(288003)['block']-at(288002)['block'],at(288004)['block']-at(288003)['block']],[18,9,10])
check('9Z F48 T10 actual HP loss',at(288004)['hp']-at(288005)['hp'],15)
check('9Z F48 terminal enemy HP delta',at(288006)['enemies'][0]['current_hp']-at(288008)['enemies'][0]['current_hp'],80)
check('9Z terminal 80 is two poison settlements plus observed single retaliation',39+38+3,80)
check('7X F31 back-segment poison before and after potion',[poison(288470,2),poison(288471,2)],[0,7])
check('7X F31 potion does not immediately change enemy HP',[e['current_hp'] for e in at(288470)['enemies']],[e['current_hp'] for e in at(288471)['enemies']])
check('7X F31 back-segment actual poison damage',at(288471)['enemies'][2]['current_hp']-at(288472)['enemies'][2]['current_hp'],7)
check('7X F31 potion turn still dies',at(288472)['hp'],0)

check('MTQ F23 matched T3 HP and enemy HP',[at(n)['hp'] for n in [288806,288899]],[10,10])
check('MTQ F23 matched T3 enemy HP',[e['current_hp'] for e in at(288806)['enemies']],[e['current_hp'] for e in at(288899)['enemies']])
check('MTQ F23 original and changed Block',[at(288811)['block'],at(288904)['block']],[29,19])
check('MTQ F23 original and changed next-turn HP',[at(288812)['hp'],at(288905)['hp']],[10,2])
check('MTQ F23 changed line gives six extra immediate enemy HP loss',sum(e['current_hp'] for e in at(288812)['enemies'])-sum(e['current_hp'] for e in at(288905)['enemies']),6)

ancillary=json.loads((S/'ancillary.json').read_text())
ghost=[x['row'] for x in ancillary['sl-attempts'] if x['run_id']=='XTSV1U9JD34T' and x['row']['floor']==49]
check('X six correlated attempts',len(ghost),6)
check('X all observed Ghost drinks at T1',[x['summary']['potions'] for x in ghost],[['T1 罐装幽灵']]*6)
sl=[x['row'] for x in ancillary['sl-attempts'] if x['run_id']=='MTQ0EUBJ3R6T' and x['row']['floor']==23]
check('MTQ four correlated attempts',[x['result'] for x in sl],['predicted_death']*3+['died'])
key_decisions={x['line']:x['row'] for x in json.loads((S/'key-decisions.json').read_text())}
criteria=key_decisions[282434]['questions']['plan']['criteria']
plans={k:json.loads(v) if isinstance(v,str) else v for k,v in criteria.items()}
check('MTQ original and changed predicted immediate HP loss',[plans[x]['hp_lost'] for x in ['plan1','plan4']],[0,8])
check('MTQ original and changed both have saturated 24-sample death estimates',[('24/24' in plans[x]['rollout']) for x in ['plan1','plan4']],[True,True])
check('MTQ executed replacement is recorded', 'SL explore' in key_decisions[282434]['rationale'],True)

(S/'settled-act-transitions.json').write_text(json.dumps(settled,ensure_ascii=False,indent=2)+'\n')
(S/'facts-validation.json').write_text(json.dumps({'kind':'material_checks_only','checks':checks,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'material_checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']]},ensure_ascii=False))
raise SystemExit(0 if all(x['passed'] for x in checks) else 1)

"""Render this batch's evidence-qualified dispositions and ledger link inputs."""
import datetime
import json
from pathlib import Path
import shutil

S = Path(__file__).resolve().parent
dispatch = json.loads((S/'dispatch-and-proposals.json').read_text())
validation = json.loads((S/'evidence-validation.json').read_text())
facts = json.loads((S/'facts-validation.json').read_text())
sources = json.loads((S/'source-readback.json').read_text())
assert facts['failed'] == 0 and facts['passed'] == 87

details = [
    {
        'title':'逐牌属性、被动挡与首小刀的组合兑现',
        'evidence':'RC61MFQM63Y6 A10 F23T3/T4：states 285223–285230，临时敏捷1→6，后续格挡0→12→21→25，次轮临时层消失。F29T3建立PHANTOM_BLADES_POWER9而已有5挡不变，T4第一小刀285291→285292使石虫29→15。F33T4生存者后手空（285414→285415）。',
        'counter':'柔嫩和临时敏捷同时变化，折扇是独立触发；不能把整轮25挡当单张牌面。F29建立能力并未防止当轮61→41，不能以能力存在推定收益已兑现。',
        'current':'首刀九层、升级预判等子模型已有源码；核实d65609ff2bc98ec5ec2e06b558159aba89d93032、d91f9600286a67480b5044e019dbb1041e2239af为base/live祖先。',
        'reason':'局部属性、折扇与九层首刀已有观察和子实现；本批没有找到当前消费者新的确定错排，也未补齐组合逐项误差及改药时的完整后继，不能据此改排序或把宽项整体登记duplicate。',
        'verify':'冻结上述逐牌状态/动作，分别核牌面、临时属性撤回、第三攻击被动挡及首刀；后续只在可定位误算与相同组合完整后继出现时实现，未观察层数继续未知。'
    },
    {
        'title':'接管阶段和自主启动的边界',
        'evidence':'XTSV1U9JD34T A10 F49T1：286896尚不可行动，286897首次可操作时为23HP/16挡/3能量，手牌仅ASCENDERS_BANE，已有SHADOWMELD1和敌临时−6力。原提案同时定位F34取得耳环、F36取得蘑菇。',
        'counter':'内部自动出牌、抽序未记录，不能还原为Jev主动规划；本局其他持耳环的战斗获胜，单场失败不支持禁取耳环或蘑菇。',
        'current':'当前规划从实际稳定手牌/能量构建输入；本批未定位当前消费者将该帧误写为自由完整首轮。支持遗物名称不等于完整开场接管模拟。',
        'reason':'缺接管内部动作、抽序及同条件自主开局，也未定位当前题面误称自主首轮的具体内容；没有可实施的新规则或足以证明整项等价覆盖的源码证据。',
        'verify':'需要新记录保留接管边界、首个稳定可行动帧及实际题面；固定额外能量和手牌数量，只有确认消费者内容缺口后改事实投影。'
    },
    {
        'title':'夜魇复制存活条件和幽灵药水',
        'evidence':'XTSV1U9JD34T A10 F49T1：286897→286898无实体0→1、现场攻击26→1，16挡覆盖且次轮仍23HP/10挡。六次尝试（sl-attempts 1021–1026）均T1饮用。末次T3实扣敌32且实损22；T4有NIGHTMARE3、1HP/6挡面对16攻击，未截断剩血−9，实际死亡。',
        'counter':'T1早喝已经兑现零损；六次同局重放没有延后饮用对照。夜魇建立复制后死亡不能证明不用它便能存活，更不能拟持有价。',
        'current':'96f17377a331e50ea5b6a3fe8d2b605932ed1bd4已实现Silent A10、无既有无实体时的单层药水分支，并保留Jev选择；已核base/live祖先，不能把该子项当夜魇/时机/药价全项实现。',
        'reason':'单层幽灵子项已在live；延后饮用、叠层、复制兑现和持有价值缺完整可比后继与独立校准，整项继续waiting。',
        'verify':'保留T1效果与T3/T4死亡前端点；新局须记录同条件留药/饮药完整后继，复制收益按实际到达的下一轮验收，不设固定回合或药价。'
    },
    {
        'title':'强制弃牌、毒胜保血和后继兑现',
        'evidence':'BTSRF7JL1W1Y A10 F31T2：decision279846预计损4、净伤13且杀丝虫；286161生存者与突然一拳两张，286162手空，286158→286163实35→21、丝虫仍活。XTSV1U9JD34T A10 F48T8：286893为32HP/0挡/5能量，毒胜后23HP，286896无恢复直入F49。',
        'counter':'普通单弃和存活毒胜保血是不同根因，均不能用来断言F49可赢；夜魇、接管和杀序缺完整同条件后继。',
        'current':'bf423c173d3be348a4ad714e1d26516df619ff41已处理已观察普通生存者唯一弃牌/未知选择边界；222445a9bb6bf56cb4f3ceea2cc8b20fba54128f已扩展限定连王毒胜的无药保血搜索。二者均base/live祖先。',
        'reason':'两个窄根因已有live源码，宽项还包括复制、接管、杀序及SL完整兑现；缺这些条件下的完整后继与整体等价证明，不能整体duplicate或修改策略。',
        'verify':'后续固定实际弃牌选择及中断后重问，分别验收保血候选生成和连战实到HP；不将未实际执行的后继牌、击杀或朝向记为收益。'
    },
    {
        'title':'赢战血价与连王资源链',
        'evidence':'XTSV1U9JD34T A10 F48T8的32→23及23HP入F49由原帧确认；BTSRF7JL1W1Y F31T2实损14。跨幕结算与SL恢复从原流分别保留，不预支未抵达营火。原提案还保存B F30赢战70→42、X F47回满97后F48胜剩23的资源追溯。',
        'counter':'战斗获胜仍可能消耗血与药；另一条路线、休息/锻造或留药没有同资源完整对照，不能把实际资源链直接解释为路线因果或安全阈值。',
        'current':'当前有continuation资源接口及限定保血搜索；局部来源可核，但本批没有新的资源权重或血线校准样本。',
        'reason':'缺同资源替代路线、休息/锻造与留药机会成本的完整对照，不能拟新资源权重、安全血线或关闭资源价值宽项。',
        'verify':'按实际到达顺序保存获药、饮药、遗物/营火回复、SL恢复及下一战入口；新局按时间留出，房间代价仍保持既有样本门槛。'
    },
    {
        'title':'属性、覆甲、临时减力和留挡分源',
        'evidence':'BTSRF7JL1W1Y A10 F31T2：黑暗镣铐后石虫力量−9，防御加生存者13牌挡、另有覆甲3，35→21；下一轮覆甲2且临时项改变。XTSV1U9JD34T F49T3步法建立3敏捷不补已有5挡，T4脆弱防御实6；幽灵T1后次轮只留10挡。',
        'counter':'本局模型旧误差同时含弃掉后继牌，不得把全部差额归因于覆甲或临时减力。三敏建立不补旧挡，10挡是实际留挡而非每轮保底。',
        'current':'普通单弃和幽灵已有上述窄源码，其他属性与留挡路径可读；本批没有定位足以新增修改的独立组合根因。',
        'reason':'局部属性/减力/留挡窗口成立，但未知组合独立效应和延后用药完整后继不足；不能拟新时机、持有价或把宽组合全称已验证。',
        'verify':'固定逐动作属性及回合边界，隔离弃牌、临时恢复和被动挡后再比当前消费者；只修复能在该输入确立的差异。'
    },
    {
        'title':'倍率挡、毒、持牌伤及反伤的结算',
        'evidence':'9Z9H2EXKLF3T A10 F48末试T10：第一偏折18，后续偏折9、防御10，共37挡；states288004→288005实18→3。T11从敌112HP/39毒到32HP，80净扣由39+38毒和已观察3反伤组成。',
        'counter':'死亡端点HP被截为0，未执行的后续攻击/反伤不能预支；换线同时改变抽牌及药时，T7局部模拟差额不能作为整战血价或胜因。',
        'current':'2184caaab265ebf86c0627aaef39c2e7a170a990的升级暗影子修复与毒模型既有源码均为live祖先；终局原帧不含完整中间毛伤事件。',
        'reason':'零血截断、未执行后续击和中间伤害事件缺口仍在，SL改线与药时混杂，不能校准新血价、必死或SL阈值。',
        'verify':'保留每击、持牌伤、毒触发、复活及反伤的先后，仅在实际发生的事件账与完整后继齐全时评价换线，有限全败样本继续只作估计。'
    },
    {
        'title':'跨幕回复、营火和SL资源接续',
        'evidence':'本批15局A9/A10共22对已到达F17→18或F33→34、同上限端点均符合floor(缺失HP×80%)；派发10锚点贡献16对，原提案五关联局贡献6对。例G403VCZ3BH1B A9 2/70→56/70及17/70→59/70，9Z9H2EXKLF3T A10 24/70→60/70及23/77→66/77。完整逐对行号/偏移/SHA见settled-act-transitions.json。',
        'counter':'幕编号先改变时仍是未回血MAP帧，下一层才有实际结算；不能把该过渡帧的0回复当公式反例，也不能将营火/SL恢复并入跨幕回复。未观察的先古/遗物交互不外推。',
        'current':'Silent经验已有限定跨幕事实，当前double-boss数据保留连续战资源边界；文字存在不构成所有资源/SL消费者的等价证明。',
        'reason':'22对只支持已观察跨幕实际回复；缺未知交互、同资源替代路线和可定位的当前消费者误算，不能关闭资源/SL/终局宽项。',
        'verify':'使用实际到达F18/F34的结算帧，不用act_id切换帧替代；后续只依据本角色同条件新局检验模型及资源消费者，不新增全回复假设或安全血线。'
    },
    {
        'title':'头骨组合毒药水和未知持有价',
        'evidence':'7X0W3U8TVA2A A10 F31T13：decision282021槽0、目标2；states288470→288471后段毒0→7、敌HP不变，288472后段25→18。玩家1HP/14挡仍死亡。该局是原派发提案证据，不是新增独立样本。',
        'counter':'已喝7毒仍死，不能证明早喝能赢。没有本局前/中段用药、重附恢复目标或无头骨对照，不能再叠加一次头骨、反推基础药效或把未知持有价当真实零值。',
        'current':'observedPoison仍为整瓶单一标量；modelledIds按药水id计覆盖。现有知识恶魔入口有完整不同遗物/能力条件，连王仅F48/F49并读取poisonPotionAmount=6。均不等同本局F31目标组合覆盖。',
        'reason':'缺未饮前/中段、重附恢复目标、未知组合及留药整战/持有价；标量和整瓶覆盖会把总量7扩至未经本局验证的目标，不能直接无条件扩展。',
        'verify':'后续实现须锁定目标及效果条件、保留其他目标未模拟，并固定后段毒0→7、HP不变、结算只扣7；未知机会成本维持未校准，Jev保留饮用选择。'
    },
    {
        'title':'饱和死亡推演中的SL即时血价',
        'evidence':'MTQ0EUBJ3R6T A10 F23四试T3同10HP、敌61/41HP；前三试29挡后仍10HP，末试SL替线19挡后2HP，即多损8且多6即时敌HP损失。decision282434 plan1/plan4都24/24死亡，SL摘要1038–1041为前三T6判死、末次T5实死。',
        'counter':'原线也没有胜局；T5与T6终止时间不同、后继抽牌/毒雾建立也不同，敌残37与29不是独立胜率或同条件整战收益。速度药已饮，不能重复计敏捷或防御。',
        'current':'explore的not-worse门槛仍按有限死亡率或B2比较，并保留原顺序排名；该授权探索规则不能仅凭这一个相关样本定性为纯bug。',
        'reason':'缺完整候选执行认证、同条件整战与独立时间留出，不能凭24/24饱和死亡推演及单局8血换6即时伤拟SL血价或药水阈值。',
        'verify':'未来固定相同牌序/用药/目标和完整动作回执，分别比较即时需损、实际存活和整战结果；不能用有限0胜推演证明实盘必死，不拟8点门槛。'
    },
]
assert len(details) == len(dispatch['proposals']) == 10
results = []
proposal = [f'# 静默猎手策略提案逐项复核：{dispatch["batch"]}',
    f'生成：{datetime.datetime.now().astimezone().isoformat()}。基线：`{dispatch["base"]}`。',
    '本批是普通提案消费任务，reason=proposal；没有research_request、implementation_request或proposal_repair。只处理派发10个既有id，不承接其他批次专题，不新建重复提案。',
    '结论：本角色原帧支持若干局部结算，已有源码覆盖若干窄项；本批没有足够新增数据支持修改策略，也未证明十个宽提案各自完整等价实现，全部waiting。源码、知识、参数和其他角色均未修改。',
    '证据规则：先经runs.jsonl核角色，再用共用extract_evidence.py抽取八流；逐条重新读取原始offset/bytes核SHA与JSON及显式身份。派发10局和原提案五关联局分开列示，不把SL重放当独立样本，不用当前代码冒认历史dirty树。']
for p,detail in zip(dispatch['proposals'],details):
    original=p['original']; item={'id':p['id'],'state':'waiting','reason':detail['reason']};results.append(item)
    proposal += [f'\n## {p["id"]}：{detail["title"]}',
        '关联账本：'+', '.join(original['ledger'])+'。',
        '原始来源任务：'+original['source_task']+'；实现任务：strategy-proposal；领域：'+', '.join(original['domains'])+'。',
        f'原提案：`{original["proposal"]}`；SHA256 `{p["markdown_sha256"]}`，本批复核一致，另保存原文副本。',
        '本批证据：'+detail['evidence'], '反例和限制：'+detail['counter'],
        '当前行为及已有子项：'+detail['current'], '处置：waiting。'+detail['reason'],
        '预期行为及验证：'+detail['verify'],
        '拟合与样本切分：本批不拟新参数；上述来源局属于回溯核验，相关SL仅算同局重复。未来本角色实际新局按时间留出，验证前不把未知写成零值或默认规则。',
        '回退：本批没有策略变更。未来实现仅逆向其独立源码提交，保留并行知识刷新和原日志/账本；实际上线后按既有流程登记并双通知Roy。']
(S/'proposal.md').write_text('\n\n'.join(proposal)+'\n')
(S/'original-proposals').mkdir(exist_ok=True)
for p in dispatch['proposals']:
    shutil.copyfile(p['original']['proposal'],S/'original-proposals'/f'{p["id"]}.md')

streams='\n'.join(f'| {v["stream"]} | {v["verified_rows"]} | {v["source_size"]} | {v["invalid_lines"]} |' for v in validation['streams'])
table='\n'.join(f'| {p["id"]} | waiting | {d["reason"]} |' for p,d in zip(dispatch['proposals'],details))
source_table='\n'.join(f'| `{x["commit"]}` | {x["base_ancestor"]} | {x["live_ancestor"]} |' for x in sources['sources'])
report=f'''# 静默猎手策略批次报告

批次：{dispatch['batch']}；task=strategy-proposal；character=silent。
生成：{datetime.datetime.now().astimezone().isoformat()}。
完整base：`{dispatch['base']}`。起始tracked clean，按普通任务执行git merge --no-edit main，结果Already up to date。没有纯研究或实现请求绑定；根旧专题绑定其他批次，未用于本批选题。

## 结果

本批十个id全部完成证据复核并保持waiting；已有局部源码不充作整项duplicate。无新增源码、经验、策略参数、提交或发布；fixes=[]、merged=null。proposal.md为运维接续入口，proposal-results.json和result.json保存逐项处置。本报告不关闭量化学习、经验入库或消费者读回父要求。

| 提案 | 状态 | 具体待补数据 |
|---|---|---|
{table}

每项证据局号、层/回合、所有原账本id、旧行为、已有子源码、反例、预期行为、验证及回退见[proposal.md](proposal.md)。原提案十份Markdown的SHA与专用队列原add行逐一一致，未改提案原文或队列。

## 输入范围及原始字节核验

派发锚点仅：{','.join(dispatch['dispatch']['runs'])}。
只为原提案追加其已关联五局：9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T；没有领取新id。共15局，A9为HMV/F4/G403三局，其余12局A10；没有混用其他角色。原始角色字段大小写通过仓库run_character统一核验，原行和完整code字段留在verified-runs.json。

| 流 | 原行复核数 | source_size字节截点 | 扫描坏行数 |
|---|---:|---:|---:|
{streams}

合计{validation['total_verified_rows']}条均逐offset/bytes/SHA/原JSON/显式run身份核对。原run-plans以run归属，其余流支持run_id/state.run_id/fingerprint.run；身份冲突拒收，不以正文提及归属。扫描坏行未收进本批，不能归因本批缺帧。fight-plans为该2233957字节截点实选0，仅说明本次未选到，不断言历史原日志不存在。未复核旧截点，也未覆盖旧报告或零行初稿。

实际brain流570条的engine字段均为codex，但这不是全历史脑调用完整性证明；run-config仍有历史build_decider等配置，runs字段名与实际模型分开。全部原局code含dirty，未重建完整历史执行树及知识刷新字节，当前源码仅用于现状定位和祖先核对。学习者本批的原生实际模型/推理请求由宿主回执核验，本报告未凭启动说明冒认核验完成。

## 固定材料核验与结论

材料核验87项通过（facts-validation.json），属于原日志事实检查，不是生产tsc/vitest或胜率校准。

- RC61 F23临时敏捷与柔嫩逐牌变化、被动挡分源及F29九层首刀14伤成立；未发现足够新增证据改组合排序。
- XTS F48毒胜32→23且无回复入F49；首个ready=true帧仅进阶之灾/3能量/16挡，接管内部序列未知。幽灵六试均T1喝，不能推延后胜线；末T4夜魇未到下一轮，实际死亡不证明替代路径能赢。
- BTS F31生存者弃唯一后继，实损14；窄根因已有live源码，不能把其他资源/复制/SL部分一并关闭。
- 9Z末试倍率挡18+9+10=37，实损15；终局112→32含39+38毒和已观察3反伤，死亡后的未执行击不预支。
- 22对实际到达下一层的跨幕结算均为同上限floor(缺失HP×80%)，其中派发锚点16对。act-transitions.json另保留22个幕编号改变的过渡MAP帧，它们尚未回血；settled-act-transitions.json才是实际结算证据。两类不混用。
- 7X后段毒0→7且HP不变，结算扣7仍死；当前observedPoison标量和modelledIds整瓶覆盖不足以无条件扩展到未观察目标。已知7毒组合与局部6常量的范围问题保留，本批未形成新的必要反证或重复通知。
- MTQ同T3两线实际多损8/多6即时伤，均无整战胜局；24/24有限全败不是实际必死或更安全证明，不拟血价/用药阈值。

本批仅回溯15个相关局，不能当全历史学习完成；旧复盘与原已知限制均保留，不重复写历史复盘。不同层/不同进阶/不同SL抽序不是受控对照，固定原局也不能兼任拟合和独立验证集。

## 现有源码及live核对

只读核对时live为`{sources['live_observed']}`。下列均为base和实际live祖先，完整文件SHA见source-readback.json：

| 已有源码提交 | base祖先 | live祖先 |
|---|---|---|
{source_table}

这些是已有子实现，未作为本批新提交或整项implemented/duplicate。检查10个源码/本角色知识叶，7叶同字节；card-model仅两处Roy/Dai历史注释差，完整差异存base-live-card-model.patch。本角色经验和双王数据另有并行刷新差异，未覆盖、未合并旧副本或据此重算新规则。worktree-source.patch为空。本批没有需要合入的新增代码，跳过live锁内合入、生产补测、版本和上线通知，不运行play。

## 失败、验证和记录

首次角色预检错误地与小写silent比较，遇原字段SILENT失败，改用既有run_character重新严格核验；原始日志未改。只读定位曾使用旧目录和不存在的猜测文件名，后按rg --files定位reflex/与knowledge/真实文件。中间探查一次将combat=null当字典、一次将无questions的自动结束动作当有题动作而报错，均未改变输入或生产代码。

首轮87项材料检查有一项失败：小刀前后帧误选285290→285291（实际为后空翻），实际差0、预期仍14。保留first-facts-validation.json及first-facts.stdout.txt；核实真正小刀为285291→285292后只纠正帧引用、预期14不变，再次87/87通过。act-id过渡帧与下一层实际回血的两份独立结果均保留，不把未结算当机制反证。上述均为材料适配/端点定位失败，不冒称生产源码失败或撤源码红绿试验。

无源码修改，所以未进行撤源码失败/恢复通过试验，tsc=null、vitest=null、cases=null；未提交，无提交前生产自测成功声明。gitleaks结果及最终clean/HEAD核验另存completion-validation.json。账本只经根learner/ledger.py update追加本批proposal/report追溯，不添加新经验、不改claim/首证/prior/evidence/status/version、不标shipped；CLI原输入和回执保存在本目录。队列状态由调度器消费最终proposal_results登记，本学习者不手改。

运维交接：{S/'proposal.md'}。实际完整后继/消费者误算数据补齐后沿十个原id重派，不新建重复提案，不因本报告关闭父要求。
'''
(S/'report.md').write_text(report)
(S/'proposal-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
ids=sorted({i for p in dispatch['proposals'] for i in p['original']['ledger']})
updates=[]
for ledger_id in ids:
    proposals=[p['id'] for p in dispatch['proposals'] if ledger_id in p['original']['ledger']]
    updates.append({'id':ledger_id,'by':'learner:strategy-proposal',
        'where':{'proposal':[str(S/'proposal.md'),str(S/'report.md')]},
        'note':f'{dispatch["batch"]}原提案追溯：'+','.join(proposals)+'；逐项waiting和具体缺数据见本批报告。仅补本次复核去处，不改原结论/证据/先验/状态/版本，不冒称整项实现或上线。'})
(S/'ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
result={'task':'strategy-proposal','character':'silent','batch':dispatch['batch'],'base':dispatch['base'],
    'runs':dispatch['dispatch']['runs'],'fixes':[],'skipped':[],'merged':None,
    'tests':{'tsc':None,'vitest':None,'cases':None},
    'code_proposals':[p['id'] for p in dispatch['proposals']],
    'implementation_domains':['combat','potion','sl','terminal','structure'],
    'proposal_results':results,'report':str(S/'report.md')}
(S/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'proposals':len(results),'ledger_link_updates':len(updates),'report':str(S/'report.md')},ensure_ascii=False))

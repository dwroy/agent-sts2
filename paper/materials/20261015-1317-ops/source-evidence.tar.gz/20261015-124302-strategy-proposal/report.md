# 静默猎手策略批次报告

批次：20261015-124302-strategy-proposal；task=strategy-proposal；character=silent。
生成：2026-10-15T12:56:12.484613+08:00。
完整base：`4f778c2199657ed0b6a01ece44ab17654552f207`。起始tracked clean，按普通任务执行git merge --no-edit main，结果Already up to date。没有纯研究或实现请求绑定；根旧专题绑定其他批次，未用于本批选题。

## 结果

本批十个id全部完成证据复核并保持waiting；已有局部源码不充作整项duplicate。无新增源码、经验、策略参数、提交或发布；fixes=[]、merged=null。proposal.md为运维接续入口，proposal-results.json和result.json保存逐项处置。本报告不关闭量化学习、经验入库或消费者读回父要求。

| 提案 | 状态 | 具体待补数据 |
|---|---|---|
| silent-proposal-03754e1265894000 | waiting | 局部属性、折扇与九层首刀已有观察和子实现；本批没有找到当前消费者新的确定错排，也未补齐组合逐项误差及改药时的完整后继，不能据此改排序或把宽项整体登记duplicate。 |
| silent-proposal-e5ea36df117ca9b7 | waiting | 缺接管内部动作、抽序及同条件自主开局，也未定位当前题面误称自主首轮的具体内容；没有可实施的新规则或足以证明整项等价覆盖的源码证据。 |
| silent-proposal-ab055ef7dfbb44e5 | waiting | 单层幽灵子项已在live；延后饮用、叠层、复制兑现和持有价值缺完整可比后继与独立校准，整项继续waiting。 |
| silent-proposal-0129c465c6f5bd79 | waiting | 两个窄根因已有live源码，宽项还包括复制、接管、杀序及SL完整兑现；缺这些条件下的完整后继与整体等价证明，不能整体duplicate或修改策略。 |
| silent-proposal-abe9d5d0be109a9f | waiting | 缺同资源替代路线、休息/锻造与留药机会成本的完整对照，不能拟新资源权重、安全血线或关闭资源价值宽项。 |
| silent-proposal-f16527e59b5cc1e0 | waiting | 局部属性/减力/留挡窗口成立，但未知组合独立效应和延后用药完整后继不足；不能拟新时机、持有价或把宽组合全称已验证。 |
| silent-proposal-7a8e9ccb7e646538 | waiting | 零血截断、未执行后续击和中间伤害事件缺口仍在，SL改线与药时混杂，不能校准新血价、必死或SL阈值。 |
| silent-proposal-cd9f76184de6e29a | waiting | 22对只支持已观察跨幕实际回复；缺未知交互、同资源替代路线和可定位的当前消费者误算，不能关闭资源/SL/终局宽项。 |
| silent-proposal-292f6731bdb9b669 | waiting | 缺未饮前/中段、重附恢复目标、未知组合及留药整战/持有价；标量和整瓶覆盖会把总量7扩至未经本局验证的目标，不能直接无条件扩展。 |
| silent-proposal-0802f69b28d25079 | waiting | 缺完整候选执行认证、同条件整战与独立时间留出，不能凭24/24饱和死亡推演及单局8血换6即时伤拟SL血价或药水阈值。 |

每项证据局号、层/回合、所有原账本id、旧行为、已有子源码、反例、预期行为、验证及回退见[proposal.md](proposal.md)。原提案十份Markdown的SHA与专用队列原add行逐一一致，未改提案原文或队列。

## 输入范围及原始字节核验

派发锚点仅：RC61MFQM63Y6,XTSV1U9JD34T,BTSRF7JL1W1Y,9Z9H2EXKLF3T,HMVJKM56S4Q8,F4QKG4J1AJJZ,G403VCZ3BH1B,25226ZFLNR1J,JLN5SK17W4FQ,JMH5C51RLN4E。
只为原提案追加其已关联五局：9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T；没有领取新id。共15局，A9为HMV/F4/G403三局，其余12局A10；没有混用其他角色。原始角色字段大小写通过仓库run_character统一核验，原行和完整code字段留在verified-runs.json。

| 流 | 原行复核数 | source_size字节截点 | 扫描坏行数 |
|---|---:|---:|---:|
| states | 11008 | 13012894617 | 2 |
| decisions | 10609 | 1559785127 | 2 |
| sl-attempts | 109 | 40310132 | 0 |
| run-config | 16 | 1747793 | 0 |
| run-plans | 97 | 8018124 | 0 |
| brain | 570 | 566684368 | 1 |
| runs | 15 | 333707 | 0 |
| fight-plans | 0 | 2233957 | 0 |

合计22424条均逐offset/bytes/SHA/原JSON/显式run身份核对。原run-plans以run归属，其余流支持run_id/state.run_id/fingerprint.run；身份冲突拒收，不以正文提及归属。扫描坏行未收进本批，不能归因本批缺帧。fight-plans为该2233957字节截点实选0，仅说明本次未选到，不断言历史原日志不存在。未复核旧截点，也未覆盖旧报告或零行初稿。

实际brain流570条的engine字段均为codex，但这不是全历史脑调用完整性证明；run-config仍有历史build_decider等配置，runs字段名与实际模型分开。全部原局code含dirty，未重建完整历史执行树及知识刷新字节，当前源码仅用于现状定位和祖先核对。学习者本批的原生实际模型/推理请求由宿主回执核验，本报告未凭启动说明冒认核验完成。

## 固定材料核验与结论

材料核验87项通过（facts-validation.json），属于原日志事实检查，不是生产tsc/vitest或胜率校准。

- RC61 F23临时敏捷与柔嫩逐牌变化、被动挡分源及F29九层首刀14伤成立；未发现足够新增证据改组合排序。
- XTS F48毒胜32→23且无回复入F49；首个ready=true帧仅进阶之灾/3能量/16挡，接管内部序列未知。幽灵六试均T1喝，不能推延后胜线；末T4夜魇未到下一轮，实际死亡不证明替代路径能赢。
- BTS F31生存者弃唯一后继，实损14；窄根因已有live源码，不能把其他资源/复制/SL部分一并关闭。
- 9Z末试倍率挡18+9+10=37，实损15；终局112→32含39+38毒和已观察3反伤，死亡后的未执行击不预支。
- 22对实际到达下一层的跨幕结算均为同上限floor(缺失HP×80%)，其中派发锚点16对。act-transitions.json另保留22个幕编号改变的过渡MAP帧，它们尚未回血；settled-act-transitions.json才是实际结算证据。两类不混用。
- 7X后段毒0→7且HP不变，结算扣7仍死；当前observedPoison标量和modelledIds整瓶覆盖不足以无条件扩展到未观察目标。已知7毒组合与局部6常量的范围问题保留，本批未形成新的必要反证或重复通知。
- MTQ同T3两线实际多损8/多6即时伤，均无整战胜局；24/24有限全败不是实际必死或更安全证明，不拟血价/用药阈值。

本批仅回溯15个相关局，不能当全历史学习完成；旧复盘与原已知限制均保留，不重复写历史复盘。不同层/不同进阶/不同SL抽序不是受控对照，固定原局也不能兼任拟合和独立验证集。

## 现有源码及live核对

只读核对时live为`fba193dfe31844e1dbde9f2ad7174427fcd446dc`。下列均为base和实际live祖先，完整文件SHA见source-readback.json：

| 已有源码提交 | base祖先 | live祖先 |
|---|---|---|
| `96f17377a331e50ea5b6a3fe8d2b605932ed1bd4` | True | True |
| `222445a9bb6bf56cb4f3ceea2cc8b20fba54128f` | True | True |
| `bf423c173d3be348a4ad714e1d26516df619ff41` | True | True |
| `d65609ff2bc98ec5ec2e06b558159aba89d93032` | True | True |
| `d91f9600286a67480b5044e019dbb1041e2239af` | True | True |
| `2184caaab265ebf86c0627aaef39c2e7a170a990` | True | True |
| `f6c5504a73b2ee3702812a5217dfcda8b14e18aa` | True | True |
| `0970bc0d112718d45c8ebf86ff7f84e0f36a7498` | True | True |

这些是已有子实现，未作为本批新提交或整项implemented/duplicate。检查10个源码/本角色知识叶，7叶同字节；card-model仅两处Roy/Dai历史注释差，完整差异存base-live-card-model.patch。本角色经验和双王数据另有并行刷新差异，未覆盖、未合并旧副本或据此重算新规则。worktree-source.patch为空。本批没有需要合入的新增代码，跳过live锁内合入、生产补测、版本和上线通知，不运行play。

## 失败、验证和记录

首次角色预检错误地与小写silent比较，遇原字段SILENT失败，改用既有run_character重新严格核验；原始日志未改。只读定位曾使用旧目录和不存在的猜测文件名，后按rg --files定位reflex/与knowledge/真实文件。中间探查一次将combat=null当字典、一次将无questions的自动结束动作当有题动作而报错，均未改变输入或生产代码。

首轮87项材料检查有一项失败：小刀前后帧误选285290→285291（实际为后空翻），实际差0、预期仍14。保留first-facts-validation.json及first-facts.stdout.txt；核实真正小刀为285291→285292后只纠正帧引用、预期14不变，再次87/87通过。act-id过渡帧与下一层实际回血的两份独立结果均保留，不把未结算当机制反证。上述均为材料适配/端点定位失败，不冒称生产源码失败或撤源码红绿试验。

最终身份回读首次误按learn.json顶层batch键取值，在44条账本读回检查完成后出现KeyError；保留completion-first-readback-failed.txt。按原文件实际batches嵌套读取本批后，继续核相同id列表、角色、工作树、HEAD和clean，不更改派发状态或放松断言。一次shell启动另遇沙箱包装器对仓库外已消失路径的glob扫描错误，原样保留，重试原只读命令成功，未扩大权限。

无源码修改，所以未进行撤源码失败/恢复通过试验，tsc=null、vitest=null、cases=null；未提交，无提交前生产自测成功声明。gitleaks结果及最终clean/HEAD核验另存completion-validation.json。账本只经根learner/ledger.py update追加本批proposal/report追溯，不添加新经验、不改claim/首证/prior/evidence/status/version、不标shipped；CLI原输入和回执保存在本目录。队列状态由调度器消费最终proposal_results登记，本学习者不手改。

运维交接：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-124302/learner/runs/20261015-124312-8d89f3d7-9543-4258-981d-2c45816f2673-strategy-proposal/proposal.md。实际完整后继/消费者误算数据补齐后沿十个原id重派，不新建重复提案，不因本报告关闭父要求。

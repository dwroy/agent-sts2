"""Verify frozen Silent evidence and project observed states without game or model calls."""
import collections
import hashlib
import json
from pathlib import Path
import sys

SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
sys.path.insert(0, str(WORKTREE / 'learner'))
from extract_evidence import run_identity


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(items):
    return {x['power_id']: x.get('amount') for x in items or []}


def main():
    selected = json.loads((SCRATCH / 'verified-runs.json').read_text())['runs']
    manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
    validations = []
    states = []
    decisions = []
    brains = collections.defaultdict(collections.Counter)
    ancillary = {}
    for stream in manifest:
        counts = collections.Counter()
        digest = hashlib.sha256()
        source = Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')
        with source.open('rb') as original, (SCRATCH / 'evidence' / (stream['stream'] + '.evidence.jsonl')).open('rb') as handle:
            for encoded in handle:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['source'] == str(source)
                assert item['offset'] + item['bytes'] <= stream['source_size']
                original.seek(item['offset'])
                raw = original.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                row = json.loads(raw)
                assert row == item['row']
                run = run_identity(row)
                assert run == item['run_id'] and run in selected
                counts[run] += 1
                ref = {k: item[k] for k in ['run_id', 'line', 'offset', 'bytes', 'sha256']}
                if stream['stream'] == 'states':
                    state = row['state']
                    run_state = state.get('run') or {}
                    assert run_state.get('character_id', 'silent').lower() == 'silent'
                    combat = state.get('combat') or {}
                    player = combat.get('player') or {}
                    states.append({**ref, 'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
                        'floor': run_state.get('floor'), 'ascension': run_state.get('ascension'),
                        'act': run_state.get('act_id'), 'screen': state.get('screen'),
                        'turn': state.get('turn'), 'in_combat': state.get('in_combat'),
                        'hp': player.get('current_hp', run_state.get('current_hp')),
                        'max_hp': player.get('max_hp', run_state.get('max_hp')),
                        'run_hp': run_state.get('current_hp'), 'block': player.get('block'),
                        'energy': player.get('energy'), 'powers': powers(player.get('powers')),
                        'potions': run_state.get('potions'), 'relics': [x.get('relic_id') for x in run_state.get('relics', [])],
                        'ready': (combat.get('action_readiness') or {}).get('can_use_combat_actions'),
                        'hand': [{k: x.get(k) for k in ['index', 'card_id', 'upgraded', 'energy_cost', 'can_play', 'is_playable', 'resolved_rules_text', 'dynamic_values']} for x in combat.get('hand', [])],
                        'enemies': [{**{k: e.get(k) for k in ['index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'intent', 'intents']}, 'powers': powers(e.get('powers'))} for e in combat.get('enemies', [])]})
                elif stream['stream'] == 'decisions':
                    decisions.append({**ref, 'row': row})
                elif stream['stream'] == 'brain':
                    brains[run][str(row.get('engine', row.get('provider', 'unknown')))] += 1
                else:
                    ancillary.setdefault(stream['stream'], []).append({**ref, 'row': row})
        assert digest.hexdigest() == stream['output_sha256']
        assert {r: counts[r] for r in selected} == stream['counts']
        validations.append({'stream': stream['stream'], 'source_size': stream['source_size'],
            'verified_rows': sum(counts.values()), 'counts': dict(counts),
            'output_sha256': digest.hexdigest(), 'invalid_lines': stream['invalid_lines'],
            'incomplete_lines': stream['incomplete_lines']})
    with (SCRATCH / 'state-projection.jsonl').open('w') as handle:
        for row in states:
            handle.write(json.dumps(row, ensure_ascii=False) + '\n')
    windows = {'RC61MFQM63Y6': [(285411,285415)],
        'XTSV1U9JD34T': [(286893,286899),(286978,286987)],
        'BTSRF7JL1W1Y': [(286158,286163)],
        '9Z9H2EXKLF3T': [(288000,288006)],
        '7X0W3U8TVA2A': [(288470,288472),(288407,288409)],
        'MTQ0EUBJ3R6T': [(288806,288812),(288899,288905)]}
    key_states = [r for r in states if any(lo <= r['line'] <= hi for lo,hi in windows.get(r['run_id'], []))]
    save('key-states.json', key_states)
    transitions = []
    for run in selected:
        rows = [x for x in states if x['run_id'] == run]
        previous = None
        seen = set()
        for row in rows:
            if previous and previous['act'] != row['act'] and previous['act'] is not None and row['act'] is not None:
                key = (previous['line'],row['line'])
                if key not in seen:
                    seen.add(key)
                    transitions.append({'run_id': run, 'ascension': row['ascension'],
                        'before': {k:previous[k] for k in ['line','floor','act','hp','max_hp','screen']},
                        'after': {k:row[k] for k in ['line','floor','act','hp','max_hp','screen']},
                        'same_max': previous['max_hp'] == row['max_hp'],
                        'actual_heal': row['hp'] - previous['hp'],
                        'observed_formula': ((previous['max_hp']-previous['hp'])*4)//5})
            previous = row
    save('act-transitions.json', transitions)
    wanted_decisions = {279117,279846,280547,280550,280631,280635,280639,281953,282021,282434}
    save('key-decisions.json', [r for r in decisions if r['line'] in wanted_decisions])
    save('ancillary.json', ancillary)
    save('evidence-validation.json', {'streams': validations, 'total_verified_rows': sum(x['verified_rows'] for x in validations),
        'state_count':len(states),'decision_count':len(decisions), 'brain_engine_fields': {r:dict(c) for r,c in brains.items()},
        'act_transition_count':len(transitions),'key_state_count':len(key_states)})
    print(json.dumps({'verified_rows': sum(x['verified_rows'] for x in validations), 'streams':[(x['stream'],x['verified_rows']) for x in validations],
        'states':len(states),'decisions':len(decisions),'act_transitions':len(transitions)},ensure_ascii=False))


if __name__ == '__main__':
    main()

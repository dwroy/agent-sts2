# 静默猎手十原提案复核

记录时间：2026-10-15 12:52:52 CST（写前已运行date）。来源/实现任务strategy-proposal，批次20261015-124302-s2-strategy-proposal。范围仅本批四个Silent A10锚点和十原ID；不新增或覆盖提案，不重复写历史复盘。

本批没有新源码、知识或规则。旧/拟议行为以每个原Markdown为准，SHA已全部核实。已存在的窄入口及记录不重做；下面记录本次核实范围与未交付范围，不把未充分校准的完整提案记作duplicate。

## silent-proposal-f54e8de2381c1250

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-051302-postmortem/proposal-guard.md

SHA256：db780eb4b443cc8fdfb17237293f186588b1b010347160b24d1d22291ae8c5ce

账本：silent-0125。原来源任务：postmortem；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：MTQ0EUBJ3R6T F11T1：decisions282138—282140、states288592—288597；F23末试T3 decision282434。

本次处置：waiting。候选、派发与离线重问审计子项已有live源码；F11选牌后重问，原护栏候选没有完整执行归属。缺同窗口完整实线排名，保持waiting。

反例/限制：候选预测14/6损血、14/16伤害与实际净损6/净扣20分列；实线新增4毒，不能把整轮20伤归给原plan1，不能据此取消护栏。

拟议行为与验证：用原指纹、decision_id和原行号贯穿原答/护栏/SL/选择/重问/执行；逐步核候选连续性后，才能输出完整候选实果和实际最优率。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-763a4b9d9f17b815

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-mechanisms.md

SHA256：989dcea2a0dd5cad05d276157131dec57fdb9d17b2bdab66cbd25f32e0e9ad39

账本：silent-0005, silent-0006, silent-0011, silent-0013, silent-0044, silent-0046, silent-0053, silent-0080, silent-0087, silent-0189, silent-0214, silent-0222, silent-0235, silent-0253。原来源任务：experience-update；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T F11T1、F17T4—T8、F20T3、F23四试T2—T5。

本次处置：waiting。普通蛇咬和磨蚀等窄模型已有；十四项临时属性、持牌伤、能力与药效时点的联合消费者校准未覆盖，不能整包duplicate或扩展修饰条件。

反例/限制：敏捷先建立不追补旧挡；速度药须后续逐牌兑现；SL后续动作不同，局部多挡不证明整场获救。原dirty知识未完整冻结。

拟议行为与验证：按原十四经验分别固定输入、动作、后继资源和消费者输出，区分已建能力/持有卡/临时撤回；未观察等级和角色保持等价。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-19a5cff2094e2d8f

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-sl.md

SHA256：7bf15ce1f8fd2291d52b8d24fc89de1fe613e8fd9812d31621f9cd48c8e2d57d

账本：silent-0021, silent-0064, silent-0079, silent-0133, silent-0125。原来源任务：experience-update；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：7X0W3U8TVA2A F31T5/T6/T13；MTQ0EUBJ3R6T F23末试T3 decision282434及四次尝试。

本次处置：waiting。暂死重接和终局端点审计子项已有；缺敌段生命周期到实际终局的联合校准、冻结知识下同输入整战对照，不能据死亡样本饱和修改终局或SL权重。

反例/限制：24/24死亡仅限有限模拟；暂死段重新出现会增加需伤，不能把当前活段血池归零当整战结束。原线也未实证能赢。

拟议行为与验证：保留每段类型、血量增补、重接、清毒和实际终结端点；同输入整战回放与后置独立新局分别校准，不把未执行毒伤补到账上。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-3540bf4360bf80af

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-053105-experience-update/proposal-resources.md

SHA256：58181f916f63872302d0ab2342b349e5de205083aa365151b8f4bcb79c1b63ce

账本：silent-0019, silent-0020, silent-0243。原来源任务：experience-update；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：MTQ0EUBJ3R6T F19T1—T3入59出46、F20T1—T7入46出8、F23未到F24；7X0W3U8TVA2A F30入70出67、F31入67。

本次处置：waiting。HP增加边界记录已有；原帧核实连续赢战净耗，尚缺逐源资源与药槽事实到完整路线/休息题面的固定读回，保持waiting。

反例/限制：开场回血、营火、跨幕和SL恢复不能合并为路线回血；未抵达F24不提供当前血量。没有随机替路线胜负对照，不拟合安全血线。

拟议行为与验证：固定原顺序读回赢战、已到回复、入房与可操作HP、药槽和来源未知；保持路线/休息选项及原排序，仅在完整消费者验证后补窄缺口。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-0ea5c0b9c030fdd6

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-054302-postmortem/proposal-sloth-potion.md

SHA256：ed57d3f8b54f0d056efe2e488a4dca2c2b32a7062433c636e71a51b395663391

账本：silent-0274, silent-0247, silent-0027, silent-0016。原来源任务：postmortem；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：KFRDELW2TH2P F33六试T7 decisions282864/282899/282933/282968/283001/283035；末states289533—289538；反例F28T2。

本次处置：waiting。奇巧剩余名额/能量及限定组合毒药6层已在live并完成旧帧读回；完整合法后继和目标收益兑现未认证，不能把局部入口当完整提案已实现。

反例/限制：手上技法7挡有效，但爆发在三名额用完后锁住；F28选防御后0能量未执行。末T7毒37→43、敌159→74仍未终结，早饮整战结果未知。

拟议行为与验证：保留六个原选牌帧；以实际能量、自动重放和剩余名额验证完整合法序列，再比较目标收益；其他遗物/能力组合继续未知，不固定目标或早喝规则。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-f915ec544ab94b6e

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-054302-postmortem/proposal-sl-tradeoff-guard.md

SHA256：2339e1598f60a64fa1db9be3ebe3cecfe7057ff323c14f15341ccce85b15de98

账本：silent-0079, silent-0125。原来源任务：postmortem；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：KFRDELW2TH2P F12T1 decisions282578/282579；F33首/第三试T6 states289339/289414→289345/289420，decision282929。

本次处置：waiting。生成牌后的重问及同盘多10伤/多6损已核，候选和SL资源差审计已有；仍缺完整执行归属与同输入整战校准，不调整SL权重。

反例/限制：两试均从15血/敌228/36毒/3覆甲开始，后继9/3血、敌145/135，均失败；F12护栏完整0损线因生成小刀被重问，实际6损不能直接认模拟错误。

拟议行为与验证：将护栏候选、生成小刀、重问与各实际动作分段；在同输入完整执行被认证时才比较预测误差；同局重试不当独立胜率样本。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-8fb51933639faf90

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-mechanisms.md

SHA256：540a529f428b0c342abb969c3d040446149db3d7fb4f855b23f4b950462a64ab

账本：silent-0005, silent-0006, silent-0027, silent-0189, silent-0276, silent-0277, silent-0278。原来源任务：experience-update；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：KFRDELW2TH2P F28T2；F33六试T2铁心、T4回血/增力、T5触媒、T6/T7覆甲/毒药。

本次处置：waiting。知识恶魔毒药6层入口已在live，旧仅覆盖双boss理由已失效；七项药效/能力的联合多轮校准与覆甲完整减层条件仍缺，整项waiting。

反例/限制：42个可识别状态帧不是42次饮药；六次T7属同局相关尝试。铁心建7层不即补牌挡，后段实际层数不能推固定每轮减1。

拟议行为与验证：逐药效核饮用当步、后续逐牌、玩家末和敌段时点；触媒结算次数与层数分列，只在已验证组合提供量化值，完整衰减条件未知时不外推。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-b3bc0eb09211af6c

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-sl-selection.md

SHA256：f3279ab3f48180d287e7ad57c0a1484e56ed48910772aac748dd6faf32185bf9

账本：silent-0021, silent-0079, silent-0102, silent-0247, silent-0274。原来源任务：experience-update；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：KFRDELW2TH2P F33六试T7、首/第三试T6；F12T1；末states289533—289538。

本次处置：waiting。奇巧事实、毒药入口与阶段审计子项已有；合法后继到实际终结全链尚未验证，换对象/顺序/提前饮毒整战对照缺失，保留waiting。

反例/限制：末T7实际85毒伤后敌仍74，不能把存毒或未施放爆发计为胜线；T6多10伤同时多损6，没有实胜对照，不据饱和模拟固定保血策略。

拟议行为与验证：把每次选择的可执行后续、当前需损、实际毒结算、敌回血和终结端点连起来；完整反事实不足时不拟合终局权重或放松必死边界。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-fdc3a505fe5e1a55

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-061302-experience-update/proposal-resources.md

SHA256：9591f8717f33da220db658aaa746a04412cd9b324bb60fbb2f9a376a0796ea75

账本：silent-0019, silent-0020, silent-0243。原来源任务：experience-update；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：KFRDELW2TH2P F28入46出44、F30入65出27、F32休息、F33首入房36而可操作38。

本次处置：waiting。赢战净耗、入房与HP增加边界已有；缺分源事实到完整路线/休息题面的固定消费者对照及替路线/锻造完整结果，不改安全节点或阈值。

反例/限制：计划F18预测boss70血不等于F33实到36血；六次回血和无精英路线仍败不证明回血错误；SL恢复与药槽恢复不计路线收益。

拟议行为与验证：按原帧分别保留营火/跨幕/遗物/SL边界、牌组与药槽；先做事实消费者完整读回，胜率与休息/锻造因果另待可比新局。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

## silent-proposal-5a95725089f53cd8

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-064304-postmortem/proposal-resource-bloodprice.md

SHA256：802a23c7d736197db33e3c57daf42eb9064bc4b2ee56fc2f5733b3fdd73fcdb7

账本：silent-0019, silent-0079, silent-0005, silent-0016, silent-0087, silent-0027, silent-0030。原来源任务：postmortem；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。

证据：GXNKW8X1XYJP F35/F38/F40/F42/F44；F45第二/末试T2—T3 decisions283641/283680/283690/283691，states290160/290165/290201/290206/290212/290213。

本次处置：waiting。复活后3/13血、0/7挡及逐槽观测已核且窄审计已有；缺逐击复活帧、完整候选归属与逐源资源消费全链，宽提案继续waiting。

反例/限制：精灵槽1 usage=Automatic后消失不当主动喝/弃；末试13血、23挡、2覆甲对40需损15差2，两线均败。多保10血和7带挡不证明整战胜率改善。

拟议行为与验证：保留原答→SL替线→重问与自动精灵/主动毒药/SL恢复的分段观测；逐击缺帧明确未知，净HP端点不冒完整需损，不更改least-loss正确的−2含义。

预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。

回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。

# 静默猎手策略提案批次回报

记录时间：2026-10-15 12:52:52 CST（写前已运行date）。批次20261015-124302-s2-strategy-proposal；base `4f778c2199657ed0b6a01ece44ab17654552f207`。

本批十原ID逐项为waiting：已有局部实现已经核实，新增规则或完整联合校准仍缺证据。无源码/知识改动、提交、合入、版本或shipped，工作树HEAD保持base。tests三个字段均null；未做撤源码/恢复、tsc或vitest，不把以下材料核验当生产测试。

## 身份与范围

开工git status为空；根learn.json仅只读本批行，task=strategy-proposal、character=silent、reason=proposal、worktree匹配，十个proposal_ids齐全，无proposal_repair/research_request/implementation_request。本批普通专题条件不成立，根deck-size请求绑定另一批；未读取其他专题、领取其他队列或修改请求/调度状态。git merge --no-edit main返回Already up to date。

已读README、最新STATE-2026-10-15、decision-log末尾、学习协议和代码提案闭环。十原Markdown均实读且SHA一致，31个关联账本均silent；只保留原CLI的十ID，不重复登记新提案/历史复盘。

启动日志记录gpt-6.1-sol / xhigh / default，原startup batch/lease及input SHA已只读核对；该启动参数与任务模板high不同，本批没有更改或重启会话，未降低强度。这里只核启动器参数，不能冒称已独立核验原生请求的实际模型/强度，交宿主验收。

## 原始证据与限定结论

共4,489条所属原行，八流按提取开始时source_size冻结，逐行offset/bytes/SHA256/JSON和显式局身份重新读回相符。states角色及runs均SILENT/A10。run-plans读取run字段，其余显式身份由共用入口处理；不以正文提及定归属。

| 局号 | states | decisions | SL | config | plans | brain | runs |
|---|---:|---:|---:|---:|---:|---:|---:|
| MTQ0EUBJ3R6T | 440 | 424 | 5 | 1 | 4 | 23 | 1 |
| 7X0W3U8TVA2A | 461 | 445 | 1 | 1 | 4 | 31 | 1 |
| KFRDELW2TH2P | 620 | 587 | 8 | 1 | 6 | 35 | 1 |
| GXNKW8X1XYJP | 673 | 649 | 7 | 1 | 10 | 48 | 1 |

四局均失败。137条脑记录均engine=codex、model=gpt-6.1-sol、accepted=true；runs旧deepseek_calls字段不是实际引擎归属依据。四局历史code均+dirty，config记录dirty_files为生成知识；完整当时知识与后续变更未冻结，不能据此宣完整运行树复原，也不把dirty直接认作策略源码改动。

源全流解析坏行states2/decisions2/brain1保留，不把全流坏行数当本批缺帧数。fight-plans在本截点实选0，只说明该截点未选到，不推原日志不存在。manifest保留每流source_size/计数/输出SHA；旧截点未重扫或覆盖。

24项固定事实断言通过，细节见facts.json：MTQ F11实际净损6、敌净扣20；KFR F33同盘15血/敌228/36毒/3覆甲，首/第三试净损6/12、敌净扣83/93，末T7毒37→43当步本体159不变，实际毒结算85后敌74；GXN F45下一轮3血0挡/13血7挡及精灵自动消耗，末13血23挡2覆甲仍不足40攻击。只支持局部血价与兑现边界，不证明新选择更安全或能赢。

资源消费者从同一冻结states/SL输入重算；MTQ F19入59出46、F20入46出8，7X0 F30入70出67；KFR F28入46出44、F30入65出27，F33首入房36和可操作38分列；GXN F35/F38/F40连续赢战后97→84→66→41、F44入71出5、F45入房5后可操作7。净耗包含回血/自损，不当敌方毛伤；无出口的SL重启明确missing/restart，不补反事实。

## 已有消费者和源码

四个冻结单局输入调用现有audit-selection.ts全部退出0。仅为工具合同记录排除4条无decision_id或observed_ts的元数据（KFR282561，GXN283515/283525/283581）；原行和SHA完整保留，未重排原行号。此有界输入读回不冒称所有原行都符合消费者合同。

| 局号 | 动作 | 题段 | 可见区间 | 整轮端点 | 未核整轮 | 同题可比预测 |
|---|---:|---:|---:|---:|---:|---:|
| MTQ0EUBJ3R6T | 424 | 68 | 156 | 25 | 50 | 57 |
| 7X0W3U8TVA2A | 445 | 119 | 36 | 7 | 64 | 93 |
| KFRDELW2TH2P | 586 | 180 | 224 | 18 | 85 | 174 |
| GXNKW8X1XYJP | 646 | 116 | 178 | 20 | 83 | 98 |

2,101动作均唯一timestamp+fingerprint匹配状态，共483题段、594相邻区间、70整轮端点、282未知轮、422同题可比预测。现有工具合同始终不认证完整候选actual_full_candidate_result/actual_rollout_best；null不直接证明原日志缺失，也不等于未实际完成。整轮端点和预测排名不充真实最优率或收益。

handTrickSlothFacts对KFR F33T7六个真实选牌帧返回剩余手动名额上界2、能量及continuation_verified=false；observedDemonPoison识别42个限定组合状态帧均为6，包含饮药后帧，不是42次饮药。只是既有函数旧帧读回，不充新自然消费者验收。

读回首稿误按所有楼层奇巧选牌收样，混入F7和F28非懒惰窗口，断言6帧失败。原mjs字节与失败log已保留；改成原证据明确的F33T7边界后原6帧/42帧断言通过，未修改生产逻辑或放宽数值断言。

live读回切点 `fba193dfe31844e1dbde9f2ad7174427fcd446dc`。17路径均核实际live祖先及该提交源码blob与live当前blob相同，live这17工作叶均干净；14与本分支字节相同，3仅历史Roy/Dai注释文字差异，完整差异见source-differences.patch。只认证这些叶，不宣整仓库源码等价。

| 已有源码路径 | 实际live祖先 |
|---|---|
| learner/audit-selection.ts | `6f3f783941270ac182237c46068097ff67e85907` |
| learner/lib/selection-execution.ts | `cf72bd21148059f111f760cc98a727369e34a47e` |
| learner/lib/selection-observation.ts | `cf72bd21148059f111f760cc98a727369e34a47e` |
| learner/lib/selection-turn.ts | `9b87d54f097d84521152e6cca8d6072af8140394` |
| learner/lib/selection-terminal.ts | `04921bd785ac6838066522f91ea0bb6ab95cb6a1` |
| learner/resource_chain.py | `3f69541b5d3259dac94d3395bfe3da47936b4de9` |
| agent/src/reflex/silent-selection-audit.ts | `05cd292c6f01bb31e406473d3a9843e659d62b93` |
| agent/src/reflex/silent-selection-dispatch.ts | `bade647f9fe4c9103b40e2f26b26296692ad24b7` |
| agent/src/reflex/silent-hp-guard-audit.ts | `a8b1f8be153fe4f3a34146117546c2178f2e446b` |
| agent/src/reflex/silent-sl-resource-comparison.ts | `a8b1f8be153fe4f3a34146117546c2178f2e446b` |
| agent/src/hand/screens/silent-hand-trick-facts.ts | `8bb53d6342b7e9a2adf96de231b53c36eaa943de` |
| agent/src/reflex/silent-demon-potion.ts | `8bb53d6342b7e9a2adf96de231b53c36eaa943de` |
| agent/src/reflex/card-model.ts | `ec74a49ce41370c10540c795338cbe5eecb78846` |
| agent/src/reflex/rollout-live.ts | `ae6a8d9950594c9b1e0ebe40fe6ed0866982fe15` |
| agent/src/memory/run-journal.ts | `52d7f343f5f183670dc9d0c0d847bf6a15420aae` |
| agent/src/reflex/combat-plan.ts | `ec74a49ce41370c10540c795338cbe5eecb78846` |
| agent/src/hand/loop.ts | `f685e05173341c045b851a0986f5151b2f915816` |

源码审计与入口调用证实已有子项；本批没有将整项提案标implemented/duplicate。缺整战反事实不是阻止已证机械修复的理由：已证窄入口本来已有，剩余完整归属/联合校准仍未认证，不能凭旧文字重复实现或拟新参数。

## 逐项结果

- **silent-proposal-f54e8de2381c1250：waiting。** 候选、派发与离线重问审计子项已有live源码；F11选牌后重问，原护栏候选没有完整执行归属。缺同窗口完整实线排名，保持waiting。 证据：MTQ0EUBJ3R6T F11T1：decisions282138—282140、states288592—288597；F23末试T3 decision282434。 账本：silent-0125。
- **silent-proposal-763a4b9d9f17b815：waiting。** 普通蛇咬和磨蚀等窄模型已有；十四项临时属性、持牌伤、能力与药效时点的联合消费者校准未覆盖，不能整包duplicate或扩展修饰条件。 证据：7X0W3U8TVA2A F31T1/T2/T5/T6/T11/T13；MTQ0EUBJ3R6T F11T1、F17T4—T8、F20T3、F23四试T2—T5。 账本：silent-0005, silent-0006, silent-0011, silent-0013, silent-0044, silent-0046, silent-0053, silent-0080, silent-0087, silent-0189, silent-0214, silent-0222, silent-0235, silent-0253。
- **silent-proposal-19a5cff2094e2d8f：waiting。** 暂死重接和终局端点审计子项已有；缺敌段生命周期到实际终局的联合校准、冻结知识下同输入整战对照，不能据死亡样本饱和修改终局或SL权重。 证据：7X0W3U8TVA2A F31T5/T6/T13；MTQ0EUBJ3R6T F23末试T3 decision282434及四次尝试。 账本：silent-0021, silent-0064, silent-0079, silent-0133, silent-0125。
- **silent-proposal-3540bf4360bf80af：waiting。** HP增加边界记录已有；原帧核实连续赢战净耗，尚缺逐源资源与药槽事实到完整路线/休息题面的固定读回，保持waiting。 证据：MTQ0EUBJ3R6T F19T1—T3入59出46、F20T1—T7入46出8、F23未到F24；7X0W3U8TVA2A F30入70出67、F31入67。 账本：silent-0019, silent-0020, silent-0243。
- **silent-proposal-0ea5c0b9c030fdd6：waiting。** 奇巧剩余名额/能量及限定组合毒药6层已在live并完成旧帧读回；完整合法后继和目标收益兑现未认证，不能把局部入口当完整提案已实现。 证据：KFRDELW2TH2P F33六试T7 decisions282864/282899/282933/282968/283001/283035；末states289533—289538；反例F28T2。 账本：silent-0274, silent-0247, silent-0027, silent-0016。
- **silent-proposal-f915ec544ab94b6e：waiting。** 生成牌后的重问及同盘多10伤/多6损已核，候选和SL资源差审计已有；仍缺完整执行归属与同输入整战校准，不调整SL权重。 证据：KFRDELW2TH2P F12T1 decisions282578/282579；F33首/第三试T6 states289339/289414→289345/289420，decision282929。 账本：silent-0079, silent-0125。
- **silent-proposal-8fb51933639faf90：waiting。** 知识恶魔毒药6层入口已在live，旧仅覆盖双boss理由已失效；七项药效/能力的联合多轮校准与覆甲完整减层条件仍缺，整项waiting。 证据：KFRDELW2TH2P F28T2；F33六试T2铁心、T4回血/增力、T5触媒、T6/T7覆甲/毒药。 账本：silent-0005, silent-0006, silent-0027, silent-0189, silent-0276, silent-0277, silent-0278。
- **silent-proposal-b3bc0eb09211af6c：waiting。** 奇巧事实、毒药入口与阶段审计子项已有；合法后继到实际终结全链尚未验证，换对象/顺序/提前饮毒整战对照缺失，保留waiting。 证据：KFRDELW2TH2P F33六试T7、首/第三试T6；F12T1；末states289533—289538。 账本：silent-0021, silent-0079, silent-0102, silent-0247, silent-0274。
- **silent-proposal-fdc3a505fe5e1a55：waiting。** 赢战净耗、入房与HP增加边界已有；缺分源事实到完整路线/休息题面的固定消费者对照及替路线/锻造完整结果，不改安全节点或阈值。 证据：KFRDELW2TH2P F28入46出44、F30入65出27、F32休息、F33首入房36而可操作38。 账本：silent-0019, silent-0020, silent-0243。
- **silent-proposal-5a95725089f53cd8：waiting。** 复活后3/13血、0/7挡及逐槽观测已核且窄审计已有；缺逐击复活帧、完整候选归属与逐源资源消费全链，宽提案继续waiting。 证据：GXNKW8X1XYJP F35/F38/F40/F42/F44；F45第二/末试T2—T3 decisions283641/283680/283690/283691，states290160/290165/290201/290206/290212/290213。 账本：silent-0019, silent-0079, silent-0005, silent-0016, silent-0087, silent-0027, silent-0030。

逐项原文路径/SHA、反例、预期行为、样本切分、验证及回退详proposal.md；各提案仍保留原领域，implementation_domains=[]表示本批无实际源码实现。

## 记录与边界

学习账本只经根learner/ledger.py update追加本批proposal/report追溯与备注，不改原claim/首证/prior/evidence/status/version，不新增支持分母，不标shipped。CLI原始输入/输出与读回另存；专用队列waiting由启动器消费report.json，不手改队列或learn.json。

没有新代码提交，未进入live合并/知识刷新/版本分配流程，也没有上线规则需要双通知。保留原未完成量化/策略父项；未发现本批需要另发的新增反证，既有反例与未知已列明。没有源码撤回/恢复测试或成功测试声明；合入提交、发布号均无。

交运维提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-124302-s2/learner/runs/20261015-124313-2b24a68e-7edc-49b7-8368-ffc233c8b964-strategy-proposal/proposal.md

报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-124302-s2/learner/runs/20261015-124313-2b24a68e-7edc-49b7-8368-ffc233c8b964-strategy-proposal/report.md

机器回报：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-124302-s2/learner/runs/20261015-124313-2b24a68e-7edc-49b7-8368-ffc233c8b964-strategy-proposal/report.json

不联网、不读其他角色知识/key/.env/游戏二进制、不运行play、不推送、不派子agent、不修改运维prompt。所有过程材料仅本批scratch，logs只读；本批工作树可由原启动器在实际验收后回收，当前不删自身。

收尾验收（2026-10-15 12:54:01 CST，写前已date）：31条根ledger CLI追溯实写成功并读回，旧claim/首证/prior/asc/evidence/status/version相等；十原ID各有waiting理由。gitleaks材料扫描223.32MB退出0、发现为空。批次身份仍匹配、HEAD仍完整base、git status为空；无新源码/提交/合入/版本，生产测试保持null。详completion-check.json。

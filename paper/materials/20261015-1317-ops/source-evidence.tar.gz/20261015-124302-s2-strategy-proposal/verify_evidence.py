import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

extractor = module('extractor', TREE / 'learner/extract_evidence.py')
resource = module('resource', TREE / 'learner/resource_chain.py')
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
runs = assigned['batch']['runs']
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
verified = 0
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    raw_output = path.read_bytes()
    assert hashlib.sha256(raw_output).hexdigest() == stream['output_sha256']
    rows = [json.loads(line) for line in raw_output.splitlines()]
    counts = Counter()
    handles = {}
    for entry in rows:
        source = handles.setdefault(entry['source'], open(entry['source'], 'rb')) if entry['source'] not in handles else handles[entry['source']]
        source.seek(entry['offset'])
        raw = source.read(entry['bytes'])
        assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == entry['sha256']
        assert json.loads(raw) == entry['row']
        assert extractor.run_identity(entry['row']) == entry['run_id'] in runs
        assert entry['offset'] + entry['bytes'] <= stream['source_size']
        if name == 'states':
            info = entry['row']['state']['run']
            assert info['character_id'].lower() == 'silent' and info['ascension'] == 10
        counts[entry['run_id']] += 1
        verified += 1
    for handle in handles.values():
        handle.close()
    assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
    streams[name] = rows

metadata = {}
for entry in streams['runs']:
    row = entry['row']
    assert row['character'].lower() == 'silent' and row['ascension'] == 10
    metadata[entry['run_id']] = row
assert set(metadata) == set(runs)
assert all(v['character'] == 'silent' for v in assigned['original'].values())
original_checks = []
for ident, proposal in assigned['original'].items():
    actual = hashlib.sha256(Path(proposal['proposal']).read_bytes()).hexdigest()
    assert actual == proposal['proposal_sha256']
    original_checks.append({'id': ident, 'sha256': actual, 'matches': True})

facts = {}
byline = {entry['line']: entry['row']['state'] for entry in streams['states']}
def state(line):
    raw = byline[line]
    player = (raw.get('combat') or {}).get('player') or {}
    return {'line': line, 'floor': raw['run']['floor'], 'turn': raw['turn'],
            'screen': raw['screen'], 'hp': raw['run']['current_hp'], 'block': player.get('block'),
            'energy': player.get('energy'),
            'powers': {p['power_id']: p['amount'] for p in player.get('powers', [])},
            'enemies': [{'id': e['enemy_id'], 'hp': e['current_hp'],
                         'powers': {p['power_id']: p['amount'] for p in e.get('powers', [])}}
                        for e in (raw.get('combat') or {}).get('enemies', [])],
            'potions': [{'index': p['index'], 'id': p['potion_id'], 'occupied': p['occupied'], 'usage': p['usage']}
                        for p in raw['run']['potions']]}
checks = []
def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({'label': label, 'actual': actual, 'expected': expected})

for line in [288592,288593,288594,288595,288596,288597,289339,289345,289414,289420,
             289533,289534,289535,289536,289537,289538,290160,290165,290201,290206,290212,290213,290214]:
    if line in byline:
        facts[str(line)] = state(line)
check('MTQ F11T1→T2 玩家净损', state(288592)['hp'] - state(288597)['hp'], 6)
check('MTQ F11T1→T2 敌血净扣', state(288592)['enemies'][0]['hp'] - state(288597)['enemies'][0]['hp'], 20)
check('MTQ F11选牌中断', state(288593)['screen'], 'CARD_SELECTION')
check('MTQ F11重问后建立毒', state(288595)['enemies'][0]['powers']['POISON_POWER'], 4)
for line in [289339, 289414]:
    check(f'KFR s{line} 同盘资源', [state(line)['hp'],state(line)['enemies'][0]['hp'],
          state(line)['enemies'][0]['powers']['POISON_POWER'],state(line)['powers']['PLATING_POWER']], [15,228,36,3])
check('KFR 首试T6净损', 15-state(289345)['hp'], 6)
check('KFR 第三试T6净损', 15-state(289420)['hp'], 12)
check('KFR 首试T6敌净扣', 228-state(289345)['enemies'][0]['hp'], 83)
check('KFR 第三试T6敌净扣', 228-state(289420)['enemies'][0]['hp'], 93)
check('KFR 末T7饮毒前毒', state(289536)['enemies'][0]['powers']['POISON_POWER'], 37)
check('KFR 末T7饮毒后毒', state(289537)['enemies'][0]['powers']['POISON_POWER'], 43)
check('KFR 饮毒未立即扣本体', [state(289536)['enemies'][0]['hp'],state(289537)['enemies'][0]['hp']], [159,159])
check('KFR 最后毒结算敌净扣', state(289537)['enemies'][0]['hp']-state(289538)['enemies'][0]['hp'], 85)
check('KFR 最后敌仍活', state(289538)['enemies'][0]['hp'], 74)
for line in [290160,290201]:
    check(f'GXN s{line} 同盘HP', state(line)['hp'], 2)
    check(f'GXN s{line} 精灵自动使用类型', state(line)['potions'][1]['usage'], 'Automatic')
check('GXN 第二试下一轮HP/挡', [state(290165)['hp'],state(290165)['block']], [3,0])
check('GXN 末试下一轮HP/挡', [state(290206)['hp'],state(290206)['block']], [13,7])
check('GXN 末试精灵槽空', state(290206)['potions'][1]['occupied'], False)
check('GXN 末试T3结束前HP/挡/覆甲', [state(290212)['hp'],state(290212)['block'],state(290212)['powers']['PLATING_POWER']], [13,23,2])
check('GXN 末试主动毒药加层', state(290213)['enemies'][0]['powers']['POISON_POWER']-state(290212)['enemies'][0]['powers']['POISON_POWER'], 7)

inputs = OUT / 'consumer-inputs'
inputs.mkdir(exist_ok=True)
exclusions = []
resources = []
for run_id in runs:
    def selected(name):
        return [{**entry['row'], '_line': entry['line'], '_source_sha256': entry['sha256']}
                for entry in streams[name] if entry['run_id'] == run_id]
    states = selected('states')
    decisions = selected('decisions')
    filtered = []
    for row in decisions:
        if not row.get('decision_id') or not row.get('observed_ts'):
            exclusions.append({'run_id': run_id, 'line': row['_line'], 'reason': '无decision_id或observed_ts的原元数据；原行保留在evidence', 'row': row})
        else:
            filtered.append(row)
    (inputs / (run_id + '.json')).write_text(json.dumps({'run': metadata[run_id], 'states': states, 'decisions': filtered}, ensure_ascii=False) + '\n')
    starts = {}
    for row in selected('sl-attempts'):
        if row.get('attempt', 1) > 1 and row.get('started_at'):
            starts.setdefault(row['floor'], []).append(row['started_at'])
    report = resource.resource_chain(states, run_id, 'silent', starts)
    (OUT / (run_id + '.resources.json')).write_text(json.dumps(report, ensure_ascii=False) + '\n')
    resources.append({'run': run_id, 'combats': len(report['combats']), 'changes': len(report['resource_changes'])})

(OUT / 'facts.json').write_text(json.dumps({'checks': checks, 'states': facts}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'audit-input-exclusions.json').write_text(json.dumps(exclusions, ensure_ascii=False, indent=2) + '\n')
summary = {'verified_rows': verified, 'runs': metadata, 'original_proposals': original_checks,
           'fixed_fact_assertions': len(checks), 'excluded_metadata': len(exclusions), 'resources': resources,
           'counts': {m['stream']: m['counts'] for m in manifest}}
(OUT / 'verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': verified, 'fixed_fact_assertions': len(checks), 'excluded_metadata': len(exclusions)}, ensure_ascii=False))

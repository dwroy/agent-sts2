import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseGameState } from '../../../agent/src/hand/mod/schema.ts';
import { handTrickSlothFacts } from '../../../agent/src/hand/screens/silent-hand-trick-facts.ts';
import { observedDemonPoison } from '../../../agent/src/reflex/silent-demon-potion.ts';

const dir = fileURLToPath(new URL('.', import.meta.url));
const rows = readFileSync(dir + 'evidence/states.evidence.jsonl', 'utf8').trim().split('\n').map(JSON.parse);
const choices = [], poisons = [];
for (const row of rows) {
  if (row.run_id !== 'KFRDELW2TH2P') continue;
  const raw = row.row.state;
  const state = parseGameState(raw);
  if (raw.run.floor === 33 && raw.turn === 7 && raw.screen === 'CARD_SELECTION' && /奇巧|sly/i.test(raw.selection?.prompt ?? '')) {
    const facts = handTrickSlothFacts(state, true);
    choices.push({ line: row.line, facts: facts ? [...facts.entries()] : null });
  }
  const poison = observedDemonPoison(state);
  if (poison !== null) poisons.push({ line: row.line, poison });
}
if (choices.length !== 6 || choices.some(row => !row.facts || row.facts.some(([, x]) =>
    x.remaining_manual_plays_upper_bound !== 2 || x.continuation_verified !== false))) throw new Error('奇巧原帧读回不符');
if (poisons.length !== 42 || poisons.some(row => row.poison !== 6)) throw new Error('毒药组合原帧读回不符');
writeFileSync(dir + 'narrow-consumer-readback.json', JSON.stringify({
  choices, poisons,
  limitation: '固定旧原帧的既有函数读回；42是状态帧数，不能记42次饮药。currentHandTrick由已核原动作给定，不充在线新自然验收或完整后继认证。',
}, null, 2) + '\n');
console.log(JSON.stringify({ choices: choices.length, poison_frames: poisons.length, poison: 6 }));

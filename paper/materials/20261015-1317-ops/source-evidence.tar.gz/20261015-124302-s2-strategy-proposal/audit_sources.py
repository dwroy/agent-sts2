import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = OUT.parents[2]
LIVE = ROOT / '.worktrees/live'

def git(tree, *args):
    return subprocess.check_output(['git', '-C', str(tree), *args])

paths = [
    'learner/audit-selection.ts', 'learner/lib/selection-execution.ts',
    'learner/lib/selection-observation.ts', 'learner/lib/selection-turn.ts',
    'learner/lib/selection-terminal.ts', 'learner/resource_chain.py',
    'agent/src/reflex/silent-selection-audit.ts', 'agent/src/reflex/silent-selection-dispatch.ts',
    'agent/src/reflex/silent-hp-guard-audit.ts', 'agent/src/reflex/silent-sl-resource-comparison.ts',
    'agent/src/hand/screens/silent-hand-trick-facts.ts', 'agent/src/reflex/silent-demon-potion.ts',
    'agent/src/reflex/card-model.ts', 'agent/src/reflex/rollout-live.ts',
    'agent/src/memory/run-journal.ts', 'agent/src/reflex/combat-plan.ts', 'agent/src/hand/loop.ts',
]
base = git(TREE, 'rev-parse', 'HEAD').decode().strip()
live = git(LIVE, 'rev-parse', 'HEAD').decode().strip()
rows = []
for path in paths:
    commit = git(LIVE, 'log', '-1', '--format=%H', live, '--', path).decode().strip()
    subprocess.run(['git', '-C', str(TREE), 'merge-base', '--is-ancestor', commit, live], check=True)
    current = git(LIVE, 'show', live + ':' + path)
    source = git(LIVE, 'show', commit + ':' + path)
    assert current == source
    local = (TREE / path).read_bytes()
    live_working = (LIVE / path).read_bytes()
    rows.append({'path': path, 'source_commit': commit, 'live_ancestor': True,
                 'source_matches_live_head': True, 'base_sha256': hashlib.sha256(local).hexdigest(),
                 'live_sha256': hashlib.sha256(current).hexdigest(), 'base_equals_live': local == current,
                 'live_working_equals_head': current == live_working})
(OUT / 'source-differences.patch').write_bytes(git(TREE, 'diff', '--binary', base, live, '--', *paths))
(OUT / 'source-audit.json').write_text(json.dumps({'base': base, 'live_head': live, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': base, 'live_head': live, 'paths': len(rows),
                  'equal': sum(row['base_equals_live'] for row in rows),
                  'live_clean_paths': all(row['live_working_equals_head'] for row in rows)}, ensure_ascii=False))

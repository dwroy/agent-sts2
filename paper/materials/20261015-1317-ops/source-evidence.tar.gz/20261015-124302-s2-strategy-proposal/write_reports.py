import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z']).decode().strip()
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
originals = assigned['original']
items = json.loads((OUT / 'dispositions.json').read_text())
assert [x['id'] for x in items] == assigned['batch']['proposal_ids']
verified = json.loads((OUT / 'verification.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
consumer = json.loads((OUT / 'consumer-summary.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
batch = '20261015-124302-s2-strategy-proposal'

report_json = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': batch,
    'base': source['base'], 'runs': assigned['batch']['runs'], 'fixes': [], 'skipped': [],
    'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': [item['id'] for item in items], 'implementation_domains': [],
    'proposal_results': [{'id': item['id'], 'state': 'waiting', 'reason': item['reason']} for item in items],
    'report': str(OUT / 'report.md'),
}
(OUT / 'report.json').write_text(json.dumps(report_json, ensure_ascii=False, indent=2) + '\n')

proposal = ['# 静默猎手十原提案复核\n',
    f'记录时间：{stamp}（写前已运行date）。来源/实现任务strategy-proposal，批次{batch}。范围仅本批四个Silent A10锚点和十原ID；不新增或覆盖提案，不重复写历史复盘。\n',
    '本批没有新源码、知识或规则。旧/拟议行为以每个原Markdown为准，SHA已全部核实。已存在的窄入口及记录不重做；下面记录本次核实范围与未交付范围，不把未充分校准的完整提案记作duplicate。\n']
for item in items:
    original = originals[item['id']]
    proposal.extend([f"## {item['id']}\n", f"原提案：{original['proposal']}\n\nSHA256：{original['proposal_sha256']}\n",
        f"账本：{', '.join(original['ledger'])}。原来源任务：{original['source_task']}；实现任务：strategy-proposal。角色silent，原局已观察A10；授权Roy-2026-10-07-learning不提供游戏事实。\n",
        f"证据：{item['evidence']}\n", f"本次处置：waiting。{item['reason']}\n",
        f"反例/限制：{item['counterexample']}\n", f"拟议行为与验证：{item['validation']}\n",
        '预期影响：在有可核数据时补齐追溯或校准，整场胜率收益未知。本次不拟合参数。固定锚点仅作诊断，同局读档相关；后续独立新局按时间后置验证，不混其他角色。\n',
        '回退：本批无源码可回退。后续任何窄源码改动应独立提交，以实际live祖先和固定消费者验证登记；撤销对应提交，保留原日志、账本、旧知识刷新和未完成宽项。\n'])
(OUT / 'proposal.md').write_text('\n'.join(proposal))

lines = ['# 静默猎手策略提案批次回报\n', f'记录时间：{stamp}（写前已运行date）。批次{batch}；base `{source["base"]}`。\n',
    '本批十原ID逐项为waiting：已有局部实现已经核实，新增规则或完整联合校准仍缺证据。无源码/知识改动、提交、合入、版本或shipped，工作树HEAD保持base。tests三个字段均null；未做撤源码/恢复、tsc或vitest，不把以下材料核验当生产测试。\n',
    '## 身份与范围\n',
    '开工git status为空；根learn.json仅只读本批行，task=strategy-proposal、character=silent、reason=proposal、worktree匹配，十个proposal_ids齐全，无proposal_repair/research_request/implementation_request。本批普通专题条件不成立，根deck-size请求绑定另一批；未读取其他专题、领取其他队列或修改请求/调度状态。git merge --no-edit main返回Already up to date。\n',
    '已读README、最新STATE-2026-10-15、decision-log末尾、学习协议和代码提案闭环。十原Markdown均实读且SHA一致，31个关联账本均silent；只保留原CLI的十ID，不重复登记新提案/历史复盘。\n',
    '启动日志记录gpt-6.1-sol / xhigh / default，原startup batch/lease及input SHA已只读核对；该启动参数与任务模板high不同，本批没有更改或重启会话，未降低强度。这里只核启动器参数，不能冒称已独立核验原生请求的实际模型/强度，交宿主验收。\n',
    '## 原始证据与限定结论\n',
    f'共{verified["verified_rows"]:,}条所属原行，八流按提取开始时source_size冻结，逐行offset/bytes/SHA256/JSON和显式局身份重新读回相符。states角色及runs均SILENT/A10。run-plans读取run字段，其余显式身份由共用入口处理；不以正文提及定归属。\n',
    '| 局号 | states | decisions | SL | config | plans | brain | runs |\n|---|---:|---:|---:|---:|---:|---:|---:|']
for run in assigned['batch']['runs']:
    counts = verified['counts']
    lines.append('| ' + run + ' | ' + ' | '.join(str(counts[name][run]) for name in ['states','decisions','sl-attempts','run-config','run-plans','brain','runs']) + ' |')
lines.extend(['\n四局均失败。137条脑记录均engine=codex、model=gpt-6.1-sol、accepted=true；runs旧deepseek_calls字段不是实际引擎归属依据。四局历史code均+dirty，config记录dirty_files为生成知识；完整当时知识与后续变更未冻结，不能据此宣完整运行树复原，也不把dirty直接认作策略源码改动。\n',
    '源全流解析坏行states2/decisions2/brain1保留，不把全流坏行数当本批缺帧数。fight-plans在本截点实选0，只说明该截点未选到，不推原日志不存在。manifest保留每流source_size/计数/输出SHA；旧截点未重扫或覆盖。\n',
    f'{verified["fixed_fact_assertions"]}项固定事实断言通过，细节见facts.json：MTQ F11实际净损6、敌净扣20；KFR F33同盘15血/敌228/36毒/3覆甲，首/第三试净损6/12、敌净扣83/93，末T7毒37→43当步本体159不变，实际毒结算85后敌74；GXN F45下一轮3血0挡/13血7挡及精灵自动消耗，末13血23挡2覆甲仍不足40攻击。只支持局部血价与兑现边界，不证明新选择更安全或能赢。\n',
    '资源消费者从同一冻结states/SL输入重算；MTQ F19入59出46、F20入46出8，7X0 F30入70出67；KFR F28入46出44、F30入65出27，F33首入房36和可操作38分列；GXN F35/F38/F40连续赢战后97→84→66→41、F44入71出5、F45入房5后可操作7。净耗包含回血/自损，不当敌方毛伤；无出口的SL重启明确missing/restart，不补反事实。\n',
    '## 已有消费者和源码\n',
    '四个冻结单局输入调用现有audit-selection.ts全部退出0。仅为工具合同记录排除4条无decision_id或observed_ts的元数据（KFR282561，GXN283515/283525/283581）；原行和SHA完整保留，未重排原行号。此有界输入读回不冒称所有原行都符合消费者合同。\n',
    '| 局号 | 动作 | 题段 | 可见区间 | 整轮端点 | 未核整轮 | 同题可比预测 |\n|---|---:|---:|---:|---:|---:|---:|'] )
for row in consumer:
    lines.append('| ' + row['run'] + ' | ' + ' | '.join(str(row[k]) for k in ['actions','segments','intervals','turn_endpoints','unknown_turns','comparable_forecasts']) + ' |')
lines.extend(['\n2,101动作均唯一timestamp+fingerprint匹配状态，共483题段、594相邻区间、70整轮端点、282未知轮、422同题可比预测。现有工具合同始终不认证完整候选actual_full_candidate_result/actual_rollout_best；null不直接证明原日志缺失，也不等于未实际完成。整轮端点和预测排名不充真实最优率或收益。\n',
    'handTrickSlothFacts对KFR F33T7六个真实选牌帧返回剩余手动名额上界2、能量及continuation_verified=false；observedDemonPoison识别42个限定组合状态帧均为6，包含饮药后帧，不是42次饮药。只是既有函数旧帧读回，不充新自然消费者验收。\n',
    '读回首稿误按所有楼层奇巧选牌收样，混入F7和F28非懒惰窗口，断言6帧失败。原mjs字节与失败log已保留；改成原证据明确的F33T7边界后原6帧/42帧断言通过，未修改生产逻辑或放宽数值断言。\n',
    f'live读回切点 `{source["live_head"]}`。17路径均核实际live祖先及该提交源码blob与live当前blob相同，live这17工作叶均干净；14与本分支字节相同，3仅历史Roy/Dai注释文字差异，完整差异见source-differences.patch。只认证这些叶，不宣整仓库源码等价。\n',
    '| 已有源码路径 | 实际live祖先 |\n|---|---|'])
for row in source['paths']:
    lines.append(f'| {row["path"]} | `{row["source_commit"]}` |')
lines.extend(['\n源码审计与入口调用证实已有子项；本批没有将整项提案标implemented/duplicate。缺整战反事实不是阻止已证机械修复的理由：已证窄入口本来已有，剩余完整归属/联合校准仍未认证，不能凭旧文字重复实现或拟新参数。\n', '## 逐项结果\n'])
for item in items:
    lines.append(f'- **{item["id"]}：waiting。** {item["reason"]} 证据：{item["evidence"]} 账本：{", ".join(originals[item["id"]]["ledger"])}。')
lines.extend(['\n逐项原文路径/SHA、反例、预期行为、样本切分、验证及回退详proposal.md；各提案仍保留原领域，implementation_domains=[]表示本批无实际源码实现。\n',
    '## 记录与边界\n',
    '学习账本只经根learner/ledger.py update追加本批proposal/report追溯与备注，不改原claim/首证/prior/evidence/status/version，不新增支持分母，不标shipped。CLI原始输入/输出与读回另存；专用队列waiting由启动器消费report.json，不手改队列或learn.json。\n',
    '没有新代码提交，未进入live合并/知识刷新/版本分配流程，也没有上线规则需要双通知。保留原未完成量化/策略父项；未发现本批需要另发的新增反证，既有反例与未知已列明。没有源码撤回/恢复测试或成功测试声明；合入提交、发布号均无。\n',
    f'交运维提案：{OUT / "proposal.md"}\n\n报告：{OUT / "report.md"}\n\n机器回报：{OUT / "report.json"}\n',
    '不联网、不读其他角色知识/key/.env/游戏二进制、不运行play、不推送、不派子agent、不修改运维prompt。所有过程材料仅本批scratch，logs只读；本批工作树可由原启动器在实际验收后回收，当前不删自身。\n'])
(OUT / 'report.md').write_text('\n'.join(lines))

before = json.loads((OUT / 'ledger-fold-before.json').read_text())
requests = []
for ident in sorted(before):
    related = [item['id'] for item in items if ident in originals[item['id']]['ledger']]
    requests.append({'id': ident, 'by': 'learner:strategy-proposal',
                     'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                     'note': f'本批{batch}仅追溯复核；关联原提案{",".join(related)}均waiting。4489所属原行逐offset/bytes/SHA及角色核、24固定事实核验；已有窄live子项不关闭完整候选/联合校准/资源宽项。无新经验/源码/合入/版本，不改旧claim/首证/prior/evidence/status/version；具体证据和缺数据见本批proposal/report。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in requests))
print(json.dumps({'base': source['base'], 'proposal_results': len(items), 'ledger_links': len(requests), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

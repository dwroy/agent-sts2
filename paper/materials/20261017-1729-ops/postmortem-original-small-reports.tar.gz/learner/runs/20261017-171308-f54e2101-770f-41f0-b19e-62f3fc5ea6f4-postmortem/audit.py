import collections,datetime,hashlib,json,re
from pathlib import Path
p=Path(__file__).parent;root=p.parents[2]
names=['runs','decisions','run-plans','states','sl-attempts','brain','run-config','fight-plans','deepseek-reasoning'];valid=0
for name in names:
 with (root/'logs'/f'{name}.jsonl').open('rb') as f:
  for l in (p/f'{name}.jsonl').open():
   e=json.loads(l);f.seek(e['offset']);raw=f.read(e['bytes'])
   assert hashlib.sha256(raw).hexdigest()==e['sha256']
   assert json.loads(raw)==e['row'];valid+=1
D=[json.loads(l) for l in (p/'decisions.jsonl').open()];S=[json.loads(l) for l in (p/'states.jsonl').open()];B=[json.loads(l) for l in (p/'brain.jsonl').open()];C=json.loads((p/'run-config.jsonl').read_text())['row']
J=[e['row'] for e in D if e['row'].get('decider')=='jev'];Q=[r for r in J if 'plan-choice' in r['label']];rank1=sum(bool(re.search(r'code rank 1(?:\D|$)',r.get('rationale',''))) for r in Q)
turns=collections.defaultdict(list);attempt=collections.defaultdict(lambda:1);last=collections.defaultdict(lambda:0)
for e in D:
 r=e['row'];f=r['floor'];t=r.get('turn')
 if not r['label'].startswith('combat/') or t is None:continue
 if t==1 and last[f]>1:attempt[f]+=1
 last[f]=t;turns[f,attempt[f],t].append(r)
code=[];pure=[]
for k,rs in turns.items():
 own=[r for r in rs if r['decider']=='code' and not r.get('rationale','').startswith('continuing the Jev-chosen plan')]
 if own:code.append([list(k),len(own)])
 if all(r['decider']=='code' and not r.get('rationale','').startswith('continuing the Jev-chosen plan') for r in rs):pure.append(list(k))
focus=collections.Counter();offered=0
for r in Q:
 fs=r.get('focus') or {};a=(r.get('answers') or {}).get('plan');key=a.get('choice') if isinstance(a,dict) else a
 if fs:offered+=1;focus[fs.get(key,'无具名focus')]+=1
parse=lambda t:datetime.datetime.fromisoformat(t.replace('Z','+00:00'))
metrics={'raw_rows_verified':valid,'decisions':len(D),'states':len(S),'start':D[0]['row']['ts'],'end':D[-1]['row']['ts'],'decision_span_seconds':(parse(D[-1]['row']['ts'])-parse(D[0]['row']['ts'])).total_seconds(),'config_span_seconds':(parse(D[-1]['row']['ts'])-parse(C['ts'])).total_seconds(),'jev':{'calls':len(J),'input':sum(r.get('usage',{}).get('input_tokens',0) for r in J),'output':sum(r.get('usage',{}).get('output_tokens',0) for r in J),'low':[[e['line'],e['row']['floor'],e['row'].get('turn'),e['row']['confidence']] for e in D if e['row'].get('decider')=='jev' and e['row'].get('confidence',1)<.35],'plan_questions':len(Q),'rank1':rank1,'best':dict(collections.Counter(str(r.get('rollout_best_chosen')) for r in Q)),'focus_offered':offered,'focus':dict(focus)},'brain':{'requests':len(B),'accepted':sum(e['row'].get('accepted') is True for e in B),'models':dict(collections.Counter(str((e['row']['engine'],e['row']['model'],e['row']['effort'])) for e in B)),'usage':{k:sum((e['row'].get('usage') or {}).get(k,0) for e in B) for k in ['inputTokens','outputTokens','cacheHitTokens']},'latency_ms':sum(e['row'].get('latency_ms',0) for e in B)},'combat_rounds':len(turns),'code_rounds':code,'code_actions':sum(n for k,n in code),'pure_code_rounds':pure}
(p/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n');print(json.dumps(metrics,ensure_ascii=False))
R=json.loads((p/'S5GZG328S1LN-resources.json').read_text());proof={}
for c in R['combats']:
 rows=[e for e in S if c['entry']['line']<=e['line']<=(c['exit'] or c['last'])['line']];ts=[];last=None
 for e in rows:
  st=e['row']['state'];t=st.get('turn');co=st.get('combat') or {}
  if t!=last and st.get('in_combat') and co.get('enemies'):
   ts.append({'turn':t,'line':e['line'],'hp':st['run']['current_hp'],'enemy_hp':sum(x['current_hp'] for x in co['enemies'] if x.get('is_alive'))});last=t
 proof[str(c['sequence'])]={'floor':c['floor'],'round_starts':ts,'hp_audit':[{k:t[k] for k in ['turn','live_enemy_hp_start','visible_enemy_hp_loss_lower_bound','observed_hp_added','net_live_enemy_hp_loss','live_enemy_hp_end','gaps']} for t in c['enemy_hp_audit']['turns']]}
(p/'turn-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')

import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));import ledger;import code_proposals
p=Path(__file__).parent;root=p.parents[2]
before=json.loads((p/'ledger-before-selected.json').read_text());rows=ledger.read_rows();after=ledger.fold(rows);updated=['silent-0349','silent-0064','silent-0020','silent-0005','silent-0030'];report={}
for ident in ['silent-0005','silent-0030']:
 previous=[]
 for n,r in rows:
  if r and r.get('id')==ident and any(e.get('run')=='S5GZG328S1LN' for e in r.get('evidence',[])):
   break
  previous.append((n,r))
 before[ident]=ledger.fold(previous)[ident]
(p/'ledger-before-mechanisms-reconstructed.json').write_text(json.dumps({i:before[i] for i in ['silent-0005','silent-0030']},ensure_ascii=False,indent=2)+'\n')
for ident in updated:
 a=after[ident];b=before[ident]
 for k in ['claim','first_run','prior','prior_runs','prior_note','status','version']:
  assert a.get(k)==b.get(k),(ident,k)
 ev=[e for e in a['evidence'] if e['run']=='S5GZG328S1LN'];assert len(ev)==1
 assert ev[0]['role']==('repeat' if ident=='silent-0349' else 'support')
 assert 'S5GZG328S1LN' in a['where']['lessons'];report[ident]={'evidence':ev,'status':a['status'],'version':a.get('version')}
queue=code_proposals.fold(root/'paper/materials/learning/code-proposals.jsonl')
ids=[(p/(n+'-cli.json')).read_text().strip() for n in ['proposal-weak-wail','proposal-resources-reattach']]
for ident in ids:
 x=queue[ident];assert x['state']=='pending';assert x['runs']==['S5GZG328S1LN'];assert Path(x['proposal']).is_file();assert x['source_task']=='postmortem';assert x['target_task']=='strategy-proposal';assert not x.get('implemented_commit')
 for item in x['ledger']:assert x['proposal'] in after[item]['where']['proposal']
 print(ident,x['state'],x['domains'])
(p/'ledger-and-proposals-verified.json').write_text(json.dumps({'items':report,'code_proposals':ids,'proposals_verified':True},ensure_ascii=False,indent=2)+'\n')
raw=(root/'notes/lessons.md').read_bytes();pre=json.loads((p/'lessons-before.json').read_text());assert hashlib.sha256(raw[:pre['bytes']]).hexdigest()==pre['sha256'];tail=raw[pre['bytes']:]
assert tail.count(b'## S5GZG328S1LN')==1;assert '34→40'.encode() in tail and '重试T6'.encode() in tail
(p/'lessons-appended.md').write_bytes(tail)
(p/'lessons-append-verification.json').write_text(json.dumps({'prefix_preserved':True,'prefix':pre,'append_bytes':len(tail),'append_sha256':hashlib.sha256(tail).hexdigest(),'one_heading':True,'erratum_present':True},indent=2)+'\n')
assert int((p/'ledger-check-exit.txt').read_text())==0
print('账本五项保护字段与证据、两提案pending、旧复盘前缀及账本check=0全部核验通过')

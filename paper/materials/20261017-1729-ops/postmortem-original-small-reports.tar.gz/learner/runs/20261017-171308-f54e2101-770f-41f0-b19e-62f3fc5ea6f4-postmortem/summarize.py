import json,collections
from pathlib import Path
p=Path(__file__).parent
D=[json.loads(l) for l in (p/'decisions.jsonl').open()];S=[json.loads(l) for l in (p/'states.jsonl').open()]
def powers(x):return {a['power_id']:a.get('amount') for a in x.get('powers',[])}
with (p/'states-summary.txt').open('w') as f:
 for e in S:
  r=e['row']['state'];c=r.get('combat') or {};q=c.get('player') or {};run=r.get('run') or {}
  f.write(str(e['line'])+' '+json.dumps({'ts':e['row']['ts'],'f':run.get('floor'),'t':r.get('turn'),'screen':r.get('screen'),'hp':run.get('current_hp'),'max':run.get('max_hp'),'player':q,'enemies':[{k:v for k,v in x.items() if k not in ['description']} for x in c.get('enemies',[])],'relics':run.get('relics'),'rest':r.get('rest'),'event':r.get('event')},ensure_ascii=False)+'\n')
print('player keys',list((S[-2]['row']['state'].get('combat') or {})))
for e in S:
 r=e['row']['state'];c=r.get('combat') or {};q=c.get('player') or {}
 if (r.get('run') or {}).get('floor')==28:
  print(e['line'],'T'+str(r.get('turn')),'hp',r['run']['current_hp'],'player',json.dumps(q,ensure_ascii=False)[:350],'enem',[(x['enemy_id'].split('_')[-1],x['current_hp'],x.get('is_alive'),powers(x),[i.get('total_damage') for i in x.get('intents',[])]) for x in c.get('enemies',[])])
print('combat candidate summaries')
for e in D:
 r=e['row']
 if r.get('floor')==28 and 'plan-choice' in r['label']:
  print('d',e['line'],'T',r['turn'],'best',r.get('rollout_best_chosen'),'rollout',r.get('rollout'),'focus',r.get('focus'),'audit keys',list((r.get('selection_audit') or {})))
  plans=(r.get('questions',{}).get('plan') or {}).get('criteria',{})
  for k,v in plans.items():
   try:a=json.loads(v)
   except:continue
   print(k,{z:a.get(z) for z in ['plays','hp_lost','damage_dealt','enemies_after','rollout','focus','hp_after']})

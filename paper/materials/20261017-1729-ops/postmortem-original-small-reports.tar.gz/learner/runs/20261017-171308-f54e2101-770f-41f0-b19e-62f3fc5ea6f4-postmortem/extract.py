import json,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261017-171308-f54e2101-770f-41f0-b19e-62f3fc5ea6f4-postmortem'; run='S5GZG328S1LN'
manifest={}
for name in ['runs','decisions','run-plans','states','sl-attempts','brain','run-config','fight-plans']:
    src=root/'logs'/f'{name}.jsonl'; n=0; offset=0
    with src.open('rb') as f, (out/f'{name}.jsonl').open('w') as g:
        cutoff=src.stat().st_size
        for line_no,line in enumerate(f,1):
            start=offset; offset+=len(line)
            if offset>cutoff: break
            if run.encode() not in line: continue
            try: row=json.loads(line)
            except ValueError: continue
            g.write(json.dumps({'line':line_no,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'row':row},ensure_ascii=False)+'\n');n+=1
    manifest[name]={'count':n,'cutoff':cutoff};print(name,n,flush=True)
dec=[json.loads(l)['row'] for l in (out/'decisions.jsonl').open()];lo=min(r['ts'] for r in dec);hi=max(r['ts'] for r in dec)
n=0
with (root/'logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-reasoning.jsonl').open('w') as g:
    offset=0
    for line_no,line in enumerate(f,1):
        start=offset;offset+=len(line)
        try:r=json.loads(line)
        except ValueError:continue
        if lo<=str(r.get('ts',''))<=hi:
            g.write(json.dumps({'line':line_no,'offset':start,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'row':r},ensure_ascii=False)+'\n');n+=1
manifest['deepseek-reasoning']={'count':n,'start':lo,'end':hi}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(manifest,flush=True)

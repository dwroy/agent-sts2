from pathlib import Path
import json, subprocess, hashlib, re, tarfile
root = Path.cwd(); r = root; p = r / 'ops/codex-ops/record-staging/20261015-1814'; pub = r / 'paper/materials/20261015-1814-ops'; sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-180124-fix-batch'; b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]; report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'failed' and b['rc'] == 0 and not b['proposal_audit_errors']
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and report['code_proposals'] == []
assert report['tests'] == {'tsc': 0, 'vitest': 0, 'cases': 41}
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
audit = json.loads((s / 'audit.json').read_text()); assert len(audit['existing_fixes']) == 72 and audit['new_fixes'] == [] and audit['merge_performed'] is False
assert sha((s / 'queue-snapshot.md').read_bytes()) == audit['queue_sha256']
assert sha(Path(audit['prior_audit']).read_bytes()) == audit['prior_audit_sha256']
for row in audit['existing_fixes']:
    for target in [report['base'], audit['live_read_only_snapshot']]: git('merge-base', '--is-ancestor', row['source_commit'], target)
    assert sha(git('show', report['base'] + ':' + row['path'])) == row['current_source_sha256']
coverage = audit['verification']; assert coverage['vitest_files'] == 9 and coverage['vitest_cases'] == 41 and coverage['filtered_cases'] == 33 and coverage['full_test_sandbox_run'] is False
for label, ref in coverage['logs'].items(): assert sha(Path(ref['path']).read_bytes()) == ref['sha256']
assert (s / 'tsc.exit').read_text().strip() == '0'
assert (s / 'vitest-core.exit').read_text().strip() == '1' and (s / 'vitest-core-r2.exit').read_text().strip() == '0' and (s / 'vitest-fixtures.exit').read_text().strip() == '0'
assert 'Failed to load custom Reporter from basic' in (s / 'vitest-core.log').read_text()
receipt = {'batch': bid, 'canonical_state': b['state'], 'canonical_rc': b['rc'], 'original_report': report, 'native': native, 'original_72_ancestors_and_base_source_hashes_verified': True, 'original_source_review': audit['changed_audited_source_review'], 'original_queue_snapshot_only': {'lines': audit['queue_lines'], 'sha256': audit['queue_sha256'], 'later_2LZ_queue_repeat_not_part_of_this_cut': True}, 'original_coverage': coverage, 'coverage_interpretation': 'tsc0 and 9 selected files/41 cases passed; 33 name-filtered cases not run. Initial reporter startup failure retained. No full-suite pass asserted.', 'no_new_commit_or_merge_blocker': True, 'canonical_failed_rc0_mergednull_preserved': True, 'no_repeated_checks_or_full_or_release': True, 'wide_items_unchanged': True}
(pub / 'fix-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
manifest = []
with tarfile.open(pub / 'fix-original-artifacts.tar.gz', 'w:gz') as tar:
    for f in list(s.iterdir()) + [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]:
        if not f.is_file(): continue
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'fix-original-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'existing_fixes': 72, 'no_new_commit': True, 'canonical': 'failed/rc0/mergednull', 'selected_checks_only': 41, 'filtered': 33}))

from pathlib import Path
import subprocess, json, hashlib, re, os, tarfile, importlib.util
root = Path.cwd(); r = root
p = r / 'ops/codex-ops/record-staging/20261015-1814'
pub = r / 'paper/materials/20261015-1814-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*a, cwd=r): return subprocess.check_output(['git', '-C', str(cwd), *a], stderr=subprocess.PIPE)
bid = '20261015-180124-strategy-proposal'
b = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = b['report']; s = Path(report['report']).parent
assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
assert b['no_change_proposals']['dispositions'] == report['proposal_results']
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == [] and all(x is None for x in report['tests'].values())
assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
exec((r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(bid, report, (r / 'ops/codex-ops/learner' / (bid + '.out')).read_text(), b['worktree'])
assert (pub / 'fix-readback.json').exists()
final = json.loads((s / 'final-validation.json').read_text())
assert final['ledger_cli_rows_verified'] == 16 and final['head_equals_base'] and final['dispatch_binding_unchanged'] and final['waiting_count'] == 10
assert final['gitleaks_exit_code'] == 0 and not final['git_status_porcelain']
ev = json.loads((s / 'evidence-verification.json').read_text()); materials = json.loads((s / 'material-checks.json').read_text())
assert ev['total'] == sum(x['count'] for x in ev['streams']) == 8444
assert all(x['all_selected_bytes_and_identities_verified'] for x in ev['streams'])
assert materials['checks_passed'] == len(materials['checks']) == 48
source = json.loads((s / 'source-readback.json').read_text()); assert len(source['files']) == 13
for x in source['files']:
    a = git('show', report['base'] + ':' + x['path']); z = git('show', source['live_at_read'] + ':' + x['path'])
    assert sha(a) == x['base_sha256'] and sha(z) == x['live_sha256']
    for commit in [x['original_source_commit'], x['last_base_source_commit']]: git('merge-base', '--is-ancestor', commit, source['live_at_read'])
    assert a == z or a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]; owned = []
for raw in (r / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 16
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
(p / 'owned-ledger.jsonl').write_bytes(b''.join(owned))
base = git('rev-parse', 'HEAD').decode().strip(); assert not git('diff', '--cached', '--name-only').strip()
old = git('show', base + ':paper/materials/learning/ledger.jsonl'); seen = set(old.splitlines())
added = b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fold = lambda raw: m.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x]); before = fold(old); after = fold(old + added)
assert set(before) == set(after)
for ident in before:
    for k in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']: assert before[ident].get(k) == after[ident].get(k), (ident, k)
receipt = {'batch': bid, 'original_report': report, 'native': native, 'canonical_no_change_gate': b['no_change_proposals'], 'source13_sha_and_two_provenance_ancestors_each_verified': True, 'two_historical_comment_differences_preserved': True, 'original_material_rows': 8444, 'original_material_assertions': 48, 'material_checks_reexecuted': False, 'owned_ledger_rows': 16, 'protected_fold_preserved': True, 'native_model': 'Original prompt high versus launcher xhigh difference retained; ops verifies actual native gpt-6.1-sol/xhigh/default policy without input/prompt/config changes.', 'historical_brain_source': 'Do not claim all six historical runs were pure Codex; keep original mixed/compatibility labels.', 'original_correction_preserved': '751 T2 paired attempt label corrected 2/3 to 1/3 against anchor; initial script/log/JSON retained, not a production bug.', 'no_source_merge_version_checks_or_game_action': True}
(pub / 'batch-readback.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
files = [f for f in s.iterdir() if f.is_file() and f.stat().st_size < 350000 and f.suffix in ['.json', '.jsonl', '.md', '.py', '.txt', '.patch', '.log'] and f.name not in ['ledger-snapshot.json', 'state-windows.jsonl']]
files += list((s / 'original-proposals').glob('*.md'))
files += [r / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(r)); dest = p / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel); manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'original-artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
line = f'\n- {at} 运维codex：1814两事件闭环：原180124-fix空修复报告failed/rc0/mergednull与原史保持，基线3e1d干净无提交/合入阻塞，不补merge/发号/检查；72既修复源在基线及旧livefe646265祖先和基线叶SHA核，原68同/4个card-model窄差审计保留，宽项不关闭。原tsc0/9文件41定向过、33按名过滤未运行，basic报告器首启动1及改参数后原重跑0留盘，不当完整套件绿或再跑。原180124-strategy十项均waiting/no-source/testsnull，六Silent A10原8444行/48材料断言只读核不复测；13叶SHA及每叶两来源祖先核、11同/两历史注释差保持，16CLI仅where/note，旧claim/首证/prior/evidence/status/version保护同验。两native实际Sol6.1/xhigh/input/lease、workspace-write/no-network核；原题high与launcher xhigh差异保留，不改prompt配置，历史L9来源不冒六局全Codex。751初稿T2第2/3试已按原anchor勘为1/3，旧脚本/JSON/log保留；同局SL不当独立样本、端点/预测/单动作不闭合完整后继或宽父。非复盘且无新经验，不重复刷新论文，原2LZ补证在其后追加不倒填1326行旧队列截点；不派重复学习、不改当前局/账号模型额度队列prompt，不等待未来事件。证据paper/materials/20261015-1814-ops/。\n'
note = f'\n- {at} [ops 修复及策略处置] 原180124-fix无新提交或合入阻塞，72既修复祖先已核；failed/rc0/null保持，原41项定向覆盖不当full，报告器失败及原重跑留盘。原同批strategy十项waiting、16CLI只追溯、无源码/合入/版本/补测，原材料配对标签勘误及来源边界保留。不重复论文刷新或派单，不改对局。回执paper/materials/20261015-1814-ops/。\n'
appends = {'paper/materials/decision-log.md': line, 'ops/inbox-dev.md': note}; (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
for path, text in appends.items():
    with (r / path).open('ab') as out: out.write(text.encode())
helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
    for f in [p / 'prepare-records.py', p / 'seal-records.py', p / 'fix-readback.py', r / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
(pub / 'ops-helper-manifest.json').write_text(json.dumps(helpers, ensure_ascii=False, indent=2) + '\n')
(pub / 'completion.json').write_text(json.dumps({'at': at, 'batch': bid, 'waiting': 10, 'own_ledger_rows': 16, 'no_source_tests_merge_release_or_dataset': True, 'protected_fields_preserved': True, 'native_model_and_original_sandbox_verified': True, 'parallel_records_preserved': True}, ensure_ascii=False, indent=2) + '\n')
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}; values['paper/materials/learning/ledger.jsonl'] = old + added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
dest = p / 'final-files'; rows = []
for path, raw in values.items():
    f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw); rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
(p / 'record-manifest.json').write_text(json.dumps({'base': base, 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env={**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl')}, capture_output=True)
(pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
print(json.dumps({'waiting': 10, 'ledger_rows': 16, 'native_verified': True, 'ledger_check': 0, 'paths': len(rows)}))

import hashlib
import importlib.util
import json
import re
from collections import Counter
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extractor', SCRATCH.parents[2] / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((SCRATCH / 'dispatch.json').read_text())
runs = set(dispatch['runs'])
manifest = json.loads((SCRATCH / 'evidence/evidence-manifest.json').read_text())
data = {}
verification = []
for stream in manifest:
    path = SCRATCH / 'evidence' / (stream['stream'] + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    rows = []
    counts = Counter({r: 0 for r in runs})
    last_offset = -1
    with Path('/home/dw/Projects/agent-sts2/logs', stream['stream'] + '.jsonl').open('rb') as source:
        for line in path.open():
            envelope = json.loads(line)
            assert extractor.run_identity(envelope['row']) == envelope['run_id'] in runs
            assert last_offset < envelope['offset']
            last_offset = envelope['offset']
            assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
            source.seek(envelope['offset'])
            raw = source.read(envelope['bytes'])
            assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
            assert json.loads(raw) == envelope['row']
            row = envelope['row']
            if stream['stream'] == 'states':
                assert row['state']['run']['character_id'] == 'SILENT'
                assert row['state']['run']['ascension'] == 10
            if stream['stream'] in ('runs', 'run-config'):
                assert row['character'] == 'SILENT' and row['ascension'] == 10
            counts[envelope['run_id']] += 1
            rows.append(envelope)
    assert dict(counts) == stream['counts']
    data[stream['stream']] = rows
    verification.append({'stream': stream['stream'], 'count': len(rows), 'source_size': stream['source_size'],
                         'all_selected_bytes_and_identities_verified': True})

def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

save('evidence-verification.json', {'streams': verification, 'total': sum(len(v) for v in data.values()),
                                  'production_tests': None})
attempts = {}
for e in data['sl-attempts']:
    row = e['row']
    key = (e['run_id'], row['floor'], row['attempt'])
    assert key not in attempts
    attempts[key] = e

def turn_metrics(run, floor, attempt, turn):
    e = attempts[(run, floor, attempt)]
    turns = e['row']['summary']['turns']
    start = next(t for t in turns if t['turn'] == turn)
    after = next(t for t in turns if t['turn'] == turn + 1)
    enemy_hp = lambda t: sum(int(a) for a, b in re.findall(r' (\d+)/(\d+)', t['enemies']))
    return {'run': run, 'floor': floor, 'attempt': attempt, 'turn': turn, 'sl_source_line': e['line'],
            'hp_before': start['hp'], 'hp_after': after['hp'], 'hp_loss': start['hp'] - after['hp'],
            'enemy_hp_before': enemy_hp(start), 'enemy_hp_after': enemy_hp(after),
            'enemy_net_hp_reduction': enemy_hp(start) - enemy_hp(after), 'plays': start['plays']}

pairs = []
for run, floor, a, b, turn in [
    ('751FN9QM9MHQ', 17, 1, 3, 2),
    ('751FN9QM9MHQ', 17, 2, 4, 7),
    ('751FN9QM9MHQ', 17, 1, 6, 13),
    ('KV0JHNJCKXLS', 33, 4, 5, 5),
    ('KEN58SH9SLZ6', 17, 4, 5, 10),
    ('KEN58SH9SLZ6', 17, 4, 6, 5),
]:
    before = turn_metrics(run, floor, a, turn)
    after = turn_metrics(run, floor, b, turn)
    pairs.append({'before': before, 'after': after,
                  'delta_hp_loss': after['hp_loss'] - before['hp_loss'],
                  'delta_enemy_net_hp_reduction': after['enemy_net_hp_reduction'] - before['enemy_net_hp_reduction'],
                  'controlled_whole_fight': False})
save('paired-turns.json', pairs)
for pair in pairs:
    print(json.dumps(pair, ensure_ascii=False))

summary = []
for key, e in attempts.items():
    r = e['row']
    anchor = (r.get('explore') or {}).get('anchor')
    summary.append({'run': e['run_id'], 'source_line': e['line'], 'floor': r['floor'],
                    'attempt': r['attempt'], 'turns': r['turns'], 'result': r['result'],
                    'end_hp': r['end_hp'], 'end_block': r['end_block'], 'incoming': r['incoming'],
                    'last_turn': r['summary']['turns'][-1], 'anchor': anchor})
save('attempt-summary.json', summary)

state_lines = {e['line']: e for e in data['states']}
decision_lines = {e['line']: e for e in data['decisions']}

def compact_state(e):
    s = e['row']['state']
    c = s.get('combat') or {}
    p = c.get('player') or {}
    return {'source_line': e['line'], 'run': e['run_id'], 'ts': e['row']['ts'],
            'turn': s.get('turn'), 'floor': s['run']['floor'], 'hp': p.get('current_hp', s['run']['current_hp']),
            'block': p.get('block'), 'powers': p.get('powers'),
            'potions': [{'index': p['index'], 'id': p.get('potion_id'), 'occupied': p.get('occupied')} for p in s['run']['potions']],
            'enemies': [{k: enemy.get(k) for k in ['enemy_id', 'current_hp', 'max_hp', 'block', 'powers', 'intents', 'move_id', 'is_alive']}
                        for enemy in c.get('enemies', [])],
            'hand': [{k: card.get(k) for k in ['index', 'card_id', 'upgraded', 'resolved_rules_text']}
                     for card in c.get('hand', [])]}

selected = [278383, 278403, 278407, 280160, 280161, 280162,
            280206, 280207, 280232, 280233, 280262, 280263, 280313, 280314,
            280315, 280316, 280348, 280349, 280354, 280355,
            280697, 280705, 280709, 280713, 280717, 280718, 280723]
save('selected-states.json', [compact_state(state_lines[n]) for n in selected])
use = []
for e in data['decisions']:
    r = e['row']
    if e['run_id'] == 'KEN58SH9SLZ6' and r.get('chosen', {}).get('action') == 'use_potion':
        use.append({'source_line': e['line'], 'floor': r['floor'], 'turn': r['turn'],
                    'chosen': r['chosen'], 'result': r.get('result'), 'observed_ts': r.get('observed_ts')})
save('ken-potion-dispatches.json', use)
print('KEN实际饮用请求', len(use))
for e in use:
    print(json.dumps(e, ensure_ascii=False))
questions = []
for n in [272361, 272434, 272575, 272531, 272652, 274505, 274568, 274484, 274601, 274087]:
    e = decision_lines[n]
    r = e['row']
    questions.append({'source_line': n, 'row': r})
    print('决策', n, r.get('sl_attempt'), r.get('turn'), r.get('chosen'), 'question_type', type(r.get('questions')).__name__)
save('selected-decisions.json', questions)

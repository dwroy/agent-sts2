# 本批10项既有Silent提案的复核处置

本批只消费dispatch.json列明的10个已领取id，不另立提案。所有原Markdown保存路径及SHA见original-proposal-shas.json，逐项证据局、层/回合、账本、反例、既有行为、缺口与验证方法见report.md。没有证据支持新策略门槛，均waiting；不冒称已有局部日志已闭合整项。

| silent-proposal-366288801d9150d9 | silent-0079, silent-0176 | 751FN9QM9MHQ | waiting：751 F17 T2/T7/T13同指纹差分已核；现有SL分账仅为候选预测，缺抽弃续问后候选到完整回合的执行归属及受控整战后继，不能拟合额外失血门槛。 |
| silent-proposal-85929bdfc8a3fc1b | silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176 | 751FN9QM9MHQ | waiting：751 F13 T3用药plan2与全程无药模型plan5均8/8结束、损8；plan3后轮仍7/8用药。缺实际无药整战、留至boss分支及弃呼唤后的完整逐源结算，持有价值不能置零。 |
| silent-proposal-efd9f83ee9e1a6dc | silent-0079, silent-0176 | 751FN9QM9MHQ | waiting：751换线多9净扣付5血、多6付10及省6少6均复核，六试同局均败；已有模型分账不能代替整轮实果，缺受控后继及后期独立验证，不改SL排序。 |
| silent-proposal-131042659448ae74 | silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176 | 751FN9QM9MHQ | waiting：已有持牌保守失血、未决弃牌、持药值未知等结构字段，但actual_turn仍null；缺攻击/毒/荆棘逐源归属、能力后继兑现和完整无药跨战结果，不能标整项duplicate。 |
| silent-proposal-990f054036609447 | silent-0102, silent-0019, silent-0020 | KV0JHNJCKXLS | waiting：KV F33第4/5试T5去掉致命毒药后净扣36→29、均零损；后轮条件亦变，缺受控完整后继、回血逐源与未执行路线/休息实果，不定SL或终局权重。 |
| silent-proposal-e18d3f18e6cac2a0 | silent-0017, silent-0250, silent-0011, silent-0027, silent-0046 | YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN | waiting：巨兽阶段、原始占位血和末态资源已有live祖先源码；anchorRank仍保留原始占位HP作同轮tie-break。L9/YQL失败及PU第五次F17胜均保留，缺改序后的受控完整后继和结局校准。 |
| silent-proposal-9733bb80f445aeae | silent-0017, silent-0019, silent-0020, silent-0250 | YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN | waiting：YQL F17末试T10毒水使残壳毒2→8，26血/13挡/自爆41均未变；已有提示不证明提前喝、不喝、留药或改变SL排序的整战收益，缺这些受控分支。 |
| silent-proposal-c51468c5e8ba6668 | silent-0019 | KEN58SH9SLZ6 | waiting：KEN七次use_potion均有后帧槽位消耗，三次原回执为pending；缺随机选牌/发光水重问后完整收益归属及F15不喝或留至boss的整战分支，不能量化跨战持药值。 |
| silent-proposal-86a7db08d1a31976 | silent-0079, silent-0021, silent-0125, silent-0005, silent-0176 | KEN58SH9SLZ6 | waiting：KEN F17第4/5试T10多损6仅多净扣2，第4/6试T5省2却将步法T5延至T9；缺完整逐源归属、受控整战及新局留出验证，不能设统一6血/2伤准入阈值。 |
| silent-proposal-e282a9131b99129a | silent-0021, silent-0079, silent-0125, silent-0176 | KEN58SH9SLZ6 | waiting：KEN双向取舍与原经验一致，六次SL仍同一局且未胜；现有预测和单动作回执不闭合能力后继及整轮实果，缺受控胜线和后期独立验证，保留探索及HP护栏。 |

本批期望行为为保留现行策略、已有提示和所有合法候选；未改变铁甲或未观察进阶。48项原始材料检查只核证据，不证明新规则有效。若未来实施，按每原提案的固定验证与回退流程，实际live源码祖先成立后再登记implemented，实际shipped由ops核实。原框架、未知和失败历史保留。

import json
from pathlib import Path

s = Path(__file__).resolve().parent
checks = []

def check(name, condition):
    assert condition, name
    checks.append(name)

pairs = json.loads((s / 'paired-turns.json').read_text())
for pair, expected in zip(pairs, [(13, 18, 9, 18), (13, 23, 12, 18), (8, 2, 17, 11),
                                  (0, 0, 36, 29), (15, 21, 2, 4), (7, 5, 1, 2)]):
    a, b = pair['before'], pair['after']
    check(f"{a['run']} F{a['floor']} T{a['turn']} attempts {a['attempt']}/{b['attempt']} resources",
          (a['hp_loss'], b['hp_loss'], a['enemy_net_hp_reduction'], b['enemy_net_hp_reduction']) == expected)
q = {e['source_line']: e['row'] for e in json.loads((s / 'selected-decisions.json').read_text())}
for a, b in [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601)]:
    check(f'decisions {a}/{b} same fingerprint', q[a]['fingerprint'] == q[b]['fingerprint'])
for n, original, replacement, diff, se in [(272575, .195, .193, -.0025, .0135),
                                         (272652, .103, .013, -.09, .0088),
                                         (274568, .385, .127, -.2583, .0132),
                                         (274601, .042, .033, -.0083, .0068)]:
    b = q[n]['sl_explore']['b2']
    check(f'decisions {n} recorded paired B2', (b['original'], b['replacement'], b['diff'], b['se']) ==
          (original, replacement, diff, se))
candidates = {k: json.loads(v) for k, v in q[272361]['questions']['plan']['criteria'].items()}
check('751 F13 T3 potion/no-potion current HP', [candidates[k]['hp_lost'] for k in ['plan2', 'plan3', 'plan5']] == [8, 8, 8])
check('751 F13 T3 immediate damage', [candidates[k]['damage_dealt'] for k in ['plan2', 'plan3', 'plan5']] == [26, 16, 16])
check('751 F13 T3 later potion possible plan3', '7/8' in candidates['plan3']['potion_cost'])
check('751 F13 T3 full no-potion model reference plan5', 'no potion for the rest' in candidates['plan5']['no_potion_fight'])
check('751 F13 T3 same sampled end count', all('8/8' in candidates[k]['rollout'] for k in ['plan2', 'plan3', 'plan5']))
states = {e['source_line']: e for e in json.loads((s / 'selected-states.json').read_text())}
for a, b, slot, potion in [(280206, 280207, 0, 'ATTACK_POTION'), (280232, 280233, 0, 'STABLE_SERUM'),
                           (280262, 280263, 0, 'SPEED_POTION'), (280313, 280314, 1, 'WEAK_POTION'),
                           (280315, 280316, 0, 'ATTACK_POTION'), (280348, 280349, 1, 'GLOWWATER_POTION'),
                           (280354, 280355, 0, 'SKILL_POTION')]:
    check(f'KEN actual potion-slot consumption states {a}/{b}',
          states[a]['potions'][slot]['id'] == potion and states[b]['potions'][slot]['id'] is None)
    check(f'KEN actual potion snapshot same turn states {a}/{b}',
          states[a]['run'] == states[b]['run'] == 'KEN58SH9SLZ6' and states[a]['floor'] == states[b]['floor']
          and states[a]['turn'] == states[b]['turn'])
uses = json.loads((s / 'ken-potion-dispatches.json').read_text())
check('KEN seven actual use requests', len(uses) == 7)
check('KEN three pending receipts require later state', sum('pending' in e['result'] for e in uses) == 3)
for n, poison in [(280160, 2), (280161, 8)]:
    e = states[n]
    enemy = e['enemies'][0]
    check(f'YQL F17 T10 state {n} exact phase/HP/block/incoming',
          e['hp'] == 26 and e['block'] == 13 and enemy['current_hp'] == 999999999
          and enemy['move_id'] == 'EXPLODE_MOVE' and enemy['intents'][0]['damage'] == 41)
    check(f'YQL F17 T10 state {n} poison', enemy['powers'][0]['amount'] == poison)
check('YQL actual death is clamped HP0', states[280162]['hp'] == 0)
check('KEN T10 final-attempt observed HP loss14', states[280705]['hp'] - states[280709]['hp'] == 14)
check('KEN T12 final-attempt observed HP loss13', states[280713]['hp'] - states[280718]['hp'] == 13)
attempts = json.loads((s / 'attempt-summary.json').read_text())
for run, floor, count in [('751FN9QM9MHQ', 17, 6), ('KEN58SH9SLZ6', 17, 6),
                          ('YQL8RZ8BWN1E', 17, 6), ('L9SGRBB5R698', 17, 6)]:
    rows = [e for e in attempts if e['run'] == run and e['floor'] == floor]
    check(run + ' six related failed attempts', len(rows) == count and not any(e['result'] == 'won' for e in rows))
pu = [e for e in attempts if e['run'] == 'PU80F84P6HPN' and e['floor'] == 17]
check('PU F17 fifth attempt won, whole run still failed later', len(pu) == 5 and pu[-1]['result'] == 'won' and pu[-1]['end_hp'] == 2)
check('all extracted lines verified', json.loads((s / 'evidence-verification.json').read_text())['total'] == 8444)
(s / 'material-checks.json').write_text(json.dumps({'checks_passed': len(checks), 'checks': checks,
                                                 'production_tests': None}, ensure_ascii=False, indent=2) + '\n')
print(f'{len(checks)} evidence/material checks passed; no production tests run')

# Silent 本批策略提案核验

本批没有足够的新证据支持更改策略。10项派发提案均保留 waiting；不重复实现已有的局部诊断，不将它们登记为整项 duplicate。没有新增源码、知识、提案 id、提交、live合入或发布号，不登记 shipped。

## 身份、基线与范围

- task=strategy-proposal，character=silent，batch=20261015-180124-strategy-proposal；根learn.json对应行 task/character/worktree/runs 已核，reason=proposal，只处理派发的10个proposal_ids，proposal_repair/research_request/implementation_request均未出现。
- 普通专题请求文件绑定的是20261010旧批，与本批不匹配，未读取其他专题输入；本批沿普通队列处理。
- 开工树干净，原HEAD=de83b8eadbba3de9de0993a7397c454de6ed37e3；依指示 merge main 无冲突快进后，report.base=3e1d6d5405fc9cbf6cea7858dfe79f7e49c88ccb。本批不再跟随后续main。
- 六局均经runs及各原状态核为SILENT A10。六局最终均败；PU F17第5试获胜、整局后来F33败，分账。L9的原deciders含deepseek (for codex)，不能冒称六局全部纯Codex大脑样本。
- 自己完成，无下级agent，无对局/模型API/网络请求。只读取Silent角色知识及相关通用源码，没有读取其他角色知识文件。现场dirty知识版本未恢复，不把当前经验库/当前源码当成当时完整运行树。
- 启动器本次实际记录命令参数为gpt-6.1-sol、xhigh、service_tier=default（launch-settings.json），与题面high不一致，未在模型内改配置或声称已切换；未独立读到原生会话模型元数据。

## 原始证据与复核

共享extract_evidence.py按显式run_id/state.run_id/fingerprint.run/run取身份，保存八流逐行源路径、原行号、offset、bytes、SHA256与各流source_size，随后逐条seek原日志核原字节、JSON、唯一身份与角色。共8444行：states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、runs6、fight-plans0。零fight-plans仅表示本截点未选到，不能推断历史完全缺失。源流的2/2/1条坏JSON分别在states/decisions/brain，全源扫描计数，不是本批已归属证据。完整切点在evidence/evidence-manifest.json；本次不复用旧截点或覆盖旧报告。

48项数值/身份材料核验通过（material-checks.json），不是生产tsc/vitest、候选策略自测或整战模拟校准。关键支持与反例：

- 751FN9QM9MHQ F17，T2第1/3试（decisions272434/272575同指纹）净扣敌9→18、损13→18；T7第2/4试（272531/272652同指纹）净扣12→18、损13→23；T13第1/6试净扣17→11、损8→2。B2为当时保存预测，局部净血差含实际毒/反伤，不能统称卡牌伤。六次同局失败，不当六个独立训练/验证样本。
- 751 F13 T3（272361）用药plan2/本轮无药plan3/整战无药模型plan5即损均8、模型终结均8/8；牌伤26/16/16。plan3后轮7/8仍用药，plan5才全程无药。F11取得药及F13饮用后58→50经states278383/278403/278407核；没有实际无药完整战斗或留至boss对照，不认定饮用错误或持有值0。
- KV0JHNJCKXLS F33 T5第4/5试，30血/敌334底板：去掉致命毒药+后净扣36→29，两次当轮都零损；下一轮毒20→13，后继也变化，不能把删输出称作已得保血。敌回血毛/净及路线、休息未执行分支仍需另核。
- YQL8RZ8BWN1E F17末试T10（274087，states280160/280161），残壳毒2→8，玩家26血13挡、来袭41与占位血999999999不变；280162实际HP截断0。26+13−41=−2只是原末态算术，不是替线胜率、也不证明提前喝必胜。
- 巨兽反例：L9SGRBB5R698六试未过；PU80F84P6HPN F17第5试胜余2血（sl源719；各试715—719详attempt-summary.json）；YQL六次清本体仍未过。原始占位血与本体进度必须分离，最长存活、残壳多扣毒和单独早清本体都不能独立证明获胜。原SL anchor保存的占位排名保留，没有受控改序结果。
- KEN58SH9SLZ6 F17第4/5试T10（274505/274568同指纹）37血/敌82且无实体，净损15→21、净扣2→4；原B2 .385→.127、配对差−.2583、se .0132。第4/6试T5（274484/274601同指纹）净损7→5、扣1→2，但步法T5延T9；这是“只保血恒优”的反例，不反驳双向成本。六次仍同一局且未胜。
- KEN F3T2/F4T1/F5T2/F11T1/F11T2/F15T1两瓶，七次use_potion与七组槽位实际清空一致；decisions274131/274237/274272最初回执pending，后帧核到耗药；不能以单动作回执证明随机选牌、重问后的整条收益。F15不喝和留至boss支线未实际执行。

初始材料脚本曾将751 T2第2/3试作为数值配对，数字同13→18与9→18，但题面锚点272434实际第1试；已改为第1/3试，并保留initial脚本、日志和JSON，不把材料选择调整当产品bug。几次初始路径探针不存在（turn-comparison.ts、src/loop.ts、sl/phase-resources.ts），随后按rg实际文件定位，不据路径不存在断言功能不存在。

## 当前实现与仍未闭合的范围

13叶源码与实际live fe6462651b593b9831581c088deface9957a404f读回：11叶字节相同，explore.ts/potion-cost.ts差异均仅历史Roy/Dai注释文字，完整patch保留。每叶原引入及base最后修改提交均核实际live祖先，live磁盘叶等于该live提交；详source-readback.json。本批没有以这些旧提交冒充自己的实现：

- silent-sl-comparison / silent-sl-resource-comparison / silent-selection-audit的原源码祖先66283dd9982bdd7f480da7a4d9bfefea0572a9ac；candidate_forecast/current_turn_prediction、original_stage明确，actual_turn_result/actual_turn仍null。
- silent-selection-dispatch原源码祖先fdaf787a372880b0438e73bcac7e6d2168b038ed，只给single_action_receipt，state_effect_verified=false、whole_plan_executed=null。
- silent-held-loss原源码祖先9d8278702dbc581b5015ba7ec9a70dc0fb94cccb，已列持牌损血来源、挡后入伤与discard_choice_pending，actual_held_hp_loss仍null；不能靠减法把余项称确定敌伤。
- silent-potion-reference原源码祖先c4670f4f416c7d93e192e889c5080e7e4e0e733f，已区分未知持药值、当轮无药与整战无药模型；没有跨战实际价值。
- silent-giant-potion原源码祖先40168f4a903ae1d8c48bd03006f8fea19fd3aa3c，已显示本体结束/残壳/当帧资源及YQL局部毒水事实；sl/attempts已有giant_phase和受限末态资源字段。explore.anchorRank仍按原存活轮及原始enemyHpLeft比较，缺改排序受控后继，不能将整宽项标duplicate。

## 逐项处置

| 派发ID | 既有账本 | 证据局 | 处置与具体缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | silent-0079, silent-0176 | 751FN9QM9MHQ | waiting：751 F17 T2/T7/T13同指纹差分已核；现有SL分账仅为候选预测，缺抽弃续问后候选到完整回合的执行归属及受控整战后继，不能拟合额外失血门槛。 |
| silent-proposal-85929bdfc8a3fc1b | silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176 | 751FN9QM9MHQ | waiting：751 F13 T3用药plan2与全程无药模型plan5均8/8结束、损8；plan3后轮仍7/8用药。缺实际无药整战、留至boss分支及弃呼唤后的完整逐源结算，持有价值不能置零。 |
| silent-proposal-efd9f83ee9e1a6dc | silent-0079, silent-0176 | 751FN9QM9MHQ | waiting：751换线多9净扣付5血、多6付10及省6少6均复核，六试同局均败；已有模型分账不能代替整轮实果，缺受控后继及后期独立验证，不改SL排序。 |
| silent-proposal-131042659448ae74 | silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176 | 751FN9QM9MHQ | waiting：已有持牌保守失血、未决弃牌、持药值未知等结构字段，但actual_turn仍null；缺攻击/毒/荆棘逐源归属、能力后继兑现和完整无药跨战结果，不能标整项duplicate。 |
| silent-proposal-990f054036609447 | silent-0102, silent-0019, silent-0020 | KV0JHNJCKXLS | waiting：KV F33第4/5试T5去掉致命毒药后净扣36→29、均零损；后轮条件亦变，缺受控完整后继、回血逐源与未执行路线/休息实果，不定SL或终局权重。 |
| silent-proposal-e18d3f18e6cac2a0 | silent-0017, silent-0250, silent-0011, silent-0027, silent-0046 | YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN | waiting：巨兽阶段、原始占位血和末态资源已有live祖先源码；anchorRank仍保留原始占位HP作同轮tie-break。L9/YQL失败及PU第五次F17胜均保留，缺改序后的受控完整后继和结局校准。 |
| silent-proposal-9733bb80f445aeae | silent-0017, silent-0019, silent-0020, silent-0250 | YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN | waiting：YQL F17末试T10毒水使残壳毒2→8，26血/13挡/自爆41均未变；已有提示不证明提前喝、不喝、留药或改变SL排序的整战收益，缺这些受控分支。 |
| silent-proposal-c51468c5e8ba6668 | silent-0019 | KEN58SH9SLZ6 | waiting：KEN七次use_potion均有后帧槽位消耗，三次原回执为pending；缺随机选牌/发光水重问后完整收益归属及F15不喝或留至boss的整战分支，不能量化跨战持药值。 |
| silent-proposal-86a7db08d1a31976 | silent-0079, silent-0021, silent-0125, silent-0005, silent-0176 | KEN58SH9SLZ6 | waiting：KEN F17第4/5试T10多损6仅多净扣2，第4/6试T5省2却将步法T5延至T9；缺完整逐源归属、受控整战及新局留出验证，不能设统一6血/2伤准入阈值。 |
| silent-proposal-e282a9131b99129a | silent-0021, silent-0079, silent-0125, silent-0176 | KEN58SH9SLZ6 | waiting：KEN双向取舍与原经验一致，六次SL仍同一局且未胜；现有预测和单动作回执不闭合能力后继及整轮实果，缺受控胜线和后期独立验证，保留探索及HP护栏。 |

## 交付与验证边界

本批只核验原提案，原Markdown逐SHA全部匹配（original-proposal-shas.json），不新建重复id，不改原文。16个关联Silent账本仅经根learner/ledger.py update追加本批报告/提案链接与note，不改claim、evidence、first_run、prior、status或version；原shipped经验不降为proposed，也不把本批处置记shipped。CLI与保护字段复核见ledger-update.log、ledger-protected-readback.json。

拟议后续验证仍按原提案：先把候选、抽弃/药水重问、完整回合执行与逐源结算对应，保留未知；如改排序/持有值，需同盘完整受控后继，独立局按真实时间切分，不能同局SL跨训练/留出。没有数据时保留现行行为，不新增阈值或宣称胜率提升。

源码撤除失败/恢复通过：不适用，没有源码实现。本批tsc/vitest/cases均null，未跑生产测试。没有代码提交或live合并，merged=null、版本=null；保留已有行为，未触发规则上线双通知。不运行play、不停局、不推送、不改运维prompt。

最终机器结果见result.json；工作树最终HEAD仍等于report.base，跟踪与非忽略工作区无改动，scratch为既有忽略目录。密钥扫描与末次git核对见final-validation.json/gitleaks.log。

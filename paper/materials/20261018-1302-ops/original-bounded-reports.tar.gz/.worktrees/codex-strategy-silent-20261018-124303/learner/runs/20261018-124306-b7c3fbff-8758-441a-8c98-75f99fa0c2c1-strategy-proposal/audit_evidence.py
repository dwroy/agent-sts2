import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE.parents[1]))
from extract_evidence import run_identity


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(values):
    return {p['power_id']: p['amount'] for p in values if p.get('amount')}


def compact(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'],
        'observed_ts': item['row'].get('observed_ts'),
        'floor': (state.get('run') or {}).get('floor'),
        'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp'), 'block': player.get('block'),
        'energy': player.get('energy'), 'powers': powers(player.get('powers', [])),
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'),
                     'hp': e.get('current_hp'), 'block': e.get('block'),
                     'powers': powers(e.get('powers', [])),
                     'move': e.get('move_id'), 'intents': e.get('intents')}
                    for e in combat.get('enemies', [])],
    }


records = {}
checks = []
for directory in ['evidence', 'evidence-extra']:
    manifest = json.loads((HERE / directory / 'evidence-manifest.json').read_text())
    for entry in manifest:
        name = entry['stream']
        path = HERE / directory / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        counts = dict.fromkeys(entry['counts'], 0)
        rows = []
        with path.open('rb') as selected, Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as original:
            for line in selected:
                digest.update(line)
                item = json.loads(line)
                original.seek(item['offset'])
                raw = original.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                assert run_identity(item['row']) == item['run_id']
                assert item['offset'] + item['bytes'] <= entry['source_size']
                counts[item['run_id']] += 1
                rows.append(item)
        assert digest.hexdigest() == entry['output_sha256']
        assert counts == entry['counts']
        records[name] = rows
        checks.append({**entry, 'verified_rows': len(rows), 'raw_readback': True})
save('evidence-readback.json', checks)

states = {x['line']: x for x in records['states']}
decisions = {x['line']: x for x in records['decisions']}
by_run = {}
for item in records['states']:
    by_run.setdefault(item['run_id'], []).append(item)
for item in records['runs']:
    assert item['row']['character'] == 'SILENT'
    assert item['row']['ascension'] == 10
save('run-identities.json', records['runs'])


def criterion(number, key):
    return json.loads(decisions[number]['row']['questions']['plan']['criteria'][key])


def turn_boundary(number):
    decision = decisions[number]
    row = decision['row']
    candidates = by_run[decision['run_id']]
    before = [x for x in candidates if x['row'].get('observed_ts') == row['observed_ts']]
    assert len(before) == 1, (number, len(before))
    first = before[0]
    later = [x for x in candidates if x['line'] > first['line'] and
             (x['row']['state'].get('run') or {}).get('floor') == row['floor'] and
             (x['row']['state'].get('turn') or 0) > row['turn']]
    last = later[0] if later else None
    return {'decision_line': number, 'sl_attempt_recorded': row.get('sl_attempt'),
            'start': compact(first), 'next_turn': compact(last) if last else None,
            'scope': 'observed boundaries; not proof of uninterrupted candidate execution'}


findings = {}
findings['apotheosis_energy'] = [compact(states[n]) for n in [275564, 275565, 275679, 275680]]
assert findings['apotheosis_energy'][0]['energy'] - findings['apotheosis_energy'][1]['energy'] == 2
assert findings['apotheosis_energy'][2]['energy'] - findings['apotheosis_energy'][3]['energy'] == 2
findings['apotheosis_f43_candidate_before_after'] = [criterion(269706, 'plan1'), criterion(269707, 'plan1')]
assert [x['damage_dealt'] for x in findings['apotheosis_f43_candidate_before_after']] == [43, 51]
assert [x['hp_lost'] for x in findings['apotheosis_f43_candidate_before_after']] == [14, 13]
findings['potion_budget_different_fingerprints'] = decisions[269748]['row']['fingerprint'] != decisions[269754]['row']['fingerprint']
assert findings['potion_budget_different_fingerprints']
findings['potion_budget'] = [{k: decisions[n]['row'].get(k) for k in ['observed_ts', 'timing', 'potions', 'rollout', 'answers', 'chosen']} for n in [269748, 269754]]
findings['sl_same_fingerprint'] = decisions[270216]['row']['fingerprint'] == decisions[270282]['row']['fingerprint']
assert findings['sl_same_fingerprint']
findings['sl_observed_boundaries'] = [turn_boundary(n) for n in [270216, 270282, 270264]]
assert [x['start']['hp'] - x['next_turn']['hp'] for x in findings['sl_observed_boundaries']] == [3, 15, 4]
findings['sl_same_board_candidates'] = [criterion(270282, 'plan1'), criterion(270282, 'plan2')]
findings['knights_t4_candidates'] = [criterion(269770, 'plan1'), criterion(269770, 'plan2')]
findings['knights_last_frames'] = [compact(x) for x in records['states'] if x['run_id'] == 'VLZ6CCT8AQ0A' and 275749 <= x['line'] <= 275756]

focused = []
for run, floor in [('CA5KE8GFJ9X2', 13), ('61E2QS63Y9WU', 17), ('61E2QS63Y9WU', 23), ('5PM6JAQG6FNQ', 33), ('5PM6JAQG6FNQ', 39), ('DUZUBAJ3A8GP', 30)]:
    rows = [x for x in by_run[run] if (x['row']['state'].get('run') or {}).get('floor') == floor]
    focused.extend(compact(x) for x in rows)
save('focused-observations.json', focused)

bubbles = []
for item in records['decisions']:
    row = item['row']
    if item['run_id'] != '5PM6JAQG6FNQ' or row.get('floor') != 39 or row.get('turn') != 2:
        continue
    if ((row.get('expect') or {}).get('card') or {}).get('id') != 'BUBBLE_BUBBLE':
        continue
    matching = [x for x in by_run[item['run_id']] if x['row'].get('observed_ts') == row.get('observed_ts')]
    if len(matching) != 1:
        continue
    before = matching[0]
    after = next(x for x in by_run[item['run_id']] if x['line'] > before['line'])
    bubbles.append({'decision_line': item['line'], 'decision': row, 'before': compact(before), 'after': compact(after)})
findings['bubble_turn2_actual_casts'] = bubbles
save('findings.json', findings)
selected = [decisions[n] for n in [269598, 269706, 269707, 269748, 269754, 269755, 269770, 270216, 270264, 270282]]
save('selected-decisions.json', selected)
save('audit-summary.json', {'streams': len(checks), 'raw_rows_verified': sum(x['verified_rows'] for x in checks), 'runs': len(records['runs']), 'same_sl_board': findings['sl_same_fingerprint'], 'different_mc_boards': findings['potion_budget_different_fingerprints'], 'bubble_casts_selected': len(bubbles)})
print(json.dumps(json.loads((HERE / 'audit-summary.json').read_text()), ensure_ascii=False))

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = '27e78f7a66078d981339eefde1ddf2ed2766a26f'
BATCH = '20261018-124303-strategy-proposal'
dispatch = json.loads((HERE / 'dispatch.json').read_text())
queue = json.loads((HERE / 'queue-snapshot.json').read_text())
by_id = {x['id']: x for x in queue}
time = (HERE / 'written-at.txt').read_text().strip()

details = [
    ('89354805ee4d7e77', '神化传播', 'VLZ6CCT8AQ0A F35T1、F43T1/T2、F45T1',
     's275564→275565及s275679→275680均付2能；d269706/269707同后续牌序的题面43伤/14损→51伤/13损。F45持有神化但未施放，不能预支升级。',
     'F35施放后发生重规划；F43虽施放仍损57；F45与前场起点/敌人不同，不能推出必打或胜负因果。',
     '普通神化及17种有限配对已有源码；未核实其余升级真值，突袭免费技能仍明确未覆盖，实际施放记录和全部后继消费也未闭环。已核配对没有发现本批新增的数值缺口，不能将部分覆盖登记整项完成。',
     '用已保存普通/升级原帧逐项校准手牌、确定抽牌及跨抽弃传播；未知附魔、费用和效果继续unknown；补实际施放消费者与剩余效果固定输入后再验。'),
    ('f2bfceddb1898dca', '药水预算与三骑士时钟', 'VLZ6CCT8AQ0A F45T1/T4/T5',
     'd269748的MC=707ms、1/12，rollout horizon1/samples1/best=null；d269754为11ms、12/12，rollout horizon5/samples3，但指纹不同。T4少损线13损/24伤、攻击候选31损/32伤。',
     '攻击候选未实打；两道不同盘面不能组成预算配对。全败推演不等于实盘确定死亡，药水名称不提供回血事实。',
     '缺同起点、同随机池、同总预算的MC先行/分阶段预算配对及样本成熟和候选稳定性曲线；另focus、留药的完整后继未观察。不能据不同题的1/12→12/12改预算、药价或目标顺序。',
     '冻结完整覆盖模型、输入和随机池，在相同总预算内配对两方案并保留所有候选；再用时间后移独立本角色完局校准，当前保留原预算和药水规则。'),
    ('283a164780d11e69', '神化经验来源链', 'VLZ6CCT8AQ0A F35T1、F43T1/T2、F45T1',
     '与89354805共享s275564/275565、s275679/275680及原经验silent-apotheosis-combat-upgrades，但来源任务是experience-update。',
     '同一来源局、四次施放及两个提案不增加独立支持局数；同主题也不证明宽请求已经实现。',
     '与原神化请求共享有限配对实现，但实际施放、剩余效果和完整后继消费未闭环；不能仅因提案重叠或经验已发布登记duplicate。',
     '保留独立经验链接；沿原神化请求验证，不新建重复代码提案，不把经验文字作为源码实现。'),
    ('ebbfe3b97548756d', '攻防机制与资源分账', 'VLZ6CCT8AQ0A F43T1—T5、F45T1—T5及F44休息',
     'F45T5 s275749—275756：32血，最终20挡，减力后攻击合59；完整需损39、差7，三敌仍存活。F43神化升级与属性、勒紧、触媒须分源；F45T3口红与步法是不同来源。',
     '临时减力随后恢复；持有毒雾不等于已建立群体毒。休息、覆甲、属性和毒的局部公式不能互相代替，也不能推出固定安全血线。',
     '原15个机制/资源子项尚未完成逐源生产调用的联合校准；当前只核实原帧与源码路径，没有新增的独立源误差证据，也没有另一focus或火房选择的完整反事实。不能用若干局部实现关闭整项。',
     '对各子项冻结当前进阶、能力、手牌、怪物数据和调用链，分列逐击/逐牌、临时期限、已结算毒和实际资源；需要新实现时逐项做撤源红/恢复绿，原房间五样本门槛保持。'),
    ('e5b87be50f28f311', 'SL与护栏执行归属', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、F17T6',
     'd270216与d270282指纹逐字相同；s276208→276212实际47→44、敌326→316，第三试s276274→276278为47→32、敌326→309，多12血只多7伤。d270264所在边界25→21、敌249→224。',
     '第三试同题候选死亡为0/24与5/24，不能说死率相同；省血替换另有少伤代价。原线没有完整赢局，前五试末轮部分结算被截断。',
     '候选比较、Jev/护栏/SL阶段与单动作回执已有局部源码，actual_turn/whole_plan仍明确unknown。原局未保存可完整连回所有候选续步的机器执行归属；抽牌、选择、药水、生成牌及SL中断后的全链固定验证未齐，不能关闭完整审计或改SL/护栏。',
     '先补齐各中断类型的冻结输入及稳定实体身份，关联候选、派发、实际状态，未知保持unknown；不得将已派发第一步标整线完成，也不从本局拟合新血价阈值。'),
    ('49632bc4878fb597', '当前属性、弱与成长', 'CA5KE8GFJ9X2 F13T1/T3/T5',
     's273237/273252/273263见敌力量0/4/8及喷水11/15/19；s273254弱后11，s273268弱后14。末态s273268为2血10挡，下一帧归零且敌16。',
     '弱没有取消下一次加压。覆甲9/9/8/7/6只是观察序列，未隔离完整减层条件；计划中的步法没有取得。',
     '该场不能同时提供力量、敏捷、弱和独立成长四路径的联合校准；蚌覆甲减层条件仍未隔离。已有步法或通用数值公式不足以证明整条复合经验全部完成，本批未核实新增源码缺陷。',
     '分别用已观察的当前属性和实际牌面检验每击/每牌数值，再冻结四路径生产调用；不新增统一保血或输出权重，不以未取得能力补数值。'),
    ('66532328a585941f', '持有、启动与兑现', '5PM6JAQG6FNQ F39末试T2、F33',
     'd268455及s274379→274380：向无毒失落打冒泡，能量5→4，双方HP/毒及敌挡均未变。本局F33与F39的已建立能力和资源条件不同。',
     'F33建立雾/触媒/群蛇后赢是另一场；不能单独证明更早启动能救F39，也不能把持有的雾当本战已经建立。',
     '缺同起始HP、构筑和抽序下不同启动/构筑顺序的完整胜负对照及可复现收益函数。空打证据支持条件分账，不能拟合启动阈值或新增固定权重。',
     '将库存、候选、实际施放和持续效果分列；固定当前无毒目标零效果事实，策略权重须另有同起点整战配对和独立后置验证。'),
    ('43a76a31ba7bdcfa', '族母吸取、负敏捷与毒', '61E2QS63Y9WU F17T5/T6/T7',
     's273503→273504后玩家力量2→0、敏捷0→−2，敌力0→2；s273505/273507两防御各增3挡。T6→T7敌67→34，毒17/16合33继续兑现。',
     '本局该场首试获胜，不是同抽多条SL线路的受控比较；负敏捷与毒成立不代表另一局的重打顺序可互用。',
     '缺相同起始HP、构筑及完整已知抽序下可救活的另一条完整SL线路；吸取、负敏捷和毒的分项事实不足以修改SL范围、阈值或换线偏好。',
     '冻结吸取前后、双防御与毒的分项事实；SL策略另按同局完整后继对照，按run_id计样本并保留当前规则。'),
    ('5264153a4a4b0e5c', '召唤、成长与目标窗口', '61E2QS63Y9WU F23T1—T5',
     's273577→273582召21血幻象；T3/T5两敌力量3/6。T4 s273593→273596玩家25→10，幻象14→2仍未退场，本体76→41，合47净扣。',
     'focus幻象的39伤/零损只是未实打候选；T4更高总伤仍保留攻击者，不能把伤害总额当退场或整战更优。',
     '已有局部召唤/成长模型，但A10召唤代际、航行及实体重新出现的完整冻结生产校准和另一目标顺序的完整后继仍缺，不能据单轮候选规定首杀。',
     '按实体和代际校准召唤/成长与目标窗口，保留全部合法目标；相同推演值并列，另线未经执行部分保持未知。'),
    ('bddfa690a84e03d0', '熟睡甲虫醒来与成长', 'DUZUBAJ3A8GP F30四次尝试T1—T6',
     '末试s274993/274998/275003睡3/2/1，s275007醒来无覆甲；T5力量2、T6力量4/攻击22，s275022为1血16挡，s275023归零。四次尝试仍属一个来源局。',
     '末试T4对首试同起点多扣3敌血同时多损2玩家血；四试全败既不证明固定攻击优先，也不能把最后截断1点实际失血当完整需损6。',
     '缺睡眠、醒来/眩晕接续和当前进阶成长的完整生产调用校准，以及同起点同抽另一顺序的完整获胜线路；四次失败不足以拟合全死排序的血价或固定杀序。',
     '分别校准自然睡眠递减、攻击唤醒、眩晕及成长，分开实际截断损血和完整需要损血；未观察的换线胜率保持unknown。'),
]

results = []
parts = [f'# 本批十项策略提案复核\n\n记录时间：{time}。角色silent，仅本批六个A10来源局；批次{BATCH}。\n',
         '本批没有research_request/implementation_request，根静默牌组专题绑定其他批次，故不承接专题。工作树初始干净；按要求merge main后Already up to date，HEAD保持'+BASE+'。只处理调度领取的十个原ID，不领取fix队列其他项、不新建重复ID。\n',
         '本次结论：十项均waiting。已存在的窄实现和本批原帧复核分别记录；没有新源码缺口得到足够证据及验证，未改变策略、知识、参数或任何角色行为。没有本批提交、合入、发布号或shipped。\n',
         '## 证据边界\n\n通过公共extract_evidence.py抽取六个来源局，八流6995条均逐offset/bytes/SHA/JSON/显式run身份读回原日志。states3432、decisions3306、sl-attempts29、run-config6、run-plans33、brain183、runs6、fight-plans0。各流独立截点，非跨流原子快照；states/decisions/brain各2条原坏行，不据此断言目标局缺帧。fight-plans只称2233957字节截点内选中0。源代码均为旧提交+dirty，未重建历史dirty源码与知识整树。SL尝试不扩独立局分母。\n']

for suffix, title, where, support, counter, reason, validation in details:
    ident = 'silent-proposal-' + suffix
    original = by_id[ident]['original']['record']
    ledgers = original['ledger']
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    parts.append(f'## {ident}：{title}\n\n来源：{original["source_task"]}；实现任务strategy-proposal；账本：'+', '.join(ledgers)+f'。原提案已按登记SHA核对并保存为[{ident}.md]({ident}.md)。\n\n证据：{where}。{support}\n\n反例/限制：{counter}\n\n旧行为与预期：保留当前策略；{validation}\n\n本批处置：waiting。{reason}\n\n拟合/验证：本批只复核原发现样本，不拟合数值、不把重复材料算盲测。上述固定输入须先完成对应生产消费者校准；新增源码时须撤源失败/恢复通过，再跑规定沙箱入口。未来独立完局按结束时间后移且按角色/进阶分层。\n\n预期影响与回退：本批仅补审计与链接，无行为收益声明、无生产代码可回退；后续实现保留原经验/日志，按实际源码commit回退。\n')

parts.append('## 当前源码对照与局部实现\n\n观测live为efd308ad4aa8ce78c590b8168edb2748163bb5fb。source-manifest.json保存16组base/live Git blob、SHA、必要原字节及live末改源码祖先核验；11叶同字节，card-model/explore/controller仅原署名注释差，rollout/rollout-live另有既有女王相关功能差。没有宣称整个工作树或旧dirty运行树等价。\n\n- 神化有限转换：ba23ca693151fa8c6f7fe035e640dc30f05ccd75；持有/候选/未知施放展示：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17。\n- HP护栏和SL候选分列：a8b1f8be153fe4f3a34146117546c2178f2e446b；Jev/SL阶段审计：05cd292c6f01bb31e406473d3a9843e659d62b93；单动作回执：bade647f9fe4c9103b40e2f26b26296692ad24b7。\n- 模拟成熟度与未建模召唤说明：9952a11811a6a73f12e0f86a8b6ec49db3cae18c。\n\n以上commit均经本批核实为所观测live祖先，仅证明相应子实现存在，不足以给十个宽请求登记implemented/duplicate。源码阅读未运行生产模拟或测试。\n')
parts.append('## 登记、测试与保留\n\n复用十个CLI原ID；不重新add、不改提案原文。账本只经根ledger.py update追加where.proposal/note，by=learner:strategy-proposal；不新增证据或support/repeat，不改claim/首证/prior/原状态/version/effect，尤其不回退既有shipped。proposal_results交原调度器消费，学习者不直接写专用队列状态。\n\n无源码修改，tsc/vitest/cases均null；未做撤源红/恢复绿，不冒报测试成功。未进入live锁、未合入、未分配版本、未写规则上线双通知。铁甲及其他角色保持原行为。未运行play、LLM、网络、依赖安装或游戏二进制。临时材料均在本批scratch，未改其他notes/paper文件。\n\n辅助读回脚本首轮将import根目录设错，ModuleNotFoundError退出1；原源码和audit-evidence.log保留，修正到learner目录后audit-evidence-v2.log为0，6995条同输入读回完成。这是材料脚本错误，不是生产代码红绿。其他只读失败（沙箱瞬时缺失邻树路径、两个不存在的源码探针）在read-only-probe-failures.json保留，不视为产品缺陷。未读取到本原生会话请求的模型/推理参数回执，故不自报已验证模型切换或普通档位。\n')
(HERE / 'proposal.md').write_text('\n'.join(parts))

report = f'''# 策略提案批次报告

记录时间：{time}。批次：{BATCH}；角色：silent；base：{BASE}。

本批逐项核查十个领取提案，全部waiting，无源码/知识/参数修改；fixes=[]，merged=null。具体证据、账本、反例、拟验证行为及缺数据逐项见[proposal.md](proposal.md)。报告不关闭原学习父要求，不宣称经验新增入库或大脑已经采用。

## 身份与范围

初始及常规合并main后HEAD同base，merge输出Already up to date。根learn.json对应本批task=strategy-proposal/character=silent/reason=proposal/worktree匹配，领取十个proposal_ids，无proposal_repair、research_request或implementation_request。根notes/strategy-research-silent.json绑定20261010-150327，与本批不符，按普通消费队列处理，没有读取其他专题。未派下级agent。

六个runs.jsonl原行均SILENT/A10，旧来源代码均带dirty：VLZ6CCT8AQ0A F45败、8JRE1C4H4Z2W F33败、CA5KE8GFJ9X2 F13败、5PM6JAQG6FNQ F39败、61E2QS63Y9WU F28败、DUZUBAJ3A8GP F30败。首试/SL分别保留，六局不能扩为多次尝试的独立支持。

## 取证与结论

公共入口抽取八流6995条：states3432、decisions3306、sl-attempts29、run-config6、run-plans33、brain183、runs6、fight-plans0。全部原offset/bytes/SHA/JSON/归局及输出SHA读回通过，见evidence-readback.json、audit-summary.json与两个原evidence-manifest.json。各源独立字节截点、三流各2原坏行、fight-plans截点零选中限制保留，不称跨流原子或原日志不存在。

神化F43固定后续牌序题面43伤/14损→51伤/13损；当前有限转换已在live，本批未发现新的已核升级数值。药水两问题面指纹不同，不能把1/12→12/12当预算受控收益。SL同指纹两次47血起点分别实际损3/15、扣敌10/17；0/24和5/24不是同死率。下水道蚌弱后仍成长、负敏捷下双防御共6挡、无毒目标空打冒泡付1能和甲虫醒来后成长均有原帧支持；这些分项事实不提供未选整战线路的胜负。

## 逐项处置

'''
for result in results:
    record = by_id[result['id']]['original']['record']
    report += f'- `{result["id"]}`：waiting。账本'+', '.join(record['ledger'])+'。'+result['reason']+'\n\n'
report += '''## 源码、登记与验证状态

source-manifest.json冻结16组base/observed-live源码：11同、3仅历史署名差、2有既有功能差；末改源码commit均为观测live祖先，未冒整树或历史dirty等价。只将具体子实现列入proposal.md，不用局部源码关闭宽提案。

根账本通过既有CLI只补本报告链接和处置说明，不改变原证据、claim、状态或版本；逐项结果由最终JSON交调度器。没有新代码提案ID或源码commit，不新增release、不标shipped，也不需要运维规则上线通知。没有新异议或反证需要替代旧结论；保留各原提案的反例和限制。

未修改源码，tsc=null、vitest=null、cases=null；未做撤源失败/恢复通过，不宣称生产消费者验证或收益通过。原始字节读回是证据检查，不是源码测试。辅助脚本首轮导入路径错误1和修正后0均留原日志；只读探针失败另存，未将它们当产品故障。

最终工作树/HEAD核验、账本CLI回执、扫描结果与材料SHA清单保存在本目录。全部过程材料、初稿和原提案副本保留，未提交或清理工作树。
'''
(HERE / 'report.md').write_text(report)

final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH,
         'base': BASE, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [],
         'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
         'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
         'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'final-report.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

ledgers = {}
for result in results:
    for ident in by_id[result['id']]['original']['record']['ledger']:
        ledgers.setdefault(ident, []).append(result['id'])
updates = [{'id': ident, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(HERE / 'proposal.md') + '#' + proposal for proposal in proposals]},
            'note': f'{BATCH}复核本批六个Silent A10旧局及当前源码；'+','.join(proposals)+'均waiting，逐项缺数据见'+str(HERE / 'report.md')+'。未新增独立证据/反例或support/repeat；不改原claim、首证、状态、version/effect，不登记shipped。'}
           for ident, proposals in sorted(ledgers.items())]
(HERE / 'ledger-updates.json').write_text(json.dumps(updates, ensure_ascii=False, indent=2) + '\n')
(HERE / 'read-only-probe-failures.json').write_text(json.dumps([
    {'stage': 'initial_protocol_read', 'exit': 1, 'detail': 'bubblewrap glob scan遇到并行邻树-s2/.aws和.codex路径不存在，后续同文件只读成功；未扩大权限'},
    {'stage': 'source_filename_probe', 'exit': 2, 'detail': 'reflex/enemy*.ts和sim/enemy*.ts不存在；改按rg --files实际路径定位'},
    {'stage': 'offline_interval_probe', 'exit': 2, 'detail': 'eval/observed-combat-intervals.ts不存在；未执行任何该模块或模拟'},
    {'stage': 'audit_import', 'exit': 1, 'detail': 'audit-evidence.log为ModuleNotFoundError；保留失败脚本txt，修正后v2同证据0'}
], ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposal_results': len(results), 'ledger_updates': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WT = ROOT / '.worktrees/codex-fix-silent-20261016-000021'
OUT = ROOT / 'learner/runs/20261016-000032-ad2e0495-b0c3-4fed-a9d4-bc110e2c3e0d-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-224306-62831b0f-88bb-488a-9019-2e7550472ddf-fix-batch'
audit = json.loads((OUT / 'audit.json').read_text())
skipped = json.loads((PRIOR / 'skipped.json').read_text())
for row in skipped:
    if row['item'].startswith('sandbox-glob-startup-race'):
        row['reason'] = ('证据不足：父注册保存屏障798af209b已是本次main及实际live祖先，三个叶与原源相同；'
                         '目录删除者、历史注册时序及其他租约拒绝原因仍未知。'
                         '保留既有核证链，不把历史ENOENT/null租约全部归因于该窄修复，不越租约重放。')
    elif row['item'].startswith('其余出牌'):
        row['reason'] = ('策略类：按任务要求沿各条原账本与独立strategy-proposal处理；'
                         '队列41条未勾选记录逐项见queue-dispositions.json，已实现窄范围不关闭宽父。')
assert (OUT / 'tsc.exit').read_text().strip() == '0'
assert (OUT / 'targeted.exit').read_text().strip() == '0'
log = (OUT / 'targeted.log').read_text()
files = int(re.search(r'Test Files\s+(\d+) passed', log).group(1))
cases = int(re.search(r'Tests\s+(\d+) passed', log).group(1))
assert files == 8 and cases == 68
status = subprocess.check_output(['git', '-C', str(WT), 'status', '--porcelain'])
assert not status
assert subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip() == audit['base']
assert hashlib.sha256((ROOT / 'notes/fix-queue-v4.md').read_bytes()).hexdigest() == audit['queue_sha256']
assert all(r['ancestor_in_base'] and r['ancestor_in_live'] for r in audit['existing_fixes'])
barrier = audit['registration_barrier']
assert barrier['ancestor_in_base'] and barrier['ancestor_in_live']
test_files = [
    'tests/learner-startup-recovery.test.ts', 'tests/learner-launch-failures.test.ts',
    'tests/learner-registration-barrier.test.ts', 'tests/ledger-publication-baseline.test.ts',
    'tests/silent-paper-krane.test.ts', 'tests/target-options.test.ts',
    'tests/feature-notice-registration.test.ts', 'tests/boss-sim-notice-registration.test.ts',
]
verification = dict(tsc_command='nice -n 19 npx tsc -p tsconfig.json --noEmit', tsc=0,
                    vitest_command='nice -n 19 npx vitest run --pool=threads --maxWorkers=1 ' + ' '.join(test_files),
                    vitest=0, files=files, cases=cases, retried=False,
                    full_sandbox_suite_run=False, reason='无代码变更、无新增提交，不重复整套检查。',
                    environment='TMPDIR为本任务scratch；PATH添加本地Node；npm离线；unset CHARACTER。',
                    without_fix_check='不适用：无新增修复；不把旧负对照结果算作本批结果。')
(OUT / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
result = dict(task='fix-batch', base=audit['base'], fixes=[], skipped=skipped, merged=None,
              tests=dict(tsc=0, vitest=0, cases=cases), code_proposals=[], implementation_domains=[],
              report=str(OUT / 'report.md'))
lines = ['## 修 bug 回报', '',
         f"- 合并基线：main → {audit['base']}（开工工作区干净；git merge --no-edit main 返回 Already up to date）。",
         '- 修复（每条一行）：无新增；74个既有修复来源均已在当前main/live祖先中。未改源码、测试、队列或账本，未提交；撤源码失败/恢复通过验证不适用。']
for row in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{row['item']} — 已修，提交 {row['source_commit']}（本批核当前源码及祖先关系，只认原限定范围）。")
lines.append(f"- 已被别人修掉的：{barrier['item']} — 已修，提交 {barrier['source_commit']}（本次已核main/live祖先，原三个叶与当前main/live均一致；原队列待合记录保留）。")
for row in skipped:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines += [
    '- 测试：tsc退出码0；Vitest定向8文件/68用例/退出码0，无重跑。固定输入；无真实LLM或网络调用。无代码变更或提交，未跑完整test-sandbox.sh，不声称完整套件通过；命令与范围见verification.json，原输出见tsc.log、targeted.log。',
    '- 合入：未合入（本批无新增源码，不空合、不新增发布号、不重复更新账本；只读核得live为' + audit['live_read_only_snapshot'] + '）。',
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '',
]
(OUT / 'report.md').write_text('\n'.join(lines))
(OUT / 'report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'skipped.json').write_text(json.dumps(skipped, ensure_ascii=False, indent=2) + '\n')
(OUT / 'final-status.txt').write_bytes(status)
manifest = {}
for file in sorted(OUT.iterdir()):
    if file.is_file() and file.name != 'artifact-manifest.json':
        data = file.read_bytes()
        manifest[file.name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
(OUT / 'artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(report=result['report'], existing_fixes=len(audit['existing_fixes']) + 1,
                      unchecked=audit['unchecked_entries'], tests=result['tests'], files=files,
                      source_diff_bytes=(OUT / 'source.diff').stat().st_size, worktree_clean=True), ensure_ascii=False, indent=2))

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WT = ROOT / '.worktrees/codex-fix-silent-20261016-000021'
OUT = ROOT / 'learner/runs/20261016-000032-ad2e0495-b0c3-4fed-a9d4-bc110e2c3e0d-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-224306-62831b0f-88bb-488a-9019-2e7550472ddf-fix-batch'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, head):
    return subprocess.run(['git', '-C', str(WT), 'merge-base', '--is-ancestor', commit, head]).returncode == 0


assert not git('status', '--porcelain')
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'refs/heads/live').decode().strip()
prior_bytes = (PRIOR / 'audit.json').read_bytes()
prior = json.loads(prior_bytes)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
prior_queue = (PRIOR / 'queue-snapshot.md').read_bytes()
assert queue == prior_queue, '队列有变化，必须逐项重新核读'
(OUT / 'queue-snapshot.md').write_bytes(queue)
dispositions = json.loads((PRIOR / 'queue-dispositions.json').read_bytes())
unchecked = [(n, line) for n, line in enumerate(queue.decode().splitlines(), 1) if line.startswith('- [ ]')]
assert [(d['line'], d['item']) for d in dispositions] == unchecked
existing = []
source_paths = set()
for old in prior['existing_fixes']:
    commit = old['source_commit']
    path = old['path']
    current = (WT / path).read_bytes()
    row = {k: old[k] for k in ('item', 'source_commit', 'path')}
    row.update(current_source_sha256=sha(current),
               same_as_prior=sha(current) == old['current_source_sha256'],
               same_as_committed_base=current == git('show', f'{base}:{path}'),
               ancestor_in_base=ancestor(commit, base), ancestor_in_live=ancestor(commit, live))
    source_paths.add(path)
    paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()
    leaves = []
    for leaf in paths:
        if not leaf.startswith(('agent/', 'learner/', 'ops/', 'eval/', 'knowledge/builders/')):
            continue
        if not leaf.endswith(('.ts', '.py', '.sh', '.json')) or leaf.startswith('knowledge/characters/'):
            continue
        if not (WT / leaf).is_file():
            continue
        data = (WT / leaf).read_bytes()
        source_paths.add(leaf)
        live_data = subprocess.run(['git', '-C', str(WT), 'show', f'{live}:{leaf}'], capture_output=True)
        leaves.append(dict(path=leaf, sha256=sha(data),
                           unchanged_since_prior_base=data == git('show', f"{prior['base']}:{leaf}"),
                           same_as_committed_base=data == git('show', f'{base}:{leaf}'),
                           same_as_live=live_data.returncode == 0 and live_data.stdout == data))
    row['source_leaves'] = leaves
    assert row['ancestor_in_base'] and row['same_as_committed_base']
    assert all(x['same_as_committed_base'] for x in leaves)
    existing.append(row)
barrier = '798af209b9a268b7dafab1440150f1b39cd5595d'
barrier_paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', barrier).decode().splitlines()
barrier_leaves = []
for path in barrier_paths:
    data = (WT / path).read_bytes()
    barrier_leaves.append(dict(path=path, sha256=sha(data), same_as_source=data == git('show', f'{barrier}:{path}')))
assert all(x['same_as_source'] for x in barrier_leaves)
changed = sorted({x['path'] for row in existing for x in row['source_leaves'] if not x['unchanged_since_prior_base']})
audit = dict(base=base, live_read_only_snapshot=live, prior_audit=str(PRIOR / 'audit.json'),
             prior_audit_sha256=sha(prior_bytes), queue_sha256=sha(queue),
             queue_lines=len(queue.decode().splitlines()), queue_unchanged_since_prior=True,
             unchecked_entries=len(unchecked), existing_fixes=existing,
             changed_source_paths_since_prior_base=changed,
             registration_barrier=dict(item='sandbox-glob-startup-race：父注册事务保存屏障',
                                       source_commit=barrier, ancestor_in_base=ancestor(barrier, base),
                                       ancestor_in_live=ancestor(barrier, live), files=barrier_leaves),
             limitations=['既有修复只确认原限定范围；不关闭宽父或自然消费者验收。',
                          '不把历史ENOENT/null租约或nonpositive-hp根因归于未证实原因。'])
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(OUT / 'queue-dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source.diff').write_bytes(git('diff', '--binary', 'HEAD'))
(OUT / 'changes-since-prior-base.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--', *sorted(source_paths)))
print(json.dumps(dict(base=base, live=live, existing=len(existing), unchecked=len(unchecked),
                      changed=changed, barrier=audit['registration_barrier'],
                      non_live=[x['item'] for x in existing if not x['ancestor_in_live']]), ensure_ascii=False, indent=2))

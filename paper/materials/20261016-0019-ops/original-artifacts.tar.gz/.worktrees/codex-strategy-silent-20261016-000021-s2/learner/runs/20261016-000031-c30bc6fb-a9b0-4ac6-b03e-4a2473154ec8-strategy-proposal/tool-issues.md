# 本批工具过程原件补记

以下只涉及材料/工具操作，未归为游戏产品缺陷，也未重写原始对局、旧报告或回执。

1. 首次派发表打印器以“父对象包含本批键”为命中条件，误将整个父派发表输出，发生截断；随后改为只打印本批值，并保存dispatch.json。首轮专用队列打印器只筛本批10 id，却打印了这些id的全部历史更新，亦发生截断；随后经既有fold函数折叠，仅保存/使用本批10项。不领取其他批次，不消费其他id。
2. 两条只读命令在shell启动前失败，原工具错误如下；后续分别重跑原内容成功，未通过该错误访问其他项目或申请扩权。

```text
error building bubblewrap command: Fatal error: ripgrep unreadable glob scan failed for /home/dw: rg: /home/dw/Projects/agent-hearthstone/.codex: No such file or directory (os error 2)

error building bubblewrap command: Fatal error: ripgrep unreadable glob scan failed for /home/dw: rg: /home/dw/Projects/agent-hearthstone/.aws: No such file or directory (os error 2)
rg: /home/dw/Projects/agent-hearthstone/.codex: No such file or directory (os error 2)
```

3. 首次原状态schema摘要器对combat=null调用list，退出1。原末尾：

```text
Traceback (most recent call last):
  File "<stdin>", line 9, in <module>
TypeError: 'NoneType' object is not iterable
```

之后只对有combat的帧读取schema，正式audit_evidence.py统一使用`or {}`处理空状态。已成功复制的原提案不受这一错误影响。

4. 一次定位调用包括不存在的agent/src/reflex/decide.ts，rg退出2；其余精确源码结果正常。最终只从实际存在的combat-plan.ts核SL消费者调用位置，不以缺文件推出产品缺陷。
5. 首次材料检查WQ第六试三饮用错中间行号：使用s282355/282356/282357得到手数10/10/10、小刀5/5/5，而s282353才是首瓶后的手数8、小刀3（s282354是重复帧）。原输出和脚本保留为audit-initial.stdout.txt、audit_evidence.py.initial.txt、material-checks.json.initial.txt、evidence-summary.json.initial.txt；未覆盖。修正到s282352/282353/282355/282357，再补其他边界，实际21项均通过。首轮脚本只列出失败不退出非零，故首轮进程exit0不等于断言全过；报告按实际8/10记载。

# 静默猎手策略提案消费报告

时间：2026-10-16T00:13:59+08:00。批次：20261016-000021-s2-strategy-proposal。角色：silent。

结论：10个原提案逐项复核后均保留waiting，没有新的充分证据支持策略源码变更。没有新增源码提交、生产测试、合入、release_id或shipped。现有狡诈、普通紧勒、开场4血和蟹朝向等窄实现均与尚未完成的联合资源/消费者校准分开；具体证据、反例、行为边界和重派所需数据见[proposal.md](proposal.md)。

## 身份与基线

- 完整base与当前HEAD：05d34cd019b03fd90098cdc27e622f8b1b3fac36。初始git status干净；git merge --no-edit main返回Already up to date。无纯研究冻结绑定，无实现请求，本批reason=proposal，10个proposal_ids与dispatch.json完全一致。
- 原提案10份均存在，原字节SHA与队列一致，见original-proposals-manifest.json；原文未改。根专题strategy-research-silent.json绑定另一旧批次，本批未转入该专题。
- 派发锚点：KEN58SH9SLZ6, TXZ6RVMQA09D, WQZVENQ7DTRP, 02HB4L0C3C67, 4D4J8USKCPAV, F4QKG4J1AJJZ, JLN5SK17W4FQ, LS8035TB32P3, NB8KCF6HRGVF, S9UZAK0JP0C0。
- 原提案补充局：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP（A10），K3676LU8B0UH（A1）、SADL3CGYTGSR（A7）。F4QKG4J1AJJZ为A9，其余派发锚点为A10。runs.jsonl身份见run-identities.json。
- 现有对局的code均带dirty；当前源码的祖先/叶校验不恢复当时未提交运行树。run-config-records.json保留原配置，未声称独立核过本学习会话的原生请求模型/强度，也未改会话配置。

## 原日志与材料复核

按指定共用learner/extract_evidence.py入口提取，八流各自先固定source_size，逐行保存offset/bytes/SHA和显式所属身份。随后对全部19,929行seek原日志、核字节SHA/JSON/身份，states角色也逐行核SILENT。源文件只读，未用正文提及判所属局。

| 流 | 本批选中行数 |
|---|---:|
| states | 9815 |
| decisions | 9448 |
| sl-attempts | 78 |
| run-config | 15 |
| run-plans | 77 |
| brain | 481 |
| runs | 15 |
| fight-plans | 0 |

冻结截点、各局计数和输出SHA见evidence/evidence-manifest.json，逐行原字节复核见raw-verification.json。源states/decisions各2条、brain1条全流不可解析行由入口报告并排除，无法给它们补造所属局；其他流无解析错误。fight-plans在该截点选中0行，仅指本次截点未选到，不断言原日志缺失。未复核任何旧截点，未覆盖旧批报告或零行初稿。

21项固定材料断言通过，范围为TXZ五次开场、WQ狡诈手位/刀数与SL局部净差、Q6紧勒分段、NHA损血/净扣/首次萎靡与蟹边界，见material-checks.json。它们是数据材料复核，**不是tsc/vitest或生产模型执行测试**。首次10项检查中8项通过、2项因我将WQ第六试首次饮药后帧错取为第二瓶后帧而未通过；纠正为s282353后新增其余边界合21项均通过。原脚本、失败检查和stdout/stderr均保存在*.initial.txt与audit-initial.*，不覆盖或伪装为产品失败。audit-corrected.*为修正后的实际结果。

关键原文/后继：key-state-windows.json、key-decisions.json、turn-windows.json、resource-state-windows.json、ken-potion-actions.json。KEN七次use_potion中四条completed、三条pending原回执保持；NHA生存者pending且弃牌后重规划的边界保持。净差、单动作回执、当前候选预测都不认证完整候选实际执行，完整候选认证仍未建立。

## 当前源码与实际live覆盖

只读live锚点cfa1c0be88147b4eac65c13d8c550b23ed4eef17。13个相关源码叶中10个逐字节相同，card-model.ts、sl/explore.ts、potion-cost.ts三叶仅历史Dai/Roy注释差；原差异不改。见source-audit-complete.json与live-source-differences.patch，完整工作树初始diff另存workspace-initial.patch。

| 子项 | 已核实际live祖先源码commit | 范围 |
|---|---|---|
| 狡诈生成/容量 | 6403fdcdadc803a092beb5165a068e22bf51c412 | 已证3/2/0及逐步手位，宽提案继续waiting |
| 普通紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 | 无挡普通分支，不外推自动/重放/升级 |
| 既有SL比较诊断 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 候选预测、实际完成未知，非整线认证 |
| 王室猛毒开场 | e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a | 已观测组合/新模拟战，现场及SL不重复扣 |
| 后续开场范围 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 | 原白名单加已证组合，不是本批新实现 |
| 蟹朝向窄修复 | ec29ea34b919344b707e57ba472ea210f9c39d62、f2c7cc1a7288893bceae0f0b20304a2b1fae5f57 | 当前进阶DB首样本及已观察分支 |
| 未知药价参考 | c4670f4f416c7d93e192e889c5080e7e4e0e733f | 未知不等已证0；未执行支线不当实盘 |

fc7042d1df0626e9e726f4bc912d9c6f626d908f不是该live锚点祖先；经验/版本/纯记录提交也不能替代源码实现证明。以上是旧子项覆盖检查，本批没有把任何宽项登记implemented/duplicate，更未报shipped。

## 逐项处置

- `silent-proposal-08eaa60bcc449852`：waiting；缺F15未饮用及同入口、同后继留药至Boss的完整成对结果；七次饮药选择和实际回血链不能校准持药价。
- `silent-proposal-92920295a648b540`：waiting；缺保持抽序、生成和药栏一致的两战完整替线；开场扣血实现不覆盖SL资源比较及连续通关校准。
- `silent-proposal-a327449c331efbc1`：waiting；缺攻防与沙坑双边界的完整受控后继、候选跨重规划执行绑定及独立胜局，不能拟定新SL血价门槛。
- `silent-proposal-a099e89437e942bb`：waiting；生成与容量已有窄实现；仍缺计划妥当保留、穿插出刀、整候选实际派发和SL恢复的联合校准。
- `silent-proposal-47910f82a1fdd98f`：waiting；开场4血子项已有实现；缺留药、路线及SL完整后继对照，以及未知回血/复活组合的结算顺序。
- `silent-proposal-f1374df72d8e6a25`：waiting；缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战，不能校准资源权重。
- `silent-proposal-38a49e6c97f31eea`：waiting；普通紧勒已有窄实现；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准。
- `silent-proposal-ef0e38a5dbd3bc07`：waiting；缺另一营火、事件、路线和用药时机的受控完整结果，不能由两条实际失败链拟合资源权重。
- `silent-proposal-7f820c02d39bfaea`：waiting；缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继；六次失败不足确定新SL阈值。
- `silent-proposal-04b6b430759815ed`：waiting；蟹朝向窄分支已有实现；缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及其他X值、升级组合和能力整战后继。

## 边界、账本与上线

不从已败局或未执行候选补写反事实，不拟新血价/药价/SL阈值，不使用其他角色知识。原105/109局历史全量及房间代价、未冻结dirty知识、完整抽序/生成、独立后移留出仍未验证；当前材料不能宣布量化父要求、经验入库或实际消费者收益完成。

只给31个相关既有账本经根learner/ledger.py update追加本批proposal/report追溯和具体waiting说明；不新增重复经验，不更改claim、evidence、first_run、prior、status、version，不将原shipped条目降级为proposed。CLI输入、输出、实际追加行与非追溯字段不变核验另存ledger-*。本批没有新提案需要add或新的CLI id。

没有生产源码/知识修改，因此撤源码失败/恢复通过、tsc、vitest和cases均未执行，JSON固定null；无提交所以不制造提交署名或测试绿。merge=live的实现上线步骤不适用于本次无源码结果，没有空合、版本或Roy规则变更双通知。report/proposal路径交调用方运维按原完成事件接续，父要求保持开放。

工具过程：首次派发表打印器误输出父级元数据而截断，已改成只输出本批；只处理本批10 id，未改任何派发状态。两条只读命令在shell启动前遇bubblewrap/ripgrep ENOENT，随后同内容重试通过；只记录工具原文提及路径，未访问其项目。首次摘要器对combat=null调用list报TypeError，已按实际schema处理，未将它归为产品bug。错误与初稿保留在tool-issues.md，原工具输出也保留于会话。

最终源码/工作树检查、记录追加与脱敏扫描见completion-checks.json。最终机器回报见final.json。

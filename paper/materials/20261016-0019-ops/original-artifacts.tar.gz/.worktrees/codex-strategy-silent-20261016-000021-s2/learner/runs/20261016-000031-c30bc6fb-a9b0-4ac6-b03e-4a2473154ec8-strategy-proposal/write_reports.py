import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
BATCH = '20261016-000021-s2-strategy-proposal'
dispatch = json.loads((HERE / 'dispatch.json').read_text())
proposals = json.loads((HERE / 'selected-proposals.json').read_text())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
timestamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()

details = [
    {
        'suffix': '08eaa60bcc449852',
        'evidence': 'KEN58SH9SLZ6 A10：F3T2、F4T1、F5T2、F11T1/T2、F15T1七次饮药选择。d274131/274237/274272原回执是pending，另四次completed，不改写回执；实际库存/选择后继与生产整候选完成分开。F5 s280255→280285为53→16；F12 s280336→280338为26/76→53/81；F16 s280382→280384为46/81→75/86；F15 s280347→280381为46→46。',
        'covered': '未知留药价值的题面参考已在live源码c4670f4f416c7d93e192e889c5080e7e4e0e733f；明确区分本轮不喝、抽样整战无药与未执行支线。它不提供F15未饮用或留到Boss的实盘结果。',
        'counterexample': 'F15零损同时耗药，不能外推不喝也零损；F5获胜仍损37。SL恢复不计真实回血。',
        'reason': '缺F15未饮用及同入口、同后继留药至Boss的完整成对结果；七次饮药选择和实际回血链不能校准持药价。',
        'expected': '保留现持药价；未来将未饮/早饮/留药的退出HP、药栏与下一战入口分账展示。',
        'validation': '冻结同起点牌序与药栏，分开药水产生的选择/抽牌重规划与实际消耗；较早独立局拟合，后移新局验证，不能把本局六次Boss尝试拆成独立样本。',
    },
    {
        'suffix': '92920295a648b540',
        'evidence': 'TXZ6RVMQA09D A10 F48T6：第二/三试48HP、敌460HP，原线当轮损3/扣36，换线损0/扣27；d275383—275385保留原答、替换与三个动作回执。F48T10退出4HP，s281563/281564奖励/地图仍4；F49T1 s281565→281566为4→0、出牌0、敌111未掉血。',
        'covered': '下一战开场失血已有e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a及后续范围扩展ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8。既有连战接续保留实际HP/药水，但不能替代本提案的三尝试联合校准。',
        'counterexample': '少损3也少打9，后继抽牌/生成已变；赢首Boss不等于连续通关。低可信模拟0%不证明必死或某替线更好。',
        'reason': '缺保持抽序、生成和药栏一致的两战完整替线；开场扣血实现不覆盖SL资源比较及连续通关校准。',
        'expected': '保留现SL资格和终局规则；候选比较同时报告首战结果、退出资源及第二战可操作前资源。',
        'validation': '本局三尝试作为一个发现案例，固定36/3与27/0及4→0边界；需另一受控完整后继或后移独立局才能修改资源权重。',
    },
    {
        'suffix': 'a327449c331efbc1',
        'evidence': 'WQZVENQ7DTRP A10 F33第2/3试T9：d275894/275960指纹相同；s282075/282144均26HP、敌184。到s282079/282148分别13HP/敌160与4HP/敌145，即13损/24伤与22损/39伤。末试T7 d276139、s282330—282336保留0→4血价与沙坑延长反例。',
        'covered': '66283dd9982bdd7f480da7a4d9bfefea0572a9ac内SL资源与候选比较已有预测、敌后态、沙坑、原答/替线和实际未知标识；actual_turn_result=null或execution=unverified。不能按completed的一个动作认证整个候选。',
        'counterexample': '付4血能延长沙坑一轮，因此不能一律保血或禁逃离。六次失败没有独立实胜反事实。',
        'reason': '缺攻防与沙坑双边界的完整受控后继、候选跨重规划执行绑定及独立胜局，不能拟定新SL血价门槛。',
        'expected': '保留现探索规则；继续展示当轮HP、已结毒、剩余毒、沙坑与未知抽序，推演相同选项保留并列。',
        'validation': '同时复现9血换15伤及4血换一沙坑轮，保存实际结算与完整后继；同一局六次SL同组，未来独立A10局作时间留出。',
    },
    {
        'suffix': 'a099e89437e942bb',
        'evidence': 'WQZVENQ7DTRP A10 F33第5试T11 s282292/282294/282295/282296手数8/10/10/10、小刀0/2/2/2；第6试s282352/282353/282355/282357手数5/8/10/10、小刀0/3/5/5。保留s282353与282354的重复状态，不以重复帧新增一次饮用。九局原来源的A7/A9/A10范围按各自身份区分。',
        'covered': '6403fdcdadc803a092beb5165a068e22bf51c412已在live实现升级小刀基础6、现场力/弱、逐步手位、锁定牌占位及剩刀传递。普通生成子项已有，未新报本批implemented。',
        'counterexample': '容量不足仅本局直接边界；连续满手饮用仍耗瓶。没有先出刀腾位再喝的完整实打胜线，不能宣称可救本局。',
        'reason': '生成与容量已有窄实现；仍缺计划妥当保留、穿插出刀、整候选实际派发和SL恢复的联合校准。',
        'expected': '保留已实现公式及所有合法饮用选项，未知组合保持原处理；不设统一饮用/持有阈值。',
        'validation': '既有3/2/0与满手耗瓶帧作固定边界；新增保留→出刀→饮药→重规划→SL恢复的完整消费者输入和后继，按run划分验证。',
    },
    {
        'suffix': '47910f82a1fdd98f',
        'evidence': 'TXZ6RVMQA09D A10 F43/F45/F46/F48/F49首动作前s281312→313、338→339、367→368、399→400、565→566分别70→66、52→48、62→58、60→56、4→0；均出牌0。另用WQ第2/3试T9与末T7双边界，不把SL恢复当开场重新扣费。',
        'covered': 'e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a的开场4血及ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8的已观测组合扩展均为实际live祖先；源码仅新模拟战扣费，现场T1和存档恢复不重复扣。原fc7042d1df0626e9e726f4bc912d9c6f626d908f不是本次live祖先，不能用它登记实现。',
        'counterexample': '有回血/复活等未知组合时不能外推单件及内部先后；一项开场修正不能关闭路线、留药和SL全链要求。',
        'reason': '开场4血子项已有实现；缺留药、路线及SL完整后继对照，以及未知回血/复活组合的结算顺序。',
        'expected': '保留现开场白名单及实际资源接续；不预支未来营火/未触发能力，不放宽必死规则。',
        'validation': '固定五个开场边界已核；需同后抽完整续战和未知组合逐时点帧，血价/沙坑/毒/能力分源校准后才扩范围。',
    },
    {
        'suffix': 'f1374df72d8e6a25',
        'evidence': '1913SE84AXQF A10 F17退出14，F18入口58；F29 s282723→282750为61→46，F31 s282755以46入场后死亡。Q6M2Y34MWKRE A10 F7 s282869→282871为36→57；F8 s282872→282912为57→2；F9 s282913以2入场，s282921死亡。F2早喝敏捷线仅未执行候选。',
        'covered': '持续/临时敏捷、再生以及未知持药价值参考已有局部接线；普通紧勒窄修复5c7105ff0294466da8319f2934beda05c6040794是live祖先。机制修正和题面诊断不等于资源权重已校准。',
        'counterexample': 'Q6的药最终喝掉且有实休，不是丢药/拒绝回血；F5/F6赢零损留药不能证明全局早喝。原机制误差与估值误差须隔离。',
        'reason': '缺隔离机制误差后的同入口、同预算未用/早用/留药成对整战，不能校准资源权重。',
        'expected': '保留当前价值规则；分开持续药与当轮临时药、胜战退出HP与下一节点需求。',
        'validation': '按相同构筑/抽序/药栏完整回放，固定下一战入口46和2；先隔离紧勒等模型误差，再用后移独立局验证资源参数。',
    },
    {
        'suffix': '38a49e6c97f31eea',
        'evidence': 'Q6M2Y34MWKRE A10 F8T4 s282887—282892：敌103→95→85→83→80，紧勒本体8、后续一拳8+2、生存者完成弃牌再2、毒3分源；下一轮层消失。1913SE84AXQF F17为58→14净损44，再生实回15与敌HP伤59分开；F31T2弃磨蚀与T3/T4反伤窗口保留在resource-state-windows。',
        'covered': '5c7105ff0294466da8319f2934beda05c6040794已实现普通无挡紧勒，未知升级/自动/重放/叠层分支保留未知；regen5与逐轮衰减、临敏期限也有模型。原提案含十项经验及增益分源，不能用紧勒子项关闭全项。',
        'counterexample': '技能弃牌与重规划使首条派发不能代表整序列；反杀不能免去已发动攻击，千足虫复活不能把旧毒沿用。整战失败不是局部公式反例。',
        'reason': '普通紧勒已有窄实现；缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准。',
        'expected': '保留已证局部公式及未证分支限制；不调整SL、药价或击杀顺序阈值。',
        'validation': '冻结逐次伤害和弃牌完成时点，联合核临时/常驻敏捷、再生封顶、复活重置、反伤截断与完整消费者执行；不借原109局汇总充当本批复算分母。',
    },
    {
        'suffix': 'ef0e38a5dbd3bc07',
        'evidence': '1913SE84AXQF A10 F24 s282706→282709为40→40（锻造），F28 s282720→282722为40→61，F29胜后46、F31以46入；Q6M2Y34MWKRE F7实回21仍F8仅剩2、F9死。未抵达的F32未来火不能算已到账。',
        'covered': '当前事实与计划资源、未触发能力分别展示的部分功能存在；没有另一营火/事件/整条路线的受控实打结果。',
        'counterexample': '1913原路线预测条件在F24从回血变锻造，不能把差额都归为同条件预测bug；Q6已休息而非拒绝回血。',
        'reason': '缺另一营火、事件、路线和用药时机的受控完整结果，不能由两条实际失败链拟合资源权重。',
        'expected': '保留现路线/休息及价值行为，继续只结转实际完成资源；死亡前未触发能力不补记。',
        'validation': '固定休息/锻造/事件/幕间/再生/SL不同来源，比较同条件完整后继；按独立局与开始时间切分，未重算原109局375火等历史全量。',
    },
    {
        'suffix': '7f820c02d39bfaea',
        'evidence': 'NHA2KW0RB7VP A10 F33T1：s283391→283397原线30→29、敌合408→400；第5试s283478→283483及第6试s283502→283507均30→23、敌408→384，即多损6/多净扣16。末段两侧均活。d277248/277272的生存者原回执pending；d277250/277274为弃牌重规划后的覆盖/重放，不能说初始精确切击已完整执行。',
        'covered': '66283dd9982bdd7f480da7a4d9bfefea0572a9ac已有原答/替换当轮预测与执行未知日志；不提供跨弃牌持久候选完成身份或完整胜负对照。',
        'counterexample': '首轮净扣8/24包括下一轮抱抱先生自动伤4，不把净差全归卡牌。初题15损与最终6损是不同阶段，不能混用。六次均失败。',
        'reason': '缺同预算饱和排序校准、跨弃牌整候选执行归属及成对完整后继；六次失败不足确定新SL阈值。',
        'expected': '保留现探索资格与排序；同时列血价、两侧敌HP、击杀、存活推进和未知，预测相同保留并列。',
        'validation': '固定两次重规划后的完整观测净差，剥离自动伤，保存原答/首步/后继；同预算完整对照和后移新局到位后才考虑筛选门槛。',
    },
    {
        'suffix': '04b6b430759815ed',
        'evidence': 'NHA2KW0RB7VP A10 F33T1 s283395/283506首普通X1萎靡均建−2力/2弱；F17首次5毒实际10。F33T2 s283398—283400首试15挡损7、第二试s283418—283422损6；同增益转向的爪1→2与火箭30→20分账。K3676LU8B0UH A1 F30及SADL3CGYTGSR A7 F45只作原提案的补充身份与各自进阶材料，不外推为A10新样本。',
        'covered': '实际live源码ec29ea34b919344b707e57ba472ea210f9c39d62及f2c7cc1a7288893bceae0f0b20304a2b1fae5f57已覆盖蟹窄朝向分支，当前从本进阶数据库首样本取基伤，并限制已观测力量/招式。油灯原遗物快照只有描述、stack=null、is_melted=false，没有首负面消费位；经验/发号提交不是油灯源码实现。',
        'counterexample': '不能把显示1再乘1.5取整当2，也不能只因持有油灯让每次重规划都重复翻倍。蟹T4才建雾且无T5，不预支后续毒。',
        'reason': '蟹朝向窄分支已有实现；缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，以及其他X值、升级组合和能力整战后继。',
        'expected': '保留已实现朝向公式及范围；未知油灯条件不加通用放大规则，不以持有/计划当能力兑现。',
        'validation': '需首负面消费身份的实际生产传递与恢复轨迹，分别冻结X值、升级、目标与制品；各子公式和消费者联合回放，不能用元数据提交登记duplicate。',
    },
]

assert [p['id'].split('silent-proposal-')[1] for p in proposals] == [d['suffix'] for d in details]
for proposal, detail in zip(proposals, details):
    detail.update({k: proposal[k] for k in ['id', 'ledger', 'runs', 'source_task', 'domains', 'proposal', 'proposal_sha256']})
    detail['state'] = 'waiting'
(HERE / 'dispositions.json').write_text(json.dumps(details, ensure_ascii=False, indent=2) + '\n')

proposal_text = f'''# 静默猎手本批十项提案复核

时间：{timestamp}。批次：{BATCH}。基线：{base}。

本批是已领取提案的普通消费任务，没有research_request或implementation_request；不承接其他专题、不领取其他id。初始工作树干净，按要求merge main返回Already up to date。所有新增材料均在本批scratch，原提案原字节与SHA另存original-proposals/及manifest。

只用本角色证据。10派发锚点及原提案引用的5个补充局均在runs.jsonl核为SILENT（A1/A7/A9/A10分别保留）；不混进阶。原105/109局及其历史统计仅作为原提案内容保留，本批没有重新全量验证，不将15局冒作历史全分母或独立量化学习完成。

以下每项均保留waiting；已有子公式不等于整个提案已有实现。本批没有新经验/新参数/源码实现，不新建重复代码提案id，不把旧源码或元数据提交冒称本批上线。
'''
for n, detail in enumerate(details, 1):
    proposal_text += f'''
## {n}. {detail['id']}

- 原提案：{detail['proposal']}（SHA256 {detail['proposal_sha256']}）。来源：{detail['source_task']}；实现任务：本批strategy-proposal。
- 既有账本：{', '.join(detail['ledger'])}。
- 证据与位置：{detail['evidence']}
- 旧规则及现有覆盖：{detail['covered']}
- 反例与未知：{detail['counterexample']}
- 处置：waiting。{detail['reason']}
- 预期行为：{detail['expected']}
- 验证及样本切分：{detail['validation']}
- 预期影响与回退：本批保留原行为，未证胜率收益。未来若证据充分，仅单独实现已观测分支，撤回对应源码提交并保留原失败、提案、数据及并行记录；其他角色和未观察进阶保持等价，按原自测/live/双通知流程执行。
'''
(HERE / 'proposal.md').write_text(proposal_text)

results = [{'id': d['id'], 'state': 'waiting', 'reason': d['reason']} for d in details]
final = {'task':'strategy-proposal', 'character':'silent', 'batch':BATCH, 'base':base,
         'runs':dispatch['runs'], 'fixes':[],
         'skipped':['10项原提案均因具体数据/联合验证缺口保留waiting，逐项见proposal_results及proposal.md'],
         'merged':None, 'tests':{'tsc':None,'vitest':None,'cases':None},
         'code_proposals':dispatch['proposal_ids'], 'implementation_domains':[],
         'proposal_results':results, 'report':str(HERE / 'report.md')}
(HERE / 'final.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')

report = f'''# 静默猎手策略提案消费报告

时间：{timestamp}。批次：{BATCH}。角色：silent。

结论：10个原提案逐项复核后均保留waiting，没有新的充分证据支持策略源码变更。没有新增源码提交、生产测试、合入、release_id或shipped。现有狡诈、普通紧勒、开场4血和蟹朝向等窄实现均与尚未完成的联合资源/消费者校准分开；具体证据、反例、行为边界和重派所需数据见[proposal.md](proposal.md)。

## 身份与基线

- 完整base与当前HEAD：{base}。初始git status干净；git merge --no-edit main返回Already up to date。无纯研究冻结绑定，无实现请求，本批reason=proposal，10个proposal_ids与dispatch.json完全一致。
- 原提案10份均存在，原字节SHA与队列一致，见original-proposals-manifest.json；原文未改。根专题strategy-research-silent.json绑定另一旧批次，本批未转入该专题。
- 派发锚点：{', '.join(dispatch['runs'])}。
- 原提案补充局：1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP（A10），K3676LU8B0UH（A1）、SADL3CGYTGSR（A7）。F4QKG4J1AJJZ为A9，其余派发锚点为A10。runs.jsonl身份见run-identities.json。
- 现有对局的code均带dirty；当前源码的祖先/叶校验不恢复当时未提交运行树。run-config-records.json保留原配置，未声称独立核过本学习会话的原生请求模型/强度，也未改会话配置。

## 原日志与材料复核

按指定共用learner/extract_evidence.py入口提取，八流各自先固定source_size，逐行保存offset/bytes/SHA和显式所属身份。随后对全部19,929行seek原日志、核字节SHA/JSON/身份，states角色也逐行核SILENT。源文件只读，未用正文提及判所属局。

| 流 | 本批选中行数 |
|---|---:|
| states | 9815 |
| decisions | 9448 |
| sl-attempts | 78 |
| run-config | 15 |
| run-plans | 77 |
| brain | 481 |
| runs | 15 |
| fight-plans | 0 |

冻结截点、各局计数和输出SHA见evidence/evidence-manifest.json，逐行原字节复核见raw-verification.json。源states/decisions各2条、brain1条全流不可解析行由入口报告并排除，无法给它们补造所属局；其他流无解析错误。fight-plans在该截点选中0行，仅指本次截点未选到，不断言原日志缺失。未复核任何旧截点，未覆盖旧批报告或零行初稿。

21项固定材料断言通过，范围为TXZ五次开场、WQ狡诈手位/刀数与SL局部净差、Q6紧勒分段、NHA损血/净扣/首次萎靡与蟹边界，见material-checks.json。它们是数据材料复核，**不是tsc/vitest或生产模型执行测试**。首次10项检查中8项通过、2项因我将WQ第六试首次饮药后帧错取为第二瓶后帧而未通过；纠正为s282353后新增其余边界合21项均通过。原脚本、失败检查和stdout/stderr均保存在*.initial.txt与audit-initial.*，不覆盖或伪装为产品失败。audit-corrected.*为修正后的实际结果。

关键原文/后继：key-state-windows.json、key-decisions.json、turn-windows.json、resource-state-windows.json、ken-potion-actions.json。KEN七次use_potion中四条completed、三条pending原回执保持；NHA生存者pending且弃牌后重规划的边界保持。净差、单动作回执、当前候选预测都不认证完整候选实际执行，完整候选认证仍未建立。

## 当前源码与实际live覆盖

只读live锚点cfa1c0be88147b4eac65c13d8c550b23ed4eef17。13个相关源码叶中10个逐字节相同，card-model.ts、sl/explore.ts、potion-cost.ts三叶仅历史Dai/Roy注释差；原差异不改。见source-audit-complete.json与live-source-differences.patch，完整工作树初始diff另存workspace-initial.patch。

| 子项 | 已核实际live祖先源码commit | 范围 |
|---|---|---|
| 狡诈生成/容量 | 6403fdcdadc803a092beb5165a068e22bf51c412 | 已证3/2/0及逐步手位，宽提案继续waiting |
| 普通紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 | 无挡普通分支，不外推自动/重放/升级 |
| 既有SL比较诊断 | 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 候选预测、实际完成未知，非整线认证 |
| 王室猛毒开场 | e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a | 已观测组合/新模拟战，现场及SL不重复扣 |
| 后续开场范围 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 | 原白名单加已证组合，不是本批新实现 |
| 蟹朝向窄修复 | ec29ea34b919344b707e57ba472ea210f9c39d62、f2c7cc1a7288893bceae0f0b20304a2b1fae5f57 | 当前进阶DB首样本及已观察分支 |
| 未知药价参考 | c4670f4f416c7d93e192e889c5080e7e4e0e733f | 未知不等已证0；未执行支线不当实盘 |

fc7042d1df0626e9e726f4bc912d9c6f626d908f不是该live锚点祖先；经验/版本/纯记录提交也不能替代源码实现证明。以上是旧子项覆盖检查，本批没有把任何宽项登记implemented/duplicate，更未报shipped。

## 逐项处置

'''
for result in results:
    report += f"- `{result['id']}`：waiting；{result['reason']}\n"
report += '''
## 边界、账本与上线

不从已败局或未执行候选补写反事实，不拟新血价/药价/SL阈值，不使用其他角色知识。原105/109局历史全量及房间代价、未冻结dirty知识、完整抽序/生成、独立后移留出仍未验证；当前材料不能宣布量化父要求、经验入库或实际消费者收益完成。

只给31个相关既有账本经根learner/ledger.py update追加本批proposal/report追溯和具体waiting说明；不新增重复经验，不更改claim、evidence、first_run、prior、status、version，不将原shipped条目降级为proposed。CLI输入、输出、实际追加行与非追溯字段不变核验另存ledger-*。本批没有新提案需要add或新的CLI id。

没有生产源码/知识修改，因此撤源码失败/恢复通过、tsc、vitest和cases均未执行，JSON固定null；无提交所以不制造提交署名或测试绿。merge=live的实现上线步骤不适用于本次无源码结果，没有空合、版本或Roy规则变更双通知。report/proposal路径交调用方运维按原完成事件接续，父要求保持开放。

工具过程：首次派发表打印器误输出父级元数据而截断，已改成只输出本批；只处理本批10 id，未改任何派发状态。两条只读命令在shell启动前遇bubblewrap/ripgrep ENOENT，随后同内容重试通过；只记录工具原文提及路径，未访问其项目。首次摘要器对combat=null调用list报TypeError，已按实际schema处理，未将它归为产品bug。错误与初稿保留在tool-issues.md，原工具输出也保留于会话。

最终源码/工作树检查、记录追加与脱敏扫描见completion-checks.json。最终机器回报见final.json。
'''
(HERE / 'report.md').write_text(report)

updates = []
ledger_ids = sorted({ident for p in proposals for ident in p['ledger']})
for ident in ledger_ids:
    linked = [d for d in details if ident in d['ledger']]
    updates.append({'id':ident, 'by':'learner:strategy-proposal',
                    'where':{'proposal':[str(HERE / 'proposal.md'),str(HERE / 'report.md')]},
                    'note':BATCH + '：原提案复核；' + '；'.join(d['id']+' waiting：'+d['reason'] for d in linked)
                           + '。无源码/合入/版本；仅追加追溯，不更改既有claim/证据/首证/prior/status/version。'})
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
print(json.dumps({'base':base,'proposals':len(details),'ledger_updates':len(updates),
                  'report':str(HERE / 'report.md')},ensure_ascii=False))

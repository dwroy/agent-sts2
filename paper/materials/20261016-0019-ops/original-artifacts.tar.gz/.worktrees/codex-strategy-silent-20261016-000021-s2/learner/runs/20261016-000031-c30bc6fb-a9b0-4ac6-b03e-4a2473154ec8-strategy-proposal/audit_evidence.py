import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE / 'evidence'


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(items):
    return {p['power_id']: p.get('amount') for p in items or []}


def state_summary(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    hand = combat.get('hand') or []
    return {
        'line': item['line'], 'ts': item['row']['ts'], 'run': item['run_id'],
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'energy': player.get('energy'), 'block': player.get('block'),
        'played': player.get('cards_played_this_turn'),
        'player_powers': powers(player.get('powers')),
        'hand_count': len(hand), 'shivs': sum(c.get('card_id') == 'SHIV' for c in hand),
        'hand': [{'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                  'variables': c.get('dynamic_values')} for c in hand],
        'potions': [{'slot': p.get('index'), 'id': p.get('potion_id')}
                    for p in run.get('potions') or [] if p.get('occupied')],
        'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'),
                     'hp': e.get('current_hp'), 'block': e.get('block'),
                     'move': e.get('move_id'), 'powers': powers(e.get('powers')),
                     'intents': e.get('intents')}
                    for e in combat.get('enemies') or []],
    }


def main():
    import importlib.util
    spec = importlib.util.spec_from_file_location('extract', HERE.parents[1] / 'extract_evidence.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
    identities = {x['run_id']: x for x in json.loads((HERE / 'run-identities.json').read_text())}
    assert len(identities) == 15 and all(x['character'] == 'SILENT' for x in identities.values())
    verified = []
    states = {}
    decisions = []
    sl_rows = []
    configs = []
    for stream in manifest:
        path = EVIDENCE / (stream['stream'] + '.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
        counts = Counter()
        with path.open() as handle, Path('/home/dw/Projects/agent-sts2/logs', stream['stream'] + '.jsonl').open('rb') as raw:
            for line in handle:
                item = json.loads(line)
                raw.seek(item['offset'])
                original = raw.read(item['bytes'])
                assert hashlib.sha256(original).hexdigest() == item['sha256']
                assert json.loads(original) == item['row']
                assert module.run_identity(item['row']) == item['run_id'] in identities
                counts[item['run_id']] += 1
                if stream['stream'] == 'states':
                    assert item['row']['state']['run']['character_id'] == 'SILENT'
                    states[item['line']] = state_summary(item)
                elif stream['stream'] == 'decisions':
                    decisions.append(item)
                elif stream['stream'] == 'sl-attempts':
                    sl_rows.append(item)
                elif stream['stream'] == 'run-config':
                    configs.append(item)
        assert all(counts[run] == count for run, count in stream['counts'].items())
        verified.append({'stream': stream['stream'], 'source_size': stream['source_size'],
                         'rows': sum(counts.values()), 'counts': dict(counts),
                         'raw_offset_bytes_sha_identity': True})
    save('raw-verification.json', {'streams': verified, 'rows': sum(s['rows'] for s in verified)})
    wanted = set(range(281312, 281314)) | set(range(281338, 281340)) | set(range(281367, 281369))
    wanted |= set(range(281399, 281402)) | set(range(281560, 281568))
    wanted |= set(range(282075, 282085)) | set(range(282144, 282154)) | set(range(282330, 282337))
    wanted |= set(range(282292, 282297)) | set(range(282352, 282358)) | set(range(282887, 282894))
    wanted |= set(range(283391, 283401)) | set(range(283418, 283423))
    wanted |= set(range(283478, 283484)) | set(range(283502, 283508)) | set(range(283146, 283148))
    selected = {str(n): states[n] for n in sorted(wanted) if n in states}
    save('key-state-windows.json', selected)
    checks = []

    def check(name, actual, expected):
        checks.append({'name': name, 'actual': actual, 'expected': expected, 'ok': actual == expected})

    for before, after, hp in [(281312, 281313, 70), (281338, 281339, 52), (281367, 281368, 62), (281399, 281400, 60), (281565, 281566, 4)]:
        a, b = states[before], states[after]
        check('TXZ开场失血_' + str(before), [a['hp'], b['hp'], b['played']], [hp, hp - 4, 0])
    check('WQ第五试三饮手数', [states[n]['hand_count'] for n in [282292, 282294, 282295, 282296]], [8, 10, 10, 10])
    check('WQ第五试三饮小刀', [states[n]['shivs'] for n in [282292, 282294, 282295, 282296]], [0, 2, 2, 2])
    check('WQ第六试三饮手数', [states[n]['hand_count'] for n in [282352, 282353, 282355, 282357]], [5, 8, 10, 10])
    check('WQ第六试三饮小刀', [states[n]['shivs'] for n in [282352, 282353, 282355, 282357]], [0, 3, 5, 5])
    check('Q6紧勒后续含弃牌净扣', [sum(e['hp'] for e in states[n]['enemies']) for n in [282887, 282888, 282889, 282891, 282892]], [103, 95, 85, 83, 80])
    check('WQ同盘两线起点', [[states[n]['hp'], states[n]['enemies'][0]['hp']] for n in [282075,282144]], [[26,184],[26,184]])
    check('WQ原线当轮净差', [states[282075]['hp']-states[282079]['hp'], states[282075]['enemies'][0]['hp']-states[282079]['enemies'][0]['hp']], [13,24])
    check('WQ换线当轮净差', [states[282144]['hp']-states[282148]['hp'], states[282144]['enemies'][0]['hp']-states[282148]['enemies'][0]['hp']], [22,39])
    check('NHA原线当轮净差', [states[283391]['hp']-states[283397]['hp'], sum(e['hp'] for e in states[283391]['enemies'])-sum(e['hp'] for e in states[283397]['enemies'])], [1,8])
    for start, end in [(283478,283483),(283502,283507)]:
        check('NHA替线当轮净差_' + str(start), [states[start]['hp']-states[end]['hp'],sum(e['hp'] for e in states[start]['enemies'])-sum(e['hp'] for e in states[end]['enemies'])], [7,24])
    for n in [283395,283506]:
        check('NHA油灯首萎靡_' + str(n), [states[n]['enemies'][0]['powers'].get('STRENGTH_POWER'),states[n]['enemies'][0]['powers'].get('WEAK_POWER')], [-2,2])
    check('NHA首试T2实际损血', states[283399]['hp']-states[283400]['hp'], 7)
    check('NHA第二试T2实际损血', states[283418]['hp']-states[283422]['hp'], 6)
    check('TXZ第二战敌未失血', [states[281565]['enemies'][0]['hp'],states[281566]['enemies'][0]['hp']], [111,111])
    save('material-checks.json', checks)
    turn_windows = []
    for run, floor, turn in [('TXZ6RVMQA09D',48,6), ('WQZVENQ7DTRP',33,7), ('WQZVENQ7DTRP',33,9), ('NHA2KW0RB7VP',33,1), ('Q6M2Y34MWKRE',8,4)]:
        groups = []
        active = None
        for s in states.values():
            if s['run'] != run or s['floor'] != floor or not s['enemies']: continue
            if s['turn'] != turn:
                active = None
                continue
            if active is None:
                active = []
                groups.append(active)
            active.append(s)
        turn_windows.append({'run':run,'floor':floor,'turn':turn,'windows':groups,
                             'complete_candidate_execution_certified':False})
    save('turn-windows.json', turn_windows)
    picked_decisions = [x for x in decisions if x['line'] in {275383,275384,275385,275894,275960,276139,277248,277250,277272,277274}]
    save('key-decisions.json', picked_decisions)
    save('sl-records.json', sl_rows)
    save('run-config-records.json', configs)
    resource_floors = {'KEN58SH9SLZ6': [5,12,15,16,17], '1913SE84AXQF': [17,18,24,28,29,31],
                       'Q6M2Y34MWKRE': [2,7,8,9], 'NHA2KW0RB7VP':[17,19,30,33],
                       'K3676LU8B0UH':[30], 'SADL3CGYTGSR':[45]}
    resource_frames = []
    for state in states.values():
        if state['floor'] in resource_floors.get(state['run'], []):
            resource_frames.append({k:v for k,v in state.items() if k != 'hand'})
    save('resource-state-windows.json', resource_frames)
    save('evidence-summary.json', {'states':len(states),'decisions':len(decisions),
                                 'sl_records':len(sl_rows),'fixed_checks':len(checks),
                                 'fixed_checks_passed':sum(c['ok'] for c in checks),
                                 'complete_candidate_execution_certified':False})
    print(json.dumps({'rows':sum(s['rows'] for s in verified), 'checks':len(checks),
                      'failed':[c for c in checks if not c['ok']]}, ensure_ascii=False))


if __name__ == '__main__':
    main()

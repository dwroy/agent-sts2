"""Verify frozen evidence bytes and preserve bounded observations, without simulating play."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extract", OUT.parents[1] / "extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((OUT / "dispatch.json").read_text())
runs = set(dispatch["runs"])
streams = {}
validation = []
for folder in ("evidence", "evidence-extra"):
    for entry in json.loads((OUT / folder / "evidence-manifest.json").read_text()):
        stream = entry["stream"]
        path = OUT / folder / (stream + ".evidence.jsonl")
        output_hash = hashlib.sha256()
        counts = Counter()
        rows = []
        previous_line = 0
        with (Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")).open("rb") as source:
            for raw in path.open("rb"):
                output_hash.update(raw)
                item = json.loads(raw)
                assert item["line"] > previous_line
                previous_line = item["line"]
                assert item["run_id"] in runs
                assert extract.run_identity(item["row"]) == item["run_id"]
                assert item["offset"] + item["bytes"] <= entry["source_size"]
                source.seek(item["offset"])
                original = source.read(item["bytes"])
                assert hashlib.sha256(original).hexdigest() == item["sha256"]
                assert json.loads(original) == item["row"]
                counts[item["run_id"]] += 1
                rows.append(item)
        assert output_hash.hexdigest() == entry["output_sha256"]
        assert {run: counts[run] for run in runs} == entry["counts"]
        streams[stream] = rows
        validation.append({**entry, "verified_rows": len(rows), "bytes_and_identity_verified": True})


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def loc(item):
    return {key: item[key] for key in ("source", "line", "offset", "bytes", "sha256", "run_id")}


checks = []


def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})
    assert condition, name


states = {item["line"]: item for item in streams["states"]}
decisions = {item["line"]: item for item in streams["decisions"]}
before = states[280160]["row"]["state"]
after = states[280161]["row"]["state"]
check("YQL T10 原始血挡与自爆未变", all(s["combat"]["player"]["current_hp"] == 26
      and s["combat"]["player"]["block"] == 13
      and s["combat"]["enemies"][0]["intents"][0]["total_damage"] == 41 for s in (before, after)))
check("YQL T10 毒2到8", before["combat"]["enemies"][0]["powers"][0]["amount"] == 2
      and after["combat"]["enemies"][0]["powers"][0]["amount"] == 8)
check("YQL T10 原始占位血保留", all(s["combat"]["enemies"][0]["current_hp"] == 999999999 for s in (before, after)))
check("YQL T10 死亡帧为0血", states[280162]["row"]["state"]["combat"]["player"]["current_hp"] == 0)

potion_uses = []
for first, slot, potion, floor, turn in [(280206, 0, "ATTACK_POTION", 3, 2),
        (280232, 0, "STABLE_SERUM", 4, 1), (280262, 0, "SPEED_POTION", 5, 2),
        (280313, 1, "WEAK_POTION", 11, 1), (280315, 0, "ATTACK_POTION", 11, 2),
        (280348, 1, "GLOWWATER_POTION", 15, 1), (280354, 0, "SKILL_POTION", 15, 1)]:
    a, b = states[first], states[first + 1]
    sa, sb = a["row"]["state"], b["row"]["state"]
    pa = next(p for p in sa["run"]["potions"] if p["index"] == slot)
    pb = next(p for p in sb["run"]["potions"] if p["index"] == slot)
    check(f"KEN {floor}/{turn} {potion} 槽位消耗", a["run_id"] == b["run_id"] == "KEN58SH9SLZ6"
          and sa["run"]["floor"] == sb["run"]["floor"] == floor and sa["turn"] == sb["turn"] == turn
          and pa["potion_id"] == potion and pa["occupied"] is True and pb["occupied"] is False)
    potion_uses.append({"before": loc(a), "after": loc(b), "floor": floor, "turn": turn,
                        "slot": slot, "potion": potion, "counterfactual_outcome": None})

pairs = []
for a, b in [(272434, 272575), (272531, 272652), (274505, 274568), (274484, 274601)]:
    x, y = decisions[a], decisions[b]
    check(f"decisions {a}/{b} 同指纹", x["row"]["fingerprint"] == y["row"]["fingerprint"])
    pairs.append({"original": loc(x), "replacement": loc(y), "same_fingerprint": True,
                  "original_chosen": x["row"].get("chosen"), "replacement_chosen": y["row"].get("chosen")})

selected_lines = {272361, 272362, 272434, 272575, 272531, 272652, 274087,
                  274131, 274156, 274185, 274235, 274237, 274267, 274272,
                  274354, 274484, 274601, 274505, 274568}
selected = [{**loc(item), "row": item["row"]} for item in streams["decisions"] if item["line"] in selected_lines]
overview = []
for item in streams["sl-attempts"]:
    row = item["row"]
    overview.append({**loc(item), **{k: row.get(k) for k in ("floor", "encounter", "attempt", "result", "turns", "started_at", "ended_at", "end_hp", "incoming")},
                     "summary": row.get("summary"), "reference": (row.get("explore") or {}).get("target")})
for run in ("751FN9QM9MHQ", "KEN58SH9SLZ6", "YQL8RZ8BWN1E"):
    rows = [x for x in overview if x["run_id"] == run and x["floor"] == 17 and x["result"] != "unfinished"]
    check(run + " 六个相关尝试均非胜局", len(rows) == 6 and all(x["result"] != "won" for x in rows))
check("PU F17 存在已胜尝试，不能外推关闭探索", any(x["run_id"] == "PU80F84P6HPN" and x["floor"] == 17 and x["result"] == "won" for x in overview))
save("evidence-validation.json", {"streams": validation, "total_verified_rows": sum(len(x) for x in streams.values()),
     "scope": "逐行字节/身份核验；语义核验限列出的材料，不是全行机制审计或生产测试"})
save("material-checks.json", {"checks": checks, "production_tests": None})
save("potion-use-observations.json", potion_uses)
save("paired-decisions.json", pairs)
save("selected-decisions.json", selected)
save("sl-overview.json", overview)
print(json.dumps({"verified_rows": sum(len(x) for x in streams.values()), "material_checks": len(checks),
      "sl_rows": len(overview), "selected_decisions": len(selected)}, ensure_ascii=False))

# 静默猎手策略批次复核报告

记录时间：2026-10-16T00:11:25+08:00

结论：10个已领取提案均为waiting。已实现的窄诊断具有实际live祖先源码，但完整候选收益、受控整战/留药/替线后继及独立验证仍缺，不能把宽提案全部记duplicate/implemented。没有新规则、源码、经验版本、提交或合入。

基线：`05d34cd019b03fd90098cdc27e622f8b1b3fac36`；实际只读live截点：`cfa1c0be88147b4eac65c13d8c550b23ed4eef17`。本批报告与逐项提案在同一scratch目录。

## 身份和证据范围

learn.json本行task/character/worktree/runs和10个proposal_ids一致，无proposal_repair、research_request或implementation_request；未读取其他批次对应行或其他角色私有知识。六局runs.jsonl均SILENT A10；原code均带dirty，未恢复当时全部执行源码/知识，不能宣称固定输入模拟复现。L9原deciders含DeepSeek，不把六局称全Codex大脑局。

|局号|states|decisions|SL记录|run-config|run-plans|brain|runs|
|---|---:|---:|---:|---:|---:|---:|---:|
|751FN9QM9MHQ|624|615|6|1|2|15|1|
|KV0JHNJCKXLS|686|669|7|1|5|32|1|
|YQL8RZ8BWN1E|582|571|6|1|3|18|1|
|L9SGRBB5R698|653|635|6|1|3|16|1|
|PU80F84P6HPN|1064|1033|12|1|5|31|1|
|KEN58SH9SLZ6|558|548|6|1|3|18|1|

共8,444条所属原始行，全部逐行重读source的offset/bytes，核SHA256、JSON和唯一身份，并核输出SHA与manifest计数。每流冻结source_size、逐行位置和SHA见evidence*/evidence-manifest.json及*.evidence.jsonl。身份用通用入口run/run_id/state.run_id/fingerprint.run；不以正文提及归属。原全流无效JSON：states 2、decisions 2、brain 1，其余0；不能将未解析行分配到这些局。fight-plans在source_size=2233957截点本六局为0，仅说明该截点未选到，不断言原日志不存在；未覆盖任何旧截点或初稿。

## 定点核验与结论边界

19项原材料断言及15项补充断言通过，共34项；这只是材料核验，不是生产tsc/vitest、模拟重跑、完整候选认证或胜率检验。

- 751 F17 T2：decisions272434的sl_attempt=1，272575=3，同指纹；相邻轮初净损13→18、净扣敌9→18。T7第2/4试同指纹，净损13→23、净扣敌12→18。原B2 .195/.193来自第3试同一道题，不能拿第1试不同计算上下文的.30与它直接充作配对实验。
- 751 F13T3：用药plan2即时损8/伤26；整战无药plan5损8/伤16且原8/8胜模型参考。plan3本轮不喝、以后7/8样本喝，与整战无药区分。缺实打无药/留药的结局。
- KV F33第4/5试T5原指纹相同：猎杀者+毒药与仅猎杀者，轮初端点净扣36/29、损血均0；第5试273451后续原答补毒再次被SL结束回合替换。下一轮出牌不同，不把7净扣差单归整战成败；回血和路线背景不据净差补毛伤害/反事实。
- KEN F17第4/5试T10：同指纹，净损15/21、净扣敌2/4。第4/6试T5：净损7/5、净扣1/2，省血同时能力由T5延后，保留反例，不能只取最少失血。所有数是轮初净差，非逐来源毛伤害认证。
- KEN七次槽位消耗由原状态对确认；decisions274131/274237/274272仍为pending(unstable)，其后槽位空不能倒改原回执completed，亦不证明随机药水整条候选完成。
- YQL末试T10：states280160/280161毒2→8、血26/挡13/来袭41不变，280162死亡为0；26+13−41的−2算式与死亡帧截断0分别记录。巨兽本体结束不等于整战胜利。YQL和L9各六试均未赢；PU F17第5试原记录won，不能外推关闭探索或按占位血统一重排。

上述10个轮初端点窗口保存在net-endpoint-observations.json。原试次、完整摘要及字节位置见sl-overview.json，四组同指纹见paired-decisions.json，七次药水见potion-use-observations.json。完整候选执行认证仍未知：本批没有实现自动逐来源、跨重规划聚合，也没有保持其余条件不变的整战反事实。

## 现有live实现核验

source-live-audit.json核12叶，其末次源码提交均为实际live祖先；10叶逐SHA相同，sl/controller.ts与sl/explore.ts仅既有Roy/Dai注释差异，完整差保存在base-live-source-diff.patch；不改写这些历史差异。

|已有功能|实际live祖先源码提交|范围|
|---|---|---|
|未决弃牌/持牌损血事实|`9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`|`agent/src/reflex/silent-held-loss.ts`|
|未知持药价及同题无药参考|`c4670f4f416c7d93e192e889c5080e7e4e0e733f`|`agent/src/reflex/silent-potion-reference.ts`|
|SL当前轮预测资源差|`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`|`agent/src/reflex/silent-sl-resource-comparison.ts`|
|单动作派发回执|`fdaf787a372880b0438e73bcac7e6d2168b038ed`|`agent/src/reflex/silent-selection-dispatch.ts`|
|残壳毒药限定观察|`40168f4a903ae1d8c48bd03006f8fea19fd3aa3c`|`agent/src/reflex/silent-giant-potion.ts`|
|巨兽阶段/限定末态资源|`b01edf46b4b619f217d070a196e161df9fe716a0`|`agent/src/sl/attempts.ts`|

silent-selection-audit/dispatch的actual_turn为null、whole_plan_executed为null；候选比较明确标模型预测。explore.enemyHpLeft仍读原始显示血，anchorRank在同轮以此排序；现有阶段解释并未完成改排序的收益验证。以上仅证明已有窄实现，不为10个宽项登记duplicate。

## 逐项处置

|提案id|状态|具体待补数据|
|---|---|---|
|silent-proposal-366288801d9150d9|waiting|751 F17 T2第1/3试与T7第2/4试的净差已核；候选配对资源预测及单动作回执已有live源码，但缺抽弃续问后逐来源结算、完整候选执行认证和受控整战后继，不能据5/10血差设SL门槛。|
|silent-proposal-85929bdfc8a3fc1b|waiting|751 F13T3有药与整战无药模型参考、持有价值未知提示已实现；缺实际无药整战、留药到后战以及T7弃呼唤后的逐来源结算，不能改饮用或持有价。|
|silent-proposal-efd9f83ee9e1a6dc|waiting|751的SL预测分账已有live实现；同局六试相关且均失败，缺能力与手持惩罚逐来源完整兑现、同随机条件完整后继和后期独立验证，不能关闭整个提案。|
|silent-proposal-131042659448ae74|waiting|未决弃牌、持牌失血来源及未知持药值已有窄展示；actual_turn仍为null，缺敏捷/毒/荆棘/呼唤逐来源完整收益与跨战留药对照，不足整项duplicate或改规则。|
|silent-proposal-990f054036609447|waiting|KV F33T5第4/5试同指纹净扣36/29且均零损已核；缺回血毛伤害逐来源认证、重问后的完整候选认证、受控整战及路线/休息替代分支，不设SL或资源门槛。|
|silent-proposal-e18d3f18e6cac2a0|waiting|巨兽阶段、占位血说明及残壳毒药观察已有live实现；旧SL同轮排序仍使用原始占位血，缺改变参考选择后的受控完整后继与结局校准；PU存在已胜支线，不能据本体归零直接重排。|
|silent-proposal-9733bb80f445aeae|waiting|YQL末试T10毒2→8但26血/13挡/自爆41未变已核；缺提前喝、不喝、留药和改SL排序的受控整战分支，局部阶段展示不关闭整项。|
|silent-proposal-c51468c5e8ba6668|waiting|KEN七次饮用槽位消耗已核，三条原回执仍为pending；缺随机选牌及发光水重问后的完整候选收益认证、F15不用药和留药到boss的受控结果，不能拟持药阈值。|
|silent-proposal-86a7db08d1a31976|waiting|KEN F17第4/5试T10净损15/21、净扣2/4及第4/6试T5省2血但延迟步法的反例已核；缺逐来源完整兑现、受控整战和独立留出，不设统一6血/2伤门槛。|
|silent-proposal-e282a9131b99129a|waiting|KEN同盘SL血价与能力窗口得到局部端点支持，现有预测/单动作回执不认证完整候选；缺保持后轮条件的反事实与新局验证，保留探索和HP护栏。|

逐项账本id、证据、反例、预期行为、验证、切分和回退见proposal.md；原提案原字节另存，原SHA均匹配。没有新的游戏结论需要入库，没有重写复盘、重建经验库或另建重复提案。仅通过根ledger CLI追加本批报告追溯；保留已有shipped状态、首证、先验、claim、版本和全部旧证据。

根CLI实际退出0、追加16行，均只含where/note及CLI元数据；逐行offset/bytes/SHA与输入核同，保护字段完全不变，旧history/notes/where前缀保留。回执为ledger-link-receipt.json，执行前后所属条目保存在ledger-before-cli.json与ledger-after-cli.json。未降低已shipped条目状态，也没有新增证据或重复提案id。

## 代码、检查和交付

- 源码与全部知识零改动；HEAD保持完整base，工作树干净；source-diff.patch为空。
- 未提交，因此没有新提交或Co-Authored-By；未合live、未分配发布号、未通知为已上线或标shipped。
- 撤源码失败/恢复通过：无源码实现，不适用；没有冒造红绿实验。tsc/vitest/cases均null，未运行生产测试。
- 未运行play、读取游戏二进制或调用额外LLM/网络；全程独立完成，未派子agent，未触碰运维prompt/账号配置。
- 首轮源码定位误用agent/src/core/loop.ts/agent/src/loop.ts的准备失败及输出截断已保留说明；后用rg找到hand/loop.ts，完整审计另存，不当生产bug或测试失败。
- 本会话未修改模型/推理强度配置；未独立读取原生模型请求回执，不把任务文字或launcher默认当实际请求证明。

最终机器回报：result.json；本报告路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-000021/learner/runs/20261016-000031-63764a96-e1e2-4a1c-bece-e3f3a0cfd99e-strategy-proposal/report.md`。

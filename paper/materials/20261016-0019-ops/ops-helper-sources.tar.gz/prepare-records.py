from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile

root = Path.cwd()
p = root / 'ops/codex-ops/record-staging/20261016-0019'
pub = root / 'paper/materials/20261016-0019-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda path: json.loads(path.read_text())
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def git(*args, cwd=root):
    return subprocess.check_output(['git', '-C', str(cwd), *args], stderr=subprocess.PIPE)

base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
assert not (p / 'own-appends.json').exists()
learn = load(root / 'ops/codex-ops/learn.json')['batches']
jobs = ['20261016-000021-fix-batch', '20261016-000021-strategy-proposal', '20261016-000021-s2-strategy-proposal']
exec((p / 'readonly-runtime.py').read_text())
summaries, artifact_files, own_rows = [], set(), []
ledger = root / 'paper/materials/learning/ledger.jsonl'
blob_cache = {}
def blob(commit, path):
    key = (commit, path)
    if key not in blob_cache:
        blob_cache[key] = git('show', commit + ':' + path)
    return blob_cache[key]
def ancestor(commit, target):
    return subprocess.run(['git', 'merge-base', '--is-ancestor', commit, target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
def optional_blob(commit, path):
    found = git('ls-tree', commit, '--', path)
    return blob(commit, path) if found else None
def manifest(s):
    data = load(s / 'artifact-manifest.json')
    entries = [{'path': name, **value} for name, value in data.items()] if isinstance(data, dict) else data
    for row in entries:
        f = (s / row['path']).resolve()
        assert f.is_relative_to(root) and f.is_file(), str(f)
        raw = f.read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], str(f)
    return len(entries)

for index, bid in enumerate(jobs):
    b = learn[bid]
    report = b['report']
    s = Path(report['report']).parent
    out = root / 'ops/codex-ops/learner' / (bid + '.out')
    output = out.read_text()
    supplied = json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```', output)[-1])
    assert report == supplied
    assert b['rc'] == 0 and not b['proposal_audit_errors']
    assert report['fixes'] == [] and report['merged'] is None and report['implementation_domains'] == []
    assert git('rev-parse', 'HEAD', cwd=b['worktree']).decode().strip() == report['base']
    assert not git('status', '--porcelain', '--untracked-files=no', cwd=b['worktree']).strip()
    native = runtime(bid, report, output, b['worktree'])
    result_name = ['report.json', 'result.json', 'final.json'][index]
    scratch_report = load(s / result_name)
    if index == 0:
        assert {k:v for k,v in scratch_report.items() if k != 'skipped'} == {k:v for k,v in report.items() if k != 'skipped'}
        assert len(scratch_report['skipped']) == len(report['skipped']) == 14
        assert [x['item'].replace(' ', '') for x in scratch_report['skipped']] == [x['item'].replace(' ', '') for x in report['skipped']]
    else:
        assert scratch_report == report
    summary = dict(batch=bid, original_state=b['state'], original_rc=b['rc'], original_report=report,
                   native=native, unchanged_clean_worktree=True, manifest_entries_verified=manifest(s),
                   scratch_report=scratch_report, stdout_skip_reasons_abbreviated=(index == 0))
    if index == 0:
        assert b['state'] == 'failed'
        assert report['tests'] == {'tsc': 0, 'vitest': 0, 'cases': 68}
        assert (s / 'source.diff').read_bytes() == b''
        assert (s / 'final-status.txt').read_bytes() == b''
        verification = load(s / 'verification.json')
        assert verification['files'] == 8 and verification['cases'] == 68 and verification['tsc'] == verification['vitest'] == 0
        assert verification['retried'] is False and verification['full_sandbox_suite_run'] is False
        assert (s / 'tsc.exit').read_text().strip() == (s / 'targeted.exit').read_text().strip() == '0'
        audit = load(s / 'audit.json')
        assert sha(Path(audit['prior_audit']).read_bytes()) == audit['prior_audit_sha256']
        assert sha((s / 'queue-snapshot.md').read_bytes()) == audit['queue_sha256']
        assert audit['queue_unchanged_since_prior'] and audit['unchecked_entries'] == len(load(s / 'queue-dispositions.json')) == 41
        leaves = set()
        for fix in audit['existing_fixes']:
            assert ancestor(fix['source_commit'], report['base']) and ancestor(fix['source_commit'], audit['live_read_only_snapshot'])
            assert sha(blob(report['base'], fix['path'])) == fix['current_source_sha256']
            for leaf in fix['source_leaves']:
                assert sha(blob(report['base'], leaf['path'])) == leaf['sha256']
                assert (blob(report['base'], leaf['path']) == optional_blob(audit['live_read_only_snapshot'], leaf['path'])) == leaf['same_as_live']
                leaves.add(leaf['path'])
        barrier = audit['registration_barrier']
        assert ancestor(barrier['source_commit'], report['base']) and ancestor(barrier['source_commit'], audit['live_read_only_snapshot'])
        for leaf in barrier['files']:
            assert sha(blob(report['base'], leaf['path'])) == leaf['sha256']
        summary.update(original_verification=verification, original_audit=audit, queue_dispositions=41,
                       existing_fix_entries=len(audit['existing_fixes']), unique_checked_leaves=len(leaves),
                       no_new_fix_or_merge_block=True, original_failed_rc0_mergednull_preserved=True)
    else:
        assert b['state'] == 'done' and all(v is None for v in report['tests'].values())
        assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' and x['reason'] for x in report['proposal_results'])
        assert b['no_change_proposals']['dispositions'] == report['proposal_results']
        selected = load(s / 'selected-proposals.json')
        assert {x['id'] for x in selected} == set(report['code_proposals'])
        for x in selected:
            f = Path(x['proposal'])
            assert f.resolve().is_relative_to(root) and sha(f.read_bytes()) == x['proposal_sha256']
        if index == 1:
            validation = load(s / 'evidence-validation.json')
            stream_rows = validation['streams']
            assert validation['total_verified_rows'] == 8444
            checks = load(s / 'material-checks.json')['checks'] + load(s / 'additional-material-checks.json')['checks']
            assert len(checks) == 34 and all(x['passed'] for x in checks)
            source = load(s / 'source-live-audit.json')
            files, live = source['files'], source['live_head']
            assert len(files) == 12
            for x in files:
                a, z = blob(report['base'], x['path']), blob(live, x['path'])
                assert sha(a) == x['base_sha256'] and sha(z) == x['live_sha256'] and (a == z) == x['same']
                assert a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
                assert ancestor(x['last_source_commit'], live)
            receipt = load(s / 'ledger-link-receipt.json')
            assert receipt['cli_exit'] == 0 and receipt['protected_fields_unchanged'] and receipt['old_history_notes_where_preserved']
            rows = receipt['updates']
            assert len(rows) == 16
            same = sum(x['same'] for x in files)
        else:
            validation = load(s / 'raw-verification.json')
            stream_rows = load(s / 'evidence/evidence-manifest.json')
            assert validation['rows'] == 19929
            checks = load(s / 'material-checks.json')
            assert len(checks) == 21 and all(x['ok'] and x['actual'] == x['expected'] for x in checks)
            completion = load(s / 'completion-checks.json')
            assert completion['worktree_clean'] and completion['ledger_non_trace_fields_preserved']
            assert completion['ledger_updates'] == 31 and completion['gitleaks']['findings'] == completion['gitleaks']['returncode'] == 0
            source = load(s / 'source-audit-complete.json')
            files, live = source['files'], source['live']
            assert len(files) == 13
            for x in files:
                a, z = blob(report['base'], x['path']), blob(live, x['path'])
                assert sha(a) == x['workspace_sha256'] and sha(z) == x['live_sha256'] and (a == z) == x['equal']
                assert a.replace(b'Roy', b'Dai') == z.replace(b'Roy', b'Dai')
            for x in source['ancestors']:
                assert ancestor(x['commit'], live) == x['live_ancestor']
            for x in load(s / 'original-proposals-manifest.json'):
                assert sha(Path(x['source']).read_bytes()) == sha(Path(x['copy']).read_bytes()) == x['sha256']
            receipt = load(s / 'ledger-cli-receipt.json')
            assert receipt['returncode'] == 0
            rows = load(s / 'ledger-appended-rows.json')
            assert len(rows) == 31
            assert all(x['unchanged_non_trace_fields'] and x['status_before'] == x['status_after'] for x in load(s / 'ledger-readback.json'))
            same = sum(x['equal'] for x in files)
            summary['original_completion'] = completion
        for x in stream_rows:
            directory = 'evidence-extra' if index == 1 and x['stream'] in ['runs', 'fight-plans'] else 'evidence'
            f = s / directory / (x['stream'] + '.evidence.jsonl')
            assert sha(f.read_bytes()) == x['output_sha256']
        inputs = [json.loads(x) for x in (s / 'ledger-updates.jsonl').read_text().splitlines()]
        assert len(inputs) == len(rows)
        for entry in rows:
            with ledger.open('rb') as handle:
                handle.seek(entry['offset'])
                raw = handle.read(entry['bytes'])
            row = json.loads(raw)
            assert sha(raw) == entry['sha256'] and row == entry['row']
            assert set(row) <= {'op','id','ts','by','where','note'}
            assert row['op'] == 'update' and any(all(row.get(k) == v for k,v in x.items()) for x in inputs)
            own_rows.append(raw)
        summary.update(waiting=10, original_evidence_validation=validation, original_material_assertions=len(checks),
                       evidence_output_shas_verified=True, material_not_rerun=True, original_source_audit=source,
                       equal_leaves=same, historical_comment_only_differences=len(files)-same,
                       original_cli_receipt=receipt, owned_trace_only_cli_rows=len(rows))
    summaries.append(summary)
    write(pub / (bid + '-readback.json'), summary)
    for f in s.iterdir():
        if f.is_file() and f.stat().st_size < 800000:
            artifact_files.add(f)
    for f in [s/'evidence/evidence-manifest.json',s/'evidence-extra/evidence-manifest.json',out,out.with_suffix('.err')]:
        if f.is_file(): artifact_files.add(f)

assert len(own_rows) == 47 and len(set(own_rows)) == 47
old = blob(base, 'paper/materials/learning/ledger.jsonl')
assert not any(raw.rstrip(b'\n') in set(old.splitlines()) for raw in own_rows)
added = b''.join(own_rows)
spec = importlib.util.spec_from_file_location('owned_ledger', root/'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
fold = lambda raw: module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x])
a, z = fold(old), fold(old + added)
assert set(a) == set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']} == {k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:
        assert z[ident].get(key,[])[:len(a[ident].get(key,[]))] == a[ident].get(key,[])
    for key,items in a[ident]['where'].items():
        assert all(x in z[ident]['where'][key] for x in items)

artifacts = []
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted(artifact_files):
        raw = f.read_bytes()
        rel = str(f.relative_to(root))
        copy = p/'archive-scan'/rel
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        archive.add(f, arcname=rel)
        artifacts.append(dict(path=rel, bytes=len(raw), sha256=sha(raw)))
write(pub/'original-artifact-manifest.json', artifacts)
helpers = []
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw = f.read_bytes()
        copy = p/'helper-scan'/f.name
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        archive.add(f, arcname=f.name)
        helpers.append(dict(path=str(f.relative_to(root)), bytes=len(raw), sha256=sha(raw)))
write(pub/'ops-helper-manifest.json', helpers)
at = subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
print(at, flush=True)
decision = f'\n- {at} 运维codex：0019三原000021完成事件核：fix原failed/rc0/mergednull保持，空fix无新源码/提交或合入阻塞；41未勾队列逐项原处置、73旧窄修复source祖先/叶及已发布798注册屏障核，不关闭目录生命周期/0332资源截断等宽缺口。原tsc0与8文件68定向0、未重跑/未full分列，不冒完整通过。两策略原done0/no-source、各十waiting/testsnull/域空/mergednull，干净WT/05d基线不变，既有子项不替宽联合消费者/整战反事实/持药价与SL校准；8444/19929原行材料产物SHA及34/21限定断言核，不重跑或当生产测试。12叶10同2历史注释差、13叶10同3历史注释差及原真实祖先核；原dirty知识/完整候选/逐源毛伤/独立后移留出未知保持，KEN三pending不升completed、PU已胜反例不抹。两批16+31所属CLI只where/note逐输入/输出ID/offset/bytes/SHA核，私有fold全部非追溯字段及旧history/notes/where保持，不重复CLI或降级shipped；原WQ帧误取8/10后21/21更正和工具定位/空schema错误保留，不当产品bug。三native实际Sol6.1/xhigh/注册input/lease/workspace-write/no-network核，原未独立核原生声明不改。仅本人记录/47追溯提交，保并行记录；无新源码/知识/版本/论文刷新/测试/派发/对局重启/账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261016-0019-ops/。\n'
note = f'\n- {at} [运维 codex] 000021修复及两策略完成事件已核：无源码变更或合入受阻，fix原failed/rc0保留；两组20项waiting及具体缺口保持。原68项定向测试与策略材料复核分列，47所属追溯已核，未重复合入、发号或重派。回执paper/materials/20261016-0019-ops/。\n'
appends = {'paper/materials/decision-log.md':decision, 'ops/inbox-dev.md':note}
write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle: handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batches=jobs,waiting=20,owned_trace_rows=47,protected_fields_preserved=True,no_new_source_or_merge_or_checks=True,wide_parents='remain open'))
values = {path:blob(base,path)+text.encode() for path,text in appends.items()}
values['paper/materials/learning/ledger.jsonl'] = old+added
for f in pub.iterdir():
    if f.is_file(): values[str(f.relative_to(root))] = f.read_bytes()
dest = p/'final-files'
entries = []
for path,raw in values.items():
    copy = dest/path
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(raw)
    entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
result = subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True)
(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr)
assert result.returncode == 0
print(json.dumps(dict(batches=3,waiting=20,owned_trace_rows=47,ledger_check=0,paths=len(entries))))

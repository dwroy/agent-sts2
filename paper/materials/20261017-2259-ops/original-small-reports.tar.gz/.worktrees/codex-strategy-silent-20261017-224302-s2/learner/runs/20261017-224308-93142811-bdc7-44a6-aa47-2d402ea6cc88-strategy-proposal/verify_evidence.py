import collections
import hashlib
import importlib.util
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract_evidence', Path.cwd() / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def verify_envelopes():
    results = []
    manifests = [(directory, entry) for directory in ['evidence', 'evidence-brain']
                 for entry in json.loads((SCRATCH / directory / 'evidence-manifest.json').read_text())]
    for directory, entry in manifests:
        stream = entry['stream']
        output = SCRATCH / directory / f'{stream}.evidence.jsonl'
        counts = collections.Counter()
        digest = hashlib.sha256()
        with (ROOT / f'logs/{stream}.jsonl').open('rb') as raw, output.open('rb') as evidence:
            for encoded in evidence:
                digest.update(encoded)
                e = json.loads(encoded)
                assert e['offset'] + e['bytes'] <= entry['source_size']
                assert e['source'] == str(ROOT / f'logs/{stream}.jsonl')
                raw.seek(e['offset'])
                original = raw.read(e['bytes'])
                assert original.endswith(b'\n')
                assert hashlib.sha256(original).hexdigest() == e['sha256']
                assert json.loads(original) == e['row']
                assert extractor.run_identity(e['row']) == e['run_id']
                counts[e['run_id']] += 1
        assert digest.hexdigest() == entry['output_sha256']
        assert all(counts[run] == count for run, count in entry['counts'].items())
        results.append({'stream': stream, 'source_size': entry['source_size'], 'rows_verified': sum(counts.values()),
                        'output_sha256': digest.hexdigest(), 'counts': entry['counts']})
    return results


def verify_observations():
    states = {x['line']: x for x in map(json.loads, (SCRATCH / 'state-summaries.jsonl').read_text().splitlines())}
    decisions = {e['line']: e['row'] for e in json.loads((SCRATCH / 'selected-decisions.json').read_text())}
    pairs = []
    for label, first_decision, second_decision, before_a, after_a, before_b, after_b, expected in [
        ('8JRE F33 T2', 270216, 270282, 276208, 276212, 276274, 276278, [3, 10, 15, 17]),
        ('YF0L F48 T1', 271309, 271348, 277327, 277337, 277366, 277373, [0, 45, 9, 38]),
        ('XP2S F33 T3', 271992, 272040, 278028, 278031, 278076, 278079, [9, 24, 14, 27]),
        ('XP2S F33 T1', 271982, 272195, 278017, 278023, 278231, 278236, [2, 25, 10, 34]),
    ]:
        assert decisions[first_decision]['fingerprint'] == decisions[second_decision]['fingerprint']
        def delta(a, b):
            old, new = states[a], states[b]
            assert old['run_id'] == new['run_id']
            assert [(e['id'], e['max_hp']) for e in old['enemies']] == [(e['id'], e['max_hp']) for e in new['enemies']]
            return [old['hp'] - new['hp'], sum(e['hp'] for e in old['enemies']) - sum(e['hp'] for e in new['enemies'])]
        actual = delta(before_a, after_a) + delta(before_b, after_b)
        assert actual == expected
        pairs.append({'label': label, 'same_fingerprint': True, 'decision_lines': [first_decision, second_decision],
                      'state_endpoints': [before_a, after_a, before_b, after_b],
                      'original': {'observed_hp_loss': actual[0], 'enemy_net_hp_loss': actual[1]},
                      'replacement': {'observed_hp_loss': actual[2], 'enemy_net_hp_loss': actual[3]},
                      'counterfactual_whole_fight': 'unknown'})
    assert states[274838]['powers']['TAINTED_POWER'] == 18
    assert states[274839]['hp'] == 37 and 'TAINTED_POWER' not in states[274839]['powers']
    assert states[274358]['powers'].get('STRENGTH_POWER', 0) == 0
    assert states[274362]['powers']['DEXTERITY_POWER'] == -2
    assert states[273238]['enemies'][0]['attacks'] == [[11, 1]]
    assert states[273252]['enemies'][0]['attacks'] == [[15, 1]]
    assert states[273264]['enemies'][0]['attacks'] == [[19, 1]]
    assert states[273268]['enemies'][0]['attacks'] == [[14, 1]]
    assert states[277513]['enemies'][0]['max_hp'] == 212
    assert states[277513]['enemies'][0]['powers'].get('POISON_POWER', 0) == 0
    assert states[277519]['powers']['ACCELERANT_POWER'] == 2
    assert states[277519]['enemies'][0]['powers'].get('POISON_POWER', 0) == 0
    assert states[277523]['block'] == states[277526]['block'] == 23
    assert states[277523]['powers']['DEXTERITY_POWER'] == 5 and states[277526]['powers']['DEXTERITY_POWER'] == 6
    assert [states[i]['enemies'][1]['attacks'][0][0] for i in [278249, 278252, 278253]] == [57, 38, 28]
    assert states[278236]['block'] == 14 and states[278240]['block'] == 20
    assert states[278237]['enemies'][0]['powers']['STRENGTH_POWER'] == -9
    assert states[278242]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) == 0
    return {'pairs': pairs, 'mechanism_observations_match': True,
            'scope': '原帧数值读回，不是生产模型重放或策略红绿测试；敌血净差只用于无换相/复活的指定同轮端点。'}


if __name__ == '__main__':
    result = {'streams': verify_envelopes(), 'observations': verify_observations()}
    result['total_rows_verified'] = sum(x['rows_verified'] for x in result['streams'])
    (SCRATCH / 'evidence-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'total_rows_verified': result['total_rows_verified'], 'paired_windows': len(result['observations']['pairs']),
                      'mechanism_observations_match': True}, ensure_ascii=False))

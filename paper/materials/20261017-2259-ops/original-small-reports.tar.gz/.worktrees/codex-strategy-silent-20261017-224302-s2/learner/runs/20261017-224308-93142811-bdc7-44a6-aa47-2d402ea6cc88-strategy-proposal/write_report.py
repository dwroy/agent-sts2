import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
DISPATCH = json.loads((S / 'dispatch.json').read_text())
PROPOSALS = json.loads((S / 'dispatched-proposals.json').read_text())
SOURCE = json.loads((S / 'source-comparison.json').read_text())
VALIDATION = json.loads((S / 'evidence-validation.json').read_text())

DETAILS = [
    ('silent-proposal-c20b5139dd0dff71', '棱柱技能与污染血价',
     'DUZUBAJ3A8GP，F27 T4—T6；states 274830—274839。T4技能污染0→3→6，能力不增加；T5火花6、污染0→6→12→18，17挡对26攻击，HP46→37；T6污染消失。',
     '已有turn-solver技能累积/逐击计伤与rollout火花增长路径，未发现本批可确定的新源码失配。',
     '技能仍有毒、弱、挡收益；一次9血代价不支持一概禁技能。当前帧也可含未稳定的能力更新，需使用动作完成后的稳定帧。',
     '缺旧dirty运行输入下火花增长、污染清除、弱、毒与格挡的完整生产联合重放认证；没有同抽序完整替线。现有代码接线不能替代该认证，保留原技能选择。',
     '冻结A10移动/能力数据、实际手牌和稳定帧，按完整出牌前缀逐步比毒、挡、污染与HP，再验证当前参考被消费者读取。'),
    ('silent-proposal-ae9e692d680e3819', '失落与遗忘的抢夺归属',
     '5PM6JAQG6FNQ，F39 T4—T6；states 274351—274362、274391起。首试力/敏各−4，两步法后敏0；失落毒死后力回0；T6遗忘再夺2敏。末试单步法只回−2敏且仍死亡。',
     '现帧负力/负敏会进入现有模型；没有逐实体累计抢夺返还的完整实现证明。',
     '只见失落退场返力，没有遗忘退场返敏后继；不能把敌人现场总属性都当被夺量，也不能由此规定先杀谁。',
     '缺逐来源累计夺取数据、遗忘退场返敏端点和另一目标顺序的完整后继；不能由一次返力推出所有返还条件。',
     '补同实体连续抢夺/退场前后帧，分离其他力敏来源；固定重放来源分账后再比较目标顺序，不预填返敏公式。'),
    ('silent-proposal-52f1e1bd2e7db0ed', '下水道蚌的加压与覆甲',
     'CA5KE8GFJ9X2，F13 T1—T5；states 273238、273252—273254、273264—273269。力量0/4/8，喷水11/15/19；虚弱后11/14。T5有2HP、10挡，对14攻击实死。',
     'move-model按DamageContext.asc读取怪物DB；roomHpCost仍保留ROOM_COST_MIN_N=5；rollout已有加力与覆甲字段。',
     '稳定轮初覆甲/敌挡9、9、8、7、6只证明本局序列；最初过渡帧敌挡0，不能把它当已准备好的轮初。没有完整减层条件或未选线胜果。',
     '缺冻结旧运行输入下加压、覆甲与弱的联合生产重放认证及完整减层条件；现有按进阶取数路径不足以关闭整项，也不支持新房间代价。',
     '固定该局稳定轮初和实际A10移动表，逐动作比意图/敌挡/力量/HP；怪物事实首样本取数与房间五样本门槛分开验证。'),
    ('silent-proposal-6dd8bbff876be528', '电击机器人成长与召唤身份',
     '5PM6JAQG6FNQ，F38 T3/T4；states 274308—274313。同23上限电击的现场力2→4、攻击17→19；因其他敌退场，index4→3，T3仍贡献17攻击。',
     'rollout的STRENGTH_GROWTH_POWERS含HIGH_VOLTAGE_POWER，敌轮后加growth，新召唤走独立构造。',
     'index改变并不表示新实体；原日志未给可核召唤代际UUID。先杀爪牙候选35伤/损3未完整实打，不能声称必多保27血。',
     '缺可靠召唤代际身份、旧实际移动输入与另一杀序整战后继；不能认证完整重置及固定杀序。',
     '补召唤/退场连续实体链和固定移动表，区分同实体成长与新实体初值；已有接线只作局部证据。'),
    ('silent-proposal-578e415a259e6835', '沙虫分段选择、沙坑与实际血价',
     '8JRE1C4H4Z2W，F33首/第三试T2；decisions 270216/270282指纹相同。states 276208→276212与276274→276278：损3/15、扣敌10/17。末试T11为5HP、22挡对37攻击，敌166→130后死亡。',
     '已有silentSelectionAudit、silentSelectionDispatch、silentHpGuardAudit和SL资源差值，均明确预测或单动作回执；actual_turn仍未知。',
     '原/替五轮死亡是0/24与5/24，只有进一步损血都封顶47；不能写成同死率。末试保血延长仍死，护栏候选差也不自动等于实付差。',
     '缺完整续步归属、沙坑逐来源与路线资源链的联合执行认证；无同抽序完整替线后继。未发现现有审计把预测写成实值的确定错误，不重复添加已有字段。',
     '按观测指纹、尝试、分段动作与后继帧对齐；抽弃/生成/用药后重新归属，分列沙坑死与攻击死；事实审计本身不以胜局为前提，动作规则另需后置验证。'),
    ('silent-proposal-c0767768bf6a7ab1', '实验体全败候选的执行与资源',
     'YF0LXT1QSTGG，F48第二/第三试T1；decisions 271309/271348指纹相同。states 277327→277337与277366→277373：原损0扣45，替损9扣38。第三试271354结束回合；未执行续步不能预支。',
     'SL候选资源比较、选择分段及单动作派发均有实际live祖先源码；完整候选执行仍未获认证。',
     '第六试恢复防御续步T1零损仍T5死；第四试T5候选被弃牌重规划切断。F33另有SL获胜，不能把F48失败泛化为所有SL无效。',
     '缺完整候选执行及逐来源血价归属认证、同抽序整战替线与独立胜线；不能拟惩罚系数或禁止探索。',
     '核原答、护栏、SL替换、首次派发和所有续步；固定同指纹当轮0/9与45/38，后继新局再评估规则，保留探索选项。'),
    ('silent-proposal-a46bdb7fe711d79a', '分阶段毒与能力兑现',
     'YF0LXT1QSTGG，F48末试T3—T5；states 277512—277528。111阶段末4血/4毒，换212阶段清旧毒/力；触媒2已建、T5仍零毒。T5先5敏建立23挡，第三小刀后升6敏，已有挡仍23；敌197→160，18HP对44攻−23挡死亡。',
     '已有silentPhaseCurrentFacts、阶段结束参考及复活阶段状态处理；当前快照明确poison_damage_already_dealt=null。',
     '持有毒性爆发或建立触媒均不能当已施毒。其他尝试建立毒雾仍败，不支持强制能力先手或牌组上限；本局没有第三阶段。',
     '缺逐候选施毒、已结毒伤、额外扣血及敏捷取得顺序的完整执行归属；现有阶段快照不等于该联合认证，不调整排序。',
     '固定阶段边界和能力建立时点，逐动作分施毒/结毒/额外扣血、先后取得敏捷与生成挡；保留零毒触媒和已建毒雾仍败反例。'),
    ('silent-proposal-1044224808015e5c', '双蟹零胜率探索的当轮代价',
     'XP2SL33HT0D9，F33首/第二试T3及首/末试T1；decisions 271992/272040、271982/272195分别同指纹。T3实际损9→14、扣24→27；T1损2→10、扣25→34并建立1力量。',
     '当前SL仍按既有B2/rollout与未试线排名探索；资源差与分段事实已有局部审计。',
     '第三试T4为21/24→23/24死亡、B2同0胜，不能称五轮死亡率并列。末试T2零损、T3损4；成长收益不能删去。',
     '当轮血价已核；缺同抽序完整替线、成长兑现后继和独立整战胜线，不能据局部差额拟全局HP系数或新的并列规则。',
     '按run而非SL次数切分样本；固定两组当轮差额和力量建立时点，再在后移独立局比较规则，不填全局常数。'),
    ('silent-proposal-7cbc6005db712ba9', '双蟹朝向、临时减力与格挡来源',
     'XP2SL33HT0D9，F33末试T2—T5；states 278236—278261。T2已有14挡，镣铐使爪0→−9力、攻击4→0，斗篷后20挡；T3恢复0力。T4火箭57→38→28，4敏脆弱下偏折6挡；T5末毒3+7、两敌仍153/125。',
     '现有solver处理朝向、负力/临时恢复与格挡；候选含新增挡，选择审计与状态快照是分离字段。',
     '已有挡不等新增挡；T2轮初14不是每轮固定。朝向贡献19与虚弱贡献10分列，不能只按总输出或挡牌数解释。',
     '缺逐候选既有/新增挡、朝向与虚弱、已结毒和生存HP统一来源的完整联合执行认证；未发现可由该六局确定的新源码失配。',
     '固定14+6=20、0→−9→0、57→38→28与6挡、死亡/毒结算顺序；早期角色/进阶样本只作原提案历史，不冒称本批复核。'),
    ('silent-proposal-c59f592f1427a67e', '能力兑现与路线资源账联合核验',
     'YF0LXT1QSTGG F45获胜70→2（states 277224—277271），F48末试T4/T5见阶段账；XP2SL33HT0D9 F22获胜48→7（277865—277891）、F30为67→48（277937—277970）、F31为48→25（277971—278013），F33见两组血价。',
     '已有选择分段、护栏审计、阶段快照和资源差；不能据这些组件拼接宣称整条路线/药水/终局联合审计完成。',
     '获胜战仍有资源代价；SL血重置不是回血，恢复的药不当新取得。未见受控留药或另一条路线整战胜果。原经验更广历史计数未在本批重新全量核验。',
     '逐来源资源账与完整候选执行归属尚未联合认证；缺路线/药水时机受控替线与独立整战后继，保留现有规则。',
     '从可操作进战帧追到战斗最终退出，分列胜战损耗、实际喝药、回血与SL恢复，再绑定候选执行链；路线/休息/用药新阈值继续待证。'),
]


def main():
    timestamp = (S / 'report-time.txt').read_text().strip()
    by_id = {d[0]: d for d in DETAILS}
    assert set(by_id) == set(DISPATCH['proposal_ids'])
    proposal_results = [{'id': i, 'state': 'waiting', 'reason': by_id[i][5]} for i in DISPATCH['proposal_ids']]
    result = {
        'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-224302-s2-strategy-proposal',
        'base': SOURCE['base'], 'runs': DISPATCH['runs'], 'fixes': [],
        'skipped': DISPATCH['proposal_ids'], 'merged': None,
        'tests': {'tsc': None, 'vitest': None, 'cases': None},
        'code_proposals': DISPATCH['proposal_ids'], 'implementation_domains': ['combat', 'sl', 'structure'],
        'proposal_results': proposal_results, 'report': str(S / 'report.md'),
    }
    (S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    p = [f'# 本批十项原提案复核\n\n记录时间：{timestamp}\n\n',
         f'批次：20261017-224302-s2-strategy-proposal；角色silent；基线 `{SOURCE["base"]}`。\n\n',
         '只消费本批十个原CLI提案，不新增重复id，不覆盖原Markdown，不修改队列状态。来源六局均为静默A10；本批不是专题研究或冻结实现请求。十项均waiting；源码、知识与动作规则保持原状。\n\n']
    for i in DISPATCH['proposal_ids']:
        _, title, evidence, existing, counter, reason, method = by_id[i]
        original = PROPOSALS[i]
        p.extend([
            f'## {title}\n\n提案：`{i}`；账本：{", ".join(original["ledger"])}。\n\n',
            f'来源：{original["source_task"]} → strategy-proposal；原文 `{original["proposal"]}`；原SHA256 `{original["proposal_sha256"]}`，已与本批保存副本核同。\n\n',
            f'证据：{evidence}\n\n现状与已有子项：{existing}\n\n反例/限制：{counter}\n\n',
            f'本批处置：**waiting**。{reason}\n\n预期行为：维持已有选项、排名、权重和护栏；后继仅在上述证据范围补全可核实的事实归属，预测与实付分列。\n\n',
            f'验证方法：{method} 新实现须固定输入、撤源码失败/恢复通过、原沙箱入口通过并真实合入live；没有完整执行证据不得把候选当实值。\n\n',
            '样本与拟合：本批只复核指定来源局；同存档SL尝试不增加独立局分母，不拟合新系数。原案其他历史局/较宽进阶支持数保留原含义，不冒称本批复验。未来按run_id及结束时间后移验证，当前没有独立留出集或胜率改善结论。\n\n',
            '预期影响与回退：本批只交付证据和处置追溯，无游戏行为影响、无需代码回退；后继实现若上线，使用自己的源码提交回退并按原流程记录版本及双通知Roy。授权Roy-2026-10-07-learning仅提供权限。\n\n',
        ])
    (S / 'proposal.md').write_text(''.join(p))
    table = ['| 日志流 | 固定source_size字节 | 核回行数 |\n|---|---:|---:|\n']
    for entry in VALIDATION['streams']:
        table.append(f'| {entry["stream"]} | {entry["source_size"]} | {entry["rows_verified"]} |\n')
    rows = []
    for i in DISPATCH['proposal_ids']:
        d = by_id[i]
        rows.append(f'| `{i}` | {d[1]} | waiting：{d[5]} |\n')
    report = f'''# 静默A10策略提案复核报告

记录时间：{timestamp}

本批十项均waiting。没有新增源码、知识或策略实现；没有提交、合入、版本或shipped登记。四组同指纹当轮血价得到原帧确认，但不能由它们拟合全局血价、固定杀序、禁止SL或强制能力规则。已有局部审计源码另行列证，不把它们拼成宽提案完成。

## 身份与边界

- batch：20261017-224302-s2-strategy-proposal；task=strategy-proposal；character=silent；reason=proposal。
- 本批learn.json只有指定十个proposal_ids，无research_request、implementation_request或proposal_repair。根普通专题请求绑定其他历史批次，不适用于本批；两个专用注册回执不存在不构成本普通批阻塞。
- 开工git status干净；按任务合main返回Already up to date。base及最终HEAD均为 `{SOURCE['base']}`。
- 六局runs.jsonl均SILENT、A10：DUZUBAJ3A8GP、5PM6JAQG6FNQ、CA5KE8GFJ9X2、8JRE1C4H4Z2W、YF0LXT1QSTGG、XP2SL33HT0D9。只处理这六局和原案关联的本角色账本/经验，未读取其他角色知识，也未重新全量核验原案历史局。
- 已读必读材料、代码提案与学习入库闭环说明。未启动游戏、调用模型/网络、派下级或触碰运维prompt。

## 证据与完整性

共用extract_evidence.py按显式身份提取八流，七流主输出与brain补充输出分别保存各自manifest，不覆盖初稿。共 {VALIDATION['total_rows_verified']} 条封套逐条回到原日志核offset/bytes/SHA/JSON/所属局，并核输出SHA及逐局计数；通过回执是evidence-validation.json。此为证据完整性和原帧读回，**不是生产模型测试**。

{''.join(table)}
fight-plans在该固定截点选中0行，只表示未选中，不断言原日志缺失。states/decisions/brain各有2条全流无效JSON，已由抽取入口计数，不分配给本批局；无未完整行。各流截点独立，不能冒称同一原子全日志快照。

四组相同fingerprint与实际相邻轮初端点（净敌血差只用于这些无换相/复活的指定当轮）：

| 对照 | 原/替损血 | 原/替敌血净扣 | 限制 |
|---|---:|---:|---|
| 8JRE F33 T2，首/第三试 | 3/15 | 10/17 | 五轮死亡0/24与5/24不同，进一步损血均封顶47 |
| YF0L F48 T1，第二/第三试 | 0/9 | 45/38 | 第六试恢复挡仍败；不能宣称原线必胜 |
| XP2S F33 T3，首/第二试 | 9/14 | 24/27 | 后继抽序/决策不同，不是整场单变量试验 |
| XP2S F33 T1，首/末试 | 2/10 | 25/34 | 另建立1力量，不能抹去成长收益 |

其余原帧核回：棱柱火花3→6与污染18后清除；蚌力量0/4/8、喷水11/15/19及弱后11/14；失落返力及遗忘再夺敏；实验体111→212清毒、零毒触媒2、23挡取得后再升敏；双蟹57→38→28、轮初14加6挡、暂减9力后恢复。详细局号/层/回合、账本及反例逐项见proposal.md。turn-boundaries.json首/末帧仅是索引，过渡帧与未完成敌方结算不能自动当稳定可操作轮初或完整实付。

## 逐项处置

| 原提案 | 范围 | 具体处置 |
|---|---|---|
{''.join(rows)}
事实审计不以获胜替线为必要条件；本批等待的审计范围是完整续步和逐来源归属的联合认证。现有字段明确标预测/单动作且实际结果未知，本批未核出新的确定误报；无需重复实现已有子项。改变动作权重或探索规则则还需要独立后继和反事实证据。原提案不关闭、原支持/反例数不增加，不另造id。

## 源码与已有实现证据

静态live快照 `{SOURCE['live_snapshot']}`；source-comparison.json保存14叶base/live blob、工作树SHA、最后触碰提交及真实live祖先布尔。11叶字节相同；rollout-live.ts、move-model.ts、explore.ts三叶差异仅Roy/Dai署名注释，已另存base-live-comment-differences.patch。它们是历史差异，不是本批改动。原六局都记录+dirty，不能用当前代码拼回当时完整运行树。

- 选择分段：9d8278702dbc581b5015ba7ec9a70dc0fb94cccb为当前叶祖先；只记录预测，actual_turn=null。
- 单动作回执：fdaf787a372880b0438e73bcac7e6d2168b038ed；明确whole_plan_executed=null、state_effect_verified=false。
- SL资源差：0e4fe4df89a06682468e0e4716c12126e76369d5；含沙坑/污染/剩余毒的候选数据，execution=unverified。
- 当前阶段：aad2700abed6dff1d66e87fb36aaa6fedb39adf3；实际快照与已结毒伤未知分列。
- 护栏候选：66283dd9982bdd7f480da7a4d9bfefea0572a9ac；actual_outcome=null。

以上均核为该live快照祖先，**只支持已有子项**，没有给任何宽提案登记duplicate/implemented。按进阶DB事实及房间成本五样本门槛保持。25个关联silent经验条目仅读取、保存选中快照，不修改文本/数值或把其较宽适用进阶当本批证实。

## 验证、记录与交接

源码变更为空，source-diff.patch为空；生产tsc/vitest/cases均null，没有撤源码红绿测试、源码提交、合入或eval版本。证据核验脚本rc0只证明原帧/封套复核，不借用历史绿色测试。两次只读schema探针分别遇到非战斗combat=null与空hand，产生TypeError/IndexError；后改为防空解析并完整核回，未改生产代码或账本；原工具事件保留。

只经根learner/ledger.py update追加本批报告/提案链接及有界复核说明，不改claim、first_run、prior、原支持/反例、status或version；无新证据重复登记，无shipped。实际CLI输入、输出和保护字段检查见ledger-update-input.jsonl、ledger-update.log、ledger-trace-validation.json。队列处置由最终proposal_results交原调度器消费，本学习者不手改learn.json/队列。

运维交接提案：{S / 'proposal.md'}

运维交接报告：{S / 'report.md'}

每项waiting的缺数据与下一步在原id下保持；本次结束不关闭父要求。没有新的机制反证或与当前经验冲突，0/24对5/24及21/24对23/24的区别已在原提案中明确，本批只是重新核回，不制造新异议通知或其他角色ACK。

最终机器结果：result.json。没有新上线，merge=live流程不进入；没有需要编号、通知新规则或登记shipped的提交。工作树保持干净，原证据、失败与过程文件保留原路径，待原调度器验收和回收。
'''
    (S / 'report.md').write_text(report)
    print(json.dumps({'report': str(S / 'report.md'), 'proposal': str(S / 'proposal.md'),
                      'waiting': len(proposal_results), 'evidence_rows': VALIDATION['total_rows_verified']}, ensure_ascii=False))


if __name__ == '__main__':
    main()

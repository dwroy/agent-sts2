import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/dw/Projects/agent-sts2')
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('project_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)

proposals = json.loads((S / 'dispatched-proposals.json').read_text())
ids = sorted({i for p in proposals.values() for i in p['ledger']})
selected = {i: [] for i in ids}
for p in proposals.values():
    for i in p['ledger']:
        selected[i].append(p['id'])
before = ledger.fold()
prefix = (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()
protected = ['character', 'claim', 'first_run', 'prior', 'prior_note', 'prior_runs', 'asc', 'status', 'version', 'shipped_at', 'evidence', 'effect']
snapshot = {i: {k: before[i].get(k) for k in protected} for i in ids}
(S / 'ledger-protected-before.json').write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + '\n')
updates = []
for i in ids:
    assert before[i]['character'] == 'silent'
    updates.append({
        'id': i, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
        'note': '20261017-224302-s2-strategy-proposal：复核本批原提案' + '、'.join(selected[i]) +
                '；八流8274封套与指定原帧核回，处置及缺数据见本批proposal.md/report.md。只追加本批追溯，不新增support/repeat/contradict，不改原结论/状态/版本；无源码实现、合入或shipped。',
    })
encoded = ''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates)
(S / 'ledger-update-input.jsonl').write_text(encoded)
command = [sys.executable, str(ROOT / 'learner/ledger.py'), 'update']
completed = subprocess.run(command, input=encoded, text=True, capture_output=True)
(S / 'ledger-update.log').write_text(completed.stdout + completed.stderr)
assert completed.returncode == 0, completed.returncode
after = ledger.fold()
for i in ids:
    assert {k: after[i].get(k) for k in protected} == snapshot[i], i
    assert str(S / 'proposal.md') in after[i]['where']['proposal']
    assert str(S / 'report.md') in after[i]['where']['proposal']
assert (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()[:len(prefix)] == prefix
result = {
    'cli': command, 'returncode': completed.returncode, 'updated_ids': ids, 'update_count': len(ids),
    'prefix_size': len(prefix), 'prefix_sha256': hashlib.sha256(prefix).hexdigest(),
    'original_prefix_unchanged': True, 'protected_fields_unchanged': protected,
    'new_evidence_rows': 0, 'status_changes': 0, 'source_commits': [],
}
(S / 'ledger-trace-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'ledger_updates': len(ids), 'rc': completed.returncode, 'protected_fields_unchanged': True}, ensure_ascii=False))

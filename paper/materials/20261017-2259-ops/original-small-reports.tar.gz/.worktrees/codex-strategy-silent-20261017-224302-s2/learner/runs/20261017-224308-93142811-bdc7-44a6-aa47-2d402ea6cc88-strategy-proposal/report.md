# 静默A10策略提案复核报告

记录时间：2026-10-17T22:56:24+08:00

本批十项均waiting。没有新增源码、知识或策略实现；没有提交、合入、版本或shipped登记。四组同指纹当轮血价得到原帧确认，但不能由它们拟合全局血价、固定杀序、禁止SL或强制能力规则。已有局部审计源码另行列证，不把它们拼成宽提案完成。

## 身份与边界

- batch：20261017-224302-s2-strategy-proposal；task=strategy-proposal；character=silent；reason=proposal。
- 本批learn.json只有指定十个proposal_ids，无research_request、implementation_request或proposal_repair。根普通专题请求绑定其他历史批次，不适用于本批；两个专用注册回执不存在不构成本普通批阻塞。
- 开工git status干净；按任务合main返回Already up to date。base及最终HEAD均为 `03e5a8f50b01203ece2518d0391d15936aa4dd50`。
- 六局runs.jsonl均SILENT、A10：DUZUBAJ3A8GP、5PM6JAQG6FNQ、CA5KE8GFJ9X2、8JRE1C4H4Z2W、YF0LXT1QSTGG、XP2SL33HT0D9。只处理这六局和原案关联的本角色账本/经验，未读取其他角色知识，也未重新全量核验原案历史局。
- 已读必读材料、代码提案与学习入库闭环说明。未启动游戏、调用模型/网络、派下级或触碰运维prompt。

## 证据与完整性

共用extract_evidence.py按显式身份提取八流，七流主输出与brain补充输出分别保存各自manifest，不覆盖初稿。共 8274 条封套逐条回到原日志核offset/bytes/SHA/JSON/所属局，并核输出SHA及逐局计数；通过回执是evidence-validation.json。此为证据完整性和原帧读回，**不是生产模型测试**。

| 日志流 | 固定source_size字节 | 核回行数 |
|---|---:|---:|
| states | 14086372323 | 4062 |
| decisions | 2364380203 | 3941 |
| sl-attempts | 46343512 | 38 |
| run-config | 1998507 | 6 |
| run-plans | 9076458 | 33 |
| runs | 364250 | 6 |
| fight-plans | 2233957 | 0 |
| brain | 775077576 | 188 |

fight-plans在该固定截点选中0行，只表示未选中，不断言原日志缺失。states/decisions/brain各有2条全流无效JSON，已由抽取入口计数，不分配给本批局；无未完整行。各流截点独立，不能冒称同一原子全日志快照。

四组相同fingerprint与实际相邻轮初端点（净敌血差只用于这些无换相/复活的指定当轮）：

| 对照 | 原/替损血 | 原/替敌血净扣 | 限制 |
|---|---:|---:|---|
| 8JRE F33 T2，首/第三试 | 3/15 | 10/17 | 五轮死亡0/24与5/24不同，进一步损血均封顶47 |
| YF0L F48 T1，第二/第三试 | 0/9 | 45/38 | 第六试恢复挡仍败；不能宣称原线必胜 |
| XP2S F33 T3，首/第二试 | 9/14 | 24/27 | 后继抽序/决策不同，不是整场单变量试验 |
| XP2S F33 T1，首/末试 | 2/10 | 25/34 | 另建立1力量，不能抹去成长收益 |

其余原帧核回：棱柱火花3→6与污染18后清除；蚌力量0/4/8、喷水11/15/19及弱后11/14；失落返力及遗忘再夺敏；实验体111→212清毒、零毒触媒2、23挡取得后再升敏；双蟹57→38→28、轮初14加6挡、暂减9力后恢复。详细局号/层/回合、账本及反例逐项见proposal.md。turn-boundaries.json首/末帧仅是索引，过渡帧与未完成敌方结算不能自动当稳定可操作轮初或完整实付。

## 逐项处置

| 原提案 | 范围 | 具体处置 |
|---|---|---|
| `silent-proposal-c20b5139dd0dff71` | 棱柱技能与污染血价 | waiting：缺旧dirty运行输入下火花增长、污染清除、弱、毒与格挡的完整生产联合重放认证；没有同抽序完整替线。现有代码接线不能替代该认证，保留原技能选择。 |
| `silent-proposal-ae9e692d680e3819` | 失落与遗忘的抢夺归属 | waiting：缺逐来源累计夺取数据、遗忘退场返敏端点和另一目标顺序的完整后继；不能由一次返力推出所有返还条件。 |
| `silent-proposal-52f1e1bd2e7db0ed` | 下水道蚌的加压与覆甲 | waiting：缺冻结旧运行输入下加压、覆甲与弱的联合生产重放认证及完整减层条件；现有按进阶取数路径不足以关闭整项，也不支持新房间代价。 |
| `silent-proposal-6dd8bbff876be528` | 电击机器人成长与召唤身份 | waiting：缺可靠召唤代际身份、旧实际移动输入与另一杀序整战后继；不能认证完整重置及固定杀序。 |
| `silent-proposal-578e415a259e6835` | 沙虫分段选择、沙坑与实际血价 | waiting：缺完整续步归属、沙坑逐来源与路线资源链的联合执行认证；无同抽序完整替线后继。未发现现有审计把预测写成实值的确定错误，不重复添加已有字段。 |
| `silent-proposal-c0767768bf6a7ab1` | 实验体全败候选的执行与资源 | waiting：缺完整候选执行及逐来源血价归属认证、同抽序整战替线与独立胜线；不能拟惩罚系数或禁止探索。 |
| `silent-proposal-a46bdb7fe711d79a` | 分阶段毒与能力兑现 | waiting：缺逐候选施毒、已结毒伤、额外扣血及敏捷取得顺序的完整执行归属；现有阶段快照不等于该联合认证，不调整排序。 |
| `silent-proposal-1044224808015e5c` | 双蟹零胜率探索的当轮代价 | waiting：当轮血价已核；缺同抽序完整替线、成长兑现后继和独立整战胜线，不能据局部差额拟全局HP系数或新的并列规则。 |
| `silent-proposal-7cbc6005db712ba9` | 双蟹朝向、临时减力与格挡来源 | waiting：缺逐候选既有/新增挡、朝向与虚弱、已结毒和生存HP统一来源的完整联合执行认证；未发现可由该六局确定的新源码失配。 |
| `silent-proposal-c59f592f1427a67e` | 能力兑现与路线资源账联合核验 | waiting：逐来源资源账与完整候选执行归属尚未联合认证；缺路线/药水时机受控替线与独立整战后继，保留现有规则。 |

事实审计不以获胜替线为必要条件；本批等待的审计范围是完整续步和逐来源归属的联合认证。现有字段明确标预测/单动作且实际结果未知，本批未核出新的确定误报；无需重复实现已有子项。改变动作权重或探索规则则还需要独立后继和反事实证据。原提案不关闭、原支持/反例数不增加，不另造id。

## 源码与已有实现证据

静态live快照 `deb9135b8c8e63080beae091b959a04738c64587`；source-comparison.json保存14叶base/live blob、工作树SHA、最后触碰提交及真实live祖先布尔。11叶字节相同；rollout-live.ts、move-model.ts、explore.ts三叶差异仅Roy/Dai署名注释，已另存base-live-comment-differences.patch。它们是历史差异，不是本批改动。原六局都记录+dirty，不能用当前代码拼回当时完整运行树。

- 选择分段：9d8278702dbc581b5015ba7ec9a70dc0fb94cccb为当前叶祖先；只记录预测，actual_turn=null。
- 单动作回执：fdaf787a372880b0438e73bcac7e6d2168b038ed；明确whole_plan_executed=null、state_effect_verified=false。
- SL资源差：0e4fe4df89a06682468e0e4716c12126e76369d5；含沙坑/污染/剩余毒的候选数据，execution=unverified。
- 当前阶段：aad2700abed6dff1d66e87fb36aaa6fedb39adf3；实际快照与已结毒伤未知分列。
- 护栏候选：66283dd9982bdd7f480da7a4d9bfefea0572a9ac；actual_outcome=null。

以上均核为该live快照祖先，**只支持已有子项**，没有给任何宽提案登记duplicate/implemented。按进阶DB事实及房间成本五样本门槛保持。25个关联silent经验条目仅读取、保存选中快照，不修改文本/数值或把其较宽适用进阶当本批证实。

## 验证、记录与交接

源码变更为空，source-diff.patch为空；生产tsc/vitest/cases均null，没有撤源码红绿测试、源码提交、合入或eval版本。证据核验脚本rc0只证明原帧/封套复核，不借用历史绿色测试。两次只读schema探针分别遇到非战斗combat=null与空hand，产生TypeError/IndexError；后改为防空解析并完整核回，未改生产代码或账本；原工具事件保留。

只经根learner/ledger.py update追加本批报告/提案链接及有界复核说明，不改claim、first_run、prior、原支持/反例、status或version；无新证据重复登记，无shipped。实际CLI输入、输出和保护字段检查见ledger-update-input.jsonl、ledger-update.log、ledger-trace-validation.json。队列处置由最终proposal_results交原调度器消费，本学习者不手改learn.json/队列。

运维交接提案：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-224302-s2/learner/runs/20261017-224308-93142811-bdc7-44a6-aa47-2d402ea6cc88-strategy-proposal/proposal.md

运维交接报告：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-224302-s2/learner/runs/20261017-224308-93142811-bdc7-44a6-aa47-2d402ea6cc88-strategy-proposal/report.md

每项waiting的缺数据与下一步在原id下保持；本次结束不关闭父要求。没有新的机制反证或与当前经验冲突，0/24对5/24及21/24对23/24的区别已在原提案中明确，本批只是重新核回，不制造新异议通知或其他角色ACK。

最终机器结果：result.json。没有新上线，merge=live流程不进入；没有需要编号、通知新规则或登记shipped的提交。工作树保持干净，原证据、失败与过程文件保留原路径，待原调度器验收和回收。

import collections
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
TARGETS = {
    'DUZUBAJ3A8GP': {27, 28, 29, 30},
    '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 45, 47, 48},
    'XP2SL33HT0D9': {22, 30, 31, 33},
}


def powers(holder):
    return {p.get('power_id'): p.get('amount') for p in holder.get('powers') or []}


def summarize_states():
    attempts = collections.defaultdict(lambda: 1)
    turns = {}
    counts = collections.Counter()
    groups = collections.defaultdict(list)
    with (SCRATCH / 'evidence/states.evidence.jsonl').open() as source, (SCRATCH / 'state-summaries.jsonl').open('w') as output:
        for line in source:
            envelope = json.loads(line)
            row = envelope['row']
            state = row['state']
            run_id = envelope['run_id']
            run = state.get('run') or {}
            floor = run.get('floor')
            combat = state.get('combat')
            turn = state.get('turn')
            if floor not in TARGETS[run_id] or not isinstance(combat, dict) or not isinstance(turn, int) or turn <= 0:
                continue
            key = (run_id, floor)
            if key in turns and turn < turns[key]:
                attempts[key] += 1
            turns[key] = turn
            player = combat.get('player') or {}
            item = {
                'run_id': run_id, 'line': envelope['line'], 'offset': envelope['offset'],
                'bytes': envelope['bytes'], 'sha256': envelope['sha256'],
                'floor': floor, 'turn': turn, 'attempt_by_turn_reset': attempts[key],
                'hp': player.get('current_hp'), 'block': player.get('block'),
                'energy': player.get('energy'), 'cards_played': player.get('cards_played_this_turn'),
                'powers': powers(player),
                'enemies': [{
                    'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                    'max_hp': e.get('max_hp'), 'block': e.get('block'), 'alive': e.get('is_alive'),
                    'move': e.get('move_id'), 'powers': powers(e),
                    'attacks': [[i.get('damage'), i.get('hits')] for i in e.get('intents') or [] if i.get('intent_type') == 'Attack'],
                } for e in combat.get('enemies') or []],
            }
            output.write(json.dumps(item, ensure_ascii=False) + '\n')
            counts[run_id] += 1
            groups[(run_id, floor, attempts[key], turn)].append(item)
    compact = []
    for key, values in groups.items():
        compact.append({'run_id': key[0], 'floor': key[1], 'attempt_by_turn_reset': key[2], 'turn': key[3],
                        'first': values[0], 'last': values[-1], 'frame_count': len(values)})
    (SCRATCH / 'turn-boundaries.json').write_text(json.dumps(compact, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'selected_frames': counts, 'turn_windows': len(compact)}, ensure_ascii=False))


if __name__ == '__main__':
    summarize_states()

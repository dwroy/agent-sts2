"""Recompute bounded observations; never label a whole candidate as executed."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = [json.loads(line) for line in (OUT / "evidence/states.evidence.jsonl").open()]
decisions = [json.loads(line) for line in (OUT / "evidence/decisions.evidence.jsonl").open()]
projected = {row["line"]: row for row in json.loads((OUT / "target-state-projections.json").read_text())}
checks = []


def check(name, actual, expected, lines):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected, "state_lines": lines})


def pp(line, power):
    return projected[line]["powers"].get(power, 0)


def enemy(line, ident):
    found = [e for e in projected[line]["enemies"] if e["id"] == ident]
    assert len(found) == 1
    return found[0]


def ep(line, ident, power):
    return enemy(line, ident)["powers"].get(power, 0)


def attack(line, ident):
    return sum(a["total"] for a in enemy(line, ident)["attacks"])


check("棱柱T4污染/能力不加层", [pp(n, "TAINTED_POWER") for n in [274830, 274831, 274832, 274833]],
      [0, 3, 3, 6], [274830, 274831, 274832, 274833])
check("棱柱T5火花与三技能污染", [ep(274834, "INFESTED_PRISM", "VITAL_SPARK_POWER")] +
      [pp(n, "TAINTED_POWER") for n in [274834, 274836, 274837, 274838, 274839]],
      [6, 0, 6, 12, 18, 0], [274834, 274836, 274837, 274838, 274839])
check("棱柱T4/T5净损", [projected[274830]["hp"] - projected[274834]["hp"],
      projected[274834]["hp"] - projected[274839]["hp"]], [3, 9], [274830, 274834, 274839])
check("蚌喷水与力量", [[attack(n, "SEWER_CLAM"), ep(n, "SEWER_CLAM", "STRENGTH_POWER")]
      for n in [273238, 273252, 273263]], [[11, 0], [15, 4], [19, 8]], [273238, 273252, 273263])
check("蚌虚弱后攻击", [attack(n, "SEWER_CLAM") for n in [273254, 273268]], [11, 14], [273254, 273268])
check("蚌覆甲只列现场", [ep(n, "SEWER_CLAM", "PLATING_POWER") for n in
      [273238, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6], [273238, 273247, 273252, 273258, 273263])
check("电击同最大HP实体增长", [[enemy(n, "ZAPBOT")["max_hp"], ep(n, "ZAPBOT", "STRENGTH_POWER"),
      attack(n, "ZAPBOT")] for n in [274308, 274313]], [[23, 2, 17], [23, 4, 19]], [274308, 274313])
check("两次抢夺与步法恢复", [[pp(n, "STRENGTH_POWER"), pp(n, "DEXTERITY_POWER")]
      for n in [274341, 274351, 274352, 274354, 274358, 274362]],
      [[-2, -2], [-4, -4], [-4, -2], [-4, 0], [0, 0], [0, -2]],
      [274341, 274351, 274352, 274354, 274358, 274362])
check("实验体换相快照", [[enemy(n, "TEST_SUBJECT")["hp"], enemy(n, "TEST_SUBJECT")["max_hp"],
      ep(n, "TEST_SUBJECT", "POISON_POWER"), ep(n, "TEST_SUBJECT", "STRENGTH_POWER")]
      for n in [277512, 277513]], [[4, 111, 4, 15], [212, 212, 0, 0]], [277512, 277513])
check("双蟹临时减力与恢复", [ep(n, "CRUSHER", "STRENGTH_POWER") for n in [278236, 278237, 278242]],
      [0, -9, 0], [278236, 278237, 278242])
check("双蟹朝向与虚弱", [attack(n, "ROCKET") for n in [278249, 278252, 278254]],
      [57, 38, 28], [278249, 278252, 278254])
check("实验体已建触媒与当前零毒", [pp(277519, "ACCELERANT_POWER"),
      ep(277519, "TEST_SUBJECT", "POISON_POWER")], [2, 0], [277519])
check("后来取得敏捷不倒补现场挡", [[pp(n, "DEXTERITY_POWER"), projected[n]["block"]]
      for n in [277523, 277526, 277527]], [[5, 23], [6, 23], [6, 23]], [277523, 277526, 277527])
check("实验体结算前算术生存缺口", attack(277527, "TEST_SUBJECT") -
      projected[277527]["block"] - projected[277527]["hp"], 3, [277527])
check("双蟹轮初与本轮新增挡分账", [[projected[n]["block"], projected[n]["hp"]]
      for n in [278236, 278240, 278242]], [[14, 37], [20, 37], [0, 37]], [278236, 278240, 278242])

by_decision = {d["line"]: d for d in decisions}
paired = []
for left, right, expected in [(270216, 270282, [[3, 10], [15, 17]]),
                             (271309, 271348, [[0, 45], [9, 38]]),
                             (271992, 272040, [[9, 24], [14, 27]]),
                             (271982, 272195, [[2, 25], [10, 34]])]:
    a, b = by_decision[left], by_decision[right]
    assert a["row"]["fingerprint"] == b["row"]["fingerprint"]
    observations = []
    for item in [a, b]:
        d = item["row"]
        matches = [i for i, s in enumerate(states) if s["run_id"] == item["run_id"] and
                   s["row"].get("observed_ts") == d["observed_ts"] and
                   s["row"].get("fingerprint") == d["fingerprint"]]
        assert len(matches) == 1
        i = matches[0]
        start = states[i]
        end = None
        for s in states[i + 1:]:
            if s["run_id"] != item["run_id"]:
                break
            raw = s["row"]["state"]
            if raw.get("run", {}).get("floor") != d["floor"] or raw.get("turn", 0) < d["turn"]:
                break
            if raw.get("turn") == d["turn"] + 1:
                end = s
                break
        assert end is not None
        before, after = projected[start["line"]], projected[end["line"]]
        roster = lambda row: {(e["id"], e["max_hp"]) for e in row["enemies"]}
        assert roster(before) == roster(after)
        hp_loss = before["hp"] - after["hp"]
        enemy_net_loss = sum(e["hp"] for e in before["enemies"]) - sum(e["hp"] for e in after["enemies"])
        observations.append({"decision_line": item["line"], "start_state_line": start["line"],
                             "end_state_line": end["line"], "player_net_hp_loss": hp_loss,
                             "enemy_net_hp_loss": enemy_net_loss})
    check("同指纹观测窗口" + str(left) + "/" + str(right),
          [[o["player_net_hp_loss"], o["enemy_net_hp_loss"]] for o in observations], expected,
          [o["start_state_line"] for o in observations] + [o["end_state_line"] for o in observations])
    paired.append({"run": a["run_id"], "same_fingerprint": True, "windows": observations,
                   "scope": "同盘面至下一轮的观测净差；不认证整候选执行或SL因果"})

(OUT / "verified-facts.json").write_text(json.dumps({"checks": checks, "pairs": paired},
                                                   ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"checks_passed": len(checks), "pairs": paired}, ensure_ascii=False))

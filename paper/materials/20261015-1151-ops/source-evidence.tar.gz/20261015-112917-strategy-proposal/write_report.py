"""Persist the reviewable disposition and CLI-only ledger link payload."""
import datetime as dt
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = "5b45cda3ac1bcba0cd93b527f571a4dbfb8bf45d"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == BASE
assert not subprocess.check_output(["git", "status", "--porcelain=v1"], text=True)
dispatch = json.loads((OUT / "dispatch.json").read_text())
proposals = json.loads((OUT / "assigned-proposals.json").read_text())
reasons = [
    "已核F27T4/T5污染0→3→6与0→6→12→18、净损3/9；现有求解器读取现场火花、逐技能累积并跨轮清空，推演已有火花增长接线。尚无当前进阶移动表及勒紧/迷雾/污染联合路径的逐步源码数值校准，未定位新增确定性差异；不能把9损写成技能禁用规则。",
    "已核F39两次抢夺、两步法恢复0敏、毒杀失落后力量归0及T6再失2敏。现帧负属性不提供全部历史抢夺来源/返还所有权；缺可核对的逐来源返还重放和另一杀序完整对照，不设固定击杀序。",
    "已核F13T1/T3/T5无弱喷水11/15/19、力量0/4/8、弱后11/14及覆甲9/9/8/7/6。数据库和成长路径已有接口；缺历史实际消费的A10移动表快照与覆甲减层条件校准，未定位新数值补丁；不将现场数字变成固定房间代价。",
    "已核F38T3/T4同23最大HP电击力量2→4、威胁17→19、T4才退场。现有逐敌增长路径存在，但本批缺召唤代际的持久身份及新实体不继承旧计数的完整观测/冻结输入；未实打的先杀线也不能当整战收益。",
    "已核沙虫F33首/三试T2同指纹，观测损3/15、敌净扣10/17；候选选择与护栏审计已有live祖先，离线整轮窗口也已实现。整候选归属仍未知，缺原答/护栏/SL/重规划联合兑现的完整校准及独立后继样本；不拟HP或成长系数。",
    "已核实验体F48第二/三试T1同指纹，观测损0/9、敌净扣45/38；YF的F33第二次SL仍实胜余20，保留反例。已有候选/窗口审计不认证未执行续步或完整替代线；缺相关资源及后继完整胜负对照，不设禁止探索或血价常数。",
    "已核F48末次T3/T4换相111→212并清旧毒/敌力量、T5触媒2而当前零毒、23挡在敏捷5→6后不倒补、结算前差3HP。当前阶段事实模块已有live祖先；它只列快照，缺下一轮增段/阶段分账与候选实际执行的联合校准，不能据此调整排序或宣称整项完成。",
    "已核双蟹F33首/二试T3同指纹损9/14、敌净扣24/27，以及首/末T1损2/10、净扣25/34。有限零胜并列不证明血价相同；缺独立后继整战与原线继续的受控结果，不能确定新的低损优先策略。",
    "已核双蟹末试T2轮初14挡→本轮20挡且零损、镣铐0→−9→0；T4朝向/弱分列57→38→28，4敏脆弱下挡6。现场模型和原日志参考已有局部实现；缺逐候选贡献拆分、完整执行绑定及未观察条件校准，不新增能力/目标权重，也不外推升级版。",
    "已复核YF/XP同盘SL血价、临时减力、轮初挡与能力兑现。现有快照/候选/区间/整轮接口均保持完整候选归属null；本批六个派发锚点不能重做或代替原101局历史分母，缺逐来源资源、完整候选与独立后继联合校准，不登记整提案duplicate/implemented。",
]
locations = ["DUZUBAJ3A8GP F27 T4–6", "5PM6JAQG6FNQ F39 T2–6", "CA5KE8GFJ9X2 F13 T1–5",
             "5PM6JAQG6FNQ F38 T3–4", "8JRE1C4H4Z2W F33 T2/T5/T11",
             "YF0LXT1QSTGG F48 T1；F33 SL第二试", "YF0LXT1QSTGG F48 T3–5",
             "XP2SL33HT0D9 F33 T1/T3", "XP2SL33HT0D9 F33 T2–5",
             "YF0LXT1QSTGG F48 T1/T3–5；XP2SL33HT0D9 F33 T1–5"]
results = [{"id": p["id"], "state": "waiting", "reason": reason} for p, reason in zip(proposals, reasons)]
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261015-112917-strategy-proposal",
          "base": BASE, "runs": dispatch["runs"], "fixes": [], "skipped": [p["id"] for p in proposals],
          "merged": None, "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": [p["id"] for p in proposals], "implementation_domains": [],
          "proposal_results": results, "report": str(OUT / "report.md")}
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
now = dt.datetime.now().astimezone().isoformat(timespec="seconds")
intro = f"""# 静默猎手策略队列核验报告

记录时间：{now}。本批：20261015-112917-strategy-proposal。
角色：silent；六局均为A10。本批仅消费已领取的10个原提案，无research_request、implementation_request或proposal_repair；普通专题条件不匹配，不切换选题。开工工作树干净，执行git merge --no-edit main，结果Already up to date。完整base/当前HEAD：`{BASE}`。

本批结论：10项全部waiting，无新增源码、知识、参数、版本、提交或合入。已核实的现场机制足以支持原有限观察；未定位本批可新增且尚未覆盖的确定性实现差异。当前已有部分事实/审计实现，逐项的联合校准、来源归属或后继策略验证仍有缺口，不能据此关闭整个原提案。数值机制本身不以完整胜局为前提；只有调整选线、血价及成长优先级的结论需要另有对应反事实/后继验证。本批不把这种策略缺口用作机制失效的证据。

## 身份与原始证据

- 根learn.json只读本batch，角色/工作树/runs集合与本题一致；十个原Markdown逐份SHA与专用队列保存值相等，原件副本见original-proposals/，原队列字段见assigned-proposals.json。不新增重复id、不改原提案。
- 通过共用extract_evidence.py抽取八流，主六流见evidence/，runs与fight-plans见evidence-extra/。逐流source_size、每行offset/bytes/SHA/显式所属局、逐局计数及输出SHA全部保留，analyze.py重新seek原日志逐行核正文与SHA，合计8,274行通过；详见source-verification.json。原日志只读，没有把正文提及当局身份。
- 六局4,062状态、3,941决策、38个SL记录、6配置、33个run-plans、188个brain、6个runs记录；fight-plans在2,233,957字节冻结截点选到0行，不能外推原日志从来不存在。run-plans截点7,999,701字节选33行，使用run字段身份。
- 原始整流扫描分别发现states/decisions/brain坏JSON行2/2/1，共用入口拒收；不把这些无有效身份行归到本批。选中状态及runs角色/进阶全部复核为silent/A10。188个brain均为accepted Codex、gpt-6.1-sol/high，只说明这些历史脑题；runs中旧deepseek_calls计数字段不据此改写。
- 六份run-config及runs记录均带dirty；保留各自历史commit，不声称重建当时完整执行树或知识数据库。本批未读取其他角色知识、游戏二进制或网络，也未启动对局。

## 可重复的固定事实

target-state-projections.json保留1,180个目标房间快照，paired-decisions.json保存13条指定原决策。verify_facts.py按已核原行重算19项材料断言，全过（facts-command-v2.log、verified-facts.json）；这不是新增生产代码测试，tests仍为null。初版15项的输出另存facts-command.log，没有覆盖。

| 同完整指纹的观测窗口 | 旧/替换当轮净损HP | 旧/替换敌净扣HP | 对照决策原行 |
|---|---:|---:|---|
| 8JRE F33 T2 首/第三试 | 3 / 15 | 10 / 17 | 270216 / 270282 |
| YF F48 T1 第二/第三试 | 0 / 9 | 45 / 38 | 271309 / 271348 |
| XP F33 T3 首/第二试 | 9 / 14 | 24 / 27 | 271992 / 272040 |
| XP F33 T1 首/末试 | 2 / 10 | 25 / 34 | 271982 / 272195 |

这些对照仅用同名单且无换相的下一轮端点；敌净扣包含该窗口所有来源，不称攻击输出，不把整轮归给单个候选或单牌。四组同档读档仍按原局计样本，后续抽弃牌及随机落点未受控。YF F33第二次SL实胜余20（sl-attempts原929行）保留，不推一律禁止探索。末页零HP只表示净损封顶；YF末轮结算前44攻击/23挡/18HP差3，用结算前快照计算，不用结束页新显示55攻击倒算本轮入伤。

## 现有实现与消费者验证

九个相关源码叶与观测时live逐字节相同，实际live源码祖先均已核，见existing-source-readback.json及source-fragments/*.txt。候选审计9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、护栏审计66283dd9982bdd7f480da7a4d9bfefea0572a9ac、阶段快照aad2700abed6dff1d66e87fb36aaa6fedb39adf3、离线整轮接口e75438488df159b2e8e9d3458cf219b39aadd933仅按对应子范围引用。combat-plan本树最后同步提交0f63424e30fe1dbf3b70f8e6a6edf265e544e7f0不是live祖先，未用它作已实现凭据；实际live末次源码提交ec74a49ce41370c10540c795338cbe5eecb78846另核，当前两叶SHA相同。

运行原learner/audit-selection.ts（生产源码不改，固定冻结输入、不调LLM）。四局全输入退出0；DUZ和CA两局完整输入因共4条无decision_id的map/route-change记录真实退出1，原输入/错误保留。仅过滤这四条形成明确标注的有界子集，分别退出0；不冒认六局全输入均通过。六个有效输出共3,937条有ID动作、641候选片段、186个整轮端点及450个未知窗口；全部actual_full_candidate_result/actual_rollout_best仍null。整轮端点只是包含所有重规划的观测窗口，不是完整候选归属或独立校准。

消费者原输入与输出保存在consumer-inputs/*.json.gz及consumer-results/*.json.gz，SHA和退出码见consumer-results.json。材料脚本初次把map/route-change写成route-change的预检失败保存在consumer-precheck-failure.json；随后tsx CLI启动的两次EPERM/IPC失败及中止堆栈保存在consumer-ipc-failure/与ipc-failure-*.log，未当代码失败。改用现有Node --import tsx加载同一源码后才得到上述实际消费者结果，没有修改生产断言或依赖、没有提权。

## 逐项处置

"""
details = []
for p, loc, reason in zip(proposals, locations, reasons):
    details.append(f"### {p['id']} — waiting\n\n证据：{loc}。账本：{', '.join(p['ledger'])}。\n\n{reason}\n\n"
                   "预期行为与验证：沿用原提案的冻结状态/移动表/实际动作前缀逐步核数，优先补上述具体缺口；当前全部选项及排序保留。已证子项沿真实live源码定位，不因局部字段或接口存在登记整项duplicate。规则调整另按独立局/时间后移验证，不将同档SL跨训练/验证分组。回退：本批没有生产改动可回退，原件与CLI追加链保留。\n")
tail = """
## 交付与边界

十个原CLI id均列result.json的proposal_results，state=waiting且各有具体缺数据理由；无新代码提案、无implemented_commit，不登记shipped。proposal.md为本批统一处置文件，逐条链接原账本及证据，报告不是经验入库或大脑已采用的证明，也不关闭量化学习/策略父要求。账本只用根learner/ledger.py update追加本批proposal路径与追溯note，不重复增加已有support、不重写claim/首证/先验/进阶/证据/status/version。原shipped项不降为proposed；本批没有新增待登记游戏结论。

无源码提交，撤源码失败/恢复通过不适用；tsc/vitest/cases均null，未运行或冒报生产测试。没有live merge、eval版本、上线通知或提交号；工作树tracked状态保持干净，HEAD=base。不推送、不运行play、不改运维prompt。源码差异原件source-diff.patch为空；本批材料和脚本只在指定scratch目录。最终秘密扫描、CLI更新读回与工作树核验结果另见final-validation.json；其真实失败也必须保留。
"""
(OUT / "proposal.md").write_text(intro + "\n".join(details) + tail)
(OUT / "report.md").write_text(intro + "\n".join(details) + tail + "\n最终JSON见同目录result.json。\n")
linked = {}
for p in proposals:
    for ident in p["ledger"]:
        linked.setdefault(ident, []).append(p["id"])
updates = [{"id": ident, "by": "learner:strategy-proposal", "where": {"proposal": [str(OUT / "proposal.md")]},
            "note": "20261015-112917策略核验；原提案 " + ",".join(ids) +
                    " 均waiting；8274原行逐offset/bytes/SHA核、19固定事实及原消费者有界核验；缺口详本批report.md。仅补追溯，不新增support或改旧规则、首证、先验、状态、版本。"}
           for ident, ids in sorted(linked.items())]
(OUT / "ledger-updates.jsonl").write_text("".join(json.dumps(u, ensure_ascii=False) + "\n" for u in updates))
print(json.dumps({"report": str(OUT / "report.md"), "proposal": str(OUT / "proposal.md"),
                  "waiting": len(results), "ledger_link_updates": len(updates)}, ensure_ascii=False))

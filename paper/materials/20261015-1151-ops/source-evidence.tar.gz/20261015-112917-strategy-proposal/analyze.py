"""Verify frozen source bytes and project only the assigned Silent evidence."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
RUNS = json.loads((OUT / "dispatch.json").read_text())["runs"]
FLOORS = dict(zip(RUNS, ([27, 30], [38, 39], [13], [17, 33], [33, 48], [33])))
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(raw):
    return {p["power_id"]: p["amount"] for p in raw or []}


streams = {}
verification = []
for folder in ("evidence", "evidence-extra"):
    for manifest in json.loads((OUT / folder / "evidence-manifest.json").read_text()):
        stream = manifest["stream"]
        path = OUT / folder / (stream + ".evidence.jsonl")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest["output_sha256"]
        counts = Counter()
        rows = []
        source = Path("/home/dw/Projects/agent-sts2/logs") / (stream + ".jsonl")
        with source.open("rb") as original, path.open() as copied:
            for line in copied:
                item = json.loads(line)
                assert item["source"] == str(source)
                assert item["offset"] + item["bytes"] <= manifest["source_size"]
                original.seek(item["offset"])
                raw = original.read(item["bytes"])
                assert raw.endswith(b"\n")
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                assert extract.run_identity(item["row"]) == item["run_id"]
                assert item["run_id"] in RUNS
                if stream == "states":
                    run = item["row"]["state"].get("run", {})
                    assert run.get("character_id", "").lower() == "silent"
                    assert run.get("ascension") == 10
                if stream == "runs":
                    assert item["row"]["character"].lower() == "silent"
                    assert item["row"]["ascension"] == 10
                counts[item["run_id"]] += 1
                rows.append(item)
        assert dict((r, counts[r]) for r in RUNS) == manifest["counts"]
        verification.append({**manifest, "verified_raw_lines": sum(counts.values()),
                             "raw_bytes_sha_identity_and_counts": True})
        streams[stream] = rows

write("source-verification.json", verification)
projected = []
for item in streams["states"]:
    row = item["row"]
    state = row["state"]
    run = state.get("run", {})
    if run.get("floor") not in FLOORS[item["run_id"]]:
        continue
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    projected.append({
        "run": item["run_id"], "line": item["line"], "ts": row.get("observed_ts"),
        "floor": run.get("floor"), "turn": state.get("turn"), "screen": state.get("screen"),
        "hp": player.get("current_hp", run.get("current_hp")), "block": player.get("block"),
        "played": player.get("cards_played_this_turn"), "powers": powers(player.get("powers")),
        "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"), "hp": e.get("current_hp"),
                     "max_hp": e.get("max_hp"), "alive": e.get("is_alive"), "block": e.get("block"),
                     "move": e.get("move_id"), "powers": powers(e.get("powers")),
                     "attacks": [{"damage": a.get("damage"), "hits": a.get("hits"),
                                  "total": a.get("total_damage")} for a in e.get("intents", [])
                                 if a.get("intent_type") == "Attack"]}
                    for e in combat.get("enemies", [])],
    })
write("target-state-projections.json", projected)

targets = {270216, 270282, 270264, 271309, 271348, 271354, 271495, 271509,
           271992, 272040, 271982, 272195, 272076}
selected = [x for x in streams["decisions"] if x["line"] in targets]
write("paired-decisions.json", selected)

inputs = OUT / "consumer-inputs"
inputs.mkdir(exist_ok=True)
summary = {}
for run_id in RUNS:
    run = next(w["row"] for w in streams["runs"] if w["run_id"] == run_id)
    def source_rows(stream):
        return [{**w["row"], "_line": w["line"], "_offset": w["offset"]}
                for w in streams[stream] if w["run_id"] == run_id]
    states = source_rows("states")
    decisions = source_rows("decisions")
    missing = [r["_line"] for r in decisions if not r.get("decision_id")]
    input_data = {"run": run, "states": states, "decisions": decisions}
    (inputs / (run_id + ".json")).write_text(json.dumps(input_data, ensure_ascii=False) + "\n")
    summary[run_id] = {"run": run, "states": len(states), "decisions": len(decisions),
                       "missing_decision_id_lines": missing,
                       "decision_labels": dict(Counter(r.get("label") for r in decisions))}
write("analysis-summary.json", summary)
print(json.dumps({"verified_lines": sum(x["verified_raw_lines"] for x in verification),
                  "stream_counts": {x["stream"]: x["counts"] for x in verification},
                  "target_projections": len(projected), "paired_decisions": len(selected),
                  "missing_ids": {r: s["missing_decision_id_lines"] for r, s in summary.items()}},
                 ensure_ascii=False))

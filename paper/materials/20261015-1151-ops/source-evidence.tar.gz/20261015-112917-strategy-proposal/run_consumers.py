"""Read frozen inputs using the existing offline consumer, preserving full-input rejections."""
import gzip
import hashlib
import json
import os
import subprocess
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
os.environ["TMPDIR"] = str(OUT)
results = []


def execute(path, scope):
    target = OUT / "consumer-results" / (path.stem + ".audit.json")
    error = target.with_suffix(".stderr.log")
    with target.open("w") as stdout, error.open("w") as stderr:
        rc = subprocess.run(["nice", "-n", "10", str(Path.home() / ".local/node/bin/node"),
                             "--import", "./agent/node_modules/tsx/dist/loader.mjs",
                             "learner/audit-selection.ts", str(path)], cwd=ROOT,
                            stdout=stdout, stderr=stderr).returncode
    result = {"input": str(path) + ".gz", "scope": scope, "exit_code": rc,
              "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "output": str(target) + ".gz", "stderr": str(error)}
    if rc == 0:
        data = json.loads(target.read_text())
        assert all(s["actual_full_candidate_result"] is None and s["actual_rollout_best"] is None
                   for s in data["segments"])
        result.update({"run_id": data["run_id"], "segments": len(data["segments"]),
                       "observed_actions": len(data["observed_actions"]),
                       "observed_intervals": len(data["observed_intervals"]),
                       "turn_status": dict(Counter(t["status"] for t in data["observed_turns"])),
                       "all_full_candidate_results_unknown": True})
    for file in (path, target):
        with file.open("rb") as original, gzip.open(str(file) + ".gz", "wb") as compressed:
            while chunk := original.read(1024 * 1024):
                compressed.write(chunk)
        file.unlink()
    results.append(result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return rc


(OUT / "consumer-results").mkdir(exist_ok=True)
for run_id in json.loads((OUT / "dispatch.json").read_text())["runs"]:
    path = OUT / "consumer-inputs" / (run_id + ".json")
    data = json.loads(path.read_text())
    missing = [r for r in data["decisions"] if not r.get("decision_id")]
    if missing:
        assert all(r.get("label") == "map/route-change" for r in missing), [
            {"line": r.get("_line"), "label": r.get("label")} for r in missing]
    execute(path, "全部冻结原始输入")
    if missing:
        subset = path.with_name(run_id + ".with-ids-subset.json")
        data["decisions"] = [r for r in data["decisions"] if r.get("decision_id")]
        subset.write_text(json.dumps(data, ensure_ascii=False) + "\n")
        assert execute(subset, "仅剔除无decision_id的route-change行；有界子集，不代表完整输入通过") == 0

(OUT / "consumer-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")

# 静默策略提案：本批十项核验报告

记录时间：2026-10-15T11:49:17+08:00。task=strategy-proposal；character=silent；batch=20261015-114302-strategy-proposal。

## 结论

十项均为waiting。本批没有新增能补齐原提案缺口的对局证据，也未发现可由已核帧直接落实、而当前源码仍漏掉的新策略差值。已有窄实现保留，宽提案的缺口不据此关闭。不改源码或知识，不新增重复提案id，不宣称经验已经入库、大脑采用、父要求完成或游戏收益。

base=c0c0adb397e51644ca6251e86c16ffabcb28ae5f；fixes=[]；merged=null；没有提交、新版本、shipped或规则通知。tsc/vitest/cases均为null，源码撤掉失败/恢复通过不适用。37项事实断言和消费者读回是本批的数据核验，不是生产代码自测。

## 派发身份与范围

开工git status为空，HEAD为上述完整40位；README、最新STATE-2026-10-15、decision-log末尾、learning-protocol和learning-code-proposals已读。只读根learn.json本批，对应task/character/worktree均相符、state=running、reason=proposal、十个proposal_ids。没有research_request、implementation_request或proposal_repair；普通专题请求仍绑定20261010旧批，因此没有承接专题或读取别的专题替代身份。按普通任务执行git merge --no-edit main，Already up to date，base未变。

派发的十个原提案逐项读取，保存路径及SHA256全部匹配，详见dispatched-proposals.json与proposal-verification.json。只处理这十项，不扩选队列，不改原提案/旧复盘。没有子agent，没有读取其他角色私有知识，没有预训练事实补充。

六个runs.jsonl原行及全部3432状态均核为SILENT/A10：VLZ6CCT8AQ0A, 8JRE1C4H4Z2W, CA5KE8GFJ9X2, 5PM6JAQG6FNQ, 61E2QS63Y9WU, DUZUBAJ3A8GP。独立局数为6，SL尝试不增加独立样本数。旧代码均带dirty，不能从提交号重建完整当时运行树/知识/随机池；六局均是发现或回归资料，不冒称时间后置盲测。

## 原始证据

经共用learner/extract_evidence.py按显式run_id/state.run_id/run/fingerprint.run提取八流，不以正文提及归属，冲突身份拒收。每流保存source_size、逐行offset/bytes/SHA与逐局计数。随后逐行seek回原日志检查原字节、SHA及JSON，共6995行全部通过；输出为evidence/evidence-manifest.json和raw-readback-verification.json。

| 流 | 冻结source_size字节 | 所属行数 |
|---|---:|---:|
| states | 13006237808 | 3432 |
| decisions | 1554240164 | 3306 |
| sl-attempts | 40310132 | 29 |
| run-config | 1742457 | 6 |
| run-plans | 7999701 | 33 |
| brain | 564902527 | 183 |
| runs | 333707 | 6 |
| fight-plans | 2233957 | 0 |

states/decisions全源各2行无效JSON，brain全源1行；这不是归属于本六局的缺行判定。fight-plans在此截点六局均0行，只表示本次未选到，不能说原日志缺失。没有重验旧run-plans截点或覆盖旧报告/初稿。

与上一轮20261014-211304的已存八流输出逐SHA比较，全部选中原行完全相同。日志全局增长不等于这些六局新增证据。37项固定原帧事实断言本次实际运行通过：神化前后与后抽升级、药水实能量/HP、覆甲0、来袭59、蚌增力/弱、族母负敏捷与毒、胧光两实体端点、甲虫临减恢复及SL同盘差值等。每项原行号和断言保存在fact-checks.json。

## 当前离线消费者

本批从已核原行构造gzip单局输入，保留真实decision_id、observed_ts、fingerprint、物理_line及SHA，不造身份。用当前base的learner/lib/selection-execution.ts离线执行，不调用LLM/网络、不启动游戏、不读取刷新知识JSON。输入、完整错误、范围与输出保存在consumer-input-manifest.json、consumer-readback.json和六组consumer-input/output文件。

| 局 | 有ID动作 | 候选片段 | 相邻端点 | 终页端点 | 整轮端点 | 未知轮 |
|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | 599 | 77 | 189 | 1 | 28 | 68 |

VLZ/8JRE/5PM完整输入被接受；CA5原267143、61E原267517、DUZU原268789/268818/268864缺decision_id，完整输入真实拒收，错误留存。只剔除这5个无ID行才取得有界子集；物理行缺口及原行保留，不能把子集说成完整输入成功。

合计3301个有ID动作、476候选片段、859相邻端点、4终页端点、121整轮端点、413未知轮。六局本次输出解压后逐SHA与上一轮完全相同。actual_full_candidate_result全部null是现有消费者的归属认证边界，不证明没有动作、没有净收益或游戏策略错误。

8JRE F33首/第三试T2原指纹相同，原SL预测0/24与5/24不同；实端点分别玩家−3/−15、敌血−10/−17，仅确认同盘多付12血、多扣7敌血。270264护栏在rationale而非结构hp_guard，结构计数0不等于没触发。5PM F39末试T2冒泡耗能5→4、无毒失落35血不变；整轮结果不全归该卡。61E F17两防御各3且毒端点67→34，F23 T4幻象仍余2血。DUZU F30前三尝试predicted_death、末次died，不能都叫执行到死。以上不提供未选整战胜线。

## 现有源码及live边界

本次只读live快照=fba193dfe31844e1dbde9f2ad7174427fcd446dc。18个相关源码叶中14个blob相同，card-model.ts/rollout-live.ts/sl/explore.ts/potion-mc.ts四个不同；已逐diff确认仅既有Dai/Roy注释文字，仍保留原字节差异。source-verification.json及base-live-source-difference.patch保存base/live blob与SHA、路径最后提交及祖先判断。曾猜错的执行/观测文件路径已改用rg定位真实路径，不据不存在的猜测路径推断功能缺失。

已核live祖先：3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17（神化参考），b2805be4ba44b7375c7908d873889372cc3cfe6c（已观察萎靡升级），05cd292c6f01bb31e406473d3a9843e659d62b93（三阶段选择快照），a8b1f8be153fe4f3a34146117546c2178f2e446b（护栏/SL局部审计），cf72bd21148059f111f760cc98a727369e34a47e（离线消费者）。它们是旧窄项的来源，不是本批提交，不据此标整项implemented/duplicate。

当前神化仅覆盖限定已测牌表；属性组合、未知抽牌仍保留unknown，actual_cast_this_fight=null。selection_dispatch仅记录单动作回执、whole_plan_executed=null；离线整轮窗口不认证整个候选。此次核验没有将null消除为虚构的实际执行数据。

## 逐项处置

| 原id | 状态 | 缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺实际施放身份贯穿抽牌、选牌、药水及SL的生产消费者校准和未覆盖属性交互证据；已有窄升级传播不足关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的分阶段MC配对及候选稳定性曲线；不能据707ms改预算、留药或固定目标。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化主项仍缺实际施放持续身份和未覆盖升级交互校准；经验链接及既有局部源码不构成完整live实现。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五条经验的属性组合、升级联动、期限及战斗/路线/休息消费者联合校准；若干原帧吻合不足认证整个复合项。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有候选快照、单动作回执和本局44个整轮端点，但缺跨重规划持续候选身份及全过程生产归属校准；端点不认证完整候选。 |
| silent-proposal-49632bc4878fb597 | waiting | 本局无正敏捷实测，缺力量、正负敏捷、虚弱与独立成长四路径的联合生产校准和独立验证；不能用单一步法提交关闭复合项。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、构筑、药水和完整抽序下不同启动顺序的整战配对及可复现收益函数；局部空打代价不足拟合启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP、构筑和完整抽序下的SL整战比较及另一可核完整线路；负敏捷/毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10逐实体召唤、复现、退场、成长的完整生产校准及另一focus的整战后继；旧召唤子项不能证明目标排序收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕期限及恢复成长全链的生产校准与同抽换序完整后继；四次失败不足拟合排序血价或固定杀序。 |

逐项证据局号/层/回合、既有账本id、原Markdown/SHA、反例、现状与预期行为、后续验证及回退见本批proposal.md。当前条件不足以新增预算常量、留药价、护栏/SL阈值或固定启动/目标顺序。相同推演仍并列，现有选项和角色行为保持。

## 记录与验收

26个既有静默账本条目仅经根learner/ledger.py update追加by=learner:strategy-proposal、本批提案/报告链接与具体核验说明。不新增相同历史证据，不改claim/evidence/first_run/asc/prior/status/version/shipped_at；已有proposed及旧shipped历史均保留，不把旧shipped倒改为本批proposed。此次无新账本项需要设置proposed，不标shipped。CLI输入、输出与读回另存ledger-updates.jsonl、ledger-update.log、ledger-update-readback.json。

专用队列、learn.json、根研究请求不手改，十项proposal_results交既有调度器接续。未启动live合入流程、未写eval版本/decision-log上线或规则双通知；没有源码修改，不制造生产测试通过或源码负控。工作树HEAD保持base，git status/diff为空，scratch按既有忽略规则保留。

本批没有新生产代码失败。旧来源报告/初稿/失败均原样保留；本批消费者对缺ID完整输入的真实拒绝与有界子集区别已明确保存。数据核验脚本复用来源、SHA和仅路径调整记helper-provenance.json；逐项核验表复用及本次重新核验记proposal-document-provenance.json。

交运维proposal：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-114302/learner/runs/20261015-114307-b06b6c71-e7c9-44be-81b7-76d0ccefa9a1-strategy-proposal/proposal.md

report：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-114302/learner/runs/20261015-114307-b06b6c71-e7c9-44be-81b7-76d0ccefa9a1-strategy-proposal/report.md

最终验收：26条本批CLI追加已实际读回，原claim/evidence/first_run/asc/prior/status/version/shipped_at逐项保持；根learn.json本批身份及十id集合再次一致。工作树status为空、HEAD=base、git diff为0。报告、提案、最终JSON及账本更新输入的gitleaks redacted扫描退出0，无泄漏；该扫描不是源码测试。最终机械回执见final-verification.json。

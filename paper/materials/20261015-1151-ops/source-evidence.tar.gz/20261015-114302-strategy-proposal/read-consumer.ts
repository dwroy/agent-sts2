import { readFileSync, writeFileSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { auditSelectionExecution } from '/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-114302/learner/lib/selection-execution.ts';

const scratch = '/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-114302/learner/runs/20261015-114307-b06b6c71-e7c9-44be-81b7-76d0ccefa9a1-strategy-proposal';
const inputs = JSON.parse(readFileSync(`${scratch}/consumer-input-manifest.json`, 'utf8'));
const summaries = [];
for (const item of inputs) {
  const input = JSON.parse(gunzipSync(readFileSync(item.path)).toString('utf8'));
  let fullError: string | null = null;
  let audit: ReturnType<typeof auditSelectionExecution> | null = null;
  let scope = 'full';
  try { audit = auditSelectionExecution(input); }
  catch (error) { fullError = String(error); }
  if (fullError) {
    scope = 'existing_decision_ids_only';
    input.decisions = input.decisions.filter((row: Record<string, unknown>) => row.decision_id);
    try { audit = auditSelectionExecution(input); }
    catch (error) {
      summaries.push({ run_id: item.run_id, full_error: fullError, bounded_error: String(error), certified_full_candidates: null });
      continue;
    }
  }
  if (!audit) throw new Error('消费者无结果');
  const actions = audit.observed_actions;
  const counts = {
    actions: actions.length,
    segments: audit.segments.length,
    observed_intervals: actions.filter((x) => x.observed_interval.status === 'observed_endpoints').length,
    terminal_intervals: actions.filter((x) => x.terminal_observation?.status === 'observed_terminal_endpoints').length,
    observed_turn_endpoints: audit.observed_turns.filter((x) => x.status === 'observed_turn_endpoints').length,
    unknown_turns: audit.observed_turns.filter((x) => x.status === 'unknown').length,
    certified_full_candidates: audit.segments.filter((x) => x.actual_full_candidate_result !== null).length,
    hp_guard_segments: audit.segments.filter((x) => x.predictions.hp_guard !== null).length,
  };
  writeFileSync(`${scratch}/${item.run_id}.consumer-output.json.gz`, gzipSync(JSON.stringify(audit)));
  summaries.push({run_id: item.run_id, scope, full_error: fullError, excluded_lines: item.missing_decision_id_lines, ...counts});
}
writeFileSync(`${scratch}/consumer-readback.json`, JSON.stringify(summaries, null, 2) + '\n');
process.stdout.write(JSON.stringify(summaries, null, 2) + '\n');

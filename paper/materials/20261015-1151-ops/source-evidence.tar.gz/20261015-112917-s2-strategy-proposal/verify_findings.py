import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
checks = []


def check(name, actual, expected):
    checks.append({"name": name, "actual": actual, "expected": expected, "ok": actual == expected})


def data(run):
    return json.loads((OUT / (run + ".audit-input.json")).read_text())


def audit(run):
    return json.loads((OUT / (run + ".audit.json")).read_text())


def state(run, line):
    return next(x["state"] for x in data(run)["states"] if x["_line"] == line)


def decision(run, line):
    return next(x for x in data(run)["decisions"] if x["_line"] == line)


def power(rows, key):
    return next((x["amount"] for x in rows if x["power_id"] == key), None)


def window(run, attempt, turn):
    return next(x for x in audit(run)["observed_turns"]
                if x["floor"] == 17 and x["attempt"] == attempt and x["turn"] == turn)


def delta(row):
    f = row["facts"]
    return [-f["player_hp_delta"], -f["enemy_hp_changes"][0]["hp_delta"]]


a, k, y, v = "751FN9QM9MHQ", "KEN58SH9SLZ6", "YQL8RZ8BWN1E", "KV0JHNJCKXLS"
for original, replacement in [(272434, 272575), (272531, 272652), (272483, 272820)]:
    check(f"751同指纹{original}/{replacement}", decision(a, original)["fingerprint"], decision(a, replacement)["fingerprint"])
for attempt, turn, expected in [(1, 2, [13, 9]), (3, 2, [18, 18]),
                                 (2, 7, [13, 12]), (4, 7, [23, 18]),
                                 (1, 13, [8, 17]), (6, 13, [2, 11])]:
    check(f"751尝试{attempt}T{turn}净损/敌净扣", delta(window(a, attempt, turn)), expected)
for original, replacement in [(274505, 274568), (274484, 274601)]:
    check(f"KEN同指纹{original}/{replacement}", decision(k, original)["fingerprint"], decision(k, replacement)["fingerprint"])
for attempt, turn, expected in [(4, 10, [15, 2]), (5, 10, [21, 4]),
                                 (4, 5, [7, 1]), (6, 5, [5, 2])]:
    check(f"KEN尝试{attempt}T{turn}净损/敌净扣", delta(window(k, attempt, turn)), expected)
for line, expected in [(280572, 2), (280689, None), (280701, None)]:
    check(f"KEN状态{line}敏捷", power(state(k, line)["combat"]["player"]["powers"], "DEXTERITY_POWER"), expected)
footwork_casts = []
for row in data(k)["decisions"]:
    if row.get("sl_attempt") != 6 or row["chosen"].get("action") != "play_card":
        continue
    if ((row.get("expect") or {}).get("card") or {}).get("id") == "FOOTWORK":
        footwork_casts.append({"line": row["_line"], "turn": row["turn"]})
check("KEN末试步法实际请求回合", [x["turn"] for x in footwork_casts], [9])
check("KEN T10成对B2差", decision(k, 274568)["sl_explore"]["b2"],
      {"original": .385, "replacement": .127, "diff": -.2583, "se": .0132})
f = decision(a, 272361)["questions"]["plan"]["criteria"]
wet, dry, dry_now = [json.loads(f[key]) for key in ("plan2", "plan5", "plan3")]
check("751有药/整战无药当轮损血", [wet["hp_lost"], dry["hp_lost"]], [8, 8])
check("751有药/整战无药牌伤", [wet["damage_dealt"], dry["damage_dealt"]], [26, 16])
check("751有药/整战无药五轮胜数文本", ["8/8" in wet["rollout"], "8/8" in dry["rollout"]], [True, True])
check("751整战无药明确标记", "no_potion_fight" in dry, True)
check("751仅当轮不喝后续仍喝", "7/8" in dry_now["potion_cost"], True)
check("751肌肉药表缺失", "table did not load" in wet["potion_cost"], True)
for line, expected in [(280160, [26, 13, 41, 2]), (280161, [26, 13, 41, 8])]:
    c = state(y, line)["combat"]
    check(f"YQL状态{line}血/挡/自爆/毒", [c["player"]["current_hp"], c["player"]["block"],
          c["enemies"][0]["intents"][0]["damage"], power(c["enemies"][0]["powers"], "POISON_POWER")], expected)
    check(f"YQL状态{line}巨兽占位上限", c["enemies"][0]["max_hp"], 999999999)
check("KV T5同指纹", decision(v, 273400)["fingerprint"], decision(v, 273450)["fingerprint"])
for before, after, expected in [(279460, 279465, [0, 36, 20]), (279511, 279515, [0, 29, 13])]:
    c, d = state(v, before)["combat"], state(v, after)["combat"]
    check(f"KV状态{before}/{after}损血/净扣/后毒", [c["player"]["current_hp"] - d["player"]["current_hp"],
          c["enemies"][0]["current_hp"] - d["enemies"][0]["current_hp"],
          power(d["enemies"][0]["powers"], "POISON_POWER")], expected)
    check(f"KV状态{before}到{after}源帧完整", len([x for x in data(v)["states"] if before <= x["_line"] <= after]), after-before+1)
consumptions = []
for dl, before, after, potion, slot in [(274131, 280206, 280207, "ATTACK_POTION", 0),
                                      (274156, 280232, 280233, "STABLE_SERUM", 0),
                                      (274185, 280262, 280263, "SPEED_POTION", 0),
                                      (274235, 280313, 280314, "WEAK_POTION", 1),
                                      (274237, 280315, 280316, "ATTACK_POTION", 0),
                                      (274267, 280348, 280349, "GLOWWATER_POTION", 1),
                                      (274272, 280354, 280355, "SKILL_POTION", 0)]:
    b, e = state(k, before), state(k, after)
    check(f"KEN药槽{dl}请求", decision(k, dl)["chosen"].get("option_index"), slot)
    check(f"KEN药槽{dl}前后ID", [b["run"]["potions"][slot]["potion_id"], e["run"]["potions"][slot]["potion_id"]], [potion, None])
    consumptions.append({"decision": dl, "before_state": before, "after_state": after, "potion": potion, "slot": slot})
check("KEN主动饮用数", sum(x["chosen"].get("action") == "use_potion" for x in data(k)["decisions"]), 7)
check("KEN主动弃药数", sum(x["chosen"].get("action") == "discard_potion" for x in data(k)["decisions"]), 0)
starts = [x for x in data(k)["decisions"] if x.get("floor") == 17 and x.get("turn") == 1 and x.get("sl_attempt") is not None]
for attempt in range(1, 7):
    row = next(x for x in starts if x["sl_attempt"] == attempt)
    frame = next(x["state"] for x in data(k)["states"] if x["observed_ts"] == row["observed_ts"] and x["fingerprint"] == row["fingerprint"])
    check(f"KEN尝试{attempt}入口HP/空药", [frame["combat"]["player"]["current_hp"], all(not x["occupied"] for x in frame["run"]["potions"])], [75, True])
summary = json.loads((OUT / "audit-summary.json").read_text())["counts"]
check("六局已核整轮端点数", sum(x["status_counts"].get("observed_turn_endpoints", 0) for x in summary), 379)
check("六局完整候选归属已知数", sum(x["actual_full_candidate_known"] for x in summary), 0)
result = {"scope": "冻结证据断言，非源码测试", "checks": checks, "consumptions": consumptions,
          "count": len(checks), "passed": sum(x["ok"] for x in checks), "all_passed": all(x["ok"] for x in checks)}
(OUT / "finding-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ("scope", "count", "passed", "all_passed")}, ensure_ascii=False))
for row in checks:
    if not row["ok"]:
        print(json.dumps(row, ensure_ascii=False))
raise SystemExit(0 if result["all_passed"] else 1)

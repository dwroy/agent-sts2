# 静默猎手策略复核报告

本批10项均保留 waiting。复核确认若干诊断子项已经有 live 源码；尚无数据支持关闭原宽提案、制定统一血价/留药/SL准入规则，或宣称实际策略收益。本批没有改动生产源码、任务模板、经验库或知识数据，没有提交、合入、发布号或shipped登记。

## 身份与基线

- task=strategy-proposal；character=silent；batch=20261015-112917-s2-strategy-proposal。
- learn.json 仅选择对应批次：reason=proposal，worktree匹配，本批proposal_ids恰为10项；无research_request、implementation_request或proposal_repair。普通专题条件不匹配；没有读取其他专题正文或领取其他队列项。
- 初始git status干净；`git merge --no-edit main` 输出 Already up to date。实际完整base与HEAD均为 `5b45cda3ac1bcba0cd93b527f571a4dbfb8bf45d`。
- 六个派发局：751FN9QM9MHQ、KV0JHNJCKXLS、YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN、KEN58SH9SLZ6。runs.jsonl逐项均为SILENT/A10，不把历史脑引擎混合局作为纯Codex战绩。只研究本批/本角色证据，不使用预训练游戏知识。
- proposal-inputs.json保留十项原add/最新update及指纹；原提案全部SHA相符。linked-experiences.json保留关联本角色经验以查冲突，未把其后期聚合或其他局计数当本批实核证据。

## 原日志冻结与复核

用本树 learner/extract_evidence.py 共用入口抽取八流，按run、run_id、state.run_id、fingerprint.run核身份；没有按正文提及匹配。总8,444条：4,167状态、4,071决策、43尝试、6配置、21计划、130脑记录、6终局。每行原source/line/offset/bytes/SHA保留在evidence，raw-verification.json记录逐行seek原日志、字节/SHA、JSON正文及身份复核全部通过；原日志只读。

| 流 | 冻结source_size（字节） | 选中条数 | 扫描全流无效JSON行数 |
|---|---:|---:|---:|
| states | 13000629129 | 4167 | 2 |
| decisions | 1551072356 | 4071 | 2 |
| sl-attempts | 40279514 | 43 | 0 |
| run-config | 1742457 | 6 | 0 |
| run-plans | 7999701 | 21 | 0 |
| brain | 563810088 | 130 | 1 |
| runs | 333230 | 6 | 0 |
| fight-plans | 2233957 | 0 | 0 |

所有流本次不完整尾行数均0。全流的2/2/1条无效JSON不擅自归属本批；未据此断言本批缺帧。fight-plans在本次2,233,957字节截点选中0条，仅说明该截点无所属记录；run-plans按顶层run实际取到21条，未使用旧截点0行稿或覆盖旧报告。evidence-manifest.json另存逐局计数和每个抽取文件SHA。

## 当前源码覆盖，及其限制

只读live在核验时的实际HEAD为 `fba193dfe31844e1dbde9f2ad7174427fcd446dc`。下表各源码提交均实核为该live祖先，10个叶与本树字节相同，explore仅3处历史注释文字差，补丁保存在live-comment-difference.patch。此表证明源码存在，不证明自然模型已消费、整轮完成或策略收益。

| 源码叶 | live祖先中的来源提交 | 本树与该live |
|---|---|---|
| `agent/src/reflex/silent-sl-comparison.ts` | `66283dd9982bdd7f480da7a4d9bfefea0572a9ac` | 相同 |
| `agent/src/reflex/silent-held-loss.ts` | `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb` | 相同 |
| `agent/src/reflex/silent-potion-reference.ts` | `04921bd785ac6838066522f91ea0bb6ab95cb6a1` | 相同 |
| `agent/src/reflex/silent-giant-potion.ts` | `40168f4a903ae1d8c48bd03006f8fea19fd3aa3c` | 相同 |
| `agent/src/reflex/silent-selection-audit.ts` | `66283dd9982bdd7f480da7a4d9bfefea0572a9ac` | 相同 |
| `agent/src/reflex/silent-selection-dispatch.ts` | `bade647f9fe4c9103b40e2f26b26296692ad24b7` | 相同 |
| `agent/src/sl/attempts.ts` | `6cd2dfea0c0e9e6b932fe5ea997e3c7c854da336` | 相同 |
| `agent/src/sl/explore.ts` | `ae04fc3582680eb856177d720f2ef30b8339517a` | 仅3处Roy/Dai历史注释差，原差异保留 |
| `learner/lib/selection-execution.ts` | `02c4e13ac8e159b82ee35a965ac788a0a029ce5a` | 相同 |
| `learner/lib/selection-observation.ts` | `8698c581dac6c7e957f50a381586960a6d0c9b57` | 相同 |
| `learner/lib/selection-turn.ts` | `9b87d54f097d84521152e6cca8d6072af8140394` | 相同 |

- silent-held-loss：分列总损血、持牌来源、弃牌未决与未知牌，不把保守持牌数当必然实损。
- silent-potion-reference：holdHp=null仍为未知，分当轮无药和已有抽样中的整战无药参考。
- silent-sl-comparison、selection-audit/dispatch：保留候选预测、SL差、动作请求与回执；actual_turn/actual_turn_result仍为null。completed或pending均不能证明整线执行。
- 巨兽阶段与毒药事实已有展示；explore.enemyHpLeft/anchorRank仍按历史最长存活、原显示HP等排序。没有把占位血当本体进度来宣称收益；本批不改排序。
- learner/lib/selection-*为已有离线证据消费者，可核已记录端点；不在线控制动作、不认证候选因果，不用其输出填模拟或反事实。

## 本批重新核实的支持与反例

### 751FN9QM9MHQ

F17：T2第1/3试同指纹（decisions272434/272575），玩家63→50/45、敌186→177/168，即净损13→18、敌净扣9→18；B2 0.195→0.193。T7第2/4试同指纹（272531/272652），玩家45→32/22、敌121→109/103，净损13→23、敌净扣12→18；B2 0.103→0.013。两边题面保守血价19/29与实盘13/23分开，不把都少6误作换线省血。T13第1/6试同指纹（272483/272820），净损8→2、敌净扣17→11。三组状态路径均完整。六试全败，同局重试不算六个独立验证局。账本silent-0079/0176。

F13 T3 decisions272361：有药plan2/整战无药plan5均预测损8、五轮8/8结束，牌伤26/16，平均存活样本终结回合文本2.3/2.9；plan3只是当轮不喝，后续7/8样本仍喝。肌肉药成本0明确源于表未加载；实际喝药分支没有提供未喝/留药至boss的实盘反事实。账本silent-0019等。该五轮预测不是本批重新跑模拟或无药实胜。

### KV0JHNJCKXLS

F33第4/5试T5同指纹（273400/273450）。原帧279460→279465为敌334→298、后毒20，279511→279515为334→305、后毒13，两者玩家始终30，净扣36→29而无保血收益。完整保留T5结束请求后两次诅咒选择，再进入T6；现有离线整轮工具因最后动作是选择、不是end_turn，严格留turn_end_unverified。这里有可核的原帧端点，不声称没有原日志；也不靠放松工具来认证完整候选。后轮动作继续改变，没有单步整战因果、独立回血毛伤/路线/休息反事实。账本silent-0102/0019/0020。

### 巨兽三局

YQL8RZ8BWN1E F17末试T10，decisions274087、states280160→280161：残壳毒2→8，而玩家26血、13挡、自爆41、残壳HP999999999均不变。26+13<41与实际死亡截断0分列；新增6毒不是本体进度或减伤6。sl-attempts958—963六试均败，前五判死未结算不伪造实死。L9SGRBB5R698 F17 attempts679—684，T14/T13存在占位血；PU80F84P6HPN attempts715—719，前两次同T17占位HP999999989/999999981，第5次实胜余2。PU胜线为必要反例，不能将失败尝试当该构筑必输，也没有新排序的受控回放证明胜因。账本silent-0017/0250等。提前用药、不用药和阶段排序的受控整战仍缺。

### KEN58SH9SLZ6

F17第4/5试T10，decisions274505/274568指纹相同；原帧280588→280592与280651→280655为玩家37→22/16、敌82→80/78，净损15→21只多敌净扣2。原B2 0.385→0.127、差−0.2583、se0.0132。第4/6试T5同指纹（274484/274601），净损7→5、敌净扣1→2，但末试随后重问追加小刀；步法请求由T5推迟至T9，T8两张防御只有5/10挡且无敏捷。此反例排除仅按省血排序；也不能把多6血/2伤定成通用禁止条件。账本silent-0079/0021/0125/0005/0176。

F3T2/F4T1/F5T2/F11T1T2/F15T1共七次请求（274131/274156/274185/274235/274237/274267/274272）及原药槽前后ID均核：攻击、稳定血清、速度、虚弱、攻击、发光水、技能药，共7饮用、0主动丢弃。六次F17入口均75血空药。现有离线工具因这些非SL走廊的sl_attempt=null而不连接动作端点，七次potion observed_interval均unknown；本批逐槽原帧核验不被该保守留空否定，但也不冒称自动消费者已核完整收益。随机选牌和发光水后的实际重问不能归给药水中位示例。缺F15不用/留药的完整支线。账本silent-0019。

## 离线消费者与证据断言

- prepare_evidence.py逐行核原字节并准备六个冻结输入；状态仅裁去离线工具不读取的顶层字段，完整原始行保存在evidence，原_line与SHA不改。按原层号限定：751 F13/17、KV F33、YQL/L9/PU F17、KEN F3/4/5/11/15/17。无decision_id的1条元数据另存audit-input-exclusions.json，不作为动作，不伪造编号。
- 原有 `node --import ./agent/node_modules/tsx/dist/loader.mjs learner/audit-selection.ts` 六局逐个nice运行，均exit0，未改该工具、未接网络/LLM/游戏。566个选线片段、495个窗口中379个端点可核、116个未知；完整候选归属已知数0。每局原输入、输出、stderr和退出码均保存。
- verify_findings.py核59个固定数据断言，59/59通过；包括同指纹、三组751血价、KEN双向取舍/步法窗口、KV差额、YQL药后不减自爆和KEN七槽变化。详见finding-verification.json。这些是证据校验，不是tsc/vitest，也不是整战反事实或收益测试。
- 全部准备过程失败/修正留preparation-notes.md：一次scratch定位错误导致rc1后修正重跑，未把准备失败当源码失败；口头8,228计数亦已纠正为8,444。源日志、原提案及早期失败均保留。

## 逐项处置与后续数据要求

**silent-proposal-366288801d9150d9 — waiting**

751 F17 T2/T7/T13同盘血价已核；缺跨抽弃续问的完整候选兑现、同后继整战对照及独立验证，不拟额外失血准入阈值。

关联账本：silent-0079, silent-0176；原提案与验证/预期/回退详见proposal.md第1项。

**silent-proposal-85929bdfc8a3fc1b — waiting**

持牌保守项和持有价值未知已有源码展示；缺751 F13 T3无药/留药至boss的完整分支及弃牌后整线兑现，不能由缺表成本0拟合留药规则。

关联账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176；原提案与验证/预期/回退详见proposal.md第2项。

**silent-proposal-efd9f83ee9e1a6dc — waiting**

原经验与751局部同盘成本一致；候选预测及单动作回执不等于完整实果，六次同局均败且无受控后继与独立校准。

关联账本：silent-0079, silent-0176；原提案与验证/预期/回退详见proposal.md第3项。

**silent-proposal-131042659448ae74 — waiting**

现有诊断只覆盖持牌/药值等子项；缺逐源伤害、能力兑现、抽弃重规划后完整归属及跨战无药对照，不能将子项当整项完成。

关联账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176；原提案与验证/预期/回退详见proposal.md第4项。

**silent-proposal-990f054036609447 — waiting**

KV F33 T5同盘删毒净扣36→29且都零损已核；诅咒选择跨轮使现有整轮工具留未知，缺完整候选归属、受控后继及路线休息反事实。

关联账本：silent-0102, silent-0019, silent-0020；原提案与验证/预期/回退详见proposal.md第5项。

**silent-proposal-e18d3f18e6cac2a0 — waiting**

巨兽阶段展示已有，SL仍按原最长存活/占位HP排序；缺新排序的受控完整后继、资源比较及结局校准，不能据阶段指标替换参考路径。

关联账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046；原提案与验证/预期/回退详见proposal.md第6项。

**silent-proposal-9733bb80f445aeae — waiting**

YQL F17 T10残壳毒2→8而HP26/挡13/来袭41不变已核；缺提前喝、不喝、留药以及阶段排序的整战对照。

关联账本：silent-0017, silent-0019, silent-0020, silent-0250；原提案与验证/预期/回退详见proposal.md第7项。

**silent-proposal-c51468c5e8ba6668 — waiting**

KEN七次药槽耗用和六次75血空栏入口已核；原hallway动作sl_attempt为空导致现有审计不连端点，缺随机选牌/发光水后完整收益归属与F15留药分支。

关联账本：silent-0019；原提案与验证/预期/回退详见proposal.md第8项。

**silent-proposal-86a7db08d1a31976 — waiting**

KEN F17 T10多损6仅多扣2、T5省2但步法延至T9的反向取舍均已核；缺完整逐源兑现、保持其余后继一致的整战及独立验证。

关联账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176；原提案与验证/预期/回退详见proposal.md第9项。

**silent-proposal-e282a9131b99129a — waiting**

KEN原经验及双向成本一致；六次重试相关，跨重问的完整候选归属与受控整战/后期独立验证不足，不能拟统一血价或关闭原提案。

关联账本：silent-0021, silent-0079, silent-0125, silent-0176；原提案与验证/预期/回退详见proposal.md第10项。

所有原提案均保留待新局，不新增重复id、不把来源复盘或经验再写一遍。若后续拟合，按独立局/时间划分训练与验证，本批局只作冻结核验；相关SL不拆分到训练/留出。没有借另一个角色或未观察进阶补数据。未发现需改旧知识结论的新反证；相反取舍及未知均明确保留，供ops接续，不伪称watcher或Roy已读/确认。

## 记录、测试与上线

仅经根目录ledger.py update追加本批追溯链接与等待理由；16个已有账本均已有shipped历史，本批不回退其status、不重写claim/首证/prior/version/shipped_at、不追加重复证据、不将宽代码提案等同于经验历史状态。CLI回执和保护字段读回单独保存；不自行改专用提案队列，proposal_results交宿主消费。

无新游戏知识或源码更改，故fixes=[]、merged=null、tests={tsc:null,vitest:null,cases:null}；撤源码失败/恢复通过不适用，未运行生产测试、不引用旧绿、未造eval版本或shipped。没有源码提交，提交前gitleaks与live合入测试不适用。没有live写入、对局重启、play、运维prompt或未授权文件改动。Git diff --binary为空，工作树最终须干净，实际HEAD保持base。只报告本批处置完成，不关闭学习父要求或宣称经验消费者已采用新策略。

交运维：本目录proposal.md、report.md、proposal-results.json、source-coverage.json、raw-verification.json、audit-summary.json、finding-verification.json及result.json。

# 准备过程原失败和修正

- 首次只读提案历史摘要输出过长被截断；改为只输出原 add 和最新 update，原队列没有改写。
- 只读路径探测中的 reflex/decide.ts、reflex/silent-selection-execution.ts、learner/selection-execution.ts、reflex/silent-potion-provenance.ts 不存在；用 rg --files 确认实际实现位于 combat-plan.ts、learner/lib/selection-execution.ts 和 audit-selection.ts，没有将路径缺失认作源码失败。
- 第一次取首帧摘要时 combat 为 null，发生 AttributeError，改成只选有 combat 的原帧后读取；原日志与抽取不变。
- scratch/prepare_evidence.py 首次 rc=1：OUT.parents[2]/extract_evidence.py 路径错误，FileNotFoundError。修正为 OUT.parents[1]/extract_evidence.py 后重跑；这只是本批证据准备脚本，不是生产源码或游戏测试。
- 进度口头计数 8,228 有误，实际完整 manifest 为 8,444 条，以下报告均取真实 manifest 计数。

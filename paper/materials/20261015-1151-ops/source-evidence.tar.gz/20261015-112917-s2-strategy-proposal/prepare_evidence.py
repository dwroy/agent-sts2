import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("extract", OUT.parents[1] / "extract_evidence.py")
EXTRACT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(EXTRACT)
RUNS = {row["run_id"]: row for row in json.loads((OUT / "run-identities.json").read_text())}
FLOORS = {
    "751FN9QM9MHQ": [13, 17], "KV0JHNJCKXLS": [33],
    "YQL8RZ8BWN1E": [17], "L9SGRBB5R698": [17],
    "PU80F84P6HPN": [17], "KEN58SH9SLZ6": [3, 4, 5, 11, 15, 17],
}
inputs = {run: {"run": row, "decisions": [], "states": []} for run, row in RUNS.items()}
verification, excluded = [], []
for stream in json.loads((OUT / "evidence/evidence-manifest.json").read_text()):
    path = OUT / "evidence" / (stream["stream"] + ".evidence.jsonl")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream["output_sha256"]
    counts = dict.fromkeys(RUNS, 0)
    with Path(path).open() as extracted, Path(next(iter(json.loads(line)["source"] for line in path.open()),
                                            "/home/dw/Projects/agent-sts2/logs/" + stream["stream"] + ".jsonl")).open("rb") as raw:
        for line in extracted:
            item = json.loads(line)
            raw.seek(item["offset"])
            data = raw.read(item["bytes"])
            assert hashlib.sha256(data).hexdigest() == item["sha256"]
            row = item["row"]
            assert json.loads(data) == row
            run = EXTRACT.run_identity(row)
            assert run == item["run_id"] and run in RUNS
            counts[run] += 1
            if stream["stream"] not in ("decisions", "states"):
                continue
            state = row.get("state") or {}
            floor = (state.get("run") or {}).get("floor") if stream["stream"] == "states" else row.get("floor")
            if floor not in FLOORS[run]:
                continue
            if stream["stream"] == "decisions" and not row.get("decision_id"):
                excluded.append({"stream": "decisions", "run": run, "line": item["line"],
                                 "reason": "无 decision_id 的元数据，不作为动作"})
                continue
            derived = {**row, "_line": item["line"], "_source_sha256": item["sha256"]}
            if stream["stream"] == "states":
                # Project fields consumed by the existing audit; full original bytes remain in evidence.
                derived["state"] = {key: state[key] for key in ("run_id", "screen", "turn", "run", "combat") if key in state}
            inputs[run][stream["stream"]].append(derived)
    assert counts == stream["counts"]
    verification.append({"stream": stream["stream"], "source_size": stream["source_size"],
                         "verified_rows": sum(counts.values()), "counts": counts,
                         "raw_bytes_and_identity_verified": True})
for run, data in inputs.items():
    path = OUT / (run + ".audit-input.json")
    path.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n")
    print(json.dumps({"run": run, "floors": FLOORS[run], "decisions": len(data["decisions"]),
                      "states": len(data["states"]), "bytes": path.stat().st_size}, ensure_ascii=False))
(OUT / "raw-verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2) + "\n")
(OUT / "audit-input-exclusions.json").write_text(json.dumps(excluded, ensure_ascii=False, indent=2) + "\n")

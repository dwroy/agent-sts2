import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = json.loads((OUT / 'anchor-states.json').read_text())
decisions = json.loads((OUT / 'anchor-decisions.json').read_text())
windows = json.loads((OUT / 'state-windows.json').read_text())
checks = []


def check(name, actual, expected, lines):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected,
                   'source_lines': lines, 'ok': True})


def s(line):
    return states[str(line)]


def r(line):
    return decisions[str(line)]['row']


def power(entity, key):
    return next((p['amount'] for p in entity['powers'] or [] if p['power_id'] == key), 0)


def criteria(line, key):
    value = r(line)['questions']['plan']['criteria'][key]
    return json.loads(value) if isinstance(value, str) else value


check('神化实付能量', s(275564)['player']['energy'] - s(275565)['player']['energy'], 2,
      [275564, 275565])
check('神化前后同序题面与实际端点',
      [[criteria(269706, 'plan1')['damage_dealt'], criteria(269706, 'plan1')['hp_lost']],
       [criteria(269707, 'plan1')['damage_dealt'], criteria(269707, 'plan1')['hp_lost']],
       [s(275679)['enemies'][0]['current_hp'] - s(275687)['enemies'][0]['current_hp'],
        s(275679)['player']['current_hp'] - s(275687)['player']['current_hp']]],
      [[43, 14], [51, 13], [51, 13]], [269706, 269707, 275679, 275687])
check('SL同盘指纹', r(270216)['fingerprint'] == r(270282)['fingerprint'], True,
      [270216, 270282])
check('SL换线实付血价与当轮输出',
      [[s(a)['player']['current_hp'] - s(b)['player']['current_hp'],
        s(a)['enemies'][0]['current_hp'] - s(b)['enemies'][0]['current_hp']]
       for a, b in [(276208, 276212), (276274, 276278)]],
      [[3, 10], [15, 17]], [276208, 276212, 276274, 276278])
mc = [r(n)['potions']['random'][0] for n in [269748, 269754]]
check('药水抽样与后续推演范围',
      [[x['ms'], x['samples'], x['requested'], r(n)['rollout']['horizon'], r(n)['rollout']['samples']]
       for x, n in zip(mc, [269748, 269754])],
      [[707, 1, 12, 1, 1], [11, 12, 12, 5, 3]], [269748, 269754])
check('药水两题非同盘', r(269748)['fingerprint'] != r(269754)['fingerprint'], True,
      [269748, 269754])
check('三骑士当轮候选代价与明确并列',
      [[[criteria(269770, k)['hp_lost'], criteria(269770, k)['damage_dealt']]
        for k in ['plan1', 'plan2']], r(269770)['rollout']['tied']],
      [[[13, 24], [31, 32]], ['plan2', 'plan3', 'plan4']], [269770])
check('蚌的当前成长及喷水',
      [[power(s(n)['enemies'][0], 'STRENGTH_POWER'), s(n)['enemies'][0]['intents'][0]['damage']]
       for n in [273238, 273252, 273263]],
      [[0, 11], [4, 15], [8, 19]], [273238, 273252, 273263])
check('负敏捷与双防御',
      [power(s(273504)['player'], 'DEXTERITY_POWER'), s(273507)['player']['block']],
      [-2, 6], [273504, 273507])
check('幻象未退场与航行后继',
      [s(273595)['enemies'][0]['current_hp'], s(273596)['enemies'][0]['current_hp'],
       s(273595)['player']['current_hp'] - s(273596)['player']['current_hp'],
       power(s(273595)['enemies'][0], 'STRENGTH_POWER'),
       power(s(273596)['enemies'][0], 'STRENGTH_POWER')],
      [2, 2, 15, 3, 6], [273595, 273596])
beetle = lambda n: next(e for e in s(n)['enemies'] if e['enemy_id'] == 'SLUMBERING_BEETLE')
check('甲虫睡层与醒后成长',
      [[power(beetle(n), 'SLUMBER_POWER') for n in [274909, 274914, 274919]],
       [[power(beetle(n), 'STRENGTH_POWER'), beetle(n)['intents'][0]['damage']]
        for n in [274923, 274929, 274934]]],
      [[3, 2, 1], [[0, 18], [2, 20], [4, 22]]],
      [274909, 274914, 274919, 274923, 274929, 274934])
before = next(x for x in windows if x['run_id'] == '5PM6JAQG6FNQ' and
              x['observed_ts'] == r(268455)['observed_ts'])
after = next(x for x in windows if x['line'] == before['line'] + 1)
check('无毒目标冒泡实付与无效果',
      [r(268455)['expect']['card']['id'], before['player']['energy'] - after['player']['energy'],
       before['enemies'] == after['enemies'],
       power(before['enemies'][0], 'POISON_POWER'), power(after['enemies'][0], 'POISON_POWER')],
      ['BUBBLE_BUBBLE', 1, True, 0, 0], [268455, before['line'], after['line']])
parsed = {}
for line in decisions:
    row = r(line)
    parsed[line] = {k: json.loads(v) if isinstance(v, str) else v
                    for k, v in (row.get('questions') or {}).get('plan', {}).get('criteria', {}).items()}
(OUT / 'parsed-criteria.json').write_text(json.dumps(parsed, ensure_ascii=False, indent=2) + '\n')
(OUT / 'fact-checks.json').write_text(json.dumps({'scope': '原日志数值一致性，非生产测试或模拟',
                                                'checks': checks, 'ok': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'ok': True}, ensure_ascii=False))

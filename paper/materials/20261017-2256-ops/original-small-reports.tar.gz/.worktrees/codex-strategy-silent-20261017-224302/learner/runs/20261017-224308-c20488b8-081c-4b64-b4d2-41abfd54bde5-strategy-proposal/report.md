# 本批十项策略提案复核

批次：20261017-224302-strategy-proposal；角色：静默猎手；已观察进阶：A10。
基线：`03e5a8f50b01203ece2518d0391d15936aa4dd50`。普通队列的task、character、worktree、六局集合与十个proposal_ids均核对；没有research_request、implementation_request或proposal_repair。普通专题根请求绑定另一批，未套用专题任务。开工工作树干净，`git merge --no-edit main`返回Already up to date。

结论：十项均waiting。现有窄实现已经覆盖部分原问题；本批没有新受控对照或可确定新增修正的源码失配。实际施放/执行归属、联合生产校准及策略反事实仍有逐项缺口，保留现有规则。没有源码提交、live合入或新发布号。Roy-2026-10-07-learning提供修改权限，不提供游戏事实。

## 证据边界与保存

六局runs.jsonl均为SILENT/A10，运行code均带dirty。当前源码只说明现有实现，不反推成历史完整运行树。十份原Markdown逐SHA匹配，原字节副本为`silent-proposal-*.original.md`；仅处理本批原id，不新增重复提案，不改原文或历史复盘。

按共用extract_evidence.py抽取八流，固定每流各自source_size，入选6995条：states3432、decisions3306、SL29、run-config6、run-plans33、brain183、runs6、fight-plans0。每条封套保留source/line/offset/bytes/SHA；`integrity.json`已逐条seek原件复读，字节、JSON、显式身份和输出SHA均通过。run-plans的run及fingerprint.run参与身份校验，正文提及不算所属局。fight-plans只表示本截点选中0，不宣称原件缺失；未复核旧截点，也未覆盖旧批或零行初稿。源states/decisions/brain各有2条不可解析行，未混入选中封套，不宣称全源无错误。

`state-windows.json`保留819帧有界相关场景；`anchor-states.json`保存32个状态锚点、`anchor-decisions.json`保存11个原决策；`decision-facts.json`及`parsed-criteria.json`分列预测与动作。`fact-checks.json`的12项仅校对原日志数值，没有调用生产模拟、LLM、网络或游戏。SL判死/实际死亡、尝试/独立局分开，未来毒不补记成已发生伤害。上述原帧已用于发现与复核，不是盲测；本批不拟合新权重，未来验证按run_id和时间后置切分。

`experience-readback.json`仅读回本角色相关19经验；`ledger-before.json`保存相关26账本的输入快照，不更改知识库或经验条目。既有经验的宽范围或支持总数不冒称本批验证数。

## 现有源码与局部完成边界

读取live快照`deb9135b8c8e63080beae091b959a04738c64587`。`source-readback.json`记录18个相关源码的base/live blob、SHA与live工作字节，均无工作副本脏改；差异仅5文件的Roy/Dai历史署名注释，完整差异在`base-live-diff.patch`，本树原字节在`source/*.txt`。

- 神化观察范围内传播已有`772b839f8ada31664cb764ea9ad3bdb03da27f64`；`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`等补了已见升级。card-model只对Silent A10已见普通神化签名启用，turn-solver/rollout保留未知牌、重放与属性组合限制。
- 神化候选事实同步提交`30ec2425012eea75f41226b31d8180b1abb837bc`的`actual_cast_this_fight`仍为null；持有、计划与模拟升级不等于实际施放。
- `45161a51c2c6b7e4a499b13cf749c4108193bbf5`已有模拟成熟度展示，区分退化、未比较与明确并列；不证明MC预算策略配对已完成。
- `fdaf787a372880b0438e73bcac7e6d2168b038ed`单动作派发回执保留`state_effect_verified=false`、`whole_plan_executed=null`；选择审计与护栏审计的actual_turn/actual_outcome仍未知。`1698adc96ba434a46942321e0237b70657e625b2`为SL资源比较窄增量，仍是预测。

上述六提交均已核为该实际live快照祖先，见`existing-ancestor-check.json`。它们证明限定子项存在，不能作为十条宽请求整体implemented/duplicate的凭据。未复用旧批测试成功来充作本批结果。

## 逐项结论

| 提案 | 证据与原账本 | 缺口及处置 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | VLZ6CCT8AQ0A F35 T1 s275564→275565实付2能；F43 T1 d269706/269707同后续序列43伤/14损→51伤/13损，s275679→275687支持实际51伤/13损。F45 T1未施放，不能把持有算作建立。 账本：silent-0237、silent-0238 | waiting：缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属和完整消费者核验；现有普通神化升级传播及候选事实为限定子项，actual_cast_this_fight仍为null。 |
| silent-proposal-f2bfceddb1898dca | VLZ6CCT8AQ0A F45 T1 d269748：药水MC707ms、1/12，rollout696ms/horizon1/samples1/best=null；d269754：MC11ms、12/12，rollout1393ms/horizon5/samples3，指纹已不同。T4 d269770：攻击线31损/32伤，实选线13损/24伤，plan2/3/4明确并列。 账本：silent-0106、silent-0019、silent-0201 | waiting：缺模型充分覆盖下同起点、同随机池、同总预算的MC策略配对及成熟度曲线；两次不同盘面的1/12与12/12不能用来确定新预算、留药常量或固定目标。 |
| silent-proposal-283a164780d11e69 | 与89354805ee4d7e77同源的VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；两份原Markdown各自SHA核同，关联同一0237/0238与silent-apotheosis-combat-upgrades经验。 账本：silent-0237、silent-0238 | waiting：同源神化经验链的实际施放持续归属及完整消费核验仍缺；不能以同题或局部实现将整项登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | VLZ6CCT8AQ0A F43 T1升级勒紧6/尖啸8，T2/T3分列减力与敏捷；F45 T4/T5分列当前损伤、临减力、零覆甲及剩余毒。原提案为14账本、15经验的复合请求。 账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019 | waiting：缺十五机制逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者的固定联合校准；本批静态核对未定位新的确定失配，已有子机制不足认证复合请求全部完成。 |
| silent-proposal-e5b87be50f28f311 | 8JRE1C4H4Z2W F33首/三试T2 d270216/270282指纹逐字相同；s276208→276212为47→44血/326→316敌血，s276274→276278为47→32血/326→309敌血，即多12血只多7伤。第三试同题原线0/24与替线5/24死亡；首试另为8样本。第二试T5 d270264护栏前16损43伤、后4损25伤。 账本：silent-0079、silent-0021、silent-0125、silent-0018 | waiting：已有Jev原答、护栏后、SL后及单动作派发审计；仍缺跨抽牌、选牌、生成、药水重问与SL的候选持续执行归属和实际整线收益认证。 |
| silent-proposal-49632bc4878fb597 | CA5KE8GFJ9X2 F13 T1/T3/T5 s273238/273252/273263：蚌力量0/4/8、喷水11/15/19。原末T5虚弱后14攻击、2血10挡，完整需损4，不能把截至0的实扣2当完整代价。 账本：silent-0005、silent-0231 | waiting：缺力量逐击、正负敏捷、虚弱及蚌独立成长的逐来源生产调用和联合校准；CA5未取得步法，无本局正敏捷实测，不新增统一保血或输出权重。 |
| silent-proposal-66532328a585941f | 5PM6JAQG6FNQ F39末试T2 d268455与s274379→274380：向无毒失落之物打BUBBLE_BUBBLE，5→4能、目标血/能力均不变。F33已经建立雾/触媒/群蛇并胜，但构筑资源与敌人条件不同。 账本：silent-0021、silent-0009 | waiting：缺同起始HP、构筑、药水及完整抽序下不同启动顺序的受控整战比较和收益函数；单步零效果不足拟合统一启动优先级或血价。 |
| silent-proposal-43a76a31ba7bdcfa | 61E2QS63Y9WU F17 T5吸取后的T6 s273504→273507：敏捷−2、双防御共6挡；敌67血/17毒，尖啸后17攻击。该战首试胜，不能把它换成一条SL获胜反事实。 账本：silent-0030、silent-0027 | waiting：缺A10同起始HP、构筑和完整抽序的另一可核SL全战线路及生产配对；负敏捷/毒端点和首试胜利不足修改SL范围或门槛。 |
| silent-proposal-5264153a4a4b0e5c | 61E2QS63Y9WU F23 T4 s273593→273595：幻象14→2、本体76→51且末10毒；T5 s273596幻象仍2、玩家25→10、本体41，力量3→6。当前源码已有召唤数据库入口与rollout接入。 账本：silent-0039、silent-0209 | waiting：缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤子项和本轮端点不足认证整项或整战目标排序收益。 |
| silent-proposal-bddfa690a84e03d0 | DUZUBAJ3A8GP F30首试s274909/274914/274919睡3/2/1；s274923/274929/274934为T4/T5/T6滚动18/20/22、力量0/2/4。sl-attempts914—917为四次同局尝试，前三predicted_death、末次died，不当四个独立实死样本。 账本：silent-0128、silent-0079 | waiting：缺伤害唤醒、眩晕接续和A10成长的全链生产校准及同抽换序完整后继；四次相关失败不足拟合新杀序、胜率或输出血价。 |

## 验证和交接

本批源码、知识、任务模板、参数、运维prompt均未修改；fixes=[]、merged=null，未运行tsc/vitest，cases为null。没有新实现，撤源码失败/恢复通过不适用；12项原日志数值核对与祖先检查不是生产测试。没有git提交、live合入、eval版本或shipped登记，无关角色行为保持原状。

仅经根ledger.py update追加这26个原账本的提案/报告追溯，by=learner:strategy-proposal；不新建重复经验，不增加support/repeat分母，不改原claim、evidence、first_run、prior、status或version。原proposed仍proposed，原shipped不降级；本批不写新的shipped。CLI实际退出码及保护字段核验见completion-check.json，未通过前不能视作登记完成。

运维交接：本目录proposal.md、report.md、result.json、proposal-results.json。十项均保留waiting，按各项缺口待新增合格本角色证据重派；本报告完成不关闭宽提案、父学习要求或未认证消费者。没有新源码，无需live合入锁、版本分配或规则变更双通知；本批没有向其他会话发送消息。

保留过程错误：首次只读schema探查在非战斗帧combat=null处报TypeError；随后加空值处理，正式八流核验与12项数值核对均实际退出0。该错误不是生产测试或撤源码实验，未冒记红绿。

## 最终读回

根ledger CLI update实际退出0，追加26条原id追溯；ledger check退出0、506项0问题。历史字节前缀SHA及claim/evidence/first_run/prior/status/version等保护字段不变，逐行追加offset/bytes/SHA在completion-check.json。最终HEAD仍等于完整base，工作树干净，生产源码与知识差异为零，本批派发绑定保持。初次gitleaks目录扫描退出0；新增账本回执材料的终检结果另记completion-check.json。tsc/vitest/cases仍为null，不宣称源码红绿、提交、合入或新版本。

新增材料后的gitleaks终检实际退出0、零发现；原始与终检回执分开保留。

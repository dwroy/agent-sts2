import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT / 'evidence'
RUNS = json.loads((OUT / 'dispatch.json').read_text())['runs']
SCOPES = {
    'VLZ6CCT8AQ0A': {35, 36, 37, 43, 45},
    '8JRE1C4H4Z2W': {17, 33},
    'CA5KE8GFJ9X2': {13},
    '5PM6JAQG6FNQ': {33, 38, 39},
    '61E2QS63Y9WU': {17, 23},
    'DUZUBAJ3A8GP': {30},
}
ANCHORS = {
    275564, 275565, 275679, 275680, 275686, 275687,
    275722, 275729, 275730, 275731, 275732, 275752, 275754, 275755,
    276208, 276212, 276274, 276278,
    273238, 273252, 273263, 273504, 273507,
    273593, 273595, 273596,
    274909, 274914, 274919, 274923, 274929, 274934,
}
DECISIONS = {269598, 269706, 269707, 269748, 269754, 269755, 269770,
             270216, 270282, 270264, 268455}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def identity(row):
    state = row.get('state') or {}
    fingerprint = row.get('fingerprint')
    if isinstance(fingerprint, str):
        try:
            fingerprint = json.loads(fingerprint)
        except ValueError:
            fingerprint = {}
    fingerprint = fingerprint if isinstance(fingerprint, dict) else {}
    values = {x for x in (row.get('run_id'), row.get('run'), state.get('run_id'), fingerprint.get('run'))
              if isinstance(x, str) and x and x != 'run_unknown'}
    assert len(values) == 1, values
    return next(iter(values))


def pointer(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def compact(item):
    row = item['row']
    state = row.get('state') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    run = state.get('run') or {}
    def cards(xs):
        return [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'energy_cost', 'dynamic_values')}
                for c in xs or []]
    return {
        **pointer(item), 'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'in_combat': state.get('in_combat'),
        'player': {k: player.get(k) for k in ('current_hp', 'max_hp', 'block', 'energy', 'powers')},
        'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'block', 'move_id', 'powers', 'intents')}
                    for e in combat.get('enemies') or []],
        'hand': cards(combat.get('hand')),
        'deck_upgraded': sum(c.get('upgraded') is True for c in run.get('deck') or []),
        'pile_keys': [k for k in combat if 'pile' in k or k == 'piles'],
    }


manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
integrity = []
windows, anchors, decisions, sl, plans = [], {}, {}, [], []
total = 0
for stream in manifest:
    name = stream['stream']
    path = EVIDENCE / (name + '.evidence.jsonl')
    counts = collections.Counter()
    digest = hashlib.sha256()
    with open('/home/dw/Projects/agent-sts2/logs/' + name + '.jsonl', 'rb') as source, path.open('rb') as rows:
        for encoded in rows:
            digest.update(encoded)
            item = json.loads(encoded)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256'], (name, item['line'])
            assert json.loads(raw) == item['row'], (name, item['line'])
            assert identity(item['row']) == item['run_id'] in RUNS
            assert item['offset'] + item['bytes'] <= stream['source_size']
            counts[item['run_id']] += 1
            total += 1
            row = item['row']
            if name == 'states':
                state = row.get('state') or {}
                run = state.get('run') or {}
                assert run.get('character_id') == 'SILENT'
                if run.get('floor') in SCOPES[item['run_id']] and state.get('combat'):
                    windows.append(compact(item))
                if item['line'] in ANCHORS:
                    anchors[str(item['line'])] = compact(item)
            elif name == 'decisions' and item['line'] in DECISIONS:
                decisions[str(item['line'])] = item
            elif name == 'sl-attempts':
                sl.append(item)
            elif name == 'run-plans':
                plans.append({'pointer': pointer(item), 'keys': list(row)})
    assert {r: counts[r] for r in RUNS} == stream['counts']
    assert digest.hexdigest() == stream['output_sha256']
    integrity.append({'stream': name, 'source_size': stream['source_size'],
                      'verified_rows': sum(counts.values()), 'counts': dict(counts),
                      'output_sha256': digest.hexdigest(), 'ok': True})
save('integrity.json', {'verified_rows': total, 'streams': integrity, 'ok': True})
save('state-windows.json', windows)
save('anchor-states.json', anchors)
save('anchor-decisions.json', decisions)
save('sl-readback.json', sl)
save('run-plans-readback.json', plans)
assert set(map(int, anchors)) == ANCHORS
assert set(map(int, decisions)) == DECISIONS
print(json.dumps({'verified_rows': total, 'streams': integrity, 'window_frames': len(windows),
                  'anchor_states': len(anchors), 'anchor_decisions': len(decisions)}, ensure_ascii=False))

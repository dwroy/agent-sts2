import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'selected-proposals.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
integrity = json.loads((OUT / 'integrity.json').read_text())
facts = json.loads((OUT / 'fact-checks.json').read_text())
assert integrity['ok'] and facts['ok']

details = [
    ('89354805ee4d7e77',
     'VLZ6CCT8AQ0A F35 T1 s275564→275565实付2能；F43 T1 d269706/269707同后续序列43伤/14损→51伤/13损，s275679→275687支持实际51伤/13损。F45 T1未施放，不能把持有算作建立。',
     '缺跨抽牌、选牌、药水重问、SL与换战的实际神化施放持续归属和完整消费者核验；现有普通神化升级传播及候选事实为限定子项，actual_cast_this_fight仍为null。',
     '保留现有观察范围内升级传播。补齐具有战斗/尝试身份的实际施放与续问证据后，用固定调用验证持续归属、场外牌组不变、未知保持未知；不新增必打神化规则。'),
    ('f2bfceddb1898dca',
     'VLZ6CCT8AQ0A F45 T1 d269748：药水MC707ms、1/12，rollout696ms/horizon1/samples1/best=null；d269754：MC11ms、12/12，rollout1393ms/horizon5/samples3，指纹已不同。T4 d269770：攻击线31损/32伤，实选线13损/24伤，plan2/3/4明确并列。',
     '缺模型充分覆盖下同起点、同随机池、同总预算的MC策略配对及成熟度曲线；两次不同盘面的1/12与12/12不能用来确定新预算、留药常量或固定目标。',
     '保留预算与选择规则。未来以同一冻结调用和随机池比较MC先行/分阶段预算，分列覆盖缺口与完整时间成本，形成样本成熟度曲线；不把单题707ms解释为应设的新常数。'),
    ('283a164780d11e69',
     '与89354805ee4d7e77同源的VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；两份原Markdown各自SHA核同，关联同一0237/0238与silent-apotheosis-combat-upgrades经验。',
     '同源神化经验链的实际施放持续归属及完整消费核验仍缺；不能以同题或局部实现将整项登记duplicate。',
     '沿原两个id保留去重关系，共用未来固定证据与实现，不另建同题提案；只有完整覆盖并核实际live源码祖先后才可改状态。'),
    ('ebbfe3b97548756d',
     'VLZ6CCT8AQ0A F43 T1升级勒紧6/尖啸8，T2/T3分列减力与敏捷；F45 T4/T5分列当前损伤、临减力、零覆甲及剩余毒。原提案为14账本、15经验的复合请求。',
     '缺十五机制逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者的固定联合校准；本批静态核对未定位新的确定失配，已有子机制不足认证复合请求全部完成。',
     '保持各来源事实和当前选择。下一步须逐机制冻结生产调用与期望端点，再验证实际消费者；不能把单轮减力、未结算毒或持有组件预支成整战收益。'),
    ('e5b87be50f28f311',
     '8JRE1C4H4Z2W F33首/三试T2 d270216/270282指纹逐字相同；s276208→276212为47→44血/326→316敌血，s276274→276278为47→32血/326→309敌血，即多12血只多7伤。第三试同题原线0/24与替线5/24死亡；首试另为8样本。第二试T5 d270264护栏前16损43伤、后4损25伤。',
     '已有Jev原答、护栏后、SL后及单动作派发审计；仍缺跨抽牌、选牌、生成、药水重问与SL的候选持续执行归属和实际整线收益认证。',
     '保留护栏与探索选择。补齐跨重问的候选身份、结束原因及实际建立端点，分开预测/派发/状态效果；首三试同盘差值仅证本轮血价，无另一完整胜线，不拟合血价或SL门槛。'),
    ('49632bc4878fb597',
     'CA5KE8GFJ9X2 F13 T1/T3/T5 s273238/273252/273263：蚌力量0/4/8、喷水11/15/19。原末T5虚弱后14攻击、2血10挡，完整需损4，不能把截至0的实扣2当完整代价。',
     '缺力量逐击、正负敏捷、虚弱及蚌独立成长的逐来源生产调用和联合校准；CA5未取得步法，无本局正敏捷实测，不新增统一保血或输出权重。',
     '按本角色分源冻结当前攻击段、属性、挡与成长脚本；正敏捷另核已有本角色证据，不以CA5未取得的牌补数。只有确定源码差错才改模型。'),
    ('66532328a585941f',
     '5PM6JAQG6FNQ F39末试T2 d268455与s274379→274380：向无毒失落之物打BUBBLE_BUBBLE，5→4能、目标血/能力均不变。F33已经建立雾/触媒/群蛇并胜，但构筑资源与敌人条件不同。',
     '缺同起始HP、构筑、药水及完整抽序下不同启动顺序的受控整战比较和收益函数；单步零效果不足拟合统一启动优先级或血价。',
     '保持持有、计划、实付、建立、后继分账；以同盘完整后继核不同启动顺序，不把跨场胜败当启动因果对照。'),
    ('43a76a31ba7bdcfa',
     '61E2QS63Y9WU F17 T5吸取后的T6 s273504→273507：敏捷−2、双防御共6挡；敌67血/17毒，尖啸后17攻击。该战首试胜，不能把它换成一条SL获胜反事实。',
     '缺A10同起始HP、构筑和完整抽序的另一可核SL全战线路及生产配对；负敏捷/毒端点和首试胜利不足修改SL范围或门槛。',
     '保留吸取、负敏捷与毒的分项事实；未来固定生产调用对齐全战后继与另一可追溯线路，未知抽序不补齐。'),
    ('5264153a4a4b0e5c',
     '61E2QS63Y9WU F23 T4 s273593→273595：幻象14→2、本体76→51且末10毒；T5 s273596幻象仍2、玩家25→10、本体41，力量3→6。当前源码已有召唤数据库入口与rollout接入。',
     '缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤子项和本轮端点不足认证整项或整战目标排序收益。',
     '保留全部目标选项及相同推演值并列；逐实体核召唤/成长/再现/退场，取得另一focus完整后继后再评估排序，不制定固定首杀。'),
    ('bddfa690a84e03d0',
     'DUZUBAJ3A8GP F30首试s274909/274914/274919睡3/2/1；s274923/274929/274934为T4/T5/T6滚动18/20/22、力量0/2/4。sl-attempts914—917为四次同局尝试，前三predicted_death、末次died，不当四个独立实死样本。',
     '缺伤害唤醒、眩晕接续和A10成长的全链生产校准及同抽换序完整后继；四次相关失败不足拟合新杀序、胜率或输出血价。',
     '分别核自然睡层、实际伤害唤醒、眩晕后继与独立成长，保持未知；未来同抽不同排序取得完整后继后再评估策略，不以四次失败确定固定杀序。'),
]
assert ['silent-proposal-' + d[0] for d in details] == dispatch['proposal_ids']
results = [{'id': 'silent-proposal-' + suffix, 'state': 'waiting', 'reason': reason}
           for suffix, evidence, reason, validation in details]
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

header = f'''# 本批十项策略提案复核

批次：20261017-224302-strategy-proposal；角色：静默猎手；已观察进阶：A10。
基线：`{source['base']}`。普通队列的task、character、worktree、六局集合与十个proposal_ids均核对；没有research_request、implementation_request或proposal_repair。普通专题根请求绑定另一批，未套用专题任务。开工工作树干净，`git merge --no-edit main`返回Already up to date。

结论：十项均waiting。现有窄实现已经覆盖部分原问题；本批没有新受控对照或可确定新增修正的源码失配。实际施放/执行归属、联合生产校准及策略反事实仍有逐项缺口，保留现有规则。没有源码提交、live合入或新发布号。Roy-2026-10-07-learning提供修改权限，不提供游戏事实。

## 证据边界与保存

六局runs.jsonl均为SILENT/A10，运行code均带dirty。当前源码只说明现有实现，不反推成历史完整运行树。十份原Markdown逐SHA匹配，原字节副本为`silent-proposal-*.original.md`；仅处理本批原id，不新增重复提案，不改原文或历史复盘。

按共用extract_evidence.py抽取八流，固定每流各自source_size，入选{integrity['verified_rows']}条：states3432、decisions3306、SL29、run-config6、run-plans33、brain183、runs6、fight-plans0。每条封套保留source/line/offset/bytes/SHA；`integrity.json`已逐条seek原件复读，字节、JSON、显式身份和输出SHA均通过。run-plans的run及fingerprint.run参与身份校验，正文提及不算所属局。fight-plans只表示本截点选中0，不宣称原件缺失；未复核旧截点，也未覆盖旧批或零行初稿。源states/decisions/brain各有2条不可解析行，未混入选中封套，不宣称全源无错误。

`state-windows.json`保留819帧有界相关场景；`anchor-states.json`保存32个状态锚点、`anchor-decisions.json`保存11个原决策；`decision-facts.json`及`parsed-criteria.json`分列预测与动作。`fact-checks.json`的12项仅校对原日志数值，没有调用生产模拟、LLM、网络或游戏。SL判死/实际死亡、尝试/独立局分开，未来毒不补记成已发生伤害。上述原帧已用于发现与复核，不是盲测；本批不拟合新权重，未来验证按run_id和时间后置切分。

`experience-readback.json`仅读回本角色相关19经验；`ledger-before.json`保存相关26账本的输入快照，不更改知识库或经验条目。既有经验的宽范围或支持总数不冒称本批验证数。

## 现有源码与局部完成边界

读取live快照`{source['live']}`。`source-readback.json`记录18个相关源码的base/live blob、SHA与live工作字节，均无工作副本脏改；差异仅5文件的Roy/Dai历史署名注释，完整差异在`base-live-diff.patch`，本树原字节在`source/*.txt`。

- 神化观察范围内传播已有`772b839f8ada31664cb764ea9ad3bdb03da27f64`；`ba23ca693151fa8c6f7fe035e640dc30f05ccd75`等补了已见升级。card-model只对Silent A10已见普通神化签名启用，turn-solver/rollout保留未知牌、重放与属性组合限制。
- 神化候选事实同步提交`30ec2425012eea75f41226b31d8180b1abb837bc`的`actual_cast_this_fight`仍为null；持有、计划与模拟升级不等于实际施放。
- `45161a51c2c6b7e4a499b13cf749c4108193bbf5`已有模拟成熟度展示，区分退化、未比较与明确并列；不证明MC预算策略配对已完成。
- `fdaf787a372880b0438e73bcac7e6d2168b038ed`单动作派发回执保留`state_effect_verified=false`、`whole_plan_executed=null`；选择审计与护栏审计的actual_turn/actual_outcome仍未知。`1698adc96ba434a46942321e0237b70657e625b2`为SL资源比较窄增量，仍是预测。

上述六提交均已核为该实际live快照祖先，见`existing-ancestor-check.json`。它们证明限定子项存在，不能作为十条宽请求整体implemented/duplicate的凭据。未复用旧批测试成功来充作本批结果。

## 逐项结论

| 提案 | 证据与原账本 | 缺口及处置 |
|---|---|---|
'''
table = ''
expanded = '# 本批提案与补证要求\n\n角色silent；观察A10；来源及实现任务strategy-proposal，批次20261017-224302-strategy-proposal。十个原提案均保留waiting，无新源码或重复id。\n\n'
for suffix, evidence, reason, validation in details:
    ident = 'silent-proposal-' + suffix
    ledger = '、'.join(proposals[ident]['ledger'])
    table += f'| {ident} | {evidence} 账本：{ledger} | waiting：{reason} |\n'
    expanded += f'''## {ident}

原提案：{proposals[ident]['proposal']}；原SHA：{proposals[ident]['proposal_sha256']}。
原账本：{ledger}。审阅领域：{'、'.join(proposals[ident]['domains'])}。

证据：{evidence}

旧行为/本批预期：保留现有实现与选择规则。{reason}

反例与未知：上述差值只属于所列局面；候选、局部正确机制及相关重打不等于独立整战收益。没有证据的后继、未知牌与抽序保持未知，不借预训练事实补齐。{validation}

拟合与验证：不新增常数，不以本批发现帧作盲测。后续新增实现须从相应原行冻结实际输入与期望值，区分单步修正与整战策略收益；使用固定数据、撤源码失败/恢复通过及原沙箱入口，再核实际live源码祖先。

处置：waiting。回退：本批无生产改动需要回退，CLI追溯按追加保留；未来若改行为，回退相应源码并按实际新发布记录，保留原证据与失败历史。

'''
footer = '''
## 验证和交接

本批源码、知识、任务模板、参数、运维prompt均未修改；fixes=[]、merged=null，未运行tsc/vitest，cases为null。没有新实现，撤源码失败/恢复通过不适用；12项原日志数值核对与祖先检查不是生产测试。没有git提交、live合入、eval版本或shipped登记，无关角色行为保持原状。

仅经根ledger.py update追加这26个原账本的提案/报告追溯，by=learner:strategy-proposal；不新建重复经验，不增加support/repeat分母，不改原claim、evidence、first_run、prior、status或version。原proposed仍proposed，原shipped不降级；本批不写新的shipped。CLI实际退出码及保护字段核验见completion-check.json，未通过前不能视作登记完成。

运维交接：本目录proposal.md、report.md、result.json、proposal-results.json。十项均保留waiting，按各项缺口待新增合格本角色证据重派；本报告完成不关闭宽提案、父学习要求或未认证消费者。没有新源码，无需live合入锁、版本分配或规则变更双通知；本批没有向其他会话发送消息。

保留过程错误：首次只读schema探查在非战斗帧combat=null处报TypeError；随后加空值处理，正式八流核验与12项数值核对均实际退出0。该错误不是生产测试或撤源码实验，未冒记红绿。
'''
(OUT / 'report.md').write_text(header + table + footer)
(OUT / 'proposal.md').write_text(expanded)
result = {'task': 'strategy-proposal', 'character': 'silent',
          'batch': '20261017-224302-strategy-proposal', 'base': source['base'],
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'],
          'implementation_domains': ['combat', 'potion', 'sl', 'structure'],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in sorted({item for p in proposals.values() for item in p['ledger']}):
    relevant = [x['id'] for x in results if ident in proposals[x['id']]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                    'note': '20261017-224302-strategy-proposal复核：' + '、'.join(relevant) +
                            '仍waiting；六局6995原行与源码边界核回，无新规则/源码/合入或新独立样本；逐项缺口见报告，保留原状态与学习父要求。'})
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal': str(OUT / 'proposal.md'),
                  'proposal_results': len(results), 'ledger_updates': len(updates)}, ensure_ascii=False))

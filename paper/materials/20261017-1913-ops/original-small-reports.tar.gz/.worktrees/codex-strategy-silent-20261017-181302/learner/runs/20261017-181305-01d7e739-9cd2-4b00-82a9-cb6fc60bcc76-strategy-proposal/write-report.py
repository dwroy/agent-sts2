import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
now = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
print(now)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())
sources = json.loads((OUT / 'source-verification.json').read_text())
raw = json.loads((OUT / 'raw-readback-verification.json').read_text())
consumers = json.loads((OUT / 'consumer-readback.json').read_text())
facts = json.loads((OUT / 'fact-checks.json').read_text())
base = sources['base']
assert all(f['ok'] for f in facts)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)

rows = [
    ('VLZ6CCT8AQ0A；F35T1/F36T2/F37T5/F43T1—T5/F45T1—T5',
     '缺跨抽牌、选牌、药水重问、SL及换战的实际神化施放持续归属和生产消费者读回；当前普通神化的窄升级传播、六原帧夹具及未知标记不足以证明整项交付。',
     'F43实付2能，同轮净扣51/损13，场外不作永久锻造；F45未施放但败不是施放效果的反例。',
     '沿已观察差值传播，保持未知显式；持有、候选、模拟已升级和本战实际施放分列。',
     '先在同一战斗/尝试身份下追溯真实派发及后继状态，核抽牌/重问/SL/换战边界，未见属性组合继续unknown；既有F43夹具读回不代替生产链认证。'),
    ('VLZ6CCT8AQ0A；F43/F44/F45T1/T4/T5',
     '缺完整模型下同起点、同随机池、同总预算的MC策略配对及样本成熟度/候选稳定性曲线；另一focus、留药和重分预算的完整后继未观察，707ms单题不足定新常量。',
     'F45首题MC为1/12、707ms且显式退化；下一问12/12不是整战胜率。T4少损线与未执行攻击线不能作整场因果比较。',
     '保留现预算、药水/护栏/目标规则；候选事实应显示成熟度、即时血价与逐敌击杀缺口。',
     '冻结神化覆盖、状态、随机池、总计算预算后成对比较MC分阶段方案，按局划时间后移验证集；无成熟度曲线不改预算。'),
    ('VLZ6CCT8AQ0A；F35T1/F43T1—T5/F45T1',
     '与89354805ee4d7e77同源，仍缺实际施放持续身份和后续生产消费认证；题意重复与现有窄实现均不足将整项登记duplicate。',
     'F35/F43实际升级支持已观测传播；F43仍损血、F45未施放，不能推出必打或固定收益。',
     '复用原神化实现及经验关联，保持未知与场内/场外边界；不另建重复id。',
     '沿原神化提案联合核验，不把经验上线或子项祖先当整项代码完成。'),
    ('VLZ6CCT8AQ0A；F43T1—T5/F45T3—T5/F44休息',
     '缺十五机制的逐来源、持续期限、升级/属性组合及战斗—路线—休息消费者联合固定校准；本批未定位新的确定源码失配，局部机制处理不等整条复合经验全部实现。',
     'F45实际勒紧4、敏捷3、覆甲0、触媒1；末20挡对59攻/32HP。F44实回34仍败不证明休息无效，未走路线结果未知。',
     '逐来源使用现场属性、期限、已结算毒与实际回复；不预支持有能力、开场覆甲或未来毒。',
     '十五子项各保存真实生产调用输入/输出，组合按实际来源与回合复核；路线和休息另需同资源对照，不能用单卡夹具覆盖全域。'),
    ('8JRE1C4H4Z2W；F17T6/F33首及第三试T2/第二试T5/末试T11',
     '已有预测三阶段、派发及观测端点审计；仍缺跨抽牌、选牌、生成、药水重问和SL的实际候选持续归属与完整生产校准。66片段均不能认证完整候选收益。',
     '首/三试T2指纹相同，整轮-3/-15HP与-10/-17敌血；预测死率0/24和5/24不同。第二试护栏候选差不自动等于实际省血，防御换线也非一概错误。',
     '维持SL/护栏阈值，保留Jev原答、护栏后、SL后及真实派发；重规划中断原候选完整执行认证。',
     '保存连续来源行、状态匹配与真实动作/卡身份，分开预测、观测端点与单卡归因；缺身份不补ID，未选整战反事实保持未知。'),
    ('CA5KE8GFJ9X2；F13T1/T3/T5',
     '本局无正敏捷实测；缺力量逐击、正负敏捷、虚弱和蚌独立成长四路径在冻结生产调用内的联合对照，不新增统一保血或输出权重。',
     '蚌力0/4/8、喷水11/15/19，弱后11/14仍成长；计划步法未兑现不能补为正敏捷样本。',
     '逐击属性、虚弱、实际牌挡及独立成长分别计量。',
     '本局只核已见蚌路径，正/负敏捷须有本角色已核原帧和真实调用；按进阶冻结敌HP/伤害/移动表，不搬其他角色数值。'),
    ('5PM6JAQG6FNQ；F33T1—T5/F38T3/F39第二试T2',
     '缺同HP、构筑、药水及完整抽序下不同启动顺序的受控整场对照和可复现收益函数；无毒冒泡局部无效不能拟合统一启动优先级或血价。',
     '末试F39T2玩家29HP，能量5→4、失落35血/0毒不变；同局F33已建组件并胜，敌人及资源条件也不同。',
     '持有、到手、实付、建立与后继分账；不将计划组件当已建立输出。',
     '保存全部抽序/生成/费用/敌状态，匹配起始资源逐方案重放；无因果对照只保事实和unknown。'),
    ('61E2QS63Y9WU；F17T5—T7',
     '缺A10同起始HP/构筑/完整抽序下另一可核SL全战线路与完整生产配对；首试胜利和负敏捷/毒端点不足改变SL适用范围或阈值。',
     '吸取前玩家力2/敏0，后力0/敏-2、敌力2；敌HP67→34。该局首试胜，不是固定换线偏好反事实。',
     '吸取、负敏捷、直接输出及已结毒独立计算；保留SL规则。',
     '复核逐动作牌挡与毒结算后，再用同起始资源和完整抽序的成对整战线路比较SL方案，相关重打不扩独立分母。'),
    ('61E2QS63Y9WU；F23T1—T5，重点T4',
     '缺A10召唤、航行、复现和退场全链的冻结生产联合校准及另一focus完整后继；已有召唤实现与T4端点不足证明目标排序整战收益。',
     'T4幻象14血/3力至T5仍2血/6力；本体线47伤/损15不能视为幻象退场。另focus候选未实打。',
     '逐实体存活/剩血/成长与复现分账，保留全部目标选项，同值并列；不定固定首杀。',
     '冻结A10实际召唤与移动脚本输入，核真实ID/退场/复现后继；另一focus须完整同资源后继，类型ID不冒充跨帧实体ID。'),
    ('DUZUBAJ3A8GP；F30四试，重点末试T1—T6',
     '缺伤害唤醒、眩晕接续及当前进阶成长的全链生产校准和同抽换序完整后继；四个相关失败尝试不足拟合新的杀序、胜率或输出血价。',
     '末试睡层3/2/1后T4醒；T5力2/攻20，尖啸后-4/攻14，T6恢复成长4/攻22。末试T4多扣3敌血也多损2玩家血。',
     '按现场睡眠/眩晕/成长与临减期限建模，保留固定杀序及血价未知。',
     '分别核自然醒、伤害醒及眩晕后继，冻结进阶与完整抽序；全败候选仍保实际当轮血价，不从四试失败拟合新权重。'),
]
assert len(rows) == len(proposals) == 10
results = []
proposal_text = [f'# 静默猎手本批十项策略提案核验\n\n记录时间：{now}。batch={dispatch["batch"]}；base={base}。\n',
                 '本批只消费已派发十个原id，不新增提案、不改原提案正文。下列“预期行为/验证”是原请求的完成条件，尚未实现部分保留waiting；没有新的游戏规则或收益参数。\n']
for p, (where, reason, observation, behavior, validation) in zip(proposals, rows):
    results.append({'id': p['id'], 'state': 'waiting', 'reason': reason})
    proposal_text.append(f'## {p["id"]}\n\n角色/范围：silent A10；证据：{where}。账本：{", ".join(p["ledger"])}。\n\n原提案：{p["proposal"]}；SHA256={p["proposal_sha256"]}，本批原字节核对一致。来源任务：{p["source_task"]}；实现任务：strategy-proposal。\n\n支持、反例与限制：{observation}\n\n旧行为与预期行为：{behavior}\n\n处置：waiting。{reason}\n\n验证方法：{validation}\n\n拟合及时间切分：本批六局只作历史发现/回归，不是独立盲测；同局SL不扩局数。未拟合新常数，待本角色新局或精确冻结输入补齐上述缺口后再审。未知保持未知。\n\n预期影响与回退：补齐事实模型与可核追溯，不承诺胜率。当前未改源码，无回退提交；将来实现须撤源码红/恢复绿、沙箱入口检查、角色隔离并按实际live源码提交登记，保留全部失败历史。\n')
(OUT / 'proposal.md').write_text('\n'.join(proposal_text))
run_rows = json.loads((OUT / 'run-identities.json').read_text())
total = {k: sum(c[k] for c in consumers) for k in ['decisions', 'states', 'candidate_segments', 'observed_action_endpoints', 'observed_terminal_endpoints', 'observed_turn_endpoints', 'unknown_turn_windows', 'certified_complete_candidates']}
same = sum(p['same_base_live'] for p in sources['files'])
report = [f'# 静默策略批次逐项处置报告\n\n记录时间：{now}。task=strategy-proposal；character=silent；batch={dispatch["batch"]}。\n',
          f'本批十项均waiting。原提案、六局日志及当前源码复核未定位新的确定源码失配，仍缺各项要求的持续执行归属、联合生产校准或受控整战比较。无源码/知识修改、源码提交、live合入、eval版本或新shipped；fixes=[]，merged=null。完整base={base}。\n',
          '## 身份与边界\n\n开工git status干净，必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol和learning-code-proposals已读。learn.json只读取本批行：task/character/worktree与六runs匹配、state=running、reason=proposal、十proposal_ids，无research_request/implementation_request/proposal_repair。普通专题根请求绑定其他旧batch，按1.2不承接，不读取别的专题替代身份。普通队列git merge --no-edit main为Already up to date，HEAD仍等于上述base。不派下级agent，不调用LLM/网络/game API，不运行play。\n',
          '六局runs.jsonl原行均SILENT/A10。独立局数六，SL不扩分母。只读取本角色证据及knowledge/characters/silent的关联经验，不搬其他角色私有知识；当前经验较宽的支持数或其他局例子不冒成本批验证分母。六局运行code均带dirty，仅从Git/当前源码不能重构当时全部源码、知识、随机池。\n',
          '## 冻结原日志与事实核验\n\n原日志由共用learner/extract_evidence.py提取8流。逐流source_size冻结；全部所属行按原offset/bytes/SHA256及JSON读回一致，身份仅从显式run_id/state.run_id/run/fingerprint.run核验，正文提及不作所属局。十个原Markdown逐SHA相符，原字节保存在original-proposals/。\n',
          '| 流 | source_size（字节） | 逐原行核验数 |\n|---|---:|---:|']
for x in raw:
    report.append(f'| {x["stream"]} | {x["source_size"]} | {x["verified_lines"]} |')
report.append(f'\n共{sum(x["verified_lines"] for x in raw)}行。每局计数见evidence/evidence-manifest.json及raw-readback-verification.json。fight-plans此截点0行只说明未选到，不断言原日志缺失。全源invalid/incomplete计数不据此归给六局。\n')
report.append(f'从原行构造了{total["states"]}状态/{total["decisions"]}决策的有界消费者输入；全部保留decision_id、observed_ts、fingerprint与物理_line，没有补ID/尝试身份或剔除元数据行。覆盖楼层如下，不能冒称六局所有楼层均完成生产校准。\n\n| 局 | 楼层 | 决策/状态 | 候选片段 | 相邻端点/终页端点 | 整轮端点/未知轮窗口 |\n|---|---|---:|---:|---:|---:|')
for c in consumers:
    report.append(f'| {c["run_id"]} | {",".join(map(str, c["scope_floors"]))} | {c["decisions"]}/{c["states"]} | {c["candidate_segments"]} | {c["observed_action_endpoints"]}/{c["observed_terminal_endpoints"]} | {c["observed_turn_endpoints"]}/{c["unknown_turn_windows"]} |')
report.append(f'\n六份gzip输入/输出的原字节SHA和消费者读回保留。当前基线真实调用learner/lib/selection-execution.ts，六输入均被接受。共{total["candidate_segments"]}候选片段、{total["observed_action_endpoints"]}相邻端点、{total["observed_terminal_endpoints"]}终页端点、{total["observed_turn_endpoints"]}整轮端点与{total["unknown_turn_windows"]}未知轮窗口；完整候选认证为0。这是消费者刻意保留的归属边界，不等于没有执行/没有观测收益。VLZ/CA5的缺尝试身份不能由reload=0补成attempt=1，旧指纹与pending回执不认证完整续步。\n')
report.append(f'\n固定原帧事实核验{len(facts)}项全部通过（fact-checks.json/log），其中六个既有神化夹具的手牌/玩家/敌人原帧一致。它们是数据一致性核验，未运行生产tsc/vitest或本次撤源码负控，不借用历史绿色结果。关键读回：\n\n- VLZ F43T1实际付2能，同序候选预测43伤/14损变51伤/13损；整轮实扣51、实损13。F45未打神化，末实际勒紧4/敏捷3/覆甲0/触媒1，20挡与32HP面对尖啸后59威胁。\n- 8JRE首/三试F33T2原指纹相同，实际整轮敌扣10/17、玩家损3/15；原预测0/24与5/24不同，进一步损失同封顶47不等同同死率。270264旧护栏记于rationale，hp_guard=null不能断言未触发。\n- CA5蚌T1/3/5力量0/4/8、喷水11/15/19；虚弱后11/14，仍有成长；本局无正敏捷实测。\n- 5PM末试F39T2无毒冒泡前后玩家HP均29、能5→4、目标35HP/0毒不变；整轮损21和敌后续净扣另账，不能由一步无效推统一启动权重。\n- 61E F17吸取前玩家力2/敏0，后力0/敏-2、敌力2；敌HP67→34。F23T4后幻象14→2且3→6力，不能把本体线当已退场。\n- DUZU末试睡3/2/1后醒，T5力2/攻20、尖啸后-4/攻14、T6力4/攻22；自然醒证据不能补所有伤害醒/眩晕分支。\n')
report.append(f'\n## 源码与live边界\n\n只读live快照={sources["live_snapshot"]}。{len(sources["files"])}条精确路径中{same}条base/live blob相同，{len(sources["files"])-same}条不同（card-model、rollout-live、sl/explore、boss-clock）。source-verification.json保存完整blob/SHA及每路径最近base提交的live祖先布尔；相同blob不自动说明最近base提交属于live历史。source-reference/仅存相关源码.txt，base.diff.patch为空，未归档整仓或建立额外检出。\n\n已核窄项源码提交均为base及该live快照祖先：\n')
for p in sources['narrow_sources']:
    report.append(f'- {p["commit"]}（base_ancestor={str(p["base_ancestor"]).lower()}；live_ancestor={str(p["live_ancestor"]).lower()}）')
report.append('\n神化处理仅Silent A10已观普通签名，配对表16项加萎靡专案共17种；未知/改造牌及未验证重放或属性组合显式unknown。当前apotheosis_reference.actual_cast_this_fight仍null，持有/候选/模拟与实际施放没有被伪造等同。选择审计有answer/before_sl/after_sl，派发回执与离线观测端点各自保留；这些窄实现不是十项全部完成。上述commit不是本批新增实现或合入，不据此填写implemented/duplicate。\n')
report.append('\n## 十项逐一处置\n\n| id | 处置 | 具体缺口 |\n|---|---|---|')
for r in results:
    report.append(f'| {r["id"]} | waiting | {r["reason"]} |')
report.append(f'\n每项证据局/层/回合、账本、反例、旧/预期行为、验证与回退详见{OUT / "proposal.md"}。已派发id集合与proposal_results精确相同，不领取其他id、不新增重复代码提案、不覆盖原Markdown或重写历史复盘。\n')
report.append('\n## 记录、检查及限制\n\n本次只经根learner/ledger.py update为相关本角色账本追加by=learner:strategy-proposal的proposal/report追溯与本批核验说明，不加重复support/反例，不改claim/首证/prior/asc/status/version/effect，不降级既有shipped；没有新经验或新代码提案需要add。CLI输入、原字节前缀SHA与追加行读回将单存。队列处置由最终proposal_results交现有调度器，不手改learn.json或code-proposals.jsonl。\n\n无源码修改，撤源码失败/恢复通过不适用；tests固定tsc=null、vitest=null、cases=null。未跑生产测试，未提交或启动live合入/知识刷新/版本分配，无新规则上线双通知或decision-log上线条目。其他角色行为保持等价。没有新的与旧知识冲突的科学主张，不发虚构异议或代填任何角色通知确认。经验入库、生产消费者采用和父要求关闭均不能由本报告/排队/局部源码推断。\n\n局限：六局均是已用历史发现数据，不是独立后置验证；相关SL不扩局数。dirty运行树与未记录随机池不能由当前live恢复。显示牌面、候选模拟、动作回执、观测净HP及整战因果始终分列。未见或缺帧保持unknown。\n\n读取源码定位时曾使用不存在的core/loop和monster-model等猜测路径，后定位到hand/loop及rollout；这些只读搜索提示不作产品故障或证据丢失。原日志/过程/失败历史保留。本批无生产测试失败可伪报红绿。\n')
report.append(f'\n交运维提案路径：{OUT / "proposal.md"}。最终报告：{OUT / "report.md"}。\n')
(OUT / 'report.md').write_text('\n'.join(report))
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'], 'base': base, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [r['id'] for r in results], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [], 'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
ledger_ids = sorted({i for p in proposals for i in p['ledger']})
updates = [{'id': ident, 'by': 'learner:strategy-proposal', 'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': f'{dispatch["batch"]}逐原行offset/bytes/SHA核六局6995条所属证据，28项原帧数据核验通过；十派发提案均waiting，具体缺数据见本批proposal/report。仅追加追溯，不新增support/反例、不改游戏结论/status/version或认定源码实现/采用。'} for ident in ledger_ids]
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates))
print(json.dumps({'base': base, 'report': str(OUT / 'report.md'), 'proposals': len(results), 'ledger_updates': len(updates), 'consumer_totals': total}, ensure_ascii=False))

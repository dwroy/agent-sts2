from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
pre = json.loads((OUT / 'ledger-pre-append.json').read_text())
source = Path(pre['source'])
raw = source.read_bytes()
prefix = raw[:pre['source_size']]
assert hashlib.sha256(prefix).hexdigest() == pre['prefix_sha256']
updates = [json.loads(line) for line in (OUT / 'ledger-updates.jsonl').read_text().splitlines()]
want = {row['id']: row for row in updates}
found = []
concurrent = []
offset = pre['source_size']
for line in raw[offset:].splitlines(keepends=True):
    row = json.loads(line)
    ref = {'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'id': row.get('id')}
    if row.get('id') in want:
        if all(row.get(k) == v for k, v in want[row['id']].items()):
            assert set(row) <= {'id', 'op', 'ts', 'by', 'where', 'note'}
            found.append(ref)
        else:
            concurrent.append({**ref, 'fields': list(row)})
    offset += len(line)
assert len(found) == len(want) == len({row['id'] for row in found}) == 26
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
before = ledger.fold([(n, json.loads(line)) for n, line in enumerate(prefix.splitlines(), 1) if line.strip()])
after = ledger.fold([(n, json.loads(line)) for n, line in enumerate(raw.splitlines(), 1) if line.strip()])
readbacks = []
changes = []
for ident, fields in pre['entries'].items():
    changed = []
    for key, sha in fields.items():
        actual = hashlib.sha256(json.dumps(after[ident].get(key), ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        if actual != sha:
            writers = [row for row in concurrent if row['id'] == ident and key in row['fields']]
            assert writers, (ident, key, '未找到并行更新来源')
            changed.append(key)
    assert all(path in after[ident]['where']['proposal'] for path in want[ident]['where']['proposal'])
    readbacks.append({'id': ident, 'proposal_links_read_back': True, 'our_update_has_no_protected_fields': True,
                      'concurrent_protected_field_changes': changed})
    if changed:
        changes.append({'id': ident, 'fields': changed, 'evidence_count_before': len(before[ident].get('evidence', [])),
                        'evidence_count_after': len(after[ident].get('evidence', []))})
verification = {'source_size_before': pre['source_size'], 'source_size_after': len(raw),
                'original_prefix_preserved': True, 'appended_rows': found, 'entry_readbacks': readbacks,
                'concurrent_rows': concurrent, 'concurrent_changes': changes}
(OUT / 'ledger-update-readback.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
assert set(dispatch['proposal_ids']) == set(result['code_proposals']) == {p['id'] for p in result['proposal_results']}
assert len(result['proposal_results']) == 10
assert result['fixes'] == [] and result['merged'] is None
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert Path(result['report']) == OUT / 'report.md'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == result['base']
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
assert not subprocess.check_output(['git', 'diff', '--binary', result['base']])
summary = {'ledger_updates_verified': len(found), 'ledger_link_readbacks': len(readbacks), 'concurrent_changes_preserved': changes,
           'head': result['base'], 'worktree_clean': True, 'all_dispatched_ids_resolved': True,
           'source_tests_run': False, 'report_exists': True}
(OUT / 'final-verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'report.md').open('a') as handle:
    handle.write('\n最终读回：根CLI实际追加26条追溯，逐offset/bytes/SHA核同，原23009903字节前缀SHA保持；本批26行仅含id/op/ts/by/where/note，未写claim/evidence/首证/asc/prior/status/version/effect，26条proposal双路径均可读回。并行写入的protected字段变化为' + json.dumps(changes, ensure_ascii=False) + '，保留其原行及真实变化。初次把全局折叠字段不变作为断言因并行evidence追加失败；原失败保留ledger-readback.initial-failure.txt，改按本批实际行与其他写者原行分开核验，没有覆盖或撤销并行证据。十派发id精确齐全，工作树tracked/index干净、HEAD保持base；无源码测试或红绿结果。\n')
(OUT / 'publication-scan.txt').write_text('\n'.join((OUT / name).read_text() for name in ['proposal.md', 'report.md', 'result.json', 'ledger-updates.jsonl', 'final-verification.json']))
print(json.dumps(summary, ensure_ascii=False))

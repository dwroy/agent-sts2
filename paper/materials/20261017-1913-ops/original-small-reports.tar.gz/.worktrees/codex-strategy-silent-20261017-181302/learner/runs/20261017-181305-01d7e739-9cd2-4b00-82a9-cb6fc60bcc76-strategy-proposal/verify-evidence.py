import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('extract', OUT.parents[1] / 'extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['runs']
selected = {}
checks = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    counts = collections.Counter()
    entries = []
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
        for line in path.open():
            entry = json.loads(line)
            assert entry['source'] == str(ROOT / 'logs' / (name + '.jsonl'))
            assert entry['offset'] + entry['bytes'] <= stream['source_size']
            source.seek(entry['offset'])
            raw = source.read(entry['bytes'])
            assert len(raw) == entry['bytes'] and raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == entry['sha256']
            assert json.loads(raw) == entry['row']
            assert extract.run_identity(entry['row']) == entry['run_id'] in runs
            counts[entry['run_id']] += 1
            entries.append(entry)
    assert {r: counts[r] for r in runs} == stream['counts']
    checks.append({'stream': name, 'source_size': stream['source_size'], 'verified_lines': sum(counts.values()), 'counts': dict(counts), 'ok': True})
    selected[name] = entries
(OUT / 'raw-readback-verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
scope = {
    'VLZ6CCT8AQ0A': [35, 36, 37, 43, 44, 45],
    '8JRE1C4H4Z2W': [17, 33],
    'CA5KE8GFJ9X2': [5, 9, 13],
    '5PM6JAQG6FNQ': [33, 38, 39],
    '61E2QS63Y9WU': [17, 23, 28],
    'DUZUBAJ3A8GP': [27, 28, 29, 30],
}
states = []
decisions = []
inputs = []
for run, floors in scope.items():
    ss = [e for e in selected['states'] if e['run_id'] == run and e['row'].get('state', {}).get('run', {}).get('floor') in floors]
    dd = [e for e in selected['decisions'] if e['run_id'] == run and e['row'].get('floor') in floors]
    for e in ss:
        state = e['row']['state']
        combat = state.get('combat') or {}
        player = combat.get('player') or {}
        states.append({'line': e['line'], 'run': run, 'floor': state['run']['floor'], 'turn': state.get('turn'),
                       'observed_ts': e['row'].get('observed_ts'), 'screen': state.get('screen'),
                       'hp': player.get('current_hp', state['run'].get('current_hp')), 'max_hp': state['run'].get('max_hp'),
                       'block': player.get('block'), 'energy': player.get('energy'), 'powers': player.get('powers'),
                       'enemies': combat.get('enemies'), 'hand': combat.get('hand'), 'potions': state['run'].get('potions')})
    for e in dd:
        row = e['row']
        decisions.append({'line': e['line'], **{k: row.get(k) for k in ['run_id', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label', 'chosen', 'result', 'rationale', 'questions', 'answers', 'journal', 'rollout', 'potions', 'hp_guard', 'sl_explore', 'selection_audit']}})
    run_row = next(e['row'] for e in selected['runs'] if e['run_id'] == run)
    missing = [e['line'] for e in dd if not e['row'].get('decision_id')]
    data = {'run': run_row, 'decisions': [dict(e['row'], _line=e['line']) for e in dd], 'states': [dict(e['row'], _line=e['line']) for e in ss]}
    raw = json.dumps(data, ensure_ascii=False).encode()
    with gzip.open(OUT / (run + '.consumer-input.json.gz'), 'wb') as dest:
        dest.write(raw)
    inputs.append({'run_id': run, 'scope_floors': floors, 'decisions': len(dd), 'states': len(ss), 'missing_decision_id_lines': missing, 'input_bytes': len(raw), 'input_sha256': hashlib.sha256(raw).hexdigest()})
(OUT / 'selected-state-facts.json').write_text(json.dumps(states, ensure_ascii=False, indent=2) + '\n')
(OUT / 'selected-decision-facts.json').write_text(json.dumps(decisions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'consumer-input-manifest.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n')
(OUT / 'attempt-facts.json').write_text(json.dumps(selected['sl-attempts'], ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'raw_checks': checks, 'consumer_inputs': inputs, 'projected_states': len(states), 'projected_decisions': len(decisions)}, ensure_ascii=False))

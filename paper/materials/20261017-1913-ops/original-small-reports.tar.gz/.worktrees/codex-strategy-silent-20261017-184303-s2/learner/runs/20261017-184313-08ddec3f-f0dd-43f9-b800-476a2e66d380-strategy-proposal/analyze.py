import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
WT = OUT.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
TARGETS = {
    'KEN58SH9SLZ6': [3, 4, 5, 11, 12, 15, 16, 17],
    'TXZ6RVMQA09D': [43, 45, 46, 48, 49],
    'WQZVENQ7DTRP': [25, 28, 30, 33],
    '1913SE84AXQF': [17, 19, 23, 24, 28, 29, 31],
    'Q6M2Y34MWKRE': [2, 3, 5, 6, 7, 8, 9],
    'NHA2KW0RB7VP': [17, 19, 30, 33],
}

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

extract = module('extract', WT / 'learner/extract_evidence.py')
resource = module('resource', WT / 'learner/resource_chain.py')
runs = {**json.loads((OUT/'runs-verified.json').read_text()),
        **json.loads((OUT/'supplemental-runs-verified.json').read_text())}
selected = {k: {'run': runs[k], 'states': [], 'decisions': [], 'sl': []} for k in TARGETS}
verified = []
for folder in ['evidence', 'supplemental-evidence']:
    manifests = json.loads((OUT/folder/'evidence-manifest.json').read_text())
    for manifest in manifests:
        stream = manifest['stream']
        path = OUT/folder/(stream+'.evidence.jsonl')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
        counts = dict.fromkeys(manifest['counts'], 0)
        with (ROOT/'logs'/(stream+'.jsonl')).open('rb') as source, path.open() as f:
            for line in f:
                e = json.loads(line)
                assert e['offset']+e['bytes'] <= manifest['source_size']
                source.seek(e['offset']); raw = source.read(e['bytes'])
                assert hashlib.sha256(raw).hexdigest() == e['sha256']
                row = json.loads(raw)
                assert row == e['row'] and extract.run_identity(row) == e['run_id']
                counts[e['run_id']] += 1
                ident = e['run_id']
                if stream == 'states':
                    state = row['state']; info = state.get('run') or {}
                    assert info.get('character_id', '').lower() == 'silent'
                    assert info.get('ascension') == runs[ident]['ascension']
                if ident not in selected:
                    continue
                if stream == 'sl-attempts':
                    selected[ident]['sl'].append(row)
                elif stream in ('states', 'decisions'):
                    floor = row['state']['run']['floor'] if stream == 'states' else row.get('floor')
                    if floor in TARGETS[ident]:
                        selected[ident][stream].append({**row, '_line': e['line']})
        assert counts == manifest['counts']
        verified.append({'folder': folder, **manifest, 'verified_rows': sum(counts.values())})
save('evidence-verification.json', verified)

summaries = []
annotations = []
for ident, data in selected.items():
    starts = {}
    for attempt in data['sl']:
        if attempt.get('attempt', 1) > 1 and attempt.get('started_at'):
            starts.setdefault(attempt['floor'], []).append(attempt['started_at'])
    chain = resource.resource_chain(data['states'], ident, 'silent', starts)
    chain['sl_events'] = data.pop('sl')
    save(ident+'.resource-chain.json', chain)
    # Route-change annotations are not dispatched actions and have no decision identity.
    annotations.extend({'run': ident, 'row': r, 'reason': 'route_annotation_outside_action_audit'}
                       for r in data['decisions'] if r.get('label') == 'map/route-change')
    data['decisions'] = [r for r in data['decisions'] if r.get('label') != 'map/route-change']
    save(ident+'.consumer-input.json', data)
    result_path = OUT/(ident+'.selection-audit.json')
    with result_path.open('w') as f, (OUT/(ident+'.consumer.stderr')).open('w') as err:
        result = subprocess.run(['node', '--import', 'tsx', '../learner/audit-selection.ts',
                                 str(OUT/(ident+'.consumer-input.json'))], cwd=WT/'agent',
                                stdout=f, stderr=err)
    assert result.returncode == 0, (ident, result.returncode)
    audit = json.loads(result_path.read_text())
    summaries.append({'run': ident, 'floors': TARGETS[ident], 'consumer_exit': result.returncode,
        'input_sha256': hashlib.sha256((OUT/(ident+'.consumer-input.json')).read_bytes()).hexdigest(),
        'output_sha256': hashlib.sha256(result_path.read_bytes()).hexdigest(),
        'decisions': len(data['decisions']), 'states': len(data['states']),
        'segments': len(audit['segments']),
        'observed_turns': sum(t['status'] == 'observed_turn_endpoints' for t in audit['observed_turns']),
        'full_candidate_certified': sum(s['actual_full_candidate_result'] is not None for s in audit['segments']),
        'combats': [{k:c.get(k) for k in ('sequence','floor','end','observed_net_hp_loss')}
                    | {'entry_hp':c['entry']['hp'], 'last_hp':c['last']['hp'],
                       'exit_hp':c['exit']['hp'] if c['exit'] else None} for c in chain['combats']]})
    print(ident, 'offline consumer', result.returncode, flush=True)
save('consumer-summary.json', summaries)
save('consumer-route-annotations.json', annotations)

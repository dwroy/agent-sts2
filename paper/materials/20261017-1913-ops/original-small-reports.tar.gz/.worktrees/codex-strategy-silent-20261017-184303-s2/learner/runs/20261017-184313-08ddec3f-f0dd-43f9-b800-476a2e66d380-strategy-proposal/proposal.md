# 本批静默策略提案核验与沙坑日志子项

本批 20261017-184303-s2-strategy-proposal，来源/实现任务 strategy-proposal，角色 silent。派发十个原 id，不新领取队列，不重建 id；非专题、非 implementation_request。初始工作树干净，按要求 merge main 返回 Already up to date；base=f39a1b8e9678fddee682dcb83b4b1e8675df352e。Roy-2026-10-07-learning 是权限依据，不提供游戏事实。

## 本批实际实现的范围

原 a327449c331efbc1 明确允许先补确定信息的比较/记录。现 silent-sl-resource-comparison.ts 已记录同盘血价、伤害、格挡、毒与污染，遗漏 Outcome.sandpitAfter。补每线 sandpit_after_enemy_turn、wins_fight 及替线减原线沙坑差额；复用原求解器结果，不新推机制。字段仅进入 SL 日志，现两处调用的选择、原答覆盖和派发路径不变。普通角色/未观察进阶仍不产生此记录，无新增药价、必死/SL门槛、排序/终局参数或知识前缀。

证据 WQZVENQ7DTRP A10 F33 末次 T7：原帧282330的26HP、敌245HP、20毒、沙坑4、25攻击；282331逃离后沙坑5；282334/282335为21挡；282336下一轮22HP、敌221HP、沙坑4。相同冻结282330盘面复算两防御/小刀/生存者与逃离/防御/小刀/生存者：0/4损、24/24伤、敌方回合后沙坑3/4。前者是同盘模型比较，不能标为实际完成的原线；后者局部端点与日志吻合。生存者结束在弃牌选择边界，保留“弃牌选择未确定”，整条候选执行仍 unverified。

反例约束：T9另一个局部窗口多15伤付9HP，两线皆败；T7多4HP也延长时钟，故不能笼统以多损血禁止替线。模型未证明延时足以抵攻击，未证明原线通关。null 不转换成零：胜战/无活跃时钟/缺预测分别由 wins_fight 和原空值保留；任一随机药水中位线或缺线不计算差额。

验证：两项新增固定测试覆盖实帧复算、差额、输入不可变、缺字段、战斗结束、随机药水中位值；现有实际 planner 回放断言验证派发意图等价。撤回本源码而保留测试必须失败，恢复后整文件通过；再跑规定 sandbox。最初夹具在生存者弃牌后继续出牌导致 replay null，已改为选择边界前结束，初次红/绿失败日志保留；有效撤源/恢复结果另存 red-green.json。源码原字节保存在 *.before.txt，补丁只涉及一个生产源和固定测试/原帧。

此子项只完善诊断，a327 原整项仍 waiting。按独立局及时间切分后验证饱和排序，不把一局SL尝试/推演样本当独立局。需要新增受控整战及后移独立局，才研究数值门槛。回退仅撤本提交的三叶；保留原日志、账本、原提案和其他实现。日志发布按 docs/eval.md 不新增行为编号；不以源码/测试完成宣称自然胜率收益或原宽父完成。

## 十个原提案的逐项处置

### silent-proposal-08eaa60bcc449852

原摘要：核赢战耗药与真实回复到boss入口的资源结转；缺未饮用/留药整战对照保留现价值规则

账本：silent-0019, silent-0020。原文：[silent-proposal-08eaa60bcc449852.original.md](silent-proposal-08eaa60bcc449852.original.md)，原 SHA256 `4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`。

证据：KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1-T2/F15T1；F12/F16回复。F5胜战53→16，F15零损仍消耗两药。

处置：waiting。缺同入口、牌组与后继动作的不饮用、提前饮用或留至Boss的成对整战结果；实际七次饮用与回复不能校准持药价值。

### silent-proposal-92920295a648b540

原摘要：固定核对SL T6少损3也少伤9、首战赢后4血与F49开场死；三尝试按同局资源链验收，禁止将首胜/低可信0%当连战改善或SL依据，缺通关对照时保留原规则并等待新局。

账本：silent-0228, silent-0255。原文：[silent-proposal-92920295a648b540.original.md](silent-proposal-92920295a648b540.original.md)，原 SHA256 `f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`。

证据：TXZ6RVMQA09D A10 F48第二/三试T6，原36伤/3损、替27伤/0损；第三试T10首胜余4、F49开场4→0。

处置：waiting。缺保持后续抽序、生成、选择与药栏一致的两战替线；少损3同时少伤9不是连续通关改善，低可信模拟不能放宽SL资格。

### silent-proposal-a327449c331efbc1

原摘要：复验沙虫全败探索同盘面9血换15伤与4血换沙坑一轮，保留血价、毒、沙坑两边界比较；缺独立胜局及完整反事实，不拟固定阈值，不放宽必死SL，行为证据不足部分保留waiting。

账本：silent-0079, silent-0018。原文：[silent-proposal-a327449c331efbc1.original.md](silent-proposal-a327449c331efbc1.original.md)，原 SHA256 `e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`。

证据：WQZVENQ7DTRP A10 F33第二/三试T9同指纹，13损/24伤→22损/39伤；末试T7支付4血增加沙坑，states282330—282336。

处置：waiting。本批补沙坑轮末预测及差额日志；仍缺约束抽序、后续动作、毒与沙坑的成对整战后继和独立验证局，不能由9HP/15伤拟合排序阈值或关闭整项。

### silent-proposal-a099e89437e942bb

原摘要：狡诈药水确定生成与剩余手位、计划妥当保留容量及出刀穿插完整序列核验

账本：silent-0030, silent-0257, silent-0258。原文：[silent-proposal-a099e89437e942bb.original.md](silent-proposal-a099e89437e942bb.original.md)，原 SHA256 `e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`。

证据：WQZVENQ7DTRP A10 F33第五/六试T11，新增小刀2/0/0与3/2/0；SADL3CGYTGSR A7 F8T1与NB8KCF6HRGVF A10 F31T5有位添3。

处置：waiting。已有生成与容量子实现；缺计划妥当保留、跨抽牌/重问的完整候选归属、SL恢复的联合消费者和穿插用药整战对照，不能整项duplicate。

### silent-proposal-47910f82a1fdd98f

原摘要：无小血瓶王室猛毒开场4血续战入口、SL同盘攻防/沙坑代价与真实资源结转

账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。原文：[silent-proposal-47910f82a1fdd98f.original.md](silent-proposal-47910f82a1fdd98f.original.md)，原 SHA256 `d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`。

证据：TXZ6RVMQA09D A10 F43/F45/F46/F48/F49出牌前净失4，F49以4血进入后0血；WQZVENQ7DTRP F33T7/T9血价与沙坑分账。

处置：waiting。已有限定开场资源模型；缺未知回血/复活组合结算、留药/路线/SL成对后继及两战生产联合校准，不将窄公式视作整项资源策略完成。

### silent-proposal-f1374df72d8e6a25

原摘要：将胜战退出HP与药栏接入下一战评估，核对低置信选线和持续/临时药价；证据不足先保留阈值

账本：silent-0019, silent-0020, silent-0050, silent-0253。原文：[silent-proposal-f1374df72d8e6a25.original.md](silent-proposal-f1374df72d8e6a25.original.md)，原 SHA256 `df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`。

证据：1913SE84AXQF A10 F17胜余14、F29胜61→46、F31死；Q6M2Y34MWKRE A10 F2T1低信心0.29，F8胜57→2、F9T2死。

处置：waiting。缺隔离机制误差后，同入口同预算的不用/早用/留药整战及下一战成对结果；局部候选与低信心答选不能反推新药价、护栏或终局权重。

### silent-proposal-38a49e6c97f31eea

原摘要：第83批静默经验：紧勒逐牌失血与增益分源固定帧闭环

账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。原文：[silent-proposal-38a49e6c97f31eea.original.md](silent-proposal-38a49e6c97f31eea.original.md)，原 SHA256 `6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`。

证据：Q6M2Y34MWKRE A10 F8T4紧勒后逐牌多4；1913SE84AXQF A10 F31T2弃磨蚀建立1敏/4荆棘、T4仍死；Q6 F8T1速度只兑现当轮。

处置：waiting。普通紧勒、已观察磨蚀及速度有子实现；缺弃磨蚀、常驻/临时增益、再生/自动触发与SL恢复的联合消费者、受控完整后继，不能拼成整项完成。

### silent-proposal-ef0e38a5dbd3bc07

原摘要：第83批静默经验：精英胜后连续血价与实际回复/能力资源链核验

账本：silent-0019, silent-0020, silent-0021。原文：[silent-proposal-ef0e38a5dbd3bc07.original.md](silent-proposal-ef0e38a5dbd3bc07.original.md)，原 SHA256 `d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`。

证据：1913SE84AXQF A10 F24锻造未回血、F28休息+21、F29胜后46进F31；Q6M2Y34MWKRE F7休息+21、F8赢损55至2后F9死。

处置：waiting。缺另一营火动作、事件/路线和用药时点的受控完整结果；实际条件变更及两条失败链有敌人/构筑/选择混杂，不能拟合路线或终局参数。

### silent-proposal-7f820c02d39bfaea

原摘要：死亡统计饱和的SL替换须显式比较即时血价与击杀、存活推进，门槛等待固定验证

账本：silent-0079。原文：[silent-proposal-7f820c02d39bfaea.original.md](silent-proposal-7f820c02d39bfaea.original.md)，原 SHA256 `bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`。

证据：NHA2KW0RB7VP A10 F33第1—4试T1原线14挡/1损/跨轮净扣8，第5/6试8挡/7损/净扣24，六试均败。

处置：waiting。缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；同局六败非六独立局，不能由6HP/16伤确定血价门槛。

### silent-proposal-04b6b430759815ed

原摘要：按静默实帧核油灯首次放大、当前手数/脆弱/能量、蟹朝向取整及能力兑现；只修已观察子公式和估值窗口

账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。原文：[silent-proposal-04b6b430759815ed.original.md](silent-proposal-04b6b430759815ed.original.md)，原 SHA256 `188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`。

证据：NHA2KW0RB7VP A10 F33T1首次X1萎靡−2力/2弱，F17首毒5→10；K3676LU8B0UH A1 F30T2毒4→8，SADL3CGYTGSR A7 F45毒5→10。

处置：waiting。蟹朝向取整和普通精确切击有受限实现；缺油灯首次消费跨动作、新战/SL恢复的联合输入及消费者、未覆盖X值/升级/叠层与能力完整后继，不能整项duplicate。

## 冻结输入与证据边界

派发十局已核 runs.jsonl 全为 Silent，其中 F4Q 为A9、其余A10；原提案还直接引用1913SE84AXQF/Q6M2Y34MWKRE/NHA2KW0RB7VP/K3676LU8B0UH/SADL3CGYTGSR五局，补核角色与进阶，只作本批原提案补证，不扩展其他队列或读取其他角色知识。两组均使用共用 extract_evidence.py：16流共19929封套，逐行回读原 source offset/bytes/SHA/JSON/明确局身份，run-plans 按 run。各 source_size 独立保存；fight-plans 两组零行仅说明该截点未选中。

六份离线消费者只处理 consumer-summary.json 列明楼层；原始所有抽取保留。map/route-change 是无 decision_id 的路线注释，不属于动作消费者：初始原输入被拒绝，保留 rejected-input、stderr 与原行；两条注释分别为 KEN 274207、Q6 276607，另存 consumer-route-annotations.json，未补造标识/时间。动作间原行号缺口仍可见，不填补候选执行或SL身份。完整候选认证均为空仅为该工具的认证边界，不能证明未执行。Q6零可核整轮不代表无实盘状态。

当前源码叶及实际 live 祖先见 source-snapshot.json。已有狡诈6403fdc、紧勒5c7105f、磨蚀d06acd4、开场扩展ebf8c57、蟹取整f2c7cc1、精确切击75a27fb、SL日志1698adc均核是 base/live 祖先；原异树15ea09a/fc7042d非祖先，不拿它们当上线证明。14叶中三叶只存在历史 Roy/Dai 注释差异；本批不改这些叶。原局均dirty运行树，当前源码核验不恢复其全部历史字节。

药水/路线/能力/SL的原结论限制保持，未发现需强行支持旧假设或新增科学异议的证据。本批经验库未更新，父要求未关闭，shipped 留运维核实。实际提交、测试与live处置以 report.md 最终回执为准。

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE / 'evidence'
FLOORS = {
    'DUZUBAJ3A8GP': [27],
    '5PM6JAQG6FNQ': [38, 39],
    'CA5KE8GFJ9X2': [13],
    '8JRE1C4H4Z2W': [17, 33],
    'YF0LXT1QSTGG': [33, 48],
    'XP2SL33HT0D9': [33],
}


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(items):
    return {p.get('power_id', p.get('id')): p.get('amount') for p in items or []}


def state_snapshot(item):
    row = item['row']
    state = row['state']
    info = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'], 'sha256': item['sha256'],
        'observed_ts': row.get('observed_ts'), 'floor': info.get('floor'), 'turn': state.get('turn'),
        'screen': state.get('screen'), 'hp': player.get('current_hp', info.get('current_hp')),
        'block': player.get('block'), 'powers': powers(player.get('powers')),
        'played': player.get('cards_played_this_turn'), 'potions': info.get('potions'),
        'enemies': [
            {**{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id', 'intents')},
             'powers': powers(e.get('powers'))}
            for e in combat.get('enemies') or []
        ],
    }


def main():
    manifest = json.loads((EVIDENCE / 'evidence-manifest.json').read_text())
    identities = {r['run_id']: r for r in json.loads((HERE / 'run-identities.json').read_text())}
    selected = {r: {'run': identities[r], 'decisions': [], 'states': []} for r in FLOORS}
    snapshots = defaultdict(list)
    decisions = defaultdict(list)
    verification = []
    excluded = []
    for stream in manifest:
        name = stream['stream']
        counts = Counter()
        output = EVIDENCE / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source, output.open('rb') as frozen:
            for encoded in frozen:
                digest.update(encoded)
                item = json.loads(encoded)
                source.seek(item['offset'])
                raw = source.read(item['bytes'])
                assert len(raw) == item['bytes']
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                run = item['run_id']
                assert run in FLOORS
                counts[run] += 1
                row = item['row']
                if name == 'states':
                    state = row['state']
                    info = state.get('run') or {}
                    assert str(info.get('character_id')).lower() == 'silent' and info.get('ascension') == 10
                    if info.get('floor') in FLOORS[run]:
                        selected[run]['states'].append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
                        snapshots[run].append(state_snapshot(item))
                elif name == 'decisions' and row.get('floor') in FLOORS[run]:
                    if not row.get('decision_id'):
                        excluded.append({'run_id': run, 'line': item['line'], 'reason': '无decision_id的元数据，不传给消费者；原封套保留'})
                        continue
                    selected[run]['decisions'].append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
                    decisions[run].append({
                        **{k: row.get(k) for k in ('decision_id', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label', 'observed_ts', 'chosen', 'result', 'answers', 'hp_guard', 'sl_explore', 'journal')},
                        'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'], 'sha256': item['sha256'],
                    })
        assert digest.hexdigest() == stream['output_sha256']
        assert dict(counts) == {k: v for k, v in stream['counts'].items() if v}
        verification.append({'stream': name, 'source_size': stream['source_size'], 'verified_lines': sum(counts.values()), 'counts': dict(counts), 'output_sha256': digest.hexdigest()})
    inputs = []
    for run, value in selected.items():
        save(run + '-audit-input.json', value)
        save(run + '-snapshots.json', snapshots[run])
        save(run + '-decisions.json', decisions[run])
        inputs.append({'run_id': run, 'floors': FLOORS[run], 'decisions': len(value['decisions']), 'states': len(value['states']),
                       'input_sha256': hashlib.sha256((HERE / (run + '-audit-input.json')).read_bytes()).hexdigest()})
    save('verification.json', {'streams': verification, 'inputs': inputs, 'metadata_exclusions': excluded,
                               'scope': '六局完整八流封套核验；离线消费者仅分析指定楼层，不认证完整候选或整战因果'})
    print(json.dumps({'verified_lines': sum(x['verified_lines'] for x in verification), 'inputs': inputs, 'metadata_exclusions': excluded}, ensure_ascii=False))


if __name__ == '__main__':
    main()

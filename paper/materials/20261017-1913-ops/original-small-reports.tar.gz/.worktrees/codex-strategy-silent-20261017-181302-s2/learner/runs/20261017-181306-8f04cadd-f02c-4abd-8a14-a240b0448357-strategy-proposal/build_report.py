import hashlib
import importlib.util
import json
import subprocess
from collections import defaultdict
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261017-181302-s2-strategy-proposal'

DETAILS = [
    ('c20b5139dd0dff71', 'DUZUBAJ3A8GP F27 T4—T6',
     'states 274830—274839：火花3→6；技能污染逐次0→3→6及0→6→12→18，次轮不再列出污染。T4迷雾同时施毒/弱，不能只把技能算成代价。',
     '当前turn-solver消费现场vitalSpark并保留污染参考，rollout有VITAL_SPARK_POWER后继；这些接线不等于本局历史移动表和完整联合后继已校准。',
     '未取得本局dirty A10移动表的可验证冻结字节，以及火花增长、污染清除、毒/弱/挡连续后继的生产联合校准；不足以认证宽提案或禁止技能策略。',
     '以原表、实际技能前缀和次轮状态固定输入，逐步比较污染/意图/毒/挡；未来独立局检验完整替线。'),
    ('ae9e692d680e3819', '5PM6JAQG6FNQ F39 T3—T6',
     'states 274347/274351：力敏各−2→−4；274358失落退场后玩家力量不再列出，遗忘仍有4敏；274362再次夺敏，玩家−2、遗忘6。末次单步法仅回−2敏仍死。',
     '当前模型可读现场负属性；总值也受步法等来源影响，不能由当前负值倒推出每个敌人的累计抢夺或返还账。',
     '缺逐实体累计抢夺真值、连续实例身份及遗忘退场返敏/再次抢夺的完整固定链；固定击杀顺序没有受控整战胜线。',
     '补稳定实例或完整召唤/退场链与每次夺取/返还原帧，复验负属性和重新抢夺；不得从总属性反填被夺数。'),
    ('52f1e1bd2e7db0ed', 'CA5KE8GFJ9X2 F13 T1—T5',
     'states 273237—273269：喷水11→15→19、力量0→4→8；T5弱后14、玩家2血10挡后归零。覆甲所见9/9/8/7/6只作现场层数，不推完整减层条件。',
     'monster-db的moveDamageAt在有当前进阶事实时直接使用，无五样本守卫；room-costs与房间代价仍保留5样本门槛。当前接口存在不等于历史加压/覆甲联合重放已完成。',
     '缺实际历史A10移动表和加压/覆甲全过程联合校准；原决策SL尝试元数据为null，不能补造尝试身份或认证整轮候选执行。',
     '保留未知身份，取得原调用输入后用T1/T3/T5固定值校验；覆甲未知条件保持未知，不把房间样本门槛移到怪物事实。'),
    ('6dd8bbff876be528', '5PM6JAQG6FNQ F38 T3—T4',
     'states 274308/274313：23上限电击所见力量2→4、攻击17→19；数组index4→3，不据index固定实例。T3仍贡献17攻，T4才退场。另一35伤/损3候选未实打。',
     'rollout已有HIGH_VOLTAGE_POWER逐敌增长路径；唯一类型端点可比较，召唤代际与被替换实体不由此确定。',
     '缺可靠召唤代际身份、原实际移动表及连续增长后继校准；现有增长代码不足以认证跨代重置或改变击杀序。',
     '冻结生成/退场原帧和每代首值，验证同代增长及新代初始值；用独立完整战斗检查另一目标顺序。'),
    ('578e415a259e6835', '8JRE1C4H4Z2W F17 T6；F33 T2/T5/T11',
     'decisions270216/270282同指纹，首/三试T2到次轮净损3/15、敌净扣10/17；0/24与5/24死亡样本并不相同。末试T11为5血22挡对37攻击，实扣5与显示差15分列。',
     'selection_audit、hp_guard_audit、单动作selection_dispatch及离线observed_turns已覆盖部分追溯；完整候选收益仍为空。护栏后抽弃牌重问会改变实际前缀。',
     '缺重规划后完整候选续步身份、沙坑逐来源结算及路线资源归属；本局相关SL尝试不能提供新的独立整战验证。',
     '保留原答/护栏/SL/派发各层，以连续身份和资源账验每次截断；新独立局验证策略，不能把候选省血记成实得收益。'),
    ('c0767768bf6a7ab1', 'YF0LXT1QSTGG F48 第二/三试T1；第四试T5；F33',
     'decisions271309/271348同指纹，原始起点至T2观测净损0/9、敌净扣45/38。第四试T5弃牌后回防御线是未完成候选反例；F33第二试实胜，不能否定全部SL。',
     '现有候选/单动作/重问审计可逐层查看；死亡比例相等仅为有限样本事实，不认证替线安全或完整执行。',
     '缺完整候选执行与血价归属、同抽序完整替线和独立整战验证；0/9与45/38只证起点后的观测净差。',
     '冻结相同起点和后续抽序，保留未执行续步/重问；补原失败线换线后实胜的独立反例，再评估阈值。'),
    ('a46bdb7fe711d79a', 'YF0LXT1QSTGG F48 末试T3—T5',
     'states277512/277513换相111→212并清旧毒/力；277521—277527既有23挡在敏捷5→6后不倒补，四小刀与消耗另源合37净扣；零毒时触媒2不产生额外毒伤。',
     '现有离线interval保留HP/最大HP、手牌和能力；阶段规则已有窄实现，仍不能替代逐候选施毒/结毒/额外失血/敏捷取得顺序的联合来源账。',
     '缺逐候选施毒与毒伤、额外扣血、敏捷取得顺序的来源归属及完整派发联合认证；窄换相修复不能代替整个提案交付。',
     '同固定输入逐步核零毒、换相、23挡及消耗附伤，保留前五试已建能力仍败的反例；后续独立局验证选线。'),
    ('1044224808015e5c', 'XP2SL33HT0D9 F33 首/二试T3；首/末试T1',
     'decisions271992/272040同指纹：净损9/14、敌净扣24/27；271982/272195同指纹：净损2/10、敌净扣25/34。后者含手里剑成长，不能只按血差判全部换线错误。',
     '候选审计保留hp_loss/damage/strength/lasting差；B2零胜并列与五轮死亡饱和是不同条件，不能称零差即安全。',
     '缺同抽序完整替线、成长兑现受控后继及独立整战胜线；不能据这几组当轮差值拟合保血优先或血价参数。',
     '固定当轮9/14、2/10和成长次序作回归；以run_id分组、后置独立局验证策略，保留原探索选择。'),
    ('7cbc6005db712ba9', 'XP2SL33HT0D9 F33 末试T2—T5',
     'states278236—278242轮初14挡、镣铐0→−9力、斗篷后20挡；T3恢复。278249—278255激光57→38→28、4敏脆弱偏折得6挡；T5实扣11、毒扣3+7，两敌仍153/125。',
     '现场已有挡、临时减力及候选结果已有入口；当前观测保留两次朝向/虚弱变换。完整逐候选来源分解与端到端存活核验仍未齐。',
     '缺逐候选原有/新增挡、朝向与虚弱、已结算毒、存活HP的统一来源校准；局部数字吻合不等于完整候选已执行。',
     '固定57→38→28、14+6→20、0→−9→恢复、6挡与终局11净损，逐项分源；不把观测参考换成未见条件的硬规则。'),
    ('c59f592f1427a67e', 'YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1—T5',
     '两局三组同指纹配对再次核实；YF已建触媒/敏捷与XP临时减力/轮初挡分别有原帧。SL恢复、路线回血、药槽恢复应分账；原101局等历史分母未在本批重算。',
     '宽提案汇集的部分机制、预测审计、回执与离线观测已有窄实现；这些子项不能合并宣称完整资源归属或策略量化已完成。',
     '缺逐来源资源账、完整候选归属、路线药水时机及受控整战后继；本批仅六个来源局，不能代替原历史分母或认证药水/路线因果。',
     '复用各原提案和账本，补完整资源链及独立后置整战；不重复登记新id，不重写历史复盘或把全败样本变成策略权重。'),
]


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    dispatch = json.loads((HERE / 'dispatch.json').read_text())
    base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    assert base == 'f39a1b8e9678fddee682dcb83b4b1e8675df352e'
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    proposals = {i: json.loads((HERE / (i + '.json')).read_text())['original'] for i in dispatch['proposal_ids']}
    assert {'silent-proposal-' + d[0] for d in DETAILS} == set(proposals)
    consumers = json.loads((HERE / 'consumer-results.json').read_text())
    verification = json.loads((HERE / 'verification.json').read_text())
    source = json.loads((HERE / 'source-readback.json').read_text())
    results = [{'id': 'silent-proposal-' + d[0], 'state': 'waiting', 'reason': d[4]} for d in DETAILS]
    final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': base,
             'runs': dispatch['runs'], 'fixes': [], 'skipped': [{'id': x['id'], 'reason': x['reason']} for x in results],
             'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
             'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [], 'proposal_results': results,
             'report': str(HERE / 'report.md')}
    save('result.json', final)
    now = datetime.now().astimezone().isoformat(timespec='seconds')
    text = [f'# 本批十项静默策略提案复核\n\n时间：{now}；batch：{BATCH}。',
            f'角色：silent；观察范围：六局A10。基线：`{base}`。普通队列派发，未绑定research_request或implementation_request；未接其他专题。',
            '本批结论：十项均保留waiting。核实了既有局部机制、资源净差和当前源码的窄覆盖；未发现足以支持新增策略源码的确定失配，缺口列于各项。未新增经验或策略参数。']
    for suffix, where, evidence, existing, reason, validation in DETAILS:
        key = 'silent-proposal-' + suffix
        old = proposals[key]
        text += [f'## {key}\n\n原摘要：{old["summary"]}\n\n证据：{where}。账本：{", ".join(old["ledger"])}。',
                 evidence, f'旧行为及现有覆盖：{existing}',
                 f'预期行为：{old["summary"]} 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。',
                 f'处置：waiting。{reason}', f'验证方法：{validation}',
                 f'原Markdown：`{old["proposal"]}`；SHA256 `{old["proposal_sha256"]}`，本批副本`{key}.md`。原source_task={old["source_task"]}，target_task=strategy-proposal；不另建重复id。']
    text += ['## 样本、反例与回退\n\n四组相同指纹仅能控制所列起点。8JRE T2多12血换7净扣、YF T1多9血且少7净扣、XP T3多5血换3净扣、XP T1多8血换9净扣；差值包含后续重问，未归因给完整候选。原提案的已建能力仍败、防御换线延后但仍死、SL在F33实胜、未执行候选等反例全部保留。六试同存档不能作六个独立局。本批六局是发现/回归证据，未进行新独立后置整战验证，不估胜率或最优血价。',
             '铁甲战士及未观察角色/进阶行为不变。本批无生产补丁可回退；后续窄实现须冻结全部必要输入、撤生产源码失败/恢复通过并跑原沙箱入口，再按live流程上线。缺数据继续由原队列等待新局，不关闭宽请求。']
    (HERE / 'proposal.md').write_text('\n\n'.join(text) + '\n')
    report = [f'# 策略学习复核报告\n\n时间：{now}；角色silent；batch `{BATCH}`。',
              f'结果：十项waiting，无新源码、无提交、无合入、无新版本。base=`{base}`，merged=null，工作树tracked/index干净。',
              '## 身份和范围\n\n根learn.json仅复制本批对应行，task/character/worktree及十原id核对相符；reason=proposal，本批无research_request/implementation_request。普通专题文件的batch属于20261010-150327，未接其专题。普通main合并返回Already up to date。六局runs.jsonl均为SILENT/A10，code均带dirty；完整身份见run-identities.json。原任务请求high；实际启动命令为gpt-6.1-sol/xhigh/service_tier=default，已据启动记录核实，本会话未改启动器设置或冒报运行强度。',
              '## 可复现证据\n\n八流使用learner/extract_evidence.py共用入口提取；source_size逐流冻结于evidence/evidence-manifest.json，各行保存原offset/bytes/SHA256。analyze.py逐条seek原文件、核字节SHA及JSON，并核抽取输出SHA和计数，共8274条。states/decisions/brain扫描各遇2行全局非法JSON，不能归给本批某局；不据此造局内缺失结论。fight-plans在本截点选中0，仅表示这次未选到，不宣称原日志缺失；run-plans按显式run身份选中33条，没有用正文提及。',
              '|流|冻结字节截点|本批引用数|\n|---|---:|---:|']
    for x in verification['streams']:
        report.append(f'|{x["stream"]}|{x["source_size"]}|{x["verified_lines"]}|')
    report += ['\n六个离线消费者仅指定楼层；输入保留真实原行号/指纹/观测时间，未补SL身份，未重编号。1043条决策/1062帧状态；无元数据排除。各输入/输出SHA、命令退出码和耗时见consumer-results.json，完整输出各`<run>-audit-output.json`。',
               '|局号|分析楼层|消费者退出码|题目片段|可核轮端点|完整候选认证|\n|---|---|---:|---:|---:|---:|']
    for x in consumers:
        report.append(f'|{x["run_id"]}|{x["floors"]}|{x["exit_code"]}|{x["segments"]}|{x["observed_turns"].get("observed_turn_endpoints", 0)}|{x["complete_candidate_results"]}|')
    report += ['\n合计206题目片段、119可核轮端点、66未知窗口、完整候选认证0。null表示未认证，不推断实际没有执行。CA5本局SL元数据为空，DU本窗口也不能补造可核整轮。四组成对指纹及后续轮端点见fingerprint-pairs.json、paired-turn-observations.json；原帧与动作投影见`<run>-snapshots.json`、`<run>-decisions.json`及`<run>-key-facts.json`。',
               '## 当前源码覆盖及限制\n\nsource-readback.json记录base/live引用、每叶SHA/来源提交/祖先布尔及live已提交字节；17叶固定源码仅保存为source/*.txt，baseline.patch为空。当前live引用为`' + source['live_head'] + '`，只作读取时快照，不当六局历史dirty运行树。rollout.ts与live字节相同但main最新同步提交不是该live祖先；不拿这个同步提交冒充实际live源提交。rollout-live.ts和sl/explore.ts与live的差别仅为既有署名注释，原差异保留。',
               '已逐处读取silent-selection-audit、silent-hp-guard-audit、silent-selection-dispatch、combat-plan接线、hand/loop回执和离线selection-execution/observation/terminal/turn消费者。候选预测和单动作回执已有真实live祖先，例如9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、fdaf787a372880b0438e73bcac7e6d2168b038ed、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933。窄子项不认证整个宽提案。完整派发/逐来源资源/历史移动表联合校准和受控整战数据仍缺，不登记十项duplicate或implemented。',
               'monster-db moveDamageAt对已有当前进阶伤害事实直接返回，房间两条代价入口各保留5样本门槛；源码存在不证明本局dirty知识原字节已恢复。没有读其他角色知识、游戏二进制或联网，没有运行play、LLM、rollout求解或战斗模拟。',
               '## 逐项处置\n\n原提案、原账本、证据层/回合、反例、旧行为、缺口及验证见proposal.md。十份原Markdown逐SHA匹配；没有改原文、新增重复id或重写复盘。']
    for x in results:
        report.append(f'- `{x["id"]}`：waiting；{x["reason"]}')
    report += ['## 验证、登记与交付\n\n本批未改生产源码/知识/模板，因此未跑tsc/vitest，不提供撤源码红/恢复绿或成功测试记录；tests固定三null。六次退出0只表示冻结输入离线审计命令成功，未作为测试或策略验证通过。无需live合并、知识刷新提交、版本分配、根双规则通知、shipped或线上收益认定。',
               '只通过根learner/ledger.py update追加本批追溯where/note；不增support/repeat、不修改claim/first_run/prior/asc/evidence/status/version/effect，不把原shipped经验降为proposed，也不把代码提案标shipped。CLI输入与回执、前后前缀保护和保护字段比较将保存ledger-update.json、ledger-cli.log、ledger-integrity.json。提交前扫描不适用（无提交）；本批材料另做脱敏gitleaks扫描，结果见gitleaks.log/final-verification.json。',
               '保留两次临时读取错误：最初用大小写敏感比较将SILENT误判，已按lower重核六局；第一次状态结构探查遇非战斗combat=null，未改数据，随后用可空读取。原错误保留在启动会话日志，首次身份错误说明另存initial-validation-note.txt。几次猜测源码路径未命中后，已用rg --files定位真实路径；不当产品失败、证据不存在或测试失败。',
               f'运维交付提案：`{HERE / "proposal.md"}`。报告：`{HERE / "report.md"}`。机器回报：result.json；最终完整产物SHA见artifacts-manifest.json。']
    (HERE / 'report.md').write_text('\n\n'.join(report) + '\n')
    links = defaultdict(list)
    for key, old in proposals.items():
        for ledger_id in old['ledger']:
            links[ledger_id].append(key)
    updates = [{'id': key, 'by': 'learner:strategy-proposal',
                'where': {'proposal': value + [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                'note': f'{BATCH}仅追溯复核：关联原提案{",".join(value)}均waiting；六个来源A10局的原始引用和有界消费者见本批报告。未追加支持/重复/反例，不改机制结论、首证、prior、证据、状态或版本；局部既有实现不代替宽请求交付。'}
               for key, value in sorted(links.items())]
    save('ledger-update.json', updates)
    spec = importlib.util.spec_from_file_location('ledger_module', ROOT / 'learner/ledger.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    protected = {}
    ledger = ROOT / 'paper/materials/learning/ledger.jsonl'
    raw = ledger.read_bytes()
    for line in raw.splitlines():
        row = json.loads(line)
        if row.get('id') in links:
            module.apply(protected, row)
    save('ledger-before.json', {'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'items': protected})
    print(json.dumps({'base': base, 'proposals': len(results), 'ledger_updates': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))


if __name__ == '__main__':
    main()

# 策略学习复核报告

时间：2026-10-17T18:22:45+08:00；角色silent；batch `20261017-181302-s2-strategy-proposal`。

结果：十项waiting，无新源码、无提交、无合入、无新版本。base=`f39a1b8e9678fddee682dcb83b4b1e8675df352e`，merged=null，工作树tracked/index干净。

## 身份和范围

根learn.json仅复制本批对应行，task/character/worktree及十原id核对相符；reason=proposal，本批无research_request/implementation_request。普通专题文件的batch属于20261010-150327，未接其专题。普通main合并返回Already up to date。六局runs.jsonl均为SILENT/A10，code均带dirty；完整身份见run-identities.json。原任务请求high；实际启动命令为gpt-6.1-sol/xhigh/service_tier=default，已据启动记录核实，本会话未改启动器设置或冒报运行强度。

## 可复现证据

八流使用learner/extract_evidence.py共用入口提取；source_size逐流冻结于evidence/evidence-manifest.json，各行保存原offset/bytes/SHA256。analyze.py逐条seek原文件、核字节SHA及JSON，并核抽取输出SHA和计数，共8274条。states/decisions/brain扫描各遇2行全局非法JSON，不能归给本批某局；不据此造局内缺失结论。fight-plans在本截点选中0，仅表示这次未选到，不宣称原日志缺失；run-plans按显式run身份选中33条，没有用正文提及。

|流|冻结字节截点|本批引用数|
|---|---:|---:|
|states|13974883706|4062|
|decisions|2294280476|3941|
|sl-attempts|45725954|38|
|run-config|1974319|6|
|run-plans|8994618|33|
|brain|758627032|188|
|runs|360542|6|
|fight-plans|2233957|0|


六个离线消费者仅指定楼层；输入保留真实原行号/指纹/观测时间，未补SL身份，未重编号。1043条决策/1062帧状态；无元数据排除。各输入/输出SHA、命令退出码和耗时见consumer-results.json，完整输出各`<run>-audit-output.json`。

|局号|分析楼层|消费者退出码|题目片段|可核轮端点|完整候选认证|
|---|---|---:|---:|---:|---:|
|DUZUBAJ3A8GP|[27]|0|8|0|0|
|5PM6JAQG6FNQ|[38, 39]|0|18|7|0|
|CA5KE8GFJ9X2|[13]|0|4|0|0|
|8JRE1C4H4Z2W|[17, 33]|0|66|44|0|
|YF0LXT1QSTGG|[33, 48]|0|52|40|0|
|XP2SL33HT0D9|[33]|0|58|28|0|


合计206题目片段、119可核轮端点、66未知窗口、完整候选认证0。null表示未认证，不推断实际没有执行。CA5本局SL元数据为空，DU本窗口也不能补造可核整轮。四组成对指纹及后续轮端点见fingerprint-pairs.json、paired-turn-observations.json；原帧与动作投影见`<run>-snapshots.json`、`<run>-decisions.json`及`<run>-key-facts.json`。

## 当前源码覆盖及限制

source-readback.json记录base/live引用、每叶SHA/来源提交/祖先布尔及live已提交字节；17叶固定源码仅保存为source/*.txt，baseline.patch为空。当前live引用为`6f2a20594536087c3453fa9076c5908cbec40e40`，只作读取时快照，不当六局历史dirty运行树。rollout.ts与live字节相同但main最新同步提交不是该live祖先；不拿这个同步提交冒充实际live源提交。rollout-live.ts和sl/explore.ts与live的差别仅为既有署名注释，原差异保留。

已逐处读取silent-selection-audit、silent-hp-guard-audit、silent-selection-dispatch、combat-plan接线、hand/loop回执和离线selection-execution/observation/terminal/turn消费者。候选预测和单动作回执已有真实live祖先，例如9d8278702dbc581b5015ba7ec9a70dc0fb94cccb、fdaf787a372880b0438e73bcac7e6d2168b038ed、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933。窄子项不认证整个宽提案。完整派发/逐来源资源/历史移动表联合校准和受控整战数据仍缺，不登记十项duplicate或implemented。

monster-db moveDamageAt对已有当前进阶伤害事实直接返回，房间两条代价入口各保留5样本门槛；源码存在不证明本局dirty知识原字节已恢复。没有读其他角色知识、游戏二进制或联网，没有运行play、LLM、rollout求解或战斗模拟。

## 逐项处置

原提案、原账本、证据层/回合、反例、旧行为、缺口及验证见proposal.md。十份原Markdown逐SHA匹配；没有改原文、新增重复id或重写复盘。

- `silent-proposal-c20b5139dd0dff71`：waiting；未取得本局dirty A10移动表的可验证冻结字节，以及火花增长、污染清除、毒/弱/挡连续后继的生产联合校准；不足以认证宽提案或禁止技能策略。

- `silent-proposal-ae9e692d680e3819`：waiting；缺逐实体累计抢夺真值、连续实例身份及遗忘退场返敏/再次抢夺的完整固定链；固定击杀顺序没有受控整战胜线。

- `silent-proposal-52f1e1bd2e7db0ed`：waiting；缺实际历史A10移动表和加压/覆甲全过程联合校准；原决策SL尝试元数据为null，不能补造尝试身份或认证整轮候选执行。

- `silent-proposal-6dd8bbff876be528`：waiting；缺可靠召唤代际身份、原实际移动表及连续增长后继校准；现有增长代码不足以认证跨代重置或改变击杀序。

- `silent-proposal-578e415a259e6835`：waiting；缺重规划后完整候选续步身份、沙坑逐来源结算及路线资源归属；本局相关SL尝试不能提供新的独立整战验证。

- `silent-proposal-c0767768bf6a7ab1`：waiting；缺完整候选执行与血价归属、同抽序完整替线和独立整战验证；0/9与45/38只证起点后的观测净差。

- `silent-proposal-a46bdb7fe711d79a`：waiting；缺逐候选施毒与毒伤、额外扣血、敏捷取得顺序的来源归属及完整派发联合认证；窄换相修复不能代替整个提案交付。

- `silent-proposal-1044224808015e5c`：waiting；缺同抽序完整替线、成长兑现受控后继及独立整战胜线；不能据这几组当轮差值拟合保血优先或血价参数。

- `silent-proposal-7cbc6005db712ba9`：waiting；缺逐候选原有/新增挡、朝向与虚弱、已结算毒、存活HP的统一来源校准；局部数字吻合不等于完整候选已执行。

- `silent-proposal-c59f592f1427a67e`：waiting；缺逐来源资源账、完整候选归属、路线药水时机及受控整战后继；本批仅六个来源局，不能代替原历史分母或认证药水/路线因果。

## 验证、登记与交付

本批未改生产源码/知识/模板，因此未跑tsc/vitest，不提供撤源码红/恢复绿或成功测试记录；tests固定三null。六次退出0只表示冻结输入离线审计命令成功，未作为测试或策略验证通过。无需live合并、知识刷新提交、版本分配、根双规则通知、shipped或线上收益认定。

只通过根learner/ledger.py update追加本批追溯where/note；不增support/repeat、不修改claim/first_run/prior/asc/evidence/status/version/effect，不把原shipped经验降为proposed，也不把代码提案标shipped。CLI输入与回执、前后前缀保护和保护字段比较已保存ledger-update.json、ledger-cli.log、ledger-integrity.json。提交前扫描不适用（无提交）；本批材料另做脱敏gitleaks扫描，结果见gitleaks.log/final-verification.json。

保留两次临时读取错误：最初用大小写敏感比较将SILENT误判，已按lower重核六局；第一次状态结构探查遇非战斗combat=null，未改数据，随后用可空读取。原错误保留在启动会话日志，首次身份错误说明另存initial-validation-note.txt。几次猜测源码路径未命中后，已用rg --files定位真实路径；不当产品失败、证据不存在或测试失败。

运维交付提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-181302-s2/learner/runs/20261017-181306-8f04cadd-f02c-4abd-8a14-a240b0448357-strategy-proposal/proposal.md`。报告：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-181302-s2/learner/runs/20261017-181306-8f04cadd-f02c-4abd-8a14-a240b0448357-strategy-proposal/report.md`。机器回报：result.json；最终完整产物SHA见artifacts-manifest.json。


最终核验：30条CLI追溯追加成功，旧账本前缀SHA保持、全部保护字段零差异；gitleaks退出0（334558317字节，未发现泄漏）；六份离线消费者退出0。HEAD仍为完整base，tracked/index及git diff --binary HEAD均空。无源码撤除/恢复测试、无tsc/vitest结果、无合入和行为版本。

# 本批十项静默策略提案复核

时间：2026-10-17T18:22:45+08:00；batch：20261017-181302-s2-strategy-proposal。

角色：silent；观察范围：六局A10。基线：`f39a1b8e9678fddee682dcb83b4b1e8675df352e`。普通队列派发，未绑定research_request或implementation_request；未接其他专题。

本批结论：十项均保留waiting。核实了既有局部机制、资源净差和当前源码的窄覆盖；未发现足以支持新增策略源码的确定失配，缺口列于各项。未新增经验或策略参数。

## silent-proposal-c20b5139dd0dff71

原摘要：冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。

证据：DUZUBAJ3A8GP F27 T4—T6。账本：silent-0168。

states 274830—274839：火花3→6；技能污染逐次0→3→6及0→6→12→18，次轮不再列出污染。T4迷雾同时施毒/弱，不能只把技能算成代价。

旧行为及现有覆盖：当前turn-solver消费现场vitalSpark并保留污染参考，rollout有VITAL_SPARK_POWER后继；这些接线不等于本局历史移动表和完整联合后继已校准。

预期行为：冻结当前技能效果和污染逐击血价；当前进阶从观测数据库取攻击，保留所有选项。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。未取得本局dirty A10移动表的可验证冻结字节，以及火花增长、污染清除、毒/弱/挡连续后继的生产联合校准；不足以认证宽提案或禁止技能策略。

验证方法：以原表、实际技能前缀和次轮状态固定输入，逐步比较污染/意图/毒/挡；未来独立局检验完整替线。

原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-infested-prism-tainted-skill-cost.md`；SHA256 `bed21b409432a70aeba53c8cbf1ce31a5e83113f5208f144766b259c4f9a0c3c`，本批副本`silent-proposal-c20b5139dd0dff71.md`。原source_task=experience-update，target_task=strategy-proposal；不另建重复id。

## silent-proposal-ae9e692d680e3819

原摘要：提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。

证据：5PM6JAQG6FNQ F39 T3—T6。账本：silent-0183, silent-0005。

states 274347/274351：力敏各−2→−4；274358失落退场后玩家力量不再列出，遗忘仍有4敏；274362再次夺敏，玩家−2、遗忘6。末次单步法仅回−2敏仍死。

旧行为及现有覆盖：当前模型可读现场负属性；总值也受步法等来源影响，不能由当前负值倒推出每个敌人的累计抢夺或返还账。

预期行为：提案：逐实体记录已观察的抢夺/返还与负属性，再验证当前方案，不设置固定击杀序。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺逐实体累计抢夺真值、连续实例身份及遗忘退场返敏/再次抢夺的完整固定链；固定击杀顺序没有受控整战胜线。

验证方法：补稳定实例或完整召唤/退场链与每次夺取/返还原帧，复验负属性和重新抢夺；不得从总属性反填被夺数。

原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lost-forgotten-possession.md`；SHA256 `b30fb59d7407c7226d4d67196479a4e2cc9322e478ab8314fa4a7ead7ea6c3b5`，本批副本`silent-proposal-ae9e692d680e3819.md`。原source_task=experience-update，target_task=strategy-proposal；不另建重复id。

## silent-proposal-52f1e1bd2e7db0ed

原摘要：第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。

证据：CA5KE8GFJ9X2 F13 T1—T5。账本：silent-0231。

states 273237—273269：喷水11→15→19、力量0→4→8；T5弱后14、玩家2血10挡后归零。覆甲所见9/9/8/7/6只作现场层数，不推完整减层条件。

旧行为及现有覆盖：monster-db的moveDamageAt在有当前进阶事实时直接使用，无五样本守卫；room-costs与房间代价仍保留5样本门槛。当前接口存在不等于历史加压/覆甲联合重放已完成。

预期行为：第一观测起使用当前进阶HP/攻击事实，冻结加压与弱；保留房间代价五样本门槛。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺实际历史A10移动表和加压/覆甲全过程联合校准；原决策SL尝试元数据为null，不能补造尝试身份或认证整轮候选执行。

验证方法：保留未知身份，取得原调用输入后用T1/T3/T5固定值校验；覆甲未知条件保持未知，不把房间样本门槛移到怪物事实。

原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-sewer-clam-pressure-growth.md`；SHA256 `651f0bdcdb88c5cd511aae9b4744b0d60852b08a67d67d0bcb76d52bd5ce8376`，本批副本`silent-proposal-52f1e1bd2e7db0ed.md`。原source_task=experience-update，target_task=strategy-proposal；不另建重复id。

## silent-proposal-6dd8bbff876be528

原摘要：复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。

证据：5PM6JAQG6FNQ F38 T3—T4。账本：silent-0233, silent-0209。

states 274308/274313：23上限电击所见力量2→4、攻击17→19；数组index4→3，不据index固定实例。T3仍贡献17攻，T4才退场。另一35伤/损3候选未实打。

旧行为及现有覆盖：rollout已有HIGH_VOLTAGE_POWER逐敌增长路径；唯一类型端点可比较，召唤代际与被替换实体不由此确定。

预期行为：复验现有HIGH_VOLTAGE_POWER逐实体增长，当前进阶攻击从DB读；新召唤者不继承旧实体计数。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺可靠召唤代际身份、原实际移动表及连续增长后继校准；现有增长代码不足以认证跨代重置或改变击杀序。

验证方法：冻结生成/退场原帧和每代首值，验证同代增长及新代初始值；用独立完整战斗检查另一目标顺序。

原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-zapbot-high-voltage-growth.md`；SHA256 `48b2be77326bb54c99a17547f0499b91bca9816e1ff9f0761baded11ddeccde5`，本批副本`silent-proposal-6dd8bbff876be528.md`。原source_task=experience-update，target_task=strategy-proposal；不另建重复id。

## silent-proposal-578e415a259e6835

原摘要：核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则

证据：8JRE1C4H4Z2W F17 T6；F33 T2/T5/T11。账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。

decisions270216/270282同指纹，首/三试T2到次轮净损3/15、敌净扣10/17；0/24与5/24死亡样本并不相同。末试T11为5血22挡对37攻击，实扣5与显示差15分列。

旧行为及现有覆盖：selection_audit、hp_guard_audit、单动作selection_dispatch及离线observed_turns已覆盖部分追溯；完整候选收益仍为空。护栏后抽弃牌重问会改变实际前缀。

预期行为：核验静默沙虫同指纹SL实付血价、已建攻防与毒结算、候选及资源分账；证据不足保留原选择规则 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺重规划后完整候选续步身份、沙坑逐来源结算及路线资源归属；本局相关SL尝试不能提供新的独立整战验证。

验证方法：保留原答/护栏/SL/派发各层，以连续身份和资源账验每次截断；新独立局验证策略，不能把候选省血记成实得收益。

原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-173847-experience-update/proposal-mechanisms-sl-resources.md`；SHA256 `e13a77ede19196a05647125bcb3c4481ed36ddf98e9e7e2889817f10c9fa190a`，本批副本`silent-proposal-578e415a259e6835.md`。原source_task=experience-update，target_task=strategy-proposal；不另建重复id。

## silent-proposal-c0767768bf6a7ab1

原摘要：全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。

证据：YF0LXT1QSTGG F48 第二/三试T1；第四试T5；F33。账本：silent-0079。

decisions271309/271348同指纹，原始起点至T2观测净损0/9、敌净扣45/38。第四试T5弃牌后回防御线是未完成候选反例；F33第二试实胜，不能否定全部SL。

旧行为及现有覆盖：现有候选/单动作/重问审计可逐层查看；死亡比例相等仅为有限样本事实，不认证替线安全或完整执行。

预期行为：全败SL替换与覆盖重放应分列同轮资源代价及未执行续步；先实现事实核验，禁止探索或惩罚系数缺受控胜局证据。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺完整候选执行与血价归属、同抽序完整替线和独立整战验证；0/9与45/38只证起点后的观测净差。

验证方法：冻结相同起点和后续抽序，保留未执行续步/重问；补原失败线换线后实胜的独立反例，再评估阈值。

原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-sl-resource-trade.md`；SHA256 `28e9d34c33097cb3858c0f92f68f34b6204fc8a6880ffda62e6cbb510c7546cb`，本批副本`silent-proposal-c0767768bf6a7ab1.md`。原source_task=postmortem，target_task=strategy-proposal；不另建重复id。

## silent-proposal-a46bdb7fe711d79a

原摘要：实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。

证据：YF0LXT1QSTGG F48 末试T3—T5。账本：silent-0021, silent-0027, silent-0028, silent-0085。

states277512/277513换相111→212并清旧毒/力；277521—277527既有23挡在敏捷5→6后不倒补，四小刀与消耗另源合37净扣；零毒时触媒2不产生额外毒伤。

旧行为及现有覆盖：现有离线interval保留HP/最大HP、手牌和能力；阶段规则已有窄实现，仍不能替代逐候选施毒/结毒/额外失血/敏捷取得顺序的联合来源账。

预期行为：实验体候选区分阶段、已建能力与已兑现毒/挡收益；零毒触媒和后取得敏捷不预支，动作排序调整证据不足。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺逐候选施毒与毒伤、额外扣血、敏捷取得顺序的来源归属及完整派发联合认证；窄换相修复不能代替整个提案交付。

验证方法：同固定输入逐步核零毒、换相、23挡及消耗附伤，保留前五试已建能力仍败的反例；后续独立局验证选线。

原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-174301-postmortem/proposal-phase-poison-delivery.md`；SHA256 `eb929b3084fc0d0026276fcaf148aac938a284f89c40176600b248999450cdb6`，本批副本`silent-proposal-a46bdb7fe711d79a.md`。原source_task=postmortem，target_task=strategy-proposal；不另建重复id。

## silent-proposal-1044224808015e5c

原摘要：核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。

证据：XP2SL33HT0D9 F33 首/二试T3；首/末试T1。账本：silent-0079。

decisions271992/272040同指纹：净损9/14、敌净扣24/27；271982/272195同指纹：净损2/10、敌净扣25/34。后者含手里剑成长，不能只按血差判全部换线错误。

旧行为及现有覆盖：候选审计保留hp_loss/damage/strength/lasting差；B2零胜并列与五轮死亡饱和是不同条件，不能称零差即安全。

预期行为：核验A10双蟹B2零胜并列的SL换线血价，分列当轮损失、输出与成长；缺独立胜线时保留原行为，不以零差宣称安全。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺同抽序完整替线、成长兑现受控后继及独立整战胜线；不能据这几组当轮差值拟合保血优先或血价参数。

验证方法：固定当轮9/14、2/10和成长次序作回归；以run_id分组、后置独立局验证策略，保留原探索选择。

原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-sl-blood-price.md`；SHA256 `4e864f92eb146261d320cdac4a721859b4c960e4d9522e27bafa8e6ab15159d5`，本批副本`silent-proposal-1044224808015e5c.md`。原source_task=postmortem，target_task=strategy-proposal；不另建重复id。

## silent-proposal-7cbc6005db712ba9

原摘要：用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。

证据：XP2SL33HT0D9 F33 末试T2—T5。账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。

states278236—278242轮初14挡、镣铐0→−9力、斗篷后20挡；T3恢复。278249—278255激光57→38→28、4敏脆弱偏折得6挡；T5实扣11、毒扣3+7，两敌仍153/125。

旧行为及现有覆盖：现场已有挡、临时减力及候选结果已有入口；当前观测保留两次朝向/虚弱变换。完整逐候选来源分解与端到端存活核验仍未齐。

预期行为：用本角色日志核验双蟹朝向、临时减力、船夹板T2格挡与能力实际兑现；补缺失条件参考，保留原出牌权重和未验证条件。 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺逐候选原有/新增挡、朝向与虚弱、已结算毒、存活HP的统一来源校准；局部数字吻合不等于完整候选已执行。

验证方法：固定57→38→28、14+6→20、0→−9→恢复、6挡与终局11净损，逐项分源；不把观测参考换成未见条件的硬规则。

原Markdown：`/home/dw/Projects/agent-sts2/learner/runs/20261007-181302-postmortem/proposal-combat-realized-window.md`；SHA256 `f6d851dba9b1b5b9765030c0d2f66f074d4ba4ed203f7dcf5bc6c9639fa73291`，本批副本`silent-proposal-7cbc6005db712ba9.md`。原source_task=postmortem，target_task=strategy-proposal；不另建重复id。

## silent-proposal-c59f592f1427a67e

原摘要：核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证

证据：YF0LXT1QSTGG F48 T1/T4/T5；XP2SL33HT0D9 F33 T1—T5。账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。

两局三组同指纹配对再次核实；YF已建触媒/敏捷与XP临时减力/轮初挡分别有原帧。SL恢复、路线回血、药槽恢复应分账；原101局等历史分母未在本批重算。

旧行为及现有覆盖：宽提案汇集的部分机制、预测审计、回执与离线观测已有窄实现；这些子项不能合并宣称完整资源归属或策略量化已完成。

预期行为：核实静默临时减力/轮初挡与已建能力兑现，分列同盘SL原答/替换/实际血价；缺完整胜线时保留规则并后移验证 本批保持现有选择结果、完整选项与原知识状态；任何未验证收益不预支。

处置：waiting。缺逐来源资源账、完整候选归属、路线药水时机及受控整战后继；本批仅六个来源局，不能代替原历史分母或认证药水/路线因果。

验证方法：复用各原提案和账本，补完整资源链及独立后置整战；不重复登记新id，不重写历史复盘或把全败样本变成策略权重。

原Markdown：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-184216-experience-update/proposal-mechanisms-sl-resources.md`；SHA256 `81f2b4019e4218efea09382a1f6781a412e3090205b8b4d8568ce9b9396a5dd2`，本批副本`silent-proposal-c59f592f1427a67e.md`。原source_task=experience-update，target_task=strategy-proposal；不另建重复id。

## 样本、反例与回退

四组相同指纹仅能控制所列起点。8JRE T2多12血换7净扣、YF T1多9血且少7净扣、XP T3多5血换3净扣、XP T1多8血换9净扣；差值包含后续重问，未归因给完整候选。原提案的已建能力仍败、防御换线延后但仍死、SL在F33实胜、未执行候选等反例全部保留。六试同存档不能作六个独立局。本批六局是发现/回归证据，未进行新独立后置整战验证，不估胜率或最优血价。

铁甲战士及未观察角色/进阶行为不变。本批无生产补丁可回退；后续窄实现须冻结全部必要输入、撤生产源码失败/恢复通过并跑原沙箱入口，再按live流程上线。缺数据继续由原队列等待新局，不关闭宽请求。

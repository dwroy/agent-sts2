import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
spec = importlib.util.spec_from_file_location('task_ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
queue = json.loads((OUT / 'proposal-queue-rows.json').read_text())
associations = {}
for id, rows in queue.items():
    original = next(row for row in rows if row['op'] == 'add')
    for item in original['ledger']:
        associations.setdefault(item, []).append(id)
before = {key: item for key, item in ledger.fold().items() if key in associations}
assert set(before) == set(associations)
assert all(item['character'] == 'silent' for item in before.values())
raw_before = (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()
prefix_sha = hashlib.sha256(raw_before).hexdigest()
(OUT / 'ledger-trace-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
rows = [{'id': id, 'by': 'learner:strategy-proposal',
         'where': {'proposal': [str(OUT / 'proposal.md')]},
         'note': '20261017-184303-strategy-proposal复核追溯：' + ','.join(ids) +
                 '；处置waiting，详见' + str(OUT / 'report.md') +
                 '。仅报告/提案链接，不新增支持或反例，不改claim/首证/prior/证据/status/version，不登记implemented/shipped。'}
        for id, ids in associations.items()]
payload = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows)
(OUT / 'ledger-trace-input.jsonl').write_text(payload)
result = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                        input=payload, text=True, capture_output=True)
(OUT / 'ledger-trace.stdout.txt').write_text(result.stdout)
(OUT / 'ledger-trace.stderr.txt').write_text(result.stderr)
assert result.returncode == 0, result.returncode
raw_after = (ROOT / 'paper/materials/learning/ledger.jsonl').read_bytes()
assert hashlib.sha256(raw_after[:len(raw_before)]).hexdigest() == prefix_sha
tail = raw_after[len(raw_before):]
appended = [json.loads(line) for line in tail.splitlines()]
own = [row for row in appended if row.get('by') == 'learner:strategy-proposal' and
       '20261017-184303-strategy-proposal复核追溯' in row.get('note', '')]
assert len(own) == len(rows)
assert {row['id'] for row in own} == set(associations)
assert all(set(row) <= {'op', 'id', 'by', 'where', 'note', 'ts'} for row in own)
after = {key: item for key, item in ledger.fold().items() if key in associations}
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_runs', 'prior_note',
             'evidence', 'status', 'version', 'effect']
changes = [(id, key) for id in before for key in protected if before[id].get(key) != after[id].get(key)]
receipt = {'at': stamp, 'exit_code': result.returncode, 'ids': list(associations),
           'own_rows': len(own), 'prefix_bytes': len(raw_before), 'prefix_sha256': prefix_sha,
           'prefix_preserved': True, 'protected_field_changes': changes,
           'other_concurrent_rows': len(appended) - len(own)}
(OUT / 'ledger-trace-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
assert not changes, changes
print(json.dumps(receipt, ensure_ascii=False))

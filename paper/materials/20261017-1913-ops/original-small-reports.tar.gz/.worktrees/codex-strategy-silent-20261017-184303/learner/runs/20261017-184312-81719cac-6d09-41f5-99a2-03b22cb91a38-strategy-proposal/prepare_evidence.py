import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
DISPATCH = json.loads((OUT / 'dispatch.json').read_text())
RUNS = DISPATCH['runs']
FLOORS = {
    '751FN9QM9MHQ': [13, 17], 'KV0JHNJCKXLS': [33],
    'YQL8RZ8BWN1E': [17], 'L9SGRBB5R698': [17],
    'PU80F84P6HPN': [17], 'KEN58SH9SLZ6': [3, 4, 5, 11, 15, 17],
}


def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


streams = {}
checks = []
for directory in ['identity-evidence', 'evidence']:
    manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
    for item in manifest:
        name = item['stream']
        path = OUT / directory / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        rows = []
        counts = collections.Counter()
        with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
            for raw in path.open('rb'):
                digest.update(raw)
                envelope = json.loads(raw)
                source.seek(envelope['offset'])
                original = source.read(envelope['bytes'])
                assert hashlib.sha256(original).hexdigest() == envelope['sha256']
                assert json.loads(original) == envelope['row']
                assert envelope['offset'] + envelope['bytes'] <= item['source_size']
                assert envelope['run_id'] in RUNS
                counts[envelope['run_id']] += 1
                rows.append(envelope)
        assert digest.hexdigest() == item['output_sha256']
        assert all(counts[run] == item['counts'][run] for run in RUNS)
        streams[name] = rows
        checks.append({'stream': name, 'source_size': item['source_size'],
                       'verified_rows': len(rows), 'counts': dict(counts),
                       'output_sha256': digest.hexdigest()})
write('raw-verification.json', checks)

run_rows = {x['run_id']: x['row'] for x in streams['runs']}
inputs = []
for run in RUNS:
    assert run_rows[run]['character'].lower() == 'silent'
    assert run_rows[run]['ascension'] == 10
    decisions = [dict(x['row'], _line=x['line']) for x in streams['decisions']
                 if x['run_id'] == run and x['row'].get('floor') in FLOORS[run]]
    states = [dict(x['row'], _line=x['line']) for x in streams['states']
              if x['run_id'] == run and x['row'].get('state', {}).get('run', {}).get('floor') in FLOORS[run]]
    for row in states:
        info = row['state']['run']
        assert info['character_id'].lower() == 'silent' and info['ascension'] == 10
    data = {'run': run_rows[run], 'decisions': decisions, 'states': states}
    name = run + '.input.json'
    write(name, data)
    inputs.append({'run_id': run, 'floors': FLOORS[run], 'decisions': len(decisions),
                   'states': len(states), 'sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()})
write('consumer-inputs.json', inputs)

interesting = []
decision_lines = {272361, 272362, 272434, 272575, 272531, 272652,
                  274087, 274131, 274156, 274185, 274235, 274237, 274267,
                  274272, 274354, 274484, 274505, 274568, 274601}
for envelope in streams['decisions']:
    row = envelope['row']
    if envelope['line'] in decision_lines or (row.get('sl_explore') or {}).get('deviation'):
        interesting.append(envelope)
write('key-decisions.json', interesting)

state_lines = {278383, 278403, 278404, 278405, 278406, 278407,
               280160, 280161, 280206, 280207, 280232, 280233, 280262, 280263,
               280313, 280314, 280315, 280316, 280348, 280349, 280354, 280355}
write('key-states.json', [x for x in streams['states'] if x['line'] in state_lines])

notes = []
for run in RUNS:
    matches = list((ROOT / 'notes').glob('run-*-' + run + '.md'))
    assert len(matches) == 1
    path = matches[0]
    raw = path.read_bytes()
    (OUT / (run + '.run-report.md')).write_bytes(raw)
    notes.append({'run_id': run, 'source': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
write('run-report-sources.json', notes)
print(json.dumps({'streams': checks, 'inputs': inputs}, ensure_ascii=False))

## 复盘：run KEN58SH9SLZ6 — 阵亡，最高第 17 层

- 决策 548 个；Jev 调用 109 次，Claude 0 次，大脑 17 次（codex 17）；token 584,047 入 / 5,083 出，约 $0.0247（Jev）；大脑 token 2,131,968 入（缓存命中 1,039,104，49%）/ 4,689 出；用时 26.8 分钟
- 决策者：code 259，jev-plan 159，jev 109，codex 21

### 战斗掉血（按层）
- 第 2 层 蟾蜍蝌蚪: HP 56→56（-0），决策 jev-plan 10，code 7，jev 5
- 第 3 层 海洋混混: HP 56→53（-3），决策 code 8，jev 7，jev-plan 6
- 第 4 层 噬尸蛞蝓: HP 53→53（-0），决策 jev-plan 9，code 7，jev 6
- 第 5 层 海洋混混/钙化邪教徒: HP 53→16（-37），决策 jev-plan 9，code 9，jev 7
- 第 11 层 卑鄙地精/地精佣兵/胖地精: HP 32→26（-6），决策 jev 10，jev-plan 6，code 5
- 第 15 层 下水道蚌: HP 46→46（-0），决策 code 11，jev-plan 9，jev 8
- 第 17 层 灵魂异鱼: HP 75→0（-75），决策 code 161，jev-plan 110，jev 66

### 死亡战斗：第 17 层 灵魂异鱼
- T11 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 呼唤
- T11 [code] combat/plan: code plan (only line): end turn; hp -0, dmg 5
- T12 [code] combat/plan: code plan (only line): 防御, 呼唤, 呼唤, 中和 -> 灵魂异鱼; hp -13, dmg 7
- T12 [code] combat/plan-continue: continuing the code-chosen plan: 呼唤
- T12 [code] combat/plan-continue: continuing the code-chosen plan: 呼唤
- T12 [code] combat/plan-continue: continuing the code-chosen plan: 中和 -> 灵魂异鱼
- T12 [code] combat/plan: code plan (only line): end turn; hp -13, dmg 4
- T13 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-3): 中和 -> 灵魂异鱼, 呼唤, 呼唤, 打击 -> 灵魂异鱼
- T13 [code] combat/plan-continue: continuing the code-chosen plan: 呼唤
- T13 [code] combat/plan-continue: continuing the code-chosen plan: 呼唤
- T13 [code] combat/plan-continue: continuing the code-chosen plan: 打击 -> 灵魂异鱼
- T13 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-3): end turn

### 各类决策由谁做
- combat/plan-continue / jev-plan: 159
- combat/plan / code: 132
- combat/plan-choice / jev: 85
- combat/plan-continue / code: 55
- reward/claim / code: 16
- map/route-follow / code: 15
- combat/least-loss / code: 13
- combat/plan-choice+potion / jev: 11
- selection/choose / jev: 11
- combat/lethal / code: 6
- event/leave / code: 6
- reward/card / codex: 6
- reward/proceed / code: 6
- event/choose / codex: 5
- shop/buy / codex: 3
- rest/plan / codex: 2
- rest/proceed / code: 2
- selection/take into my hand / jev: 2
- chest/open / code: 1
- chest/proceed / code: 1
- chest/relic / code: 1
- combat/end_turn / code: 1
- event/plan / codex: 1
- map/route-change / codex: 1
- map/route-plan / codex: 1
- run/finalize / code: 1
- selection/add / codex: 1
- selection/take into my hand / code: 1
- shop/leave / code: 1
- shop/open / code: 1
- shop/plan / codex: 1

### 兜底介入（Claude/DeepSeek）：0 次（推翻 Jev 0 次）

### Jev 低置信度（<0.35）决策：10 个
- 第 3 层 combat/plan-choice+potion: Jev chose plan 1/2 (end turn) with confidence 0.25; code rank 1 (0.25)
- 第 3 层 combat/plan-choice+potion: Jev chose to drink 攻击药水, then re-plan (confidence 0.33) (0.33)
- 第 4 层 combat/plan-choice: Jev chose plan 1/2 (打击 -> 噬尸蛞蝓) with confidence 0.32; code rank 1 (0.32)
- 第 11 层 combat/plan-choice+potion: Jev chose plan 4/5 (防御, 突然一拳 -> 地精佣兵, 生存者) with confidence 0.16; code rank 4 (0.16)
- 第 11 层 selection/choose: Jev chose 迷雾 with confidence 0.28 (0.28)
- 第 15 层 combat/plan-choice: Jev chose plan 1/2 (匕首雨, 打击 -> 下水道蚌, 打击 -> 下水道蚌) with confidence 0.30; code rank 1 (0.30)
- 第 17 层 combat/plan-choice: Jev chose plan 1/2 (打击 -> 灵魂异鱼, 飞镖 -> 灵魂异鱼, 生存者) with confidence 0.26; code rank 1 (0.26)
- 第 17 层 selection/choose: Jev chose 呼唤 with confidence 0.28 (0.28)
- 第 17 层 combat/plan-choice: Jev chose plan 1/2 (呼唤, 打击 -> 灵魂异鱼, 呼唤) with confidence 0.12; code rank 1 [ending now kills by what the mod's lethal flag does not count: 12 HP lost i (0.12)
- 第 17 层 selection/choose: Jev chose 呼唤 with confidence 0.32 (0.32)

import collections
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
inputs = json.loads((OUT / 'consumer-inputs.json').read_text())
summary = []
key_turns = []
potion_actions = []
for item in inputs:
    run = item['run_id']
    output = OUT / (run + '.audit.json')
    errors = OUT / (run + '.audit.stderr.txt')
    input_path = item.get('input_path', str(OUT / (run + '.input.json')))
    cmd = ['node', '--import', './agent/node_modules/tsx/dist/loader.mjs',
           'learner/audit-selection.ts', input_path]
    if run != 'KEN58SH9SLZ6':
        assert output.is_file() and errors.read_bytes() == b''
        json.loads(output.read_text())
        rc = 0
        execution = '初次连续执行已通过，复用原输出，不重跑前五局'
    else:
        with output.open('wb') as stdout, errors.open('wb') as stderr:
            rc = subprocess.run(cmd, cwd=WORKTREE, stdout=stdout, stderr=stderr).returncode
        execution = '保留初次失败；仅排除无ID非战斗路线元事件后执行'
    assert rc == 0, (run, rc, str(errors))
    result = json.loads(output.read_text())
    segments = result['segments']
    turns = result['observed_turns']
    observed = [t for t in turns if t['status'] == 'observed_turn_endpoints']
    summary.append(dict(item, exit_code=rc, execution=execution, command=cmd,
                        output_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                        segments=len(segments), turns=len(turns), observed_turns=len(observed),
                        full_candidates=sum(s['actual_full_candidate_result'] is not None for s in segments),
                        unknown_turn_reasons=dict(collections.Counter(t['reason'] for t in turns if t['reason'])),
                        dispatch_counts=dict(collections.Counter(a['dispatch'] for a in result['observed_actions']))))
    for turn in observed:
        if (run == '751FN9QM9MHQ' and turn['floor'] == 17 and turn['turn'] in [2, 7, 13]) or (
            run == 'KEN58SH9SLZ6' and turn['floor'] == 17 and turn['turn'] in [2, 5, 8, 9, 10, 12, 13]) or (
            run == 'KV0JHNJCKXLS' and turn['floor'] == 33 and turn['turn'] in [1, 4, 5]):
            facts = turn['facts']
            key_turns.append({'run_id': run, 'floor': turn['floor'], 'turn': turn['turn'],
                              'attempt': turn['attempt'], 'reloads': turn['reloads'],
                              'decisions': [d['source_line'] for d in turn['decisions']],
                              'hp_before': facts['before']['hp'], 'hp_after': facts['after']['hp'],
                              'hp_delta': facts['player_hp_delta'],
                              'enemy_hp_changes': facts['enemy_hp_changes'],
                              'replanning_decisions': facts['replanning_decisions'],
                              'state_path_status': facts['state_path_status']})
    for action in result['observed_actions']:
        chosen = action.get('chosen') or {}
        if chosen.get('action') in ['use_potion', 'discard_potion']:
            potion_actions.append({'run_id': run, **action})
for name, data in [('consumer-summary.json', summary), ('key-turn-endpoints.json', key_turns),
                   ('potion-observations.json', potion_actions)]:
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))

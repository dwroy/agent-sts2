## 复盘：run YQL8RZ8BWN1E — 阵亡，最高第 17 层

- 决策 571 个；Jev 调用 253 次，Claude 0 次，大脑 18 次（codex 18）；token 1,280,864 入 / 12,352 出，约 $0.0543（Jev）；大脑 token 2,257,450 入（缓存命中 1,385,472，61%）/ 4,733 出；用时 25.6 分钟
- 决策者：jev 253，jev-plan 172，code 125，codex 21

### 战斗掉血（按层）
- 第 2 层 淤泥旋螺: HP 67→63（-4），决策 jev 12，jev-plan 10，code 2
- 第 3 层 海洋混混: HP 63→63（-0），决策 jev 5，jev-plan 4，code 4
- 第 4 层 噬尸蛞蝓: HP 63→62（-1），决策 jev 10，jev-plan 5，code 1
- 第 5 层 卑鄙地精/地精佣兵/胖地精: HP 62→47（-15），决策 jev 11，jev-plan 8，code 2
- 第 6 层 海洋混混/钙化邪教徒: HP 47→18（-29），决策 jev 11，jev-plan 8，code 3
- 第 7 层 幽灵船: HP 18→14（-4），决策 jev 6，jev-plan 5，code 2
- 第 12 层 拳击构装体: HP 39→35（-4），决策 jev 8，jev-plan 7，code 1
- 第 13 层 化石追踪者: HP 35→35（-0），决策 jev 10，jev-plan 8，code 4
- 第 15 层 潮湿邪教徒/钙化邪教徒: HP 35→32（-3），决策 jev 6，code 5，jev-plan 3
- 第 17 层 瀑布巨兽: HP 57→0（-57），决策 jev 174，jev-plan 114，code 39

### 死亡战斗：第 17 层 瀑布巨兽
- T7 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 切割 -> 瀑布巨兽
- T7 [jev] combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.48; code rank 1 conf 0.48
- T8 [jev] combat/plan-choice+potion: Jev chose plan 5/5 (触媒, 防御) with confidence 0.86; code rank - (rollout's best line, added) conf 0.86
- T8 [jev-plan] combat/plan-continue: continuing the Jev-chosen plan: 防御
- T8 [jev] combat/plan-choice+potion: Jev chose plan 1/2 (打击 -> 瀑布巨兽) with confidence 0.38; code rank 1 conf 0.38
- T8 [jev] combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.52; code rank 1 conf 0.52
- T9 [jev] combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.52; code rank 1 conf 0.52
- T10 [jev] combat/play: Jev chose c1 (Play 生存者) with confidence 0.44 conf 0.44
- T10 [jev] selection/choose: Jev chose 打击 with confidence 0.80 conf 0.80
- T10 [jev] combat/play: Jev chose c1 (Play 防御) with confidence 0.75 conf 0.75
- T10 [jev] combat/play: Jev chose p0->e0 (Drink 毒药水 on 瀑布巨兽) with confidence 0.34 conf 0.34
- T10 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-2): end turn

### 各类决策由谁做
- combat/plan-choice+potion / jev: 208
- combat/plan-continue / jev-plan: 172
- selection/choose / jev: 37
- reward/claim / code: 28
- combat/plan-continue / code: 22
- map/route-follow / code: 15
- combat/lethal / code: 12
- combat/least-loss / code: 11
- combat/plan / code: 11
- reward/card / codex: 10
- reward/proceed / code: 9
- combat/mod-lethal / code: 5
- combat/plan-choice / jev: 5
- combat/play / jev: 3
- event/choose / codex: 3
- event/leave / code: 3
- rest/plan / codex: 3
- rest/proceed / code: 3
- chest/open / code: 1
- chest/proceed / code: 1
- chest/relic / code: 1
- combat/end_turn / code: 1
- combat/potion-now / code: 1
- event/plan / codex: 1
- map/route-change / codex: 1
- map/route-plan / codex: 1
- run/finalize / code: 1
- selection/enchant / codex: 1
- selection/upgrade / codex: 1

### 兜底介入（Claude/DeepSeek）：0 次（推翻 Jev 0 次）

### Jev 低置信度（<0.35）决策：21 个
- 第 2 层 combat/plan-choice+potion: Jev chose plan 3/3 (打击 -> 淤泥旋螺, 生存者) with confidence 0.33; code rank - (rollout's best line, added) (0.33)
- 第 6 层 selection/choose: Jev chose 猎杀者 with confidence 0.09 (0.09)
- 第 13 层 selection/choose: Jev chose 弹跳药瓶 with confidence 0.23 (0.23)
- 第 15 层 selection/choose: Jev chose 进阶之灾 with confidence 0.27 (0.27)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.16; code rank 1 (0.16)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 2/3 (中和 -> 瀑布巨兽, 防御, 防御) with confidence 0.24; code rank 2 (0.24)
- 第 17 层 combat/plan-choice+potion: Jev chose to drink 毒药水 (confidence 0.20) (0.20)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.20; code rank 1 (0.20)
- 第 17 层 combat/plan-choice+potion: Jev chose to drink 毒药水 (confidence 0.34) (0.34)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.32; code rank 1 (0.32)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.00; code rank 1 (0.00)
- 第 17 层 combat/plan-choice+potion: Jev chose to drink 毒药水 (confidence 0.34) (0.34)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.28; code rank 1 (0.28)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.02; code rank 1 (0.02)
- 第 17 层 combat/plan-choice+potion: Jev chose to drink 毒药水 (confidence 0.18) (0.18)

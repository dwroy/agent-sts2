import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
queue = json.loads((OUT / 'proposal-queue-rows.json').read_text())
source = json.loads((OUT / 'source-comparison.json').read_text())
summary = json.loads((OUT / 'consumer-summary.json').read_text())
stamp = subprocess.check_output(['date', '-Iseconds'], text=True).strip()
reasons = [
    '751 F17 T2/T7/T13同指纹净血价与净扣敌差已复核；缺逐来源实际结算、完整候选归属和保持后续条件一致的整战对照及独立验证，不能拟合SL探索门槛。',
    '751 F13 T3用药与整战无药候选均报8/8胜，但实际只执行用药支线；缺不喝及留药后战完整对照、未决弃牌逐来源兑现，不能拟合持有价或改弃牌排序。',
    '与366288801d9150d9共用751同一局三组对照；现有预测/派发回执只完成诊断子项，缺完整实际成本归属及受控整战后继，不增加独立样本。',
    '751敏捷、毒、荆棘、呼唤及持有价值未知已有诊断子项；缺各来源联合实际校准、完整候选归属及跨战留药对照，不能以单机制实现关闭整项。',
    'KV F33 T5删除毒药的同指纹预测36→29伤且均零即时损血、全局模拟零胜；消费者该两轮结束端点未认证，缺敌回血/毒及能力收益完整归属、受控胜线与独立验证，不能调整SL或路线门槛。',
    'YQL F17 T10残壳毒2→8而血26/挡13/来袭41不变；阶段提示已有，原占位HP排序保留。缺同轮自爆资源及完整后继的受控排序验证、提前用药实果，不能直接把占位血归零改序。',
    '与e18d3f18e6cac2a0共享YQL及L9/PU阶段证据；本体结束不等胜，阶段说明不等终局/SL目标已校准，缺受控排序后继、药水时点及路线反事实，不新增重复实现。',
    'KEN七条用药请求和逐槽有药→空已核，其中两攻击药及技能药为pending回执；缺随机选牌与发光水重问后完整收益归属、同题不喝及留至Boss支线，空栏入口不能拟合持有价。',
    'KEN F17 T10同盘净损15→21、扣敌2→4，T5净损7→5而步法延后；缺完整候选及能力收益归属、受控整战后继和后期独立验证，保留排序与HP护栏。',
    '与86a7db08d1a31976共用KEN同一局两组对照，六次SL不当六局；局部血价不能认证完整候选或后续胜因，缺受控整战与独立验证，不拟合统一6血/2伤阈值。',
]
evidence = [
    '751FN9QM9MHQ F17 T2（decisions272434/272575）、T7（272531/272652）、T13（272483/272820）；净损13→18、13→23、8→2；净扣敌9→18、12→18、17→11。',
    '751FN9QM9MHQ F13 T3 decisions272361/272362；F17 T7/T13/T17。用药plan2与整战无药plan5均报8/8胜，plan3后续仍可能喝药；不把本轮无药当整战无药。',
    '同第一项；经验silent-fysh-resource-sl-observation、silent-beckon-held-end-turn-loss与原复盘共用证据，非新增独立支持。',
    '751FN9QM9MHQ F17 T3建敏捷、T5/T10/T15无实体、T7未决弃牌与T17剩呼唤；F13 T3药水。机制支持来自原提案及本角色原复盘，未新拟联合参数。',
    'KV0JHNJCKXLS F33 T5 decisions273400/273450同指纹；替线B2原/换0/0，题面损0/0、伤36/29；末试T4原复盘敌回血30，净扣不能作毛伤。',
    'YQL8RZ8BWN1E F17第6试T10 decisions274087、states280160/280161；L9SGRBB5R698 F17 T14 sl-attempts681；PU80F84P6HPN F17 T17 sl-attempts717。',
    'YQL8RZ8BWN1E F17六次本体结束T12/12/11/12/12/9，自爆50/50/47/50/50/41；末试26+13<41。L9/PU旧占位残血仅作历史复核。',
    'KEN58SH9SLZ6：F3T2 274131/280206→280207；F4T1 274156/280232→280233；F5T2 274185/280262→280263；F11T1/T2 274235/274237与280313→280314/280315→280316；F15T1 274267/274272与280348→280349/280354→280355。',
    'KEN58SH9SLZ6 F17 T10 decisions274505/274568；T5 274484/274601；T2护栏274354。T10 B2 .385→.127，配对差−.2583、SE .0132；T5追加重问不能并作原候选伤害。',
    '同第九项；经验来源与复盘来源共享KEN数据。T10换线多6净损、多2净扣；T5省2血却延后步法，构成只按当轮保血排序的反向取舍。',
]
sections = []
results = []
for index, id in enumerate(dispatch['proposal_ids']):
    original = next(x for x in queue[id] if x['op'] == 'add')
    results.append({'id': id, 'state': 'waiting', 'reason': reasons[index]})
    sections.append(f'''## {index + 1}. {id}

角色/范围：silent，已观察A10。来源任务：{original['source_task']}；本次实现任务：strategy-proposal/{'20261017-184303-strategy-proposal'}。
账本：{', '.join(original['ledger'])}。
原提案：{original['proposal']}；原Markdown SHA256：{original['proposal_sha256']}，已逐份核同并保存 `{id}.original.md`。

证据：{evidence[index]}

处置：waiting。{reasons[index]}

旧/预期行为：保留当前出牌、用药、SL、终局及参考路径排序；既有字段继续区分候选预测、单动作回执与观测结果。补证后才判断是否需要新实现；当前不删选项、不定固定阈值、不将缺值改成零。

验证：原始JSON逐offset/长度/SHA核验；用已存在的离线消费者关联有界决策与状态，未知及重问保留。若未来修改策略，必须另冻保持后继条件一致的完整对照，并将更早独立局用于拟合、时间靠后的新局用于验证；同局重试和复盘/经验双提案不拆成独立分母。

反例/限制：本批同时有增加输出付血和省血牺牲后继收益的案例；未执行分支不填实盘收益，模拟并列保留并列。没有完整受控胜线时，不能承诺改线必胜或降低既有安全边界。

预期影响/回退：本次仅保存可追溯证据与等待条件，不宣称胜率收益；没有新源码或参数，故无新上线可回退。原提案、经验、失败与历史源码记录均保留。
''')
proposal = f'''# 静默猎手十项派发提案复核

记录时间：{stamp}。batch：20261017-184303-strategy-proposal。
基线：{source['base']}。本批无research_request或implementation_request，根旧专题不匹配本批身份；不承接专题、不扩展队列。

以下十项均为原CLI提案的本次处置，不新建重复ID。结论范围限六个派发局，具体运行源码均带dirty历史，未重建当时完整脏树；当前源码只作为本批参考。

''' + '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal)
table = '\n'.join(f"| {x['run_id']} | {','.join(map(str,x['floors']))} | {x['decisions']} | {x['states']} | {x['segments']} | {x['observed_turns']} | 0 |" for x in summary)
report = f'''# 本批策略提案报告

记录时间：{stamp}。任务strategy-proposal，角色silent，batch 20261017-184303-strategy-proposal。

十项均waiting；无新源码、知识、提交、合入或版本。不将已有局部诊断登记成整项duplicate/implemented，不登记shipped。详细证据/账本/预期行为和逐项验证条件见 `{OUT / 'proposal.md'}`。

## 身份与基线

开工git status干净；核root learn.json仅本批行，task/character/worktree及六局完全匹配，proposal_ids十项，无proposal_repair/research_request/implementation_request。普通任务按要求git merge --no-edit main，结果Already up to date。
完整base/HEAD：`{source['base']}`。本次未提交源码，不制造新基线；结束另保存git核验。
六局runs.jsonl各一行均为SILENT/A10；保留原code的+dirty，不把当前live源码当当时运行全树。全程未读取其他角色知识、游戏二进制、key或.env，未联网、运行play、启动模型或派下级。

## 原日志与冻结范围

共用extract_evidence.py抽取八流，共8444条：runs6、states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、fight-plans0。各流source_size、计数、输出SHA见两份evidence-manifest；每条offset/bytes/SHA/原JSON重新seek核验通过，见raw-verification.json。
全源states/decisions/brain扫描各见2条非法JSON，extractor已计数，未以正文提及充作身份。fight-plans零行仅表示该2233957字节截点未选中本批局，不断言原日志缺失。没有覆盖旧报告或旧截点。
逐份核十个原提案Markdown SHA，并保留全部匹配队列历史与六份原局报，见proposal-queue-rows.json、run-report-sources.json。账本仅选这十项关联的16个silent ID，保留现有claim/首证/prior/evidence/status/version，不倒改历史或补写复盘。

## 已有源码覆盖及其限制

参考live快照：`{source['live_snapshot']}`；source-comparison.json核19个源码叶的blob/SHA、实际live祖先和live字节与快照提交的一致性。17叶与本base字节同，combat.ts/explore.ts两叶仅Roy/Dai历史注释署名不同，base-live-reference.patch保留差异。此为本次读取时点，非完整生产/自然效果验收。

已存在：silent-held-loss的保守持牌/未决弃牌拆项（9d8278702dbc581b5015ba7ec9a70dc0fb94cccb）；silent-potion-reference的持有价null和同题无药范围（c4670f4f416c7d93e192e889c5080e7e4e0e733f）；silent-sl-comparison/hp-guard（66283dd9982bdd7f480da7a4d9bfefea0572a9ac）；SL资源对照（1698adc96ba434a46942321e0237b70657e625b2）；单动作派发回执（fdaf787a372880b0438e73bcac7e6d2168b038ed）；巨兽残壳用药事实（40168f4a903ae1d8c48bd03006f8fea19fd3aa3c）；阶段与SL原始指标（b01edf46b4b619f217d070a196e161df9fe716a0）；离线端点工具（a32050fbce4c2863f640468c2dbf378fc9157074）。均已核实际live祖先；调用点见combat-plan.ts、combat.ts与hand/loop.ts。

这些实现明确scope为预测/单动作回执/观测区间，完整候选实果保持null；没有完整执行和实际成本来源分账的等价交付。anchorRank仍保留最长存活和原enemyHpLeft的排序，阶段说明不等同改排序已验证。现有诊断不重复实现，整项仍保留waiting。

## 有界消费者验证

只使用本批冻结输入、现有learner/audit-selection.ts，无求解、模拟池、LLM或网络。所有原行号保留，缺失SL元数据不补，净HP差与毛伤/反事实分开。

| 局号 | 楼层 | 决策 | 状态 | 候选片段 | 可核轮端点 | 认证完整候选 |
|---|---|---:|---:|---:|---:|---:|
{table}

共2328决策/2354状态、566候选片段、379可核轮端点；完整候选认证0为工具当前边界，不能据null推断动作未发生或收益为0。其余轮端点未知原因逐局保存在consumer-summary.json；KV两组T5均turn_end_unverified，原题面的36/29不可冒充消费者认证整轮实果。

首次runs.character大小写断言失败，归一后六局通过；原值未改，见identity-initial-failure.txt。初次消费者前五局退出0；KEN因F5原decisions274207的map/route-change非战斗元事件无decision_id退出1。原输入/失败stderr/脚本/日志保留；只在新scoped-input中排除该一条事件，不补ID、不删战斗/选择决策或状态。第二轮只执行KEN，退出0，前五输出原SHA保持。排除原JSON及原因见consumer-input-exclusions.json。消费者0不是生产tsc/Vitest通过。

六组原同指纹对照均核等，见verified-pairs.json；751三组和KEN两组观测净HP端点与原复盘一致，见key-turn-endpoints.json。YQL280160→280161残壳毒2→8，血26/挡13/41来袭未变；KEN七次逐槽有药→空并有用药请求，其中两攻击药及技能药回执pending。后帧槽位变化不认证随机牌全收益，来源与后战收益仍留未知。

## 结论、等待条件与交付

局部数据支持同时保留血价、实伤与能力建立窗口；并列推演不消除血价，当轮省血也不证明后继更优。六次同局SL相关，不能做六个独立拟合/验证样本，复盘和经验双提案不增加分母。缺完整候选归属、受控整战后继、无药/留药跨战对照和后期独立验证，本次不拟合新阈值。
逐项proposal_results在result.json及proposal.md；没有新游戏异议需要推翻原经验，没有新增代码提案ID。代码提案数组沿用本批十个真实CLI ID，implementation_domains空。只经根ledger.py追加本批报告追溯，既有shipped不得降级为proposed；追溯不新增support/反例或经验条目，执行回执另存。

fixes=[]、merged=null、版本null；生产tests固定tsc=null/vitest=null/cases=null。未改源码，所以没有撤源码失败/恢复通过实验，无生产测试或gitleaks提交检查可冒称；无提交及live动作，merge=live流程无需执行，铁甲行为等价。本批报告/提案和失败产物保留，由运维按真实回执登记处置及原调度器回收；不自行删除当前工作树。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-184303-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'base': source['base'], 'proposal_results': len(results), 'report': str(OUT / 'report.md')}, ensure_ascii=False))

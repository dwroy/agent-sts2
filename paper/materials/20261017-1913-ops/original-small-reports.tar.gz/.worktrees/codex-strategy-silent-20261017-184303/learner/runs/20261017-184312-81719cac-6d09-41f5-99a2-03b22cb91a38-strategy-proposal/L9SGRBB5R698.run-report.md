## 复盘：run L9SGRBB5R698 — 阵亡，最高第 17 层

- 决策 635 个；Jev 调用 251 次，Claude 0 次，DeepSeek 16 次；token 1,161,465 入 / 11,359 出，约 $0.0493（Jev）；DeepSeek token 1,832,335 入（缓存命中 1,610,240，88%）/ 100,031 出；用时 31.3 分钟
- 决策者：jev 251，jev-plan 206，code 160，deepseek (for codex) 18

### 战斗掉血（按层）
- 第 2 层 淤泥旋螺: HP 56→55（-1），决策 code 9，jev-plan 5，jev 3
- 第 4 层 海洋混混: HP 55→47（-8），决策 code 10，jev-plan 7，jev 6
- 第 5 层 蟾蜍蝌蚪: HP 47→47（-0），决策 jev-plan 9，code 8，jev 6
- 第 7 层 气态炸弹/活雾: HP 33→24（-9），决策 jev 23，jev-plan 17，code 2
- 第 12 层 骇鳗: HP 58→14（-44），决策 jev 21，jev-plan 21，code 1
- 第 14 层 幽灵船: HP 31→27（-4），决策 jev 12，jev-plan 9，code 2
- 第 15 层 海洋混混/钙化邪教徒: HP 27→19（-8），决策 jev 17，jev-plan 13，code 2
- 第 17 层 瀑布巨兽: HP 37→0（-37），决策 jev 163，jev-plan 125，code 74

### 死亡战斗：第 17 层 瀑布巨兽
- T11 [code] combat/plan-continue: continuing the code-chosen plan: 防御
- T11 [code] combat/plan-continue: continuing the code-chosen plan: 串刺 -> 瀑布巨兽
- T11 [code] combat/plan: code plan (only line): end turn; hp -0, dmg 20
- T12 [code] combat/plan: code plan (only distinct line): 打击 -> 瀑布巨兽; hp -0, dmg 21
- T12 [code] combat/mod-lethal: mod says ending the turn is lethal, solver disagrees; not ending it: 突然一拳 -> 瀑布巨兽 [calc mismatch: solver says ending now does not kill, mod says lethal: no end-
- T12 [code] combat/plan: code plan (only line): end turn; hp -0, dmg 7 [calc mismatch: solver says ending now does not kill, mod says lethal: no end-of-turn block, Regen or Buffer the f
- T13 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-37): 打击 -> 瀑布巨兽, 致命毒药 -> 瀑布巨兽, 逃脱计划, 防御
- T13 [code] combat/plan-continue: continuing the code-chosen plan: 致命毒药 -> 瀑布巨兽
- T13 [code] combat/plan-continue: continuing the code-chosen plan: 逃脱计划
- T13 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-29): 防御, 中和 -> 瀑布巨兽
- T13 [code] combat/plan-continue: continuing the code-chosen plan: 中和 -> 瀑布巨兽
- T13 [code] combat/least-loss: every simulated line dies; playing the one that keeps the most HP (-29): end turn

### 各类决策由谁做
- combat/plan-continue / jev-plan: 206
- combat/plan-choice+potion / jev: 205
- combat/plan / code: 43
- combat/plan-continue / code: 35
- combat/plan-choice / jev: 23
- selection/choose / jev: 22
- reward/claim / code: 18
- combat/least-loss / code: 15
- map/route-follow / code: 15
- combat/lethal / code: 8
- reward/card / deepseek (for codex): 7
- reward/proceed / code: 7
- combat/mod-lethal / code: 6
- event/leave / code: 4
- rest/plan / deepseek (for codex): 4
- rest/proceed / code: 4
- event/choose / deepseek (for codex): 3
- chest/open / code: 1
- chest/proceed / code: 1
- chest/relic / code: 1
- combat/end_turn / code: 1
- event/plan / deepseek (for codex): 1
- map/route-change / deepseek (for codex): 1
- map/route-plan / deepseek (for codex): 1
- run/finalize / code: 1
- selection/enchant / deepseek (for codex): 1
- selection/take into my hand / jev: 1

### 兜底介入（Claude/DeepSeek）：0 次（推翻 Jev 0 次）

### Jev 低置信度（<0.35）决策：94 个
- 第 2 层 selection/choose: Jev chose 进阶之灾 with confidence 0.29 (0.29)
- 第 12 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.01; code rank 1 (0.01)
- 第 12 层 combat/plan-choice+potion: Jev chose plan 2/2 (打击 -> 骇鳗, 突然一拳 -> 骇鳗, 带毒刺击 -> 骇鳗) with confidence 0.22; code rank 2 (0.22)
- 第 14 层 combat/plan-choice+potion: Jev chose plan 3/3 (打击 -> 幽灵船, 致命毒药 -> 幽灵船, 突然一拳 -> 幽灵船) with confidence 0.21; code rank - (rollout's best line, added) (0.21)
- 第 14 层 combat/plan-choice+potion: Jev chose to drink 无色药水, then re-plan (confidence 0.17) (0.17)
- 第 15 层 selection/choose: Jev chose 打击 with confidence 0.14 (0.14)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/2 (带毒刺击 -> 瀑布巨兽, 防御) with confidence 0.21; code rank 1 (0.21)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.23; code rank 1 (0.23)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (小刀 -> 瀑布巨兽) with confidence 0.18; code rank 1 (0.18)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.26; code rank 1 (0.26)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.32; code rank 1 (0.32)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.29; code rank 1 (0.29)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (连续反弹, 打击 -> 瀑布巨兽, 逃脱计划) with confidence 0.29; code rank 1 (0.29)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.15; code rank 1 (0.15)
- 第 17 层 combat/plan-choice+potion: Jev chose plan 1/1 (end turn) with confidence 0.22; code rank 1 (0.22)

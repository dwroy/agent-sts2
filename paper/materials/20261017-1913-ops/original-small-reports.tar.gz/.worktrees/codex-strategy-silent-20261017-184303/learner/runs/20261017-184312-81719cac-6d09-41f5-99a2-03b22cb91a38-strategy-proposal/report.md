# 本批策略提案报告

记录时间：2026-10-17T18:54:40+08:00。任务strategy-proposal，角色silent，batch 20261017-184303-strategy-proposal。

十项均waiting；无新源码、知识、提交、合入或版本。不将已有局部诊断登记成整项duplicate/implemented，不登记shipped。详细证据/账本/预期行为和逐项验证条件见 `/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-184303/learner/runs/20261017-184312-81719cac-6d09-41f5-99a2-03b22cb91a38-strategy-proposal/proposal.md`。

## 身份与基线

开工git status干净；核root learn.json仅本批行，task/character/worktree及六局完全匹配，proposal_ids十项，无proposal_repair/research_request/implementation_request。普通任务按要求git merge --no-edit main，结果Already up to date。
完整base/HEAD：`f39a1b8e9678fddee682dcb83b4b1e8675df352e`。本次未提交源码，不制造新基线；结束另保存git核验。
六局runs.jsonl各一行均为SILENT/A10；保留原code的+dirty，不把当前live源码当当时运行全树。全程未读取其他角色知识、游戏二进制、key或.env，未联网、运行play、启动模型或派下级。

## 原日志与冻结范围

共用extract_evidence.py抽取八流，共8444条：runs6、states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、fight-plans0。各流source_size、计数、输出SHA见两份evidence-manifest；每条offset/bytes/SHA/原JSON重新seek核验通过，见raw-verification.json。
全源states/decisions/brain扫描各见2条非法JSON，extractor已计数，未以正文提及充作身份。fight-plans零行仅表示该2233957字节截点未选中本批局，不断言原日志缺失。没有覆盖旧报告或旧截点。
逐份核十个原提案Markdown SHA，并保留全部匹配队列历史与六份原局报，见proposal-queue-rows.json、run-report-sources.json。账本仅选这十项关联的16个silent ID，保留现有claim/首证/prior/evidence/status/version，不倒改历史或补写复盘。

## 已有源码覆盖及其限制

参考live快照：`6f2a20594536087c3453fa9076c5908cbec40e40`；source-comparison.json核19个源码叶的blob/SHA、实际live祖先和live字节与快照提交的一致性。17叶与本base字节同，combat.ts/explore.ts两叶仅Roy/Dai历史注释署名不同，base-live-reference.patch保留差异。此为本次读取时点，非完整生产/自然效果验收。

已存在：silent-held-loss的保守持牌/未决弃牌拆项（9d8278702dbc581b5015ba7ec9a70dc0fb94cccb）；silent-potion-reference的持有价null和同题无药范围（c4670f4f416c7d93e192e889c5080e7e4e0e733f）；silent-sl-comparison/hp-guard（66283dd9982bdd7f480da7a4d9bfefea0572a9ac）；SL资源对照（1698adc96ba434a46942321e0237b70657e625b2）；单动作派发回执（fdaf787a372880b0438e73bcac7e6d2168b038ed）；巨兽残壳用药事实（40168f4a903ae1d8c48bd03006f8fea19fd3aa3c）；阶段与SL原始指标（b01edf46b4b619f217d070a196e161df9fe716a0）；离线端点工具（a32050fbce4c2863f640468c2dbf378fc9157074）。均已核实际live祖先；调用点见combat-plan.ts、combat.ts与hand/loop.ts。

这些实现明确scope为预测/单动作回执/观测区间，完整候选实果保持null；没有完整执行和实际成本来源分账的等价交付。anchorRank仍保留最长存活和原enemyHpLeft的排序，阶段说明不等同改排序已验证。现有诊断不重复实现，整项仍保留waiting。

## 有界消费者验证

只使用本批冻结输入、现有learner/audit-selection.ts，无求解、模拟池、LLM或网络。所有原行号保留，缺失SL元数据不补，净HP差与毛伤/反事实分开。

| 局号 | 楼层 | 决策 | 状态 | 候选片段 | 可核轮端点 | 认证完整候选 |
|---|---|---:|---:|---:|---:|---:|
| 751FN9QM9MHQ | 13,17 | 435 | 437 | 75 | 83 | 0 |
| KV0JHNJCKXLS | 33 | 274 | 281 | 47 | 22 | 0 |
| YQL8RZ8BWN1E | 17 | 328 | 329 | 147 | 63 | 0 |
| L9SGRBB5R698 | 17 | 363 | 370 | 151 | 65 | 0 |
| PU80F84P6HPN | 17 | 446 | 447 | 54 | 76 | 0 |
| KEN58SH9SLZ6 | 3,4,5,11,15,17 | 482 | 490 | 92 | 70 | 0 |

共2328决策/2354状态、566候选片段、379可核轮端点；完整候选认证0为工具当前边界，不能据null推断动作未发生或收益为0。其余轮端点未知原因逐局保存在consumer-summary.json；KV两组T5均turn_end_unverified，原题面的36/29不可冒充消费者认证整轮实果。

首次runs.character大小写断言失败，归一后六局通过；原值未改，见identity-initial-failure.txt。初次消费者前五局退出0；KEN因F5原decisions274207的map/route-change非战斗元事件无decision_id退出1。原输入/失败stderr/脚本/日志保留；只在新scoped-input中排除该一条事件，不补ID、不删战斗/选择决策或状态。第二轮只执行KEN，退出0，前五输出原SHA保持。排除原JSON及原因见consumer-input-exclusions.json。消费者0不是生产tsc/Vitest通过。

六组原同指纹对照均核等，见verified-pairs.json；751三组和KEN两组观测净HP端点与原复盘一致，见key-turn-endpoints.json。YQL280160→280161残壳毒2→8，血26/挡13/41来袭未变；KEN七次逐槽有药→空并有用药请求，其中两攻击药及技能药回执pending。后帧槽位变化不认证随机牌全收益，来源与后战收益仍留未知。

## 结论、等待条件与交付

局部数据支持同时保留血价、实伤与能力建立窗口；并列推演不消除血价，当轮省血也不证明后继更优。六次同局SL相关，不能做六个独立拟合/验证样本，复盘和经验双提案不增加分母。缺完整候选归属、受控整战后继、无药/留药跨战对照和后期独立验证，本次不拟合新阈值。
逐项proposal_results在result.json及proposal.md；没有新游戏异议需要推翻原经验，没有新增代码提案ID。代码提案数组沿用本批十个真实CLI ID，implementation_domains空。只经根ledger.py追加本批报告追溯，既有shipped不得降级为proposed；追溯不新增support/反例或经验条目，执行回执另存。

fixes=[]、merged=null、版本null；生产tests固定tsc=null/vitest=null/cases=null。未改源码，所以没有撤源码失败/恢复通过实验，无生产测试或gitleaks提交检查可冒称；无提交及live动作，merge=live流程无需执行，铁甲行为等价。本批报告/提案和失败产物保留，由运维按真实回执登记处置及原调度器回收；不自行删除当前工作树。

## 最终记录核验

2026-10-17T18:56:37+08:00：根ledger CLI update退出0，仅追加16条where/note追溯，旧23067896字节前缀SHA256 8620213ed639cee2ae7114aecf72e675fd1e6ae062d654f85b1de17bfb3fcfd5保持；保护字段变化0，见ledger-trace-receipt.json。根ledger check退出0（506条，0问题）。本批产物gitleaks退出0、未发现泄漏，仅作材料检查，非提交或生产测试。HEAD仍为f39a1b8e9678fddee682dcb83b4b1e8675df352e，tracked/index干净；六份消费者输入/输出SHA均核同，十项真实派发ID均有waiting理由。无源码修改及合入。

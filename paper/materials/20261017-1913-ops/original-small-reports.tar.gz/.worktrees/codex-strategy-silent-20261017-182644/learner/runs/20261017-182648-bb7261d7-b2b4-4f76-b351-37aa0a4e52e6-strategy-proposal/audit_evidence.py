"""核验本批冻结抽取，保留有界实盘摘要，不拟合策略参数。"""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
FOCUS = {
    'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39},
    'CA5KE8GFJ9X2': {13}, '8JRE1C4H4Z2W': {17, 33},
    'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33},
}


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def powers(entity):
    raw = entity.get('powers')
    return {p['power_id']: p.get('amount') for p in raw if isinstance(p, dict)} if isinstance(raw, list) else None


def ref(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def state_brief(item):
    row = item['row']; state = row['state']; combat = state.get('combat') or {}
    player = combat.get('player') or {}
    enemies = []
    for enemy in combat.get('enemies', []):
        enemies.append({**{k: enemy.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'is_alive', 'move_id')},
                        'powers': powers(enemy), 'intents': enemy.get('intents'),
                        'identity_keys': [k for k in enemy if 'instance' in k or 'uuid' in k or 'generation' in k]})
    return {**ref(item), 'observed_ts': row.get('observed_ts'), 'ts': row.get('ts'),
            'floor': state.get('run', {}).get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp'), 'block': player.get('block'), 'energy': player.get('energy'),
            'cards_played': player.get('cards_played_this_turn'), 'powers': powers(player), 'enemies': enemies,
            'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'dynamic_values')} for c in combat.get('hand', [])]}


counts = {}; checks = []; state_rows = []; selected_decisions = []; sl_rows = []; plans = []
decision_rows = {}
manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
for stream in manifest:
    name = stream['stream']; path = HERE / ('evidence/' + name + '.evidence.jsonl')
    digest = hashlib.sha256(); actual = Counter(); verified = 0
    with path.open('rb') as handle, Path('/home/dw/Projects/agent-sts2/logs/' + name + '.jsonl').open('rb') as source:
        for encoded in handle:
            digest.update(encoded); item = json.loads(encoded); actual[item['run_id']] += 1
            source.seek(item['offset']); original = source.read(item['bytes'])
            assert hashlib.sha256(original).hexdigest() == item['sha256']
            assert json.loads(original) == item['row']
            assert item['offset'] + item['bytes'] <= stream['source_size']
            verified += 1; row = item['row']; run = item['run_id']
            if name == 'states':
                state = row['state']
                assert state['run_id'] == run
                run_state = state.get('run') or {}
                if run_state:
                    assert run_state.get('character_id') == 'SILENT' and run_state.get('ascension') == 10
                if run_state.get('floor') in FOCUS[run] and state.get('combat'):
                    state_rows.append(state_brief(item))
            elif name == 'decisions':
                decision_rows[item['line']] = item
                if row.get('floor') in FOCUS[run]:
                    selected_decisions.append({**ref(item), **{k: row.get(k) for k in (
                        'ts', 'observed_ts', 'floor', 'turn', 'label', 'decision_id', 'chosen', 'result', 'sl_explore',
                        'selection_audit', 'selection_dispatch', 'hp_guard_audit', 'guard', 'rationale')},
                        'keys': list(row)})
            elif name == 'sl-attempts':
                sl_rows.append({**ref(item), 'row': row})
            elif name in ('run-config', 'run-plans', 'fight-plans'):
                plans.append({**ref(item), 'row': row})
    assert digest.hexdigest() == stream['output_sha256']
    assert dict(actual) == {k:v for k,v in stream['counts'].items() if v}
    counts[name] = dict(actual)
    checks.append({'stream': name, 'source_size': stream['source_size'], 'verified_rows': verified,
                   'output_sha256': digest.hexdigest(), 'offset_bytes_sha_json': True})

with (HERE / 'focused-states.jsonl').open('w') as handle:
    for row in state_rows: handle.write(json.dumps(row, ensure_ascii=False) + '\n')
with (HERE / 'focused-decisions.jsonl').open('w') as handle:
    for row in selected_decisions: handle.write(json.dumps(row, ensure_ascii=False) + '\n')
save('sl-attempts-selected.json', sl_rows)
save('plans-and-configs.json', plans)

pairs = []
for a, b in [(270216,270282), (271309,271348), (271992,272040), (271982,272195)]:
    before, after = decision_rows[a], decision_rows[b]
    assert before['run_id'] == after['run_id']
    ra, rb = before['row'], after['row']
    assert ra['fingerprint'] == rb['fingerprint']
    pair = {'original': ref(before), 'replacement': ref(after), 'fingerprint_identical': True}
    for key, row in [('original_decision',ra), ('replacement_decision',rb)]:
        pair[key] = {k:row.get(k) for k in ('floor','turn','chosen','sl_explore','rationale','result','questions','answers')}
    pairs.append(pair)
save('paired-decisions.json', pairs)

byline = {r['line']: r for r in state_rows}
endpoints = []
for a,b in [(277327,277337),(277366,277373),(278017,278021),(278231,278236)]:
    first,last=byline[a],byline[b]
    assert first['run_id'] == last['run_id']
    hp_loss=first['hp']-last['hp']
    enemy_before=sum(e['current_hp'] for e in first['enemies'])
    enemy_after=sum(e['current_hp'] for e in last['enemies'])
    endpoints.append({'first':first,'last':last,'observed_net_hp_loss':hp_loss,
                      'enemy_body_hp_net_decrease':enemy_before-enemy_after,
                      'note':'仅所列端点净差；不自动归为候选完成、毛伤或受控整战收益。'})
save('paired-state-endpoints.json', endpoints)

turns = defaultdict(list)
for row in state_rows:
    turns[(row['run_id'],row['floor'],row['turn'])].append(row)
turn_summary=[]
for (run,floor,turn), rows in turns.items():
    turn_summary.append({'run_id':run,'floor':floor,'turn':turn,'rows':len(rows),
                         'first_line':rows[0]['line'],'last_line':rows[-1]['line'],
                         'note':'可能包括同存档多次尝试，不将此分组当独立样本。'})
save('turn-index.json',turn_summary)
save('evidence-verification.json',{'checks':checks,'counts':counts,'focused_states':len(state_rows),
    'focused_decisions':len(selected_decisions),'same_fingerprint_pairs':len(pairs),
    'production_tests_run':False})
print(json.dumps({'verified_rows':sum(c['verified_rows'] for c in checks),'counts':counts,
    'focused_states':len(state_rows),'focused_decisions':len(selected_decisions),
    'pairs':len(pairs),'endpoints':[{'first':e['first']['line'],'last':e['last']['line'],
        'hp_loss':e['observed_net_hp_loss'],'enemy_hp_net':e['enemy_body_hp_net_decrease']} for e in endpoints]},ensure_ascii=False))

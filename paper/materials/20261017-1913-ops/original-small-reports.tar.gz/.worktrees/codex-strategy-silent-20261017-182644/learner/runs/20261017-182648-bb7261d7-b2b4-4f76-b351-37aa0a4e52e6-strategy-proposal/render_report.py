"""将本批逐项核验写成报告和调度器回报；不修改生产源码或提案队列。"""
import datetime
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch.json').read_text())
proposals = json.loads((HERE / 'selected-proposals.json').read_text())
source = json.loads((HERE / 'source-readback.json').read_text())
verification = json.loads((HERE / 'evidence-verification.json').read_text())
facts = {
    'c20b5139dd0dff71': {
        'where': 'DUZUBAJ3A8GP F27 T4—T6；states 274830—274839',
        'finding': 'T4火花3，迷雾使污染0→3，勒紧能力不加污染，防御再到6；T5火花6，技能使污染0→6→12→18，弱后攻击26、17挡、HP46→37；T6污染已清。',
        'counter': '技能同时有施毒、虚弱或格挡收益；这场仍继续至后续楼层，不能按污染层数固定禁止技能。',
        'expected': '冻结当前技能效果、逐击污染血价及当前进阶敌方数据，保留所有候选。',
        'reason': '已核污染增长与清除端点；未恢复历史dirty A10移动表，也未完成火花增长、毒、弱、挡联合的生产路径固定重放，不能认证整项实现或改技能权重。',
        'validate': '用真实冻结输入逐步重放T4—T6；比较污染、施毒、挡、HP及敌本体HP，核新增技能代价与原效果同时兑现。',
    },
    'ae9e692d680e3819': {
        'where': '5PM6JAQG6FNQ F39 首试T4—T6、末试T4；states 274351—274362、274391—274397',
        'finding': '首试T4力敏均−4，两步法只将敏捷恢复0；失落毒死后次轮力量恢复，遗忘T6再次抢夺使敏捷−2。末试一步法只到−2，失落毒死后仍8血0挡对遗忘19攻击死亡。POSSESS标记层数1并不是累计抢夺4或6。',
        'counter': '返还力量没有使末试存活；现帧负属性与敌方普通属性也不能独立证明各自累计抢夺量。',
        'expected': '按实体记录抢夺及返还，保留负属性和后续再次抢夺；不给固定击杀顺序。',
        'reason': '缺逐实体累计抢夺真值及遗忘退场返敏的完整链；本批不能把POSSESS层数1或当前属性直接当返还量，亦缺完整目标顺序对照。',
        'validate': '冻结两实体完整抢夺、退场、返还和再次抢夺序列，逐动作比对玩家属性及后续攻击/格挡；先确定可复现失配再改。',
    },
    '52f1e1bd2e7db0ed': {
        'where': 'CA5KE8GFJ9X2 F13 T1—T5；states 273237—273269',
        'finding': '轮初覆甲9/9/8/7/6；两次加压后力量0→4→8，喷水11→15→19，弱后11/14。末轮2血10挡对14，HP归零，敌本体余16。',
        'counter': '这条连续实盘链不等于现生产组合已重放匹配；末帧覆甲5不应误当T5轮初值。sl-attempts该局选中0与没有读档相符，不据此推断日志丢失。',
        'expected': '第一样本起读取当前进阶HP/攻击事实；房间代价仍保留五胜样本门槛。',
        'reason': '当前源码已有按进阶取数与覆甲路径，未发现本批可确定的新源码失配；历史dirty移动表未恢复，尚无加压、覆甲、弱联合的固定生产重放，不能整项登记duplicate。',
        'validate': '以冻结数据库和实盘动作重放五轮，分清轮初与结算后覆甲；单样本事实入口及ROOM_COST_MIN_N=5分别验收。',
    },
    '6dd8bbff876be528': {
        'where': '5PM6JAQG6FNQ F38 T3—T4；states 274308—274316',
        'finding': '最大HP23电击机器人T3力量2/攻击17，T4力量4/攻击19，高电压均2；T3玩家61→31，机器人到T4才退场。',
        'counter': '先杀爪牙的35伤/损3候选未实打；不能宣称可把预计27血全带进F39。同最大HP、enemy_id和数组index不是可靠召唤代际身份。',
        'expected': '复验现有HIGH_VOLTAGE逐实体增长，当前进阶攻击取数据库；新实体不继承旧计数。',
        'reason': '已有HIGH_VOLTAGE增长接线，但缺可靠召唤代际身份及历史移动表联合重放，不能由两帧增长认证新召唤者重置或固定击杀序。',
        'validate': '固定召唤、增长、退场、再召唤的完整链；先验证实体匹配和重置，再比较同一实例连续两轮意图。',
    },
    '578e415a259e6835': {
        'where': '8JRE1C4H4Z2W F33 首/第三试T2、第二试T5、末试T11，另F17T6；decisions 270216/270282/270264',
        'finding': '首/第三试T2同指纹：实际损3→15、本体净扣10→17；五轮死亡0/24与5/24不同。HP护栏候选差和抽牌重规划后的实际资源必须分账。末试T11已有能力仍仅22挡、5血对37。',
        'counter': '更偏防御的末次尝试延至T11仍败；F17T6抽牌后重规划，不能把首题候选省血直接登记为实际收益。',
        'expected': '贯通原答、护栏、SL、首次派发与重规划，分列沙坑、毒、挡、成长和实际血价。',
        'reason': '当前已有预测分段及单动作回执；完整候选续步执行归属、沙坑逐来源结算和路线资源链尚未联合认证，缺独立受控整战后继，不改护栏或探索参数。',
        'validate': '固定F17T6、F33T2/T5/T11，逐步连接同一观测、候选、派发、抽弃边界和后继；候选未完成时保留未知。',
    },
    'c0767768bf6a7ab1': {
        'where': 'YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348；states 277327→277337、277366→277373',
        'finding': '同指纹候选均24/24死、后损封顶27；实际损0→9、本体净扣45→38。第三试拟定续步被截断，题面预测不等于完整执行。',
        'counter': '第六试恢复防御续步仍T5败；本局F33第二试确实SL获胜，不能由F48失败否定所有SL。',
        'expected': '展示全败并列及资源代价，追踪重放、未派发续步与实际结果，保留探索。',
        'reason': '缺完整候选执行认证和逐来源血价归属；现单动作回执不证明全轮执行，也无同抽序完整替线及独立胜线，不能拟惩罚系数或禁探索。',
        'validate': '对齐上述同盘配对与F33成功反例，跨抽弃/药水边界标记续步是否派发；长期策略验收按独立局后移。',
    },
    'a46bdb7fe711d79a': {
        'where': 'YF0LXT1QSTGG F48 末试T3—T5；states 277512—277528',
        'finding': '阶段转为212HP后旧毒/力清空；触媒2已建但T5零毒。T5先有5敏形成13+10=23挡，第三小刀后敏捷升6不倒补；四刀及额外扣血、刀舞消耗需分源，末18血面对44攻击仍死。',
        'counter': '多次建立毒雾或余像的尝试仍败；不从零毒触媒推定唯一死因，不预支手牌或牌组里的毒组件。',
        'expected': '逐阶段列当前HP、已建能力、当前毒、即时施毒、已结算毒伤和敏捷取得顺序。',
        'reason': '已有当前阶段快照与零毒说明；逐候选施毒、毒伤、额外扣血及敏捷取得顺序的完整执行归属尚缺，不能由窄阶段修复认整项完成或改排序。',
        'validate': '固定阶段切换、零毒触媒与23挡时点，逐动作分开攻击本体扣血、额外伤害和毒结算；候选事实须接实际派发。',
    },
    '1044224808015e5c': {
        'where': 'XP2SL33HT0D9 F33 首/第二试T3、首/末试T1；decisions 271992/272040、271982/272195',
        'finding': 'T3同指纹实损9→14、本体净扣24→27；T1同指纹实损2→10、本体净扣25→34，替线同时建立手里剑1力量；B2两线均0胜。',
        'counter': '末试T2因镣铐、朝向及格挡而零损，T3损4；不能把舍挡一概判错，也不能抹掉永久力量收益。',
        'expected': '并列原因、样本/信度、当轮HP代价、进度与成长分列；仅有独立证据时调整窄SL选择。',
        'reason': '缺同抽序完整替线、成长兑现的受控后继及独立整战胜线；多5血换3伤或多8血换9伤不能直接拟全局参数，保留原SL规则。',
        'validate': '当前三组资源与成长事实可作回归；策略调参须整局切分、后移验证，并保留成功探索反例。',
    },
    '7cbc6005db712ba9': {
        'where': 'XP2SL33HT0D9 F33 末试T2—T5；states 278236—278261',
        'finding': 'T2轮初14挡、镣铐爪0→−9力、4→0攻击，转向后火箭30→20，斗篷加6到20，次轮HP仍37且爪减力恢复。T4火箭57→38→28，4敏脆弱下偏折6挡。末T5毒实扣3+7、两敌余153/125。',
        'counter': '六次T2的14挡不等于每轮都有；能力已建立仍无一侧减员。末轮HP净损按11血截断，不能据此压低完整入伤。',
        'expected': '现场已有挡、本线新增挡、朝向、弱、临时减力、已结算毒及存活HP统一分源展示。',
        'reason': '已有相关机制与部分参考，但缺逐候选既有/新增挡、朝向虚弱、已结算毒与生存HP统一来源的生产联合认证，不冒整项duplicate或新增出牌权重。',
        'validate': '固定14+6、0→−9→0、57→38→28、4敏脆弱6挡及末轮毒端点，核完整执行与抽弃重规划分别落盘。',
    },
    'c59f592f1427a67e': {
        'where': 'YF0LXT1QSTGG F48 T1/T4/T5及路线资源；XP2SL33HT0D9 F33 T1—T5与F22/F30/F31',
        'finding': '本批直接核四组同指纹资源差、阶段快照、镣铐恢复、朝向与挡兑现；两局赢战耗血和SL资源恢复在本角色原复盘已分列，不能把存档恢复算路线回血。',
        'counter': 'YF有成功SL但末boss全败；XP已建力敏仍未减员。两份历史提案中的跨历史计数没有在本批重做，不能当新增独立验证样本。',
        'expected': '原答/SL/覆盖重放/实际完成分段，毒与额外扣血分源；路线、休息及药水时机保持观察范围。',
        'reason': '缺逐来源资源账与完整候选归属的联合认证，亦无路线/药水时机受控替线及独立整战后继；本批六锚点不补成跨全历史量化学习。',
        'validate': '先统一上述配对、机制与实际执行归属；路线药水结论须另有本角色完整时序对照，不修改未证权重。',
    },
}

now = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
results=[]; sections=[]
for item in proposals:
    f=facts[item['id'].split('-')[-1]]
    results.append({'id':item['id'],'state':'waiting','reason':f['reason']})
    sections.append('\n'.join([
        '## '+item['id'], '', '账本：'+ '、'.join(item['ledger'])+'。', '',
        '证据：'+f['where']+'。', '', '核实：'+f['finding'], '',
        '反例与限制：'+f['counter'], '', '旧规则与预期行为：'+f['expected'], '',
        '处置：waiting。'+f['reason'], '', '后续验证：'+f['validate'], '',
        '拟合与切分：本批不拟合参数；同存档SL仍归原run_id，发现样本不作为独立后移验证。', '',
        '回退：本批无生产改动。后续如实现，单项撤生产源码须使针对性固定测试失败、恢复通过，并走原沙箱/live/版本/双通知流程。', '',
        '原提案：'+item['proposal']+'；原文SHA256：'+item['proposal_sha256']+'。',
    ]))

header = f'''# 静默猎手 A10 十项派发提案复核

记录时间：{now}。来源/实现任务：strategy-proposal；batch：20261017-182644-strategy-proposal。
base：{source['base']}；只读live快照：{source['live_snapshot']}。

只处理本批十个原id，未创建重复提案、未认领其他队列。六局角色均为SILENT、进阶10；没有research_request或implementation_request。本树已执行git merge --no-edit main，结果Already up to date。未改源码、知识或任务模板，无源码提交、合入、行为版本或shipped。

原提案允许先补审计；当前已有预测字段及单动作回执，完整候选执行归属仍未认证。waiting不表示这些窄字段没有实现，也不表示日志原件缺失；需要的是各项列出的联合校准或受控后继。确定性机制无需先证明胜局才能修；本批未得到足以指向新确定源码失配的固定复现，不为产出代码而添加假设。

8274条八流引用逐条按原source offset/bytes/SHA/JSON复核，完整输出SHA也核同；其中4062状态、3941决策。聚焦1060帧状态、1043条决策，另保存50个关键机制端点、四组同指纹配对。所有数字均只来自本角色本批证据；同存档尝试不扩大独立局数。

原报告、原提案及初稿保留，原提案不改写。每条完整证据引用见evidence/、focused-states.jsonl、focused-decisions.jsonl、paired-decisions.json、paired-turn-endpoints-v2.json和mechanism-endpoints.json。仅追溯的账本CLI更新保留原claim、evidence、status、version、effect与首证，不重复增加support/repeat或降级已shipped条目。
'''
(HERE/'proposal.md').write_text(header+'\n\n'+'\n\n'.join(sections)+'\n')

table='| 原提案id | 证据局/层/回合 | 处置及缺口 |\n|---|---|---|\n'
for item,result in zip(proposals,results):
    table += '| '+item['id']+' | '+facts[item['id'].split('-')[-1]]['where']+' | waiting：'+result['reason']+' |\n'

report = header + '''
## 逐项处置

''' + table + '''
每项完整账本id、反例、旧规则/预期行为、验证、拟合范围和回退见同目录proposal.md。原提案Markdown均按队列登记SHA核回并保存为<id>.original.md；selected-proposals.json保留本次只读队列快照，dispatch.json保留领取身份。

## 可确认的同盘资源差

| 来源 | 原线/替线实际净损HP | 原线/替线敌本体净扣 | 替线减原线 |
|---|---|---|---|
| 8JRE1C4H4Z2W F33 T2 | 3 / 15 | 10 / 17 | +12血价、+7进度 |
| YF0LXT1QSTGG F48 T1 | 0 / 9 | 45 / 38 | +9血价、−7进度 |
| XP2SL33HT0D9 F33 T3 | 9 / 14 | 24 / 27 | +5血价、+3进度 |
| XP2SL33HT0D9 F33 T1 | 2 / 10 | 25 / 34 | +8血价、+9进度，另有1力量成长 |

四对完整fingerprint逐字相同；次轮首帧按decisions.observed_ts关联states定位，原始offset/bytes/SHA保存在paired-turn-endpoints-v2.json。这些是观测端点净差，包含实际结算；没有自动归为完整候选、某一伤害来源或整战单变量因果。第一对0/24与5/24死亡不同，其余所述全败并列不等于安全。

初稿paired-state-endpoints.json中XP首试278017→278021停在敌方结算前，净损为0，只是这个前缀事实。校正版保留初稿并另存v2，按决策观测278018→次轮278023核得实损2；没有覆写原字节或把前缀0冒成全轮0。

## 源码现状及缺输入

source-readback.json核15个相关叶的base/live blob与文件SHA。11叶同字节，另外4叶差异仅Roy/Dai历史署名文字；完整git diff --binary保存在source-reference.patch。窄审计源码祖先66283dd9982bdd7f480da7a4d9bfefea0572a9ac和1698adc96ba434a46942321e0237b70657e625b2均为当时base及live祖先。仅用来证明已有接线，未将任一窄祖先用于整项implemented/duplicate。

- silent-selection-audit.ts保留原答、SL前后预测、requested_action；actual_turn仍null。
- silent-selection-dispatch.ts及hand/loop.ts提供实际单动作回执；whole_plan_executed仍null，成功响应也未宣称效果已核。
- silent-sl-resource-comparison.ts提供当轮HP/伤害/挡/力量、污染及回合后余毒差，execution为unverified。
- silent-phase-current.ts展示当前阶段HP、实有毒/能力/挡/敏捷，已结算毒伤仍null；它不代替逐候选派发归属。
- rollout.ts已列HIGH_VOLTAGE及覆甲路径，rollout-live.ts按asc读取移动表；monster-db.ts保留ROOM_COST_MIN_N=5。不能因原提案写waiting就假定现源码没有这些能力。

六份run-config均记录dirty=true且knowledge/common/monster-db.json在dirty_files，具体提交及知识前缀SHA元数据见historical-input-limitations.json；这些元数据没有恢复完整历史数据库字节。本批未拿当前滚动数据库替代历史输入，也未用今天源码冒充当时完整dirty组合。尚缺的联合校准按各提案列明。

eight-stream抽取manifest保存各流source_size和invalid_lines：states/decisions/brain各有2个不可解析行，未接收为证据；其余0。fight-plans在本次2233957字节截点对六局均选中0，仅说明该截点未选到，不能断言原日志不存在；run-plans已按run字段选中33行。CA的sl-attempts选中0也不作为证据缺失结论。

## 验证、记录与交接

本批只做原日志/提案SHA与状态端点核验，没有执行生产求解、模拟、LLM、网络或游戏动作。未改生产源码，撤源码失败/恢复通过不适用；tsc、vitest、cases均为null，未借历史测试绿色。无提交，无live合并，无新eval版本，无规则上线双通知；铁甲及其他角色行为无变化。

ledger-update-request.jsonl与ledger-update-result.json保存唯一根ledger.py update追溯请求及实际结果；只连本批proposal.md/report.md和十原提案id，by=learner:strategy-proposal，不加经验、不设新状态、不代ops登记shipped。ledger-readback.json记录逐项原状态/版本/证据/首证保持及新链接读回。原专用队列状态由调度器消费report.json中的proposal_results，学习者不手写队列。

报告给运维：本目录report.md；逐项提案：本目录proposal.md。全部十项waiting，保留待相应新增证据，不把本批锚点叫作全历史量化学习完成。
'''
(HERE/'report.md').write_text(report)
report_json={'task':'strategy-proposal','character':'silent','batch':'20261017-182644-strategy-proposal',
    'base':source['base'],'runs':dispatch['runs'],'fixes':[],'skipped':results,'merged':None,
    'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':dispatch['proposal_ids'],
    'implementation_domains':[],'proposal_results':results,'report':str(HERE/'report.md')}
(HERE/'report.json').write_text(json.dumps(report_json,ensure_ascii=False,indent=2)+'\n')
before=json.loads((HERE/'ledger-selected-before.json').read_text())
updates=[]
for ident in sorted(before):
    related=[r for p,r in zip(proposals,results) if ident in p['ledger']]
    updates.append({'id':ident,'by':'learner:strategy-proposal',
        'where':{'proposal':[str(HERE/'proposal.md'),str(HERE/'report.md')]},
        'note':'本批20261017-182644-strategy-proposal核验：'+ '；'.join(r['id']+' waiting：'+r['reason'] for r in related)+
        '。仅追加追溯，不重复计支持或反例、不改旧claim/首证/prior/status/version/effect，不认implemented或shipped。'})
(HERE/'ledger-update-request.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in updates))
print(json.dumps({'report':str(HERE/'report.md'),'proposal':str(HERE/'proposal.md'),'waiting':len(results),'ledger_links':len(updates)},ensure_ascii=False))

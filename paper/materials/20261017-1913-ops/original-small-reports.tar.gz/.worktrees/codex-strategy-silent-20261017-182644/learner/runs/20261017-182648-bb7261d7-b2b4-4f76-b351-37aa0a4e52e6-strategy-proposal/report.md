# 静默猎手 A10 十项派发提案复核

记录时间：2026-10-17T18:36:05+08:00。来源/实现任务：strategy-proposal；batch：20261017-182644-strategy-proposal。
base：f39a1b8e9678fddee682dcb83b4b1e8675df352e；只读live快照：6f2a20594536087c3453fa9076c5908cbec40e40。

只处理本批十个原id，未创建重复提案、未认领其他队列。六局角色均为SILENT、进阶10；没有research_request或implementation_request。本树已执行git merge --no-edit main，结果Already up to date。未改源码、知识或任务模板，无源码提交、合入、行为版本或shipped。

原提案允许先补审计；当前已有预测字段及单动作回执，完整候选执行归属仍未认证。waiting不表示这些窄字段没有实现，也不表示日志原件缺失；需要的是各项列出的联合校准或受控后继。确定性机制无需先证明胜局才能修；本批未得到足以指向新确定源码失配的固定复现，不为产出代码而添加假设。

8274条八流引用逐条按原source offset/bytes/SHA/JSON复核，完整输出SHA也核同；其中4062状态、3941决策。聚焦1060帧状态、1043条决策，另保存50个关键机制端点、四组同指纹配对。所有数字均只来自本角色本批证据；同存档尝试不扩大独立局数。

原报告、原提案及初稿保留，原提案不改写。每条完整证据引用见evidence/、focused-states.jsonl、focused-decisions.jsonl、paired-decisions.json、paired-turn-endpoints-v2.json和mechanism-endpoints.json。仅追溯的账本CLI更新保留原claim、evidence、status、version、effect与首证，不重复增加support/repeat或降级已shipped条目。

## 逐项处置

| 原提案id | 证据局/层/回合 | 处置及缺口 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | DUZUBAJ3A8GP F27 T4—T6；states 274830—274839 | waiting：已核污染增长与清除端点；未恢复历史dirty A10移动表，也未完成火花增长、毒、弱、挡联合的生产路径固定重放，不能认证整项实现或改技能权重。 |
| silent-proposal-ae9e692d680e3819 | 5PM6JAQG6FNQ F39 首试T4—T6、末试T4；states 274351—274362、274391—274397 | waiting：缺逐实体累计抢夺真值及遗忘退场返敏的完整链；本批不能把POSSESS层数1或当前属性直接当返还量，亦缺完整目标顺序对照。 |
| silent-proposal-52f1e1bd2e7db0ed | CA5KE8GFJ9X2 F13 T1—T5；states 273237—273269 | waiting：当前源码已有按进阶取数与覆甲路径，未发现本批可确定的新源码失配；历史dirty移动表未恢复，尚无加压、覆甲、弱联合的固定生产重放，不能整项登记duplicate。 |
| silent-proposal-6dd8bbff876be528 | 5PM6JAQG6FNQ F38 T3—T4；states 274308—274316 | waiting：已有HIGH_VOLTAGE增长接线，但缺可靠召唤代际身份及历史移动表联合重放，不能由两帧增长认证新召唤者重置或固定击杀序。 |
| silent-proposal-578e415a259e6835 | 8JRE1C4H4Z2W F33 首/第三试T2、第二试T5、末试T11，另F17T6；decisions 270216/270282/270264 | waiting：当前已有预测分段及单动作回执；完整候选续步执行归属、沙坑逐来源结算和路线资源链尚未联合认证，缺独立受控整战后继，不改护栏或探索参数。 |
| silent-proposal-c0767768bf6a7ab1 | YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348；states 277327→277337、277366→277373 | waiting：缺完整候选执行认证和逐来源血价归属；现单动作回执不证明全轮执行，也无同抽序完整替线及独立胜线，不能拟惩罚系数或禁探索。 |
| silent-proposal-a46bdb7fe711d79a | YF0LXT1QSTGG F48 末试T3—T5；states 277512—277528 | waiting：已有当前阶段快照与零毒说明；逐候选施毒、毒伤、额外扣血及敏捷取得顺序的完整执行归属尚缺，不能由窄阶段修复认整项完成或改排序。 |
| silent-proposal-1044224808015e5c | XP2SL33HT0D9 F33 首/第二试T3、首/末试T1；decisions 271992/272040、271982/272195 | waiting：缺同抽序完整替线、成长兑现的受控后继及独立整战胜线；多5血换3伤或多8血换9伤不能直接拟全局参数，保留原SL规则。 |
| silent-proposal-7cbc6005db712ba9 | XP2SL33HT0D9 F33 末试T2—T5；states 278236—278261 | waiting：已有相关机制与部分参考，但缺逐候选既有/新增挡、朝向虚弱、已结算毒与生存HP统一来源的生产联合认证，不冒整项duplicate或新增出牌权重。 |
| silent-proposal-c59f592f1427a67e | YF0LXT1QSTGG F48 T1/T4/T5及路线资源；XP2SL33HT0D9 F33 T1—T5与F22/F30/F31 | waiting：缺逐来源资源账与完整候选归属的联合认证，亦无路线/药水时机受控替线及独立整战后继；本批六锚点不补成跨全历史量化学习。 |

每项完整账本id、反例、旧规则/预期行为、验证、拟合范围和回退见同目录proposal.md。原提案Markdown均按队列登记SHA核回并保存为<id>.original.md；selected-proposals.json保留本次只读队列快照，dispatch.json保留领取身份。

## 可确认的同盘资源差

| 来源 | 原线/替线实际净损HP | 原线/替线敌本体净扣 | 替线减原线 |
|---|---|---|---|
| 8JRE1C4H4Z2W F33 T2 | 3 / 15 | 10 / 17 | +12血价、+7进度 |
| YF0LXT1QSTGG F48 T1 | 0 / 9 | 45 / 38 | +9血价、−7进度 |
| XP2SL33HT0D9 F33 T3 | 9 / 14 | 24 / 27 | +5血价、+3进度 |
| XP2SL33HT0D9 F33 T1 | 2 / 10 | 25 / 34 | +8血价、+9进度，另有1力量成长 |

四对完整fingerprint逐字相同；次轮首帧按decisions.observed_ts关联states定位，原始offset/bytes/SHA保存在paired-turn-endpoints-v2.json。这些是观测端点净差，包含实际结算；没有自动归为完整候选、某一伤害来源或整战单变量因果。第一对0/24与5/24死亡不同，其余所述全败并列不等于安全。

初稿paired-state-endpoints.json中XP首试278017→278021停在敌方结算前，净损为0，只是这个前缀事实。校正版保留初稿并另存v2，按决策观测278018→次轮278023核得实损2；没有覆写原字节或把前缀0冒成全轮0。

## 源码现状及缺输入

source-readback.json核15个相关叶的base/live blob与文件SHA。11叶同字节，另外4叶差异仅Roy/Dai历史署名文字；完整git diff --binary保存在source-reference.patch。窄审计源码祖先66283dd9982bdd7f480da7a4d9bfefea0572a9ac和1698adc96ba434a46942321e0237b70657e625b2均为当时base及live祖先。仅用来证明已有接线，未将任一窄祖先用于整项implemented/duplicate。

- silent-selection-audit.ts保留原答、SL前后预测、requested_action；actual_turn仍null。
- silent-selection-dispatch.ts及hand/loop.ts提供实际单动作回执；whole_plan_executed仍null，成功响应也未宣称效果已核。
- silent-sl-resource-comparison.ts提供当轮HP/伤害/挡/力量、污染及回合后余毒差，execution为unverified。
- silent-phase-current.ts展示当前阶段HP、实有毒/能力/挡/敏捷，已结算毒伤仍null；它不代替逐候选派发归属。
- rollout.ts已列HIGH_VOLTAGE及覆甲路径，rollout-live.ts按asc读取移动表；monster-db.ts保留ROOM_COST_MIN_N=5。不能因原提案写waiting就假定现源码没有这些能力。

六份run-config均记录dirty=true且knowledge/common/monster-db.json在dirty_files，具体提交及知识前缀SHA元数据见historical-input-limitations.json；这些元数据没有恢复完整历史数据库字节。本批未拿当前滚动数据库替代历史输入，也未用今天源码冒充当时完整dirty组合。尚缺的联合校准按各提案列明。

eight-stream抽取manifest保存各流source_size和invalid_lines：states/decisions/brain各有2个不可解析行，未接收为证据；其余0。fight-plans在本次2233957字节截点对六局均选中0，仅说明该截点未选到，不能断言原日志不存在；run-plans已按run字段选中33行。CA的sl-attempts选中0也不作为证据缺失结论。

## 验证、记录与交接

本批只做原日志/提案SHA与状态端点核验，没有执行生产求解、模拟、LLM、网络或游戏动作。未改生产源码，撤源码失败/恢复通过不适用；tsc、vitest、cases均为null，未借历史测试绿色。无提交，无live合并，无新eval版本，无规则上线双通知；铁甲及其他角色行为无变化。

ledger-update-request.jsonl与ledger-update-result.json保存唯一根ledger.py update追溯请求及实际结果；只连本批proposal.md/report.md和十原提案id，by=learner:strategy-proposal，不加经验、不设新状态、不代ops登记shipped。ledger-readback.json记录逐项原状态/版本/证据/首证保持及新链接读回。原专用队列状态由调度器消费report.json中的proposal_results，学习者不手写队列。

报告给运维：本目录report.md；逐项提案：本目录proposal.md。全部十项waiting，保留待相应新增证据，不把本批锚点叫作全历史量化学习完成。

最终读回：30个账本原claim/首证/prior/asc/status/version/effect/evidence均保持，新proposal/report链接全部可读；CLI退出0，23035583字节原账本前缀SHA保持。本批工作树tracked/index/untracked均干净，HEAD仍等于完整base，派发身份和十原id仍匹配。gitleaks dir以--redact扫描本批192.24MB产物，退出0、零发现；无代码提交。具体结果见final-validation.json、ledger-readback.json与gitleaks-report.json。

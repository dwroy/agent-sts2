import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261017-182644'
SCRATCH = ROOT / 'learner/runs/20261017-182649-7faa35aa-4105-4992-af30-167d860c59c0-fix-batch'
PREVIOUS = ROOT / 'learner/runs/20261017-171308-b1496e01-d6c3-4605-ad9e-a8ba42aa714d-fix-batch'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])


def ancestor(commit, head):
    result = subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, head])
    if result.returncode not in (0, 1):
        raise RuntimeError('Unable to verify Git ancestry')
    return result.returncode == 0


previous = json.loads((PREVIOUS / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
main = git('rev-parse', 'main').decode().strip()
live = git('rev-parse', 'live').decode().strip()
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
(SCRATCH / 'fix-queue.snapshot.md').write_bytes(queue)
queue_unchanged = queue == (PREVIOUS / 'fix-queue.snapshot.md').read_bytes()
paths = sorted(set(previous['source_blobs']) | {'agent/tests/silent-test-subject-phase.test.ts'})
tree = git('ls-tree', '-r', '-z', base, '--', *paths)
blobs = {}
for entry in tree.split(b'\0'):
    if not entry:
        continue
    metadata, path = entry.split(b'\t', 1)
    blobs[path.decode()] = metadata.split()[2].decode()

source_blobs = {}
changed = []
for path in paths:
    if Path(path).name == '.env' or path.endswith('.env'):
        raise RuntimeError('Unexpected denied input')
    content = (WORK / path).read_bytes()
    working_blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    source_blobs[path] = {'blob': blobs[path], 'working_blob': working_blob,
                          'sha256': hashlib.sha256(content).hexdigest()}
    old = previous['source_blobs'].get(path, {}).get('blob')
    if old != blobs[path]:
        changed.append({'path': path, 'previous_blob': old, 'base_blob': blobs[path]})
    if working_blob != blobs[path]:
        raise RuntimeError(f'Unexpected working copy change: {path}')

fixed = []
for item in previous['already_fixed']:
    row = {'item': item['item'].replace('（默认路径本批另补）', '（默认路径已另修）').replace('（本轮期间由原ops发布V5-R384，宿主检查待完成）', '（已发布V5-R384）'),
           'commit': item['commit']}
    for name, head in [('base', base), ('main', main), ('live', live)]:
        row[name + '_ancestor'] = ancestor(row['commit'], head)
    fixed.append(row)

diff = git('diff', '--binary', previous['base'], base, '--', 'agent', 'learner', 'ops', 'knowledge/builders')
(SCRATCH / 'implementation-since-previous.diff').write_bytes(diff)
working_diff = git('diff', '--binary', base)
(SCRATCH / 'working-tree.diff').write_bytes(working_diff)
dirty = git('status', '--porcelain').decode().splitlines()

proposal_ids = {'silent-proposal-72e0c8b41d2f5ab8', 'silent-proposal-59b2e430bb7521d4'}
proposals = []
with (ROOT / 'paper/materials/learning/code-proposals.jsonl').open() as stream:
    for line in stream:
        row = json.loads(line)
        if row.get('id') in proposal_ids:
            proposals.append(row)
(SCRATCH / 'existing-proposals-readback.json').write_text(json.dumps(proposals, ensure_ascii=False, indent=2) + '\n')

audit = {'base': base, 'main': main, 'live': live, 'previous_base': previous['base'],
         'previous_audit': str(PREVIOUS / 'source-audit.json'),
         'queue_sha256': hashlib.sha256(queue).hexdigest(), 'queue_unchanged': queue_unchanged,
         'already_fixed': fixed, 'source_paths_checked': len(source_blobs), 'source_blobs': source_blobs,
         'changed_paths_since_previous': changed, 'dirty_paths': dirty,
         'change_review': '新增两处生产源码和一个固定测试均为已发布V5-R386的限定实验体阶段能力修正；不撤销41项既有纯bug修复。完整diff留档。',
         'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0}}
(SCRATCH / 'source-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
all_ancestors = all(row[name + '_ancestor'] for row in fixed for name in ['base', 'main', 'live'])
print(json.dumps({'base': base, 'main': main, 'live': live, 'queue_unchanged': queue_unchanged,
                  'existing_fix_count': len(fixed), 'all_fixed_commits_base_main_live_ancestors': all_ancestors,
                  'source_paths_checked': len(source_blobs), 'changed_paths': changed,
                  'working_tree_clean': not dirty}, ensure_ascii=False, indent=2))
assert queue_unchanged and all_ancestors and not dirty

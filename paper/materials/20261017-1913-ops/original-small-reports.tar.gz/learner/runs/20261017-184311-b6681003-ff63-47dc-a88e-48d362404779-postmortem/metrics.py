import json,pathlib,collections,re,datetime
P=pathlib.Path(__file__).parent; D=json.loads((P/'decisions.json').read_text());S=json.loads((P/'states.json').read_text()); B=json.loads((P/'brain.json').read_text()); R=json.loads((P/'WQB3YYNTRB2L-resources.json').read_text())
byline={r['_line']:r for r in S}; Q=[d for d in D if d.get('decider')=='jev'];C=[d for d in Q if d['label'].startswith('combat/plan-choice')]; L=[d for d in Q if isinstance(d.get('confidence'),(int,float)) and d['confidence']<.35]
M={'jev_count':len(Q),'low':[(d['_line'],d['floor'],d['turn'],d['label'],d['confidence']) for d in L],'choices':len(C),'best':dict(collections.Counter(str(d.get('rollout_best_chosen')) for d in C)), 'ranks':dict(collections.Counter(re.search(r'code rank (\d+|\-)',d['rationale']).group(1) if re.search(r'code rank (\d+|\-)',d['rationale']) else '?' for d in C)),'raw_deciders':dict(collections.Counter(d['decider'] for d in D)), 'jev_tokens':{k:sum(d.get('usage',{}).get(k,0) for d in Q) for k in ['input_tokens','output_tokens']}, 'brain_count':len(B),'brain_accepted':dict(collections.Counter(str(b.get('accepted')) for b in B)), 'brain_usage':{k:sum(b.get('usage',{}).get(k,0) for b in B) for k in ['inputTokens','outputTokens','cacheHitTokens']},'brain_latency':sum(b.get('latency_ms',0) for b in B),'guard':[d['_line'] for d in D if 'HP guard' in d.get('rationale','') or d.get('hp_guard')],'audits_actual':collections.Counter(str(d['selection_audit'].get('actual_turn')) for d in D if d.get('selection_audit'))}
turns=collections.defaultdict(list)
for d in D:
 if str(d.get('label','')).startswith(('combat/','selection/')) and isinstance(d.get('turn'),int):turns[(d['floor'],d['turn'])].append(d)
ind={k:v for k,v in turns.items() if any(d['decider']=='code' and d['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/play'] and (d.get('chosen') or {}).get('action') in ['play_card','use_potion'] for d in v)}
M.update(combat_turns=len(turns),independent_code_turns=len(ind),independent_code_keys=list(ind),fully_code_turns=[k for k,v in ind.items() if all(d['decider']=='code' for d in v)],independent_code_actions=sum(d['decider']=='code' and d['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/play'] and (d.get('chosen') or {}).get('action') in ['play_card','use_potion'] for d in D))
print(json.dumps(M,ensure_ascii=False,indent=2));(P/'metrics.json').write_text(json.dumps(M,ensure_ascii=False,indent=2))
print('关键轮初/轮末；轮初按已发牌cards_played=0')
for w in R['combats']:
 if w['floor'] not in [14,17,19,20,22,24]:continue
 ss=[r for r in S if w['entry']['line']<=r['_line']<=w['exit']['line']];groups=collections.defaultdict(list)
 for r in ss:groups[r['state'].get('turn')].append(r)
 for t,rr in groups.items():
  a=next((r for r in rr if r['state'].get('in_combat') and r['state'].get('combat',{}).get('hand') and r['state']['combat']['player'].get('cards_played_this_turn')==0),rr[0]); z=rr[-1]
  def obs(r):
   s=r['state'];c=s.get('combat')or{};return {'s':r['_line'],'hp':s['run']['current_hp'],'max':s['run']['max_hp'],'block':c.get('player',{}).get('block'),'powers':[(x['power_id'],x['amount']) for x in c.get('player',{}).get('powers',[])],'enemy':[(x['enemy_id'],x['current_hp'],x.get('is_alive')) for x in c.get('enemies',[])]}
  print(w['floor'],t,obs(a),obs(z))
print('每个Jev选线预测与rollout')
for d in C:
 if d['floor'] not in [14,17,19,22,24]:continue
 a=(d.get('selection_audit') or {}).get('answer')or{};print('d'+str(d['_line']),d['floor'],d['turn'],a.get('turn'),a.get('rollout'))
print('focus题')
for d in Q:
 q=d.get('questions')or{};ans=d.get('answers')or{}
 if 'focus' in json.dumps(q).lower() or 'focus' in json.dumps(ans).lower():print(d['_line'],d['floor'],d['turn'],'answers',ans,'questions_keys',list(q) if isinstance(q,dict) else q)
print('遗物及事件')
for fl in [7,8,10,18,21,23,24]:
 rr=[r for r in S if r['state']['run']['floor']==fl];s=rr[-1]['state'];print(fl, 'relics',[(x['relic_id'],x['name'],x.get('description'),x.get('counter')) for x in s['run'].get('relics',[])], 'event',s.get('event'))

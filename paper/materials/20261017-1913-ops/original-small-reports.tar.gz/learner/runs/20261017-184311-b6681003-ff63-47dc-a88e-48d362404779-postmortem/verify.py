import json,pathlib,hashlib,collections,datetime
P=pathlib.Path(__file__).parent;ROOT=P.parents[2];D=json.loads((P/'decisions.json').read_text());S=json.loads((P/'states.json').read_text());B=json.loads((P/'brain.json').read_text());R=json.loads((P/'WQB3YYNTRB2L-resources.json').read_text());M=json.loads((P/'metrics.json').read_text())
checks=[]
def check(name,truth):
 assert truth,name
 checks.append(name)
manifest=json.loads((P/'source-and-evidence-manifest.json').read_text());handles={}
for e in manifest['evidence']:
 f=handles.setdefault(e['file'],(ROOT/e['file']).open('rb'));f.seek(e['offset']);b=f.read(e['bytes']);check(f"原始证据 {e['file']}:{e['line']}",hashlib.sha256(b).hexdigest()==e['sha256'])
for f in handles.values():f.close()
check('记录行数',(len(D),len(S),len(B))==(351,375,24));check('角色与进阶',all(s['state']['run']['character_id']=='SILENT' and s['state']['run']['ascension']==10 for s in S))
expected=[(2,56,56,70,70),(3,56,56,70,70),(5,56,56,70,70),(9,49,49,77,78),(12,49,50,78,79),(14,73,56,79,80),(15,56,56,80,81),(17,80,39,81,82),(19,73,51,82,83),(20,51,52,83,84),(22,52,8,84,85),(24,8,0,85,85)]
actual=[(w['floor'],w['entry']['hp'],w['exit']['hp'],w['entry']['max_hp'],w['exit']['max_hp']) for w in R['combats']];check('十二场完整入口出口HP',actual==expected);check('十二场T1',all(w['entry_is_turn_one'] for w in R['combats']));check('十二场有退出',all(w['end']=='observed_exit' for w in R['combats']))
last=S[-1]['state'];c=last['combat'];check('死亡帧HP和回合',last['turn']==3 and last['run']['current_hp']==0 and last['run']['max_hp']==85);check('死亡后敌血max与攻击',[(e['enemy_id'],e['current_hp'],e['max_hp']) for e in c['enemies']]==[('TOUGH_EGG',12,23),('TOUGH_EGG',9,20),('OVICOPTER',46,132)]);check('幸存攻击16',sum(i.get('total_damage')or 0 for e in c['enemies'] for i in e['intents'])==16)
sline={r['_line']:r['state'] for r in S};check('结束前8血5挡',sline[437978]['run']['current_hp']==8 and sline[437978]['combat']['player']['block']==5);check('结束前被毒杀幼虫',sline[437978]['combat']['enemies'][0]['current_hp']==3 and any(p['power_id']=='POISON_POWER' and p['amount']==3 for p in sline[437978]['combat']['enemies'][0]['powers']));check('完整损失和存活差额',16-5==11 and 11-8+1==4)
check('T1母体实打',sline[437958]['combat']['enemies'][0]['current_hp']-sline[437967]['combat']['enemies'][-1]['current_hp']==40);check('死亡回合推进',sum(e['current_hp'] for e in sline[437974]['combat']['enemies'])-sum(e['current_hp'] for e in c['enemies'])==49)
check('Jev计数',(M['jev_count'],len(M['low']),M['choices'])==(83,13,61));check('推演最佳布尔',M['best']=={'True':58,'None':1,'False':2});check('Jevtoken',M['jev_tokens']=={'input_tokens':580307,'output_tokens':4555});check('brain用量',M['brain_usage']=={'inputTokens':4146614,'outputTokens':27944,'cacheHitTokens':2145408});check('brain均真实Codex',all((b['engine'],b['model'],b['effort'])==('codex','gpt-6.1-sol','xhigh') for b in B));check('代码回合',(M['combat_turns'],M['independent_code_turns'],len(M['fully_code_turns']),M['independent_code_actions'])==(54,18,12,22));check('HP护栏替换0',not M['guard'])
drinks=[d for d in D if (d.get('chosen')or{}).get('action')=='use_potion'];check('五次实饮动作',[d['_line'] for d in drinks]==[423439,423453,423475,423496,423634]);check('无丢药',not any((d.get('chosen')or{}).get('action')=='discard_potion' for d in D));check('六次获得药水',sum(len(set(map(tuple,e['to']['potions']))-set(map(tuple,e['from']['potions']))) for e in R['resource_changes'])==6);check('终局留能力药',R['combats'][-1]['exit']['potions']==[[1,'POWER_POTION']])
sl=json.loads((P/'sl-attempts.json').read_text());check('两SL首试无重载',[(x['floor'],x['attempt'],x['result']) for x in sl]==[(17,1,'won'),(24,1,'died')] and all(x.get('reload') is None for x in sl));check('末战最多四实际一',sl[-1]['max_attempts']==4)
for fl,vals,hp in [(14,[132,84,50,39,4],[73,73,73,73,55]),(17,[183,178,171,155,125,85,74,53,19],[80,80,76,59,59,57,57,38,38]),(19,[84,78,59,49,27],[73,73,73,50,50]),(20,[71,22,9],[51,51,51]),(22,[131,80,61,39],[52,34,25,7])]:
 groups={}
 for r in S:
  s=r['state']
  if s['run']['floor']==fl and s.get('in_combat'):groups.setdefault(s['turn'],s)
 check(f'F{fl}逐回合轮初HP池',vals==[sum(e['current_hp'] for e in s['combat']['enemies'] if e['is_alive']) for s in groups.values()]);check(f'F{fl}逐回合玩家HP',hp==[s['run']['current_hp'] for s in groups.values()])
dline={d['_line']:d for d in D};check('T1原条件预测57',dline[423624]['selection_audit']['answer']['turn']['damage']==57);check('T1重问后29',dline[423628]['selection_audit']['answer']['turn']['damage']==29);check('T2精确伤51挡20零损',dline[423633]['selection_audit']['answer']['turn']['damage']==51 and dline[423633]['selection_audit']['answer']['turn']['block_gained']==20 and dline[423633]['selection_audit']['answer']['turn']['hp_loss']==0)
for n in [423626,423627]:
 d=dline[n];ans=d['answers']['pick']['choice'];off=json.loads(d['questions']['pick']['criteria'][ans]);check(f'd{n}已提示后继',off['removes_planned_continuation'] is True)
check('F22原选血价',dline[423606]['selection_audit']['answer']['turn']['hp_loss']==18 and dline[423606]['selection_audit']['answer']['turn']['damage']==16)
q={k:json.loads(v) for k,v in dline[423606]['questions']['plan']['criteria'].items()};check('F22未选候选损0伤9',q['plan1']['hp_lost']==0 and q['plan1']['damage_dealt']==9)
check('F19逃脱可见末帧',sline[437897]['combat']['enemies'][0]['current_hp']==8 and sline[437897]['combat']['enemies'][0]['move_id']=='ESCAPE_MOVE')
q16=dline[423491]['boss_sim']['quantitative']['options']['o0'];check('Boss模拟231/228/3',q16['samples']==231 and q16['wins']==228 and q16['deaths']==3 and q16['capped']==0);check('Boss有效DPR',abs(q16['effective_damage_per_turn']['mean']-20.00072165689051)<1e-12)
old=collections.Counter();rd=[]
for r in S:
 s=r['state'];new=collections.Counter(e['relic_id'] for e in s['run'].get('relics',[]))
 if old and old!=new:rd.append((r['_line'],s['run']['floor'],list((new-old).elements())))
 old=new
check('红面具F10',any(fl==10 and 'RED_MASK' in es for _,fl,es in rd));check('准备背包F14',any(fl==14 and 'BAG_OF_PREPARATION' in es for _,fl,es in rd))
entry=(P/'entry.md').read_text();check('三条经验',sum(line.startswith('- [') and not line.startswith('- [记录]') for line in entry.splitlines())==3);check('标题角色与正确maxHP','## WQB3YYNTRB2L（A10，静默猎手，第24层' in entry and '两幼虫12/23与9/20血' in entry);check('没有F3早店误写','F3问号实为早店' not in entry)
result={'status':'通过','checks':len(checks),'items':checks,'relic_changes':rd};(P/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({'status':'通过','checks':len(checks),'relic_changes':rd})

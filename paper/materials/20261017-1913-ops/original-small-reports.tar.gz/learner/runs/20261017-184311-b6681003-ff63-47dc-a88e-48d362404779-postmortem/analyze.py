import json, pathlib, collections, datetime
P=pathlib.Path(__file__).parent
D=json.loads((P/'decisions.json').read_text()); S=json.loads((P/'states.json').read_text()); B=json.loads((P/'brain.json').read_text()); R=json.loads((P/'WQB3YYNTRB2L-resources.json').read_text())
def line(r):return f"d{r['_line']} F{r.get('floor')}T{r.get('turn')} {r['ts']}"
def power(a):return [(p.get('power_id'),p.get('amount')) for p in (a or [])]
def enemies(s):return [(e.get('index'),e.get('name'),e.get('enemy_id'),e.get('current_hp'),e.get('block'),e.get('is_alive'),e.get('intents'),power(e.get('powers'))) for e in (s.get('combat') or {}).get('enemies',[])]
with (P/'summary.txt').open('w') as f:
 def out(*x):print(*x,file=f)
 out('非战斗决定')
 for d in D:
  if d.get('decider') in ['codex','code-fallback'] or (d.get('chosen')or{}).get('action') in ['use_potion','discard_potion'] or 'guard' in str(d.get('rationale','')).lower():out(line(d),d['label'],d.get('chosen'),d['rationale'])
 out('资源变化')
 for c in R['resource_changes']:
  a,b=c['from'],c['to'];out(f"s{a['line']}→{b['line']} F{a['floor']}T{a['turn']}→F{b['floor']}T{b['turn']} {a['hp']}/{a['max_hp']}→{b['hp']}/{b['max_hp']} {a['potions']}→{b['potions']} {b['ts']}")
 out('关键状态')
 for r in S:
  s=r['state'];fl=s['run']['floor']
  if fl not in [14,17,19,20,22,24] or not s.get('combat'):continue
  c=s['combat'];out(f"s{r['_line']} {r['ts']} F{fl}T{s.get('turn')} HP{s['run']['current_hp']} in_combat={s['in_combat']}", 'player', {k:v for k,v in c.get('player',{}).items() if k not in ['hand','draw_pile','discard_pile','exhaust_pile']}, 'enemies',enemies(s))
  if fl==24: out('hand',[(a['index'],a['name'],a['card_id'],a.get('energy_cost'),a.get('resolved_rules_text')) for a in c.get('hand',[])])
 out('关键决定')
 for d in D:
  if d.get('floor') not in [17,22,24] or not str(d.get('label')).startswith(('combat/','selection/')):continue
  out(line(d),d['label'],d['decider'],d.get('rationale'),d.get('chosen'))
  if d.get('rollout'):
   rr=d['rollout'];out('rollout',{k:rr.get(k) for k in ['horizon','samples','degraded','best','best_added','no_potion']})
  if d.get('selection_audit'):out('audit',d['selection_audit'])
 out('大脑元数据')
 for b in B:
  out('b'+str(b['_line']),b['ts'],b['label'],b['engine'],b['model'],b['effort'],b.get('accepted'),b.get('usage'),b.get('latency_ms'),b.get('answer'))
 out('计划')
 for r in json.loads((P/'run-plans.json').read_text()):out('p'+str(r['_line']),r['ts'],r['floor'],r['trigger'],r['plan'])
 out('SL')
 for r in json.loads((P/'sl-attempts.json').read_text()):out(r)
 out('配置',json.loads((P/'run-config.json').read_text()))
print('summary',P/'summary.txt')
print('combat fields',S[2]['state'].get('combat',{}).keys() if S[2]['state'].get('combat') else next(r['state']['combat'].keys() for r in S if r['state'].get('combat')))

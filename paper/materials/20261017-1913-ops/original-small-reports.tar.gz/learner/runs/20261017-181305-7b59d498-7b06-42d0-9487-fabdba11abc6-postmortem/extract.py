import json,hashlib
from pathlib import Path
p=Path('/home/dw/Projects/agent-sts2'); out=p/'learner/runs/20261017-181305-7b59d498-7b06-42d0-9487-fabdba11abc6-postmortem'; run=b'4JS3T2UNKPVM'
index={}
for name in ['runs','decisions','states','run-plans','sl-attempts','brain','run-config','fight-plans']:
    src=p/'logs'/f'{name}.jsonl'
    if not src.exists(): continue
    hits=[]; offset=0; cutoff=src.stat().st_size
    with src.open('rb') as f,(out/f'{name}.jsonl').open('wb') as dest:
        for n,line in enumerate(f,1):
            start=offset;offset+=len(line)
            if offset>cutoff: break
            if run not in line: continue
            row=json.loads(line); dest.write(line)
            hits.append({'line':n,'offset':start,'length':len(line),'sha256':hashlib.sha256(line).hexdigest(),'ts':row.get('ts')})
    index[name]={'cutoff':cutoff,'hits':hits}
    print(name,len(hits),flush=True)
ds=[json.loads(l) for l in (out/'decisions.jsonl').open()]; begin=min(d['ts'] for d in ds);end=max(d['ts'] for d in ds)
hits=[]; offset=0
with (p/'logs/deepseek-reasoning.jsonl').open('rb') as f,(out/'deepseek-reasoning.jsonl').open('wb') as dest:
    for n,line in enumerate(f,1):
        start=offset;offset+=len(line)
        try: row=json.loads(line)
        except ValueError: continue
        if begin<=row.get('ts','')<=end:
            dest.write(line);hits.append({'line':n,'offset':start,'length':len(line),'sha256':hashlib.sha256(line).hexdigest()})
index['deepseek-reasoning']={'window':[begin,end],'hits':hits};(out/'source-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print('reasoning',len(hits),'window',begin,end,flush=True)

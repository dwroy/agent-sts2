import json,re,collections,datetime
from pathlib import Path
p=Path(__file__).parent; ix=json.loads((p/'source-index.json').read_text())
def rows(n):
 return [{**json.loads(l),'_line':h['line']} for l,h in zip((p/f'{n}.jsonl').open(),ix[n]['hits'])]
ds=rows('decisions');ss=rows('states');bs=rows('brain'); rc=json.loads((p/'4JS3T2UNKPVM-resources.json').read_text())
report={};report['deciders_raw']=dict(collections.Counter(d['decider'] for d in ds)); norm=lambda d: 'jev-plan' if d['decider']=='code' and d.get('rationale','').startswith('continuing the Jev-chosen plan:') else d['decider'];report['deciders_normalized']=dict(collections.Counter(norm(d) for d in ds))
js=[d for d in ds if d['decider']=='jev'];plans=[d for d in js if d['label'].startswith('combat/plan-choice')]
report['jev']={'count':len(js),'low':[{k:d.get(k) for k in ['_line','floor','turn','label','confidence','rationale']} for d in js if d.get('confidence',1)<.35], 'rollout_best':dict(collections.Counter(str(d.get('rollout_best_chosen')) for d in plans)),'plan_count':len(plans),'rank1':sum('code rank 1' in d['rationale'] for d in plans),'usage':{k:sum((d.get('usage') or {}).get(k,0) for d in js) for k in ['input_tokens','output_tokens']}}
report['brain']=[{k:b.get(k) for k in ['_line','ts','label','engine','model','effort','accepted','problems','latency_ms','usage']} for b in bs]
report['focus']=[]
for d in plans:
 ans=(d.get('answers') or {}).get('plan') or {};key=ans.get('choice');crit=(((d.get('questions') or {}).get('plan') or {}).get('criteria') or {}).get(key)
 if isinstance(crit,str):
  try:crit=json.loads(crit)
  except ValueError:pass
 keys=[]
 for k,v in ((d.get('questions') or {}).get('plan') or {}).get('criteria',{}).items():
  if 'focus' in str(v).lower():keys.append(k)
 if keys:report['focus'].append({'line':d['_line'],'floor':d['floor'],'turn':d['turn'],'answer':key,'matching':keys,'chosen_fields':{k:v for k,v in (crit or {}).items() if 'focus' in k.lower()} if isinstance(crit,dict) else crit})
report['guard']=[{'line':d['_line'],'rationale':d['rationale'],'audit':d.get('selection_audit')} for d in ds if re.search('guardrail|hp guard|护栏',d.get('rationale',''),re.I)]
report['combat_turns']=[]
for c in rc['combats']:
 start,end=c['entry']['ts'],(c['exit'] or c['last'])['ts']; cr=[d for d in ds if start<=d['ts']<=end and d['label'].startswith('combat/')]
 for t in sorted(set(d['turn'] for d in cr)):
  tr=[d for d in cr if d['turn']==t]; independent=[d for d in tr if norm(d)=='code' and (d.get('chosen') or {}).get('action') in ['play_card','end_turn','use_potion']]
  report['combat_turns'].append({'seq':c['sequence'],'floor':c['floor'],'turn':t,'autonomous':len(independent),'all_code':bool(independent) and all(norm(d)=='code' for d in tr),'lines':[d['_line'] for d in independent]})
report['turns']=[]
for c in rc['combats']:
 start,end=c['entry']['ts'],(c['exit'] or c['last'])['ts']; cr=[s for s in ss if start<=s['ts']<=end and s['state'].get('in_combat')]
 groups=[]
 for s in cr:
  state=s['state'];t=state['turn'];co=state.get('combat') or {}
  if not co.get('enemies'):continue
  if not groups or groups[-1]['turn']!=t:
   groups.append({'turn':t,'start':s['_line'],'hp':state['run']['current_hp'],'enemy_hp':[(e['enemy_id'],e['current_hp']) for e in co['enemies'] if e['is_alive']]})
  groups[-1]['last']=s['_line'];groups[-1]['last_hp']=state['run']['current_hp'];groups[-1]['last_enemy_hp']=[(e['enemy_id'],e['current_hp']) for e in co['enemies'] if e['is_alive']]
 report['turns'].append({'seq':c['sequence'],'floor':c['floor'],'groups':groups})
report['other_decisions']=[{'line':d['_line'],'floor':d['floor'],'turn':d['turn'],'label':d['label'],'decider':norm(d),'chosen':(d.get('chosen') or {}),'rationale':d['rationale']} for d in ds if d['label'].startswith(('rest/','event/','chest/')) or (d.get('chosen') or {}).get('action') in ['use_potion','discard_potion']]
report['f22_audits']=[{'line':d['_line'],'turn':d['turn'],'rationale':d['rationale'],'audit':d.get('selection_audit'),'rollout':d.get('rollout'),'answers':d.get('answers')} for d in plans if d['floor']==22]
(p/'analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for key in ['deciders_raw','deciders_normalized','jev','focus']:
 print(key,json.dumps(report[key],ensure_ascii=False))
print('guard_count',len(report['guard']))
print('combat_rounds',len(report['combat_turns']),'autonomous_turns',sum(bool(t['autonomous']) for t in report['combat_turns']),'autonomous_actions',sum(t['autonomous'] for t in report['combat_turns']),'only_code_turns',sum(t['all_code'] for t in report['combat_turns']))
print('brain',json.dumps(report['brain'],ensure_ascii=False))
for r in report['turns']:
 if r['floor']>=17:print('TURNS',r)
for r in report['other_decisions']:print('OTHER',json.dumps(r,ensure_ascii=False))

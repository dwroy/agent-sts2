import gzip
import json
from pathlib import Path

out = Path(__file__).resolve().parent
states = [json.loads(line) for line in (out / 'evidence/states.evidence.jsonl').open()]
decisions = [json.loads(line) for line in (out / 'evidence/decisions.evidence.jsonl').open()]
state_index = {(e['row']['observed_ts'], e['row']['fingerprint']): e for e in states}
by_line = {e['line']: e for e in states}
decision_lines = {e['line']: e for e in decisions}
ref = lambda e: {k: e[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}

def snapshot(e):
    s = e['row']['state']
    c, r = s.get('combat') or {}, s.get('run') or {}
    p = c.get('player') or {}
    return {'ref': ref(e), 'floor': r.get('floor'), 'turn': s.get('turn'),
            'hp': p.get('current_hp', r.get('current_hp')), 'block': p.get('block'),
            'energy': p.get('energy'), 'powers': p.get('powers'),
            'deck_upgraded_count': sum(bool(card.get('upgraded')) for card in r.get('deck', [])),
            'hand': [{'id': card['card_id'], 'upgraded': card['upgraded'], 'energy_cost': card['energy_cost'],
                      'values': card['dynamic_values']} for card in c.get('hand', [])],
            'enemies': [{k: enemy.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block', 'powers', 'intents')}
                        for enemy in c.get('enemies', [])]}

result = {'apotheosis_pairs': [{'before': snapshot(by_line[a]), 'after': snapshot(by_line[b])}
                               for a, b in [(275564, 275565), (275679, 275680)]],
          'sl_same_fingerprint': decision_lines[270216]['row']['fingerprint'] == decision_lines[270282]['row']['fingerprint'],
          'sl_same_board_refs': [ref(decision_lines[n]) for n in (270216, 270282)],
          'sl_logged_differences': decision_lines[270282]['row']['sl_explore'], 'bubble_actions': [], 'turns': []}
for item in decisions:
    row = item['row']
    if item['run_id'] != '5PM6JAQG6FNQ' or row.get('floor') != 39 or row.get('turn') != 2:
        continue
    before = state_index.get((row.get('observed_ts'), row.get('fingerprint')))
    if before is None or row.get('chosen', {}).get('action') != 'play_card':
        continue
    hand = before['row']['state']['combat']['hand']
    card = next((card for card in hand if card['index'] == row['chosen']['card_index']), None)
    if card is None or card['card_id'] != 'BUBBLE_BUBBLE':
        continue
    after = by_line.get(before['line'] + 1)
    result['bubble_actions'].append({'decision_ref': ref(item), 'attempt': row.get('sl_attempt'),
                                    'reloads': row.get('sl_reloads'), 'card': card,
                                    'before': snapshot(before), 'after': snapshot(after) if after else None})
for path in sorted((out / 'consumer').glob('*.output.json.gz')):
    audit = json.loads(gzip.decompress(path.read_bytes()))
    for turn in audit['observed_turns']:
        run = audit['run_id']
        wanted = run == '8JRE1C4H4Z2W' and turn['floor'] == 33 and ((turn['turn'] == 2 and turn['attempt'] in (1, 3)) or
                 (turn['turn'] == 5 and turn['attempt'] == 2) or turn['turn'] == 11)
        wanted |= run == 'CA5KE8GFJ9X2' and turn['turn'] in (3, 5)
        wanted |= run == '61E2QS63Y9WU' and ((turn['floor'] == 17 and turn['turn'] in (5, 6)) or
                  (turn['floor'] == 23 and turn['turn'] in (4, 5)))
        wanted |= run == 'DUZUBAJ3A8GP' and turn['turn'] in (4, 5, 6)
        wanted |= run == 'VLZ6CCT8AQ0A' and turn['floor'] in (43, 45) and turn['turn'] in (1, 4, 5)
        if not wanted:
            continue
        facts = turn['facts'] or {}
        result['turns'].append({'run_id': run, **{k: turn[k] for k in ('floor', 'turn', 'attempt', 'status', 'reason')},
                                'source_decisions': [d['source_line'] for d in turn['decisions']],
                                'player_hp_delta': facts.get('player_hp_delta'),
                                'enemy_hp_changes': facts.get('enemy_hp_changes'),
                                'before_hp': facts.get('before', {}).get('hp'),
                                'after_hp': facts.get('after', {}).get('hp'),
                                'actual_full_candidate_result': facts.get('actual_full_candidate_result')})
(out / 'observations.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
assert result['sl_same_fingerprint']
assert result['apotheosis_pairs'][0]['before']['energy'] - result['apotheosis_pairs'][0]['after']['energy'] == 2
assert result['apotheosis_pairs'][1]['before']['energy'] - result['apotheosis_pairs'][1]['after']['energy'] == 2
assert result['bubble_actions']
for action in result['bubble_actions']:
    print(json.dumps({'bubble_decision': action['decision_ref']['line'], 'attempt': action['attempt'],
                      'hp': [action['before']['hp'], action['after']['hp']],
                      'energy': [action['before']['energy'], action['after']['energy']]}, ensure_ascii=False))
for turn in result['turns']:
    if turn['run_id'] == '8JRE1C4H4Z2W':
        print(json.dumps(turn, ensure_ascii=False))

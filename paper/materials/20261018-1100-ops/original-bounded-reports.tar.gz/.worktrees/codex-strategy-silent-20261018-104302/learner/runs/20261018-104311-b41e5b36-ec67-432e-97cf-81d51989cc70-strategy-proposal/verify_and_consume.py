import collections
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location('evidence_entry', WORKTREE / 'learner/extract_evidence.py')
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['runs']
streams = {}
verified = []
for manifest in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
    stream = manifest['stream']
    evidence_path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    raw = evidence_path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == manifest['output_sha256']
    rows = [json.loads(line) for line in raw.splitlines()]
    counts = dict.fromkeys(runs, 0)
    with open('/home/dw/Projects/agent-sts2/logs/' + stream + '.jsonl', 'rb') as source:
        for item in rows:
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            source.seek(item['offset'])
            line = source.read(item['bytes'])
            assert line.endswith(b'\n')
            assert hashlib.sha256(line).hexdigest() == item['sha256']
            assert json.loads(line) == item['row']
            assert entry.run_identity(item['row']) == item['run_id'] in counts
            counts[item['run_id']] += 1
    assert counts == manifest['counts']
    streams[stream] = rows
    verified.append(dict(manifest, verified_rows=len(rows)))
    print(json.dumps({'stream': stream, 'verified_rows': len(rows)}, ensure_ascii=False), flush=True)

run_rows = {item['run_id']: item['row'] for item in streams['runs']}
assert set(run_rows) == set(runs)
assert all(row['character'].lower() == 'silent' and row['ascension'] == 10 for row in run_rows.values())
for item in streams['states']:
    info = item['row']['state'].get('run') or {}
    assert info['character_id'].lower() == 'silent' and info['ascension'] == 10
(OUT / 'verified-evidence.json').write_text(json.dumps({
    'streams': verified, 'total_rows': sum(item['verified_rows'] for item in verified),
    'runs': run_rows, 'source_verification': '逐行原字节、SHA、JSON及显式归局核回',
}, ensure_ascii=False, indent=2) + '\n')

floors = {'VLZ6CCT8AQ0A': [35, 43, 45], '8JRE1C4H4Z2W': [17, 33],
          'CA5KE8GFJ9X2': [13], '5PM6JAQG6FNQ': [33, 39],
          '61E2QS63Y9WU': [17, 23], 'DUZUBAJ3A8GP': [30]}
audit_dir = OUT / 'consumer'
audit_dir.mkdir(exist_ok=True)
summary = []
for run in runs:
    decisions = []
    excluded = []
    for item in streams['decisions']:
        row = item['row']
        if item['run_id'] != run or row.get('floor') not in floors[run]:
            continue
        if not row.get('decision_id'):
            excluded.append({key: item[key] for key in ('line', 'offset', 'bytes', 'sha256')} |
                            {'reason': '原行没有decision_id，单列元数据，不补造动作身份。', 'row': row})
            continue
        decisions.append(dict(row, _line=item['line'], _source_sha256=item['sha256']))
    states = [dict(item['row'], _line=item['line'], _source_sha256=item['sha256'])
              for item in streams['states'] if item['run_id'] == run and
              (item['row']['state'].get('run') or {}).get('floor') in floors[run]]
    frozen = {'run': run_rows[run], 'decisions': decisions, 'states': states}
    input_bytes = (json.dumps(frozen, ensure_ascii=False) + '\n').encode()
    path = audit_dir / (run + '.input.json')
    path.write_bytes(input_bytes)
    (audit_dir / (run + '.excluded.json')).write_text(json.dumps(excluded, ensure_ascii=False, indent=2) + '\n')
    output_path = audit_dir / (run + '.output.json.gz')
    stderr_path = audit_dir / (run + '.stderr.txt')
    digest = hashlib.sha256()
    output_size = 0
    with stderr_path.open('wb') as errors, gzip.open(output_path, 'wb') as destination:
        process = subprocess.Popen(['node', '--import', str(WORKTREE / 'agent/node_modules/tsx/dist/loader.mjs'),
                                    str(WORKTREE / 'learner/audit-selection.ts'), str(path)],
                                   cwd=WORKTREE, stdout=subprocess.PIPE, stderr=errors)
        while True:
            chunk = process.stdout.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
            destination.write(chunk)
            output_size += len(chunk)
        rc = process.wait()
    receipt = {'run_id': run, 'floors': floors[run], 'returncode': rc,
               'input_sha256': hashlib.sha256(input_bytes).hexdigest(),
               'output_sha256': digest.hexdigest(), 'output_bytes': output_size,
               'input_decisions': len(decisions), 'input_states': len(states),
               'excluded_metadata': len(excluded)}
    if rc == 0:
        decompressed = gzip.decompress(output_path.read_bytes())
        assert hashlib.sha256(decompressed).hexdigest() == digest.hexdigest()
        audit = json.loads(decompressed)
        assert audit['run_id'] == run
        receipt.update(segments=len(audit['segments']), observed_actions=len(audit['observed_actions']),
                       observed_turns=len(audit['observed_turns']),
                       certified_full_candidates=sum(s['actual_full_candidate_result'] is not None for s in audit['segments']),
                       actual_rollout_best_nonnull=sum(s['actual_rollout_best'] is not None for s in audit['segments']),
                       boundary_counts=dict(collections.Counter(s['boundary']['kind'] for s in audit['segments'])))
    with gzip.open(str(path) + '.gz', 'wb') as destination:
        destination.write(input_bytes)
    assert gzip.decompress(Path(str(path) + '.gz').read_bytes()) == input_bytes
    path.unlink()
    summary.append(receipt)
    (audit_dir / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False), flush=True)

key_lines = {'states': [275564, 275565, 275679, 275680, 275687, 275721, 275722, 275730,
                        275731, 275732, 275752, 275754, 275755, 276433, 276434],
             'decisions': [269706, 269707, 269748, 269754, 269770, 270216, 270264, 270282, 270441, 270442]}
key_rows = {name: [item for item in streams[name] if item['line'] in numbers]
            for name, numbers in key_lines.items()}
(OUT / 'key-evidence.json').write_text(json.dumps(key_rows, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_total': sum(item['verified_rows'] for item in verified),
                  'consumer_rc': [row['returncode'] for row in summary]}, ensure_ascii=False))

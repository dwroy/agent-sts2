# Silent 策略提案批次报告

10个派发原提案均为waiting。本批没有可按证据完成固定生产校准的源码增量；不把已有局部实现或同题经验链登记为整项implemented/duplicate。

核查时间：2026-10-18T10:55:48+08:00；batch=20261018-104302-strategy-proposal。
完整base：`c1d54326e65bd3681fb72261ee2381609d8e0785`。开工工作树干净，普通任务已执行`git merge --no-edit main`，结果Already up to date。
根专题请求绑定另一旧batch，本批无research_request，按普通队列处理；没有读取其他专题代替身份，也不修改请求或learn.json。

## 证据与身份

六局runs.jsonl全部为SILENT、A10；source code均带dirty，不用当前提交冒认旧运行的完整源码树。原始身份只认run/run_id/state.run_id/fingerprint.run，正文提及不作归局。

| 局号 | 结束层 | states | decisions | SL记录 | brain | run-plans |
|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 45 | 729 | 699 | 2 | 46 | 8 |
| 8JRE1C4H4Z2W | 33 | 676 | 659 | 7 | 31 | 6 |
| CA5KE8GFJ9X2 | 13 | 282 | 265 | 0 | 11 | 2 |
| 5PM6JAQG6FNQ | 39 | 660 | 638 | 7 | 39 | 7 |
| 61E2QS63Y9WU | 28 | 462 | 443 | 7 | 27 | 4 |
| DUZUBAJ3A8GP | 30 | 623 | 602 | 6 | 29 | 6 |

公共入口抽取8流，共6995条；source_size、逐行offset/bytes/SHA和计数在evidence/evidence-manifest.json及各evidence.jsonl。verify_and_consume.py逐行seek原日志，核原字节SHA、JSON、显式归局与输出SHA，结果见verified-evidence.json和verification-consumer.log。
states/decisions/brain各有2行全源无效JSON，公共入口原计数保留；不把它们归到某个本批局。fight-plans在本次字节截点选到0行，仅说明这个截点没有选中，不能推断日志从未存在。独立identity-evidence保留，不覆盖初始结果。

## 逐项结果

| 原提案ID | 账本 | 结果及缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | silent-0237, silent-0238 | waiting：已有神化同线与已核卡对的局部实现；仍缺未覆盖卡的完整状态效果、确定抽序和战内各堆实例，以及实际施放到跨抽牌/重规划/SL消费者的校准，不能把整项登记implemented。 |
| silent-proposal-f2bfceddb1898dca | silent-0106, silent-0019, silent-0201 | waiting：缺同起点、同随机池、同总预算的配对实验、候选稳定性和MC收益曲线；不同盘面的1/12与12/12不能校准新预算、持有价、护栏或固定目标规则。 |
| silent-proposal-283a164780d11e69 | silent-0237, silent-0238 | waiting：这是同证据的经验来源链；当前局部实现尚未闭合实际施放与后继消费，不能用另一条仍waiting的同题提案把它登记duplicate，沿原ID保留。 |
| silent-proposal-ebbfe3b97548756d | silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019 | waiting：15个机制/资源子项缺按来源、期限和属性组合冻结的生产调用联合校准，路线与休息的反事实也未观测；不能用局部公式或知识文字证明整项完成。 |
| silent-proposal-e5b87be50f28f311 | silent-0079, silent-0021, silent-0125, silent-0018 | waiting：已有候选、护栏、SL、单动作回执与离线整轮端点子实现；完整候选执行归属、全部中断与反事实仍未认证，且缺独立策略效益验证，原宽提案保留waiting。 |
| silent-proposal-49632bc4878fb597 | silent-0005, silent-0231 | waiting：单项属性/虚弱公式已有实现，但本批不足以提供力量、敏捷、虚弱、成长四路径的完整生产联合校准；不增加统一保血或输出权重。 |
| silent-proposal-66532328a585941f | silent-0021, silent-0009 | waiting：缺同起始血量、构筑和抽序下不同启动/构筑顺序的完整对照及可复现收益函数，不能由一次空打拟合启动阈值或优先级。 |
| silent-proposal-43a76a31ba7bdcfa | silent-0030, silent-0027 | waiting：缺同起始HP/构筑/完整抽序下的另一可救活SL线路与分项生产校准；本局首试胜利不能用于改SL门槛或换线偏好。 |
| silent-proposal-5264153a4a4b0e5c | silent-0039, silent-0209 | waiting：缺A10召唤/航行全链的冻结生产调用输入与另一目标序的实际后续结果；已有召唤子实现不能证明成长及固定杀序收益。 |
| silent-proposal-bddfa690a84e03d0 | silent-0128, silent-0079 | waiting：缺同抽不同排序的完整胜线及睡眠/醒来/眩晕/当前进阶成长的生产全链校准；四次失败不能拟合全败排序权重或固定杀序。 |

逐项证据局号、层、回合、支持、反例、旧/新行为、样本限制、验证及回退详见proposal.md；19条相关Silent经验和26个原账本仅作为选中提案追溯，未写新经验或扩大统计分母。

## 实际源码与消费者读回

只读live截点：`b155d00a36080418149e63d2f21b491d34d7f40a`。16个选定文件的base字节、Git blob、SHA、最后源码提交及其实际live祖先关系在source/pins.json；16个最后提交均为实际live祖先。12文件逐字相同，4文件差异保存在source/base-live.patch。
card-model、potion-cost、SL explore是所选署名注释差；rollout还含Queen盟友力量的另一增量。这里仅核该差异，未研究另一任务，不能外推整树等价。原源码快照全部以.txt保存。

| 已有局部能力 | 实际live祖先源码commit |
|---|---|
| agent/src/reflex/silent-apotheosis.ts | `ba23ca693151fa8c6f7fe035e640dc30f05ccd75` |
| agent/src/reflex/silent-apotheosis-reference.ts | `30ec2425012eea75f41226b31d8180b1abb837bc` |
| agent/src/reflex/silent-hp-guard-audit.ts | `66283dd9982bdd7f480da7a4d9bfefea0572a9ac` |
| agent/src/reflex/silent-selection-audit.ts | `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb` |
| agent/src/reflex/silent-selection-dispatch.ts | `fdaf787a372880b0438e73bcac7e6d2168b038ed` |
| learner/lib/selection-execution.ts | `a32050fbce4c2863f640468c2dbf378fc9157074` |
| learner/lib/selection-terminal.ts | `83512ddcd2c70fd9b983dc38524ff25c8970c1d3` |
| learner/lib/selection-turn.ts | `e75438488df159b2e8e9d3458cf219b39aadd933` |

这些提交只证明各自局部实现，均不是本批提交，也不作为整项implemented_commit。

使用当前base的learner/audit-selection.ts消费六个限定窗口（保持原行号/尝试/指纹/时间），不接网络、LLM、游戏或刷新知识。所有输入、输出以gzip保留，压缩解压后SHA逐字核回；stderr、退出码和范围见consumer/summary.json。

| 局号 | 层范围 | 决策/状态 | 片段/动作/轮窗口 | 退出码 |
|---|---|---|---|---:|
| VLZ6CCT8AQ0A | 35,43,45 | 99/105 | 14/99/15 | 0 |
| 8JRE1C4H4Z2W | 17,33 | 277/280 | 66/277/57 | 0 |
| CA5KE8GFJ9X2 | 13 | 26/33 | 4/26/5 | 0 |
| 5PM6JAQG6FNQ | 33,39 | 114/116 | 21/114/18 | 0 |
| 61E2QS63Y9WU | 17,23 | 60/63 | 12/60/12 | 0 |
| DUZUBAJ3A8GP | 30 | 117/118 | 22/117/24 | 0 |

合计139个选线片段、693个已记录动作、131个轮窗口；这些窗口包含unknown，不是全部完整回合。限定窗口内无缺decision_id元数据排除；未覆盖的其他层未冒称已消费。
actual_full_candidate_result与actual_rollout_best仍均为null（非空计数为0）。这反映现有消费者的保守认证范围，不证明所有候选永远无法人工核验，也不把observed净变化当成选线因果。

observations.json及observations.log读回：8JRE同盘首/三试T2实损3/15、实扣10/17；第二试T5实损4、实扣25；末试T11整轮实扣敌36、玩家5→0，与末步毒结算敌154→130分列。5PM冒泡时玩家29→29、能量5→4；旧35血备注已有原账本勘误，不重写历史。神化两组实际支付2能已核。

## 验证、记录与交付边界

没有生产源码或生成知识改动，没有新提交、合入、eval版本或shipped。merge=live的源码发布步骤不适用于本批无改动结果，因此未抢live锁、未提交后台知识数据、未改上线通知。
未运行tsc、vitest或撤源码红绿；tests固定三个null。六次离线消费者退出0与逐字核验仅为材料/消费者读回，不冒充生产测试、自然采用或策略收益。
账本追溯仅经根learner/ledger.py update追加where.proposal与note，不增支持局、不改claim/first_run/prior/evidence/status/version/effect；原shipped条目不倒退为proposed。回执和输入保留在ledger-links.*，最终检查见final-checks.json。原队列状态由宿主消费proposal_results；不直接改专用队列、不另建ID。
提交前gitleaks规定无新提交触发；仍对本批可读交付材料运行脱敏扫描，具体退出码及扫描范围保留在gitleaks.*和final-checks.json，不声称扫描所有运行日志或整个会话。
提案绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-104302/learner/runs/20261018-104311-b41e5b36-ec67-432e-97cf-81d51989cc70-strategy-proposal/proposal.md
报告绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-104302/learner/runs/20261018-104311-b41e5b36-ec67-432e-97cf-81d51989cc70-strategy-proposal/report.md
原失败/初稿/并行记录全部保留；临时分析均在本批scratch，工作树受跟踪文件保持干净。运行模型的原生身份由宿主核实，本报告不凭默认配置自报已核。

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261018-104302-strategy-proposal",
  "base": "c1d54326e65bd3681fb72261ee2381609d8e0785",
  "runs": [
    "VLZ6CCT8AQ0A",
    "8JRE1C4H4Z2W",
    "CA5KE8GFJ9X2",
    "5PM6JAQG6FNQ",
    "61E2QS63Y9WU",
    "DUZUBAJ3A8GP"
  ],
  "fixes": [],
  "skipped": [
    {
      "id": "silent-proposal-89354805ee4d7e77",
      "reason": "已有神化同线与已核卡对的局部实现；仍缺未覆盖卡的完整状态效果、确定抽序和战内各堆实例，以及实际施放到跨抽牌/重规划/SL消费者的校准，不能把整项登记implemented。"
    },
    {
      "id": "silent-proposal-f2bfceddb1898dca",
      "reason": "缺同起点、同随机池、同总预算的配对实验、候选稳定性和MC收益曲线；不同盘面的1/12与12/12不能校准新预算、持有价、护栏或固定目标规则。"
    },
    {
      "id": "silent-proposal-283a164780d11e69",
      "reason": "这是同证据的经验来源链；当前局部实现尚未闭合实际施放与后继消费，不能用另一条仍waiting的同题提案把它登记duplicate，沿原ID保留。"
    },
    {
      "id": "silent-proposal-ebbfe3b97548756d",
      "reason": "15个机制/资源子项缺按来源、期限和属性组合冻结的生产调用联合校准，路线与休息的反事实也未观测；不能用局部公式或知识文字证明整项完成。"
    },
    {
      "id": "silent-proposal-e5b87be50f28f311",
      "reason": "已有候选、护栏、SL、单动作回执与离线整轮端点子实现；完整候选执行归属、全部中断与反事实仍未认证，且缺独立策略效益验证，原宽提案保留waiting。"
    },
    {
      "id": "silent-proposal-49632bc4878fb597",
      "reason": "单项属性/虚弱公式已有实现，但本批不足以提供力量、敏捷、虚弱、成长四路径的完整生产联合校准；不增加统一保血或输出权重。"
    },
    {
      "id": "silent-proposal-66532328a585941f",
      "reason": "缺同起始血量、构筑和抽序下不同启动/构筑顺序的完整对照及可复现收益函数，不能由一次空打拟合启动阈值或优先级。"
    },
    {
      "id": "silent-proposal-43a76a31ba7bdcfa",
      "reason": "缺同起始HP/构筑/完整抽序下的另一可救活SL线路与分项生产校准；本局首试胜利不能用于改SL门槛或换线偏好。"
    },
    {
      "id": "silent-proposal-5264153a4a4b0e5c",
      "reason": "缺A10召唤/航行全链的冻结生产调用输入与另一目标序的实际后续结果；已有召唤子实现不能证明成长及固定杀序收益。"
    },
    {
      "id": "silent-proposal-bddfa690a84e03d0",
      "reason": "缺同抽不同排序的完整胜线及睡眠/醒来/眩晕/当前进阶成长的生产全链校准；四次失败不能拟合全败排序权重或固定杀序。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-89354805ee4d7e77",
    "silent-proposal-f2bfceddb1898dca",
    "silent-proposal-283a164780d11e69",
    "silent-proposal-ebbfe3b97548756d",
    "silent-proposal-e5b87be50f28f311",
    "silent-proposal-49632bc4878fb597",
    "silent-proposal-66532328a585941f",
    "silent-proposal-43a76a31ba7bdcfa",
    "silent-proposal-5264153a4a4b0e5c",
    "silent-proposal-bddfa690a84e03d0"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-89354805ee4d7e77",
      "state": "waiting",
      "reason": "已有神化同线与已核卡对的局部实现；仍缺未覆盖卡的完整状态效果、确定抽序和战内各堆实例，以及实际施放到跨抽牌/重规划/SL消费者的校准，不能把整项登记implemented。"
    },
    {
      "id": "silent-proposal-f2bfceddb1898dca",
      "state": "waiting",
      "reason": "缺同起点、同随机池、同总预算的配对实验、候选稳定性和MC收益曲线；不同盘面的1/12与12/12不能校准新预算、持有价、护栏或固定目标规则。"
    },
    {
      "id": "silent-proposal-283a164780d11e69",
      "state": "waiting",
      "reason": "这是同证据的经验来源链；当前局部实现尚未闭合实际施放与后继消费，不能用另一条仍waiting的同题提案把它登记duplicate，沿原ID保留。"
    },
    {
      "id": "silent-proposal-ebbfe3b97548756d",
      "state": "waiting",
      "reason": "15个机制/资源子项缺按来源、期限和属性组合冻结的生产调用联合校准，路线与休息的反事实也未观测；不能用局部公式或知识文字证明整项完成。"
    },
    {
      "id": "silent-proposal-e5b87be50f28f311",
      "state": "waiting",
      "reason": "已有候选、护栏、SL、单动作回执与离线整轮端点子实现；完整候选执行归属、全部中断与反事实仍未认证，且缺独立策略效益验证，原宽提案保留waiting。"
    },
    {
      "id": "silent-proposal-49632bc4878fb597",
      "state": "waiting",
      "reason": "单项属性/虚弱公式已有实现，但本批不足以提供力量、敏捷、虚弱、成长四路径的完整生产联合校准；不增加统一保血或输出权重。"
    },
    {
      "id": "silent-proposal-66532328a585941f",
      "state": "waiting",
      "reason": "缺同起始血量、构筑和抽序下不同启动/构筑顺序的完整对照及可复现收益函数，不能由一次空打拟合启动阈值或优先级。"
    },
    {
      "id": "silent-proposal-43a76a31ba7bdcfa",
      "state": "waiting",
      "reason": "缺同起始HP/构筑/完整抽序下的另一可救活SL线路与分项生产校准；本局首试胜利不能用于改SL门槛或换线偏好。"
    },
    {
      "id": "silent-proposal-5264153a4a4b0e5c",
      "state": "waiting",
      "reason": "缺A10召唤/航行全链的冻结生产调用输入与另一目标序的实际后续结果；已有召唤子实现不能证明成长及固定杀序收益。"
    },
    {
      "id": "silent-proposal-bddfa690a84e03d0",
      "state": "waiting",
      "reason": "缺同抽不同排序的完整胜线及睡眠/醒来/眩晕/当前进阶成长的生产全链校准；四次失败不能拟合全败排序权重或固定杀序。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-104302/learner/runs/20261018-104311-b41e5b36-ec67-432e-97cf-81d51989cc70-strategy-proposal/report.md"
}
```

最终检查：派发10 ID及六锚点身份仍匹配；工作树干净、HEAD仍为上述base；账本CLI与全账本check均退出0、原科学字段不变；本批材料gitleaks退出0（gzip不作解包扫描声明）。完整回执见final-checks.json。

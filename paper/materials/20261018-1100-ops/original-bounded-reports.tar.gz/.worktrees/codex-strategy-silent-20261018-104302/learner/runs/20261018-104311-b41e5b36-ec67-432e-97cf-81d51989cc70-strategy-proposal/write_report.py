import json
from pathlib import Path

out = Path(__file__).resolve().parent
dispatch = json.loads((out / 'dispatch.json').read_text())
queue = json.loads((out / 'queue-selected.json').read_text())
pins = json.loads((out / 'source/pins.json').read_text())
verified = json.loads((out / 'verified-evidence.json').read_text())
consumer = json.loads((out / 'consumer/summary.json').read_text())
base = pins['base']
batch = '20261018-104302-strategy-proposal'

details = {
    '89354805ee4d7e77': {
        'evidence': 'VLZ6CCT8AQ0A F35 T1、F43 T1—T5、F45 T1；states 275564→275565、275679→275680、275687、275721—275732；decisions 269706/269707/269748/269754。',
        'support': '两组神化实际施放均花2能；F35手牌普通→升级及F43后续抽牌变化可核。当前代码已有观察配对、同线升级、牌堆升级和候选参考；场外deck与战内状态分开。',
        'counter': 'F45持有但未施放；F43施放后仍有显著战损。猛扑的FREE_SKILL_POWER已有显式未覆盖标记；仅有伤害配对不足以把它标为完整known。',
        'reason': '已有神化同线与已核卡对的局部实现；仍缺未覆盖卡的完整状态效果、确定抽序和战内各堆实例，以及实际施放到跨抽牌/重规划/SL消费者的校准，不能把整项登记implemented。',
        'validation': '保存普通/升级卡、实际支付、当时属性及每次抽牌身份；固定验证同线与后继抽牌、未覆盖卡保持unknown、已升级不叠加、场外deck不变。新增源码须撤掉失败、恢复通过。',
    },
    'f2bfceddb1898dca': {
        'evidence': 'VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；decisions 269748/269754/269770；states 275721—275755。',
        'support': '原题记录药水MC 1/12与后问12/12，后问已换盘面；F45末轮32HP、20挡、减力后显示总来袭59的算术仍有缺口。留存全部候选和原药水事实。',
        'counter': '707ms耗时不是同预算策略的受控对照；CURE_ALL实际补能/抽牌不等于按名字回血；T4高伤线未实打，全败推演也不证明固定focus或留药规则。',
        'reason': '缺同起点、同随机池、同总预算的配对实验、候选稳定性和MC收益曲线；不同盘面的1/12与12/12不能校准新预算、持有价、护栏或固定目标规则。',
        'validation': '先冻结完整模型及种子/随机池，在同题同总预算比较现策略与分段预算，记录每候选样本、耗时、缺覆盖与并列；缺这些输入时保留现行为。',
    },
    '283a164780d11e69': {
        'evidence': '与89354805ee4d7e77相同的VLZ6CCT8AQ0A F35/F43/F45；原经验silent-apotheosis-combat-upgrades，独立source_task=experience-update。',
        'support': '经验链与复盘链原SHA分别核回；两项共享本局证据，不能重复计支持局。',
        'counter': '同主题不等于已有完整live实现；原神化提案仍有未覆盖卡与实际消费缺口。',
        'reason': '这是同证据的经验来源链；当前局部实现尚未闭合实际施放与后继消费，不能用另一条仍waiting的同题提案把它登记duplicate，沿原ID保留。',
        'validation': '沿两个原ID共同验证神化状态传播；完整实际live祖先源码及消费证据齐备后再按各来源链登记，不另建重复ID。',
    },
    'ebbfe3b97548756d': {
        'evidence': 'VLZ6CCT8AQ0A F43 T1—T5、F45 T3—T5及逐场资源；states 275679—275710、275738—275755；原稿列出的15项经验及14个账本全部保留。',
        'support': '现场力量、敏捷、勒紧、覆甲、毒和未来能力必须分源；F45三敌直到终态仍未退场。原经验已区分实际HEAL与路线投影，当前局部公式/审计不能代表联合完成。',
        'counter': '升级、当前属性、毒触发和未来资源不是同一实验分母；赢战仍付血价，未走路线、锻造、另一focus无同盘整场结果。',
        'reason': '15个机制/资源子项缺按来源、期限和属性组合冻结的生产调用联合校准，路线与休息的反事实也未观测；不能用局部公式或知识文字证明整项完成。',
        'validation': '逐子项冻结原帧、当时属性/进阶与调用输入，分别验证升级毒、四段减力、现场0覆甲及20挡，再核胜战→休息→后战资源链；不拟合统一保血或路线权重。',
    },
    'e5b87be50f28f311': {
        'evidence': '8JRE1C4H4Z2W F17 T6、F33 首/三试T2、第二试T5及第六试T11；decisions 270216/270282/270264/270441/270442；states 276433→276434。',
        'support': '270216与270282指纹逐字相同；离线整轮端点核回首/三试T2玩家47→44/32、敌326→316/309，实付多12HP、多7敌血；第二试T5实损4、扣25。原回答、SL替换和原journal分列，避免旧journal误当替换结果。',
        'counter': '同盘差值并无原线整战赢局；末次T11整轮5→0、敌166→130含已记录全部动作，结束请求端点敌154→130另列，不把整轮36归给末步或单个候选。显示37−22=15仅算术，截断实扣5不等完整入伤。',
        'reason': '已有候选、护栏、SL、单动作回执与离线整轮端点子实现；完整候选执行归属、全部中断与反事实仍未认证，且缺独立策略效益验证，原宽提案保留waiting。',
        'validation': '继续保留decision_id、原行号、尝试/重载、指纹与时间，逐段核原答→护栏→SL→派发→重问；整轮端点和单题预测分开，缺帧/跨尝试不连接。',
    },
    '49632bc4878fb597': {
        'evidence': 'CA5KE8GFJ9X2 F13 T1/T3/T5；states 273237、273252、273263—273269。',
        'support': '本批原帧分别显示力量0/4/8与喷水11/15/19；虚弱后的变化须按当时状态单列，不能当停止成长。',
        'counter': '本局未建立计划中的步法；没有把力量、敏捷、弱与独立成长一起冻结并校准的实际生产调用输入，不能借单一挡牌修复完成复合条目。',
        'reason': '单项属性/虚弱公式已有实现，但本批不足以提供力量、敏捷、虚弱、成长四路径的完整生产联合校准；不增加统一保血或输出权重。',
        'validation': '冻结本局F13 T5手牌、玩家/敌属性、进阶HP/移动表及实际前缀，分开验证每击、减益、挡和成长；新权重须独立后置局验证。',
    },
    '66532328a585941f': {
        'evidence': '5PM6JAQG6FNQ F33 T1/T2、F39 第二试T2；decisions 268455；对应原states由observations.json的bubble_actions保留精确offset/bytes/SHA。',
        'support': '末试冒泡前后玩家均29HP，能量5→4；无毒目标没有新增毒。此前F33已建立雾3/触媒1/群蛇4，必须与末战未建立分账。',
        'counter': '旧备注35HP是目标敌血，原账本已有勘误，本批读回不再覆写或新增勘误；不同敌人与资源条件下的胜负不能当启动顺序对照。',
        'reason': '缺同起始血量、构筑和抽序下不同启动/构筑顺序的完整对照及可复现收益函数，不能由一次空打拟合启动阈值或优先级。',
        'validation': '持有、计划与建立时点分别保存，固定核零毒冒泡实付1能；长期收益须以独立同条件对照验证，不把其他战斗已建立能力迁入本战。',
    },
    '43a76a31ba7bdcfa': {
        'evidence': '61E2QS63Y9WU F17 T5/T6/T7；states 273502—273513。',
        'support': '吸取后玩家力量2→0、敏捷0→−2，敌力0→2；T6双防御各3，后续毒结算需与直伤/挡分账。',
        'counter': '该战首试胜利，不能从后续死亡倒推固定SL顺序或范围；缺同起点同抽序的另一可获胜SL线路。',
        'reason': '缺同起始HP/构筑/完整抽序下的另一可救活SL线路与分项生产校准；本局首试胜利不能用于改SL门槛或换线偏好。',
        'validation': '冻结吸取前后、负敏捷挡牌、毒层与触发，逐分项校准；若改SL规则须留完整同盘线路及后置独立局结果。',
    },
    '5264153a4a4b0e5c': {
        'evidence': '61E2QS63Y9WU F23 T4/T5；states 273593—273605。',
        'support': 'T4本体线47伤/损15在原帧兑现，幻象14→2仍未退场；T5成长到6力后才结束幻象。',
        'counter': 'focus幻象的39伤零损只是题面候选，未实打后续，不能据此规定先杀幻象或声称整战多省15。',
        'reason': '缺A10召唤/航行全链的冻结生产调用输入与另一目标序的实际后续结果；已有召唤子实现不能证明成长及固定杀序收益。',
        'validation': '冻结两实体每轮HP/力量/意图和召唤脚本，保留全部目标选项、相同推演并列；分别核退场窗口与当前伤害，不给固定首杀规则。',
    },
    'bddfa690a84e03d0': {
        'evidence': 'DUZUBAJ3A8GP F30 四试，重点末试T4—T6；原始state窗口及consumer/DUZUBAJ3A8GP输出。',
        'support': '睡3/2/1后T4醒来，后继力量2/4与攻击20/22；临时减力恢复和独立成长须分别核。',
        'counter': '四试均败；末试T4比首试多扣3敌血同时多损2玩家血，没有支持固定输出血价或换线胜率的获胜对照。',
        'reason': '缺同抽不同排序的完整胜线及睡眠/醒来/眩晕/当前进阶成长的生产全链校准；四次失败不能拟合全败排序权重或固定杀序。',
        'validation': '按A10实帧冻结睡层、眩晕、力量恢复与成长、实际挡及毒；比较完整线路时按run_id分组，SL尝试不扩独立分母。',
    },
}

proposal_sections = ['# 本批十项原提案复核与待验证实现边界', '',
    '核查时间：2026-10-18T10:55:48+08:00（写入前已运行date）。角色silent；本批观察进阶均A10。',
    f'任务strategy-proposal；batch={batch}；base={base}。',
    '仅消费dispatch.json内10个原CLI提案ID，不新建同题ID；本批没有research_request、implementation_request或proposal_repair。',
    '原提案正文与保存SHA全部核回，副本在original-proposals/；不是重新编写历史复盘。当前结论是逐项waiting，无源码、规则、知识或版本改动。',
    '', '## 共同范围、方法与限制', '',
    '原六局是2026-10-07旧样本，全部为发现/复核集；本次重读不是新增支持局，同局不同战斗与SL尝试不充作独立后置验证。',
    '只读本角色原日志、所派原提案/账本、Silent知识和相关实现；未引入其他角色的游戏结论。授权Roy-2026-10-07-learning提供修改权限，不提供机制事实。',
    '本轮没有拟合阈值、常量、留药价格、固定目标顺序或终局权重。若后续形成可实施子项，须保留未知边界并按原固定数据红绿、沙箱检查及live流程交付；本报告不代替这些验证。',
    '现有消费者把完整候选收益保守留null；这是接口契约，不意味着人工逐帧绝不可能核清某条完整候选，也不等于所有已有实现都无效。', '']
results = []
for ident in dispatch['proposal_ids']:
    original = queue['originals'][ident]
    d = details[ident.removeprefix('silent-proposal-')]
    results.append({'id': ident, 'state': 'waiting', 'reason': d['reason']})
    proposal_sections += [f'## {ident}', '', f"原摘要：{original['summary']}",
        f"账本：{', '.join(original['ledger'])}；原提案SHA256：{original['proposal_sha256']}。",
        f"来源任务：{original['source_task']}；实现任务：strategy-proposal。", '',
        f"证据局号/层/回合及引用：{d['evidence']}", '', f"支持与当前实现：{d['support']}", '',
        f"反例及限制：{d['counter']}", '', f"处置waiting及具体缺口：{d['reason']}", '',
        '旧/新行为：保留当前合法选项、参考并列、出牌/药水/SL/终局规则；本批没有新行为。预期实现仅限原提案要求的分项状态与可审计事实，证据充分后另作源码增量。', '',
        f"后续验证方法：{d['validation']}", '',
        '预期影响：目前仅补充可追溯的缺口与证据链接，不宣称策略收益。回退：本批无生产改动；保留原记录，后续源码须用其实际提交回退，不撤销历史证据。', '']
(out / 'proposal.md').write_text('\n'.join(proposal_sections))

result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': batch, 'base': base,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [{'id': r['id'], 'reason': r['reason']} for r in results],
          'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(out / 'report.md')}
(out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

lines = ['# Silent 策略提案批次报告', '',
         '10个派发原提案均为waiting。本批没有可按证据完成固定生产校准的源码增量；不把已有局部实现或同题经验链登记为整项implemented/duplicate。', '',
         f'核查时间：2026-10-18T10:55:48+08:00；batch={batch}。',
         f'完整base：`{base}`。开工工作树干净，普通任务已执行`git merge --no-edit main`，结果Already up to date。',
         '根专题请求绑定另一旧batch，本批无research_request，按普通队列处理；没有读取其他专题代替身份，也不修改请求或learn.json。', '',
         '## 证据与身份', '',
         '六局runs.jsonl全部为SILENT、A10；source code均带dirty，不用当前提交冒认旧运行的完整源码树。原始身份只认run/run_id/state.run_id/fingerprint.run，正文提及不作归局。', '',
         '| 局号 | 结束层 | states | decisions | SL记录 | brain | run-plans |',
         '|---|---:|---:|---:|---:|---:|---:|']
by_stream = {m['stream']: m for m in verified['streams']}
for run in dispatch['runs']:
    lines.append('| ' + ' | '.join(map(str, [run, verified['runs'][run]['floor']] +
                 [by_stream[s]['counts'][run] for s in ('states', 'decisions', 'sl-attempts', 'brain', 'run-plans')])) + ' |')
lines += ['', f"公共入口抽取8流，共{verified['total_rows']}条；source_size、逐行offset/bytes/SHA和计数在evidence/evidence-manifest.json及各evidence.jsonl。verify_and_consume.py逐行seek原日志，核原字节SHA、JSON、显式归局与输出SHA，结果见verified-evidence.json和verification-consumer.log。",
          'states/decisions/brain各有2行全源无效JSON，公共入口原计数保留；不把它们归到某个本批局。fight-plans在本次字节截点选到0行，仅说明这个截点没有选中，不能推断日志从未存在。独立identity-evidence保留，不覆盖初始结果。', '',
          '## 逐项结果', '', '| 原提案ID | 账本 | 结果及缺口 |', '|---|---|---|']
for r in results:
    lines.append(f"| {r['id']} | {', '.join(queue['originals'][r['id']]['ledger'])} | waiting：{r['reason']} |")
lines += ['', '逐项证据局号、层、回合、支持、反例、旧/新行为、样本限制、验证及回退详见proposal.md；19条相关Silent经验和26个原账本仅作为选中提案追溯，未写新经验或扩大统计分母。', '',
          '## 实际源码与消费者读回', '',
          f"只读live截点：`{pins['observed_live']}`。16个选定文件的base字节、Git blob、SHA、最后源码提交及其实际live祖先关系在source/pins.json；16个最后提交均为实际live祖先。12文件逐字相同，4文件差异保存在source/base-live.patch。",
          'card-model、potion-cost、SL explore是所选署名注释差；rollout还含Queen盟友力量的另一增量。这里仅核该差异，未研究另一任务，不能外推整树等价。原源码快照全部以.txt保存。', '',
          '| 已有局部能力 | 实际live祖先源码commit |', '|---|---|']
for filename in ['agent/src/reflex/silent-apotheosis.ts', 'agent/src/reflex/silent-apotheosis-reference.ts',
                 'agent/src/reflex/silent-hp-guard-audit.ts', 'agent/src/reflex/silent-selection-audit.ts',
                 'agent/src/reflex/silent-selection-dispatch.ts', 'learner/lib/selection-execution.ts',
                 'learner/lib/selection-terminal.ts', 'learner/lib/selection-turn.ts']:
    p = next(p for p in pins['files'] if p['path'] == filename)
    lines.append(f"| {filename} | `{p['last_commit']}` |")
lines += ['', '这些提交只证明各自局部实现，均不是本批提交，也不作为整项implemented_commit。', '',
          '使用当前base的learner/audit-selection.ts消费六个限定窗口（保持原行号/尝试/指纹/时间），不接网络、LLM、游戏或刷新知识。所有输入、输出以gzip保留，压缩解压后SHA逐字核回；stderr、退出码和范围见consumer/summary.json。', '',
          '| 局号 | 层范围 | 决策/状态 | 片段/动作/轮窗口 | 退出码 |', '|---|---|---|---|---:|']
for c in consumer:
    lines.append(f"| {c['run_id']} | {','.join(map(str,c['floors']))} | {c['input_decisions']}/{c['input_states']} | {c['segments']}/{c['observed_actions']}/{c['observed_turns']} | {c['returncode']} |")
lines += ['', f"合计{sum(c['segments'] for c in consumer)}个选线片段、{sum(c['observed_actions'] for c in consumer)}个已记录动作、{sum(c['observed_turns'] for c in consumer)}个轮窗口；这些窗口包含unknown，不是全部完整回合。限定窗口内无缺decision_id元数据排除；未覆盖的其他层未冒称已消费。",
          'actual_full_candidate_result与actual_rollout_best仍均为null（非空计数为0）。这反映现有消费者的保守认证范围，不证明所有候选永远无法人工核验，也不把observed净变化当成选线因果。', '',
          'observations.json及observations.log读回：8JRE同盘首/三试T2实损3/15、实扣10/17；第二试T5实损4、实扣25；末试T11整轮实扣敌36、玩家5→0，与末步毒结算敌154→130分列。5PM冒泡时玩家29→29、能量5→4；旧35血备注已有原账本勘误，不重写历史。神化两组实际支付2能已核。', '',
          '## 验证、记录与交付边界', '',
          '没有生产源码或生成知识改动，没有新提交、合入、eval版本或shipped。merge=live的源码发布步骤不适用于本批无改动结果，因此未抢live锁、未提交后台知识数据、未改上线通知。',
          '未运行tsc、vitest或撤源码红绿；tests固定三个null。六次离线消费者退出0与逐字核验仅为材料/消费者读回，不冒充生产测试、自然采用或策略收益。',
          '账本追溯仅经根learner/ledger.py update追加where.proposal与note，不增支持局、不改claim/first_run/prior/evidence/status/version/effect；原shipped条目不倒退为proposed。回执和输入保留在ledger-links.*，最终检查见final-checks.json。原队列状态由宿主消费proposal_results；不直接改专用队列、不另建ID。',
          '提交前gitleaks规定无新提交触发；仍对本批可读交付材料运行脱敏扫描，具体退出码及扫描范围保留在gitleaks.*和final-checks.json，不声称扫描所有运行日志或整个会话。',
          f'提案绝对路径：{out / "proposal.md"}', f'报告绝对路径：{out / "report.md"}',
          '原失败/初稿/并行记录全部保留；临时分析均在本批scratch，工作树受跟踪文件保持干净。运行模型的原生身份由宿主核实，本报告不凭默认配置自报已核。', '',
          '```json', json.dumps(result, ensure_ascii=False, indent=2), '```', '']
(out / 'report.md').write_text('\n'.join(lines))

ledger_ids = sorted({ident for item in queue['originals'].values() for ident in item['ledger']})
updates = []
for ident in ledger_ids:
    proposals = [p for p in dispatch['proposal_ids'] if ident in queue['originals'][p]['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(out / 'proposal.md'), str(out / 'report.md')]},
                    'note': f'{batch}复核原六局旧证，关联原提案{",".join(proposals)}：本批均waiting；无新增独立支持或源码实现，保留原claim/首证/prior/evidence/status/version/effect，仅追加本批报告追溯。'})
(out / 'ledger-links.input.jsonl').write_text(''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates))
print(json.dumps({'report': str(out / 'report.md'), 'waiting': len(results), 'ledger_metadata_updates': len(updates),
                  'tests': result['tests']}, ensure_ascii=False))

from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, tarfile
root=Path.cwd(); r=root; p=r/'ops/codex-ops/record-staging/20261015-2359'; pub=r/'paper/materials/20261015-2359-ops'; pub.mkdir(exist_ok=True); sha=lambda raw:hashlib.sha256(raw).hexdigest()
def load(f): return json.loads(f.read_text())
def write(f,v): f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=r): return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip(); assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261015-234301-strategy-proposal'; b=load(r/'ops/codex-ops/learn.json')['batches'][bid]; report=b['report']; s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results']) and report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(v is None for v in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
completion=load(s/'completion-verification.json'); assert completion['head']==report['base'] and completion['git_status_clean'] and completion['tracked_diff_empty'] and completion['ten_proposal_results_match_dispatch'] and completion['no_new_source_or_knowledge'] and completion['material_checks']==70 and completion['ledger_links']==26 and completion['ledger_protected_fields'] and completion['report_links_valid']
for x in load(s/'delivery-manifest.json'):
 f=Path(x['path']); assert f.is_relative_to(s); raw=f.read_bytes(); assert len(raw)==x['bytes'] and sha(raw)==x['sha256']
material=load(s/'material-verification.json'); assert material['记录总数']==sum(sum(x['counts'].values()) for x in material['流'])==6995 and material['逐行原字节已核验'] and material['材料断言数']==len(material['断言'])==70 and all(x['实值']==x['期望'] for x in material['断言'])
for x in material['流']:
 directory='evidence-extra' if x['stream'] in ['runs','fight-plans'] else 'evidence'; assert sha((s/directory/(x['stream']+'.evidence.jsonl')).read_bytes())==x['output_sha256']
proposals=load(s/'selected-proposals.json'); assert len(proposals)==10 and {x['id'] for x in proposals}==set(report['code_proposals'])
for x in proposals:
 f=Path(x['proposal']); assert f.resolve().is_relative_to(r); assert sha(f.read_bytes())==x['proposal_sha256']==sha((s/(x['id']+'.original.md')).read_bytes())
source=load(s/'source-readback.json'); assert source['base']==report['base'] and len(source['leaves'])==13; equal=0
for x in source['leaves']:
 raw=git('show',report['base']+':'+x['path']); live=git('show',source['live_head']+':'+x['path']); assert sha(raw)==x['base_sha256'] and sha(live)==x['live_sha256']; assert (raw==live)==x['equal'] and raw.replace(b'Roy',b'Dai')==live.replace(b'Roy',b'Dai'); equal+=raw==live
 assert x['base_source_is_live_ancestor']; git('merge-base','--is-ancestor',x['base_source_commit'],report['base']); git('merge-base','--is-ancestor',x['base_source_commit'],source['live_head']); git('merge-base','--is-ancestor',x['live_source_commit'],source['live_head'])
assert equal==11
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text()); native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
inputs=[json.loads(x) for x in (s/'ledger-update-input.jsonl').read_text().splitlines()]; ledger=r/'paper/materials/learning/ledger.jsonl'; owned=[]
for raw in ledger.read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs): owned.append(raw)
assert len(inputs)==len(owned)==26 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned); assert set((s/'ledger-update.log').read_text().split())=={x['id'] for x in inputs}
receipt=load(s/'ledger-append-verification.json'); assert receipt['append_count']==26 and receipt['old_selected_rows_verified']==11461 and receipt['other_selected_appends_during_window']==2 and receipt['status_fields_written'] is False and receipt['evidence_fields_written'] is False
for x in receipt['protected_items'].values(): assert all(x[k] for k in ['non_trace_fields_unchanged','old_history_prefix_unchanged','old_notes_prefix_unchanged','old_where_prefix_unchanged'])
for x in receipt['appends']+receipt['selected_other_appends']:
 with ledger.open('rb') as f: f.seek(x['offset']); raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and json.loads(raw)==x['row']
 if x in receipt['appends']: assert raw in owned
 else: assert raw not in owned
old=git('show',base+':paper/materials/learning/ledger.jsonl'); existing=set(old.splitlines()); added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in existing); assert len(added.splitlines())==26
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); fold=lambda raw:module.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]); a=fold(old); z=fold(old+added); assert set(a)==set(z)
for ident in a:
 assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
 assert z[ident]['history'][:len(a[ident]['history'])]==a[ident]['history']
 for key,items in a[ident]['where'].items(): assert all(x in z[ident]['where'][key] for x in items)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_no_change_gate=b['no_change_proposals'],native=native,original_completion=completion,delivery_artifacts_and_evidence_sha_verified=True,original_evidence_rows=6995,original_material_assertions=70,source13_sha_and_ancestry_verified=True,equal11_historical_comment_only2=True,original_ledger_receipt=receipt,owned_learner_cli_rows=26,other2_postmortem_rows_preserved_not_staged=True,protected_fold_history_where_preserved=True,material_not_reexecuted=True,limits=['Six historical dirty Silent A10 anchors and183 high brain records remain distinct from current native Sol6.1/xhigh. No reconstructed consumed dirty tree/knowledge or full-history calibration.', 'Existing R361 Deadly Poison and R364 Pounce coverage source ancestors are static provenance, not this batch implementation or new natural consumers.', 'Whole candidate execution, persistent cast identity, free Skill propagation, per-source growth, combined calibration, paired full outcomes and independent holdout remain unknown.', 'Original path probes, output truncation and preparation indentation error preserved; no new contradictory game knowledge or product failure claimed.']))
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip(); print(at,flush=True)
decision=f'\n- {at} 运维codex：2359原234301策略done0/no-source处置核，7b1干净WT/HEAD不变、十完整提案waiting/testsnull/域空/mergednull，无源码或合入阻塞，不空合/发号/补测。六Silent A10八流6995原行及70原材料断言/精选40状态10决策为学习者有限核验，SHA核不重跑或当生产测试/整候选认证；原神化、已证配对与猛扑提示R361/R364的真实source祖先只作既有窄来源，不当本批上线/自然消费者或宽父完成。13叶旧livecfa1逐SHA/双来源祖先核11同2历史Roy-Dai注释差，实际施放身份/免费传播/四属性联合/召唤期限/同抽SL整战与历史dirty消费字节等缺口保持，不拟新阈值。26所属CLI纯where/note逐输入/输出ID、原offset/bytes/SHA核，私有fold全部非追溯字段/旧history/where保持；原窗口11461旧选中行及2外来postmortem追加分列保护，不纳本轮提交、不重复CLI/旧证据/降级shipped。历史183脑high与当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network分列，原定位缺文件/截断/准备脚本缩进错误保留，不当产品失败或另派修复。仅本人记录/26所属追溯提交，保并行脏记录；无新知识/源码/版本/复盘/论文刷新/测试/派发/重启或账号home模型额度队列prompt操作，不关闭宽父。证据paper/materials/20261015-2359-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原234301十完整提案继续waiting，无源码修改/合入阻塞；6995原行与70材料断言读回留有界结论，原窄发布不关闭完整施放/费用/联合校准缺口。26所属CLI追溯已核并与2外来追加分离，未重复登记、补测或发号。回执paper/materials/20261015-2359-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note}; write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f: f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,own_ledger_rows=26,foreign2_rows_not_staged=True,protected_fields_preserved=True,no_new_source_or_tests_or_merge=True,wide_parents='remain open'))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[x for x in s.iterdir() if x.is_file() and x.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',s/'evidence-extra/evidence-manifest.json']+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']]
 for f in sorted(files):
  raw=f.read_bytes(); rel=str(f.relative_to(r)); copy=p/'archive-scan'/rel; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=rel); artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts); helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes(); copy=p/'helper-scan'/f.name; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); archive.add(f,arcname=f.name); helpers.append(dict(path=str(f.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers); values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}; values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file(): values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files'; entries=[]
for path,raw in values.items():
 copy=dest/path; copy.parent.mkdir(parents=True,exist_ok=True); copy.write_bytes(raw); entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries)); result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True); (pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr); assert result.returncode==0; print(json.dumps(dict(waiting=10,owned_cli_rows=26,ledger_check=0,paths=len(entries))))

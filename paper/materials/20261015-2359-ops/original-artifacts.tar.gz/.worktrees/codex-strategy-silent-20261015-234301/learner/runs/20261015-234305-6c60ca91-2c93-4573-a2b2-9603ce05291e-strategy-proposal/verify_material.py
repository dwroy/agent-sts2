import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['dispatch']['runs']
streams = {}
manifests = []
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'核验': name, '实值': actual, '期望': expected})


def identity(row):
    state = row.get('state') or {}
    fp = row.get('fingerprint')
    if isinstance(fp, str):
        fp = json.loads(fp)
    values = [row.get('run_id'), state.get('run_id'), row.get('run'),
              (fp or {}).get('run')]
    values = {v for v in values if isinstance(v, str) and v and v != 'run_unknown'}
    return next(iter(values)) if len(values) == 1 else None


for directory in ['evidence', 'evidence-extra']:
    manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
    for item in manifest:
        name = item['stream']
        path = OUT / directory / (name + '.evidence.jsonl')
        check(name + ' 抽取文件SHA', hashlib.sha256(path.read_bytes()).hexdigest(), item['output_sha256'])
        records = []
        count = collections.Counter({r: 0 for r in runs})
        with (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
            for line in path.open():
                entry = json.loads(line)
                source.seek(entry['offset'])
                raw = source.read(entry['bytes'])
                assert len(raw) == entry['bytes'] and raw.endswith(b'\n')
                assert hashlib.sha256(raw).hexdigest() == entry['sha256']
                assert json.loads(raw) == entry['row']
                assert identity(entry['row']) == entry['run_id'] in runs
                assert entry['offset'] + entry['bytes'] <= item['source_size']
                count[entry['run_id']] += 1
                records.append(entry)
        check(name + ' 逐行字节/JSON/身份核验后计数', dict(count), item['counts'])
        streams[name] = records
        manifests.append(item)

S = {e['line']: e for e in streams['states']}
D = {e['line']: e for e in streams['decisions']}
used_s = set()
used_d = set()


def state(n):
    used_s.add(n)
    return S[n]['row']['state']


def combat(n):
    return state(n)['combat']


def player(n):
    return combat(n)['player']


def power(entity, name):
    return next((x['amount'] for x in entity['powers'] if x['power_id'] == name), 0)


def enemy(n, name):
    return next(e for e in combat(n)['enemies'] if e['enemy_id'] == name)


def attack(n, name):
    return sum((i.get('damage') or 0) * (i.get('hits') or 0) for i in enemy(n, name)['intents'])


def decision(n):
    used_d.add(n)
    return D[n]['row']


def option(n, key):
    return json.loads(decision(n)['questions']['plan']['criteria'][key])


def observed_hand(n, name):
    return [c for c in combat(n)['hand'] if c['card_id'] == name]


check('派发六局无重复', len(set(runs)), 6)
for e in streams['runs']:
    check(e['run_id'] + ' 角色/进阶', [e['row']['character'].lower(), e['row']['ascension']], ['silent', 10])

check('VLZ F35神化支付能量', [player(n)['energy'] for n in [275564, 275565]], [7, 5])
check('VLZ F43神化支付能量', [player(n)['energy'] for n in [275679, 275680]], [7, 5])
for name in ['STRIKE_SILENT', 'SUCKER_PUNCH', 'FASTEN', 'PIERCING_WAIL']:
    check('VLZ F43 ' + name + ' 施放前后升级标记',
          [[c['upgraded'] for c in observed_hand(n, name)] for n in [275679, 275680]],
          [[False] * len(observed_hand(275679, name)), [True] * len(observed_hand(275680, name))])
check('VLZ F43神化前同序候选', [option(269706, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']], [43, 14])
check('VLZ F43神化后同序候选', [option(269707, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']], [51, 13])
check('VLZ F43整轮观察端点净伤/净损',
      [enemy(275679, 'SOUL_NEXUS')['current_hp'] - enemy(275687, 'SOUL_NEXUS')['current_hp'],
       player(275679)['current_hp'] - player(275687)['current_hp']], [51, 13])
check('VLZ F43后继勒紧已建', power(player(275687), 'FASTEN_POWER'), 6)
check('VLZ F45首次推演范围', [decision(269748)['rollout'][k] for k in ['horizon', 'samples', 'best']], [1, 1, None])
mc = decision(269748)['potions']['random'][0]
check('VLZ F45首次药水MC成熟度', [mc[k] for k in ['potion', 'samples', 'requested', 'ms']], ['CURE_ALL', 1, 12, 707])
check('VLZ F45第二次药水MC样本', decision(269754)['potions']['random'][0]['samples'], 12)
check('VLZ F45实际喝药不回血且加能量',
      [[player(n)['current_hp'], player(n)['energy']] for n in [275728, 275729]], [[67, 1], [67, 2]])
check('VLZ F45T4所选线', [option(269770, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']], [24, 13])
check('VLZ F45T4未实打攻击线', [option(269770, 'plan2')[k] for k in ['damage_dealt', 'hp_lost']], [32, 31])
check('VLZ F45T4观察端点',
      [player(275745)['current_hp'] - player(275748)['current_hp'],
       sum(e['current_hp'] for e in combat(275745)['enemies']) - sum(e['current_hp'] for e in combat(275748)['enemies'])], [13, 24])
check('VLZ F45T5无临减时总威胁', sum(attack(275748, name) for name in ['FLAIL_KNIGHT', 'SPECTRAL_KNIGHT', 'MAGI_KNIGHT']), 83)
check('VLZ F45T5尖啸后总威胁', sum(attack(275754, name) for name in ['FLAIL_KNIGHT', 'SPECTRAL_KNIGHT', 'MAGI_KNIGHT']), 59)
check('VLZ F45T5现场血/挡/覆甲', [player(275754)['current_hp'], player(275754)['block'], power(player(275754), 'PLATING_POWER')], [32, 20, 0])
check('VLZ F45T5完整需损与实际截断', [59 - player(275754)['block'], player(275754)['current_hp'] - player(275755)['current_hp']], [39, 32])
check('VLZ F45毒后敌血仍正', sorted(e['current_hp'] for e in combat(275755)['enemies']), [21, 77, 80])

check('8JRE 首/第三试同原始指纹', decision(270216)['fingerprint'], decision(270282)['fingerprint'])
check('8JRE 首/第三试尝试身份', [decision(n)['sl_attempt'] for n in [270216, 270282]], [1, 3])
check('8JRE 首试T2观察端点净损/净伤',
      [player(276208)['current_hp'] - player(276212)['current_hp'], enemy(276208, 'THE_INSATIABLE')['current_hp'] - enemy(276212, 'THE_INSATIABLE')['current_hp']], [3, 10])
check('8JRE 第三试T2观察端点净损/净伤',
      [player(276274)['current_hp'] - player(276278)['current_hp'], enemy(276274, 'THE_INSATIABLE')['current_hp'] - enemy(276278, 'THE_INSATIABLE')['current_hp']], [15, 17])
numbers = decision(270282)['sl_explore']['numbers']
check('8JRE 原线0/24与替线5/24不等', ['dead 0/24' in numbers['original'], 'dead 5/24' in numbers['replacement']], [True, True])
check('8JRE 第二试T5原答/护栏候选血价', [option(270264, k)['hp_lost'] for k in ['plan4', 'plan6']], [16, 4])
check('8JRE 第二试T5原答/护栏候选伤害', [option(270264, k)['damage_dealt'] for k in ['plan4', 'plan6']], [43, 25])
check('8JRE 第二试T5观察端点', [player(276256)['current_hp'] - player(276259)['current_hp'], enemy(276256, 'THE_INSATIABLE')['current_hp'] - enemy(276259, 'THE_INSATIABLE')['current_hp']], [4, 25])
sandworm = [e['row'] for e in streams['sl-attempts'] if e['run_id'] == '8JRE1C4H4Z2W' and e['row']['floor'] == 33]
check('8JRE 沙虫六试结局分口径', [s['result'] for s in sandworm], ['predicted_death'] * 5 + ['died'])

check('CA5 F13无虚弱喷水与独立增力',
      [[power(enemy(n, 'SEWER_CLAM'), 'STRENGTH_POWER'), attack(n, 'SEWER_CLAM')] for n in [273237, 273252, 273263]], [[0, 11], [4, 15], [8, 19]])
check('CA5 F13T5虚弱未取消8力量', [power(enemy(273268, 'SEWER_CLAM'), 'STRENGTH_POWER'), attack(273268, 'SEWER_CLAM')], [8, 14])
check('CA5 F13T5现场血/挡/完整需损', [player(273268)['current_hp'], player(273268)['block'], attack(273268, 'SEWER_CLAM') - player(273268)['block']], [2, 10, 4])

check('5PM F33已建立三项能力', [power(player(274202), k) for k in ['NOXIOUS_FUMES_POWER', 'ACCELERANT_POWER', 'SERPENT_FORM_POWER']], [3, 1, 4])
check('5PM F39第二试T2空打冒泡支付/毒/HP',
      [[player(n)['energy'], power(enemy(n, 'THE_LOST'), 'POISON_POWER'), enemy(n, 'THE_LOST')['current_hp']] for n in [274379, 274380]], [[5, 0, 35], [4, 0, 35]])
check('5PM F39空打动作身份', decision(268455)['expect']['card']['id'], 'BUBBLE_BUBBLE')
check('5PM F39空打前未建立毒雾', power(player(274379), 'NOXIOUS_FUMES_POWER'), 0)

check('61E F17吸取前后玩家力敏/敌力',
      [[power(player(n), 'STRENGTH_POWER'), power(player(n), 'DEXTERITY_POWER'), power(enemy(n, 'LAGAVULIN_MATRIARCH'), 'STRENGTH_POWER')] for n in [273503, 273504]], [[2, 0, 0], [0, -2, 2]])
check('61E F17负敏捷双防御累计挡', [player(n)['block'] for n in [273504, 273505, 273507]], [0, 3, 6])
check('61E F17毒继续实扣33', [enemy(273507, 'LAGAVULIN_MATRIARCH')['current_hp'] - enemy(273508, 'LAGAVULIN_MATRIARCH')['current_hp'], power(enemy(273508, 'LAGAVULIN_MATRIARCH'), 'POISON_POWER')], [33, 15])
check('61E F23召唤与成长逐实体',
      [[len(combat(n)['enemies']), power(enemy(n, 'THE_OBSCURA'), 'STRENGTH_POWER')] for n in [273577, 273583, 273589, 273596]], [[1, 0], [2, 0], [2, 3], [2, 6]])
check('61E F23T4主体线观察净伤/净损及幻象残血',
      [sum(e['current_hp'] for e in combat(273593)['enemies']) - sum(e['current_hp'] for e in combat(273596)['enemies']), player(273593)['current_hp'] - player(273596)['current_hp'], enemy(273596, 'PARAFRIGHT')['current_hp']], [47, 15, 2])
check('61E F23未选focus候选', [option(267696, 'plan1')[k] for k in ['damage_dealt', 'hp_lost']], [39, 0])

check('DU F30末试睡层消退', [power(enemy(n, 'SLUMBERING_BEETLE'), 'SLUMBER_POWER') for n in [274998, 275003, 275007]], [2, 1, 0])
check('DU F30末试成长与尖啸到期',
      [[power(enemy(n, 'SLUMBERING_BEETLE'), 'STRENGTH_POWER'), attack(n, 'SLUMBERING_BEETLE')] for n in [275007, 275013, 275016, 275018]], [[0, 18], [2, 20], [-4, 14], [4, 22]])
beetle = [e['row'] for e in streams['sl-attempts'] if e['run_id'] == 'DUZUBAJ3A8GP' and e['row']['floor'] == 30]
check('DU F30四试结局分口径', [s['result'] for s in beetle], ['predicted_death'] * 3 + ['died'])

summary = {'记录总数': sum(len(v) for v in streams.values()), '逐行原字节已核验': True,
           '流': manifests, '材料断言数': len(checks), '断言': checks,
           '限制': ['这是固定原日志材料核验，不是生产源码测试、完整候选执行认证或独立因果验证。',
                    'fight-plans零行只表示本次截点未选到，不推断其他截点或所有日志均无记录。']}
(OUT / 'material-verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
selected = {'states': [S[n] for n in sorted(used_s)], 'decisions': [D[n] for n in sorted(used_d)]}
(OUT / 'verified-key-frames.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'records': summary['记录总数'], 'material_checks': len(checks), 'states': len(used_s), 'decisions': len(used_d)}, ensure_ascii=False))

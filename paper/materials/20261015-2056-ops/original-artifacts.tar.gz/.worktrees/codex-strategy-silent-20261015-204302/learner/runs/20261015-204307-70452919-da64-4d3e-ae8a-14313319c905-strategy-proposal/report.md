# 20261015-204302 静默策略学习回报

本批完成十项已领取提案的证据与源码复核，十项均waiting；没有新的源码、经验库或行为规则修改，没有提交、合入或版本发布。现有窄功能不能证明原宽提案已完成，具体补证条件见proposal.md和proposal-results.json。

## 身份和基线

- batch：20261015-204302-strategy-proposal；task=strategy-proposal；character=silent；reason=proposal。
- 开工git status --short为空，HEAD=cd6be6ac456b731612522a7e044ee1e2b7763819；git merge --no-edit main返回Already up to date。没有research_request或implementation_request，不适用纯研究或冻结实现任务。普通专题根请求绑定另一20261010批次，本批不承接、不替换选题。
- 仅消费dispatch.json十个proposal_ids；十份原Markdown存在且SHA全等，原字节副本与proposal-source-manifest.json已保存；队列add及update逐行offset/bytes/SHA见queue-events.json。没有领取其他id，没有重写复盘、原提案或队列。
- runs.jsonl和所选states确认六局均SILENT/A10；原run-config的code均为dirty历史标记，不能由其短SHA还原整棵当时源码。历史brain设置和当前学习者配置分列；本批未读取原生学习者会话模型/强度，未声称已经切换运行设置，也未修改任何模型或权限配置。

## 证据提取与核验

执行任务指定extract_evidence.py默认六流，并单独用同入口提取runs流到evidence-runs/。共6,995行：states3432、decisions3306、sl-attempts29、run-config6、run-plans33、brain183、runs6。来源字节截点、逐局计数、无效JSON行数及输出SHA在两个evidence-manifest.json；不是用正文提及判所属局。

audit_evidence.py逐行seek原日志offset，核原bytes/SHA/JSON和统一run_identity，拒绝身份冲突；核输出整体SHA、计数和截点，全部通过。原流states/decisions各2个、brain1个无效JSON保持，不修原日志、不把它们算作有效局证据。run-plans按run字段成功选出33行，没有根据旧截点零行断言缺日志。

state-projections.json保存本批目标房间的状态投影，decision-facts.json保存八个指定询问，sl-facts.json分列判死/实死/胜及尝试号。check_materials.py的55项原帧事实校验通过；这是材料校验，不是tsc/vitest、源码负控或策略收益测试。

## 核实的事实和反例

1. VLZ F35 T1神化实际耗2能，防御5→8、打击7→10、匕首雨逐击5→7、工具1→0；F43 T1同后续牌序预测43伤/14损→51伤/13损，实际当轮净扣51、净损13，场外升级数仍4。F45持有但未施放，不能记成已兑现。神化传播局部已存在；未知组合、实际施放持续身份和后置消费者仍未闭合。
2. VLZ F45首问MC707ms/1样本，后续推演horizon1/samples1/best=null；重问MC11ms/12样本、5轮3样本，但指纹不同。不能将两个不同盘面当预算配对。T4三个攻击focus候选31损/32伤明确并列，实际较少损线13损/24伤；未实打的候选不补整战胜负。T5原83攻击经四段减力成59，20挡/32血完整需损39、至少缺7血，三敌仍活；净HP/死亡截顶不当毛伤。
3. 8JRE F33首/三试T2指纹相同，原帧实损3/15、敌净扣10/17，即多12血价只多7当轮伤。原答候选0/24与SL替换5/24是推演死亡数，不是相同死率；均封顶预期损血也不证明同死率。末试延至T11仍实死，前五次是predicted_death；防御有延长观察，但无受控整战胜例，既不规定一律保血，也不一概否定成长牌。
4. CA5 F13力量0/4/8、喷水11/15/19；末弱后14、10挡/2血完整需损4。本战没有正敏捷，不能借单场关闭力量/敏捷/弱/成长复合条目。
5. 5PM F39末试T2无毒目标上冒泡耗1能、敌状态未变、未建毒雾；decisions268455原动作completed、原手牌移除BUBBLE_BUBBLE的回读另存bubble-action-readback.json。F33已有雾3/触媒1/群蛇4的胜场与此敌人、抽序、资源不同，不是启动顺序的受控对照。
6. 61E F17首试七轮胜，T6负2敏捷下双防御各3，毒净扣33是分项事实；不支持扩大SL范围。F23航行后两实体增力，幻象T4末仍2血、T5轮初还在；旧召唤接线不等成长/复现/退场全链已校准，不能指定固定首杀。
7. DUZ F30睡3/2/1后醒，醒后力量0/2/4、同招18/20/22；四试前三判死、末次实死，同局尝试不扩独立样本，不能拟合全败血价或另顺序必胜。

所有发现帧均已用于分析，不能当独立盲测。没有新增游戏结论与旧知识冲突；上述限制与原提案一致，没有另造反证通知，也不声称Roy或消费者已读。

## 实际live源码核对

核对时live=fe6462651b593b9831581c088deface9957a404f。source-comparison.json记录14个相关源码叶的两侧SHA，11叶相同；card-model.ts、rollout-live.ts、move-model.ts三叶仅既有Roy/Dai注释文字差，完整差存live-source-comment-diff.patch，不覆盖它们。没有读取其他角色专属知识或夹具，通用源码内的非本角色注释不作为本角色结论。

existing-source-ancestors.json核实六个窄源码是上述live实际祖先：

- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：神化候选事实，actual_cast_this_fight=null。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：候选阶段/护栏审计，actual_turn=null。
- bade647f9fe4c9103b40e2f26b26296692ad24b7：单动作派发回执，whole_plan_executed/actual_turn=null。
- 1e076b173c6874cef4bf90fd13cd3eb33355827a：活体召唤接线。
- b2805be4ba44b7375c7908d873889372cc3cfe6c：已见神化萎靡升级。
- ba23ca693151fa8c6f7fe035e640dc30f05ccd75：已见神化致命毒药升级。

以上只证明所列窄源码的部署祖先，不把它们登记成本批实现/整项duplicate，也不把null填成false或已验证。当前solver仍保留弱/脆弱/暗影等组合的unknown，并未声称完整游戏模型正确。

## 逐项处置

- silent-proposal-89354805ee4d7e77：waiting。账本silent-0237、silent-0238。已核F35/F43普通神化升级，但当前actual_cast_this_fight仍null；六旧局缺跨抽牌、选择、药水和SL重规划的持续施放身份、未知升级组合及后置消费者校准，不能把已live窄传播算整项完成。
- silent-proposal-f2bfceddb1898dca：waiting。账本silent-0106、silent-0019、silent-0201。F45首问MC707ms/1样本，重问11ms/12样本，但两题指纹不同且首题神化未建模；缺同盘同随机池同总预算的分阶段MC配对及稳定性曲线，不改预算、血价或留药价。
- silent-proposal-283a164780d11e69：waiting。账本silent-0237、silent-0238。与89354805共享神化事实但来源任务/经验链接独立；普通升级已有局部实现，仍缺完整本战施放追踪、未覆盖升级交互与后置消费者验证，不按标题相近标整项duplicate。
- silent-proposal-ebbfe3b97548756d：waiting。账本silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。十五条经验的当轮属性、毒和资源事实可核，缺各自组合/期限、路线与休息消费者的联合校准；F43高血胜仍净损57、F44回血后F45仍败，不能拟合统一血线或整战组件收益。
- silent-proposal-e5b87be50f28f311：waiting。账本silent-0079、silent-0021、silent-0125、silent-0018。F33首/三试T2同指纹确证多损12仅多扣7；现有源码只记候选阶段与单动作回执，actual_turn/whole_plan_executed仍null。旧日志缺跨重规划持续候选身份和成长分源，不能认证完整审计或改HP护栏/SL。
- silent-proposal-49632bc4878fb597：waiting。账本silent-0005、silent-0231。CA5 F13可核力量0/4/8、喷水11/15/19及末轮弱后14，但本战没有正敏捷帧；缺力量、正负敏捷、虚弱及独立成长四路径冻结联合调用校准，单公式不闭合复合经验。
- silent-proposal-66532328a585941f：waiting。账本silent-0021、silent-0009。5PM F39末试T2冒泡耗1能而目标无毒、敌状态未变；F33胜局已建雾3/触媒1/群蛇4但敌人、牌序与资源不同。缺同起点完整抽序下启动顺序的整战配对与收益函数，不设启动阈值。
- silent-proposal-43a76a31ba7bdcfa：waiting。账本silent-0030、silent-0027。61E F17首试七轮胜，T6负2敏双防御各3、毒净扣33仅支持分项；缺同起始血量/构筑/完整抽序的另一可核SL整战后继，不据首试胜扩大SL范围或指定换线。
- silent-proposal-5264153a4a4b0e5c：waiting。账本silent-0039、silent-0209。61E F23召唤与两实体增力0/3/6、T4末幻象余2已核，旧召唤源码是live祖先；仍缺A10召唤/复现/退场/成长全链校准及另一focus整战后继，不制定固定首杀。
- silent-proposal-bddfa690a84e03d0：waiting。账本silent-0128、silent-0079。DUZ F30睡3/2/1、醒后力0/2/4及同招18/20/22可核；四试是前三predicted_death、末试实死。缺失血唤醒/眩晕/恢复成长全链与同抽不同排序整战后继，不由四试拟合全败血价或杀序。

## 记录、验证和上线口径

26条原账本记录只经根目录learner/ledger.py update追加本批where.proposal/note追溯，CLI退出0且保护字段逐项同验，不新增claim/evidence或重计支持，不改first_run/prior/status/version；既有shipped窄经验不降级proposed，也不把宽提案标shipped。具体CLI输入、输出、追加字节与保护字段核验另存同目录。

没有生产源码变化，tsc/vitest/cases均null；撤源码失败/恢复通过不适用，未运行沙箱测试、LLM或网络。没有代码提交，因此不制造gitleaks提交扫描通过或提交Co-Author；没有live合入、eval版本或decision-log上线行，不触发发布双通知。本工作树的受跟踪源码/知识/记录保持零差异，最终HEAD、git status及二进制diff检查另存final-integrity.json。

过程中的错误路径/输出截断/过界blame行号只是只读定位问题，记录在process-notes.md；未据此判断产品失败，未改生产行为。原始证据及所有材料保留。最终机器回报在result.json；运维可据本批十项proposal_results保留waiting并等新增本角色证据，不关闭原学习父要求。

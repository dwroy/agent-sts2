# 本批十项静默策略提案复核

本文件仅处理20261015-204302-strategy-proposal已领取的十个原id；不创建重复id、不改原提案。均为waiting，以下逐项给出本次核实的证据、账本与限制。

授权Roy-2026-10-07-learning不构成游戏事实。已实现的局部传播/审计继续保留，未观察的组合及长期收益不补预训练结论。完整证据、源对照与验收见同目录report.md、evidence/和material-checks.json。

## silent-proposal-89354805ee4d7e77

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md。原文SHA：ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d。

账本：silent-0237、silent-0238。证据：VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1；states 275564–275565、275679–275687；decisions 269706/269707/269748。

原目标：按静默已观测帧补齐神化在同线及后续抽牌中的升级传播，并区分持有、施放与模型覆盖；无整场转胜保证。

处置与缺数据：已核F35/F43普通神化升级，但当前actual_cast_this_fight仍null；六旧局缺跨抽牌、选择、药水和SL重规划的持续施放身份、未知升级组合及后置消费者校准，不能把已live窄传播算整项完成。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-f2bfceddb1898dca

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md。原文SHA：fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26。

账本：silent-0106、silent-0019、silent-0201。证据：VLZ6CCT8AQ0A A10 F45 T1/T4/T5；decisions 269748/269754/269770；states 275748–275754。

原目标：核验三骑士全败候选的即时血价、击杀缺口与药水MC预算成熟度；先做同盘预算实验，缺对照时保留原护栏、留药与目标规则。

处置与缺数据：F45首问MC707ms/1样本，重问11ms/12样本，但两题指纹不同且首题神化未建模；缺同盘同随机池同总预算的分阶段MC配对及稳定性曲线，不改预算、血价或留药价。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-283a164780d11e69

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md。原文SHA：78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637。

账本：silent-0237、silent-0238。证据：VLZ6CCT8AQ0A A10 F35 T1、F43 T1/T2、F45 T1；同89354805；原experience来源与Markdown独立保留。

原目标：神化已观察升级进入同方案与后续抽牌，保留未知边界，不定必打规则

处置与缺数据：与89354805共享神化事实但来源任务/经验链接独立；普通升级已有局部实现，仍缺完整本战施放追踪、未覆盖升级交互与后置消费者验证，不按标题相近标整项duplicate。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-ebbfe3b97548756d

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md。原文SHA：08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2。

账本：silent-0005、silent-0016、silent-0049、silent-0071、silent-0143、silent-0046、silent-0053、silent-0027、silent-0011、silent-0021、silent-0106、silent-0204、silent-0020、silent-0019。证据：VLZ6CCT8AQ0A A10 F43 T1–T6、F45 T3–T5；states 275679–275706、275738–275754。

原目标：逐源验证当前攻防、毒触发与持续资源，不从持有或单轮减力预支整场收益

处置与缺数据：十五条经验的当轮属性、毒和资源事实可核，缺各自组合/期限、路线与休息消费者的联合校准；F43高血胜仍净损57、F44回血后F45仍败，不能拟合统一血线或整战组件收益。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-e5b87be50f28f311

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md。原文SHA：5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709。

账本：silent-0079、silent-0021、silent-0125、silent-0018。证据：8JRE1C4H4Z2W A10 F33 首/三试T2、二试T5、末试T11；decisions 270216/270282/270264；states 276208/276212/276274/276278；sl-attempts 921–926。

原目标：静默A10同盘SL以12血换7伤重犯：补齐Jev原答、HP护栏、SL换线及重规划的候选代价与实际成长兑现审计；单局不足以改阈值，保留现行为并独立验证。

处置与缺数据：F33首/三试T2同指纹确证多损12仅多扣7；现有源码只记候选阶段与单动作回执，actual_turn/whole_plan_executed仍null。旧日志缺跨重规划持续候选身份和成长分源，不能认证完整审计或改HP护栏/SL。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-49632bc4878fb597

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md。原文SHA：aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2。

账本：silent-0005、silent-0231。证据：CA5KE8GFJ9X2 A10 F13 T1/T3/T5；states 273237/273252/273263–273268。

原目标：把当前属性、每击修正、弱与成长分项验证，不增加统一保血或输出权重。

处置与缺数据：CA5 F13可核力量0/4/8、喷水11/15/19及末轮弱后14，但本战没有正敏捷帧；缺力量、正负敏捷、虚弱及独立成长四路径冻结联合调用校准，单公式不闭合复合经验。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-66532328a585941f

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md。原文SHA：56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831。

账本：silent-0021、silent-0009。证据：5PM6JAQG6FNQ A10 F33 T2、F39 末试T2；states 274202、274379–274380；sl-attempts 910–911。

原目标：持有/计划/已建立分账；如提构筑或启动权重，先做实盘兑现与受控整场验证。

处置与缺数据：5PM F39末试T2冒泡耗1能而目标无毒、敌状态未变；F33胜局已建雾3/触媒1/群蛇4但敌人、牌序与资源不同。缺同起点完整抽序下启动顺序的整战配对与收益函数，不设启动阈值。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-43a76a31ba7bdcfa

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md。原文SHA：f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c。

账本：silent-0030、silent-0027。证据：61E2QS63Y9WU A10 F17 T5/T6/T7；states 273502–273508；sl-attempts 898。

原目标：冻结吸取、负敏捷与毒的分项事实；任何SL范围或换线偏好需完整同盘验证。

处置与缺数据：61E F17首试七轮胜，T6负2敏双防御各3、毒净扣33仅支持分项；缺同起始血量/构筑/完整抽序的另一可核SL整战后继，不据首试胜扩大SL范围或指定换线。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-5264153a4a4b0e5c

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md。原文SHA：b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02。

账本：silent-0039、silent-0209。证据：61E2QS63Y9WU A10 F23 T1–T5；states 273577/273583/273589/273593–273596。

原目标：复验已有召唤和各实体成长；保留所有目标选项，相同推演值并列，不强制首杀。

处置与缺数据：61E F23召唤与两实体增力0/3/6、T4末幻象余2已核，旧召唤源码是live祖先；仍缺A10召唤/复现/退场/成长全链校准及另一focus整战后继，不制定固定首杀。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

## silent-proposal-bddfa690a84e03d0

原提案：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md。原文SHA：b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780。

账本：silent-0128、silent-0079。证据：DUZUBAJ3A8GP A10 F30 T1–T6；states 274906/274914/274919/274923/274929/274934；sl-attempts 914–917。

原目标：按当前进阶、睡眠/眩晕/成长分别验证；不把未知换线胜率或固定杀序写成规则。

处置与缺数据：DUZ F30睡3/2/1、醒后力0/2/4及同招18/20/22可核；四试是前三predicted_death、末试实死。缺失血唤醒/眩晕/恢复成长全链与同抽不同排序整战后继，不由四试拟合全败血价或杀序。

现状与预期：保留当前合法选项、模型参考和未知标记，本批不改变选择规则。验证条件：补足上列冻结输入及缺失后继后，逐步核对状态/期限/实际消费者；若改变源码，须固定夹具撤源码失败、恢复通过及原沙箱检查，实际合live后才能报告实现。现有发现帧不能当时间后置盲测，同局重试不增加独立样本。回退：本批无源码可回退，原提案、证据和账本历史保留。

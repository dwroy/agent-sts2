import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {s["line"]: s for s in json.loads((OUT / "state-projections.json").read_text())}
decisions = {d["line"]: d for d in json.loads((OUT / "decision-facts.json").read_text())}
attempts = json.loads((OUT / "sl-facts.json").read_text())
checks = []


def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected})


def hand(line, ident):
    return next(c for c in states[line]["hand"] if c["card_id"] == ident)


def value(line, ident, name):
    return next(v["current_value"] for v in hand(line, ident)["dynamic_values"] if v["name"] == name)


def enemy(line, ident):
    return next(e for e in states[line]["enemies"] if e["id"] == ident)


check("F35神化实际耗能", states[275564]["energy"] - states[275565]["energy"], 2)
for ident, field, pair in [("DEFEND_SILENT", "Block", [5, 8]), ("STRIKE_SILENT", "Damage", [7, 10]),
                           ("DAGGER_SPRAY", "Damage", [5, 7])]:
    check("F35升级" + ident, [value(n, ident, field) for n in [275564, 275565]], pair)
check("F35必备工具费用", [hand(n, "TOOLS_OF_THE_TRADE")["energy_cost"] for n in [275564, 275565]], [1, 0])
check("F35场外升级不变", [states[n]["deck_upgraded"] for n in [275564, 275565]], [1, 1])
check("F43突然一拳伤害", [value(n, "SUCKER_PUNCH", "Damage") for n in [275679, 275680]], [9, 11])
check("F43突然一拳虚弱", [value(n, "SUCKER_PUNCH", "WeakPower") for n in [275679, 275680]], [1, 2])
check("F43勒紧升级", [value(n, "FASTEN", "ExtraBlock") for n in [275679, 275680]], [4, 6])
check("F43尖啸升级", [value(n, "PIERCING_WAIL", "StrengthLoss") for n in [275679, 275680]], [6, 8])
check("F43重问预测增伤", decisions[269707]["options"]["plan1"]["damage_dealt"] - decisions[269706]["options"]["plan1"]["damage_dealt"], 8)
check("F43重问预测少损", decisions[269706]["options"]["plan1"]["hp_lost"] - decisions[269707]["options"]["plan1"]["hp_lost"], 1)
check("F43当轮实际净扣", states[275679]["enemies"][0]["hp"] - states[275687]["enemies"][0]["hp"], 51)
check("F43当轮实际净损", states[275679]["hp"] - states[275687]["hp"], 13)
check("F43后抽毒雾升级", hand(275687, "NOXIOUS_FUMES")["upgraded"], True)
check("F43场外升级数", states[275687]["deck_upgraded"], 4)
check("F45首问MC样本", decisions[269748]["potions"]["random"][0]["samples"], 1)
check("F45首问MC占时", decisions[269748]["potions"]["random"][0]["ms"], 707)
check("F45首问推演范围", [decisions[269748]["rollout"][k] for k in ["horizon", "samples", "best"]], [1, 1, None])
check("F45重问MC样本", decisions[269754]["potions"]["random"][0]["samples"], 12)
check("F45两问盘面不同", decisions[269748]["fingerprint"] != decisions[269754]["fingerprint"], True)
check("F45三攻击线并列", decisions[269770]["rollout"]["tied"], ["plan2", "plan3", "plan4"])
check("F45攻击线代价", [decisions[269770]["options"]["plan2"][k] for k in ["hp_lost", "damage_dealt"]], [31, 32])
check("F45较少损线代价", [decisions[269770]["options"]["plan1"][k] for k in ["hp_lost", "damage_dealt"]], [13, 24])
check("F45末轮原来袭", sum(sum(e["attacks"]) for e in states[275748]["enemies"]), 83)
check("F45末轮减力后来袭", sum(sum(e["attacks"]) for e in states[275754]["enemies"]), 59)
check("F45末轮完整需损", 59 - states[275754]["block"], 39)
check("F45末轮生存量缺口", 39 - states[275754]["hp"], 7)
check("F45末轮没有覆甲", states[275754]["player_powers"].get("PLATING_POWER", 0), 0)
check("F45末轮三敌仍活", all(e["hp"] > 0 for e in states[275754]["enemies"]), True)
check("CA5力量成长", [enemy(n, "SEWER_CLAM")["powers"].get("STRENGTH_POWER", 0) for n in [273237, 273252, 273263]], [0, 4, 8])
check("CA5同招威胁", [enemy(n, "SEWER_CLAM")["attacks"][0] for n in [273237, 273252, 273263]], [11, 15, 19])
check("CA5末轮虚弱", enemy(273268, "SEWER_CLAM")["attacks"], [14])
check("CA5末轮完整需损", 14 - states[273268]["block"], 4)
check("CA5本战无正敏捷证据", any(s["run_id"] == "CA5KE8GFJ9X2" and s["floor"] == 13 and s["player_powers"].get("DEXTERITY_POWER", 0) > 0 for s in states.values()), False)
check("5PM末试冒泡花一能", states[274379]["energy"] - states[274380]["energy"], 1)
check("5PM末试冒泡后敌状态未变", states[274379]["enemies"], states[274380]["enemies"])
check("5PM末试没有毒雾", states[274380]["player_powers"].get("NOXIOUS_FUMES_POWER", 0), 0)
check("5PM胜场已有组件", [states[274202]["player_powers"][k] for k in ["NOXIOUS_FUMES_POWER", "ACCELERANT_POWER", "SERPENT_FORM_POWER"]], [3, 1, 4])
check("61E吸取后负敏捷", states[273504]["player_powers"]["DEXTERITY_POWER"], -2)
check("61E双防御各三挡", [states[273505]["block"], states[273507]["block"] - states[273506]["block"]], [3, 3])
check("61E毒结算净扣", enemy(273507, "LAGAVULIN_MATRIARCH")["hp"] - enemy(273508, "LAGAVULIN_MATRIARCH")["hp"], 33)
check("61E族母首试获胜", [(a["attempt"], a["result"], a["turns"]) for a in attempts if a["run_id"] == "61E2QS63Y9WU" and a["floor"] == 17], [(1, "won", 7)])
check("61E幻象T4末仍活", enemy(273595, "PARAFRIGHT")["hp"], 2)
check("61E航行后幻象增力", [enemy(n, "PARAFRIGHT")["powers"].get("STRENGTH_POWER", 0) for n in [273583, 273589, 273596]], [0, 3, 6])
check("DUZ睡层逐轮下降", [enemy(n, "SLUMBERING_BEETLE")["powers"]["SLUMBER_POWER"] for n in [274906, 274914, 274919]], [3, 2, 1])
check("DUZ醒后增长", [enemy(n, "SLUMBERING_BEETLE")["powers"].get("STRENGTH_POWER", 0) for n in [274923, 274929, 274934]], [0, 2, 4])
check("DUZ同招威胁", [enemy(n, "SLUMBERING_BEETLE")["attacks"][0] for n in [274923, 274929, 274934]], [18, 20, 22])
check("DUZ前三判死末试实死", [a["result"] for a in attempts if a["run_id"] == "DUZUBAJ3A8GP" and a["floor"] == 30], ["predicted_death"] * 3 + ["died"])
check("8JRE首三试T2同指纹", decisions[270216]["fingerprint"], decisions[270282]["fingerprint"])
check("8JRE首试T2实损", states[276208]["hp"] - states[276212]["hp"], 3)
check("8JRE三试T2实损", states[276274]["hp"] - states[276278]["hp"], 15)
check("8JRE首试T2净扣", states[276208]["enemies"][0]["hp"] - states[276212]["enemies"][0]["hp"], 10)
check("8JRE三试T2净扣", states[276274]["enemies"][0]["hp"] - states[276278]["enemies"][0]["hp"], 17)
check("8JRE六试结果分列", [a["result"] for a in attempts if a["run_id"] == "8JRE1C4H4Z2W" and a["floor"] == 33], ["predicted_death"] * 5 + ["died"])

(OUT / "material-checks.json").write_text(json.dumps({"scope": "只验证冻结实盘材料，不是生产源码测试或撤源码负控", "checks": checks}, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"material_checks": len(checks), "passed": True}, ensure_ascii=False))

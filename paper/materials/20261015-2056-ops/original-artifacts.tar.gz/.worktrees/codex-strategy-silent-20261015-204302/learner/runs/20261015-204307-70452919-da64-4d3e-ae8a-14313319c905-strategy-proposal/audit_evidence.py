import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", ROOT / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / "dispatch.json").read_text())
runs = set(dispatch["runs"])
targets = {
    "VLZ6CCT8AQ0A": {35, 36, 37, 43, 45},
    "8JRE1C4H4Z2W": {17, 33},
    "CA5KE8GFJ9X2": {13},
    "5PM6JAQG6FNQ": {33, 39},
    "61E2QS63Y9WU": {17, 23},
    "DUZUBAJ3A8GP": {30},
}


def powers(holder):
    return {p["power_id"]: p.get("amount") for p in holder.get("powers", [])}


def card(c):
    return {k: c.get(k) for k in ["index", "card_id", "upgraded", "energy_cost", "resolved_rules_text", "dynamic_values"]}


def project(q):
    s = q["row"]["state"]
    combat = s.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "run_id": q["run_id"], "line": q["line"], "offset": q["offset"], "sha256": q["sha256"],
        "observed_ts": q["row"].get("observed_ts"), "floor": s.get("run", {}).get("floor"),
        "turn": s.get("turn"), "screen": s.get("screen"), "in_combat": s.get("in_combat"),
        "readiness": combat.get("action_readiness"),
        "hp": player.get("current_hp"), "block": player.get("block"), "energy": player.get("energy"),
        "player_powers": powers(player), "hand": [card(c) for c in combat.get("hand", [])],
        "deck_upgraded": sum(bool(c.get("upgraded")) for c in s.get("run", {}).get("deck", [])),
        "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"), "hp": e.get("current_hp"),
                     "block": e.get("block"), "alive": e.get("is_alive"), "move": e.get("move_id"),
                     "powers": powers(e), "attacks": [i.get("total_damage") for i in e.get("intents", [])
                                                       if i.get("intent_type") == "Attack"]}
                    for e in combat.get("enemies", [])],
    }


streams = []
projections = []
decision_facts = []
sl = []
configs = []
selected_decisions = {269706, 269707, 269748, 269754, 269770, 270216, 270282, 270264}
for manifest_name, folder in [("evidence-manifest.json", "evidence"), ("evidence-manifest.json", "evidence-runs")]:
    for m in json.loads((OUT / folder / manifest_name).read_text()):
        counts = Counter()
        output = OUT / folder / (m["stream"] + ".evidence.jsonl")
        digest = hashlib.sha256()
        with output.open("rb") as f, (Path("/home/dw/Projects/agent-sts2/logs") / (m["stream"] + ".jsonl")).open("rb") as raw:
            for line in f:
                digest.update(line)
                q = json.loads(line)
                assert q["run_id"] in runs
                raw.seek(q["offset"])
                source_line = raw.read(q["bytes"])
                assert hashlib.sha256(source_line).hexdigest() == q["sha256"]
                assert json.loads(source_line) == q["row"]
                assert extractor.run_identity(q["row"]) == q["run_id"]
                assert q["offset"] + q["bytes"] <= m["source_size"]
                counts[q["run_id"]] += 1
                row = q["row"]
                if m["stream"] == "runs":
                    assert row["character"] == "SILENT" and row["ascension"] == 10
                if m["stream"] == "states":
                    state = row["state"]
                    assert state["run"]["character_id"] == "SILENT" and state["run"]["ascension"] == 10
                    if state["run"].get("floor") in targets[q["run_id"]]:
                        projections.append(project(q))
                if m["stream"] == "decisions" and q["line"] in selected_decisions:
                    opts = row.get("questions", {}).get("plan", {}).get("criteria", {})
                    decision_facts.append({"line": q["line"], "run_id": q["run_id"], "floor": row.get("floor"),
                        "turn": row.get("turn"), "attempt": row.get("sl_attempt"), "fingerprint": row.get("fingerprint"),
                        "options": {k: json.loads(v) if isinstance(v, str) else v for k, v in opts.items()},
                        **{k: row.get(k) for k in ["chosen", "answers", "rollout", "potions", "timing", "sl_explore", "sl_retry", "jev_hints"]}})
                if m["stream"] == "sl-attempts":
                    sl.append({"line": q["line"], **{k: row.get(k) for k in ["run_id", "floor", "attempt", "result", "turns", "end_hp", "incoming", "from", "started_at", "ended_at"]}})
                if m["stream"] == "run-config":
                    configs.append({"line": q["line"], **{k: row.get(k) for k in ["run_id", "character", "ascension", "code", "brain"]}})
        assert digest.hexdigest() == m["output_sha256"]
        assert all(counts[run] == n for run, n in m["counts"].items())
        streams.append({"stream": m["stream"], "rows": sum(counts.values()), "counts": dict(counts),
                        "source_size": m["source_size"], "invalid_lines": m["invalid_lines"], "verified": True})

for filename, data in [("state-projections.json", projections), ("decision-facts.json", decision_facts),
                       ("sl-facts.json", sl), ("run-config-facts.json", configs), ("byte-verification.json", streams)]:
    (OUT / filename).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_rows": sum(s["rows"] for s in streams), "streams": streams,
                  "projected_states": len(projections), "selected_decisions": len(decision_facts)}, ensure_ascii=False))

from pathlib import Path
p=Path('ops/codex-ops/record-staging/20261015-2056')
old=Path('ops/codex-ops/record-staging/20261015-2026/prepare-records.py').read_text().replace('20261015-2026','20261015-2056').replace('20261015-201302-s2-strategy-proposal','20261015-204302-strategy-proposal')
a=old.index('final=');z=old.index('inputs=')
old=old[:a]+'''final=load(s/'final-integrity.json');assert final['base']==final['head']==report['base'] and final['clean'] and final['status_porcelain']=='' and final['diff_bytes']==final['staged_diff_bytes']==0 and final['proposal_results']==10 and final['ledger_updates']==26
assert (s/'baseline.diff.patch').read_bytes()==(s/'final.diff.patch').read_bytes()==b''
manifest=load(s/'delivery-manifest.json')
for x in manifest:
 raw=(s/x['file']).read_bytes();assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],x['file']
markdown=load(s/'proposal-source-manifest.json');assert len(markdown)==10
for x in markdown:assert x['exists'] and sha((s/(x['id']+'.original.md')).read_bytes())==x['sha256']==x['expected']
evidence=load(s/'byte-verification.json');assert len(evidence)==7 and sum(x['rows'] for x in evidence)==6995 and all(x['verified'] and sum(x['counts'].values())==x['rows'] for x in evidence)
assert len(evidence[0]['counts'])==6
materials=load(s/'material-checks.json');assert len(materials['checks'])==55 and all(x['actual']==x['expected'] for x in materials['checks'])
source=load(s/'source-comparison.json');assert len(source['files'])==14;equal=0
for x in source['files']:
 a=git('show',report['base']+':'+x['path']);z=git('show',source['live']+':'+x['path']);assert sha(a)==x['local_sha256'] and sha(z)==x['live_sha256']
 if a==z:equal+=1
 else:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert equal==11
ancestors=load(s/'existing-source-ancestors.json');assert ancestors['live']==source['live'] and len(ancestors['sources'])==6
for x in ancestors['sources']:
 assert x['live_ancestor']
 for target in [report['base'],source['live']]:git('merge-base','--is-ancestor',x['commit'],target)
''' +old[z:]
a=old.index('inputs=');z=old.index("(p/'owned-ledger.jsonl')")
old=old[:a]+'''inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];owned=[];owned_refs=[];offset=0
for number,raw in enumerate((r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True),1):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs):owned.append(raw);owned_refs.append({'id':row['id'],'line':number,'offset':offset,'bytes':len(raw),'sha256':sha(raw)})
 offset+=len(raw)
assert len(inputs)==len(owned)==26 and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
receipt=load(s/'ledger-cli-receipt.json');assert receipt['exit_code']==0 and len(receipt['rows'])==26 and receipt['protected_fields_unchanged']
for x in receipt['rows']:
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as f:f.seek(x['offset']);raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and raw in owned
ids=(s/'ledger-cli.stdout.txt').read_text().split();assert len(ids)==26 and set(ids)==set(receipt['ids'])=={json.loads(x)['id'] for x in owned}
''' +old[z:]
old=old.replace("assert load(s/'gitleaks.json')==[] and (s/'gitleaks.exit').read_text().strip()=='0'",'')
a=old.index("write(pub/'batch-readback.json'");z=old.index('files=',a)
old=old[:a]+'''write(pub/'batch-readback.json',{'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_final_verification':final,'original_manifest_entries_verified':len(manifest),'ten_original_proposal_sha_verified':True,'source14_base_and_old_live_sha_and_six_narrow_ancestors_verified':True,'source11_equal3_historical_name_comments_preserved':True,'original_evidence_rows':6995,'original_material_assertions':55,'material_probes_reexecuted':False,'original_cohort':'Six original Silent A10 runs; repeated SL is not independent data.','owned_trace_only_ledger_rows':26,'owned_ledger_byte_refs':owned_refs,'protected_fold_preserved':True,'original_preparation_failures':'Incorrect source paths, out-of-range blame lines and truncated outputs retained in process-notes; material audit completed once, not a product failure or full-suite result.','native_gap':'Ops verified original Sol6.1/xhigh/input/lease/workspace-write/no-network. Historical run/brain settings and learner original lack of native readback are not rewritten.','limits':['55 material checks are original fixed arithmetic readbacks, not product tests, full candidates or strategy benefit.','F45 first MC707ms/1sample and second11ms/12samples have different fingerprints; subsequent horizon samples are distinct from MC samples. No budget pairing or new threshold follows.','Original SL predicted-death counts0/24 and5/24 differ; capped HP loss does not prove equal death probabilities. Late observed death is not unobserved complete candidate outcome.','actual_cast_this_fight, actual_turn and whole_plan_executed remain unknown; narrow source ancestry does not close wide proposals or learning parents.'],'no_source_tests_merge_release_dataset_or_game_actions':True})
''' +old[z:]
old=old.replace("'.stdout','.stderr','.exit'", "'.stdout','.stderr','.exit','.log'")
old=old.replace("files+=[s/'evidence/evidence-manifest.json']", "files+=[s/'evidence/evidence-manifest.json',s/'evidence-runs/evidence-manifest.json']")
a=old.index('line=f');z=old.index("appends={'paper",a)
old=old[:a]+'''line=f'\\n- {at} 运维codex：2056原204302策略rc0/done/no-source门禁核，十项waiting；cd6b干净WT无新源码提交，testsnull/mergednull/域空，不重合/发号/补测或新派。六Silent A10所属原6995行字节/身份、55材料断言为原学习者读回，默认六流与独立runs流分列，不重跑或当生产测试/完整候选/整战收益；F45首MC707ms/1样本与后11ms/12样本指纹不同，后轮horizon样本另列，不作预算配对；SL推演0/24与5/24不同，不因封顶损血相同冒同死率，前三判死/末试实死分列。14叶旧livefe646265逐SHA与六窄源码main-live祖先核，11同/3历史Roy-Dai注释差保持；神化持续施放及actual_turn/whole_plan_executed仍null，窄实现不关闭宽提案。26原CLI只where/note、逐输入及原offset/bytes/SHA核，claim/首证/prior/evidence/status/version等保护字段不变、不重复CLI。ops补核实际native Sol6.1/xhigh/input/lease与workspace-write/no-network，原历史模型设置与学习者未核native边界不改。原错误源码路径/越界blame与截断输出留史，材料核验一次通过不当撤源码负控或完整套件；无新增知识/反证/源码/复盘，不刷新论文、不改当前局/账号home模型预算队列prompt，原宽父/各owner继续原链、不等待未来事件。证据paper/materials/20261015-2056-ops/。\\n'
note=f'\\n- {at} [ops 策略处置] 原204302十项继续waiting，无源码/合入/版本；26条CLI仅追溯且保护旧知识/状态。原6995行/55材料与路径准备错误均归档；不同盘MC、不同死亡推演数及完整执行未知分列，未重派或补测。回执paper/materials/20261015-2056-ops/。\\n'
''' +old[z:]
old=old.replace("'own_ledger_rows':44", "'own_ledger_rows':26").replace("'owned_ledger_rows':44", "'owned_ledger_rows':26")
old=old.replace("p/'prepare-records.py',p/'seal-records.py',", "p/'prepare-records.py',p/'make-helper.py',p/'seal-records.py',")
(p/'prepare-records.py').write_text(old)
seal=Path('ops/codex-ops/record-staging/20261015-2026/seal-records.py').read_text().replace('20261015-2026','20261015-2056').replace('forty-four trace-only ledger updates','twenty-six trace-only ledger updates').replace('ops: record unchanged 201302-s2 strategy dispositions','ops: record unchanged 204302 strategy dispositions')
(p/'seal-records.py').write_text(seal)

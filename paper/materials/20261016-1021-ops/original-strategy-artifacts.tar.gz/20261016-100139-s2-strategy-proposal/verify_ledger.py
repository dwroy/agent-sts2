import hashlib
import importlib.util
import json
import os
from pathlib import Path

S = Path(__file__).resolve().parent
before = json.loads((S / 'ledger-canonical-before.json').read_text())
ids = set(before)
spec = importlib.util.spec_from_file_location('ledger', '/home/dw/Projects/agent-sts2/learner/ledger.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
oldphysical = json.loads((S / 'ledger-physical-before.json').read_text())
cut = oldphysical['source_size']
rows, new = [], []
offset = 0
with open(m.LEDGER, 'rb') as handle:
    limit = os.fstat(handle.fileno()).st_size
    while offset < limit:
        raw = handle.readline(limit - offset)
        row = json.loads(raw)
        if row.get('id') in ids:
            rows.append((len(rows) + 1, row))
            if offset >= cut and row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith('20261016-100139-s2-strategy-proposal：'):
                new.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'record': row})
        offset += len(raw)
assert {x['record']['id'] for x in new} == ids and len(new) == len(ids), '所属CLI追加行数/身份'
after = m.fold(rows)
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'effect', 'shipped_at']
for i, a in before.items():
    b = after[i]
    for key in protected:
        assert a.get(key) == b.get(key), (i, key)
    assert b['notes'][:len(a['notes'])] == a['notes'], (i, 'notes前缀')
    assert b['history'][:len(a['history'])] == a['history'], (i, 'history前缀')
    for key, values in a['where'].items():
        assert b['where'][key][:len(values)] == values, (i, key, 'where前缀')
    assert str(S / 'report.md') in b['where']['proposal'], (i, '绝对报告路径')
    assert str(S / 'proposal.md') in b['where']['proposal'], (i, '绝对提案路径')
with open(m.LEDGER, 'rb') as handle:
    for item in oldphysical['rows']:
        handle.seek(item['offset'])
        assert hashlib.sha256(handle.read(item['bytes'])).hexdigest() == item['sha256'], item['offset']
receipt = {'cli_exit': 0, 'updates': len(new), 'source_size_before': cut, 'source_size_after': limit,
           'protected_fields_unchanged': protected, 'old_notes_history_where_prefix_preserved': True,
           'old_physical_rows_unchanged': len(oldphysical['rows']), 'rows': new}
(S / 'ledger-update-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'rows'}, ensure_ascii=False))

import { readFileSync, writeFileSync } from 'node:fs';
import { parseGameState } from '../../../agent/src/hand/mod/schema.ts';
import { silentPhaseCurrentFacts } from '../../../agent/src/reflex/silent-phase-current.ts';
import { silentSlResourceComparison } from '../../../agent/src/reflex/silent-sl-resource-comparison.ts';
import { silentSelectionDispatch } from '../../../agent/src/reflex/silent-selection-dispatch.ts';
import { moveDamageAt, monsterHpAt } from '../../../agent/src/knowledge/monster-db.ts';
import { MEASURED_ROOM_MIN_N, measuredRoom, setRoomCostsForTests } from '../../../agent/src/knowledge/room-costs.ts';

const here = new URL('./', import.meta.url);
const load = name => JSON.parse(readFileSync(new URL(name, here), 'utf8'));
const frames = new Map(load('probe-frames.json').map(item => [item.line, item.row.state]));
const state = line => parseGameState(structuredClone(frames.get(line)));
const outputs = {};
const checks = [];
const check = (name, actual, expected) => checks.push({ name, actual, expected, passed: JSON.stringify(actual) === JSON.stringify(expected) });

for (const line of [277512, 277513, 277518, 277519, 277524, 277526]) {
  outputs[`phase_${line}`] = silentPhaseCurrentFacts(state(line));
}
check('阶段旧毒与新阶段不串用', [outputs.phase_277512.test_subject_current.poison_now, outputs.phase_277513.test_subject_current.poison_now], [4, 0]);
check('阶段已结毒伤保持未知', outputs.phase_277519.test_subject_current.poison_damage_already_dealt, null);
check('已有触媒与当前零毒分别记录', [outputs.phase_277519.test_subject_current.accelerant_established_now, outputs.phase_277519.test_subject_current.poison_now], [2, 0]);
check('后取得敏捷不重写现场挡', [outputs.phase_277524.test_subject_current.block_now, outputs.phase_277526.test_subject_current.block_now], [23, 23]);
const changed = state(277519); changed.run.ascension = 9;
check('阶段快照不扩展到未验证进阶', silentPhaseCurrentFacts(changed), {});

const pair = load('paired-decisions.json').find(item => item.run === 'YF0LXT1QSTGG');
const originalRow = pair.original_decisions[1].row;
const numeric = text => {
  const match = /this turn hp -([0-9.]+), dmg ([0-9.]+)/.exec(text);
  if (!match) throw new Error('缺原候选数值');
  return {
    steps: [],
    outcome: { hpLoss: Number(match[1]), damageDealt: Number(match[2]), blockGained: NaN,
      strengthGained: NaN, cardsDrawn: 0, unknownCards: ['本探针未重放完整候选'], dies: false },
  };
};
const before = numeric(originalRow.sl_explore.numbers.original);
const after = numeric(originalRow.sl_explore.numbers.replacement);
outputs.resource = silentSlResourceComparison(state(277327), before, after, { original: false, replacement: false });
check('候选血价差维持预测10而非实际9', outputs.resource.resource_comparison.delta.hp_loss, 10);
check('候选输出差维持预测负18而非实际负7', outputs.resource.resource_comparison.delta.damage_dealt, -18);
check('候选执行仍未验证', outputs.resource.resource_comparison.replacement.execution, 'unverified');
outputs.random_median = silentSlResourceComparison(state(277327), before, after, { original: false, replacement: true });
check('随机药水中位线不产生配对血价差', outputs.random_median.resource_comparison.delta.hp_loss, null);
const intent = originalRow.chosen;
outputs.dispatch = silentSelectionDispatch(state(277327), { scope: 'predicted_candidates', requested_action: intent }, intent,
  { status: 'returned', result: { status: 'completed', stable: true } });
check('单动作completed不证明整线已执行', outputs.dispatch.selection_dispatch.whole_plan_executed, null);
check('单动作completed不证明状态效果已核', outputs.dispatch.selection_dispatch.state_effect_verified, false);
check('单动作回执实际回合仍未知', outputs.dispatch.selection_dispatch.actual_turn, null);

// This minimal API fixture uses this batch's observed A10 58 HP and 11 x 1 attack.
// Its count of one checks the reader's threshold; it does not reconstruct the old dirty move database.
const db = { SEWER_CLAM: { hp_by_asc: { '10': { median: 58, n: 1 } }, moves: {
  JET_MOVE: { damage_by_asc: { '10': { base_per_hit: { '11': 1 }, hits: { '1': 1 } } } },
} } };
outputs.one_sample_hp = monsterHpAt(db, 'SEWER_CLAM', 10);
outputs.one_sample_damage = moveDamageAt(db, 'SEWER_CLAM', 'JET_MOVE', 10);
check('一个当前进阶HP样本可读', [outputs.one_sample_hp.hp, outputs.one_sample_hp.n, outputs.one_sample_hp.estimated], [58, 1, false]);
check('一个当前进阶攻击样本可读', [outputs.one_sample_damage.perHit, outputs.one_sample_damage.hits, outputs.one_sample_damage.estimated], [11, 1, false]);
check('房间代价原五样本门槛', MEASURED_ROOM_MIN_N, 5);
setRoomCostsForTests({ '10': { '1': { Monster: { n: 4, median: 3, p75: 4, mean: 3 } } } });
check('四个房间样本仍不采用', measuredRoom(1, 10, 'Monster'), null);
setRoomCostsForTests(null);

const result = { scope: '只读函数消费者探针；无游戏、网络、LLM、刷新知识读取或完整模型重放',
  fixture_limits: '资源候选只取原日志已存hp/dmg，其他未重放量为未知；数据库是接口最小夹具，不是历史dirty输入复原。',
  checks, passed: checks.filter(x => x.passed).length, failed: checks.filter(x => !x.passed).length, outputs };
writeFileSync(new URL('consumer-probes.json', here), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ passed: result.passed, failed: result.failed }));
if (result.failed) process.exitCode = 1;

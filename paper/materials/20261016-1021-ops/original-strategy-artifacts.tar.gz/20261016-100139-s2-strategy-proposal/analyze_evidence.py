import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH.parents[2]
spec = importlib.util.spec_from_file_location('extract', ROOT / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
dispatch = json.loads((SCRATCH / 'dispatch-and-proposals.json').read_text())['dispatch']
runs = set(dispatch['runs'])
streams = {}
receipts = []
for directory in ['evidence', 'evidence-extra']:
    for manifest in json.loads((SCRATCH / directory / 'evidence-manifest.json').read_text()):
        name = manifest['stream']
        path = SCRATCH / directory / (name + '.evidence.jsonl')
        digest = hashlib.sha256()
        count = Counter()
        rows = []
        source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
        with source.open('rb') as raw_source, path.open('rb') as handle:
            for encoded in handle:
                digest.update(encoded)
                item = json.loads(encoded)
                assert extract.run_identity(item['row']) == item['run_id'] in runs
                assert item['offset'] + item['bytes'] <= manifest['source_size']
                raw_source.seek(item['offset'])
                raw = raw_source.read(item['bytes'])
                assert hashlib.sha256(raw).hexdigest() == item['sha256']
                assert json.loads(raw) == item['row']
                if name == 'states':
                    assert item['row']['state']['run']['character_id'].lower() == 'silent'
                    assert item['row']['state']['run']['ascension'] == 10
                if name == 'runs':
                    assert item['row']['character'].lower() == 'silent'
                count[item['run_id']] += 1
                rows.append(item)
        assert digest.hexdigest() == manifest['output_sha256']
        assert {run: count[run] for run in runs} == manifest['counts']
        streams[name] = rows
        receipts.append({**manifest, 'rows_verified_against_source': len(rows)})
(SCRATCH / 'provenance-verification.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')


def powers(holder):
    return {p['power_id']: p.get('amount') for p in holder.get('powers', [])}


def compact(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'run': item['run_id'], 'floor': state['run']['floor'],
        'turn': state.get('turn'), 'screen': state['screen'],
        'observed_ts': item['row'].get('observed_ts'),
        'hp': player.get('current_hp', state['run'].get('current_hp')),
        'block': player.get('block'), 'powers': powers(player),
        'potions': [(p['index'], p.get('potion_id')) for p in state['run'].get('potions', []) if p.get('occupied')],
        'enemies': [{
            'index': e['index'], 'id': e['enemy_id'], 'hp': e['current_hp'],
            'max_hp': e['max_hp'], 'alive': e['is_alive'], 'block': e.get('block'),
            'powers': powers(e), 'move': e.get('move_id'),
            'attacks': [i.get('total_damage') for i in e.get('intents', []) if i.get('total_damage') is not None],
        } for e in combat.get('enemies', [])],
    }


targets = {'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39}, 'CA5KE8GFJ9X2': {13},
           '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {31, 33}}
compact_rows = [compact(item) for item in streams['states']]
(SCRATCH / 'state-timeline.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in compact_rows))
groups = defaultdict(list)
attempts = defaultdict(lambda: 1)
previous = {}
for item, row in zip(streams['states'], compact_rows):
    key = (row['run'], row['floor'])
    if not row['enemies'] or not row['turn']:
        continue
    if key in previous and row['turn'] < previous[key]:
        attempts[key] += 1
    previous[key] = row['turn']
    groups[(*key, attempts[key], row['turn'])].append(row)
turns = []
for (run, floor, attempt, turn), rows in groups.items():
    next_rows = groups.get((run, floor, attempt, turn + 1))
    first, last = rows[0], rows[-1]
    end = next_rows[0] if next_rows else last if last['hp'] == 0 else None
    turns.append({'run': run, 'floor': floor, 'attempt': attempt, 'turn': turn,
                  'first': first, 'last_observed': last, 'settled_or_next': end,
                  'net_hp_loss': first['hp'] - end['hp'] if end else None,
                  'enemy_hp_net_change': sum(e['hp'] for e in first['enemies']) - sum(e['hp'] for e in end['enemies']) if end else None,
                  'limitation': '净HP差包含回复；敌总血差遇召唤/复活/阶段转换不等于伤害，截断无后继不补结算。'})
(SCRATCH / 'combat-turns.json').write_text(json.dumps(turns, ensure_ascii=False, indent=2) + '\n')
selected = [x for x in turns if x['floor'] in targets[x['run']]]
(SCRATCH / 'target-turns.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')

lines = {item['line']: item for item in streams['states']}
probe_lines = [277512, 277513, 277518, 277519, 277524, 277526, 277528,
               *range(278236, 278256), *range(277327, 277338), *range(277366, 277374)]
probe_frames = [lines[line] for line in probe_lines if line in lines]
(SCRATCH / 'probe-frames.json').write_text(json.dumps(probe_frames, ensure_ascii=False) + '\n')

decision_lines = {item['line']: item for item in streams['decisions']}
pairs = [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]
pair_results = []
for a, b in pairs:
    left, right = decision_lines[a], decision_lines[b]
    assert left['row']['fingerprint'] == right['row']['fingerprint']
    pair_results.append({'decision_lines': [a, b], 'identical_fingerprint': True,
                         'run': left['run_id'], 'floor': left['row']['floor'], 'turn': left['row']['turn'],
                         'original_decisions': [left, right]})
(SCRATCH / 'paired-decisions.json').write_text(json.dumps(pair_results, ensure_ascii=False, indent=2) + '\n')

facts = {
    'source_rows_verified': sum(x['rows_verified_against_source'] for x in receipts),
    'stream_rows': {x['stream']: x['rows_verified_against_source'] for x in receipts},
    'combat_attempt_counts': {f'{r}/F{f}': attempts[(r, f)] for r, fs in targets.items() for f in fs},
    'same_fingerprint_pairs': [{'run': x['run'], 'floor': x['floor'], 'turn': x['turn'], 'lines': x['decision_lines']} for x in pair_results],
}
(SCRATCH / 'material-summary.json').write_text(json.dumps(facts, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(facts, ensure_ascii=False, indent=2))
for x in selected:
    if (x['run'], x['floor']) in [('CA5KE8GFJ9X2', 13), ('5PM6JAQG6FNQ', 38), ('5PM6JAQG6FNQ', 39)]:
        a, b = x['first'], x['last_observed']
        print(x['run'], x['floor'], x['attempt'], x['turn'], a['line'], b['line'],
              'hp', a['hp'], 'loss', x['net_hp_loss'], 'powers', a['powers'],
              'enemies', [(e['id'], e['hp'], e['powers'], e['attacks']) for e in a['enemies']])

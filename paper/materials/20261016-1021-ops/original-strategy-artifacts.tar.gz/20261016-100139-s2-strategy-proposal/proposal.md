# 静默A10：本批十项已领取提案核验

批次：20261016-100139-s2-strategy-proposal；来源/实现任务：strategy-proposal。基线：`1176e0296c1af8475992d719e5277e5af1f04fae`。

本批无research_request/implementation_request，只处理原十个id。无源码或知识修改，十项均waiting；已有窄功能不能冒标整个宽提案duplicate或implemented。无新增提案id、无规则变更。

共同范围：六局均为silent/A10，同局SL保持一个相关局样本。不引入其他角色知识。具体策略和参数只由实盘证据支持；Roy授权仅为权限。

## silent-proposal-c20b5139dd0dff71 — 感染棱柱：技能收益与污染血价

- 证据：DUZUBAJ3A8GP F27 T4–T5；states 274830–274838。账本：silent-0168。

- 核实：T4技能使污染0→3，勒紧能力仍3，再技能至6；T5火花6，污染清0后三个技能6/12/18，意图17/21/26。毒7→13与17挡同时存在。

- 反例/限制：技能也产生毒/挡；不支持一律少打技能。只观察到当前序列，未选技能线的完整后继未知。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/turn-solver.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）；`agent/src/reflex/rollout.ts` @ `f3dea91880600bc2e7228268a110a644531738f7`（已核实际live祖先）；`agent/src/reflex/silent-sl-resource-comparison.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）。

- 未完成原因：缺历史实际移动表及刷新输入的复原字节、火花增长/污染撤除与弱毒挡的联合校准；不能据单轮9损改技能或终局权重。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-ae9e692d680e3819 — 失落与遗忘：抢夺来源与返还

- 证据：5PM6JAQG6FNQ F39 T2/T4–T6；states 274341–274397。账本：silent-0183, silent-0005。

- 核实：两次抢夺后玩家力敏各−4；首试T4两步法恢复0敏，T5失落退出后力量归0，T6遗忘再夺至−2敏。末试单步法仅到−2敏，8HP/0挡面对遗忘19死亡。首帧27和血瓶后29分列。

- 反例/限制：两试都没有替代杀序完整胜局；负属性当前值不是逐来源账，类型与当前index不构成稳定实例ID。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/turn-solver.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）；`agent/src/reflex/rollout.ts` @ `f3dea91880600bc2e7228268a110a644531738f7`（已核实际live祖先）；`agent/src/reflex/combat-plan.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）。

- 未完成原因：缺抢夺来源、失落退场返还、遗忘再次抢夺的逐实体联合消费者与受控后继；仅当前负力敏公式不能关闭来源/返还提案。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-52f1e1bd2e7db0ed — 下水道蚌：进阶首样本与加压

- 证据：CA5KE8GFJ9X2 F13 T1–T5；states 273237–273269。账本：silent-0231。

- 核实：当前A10本体58；轮初力量0/4/8、喷水11/15/19；覆甲9/9/8/7/6。末轮弱后14、10挡、2HP，完整需损4而实际只扣剩2。

- 反例/限制：覆甲序列不足以隔离完整减层条件；虚弱没有关闭后续成长，不能把一场净损当房间固定成本。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/knowledge/monster-db.ts` @ `4ed3c72df30f27b881da637aebf528b97440e0bb`（已核实际live祖先）；`agent/src/knowledge/move-model.ts` @ `c519952b31e3a0bb3acdd2115883ae8671b8a090`（已核实际live祖先）；`agent/src/knowledge/room-costs.ts` @ `295a90aef9eb6f5b267490294f7733806419c45a`（已核实际live祖先）；`agent/src/reflex/rollout.ts` @ `f3dea91880600bc2e7228268a110a644531738f7`（已核实际live祖先）。

- 未完成原因：当前进阶首样本API已实现；缺历史实际移动表及加压/弱/覆甲联合重放校准，不增减层规则，不改房间五样本门槛。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-6dd8bbff876be528 — 电击机器人：连续成长与新召唤代际

- 证据：5PM6JAQG6FNQ F38 T3–T4；states 274308/274313。账本：silent-0233, silent-0209。

- 核实：连续在场23上限电击力量2→4、攻击17→19、HP23→15；它的当前index从4变3。T3仍贡献17攻击，T4才退场。

- 反例/限制：本体被施毒未消除爪牙攻击；同上限/同类型与邻帧连续性不保证所有新召唤代际，未执行另一杀序不算保血实证。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/rollout.ts` @ `f3dea91880600bc2e7228268a110a644531738f7`（已核实际live祖先）；`agent/src/reflex/combat-plan.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）。

- 未完成原因：现存高电压成长已有源码；仍缺稳定实例/新召唤代际连续轨迹与实际A10运行输入的联合校准，不设置固定击杀序。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-578e415a259e6835 — 沙虫：护栏、SL与能力实际兑现

- 证据：8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11；另F17 T6。账本：silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016。

- 核实：decisions 270216/270282完整指纹相等；原/替线实损3/15、净扣10/17，原日志rollout死亡0/24与5/24并不相等。末试T11为5HP/22挡对37，完整需损15。

- 反例/限制：末次防御换线延至T11仍败，不能把全部防御替换判错；候选省血不是实际省血，抽弃牌后有重规划。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/silent-selection-audit.ts` @ `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`（已核实际live祖先）；`agent/src/reflex/silent-hp-guard-audit.ts` @ `66283dd9982bdd7f480da7a4d9bfefea0572a9ac`（已核实际live祖先）；`agent/src/reflex/silent-selection-dispatch.ts` @ `fdaf787a372880b0438e73bcac7e6d2168b038ed`（已核实际live祖先）；`agent/src/reflex/silent-sl-resource-comparison.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）。

- 未完成原因：原答/护栏/SL候选和单动作回执已有窄审计；缺跨抽弃牌完整候选归属、逐源成长兑现与路线/药水/SL恢复联合读回。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-c0767768bf6a7ab1 — 实验体：全败SL资源代价与覆盖重放

- 证据：YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348，states 277327–277373。账本：silent-0079。

- 核实：完整指纹相等；原候选0损/54伤、替线10损/36伤，两者24/24死且封顶27；实打则0/9损、45/38净扣。候选预测与实际差异明确分列。

- 反例/限制：同局F33第二试确有获胜，F48第四试T5弃牌后未完整执行原候选；不能否定所有SL或把未派发续步计成已执行。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/silent-sl-resource-comparison.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）；`agent/src/reflex/silent-selection-audit.ts` @ `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`（已核实际live祖先）；`agent/src/reflex/silent-selection-dispatch.ts` @ `fdaf787a372880b0438e73bcac7e6d2168b038ed`（已核实际live祖先）；`agent/src/sl/explore.ts` @ `b01edf46b4b619f217d070a196e161df9fe716a0`（已核实际live祖先）。

- 未完成原因：缺覆盖重放与重规划后的整条执行归属、未派发续步和未选线后继；缺独立完整胜局校准，不从全败比例拟惩罚或禁探索。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-a46bdb7fe711d79a — 实验体：阶段毒与格挡兑现

- 证据：YF0LXT1QSTGG F48 末试T3–T5；states 277512–277528。账本：silent-0021, silent-0027, silent-0028, silent-0085。

- 核实：阶段4HP/4毒→新212HP/0毒；T5触媒2、当前毒0。既有23挡时敏捷5→6仍23挡；本体197→160净扣37。18HP面对44−23完整需21，实际死亡只扣18。

- 反例/限制：前五试曾建立毒雾/余像仍败，不能把未建毒当唯一死因；持牌、当前毒和已结毒伤不同。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/silent-phase-current.ts` @ `aad2700abed6dff1d66e87fb36aaa6fedb39adf3`（已核实际live祖先）；`agent/src/reflex/silent-phase-reference.ts` @ `1d57f9d0dbbb63603e9ce9768e74cb2021478464`（已核实际live祖先）；`agent/src/reflex/rollout.ts` @ `f3dea91880600bc2e7228268a110a644531738f7`（已核实际live祖先）；`agent/src/reflex/turn-solver.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）。

- 未完成原因：现场阶段快照已有实现；缺逐候选施毒、已结毒伤、敏捷取得顺序与跨阶段完整执行对账，不据零毒改排名或能力优先级。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-1044224808015e5c — 双蟹：零胜并列SL血价

- 证据：XP2SL33HT0D9 F33 首/二试T3、首/末试T1；decisions 271992/272040、271982/272195。账本：silent-0079。

- 核实：两组完整指纹各相等。T3原/替损9/14、净扣24/27；T1损2/10、净扣25/34，替线也建立永久力量。两组B2为0且同存档六试均败。

- 反例/限制：末次T2临时减力/朝向/挡组合零损；T3仍有4损。不能把低损或高输出单独判成整战胜因，随机药瓶与后续抽序未控制。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/silent-sl-resource-comparison.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）；`agent/src/reflex/silent-loss-reference.ts` @ `1dab14da481fe7951d9020dba52ad0ebebb1029b`（已核实际live祖先）；`agent/src/reflex/silent-selection-audit.ts` @ `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`（已核实际live祖先）；`agent/src/sl/explore.ts` @ `b01edf46b4b619f217d070a196e161df9fe716a0`（已核实际live祖先）。

- 未完成原因：当前血价事实和并列参考已有窄实现；缺受控抽序、随机后继与独立完整胜线，不能校准零胜并列下血价/成长权重或设置全局HP常数。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-7cbc6005db712ba9 — 双蟹：朝向、临减与能力兑现窗口

- 证据：XP2SL33HT0D9 F33 末试T2–T5；states 278236–278263。账本：silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242。

- 核实：T2轮初14挡、镣铐使爪力0→−9/4攻→0，斗篷后20挡零损；T3临减恢复。T4火箭57→转向38→弱28，两步法后4敏，脆弱下防御牌6挡。

- 反例/限制：朝向与弱的19/10减攻分开；已建立能力仍未结束一侧，不外推固定目标序、额外叠层或单组件胜因。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/passive-pieces.ts` @ `c519952b31e3a0bb3acdd2115883ae8671b8a090`（已核实际live祖先）；`agent/src/reflex/turn-solver.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）；`agent/src/knowledge/move-model.ts` @ `c519952b31e3a0bb3acdd2115883ae8671b8a090`（已核实际live祖先）；`agent/src/reflex/silent-selection-dispatch.ts` @ `fdaf787a372880b0438e73bcac7e6d2168b038ed`（已核实际live祖先）。

- 未完成原因：船夹板/临减/朝向已有窄源码；仍缺逐候选朝向、弱、恢复、伤害及重规划后继的联合完整执行记录，现帧不证明整候选反事实。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

## silent-proposal-c59f592f1427a67e — 综合：机制兑现与路线、休息、药水、SL分账

- 证据：YF0LXT1QSTGG F33/F48 与 XP2SL33HT0D9 F33；本批六锚点分局核对。账本：silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242。

- 核实：已核上述同盘血价、阶段重读、临减/赠挡。初始战斗帧、血瓶后可操作HP、死亡剩血截断、SL恢复及未结算毒必须分列。原提案101局/1499房为原批范围，本批未重做该统计。

- 反例/限制：YF F33 SL确实过关，末boss失败不能否定全部SL。净HP包含回复，药槽变化也不自动说明喝药；XP F31幻象复活缺中间帧，净敌血差不当完整输出。

- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。

- 已有窄实现：`agent/src/reflex/silent-selection-audit.ts` @ `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`（已核实际live祖先）；`agent/src/reflex/silent-selection-dispatch.ts` @ `fdaf787a372880b0438e73bcac7e6d2168b038ed`（已核实际live祖先）；`agent/src/reflex/silent-phase-current.ts` @ `aad2700abed6dff1d66e87fb36aaa6fedb39adf3`（已核实际live祖先）；`agent/src/reflex/silent-sl-resource-comparison.ts` @ `1698adc96ba434a46942321e0237b70657e625b2`（已核实际live祖先）。

- 未完成原因：缺完整候选与路线/休息/用药/SL恢复的联合消费者、逐源资源账及独立替线后继；六锚点不能替原101局重建或关闭学习入库宽父。

- 验证：固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。

- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。

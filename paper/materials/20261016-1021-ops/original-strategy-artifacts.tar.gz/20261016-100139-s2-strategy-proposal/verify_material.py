import json
from pathlib import Path

S = Path(__file__).resolve().parent
rows = {x['line']: x for x in map(json.loads, (S / 'state-timeline.jsonl').open())}
turns = json.loads((S / 'combat-turns.json').read_text())
checks = []


def check(name, actual, expected):
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})


def ep(line, key, enemy=0):
    return rows[line]['enemies'][enemy]['powers'].get(key, 0)


def pp(line, key):
    return rows[line]['powers'].get(key, 0)


def turn(run, floor, attempt, number):
    return next(x for x in turns if (x['run'], x['floor'], x['attempt'], x['turn']) == (run, floor, attempt, number))


check('蚌逐轮覆甲', [ep(n, 'PLATING_POWER') for n in [273237, 273247, 273252, 273258, 273263]], [9, 9, 8, 7, 6])
check('蚌加压后的力量', [ep(n, 'STRENGTH_POWER') for n in [273237, 273252, 273263]], [0, 4, 8])
check('蚌喷水意图', [rows[n]['enemies'][0]['attacks'][0] for n in [273237, 273252, 273263]], [11, 15, 19])
check('蚌末轮实扣按剩血截断', turn('CA5KE8GFJ9X2', 13, 1, 5)['net_hp_loss'], 2)
check('蚌末轮完整未挡需求', 14 - 10, 4)
check('失落再次抢夺后负力量', pp(274351, 'STRENGTH_POWER'), -4)
check('失落再次抢夺后负敏捷', pp(274351, 'DEXTERITY_POWER'), -4)
check('失落退出后力量归零', pp(274358, 'STRENGTH_POWER'), 0)
check('遗忘再次抢夺的敏捷', pp(274362, 'DEXTERITY_POWER'), -2)
check('末次单步法后的敏捷', pp(274396, 'DEXTERITY_POWER'), -2)
check('电击连续当前力量', [ep(274308, 'STRENGTH_POWER', 4), ep(274313, 'STRENGTH_POWER', 3)], [2, 4])
check('电击连续攻击', [rows[274308]['enemies'][4]['attacks'][0], rows[274313]['enemies'][3]['attacks'][0]], [17, 19])
check('电击序号发生重排', [rows[274308]['enemies'][4]['index'], rows[274313]['enemies'][3]['index']], [4, 3])
check('火花第三层技能污染及能力不增', [pp(n, 'TAINTED_POWER') for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6])
check('次轮清污染并提高火花', [pp(274834, 'TAINTED_POWER'), ep(274834, 'VITAL_SPARK_POWER')], [0, 6])
check('火花六层三个技能污染', [pp(n, 'TAINTED_POWER') for n in [274836, 274837, 274838]], [6, 12, 18])
for run, floor, number, a, b, expected in [
    ('8JRE1C4H4Z2W', 33, 2, 1, 3, [3, 15, 10, 17]),
    ('YF0LXT1QSTGG', 48, 1, 2, 3, [0, 9, 45, 38]),
    ('XP2SL33HT0D9', 33, 3, 1, 2, [9, 14, 24, 27]),
    ('XP2SL33HT0D9', 33, 1, 1, 6, [2, 10, 25, 34]),
]:
    x, y = turn(run, floor, a, number), turn(run, floor, b, number)
    check(f'{run}/F{floor}T{number}同盘血价与净扣',
          [x['net_hp_loss'], y['net_hp_loss'], x['enemy_hp_net_change'], y['enemy_hp_net_change']], expected)
check('实验体换阶段现场', [rows[277512]['enemies'][0]['hp'], ep(277512, 'POISON_POWER'),
                           rows[277513]['enemies'][0]['max_hp'], ep(277513, 'POISON_POWER')], [4, 4, 212, 0])
check('触媒建立时当前零毒', [pp(277519, 'ACCELERANT_POWER'), ep(277519, 'POISON_POWER')], [2, 0])
check('后来敏捷不倒补既有挡', [pp(277524, 'DEXTERITY_POWER'), rows[277524]['block'], pp(277526, 'DEXTERITY_POWER'), rows[277526]['block']], [5, 23, 6, 23])
check('末轮实验体实扣本体', rows[277519]['enemies'][0]['hp'] - rows[277528]['enemies'][0]['hp'], 37)
check('实验体实际扣剩18与完整需21分列', [rows[277519]['hp'], rows[277528]['hp'], 44 - 23], [18, 0, 21])
check('船夹板赠挡与卡牌挡', [rows[278236]['block'], rows[278240]['block']], [14, 20])
check('普通镣铐临减', [ep(278236, 'STRENGTH_POWER'), ep(278237, 'STRENGTH_POWER')], [0, -9])
check('火箭朝向与弱分别降低意图', [rows[n]['enemies'][1]['attacks'][0] for n in [278249, 278252, 278253]], [57, 38, 28])
check('四个完整指纹配对', len(json.loads((S / 'paired-decisions.json').read_text())), 4)
result = {'scope': '固定原始材料算术与指纹核验，不是生产tsc/vitest或完整策略校准',
          'checks': checks, 'passed': sum(x['passed'] for x in checks), 'failed': sum(not x['passed'] for x in checks)}
(S / 'material-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(bool(result['failed']))

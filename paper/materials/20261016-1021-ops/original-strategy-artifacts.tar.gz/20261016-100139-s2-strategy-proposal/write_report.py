import hashlib
import json
import subprocess
from pathlib import Path

S = Path(__file__).resolve().parent
D = json.loads((S / 'dispatch-and-proposals.json').read_text())
SOURCE = json.loads((S / 'source-snapshot.json').read_text())
source = {x['path'].rsplit('/', 1)[-1]: x for x in SOURCE['files']}
base = SOURCE['base']


def refs(*names):
    return [{'path': source[n]['path'], 'commit': source[n]['last_commit'],
             'live_ancestor': source[n]['live_ancestor']} for n in names]


items = [
    ('c20b5139dd0dff71', '感染棱柱：技能收益与污染血价', 'DUZUBAJ3A8GP F27 T4–T5；states 274830–274838',
     'T4技能使污染0→3，勒紧能力仍3，再技能至6；T5火花6，污染清0后三个技能6/12/18，意图17/21/26。毒7→13与17挡同时存在。',
     '技能也产生毒/挡；不支持一律少打技能。只观察到当前序列，未选技能线的完整后继未知。',
     '缺历史实际移动表及刷新输入的复原字节、火花增长/污染撤除与弱毒挡的联合校准；不能据单轮9损改技能或终局权重。',
     refs('turn-solver.ts', 'rollout.ts', 'silent-sl-resource-comparison.ts')),
    ('ae9e692d680e3819', '失落与遗忘：抢夺来源与返还', '5PM6JAQG6FNQ F39 T2/T4–T6；states 274341–274397',
     '两次抢夺后玩家力敏各−4；首试T4两步法恢复0敏，T5失落退出后力量归0，T6遗忘再夺至−2敏。末试单步法仅到−2敏，8HP/0挡面对遗忘19死亡。首帧27和血瓶后29分列。',
     '两试都没有替代杀序完整胜局；负属性当前值不是逐来源账，类型与当前index不构成稳定实例ID。',
     '缺抢夺来源、失落退场返还、遗忘再次抢夺的逐实体联合消费者与受控后继；仅当前负力敏公式不能关闭来源/返还提案。',
     refs('turn-solver.ts', 'rollout.ts', 'combat-plan.ts')),
    ('52f1e1bd2e7db0ed', '下水道蚌：进阶首样本与加压', 'CA5KE8GFJ9X2 F13 T1–T5；states 273237–273269',
     '当前A10本体58；轮初力量0/4/8、喷水11/15/19；覆甲9/9/8/7/6。末轮弱后14、10挡、2HP，完整需损4而实际只扣剩2。',
     '覆甲序列不足以隔离完整减层条件；虚弱没有关闭后续成长，不能把一场净损当房间固定成本。',
     '当前进阶首样本API已实现；缺历史实际移动表及加压/弱/覆甲联合重放校准，不增减层规则，不改房间五样本门槛。',
     refs('monster-db.ts', 'move-model.ts', 'room-costs.ts', 'rollout.ts')),
    ('6dd8bbff876be528', '电击机器人：连续成长与新召唤代际', '5PM6JAQG6FNQ F38 T3–T4；states 274308/274313',
     '连续在场23上限电击力量2→4、攻击17→19、HP23→15；它的当前index从4变3。T3仍贡献17攻击，T4才退场。',
     '本体被施毒未消除爪牙攻击；同上限/同类型与邻帧连续性不保证所有新召唤代际，未执行另一杀序不算保血实证。',
     '现存高电压成长已有源码；仍缺稳定实例/新召唤代际连续轨迹与实际A10运行输入的联合校准，不设置固定击杀序。',
     refs('rollout.ts', 'combat-plan.ts')),
    ('578e415a259e6835', '沙虫：护栏、SL与能力实际兑现', '8JRE1C4H4Z2W F33 首/三试T2、第二试T5、末试T11；另F17 T6',
     'decisions 270216/270282完整指纹相等；原/替线实损3/15、净扣10/17，原日志rollout死亡0/24与5/24并不相等。末试T11为5HP/22挡对37，完整需损15。',
     '末次防御换线延至T11仍败，不能把全部防御替换判错；候选省血不是实际省血，抽弃牌后有重规划。',
     '原答/护栏/SL候选和单动作回执已有窄审计；缺跨抽弃牌完整候选归属、逐源成长兑现与路线/药水/SL恢复联合读回。',
     refs('silent-selection-audit.ts', 'silent-hp-guard-audit.ts', 'silent-selection-dispatch.ts', 'silent-sl-resource-comparison.ts')),
    ('c0767768bf6a7ab1', '实验体：全败SL资源代价与覆盖重放', 'YF0LXT1QSTGG F48 第二/第三试T1；decisions 271309/271348，states 277327–277373',
     '完整指纹相等；原候选0损/54伤、替线10损/36伤，两者24/24死且封顶27；实打则0/9损、45/38净扣。候选预测与实际差异明确分列。',
     '同局F33第二试确有获胜，F48第四试T5弃牌后未完整执行原候选；不能否定所有SL或把未派发续步计成已执行。',
     '缺覆盖重放与重规划后的整条执行归属、未派发续步和未选线后继；缺独立完整胜局校准，不从全败比例拟惩罚或禁探索。',
     refs('silent-sl-resource-comparison.ts', 'silent-selection-audit.ts', 'silent-selection-dispatch.ts', 'explore.ts')),
    ('a46bdb7fe711d79a', '实验体：阶段毒与格挡兑现', 'YF0LXT1QSTGG F48 末试T3–T5；states 277512–277528',
     '阶段4HP/4毒→新212HP/0毒；T5触媒2、当前毒0。既有23挡时敏捷5→6仍23挡；本体197→160净扣37。18HP面对44−23完整需21，实际死亡只扣18。',
     '前五试曾建立毒雾/余像仍败，不能把未建毒当唯一死因；持牌、当前毒和已结毒伤不同。',
     '现场阶段快照已有实现；缺逐候选施毒、已结毒伤、敏捷取得顺序与跨阶段完整执行对账，不据零毒改排名或能力优先级。',
     refs('silent-phase-current.ts', 'silent-phase-reference.ts', 'rollout.ts', 'turn-solver.ts')),
    ('1044224808015e5c', '双蟹：零胜并列SL血价', 'XP2SL33HT0D9 F33 首/二试T3、首/末试T1；decisions 271992/272040、271982/272195',
     '两组完整指纹各相等。T3原/替损9/14、净扣24/27；T1损2/10、净扣25/34，替线也建立永久力量。两组B2为0且同存档六试均败。',
     '末次T2临时减力/朝向/挡组合零损；T3仍有4损。不能把低损或高输出单独判成整战胜因，随机药瓶与后续抽序未控制。',
     '当前血价事实和并列参考已有窄实现；缺受控抽序、随机后继与独立完整胜线，不能校准零胜并列下血价/成长权重或设置全局HP常数。',
     refs('silent-sl-resource-comparison.ts', 'silent-loss-reference.ts', 'silent-selection-audit.ts', 'explore.ts')),
    ('7cbc6005db712ba9', '双蟹：朝向、临减与能力兑现窗口', 'XP2SL33HT0D9 F33 末试T2–T5；states 278236–278263',
     'T2轮初14挡、镣铐使爪力0→−9/4攻→0，斗篷后20挡零损；T3临减恢复。T4火箭57→转向38→弱28，两步法后4敏，脆弱下防御牌6挡。',
     '朝向与弱的19/10减攻分开；已建立能力仍未结束一侧，不外推固定目标序、额外叠层或单组件胜因。',
     '船夹板/临减/朝向已有窄源码；仍缺逐候选朝向、弱、恢复、伤害及重规划后继的联合完整执行记录，现帧不证明整候选反事实。',
     refs('passive-pieces.ts', 'turn-solver.ts', 'move-model.ts', 'silent-selection-dispatch.ts')),
    ('c59f592f1427a67e', '综合：机制兑现与路线、休息、药水、SL分账', 'YF0LXT1QSTGG F33/F48 与 XP2SL33HT0D9 F33；本批六锚点分局核对',
     '已核上述同盘血价、阶段重读、临减/赠挡。初始战斗帧、血瓶后可操作HP、死亡剩血截断、SL恢复及未结算毒必须分列。原提案101局/1499房为原批范围，本批未重做该统计。',
     'YF F33 SL确实过关，末boss失败不能否定全部SL。净HP包含回复，药槽变化也不自动说明喝药；XP F31幻象复活缺中间帧，净敌血差不当完整输出。',
     '缺完整候选与路线/休息/用药/SL恢复的联合消费者、逐源资源账及独立替线后继；六锚点不能替原101局重建或关闭学习入库宽父。',
     refs('silent-selection-audit.ts', 'silent-selection-dispatch.ts', 'silent-phase-current.ts', 'silent-sl-resource-comparison.ts')),
]
result_items = []
for suffix, title, evidence, support, counter, missing, existing in items:
    pid = 'silent-proposal-' + suffix
    old = D['proposals'][pid]['add']
    result_items.append({'id': pid, 'title': title, 'state': 'waiting', 'reason': missing,
                         'runs': old['runs'], 'ledger': old['ledger'], 'evidence_location': evidence,
                         'support': support, 'counterexamples_and_limits': counter,
                         'existing_narrow_sources': existing,
                         'validation': '固定原始状态/动作与真实运行输入，核逐步资源和重规划边界；策略改变另按独立run时间后移验证，不把同存档尝试分作独立训练/验证。'})
assert [x['id'] for x in result_items] == D['dispatch']['proposal_ids']
(S / 'proposal-results-detail.json').write_text(json.dumps(result_items, ensure_ascii=False, indent=2) + '\n')

proposal = ['# 静默A10：本批十项已领取提案核验\n',
            f'批次：20261016-100139-s2-strategy-proposal；来源/实现任务：strategy-proposal。基线：`{base}`。\n',
            '本批无research_request/implementation_request，只处理原十个id。无源码或知识修改，十项均waiting；已有窄功能不能冒标整个宽提案duplicate或implemented。无新增提案id、无规则变更。\n',
            '共同范围：六局均为silent/A10，同局SL保持一个相关局样本。不引入其他角色知识。具体策略和参数只由实盘证据支持；Roy授权仅为权限。\n']
for item in result_items:
    proposal += [f"## {item['id']} — {item['title']}\n",
                 f"- 证据：{item['evidence_location']}。账本：{', '.join(item['ledger'])}。\n",
                 f"- 核实：{item['support']}\n", f"- 反例/限制：{item['counterexamples_and_limits']}\n",
                 '- 旧/新行为：现有选择、排序、药水、SL和终局参数保持；本批仅核验并补追溯，无可上线的新规则。\n',
                 '- 已有窄实现：' + '；'.join(f"`{x['path']}` @ `{x['commit']}`（已核实际live祖先）" for x in item['existing_narrow_sources']) + '。\n',
                 f"- 未完成原因：{item['reason']}\n", f"- 验证：{item['validation']}\n",
                 '- 预期影响/回退：本批不改变对局；后续只对已核缺口实现，需撤源码失败/恢复通过与项目自测后上线，按实际commit回退并保留历史。\n']
(S / 'proposal.md').write_text('\n'.join(proposal))

summary = json.loads((S / 'material-summary.json').read_text())
checks = json.loads((S / 'material-checks.json').read_text())
probe = json.loads((S / 'consumer-probes.json').read_text())
report = [
    '# 本批静默策略提案报告\n',
    '十项均保留waiting：已有窄功能确实位于live祖先，但本批证据不够完成原提案的联合模型/执行验证，也不够拟合新的策略参数。本批无源码和知识改动、无提交、无live合入和新版本。\n',
    f'基线/最终HEAD：`{base}`；开工git status干净，`git merge --no-edit main`返回Already up to date。实际live只读锚点：`{SOURCE["live_head_observed"]}`。\n',
    '## 派发与来源\n',
    '本次learn.json实际task=strategy-proposal、character=silent、reason=proposal，工作树一致；proposal_ids精确十项，没有proposal_repair/research_request/implementation_request。旧deck-size请求绑定其他批，未承接或读取其他专题正文。dispatch-and-proposals.json保留本批行、仅所属队列事件的offset/bytes/SHA以及原add。十份原Markdown均已读，字节SHA与队列登记值全部相等；原件以*.original.md保留。\n',
    'runs.jsonl六局角色枚举均SILENT、进阶10；六个完整源码commit对象均存在，但run-config均dirty，刷新输入实际字节未由本批复原，不能把当前HEAD或旧源码commit当历史联合输入。详见run-identity.json、historical-input-boundaries.json。知识仅读本树knowledge/characters/silent中的所属条目；已有统计与[0,20]范围未当作本批跨进阶策略验证。\n',
    '## 原始证据与检查\n',
    f'共逐行回读原文件offset/bytes/SHA与JSON核验{summary["source_rows_verified"]}行：states=4062、decisions=3941、SL=38、run-config=6、run-plans=33、brain=188、runs=6、fight-plans=0。共用extract_evidence.py明确身份筛选，未用正文提及认领所属局。主/附加manifest保存每流source_size、逐局计数和输出SHA。fight-plans零行仅表示该截点无所选显式身份行，不推断历史文件缺失。全截点解析失败计数states=2、decisions=2、brain=1，不将无身份坏行归给本批；其余流0。未覆盖旧截点或零行初稿。\n',
    f'固定材料检查{checks["passed"]}/{len(checks["checks"])}通过，含四组完整指纹配对、负属性/返还、污染和火花、蚌成长、阶段清毒及晚敏捷、镣铐和朝向。state-timeline.jsonl、combat-turns.json和paired-decisions.json可重核。净HP/敌血差只是观测，召唤/复活/阶段、回复及截断不按差值补写伤害。\n',
    f'只读消费者探针{probe["passed"]}/{len(probe["checks"])}通过：阶段快照将已结毒伤保留null、当前零毒与触媒分列；资源比较保持候选10损/−18输出差，而非实打9损/−7；随机药水中位线不作配对；单动作completed仍whole_plan_executed=null、state_effect_verified=false。最小固定DB核n=1当前进阶58HP/11攻击可读，房间n=4仍不采用。该夹具不是历史dirty DB复原、整场模拟或自然消费者验收，未调用LLM/网络/游戏。输入probe-frames.json、paired-decisions.json，输出consumer-probes.json。\n',
    'source-snapshot.json记录16源码叶SHA和最后源码commit，全部均已核为上述真实live的祖先。不能以这些窄子项或探针通过关闭整个宽提案。\n',
    '## 逐项处置\n',
    '| 原提案 | 证据 | 处置与未实现原因 |\n|---|---|---|\n',
]
for x in result_items:
    report.append(f"| {x['id']} | {x['evidence_location']}；账本见proposal.md逐项 | waiting：{x['reason']} |\n")
report += [
    '\n## 结论、验证边界与交接\n',
    '支持“长程全败/封顶不能抹掉当轮血价；已持有、已建立、已结算与实际完成分列”。四配对结果为8J沙虫损3/15、扣10/17；YF实验体损0/9、扣45/38；XP双蟹T3损9/14、扣24/27，T1损2/10、扣25/34。它们是相关的当轮配对，不是独立整战收益证明。反例包括YF F33 SL过关、较保守末线仍败、原候选因抽弃牌未完成，以及已建立能力但零毒/无减员。\n',
    '不拟合或更改技能优先级、杀序、全局血价常数、禁探索、用药持有价、房间门槛及终局权重。其他角色/未观察进阶无变化。缺独立后继和完整联合消费者时保持waiting；学习入库与资源校准宽父保持，报告结束不算入库、自然采用或shipped。\n',
    '无生产改动，因此撤源码失败/恢复通过不适用；没有运行tsc、vitest或完整沙箱套件，tests各null，不报成功或0例。29材料断言与16函数探针单列，不能代替生产检查。无实现commit、merge、release或规则双通知。\n',
    '过程失败保留：首轮读取器把SILENT与silent严格比较触发断言、误写core/loop.ts路径、非战斗combat=null形状探针失败；修正均只在本批读取器。首轮消费者相对import多一层导致ERR_MODULE_NOT_FOUND，原脚本.txt及first-failure.log保留，纠正路径后16项全过，未改生产断言。一次工具启动遇并行工作树回收的bubblewrap/rg缺目录拒绝，重试同一只读命令成功，属于沙箱入口，不报产品故障。\n',
    f'运维入口：`{S / "proposal.md"}` 与本报告。完整处置为proposal-results-detail.json；最后JSON见result.json。只经根ledger.py追加所属where/note追溯，保持旧claim/首证/prior/evidence/status/version，不重复登记support/repeat、不降级既有shipped、不新增提案id；追加回执及不变量见ledger-update-receipt.json（验收完成后生成）。\n',
]
(S / 'report.md').write_text('\n'.join(report))
result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-100139-s2-strategy-proposal',
    'base': base, 'runs': D['dispatch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': D['dispatch']['proposal_ids'], 'implementation_domains': [],
    'proposal_results': [{'id': x['id'], 'state': 'waiting', 'reason': x['reason']} for x in result_items],
    'report': str(S / 'report.md'),
}
(S / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
updates = []
for ledger in sorted({i for x in result_items for i in x['ledger']}):
    belongs = [x for x in result_items if ledger in x['ledger']]
    updates.append({'id': ledger, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]},
                    'note': '20261016-100139-s2-strategy-proposal：仅复核既有证据并补追溯，不新增支持/重犯或改变已上线经验状态；' +
                    '；'.join(x['id'] + '=waiting：' + x['reason'] for x in belongs)})
(S / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'proposal_count': len(result_items), 'ledger_updates': len(updates), 'report': str(S / 'report.md')}, ensure_ascii=False))

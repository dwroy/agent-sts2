# 静默策略批次核验报告

记录时间：2026-10-18T09:57:17+08:00。

10项全部waiting：证据能核实局部资源与机制，但不足完成原提案要求的完整归属、联合校准或安全抽序身份修复。源码、知识、任务模板及Git跟踪文件没有本批改动；fixes=[]，merged=null。

派发初始HEAD为84d37ee0947517411a9825460cfa4f3952ab35d8。已核learn.json本批task/character/worktree/runs/proposal_ids；没有research_request、implementation_request或proposal_repair；普通专题文件绑定另一批，未转为专题。按任务合并main一次，快进后base/HEAD为`a39157dabea8791c896df7b5cc477707ec5c89fd`，后续不追并行main。没有源码提交、live合入、行为版本、shipped或消费者已采用声明。

## 证据边界

只使用本批五局、原提案及其silent账本/经验。runs.jsonl核实7X0W3U8TVA2A、MTQ0EUBJ3R6T、KFRDELW2TH2P、GXNKW8X1XYJP为SILENT A10；ZE8F192FKX24为SILENT A5。四A10末局均败，A5胜；不将A5用于未观察A10策略外推。原运行code均有dirty，不以当前源码替代历史运行输入。

共6060条：states2965、decisions2846、sl-attempts26、run-config5、run-plans30、brain183、runs5、fight-plans0。主六流与extra两流各有source_size、逐条offset/bytes/SHA/JSON显式归局和输出SHA；全部已重新seek读原日志核回，见evidence-verification.json。run-plans读取run而非正文；fight-plans的0只代表该截点选中0行。全源states/decisions/brain各2坏行无法归本五局，不充当本局缺失证据或零错误原日志。

## 逐项处置

| 原提案ID | 局/层/回合与账本 | 处置与具体缺口 |
|---|---|---|
| silent-proposal-19a5cff2094e2d8f | MTQ0EUBJ3R6T F23T3 decision282434；7X0W3U8TVA2A F31T5 states288426/288430。<br>silent-0021, silent-0064, silent-0079, silent-0133, silent-0125 | waiting；缺同输入同后继的整战校准、未截断入伤和持续敌实体归属；24/24死亡不能校准新SL或终局权重。 |
| silent-proposal-3540bf4360bf80af | 7X0W3U8TVA2A F17→18 states288236/288237；MTQ0EUBJ3R6T F17→18 states288726/288727及F19/F20。<br>silent-0019, silent-0020, silent-0243 | waiting；现有HP边界观测只记录净变化；缺休息、开场、SL、逐槽药水的完整来源归因和路线/休息消费者联合读回。 |
| silent-proposal-0ea5c0b9c030fdd6 | KFRDELW2TH2P F33T7 decisions282864/282899/282933/282968/283001/283035；states289533—289538。<br>silent-0274, silent-0247, silent-0027, silent-0016 | waiting；live已有名额提示与限定恶魔6毒入口，但continuation_verified=false；缺合法完整后继、自动重放交互及多轮收益校准。 |
| silent-proposal-f915ec544ab94b6e | KFRDELW2TH2P F12T1 decisions282578/282579；F33T6 decision282929，states289339/289345/289414/289420。<br>silent-0079, silent-0125 | waiting；离线阶段关联已有；F12生成后重问、F33T6缺可核整轮开端，未能将完整候选结果归给实际线，不能据净差改排序。 |
| silent-proposal-8fb51933639faf90 | KFRDELW2TH2P F28T2、F33T2/T4/T5/T6/T7；末states289536/289537/289538。<br>silent-0005, silent-0006, silent-0027, silent-0189, silent-0276, silent-0277, silent-0278 | waiting；局部药效模型已存在；缺覆甲完整减层条件及能量、药效、能力多入口叠加的消费者校准，未定位新独立数值失配。 |
| silent-proposal-b3bc0eb09211af6c | KFRDELW2TH2P F33T6/T7，states289339/289345/289414/289420/289533—289538。<br>silent-0021, silent-0079, silent-0102, silent-0247, silent-0274 | waiting；奇巧提示和即时资源比较已有；缺完整后继、未建立能力收益及整战终局校准，六次相关SL均无可核整战胜线。 |
| silent-proposal-fdc3a505fe5e1a55 | KFRDELW2TH2P F17→18 states289149/289150；F28T2、F29—33；原提案F18投影/F33实际入口。<br>silent-0019, silent-0020, silent-0243 | waiting；现有HP边界记录不等于完整来源链；缺逐源路线/休息消费者验收和可比替路线后继，不能调整路线或休息阈值。 |
| silent-proposal-5a95725089f53cd8 | GXNKW8X1XYJP F45T2/T3 decisions283641/283680/283690/283691；states290160/290165/290201/290206/290212—290214。<br>silent-0019, silent-0079, silent-0005, silent-0016, silent-0087, silent-0027, silent-0030 | waiting；缺复活瞬时逐击、未截断入伤、前三次退出及完整候选持续归属；两线均失败，不能据局部10血差更改评分或SL。 |
| silent-proposal-51fa8bc34774f72d | GXNKW8X1XYJP F45T2→T3 sl-attempts1053—1056、states290201/290205/290206/290214；ZE8F192FKX24 A5 F42T3/T4 states223268/223272。<br>silent-0279, silent-0280 | waiting；升级键整堆作差路径仍在；缺纯改标中间帧、唯一物理副本及并发次序，不能仅凭基ID守恒安全延长已知抽序。 |
| silent-proposal-29b7b36dffbcb017 | GXNKW8X1XYJP F33T5 states289986/289987、T6；F45T3 states290206/290212—290214。<br>silent-0005, silent-0006, silent-0011, silent-0016, silent-0021, silent-0027, silent-0030, silent-0087, silent-0278 | waiting；毒结算等局部模型已有；缺头骨、毒雾、覆甲与力敏联合多轮校准及完整时点对照，未定位可隔离的新源码差额。 |

完整原/预期行为、支持、反例、拟合限制、验证及回退见proposal.md各同名段落。没有把已上线窄子功能记成整项duplicate。

## 现有源码范围

审计所见live为`53c9d61749abd51ed1727ac0c22dc5d52a8a7965`，只作只读谱系核实。21个所需源码/离线工具叶保存base/live字节副本、Git blob、SHA和最后源提交，见source-pins.json；六叶字节不同，draws/explore/card-model/run-journal差异为注释，rollout另有其他已发布窄机制，未据此声称整树或历史dirty树等价。

| 已存在的局部能力 | 实际live祖先源码提交 |
|---|---|
| handTrickSlothFacts | `8bb53d6342b7e9a2adf96de231b53c36eaa943de` |
| observedDemonPoison | `8bb53d6342b7e9a2adf96de231b53c36eaa943de` |
| silentSelectionAudit | `a8b1f8be153fe4f3a34146117546c2178f2e446b` |
| silentSlResourceComparison | `66283dd9982bdd7f480da7a4d9bfefea0572a9ac` |
| trackSilentHpRecovery | `52d7f343f5f183670dc9d0c0d847bf6a15420aae` |
| auditSelectionExecution | `6f3f783941270ac182237c46068097ff67e85907` |

以上仅证明该局部实现已在观测live历史中，不能关闭含完整后继/联合消费者交付的原提案。抽序cardKey仍含升级标记，整堆作差、fresh/inserted及残差断序路径仍存在。

## 离线材料复算与限制

KFR T6：15血/228敌血/36毒/3覆甲同盘，两线端点分别9血/145敌血与3血/135敌血，即损6/12和净扣83/93。KFR T7：三牌满额爆发锁住；37→43毒当步敌159不变，最后结85到74。GX T2→T3：相同初始2血，两线剩3/13、带挡0/7、敌血差8；GX F33T5建立触媒2层后29毒结84。详paired-facts.json、verified-local-facts.json。净差不归为单动作因果，也不填逐击毛入伤。

四次GX抑制首次观测都在T3，前帧为T2零血/复活窗口，手牌同时变成新轮普通牌；四条SL仍列四普通键inserted、旧+键离堆及clean19/18/19/18。缺纯改标帧和唯一持续物理身份，未安全延长抽序。A5读到普通文本只证明现场版本可读，不证明SL追踪已正确。

HP增加观测72段只作净变化端点，source_cause=null；7X28→61、MTQ19→59、KFR22→60可核。原act_id在边界邻帧可能相同，不能仅靠act_id变化判定无回复；本报告按原层与原提案来源边界列事实，不推新回复规则。

现有auditSelectionExecution首次直接喂全部决策因map/route-change无decision_id而拒收（offline-audit-initial-failure.log保留）。查明这些是chosen=null、no game action的路线记录；四A10共4条只从工具输入排除，原证据均保留、原行号间隙阻断跨段认证，见offline-audit-exclusions.json。没有排序、补造ID、伪造动作或改源码。

工具复算结果如下；这不是tsc/vitest、生产测试、消费者自然采用或新增独立样本。该工具的actual_full_candidate_result本来就保守为null，不能仅凭null计数断言所有历史候选都未执行；需结合重问与帧缺口判断。

| 局号 | 题段 | 可核整轮端点/窗口 | 相邻观测区间 | 工具认证完整候选 |
|---|---:|---:|---:|---:|
| 7X0W3U8TVA2A | 119 | 7/71 | 36 | 0 |
| MTQ0EUBJ3R6T | 68 | 25/75 | 156 | 0 |
| KFRDELW2TH2P | 180 | 18/103 | 224 | 0 |
| GXNKW8X1XYJP | 116 | 20/103 | 178 | 0 |

F12护栏首动作后下一题确实重问；原完整0损预测不能当后来不同实线损6的预测误差。F33T6后续也有重问，整轮开端不完整。离线工具完成只表示可核材料复算完成，未完成原提案全范围交付。

## 记录、检查与交付

既有提案ID全部复用。仅经根ledger.py update给关联账本追加本报告/提案的where与note；不新增support/repeat、claim、首证、prior、状态、版本或效果，不将旧shipped状态倒改proposed。实际CLI输入、回执与独立读回见ledger-updates.json、ledger-update.log、ledger-append-proof.json、ledger-readback.json。队列处置交proposal_results，由原调度器接续，不手改队列。

未修改执行源码：撤源码失败/恢复通过不适用，tsc=null、vitest=null、cases=null。离线材料复算的exit0不替代这些测试字段。未提交，无提交前gitleaks或Co-Authored-By可报；未推送、未运行play、未启动LLM或游戏模拟、未读其他角色知识。

报告保留初次材料读取遇空文件/空combat对象的只读探针失败、离线工具初次输入拒收及后续明确排除；原失败日志不改写。进度消息曾将6060误写6606，已更正，最终逐流数量以manifest和复核报告为准。

提案交运维路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261018-094302-s2/learner/runs/20261018-094305-71e9f58a-c826-4afa-9ae2-9cb60e9218a9-strategy-proposal/proposal.md`。最终机器回报：result.json。源码/知识/任务模板零差异及HEAD基线见final-verification.json，材料SHA见artifact-manifest.json。

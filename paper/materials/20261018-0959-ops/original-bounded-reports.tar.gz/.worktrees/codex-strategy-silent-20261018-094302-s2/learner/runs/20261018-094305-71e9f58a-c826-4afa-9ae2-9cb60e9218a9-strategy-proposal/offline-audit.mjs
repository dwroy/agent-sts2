import { createReadStream, writeFileSync } from "node:fs";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { auditSelectionExecution } from "../../lib/selection-execution.ts";

const here = fileURLToPath(new URL(".", import.meta.url));
async function rows(path) {
  const result = [];
  for await (const line of createInterface({ input: createReadStream(path), crlfDelay: Infinity })) {
    const wrapper = JSON.parse(line);
    result.push({ ...wrapper.row, _line: wrapper.line });
  }
  return result;
}
const runs = await rows(here + "evidence-extra/runs.evidence.jsonl");
const states = await rows(here + "evidence/states.evidence.jsonl");
const decisions = await rows(here + "evidence/decisions.evidence.jsonl");
const summary = [];
const exclusions = [];
for (const run of runs) {
  if (run.ascension !== 10) continue;
  const ownDecisions = decisions.filter(row => row.run_id === run.run_id);
  const validDecisions = ownDecisions.filter(row => {
    if (typeof row.decision_id === "string" && row.decision_id.length > 0) return true;
    exclusions.push({ run_id: run.run_id, source_line: row._line, label: row.label,
      reason: "原行没有decision_id；保留原证据，不伪造动作ID。原行号间隙会阻断相邻区间认证。" });
    return false;
  });
  const audit = auditSelectionExecution({ run,
    states: states.filter(row => row.state.run_id === run.run_id),
    decisions: validDecisions });
  writeFileSync(here + run.run_id + ".selection-audit.json", JSON.stringify(audit, null, 2) + "\n");
  summary.push({ run_id: run.run_id, segments: audit.segments.length,
    certified_full_candidates: audit.segments.filter(row => row.actual_full_candidate_result !== null).length,
    observed_turn_windows: audit.observed_turns.filter(row => row.status === "observed_turn_endpoints").length,
    total_turn_windows: audit.observed_turns.length,
    observed_intervals: audit.observed_intervals.filter(row => row.reason === "adjacent_logged_observations").length,
    actions: audit.observed_actions.length,
    key_segments: audit.segments.filter(row => [282578, 282929, 283641, 283690].includes(row.source_line)) });
}
writeFileSync(here + "offline-audit-exclusions.json", JSON.stringify(exclusions, null, 2) + "\n");
writeFileSync(here + "offline-audit-summary.json", JSON.stringify(summary, null, 2) + "\n");
process.stdout.write(JSON.stringify(summary.map(({ key_segments, ...row }) => row)) + "\n");

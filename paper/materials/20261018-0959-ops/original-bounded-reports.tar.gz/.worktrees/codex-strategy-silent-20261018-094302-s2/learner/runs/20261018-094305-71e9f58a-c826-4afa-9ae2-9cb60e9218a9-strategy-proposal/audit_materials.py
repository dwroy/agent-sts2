import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location("evidence_reader", ROOT / "learner/extract_evidence.py")
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def rec(value):
    return value if isinstance(value, dict) else {}


def powers(value):
    return {p.get("power_id"): p.get("amount") for p in value or []}


streams = {}
verification = []
for directory in ["evidence", "evidence-extra"]:
    manifest = json.loads((HERE / directory / "evidence-manifest.json").read_text())
    for item in manifest:
        output = HERE / directory / (item["stream"] + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        rows = []
        with output.open("rb") as handle, Path("/home/dw/Projects/agent-sts2/logs", item["stream"] + ".jsonl").open("rb") as source:
            for raw in handle:
                digest.update(raw)
                wrapper = json.loads(raw)
                source.seek(wrapper["offset"])
                original = source.read(wrapper["bytes"])
                assert len(original) == wrapper["bytes"]
                assert wrapper["offset"] + wrapper["bytes"] <= item["source_size"]
                assert hashlib.sha256(original).hexdigest() == wrapper["sha256"]
                assert json.loads(original) == wrapper["row"]
                assert reader.run_identity(wrapper["row"]) == wrapper["run_id"]
                counts[wrapper["run_id"]] += 1
                rows.append(wrapper)
        assert digest.hexdigest() == item["output_sha256"]
        assert all(counts[run] == n for run, n in item["counts"].items())
        streams[item["stream"]] = rows
        verification.append({**item, "verified_references": sum(counts.values()), "offset_bytes_sha_json_identity": True})
save("evidence-verification.json", verification)

runs = {x["run_id"]: x["row"] for x in streams["runs"]}
assert set(runs) == set(json.loads((HERE / "dispatch.json").read_text())["runs"])
assert all(str(r["character"]).lower() == "silent" for r in runs.values())
for wrapper in streams["states"]:
    state = wrapper["row"]["state"]
    run = rec(state.get("run"))
    assert str(run.get("character_id")).lower() == "silent"
    assert run.get("ascension") == runs[wrapper["run_id"]]["ascension"]


def state_view(wrapper):
    row = wrapper["row"]
    state = row["state"]
    run = rec(state.get("run"))
    combat = rec(state.get("combat"))
    player = rec(combat.get("player"))
    return {
        "reference": {k: wrapper[k] for k in ["source", "line", "offset", "bytes", "sha256", "run_id"]},
        "observed_ts": row.get("observed_ts"), "floor": run.get("floor"), "turn": state.get("turn"),
        "screen": state.get("screen"), "hp": player.get("current_hp", run.get("current_hp")),
        "run_hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "block": player.get("block"), "energy": player.get("energy"),
        "cards_played": player.get("cards_played_this_turn"), "powers": powers(player.get("powers")),
        "potions": run.get("potions"),
        "hand": [{k: c.get(k) for k in ["card_id", "upgraded", "energy_cost", "playable", "unplayable_preventer_id", "resolved_rules_text"]} for c in combat.get("hand") or []],
        "enemies": [{k: e.get(k) for k in ["index", "enemy_id", "current_hp", "max_hp", "is_alive", "powers", "intents"]} for e in combat.get("enemies") or []],
        "piles": rec(rec(state.get("agent_view")).get("combat")),
        "deck_upgrades": [c for c in run.get("deck") or [] if c.get("upgraded")],
    }


state_lines = {
    223268, 223272, 288236, 288237, 288406, 288407, 288408, 288409, 288426, 288430, 288472,
    289339, 289345, 289414, 289420, 289533, 289534, 289535, 289536, 289537, 289538,
    289986, 289987, 290160, 290165, 290201, 290206, 290212, 290213, 290214,
}
selected = [state_view(x) for x in streams["states"] if x["line"] in state_lines]
assert state_lines <= {x["reference"]["line"] for x in selected}, state_lines - {x["reference"]["line"] for x in selected}
save("key-states.json", selected)
decision_lines = {281977, 282578, 282579, 282929, 282864, 282899, 282933, 282968, 283001, 283035, 283641, 283680, 283690, 283691, 218927, 218928}
decisions = [x for x in streams["decisions"] if x["line"] in decision_lines]
assert decision_lines <= {x["line"] for x in decisions}
save("key-decisions.json", decisions)
save("gx-draw-records.json", [x for x in streams["sl-attempts"] if x["run_id"] == "GXNKW8X1XYJP"])

index = {x["reference"]["line"]: x for x in selected}
facts = {
    "kfr_t6_pair": [{"start": index[a], "end": index[b]} for a, b in [(289339, 289345), (289414, 289420)]],
    "gx_t2_pair": [{"start": index[a], "end": index[b]} for a, b in [(290160, 290165), (290201, 290206)]],
    "kfr_t7_poison": {"before": index[289536], "after": index[289537], "settled": index[289538]},
    "gx_t5_poison": {"before": index[289986], "after": index[289987]},
    "act_boundary_7x": {"before": index[288236], "after": index[288237]},
    "limitations": ["端点净变化不是逐击入伤或完整候选因果。", "同局读档不是独立样本；未记录的后继保持未知。"],
}
save("paired-facts.json", facts)
summary = {
    "runs": [{"run_id": key, "character": value["character"], "ascension": value["ascension"], "code": value.get("code"), "victory": value.get("victory")} for key, value in runs.items()],
    "references": sum(x["verified_references"] for x in verification),
    "counts": {x["stream"]: x["counts"] for x in verification},
    "key_state_lines": sorted(state_lines), "key_decision_lines": sorted(decision_lines),
}
save("material-summary.json", summary)
print(json.dumps(summary, ensure_ascii=False))

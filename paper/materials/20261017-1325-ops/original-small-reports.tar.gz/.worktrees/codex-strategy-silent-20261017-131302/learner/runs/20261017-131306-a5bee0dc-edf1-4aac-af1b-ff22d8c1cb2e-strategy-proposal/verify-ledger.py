import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '-Is'], text=True).strip()
receipt = json.loads((S / 'ledger-cli-receipt.json').read_text())
assert receipt['exit_code'] == 0
updates = [json.loads(line) for line in (S / 'ledger-updates.jsonl').read_text().splitlines()]
expected = {item['id']: item for item in updates}
assert len(expected) == len(updates) == 26
assert set((S / 'ledger-cli.stdout').read_text().split()) == set(expected)
cut = json.loads((S / 'ledger-prefix-before-cli.json').read_text())
old_cut = json.loads((S / 'ledger-cut.json').read_text())
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
with ledger_path.open('rb') as stream:
    end = ledger_path.stat().st_size
    contents = stream.read(end)
assert hashlib.sha256(contents[:cut['source_size']]).hexdigest() == cut['sha256']
assert hashlib.sha256(contents[:old_cut['source_size']]).hexdigest() == old_cut['prefix_sha256']
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
folded = {}
own_rows = []
concurrent = []
offset = 0


def protected(item):
    return {k: copy.deepcopy(v) for k, v in item.items() if k not in {'where', 'notes', 'history'}}


for raw in contents.splitlines(keepends=True):
    assert raw.endswith(b'\n')
    row = json.loads(raw)
    lid = row.get('id')
    if lid in expected:
        note = row.get('note') or ''
        is_own = offset >= cut['source_size'] and row.get('by') == 'learner:strategy-proposal' and note == expected[lid]['note']
        before = protected(folded[lid]) if lid in folded else None
        if is_own:
            assert set(row) == {'op', 'id', 'ts', 'by', 'where', 'note'}
            assert {k: v for k, v in row.items() if k not in {'op', 'ts'}} == expected[lid]
            assert row['op'] == 'update'
        module.apply(folded, row)
        if is_own:
            assert before == protected(folded[lid])
            own_rows.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'row': row, 'protected_fields_unchanged': True})
        elif offset >= cut['source_size']:
            concurrent.append({'id': lid, 'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'fields': list(row)})
    offset += len(raw)
assert len(own_rows) == 26 and {x['row']['id'] for x in own_rows} == set(expected)
result = {'at': stamp, 'cli_exit_code': 0, 'requested_rows': 26, 'verified_own_rows': len(own_rows), 'pre_cli_prefix_unchanged': True, 'initial_prefix_unchanged': True, 'source_size_at_verification': end, 'rows': own_rows, 'other_selected_id_updates_after_cut': concurrent, 'scope': '仅逐本批实际追加行比较fold保护字段，允许并行记录，不覆盖或代写其他角色状态。'}
(S / 'ledger-append-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['at', 'cli_exit_code', 'verified_own_rows', 'pre_cli_prefix_unchanged', 'initial_prefix_unchanged']}, ensure_ascii=False))

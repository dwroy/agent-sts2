# 静默策略学习：十项仍待证据，不改策略

记录时间：2026-10-17T13:22:27+08:00。batch=20261017-131302-strategy-proposal，character=silent。十项逐项核验后均waiting；当前原始证据没有新增独立局/完整后继，未发现可由本批数据校准的新策略参数或新的确定数值缺口。fixes=[]、merged=null、implementation_domains=[]。未修改源码、知识或任一角色行为，未提交、合入live、发布版本或登记shipped。详细证据/账本/反例/旧规则/预期行为/验证/回退见同目录proposal.md。

## 身份、基线与证据

先git status确认干净，必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol及learning-code-proposals；已读取本批learn.json唯一对应行，task/character/worktree/running/十id均匹配。没有专题/实现请求，不读取另一专题替代身份。按普通任务合main后仍为完整40位base=fe8b000d766058c687c3ca022333b9feb254cdcf，结束HEAD保持此值。没有下级agent、联网、LLM调用、play或新的模拟。

六局VLZ6CCT8AQ0A, 8JRE1C4H4Z2W, CA5KE8GFJ9X2, 5PM6JAQG6FNQ, 61E2QS63Y9WU, DUZUBAJ3A8GP均已结束Silent A10，只分析这六局；源代码code全部带dirty，不能凭Git hash复原当时全输入。当前相关19个静默经验条目只读，未把其后续支持数算成本批新实测。原提案10份保存原字节且SHA全部匹配，不改队列原文、不新建重复id、不读其他角色私有知识。

共用入口抽取七流6,995封套并逐一读回原offset/bytes/SHA/显式身份/JSON，见evidence-verification.json；828相关状态及800决策投影、局部动作前后帧另存selected-state-facts.json、selected-decision-facts.json、focused-action-facts.json。各流独立冻结，不能冒同一原子cut。states/decisions/brain全源各有2条无效JSON，不归为这六局的丢失证据。

| 流 | source_size字节 | 本六局记录 |
|---|---:|---:|
| states | 13869235334 | 3432 |
| decisions | 2209788102 | 3306 |
| sl-attempts | 45190317 | 29 |
| run-config | 1944926 | 6 |
| run-plans | 8860505 | 33 |
| brain | 735150423 | 183 |
| runs | 356728 | 6 |

run-plans按run及其他显式身份读取，本cut六局33条，不因总日志增长增加独立样本。没有零行推断原日志缺失，也没有覆盖旧截点报告或初稿。

## 消费者读回与源码边界

本批90项材料核验通过：原提案指纹、七流原字节/计数、六局完整输入相等、五个消费者递归依赖SHA、九份完整/有界结果及失败回执SHA、11窄源码祖先。材料核验不是生产测试，不填为tsc/vitest成功。consumer-reuse-verification.json保存复用路径与逐文件SHA：三份完整成功，CA5/61E/DUZU完整输入分别因原物理d267143、d267517、d268789/268818/268864缺decision_id真实拒收；有界输入只删五行，保留缺口。未重新跑旧消费者、模拟或测试，也未造ID/放宽消费者。

复用原结果合计3,301有ID动作、476候选片段、859相邻端点、4终页端点、121整轮端点、413未知轮窗。476片段actual_full_candidate_result均null只代表没有认证整条候选，不能说候选从未执行、没有任何可核端点或机制已失败。这是原回执的复用读回，没有新受控整战反事实或时间后移验证。

关键复核：VLZ神化升级实际与持有分账；F45末32HP/20挡/59攻击不能将截断血损当完整需损39。8JRE F33 T2同fingerprint，多12血损/多7伤、0/24与5/24不并列；护栏预测与重问后整轮端点分账。CA5末2血10挡对14仍死，荆棘另源。5PM冒泡无毒实付1能而目标35/0毒不变。61E负敏捷双防各3、毒端点67→34；F23幻象仍余2不作已退场。DUZU临减恢复与持续增力分列，四试不扩独立局数。上述均为已用于发现的旧局，不产生新的support/repeat。

当前源码15叶相对前批12相同/3变更，H0两rollout叶和预算解析loop差异保原patch，不冒全树等价；相对实际live快照6fbbd82abd6d407dbaf93f82639b7f927efa54a0，11同字节、4仅历史署名词差，详source-snapshot.json。神化实际施放仍null、派发state_effect_verified=false/whole_plan_executed=null。11个明确窄源均为base/live祖先：772b839f、f516592f、b2805be4、ba23ca69、3aa6c03a、05cd292c、a8b1f8be、fdaf787a、1e076b17、cf72bd21、7af803c0；完整40位及作用域见existing-live-ancestors.json。它们是旧局部交付，不能登记本批整个原提案implemented/duplicate。H1工程预算不当药水MC分阶段收益或药价验证。

## 每个派发id的结果

| 原id | 处置 | 具体缺口 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺跨抽牌、选牌、用药、重问、SL及换战的实际施放持续身份与生产读回；未覆盖升级交互没有本批新实测。既有配对转换不能证明整项完成。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池、同总预算的分阶段MC配对与样本成熟曲线，亦缺留药及另一focus的完整后继；H1工程发布不能充作本提案收益证明。 |
| silent-proposal-283a164780d11e69 | waiting | 同源神化请求仍缺跨中断的实际施放归属及未知升级组合校准；没有覆盖全部原请求的实际live源码提交，不能登记duplicate。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五子项逐来源属性、升级组合、期限及战斗—路线—休息的联合生产校准；本批原帧没有隔离出新的确定数值失配，局部实现不足关闭整条复合请求。 |
| silent-proposal-e5b87be50f28f311 | waiting | 缺跨抽牌、选择、用药、重问、SL的完整候选持续归属和全过程生产校准；原113个片段的actual_full_candidate_result均为null，不能据此认成长收益或整战改线因果。 |
| silent-proposal-49632bc4878fb597 | waiting | 缺逐击力量、正负敏捷、虚弱与独立成长四路径在同一冻结生产调用中的联合校准；本局未实测正敏捷，也未发现新的确定子公式失配。 |
| silent-proposal-66532328a585941f | waiting | 缺相同HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照及可复现收益函数；局部空打端点不足拟合启动阈值或构筑权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP、构筑、完整抽序的生产整战配对与另一可核SL线路；负敏捷及毒端点不足支持变更SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤源码和T4净扣不能证明目标排序整战收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕接续及当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次相关失败不足拟合血价、全败排序或固定杀序。 |

## 账本、验证与交付

仅通过根learner/ledger.py update为相关26条静默账本追加本批proposal/report的where链接和note，by=learner:strategy-proposal，不改claim/首证/进阶/prior/evidence/status/version/shipped/effect。既有shipped不降级为proposed；本批没有新发现条目需要add。CLI输入、stdout/stderr及逐物理行保护字段核验保存在本目录。队列proposal_results由最终JSON交原调度器，不直接修改队列或learn.json。

没有生产源码变更，撤源码失败/恢复通过不适用，tests={"tsc":null,"vitest":null,"cases":null}。未运行生产套件、未造绿色结果或把旧宿主绿算本批通过。没有源码提交，也不制造署名/合入/版本/decision-log上线行/规则双通知。报告及输入完成脱敏gitleaks检查，结果另存。所有scratch、旧失败与原日志保留；工作树保持干净。当前没有新机制异议、反证或与旧知识冲突，不重复发旧通知。

保留本批探索错误：尝试查看并不存在的learner/tools/selection-execution.ts时sed返回2，随后定位已有learner/lib入口；没有修改产品或验收条件。原消费者三份完整输入拒收和前批初稿错误均保留原件，不借成功复用抹历史。

限制：只有六局历史发现证据，未知原dirty输入/随机池、跨中断候选归属、未选完整线路和受控收益；不得把账本链接/报告/批次结束当经验库新发布、大脑实际采用或父要求完成。原生模型/强度/计费档由宿主回执核，本批没有读取凭据、修改权限/模型或拿默认配置冒原生证明。

运维提案绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-131302/learner/runs/20261017-131306-a5bee0dc-edf1-4aac-af1b-ff22d8c1cb2e-strategy-proposal/proposal.md。报告绝对路径：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-131302/learner/runs/20261017-131306-a5bee0dc-edf1-4aac-af1b-ff22d8c1cb2e-strategy-proposal/report.md。最终结构化回报另存final-report.json。

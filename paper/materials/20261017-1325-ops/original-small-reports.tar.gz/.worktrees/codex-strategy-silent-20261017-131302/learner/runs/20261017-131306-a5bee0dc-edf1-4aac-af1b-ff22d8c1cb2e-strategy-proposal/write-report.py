import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
W = S.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
BATCH = '20261017-131302-strategy-proposal'
stamp = subprocess.check_output(['date', '-Is'], text=True).strip()
dispatch = json.loads((S / 'dispatch.json').read_text())
base = dispatch['heads']['HEAD']
runs = dispatch['batch']['runs']
adds = {x['item']['id']: x['item'] for x in json.loads((S / 'queue-history.json').read_text()) if x['item'].get('op') == 'add'}
items = [
    ('89354805ee4d7e77', '神化的实际施放与候选升级',
     'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；s275564→275565、s275679→275687，d269706/269707/269748/269754。',
     'F35神化7→5能，防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费；F43后轮牌仍升级、场外deck升级数保持4。F45持有而未施放，不能预支升级。',
     '已有普通神化配对和候选参考字段；turn-solver仍将虚弱、脆弱、缩小、暗影、重放/自动出牌组合标未知，actual_cast_this_fight仍为null。',
     '缺跨抽牌、选牌、用药、重问、SL及换战的实际施放持续身份与生产读回；未覆盖升级交互没有本批新实测。既有配对转换不能证明整项完成。',
     '仅由实测配对传播升级，已施放、候选模拟及场外牌组分账；冻结上述状态验证未知边界，后续独立A10局验证持续归属，不增加必打或固定加分规则。'),
    ('f2bfceddb1898dca', '三骑士药水预算与全败候选',
     'VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5；d269748/269754/269770，s275722/275731/275732/275752/275754。',
     'F45首题horizon1/samples1/best=null是退化；T4攻击候选32伤/31损与实选24伤/13损没有整战反事实。T5三敌未退出，32血20挡对59入伤的完整需损为39，观察到的归零血量不是39实扣。',
     '已有药水样本/退化字段及H1工程预算；当前不能照搬旧707ms描述全局现状。工程截止和候选数量不等于药水分阶段分配已量化。',
     '缺完整模型下同起点、同随机池、同总预算的分阶段MC配对与样本成熟曲线，亦缺留药及另一focus的完整后继；H1工程发布不能充作本提案收益证明。',
     '保持现有药价、护栏及目标选择；在模型覆盖完整后，以同盘同预算记录样本曲线和候选稳定性，药水实抽后再核，不把局部样本当胜负。'),
    ('283a164780d11e69', '经验来源的同源神化请求',
     'VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；证据与89354805ee4d7e77相同。',
     '该原经验只支持已观测升级与持有/施放分账；四次施放是同一独立局内重复，不能当四局。',
     '与原postmortem提案共享窄源码；原id和经验链保持，不重新注册或把同源pending项冒称已在live完整重复实现。',
     '同源神化请求仍缺跨中断的实际施放归属及未知升级组合校准；没有覆盖全部原请求的实际live源码提交，不能登记duplicate。',
     '沿原id与原证据去重后续实现，验证及未知保持方式同前项；不另建重复代码提案。'),
    ('ebbfe3b97548756d', '十五子项攻防与资源分账',
     'VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5及F44回血；s275737→275738、s275752/275754。',
     '口红T3使力1→2、敏0→1，步法后总3敏；F45后空翻8、防御12，勒紧4只用于防御。覆甲末轮已无；临减6影响四攻击段但不停止后续成长。',
     '十五关联经验和26账本只作原链核对；逐击属性、毒触发、路线/休息各有局部实现，不将综合条目支持局数当同一公式的独立实验分母。',
     '缺十五子项逐来源属性、升级组合、期限及战斗—路线—休息的联合生产校准；本批原帧没有隔离出新的确定数值失配，局部实现不足关闭整条复合请求。',
     '逐源冻结手牌、属性、已结算毒、当前覆甲及资源后继；发现明确数值失配才补静默路径。休息/路线无受控对照，保持选择规则。'),
    ('e5b87be50f28f311', 'SL与HP护栏的候选—实际审计',
     '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11，F17 T6；d270216/270282/270264。',
     'T2两题fingerprint完全相同，SL替换本轮多12血损、多7敌净扣；0/24与5/24死亡不能并列。第二试T5护栏题面省12血少18伤，重问后的整轮端点不全归单次替换；六试仍为一独立局。',
     '已存在三阶段快照、护栏审计、单动作回执及离线消费者；scope分别是predicted_candidates、single_action_receipt和观测端点，均未认证完整候选。',
     '缺跨抽牌、选择、用药、重问、SL的完整候选持续归属和全过程生产校准；原113个片段的actual_full_candidate_result均为null，不能据此认成长收益或整战改线因果。',
     '保留候选与实际端点分账，API回执不当生效证明；补齐重规划与能力建立归属后再做固定红绿验证。不改血价、护栏、SL范围或成长优先级。'),
    ('49632bc4878fb597', '力量、敏捷、虚弱及蚌成长',
     'CA5KE8GFJ9X2 F13 T2—T5；s273251→273252、s273262→273263、s273268→273269，d267371/267380/267385。',
     '两次加压后力量4/8、喷水15/19，施弱后末轮14攻，2血10挡完整需损4而显示血量只扣2。敌死前荆棘使19→16，不能将其归直伤或毒。',
     '已有属性与成长模型；该局没有建立计划中的正敏捷。完整离线消费者因原d267143缺decision_id拒收，有界输入只删该行而保物理缺口，不能冒称完整输入通过。',
     '缺逐击力量、正负敏捷、虚弱与独立成长四路径在同一冻结生产调用中的联合校准；本局未实测正敏捷，也未发现新的确定子公式失配。',
     '保持当前属性公式与成长取表；按当前进阶冻结数据库与原帧逐步比对。不能用单个步法源码祖先证明复合请求全部实现。'),
    ('66532328a585941f', '启动组件的实付与兑现',
     '5PM6JAQG6FNQ F39第二试T2，d268455、s274379→274380；F33已建立组件的胜战仅作有条件对照。',
     '无毒目标上冒泡实付能量5→4，目标35HP与无毒状态保持。持有雾和触媒不代表本战已经建立；F33与F39敌人、资源与抽序不同。',
     '原消费者完整输入638动作/83片段可读回，完整候选归属仍未认证；不能以构筑文字计划替代实盘建立。',
     '缺相同HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照及可复现收益函数；局部空打端点不足拟合启动阈值或构筑权重。',
     '沿持有、到手、实付、建立与后继分账，先核真实可活窗口；不增加固定早打、保血或输出权重。'),
    ('43a76a31ba7bdcfa', '族母吸取、负敏捷与毒',
     '61E2QS63Y9WU F17 T5/T6；s273503→273508，d267611/267612/267614。',
     '吸取后玩家力2→0、敏0→−2，敌力0→2；双防御各3，触媒1下17毒端点67→34。首试胜只支持这些条件下的事实，不提供另一可救线路。',
     '现有负敏捷与毒路径分开；完整离线输入因d267517缺decision_id拒收，有界结果保留原行缺口。',
     '缺同起始HP、构筑、完整抽序的生产整战配对与另一可核SL线路；负敏捷及毒端点不足支持变更SL范围或阈值。',
     '固定吸取、牌挡、已结毒和临减恢复分别校准；保留现有SL与换线规则，不能据本局首试获胜拟合新偏好。'),
    ('5264153a4a4b0e5c', '胧光怪召唤、成长与退场',
     '61E2QS63Y9WU F23 T4/T5；d267696、s273593—273598。',
     'T4本体76→41、幻象14→2，合净扣47而幻象仍能攻击；原另一focus题面39伤/零损未实打。各实体成长和实际退出窗口不能合成一个总伤害。',
     '已有活体召唤窄源码祖先；离线消费者此窗口为unknown仍保原帧端点，不把unknown解释为日志完全不存在。',
     '缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤源码和T4净扣不能证明目标排序整战收益。',
     '按当前进阶敌方数据逐实体核召唤/意图/剩血，保留全部目标；推演相同者并列，不强制先杀幻象或本体。'),
    ('bddfa690a84e03d0', '熟睡甲虫唤醒与持续成长',
     'DUZUBAJ3A8GP F30四试T4—T6；末试s275012→275023，d269067/269072/269077。',
     '末试T4 24挡实损4，首试26挡实损2，多3敌净扣仍有2血价；T5临减后力−4、14攻，T6恢复并成长至4力22攻。末1血16挡完整需损6，血量截断不是完整入伤。',
     '四次失败相关，不能扩为四独立局；完整消费者因d268789/268818/268864缺decision_id拒收，限定输入保缺口。',
     '缺伤害唤醒、眩晕接续及当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次相关失败不足拟合血价、全败排序或固定杀序。',
     '睡眠、失血唤醒、眩晕与独立增力逐步核；保留未知和现有排序，不以全败抹掉实际血价。'),
]

results = []
sections = []
for short, title, evidence, facts, existing, reason, validation in items:
    pid = 'silent-proposal-' + short
    original = adds[pid]
    results.append({'id': pid, 'state': 'waiting', 'reason': reason})
    sections.append(f'''## {pid}：{title}

来源：{original['source_task']} → strategy-proposal；账本：{', '.join(original['ledger'])}；角色silent，观察进阶A10。原Markdown：{original['proposal']}；SHA256={original['proposal_sha256']}，本批逐字副本为{pid}-original.md。

证据局号、层、回合与原物理行：{evidence}

核实事实及反例：{facts}

旧规则/现有覆盖：{existing}

处置waiting：{reason}

预期行为与验证：{validation} 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。
''')

proposal = f'''# 静默策略：十项原提案的本批证据处置

记录时间：{stamp}。batch={BATCH}；task=strategy-proposal；character=silent。完整base={base}。

本批十项均waiting。只处理learn.json明确领取的十个id，无proposal_repair、research_request或implementation_request；普通专题请求绑定其他批次，未转为专题。git初始干净，git merge --no-edit main返回Already up to date，HEAD不变。没有源码、知识、规则或参数改动；没有新增代码提案id、源码提交、合入、版本或shipped。

证据只使用六派发局：{', '.join(runs)}。runs.jsonl均核Silent A10；SL次数、同局帧和十五子机制不扩独立局数。原提案引用的其他旧局只保其原文出处，本批不将其算作已重新分析的局。

共用extract_evidence.py提取七流；每流独立source_size、每行offset/bytes/SHA及计数保存在evidence/。6,995封套逐行原日志读回、身份一致；不从正文提及认领局号。六局封套、完整消费者输入及五递归依赖与111303前批相同，核验见consumer-reuse-verification.json。只复用原回执，没有重新运行消费者/模拟。原缺decision_id的三份完整输入真实失败与相应有界输入全部保留在原路径，不能以有界成功替代完整成功。

当前源码15叶与前批12同字节，rollout.ts、rollout-live.ts、hand/loop.ts有已发布变更，补丁逐字保存在source-since-prior.patch.txt。其中H0为明确A2上下文，非本批A10证据；loop为预算到期解析标记。不能冒整树不变。当前live快照6fbbd82abd6d407dbaf93f82639b7f927efa54a0；15叶中11同字节、4仅独立单词Roy/Dai历史署名差。11个既有窄源码commit均重新核为本base/live祖先，见existing-live-ancestors.json；不把窄祖先当整个请求已实现。

统一边界：Roy-2026-10-07-learning提供修改授权，不提供游戏事实；证据不足保留规则。本批不拟合血价、药价、启动权重、SL/终局阈值或固定杀序。不新增机制异议/反证；原限制不强行支持为规则。其他角色行为没有修改。

''' + '\n'.join(sections)
(S / 'proposal.md').write_text(proposal)

manifest = json.loads((S / 'evidence/evidence-manifest.json').read_text())
stream_table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} |" for m in manifest)
result_table = '\n'.join(f"| {x['id']} | waiting | {x['reason']} |" for x in results)
report = f'''# 静默策略学习：十项仍待证据，不改策略

记录时间：{stamp}。batch={BATCH}，character=silent。十项逐项核验后均waiting；当前原始证据没有新增独立局/完整后继，未发现可由本批数据校准的新策略参数或新的确定数值缺口。fixes=[]、merged=null、implementation_domains=[]。未修改源码、知识或任一角色行为，未提交、合入live、发布版本或登记shipped。详细证据/账本/反例/旧规则/预期行为/验证/回退见同目录proposal.md。

## 身份、基线与证据

先git status确认干净，必读README、最新STATE-2026-10-17、decision-log末尾、learning-protocol及learning-code-proposals；已读取本批learn.json唯一对应行，task/character/worktree/running/十id均匹配。没有专题/实现请求，不读取另一专题替代身份。按普通任务合main后仍为完整40位base={base}，结束HEAD保持此值。没有下级agent、联网、LLM调用、play或新的模拟。

六局{', '.join(runs)}均已结束Silent A10，只分析这六局；源代码code全部带dirty，不能凭Git hash复原当时全输入。当前相关19个静默经验条目只读，未把其后续支持数算成本批新实测。原提案10份保存原字节且SHA全部匹配，不改队列原文、不新建重复id、不读其他角色私有知识。

共用入口抽取七流6,995封套并逐一读回原offset/bytes/SHA/显式身份/JSON，见evidence-verification.json；828相关状态及800决策投影、局部动作前后帧另存selected-state-facts.json、selected-decision-facts.json、focused-action-facts.json。各流独立冻结，不能冒同一原子cut。states/decisions/brain全源各有2条无效JSON，不归为这六局的丢失证据。

| 流 | source_size字节 | 本六局记录 |
|---|---:|---:|
{stream_table}

run-plans按run及其他显式身份读取，本cut六局33条，不因总日志增长增加独立样本。没有零行推断原日志缺失，也没有覆盖旧截点报告或初稿。

## 消费者读回与源码边界

本批90项材料核验通过：原提案指纹、七流原字节/计数、六局完整输入相等、五个消费者递归依赖SHA、九份完整/有界结果及失败回执SHA、11窄源码祖先。材料核验不是生产测试，不填为tsc/vitest成功。consumer-reuse-verification.json保存复用路径与逐文件SHA：三份完整成功，CA5/61E/DUZU完整输入分别因原物理d267143、d267517、d268789/268818/268864缺decision_id真实拒收；有界输入只删五行，保留缺口。未重新跑旧消费者、模拟或测试，也未造ID/放宽消费者。

复用原结果合计3,301有ID动作、476候选片段、859相邻端点、4终页端点、121整轮端点、413未知轮窗。476片段actual_full_candidate_result均null只代表没有认证整条候选，不能说候选从未执行、没有任何可核端点或机制已失败。这是原回执的复用读回，没有新受控整战反事实或时间后移验证。

关键复核：VLZ神化升级实际与持有分账；F45末32HP/20挡/59攻击不能将截断血损当完整需损39。8JRE F33 T2同fingerprint，多12血损/多7伤、0/24与5/24不并列；护栏预测与重问后整轮端点分账。CA5末2血10挡对14仍死，荆棘另源。5PM冒泡无毒实付1能而目标35/0毒不变。61E负敏捷双防各3、毒端点67→34；F23幻象仍余2不作已退场。DUZU临减恢复与持续增力分列，四试不扩独立局数。上述均为已用于发现的旧局，不产生新的support/repeat。

当前源码15叶相对前批12相同/3变更，H0两rollout叶和预算解析loop差异保原patch，不冒全树等价；相对实际live快照6fbbd82abd6d407dbaf93f82639b7f927efa54a0，11同字节、4仅历史署名词差，详source-snapshot.json。神化实际施放仍null、派发state_effect_verified=false/whole_plan_executed=null。11个明确窄源均为base/live祖先：772b839f、f516592f、b2805be4、ba23ca69、3aa6c03a、05cd292c、a8b1f8be、fdaf787a、1e076b17、cf72bd21、7af803c0；完整40位及作用域见existing-live-ancestors.json。它们是旧局部交付，不能登记本批整个原提案implemented/duplicate。H1工程预算不当药水MC分阶段收益或药价验证。

## 每个派发id的结果

| 原id | 处置 | 具体缺口 |
|---|---|---|
{result_table}

## 账本、验证与交付

仅通过根learner/ledger.py update为相关26条静默账本追加本批proposal/report的where链接和note，by=learner:strategy-proposal，不改claim/首证/进阶/prior/evidence/status/version/shipped/effect。既有shipped不降级为proposed；本批没有新发现条目需要add。CLI输入、stdout/stderr及逐物理行保护字段核验保存在本目录。队列proposal_results由最终JSON交原调度器，不直接修改队列或learn.json。

没有生产源码变更，撤源码失败/恢复通过不适用，tests={{"tsc":null,"vitest":null,"cases":null}}。未运行生产套件、未造绿色结果或把旧宿主绿算本批通过。没有源码提交，也不制造署名/合入/版本/decision-log上线行/规则双通知。报告及输入完成脱敏gitleaks检查，结果另存。所有scratch、旧失败与原日志保留；工作树保持干净。当前没有新机制异议、反证或与旧知识冲突，不重复发旧通知。

保留本批探索错误：尝试查看并不存在的learner/tools/selection-execution.ts时sed返回2，随后定位已有learner/lib入口；没有修改产品或验收条件。原消费者三份完整输入拒收和前批初稿错误均保留原件，不借成功复用抹历史。

限制：只有六局历史发现证据，未知原dirty输入/随机池、跨中断候选归属、未选完整线路和受控收益；不得把账本链接/报告/批次结束当经验库新发布、大脑实际采用或父要求完成。原生模型/强度/计费档由宿主回执核，本批没有读取凭据、修改权限/模型或拿默认配置冒原生证明。

运维提案绝对路径：{S / 'proposal.md'}。报告绝对路径：{S / 'report.md'}。最终结构化回报另存final-report.json。
'''
(S / 'report.md').write_text(report)
final = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': base, 'runs': runs, 'fixes': [], 'skipped': [], 'merged': None, 'tests': {'tsc': None, 'vitest': None, 'cases': None}, 'code_proposals': dispatch['batch']['proposal_ids'], 'implementation_domains': [], 'proposal_results': results, 'report': str(S / 'report.md')}
(S / 'final-report.json').write_text(json.dumps(final, ensure_ascii=False, indent=2) + '\n')
ledger = json.loads((S / 'ledger-before.json').read_text())
updates = []
for lid in sorted(ledger):
    related = [x['id'] for x in adds.values() if lid in x.get('ledger', [])]
    updates.append({'id': lid, 'by': 'learner:strategy-proposal', 'where': {'proposal': [str(S / 'proposal.md'), str(S / 'report.md')]}, 'note': f'{BATCH}：仅本批10原id处置与追溯，关联{"、".join(related)}均waiting。六Silent A10局6995原封套重核，输入/消费者SHA同旧回执复用；没有新support/repeat、策略/状态/版本/收益认定。具体缺口见本批proposal.md，不将窄祖先当整个原请求兑现。'})
(S / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'date': stamp, 'proposal': str(S / 'proposal.md'), 'report': str(S / 'report.md'), 'waiting': len(results), 'ledger_updates_prepared': len(updates)}, ensure_ascii=False))

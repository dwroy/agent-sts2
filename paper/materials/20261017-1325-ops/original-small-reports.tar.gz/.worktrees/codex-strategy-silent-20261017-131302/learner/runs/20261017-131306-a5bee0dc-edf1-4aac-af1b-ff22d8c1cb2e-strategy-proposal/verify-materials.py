import collections
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

SCRATCH = Path(__file__).resolve().parent
WORKTREE = SCRATCH.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261017-111303/learner/runs/20261017-111311-8561b145-c866-479f-afb0-9690778f8b1a-strategy-proposal'


def read(path):
    return json.loads(Path(path).read_text())


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORKTREE), *args])


checks = []


def check(label, condition):
    checks.append({'name': label, 'passed': bool(condition)})
    if not condition:
        save('material-checks.failed.json', checks)
        raise AssertionError(label)


dispatch = read(SCRATCH / 'dispatch.json')
batch = dispatch['batch']
runs = batch['runs']
base = dispatch['heads']['HEAD']
check('六派发局和十个提案身份无重复', len(runs) == len(set(runs)) == 6 and len(batch['proposal_ids']) == len(set(batch['proposal_ids'])) == 10)
check('HEAD仍为本批基线', git('rev-parse', 'HEAD').decode().strip() == base)
check('工作树无跟踪或可见未跟踪改动', not git('status', '--porcelain').strip())
adds = [entry['item'] for entry in read(SCRATCH / 'queue-history.json') if entry['item'].get('op') == 'add']
for item in adds:
    raw = (SCRATCH / (item['id'] + '-original.md')).read_bytes()
    check(item['id'] + ' 原提案SHA和角色', sha(raw) == item['proposal_sha256'] and item['character'] == 'silent')

spec = importlib.util.spec_from_file_location('extract_evidence', WORKTREE / 'learner/extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
streams = {}
references = []
manifest = read(SCRATCH / 'evidence/evidence-manifest.json')
for info in manifest:
    name = info['stream']
    path = SCRATCH / 'evidence' / (name + '.evidence.jsonl')
    raw = path.read_bytes()
    check(name + ' 抽取产物SHA', sha(raw) == info['output_sha256'])
    envelopes = [json.loads(line) for line in raw.splitlines()]
    counts = collections.Counter()
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source:
        for item in envelopes:
            check_identity = module.run_identity(item['row'])
            if check_identity != item['run_id'] or check_identity not in runs:
                raise AssertionError('证据身份失配')
            source.seek(item['offset'])
            original = source.read(item['bytes'])
            if sha(original) != item['sha256'] or json.loads(original) != item['row']:
                raise AssertionError('证据原字节失配')
            if item['offset'] + item['bytes'] > info['source_size']:
                raise AssertionError('越过冻结字节范围')
            references.append({key: item[key] for key in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']})
            counts[item['run_id']] += 1
    check(name + ' 逐行原日志/身份/截点及计数', dict(counts) == {k: v for k, v in info['counts'].items() if v})
    old_path = PRIOR / 'evidence' / (name + '.evidence.jsonl')
    if old_path.exists():
        old = [json.loads(line) for line in old_path.open() if module.run_identity(json.loads(line)['row']) in runs]
        check(name + ' 六局原封套与前批相同', old == envelopes)
    streams[name] = envelopes
save('evidence-verification.json', {'verified_envelopes': len(references), 'references': references, 'streams': manifest})
run_rows = {item['run_id']: item['row'] for item in streams['runs']}
check('六局均为已完成Silent A10', set(run_rows) == set(runs) and all(x['character'].lower() == 'silent' and x['ascension'] == 10 for x in run_rows.values()))
save('runs-verified.json', run_rows)

# Reuse only exact old inputs and exact transitive consumer source bytes.
consumer_sources = read(PRIOR / 'consumer-source-manifest.json')
for item in consumer_sources:
    check('消费者源码 ' + item['path'], sha((WORKTREE / item['path']).read_bytes()) == item['sha256'])
save('consumer-source-manifest.json', consumer_sources)
old_input_manifest = read(PRIOR / 'consumer-input-manifest.json')
prior_artifacts = {item['path']: item for item in read(PRIOR / 'artifact-manifest.json')}
reused = []
for item in old_input_manifest:
    run = item['run_id']
    frozen = Path(item['path']).read_bytes()
    check(run + ' 原完整消费者输入SHA', sha(frozen) == item['sha256'])
    old = json.loads(gzip.decompress(frozen))
    current = {'run': run_rows[run]}
    for name in ['states', 'decisions']:
        current[name] = [{**x['row'], '_line': x['line']} for x in streams[name] if x['run_id'] == run]
    check(run + ' 本批抽取与原消费者完整输入相同', current == old)
    for kind in ['full'] + (['bounded'] if item.get('bounded_path') else []):
        prefix = run + '.consumer-' + kind
        receipt_path = PRIOR / (prefix + '.receipt.json')
        receipt = read(receipt_path)
        entries = []
        for suffix in ['.receipt.json', '.stderr'] + (['.output.json.gz'] if receipt['exit_code'] == 0 else []):
            name = prefix + suffix
            contents = (PRIOR / name).read_bytes()
            check(name + ' 原产物SHA', sha(contents) == prior_artifacts[name]['sha256'])
            entries.append({'path': str(PRIOR / name), 'bytes': len(contents), 'sha256': sha(contents)})
        if kind == 'bounded':
            bounded_bytes = Path(item['bounded_path']).read_bytes()
            check(run + ' 有界输入SHA与精确过滤范围', sha(bounded_bytes) == item['bounded_sha256'] and json.loads(gzip.decompress(bounded_bytes)) == {**current, 'decisions': [x for x in current['decisions'] if x.get('decision_id')]})
        reused.append({'run_id': run, 'kind': kind, 'receipt': receipt, 'artifacts': entries, 'new_consumer_execution': False})
save('consumer-reuse-verification.json', {'prior': str(PRIOR), 'basis': '本批六局完整输入逐对象相同，五个消费者依赖SHA相同；仅读回原结果，不重跑旧套件或模拟。', 'results': reused})

live = git('rev-parse', 'live').decode().strip()
old_source = read(PRIOR / 'source-snapshot.json')
snapshot = []
for entry in old_source['files']:
    path = entry['path']
    contents = (WORKTREE / path).read_bytes()
    live_contents = git('show', live + ':' + path)
    snapshot.append({'path': path, 'sha256': sha(contents), 'prior_sha256': entry['sha256'], 'same_prior_bytes': sha(contents) == entry['sha256'], 'live_sha256': sha(live_contents), 'same_live_bytes': contents == live_contents,
                     'source_live_roy_dai_only': re.sub(rb'\b(?:Roy|Dai)\b', b'PERSON', contents) == re.sub(rb'\b(?:Roy|Dai)\b', b'PERSON', live_contents)})
(SCRATCH / 'source-since-prior.patch.txt').write_bytes(git('diff', '--binary', old_source['base'], base, '--', *[x['path'] for x in snapshot]))
(SCRATCH / 'source-vs-live.patch.txt').write_bytes(git('diff', '--binary', base, live, '--', *[x['path'] for x in snapshot]))
save('source-snapshot.json', {'base': base, 'live': live, 'prior_base': old_source['base'], 'files': snapshot})
ancestors = read(PRIOR / 'existing-live-ancestors.json')['commits']
for item in ancestors:
    for key, commit in [('in_base', base), ('in_live', live)]:
        item[key] = subprocess.run(['git', '-C', str(WORKTREE), 'merge-base', '--is-ancestor', item['commit'], commit]).returncode == 0
    check('既有窄源码祖先 ' + item['commit'], item['in_base'] and item['in_live'])
save('existing-live-ancestors.json', {'base': base, 'live': live, 'commits': ancestors})

floors = {'VLZ6CCT8AQ0A': {35, 36, 37, 43, 44, 45}, '8JRE1C4H4Z2W': {17, 33}, 'CA5KE8GFJ9X2': {7, 13}, '5PM6JAQG6FNQ': {33, 38, 39}, '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}
selected_states = []
for item in streams['states']:
    state = item['row']['state']
    info = state.get('run') or {}
    if info.get('floor') not in floors[item['run_id']]:
        continue
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    selected_states.append({'ref': {k: v for k, v in item.items() if k != 'row'}, 'observed_ts': item['row'].get('observed_ts'), 'floor': info.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'), 'hp': player.get('current_hp', info.get('current_hp')), 'max_hp': info.get('max_hp'), 'block': player.get('block'), 'energy': player.get('energy'), 'powers': player.get('powers'), 'hand': combat.get('hand'), 'enemies': combat.get('enemies'), 'potions': info.get('potions'), 'deck_upgraded': sum(bool(c.get('upgraded')) for c in info.get('deck', []))})
selected_decisions = []
for item in streams['decisions']:
    row = item['row']
    if row.get('floor') in floors[item['run_id']]:
        selected_decisions.append({'ref': {k: v for k, v in item.items() if k != 'row'}, **{k: row.get(k) for k in ['decision_id', 'observed_ts', 'floor', 'turn', 'sl_attempt', 'sl_reloads', 'label', 'fingerprint', 'chosen', 'expect', 'result', 'rationale', 'answers', 'questions', 'rollout', 'rollout_best_chosen', 'hp_guard', 'sl_explore', 'selection_audit']}})
save('selected-state-facts.json', selected_states)
save('selected-decision-facts.json', selected_decisions)
save('material-checks.json', {'scope': '材料指纹、原日志身份和已有回执复用核验；不是生产tsc/vitest或新模拟。', 'checks': checks, 'passed': len(checks), 'selected_states': len(selected_states), 'selected_decisions': len(selected_decisions)})
print(json.dumps({'verified_envelopes': len(references), 'checks': len(checks), 'base': base, 'live': live, 'source_changes_since_prior': [x['path'] for x in snapshot if not x['same_prior_bytes']], 'selected_states': len(selected_states), 'selected_decisions': len(selected_decisions)}, ensure_ascii=False))

# 静默策略：十项原提案的本批证据处置

记录时间：2026-10-17T13:22:27+08:00。batch=20261017-131302-strategy-proposal；task=strategy-proposal；character=silent。完整base=fe8b000d766058c687c3ca022333b9feb254cdcf。

本批十项均waiting。只处理learn.json明确领取的十个id，无proposal_repair、research_request或implementation_request；普通专题请求绑定其他批次，未转为专题。git初始干净，git merge --no-edit main返回Already up to date，HEAD不变。没有源码、知识、规则或参数改动；没有新增代码提案id、源码提交、合入、版本或shipped。

证据只使用六派发局：VLZ6CCT8AQ0A, 8JRE1C4H4Z2W, CA5KE8GFJ9X2, 5PM6JAQG6FNQ, 61E2QS63Y9WU, DUZUBAJ3A8GP。runs.jsonl均核Silent A10；SL次数、同局帧和十五子机制不扩独立局数。原提案引用的其他旧局只保其原文出处，本批不将其算作已重新分析的局。

共用extract_evidence.py提取七流；每流独立source_size、每行offset/bytes/SHA及计数保存在evidence/。6,995封套逐行原日志读回、身份一致；不从正文提及认领局号。六局封套、完整消费者输入及五递归依赖与111303前批相同，核验见consumer-reuse-verification.json。只复用原回执，没有重新运行消费者/模拟。原缺decision_id的三份完整输入真实失败与相应有界输入全部保留在原路径，不能以有界成功替代完整成功。

当前源码15叶与前批12同字节，rollout.ts、rollout-live.ts、hand/loop.ts有已发布变更，补丁逐字保存在source-since-prior.patch.txt。其中H0为明确A2上下文，非本批A10证据；loop为预算到期解析标记。不能冒整树不变。当前live快照6fbbd82abd6d407dbaf93f82639b7f927efa54a0；15叶中11同字节、4仅独立单词Roy/Dai历史署名差。11个既有窄源码commit均重新核为本base/live祖先，见existing-live-ancestors.json；不把窄祖先当整个请求已实现。

统一边界：Roy-2026-10-07-learning提供修改授权，不提供游戏事实；证据不足保留规则。本批不拟合血价、药价、启动权重、SL/终局阈值或固定杀序。不新增机制异议/反证；原限制不强行支持为规则。其他角色行为没有修改。

## silent-proposal-89354805ee4d7e77：神化的实际施放与候选升级

来源：postmortem → strategy-proposal；账本：silent-0237, silent-0238；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-apotheosis.md；SHA256=ab6488e1b2e17415061c372d3efa10dbba468de2574f784088e1a967358df76d，本批逐字副本为silent-proposal-89354805ee4d7e77-original.md。

证据局号、层、回合与原物理行：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；s275564→275565、s275679→275687，d269706/269707/269748/269754。

核实事实及反例：F35神化7→5能，防御5→8、打击7→10、匕首雨逐击5→7、必备工具1→0费；F43后轮牌仍升级、场外deck升级数保持4。F45持有而未施放，不能预支升级。

旧规则/现有覆盖：已有普通神化配对和候选参考字段；turn-solver仍将虚弱、脆弱、缩小、暗影、重放/自动出牌组合标未知，actual_cast_this_fight仍为null。

处置waiting：缺跨抽牌、选牌、用药、重问、SL及换战的实际施放持续身份与生产读回；未覆盖升级交互没有本批新实测。既有配对转换不能证明整项完成。

预期行为与验证：仅由实测配对传播升级，已施放、候选模拟及场外牌组分账；冻结上述状态验证未知边界，后续独立A10局验证持续归属，不增加必打或固定加分规则。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-f2bfceddb1898dca：三骑士药水预算与全败候选

来源：postmortem → strategy-proposal；账本：silent-0106, silent-0019, silent-0201；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-154302-postmortem/proposal-budget-and-clock.md；SHA256=fc9f3dfdb7df5f99a57ff6c1a7e7f08f9e5e6514dde8cd1013e04995d912eb26，本批逐字副本为silent-proposal-f2bfceddb1898dca-original.md。

证据局号、层、回合与原物理行：VLZ6CCT8AQ0A F43/F44资源链、F45 T1/T4/T5；d269748/269754/269770，s275722/275731/275732/275752/275754。

核实事实及反例：F45首题horizon1/samples1/best=null是退化；T4攻击候选32伤/31损与实选24伤/13损没有整战反事实。T5三敌未退出，32血20挡对59入伤的完整需损为39，观察到的归零血量不是39实扣。

旧规则/现有覆盖：已有药水样本/退化字段及H1工程预算；当前不能照搬旧707ms描述全局现状。工程截止和候选数量不等于药水分阶段分配已量化。

处置waiting：缺完整模型下同起点、同随机池、同总预算的分阶段MC配对与样本成熟曲线，亦缺留药及另一focus的完整后继；H1工程发布不能充作本提案收益证明。

预期行为与验证：保持现有药价、护栏及目标选择；在模型覆盖完整后，以同盘同预算记录样本曲线和候选稳定性，药水实抽后再核，不把局部样本当胜负。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-283a164780d11e69：经验来源的同源神化请求

来源：experience-update → strategy-proposal；账本：silent-0237, silent-0238；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-apotheosis.md；SHA256=78e23dae4213fa5b07bda1a0799bbbe0c94567c889db235b40560f523608e637，本批逐字副本为silent-proposal-283a164780d11e69-original.md。

证据局号、层、回合与原物理行：VLZ6CCT8AQ0A F35 T1、F43 T1/T2、F45 T1；证据与89354805ee4d7e77相同。

核实事实及反例：该原经验只支持已观测升级与持有/施放分账；四次施放是同一独立局内重复，不能当四局。

旧规则/现有覆盖：与原postmortem提案共享窄源码；原id和经验链保持，不重新注册或把同源pending项冒称已在live完整重复实现。

处置waiting：同源神化请求仍缺跨中断的实际施放归属及未知升级组合校准；没有覆盖全部原请求的实际live源码提交，不能登记duplicate。

预期行为与验证：沿原id与原证据去重后续实现，验证及未知保持方式同前项；不另建重复代码提案。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-ebbfe3b97548756d：十五子项攻防与资源分账

来源：experience-update → strategy-proposal；账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-164302-experience-update/proposal-mechanisms-and-resources.md；SHA256=08eaeed02365ece6b99ec54adb8ead6688d7323d6f59f30c1cb5996f41c552e2，本批逐字副本为silent-proposal-ebbfe3b97548756d-original.md。

证据局号、层、回合与原物理行：VLZ6CCT8AQ0A F43 T1—T5、F45 T3/T5及F44回血；s275737→275738、s275752/275754。

核实事实及反例：口红T3使力1→2、敏0→1，步法后总3敏；F45后空翻8、防御12，勒紧4只用于防御。覆甲末轮已无；临减6影响四攻击段但不停止后续成长。

旧规则/现有覆盖：十五关联经验和26账本只作原链核对；逐击属性、毒触发、路线/休息各有局部实现，不将综合条目支持局数当同一公式的独立实验分母。

处置waiting：缺十五子项逐来源属性、升级组合、期限及战斗—路线—休息的联合生产校准；本批原帧没有隔离出新的确定数值失配，局部实现不足关闭整条复合请求。

预期行为与验证：逐源冻结手牌、属性、已结算毒、当前覆甲及资源后继；发现明确数值失配才补静默路径。休息/路线无受控对照，保持选择规则。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-e5b87be50f28f311：SL与HP护栏的候选—实际审计

来源：postmortem → strategy-proposal；账本：silent-0079, silent-0021, silent-0125, silent-0018；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/learner/runs/20261007-164302-postmortem/proposal-combat-sl-audit.md；SHA256=5e713a9a6a50830d4ff7c2aba1c2af90487cc8d03e4881555257b43161632709，本批逐字副本为silent-proposal-e5b87be50f28f311-original.md。

证据局号、层、回合与原物理行：8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11，F17 T6；d270216/270282/270264。

核实事实及反例：T2两题fingerprint完全相同，SL替换本轮多12血损、多7敌净扣；0/24与5/24死亡不能并列。第二试T5护栏题面省12血少18伤，重问后的整轮端点不全归单次替换；六试仍为一独立局。

旧规则/现有覆盖：已存在三阶段快照、护栏审计、单动作回执及离线消费者；scope分别是predicted_candidates、single_action_receipt和观测端点，均未认证完整候选。

处置waiting：缺跨抽牌、选择、用药、重问、SL的完整候选持续归属和全过程生产校准；原113个片段的actual_full_candidate_result均为null，不能据此认成长收益或整战改线因果。

预期行为与验证：保留候选与实际端点分账，API回执不当生效证明；补齐重规划与能力建立归属后再做固定红绿验证。不改血价、护栏、SL范围或成长优先级。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-49632bc4878fb597：力量、敏捷、虚弱及蚌成长

来源：experience-update → strategy-proposal；账本：silent-0005, silent-0231；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-strength-weak-observation.md；SHA256=aac4fddf0f24862a3fb8e289d000a312358c3bb9ee3d624602bf755d0b5409a2，本批逐字副本为silent-proposal-49632bc4878fb597-original.md。

证据局号、层、回合与原物理行：CA5KE8GFJ9X2 F13 T2—T5；s273251→273252、s273262→273263、s273268→273269，d267371/267380/267385。

核实事实及反例：两次加压后力量4/8、喷水15/19，施弱后末轮14攻，2血10挡完整需损4而显示血量只扣2。敌死前荆棘使19→16，不能将其归直伤或毒。

旧规则/现有覆盖：已有属性与成长模型；该局没有建立计划中的正敏捷。完整离线消费者因原d267143缺decision_id拒收，有界输入只删该行而保物理缺口，不能冒称完整输入通过。

处置waiting：缺逐击力量、正负敏捷、虚弱与独立成长四路径在同一冻结生产调用中的联合校准；本局未实测正敏捷，也未发现新的确定子公式失配。

预期行为与验证：保持当前属性公式与成长取表；按当前进阶冻结数据库与原帧逐步比对。不能用单个步法源码祖先证明复合请求全部实现。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-66532328a585941f：启动组件的实付与兑现

来源：experience-update → strategy-proposal；账本：silent-0021, silent-0009；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-deck-burst-observation.md；SHA256=56a0a04049f43aa425242d11caa305a1bb869fc6b4fc38d0138e9f6edad44831，本批逐字副本为silent-proposal-66532328a585941f-original.md。

证据局号、层、回合与原物理行：5PM6JAQG6FNQ F39第二试T2，d268455、s274379→274380；F33已建立组件的胜战仅作有条件对照。

核实事实及反例：无毒目标上冒泡实付能量5→4，目标35HP与无毒状态保持。持有雾和触媒不代表本战已经建立；F33与F39敌人、资源与抽序不同。

旧规则/现有覆盖：原消费者完整输入638动作/83片段可读回，完整候选归属仍未认证；不能以构筑文字计划替代实盘建立。

处置waiting：缺相同HP、牌组、药水和完整抽序下不同启动顺序的受控整战对照及可复现收益函数；局部空打端点不足拟合启动阈值或构筑权重。

预期行为与验证：沿持有、到手、实付、建立与后继分账，先核真实可活窗口；不增加固定早打、保血或输出权重。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-43a76a31ba7bdcfa：族母吸取、负敏捷与毒

来源：experience-update → strategy-proposal；账本：silent-0030, silent-0027；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-lagavulin-siphon-poison-sl.md；SHA256=f4a38e2d7ee0b5d205a3168cc58dfec442046d7be3a89701054b3dcb7fdf0a6c，本批逐字副本为silent-proposal-43a76a31ba7bdcfa-original.md。

证据局号、层、回合与原物理行：61E2QS63Y9WU F17 T5/T6；s273503→273508，d267611/267612/267614。

核实事实及反例：吸取后玩家力2→0、敏0→−2，敌力0→2；双防御各3，触媒1下17毒端点67→34。首试胜只支持这些条件下的事实，不提供另一可救线路。

旧规则/现有覆盖：现有负敏捷与毒路径分开；完整离线输入因d267517缺decision_id拒收，有界结果保留原行缺口。

处置waiting：缺同起始HP、构筑、完整抽序的生产整战配对与另一可核SL线路；负敏捷及毒端点不足支持变更SL范围或阈值。

预期行为与验证：固定吸取、牌挡、已结毒和临减恢复分别校准；保留现有SL与换线规则，不能据本局首试获胜拟合新偏好。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-5264153a4a4b0e5c：胧光怪召唤、成长与退场

来源：experience-update → strategy-proposal；账本：silent-0039, silent-0209；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-obscura-summon-growth.md；SHA256=b32fb321d95e941c095993cdde0d011354c689718ffe2a3b2428fe68c444ec02，本批逐字副本为silent-proposal-5264153a4a4b0e5c-original.md。

证据局号、层、回合与原物理行：61E2QS63Y9WU F23 T4/T5；d267696、s273593—273598。

核实事实及反例：T4本体76→41、幻象14→2，合净扣47而幻象仍能攻击；原另一focus题面39伤/零损未实打。各实体成长和实际退出窗口不能合成一个总伤害。

旧规则/现有覆盖：已有活体召唤窄源码祖先；离线消费者此窗口为unknown仍保原帧端点，不把unknown解释为日志完全不存在。

处置waiting：缺A10召唤、航行、复现与退场全链的冻结生产校准及另一focus完整后继；已有召唤源码和T4净扣不能证明目标排序整战收益。

预期行为与验证：按当前进阶敌方数据逐实体核召唤/意图/剩血，保留全部目标；推演相同者并列，不强制先杀幻象或本体。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

## silent-proposal-bddfa690a84e03d0：熟睡甲虫唤醒与持续成长

来源：experience-update → strategy-proposal；账本：silent-0128, silent-0079；角色silent，观察进阶A10。原Markdown：/home/dw/Projects/agent-sts2/.worktrees/codex-dev/learner/runs/20261007-170245-strategy-proposal/silent-slumbering-beetle-wake-growth.md；SHA256=b9f90f13d558011142b4bfc459efdfd4680dd297206c182c9c48d86f4c32e780，本批逐字副本为silent-proposal-bddfa690a84e03d0-original.md。

证据局号、层、回合与原物理行：DUZUBAJ3A8GP F30四试T4—T6；末试s275012→275023，d269067/269072/269077。

核实事实及反例：末试T4 24挡实损4，首试26挡实损2，多3敌净扣仍有2血价；T5临减后力−4、14攻，T6恢复并成长至4力22攻。末1血16挡完整需损6，血量截断不是完整入伤。

旧规则/现有覆盖：四次失败相关，不能扩为四独立局；完整消费者因d268789/268818/268864缺decision_id拒收，限定输入保缺口。

处置waiting：缺伤害唤醒、眩晕接续及当前进阶成长的冻结生产全链校准和同抽换序完整后继；四次相关失败不足拟合血价、全败排序或固定杀序。

预期行为与验证：睡眠、失血唤醒、眩晕与独立增力逐步核；保留未知和现有排序，不以全败抹掉实际血价。 发现样本内固定核验不作为独立时间后移验证；若后续修改源码，使用固定输入，撤源码须失败、恢复须通过，再走原沙箱和live流程。单独保存未覆盖输入，不依赖刷新的知识JSON，不调用模型。

预期影响仅为事实可追溯和缺口明确，当前没有策略收益证明。本批没有生产改动可回退；后续实现按实际源码commit回退，保留证据、账本、原提案和失败回执。

import json
import runpy
from pathlib import Path

here = Path(__file__).resolve().parent
namespace = runpy.run_path(str(here / "audit_materials.py"))
states, decisions, sl = (namespace[key] for key in ["states", "decisions", "sl"])
slim_state, ref, save = (namespace[key] for key in ["slim_state", "ref", "save"])

kv = namespace["endpoint"](namespace["choice"]("KV0JHNJCKXLS", 6, 4))
save("kv-last-t4.json", kv)

questions = []
for line in [272361, 272362, 272455, 274354, 273450, 273451, 273474, 273480]:
    record = namespace["decision_by_line"][line]
    row = record["row"]
    questions.append({"ref": ref(record), **{k: row.get(k) for k in ["floor", "turn", "sl_attempt", "questions", "answers", "chosen", "rationale", "rollout", "sl_explore", "result"]}})
save("question-and-replan-audit.json", questions)

footwork = []
for record in sl:
    row = record["row"]
    if record["run_id"] != "KEN58SH9SLZ6" or row["floor"] != 17:
        continue
    seen = []
    for state_record in states:
        if state_record["run_id"] != record["run_id"] or not row["started_at"] <= state_record["row"]["ts"] <= row["ended_at"]:
            continue
        state = slim_state(state_record)
        if any(p["power_id"] == "DEXTERITY_POWER" and p["amount"] == 2 for p in state["powers"] or []):
            seen.append(state)
    footwork.append({"attempt": row["attempt"], "first_two_dexterity_frame": seen[0] if seen else None,
                     "played_footwork_turns": [turn["turn"] for turn in row["summary"]["turns"] if any("灵动步法" in play for play in turn["plays"])]})
assert [x["first_two_dexterity_frame"]["turn"] for x in footwork] == [3, 5, 5, 5, 5, 9]
save("ken-footwork-establishment.json", footwork)

anchors = []
for record in sl:
    if record["line"] not in [681, 717, 960, 961, 962, 963]:
        continue
    anchor = record["row"]["explore"]["target"]["anchor"]
    assert any((entry["enemyHp"] or 0) > 999000000 for entry in anchor["ranked"])
    anchors.append({"ref": ref(record), "anchor": anchor})
save("giant-anchor-audit.json", anchors)
print("追加复核完成：知识恶魔末试T4、八条题面/续问、六试步法建立时点、六条巨兽旧参考路径。")

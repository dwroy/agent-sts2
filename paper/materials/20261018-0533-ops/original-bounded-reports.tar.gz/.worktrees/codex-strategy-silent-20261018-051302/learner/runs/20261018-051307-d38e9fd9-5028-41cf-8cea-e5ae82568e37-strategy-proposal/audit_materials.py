import collections
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location("extract", ROOT / "learner/extract_evidence.py")
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
RUNS = json.loads((HERE / "dispatch.json").read_text())["runs"]


def save(name, obj):
    (HERE / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def ref(record):
    return {key: record[key] for key in ["source", "line", "offset", "bytes", "sha256", "run_id"]}


streams = {}
checks = []
for directory in ["evidence", "evidence-extra"]:
    for manifest in json.loads((HERE / directory / "evidence-manifest.json").read_text()):
        name = manifest["stream"]
        path = HERE / directory / (name + ".evidence.jsonl")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest["output_sha256"]
        records = []
        counts = collections.Counter()
        with path.open() as handle:
            for line in handle:
                record = json.loads(line)
                assert record["run_id"] in RUNS
                assert record["offset"] + record["bytes"] <= manifest["source_size"]
                with open(record["source"], "rb") as source:
                    source.seek(record["offset"])
                    raw = source.read(record["bytes"])
                assert hashlib.sha256(raw).hexdigest() == record["sha256"]
                assert json.loads(raw) == record["row"]
                assert extract.run_identity(record["row"]) == record["run_id"]
                counts[record["run_id"]] += 1
                records.append(record)
        assert all(counts[run] == count for run, count in manifest["counts"].items())
        streams[name] = records
        checks.append({**manifest, "verified_references": len(records), "all_selected_bytes_and_identity_verified": True})
save("evidence-verification.json", checks)

states = streams["states"]
decisions = streams["decisions"]
sl = streams["sl-attempts"]
state_by_line = {r["line"]: r for r in states}
decision_by_line = {r["line"]: r for r in decisions}


def slim_state(record):
    state = record["row"]["state"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "ref": ref(record), "ts": record["row"]["ts"], "floor": state["run"]["floor"],
        "turn": state.get("turn"), "screen": state["screen"],
        "hp": player.get("current_hp", state["run"].get("current_hp")),
        "block": player.get("block"), "powers": player.get("powers"),
        "potions": state["run"].get("potions"),
        "hand": [{k: c.get(k) for k in ["index", "card_id", "name", "upgraded", "block", "resolved_rules_text"]} for c in combat.get("hand", [])],
        "enemies": [{k: e.get(k) for k in ["index", "enemy_id", "current_hp", "max_hp", "is_alive", "move_id", "powers", "intents"]} for e in combat.get("enemies", [])],
    }


def choice(run, attempt, turn):
    return next(r for r in decisions if r["run_id"] == run and r["row"].get("floor") == (33 if run == "KV0JHNJCKXLS" else 17)
                and r["row"].get("sl_attempt") == attempt and r["row"].get("turn") == turn
                and "plan" in (r["row"].get("questions") or {}))


def endpoint(decision):
    row = decision["row"]
    matching = [r for r in states if r["run_id"] == decision["run_id"] and r["row"].get("fingerprint") == row["fingerprint"]
                and r["row"]["ts"] <= row["ts"]]
    assert matching, (decision["line"], "没有同指纹起点")
    start = matching[-1]
    attempt = next(r["row"] for r in sl if r["run_id"] == decision["run_id"] and r["row"]["floor"] == row["floor"] and r["row"]["attempt"] == row["sl_attempt"])
    end = next(r for r in states if r["run_id"] == decision["run_id"] and r["line"] > start["line"]
               and r["row"]["ts"] <= attempt["ended_at"] and r["row"]["state"]["run"]["floor"] == row["floor"]
               and r["row"]["state"].get("turn") == row["turn"] + 1
               and "end_turn" in r["row"]["state"].get("available_actions", []))
    a, b = slim_state(start), slim_state(end)
    damage = sum(e["current_hp"] for e in a["enemies"] if e["is_alive"]) - sum(e["current_hp"] for e in b["enemies"] if e["is_alive"])
    options = {}
    for key, value in row["questions"]["plan"].get("criteria", {}).items():
        try:
            options[key] = json.loads(value) if isinstance(value, str) else value
        except (ValueError, TypeError):
            options[key] = value
    return {"decision": ref(decision), "attempt": row["sl_attempt"], "turn": row["turn"], "start": a, "next_turn": b,
            "actual_net_hp_loss": a["hp"] - b["hp"], "actual_net_enemy_hp_reduction": damage,
            "sl_explore": row.get("sl_explore"), "chosen": row.get("chosen"), "result": row.get("result"),
            "options": options, "answers": row.get("answers"), "rationale": row.get("rationale"),
            "whole_plan_execution_certified": False}


pairs = [
    ("751FN9QM9MHQ", 1, 3, 2), ("751FN9QM9MHQ", 2, 4, 7), ("751FN9QM9MHQ", 1, 6, 13),
    ("KV0JHNJCKXLS", 4, 5, 5), ("KV0JHNJCKXLS", 1, 6, 1),
    ("KEN58SH9SLZ6", 4, 5, 10), ("KEN58SH9SLZ6", 4, 6, 5),
]
comparisons = []
for run, original, replacement, turn in pairs:
    a, b = choice(run, original, turn), choice(run, replacement, turn)
    same = a["row"]["fingerprint"] == b["row"]["fingerprint"]
    assert same, (run, turn, "指纹不同")
    before, after = endpoint(a), endpoint(b)
    comparisons.append({"run": run, "floor": a["row"]["floor"], "turn": turn, "same_fingerprint": same,
                        "original": before, "replacement": after,
                        "delta_net_hp_loss": after["actual_net_hp_loss"] - before["actual_net_hp_loss"],
                        "delta_net_enemy_hp_reduction": after["actual_net_enemy_hp_reduction"] - before["actual_net_enemy_hp_reduction"]})
save("paired-rounds.json", comparisons)
print("同指纹回合端点", [(c["run"], c["turn"], c["delta_net_hp_loss"], c["delta_net_enemy_hp_reduction"]) for c in comparisons])

potions = []
for decision_line, first, last, slot, ident in [
    (274131, 280206, 280207, 0, "ATTACK_POTION"),
    (274156, 280232, 280233, 0, "STABLE_SERUM"),
    (274185, 280262, 280263, 0, "SPEED_POTION"),
    (274235, 280313, 280314, 1, "WEAK_POTION"),
    (274237, 280315, 280316, 0, "ATTACK_POTION"),
    (274267, 280348, 280349, 1, "GLOWWATER_POTION"),
    (274272, 280354, 280355, 0, "SKILL_POTION"),
]:
    before, after = slim_state(state_by_line[first]), slim_state(state_by_line[last])
    d = decision_by_line[decision_line]
    assert d["row"]["chosen"]["action"] == "use_potion"
    assert d["run_id"] == "KEN58SH9SLZ6"
    held = next(p for p in before["potions"] if p["index"] == slot)
    empty = next(p for p in after["potions"] if p["index"] == slot)
    assert held["potion_id"] == ident and held["occupied"] and not empty["occupied"]
    potions.append({"decision": ref(d), "chosen": d["row"]["chosen"], "result": d["row"]["result"],
                    "potion": ident, "slot": slot, "before": before, "after": after,
                    "whole_potion_plan_realized": None})
save("ken-seven-potions.json", potions)

before, after = slim_state(state_by_line[280160]), slim_state(state_by_line[280161])
poison = lambda state: next(p["amount"] for p in state["enemies"][0]["powers"] if p["power_id"] == "POISON_POWER")
assert (poison(before), poison(after)) == (2, 8)
assert before["hp"] == after["hp"] == 26 and before["block"] == after["block"] == 13
assert before["enemies"][0]["intents"] == after["enemies"][0]["intents"]
save("giant-poison-use.json", {"before": before, "after": after, "no_change_in_hp_block_intent": True})

attempts = []
for record in sl:
    row = record["row"]
    attempts.append({"ref": ref(record), **{k: row.get(k) for k in ["floor", "attempt", "result", "turns", "end_hp", "end_block", "incoming", "started_at", "ended_at", "encounter", "judge"]},
                     "turns_summary": row["summary"]["turns"],
                     "anchor": ((row.get("explore") or {}).get("target") or {}).get("anchor")})
save("attempts-audit.json", attempts)
save("audit-summary.json", {"verified_references": sum(c["verified_references"] for c in checks), "streams": len(checks),
                           "paired_rounds": len(comparisons), "potion_consumptions": len(potions), "giant_poison_use": 1,
                           "attempt_records": len(attempts), "production_tests_run": False})
print("材料复核完成；未运行生产测试。")

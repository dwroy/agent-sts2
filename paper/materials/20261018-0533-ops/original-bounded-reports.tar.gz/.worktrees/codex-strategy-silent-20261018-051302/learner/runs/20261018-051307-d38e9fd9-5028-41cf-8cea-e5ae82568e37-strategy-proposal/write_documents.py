import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / "dispatch.json").read_text())
proposals = json.loads((HERE / "selected-proposals.json").read_text())
source = json.loads((HERE / "source-manifest.json").read_text())
base = source["base"]
reasons = {
    "silent-proposal-366288801d9150d9": "751局F17三组同指纹血价已核；现有SL资源预测和持牌诊断不认证续问、弃牌后的完整实际结算。缺完整候选执行归属、固定后继整战对照与独立验证，不能拟探索血价阈值。",
    "silent-proposal-85929bdfc8a3fc1b": "751局F13 T3实际仅执行用药支线；未知持有价值、同题无药参考及未决弃牌保守提示已有。缺逐来源实际收益、无药或留至后战的完整结果，不能给留药估值或改弃牌规则。",
    "silent-proposal-efd9f83ee9e1a6dc": "与366288801d9150d9共享751同局证据，已逐项复核；现有预测和单动作回执不认证完整执行。缺实际成本归属、受控整战及后期独立验证，同主题不等于整项已实现。",
    "silent-proposal-131042659448ae74": "已有持牌预测、未知留药价和无药参考；本批未重做原101局历史全审。缺敏捷、毒、荆棘与未决弃牌的完整联合消费者结算，以及跨战留药对照，不能把局部事实记为整项duplicate。",
    "silent-proposal-990f054036609447": "KV局F33 T5删毒药后净扣敌36→29、双方零净损且次轮毒20→13已核；末试T4敌327/15毒→342/14毒的结算端点已保存。缺完整毛伤/回血与能力来源归属、固定后继胜线和独立验证，不能据净差拟探索或路线参数。",
    "silent-proposal-e18d3f18e6cac2a0": "YQL局残壳毒2→8而血26/挡13/自爆41不变，L9/PU旧占位血参考已核；阶段显示已有但原残血同轮排序仍保留。缺改序受控后继、完整最终资源与提前用药结果，不能直接归零占位HP改序。",
    "silent-proposal-9733bb80f445aeae": "共享YQL/L9/PU阶段证据，既有本体/自爆显示及毒药观察已在live祖先；PU第五试获胜同时改变多处后继。缺改序、提前用药及路线的受控验证，不能把阶段子实现登记为整项duplicate。",
    "silent-proposal-c51468c5e8ba6668": "KEN七次实际耗药的请求和前后槽位已核，六次Boss入口75/86空栏；缺随机选牌、发光水重问后的完整候选收益认证，以及不喝或留到Boss的完整分支，保留持有价值与跨战预算。",
    "silent-proposal-86a7db08d1a31976": "KEN局T10多损6血仅多扣敌2血、T5省2血却将步法建立推迟至T9均已核；缺完整能力后继及逐来源实际归属、保持其他后轮的整战对照和独立验证，不能拟统一6血/2伤阈值。",
    "silent-proposal-e282a9131b99129a": "共享KEN两组同指纹对照，六试只算一个独立局；持牌预测、选择阶段和单动作回执已有。缺续问后的完整执行归属、受控整战及后期独立验证，不能据当轮省血或未试线直接改探索规则。",
}
evidence = {
    "silent-proposal-366288801d9150d9": "751FN9QM9MHQ F17 T2/T7/T13；decisions 272434/272575、272531/272652及同指纹T13。",
    "silent-proposal-85929bdfc8a3fc1b": "751FN9QM9MHQ F13 T3（272361/272362）；F17 T7（272455），T13、T17。",
    "silent-proposal-efd9f83ee9e1a6dc": "751FN9QM9MHQ F17 T2/T7/T13；与第一项共享原始证据，不增加独立样本。",
    "silent-proposal-131042659448ae74": "751FN9QM9MHQ F13 T3；F17 T3/T5/T7/T13/T17；原101局的宽支持数未作为本批覆盖数。",
    "silent-proposal-990f054036609447": "KV0JHNJCKXLS F33 第4/5试T5（273400/273450/273451）；第1/6试T1（273242/273474/273480）；末试T4状态279553—279560。",
    "silent-proposal-e18d3f18e6cac2a0": "YQL8RZ8BWN1E F17 T10 states280160/280161，sl-attempts960—963；L9SGRBB5R698 F17 T14旧参考681；PU80F84P6HPN F17 T17旧参考717。",
    "silent-proposal-9733bb80f445aeae": "YQL8RZ8BWN1E F17六试及T10；L9SGRBB5R698 F17；PU80F84P6HPN F17第五试T15胜余2；不把相关重打独立拆分。",
    "silent-proposal-c51468c5e8ba6668": "KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1、T2/F15T1；decisions274131/274156/274185/274235/274237/274267/274272。",
    "silent-proposal-86a7db08d1a31976": "KEN58SH9SLZ6 F17 第4/5试T10（274505/274568）、第4/6试T5（274484/274601），第2试T2护栏274354。",
    "silent-proposal-e282a9131b99129a": "KEN58SH9SLZ6 F17 T5/T10；与前项共享两组对照，六试只有一局独立证据。",
}
results = [{"id": p["id"], "state": "waiting", "reason": reasons[p["id"]]} for p in proposals]
(HERE / "proposal-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")

intro = f"""# 静默猎手策略提案逐项复核

本批：20261018-051302-strategy-proposal。基线：`{base}`。仅处理派发的十个已有id；无research_request或implementation_request。根专题登记属于20261010-150327，未绑定本批，不套用专题任务。初始工作树干净，普通分支执行`git merge --no-edit main`结果Already up to date；未并入后续main。

角色和范围：六局在runs.jsonl均为SILENT、A10。本批只使用这六局的原始证据、本角色原提案、账本和知识；未新增独立局。已有原提案的十份Markdown逐字节保存，SHA均等于队列登记值。来源任务和实现任务继续沿用原id；没有重复登记code_proposals。授权Roy-2026-10-07-learning允许证据充分后改规则，本次等待原因是证据缺口。

结论：事实诊断已有窄实现；十个提案的完整执行、联合结算或策略收益验证仍未闭环，全部waiting。没有发现可据本批证据新增的已验证策略参数或需要新修的源码失配，因此无源码/知识改动、无提交、无live合入、无版本、无shipped。

## 证据方法与边界

通过指定extract_evidence.py抽六个默认流，并另存runs/fight-plans两个补充流。八流共8444条所选记录，全部逐offset/bytes/SHA读取原日志、比较JSON和显式归局身份，输出SHA与manifest一致；不以正文提及归局。各流source_size和各局计数见`evidence/evidence-manifest.json`、`evidence-extra/evidence-manifest.json`、`evidence-verification.json`。状态4167、决策4071、SL43、配置6、计划21、大脑130、局报6、旧fight-plans0。全源states/decisions/brain各2坏行未进入所选记录，未据此推断其所属局；本批所选原行全部通过。fight-plans零行仅说明该流此截点未选到，不能证明原日志或作战计划缺失。

固定复核来自原状态和当年决策，不运行游戏、不调用LLM/网络、不重建dirty对局源码，不从当前刷新知识推演历史。七组同指纹回合均核原始起点和下一可操作回合端点；完整fingerprint相同不证明后续隐藏随机、抽序及全部动作受控。净HP变化不等于敌方总伤害，净敌HP差不等于毛输出；SL截断末轮不补结算。相关六次SL只算一局独立证据。本批未重做原101/102/103/104局历史审计，也不沿用这些宽计数作为新增分母。

## 七组同指纹对照

以下均为实际整轮端点，损血包含全部当轮实际来源，扣敌包含已结算来源；两者都不是单卡因果。详细原行和原/替候选题面见`paired-rounds.json`。

|局/层/回合（原试→替试）|原：净损/扣敌|替：净损/扣敌|净变化：损血/扣敌|
|---|---:|---:|---:|
"""
for c in json.loads((HERE / "paired-rounds.json").read_text()):
    a, b = c["original"], c["replacement"]
    intro += f"|{c['run']} F{c['floor']} T{c['turn']}（{a['attempt']}→{b['attempt']}）|{a['actual_net_hp_loss']}/{a['actual_net_enemy_hp_reduction']}|{b['actual_net_hp_loss']}/{b['actual_net_enemy_hp_reduction']}|{c['delta_net_hp_loss']:+}/{c['delta_net_enemy_hp_reduction']:+}|\n"
intro += """
751 T2 B2 .195→.193，差−.0025、标准误.0135；T7 .103→.013，差−.09、误差.0088。题面T7损19→29，实际13→23；两线保守绝对误差均6，没有消除实际10血差。T13省血伴随输出下降。KEN T10 B2 .385→.127，差−.2583、误差.0132，五轮死亡6/24→12/24；无实体下新增牌面输出未按牌面兑现。KEN T5实际多扣1（1→2）包含后续另问追加动作，不能把全部增量归原候选；步法实际建立回合为六试T3/T5/T5/T5/T5/T9，原始首个2敏捷帧见`ken-footwork-establishment.json`。这是对“只省血恒优”的反向取舍；仍没有隔离后续的胜负因果。

KV T5两线均零净损，扣敌36→29、次轮毒20→13；原/替最终都T10判死。末试T4从342/15毒经出牌到327/15毒，下一可操作帧342/14毒且玩家30血不变（279553—279560）；该轮净扣0不能标为没有打伤害，原提案的毛伤/回血全链并未仅凭这些帧自动认证。材料见`kv-last-t4.json`、`kv-t4-healing-frames.json`。

## 药水与巨兽阶段

751 F13 T3 plan2用药线即时损8/牌伤26，plan3本轮无药即时损8/牌伤16但后续7/8样本喝药；plan5才是整战无药参考，损8、8/8胜、约2.9轮，用药plan2约2.3轮。本批保存272361/272362原题与动作；没有把“本轮无药”误作“整战无药”，8/8是原模型样本而非实际无药结果。成本0附带药水表未加载，不能学习为持有价值0。

KEN七次use_potion请求均有对应槽位从指定药水变空：F3T2攻击药水、F4T1稳定血清、F5T2速度药水、F11T1虚弱药水和T2攻击药水、F15T1发光水和技能药水。七次即时用药前后HP分别56/53/49/32/32/46/46均未变；这不是零整轮伤害或零药水收益。见`ken-seven-potions.json`。原F15零净损不能证明未喝药也零损，随机选牌与重问之后的整线兑现仍未认证。六试Boss入口75/86空栏沿原状态与尝试摘要核对，不由空栏败局倒推留药必胜。

YQL F17 T10原状态280160→280161：占位体毒2→8、玩家26血13挡、DeathBlow41均未变，最大血999999999；本体已结束，战斗仍未胜。原六试全部失败，末试自爆前26+13不足41；实际死亡HP截断为0与算术差−2分列，未补造提前用药胜线。L9旧参考681、PU717及YQL960—963的近十亿enemyHp确在explore.target.anchor.ranked；它们不是本体进度。PU第五试T15实际赢余2，但同时改变后续行动与抽序，不能当改参考排序的受控胜线。见`giant-poison-use.json`、`giant-anchor-audit.json`、`attempts-audit.json`。

## 现有源码覆盖及不能宣称完成的部分

`source-manifest.json`保存18个精确base blob、字节数/SHA、完整源码提交、实际live祖先核验与源快照`.txt`，没有完整仓库副本。核对时实际live为`""" + source["live_observed"] + """`。potion-cost.ts和explore.ts的live字节不同仅为Roy/Dai注释署名；原差异patch和live文本已保存，不说两树全等。其余所选16文件字节相同，18个base最后源码提交均为该live祖先；这只证明所选源码存在。

|已有窄能力|文件与可核的实际live祖先源码提交|尚缺|
|---|---|---|
"""
capabilities = [
    ("SL原/替线当轮预测及差值", "agent/src/reflex/silent-sl-resource-comparison.ts", "不是实际执行结果，execution为unverified"),
    ("HP护栏候选分账", "agent/src/reflex/silent-hp-guard-audit.ts", "actual_outcome仍null，SL与后续重问可再次换线"),
    ("持牌保守失血和未决弃牌提示", "agent/src/reflex/silent-held-loss.ts", "不把剩余差额声明为已确定敌伤，不认证实际持牌结算"),
    ("未知持有价值和本轮/整战无药参考", "agent/src/reflex/silent-potion-reference.ts", "不能认证未执行分支或跨战留药价值"),
    ("巨兽本体/残壳、自爆与毒药原观察", "agent/src/reflex/silent-giant-potion.ts", "不改参考排序，不推断提前用药效果"),
    ("选择阶段记录", "agent/src/reflex/silent-selection-audit.ts", "execution_status=pending_dispatch，actual_turn=null"),
    ("单动作派发回执", "agent/src/reflex/silent-selection-dispatch.ts", "whole_plan_executed=null，state_effect_verified=false"),
    ("巨兽阶段与受限最终资源记录", "agent/src/sl/attempts.ts", "最终资源仅有限已核修饰集适用，不能填本批未知组合"),
]
for title, path, missing in capabilities:
    entry = next(x for x in source["files"] if x["path"] == path)
    intro += f"|{title}|{path} / `{entry['last_source_commit']}`|{missing}|\n"
intro += """
`combat-plan.ts`已经把上述字段接入候选题面、SL重放/偏离和选择审计；`hand/loop.ts`消费单动作回执。`explore.ts`保留未强制notWorseOnly时在较差未试线中探索、最长存活后原始残血的同轮排序。字段存在、接入存在、单动作返回、完整方案兑现和策略收益是不同证据阶段；本批没有把旧窄源码登记为整项duplicate或implemented。

## 逐项提案处置

"""
for p in proposals:
    intro += f"### {p['id']}\n\n- 原摘要：{p['summary']}\n- 证据：{evidence[p['id']]}\n- 既有账本：{', '.join(p['ledger'])}。\n- 来源任务：{p['source_task']}；实现任务：{p['target_task']}；原领域：{', '.join(p['domains'])}。\n- 处置：waiting。{reasons[p['id']]}\n- 原Markdown：`{p['proposal']}`；原字节副本：`{p['id']}.original.md`。\n\n"
intro += """## 后续验证与回退

本批不拟合权重、HP价或阈值；本批原六局只用于历史固定复核，不能又当新训练又报后期独立检验。下一步需要原调度器从自然新局取得候选选择、实际动作、抽弃/生成/用药重问和完整后继的可归属链；模型对照须冻结实际可得输入、随机池及总预算，分别报告未知。留药结论需同角色可比入口、实际后战资源与不使用支线，不能把八个模拟样本当八局。若未来拟合，则按独立局真实时间切分、明确训练/留出及机制覆盖，不向其他角色或未观察进阶外推。

没有新源码，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；8444条字节复核和材料断言不是生产测试，也没有新运行整战模拟。无提交因此未触发提交前测试或gitleaks门禁，无live合并、版本、规则上线双通知或ledger shipped。现有策略保持；不存在本批需回退的源码commit。根账本只经CLI追加本批提案/报告链接和等待说明，不追加重复support/repeat，不更改原claim、首证、进阶、prior、status、version或effect。原失败历史、提案和父要求均保留。

## 过程校正与产物

首次learn.json读取筛选过宽导致输出截断，随后改为精确batch行；其他批次未用作本批证据。首次源快照误用不存在的hand/execute.ts，git show128、包装1；按实际hand/act/dispatch.ts改正，记录见source-snapshot-first-failure.txt。两次探索性打印分别碰到非战斗combat=null和无plan题面而提前结束，之后按COMBAT及存在plan过滤；都不是生产测试失败。第一次材料脚本的anchor取值少了一层target，仅使衍生anchor字段为null；原稿attempts-audit.first-anchor-path.json保留，修正脚本后重新全量核所选8444条原引用并按六条旧参考核回。最终两次材料校验日志分别audit-materials-first.log与audit-materials-final.log，均退出0；第一次anchor提取遗漏不改称已核。

报告和提案仅保存在本批learner/runs；工作树代码、任务、全部知识零差异。账本CLI回执与最终机械验收另存`ledger-cli.log`、`ledger-records.jsonl`、`final-verification.json`。最终JSON见`result.json`。
"""
(HERE / "proposal.md").write_text(intro)
(HERE / "report.md").write_text(intro.replace("# 静默猎手策略提案逐项复核", "# 静默猎手策略学习报告", 1))
result = {"task": "strategy-proposal", "character": "silent", "batch": "20261018-051302-strategy-proposal",
          "base": base, "runs": dispatch["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": dispatch["proposal_ids"], "implementation_domains": [],
          "proposal_results": results, "report": str(HERE / "report.md")}
(HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
updates = []
for ident in sorted({i for p in proposals for i in p["ledger"]}):
    linked = [p["id"] for p in proposals if ident in p["ledger"]]
    updates.append({"id": ident, "by": "learner:strategy-proposal", "where": {"proposal": [str(HERE / "proposal.md"), str(HERE / "report.md"), *linked]},
                    "note": "20261018-051302-strategy-proposal仅复核原六局与现有窄源码，所关联派发提案全部waiting，逐项缺口见本批报告；无新增独立局、重复support/repeat、新源码、合入、版本或shipped。保留原claim/首证/进阶/prior/status/version/effect。"})
(HERE / "ledger-updates.json").write_text(json.dumps(updates, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"proposal_results": len(results), "ledger_updates": len(updates), "base": base, "report": result["report"]}, ensure_ascii=False))

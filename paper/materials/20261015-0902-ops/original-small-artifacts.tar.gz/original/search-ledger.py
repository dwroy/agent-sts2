import subprocess,json,pathlib
p=pathlib.Path(__file__).parent
for term in ['贪婪','GREED','早店','四连','弹跳药瓶','FLYCONID','飞蝇菌子','FORTIFIER','佩尔之爪','OVICOPTER','磨蚀','VANTOM','入场']:
 r=subprocess.run(['python3','learner/ledger.py','find','--character','silent','--text',term,'--json'],text=True,capture_output=True)
 (p/f'ledger-search-{term}.json').write_text(r.stdout)
 print('TERM',term,'rc',r.returncode,flush=True)
 if r.returncode==0:
  for x in json.loads(r.stdout):print(x['id'],x['status'],x.get('version'),x['first_run'],x['claim'][:450],flush=True)

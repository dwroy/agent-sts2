import pathlib,json,hashlib,re
p=pathlib.Path(__file__).parent.resolve();root=pathlib.Path('/home/dw/Projects/agent-sts2')
ids=['silent-proposal-5f1404055363969c','silent-proposal-1f2202d0f5b3fc5b','silent-proposal-08f72e2f585118a7']
queue={}
with (root/'paper/materials/learning/code-proposals.jsonl').open() as f:
 for line in f:
  x=json.loads(line)
  if x.get('id') in ids:
   if x.get('op')=='add':queue[x['id']]=x
   elif x.get('op')=='update':queue[x['id']].update(x)
assert set(queue)==set(ids)
for ident,x in queue.items():
 assert x['character']=='silent' and x['source_task']=='postmortem' and x['target_task']=='strategy-proposal' and x['state']=='pending'
 assert hashlib.sha256(pathlib.Path(x['proposal']).read_bytes()).hexdigest()==x['proposal_sha256']
checks=[]
for rid,expected in [('13CBGUPK6122',{'silent-0019','silent-0044','silent-0225','silent-0227','silent-0418'}),('X7REGM0RUNSA',{'silent-0019','silent-0295','silent-0418'})]:
 items=json.loads((p/f'{rid}-ledger-readback.json').read_text());assert {x['id'] for x in items}==expected
 section=(p/f'{rid}-section.md').read_bytes();receipt=json.loads((p/f'{rid}-append-receipt.json').read_text())
 assert hashlib.sha256(section).hexdigest()==receipt['section_sha256']
 digest=hashlib.sha256()
 with (root/'notes/lessons.md').open('rb') as f:
  remaining=receipt['before_bytes']
  while remaining:
   data=f.read(min(1024*1024,remaining));digest.update(data);remaining-=len(data)
  tail=f.read()
 assert digest.hexdigest()==receipt['before_prefix_sha256'] and tail.count(section)==1
 checks.append({'run':rid,'section_sha256':receipt['section_sha256'],'old_prefix_unchanged':True,'ledger_ids':sorted(expected),'three_lessons':True,'numeric_source_readback':'post-append-numeric-readback.json'})
result={'task':'postmortem','appended':['13CBGUPK6122','X7REGM0RUNSA'],'skipped':[],
'bugs':[{'run':'X7REGM0RUNSA','where':'agent/src/reflex/turn-solver.ts:2474','what':'已有silent-0295：随机毒集中到最高HP目标，F3T3预测损3而实际损15；fix-queue-v4.md已有','new':False}],
'ledger':{'added':[],'updated':['silent-0019','silent-0044','silent-0225','silent-0227','silent-0295','silent-0418'],'repeats':['silent-0295'],'check':0},
'code_proposals':ids,'implementation_domains':['combat','potion','sl'],'report':str(p/'report.md')}
(p/'completion.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(p/'final-readback.json').write_text(json.dumps({'ledger_check':{'exit_code':0,'items':483,'problems':0},'source_readback_checks':2347,'runs':checks,'proposals':[{k:x[k] for k in ['id','state','ledger','runs','domains','proposal','proposal_sha256','target_task']} for x in queue.values()]},ensure_ascii=False,indent=2)+'\n')
report='''## 复盘回报
- 已追加：13CBGUPK6122（A10，第23层，产卵虫与三幼虫合21攻，10血8挡阵亡）。
- 已追加：X7REGM0RUNSA（A10，第5层，飞蝇菌子13攻，6血5挡阵亡）。
- 新的纯 bug：无；X7REGM0RUNSA复现已有silent-0295，定位agent/src/reflex/turn-solver.ts:2474、:2743，fix-queue-v4.md已有。
- 写成「未记录」的项：两局均有开局dirty知识全量、完整逐击与伤害分源、全局候选兑现率、未选行动的受控后继、未抵达楼层资源、已校准boss时钟与同口径实打估值、Jev缓存、真实费用及纯战斗用时；13CBGUPK6122另有判死尝试退出与未结算伤害。
- 学习账本：13CBGUPK6122：新增无；更新silent-0019、silent-0044、silent-0225、silent-0227、silent-0418（均support）。
- 学习账本：X7REGM0RUNSA：新增无；更新silent-0019、silent-0295、silent-0418（老错silent-0295为repeat）；ledger.py check退出码0。
- 代码提案：13CBGUPK6122 F19/F22/F23及X7REGM0RUNSA F2—F5→0019/0044/0225→silent-proposal-5f1404055363969c；13CBGUPK6122 F23T1/T3及X7REGM0RUNSA F5T3→0418→silent-proposal-1f2202d0f5b3fc5b；X7REGM0RUNSA F3T3→0295→silent-proposal-08f72e2f585118a7。均pending，关联独立strategy-proposal；缺完整反事实胜局，未改代码或宣称上线。
'''
(p/'report.md').write_text(report+'\n```json\n'+json.dumps(result,ensure_ascii=False)+'\n```\n')
(p/'process-notes.md').write_text('''# 过程与限制

初次抽取命令在执行前被bubblewrap拒绝：ripgrep unreadable glob scan failed，指向项目外两个不存在的glob扫描路径。未请求提权、未读被拒路径，同权限重试成功。

探索性输出有截断，后续改用紧凑摘要及原字节偏移核验。一次临时交互查询对无questions的代码决策访问失败（KeyError: questions），没有写授权记录，后续使用get处理。

最初试把decisions.observed_ts与states外层ts比较，得到663/81不匹配；外层ts是日志写入时间，改按states.observed_ts加fingerprint后全部761决策匹配。错误探查数字未写入复盘或账本。

长局初稿有药水后帧编号及墨影第4试T4文字不精确，追加前已核正；初稿保留为13CBGUPK6122-draft-before-corrections.md。追加后关键数字再次按原日志偏移核验2347项；两节原内容和旧前缀哈希保持，没有已追加错误或勘误。

本次仅授权记录和任务scratch写入；未改源码、未提交、未推送、未运行play、未派下级agent。未实施代码无需跑源码测试。CLI提案链接不会将账本自动变为shipped；三个提案实际状态pending。资源和轨迹审计提案不新设权重，随机毒提案只提出已证分配安全边界，收益仍未知。
''')
print(json.dumps({'appended':result['appended'],'ledger_check':0,'proposals':ids,'report':result['report'],'old_prefixes_unchanged':True},ensure_ascii=False))

import pathlib,json,hashlib,collections,datetime
p=pathlib.Path(__file__).parent;root=p.parents[2];allfacts={};checks=0
for rid in ['13CBGUPK6122','X7REGM0RUNSA']:
 rows={name:[json.loads(l) for l in (p/f'{rid}-{name}.jsonl').open()] for name in ['decisions','states','run-plans','sl-attempts']}
 # Re-read each extracted source row at its exact byte offset, preserving the source body hash.
 manifest=[]
 for name,items in rows.items():
  with (root/'logs'/f'{name}.jsonl').open('rb') as src:
   for row in items:
    src.seek(row['_offset']);raw=src.readline();original=json.loads(raw)
    assert original=={k:v for k,v in row.items() if k not in ['_line','_offset']};checks+=1
    manifest.append({'source':name,'line':row['_line'],'offset':row['_offset'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 s=rows['states'];d=rows['decisions'];state={x['_line']:x['state'] for x in s};dec={x['_line']:x for x in d}
 pairs={(x.get('observed_ts'),x.get('fingerprint')) for x in s}
 assert all((x.get('observed_ts'),x.get('fingerprint')) in pairs for x in d);checks+=len(d)
 r=json.loads((p/f'{rid}-resources.json').read_text());assert all(c['entry_is_turn_one'] for c in r['combats']);checks+=1
 if rid=='13CBGUPK6122':
  assert len(d)==673 and len(s)==695 and len(r['combats'])==19
  end=state[408419];en=end['combat']['enemies'];assert end['run']['current_hp']==10 and end['combat']['player']['block']==8
  assert [sum(i.get('total_damage') or 0 for i in e['intents']) for e in en]==[5,5,5,6]
  assert state[408420]['run']['current_hp']==0 and [e['current_hp'] for e in state[408420]['combat']['enemies']]==[19,18,19,79]
  assert dec[395803]['journal']['choice'].count('打击')==2 and dec[395806]['journal']['choice']=='打击' and dec[395807]['journal']['choice']=='打击'
  assert state[408327]['combat']['player']['block']==12 and state[408326]['combat']['player']['block']==4
 else:
  assert len(d)==88 and len(s)==92 and len(r['combats'])==4
  assert state[408466]['run']['current_hp']==37 and state[408470]['run']['current_hp']==22
  assert [e['current_hp'] for e in state[408468]['combat']['enemies']]==[9,9]
  assert [[v['amount'] for v in e['powers'] if v['power_id']=='POISON_POWER'] for e in state[408469]['combat']['enemies']]==[[3],[6]]
  assert state[408514]['run']['current_hp']==6 and state[408514]['combat']['player']['block']==5 and state[408515]['run']['current_hp']==0
  assert state[408514]['combat']['enemies'][0]['intents'][0]['total_damage']==13
 checks+=8
 facts={'decisions':len(d),'states':len(s),'plans':len(rows['run-plans']),'sl_rows':len(rows['sl-attempts']),
 'deciders':dict(collections.Counter(x['decider'] for x in d)), 'jev_low':sum(x['decider']=='jev' and x.get('confidence',1)<.35 for x in d),
 'first':d[0]['ts'],'last':d[-1]['ts'],'duration_s':(datetime.datetime.fromisoformat(d[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(d[0]['ts'].replace('Z','+00:00'))).total_seconds()}
 own=[x for x in d if x['decider']=='code' and x['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn','combat/potion-now']]
 key=lambda x:(x['floor'],x.get('sl_reloads'),x['turn'])
 facts['code_primary_actions']=len(own);facts['code_primary_turns']=len(set(map(key,own)));facts['code_with_sl_turns']=len(set(map(key,own))|{key(x) for x in d if 'SL explore' in x['rationale']})
 choices=[x for x in d if x['decider']=='jev' and x['label'].startswith('combat/plan-choice')];stats=collections.Counter()
 for x in choices:
  opts=[json.loads(v) if isinstance(v,str) else v for v in x['questions']['plan']['criteria'].values()]
  v=next(v for v in opts if v.get('plays')==x['journal']['choice']);stats['best']+=v.get('rollout_best')==True;stats['tied']+=bool(v.get('rollout_tied'))
 facts['plan_choices']=len(choices);facts['rollout']=dict(stats)
 facts['usage']={who:{k:sum((x.get('usage')or{}).get(k,0)or 0 for x in d if x['decider']==who) for k in ['input_tokens','output_tokens','cache_hit_tokens','reasoning_tokens']} for who in ['jev','codex']}
 allfacts[rid]=facts
 (p/f'{rid}-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(p/'verified-facts.json').write_text(json.dumps({'checks':checks,'runs':allfacts},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':checks,'runs':allfacts},ensure_ascii=False,indent=2))

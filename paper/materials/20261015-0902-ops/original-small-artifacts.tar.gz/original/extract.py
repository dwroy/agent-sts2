import json,pathlib
root=pathlib.Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261015-084306-3deb917f-1918-4192-b70d-f316770d7d95-postmortem'
ids=['13CBGUPK6122','X7REGM0RUNSA']
for name in ['decisions','run-plans','sl-attempts','states']:
    sinks={r:(out/f'{r}-{name}.jsonl').open('w') for r in ids}
    counts={r:0 for r in ids};offset=0
    with (root/'logs'/f'{name}.jsonl').open('rb') as h:
        cutoff=h.seek(0,2);h.seek(0)
        for n,line in enumerate(h,1):
            start=offset;offset+=len(line)
            if offset>cutoff:break
            for rid in ids:
                if rid.encode() not in line:continue
                try:row=json.loads(line)
                except ValueError:continue
                if name=='run-plans': match=row.get('run')==rid
                elif name=='states':match=(row.get('state') or {}).get('run_id',row.get('run_id'))==rid
                else:match=row.get('run_id',row.get('run'))==rid
                if not match:continue
                row['_line']=n;row['_offset']=start
                sinks[rid].write(json.dumps(row,ensure_ascii=False)+'\n');counts[rid]+=1
    for h in sinks.values():h.close()
    print(name,counts,flush=True)

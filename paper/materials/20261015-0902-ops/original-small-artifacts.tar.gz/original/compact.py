import pathlib,json,collections,re,datetime
p=pathlib.Path(__file__).parent
for rid in ['13CBGUPK6122','X7REGM0RUNSA']:
 s=[json.loads(l) for l in (p/f'{rid}-states.jsonl').open()];d=[json.loads(l) for l in (p/f'{rid}-decisions.jsonl').open()];r=json.loads((p/f'{rid}-resources.json').read_text())
 print('\nRUN',rid)
 for c in r['combats']:
  e=c['entry'];ex=c['exit'];last=c['last'];st=[]
  for x in s:
   if e['line']<=x['_line']<=last['line'] and (not st or st[-1][0]!=x['state'].get('turn')):
    z=x['state'];en=z.get('combat',{}).get('enemies',[]);st.append((z.get('turn'),z['run']['current_hp'],sum(v['current_hp'] for v in en if v.get('is_alive'))))
  print('C',c['sequence'],'F',c['floor'],'IDs',c['enemies'],'HP',e['hp'],(ex or last)['hp'],'max',e['max_hp'],(ex or last)['max_hp'],'P',e['potions'],(ex or last)['potions'],'S',e['line'],(ex or last)['line'],'T',e['turn'],(ex or last)['turn'],c['end'],'turn:HP:enemy',st)
 print('OUTSIDE/SL CHANGES')
 for x in r['resource_changes']:
  if x['combat_sequence'] is not None:continue
  a=x['from'];b=x['to'];print('SL' if x['restart_boundary'] else 'out','F',a['floor'],b['floor'],'HP',a['hp'],b['hp'],'P',a['potions'],b['potions'],'S',a['line'],b['line'],'time',b['ts'])
 jev=[x for x in d if x['decider']=='jev'];plans=[x for x in jev if x['label'].startswith('combat/plan-choice')]
 ranks=collections.Counter();roll=collections.Counter();focus=[]
 for x in plans:
  m=re.search('code rank (\d+)',x['rationale']);ranks[int(m[1]) if m else None]+=1
  criteria=x['questions']['plan']['criteria'];chosen=x.get('journal',{}).get('choice','');opts={k:json.loads(v) if isinstance(v,str) else v for k,v in criteria.items()};key=next((k for k,v in opts.items() if v.get('plays')==chosen),None)
  if key:
   v=opts[key];rv={k:z for k,z in v.items() if 'best' in k or 'rollout' in k or 'focus' in k};roll[str(rv.get('rollout_best','missing'))]+=1
   if any('focus' in k for k in v): focus.append((x['_line'],x['floor'],x['turn'],{k:z for k,z in v.items() if 'focus' in k}))
  else:roll['no-match']+=1
 print('plans',len(plans),'ranks',ranks,'roll',roll,'focus',focus)
 print('JEV_P1_KEYS',list(json.loads(next(iter(plans[0]['questions']['plan']['criteria'].values())))))
 autonomous=[x for x in d if x['decider']=='code' and x['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn','combat/potion-now']]
 print('AUTONOMOUS',len(autonomous),collections.Counter(x['label'] for x in autonomous),'windows',len(set((x['floor'],x.get('sl_reloads'),x['turn']) for x in autonomous)))
 print('guard',[(x['_line'],x['rationale']) for x in d if re.search('HP guard|hp.guard|护栏',x['rationale'],re.I)])
 print('usage sums', {dec:{k:sum((x.get('usage') or {}).get(k,0) or 0 for x in d if x['decider']==dec) for k in ['input_tokens','output_tokens','cache_read_input_tokens','cached_input_tokens','reasoning_tokens']} for dec in ['jev','codex']})
 print('duration',(datetime.datetime.fromisoformat(d[-1]['ts'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(d[0]['ts'].replace('Z','+00:00'))).total_seconds())

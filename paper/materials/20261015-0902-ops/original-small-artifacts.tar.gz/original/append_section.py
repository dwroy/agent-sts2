import pathlib,subprocess,hashlib,json,sys
p=pathlib.Path(__file__).parent;rid=sys.argv[1];dest=pathlib.Path('/home/dw/Projects/agent-sts2/notes/lessons.md')
section=(p/f'{rid}-section.md').read_text()
with dest.open('rb') as h:
 for line in h:
  if line.startswith(('## '+rid).encode()):raise SystemExit('已存在该局标题，禁止重复追加')
size=dest.stat().st_size;prefix=hashlib.sha256()
with dest.open('rb') as h:
 remaining=size
 while remaining:
  chunk=h.read(min(1024*1024,remaining));prefix.update(chunk);remaining-=len(chunk)
assert '\nEOF\n' not in section
script="cat >> /home/dw/Projects/agent-sts2/notes/lessons.md <<'EOF'\n"+section+'EOF\n'
(p/f'append-{rid}.sh').write_text(script)
subprocess.run(['bash',str(p/f'append-{rid}.sh')],check=True)
after=hashlib.sha256()
with dest.open('rb') as h:
 remaining=size
 while remaining:
  chunk=h.read(min(1024*1024,remaining));after.update(chunk);remaining-=len(chunk)
 tail=h.read()
assert prefix.hexdigest()==after.hexdigest();assert tail.count(section.encode())==1
receipt={'run':rid,'before_bytes':size,'before_prefix_sha256':prefix.hexdigest(),'prefix_unchanged':True,'section_sha256':hashlib.sha256(section.encode()).hexdigest(),'section_bytes':len(section.encode()),'append_command':str(p/f'append-{rid}.sh')}
(p/f'{rid}-append-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))

import json,pathlib,collections,re,datetime
p=pathlib.Path(__file__).parent
for rid in ['13CBGUPK6122','X7REGM0RUNSA']:
 d=[json.loads(l) for l in (p/f'{rid}-decisions.jsonl').open()]
 s=[json.loads(l) for l in (p/f'{rid}-states.jsonl').open()]
 r=json.loads((p/f'{rid}-resources.json').read_text())
 print('\nRUN',rid,'statekeys',list(s[0]['state']))
 print('DECIDERS',collections.Counter(x['decider'] for x in d),'low',sum(x['decider']=='jev' and x.get('confidence',1)<.35 for x in d),'fallback',sum(bool(x.get('fallback')) for x in d))
 for c in r['combats']:
  ent=c['entry'];ex=c['exit'];last=c['last'];audit=c.get('enemy_hp_audit',{})
  print('COMBAT',c['sequence'],c['floor'],c['enemies'],'entry',ent,'exit',ex,'last',last if not ex else '',c['end'],'net',c['observed_net_hp_loss'])
  turns=[]
  for row in s:
   if not (ent['line']<=row['_line']<=last['line']):continue
   st=row['state'];t=st.get('turn');run=st.get('run') or {};en=(st.get('combat') or {}).get('enemies') or []
   if turns and turns[-1]['turn']==t:continue
   turns.append({'turn':t,'line':row['_line'],'hp':run.get('current_hp'),'enemies':[(e.get('enemy_id'),e.get('name'),e.get('current_hp'),e.get('block'),e.get('intents'),e.get('powers')) for e in en]})
  print('TURNS',json.dumps(turns,ensure_ascii=False))
 print('CHANGES')
 for x in r['resource_changes']:
  a=x['from'];b=x['to'];print(x['combat_sequence'],x['restart_boundary'],a['floor'],a['turn'],a['hp'],a['max_hp'],a['potions'],'->',b['floor'],b['turn'],b['hp'],b['max_hp'],b['potions'],b['line'],b['ts'])

# 过程与限制

初次抽取命令在执行前被bubblewrap拒绝：ripgrep unreadable glob scan failed，指向项目外两个不存在的glob扫描路径。未请求提权、未读被拒路径，同权限重试成功。

探索性输出有截断，后续改用紧凑摘要及原字节偏移核验。一次临时交互查询对无questions的代码决策访问失败（KeyError: questions），没有写授权记录，后续使用get处理。

最初试把decisions.observed_ts与states外层ts比较，得到663/81不匹配；外层ts是日志写入时间，改按states.observed_ts加fingerprint后全部761决策匹配。错误探查数字未写入复盘或账本。

长局初稿有药水后帧编号及墨影第4试T4文字不精确，追加前已核正；初稿保留为13CBGUPK6122-draft-before-corrections.md。追加后关键数字再次按原日志偏移核验2347项；两节原内容和旧前缀哈希保持，没有已追加错误或勘误。

本次仅授权记录和任务scratch写入；未改源码、未提交、未推送、未运行play、未派下级agent。未实施代码无需跑源码测试。CLI提案链接不会将账本自动变为shipped；三个提案实际状态pending。资源和轨迹审计提案不新设权重，随机毒提案只提出已证分配安全边界，收益仍未知。

# 执行过程限制

- 首次learn.json筛选误匹配父batches对象，导致工具输出过宽；后续改用本批键精确读取。分析与处置只采用本批10个proposal_ids，没有领取、改写或处理其他批次。
- 第一次scratch证据审计导入路径错一层，退出1；原错误摘要保存在audit-first-failure.txt，改正后完成逐字节校验。
- 第一份饮用动作关联把option_index误当potion_index，且用observed_ts对齐了前一帧；旧初稿保存在drink-transitions-initial.json。最终改为决策同指纹、决策ts以及严格后继帧，66项算术核验仅使用修正版。
- 初始selected-ledger.json只按最后一行覆盖，不能代表append-only账本的累计内容；正式使用根ledger.py的fold得到selected-ledger-folded.json。
- 一次ledger CLI命令在shell启动之前被沙箱glob扫描ENOENT阻断，错误路径为并行校准任务已消失的sl-replay-8PEYbO/sl-replay-9TJkVd。该次没有执行写入；沿同一权限重试后CLI成功追加31条。没有扩大权限或修改并行目录。

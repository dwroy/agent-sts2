# 本批十项策略提案核验与处置

记录时间：2026-10-15 17:16:26 CST。批次：20261015-170527-s2-strategy-proposal。角色：silent。
基线：`e8931a14f1f9b0bf055f4e44d63ac14e5a13f592`。仅消费本批十个既有id，不创建重复提案，不改原文。

以下账本关联使用根ledger.py正式fold；selected-ledger.json只是初始定位快照，逐行覆盖不是账本真实合并口径，不能用其最后一条evidence代表全部历史。权威快照为selected-ledger-folded.json。

## silent-proposal-08eaa60bcc449852：赢战耗药与下一战资源结转

账本：silent-0019,silent-0020。来源任务：experience-update；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md；SHA256：4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016（本批核相同，原字节副本为同名.original.md）。
证据：KEN58SH9SLZ6 A10：F3T2、F4T1、F5T2、F11T1/T2、F15T1共7次饮用，d274131/156/185/235/237/267/272；F2/3/4/5/11/15胜战净损0/3/0/37/6/0，共46。F12 s280336→337回27，F16 s280382→383回29，均同时增生命上限，不能用固定旧上限替代。
反例和限制：F15净损0但喝了发光药水和技能药水；F5获胜仍净损37。没有不饮用或留到Boss的同入口整战。
已有源码/覆盖：当前模型已区分实际药栏、临时/持续资源与后继；未定位本批可新增的确定性结转差异。原105局统计未在本批重算，不能将15局称全史。
旧行为与本批预期：保留现饮用/持有价值；后续比较完整候选的退出HP、剩余药槽与下一战结果，分开SL恢复、真实回复和奖励。
本项处置：waiting。缺同入口、后续抽牌及药栏下不饮用或留到Boss的成对整战结果，七次实际饮用和两次真实回复不足重拟持药价。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-92920295a648b540：首场改善与连续通关分账

账本：silent-0228,silent-0255。来源任务：postmortem；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md；SHA256：f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf（本批核相同，原字节副本为同名.original.md）。
证据：TXZ6RVMQA09D A10 F48第二/三试T6：sl973/974显示48血/敌460起，次轮分别45/424与48/433，实损3/0、敌净扣36/27；d275383–385记录换线。第三试F48结束4血，F49 s281565→566为4→0且无可操作帧。
反例和限制：第三次赢首场仍死于第二场；抽牌和生成改变，少损3同时少输出9，不能把首胜当连续通关改进。
已有源码/覆盖：e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a是实际live祖先，已覆盖受限开场扣4；boss-sim continuationInput按首场真实样本余HP/药/复活传递，不把此子项重复实现为整项。
旧行为与本批预期：保留SL资格与终局权重；按尝试同时验首场结局、退出资源、次战开场及两战结局，不用低可信0%放宽必死门槛。
本项处置：waiting。缺保持后续抽牌、生成和药栏一致的两战通关替线；开场扣血已实现不能关闭连战/SL资源校准宽项。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-a327449c331efbc1：沙虫SL双向血价与沙坑边界

账本：silent-0079,silent-0018。来源任务：postmortem；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md；SHA256：e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925（本批核相同，原字节副本为同名.original.md）。
证据：WQZVENQ7DTRP A10 F33第2/3试T9（d275894/275960、sl980/981）同26血/敌184：原线损13/扣24，替线损22/扣39。第2/6试T7（d276139、sl980/984）分别损0/4、同扣24；s282330→331沙坑4→5。
反例和限制：多付4血延长沙坑一轮是反向约束，不能一律禁多损血；六次全败，未有只保血的受控完整胜线。
已有源码/覆盖：live祖先5604982e13890e0e2bc8bf8246272e8267321c0b与c769739b97389fdc978b6515b83a38e3cd900f67已有血价/伤害/沙坑/敌剩血预测审计；actual_turn_result仍为空，未冒充整候选执行。
旧行为与本批预期：继续同时保留血价、伤害、已结/未结毒和沙坑；按局分组、时间后移验证后再考虑规则变化。
本项处置：waiting。缺双边界完整受控后继和独立胜局，现有候选预测不能校准新的探索排序或固定血价阈值。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-a099e89437e942bb：狡诈容量、保留与完整穿插序列

账本：silent-0030,silent-0257,silent-0258。来源任务：experience-update；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md；SHA256：e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2（本批核相同，原字节副本为同名.original.md）。
证据：九局42次狡诈饮用全部以决策option_index和同指纹状态接续核验：37次添3、2次添2、3次添0；所有新增均SHIV且upgraded=true，HP/能量不变。WQ F33第5试T11 d276102/103/104为8→10→10→10，第6试d276161/162/163为5→8→10→10。九局角色均已核；A7/A9/A10分列。
反例和限制：容量不足只在WQ观察到；满手消耗药瓶不等于多打出小刀。穿插序列的固定模型支持不等于完整真实候选已执行或胜率改善。
已有源码/覆盖：6403fdcdadc803a092beb5165a068e22bf51c412是live祖先，card-model/turn-solver已模型化3张升级小刀、10手上限和释放手位后再饮用；现有silent-cunning.test.ts已有2/0/0、3/2/0和穿插用例，本批未重跑。
旧行为与本批预期：保留已有确定生成；以后冻结保留选择题、实际手位和完整派发/重规划归属，不把模型中的额外刀数当本局已兑现收益。
本项处置：waiting。确定生成及容量子项已实现；仍缺计划妥当保留选择、出刀穿插、完整候选派发与SL恢复的联合消费者校准，不能登记整项duplicate。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-47910f82a1fdd98f：连战开场与SL资源价值

账本：silent-0018,silent-0019,silent-0020,silent-0021,silent-0025,silent-0079,silent-0198,silent-0228,silent-0255。来源任务：experience-update；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md；SHA256：d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd（本批核相同，原字节副本为同名.original.md）。
证据：TXZ6RVMQA09D A10 F43/45/46/48/49分别70→66、52→48、62→58、60→56、4→0，均出牌前；s281312/313、281338/339、281367/368、281399/400、281565/566。WQ F33T7/T9双向血价同上。
反例和限制：不把其他回血/复活组合或未观察结算顺序套成扣4；不把SL恢复当路线回血或新获药，不以未抵达营火为现有HP。
已有源码/覆盖：受限开场子项live祖先e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a；ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8后续组合扩展也已是live祖先。旧fc7042d1df0626e9e726f4bc912d9c6f626d908f不是live祖先，不可拿它自报implemented。
旧行为与本批预期：保持已见分支开场结转，未知组合保留限制；不新增SL、路线或持药权重。
本项处置：waiting。开场子项已有实际live源码；缺留药、路线、SL的完整后继对照及未知回血/复活组合顺序，资源价值宽项仍未验证。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-f1374df72d8e6a25：连续战斗退出资源与用药价值

账本：silent-0019,silent-0020,silent-0050,silent-0253。来源任务：postmortem；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md；SHA256：df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0（本批核相同，原字节副本为同名.original.md）。
证据：1913SE84AXQF A10 F29 s282723→282750为61→46，F31 s282755以46血入场。Q6M2Y34MWKRE A10 F7 s282869→870为36→57，F8 s282872→907赢后2血，F9 s282913→921为2→0。Q6 F8T4紧勒链103→95→85→83→80独立核验。
反例和限制：Q6 F2早喝敏捷的候选未完整执行；F5/F6零损留药不支持全局提前喝。1913 F24改锻造改变路线条件，不能当同条件预测误差。
已有源码/覆盖：普通紧勒局部漏伤已有live祖先5c7105ff0294466da8319f2934beda05c6040794，不把它再次归成药水价值参数错误；本批未新增受控整战。
旧行为与本批预期：保留现权重/护栏；按真实退出HP、药栏、实际持续时间及下一战结果验证，不能把候选省血当实得回血。
本项处置：waiting。缺隔离机制误差后同入口、同预算及同后续的未用、早用、留药成对整战结果，单题候选不足校准持药价或终局权重。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-38a49e6c97f31eea：紧勒与增益、复活、再生的联合校准

账本：silent-0006,silent-0011,silent-0025,silent-0044,silent-0050,silent-0064,silent-0133,silent-0253,silent-0259,silent-0261,silent-0262。来源任务：experience-update；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md；SHA256：6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0（本批核相同，原字节副本为同名.original.md）。
证据：Q6M2Y34MWKRE A10 F8T4 s282887/888/889/891/892敌血103/95/85/83/80；1913SE84AXQF A10 F31T2 s282767→768弃磨蚀能量3不变、建1敏/4荆棘；T4 s282777中段25血且无旧毒/力量，T4毒雾3建立后在s282783死亡前没有下一轮。
反例和限制：普通无挡紧勒不能外推升级/叠层/重放/有挡；建立毒雾不预支下一轮补毒。反伤杀敌不能提前抵销已发生的敌攻，净损不等敌总伤。
已有源码/覆盖：紧勒子项live祖先5c7105ff0294466da8319f2934beda05c6040794；中段重接清旧毒/力量live祖先0970bc0d112718d45c8ebf86ff7f84e0f36a7498，生产enemySims/rollout接线均存在。再生/临时敏捷已有模型，不为已有实现重复加权。
旧行为与本批预期：继续限制已观察普通分支，分开牌伤、逐牌失血、毒、反伤与实际回复；完整候选与后继验证不足时不改行为。
本项处置：waiting。普通紧勒和受限中段重接已实现；缺弃磨蚀、增益分源、再生、自动触发和SL恢复的完整联合消费者校准，不把局部公式覆盖当整项完成。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-ef0e38a5dbd3bc07：实际休息与未来营火、能力兑现分账

账本：silent-0019,silent-0020,silent-0021。来源任务：experience-update；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md；SHA256：d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5（本批核相同，原字节副本为同名.original.md）。
证据：1913SE84AXQF A10 F24 s282706–709锻造且HP40不变；F28 s282720→721回21至61；F29胜后46，F31以46入场死亡。Q6M2Y34MWKRE A10 F3事件44→36、F7休36→57、F8胜后2、F9死亡。
反例和限制：1913原预计F24休息后来锻造，不能把全部预测偏差当同条件bug；Q6已休息且药最终饮用，不能描述为拒绝回复或丢药。
已有源码/覆盖：已验证真实发生的节点链；没有新的同输入资源传递差异。原109局历史分母/统计不在本批重算，不用这15局替代全史。
旧行为与本批预期：只记实际完成回复，后继强制战与未来火分开；不预支未取得组件或死亡前未触发能力，不重拟路线阈值。
本项处置：waiting。缺另一营火、事件、路线与药时的完整受控结果；两条实际失败链和条件改变不足拟合资源权重或保证未来营火可达。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-7f820c02d39bfaea：饱和SL替线的成本与实际执行归属

账本：silent-0079。来源任务：postmortem；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md；SHA256：bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105（本批核相同，原字节副本为同名.original.md）。
证据：NHA2KW0RB7VP A10 F33首四试T1到T2为30→29、两敌408→400；后两试30→23、408→384，即多损6换多净扣16。d277248/277272初选生存者为pending；弃掉精确切击后，d277250/277274另题才实际派回响斩击；sl987–992六试均失败。
反例和限制：不能把初题列出的完整计划当整线已执行；两侧均未杀，跨轮净扣含次轮自动伤害，不能全归卡牌。固定重放不算独立成功样本。
已有源码/覆盖：5604982e13890e0e2bc8bf8246272e8267321c0b与c769739b97389fdc978b6515b83a38e3cd900f67已有只读预测比较；explore.ts仍按既定B2/rollout门槛与排序选择，未找到可由本败局确定的优越新规则。
旧行为与本批预期：保留探索资格/门槛，分开原答、覆盖、实际派发与整个回合结果；后续按run隔离、时间后移验证。
本项处置：waiting。缺同预算饱和排序校准、跨弃牌重规划的整候选执行归属和成对完整后继，六次全败不足确定新SL成本阈值。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。

## silent-proposal-04b6b430759815ed：油灯首次消费、蟹取整与能力兑现

账本：silent-0005,silent-0006,silent-0021,silent-0011,silent-0065,silent-0264,silent-0079,silent-0133,silent-0169,silent-0189,silent-0013,silent-0053,silent-0162,silent-0265。来源任务：experience-update；实现任务：strategy-proposal/20261015-170527-s2-strategy-proposal。
原文：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md；SHA256：188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58（本批核相同，原字节副本为同名.original.md）。
证据：K3676LU8B0UH A1 F30T2 s217009→010首毒0→8，后s217011到15；SADL3CGYTGSR A7 F45T1 s232562→563首毒0→10、随后19；NHA2KW0RB7VP A10 F33T1 s283394→395普通X1萎靡实−2力/2弱。F33T2 s283398/399转身后合计意图22、15挡实际损7。
反例和限制：油灯原始遗物对象只有index/id/name/description/stack/is_melted，施用前后字段相同，未暴露首次已消费标记；不能仅凭持有、当前毒0或T1补出该状态。其他X/升级/叠层及缺前缀/新战/SL恢复仍未知。
已有源码/覆盖：蟹取整窄修复ec29ea34b919344b707e57ba472ea210f9c39d62及实际重放f2c7cc1a7288893bceae0f0b20304a2b1fae5f57均是live祖先；当前从精确A10数据库读基伤并保留虚弱小数。精确切击七手分支已在当前源码；未把这些子项当油灯已完成。
旧行为与本批预期：保留已见数值和未知；先取得可恢复的首次消费输入、完整前缀与消费者验证，再实现油灯，不凭遗物静态文本补一般化规则。
本项处置：waiting。蟹取整等子公式已实现；油灯缺可靠首次消费来源及跨动作、新战、SL恢复的联合输入校准，其他X值/升级组合和能力整战后继未知。
验证：原始行逐字节身份/SHA核验和findings-verification.json对应固定算术检查；后续行为拟合必须按独立run分组，SL不拆局，用后移新局验证，未知后继不补造。
本批没有源码变更，未撤源码/恢复源码、未跑tsc/vitest、未提交/合入/发版；不声称收益或大脑已采用。后续实现须隔离源码提交，按原沙箱/live流程自测；回退只撤其源码提交，保留本批和旧原件/账本/失败历史。


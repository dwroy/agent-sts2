from pathlib import Path
import json, subprocess, hashlib, re, os, tarfile

root = Path.cwd()
stage = root / 'ops/codex-ops/record-staging/20261015-1730'
pub = root / 'paper/materials/20261015-1730-ops'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def git(*args, cwd=root):
    return subprocess.check_output(['git', '-C', str(cwd), *args], stderr=subprocess.PIPE)
def save(name, value):
    (pub / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

learn = json.loads((root / 'ops/codex-ops/learn.json').read_text())['batches']
sid = '20261015-170527-s2-strategy-proposal'
cid = '20261015-154303-fix-batch'
sb, cb = learn[sid], learn[cid]
sr, cr = sb['report'], cb['report']
s = Path(sr['report']).parent
c = Path(cr['report']).parent
for bid, b in [(sid, sb), (cid, cb)]:
    assert b['state'] == 'done' and b['rc'] == 0 and not b['proposal_audit_errors']
    output = (root / 'ops/codex-ops/learner' / (bid + '.out')).read_text()
    thread = re.search(r'会话：([^\n]+)', output).group(1)
    event = Path(re.search(r'^日志：([^\n]+)', output, re.M).group(1))
    headers = []
    with event.open('rb') as handle:
        for _ in range(512):
            offset = handle.tell(); raw = handle.readline()
            if not raw: break
            row = json.loads(raw)
            if row.get('type') in ['learner_launch', 'learner_startup_attempt', 'learner_startup_exit', 'thread.started']:
                headers.append((row, {'offset': offset, 'bytes': len(raw), 'sha256': sha(raw)}))
            if row.get('type') == 'item.completed': break
    launch = next(x for x, ref in headers if x['type'] == 'learner_launch')
    assert launch['cwd'] == b['worktree']
    starts = [x for x, ref in headers if x['type'] == 'learner_startup_attempt']
    assert starts and len({x['input_sha256'] for x in starts}) == 1
    assert len({x['command_sha256'] for x in starts}) == 1
    assert len({json.dumps(x.get('lease'), sort_keys=True) for x in starts}) == 1
    assert [x['thread_id'] for x, ref in headers if x['type'] == 'thread.started'] == [thread]
    natives = list((root / 'ops/codex-ops/accounts/codex1/learner/sessions').glob('**/*' + thread + '.jsonl'))
    assert len(natives) == 1
    context = user = None
    with natives[0].open('rb') as handle:
        for _ in range(512):
            offset = handle.tell(); raw = handle.readline()
            if not raw: break
            row = json.loads(raw); p = row.get('payload', {})
            ref = {'offset': offset, 'bytes': len(raw), 'sha256': sha(raw)}
            if row.get('type') == 'turn_context':
                assert p['cwd'] == b['worktree'] and p['model'] == 'gpt-6.1-sol' and p['effort'] == 'xhigh'
                assert p['sandbox_policy']['type'] == 'workspace-write' and p['sandbox_policy'].get('network_access') is False
                assert p['approval_policy'] == 'never'
                context = ref | {k: p.get(k) for k in ['cwd', 'model', 'effort', 'sandbox_policy', 'approval_policy', 'service_tier']}
            if row.get('type') == 'response_item' and p.get('role') == 'user':
                words = ''.join(x.get('text', '') for x in p.get('content', []) if x.get('type') == 'input_text')
                if sha(words.encode()) == starts[-1]['input_sha256']: user = ref
            if context and user: break
    assert context and user
    save(bid + '-runtime.json', {'thread': thread, 'native': str(natives[0].relative_to(root)), 'context': context, 'input': user, 'original_lease': starts[-1].get('lease'), 'headers': [ref | {'type': x['type']} for x, ref in headers], 'no_restarted_or_permission_change': True})

assert sb['no_change_proposals']['dispositions'] == sr['proposal_results']
assert len(sr['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in sr['proposal_results'])
assert sr['fixes'] == [] and sr['merged'] is None and all(x is None for x in sr['tests'].values())
assert git('rev-parse', 'HEAD', cwd=sb['worktree']).decode().strip() == sr['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=sb['worktree']).strip()
ev = json.loads((s / 'evidence-verification.json').read_text())
assert len(ev) == 8 and sum(x['rows'] for x in ev) == 19929 and all(x['offset_bytes_sha_identity'] for x in ev)
findings = json.loads((s / 'findings-verification.json').read_text())['checks']
assert len(findings) == 66 and all(x['observed'] == x['expected'] for x in findings)
readback = json.loads((s / 'source-live-readback.json').read_text())
for x in readback['files']:
    assert sha(git('show', sr['base'] + ':' + x['file'])) == x['base_sha256']
    assert sha(git('show', readback['live'] + ':' + x['file'])) == x['live_head_sha256']
ancestors = json.loads((s / 'live-ancestors.json').read_text())
extra = json.loads((s / 'additional-live-ancestors.json').read_text())
for x in ancestors:
    rc = subprocess.run(['git', 'merge-base', '--is-ancestor', x['commit'], x['live']], capture_output=True).returncode
    assert rc in [0, 1] and (rc == 0) == x['ancestor']
for commit, expected in extra['commits'].items():
    rc = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, extra['live']], capture_output=True).returncode
    assert rc in [0, 1] and (rc == 0) == expected
inputs = [json.loads(x) for x in (s / 'ledger-links-input.jsonl').read_text().splitlines()]
owned = []
for raw in (root / 'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('op') == 'update' and any(all(row.get(k) == x.get(k) for k in x) for x in inputs): owned.append(raw)
assert len(inputs) == len(owned) == 31
assert all(set(json.loads(x)) <= {'op', 'id', 'ts', 'by', 'where', 'note'} for x in owned)
(stage / 'strategy-owned-ledger.jsonl').write_bytes(b''.join(owned))
save('strategy-readback.json', {'batch': sid, 'report': sr, 'canonical_no_change_gate': sb['no_change_proposals'], 'original_rows': 19929, 'original_material_assertions': 66, 'material_tests_reexecuted': False, 'source_leaves': readback, 'ancestors': ancestors, 'additional_ancestors': extra, 'owned_trace_only_ledger_rows': 31, 'no_new_source_release_or_checks': True})

source = cr['commits']['source']; merge = cr['commits']['merge']; deployed = cr['commits']['publication']
actual = git('rev-parse', 'HEAD', cwd=root / '.worktrees/live').decode().strip()
for a, b in [(source, merge), (merge, deployed), (deployed, actual)]: git('merge-base', '--is-ancestor', a, b)
publication = json.loads((c / 'publication.json').read_text())
assert len(publication['paths']) == 92
leaves = []
scan = stage / 'source-scan'
for path in publication['paths']:
    raw = git('show', source + ':' + path)
    assert raw == git('show', merge + ':' + path) == git('show', actual + ':' + path)
    assert path.startswith('experiments/boss-sim/silent/') or path in ['knowledge/characters/silent/boss-trust.json', 'paper/materials/silent/boss-sim-calibration.md']
    dest = scan / path; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
    leaves.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
assert not git('diff', '--name-only', merge + '^1', merge, '--', 'agent/', 'ops/', 'learner/').strip()
final = json.loads((c / 'final-verification.json').read_text())
assert sha((c / 'live-sandbox.log').read_bytes()) == final['live_tests']['sha256']
assert sha((c / 'source-sandbox.log').read_bytes()) == final['source_tests']['log_sha256']
assert json.loads((c / 'trust-changes.json').read_text()) == {'b2': {'added': ['THE_INSATIABLE'], 'removed': []}, 'b3': {'added': [], 'removed': []}}
for label in ['candidate', 'live']:
    d = json.loads((c / (label + '-consumer-read.json')).read_text())
    assert d['checks'] == 28
    assert next(x for x in d['results'] if x['boss'] == 'THE_INSATIABLE' and x['use'] == 'b2')['trusted'] is True
    assert next(x for x in d['results'] if x['boss'] == 'THE_INSATIABLE' and x['use'] == 'b3')['trusted'] is False
checks = cb['checks']; assert checks['rc'] == 0 and cb['checks_pending'] is False
assert git('rev-parse', checks['merged'] + '^{tree}').decode().strip() == checks['tree'] == cr['fixes'][0]['fixed_release_tree']
lograw = Path(checks['log']).read_bytes(); log = re.sub(r'\x1b\[[0-9;]*m', '', lograw.decode())
assert '484 passed' in log and '4897 passed' in log and '2 skipped' in log and '617.40s' in log
assert 'tsc' in log and not re.search(r'error TS\d', log)
save('calibration-readback.json', {'batch': cid, 'original_report': cr, 'source': source, 'merge': merge, 'original_publication': deployed, 'observed_live': actual, 'source92_blobs_verified': leaves, 'no_production_source_change': True, 'original_validation': final, 'source_and_live_consumers': 28, 'fixed_model_scope_only': True, 'live_different_frozen_inputs': 70, 'natural_consumer': 'pending; fixed fixtures are not natural adoption', 'parent_closed': False})
save('host-completion.json', {'batch': cid, 'canonical': checks, 'log_bytes': len(lograw), 'log_sha256': sha(lograw), 'tsc': 0, 'vitest': 0, 'files_passed': 484, 'cases_passed': 4897, 'cases_skipped': 2, 'duration_s': 617.40, 'original_report_pending_superseded_only_for_exact_tree': checks['tree'], 'no_repeated_checks': True})
(pub / 'host-full-tail.txt').write_text(log[-1800:])

files = []
for bid, directory, names in [(sid, s, ['report.md', 'proposal.md', 'final-verification.json', 'evidence-verification.json', 'findings-verification.json', 'ledger-links-input.jsonl', 'ledger-links-verification.json', 'source-live-readback.json', 'live-ancestors.json', 'additional-live-ancestors.json', 'audit-first-failure.txt', 'execution-notes.md']), (cid, c, ['report.md', 'result.json', 'publication.json', 'final-verification.json', 'tests-summary.json', 'live-consumer-read.json', 'candidate-consumer-read.json', 'trust-changes.json', 'live-committed-model-differences.json', 'notification.json', 'ledger-item.json', 'ledger-source-update.json'])]:
    for name in names:
        f = directory / name
        if f.is_file(): files.append(f)
    files += [root / 'ops/codex-ops/learner' / (bid + ext) for ext in ['.out', '.err']]
manifest = []
with tarfile.open(pub / 'original-artifacts.tar.gz', 'w:gz') as tar:
    for f in files:
        raw = f.read_bytes(); rel = str(f.relative_to(root))
        dest = stage / 'archive-scan' / rel; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        tar.add(f, arcname=rel)
        manifest.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw)})
save('original-artifact-manifest.json', manifest)
(stage / 'prepared.json').write_text(json.dumps({'source': source, 'merge': merge, 'deployed': deployed, 'live': actual, 'leaves': leaves, 'checks': checks, 'canonical_batches': [sid, cid]}, indent=2) + '\n')
print(json.dumps({'strategy_waiting': 10, 'strategy_ledger': 31, 'calibration_source_leaves': len(leaves), 'host_rc': 0, 'no_source_tests_reexecuted': True}))

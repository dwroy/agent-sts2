from pathlib import Path
import json, subprocess, hashlib, os, sys, tarfile, importlib.util

r = Path.cwd(); p = r / 'ops/codex-ops/record-staging/20261015-1730'
pub = r / 'paper/materials/20261015-1730-ops'; sha = lambda b: hashlib.sha256(b).hexdigest()
def git(*a, env=None, data=None):
    return subprocess.check_output(['git', *a], env=env, input=data, stderr=subprocess.PIPE)
def save(name, value):
    (pub / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
release = json.loads((pub / 'release-registration.json').read_text())
pre = json.loads((p / 'prepared.json').read_text())
if len(sys.argv) == 1:
    assert not (p / 'record-manifest.json').exists()
    base = git('rev-parse', 'HEAD').decode().strip()
    assert not git('diff', '--cached', '--name-only').strip()
    values = {}; modes = {}; physically_preserved = []
    for leaf in pre['leaves']:
        path = leaf['path']; raw = (p / 'source-scan' / path).read_bytes()
        assert sha(raw) == leaf['sha256']
        parent = git('rev-parse', pre['source'] + '^').decode().strip()
        old_source = subprocess.run(['git', 'show', parent + ':' + path], capture_output=True)
        old_main = subprocess.run(['git', 'show', base + ':' + path], capture_output=True)
        assert (old_source.returncode != 0 and old_main.returncode != 0) or old_main.stdout in [old_source.stdout, raw], (path, 'unexpected parallel committed delta')
        f = r / path
        if not f.exists() or f.read_bytes() in [old_main.stdout, raw]:
            f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw)
        else: physically_preserved.append({'path': path, 'physical_sha256': sha(f.read_bytes()), 'committed_source_sha256': sha(raw)})
        values[path] = raw
        modes[path] = git('ls-tree', pre['source'], '--', path).decode().split()[0]
    versions_old = git('show', base + ':eval/versions.json')
    assert (r / 'eval/versions.json').read_bytes() == versions_old
    versions = json.loads(versions_old)
    live_versions = json.loads(git('show', release['live'] + ':eval/versions.json'))
    new = [e for e in live_versions['versions'] if e['name'] == release['name']]
    assert len(new) == 1 and new[0]['release_id'] == release['release_id']
    assert not any(e['name'] == release['name'] for e in versions['versions'])
    versions['versions'].append(new[0])
    allocation = [e for e in live_versions['release_numbering']['releases'] if e['commit'] == release['behavior']]
    assert len(allocation) == 1
    assert not any(e['commit'] == release['behavior'] or e['release_id'] == release['release_id'] for e in versions['release_numbering']['releases'])
    versions['release_numbering']['releases'].append(allocation[0])
    values['eval/versions.json'] = (json.dumps(versions, ensure_ascii=False, indent=2) + '\n').encode()
    (r / 'eval/versions.json').write_bytes(values['eval/versions.json'])
    physical = (r / 'paper/materials/learning/ledger.jsonl').read_bytes()
    cal = []
    for raw in physical.splitlines(keepends=True):
        row = json.loads(raw)
        if row.get('id') == 'silent-0484' and row.get('by') in ['learner:fix-batch', 'ops']: cal.append(raw)
    assert len(cal) == 3 and [json.loads(x)['op'] for x in cal] == ['add', 'update', 'update']
    assert json.loads(cal[-1])['version'] == release['name'] and json.loads(cal[-1])['status'] == 'shipped'
    owned = (p / 'strategy-owned-ledger.jsonl').read_bytes() + b''.join(cal)
    assert len(owned.splitlines()) == 34
    (p / 'owned-ledger.jsonl').write_bytes(owned)
    old_ledger = git('show', base + ':paper/materials/learning/ledger.jsonl')
    seen = set(old_ledger.splitlines()); added = b''.join(x for x in owned.splitlines(keepends=True) if x.rstrip(b'\n') not in seen)
    values['paper/materials/learning/ledger.jsonl'] = old_ledger + added
    spec = importlib.util.spec_from_file_location('owned_ledger', r / 'learner/ledger.py'); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    fold = lambda raw: mod.fold([(i, json.loads(x)) for i, x in enumerate(raw.splitlines(), 1) if x])
    before, after = fold(old_ledger), fold(old_ledger + added)
    assert set(after) == set(before) | {'silent-0484'}
    for ident in before:
        for key in ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']:
            assert before[ident].get(key) == after[ident].get(key), (ident, key)
    assert after['silent-0484']['status'] == 'shipped' and after['silent-0484']['version'] == release['name']
    at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    appends = json.loads((p / 'own-appends.json').read_text())
    line = f'\n- {at} 运维codex：1730两事件闭环：原170527-s2十项waiting/no-source门禁与e893干净树、testsnull/mergednull核，15个本角色原局19929行身份/字节及66算术断言为学习者材料读回，不重跑或当生产测试；10叶旧live5761祖先/SHA、8主+2补祖先核，原fc704非祖先保留，不称全部已实现，31原CLI只追溯、宽项继续waiting。原154303定期校准source6dabe→行为5761→原3d066已实合，92数据/归档叶逐SHA，原23新增实际结局仅扩验证415→438、107调参/模型/Platt/切点不变，新增THE_INSATIABLE B2按原四闸准入、B3仍低，F49及旧B2/B3/Queen/未知进阶限制保持；固定生产清单仍70输入不同，不冒当前模型重校准或自然收益。原源433文件4086及live433文件4090、候选/live消费者各28项原件核，不重复自测；原通道精确bc98332宿主tsc0/vitest0、484文件4897过2跳/617.40s，源导入历史副本失败/130中断和全部保全恢复记录保持，不借给旧6a55失败树。首锁忙且持有2097550在目标身份复核已退出后，仅一次顺序接续原锁正式{release["release_id"]}/{release["name"]}，live{release["live"]}/tree{release["tree"]}只改registry；本轮main精确集成92叶/编号，不整分支树覆盖，保并行记录/刷新/源码，原silent-0484两CLI与ops真实shipped共3行、总34所属ledger纳入，父及自然消费者待验。源扫描一处fight compound identity命中，经run/floor/attempt同字段核为非凭据误报，只豁免唯一fingerprint、原exit1及后续0保持，无全局放宽。根双通知含旧新/证据/预期/回退，原watcher实际运输0仅算送达命令成功，未代ACK；无新源码/测试/对局重启/账号模型额度队列prompt变更或重复学习，非复盘不刷新论文，不等未来事件。证据paper/materials/20261015-1730-ops/。\n'
    assert 'paper/materials/decision-log.md' not in appends
    appends['paper/materials/decision-log.md'] = line
    with (r / 'paper/materials/decision-log.md').open('ab') as out: out.write(line.encode())
    (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
    for path, text in appends.items(): values[path] = git('show', base + ':' + path) + text.encode()
    save('main-integration-readback.json', {'base': base, 'exact_source_leaves': 92, 'source_parent_checked': True, 'registry_entry_and_unique_mapping': release, 'physical_conflicts_preserved': physically_preserved, 'own_ledger_rows': 34, 'existing_ledger_protected_fields_unchanged': True, 'calibration_status_only_marks_actual_table_deployment': True, 'no_source_tests_repeated_or_game_action': True})
    save('completion.json', {'at': at, 'strategy_waiting': 10, 'source_leaves_integrated': 92, 'formal_release_id': release['release_id'], 'exact_host_completed': pre['checks'], 'natural_adoption': 'pending', 'parent_closed': False, 'no_dataset_generation_or_future_event_wait': True, 'only_own_records_staged': True})
    helpers = []; hs = p / 'helper-scan'; hs.mkdir(exist_ok=True)
    with tarfile.open(pub / 'ops-helper-sources.tar.gz', 'w:gz') as tar:
        for f in [p / 'preflight.py', p / 'register-live.py', p / 'main-records.py']:
            raw = f.read_bytes(); (hs / f.name).write_bytes(raw); tar.add(f, arcname=f.name); helpers.append({'path': str(f.relative_to(r)), 'bytes': len(raw), 'sha256': sha(raw)})
    save('ops-helper-manifest.json', helpers)
    for f in pub.iterdir():
        if f.is_file(): values[str(f.relative_to(r))] = f.read_bytes()
    rows = []; dest = p / 'final-files'; rs = p / 'record-scan'
    for path, raw in values.items():
        f = dest / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw)
        rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'mode': modes.get(path, '100644')})
        if path not in modes:
            f = rs / path; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(raw)
    env = {**os.environ, 'LEDGER_FILE': str(dest / 'paper/materials/learning/ledger.jsonl'), 'LEDGER_VERSIONS': str(dest / 'eval/versions.json')}
    q = subprocess.run(['nice', '-n', '19', 'python3', 'learner/ledger.py', 'check'], env=env, capture_output=True)
    (pub / 'final-ledger-check.log').write_bytes(q.stdout + q.stderr); assert q.returncode == 0
    (p / 'record-manifest.json').write_text(json.dumps({'base': base, 'live_parent': release['live'], 'paths': rows}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'paths': len(rows), 'ledger_rows': 34, 'ledger_check': q.returncode, 'release': release['release_id']}))
else:
    assert sys.argv[1] == 'seal'
    for label in ['source-gitleaks-classified', 'archive-gitleaks', 'registry-gitleaks', 'record-gitleaks', 'helper-gitleaks']:
        assert json.loads((p / (label + '.json')).read_text()) == []
    m = json.loads((p / 'record-manifest.json').read_text()); base = m['base']
    assert git('rev-parse', 'HEAD').decode().strip() == base and not git('diff', '--cached', '--name-only').strip()
    for f in [pub / 'final-ledger-check.log', pub / 'record-gitleaks.log', pub / 'helper-gitleaks.log']:
        raw = f.read_bytes(); path = str(f.relative_to(r)); dest = p / 'final-files' / path; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(raw)
        m['paths'] = [x for x in m['paths'] if x['path'] != path] + [{'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'mode': '100644'}]
    idx = p / 'records.index'; env = {**os.environ, 'GIT_INDEX_FILE': str(idx)}; git('read-tree', base, env=env)
    for x in m['paths']:
        raw = (p / 'final-files' / x['path']).read_bytes(); assert sha(raw) == x['sha256']
        obj = git('hash-object', '-w', '--stdin', data=raw).decode().strip()
        git('update-index', '--add', '--cacheinfo', x['mode'], obj, x['path'], env=env)
    tree = git('write-tree', env=env).decode().strip()
    changed = git('diff', '--name-only', base, tree).decode().splitlines()
    assert set(changed) == {x['path'] for x in m['paths']}
    assert not any(x.startswith(('agent/', 'ops/')) and x != 'ops/inbox-dev.md' for x in changed)
    msg = f'Integrate verified Silent calibration data and register {release["release_id"]}\n\nPreserve all ten unchanged waiting proposals, 34 owned ledger rows, the exact completed host checks and original calibration limitations. Integrate only 92 verified source leaves and release metadata; retain parallel records and production code.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
    commit = git('commit-tree', tree, '-p', base, '-p', m['live_parent'], data=msg.encode()).decode().strip()
    index = Path(git('rev-parse', '--git-path', 'index').decode().strip()).resolve(); lock = Path(str(index) + '.lock')
    fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600); done = False
    try:
        assert git('rev-parse', 'HEAD').decode().strip() == base and not git('diff', '--cached', '--name-only').strip()
        with os.fdopen(fd, 'wb') as f: f.write(idx.read_bytes()); f.flush(); os.fsync(f.fileno())
        git('update-ref', '-m', 'ops: integrate verified Silent calibration refresh', 'HEAD', commit, base)
        done = True; os.replace(lock, index)
    finally:
        if lock.exists() and not done: lock.unlink()
    for x in m['paths']: assert sha(git('show', commit + ':' + x['path'])) == x['sha256']
    assert not git('diff', '--cached', '--name-only').strip()
    git('merge-base', '--is-ancestor', release['source'], commit)
    git('merge-base', '--is-ancestor', release['live'], commit)
    m.update(commit=commit, tree=tree); (p / 'record-manifest-final.json').write_text(json.dumps(m, ensure_ascii=False, indent=2) + '\n')
    (p / 'commit-readback.json').write_text(json.dumps({'commit': commit, 'parents': [base, m['live_parent']], 'tree': tree, 'paths': changed, 'ordinary_index_empty': True, 'all_owned_blobs_verified': True}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'commit': commit, 'release': release['release_id'], 'paths': len(changed), 'ordinary_index_empty': True, 'all_owned_blobs_verified': True}))

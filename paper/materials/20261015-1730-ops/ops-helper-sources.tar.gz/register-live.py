from pathlib import Path
import json, subprocess, hashlib, os, fcntl, re

r = Path.cwd(); live = r / '.worktrees/live'
p = r / 'ops/codex-ops/record-staging/20261015-1730'
pub = r / 'paper/materials/20261015-1730-ops'
def git(*a, env=None, data=None):
    return subprocess.check_output(['git', '-C', str(live), *a], env=env, input=data, stderr=subprocess.PIPE)
def sha(b): return hashlib.sha256(b).hexdigest()
assert json.loads((p / 'source-gitleaks-classified.json').read_text()) == []
assert json.loads((p / 'archive-gitleaks.json').read_text()) == []
pre = json.loads((p / 'prepared.json').read_text())
with (r / 'ops/live-merge.lock').open('a') as held:
    fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    before = git('rev-parse', 'HEAD').decode().strip()
    git('merge-base', '--is-ancestor', pre['deployed'], before)
    assert not git('diff', '--cached', '--name-only').strip()
    old = git('show', before + ':eval/versions.json')
    assert (live / 'eval/versions.json').read_bytes() == old
    d = json.loads(old)
    entry = [x for x in d['versions'] if x['name'] == 'S1.boss-calibration19']
    assert len(entry) == 1 and entry[0]['commit'] == pre['merge']
    entries = d['release_numbering']['releases']
    aliases = [x for x in entries if x['commit'] == pre['merge']]
    assert not aliases and not entry[0].get('release_id')
    identifiers = [x['release_id'] for x in entries] + [x['release_id'] for x in d['versions'] if x.get('release_id')]
    sequence = max(int(re.fullmatch(r'V\d+-R(\d+)', x).group(1)) for x in identifiers) + 1
    release = f'V5-R{sequence:03d}'
    entry[0]['release_id'] = release
    entry[0]['release_status'] = 'registered-primary-ops'
    entries.append({'release_id': release, 'commit': pre['merge'], 'aliases': [entry[0]['name']]})
    new = (json.dumps(d, ensure_ascii=False, indent=2) + '\n').encode()
    scan = p / 'registry-scan'; scan.mkdir(exist_ok=True)
    (scan / 'versions.json').write_bytes(new)
    log = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', str(scan), '--redact', '--no-banner', '--exit-code', '1', '--report-format', 'json', '--report-path', str(p / 'registry-gitleaks.json')], env={**os.environ, 'GOMAXPROCS': '2'}, capture_output=True)
    (pub / 'registry-gitleaks.log').write_bytes(log.stdout + log.stderr)
    assert log.returncode == 0
    for leaf in pre['leaves']:
        assert sha(git('show', before + ':' + leaf['path'])) == leaf['sha256']
    idx = p / 'live-registry.index'; env = {**os.environ, 'GIT_INDEX_FILE': str(idx)}
    git('read-tree', before, env=env)
    obj = git('hash-object', '-w', '--stdin', data=new).decode().strip()
    git('update-index', '--add', '--cacheinfo', '100644', obj, 'eval/versions.json', env=env)
    tree = git('write-tree', env=env).decode().strip()
    assert git('diff', '--name-only', before, tree).decode().splitlines() == ['eval/versions.json']
    msg = f'Register actual Silent calibration refresh as {release}\n\nMetadata only; preserve S1.boss-calibration19 identity, fixed-model limits and the exact completed bc98332 host full.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
    commit = git('commit-tree', tree, '-p', before, data=msg.encode()).decode().strip()
    index = Path(git('rev-parse', '--git-path', 'index').decode().strip()).resolve()
    lock = Path(str(index) + '.lock'); fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    done = False
    try:
        assert git('rev-parse', 'HEAD').decode().strip() == before
        assert not git('diff', '--cached', '--name-only').strip()
        assert (live / 'eval/versions.json').read_bytes() == old
        with os.fdopen(fd, 'wb') as f: f.write(idx.read_bytes()); f.flush(); os.fsync(f.fileno())
        (live / 'eval/versions.json').write_bytes(new)
        git('update-ref', '-m', 'ops: register actual calibration release', 'HEAD', commit, before)
        done = True; os.replace(lock, index)
    finally:
        if lock.exists() and not done: lock.unlink()
    assert not git('diff', '--cached', '--name-only').strip()
    at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    receipt = {'at': at, 'release_id': release, 'name': entry[0]['name'], 'source': pre['source'], 'behavior': pre['merge'], 'learner_publication': pre['deployed'], 'live_before': before, 'live': commit, 'tree': tree, 'source92_blobs_preserved': True, 'only_changed': ['eval/versions.json'], 'exact_host_pass_tree': pre['checks']['tree'], 'metadata_tree_not_claimed_as_separate_full': True, 'natural_consumer': 'pending', 'parent_open': True}
    (pub / 'release-registration.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    note = f'\n- {at} [规则发布 {release} / S1.boss-calibration19] 已核 source {pre["source"]}→实际行为 {pre["merge"]}→原登记{pre["deployed"]}，本轮ops在原live锁登记{commit}/tree{tree}，92数据/归档叶逐SHA保持、生产源码不变。旧规则：上一固定校准表，THE_INSATIABLE B2低可信；新规则：23新增实际结局仅扩验证415→438、固定107调参/切点/模型/Platt不变，B2该boss按原四闸达标，B3仍低可信，其他低可信/F49与A0–9未知保持。证据silent-0484、原303完局/1321尝试/545实际结局；B2 n43/Brier0.1299/胜率差2.5个百分点/打穿比1.296，F49 n27虽样本够但质量不合格。预期仅更新校准映射与可信闸，不宣实盘收益；真实当前live与冻结模型仍有70输入叶不同，不冒称当前模型完成重校准。原候选/固定消费者各28项绿；实际bc98332宿主tsc0/vitest0、484文件4897过2跳/617.40s，本编号只改registry，不冒新树独立全套或借给旧失败树。回退：下一局恢复行为提交父树的silent/boss-trust.json窄差，保留后继源码/刷新/原样本和台账。原失败/中断/保全恢复与扫描游戏compound-key误报保留；原父/自然消费者仍pending，不重启当前局或改账号/模型/额度队列prompt。回执paper/materials/20261015-1730-ops/。\n'
    appends = {'notes/for-roy.md': note, 'ops/inbox-dev.md': note}
    for path, text in appends.items():
        with (r / path).open('ab') as out: out.write(text.encode())
    (p / 'own-appends.json').write_text(json.dumps(appends, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt, ensure_ascii=False))

#!/usr/bin/env bash
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261018-045738-b4a2af94-a06a-4d73-8871-692fb30fbed2-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
cd /home/dw/Projects/agent-sts2/.worktrees/live
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git status --short > "$TMPDIR/live-status-before.txt"
git diff --cached --quiet || { echo 'Existing live staged changes; stopped without staging'; exit 75; }
git add notes/fight-value-backtest.md knowledge
if ! git diff --cached --quiet; then
    nice -n 19 gitleaks git --staged --no-banner --redact --log-level error > "$TMPDIR/gitleaks-live-refresh.log" 2>&1
    git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
git rev-parse HEAD > "$TMPDIR/live-before-merge.sha"
git diff --name-only 738433d865d943e80b7726588fa2bbeb3a1980da codex-fix-silent-20261018-045726 > "$TMPDIR/branch-owned-paths.txt"
git diff --name-only "$(git merge-base HEAD codex-fix-silent-20261018-045726)" HEAD -- knowledge notes/fight-value-backtest.md > "$TMPDIR/live-knowledge-paths.txt"
comm -12 <(sort "$TMPDIR/branch-owned-paths.txt") <(sort "$TMPDIR/live-knowledge-paths.txt") > "$TMPDIR/knowledge-overlap.txt"
if test -s "$TMPDIR/knowledge-overlap.txt"; then
    echo 'Knowledge overlap; stopped without merging'
    exit 76
fi
preflight=0
git merge-tree --write-tree HEAD codex-fix-silent-20261018-045726 > "$TMPDIR/live-final-merge-preflight.txt" 2> "$TMPDIR/live-final-merge-preflight.stderr" || preflight=$?
if test "$preflight" -ne 0; then
    echo "Merge preflight failed ($preflight); stopped without modifying live source or index"
    sed -n '/^CONFLICT/p' "$TMPDIR/live-final-merge-preflight.txt"
    exit 77
fi
git merge --no-edit codex-fix-silent-20261018-045726
if (cd agent && bash tools/test-sandbox.sh) > "$TMPDIR/sandbox-live.log" 2>&1; then
    git rev-parse HEAD > "$TMPDIR/live-merged.sha"
else
    result=$?
    git reset --merge "$(cat "$TMPDIR/live-before-merge.sha")"
    echo "Live checks failed ($result); reverted merge and retained refreshed knowledge"
    exit "$result"
fi

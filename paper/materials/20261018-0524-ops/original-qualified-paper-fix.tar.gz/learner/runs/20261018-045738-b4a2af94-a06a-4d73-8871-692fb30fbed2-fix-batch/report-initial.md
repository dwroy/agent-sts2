## 修 bug 回报

- 合并基线：main → 738433d865d943e80b7726588fa2bbeb3a1980da
- 修复（每条一行）：infra-paper-dataset-concurrent-gzip-keyscan-20261018：并发导出/扫描及半成品归档 — dee6386621e8122d123a3cd0017c3e4c199f524e — 测试 agent/tests/paper-dataset-publication.test.ts:serializes dataset cuts and scans, publishes closed archives, and names corrupt inputs — 去掉修复时失败：是（最终撤修Vitest退出1、Python 4失败6错误；恢复退出0、8项通过）
- 已被别人修掉的：额度恢复基线与实际进阶通知 — 5b56a452bb9be14d620b368ec46974c1b57901ca
- 已被别人修掉的：核心通知stdout/stderr持久化（不等于旧原生通知已安全恢复） — 5c92f2aaf0b758a1a5e7d591745694004664f83a
- 已被别人修掉的：知识工作线程签名固定输入 — 8fbb441eb61eef226eb7366f9612003480c83988
- 已被别人修掉的：rollout最佳候选固定输入 — bbc5b993a7524bbb8e80a975f204f8d193657b46
- 已被别人修掉的：空产出补链误派 — 84366ad06ee4f978394c1b9489a82c83ea12bd36
- 已被别人修掉的：多角色药水表测试隔离 — 5ef3c4612bd2673c19968c5a2d24bf62af519ee1
- 已被别人修掉的：未派发提案结果登记 — 3a98e213a826e94f9708af4b1a265e1892659f4e
- 已被别人修掉的：事件流同秒碰撞 — b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f
- 已被别人修掉的：纸鹤夹具 — befc39e5ca0105f8ff96d47f817df44f0b2760f1
- 已被别人修掉的：账本状态分叉前缀 — dd478f0b3e5a0f234f082972d21b203dbf8229d7
- 已被别人修掉的：共享main启动冲突 — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2
- 已被别人修掉的：根事件通知路径 — 577f0bc424b7287910735cfdc86c253cc7ee8057
- 已被别人修掉的：global-build宿主loadavg — 5bc8f025fe043cb8738cce57870354fa23fa84a1
- 已被别人修掉的：局间quiet误报 — 21a9c52484f04d510bd397959c958ec9767f1d2d
- 已被别人修掉的：global-health异步测试 — d27df54f0651c4af84c6c12ceceec82a016f1142
- 已被别人修掉的：target-options此前两个标注回放的固定预算（默认路径已另修） — 83a7f796c24eea8f16eb317bc70bfd832251ad27
- 已被别人修掉的：retention数字UUID — d91236326bc1af7a5417ce016c1a182f8084e7a3
- 已被别人修掉的：retention旧根scratch — 0699b05c436d3d51d00ee92f153d16d16e64bea4
- 已被别人修掉的：无COMBAT决策死亡漏记 — 3b48088dec5fc6eafe576a1296bbdadde43432ee
- 已被别人修掉的：broker请求写失败立即退出 — eaa118c1d72f11b2b6b68c98c1d7bab10d138f5b
- 已被别人修掉的：broker回执保留与队列错误隔离 — 6eb38508ceeb81d534159b3516458521ad09bbed
- 已被别人修掉的：JSONL残尾边界恢复 — 3daf122a5168d1a8cb456aed1c926b2d1b6c4488
- 已被别人修掉的：宿主定向续验入口 — 24c2e3a75b5db6bac76d6c924f86b7fcd9438316
- 已被别人修掉的：会话启动租约保存屏障 — 798af209b9a268b7dafab1440150f1b39cd5595d
- 已被别人修掉的：prompt-dump倒序按偏移读取状态日志 — 6ee8e2a2c1edc31492962137b96af8c6e1d12093
- 已被别人修掉的：知识前缀房间回血说明角色中立 — 6d2de57ceae3def4caf073951ed9d2f9d1544cd7
- 已被别人修掉的：fix-batch默认队列与live模板 — 5805dd187b7913a53b9e2645f40db1657eb5213c
- 已被别人修掉的：experience-update使用live合入流程 — 16ebc4aecb12a1d4b2f34ee767bb2816a3a0b466
- 已被别人修掉的：outcome-stats按mtime与大小重新加载 — 2650aed8baa84b8cf26e1e98b975582a6d5ab537
- 已被别人修掉的：021302宿主eval校准固定夹具超时（误遍历线上发布表） — d8748f2e70bfb2a91138ede0e1f6046927c116a4
- 已被别人修掉的：021302宿主potions-jev-call全部局面扫描超时 — c5fd30d8d369ea6c56bba2e4c3daa6e01e3bf420
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout（默认EZ2L路径） — c57105ca66bd75c6d6952772dcf712399eda828b
- 已被别人修掉的：infra-test-rollout-ties-host-timeout-15000 — da08fcead2025c293140f1ba103d8efdbd39a4c3
- 已被别人修掉的：infra-test-build-facts-selection-remove-latency — e2c1d8a2d29f1cbaf8e5620e4bb912d6f05965f0
- 已被别人修掉的：h1-budget-completion-health-contract — c40e43fd25c200a01f4da94a4dac8db1b34664a8
- 已被别人修掉的：h1-strict-pick-deadline-stall — b3b9734d85defbdbd1b73ab85fab9ea2f636affd
- 已被别人修掉的：selection-hidden-daggers-conditional-followup-readback — a473263eb35ce5bea8e06f1ee94f4da1ba880bc3
- 已被别人修掉的：silent-0338：末挡诊断漏列既有奥利哈钢 — c1d84804956bedbd29a7f0e81294114e18415b9d
- 已被别人修掉的：silent-0272：商店移除预判误报不可选 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26
- 已被别人修掉的：silent-0367：构筑事实未传已用尾巴状态 — 5baf663d7e6678efa3690e5a48329c4f8baee109
- 已被别人修掉的：h1-b2-margin-sample-identity（已发布V5-R384） — 660b194c950f017e356a4b3da952e127c7e5c768
- 已被别人修掉的：silent-vigor-skewer-J2VR：赤牛活力与串刺两段伤害（J2VR2DFJG8K4 A10 F22第2/3试T1，silent-0504/0505，V5-R387） — d959e176af7338ea2bca6f4ff9a39673b80e5fdf
- 已被别人修掉的：U5W7NUE925NK/H1/G2预算到期诊断及零样本前缀（已实际合入；原F15/F16完整根因仍未知） — 0b1807b159a1e3d7fc09aad541ea6f97be627a91
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval固定历史发布表夹具 — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7
- 已被别人修掉的：host-fixed-test-timeouts-010547：F45固定工作时钟与采样夹具 — 9e8c93555131c3347f9e809d9722a848a75c2692
- 已被别人修掉的：ops-learner-recheck-report-fixes-shape-20261018：描述型fixes格式兼容子项 — 4c16dab0457a61e22ef06b27e367d146cb99bab3
- 已被别人修掉的：infra-h0-414-host-fixed-test-stability-20261018：Codex stall固定时间/rollout固定回执（main已集成原031302六测试叶） — 738433d865d943e80b7726588fa2bbeb3a1980da
- 没修的：出牌、药水、SL、终局、路线及角色机制条目（0256/0260/0263/0266/0308/0311/0317/0319/0320/0322/0324/0329/0334/0339/0344/0347/0349/0362/0365/0481/0487，另含XTSV1U9JD34T终局与GXNKW8X1XYJP抽牌身份） — 策略类；沿已有独立strategy-proposal链处理，不重复派发或补入开发者游戏知识。
- 没修的：silent-0339续证：BXU0CKWKH2RU尾巴误核销 — 策略类；已有58ab473f6c814061/c232010cd405fe44原提案链，保留当前行为和原证据。
- 没修的：silent-0332 nonpositive-hp实际资源契约根因 — 证据不足；原专用owner链仍未闭环，诊断及样本身份窄修不等于根因修复。
- 没修的：U5W7NUE925NK F15/F16两次原G2缺DPR告警的完整根因 — 证据不足；原未来样本数组及配对DPR分母未保存，仅修有固定复现的严格零前缀边界，不将其冒作两次实盘根因。
- 没修的：sandbox-glob-startup-race目录生命周期与磁盘压力宽项 — 证据不足；已有启动恢复/租约/回收窄修，目录删除归属与上游时序未确定。
- 没修的：arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression及调度公平性调查 — 独立架构、策略或归因任务，范围太大，超出普通纯bug批次。
- 没修的：core-build-notify-222802-rc2旧原生通知恢复 — 证据不足；stderr持久化已修，旧送达状态未证，不重发可能已送达的通知。
- 没修的：Codex缓存实测、DPR/B2性能及历史宿主超时根因 — 证据不足或独立性能调查；固定测试确定性子项已修，不代表自然性能根因已解决。
- 没修的：原20261018-011241报告的recheck接续 — 证据不足：固定原报告的9ae48941源码不是所报dddad5d67发布提交祖先；六叶相同不代替祖先证明。原报告/状态/recheck2保留，未重复075726已验宿主，格式修复不冒称原批full0。
- 没修的：ops-learner-recheck-report-fixes-shape-20261018补证：窄cherry-pick提案验收 — 太大：原Markdown没有机器JSON、原输出缺runs/base；独立原注册/原报告/六叶源码及发布/真实宿主回执协议超出本批格式修复。不造祖先、不改原报告/提案ID/seen_runs/租约或ACK，保留pending。
- 没修的：infra-h0-414-host-fixed-test-stability-20261018 的生产性能及原full1归因 — 证据不足；已合入的固定测试修复不证明CPU或产品性能根因已解决，保留原失败历史。
- 测试：tsc退出码0；Vitest 490文件 / 4447用例 / 退出码0（489文件4436项＋paths 1文件11项），无超时重跑；Python固定夹具8项通过；gitleaks退出码0。证据U6JELGQTBMHN/Silent A10/终局F28/离线导出无战斗回合；原未命名失败文件的身份不外推，保留原失败与调查指纹。CLI按gzip与paper_dataset检索bug-infra均无对应项，未新建/改写账本或登记shipped。
- 合入：未合入；live锁内知识刷新已结束，无待提交的指定知识数据、无知识路径重叠；最终预检18处历史记录/账本/论文冲突（live-final-merge-preflight.txt），按任务要求停止，live保持58eaab9e8062c466efff21cbc1cd18662d75896b。未执行实际merge、合后测试、版本或上线记录；两个原有非目标notes脏文件保留。
- 需要 Roy 定的事：无

```json
{
  "task": "fix-batch",
  "base": "738433d865d943e80b7726588fa2bbeb3a1980da",
  "fixes": [
    {
      "item": "infra-paper-dataset-concurrent-gzip-keyscan-20261018：并发导出/扫描及半成品归档",
      "commit": "dee6386621e8122d123a3cd0017c3e4c199f524e",
      "test": "agent/tests/paper-dataset-publication.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "出牌、药水、SL、终局、路线及角色机制条目（0256/0260/0263/0266/0308/0311/0317/0319/0320/0322/0324/0329/0334/0339/0344/0347/0349/0362/0365/0481/0487，另含XTSV1U9JD34T终局与GXNKW8X1XYJP抽牌身份）",
      "reason": "策略类；沿已有独立strategy-proposal链处理，不重复派发或补入开发者游戏知识。"
    },
    {
      "item": "silent-0339续证：BXU0CKWKH2RU尾巴误核销",
      "reason": "策略类；已有58ab473f6c814061/c232010cd405fe44原提案链，保留当前行为和原证据。"
    },
    {
      "item": "silent-0332 nonpositive-hp实际资源契约根因",
      "reason": "证据不足；原专用owner链仍未闭环，诊断及样本身份窄修不等于根因修复。"
    },
    {
      "item": "U5W7NUE925NK F15/F16两次原G2缺DPR告警的完整根因",
      "reason": "证据不足；原未来样本数组及配对DPR分母未保存，仅修有固定复现的严格零前缀边界，不将其冒作两次实盘根因。"
    },
    {
      "item": "sandbox-glob-startup-race目录生命周期与磁盘压力宽项",
      "reason": "证据不足；已有启动恢复/租约/回收窄修，目录删除归属与上游时序未确定。"
    },
    {
      "item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression及调度公平性调查",
      "reason": "独立架构、策略或归因任务，范围太大，超出普通纯bug批次。"
    },
    {
      "item": "core-build-notify-222802-rc2旧原生通知恢复",
      "reason": "证据不足；stderr持久化已修，旧送达状态未证，不重发可能已送达的通知。"
    },
    {
      "item": "Codex缓存实测、DPR/B2性能及历史宿主超时根因",
      "reason": "证据不足或独立性能调查；固定测试确定性子项已修，不代表自然性能根因已解决。"
    },
    {
      "item": "原20261018-011241报告的recheck接续",
      "reason": "证据不足：固定原报告的9ae48941源码不是所报dddad5d67发布提交祖先；六叶相同不代替祖先证明。原报告/状态/recheck2保留，未重复075726已验宿主，格式修复不冒称原批full0。"
    },
    {
      "item": "ops-learner-recheck-report-fixes-shape-20261018补证：窄cherry-pick提案验收",
      "reason": "太大：原Markdown没有机器JSON、原输出缺runs/base；独立原注册/原报告/六叶源码及发布/真实宿主回执协议超出本批格式修复。不造祖先、不改原报告/提案ID/seen_runs/租约或ACK，保留pending。"
    },
    {
      "item": "infra-h0-414-host-fixed-test-stability-20261018 的生产性能及原full1归因",
      "reason": "证据不足；已合入的固定测试修复不证明CPU或产品性能根因已解决，保留原失败历史。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "files": 490,
    "cases": 4447
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261018-045738-b4a2af94-a06a-4d73-8871-692fb30fbed2-fix-batch/report.md"
}
```

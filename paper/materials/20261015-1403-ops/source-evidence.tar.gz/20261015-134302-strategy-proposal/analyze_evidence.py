import collections
import bisect
import hashlib
import json
from pathlib import Path

S = Path(__file__).parent
E = S / 'evidence'
scopes = {
    'K2JAGKVJAWZJ': {15, 17, 27, 31, 32, 33, 45, 46},
    'NEWRFAYKTQHR': {17, 28, 31},
    '79UCJ0K6R9C1': {3, 12, 14},
    '9R916WW0V65N': set(range(42, 50)),
    'ZVYUL2YP3518': {33},
    '10GPK5XGHCK3': {17},
    'UJ0K3G10609Y': {33},
}


def rows(stream):
    with (E / (stream + '.evidence.jsonl')).open() as source:
        for line in source:
            yield json.loads(line)


def ref(x):
    return {k: x[k] for k in ('line', 'offset', 'bytes', 'sha256', 'run_id')}


def powers(entries):
    return {p['power_id']: p.get('amount') for p in entries or []}


def project(x):
    st = x['row']['state']
    run = st['run']
    combat = st.get('combat') or {}
    player = combat.get('player') or run
    return {
        **ref(x), 'ts': x['row']['ts'], 'observed_ts': x['row'].get('observed_ts') or x['row']['ts'],
        'floor': run.get('floor'),
        'turn': st.get('turn'), 'in_combat': st.get('in_combat'),
        'screen': st.get('screen'), 'hp': player.get('current_hp'),
        'max_hp': player.get('max_hp'), 'block': player.get('block'),
        'energy': player.get('energy'), 'powers': powers(player.get('powers')),
        'attacks': player.get('attacks_played_this_turn'),
        'kunai': [r for r in run.get('relics', []) if r.get('relic_id') == 'KUNAI'],
        'revive_relic': [r for r in run.get('relics', []) if r.get('relic_id') == 'LIZARD_TAIL'],
        'potions': run.get('potions'),
        'hand': [{'index': c.get('index'), 'id': c.get('card_id'), 'upgraded': c.get('upgraded'),
                  'text': c.get('resolved_rules_text'),
                  'values': {v['name']: v.get('current_value') for v in c.get('dynamic_values', [])}}
                 for c in combat.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'),
                     'powers': powers(e.get('powers')), 'intents': e.get('intents')}
                    for e in combat.get('enemies', [])],
    }


counts = collections.defaultdict(collections.Counter)
state_by_fp = {}
selected = []
floors = {}
assertions = 0
with open('/home/dw/Projects/agent-sts2/logs/states.jsonl', 'rb') as original:
    for x in rows('states'):
        st = x['row']['state']
        assert st['run_id'] == x['run_id']
        assert st['run']['character_id'] == 'SILENT'
        assertions += 2
        counts[x['run_id']]['states'] += 1
        p = project(x)
        key = (x['run_id'], p['floor'])
        floors.setdefault(key, {'first': p, 'last': p, 'frames': 0})
        floors[key]['last'] = p
        floors[key]['frames'] += 1
        if p['floor'] in scopes.get(x['run_id'], set()):
            original.seek(x['offset'])
            raw = original.read(x['bytes'])
            assert hashlib.sha256(raw).hexdigest() == x['sha256']
            assert json.loads(raw) == x['row']
            assertions += 2
            selected.append(p)
            state_by_fp.setdefault((x['run_id'], x['row']['fingerprint']), []).append(p)

(S / 'state-projections.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2))
(S / 'floor-endpoints.json').write_text(json.dumps([
    {'run_id': k[0], 'floor': k[1], **v} for k, v in floors.items()
], ensure_ascii=False, indent=2))

key_decisions = []
raw_candidates = []
for x in rows('decisions'):
    d = x['row']
    counts[x['run_id']]['decisions'] += 1
    if d.get('decider') == 'codex':
        counts[x['run_id']]['codex_decisions'] += 1
    if d.get('deepseek'):
        counts[x['run_id']]['legacy_deepseek_payload_nonnull'] += 1
    candidates = state_by_fp.get((x['run_id'], d.get('fingerprint')), [])
    observed = d.get('observed_ts') or d['ts']
    index = bisect.bisect_right([c['observed_ts'] for c in candidates], observed) - 1
    p = candidates[index] if index >= 0 else None
    if p is not None:
        assert p['observed_ts'] <= observed
    if d.get('floor') in scopes.get(x['run_id'], set()):
        chosen = d.get('chosen') or {}
        if chosen.get('action') in ('use_potion', 'end_turn', 'save_and_quit') or d.get('sl_explore'):
            key_decisions.append({**ref(x), 'ts': d['ts'], 'floor': d.get('floor'), 'turn': d.get('turn'),
                                  'chosen': chosen, 'result': d.get('result'),
                                  'sl_attempt': d.get('sl_attempt'), 'sl_explore': d.get('sl_explore'),
                                  'state': p})
        if x['run_id'] == 'NEWRFAYKTQHR' and d.get('floor') == 31 and d.get('turn') == 2 and d.get('questions'):
            raw_candidates.append({**ref(x), 'row': d, 'state': p})
(S / 'key-decisions.json').write_text(json.dumps(key_decisions, ensure_ascii=False, indent=2))
(S / 'newr-t2-original-questions.json').write_text(json.dumps(raw_candidates, ensure_ascii=False, indent=2))

configs = []
for stream in ('brain', 'run-plans', 'sl-attempts', 'fight-plans', 'run-config', 'runs'):
    for x in rows(stream):
        counts[x['run_id']][stream] += 1
        if stream == 'run-config':
            configs.append({**ref(x), 'row': x['row']})
        if stream == 'brain':
            counts[x['run_id']]['brain_engine_' + str(x['row'].get('engine'))] += 1
(S / 'run-config-readback.json').write_text(json.dumps(configs, ensure_ascii=False, indent=2))
(S / 'analysis-counts.json').write_text(json.dumps({'counts': counts, 'material_assertions': assertions,
    'selected_state_frames': len(selected), 'selected_decisions': len(key_decisions),
    'newr_t2_questions': len(raw_candidates), 'production_tests': None}, ensure_ascii=False, indent=2))
print(json.dumps({'counts': counts, 'material_assertions': assertions, 'selected_state_frames': len(selected),
                  'selected_decisions': len(key_decisions), 'newr_t2_questions': len(raw_candidates)}, ensure_ascii=False))

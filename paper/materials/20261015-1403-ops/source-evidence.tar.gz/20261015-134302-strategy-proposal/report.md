# 静默猎手策略提案核查报告

记录时间：2026-10-15 13:58:22 CST。任务与批次：strategy-proposal / 20261015-134302-strategy-proposal。

本批十项全部完成核查：一项已有 live 实现，九项保留 waiting。本批没有新增源码或游戏知识、提交、合入、行为版本或 shipped，也没有把缺证改成策略结论。

基线与最终 HEAD：`aff144c69dc6ed73dfc82484221808d4fec3508e`。只读核查时 live：`efed9b0a105c2f2c0d59089c8e938121f5ea8fc1`。开工与结束均为干净工作树；main 已最新。详见 [逐项提案、证据、反例及验证边界](proposal.md)。

## 派发及输入

根 learn.json 对应行是 task=strategy-proposal、character=silent、reason=proposal、state=running、指定工作树和十个 proposal_ids；无专题或实现请求绑定。普通专题文件属于旧批，本批不承接。没有扩展领取其他队列 id，也没有自行创建新提案。十份原 Markdown 均与保存 SHA 一致，完整原字节已留存。

本批 runs 仍为十个派发锚点；为核原提案，额外只读取它们明列的九个 Silent 证据局。十九局角色全部由 runs.jsonl 核实。下表仅表示身份及日志覆盖，不等于十九局全量机制研究或纯 Codex 战绩。

| 局号 | 进阶 | 状态 | 决策 | 原脑日志 |
|---|---:|---:|---:|---:|
| 10GPK5XGHCK3 | 3 | 1020 | 986 | 50 |
| 9YBKCNBFP0X5 | 4 | 1065 | 1035 | 47 |
| UACFSW4VDDLD | 6 | 1236 | 1202 | 50 |
| 4Y94N8RDPGPM | 7 | 719 | 693 | 42 |
| LLYSRQQ35AVW | 8 | 679 | 651 | 54 |
| UJ0K3G10609Y | 10 | 958 | 913 | 45 |
| TCFAHJ9K19VY | 10 | 489 | 476 | 16 |
| ZVYUL2YP3518 | 10 | 1147 | 1110 | 46 |
| UMVLWER4CD98 | 10 | 1202 | 1165 | 50 |
| HSX4HYATB4E2 | 10 | 1013 | 927 | 49 |
| TDLBRNA0R05B | 10 | 972 | 947 | 49 |
| TXZ6RVMQA09D | 10 | 840 | 762 | 48 |
| 1913SE84AXQF | 10 | 413 | 398 | 31 |
| BTSRF7JL1W1Y | 10 | 653 | 635 | 28 |
| 9Z9H2EXKLF3T | 10 | 1018 | 932 | 51 |
| K2JAGKVJAWZJ | 10 | 814 | 722 | 48 |
| 79UCJ0K6R9C1 | 10 | 243 | 235 | 14 |
| NEWRFAYKTQHR | 10 | 675 | 658 | 30 |
| 9R916WW0V65N | 10 | 1405 | 1165 | 50 |

逐流 source_size 及 SHA 见 evidence/evidence-manifest.json。八流原始提取的33,276行全部按 offset/bytes/SHA、JSON内容、明确局身份及计数核回，见 evidence-verification.json。states/decisions各有2条源流无效JSON、brain有1条；它们未被计入所选局证据，不能由此判断其局属。fight-plans在本次截点按明确身份选到0行，只表示该范围未选到，不声称日志不存在。run-plans识别字段 run，未漏计K2的7条。

详细核查是1,547个状态、309条关键决策、5个NEWR原T2问项及7个苦无原字节帧；有40项额外材料事实/算术断言通过，见 factual-checks.json。其他引用局仅在原提案范围内核身份、统计与输入，不外推未核组合。初稿状态关联、时间字段和旧deepseek载荷计数探针已校正，所有旧稿保留；见 analysis-corrections.md。

## 逐项结果

| 原提案 id | 处置 | 账本 | 具体理由 |
|---|---|---|---|
| silent-proposal-243ad8dd038a4ff6 | waiting | silent-0019、silent-0020、silent-0065、silent-0106 | 缺洗牌后同抽牌条件、单动作整战及替代路线对照；首29抽相同不能独立归因胜线。 |
| silent-proposal-9c3ff04261867dd2 | waiting | silent-0021、silent-0243、silent-0276、silent-0277、silent-0278 | 铁心0挡到0挡、覆甲0到7已核；缺饮药时点整战对照及实际能力、回复和来源的完整消费者验证。 |
| silent-proposal-650ea306e8627f9e | waiting | silent-0010、silent-0012、silent-0013、silent-0019、silent-0020、silent-0021、silent-0046、silent-0065、silent-0077、silent-0106、silent-0115、silent-0178、silent-0243、silent-0276、silent-0277、silent-0278 | 48次独立调用与71次含复用决策已核；关联宽机制和资源消费者未闭合，当时dirty知识输入未冻结。 |
| silent-proposal-aff5ac3bb7cdb81b | waiting | silent-0079、silent-0135、silent-0167、silent-0168、silent-0010 | 同24/24死亡两案的5HP及7伤等差额已核；缺受控整战对照和污染、饱和状态、实际续步的完整消费者验证。 |
| silent-proposal-60e68d681e861d1c | waiting | silent-0286、silent-0278 | 感染先于毒结算已有窄实现；缺普通战毒瓶其他入口、头骨/制品组合及整条消费路径验证。 |
| silent-proposal-9aa48a84227bcdb5 | waiting | silent-0019、silent-0020、silent-0243、silent-0021、silent-0276、silent-0277、silent-0259 | 缺替代路线、饮药时点和整战结果的配对证据，资源消费者尚未完整校准。 |
| silent-proposal-7cfd0f9b6b0fbbda | waiting | silent-0012、silent-0005、silent-0016、silent-0080、silent-0046、silent-0084、silent-0011、silent-0023、silent-0010、silent-0123、silent-0168、silent-0079、silent-0135、silent-0133、silent-0289 | 坚韧之环施放快照与当前敏捷不同已核；缺可靠快照/剩余轮次入口及升级、叠层、重放跨轮对照。 |
| silent-proposal-e6f9cb57c1204036 | waiting | silent-0286、silent-0278 | 已遵循combat/potion领域勘误；同源感染/毒瓶宽提案的未覆盖入口和组合仍缺验证。 |
| silent-proposal-8df611363cd82fc9 | duplicate | silent-0291、silent-0085、silent-0005 | 既有live祖先源码已覆盖原提案限定的Silent A10可靠计数、手动第三攻增敏、后继挡及跨轮传播，自动/重放保持未知。 实际源码提交：`0944cf8cfd06d345548f5271f1e6521b0cd46656`。 |
| silent-proposal-6353ffbadaaac619 | waiting | silent-0228、silent-0290、silent-0291 | F48到F49实际12HP空药已核，苦无子项已有实现；缺F42独立复活充能观测、固定资源与种子的两战配对及独立留出。 |

苦无的 duplicate 只覆盖原提案限定的可靠计数、普通手动第三攻、后继格挡和跨轮敏捷。实际 live 祖先0944cf8cfd06d345548f5271f1e6521b0cd46656及同代码main集成f3dea91880600bc2e7228268a110a644531738f7均已核；不是新提交或本批上线。自动/重放未知、计数缺失及未观察组合继续保留原边界，不以单局证明胜率效果。

## 主要证据与限制

- K2JAGKVJAWZJ F27T2（silent-0277）：药前后0挡、覆甲0→7，采用原较晚勘误；没有新增与旧知识相冲突的发现。F33首29抽相同，两次结果仍是predicted_death与won分账，不能补成首试实际死亡或单动作因果。48实际Codex调用与71含复用决策分开。
- NEWRFAYKTQHR F31T2（silent-0079/0168/0010）：三盘同28HP/2力量/敌151HP4毒/同手牌；第三及末试两案均24/24模拟死亡，实际两线仍损3/8、扣30/23、挡11/4、毒11/4、污染6/3。它支持差额记录，不能单独支持改变探索门槛或宣称保留原线能赢。
- 79UCJ0K6R9C1 F14T11（silent-0286）：2HP/7挡、三感染，玩家到0而敌仍8HP10毒。已有live窄修复2e6fa2e5c68be70efb2ee87bee58f2cb3128bfb2不可重复算本批产出；普通战毒瓶其他入口与组合的宽项未验完。
- ZVYUL2YP3518 F33T6/T7（silent-0289）：6敏施放得到11挡，次回合敏回2仍11挡；power层2→1不是格挡额度。升级/叠层/重放及可靠快照入口仍不足。
- 9R916WW0V65N F49T1/T2（silent-0291）：第三攻前后计数2→3、敏0→1；下一回合保留敏捷；末试第三刀5→6敏但旧挡仍0。F48出口到F49实际12HP空药，末试最终死时敌余568（silent-0228）；已有苦无模型不能据此声称整战转胜。

主要证据局都有明确历史源码提交，dirty列表为当时知识/材料；本批没有重建这些旧字节，故不能把当前代码加当前知识的回放当原运行输入精确复现。UAC原脑为48 Codex加2 DeepSeek，UJ为45 DeepSeek，其余不得仅据旧deepseek载荷字段判来源。所有模型调用/进阶/同局SL分组均保留历史，不算当前会话模型核验或新增独立样本。

## 源码、账本及验证

17个源码/固定测试/本角色数据叶与live核SHA；14叶相同，card-model.ts、sl/explore.ts、sl/judge.ts三叶差异仅历史Roy/Dai注释，逐行差异完整保存在base-live-comment-differences.patch。七个引用实现提交均核实际live祖先，见source-readback.json。其他窄实现和联合Boss模型不代替九个宽提案完成。

仅经根learner/ledger.py update追加35个既有Silent账本条目的where.proposal和note，CLI退出0，35条实际原行已按offset/bytes/SHA核回，见ledger-receipt.json及ledger-cli.stdout.txt。没有新增support/repeat、id或经验条目，不改claim、首证、先验、status、version，不把旧shipped降为proposed，也不代运维登记shipped。原提案队列及Markdown未改；最终proposal_results交调度器消费。

本批没有源码修改，未运行tsc/vitest或撤源码失败/恢复通过实验；tests固定为{"tsc":null,"vitest":null,"cases":null}。40项材料断言和原日志逐行复核不是生产测试。已有测试文件或旧宿主回执不当本批测试成功。无新合入和版本，跳过live合入流程、规则双通知及源码提交；工作树保持干净。不运行play、不联网、不新增依赖、不推送。

未拟合新权重、HP阈值、药水持有价格或终局价值，没有可声称的实际胜率收益。后续须保留同局SL整组，以新完局作时间留出；九个waiting缺口逐项见表，不以报告结束关闭父学习要求。本批无净源码补丁可回退，原证据及失败/探针稿全部保留。

最终机器回报保存为 result.json；提案路径：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-134302/learner/runs/20261015-134309-f345e64e-4f09-4721-8ec5-4d75ba73410b-strategy-proposal/proposal.md`。

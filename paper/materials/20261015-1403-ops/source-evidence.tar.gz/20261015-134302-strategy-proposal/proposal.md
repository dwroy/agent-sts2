# 静默猎手十项已派发提案：原始证据及实现覆盖核查

任务：strategy-proposal；批次：20261015-134302-strategy-proposal。本文件是本批核查，不覆盖十份原提案，不新建重复提案 id。

基线：`aff144c69dc6ed73dfc82484221808d4fec3508e`。开工工作树干净，`git merge --no-edit main` 返回 Already up to date。本批 learn.json 的 task、character、worktree 与十个 proposal_ids 匹配；没有 research_request、implementation_request 或 proposal_repair。普通专题文件绑定另一批，不承接其 work_spec，不读取其他专题。

只处理本批十个 id。原 Markdown 已逐份核 SHA，原字节保存在各 `silent-proposal-*.original.md`。原始派发及原队列历史分别保存在 dispatch.json、queue-history.json；账本读取保存在 ledger-folded.json。

## 证据范围与方法

本批十锚点及原提案明确引用的九个补充局，共十九局，runs.jsonl 均明确为 SILENT。进阶分别为 A3/A4/A6/A7/A8/A10，不混合估计牌值、胜率、房间代价或参数。提取使用本工作树 learner/extract_evidence.py，包含 states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans 八流。冻结截点、逐行 offset/bytes/SHA/身份及计数保存在 evidence/；evidence-verification.json 记录全部 33,276 条选中行与原日志的逐字节复核。

详细检查限定在 state-projections.json 的 1,547 个状态及 key-decisions.json 的 309 条关键决策；不宣称完整复盘十九局。原问项单列 newr-t2-original-questions.json。状态与动作以同局、同 fingerprint 和 observed_ts 关联，不能用正文提及局号或重复 SL 的相同 fingerprint 单独建立所属关系。

40 项材料断言见 factual-checks.json；这是原始数字、来源和算术检查，不是生产测试，不是整战反事实或独立新样本。游戏结论仅来自这些本角色原帧；没有运行 play、LLM、联网或模拟补胜线。

## 逐项处置

### 1. silent-proposal-243ad8dd038a4ff6 — waiting

账本：silent-0019、0020、0065、0106。证据：K2JAGKVJAWZJ A10/F33 两次尝试，sl-attempts:1081/1082；F46 是失败终点。

首29抽及其归属回合两试一致，T5 洗牌后边界不再已知。首试 T10 10HP、饮毒后 predicted_death 并重载；第二试 T11 won、出口28HP且未饮毒。只证明同初抽条件下多处改线后结果不同，不能把胜因单独归到首目标、留药或某个动作。F46 也没有替代目标的受控整战胜线。

缺数据：洗牌后相同抽牌条件、只改变一项动作的完整对照及替代路线实际结果。保留现有 SL、目标、休息和药水规则；不拟统一阈值。后续验证须固定完整输入与种子，将同局全部 SL 放在同一组，并用时间之后的独立完局留出。

### 2. silent-proposal-9c3ff04261867dd2 — waiting

账本：silent-0021、0243、0276、0277、0278。证据：K2JAGKVJAWZJ A10/F15T2、F27T2、F33T10。F27 states:292788→292789，挡0→0、覆甲0→7；F33 states:292940→292941，目标54HP不变、毒42→48。原“16挡”勘误有效，不重新采用旧数值。

代码已有铁心覆甲、敏捷和部分毒药入口；这不证明全部场景和资源来源消费者完成。缺饮药时点、实际能力建立和跨幕/SL来源的完整条件化消费者验证及整战对照。保持现有喝药/留药/终局参数，不以弃瓶或持有能力归因败局。

### 3. silent-proposal-650ea306e8627f9e — waiting

账本：silent-0010、0012、0013、0019、0020、0021、0046、0065、0077、0106、0115、0178、0243、0276、0277、0278。证据：K2JAGKVJAWZJ 814状态、722决策、48脑日志、71个 decider=codex 决策、7条计划；48次实际脑调用均 engine=codex。

71含计划复用，不能当独立调用次数。旧 `deepseek` 兼容载荷非空也不能当 DeepSeek 调用：必须核内层 brain.engine 和 brain.jsonl。10GPK5XGHCK3 A3/F17T5、UJ0K3G10609Y A10/F33T7只保留为本角色原提案的机制来源；UJ 原脑日志为 DeepSeek，不能算纯 Codex 战绩。

来源计数已核，关联的宽机制/资源提案并未全部闭合；旧 dirty 知识输入也未完整保存。此项不需要为计数勘误制造策略源码或发布。等待关联消费者回放及原运行输入充分可追溯后再判覆盖。

### 4. silent-proposal-aff5ac3bb7cdb81b — waiting

账本：silent-0079、0135、0167、0168、0010。证据：NEWRFAYKTQHR A10/F31T2，decisions:287298/287341/287366，分别绑定 states:294063/294106/294131。三盘均28HP、2力量、敌151HP/4毒、同五手牌；第三及末试原问项两案均五轮24/24死亡。

原线 states:294067→294068：11挡、6污染、11毒，实损3、扣敌血30。末试 states:294134→294135：4挡、3污染、4毒，实损8、扣敌血23。因此差额为+5损血、−7伤害、−7挡、−7毒、−3污染；这些是此局局部实际兑现，不代表整场收益。原 Jev 选择和 SL 替线明确分开，原始答项、替换及其文字数字均保留。

现有 live 的 candidate_comparison/resource_comparison 已覆盖候选 HP、伤害、挡及部分毒端点，actual_turn_result 仍为 null；没有本提案全部污染差额、饱和状态和实际续步归属的完整验证。原线完整尝试也未获胜，不能从局部差额修改探索准入或排序。缺受控整战对照与完整消费者验证，保留 waiting，不把局部审计实现算全提案完成。

### 5. silent-proposal-60e68d681e861d1c — waiting

账本：silent-0286、0278。证据：79UCJ0K6R9C1 A10/F14T6、T10、T11；NEWRFAYKTQHR A10/F17/F28/F31及原提案列出的本角色历史局。

79 F14T11 states:293464→293465：2HP/7挡、三感染；敌8HP/10毒，玩家先到0，敌仍8HP/10毒。当前 live `2e6fa2e5c68be70efb2ee87bee58f2cb3128bfb2` 已有 held-card damage before poison 的窄实现，不能报全面漏算。毒瓶即时只加毒的原帧也已核。

缺普通战其他毒瓶入口、头骨/制品组合及整条求解、药水、SL消费路径的条件化验证。不能把已实现的感染子项当整份宽提案 duplicate。领域按第8项勘误使用 combat/potion，不改 terminal 权重或饮药时点门槛。

### 6. silent-proposal-9aa48a84227bcdb5 — waiting

账本：silent-0019、0020、0243、0021、0276、0277、0259。证据：79UCJ0K6R9C1 A10/F14；NEWRFAYKTQHR A10/F17、F28、F31。实盘入口、药槽、普通回复与 SL 恢复须分账。原帧可验证当前路径的消耗，不能生成未走路线、不同饮药时点或未实到火堆的结果。

缺替代路线、饮药时点与整战结果的配对证据，以及完整资源消费者校准。保留现有资源参数，不由短推演全败或未来休息推实际胜负。只有本角色后续独立实盘/固定输入配对足够时再更新。

### 7. silent-proposal-7cfd0f9b6b0fbbda — waiting

账本：silent-0012、0005、0016、0080、0046、0084、0011、0023、0010、0123、0168、0079、0135、0133、0289。证据：NEWRFAYKTQHR A10/F31T2 污染/蜃景；79UCJ0K6R9C1 A10/F14；ZVYUL2YP3518 A10/F33T6—T8；其余只限原提案引用的本角色补充局。

ZVY states:257821 T6 为6敏11挡、TORIC_TOUGHNESS_POWER=2；257823 T7 已回2敏仍11挡、该 power=1。power层数不能直接当格挡额度；施放快照需要与剩余轮次分开。现有普通蜃景和升级零毒模板只是窄子项，实际 live `d2afe7f39a512c89ae3576056ae86e95bcf05e60` 不覆盖全部组合。

缺可靠施放额度/剩余轮次入口及升级、叠层、重放跨轮对照，不能用当前敏捷重算旧快照或据多机制单局泛化。保留现有行为，未核分支明确未知。

### 8. silent-proposal-e6f9cb57c1204036 — waiting

账本：silent-0286、0278。证据与第5项同源；这份原文对60e的领域作勘误，不构成第二份独立机制样本。已遵循 combat/potion，不涉及 terminal。保留两份原提案与各自 SHA，不新建重复 id、不重复实现；原宽提案的毒瓶入口、组合及完整消费者仍缺验证，因此该关联项继续 waiting。

### 9. silent-proposal-8df611363cd82fc9 — duplicate

账本：silent-0291、0085、0005。证据：9R916WW0V65N A10/F49T1/T2。直接核回原字节的七帧保存在 kunai-raw-readback.json：295534→295535，攻击2→3、敏捷0→1，挡仍0；295536步法后3敏/7挡，295537后空翻后15挡；295540新回合3敏/计数0；295548→295549第三刀5→6敏、挡0不变。末试与前五试牌序分别保留。

实际 live 祖先源码提交：`0944cf8cfd06d345548f5271f1e6521b0cd46656`，main 对应集成 `f3dea91880600bc2e7228268a110a644531738f7` 也为实际 live 祖先。silent-kunai.ts、combat-plan.ts、turn-solver.ts、rollout.ts及固定测试叶在当前基线/live相同。

已有实现限定 Silent A10、有效且未熔毁苦无、明确整数计数且两计数模3一致；手动第三攻完成后增敏、只影响随后格挡，跨轮保留敏捷并重置计数；自动/重放保留未知，组合排除和其他角色门控仍在。对应固定测试已覆盖这些边界，本批只读核源码和原帧，没有重新运行测试。原提案限定范围已有实现，因此记 duplicate，不冒称本批 implemented 或 shipped。未观察分支、整战胜率和自然消费者效果均不扩大。

### 10. silent-proposal-6353ffbadaaac619 — waiting

账本：silent-0228、0290、0291。证据：9R916WW0V65N A10/F42—F49。states:295422→295423→295424，实际12HP、四空槽由F48进入F49；F48第三试 T15 won，前两试只是 predicted_death。末试F49T2 states:295550→295551，12HP/0挡归零，敌207+361=568HP。苦无子项现已闭合，不继续称它全未实现。

现有连续Boss实现会按同一样本传递实际HP、剩药和复活状态；这是既有 live 能力，不是本批产出。F42的净血量端点不能独立证明复活或剩余充能。缺明确复活充能观测、固定真实资源与种子的两战配对、0290相关模型的完整校准和独立留出；不据此拟留药价格、终局HP权重或承诺多4血能赢。

## 验证、预期与回退

source-readback.json 保存基线/live 17叶SHA和七个已核 live 祖先。三叶字节差仅为历史 Roy/Dai 注释，完整差异见 base-live-comment-differences.patch；没有冒称17叶全相同。四个主要证据局的 run-config 都有明确源码提交，列出的 dirty 文件均为知识/材料；本批未复原当时这些文件的原字节，当前数据重放不能冒作原运行输入的精确复现。

本批没有拟合权重、规则或胜率，没有修改源码/知识、提交、合入、发布或 shipped。预期产出是准确缩小待办范围：苦无限定提案已有实现，九个宽项的缺证仍显式保留；不宣称改变实际胜率。没有本批源码可撤，撤源码失败/恢复通过不适用；tsc/vitest/cases 均为 null。后续源码变更仍须按原提案固定正反例、撤源码验证、沙箱检查及 live 流程，独立回退净补丁并保留全部原始记录。

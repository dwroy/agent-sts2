# 材料探针与初稿保留

1. 最初的 schema 探针在所选首帧非战斗、combat=null 时抛出 TypeError。已使用空 combat/player 回退处理；不将该探针当证据缺失或生产代码失败。
2. 初稿以 fingerprint 单值表关联状态，会在同局多次 SL 相同盘面时覆盖早期帧。该结果保存在 key-decisions.initial.json、newr-t2-original-questions.initial.json，不用于报告结论。
3. 下一稿按 row.ts 对比动作 observed_ts，因状态日志是在决策完成时落盘，会匹配到上一次 SL 的相同 fingerprint 或找不到状态。该稿另存 *.timestamp-probe.json。最终使用同局 fingerprint 的有序观测列表，以 observed_ts 关联，五个 NEWR T2 原问项均与原状态 observed_ts 精确相等，40项材料检查包含这五项约束。
4. 最初计数键 deepseek_nonnull 仅统计旧兼容载荷是否存在，不能表示实际引擎。初稿保存在 analysis-counts.initial.json。最终改名 legacy_deepseek_payload_nonnull，并另外统计 brain.jsonl 的明确 engine；K2 的48次调用均为 Codex，UJ 为45次 DeepSeek，UAC 为48次 Codex加2次 DeepSeek。没有改写历史引擎记录，也不把这些旧日志当当前模型配置核验。

最终结论只使用没有 initial/timestamp-probe 后缀的产物。源日志逐行验证与 factual-checks.json 均已通过；这些检查不属于生产 tsc/vitest，不构成整战胜线、收益或校准验收。

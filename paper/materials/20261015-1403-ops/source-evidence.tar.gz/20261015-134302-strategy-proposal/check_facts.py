import json
from pathlib import Path

S = Path(__file__).parent
states = {p['line']: p for p in json.load(open(S / 'state-projections.json'))}
counts = json.load(open(S / 'analysis-counts.json'))['counts']
checks = []


def check(name, actual, expected, lines=()):
    checks.append({'name': name, 'actual': actual, 'expected': expected,
                   'source_state_lines': list(lines), 'passed': actual == expected})


def power(line, name):
    return states[line]['powers'].get(name, 0)


check('K2 独立脑调用', counts['K2JAGKVJAWZJ']['brain'], 48)
check('K2 含计划复用的 Codex 决策', counts['K2JAGKVJAWZJ']['codex_decisions'], 71)
check('K2 脑日志明确 Codex', counts['K2JAGKVJAWZJ']['brain_engine_codex'], 48)
check('K2 计划流', counts['K2JAGKVJAWZJ']['run-plans'], 7)
check('K2 铁心不即时加挡', [states[n]['block'] for n in (292788, 292789)], [0, 0], (292788, 292789))
check('K2 铁心覆甲', [power(n, 'PLATING_POWER') for n in (292788, 292789)], [0, 7], (292788, 292789))

attempts = []
for raw in open(S / 'evidence/sl-attempts.evidence.jsonl'):
    x = json.loads(raw)
    if x['run_id'] == 'K2JAGKVJAWZJ' and x['row']['floor'] == 33:
        attempts.append(x['row'])
check('蟹两试首29抽同序', attempts[0]['draws']['order'][:29], attempts[1]['draws']['order'][:29])
check('蟹两试首29抽归属回合相同', attempts[0]['draws']['turns'][:29], attempts[1]['draws']['turns'][:29])
check('蟹两试洗牌边界', [x['draws']['clean'] for x in attempts], [29, 29])
check('蟹两试结果分账', [x['result'] for x in attempts], ['predicted_death', 'won'])
check('蟹末试出口', attempts[1]['end_hp'], 28)

for n in (294063, 294106, 294131):
    p = states[n]
    check('棱柱同盘血量 ' + str(n), [p['hp'], p['enemies'][0]['hp'], p['enemies'][0]['powers'].get('POISON_POWER'), power(n, 'STRENGTH_POWER')], [28, 151, 4, 2], (n,))
    check('棱柱同五张手牌 ' + str(n), [c['id'] for c in p['hand']], ['MIRAGE', 'SLICE', 'STRIKE_SILENT', 'DEADLY_POISON', 'ASCENDERS_BANE'], (n,))
check('棱柱原线与替线挡', [states[n]['block'] for n in (294067, 294134)], [11, 4], (294067, 294134))
check('棱柱污染不同', [power(n, 'TAINTED_POWER') for n in (294067, 294134)], [6, 3], (294067, 294134))
check('棱柱原线与替线毒量', [states[n]['enemies'][0]['powers']['POISON_POWER'] for n in (294067, 294134)], [11, 4], (294067, 294134))
check('棱柱原线与替线实际净损', [28 - states[n]['hp'] for n in (294068, 294135)], [3, 8], (294068, 294135))
check('棱柱原线与替线扣敌血', [151 - states[n]['enemies'][0]['hp'] for n in (294068, 294135)], [30, 23], (294068, 294135))
check('感染先死而敌毒未结', [states[293464]['hp'], states[293465]['hp'], states[293465]['enemies'][0]['hp'], states[293465]['enemies'][0]['powers']['POISON_POWER']], [2, 0, 8, 10], (293464, 293465))
check('感染持有三张', [c['id'] for c in states[293464]['hand']], ['INFECTION'] * 3, (293464,))
check('坚韧之环施放快照', [power(257821, 'DEXTERITY_POWER'), states[257821]['block'], power(257823, 'DEXTERITY_POWER'), states[257823]['block']], [6, 11, 2, 11], (257821, 257823))

for n in (295422, 295423, 295424):
    check('连续两战实际12HP ' + str(n), states[n]['hp'], 12, (n,))
    check('连续两战实际空药槽 ' + str(n), any(p.get('occupied') for p in states[n]['potions']), False, (n,))
check('苦无第三攻击计数', [states[n]['attacks'] for n in (295534, 295535)], [2, 3], (295534, 295535))
check('苦无第三攻击增敏', [power(n, 'DEXTERITY_POWER') for n in (295534, 295535)], [0, 1], (295534, 295535))
check('苦无不倒补已有挡', [states[n]['block'] for n in (295548, 295549)], [0, 0], (295548, 295549))
check('末试仍死亡且敌余568', [states[295551]['hp'], sum(e['hp'] for e in states[295551]['enemies'])], [0, 568], (295551,))
for x in json.load(open(S / 'newr-t2-original-questions.json')):
    p = x['state']
    check('原问项与同一观测时刻关联 ' + str(x['line']), p['observed_ts'], x['row']['observed_ts'], (p['line'],))

(S / 'factual-checks.json').write_text(json.dumps({'scope': '材料算术及来源核查，不是生产测试、整战反事实或新独立样本', 'checks': checks}, ensure_ascii=False, indent=2))
assert all(c['passed'] for c in checks), [c['name'] for c in checks if not c['passed']]
print(json.dumps({'material_checks': len(checks), 'passed': len(checks), 'production_tests': None}, ensure_ascii=False))

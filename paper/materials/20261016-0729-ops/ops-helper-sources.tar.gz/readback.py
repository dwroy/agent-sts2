from pathlib import Path
import json, hashlib, subprocess, re, tarfile, os
r=root=Path.cwd(); p=r/'ops/codex-ops/record-staging/20261016-0729'; pub=r/'paper/materials/20261016-0729-ops'; sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda f:json.loads(f.read_text())
def write(f,v): f.parent.mkdir(parents=True,exist_ok=True); f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
state=load(r/'ops/codex-ops/learn.json')['batches']; at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
exec((r/'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text())
route='20261016-064301-s2-strategy-proposal'; empty='20261016-071301-fix-batch'; prior='20261016-064301-fix-batch'
b=state[empty];report=b['report'];wt=Path(b['worktree']);scratch=Path(report['report']).parent
assert b['state']=='failed' and b['rc']==0 and b['merged'] is None and report['fixes']==[]
assert report['tests']==dict(tsc=0,vitest=0,cases=5,files=5,scope='targeted',full_sandbox=130)
assert git('rev-parse','HEAD',cwd=wt).decode().strip()==report['base']=='aefce170750769d997bfb088785f0aad88b1eb54'
assert not git('status','--porcelain','--untracked-files=no',cwd=wt).strip()
assert (scratch/'without-fix.exit').read_text().strip()=='1' and (scratch/'with-fix.exit').read_text().strip()=='0'
assert load(scratch/'full-sandbox-interrupted.json')['exit']==130
native=runtime(empty,report,(r/('ops/codex-ops/learner/'+empty+'.out')).read_text(),worktree=wt)
write(pub/'empty-fix-readback.json',dict(at=at,batch=empty,canonical_state=b['state'],rc=b['rc'],merged=b['merged'],original_report=report,native=native,worktree_head=report['base'],tracked_changes=False,tests_scope='five targeted tests only; duplicate sandbox deliberately interrupted130, never a full pass',new_source_or_merge=False,new_host_request=False,new_release=False))
# Preserve bounded original artifacts, including initial failures and interrupted checks. Large gameplay evidence is referenced by its own manifest, not duplicated.
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for bid in [route,empty]:
  folder=Path(state[bid]['report']['report']).parent
  wanted={'.json','.jsonl','.md','.log','.txt','.err','.exit','.patch','.diff','.py'}
  for f in sorted(folder.iterdir()):
   if f.is_file() and f.stat().st_size<250_000 and f.suffix in wanted and f.name not in ['source-audit.json','audit.json']:
    tar.add(f,arcname=bid+'/'+f.name,recursive=False);manifest.append(ref(f))
  for f in [r/('ops/codex-ops/learner/'+bid+'.out'),r/('ops/codex-ops/learner/'+bid+'.err')]:
   tar.add(f,arcname=bid+'/'+f.name,recursive=False);manifest.append(ref(f))
write(pub/'original-artifact-manifest.json',manifest)
# Existing exact-tree host result; do not use it as proof for the unpublished route source.
h=state[prior]; checks=h['fallback_checks']; assert len(checks)==1; c=checks[0]
assert c['rc']==0 and c['merged']=='2806f8bd8376e9e6e83c296226d9209b386d7292' and c['tree']=='251b0c366ffc51f54aaa8e3f1e0b8658d0b9d8ac'
assert c['commits']==['577f0bc424b7287910735cfdc86c253cc7ee8057']
hlog=Path(c['log']);raw=hlog.read_bytes();txt=re.sub(r'\x1b\[[0-9;]*m','',raw.decode());assert re.search(r'Test Files\s+489 passed',txt) and re.search(r'Tests\s+4916 passed\s*\|\s*2 skipped',txt)
assert git('rev-parse',c['merged']+'^{tree}').decode().strip()==c['tree']
git('merge-base','--is-ancestor',c['commits'][0],c['merged']);git('merge-base','--is-ancestor',c['merged'],'HEAD',cwd=r/'.worktrees/live')
with tarfile.open(pub/'prior-host-original.tar.gz','w:gz') as tar:tar.add(hlog,arcname=hlog.name,recursive=False)
host=dict(at=at,batch=prior,source=c['commits'][0],live=c['merged'],tree=c['tree'],tsc_exit=0,full_vitest_exit=0,files=489,passed=4916,skipped=2,original_log=ref(hlog),broker_result=ref(r/'paper/materials/20261016-0710-ops/host-recheck-request.log'),canonical_failed_rc0_mergednull_preserved=True,repeated_checks=0,scope='Prior notification-source exact251b tree only; no evidence for unpublished route source.')
write(pub/'prior-host-result.json',host)
# Read existing independent actor receipts and their actual CLI evidence; no stage invocation by ops.
nfile=r/'ops/codex-ops/learning-notices/676bee9f38912ae4c39c596a.json';notice=load(nfile); w=r/'paper/materials/20261016-watcher-notice-676bee9f38912ae4c39c596a'; wr=load(w/'formal-role-ack-readback.json'); chain=[];rolefiles=[nfile,w/'formal-role-ack-readback.json']
for stage in ['ops_forwarded','watcher_received','roy_notified']:
 v=notice[stage];f=Path(v['path']);assert sha(f.read_bytes())==v['sha256']; receipt=load(f);ev=r/receipt['evidence']['path'];assert sha(ev.read_bytes())==receipt['evidence']['sha256']
 assert receipt['stage']==stage and receipt['notice_id']==notice['id'] and receipt['status']=='delivered'
 assert receipt['actor']==('ops' if stage=='ops_forwarded' else 'watcher')
 if stage!='ops_forwarded':
  cli=w/('formal-'+stage+'.cli.json');record=load(cli);assert record['rc']==0 and record['original_receipt_reused_without_edit']==v['sha256'];assert stage in record['argv'];rolefiles.append(cli)
 chain.append(dict(stage=stage,actor=receipt['actor'],registry=v,receipt=ref(f),evidence=ref(ev)));rolefiles.extend([f,ev])
assert wr['watcher_received_cli_exit']==wr['roy_notified_cli_exit']==0 and not wr['Roy_ACK_created']
with tarfile.open(pub/'formal-role-originals.tar.gz','w:gz') as tar:
 for f in dict.fromkeys(rolefiles):tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
write(pub/'formal-role-readback.json',dict(at=at,notice_id=notice['id'],registry_snapshot=ref(nfile),chain=chain,watcher_actual_cli=ref(w/'formal-role-ack-readback.json'),all_three_formal_stages_complete=True,ops_other_actor_calls=0,new_transmissions=0,Roy_ack_created=False,historical_pending_receipts_retained=True,wide_learning_or_calibration_parents_closed=False))
# Ledger entries are original CLI provenance updates only. Verify their source offsets, bytes and hashes; do not invoke CLI or change status.
s=Path(state[route]['report']['report']).parent; rows=load(s/'ledger-final-audit.json')['rows']; inputs=[json.loads(line) for n in ['ledger-links-input.jsonl','ledger-source-input.jsonl'] for line in (s/n).read_text().splitlines()]; assert len(rows)==len(inputs)==23
ledger=r/'paper/materials/learning/ledger.jsonl'; originals=[]
with ledger.open('rb') as handle:
 for row,i in zip(rows,inputs):
  handle.seek(row['offset']);raw=handle.read(row['bytes']);assert sha(raw)==row['sha256'];v=json.loads(raw);assert v['op']=='update' and set(v)<=set(['op','id','ts','by','where','note']);assert all(v[k]==value for k,value in i.items());originals.append(raw)
(p/'ledger-original-rows.jsonl').write_bytes(b''.join(originals));write(pub/'ledger-provenance-readback.json',dict(original_rows=rows,original_rows_sha256=sha(b''.join(originals)),row_count=23,allowed_fields=['where','note'],claim_status_evidence_first_run_prior_version_untouched=True,new_CLI_calls=0,new_support_or_repeat=0,whole_proposals='all ten original waiting dispositions retained'))
# Initial publication guard stopped before any code/index/HEAD mutation. Record the concurrent builder, and queue only the original fallback.
proc=Path('/proc/962689'); builder=None
if proc.exists():
 argv=(proc/'cmdline').read_bytes().split(b'\0');target=[x.decode() for x in argv if x.startswith(b'/home/dw/Projects/agent-sts2/') and b'knowledge/builders/build-' in x and b'\n' not in x];stat=(proc/'stat').read_text();birth=stat[stat.rfind(')')+2:].split()[19];builder=dict(pid=962689,starttime_ticks=birth,program=(proc/'comm').read_text().strip(),builder_args=target)
 assert target==['/home/dw/Projects/agent-sts2/.worktrees/live/knowledge/builders/build-fight-value.py']
assert git('rev-parse','HEAD').decode().strip()=='228377d24acf518426f31820b6f9a9bcf642f01e';assert git('rev-parse','HEAD',cwd=r/'.worktrees/live').decode().strip()==c['merged']
assert not git('diff','--cached','--name-only').strip() and not git('diff','--cached','--name-only',cwd=r/'.worktrees/live').strip()
assert not (pub/'publication.json').exists(); assert 'assert active.returncode == 1' in (p/'publish.log').read_text();assert '已发送合入兜底事件' in (pub/'route-fallback-event.log').read_text()
pending=dict(at=at,batch=route,branch='codex-strategy-silent-20261016-064301-s2',source='7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a',base=state[route]['report']['base'],original_failed_rc0_mergednull=True,original_conflicts=19,paths=load(pub/'source-readback.json')['source_paths'],source_checks='tsc0,439 files4115 tests0; no repeat',state='pending original fallback; initial guarded publication did not mutate code',blocker='active live knowledge builder detected before mutation',builder=builder,main_unchanged=git('rev-parse','HEAD').decode().strip(),live_unchanged=c['merged'],live_tree=c['tree'],original_fallback_event_queued=True,event_receipt=ref(pub/'route-fallback-event.log'),event_is_not_merge_or_ACK=True,host_requested=False,release_increment=False,existing_release='V5-R366',wide_proposals='ten waiting; no parent closed',receipt='paper/materials/20261016-0729-ops/route-pending-readback.json',resume='On the original manual fallback event, acquire the original nonblocking live lock; verify builder exit and actual live/main, preserve knowledge/dirty records, integrate only these immutable three source leaves, then request one original064301-s2 exact-tree host full. Do not re-run source full or dispatch a learner.')
write(pub/'route-pending-readback.json',pending);write(r/'ops/codex-ops/pending-integrations/20261016-064301-route-provenance.json',pending)
old=r/'ops/codex-ops/pending-integrations/20261016-064301-notice-root-event.json';v=load(old);v.update(at=at,host='complete exact251b tsc0/full vitest0;489files4916pass2skip',watcher_stage_CLI='complete: independently invoked by original watcher; ops read exact receipts/CLI0',host_result_receipt='paper/materials/20261016-0729-ops/prior-host-result.json',role_result_receipt='paper/materials/20261016-0729-ops/formal-role-readback.json',status='complete for the narrow notice-path source, exact host and original676 registration only; wider parents remain open');write(old,v)
old=r/'ops/codex-ops/pending-deliveries/676bee9f38912ae4c39c596a.json';v=load(old);v.update(role_CLI_registration='all three formal stages complete; watcher executed its own two original CLI calls0, ops did not invoke them',registration_status='complete',ops_final_readback='paper/materials/20261016-0729-ops/formal-role-readback.json',new_notice_or_Roy_ACK=False);write(old,v)
write(pub/'operational-pending-file-readback.json',[ref(r/x) for x in ['ops/codex-ops/pending-integrations/20261016-064301-notice-root-event.json','ops/codex-ops/pending-deliveries/676bee9f38912ae4c39c596a.json','ops/codex-ops/pending-integrations/20261016-064301-route-provenance.json']])
print(json.dumps(dict(source_merge='pending active builder; original fallback queued',empty_fix='no source, targeted5 only/full130 retained',prior_host='exact251b full0',notice676='three independent formal stages verified',ledger_original_trace_rows=23),ensure_ascii=False))

from pathlib import Path
import hashlib,json,subprocess,tarfile,copy,sys
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-0729';pub=r/'paper/materials/20261016-0729-ops';sha=lambda x:hashlib.sha256(x).hexdigest()
def write(f,x):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
assert not (p/'own-appends.json').exists();base=git('rev-parse','HEAD').decode().strip();assert base=='228377d24acf518426f31820b6f9a9bcf642f01e' and not git('diff','--cached','--name-only').strip()
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
route=json.loads((pub/'route-pending-readback.json').read_text());host=json.loads((pub/'prior-host-result.json').read_text());assert route['host_requested'] is False and host['full_vitest_exit']==0
note=f'\n- {at} [ops 0729三事件] 原064301-fix通知路径source577f0bc4/live2806f8bd/tree251b0c36的唯一宿主完整tsc+vitest已exit0：489文件4916通过/2跳过，750.75s；已核原日志/canonical fallback回执、闭环其pending，不重测。原676bee9f通知三阶段均已真实登记：ops原发送、watcher本人两CLI0及两份06:31原生接收/告知字节逐SHA核；回执内旧pending只是历史切点，不改原件、不代角色ACK、不重发Roy通知，仅通知路径与登记窄闭环，宽校准/生产70输入边界保持。原071301-fix无新增源码/版本/合入，撤回重复通知修复后HEAD aefce170、WT干净；只有tsc0与5文件5定向0，重复full中断130保留，canonical failed/rc0/mergednull不改。原064301-s2 source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a仅3叶路线投影来源日志与固定测试、Silent A10适用，旧题面/排序/模型输入与其他角色进阶等价；原源439文件4115项全0/撤码1恢复0/材料26项12702行实核，原cases0占位和19记录冲突保留。运维首次原锁预检实见live build-fight-value.py PID962689/start{route["builder"]["starttime_ticks"] if route["builder"] else "unknown"}仍在运行，断言在任何HEAD/index/代码写入前停下；main/live仍228377d2/2806f8bd，未上线，不借251旧绿。已仅发送原branch learner-merge兜底事件exit0，原source/三叶/pending材料留盘，排队不当合入/已测；后继原通道核builder退出及实际live后窄合并一次精确树host，不重跑源full或新派学习。原23条CLI where/note溯源行逐offset/bytes/SHA核纳入，不改claim/首证/证据/status/version或添support/repeat，十宽提案仍waiting。V5-R366/知识/当前对局/账号home模型prompt预算不动。资料paper/materials/20261016-0729-ops/。\n'
decision=f'\n- {at} 运维codex：0729三事件分别闭环：原064301-fix live2806f8bd/tree251b0c36完整宿主tsc0/vitest0、489文件4916通过2跳过，保canonical failed/rc0/mergednull与原冲突/失败，不重复检查；676三正式阶段本人实证CLI/原生SHA已核完，仅登记/通知路径闭环、不代角色或用户ACK、不重发。071301-fix无source，5文件5定向0与重复full130分列，撤回重复修复后aefce170干净，30旧未修/宽项保持。064301-s2窄诊断source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a自测439文件4115项0/撤码1恢复0及26材料检查12702行实核，原生Sol6.1/xhigh/原沙箱/input/lease核；10提案waiting、19记录冲突和原cases0占位保持，23原CLI行只where/note追溯，不改旧知识/证据/状态/版本。运维锁内知识构建预检遇仍运行live build-fight-value.py PID962689，在所有源码/HEAD/index变更前守卫停下；未强合/停刷新/重试等待，原branch learner-merge单次兜底事件已发送并留pending，后继仅同一不可变3叶与精确新树host，不能借旧251绿。未新增行为号或修改V5-R366/当前局/home/账号模型prompt预算，无新研究/实现派发/宽父关闭。只提交所属记录与原23溯源行，所有并行脏记录/原失败保留。私有读回首轮ANSI解析断言失败与修正后实读0分列，非产品失败；材料paper/materials/20261016-0729-ops/。\n'
queue=f'\n- {at} [原infra-feature-root-event-notice-path后验结案 / silent-route-projection-provenance兜底待续] 通知修复source577f0bc4/live2806f8bd/tree251b完整host0，489文件4916通过2跳过；676原三角色阶段实际CLI与原生证据齐，仅此通知缺陷/登记窄闭环，0332资源契约与宽校准等仍open。原071301-fix无新增source，重复full中断130保留。原064301-s2 route诊断source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a/parent84524bce只agent/src/hand/screens/route-plan.ts及两个固定测试叶，439文件4115源全0，未改实际决策；19并行记录冲突及原10提案waiting/23原where-note行保持。原锁预检实遇live build-fight-value.py运行、未写任何代码/index/HEAD；原branch learner-merge事件已发送，按pending-integrations/20261016-064301-route-provenance.json同链接续，勿新派模型/重复实现或把排队称上线。资料paper/materials/20261016-0729-ops/。\n'
handoff=f'\n- {at} 0729接力：原通知source577f/live2806/tree251b完整宿主0（489文件4916过2跳）及676 watcher本人两正式CLI0与原native证据实核，两个旧pending已改窄complete，历史pending回执不改；宽父/校准边界不关闭，无需重发Roy。071301-fix原failed/rc0/mergednull无新源码，targeted5绿/full130分账。原064301-s2 source7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a只3路线投影来源诊断叶，源439/4115绿，无新行为号；预检live知识build-fight-value.py PID962689活跃，未变main228377d2/live2806f8bd或index。已实际发送learner-merge codex-strategy-silent-20261016-064301-s2，等待原manual事件接同不可变源，先核构建器结束/原锁/实际HEAD与知识，再只3叶窄差保全部并行记录（源parent84524bce），原10waiting不改，合后仅一次原064301-s2宿主精确树full；不要重跑源full/借251绿/新派学习。pending及原source/native/失败/23原CLI where-note字节详paper/materials/20261016-0729-ops/。\n'
appends={'ops/inbox-dev.md':note,'paper/materials/decision-log.md':decision,'notes/fix-queue-v4.md':queue,'notes/ops-handoff.md':handoff};write(p/'own-appends.json',appends)
values={}
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
 values[path]=git('show',base+':'+path)+text.encode()
# Commit only the original source batch's 23 provenance rows; keep all other physical append-only ledger rows outside our index.
path='paper/materials/learning/ledger.jsonl';old=git('show',base+':'+path);rows=(p/'ledger-original-rows.jsonl').read_bytes().splitlines(keepends=True);assert len(rows)==23 and all(old.count(x)==0 for x in rows);new=old+b''.join(rows);values[path]=new
sys.path.insert(0,str(r));from learner.ledger import fold
parse=lambda raw:[(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x.strip()]
a=fold(parse(old));b=fold(parse(new));assert set(a)==set(b)
protected=lambda item:{k:v for k,v in item.items() if k not in ['where','notes','history']}
assert all(protected(a[k])==protected(b[k]) for k in a)
write(pub/'ledger-final-check.json',dict(committed_original_provenance_rows=23,all_ids_preserved=True,all_protected_fields_equal=True,rows_already_in_shared_physical_ledger=True,new_CLI_calls=0,physical_ledger_file_not_modified=True))
write(pub/'record-registration.json',dict(at=at,base=base,prior_notice_host='exact251b full0',notice676_three_formal_stages='actual independent actor CLI and native evidence read',route_source=route['source'],route_merge='not started: active builder guard',fallback='original branch event queued, not a merge or ACK',host_route_request=False,new_release=False,existing_release='V5-R366',source_full_reruns=0,game_actions=0,other_actor_ACK_calls=0,wide_parents='remain open'))
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 helpers=[]
 for f in sorted(p.glob('*.py')):tar.add(f,arcname=f.name,recursive=False);helpers.append(dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
write(pub/'ops-helper-manifest.json',helpers)
with tarfile.open(pub/'ops-attempt-logs.tar.gz','w:gz') as tar:
 for name in ['publish.log','readback-first-ansi-assertion.log','readback.log']:
  f=p/name;tar.add(f,arcname=name,recursive=False)
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
# Previous wake's owned request log now contains its genuine completion receipt; stage that actual output only.
prior='paper/materials/20261016-0710-ops/host-recheck-request.log';values[prior]=(r/prior).read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(paths=len(entries),route_merge='pending',previous_host='complete0',notice='complete',source_trace_rows=23)))

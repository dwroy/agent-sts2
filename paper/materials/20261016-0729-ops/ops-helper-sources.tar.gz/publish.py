from pathlib import Path
import fcntl, hashlib, json, os, re, subprocess, tarfile

r = root = Path.cwd()
live = r / '.worktrees/live'
p = r / 'ops/codex-ops/record-staging/20261016-0729'
pub = r / 'paper/materials/20261016-0729-ops'
pub.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = '7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a'
base = '84524bce1d7b57f42403b80e42082c62fc8cd158'
template = (r / 'ops/codex-ops/record-staging/20261016-0240/publish.py').read_text()
exec(template[template.index('def git('):template.index('assert not (pub/')].replace('.ops-poison.tmp', '.ops-feature-root.tmp'))
def write(file, value): file.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
bid = '20261016-064301-s2-strategy-proposal'
batch = json.loads((r / 'ops/codex-ops/learn.json').read_text())['batches'][bid]
report = batch['report']; scratch = Path(report['report']).parent; wt = Path(batch['worktree'])
result = json.loads((scratch / 'result.json').read_text()); checks = result['validation']
assert checks['sandbox_cases'] == 4115 and checks['sandbox_files'] == 439
assert json.loads((scratch / 'sandbox-source-result.json').read_text())['exit_code'] == 0
assert checks['without_source_exit'] == 1 and checks['restored_exit'] == checks['gitleaks_exit'] == 0
assert all(x['pass'] for x in json.loads((scratch / 'evidence-check.json').read_text())['checks'])
assert report['tests'] == dict(tsc=0, vitest=0, cases=0)
assert git('rev-parse', 'HEAD', cwd=wt).decode().strip() == source and not git('status', '--porcelain', '--untracked-files=no', cwd=wt).strip()
assert batch['rc'] == 0 and batch['merged'] is None and batch['state'] == 'failed'
assert len(report['proposal_results']) == 10 and all(x['state'] == 'waiting' for x in report['proposal_results'])
exec((r / 'ops/codex-ops/record-staging/20261016-0611/readonly-runtime.py').read_text())
out = r / ('ops/codex-ops/learner/' + bid + '.out')
native = runtime(bid, report, out.read_text(), worktree=wt)
paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', source).decode().splitlines()
assert set(paths) == {'agent/src/hand/screens/route-plan.ts', 'agent/tests/silent-route-projection-evidence.json', 'agent/tests/silent-route-projection.test.ts'}
conflicts = json.loads((scratch / 'merge-blocker.json').read_text())
assert not conflicts['live_mutated'] and len(conflicts['conflicts']) == 19
write(pub / 'source-readback.json', dict(batch=bid, source=source, source_parent=base, source_checks=checks, native=native, original_failed_state_preserved=True, original_merge_result=conflicts, original_report=report, source_paths=paths, original_cases_zero_placeholder_preserved=True, classification='Silent A10 route projection provenance logging only. Existing route inputs, model text and decisions unchanged; ten wider proposals remain waiting. No game behavior or release increment.'))
assert not (pub / 'publication.json').exists()
with (r / 'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    print(at, flush=True)
    mh = git('rev-parse', 'HEAD').decode().strip()
    lh = git('rev-parse', 'HEAD', cwd=live).decode().strip()
    assert lh == '2806f8bd8376e9e6e83c296226d9209b386d7292'
    active = subprocess.run(['pgrep', '-f', '/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'], capture_output=True)
    assert active.returncode == 1
    for cwd in [r, live]: assert not git('diff', '--cached', '--name-only', cwd=cwd).strip() and not git('ls-files', '-u', cwd=cwd).strip()
    before = {}
    for cwd in [r, live]:
        before[str(cwd)] = {x: sha((cwd / x).read_bytes()) for x in git('diff', '--name-only', 'HEAD', cwd=cwd).decode().splitlines() if x not in paths}
    values = {}
    livevalues = {}
    preserved_difference = None
    for path in paths:
        old = blob(base, path)
        raw = blob(source, path)
        oldlive = blob(lh, path, live)
        assert blob(mh, path) == old, path
        for cwd, prior in [(r, old), (live, oldlive)]: assert ((cwd / path).read_bytes() if (cwd / path).exists() else None) == prior, path
        values[path] = raw
        if oldlive == old:
            livevalues[path] = raw
        else:
            raise AssertionError(('unexpected live divergence', path))
        for lane, content in [('main', raw), ('live', livevalues[path])]:
            scan = p / 'source-scan' / lane / path
            scan.parent.mkdir(parents=True, exist_ok=True)
            scan.write_bytes(content)
    with (pub / 'source-composition-gitleaks.log').open('wb') as outscan:
        scan = subprocess.run(['nice', '-n', '19', 'gitleaks', 'dir', str(p / 'source-scan'), '--redact', '--no-banner', '--report-format', 'json', '--report-path', str(p / 'source-gitleaks.json')], stdout=outscan, stderr=subprocess.STDOUT, env={**os.environ, 'GOMAXPROCS': '1'})
    assert scan.returncode == 0 and json.loads((p / 'source-gitleaks.json').read_text()) == []
    staged = []
    for cwd, head, label in [(r, mh, 'main'), (live, lh, 'live')]:
        env = {**os.environ, 'GIT_INDEX_FILE': str(p / (label + '.index'))}
        git('read-tree', head, env=env, cwd=cwd)
        for path, raw in (values if cwd == r else livevalues).items(): stage(path, raw, env, cwd)
        tree = git('write-tree', env=env, cwd=cwd).decode().strip()
        assert set(git('diff', '--name-only', head, tree, cwd=cwd).decode().splitlines()) == set(paths)
        new = commit(tree, [head, source], 'Integrate Silent A10 route projection provenance diagnostics', cwd)
        staged.append((cwd, head, env, new, tree))
    locks = locks_for([(x[0], x[2]) for x in staged])
    try:
        for cwd, head, env, new, tree in staged:
            assert git('rev-parse', 'HEAD', cwd=cwd).decode().strip() == head
            assert all(sha((cwd / path).read_bytes()) == value for path, value in before[str(cwd)].items())
        for cwd, head, env, new, tree in staged:
            git('update-ref', '-m', 'ops: exact three-leaf route-provenance fallback', 'HEAD', new, head, cwd=cwd)
            for path, raw in (values if cwd == r else livevalues).items(): install(cwd, path, raw)
        for index, lp in locks: os.replace(lp, index)
    finally:
        for _, lp in locks:
            if lp.exists(): lp.unlink()
    for cwd, head, env, new, tree in staged:
        assert not git('diff', '--cached', '--name-only', cwd=cwd).strip()
        git('merge-base', '--is-ancestor', source, 'HEAD', cwd=cwd)
        assert blob(head, 'eval/versions.json', cwd) == blob(new, 'eval/versions.json', cwd)
        assert all(sha((cwd / path).read_bytes()) == value for path, value in before[str(cwd)].items())
    rec = dict(at=at, batch=bid, source=source, source_parent=base, old_main=mh, main=staged[0][3], old_live=lh, live=staged[1][3], tree=staged[1][4], source_paths=[dict(path=path, source_sha256=sha(raw), live_sha256=sha(livevalues[path])) for path, raw in values.items()], preserved_existing_script_difference=preserved_difference, source_actual_main_live_ancestor=True, unrelated_dirty_preserved=before, source_checks=checks, original_merge_conflicts_preserved=conflicts, release_id=None, release_increment=False, existing_behavior_release='V5-R366 unchanged', game_decision_behavior_or_account_home_model_prompt_changed=False, host='pending single original064301-s2-strategy-proposal request')
    write(pub / 'publication.json', rec)
    print(json.dumps({k: rec[k] for k in ['main', 'live', 'tree', 'release_id', 'source_actual_main_live_ancestor']}), flush=True)

## 修 bug 回报
- 合并基线：main → aefce170750769d997bfb088785f0aad88b1eb54（首次合并基线 7da6f7693325878a4b59113d630d219316a7f64a）
- 修复（每条一行）：无；原通知补丁在本批检查期间已由运维上线，撤销本批未提交的重复集成后快进main。
- 已被别人修掉的：silent-0254：无动作死亡战斗归因 — 3b48088dec5fc6eafe576a1296bbdadde43432ee
- 已被别人修掉的：silent-0256：狡诈药水已观察容量子项 — 6403fdcdadc803a092beb5165a068e22bf51c412
- 已被别人修掉的：silent-0260：普通紧勒逐牌失血 — 5c7105ff0294466da8319f2934beda05c6040794
- 已被别人修掉的：silent-0263：碾碎爪已观察转向取整子项 — ec29ea34b919344b707e57ba472ea210f9c39d62
- 已被别人修掉的：silent-0266：SL首牌身份 — e784dd9f043bf87c29109573f48975f9903280d3
- 已被别人修掉的：silent-0272：商店移除预览与选牌页核对 — db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26
- 已被别人修掉的：rollout-live最佳线固定夹具 — bbc5b993a7524bbb8e80a975f204f8d193657b46
- 已被别人修掉的：silent-0317：A10升级计算下注已观察模板 — b49112dbc106e315bd7156361d290fc4c73d29e2
- 已被别人修掉的：silent-0319：A10两费十毒已观察模板 — 5b56a452bb9be14d620b368ec46974c1b57901ca
- 已被别人修掉的：silent-0324：普通刀舞生成小刀 — 66c22ba7d87b8748690a4183fff838acd346bd3e
- 已被别人修掉的：silent-0338：回合末防御事实注记 — c1d84804956bedbd29a7f0e81294114e18415b9d
- 已被别人修掉的：silent-0367：已用尾巴事实传递 — 5baf663d7e6678efa3690e5a48329c4f8baee109
- 已被别人修掉的：codex-usage-credit-baseline-recovery — 5b56a452bb9be14d620b368ec46974c1b57901ca
- 已被别人修掉的：ascension-up实际进阶 — 8045d9fbf0a12523b1dbe39bbed8af06c7497b09
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout — bae9c45ccffefb284a1c6634526c8768a9f5f7a8
- 已被别人修掉的：infra-ledger-status-prefix-git-divergence — dd478f0b3e5a0f234f082972d21b203dbf8229d7
- 已被别人修掉的：infra-learner-launch-shared-main-config-race — 22efae55484bc2bdcc54e847a8dc40bb4888c4e2
- 已被别人修掉的：host-fixed-test-timeouts-010547（eval/Apotheosis固定输入及有界夹具） — d9881ba593b0b8d701ebbe1c95626c0ebdd554c7、9e8c93555131c3347f9e809d9722a848a75c2692
- 已被别人修掉的：infra-feature-root-event-notice-path（本批撤源码测试exit1，恢复及相关5项exit0） — 577f0bc424b7287910735cfdc86c253cc7ee8057
- 没修的：silent-0271：毒必胜提前返回遗漏保血候选 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0279：SL抽序升级改标 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0308：沙坑截止结束题面 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0311：库存恢复血量预算 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0320：同线新建UNMOVABLE — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0322：升级神化同线升级 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0329：饮药临时力量接线 — 策略类/沿原独立提案，宽父保持
- 没修的：arch-funnel-guard — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：arch-learning-priority — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：arch-unified-resource-value — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：inv-f33-regression — 太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。
- 没修的：silent-0332：成功首战接续nonpositive-hp — 证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知
- 没修的：silent-0334：升级隐秘匕首模型 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0339：尾巴误核销 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0344：坚韧之环延迟格挡 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0347：组装师攻击召唤 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0349：已有虚弱后的减力 — 策略类/沿原独立提案，宽父保持
- 没修的：core-build-notify-222802-rc2：历史发送事实 — 证据不足：后续诊断已修，原历史发送事实未知
- 没修的：silent-0362：背向攻击减力倍率 — 策略类/沿原独立提案，宽父保持
- 没修的：silent-0365：未建模药水目标可达性 — 策略类/沿原独立提案，宽父保持
- 没修的：框架外层时限与分段续验收尾 — 太大/独立框架：精确续验入口已实现，宿主收尾范围继续
- 没修的：调度公平性核查 — 证据不足：未证明永久饥饿，沿原框架核查
- 没修的：silent-0481：技能药水生命周期措辞 — 策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项
- 没修的：silent-0487：MAD_SCIENCE三段攻击模型 — 策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。
- 没修的：codex大脑缓存命中偏低 — 证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。
- 没修的：sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因 — 证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。
- 没修的：named-card-facts-transport：事件入口之外范围 — 太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。
- 没修的：boss模拟样本性能及v5-dpr-health宽范围 — 太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。
- 没修的：rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。
- 没修的：silent-0469：纸鹤其他未知组合/整战收益 — 策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。
- 测试：tsc退出码0；定向vitest 5文件/5用例/退出码0；未重跑。完整沙箱已进入vitest后因原修复已上线而主动中止，退出码130，没有全套通过结论。gitleaks补丁扫描0。
- 合入：未合入（本批无新增提交；原修复已由运维合入live 2806f8bd8376e9e6e83c296226d9209b386d7292，main aefce170750769d997bfb088785f0aad88b1eb54；工作区干净）。
- 需要 Roy 定的事（没有写「无」）：无。

```json
{
  "task": "fix-batch",
  "base": "aefce170750769d997bfb088785f0aad88b1eb54",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0271：毒必胜提前返回遗漏保血候选",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0279：SL抽序升级改标",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0308：沙坑截止结束题面",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0311：库存恢复血量预算",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0320：同线新建UNMOVABLE",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0322：升级神化同线升级",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0329：饮药临时力量接线",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "arch-funnel-guard",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-learning-priority",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "arch-unified-resource-value",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "inv-f33-regression",
      "reason": "太大/独立架构或归因任务，普通纯bug批不混入；沿原owner继续。"
    },
    {
      "item": "silent-0332：成功首战接续nonpositive-hp",
      "reason": "证据不足：契约分支可定位，资源/steps尾部及机制根因仍未知"
    },
    {
      "item": "silent-0334：升级隐秘匕首模型",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0339：尾巴误核销",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0344：坚韧之环延迟格挡",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0347：组装师攻击召唤",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0349：已有虚弱后的减力",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足：后续诊断已修，原历史发送事实未知"
    },
    {
      "item": "silent-0362：背向攻击减力倍率",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "silent-0365：未建模药水目标可达性",
      "reason": "策略类/沿原独立提案，宽父保持"
    },
    {
      "item": "框架外层时限与分段续验收尾",
      "reason": "太大/独立框架：精确续验入口已实现，宿主收尾范围继续"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：未证明永久饥饿，沿原框架核查"
    },
    {
      "item": "silent-0481：技能药水生命周期措辞",
      "reason": "策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项"
    },
    {
      "item": "silent-0487：MAD_SCIENCE三段攻击模型",
      "reason": "策略类：MAD_SCIENCE三段攻击模型；沿原silent-proposal-0a0b31e284e6793e独立策略链，不重复派发。"
    },
    {
      "item": "codex大脑缓存命中偏低",
      "reason": "证据不足：缺当前同题受控请求对比，本离线任务不调用真实LLM或网络。"
    },
    {
      "item": "sandbox-glob-startup-race：上游目录生命周期及其他租约拒绝原因",
      "reason": "证据不足：798af209注册保存屏障已是main/live祖先；上游目录删除者及完整生命周期仍未知。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外范围",
      "reason": "太大/独立功能：42c920f34事件入口已实现，其余沿原架构owner。"
    },
    {
      "item": "boss模拟样本性能及v5-dpr-health宽范围",
      "reason": "太大/独立专项：保留原冻结输入、样本/预算和验收链，不以定向回归代替校准。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构：沿原silent-proposal-2d3aa8dfb27dbe3f，不无条件提交未确认动作。"
    },
    {
      "item": "silent-0469：纸鹤其他未知组合/整战收益",
      "reason": "策略类：本基线已含8d386fc76的已观察聚合体子项，不能关闭更宽组合/整战范围。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 5,
    "files": 5,
    "scope": "targeted",
    "full_sandbox": 130
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261016-071305-e225ab76-3c86-43d0-b1ce-41f73a44fd6b-fix-batch/report.md"
}
```

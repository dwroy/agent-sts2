# 批次报告初稿（检查与部署待完成）

base=84524bce1d7b57f42403b80e42082c62fc8cd158

本批只实施路线投影可追溯字段，仍没有足够证据调整游戏策略参数。10项派发宽提案保留waiting，逐项证据、反例、缺口及回退见proposal.md；本次不得以未来字段齐全替代旧局完整资源归属。

材料核验：12702行、8流、26项限定断言；17条ZTR饮用请求与SL恢复分账，K2铁心勘误原件为states292788→292789，0挡不变、覆甲+7。K2/79的历史brain题面显示成本已定位，不复用旧“全部源成本无法定位”的笼统说法。

固定记录测试：移除新增源码exit1（4失败/1通过），恢复exit0（5通过）。gitleaks staged扫描exit0。完整沙箱检查仍pending，不将tsc阶段已过当成vitest已过。

源码接线手工审计：原loop.ts:applyResolved/logRouteChange序列化整个route_plan；journal-replay.ts:routePlanOf直接读回；RunJournal和构筑/战斗消费者继续只用原字段。源码10叶7同，3叶只有已有Roy/Dai注释差；既有零毒分支来源为5dbb47bfb48d652adfcda2e62c166a804098b6c3，原base与本轮live快照祖先均通过，不能当本批新实现。

局限：源材料的行SHA/身份认证不等全行语义认证；p75显示值可能取整，不还原旧完整dirty知识。原F27 16挡稿及更正稿都保存；旧K2路线变更两行无decision_id，不补造旧ID。未核完整随机多目标、洗牌后受控替线与饮药时机，均不填零或认胜。

初始宽输出曾截断、core/log.ts和setup.*路径探针未命中；已改用精确读取，不当产品bug。原失败日志及初稿保留。无play、无联网、无下级agent、无依赖安装、无版本或shipped声明。

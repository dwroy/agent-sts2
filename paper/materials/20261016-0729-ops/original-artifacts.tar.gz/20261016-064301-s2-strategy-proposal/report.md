# 静默猎手策略提案批次报告

批次：`20261016-064301-s2-strategy-proposal`；角色：silent。

源码已提交：`7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a`；基线/源码父提交：`84524bce1d7b57f42403b80e42082c62fc8cd158`。

**结果：只实现路线投影追溯字段，自测通过；因19个记录文件合并冲突，未合入live。十项宽提案全部waiting，未关闭任何父要求。**

## 本次源码与证据

关联原提案 silent-proposal-9edfef7a6b2873c2，账本 silent-0019/silent-0020/silent-0021。仅在 Silent A10 的 makeRoutePlan 增加可选projection对象：起始HP/maxHP、当前地图节点、房间成本的数值与来源、休息回血与未建模Boss损失假设、逐节点绝对HP/maxHP；复制嵌套输入防后续刷新污染旧计划。

原loop的route_plan日志完整序列化与journal-replay的routePlanOf读回保留新对象；模型文字和决策继续使用原path/hpPct，固定回放逐项相等。其他角色及未观察进阶对象形状相等。本次没有修改打法、路线权重、药水持有价、SL或尾端公式，因此没有新行为发布号。

| 证据 | 计划与实际 | 直接支持的范围 |
|---|---|---|
| K2JAGKVJAWZJ F34非战斗计划 → F46T1 | decisions286314 / brain8622；r12c3旧投影75，实到86/91 | 保存原75分母、原起始65/75和成本，不用后得91重算 |
| 79UCJ0K6R9C1 F1计划 → F14T1 | decisions286488 / brain8635；r13c6旧投影70，实到51/70 | 原始中位数投影与实际资源分列，不按两个误差拟统一扣加值 |

固定夹具 agent/tests/silent-route-projection-evidence.json 保存原件源行/offset/bytes/SHA与当时显示成本，测试不读取刷新knowledge、不调LLM或网络。显示p75 35.8可能取整，只认证记录中位数路径，不冒称完整旧知识字节已恢复。第二Boss等未知HP保持null，不填0。

## 验证

| 检查 | 实际结果 |
|---|---|
| 撤新增源码定向检查 | exit1；4失败/1通过 |
| 恢复源码定向检查 | exit0；5通过，首轮和确认轮日志均保留 |
| agent/tools/test-sandbox.sh | exit0；tsc0；438文件4104项 + paths 1文件11项，共439文件4115项通过 |
| gitleaks staged --redact | exit0；未发现泄漏 |
| 原件材料核验 | 8流12702行，逐offset/bytes/SHA/显式身份核；26项限定断言通过 |

沙箱测试首段1267.76秒、paths段4.72秒；无超时重跑。固定排除名单仍按原脚本；未运行沙箱外完整套件，也未运行合后测试。材料检查不是生产测试或全行机制语义认证。

## 合入受阻与运维交接

已取得 ops/live-merge.lock，在实际live `92c3d22f191f0a79a4f0c56d29b189bd7185fca0` 上对源码 `7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a` 做只读三方合并预检，exit1。前后HEAD相同，源码不是该live祖先。未进入知识刷新提交或实际merge，live用户文件没有被本任务改写；没有合入提交、版本、上线通知或shipped。

19个冲突路径：

- `notes/fix-queue-v4.md`
- `notes/for-roy.md`
- `notes/lessons.md`
- `notes/ops-handoff.md`
- `ops/inbox-dev.md`
- `paper/data/README.md`
- `paper/data/commits.csv`
- `paper/data/cost-curve-silent.csv`
- `paper/data/cost-silent.csv`
- `paper/data/cost-sources.json`
- `paper/data/cost-unattributed.csv`
- `paper/data/decisions_by_label.csv`
- `paper/data/learning-curve-silent.csv`
- `paper/data/runs.csv`
- `paper/data/summary.json`
- `paper/data/verification.json`
- `paper/materials/decision-log.md`
- `paper/materials/learning/ledger.jsonl`
- `paper/materials/silent/cost.md`

冲突原件 preflight-live-merge.txt / preflight-live-merge.err，锁与HEAD回执 merge-blocker.json。运维可据源码提交及 source-staged.patch 兜底集成；保留并行知识、账本与记录，不把预检生成的树当发布树。实际合入后仍须标准知识预检、合后检查及宿主补跑；消费者自然记录尚未验收。

## 派发逐项处置

### silent-proposal-0b8ef30de463f317 — waiting

账本：silent-0013, silent-0277。
证据：ZTRGYYMLR8SC F6T3、F17六试T1/T2/T14；states 292343；17条饮药请求，见 evidence-check.json。
具体限制/未实现原因：当前 potion-cost.ts 已区分 no_table/no_value。铁心只增加覆甲与旧牌挡分列。缺晚喝/留药同资源完整对照，SL恢复的两原瓶不能当新增独立药水样本；不改持有价和饮用阈值。

### silent-proposal-5367449b857450a7 — waiting

账本：silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284。
证据：ZTRGYYMLR8SC F17末T5/T14；原提案的1LMB/9YT/252/TCF/ULP/61证据已按局提取并核身份。
具体限制/未实现原因：现有 card-model/turn-solver 已有减力、脆弱、覆甲和单弃牌子项。刀扇原关键窗只有单敌；铜钹多弃/随机多目标与混合修饰未获可隔离全链，不用100次单弃代替多弃公式。

### silent-proposal-9b8890c2649a2734 — waiting

账本：silent-0012, silent-0019, silent-0020, silent-0021, silent-0125。
证据：ZTRGYYMLR8SC F11T3、F17首试T10/末试T13/T14；F17六个68/70入口和五个缺出口见资源报告。
具体限制/未实现原因：六试共享同局资源；候选局部省血不是整战已得收益，原线、未走路线、晚喝药没有完整受控出口。已有追踪不等完整联合校准，不改HP护栏、SL或终局权重。

### silent-proposal-645ff7b72e0b9991 — waiting

账本：silent-0010, silent-0106, silent-0021, silent-0286。
证据：K2JAGKVJAWZJ F46T1 states293158→293159；79UCJ0K6R9C1 F14T3/T6/T10/T11 states293463→293465。
具体限制/未实现原因：5dbb47bfb4来源的零毒升级蜃景窄分支已存在；普通正毒蜃景是不能全类归零的反例。0/8实赢不等8死，缺尾端胜率校准及替线完整结果；感染终局先死而毒未结，保留既有顺序。

### silent-proposal-68ef2857229d1287 — waiting

账本：silent-0278, silent-0286。
证据：K2JAGKVJAWZJ F33首试T10 states292940→292941毒42→48/HP54不变；79UCJ0K6R9C1 F14T11 states293463→293464毒4→10/HP8不变。
具体限制/未实现原因：两次只支持当步施毒，不支持整轮生存。当前 crabPoisonFacts 的完整组合属于另一已核观察，不能套K2，79又是同型多虫。缺两者联合修饰及完整后继校准，不扩大所有非双boss短推演范围。

### silent-proposal-9edfef7a6b2873c2 — waiting

账本：silent-0020, silent-0019, silent-0021。
证据：K2JAGKVJAWZJ F34非战斗计划 decisions286314/brain8622，F46T1实到86/91；79UCJ0K6R9C1 F1计划decisions286488/brain8635，F14T1实到51/70。
具体限制/未实现原因：本批实施未来路线投影的审计字段：起始HP/maxHP、当前节点、房间成本原精度与source、休息/未建模Boss损失假设、逐节点绝对HP/maxHP。旧归一化投影与选择输入保持。旧路线变更两条无decision_id、分类药水/SL/每轮整战联合消费者仍不完整，因此宽提案维持waiting，不把局部接线当整项完成。 局部源码7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a自测通过，但锁内合并预检19记录冲突，尚非live祖先，交ops兜底。

### silent-proposal-ff1d168227e369e0 — waiting

账本：silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178。
证据：K2JAGKVJAWZJ F46T1/T6/T7/T9及10GPK5XGHCK3 A3；UJ0K3G10609Y仅保留原提案来源，本批不冒称已新核其全局。
具体限制/未实现原因：升级零毒子项已有实现；升级正毒、爆发/暗影/逐击减损联合后继不能由零毒样本推出。三骑士T7多2伤的完整来源未隔离，A3不混A10参数；不扩全组合公式。

### silent-proposal-c64bdd50a949d16f — waiting

账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。
证据：K2JAGKVJAWZJ F27T2 decisions286123，states292788→292789；F33两试62HP入口与末试28HP出口。
具体限制/未实现原因：原稿“16挡”已被原纠正版9c3ff取代；本批核药前后均0挡、覆甲0→7，保留旧原文SHA。不能因勘误落盘就将整个资源/能力/饮药时机联合提案标duplicate；完整时点反事实与跨战消费者仍缺。

### silent-proposal-243ad8dd038a4ff6 — waiting

账本：silent-0019, silent-0020, silent-0065, silent-0106。
证据：K2JAGKVJAWZJ F31进75出40；F33首试62→10判死截断、次试62→28胜；F46进86/91实死。
具体限制/未实现原因：同首29抽只限定已有前缀，T5洗牌后的抽序与多动作差异未控，不能单独归因首目标或未喝药。三骑士替目标整战胜线、替路线/休息后继均未执行，不拟固定SL血价和目标序。

### silent-proposal-9c3ff04261867dd2 — waiting

账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。
证据：K2JAGKVJAWZJ F27T2 states292788→292789即时挡0→0、覆甲0→7；F33T10药后不伤本体。
具体限制/未实现原因：覆甲数字勘误已重新核实，仍缺实建能力/获得/弃药/饮用/SL恢复至终局的联合消费者与早喝/换瓶完整对照；勘误不是新的药水时机规则。

## 账本、知识与历史边界

根账本仅经ledger.py追加20条where/note链接与3条局部源码追溯，均by=learner:strategy-proposal；不重复support/repeat，不修改旧claim、first_run、prior、状态、版本或证据。专用队列沿原十id，无重复新id；最终状态交调用方按proposal_results保存。本次不写经验库、不冒称大脑已采用。

十锚点身份均SILENT；A3/A4/A7各1局，A10七局分列，未将历史混合脑局改成纯Codex成绩。来源提案UJ0K3G10609Y未在本批重新抽取或当新证。六默认流与runs/fight-plans由共用extract_evidence.py提取，保存原截点和逐行指纹；fight-plans本次截点0行仅表示未选到。

ZTR F17六试68/70入口、五个SL缺出口单列；K2 F33首试62→10截断，SL后62→28胜；79 F14入51/70，三感染先致死而敌8HP/10毒未结。K2 F27T2铁心药前后0挡，覆甲0→7，原16挡提案与更正版原文/SHA均保留。单动作、SL重复、净敌血池和少量尾端样本不替代完整整战反事实或独立样本。

历史run-config的十个源码提交均存在；dirty列表中的知识/记录字节未完整恢复，不笼统称源码无法定位。当前相关10叶7同，3叶仅旧Roy/Dai注释差；旧零毒来源5dbb47bfb48d652adfcda2e62c166a804098b6c3已是base/预检live祖先，不能当本批新实现。

初始宽输出截断和路径探针失败已保留，不当产品缺陷。report-draft.md保留测试尚pending时的原初稿；最终以本报告和result.json为准。没有联网、play、依赖安装、推送、下级agent或运维prompt修改。工作树源码已提交且干净；自身工作树和所有材料保留，回收由原调度器处理。

## 机器回报

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261016-064301-s2-strategy-proposal",
  "base": "84524bce1d7b57f42403b80e42082c62fc8cd158",
  "runs": [
    "ZTRGYYMLR8SC",
    "1LMBFGSMCWKU",
    "9YT51CK8RC39",
    "25226ZFLNR1J",
    "TCFAHJ9K19VY",
    "ULP4TN1GNHMK",
    "61E2QS63Y9WU",
    "K2JAGKVJAWZJ",
    "79UCJ0K6R9C1",
    "10GPK5XGHCK3"
  ],
  "fixes": [
    {
      "id": "silent-route-projection-provenance",
      "proposal_id": "silent-proposal-9edfef7a6b2873c2",
      "commit": "7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a",
      "source_parent": "84524bce1d7b57f42403b80e42082c62fc8cd158",
      "ledger": [
        "silent-0019",
        "silent-0020",
        "silent-0021"
      ],
      "summary": "Silent A10路线投影审计来源局部实现；已自测，尚未合入live"
    }
  ],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 0
  },
  "code_proposals": [
    "silent-proposal-0b8ef30de463f317",
    "silent-proposal-5367449b857450a7",
    "silent-proposal-9b8890c2649a2734",
    "silent-proposal-645ff7b72e0b9991",
    "silent-proposal-68ef2857229d1287",
    "silent-proposal-9edfef7a6b2873c2",
    "silent-proposal-ff1d168227e369e0",
    "silent-proposal-c64bdd50a949d16f",
    "silent-proposal-243ad8dd038a4ff6",
    "silent-proposal-9c3ff04261867dd2"
  ],
  "implementation_domains": [
    "structure"
  ],
  "proposal_results": [
    {
      "id": "silent-proposal-0b8ef30de463f317",
      "state": "waiting",
      "reason": "当前 potion-cost.ts 已区分 no_table/no_value。铁心只增加覆甲与旧牌挡分列。缺晚喝/留药同资源完整对照，SL恢复的两原瓶不能当新增独立药水样本；不改持有价和饮用阈值。"
    },
    {
      "id": "silent-proposal-5367449b857450a7",
      "state": "waiting",
      "reason": "现有 card-model/turn-solver 已有减力、脆弱、覆甲和单弃牌子项。刀扇原关键窗只有单敌；铜钹多弃/随机多目标与混合修饰未获可隔离全链，不用100次单弃代替多弃公式。"
    },
    {
      "id": "silent-proposal-9b8890c2649a2734",
      "state": "waiting",
      "reason": "六试共享同局资源；候选局部省血不是整战已得收益，原线、未走路线、晚喝药没有完整受控出口。已有追踪不等完整联合校准，不改HP护栏、SL或终局权重。"
    },
    {
      "id": "silent-proposal-645ff7b72e0b9991",
      "state": "waiting",
      "reason": "5dbb47bfb4来源的零毒升级蜃景窄分支已存在；普通正毒蜃景是不能全类归零的反例。0/8实赢不等8死，缺尾端胜率校准及替线完整结果；感染终局先死而毒未结，保留既有顺序。"
    },
    {
      "id": "silent-proposal-68ef2857229d1287",
      "state": "waiting",
      "reason": "两次只支持当步施毒，不支持整轮生存。当前 crabPoisonFacts 的完整组合属于另一已核观察，不能套K2，79又是同型多虫。缺两者联合修饰及完整后继校准，不扩大所有非双boss短推演范围。"
    },
    {
      "id": "silent-proposal-9edfef7a6b2873c2",
      "state": "waiting",
      "reason": "本批实施未来路线投影的审计字段：起始HP/maxHP、当前节点、房间成本原精度与source、休息/未建模Boss损失假设、逐节点绝对HP/maxHP。旧归一化投影与选择输入保持。旧路线变更两条无decision_id、分类药水/SL/每轮整战联合消费者仍不完整，因此宽提案维持waiting，不把局部接线当整项完成。 局部源码7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a自测通过，但锁内合并预检19记录冲突，尚非live祖先，交ops兜底。"
    },
    {
      "id": "silent-proposal-ff1d168227e369e0",
      "state": "waiting",
      "reason": "升级零毒子项已有实现；升级正毒、爆发/暗影/逐击减损联合后继不能由零毒样本推出。三骑士T7多2伤的完整来源未隔离，A3不混A10参数；不扩全组合公式。"
    },
    {
      "id": "silent-proposal-c64bdd50a949d16f",
      "state": "waiting",
      "reason": "原稿“16挡”已被原纠正版9c3ff取代；本批核药前后均0挡、覆甲0→7，保留旧原文SHA。不能因勘误落盘就将整个资源/能力/饮药时机联合提案标duplicate；完整时点反事实与跨战消费者仍缺。"
    },
    {
      "id": "silent-proposal-243ad8dd038a4ff6",
      "state": "waiting",
      "reason": "同首29抽只限定已有前缀，T5洗牌后的抽序与多动作差异未控，不能单独归因首目标或未喝药。三骑士替目标整战胜线、替路线/休息后继均未执行，不拟固定SL血价和目标序。"
    },
    {
      "id": "silent-proposal-9c3ff04261867dd2",
      "state": "waiting",
      "reason": "覆甲数字勘误已重新核实，仍缺实建能力/获得/弃药/饮用/SL恢复至终局的联合消费者与早喝/换瓶完整对照；勘误不是新的药水时机规则。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-064301-s2/learner/runs/20261016-064305-3234cef3-e3a0-42c5-94fa-0d7e59388953-strategy-proposal/report.md",
  "proposal": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-064301-s2/learner/runs/20261016-064305-3234cef3-e3a0-42c5-94fa-0d7e59388953-strategy-proposal/proposal.md",
  "version": null,
  "merge_blocker": {
    "live": "92c3d22f191f0a79a4f0c56d29b189bd7185fca0",
    "conflict_count": 19,
    "preflight_exit": 1,
    "lock_acquired": true,
    "live_mutated": false
  },
  "validation": {
    "sandbox_files": 439,
    "sandbox_cases": 4115,
    "focused_cases": 5,
    "without_source_exit": 1,
    "restored_exit": 0,
    "gitleaks_exit": 0,
    "evidence_checks": 26,
    "evidence_rows": 12702,
    "live_checks": null
  }
}
```

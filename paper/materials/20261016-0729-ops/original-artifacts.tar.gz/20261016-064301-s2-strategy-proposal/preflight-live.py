import fcntl
import json
import subprocess
import time
from pathlib import Path

out = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
live = root / '.worktrees/live'
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
result = {'source': source, 'lock_acquired': False, 'live_mutated': False, 'merged': None}
with (root / 'ops/live-merge.lock').open('a') as lock:
    deadline = time.monotonic() + 20
    while True:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            result['lock_acquired'] = True
            break
        except BlockingIOError:
            if time.monotonic() >= deadline: break
            time.sleep(1)
    if result['lock_acquired']:
        head = subprocess.check_output(['git', '-C', str(live), 'rev-parse', 'HEAD'], text=True).strip()
        result['live_before'] = head
        probe = subprocess.run(['git', '-c', 'merge.renames=false', 'merge-tree', '--write-tree', '--name-only', head, source], capture_output=True, text=True)
        (out / 'preflight-live-merge.txt').write_text(probe.stdout)
        (out / 'preflight-live-merge.err').write_text(probe.stderr)
        result['preflight_exit'] = probe.returncode
        lines = probe.stdout.splitlines()
        result['conflicts'] = lines[1:lines.index('')] if probe.returncode == 1 and '' in lines else []
        result['source_is_live_ancestor'] = subprocess.run(['git', '-C', str(live), 'merge-base', '--is-ancestor', source, head]).returncode == 0
        result['live_after'] = subprocess.check_output(['git', '-C', str(live), 'rev-parse', 'HEAD'], text=True).strip()
        assert result['live_after'] == head
        result['reason'] = '三方合并预检存在记录冲突，未进入任何live文件变更，交ops兜底。' if probe.returncode else '预检可合并；须继续标准刷新/合入/检查流程。'
    else:
        result['reason'] = 'live-merge.lock在20秒内未释放；未进入live变更。已有基线分叉预检19冲突保留。'
(out / 'merge-blocker.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

# 本批策略提案核验与有限追溯实现

本批：`20261016-064301-s2-strategy-proposal`；角色：silent；基线：`84524bce1d7b57f42403b80e42082c62fc8cd158`。

身份：learn.json 对应行 task=strategy-proposal、character=silent、reason=proposal，工作树匹配；只领取原十个 id，无 research_request / implementation_request。专题请求属于其他批，不承接。main 合并返回 Already up to date。

## 共同证据与边界

游戏结论只用本角色原始对局。十锚点的 runs 身份全部为SILENT，A3/A4/A7各1局、A10七局，分阶保留；历史混合大脑局不改成纯Codex战绩。六条默认流加runs/fight-plans共12702行，逐源offset/bytes/SHA/显式身份核验见 evidence-check.json；26项限定材料断言通过不是全语义审计，也不是生产测试。fight-plans本次截点未选到行，不推断日志从未存在。

不拟合打法/持有价/SL/尾端权重；同局SL整组不拆训练验证。现有两局作固定回放，只有未来新完局可供时间后留出。两原始日志显示的成本来源与中位数投影可核；不称已恢复完整历史dirty知识或全部原精度。

## 实际源码范围

`agent/src/hand/screens/route-plan.ts` 的 `makeRoutePlan` 仅在已观察 Silent A10 加可选 `projection` 审计对象，直接复制本次调用的成本模型，保存绝对到达HP/maxHP与未知null。决策原行已有 observed_ts / fingerprint / run_id / decision_id 或旧计划ref；原有 loop.ts 直接序列化整个 route_plan，journal-replay.ts 原样读回。新对象不进入现有 routeBlockState/RunJournal 的模型文字；各既有策略只读原path/hpPct，未修改排序、阈值或游戏公式。其他角色和未观察进阶保持原对象形状。

K2 F34旧投影使用75上限，r12c3到达75；真实F46为86/91。79旧计划r13c6到达70，真实F14为51/70。这是两个不同方向误差，不是统一加减血规则。未来记录保存原分母和原成本，不能用后来的91重算旧75。旧第二Boss HP为null的记录仍为null。

验证：固定两局保存原件引用与显示成本；检查新记录序列化/原生产回放读取、原normalized path逐项相等、后继状态/输入成本突变不污染历史快照，以及其他角色/进阶对象形状相等。撤源码定向测试exit1，恢复exit0；生产沙箱全套另见报告。预期仅增加可追溯性，不承诺收益。回退为逆向单独源码提交；保留原日志、知识刷新、账本和失败材料。

## 派发逐项

### silent-proposal-0b8ef30de463f317

原件：`/home/dw/Projects/agent-sts2/learner/runs/20261008-084303-postmortem/proposal-potion-plating.md`；SHA256 `ac20c158f9134f0c139a7a3886d3c26fbb542517b3ebf2e1c2c8078e228cbeb8`。
账本：silent-0013, silent-0277。来源任务 postmortem → strategy-proposal。
证据：ZTRGYYMLR8SC F6T3、F17六试T1/T2/T14；states 292343；17条饮药请求，见 evidence-check.json。
处置与缺口：当前 potion-cost.ts 已区分 no_table/no_value。铁心只增加覆甲与旧牌挡分列。缺晚喝/留药同资源完整对照，SL恢复的两原瓶不能当新增独立药水样本；不改持有价和饮用阈值。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-5367449b857450a7

原件：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-mechanisms.md`；SHA256 `2bbe2e854ce6bdb95609f800eb8434cdb05b6be963cfc8ec1870d81d65aee062`。
账本：silent-0012, silent-0013, silent-0046, silent-0149, silent-0277, silent-0284。来源任务 experience-update → strategy-proposal。
证据：ZTRGYYMLR8SC F17末T5/T14；原提案的1LMB/9YT/252/TCF/ULP/61证据已按局提取并核身份。
处置与缺口：现有 card-model/turn-solver 已有减力、脆弱、覆甲和单弃牌子项。刀扇原关键窗只有单敌；铜钹多弃/随机多目标与混合修饰未获可隔离全链，不用100次单弃代替多弃公式。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-9b8890c2649a2734

原件：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-085641-experience-update/proposal-trace.md`；SHA256 `ddafc2fed623f77ca9c28eff1309aedb8f1f746e3714756f5b71ee5eb1d97f57`。
账本：silent-0012, silent-0019, silent-0020, silent-0021, silent-0125。来源任务 experience-update → strategy-proposal。
证据：ZTRGYYMLR8SC F11T3、F17首试T10/末试T13/T14；F17六个68/70入口和五个缺出口见资源报告。
处置与缺口：六试共享同局资源；候选局部省血不是整战已得收益，原线、未走路线、晚喝药没有完整受控出口。已有追踪不等完整联合校准，不改HP护栏、SL或终局权重。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-645ff7b72e0b9991

原件：`/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-combat-observed-payoff.md`；SHA256 `55cd7445ba3ac32ef6bff153a908a5b729ea6dc7939b84be7ba6712080cd5ace`。
账本：silent-0010, silent-0106, silent-0021, silent-0286。来源任务 postmortem → strategy-proposal。
证据：K2JAGKVJAWZJ F46T1 states293158→293159；79UCJ0K6R9C1 F14T3/T6/T10/T11 states293463→293465。
处置与缺口：5dbb47bfb4来源的零毒升级蜃景窄分支已存在；普通正毒蜃景是不能全类归零的反例。0/8实赢不等8死，缺尾端胜率校准及替线完整结果；感染终局先死而毒未结，保留既有顺序。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-68ef2857229d1287

原件：`/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-potion-observed-scope.md`；SHA256 `f30a8d0b9964ccf0009478cb80065bb5fafc8d6cce81b760bafc7aace1848d6f`。
账本：silent-0278, silent-0286。来源任务 postmortem → strategy-proposal。
证据：K2JAGKVJAWZJ F33首试T10 states292940→292941毒42→48/HP54不变；79UCJ0K6R9C1 F14T11 states293463→293464毒4→10/HP8不变。
处置与缺口：两次只支持当步施毒，不支持整轮生存。当前 crabPoisonFacts 的完整组合属于另一已核观察，不能套K2，79又是同型多虫。缺两者联合修饰及完整后继校准，不扩大所有非双boss短推演范围。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-9edfef7a6b2873c2

原件：`/home/dw/Projects/agent-sts2/learner/runs/20261008-094302-postmortem/proposal-resource-projection-provenance.md`；SHA256 `d920109bd6d754df32fa941dc4404e979dbcfaaf48db906b85cbc9d77a45cc96`。
账本：silent-0020, silent-0019, silent-0021。来源任务 postmortem → strategy-proposal。
证据：K2JAGKVJAWZJ F34非战斗计划 decisions286314/brain8622，F46T1实到86/91；79UCJ0K6R9C1 F1计划decisions286488/brain8635，F14T1实到51/70。
处置与缺口：本批实施未来路线投影的审计字段：起始HP/maxHP、当前节点、房间成本原精度与source、休息/未建模Boss损失假设、逐节点绝对HP/maxHP。旧归一化投影与选择输入保持。旧路线变更两条无decision_id、分类药水/SL/每轮整战联合消费者仍不完整，因此宽提案维持waiting，不把局部接线当整项完成。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-ff1d168227e369e0

原件：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-mechanisms.md`；SHA256 `b69ab5987f7e058572c2e42190046ab1f4806712d9939f55db969342df3a34e1`。
账本：silent-0010, silent-0012, silent-0013, silent-0046, silent-0077, silent-0115, silent-0178。来源任务 experience-update → strategy-proposal。
证据：K2JAGKVJAWZJ F46T1/T6/T7/T9及10GPK5XGHCK3 A3；UJ0K3G10609Y仅保留原提案来源，本批不冒称已新核其全局。
处置与缺口：升级零毒子项已有实现；升级正毒、爆发/暗影/逐击减损联合后继不能由零毒样本推出。三骑士T7多2伤的完整来源未隔离，A3不混A10参数；不扩全组合公式。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-c64bdd50a949d16f

原件：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-resources.md`；SHA256 `979e5eb65499c91eed763906c40aa0b50a42b598925021c83c220bef3e7bc658`。
账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。来源任务 experience-update → strategy-proposal。
证据：K2JAGKVJAWZJ F27T2 decisions286123，states292788→292789；F33两试62HP入口与末试28HP出口。
处置与缺口：原稿“16挡”已被原纠正版9c3ff取代；本批核药前后均0挡、覆甲0→7，保留旧原文SHA。不能因勘误落盘就将整个资源/能力/饮药时机联合提案标duplicate；完整时点反事实与跨战消费者仍缺。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-243ad8dd038a4ff6

原件：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-trace.md`；SHA256 `e8f8451e62c4f0435082e636dba0308bbe60ee86b992f85328a17835062a1acc`。
账本：silent-0019, silent-0020, silent-0065, silent-0106。来源任务 experience-update → strategy-proposal。
证据：K2JAGKVJAWZJ F31进75出40；F33首试62→10判死截断、次试62→28胜；F46进86/91实死。
处置与缺口：同首29抽只限定已有前缀，T5洗牌后的抽序与多动作差异未控，不能单独归因首目标或未喝药。三骑士替目标整战胜线、替路线/休息后继均未执行，不拟固定SL血价和目标序。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。

### silent-proposal-9c3ff04261867dd2

原件：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-101302-experience-update/proposal-resources-corrected.md`；SHA256 `2f19523d142524633da29cdb34fd133fd86b3b8fbc95cf4de2e10c37ad4ebb7b`。
账本：silent-0021, silent-0243, silent-0276, silent-0277, silent-0278。来源任务 experience-update → strategy-proposal。
证据：K2JAGKVJAWZJ F27T2 states292788→292789即时挡0→0、覆甲0→7；F33T10药后不伤本体。
处置与缺口：覆甲数字勘误已重新核实，仍缺实建能力/获得/弃药/饮用/SL恢复至终局的联合消费者与早喝/换瓶完整对照；勘误不是新的药水时机规则。
状态：waiting（局部实现的实际提交/合入由report补记；不登记整项implemented或shipped）。


## 最终实现与合入处置

局部源码 `7c43bbbb98f58ff3bfe9a68a04d8539ebb187d6a`，父提交 `84524bce1d7b57f42403b80e42082c62fc8cd158`。沙箱tsc0、439文件4115项vitest通过；撤源码4失败/1通过，恢复5通过。最终锁内预检仍有19个记录冲突，live `92c3d22f191f0a79a4f0c56d29b189bd7185fca0` 未改动，源码尚非live祖先；不标整项implemented/duplicate/shipped，不分配版本。其余九项没有新增策略源码。最终报告：[report.md](report.md)。

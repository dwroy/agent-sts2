import hashlib
import importlib.util
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
dispatch = json.loads((OUT / 'dispatch-proposals.json').read_text())
runs = json.loads((OUT / 'runs-identity.json').read_text())
checks, streams, rows = [], [], {}

def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    assert value, name

for directory in ('evidence', 'evidence-extra'):
    manifest = json.loads((OUT / directory / 'evidence-manifest.json').read_text())
    for meta in manifest:
        path = OUT / directory / (meta['stream'] + '.evidence.jsonl')
        check(meta['stream'] + ':artifact_sha', hashlib.sha256(path.read_bytes()).hexdigest() == meta['output_sha256'])
        selected = []
        with (Path('/home/dw/Projects/agent-sts2/logs') / (meta['stream'] + '.jsonl')).open('rb') as source:
            for line in path.open():
                envelope = json.loads(line)
                source.seek(envelope['offset'])
                raw = source.read(envelope['bytes'])
                assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
                assert json.loads(raw) == envelope['row']
                assert envelope['offset'] + envelope['bytes'] <= meta['source_size']
                row = envelope['row']
                identities = [row.get('run_id'), row.get('run')]
                if isinstance(row.get('state'), dict): identities.append(row['state'].get('run_id'))
                fingerprint = row.get('fingerprint')
                if isinstance(fingerprint, str): fingerprint = json.loads(fingerprint)
                if isinstance(fingerprint, dict): identities.append(fingerprint.get('run'))
                explicit = {v for v in identities if isinstance(v, str) and v and v != 'run_unknown'}
                assert explicit == {envelope['run_id']}
                assert envelope['run_id'] in runs
                selected.append(envelope)
        count = Counter(e['run_id'] for e in selected)
        check(meta['stream'] + ':source_bytes_identity_counts', all(count[r] == n for r, n in meta['counts'].items()))
        rows[meta['stream']] = selected
        streams.append({'stream': meta['stream'], 'rows': len(selected), 'source_size': meta['source_size'], 'sha256': meta['output_sha256']})

check('dispatch:ten_own_proposals', len(dispatch['proposals']) == 10 and all(p['character'] == 'silent' for p in dispatch['proposals']))
check('runs:character', all(r['character'] == 'SILENT' for r in runs.values()))
check('states:character_ascension', all(e['row']['state']['run']['character_id'] == 'SILENT' and e['row']['state']['run']['ascension'] == runs[e['run_id']]['ascension'] for e in rows['states']))
states = {e['line']: e['row']['state'] for e in rows['states']}
def player(line): return states[line]['combat']['player']
def enemy(line, at=0): return states[line]['combat']['enemies'][at]
def power(body, name): return next((p['amount'] for p in body.get('powers', []) if p['power_id'] == name), 0)
check('K2:mirage_upgraded_zero_poison_no_block', player(293158)['block'] == player(293159)['block'] == 16 and all(power(e, 'POISON_POWER') == 0 for e in states[293158]['combat']['enemies']))
check('K2:mirage_energy_paid', player(293158)['energy'] - player(293159)['energy'] == 1)
check('K2:poison_application_only', power(enemy(292940), 'POISON_POWER') == 42 and power(enemy(292941), 'POISON_POWER') == 48 and enemy(292940)['current_hp'] == enemy(292941)['current_hp'] == 54)
check('79:poison_application_only', power(enemy(293463), 'POISON_POWER') == 4 and power(enemy(293464), 'POISON_POWER') == 10 and enemy(293463)['current_hp'] == enemy(293464)['current_hp'] == 8)
check('79:death_before_poison', states[293464]['run']['current_hp'] == 2 and player(293464)['block'] == 7 and states[293465]['run']['current_hp'] == 0 and enemy(293465)['current_hp'] == 8 and power(enemy(293465), 'POISON_POWER') == 10)

index = defaultdict(list)
for e in rows['states']:
    r = e['row']; index[(r['observed_ts'], r['fingerprint'])].append(e)
potion_pairs = []
for e in rows['decisions']:
    d = e['row']
    if e['run_id'] not in ('ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1') or (d.get('chosen') or {}).get('action') != 'use_potion': continue
    before = index.get((d.get('observed_ts'), d.get('fingerprint')), [])
    at = before[0]['line'] if len(before) == 1 else None
    after = states.get(at + 1) if at is not None else None
    match = before[0] if len(before) == 1 else None
    same = after is not None and after.get('run_id') == e['run_id'] and after['run']['floor'] == d['floor'] and after['turn'] == d['turn']
    potion_pairs.append({'run_id': e['run_id'], 'decision_line': e['line'], 'floor': d['floor'], 'turn': d['turn'], 'potion': (d.get('expect') or {}).get('potion', {}).get('id'), 'result': d.get('result'), 'before_line': at, 'after_line': at + 1 if same else None, 'before_block': player(at)['block'] if match else None, 'after_block': after['combat']['player']['block'] if same else None, 'before_plating': power(player(at), 'PLATING_POWER') if match else None, 'after_plating': power(after['combat']['player'], 'PLATING_POWER') if same else None})
iron = next(p for p in potion_pairs if p['run_id'] == 'K2JAGKVJAWZJ' and p['floor'] == 27 and p['potion'] == 'HEART_OF_IRON')
check('K2:F27_corrected_zero_immediate_block', iron['before_block'] == iron['after_block'] == 0 and iron['after_plating'] - iron['before_plating'] == 7)
check('ZTR:17_potion_requests_not_17_new_bottles', sum(p['run_id'] == 'ZTRGYYMLR8SC' for p in potion_pairs) == 17)

spec = importlib.util.spec_from_file_location('resource_chain', ROOT / 'learner/resource_chain.py')
resource = importlib.util.module_from_spec(spec); spec.loader.exec_module(resource)
resources = {}
for run_id in ('ZTRGYYMLR8SC', 'K2JAGKVJAWZJ', '79UCJ0K6R9C1'):
    frames = [{**e['row'], '_line': e['line']} for e in rows['states'] if e['run_id'] == run_id]
    sl = [e['row'] for e in rows['sl-attempts'] if e['run_id'] == run_id]
    starts = defaultdict(list)
    for s in sl:
        if s.get('attempt', 1) > 1 and s.get('started_at'): starts[s['floor']].append(s['started_at'])
    result = resource.resource_chain(frames, run_id, 'silent', starts)
    resources[run_id] = result
    (OUT / (run_id + '-resources.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

result = {'checks': checks, 'streams': streams, 'total_rows': sum(m['rows'] for m in streams), 'potion_pairs': potion_pairs,
          'resource_summary': {r: {'combats': len(d['combats']), 'missing_exits': sum(c['exit'] is None for c in d['combats'])} for r, d in resources.items()},
          'limitations': ['材料与原件逐字节/身份核验不是全部行的机制语义认证。', '药水请求和相邻帧不能独立确定整战反事实收益。', '多只同型敌人保持实体归属未知，净血池变化不当完整伤害。']}
(OUT / 'evidence-check.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'total_rows': result['total_rows'], 'resource_summary': result['resource_summary']}, ensure_ascii=False))

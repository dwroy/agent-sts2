from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,re,subprocess,sys
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-global-build-dispatch';control=r/'paper/materials/20261016-global-build-control';sha=lambda raw:hashlib.sha256(raw).hexdigest()
sys.path.insert(0,str(r/'ops'));import learning_requests as lr

def write(f,v):lr.atomic(f,v)
def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def alive(pid):
 try:os.kill(int(pid),0);return True
 except (ValueError,TypeError,OSError):return False
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
owner='01a13dcd-83d4-7c63-b233-f93cf878ecf4';parent='roy-20261016-global-build';home=(r/'ops/codex-ops/codex-home').read_text().strip();assert home==str(r/'ops/codex-ops/accounts/codex1/learner')
assert git('rev-parse','50e2da099^{commit}').decode().strip()=='50e2da099a5e1745878070ea960f3160324f2217'
send=control/'ops-start-send.json';sv=json.loads(send.read_text());assert sv['parent']==parent and sv['target']=='wJ:p5' and sv['rc']==0
message=r/sv['message'];assert sha(message.read_bytes())==sv['message_sha256']
# Only the receiving ops role acknowledges this actual turn. No watcher/user ACK is created.
write(control/'ops-received.json',dict(at=at,parent=parent,actor='ops',status='received',target='wJ:p5',original_watcher_owner=owner,original_transport=ref(send),original_message=ref(message),inputs_read=[ref(r/'paper/materials'/('20261016-global-build-'+phase)/'learner-request.md') for phase in ['g1a','g4']],actual_dispatch=False,no_other_role_ACK=True))
oldpath=r/'notes/learning-requests/roy-20261012-concrete-core-decklists.json';oldraw=oldpath.read_bytes();oldreq=json.loads(oldraw)
# Register under the original shared learning lock, using the existing native owners, leases and two slots.
with lr.locked(r/'ops/codex-ops') as state:
 oldstate=state['learning_requests'][oldreq['id']];assert oldstate['state']=='completed' and oldstate['revision']==oldreq['revision']==2 and oldstate['request_sha256']==sha(oldraw)
 records=[];new=[];leases=[]
 try:
  for phase,bid,request_id,revision in [('g1a','20261016-050119-fix-batch',parent+'-g1a',1),('g4',oldreq['original_batch'],oldreq['id'],3)]:
   stage=r/'paper/materials'/('20261016-global-build-'+phase)/'ops-dispatch';stage.mkdir(parents=True,exist_ok=True)
   assert not (stage/('input-r'+str(revision)+'.md')).exists()
   b=state['batches'][bid];tree=Path(b['worktree']);assert b['state'] in ['done','failed'] and not alive(b.get('pid'))
   assert not any(x.get('worktree')==str(tree) and x.get('state')=='running' and alive(x.get('pid')) for x in state['batches'].values())
   from learner_jobs import external_writer
   assert not external_writer(str(tree))
   lease=(r/'ops/codex-ops/learner'/(tree.name+'.lock')).open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);leases.append(lease)
   assert not git('diff','--cached','--name-only',cwd=tree).strip() and not git('status','--porcelain','--untracked-files=no',cwd=tree).strip()
   output=(r/('ops/codex-ops/learner/'+bid+'.out')).read_text();match=re.search(r'^日志：([^\n]+)',output,re.M);assert match
   log=Path(match[1]);raw=log.read_bytes();ev=[json.loads(x) for x in raw.splitlines() if x.strip()];launch=next(x for x in ev if x.get('type')=='learner_launch');thread=next(x['thread_id'] for x in ev if x.get('type')=='thread.started');assert launch['cwd']==str(tree) and launch['engine']=='codex'
   native=list((Path(home)/'sessions').glob('**/*'+thread+'.jsonl'));assert len(native)==1
   context=None
   with native[0].open('rb') as f:
    for _ in range(512):
     off=f.tell();line=f.readline()
     if not line:break
     v=json.loads(line)
     if v.get('type')=='turn_context':context=dict(source=str(native[0].relative_to(r)),offset=off,bytes=len(line),sha256=sha(line),model=v['payload'].get('model'),effort=v['payload'].get('effort'));break
   assert context and context['effort']=='xhigh'
   head=git('rev-parse','HEAD',cwd=tree).decode().strip()
   if phase=='g4':assert thread==oldreq['thread_id'] and lr.artifact(r,oldreq['original_log'])==raw
   original_req=None
   if phase=='g4':
    (stage/'prior-request-r2.json').write_bytes(oldraw);write(stage/'prior-completed-r2-state.json',oldstate);original_req=ref(stage/'prior-request-r2.json')
   original_task=r/'paper/materials'/('20261016-global-build-'+phase)/'learner-request.md'
   plan=r/'docs/v5-global-build-plan.md';requirements=control/'requirements.json';checkpoint=control/'checkpoint.json';original_manifest=control/'input-manifest.json'
   frozen={}
   for name,f in [('learner-request-original.md',original_task),('approved-plan.md',plan),('parent-requirements.json',requirements),('parent-checkpoint.json',checkpoint),('parent-input-manifest.json',original_manifest)]:
    target=stage/('r'+str(revision)+'-frozen')/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes());frozen[name]=ref(target)
   requirements_keys=([*oldreq['requirements'],'global-g4-template-core-eligibility','global-g4-r-direction-nonselection','global-g4-experience-live-consumer','global-g4-unknowns-and-objections'] if phase=='g4' else ['global-g1a-low-trust-per-boss','global-g1a-fixed-and-production-inputs','global-g1a-continuous-resource-contract','global-g1a-experience-live-consumer','global-g1a-unknowns-and-objections'])
   instructions=(f'# {parent} / {phase.upper()} 原线程接续，revision {revision}\n\nRoy 2026-10-16明确授权本次知识学习派发，批准commit50e2da099a5e1745878070ea960f3160324f2217，watcher原owner {owner}。你沿原批{bid}/thread {thread}/worktree {tree}接续；不是新研究会话，不另派子agent，不改变账号/home/模型/权限/预算。实际续跑必须gpt-6.1-sol/xhigh/default、原沙箱。\n\n'+original_task.read_text()+'\n## 冻结输入与去重\n\n'+json.dumps(frozen,ensure_ascii=False,indent=2)+'\n\n严格使用这些冻结快照和当前原角色日志的明确截止/offset/bytes/SHA；登记之后不热替输入，不借别的角色或进阶。父目标全阶段由watcher拥有；你只做本知识阶段，G1b/G1c/G2/G3/G5及通用连续Boss接口由watcher实现，不争抢其代码。游戏结论必须有本角色真实证据、反证与未知，支持/限定/否定结论均按原CLI入库和消费者读回；不能以报告/测试/退出0关闭父。\n\n复用所有已完成的原研究、校准及固定回放；不重跑原30题/54池/Jev144，不重复旧107调参/460验证的模拟，不调用额外模型/API，不另开局、不改当前对局或原0332/P0/R3冻结输入。G1a若只需读取已有校准表与实证日志即可回答，直接复用；若确需新对象，先明确对象/模型与输入差/固定边界并在原任务内形成可审计计划，不能把生产70差异抹平。\n\n现有普通策略批071301/074303仍各自消费原输入；你不改它们的文件/注册/任务，不把它们已有局部机制/资源工作复算为本阶段新研究。复用其已有交付，未交付的范围保留未知，原owner后继产物按新revision再接。\n')
   if phase=='g4':instructions+='\n旧request roy-20261012-concrete-core-decklists 的revision2及其四次接续/已完成入库与原通知原件全部保留。这是同一原核心资格学习的revision3扩展，关联新父global-build G4验收，不另造同题父。旧六requirements沿既有live经验/消费者回执复用，不能重跑旧模拟；新验收专门针对当前四候选资格和冻结231条计划中的R未选。旧五牌表候选与当前四模板身份/版本必须分列，不把任一旧候选冒充现在合格核心。原更宽roy-20261011父及其他未完父不关闭。\n'
   else:instructions+='\n沿原050119校准owner及thread续办，现有silent-calibration-92f552eada491fed1ca5c9f0/校准20/R366及676已完成通知保持原身份；这是新父global-build的G1a验收子要求，不伪造原feature的revision/ACK，不复派原周期校准。保留旧固定7e1193模型、107调参/460验证与70生产输入差，逐Boss写通过或证据/质量缺口；连续Boss已知契约给watcher，不自己重做整场/接口或用平均HP补未知联合率。\n'
   inputfile=stage/('input-r'+str(revision)+'.md');inputfile.write_text(instructions)
   req=dict(oldreq) if phase=='g4' else dict(schema='learning-request-v1',id=request_id,parent_request_id=parent,authorized_by='Roy',goal='experience-live',character='silent',original_batch=bid,worktree=str(tree.relative_to(r)),thread_id=thread,learner_home=home,original_log={'path':str(log.relative_to(r)),'sha256':sha(raw)})
   req.update(revision=revision,authorization='Roy 2026-10-16批准global-build G1a/G4知识学习，原ops实际接收；沿原owner/thread及现有两槽，不另开研究或热改在跑revision。',input={'path':str(inputfile.relative_to(r)),'sha256':sha(inputfile.read_bytes())},requirements=requirements_keys,linked_parent_requests=list(dict.fromkeys([*req.get('linked_parent_requests',[]),parent])),phase=phase.upper(),watcher_owner=owner,phase_parent_requirements=(['G4.1','G4.2','G4.3'] if phase=='g4' else ['G1a.1','G1a.2','G1a.3']),prior_revision_completed=(2 if phase=='g4' else None))
   reqpath=r/'notes/learning-requests'/(request_id+'.json');candidate=p/(request_id+'.json');write(candidate,req)
   validated,request_raw=lr.read_request(r,candidate);assert validated==req
   write(stage/('registration-r'+str(revision)+'.json'),dict(at=at,parent=parent,phase=phase.upper(),request_id=request_id,revision=revision,request_path=str(reqpath.relative_to(r)),request_sha256=sha(request_raw),input=ref(inputfile),original_batch=bid,owner_thread=thread,worktree=str(tree.relative_to(r)),worktree_head=head,learner_home=home,original_log=ref(log),original_context=context,original_request=original_req,watcher_owner=owner,stage='validated original provenance; registered for existing slots, not yet dispatched',actual_batch=None,actual_start=False,actual_model_reply=False,no_other_actor_ACK=True))
   new.append((reqpath,request_raw));records.append(dict(phase=phase.upper(),request_id=request_id,revision=revision,thread=thread,original_batch=bid,worktree=str(tree.relative_to(r)),registration=str((stage/('registration-r'+str(revision)+'.json')).relative_to(r))))
  for dest,raw in new:
   tmp=dest.with_name(dest.name+'.'+str(os.getpid())+'.tmp');tmp.write_bytes(raw);os.replace(tmp,dest)
  running=[dict(batch=k,pid=b.get('pid'),worktree=b.get('worktree'),proposal_ids=b.get('proposal_ids',[])) for k,b in state['batches'].items() if b.get('task')=='strategy-proposal' and b.get('state')=='running' and alive(b.get('pid'))]
  write(control/'ops-dispatch-registration.json',dict(at=at,parent=parent,actor='ops',watcher_owner=owner,requests=records,existing_strategy_slots=2,running_slots=running,scope='original native owners and frozen revisions, no new research session or timer; actual dispatch and first model reply require separate receipts',actual_dispatched=0,old_r2_completed_receipts_preserved=True))
 finally:
  for lease in leases:lease.close()
print(json.dumps(dict(registered=records,actual_dispatch=False,old_live_unchanged=True),ensure_ascii=False))

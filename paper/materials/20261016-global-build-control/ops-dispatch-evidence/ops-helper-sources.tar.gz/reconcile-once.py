from pathlib import Path
import datetime as dt,json,os,sys,subprocess
r=Path.cwd();sys.path.insert(0,str(r/'ops'));import learning_requests as lr
from learner_jobs import start_learner,STRATEGY_WORKERS
p=r/'ops/codex-ops/record-staging/20261016-global-build-dispatch';c=r/'paper/materials/20261016-global-build-control';d=r/'ops/codex-ops'
def alive(pid):
 try:os.kill(int(pid),0);return True
 except (OSError,ValueError,TypeError):return False
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
ids=['roy-20261016-global-build-g1a','roy-20261012-concrete-core-decklists'];drain=any((d/x).is_file() for x in ['LLM_DRAIN','ACCOUNT_DRAIN'])
with lr.locked(d) as state:
 before={key:state.get('learning_requests',{}).get(key) for key in ids};old_running=[dict(batch=k,pid=b.get('pid'),worktree=b.get('worktree')) for k,b in state['batches'].items() if b.get('task')=='strategy-proposal' and b.get('state')=='running' and alive(b.get('pid'))]
 result=None
 if not drain:result=lr.reconcile(state,r,r/'ops','silent',alive,dt.datetime.now().strftime('%Y%m%d-%H%M%S'),start_learner,STRATEGY_WORKERS)
 after={key:state.get('learning_requests',{}).get(key) for key in ids}
 stamp=dt.datetime.now().strftime('%Y%m%d-%H%M%S');path=c/('ops-existing-reconcile-'+stamp+'.json');lr.atomic(path,dict(at=at,kind='single call to existing learning_requests.reconcile under existing learn.lock; no new scheduler',slot_limit=STRATEGY_WORKERS,account_draining=drain,previous_running=old_running,dispatch_result=result,requests=after,actual_model_reply_not_inferred=True))
print(json.dumps(dict(dispatch_result=result,receipt=str(path.relative_to(r)),requests={k:{x:v.get(x) for x in ['state','revision','batch','reason']} if v else None for k,v in after.items()}),ensure_ascii=False))

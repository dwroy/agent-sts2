from pathlib import Path
import hashlib,json,os,re,subprocess,sys
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-global-build-dispatch';control=r/'paper/materials/20261016-global-build-control';sha=lambda b:hashlib.sha256(b).hexdigest();sys.path.insert(0,str(r/'ops'));import learning_requests as lr

def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
def rows(path):
 with path.open('rb') as f:
  while True:
   at=f.tell();raw=f.readline()
   if not raw:break
   try:v=json.loads(raw)
   except ValueError:continue
   yield dict(path=str(path.relative_to(r)),offset=at,bytes=len(raw),sha256=sha(raw)),v,raw
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
s=json.loads((r/'ops/codex-ops/learn.json').read_text());results=[]
for phase,ident,revision in [('g1a','roy-20261016-global-build-g1a',1),('g4','roy-20261012-concrete-core-decklists',3)]:
 dest=r/'paper/materials'/('20261016-global-build-'+phase)/'ops-dispatch';reqfile=r/'notes/learning-requests'/(ident+'.json');req,raw=lr.read_request(r,reqfile);assert req['revision']==revision
 rec=s.get('learning_requests',{}).get(ident,{});result=dict(at=at,parent='roy-20261016-global-build',phase=phase.upper(),request_id=ident,revision=revision,request_file=ref(reqfile),input=req['input'],original_owner_thread=req['thread_id'],original_owner_worktree=req['worktree'],original_batch=req['original_batch'],watcher_owner=req['watcher_owner'],scheduler_state=rec.get('state','not yet reconciled'),actual_batch=None,actual_started=False,actual_reply_received=False,other_actor_ACK_calls=0,old_revision_or_other_task_inputs_not_modified=True)
 bid=rec.get('batch');b=s['batches'].get(bid,{})
 if b.get('learning_request')==ident and b.get('learning_revision')==revision:
  result['actual_batch']=bid;result['wrapper_pid']=b.get('pid');snapshot=Path(b['learning_input']);assert sha(snapshot.read_bytes())==b['learning_input_sha256'] and snapshot.read_bytes()==raw;result['frozen_batch_input']=ref(snapshot)
  err=r/('ops/codex-ops/learner/'+bid+'.err');match=re.search(r'日志 (\S+\.jsonl)',err.read_text()) if err.exists() else None
  if match:
   eventlog=Path(match[1]);launches=[];starts=[];thread_rows=[];acks=[];last_agent=None;agent_raw=None
   for proof,v,line in rows(eventlog):
    if v.get('type')=='learner_launch':launches.append((proof,v,line))
    if v.get('type')=='learner_startup_attempt':starts.append((proof,v,line))
    if v.get('type')=='thread.started':thread_rows.append((proof,v,line))
    if v.get('type')=='item.completed' and v.get('item',{}).get('type')=='agent_message':last_agent=(proof,v);agent_raw=line
    if v.get('type')=='learner_resume_ack':acks.append((proof,v,line,last_agent,agent_raw))
   assert len(launches)==1 and launches[0][1]['cwd']==str(r/req['worktree'])
   launch=launches[0][1];cmd=launch['command'];assert launch['engine']=='codex' and cmd[1:3]==['exec','resume'] and cmd[-2:]==[req['thread_id'],'-'];assert cmd[cmd.index('--model')+1]=='gpt-6.1-sol' and 'model_reasoning_effort=\"xhigh\"' in cmd and 'service_tier=\"default\"' in cmd
   assert thread_rows and all(x[1]['thread_id']==req['thread_id'] for x in thread_rows)
   successful=[x for x in starts if x[0]['offset']<thread_rows[0][0]['offset']][-1];st=successful[1];result.update(actual_started=True,launch=launches[0][0],startup_attempt=successful[0],thread_started=thread_rows[0][0],native_event_log=str(eventlog.relative_to(r)))
   home=Path(req['learner_home']);native=list((home/'sessions').glob('**/*'+req['thread_id']+'.jsonl'));assert len(native)==1;contexts=[];user_input=[]
   for proof,v,line in rows(native[0]):
    payload=v.get('payload',{})
    if v.get('type')=='turn_context' and payload.get('cwd')==str(r/req['worktree']):contexts.append((proof,payload))
    if v.get('type')=='response_item' and payload.get('role')=='user':
     text=''.join(x.get('text','') for x in payload.get('content',[]) if x.get('type')=='input_text')
     if sha(text.encode())==st['input_sha256']:user_input.append(proof)
   assert user_input
   context=[x for x in contexts if x[0]['offset']<user_input[-1]['offset']]
   # Native turn_context may follow user input; select the latest context of the actual newly resumed turn.
   context=contexts[-1];v=context[1];assert v['model']=='gpt-6.1-sol' and v['effort']=='xhigh' and v['approval_policy']=='never' and v['sandbox_policy']['type']=='workspace-write' and v['sandbox_policy'].get('network_access') is False
   result['actual_native_context']={**context[0],**{k:v.get(k) for k in ['model','effort','approval_policy','sandbox_policy','service_tier']}};result['actual_native_user_input']=user_input[-1];result['input_sha256']=st['input_sha256'];result['command_sha256']=st['command_sha256'];result['service_tier']='default by unchanged project launcher; native optional field separately recorded'
   saved=[(launches[0][0],launches[0][2]),(successful[0],successful[2]),(thread_rows[0][0],thread_rows[0][2])]
   if acks:
    proof,ack,line,msg,msgraw=acks[0];assert ack['thread_id']==req['thread_id'] and ack['batch']==bid and ack['input_sha256']==st['input_sha256'] and ack['command_sha256']==st['command_sha256'];assert msg and sha(msg[1]['item']['text'].encode())==ack['first_message_sha256']
    result.update(actual_reply_received=True,actual_model_receipt=proof,actual_first_message=msg[0],actual_first_message_sha256=ack['first_message_sha256']);saved.extend([(msg[0],msgraw),(proof,line)])
   f=dest/('native-start-r'+str(revision)+'.jsonl');f.write_bytes(b''.join(line for _,line in saved));result['startup_original_bytes']=ref(f)
 result['scope']='Actual starter/process/native model and original-thread first agent reply are separate facts; report/live/experience/phase completion not inferred.'
 if not result['actual_started']:result['blocker']=rec.get('reason') if rec.get('state') in ['blocked','questioned'] else 'existing shared two strategy slots occupied or original owner lease unavailable; no extra worker created'
 lr.atomic(dest/('startup-r'+str(revision)+'-readback.json'),result);results.append(result)
lr.atomic(control/'ops-dispatch-readback.json',dict(at=at,parent='roy-20261016-global-build',actor='ops',requests=results,no_other_actor_ACK=True,no_new_research_or_timer=True,phase_or_parent_completed=False))
print(json.dumps([{k:x.get(k) for k in ['phase','request_id','revision','scheduler_state','actual_batch','actual_started','actual_reply_received','blocker']} for x in results],ensure_ascii=False))

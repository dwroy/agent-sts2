from pathlib import Path
import hashlib,json,subprocess,tarfile,os,sys
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261016-global-build-dispatch';control=r/'paper/materials/20261016-global-build-control';pub=control/'ops-dispatch-evidence';pub.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
def load(f):return json.loads(f.read_text())
def write(f,v):f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def ref(f):return dict(path=str(f.relative_to(r)),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
assert not (p/'own-appends.json').exists();base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
x=load(control/'ops-dispatch-readback.json');sent=load(control/'ops-dispatch-send.json');assert sent['transport_exit']==0 and sent['response']['result']['type']=='agent_prompted'
assert len(x['requests'])==2 and all(v['actual_started'] and v['actual_reply_received'] for v in x['requests'])
state=load(r/'ops/codex-ops/learn.json');liveness=[]
for result in x['requests']:
 bid=result['actual_batch'];b=state['batches'][bid];assert b['learning_request']==result['request_id'] and b['learning_revision']==result['revision'] and b['state']=='running'
 proc=Path('/proc')/str(b['pid']);stat=(proc/'stat').read_text();birth=stat[stat.rfind(')')+2:].split()[19];liveness.append(dict(batch=bid,pid=b['pid'],birth=birth,program=(proc/'comm').read_text().strip(),worktree=b['worktree'],request_id=b['learning_request'],revision=b['learning_revision']))
 reqpath=r/result['request_file']['path'];assert sha(reqpath.read_bytes())==result['request_file']['sha256'];snapshot=Path(b['learning_input']);assert sha(snapshot.read_bytes())==b['learning_input_sha256']==result['request_file']['sha256'];assert snapshot.read_bytes()==reqpath.read_bytes()
 for key in ['input']:
  v=result[key];assert sha((r/v['path']).read_bytes())==v['sha256']
 for key in ['actual_model_receipt','actual_first_message','actual_native_context','actual_native_user_input']:
  v=result[key];f=r/v['path']
  with f.open('rb') as handle:handle.seek(v['offset']);raw=handle.read(v['bytes']);assert sha(raw)==v['sha256']
active=[bid for bid,b in state['batches'].items() if b.get('task')=='strategy-proposal' and b.get('state')=='running' and Path('/proc',str(b.get('pid'))).exists()];assert len(active)==2 and set(active)=={v['actual_batch'] for v in x['requests']}
write(pub/'runtime-and-freeze-verification.json',dict(at=at,actual_active_strategy_batches=active,unchanged_slot_limit=2,original_owner_processes=liveness,model='gpt-6.1-sol',effort='xhigh',service='default via actual command tokens',sandbox='existing workspace-write network false, no permission changes',actual_model_reply_and_learner_resume_ack_verified=True,frozen_snapshot_request_input_exact=True,no_live_or_account_home_model_prompt_budget_changes=True))
write(control/'ops-coordination.json',dict(at=at,parent=x['parent'],actor='ops',owner='01a13dcd-83d4-7c63-b233-f93cf878ecf4',knowledge_requests=[{k:v[k] for k in ['phase','request_id','revision','original_owner_thread','actual_batch','actual_started','actual_reply_received']} for v in x['requests']],dispatch_state='both actually resumed and replied',G1a_G4_completion=False,G1b_S_choice='Roy only; pending, no unilateral rollback',G1c_every10='await original watcher exact tool delivery; integrate existing cadence after source publication, no ops prompt or new timer',future_behavior_stages='original serial live lock, independent behavior release IDs, dual notification and exact-tree host per actual stage; no current publication',old_completed_revision2='preserved in G4 ops-dispatch/prior-request-r2.json and prior-completed-r2-state.json; new r3 links global G4',other_parents='old0332/calibration/R2/R3 and quantitative parents remain unchanged',watcher_transport='sent to existing native owner, read or ACK not inferred',delivery_receipt='paper/materials/20261016-global-build-control/ops-dispatch-send.json'))
note=f'\n- {at} [ops global-build G1a/G4已真实接续] 已本人实收Roy批准父roy-20261016-global-build、watcher01a13dcd-83d4-7c63-b233-f93cf878ecf4原请求，原批准50e2da099。先查原两槽/旧父/owner lease与原日志thread/home，未热改071301/074303在跑输入；两槽自然释放后用既有learning_requests.reconcile/learn.lock和原owner lease实际续跑。G1a request roy-20261016-global-build-g1a r1，原050119校准thread01a1415e-a511-7131-be7c-a2dc691c847f/.worktrees/silent-boss-calibration，实际batch20261016-075726-strategy-proposal/PID1153952；G4复用roy-20261012-concrete-core-decklists升r3，原thread01a12eba-13a8-7550-ac47-692d3d19bed1/.worktrees/codex-strategy-silent-20261012-140741，实际batch20261016-075639-strategy-proposal/PID1146307，不另造同题父，旧r2完成/六验收与输入/通知原件另冻保留。两个新request/input SHA、batch.learning-input、exec resume真实thread.started/原生用户输入/实际Sol6.1-xhigh-default/原沙箱无网络及首条模型回复/learner_resume_ack逐offset/bytes/SHA核，已实际启动并实收，非仅排队。冻结材料分别在G1a/G4 ops-dispatch，汇总paper/materials/20261016-global-build-control/ops-dispatch-readback.json；首轮私有读回错误使用不存在launch.resume_thread字段，保失败并改核真实exec resume命令/模型，不当产品故障。原G1a固定7e1193/107/460与70生产差、连续资源unknown和G4当前四模板/R未选证据边界写入冻结输入；不重跑旧30/54/Jev144/已完校准或源full，不派新研究/计时器/辅助，不抢watcher接口/G1b/G1c/G2/G3/G5。已经Herdr向原wJ:pJT/01a13dcd发送真实派发回执transport0，不能冒watcher已读/用户ACK。学习阶段/父仍active，异议按原ops→watcher→Roy链；G1b的S去留仅Roy决定，G1c待精确工具源再接每10完局，无prompt修改；未来行为按原锁独立编号/根双通知/精确宿主。未改当前局/live代码/账号home模型权限prompt预算、版本表或旧0332/其他宽父，无新未变树full。\n'
decision=f'\n- {at} 运维codex：Roy授权global-build知识阶段已沿现有原生owner与两槽真实派发并读回首回复。G1a注册roy-20261016-global-build-g1a/r1→原050119/thread01a1415e-a511-7131-be7c-a2dc691c847f、实际075726-strategy-proposal/PID1153952；G4为原roy-20261012-concrete-core-decklists/r3→原140741/thread01a12eba-13a8-7550-ac47-692d3d19bed1、实际075639-strategy-proposal/PID1146307，同题不另造父，旧r2 completed请求/状态/六验收单列冻结、宽旧父保留。两个策略槽自然释放后既有reconcile/learn.lock/原lease接续，未扩槽/新研究或热改在跑输入；每个冻结request/input与batch snapshot、原exec resume/thread.started、native Sol6.1/xhigh/default/原沙箱无网与真实agent_message/learner_resume_ack字节SHA逐项核。接收ACK仅本ops，原watcher回传transport0不当其已读/Roy ACK。G1a逐低可信Boss/缺口和学习者确认连续资源契约、旧固定107/460与70生产差分列；G4四候选核心资格/R未选原231计划、持有/施放/存活/通关分账与未知均冻结，旧模拟/全检不重跑，接口/其他阶段由watcher承担，不改游戏知识。私有读回首轮launch字段假设失败保原件，按真实命令身份修正后两个实收核验0；非产品故障。新阶段和父未完成，S去留Roy待定，G1c精确源到后接原每10完局归档、各行为阶段再原锁编号/双通知/宿主；当前局/home账号模型权限prompt预算/live与版本不动。回执paper/materials/20261016-global-build-control/ops-dispatch-readback.json及各阶段ops-dispatch/。\n'
handoff=f'\n- {at} 新父roy-20261016-global-build知识接续：watcher仍01a13dcd，原ops已真实接收与登记并回原wJ:pJT运输，非其他角色ACK。G1a roy-20261016-global-build-g1a r1/original050119/thread01a1415e-a511-7131-be7c-a2dc691c847f→实际20261016-075726-strategy-proposal；G4复用roy-20261012-concrete-core-decklists升r3/original140741/thread01a12eba-13a8-7550-ac47-692d3d19bed1→实际20261016-075639-strategy-proposal。两旧槽自然释放后在同2槽/原lease正常running，原生Sol6.1/xhigh/default/原沙箱、冻结request/input/batch SHA及首条回复+learner_resume_ack已核；阶段目录ops-dispatch/startup-r1-readback.json、startup-r3-readback.json，control/ops-dispatch-readback.json汇总。旧r2完成/验收冻结保留，新G4扩展不重做旧六项/模拟，其他宽父与0332保持；原owner输入不可热替，补充须revision。后继只接原学习完成/质疑通知链，不因退出/报告或固定读回关闭新父；G1b S去留Roy决定，G1c待原工具源后接每10完局（无新timer/prompt），G2/3/5各行为原锁独立号/双通知/精确树宿主。没有本目标新增研究会话/辅助、无未改树full或对局/home账号模型权限prompt预算改动。\n'
appends={'ops/inbox-dev.md':note,'notes/for-roy.md':note,'paper/materials/decision-log.md':decision,'notes/ops-handoff.md':handoff};write(p/'own-appends.json',appends)
values={}
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
 values[path]=git('show',base+':'+path)+text.encode()
for v in x['requests']:
 f=r/v['request_file']['path'];values[str(f.relative_to(r))]=f.read_bytes()
for phase in ['g1a','g4']:
 for f in (r/'paper/materials'/('20261016-global-build-'+phase)/'ops-dispatch').rglob('*'):
  if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
control_names=['ops-received.json','ops-dispatch-registration.json','ops-dispatch-readback.json','ops-dispatch-message.txt','ops-dispatch-transport.stdout','ops-dispatch-transport.stderr','ops-dispatch-send.json','ops-coordination.json']
for f in [control/n for n in control_names]+list(control.glob('ops-existing-reconcile-*.json')):
 assert f.is_file();values[str(f.relative_to(r))]=f.read_bytes()
write(pub/'record-registration.json',dict(at=at,base=base,parent=x['parent'],requests=[{k:v[k] for k in ['phase','request_id','revision','original_owner_thread','actual_batch','actual_started','actual_reply_received']} for v in x['requests']],native_model='Sol6.1/xhigh/default actually verified',source_code_changed=False,tests='record-only; no unchanged full repeated',new_research_sessions=0,new_timers=0,other_actor_ACK_calls=0,game_or_account_changes=False,phase_or_parent_complete=False))
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 helpers=[]
 for f in sorted(p.glob('*.py')):tar.add(f,arcname=f.name,recursive=False);helpers.append(ref(f))
write(pub/'ops-helper-manifest.json',helpers)
with tarfile.open(pub/'ops-attempt-logs.tar.gz','w:gz') as tar:
 for name in ['register.log','reconcile-once.log','reconcile-remaining-g1a.log','start-readback-first-launch-field-assertion.log','start-readback.log','notify-watcher.log']:
  f=p/name;tar.add(f,arcname=name,recursive=False)
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries))
scan=p/'archive-scan';scan.mkdir(exist_ok=True)
for f in pub.glob('*.tar.gz'):
 out=scan/f.stem;out.mkdir(exist_ok=True)
 with tarfile.open(f) as tar:
  assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in tar.getmembers());tar.extractall(out,filter='data')
print(json.dumps(dict(record_paths=len(entries),real_continuations=2,real_first_replies=2,new_research_sessions=0,phases_complete=False,base=base)))

"""Audit a bounded SL/potion question using existing frozen indices and selected raw rows."""
import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
FROZEN = ROOT / 'paper/materials/20261016-f48-f49'
LEAN = ROOT / 'paper/materials/20261016-v5s-regression-diagnosis/inputs-lean'
SELECTED = {'9KP5S3317EEL', 'RQCHNN0W72KF', 'TCDUBRWMEMNA', 'VNSXWCWXR3VW', 'DHYFWEN40SJ7', 'JWK2C8LE4SFV'}


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stamp(value):
    parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    return parsed.replace(tzinfo=dt.timezone.utc).timestamp() if parsed.tzinfo is None else parsed.timestamp()


freeze = json.loads((FROZEN / 'freeze.json').read_text())
lean_manifest = json.loads((LEAN / 'manifest.json').read_text())
dependencies = []
for name in ['frames.jsonl.gz', 'decisions.jsonl.gz']:
    path = LEAN / name
    expected = next(i for i in lean_manifest['files'] if i['path'] == 'inputs-lean/' + name)
    raw = path.read_bytes()
    assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes']
    dependencies.append({'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)})
write('index-dependencies.json', dependencies)

handles, read_rows = {}, {}


def load(ref, run=None):
    name = ref['path']
    assert name.startswith('logs/') and name.endswith('.jsonl')
    off, length = ref['off'], ref['len']
    assert off + length <= freeze['source_bounds'][Path(name).stem]['complete_prefix_bytes']
    key = (name, off)
    if key in read_rows:
        return read_rows[key]['row']
    source = handles.setdefault(name, (ROOT / name).open('rb'))
    source.seek(off)
    raw = source.read(length)
    digest = sha(raw)
    if 'sha256' in ref:
        assert digest == ref['sha256']
    row = json.loads(raw)
    identities = {x for x in [row.get('run_id'), (row.get('state') or {}).get('run_id')] if x}
    if run:
        assert identities == {run}, (name, off, identities, run)
    if 'state' in row:
        assert (row['state'].get('run') or {}).get('character_id', '').lower() == 'silent'
    read_rows[key] = {'source': {'path': name, 'off': off, 'len': length, 'sha256': digest}, 'row': row}
    return row


attempts = list(csv.DictReader((ROOT / 'paper/materials/20261016-2219-ops/inputs/attempts.csv').open()))
retries = list(csv.DictReader((ROOT / 'paper/materials/20261016-2219-ops/inputs/retries.csv').open()))
assert len(attempts) == 212 and len(retries) == 114
aggregate = []
for cohort in ['pre', 'post']:
    for floor in [None, 17, 33, 48, 49]:
        rows = [r for r in retries if r['cohort'] == cohort and (floor is None or int(r['floor']) == floor)]
        aggregate.append({'cohort': cohort, 'floor': floor, 'retry_attempts': len(rows),
                          'run_floor_count': len({(r['run_id'], r['floor']) for r in rows}),
                          'schedule_changed': sum(r['potion_schedule_diff_vs_first'] == 'True' for r in rows),
                          'empty_drink_schedule': sum(json.loads(r['potions']) == [] for r in rows),
                          'same_schedule_but_changed_plays': sum(r['potion_schedule_diff_vs_first'] == 'False' and
                            bool(r['first_actual_turn_diff_vs_first']) for r in rows)})
write('csv-derived-counts.json', aggregate)

with gzip.open(FROZEN / 'inputs/sl.original.jsonl.gz', 'rt') as source:
    sl = [json.loads(line) for line in source]
selected = [s for s in sl if s['run_id'] in SELECTED and s['floor'] in [48, 49]]
assert len(selected) == 47
verified = []
for s in selected:
    row = load(s['_source'], s['run_id'])
    assert {k: row[k] for k in row} == {k: s[k] for k in row}
    events = []
    for turn in (row.get('summary') or {}).get('turns', []):
        for index, action in enumerate(turn['plays']):
            if action.startswith('potion '):
                events.append({'turn': turn['turn'], 'within_turn_index': index, 'action': action,
                               'preceding_actions': turn['plays'][:index]})
    verified.append({'run_id': s['run_id'], 'floor': s['floor'], 'attempt': s['attempt'],
                     'result': row['result'], 'turns': row['turns'], 'end_hp': row.get('end_hp'),
                     'summary_schedule': row['summary']['potions'], 'ordered_events': events,
                     'reload': row.get('reload'), 'source': s['_source']})
write('selected-sl-observations.json', verified)

frames = collections.defaultdict(list)
by_time = collections.defaultdict(list)
with gzip.open(LEAN / 'frames.jsonl.gz', 'rt') as source:
    for line in source:
        f = json.loads(line)
        if f['run_id'] in SELECTED and f['floor'] in [48, 49] and f.get('observed') is not False:
            f['_time'] = stamp(f.get('observed_ts') or f['ts'])
            frames[(f['run_id'], f['floor'])].append(f)
            by_time[(f['run_id'], f['_time'])].append(f)
for rows in frames.values():
    rows.sort(key=lambda x: (x['_time'], x['off']))


def state_ref(f):
    return {'path': 'logs/states.jsonl', 'off': f['off'], 'len': f['len']}


def describe(row):
    s = row['state']
    combat = s.get('combat') or {}
    return {'run_id': s['run_id'], 'floor': s['run']['floor'], 'turn': s.get('turn'), 'screen': s.get('screen'),
            'hp': (combat.get('player') or {}).get('current_hp', s['run'].get('current_hp')),
            'potions': s['run'].get('potions', []), 'player': combat.get('player'),
            'hand': combat.get('hand', []), 'enemies': combat.get('enemies', [])}


boundaries = []
with gzip.open(FROZEN / 'inputs/resource-boundary-frames.jsonl.gz', 'rt') as source:
    for line in source:
        b = json.loads(line)
        if b['run_id'] in SELECTED and b['floor'] in [48, 49]:
            row = load(b['source'], b['run_id'])
            boundaries.append({'source': b['source'], **describe(row)})
write('selected-boundary-states.json', boundaries)

actions = []
with gzip.open(LEAN / 'decisions.jsonl.gz', 'rt') as source:
    for line in source:
        d = json.loads(line)
        if d['run_id'] not in SELECTED or d.get('floor') not in [48, 49] or d.get('chosen', {}).get('action') != 'use_potion':
            continue
        row = load(d['_source'], d['run_id'])
        before = by_time.get((d['run_id'], stamp(d['observed_ts'])), [])
        exact = []
        for f in before:
            state = load(state_ref(f), d['run_id'])
            if state['fingerprint'] == row['fingerprint']:
                exact.append(f)
        assert exact, (d['run_id'], d['decision_id'])
        pre = exact[-1]
        start = load(state_ref(pre), d['run_id'])
        chosen = row['chosen']
        slot = chosen.get('option_index')
        bottle = next((p for p in start['state']['run']['potions'] if p['index'] == slot), None)
        assert bottle is not None and bottle['occupied'] and bottle['can_use'] is True
        later = [f for f in frames[(d['run_id'], d['floor'])] if f['_time'] > pre['_time']]
        after = later[:2]
        snapshots = []
        for f in after:
            state = load(state_ref(f), d['run_id'])
            snapshots.append({'source': read_rows[('logs/states.jsonl', f['off'])]['source'], **describe(state)})
        actions.append({'run_id': d['run_id'], 'floor': d['floor'], 'attempt': row.get('sl_attempt'),
                        'turn': d['turn'], 'observed_ts': d['observed_ts'], 'source': d['_source'],
                        'decision_id': d['decision_id'], 'chosen': chosen, 'result': row['result'],
                        'rationale': row.get('rationale'), 'slot_before': bottle,
                        'before': {'source': read_rows[('logs/states.jsonl', pre['off'])]['source'], **describe(start)},
                        'following_observations': snapshots})
write('potion-actions-and-slots.json', actions)

write('raw-source-index.json', [i['source'] for i in read_rows.values()])
with gzip.open(HERE / 'selected-raw-evidence.jsonl.gz', 'wt') as out:
    for item in read_rows.values():
        out.write(json.dumps(item, ensure_ascii=False) + '\n')
write('bounded-summary.json', {'selected_runs': sorted(SELECTED), 'sl_attempts': len(verified),
                              'boundaries': len(boundaries), 'potion_dispatches': len(actions),
                              'verified_raw_rows': len(read_rows),
                              'all_drinks_held_and_legally_usable': True,
                              'scope': 'six named runs, F48/F49 only; same immutable cutoff; not a causal comparison'})
print((HERE / 'bounded-summary.json').read_text())

# SL用药机会与真实兑现的限定经验发布

请求roy-20261016-sl-potion-retry/r1，原线程01a144f3-f753-7881-afd9-9567174ea8e3。外层任务strategy-proposal；本接续执行经验更新阶段，CLI source_task=experience-update、target_task=strategy-proposal。旧四宽提案08eaa60bcc449852/92920295a648b540/f1374df72d8e6a25/7f820c02d39bfaea及旧报告原样保留，不把本限定交付当其整战反事实完成。

角色silent，仅A10。账本silent-0498、silent-0253；经验silent-sl-potion-retry-opportunity、silent-speed-potion-temporary-dexterity。授权Roy-2026-10-07-learning及Roy22:19，不把观察假设当结论。

## 冻结证据与方法

输入ab37a615be5f146a61c9c4943db0fba9596d8d15325da27102d43f64d6f3bee1，manifest3f006f6af62dcaca1ec34d6b1eb5273e7c62c50344c2bb74202ffd23dc39a777，原17:15:44截点/49局/98场/212尝试。先核冻结文件SHA，复用两原索引；只读六例局F48/F49的47条SL原行、94边界、47个真实饮药动作和对应前后帧，共319行逐offset/len/SHA/身份核验，未做全历史抽取或原脚本重跑。CSV投影计数保原114重试，19/58→7/56及F48/F49子计数不改；SL相关分支不作独立局。全部材料见selected-sl-observations.json、potion-actions-and-slots.json、selected-boundary-states.json与raw-source-index.json。

## 新发现、反例与限制

VNSXWCWXR3VW F49六试实际肌肉T1、速度T2；原冻结报告称两药T1是摘要笔误，原稿不覆盖。速度前动作数4/3/1/1/2/1；首试饮前2HP/0能/10挡，敏1→6、旧挡仍10，T3已无药敏。第2/5试余1能，后空翻+13→27；第3/4/6试后空翻0→11。原药名+回合比较保持相同，却有真实同轮牌药前后差异；不能据它认完全没改药时。相关动作/状态已持有且can_use=true，当前能力、手牌及能量按原帧核，不从候选模拟填实打。全六试失败、牌序/抽牌/入轮HP也变化，新增挡不全部归药，不能称早喝救局。

后段F49二十重试：9KP5S3317EEL与RQCHNN0W72KF各五次、合十次空药；TCDUBRWMEMNA五次仅石头、VNS五次持肌肉/速度。只是四个run/floor，不是二十个独立可换药机会。空栏不能解释为拒绝留药；9KP F48第四胜3血、RQ首胜4血到空药F49六败，缺留药也可过F48的整战对照。

TCD F48第二试铁心T1、石头延T2仍败，其他牌亦变；第五试石头回T1首胜6血，后战仍败，不能归单一药时。TCD/VNS在F48饮过名称在F49仍有同名槽位，不能倒填未消费或保留同一瓶；逐槽前后实变与SL恢复另账，来源不全则未知。DHY/JWK F48各六试均T1毒、后续牌线确变但全败，未有改药时的实胜反事实。

## 旧行为与本次新行为

旧知识已有临时敏捷不补旧挡、连战实际资源结转、不凭饱和死率忽略血价。只去重补速度经验VNS一局支持（57→58，旧57局/反例/范围保留），新增一条SL用药机会的限定说明；不新增出牌/用药/必死/SL阈值或自动动作，不认换药或留药因果。铁甲及其他角色文件不变；新泛药水条目仅A10，速度追加案例也明确A10。

## 拟合、验证、交付和回退

没有自由参数拟合、A/B或模拟。冻结样本是发现/固定读回集，未来收益须独立run后移验证；同局SL不拆训练与验证。数据前后只一更新/一新增，其余236条逐对象保持。运行实际loadExperience/loadKnowledgeData与全经验renderExperience，核两条真实文本/hash、A10适用和新条目A9排除，保存探针输入/输出/源码SHA；实际live再跑同探针。仅数据变化，tsc/vitest不伪造新成功，也不重跑未变源full。

实际发布沿live锁、先查刷新及重叠；版本登记后交ops统一核release_id，双通知包括异议原文，ops/watcher/Roy各自ACK，学习者不代填。旧规则门槛不变；回退仅撤新条目及速度本次追加/新支持局，保并行知识与旧57局，并另记真实行为回退号。整战胜率与自然消费者采用保持未知。

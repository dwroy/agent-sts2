import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const [root, output, expectedFile] = process.argv.slice(2);
assert(root && output && expectedFile);
const expected = JSON.parse(readFileSync(expectedFile, 'utf8'));
const hash = value => createHash('sha256').update(value).digest('hex');
const canonical = value => value === null || typeof value !== 'object' ? JSON.stringify(value)
  : Array.isArray(value) ? `[${value.map(canonical).join(',')}]`
    : `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
const load = path => import(pathToFileURL(join(root, path)).href);

// Select the character before importing any loader that can cache character data.
const files = await load('agent/src/knowledge/files.ts');
files.setKnowledgeCharacter('silent');
const { loadExperience } = await load('agent/src/knowledge/experience.ts');
const { loadKnowledgeData } = await load('agent/src/knowledge/render/data.ts');
const { activeLessons, renderExperience, appliesAt } = await load('agent/src/knowledge/render/experience-text.ts');
const dir = join(root, 'knowledge');
const fromLoader = loadExperience(dir);
const data = loadKnowledgeData(dir);
assert.equal(data.experience.version, expected.version);
const active = activeLessons(data, 10);
const postmortems = { path: 'omitted-by-fixed-consumer', sections: null,
  missing: '本探针仅验证经验读取，不载入复盘正文' };
const rendered = renderExperience({ knowledgeDir: dir, ascension: 10, facts: text => text }, postmortems);
const targets = [];
for (const ref of expected.coverage_refs) {
  const actual = data.experience.entries.find(entry => entry.id === ref.id);
  assert(actual);
  assert.equal(hash(canonical(actual)), ref.sha256);
  assert.deepEqual(fromLoader.find(entry => entry.id === ref.id), actual);
  assert(active.some(entry => entry.id === ref.id));
  assert(rendered.includes(actual.id) && rendered.includes(actual.lesson));
  assert(actual.evidence.includes('VNSXWCWXR3VW'));
  targets.push({ id: actual.id, sha256: ref.sha256, lesson: actual.lesson,
    evidence: actual.evidence, activeAt10: appliesAt(actual, 10), activeAt9: appliesAt(actual, 9) });
}
const bounded = targets.find(entry => entry.id === 'silent-sl-potion-retry-opportunity');
assert.equal(bounded.activeAt9, false);
assert(!activeLessons(data, 9).some(entry => entry.id === bounded.id));
assert(bounded.lesson.includes('肌肉T1、速度T2') && bounded.lesson.includes('收益未知'));
const timing = targets.find(entry => entry.id === 'silent-speed-potion-temporary-dexterity');
assert(timing.lesson.includes('0能已有10挡') && timing.lesson.includes('六败'));
// Role isolation is checked by the resolved path, without reading another role's private knowledge.
assert.notEqual(files.knowledgeFile(dir, 'experience.json', 'ironclad'), files.knowledgeFile(dir, 'experience.json', 'silent'));
const sourcePaths = ['agent/src/knowledge/files.ts', 'agent/src/knowledge/experience.ts',
  'agent/src/knowledge/render/data.ts', 'agent/src/knowledge/render/experience-text.ts'];
writeFileSync(`${output}.rendered.txt`, rendered);
writeFileSync(`${output}.json`, `${JSON.stringify({ root, character: files.knowledgeCharacter(),
  experience_version: data.experience.version,
  experience_file_sha256: hash(readFileSync(files.knowledgeFile(dir, 'experience.json'))),
  active_count: active.length, targets, new_entry_excluded_at9: true, role_path_isolated: true,
  rendered_sha256: hash(Buffer.from(rendered)),
  source_files: sourcePaths.map(path => ({ path: join(root, path), sha256: hash(readFileSync(join(root, path))) })),
  checks: ['loader', 'data', 'full-text', 'canonical-hash', 'ascension', 'role-path'],
  status: 'passed', meaning: '实际加载和完整文本渲染；不证明自然采用或胜率改善' }, null, 2)}\n`);
console.log(JSON.stringify({ experience_version: data.experience.version, targets: targets.map(entry => entry.id),
  new_entry_excluded_at9: true, active_count: active.length, status: 'passed' }));

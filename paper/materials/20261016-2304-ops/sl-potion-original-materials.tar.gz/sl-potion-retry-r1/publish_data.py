"""Publish only the reviewed data commit, preserving the live worktree's unrelated history and changes."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[3]
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
FILE = 'knowledge/characters/silent/experience.json'
SOURCE = '4f501afaf8059c3355dade9aeeac2c910fd12fad'
NAME = 'V5.silent-sl-potion-retry-knowledge1'
NODE = Path.home() / '.local/node/bin/node'


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git(where, *args, **kwargs):
    return subprocess.check_output(['git', '-C', str(where), *args], **kwargs)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


with (ROOT / 'ops/live-merge.lock').open('a') as lock:
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print('live lock busy; no mutation', file=sys.stderr)
        sys.exit(75)
    if subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
        print('knowledge builder still running; no mutation', file=sys.stderr)
        sys.exit(75)
    assert git(WORK, 'rev-parse', 'HEAD').decode().strip() == SOURCE
    assert git(WORK, 'diff-tree', '--no-commit-id', '--name-only', '-r', SOURCE).decode().splitlines() == [FILE]
    assert git(LIVE, 'diff', '--cached', '--name-only').strip() == b''
    before = git(LIVE, 'rev-parse', 'HEAD').decode().strip()
    agent_tree = git(LIVE, 'rev-parse', 'HEAD:agent').decode().strip()
    status = git(LIVE, 'status', '--porcelain=v1').decode()
    changed = git(LIVE, 'diff', '--name-only', '--', 'knowledge', 'notes/fight-value-backtest.md').decode().splitlines()
    # A concurrent data owner or refresher must be handled before taking this immutable preimage.
    if changed:
        write('live-refresh-overlap.json', {'head': before, 'changed': changed, 'mutation': False})
        raise RuntimeError('live knowledge refresh is dirty; preserve it for ops, do not overwrite')
    preimage = git(WORK, 'show', SOURCE + '^:' + FILE)
    current = (LIVE / FILE).read_bytes()
    assert current == preimage, 'live experience is no longer the reviewed preimage'
    dirty_before = {}
    for path in git(LIVE, 'diff', '--name-only').decode().splitlines():
        dirty_before[path] = sha((LIVE / path).read_bytes())
    patch = git(WORK, 'diff', '--binary', SOURCE + '^', SOURCE, '--', FILE)
    (HERE / 'published-data.patch').write_bytes(patch)
    checked = subprocess.run(['git', '-C', str(LIVE), 'apply', '--check', '-'], input=patch, capture_output=True)
    assert checked.returncode == 0, checked.stderr.decode()
    write('live-prepublication.json', {'head': before, 'agent_tree': agent_tree, 'status': status,
                                     'experience_preimage_sha256': sha(current), 'dirty_files': dirty_before,
                                     'method': 'single data commit cherry-pick; whole-history merge conflicts preserved in dry preflight',
                                     'source': SOURCE})
    picked = subprocess.run(['git', '-C', str(LIVE), 'cherry-pick', SOURCE], capture_output=True, text=True)
    (HERE / 'live-cherry-pick.stdout.txt').write_text(picked.stdout)
    (HERE / 'live-cherry-pick.stderr.txt').write_text(picked.stderr)
    assert picked.returncode == 0, picked.stderr
    merged = git(LIVE, 'rev-parse', 'HEAD').decode().strip()
    assert (LIVE / FILE).read_bytes() == (WORK / FILE).read_bytes()
    assert git(LIVE, 'diff', '--name-only', before, merged).decode().splitlines() == [FILE]
    assert git(LIVE, 'rev-parse', 'HEAD:agent').decode().strip() == agent_tree
    for path, digest in dirty_before.items():
        assert sha((LIVE / path).read_bytes()) == digest
    args = [str(NODE), '--import', str(LIVE / 'agent/node_modules/tsx/dist/loader.mjs'),
            str(HERE / 'consumer-probe.mjs'), str(LIVE), str(HERE / 'live-consumer'), str(HERE / 'experience-change.json')]
    with (HERE / 'live-consumer.stdout.txt').open('w') as out, (HERE / 'live-consumer.stderr.txt').open('w') as err:
        result = subprocess.run(args, cwd=LIVE / 'agent', stdout=out, stderr=err)
    write('live-consumer-command.json', {'argv': args, 'cwd': str(LIVE / 'agent'), 'exit_code': result.returncode})
    if result.returncode:
        reverted = subprocess.run(['git', '-C', str(LIVE), 'revert', '--no-edit', merged], capture_output=True, text=True)
        write('failed-consumer-rollback.json', {'published': merged, 'revert_exit': reverted.returncode,
                                              'stdout': reverted.stdout, 'stderr': reverted.stderr})
        raise RuntimeError('live consumer failed; bounded data revert attempted')
    date = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
    print(date)
    versions_path = LIVE / 'eval/versions.json'
    versions = json.loads(versions_path.read_text())
    assert not any(v.get('name') == NAME for v in versions['versions'])
    versions['versions'].append({'name': NAME, 'family': 'V5', 'character': 'SILENT', 'commit': merged,
        'release_status': 'awaiting-primary-ops-numbering',
        'source': date + '; roy-20261016-sl-potion-retry/r1, source ' + SOURCE +
        '. Data only: one A10 SL/potion opportunity qualification and VNS timing added to the existing Speed Potion lesson. '
        'Same turn/drug labels omit within-turn ordering; empty belts are not legal alternative potion opportunities. '
        'No causal win claim, potion price, survival/300-sample/SL threshold or source change. '
        'Experience 2026-10-16.4, ledger silent-0498/0253, proposal silent-proposal-4e4385b2f64bd66e. '
        'Actual live loader/full-render fixed consumer passed; natural adoption/effect and ops/watcher/Roy delivery pending. '
        'Primary ops must allocate the formal release_id under the existing lock; learner did not assign one.'})
    versions_path.write_text(json.dumps(versions, ensure_ascii=False, indent=2) + '\n')
    log = LIVE / 'paper/materials/decision-log.md'
    with log.open('a') as out:
        out.write('\n- ' + date + ' 静默学习者原214302线程承接roy-20261016-sl-potion-retry/r1：源' + SOURCE +
                  '单文件知识提交安全摘入live ' + merged + '，经验2026-10-16.4；新增SL用药机会限定、速度经验追加VNS。'
                  '证据VNSXWCWXR3VW F49T2、TCDUBRWMEMNA F48T1/T2及RQCHNN0W72KF/9KP5S3317EEL F49空药；'
                  '账本silent-0498/0253、提案silent-proposal-4e4385b2f64bd66e。实帧319行/12材料检查及live实际加载全渲染0；'
                  'VNS报告两药T1勘误为肌肉T1/速度T2，粗药事件相同不等同轮时点相同。'
                  '无源码或药价/SL门槛变化、不造tsc/vitest；alias ' + NAME + '待主ops持锁核正式编号，不预认release_id。'
                  '固定读取不等自然采用/收益；原四宽提案、0332及量化父保持，异议双通知待ops→watcher→Roy各角色本人回执。\n')
    for path in [versions_path, log]:
        scan = subprocess.run(['gitleaks', 'dir', str(path), '--no-banner', '--redact', '--log-level', 'error'], capture_output=True, text=True)
        (HERE / ('gitleaks-live-' + path.name + '.log')).write_text(scan.stdout + scan.stderr)
        assert scan.returncode == 0
    subprocess.run(['git', '-C', str(LIVE), 'add', 'eval/versions.json', 'paper/materials/decision-log.md'], check=True)
    message = 'Record qualified Silent SL potion knowledge publication\n\nActual data source ' + merged + \
        '; formal release numbering remains with primary ops.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
    (HERE / 'live-record-message.txt').write_text(message)
    recorded = subprocess.run(['git', '-C', str(LIVE), 'commit', '-F', str(HERE / 'live-record-message.txt')], capture_output=True, text=True)
    (HERE / 'live-record.stdout.txt').write_text(recorded.stdout)
    (HERE / 'live-record.stderr.txt').write_text(recorded.stderr)
    assert recorded.returncode == 0, recorded.stderr
    after = git(LIVE, 'rev-parse', 'HEAD').decode().strip()
    assert subprocess.run(['git', '-C', str(LIVE), 'merge-base', '--is-ancestor', merged, after]).returncode == 0
    for path, digest in dirty_before.items():
        assert sha((LIVE / path).read_bytes()) == digest
    write('live-publication.json', {'source_commit': SOURCE, 'merged': merged, 'before': before, 'record_commit': after,
                                  'experience_version': '2026-10-16.4', 'experience_sha256': sha((LIVE / FILE).read_bytes()),
                                  'consumer_exit_code': result.returncode, 'alias': NAME, 'release_id': None,
                                  'release_numbering': 'awaiting primary ops', 'agent_tree_unchanged': True,
                                  'unrelated_dirty_files_preserved': dirty_before})
    print((HERE / 'live-publication.json').read_text())

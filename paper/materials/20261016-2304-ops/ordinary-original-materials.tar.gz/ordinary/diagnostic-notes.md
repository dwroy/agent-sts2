# 本批只读探针记录

开始时 git status --short 为空；git merge --no-edit main 返回 Already up to date，HEAD=c1b9aa1fd377f18b41e479eb90cb7cd55f503786。

首轮派发表递归输出条件误中包含本批 key 的父对象，输出过宽；后续已改为仅返回本批对象，实际绑定见 dispatch.json。未消费其他批次队列。部分长输出被终端截断，以保存的十原提案、queue-records.json 和后续有界读取为准。

证据提取尚在读取源日志时，过早读取零字节 states.evidence.jsonl 触发 StopIteration；这是提取未完成，不代表原日志缺失。之后首帧为地图时，对空 agent_view.combat 取 list 触发 TypeError: NoneType object is not iterable；未作为产品故障、游戏反例或证据缺失。

尝试在当前工作树定位旧121302 scratch时 rg 返回不存在；已找到原121302工作树中的报告、脚本与源码回执。没有改写原文件。旧材料断言脚本保留原字节 prior-audit-script.txt，本批版本仅将双 evidence 目录改为本批单目录。

本批没有可核的原生运行模型/推理强度接口，不将任务模板和项目默认配置当运行证明；不改账号、配置、服务档或重启线程，由宿主核原生请求。

绝对路径apply_patch写read_consumers.py失败；改用相对路径成功，现有四局离线消费者均exit0。根ledger单次29项CLI update实exit0、stderr0，29项原保护字段与记录前缀核验通过。本批没有修改生产源码、运行生产测试或注册新提案。

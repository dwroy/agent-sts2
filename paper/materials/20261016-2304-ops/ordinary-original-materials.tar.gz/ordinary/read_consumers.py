import collections
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
WORKTREE = OUT.parents[2]
RUNS = ("GXNKW8X1XYJP", "PD9AYQVMLQW6", "L2TSFU62Z57Z", "ZTRGYYMLR8SC")


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


identities = {row["run_id"]: row for row in json.loads((OUT / "run-identity.json").read_text())}
inputs = {run: {"run": identities[run], "decisions": [], "states": []} for run in RUNS}
excluded = []
for stream in ("decisions", "states"):
    with (OUT / "evidence" / f"{stream}.evidence.jsonl").open() as handle:
        for raw in handle:
            envelope = json.loads(raw)
            run = envelope["run_id"]
            if run not in inputs:
                continue
            row = {**envelope["row"], "_line": envelope["line"]}
            if stream == "decisions" and not row.get("decision_id"):
                excluded.append({"run_id": run, "reason": "原行没有decision_id，不补造身份", **envelope})
                continue
            inputs[run][stream].append(row)

save(OUT / "consumer-exclusions.json", excluded)
results = []
for run, data in inputs.items():
    assert str(data["run"]["character"]).lower() == "silent" and data["run"]["ascension"] == 10
    src = OUT / f"consumer-{run}.input.json"
    dest = OUT / f"consumer-{run}.output.json"
    err = OUT / f"consumer-{run}.stderr.log"
    save(src, data)
    with dest.open("wb") as stdout, err.open("wb") as stderr:
        result = subprocess.run(
            [str(Path.home() / ".local/node/bin/node"), "--max-old-space-size=2048", "--import", "tsx",
             "../learner/audit-selection.ts", str(src)],
            cwd=WORKTREE / "agent", stdout=stdout, stderr=stderr,
        )
    summary = {"run_id": run, "exit_code": result.returncode, "input_sha256": digest(src),
               "output_sha256": digest(dest), "stderr_sha256": digest(err),
               "states": len(data["states"]), "decisions": len(data["decisions"]),
               "excluded_metadata": sum(x["run_id"] == run for x in excluded), "production_test": False}
    if result.returncode == 0:
        audit = json.loads(dest.read_text())
        segments = audit["segments"]
        turns = audit["observed_turns"]
        summary.update({"segments": len(segments), "observed_actions": len(audit["observed_actions"]),
                        "observed_turns": len(turns),
                        "complete_candidate_results": sum(x["actual_full_candidate_result"] is not None for x in segments),
                        "interval_reasons": dict(collections.Counter(x["reason"] for x in audit["observed_intervals"])),
                        "turn_keys": list(turns[0]) if turns else []})
    results.append(summary)
    save(OUT / "consumer-summary.json", results)
    print(json.dumps(summary, ensure_ascii=False), flush=True)

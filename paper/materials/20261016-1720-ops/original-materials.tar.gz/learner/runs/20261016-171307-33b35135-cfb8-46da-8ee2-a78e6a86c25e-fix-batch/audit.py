import difflib
import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path('/home/dw/Projects/agent-sts2')
TREE = ROOT / '.worktrees/codex-fix-silent-20261016-171301'
SCRATCH = ROOT / 'learner/runs/20261016-171307-33b35135-cfb8-46da-8ee2-a78e6a86c25e-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-170047-52e6ea3c-9f93-4023-9bd6-fb6e562d31c7-fix-batch'


def git(*args, tree=TREE):
    return subprocess.check_output(['git', '-C', str(tree), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


checked_at = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
prior = json.loads((PRIOR / 'audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', tree=ROOT / '.worktrees/live').decode().strip()
ancestors = set(git('rev-list', base).decode().splitlines())
live_ancestors = set(git('rev-list', live).decode().splitlines())
files = []
for old in prior['current_files']:
    path = old['path']
    digest = sha((TREE / path).read_bytes())
    files.append({'path': path, 'sha256': digest, 'prior_sha256': old['sha256'],
                  'same_as_prior': digest == old['sha256']})
assert all(row['same_as_prior'] for row in files)
fixed = []
for old in prior['existing_fixes']:
    row = {**old, 'ancestor_in_base': old['commit'] in ancestors,
           'ancestor_in_live': old['commit'] in live_ancestors}
    assert row['ancestor_in_base'] and row['ancestor_in_live'], row
    fixed.append(row)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
old_queue = (PRIOR / 'queue-readonly-snapshot.md').read_bytes()
assert queue.startswith(old_queue)
tree_queue = (TREE / 'notes/fix-queue-v4.md').read_bytes()
assert [line for line in tree_queue.splitlines() if line.strip()] == [
    line for line in queue.splitlines() if line.strip()]
added = queue[len(old_queue):].decode()
assert 'silent-0308' in added and '3707a98930a03d83' in added
queue_lines = queue.decode().splitlines()
unchecked = [{'line': i + 1, 'item': line} for i, line in enumerate(queue_lines)
             if line.startswith('- [ ]')]
assert [(r['line'], r['item']) for r in unchecked] == [
    (r['line'], r['item']) for r in prior['queue_dispositions']]
dispositions = []
for row in prior['queue_dispositions']:
    dispositions.append({**row, 'same_original_text_as_prior': True,
        'verification': '本轮核当前原文、相关文件SHA及base/live祖先；同字节历史分析沿用，未重跑生产测试。'})
focused = []
for row in prior['focused_source_review']:
    lines = (TREE / row['path']).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if row['anchor'] in line]
    assert found, row
    focused.append({**row, 'current_matching_lines': found})
for path, anchor in [
    ('agent/src/reflex/combat.ts', 'const endTurnWouldKill = bool(combat["end_turn_will_kill_player"])'),
    ('agent/src/reflex/combat-plan.ts', 'if (!escape) return decision;'),
]:
    lines = (TREE / path).read_text().splitlines()
    found = [i + 1 for i, line in enumerate(lines) if anchor in line]
    assert found
    focused.append({'path': path, 'anchor': anchor, 'current_matching_lines': found})
evidence = json.loads((PRIOR / 'evidence-0332-readback.json').read_text())
for row in evidence['rows']:
    with Path(evidence['path']).open('rb') as handle:
        handle.seek(row['offset'])
        raw = handle.read(row['bytes'])
    assert sha(raw) == row['sha256']
    data = json.loads(raw)
    assert data['run_id'] == row['run'] and data['floor'] == row['floor']
    if row['seed'] is not None:
        assert f"seed={row['seed']}" in raw.decode()
    row['sha256_rechecked'] = True
evidence['limitation'] = '本轮重读三段固定偏移原字节并核SHA/局号/F40；两条原错误仍截断，完整resources/steps与根因未知，不修改正HP/300样本契约。'
save('evidence-0332-readback.json', evidence)
ref_path = 'paper/materials/20261016-1703-ops/postmortem-original-references.json'
refs = json.loads((TREE / ref_path).read_text())
new_evidence = []
for row in refs:
    if not ((row['stream'] == 'decisions' and 412490 <= row['learner_line'] <= 412494)
            or (row['stream'] == 'states' and row['learner_line'] in (426131, 426132))):
        continue
    with (ROOT / 'logs' / (row['stream'] + '.jsonl')).open('rb') as handle:
        handle.seek(row['offset'])
        raw = handle.read(row['bytes'])
    assert sha(raw) == row['sha256']
    data = json.loads(raw)
    record = {**row, 'sha256_rechecked': True, 'valid_json': True}
    if row['stream'] == 'decisions':
        assert data['run_id'] == '0YQJ9D1MC4NK' and data['floor'] == 33 and data['turn'] == 7
        record.update({key: data[key] for key in ('run_id', 'floor', 'turn', 'label')})
    new_evidence.append(record)
assert len(new_evidence) == 7
save('evidence-0308-readback.json', {
    'reference_path': ref_path, 'reference_blob': git('hash-object', ref_path).decode().strip(),
    'reference_sha256': sha((TREE / ref_path).read_bytes()), 'rows': new_evidence,
    'limitation': '仅核原始字节与决策身份；不做新游戏机制推断或完整未选候选收益判断，沿0308原策略链。'})
proposals = []
proposal_ids = {'silent-proposal-0ff91bb5da98a252', 'silent-proposal-3707a98930a03d83',
                'silent-proposal-5aa2672bd7cd1bf4'}
with (ROOT / 'paper/materials/learning/code-proposals.jsonl').open() as handle:
    for line in handle:
        row = json.loads(line)
        if row.get('id') in proposal_ids and row.get('op') == 'add':
            proposals.append({'id': row['id'], 'character': row['character'], 'ledger': row['ledger'],
                              'runs': row['runs'], 'target_task': row['target_task'],
                              'proposal_sha256': row['proposal_sha256']})
assert {row['id'] for row in proposals} == proposal_ids
changed = git('diff', '--name-only', prior['base'], base).decode().splitlines()
code_changed = [path for path in changed if path.startswith(('agent/src/', 'agent/tests/', 'agent/tools/',
    'knowledge/builders/', 'learner/', 'eval/', 'ops/')) and path != 'ops/inbox-dev.md']
assert not code_changed, code_changed
assert not git('status', '--porcelain').strip()
(SCRATCH / 'queue-readonly-snapshot.md').write_bytes(queue)
(SCRATCH / 'queue-diff-from-prior.patch').write_text(''.join(difflib.unified_diff(
    old_queue.decode().splitlines(keepends=True), queue.decode().splitlines(keepends=True),
    fromfile='prior-root-queue', tofile='current-root-queue')))
(SCRATCH / 'worktree-diff.patch').write_bytes(git('diff', '--binary', 'HEAD'))
audit = {'checked_at': checked_at, 'base': base, 'live_read_only_snapshot': live,
    'prior_audit': str(PRIOR / 'audit.json'), 'prior_audit_sha256': sha((PRIOR / 'audit.json').read_bytes()),
    'queue_sha256': sha(queue), 'tree_queue_sha256': sha(tree_queue),
    'queue_only_blank_lines_differ_from_tree': True,
    'queue_lines': len(queue_lines), 'queue_append': added,
    'unchecked_entries': len(unchecked), 'queue_dispositions': dispositions,
    'current_files': files, 'existing_fixes': fixed, 'new_fixes': [],
    'focused_source_review': focused, 'changed_paths_since_prior': changed,
    'code_changes_since_prior': code_changed, 'evidence_0332': evidence,
    'evidence_0308': str(SCRATCH / 'evidence-0308-readback.json'), 'existing_proposal_links': proposals,
    'tests': {'tsc': None, 'vitest': None, 'files': 0, 'cases': 0, 'retries': []},
    'actual_merge_performed_by_this_task': False, 'final_head': base, 'final_status_clean': True,
    'initial_read_failure': '历史材料被按需存储收起，首次读取FileNotFoundError/rg exit2；git ls-tree确认124776f1d27d560319f890e93de8be94589dd632后按原storage CLI恢复精确文件，非产品bug。',
    'initial_audit_failure': '首次脚本误要求根物理队列与Git基线逐字节相同；实际只有两处空行位置差异。保留audit-initial-failure.log，改为核所有非空原行相同，不改任一队列。'}
save('audit.json', audit)
print(json.dumps({'base': base, 'live': live, 'unchanged_files': len(files),
    'existing_fixes_in_base_and_live': len(fixed), 'unchecked_entries': len(unchecked),
    'queue_added_lines': len(added.splitlines()), 'evidence_rows': len(new_evidence) + len(evidence['rows']),
    'new_fixes': 0, 'worktree_clean': True}, ensure_ascii=False))

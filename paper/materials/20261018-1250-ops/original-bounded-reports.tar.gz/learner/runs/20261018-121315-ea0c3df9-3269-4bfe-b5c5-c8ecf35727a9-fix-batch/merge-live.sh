#!/usr/bin/env bash
set -eu
export TMPDIR=/home/dw/Projects/agent-sts2/learner/runs/20261018-121315-ea0c3df9-3269-4bfe-b5c5-c8ecf35727a9-fix-batch
export PATH="$HOME/.local/node/bin:$PATH"
export SANDBOX_WORKERS=2
branch=codex-fix-silent-20261018-121302
live=/home/dw/Projects/agent-sts2/.worktrees/live
cd "$live"
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
git status --short > "$TMPDIR/live-status-before.txt"
if test -n "$(git diff --cached --name-only)"; then
  echo 'Live index has existing staged changes; preserving it.'
  exit 76
fi
git add notes/fight-value-backtest.md knowledge
if ! git diff --cached --quiet; then
  git diff --cached --binary | gitleaks stdin --redact --no-banner > "$TMPDIR/gitleaks-refresh.log" 2>&1
  git commit -m 'Refresh knowledge data' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
fi
git rev-parse HEAD > "$TMPDIR/live-premerge.txt"
python3 - "$branch" <<'PY'
import json, os, subprocess, sys
from pathlib import Path
def git(*args):
    return subprocess.check_output(['git', *args])
branch = sys.argv[1]
base = git('merge-base', 'HEAD', branch).decode().strip()
def changed(ref):
    return set(git('diff', '--name-only', '-z', base, ref, '--', 'knowledge', 'notes/fight-value-backtest.md').decode().strip('\0').split('\0')) - {''}
overlap = changed('HEAD') & changed(branch)
conflicts = [name for name in sorted(overlap) if git('ls-tree', 'HEAD', '--', name) != git('ls-tree', branch, '--', name)]
record = {'base': base, 'overlap': sorted(overlap), 'conflicts': conflicts}
Path(os.environ['TMPDIR'], 'knowledge-overlap.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
sys.exit(77 if conflicts else 0)
PY
if git merge --no-edit "$branch" > "$TMPDIR/live-git-merge.log" 2>&1; then
  git rev-parse HEAD > "$TMPDIR/live-merged-source.txt"
else
  git diff --name-only --diff-filter=U > "$TMPDIR/live-merge-conflicts.txt"
  if git rev-parse -q --verify MERGE_HEAD >/dev/null; then git merge --abort; fi
  echo 'Merge conflicted; aborted and retained the knowledge refresh.'
  exit 78
fi
cd agent
if bash tools/test-sandbox.sh > "$TMPDIR/live-sandbox.log" 2>&1; then
  printf '0\n' > "$TMPDIR/live-sandbox.exit"
else
  result=$?
  printf '%s\n' "$result" > "$TMPDIR/live-sandbox.exit"
  cd ..
  git reset --merge "$(cat "$TMPDIR/live-premerge.txt")"
  echo 'Live checks failed; returned to the preserved premerge commit.'
  exit "$result"
fi
cd ..
date '+%Y-%m-%d %H:%M:%S %Z' > "$TMPDIR/live-release-date.txt"
python3 - <<'PY'
import os, subprocess
from pathlib import Path
p=Path(os.environ['TMPDIR'])
stamp=(p/'live-release-date.txt').read_text().strip()
source=subprocess.check_output(['git','rev-parse','codex-fix-silent-20261018-121302'],text=True).strip()
with Path('paper/materials/decision-log.md').open('a') as handle:
    handle.write(f'\n- {stamp} 学习者fix-batch：fix-queue-v4原ops-learner-recheck-report-fixes-shape-20261018窄cherry-pick子项，来源批20261018-011241/source9ae48941→live dddad5d67；原四例HNX4A2WBC34W F48T3、25226ZFLNR1J F48T4、YF0LXT1QSTGG F48T3、L704TLETMZBM F48T3仅作来源身份、不增加游戏结论。源码{source}已合live、合后原沙箱tsc/vitest0；固定Git七题及撤源码红恢复绿，保原失败/报告/当前叶守卫，source映射不冒live祖先，unassigned提案登记宽项仍pending。未找到对应bug-infra账本，不新建或shipped；纯运维验收无行为号、无游戏规则变化。\n')
PY
git add paper/materials/decision-log.md
git diff --cached --binary | gitleaks stdin --redact --no-banner > "$TMPDIR/gitleaks-live-record.log" 2>&1
git commit -m 'Record verified narrow strategy recheck publication' -m 'Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>'
git rev-parse HEAD > "$TMPDIR/live-final.txt"

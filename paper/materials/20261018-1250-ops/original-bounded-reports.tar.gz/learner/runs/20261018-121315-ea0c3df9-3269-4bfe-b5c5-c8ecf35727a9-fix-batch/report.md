## 修 bug 回报
- 合并基线：main → 7c27a19ac73ea6f5920b41d42689896f9996be44
- 修复（每条一行）：窄cherry-pick的recheck身份验收 — 5ff419bbf2968a13167c6556885ced73736c6ec6 — 测试 agent/tests/learner-cherry-pick-recheck.test.ts:rechecks an exact narrow publication without inventing source ancestry or rewriting failures — 去掉修复时失败：是（两项Python正常路径失败；恢复后7项通过）。
- 已被别人修掉的：H1预算协议 c40e43fd2；B2样本身份 660b194c9；R394监测兼容 5011b4cbd；报告格式 4c16dab04；文件关闭 9aec57cd7；max-gap夹具 a6913706；无动作死亡归因 3b48088de。已有待运输源码 dee638662/2a778b13，未重复实现。
- 没修的：策略/机制项沿原提案；0332、G2/DPR、生命周期和性能根因证据不足；旧提案登记协议及独立架构项范围太大；论文和消费夹具已有源待ops运输。逐条处置与原失败见本目录 audit.md、queue-dispositions.json。
- 测试：最终冻结源码 tsc 退出码 0；沙箱 vitest 496 文件 / 4478 用例 / 退出码 0。因补入历史身份反例重跑全套；没有超时重跑。定向2文件通过，gitleaks退出码0。
- 合入：未合入；live中notes/fight-value-backtest-silent.md、notes/monster-db-check.md两份未提交记录会被覆盖；三方合并未开始，两份记录及知识刷新已保留，无合后测试。 刷新后保留提交 efd308ad4aa8ce78c590b8168edb2748163bb5fb。
- 需要 Roy 定的事（没有写「无」）：无

```json
{
  "task": "fix-batch",
  "base": "7c27a19ac73ea6f5920b41d42689896f9996be44",
  "fixes": [
    {
      "item": "ops-learner-recheck-report-fixes-shape-20261018：窄cherry-pick的recheck身份子项",
      "commit": "5ff419bbf2968a13167c6556885ced73736c6ec6",
      "test": "agent/tests/learner-cherry-pick-recheck.test.ts",
      "fails_without_fix": true
    }
  ],
  "skipped": [
    {
      "item": "原unassigned_proof窄cherry-pick提案登记宽项",
      "reason": "太大：原Markdown无机器JSON、输出缺base/runs；需独立冻结原报告/注册/发布/宿主回执协议。本批只修recheck，不改原报告、祖先、ID或租约。"
    },
    {
      "item": "出牌/药水/SL/终局/路线及角色机制项（含0311/0317/0319/0320/0322/0329/0334/0339/0344/0347/0349/0362/0365/0461/0481/0487/0496与hidden-daggers后继）",
      "reason": "策略类：沿已有独立strategy-proposal和原证据链，不重复实现或补入开发者游戏知识。"
    },
    {
      "item": "silent-0332实际资源契约根因",
      "reason": "证据不足：完整resources/steps及触发根因仍缺；诊断、限时及样本身份窄修不等于根因解决。"
    },
    {
      "item": "U5W7NUE925NK原G2缺DPR告警的完整根因",
      "reason": "证据不足：原未来样本数组及配对分母未保存；已有零前缀/L2预算修复不冒认整项根因。"
    },
    {
      "item": "sandbox-glob-startup-race生命周期、磁盘/宿主超时与DPR性能宽项",
      "reason": "证据不足：已有恢复/回收/固定夹具窄修，不能由定向补验推出CPU、产品或调度因果。"
    },
    {
      "item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression / 调度公平性",
      "reason": "太大：独立架构、策略或归因任务，超出普通纯bug批次。"
    },
    {
      "item": "core-build-notify-222802-rc2旧通知恢复",
      "reason": "证据不足：旧实际送达状态未证，不重发可能已送达通知或代填其他角色ACK。"
    },
    {
      "item": "infra-paper-dataset-concurrent-gzip-keyscan-20261018",
      "reason": "已有源码dee6386621e8122d123a3cd0017c3e4c199f524e自测完成，原ops运输pending；队列禁止重复实现。"
    },
    {
      "item": "a406-fixed-deadlines五处消费夹具",
      "reason": "已有源码2a778b13ac1ead79afef957d4708c1df5dfd3757待原ops集成，不盲叠候选；read_report关闭修复9aec57cd7已在基线。"
    },
    {
      "item": "21bf-fake-herdr-workspace-deadline及一般固定测试性能根因",
      "reason": "证据不足：退出进程误判已有707702873窄修，原15秒宿主超时与宽因果仍未知；不加时限/skip/弱断言。"
    },
    {
      "item": "infra-chest-claimed-action-conflict-0516",
      "reason": "证据不足：缺领取请求和有界确认契约；原结构提案cf77920511042e9c由已有策略链核实。"
    },
    {
      "item": "本批live合入",
      "reason": "live中notes/fight-value-backtest-silent.md、notes/monster-db-check.md两份未提交记录会被覆盖；三方合并未开始，两份记录及知识刷新已保留，无合后测试。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 4478
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261018-121315-ea0c3df9-3269-4bfe-b5c5-c8ecf35727a9-fix-batch/report.md"
}
```

# 本批核验边界

本批只修改运维完整检查的窄 cherry-pick 验收。原 source 9ae48941c8d1495b2d4048aa40feee9713d54784 的六个文件对象与旧实际发布 dddad5d67b673b6fb157bf1b73c5e32e45c3c676 相同；源提交不是该旧发布的祖先。后来源提交已进入当前 live 历史，这个后来关系不能追认旧发布。当前 live 的 experience.json 已发生后续变化，仍必须通过当前文件守卫，不能借本修复冒称原交付当前六叶一致或再次触发旧批完整检查。

原报告 SHA256：80db955e17d8091dba170c45152d49d5129e6f894fd9920260783afea0a2cf5d。原四局楼层/回合只作为报告来源身份：HNX4A2WBC34W F48T3、25226ZFLNR1J F48T4、YF0LXT1QSTGG F48T3、L704TLETMZBM F48T3；未重新抽取游戏机制、运行模拟、调用模型或发游戏动作。

原 unassigned_proof 提案登记仍缺冻结报告协议：Markdown 无机器 JSON，原输出缺 base/runs 且 fixes 为描述型字符串。本批不改原报告、不造字段/祖先/提案 ID、不写 implemented/shipped/seen_runs/租约/角色 ACK；该宽项保留原普通运维队列。完整检查入口的 source_publications 仅记录经核实的源码对应关系，commits 仍只包含真实 live 祖先。

固定测试建立独立临时 Git 库，含新增/修改/删除文件及知识叶。七项分别覆盖精确窄合、后来的源祖先、原源码脏改/后续改动、外部/缺失工作树、live 脏改/后改/回退、不含源变化的伪发布/未发布提交、模式变化及未跟踪输入/删除叶重放。完整检查命令只在测试内替代为固定退出码；真实 Git 校验均执行。其他报告形状的原测试仍运行。

初稿的未发布负对照失败已保留 cherry-python-first.log 与 targeted-first.log；补齐实际发布祖先守卫后通过。首轮撤源码六项中一项失败、恢复通过；最终七项撤源码两项失败、恢复通过。最初整套执行期间曾补入最后的身份反例，首轮整套的 496 文件/4478 用例通过只作为历史记录；最终冻结三叶另跑完整沙箱入口，不借初轮充当最终资格。所有日志、差异和清单留在本目录。

学习账本查询 cherry、011241、report-fixes-shape 未找到对应基础设施条目，不新建或更改游戏账本。57 条显式未勾选条目的快照、账本状态与本批处置分别在 unchecked-queue-items.json、unchecked-queue-ledger-audit.json、queue-dispositions.json；原队列未改。已有原源码 dee638662 和 2a778b13 待 ops 运输，不重复实现/盲叠候选。H1、样本身份、R394 监测和 max-gap 等已有窄修复保留原提交；历史 full1 与任何补验范围不改写。

原策略/机制条目、0332 的实际资源根因、G2 两次缺 DPR 的完整根因、目录生命周期/磁盘宽项、架构/公平性/性能归因、宝箱接口矛盾均保持原证据和原 owner。本批没有产生新策略提案或游戏规则，也不代其他角色确认通知。纯工具 implementation_domains=[]。

实际合入回执更正：通用脚本和初次进度曾称冲突/abort；Git原始日志明确是两份未提交记录会被覆盖，三方合并未开始，U列表为空且无MERGE_HEAD。notes/fight-value-backtest-silent.md与notes/monster-db-check.md原样保留；知识刷新efd308ad4aa8ce78c590b8168edb2748163bb5fb已保存。本批源码5ff419bbf2968a13167c6556885ced73736c6ec6不是实际live祖先，未运行合后检查、未新增行为号或登记shipped。原失败日志不改写；最终机械回执见live-final-readback.json。

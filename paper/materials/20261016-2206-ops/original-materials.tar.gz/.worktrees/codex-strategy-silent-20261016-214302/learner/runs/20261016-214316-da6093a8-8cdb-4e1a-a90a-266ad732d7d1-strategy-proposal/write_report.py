"""Save the bounded review and its existing proposal links."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
PREVIOUS = ROOT / '.worktrees/codex-strategy-silent-20261016-201302/learner/runs/20261016-201307-1ca47641-25b0-4fab-b087-73a37c838be4-strategy-proposal'
data = json.loads((HERE / 'batch-input.json').read_text())
summary = json.loads((HERE / 'material-summary.json').read_text())
source = json.loads((HERE / 'source-audit.json').read_text())
audit = json.loads((HERE / 'raw-evidence-audit.json').read_text())
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(stamp)

details = {
 'silent-proposal-08eaa60bcc449852': {
  'evidence': 'KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1共7次饮用请求。F5 states280255→280280为53→16，获胜仍损37；F15 states280347→280376为46→46并耗两瓶。',
  'boundary': 'F15零净损不能推出不用药也零损；pending接口回执与药栏实际变化分别核实，SL恢复不能记作新得药或路线回血。',
  'reason': '缺F15不饮用及同入口、同后继下留药至Boss的完整成对结果；零净损但耗两药不能校准持药价格。',
  'next': '按同一入口冻结HP、药栏与整战后继，比较不用、当场用及留至Boss的完整资源链；新参数须按独立局和时间留出验证。'},
 'silent-proposal-92920295a648b540': {
  'evidence': 'TXZ6RVMQA09D A10 F48第2/3次T6同48HP、敌460，原线损3/净扣36，替线损0/净扣27；decisions275383/275385。第三次首胜剩4，F49 states281565→281566为4→0、敌111未伤且出牌0。',
  'boundary': '首战胜与连续两战胜分列；原低可信1200样本不构成必死/SL证据。两试后轮抽牌和生成并未保持一致。',
  'reason': '缺保持抽序、生成牌、药栏及后续选择一致的两战替线与联合资源校准；少损3同时少伤9不能证明通关改善。',
  'next': '同时验首战退出HP/药/复活、第二战开场效果、首次可操作帧与最终两战结局；同局SL不得拆为独立局。'},
 'silent-proposal-a327449c331efbc1': {
  'evidence': 'WQZVENQ7DTRP A10 F33第2/3次T9 states282075/282144指纹相同：26HP、敌184；相邻轮损13/22、敌净扣24/39。第2/6次T7损0/4、同扣24，延时线沙坑末值4→5。',
  'boundary': 'T9多15伤付9血并非同安全；T7多付4血有延时作用，亦不能统一禁止付血。末次攻击与沙坑内部先致死来源没有分项帧。',
  'reason': '缺攻击、格挡、沙坑两条边界的受控整战后继和独立验证，不能把9血换15伤拟成固定阈值或修改SL门槛。',
  'next': '保留原答、覆盖、完整执行和各自血价/输出/毒/沙坑，只有同预算完整后继支持时才调整排序。'},
 'silent-proposal-a099e89437e942bb': {
  'evidence': 'WQZVENQ7DTRP A10 F33T11第五次八手续饮添2/0/0刀、末次五手续饮添3/2/0刀；18个固定饮用窗口逐字节复核手位、生成及HP/能量。本批15局含原9局，原9局42饮统计未在本批重新逐饮全量拟合。',
  'boundary': '6403fdcdadc803a092beb5165a068e22bf51c412覆盖生成和穿插子模型，已核实际live祖先；未见过的保留、跨重问、恢复组合不能由一个生成公式外推。',
  'reason': '生成及穿插子模型已有实际live源码祖先；仍缺计划妥当保留容量、跨重问完整候选派发与SL恢复的联合消费者校准。',
  'next': '冻结饮用—出刀—饮用及保留/选择/重问后的实际完整动作和药栏，逐步核候选归属、容量及恢复；不将局部可多生刀当整战胜线。'},
 'silent-proposal-47910f82a1fdd98f': {
  'evidence': 'TXZ6RVMQA09D A10 F43/45/46/48/49五组出牌前原帧净扣4，最后4→0。WQZVENQ7DTRP F33T9攻防差和T7沙坑延时反例分账。',
  'boundary': '现有开场模型只覆盖观察组合，实际T1/SL恢复不重复扣开场；旧王室猛毒加小血瓶净2不拆成单件数值。',
  'reason': '王室猛毒开场和连战传递已有受限实现；缺未知回血/复活组合顺序及留药、路线、SL受控整战后继的联合校准。',
  'next': '在已见组合逐样本传递首战真实末HP、剩药及复活；未知开场组合维持未知，不预支奖励或未来回复。'},
 'silent-proposal-f1374df72d8e6a25': {
  'evidence': '1913SE84AXQF A10 F29 states282723→282744为61→46，F31以46和虚弱/复制药入场后死。Q6M2Y34MWKRE A10 F8 states282872→282906为57→2，F9 states282913→282921为2→0。F2T1早喝敏捷候选未完整实打，F8T1速度5敏在次轮撤回。',
  'boundary': 'Q6确已休息且最终喝药，F5/F6零损留药不是反例；先隔离紧勒等机制误差，不据低信心候选调药价或高血护栏。',
  'reason': '缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果，不能据低信心候选拟新权重。',
  'next': '比较真实胜战退出资源与下一战入口，临时/持续药效分源；机制固定回放与价值参数的后移验证分开。'},
 'silent-proposal-38a49e6c97f31eea': {
  'evidence': 'Q6M2Y34MWKRE A10 F8T4 states282887—282892敌血103→95→85→85→83→80；生存者选择页仍85，弃牌完成才83，随后结3毒。1913SE84AXQF F31T2弃磨蚀建1敏/4荆棘，T4未等毒雾下一轮补毒便死（此后者沿原稿引用，不冒作新增独立样本）。',
  'boundary': '5c7105ff0294466da8319f2934beda05c6040794已覆盖普通无挡紧勒受限公式，未据此覆盖升级、自动、叠层、有挡或完整弃牌后候选执行。',
  'reason': '普通紧勒受限公式已有实际live源码祖先；缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准和受控整战后继。',
  'next': '逐完成动作复核增益、反伤、再生与复活时点；选择未完成时阻断假续步，局部公式正确不得充当全战胜负改善。'},
 'silent-proposal-ef0e38a5dbd3bc07': {
  'evidence': '1913SE84AXQF A10 F24实际锻造、F28实回21、F29胜后46、F31死；Q6M2Y34MWKRE F7休息36→57，F8胜后2，F9死。F32未来火没有抵达。',
  'boundary': '1913实际休息条件改变，投影差不能全部归为同条件预测误差；持有/计划与已经付费建立的能力分列。',
  'reason': '缺另一营火、事件、路线和用药时机的受控完整结果，两条观察性失败链不足校准路线或终局权重。',
  'next': '以实际节点动作结转回复、事件血价、幕间和战内再生，SL另账；未来火和未建能力不能当已经到账。'},
 'silent-proposal-7f820c02d39bfaea': {
  'evidence': 'NHA2KW0RB7VP A10 F33第1/5/6次T1，实际可操作30HP、敌合408；相邻轮分别损1/7/7、敌净扣8/24/24。decisions277248/277250/277272/277274显示弃牌后重新规划，初题精确切击已被弃。',
  'boundary': '1698adc96ba434a46942321e0237b70657e625b2只提供current_turn_prediction、execution=unverified；初题不能认证整轮执行，六次全败仍仅一个独立局。',
  'reason': '缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；六次失败不构成六个独立验证局。',
  'next': '同时列原答/覆盖/实打、即时6血代价、净扣及是否实际击杀/推进；完整后继足够前保持notWorse/deathShare门槛。'},
 'silent-proposal-04b6b430759815ed': {
  'evidence': 'NHA2KW0RB7VP A10 F17T1 states283146→283147毒0→10，F33T1 states283395首次X1萎靡实−2力/2弱。三帧油灯对象仅index/relic_id/name/description/stack/is_melted，缺首次消费标志。K3676LU8B0UH A1、SADL3CGYTGSR A7为原稿历史支持。',
  'boundary': 'ec29ea34b919344b707e57ba472ea210f9c39d62已覆盖观察的蟹朝向取整；10c53de是经验发布，不能冒作油灯源码实现。只有持有油灯不能确定跨动作/恢复后的首次效果可用。',
  'reason': '蟹朝向取整子实现已有实际live源码祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入，以及未覆盖X值/升级组合与能力整战后继。',
  'next': '补可追溯的首次负面消费状态及恢复输入，按观察牌/目标/制品/实付X固定回放；未证实零X/升级/叠层不默认翻倍。'}
}

intro = f'''# 本批静默策略提案复核

记录时间：{stamp}。batch=20261016-214302-strategy-proposal。
基线：{summary['base']}。开工工作树干净，普通任务执行git merge --no-edit main，结果Already up to date。
learn.json本批task=strategy-proposal、character=silent、reason=proposal、工作树相符，精确领取10个proposal_ids；没有research_request、implementation_request或proposal_repair。普通专题文件绑定其他历史批，不满足本批条件，未转为专题或另读其他专题。

十项均保留waiting；没有新增行为规则、源码或知识修改、源码提交、合入、版本、shipped。生成、紧勒、开场扣血、连战与SL诊断的已有实现仅按其真实范围确认。完整执行/受控整战/联合消费者验证不足的整项不报duplicate或implemented。
'''
proposal = [intro]
for p in data['proposals']:
    item = details[p['id']]
    proposal.append(f'''## {p['id']}

原稿：{p['proposal']}；SHA256={p['proposal_sha256']}；原字节副本为本目录{p['id']}.original.md。
来源任务：{p['source_task']}；实现任务：strategy-proposal；领域：{', '.join(p['domains'])}；账本：{', '.join(p['ledger'])}。

证据：{item['evidence']}

反例与限制：{item['boundary']}

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：{item['next']}

处置：waiting。{item['reason']}

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。
''')
(HERE / 'proposal.md').write_text('\n'.join(proposal))

manifest = json.loads((HERE / 'evidence/evidence-manifest.json').read_text())
old_plan = json.loads((HERE / 'evidence-old-plan-cut/evidence-manifest.json').read_text())[0]
prior_plan = next(i for i in json.loads((PREVIOUS / 'evidence-reuse-audit.json').read_text()) if i['stream'] == 'run-plans')
assert old_plan['source_size'] == prior_plan['source_size'] == 8607652
assert old_plan['output_sha256'] == prior_plan['output_sha256']
assert old_plan['counts'] == prior_plan['counts']
(HERE / 'old-plan-cut-audit.json').write_text(json.dumps({'source_size': old_plan['source_size'], 'counts': old_plan['counts'],
    'output_sha256': old_plan['output_sha256'], 'same_prior': True}, ensure_ascii=False, indent=2) + '\n')

rows = ['| 日志流 | 本次冻结字节截点 | 选中行 |', '|---|---:|---:|']
for s in manifest:
    rows.append(f"| {s['stream']} | {s['source_size']} | {sum(s['counts'].values())} |")
source_rows = ['| 已有范围 | 实际live祖先源码提交 |', '|---|---|',
 '| 狡诈药水生成/手位 | 6403fdcdadc803a092beb5165a068e22bf51c412 |',
 '| 普通无挡紧勒 | 5c7105ff0294466da8319f2934beda05c6040794 |',
 '| 蟹朝向取整 | ec29ea34b919344b707e57ba472ea210f9c39d62 |',
 '| 连战与样本资源接续 | e1a467e18a0dfa8d99046a24ff4c0e1af59278c8；5b56a452bb9be14d620b368ec46974c1b57901ca；66283dd9982bdd7f480da7a4d9bfefea0572a9ac |',
 '| 开场观察组合扩展 | ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8 |',
 '| SL当前轮资源比较 | 1698adc96ba434a46942321e0237b70657e625b2 |']
report = intro + f'''
## 本批输入与材料验收

只读取派来的10项专用队列记录、10份Markdown和31个关联静默账本条目。原稿SHA逐一相符。派发10局保留原顺序，另核原提案5局1913SE84AXQF、Q6M2Y34MWKRE、NHA2KW0RB7VP、K3676LU8B0UH、SADL3CGYTGSR，共15局runs.jsonl均为SILENT；A1/A7/A9/A10分开，没有其他角色私有知识输入。knowledge只筛本批相关silent经验作现状核对，不把其新增案例视为本批重新验证的数据。

本次通过本工作树learner/extract_evidence.py对15局重新提取8流。每流source_size、逐行offset/bytes/SHA256、显式身份和计数保存于evidence/；全部{summary['verified_rows']}行又从原日志seek读回，校验JSON及身份。独立索引raw-evidence-index.jsonl可在过程副本回收后按原日志恢复。

''' + '\n'.join(rows) + f'''

无效原行states2、decisions2、brain1未纳入证据；fight-plans本截点0行仅表示未选到，不能断言日志缺失。run-plans另按原8607652截点重提取到独立evidence-old-plan-cut/，77行与前批原输出SHA及各局计数相同；新旧报告/零行初稿没有覆盖。

{summary['checks']}项固定材料检查全部通过：37个既有窗口重新计算，再加KEN两战、1913 F29、Q6 F8/F9资源端点和KEN7饮请求计数。包含TXZ五次开场扣血、WQ同指纹/双边界、NHA饱和替线、18个狡诈饮用窗口、紧勒弃牌完成时点和油灯局部效果。材料检查不是生产tsc/vitest，也不是完整候选认证或整战收益。详见bounded-checks.json、selected-decisions.json、ken-potion-actions.json和lamp-observed-fields.json。

## 当前源码与实际live范围

核对时live={source['live_head']}。{summary['source_leaves']}个相关源码/测试叶中，{summary['same_prior']}个与前批基线相同，{summary['same_live']}个与该live提交同字节；物理文件与提交核对、完整SHA及差分见source-audit.json、prior-base-source.patch、base-live-source.patch。未将这几个文件外推成全部knowledge或原dirty运行树已复原。

''' + '\n'.join(source_rows) + '''

同名狡诈侧支15ea09ad75a421d4bd65a820c187c8ee188186c8不是实际live祖先，不冒用。10c53de98c54b118660b8a478bbdedba548dd1c8是经验发布，不能代替油灯源码与消费者验收。

相较前批，当前combat-plan新增failureDirectory接线、rollout新增resourceAudit诊断字段；本批只读原差分。V5-R373的0332诊断封套发布事实保持，不把可留证/可读当根缺陷已修或本批策略实现，不改变其原owner与父要求。没有运行模拟池、LLM或生产消费者重测。

## 逐项结论

'''
for p in data['proposals']:
    i = details[p['id']]
    report += f"### {p['id']}\n\n账本：{', '.join(p['ledger'])}。\n\n{i['evidence']}\n\n{i['boundary']}\n\n**waiting**：{i['reason']}\n\n下一步：{i['next']}\n\n"
report += '''## 交付与限制

没有足够新增证据支持修改策略，保持现有行为。未新增CLI提案id，code_proposals沿10个派发原id；implementation_domains=[]表示本批无新增代码实现。逐项旧/新行为、反例、验证方法、样本划分与回退边界见proposal.md，不重写历史复盘或原提案。

只经根learner/ledger.py update为31个原条目追加本批proposal/report追溯，by=learner:strategy-proposal；没有新增游戏结论或证据计次，故不重复add。保留旧claim、首证、prior、evidence、status、version与shipped，不把已经shipped的条目降回proposed。本批没有新的游戏经验可登记proposed；waiting由调度器根据proposal_results保留待新局。CLI输入输出、物理追加偏移/SHA、前缀和字段保护验收在ledger-append-audit.json。

HEAD保持完整40位base，工作树及索引保持干净。无代码提交，撤源码失败/恢复通过、tsc/vitest、gitleaks提交前检查及live合前/合后验证均不适用，tests={"tsc":null,"vitest":null,"cases":null}；43项材料检查不填生产cases。fixes=[]、merged=null；没有空合并、行为版本、上线通知或shipped，不将本报告或诊断框架完成当量化学习/经验入库/自然消费者采用完成。

原运行版本多为dirty，不能完整还原当时源码和全部knowledge；原9局42饮、油灯3局17窗口等历史全量统计只按原稿引用，不声称本批全部重校准。原初稿、失败和前批历史保留；本批一次只读文件定位沿错误旧文件名未找到，随后读取真实review.py，不产生生产失败或证据缺失判断。一次账本查询输出过多where历史，随后缩减为本批条目claim和有限尾项，不据无关历史另选题。

本批没有新证据足以推翻或强行支持旧游戏结论；保留证据不足项，不因等待而关闭原父要求。现有工具未提供本原生会话实际模型/推理/服务档的独立回执，不将配置默认或其他批核验写成本批已核，也未改运行配置或另开模型。没有派下级agent、play、网络、依赖安装、游戏二进制读取或运维prompt修改。

运维交付：本目录proposal.md、report.md与result.json。没有待兜底提交或合入补丁；只需保存十项waiting及各自缺数据原因，沿现有新局重派链继续。
'''
(HERE / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-214302-strategy-proposal',
          'base': summary['base'], 'runs': data['batch']['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': data['batch']['proposal_ids'], 'implementation_domains': [],
          'proposal_results': [{'id': p['id'], 'state': 'waiting', 'reason': details[p['id']]['reason']} for p in data['proposals']],
          'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
updates = []
for ident in sorted(data['ledger']):
    links = [p['id'] for p in data['proposals'] if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': '20261016-214302本批复核' + ','.join(links) + '，整项waiting；已核原稿SHA、15静默局角色、19929原行及43材料检查。没有新源码/知识、提交/合入/生产测试或收益；原claim/证据/状态/版本保持。详细缺口见本批proposal/report。'})
(HERE / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(u, ensure_ascii=False) + '\n' for u in updates))
print(json.dumps({'report': str(HERE / 'report.md'), 'proposals': len(details), 'ledger_links': len(updates)}, ensure_ascii=False))

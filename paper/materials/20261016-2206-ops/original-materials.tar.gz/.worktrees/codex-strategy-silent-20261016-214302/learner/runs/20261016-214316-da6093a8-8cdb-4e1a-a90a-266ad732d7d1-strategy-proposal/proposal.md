# 本批静默策略提案复核

记录时间：2026-10-16 21:53:49 CST。batch=20261016-214302-strategy-proposal。
基线：e609e0038506294bee7afd8194a214be54f7fbb6。开工工作树干净，普通任务执行git merge --no-edit main，结果Already up to date。
learn.json本批task=strategy-proposal、character=silent、reason=proposal、工作树相符，精确领取10个proposal_ids；没有research_request、implementation_request或proposal_repair。普通专题文件绑定其他历史批，不满足本批条件，未转为专题或另读其他专题。

十项均保留waiting；没有新增行为规则、源码或知识修改、源码提交、合入、版本、shipped。生成、紧勒、开场扣血、连战与SL诊断的已有实现仅按其真实范围确认。完整执行/受控整战/联合消费者验证不足的整项不报duplicate或implemented。

## silent-proposal-08eaa60bcc449852

原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md；SHA256=4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016；原字节副本为本目录silent-proposal-08eaa60bcc449852.original.md。
来源任务：experience-update；实现任务：strategy-proposal；领域：potion；账本：silent-0019, silent-0020。

证据：KEN58SH9SLZ6 A10 F3T2、F4T1、F5T2、F11T1/T2、F15T1共7次饮用请求。F5 states280255→280280为53→16，获胜仍损37；F15 states280347→280376为46→46并耗两瓶。

反例与限制：F15零净损不能推出不用药也零损；pending接口回执与药栏实际变化分别核实，SL恢复不能记作新得药或路线回血。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：按同一入口冻结HP、药栏与整战后继，比较不用、当场用及留至Boss的完整资源链；新参数须按独立局和时间留出验证。

处置：waiting。缺F15不饮用及同入口、同后继下留药至Boss的完整成对结果；零净损但耗两药不能校准持药价格。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-92920295a648b540

原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md；SHA256=f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf；原字节副本为本目录silent-proposal-92920295a648b540.original.md。
来源任务：postmortem；实现任务：strategy-proposal；领域：combat, sl, terminal；账本：silent-0228, silent-0255。

证据：TXZ6RVMQA09D A10 F48第2/3次T6同48HP、敌460，原线损3/净扣36，替线损0/净扣27；decisions275383/275385。第三次首胜剩4，F49 states281565→281566为4→0、敌111未伤且出牌0。

反例与限制：首战胜与连续两战胜分列；原低可信1200样本不构成必死/SL证据。两试后轮抽牌和生成并未保持一致。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：同时验首战退出HP/药/复活、第二战开场效果、首次可操作帧与最终两战结局；同局SL不得拆为独立局。

处置：waiting。缺保持抽序、生成牌、药栏及后续选择一致的两战替线与联合资源校准；少损3同时少伤9不能证明通关改善。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-a327449c331efbc1

原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md；SHA256=e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925；原字节副本为本目录silent-proposal-a327449c331efbc1.original.md。
来源任务：postmortem；实现任务：strategy-proposal；领域：combat, sl；账本：silent-0079, silent-0018。

证据：WQZVENQ7DTRP A10 F33第2/3次T9 states282075/282144指纹相同：26HP、敌184；相邻轮损13/22、敌净扣24/39。第2/6次T7损0/4、同扣24，延时线沙坑末值4→5。

反例与限制：T9多15伤付9血并非同安全；T7多付4血有延时作用，亦不能统一禁止付血。末次攻击与沙坑内部先致死来源没有分项帧。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：保留原答、覆盖、完整执行和各自血价/输出/毒/沙坑，只有同预算完整后继支持时才调整排序。

处置：waiting。缺攻击、格挡、沙坑两条边界的受控整战后继和独立验证，不能把9血换15伤拟成固定阈值或修改SL门槛。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-a099e89437e942bb

原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md；SHA256=e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2；原字节副本为本目录silent-proposal-a099e89437e942bb.original.md。
来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion；账本：silent-0030, silent-0257, silent-0258。

证据：WQZVENQ7DTRP A10 F33T11第五次八手续饮添2/0/0刀、末次五手续饮添3/2/0刀；18个固定饮用窗口逐字节复核手位、生成及HP/能量。本批15局含原9局，原9局42饮统计未在本批重新逐饮全量拟合。

反例与限制：6403fdcdadc803a092beb5165a068e22bf51c412覆盖生成和穿插子模型，已核实际live祖先；未见过的保留、跨重问、恢复组合不能由一个生成公式外推。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：冻结饮用—出刀—饮用及保留/选择/重问后的实际完整动作和药栏，逐步核候选归属、容量及恢复；不将局部可多生刀当整战胜线。

处置：waiting。生成及穿插子模型已有实际live源码祖先；仍缺计划妥当保留容量、跨重问完整候选派发与SL恢复的联合消费者校准。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-47910f82a1fdd98f

原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md；SHA256=d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd；原字节副本为本目录silent-proposal-47910f82a1fdd98f.original.md。
来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion, sl, terminal；账本：silent-0018, silent-0019, silent-0020, silent-0021, silent-0025, silent-0079, silent-0198, silent-0228, silent-0255。

证据：TXZ6RVMQA09D A10 F43/45/46/48/49五组出牌前原帧净扣4，最后4→0。WQZVENQ7DTRP F33T9攻防差和T7沙坑延时反例分账。

反例与限制：现有开场模型只覆盖观察组合，实际T1/SL恢复不重复扣开场；旧王室猛毒加小血瓶净2不拆成单件数值。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：在已见组合逐样本传递首战真实末HP、剩药及复活；未知开场组合维持未知，不预支奖励或未来回复。

处置：waiting。王室猛毒开场和连战传递已有受限实现；缺未知回血/复活组合顺序及留药、路线、SL受控整战后继的联合校准。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-f1374df72d8e6a25

原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md；SHA256=df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0；原字节副本为本目录silent-proposal-f1374df72d8e6a25.original.md。
来源任务：postmortem；实现任务：strategy-proposal；领域：combat, potion, terminal；账本：silent-0019, silent-0020, silent-0050, silent-0253。

证据：1913SE84AXQF A10 F29 states282723→282744为61→46，F31以46和虚弱/复制药入场后死。Q6M2Y34MWKRE A10 F8 states282872→282906为57→2，F9 states282913→282921为2→0。F2T1早喝敏捷候选未完整实打，F8T1速度5敏在次轮撤回。

反例与限制：Q6确已休息且最终喝药，F5/F6零损留药不是反例；先隔离紧勒等机制误差，不据低信心候选调药价或高血护栏。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：比较真实胜战退出资源与下一战入口，临时/持续药效分源；机制固定回放与价值参数的后移验证分开。

处置：waiting。缺隔离机制误差后的同入口、同预算不用/早用/留药整战及下一战成对结果，不能据低信心候选拟新权重。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-38a49e6c97f31eea

原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md；SHA256=6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0；原字节副本为本目录silent-proposal-38a49e6c97f31eea.original.md。
来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion, sl；账本：silent-0006, silent-0011, silent-0025, silent-0044, silent-0050, silent-0064, silent-0133, silent-0253, silent-0259, silent-0261, silent-0262。

证据：Q6M2Y34MWKRE A10 F8T4 states282887—282892敌血103→95→85→85→83→80；生存者选择页仍85，弃牌完成才83，随后结3毒。1913SE84AXQF F31T2弃磨蚀建1敏/4荆棘，T4未等毒雾下一轮补毒便死（此后者沿原稿引用，不冒作新增独立样本）。

反例与限制：5c7105ff0294466da8319f2934beda05c6040794已覆盖普通无挡紧勒受限公式，未据此覆盖升级、自动、叠层、有挡或完整弃牌后候选执行。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：逐完成动作复核增益、反伤、再生与复活时点；选择未完成时阻断假续步，局部公式正确不得充当全战胜负改善。

处置：waiting。普通紧勒受限公式已有实际live源码祖先；缺弃磨蚀、增益分源、再生、自动触发及SL恢复的联合消费者校准和受控整战后继。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-ef0e38a5dbd3bc07

原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md；SHA256=d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5；原字节副本为本目录silent-proposal-ef0e38a5dbd3bc07.original.md。
来源任务：experience-update；实现任务：strategy-proposal；领域：combat, potion, terminal；账本：silent-0019, silent-0020, silent-0021。

证据：1913SE84AXQF A10 F24实际锻造、F28实回21、F29胜后46、F31死；Q6M2Y34MWKRE F7休息36→57，F8胜后2，F9死。F32未来火没有抵达。

反例与限制：1913实际休息条件改变，投影差不能全部归为同条件预测误差；持有/计划与已经付费建立的能力分列。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：以实际节点动作结转回复、事件血价、幕间和战内再生，SL另账；未来火和未建能力不能当已经到账。

处置：waiting。缺另一营火、事件、路线和用药时机的受控完整结果，两条观察性失败链不足校准路线或终局权重。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-7f820c02d39bfaea

原稿：/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md；SHA256=bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105；原字节副本为本目录silent-proposal-7f820c02d39bfaea.original.md。
来源任务：postmortem；实现任务：strategy-proposal；领域：combat, sl；账本：silent-0079。

证据：NHA2KW0RB7VP A10 F33第1/5/6次T1，实际可操作30HP、敌合408；相邻轮分别损1/7/7、敌净扣8/24/24。decisions277248/277250/277272/277274显示弃牌后重新规划，初题精确切击已被弃。

反例与限制：1698adc96ba434a46942321e0237b70657e625b2只提供current_turn_prediction、execution=unverified；初题不能认证整轮执行，六次全败仍仅一个独立局。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：同时列原答/覆盖/实打、即时6血代价、净扣及是否实际击杀/推进；完整后继足够前保持notWorse/deathShare门槛。

处置：waiting。缺同预算饱和排序校准、跨弃牌完整候选执行归属及成对整战后继；六次失败不构成六个独立验证局。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

## silent-proposal-04b6b430759815ed

原稿：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md；SHA256=188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58；原字节副本为本目录silent-proposal-04b6b430759815ed.original.md。
来源任务：experience-update；实现任务：strategy-proposal；领域：combat, terminal；账本：silent-0005, silent-0006, silent-0021, silent-0011, silent-0065, silent-0264, silent-0079, silent-0133, silent-0169, silent-0189, silent-0013, silent-0053, silent-0162, silent-0265。

证据：NHA2KW0RB7VP A10 F17T1 states283146→283147毒0→10，F33T1 states283395首次X1萎靡实−2力/2弱。三帧油灯对象仅index/relic_id/name/description/stack/is_melted，缺首次消费标志。K3676LU8B0UH A1、SADL3CGYTGSR A7为原稿历史支持。

反例与限制：ec29ea34b919344b707e57ba472ea210f9c39d62已覆盖观察的蟹朝向取整；10c53de是经验发布，不能冒作油灯源码实现。只有持有油灯不能确定跨动作/恢复后的首次效果可用。

旧/新行为：保持当前已观察范围内实现及生产门槛；本批不新增权重或机制。待验证行为为：补可追溯的首次负面消费状态及恢复输入，按观察牌/目标/制品/实付X固定回放；未证实零X/升级/叠层不默认翻倍。

处置：waiting。蟹朝向取整子实现已有实际live源码祖先；缺油灯首次消费跨动作、新战/SL恢复的联合输入，以及未覆盖X值/升级组合与能力整战后继。

验证与预期：先用本角色固定原始帧核资源与动作归属，未来参数按独立局和时间先后划分训练/验证，同局SL不拆样本，不以同一局既拟合又宣称样本外成功。预期是减少模型/资源认定误差，整战收益尚未知。无本批行为变化可回退；后续实际实现单项提交、自测及live，回退仅撤对应源码，保留证据和旧失败。Roy-2026-10-07-learning只提供授权，不提供游戏事实。

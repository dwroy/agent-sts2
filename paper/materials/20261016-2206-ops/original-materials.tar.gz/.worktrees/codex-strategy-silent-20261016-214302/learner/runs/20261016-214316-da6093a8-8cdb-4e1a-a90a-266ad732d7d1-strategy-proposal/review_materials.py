"""Verify this batch's raw evidence and bounded observations without changing production inputs."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
PREVIOUS = ROOT / '.worktrees/codex-strategy-silent-20261016-201302/learner/runs/20261016-201307-1ca47641-25b0-4fab-b087-73a37c838be4-strategy-proposal'
sys.path.insert(0, str(WORK / 'learner'))
from extract_evidence import run_identity


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])


def ref(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


inputs = json.loads((HERE / 'batch-input.json').read_text())
runs = set(inputs['runs'])
assert len(runs) == 15
assert all(row['character'].lower() == 'silent' for rows in inputs['runs'].values() for row in rows)
assert len(inputs['proposals']) == len(inputs['batch']['proposal_ids']) == 10
proposal_audit = []
for p in inputs['proposals']:
    raw = (HERE / (p['id'] + '.original.md')).read_bytes()
    assert sha(raw) == p['proposal_sha256']
    assert all(inputs['ledger'][i]['character'] == 'silent' for i in p['ledger'])
    proposal_audit.append({k: p[k] for k in ('id', 'proposal', 'proposal_sha256', 'runs', 'ledger', 'domains')})
write('proposal-input-audit.json', proposal_audit)

states, decisions, by_time = {}, {}, {}
audit = []
index_path = HERE / 'raw-evidence-index.jsonl'
with index_path.open('w') as index:
    for stream in json.loads((HERE / 'evidence/evidence-manifest.json').read_text()):
        name = stream['stream']
        source = ROOT / 'logs' / (name + '.jsonl')
        assert source.stat().st_size >= stream['source_size']
        assert set(stream['counts']) == runs
        digest = hashlib.sha256()
        counts = collections.Counter()
        with source.open('rb') as raw, (HERE / 'evidence' / (name + '.evidence.jsonl')).open('rb') as extracted:
            for encoded in extracted:
                digest.update(encoded)
                item = json.loads(encoded)
                assert item['run_id'] in runs and run_identity(item['row']) == item['run_id']
                assert item['source'] == str(source)
                assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= stream['source_size']
                raw.seek(item['offset'])
                original = raw.read(item['bytes'])
                assert sha(original) == item['sha256'] and json.loads(original) == item['row']
                counts[item['run_id']] += 1
                index.write(json.dumps(ref(item), ensure_ascii=False) + '\n')
                if name == 'states':
                    character = (item['row']['state'].get('run') or {}).get('character_id')
                    assert character is None or character.lower() == 'silent'
                    states[item['line']] = item
                    for key in ('ts', 'observed_ts'):
                        if item['row'].get(key):
                            by_time[(item['run_id'], item['row'][key])] = item
                elif name == 'decisions':
                    decisions[item['line']] = item
        assert digest.hexdigest() == stream['output_sha256']
        assert {run: counts[run] for run in runs} == stream['counts']
        audit.append({**stream, 'verified_rows': sum(counts.values())})
write('raw-evidence-audit.json', {'streams': audit, 'index_sha256': sha(index_path.read_bytes())})


def player(item):
    return item['row']['state']['combat']['player']


def enemies(item):
    return item['row']['state']['combat']['enemies']


def power(enemy, ident):
    return next((p['amount'] for p in enemy.get('powers', []) if p['power_id'] == ident), 0)


checks = []


def check(label, actual, expected, items):
    entry = {'label': label, 'actual': actual, 'expected': expected, 'pass': actual == expected,
             'evidence': [ref(item) for item in items]}
    checks.append(entry)
    write('bounded-checks.json', checks)
    assert entry['pass'], entry


# Recompute the original bounded checks, using the new extraction's copies of raw rows.
old_checks = json.loads((PREVIOUS / 'bounded-observations.json').read_text())['checks']
for old in old_checks:
    items = [states[r['line']] for r in old['evidence']]
    assert [ref(i) for i in items] == old['evidence']
    label = old['label']
    if '出牌前净失4' in label:
        a, b = items
        actual = [player(a)['current_hp'] - player(b)['current_hp'], player(b)['cards_played_this_turn']]
    elif '开场归零' in label:
        actual = [player(items[-1])['current_hp'], enemies(items[-1])[0]['current_hp']]
    elif '指纹同一' in label:
        actual = items[0]['row']['fingerprint'] == items[1]['row']['fingerprint']
    elif '相邻轮HP损/敌净扣' in label:
        a, b = items
        actual = [player(a)['current_hp'] - player(b)['current_hp'],
                  sum(e['current_hp'] for e in enemies(a)) - sum(e['current_hp'] for e in enemies(b))]
    elif '狡诈实饮' in label:
        a, b = items
        ca, cb = (i['row']['state']['combat'] for i in items)
        added = sum(c['card_id'] == 'SHIV' for c in cb['hand']) - sum(c['card_id'] == 'SHIV' for c in ca['hand'])
        actual = [len(ca['hand']), len(cb['hand']), added, player(b)['current_hp'] - player(a)['current_hp'],
                  player(b)['energy'] - player(a)['energy']]
    elif '紧勒与弃牌' in label:
        actual = [enemies(i)[0]['current_hp'] for i in items]
    elif '首毒实建10' in label:
        actual = [power(enemies(i)[0], 'POISON_POWER') for i in items]
    elif '首次萎靡' in label:
        actual = [power(enemies(items[0])[0], p) for p in ['STRENGTH_POWER', 'WEAK_POWER']]
    else:
        raise ValueError(label)
    check(label, actual, old['expected'], items)

for label, a, b, expected in [
    ('KEN F5胜战退出资源', 280255, 280280, [53, 16]),
    ('KEN F15零损且耗药', 280347, 280376, [46, 46]),
    ('1913 F29胜战退出资源', 282723, 282744, [61, 46]),
    ('Q6 F8胜战退出资源', 282872, 282906, [57, 2]),
    ('Q6 F9入口与死亡', 282913, 282921, [2, 0]),
]:
    check(label, [player(states[a])['current_hp'], player(states[b])['current_hp']], expected, [states[a], states[b]])

ken = [i for i in decisions.values() if i['run_id'] == 'KEN58SH9SLZ6' and i['row'].get('chosen', {}).get('action') == 'use_potion']
check('KEN七次饮用请求', len(ken), 7, ken)
write('ken-potion-actions.json', [{**ref(i), **{k: i['row'].get(k) for k in ('floor', 'turn', 'chosen', 'result')}} for i in ken])
selected = [275383, 275385, 275894, 275960, 277248, 277250, 277272, 277274]
write('selected-decisions.json', [{**ref(decisions[n]), **{k: decisions[n]['row'].get(k) for k in
      ('floor', 'turn', 'chosen', 'rationale', 'result')}} for n in selected])
lamp = []
for n in [283146, 283147, 283395]:
    relics = [r for r in states[n]['row']['state']['run']['relics'] if r['relic_id'] == 'UNSETTLING_LAMP']
    assert len(relics) == 1
    lamp.append({'evidence': ref(states[n]), 'relic': relics[0]})
write('lamp-observed-fields.json', lamp)

old_source = json.loads((PREVIOUS / 'source-audit.json').read_text())
base = git('rev-parse', 'HEAD').decode().strip()
live = git('-C', str(ROOT / '.worktrees/live'), 'rev-parse', 'HEAD').decode().strip()
paths = [i['path'] for i in old_source['paths']]
source_audit = {'base': base, 'prior_base': old_source['base'], 'live_head': live, 'paths': [], 'ancestor_checks': []}
for path in paths:
    current = (WORK / path).read_bytes()
    prior = git('show', old_source['base'] + ':' + path)
    live_bytes = git('show', live + ':' + path)
    physical = (ROOT / '.worktrees/live' / path).read_bytes()
    source_audit['paths'].append({'path': path, 'sha256': sha(current), 'prior_sha256': sha(prior),
                                'live_sha256': sha(live_bytes), 'live_physical_sha256': sha(physical),
                                'same_prior': current == prior, 'same_live': current == live_bytes,
                                'live_physical_matches_head': live_bytes == physical})
for item in old_source['ancestor_checks']:
    commit = item['commit']
    source_audit['ancestor_checks'].append({'commit': commit, 'subject': item['subject'],
        'base_ancestor': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
        'live_ancestor': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, live]).returncode == 0})
(HERE / 'prior-base-source.patch').write_bytes(git('diff', '--binary', old_source['base'], base, '--', *paths))
(HERE / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
write('source-audit.json', source_audit)
write('material-summary.json', {'base': base, 'live': live, 'verified_rows': sum(i['verified_rows'] for i in audit),
                              'checks': len(checks), 'all_passed': all(i['pass'] for i in checks), 'source_leaves': len(paths),
                              'same_prior': sum(i['same_prior'] for i in source_audit['paths']),
                              'same_live': sum(i['same_live'] for i in source_audit['paths'])})
print((HERE / 'material-summary.json').read_text())

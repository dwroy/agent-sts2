# 本批策略提案回报

本批十项均 waiting，已逐项核原文、账本、六局原始证据及既有 live 窄实现；没有足够新证据实施排序、药水持有价值或终局参数变更。完整证据、反例、旧规则/拟议行为、缺口、验证方法与回退见 [proposal.md](proposal.md)。

- 批次：20261016-140405-strategy-proposal；角色 silent；来源局均 A10。
- 初始 HEAD：d86bc1d927d5bce0244059878cee19091bc77820；初始工作树干净，按普通批次无冲突同步 main。
- report.base：2554cfa65131163fc7fd4e469594e2b91f12ff5f；没有绑定专题或实现请求。
- 实核 live 快照：9afbe4075ac8d941da6f1a47020e046aa2d5d8be。没有本批源码 commit、合入 commit、eval 版本或 shipped。

## 范围与原件验证

共用提取入口保存 states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、runs6，共8444条；fight-plans在该截点选中0条，不据此断言日志不存在。每流 source_size、输出SHA、逐原行offset/bytes/SHA及角色身份可读回，evidence-verification.json全部通过。原全局流有states2/decisions2/brain1条无效行，未归属本批、不推断所属局或填补内容。十份原Markdown指纹全部一致，见 assigned-proposals.json。未搬用其他角色知识或重写旧复盘。

## 原始证据所得

- 751 F17T2/T7配对指纹相同：端点多9敌净损/多5自身失血，多6敌净损/多10自身失血；T13省6失血同时少6敌净损。五次判死与末次实死分开，不当六个独立局。
- KV F33T5第4/5试同指纹，334→298/305、自己30→30，下轮毒20/13；第五试还有阻止补打毒的续问。严格整轮工具仍unknown，直接状态端点另存，不认证单卡因果或完整方案。
- YQL F17T10毒水后毒2→8，HP26、挡13、自爆41不变，下一帧实死；−2为未截断余血。PU F17第5试T15已won/end_hp2是实际成功反例，不把占位阶段当必死或胜利。
- KEN F17T10第4/5试同指纹，端点扣敌2→4/失血15→21；T5少失2血同时能力延后且追加续问。不能只按最少失血或单轮输出定长期最优。
- KEN七次use_potion均有相邻槽位消失帧，三次接口pending保留；不将七次均写completed，不以零净损认定无药也零损。

## 离线消费者与失败边界

冻结输入使用现有 learner/audit-selection.ts，未运行新模拟、LLM、网络或游戏API。首轮一局exit0，五局因六条历史改路线记录缺decision_id而exit1；原输入/输出/错误保留。准备脚本曾错误要求MAP页、错误假定KV T5无续问，失败见analysis-first-failures.json。最终仅排除六条非战斗改路线记录于战斗输入，完整封套保留、原行号不连续仍标未知，不填造ID。五局新输入exit0，第一局未变结果直接复用。

| 局号 | 题段 | 动作 | 可核整轮 | 未知窗口 |
|---|---:|---:|---:|---:|
| 751FN9QM9MHQ | 96 | 615 | 83 | 46 |
| KV0JHNJCKXLS | 92 | 667 | 31 | 83 |
| YQL8RZ8BWN1E | 213 | 570 | 63 | 51 |
| L9SGRBB5R698 | 228 | 634 | 65 | 60 |
| PU80F84P6HPN | 136 | 1032 | 103 | 80 |
| KEN58SH9SLZ6 | 96 | 547 | 70 | 42 |

合计861题段、4065动作、415可核整轮、362未知窗口。完整候选结果均null是工具的认证边界，不能证明实盘从未完整执行；消费者exit0也不证明候选预测正确、策略获益或自然采用。输入/输出/stderr SHA见consumer-readback-r3.json，具体端点见critical-observed-turns.json。

## 既有实现与尚缺范围

以下提交实核为本批base和实际live祖先，只证明其窄覆盖，不将十宽提案整包duplicate：

| 范围 | 实际祖先commit |
|---|---|
| 持牌失血保守来源 | 05cd292c6f01bb31e406473d3a9843e659d62b93 |
| 持药未知/无药预测参照 | c4670f4f416c7d93e192e889c5080e7e4e0e733f |
| 选择预测及动作回执 | a8b1f8be153fe4f3a34146117546c2178f2e446b |
| 巨兽SL阶段说明 | a83d9ab675560a177249aa638e99df40bcfb5553 |
| 巨兽当前毒水观察 | d5e20aa4dd44168ce30944dfcce74f8322144953 |
| 巨兽窄末态血挡说明 | 0d092f6b928a6221eabf3516abad25c48ceaac9c |

15个相关源码/消费者文件中14个与live逐SHA相同，explore.ts仅三处历史Roy/Dai注释署名差，完整patch已保存。anchorRank仍使用原始HP作同轮排序；缺新旧参考选择的受控后继，不直接把占位HP改0后称纯指标修正。选择审计与单动作回执明确actual_turn/whole_plan_executed为null。

## 逐项结果

- `silent-proposal-366288801d9150d9` — waiting；账本：silent-0079, silent-0176；751 F17同指纹血价已核；缺抽弃重问后的完整候选身份、逐来源结算及受控整战后继，不能拟SL血价门槛。
- `silent-proposal-85929bdfc8a3fc1b` — waiting；账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176；已有持牌保守损血、持药未知及无药预测参照；缺751 F13无药整战、留药后战和完整执行收益对照。
- `silent-proposal-efd9f83ee9e1a6dc` — waiting；账本：silent-0079, silent-0176；751六试无胜线且与原提案共用证据；缺同条件完整后继和独立局验证，不把局部成本改成禁探索规则。
- `silent-proposal-131042659448ae74` — waiting；账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176；751分项机制已有窄覆盖；缺联合逐来源实际结算、完整候选执行及跨战留药对照。
- `silent-proposal-990f054036609447` — waiting；账本：silent-0102, silent-0019, silent-0020；KV F33T5净扣36/29且都零损的端点已核，严格整轮仍unknown；缺毛伤回血归属及路线休息替代后继。
- `silent-proposal-e18d3f18e6cac2a0` — waiting；账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046；巨兽阶段与毒水局部限制已有实现；旧参考排序仍用原始占位HP，缺新旧改序完整后继及受控药水分支。
- `silent-proposal-9733bb80f445aeae` — waiting；账本：silent-0017, silent-0019, silent-0020, silent-0250；YQL末轮毒2→8而血挡和41来袭未变；PU第5试余2血胜反例保留，缺提前喝、不喝、留药及改序对照。
- `silent-proposal-c51468c5e8ba6668` — waiting；账本：silent-0019；KEN七次饮药请求均有槽位消失后帧，三次回执pending；缺随机选牌、重问后完整收益及留药Boss对照。
- `silent-proposal-86a7db08d1a31976` — waiting；账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176；KEN T10实伤2→4/失血15→21、T5省2血但延迟能力已核；缺逐来源完整兑现、相同后轮及独立验证。
- `silent-proposal-e282a9131b99129a` — waiting；账本：silent-0021, silent-0079, silent-0125, silent-0176；KEN同指纹局部取舍和既有预测拆项已核；缺完整候选认证及受控后继，不拟通用6血/2伤准入阈值。

## 验证、记录和后续

无生产源码或知识变更，未执行撤源码/恢复试验、tsc、vitest或沙箱套件，tests三个字段均null；离线读回不折算生产测试成功。未新增提案ID或支持证据，不改原claim/first_run/prior/status/version/shipped。账本仅经根ledger.py update追加本次proposal/report追溯，实际CLI回执见ledger-cli-receipt.json。无上线，不写上线记录、版本或规则双通知；由调用方沿原队列保留waiting等待具体新数据，不关闭经验入库或量化学习父要求。

本批任务参数要求普通/high；启动记录只显示宿主传入gpt-6.1-sol/xhigh/default，见runtime-readback.json。沙箱未取得原生进程/请求记录，不以启动参数证明本原生会话模型或强度已核；本任务未改模型配置。

最终机械结果见result.json；proposal路径位于本批learner/runs内。

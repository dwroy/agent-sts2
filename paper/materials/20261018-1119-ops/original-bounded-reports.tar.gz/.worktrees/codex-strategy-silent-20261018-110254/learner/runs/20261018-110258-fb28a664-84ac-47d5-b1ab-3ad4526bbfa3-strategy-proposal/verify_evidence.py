import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('evidence_reader', OUT.parents[1] / 'extract_evidence.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
selected = {'states': {}, 'decisions': {}, 'sl-attempts': {}}
checks = []
for stream in manifest:
    name = stream['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    counts = dict.fromkeys(dispatch['runs'], 0)
    digest = hashlib.sha256()
    with path.open('rb') as evidence, (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
        for encoded in evidence:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
            row = json.loads(raw)
            assert row == item['row'] and reader.run_identity(row) == item['run_id']
            counts[item['run_id']] += 1
            if name == 'states':
                run = row['state'].get('run') or {}
                assert run.get('character_id', '').lower() == 'silent' and run.get('ascension') == 10
            if name in selected:
                selected[name][item['line']] = item
    assert counts == stream['counts'] and digest.hexdigest() == stream['output_sha256']
    checks.append({'stream': name, 'source_size': stream['source_size'], 'counts': counts,
                   'verified_references': sum(counts.values()), 'output_sha256': digest.hexdigest()})

pairs = [(272434, 272575), (272531, 272652), (272483, 272820),
         (273400, 273450), (273242, 273474), (274505, 274568), (274484, 274601)]
pair_checks = []
for a, b in pairs:
    first, second = (selected['decisions'][line] for line in (a, b))
    assert first['run_id'] == second['run_id']
    same = first['row']['fingerprint'] == second['row']['fingerprint']
    assert same
    pair_checks.append({'run_id': first['run_id'], 'decision_lines': [a, b], 'same_fingerprint': same})

def snapshot(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'source_line': item['line'], 'offset': item['offset'], 'sha256': item['sha256'],
            'run_id': item['run_id'], 'floor': state['run']['floor'], 'turn': state.get('turn'),
            'hp': player.get('current_hp'), 'max_hp': player.get('max_hp'), 'block': player.get('block'),
            'powers': player.get('powers'),
            'hand': [{k: c.get(k) for k in ('index', 'card_id', 'upgraded', 'block', 'resolved_rules_text')}
                     for c in combat.get('hand', [])],
            'potions': state['run'].get('potions'),
            'enemies': [{k: e.get(k) for k in ('index', 'enemy_id', 'current_hp', 'max_hp', 'block',
                                               'powers', 'move_id', 'intents', 'is_alive')}
                        for e in combat.get('enemies', [])]}

transitions = [(274131, 280206, 280207), (274156, 280232, 280233),
               (274185, 280262, 280263), (274235, 280313, 280314),
               (274237, 280315, 280316), (274267, 280348, 280349),
               (274272, 280354, 280355)]
consumptions = []
for decision, before, after in transitions:
    choice = selected['decisions'][decision]['row']
    a, b = (snapshot(selected['states'][line]) for line in (before, after))
    slot = choice['chosen']['option_index']
    previous = next(p for p in a['potions'] if p['index'] == slot)
    following = next(p for p in b['potions'] if p['index'] == slot)
    assert previous['occupied'] is True and following['occupied'] is False
    assert a['run_id'] == b['run_id'] == 'KEN58SH9SLZ6'
    consumptions.append({'decision_line': decision, 'receipt': choice.get('result'), 'slot': slot,
                         'potion_id': previous['potion_id'], 'before': a, 'after': b})
ken_actions = [i for i in selected['decisions'].values() if i['run_id'] == 'KEN58SH9SLZ6']
assert sum(i['row'].get('chosen', {}).get('action') == 'use_potion' for i in ken_actions) == 7
assert not any(i['row'].get('chosen', {}).get('action') == 'discard_potion' for i in ken_actions)

before, after = (snapshot(selected['states'][line]) for line in (280160, 280161))
assert [before[k] for k in ('hp', 'block')] == [after[k] for k in ('hp', 'block')] == [26, 13]
def poison(s):
    return next(p['amount'] for p in s['enemies'][0]['powers'] if p['power_id'] == 'POISON_POWER')
assert poison(before) == 2 and poison(after) == 8
assert before['enemies'][0]['intents'] == after['enemies'][0]['intents']
assert before['enemies'][0]['current_hp'] == after['enemies'][0]['current_hp'] == 999999999

decision_lines = {line for pair in pairs for line in pair} | {272361, 272362, 273451, 273480, 274087, 274354}
decision_lines.update(t[0] for t in transitions)
(OUT / 'focused-decisions.json').write_text(json.dumps([selected['decisions'][line] for line in sorted(decision_lines)], ensure_ascii=False, indent=2) + '\n')
(OUT / 'potion-consumption-observations.json').write_text(json.dumps(consumptions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'giant-potion-observation.json').write_text(json.dumps({'before': before, 'after': after}, ensure_ascii=False, indent=2) + '\n')
receipt = {'streams': checks, 'verified_references': sum(c['verified_references'] for c in checks),
           'fingerprint_pairs': pair_checks, 'seven_consumptions_verified': True,
           'zero_discard_potion_decisions': True, 'giant_poison_transition_verified': True,
           'scope': '证据完整性与已观察动作核验；不是策略源码测试、反事实或整场胜率验证。'}
(OUT / 'evidence-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_references': receipt['verified_references'], 'fingerprint_pairs': pair_checks,
                  'seven_consumptions_verified': True, 'giant_poison_transition_verified': True}, ensure_ascii=False))

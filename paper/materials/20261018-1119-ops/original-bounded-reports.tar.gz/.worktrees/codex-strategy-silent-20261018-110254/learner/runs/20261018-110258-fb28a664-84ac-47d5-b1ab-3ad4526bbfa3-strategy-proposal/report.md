# 静默猎手策略提案复核报告

批次：20261018-110254-strategy-proposal。结论：十项均 waiting；没有新的策略源码改动或足以认证原整项完成的证据。已有局部诊断保留，剩余缺口逐项落盘，不新增重复提案 ID。

## 身份、基线与边界

- 本批 learn.json 对应行 task=strategy-proposal、character=silent、reason=proposal，工作树正确，proposal_ids 恰为领取的十项，无 proposal_repair、research_request 或 implementation_request。
- 普通专题文件仍绑定其他旧批次，与本批不匹配；未读取其研究正文，不承接手动专题，也未退回整条队列选题。
- 启动 HEAD 为 `92024e9e266ee78e29d9909029971f320bb122fe`，tracked clean。按普通任务要求 merge main，fast-forward 到本报告 base `21a1992020b5cb6833b75a7aaa5180b4515242a0`，没有冲突；只带入已经存在的运维记录。没有源码提交后自报新基线。
- 六个派发局经 runs.jsonl 确认均 SILENT、A10。第一次读取脚本把 SILENT 与 silent 作区分，断言退出1；按标准角色小写归一化后六局通过。原日志没改；identity-readback-note.txt 保留该读取错误，不能解释为角色冲突。
- 只核本批六个旧局、原十项及其16个既有账本、本角色相关经验和消费者源码。没有从其他角色知识取值，也未分析本批之外的新局。

## 原始证据与完整性

调用本工作树 learner/extract_evidence.py，输出保存于 evidence/，各流冻结 source_size、逐行 offset/bytes/SHA、计数和输出 SHA。verify_evidence.py 对全部所选原字节重新 seek/读取、核 SHA/JSON/显式身份，并核 states 的角色和进阶，8444 条通过；不是源码测试。

| 流 | 冻结字节截点 | 本批行数 |
|---|---:|---:|
| states | 14296274977 | 4167 |
| decisions | 2510164492 | 4071 |
| sl-attempts | 47743216 | 43 |
| run-config | 2080396 | 6 |
| run-plans | 9297388 | 21 |
| brain | 809399283 | 130 |
| runs | 371605 | 6 |
| fight-plans | 2233957 | 0 |

states、decisions、brain 全源扫描各遇到2条不能解析的行；它们没有被选入本批，不能据此推断坏行所属局或补全缺帧。fight-plans 的零行仅说明该截点未选到；没有据此说原日志缺失。未覆盖任何旧报告或零行初稿，没有把正文提及当归局。

| 局号 | states | decisions | SL行 | run-plans | brain |
|---|---:|---:|---:|---:|---:|
| 751FN9QM9MHQ | 624 | 615 | 6 | 2 | 15 |
| KV0JHNJCKXLS | 686 | 669 | 7 | 5 | 32 |
| YQL8RZ8BWN1E | 582 | 571 | 6 | 3 | 18 |
| L9SGRBB5R698 | 653 | 635 | 6 | 3 | 16 |
| PU80F84P6HPN | 1064 | 1033 | 12 | 5 | 31 |
| KEN58SH9SLZ6 | 558 | 548 | 6 | 3 | 18 |

run-config 和 runs 各局各1行。七组同指纹对照全部一致；KEN 七次饮药前后槽位及巨兽毒2→8/血挡来袭不变均直接回读核实。各 SL 行覆盖不同楼层的战斗，不把43行说成43个独立实验；六个旧局再核不新增支持N。

## 逐项处置

完整证据、反例、旧/拟议行为、验证、时间切分及回退见同目录 proposal.md。原 Markdown 十份均按专用队列 proposal_sha256 核实并保留原字节，见 original-proposal-manifest.json。

| 原 CLI ID | 证据局号/层/回合 | 既有账本 | 处置与具体缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | 751FN9QM9MHQ F17 T2/T7/T13 | silent-0079、0176 | waiting：缺候选实际逐源成本、同后继整战与独立验证；三组局部血价不足拟探索门槛。 |
| silent-proposal-85929bdfc8a3fc1b | 751FN9QM9MHQ F13 T3/F17 T7 | silent-0019、0021、0005、0007、0129、0176 | waiting：缺确定弃牌后的实际逐源结算、无药/留到后战完整实际分支；成本缺表不是持有值零。 |
| silent-proposal-efd9f83ee9e1a6dc | 751FN9QM9MHQ F17 T2/T7/T13 | silent-0079、0176 | waiting：同源经验/部分诊断不证明整项完成；仍缺完整成本归属、受控整战与后期独立验证。 |
| silent-proposal-131042659448ae74 | 751FN9QM9MHQ F13 T3/F17 T7/T13/T17 | silent-0019、0020、0021、0005、0006、0007、0046、0129、0176 | waiting：缺联合机制的完整实际消费者结算及跨战留药对照，组件存在不覆盖九类经验整项。 |
| silent-proposal-990f054036609447 | KV0JHNJCKXLS F33 T1/T4/T5/T6 | silent-0102、0019、0020 | waiting：缺毛伤/回血/成长完整归属、保持后继一致的整战及独立验证；同零损删输出不是已证保血。 |
| silent-proposal-e18d3f18e6cac2a0 | YQL8RZ8BWN1E F17 T9/T10及各末轮；L9SGRBB5R698 F17 T14；PU80F84P6HPN F17 T17 | silent-0017、0250、0011、0027、0046 | waiting：缺改序后的受控整战、完整最终资源和提前饮药结果；归零占位HP会影响同轮排序。 |
| silent-proposal-9733bb80f445aeae | 同上三局 F17，含PU第5试T15胜例 | silent-0017、0019、0020、0250 | waiting：阶段子实现不等于整项duplicate；缺阶段改序、提前药水和路线的受控验证。 |
| silent-proposal-c51468c5e8ba6668 | KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/T2/F15T1，F17入口 | silent-0019 | waiting：七次实耗已核，缺随机选牌/发光水重问的完整收益归属及未饮用或留至Boss的整战分支。 |
| silent-proposal-86a7db08d1a31976 | KEN58SH9SLZ6 F17 T2/T5/T8/T9/T10/T12/T13 | silent-0079、0021、0125、0005、0176 | waiting：缺能力后继、实际逐源归属、同后轮整战及独立验证；不能拟统一6血/2伤准入阈值。 |
| silent-proposal-e282a9131b99129a | KEN58SH9SLZ6 F17 T2/T5/T8/T9/T10 | silent-0021、0079、0125、0176 | waiting：缺续问后完整执行归属、受控整战和后期独立验证；省血或未试线均不足关闭探索或改变护栏。 |

## 当前源码与真实 live 祖先

取证时实际 live HEAD 为 `b155d00a36080418149e63d2f21b491d34d7f40a`。source-manifest.json 记录17叶的基线/live Git blob、SHA、工作字节和最后源码提交祖先核验。13叶字节相同；另4叶（card-model、potion-cost、explore、controller）保留实际 diff，差异为 Roy/Dai 注释署名文字，未把它们描述成字节一致。只证明所列叶子及取证时实际 live，不恢复旧局的 dirty 整树。

已有覆盖：

- silent-held-loss 和 selection-audit 已对候选持牌预测/弃牌待定分账，实际持牌与完整回合仍为 null。
- silent-potion-reference 已显示未知持有值、当轮无药/抽样整战无药的区别。
- silent-sl-resource-comparison、silent-sl-comparison、combat-plan 已保存原/替候选预测、B2配对和回退信息；预测不等于派发或收益兑现。
- silent-selection-dispatch 经 hand/loop 写单动作回执，whole_plan_executed/actual_turn 仍未知。
- attempts、explore、silent-giant-potion 已给本体结束/自爆未结算说明；anchorRank 仍使用原最长存活/原敌残血比较，阶段显示不证明改序收益。

所列源码的真实完整祖先提交见 source-manifest.json；本批十项都没有登记 implemented/duplicate，避免把部分覆盖当整项完成。

## 验证、记录与交付口径

没有修改 agent/learner/eval/ops/knowledge 的生产源码、测试或数据；source-diff.patch 为空，tracked 工作树保持干净。临时分析脚本只在本批被忽略的 scratch。没有实际功能实现，撤源码失败/恢复通过不适用；tsc、vitest、cases 均 null，未运行或借用历史测试作本批成功。没有 commit、live merge、eval版本、规则双通知或新 shipped 登记；merge=live 仅对实际源码实现触发，本批无需抢锁或碰刷新知识。

账本只经根 learner/ledger.py update 为16个原条目追加本批 proposal/report 路径和复核说明，不新增证据、不更改 claim/first_run/asc/prior/status/version/effect，也不将旧 shipped 状态记成本批新上线。逐项队列状态交本批最终 proposal_results 由原调度器处理，不直接改专用队列或 learn.json。账本CLI回执、保护字段比较和记录扫描结果见同目录后续验证回执。

本次没有新已证游戏结论入经验库，不冒称经验库已更新、大脑已采用或宽父要求已完成。后续只在原 ID 缺口得到实际证据后继续；原失败、未知和各原提案完整保留。

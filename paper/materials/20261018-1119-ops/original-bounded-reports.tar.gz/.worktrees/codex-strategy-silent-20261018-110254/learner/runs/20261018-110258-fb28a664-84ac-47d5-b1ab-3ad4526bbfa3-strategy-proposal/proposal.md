# 静默猎手：本批十项提案的证据复核与剩余实现条件

批次：20261018-110254-strategy-proposal。来源任务与实现任务均为 strategy-proposal；沿用原十个 CLI 提案 ID，不新建重复 ID、不覆盖原文。适用范围为本批六局 Silent A10。授权为 Roy-2026-10-07-learning；授权不提供游戏事实。

本批没有足够依据新增策略规则，也没有发现需要重复实现的诊断缺口。已有诊断只能证明其覆盖的部分，不能据此将原整项登记 implemented/duplicate。以下十项均 waiting，保留原行为；不登记新源码提交、合入、版本或 shipped。

## 证据与样本边界

六局为 751FN9QM9MHQ、KV0JHNJCKXLS、YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN、KEN58SH9SLZ6。已核 runs.jsonl 的原角色字段 SILENT 和进阶 10。没有读取其他角色的经验或统计，没有分析本批以外新局；原提案提及的其他历史局只作为来源说明，不计本次独立核实支持。

共用 extract_evidence.py 抽取八流，逐条回读源 offset/bytes/SHA/JSON/显式归局，8444 条全部一致。七组决策指纹相同。完整截点、各局计数和摘要见 evidence/evidence-manifest.json、evidence-verification.json；原提案十份 SHA 均与专用队列一致，原字节副本在 original-proposals/。fight-plans 在本截点选到零行，仅为截点选择结果，不推断原日志缺失。

同局 SL 尝试相关，只按局计独立样本；本次六个旧局的再核不新增独立支持 N。不拟合门槛、药水持有价、路线代价或新权重；不得把模拟候选当实盘反事实。

## 1. 异鱼 SL 血价（366288801d9150d9、efd9f83ee9e1a6dc）

完整 ID：silent-proposal-366288801d9150d9、silent-proposal-efd9f83ee9e1a6dc。账本均为 silent-0079、silent-0176；原来源分别为 postmortem 和 experience-update。

- 751FN9QM9MHQ F17 T2，第1/3试 decisions 272434/272575 同指纹：回合实际净损13→18，敌净扣9→18；B2 .195→.193，差−.0025、SE .0135。瞬时模型伤害与实际净扣分账。
- F17 T7，第2/4试 decisions 272531/272652 同指纹：模型损19→29，实际损13→23；敌净扣12→18，多6扣血付10血。B2 .103→.013，差−.09、SE .0088。原线和替线各有6的保守差，不能把它混进换线差额。
- F17 T13，第1/6试 decisions 272483/272820 同指纹：打击换呼唤后实际损8→2、敌净扣17→11。省血也少输出，六试均败。

旧规则：未强制 notWorseOnly 时仍可探索 B2 更差的未试线。现有 silent-sl-resource-comparison、silent-sl-comparison、silent-selection-audit/dispatch 已分列原线、替线、模型资源与单动作回执，完整实际回合仍未知。

待实现行为：只依据完整实际动作链核出持牌、弃牌、挡后敌伤与能力成本的归属；若调整探索准入，须给出可重放整战和独立验证。此批不把未决弃牌当已确定损血，不把选择回执当整线执行，不直接关闭更差线探索或写死5/10血门槛。

验证入口：上述三组底板及后继在 focused-decisions.json、paired-turn-observations.json。保持相同后继的原/替整战对照、实际逐源归属和独立局验证仍缺。两 ID 都 waiting；同源 Markdown 不构成源码 duplicate。

## 2. 未决持牌、联合机制与药水未知持有值（85929bdfc8a3fc1b、131042659448ae74）

完整 ID：silent-proposal-85929bdfc8a3fc1b、silent-proposal-131042659448ae74。共同证据为 751FN9QM9MHQ；共同账本 silent-0019、silent-0021、silent-0005、silent-0007、silent-0129、silent-0176；后者还关联 silent-0020、silent-0006、silent-0046。

F13 T3 decisions 272361/272362 记录先防御再实际喝肌肉药。plan2 有药伤26、损8、五轮8/8结束；plan3 当轮无药伤16、损8，但后轮7/8样本仍用药。plan5 才是整战无药参考，伤16、损8、8/8结束，存活样本平均终结约2.9轮；有药约2.3轮。成本原文说明表未加载。states 278403→278407 为58→50且药槽清空。未实打无药或留至 Boss 的整战分支。

F17 T7 实际弃牌后的结算与题面未决持牌上界不同。当前 silent-held-loss 及 selection-audit 以 total_hp_loss、held_hp_loss、discard_choice_pending、actual_held_hp_loss=null 分列，明确不能把剩余差额称作确定敌伤。silent-potion-reference 已保留 hold_hp=null、zero_reason 和同题无药范围；未知持有值不等于零价值。

反例：plan3 说明“不在本轮喝”不等于“整战不喝”；空药栏进 Boss 失败也不能反推出此前用药错误。敏捷、毒、荆棘、弃牌等组件存在不等于九类经验联合结算已全覆盖。

待实现与验证：补完整实际逐源结算和无药/留至后战分支，先核明确弃牌后的重算；保留未知、现有护栏和选项。没有数据拟合持有值或固定留药规则。两 ID 都 waiting，已有局部字段不认证原整项完成。

## 3. 知识恶魔毛伤、净伤与后继（990f054036609447）

完整 ID：silent-proposal-990f054036609447。证据 KV0JHNJCKXLS F33；账本 silent-0102、silent-0019、silent-0020。

第4/5试 T5 decisions 273400/273450 同指纹，30血、敌334。SL 删致命毒药，273451 又阻止补打。两线本轮都不损血，敌净扣36→29；次轮初毒20→13（states 279465/279515）。第1/6试 T1 decisions 273242/273474 同指纹，删究极打击后敌净扣28→14，仍同零损。末试 T4 最后动作帧敌327、15毒（279559），下一轮回到342，不能把净变化当毛伤或忽略回血。

反例：删输出而同零损，没有已观察保血收益；第4/5试都 T10 判死，后轮动作不同，不能单归本步。当前资源对照有预测输出和结毒后毒层；没有完整实际毛伤/回血/成长的联合归属，也没有保持后继一致的整战胜线。

待实现与验证：补真实结算来源、路线已发生回血与假设机会的区别；固定两组底板做后继一致的整战对照，再按独立局时间留出验证。此批不改探索、药水或路线参数，waiting。

## 4. 巨兽本体、自爆与参考路径（e18d3f18e6cac2a0、9733bb80f445aeae）

完整 ID：silent-proposal-e18d3f18e6cac2a0、silent-proposal-9733bb80f445aeae。证据 YQL8RZ8BWN1E、L9SGRBB5R698、PU80F84P6HPN F17；共同账本 silent-0017、silent-0250；前者另有 silent-0011、silent-0027、silent-0046，后者另有 silent-0019、silent-0020。

YQL 六试末轮为 T13/T13/T12/T13/T13/T10，自爆50/50/47/50/50/41；本体结束后仍失败。末试 T10 decisions 274087、states 280160→280161：毒2→8，但占位HP999999999、玩家HP26、挡13、来袭41均不变。新增毒不能记成已造成6伤、减自爆6或已胜利；本次真实死亡0血与先前26血末态分开。

旧 SL summary 用接近十亿的占位血参与残血比较。现有 attempts 的 giantPhaseAtTurnStart、giant_phase、giant_final_resources 以及 silent-giant-potion 已明确 body_hp=0、blast_pending、fight_won=false，并保留原始HP；最终资源只在其严格已覆盖条件下给值。explore 的 anchorRank 仍保留原最长存活/原残血排序。

反例：将阶段显示修正直接变成占位HP归零排序，可能改变同轮参考，不能当无行为影响的统计修复。YQL 第1试末块信息来自 least-loss 判断，第2试是 rules 判断，不能把二者一概当完整最终实际资源；第2试6血10挡对50也不能证明更好。PU80F84P6HPN 第5试 T15 确有胜利余2血，但后继动作同变，不认证新排序或单瓶药因果。

待实现与验证：补改序后的完整选择/执行/资源结果及提前饮药的受控整战。保留本体/占位血/自爆阶段分项，不修改胜利条件、读档或通用排序权重。两 ID 都 waiting，已有阶段子实现不等于原整项 duplicate。

## 5. 七次耗药与跨战预算（c51468c5e8ba6668）

完整 ID：silent-proposal-c51468c5e8ba6668。证据 KEN58SH9SLZ6，账本 silent-0019。

已逐槽核对：F3 T2 攻击药（274131/280206→280207）；F4 T1 稳定血清（274156/280232→280233）；F5 T2 速度药（274185/280262→280263）；F11 T1 虚弱药（274235/280313→280314）、T2 攻击药（274237/280315→280316）；F15 T1 发光水（274267/280348→280349）、技能药（274272/280354→280355）。七次槽位由占用到空，discard_potion 决策零。三次随机牌药的返回状态为 pending/unstable，用后续槽位确认消费，不把回执误写为 completed。

六试 F17 首轮均75/86空药栏。实际消费不证明原候选整线都执行，也不证明 F15 不饮用仍零损，或留到 Boss 一定更好。当前 selection-dispatch 只认证单动作接口回执，state_effect_verified=false、whole_plan_executed=null。

待实现与验证：补随机选牌、发光水后重问的完整候选收益归属，及未饮用/留药的后继整场分支；再谈持有值或跨战预算。potion-consumption-observations.json 保存七组原帧与回执。保留现行规则，waiting。

## 6. 无实体新增输出与能力窗口（86a7db08d1a31976、e282a9131b99129a）

完整 ID：silent-proposal-86a7db08d1a31976、silent-proposal-e282a9131b99129a。证据 KEN58SH9SLZ6 F17；共同账本 silent-0079、silent-0021、silent-0125、silent-0176，前者另有 silent-0005。

第4/5试 T10 decisions 274505/274568 同指纹：37血、敌82，无实体；替线后实际净损15→21、敌净扣2→4。B2 .385→.127、差−.2583、SE .0132；五轮死亡6/24→12/24。第4/6试 T5 decisions 274484/274601 同指纹：损7→5，但步法由 T5 延到 T9；后问追加小刀，实际扣1→2，不能把候选预测伤1直接冒称完整回合输出2。

反例由末试原帧补核：T8 states 280697→280700 仍无敏捷，两防后挡10；T9 states 280701→280704 才出现敏捷2。第2试 T2 decisions 274354 的 HP 护栏改线省血，但未建立原迷雾4毒，原线没有完整实际分支。末试清呼唤后仍死，不能得出“只要清呼唤就赢”。

待实现与验证：补重问后的完整实际归属和能力后继，固定其他后轮再对照；独立局按真实开始时间留后期验证。不得只按少失血、未试过或单个6血/2伤比值改变探索或护栏。两 ID 都 waiting。

## 统一验证、预期影响与回退

此批完成的是原始证据与当前源码覆盖复核，非新源码实现。source-manifest.json 钉住17个源码叶子、Git blob、SHA及其实际 live 祖先；live-vs-base-source.patch 保留四叶的真实差异，均为 Roy/Dai 署名注释文字，未冒称字节全同。没有运行新模拟、LLM、对局或源码测试。

后续若满足逐项缺数据条件，继续原 ID，保留冻结帧及原失败历史。规则实现须固定数据回放、撤源码失败/恢复通过、沙箱 tsc/vitest、自测后实际 live 合入、版本及双通知；未完成前不登记 implemented/shipped。本次预期作用仅为明确下一次验收条件，不承诺胜率提升。不产生源码回退操作；原行为保持，证据与账本链接长期保留。

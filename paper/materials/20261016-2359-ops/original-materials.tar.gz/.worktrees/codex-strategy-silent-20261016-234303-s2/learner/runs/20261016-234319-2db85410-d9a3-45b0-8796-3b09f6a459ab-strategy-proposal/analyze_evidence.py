import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
FLOORS = {
    'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {38, 39}, 'CA5KE8GFJ9X2': {13},
    '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33},
}


def powers(value):
    return {p['power_id']: p.get('amount') for p in value or []}


def compact(item):
    row = item['row']
    state = row['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'], 'sha256': item['sha256'],
        'run': item['run_id'], 'floor': run.get('floor'), 'turn': state.get('turn'),
        'ts': row.get('ts'), 'observed_ts': row.get('observed_ts'),
        'fingerprint_sha256': hashlib.sha256(row.get('fingerprint', '').encode()).hexdigest(),
        'hp': player.get('current_hp'), 'block': player.get('block'), 'energy': player.get('energy'),
        'powers': powers(player.get('powers')),
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'), 'upgraded': c.get('upgraded')}
                 for c in combat.get('hand', [])],
        'enemies': [{'index': e.get('index'), 'id': e.get('enemy_id'), 'hp': e.get('current_hp'),
                     'max_hp': e.get('max_hp'), 'alive': e.get('is_alive'), 'block': e.get('block'),
                     'move': e.get('move_id'), 'powers': powers(e.get('powers')),
                     'intents': e.get('intents')}
                    for e in combat.get('enemies', [])],
    }


def main():
    selected = []
    counts = collections.Counter()
    for raw in (OUT / 'evidence/states.evidence.jsonl').open():
        item = json.loads(raw)
        state = item['row']['state']
        assert state['run_id'] == item['run_id']
        assert (state.get('run') or {}).get('character_id') == 'SILENT'
        counts[item['run_id']] += 1
        if state.get('in_combat') and (state.get('run') or {}).get('floor') in FLOORS[item['run_id']]:
            selected.append(compact(item))
    (OUT / 'combat-frames.json').write_text(json.dumps(selected, ensure_ascii=False, indent=2) + '\n')
    index = {v['line']: v for v in selected}
    checks = []

    def check(name, condition, lines):
        checks.append({'name': name, 'passed': bool(condition), 'state_lines': lines})

    a, b = index[277512], index[277513]
    check('YF阶段111至212重读零毒', a['enemies'][0]['hp'] == 4 and
          a['enemies'][0]['powers']['POISON_POWER'] == 4 and
          b['enemies'][0]['max_hp'] == 212 and b['enemies'][0]['hp'] == 212 and
          b['enemies'][0]['powers'].get('POISON_POWER', 0) == 0, [277512, 277513])
    a, b = index[277524], index[277526]
    check('YF五敏至六敏不倒补已成23挡', a['powers']['DEXTERITY_POWER'] == 5 and
          b['powers']['DEXTERITY_POWER'] == 6 and a['block'] == b['block'] == 23, [277524, 277526])
    a = index[277519]
    check('YF触媒二层与零毒同帧', a['powers']['ACCELERANT_POWER'] == 2 and
          a['enemies'][0]['powers'].get('POISON_POWER', 0) == 0, [277519])
    a, b = index[278236], index[278237]
    check('XP船夹板轮初14挡及镣铐负九', a['block'] == 14 and
          b['enemies'][0]['powers']['STRENGTH_POWER'] == -9, [278236, 278237])
    (OUT / 'material-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'counts': counts, 'selected_frames': len(selected), 'checks': checks}, ensure_ascii=False))
    for run in ['DUZUBAJ3A8GP', '5PM6JAQG6FNQ', 'CA5KE8GFJ9X2']:
        rows = [v for v in selected if v['run'] == run]
        print(run, 'frames', len(rows))
        for v in rows:
            if v['turn'] is not None and (run != 'DUZUBAJ3A8GP' or v['turn'] >= 4):
                print(json.dumps({k: v[k] for k in ['line', 'floor', 'turn', 'hp', 'block', 'powers', 'enemies']}, ensure_ascii=False))


if __name__ == '__main__':
    main()

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract', TREE / 'learner/extract_evidence.py')
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
selected_decisions = {270216, 270282, 271309, 271348, 271354, 271982, 272195, 271992, 272040}
frames = {v['line']: v for v in json.loads((OUT / 'combat-frames.json').read_text())}
selected_states = {
    273237, 273247, 273252, 273258, 273263, 274308, 274313, 274317,
    274351, 274352, 274354, 274357, 274358, 274362,
    274830, 274831, 274832, 274833, 274834, 274836, 274837, 274838,
    277327, 277337, 277366, 277373, 277512, 277513, 277518, 277519, 277524, 277526,
    278017, 278021, 278022, 278231, 278236, 278237, 278249, 278253, 278254,
}
decisions = {}
stream_reports = []
source_checks = []
sl = []
for entry in manifest:
    name = entry['stream']
    path = OUT / f'evidence/{name}.evidence.jsonl'
    counts = collections.Counter()
    digest = hashlib.sha256()
    source = Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')
    with path.open('rb') as handle, source.open('rb') as original:
        for raw in handle:
            digest.update(raw)
            item = json.loads(raw)
            assert extract.run_identity(item['row']) == item['run_id']
            assert item['offset'] + item['bytes'] <= entry['source_size']
            counts[item['run_id']] += 1
            if name in ('run-config', 'runs', 'run-plans', 'sl-attempts') or (
                name == 'states' and item['line'] in selected_states) or (
                name == 'decisions' and item['line'] in selected_decisions):
                original.seek(item['offset'])
                physical = original.read(item['bytes'])
                assert hashlib.sha256(physical).hexdigest() == item['sha256']
                assert json.loads(physical) == item['row']
                source_checks.append({k: item[k] for k in ['source', 'line', 'offset', 'bytes', 'sha256', 'run_id']})
            if name == 'decisions' and item['line'] in selected_decisions:
                decisions[item['line']] = item['row']
            if name == 'sl-attempts':
                sl.append({k: item['row'].get(k) for k in ['run_id', 'floor', 'attempt', 'result', 'turns', 'end_hp']})
    assert digest.hexdigest() == entry['output_sha256']
    assert all(counts[k] == v for k, v in entry['counts'].items())
    stream_reports.append({'stream': name, 'source_size': entry['source_size'], 'counts': entry['counts'],
                           'output_sha256': digest.hexdigest(), 'verified': True})

checks = []


def check(label, condition, lines, stream='states'):
    checks.append({'name': label, 'passed': bool(condition), 'stream': stream, 'lines': lines})


for a, b in [(270216, 270282), (271309, 271348), (271982, 272195), (271992, 272040)]:
    check('两次决策完整指纹逐字一致', decisions[a]['fingerprint'] == decisions[b]['fingerprint'], [a, b], 'decisions')

check('棱柱T4技能污染三再三且能力不加',
      [frames[n]['powers'].get('TAINTED_POWER', 0) for n in [274830, 274831, 274832, 274833]] == [0, 3, 3, 6],
      [274830, 274831, 274832, 274833])
check('棱柱T5污染清零与火花六和三个技能增量六',
      frames[274834]['enemies'][0]['powers']['VITAL_SPARK_POWER'] == 6 and
      [frames[n]['powers'].get('TAINTED_POWER', 0) for n in [274834, 274836, 274837, 274838]] == [0, 6, 12, 18],
      [274834, 274836, 274837, 274838])
check('蚌两次加压后力量零至四至八',
      [frames[n]['enemies'][0]['powers'].get('STRENGTH_POWER', 0) for n in [273237, 273252, 273263]] == [0, 4, 8],
      [273237, 273252, 273263])
zap = [next(e for e in frames[n]['enemies'] if e['id'] == 'ZAPBOT') for n in [274308, 274313]]
check('电击同上限23者力量二至四攻击17至19',
      [e['max_hp'] for e in zap] == [23, 23] and
      [e['powers']['STRENGTH_POWER'] for e in zap] == [2, 4] and
      [next(a['damage'] for a in e['intents'] if a.get('damage') is not None) for e in zap] == [17, 19],
      [274308, 274313])
check('两步法使负四敏依次恢复负二和零',
      [frames[n]['powers'].get('DEXTERITY_POWER', 0) for n in [274351, 274352, 274354]] == [-4, -2, 0],
      [274351, 274352, 274354])
check('失落退场后恢复四力量', frames[274357]['powers']['STRENGTH_POWER'] == -4 and
      frames[274358]['powers'].get('STRENGTH_POWER', 0) == 0 and
      all(e['id'] != 'THE_LOST' for e in frames[274358]['enemies']), [274357, 274358])
check('遗忘后续再次降低二敏', frames[274362]['powers']['DEXTERITY_POWER'] == -2, [274362])
check('YF两同盘T1实损零与九并扣45与38',
      frames[277327]['hp'] - frames[277337]['hp'] == 0 and
      frames[277366]['hp'] - frames[277373]['hp'] == 9 and
      frames[277327]['enemies'][0]['hp'] - frames[277337]['enemies'][0]['hp'] == 45 and
      frames[277366]['enemies'][0]['hp'] - frames[277373]['enemies'][0]['hp'] == 38,
      [277327, 277337, 277366, 277373])
check('XP首末T1实损二与十且本体扣25与34',
      frames[278017]['hp'] - frames[278022]['hp'] == 2 and
      frames[278231]['hp'] - frames[278236]['hp'] == 10 and
      sum(e['hp'] for e in frames[278017]['enemies']) - sum(e['hp'] for e in frames[278022]['enemies']) == 25 and
      sum(e['hp'] for e in frames[278231]['enemies']) - sum(e['hp'] for e in frames[278236]['enemies']) == 34,
      [278017, 278022, 278231, 278236])
attacks = lambda n: [a['damage'] for e in frames[n]['enemies'] if e['id'] == 'ROCKET'
                      for a in e['intents'] if a.get('damage') is not None]
check('XP火箭背向转向再弱为57至38至28',
      [attacks(n) for n in [278249, 278253, 278254]] == [[57], [38], [28]], [278249, 278253, 278254])

summary = {'streams': stream_reports, 'physical_row_checks': source_checks, 'checks': checks,
           'sl_attempt_rows': sl, 'all_checks_passed': all(v['passed'] for v in checks),
           'scope': '本报告材料一致性检查，不是tsc、Vitest、源码撤回红绿或策略效果测试'}
(OUT / 'verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'selected_rows_verified': len(source_checks), 'checks': checks,
                  'all_checks_passed': summary['all_checks_passed']}, ensure_ascii=False))

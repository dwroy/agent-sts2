import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = '863ff95dc199e376abd171540887f83c610fe250'
BATCH = '20261016-234303-s2-strategy-proposal'
assigned = json.loads((OUT / 'assigned-proposals.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
ledger = json.loads((OUT / 'ledger-selected.json').read_text())
reasons = [
    '火花3至6、污染清零及技能增量已核；现有逐击模型覆盖窄机制，尚缺该局成长、技能收益和完整候选的联合消费者回放，不能整项登记duplicate。',
    '已核两步法恢复负敏、失落退场返4力和后续再夺2敏；缺逐来源被夺量的持久真值及返还与重抢的完整消费者校准，不设固定杀序。',
    '已核加压两次各加4力；当前进阶数据库入口已有，仍缺本局原运行移动表的冻结实际输入、覆甲减层条件与联合消费者校准，不从单败拟房间成本。',
    '已核23上限电击者跨轮力量2至4、攻击17至19且T4才退场；通用成长入口已有，召唤与替换实体完整消费者及替杀序后继未验证。',
    '已核沙虫同指纹换线多12血只多7伤；现有审计是候选预测且执行未验证，缺原答至护栏、SL、重规划的完整实际分段归属及受控整战后继；另有旧金刚杵账本错配。',
    '已核实验体同盘T1实际多损9且少扣7；现有SL对比未认证整线执行，抽弃牌后续与受控整战反事实不足；F33重打获胜反例保留。',
    '阶段清毒、零毒触媒及后得敏捷不倒补23挡已有窄实现；仍缺全部候选施毒、增段攻击、遗忘之魂与重规划后继的联合消费者，不据全败调排序。',
    '已核双蟹同盘T3多损5只多伤3及T1多损8多伤9；缺同抽序完整替线和独立获胜验证，不能以B2零胜并列拟血价或禁付血探索。',
    '已核14轮初挡、临时负9力、火箭57至38至28与脆弱下6挡；单项模型已有，整套条件组合及实际候选兑现的联合消费者仍未认证，固定目标序无整战对照。',
    '两局同盘血价与阶段、敏捷、临减事实已核；原宽项尚缺分段实际执行、逐来源资源和完整后继联合校准，当前局部入口不构成整项live实现证明。',
]
evidence = [
    'DUZUBAJ3A8GP F27 T4/T5；states 274830—274838：污染0/3/3/6，次轮清零；火花6后污染0/6/12/18。',
    '5PM6JAQG6FNQ F39 T4—T6；states 274351/352/354/357/358/362：敏−4→−2→0；失落退场后力−4→0；后续敏−2。',
    'CA5KE8GFJ9X2 F13 T1—T5；states 273237/273252/273263：力0/4/8；原稿喷水11/15/19、弱后11/14，覆甲完整减层条件未隔离。',
    '5PM6JAQG6FNQ F38 T3/T4；states 274308/274313/274317：23上限电击力量2→4、攻击17→19，T3仍活、T4退场。',
    '8JRE1C4H4Z2W F33 首/三试T2；decisions 270216/270282指纹相同；sl-attempts 921/923原始summary：47→44/32，敌326→316/309。',
    'YF0LXT1QSTGG F48 二/三试T1；decisions 271309/271348指纹相同；states 277327→277337及277366→277373：实损0/9，敌净扣45/38。',
    'YF0LXT1QSTGG F48 末试T3—T5；states 277512/277513：111阶段4血4毒→212阶段212血0毒；277519触媒2零毒；277524/277526敏5→6而挡均23。',
    'XP2SL33HT0D9 F33 首/二试T3及首/末试T1；decisions 271992/272040及271982/272195各同指纹；sl-attempts 939/940：T3实际损9/14、两敌净扣24/27；states 278017→278023及278231→278236：损2/10、扣25/34。',
    'XP2SL33HT0D9 F33 末试T2/T4/T5；states 278236/278237：14挡及爪−9力；278249/278252/278253火箭57/38/28；278255偏折后6挡。未把旧提案的早期他局摘要当本批新核实证据。',
    'YF0LXT1QSTGG F48及XP2SL33HT0D9 F33；以上两局四组同指纹和阶段、格挡、临减原帧。历史101局/22次镣铐/50帧船夹板只保留为原稿来源，不声称本批重新全历史认证。',
]
implemented_parts = [
    'combat-plan.ts读取现场vitalSpark；turn-solver.ts按Skill逐次加污染、逐攻击段结算；rollout.ts支持VITAL_SPARK_POWER增长。',
    '当前负力/负敏参与现场牌值；POSSESS_STRENGTH_POWER/POSSESS_SPEED_POWER列为已知能力不等于逐来源返还建模。',
    'monster-db.ts nearestAscension优先精确进阶，无HP/攻击五样本门槛；roomHpCost单独保持ROOM_COST_MIN_N=5。',
    'rollout.ts STRENGTH_GROWTH_POWERS包含HIGH_VOLTAGE_POWER；combat-plan.ts按现场敌人读力量与能力。',
    'silent-sl-comparison和silent-sl-resource-comparison保留预测、当轮差值、死亡样本及重规划边界；execution仍unverified。',
    '同上，原线为护栏后/SL前，actual_turn_result=null；字段不能替代原始Jev答到整回合执行的证据链。',
    'aad2700abed6dff1d66e87fb36aaa6fedb39adf3的silent-phase-current明确零毒/已建能力/持有牌，1d57f9d0dbbb63603e9ce9768e74cb2021478464另列阶段结束参考；f3dea91880600bc2e7228268a110a644531738f7传播苦无后继敏捷。',
    'SL当前B2/rollout门槛与原排名保留；候选资源比较有窄接线，但不是两线整战实结。',
    'passive-pieces有船夹板T2=14；当前模型含临减、朝向、虚弱、脆弱和敏捷；68711002f15b298b8863d2258ee5da236da151d2仅特定爪取整条件。',
    '1698adc96ba434a46942321e0237b70657e625b2资源对比和上述阶段/苦无路径均为base与live祖先；不合并成宽项implemented。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(assigned, reasons)]
assert [v['id'] for v in results] == dispatch['proposal_ids']
notice = {
    'proposal_id': assigned[4]['id'], 'batch': BATCH, 'character': 'silent',
    'original_proposal_sha256': assigned[4]['proposal_sha256'],
    'kind': 'provenance-disagreement',
    'claim': '原578e提案将silent-vajra-opening-strength对应silent-0016。',
    'finding': 'silent-0016的原add与当前claim均为护喉甲覆甲，where.experience原链接silent-gorget-plating；不能用它证明金刚杵力量。',
    'experience_ids': ['silent-vajra-opening-strength', 'silent-gorget-plating'],
    'evidence': ['silent-proposal-578e415a259e6835.original.md', 'ledger-selected.json', 'experience-selected.json'],
    'recommendation': '运维核本报告后，经既有ops→watcher→Roy通知原文；后续只用CLI追加正确账本链接，保留原提案和首证，不把数据纠错当策略收益。',
    'delivery': '待运维接续；本批仅在授权scratch和ledger追溯中保存，未写根通知状态或代填任何ACK。',
}
(OUT / 'provenance-question.json').write_text(json.dumps(notice, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 静默猎手A10十项派发提案复核

批次：{BATCH}；基线：{BASE}。
来源任务与实现任务：各原postmortem/experience-update提案 → 本次strategy-proposal。
本批是普通消费队列；六个派发局与十个proposal_ids已核绑定，无research_request、implementation_request或proposal_repair，不承接旧手动专题。
开工工作树干净，git merge --no-edit main返回Already up to date。当前不改源码、知识、权重或调度状态。

本批逐项复核后十项保留waiting。已证窄机制与既有代码分别列出；没有新增经完整验证的策略参数，也未发现需要重复提交的窄源码补丁。所有同盘SL尝试仍按来源局分组，不能扩大独立样本。以下消费者缺口不能靠新增“已执行”字段或未验证数值填平。

授权：Roy-2026-10-07-learning允许证据充分的规则修正；本批限制来自各项所列证据/实现校准缺口，没有因旧规则由Roy制定而转审批。

'''
parts = [intro]
for i, (p, reason, ev, existing) in enumerate(zip(assigned, reasons, evidence, implemented_parts), 1):
    parts.append(f'''## {i}. {p['id']}

原摘要：{p['summary']}
账本：{', '.join(p['ledger'])}；原领域：{', '.join(p['domains'])}。
原Markdown：{p['proposal']}；SHA256：{p['proposal_sha256']}。

证据与边界：{ev}
既有实现：{existing}
处置：waiting。{reason}
预期后续行为：{p['summary']} 完整消费者只显示确证事实及未知，保留全部选项与原动作规则；本批没有实施该后续行为。
验证方法：以列明原帧冻结输入，逐步核对候选和实际派发/结算；对抽弃牌、生成、阶段变化及SL恢复终止原候选完整执行归属。缺失原帧不反推未执行结果。若改生产代码，另按固定回放撤源码失败/恢复通过及沙箱入口验证；当前未做源码撤回。
反例：技能也有挡/毒收益；防御替换可能延长存活；YF在F33第二次SL实际获胜余20HP；这些都反对将后场六败推广成禁技能、禁探索或固定击杀顺序。各具体原稿反例保留。
拟合与切分：本批仅六个独立Silent A10来源局作发现/原帧核验，无系数拟合、无独立留出新局、无胜率改善估计。后续策略验证按run_id及时间后移，不能把同档尝试跨训练/验证。
预期影响与回退：本批只有追溯记录，无线上行为可回退；后续若实现，应以独立实际源码提交回退并保留全部失败/原始证据。此处不登记implemented、duplicate或shipped。

''')
parts.append('''## 原稿链接差异与通知交接

578e原稿的“silent-vajra-opening-strength → silent-0016”与账本原add/现claim不一致；0016记录护喉甲覆甲。保留原稿与原id，不改写首证、claim、prior、已上线版本和状态。详见provenance-question.json。这里质疑证据归属，不否定金刚杵经验本身，也不重新生成重复提案。请运维沿ops→watcher→Roy转达；本批未代填投递或已读ACK，报告退出不表示通知完成。

## 共同限制

六局run-config均为+dirty，列出的dirty文件主要是知识与记录；本批没有重建当时完整知识输入，当前源码不等于对原预测的历史复原。19个选定源码/测试叶仅证明本次读取的范围，不能推出全仓库或全部dirty知识等价。四个live文件与本树仅有Roy/Dai历史注释差，已保存补丁，未改写它们。

已有资源比较显式标候选预测与execution=unverified，阶段事实显式不追认已结算毒伤。缺失的实际执行/资源归属必须从原动作与状态联合取得；不由零胜率、死亡封顶或局部净血差推出整场因果。完整替线尚未实打，药水/休息/路线的未选后继也不补造。

对其他角色不做知识读取、参数迁移或行为修改。只用本批六局及其原提案、关联账本、Silent知识，原稿提到其他Silent历史局只保留为来源，没有冒称本批已重新核实。
''')
(OUT / 'proposal.md').write_text(''.join(parts))

manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verification = json.loads((OUT / 'verification-r2.json').read_text())
assert verification['all_checks_passed']
stamp = (OUT / 'report-time.txt').read_text().strip()
report = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
    'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': results, 'report': str(OUT / 'report.md'),
    'questions': [notice],
}
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
table = '\n'.join(f"| {p['id']} | {', '.join(p['runs'])} | waiting | {r} |" for p, r in zip(assigned, reasons))
text = f'''# 本批策略实现回报

时间（先date后落盘）：{stamp}。

结论：十个已领取提案全部完成本轮证据/既有实现核查并保留waiting，没有新源码、提交、live合入或版本。完整逐项论证、层/回合/账本、反例、预期行为及验证方法见proposal.md。不存在main合并冲突或待兜底提交的本批补丁；waiting不作为队列关闭。

基线：{BASE}。git merge --no-edit main在开工时为Already up to date；最终保留此基线，不把后续并行main记录自报成本批源码工作。git状态、diff和指纹验收另存final-worktree.json。

## 身份与范围

本批{BATCH}，character=silent、reason=proposal，工作树与题目一致。只消费dispatch.json中的十个原id，不另领队列；没有手动专题/实现请求。runs.jsonl六个来源均SILENT A10，终局层分别13、39、30、33、48、33，非六场独立SL样本。提案原稿十个SHA已对专用队列核验并逐份保存.original.md。

宿主原launch参数为gpt-6.1-sol、xhigh、service_tier=default，thread=01a14561-ea49-7692-ab6c-72d9d3ab7fa1，见runtime-launch.json。本模型未切换为题面要求的high，亦未独立核实际原生请求模型/服务档；没有修改账号、原线程、模型配置或重启任务，不能将启动参数当实际请求验收。

## 十项处置

| 提案 | 来源局 | 状态 | 具体原因 |
|---|---|---|---|
{table}

code_proposals沿用原CLI十个id。implementation_domains=[]表示本批未新增实际实现；原提案涉及combat/sl/structure，分别保存在assigned-proposals.json，不以领域标签冒称源码完成。没有implemented或duplicate登记，也没有shipped变更。

## 证据及已有实现

共用extract_evidence.py以各流独立source_size截点提取：{sum(sum(s['counts'].values()) for s in manifest)}行，states4062、decisions3941、SL38、config6、run-plans33、brain188、runs6、fight-plans0。各流原始offset/bytes/SHA、身份、计数、输出SHA和源截点保存在evidence/。fight-plans零行只表示该截点未选到本批局，不说明原日志缺失；states/decisions/brain各2条无效原行作为全源扫描诊断保留，不伪装本批证据。

本次分析1033个相关战斗帧；133个原物理行重新按offset/bytes/SHA读取，八流输出SHA和计数全部复核。四组原决策完整fingerprint相等；14项材料检查通过，加初次4项基础检查通过，见verification-r2.json和material-checks.json。这些是资料一致性检查，不是生产测试或新规则效果测试。

首轮材料脚本有两项false：把XP首试尚未结算的278022当T1出口，以及把已施弱的278253当转向38伤的帧。随后核原相邻帧，实际出口278023、转向帧278252；verify_materials.py、verification.json及原stdout永留，r2另存并14项通过。不是产品回归、也不是游戏反例；没有改原数据或把首轮失败覆盖成成功。一次shell入口在执行前因并行树路径消失触发bubblewrap glob扫描失败，原命令重试成功；不是测试失败或源码变更。

source-audit.json记录19个源码/测试叶及live逐SHA：15同字节，4仅历史署名注释不同，原差分.patch保留。1698adc96ba434a46942321e0237b70657e625b2、aad2700abed6dff1d66e87fb36aaa6fedb39adf3、1d57f9d0dbbb63603e9ce9768e74cb2021478464、f3dea91880600bc2e7228268a110a644531738f7、68711002f15b298b8863d2258ee5da236da151d2等六个所核旧提交均为本基线及实际live祖先；它们只证明各自窄能力的已存在来源，不能关闭十项宽父。本次未运行新的模拟、LLM或网络消费者，不借既有测试结果给本基线填绿。

## 记录、通知及验收

旧金刚杵/0016错配已明确写provenance-question.json、proposal.md和本报告；仅提出追加正确追溯，原稿及所有claim/首证/prior/status/version保持。请运维在实收本报告后经原ops→watcher→Roy告知；当前不冒称已送达/已读/Roy已知，通知仍待原链。

ledger-update-input.jsonl只给已关联Silent条目追加where.proposal和note，by=learner:strategy-proposal；既有shipped/proposed状态不降级、不重记机制首证。实际CLI返回、后验和物理行回执保存在ledger-update-*材料中。未新建账本或代码提案，不修改根队列/请求/learn.json或旧done。

无生产源码改动，tsc/vitest/cases均null；未做源码撤回失败/恢复通过，不冒称成功。无git commit，因此无提交前扫描成功声明；报告材料的独立保密扫描另存原输出。没有live锁/刷新/merge/版本登记动作，也没有上线决策日志或规则双通知。原角色行为保持，未运行play、联网、推送、安装依赖或读key、.env、游戏二进制。

本批可回收边界由原调度器验收，本模型未清理自身树、历史原件或未完成提案。

交运维提案绝对路径：{OUT / 'proposal.md'}
最终结构化回报：report.json。报告退出只完成本批复核，十个waiting与通知交付各自继续保留。
'''
(OUT / 'report.md').write_text(text)
updates = []
for ident in sorted({i for p in assigned for i in p['ledger']}):
    relevant = [p['id'] for p in assigned if ident in p['ledger']]
    note = f'批次{BATCH}：本批六Silent A10局核验，关联提案均waiting；无源码/测试/合入/版本，保留原claim/首证/prior/status/version。逐项缺口见{OUT / "proposal.md"}；提案' + ','.join(relevant)
    if ident == 'silent-0016':
        note += '。原578e稿把金刚杵映射到本覆甲条目有误；本条不能作金刚杵证据，保留原稿并交ops→watcher→Roy追加纠错，未代填通知ACK。'
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]}, 'note': note})
(OUT / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(v, ensure_ascii=False) + '\n' for v in updates))
print(json.dumps({'report': str(OUT / 'report.md'), 'proposals': len(results), 'ledger_updates': len(updates)}, ensure_ascii=False))

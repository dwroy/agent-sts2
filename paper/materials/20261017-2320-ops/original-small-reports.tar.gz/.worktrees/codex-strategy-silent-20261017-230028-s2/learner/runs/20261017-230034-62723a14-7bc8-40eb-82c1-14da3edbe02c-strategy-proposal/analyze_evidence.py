"""Audit frozen evidence and retain compact observations, without changing production."""
import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extract_evidence", HERE.parents[1] / "extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(values):
    return {v["power_id"]: v.get("amount") for v in values or []}


def slim(item):
    row = item["row"]
    st = row["state"]
    run, combat = st.get("run") or {}, st.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "run": item["run_id"], "line": item["line"], "offset": item["offset"],
        "bytes": item["bytes"], "sha256": item["sha256"], "ts": row.get("ts"),
        "floor": run.get("floor"), "turn": st.get("turn"), "screen": st.get("screen"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "energy": player.get("energy"), "block": player.get("block"),
        "played": player.get("cards_played_this_turn"), "powers": powers(player.get("powers")),
        "potions": [p.get("potion_id") if p.get("occupied") else None for p in run.get("potions", [])],
        "relics": [{"id": r.get("relic_id"), "stack": r.get("stack")} for r in run.get("relics", [])],
        "hand": [{"index": c.get("index"), "id": c.get("card_id"), "upgraded": c.get("upgraded"),
                  "values": {v["name"]: v.get("current_value") for v in c.get("dynamic_values", [])}}
                 for c in combat.get("hand", [])],
        "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"), "hp": e.get("current_hp"),
                     "block": e.get("block"), "alive": e.get("is_alive"), "move": e.get("move_id"),
                     "powers": powers(e.get("powers")),
                     "intents": [{k: i.get(k) for k in ["intent_type", "damage", "hits", "total_damage"]}
                                 for i in e.get("intents", [])]}
                    for e in combat.get("enemies", [])],
    }


def main():
    manifest_path = HERE / "evidence/evidence-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    identities = json.loads((HERE / "run-identities.json").read_text())
    audit, states, decisions = [], [], []
    for stream in manifest:
        name = stream["stream"]
        path = HERE / "evidence" / (name + ".evidence.jsonl")
        digest = hashlib.sha256()
        counts = Counter()
        with path.open("rb") as records, Path("/home/dw/Projects/agent-sts2/logs", name + ".jsonl").open("rb") as original:
            for encoded in records:
                digest.update(encoded)
                item = json.loads(encoded)
                original.seek(item["offset"])
                raw = original.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                assert json.loads(raw) == item["row"]
                assert extractor.run_identity(item["row"]) == item["run_id"]
                assert item["run_id"] in identities
                counts[item["run_id"]] += 1
                if name == "states":
                    st = item["row"]["state"]
                    assert st["run"]["character_id"] == "SILENT"
                    assert st["run"]["ascension"] == identities[item["run_id"]]["row"]["ascension"]
                    states.append(slim(item))
                elif name == "decisions":
                    r = item["row"]
                    decisions.append({"run": item["run_id"], "line": item["line"], "offset": item["offset"],
                                      "sha256": item["sha256"], **{k: r.get(k) for k in
                                      ["ts", "observed_ts", "floor", "turn", "chosen", "label", "sl_attempt", "result"]}})
        assert digest.hexdigest() == stream["output_sha256"]
        assert all(counts[r] == n for r, n in stream["counts"].items())
        audit.append({"stream": name, "source_size": stream["source_size"], "rows": sum(counts.values()),
                      "counts": dict(counts), "original_bytes_verified": True, "identity_verified": True,
                      "output_sha256": digest.hexdigest(), "invalid_lines": stream["invalid_lines"],
                      "incomplete_lines": stream["incomplete_lines"]})
    write("evidence-verification.json", audit)
    write("states-compact.json", states)
    write("decisions-compact.json", decisions)
    by_run = defaultdict(list)
    for st in states:
        by_run[st["run"]].append(st)
    consumptions = []
    for run, rows in by_run.items():
        for before, after in zip(rows, rows[1:]):
            if (before["floor"], before["turn"], before["screen"]) != (after["floor"], after["turn"], "COMBAT"):
                continue
            lost = Counter(p for p in before["potions"] if p) - Counter(p for p in after["potions"] if p)
            if not lost:
                continue
            observed_actions = [d for d in decisions if d["run"] == run and d["floor"] == before["floor"] and
                                d["turn"] == before["turn"] and before["ts"] <= d["ts"] <= after["ts"] and
                                isinstance(d["chosen"], dict) and d["chosen"].get("action") == "use_potion"]
            consumptions.append({"run": run, "floor": before["floor"], "turn": before["turn"],
                                 "potions": list(lost.elements()), "before_line": before["line"], "after_line": after["line"],
                                 "hand_before": len(before["hand"]), "hand_after": len(after["hand"]),
                                 "shivs_added": sum(c["id"] == "SHIV" for c in after["hand"]) - sum(c["id"] == "SHIV" for c in before["hand"]),
                                 "added_shivs": [c for c in after["hand"] if c["id"] == "SHIV" and c not in before["hand"]],
                                 "hp_delta": after["hp"] - before["hp"], "energy_before": before["energy"], "energy_after": after["energy"],
                                 "decision_lines": [d["line"] for d in observed_actions]})
    write("potion-transitions.json", consumptions)
    ranges = {
        "TXZ6RVMQA09D": [(281545, 281566)],
        "WQZVENQ7DTRP": [(282070, 282088), (282139, 282155), (282292, 282299), (282330, 282336), (282352, 282367)],
        "1913SE84AXQF": [(282740, 282775)],
        "Q6M2Y34MWKRE": [(282800, 282811), (282885, 282907)],
        "NHA2KW0RB7VP": [(283140, 283150), (283390, 283405), (283500, 283525)],
        "K3676LU8B0UH": [(217007, 217012)],
    }
    windows = [st for st in states if any(lo <= st["line"] <= hi for lo, hi in ranges.get(st["run"], []))]
    write("fixed-windows.json", windows)
    by_line = {st["line"]: st for st in states}
    checks = {
        "txz_second_opening": [by_line[281565]["hp"], by_line[281566]["hp"]] == [4, 0],
        "wq_attempt5_capacity": [len(by_line[n]["hand"]) for n in [282292, 282294, 282295, 282296]] == [8, 10, 10, 10],
        "wq_attempt6_capacity": [len(by_line[n]["hand"]) for n in [282352, 282353, 282355, 282357]] == [5, 8, 10, 10],
        "ken_drink_count": len([d for d in decisions if d["run"] == "KEN58SH9SLZ6" and isinstance(d["chosen"], dict) and d["chosen"].get("action") == "use_potion"]) == 7,
    }
    # These are evidence checks, not production test results.
    write("material-checks.json", checks)
    print(json.dumps({"rows": sum(x["rows"] for x in audit), "streams": audit,
                      "checks": checks, "potion_transitions": len(consumptions),
                      "cunning": [p for p in consumptions if "CUNNING_POTION" in p["potions"]]}, ensure_ascii=False))


if __name__ == "__main__":
    main()

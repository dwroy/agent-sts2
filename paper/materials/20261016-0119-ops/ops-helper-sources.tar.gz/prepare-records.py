from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile

root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0119';pub=root/'paper/materials/20261016-0119-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a,cwd=root,data=None):return subprocess.check_output(['git','-C',str(cwd),*a],input=data,stderr=subprocess.PIPE)
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-011301-fix-batch';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/'ops/codex-ops/learner'/(bid+'.out');output=out.read_text();assert json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])==report
scratch=load(s/'report.json');assert {k:v for k,v in scratch.items() if k!='skipped'}=={k:v for k,v in report.items() if k!='skipped'} and len(scratch['skipped'])==len(report['skipped'])==14
assert b['state']=='failed' and b['rc']==0 and not b['proposal_audit_errors']
assert report['fixes']==report['code_proposals']==report['implementation_domains']==[] and report['merged'] is None and report['tests']==dict(tsc=0,vitest=0,cases=69)
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
assert (s/'source.diff').read_bytes()==b''
verification=load(s/'verification.json');assert verification['tsc']==verification['vitest']==0 and verification['files']==9 and verification['cases']==69 and verification['retried'] is False and verification['full_sandbox_suite_run'] is False
assert (s/'tsc.exit').read_text().strip()==(s/'targeted.exit').read_text().strip()=='0'
artifacts=load(s/'artifact-manifest.json')
for path,entry in artifacts.items():
    f=(s/path).resolve();assert f.is_relative_to(root);raw=f.read_bytes();assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
audit=load(s/'audit.json');prior=load(Path(audit['prior_audit']));assert sha(Path(audit['prior_audit']).read_bytes())==audit['prior_audit_sha256']
assert audit['base']==report['base'] and audit['queue_unchanged_since_prior'] and audit['changed_source_paths_since_prior_base']==[]
assert sha((s/'queue-snapshot.md').read_bytes())==audit['queue_sha256'] and len((s/'queue-snapshot.md').read_text().splitlines())==audit['queue_lines']==1342
dispositions=load(s/'queue-dispositions.json');assert audit['unchecked_entries']==len(dispositions)==41 and len(audit['existing_fixes'])==74
leaves={}
for fix in audit['existing_fixes']:
    assert fix['ancestor_in_base'] and fix['ancestor_in_live']
    git('merge-base','--is-ancestor',fix['source_commit'],report['base']);git('merge-base','--is-ancestor',fix['source_commit'],audit['live_read_only_snapshot'])
    for row in fix['files']:
        if row.get('same_as_source'):
            assert sha(git('show',fix['source_commit']+':'+row['path']))==row['sha256']
        previous=leaves.get(row['path'],{})
        assert all(previous[k]==row[k] for k in set(previous)&set(row))
        leaves[row['path']]={**previous,**row}
assert len(leaves)==audit['unique_source_paths']==381
assert all(not x.endswith(('.env','.dll','.pck')) and 'auth.json' not in x and not x.startswith('third_party/') for x in leaves)
assert not git('diff','--name-only',prior['base'],report['base'],'--',*sorted(leaves)).strip()
requests=[(commit,path) for path in sorted(leaves) for commit in [report['base'],audit['live_read_only_snapshot']]]
output_bytes=git('cat-file','--batch',data=''.join(commit+':'+path+'\n' for commit,path in requests).encode());handle=io.BytesIO(output_bytes);blobs={}
for key in requests:
    header=handle.readline().rstrip(b'\n').split()
    if header[-1:]==[b'missing']:blobs[key]=None;continue
    assert header[1]==b'blob';n=int(header[2]);raw=handle.read(n);assert len(raw)==n and handle.read(1)==b'\n';blobs[key]=raw
assert handle.read()==b''
absent=[];different=[]
for path,row in leaves.items():
    a=blobs[(report['base'],path)];z=blobs[(audit['live_read_only_snapshot'],path)]
    assert a is not None and sha(a)==row['sha256']
    assert row.get('same_as_committed_base',True) and row.get('unchanged_since_prior_base',True)
    assert (z is not None)==row.get('present_in_live',True) and (a==z)==row['same_as_live']
    if z is None:absent.append(path)
    elif a!=z:different.append(path)
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,out.read_text(),b['worktree'])
write(pub/'batch-readback.json',dict(batch=bid,original_state=b['state'],original_rc=b['rc'],original_report=report,original_scratch_report=scratch,stdout_skips_abbreviated=True,native=native,unchanged_clean_worktree=True,no_new_fix_or_merge_block=True,original_audit=audit,source381_base_shas_and_original_live_equalities_verified=True,live_absent_paths=absent,live_different_paths=different,original_queue_dispositions=dispositions,original_verification=verification,artifact_hashes_verified=len(artifacts),no_production_tests_reexecuted=True,limits=['Original failed/rc0/mergednull and the original audit missing-live-path error are preserved. The audit correction is not a test rerun or product failure.','Only existing scoped source ancestry/coverage is confirmed; current live leaf differences/absence remain explicit. No wide parent or natural consumer admission is closed.','Resource/steps truncation, historical directory ownership and other lease failures, notification history, controlled model comparisons and independent architecture scope remain unresolved.']))
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([x for x in s.iterdir() if x.is_file()]+[out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);manifest.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',manifest)
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in [p/'prepare-records.py',p/'seal-records.py',p/'readonly-runtime.py']:
        raw=f.read_bytes();copy=p/'helper-scan'/f.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0119原011301-fix空修复回报核，原failed/rc0/mergednull保持，2f719基线/干净WT/HEAD不变，无新源码或提交/合入受阻，不空合/发号/再派。41未勾队列原处置及1342行旧SHA保持；74既有窄修复来源本main/live祖先、381当前base叶SHA及相对旧base无变核，live原缺叶{len(absent)}/差叶{len(different)}分列，不把祖先当逐叶全等或关闭宽父。原tsc0、9文件69定向0/单worker nice19/未重跑/未full及18原件SHA核，不冒完整套件绿；首次审计未处理live缺worktree-storage.test.ts失败原件和更正保留，不当生产bug或测试重跑。当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核；原0332 resources/steps截断根因、目录生命周期/其他租约拒绝及历史通知发送未知沿原owner，不重复队列/研究。仅本人记录提交，未改代码/知识/账本/队列状态，无论文刷新/测试/对局重启/账号home模型额度权限prompt操作。证据paper/materials/20261016-0119-ops/。\n'
note=f'\n- {at} [运维 codex] 原011301修复批次无新增源码或合入受阻，原failed/rc0保留；tsc与9文件69项定向0，仅按原范围记录，不声称完整套件通过。既有修复来源和41条待办边界已核，不重复合入/发号/补测。回执paper/materials/20261016-0119-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as f:f.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,original_state=b['state'],rc=0,existing_sources=74,base_source_leaves=381,queue_entries=41,original_tsc=0,original_targeted_files=9,original_targeted_cases=69,original_targeted_exit=0,no_new_fix_commit_merge_or_release=True,no_tests_reexecuted=True,record_only=True))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()}
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(paths=len(entries),sources=74,leaves=381,no_new_source=True)))

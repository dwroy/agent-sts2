import hashlib
import json
import re
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
OUT = ROOT / 'learner/runs/20261016-011305-73fe3512-3818-470f-8113-e31598405959-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-000032-ad2e0495-b0c3-4fed-a9d4-bc110e2c3e0d-fix-batch'
audit = json.loads((OUT / 'audit.json').read_text())
skipped = json.loads((PRIOR / 'skipped.json').read_text())
log = (OUT / 'targeted.log').read_text()
files = int(re.search(r'Test Files\s+(\d+) passed', log).group(1))
cases = int(re.search(r'Tests\s+(\d+) passed', log).group(1))
tsc = int((OUT / 'tsc.exit').read_text())
vitest = int((OUT / 'targeted.exit').read_text())
assert (tsc, vitest, files, cases) == (0, 0, 9, 69)
verification = dict(tsc_command='nice -n 19 npx tsc -p tsconfig.json --noEmit', tsc=tsc,
    vitest_command='nice -n 19 npx vitest run --pool=threads --maxWorkers=1 tests/learner-startup-recovery.test.ts tests/learner-launch-failures.test.ts tests/learner-entry.test.ts tests/learner-registration-barrier.test.ts tests/ledger-publication-baseline.test.ts tests/silent-paper-krane.test.ts tests/target-options.test.ts tests/feature-notice-registration.test.ts tests/boss-sim-notice-registration.test.ts',
    vitest=vitest, files=files, cases=cases, retried=False, full_sandbox_suite_run=False,
    reason='无源码变更或新增提交；本批运行类型检查与既有修复定向回归，不声称完整沙箱/宿主套件通过。',
    environment='TMPDIR为本任务scratch；PATH添加本地Node；npm离线；unset CHARACTER；单worker/nice19。',
    without_fix_check='不适用：本批没有新增修复，未撤除既有修复，旧红绿结果不冒作本批验证。',
    audit_first_attempt='审计脚本首次未处理live缺少worktree-storage.test.ts，已记录为既有存储差异；修正审计后exit0。不是测试重跑或产品故障。')
report = dict(task='fix-batch', base=audit['base'], fixes=[], skipped=skipped, merged=None,
              tests=dict(tsc=tsc, vitest=vitest, cases=cases), code_proposals=[], implementation_domains=[],
              report=str(OUT / 'report.md'))
lines = ['## 修 bug 回报',
    f"- 合并基线：main → {audit['base']}（开工工作区干净；git merge --no-edit main 返回 Already up to date）。",
    '- 修复（每条一行）：无新增修复。队列1342行与上一批逐字节相同；41条未勾选记录逐项核对为16条已有修复/限定子项、21条策略类、3条证据不足、1条独立框架。74个既有来源均是本main/live祖先，相关381个文件与上一已核基线相同；详细逐项处置见queue-dispositions.json，逐叶SHA及live差异见audit.json。未改源码、队列、账本或测试，未提交；撤源码红绿验证不适用。']
for row in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{row['item']} — 已修，提交 {row['source_commit']}（本批核源码及祖先，只认原限定范围，不将祖先关系冒作当前live逐叶等同）。")
for row in skipped:
    lines.append(f"- 没修的：{row['item']} — {row['reason']}")
lines += [
    '- 测试：tsc退出码0；Vitest定向9文件/69用例/退出码0，无测试重跑；固定输入，无真实LLM或网络调用。无新增提交，未跑完整test-sandbox.sh，不声称完整套件通过。命令及范围见verification.json；原日志tsc.log、targeted.log。审计脚本首次live缺路径错误及更正保留audit-first-attempt.txt，不当产品bug。',
    f"- 合入：未合入（本批无新增源码，不空合；只读live快照{audit['live_read_only_snapshot']}。不新增发布号、部署记录或重复更新shipped账本）。",
    '- 需要 Roy 定的事（没有写「无」）：无。', '', '```json', json.dumps(report, ensure_ascii=False, indent=2), '```', '']
(OUT / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
(OUT / 'skipped.json').write_text(json.dumps(skipped, ensure_ascii=False, indent=2) + '\n')
(OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
(OUT / 'report.md').write_text('\n'.join(lines))
manifest = {path.name: dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for path in OUT.iterdir() if path.is_file() and path.name != 'artifact-manifest.json'}
(OUT / 'artifact-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(report=report['report'], base=report['base'], fixes=0, existing=74,
                      unchecked=41, files=files, cases=cases, tsc=tsc, vitest=vitest, merged=None), ensure_ascii=False, indent=2))

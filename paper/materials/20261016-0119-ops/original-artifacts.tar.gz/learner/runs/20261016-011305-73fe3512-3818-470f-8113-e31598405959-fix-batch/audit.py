import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2')
WT = ROOT / '.worktrees/codex-fix-silent-20261016-011301'
OUT = ROOT / 'learner/runs/20261016-011305-73fe3512-3818-470f-8113-e31598405959-fix-batch'
PRIOR = ROOT / 'learner/runs/20261016-000032-ad2e0495-b0c3-4fed-a9d4-bc110e2c3e0d-fix-batch'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ancestor(commit, head):
    return subprocess.run(['git', '-C', str(WT), 'merge-base', '--is-ancestor', commit, head]).returncode == 0


assert not git('status', '--porcelain')
base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'refs/heads/live').decode().strip()
prior_bytes = (PRIOR / 'audit.json').read_bytes()
prior = json.loads(prior_bytes)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
assert queue == (PRIOR / 'queue-snapshot.md').read_bytes(), '队列有变化，必须重新核读'
dispositions = json.loads((PRIOR / 'queue-dispositions.json').read_bytes())
unchecked = [(n, line) for n, line in enumerate(queue.decode().splitlines(), 1) if line.startswith('- [ ]')]
assert [(d['line'], d['item']) for d in dispositions] == unchecked
existing = []
all_paths = set()
for old in prior['existing_fixes']:
    paths = sorted({old['path']} | {leaf['path'] for leaf in old['source_leaves']})
    commit = old['source_commit']
    row = dict(item=old['item'], source_commit=commit,
               ancestor_in_base=ancestor(commit, base), ancestor_in_live=ancestor(commit, live), files=[])
    for path in paths:
        assert '.env' not in Path(path).parts and not path.startswith('third_party/')
        data = (WT / path).read_bytes()
        live_result = subprocess.run(['git', '-C', str(WT), 'show', f'{live}:{path}'], capture_output=True)
        leaf = dict(path=path, sha256=sha(data),
                    unchanged_since_prior_base=data == git('show', f"{prior['base']}:{path}"),
                    same_as_committed_base=data == git('show', f'{base}:{path}'),
                    present_in_live=live_result.returncode == 0,
                    same_as_live=live_result.returncode == 0 and data == live_result.stdout)
        assert leaf['unchanged_since_prior_base'] and leaf['same_as_committed_base']
        row['files'].append(leaf)
        all_paths.add(path)
    assert row['ancestor_in_base'] and row['ancestor_in_live']
    existing.append(row)
barrier = prior['registration_barrier']
barrier_row = dict(item=barrier['item'], source_commit=barrier['source_commit'],
                   ancestor_in_base=ancestor(barrier['source_commit'], base),
                   ancestor_in_live=ancestor(barrier['source_commit'], live), files=[])
for old in barrier['files']:
    path = old['path']
    data = (WT / path).read_bytes()
    leaf = dict(path=path, sha256=sha(data), same_as_source=data == git('show', f"{barrier['source_commit']}:{path}"),
                same_as_live=data == git('show', f'{live}:{path}'))
    assert leaf['same_as_source'] and leaf['same_as_live']
    barrier_row['files'].append(leaf)
    all_paths.add(path)
assert barrier_row['ancestor_in_base'] and barrier_row['ancestor_in_live']
existing.append(barrier_row)
for row in dispositions:
    if row.get('commit'):
        assert ancestor(row['commit'], base) and ancestor(row['commit'], live)
    row['verification'] = '本批队列逐字节相同；相关源码逐叶核同上一已核基线；已有提交为本基线及live祖先。只认原限定范围。'
audit = dict(base=base, live_read_only_snapshot=live, prior_audit=str(PRIOR / 'audit.json'),
             prior_audit_sha256=sha(prior_bytes), queue_sha256=sha(queue),
             queue_lines=len(queue.decode().splitlines()), queue_unchanged_since_prior=True,
             unchecked_entries=len(unchecked), existing_fixes=existing,
             unique_source_paths=len(all_paths), changed_source_paths_since_prior_base=[],
             limitations=['只确认既有修复限定范围，未关闭宽父或自然消费者验收。',
                          '无新增源码，不执行合入、不补造发布号或shipped账本状态。',
                          '历史目录删除者、通知发送事实及nonpositive-hp根因仍未知。'])
(OUT / 'queue-snapshot.md').write_bytes(queue)
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(OUT / 'queue-dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source.diff').write_bytes(git('diff', '--binary', 'HEAD'))
(OUT / 'changes-since-prior-base.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--', *sorted(all_paths)))
print(json.dumps(dict(base=base, live=live, queue_lines=audit['queue_lines'], unchecked=len(unchecked),
                      existing_fixes=len(existing), source_paths=len(all_paths), changed=[],
                      source_live_differences=sorted({leaf['path'] for row in existing for leaf in row['files'] if not leaf.get('same_as_live', False)})), ensure_ascii=False, indent=2))

import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
states = json.loads((out / "state-frames.json").read_text())
by_line = {f["ref"]["line"]: f for rows in states.values() for f in rows}
checks = []


def check(name, actual, expected, lines=()):
    assert actual == expected, (name, actual, expected)
    checks.append({"name": name, "actual": actual, "expected": expected,
                   "refs": [by_line[n]["ref"] for n in lines], "passed": True})


def frame(line):
    return by_line[line]


def threat(line, enemy=0):
    return sum(i.get("total_damage") or 0 for i in frame(line)["enemies"][enemy]["intents"])


proposals = json.loads((out / "dispatched-proposals.json").read_text())
for proposal in proposals:
    raw = (out / (proposal["id"] + ".original.md")).read_bytes()
    check(proposal["id"] + " 原文指纹", hashlib.sha256(raw).hexdigest(), proposal["proposal_sha256"])

for stream in json.loads((out / "verified-evidence.json").read_text()):
    check(stream["stream"] + " 原始字节及身份复核", stream["verified"], True)

transitions = json.loads((out / "act-transitions-r2.json").read_text())["pairs"]
for pair in transitions:
    check(pair["run_id"] + f' F{pair["before"]["floor"]}跨幕实回', pair["healed"], pair["expected"],
          [pair["before"]["ref"]["line"], pair["after"]["ref"]["line"]])

check("RC 预判后柔嫩净敏1", frame(285223)["powers"]["DEXTERITY_POWER"], 1, [285223])
check("RC 速度药当步净加5敏", frame(285224)["powers"]["DEXTERITY_POWER"] - frame(285223)["powers"]["DEXTERITY_POWER"], 5, [285223, 285224])
check("RC 斗篷实际12挡", frame(285225)["block"], 12, [285225])
check("RC 防御实际补9挡", frame(285227)["block"] - frame(285226)["block"], 9, [285226, 285227])
check("RC 第三攻零伤仍补4被动挡", [frame(285229)["block"] - frame(285228)["block"], frame(285228)["enemies"][0]["hp"] - frame(285229)["enemies"][0]["hp"]], [4, 0], [285228, 285229])
check("RC 次轮临时敏捷层归零", [frame(285230)["powers"].get(k, 0) for k in ["DEXTERITY_POWER", "ANTICIPATE_POWER", "SPEED_POTION_POWER"]], [0, 0, 0], [285230])
check("RC 幻影9层首刀14伤", [frame(285291)["powers"]["PHANTOM_BLADES_POWER"], frame(285291)["enemies"][0]["hp"] - frame(285292)["enemies"][0]["hp"]], [9, 14], [285291, 285292])

check("X 接管首个稳定状态仅进阶之灾", [c["id"] for c in frame(286897)["hand"]], ["ASCENDERS_BANE"], [286897])
check("X 接管首帧实际资源", [frame(286897)[k] for k in ["hp", "block", "energy"]], [23, 16, 3], [286897])
check("X 实饮幽灵新增一层", frame(286898)["powers"]["INTANGIBLE_POWER"], 1, [286898])
check("X 实饮攻击26变1", [threat(286897), threat(286898)], [26, 1], [286897, 286898])
check("X 幽灵后下一轮23血留10挡", [frame(286899)["hp"], frame(286899)["block"]], [23, 10], [286899])
check("X 末T3到T4实损22", frame(286978)["hp"] - frame(286982)["hp"], 22, [286978, 286982])
check("X 夜魇标记未产生次轮存活", [frame(286986)["powers"]["NIGHTMARE_POWER"], frame(286986)["hp"], frame(286987)["hp"]], [3, 1, 0], [286986, 286987])
check("X T4实际16威胁6挡仍差10", [threat(286986), frame(286986)["block"], threat(286986) - frame(286986)["block"]], [16, 6, 10], [286986])
check("X F48毒胜前尚有合法防御牌", {"DEFEND_SILENT", "UNTOUCHABLE"}.issubset({c["id"] for c in frame(286893)["hand"]}), True, [286893])
check("X F48毒胜仍支付9持牌血价", frame(286893)["hp"] - frame(286894)["hp"], 9, [286893, 286894])

check("B 生存者实际使唯一后继消失", [c["id"] for c in frame(286162)["hand"]], [], [286161, 286162])
check("B 生存者给8实际挡", frame(286162)["block"] - frame(286161)["block"], 8, [286161, 286162])
check("B 非实际出拳，丝甲虫未在当步掉血", frame(286162)["enemies"][1]["hp"], 7, [286162])
check("B 当轮净损14", frame(286162)["hp"] - frame(286163)["hp"], 14, [286162, 286163])
check("B 镣铐后石虫7攻", threat(286159), 7, [286159])
check("B 中和后另一甲虫13攻", threat(286160, 2), 13, [286160])

check("7X 喝毒药当步不扣HP", [e["hp"] for e in frame(288470)["enemies"]], [e["hp"] for e in frame(288471)["enemies"]], [288470, 288471])
check("7X 后段毒0变7", [frame(n)["enemies"][2]["powers"].get("POISON_POWER", 0) for n in [288470, 288471]], [0, 7], [288470, 288471])
check("7X 后段下一步实扣7到18", frame(288472)["enemies"][2]["hp"], 18, [288472])
check("7X 已饮仍死亡不当胜线", frame(288472)["hp"], 0, [288472])

check("MTQ T3两入口同HP和手牌", [frame(288806)["hp"], frame(288806)["hand"]], [frame(288899)["hp"], frame(288899)["hand"]], [288806, 288899])
check("MTQ 原线29挡替线19挡", [frame(288811)["block"], frame(288904)["block"]], [29, 19], [288811, 288904])
check("MTQ 原线0损替线8损", [frame(288806)["hp"] - frame(288812)["hp"], frame(288899)["hp"] - frame(288905)["hp"]], [0, 8], [288806, 288812, 288899, 288905])
check("MTQ 替线增加6实际即时伤", sum(e["hp"] for e in frame(288812)["enemies"]) - sum(e["hp"] for e in frame(288905)["enemies"]), 6, [288812, 288905])

check("9Z 末次T10后两张挡非再次翻倍", [frame(288000)["block"], frame(288003)["block"], frame(288004)["block"]], [18, 27, 37], [288000, 288003, 288004])
check("9Z 末次T10实损15", frame(288004)["hp"] - frame(288005)["hp"], 15, [288004, 288005])
check("9Z 死亡帧净扣80非两击反伤预支", frame(288007)["enemies"][0]["hp"] - frame(288008)["enemies"][0]["hp"], 80, [288007, 288008])

resources = json.loads((out / "resource-boundaries.json").read_text())
for run, floor, before, after in [("BTSRF7JL1W1Y", 30, 70, 42), ("XTSV1U9JD34T", 48, 97, 23),
    ("9Z9H2EXKLF3T", 35, 66, 30), ("9Z9H2EXKLF3T", 42, 11, 31), ("9Z9H2EXKLF3T", 45, 31, 7),
    ("9Z9H2EXKLF3T", 47, 7, 27)]:
    r = next(r for r in resources if r["run_id"] == run and r["floor"] == floor)
    check(run + f" F{floor}实际资源链", [r["first"]["hp"], r["last"]["hp"]], [before, after],
          [r["first"]["ref"]["line"], r["last"]["ref"]["line"]])

source = json.loads((out / "source-audit.json").read_text())
check("15源码叶均有实际live祖先", [f["live_ancestor"] for f in source["files"]], [True] * 15)
check("11叶完全相同另4叶保留差异", sum(f["equal"] for f in source["files"]), 11)

result = {"scope": "只读证据材料与源码身份核验，不是tsc/vitest或源码回归测试", "cases": len(checks), "passed": True, "checks": checks}
(out / "material-checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ["scope", "cases", "passed"]}, ensure_ascii=False))

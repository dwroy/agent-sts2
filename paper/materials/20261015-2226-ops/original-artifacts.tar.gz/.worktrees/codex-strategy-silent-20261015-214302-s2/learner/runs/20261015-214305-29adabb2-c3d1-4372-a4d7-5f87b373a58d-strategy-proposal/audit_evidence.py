import collections
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[1]))
from extract_evidence import run_identity


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def ref(item):
    return {k: item[k] for k in ("source", "line", "offset", "bytes", "sha256")}


def powers(holder):
    return {p["power_id"]: p["amount"] for p in (holder or {}).get("powers", [])}


def compact(item):
    s = item["row"]["state"]
    run = s.get("run") or {}
    combat = s.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "ref": ref(item), "run_id": item["run_id"], "floor": run.get("floor"),
        "act": run.get("act_id"), "turn": s.get("turn"), "screen": s.get("screen"),
        "combat": bool(s.get("in_combat")), "hp": player.get("current_hp", run.get("current_hp")),
        "max_hp": player.get("max_hp", run.get("max_hp")), "block": player.get("block"),
        "energy": player.get("energy"), "powers": powers(player),
        "hand": [{"id": c.get("card_id"), "index": c.get("index"), "cost": c.get("energy_cost"),
                  "playable": c.get("playable"), "text": c.get("resolved_rules_text"),
                  "values": {v["name"]: v.get("current_value") for v in c.get("dynamic_values", [])}}
                 for c in combat.get("hand", [])],
        "potions": [{"slot": p.get("index"), "id": p.get("potion_id")}
                    for p in run.get("potions", []) if p.get("potion_id")],
        "enemies": [{"id": e.get("enemy_id"), "index": e.get("index"), "hp": e.get("current_hp"),
                     "max_hp": e.get("max_hp"), "alive": e.get("is_alive"), "block": e.get("block"),
                     "move": e.get("move_id"), "powers": powers(e), "intents": e.get("intents")}
                    for e in combat.get("enemies", [])],
    }


def main():
    manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
    metadata = json.loads((OUT / "runs-metadata.json").read_text())
    verified = []
    states = collections.defaultdict(list)
    decisions = []
    sl = []
    configs = []
    brains = []
    for stream in manifest:
        name = stream["stream"]
        counts = collections.Counter()
        output_hash = hashlib.sha256()
        with (OUT / "evidence" / (name + ".evidence.jsonl")).open("rb") as handle:
            source = None
            for line in handle:
                output_hash.update(line)
                item = json.loads(line)
                if source is None:
                    source = Path(item["source"]).open("rb")
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                assert raw.endswith(b"\n") and hashlib.sha256(raw).hexdigest() == item["sha256"]
                original = json.loads(raw)
                assert original == item["row"] and run_identity(original) == item["run_id"]
                assert metadata[item["run_id"]]["character"].lower() == "silent"
                counts[item["run_id"]] += 1
                if name == "states":
                    s = original["state"]
                    assert not s.get("run") or s["run"]["character_id"].lower() == "silent"
                    states[item["run_id"]].append(compact(item))
                elif name == "decisions":
                    decisions.append({"ref": ref(item), **{k: original.get(k) for k in
                        ("run_id", "floor", "turn", "label", "chosen", "result", "rationale", "expect", "combat_plan", "sl_attempt")}})
                elif name == "sl-attempts":
                    sl.append({"ref": ref(item), **{k: original.get(k) for k in
                        ("run_id", "floor", "attempt", "result", "turns", "end_hp", "end_block", "incoming", "reload", "judge", "summary", "explore")}})
                elif name == "run-config":
                    configs.append({"ref": ref(item), **{k: original.get(k) for k in
                        ("run_id", "floor", "character", "ascension", "code", "brain", "knowledge")}})
                elif name == "brain":
                    brains.append({"ref": ref(item), **{k: original.get(k) for k in
                        ("run_id", "label", "engine", "model", "effort", "answer")}})
            if source:
                source.close()
        assert output_hash.hexdigest() == stream["output_sha256"]
        assert all(counts[k] == v for k, v in stream["counts"].items())
        verified.append({"stream": name, "count": sum(counts.values()), "counts": dict(counts),
                         "source_size": stream["source_size"], "sha256": output_hash.hexdigest(), "verified": True})
    save("verified-evidence.json", verified)
    save("state-frames.json", states)
    save("decision-frames.json", decisions)
    save("sl-frames.json", sl)
    save("config-frames.json", configs)
    save("brain-summary.json", brains)

    transitions = []
    for run, frames in states.items():
        previous = None
        for frame in frames:
            if previous and previous["act"] != frame["act"] and previous["act"] is not None and frame["act"] is not None:
                if previous["max_hp"] == frame["max_hp"]:
                    missing = previous["max_hp"] - previous["hp"]
                    transitions.append({"run_id": run, "ascension": metadata[run]["ascension"],
                        "from": previous, "to": frame, "healed": frame["hp"] - previous["hp"],
                        "expected_observed_formula": missing * 80 // 100,
                        "matches": frame["hp"] - previous["hp"] == missing * 80 // 100})
            previous = frame
    save("act-transitions.json", transitions)

    windows = {
        "RC61MFQM63Y6": {17: {2, 11}, 23: {3, 4}, 29: {3, 4}, 33: {1, 4}},
        "XTSV1U9JD34T": {33: None, 34: None, 36: None, 47: None, 48: {8}, 49: {1, 2, 3, 4}},
        "BTSRF7JL1W1Y": {17: {5, 13}, 30: None, 31: {1, 2, 3}},
        "9Z9H2EXKLF3T": {35: None, 38: None, 39: None, 42: None, 45: None, 47: None, 48: {7, 8, 10, 11}},
        "7X0W3U8TVA2A": {30: None, 31: {1, 13}},
        "MTQ0EUBJ3R6T": {19: None, 20: None, 23: {3, 5, 6}},
    }
    selected = {run: [f for f in states[run] if f["floor"] in floors and
                     (floors[f["floor"]] is None or f["turn"] in floors[f["floor"]])]
                for run, floors in windows.items()}
    save("selected-state-windows.json", selected)
    summary = {"verified_lines": sum(v["count"] for v in verified), "streams": len(verified),
               "runs": len(metadata), "state_frames": sum(map(len, states.values())),
               "selected_state_frames": sum(map(len, selected.values())), "act_pairs": len(transitions),
               "all_act_pairs_match": all(t["matches"] for t in transitions),
               "sl_by_run_floor": dict(collections.Counter(f'{r["run_id"]}/F{r["floor"]}' for r in sl))}
    save("evidence-summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

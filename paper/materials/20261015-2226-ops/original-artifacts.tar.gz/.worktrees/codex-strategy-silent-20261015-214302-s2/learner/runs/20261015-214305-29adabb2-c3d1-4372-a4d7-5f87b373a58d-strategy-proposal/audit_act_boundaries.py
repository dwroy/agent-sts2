import json
from pathlib import Path

out = Path(__file__).resolve().parent
states = json.loads((out / "state-frames.json").read_text())
metadata = json.loads((out / "runs-metadata.json").read_text())
pairs = []
for run, frames in states.items():
    for before, after in zip(frames, frames[1:]):
        if before["floor"] not in (17, 33) or after["floor"] != before["floor"] + 1:
            continue
        assert before["screen"] == "MAP" and after["screen"] == "EVENT"
        assert before["max_hp"] == after["max_hp"]
        healed = after["hp"] - before["hp"]
        expected = (before["max_hp"] - before["hp"]) * 80 // 100
        pairs.append({"run_id": run, "ascension": metadata[run]["ascension"], "before": before,
                      "after": after, "healed": healed, "expected": expected, "matches": healed == expected})
assert len(pairs) == 22 and all(p["matches"] for p in pairs)
result = {"method": "F17/F33 final MAP to F18/F34 first EVENT; act_id switches before healing",
          "supersedes": "act-transitions.json (wrong boundary: act_id changes on the same floor)",
          "pairs": pairs, "count": len(pairs), "all_match": True}
(out / "act-transitions-r2.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"count": len(pairs), "all_match": True, "by_ascension": {
    str(a): sum(p["ascension"] == a for p in pairs) for a in (9, 10)}}, ensure_ascii=False))

import json
from pathlib import Path
import re

out = Path(__file__).resolve().parent
dispatch = json.loads((out / 'dispatch.json').read_text())
rows = json.loads((out / 'dispositions-draft.json').read_text())
proof = json.loads((out / 'source-commit-proof.json').read_text())
receipt = json.loads((out / 'live-merge-receipt.json').read_text())
source = proof['source']
implemented_id = 'silent-proposal-e5ea36df117ca9b7'
for row in rows:
    if row['id'] == implemented_id:
        row['state'] = 'waiting'
        row['reason'] = ('首轮接管事实提示源码已提交' + source +
            '，撤源码3败/4过、恢复7过及完整沙箱通过；live刷新后与整分支预检有10个知识文件冲突，未执行merge。'
            '源提交尚非实际live祖先，待ops定向集成4叶并完成合后验证，不能登记implemented/shipped。')
(out / 'dispositions.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')

tests = {'tsc': 0, 'vitest': 0, 'cases': 4099, 'files': 435, 'scope': 'sandbox',
         'withdrawn': {'exit': 1, 'failed': 3, 'passed': 4},
         'restored': {'exit': 0, 'passed': 7}, 'live': None}
assert (out / 'sandbox.exit').read_text().strip() == '0'
assert (out / 'target-withdrawn.exit').read_text().strip() == '1'
assert (out / 'target-restored.exit').read_text().strip() == '0'
results = [{'id': r['id'], 'state': 'waiting', 'reason': r['reason']} for r in rows]
report = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-214302-s2-strategy-proposal',
          'base': proof['parent'], 'runs': dispatch['runs'],
          'fixes': [{'id': implemented_id, 'commit': source, 'ledger': ['silent-0164'],
                     'summary': '静默A10低语耳环的已持有/买入候选披露首轮接管未建模，保留全部选项及模拟数值',
                     'files': [f['path'] for f in proof['changed_files']], 'live_ancestor': False}],
          'skipped': [{'id': r['id'], 'reason': r['reason']} for r in rows if r['id'] != implemented_id],
          'merged': None, 'version': None, 'tests': tests,
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': ['structure'],
          'proposal_results': results, 'merge_blocked': {
              'reason': receipt['reason'], 'live_before_refresh': receipt['live_before_refresh'],
              'live_after_refresh': receipt['pre_merge'], 'conflicts': receipt['refreshed_overlap'],
              'live_tests': None},
          'report': str(out / 'report.md')}
(out / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

manifest = json.loads((out / 'evidence/evidence-manifest.json').read_text())
scope = json.loads((out / 'scope-source-commits.json').read_text())
text = [
    '# 本批策略实现与未合入回执', '',
    '已实现并提交一项有界信息提示：Silent A10低语耳环的首轮接管未建模，分别送达B3持有遗物事实及购买候选。'
    '源码自测通过，但live知识刷新产生10文件三方冲突，按任务要求停止合入。其余九项缺数据保留。', '',
    f'时间：{(out / "final-recorded-at.txt").read_text().strip()}。',
    f'源码提交：`{source}`；父提交/本批base：`{proof["parent"]}`。工作树干净。',
    f'实际live：刷新前`{receipt["live_before_refresh"]}`，刷新后`{receipt["pre_merge"]}`。'
    '该刷新提交不是本策略合入；源提交不是live祖先，merged=null，无新发布号，无实际上线/自然消费者/入库/大脑采用声称。', '',
    '## 派发与证据边界', '',
    '本批learn.json为task=strategy-proposal、character=silent、reason=proposal，worktree完全匹配，10个proposal_ids全数消费。'
    '没有research_request、implementation_request或proposal_repair。普通专题文件绑定其他旧批，本批不承接专题。'
    '初始git status干净，按普通任务merge main返回Already up to date，base未变。',
    '15个原始runs.jsonl身份均SILENT：本批10锚点加原提案中的9TG1RP5LFAAK、JQPT83P8KDSZ、S9UZAK0JP0C0、7X0W3U8TVA2A、MTQ0EUBJ3R6T。'
    'HMV/F4Q/G403为A9，其余A10；按进阶分列，不读取其他角色专属knowledge或引入预训练事实。',
    '本次只复核这15局。旧113/115/116局分母和各经验全历史统计没有重算，不能把10锚点或15局冒作全历史。'
    '同局SL不增加独立样本。所有16条历史run-config均dirty，当前源码不冒认历史完整运行树。',
    '本学习者原生会话01a13fcd-6816-7871-865e-01c4a6ec03be的turn_context实际为gpt-6.1-sol/xhigh、workspace-write、network_access=false。'
    '正文high与宿主实际xhigh差异保留，未改线程/账号/配置或降低强度；service_tier字段未提供，不据默认值冒称原生已证普通档。'
    '来源与只读元数据见native-session-metadata.json；没有读取auth/key/.env。', '',
    '原提案10份逐SHA匹配，原文不改；源角色/账本原始字段核对，44条账本仅由根CLI追加追溯，后另1条补源码/阻塞回执。'
    'code_proposals CLI按原输入预核去重并返回原e5ea36df117ca9b7，没有另建重复id。', '',
    '## 实现、支持与反例', '',
    '提案：silent-proposal-e5ea36df117ca9b7；账本silent-0164；领域structure。',
    '证据XTSV1U9JD34T F49T1 states:286897：23/97HP、16挡、3能量，手中只有进阶之灾；'
    'F47 states:286839核持有耳环。接管内部动作未记录，不用0挡过渡帧286896代替首个稳定可行动帧。',
    '旧代码把耳环归入已建模的能量遗物，fightStartRelics跳过其未知首轮；B3构筑方法说明由求解器逐回合出牌，'
    '但持有及买入题面没有披露接管缺失。这是当前源码中可直接定位的信息缺口，不需要先拟合遗物价值。',
    '新代码：仅silent A10且已持有耳环时向原relics_not_modelled添加有证据的局限；买入该遗物的候选向原note添加同一局限。'
    '提示区分模型仅计能量、自主模拟开场与实盘可控阶段；明确内部顺序未知。'
    '未实现自动接管推演、未改变模拟数值/预算/排序/选择或原合法动作，铁甲及A9/A11/无遗物保持原行为。',
    'X F49接管后仍3能反驳“一定耗光”；同局持有后仍有胜战，且没有移除耳环或蘑菇的受控胜线。'
    '不禁取遗物，不断言接管导致该败局，不把这一信息提示称为游戏模型已准确或量化学习完成。', '',
    '## 验证', '',
    '- 固定消费者测试7项：真实B3增强函数、已持有/买入两通道、原resolver/options/数值、其他角色/进阶/无遗物边界。'
    '测试用原局固定两帧及标明的人工购买变体；模拟输出固定，不读刷新knowledge、不连网络/LLM。',
    '- 撤掉本次两源码、保留同一测试：退出1，3失败/4通过；恢复原实现字节：退出0，7通过。'
    '见target-withdrawn.log、target-restored.log及对应exit。不是仅撤测试或让导入失败。',
    '- 每次代码提交前agent/tools/test-sandbox.sh退出0：生产tsc通过，434文件/4088项通过，另paths 1文件/11项通过；'
    '合计4099项。未超时，未因无变更重复跑；沙箱固定排除名单仍在，不能当宿主完整套件通过。',
    '- 四个提交文件gitleaks逐文件全内容扫描均0，刷新数据暂存差量另经gitleaks stdin扫描0。git diff --check通过。',
    '- 82项证据材料断言通过，另22424原行逐字节/JSON/身份/offset/bytes/SHA及8流输出SHA复核通过；'
    '这些是材料验证，不计入4099个生产测试。',
    '- 因合前预检已阻塞，没有运行合后live测试，也没有撤销/回退已经合入的策略。live_tests=null。', '',
    '## live预检阻塞与运维接续', '',
    f'在ops/live-merge.lock内等待builders结束，保存现场后按任务提交10个已刷新知识文件为`{receipt["pre_merge"]}`'
    '（Refresh knowledge data，附真实引擎/模型Co-Authored-By）。原两篇未提交notes未修改。',
    '刷新路径与整分支incoming有10处重叠；git merge-tree --write-tree三方预检退出1，逐项CONFLICT (content)。'
    '未执行实际git merge、未覆盖新知识、未制造unmerged index，锁已释放。', '',
]
text.extend('- `' + p + '`' for p in receipt['refreshed_overlap'])
text += ['',
    '运维只需沿原实现任务定向集成本源码提交的4叶，保留刷新数据、其他角色知识、历史Roy/Dai注释和并行notes，'
    '完成新组合合后检查后再登记实际祖先与发布号。源码补丁为source-commit.patch，SHA在source-commit-proof.json。'
    '本报告不把建议接续算作已经派发/收到或实际合入。',
    '实际上线后再date、decision-log/eval登记、根notes/for-roy.md与ops/inbox-dev.md双通知、ops核实shipped。'
    '本轮没有实际上线，因此没有写规则双通知/发布号或标shipped。',
    '回退若后续发布：逆向本次4叶提交，保留所有并行知识刷新、原失败/报告和台账；不回收旧发布号。', '',
    '## 原有窄实现核验', '',
    '以下提交均已核为本轮检查时实际live祖先；仅证明对应子项，不作为整条原提案duplicate/implemented。'
    '15既有源码叶11逐字节相同、4处仅Roy/Dai历史注释差；原差异保留在source-base-vs-live.patch。', '',
]
text.extend(f'- {s["scope"]}：`{s["commit"]}`，`{s["path"]}`。' for s in scope)
text += ['', '## 逐项结果', '']
for r in rows:
    text += [f'### {r["id"]} — waiting', '',
             '账本：' + ','.join(r['ledger']) + '。', '证据：' + r['evidence'],
             '处置/缺口：' + r['reason'], '反例/限制：' + r['counterexample'], '']

text += ['## 证据冻结、勘误和限制', '',
         '| 流 | 原始字节截点 | 选中行数 |', '|---|---:|---:|']
text.extend(f'| {m["stream"]} | {m["source_size"]} | {sum(m["counts"].values())} |' for m in manifest)
text += ['',
    '抽取器身份只认run/run_id/state.run_id/fingerprint.run，一致才接受，不以正文提及分配所属局。'
    '源全局非法JSON行数量为states2、decisions2、brain1，均由入口跳过并保留计数，不能认作本角色身份记录。'
    'fight-plans本字节截点选中0行，只说明该截点未选中，不宣称原日志缺失。未覆盖旧报告或零行材料。',
    '跨幕初稿act-transitions.json误按act_id变化配对，抓到同层MAP转换、尚未回血，False为材料边界错误。'
    '原稿及脚本/log保留；独立audit_act_boundaries.py改为F17/F33最后MAP到F18/F34首EVENT，'
    'act-transitions-r2.json实际22对（A9五/A10十七）全匹配floor(缺血×80%)。不据此外推未知遗物/先古或其他角色。',
    '初始派发查询错误输出父索引，后收窄本批；首次空combat.hand探针IndexError、猜测源码路径不存在、'
    '一次merge-base误把ref文件路径当对象的失败、工具输出截断，以及过宽读取全局工程说明中出现的其他角色清单，'
    '均未用于本角色游戏结论或当作产品bug。未读其他角色专属knowledge。过程原转录由启动器保留。',
    '其余未知：接管动作/抽序、幽灵延后与多层、完整可执行候选及后继、留药或改线整战反事实、独立留出、'
    '逐击毛伤/死亡截断、原dirty树和未观察交互。未拟合新血价/安全线/药价/SL阈值；未执行play、推送或重启对局。',
    '记录位置：proposal.md为运维提案入口，report.md为本报告；dispositions.json/result.json保存逐项处置及机器回执；'
    'evidence/保存所有选中原行及逐行引用，source/原源码副本为.txt；没有全仓归档或展开双份源码。'
    '本源尚未合main/live，不登记完成回收，不删除自身工作树/材料。', '',
    '## 最终JSON', '', '```json', json.dumps(report, ensure_ascii=False, indent=2), '```', '']
(out / 'report.md').write_text('\n'.join(text))

# The original external proposal stays immutable. This is the batch's own implementation addendum.
with (out / 'proposal.md').open('a') as handle:
    handle.write('\n## 最终提交与合入回执\n\n')
    handle.write('源码提交`' + source + '`；完整沙箱tsc/vitest通过4099项。live刷新后`' + receipt['pre_merge'] +
        '`与整分支10个知识文件冲突，合前停止，merged=null。e5ea36df117ca9b7因此仍waiting，未登记implemented/shipped/版本；'
        '其余9项仍为具体证据不足，完整字段见report.md及result.json。\n')
print(json.dumps({'report': str(out / 'report.md'), 'proposal_count': len(results),
                  'source': source, 'merged': None, 'tests': tests}, ensure_ascii=False))

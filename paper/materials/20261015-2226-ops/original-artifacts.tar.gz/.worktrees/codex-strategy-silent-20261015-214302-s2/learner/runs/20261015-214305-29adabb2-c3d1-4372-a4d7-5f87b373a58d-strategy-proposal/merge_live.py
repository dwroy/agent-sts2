import fcntl
import json
from pathlib import Path
import subprocess
import time
import os

out = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
live = root / '.worktrees/live'
source = 'a78bb40ef73af8bb15f40f7fa302dd33a76c2907'
receipt = {'source': source, 'merged': None, 'state': 'pending', 'live_tests': None}


def save():
    (out / 'live-merge-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')


def git(*args, check=True):
    result = subprocess.run(['git', '-C', str(live), *args], capture_output=True)
    if check and result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')[:1000])
    return result


def scan_staged(tag):
    patch = git('diff', '--cached', '--binary').stdout
    with (out / (tag + '-gitleaks.log')).open('wb') as log:
        result = subprocess.run(['nice', '-n', '19', 'gitleaks', 'stdin', '--redact', '--no-banner',
            '--report-format', 'json', '--report-path', str(out / (tag + '-gitleaks.json'))],
            input=patch, stdout=log, stderr=log)
    if result.returncode:
        raise RuntimeError('刷新数据gitleaks未通过，保留扫描回执和暂存现场，不提交')


def run():
    with (root / 'ops/live-merge.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        receipt['lock_acquired'] = subprocess.check_output(['date', '-Iseconds']).decode().strip()
        receipt['live_before_refresh'] = git('rev-parse', 'HEAD').stdout.decode().strip()
        receipt['status_before'] = git('status', '--short').stdout.decode()
        save()
        while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
            time.sleep(10)
        staged = git('diff', '--cached', '--name-only').stdout.decode().splitlines()
        if any(not (p.startswith('knowledge/') or p == 'notes/fight-value-backtest.md') for p in staged):
            receipt.update(state='blocked', reason='live存在非刷新范围的已暂存改动，未触碰暂存区')
            save()
            return
        git('add', 'notes/fight-value-backtest.md', 'knowledge')
        refreshed = git('diff', '--cached', '--name-only').stdout.decode().splitlines()
        receipt['refreshed_paths'] = refreshed
        if refreshed:
            scan_staged('refresh')
            receipt['refresh_commit_time'] = subprocess.check_output(['date', '-Iseconds']).decode().strip()
            message = 'Refresh knowledge data\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
            git('commit', '-m', message)
        pre_merge = git('rev-parse', 'HEAD').stdout.decode().strip()
        receipt['pre_merge'] = pre_merge
        base = git('merge-base', pre_merge, source).stdout.decode().strip()
        incoming = git('diff', '--name-only', base, source).stdout.decode().splitlines()
        receipt['refreshed_overlap'] = sorted(set(refreshed) & set(incoming))
        preview = git('merge-tree', '--write-tree', pre_merge, source, check=False)
        (out / 'live-merge-preview.log').write_bytes(preview.stdout + preview.stderr)
        receipt['preview_exit'] = preview.returncode
        if preview.returncode:
            receipt.update(state='blocked', reason='三方合入预检发现冲突；未执行git merge，刷新数据提交及原live未提交记录保留')
            save()
            return
        merged = git('merge', '--no-edit', source, check=False)
        (out / 'live-merge.log').write_bytes(merged.stdout + merged.stderr)
        if merged.returncode:
            receipt['merge_exit'] = merged.returncode
            conflicts = git('diff', '--name-only', '--diff-filter=U', check=False).stdout.decode().splitlines()
            receipt['conflicts'] = conflicts
            if conflicts:
                git('merge', '--abort')
            receipt.update(state='blocked', reason='实际merge未成功，冲突/原未提交文件阻止合入；没有覆盖刷新数据')
            save()
            return
        integrated = git('rev-parse', 'HEAD').stdout.decode().strip()
        receipt.update(state='testing', integration_commit=integrated)
        save()
        env = dict(os.environ, TMPDIR=str(out))
        with (out / 'live-sandbox.log').open('wb') as log:
            result = subprocess.run(['bash', 'tools/test-sandbox.sh'], cwd=live/'agent', env=env, stdout=log, stderr=log)
        receipt['live_tests'] = result.returncode
        if result.returncode:
            rollback = git('reset', '--merge', pre_merge, check=False)
            receipt.update(state='test_failed', rollback_exit=rollback.returncode,
                rollback_head=git('rev-parse', 'HEAD').stdout.decode().strip(), reason='live组合自测失败，回退到刷新后提交')
            save()
            return
        assert git('merge-base', '--is-ancestor', source, integrated, check=False).returncode == 0
        receipt.update(state='merged', merged=integrated)
        save()


try:
    run()
except Exception as error:
    receipt.update(state='blocked', reason=str(error))
    save()
print(json.dumps(receipt, ensure_ascii=False, indent=2))

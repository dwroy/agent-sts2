from pathlib import Path

p=Path('ops/codex-ops/record-staging/20261015-2226')
s=Path('ops/codex-ops/record-staging/20261015-1650/publish.py').read_text()
s=s.replace('20261015-1650','20261015-2226').replace("source='ba23ca693151fa8c6f7fe035e640dc30f05ccd75';base='ac7dc94915cfc25ea6bd3db16de821b4db4a0c89'", "source='a78bb40ef73af8bb15f40f7fa302dd33a76c2907';base='a24ab305b337de84344000190c7f06c1ad8d59ed'")
s=s.replace("(pub/'20261015-154303-strategy-proposal-readback.json')", "(pub/'strategy-readback.json')")
s=s.replace("['agent/src/reflex/card-model.ts','agent/src/reflex/silent-apotheosis.ts','agent/tests/silent-apotheosis-deadly-poison-evidence.json','agent/tests/silent-apotheosis-deadly-poison.test.ts']", "['agent/src/sim/boss-start.ts','agent/src/sim/build-sim-facts.ts','agent/tests/silent-controlled-opening-evidence.json','agent/tests/silent-controlled-opening.test.ts']")
s=s.replace("assert lh=='fad271855a515e229c7022f5049cc870f95a8d69'", "assert lh=='f92636aec0e099e656eb18d14ef73c7dc266ff55'\n active=subprocess.run(['pgrep','-f','/home/dw/Projects/agent-sts2/(.worktrees/live/)?knowledge/builders/build-'],capture_output=True);assert active.returncode==1")
s=s.replace("path=='agent/src/reflex/card-model.ts'", "path=='agent/src/sim/boss-start.ts'")
s=s.replace("name='V5.silent-apotheosis-deadly-poison1'", "name='V5.silent-controlled-opening-disclosure1'")
old=" for path,raw in livevalues.items():stage(path,raw,le,live)\n bt=git('write-tree',env=le,cwd=live).decode().strip();assert set(git('diff','--name-only',rt,bt,cwd=live).decode().splitlines())==set(paths);behavior=commit(bt,[fresh,source],'Publish observed Silent Deadly Poison Apotheosis upgrade',live)"
new=""" ops_source='798af209b9a268b7dafab1440150f1b39cd5595d';ops_values={};ops_paths=git('diff','--name-only',ops_source+'^',ops_source).decode().splitlines()
 assert len(ops_paths)==3
 for path in ops_paths:
  assert blob(lh,path,live)==blob(ops_source+'^',path)
  raw=blob(ops_source,path);ops_values[path]=raw;mode=git('ls-tree',ops_source,'--',path).decode().split()[0];oid=git('hash-object','-w','--stdin',data=raw).decode().strip();git('update-index','--add','--cacheinfo',mode,oid,path,cwd=live,env=le)
 ot=git('write-tree',env=le,cwd=live).decode().strip();assert set(git('diff','--name-only',rt,ot).decode().splitlines())==set(ops_paths);ops_live=commit(ot,[fresh,ops_source],'Integrate tested learner registration barrier into live',live)
 for path,raw in livevalues.items():stage(path,raw,le,live)
 bt=git('write-tree',env=le,cwd=live).decode().strip();assert set(git('diff','--name-only',ot,bt,cwd=live).decode().splitlines())==set(paths);behavior=commit(bt,[ops_live,source],'Publish observed Silent controlled-opening disclosure',live)"""
assert old in s;s=s.replace(old,new)
start=s.index(" entry={'name':name");end=s.index(';versions={}',start)
entry=""" entry={'name':name,'family':'V5','character':'SILENT','commit':behavior,'release_id':rid,'release_status':'registered-primary-ops','source':at+'; original20261015-214302-s2-strategy-proposal source '+source+'; silent-proposal-e5ea36df117ca9b7/ledger silent-0164. XTSV1U9JD34T Silent A10 F47 and F49T1 stable post-takeover frame:23HP/16block/3energy/only Ascenders Bane; internal automatic actions unrecorded. Old B3 modelled energy without disclosing missing opening control. New held-relic and buy-candidate facts disclose modelled energy versus unmodelled takeover, with unknown internal order and no ban or game-outcome claim. No simulated numbers, legal choices, sampling, ranking, HP/SL/potion, other-character or unobserved-ascension changes. Fixed withdrawn3fail4pass/restored7pass; source sandbox tsc0/434files4088+paths11/gitleaks0 verified, not rerun. Preserve10 original knowledge preflight conflicts, failed/rc0/mergednull and9 waiting proposals. Preserve all live knowledge refresh and historical Dai/Roy comments. Registration barrier798af209 integrated separately as infrastructure, no extra behavior number. Actual combined targeted/host full and natural consumers pending. Rollback only the four source leaves with current-context inverse patch, preserving other releases and knowledge. Evidence paper/materials/20261015-2226-ops/.'}"""
s=s[:start]+entry+s[end:]
s=s.replace('Register observed poison upgrade as','Register observed controlled-opening disclosure as').replace('Integrate exact observed poison upgrade and record','Integrate exact controlled-opening disclosure and record')
s=s.replace("'original_completion_preserved':readback['original_completion']", "'original_completion_preserved':readback['original_report']")
s=s.replace("readback['original_conflicts']['conflicts']", "readback['original_conflicts']['refreshed_overlap']")
s=s.replace("'original10wideproposals':'waiting; narrow source publication does not close them'", "'original_proposals':'earring source ready for mechanical implemented registration; other9 waiting; broad learning/natural consumer remains open'")
s=s.replace("rec={'at':at,", "rec={'at':at,'ops_source':ops_source,'ops_live_commit':ops_live,'ops_live_tree':ot,'ops_paths':ops_paths,")
s=s.replace("  for path,raw in livevalues.items():install(live,path,raw)", "  for path,raw in ops_values.items():\n   install(live,path,raw);os.chmod(live/path,0o755 if path.endswith('.sh') else 0o644)\n  for path,raw in livevalues.items():install(live,path,raw)")
s=s.replace("git('merge-base','--is-ancestor',source,'HEAD',cwd=cwd)", "git('merge-base','--is-ancestor',source,'HEAD',cwd=cwd);git('merge-base','--is-ancestor',ops_source,'HEAD',cwd=cwd)")
s=s.replace("'new_host':'pending single original154303 channel request'", "'new_host':'pending single original214302-fix-batch channel final-combination full; covers both source deltas at exact same tree'")
s=s.replace("'ops: integrate original tested poison upgrade'", "'ops: integrate original tested controlled-opening disclosure'")
(p/'publish.py').write_text(s)

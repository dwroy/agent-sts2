from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261015-2226';pub=root/'paper/materials/20261015-2226-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def load(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
bid='20261015-214302-s2-strategy-proposal';batch=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=batch['report'];scratch=Path(report['report']).parent;source=report['fixes'][0]['commit']
assert source=='a78bb40ef73af8bb15f40f7fa302dd33a76c2907' and batch['state']=='failed' and batch['rc']==0 and report['merged'] is None and batch['proposal_audit_errors']==[]
assert report['tests']['cases']==4099 and report['tests']['tsc']==report['tests']['vitest']==0
assert git('rev-parse','HEAD',cwd=batch['worktree']).decode().strip()==source and not git('status','--porcelain','--untracked-files=no',cwd=batch['worktree']).strip()
assert (scratch/'sandbox.exit').read_text().strip()=='0' and (scratch/'target-withdrawn.exit').read_text().strip()=='1' and (scratch/'target-restored.exit').read_text().strip()=='0'
log=(scratch/'sandbox.log').read_text();assert '434 passed (434)' in log and '4088 passed (4088)' in log and '11 passed (11)' in log
proof=load(scratch/'source-commit-proof.json');assert proof['source']==source and proof['parent']==report['base']
for row in proof['changed_files']:
 raw=git('show',source+':'+row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
assert all(row['exit']==0 for row in load(scratch/'gitleaks-results.json'))
for name in ['gitleaks-0.json','gitleaks-1.json','gitleaks-2.json','gitleaks-3.json']:assert load(scratch/name)==[]
checks=load(scratch/'material-checks.json');assert checks['cases']==82 and checks['passed'] and len(checks['checks'])==82
evidence=load(scratch/'verified-evidence.json');assert sum(row['count'] for row in evidence)==22424 and all(row['verified'] for row in evidence)
fixture=json.loads(git('show',source+':agent/tests/silent-controlled-opening-evidence.json'))
refs=[]
for key in ['pre_boss','after_takeover']:
 row=fixture[key];path=Path(row['source']).resolve();assert path.is_relative_to(root)
 with path.open('rb') as handle:handle.seek(row['offset']);raw=handle.read(row['bytes'])
 assert sha(raw)==row['sha256'] and json.loads(raw)==row['row']
 assert row['row']['state']['run_id']=='XTSV1U9JD34T' and row['row']['state']['run']['character_id']=='SILENT' and row['row']['state']['run']['ascension']==10
 refs.append({key:row[key] for key in ['source','line','offset','bytes','sha256']})
exec((root/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text());native=runtime(bid,report,(root/'ops/codex-ops/learner'/(bid+'.out')).read_text(),batch['worktree'])
inputs=[json.loads(line) for name in ['ledger-trace-input.jsonl','ledger-commit-input.jsonl'] for line in (scratch/name).read_text().splitlines()]
owned=[]
for raw in (root/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(key)==value for key,value in item.items()) for item in inputs):owned.append(raw)
assert len(inputs)==len(owned)==45 and all(set(json.loads(raw))<={'op','id','ts','by','where','note'} for raw in owned)
(p/'owned-learner-ledger.jsonl').write_bytes(b''.join(owned))
source_audit=load(scratch/'source-audit.json');equal=0
for row in source_audit['files']:
 a=git('show',source_audit['base']+':'+row['path']);z=git('show',source_audit['live']+':'+row['path']);assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai');equal+=a==z
assert len(source_audit['files'])==15 and equal==11
for row in load(scratch/'scope-source-commits.json'):git('merge-base','--is-ancestor',row['commit'],source_audit['live'])
write(pub/'strategy-readback.json',dict(batch=bid,original_report=report,source=source,source_checks=dict(tsc=0,sandbox_files=434,sandbox_cases=4088,paths_cases=11,total=4099,exit_code=0),native=native,source_proof=proof,raw_fixture_refs_verified=refs,original_material_assertions=82,original_evidence_rows=22424,material_probes_reexecuted=False,owned_learner_trace_rows=45,original_conflicts=load(scratch/'live-merge-receipt.json'),old_pinned_source_leaves=15,equal_leaves=11,historical_comment_differences=4,original_state_and_mergednull_preserved=True,limits=['Only Silent A10 held/buy disclosure; no takeover sequence model, numerical or ranking changes.','Original act_id draft boundary error corrected to22 F17/33 MAP->F18/34 EVENT pairs; old draft/log retained.','Old dc64 notice and X06 pre-poisoned target evidence remain independent of this narrow7X-only observation window; no withdrawal or new ACK.','Nine broad proposals remain waiting; source implementation does not establish game benefit or complete natural consumption.']))
print(json.dumps(dict(source=source,source_full=4099,native_verified=True,learner_trace_rows=45,original_state_preserved=True)))

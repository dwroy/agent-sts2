from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,tarfile
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-2226';pub=r/'paper/materials/20261015-2226-ops';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def load(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();main=load(pub/'main-integration.json');readback=load(pub/'strategy-readback.json');bid=readback['batch'];report=readback['original_report'];s=Path(report['report']).parent
assert base==main['main'] and not git('diff','--cached','--name-only').strip()
live=r/'.worktrees/live';lh=git('rev-parse','HEAD',cwd=live).decode().strip()
sources=['798af209b9a268b7dafab1440150f1b39cd5595d',main['source']]
for source in sources:
 git('merge-base','--is-ancestor',source,'HEAD')
 result=subprocess.run(['git','-C',str(live),'merge-base','--is-ancestor',source,'HEAD'],capture_output=True);assert result.returncode==1
owned=(p/'owned-learner-ledger.jsonl').read_bytes().splitlines(keepends=True);assert len(owned)==45 and len(set(owned))==45
old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(raw for raw in owned if raw.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('ops_owned_ledger',r/'learner/ledger.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);fold=lambda raw:module.fold([(n,json.loads(line)) for n,line in enumerate(raw.splitlines(),1) if line]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 assert {k:v for k,v in before[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in after[ident].items() if k not in ['where','history','notes']},ident
 for key,values in before[ident]['where'].items():assert all(value in after[ident]['where'][key] for value in values)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
pending=dict(at=at,bundle='20261015-2226-original-two-source-continuation',batches=['20261015-214302-fix-batch',bid],
 sources=sources,current_main=base,live_observed=lh,
 previous_manual='Original learner-merge codex-fix-silent-20261015-214302 event was consumed in this wake. No duplicate immediate manual request queued.',
 block=dict(kind='nonblocking_live_merge_lock_busy',owner_pid=3183615,owner_birth='96654808',owner='original ops/learner_retention.py sweep --apply --limit4',builder_state='Earlier builder has ended; live lock is now held by original retention, not attributed to the former builder.'),
 source_paths=dict(registration=git('diff','--name-only',sources[0]+'^',sources[0]).decode().splitlines(),controlled_opening=git('diff','--name-only',sources[1]+'^',sources[1]).decode().splitlines()),
 live_published=False,release_id=None,host_full_started=False,natural_consumers='pending',
 next_steps=['Use original pending bundle after the existing lock owner naturally releases. Nonblocking guard only; if still busy, retain pending and do not immediately requeue or wait.',
 'Do not rerun publish.py unchanged or re-integrate main. Main already has both exact source ancestors; preserve its parallel records.',
 'In the original live lock, inspect active builders/current live/index and preserve all new knowledge bytes in their own refresh commit. Narrowly integrate3 registration leaves, then4 opening-disclosure leaves with three-way merges preserving historical comments and every other live source/config leaf. Bind both original source ancestors.',
 'Allocate an actual new release_id only for the opening-disclosure behavior after deployment, using the latest complete registry under the lock. Registration sequencing alone does not consume a game behavior number. Add actual old/new/evidence/expectation/rollback dual notices and code/ledger provenance through original CLIs; do not rewrite the failed/mergednull originals.',
 'Run combined fixed fixtures on the actual new live composition; request one precise final-tree host full through original214302-fix-batch channel. The same exact tree can cover both deltas; do not borrow old-tree green or repeat source full.',
 'Validate next natural saved registration/lease and Silent A10 held/buy payload consumers. Do not dispatch a model, restart a game, change accounts/permissions or close broad parents just for validation. Retain both source workspaces until original publication/check/retention gates pass.'],
 prior_request_receipt='paper/materials/20261015-2216-ops/live-continuation-request.log',
 role_receipt='Ops actually read both original reports; no watcher/Roy ACK or published version claimed.')
write(pub/'pending-live-handoff.json',pending)
for task in pending['batches']:write(r/'ops/codex-ops/pending-integrations'/(task+'.json'),pending)
write(pub/'completion.json',dict(at=at,batch=bid,main=base,source=main['source'],earring_source_main_ancestor=True,
 registration_source_main_ancestor=True,original_source_full_cases=4099,original_material_checks=82,original_evidence_rows=22424,
 waiting_for_evidence=9,submitted_waiting_for_live=1,learner_trace_rows=45,new_to_HEAD_rows=len(added.splitlines()),
 protected_ledger_fields_preserved=True,actual_live_publication=False,release_id=None,host_full_started=False,
 original_manual_consumed=True,new_manual_requests=0,current_game_changed=False,source_workspaces_retained=True))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
 files=[path for path in s.iterdir() if path.is_file()]+[s/'evidence/evidence-manifest.json']
 files += [r/'ops/codex-ops/learner'/(bid+extension) for extension in ['.out','.err']]
 for path in sorted(files):
  raw=path.read_bytes();rel=str(path.relative_to(r));archived=len(raw)<600000;artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw),archived=archived))
  if archived:
   copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(path,arcname=rel)
write(pub/'original-artifact-manifest.json',artifacts)
decision=f'\n- {at} 运维codex：2226两事件实际承接；原214302-s2 sourcea78bb40e的Silent A10耳环接管未知提示已窄4叶集成main{base}并绑定原source，原0164/e5ea提案，持有及买入两通道、其他角色/进阶与模拟数字保持源限定；源撤3红4绿/恢复7绿、434文件4088+paths11/tsc0/gitleaks0与两原帧offset字节核。45所属learner CLI仅追溯/源码阻塞链接，全部非追溯fold字段不变，不重复CLI/登记shipped；9项证据waiting和1项待live源保持，未resolve implemented。原22424行/82材料检查、22跨幕配对为学习者有限读回，act_id边界首误及原冲突/failed0/mergednull全部保留；旧dc64既毒目标反证不因本批7X窄窗口撤回或代ACK。原注册修复798af209 main09cec已承继，本轮原manual live续办非阻塞取锁busy，实际owner是原retention sweep PID3183615/start96654808，非前轮已结束builder；未写live/index/知识/版本，live观察{lh}。本策略main{base}知识/版本不变，不把main集成当实际上线；未分号、未启动合后/宿主检查、未新派学习/手动重放/改账号home模型权限prompt或对局。两源统一原pending接续，保刷新/历史注释，之后只按实际live分配行为号和原精确最终树host，原源full不重跑；源WT均保留。证据paper/materials/20261015-2226-ops/。\n'
note=f'\n- {at} [ops 原实现接收/main已集成、live仍待续] 原e5ea/0164耳环提示sourcea78bb40e已main{base}：仅Silent A10持有/买入披露“能量已建模、首轮接管未建模、内部顺序未知”，不改数值/排序或禁取。证据XTS F47/F49T1及固定撤3红/恢复7绿、源4099项通过。9项继续补证waiting，1项源待live；45账本行仅追溯，旧状态/版本不改。原注册屏障源798af209同在main。live续办被原retention PID3183615/start96654808持锁阻挡，非阻塞退出未写live，原failed/mergednull/10知识冲突保留；不预分行为号、不登记shipped或host已启。两源回执/下一步paper/materials/20261015-2226-ops/pending-live-handoff.json；不立即重复排队、不等待锁，不改当前局/账号/模型/权限。\n'
handoff=f'\n- {at} 更新2216原live待办（同原任务，不新派）：earring sourcea78bb40ef73af8bb15f40f7fa302dd33a76c2907已main{base}，注册源798af209同为main祖先。前轮知识builder已结束；本轮原manual的live非阻塞锁被原retention sweep PID3183615/start96654808占用，未写live/版本或启动host。两个pending键同指paper/materials/20261015-2226-ops/pending-live-handoff.json一份合并接续：保当前知识刷新，先窄3注册叶（无游戏号）再窄4耳环叶（实际锁内分独立行为号/双通知），原fixed组合与同树一次host，随后自然消费者。不得原样重跑已集成main的辅助脚本或整枝10知识冲突merge；busy保持pending不立即循环排队。9宽waiting、dc64旧既毒目标通知与其他宽父保持；两源WT暂留。\n'
queue=f'\n- {at} [原注册屏障接续状态更新] 前轮builder已结束，原214302-fix manual这轮受原retention sweep活锁阻挡，仍未合live；798af209与a78bb40e两个已测源均已main，合并接续仅指同一既有父范围，源码/知识/账号对局不重派或重启。原上游目录/历史null租约及0332未知继续原链。待办paper/materials/20261015-2226-ops/pending-live-handoff.json。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note,'notes/for-roy.md':note,'notes/ops-handoff.md':handoff,'notes/fix-queue-v4.md':queue};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as handle:handle.write(text.encode())
helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
 files=[p/name for name in ['readbacks.py','make-publisher.py','publish.py','publisher-first-lock-busy.log','integrate-main.py','prepare-records.py','seal-records.py']]+[r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']
 for path in files:
  raw=path.read_bytes();copy=p/'helper-scan'/path.name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(path,arcname=path.name);helpers.append(dict(path=str(path.relative_to(r)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
dest=p/'final-files';checkledger=dest/'paper/materials/learning/ledger.jsonl';checkledger.parent.mkdir(parents=True,exist_ok=True);checkledger.write_bytes(old+added)
check=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(checkledger)},capture_output=True);(pub/'final-ledger-check.log').write_bytes(check.stdout+check.stderr);assert check.returncode==0
for path in pub.iterdir():
 if path.is_file():values[str(path.relative_to(r))]=path.read_bytes()
entries=[]
for path,raw in values.items():
 copy=dest/path;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));print(json.dumps(dict(main=base,learner_rows=45,new_to_HEAD_rows=len(added.splitlines()),ledger_check=0,live_publication=False,host_started=False,paths=len(entries))))

from pathlib import Path
import hashlib,json,os,subprocess
r=Path.cwd();p=r/'ops/codex-ops/record-staging/20261015-2226';pub=r/'paper/materials/20261015-2226-ops';source='a78bb40ef73af8bb15f40f7fa302dd33a76c2907';sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args,env=None,data=None):return subprocess.check_output(['git',*args],env=env,input=data,stderr=subprocess.PIPE)
assert json.loads((p/'source-gitleaks.json').read_text())==[]
assert not (pub/'main-integration.json').exists()
head=git('rev-parse','HEAD').decode().strip();assert head=='05a49e179172209323b62e1eccb2fa2fb888d55b'
assert not git('diff','--cached','--name-only').strip()
paths=git('diff','--name-only',source+'^',source).decode().splitlines();assert len(paths)==4
index=p/'main-source.index';env={**os.environ,'GIT_INDEX_FILE':str(index)};git('read-tree',head,env=env);leaves=[]
for path in paths:
 parent=subprocess.run(['git','show',source+'^:'+path],capture_output=True);current=subprocess.run(['git','show',head+':'+path],capture_output=True)
 assert parent.returncode==current.returncode and parent.stdout==current.stdout
 if current.returncode:assert not (r/path).exists()
 else:assert (r/path).read_bytes()==current.stdout
 mode,_,oid,_=git('ls-tree',source,'--',path).decode().split(None,3);git('update-index','--add','--cacheinfo',mode,oid,path,env=env);leaves.append(dict(path=path,blob=oid,sha256=sha(git('show',source+':'+path))))
tree=git('write-tree',env=env).decode().strip();assert set(git('diff','--name-only',head,tree).decode().splitlines())==set(paths)
message='Integrate tested Silent controlled-opening disclosure into main\n\nApply only the four exact checked source leaves and bind source '+source+'. Live publication is deferred behind the existing retention owner of live-merge.lock. Preserve all live knowledge, versions, current game and parallel records.\n\nCo-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>\n'
commit=git('commit-tree',tree,'-p',head,'-p',source,data=message.encode()).decode().strip();real=Path(git('rev-parse','--git-path','index').decode().strip()).resolve();lock=Path(str(real)+'.lock');fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);published=False
try:
 assert git('rev-parse','HEAD').decode().strip()==head and not git('diff','--cached','--name-only').strip()
 with os.fdopen(fd,'wb') as handle:handle.write(index.read_bytes());handle.flush();os.fsync(handle.fileno())
 git('update-ref','-m','ops: integrate original controlled-opening source into main','HEAD',commit,head);published=True
 for leaf in leaves:
  target=r/leaf['path'];tmp=p/(Path(leaf['path']).name+'.leaf');tmp.write_bytes(git('show',source+':'+leaf['path']));os.chmod(tmp,0o644);os.replace(tmp,target)
 os.replace(lock,real)
finally:
 if lock.exists() and not published:lock.unlink()
assert not git('diff','--cached','--name-only').strip()
for leaf in leaves:assert sha((r/leaf['path']).read_bytes())==leaf['sha256']
git('merge-base','--is-ancestor',source,'HEAD');git('merge-base','--is-ancestor','798af209b9a268b7dafab1440150f1b39cd5595d','HEAD')
assert git('rev-parse',head+':knowledge')==git('rev-parse',commit+':knowledge') and git('rev-parse',head+':eval/versions.json')==git('rev-parse',commit+':eval/versions.json')
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();receipt=dict(at=at,source=source,before=head,main=commit,tree=tree,leaves=leaves,source_ancestor=True,only_four_checked_source_leaves_changed=True,knowledge_and_versions_preserved=True,registration_source_preserved=True,live_published=False,release_id=None,live_block='nonblocking lock busy: original retention sweep PID3183615/start96654808; no repeated live attempt',host_full_started=False,natural_consumer='pending')
(pub/'main-integration.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(main=commit,source=source,source_ancestor=True,live_published=False,release_id=None)))

import { vi } from "vitest";
import * as rollout from "../src/reflex/rollout.js";
import { rolloutLiveOptions } from "../src/reflex/rollout-live.js";
import { withPotionWorkFixture } from "./apotheosis-potion-fixture.js";

/** Synthetic 5 x 8 receipts for format consumers; no claim about the logged fight's future. */
export function withFullRolloutFactsFixture<T>(run: () => T): T {
  const previous = rolloutLiveOptions.now;
  const replay = vi.spyOn(rollout, "rolloutDecision").mockImplementation((input) => {
    const horizon = input.options?.horizon ?? 5;
    const samples = input.options?.samples ?? 8;
    const lines: rollout.LineEstimate[] = input.plans.map((plan, index) => ({
      plan, order: null, orders: [], tags: [], score: plan.score, currentValue: 0,
      oneTurn: { hpLoss: 10 + index, winProb: 0.5, turns: 1, modelValue: null, value: -30 - index },
      hpLoss: 10 + index, value: -30 - index, enemyHpLeft: 40,
      leaderHpLeft: null, turnsSurvived: horizon, turnsToWin: null,
      deaths: 0, turnsToDeath: null, winProb: 0.5, wins: 0, horizon, samples,
      perTurn: Array.from({ length: horizon - 1 }, (_, turn) => ({
        turn: turn + 2, fighting: samples, loss: { mean: 2, min: 1, max: 3 },
        dmg: { mean: 4, min: 2, max: 6 }, alive: samples, won: 0,
      })),
      valueModelTerminal: -30 - index,
      modelForecast: { oneTurn: { hpLoss: 10 + index, winProb: 0.5 }, rollout: { hpLoss: 10 + index, winProb: 0.5 } },
      basis: { rolloutSamples: samples, horizon, modelN: 100, w: 1, segment: "global", gateN: 100 },
    }));
    return { lines, orders: [], horizon, samples, elapsedMs: 0, degraded: [],
      policyTurns: 0, policyMs: 0, policyNodes: 0 };
  });
  rolloutLiveOptions.now = () => 0;
  try {
    return withPotionWorkFixture(run);
  } finally {
    replay.mockRestore();
    rolloutLiveOptions.now = previous;
  }
}

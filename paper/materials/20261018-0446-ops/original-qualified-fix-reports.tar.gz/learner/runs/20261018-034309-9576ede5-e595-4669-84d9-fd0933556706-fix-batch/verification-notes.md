# 验证记录

- 合并 main 后基线：16b25669a34ec0af96ed0d4ae5cb5f0d43e8b0f5；开工工作区干净，合并无需新增提交。
- 固定队列见 queue-snapshot.md；45 项既有修复全部是基线祖先，212 个执行文件记录在 existing-fix-audit.json，其中 133 个与原提交对象完全一致，其余保留后续修改并核关键接线。格式兼容源码 4c16dab0457a61e22ef06b27e367d146cb99bab3 也已在基线。
- 原宿主失败日志校验见 host-failure-proof.json，SHA256 与原 ops 决定一致。原完整检查失败及后续两题补验不改写为整套通过。
- 本批两项均为测试基础设施修复，局号／层／回合不适用；原证据为 075726 宿主 tree 414ea8b173ca04165fc84193f9828e4b136a17e9。没有新增游戏判断或代码提案。

## Codex 卡住诊断的启动时间

- 使用真实 CodexEngine 的解析、watchdog 和重试逻辑，runAgent 由固定事件替代，不启动 CLI 或模型。
- 新回归精确安排 0／750／1700 毫秒启动，分别检验 1000／1500 毫秒 stall 门槛、两次尝试、首 token／末事件实际时间及最终诊断。
- 最初回归夹具的 0 毫秒定时事件处于测试推进终点，导致新夹具自身超时；改为直接发出零延迟事件并推进全部已排有限定时器。原日志 brain-fixed.log 保留，未改生产时钟、原测试期限或断言语义。
- 有效消融：git stash 只撤 agent/tests/brain-codex.test.ts，保留新增回归。brain-without-fix.log / exit=1，750／1700 毫秒两项失败、零延迟一项通过，失败直接是原匹配器只接受 0 秒。
- git stash pop 恢复后，brain-restored.log / exit=0，两文件六项通过；另一个文件是既有 watchdog 的期限／长思考／外部取消检查。
- 原 CLI 套件仍按固定 sandbox 排除表留给调度器宿主检查；本记录不声称运行了被排除文件。
- learner/ledger.py 按精确条目及 stall 搜索均无对应 bug-infra，不新建账本、不将游戏条目标为 proposed/shipped。

- 第一项完整沙箱：brain-sandbox.exit=0；tsc=0，Vitest 第一段487文件4436项通过，paths一文件11项通过，合计488文件4447项。单worker耗时1813.51秒。类型标注整理后另有 brain-final-targeted.log 两文件六项通过。
- 第一项源码提交：60616b3363596a47ac114584951d08655e135ced；两叶staged gitleaks退出0。
- 时间边界实核：brain-sandbox.exit 文件mtime为04:20:41.524530409，第二项两个新源码首次写入为04:20:41.640954352／04:20:41.641098981，原测试修改为04:20:56.752340117；第一轮完整检查先结束，第二项后写入，第一轮不包含第二项。

## rollout格式消费者的无界求解

- 保留 G8YYU94P2SBB F30 T3 记录板及v1/off两个通道，原格式、历史估计、唯一best、选择与日志断言不删。固定结果仍为5回合×8样本，原30000ms期限不改。
- 仅格式消费者使用合成未来结果；真实当回合计划、liveRollout转换及rolloutFacts输出继续运行。整个原文件使用已有potion-cost-knowledge.json固定模型，未知文件报ENOENT，不依赖刷新数据。
- 新回归让真实未来求解函数一旦被调用就抛错，覆盖0／10000毫秒宿主时钟跳变、原有预算/药水采样设置及成功/异常后的恢复。
- 有效消融只删除rollout-facts-fixture.ts的结果替代实现，保留导出函数、时钟作用域和全部测试；rollout-without-fix.exit=1，两项因试图实际求解而输出unavailable，恢复检查一项仍通过。原函数块和恢复源码均保留。
- 恢复后先验精确格式用例与新回归：rollout-fixed-targeted.exit=0，两文件四项通过，138项是本次定向选择未运行；不将其冒称整个原文件通过。

- 初次整文件恢复验证 rollout-restored.log 退出1（61失败/85通过）：将旧potion快照用于整个历史文件使机制用例缺少后来记录的转换；已撤掉原文件全局fs替换，未改任何机制断言。冻结快照仅在新增rollout-full-facts.test.ts的独立上下文使用；原139项仍走原有入口。该初稿失败与修正分列保留。

- 收窄快照作用域后的整文件验证：rollout-restored-r2.exit=0，3文件146项全部通过（原rollout-live全139项、新回归3项、既有clock4项），未增超时、skip或减少样本。

- 第二项完整沙箱 rollout-sandbox.exit=0；tsc0，第一段488文件4439项通过，paths一文件11项通过，合计489文件4450项，四worker、328.05秒。第二项staged gitleaks0；源码提交2d87f503ab1edcec75a016d490974bd6c1bb54f1。
- 实际live锁内先保留并行Queen发布后的a845988ecd052864f78141f12a11c7c47a44a3ba，再提交7个知识刷新叶为ee57b0c8aa773a7303d404eb98f8a1a03a5c66b8；刷新与本批5个测试文件重叠0，refresh gitleaks0。merge-tree预检18处历史记录/论文/账本冲突，流程退出3，未执行实际源码merge、合后测试、生成器重建、发布号或上线记录；按任务要求停止。
- live-stop-proof.json核实：刷新提交保留、两源码均不是实际live祖先、测试文件未变化、Git index无暂存或MERGE_HEAD。notes/monster-db-check.md原并行未提交记录保留；没有回退/覆盖任何刷新或其他记录。

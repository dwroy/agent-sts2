import json
import re
import subprocess
from pathlib import Path

scratch = Path(__file__).parent
tree = Path('/home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261018-034302')
base = '16b25669a34ec0af96ed0d4ae5cb5f0d43e8b0f5'
first = '60616b3363596a47ac114584951d08655e135ced'
second = '2d87f503ab1edcec75a016d490974bd6c1bb54f1'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip() == second
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree, text=True).strip()
for filename in ('brain-sandbox.exit', 'rollout-sandbox.exit', 'brain-restored.exit', 'rollout-restored-r2.exit', 'rollout-staged-gitleaks.exit'):
    assert (scratch / filename).read_text().strip() == '0', filename
for filename in ('brain-without-fix.exit', 'rollout-without-fix.exit'):
    assert (scratch / filename).read_text().strip() == '1', filename
assert (scratch / 'rollout-facts-fixed.ts').read_bytes() == (tree / 'agent/tests/rollout-facts-fixture.ts').read_bytes()

def summary(name):
    log = (scratch / name).read_text()
    files = sum(int(n) for n in re.findall(r'Test Files\s+(\d+) passed', log))
    cases = sum(int(n) for n in re.findall(r'^\s+Tests\s+(\d+) passed', log, re.M))
    return {'files': files, 'cases': cases}

current = summary('rollout-sandbox.log')
previous_checks = summary('brain-sandbox.log')
assert current == {'files': 489, 'cases': 4450}, current
assert previous_checks == {'files': 488, 'cases': 4447}, previous_checks
merge = json.loads((scratch / 'live-merge.json').read_text())
assert merge['status'] != 'pending'
merged = merge.get('merged') if merge['status'] == 'merged_and_verified' else None
prior = json.loads(Path('/home/dw/Projects/agent-sts2/learner/runs/20261018-021306-a4687a0f-0a61-4671-be4c-f205a3519b0d-fix-batch/report.json').read_text())
skipped = [item for item in prior['skipped'] if item['item'] != 'infra-h0-414-host-fixed-test-stability-20261018']
existing = json.loads((scratch / 'existing-fix-audit.json').read_text())['already_fixed']
existing.append({'item': 'ops-learner-recheck-report-fixes-shape-20261018：描述型fixes格式兼容子项', 'commit': '4c16dab0457a61e22ef06b27e367d146cb99bab3'})
fixes = [
    {'item': 'infra-h0-414-host-fixed-test-stability-20261018：Codex stall测试错误假定0秒启动', 'commit': first, 'test': 'agent/tests/brain-codex-stall-fixture.test.ts', 'fails_without_fix': True},
    {'item': 'infra-h0-414-host-fixed-test-stability-20261018：rollout完整事实格式用例重复执行未来回合求解', 'commit': second, 'test': 'agent/tests/rollout-full-facts.test.ts', 'fails_without_fix': True},
]
tests = {'tsc': 0, 'vitest': 0, **current}
report = {'task': 'fix-batch', 'base': base, 'fixes': fixes, 'skipped': skipped,
          'merged': merged, 'tests': tests, 'code_proposals': [], 'implementation_domains': [],
          'report': str(scratch / 'report.md')}
names = [
    'native stall assertions retain the recorded timestamps after %i ms startup',
    'full facts retain 5 x 8 output without future-turn solving under %i ms host pauses',
]
lines = ['## 修 bug 回报', f'- 合并基线：main → {base}']
for fix, name in zip(fixes, names):
    lines.append(f'- 修复（每条一行）：{fix["item"]} — {fix["commit"]} — 测试 {fix["test"]}:{name} — 去掉修复时失败：是')
for item in existing:
    lines.append(f'- 已被别人修掉的：{item["item"]} — {item["commit"]}')
for item in skipped:
    lines.append(f'- 没修的：{item["item"]} — {item["reason"]}')
lines.append('- 测试：tsc退出码0；Vitest 489文件 / 4450用例 / 退出码0；第一修复提交前488文件4447项/0。有效消融均2失败1通过，恢复分别6项/146项通过。新Codex零延迟夹具初稿超时、rollout全文件套旧快照初稿61失败均已修正并保留，见verification-notes.md；最终完整沙箱无战斗超时重跑，staged gitleaks均0。')
if merged:
    lines.append(f'- 合入：{merged}；合后沙箱退出0，纯测试不增行为发布号。')
else:
    explanation = merge['status']
    conflicts = []
    if explanation == 'blocked_by_merge_conflicts':
        output = (scratch / 'live-merge-tree.log').read_text().splitlines()
        start = next((i + 1 for i, line in enumerate(output) if re.fullmatch('[0-9a-f]{40}', line)), None)
        if start is not None:
            for line in output[start:]:
                if not line.strip():
                    break
                conflicts.append(line)
        (scratch / 'live-merge-conflicts.txt').write_text('\n'.join(conflicts) + '\n')
        detail = f'{len(conflicts)}处历史冲突' if conflicts else '失败（详见live-merge-tree.log）'
        explanation = f'锁内预检{detail}，按要求停止；刷新数据保留于{merge["pre_merge"]}，未执行实际源码merge/合后测试/版本或上线记录'
    lines.append(f'- 合入：未合入；{explanation}。')
lines.append('- 需要 Roy 定的事：无')
payload = json.dumps(report, ensure_ascii=False, indent=2)
(scratch / 'report.json').write_text(payload + '\n')
(scratch / 'report.md').write_text('\n'.join(lines) + '\n\n```json\n' + payload + '\n```\n')
print(json.dumps({'report': report['report'], 'fixes': len(fixes), 'already_fixed': len(existing), 'skipped': len(skipped), 'merged': merged, 'tests': tests}, ensure_ascii=False))

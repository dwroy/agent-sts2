import { basename, resolve } from "node:path";
import { afterEach, expect, it, vi } from "vitest";

vi.hoisted(() => vi.resetModules());
vi.mock("node:fs", async (original) => {
  const { historicalKnowledgeFs } = await import("./historical-knowledge-fs.js");
  const fs = historicalKnowledgeFs(await original<typeof import("node:fs")>());
  const { KNOWLEDGE_DIR } = await import("../src/knowledge/files.js");
  const pinned = JSON.parse(fs.readFileSync(new URL("./potion-cost-knowledge.json", import.meta.url), "utf8"));
  const readFileSync = ((path: Parameters<typeof fs.readFileSync>[0], ...args: unknown[]) => {
    if (typeof path === "string" && resolve(path).startsWith(resolve(KNOWLEDGE_DIR) + "/")) {
      const name = basename(path);
      if (Object.hasOwn(pinned, name)) return JSON.stringify(pinned[name]);
      throw Object.assign(new Error(`ENOENT: fixed facts fixture, ${name}`), { code: "ENOENT" });
    }
    return (fs.readFileSync as (...args: unknown[]) => unknown)(path, ...args);
  }) as typeof fs.readFileSync;
  return { ...fs, readFileSync, default: { ...fs, readFileSync } };
});

import { planCombatTurn } from "../src/reflex/combat-plan.js";
import * as rollout from "../src/reflex/rollout.js";
import { ROLLOUT_BUDGET_MS, rolloutLiveOptions } from "../src/reflex/rollout-live.js";
import { potionMcOptions } from "../src/reflex/potion-mc.js";
import type { AskDecision } from "../src/memory/types.js";
import { logged, loggedEnv } from "./logged.js";
import { withFullRolloutFactsFixture } from "./rollout-facts-fixture.js";

afterEach(() => { vi.restoreAllMocks(); rolloutLiveOptions.now = null; potionMcOptions.now = null; });

it.each([0, 10_000])("full facts retain 5 x 8 output without future-turn solving under %i ms host pauses", (pause) => {
  let wall = 0, futureCalls = 0;
  vi.spyOn(performance, "now").mockImplementation(() => (wall += pause));
  const original = rollout.rolloutDecision;
  vi.spyOn(rollout, "rolloutDecision").mockImplementation(() => {
    futureCalls += 1;
    throw new Error("format consumers must not simulate future turns");
  });
  const clock = () => 123;
  const potionClock = () => 456;
  rolloutLiveOptions.now = clock;
  potionMcOptions.now = potionClock;
  const potionSettings = { samples: potionMcOptions.samples, budget: potionMcOptions.budgetMs };
  const decisions = withFullRolloutFactsFixture(() => ["v1", "off"].map((context) =>
    planCombatTurn(loggedEnv(logged("g8yy-f30-t3"), { jevContext: context as "v1" | "off" })) as AskDecision));
  for (const decision of decisions) {
    expect(decision.kind).toBe("ask");
    const criteria = (decision.jevView?.questions ?? decision.questions)["plan"]!.criteria!;
    const plans = Object.keys(criteria).filter((key) => /^plan\d+$/.test(key));
    expect(plans.length).toBeGreaterThanOrEqual(2);
    for (const key of plans) {
      const facts = JSON.parse(criteria[key]!);
      expect(facts.rollout).toMatch(/^5-turn rollout \(8 samples\)/);
      expect(facts.rollout_turns.split("; ")).toHaveLength(5);
      expect(facts.history_estimate).toMatch(/^further HP loss \d+, win \d+%/);
    }
    expect(plans.filter((key) => JSON.parse(criteria[key]!).rollout_best === true)).toHaveLength(1);
  }
  expect(futureCalls).toBe(0);
  expect(rollout.rolloutDecision).toBe(original);
  expect(rolloutLiveOptions.now).toBe(clock);
  expect(rolloutLiveOptions.budgetMs).toBe(ROLLOUT_BUDGET_MS);
  expect(potionMcOptions.now).toBe(potionClock);
  expect({ samples: potionMcOptions.samples, budget: potionMcOptions.budgetMs }).toEqual(potionSettings);
});

it("restores clocks and the simulator after a failed facts assertion", () => {
  const original = rollout.rolloutDecision;
  const clock = () => 123;
  rolloutLiveOptions.now = clock;
  const potionClock = potionMcOptions.now;
  expect(() => withFullRolloutFactsFixture(() => { throw new Error("fixed assertion failure"); })).toThrow("fixed assertion failure");
  expect(rollout.rolloutDecision).toBe(original);
  expect(rolloutLiveOptions.now).toBe(clock);
  expect(potionMcOptions.now).toBe(potionClock);
});

#!/usr/bin/env bash
set -euo pipefail
task_root=/home/dw/Projects/agent-sts2
task_tree="$task_root/.worktrees/codex-fix-silent-20261018-034302"
task_live="$task_root/.worktrees/live"
task_scratch="$task_root/learner/runs/20261018-034309-9576ede5-e595-4669-84d9-fd0933556706-fix-batch"
task_base=16b25669a34ec0af96ed0d4ae5cb5f0d43e8b0f5
task_branch=codex-fix-silent-20261018-034302
task_source=$(git -C "$task_tree" rev-parse HEAD)
task_before=
task_pre=
task_merged=
task_test=
task_state() {
  python3 - "$task_scratch/live-merge.json" "$1" "$task_source" "$task_before" "$task_pre" "$task_merged" "$task_test" <<'PY'
import json,sys
from pathlib import Path
keys=('status','source','before_refresh','pre_merge','merged','test_exit')
d=dict(zip(keys,(v or None for v in sys.argv[2:])))
Path(sys.argv[1]).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(d,ensure_ascii=False))
PY
}
date
exec 9>>"$task_root/ops/live-merge.lock"
flock 9
while pgrep -f 'knowledge/builders/buil[d]-' >/dev/null; do sleep 10; done
task_before=$(git -C "$task_live" rev-parse HEAD)
if ! git -C "$task_live" diff --cached --quiet; then
  task_state blocked_by_existing_index
  exit 2
fi
git -C "$task_live" status --short > "$task_scratch/live-status-before.txt"
git -C "$task_live" add notes/fight-value-backtest.md knowledge
if ! git -C "$task_live" diff --cached --quiet; then
  git -C "$task_live" diff --cached --binary | gitleaks stdin --no-banner --redact --log-level error > "$task_scratch/live-refresh-gitleaks.log" 2>&1
  git -C "$task_live" commit -m "Refresh knowledge data" -m "Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>"
fi
task_pre=$(git -C "$task_live" rev-parse HEAD)
git -C "$task_live" diff --name-only "$task_before" "$task_pre" > "$task_scratch/live-refreshed-paths.txt"
git -C "$task_tree" diff --name-only "$task_base" "$task_source" > "$task_scratch/source-changed-paths.txt"
if ! python3 - "$task_scratch" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1])
overlap=set((s/'live-refreshed-paths.txt').read_text().splitlines()) & set((s/'source-changed-paths.txt').read_text().splitlines())
(s/'live-refresh-overlap.txt').write_text('\n'.join(sorted(overlap))+('\n' if overlap else ''))
raise SystemExit(bool(overlap))
PY
then
  task_state blocked_by_refresh_overlap
  exit 3
fi
if ! git -C "$task_live" merge-tree --write-tree --name-only "$task_pre" "$task_source" > "$task_scratch/live-merge-tree.log" 2>&1; then
  task_state blocked_by_merge_conflicts
  exit 3
fi
if ! git -C "$task_live" diff --quiet -- knowledge; then
  task_state blocked_by_new_refresh
  exit 3
fi
if [[ $(git -C "$task_live" rev-parse HEAD) != "$task_pre" ]]; then
  task_state blocked_by_concurrent_live_commit
  exit 3
fi
if ! git -C "$task_live" merge --no-edit "$task_branch" -m "Merge fixed fixture infrastructure" -m "Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>"; then
  task_state merge_failed
  exit 4
fi
task_merged=$(git -C "$task_live" rev-parse HEAD)
export TMPDIR="$task_scratch"
export PATH="$HOME/.local/node/bin:$PATH"
export SANDBOX_WORKERS=4
if (cd "$task_live/agent"; bash tools/test-sandbox.sh) > "$task_scratch/live-sandbox.log" 2>&1; then
  task_test=0
else
  task_test=$?
  git -C "$task_live" reset --merge "$task_pre"
  task_merged=
  task_state reverted_after_test_failure
  exit 5
fi
task_record_time=$(date '+%F %T %Z')
printf '%s\n' "$task_record_time"
python3 - "$task_live/paper/materials/decision-log.md" "$task_record_time" "$task_merged" "$task_source" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
line=f'\n- {sys.argv[2]} 静默fix-batch：infra-h0-414-host-fixed-test-stability-20261018两项纯测试修复，Codex诊断按实际trace核时间，rollout格式用固定5×8结果且禁止未来求解；源码60616b3363596a47ac114584951d08655e135ced/{sys.argv[4]}，实际合入live {sys.argv[3]}。证据原075726宿主tree414ea8b173ca04165fc84193f9828e4b136a17e9及固定G8YYU94P2SBB F30 T3；无对应bug-infra账本，不造shipped。撤修复红/恢复绿、源及合后沙箱tsc/vitest0；所有原断言/时限和生产代码保持，不增行为发布号，原宿主失败与宽父保持。\n'
with p.open('a') as f: f.write(line)
PY
git -C "$task_live" add paper/materials/decision-log.md
git -C "$task_live" diff --cached --binary | gitleaks stdin --no-banner --redact --log-level error > "$task_scratch/live-record-gitleaks.log" 2>&1
git -C "$task_live" commit -m "Record fixture stability fixes in live" -m "Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>"
task_merged=$(git -C "$task_live" rev-parse HEAD)
task_state merged_and_verified

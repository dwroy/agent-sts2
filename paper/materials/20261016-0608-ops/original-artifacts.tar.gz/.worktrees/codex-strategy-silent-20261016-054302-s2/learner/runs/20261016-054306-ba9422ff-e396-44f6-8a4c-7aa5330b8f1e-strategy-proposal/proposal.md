# 本批静默猎手十项已领取提案核验

记录时间：2026-10-16T05:56:10+08:00。批次：20261016-054302-s2-strategy-proposal。角色：silent。
基线：`e9b5316c63f2362e728e060cdb56b43123c6ffb8`。仅处理dispatch.json所列十个既有CLI id；无research_request、implementation_request或proposal_repair，不承接其他专题。

## 取证范围与共同限制

先核干净工作树、README、最新STATE、决定末尾及学习协议；普通任务合入main为记录快进，未改源码。十份原Markdown均与队列SHA一致，副本保留为各id.original.md。
仅使用十五局静默证据：本批十锚点与提案原有五个补充来源。runs原字段保留SILENT大小写，规范核对为silent；A1/A7/A9各一局，A10十二局，不能混合拟合。
共用extract_evidence.py八流提取19929行，每流单独冻结source_size；逐行回读原offset/bytes/SHA/JSON及显式所属身份，通过原字节校验。fight-plans为此截点零行，不据此断言日志缺失。
以下是有界实帧、动作和资源链复核，不重算旧105/109局、历史全量统计或原17油灯窗口；相关知识库只作既有声明和缺口定位。无LLM、网络、play或Boss模拟池。
25组固定材料断言与42次狡诈逐步核验不是生产测试、完整候选执行认证或自然消费者验收。跨重规划、弃牌、生成和SL时，净端点不自动归因给整条候选。

## silent-proposal-08eaa60bcc449852

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-resources.md`；SHA256：`4d080ad9b9f1c93bff7bf169d59add7d863db358ca7e05ba10d95cdfb6b31016`。
关联账本：silent-0019、silent-0020。来源任务：experience-update；本次实现任务：strategy-proposal。
证据局/层/回合：KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1–2/F15T1；F12、F16实际回复。
本次核实：七个饮用请求的后继药栏分别减少一瓶，其中三条原回执仍为pending。F12为26/76→53/81，F16为46/81→75/86；不能把回复、SL恢复或零净损当作未花资源。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：继续按实际资源结转；只有在同入口、同预算且实际后继齐备时比较早用/不用/留药。零损已饮药战是不能把零损直接当免费结果的约束。
处置：waiting。具体缺口：缺F15不饮用及同入口、同后继把药留到Boss的完整成对结果；七次实际消耗和两次回复不能校准持药价值。

## silent-proposal-92920295a648b540

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-214301-postmortem/proposal-sl-continuation-validation.md`；SHA256：`f9d04951c404f2d568d492c633e8baeb7ca5b4bee6826e20e9d5c2348c739bbf`。
关联账本：silent-0228、silent-0255。来源任务：postmortem；本次实现任务：strategy-proposal。
证据局/层/回合：TXZ6RVMQA09D A10 F48第二/三试T6–7、第三试T10及F49开场。
本次核实：同指纹T6原线48→45、敌460→424；替线48→48、敌460→433。实少损3也少扣9；首战奖励4血，F49零能量空手4血过渡到0血，敌仍111。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：固定核首胜、剩余HP/药/复活、后战开场及可操作性；不得用1200首胜/后败模拟放宽必死判据。首胜后开场死是只验首战改善的反例。
处置：waiting。具体缺口：缺保持抽序、生成牌、药栏和后续选择一致的两战完整替线；已存在的连战/开场实现不能证明SL资源比较已校准。

## silent-proposal-a327449c331efbc1

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-221303-postmortem/sl-tradeoff-proposal.md`；SHA256：`e52c156a500b9e5f9d35e7b7e6922a91ee893b16576bc7d11f14e179c2e6a925`。
关联账本：silent-0079、silent-0018。来源任务：postmortem；本次实现任务：strategy-proposal。
证据局/层/回合：WQZVENQ7DTRP A10 F33第二/三试T9–10，以及第二/末试T7–8。
本次核实：T9同指纹原线损13/敌净扣24，替线损22/净扣39；T7原线损0/净扣24，延长线损4/净扣24，下一轮沙坑余量3对4（当步4→5后再递减）。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：继续同时列即时血价、伤害、毒与沙坑；不固定总保血，也不把全败模拟并列当相同安全。T7支付4血延长是对一律禁止付血的约束。
处置：waiting。具体缺口：缺攻防和沙坑两边界的完整受控后继、跨重规划的候选执行归属及独立胜局；9血换15伤不能确定新SL阈值。

## silent-proposal-a099e89437e942bb

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-cunning-capacity.md`；SHA256：`e02b6c6c93defbea23d60a515bf17be3c1c6ac3d3b47dd0e6da647cea92910c2`。
关联账本：silent-0030、silent-0257、silent-0258。来源任务：experience-update；本次实现任务：strategy-proposal。
证据局/层/回合：九个已核静默来源局42饮；重点WQZVENQ7DTRP A10 F33第5/6试T11。A7、A9、A10分列。
本次核实：逐次核37次添3、2次添2、3次添0；115张新增牌均为升级小刀、Damage.base_value=6，药栏减一，饮用端点HP/能量/敌状态不变。第5试2/0/0，第6试3/2/0。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：保留当前已证实生成分支；需要能定位每张生成牌和保留牌、追踪喝药—出刀—再喝及恢复后的整候选后继。满手耗瓶无新增是约束，未有穿插胜局。
处置：waiting。具体缺口：确定生成与容量已有live子实现；仍缺计划妥当保留容量、出刀穿插、跨重问整候选派发和SL恢复的联合校准，42饮不能关闭整项。

## silent-proposal-47910f82a1fdd98f

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-223544-experience-update/proposal-continuation-sl.md`；SHA256：`d4ff2c80c60bdac273fbce918109b0a4634484006ec7e3b6b4516b9afede51bd`。
关联账本：silent-0018、silent-0019、silent-0020、silent-0021、silent-0025、silent-0079、silent-0198、silent-0228、silent-0255。来源任务：experience-update；本次实现任务：strategy-proposal。
证据局/层/回合：TXZ6RVMQA09D A10 F48T6、F49开场；WQZVENQ7DTRP A10 F33T7/T9。
本次核实：四血连战入口与SL双向代价均重核；现有silent-opening只在已观察组合建模，不能向未知回血/复活组合外推。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：继续把入口自损、真实回复、SL恢复和已兑现毒分源；不能预支开场后才可能执行的药或能力。用原两个SL方向约束后续参数学习。
处置：waiting。具体缺口：四血开场已有live子实现；仍缺留药、路线、SL的完整后继对照和未知回血/复活组合的结算顺序，联合要求保留。

## silent-proposal-f1374df72d8e6a25

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-224302-postmortem/proposal-resource-value.md`；SHA256：`df1e14ed2c6b4b31c1dcbd1bd373702cff34a58332d4aab60f7e31dc44b395a0`。
关联账本：silent-0019、silent-0020、silent-0050、silent-0253。来源任务：postmortem；本次实现任务：strategy-proposal。
证据局/层/回合：1913SE84AXQF A10 F17/F19/F23/F24/F28–31；Q6M2Y34MWKRE A10 F2/F7–9。
本次核实：1913首王58→14、幕间58，后两战58→44→40，F24锻造仍40，F28回61，F29赢后46，F31以虚弱/复制入场而死；Q6休36→57、精英胜留2，下一走廊死。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：只核真实退出资源和临时/持续药效；Q6 F5/F6确实零损留药且最终喝药，不因前战候选更省血就认定全局应早喝或能够通关。
处置：waiting。具体缺口：缺隔离机制误差后的同入口、同预算不用/早用/留药的整战及下一战成对结果；未执行早喝候选和两条失败资源链不能拟合新权重。

## silent-proposal-38a49e6c97f31eea

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-mechanisms.md`；SHA256：`6a07471e9049744900d49529a939a7014fb686810a0d7983e6c35eb65b5e8cb0`。
关联账本：silent-0006、silent-0011、silent-0025、silent-0044、silent-0050、silent-0064、silent-0133、silent-0253、silent-0259、silent-0261、silent-0262。来源任务：experience-update；本次实现任务：strategy-proposal。
证据局/层/回合：Q6M2Y34MWKRE A10 F8T4、F9T2；1913SE84AXQF A10 F31T2–4。
本次核实：Q6紧勒链敌103→95→85→85→83，毒结后80；已完成弃牌后才多扣2。1913弃磨蚀能量3不变而建1敏/4荆棘，T3双挡12仍损5；T4中段重接25且无旧毒/2力，雾3已建但无下一轮。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：保持普通无挡模板与不确定分支的边界，不把升级、叠层、自动重放或未触发能力补成已验证。逐击中间帧不足时保留毛伤/净损未知。
处置：waiting。具体缺口：普通紧勒已有live窄实现；仍缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准和受控整战后继。

## silent-proposal-ef0e38a5dbd3bc07

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-234302-experience-update/proposal-resources.md`；SHA256：`d37416e85fd4f9331fc5f652f5838eae9b528a76fe45b9c10aac07acfd572da5`。
关联账本：silent-0019、silent-0020、silent-0021。来源任务：experience-update；本次实现任务：strategy-proposal。
证据局/层/回合：1913SE84AXQF A10 F24/F28–31；Q6M2Y34MWKRE A10 F3/F7–9。
本次核实：资源链核F24无回复、F28加21、F31入口46；Q6事件44→36、营火36→57、精英赢57→2，空药2血接下一战实际死亡。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：只计已到节点/已完成回复和本战已建能力，不预支未来第三火；路线条件改变分账，保留休息后仍败及零损留药的约束。
处置：waiting。具体缺口：缺另一营火、事件、路线和用药时机的受控完整结果；实际资源链只核兑现，不能据两败拟合路线或终局权重。

## silent-proposal-7f820c02d39bfaea

原提案：`/home/dw/Projects/agent-sts2/learner/runs/20261007-234302-postmortem/proposal-saturated-sl.md`；SHA256：`bee54fe85711a177349f927c21f184b7112308ead5c74708b8f3b0b183ecf105`。
关联账本：silent-0079。来源任务：postmortem；本次实现任务：strategy-proposal。
证据局/层/回合：NHA2KW0RB7VP A10 F33第1–6试T1–2；决策277248/277250/277272/277274。
本次核实：首轮原线30→29、敌总408→400；第5/6试30→23、敌总408→384，实多付6血、多净扣16，两侧均活。初题精确切击随后被弃，后重规划必须另列。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：保留原答、护栏、SL与真实执行的分段记录；现有诊断actual_turn=null不算执行认证。第3试T2转向后实际损6不由初题15损替代。
处置：waiting。具体缺口：缺同预算饱和排序校准、跨弃牌的整候选执行归属和成对完整后继；同局六次失败及1/7血价差不足确定新SL门槛。

## silent-proposal-04b6b430759815ed

原提案：`/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-004303-experience-update/proposal-mechanisms.md`；SHA256：`188d4daee0970bba6b59aa7c3498d9da76ef31aac4a42c69be2a86192cadab58`。
关联账本：silent-0005、silent-0006、silent-0021、silent-0011、silent-0065、silent-0264、silent-0079、silent-0133、silent-0169、silent-0189、silent-0013、silent-0053、silent-0162、silent-0265。来源任务：experience-update；本次实现任务：strategy-proposal。
证据局/层/回合：K3676LU8B0UH A1 F30T2；SADL3CGYTGSR A7 F45T1；NHA2KW0RB7VP A10 F17T1、F33T1/T2。
本次核实：本批直接复核九个施放端点：K367实际目标BOWLBUG_NECTAR的毒0→8，SAD目标THE_FORGOTTEN的毒0→10，NHA首毒0→10及六次X1萎靡各减2力/建2弱；六试不算六独立局。蟹朝向已有局部修正。
旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。
候选行为、反例约束与验证要求：只保留已观察目标和数值；需明确首次负面消费来源、当前X与实际目标，并验证生命周期。持有/建立/后继兑现分账，不因额外毒或局部朝向伤害差宣称救局。
处置：waiting。具体缺口：缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，未覆盖X值、升级组合及能力整战后继；九端点不能认证原17窗口或全组合。

## 当前已有源码与后续验收

核对时live为`e716bd28fd8eca9e4d76d066680304fd11935e37`。所查13个源码叶10个逐字节相同；card-model、sl/explore、sl/judge的三个差异仅既有Roy/Dai注释，原差异保存base-live-relevant.diff.patch，不改写为逐字节全等。
以下原始源码提交均已核为本基线及实际live祖先；仅作既有子功能来源，不登记本批implemented、duplicate、shipped或新发布：

- `6403fdcdadc803a092beb5165a068e22bf51c412`：Model observed Silent Cunning Potion generation and hand capacity。
- `5c7105ff0294466da8319f2934beda05c6040794`：Model observed ordinary Strangle losses for Silent。
- `e8b4bb320ae3068db5ebb6ce8c6fa91a9689178a`：Model observed Silent opening HP loss in continuous fights。
- `be69855995737d6f381adb10bf248964832da24b`：Audit predicted Silent combat selections before and after SL。
- `f1542578594462e9f9f4e175488795fc480a8a13`：Log Silent A10 HP guard candidate predictions。
- `e1a467e18a0dfa8d99046a24ff4c0e1af59278c8`：feat(silent): value resources and simulate continuous A10 bosses。
- `ec29ea34b919344b707e57ba472ea210f9c39d62`：Fix observed Silent Crusher facing rounding。

## 拟合、预期影响与回退

不拟合新参数。本批固定帧仅核观察和既有实现边界；将来必须按独立run和开始时间切分较早训练/较晚验证，同局所有SL同组，保留原答、覆盖、请求回执、实际动作及退出资源。未实打替线保持未知，不以模拟样本充当独立局。
如补到具体确定机制缺口，仍须以原id关联固定输入、撤源码应失败/恢复后通过与沙箱检查；价值与门槛调整还须有隔离机制误差的完整后继校准。改变实际规则再履行live、版本与Roy双通知。
本次预期仅提高追溯准确性；没有实盘收益或已入库消费者声称。没有新策略可回退，当前代码与知识不动；未来实现只撤其隔离提交，保留并行知识刷新、旧提案、失败记录和证据。
十五局run-config均有可定位的完整源码commit，所列dirty_files仅knowledge/或notes/；准确限制是未还原当时刷新知识/移动表字节及联合消费者，不笼统声称源码commit不可定位。

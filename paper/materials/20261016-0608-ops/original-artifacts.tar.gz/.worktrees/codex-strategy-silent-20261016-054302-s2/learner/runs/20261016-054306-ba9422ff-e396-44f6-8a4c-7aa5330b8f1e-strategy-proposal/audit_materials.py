"""Verify frozen evidence bytes and project bounded observations; no game simulation."""
import collections
import hashlib
import json
import pathlib
import sys

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('/home/dw/Projects/agent-sts2')
sys.path.insert(0, str(ROOT / 'learner'))
from extract_evidence import run_identity


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def ref(item):
    return {k: item[k] for k in ('source', 'line', 'offset', 'bytes', 'sha256', 'run_id')}


def snap(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'source_line': item['line'], 'observed_ts': item['row'].get('observed_ts'),
        'floor': run.get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
        'hp': player.get('current_hp', run.get('current_hp')), 'max_hp': run.get('max_hp'),
        'block': player.get('block'), 'energy': player.get('energy'),
        'powers': {p['power_id']: p.get('amount') for p in player.get('powers', [])},
        'potions': [p.get('potion_id') for p in run.get('potions', []) if p.get('occupied')],
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'), 'upgraded': c.get('upgraded'),
                  'dynamic_values': c.get('dynamic_values')} for c in combat.get('hand', [])],
        'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'),
                     'powers': {p['power_id']: p.get('amount') for p in e.get('powers', [])},
                     'move': e.get('move_id'), 'intents': e.get('intents')} for e in combat.get('enemies', [])],
    }


manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
allowed = set((OUT / 'run-ids.txt').read_text().strip().split(','))
streams = {}
verified = []
for part in manifest:
    name = part['stream']
    evidence = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    items = []
    counts = collections.Counter()
    with (ROOT / 'logs' / (name + '.jsonl')).open('rb') as source, evidence.open('rb') as selected:
        for encoded in selected:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['source'] == str(ROOT / 'logs' / (name + '.jsonl'))
            assert item['run_id'] in allowed and run_identity(item['row']) == item['run_id']
            assert 0 <= item['offset'] < item['offset'] + item['bytes'] <= part['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n') and hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            if name == 'states':
                run = item['row']['state'].get('run') or {}
                assert run.get('character_id', '').lower() == 'silent'
            counts[item['run_id']] += 1
            items.append(item)
    assert digest.hexdigest() == part['output_sha256']
    assert {r: counts[r] for r in allowed} == part['counts']
    verified.append({'stream': name, 'source_size': part['source_size'], 'verified_rows': len(items),
                     'sha256': digest.hexdigest(), 'counts': dict(counts)})
    streams[name] = items
save('raw-byte-verification.json', verified)

states_by_key = collections.defaultdict(list)
for item in streams['states']:
    row = item['row']
    states_by_key[(row.get('observed_ts'), row.get('fingerprint'))].append(item)


def matched(decision):
    row = decision['row']
    found = states_by_key[(row.get('observed_ts'), row.get('fingerprint'))]
    return found[0] if len(found) == 1 else None


decisions_by_run = collections.defaultdict(list)
for item in streams['decisions']:
    decisions_by_run[item['run_id']].append(item)

potion_observations = []
for run, items in decisions_by_run.items():
    for i, item in enumerate(items):
        row = item['row']
        if (row.get('chosen') or {}).get('action') != 'use_potion':
            continue
        before = matched(item)
        following = items[i + 1] if i + 1 < len(items) else None
        after = matched(following) if following else None
        potion_observations.append({
            'decision': ref(item), 'floor': row.get('floor'), 'turn': row.get('turn'),
            'attempt': row.get('sl_attempt'), 'reloads': row.get('sl_reloads'),
            'potion': (row.get('expect') or {}).get('potion'), 'chosen': row.get('chosen'),
            'result': row.get('result'), 'next_decision': ref(following) if following else None,
            'source_decisions_adjacent': following is not None and following['line'] == item['line'] + 1,
            'before': snap(before) if before else None, 'after': snap(after) if after else None,
            'scope': '相邻已记录动作的状态端点；pending、跨轮、重试或缺帧不自动认证单动作因果',
        })
save('potion-observations.json', potion_observations)

decision_lines = {275383, 275384, 275385, 275894, 275960, 276139, 277248, 277250, 277272, 277274}
selected_decisions = []
for item in streams['decisions']:
    row = item['row']
    if item['line'] in decision_lines or (
        item['run_id'] in {'TXZ6RVMQA09D', 'WQZVENQ7DTRP', 'NHA2KW0RB7VP', 'Q6M2Y34MWKRE'}
        and (row.get('sl_explore') or row.get('hp_guard'))):
        selected_decisions.append({
            'reference': ref(item), 'row': {k: v for k, v in row.items() if k != 'agent_view'},
            'state': snap(matched(item)) if matched(item) else None,
        })
save('selected-decisions.json', selected_decisions)

state_lines = set(range(281563, 281567)) | {282075, 282144} | set(range(282330, 282337))
selected_states = []
for item in streams['states']:
    state = item['row']['state']
    run = state.get('run') or {}
    if item['line'] in state_lines or (
        item['run_id'] in {'1913SE84AXQF', 'Q6M2Y34MWKRE', 'NHA2KW0RB7VP'}
        and run.get('floor') in {8, 9, 17, 30, 31, 33}):
        selected_states.append({'reference': ref(item), 'state': snap(item)})
save('selected-states.json', selected_states)

attempts = []
for item in streams['sl-attempts']:
    if item['run_id'] in {'KEN58SH9SLZ6', 'TXZ6RVMQA09D', 'WQZVENQ7DTRP', 'NHA2KW0RB7VP'}:
        attempts.append({'reference': ref(item), 'row': item['row']})
save('selected-attempts.json', attempts)

summary = {
    'streams': len(verified), 'verified_rows': sum(x['verified_rows'] for x in verified),
    'runs': len(allowed), 'potion_requests': len(potion_observations),
    'cunning_requests': sum((p['potion'] or {}).get('id') == 'CUNNING_POTION' for p in potion_observations),
    'selected_decisions': len(selected_decisions), 'selected_states': len(selected_states),
    'tests': '材料核验；没有生产测试、模拟或新策略收益验证',
}
save('material-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))

"""Save explicit action-local evidence for the dispatched lamp proposal."""
import json
import pathlib

OUT = pathlib.Path(__file__).resolve().parent
index = {}
decisions = []
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    item = json.loads(line)
    row = item['row']
    index.setdefault((row.get('observed_ts'), row.get('fingerprint')), []).append(item)
for line in (OUT / 'evidence/decisions.evidence.jsonl').open():
    decisions.append(json.loads(line))


def matched(item):
    row = item['row']
    values = index.get((row.get('observed_ts'), row.get('fingerprint')), [])
    return values[0] if len(values) == 1 else None


observations = []
for i, item in enumerate(decisions[:-1]):
    row = item['row']
    chosen = row.get('chosen') or {}
    if chosen.get('action') != 'play_card':
        continue
    before = matched(item)
    after = matched(decisions[i + 1])
    if before is None or after is None or decisions[i + 1]['line'] != item['line'] + 1:
        continue
    state = before['row']['state']
    combat = state.get('combat') or {}
    card = next((c for c in combat.get('hand', []) if c.get('index') == chosen.get('card_index')), None)
    if card is None:
        continue
    run, floor, turn, card_id = item['run_id'], row.get('floor'), row.get('turn'), card.get('card_id')
    wanted = (run == 'NHA2KW0RB7VP' and floor == 33 and turn == 1 and card_id == 'MALAISE') or (
        run == 'NHA2KW0RB7VP' and floor == 17 and turn == 1 and card_id == 'DEADLY_POISON') or (
        run == 'K3676LU8B0UH' and floor == 30 and turn == 2 and card_id == 'POISONED_STAB') or (
        run == 'SADL3CGYTGSR' and floor == 45 and card_id == 'DEADLY_POISON')
    if not wanted:
        continue
    next_state = after['row']['state']
    target = chosen.get('target_index')
    def target_info(s):
        enemy = next((e for e in (s.get('combat') or {}).get('enemies', []) if e.get('index') == target), None)
        return None if enemy is None else {
            'id': enemy.get('enemy_id'), 'index': target, 'hp': enemy.get('current_hp'),
            'powers': {p['power_id']: p.get('amount') for p in enemy.get('powers', [])},
        }
    observations.append({
        'run_id': run, 'floor': floor, 'turn': turn, 'attempt': row.get('sl_attempt'),
        'decision_line': item['line'], 'before_line': before['line'], 'after_line': after['line'],
        'card': {k: card.get(k) for k in ('card_id', 'upgraded', 'energy_cost', 'costs_x', 'dynamic_values')},
        'energy_before': combat.get('player', {}).get('energy'),
        'target_before': target_info(state), 'target_after': target_info(next_state),
        'result': row.get('result'), 'scope': '现场目标与施放端点；不证明首次消费跨动作追踪或整战收益',
    })
(OUT / 'lamp-action-observations.json').write_text(json.dumps(observations, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'observations': len(observations), 'items': [{
    'run': x['run_id'], 'floor': x['floor'], 'turn': x['turn'], 'decision': x['decision_line'],
    'before': x['target_before'], 'after': x['target_after'],
} for x in observations]}, ensure_ascii=False))

"""Write the bounded disposition of the ten assigned proposals."""
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
BATCH = '20261016-054302-s2-strategy-proposal'
BASE = 'e9b5316c63f2362e728e060cdb56b43123c6ffb8'
recorded = subprocess.check_output(['date', '--iso-8601=seconds'], text=True).strip()
dispatch = json.loads((OUT / 'dispatch.json').read_text())
queue = json.loads((OUT / 'assigned-queue.json').read_text())['folded']
source = json.loads((OUT / 'source-audit-v2.json').read_text())

details = [
    ('08eaa60bcc449852',
     'KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1–2/F15T1；F12、F16实际回复。',
     '七个饮用请求的后继药栏分别减少一瓶，其中三条原回执仍为pending。F12为26/76→53/81，F16为46/81→75/86；不能把回复、SL恢复或零净损当作未花资源。',
     '缺F15不饮用及同入口、同后继把药留到Boss的完整成对结果；七次实际消耗和两次回复不能校准持药价值。',
     '继续按实际资源结转；只有在同入口、同预算且实际后继齐备时比较早用/不用/留药。零损已饮药战是不能把零损直接当免费结果的约束。'),
    ('92920295a648b540',
     'TXZ6RVMQA09D A10 F48第二/三试T6–7、第三试T10及F49开场。',
     '同指纹T6原线48→45、敌460→424；替线48→48、敌460→433。实少损3也少扣9；首战奖励4血，F49零能量空手4血过渡到0血，敌仍111。',
     '缺保持抽序、生成牌、药栏和后续选择一致的两战完整替线；已存在的连战/开场实现不能证明SL资源比较已校准。',
     '固定核首胜、剩余HP/药/复活、后战开场及可操作性；不得用1200首胜/后败模拟放宽必死判据。首胜后开场死是只验首战改善的反例。'),
    ('a327449c331efbc1',
     'WQZVENQ7DTRP A10 F33第二/三试T9–10，以及第二/末试T7–8。',
     'T9同指纹原线损13/敌净扣24，替线损22/净扣39；T7原线损0/净扣24，延长线损4/净扣24，下一轮沙坑余量3对4（当步4→5后再递减）。',
     '缺攻防和沙坑两边界的完整受控后继、跨重规划的候选执行归属及独立胜局；9血换15伤不能确定新SL阈值。',
     '继续同时列即时血价、伤害、毒与沙坑；不固定总保血，也不把全败模拟并列当相同安全。T7支付4血延长是对一律禁止付血的约束。'),
    ('a099e89437e942bb',
     '九个已核静默来源局42饮；重点WQZVENQ7DTRP A10 F33第5/6试T11。A7、A9、A10分列。',
     '逐次核37次添3、2次添2、3次添0；115张新增牌均为升级小刀、Damage.base_value=6，药栏减一，饮用端点HP/能量/敌状态不变。第5试2/0/0，第6试3/2/0。',
     '确定生成与容量已有live子实现；仍缺计划妥当保留容量、出刀穿插、跨重问整候选派发和SL恢复的联合校准，42饮不能关闭整项。',
     '保留当前已证实生成分支；需要能定位每张生成牌和保留牌、追踪喝药—出刀—再喝及恢复后的整候选后继。满手耗瓶无新增是约束，未有穿插胜局。'),
    ('47910f82a1fdd98f',
     'TXZ6RVMQA09D A10 F48T6、F49开场；WQZVENQ7DTRP A10 F33T7/T9。',
     '四血连战入口与SL双向代价均重核；现有silent-opening只在已观察组合建模，不能向未知回血/复活组合外推。',
     '四血开场已有live子实现；仍缺留药、路线、SL的完整后继对照和未知回血/复活组合的结算顺序，联合要求保留。',
     '继续把入口自损、真实回复、SL恢复和已兑现毒分源；不能预支开场后才可能执行的药或能力。用原两个SL方向约束后续参数学习。'),
    ('f1374df72d8e6a25',
     '1913SE84AXQF A10 F17/F19/F23/F24/F28–31；Q6M2Y34MWKRE A10 F2/F7–9。',
     '1913首王58→14、幕间58，后两战58→44→40，F24锻造仍40，F28回61，F29赢后46，F31以虚弱/复制入场而死；Q6休36→57、精英胜留2，下一走廊死。',
     '缺隔离机制误差后的同入口、同预算不用/早用/留药的整战及下一战成对结果；未执行早喝候选和两条失败资源链不能拟合新权重。',
     '只核真实退出资源和临时/持续药效；Q6 F5/F6确实零损留药且最终喝药，不因前战候选更省血就认定全局应早喝或能够通关。'),
    ('38a49e6c97f31eea',
     'Q6M2Y34MWKRE A10 F8T4、F9T2；1913SE84AXQF A10 F31T2–4。',
     'Q6紧勒链敌103→95→85→85→83，毒结后80；已完成弃牌后才多扣2。1913弃磨蚀能量3不变而建1敏/4荆棘，T3双挡12仍损5；T4中段重接25且无旧毒/2力，雾3已建但无下一轮。',
     '普通紧勒已有live窄实现；仍缺弃磨蚀、增益分源、再生、自动触发与SL恢复的联合消费者校准和受控整战后继。',
     '保持普通无挡模板与不确定分支的边界，不把升级、叠层、自动重放或未触发能力补成已验证。逐击中间帧不足时保留毛伤/净损未知。'),
    ('ef0e38a5dbd3bc07',
     '1913SE84AXQF A10 F24/F28–31；Q6M2Y34MWKRE A10 F3/F7–9。',
     '资源链核F24无回复、F28加21、F31入口46；Q6事件44→36、营火36→57、精英赢57→2，空药2血接下一战实际死亡。',
     '缺另一营火、事件、路线和用药时机的受控完整结果；实际资源链只核兑现，不能据两败拟合路线或终局权重。',
     '只计已到节点/已完成回复和本战已建能力，不预支未来第三火；路线条件改变分账，保留休息后仍败及零损留药的约束。'),
    ('7f820c02d39bfaea',
     'NHA2KW0RB7VP A10 F33第1–6试T1–2；决策277248/277250/277272/277274。',
     '首轮原线30→29、敌总408→400；第5/6试30→23、敌总408→384，实多付6血、多净扣16，两侧均活。初题精确切击随后被弃，后重规划必须另列。',
     '缺同预算饱和排序校准、跨弃牌的整候选执行归属和成对完整后继；同局六次失败及1/7血价差不足确定新SL门槛。',
     '保留原答、护栏、SL与真实执行的分段记录；现有诊断actual_turn=null不算执行认证。第3试T2转向后实际损6不由初题15损替代。'),
    ('04b6b430759815ed',
     'K3676LU8B0UH A1 F30T2；SADL3CGYTGSR A7 F45T1；NHA2KW0RB7VP A10 F17T1、F33T1/T2。',
     '本批直接复核九个施放端点：K367实际目标BOWLBUG_NECTAR的毒0→8，SAD目标THE_FORGOTTEN的毒0→10，NHA首毒0→10及六次X1萎靡各减2力/建2弱；六试不算六独立局。蟹朝向已有局部修正。',
     '缺油灯首次消费身份跨动作/新战/SL恢复的联合输入，未覆盖X值、升级组合及能力整战后继；九端点不能认证原17窗口或全组合。',
     '只保留已观察目标和数值；需明确首次负面消费来源、当前X与实际目标，并验证生命周期。持有/建立/后继兑现分账，不因额外毒或局部朝向伤害差宣称救局。'),
]

assert ['silent-proposal-' + x[0] for x in details] == dispatch['proposal_ids']
results = []
proposal = [
    '# 本批静默猎手十项已领取提案核验', '',
    f'记录时间：{recorded}。批次：{BATCH}。角色：silent。',
    f'基线：`{BASE}`。仅处理dispatch.json所列十个既有CLI id；无research_request、implementation_request或proposal_repair，不承接其他专题。', '',
    '## 取证范围与共同限制', '',
    '先核干净工作树、README、最新STATE、决定末尾及学习协议；普通任务合入main为记录快进，未改源码。十份原Markdown均与队列SHA一致，副本保留为各id.original.md。',
    '仅使用十五局静默证据：本批十锚点与提案原有五个补充来源。runs原字段保留SILENT大小写，规范核对为silent；A1/A7/A9各一局，A10十二局，不能混合拟合。',
    '共用extract_evidence.py八流提取19929行，每流单独冻结source_size；逐行回读原offset/bytes/SHA/JSON及显式所属身份，通过原字节校验。fight-plans为此截点零行，不据此断言日志缺失。',
    '以下是有界实帧、动作和资源链复核，不重算旧105/109局、历史全量统计或原17油灯窗口；相关知识库只作既有声明和缺口定位。无LLM、网络、play或Boss模拟池。',
    '25组固定材料断言与42次狡诈逐步核验不是生产测试、完整候选执行认证或自然消费者验收。跨重规划、弃牌、生成和SL时，净端点不自动归因给整条候选。', '',
]
for suffix, evidence, finding, reason, behavior in details:
    ident = 'silent-proposal-' + suffix
    item = queue[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    proposal.extend([
        f'## {ident}', '', f'原提案：`{item["proposal"]}`；SHA256：`{item["proposal_sha256"]}`。',
        '关联账本：' + '、'.join(item['ledger']) + '。来源任务：' + item['source_task'] + '；本次实现任务：strategy-proposal。',
        '证据局/层/回合：' + evidence, '本次核实：' + finding,
        '旧规则/已有实现：现行策略、药价、SL资格与终局权重保持；具体已有子实现见下方真实live祖先列表，不能据局部存在关闭整项。',
        '候选行为、反例约束与验证要求：' + behavior,
        '处置：waiting。具体缺口：' + reason, '',
    ])
proposal.extend([
    '## 当前已有源码与后续验收', '',
    f'核对时live为`{source["live"]}`。所查13个源码叶10个逐字节相同；card-model、sl/explore、sl/judge的三个差异仅既有Roy/Dai注释，原差异保存base-live-relevant.diff.patch，不改写为逐字节全等。',
    '以下原始源码提交均已核为本基线及实际live祖先；仅作既有子功能来源，不登记本批implemented、duplicate、shipped或新发布：', '',
])
for x in source['original_sources']:
    proposal.append(f'- `{x["commit"]}`：{x["subject"]}。')
proposal.extend([
    '', '## 拟合、预期影响与回退', '',
    '不拟合新参数。本批固定帧仅核观察和既有实现边界；将来必须按独立run和开始时间切分较早训练/较晚验证，同局所有SL同组，保留原答、覆盖、请求回执、实际动作及退出资源。未实打替线保持未知，不以模拟样本充当独立局。',
    '如补到具体确定机制缺口，仍须以原id关联固定输入、撤源码应失败/恢复后通过与沙箱检查；价值与门槛调整还须有隔离机制误差的完整后继校准。改变实际规则再履行live、版本与Roy双通知。',
    '本次预期仅提高追溯准确性；没有实盘收益或已入库消费者声称。没有新策略可回退，当前代码与知识不动；未来实现只撤其隔离提交，保留并行知识刷新、旧提案、失败记录和证据。',
    '十五局run-config均有可定位的完整源码commit，所列dirty_files仅knowledge/或notes/；准确限制是未还原当时刷新知识/移动表字节及联合消费者，不笼统声称源码commit不可定位。',
])
(OUT / 'proposal.md').write_text('\n'.join(proposal) + '\n')
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

report = [
    '# 策略提案处理报告', '',
    f'记录时间：{recorded}。批次：{BATCH}。角色：静默猎手（silent）。',
    '结论：十项均保留waiting。现有证据支持局部资源与机制观察，尚不能关闭完整联合要求或据此更改血价、药价、SL及终局价值；本批没有源码、知识或行为变更。', '',
    '## 身份与基线', '',
    '本批learn.json的task/character/worktree/runs及十个proposal_ids匹配；reason=proposal，不是第1.2节reason=ops的纯研究。无research_request、implementation_request、proposal_repair。普通专题根请求属于其他批次，未用其输入替代本批。',
    '开工HEAD为c53d98a4b5e07eb99c42da4c20fc63c0095104c5，git status干净；git merge --no-edit main实际记录快进至完整base：',
    f'`{BASE}`。本批无新增Git提交，fixes=[]，merged=null，版本=null；无实际上线、shipped或合入受阻。', '',
    '## 核实证据与实际限制', '',
    'runs.jsonl十五来源角色均核为silent，A1/A7/A9各一局、A10十二局。仅本批十锚点填最终runs；额外五来源沿既有提案，不领取别的队列。十个原Markdown与登记SHA全吻合，31个既有账本id角色匹配。',
    '八流：states9815、decisions9448、sl-attempts78、run-config15、run-plans77、brain481、runs15、fight-plans0，共19929。逐行原offset/bytes/SHA/JSON/显式身份已核。source_size见evidence/evidence-manifest.json，不同时点的各流截点不冒充同一原子快照。全流扫描的无效行计数states2/decisions2/brain1并不归因给本批局。',
    '有界核验产物：raw-byte-verification.json、case-verification.json（25组）、cunning-verification.json（42饮）、lamp-action-observations.json（九个施放端点）、resource-chain.json、selected-decisions.json、selected-states.json与selected-attempts.json。',
    'TXZ第二/三试T6的同指纹、3/0损血与36/27敌净扣，首胜4血及后战开场0血已复核；WQ同指纹T9为13/22损、24/39敌净扣；T7花4血多一沙坑余量也保留。不同后轮抽牌与重规划不受控，不能推整战收益。',
    '42次狡诈饮用是九局内观察，含同局多次SL；37添3、2添2、3添0及115张升级小刀base6均吻合。没有穿插用药完整胜线。KEN三条pending不改成completed，仅另核后继药栏减少；两次回复与SL分账。',
    'Q6紧勒103→95→85→85→83→80逐牌、弃牌及毒分源；1913弃磨蚀建1敏/4荆棘、能量3不变，中段重接25与未兑现雾3保留。1913 F31入口46、Q6 F9入口2为真实资源链，未执行替线不当已得省血。',
    'NHA首轮原/替跨轮1/7损、8/24敌净扣，两侧均活；初题精确切击被弃后重问，不能把初题计划当整轮执行。油灯只直接核九个目标端点，不复称已重验全部17窗口。',
    '15份run-config的完整源码commit均实际存在，dirty_files列示仅knowledge/notes；未复原的是当时刷新数据字节与完整输入，而非笼统无法定位源码。原文和旧报告保持。',
    '本批没有新的相反机制结论，不重复写历史复盘、统计、反证通知或其他角色确认。未独立读取本学习会话原生模型/推理参数，不以任务正文或默认配置冒充已核实际运行模型。', '',
    '## 逐项处置', '',
    '| 原提案id | 关联账本 | 处置及具体缺口 |', '| --- | --- | --- |',
]
for result in results:
    item = queue[result['id']]
    report.append('| ' + result['id'] + ' | ' + '、'.join(item['ledger']) + ' | waiting；' + result['reason'] + ' |')
report.extend([
    '', '逐项证据局/层/回合、原文指纹、反例、候选行为与验证方法完整保存于proposal.md。', '',
    '## 现有源码、验证与记录', '',
    'source-audit-v2.json核13叶10同、3个历史Roy/Dai注释差，并逐项核七个原始来源为实际live祖先；它们不是本批实现。既有诊断scope=predicted_candidates、execution_status=pending_dispatch、actual_turn=null，不能冒充自然整候选读回。没有用当前知识热替旧局输入跑模拟。',
    '未改生产源码，未运行tsc、vitest、撤源码/恢复测试、Boss池、LLM或网络；tests固定为tsc=null、vitest=null、cases=null。材料脚本成功不算生产测试成功。没有代码提交，故未创建空合入、eval版本、上线记录或规则变更双通知。',
    '沿31个既有账本仅经根ledger.py追加本批proposal/report的where与note追溯；无新增游戏断言、support/repeat、状态降级或shipped。CLI输入/输出与前后核验见ledger-updates.jsonl、ledger-cli.stdout.log、ledger-readback.json（实际执行后生成）。原十个队列id由最终proposal_results交调度器登记，本模型不直接改原提案或根请求。',
    'gitleaks结果见gitleaks.log与gitleaks.json（实际执行后生成）；最终git status、HEAD、零源码/知识差异及输入指纹见completion-check.json。', '',
    '## 过程中的工具问题', '',
    '首次角色比较把原SILENT与silent作大小写敏感比较而触发AssertionError；随后按原角色标识规范核对并核全15局。探针碰到非战斗combat=null和空开场hand，分别有TypeError/IndexError；已改为有类型及非空条件的有界投影。一次猜测selection-execution-schema.ts路径不存在，实际代码是selection-execution.ts及selection-turn.ts。',
    '若干宽输出触发工具截断，已按指定字段/片段补读；不把这些材料探针错误当产品bug、游戏反例、测试失败或源码变更。正式脚本的stdout/stderr和所有提取产物保留，没有覆盖旧报告或零行初稿。source-audit初次保存的集成来源也保留，v2另存七个原始源码来源。', '',
    '## 交接', '',
    f'提案：{OUT / "proposal.md"}', f'报告：{OUT / "report.md"}',
    '等待按上述具体缺口补新局或可归属的完整后继后，再沿原id重派；不关闭宽父项、学习入库或消费者闭环。',
])
(OUT / 'report.md').write_text('\n'.join(report) + '\n')

packet = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
    'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': results, 'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(packet, ensure_ascii=False, indent=2) + '\n')

updates = []
for ident in sorted({i for item in queue.values() for i in item['ledger']}):
    linked = [p for p, item in queue.items() if ident in item['ledger']]
    updates.append({
        'id': ident, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
        'note': BATCH + '：核本批原提案及限定实帧，关联' + '、'.join(linked) +
                '；均waiting，具体缺数据见本批报告。本次仅补追溯，不新增证据/反证/重复次数、不改旧claim/首证/prior/status/version，不代表实现、上线或消费者采用。',
    })
(OUT / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
print(json.dumps({'base': BASE, 'proposals': len(results), 'waiting': len(results), 'ledger_links_prepared': len(updates)}, ensure_ascii=False))

"""Check bounded source observations; these are material checks, not production tests."""
import collections
import json
import pathlib

OUT = pathlib.Path(__file__).resolve().parent


def read(name):
    return json.loads((OUT / name).read_text())


states = {}
decisions = {}
for stream, dest in [('states', states), ('decisions', decisions)]:
    for line in (OUT / 'evidence' / (stream + '.evidence.jsonl')).open():
        item = json.loads(line)
        dest[item['line']] = item

checks = []


def check(name, actual, expected, refs):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'references': refs})


def state(line):
    return states[line]['row']['state']


def hp(line):
    s = state(line)
    return (s.get('combat') or {}).get('player', {}).get('current_hp', (s.get('run') or {}).get('current_hp'))


def enemy_hp(line):
    return [e['current_hp'] for e in (state(line).get('combat') or {}).get('enemies', [])]


potions = read('potion-observations.json')
cunning = [x for x in potions if (x['potion'] or {}).get('id') == 'CUNNING_POTION']
check('狡诈饮用请求数量', len(cunning), 42, [x['decision']['line'] for x in cunning])
check('狡诈独立局数', len({x['decision']['run_id'] for x in cunning}), 9, [])
capacity = collections.Counter()
cunning_checks = []
for x in cunning:
    before, after = x['before'], x['after']
    assert before and after and x['source_decisions_adjacent']
    assert (before['floor'], before['turn']) == (after['floor'], after['turn'])
    count = min(3, 10 - len(before['hand']))
    added = after['hand'][len(before['hand']):]
    assert len(added) == count
    assert [(c['id'], c['upgraded']) for c in before['hand']] == [(c['id'], c['upgraded']) for c in after['hand'][:len(before['hand'])]]
    assert len(before['potions']) == len(after['potions']) + 1
    assert all(before[k] == after[k] for k in ('hp', 'block', 'energy', 'enemies'))
    for c in added:
        assert c['id'] == 'SHIV' and c['upgraded'] is True
        damage = next(v for v in c['dynamic_values'] if v['name'] == 'Damage')
        assert damage['base_value'] == 6
    capacity[count] += 1
    cunning_checks.append({'decision': x['decision'], 'before_line': before['source_line'], 'after_line': after['source_line'],
                           'hand_before': len(before['hand']), 'added': len(added), 'potion_consumed': True,
                           'base_damage_six_and_upgraded': True, 'immediate_hp_energy_enemies_unchanged': True})
check('狡诈三张/两张/零张分布', dict(capacity), {3: 37, 2: 2, 0: 3}, [])
(OUT / 'cunning-verification.json').write_text(json.dumps(cunning_checks, ensure_ascii=False, indent=2) + '\n')

ken = [x for x in potions if x['decision']['run_id'] == 'KEN58SH9SLZ6']
check('KEN七个饮用请求位置', [[x['floor'], x['turn']] for x in ken], [[3, 2], [4, 1], [5, 2], [11, 1], [11, 2], [15, 1], [15, 1]], [x['decision']['line'] for x in ken])
check('KEN保留pending请求身份', sum(x['result'].startswith('pending') for x in ken), 3, [274131, 274237, 274272])
check('KEN七次后继药栏减少', [len(x['before']['potions']) - len(x['after']['potions']) for x in ken], [1] * 7, [x['decision']['line'] for x in ken])
check('KEN两次实际回复及上限变化', [[hp(a), state(a)['run']['max_hp'], hp(b), state(b)['run']['max_hp']] for a, b in [(280336, 280337), (280382, 280383)]], [[26, 76, 53, 81], [46, 81, 75, 86]], [280336, 280337, 280382, 280383])

check('TXZ第二第三试T6同指纹', decisions[275342]['row']['fingerprint'] == decisions[275383]['row']['fingerprint'], True, [275342, 275383])
check('TXZ原/替T6到T7实血价', [hp(281480) - hp(281485), hp(281536) - hp(281540)], [3, 0], [281480, 281485, 281536, 281540])
check('TXZ原/替T6到T7敌净扣', [enemy_hp(281480)[0] - enemy_hp(281485)[0], enemy_hp(281536)[0] - enemy_hp(281540)[0]], [36, 27], [281480, 281485, 281536, 281540])
check('TXZ首战奖励到后战死亡', [hp(i) for i in range(281563, 281567)], [4, 4, 4, 0], list(range(281563, 281567)))
check('TXZ后战没有攻击伤害兑现', [enemy_hp(281565), enemy_hp(281566)], [[111], [111]], [281565, 281566])
check('TXZ后战开场空手零能量', [len(state(281565)['combat']['hand']), state(281565)['combat']['player']['energy']], [0, 0], [281565])

check('WQ第二第三试T9同指纹', decisions[275894]['row']['fingerprint'] == decisions[275960]['row']['fingerprint'], True, [275894, 275960])
check('WQ原/替T9到T10实血价', [hp(282075) - hp(282079), hp(282144) - hp(282148)], [13, 22], [282075, 282079, 282144, 282148])
check('WQ原/替T9到T10敌净扣', [enemy_hp(282075)[0] - enemy_hp(282079)[0], enemy_hp(282144)[0] - enemy_hp(282148)[0]], [24, 39], [282075, 282079, 282144, 282148])
check('WQ相反约束T7到T8血价', [hp(282066) - hp(282072), hp(282330) - hp(282336)], [0, 4], [282066, 282072, 282330, 282336])
check('WQ相反约束T7到T8敌净扣相同', [enemy_hp(282066)[0] - enemy_hp(282072)[0], enemy_hp(282330)[0] - enemy_hp(282336)[0]], [24, 24], [282066, 282072, 282330, 282336])
def sand(line):
    return next(p['amount'] for p in state(line)['combat']['enemies'][0]['powers'] if p['power_id'] == 'SANDPIT_POWER')
check('WQ延长线后轮沙坑多一轮', [sand(282072), sand(282336)], [3, 4], [282072, 282336])

check('Q6紧勒逐牌及毒后敌HP', [enemy_hp(i)[0] for i in range(282887, 282893)], [103, 95, 85, 85, 83, 80], list(range(282887, 282893)))
check('Q6末战两血十挡后归零', [hp(282918), hp(282920), state(282920)['combat']['player']['block'], hp(282921)], [2, 2, 10, 0], [282918, 282920, 282921])
check('Q6骇鳗T7后实留两血', [hp(282900), hp(282904)], [33, 2], [282900, 282904])

check('NHA首轮原/替净血价', [hp(283391) - hp(283397), hp(283478) - hp(283483), hp(283502) - hp(283507)], [1, 7, 7], [283391, 283397, 283478, 283483, 283502, 283507])
check('NHA首轮跨轮敌净扣', [sum(enemy_hp(a)) - sum(enemy_hp(b)) for a, b in [(283391, 283397), (283478, 283483), (283502, 283507)]], [8, 24, 24], [283391, 283397, 283478, 283483, 283502, 283507])
check('NHA三组后轮两侧均活', [all(e['is_alive'] for e in state(i)['combat']['enemies']) for i in [283397, 283483, 283507]], [True] * 3, [283397, 283483, 283507])

(OUT / 'case-verification.json').write_text(json.dumps({'scope': '原日志固定端点与算术核验；不认证整候选执行、反事实或策略收益', 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_check_groups': len(checks), 'cunning_observations': len(cunning_checks), 'production_tests': None}, ensure_ascii=False))

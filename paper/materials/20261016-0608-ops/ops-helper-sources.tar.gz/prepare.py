from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
root=Path.cwd();p=root/'ops/codex-ops/record-staging/20261016-0608';pub=root/'paper/materials/20261016-0608-ops'
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda f:json.loads(f.read_text())
def write(f,v):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=root):return subprocess.check_output(['git','-C',str(cwd),*args],stderr=subprocess.PIPE)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip() and not (p/'own-appends.json').exists()
bid='20261016-054302-s2-strategy-proposal';b=load(root/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
out=root/f'ops/codex-ops/learner/{bid}.out';output=out.read_text();original=load(s/'result.json')
assert report==original==json.loads(re.findall(r'```json\s*(\{[\s\S]*?\})\s*```',output)[-1])
assert b['state']=='done' and b['rc']==0 and b['merged'] is None and not b['proposal_audit_errors'] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' and x['reason'] for x in report['proposal_results']) and {x['id'] for x in report['proposal_results']}==set(b['proposal_ids'])==set(report['code_proposals'])
assert report['fixes']==report['skipped']==report['implementation_domains']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=all',cwd=b['worktree']).strip()
final=load(s/'completion-check.json');assert final['base']==final['head']==report['base'] and final['git_status']=='' and final['tracked_diff_bytes']==final['staged_diff_bytes']==0 and final['ledger_owned_updates']==31 and final['new_source_commits']==[] and final['gitleaks']==0 and load(s/'gitleaks.json')==[]
for key,value in final.items():
    if key.endswith('_sha256') and key[:-7] in ['proposal.md','report.md','result.json','ledger-readback.json','case-verification.json','cunning-verification.json']:assert sha((s/key[:-7]).read_bytes())==value
for item in load(s/'artifact-manifest.json')['files']:
    f=s/item['path'];raw=f.read_bytes();assert f.is_relative_to(s) and len(raw)==item['bytes'] and sha(raw)==item['sha256']
source=load(s/'source-audit-v2.json');live=source['live'];assert source['base']==report['base'] and len(source['leaves'])==13
for item in source['leaves']:
    a=git('show',report['base']+':'+item['path']);z=git('show',live+':'+item['path'])
    assert sha(a)==item['sha256'] and sha(z)==item['live_sha256'] and (a==z)==item['same'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
assert sum(x['same'] for x in source['leaves'])==10
for item in source['original_sources']+source['witnesses']:
    assert item['base_ancestor'] and item['live_ancestor'];git('merge-base','--is-ancestor',item['commit'],report['base']);git('merge-base','--is-ancestor',item['commit'],live)
current_live=git('rev-parse','HEAD',cwd=root/'.worktrees/live').decode().strip();git('merge-base','--is-ancestor',live,current_live)
assigned=load(s/'assigned-queue.json')['folded'];assert set(assigned)==set(report['code_proposals'])
originals=[]
for f in sorted(s.glob('*.original.md')):
    ident=f.name.removesuffix('.original.md');assert ident in report['code_proposals'];assert sha(f.read_bytes())==assigned[ident]['proposal_sha256']==sha(Path(assigned[ident]['proposal']).read_bytes());originals.append(dict(id=ident,path=str(f.relative_to(root)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
assert len(originals)==10 and final['original_markdown_hashes_valid']
extract=module('original_extract',root/'learner/extract_evidence.py');counts={};runrows={};configs={};cohorts=collections.Counter()
for entry in load(s/'raw-byte-verification.json'):
    stream=entry['stream'];h=hashlib.sha256();seen=collections.Counter()
    with (s/'evidence'/(stream+'.evidence.jsonl')).open('rb') as selected,(root/'logs'/(stream+'.jsonl')).open('rb') as rawfile:
        for line in selected:
            h.update(line);e=json.loads(line);rawfile.seek(e['offset']);raw=rawfile.read(e['bytes']);row=json.loads(raw)
            assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and row==e['row'] and e['offset']+e['bytes']<=entry['source_size'] and extract.run_identity(row)==e['run_id']
            if stream=='runs':assert row['character']=='SILENT';runrows[e['run_id']]=row;cohorts[row['ascension']]+=1
            if stream=='run-config':configs[e['run_id']]=row
            seen[e['run_id']]+=1
    assert h.hexdigest()==entry['sha256'] and dict(seen)=={k:v for k,v in entry['counts'].items() if v} and sum(seen.values())==entry['verified_rows'];counts[stream]=sum(seen.values())
assert sum(counts.values())==19929 and len(runrows)==len(configs)==15 and cohorts=={1:1,7:1,9:1,10:12} and set(report['runs'])<=set(runrows)
for entry in load(s/'historical-source-check.json'):
    row=configs[entry['run']];assert row['code']['commit']==entry['commit'] and entry['commit_exists'] and entry['dirty_paths_only_knowledge_notes'] and all(x.startswith(('knowledge/','notes/')) for x in row['code']['dirty_files']);git('cat-file','-e',entry['commit']+'^{commit}')
facts=load(s/'case-verification.json');assert len(facts['checks'])==25 and all(x['actual']==x['expected'] for x in facts['checks']) and len(load(s/'cunning-verification.json'))==42 and len(load(s/'lamp-action-observations.json'))==9
trace=load(s/'ledger-readback.json');inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];prefix=load(s/'ledger-prefix-before.json');own=[];owned=[]
assert trace['prefix_unchanged'] and trace['all_input_fields_matched'] and trace['private_fold_preserves_all_non_provenance_fields'] and len(inputs)==len(trace['owned_rows'])==trace['owned_updates']==31
assert (s/'ledger-cli.stderr.log').read_bytes()==b'' and set((s/'ledger-cli.stdout.log').read_text().split())=={x['id'] for x in inputs}
with (root/'paper/materials/learning/ledger.jsonl').open('rb') as handle:
    assert sha(handle.read(prefix['bytes']))==prefix['sha256']
    for entry in trace['owned_rows']:
        handle.seek(entry['offset']);raw=handle.read(entry['bytes']);row=json.loads(raw)
        assert sha(raw)==entry['sha256'] and row['id']==entry['id'] and set(row)<={'op','id','ts','by','where','note'} and row['op']=='update' and row['by']=='learner:strategy-proposal' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs)
        own.append(raw);owned.append(dict(**entry,row=row))
old=git('show',base+':paper/materials/learning/ledger.jsonl');assert len(set(own))==31 and not set(x.rstrip(b'\n') for x in own)&set(old.splitlines());added=b''.join(own)
ledger=module('owned_ledger',root/'learner/ledger.py');fold=lambda raw:ledger.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);a,z=fold(old),fold(old+added);assert set(a)==set(z)
for ident in a:
    assert {k:v for k,v in a[ident].items() if k not in ['where','history','notes']}=={k:v for k,v in z[ident].items() if k not in ['where','history','notes']}
    for key in ['history','notes']:assert z[ident].get(key,[])[:len(a[ident].get(key,[]))]==a[ident].get(key,[])
    for key,values in a[ident]['where'].items():assert z[ident]['where'][key][:len(values)]==values
exec((p/'readonly-runtime.py').read_text());native=runtime(bid,report,output,b['worktree']);pub.mkdir(parents=True,exist_ok=True)
write(pub/'batch-readback.json',dict(batch=bid,original_report=report,original_gate=b['no_change_proposals'],native=native,completion=final,source=source,original_live=live,current_live_at_ops_read=current_live,current_live_is_original_descendant=True,no_live_write_by_this_wake=True,original_proposals=originals,original_rows_verified=19929,stream_counts=counts,cohorts=dict(cohorts),fixed_material_groups=25,cunning_drink_observations=42,lamp_action_endpoints=9,owned_trace_rows=owned,protected_old_fields_and_prefixes_preserved=True,limits=['Local endpoint arithmetic and same-run SL attempts do not calibrate complete candidate execution, controlled potion retention, resource value or full-fight alternatives.','42 drink observations come from9runs;9lamp endpoints are not17complete windows or complete joint combinations.','All15historical source commits exist and listed dirty paths are knowledge/notes. Missing refreshed input bytes remain distinct from source location.','Original role-case/null-combat/empty-hand/path/output-truncation probes and initial source audit retained. No new gameplay contradiction or other role ACK.','Original source audit binds e716; unrelated later live calibration/refresh ancestry is preserved and is not certified by old source checks.','No source, merge blockage, release, production test, simulation rerun, paper refresh, dispatch or game restart. Broad parents remain open.']))
artifacts=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as archive:
    for f in sorted([f for f in s.iterdir() if f.is_file() and f.stat().st_size<800000]+[s/'evidence/evidence-manifest.json',out,out.with_suffix('.err')]):
        raw=f.read_bytes();rel=str(f.relative_to(root));copy=p/'archive-scan'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(raw);archive.add(f,arcname=rel);artifacts.append(dict(path=rel,bytes=len(raw),sha256=sha(raw)))
write(pub/'original-artifact-manifest.json',artifacts);helpers=[]
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as archive:
    for f in p.glob('*.py'):
        raw=f.read_bytes();archive.add(f,arcname=f.name);helpers.append(dict(path=str(f.relative_to(root)),bytes=len(raw),sha256=sha(raw)))
write(pub/'ops-helper-manifest.json',helpers)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip();print(at,flush=True)
decision=f'\n- {at} 运维codex：0608原054302-s2策略done0/no-source核收，e9b5基线干净工作树/HEAD不变，十waiting逐项原缺口/testsnull/mergednull保持，无提交或合入受阻。十五Silent来源A1/A7/A9各一及A10十二分列，八流19929原行逐offset/bytes/SHA/JSON/显式身份核，25原材料组一致；42狡诈饮用含同局SL、37添3/2添2/3添0、九油灯端点仅局部观察，不充17完整窗口或联合组合。TXZ同局胜后四血/后战零血、WQ攻防沙坑和NHA弃牌重问边界均保，不由9血15伤或1/7局部净损拟SL血价/药价/新排序；KEN三pending及未执行留药/路线/休息后继不补。13相关源码10同3历史Roy/Dai注释差，七原功能及集成来源base/原e716 live祖先核；十五原run-config源码commit实际存在，列出脏路径仅knowledge/notes，未知为当时刷新字节及联合输入，不笼统称源码无法定位。31所属CLI原物理前缀/offset/bytes/SHA与私有fold核，只where/note，旧claim/首证/prior/evidence/status/version及history/notes/where前缀保持，不重复CLI/support/repeat或造shipped。原大小写/null-combat/空手/猜路径/输出截断及初版source-audit保留；当前native实际Sol6.1/xhigh/input/lease/workspace-write/no-network核。当前live已沿原链刷新至{current_live[:12]}，本批源码审计仍绑定原e716，不借旧树绿或处理未到完成事件。仅所属记录/31追溯提交，保并行记录，无源码/合入/发号/补测/论文刷新/复派/对局或账号home模型权限prompt改变，不关闭宽父。证据paper/materials/20261016-0608-ops/。\n'
note=f'\n- {at} [运维 codex] 原054302-s2策略十项均waiting，无源码修改或合入阻塞；原材料及31条所属追溯核收，局部端点/同局SL与完整联合要求分列。仅记录提交，未知和宽父保持，无新发布或补测。回执paper/materials/20261016-0608-ops/。\n'
appends={'paper/materials/decision-log.md':decision,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
    with (root/path).open('ab') as handle:handle.write(text.encode())
write(pub/'completion.json',dict(at=at,batch=bid,waiting=10,owned_trace_rows=31,no_source_tests_merge_release=True,wide_parents='open'))
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
    if f.is_file():values[str(f.relative_to(root))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
    f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
write(p/'record-manifest.json',dict(base=base,paths=entries));result=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
print(json.dumps(dict(waiting=10,original_rows=19929,owned_trace_rows=31,ledger_check=0,paths=len(entries))))

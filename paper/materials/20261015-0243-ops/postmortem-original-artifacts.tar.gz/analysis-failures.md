首次shell调用在执行前被沙箱扫描损坏目录链接拦截；显式指定工作目录后恢复，未请求扩大权限。

details.py首次执行到第34行时因choices未定义而退出：NameError: name 'choices' is not defined。失败脚本与其已输出的details.txt保留；后续独立audit.py按原始顶层字段核rollout_best_chosen，未将最初journal查询全None当最终数据。

草稿最初营火计数有待核占位；追加前已核原decisions，改为七锻造、四休息，共十一。未曾把错误占位追加到lessons。

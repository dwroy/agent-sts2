import json,collections,re,hashlib
from pathlib import Path
p=Path(__file__).parent
rows=lambda n:[dict(json.loads(b),_line=i['line']) for b,i in zip((p/f'{n}.jsonl').open(),map(json.loads,(p/f'{n}-index.jsonl').open()))]
d=rows('decisions');s=rows('states');b=rows('brain');run=rows('runs')[0]; chain=json.loads((p/'1GN7WFBWC2E3-resources.json').read_text());text=(p/'draft.md').read_text();checks={}
def check(k,x):assert x,k;checks[k]=True
check('角色与终局',run['character'].lower()=='silent' and run['ended'] and run['ascension']==10 and run['floor']==49 and not run['victory'])
check('三条主经验',len(re.findall(r'^- \[(?!记录)',text,re.M))==3)
check('战斗窗口23个',len(chain['combats'])==23 and all(c['entry_is_turn_one'] for c in chain['combats']))
check('退出21个截断2个',sum(c['exit'] is not None for c in chain['combats'])==21)
check('药水入栏18次',sum(len(set(map(tuple,c['to']['potions']))-set(map(tuple,c['from']['potions']))) for c in chain['resource_changes'] if not c['restart_boundary'])==18)
check('饮用19次主动丢弃0',sum(r['chosen']['action']=='use_potion' for r in d)==19 and not any(r['chosen']['action']=='discard_potion' for r in d))
rests=[r for r in d if r['label']=='rest/plan'];check('四次回血七次锻造',len(rests)==11 and sum(r['chosen']['option_index']==0 for r in rests)==4)
st={r['_line']:r['state'] for r in s}
check('连续boss资源',[(c['entry']['hp'],(c['exit'] or c['last'])['hp']) for c in chain['combats'][-4:]]==[(80,1),(80,26),(26,2),(26,0)])
check('死亡回合5与实际27攻',st[405217]['turn']==5 and st[405217]['run']['current_hp']==3 and st[405217]['combat']['player']['block']==23 and st[405217]['combat']['enemies'][0]['intents'][0]['total_damage']==27)
check('末敌血117与318',[(e['enemy_id'],e['current_hp']) for e in st[405218]['combat']['enemies']]==[('TORCH_HEAD_AMALGAM',117),('QUEEN',318)])
check('迅捷实得实饮',st[405195]['run']['potions'][0]['potion_id']=='SWIFT_POTION' and not st[405199]['run']['potions'][0]['occupied'])
check('触媒在首王建立末王未建',any(x['power_id']=='ACCELERANT_POWER' and x['amount']==2 for x in st[405133]['combat']['player']['powers']) and not any(x['power_id']=='ACCELERANT_POWER' for x in st[405217]['combat']['player']['powers']))
check('末王敏捷3',any(x['power_id']=='DEXTERITY_POWER' and x['amount']==3 for x in st[405217]['combat']['player']['powers']))
check('永久牌35张',len(st[405218]['run']['deck'])==35)
c=[r for r in d if r['decider']=='jev' and r['label'].startswith('combat/plan-choice')];check('Jev最优155／161',collections.Counter(str(r.get('rollout_best_chosen')) for r in c)=={'True':155,'False':6,'None':5})
check('低信心24',sum(r['decider']=='jev' and r.get('confidence') is not None and r['confidence']<.35 for r in d)==24)
check('HP护栏8次',sum(bool(r.get('hp_guard')) for r in d)==8)
check('代码主决策153',sum(r['decider']=='code' and r['label'] in ['combat/plan','combat/lethal','combat/least-loss'] for r in d)==153)
check('50个实际Codex脑请求',len(b)==50 and all(r['engine']=='codex' and r['model']=='gpt-6.1-sol' and r['effort']=='xhigh' and r['accepted'] for r in b))
check('脑总token与缓存',sum(r['usage']['inputTokens'] for r in b)==9581836 and sum(r['usage']['outputTokens'] for r in b)==66475 and sum(r['usage']['cacheHitTokens'] for r in b)==3281792)
check('Jev用量',sum(r.get('usage',{}).get('input_tokens',0) for r in d if r['decider']=='jev')==1699969 and sum(r.get('usage',{}).get('output_tokens',0) for r in d if r['decider']=='jev')==11161)
check('所有原行SHA读回',json.loads((p/'raw-readback.json').read_text())=={'rows':1860,'sha256_match':True})
check('草稿无待核修辞','追加前核验修正' not in text and '？此计数' not in text)
(p/'verification.json').write_text(json.dumps({'checks':checks,'draft_sha256':hashlib.sha256(text.encode()).hexdigest(),'passed':len(checks)},ensure_ascii=False,indent=2)+'\n')
print('核验通过',len(checks),'项')

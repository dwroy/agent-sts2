import json,collections,datetime,hashlib
from pathlib import Path
p=Path(__file__).parent; root=p.parents[2]
def rows(n):return [dict(json.loads(b),_line=i['line'],_offset=i['offset']) for b,i in zip((p/f'{n}.jsonl').open(),[json.loads(l) for l in (p/f'{n}-index.jsonl').open()])]
d=rows('decisions');s=rows('states');b=rows('brain');chain=json.loads((p/'1GN7WFBWC2E3-resources.json').read_text()); choices=[r for r in d if r['decider']=='jev' and r['label'].startswith('combat/plan-choice')]
print('BEST',collections.Counter(str(r.get('rollout_best_chosen')) for r in choices));print('FOCUS49',[(r['_line'],r['turn'],r.get('focus')) for r in choices if r['floor']==49]);print('RANK1',sum(r.get('code_rank')==1 for r in choices),sum(isinstance(r.get('code_rank'),(int,float)) for r in choices))
fp=collections.defaultdict(list)
for r in s:fp[r.get('fingerprint')].append(r)
actions=[]
for r in d:
 st=[z for z in fp[r.get('fingerprint')] if z['ts']<=r['ts']]; before=st[-1] if st else None
 if before is None:continue
 action=r['chosen']; combat=before['state'].get('combat') or {}; hand=combat.get('hand') or []; belt=before['state']['run']['potions']; what=action['action']
 if action['action']=='play_card':
  card=next((x for x in hand if x['index']==action['card_index']),{});what=card.get('name','?')+' '+card.get('card_id','?')
 if action['action']=='use_potion':
  potion=next((x for x in belt if x['index']==action.get('option_index')),{});what=potion.get('name','?')+' '+potion.get('potion_id','?')+' slot'+str(action.get('option_index'))
 after=s[s.index(before)+1] if s.index(before)+1<len(s) else None
 item={'d':r['_line'],'s':before['_line'],'next_s':after['_line'] if after else None,'ts':r['ts'],'floor':r['floor'],'turn':r['turn'],'reloads':r.get('sl_reloads'),'what':what,'chosen':action,'result':r['result']}; actions.append(item)
 if r['floor'] in [48,49] and action['action']=='play_card' and card.get('card_id') in ['FOOTWORK','ACCELERANT','ALCHEMIZE']:print('CORE',item)
 if action['action']=='use_potion' or action['action']=='discard_potion':print('POTION',item)
(p/'actions.json').write_text(json.dumps(actions,ensure_ascii=False,indent=2)+'\n')
for c in chain['combats']:
 lo=c['entry']['line']; hi=(c['exit'] or c['last'])['line']; names=sorted({(e['name'],e['enemy_id']) for r in s if lo<=r['_line']<=hi for e in r['state'].get('combat',{}).get('enemies',[])}); print('ENCOUNTER',c['sequence'],names)
for r in b:
 if r['label']=='rest/plan' and 'consecutive bosses' in str(r['answer']):
  facts=r['payload']['facts']; print('FINALFACTKEYS',facts.keys());print('FINALROUTE',str(facts.get('route_review'))[:3500]); print('CLOCK',str(facts.get('boss_clock'))[:3500]);print('OPTIONS',[(k,str(v)[:600]) for k,v in r.get('options',{}).items()] if isinstance(r.get('options'),dict) else str(r.get('options'))[:2000])
  sim=facts.get('act_boss_sim',{});print('SIMKEYS',sim.keys());
  for k,v in sim.items():
   if k not in ['quantitative_uncertainty','boss_margin_objective']:print('SIM',k,str(v)[:800])
print('USAGE50',{k:sum(r['usage'].get(k,0) or 0 for r in b) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']});print('50_MINUS_RUNPLAN',[sum(r['usage'].get(k,0) or 0 for r in b if r['label']!='run-plan') for k in ['inputTokens','outputTokens','cacheHitTokens']])
print('WINDOW',(datetime.datetime.fromisoformat(d[-1]['ts'])-datetime.datetime.fromisoformat(d[0]['ts'])).total_seconds())
# Re-open only the indexed byte ranges of original immutable evidence.
total=0
for name in ['decisions','states','run-plans','run-config','brain','codex-calls','sl-attempts','runs']:
 with (root/'logs'/f'{name}.jsonl').open('rb') as handle:
  for i in [json.loads(l) for l in (p/f'{name}-index.jsonl').open()]:
   handle.seek(i['offset']); raw=handle.read(i['bytes']); assert hashlib.sha256(raw).hexdigest()==i['sha256']; total+=1
print('RAW_READBACK',total)
(p/'raw-readback.json').write_text(json.dumps({'rows':total,'sha256_match':True})+'\n')

import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
rows=lambda n:[dict(json.loads(b),_line=i['line'],_offset=i['offset']) for b,i in zip((p/f'{n}.jsonl').open(),[json.loads(l) for l in (p/f'{n}-index.jsonl').open()])]
d=rows('decisions');s=rows('states');b=rows('brain'); plans=rows('run-plans'); sl=rows('sl-attempts'); chain=json.loads((p/'1GN7WFBWC2E3-resources.json').read_text())
print('SCHEMAS', {n:list(rows(n)[0]) for n in ['states','brain','run-plans']})
print('COUNTS',collections.Counter(r['decider'] for r in d),collections.Counter(r['label'] for r in d if r['decider']=='code'))
jev=[r for r in d if r['decider']=='jev']; choices=[r for r in jev if r['label'].startswith('combat/plan-choice')]
print('LOW',len([r for r in jev if (r.get('confidence') or 0)<.35]),[(r['_line'],r['floor'],r['turn'],r['confidence']) for r in jev if r.get('confidence') is not None and r['confidence']<.35])
for r in choices[:1]: print('JOURNAL',r['journal'])
print('BEST',collections.Counter(str(r.get('journal',{}).get('rollout_best_chosen')) for r in choices))
print('HP GUARDS',[(r['_line'],r['floor'],r['turn'],r['rationale']) for r in d if any(x in r.get('rationale','').lower() for x in ['guard','护栏','protect hp'])])
print('SL',[(r['_line'],r['floor'],r['attempt'],r['result'],r.get('turns'),r.get('end_hp'),r.get('incoming'),r.get('started_at'),r.get('ended_at')) for r in sl])
for c in chain['combats']:
 e=c['entry']; x=c['exit'] or c['last']; print('RESOURCE',c['sequence'],c['floor'],','.join(c['enemies']),e['hp'],x['hp'],e['max_hp'],x['max_hp'],e['potions'],x['potions'],'s'+str(e['line']),'s'+str(x['line']),e['ts'],x['ts'],c['end'])
print('BRAINS',len(b),collections.Counter((r.get('engine'),r.get('accepted')) for r in b))
print('BRAINlast', {k:str(v)[:400] for k,v in b[-1].items() if k not in ['question','context','knowledge','messages']})
for r in d:
 if r['floor'] in [48,49] and r['label']!='combat/plan-continue': print('ENDDEC',r['_line'],r['floor'],r['turn'],r['label'],r['decider'],r.get('chosen'),r.get('rationale'),{k:v for k,v in r.get('journal',{}).items() if k in ['rollout_best_chosen','code_rank','chosen_plan','focus','jev_plan']})
print('STATEkeys',list(s[-2]['state']), 'combat',list(s[-2]['state'].get('combat',{})))
print('STATElast',json.dumps(s[-2]['state'],ensure_ascii=False)[:4800])

import json,hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2'); out=root/'learner/runs/20261015-021302-postmortem'; run='1GN7WFBWC2E3'; needle=run.encode()
for name in ['decisions','states','run-plans','run-config','brain','codex-calls','sl-attempts','runs']:
 p=root/'logs'/f'{name}.jsonl'; cutoff=p.stat().st_size; offset=0; n=0
 with p.open('rb') as f,(out/f'{name}.jsonl').open('wb') as dest,(out/f'{name}-index.jsonl').open('w') as idx:
  for line_no,b in enumerate(f,1):
   start=offset; offset+=len(b)
   if offset>cutoff: break
   if needle not in b: continue
   try: row=json.loads(b)
   except ValueError: continue
   ident=row.get('run_id',row.get('run',(row.get('state') or {}).get('run_id')))
   if ident!=run: continue
   dest.write(b); idx.write(json.dumps({'line':line_no,'offset':start,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'ts':row.get('ts')})+'\n'); n+=1
 print(name,n,flush=True)
d=[json.loads(b) for b in (out/'decisions.jsonl').open()]; lo=d[0]['ts']; hi=d[-1]['ts']; p=root/'logs/deepseek-reasoning.jsonl'
# This legacy file predates the run: bounded tail inspection establishes its final timestamp.
with p.open('rb') as f:
 f.seek(max(0,p.stat().st_size-200000)); f.readline(); last=None
 for b in f:
  try: last=json.loads(b)
  except ValueError: pass
(out/'reasoning-window.json').write_text(json.dumps({'decision_first':lo,'decision_last':hi,'legacy_reasoning_last_ts':last.get('ts') if last else None},ensure_ascii=False,indent=2)+'\n')
print('window',lo,hi,'legacy_last',last.get('ts') if last else None)

exec((__import__('pathlib').Path(__file__).parent/'analyze.py').read_text().split("print('SCHEMAS'")[0])
def powers(x):return {v['power_id']:v['amount'] for v in x.get('powers',[])}
def simple(r):
 z=r['state']; c=z.get('combat') or {}; return {'s':r['_line'],'ts':r['ts'],'F':z['run']['floor'],'T':z.get('turn'),'screen':z['screen'],'hp':z['run']['current_hp'],'player':{k:c.get('player',{}).get(k) for k in ['energy','block','cards_played_this_turn']},'powers':powers(c.get('player',{})),'enemies':[{'id':e['enemy_id'],'hp':e['current_hp'],'block':e['block'],'powers':powers(e),'intent':e.get('move_id'),'atk':sum((i.get('total_damage') or 0) for i in e.get('intents',[]))} for e in c.get('enemies',[])],'hand':[(x['index'],x['card_id'],x['energy_cost'],x['playable'],x.get('unplayable_preventer_id')) for x in c.get('hand',[])]}
rounds=[]
for c in chain['combats']:
 a=c['entry']['line']; z=(c['exit'] or c['last'])['line']; ss=[r for r in s if a<=r['_line']<=z]; groups=[]
 for r in ss:
  if r['state'].get('in_combat') and (not groups or r['state'].get('turn')!=groups[-1][0]['state'].get('turn')): groups.append([r])
  elif groups: groups[-1].append(r)
 vals=[]
 for g in groups:
  bef=g[0]; aft=g[-1]; nxt=ss[ss.index(aft)+1] if ss.index(aft)+1<len(ss) else aft
  eh=lambda q:sum(e['current_hp'] for e in q['state'].get('combat',{}).get('enemies',[]) if e['is_alive'])
  vals.append({'T':bef['state'].get('turn'),'hp':bef['state']['run']['current_hp'],'endhp':nxt['state']['run']['current_hp'],'need':eh(bef),'net_enemy_hp':eh(bef)-eh(nxt),'last':simple(aft),'first':simple(bef)})
 rounds.append({'seq':c['sequence'],'floor':c['floor'],'rounds':vals})
 print('ROUNDS',c['sequence'],c['floor'],'HP',[(v['T'],v['hp'],v['endhp']) for v in vals],'NEED',[v['need'] for v in vals],'NET',[v['net_enemy_hp'] for v in vals])
(p/'rounds.json').write_text(json.dumps(rounds,ensure_ascii=False,indent=2)+'\n')
for q in rounds:
 if q['floor'] in [48,49]:
  for v in q['rounds']: print('FRAME',q['seq'],json.dumps(v['first'],ensure_ascii=False)); print('LAST',q['seq'],json.dumps(v['last'],ensure_ascii=False))
print('CHANGES')
for c in chain['resource_changes']:
 fr=c['from'];to=c['to'];print('CHANGE',c['combat_sequence'],c['restart_boundary'],'s'+str(fr['line'])+'->'+str(to['line']),to['floor'],to['turn'],fr['hp'],to['hp'],fr['max_hp'],to['max_hp'],fr['potions'],to['potions'],to['ts'])
print('POTIONDECS')
for r in d:
 if r['chosen'].get('action') in ['use_potion','discard_potion','claim_reward'] or 'potion' in r['label']: print(r['_line'],r['floor'],r['turn'],r['chosen'],r['rationale'])
print('NONCOMBAT')
for r in d:
 if r['decider']=='codex': print(r['_line'],r['floor'],r['label'],r['chosen'],r['rationale'])
print('BRAINUSAGE',[sum(r['usage'].get(k,0) or 0 for r in b) for k in ['inputTokens','outputTokens','cacheHitTokens','reasoningTokens']])
print('DECUSAGE',[sum(r.get('usage',{}).get(k,0) or 0 for r in d) for k in ['input_tokens','output_tokens']])
print('BRAINMODELS',collections.Counter((r['engine'],r['model'],r['effort']) for r in b))
for r in choices:
 def walk(o,path=''):
  if isinstance(o,dict):
   for k,v in o.items():
    if k in ['rollout_best_chosen','code_rank','focus','chosen_order']: print('FLAG',r['_line'],path+'.'+k,str(v)[:100])
    elif k not in ['questions']: walk(v,path+'.'+k)
 walk(r)

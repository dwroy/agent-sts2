import json, re, subprocess
from pathlib import Path
scratch = Path(__file__).parent
root = Path("/home/dw/Projects/agent-sts2/.worktrees/codex-fix-silent-20261018-061301")
audit = json.loads((scratch / "queue-audit.json").read_text())
source = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
assert source != audit["base"], "source fix must be committed first"
text = (scratch / "sandbox-final.log").read_text()
files = [int(n) for n in re.findall(r"Test Files\s+(\d+) passed", text)]
cases = [int(n) for n in re.findall(r"Tests\s+(\d+) passed", text)]
assert len(files) == len(cases) == 2, "both sandbox phases must finish"
assert not re.search(r"Test Files[^\n]*failed", text), "sandbox failures must be resolved"
assert (scratch / "sandbox.exit").read_text().strip() == "0"
merge = json.loads((scratch / "merge-result.json").read_text())
merged = merge.get("final_live_head") or merge.get("merged")
item = "infra-h0-414-host-fixed-test-stability-20261018 / a406-fixed-deadlines：固定五处消费/回收夹具的执行边界"
fixes = [{"item": item, "commit": source, "test": "agent/tests/loop-consumer-fixed-transport.test.ts", "fails_without_fix": True}]
skipped = audit["skipped"]
report = {"task": "fix-batch", "base": audit["base"], "fixes": fixes, "skipped": skipped,
          "merged": merged, "tests": {"tsc": 0, "vitest": 0, "files": sum(files), "cases": sum(cases)},
          "code_proposals": [], "implementation_domains": [], "report": str(scratch / "report.md")}
lines = ["## 修 bug 回报", "", "- 合并基线：main → " + audit["base"],
         "- 修复（每条一行）：" + item + " — " + source + " — 测试 agent/tests/loop-consumer-fixed-transport.test.ts:runs a serialized historical question and action without listening sockets；global-build-fixed-inputs.test.ts:global fact consumers capture synthetic boards without searching opening hands；learner-retention-fixture.test.ts:assigns the original deadline separately to every retention safety case — 去掉修复时失败：是（3文件5败/12过/exit1；恢复4文件34过/exit0）。"]
for old in audit["already_fixed"]:
    lines.append("- 已被别人修掉的：" + old["item"] + " — " + old["commit"])
for old in skipped:
    lines.append("- 没修的：" + old["item"] + " — " + old["reason"])
lines.append(f"- 测试：生产tsc退出码0；沙箱Vitest {sum(files)}文件 / {sum(cases)}用例 / 退出码0（单worker，未因超时重跑）。原始失败标题补验5文件20项0；最初定向误选journal相邻用例，随后已按原标题补验。额外五整文件92过/1败，唯一原假Claude CLI属于固定沙箱排除项；仓库根目录误执行npx因EAI_AGAIN退出1，已改为agent目录和离线模式。附加测试类型检查仍exit1；本批两处HeadersInit已修，重查0新增诊断，Vite转译JavaScript逐字相同。原宿主两轮full1保持，不冒称宿主完整绿。固定数据、无真实LLM调用；gitleaks暂存扫描0。详见validation-details.json及原日志。")
if merged:
    lines.append("- 合入：" + merged + "；仅测试/夹具，不改变对局行为，不分配发布号，不登记学习账本shipped。")
else:
    why = merge.get("blocked", "未合入")
    lines.append("- 合入：未合入；" + why + "；刷新后/合前live " + merge.get("before_merge", merge.get("before_refresh", "未改")) + "；merge退出码" + str(merge.get("merge_exit")) + "，abort退出码" + str(merge.get("abort_exit")) + "；冲突 " + str(len(merge.get("conflicts", []))) + "处，完整路径见merge-result.json。刷新数据及原脏笔记保留，无合后测试/上线/版本或shipped登记。")
lines.append("- 需要 Roy 定的事：无。")
lines += ["", "```json", json.dumps(report, ensure_ascii=False, indent=2), "```", ""]
(scratch / "report.md").write_text("\n".join(lines))
(scratch / "result.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False))

import json, os, subprocess, sys, time
from pathlib import Path
scratch = Path(__file__).parent
live = Path("/home/dw/Projects/agent-sts2/.worktrees/live")
source, base = sys.argv[1:]
result = {"source": source, "base": base, "merged": None}
def run(args, **kw):
    return subprocess.run(args, cwd=live, text=True, **kw)
def git(*args):
    p = run(["git", *args], capture_output=True)
    if p.returncode: raise RuntimeError(p.stderr)
    return p.stdout.strip()
def save():
    (scratch / "merge-result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
while subprocess.run(["pgrep", "-f", "knowledge/builders/buil[d]-"], stdout=subprocess.DEVNULL).returncode == 0:
    print("waiting_for_knowledge_builders", flush=True)
    time.sleep(10)
if git("diff", "--cached", "--name-only"):
    result["blocked"] = "pre-existing staged live changes; preserved"
    save(); sys.exit(2)
result["before_refresh"] = git("rev-parse", "HEAD")
result["live_status_before"] = git("status", "--short", "--untracked-files=no")
refresh = git("diff", "--name-only", "--", "knowledge", "notes/fight-value-backtest.md").splitlines()
changed = git("diff", "--name-only", base, source).splitlines()
result["refresh_paths"] = refresh
result["overlap"] = sorted(set(refresh) & set(changed))
# Preserve refreshed knowledge before attempting the authorized whole-branch merge.
run(["git", "add", "--", "knowledge"], check=True)
if git("ls-files", "--", "notes/fight-value-backtest.md"):
    run(["git", "add", "--", "notes/fight-value-backtest.md"], check=True)
if git("diff", "--cached", "--name-only"):
    with (scratch / "gitleaks-refresh.log").open("w") as log:
        scan = run(["gitleaks", "git", "--pre-commit", "--staged", "--redact", "--no-banner"], stdout=log, stderr=subprocess.STDOUT)
    if scan.returncode:
        result["blocked"] = "refresh staged secret scan failed"
        save(); sys.exit(3)
    run(["date"], check=True)
    run(["git", "commit", "-m", "Refresh knowledge data", "-m", "Co-Authored-By: Codex gpt-6.1-sol <noreply@openai.com>"], check=True)
result["before_merge"] = git("rev-parse", "HEAD")
if result["overlap"]:
    result["blocked"] = "refreshed knowledge overlaps feature changes"
    save(); sys.exit(4)
with (scratch / "live-merge.log").open("w") as log:
    merge = run(["git", "merge", "--no-edit", source], stdout=log, stderr=subprocess.STDOUT)
result["merge_exit"] = merge.returncode
if merge.returncode:
    result["conflicts"] = git("diff", "--name-only", "--diff-filter=U").splitlines()
    if run(["git", "rev-parse", "--verify", "MERGE_HEAD"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
        result["abort_exit"] = run(["git", "merge", "--abort"]).returncode
    result["blocked"] = "whole-branch merge failed; no manual conflict resolution"
    result["live_head"] = git("rev-parse", "HEAD")
    result["live_status_after"] = git("status", "--short", "--untracked-files=no")
    save(); print(json.dumps(result, ensure_ascii=False), flush=True); sys.exit(5)
result["merged"] = git("rev-parse", "HEAD")
with (scratch / "sandbox-live.log").open("w") as log:
    checked = subprocess.run(["bash", "tools/test-sandbox.sh"], cwd=live / "agent", stdout=log, stderr=subprocess.STDOUT)
result["live_tests_exit"] = checked.returncode
if checked.returncode:
    # The source changes only tests; the pre-merge dirty notes are outside the merged paths.
    run(["git", "reset", "--merge", result["before_merge"]], check=True)
    result["merged"] = None
    result["blocked"] = "post-merge sandbox failure; rolled back to refreshed knowledge"
result["live_head"] = git("rev-parse", "HEAD")
save(); print(json.dumps(result, ensure_ascii=False), flush=True)
sys.exit(checked.returncode)

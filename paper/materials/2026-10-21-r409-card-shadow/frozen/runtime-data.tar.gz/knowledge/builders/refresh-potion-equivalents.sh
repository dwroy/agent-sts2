#!/usr/bin/env bash
# Rebuild a character's potion table (knowledge/characters/<id>/potion-equivalents.json: what each potion held is worth in the act boss,
# the potion cost the solver and Jev's question use; docs/potion-equivalents.md) only when it is stale (Roy
# 2026-09-30: once a day, and when the ascension goes up):
#   - it was generated before today (local date), or
#   - it has no numbers for .env's TARGET_ASCENSION.
# Otherwise it does nothing. Ops calls it in each run's post-game knowledge refresh (docs/v4-go-live.md).
#
# Usage: knowledge/builders/refresh-potion-equivalents.sh [--dry-run] [--force] [--character ID]
#   --dry-run       say whether it would rebuild, and why; change nothing
#   --force         rebuild whatever the table's date
#   --character ID  the character's table (default ironclad; a character with no logged run gets none)
# Env: ENV_FILE (default <root>/agent/.env), POTION_TABLE (default <root>/knowledge/characters/<id>/potion-equivalents.json).
# The rebuild runs with the log database's Python (data/logdb-venv/bin/python; it syncs the log DB first) and
# writes the table atomically: a failed rebuild leaves the old table in place and exits non-zero.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"  # the project root (docs/layout.md)
ENV_FILE="${ENV_FILE:-$ROOT/agent/.env}"
PY="$ROOT/data/logdb-venv/bin/python"

dry=0
force=0
character=ironclad
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) dry=1 ;;
    --force) force=1 ;;
    --character) character="$(printf '%s' "${2:-}" | tr '[:upper:]' '[:lower:]')"; shift ;;
    *) echo "usage: $0 [--dry-run] [--force] [--character ID]" >&2; exit 2 ;;
  esac
  shift
done
if [[ ! "$character" =~ ^[a-z0-9_]+$ ]]; then
  echo "refresh-potion-equivalents: --character '$character' is not a character id" >&2
  exit 2
fi
TABLE="${POTION_TABLE:-$ROOT/knowledge/characters/$character/potion-equivalents.json}"

# Prefer the lane environment; fall back to its env file (last assignment, quotes and spaces dropped).
target="${TARGET_ASCENSION:-}"
if [[ -z "$target" && -f "$ENV_FILE" ]]; then
  target="$(grep -E '^[[:space:]]*(export[[:space:]]+)?TARGET_ASCENSION=' "$ENV_FILE" | tail -1 | sed -E 's/^[^=]*=//; s/[[:space:]"'"'"']//g; s/#.*$//' || true)"
fi
if [[ "$target" = climb ]]; then
  # A dynamic policy is not an ascension number. Use this character's latest observed completed run,
  # without predicting the next level or mixing another character's history into the table.
  target="$(python3 - "$ROOT/logs/runs.jsonl" "$character" <<'PY'
import json, sys
target = None
try:
    with open(sys.argv[1], encoding="utf8") as handle:
        for line in handle:
            try:
                row = json.loads(line)
            except ValueError:
                continue
            character = str(row.get("character") or "ironclad").lower()
            ascension = row.get("ascension")
            if character == sys.argv[2] and type(ascension) is int and ascension >= 0:
                target = ascension
except FileNotFoundError:
    pass
if target is None:
    print("refresh-potion-equivalents: climb has no completed run with an observed ascension for " + sys.argv[2], file=sys.stderr)
    raise SystemExit(2)
print(target)
PY
)"
fi
if [[ -n "$target" && ! "$target" =~ ^[0-9]+$ ]]; then
  echo "refresh-potion-equivalents: TARGET_ASCENSION '$target' in $ENV_FILE is not a number" >&2
  exit 2
fi

# Why the table is stale ("" when it is not): python3 reads the JSON (the system one is enough for this).
reason="$(python3 - "$TABLE" "$target" <<'PY'
import datetime as dt, json, sys
path, target = sys.argv[1], sys.argv[2]
try:
    meta = json.load(open(path, encoding="utf8"))["meta"]
except Exception as error:  # missing or broken: rebuild
    print(f"table unreadable ({type(error).__name__})")
    sys.exit(0)
generated = str(meta.get("generated", ""))
try:
    day = dt.datetime.fromisoformat(generated.replace("Z", "+00:00")).astimezone().date()
except ValueError:
    print(f"generated '{generated}' unreadable")
    sys.exit(0)
if day != dt.date.today():
    print(f"generated {day}, today {dt.date.today()}")
elif target and int(target) not in [int(a) for a in meta.get("ascensions", [])]:
    print(f"no numbers for TARGET_ASCENSION {target} (table: {meta.get('ascensions')})")
PY
)"

if [[ $force -eq 1 && -z "$reason" ]]; then reason="--force"; fi
if [[ -z "$reason" ]]; then
  echo "refresh-potion-equivalents: up to date (today's table${target:+, has A$target}); nothing to do"
  exit 0
fi
if [[ $dry -eq 1 ]]; then
  echo "refresh-potion-equivalents: would rebuild ($reason)"
  exit 0
fi
if [[ ! -x "$PY" ]]; then
  echo "refresh-potion-equivalents: $PY missing (the log database's Python); table left as it is ($reason)" >&2
  exit 1
fi
echo "refresh-potion-equivalents: rebuilding ($reason)"
cd "$ROOT"
"$PY" knowledge/builders/build-potion-equivalents.py --character "$character" --out "$TABLE" ${target:+--ascensions "$target"}

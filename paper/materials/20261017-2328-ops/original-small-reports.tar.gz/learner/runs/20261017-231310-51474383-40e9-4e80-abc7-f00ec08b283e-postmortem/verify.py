import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
states = [json.loads(line) for line in (base / 'states.jsonl').open()]
decisions = [json.loads(line) for line in (base / 'decisions.jsonl').open()]
by_state = {row['_line']: row['state'] for row in states}
by_decision = {row['_line']: row for row in decisions}
resources = json.loads((base / 'U1JMSKC80LQE-resources.json').read_text())
expected = [(2, 56, 47), (3, 47, 41), (4, 41, 30), (5, 30, 29), (6, 29, 0)]
assert [(c['floor'], c['entry']['hp'], c['exit']['hp']) for c in resources['combats']] == expected
assert all(c['entry_is_turn_one'] and c['entry']['max_hp'] == c['exit']['max_hp'] == 70 for c in resources['combats'])
assert not resources['sl_events']
assert sum(r.get('sl_reloads') == 0 for r in decisions) == 129
assert all(r.get('sl_reloads', 0) == 0 for r in decisions)
for line, hp in [(440991, 29), (441001, 23), (441004, 23), (441007, 18), (441011, 7), (441017, 5), (441021, 5), (441022, 0)]:
    assert by_state[line]['run']['current_hp'] == hp
last = by_state[441021]['combat']
assert last['player']['block'] == 5
assert last['enemies'][0]['current_hp'] == 4
assert last['enemies'][0]['enemy_id'] == 'DAMP_CULTIST'
assert last['enemies'][0]['intents'][0]['total_damage'] == 24
assert by_state[441022]['screen'] == 'GAME_OVER'
assert by_state[440967]['run']['potions'][0]['potion_id'] == 'STRENGTH_POTION'
assert by_decision[426383]['chosen']['action'] == 'claim_reward'
assert by_decision[426388]['chosen'] == {'action': 'use_potion', 'option_index': 0}
assert by_decision[426364]['label'] == 'reward/claim'
assert by_decision[426404]['decider'] == 'code'
assert by_decision[426404]['time_budget']['fallback'] == 'L2_deadline_existing_L1'
assert len([r for r in decisions if r.get('hp_guard')]) == 1
assert by_decision[426370]['hp_guard']['predicted_hp_saved'] == 10
assert by_decision[426370]['hp_guard']['predicted_damage_change'] == -12
assert [r for r in decisions if r['label'] == 'combat/plan-choice' and r.get('rollout_best_chosen') is True].__len__() == 20
assert sum(r['decider'] == 'jev' for r in decisions) == 25
metrics = json.loads((base / 'metrics.json').read_text())
expected_need = [[57,51,42,36,27,18,8], [47,32,26,20,5], [49,43,28,5], [58,44,35,18,10], [92,74,62,47,28,22,19]]
expected_damage = [[6,9,6,9,9,10,8], [15,6,6,15,5], [6,15,23,5], [14,9,17,8,10], [18,12,15,19,6,3,15]]
assert [[t['need'] for t in f['turns']] for f in metrics['turns']] == expected_need
assert [[t['damage'] for t in f['turns']] for f in metrics['turns']] == expected_damage
assert sum(t['damage'] for t in metrics['turns'][-1]['turns']) == 88
for name in ['states.jsonl', 'decisions.jsonl', 'brain.jsonl', 'run-plans.jsonl', 'sl-attempts.jsonl', 'run-config.jsonl', 'U1JMSKC80LQE-resources.json', 'lesson-draft.md']:
    p = base / name
    print(name, hashlib.sha256(p.read_bytes()).hexdigest())
print('核验通过：五场资源、逐轮需伤／实扣、药水、护栏与死亡末态一致。')

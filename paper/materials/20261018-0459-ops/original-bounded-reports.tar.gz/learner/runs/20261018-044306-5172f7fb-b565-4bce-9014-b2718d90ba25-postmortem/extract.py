import json, subprocess, hashlib
from pathlib import Path
root=Path('/home/dw/Projects/agent-sts2')
out=root/'learner/runs/20261018-044306-5172f7fb-b565-4bce-9014-b2718d90ba25-postmortem'
run='9W38TRGPJW9Q'
for name in ['decisions','states','run-plans','sl-attempts','run-config','fight-plans','brain','runs']:
    path=root/'logs'/f'{name}.jsonl'
    if not path.exists(): continue
    proc=subprocess.Popen(['rg','-n','-b','-F',run,str(path)],stdout=subprocess.PIPE)
    count=0
    with (out/f'{name}.jsonl').open('w') as dest:
        for line in proc.stdout:
            n,off,raw=line.split(b':',2)
            try: row=json.loads(raw)
            except ValueError: continue
            row['_source']={'file':str(path),'line':int(n),'offset':int(off),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
            dest.write(json.dumps(row,ensure_ascii=False)+'\n');count+=1
    proc.wait()
    print(name,count,flush=True)

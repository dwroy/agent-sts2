import subprocess,json,re
from pathlib import Path
p=Path(__file__).parent
queries=['超巨化','GIGANTIFICATION_POTION','毒雾','NOXIOUS_FUMES','同族神官','KIN_PRIEST','旧日雕像','BYGONE_EFFIGY','路线','空饮']
for q in queries:
 r=subprocess.run(['python3','learner/ledger.py','find','--character','silent','--text',q,'--json'],capture_output=True,text=True,check=True)
 data=json.loads(r.stdout)
 (p/('ledger-query-'+q+'.json')).write_text(r.stdout)
 print('检索',q,'总匹配',len(data))
 for x in data:
  if q.lower() in x['claim'].lower():
   print(x['id'],x['status'],x.get('version'),x['first_run'],x['claim'][:370])

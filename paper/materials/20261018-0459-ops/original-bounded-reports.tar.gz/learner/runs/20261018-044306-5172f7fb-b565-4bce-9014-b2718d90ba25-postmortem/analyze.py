import json,collections,datetime
from pathlib import Path
p=Path(__file__).parent
d=[json.loads(x) for x in (p/'decisions.jsonl').open()]
s=[json.loads(x) for x in (p/'states.jsonl').open()]
r=json.loads((p/'9W38TRGPJW9Q-resources.json').read_text())
with (p/'turns.txt').open('w') as f:
 for c in r['combats']:
  frames=[x for x in s if c['entry']['line']<=x['_source']['line']<=((c['exit'] or c['last'])['line'])]
  turns=[]
  for x in frames:
   st=x['state'];co=st.get('combat') or {}
   if st.get('in_combat') and co.get('enemies'):
    t=st.get('turn')
    if not turns or turns[-1][0]!=t: turns.append((t,[]))
    turns[-1][1].append(x)
  print('战斗',c['sequence'],'F',c['floor'],file=f)
  for i,(t,fr) in enumerate(turns):
   first,last=fr[0],fr[-1]; a,b=first['state'],last['state'];after=turns[i+1][1][0] if i+1<len(turns) else next((x for x in frames if not x['state'].get('in_combat')),None)
   enemies=lambda st:[{k:e.get(k) for k in ['index','enemy_id','current_hp','block','is_alive','powers','intents']} for e in (st.get('combat') or {}).get('enemies',[])]
   print(json.dumps({'turn':t,'first_line':first['_source']['line'],'last_line':last['_source']['line'],'hp_start':a['run']['current_hp'],'hp_end':(after or last)['state']['run']['current_hp'],'block_last':(b.get('combat') or {}).get('player',{}).get('block'),'start_enemies':enemies(a),'last_enemies':enemies(b),'player_start':(a.get('combat') or {}).get('player'),'player_last':(b.get('combat') or {}).get('player')},ensure_ascii=False),file=f)
with (p/'resource-events.txt').open('w') as f:
 for ch in r['resource_changes']:
  print(json.dumps(ch,ensure_ascii=False),file=f)
j=[x for x in d if x['decider']=='jev'];plans=[x for x in j if x['label']=='combat/plan-choice']
print('首末',d[0]['ts'],d[-1]['ts'])
print('decider',collections.Counter(x['decider'] for x in d))
print('低信心',len([x for x in j if x.get('confidence') is not None and x['confidence']<.35]),'plans',len(plans),'rollout',collections.Counter(str(x.get('rollout_best_chosen')) for x in plans))
print('护栏',[(x['_source']['line'],x['rationale']) for x in d if any(z in x['rationale'].lower() for z in ['hp guard','hp-guard','护栏','guard replaced'])])
ind=[x for x in d if x['decider']=='code' and x['label'] in ['combat/plan','combat/lethal','combat/least-loss','combat/end_turn']]
print('代码独立',len(ind),collections.Counter(x['label'] for x in ind),'窗口',len(set((x['floor'],x['sl_attempt'],x['turn']) for x in ind)))
print('纯代码窗口',len(set((x['floor'],x['sl_attempt'],x['turn']) for x in ind)-set((x['floor'],x['sl_attempt'],x['turn']) for x in j if x['label'].startswith('combat/'))))
print('药水动作')
for x in d:
 if 'potion' in x['chosen']['action']: print(x['_source']['line'],x['floor'],x['sl_attempt'],x['turn'],x['chosen'],x.get('expect'),x['rationale'])
print('大脑')
for x in map(json.loads,(p/'brain.jsonl').open()):
 print(x['_source']['line'],x['ts'],x['label'],'usage',x['usage'],'payloadkeys',list(x['payload']) if isinstance(x['payload'],dict) else type(x['payload']).__name__)
print('样本状态', json.dumps(s[-2]['state']['combat'],ensure_ascii=False)[:6000])

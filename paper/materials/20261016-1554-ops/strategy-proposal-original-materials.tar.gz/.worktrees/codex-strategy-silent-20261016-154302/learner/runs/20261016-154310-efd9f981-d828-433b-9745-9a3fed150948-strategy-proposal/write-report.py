import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / 'dispatch-identity.json').read_text())
proposals = json.loads((HERE / 'dispatched-proposals.json').read_text())
source = json.loads((HERE / 'source-verification.json').read_text())
raw = json.loads((HERE / 'raw-readback-verification.json').read_text())
facts = json.loads((HERE / 'fact-checks.json').read_text())
assert len(facts) == 37 and all(x['passed'] for x in facts)
assert len(json.loads((HERE / 'preserved-consumer-readback.json').read_text())) == 6
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z']).decode().strip()
print(stamp)
details = [
    ('神化传播及实际施放身份', 'VLZ6CCT8AQ0A F35 T1、F43 T1—T2、F45 T1',
     'F35神化前后能量7→5，防御5→8、打击7→10、匕首雨逐段5→7、必备工具1→0费；F43勒紧4→6、尖啸6→8；后抽毒雾已升级。',
     'F43实际施放后仍损57，F45持有但未施放；不同敌人、资源及抽序不构成胜负对照。',
     '缺跨抽牌、选牌、药水、重规划、SL和换战的实际施放持续身份，以及剩余升级交互校准；已有升级传播不能关闭整项。',
     '复用已上线升级传播；为实际施放建立可核战斗/尝试/动作身份，覆盖重规划和换战重置，未知升级交互保留未知，不设必打神化规则。'),
    ('三骑士全败候选和药水预算', 'VLZ6CCT8AQ0A F43—F45，重点F45 T1/T4/T5',
     'F45首题药水MC为707ms、1/12样本；rollout horizon=1、samples=1、best=null。痊愈药水实际能量1→2，HP67不变并抽牌。T5为32血20挡对59攻。',
     '第二题12/12属于另一指纹；未选高伤线及留药后继没有实打结果。预算退化与确定死亡不同，不能用单题时长拟合新常量。',
     '缺完整模型下同起点、同随机池、同总预算的MC分配配对、候选稳定性曲线及留药后继；不能由两次不同指纹题改预算或药价。',
     '先冻结完整模型和预算输入，比较分阶段MC与现有分配的样本/排名稳定性；全败并列仍列本轮代价及击杀缺口，保留全部选择。'),
    ('神化经验链', 'VLZ6CCT8AQ0A F35 T1、F43 T1—T2、F45 T1',
     '与原postmortem同源；当前源码已传递已观察升级，actual_cast_this_fight仍明确为null。',
     '同源经验不是新的独立样本；持有、候选含牌、模拟应用和实际施放分别记账。',
     '同源神化经验链仍缺本战实际施放持续身份和剩余升级交互校准；局部live实现不足以将整项标duplicate。',
     '沿原89354805ee4d7e77及现有源码补同一实际施放身份和校准，不再建重复提案或按固定分替代状态变换。'),
    ('十五项机制与资源分账', 'VLZ6CCT8AQ0A F43 T1—T5、F45 T3—T5，F44休息',
     '已核F43升级及后抽牌；F45末轮覆甲0、HP32/挡20、显示来袭59，不能沿用开场覆甲；药水未回血。原十五经验的源列表保留于原Markdown。',
     '同局多轮不扩大独立局数；胜局耗血、休息净回、能力与毒结算分源，不能从残局败局拟合统一安全血线。',
     '缺十五子项的属性/升级组合、状态期限以及战斗、路线、休息消费者的逐源联合校准；局部模型不能代替整项验收。',
     '逐子项冻结当前进阶调用输入，核力量/敏捷/勒紧/覆甲/减力期限/毒/休息净回；只对可复现生产差值单独实现，保留其他角色等价。'),
    ('Jev、护栏、SL和重规划审计', '8JRE1C4H4Z2W F33首/第三试T2、第二试T5、末试T11；F17 T6',
     '270216/270282指纹相同；原SL死亡数0/24与5/24，饱和损失均47。保存消费者的整轮端点分别玩家−3/−15、敌−10/−17，确证本轮多12血、多7净扣。',
     '另一防御换线延长至T11仍败；单动作completed与113候选段不能认证整方案，hp_guard结构为0也不能否定rationale里的护栏。',
     '缺跨重规划持续候选身份、完整执行认证及能力成长逐源归属；已有单动作回执和113候选段不能认证完整方案或改SL血价。',
     '复用三阶段selection_audit、单动作dispatch及资源比较，关联真实续步和能力建立时点；每次抽牌/选牌/药水/SL后核新状态，不把整轮净差归给单候选。'),
    ('力量、虚弱、敏捷和独立成长', 'CA5KE8GFJ9X2 F13 T1—T5',
     '蚌力量0/4/8，同一喷水显示11/15/19；虚弱后11/14。末轮2血10挡对14攻，完整需损4与零血截断净损不同。',
     '本局未建立正敏捷，计划步法不能补作实测；虚弱没有取消后继加压。',
     '本局无正敏捷实测；缺逐击力量、正负敏捷、虚弱和独立成长四路径的同次冻结生产校准，不新增统一保血/输出权重。',
     '冻结当前进阶敌人HP/伤害/移动表和属性，逐击比对；敏捷需有各自真实来源条件，不能以已有单项实现证明整复合经验通过。'),
    ('组件持有与实际启动', '5PM6JAQG6FNQ F33及F39末试T2',
     'F39末试向无毒失落打冒泡，状态274379→274380能量5→4、目标35血不变、毒0；整轮净损21另账。',
     'F33已建立组件并赢，与F39的敌人、牌序和入场资源不同，不能建立统一启动权重。',
     '缺同HP、牌组、药水及完整抽序下不同启动顺序的受控整战结果和收益函数；无毒冒泡局部无效不足以拟合启动权重。',
     '分别列持有/计划/已建立，按同起点完整抽序对照启动顺序，收益函数和验证分组按run_id定义，SL不扩样本。'),
    ('吸取、负敏捷、毒与SL', '61E2QS63Y9WU F17 T5—T7，重点T6',
     '吸取后玩家力2→0、敏0→−2、敌力0→2；T6两防御各3；敌HP67→34对应毒17+16。原SL记录首试7轮won。',
     '本场首试60血进、48血赢；没有另一完整SL线路，不能从别局失败补出可救活概率。',
     '缺同起始HP、构筑和完整抽序的SL整战配对及另一条已核后继；首试胜利和毒端点不足以修改SL范围或阈值。',
     '固定吸取前后模型输入与毒逐次结算；SL范围或偏好修改另需同盘完整后继，保持当前阈值。'),
    ('召唤、航行成长与目标选择', '61E2QS63Y9WU F23 T2—T5，重点T4',
     '两实体航行后力量3/6；T4本体76→41、幻象14→2、玩家25→10，合47敌净扣/15玩家净损，幻象T5才0血。',
     '另一focus的39伤/零损只是未执行候选；enemy_id是类型，动态召唤不凭类型认证永久实体身份。',
     '缺A10召唤、航行成长、退场和复现的全链冻结生产校准，以及另一focus的完整后继；局部源码不支持固定杀序。',
     '逐实体核召唤、成长、退场、复现和当前进阶伤害，保留全部目标与相同推演值并列，不强制首杀。'),
    ('熟睡甲虫唤醒与成长', 'DUZUBAJ3A8GP F30 T1—T6，四次相关尝试',
     '原睡3/2/1后T4醒来；末试尖啸前/后/下轮力量2/−4/4，对应攻击20/14/22；前三试停predicted_death，末试实际died。',
     '四试来自同一局；较多本轮敌净扣同时增加玩家损血，不能据此改全死排序或把前三次预测截断当已执行死亡。',
     '缺伤害唤醒、眩晕接续、当前进阶成长的全链生产校准和同抽换序后继；四次相关失败不足以拟合血价或固定杀序。',
     '按本进阶冻结睡眠、受伤唤醒、眩晕和恢复成长的完整输入及同抽后继，未知换线收益保留未知。'),
]
assert len(details) == len(proposals) == 10
results = []
proposal_text = [f'# 静默猎手十项已领取提案核验\n\n记录时间：{stamp}。\n\n角色silent；A10；batch={dispatch["batch"]}；来源/实现任务strategy-proposal。只处理本批十个原id。\n\n本批十项均waiting，无源码或知识改动。现有局部实现与原提案剩余范围分列；不新增重复id或将报告当学习父要求关闭。\n']
for item, detail in zip(proposals, details):
    title, where, evidence, counter, reason, expected = detail
    results.append({'id': item['id'], 'state': 'waiting', 'reason': reason})
    proposal_text.append(f'## {item["id"]}：{title}\n\n'
                         f'- 原提案：{item["proposal"]}；SHA256={item["proposal_sha256"]}，本批核对一致。\n'
                         f'- 证据局/层/回合：{where}。账本：{", ".join(item["ledger"])}。原来源任务：{item["source_task"]}。\n'
                         f'- 支持事实：{evidence}\n- 反例和未知：{counter}\n'
                         f'- 当前行为与处置：{reason}\n- 预期行为及验证：{expected}\n'
                         '- 拟合与时间切分：本六局为历史发现/回归证据，不称盲测；不拟合新参数，未来独立同角色完局才作时间后置验证。\n'
                         '- 预期影响与回退：仅在补足证据后修已证差值，不承诺转胜；后续实现须撤源码红/恢复绿、原沙箱检查及角色隔离。回退独立源码提交，保留证据和失败。本批无生产改动可回退。\n')
(HERE / 'proposal.md').write_text('\n'.join(proposal_text))
ledger_ids = sorted({x for p in proposals for x in p['ledger']})
updates = []
for ident in ledger_ids:
    related = [(p, r) for p, r in zip(proposals, results) if ident in p['ledger']]
    updates.append({'id': ident, 'by': 'learner:strategy-proposal',
                    'where': {'proposal': [str(HERE / 'proposal.md'), str(HERE / 'report.md')]},
                    'note': f'{dispatch["batch"]}只追加本批追溯；6995所属原行逐offset/bytes/SHA/JSON/显式身份核，选中字节和20相关源码与前批相同。'
                            + '；'.join(r['id'] + ' waiting：' + r['reason'] for _, r in related)
                            + '。本批无源码/知识改动、新提交、合入、版本或生产测试，不重复support/repeat，不改变旧状态或shipped。'})
(HERE / 'ledger-updates.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in updates))
table = '\n'.join(f'| {x["stream"]} | {x["source_size"]} | {x["verified_rows"]} |' for x in raw['streams'])
result_table = '\n'.join(f'| {r["id"]} | waiting | {r["reason"]} |' for r in results)
ancestors = '、'.join(x['commit'] for x in source['ancestry'])
report = f'''# 静默猎手本批策略处置报告

记录时间：{stamp}；task=strategy-proposal；character=silent；batch={dispatch['batch']}。

十项均waiting。本批来源证据未增加，20个相关源码相对前批也未变化；原提案所需的持续执行归属、联合生产校准或受控整战后继仍不完整。没有足够依据制定新MC预算、药价、SL阈值、启动权重或固定目标顺序。无源码/知识修改、新提案id、提交、live合入、eval版本或shipped。fixes=[]、merged=null。报告不是学习入库或宽父要求完成。

## 身份与基线

开工git status干净；必读README、最新STATE-2026-10-16、decision-log末尾、learning-protocol及learning-code-proposals已读。根learn.json只取本批行：reason=proposal、running、task/character/worktree/六局/十proposal_ids匹配，无research_request、implementation_request或proposal_repair。普通专题根文件绑定另一个旧批次，不承接专题或读取其他专题替代身份，不扩展队列。

git merge --no-edit main返回Already up to date；完整base={dispatch['base']}，HEAD保持该提交。六局runs.jsonl及3432选中状态均SILENT/A10：{','.join(dispatch['record']['runs'])}。SL尝试不扩独立局数。未派下级agent，不读其他角色私有知识，不联网或调用LLM、游戏API、模拟或play。不修改账号、模型、推理配置或运维prompt；本批工具没有独立核到原生模型/推理参数，交宿主按原线程核验，不冒称已切换。

## 原始证据与核验方法

本次共用extract_evidence.py实际重新提取runs、run-config、run-plans、fight-plans四流；states、decisions、sl-attempts、brain复用前批共用提取器的冻结输出及原source_size，逐文件来源另存evidence-origins.json。不把复用说成本次全流重新扫描。四流本次原manifest另存current-extraction-manifest.json，完整八流及逐行offset/bytes/SHA保存在evidence/。本次逐6995原行从只读logs原offset读回，核bytes、SHA256、JSON、显式身份及冻结字节边界通过；所有选中封套SHA与前批相同。来源正文提及不作所属身份，run/run_id/state.run_id/fingerprint.run冲突拒收。

| 流 | 冻结source_size字节 | 所属行数 |
|---|---:|---:|
{table}

fight-plans该截点0行仅说明未选到，不断言原日志缺失。原流无效JSON计数不归为本六局。718个相关状态投影从本次已核原行重新推导并与保存投影一致；37项固定原帧/保存消费者事实检查通过。检查属于材料核验，不是生产tsc/vitest或实现红绿。

六份保存消费者输入逐字段与本次6995原行匹配，输入/输出压缩及解码SHA、计数已核；没有重跑消费者。沿用旧输出的3301有ID动作、476候选段、121整轮端点及413未知轮窗口，全部actual_full_candidate_result=null。CA5一行、61E一行、DUZU三行缺decision_id的历史完整输入拒收及有界子集范围保留，不造ID、不将有界输出称完整局通过。原动作端点只作观测，不能认证整候选收益或未选胜线。

重点事实、层/回合、原账本、反例、旧/预期行为及验证逐项保存proposal.md。8JRE同指纹首/三试T2多12血/多7敌净扣与SL死亡样本0/24、5/24分列；5PM无毒冒泡局部无效不拟合启动阈值；CA5没有正敏捷实测；61E未选focus无完整后继；DUZU前三试预测截断与末试实际died分列。没有新增机制反证或意见分歧。

## 源码与live已有窄实现

只读live快照={source['live_snapshot']}。核20相关文件，全部与前批base逐SHA相同；16个与live逐SHA相同，另4个只有历史Roy/Dai署名注释差异，精确source-since-prior.patch及base-live-differences.patch保留。没有凭旧dirty运行Git号宣称完整当时源码、知识或随机池可重建。

本base与实际live祖先的八个窄源码提交均已实核：{ancestors}。神化已观察升级传播、致命毒药升级、三阶段选择审计、单动作dispatch和SL资源差额不能再报未上线；也不足以关闭本批宽提案。当前silent-apotheosis-reference的actual_cast_this_fight仍为null，单动作dispatch的whole_plan_executed为null，SL资源比较仍为current_turn_prediction/execution=unverified；这些明确边界与原提案要求不同。

## 逐项结果

| 原id | 状态 | 具体缺口 |
|---|---|---|
{result_table}

十项原Markdown SHA均匹配，未改原文、未重写复盘、未新增重复id。code_proposals为本批十个原CLI id；implementation_domains=[]，因为没有新实际实现。

## 记录和验收边界

本批只准备经根learner/ledger.py update追加26条相关静默账本的proposal/report追溯及waiting说明，by=learner:strategy-proposal；不新增证据support/repeat，不改变旧claim、first_run、asc、prior、evidence、status、version及shipped历史。输入、CLI执行结果和物理追加读回另存。原已shipped经验不倒退proposed；没有新经验须add proposed。最终proposal_results交原调度器消费，不手改learn.json或提案队列，不代其他角色ACK。

无源码修改，撤源码失败/恢复通过不适用；tests固定tsc=null、vitest=null、cases=null，未跑生产套件、不借历史绿作本批成功。没有源码commit/live合入/版本；不进入live锁、刷新提交或规则双通知。材料校验脚本首版将ledger.fold返回字典误作序列，报KeyError:0，已保存初版和失败log，修正后6995行核验通过；这是材料脚本错误，不是生产测试或游戏反证。

最终工作树干净、HEAD/base及账本CLI物理追加、gitleaks材料扫描以final-verification.json记录实际结果。失败现场保留；不制造提交、合入、测试成功或父要求关闭。

交运维提案：{HERE / 'proposal.md'}。
报告：{HERE / 'report.md'}。
'''
(HERE / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': dispatch['batch'],
          'base': dispatch['base'], 'runs': dispatch['record']['runs'], 'fixes': [],
          'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': [x['id'] for x in proposals], 'implementation_domains': [],
          'proposal_results': results, 'report': str(HERE / 'report.md')}
(HERE / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'proposals': len(results), 'ledger_updates_prepared': len(updates), 'report': str(HERE / 'report.md')}, ensure_ascii=False))

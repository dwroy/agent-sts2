import gzip
import json
from pathlib import Path

ROOT = Path('/home/dw/Projects/agent-sts2/learner/runs/20261014-211320-strategy-proposal')
states = {r['line']: r for r in json.loads((ROOT / 'selected-state-facts.json').read_text())}
inputs = {r: json.loads(gzip.decompress((ROOT / (r + '.consumer-input.json.gz')).read_bytes()))
          for r in ['VLZ6CCT8AQ0A', '8JRE1C4H4Z2W', '5PM6JAQG6FNQ']}
checks = []

def check(label, actual, expected, lines):
    record = {'statement': label, 'actual': actual, 'expected': expected, 'source_lines': lines, 'passed': actual == expected}
    checks.append(record)
    assert record['passed'], record

def values(line, card, key):
    return [c['values'][key] for c in states[line]['hand'] if c['id'] == card]

def enemy(line, kind):
    return next(e for e in states[line]['enemies'] if e['id'] == kind)

for a, b, floor in [(275564, 275565, 35), (275679, 275680, 43)]:
    check(f'VLZ F{floor}神化前后能量', [states[a]['energy'], states[b]['energy']], [7, 5], [a, b])
check('F35防御牌面', [values(275564, 'DEFEND_SILENT', 'Block'), values(275565, 'DEFEND_SILENT', 'Block')], [[5], [8]], [275564, 275565])
check('F35打击牌面', [values(275564, 'STRIKE_SILENT', 'Damage'), values(275565, 'STRIKE_SILENT', 'Damage')], [[7], [10]], [275564, 275565])
check('F35匕首雨每段牌面', [values(275564, 'DAGGER_SPRAY', 'Damage'), values(275565, 'DAGGER_SPRAY', 'Damage')], [[5], [7]], [275564, 275565])
check('F35必备工具费用', [[c['cost'] for c in states[n]['hand'] if c['id'] == 'TOOLS_OF_THE_TRADE'] for n in [275564, 275565]], [[1], [0]], [275564, 275565])
for card, field, before, after in [('SUCKER_PUNCH', 'Damage', [9], [11]), ('SUCKER_PUNCH', 'WeakPower', [1], [2]),
                                  ('FASTEN', 'ExtraBlock', [4], [6]), ('PIERCING_WAIL', 'StrengthLoss', [6], [8])]:
    check('F43神化后' + card + '/' + field, [values(275679, card, field), values(275680, card, field)], [before, after], [275679, 275680])
check('F43 T2后续毒雾升级牌面', [(c['upgraded'], c['values']['PoisonPerTurn']) for c in states[275687]['hand'] if c['id'] == 'NOXIOUS_FUMES'], [(True, 3)], [275687])
check('F45痊愈药水前后实能量/HP', [[states[n]['energy'], states[n]['hp']] for n in [275728, 275729]], [[1, 67], [2, 67]], [275728, 275729])
check('F45药水新手牌', [c['id'] for c in states[275729]['hand']], ['APOTHEOSIS', 'TOOLS_OF_THE_TRADE', 'SURVIVOR'], [275728, 275729])
check('F45末轮无覆甲', states[275754]['powers'].get('PLATING_POWER', 0), 0, [275754])
check('F45末轮血/挡', [states[275754]['hp'], states[275754]['block']], [32, 20], [275754])
check('F45末轮显示完整来袭', sum(i['total_damage'] or 0 for e in states[275754]['enemies'] for i in e['intents']), 59, [275754])
check('CA5蚌增力', [enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0) for n in [273237, 273252, 273263]], [0, 4, 8], [273237, 273252, 273263])
check('CA5蚌同招显示伤害', [enemy(n, 'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273237, 273252, 273263]], [11, 15, 19], [273237, 273252, 273263])
check('CA5蚌虚弱显示伤害', [enemy(n, 'SEWER_CLAM')['intents'][0]['total_damage'] for n in [273257, 273268]], [11, 14], [273257, 273268])
check('族母T6负敏捷防御牌面', values(273504, 'DEFEND_SILENT', 'Block'), [3, 3], [273504])
check('族母T6敏捷', states[273504]['powers']['DEXTERITY_POWER'], -2, [273504])
check('族母T6毒端点', [enemy(n, 'LAGAVULIN_MATRIARCH')['hp'] for n in [273504, 273508]], [67, 34], [273504, 273508])
check('胧光T4本体/幻象实际端点', [[enemy(n, kind)['hp'] for kind in ['THE_OBSCURA', 'PARAFRIGHT']] for n in [273593, 273596]], [[76, 14], [41, 2]], [273593, 273596])
check('胧光T4实际玩家端点', [states[n]['hp'] for n in [273593, 273596]], [25, 10], [273593, 273596])
check('胧光两次航行后的力量', [[enemy(n, kind)['powers'].get('STRENGTH_POWER', 0) for kind in ['THE_OBSCURA', 'PARAFRIGHT']] for n in [273589, 273596]], [[3, 3], [6, 6]], [273589, 273596])
check('甲虫临时减力/恢复加成长', [enemy(n, 'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'] for n in [274929, 274932, 274934]], [2, -4, 4], [274929, 274932, 274934])
check('甲虫临时减力/后轮攻击', [enemy(n, 'SLUMBERING_BEETLE')['intents'][0]['total_damage'] for n in [274929, 274932, 274934]], [20, 14, 22], [274929, 274932, 274934])
rows = {d['_line']: d for v in inputs.values() for d in v['decisions']}
check('8JRE首/三试T2指纹逐字相同', rows[270216]['fingerprint'] == rows[270282]['fingerprint'], True, [270216, 270282])
sl = rows[270282]['sl_explore']
check('8JRE第三试SL保留不同死亡样本', ['dead 0/24' in sl['numbers']['original'], 'dead 5/24' in sl['numbers']['replacement']], [True, True], [270282])
check('8JRE原护栏在rationale而非结构hp_guard', ['HP guard:' in rows[270264]['rationale'], 'hp_guard' in rows[270264]], [True, False], [270264])
mc = rows[269748]['potions']['random'][0]
check('VLZ F45首题药水样本/预算', [mc['samples'], mc['requested'], mc['ms']], [1, 12, 707], [269748])
check('VLZ F45首题推演退化', [rows[269748]['rollout']['horizon'], rows[269748]['rollout']['samples'], rows[269748]['rollout']['best']], [1, 1, None], [269748])
a = json.loads(gzip.decompress((ROOT / '8JRE1C4H4Z2W.consumer-output.json.gz').read_bytes()))
turns = [t for t in a['observed_turns'] if t['floor'] == 33 and t['turn'] == 2 and t['attempt'] in [1, 3]]
check('8JRE T2实付HP端点', [t['facts']['player_hp_delta'] for t in turns], [-3, -15], [270216, 270282])
check('8JRE T2实际敌血端点', [t['facts']['enemy_hp_changes'][0]['hp_delta'] for t in turns], [-10, -17], [270216, 270282])
check('5PM末试无毒冒泡前后能量', [states[n]['energy'] for n in [274379, 274380]], [5, 4], [274379, 274380, 268455])
check('5PM末试无毒冒泡目标血量', [enemy(n, 'THE_LOST')['hp'] for n in [274379, 274380]], [35, 35], [274379, 274380, 268455])
check('5PM末试无毒冒泡未建立毒', [enemy(n, 'THE_LOST')['powers'].get('POISON_POWER', 0) for n in [274379, 274380]], [0, 0], [274379, 274380, 268455])
write = Path(__file__).resolve().parent / 'fact-checks.json'
write.write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
print('固定原帧事实断言通过：', len(checks))

import ast
import collections
import hashlib
import importlib.util
import json
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
PRIOR = ROOT / '.worktrees/codex-strategy-silent-20261016-150316/learner/runs/20261016-150319-d98aa4da-ad5a-40ec-b1e2-4c874e08e01f-strategy-proposal'
ORIGINAL = ROOT / 'learner/runs/20261014-211320-strategy-proposal'
BATCH = '20261016-154302-strategy-proposal'


def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORKTREE)


def module(path):
    spec = importlib.util.spec_from_file_location(path.stem.replace('-', '_'), path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


batch = json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())['batches'][BATCH]
assert batch['task'] == 'strategy-proposal' and batch['character'] == 'silent'
assert batch['state'] == 'running' and batch['worktree'] == str(WORKTREE)
assert not any(k in batch for k in ['research_request', 'implementation_request', 'proposal_repair'])
assert len(batch['runs']) == len(set(batch['runs'])) == 6
assert len(batch['proposal_ids']) == len(set(batch['proposal_ids'])) == 10
assert git('status', '--porcelain') == b''
base = git('rev-parse', 'HEAD').decode().strip()
write('dispatch-identity.json', {'batch': BATCH, 'record': batch, 'base': base,
                               'merge_main_result': 'Already up to date.',
                               'native_model_independently_verified': False})

proposals = module(ROOT / 'learner/code_proposals.py').fold(ROOT / 'paper/materials/learning/code-proposals.jsonl')
selected = [proposals[x] for x in batch['proposal_ids']]
write('dispatched-proposals.json', selected)
materials = []
for item in selected:
    assert item['character'] == 'silent' and set(item['runs']) <= set(batch['runs'])
    data = Path(item['proposal']).read_bytes()
    assert sha(data) == item['proposal_sha256']
    (HERE / (item['id'] + '.original.md')).write_bytes(data)
    materials.append({'id': item['id'], 'path': item['proposal'], 'sha256': sha(data), 'bytes': len(data)})
write('original-proposal-readback.json', materials)
ledger_module = module(ROOT / 'learner/ledger.py')
ledger = ledger_module.fold()
ledger_ids = sorted({x for p in selected for x in p['ledger']})
assert all(ledger[x]['character'] == 'silent' for x in ledger_ids)
write('ledger-before.json', {x: ledger[x] for x in ledger_ids})

previous_sources = json.loads((PRIOR / 'source-verification.json').read_text())
live = subprocess.check_output(['git', '-C', str(ROOT / '.worktrees/live'), 'rev-parse', 'HEAD']).decode().strip()
paths = []
for item in previous_sources['paths']:
    path = item['path']
    actual = (WORKTREE / path).read_bytes()
    frozen = git('show', f'{base}:{path}')
    assert actual == frozen
    live_data = git('show', f'{live}:{path}')
    paths.append({'path': path, 'base_sha256': sha(frozen), 'live_sha256': sha(live_data),
                  'same_live': frozen == live_data, 'same_prior_base': sha(frozen) == item['base_sha256']})
ancestry = []
for commit in ['3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17', 'b2805be4ba44b7375c7908d873889372cc3cfe6c',
               '05cd292c6f01bb31e406473d3a9843e659d62b93', 'a8b1f8be153fe4f3a34146117546c2178f2e446b',
               'cf72bd21148059f111f760cc98a727369e34a47e', 'ba23ca693151fa8c6f7fe035e640dc30f05ccd75',
               '1698adc96ba434a46942321e0237b70657e625b2', '772b839f8ada31664cb764ea9ad3bdb03da27f64']:
    checks = {key: subprocess.run(['git', 'merge-base', '--is-ancestor', commit, ref], cwd=WORKTREE).returncode == 0
              for key, ref in [('base', base), ('live', live)]}
    assert all(checks.values())
    ancestry.append({'commit': commit, **checks})
write('source-verification.json', {'base': base, 'live_snapshot': live, 'prior_report': str(PRIOR / 'report.md'),
                                  'previous_base': previous_sources['base'], 'paths': paths, 'ancestry': ancestry})
(HERE / 'source-since-prior.patch').write_bytes(git('diff', '--binary', previous_sources['base'], base, '--', *[x['path'] for x in paths]))
(HERE / 'base-live-differences.patch').write_bytes(git('diff', '--binary', base, live, '--', *[x['path'] for x in paths]))

evidence = HERE / 'evidence'
fresh = json.loads((evidence / 'evidence-manifest.json').read_text())
write('current-extraction-manifest.json', fresh)
previous = json.loads((PRIOR / 'evidence/evidence-manifest.json').read_text())
manifest = {x['stream']: x for x in fresh}
origins = []
for meta in previous:
    stream = meta['stream']
    if stream not in manifest:
        shutil.copyfile(PRIOR / f'evidence/{stream}.evidence.jsonl', evidence / f'{stream}.evidence.jsonl')
        manifest[stream] = meta
        origins.append({'stream': stream, 'method': 'reuse_frozen_extractor_output',
                        'origin': str(PRIOR / f'evidence/{stream}.evidence.jsonl'), 'source_size': meta['source_size']})
    else:
        origins.append({'stream': stream, 'method': 'fresh_common_extractor', 'source_size': manifest[stream]['source_size']})
ordered = [manifest[x] for x in ['states', 'decisions', 'sl-attempts', 'run-config', 'run-plans', 'brain', 'runs', 'fight-plans']]
write('evidence/evidence-manifest.json', ordered)
write('evidence-origins.json', origins)
identity = module(WORKTREE / 'learner/extract_evidence.py').run_identity
raw_by_stream = {}
verification = []
for meta in ordered:
    stream = meta['stream']
    data = (evidence / f'{stream}.evidence.jsonl').read_bytes()
    assert sha(data) == meta['output_sha256']
    rows = [json.loads(line) for line in data.splitlines()]
    counts = collections.Counter(x['run_id'] for x in rows)
    assert all(counts[r] == meta['counts'][r] for r in batch['runs'])
    source = ROOT / f'logs/{stream}.jsonl'
    with source.open('rb') as handle:
        for item in rows:
            assert item['source'] == str(source)
            assert item['offset'] + item['bytes'] <= meta['source_size'] <= source.stat().st_size
            handle.seek(item['offset'])
            raw = handle.read(item['bytes'])
            assert raw.endswith(b'\n') and sha(raw) == item['sha256']
            row = json.loads(raw)
            assert row == item['row'] and identity(row) == item['run_id'] in batch['runs']
    raw_by_stream[stream] = rows
    old = next(x for x in previous if x['stream'] == stream)
    verification.append({'stream': stream, 'source_size': meta['source_size'], 'verified_rows': len(rows),
                         'counts': meta['counts'], 'output_sha256': sha(data), 'same_selected_bytes_as_prior': sha(data) == old['output_sha256']})
write('raw-readback-verification.json', {'verified': True, 'total_rows': sum(x['verified_rows'] for x in verification), 'streams': verification})
identities = [x['row'] for x in raw_by_stream['runs']]
assert len(identities) == 6 and {x['run_id'] for x in identities} == set(batch['runs'])
assert all(x['character'] == 'SILENT' and x['ascension'] == 10 for x in identities)
assert all(x['row']['state']['run']['character_id'] == 'SILENT' and x['row']['state']['run']['ascension'] == 10
           for x in raw_by_stream['states'])
write('run-identities.json', identities)

source_tree = ast.parse((ORIGINAL / 'verify-evidence.py').read_text())
projection_tree = ast.Module(body=[x for x in source_tree.body if isinstance(x, ast.FunctionDef) and x.name in ['power', 'snapshot']], type_ignores=[])
namespace = {}
exec(compile(projection_tree, '<preserved-state-projection>', 'exec'), namespace)
target_floors = {'VLZ6CCT8AQ0A': {35, 43, 44, 45}, '8JRE1C4H4Z2W': {17, 33}, 'CA5KE8GFJ9X2': {13},
                 '5PM6JAQG6FNQ': {33, 39}, '61E2QS63Y9WU': {17, 23}, 'DUZUBAJ3A8GP': {30}}
states = [namespace['snapshot'](x) for run in batch['runs'] for x in raw_by_stream['states']
          if x['run_id'] == run and x['row']['state']['run']['floor'] in target_floors[run]]
assert states == json.loads((ORIGINAL / 'selected-state-facts.json').read_text())
write('selected-state-facts.json', states)
facts = json.loads((ORIGINAL / 'fact-checks.json').read_text())
assert len(facts) == 37 and all(x['passed'] for x in facts)
write('prior-fact-checks.json', facts)
check_source = (ORIGINAL / 'check-facts.py').read_text()
check_source = check_source.replace('ROOT = Path(__file__).resolve().parent', f'ROOT = Path({str(ORIGINAL)!r})')
check_source = check_source.replace("write = ROOT / 'fact-checks.json'", "write = Path(__file__).resolve().parent / 'fact-checks.json'")
(HERE / 'check-preserved-facts.py').write_text(check_source)
write('verification-summary.json', {'verified_rows': sum(x['verified_rows'] for x in verification),
                                  'all_selected_streams_same_as_prior': all(x['same_selected_bytes_as_prior'] for x in verification),
                                  'rederived_state_projections': len(states),
                                  'source_paths': len(paths), 'source_paths_same_prior': sum(x['same_prior_base'] for x in paths),
                                  'source_paths_same_live': sum(x['same_live'] for x in paths),
                                  'production_tests_run': False, 'consumers_rerun': False})
print(json.dumps(json.loads((HERE / 'verification-summary.json').read_text()), ensure_ascii=False))

import copy
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')

def write(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORKTREE).decode().strip()

result = json.loads((HERE / 'result.json').read_text())
batch = json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())['batches'][result['batch']]
assert batch['state'] == 'running' and batch['worktree'] == str(WORKTREE)
assert batch['proposal_ids'] == result['code_proposals']
assert set(x['id'] for x in result['proposal_results']) == set(batch['proposal_ids'])
assert all(x['state'] == 'waiting' for x in result['proposal_results'])
assert git('rev-parse', 'HEAD') == result['base'] and git('status', '--porcelain') == ''
assert git('diff', '--binary', result['base']) == '' and git('diff', '--cached', '--binary') == ''

publication = b'\n'.join((HERE / name).read_bytes() for name in ['proposal.md', 'report.md', 'result.json', 'ledger-updates.jsonl'])
scan = subprocess.run(['gitleaks', 'stdin', '--no-banner', '--redact', '--report-format', 'json',
                       '--report-path', str(HERE / 'gitleaks.json')], input=publication, capture_output=True)
(HERE / 'gitleaks.log').write_bytes(scan.stdout + scan.stderr)
assert scan.returncode == 0

spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
updates = [json.loads(line) for line in (HERE / 'ledger-updates.jsonl').read_text().splitlines()]
ids = {x['id'] for x in updates}
ledger_path = ROOT / 'paper/materials/learning/ledger.jsonl'
before_raw = ledger_path.read_bytes()
before_rows = [(i, json.loads(line)) for i, line in enumerate(before_raw.splitlines(), 1) if line.strip()]
before = ledger.fold([(i, row) for i, row in before_rows if row.get('id') in ids])
write('ledger-immediate-before.json', before)
write('ledger-prefix-before.json', {'bytes': len(before_raw), 'sha256': hashlib.sha256(before_raw).hexdigest()})
assert all(set(x) == {'id', 'by', 'where', 'note'} and x['by'] == 'learner:strategy-proposal' for x in updates)
private = copy.deepcopy(before)
for row in updates:
    ledger.apply(private, {**row, 'op': 'update'})
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'shipped_at', 'effect']
assert all(private[ident].get(key) == before[ident].get(key) for ident in ids for key in protected)
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z']).decode().strip()
print(stamp, flush=True)
mutation = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'],
                          input=(HERE / 'ledger-updates.jsonl').read_bytes(), capture_output=True)
(HERE / 'ledger-update.log').write_bytes(mutation.stdout + mutation.stderr)
write('ledger-cli-result.json', {'date_before_cli': stamp, 'exit_code': mutation.returncode})
assert mutation.returncode == 0
after_raw = ledger_path.read_bytes()
assert after_raw[:len(before_raw)] == before_raw
offset = len(before_raw)
appended = []
for line in after_raw[len(before_raw):].splitlines(keepends=True):
    row = json.loads(line)
    if row.get('id') in ids and row.get('by') == 'learner:strategy-proposal' and result['batch'] in row.get('note', ''):
        appended.append({'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
assert len(appended) == len(updates) == 26
assert {x['row']['id'] for x in appended} == ids
for item in appended:
    original = next(x for x in updates if x['id'] == item['row']['id'])
    assert all(item['row'][key] == value for key, value in original.items())
write('ledger-appended-rows.json', appended)
after_rows = [(i, json.loads(line)) for i, line in enumerate(after_raw.splitlines(), 1) if line.strip()]
after = ledger.fold([(i, row) for i, row in after_rows if row.get('id') in ids])
assert all(after[ident].get(key) == before[ident].get(key) for ident in ids for key in protected)
assert all(str(HERE / 'proposal.md') in after[ident]['where']['proposal'] and str(HERE / 'report.md') in after[ident]['where']['proposal'] for ident in ids)
write('ledger-update-readback.json', {'rows': len(appended), 'prefix_preserved': True,
                                    'protected_fields_preserved': protected, 'new_evidence_rows': 0,
                                    'status_changes': 0, 'shipped_changes': 0})
final = {'base': result['base'], 'head': git('rev-parse', 'HEAD'), 'git_status': git('status', '--porcelain'),
         'tracked_diff': git('diff', '--stat'), 'index_diff': git('diff', '--cached', '--stat'),
         'proposal_results_match_dispatch': True, 'ledger_cli_exit': mutation.returncode, 'ledger_updates': len(appended),
         'gitleaks_exit': scan.returncode, 'production_tests': result['tests'], 'merged': None,
         'report_sha256': hashlib.sha256((HERE / 'report.md').read_bytes()).hexdigest(),
         'proposal_sha256': hashlib.sha256((HERE / 'proposal.md').read_bytes()).hexdigest()}
assert final['head'] == final['base'] and final['git_status'] == final['tracked_diff'] == final['index_diff'] == ''
write('final-verification.json', final)
print(json.dumps(final, ensure_ascii=False))

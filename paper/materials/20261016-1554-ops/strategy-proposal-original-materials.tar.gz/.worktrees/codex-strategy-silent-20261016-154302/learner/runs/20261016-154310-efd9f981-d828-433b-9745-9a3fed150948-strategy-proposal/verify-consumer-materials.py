import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = Path('/home/dw/Projects/agent-sts2/learner/runs/20261014-211320-strategy-proposal')
batch = json.loads((HERE / 'dispatch-identity.json').read_text())['record']
raw = {stream: [json.loads(line) for line in (HERE / f'evidence/{stream}.evidence.jsonl').read_text().splitlines()]
       for stream in ['states', 'decisions', 'runs']}
counts = {x['run_id']: x for x in json.loads((OLD / 'consumer-readback.json').read_text())}
manifests = {x['run_id']: x for x in json.loads((OLD / 'consumer-input-manifest.json').read_text())}
readback = []
for run in batch['runs']:
    paths = {kind: OLD / f'{run}.consumer-{kind}.json.gz' for kind in ['input', 'output']}
    data = {kind: path.read_bytes() for kind, path in paths.items()}
    decoded = {kind: gzip.decompress(value) for kind, value in data.items()}
    content = {kind: json.loads(value) for kind, value in decoded.items()}
    assert hashlib.sha256(decoded['input']).hexdigest() == manifests[run]['raw_sha256']
    assert content['input']['run'] == next(x['row'] for x in raw['runs'] if x['run_id'] == run)
    for stream in ['states', 'decisions']:
        expected = [x['row'] | {'_line': x['line'], '_source_sha256': x['sha256']}
                    for x in raw[stream] if x['run_id'] == run]
        assert content['input'][stream] == expected
    missing = [x['_line'] for x in content['input']['decisions'] if not x.get('decision_id')]
    assert missing == counts[run]['excluded_lines']
    output = content['output']
    assert output['run_id'] == run and output['character'] == 'silent' and output['ascension'] == 10
    assert len(output['segments']) == counts[run]['segments']
    assert len(output['observed_actions']) == counts[run]['actions']
    assert all(x['actual_full_candidate_result'] is None for x in output['segments'])
    readback.append({'run_id': run, 'consumer_rerun': False, 'raw_input_matches_this_batch': True,
                     'preserved_counts': counts[run], 'files': [
                         {'path': str(paths[kind]), 'sha256': hashlib.sha256(data[kind]).hexdigest(),
                          'decoded_sha256': hashlib.sha256(decoded[kind]).hexdigest(), 'bytes': len(data[kind])}
                         for kind in ['input', 'output']]})
(HERE / 'preserved-consumer-readback.json').write_text(json.dumps(readback, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'runs': len(readback), 'input_matches': True, 'consumer_rerun': False,
                  'actions': sum(x['actions'] for x in counts.values()), 'segments': sum(x['segments'] for x in counts.values()),
                  'turn_endpoints': sum(x['observed_turn_endpoints'] for x in counts.values()),
                  'unknown_turn_windows': sum(x['unknown_turns'] for x in counts.values())}, ensure_ascii=False))

# 静默猎手派发提案复核

记录时间：2026-10-16 13:22:30 CST。批次 `20261016-131302-s2-strategy-proposal`；角色 silent；三局均已从runs原行核实SILENT/A10。
基线 `ca9f61f7396ebdf181843f7099c177d3ca865fae`；开工干净，普通批次执行 `git merge --no-edit main` 返回Already up to date。没有research_request、implementation_request或proposal_repair，只处理本批十个原id。

本批没有可据现有证据新增的策略源码。十项均waiting，逐项理由如下；已有窄实现仍按实际live祖先记录，不将局部实现当整组完成。纠正AD末轮hpAfter字段误读及AD完整开场组合未覆盖的过时说法。未改源码、知识、规则、版本或原提案，未提交或合入，不登记shipped。

## 实证和反例

共用extractor冻结八流，4161条选中原行全部逐offset/bytes/SHA/JSON/显式run身份读回；20项材料断言及34个状态投影已保存。三局状态930/728/396、决策844/708/387、brain49/43/22。run-plans通过`run`字段选9/9/6行；其余身份使用run_id/state.run_id/fingerprint.run，正文提及不作归属。fight-plans仅在source_size=2233957截点选0，不推断原日志不存在。各流source_size、计数、输出SHA及源invalid/incomplete计数在两个manifest和evidence-audit.json保存；这些数据核验不当生产测试或独立样本。

- H1 F47休息33→52、F48仍败，F49未到；F33以28HP实胜是反例，不能把有限推演/持牌代价化成必败规则。F48末T4的34HP、30攻击加6持牌伤与实死一致。H1纸伤只核上限70→68→64；不据净端点推每个内部时序。
- AD F48女王实胜15、F49入房15/首手11空药；保血线少9伤保8HP，多活一轮仍败，缺同抽序完整后继。末轮毒3→6时敌仍72，最终结毒64→58后玩家实死，不能提前兑现毒。
- 9D F22已赢但退出2HP；F23四试同线、三次SL，末次2HP/12挡对14攻实死、敌81HP。多1血只是本轮严格生存下限，不是整场胜利差。未执行防御线没有到F24营火的受控后继。

## 已有源码及范围

只读核验live `1ddaba4bca8350969bb2e8dda1265095cc86b61d`。16个相关源码/夹具/工具文件中11个逐字节相等，另5个差异逐diff核实仅历史Dai/Roy注释文字，保留不改。source-audit.json保存每叶SHA和五个真实祖先；注释diff另存source-live-comments.patch。

- 凋萎可见伤害：`f680b7866cea9b440307cb28c39f2a0d214adaf6`。
- AD两套完整遗物组合开场扣4：`ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8`；当前silent-opening.ts已含AD集合，boss-start/continuationInput仅新战扣一次。原V5-R358为历史上线，本批不发新号。
- H1群蛇蜃景重放：`be9577c81a003aff0e69968c928e264f5173da7c`。
- 普通单层紧勒逐牌2及后轮撤：`5c7105ff0294466da8319f2934beda05c6040794`。
- 逐技能现场激怒和开信刀已有代码；`295a90aef9eb6f5b267490294f7733806419c45a`为含这些既有路径的实际祖先，仅说明既有实现，不冒称本角色新学或原始功能首提交。

没有以当时a340c1ec/1a0adbaa/7f0c04dd加dirty的未保存源码冒认当前树；历史完整输入及知识未复原。已有测试源码/旧报告只用作范围核对，旧负控和旧全套结果不是本批执行结果。本批不运行生产tsc/vitest、不撤源码做负控，tests三项均null。

## 分析勘误及通知

四份原Markdown的“末轮预计损2与完整需损5差额”缺少该rationale支持。d292362及d292364原文为 `keeps the most HP (-2)`，同一模板在a340c1ec和当前代码均插入`outcome.hpAfter`，两份九行原字节摘要SHA一致。s299564有3HP/18挡，对23攻完整需损5，预计剩血为-2；s299565实死。这里没有可由文本证明的3伤预测差额，不应继续据此派纯bug或拟新参数。未保存dirty源码，故也不据此证明整套旧模型正确。

原四份Markdown/队列/历史复盘不改写。questions及notification-request.json保存原观点、不同解释、原行证据、影响账本与下一步，交本次启动器完成回报给ops，须由ops沿现有watcher通道向Roy说明。受本任务写入范围限制，本模型没有创建根通知或修改收件箱；不将材料准备当ops_forwarded，不代填watcher_received/roy_notified。异议通知在实际转达前保持pending，批次结束不关闭父要求。

## 逐项提案

### silent-proposal-b259f9956e08088a

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-144110-experience-update/proposal-windows.md，SHA256 `e283eaae2c13d78fb3f0cd59205434455d41afba6001b0b63a500b5a6e2a3761`。本批副本original-proposals逐字节保存。

证据：H1T1F8ML9FUE F33 T9、F35 T1—T3、F48 T3—T4。账本：silent-0024,silent-0025,silent-0079,silent-0018,silent-0117,silent-0221,silent-0297。

已核事实及反例：F33实际赢战出口28HP；F35上限70→68→64；F48末T4有34HP、30攻击及新生6伤凋萎。

处置：waiting。凋萎可见缓存子项已有live祖先f680b7866cea9b440307cb28c39f2a0d214adaf6；饱和换线、单弃保逃离及纸伤多窗口消费仍缺完整候选后继和独立验证，不能整体duplicate。

预期行为与验证：保留原选择规则；未来固定单弃选择及沙坑、攻击、持牌伤分别结算，需有可比较完整后继。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-34209e8b9f982e49

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-144110-experience-update/proposal-resources.md，SHA256 `f5b3ac55faa17184117fd0a9c5fdd0608c6b0587e44e26e888574873b78024e4`。本批副本original-proposals逐字节保存。

证据：H1T1F8ML9FUE F47、F48 T1—T4。账本：silent-0243,silent-0020,silent-0019,silent-0021。

已核事实及反例：F47实休息33→52；末战六试同入口、没有完整胜线，F49未到。

处置：waiting。缺同盘替路线、留药及首后场联合结局和时间留出；不能凭末战失败拟药水持有价、终局权重或SL阈值。

预期行为与验证：保留现有权重；将实饮、主动弃药、事件交换、SL恢复及实到回复分账，未到后场继续未知。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-015f25123c45671c

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-151301-postmortem/proposal-resources.md，SHA256 `a9826cae824dc9bc7b3df59449e00980bfa05ef01c326233624cdc2c6966e13c`。本批副本original-proposals逐字节保存。

证据：AD3QSC3P41JU F48 T11、F49 T1。账本：silent-0228,silent-0255,silent-0030,silent-0069。

已核事实及反例：s299493/299495/299496核实15→15→11、空药。完整遗物组合已由ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8上线。

处置：waiting。旧队列所称AD完整遗物组合未覆盖已过时；当前已覆盖开场扣4及同样本接续。原宽项仍缺从F48开始的受控留药/缩短首战比较及独立联合校准，不整体关闭。

预期行为与验证：不重复扣血、不重做已上线补丁；后续冻结首场起始输入与种子，逐样本比较首战收益、出口和次战可操作入口。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-01d7495835a3eb19

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-151301-postmortem/proposal-combat.md，SHA256 `9282fefa7c494597de6d0ddd65d725fb5e8f07abf9b538b9f46b001e78e3d93e`。本批副本original-proposals逐字节保存。

证据：AD3QSC3P41JU F49 T1—T3。账本：silent-0079,silent-0028,silent-0011,silent-0048。

已核事实及反例：同入口保血线21伤/零损，另一线30伤/损8；第二试多活至T3仍败。d292362/292364的(-2)是预计剩血，符合3−(23−18)=−2。

处置：waiting。缺T1以后同抽序、完整重规划归属和受控整战后继，不能拟护栏8的新边界或SL门槛；原提案把预计剩血-2读成损2的文字须勘误，不继续当预测差额证据。

预期行为与验证：保留当前护栏和SL；未来固定原答、SL替线、抽牌重问和最终派发，并分别比较即时血价与完整后继。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-cb23be067a5f04c1

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-153440-experience-update/proposal-modifiers.md，SHA256 `0c335abd90d0afe5853ed127053296ca9208c3cb81d66d7d193ea44100e8ac82`。本批副本original-proposals逐字节保存。

证据：AD3QSC3P41JU F48 T6/T9/T10、F49 T2。账本：silent-0012,silent-0010,silent-0011,silent-0013,silent-0030,silent-0046,silent-0115,silent-0048,silent-0069,silent-0276。

已核事实及反例：F48已见毒/蜃景与分源挡；F49四技能敌力3→15、来袭19→31、弱后23，末18挡/3HP实死。

处置：waiting。毒雾、蜃景、臂甲、爆发尖啸及水盆已有局部接线；缺整组实际修饰组合的固定整线归属及受控后继，不能宣称整体校准或拟敏捷药留药时点。所谓损2对损5不由原rationale支持。

预期行为与验证：保持现有模型；只按实际建层/结毒与牌挡、被动挡、临时力量分别验证，未知组合明确保留未知。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-53ed69feeb9898fe

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-153440-experience-update/proposal-enrage.md，SHA256 `f8c860cbaf5ba93b27d98d536fd220b254e6514dd9c19033f7604484b23aa395`。本批副本original-proposals逐字节保存。

证据：AD3QSC3P41JU F49末试T2。账本：silent-0028,silent-0079。

已核事实及反例：s299559—299563四技能逐次加3力量、来袭19/22/25/28/31；突然一拳后23，毒6实结后敌仍58HP。

处置：waiting。现有逐技能激怒接线已在live；尚缺抽牌后各候选到最终派发的完整受控回放和独立后继，不能拟HP护栏/SL参数。原末轮损2/损5差额是HP字段误读，已提出勘误。

预期行为与验证：不修改已符合现场的激怒数值；保留重规划来源和实际前缀，先补同线归属，再讨论选择策略。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-1f34e9d37b21ba71

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-153440-experience-update/proposal-resources.md，SHA256 `79a49cd2ef7238a3dcf33ed556d5cde7071efe83b7b22efb77dd7539c2e65c27`。本批副本original-proposals逐字节保存。

证据：AD3QSC3P41JU F47、F48 T11、F49 T1—T2。账本：silent-0255,silent-0228,silent-0243,silent-0020,silent-0019,silent-0021。

已核事实及反例：末火实回36至62，女王退出15空药，实验体入房15/首手11；前战能力需重建。

处置：waiting。开场完整组合子项ebf8c57ecd811cceeb85fa636d49abbbb4c65dc8已为实际live祖先；宽项留药、休息、路线和连续boss联合结果仍缺受控样本。窄实现及原测试不代替自然消费或宽父验收。

预期行为与验证：沿既有同样本资源传递；不再声称开场组合未覆盖，不按全败样本拟终局价值。原Markdown的损2表述一并勘误。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-fc6618e0844f2007

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-154302-postmortem/proposal-resource-terminal.md，SHA256 `1be9084ad8cd9df4b9140743b90102ff5c87f414d52eb1d728dcdc660e078217`。本批副本original-proposals逐字节保存。

证据：9DAS5L8YM1CN F19、F21、F22 T2—T6、F23 T2。账本：silent-0019,silent-0232,silent-0044。

已核事实及反例：实际入口38/25/2；F22蛇咬线13伤/损22实打，防御候选24伤/损17未执行；F24营火未到。

处置：waiting。未执行防御候选缺到下一营火的完整配对后继与独立校准；不能由本场赢后余2HP拟终局血药权重或声称换线可救。

预期行为与验证：保留现有参数；冻结候选、资源链和必经房，需完整同样本后继再评估普通战末资源。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-a86e7753ca2a347c

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-160331-experience-update/proposal-modifiers.md，SHA256 `eed41f373dd51a48a103b2efed092fed9ba083d1214664101fd318f0b99b0b31`。本批副本original-proposals逐字节保存。

证据：9DAS5L8YM1CN F3、F17 T5、F22 T5—T6、F23 T2。账本：silent-0012,silent-0044,silent-0046,silent-0232,silent-0253,silent-0286,silent-0133。

已核事实及反例：磨蚀实付3能建立1敏/4荆棘；末战速度药5敏、手上技法12挡，后续柔嫩至力-4/敏1，对14攻实死，敌仍81。

处置：waiting。缺磨蚀毒/反伤末击中间帧、宽组合配对回放和异线完整结果；四次同线不作四独立局，不能由失败推出新柔嫩、药水或SL规则。

预期行为与验证：保留已观察局部模型和未知边界；不预支未执行弃磨蚀联动，不把至少多1血能活本轮说成通关收益。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

### silent-proposal-438a0eb4516e7975

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-160331-experience-update/proposal-card-triggers.md，SHA256 `b2a3fa0b559c5c533dc70fc6ea803e99b61a146d9621257d7aa24a44ceb8d84e`。本批副本original-proposals逐字节保存。

证据：9DAS5L8YM1CN F21 T1、F22 T3/T4。账本：silent-0261,silent-0055,silent-0009,silent-0220,silent-0260。

已核事实及反例：F21敌84→60→58→56，紧勒后两牌各2；F22有第三技能开信刀、冒泡与后结毒等并发来源。

处置：waiting。普通紧勒子项5c7105ff0294466da8319f2934beda05c6040794已为live祖先，开信刀/冒泡/蛇咬也有基础路径；整组与弃牌重规划的配对完整结果及确定弃牌仍未闭合，不能整体duplicate或承诺挽救末战。

预期行为与验证：沿现有普通单层边界；固定弃牌完成、逐技能计数、毒建立和实际结算，未知叠层/重放不扩展。 同一局的SL尝试整体分组，不当独立留出；本批无参数拟合。未来如有足够证据实施，只逆向对应实际源码增补回退，保留知识刷新和原记录；现阶段保持行为。

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[2]
spec = importlib.util.spec_from_file_location("extract_evidence", workspace / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
runs = {"H1T1F8ML9FUE", "AD3QSC3P41JU", "9DAS5L8YM1CN"}
states = {}
audits = []
for folder in [scratch / "evidence", scratch / "evidence-extra"]:
    manifest = json.loads((folder / "evidence-manifest.json").read_text())
    for stream in manifest:
        path = folder / (stream["stream"] + ".evidence.jsonl")
        counts = collections.Counter(dict.fromkeys(runs, 0))
        digest = hashlib.sha256()
        with (Path("/home/dw/Projects/agent-sts2/logs") / (stream["stream"] + ".jsonl")).open("rb") as source:
            for encoded in path.open("rb"):
                digest.update(encoded)
                item = json.loads(encoded)
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                assert extractor.run_identity(item["row"]) == item["run_id"]
                assert item["run_id"] in runs
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                counts[item["run_id"]] += 1
                if stream["stream"] == "states":
                    state = item["row"]["state"]
                    if state.get("run"):
                        assert state["run"]["character_id"].lower() == "silent"
                        assert state["run"]["ascension"] == 10
                    states[item["line"]] = item
        assert dict(counts) == stream["counts"]
        assert digest.hexdigest() == stream["output_sha256"]
        audits.append({**stream, "raw_rows_verified": sum(counts.values())})

checks = []
used = set()


def state(line):
    used.add(line)
    return states[line]["row"]["state"]


def hp(line):
    return state(line)["run"]["current_hp"]


def enemy(line, index=0):
    return state(line)["combat"]["enemies"][index]


def power(entity, ident):
    return next((p["amount"] for p in entity.get("powers", []) if p["power_id"] == ident), 0)


def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({"检查": label, "实际": actual, "预期": expected})


check("H1末火实际回复", [hp(298645), hp(298646)], [33, 52])
check("H1纸伤生命上限端点", [state(n)["run"]["max_hp"] for n in [298470, 298471, 298477]], [70, 68, 64])
check("H1沙虫赢战出口", [hp(298455), state(298455)["screen"]], [28, "REWARD"])
check("H1群蛇蜃景重放实挡", [state(n)["combat"]["player"]["block"] for n in [298603, 298604]], [2, 10])
check("H1末轮HP与结局", [hp(298832), hp(298834)], [34, 0])
check("H1末轮新生凋萎文本6", any(c["card_id"] == "WITHER" and "6" in c["resolved_rules_text"] for c in state(298832)["combat"]["hand"]), True)
check("H1末轮敌血与未兑现毒", [enemy(298833)["current_hp"], power(enemy(298833), "POISON_POWER")], [402, 0])
check("AD前boss入房到首手", [hp(299449), hp(299450)], [62, 58])
check("AD两boss交接", [hp(299493), hp(299495), hp(299496)], [15, 15, 11])
check("AD交接空药", [any(p.get("occupied") for p in state(n)["run"]["potions"]) for n in [299493, 299495, 299496]], [False, False, False])
check("AD第二试保血多活到T3", [hp(299512), hp(299517), state(299517)["turn"]], [11, 11, 3])
check("AD额外轮初毒先建不先扣血", [enemy(299558)["current_hp"], enemy(299559)["current_hp"], power(enemy(299558), "POISON_POWER"), power(enemy(299559), "POISON_POWER")], [72, 72, 3, 6])
check("AD四技能激怒3逐次力量", [power(enemy(n), "STRENGTH_POWER") for n in range(299559, 299564)], [3, 6, 9, 12, 15])
check("AD四技能来袭逐次增3", [enemy(n)["intents"][0]["damage"] for n in range(299559, 299564)], [19, 22, 25, 28, 31])
check("AD末次弱与挡及真实扣血", [enemy(299564)["intents"][0]["damage"], state(299564)["combat"]["player"]["block"], hp(299564), hp(299565)], [23, 18, 3, 0])
check("AD末次毒结算未杀敌", [enemy(299564)["current_hp"], enemy(299565)["current_hp"]], [64, 58])
check("9D紧勒首攻与后续逐牌2", [enemy(n)["current_hp"] for n in [299864, 299865, 299867, 299868]], [84, 60, 58, 56])
check("9D末次速度药不倒补挡", [power(state(299959)["combat"]["player"], "DEXTERITY_POWER"), state(299959)["combat"]["player"]["block"]], [5, 0])
check("9D手上技法实挡及柔嫩", [state(299960)["combat"]["player"]["block"], power(state(299960)["combat"]["player"], "DEXTERITY_POWER"), power(state(299960)["combat"]["player"], "STRENGTH_POWER")], [12, 4, -1])
check("9D末轮实死并非差1血通关", [hp(299963), state(299963)["combat"]["player"]["block"], enemy(299963)["intents"][0]["damage"], hp(299964), enemy(299964)["current_hp"]], [2, 12, 14, 0, 81])

projections = []
for line in sorted(used):
    item = states[line]
    raw = item["row"]["state"]
    combat = raw.get("combat") or {}
    player = combat.get("player") or {}
    projections.append({"line": line, "run_id": item["run_id"], "offset": item["offset"], "bytes": item["bytes"], "sha256": item["sha256"],
                        "floor": raw["run"]["floor"], "turn": raw["turn"], "hp": raw["run"]["current_hp"], "max_hp": raw["run"]["max_hp"],
                        "screen": raw["screen"], "player": {key: player.get(key) for key in ["block", "energy", "powers"]},
                        "enemies": combat.get("enemies"), "hand": combat.get("hand"), "potions": raw["run"]["potions"]})
(scratch / "evidence-audit.json").write_text(json.dumps({"streams": audits, "row_count": sum(s["raw_rows_verified"] for s in audits), "fact_checks": checks, "fact_check_count": len(checks)}, ensure_ascii=False, indent=2) + "\n")
(scratch / "state-projections.json").write_text(json.dumps(projections, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"原行核验": sum(s["raw_rows_verified"] for s in audits), "材料断言": len(checks), "状态投影": len(projections)}, ensure_ascii=False))

from pathlib import Path
import subprocess,json,re,hashlib,importlib.util,tarfile,collections
root=Path.cwd();private=root/'ops/codex-ops/record-staging/20261015-1436';pub=root/'paper/materials/20261015-1436-serpent-replay';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],stderr=subprocess.PIPE)
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
exec((root/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
bid='20261015-141302-s2-strategy-proposal';out=(root/'ops/codex-ops/learner'/f'{bid}.out').read_text();report=json.loads(re.findall(r'```json\s*(.*?)```',out,re.S)[-1]);scratch=Path(report['report']).parent;canonical=json.loads((root/'ops/codex-ops/learn.json').read_text())['batches'][bid];native=runtime(bid,report,out,canonical['worktree']);source=report['fixes'][0]['commit'];publication=json.loads((pub/'serpent-publication-receipt.json').read_text());assert source==publication['source'];assert git('-C',canonical['worktree'],'rev-parse','HEAD').decode().strip()==source;assert not git('-C',canonical['worktree'],'status','--porcelain').strip();assert report['merged'] is None and report['tests']['cases']==4066 and canonical['rc']==0 and not canonical['proposal_audit_errors']
queue=module('proposal_library',root/'learner/code_proposals.py').fold(root/'paper/materials/learning/code-proposals.jsonl')
for result in report['proposal_results']:
 p=queue[result['id']];assert sha(Path(p['proposal']).read_bytes())==p['proposal_sha256']
 if result['state']=='duplicate':git('merge-base','--is-ancestor',result['commit'],publication['actual_live'])
rawrefs=[];identities={};total=0
for m in json.loads((scratch/'evidence/evidence-manifest.json').read_text()):
 f=scratch/'evidence'/f"{m['stream']}.evidence.jsonl";count=0;by=collections.Counter();digest=hashlib.sha256()
 with (root/'logs'/f"{m['stream']}.jsonl").open('rb') as rawsource,f.open('rb') as frozen:
  for line in frozen:
   digest.update(line);e=json.loads(line);assert e['offset']+e['bytes']<=m['source_size'];rawsource.seek(e['offset']);b=rawsource.read(e['bytes']);row=json.loads(b);assert sha(b)==e['sha256'] and row==e['row']
   if m['stream']=='states':
    run=row['state']['run'];assert run['character_id']=='SILENT' and run['ascension']==10;identities[e['run_id']]=10
   count+=1;by[e['run_id']]+=1
 assert digest.hexdigest()==m['output_sha256'] and count==sum(m['counts'].values());total+=count;rawrefs.append({'stream':m['stream'],'rows':count,'source_size':m['source_size'],'frozen_sha256':digest.hexdigest(),'by_run':dict(by),'invalid_lines':m['invalid_lines']})
assert total==4314 and len(identities)==3
ledger=(root/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True);owned=[]
for raw in ledger:
 row=json.loads(raw)
 if str(scratch) in json.dumps(row,ensure_ascii=False):
  assert row['op']=='update' and row['by']=='learner:strategy-proposal' and set(row)<=set(['op','id','ts','by','where','note']);owned.append(raw)
assert len(owned)==29;(private/'original-owned-ledger.jsonl').write_bytes(b''.join(owned))
archives=[(f,'original/'+f.name) for f in scratch.iterdir() if f.is_file() and f.stat().st_size<300000 and not f.name.endswith('.before.txt') and not f.name.startswith('jev-sts2-settle-')]
archives.append((scratch/'evidence/evidence-manifest.json','original/evidence/evidence-manifest.json'))
for ext in ['out','err']:
 f=root/'ops/codex-ops/learner'/f'{bid}.{ext}'
 if f.exists():archives.append((f,'output/'+f.name))
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as target:
 for f,name in archives:
  b=f.read_bytes();q=private/'archive-scan'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);target.add(f,arcname=name);manifest.append({'source':str(f.relative_to(root)),'archive':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(pub/'original-artifacts.tar.gz','r:gz') as target:
 for v in manifest:assert sha(target.extractfile(v['archive']).read())==v['sha256']
(pub/'original-artifact-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(pub/'batch-readback.json').write_text(json.dumps({'batch':bid,'original_report':report,'native':native,'original_canonical':{k:canonical.get(k) for k in ['state','rc','merged','proposal_audit_errors']},'source_worktree_clean':True,'original_source':source,'original_no_live_report_and_record_conflicts_preserved':True,'original_source_full':publication['source_checks'],'new_deployment':{'main':publication['main_integration'],'live':publication['actual_live'],'tree':publication['actual_live_tree'],'release_id':publication['release_id']},'original_cli_rows':29,'original_raw_rows':4314,'raw_streams':rawrefs,'state_roles_and_ascension':identities,'wide_c888_proposal_not_closed_by_narrow_fix':True,'existing_duplicate_not_new_work':True,'new_natural_consumption_and_host_pass':'pending; original fixed consumer and sandbox distinct','raw_dirty_historical_tree_not_reconstructed':True,'source_small_artifacts':len(manifest)},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'original_raw_rows':total,'original_ledger_rows':29,'artifacts':len(manifest),'source':source,'release':publication['release_id']}))

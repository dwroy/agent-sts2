# 静默策略提案批次交付

本批完成一项有实盘证据的窄源码修正，但未上线。十个原id最终为1项duplicate、9项waiting：其中c888为源码与自测完成后工程合入受阻，另外8项保留具体缺数据理由。父研究、宽量化／策略要求和原提案未自动关闭。

任务 strategy-proposal；角色 silent；batch 20261015-141302-s2-strategy-proposal。基线 `e3ffc2301d9eb25a0fedf874d56710b938dc41a3`，实际源码 `be9577c81a003aff0e69968c928e264f5173da7c`。开工干净，按普通队列同步main后基线不变；无research_request/implementation_request，不采用纯研究口径。原队列十个Markdown逐SHA读取并保留，详见proposal.md。没有新增代码提案id，也没有改原提案、旧done请求或调度状态。

## 源码与实盘证据

所属 `silent-proposal-c888545b80180da7`，原账本 silent-0132，关联0023/0010。H1T1F8ML9FUE A10 F45T5，s298603→298604：零敏、脆弱、余像1、群蛇4、单敌5毒4挡100血，蜃景+重放1、每次3挡。实际花1能量、挡2→10、敌挡4→0且血100→96；毒仍5。旧生产输入正确算挡，但群蛇只允许单次牌，因此重放少计实见8伤并两次标unknown。新模型只在已观察模板和同修饰窗口允许两次各4的触发；其他牌／角色／进阶、自动、复制、多敌、叠层、不同毒与敏捷等维持旧结果。

冻结原帧经parseGameState→planCombatTurn→真实SolverInput→traceSteps，行动阶段复现能量2／挡10／敌96血5毒及4本体伤；敌盾与本体、后续9毒和格挡盾6伤分开。不是改选择优先级、HP容差、药水持有价、终局曲线或真正必死条件。无整战获胜、消费者自然采用或收益结论。回退只逆向本次源码提交，不碰原数据和并行记录。

## 证据字节和身份

共用extractor冻结8流，source_size、offset、bytes、SHA和分局计数均保留。4314条选中原行已逐字节／SHA／JSON／显式run身份读回，状态另核SILENT；32个状态投影和16个固定事实断言通过。三局runs.jsonl均SILENT/A10：LYB F30败，H1 F48败，AD F49败。状态分别478/930/728；决策455/844/708；真实brain原行28/49/43，兼容deepseek_calls不当引擎证据。fight-plans在本截点0行，只报告选到0，不推日志不存在。详见evidence/evidence-manifest.json、evidence-audit.json、state-projections.json、selected-decisions.json。

原三dirty执行树未快照，不将当前基线或当前知识冒作旧运行树。当前11个既有源码叶与锁前live比对，8叶逐字节同、3叶仅Roy/Dai历史注释不同，差异另存existing-source-differences.patch，未改这些历史文字。

## 自测与失败原件

- 最终测试SHA `92dbe866bb648c7b5e55fea1daa9babfabadbc701c472e8b56bdcef837a613a8`。撤掉两个源码叶、保留最终固定测试：退出1，1失败／14通过；finally恢复后退出0，15通过。source-withdrawn.log、source-restored.log和negative-control.json可复验，源码恢复字节已核。
- 新测试＋原群蛇回归：2文件33项过。完整规定沙箱入口 `bash tools/test-sandbox.sh`：退出0，tsc0，431文件4055项＋paths单文件11项，共432文件4066项通过；未重试、未宣称沙箱外排除文件也运行。日志sandbox-before-commit.log。
- 提交前暂存差异gitleaks stdin扫描退出0，约193668字节，无泄漏；git diff --cached --check通过。全局身份提交，Co-Authored-By为Codex GPT-6.1-Sol，未改仓库身份、hooks/config或依赖。
- 原先测试首稿把完整回合敌HP断言成87，漏分已有格挡盾结算；replay-before.log及replay-diagnostic.log保留。最终改用真实行动trace，负控和恢复是同一最终测试，而非借首稿误断言。
- 材料审计首稿相对路径多上一层，FileNotFoundError原件evidence-audit.log保留；修正后v2完成4314原行核对。初次apply_patch锚点未匹配未改变源码，后按实际文本重做；不把这些材料／编辑失败记作生产故障。

## live合入事实

本次源提交完成后，使用ops/live-merge.lock，等待规定builder检查；live原有暂存为空。按任务git add notes/fight-value-backtest.md knowledge后无刷新可提交，refresh_paths=[]、refresh_overlap=[]，没有覆盖任何知识刷新。记录合前真实live `efed9b0a105c2f2c0d59089c8e938121f5ea8fc1`。

锁内以这同一个live提交和精确源码提交运行merge-tree预检，退出1：notes/for-roy.md、ops/inbox-dev.md、paper/materials/decision-log.md、paper/materials/learning/ledger.jsonl四个并行记录冲突；源码叶没有报告冲突。按任务“有冲突停下回报”停止，未在live制造冲突工作区或尝试越权解决记录。live HEAD及两份原dirty notes状态前后完全相同，未actual merge、未跑合后测试、无需回滚。live-integration.json和live-merge-preview.log保留完整回执。

因此merged=null、version=null；本源码不是live祖先，不能给c888标implemented或shipped，没有添加eval版本／上线日志／规则已上线双通知。请运维依原兜底职责接收本源码窄差和证据后合入，保留四处并行记录；本批不再自行尝试其他合入方式，也不请求新的规则审批。固定测试通过不等于上线。

## 十项最终处置

- `silent-proposal-49bb659734d555e3`：**waiting**；证据 LYBHQ1X230ZB；账本 silent-0142,silent-0243,silent-0020,silent-0019,silent-0021。LYB F29T6另一少损6HP候选未实打；缺同盘下一房资源和受控整场结局，不能拟终局HP或留药权重。
- `silent-proposal-179fd62ad9b2f71b`：**duplicate**；证据 H1T1F8ML9FUE；账本 silent-0297,silent-0024,silent-0025,silent-0006。可见弃牌区凋萎6伤同步已由实际live祖先9b65f1bee0f26ced606ec256fc3d173db48caa3e覆盖；当前源码保留A10/文本一致性/SL重置门槛。
- `silent-proposal-2ae7436286228166`：**waiting**；证据 H1T1F8ML9FUE；账本 silent-0079,silent-0117,silent-0010,silent-0018。H1 F48T3同12伤换线多付3HP属实；缺完整候选后继及未来收益比较，Prepared双弃投影不覆盖本局Survivor单弃保逃离策略。
- `silent-proposal-de26499e8385f25b`：**waiting**；证据 H1T1F8ML9FUE；账本 silent-0019,silent-0005,silent-0023,silent-0132,silent-0221。H1药水饮用/主动丢弃/事件交换及恢复分账可核，但F48未赢且F49未到，缺受控留药/换时点整场结果及消费者误差归因。
- `silent-proposal-c888545b80180da7`：**waiting**；证据 H1T1F8ML9FUE；账本 silent-0012,silent-0010,silent-0023,silent-0132,silent-0046,silent-0276。H1 F45T5群蛇重放窄子项证据充分，已提交be9577c81a003aff0e69968c928e264f5173da7c，固定撤源失败/恢复通过及沙箱4066项通过；锁内精确合入预检四处并行记录冲突，工程受阻未live，不能标implemented。其他未观察交互保留旧结果。
- `silent-proposal-3b37b520b22f0eaf`：**waiting**；证据 H1T1F8ML9FUE；账本 silent-0007,silent-0011,silent-0027。已有制品消费及毒雾/触媒基础路径；H1末T4为0毒且下一轮未到，缺匹配完整后继和后期模型误差验证，不能校准未来结毒或整战可信度。
- `silent-proposal-b259f9956e08088a`：**waiting**；证据 H1T1F8ML9FUE；账本 silent-0024,silent-0025,silent-0079,silent-0018,silent-0117,silent-0221,silent-0297。0297可见凋萎子项已有live祖先，但饱和换线/单弃沙坑及纸伤多窗口消费范围未闭合；缺同盘全后继和独立策略验证，不能整体duplicate。
- `silent-proposal-34209e8b9f982e49`：**waiting**；证据 H1T1F8ML9FUE；账本 silent-0243,silent-0020,silent-0019,silent-0021。H1末火33→52实到，F48六试均败、F49未到；缺替路线/留药/终局参数的受控联合结局和时间留出，保留权重。
- `silent-proposal-015f25123c45671c`：**waiting**；证据 AD3QSC3P41JU；账本 silent-0228,silent-0255,silent-0030,silent-0069。AD F48胜15→F49首手11空药属实；e8b4bb32只覆盖原白名单遗物组合，AD有10种白名单外伴随遗物，缺同种子留药联合结果/独立校准，宽项继续waiting。
- `silent-proposal-01d7495835a3eb19`：**waiting**；证据 AD3QSC3P41JU；账本 silent-0079,silent-0028,silent-0011,silent-0048。AD F49T1少9伤换保8HP多活一轮仍败；末T2抽牌重规划旧dirty完整输入及受控同抽序后继缺失，不能据此拟8血容差或SL新门槛。

## 台账与后续

仅经根目录learner/ledger.py update追加29条现有账本的where/note链接；silent-0132另链接真实源码提交。没有改claim、evidence、首证、prior、status或version，没有新增support/repeat或标shipped。ledger-updates.jsonl／ledger-cli.log保留输入与CLI回执。旧条目的shipped状态属于旧经验/代码，不能当本次重放修正上线。

本报告和proposal.md交原运维接续；原十个id、完整源提交、负控、自测、真实合入阻塞保留。已实现源码保持本工作树clean；原日志只读，临时材料均在本批scratch。不推送、不运行play、不停局、不调用网络或LLM、不读取游戏二进制，不创建下级agent，不改其他角色知识。

启动器命令白名单可核gpt-6.1-sol／xhigh／default，保存launch-model-whitelist.json；仅为本批宿主启动参数，不假称从不可访问的宿主PID命名空间核到了提供方内部模型或切换了正在运行的请求。

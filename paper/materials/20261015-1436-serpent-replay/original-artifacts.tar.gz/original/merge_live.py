import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'
SOURCE = 'be9577c81a003aff0e69968c928e264f5173da7c'

def git(*args, **kwargs):
    return subprocess.run(['git', '-C', str(LIVE), *args], capture_output=True, text=True, **kwargs)

def save(result):
    (OUT / 'live-integration.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False), flush=True)

with (ROOT / 'ops/live-merge.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    while subprocess.run(['pgrep', '-f', 'knowledge/builders/buil[d]-'], stdout=subprocess.DEVNULL).returncode == 0:
        print('等待知识构建结束', flush=True)
        time.sleep(10)
    result = {'source': SOURCE, 'before_refresh': git('rev-parse', 'HEAD').stdout.strip(),
              'status_before': git('status', '--porcelain=v1').stdout, 'merged': None}
    if git('diff', '--cached', '--quiet').returncode != 0:
        result.update(state='blocked', reason='live存在并行暂存内容，保留现场，未添加或提交其他记录')
        save(result)
        sys.exit(2)
    add = git('add', '--', 'notes/fight-value-backtest.md', 'knowledge')
    if add.returncode:
        result.update(state='blocked', reason='刷新数据暂存失败', error=add.stderr)
        save(result)
        sys.exit(2)
    refreshed = git('diff', '--cached', '--name-only').stdout.splitlines()
    result['refresh_paths'] = refreshed
    if refreshed:
        commit = git('commit', '-m', 'Refresh knowledge data', '-m', 'Co-Authored-By: Codex GPT-6.1-Sol <noreply@openai.com>')
        if commit.returncode:
            result.update(state='blocked', reason='刷新数据提交失败', error=commit.stderr)
            save(result)
            sys.exit(2)
    before = git('rev-parse', 'HEAD').stdout.strip()
    result['before_merge'] = before
    base = git('merge-base', before, SOURCE).stdout.strip()
    branch_paths = git('diff', '--name-only', base, SOURCE).stdout.splitlines()
    overlaps = sorted(set(refreshed) & set(branch_paths))
    result['refresh_overlap'] = overlaps
    if overlaps:
        result.update(state='blocked', reason='本分支与live刚刷新路径重叠，按任务要求停止，不覆盖刷新数据')
        save(result)
        sys.exit(2)
    preview = git('merge-tree', '--write-tree', before, SOURCE)
    (OUT / 'live-merge-preview.log').write_text(preview.stdout + preview.stderr)
    result['preview_exit'] = preview.returncode
    result['preview_sha256'] = hashlib.sha256((preview.stdout + preview.stderr).encode()).hexdigest()
    if preview.returncode:
        result.update(state='blocked', reason='锁内精确源码提交合入预检发现内容冲突；按冲突停止要求保留live，无工作树合并或版本')
        result['live_unchanged'] = git('rev-parse', 'HEAD').stdout.strip() == before
        result['status_after'] = git('status', '--porcelain=v1').stdout
        save(result)
        sys.exit(2)
    merge = git('merge', '--no-edit', SOURCE)
    (OUT / 'live-merge.log').write_text(merge.stdout + merge.stderr)
    if merge.returncode:
        result.update(state='blocked', reason='实际merge失败，保留冲突现场交运维', error=merge.stderr)
        save(result)
        sys.exit(2)
    result['merged'] = git('rev-parse', 'HEAD').stdout.strip()
    env = dict(os.environ, TMPDIR=str(OUT))
    with (OUT / 'sandbox-after-merge.log').open('w') as log:
        check = subprocess.run(['bash', 'tools/test-sandbox.sh'], cwd=LIVE / 'agent', env=env, stdout=log, stderr=subprocess.STDOUT)
    result['sandbox_exit'] = check.returncode
    if check.returncode:
        reset = git('reset', '--keep', before)
        result.update(state='rolled_back' if reset.returncode == 0 else 'rollback_blocked',
                      rollback_exit=reset.returncode, rollback_error=reset.stderr)
        result['merged'] = None
        save(result)
        sys.exit(2)
    result.update(state='merged_checks_passed', source_live_ancestor=git('merge-base', '--is-ancestor', SOURCE, 'HEAD').returncode == 0)
    save(result)

import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extract_evidence", OUT.parents[1] / "extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
manifest = json.loads((OUT / "evidence/evidence-manifest.json").read_text())
streams = {}
checks = []
for meta in manifest:
    path = OUT / "evidence" / (meta["stream"] + ".evidence.jsonl")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == meta["output_sha256"]
    rows = [json.loads(line) for line in path.open()]
    counts = Counter()
    handle = None
    try:
        for row in rows:
            if handle is None:
                handle = open(row["source"], "rb")
            handle.seek(row["offset"])
            raw = handle.read(row["bytes"])
            assert hashlib.sha256(raw).hexdigest() == row["sha256"]
            assert json.loads(raw) == row["row"]
            assert extractor.run_identity(row["row"]) == row["run_id"]
            if meta["stream"] == "states":
                assert row["row"]["state"]["run"]["character_id"] == "SILENT"
            counts[row["run_id"]] += 1
    finally:
        if handle:
            handle.close()
    assert all(counts[run] == count for run, count in meta["counts"].items())
    streams[meta["stream"]] = rows
    checks.append({"stream": meta["stream"], "source_size": meta["source_size"],
                   "rows_verified": len(rows), "counts": meta["counts"]})

states = {r["line"]: r for r in streams["states"]}
decisions = {r["line"]: r for r in streams["decisions"]}

def state(line):
    return states[line]["row"]["state"]

def powers(entity):
    return {p["power_id"]: p["amount"] for p in entity.get("powers", [])}

def summary(line):
    s = state(line)
    c = s.get("combat") or {}
    return {"line": line, "run": s["run_id"], "floor": s["run"]["floor"], "turn": s["turn"],
            "screen": s["screen"], "hp": s["run"]["current_hp"], "max_hp": s["run"]["max_hp"],
            "potions": [{k: p.get(k) for k in ("slot_index", "potion_id", "occupied")} for p in s["run"].get("potions", [])],
            "player": {k: c.get("player", {}).get(k) for k in ("block", "energy", "cards_played_this_turn")},
            "powers": powers(c.get("player", {})),
            "enemies": [{"id": e["enemy_id"], "hp": e["current_hp"], "block": e["block"],
                         "powers": powers(e), "intents": e.get("intents")} for e in c.get("enemies", [])],
            "hand": [{k: h.get(k) for k in ("card_id", "resolved_rules_text")} for h in c.get("hand", [])]}

selected = [297822,297823,297827,297859,297864,297901,298453,298454,298455,
            298603,298604,298723,298728,298755,298761,298827,298830,298832,298834,
            299449,299493,299495,299496,299507,299518,299559,299560,299561,299562,299563,299564,299565]
projections = [summary(n) for n in selected]
(OUT / "state-projections.json").write_text(json.dumps(projections, ensure_ascii=False, indent=2) + "\n")

assert state(298603)["combat"]["player"]["block"] == 2
assert state(298604)["combat"]["player"]["block"] == 10
assert state(298603)["combat"]["enemies"][0]["block"] == 4
assert state(298604)["combat"]["enemies"][0]["block"] == 0
assert state(298603)["combat"]["enemies"][0]["current_hp"] == 100
assert state(298604)["combat"]["enemies"][0]["current_hp"] == 96
assert state(297859)["run"]["current_hp"] == 4
assert state(299493)["run"]["current_hp"] == 15
assert state(299495)["run"]["current_hp"] == 15
assert state(299496)["run"]["current_hp"] == 11
assert state(298830)["run"]["current_hp"] == 34
assert state(298834)["run"]["current_hp"] == 0
assert not any(c["card_id"] == "WITHER" for c in state(298830)["combat"]["hand"])
assert any("6点伤害" in p["line"] for p in state(298830)["agent_view"]["combat"]["discard"] if p["card_ids"] == ["WITHER"])
last = summary(299564)
assert last["hp"] == 3 and last["player"]["block"] == 18
assert state(299565)["run"]["current_hp"] == 0

selected_decisions = [290786,291285,291333,291334,291596,291650,292263,292296,292307,292352,292359,292360,292361,292362,292363,292364]
(OUT / "selected-decisions.json").write_text(json.dumps([decisions[n] for n in selected_decisions if n in decisions], ensure_ascii=False, indent=2) + "\n")
result = {"streams": checks, "total_verified_rows": sum(c["rows_verified"] for c in checks),
          "state_projection_count": len(projections), "fixed_assertions": 16,
          "scope": "材料字节、角色身份和固定事实核验；不代替生产测试或整场反事实"}
(OUT / "evidence-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False))

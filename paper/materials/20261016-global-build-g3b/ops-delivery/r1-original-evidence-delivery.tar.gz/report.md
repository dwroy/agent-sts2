# G3b r1：冻结真实后继帧核验

本轮已检查原r1全部1371锚点及七项要求，交付条件匹配结果和可核缺口；合格matched标签为184。这不等于145264行全部为false，也不证明构筑或既有策略无效。宽父roy-20261016-global-build、原量化父、G4资格与0332保持；未运行原eval/construction.py，未推进advisory/G3a/G3c/G5/G2或任何发布。

写时先date：2026-10-16 15:19:37 CST。原owner/thread：quantitative / 01a12c46-fef2-7282-b689-1fd8b4e0450b；parent_batch=20261012-024317-strategy-proposal；base=51e0c1f475f842b355172f1f2a6f320cae9fb58d。原树干净，旧51e0/报告/failed/rc0历史未修改或合入。只写本learner-results。

## 冻结范围和可复现入口

逐项核主根绝对路径ops-dispatch/input-r1.json（SHA090156079b1e5da5efe292c5be3249cd4a517bd933be9865b1b39983422248de）、完整learner-input.md（aff9f323…）、原数据manifest（588276ef299dd6802bfe3e7e69e5ad07a506a91eb81bd034bdf30b10824d6ecb）、七投影、两授权及旧owner原日志。coordination/anchor-index.json的SHA724e2996…匹配，只作锚点地址核对，未用其chosen元数据作执行/政策真值。run-plans.json仍为空，未补造或覆盖。此报告仅覆盖原r1明确1371锚点，不称全部R328历史；未切换或扩展其他revision。

截止2026-10-16T05:43:17.052214+00:00。所有原行off+len都不超过各source_bounds.complete_prefix_bytes，未借当前追加帧。Parquet只提供候选地址；逐行读取原日志验角色/进阶、行末、长度与SHA。原始读取29165状态、27328决策、1481原脑记录；缓存保留必要状态、所有锚点/非战斗选择及具名动作见证。共享窗口/原件不当独立样本。

确定性提取入口：`nice -n 19 python3 /home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261012-024317/learner/runs/20261016-135541-9b95a56c-ddfa-4e65-b94d-cbe7a5f57947-strategy-proposal/learner-results/extract_outcomes.py`。只做冻结日志连接、历史政策的一步算术核对和机械签名判定，不调用预测器、模拟器、游戏/模型API。当前主提取退出0；最后完整性核验命令为同目录finalize_delivery.py，退出码按finalize-delivery日志保存。生产tsc/vitest/cases均null。

原行在raw-*.jsonl.gz中按原字节保存；evidence-manifest.jsonl为实际引用的12222个原行提供path/off/len/SHA及本地gzip解压偏移，原byte可复核。historical-source-manifest.json按33个实际代码commit保存planner/adapter/admission/route/template，legality-source-manifest.json补原资源约束源码；不执行这些TS或借51e0语义。早期没有admission文件原样标缺，未倒填绑定。四模板在这些原提交中机械摘要76e91c950bfd87d820093bdd7dd4b3f11db15256ea2b6e0bb41b9f1ec89f998c与原生记录对应；status=candidate，不推出functional。

## 七项检查与限定结果

| 要求 | 实际做了什么 | 结果与缺口 |
| --- | --- | --- |
| initial-option | 原accepted脑回答、完整决策/执行result、原始库存前后帧；复合服务连接真正执行的选牌子项 | 981锚点可核选项身份，390仍未知。current从未当实际skip；无法精确绑定的多步商店/子项保留unknown。 |
| actual-route | 本题原计划，或预测前同版本完整快照+当前计划版本摘要+无中间改线/重启；原constructionRoute逐层转换，实际MAP到访或原生节点选择+真实后继 | same 785、changed 139、unknown 447锚点；这些是单维度，不等于条件标签。只存类型摘要而坐标链不能闭合的仍unknown。 |
| completion-choice-policy | 每核心按原missingRequirements、当前可见库存/实际价格/合法资源和声明动作集合逐项核后继选择；已售库存剔除；等距等价而数组顺序未绑定留未知 | 5484锚点×核心审查中政策状态{'changed': 3865, 'same': 1191, 'unknown': 428}。只升级/买遗物药水/多步交易与原模型动作范围不同或资源条件不闭合时不强配。 |
| sl-branch | 原[sl_attempt,sl_reloads]文本保留；查显式reload/SL摘要、config restart及非单调物理层/回合 | null不是1；不能证明同一分支则sl_unknown，不拼接不同尝试的库存/路线。 |
| original-template-endpoint | 原提交模板数量/替代/升级/遗物条件；分别列到达首Boss节点入口与该Boss完成后、任何奖励/后续非战斗动作前的同层干净原帧 | observed_at用原帧observed_ts，晚于原as_of。缺完整节点、死亡、未到期或分支不闭合不能当false。F48不替换成F49。 |
| separate-observations | 组件、具名动作、存活、原run摘要分列；动作要求原执行行+新鲜匹配原帧，否则另列dispatch proxy | 原摘要40局（报告胜3），1局在截点内无摘要；不把同run摘要自动归给每条SL分支或当terminalWin标签。 |
| all-anchor-coverage | anchors.jsonl精确1371 source_off；5484份共享核心审查；显式条件行和压缩其他指标行覆盖原键 | 36316 conditionalSignature行在outcomes.jsonl；108948其他原null指标行在expanded-row-coverage.jsonl.gz。合计145264，无丢option；2454 unsupported原选项仍在锚点覆盖中。 |

coverage中的true表示该维度已检查并保存证据或未知/排除，不表示样本通过。未处理锚点为0；coverage.json.unresolved_anchor_source_offs列初始选项、路线或终点尚未闭合的锚点，政策、SL等其他排除另见各核心审查及分组原因，不把未知列成false。

## 精确分组与排除

原展开行为选项×四核心×四指标，不能当独立局数。完整96组的角色/核心/A10/指标/截止层/模型/政策/模板、候选行/数值行、实际匹配、独立局、每项排除原因均在coverage.json.groups；早期缺绑定组保留null，不用后来的绑定替换。

| 核心 | 截止层 | 指标 | 原模型 | 候选行 | 数值行 | matched | 独立matched局 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| D | 17 | conditionalSignature | observed-opportunity-window4-v1 | 3057 | 3057 | 24 | 23 |
| D | 33 | conditionalSignature | observed-opportunity-window4-v1 | 2661 | 2661 | 16 | 14 |
| D | 48 | conditionalSignature | observed-opportunity-window4-v1 | 1787 | 1787 | 6 | 5 |
| P | 17 | conditionalSignature | observed-opportunity-window4-v1 | 3057 | 3057 | 24 | 23 |
| P | 33 | conditionalSignature | observed-opportunity-window4-v1 | 2661 | 2661 | 16 | 14 |
| P | 48 | conditionalSignature | observed-opportunity-window4-v1 | 1787 | 1787 | 6 | 5 |
| R | 17 | conditionalSignature | observed-opportunity-window4-v1 | 3057 | 3057 | 24 | 23 |
| R | 33 | conditionalSignature | observed-opportunity-window4-v1 | 2661 | 2661 | 16 | 14 |
| R | 48 | conditionalSignature | observed-opportunity-window4-v1 | 1787 | 1787 | 6 | 5 |
| S | 17 | conditionalSignature | observed-opportunity-window4-v1 | 3057 | 3057 | 24 | 23 |
| S | 33 | conditionalSignature | observed-opportunity-window4-v1 | 2661 | 2661 | 16 | 14 |
| S | 48 | conditionalSignature | observed-opportunity-window4-v1 | 1787 | 1787 | 6 | 5 |

5484份共享锚点×核心审查的主要原因（不是独立样本）为：{"missing_native_forecast_model,forecast_policy,template_sha256,as_of": 1576, "actual_node_differs": 380, "composite_service_target_not_exactly_bound_to_executed_child": 88, "actual_selected_option_unsupported_in_original_forecast": 600, "actual_inventory_transition_not_exactly_matched_to_projected_option": 44, "actual_choice_differs_from_completionChoice": 969, "accepted_answer_not_uniquely_bound": 336, "rest_fallback_or_service_choice_not_fully_resolved": 74, "all_frozen_conditions_verified": 184, "initial_dispatch_not_completed": 44, "upgrade_does_not_reduce_original_signature_distance_policy_would_skip": 300, "SL_branch_not_closed": 109, "future_shop_policy_only_considers_revealed_card_add_actions": 112, "unknown_route_node_resource_condition_not_closed": 57, "death_or_no_complete_terminal_node_before_cutoff": 508, "same_room_extra_transactions_outside_original_future_route_steps": 40, "missing_original_before_or_actual_successor_frame": 16, "composite_service_missing_executed_child": 20, "only_room_type_summary_without_bound_coordinate_plan": 19, "not_completed_at_frozen_cutoff": 8}。每个维度的附加缺口仍保留，主原因没有覆盖掉其他问题。未选候选只标unselected，不占原evaluator没有option维的真实identity；非数值指标不拿签名、存活或run摘要补数。实际matched为184；没有制造十局、校准分数或通过文件，由原watcher决定原eval/construction.py的后续运行。

## 原件反例和不确定性

例：4YPGHGJD393H F6锚点1284102845、核心S的后继选择，原政策参照{"id": "LEADING_STRIKE", "upgraded": false, "index": 1, "price": 0, "native": {"index": 1, "upgraded": false, "energy_cost": 1}}，实际{"id": "SKEWER", "upgraded": false, "index": 0, "price": 0, "native": {"index": 0, "upgraded": false, "energy_cost": 0}}。原字段及三类源帧在counterexamples-and-gaps.json。这里只证明政策差异，不判断哪条打法更好。

到达/完成节点的机械签名可以为true，但不能跳过路线、政策、SL或未知事件门禁。独立(run,horizon,core)描述性观察：[{"core": "D", "signature_present": false, "run_horizon_windows": 54}, {"core": "D", "signature_present": true, "run_horizon_windows": 11}, {"core": "P", "signature_present": false, "run_horizon_windows": 47}, {"core": "P", "signature_present": true, "run_horizon_windows": 18}, {"core": "R", "signature_present": false, "run_horizon_windows": 65}, {"core": "S", "signature_present": false, "run_horizon_windows": 64}, {"core": "S", "signature_present": true, "run_horizon_windows": 1}]。这些是完成节点库存的共现记录，不能作为条件匹配分母或可运转/通关率。具名动作有352个去重动作级见证、1196个身份/后继或SL尚不闭合的dispatch代理；都不提供完整施放总次数，未列牌为unknown，不说未施放。效果结算、同实例归属、循环和functional均未由此验证。

原算法在首个Boss就break；类型摘要“休→怪→店…”若无可证明的原坐标计划不能补造。当前题缺计划时，只回查其as_of之前、当前记忆同一F计划版本且中间无改线/重启的完整快照；未读未来计划倒填。恢复方式计数：{'same_question_snapshot': 827, 'not_recovered': 313, 'earlier_snapshot_same_memory_revision_no_intervening_change': 231}。未知节点改变牌组/遗物/金币、同房额外交易不在原未来步骤、实际政策偏离等均列具体原件，不将其当预测失败。

本轮未发现足以新增或推翻牌值/机制经验的因果对照。原P/D/S/R模板candidate、G4异议及无完整functional验证器的旧边界保持。这里发现的是“声明的条件政策”与实际选择/可核条件的差别，不说明实际选择更差。原文政策、不同实际选择、原模板ID、逐原帧证据和下一步见counterexamples-and-gaps.json；交原ops→原watcher→Roy，未代填任何通知ACK。

## 原失败、检查和交接

保留原owner旧failed/rc0，以及本目录真实中间失败：早期admission文件在原提交不存在（后改为保留缺失）；两次缓存上限保护；末验7个默认终点晚于奖励动作，已在同一冻结原件中重建干净端点、不能闭合的排除，原草稿与outcomes保留before-endpoint-audit；计数器/字符串写gzip的离线序列化错误。修正仅本目录提取/缓存材料；压缩整理没有改原日志或线上。主提取最终exit0、原字节/展开键/版本/时间与工作树检查详delivery-integrity.json；这些不是源码测试或校准通过。

缓存最终在256MiB以内，仅必要原件和静态源码片段，没有整库tar/展开副本。未运行预测、历史模拟、额外模型/游戏API、play、源码full、eval或安装。未改源码/经验/construction-calibration.json/配置/注册/ACK/main/live，没有提交、版本或合入。fixes=[]、merged=null、tests三个null、code_proposals=[]、implementation_domains=[]、proposal_results=[]。

限定本轮证据报告完成后即停，不监听/轮询自然局，不接其他阶段。下一步：原ops原样归档本learner-results；原watcher消费outcomes和完整coverage，在原eval入口处理合格行及去重，保持未满足入场线的组不晋级；缺计划坐标/政策遵从/分支或截止帧的具体缺口沿原链保留，不能把本报告当父项/G4/0332关闭。

import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUNS = json.loads((OUT / 'run-identities.json').read_text())
BY_RUN = {row['run_id']: row for row in RUNS}
assert len(BY_RUN) == 6
assert all(row['character'].lower() == 'silent' and row['ascension'] == 10 for row in RUNS)
STREAMS = {}
verification = []
for manifest in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
    name = manifest['stream']
    path = OUT / 'evidence' / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest['output_sha256']
    rows = []
    counts = collections.Counter()
    with Path('/home/dw/Projects/agent-sts2/logs', name + '.jsonl').open('rb') as source:
        for line in path.open():
            item = json.loads(line)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert item['offset'] + item['bytes'] <= manifest['source_size']
            counts[item['run_id']] += 1
            rows.append(item)
    assert all(counts[run] == count for run, count in manifest['counts'].items())
    STREAMS[name] = rows
    verification.append({'stream': name, 'source_size': manifest['source_size'],
                         'verified_rows': len(rows), 'counts': dict(counts), 'raw_byte_checks': True})
(OUT / 'raw-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')

floors = {'DUZUBAJ3A8GP': {27}, '5PM6JAQG6FNQ': {39}, 'CA5KE8GFJ9X2': {13},
          '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {29, 33}}
for item in STREAMS['states']:
    if item['run_id'] == '5PM6JAQG6FNQ':
        state = item['row']['state']
        if any(enemy.get('enemy_id') == 'ZAPBOT' for enemy in (state.get('combat') or {}).get('enemies', [])):
            floors[item['run_id']].add(state['run']['floor'])

summary = []
state_summaries = []
for run, identity in BY_RUN.items():
    selected = {}
    for stream in ['decisions', 'states']:
        selected[stream] = []
        for item in STREAMS[stream]:
            if item['run_id'] != run:
                continue
            row = item['row']
            floor = row.get('floor') if stream == 'decisions' else row['state']['run'].get('floor')
            if floor not in floors[run]:
                continue
            selected[stream].append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    selected['decisions'].sort(key=lambda row: row.get('observed_ts') or '')
    input_path = OUT / (run + '.consumer-input.json')
    input_path.write_text(json.dumps({'run': identity, **selected}, ensure_ascii=False) + '\n')
    issues = [row['_line'] for row in selected['decisions'] if not row.get('decision_id')]
    summary.append({'run_id': run, 'floors': sorted(floors[run]), 'decisions': len(selected['decisions']),
                    'states': len(selected['states']), 'missing_decision_id_lines': issues,
                    'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
                    'scope': '所有指定楼层决策及状态，未删除缺ID行，保留原始行号；其他楼层不在有界消费者范围'})
    for row in selected['states']:
        state = row['state']
        combat = state.get('combat') or {}
        if state.get('screen') not in ['COMBAT', 'GAME_OVER']:
            continue
        player = combat.get('player') or {}
        state_summaries.append({'run': run, 'line': row['_line'], 'observed_ts': row.get('observed_ts'),
            'floor': state['run'].get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', state['run'].get('current_hp')), 'block': player.get('block'),
            'player_powers': player.get('powers'),
            'hand': [{k: c.get(k) for k in ['index', 'card_id', 'upgraded']} for c in combat.get('hand', [])],
            'enemies': [{k: e.get(k) for k in ['enemy_id', 'index', 'current_hp', 'max_hp', 'move_id', 'powers', 'intents']}
                        for e in combat.get('enemies', [])]})
(OUT / 'consumer-input-scopes.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'target-states.jsonl').open('w') as handle:
    for row in state_summaries:
        handle.write(json.dumps(row, ensure_ascii=False) + '\n')
print(json.dumps({'streams': verification, 'consumer_inputs': summary}, ensure_ascii=False))

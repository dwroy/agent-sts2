import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = 'caadc26431119d0c9103264ec231703fd82a9abd'
BATCH = '20261017-144302-strategy-proposal'
dispatch = json.loads((OUT / 'dispatch.json').read_text())
originals = json.loads((OUT / 'dispatched-proposals.json').read_text())
details = [
    ('感染棱柱技能污染',
     'DUZUBAJ3A8GP F27 T4—T5；states 274830—274838。T4火花3、污染0→3→6；T5火花6、污染清空后0→6→12→18。T5挡17对攻击26，实际下一轮损9。',
     '技能同时带来格挡、毒和虚弱；T4迷雾后意图10→9，不支持一律禁技能。未选完整替线没有实战结局。',
     '技能污染与逐击计算已在求解器，火花增长接口已在rollout，SL差值也已有实现。仍缺旧运行实际读取的A10移动表冻结字节，以及污染清除、火花增长、毒/弱/挡同时成立的完整后继校准；本批不另拟禁技能规则。'),
    ('抢夺及返还按实体记账',
     '5PM6JAQG6FNQ F39 T2—T6；states 274341/274351/274352/274354/274358/274362。两次抢夺后力敏各−4，两步法将敏捷恢复0；失落退场后力量恢复，遗忘T6再次抢敏至−2。',
     '另一次尝试states 274391/274392只有一步法，敏捷仅−4→−2。失落退场端点不能证明遗忘死亡返还敏捷；这局没有统一击杀序的胜利对照。',
     '负属性现帧和返力端点可核，但缺逐实体抢夺累计的显式真值、遗忘退场返敏及后续重抢的完整固定链。类型与index不认证稳定实例，不能用敌方总力量/敏捷替代被抢数，也不能据端点认证预测已实现。'),
    ('下水道蚌成长及当前进阶事实',
     'CA5KE8GFJ9X2 F13 T1—T5；states 273237/273252/273263：喷水11→15→19，力量0→4→8；273254/273268虚弱后11/14。末2血、10挡对14，缺2生存量。',
     '覆甲现场9/9/8/7/6不等于已验证全部减层条件；虚弱没有关闭力量增长。不能把这场3血进战的代价当固定房间均值。',
     'enemyTable已按当前asc读取移动数据库，房间代价仍用5样本门槛。缺原运行时A10移动表字节与加压/覆甲全过程的联合校准，未知减层条件保留；本局决策缺尝试元数据，现有消费者不连成完整轮。'),
    ('电击机器人逐实体成长',
     '5PM6JAQG6FNQ F38 T2—T4；states 274307新召唤者UNSET_MOVE，274308力量2/攻击17，274313力量4/攻击19，274315仍活着。',
     '新召唤者没有旧实体的历史；同房存在两个GUARDBOT，名单及index会随减员变化。另一击杀序只有预测。',
     'HIGH_VOLTAGE_POWER增长及新召唤初始化路径已有源码；缺冻结原移动表、可靠实例身份和连续完整后继校准，不能把同类型实体视为同一个，或由成长事实制定统一集火序。'),
    ('沙虫候选与实际执行、成长及资源分账',
     '8JRE1C4H4Z2W F33首/三试T2，decisions 270216/270282同指纹，实损3→15、扣敌10→17；第二试T5 decision270264；末试T11 states276433/276434为玩家5→0、敌154→130。',
     '原/替线五轮死亡0/24与5/24，不能说成死亡比例相同。末试22挡对37，实际零血截断损5，不把算术缺口15当实际入伤。F17抽牌重问也切断原候选。',
     '预测阶段、护栏、派发回执和离线端点均有live祖先；仍缺全部重规划后逐候选续步身份、沙坑/能力与路线资源的逐来源结算，当前消费者明确不认证完整候选。不能将多个窄子项拼成整项完成。'),
    ('实验体SL替换及覆盖重放资源差',
     'YF0LXT1QSTGG F48第二/三试T1，decisions271309/271348同指纹；271354在可继续防御时结束。实损0→9，扣敌45→38；原/替预测24/24全败、当前损0/10、伤54/36。',
     '第六次恢复防御续步后T1仍零损却T5败；第四次T5替换在弃牌后未完整执行。F33第二试SL实胜，不能禁止所有探索。',
     '1698adc96ba434a46942321e0237b70657e625b2已有替换/重放/avoid预测资源差，fdaf787a372880b0438e73bcac7e6d2168b038ed只认证单动作回执。仍缺整候选实际续步与血价归属、同抽序完整替线及独立整战验证，保留SL规则。'),
    ('实验体阶段、毒启动与敏捷取得顺序',
     'YF0LXT1QSTGG F48末试T3—T5；states277512/277513阶段4/111→212/212、旧毒/力清空；277519触媒2且零毒；277523/277526敏捷5→6，已建23挡不变。',
     '前五次T4建立毒雾或余像仍败，组件持有不等于本阶段已经兑现；不能以没启动毒作为唯一死因。末18血、23挡对44是缺3，不补未来毒。',
     'aad2700abed6dff1d66e87fb36aaa6fedb39adf3已有当前阶段、持有及已建能力事实，消费者可核端点；逐候选即时施毒/已结算毒、额外扣血与敏捷先后的来源归属及完整派发结果仍未联合认证。'),
    ('双蟹零胜率并列SL的当轮血价',
     'XP2SL33HT0D9 F33首/二试T3，decisions271992/272040同指纹，实损9→14、扣敌24→27；首/末T1 decisions271982/272195实损2→10、扣敌25→34。',
     'T1替线还触发手里剑永久力量；末试T2临时减力与朝向实现零损，不能仅按少打防御牌否定。所有末战尝试失败，不构成独立胜负反事实。',
     'B2零差没有消除当轮成本，预测差值已有live实现；缺同抽序完整替线、成长兑现后继与独立整战胜线，不能拟新低血优先门槛、HP惩罚常数或禁止探索。'),
    ('双蟹朝向、临时减力和能力兑现窗口',
     'XP2SL33HT0D9 F33末试T2—T5；states278236轮初14挡，278237爪0→−9力量，278242恢复；278240挡20；278249/278252/278253激光57→38→28。',
     'T2零损不推广其他轮；T4两步法4敏捷但脆弱下挡仍6，后续仍败。原提案“升级镣铐未知”是历史原文，后续经验已补限定机制；本批不倒改原文或扩用本批未核的旧局。',
     '船夹板14/T2、临时减力、朝向和脆弱算式已有实现；逐候选拆分原有/新增挡、朝向/弱、已结算毒与存活HP的统一来源校准尚缺，不能把现场参考等同完整执行模型。'),
    ('两局综合：临时减力、轮初挡、能力及SL资源',
     'YF0LXT1QSTGG F48 T1/T4—T5与XP2SL33HT0D9 F33 T1—T5，详见上述同指纹对照和逐帧材料；两个来源局各自只有一个独立分母。',
     '实验体零毒触媒、后取得敏捷不倒补、双蟹零损窗口与最终死亡均保留；不由全败否定全部SL或能力，不把SL恢复记回血/新获药。',
     '多个窄事实已有live源码祖先，但逐来源资源账、全部重规划后的完整候选归属、路线/药水时机及受控整战后继未完整交付。本批不重复建ID或用子项实现关闭原宽提案。'),
]
results = []
sections = []
for entry, detail in zip(originals, details):
    item = entry['add']; title, evidence, counter, reason = detail
    assert item['id'] in dispatch['proposal_ids'] and entry['actual_sha256'] == item['proposal_sha256']
    results.append({'id': item['id'], 'state': 'waiting', 'reason': reason})
    sections.append(f"## {item['id']}：{title}\n\n"
        f"角色/范围：silent，A10；原来源任务 `{item['source_task']}`，实现任务 `strategy-proposal`。\n\n"
        f"账本：{', '.join(item['ledger'])}。原提案 SHA256：`{entry['actual_sha256']}`；原文副本 `{item['id']}.md` 保留。\n\n"
        f"证据：{evidence}\n\n反例/限制：{counter}\n\n"
        f"旧行为与本批结论：{reason}\n\n"
        "预期行为与验证：已有事实字段和选择规则保持；后续只补证据限定的缺项，冻结现场手牌/能力/敌人移动表及全部重问，逐步核毒、挡、HP、实例与资源来源。新增源码须撤源失败、恢复通过并跑仓库沙箱检查；动作规则另用按run_id分组、时间后移的独立同角色对局验证，不将SL次数扩样本。\n\n"
        "拟合/回退：本批不拟合参数、不改排序或删选项、没有生产补丁可回退。若以后实现，按实际源码commit窄回退并保留原日志；上线后另登记版本及双通知Roy。\n\n"
        "处置：**waiting**，不登记implemented/duplicate/shipped；部分既有实现的证据不代表原提案全部完成。\n")
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
proposal = ("# 本批十项静默策略提案核验\n\n"
    f"batch：`{BATCH}`；基线：`{BASE}`。只处理本批已派10个原ID，不领取其他提案。\n\n"
    "本批是普通消费队列，无research_request或implementation_request；根deck-size请求绑定另批，未据此展开专题。工作树初始干净，git merge --no-edit main为Already up to date。\n\n"
    "本批四个同指纹配对均只证明当轮观测取舍，不构成完整候选执行或整战胜负因果。六局均为silent A10，SL不算独立样本；不读取其他角色知识、不用预训练游戏事实补未知。\n\n"
    + '\n'.join(sections))
(OUT / 'proposal.md').write_text(proposal)
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
consumers = json.loads((OUT / 'consumer-summary.json').read_text())
raw_count = sum(sum(item['counts'].values()) for item in manifest) + 6
counts_table = '\n'.join(f"| {r['stream']} | {r['source_size']} | {sum(r['counts'].values())} | {r['invalid_lines']} |" for r in manifest)
consumer_table = '\n'.join(f"| {r['run_id']} | {r['exit']} | {r['segments']} | {r['actions']} | {r['adjacent_observed']} | {r['terminal_observed']} | {r['turns_observed']} | {r['turns_unknown']} |" for r in consumers)
summary = {key: sum(item[key] for item in consumers) for key in ['segments', 'actions', 'adjacent_observed', 'terminal_observed', 'turns_observed', 'turns_unknown', 'complete_candidates']}
(OUT / 'analysis-summary.json').write_text(json.dumps({'raw_rows': raw_count, **summary}, ensure_ascii=False, indent=2) + '\n')
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': BATCH, 'base': BASE,
          'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
report = f"""# 静默策略学习批次回报

十项原提案均保留 waiting：已有局部源码与实盘端点，但本批未取得足以补齐原提案或修改策略的完整数据。不新增源码、知识、提案ID、提交、合入或发布版本；测试字段均为null。

## 身份与范围

- batch：`{BATCH}`；task=strategy-proposal，character=silent，reason=proposal，merge授权为live。
- 工作树：`{OUT.parents[2]}`；base=`{BASE}`，main合并结果Already up to date。
- 已领取10个proposal_ids；本批无proposal_repair、research_request、implementation_request，不扩题，不改根请求/派发文件/原提案。
- 六局runs.jsonl角色均SILENT、A10；身份与原始字节位于run-identities.json及evidence-runs/。旧code字段均+dirty；当前源码不冒称当年完整运行输入。
- 原提案10份SHA全部匹配队列记录；30个既有账本ID逐项关联。只追加本批追溯，不新增support/repeat或改claim/prior/状态/版本，保留并行记录。

## 原始证据

使用指定extract_evidence.py，按显式run/run_id/state.run_id/fingerprint.run选择，不按正文提及选局；{raw_count}个封套（含runs6行）逐项按offset/bytes/SHA读回。所有stream都有各自source_size，扫描期间后续追加不属于该截点。

| 流 | source_size字节 | 本批行数 | 全源无效JSON行数 |
|---|---:|---:|---:|
{counts_table}
| runs | {json.loads((OUT / 'evidence-runs/evidence-manifest.json').read_text())[0]['source_size']} | 6 | 0 |

无效行数是扫描到的全源数字，不归因于本批；本批选中行均完成原字节读回。CA5的SL流零行仅表示本截点未选中；run-plans本批实际33行，没有以旧零行报告断言缺失。未覆盖或改写旧报告/旧截点。

## 确定可核的当轮取舍

| 局/层/回合 | 决策原行 | 原/替实损HP | 原/替敌HP净扣 |
|---|---|---:|---:|
| 8JRE1C4H4Z2W F33 T2 | 270216/270282 | 3/15 | 10/17 |
| YF0LXT1QSTGG F48 T1 | 271309/271348 | 0/9 | 45/38 |
| XP2SL33HT0D9 F33 T3 | 271992/272040 | 9/14 | 24/27 |
| XP2SL33HT0D9 F33 T1 | 271982/272195 | 2/10 | 25/34 |

四组完整fingerprint相同，前后端点逐一匹配observed_ts+fingerprint；完整数字/原行SHA在verified-facts.json。表述为起点至下一轮首匹配决策的净变化，不认定单卡因果/中间无未落盘动作/整候选执行。SL同存档不扩独立分母，XP的T1力量成长收益保留。

补核污染0→3→6、下轮清除及火花3→6；下水道蚌11/15/19及弱后11/14；机器人新召唤及力量2→4、攻击17→19；抢夺/步法/返力/再次抢敏；实验体111→212阶段、零毒触媒2和敏捷5→6不倒补23挡；双蟹14轮初挡、临减−9及恢复、激光57→38→28。证据不支持全局禁技能、统一击杀序、强制能力先手或新血价常数。

## 既有离线消费者实际读回

按consumer-input-scopes.json冻结有界楼层；每个楼层保留全部决策与状态及原始行号，无删缺ID行、无重编身份。六输入共{summary['actions']}条决策，全部exit0。使用node --import现有tsx loader运行learner/audit-selection.ts，只读固定JSON，不接游戏/LLM/网络，不读刷新的知识JSON。

| 局 | exit | 候选分段 | 动作 | 相邻观测 | 终页观测 | 可核整轮端点 | 未知轮 |
|---|---:|---:|---:|---:|---:|---:|---:|
{consumer_table}

合计{summary['segments']}个分段、{summary['adjacent_observed']}个相邻区间、{summary['terminal_observed']}个终页、{summary['turns_observed']}个可核轮端点、{summary['turns_unknown']}个未知轮。完整候选认证数{summary['complete_candidates']}，因为现有工具明确保留actual_full_candidate_result=null；这不证明实际没有执行，仅说明该消费者没有认证其来源/完整性。CA5/DUZ缺已知SL尝试元数据时，消费者按合同保unknown，本批没有填造尝试号。各输入/输出及stderr完整保留。

这些是材料消费者运行及原字节验证，不是生产tsc/vitest或策略撤源红绿。没有源码改动，未执行源码撤除/恢复、自测/live测试；不冒称绿色或新策略收益。

## 源码与live核对

source-readback.json保存当时实际live=`5782a41c4b1db735e3eba8e769e0ad52c356f136`、12叶base/live blob及源码SHA。rollout-live/passive-pieces只有独立历史署名注释差，原字节patch单存；最新路径提交不在live祖先时保false，不用同blob替换提交归属。

- 1698adc96ba434a46942321e0237b70657e625b2：SL原/替/重放/avoid预测资源差，已核live祖先。
- 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb：预测候选阶段审计，已核live祖先。
- fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执，已核live祖先。
- aad2700abed6dff1d66e87fb36aaa6fedb39adf3：当前阶段及组件/能力分账，已核live祖先。
- a32050fbce4c2863f640468c2dbf378fc9157074、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933：离线相邻/终页/轮端点消费者，已核live祖先。

当前进阶移动表读取与房间代价5样本门槛的源码路径已核，不把读取接口存在当作这六局原运行移动表已经恢复。仅借此确认既有子项，不登记任何原宽提案duplicate/implemented。

## 逐项处置与未实现原因

完整逐项证据、账本、反例、旧/预期行为、验证和回退见 `{OUT / 'proposal.md'}`。原10份提案副本逐字保留，所有waiting理由在proposal-results.json及最终result.json。

""" + '\n'.join(f"- `{r['id']}`：waiting。{r['reason']}" for r in results) + f"""

## 交付边界

fixes=[]，merged=null；没有源码commit、合入commit或新eval版本，未改任何角色对局行为。没有新科学异议或反证需要新增通知；上述反例属于原提案已保留的边界。本批不关闭原学习父要求、不冒称经验已入live或消费者已在自然对局采用。

账本仅经根ledger.py update追加本批proposal/report追溯；保留原shipped/proposed状态，不统一降为proposed。无新发现，重复核旧局不再次增加支持数。原始账本前缀和本批CLI回执均保存；材料验证另存material-validation.json，生产测试固定null。没有代码提交，故不创建Co-Authored提交、不做live合入/版本/上线通知。

保留prepare_evidence.py、analyze_evidence.py、write_report.py及其原输出；它们只在本批scratch生成材料，未进入生产源码或提交。早期只读路径探测中猜错文件名的sed失败没有源码/记录写入，不作产品测试失败。ledger-before.json是早期简单逐行合并草稿，正式前态采用ledger-before-fold.json（原ledger.apply规则），不把前者当证据累计口径。

最终机器回报：`{OUT / 'result.json'}`。
"""
(OUT / 'report.md').write_text(report)
print(json.dumps({'report': str(OUT / 'report.md'), 'proposals': len(results), 'summary': summary}, ensure_ascii=False))

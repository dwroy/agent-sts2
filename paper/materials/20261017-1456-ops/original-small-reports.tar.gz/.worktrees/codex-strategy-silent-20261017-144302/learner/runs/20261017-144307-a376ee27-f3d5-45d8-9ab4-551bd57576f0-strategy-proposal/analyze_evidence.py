import collections
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
def read(stream):
    return [json.loads(line) for line in (OUT / 'evidence' / (stream + '.evidence.jsonl')).open()]
decisions = read('decisions')
states = read('states')
by_line = {item['line']: item for item in decisions}
state_index = collections.defaultdict(list)
for item in states:
    row = item['row']
    state_index[(row.get('observed_ts'), row.get('fingerprint'))].append(item)

def matched(item):
    row = item['row']
    found = state_index[(row.get('observed_ts'), row.get('fingerprint'))]
    assert len(found) == 1, (item['line'], len(found))
    return found[0]

def brief(item):
    row = item['row']; state = row['state']; combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'sha256': item['sha256'], 'run': item['run_id'],
            'floor': state['run'].get('floor'), 'turn': state.get('turn'), 'screen': state.get('screen'),
            'hp': player.get('current_hp', state['run'].get('current_hp')), 'block': player.get('block'),
            'powers': {p['power_id']: p.get('amount') for p in player.get('powers', [])},
            'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                         'max_hp': e.get('max_hp'), 'move': e.get('move_id'),
                         'powers': {p['power_id']: p.get('amount') for p in e.get('powers', [])},
                         'intents': e.get('intents')} for e in combat.get('enemies', [])]}

pairs = []
for left, right in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    a = by_line[left]; b = by_line[right]
    assert a['row']['fingerprint'] == b['row']['fingerprint']
    comparisons = []
    for item in [a, b]:
        row = item['row']
        successors = [other for other in decisions if other['line'] > item['line'] and
                      other['run_id'] == item['run_id'] and other['row'].get('floor') == row['floor'] and
                      other['row'].get('sl_attempt') == row['sl_attempt'] and other['row'].get('turn') == row['turn'] + 1]
        successor = min(successors, key=lambda other: other['line'])
        start = brief(matched(item)); end = brief(matched(successor))
        assert [(e['id'], e['max_hp']) for e in start['enemies']] == [(e['id'], e['max_hp']) for e in end['enemies']]
        comparisons.append({'decision_line': item['line'], 'next_turn_decision_line': successor['line'],
                            'attempt': row['sl_attempt'], 'before': start, 'after': end,
                            'observed_hp_loss': start['hp'] - end['hp'],
                            'observed_enemy_hp_reduction': sum(e['hp'] for e in start['enemies']) - sum(e['hp'] for e in end['enemies']),
                            'sl_forecast': row.get('sl_explore'), 'actual_full_candidate_result': None})
    pairs.append({'decision_lines': [left, right], 'same_fingerprint': True, 'comparisons': comparisons,
                  'interpretation': '同题起点至下一轮首个匹配决策的观测净差；未认证单卡因果或完整候选执行'})

key_states = [brief(item) for item in states if
              (277512 <= item['line'] <= 277528) or (278236 <= item['line'] <= 278256) or
              item['line'] in [276433, 276434]]
mechanism_frames = []
last = {}
for item in states:
    frame = brief(item)
    relevant = (item['run_id'] == 'DUZUBAJ3A8GP' and frame['floor'] == 27 and frame['turn'] in [4, 5]) or \
               (item['run_id'] == 'CA5KE8GFJ9X2' and frame['floor'] == 13) or \
               (item['run_id'] == '5PM6JAQG6FNQ' and frame['floor'] in [38, 39])
    if not relevant or frame['screen'] != 'COMBAT':
        continue
    signature = json.dumps([frame['turn'], frame['powers'],
        [(e['id'], e['move'], e['powers'], e['intents']) for e in frame['enemies']]], sort_keys=True)
    if last.get(item['run_id']) != signature:
        mechanism_frames.append(frame)
        last[item['run_id']] = signature
config = []
for item in read('run-config'):
    row = item['row']
    config.append({'run_id': item['run_id'], 'line': item['line'], 'sha256': item['sha256'],
                   'row_keys': list(row), 'code': row.get('code')})
result = {'pairs': pairs, 'key_states': key_states, 'mechanism_frames': mechanism_frames,
          'run_config_scope': config,
          'limitations': ['本批只有六个来源局，SL不扩独立局分母。',
                          '端点净差不认证完整候选或卡牌来源；旧dirty运行知识与数据库未被这些帧完整冻结。',
                          '无未选线的同抽序整战反事实，不拟合血价/能力优先级。']}
(OUT / 'verified-facts.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'pairs': [{'decisions': p['decision_lines'], 'hp_loss': [c['observed_hp_loss'] for c in p['comparisons']],
                             'enemy_hp_reduction': [c['observed_enemy_hp_reduction'] for c in p['comparisons']]} for p in pairs],
                  'key_states': len(key_states), 'mechanism_frames': len(mechanism_frames)}, ensure_ascii=False))

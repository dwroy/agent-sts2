import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
checks = []
def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    assert condition, name

result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
current = json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())['batches'][result['batch']]
check('当前batch角色/树/原ID/runs未变', all(current[k] == dispatch[k] for k in ['task', 'character', 'worktree', 'proposal_ids', 'runs']))
check('非专题非冻结实现', all(k not in current for k in ['research_request', 'implementation_request']))
check('十项均有唯一具体waiting结果', len(result['proposal_results']) == len(set(dispatch['proposal_ids'])) == 10 and
      set(r['id'] for r in result['proposal_results']) == set(dispatch['proposal_ids']) and
      all(r['state'] == 'waiting' and len(r['reason']) > 20 and 'commit' not in r for r in result['proposal_results']))
check('无源码改动口径', result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == [] and
      result['tests'] == {'tsc': None, 'vitest': None, 'cases': None})
check('真实绝对报告路径', Path(result['report']).is_absolute() and Path(result['report']) == OUT / 'report.md' and (OUT / 'proposal.md').is_file())
for row in json.loads((OUT / 'dispatched-proposals.json').read_text()):
    check(row['add']['id'] + '原MarkdownSHA', hashlib.sha256((OUT / (row['add']['id'] + '.md')).read_bytes()).hexdigest() == row['add']['proposal_sha256'])
summary = json.loads((OUT / 'analysis-summary.json').read_text())
check('七流8274原封套', summary['raw_rows'] == 8274)
consumers = json.loads((OUT / 'consumer-summary.json').read_text())
check('六有界消费者均成功', len(consumers) == 6 and all(r['exit'] == 0 for r in consumers))
check('完整候选始终未知', sum(r['complete_candidates'] for r in consumers) == 0)
for scope in json.loads((OUT / 'consumer-input-scopes.json').read_text()):
    check(scope['run_id'] + '输入SHA及无缺ID行', not scope['missing_decision_id_lines'] and
          hashlib.sha256((OUT / (scope['run_id'] + '.consumer-input.json')).read_bytes()).hexdigest() == scope['input_sha256'])
facts = json.loads((OUT / 'verified-facts.json').read_text())
expected = [([3, 15], [10, 17]), ([0, 9], [45, 38]), ([9, 14], [24, 27]), ([2, 10], [25, 34])]
for pair, (hp, damage) in zip(facts['pairs'], expected):
    check(str(pair['decision_lines']) + '配对端点', pair['same_fingerprint'] and
          [x['observed_hp_loss'] for x in pair['comparisons']] == hp and
          [x['observed_enemy_hp_reduction'] for x in pair['comparisons']] == damage)
source = json.loads((OUT / 'source-readback.json').read_text())
for row in source['paths']:
    ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', row['last_path_commit'], source['live_head']]).returncode == 0
    check(row['path'] + '祖先原布尔保留', ancestor == row['last_path_commit_live_ancestor'])
    check(row['path'] + '源码SHA保持', hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['worktree_sha256'])

prefix = json.loads((OUT / 'ledger-prefix.json').read_text())
ledger_raw = Path(prefix['source']).read_bytes()
check('账本原前缀保持', hashlib.sha256(ledger_raw[:prefix['source_size']]).hexdigest() == prefix['sha256'])
inputs = [json.loads(line) for line in (OUT / 'ledger-updates.input.jsonl').open()]
by_id = {row['id']: row for row in inputs}
spec = importlib.util.spec_from_file_location('ledger_api', ROOT / 'learner/ledger.py')
api = importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)
items = {}
found = []
offset = 0
for line in ledger_raw.splitlines(keepends=True):
    row = json.loads(line)
    key = row.get('id')
    before = json.loads(json.dumps(items.get(key))) if key in items else None
    if key in by_id:
        api.apply(items, row)
    if key in by_id and row.get('by') == 'learner:strategy-proposal' and row.get('note') == by_id[key]['note']:
        check(key + '本批行只含追溯字段', set(row) == {'id', 'by', 'where', 'note', 'op', 'ts'} and
              row['where'] == by_id[key]['where'] and offset >= prefix['source_size'])
        after = json.loads(json.dumps(items[key]))
        for value in [before, after]:
            for field in ['where', 'notes', 'history']:
                value.pop(field, None)
        check(key + '本批行保护claim/evidence/prior/status/version', before == after)
        found.append({'id': key, 'offset': offset, 'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'row': row})
    offset += len(line)
check('本批30行逐行实存且不重复', len(found) == len(by_id) == 30 and len(set(r['id'] for r in found)) == 30)
(OUT / 'ledger-own-appends.json').write_text(json.dumps(found, ensure_ascii=False, indent=2) + '\n')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
check('HEAD等于完整40位base', head == result['base'] and len(head) == 40)
check('工作树tracked/index干净', status == '')
(OUT / 'material-validation.json').write_text(json.dumps({'kind': '材料及追溯验证，非生产测试', 'checks': checks,
    'count': len(checks), 'all_passed': True, 'head': head, 'git_status': status}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'passed': True, 'head': head, 'git_status': status}, ensure_ascii=False))

# 静默策略学习批次回报

十项原提案均保留 waiting：已有局部源码与实盘端点，但本批未取得足以补齐原提案或修改策略的完整数据。不新增源码、知识、提案ID、提交、合入或发布版本；测试字段均为null。

## 身份与范围

- batch：`20261017-144302-strategy-proposal`；task=strategy-proposal，character=silent，reason=proposal，merge授权为live。
- 工作树：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-144302`；base=`caadc26431119d0c9103264ec231703fd82a9abd`，main合并结果Already up to date。
- 已领取10个proposal_ids；本批无proposal_repair、research_request、implementation_request，不扩题，不改根请求/派发文件/原提案。
- 六局runs.jsonl角色均SILENT、A10；身份与原始字节位于run-identities.json及evidence-runs/。旧code字段均+dirty；当前源码不冒称当年完整运行输入。
- 原提案10份SHA全部匹配队列记录；30个既有账本ID逐项关联。只追加本批追溯，不新增support/repeat或改claim/prior/状态/版本，保留并行记录。

## 原始证据

使用指定extract_evidence.py，按显式run/run_id/state.run_id/fingerprint.run选择，不按正文提及选局；8274个封套（含runs6行）逐项按offset/bytes/SHA读回。所有stream都有各自source_size，扫描期间后续追加不属于该截点。

| 流 | source_size字节 | 本批行数 | 全源无效JSON行数 |
|---|---:|---:|---:|
| states | 13905807705 | 4062 | 2 |
| decisions | 2239193053 | 3941 | 2 |
| sl-attempts | 45349924 | 38 | 0 |
| run-config | 1950717 | 6 | 0 |
| run-plans | 8906304 | 33 | 0 |
| brain | 743173966 | 188 | 2 |
| runs | 357522 | 6 | 0 |

无效行数是扫描到的全源数字，不归因于本批；本批选中行均完成原字节读回。CA5的SL流零行仅表示本截点未选中；run-plans本批实际33行，没有以旧零行报告断言缺失。未覆盖或改写旧报告/旧截点。

## 确定可核的当轮取舍

| 局/层/回合 | 决策原行 | 原/替实损HP | 原/替敌HP净扣 |
|---|---|---:|---:|
| 8JRE1C4H4Z2W F33 T2 | 270216/270282 | 3/15 | 10/17 |
| YF0LXT1QSTGG F48 T1 | 271309/271348 | 0/9 | 45/38 |
| XP2SL33HT0D9 F33 T3 | 271992/272040 | 9/14 | 24/27 |
| XP2SL33HT0D9 F33 T1 | 271982/272195 | 2/10 | 25/34 |

四组完整fingerprint相同，前后端点逐一匹配observed_ts+fingerprint；完整数字/原行SHA在verified-facts.json。表述为起点至下一轮首匹配决策的净变化，不认定单卡因果/中间无未落盘动作/整候选执行。SL同存档不扩独立分母，XP的T1力量成长收益保留。

补核污染0→3→6、下轮清除及火花3→6；下水道蚌11/15/19及弱后11/14；机器人新召唤及力量2→4、攻击17→19；抢夺/步法/返力/再次抢敏；实验体111→212阶段、零毒触媒2和敏捷5→6不倒补23挡；双蟹14轮初挡、临减−9及恢复、激光57→38→28。证据不支持全局禁技能、统一击杀序、强制能力先手或新血价常数。

## 既有离线消费者实际读回

按consumer-input-scopes.json冻结有界楼层；每个楼层保留全部决策与状态及原始行号，无删缺ID行、无重编身份。六输入共1046条决策，全部exit0。使用node --import现有tsx loader运行learner/audit-selection.ts，只读固定JSON，不接游戏/LLM/网络，不读刷新的知识JSON。

| 局 | exit | 候选分段 | 动作 | 相邻观测 | 终页观测 | 可核整轮端点 | 未知轮 |
|---|---:|---:|---:|---:|---:|---:|---:|
| CA5KE8GFJ9X2 | 0 | 4 | 26 | 0 | 0 | 0 | 5 |
| 5PM6JAQG6FNQ | 0 | 18 | 108 | 67 | 1 | 7 | 8 |
| DUZUBAJ3A8GP | 0 | 8 | 45 | 0 | 0 | 0 | 8 |
| 8JRE1C4H4Z2W | 0 | 66 | 277 | 264 | 1 | 44 | 13 |
| YF0LXT1QSTGG | 0 | 52 | 343 | 328 | 1 | 40 | 15 |
| XP2SL33HT0D9 | 0 | 58 | 247 | 237 | 1 | 28 | 17 |

合计206个分段、896个相邻区间、4个终页、119个可核轮端点、66个未知轮。完整候选认证数0，因为现有工具明确保留actual_full_candidate_result=null；这不证明实际没有执行，仅说明该消费者没有认证其来源/完整性。CA5/DUZ缺已知SL尝试元数据时，消费者按合同保unknown，本批没有填造尝试号。各输入/输出及stderr完整保留。

这些是材料消费者运行及原字节验证，不是生产tsc/vitest或策略撤源红绿。没有源码改动，未执行源码撤除/恢复、自测/live测试；不冒称绿色或新策略收益。

## 源码与live核对

source-readback.json保存当时实际live=`5782a41c4b1db735e3eba8e769e0ad52c356f136`、12叶base/live blob及源码SHA。rollout-live/passive-pieces只有独立历史署名注释差，原字节patch单存；最新路径提交不在live祖先时保false，不用同blob替换提交归属。

- 1698adc96ba434a46942321e0237b70657e625b2：SL原/替/重放/avoid预测资源差，已核live祖先。
- 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb：预测候选阶段审计，已核live祖先。
- fdaf787a372880b0438e73bcac7e6d2168b038ed：单动作派发回执，已核live祖先。
- aad2700abed6dff1d66e87fb36aaa6fedb39adf3：当前阶段及组件/能力分账，已核live祖先。
- a32050fbce4c2863f640468c2dbf378fc9157074、83512ddcd2c70fd9b983dc38524ff25c8970c1d3、e75438488df159b2e8e9d3458cf219b39aadd933：离线相邻/终页/轮端点消费者，已核live祖先。

当前进阶移动表读取与房间代价5样本门槛的源码路径已核，不把读取接口存在当作这六局原运行移动表已经恢复。仅借此确认既有子项，不登记任何原宽提案duplicate/implemented。

## 逐项处置与未实现原因

完整逐项证据、账本、反例、旧/预期行为、验证和回退见 `/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-144302/learner/runs/20261017-144307-a376ee27-f3d5-45d8-9ab4-551bd57576f0-strategy-proposal/proposal.md`。原10份提案副本逐字保留，所有waiting理由在proposal-results.json及最终result.json。

- `silent-proposal-c20b5139dd0dff71`：waiting。技能污染与逐击计算已在求解器，火花增长接口已在rollout，SL差值也已有实现。仍缺旧运行实际读取的A10移动表冻结字节，以及污染清除、火花增长、毒/弱/挡同时成立的完整后继校准；本批不另拟禁技能规则。
- `silent-proposal-ae9e692d680e3819`：waiting。负属性现帧和返力端点可核，但缺逐实体抢夺累计的显式真值、遗忘退场返敏及后续重抢的完整固定链。类型与index不认证稳定实例，不能用敌方总力量/敏捷替代被抢数，也不能据端点认证预测已实现。
- `silent-proposal-52f1e1bd2e7db0ed`：waiting。enemyTable已按当前asc读取移动数据库，房间代价仍用5样本门槛。缺原运行时A10移动表字节与加压/覆甲全过程的联合校准，未知减层条件保留；本局决策缺尝试元数据，现有消费者不连成完整轮。
- `silent-proposal-6dd8bbff876be528`：waiting。HIGH_VOLTAGE_POWER增长及新召唤初始化路径已有源码；缺冻结原移动表、可靠实例身份和连续完整后继校准，不能把同类型实体视为同一个，或由成长事实制定统一集火序。
- `silent-proposal-578e415a259e6835`：waiting。预测阶段、护栏、派发回执和离线端点均有live祖先；仍缺全部重规划后逐候选续步身份、沙坑/能力与路线资源的逐来源结算，当前消费者明确不认证完整候选。不能将多个窄子项拼成整项完成。
- `silent-proposal-c0767768bf6a7ab1`：waiting。1698adc96ba434a46942321e0237b70657e625b2已有替换/重放/avoid预测资源差，fdaf787a372880b0438e73bcac7e6d2168b038ed只认证单动作回执。仍缺整候选实际续步与血价归属、同抽序完整替线及独立整战验证，保留SL规则。
- `silent-proposal-a46bdb7fe711d79a`：waiting。aad2700abed6dff1d66e87fb36aaa6fedb39adf3已有当前阶段、持有及已建能力事实，消费者可核端点；逐候选即时施毒/已结算毒、额外扣血与敏捷先后的来源归属及完整派发结果仍未联合认证。
- `silent-proposal-1044224808015e5c`：waiting。B2零差没有消除当轮成本，预测差值已有live实现；缺同抽序完整替线、成长兑现后继与独立整战胜线，不能拟新低血优先门槛、HP惩罚常数或禁止探索。
- `silent-proposal-7cbc6005db712ba9`：waiting。船夹板14/T2、临时减力、朝向和脆弱算式已有实现；逐候选拆分原有/新增挡、朝向/弱、已结算毒与存活HP的统一来源校准尚缺，不能把现场参考等同完整执行模型。
- `silent-proposal-c59f592f1427a67e`：waiting。多个窄事实已有live源码祖先，但逐来源资源账、全部重规划后的完整候选归属、路线/药水时机及受控整战后继未完整交付。本批不重复建ID或用子项实现关闭原宽提案。

## 交付边界

fixes=[]，merged=null；没有源码commit、合入commit或新eval版本，未改任何角色对局行为。没有新科学异议或反证需要新增通知；上述反例属于原提案已保留的边界。本批不关闭原学习父要求、不冒称经验已入live或消费者已在自然对局采用。

账本仅经根ledger.py update追加本批proposal/report追溯；保留原shipped/proposed状态，不统一降为proposed。无新发现，重复核旧局不再次增加支持数。原始账本前缀和本批CLI回执均保存；材料验证另存material-validation.json，生产测试固定null。没有代码提交，故不创建Co-Authored提交、不做live合入/版本/上线通知。

保留prepare_evidence.py、analyze_evidence.py、write_report.py及其原输出；它们只在本批scratch生成材料，未进入生产源码或提交。早期只读路径探测中猜错文件名的sed失败没有源码/记录写入，不作产品测试失败。ledger-before.json是早期简单逐行合并草稿，正式前态采用ledger-before-fold.json（原ledger.apply规则），不把前者当证据累计口径。

最终机器回报：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261017-144302/learner/runs/20261017-144307-a376ee27-f3d5-45d8-9ab4-551bd57576f0-strategy-proposal/result.json`。

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent

def powers(items):
    return {p['power_id']: p['amount'] for p in items or []}

def projection(item):
    state = item['row']['state']
    run = state.get('run') or {}
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {
        'run': item['run_id'], 'line': item['line'], 'offset': item['offset'],
        'sha256': item['sha256'], 'floor': run.get('floor'), 'turn': state.get('turn'),
        'screen': state.get('screen'), 'hp': run.get('current_hp'), 'max_hp': run.get('max_hp'),
        'energy': player.get('energy'), 'block': player.get('block'), 'powers': powers(player.get('powers')),
        'enemies': [{'id': e.get('enemy_id'), 'index': e.get('index'), 'hp': e.get('current_hp'),
                     'block': e.get('block'), 'alive': e.get('is_alive'), 'powers': powers(e.get('powers')),
                     'intents': e.get('intents')} for e in combat.get('enemies', [])],
        'hand': [{'id': c.get('card_id'), 'index': c.get('index'), 'cost': c.get('energy_cost'),
                  'playable': c.get('playable'), 'upgraded': c.get('upgraded'),
                  'values': {v['name']: v.get('current_value') for v in c.get('dynamic_values', [])}}
                 for c in combat.get('hand', [])],
        'potions': [{'slot': p.get('index'), 'id': p.get('potion_id'), 'occupied': p.get('occupied')}
                    for p in run.get('potions', [])],
    }

def main():
    compact = defaultdict(list)
    with (BASE / 'evidence/states.evidence.jsonl').open() as handle:
        for line in handle:
            item = json.loads(line)
            state = item['row']['state']
            assert state.get('run', {}).get('character_id') == 'SILENT'
            compact[item['run_id']].append(projection(item))
    with (BASE / 'state-projections.jsonl').open('w') as handle:
        for run, rows in compact.items():
            for row in rows:
                handle.write(json.dumps(row, ensure_ascii=False) + '\n')
    transitions = []
    for run, rows in compact.items():
        for a, b in zip(rows, rows[1:]):
            if (a['floor'], b['floor']) not in [(17, 18), (33, 34)]:
                continue
            delta = b['hp'] - a['hp']
            same_max = a['max_hp'] == b['max_hp']
            expected = (a['max_hp'] - a['hp']) * 4 // 5
            transitions.append({'run': run, 'before': a, 'after': b, 'actual_heal': delta,
                                'expected_heal': expected, 'same_max': same_max,
                                'matches_observation': same_max and delta == expected})
    wanted = {
        'RC61MFQM63Y6': [(23, 3), (29, 3), (29, 4), (33, 4)],
        'XTSV1U9JD34T': [(48, 8), (49, 1), (49, 3), (49, 4)],
        'BTSRF7JL1W1Y': [(31, 2)],
        '9Z9H2EXKLF3T': [(48, 8), (48, 10), (48, 11)],
        '7X0W3U8TVA2A': [(31, 13)],
        'MTQ0EUBJ3R6T': [(23, 3)],
    }
    windows = []
    for run, selected in wanted.items():
        for floor, turn in selected:
            previous = False
            current = []
            for row in compact[run]:
                matched = row['floor'] == floor and row['turn'] == turn and row['screen'] == 'COMBAT'
                if matched:
                    current.append(row)
                elif previous:
                    windows.append({'run': run, 'floor': floor, 'turn': turn, 'frames': current,
                                    'next': row})
                    current = []
                previous = matched
            if current:
                windows.append({'run': run, 'floor': floor, 'turn': turn, 'frames': current, 'next': None})
    facts = {
        'state_counts': {r: len(rows) for r, rows in compact.items()},
        'transitions': transitions, 'windows': windows,
        'limitations': ['端点生命差不等于未封顶入伤。', '同局SL窗口为相关观察，不能作为独立对局。',
                        '未执行的留药、改线与整战结果未知。'],
    }
    (BASE / 'evidence-facts.json').write_text(json.dumps(facts, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'state_counts': facts['state_counts'], 'transition_count': len(transitions),
                      'transition_matches': sum(t['matches_observation'] for t in transitions),
                      'windows': [{'run': w['run'], 'floor': w['floor'], 'turn': w['turn'],
                                   'first_line': w['frames'][0]['line'], 'last_line': w['frames'][-1]['line'],
                                   'first_hp': w['frames'][0]['hp'], 'last_hp': w['frames'][-1]['hp'],
                                   'last_block': w['frames'][-1]['block'],
                                   'next_hp': w['next']['hp'] if w['next'] else None}
                                  for w in windows]}, ensure_ascii=False))

if __name__ == '__main__':
    main()

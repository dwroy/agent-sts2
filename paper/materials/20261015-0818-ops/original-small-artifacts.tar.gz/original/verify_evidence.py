import hashlib
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parents[1]))
from extract_evidence import run_identity

directory = sys.argv[1] if len(sys.argv) > 1 else 'evidence'
run_file = sys.argv[2] if len(sys.argv) > 2 else 'verified-runs.json'
manifest = json.loads((BASE / directory / 'evidence-manifest.json').read_text())
allowed = {r['run_id'] for r in json.loads((BASE / run_file).read_text())}
verified = []
for stream in manifest:
    path = BASE / directory / (stream['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    counts = dict.fromkeys(allowed, 0)
    selected = 0
    source = Path('/home/dw/Projects/agent-sts2/logs') / (stream['stream'] + '.jsonl')
    with path.open('rb') as evidence, source.open('rb') as original:
        for encoded in evidence:
            digest.update(encoded)
            item = json.loads(encoded)
            assert item['run_id'] in allowed
            assert item['source'] == str(source)
            assert item['offset'] + item['bytes'] <= stream['source_size']
            original.seek(item['offset'])
            raw = original.read(item['bytes'])
            assert raw.endswith(b'\n')
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            row = json.loads(raw)
            assert row == item['row']
            assert run_identity(row) == item['run_id']
            if stream['stream'] == 'states':
                assert row['state']['run']['character_id'] == 'SILENT'
            if stream['stream'] == 'runs':
                assert row['character'] == 'SILENT'
            counts[item['run_id']] += 1
            selected += 1
    assert digest.hexdigest() == stream['output_sha256']
    assert counts == stream['counts']
    verified.append({'stream': stream['stream'], 'source_size': stream['source_size'],
                     'selected_rows': selected, 'counts': counts, 'sha256': digest.hexdigest(),
                     'raw_bytes_sha_identity_verified': True})
result = {'streams': verified, 'total_rows': sum(s['selected_rows'] for s in verified),
          'all_passed': True,
          'zero_rows_scope': 'fight-plans仅在本次独立冻结字节截点中未选到，不推断其他截点或原日志缺失。'}
(BASE / (directory + '-integrity.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'total_rows': result['total_rows'],
                  'streams': {s['stream']: s['selected_rows'] for s in verified}, 'all_passed': True}))

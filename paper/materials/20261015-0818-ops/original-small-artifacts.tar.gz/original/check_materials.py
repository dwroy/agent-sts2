import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
rows = [json.loads(line) for line in (BASE / 'state-projections.jsonl').open()]
by_line = {r['line']: r for r in rows}
checks = []

def check(name, condition, details):
    assert condition, name
    checks.append({'name': name, 'passed': True, 'details': details})

starts = [by_line[n] for n in [288806, 288837, 288868, 288899]]
keys = ['hp', 'max_hp', 'energy', 'block', 'powers', 'enemies', 'hand', 'potions']
boards = [{k: s[k] for k in keys} for s in starts]
check('MTQ四次T3已保留盘面字段相同', all(b == boards[0] for b in boards),
      {'lines': [s['line'] for s in starts], 'compared_fields': keys,
       'scope': '不声称完整随机状态相同或完整后继可比'})
ends = [by_line[n] for n in [288811, 288842, 288873, 288904]]
afters = [by_line[n] for n in [288812, 288843, 288874, 288905]]
blocks = [r['block'] for r in ends]
losses = [a['hp'] - b['hp'] for a, b in zip(starts, afters)]
damage = [sum(e['hp'] for e in a['enemies']) - sum(e['hp'] for e in b['enemies'])
          for a, b in zip(starts, afters)]
check('MTQ实线即时端点复算', blocks == [29, 29, 29, 19] and losses == [0, 0, 0, 8]
      and damage == [13, 13, 13, 19], {'block': blocks, 'hp_loss': losses, 'enemy_hp_delta': damage})

a, b, c = [by_line[n] for n in [288470, 288471, 288472]]
check('7X仅后段实饮总增量7', a['enemies'][2]['powers'].get('POISON_POWER', 0) == 0
      and b['enemies'][2]['powers']['POISON_POWER'] == 7 and a['hp'] == b['hp'] == 1
      and a['enemies'][2]['hp'] == b['enemies'][2]['hp'] == 25
      and c['enemies'][2]['hp'] == 18,
      {'lines': [a['line'], b['line'], c['line']], 'target': 'DECIMILLIPEDE_SEGMENT_BACK',
       'scope': '组合总量，不拆出基础药效；非早喝对照；不外推其他目标或叠毒'})

a, b = [by_line[n] for n in [286897, 286898]]
check('XTS幽灵一层现场效果', a['powers'].get('INTANGIBLE_POWER', 0) == 0
      and b['powers']['INTANGIBLE_POWER'] == 1 and a['block'] == b['block'] == 16
      and a['hp'] == b['hp'] == 23 and a['enemies'][0]['intents'][0]['total_damage'] == 26
      and b['enemies'][0]['intents'][0]['total_damage'] == 1,
      {'before': a['line'], 'after': b['line'], 'deferred_drink_result': None})
check('XTS夜魇收益未兑现', by_line[286986]['powers']['NIGHTMARE_POWER'] == 3
      and by_line[286987]['screen'] == 'GAME_OVER' and by_line[286987]['hp'] == 0,
      {'before': 286986, 'after': 286987, 'copies_received_next_turn': False})

facts = json.loads((BASE / 'evidence-facts.json').read_text())
dispatch = set(json.loads((BASE / 'dispatch.json').read_text())['runs'])
transitions = facts['transitions']
check('跨幕同上限回血逐对核算', len(transitions) == 22
      and all(t['matches_observation'] for t in transitions),
      {'all_original_proposal_runs_pairs': 22, 'dispatch_anchor_pairs': sum(t['run'] in dispatch for t in transitions),
       'observed_formula': 'floor(当时缺失HP×80%)', 'unobserved_interactions': None})

offsets = {}
fixtures = []
for name in ['silent-ghost-potion-evidence.json', 'silent-poison-win-search-evidence.json']:
    path = BASE.parents[2] / 'agent/tests' / name
    fixture = json.loads(path.read_text())
    prov = fixture['provenance']
    offsets[prov.get('source_offset') or prov['before']['offset']] = (name, fixture)
with (BASE / 'evidence/states.evidence.jsonl').open() as handle:
    for line in handle:
        row = json.loads(line)
        if row['offset'] not in offsets:
            continue
        name, fixture = offsets[row['offset']]
        state = row['row']['state']
        kept = {k: state[k] for k in fixture['state']}
        omitted = sorted(set(state) - set(fixture['state']))
        omitted_nonnull = [key for key in omitted if state[key] is not None]
        check('既有夹具保留字段读回:' + name, kept == fixture['state']
              and omitted_nonnull == ['agent_view', 'native_profile_id'],
              {'source_line': row['line'], 'offset': row['offset'], 'sha256': row['sha256'],
               'omitted_fields': omitted, 'omitted_nonnull': omitted_nonnull,
               'scope': '原字节定位及保留字段对照，不是运行模拟器或tsc/vitest'})

(BASE / 'material-checks.json').write_text(json.dumps({'checks': checks, 'all_passed': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'all_passed': True}))

# 静默猎手策略队列核验报告

记录时间：2026-10-16T08:56:06+08:00。批次：20261016-084302-strategy-proposal。

**结论：本批十个派发ID均为waiting。没有新增源码、知识、提交、合入或发布号。** 原文、账本、六局原始证据和现有实现已逐项核对；支持若干局部机制及同轮血价观察，仍不足以关闭完整候选执行、逐源归属或整战策略请求。详细逐项证据、反例、旧/新行为、验证和回退见 [proposal.md](proposal.md)。

## 身份与基线

- 完整base/最终HEAD：`6476cb0d9c0d73785b0894184d793a80cb145467`；初始与最终工作树均干净，`git merge --no-edit main` 返回Already up to date。没有源码提交后重报base。
- 根learn.json对应行task=strategy-proposal、character=silent、reason=proposal；工作树及六个runs匹配，带十个proposal_ids，不带research_request或implementation_request。只读普通专题入口，其绑定为另一历史批次，不套用本批身份，也未读取其他专题代替。
- dispatch.json保存本批行；assigned-proposals.json保存只属于本批十ID的折叠记录。十份 `<id>.original.md` 均与专用队列保存SHA一致；原Markdown、根请求和队列状态没有被本模型改写。
- 仅本角色六局均由runs.jsonl核实为SILENT/A10，均失败。各运行code带+dirty，不能以当前源码或当前知识重建当时全部实际消费。无其他角色知识、游戏二进制、网络或LLM调用。

## 原始证据和范围

使用本工作树 learner/extract_evidence.py 公共入口提取八流；每流冻结source_size、逐行原offset/bytes/SHA和显式身份。inspect_evidence.py逐行重新seek原日志核原字节、解析后JSON和run身份，拒绝正文提及/冲突身份作为所属局。evidence/evidence-manifest.json与verification.json为实际回执。

| 流 | 本批选中并复核行数 |
|---|---:|
| states | 4062 |
| decisions | 3941 |
| sl-attempts | 38 |
| run-config | 6 |
| run-plans | 33 |
| brain | 188 |
| runs | 6 |
| fight-plans | 0 |
| 合计 | 8274 |

fight-plans在本次冻结截点选中0行，仅表示该截点/身份选择未选到记录，不能据此宣称历史原日志缺失。没有覆盖或改写旧截点/零行初稿。

| 本局 | 终层 | 运行code | 本次离线审计层 |
|---|---:|---|---|
| CA5KE8GFJ9X2 | 13 | 33f02a6f+dirty | 13 |
| 5PM6JAQG6FNQ | 39 | f56da22b+dirty | 38, 39 |
| DUZUBAJ3A8GP | 30 | 93298980+dirty | 27 |
| 8JRE1C4H4Z2W | 33 | b0f41f03+dirty | 17, 33 |
| YF0LXT1QSTGG | 48 | 91c1db90+dirty | 33, 48 |
| XP2SL33HT0D9 | 33 | 60685510+dirty | 33 |

只有以上六局/指定层参与本次重新分析；原提案更宽历史支持数、未观察进阶和其他历史引用均不冒充本批重新验证。六局分别是六个独立来源，SL尝试/四组成对观察不扩独立局数。只作发现及固定材料核验，没有新的时间后移验证局，没有拟合系数。

## 原帧核验和反例

material-checks.json共有41项实际断言，全部通过。这是证据材料核验，不是生产源码测试。它逐项验证火花/污染、蚌力量和弱、抢夺后属性、原帧电击成长、实验体阶段与敏捷时点、双蟹朝向/弱/轮初挡，以及以下四个同指纹配对：

| 局/层/回合（原决策行） | 原线→替线实际玩家净损 | 敌HP净扣 | 限制 |
|---|---:|---:|---|
| 8JRE1C4H4Z2W F33 T2（270216/270282） | 3→15 | 10→17 | 原五轮死亡0/24与5/24，不是同死率；无整战胜线 |
| YF0LXT1QSTGG F48 T1（271309/271348） | 0→9 | 45→38 | 原题预测0/10、54/36不同于实际；覆盖重放在271354结束回合 |
| XP2SL33HT0D9 F33 T3（271992/272040） | 9→14 | 24→27 | B2原0/0、差与误差0不证明安全；随机后继未控 |
| XP2SL33HT0D9 F33 T1（271982/272195） | 2→10 | 25→34 | 攻击同时建立力量；后轮不相同，不能作单牌整战因果 |

完整源行和配对端点见paired-observations.json。末试沙虫终态5→0与敌154→130单列；37攻击−22挡=15是结算前显示需求，不把实扣5写成未封顶15伤。YF末试敏捷5→6仍23挡、18血对44攻，显示需求差3；能力持有/建立不等于已兑现毒伤。双蟹57→38→28分别伴随朝向和虚弱，14轮初挡与新增6挡分开。

反例/限定保留：YF同局F33重打获胜，不否定全部SL；8JRE防御替换延后死亡仍未赢，不推所有防御取舍错误；YF早先已建毒/余像的失败尝试、XP能力启动仍双敌存活，都不以“能力未启动”作唯一死因。未实打的目标顺序、留药/休息/路线后继仍未知。新核事实与原关联账本的限定结论一致，没有新增机制反证，也没有强行支持旧宽策略假设。

## 现有离线消费者读回

复用现有 learner/audit-selection.ts，固定JSON只取指定层；仅去顶层agent_view，保留原_line及_source_sha256，不重编号。audit-input-manifest.json记录实际输入SHA、范围和数量；本范围input-exclusions.json为空，没有伪造decision_id。六个消费者实际返回0，输出/输入/空stderr及压缩SHA见audit-receipts-v2.json。仅nice19顺序运行，无LLM、游戏或刷新知识输入。

| 局 | 选线片段 | 动作 | 相邻动作观测端点 | 终态端点 | 整轮已知/未知窗口 |
|---|---:|---:|---:|---:|---:|
| CA5KE8GFJ9X2 | 4 | 26 | 0 | 0 | 0/5 |
| 5PM6JAQG6FNQ | 18 | 108 | 67 | 1 | 7/8 |
| DUZUBAJ3A8GP | 8 | 45 | 0 | 0 | 0/8 |
| 8JRE1C4H4Z2W | 66 | 277 | 264 | 1 | 44/13 |
| YF0LXT1QSTGG | 52 | 343 | 328 | 1 | 40/15 |
| XP2SL33HT0D9 | 58 | 244 | 237 | 1 | 28/17 |

合计206片段、1043动作、896相邻动作端点、4终态端点；185整轮窗口中119个端点可核、66未知。所有片段actual_full_candidate_result仍为null，这是现有工具不认证完整候选因果的契约；不能解读成没有执行、没有收益或已证明策略无效。CA与DUZ非SL帧尝试号未知，工具保守留空，不补造attempt=1以换取端点数。

过程失败保留：首版run_audits.py在首消费者已经返回0后，统计terminal_observation可空字段时抛AttributeError；audit-run.stderr.txt与首输出原件保留。finish_audits.py复用首成功输出，只运行余五局。其初稿audit-summary.json又按错层级取after而显示端点0；检查实际status/facts后，check_materials.py生成audit-summary-corrected.json，实际896/4如上，未重跑任何消费者。两处均为本批材料汇总脚本问题，不是生产故障、游戏反证或生产回归失败。

## 当前源码范围

本批检查时live HEAD为 `86a4a119eb8e7e1e61be9fda957edd74a70e96f5`。source-scope-with-offline.json记录17个叶的SHA、最后源码commit与真实live祖先检查；16叶相同，sl/explore.ts的三处Roy/Dai历史注释差异保留于sl-live-leaf-difference.patch。没有据此恢复dirty历史运行或变更live。

| 窄覆盖 | 已核真实live祖先源码commit |
|---|---|
| 原答/SL候选快照；actual_turn=null | `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb` |
| SL当轮预测资源差；execution=unverified | `1698adc96ba434a46942321e0237b70657e625b2` |
| 实验体当前快照；已结毒伤=null | `aad2700abed6dff1d66e87fb36aaa6fedb39adf3` |
| HP护栏候选审计；actual_outcome=null | `66283dd9982bdd7f480da7a4d9bfefea0572a9ac` |
| 当前进阶怪物事实读取 | `4ed3c72df30f27b881da637aebf528b97440e0bb` |
| 离线选线/动作与药槽端点 | `a32050fbce4c2863f640468c2dbf378fc9157074` |
| 离线整轮端点 | `e75438488df159b2e8e9d3458cf219b39aadd933` |
| 离线终态端点 | `83512ddcd2c70fd9b983dc38524ff25c8970c1d3` |

这些源码只证明上述窄范围存在。没有整项implemented/duplicate处置，没有将任一last commit冒充本批提交或新上线。完整执行/逐源返还/联合校准缺口分别在proposal.md和下表明确保留。

## 十项派发处置

| ID | 账本 | 状态及仍缺数据 |
|---|---|---|
| silent-proposal-c20b5139dd0dff71 | silent-0168 | waiting：缺历史实际移动表/dirty输入的可复原字节，以及火花增长、污染清除、弱/毒/挡的联合模型校准；未选技能线的完整后继未知。 |
| silent-proposal-ae9e692d680e3819 | silent-0183, silent-0005 | waiting：缺逐实体的抢夺来源账、退场返还与再次抢夺的联合执行验证；类型/index不是跨帧实例ID，没有可归因的另一击杀序整战。 |
| silent-proposal-52f1e1bd2e7db0ed | silent-0231 | waiting：首样本读取已有实现；缺当时实际移动表及加压、虚弱、覆甲的联合回放校准，覆甲完整减层条件仍未隔离。 |
| silent-proposal-6dd8bbff876be528 | silent-0233, silent-0209 | waiting：现存高电压增长已覆盖；缺稳定实例/新召唤代际的连续轨迹及与实际A10输入的联合校准，不能从同类型和血上限保证实例身份。 |
| silent-proposal-578e415a259e6835 | silent-0005, silent-0006, silent-0018, silent-0079, silent-0019, silent-0020, silent-0021, silent-0125, silent-0023, silent-0027, silent-0046, silent-0016 | waiting：窄审计已有实现；缺跨抽弃牌和重规划的完整候选归属、成长逐源兑现，以及路线/药水/SL恢复的联合消费者。 |
| silent-proposal-c0767768bf6a7ab1 | silent-0079 | waiting：缺覆盖重放和重规划后整条候选执行/未派发续步的归属、未选线后继与独立完整胜局；不能以全败比例拟惩罚或禁止探索。 |
| silent-proposal-a46bdb7fe711d79a | silent-0021, silent-0027, silent-0028, silent-0085 | waiting：现场阶段快照已有实现；缺逐候选施毒、已结毒伤、敏捷取得顺序与跨阶段完整执行对账，不据当前零毒调整排名。 |
| silent-proposal-1044224808015e5c | silent-0079 | waiting：当轮血价差不足以校准整战价值；缺受控抽序、随机药瓶后继和独立完整胜线，不能按零胜并列调整全局血价。 |
| silent-proposal-7cbc6005db712ba9 | silent-0021, silent-0005, silent-0007, silent-0063, silent-0065, silent-0241, silent-0242 | waiting：窄机制已有源码；缺朝向、虚弱、临减恢复、成长、伤害和抽牌重规划的联合完整执行归属，现帧不提供整候选反事实。 |
| silent-proposal-c59f592f1427a67e | silent-0005, silent-0006, silent-0019, silent-0020, silent-0021, silent-0028, silent-0027, silent-0079, silent-0046, silent-0085, silent-0060, silent-0063, silent-0065, silent-0062, silent-0039, silent-0013, silent-0011, silent-0023, silent-0018, silent-0087, silent-0241, silent-0242 | waiting：缺完整候选与路线、休息、用药、SL恢复的联合消费者和独立替线后继；净HP、药槽变化不能分解为逐源因果或完整入伤。 |

## 账本和交付

仅经根 learner/ledger.py update 追加30条本角色关联账本的where/note追溯，by=learner:strategy-proposal；不增加重复证据，不改旧claim、首证、prior、status、version或effect，不将原shipped降为proposed。没有新增独立结论/提案，因此不调用add制造重复ID。ledger-update-input.jsonl、ledger-cli-exit.json、ledger-own-appended.json记录实际输入/退出0和每条真实offset/bytes/SHA；ledger-link-receipt.json核原物理前缀、旧history/notes/where前缀及受保护字段保持。队列waiting处置交原调度器消费最终JSON，本模型不手改队列。

提案文件：/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-084302/learner/runs/20261016-084306-84cb77e2-eb18-4ae3-9a8b-adf61ee36ca5-strategy-proposal/proposal.md

本批没有生产源码/知识改动；撤源码失败与恢复通过、tsc、vitest、沙箱套件均不适用且未执行，tests固定null。41项材料断言与六个离线消费者不是该测试字段的成功值。fixes=[]、merged=null，无源码/合入提交、无eval新版本、无shipped或生产采用声明；不进入live合并流程，不更改对局、当前局或其他角色。工作树保持干净。

过程副本和失败日志保留在本批scratch，不归档全仓库、不删除自身运行树。完成报告不关闭学习入库/量化等宽父请求；缺口继续由原队列等待新证据。

## 最终机器回报

```json
{
  "task": "strategy-proposal",
  "character": "silent",
  "batch": "20261016-084302-strategy-proposal",
  "base": "6476cb0d9c0d73785b0894184d793a80cb145467",
  "runs": [
    "DUZUBAJ3A8GP",
    "5PM6JAQG6FNQ",
    "CA5KE8GFJ9X2",
    "8JRE1C4H4Z2W",
    "YF0LXT1QSTGG",
    "XP2SL33HT0D9"
  ],
  "fixes": [],
  "skipped": [],
  "merged": null,
  "tests": {
    "tsc": null,
    "vitest": null,
    "cases": null
  },
  "code_proposals": [
    "silent-proposal-c20b5139dd0dff71",
    "silent-proposal-ae9e692d680e3819",
    "silent-proposal-52f1e1bd2e7db0ed",
    "silent-proposal-6dd8bbff876be528",
    "silent-proposal-578e415a259e6835",
    "silent-proposal-c0767768bf6a7ab1",
    "silent-proposal-a46bdb7fe711d79a",
    "silent-proposal-1044224808015e5c",
    "silent-proposal-7cbc6005db712ba9",
    "silent-proposal-c59f592f1427a67e"
  ],
  "implementation_domains": [],
  "proposal_results": [
    {
      "id": "silent-proposal-c20b5139dd0dff71",
      "state": "waiting",
      "reason": "缺历史实际移动表/dirty输入的可复原字节，以及火花增长、污染清除、弱/毒/挡的联合模型校准；未选技能线的完整后继未知。"
    },
    {
      "id": "silent-proposal-ae9e692d680e3819",
      "state": "waiting",
      "reason": "缺逐实体的抢夺来源账、退场返还与再次抢夺的联合执行验证；类型/index不是跨帧实例ID，没有可归因的另一击杀序整战。"
    },
    {
      "id": "silent-proposal-52f1e1bd2e7db0ed",
      "state": "waiting",
      "reason": "首样本读取已有实现；缺当时实际移动表及加压、虚弱、覆甲的联合回放校准，覆甲完整减层条件仍未隔离。"
    },
    {
      "id": "silent-proposal-6dd8bbff876be528",
      "state": "waiting",
      "reason": "现存高电压增长已覆盖；缺稳定实例/新召唤代际的连续轨迹及与实际A10输入的联合校准，不能从同类型和血上限保证实例身份。"
    },
    {
      "id": "silent-proposal-578e415a259e6835",
      "state": "waiting",
      "reason": "窄审计已有实现；缺跨抽弃牌和重规划的完整候选归属、成长逐源兑现，以及路线/药水/SL恢复的联合消费者。"
    },
    {
      "id": "silent-proposal-c0767768bf6a7ab1",
      "state": "waiting",
      "reason": "缺覆盖重放和重规划后整条候选执行/未派发续步的归属、未选线后继与独立完整胜局；不能以全败比例拟惩罚或禁止探索。"
    },
    {
      "id": "silent-proposal-a46bdb7fe711d79a",
      "state": "waiting",
      "reason": "现场阶段快照已有实现；缺逐候选施毒、已结毒伤、敏捷取得顺序与跨阶段完整执行对账，不据当前零毒调整排名。"
    },
    {
      "id": "silent-proposal-1044224808015e5c",
      "state": "waiting",
      "reason": "当轮血价差不足以校准整战价值；缺受控抽序、随机药瓶后继和独立完整胜线，不能按零胜并列调整全局血价。"
    },
    {
      "id": "silent-proposal-7cbc6005db712ba9",
      "state": "waiting",
      "reason": "窄机制已有源码；缺朝向、虚弱、临减恢复、成长、伤害和抽牌重规划的联合完整执行归属，现帧不提供整候选反事实。"
    },
    {
      "id": "silent-proposal-c59f592f1427a67e",
      "state": "waiting",
      "reason": "缺完整候选与路线、休息、用药、SL恢复的联合消费者和独立替线后继；净HP、药槽变化不能分解为逐源因果或完整入伤。"
    }
  ],
  "report": "/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-084302/learner/runs/20261016-084306-84cb77e2-eb18-4ae3-9a8b-adf61ee36ca5-strategy-proposal/report.md"
}
```

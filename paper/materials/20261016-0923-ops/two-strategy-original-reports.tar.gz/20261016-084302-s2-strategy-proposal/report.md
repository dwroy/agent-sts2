# 静默猎手策略提案复核报告

本批十项均为waiting，未新增源码、知识或游戏规则，未提交、未合live、未发版本。已验证的局部事实与既有源码覆盖保留，具体缺数据条件逐项列明。

## 身份与基线

- task=strategy-proposal，character=silent，batch=20261016-084302-s2-strategy-proposal。
- base与当前HEAD：`6476cb0d9c0d73785b0894184d793a80cb145467`；开工干净，按普通提案执行`git merge --no-edit main`返回Already up to date。
- 根learn.json对应行的task/character/worktree和六局集合已核，proposal_ids精确为本报告十项，没有proposal_repair、research_request、implementation_request。普通专题条件不成立，未承接旧专题、未读取其他专题work_spec、未扩展队列。
- 六局均由runs.jsonl核为SILENT A10；局号：751FN9QM9MHQ, KV0JHNJCKXLS, YQL8RZ8BWN1E, L9SGRBB5R698, PU80F84P6HPN, KEN58SH9SLZ6。单局多次SL保持相关样本口径。原+dirty版本不被当前源码替代，也不声称恢复历史知识快照。

## 原日志证据和限制

共用extract_evidence.py八流退出0。8,444行选中记录逐行原offset/bytes/SHA256/JSON/显式身份核过；run-plans用run，其他流核run_id/state.run_id/fingerprint.run，冲突不接收。清单及原行完整保留在evidence/，复核见evidence-verification.json。

| 流 | 冻结source_size | 本批选中行 |
|---|---:|---:|
| states | 13414327575 | 4167 |
| decisions | 1844484958 | 4071 |
| sl-attempts | 42746605 | 43 |
| run-config | 1834513 | 6 |
| run-plans | 8430614 | 21 |
| brain | 651890738 | 130 |
| runs | 344463 | 6 |
| fight-plans | 2233957 | 0 |

全源扫描计数中的无效行：states 2、decisions 2、brain 1；不是归属本批的有效选中证据，不猜它们的角色或内容。fight-plans只说明该冻结字节截点没有本批选中行，不宣称原日志缺失。没有覆盖旧截点或旧报告。

## 固定事实复核

findings-verification.json的36项、supplemental-findings.json的19项材料断言均首次正式运行通过；这是原材料/端点核验，不是生产测试或模型校准。

1. 751FN9QM9MHQ F17 T2：decisions272434/272575同指纹，状态278479→278483与278620→278623的净失血13/18、敌净扣9/18。T7：272531/272652同指纹，278576→278581与278697→278702，净失血13/23、敌净扣12/18；题面损19/29为保守模型预测，不能混作实际，题面牌伤9/15也不是整轮净扣。T13：272483/272820，278528→278532与278865→278869，损8/2、敌净扣17/11。三组均有血与输出双向代价，六试无胜线。
2. KEN58SH9SLZ6 F17 T10：274505/274568同指纹，280588→280592与280651→280655，损15/21、敌净扣2/4；换线B2 .385→.127，diff=-.2583、se=.0132。T5：274484/274601同指纹，损7/5、敌净扣1/2；实际步法请求第4试274485/T5、第6试274618/T9，不能把省2血当保留相同能力窗口。追加小刀和重问属于实际后续。六试不是六个独立实验。
3. KV0JHNJCKXLS F33 T5：273400/273450同指纹，279460→279465与279511→279515，零净失血、敌净扣36/29。T1：273242/273474，279298→279309与279535→279545，零净失血、敌净扣28/14。两组手工端点与原日志一致，但离线严格轮窗仍unknown，不能人工改为认证，更不能将净扣当回血前毛伤或删牌保血收益。
4. 751 F13T3 decision272361：plan2有药、plan5整战无药参考同预测损8、当前牌伤26/16、各8/8抽样结束，平均终结轮约2.3/2.9。plan3本轮不喝但7/8后续样本喝药，不能混同plan5。缺表成本0与持有价值未知分开；没有实际无药整战/后战留药分支，不据此指责当时饮用。
5. YQL8RZ8BWN1E F17末试T10：states280160/280161，毒2→8但玩家26血13挡、显示自爆41保持；2+6毒不等于已造成6伤或少6自爆。PU80F84P6HPN同F17第5试实际胜余2血；它反驳“本体结束必定已胜”与“残壳阶段必死”的过度归纳，不证明某次改序因果。L9与PU原SL占位指标只支持区分本体/残壳，不能定新排序权重。
6. KEN七次use_potion请求逐槽绑定：274131/274156/274185/274235/274237/274267/274272，后状态280207/280233/280263/280314/280316/280349/280355均所点槽为空。其中274131、274237、274272原接口回执仍pending，未改成completed。六次F17入口均75/86空药栏；发光水后重问、随机生成选牌和全方案收益仍待证，未用空槽替代因果。

以上均为观测净端点或原题模型数据；不重算/冒称验证旧101/102/103/104局资源统计，不把相关SL拆作独立样本，不新增固定血价、必留药、SL或终局阈值。

## 原离线消费者核验

复用现有learner/audit-selection.ts，六次绝对tsx loader、nice15、TMPDIR本批目录、固定JSON输入均exit0，input/output/stderr SHA保留在offline-audit-receipts.json。未联网、未调用LLM、未跑对局、未读取刷新中的知识来决定结果。

| 局号 | 限定层 | 动作/状态 | 题段 | 轮窗可核/未知 |
|---|---|---:|---:|---:|
| 751FN9QM9MHQ | 11,13,17 | 470/473 | 80 | 83/22 |
| KV0JHNJCKXLS | 33 | 274/281 | 47 | 22/32 |
| YQL8RZ8BWN1E | 17 | 328/329 | 147 | 63/11 |
| L9SGRBB5R698 | 17 | 363/370 | 151 | 65/12 |
| PU80F84P6HPN | 17 | 446/447 | 54 | 76/10 |
| KEN58SH9SLZ6 | 3,4,5,11,15,17 | 482/490 | 92 | 70/36 |

合计2,363个动作、2,390帧、571题段、502轮窗（379可核、123未知），2,103相邻观测端点及4终态端点。完整候选结果均null；工具本身明确不认证整候选，0认证不等于0执行或0收益。严格窗口/归因缺口不能以成功CLI退出补齐。KEN原274207无decision_id路线元数据单独保留，不补号、不虚构相邻连续性。

## 已有源码覆盖与live关系

只读观察live HEAD为`86a4a119eb8e7e1e61be9fda957edd74a70e96f5`。source-audit.json核15相关叶：13逐字节相同，potion-cost.ts与sl/explore.ts仅既有Roy/Dai英文历史注释差，差异patch保存。源码祖先核不代表运行dirty知识、自然消费者或完整策略收益已验收。

- `1698adc96ba434a46942321e0237b70657e625b2`：现有SL当前回合资源预测、饱和标记、成长/剩余毒拆项。未改变排序、派发或SL准入，不证明实际执行。
- `9d8278702dbc581b5015ba7ec9a70dc0fb94cccb`：持牌保守损失/弃牌未定和选择阶段事实。actual_held_hp_loss、actual_turn仍null。
- `c4670f4f416c7d93e192e889c5080e7e4e0e733f`：持药未知及同题/整战无药抽样参考。
- `b01edf46b4b619f217d070a196e161df9fe716a0`：巨兽观察阶段与有界末态资源；原anchorRank仍按存活回合、显示敌HP排序。
- `a32050fbce4c2863f640468c2dbf378fc9157074`、`e75438488df159b2e8e9d3458cf219b39aadd933`：离线动作/轮窗观察；缺源、实体歧义、恢复及完整候选收益保持未知。

上述六个实际源码提交均已核为本base和观察live的祖先；它们是既有局部覆盖，本批没有新implemented/duplicate的完整交付。具体组合/改序/跨战反事实尚缺，不能以窄实现关闭原十项。

## 十项处置

| 提案id | 账本 | 层/回合 | 处置与具体缺口 |
|---|---|---|---|
| silent-proposal-366288801d9150d9 | silent-0079, silent-0176 | 751 F17 T2/T7/T13 | waiting；751 F17三组同指纹净血价已核；已有预测审计，缺抽弃重问后的完整候选认证、逐来源实际结算及受控整战后继，不能拟固定SL血价。 |
| silent-proposal-85929bdfc8a3fc1b | silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176 | 751 F13 T3；F17 T7/T13/T17 | waiting；未决弃牌、持药未知与无药参考已有实现；缺真实无药整战、留药后战对照及抽弃续问后的完整收益，不由缺表成本0改成留药价值0。 |
| silent-proposal-efd9f83ee9e1a6dc | silent-0079, silent-0176 | 751 F17 T2/T7/T13 | waiting；751六试同属一局且均未胜；已有预测成本字段，缺保持后轮条件的完整对照及独立验证，不能由局部血价收窄或关闭更差线探索。 |
| silent-proposal-131042659448ae74 | silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176 | 751 F13 T3；F17 T3/T5/T7/T17 | waiting；敏捷、毒、荆棘、呼唤有分项观测且已有提示；缺联合逐来源实际累计、完整候选执行与跨战留药反事实，不能将分项成立当组合收益。 |
| silent-proposal-990f054036609447 | silent-0102, silent-0019, silent-0020 | KV F33 T1/T4/T5；路线F28/F29/F32 | waiting；KV同指纹T5净扣36→29、T1净扣28→14且均零损；严格轮窗认证仍unknown，缺回血毛伤逐来源、完整候选和路线休息替代后继。 |
| silent-proposal-e18d3f18e6cac2a0 | silent-0017, silent-0250, silent-0011, silent-0027, silent-0046 | YQL F17 T9/T10；L9 F17 T14；PU F17 T15/T17 | waiting；巨兽本体/残壳和末态资源提示已有实现，占位HP仍参与旧同轮排序；缺改序后的受控完整后继，PU第5试余2血胜是必须保留的边界。 |
| silent-proposal-9733bb80f445aeae | silent-0017, silent-0019, silent-0020, silent-0250 | YQL F17 T10；L9/PU F17原SL参考 | waiting；残壳毒2→8而26血/13挡/41来袭保持已核；缺提前喝、不喝、留药及新排序的完整分支，不能将加6毒视为已减6自爆。 |
| silent-proposal-c51468c5e8ba6668 | silent-0019 | KEN F3T2/F4T1/F5T2/F11T1-2/F15T1 | waiting；KEN七次饮药请求与所点槽后帧为空均已核，其中三次接口仍pending；缺随机选牌、发光水重问后的完整收益及留药后战对照。 |
| silent-proposal-86a7db08d1a31976 | silent-0079, silent-0021, silent-0125, silent-0005, silent-0176 | KEN F17 T2/T5/T10/T13 | waiting；KEN同指纹T10多失6血仅多2敌净扣、T5省2血却把步法请求延至T9已核；缺逐来源完整兑现、相同后轮对照与独立验证。 |
| silent-proposal-e282a9131b99129a | silent-0021, silent-0079, silent-0125, silent-0176 | KEN F17 T2/T5/T10/T13 | waiting；同指纹血价与能力窗口只支持局部取舍；已有预测拆项，缺完整候选认证及受控后继，不拟统一6血/2伤阈值或声称改线必胜。 |

各项旧/拟新行为、反例、验证、预期影响和回退方法完整见proposal.md及十份.original.md。保留已有十个CLI id，不新建重复提案；code_proposals填这十个既有注册id，implementation_domains=[]表示本批未实施代码。

## 验证、记录与交付边界

本批无源码修改，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；没有把55项材料断言或六次离线运行记为生产测试。无代码提交、合入提交、eval版本或shipped登记，无需进入live合入/刷新/通知流程，也未关闭学习父要求。

账本只经根learner/ledger.py update给关联的16个本角色既有条目追加本批proposal/report追溯与具体waiting说明；不新增重复support/repeat、不改原claim/first_run/prior/status/version、不把旧shipped重置成proposed。CLI输入/输出及按物理行保存的读回另见ledger-update-input.jsonl、ledger-update.stdout.txt、ledger-readback.json；若登记受阻则保留原件并在最终JSON记录，不伪造成功。

工作树HEAD保持base、tracked diff为空；scratch为本批忽略材料。无新结论需要作为反证通知，不代ops/watcher/Roy确认。已有局部覆盖与后续消费者/宽父验收仍分开，实际状态不因本报告变为完成。

两个临时只读查看探针分别遇到combat=null的.get错误、sum含None的错误，另有按旧布局猜路径的rg缺文件；未作为产品bug、游戏反证或测试失败。正式材料脚本与离线消费者均首跑通过，保留探针错误摘要于inspection-notes.md，不覆盖旧历史。

import { readFileSync, writeFileSync } from 'node:fs';
import { gzipSync, gunzipSync } from 'node:zlib';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { auditSelectionExecution } from '../../lib/selection-execution.ts';
const dir = dirname(fileURLToPath(import.meta.url));
const runs = JSON.parse(readFileSync(join(dir, 'dispatch.json'), 'utf8')).runs;
const summaries = [];
const selected = [];
for (const run of runs) {
  const input = JSON.parse(gunzipSync(readFileSync(join(dir, `${run}-consumer-input.json.gz`))).toString());
  let audit, rejection = null;
  try { audit = auditSelectionExecution(input); }
  catch (error) { rejection = { message: String(error.message), missing_decision_ids: input.decisions.filter(row => !row.decision_id).map(row => ({ line: row._line, label: row.label, chosen: row.chosen })) }; }
  if (rejection) {
    writeFileSync(join(dir, `${run}-full-input-rejection.json`), JSON.stringify(rejection, null, 2) + '\n');
    audit = auditSelectionExecution({ ...input, decisions: input.decisions.filter(row => row.decision_id) });
  }
  const bytes = gzipSync(JSON.stringify(audit));
  writeFileSync(join(dir, `${run}-consumer-output.json.gz`), bytes);
  const summary = { run, full_input_accepted: rejection === null, rejection,
    actions: audit.observed_actions.length, segments: audit.segments.length,
    observed_action_endpoints: audit.observed_actions.filter(a => a.observed_interval.status === 'observed_endpoints').length,
    terminal_endpoints: audit.observed_actions.filter(a => a.terminal_observation?.status === 'observed_terminal_endpoints').length,
    observed_turn_endpoints: audit.observed_turns.filter(t => t.status === 'observed_turn_endpoints').length,
    unknown_turns: audit.observed_turns.filter(t => t.status === 'unknown').length,
    certified_full_candidate_results: audit.segments.filter(a => a.actual_full_candidate_result !== null).length };
  summaries.push(summary);
  for (const t of audit.observed_turns) {
    if (run === '8JRE1C4H4Z2W' && t.floor === 33 && [2,5,11].includes(t.turn)) selected.push({ run, ...t });
  }
  console.log(JSON.stringify(summary));
}
writeFileSync(join(dir, 'consumer-summary.json'), JSON.stringify(summaries, null, 2) + '\n');
writeFileSync(join(dir, 'selected-consumer-turns.json'), JSON.stringify(selected, null, 2) + '\n');

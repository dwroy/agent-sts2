import hashlib,importlib.util,json,subprocess
from pathlib import Path
s=Path(__file__).resolve().parent;root=Path('/home/dw/Projects/agent-sts2');wt=s.parents[2]
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
ld=module('ld',root/'learner/ledger.py');cp=module('cp',root/'learner/code_proposals.py')
before=json.load(open(s/'ledger-before.json'));rows=ld.read_rows(str(root/'paper/materials/learning/ledger.jsonl'));after=ld.fold(rows)
owned=[(n,r) for n,r in rows if r and r.get('by')=='learner:strategy-proposal' and r.get('note','').startswith('20261015-084303-strategy-proposal：')]
assert len(owned)==len(before)==26
assert {r['id'] for n,r in owned}==set(before)
assert all(set(r)<= {'op','id','ts','by','where','note'} for n,r in owned)
fields=['claim','status','version','evidence','first_run','asc','prior','prior_note','prior_runs','kind','character']
checks=[]
for ident,v in before.items():
 same={k:v.get(k)==after[ident].get(k) for k in fields}
 assert all(same.values()),(ident,same)
 assert str(s/'proposal.md') in after[ident]['where']['proposal'] and str(s/'report.md') in after[ident]['where']['proposal']
 checks.append({'id':ident,'stable_fields':same,'report_and_proposal_linked':True})
(s/'ledger-readback.json').write_text(json.dumps({'owned_updates':len(owned),'checks':checks,'owned_rows':[{'line':n,'row':r} for n,r in owned]},ensure_ascii=False,indent=2)+'\n')
r=json.load(open(s/'report.json'));d=json.load(open(s/'dispatch.json'));proposals=json.load(open(s/'assigned-proposals.json'))
assert r['base']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],text=True);assert status==''
assert subprocess.run(['git','diff','--exit-code',r['base']],stdout=subprocess.DEVNULL).returncode==0
ids=d['proposal_ids'];assert r['code_proposals']==ids and len(set(ids))==10
assert [p['id'] for p in r['proposal_results']]==ids
assert all(p['state']=='waiting' and p['reason'] and 'commit' not in p for p in r['proposal_results'])
assert r['fixes']==[] and r['merged'] is None and r['tests']=={'tsc':None,'vitest':None,'cases':None}
assert Path(r['report'])==s/'report.md' and Path(r['report']).is_file()
current=json.load(open(root/'ops/codex-ops/learn.json'))['batches'][r['batch']]
assert current['proposal_ids']==ids and current['worktree']==str(wt) and current['character']=='silent'
assert cp.report_links(r,{p['id']:p for p in proposals},'silent')==[]
for i,p in enumerate(proposals):assert hashlib.sha256((s/f'{i+1:02d}-original-proposal.md').read_bytes()).hexdigest()==p['proposal_sha256']
scan=json.load(open(s/'gitleaks.json'));assert scan==[]
closure={'base':r['base'],'head_equals_base':True,'git_status_porcelain':status,'tracked_diff_empty':True,'assigned_ids':ids,'all_assigned_ids_resolved_waiting':True,'root_ledger_trace_rows':len(owned),'ledger_game_fields_unchanged':True,'proposal_sha256':hashlib.sha256((s/'proposal.md').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((s/'report.md').read_bytes()).hexdigest(),'report_json_sha256':hashlib.sha256((s/'report.json').read_bytes()).hexdigest(),'gitleaks_materials_exit':0,'tsc':None,'vitest':None,'cases':None,'source_commits':[],'merge':None}
(s/'closure.json').write_text(json.dumps(closure,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(closure,ensure_ascii=False))

import gzip,hashlib,importlib.util,json
from collections import Counter
from pathlib import Path
s=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extractor',s.parents[2]/'learner/extract_evidence.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
manifest=json.load(open(s/'evidence/evidence-manifest.json'));runs=json.load(open(s/'run-identities.json'))
data={r:{'run':v,'states':[],'decisions':[]} for r,v in runs.items()};checks=[]
for info in manifest:
 path=s/'evidence'/(info['stream']+'.evidence.jsonl');digest=hashlib.sha256();counts=Counter();handles={}
 for raw in path.open('rb'):
  digest.update(raw);x=json.loads(raw);source=Path(x['source'])
  assert source.parent==Path('/home/dw/Projects/agent-sts2/logs')
  if source not in handles:handles[source]=source.open('rb')
  h=handles[source];h.seek(x['offset']);original=h.read(x['bytes'])
  assert x['offset']+x['bytes']<=info['source_size']
  assert hashlib.sha256(original).hexdigest()==x['sha256']
  assert json.loads(original)==x['row']
  assert m.run_identity(x['row'])==x['run_id'] in runs
  counts[x['run_id']]+=1
  if info['stream'] in {'states','decisions'}:
   row=dict(x['row']);row['_line']=x['line'];row['_source_sha256']=x['sha256'];data[x['run_id']][info['stream']].append(row)
 for h in handles.values():h.close()
 assert digest.hexdigest()==info['output_sha256']
 assert all(counts[r]==n for r,n in info['counts'].items())
 checks.append({'stream':info['stream'],'verified':sum(counts.values()),'sha256':digest.hexdigest(),'source_size':info['source_size']})
for r,x in data.items():
 x['decisions'].sort(key=lambda row:row.get('observed_ts',''))
 with gzip.open(s/(r+'-consumer-input.json.gz'),'wt',encoding='utf8') as out:json.dump(x,out,ensure_ascii=False,separators=(',',':'))
(s/'evidence-verification.json').write_text(json.dumps({'streams':checks,'total':sum(x['verified'] for x in checks),'source_byte_hash_and_identity_verified':True},ensure_ascii=False,indent=2)+'\n')
selected={269706,269707,269748,269754,269770,270216,270264,270282}
view=[]
for r,x in data.items():
 for d in x['decisions']:
  if d['_line'] in selected:
   v={k:d.get(k) for k in ['_line','run_id','floor','turn','sl_attempt','sl_reloads','fingerprint','observed_ts','chosen','answers','rationale','rollout','sl_explore','hp_guard','timing','potions']}
   v['criteria']=d.get('questions',{}).get('plan',{}).get('criteria');view.append(v)
(s/'selected-decisions.json').write_text(json.dumps(view,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False));print('total',sum(x['verified'] for x in checks))

# 静默策略学习本批报告

记录时间：2026-10-15T08:51:36+08:00。batch=20261015-084303-strategy-proposal。

本批十项原提案均waiting。已独立核六局原始字节、固定事实与离线消费者；没有足够新证据支持新预算、血价/SL阈值、统一启动权重或固定杀序。既有神化及审计局部实现不冒充整项完成。无源码/知识改动、无提交、无live合入、无新版本或shipped。

## 派发与基线

开工git status干净；HEAD=bdb560d13a43a1cb043a5c55d8f9009ecd39768b。已读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol及learning-code-proposals。只读根learn.json本批行，task/character/worktree/runs及十proposal_ids相符，reason=proposal，无proposal_repair/research_request/implementation_request。普通专题请求绑定20261010旧batch，不承接、不读取另专题替代。按普通流程git merge --no-edit main，结果Already up to date，base保持bdb560d13a43a1cb043a5c55d8f9009ecd39768b。未派下级agent。

六个runs原行均SILENT/A10，运行code均有dirty标记，不凭Git提交还原当时完整源码/知识。brain流183条均engine=codex、model=gpt-6.1-sol；runs.deepseek_calls/ds_*兼容名称不当实际DeepSeek作答证据。未修改当前原生会话/模型配置，未宣称模型已切换。

## 原始证据

共用learner/extract_evidence.py抽八流，每流先冻结source_size；全部所属行重新seek原日志，逐行核offset/bytes/SHA256/JSON正文及显式身份，无冲突或正文冒认。evidence-verification.json保存实际6995条核验结果，evidence/evidence-manifest.json保存每流逐局计数和输出SHA。

| 流 | source_size字节 | 核验所属行 |
|---|---:|---:|
| states | 12959396542 | 3432 |
| decisions | 1515677316 | 3306 |
| sl-attempts | 40088627 | 29 |
| run-config | 1737123 | 6 |
| run-plans | 7952333 | 33 |
| brain | 551865823 | 183 |
| runs | 332536 | 6 |
| fight-plans | 2233957 | 0 |

固定事实断言55项全部通过，详fact-checks.json、fact-checks.log。它们是材料核验，不是生产源码测试或撤码红绿。states/decisions全源各有2条无效JSON，brain全源1条；不据此断言属于本六局。fight-plans该截点选中0行，仅表示此截点未选到，不说原日志缺失。没有覆盖或重写旧零行稿/截点报告。

selected-state-facts.json保留关键状态投影；selected-decisions.json保留关键原题/原答/SL/预算。原提案十份均按保存SHA复制复核。只读本角色knowledge/characters/silent的关联经验，不读其他角色私有知识，不用预训练事实补规则。

## 离线消费者实际读回

用本基线learner/lib/selection-execution.ts，固定单局输入经node+tsx离线调用；不调LLM、网络、游戏或刷新知识。输入和完整输出按局保存*.json.gz，consumer-readback.log及consumer-summary.json保实际结果。

| 局 | 完整输入接受 | 有ID动作 | 候选片段 | 相邻动作端点 | 终页端点 | 整轮端点 | 未知轮 |
|---|---|---:|---:|---:|---:|---:|---:|
| VLZ6CCT8AQ0A | 是 | 699 | 99 | 77 | 0 | 10 | 97 |
| 8JRE1C4H4Z2W | 是 | 659 | 113 | 264 | 1 | 44 | 67 |
| CA5KE8GFJ9X2 | 否，仅有界子集 | 264 | 41 | 0 | 0 | 0 | 46 |
| 5PM6JAQG6FNQ | 是 | 638 | 83 | 202 | 1 | 25 | 76 |
| 61E2QS63Y9WU | 否，仅有界子集 | 442 | 63 | 127 | 1 | 14 | 59 |
| DUZUBAJ3A8GP | 否，仅有界子集 | 599 | 77 | 189 | 1 | 28 | 68 |

CA5原d267143、61E原d267517、DUZU原d268789/268818/268864为没有decision_id的map/route-change行；完整输入真实拒收，原拒收JSON保留。之后只去掉这5行做有界子集，不补ID、不重编号，原行仍在抽取与完整输入内。三个子集结果不是完整输入通过。

总计3301有ID动作、476片段、859相邻动作端点、4终页、121整轮端点、413未知轮。所有完整候选归属仍为null，这是消费者认证边界，不能当作没有执行或零收益。8JRE F33首/第三试T2实际整轮分别损3/15、敌扣10/17，确认多12血价换7净扣；两题指纹相同、0/24与5/24不等死率。第二试T5护栏候选差额不自动成为实际保血收益；末试T11整轮玩家-5/敌-36，死前当前5血22挡对37，截断5不当完整需损15。没有未选整场胜线。

## 现有源码的限定核实

只读live快照52046a3deaa359adbafdd9e6d3e96c2527017f49。核11个相关叶，10个逐字节相同；card-model.ts仅两处Roy/Dai历史注释不同，原diff保存在base-live-card-model.patch，未改动。该窄比对不代表main/live整树等价，也不代表运行dirty树已复原。source-readback.json保存每叶实际SHA256及源码祖先验证。

已核真实live祖先：

- 772b839f8ada31664cb764ea9ad3bdb03da27f64：Model observed Silent Apotheosis upgrades。
- f516592fff557ef02c8ece43433706358c3f7fe6：Propagate the observed Silent Apotheosis Accelerant upgrade。
- a11dd870b09f3f1b67fcb5d6c08af6573fd809e0：重放神化萎靡限定修正和静默经验12.4原增量。
- 3aa6c03a83c5cdcdea29c43e3caa130bcce9bd17：ops: replay checked Silent Apotheosis candidate facts。
- a8b1f8be153fe4f3a34146117546c2178f2e446b：Integrate repaired legacy learning deltas and bounded continuation adapter。

神化已涵盖本局已观察牌对、手牌/后续牌堆传播；当前actual_cast_this_fight=null，属性组合未知边界保留。选择快照、护栏/SL候选差与单动作派发回执均已有；它们不认证完整候选。cf72bd21148059f111f760cc98a727369e34a47e等既有离线审计消费者只用于本次读回，不充作本批新增提交或闭合整个在线持续身份要求。无新源码缺口被本批固定证据独立证明到足以新增规则或关闭宽项。

## 十项结果

各项原账本、证据局/层/回合、反例、旧/预期行为、拟合/验证和回退完整列于同目录proposal.md。以下十id与派发集合完全相同，均保留待新证据重派。

| 原id | 处置 | 具体未实现原因 |
|---|---|---|
| silent-proposal-89354805ee4d7e77 | waiting | 缺实际施放身份贯穿抽牌、选牌、药水和SL的消费者校准，以及未覆盖属性交互证据；现有窄传播不足关闭整项。 |
| silent-proposal-f2bfceddb1898dca | waiting | 缺完整模型下同起点、同随机池和同总预算的分阶段MC配对及稳定性曲线；707ms单题不足制定新预算、留药或固定目标规则。 |
| silent-proposal-283a164780d11e69 | waiting | 同源主项仍缺实际施放持续身份及未覆盖升级交互校准；已补链和局部源码不是完整live实现证明。 |
| silent-proposal-ebbfe3b97548756d | waiting | 缺十五条经验的属性组合、升级联动、状态期限和战斗/路线/休息消费者联合校准；分项原帧正确不能证明全项完成。 |
| silent-proposal-e5b87be50f28f311 | waiting | 已有三阶段预测、单动作回执和44个本局整轮端点，但缺跨重规划的持续候选身份及全过程生产归属校准；端点不认证完整候选。 |
| silent-proposal-49632bc4878fb597 | waiting | 本局没有正敏捷实测，尚无覆盖力量、正负敏捷、虚弱及独立成长四条路径的联合生产校准和独立验证；不增统一血价权重。 |
| silent-proposal-66532328a585941f | waiting | 缺同HP、构筑、药水与完整抽序下不同启动顺序的整战配对及可复现收益函数；局部空打代价不足拟合启动权重。 |
| silent-proposal-43a76a31ba7bdcfa | waiting | 缺同起始HP、构筑和完整抽序下的SL整战比较及另一可核完整线路；负敏捷和毒端点不足改变SL范围或阈值。 |
| silent-proposal-5264153a4a4b0e5c | waiting | 缺A10逐实体召唤、复现、退场和成长的完整生产校准及另一focus的整战后继；未执行的39伤零损线不能当收益。 |
| silent-proposal-bddfa690a84e03d0 | waiting | 缺伤害唤醒、眩晕期限和恢复成长全链的生产校准及同抽换序的完整后继；四次失败不足拟合排序血价或固定杀序。 |

## 记录、验证与限制

只经根learner/ledger.py update为相关26个静默条目追加by=learner:strategy-proposal的本批proposal/report追溯链接，不改claim、evidence、first_run、prior、asc、status或version，不降已shipped历史；不重复登记既有support/repeat、不建新提案id。CLI输入、输出和最终读回保存在本批目录，专用队列由proposal_results交原调度器消费，不手改learn.json或队列。

没有新源码，撤源码失败/恢复通过不适用，未跑tsc/vitest，tests三项均null；不把材料55断言或离线消费者通过冒作生产测试。没有源码提交，不需要合入或上线版本，merged=null。未运行play、不联网、不推送、不读密钥/.env/二进制，不改运维prompt或其他角色行为；没有规则变化通知或新shipped。

全部六局是已有历史发现样本，不是时间后置验证。未观察升级、持续身份、召唤复现、伤害唤醒/眩晕及未选整战后继保持未知；同局SL不扩独立分母，选择文本和端点不能冒认证因果收益。原提案/经验未被新反证推翻，本批没有新的必要反证通知，不以报告完成关闭学习父要求或宣称经验已入库/大脑已采用。

只读定位时几条猜测的源码路径不存在（core/loop、hand/screens/types、rollout-enemy*等），已改用rg --files定位实际路径；未生成生产修改。base/live的git diff --no-index退出1只是已知注释差异，不是测试失败。消费者三份完整输入拒收是原身份限制，原件保留，没有放宽验证。

最终检查与账本追加读回、密钥扫描结果见closure.json及ledger-readback.json；未提交、不借用历史测试绿。


交运维：proposal=/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-084303/learner/runs/20261015-084315-526ea6ba-0278-4c14-a8b5-e536a42d8470-strategy-proposal/proposal.md；report=/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261015-084303/learner/runs/20261015-084315-526ea6ba-0278-4c14-a8b5-e536a42d8470-strategy-proposal/report.md。最终结构化回报在report.json。

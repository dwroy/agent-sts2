import json
from pathlib import Path
s=Path(__file__).resolve().parent
floors={'VLZ6CCT8AQ0A':{35,43,45},'8JRE1C4H4Z2W':{17,33},'CA5KE8GFJ9X2':{13},'5PM6JAQG6FNQ':{33,39},'61E2QS63Y9WU':{17,23},'DUZUBAJ3A8GP':{30}}
def powers(o):return {p['power_id']:p['amount'] for p in o.get('powers',[])}
def compact(x):
 t=x['row'];v=t['state'];r=v.get('run') or {};c=v.get('combat') or {};p=c.get('player') or {}
 return {'run':x['run_id'],'line':x['line'],'offset':x['offset'],'ts':t.get('observed_ts',t.get('ts')),'screen':v.get('screen'),'floor':r.get('floor'),'turn':v.get('turn'),'player':{'hp':p.get('current_hp',r.get('current_hp')),'max_hp':p.get('max_hp',r.get('max_hp')),'energy':p.get('energy'),'block':p.get('block'),'powers':powers(p)},'enemies':[{'index':e.get('index'),'id':e.get('enemy_id'),'hp':e.get('current_hp'),'block':e.get('block'),'powers':powers(e),'move':e.get('move_id'),'intents':e.get('intents'),'alive':e.get('is_alive')} for e in c.get('enemies',[])],'hand':[{'index':h.get('index'),'id':h['card_id'],'upgraded':h['upgraded'],'cost':h.get('energy_cost'),'values':{z['name']:[z.get('base_value'),z.get('current_value')] for z in h.get('dynamic_values',[])}} for h in c.get('hand',[])],'deck_upgrades':sum(h.get('upgraded',False) for h in r.get('deck',[]))}
rows=[]
for line in open(s/'evidence/states.evidence.jsonl'):
 x=json.loads(line);v=x['row']['state'];r=v.get('run') or {}
 assert r.get('character_id')=='SILENT' and r.get('ascension')==10
 if r.get('floor') in floors[x['run_id']]:rows.append(compact(x))
(s/'selected-state-facts.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
known={275564,275565,275679,275680,275687,275749,275753}
seen=set()
for r in rows:
 key=(r['run'],r['floor'],r['turn'])
 show=r['line'] in known or r['offset'] in {8445489179,8445536391}
 if r['run']=='CA5KE8GFJ9X2' and key not in seen:show=True
 if r['run']=='61E2QS63Y9WU' and ((r['floor']==17 and r['turn'] in {5,6,7}) or (r['floor']==23 and r['turn'] in {2,3,4,5})) and key not in seen:show=True
 if r['run']=='DUZUBAJ3A8GP' and r['turn'] in {1,2,3,4,5,6} and key not in seen:show=True
 if show:print(json.dumps(r,ensure_ascii=False))
 seen.add(key)
print('selected',len(rows))

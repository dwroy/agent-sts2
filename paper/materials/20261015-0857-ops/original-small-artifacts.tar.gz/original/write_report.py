import hashlib,json,subprocess
from pathlib import Path
s=Path(__file__).resolve().parent
items=json.load(open(s/'assigned-proposals.json'));dispatch=json.load(open(s/'dispatch.json'));source=json.load(open(s/'source-readback.json'));facts=json.load(open(s/'fact-checks.json'));verification=json.load(open(s/'evidence-verification.json'));consumer=json.load(open(s/'consumer-summary.json'));stamp=(s/'record-time.txt').read_text().strip()
content=[
('神化的升级传播及施放身份','VLZ6CCT8AQ0A / F35T1、F43T1—T2、F45T1',
 's275564→275565实付7→5能，防御5→8、打击7→10、匕首雨5→7、必备工具1→0费；s275679→275680勒紧4→6、尖啸6→8，s275687后来抽入毒雾+且场外升级计数仍4。',
 '已施放的F43下一轮玩家90→77、敌254→203；F45持有神化但未施放，不能预支升级或宣称打出即可赢。当前PAIRS及手牌/牌堆传播已有窄实现；actual_cast_this_fight仍明确为null，虚弱/脆弱/缩小/暗影等组合仍保留未知。',
 '保留现有已观测牌对传播，另需按实际派发和后帧核验本战施放身份，跨抽牌/选牌/药水/SL/换战持续区分；不增加必打规则或固定加分。',
 '缺实际施放身份贯穿抽牌、选牌、药水和SL的消费者校准，以及未覆盖属性交互证据；现有窄传播不足关闭整项。',
 '固定F35/F43原帧逐牌比对，F45验证持有不当施放；用后置独立A10对局验证身份延续、失效和未知边界。'),
('三骑士全败候选与MC预算','VLZ6CCT8AQ0A / F43、F45T1/T4/T5',
 'd269748 timing.mc_ms=707，随机药只1/12样本且rollout退化；d269754另一次饮药选择后须重问。d269770所选13损/24伤，另三线均31损/32伤。s275749→275753总攻击83→59；s275754为32HP/20挡，终帧三敌21/80/77。',
 'F43实际90→33获胜、F44休息到67/104仍在F45败；攻击候选未实打，不能把少8伤当败因，单题预算耗尽也不证明固定预算应改多少。',
 '先以完整模型、相同起点/随机池/总预算做MC阶段分配配对，报告有效样本、未知、同轮净损和逐敌击杀缺口；保留所有选项及并列。',
 '缺完整模型下同起点、同随机池和同总预算的分阶段MC配对及稳定性曲线；707ms单题不足制定新预算、留药或固定目标规则。',
 '固定F45T1退化题及T4全败题与较成熟F17/F33/F43分层核验；不将本批发现帧当独立留出。'),
('神化经验的同源实现链接','VLZ6CCT8AQ0A / F35T1、F43T1—T2、F45T1',
 '与89354805ee4d7e77共享silent-0237/0238及同一神化原帧；原经验silent-apotheosis-combat-upgrades已经关联。两个原Markdown各自SHA均核实，保留两个原id，不新增重复请求。',
 '经验active、题意同源或窄源码已存在，都不证明实际身份和全部升级交互已经实现。',
 '沿原神化主项复用已证传播和原经验链；完整交付前不将补链条目登记duplicate。',
 '同源主项仍缺实际施放持续身份及未覆盖升级交互校准；已补链和局部源码不是完整live实现证明。',
 '复用主项固定原帧及角色/进阶隔离检查，经验链接和源码覆盖分别验收。'),
('十五条机制与资源消费者','VLZ6CCT8AQ0A / F43T1—T5、F45T1—T5、F44休息',
 '原提案十五条经验、十四账本逐项保留。F43神化后勒紧6；F45末轮步法/口红合3敏、勒紧4，后空翻8、防御12分源，s275754总挡20。s275753临时减力后的四段攻击合59，终帧三敌均有血。',
 '持续能力/毒只有已建立且已结算部分可计；未建毒雾、未到火堆、另一focus与锻造的整战结果均不能补记。宽经验的历史支持数不能充作相同属性实验分母。',
 '复用已准确的逐击力量、逐牌敏捷、勒紧、毒结算与资源事实；发现固定消费者偏差才补静默路径，不拟合统一保血/输出权重。',
 '缺十五条经验的属性组合、升级联动、状态期限和战斗/路线/休息消费者联合校准；分项原帧正确不能证明全项完成。',
 '从固定原帧逐源验证数值及期限，资源链保留胜战消耗与实际净回；缺未选路线/休息/目标的完整后继时保持未知。'),
('SL与HP护栏的实际执行归属','8JRE1C4H4Z2W / F33首/第三试T2、第二试T5、末试T11；F17T6',
 'd270216与d270282指纹相同。第三试SL原线/替线预测死亡0/24与5/24；现有离线消费者读回首/第三试T2整轮玩家-3/-15、敌-10/-17，确认多12血价、多7净扣。末试T11整轮玩家-5、敌-36，末敌130，不能将截断5当完整入伤。',
 '首/第三试均没有可核整战胜利替线；末试更久仍败，也反对把所有防御替换一概判错。第二试T5候选差额不是未执行原线的实际保血收益。',
 '保留原答、护栏、SL及派发阶段，按后续抽牌/选择/重问结束原候选归属；状态端点、能力建立与实际整轮另账。',
 '已有三阶段预测、单动作回执和44个本局整轮端点，但缺跨重规划的持续候选身份及全过程生产归属校准；端点不认证完整候选。',
 '固定同盘T2、第二试T5、F17T6和末T11；需要逐候选生产归属与后置独立局验证，不改血价、护栏或SL阈值。'),
('力量、敏捷、弱与蚌成长','CA5KE8GFJ9X2 / F13T1—T5',
 's273252和s273263蚌力量4/8、同招喷水15/19；s273268虚弱后14攻击，玩家2血10挡，s273269敌余16。当前全局原始状态已冻结，计划中的步法没有取得或建立。',
 '本局没有正敏捷实验；虚弱未取消下一次加压，不能从计划的步法补正敏捷或把单一成长实验当四条路径联合校准。',
 '按当前属性、逐击修正、虚弱和独立成长分项比较，保留现有排序与权重。',
 '本局没有正敏捷实测，尚无覆盖力量、正负敏捷、虚弱及独立成长四条路径的联合生产校准和独立验证；不增统一血价权重。',
 '固定F13T3/T5实际出牌前缀与当前进阶敌人数据，逐步对挡/敌血/净损；未来有正敏捷的独立同角色局另验。'),
('持有、启动和构筑兑现','5PM6JAQG6FNQ / F39末试T2；F33',
 's274379→274380（原offset 8445489179→8445536391）无毒冒泡后能量5→4，玩家HP29→29，失落35、遗忘72均不变，两个敌人都未出现毒层；35是敌血，旧账本的玩家血勘误已经存在。',
 '同局F33已有雾3/触媒1/群蛇4并赢，但构筑、敌人和生存条件不同；不能据此给出统一启动顺序或收益常数。',
 '持有、到手、实付、已建立和后继分账，不预支未建能力或未来毒。',
 '缺同HP、构筑、药水与完整抽序下不同启动顺序的整战配对及可复现收益函数；局部空打代价不足拟合启动权重。',
 '固定末试F39T2验证1能零净扣/零施毒；F33作为不同现场的对照观察，按run分组后置验证，不扩SL分母。'),
('族母吸取、负敏捷与SL','61E2QS63Y9WU / F17T5—T7',
 's273504负2敏捷下两张防御各3；s273505/273507总挡3/6。敌力量s273504/506/508为2/-4/2；T6→T7敌本体67→34、毒17→15，玩家56→48。',
 '本局首试获胜，不构成改变SL范围或另一完整路线的证据；已建毒端点与逐击临减/恢复需分账。',
 '保留吸取、负敏捷、毒与临时减力的分项事实，不从本局首试赢定新SL偏好。',
 '缺同起始HP、构筑和完整抽序下的SL整战比较及另一可核完整线路；负敏捷和毒端点不足改变SL范围或阈值。',
 '固定F17T5—T7逐步比对负敏捷牌挡与毒端点，完整SL线路需新证据；现有局内帧不是独立留出。'),
('胧光怪召唤、成长和目标','61E2QS63Y9WU / F23T1—T5，重点T4',
 's273593→273596：玩家25→10，幻象14→2仍存活，本体76→41；到T5两实体力量均6。原T4全体净扣47与实损15可核，不能将本体推进当全体退场。',
 'focus幻象39伤/零损候选未实打；本局未观察到退场后再次复现，不能用历史召唤窄源码证明A10所有成长/复现/目标收益。',
 '保留全部合法目标，数值相同列并列；逐实体HP/成长与攻击者分列，不强制首杀。',
 '缺A10逐实体召唤、复现、退场和成长的完整生产校准及另一focus的整战后继；未执行的39伤零损线不能当收益。',
 '固定F23召唤与T4/T5成长/幻象余血，再用实际复现和换目标后继验证；不外推固定杀序。'),
('熟睡甲虫唤醒、眩晕与成长','DUZUBAJ3A8GP / F30T1—T6，四次相关尝试',
 's274906/914/919睡层3/2/1；自然醒后滚动。末试s275017临减后力量-4、14攻击，s275018恢复/成长到4、22攻击；s275022为1HP/16挡，s275023实际死亡。',
 '四试同一局，不是四个独立样本；前三次预测截断不补写为已结算死亡。末试T4多输出也付更多血价，没有同抽换序的完整胜线。',
 '依当前进阶分别核睡层、覆甲、眩晕与成长恢复，不把未知换线胜率或血价写成规则。',
 '缺伤害唤醒、眩晕期限和恢复成长全链的生产校准及同抽换序的完整后继；四次失败不足拟合排序血价或固定杀序。',
 '固定自然睡层/醒后T5—T6及实际终局，另需独立伤害唤醒和眩晕接续原帧；新实现才做撤码红/恢复绿。')]
assert len(content)==len(items)==10
results=[]
proposal=[f'# 静默策略提案逐项复核\n\n记录时间：{stamp}。批次：{dispatch["task"]} / 20261015-084303-strategy-proposal；本批普通队列，不承接另批专题。\n\n十项均waiting；以下是原CLI提案的本次核验与后续验证要求，不另建id，不改原提案。当前无新策略源码或知识更改。\n']
for p,(title,where,evidence,counter,expected,reason,validation) in zip(items,content):
 results.append({'id':p['id'],'state':'waiting','reason':reason})
 proposal.append(f'## {p["id"]}：{title}\n\n角色/进阶：silent/A10；原来源任务{p["source_task"]} → 实现任务strategy-proposal。账本：{"、".join(p["ledger"])}。\n\n证据局/层/回合：{where}。\n\n已核实：{evidence}\n\n反例与未知：{counter}\n\n旧规则/本次行为：保留当前行为，无新代码；预期后续行为：{expected}\n\n处置：waiting。{reason}\n\n拟合、样本与验证：本批六个独立历史A10局，SL不扩分母；只核已观察事实，不拟合新常量；这些帧已用于发现，不称盲测。{validation}\n\n预期影响仅为让事实和已执行范围可核，不承诺整战转胜。当前无需源码回退；后续实现单独提交、自测和live核实，回退其独立源码提交并保留本材料。\n\n原Markdown：{p["proposal"]}\n\n原SHA256：{p["proposal_sha256"]}（本批副本{items.index(p)+1:02d}-original-proposal.md，逐字节相符）。\n')
proposal.append('## 共同边界\n\nRoy-2026-10-07-learning提供修改权限，不提供游戏事实。本批没有新机制反证或与旧知识冲突；同盘血价、未建立能力和既有数值均保留原限制。未发现足以据实新增规则的差异。现有局部实现不代表宽项完整交付；不冒认implemented/duplicate、shipped、自然采用或策略收益。code_proposals引用十个已有CLI id，implementation_domains=[]表示本批无新实现。\n')
(s/'proposal.md').write_text('\n'.join(proposal))
base=source['base'];report_path=str(s/'report.md')
report={'task':'strategy-proposal','character':'silent','batch':'20261015-084303-strategy-proposal','base':base,'runs':dispatch['runs'],'fixes':[],'skipped':[],'merged':None,'tests':{'tsc':None,'vitest':None,'cases':None},'code_proposals':[p['id'] for p in items],'implementation_domains':[],'proposal_results':results,'report':report_path}
(s/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=[f'# 静默策略学习本批报告\n\n记录时间：{stamp}。batch=20261015-084303-strategy-proposal。\n\n本批十项原提案均waiting。已独立核六局原始字节、固定事实与离线消费者；没有足够新证据支持新预算、血价/SL阈值、统一启动权重或固定杀序。既有神化及审计局部实现不冒充整项完成。无源码/知识改动、无提交、无live合入、无新版本或shipped。\n',
 f'## 派发与基线\n\n开工git status干净；HEAD={base}。已读README、最新STATE-2026-10-15、decision-log末尾、learning-protocol及learning-code-proposals。只读根learn.json本批行，task/character/worktree/runs及十proposal_ids相符，reason=proposal，无proposal_repair/research_request/implementation_request。普通专题请求绑定20261010旧batch，不承接、不读取另专题替代。按普通流程git merge --no-edit main，结果Already up to date，base保持{base}。未派下级agent。\n\n六个runs原行均SILENT/A10，运行code均有dirty标记，不凭Git提交还原当时完整源码/知识。brain流183条均engine=codex、model=gpt-6.1-sol；runs.deepseek_calls/ds_*兼容名称不当实际DeepSeek作答证据。未修改当前原生会话/模型配置，未宣称模型已切换。\n',
 '## 原始证据\n\n共用learner/extract_evidence.py抽八流，每流先冻结source_size；全部所属行重新seek原日志，逐行核offset/bytes/SHA256/JSON正文及显式身份，无冲突或正文冒认。evidence-verification.json保存实际6995条核验结果，evidence/evidence-manifest.json保存每流逐局计数和输出SHA。\n\n| 流 | source_size字节 | 核验所属行 |\n|---|---:|---:|']
for c in verification['streams']:lines.append(f'| {c["stream"]} | {c["source_size"]} | {c["verified"]} |')
lines.append(f'\n固定事实断言{facts["count"]}项全部通过，详fact-checks.json、fact-checks.log。它们是材料核验，不是生产源码测试或撤码红绿。states/decisions全源各有2条无效JSON，brain全源1条；不据此断言属于本六局。fight-plans该截点选中0行，仅表示此截点未选到，不说原日志缺失。没有覆盖或重写旧零行稿/截点报告。\n\nselected-state-facts.json保留关键状态投影；selected-decisions.json保留关键原题/原答/SL/预算。原提案十份均按保存SHA复制复核。只读本角色knowledge/characters/silent的关联经验，不读其他角色私有知识，不用预训练事实补规则。\n')
lines.append('## 离线消费者实际读回\n\n用本基线learner/lib/selection-execution.ts，固定单局输入经node+tsx离线调用；不调LLM、网络、游戏或刷新知识。输入和完整输出按局保存*.json.gz，consumer-readback.log及consumer-summary.json保实际结果。\n\n| 局 | 完整输入接受 | 有ID动作 | 候选片段 | 相邻动作端点 | 终页端点 | 整轮端点 | 未知轮 |\n|---|---|---:|---:|---:|---:|---:|---:|')
for c in consumer:lines.append(f'| {c["run"]} | {"是" if c["full_input_accepted"] else "否，仅有界子集"} | {c["actions"]} | {c["segments"]} | {c["observed_action_endpoints"]} | {c["terminal_endpoints"]} | {c["observed_turn_endpoints"]} | {c["unknown_turns"]} |')
lines.append('\nCA5原d267143、61E原d267517、DUZU原d268789/268818/268864为没有decision_id的map/route-change行；完整输入真实拒收，原拒收JSON保留。之后只去掉这5行做有界子集，不补ID、不重编号，原行仍在抽取与完整输入内。三个子集结果不是完整输入通过。\n\n总计3301有ID动作、476片段、859相邻动作端点、4终页、121整轮端点、413未知轮。所有完整候选归属仍为null，这是消费者认证边界，不能当作没有执行或零收益。8JRE F33首/第三试T2实际整轮分别损3/15、敌扣10/17，确认多12血价换7净扣；两题指纹相同、0/24与5/24不等死率。第二试T5护栏候选差额不自动成为实际保血收益；末试T11整轮玩家-5/敌-36，死前当前5血22挡对37，截断5不当完整需损15。没有未选整场胜线。\n')
lines.append(f'## 现有源码的限定核实\n\n只读live快照{source["live_head"]}。核11个相关叶，10个逐字节相同；card-model.ts仅两处Roy/Dai历史注释不同，原diff保存在base-live-card-model.patch，未改动。该窄比对不代表main/live整树等价，也不代表运行dirty树已复原。source-readback.json保存每叶实际SHA256及源码祖先验证。\n\n已核真实live祖先：\n')
for c in source['commits']:lines.append(f'- {c["commit"]}：{c["subject"]}。')
lines.append('\n神化已涵盖本局已观察牌对、手牌/后续牌堆传播；当前actual_cast_this_fight=null，属性组合未知边界保留。选择快照、护栏/SL候选差与单动作派发回执均已有；它们不认证完整候选。cf72bd21148059f111f760cc98a727369e34a47e等既有离线审计消费者只用于本次读回，不充作本批新增提交或闭合整个在线持续身份要求。无新源码缺口被本批固定证据独立证明到足以新增规则或关闭宽项。\n')
lines.append('## 十项结果\n\n各项原账本、证据局/层/回合、反例、旧/预期行为、拟合/验证和回退完整列于同目录proposal.md。以下十id与派发集合完全相同，均保留待新证据重派。\n\n| 原id | 处置 | 具体未实现原因 |\n|---|---|---|')
for r in results:lines.append(f'| {r["id"]} | waiting | {r["reason"]} |')
lines.append('\n## 记录、验证与限制\n\n只经根learner/ledger.py update为相关26个静默条目追加by=learner:strategy-proposal的本批proposal/report追溯链接，不改claim、evidence、first_run、prior、asc、status或version，不降已shipped历史；不重复登记既有support/repeat、不建新提案id。CLI输入、输出和最终读回保存在本批目录，专用队列由proposal_results交原调度器消费，不手改learn.json或队列。\n\n没有新源码，撤源码失败/恢复通过不适用，未跑tsc/vitest，tests三项均null；不把材料55断言或离线消费者通过冒作生产测试。没有源码提交，不需要合入或上线版本，merged=null。未运行play、不联网、不推送、不读密钥/.env/二进制，不改运维prompt或其他角色行为；没有规则变化通知或新shipped。\n\n全部六局是已有历史发现样本，不是时间后置验证。未观察升级、持续身份、召唤复现、伤害唤醒/眩晕及未选整战后继保持未知；同局SL不扩独立分母，选择文本和端点不能冒认证因果收益。原提案/经验未被新反证推翻，本批没有新的必要反证通知，不以报告完成关闭学习父要求或宣称经验已入库/大脑已采用。\n\n只读定位时几条猜测的源码路径不存在（core/loop、hand/screens/types、rollout-enemy*等），已改用rg --files定位实际路径；未生成生产修改。base/live的git diff --no-index退出1只是已知注释差异，不是测试失败。消费者三份完整输入拒收是原身份限制，原件保留，没有放宽验证。\n\n最终检查与账本追加读回、密钥扫描结果见closure.json及ledger-readback.json；未提交、不借用历史测试绿。\n')
lines.append(f'\n交运维：proposal={s/"proposal.md"}；report={s/"report.md"}。最终结构化回报在report.json。\n')
(s/'report.md').write_text('\n'.join(lines))
ledger=json.load(open(s/'ledger-before.json'));updates=[]
for ident in ledger:
 links=[p['id'] for p in items if ident in p['ledger']]
 updates.append({'id':ident,'by':'learner:strategy-proposal','where':{'proposal':[str(s/'proposal.md'),str(s/'report.md')]},'note':f'20261015-084303-strategy-proposal：本角色六局八流6995原行字节/身份核验，55材料断言与离线消费者读回；相关原提案{"、".join(links)}仍waiting，缺项详本批报告。无源码/知识/阈值变更，不宣称完整候选归属、implemented或shipped；保留原claim、证据、首证、先验、进阶、status和version。'})
(s/'ledger-updates.jsonl').write_text(''.join(json.dumps(u,ensure_ascii=False)+'\n' for u in updates))
print(json.dumps({'report':report_path,'proposal':str(s/'proposal.md'),'assigned':len(results),'ledger_trace_updates':len(updates),'fact_checks':facts['count']},ensure_ascii=False))

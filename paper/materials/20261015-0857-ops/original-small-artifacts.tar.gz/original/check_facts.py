import json
from pathlib import Path
s=Path(__file__).resolve().parent
states={x['line']:x for x in json.load(open(s/'selected-state-facts.json'))}
decisions={x['_line']:x for x in json.load(open(s/'selected-decisions.json'))}
checks=[]
def eq(name,actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'name':name,'actual':actual,'expected':expected})
def h(line,id):return next(c for c in states[line]['hand'] if c['id']==id)
def enemy(line,id):return next(c for c in states[line]['enemies'] if c['id']==id)
def threat(line):return sum(i.get('total_damage') or 0 for e in states[line]['enemies'] for i in e.get('intents',[]))
for line,after in [(275564,275565),(275679,275680)]:
 eq(f'{line}神化支付能量',[states[line]['player']['energy'],states[after]['player']['energy']],[7,5])
 eq(f'{line}场外升级计数不变',states[line]['deck_upgrades'],states[after]['deck_upgrades'])
for id,field,before,after in [('DEFEND_SILENT','Block',5,8),('STRIKE_SILENT','Damage',7,10),('DAGGER_SPRAY','Damage',5,7)]:
 eq(f'F35神化{id}',[h(275564,id)['values'][field][1],h(275565,id)['values'][field][1]],[before,after])
eq('F35必备工具费用',[h(275564,'TOOLS_OF_THE_TRADE')['cost'],h(275565,'TOOLS_OF_THE_TRADE')['cost']],[1,0])
for id,field,before,after in [('SUCKER_PUNCH','Damage',9,11),('SUCKER_PUNCH','WeakPower',1,2),('FASTEN','ExtraBlock',4,6),('PIERCING_WAIL','StrengthLoss',6,8)]:
 eq(f'F43神化{id}/{field}',[h(275679,id)['values'][field][1],h(275680,id)['values'][field][1]],[before,after])
eq('F43后轮实血',states[275687]['player']['hp'],77)
eq('F43敌本体净扣',enemy(275679,'SOUL_NEXUS')['hp']-enemy(275687,'SOUL_NEXUS')['hp'],51)
eq('F43后来毒雾升级',h(275687,'NOXIOUS_FUMES')['upgraded'],True)
eq('F45当前MC时间',decisions[269748]['timing']['mc_ms'],707)
p0=decisions[269748]['criteria']['p0'];p0=json.loads(p0) if isinstance(p0,str) else p0
eq('F45随机药只一实际模型样本','Monte Carlo, 1 sample' in p0['simulated'],True)
eq('8JRE同盘指纹',decisions[270216]['fingerprint'],decisions[270282]['fingerprint'])
nums=decisions[270282]['sl_explore']['numbers']
eq('SL原线死亡样本','dead 0/24' in nums['original'],True)
eq('SL替线死亡样本','dead 5/24' in nums['replacement'],True)
turns=json.load(open(s/'selected-consumer-turns.json'))
def turn(attempt,t):return next(x for x in turns if x['attempt']==attempt and x['turn']==t)
for a,hp,dmg in [(1,-3,-10),(3,-15,-17)]:
 t=turn(a,2);eq(f'8JRE第{a}试T2整轮HP',t['facts']['player_hp_delta'],hp);eq(f'8JRE第{a}试T2敌本体',t['facts']['enemy_hp_changes'][0]['hp_delta'],dmg)
 eq(f'8JRE第{a}试候选完整归属',t['facts']['actual_full_candidate_result'],None)
for line,strength,attack in [(273252,4,15),(273263,8,19)]:
 eq(f'蚌{line}力量',enemy(line,'SEWER_CLAM')['powers']['STRENGTH_POWER'],strength)
 eq(f'蚌{line}喷水',threat(line),attack)
eq('蚌T5施弱后攻击',threat(273268),14)
eq('蚌T5当前血挡',[states[273268]['player']['hp'],states[273268]['player']['block']],[2,10])
eq('蚌终态剩余本体',enemy(273269,'SEWER_CLAM')['hp'],16)
eq('无毒冒泡能量',[states[274379]['player']['energy'],states[274380]['player']['energy']],[5,4])
eq('无毒冒泡玩家血',[states[274379]['player']['hp'],states[274380]['player']['hp']],[29,29])
for id,hp in [('THE_LOST',35),('THE_FORGOTTEN',72)]:
 eq(id+'冒泡前后血',[enemy(274379,id)['hp'],enemy(274380,id)['hp']],[hp,hp])
 eq(id+'冒泡前后毒',[enemy(274379,id)['powers'].get('POISON_POWER'),enemy(274380,id)['powers'].get('POISON_POWER')],[None,None])
eq('族母负敏捷',states[273504]['player']['powers']['DEXTERITY_POWER'],-2)
eq('族母双防御各3',[states[x]['player']['block'] for x in [273504,273505,273507]],[0,3,6])
eq('族母毒结算端点',[enemy(x,'LAGAVULIN_MATRIARCH')['hp'] for x in [273504,273508]],[67,34])
eq('族母临时力量恢复',[enemy(x,'LAGAVULIN_MATRIARCH')['powers']['STRENGTH_POWER'] for x in [273504,273506,273508]],[2,-4,2])
eq('胧光T4玩家血价',[states[x]['player']['hp'] for x in [273593,273596]],[25,10])
eq('胧光T4幻象未退场',enemy(273596,'PARAFRIGHT')['hp'],2)
eq('胧光T4后各体成长',[e['powers']['STRENGTH_POWER'] for e in states[273596]['enemies']],[6,6])
eq('甲虫自然睡层',[enemy(x,'SLUMBERING_BEETLE')['powers']['SLUMBER_POWER'] for x in [274906,274914,274919]],[3,2,1])
eq('甲虫临时减力后恢复成长',[enemy(x,'SLUMBERING_BEETLE')['powers']['STRENGTH_POWER'] for x in [275017,275018]],[-4,4])
eq('甲虫次轮攻击',threat(275018),22)
eq('甲虫末轮当前血挡',[states[275022]['player']['hp'],states[275022]['player']['block']],[1,16])
eq('三骑士本轮总威胁',[threat(x) for x in [275749,275753]],[83,59])
eq('三骑士末轮当前血挡',[states[275754]['player']['hp'],states[275754]['player']['block']],[32,20])
eq('三骑士终态三个仍有血',[e['hp'] for e in states[275755]['enemies']],[21,80,77])
summary=json.load(open(s/'consumer-summary.json'))
eq('消费者完整身份缺失行总数',sum(len(x['rejection']['missing_decision_ids']) if x['rejection'] else 0 for x in summary),5)
eq('消费者不认证完整候选',sum(x['certified_full_candidate_results'] for x in summary),0)
(s/'fact-checks.json').write_text(json.dumps({'count':len(checks),'checks':checks,'scope':'固定证据材料核验；不是生产源码测试'},ensure_ascii=False,indent=2)+'\n')
print('固定证据材料断言通过',len(checks))

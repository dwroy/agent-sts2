import datetime
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'assigned-proposals.json').read_text())
sources = json.loads((OUT / 'source-audit.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
consumers = json.loads((OUT / 'consumer-summary.json').read_text())

details = {
    'ac022f51b42a960f': ('PF90JTU0UZ5M F19/20/21/22；未到F23/27/29/32',
        '三胜65→47→21→3；F21含一次SL恢复，不能重复计血药。',
        '现有路线绝对来源投影、当前HP/药栏和离线资源链已有；缺已发生问号战/逐槽药水/恢复来源与路线休息题面的完整联合读回，未找到新的可隔离数值失配。未到恢复点不计实回，不据本四局拟安全血线。'),
    'f10961933e0f7f14': ('PF90JTU0UZ5M F22第3/4试T1—T3；SY0WMJNNVRLM F21第2/3试T4',
        'PF原防御线损0/扣26，锚线损2/扣31；SY同9血、39/23敌HP各5毒，两试后继不同。',
        '已有重放/探索即时资源比较与离线动作关联；仍缺锚线连续执行认证、固定后继与未截断入伤。不能从PF多损2或SY最终胜一试推统一杀序/重放禁令，保留原准入。'),
    '91afbdb3459a627b': ('2H311EAD34GD F8T1/T5；F17T7/T11/T12',
        'F8四体到T3才首退，胜55→4；末T12力−4/敏−1，两防御8对25攻、11血实死，敌余79。',
        '题面已有逐敌HP/挡/意图、当前净属性和分列的deck/want；离线多同类敌实体不作稳定跨帧归属。缺退场进度与计划组件实际兑现的完整消费者验收，未证固定集火/选牌/求毒策略收益，不将局部事实通道当整项完成。'),
    'ce28c6de450fda0b': ('2H311EAD34GD F17第4/5试T4、末试T10',
        '同52血/3能/3敏/6覆甲：实际损1/9、扣25/31；五轮0/24死与整场0/1200胜分列。',
        '现有selection_audit、hp_guard、SL候选比较与本次离线关联已保留阶段；完整候选结果仍null。缺可归属完整执行和受控后继，无法把护栏中间替换或B2零胜并列校准为整战因果，不改护栏/SL规则。'),
    '14f13ef0487858d7': ('2H311EAD34GD F17六次饮用、T4/T5/T10',
        '六次饮用均覆甲+7、旧挡不变；同盘T4剩6层并实损1，后轮用剩层，末轮无覆甲。',
        '提案要求的模型核验已存在：modelPotion建立7覆甲且即时block为0，combat-plan从现场PLATING_POWER读取endTurnBlock，后轮重读现场值。六饮原帧及同盘局部模型核验通过。原提案明确不要求拟新喝药时点；同瓶六次SL非六独立样本，完整减层机制与早晚喝整战收益仍未知。'),
    '81e3b8bf97493a4a': ('WZL2AMEY85S7 F17第1/3试T4',
        '同20血/敌216/4力/7毒：损13/18、整轮扣28/34；25/31模型伤另有3荆棘。',
        '即时血价和SL候选审计已存在；本次原帧与局部模型可重现交换，缺完整原线受控后继和逐源完整候选认证。B2零胜不能证明同等安全，也不足拟新的探索血线。'),
    'c9eebe66516045f0': ('WZL2AMEY85S7 F17末试T5/T6/T8',
        'T6毒11使166→155跨现场160并取消攻击；T8生存者8挡后余2能锁牌，需损9、8血归零，敌109。',
        '昏眩单牌上限、阈值取消与毒/荆棘局部模型均可核；本次只验证所选生存者及已见端点，未认证全部合法首张的题面预算和完整结算来源。未抽究极防御不算可用，缺首张替换/提前抽牌受控后继，保留原评分。'),
    'fcdf526c2ff89a96': ('2H311EAD34GD F8、F17T4/T7/T11/T12；WZL2AMEY85S7 F17T4/T6/T8；SY0WMJNNVRLM F14T1',
        '净力敏、现场覆甲、毒跨阈值、反伤和昏眩分别成立；局部已正确不代表联合策略收益。',
        '覆甲窄模型已有且14f已单列duplicate；联合多入口/多轮校准、完整减层条件及完整候选分源归属仍缺。当前胆小经验已限定不把每次攻击当必补盾，不采用旧宽语作新规则；未重核A5HK原局，不新增反证或支持样本。原宽项不关闭。'),
    'ef192c07f518e37d': ('2H311EAD34GD F7/9/12/16与F8/F17；WZL2AMEY85S7 F4/F13、四火及F17',
        '两局各四火实回84，前七胜净耗82/91、事件耗6/9后52/40进Boss；未有替路线整战对照。',
        '已有当前牌组/药栏/HP与离线净资源链；缺随机升级具体牌验收、问号战计数及路线/休息消费者的完整关联。随机强化不当核心已升级，未发现新独立源码差额，不据六败改路线或回血规则。'),
    'a3ac35773142c17f': ('2H311EAD34GD F17第4/5试T4；WZL2AMEY85S7 F17第1/3试T4、末试T6/T8',
        '两组少挡换伤分别多6伤/多损8和多6伤/多损5；两场各六败，但后续抽牌和动作不同。',
        '已有原答/护栏/SL即时资源审计，本批重算同盘局部交换；缺保持未来牌序/动作的整战配对或新增完整胜次，不能据两组端点拟统一禁止探索/新排序，整项waiting。'),
}
results = []
for p in proposals:
    suffix = p['id'].removeprefix('silent-proposal-')
    evidence, counterexample, reason = details[suffix]
    result = {'id': p['id'], 'state': 'duplicate' if suffix == '14f13ef0487858d7' else 'waiting',
              'reason': reason}
    if result['state'] == 'duplicate':
        result['commit'] = '66283dd9982bdd7f480da7a4d9bfefea0572a9ac'
    results.append(result)
(OUT / 'proposal-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')

proposal_text = f'''# 本批静默策略提案核对

记录时间：{stamp}（写入前执行date）。batch={dispatch.get('batch', '20261017-044302-strategy-proposal')}；基线 `{BASE}`。

只处理本批派发的十个原CLI ID，不新增或领取其他ID。九项waiting、一项duplicate；不修改源码、知识或玩法参数。原Markdown均核原队列SHA并按原字节保存为`<id>.original.md`，身份见dispatch.json，原登记见assigned-proposals.json。

适用范围仅本批四个SILENT A10局。SL是同局重试，不增加独立样本；本批发现/确定性核验不作时间留出。未来新增本角色完整对局、保持同盘同后继的配对数据才用于策略效果验证。实际模型/策略来源不以本次授权或预训练事实替代。

'''
for p, result in zip(proposals, results):
    evidence, counterexample, reason = details[p['id'].removeprefix('silent-proposal-')]
    proposal_text += f'''## {p['id']}：{p['summary']}

- 处置：{result['state']}。{('实际live祖先源码commit：`' + result['commit'] + '`。') if result.get('commit') else ''}
- 来源任务：{p['source_task']}；实现任务：strategy-proposal；原领域：{','.join(p['domains'])}。
- 原证据局：{','.join(p['runs'])}；层/回合：{evidence}。
- 原学习账本：{','.join(p['ledger'])}；原提案SHA256：`{p['proposal_sha256']}`。
- 支持、反例与限制：{counterexample}
- 旧行为/现有实现与本次结论：{reason}
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

'''
(OUT / 'proposal.md').write_text(proposal_text)

stream_table = '\n'.join(f"| {m['stream']} | {m['source_size']} | {sum(m['counts'].values())} |" for m in manifest)
consumer_table = '\n'.join(f"| {c['run']} | {c['segments']} | {c['actions']} | {c['turn_endpoints']} | {c['unknown_turn_windows']} | 0 |" for c in consumers)
result_table = '\n'.join(f"| {r['id']} | {r['state']} | {r['reason']} |" for r in results)
source_table = '\n'.join(f"| {c['commit']} | {c['base_ancestor']} / {c['live_ancestor']} |" for c in sources['commits'])
report = f'''# 静默策略队列本批报告

记录时间：{stamp}（写入前执行date）。task=strategy-proposal，character=silent，batch=20261017-044302-strategy-proposal。

十个派发提案已逐项处置：铁心剩层模型14f为duplicate，实际live祖先源码`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`；其余九项因具体缺数据waiting。没有源码/知识修改、新提交、合入或新版本；fixes=[]、merged=null。

完整base/HEAD：`{BASE}`。开工工作树干净，身份核实后普通流程`git merge --no-edit main`返回Already up to date。之后main并行前进未二次合入，也未覆盖并行记录。

## 身份与证据边界

已读README、AGENTS、最新STATE-2026-10-16、decision-log末尾、learning-protocol、learning-code-proposals与learning-requests。根learn.json只读本批对应行：task/character/worktree、四个runs、十个proposal_ids核对一致，reason=proposal；无proposal_repair、research_request或implementation_request。普通专题文件仍绑定另一旧批，不适用本批；不读取其他专题来替代身份，不改根请求/learn.json/调度状态。未派下级agent。

四局runs.jsonl均为SILENT/A10：PF90JTU0UZ5M F22败、2H311EAD34GD F17败、WZL2AMEY85S7 F17败、SY0WMJNNVRLM F33败。原run-config完整源码提交及dirty列表保存在各局metadata.json；当时dirty知识原字节未复原，当前源码不充作旧运行完整输入。兼容字段deepseek_calls不当引擎证明。本会话实际原生模型/强度/服务档未独立核实，不以历史对局配置冒充。

共用extract_evidence.py以nice10提取八流，保存每流source_size、逐行offset/bytes/SHA和计数。4482条封套全部seek回原日志重核SHA、JSON、截点与显式局身份，run-plans.run、run_id、state.run_id、fingerprint.run按共用函数处理，冲突身份拒收。原日志只读，各流边界分别记录，不称同一墙钟快照。

| 流 | source_size | 本批核验行数 |
|---|---:|---:|
{stream_table}

fight-plans在该截点选到0行，仅说明此次未选到，不断言日志不存在。三流各2条非法源行无法归属，不当本批游戏结论；没有覆盖旧报告或零行初稿，也没有将增长截点当新增独立样本。

## 支持、反例与当前模型

- PF二幕三胜65→47→21→3，F21含SL恢复；未来店/火未抵达。SY F21T4两试同9HP、3能、两敌39/23且各5毒，原s301449/s301472核实；目标、弱化和后继共同改变，不推单一固定杀序。
- 2H F17六次铁心饮用当步均覆甲+7、原挡不变。同52HP/3能/3敏/6覆甲的第4/5试T4，原防御线损1/扣25，SL撤防御损9/扣31。当前局部原语重放相同数值，五轮0/24死亡和B2整战0/1200胜不是同一时间范围。
- WZ F17同T4原线损13/整轮扣28，SL线损18/扣34；模型25/31另有独立荆棘3。T6敌166、毒11跨现场160至155并取消攻击，玩家8HP保持；T8生存者8挡后余2能仍锁牌，完整需损9、当前8HP仅实扣至0，毒21与荆棘3使敌133→109。未抽究极防御不记可用。
- 2H末T12当前力−4/敏−1，打击2、两防御8，25攻需损17，模型hpAfter=-6与实盘11→0的截断分开。两局各四火回84、前七胜净耗82/91，事件另账后52/40进Boss，不能由六败归因回血/避精英错误。

固定输入33原帧、23个局部原语/材料断言与13个资源材料断言已核，不读刷新知识、不运行LLM/网络/长程模拟。该核验用原始动态值和手工连接的现有单轮原语，不冒充完整生产planner消费者或新回归测试。初版r1误把族母防御线的一张匕首雨写成打击，导致23对25；核原d297715后更正实际序列。r2误把enemyHpAfter当作已含独立retaliated的实盘终态，191对188；按已有字段分账后r3通过。两次失败日志和脚本原字节保留，均为本批审计输入/契约错误，不是产品缺陷，也不是撤源码失败/恢复通过。

现库胆小经验已明确限定“不把每次攻击都当必补盾”，现有skittish代码也有已消费触发观测；不把旧提案较宽措辞写成新规则。本批没有重核该后续A5HK局、不新增此机制结论或反证，不重复旧通知/代填ACK。

## 离线消费者与缺口

四局固定输入调用现有learner/audit-selection.ts均实际exit0；输入/输出、stderr、退出码和原始SHA保留。PF原d296851与WZ原d298015为无decision_id路线元数据，单独保存排除原因，不补造ID；2106条有ID动作进入消费者。resource_chain函数仅消费同一冻结states及SL起点，不再次扫描或更改原日志。

| 局号 | 候选段 | 有ID动作 | 已核回合端点 | 未知回合窗 | 完整候选认证 |
|---|---:|---:|---:|---:|---:|
{consumer_table}

共437候选段，384回合窗中164已核端点、220未知。actual_full_candidate_result为工具契约null；0认证不能倒推出候选实际未执行。接口回执、相邻观测、整轮端点、预测和完整候选归属分别保留。未执行线/固定后继/路线休息替选反事实及原dirty联合校准仍未知，因此不拟血线、药水持有价或SL排序。

## 已有live源码

只读观察live提交`{sources['live_observed']}`，不是本批merged。23个相关源码叶中17个同字节，6个只差历史Roy/Dai注释；两边归一后23个均同，实际live工作文件也逐叶同该live提交。source-live-diff.patch保存完整binary diff，source-audit.json保存SHA及祖先检查；有限叶一致不代表全运行输入等价。

| 已有源码commit | base/live祖先 |
|---|---|
{source_table}

card-model中的HEART_OF_IRON=plating7、combat-plan现场PLATING_POWER→endTurnBlock及单牌上限接线已在66283中直接读回。14f只结案其原文要求的局部剩层模型核验，不声称喝药时点或完整减层机制已验证；fcdf联合宽项仍waiting。已有selection_audit/hp_guard/SL资源比较只记候选预测，actual_turn仍null；不重复开发窄实现，也不把源码祖先自动当收益或经验shipped。

## 逐项结果

原证据局号/层/回合、账本id、反例、旧/新行为、预期和验证/回退逐项见proposal.md与十份原Markdown。

| 原CLI id | 处置 | 理由 |
|---|---|---|
{result_table}

## 记录与交付

仅经根learner/ledger.py update追加19个既有本角色账本的where.proposal与note，实际执行与逐行读回见ledger-receipt.json。原claim、首证/prior、evidence、status、version、effect和旧history/notes/where前缀保持；不重复support/repeat，不把已有shipped倒退为proposed。没有新增游戏知识、代码提案ID或经验条目，本批code_proposals沿用十原CLI ID；不改队列原行或自标shipped。

无源码提交，撤源码失败/恢复通过不适用，tsc/vitest/cases均null；上列材料核验与离线exit0不是生产测试。未执行提交前gitleaks/完整测试或live合入，没有eval版本/decision-log上线记录或规则双通知。不运行play/游戏API，不改运维prompt、账号或模型配置，不推送。九waiting沿原队列等具体新证据，不关闭任何学习入库/量化父要求。

提案：{OUT / 'proposal.md'}

报告：{OUT / 'report.md'}；机器回报：{OUT / 'result.json'}。最终工作树/HEAD/原账本字段验收与产物SHA见final-verification.json、artifact-manifest.json；本批运行中不删除或回收自身工作树。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-044302-strategy-proposal',
          'base': BASE, 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'report.md'), 'states': [r['state'] for r in results]}, ensure_ascii=False))

import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('extract_evidence', ROOT / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
data = {run: collections.defaultdict(list) for run in dispatch['runs']}
verified = []
for stream in manifest:
    name = stream['stream']
    counts = collections.Counter()
    output = OUT / 'evidence' / (name + '.evidence.jsonl')
    digest = hashlib.sha256()
    with output.open('rb') as frozen, (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
        for encoded in frozen:
            digest.update(encoded)
            envelope = json.loads(encoded)
            assert envelope['offset'] + envelope['bytes'] <= stream['source_size']
            source.seek(envelope['offset'])
            raw = source.read(envelope['bytes'])
            assert hashlib.sha256(raw).hexdigest() == envelope['sha256']
            row = json.loads(raw)
            assert row == envelope['row']
            run = extractor.run_identity(row)
            assert run == envelope['run_id'] and run in data
            counts[run] += 1
            row['_line'] = envelope['line']
            row['_source_sha256'] = envelope['sha256']
            data[run][name].append(row)
    assert digest.hexdigest() == stream['output_sha256']
    assert {run: counts[run] for run in data} == stream['counts']
    verified.append({'stream': name, 'source_size': stream['source_size'],
                     'verified': sum(counts.values()), 'sha256': digest.hexdigest()})
inputs = []
for run, streams in data.items():
    assert len(streams['runs']) == 1
    record = streams['runs'][0]
    assert record['character'] == 'SILENT' and record['ascension'] == 10
    decisions, excluded = [], []
    for row in streams['decisions']:
        if row.get('decision_id'):
            decisions.append(row)
        else:
            excluded.append({'line': row['_line'], 'label': row.get('label'),
                             'reason': '原元数据无decision_id，不补造动作身份'})
    path = OUT / (run + '.consumer-input.json')
    path.write_text(json.dumps({'run': record, 'states': streams['states'], 'decisions': decisions}, ensure_ascii=False) + '\n')
    inputs.append({'run': run, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                   'states': len(streams['states']), 'decisions': len(decisions), 'exclusions': excluded})
    # Preserve run plans and startup inputs for bounded source attribution, not as this session's model identity.
    (OUT / (run + '.metadata.json')).write_text(json.dumps({
        name: streams[name] for name in ('runs', 'run-config', 'run-plans', 'sl-attempts')
    }, ensure_ascii=False, indent=2) + '\n')
(OUT / 'evidence-verification.json').write_text(json.dumps({'streams': verified, 'total': sum(x['verified'] for x in verified),
    'inputs': inputs}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified': sum(x['verified'] for x in verified),
    'inputs': [{k: v for k, v in x.items() if k not in ('path', 'sha256')} for x in inputs]}, ensure_ascii=False))

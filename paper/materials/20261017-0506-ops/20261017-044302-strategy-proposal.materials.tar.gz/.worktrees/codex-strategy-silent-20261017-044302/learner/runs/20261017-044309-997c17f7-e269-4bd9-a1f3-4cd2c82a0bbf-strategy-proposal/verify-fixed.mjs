import fs from 'node:fs';
import assert from 'node:assert/strict';
import { syncBuiltinESMExports } from 'node:module';
import { fileURLToPath } from 'node:url';

const directory = fileURLToPath(new URL('.', import.meta.url));
const root = fileURLToPath(new URL('../../../', import.meta.url));
const frames = JSON.parse(fs.readFileSync(`${directory}fixed-frames.json`, 'utf8'));
const read = fs.readFileSync;
const deniedKnowledgeReads = [];
fs.readFileSync = function (path, ...args) {
  const name = path instanceof URL ? fileURLToPath(path) : String(path);
  if (name.startsWith(`${root}knowledge/`)) {
    deniedKnowledgeReads.push(name);
    throw new Error('固定核验禁止读取刷新知识');
  }
  return read.call(this, path, ...args);
};
syncBuiltinESMExports();
const { modelHandCard, modelPotion } = await import('../../../agent/src/reflex/card-model.ts');
const { replaySteps } = await import('../../../agent/src/reflex/turn-solver.ts');
const knowledge = { card: () => null, cards: () => [], relic: () => null, relics: () => [],
  potion: () => null, power: () => null, monster: () => null, event: () => null };
const state = (line) => frames[String(line)].row.state;
const power = (entity, id) => entity.powers.find((p) => p.power_id === id)?.amount ?? 0;
const checks = [];
function equal(label, actual, expected) {
  assert.deepEqual(actual, expected, label);
  checks.push({ label, actual, expected });
}

// This isolates existing one-turn primitives. It does not certify the live planner or an entire candidate.
function inputOf(line) {
  const raw = state(line), combat = raw.combat, p = combat.player;
  return { hand: combat.hand.map((c, i) => modelHandCard(c, i, knowledge, 'silent', 10)),
    player: { hp: p.current_hp, maxHp: p.max_hp, block: p.block, energy: p.energy,
      dexterityNow: power(p, 'DEXTERITY_POWER'), weak: power(p, 'WEAK_POWER') > 0,
      vulnerable: power(p, 'VULNERABLE_POWER') > 0, frail: power(p, 'FRAIL_POWER') > 0,
      intangible: false, endTurnBlock: power(p, 'PLATING_POWER'), retaliate: power(p, 'THORNS_POWER'),
      maxPlays: power(p, 'RINGING_POWER') === 1 ? Math.max(0, 1 - p.cards_played_this_turn) : null },
    enemies: combat.enemies.map((e) => ({ index: e.index, name: e.name, hp: e.current_hp,
      maxHp: e.max_hp, block: e.block, vulnerable: power(e, 'VULNERABLE_POWER'),
      weak: power(e, 'WEAK_POWER'), poison: power(e, 'POISON_POWER'),
      shriek: power(e, 'PLOW_POWER'), artifact: power(e, 'ARTIFACT_POWER'),
      attacks: e.intents.filter((i) => typeof i.damage === 'number').map((i) => ({ damage: i.damage, hits: i.hits ?? 1 })) })),
    fightKind: 'boss', turn: raw.turn };
}
function replay(line, indices) {
  const input = inputOf(line);
  const plan = replaySteps(input, indices.map((index) => {
    const c = input.hand.find((card) => card.index === index);
    assert(c);
    return { cardIndex: c.index, cardId: c.cardId, name: c.name, upgraded: c.upgraded,
      target: c.target === 'single' ? 0 : null };
  }));
  assert(plan);
  return plan;
}

for (const [before, after] of [[304955,304956],[305026,305027],[305099,305100],
  [305166,305167],[305240,305241],[305304,305305]]) {
  const a = state(before).combat.player, b = state(after).combat.player;
  equal(`s${before}→${after}覆甲增加且原挡不变`,
    [power(b,'PLATING_POWER')-power(a,'PLATING_POWER'),b.block-a.block,b.current_hp-a.current_hp],[7,0,0]);
}
equal('既有铁心模型建立覆甲而非即时牌挡',
  [modelPotion('HEART_OF_IRON','铁心',0,[]).plating,modelPotion('HEART_OF_IRON','铁心',0,[]).block],[7,0]);
equal('2H第4/5试T4完整手牌相同',state(305168).combat.hand,state(305242).combat.hand);
equal('2H第4/5试T4同入口资源',
  [305168,305242].map((n)=>[state(n).combat.player.current_hp,state(n).combat.player.energy,
    power(state(n).combat.player,'DEXTERITY_POWER'),power(state(n).combat.player,'PLATING_POWER'),state(n).combat.enemies[0].current_hp]),
  [[52,3,3,6,216],[52,3,3,6,216]]);
equal('2H两条实盘端点血价/扣血',
  [52-state(305175).combat.player.current_hp,52-state(305249).combat.player.current_hp,
    216-state(305175).combat.enemies[0].current_hp,216-state(305249).combat.enemies[0].current_hp],[1,9,25,31]);
for (const [line, indices, hpLoss, damage] of [[305168,[0,1,2,3,5,6],1,25],[305242,[0,2,3,4,5,6],9,31]]) {
  const plan = replay(line,indices);
  equal(`s${line}当前局部模型损血和伤害`,[plan.outcome.hpLoss,plan.outcome.damageDealt],[hpLoss,damage]);
}
equal('WZ第1/3试T4完整手牌和敌盘面相同',
  [state(305565).combat.hand,state(305565).combat.enemies],[state(305630).combat.hand,state(305630).combat.enemies]);
equal('WZ两条实盘端点血价/完整扣血',
  [20-state(305570).combat.player.current_hp,20-state(305635).combat.player.current_hp,
    216-state(305570).combat.enemies[0].current_hp,216-state(305635).combat.enemies[0].current_hp],[13,18,28,34]);
for (const [line,indices,hpLoss,damage,enemyHp] of [[305565,[0,1,2,4],13,25,188],[305630,[1,2,3,4],18,31,182]]) {
  const plan = replay(line,indices);
  const retaliation = (plan.outcome.retaliated ?? []).reduce((sum,e)=>sum+e.amount,0);
  equal(`s${line}当前局部模型与额外反伤分账`,
    [plan.outcome.hpLoss,plan.outcome.damageDealt,retaliation,plan.outcome.enemyHpAfter[0].hp-retaliation],[hpLoss,damage,3,enemyHp]);
}
equal('WZT6实际11毒跨160并取消攻击',
  [state(305738).combat.enemies[0].current_hp,state(305739).combat.enemies[0].current_hp,
    state(305738).combat.player.current_hp,state(305739).combat.player.current_hp,
    power(state(305739).combat.enemies[0],'PLOW_POWER'),power(state(305739).combat.enemies[0],'STRENGTH_POWER')],[166,155,8,8,0,0]);
const threshold = replay(305738,[]);
equal('当前局部模型保留现场160阈值',
  [threshold.outcome.hpLoss,threshold.outcome.damageDealt,threshold.outcome.enemyHpAfter[0].hp],[0,11,155]);
equal('WZT8现场无究极防御且只打一张后锁牌',
  [state(305741).combat.hand.some((c)=>c.card_id==='ULTIMATE_DEFEND'),
    state(305742).combat.player.energy,state(305742).combat.player.block,
    state(305743).combat.hand.every((c)=>!c.playable&&c.unplayable_reason==='blocked_by_hook')],[false,2,8,true]);
const ringing = replay(305741,[1]);
equal('当前局部模型昏眩生存者血量预算',
  [ringing.outcome.hpLoss,ringing.outcome.hpAfter,ringing.outcome.blockGained,
    ringing.outcome.enemyHpAfter[0].hp,(ringing.outcome.retaliated??[]).reduce((sum,e)=>sum+e.amount,0)],[9,-1,8,112,3]);
equal('WZT8实盘只截断到零血且敌余109',
  [state(305744).combat.player.current_hp,state(305744).combat.enemies[0].current_hp],[0,109]);
const negative = replay(305347,[1,2,4]);
equal('2H负力敏末轮当前局部模型',
  [negative.outcome.damageDealt,negative.outcome.blockGained,negative.outcome.hpLoss,negative.outcome.hpAfter],[2,8,17,-6]);
equal('没有读取刷新的知识文件',deniedKnowledgeReads,[]);
fs.writeFileSync(`${directory}fixed-verification.json`,JSON.stringify({ scope:'固定原帧与现有单轮原语；不是完整候选认证或生产测试',checks,knowledge_reads:deniedKnowledgeReads },null,2)+'\n');
console.log(JSON.stringify({scope:'材料及现有局部模型核验',checks:checks.length,passed:true}));

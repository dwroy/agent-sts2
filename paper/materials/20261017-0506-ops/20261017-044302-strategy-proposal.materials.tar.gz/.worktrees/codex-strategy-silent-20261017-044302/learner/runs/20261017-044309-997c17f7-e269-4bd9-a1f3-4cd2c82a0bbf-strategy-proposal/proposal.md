# 本批静默策略提案核对

记录时间：2026-10-17 05:04:08 CST（写入前执行date）。batch=20261017-044302-strategy-proposal；基线 `edff4b9a3f6a9a8061c077a5ce731781fc7d4c79`。

只处理本批派发的十个原CLI ID，不新增或领取其他ID。九项waiting、一项duplicate；不修改源码、知识或玩法参数。原Markdown均核原队列SHA并按原字节保存为`<id>.original.md`，身份见dispatch.json，原登记见assigned-proposals.json。

适用范围仅本批四个SILENT A10局。SL是同局重试，不增加独立样本；本批发现/确定性核验不作时间留出。未来新增本角色完整对局、保持同盘同后继的配对数据才用于策略效果验证。实际模型/策略来源不以本次授权或预训练事实替代。

## silent-proposal-ac022f51b42a960f：静默路线真实问号战血药链及未到恢复节点不预支

- 处置：waiting。
- 来源任务：experience-update；实现任务：strategy-proposal；原领域：structure,potion,terminal。
- 原证据局：PF90JTU0UZ5M；层/回合：PF90JTU0UZ5M F19/20/21/22；未到F23/27/29/32。
- 原学习账本：silent-0019,silent-0020；原提案SHA256：`2a12592de1dd750dd3de3f2f7feddf2e88858d242cd39e832d1ae46e2cc007a2`。
- 支持、反例与限制：三胜65→47→21→3；F21含一次SL恢复，不能重复计血药。
- 旧行为/现有实现与本次结论：现有路线绝对来源投影、当前HP/药栏和离线资源链已有；缺已发生问号战/逐槽药水/恢复来源与路线休息题面的完整联合读回，未找到新的可隔离数值失配。未到恢复点不计实回，不据本四局拟安全血线。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-f10961933e0f7f14：静默SL同底板锚线重放保留当轮血价及后继生存约束

- 处置：waiting。
- 来源任务：experience-update；实现任务：strategy-proposal；原领域：combat,potion,sl。
- 原证据局：PF90JTU0UZ5M；层/回合：PF90JTU0UZ5M F22第3/4试T1—T3；SY0WMJNNVRLM F21第2/3试T4。
- 原学习账本：silent-0079,silent-0007；原提案SHA256：`92b9e5d94fb4605ddad61aeb24f4e32d48ec2053c7fc76fc5a45496f2011f2c7`。
- 支持、反例与限制：PF原防御线损0/扣26，锚线损2/扣31；SY同9血、39/23敌HP各5毒，两试后继不同。
- 旧行为/现有实现与本次结论：已有重放/探索即时资源比较与离线动作关联；仍缺锚线连续执行认证、固定后继与未截断入伤。不能从PF多损2或SY最终胜一试推统一杀序/重放禁令，保留原准入。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-91afbdb3459a627b：核对静默A10多敌退场进度、族母吸取后的真实攻防与计划所求/实际构筑事实；先查已有等价实现，不据单局定集火或选牌规则。

- 处置：waiting。
- 来源任务：postmortem；实现任务：strategy-proposal；原领域：combat,structure。
- 原证据局：2H311EAD34GD；层/回合：2H311EAD34GD F8T1/T5；F17T7/T11/T12。
- 原学习账本：silent-0209,silent-0030,silent-0211,silent-0005,silent-0158；原提案SHA256：`c9def33a952e20af7d74772bb44fa2b28c8b33fc43f89021775f9317f6d4830c`。
- 支持、反例与限制：F8四体到T3才首退，胜55→4；末T12力−4/敏−1，两防御8对25攻、11血实死，敌余79。
- 旧行为/现有实现与本次结论：题面已有逐敌HP/挡/意图、当前净属性和分列的deck/want；离线多同类敌实体不作稳定跨帧归属。缺退场进度与计划组件实际兑现的完整消费者验收，未证固定集火/选牌/求毒策略收益，不将局部事实通道当整项完成。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-ce28c6de450fda0b：区分全败B2与五轮存活、护栏中间替换和SL最终动作，验证同盘面多6伤/多损8血；保持现门禁与必死规则，缺整场配对数据。

- 处置：waiting。
- 来源任务：postmortem；实现任务：strategy-proposal；原领域：combat,sl。
- 原证据局：2H311EAD34GD；层/回合：2H311EAD34GD F17第4/5试T4、末试T10。
- 原学习账本：silent-0079,silent-0125；原提案SHA256：`62d4fc94fddd1369acba35208d9c83133383a3759ab0987e1365c9a7ff087c1e`。
- 支持、反例与限制：同52血/3能/3敏/6覆甲：实际损1/9、扣25/31；五轮0/24死与整场0/1200胜分列。
- 旧行为/现有实现与本次结论：现有selection_audit、hp_guard、SL候选比较与本次离线关联已保留阶段；完整候选结果仍null。缺可归属完整执行和受控后继，无法把护栏中间替换或B2零胜并列校准为整战因果，不改护栏/SL规则。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-14f13ef0487858d7：按固定帧验证铁心增加7覆甲而非即时/恒定挡及后续现场剩层；先查现模型，不凭两试差1改喝药门槛。

- 处置：duplicate。实际live祖先源码commit：`66283dd9982bdd7f480da7a4d9bfefea0572a9ac`。
- 来源任务：postmortem；实现任务：strategy-proposal；原领域：potion,combat。
- 原证据局：2H311EAD34GD；层/回合：2H311EAD34GD F17六次饮用、T4/T5/T10。
- 原学习账本：silent-0277；原提案SHA256：`a76a8ef62562caf88dbd54e3173f01e04f08dc0dcd058a4507d9f36219a57383`。
- 支持、反例与限制：六次饮用均覆甲+7、旧挡不变；同盘T4剩6层并实损1，后轮用剩层，末轮无覆甲。
- 旧行为/现有实现与本次结论：提案要求的模型核验已存在：modelPotion建立7覆甲且即时block为0，combat-plan从现场PLATING_POWER读取endTurnBlock，后轮重读现场值。六饮原帧及同盘局部模型核验通过。原提案明确不要求拟新喝药时点；同瓶六次SL非六独立样本，完整减层机制与早晚喝整战收益仍未知。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-81e3b8bf97493a4a：核验仪式兽全败并列SL探索中少5挡换6伤的同盘血价，先补可审计配对事实，缺完整后继对照时保留探索规则。

- 处置：waiting。
- 来源任务：postmortem；实现任务：strategy-proposal；原领域：combat,sl。
- 原证据局：WZL2AMEY85S7；层/回合：WZL2AMEY85S7 F17第1/3试T4。
- 原学习账本：silent-0079；原提案SHA256：`8fc114be41ed4ffd405a83f715adf83924ed58a015234ae6dc86663482e26b0c`。
- 支持、反例与限制：同20血/敌216/4力/7毒：损13/18、整轮扣28/34；25/31模型伤另有3荆棘。
- 旧行为/现有实现与本次结论：即时血价和SL候选审计已存在；本次原帧与局部模型可重现交换，缺完整原线受控后继和逐源完整候选认证。B2零胜不能证明同等安全，也不足拟新的探索血线。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-c9eebe66516045f0：核验昏眩1下按实际首张计算存活预算，分开毒/荆棘/阈值取消攻击及HP死亡截断；现有计算一致，不冒认新bug或新增未经验证评分。

- 处置：waiting。
- 来源任务：postmortem；实现任务：strategy-proposal；原领域：combat。
- 原证据局：WZL2AMEY85S7；层/回合：WZL2AMEY85S7 F17末试T5/T6/T8。
- 原学习账本：silent-0222,silent-0011,silent-0046,silent-0129,silent-0133；原提案SHA256：`ce0b76cafab46cc79aabfbe11932eeccfab1c6e09e48f39d0878e0023d7a954d`。
- 支持、反例与限制：T6毒11使166→155跨现场160并取消攻击；T8生存者8挡后余2能锁牌，需损9、8血归零，敌109。
- 旧行为/现有实现与本次结论：昏眩单牌上限、阈值取消与毒/荆棘局部模型均可核；本次只验证所选生存者及已见端点，未认证全部合法首张的题面预算和完整结算来源。未抽究极防御不算可用，缺首张替换/提前抽牌受控后继，保留原评分。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-fcdf526c2ff89a96：静默实建力敏、负属性、覆甲剩量、毒与反伤结算及单牌限制核验

- 处置：waiting。
- 来源任务：experience-update；实现任务：strategy-proposal；原领域：combat,potion。
- 原证据局：2H311EAD34GD,WZL2AMEY85S7,SY0WMJNNVRLM；层/回合：2H311EAD34GD F8、F17T4/T7/T11/T12；WZL2AMEY85S7 F17T4/T6/T8；SY0WMJNNVRLM F14T1。
- 原学习账本：silent-0005,silent-0012,silent-0021,silent-0030,silent-0079,silent-0209,silent-0211,silent-0158,silent-0277,silent-0011,silent-0046,silent-0129,silent-0133,silent-0222；原提案SHA256：`bc3d75cbeca95639b087c20d616a12c94018cefff9c4f0a45511bada2fca0866`。
- 支持、反例与限制：净力敏、现场覆甲、毒跨阈值、反伤和昏眩分别成立；局部已正确不代表联合策略收益。
- 旧行为/现有实现与本次结论：覆甲窄模型已有且14f已单列duplicate；联合多入口/多轮校准、完整减层条件及完整候选分源归属仍缺。当前胆小经验已限定不把每次攻击当必补盾，不采用旧宽语作新规则；未重核A5HK原局，不新增反证或支持样本。原宽项不关闭。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-ef192c07f518e37d：静默路线已发生战斗血药链、恢复节点及随机升级组件验收

- 处置：waiting。
- 来源任务：experience-update；实现任务：strategy-proposal；原领域：structure,potion。
- 原证据局：2H311EAD34GD,WZL2AMEY85S7；层/回合：2H311EAD34GD F7/9/12/16与F8/F17；WZL2AMEY85S7 F4/F13、四火及F17。
- 原学习账本：silent-0019,silent-0020,silent-0170；原提案SHA256：`7fa53193603db47d35d1d7b5915bec9b4618d40c0d614a8cf9f06a59d8cbfa00`。
- 支持、反例与限制：两局各四火实回84，前七胜净耗82/91、事件耗6/9后52/40进Boss；未有替路线整战对照。
- 旧行为/现有实现与本次结论：已有当前牌组/药栏/HP与离线净资源链；缺随机升级具体牌验收、问号战计数及路线/休息消费者的完整关联。随机强化不当核心已升级，未发现新独立源码差额，不据六败改路线或回血规则。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。

## silent-proposal-a3ac35773142c17f：静默全败模拟同盘探索保留少挡换伤血价及后继需求

- 处置：waiting。
- 来源任务：experience-update；实现任务：strategy-proposal；原领域：combat,sl。
- 原证据局：2H311EAD34GD,WZL2AMEY85S7；层/回合：2H311EAD34GD F17第4/5试T4；WZL2AMEY85S7 F17第1/3试T4、末试T6/T8。
- 原学习账本：silent-0030,silent-0079,silent-0133；原提案SHA256：`7270b7e1dc9847d6785c27401c09dd2665244686fa8a861e28d1c9007b02104c`。
- 支持、反例与限制：两组少挡换伤分别多6伤/多损8和多6伤/多损5；两场各六败，但后续抽牌和动作不同。
- 旧行为/现有实现与本次结论：已有原答/护栏/SL即时资源审计，本批重算同盘局部交换；缺保持未来牌序/动作的整战配对或新增完整胜次，不能据两组端点拟统一禁止探索/新排序，整项waiting。
- 预期行为：仅在可验证事实缺口成立时补限定显示/模型；缺证保持当前行为，不删合法选项，不混其他角色或未观察进阶。
- 验证：本批八流4482封套逐原offset/bytes/SHA/JSON和显式身份读回；四局离线消费者、33固定帧及23局部核验与13材料核验分别保存。具体适用项见fixed-verification.json、material-checks.json、各局consumer-output.json；这不认证完整候选或胜率收益。
- 拟合/回退：未拟参数，未新增源码提交；本批无行为差量可回退。保留原提案、失败和初稿，后续实现应独立提交并可独立revert。


from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

root = Path.cwd()
stage = root / 'ops/codex-ops/record-staging/20261015-2124'
public = root / 'paper/materials/20261015-2124-ops'
sha = lambda data: hashlib.sha256(data).hexdigest()


def git(*args, cwd=root):
    return subprocess.check_output(['git', '-C', str(cwd), *args], stderr=subprocess.PIPE)


def load(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


base = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--cached', '--name-only').strip()
batch_id = '20261015-211145-fix-batch'
batch = load(root / 'ops/codex-ops/learn.json')['batches'][batch_id]
report = batch['report']
scratch = Path(report['report']).parent
assert batch['state'] == 'failed' and batch['rc'] == 0
assert batch['proposal_audit_errors'] == []
assert report['fixes'] == [] and report['merged'] is None
assert report['code_proposals'] == [] and report['implementation_domains'] == []
assert report['tests'] == dict(tsc=0, vitest=0, cases=59, files=7, scope='targeted', reruns=[])
assert git('rev-parse', 'HEAD', cwd=batch['worktree']).decode().strip() == report['base']
assert not git('status', '--porcelain', '--untracked-files=no', cwd=batch['worktree']).strip()
exec((root / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native = runtime(batch_id, report, (root / 'ops/codex-ops/learner' / (batch_id + '.out')).read_text(), batch['worktree'])

audit = load(scratch / 'audit.json')
assert audit['base'] == report['base']
assert audit['no_new_source_changes'] and audit['no_new_commits_since_merged_main']
assert audit['changed_code_since_prior'] == []
sources = audit['existing_fixes']
assert len(sources) == 73 and len({row['path'] for row in sources}) == 51
assert sha((scratch / 'queue-snapshot.md').read_bytes()) == audit['queue_sha256']
prior = Path(audit['prior_audit']).parent
assert sha(Path(audit['prior_audit']).read_bytes()) == audit['prior_audit_sha256']
assert (scratch / 'queue-snapshot.md').read_bytes() == (prior / 'queue-snapshot.md').read_bytes() + audit['queue_appended_text'].encode()
assert not audit['queue_identical_to_prior'] and audit['queue_lines'] == 1338
for row in sources:
    for target in [report['base'], audit['live_read_only_snapshot']]:
        git('merge-base', '--is-ancestor', row['source_commit'], target)
    assert sha(git('show', report['base'] + ':' + row['path'])) == row['current_source_sha256']
    if row['live_leaf_present']:
        assert sha(git('show', audit['live_read_only_snapshot'] + ':' + row['path'])) == row['live_source_sha256']
    else:
        assert not git('ls-tree', audit['live_read_only_snapshot'], '--', row['path']).strip()
    assert all(row[key] for key in ['same_as_prior_audit', 'same_as_committed_base', 'ancestor_in_base', 'ancestor_in_live_snapshot'])

queue = load(scratch / 'queue-dispositions.json')
assert len(queue) == len(audit['unchecked_queue_entries']) == 41
assert all(row['disposition'] for row in queue)
assert [(row['line'], row['item']) for row in queue] == [(row['line'], row['item']) for row in audit['unchecked_queue_entries']]
old_0481 = [row for row in load(prior / 'queue-dispositions.json') if 'silent-0481' in row['item']]
new_0481 = [row for row in queue if 'silent-0481' in row['item']]
assert len(old_0481) == len(new_0481) == 1
assert old_0481[0]['commit'] == '66c22ba7d87b8748690a4183fff838acd346bd3e'
assert '686d4e759478eebb' in new_0481[0]['disposition']
assert new_0481[0]['prior_scratch_inventory_correction']
selection = git('show', report['base'] + ':agent/src/hand/screens/selection.ts').decode()
assert selection.count('This card is only for this turn') == 2
assert (scratch / 'source.diff').read_bytes() == b''
for name in ['tsc', 'vitest', 'gitleaks']:
    assert (scratch / (name + '.exit')).read_text().strip() == '0'
assert load(scratch / 'gitleaks.json') == []
assert re.search(r'Test Files\s+7 passed', (scratch / 'vitest.log').read_text())
assert re.search(r'Tests\s+59 passed', (scratch / 'vitest.log').read_text())

evidence = load(scratch / 'evidence-readback.json')
for ref in [evidence['startup'], evidence['resource_receipt']]:
    assert sha(Path(ref['path']).read_bytes()) == ref['sha256']
assert evidence['startup']['attempt']['lease'] is None
assert evidence['startup']['attempt']['batch'] is None
assert len(evidence['raw_decision_checks']) == 9
for row in evidence['raw_decision_checks']:
    ref = row['source']
    path = (root / ref['path']).resolve()
    assert path.is_relative_to(root)
    with path.open('rb') as handle:
        handle.seek(ref['offset'])
        raw = handle.read(ref['bytes'])
    assert sha(raw) == ref['sha256']
    assert json.loads(raw)['run_id'] == row['run_id'] == 'RQCHNN0W72KF'

at = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
receipt = dict(
    at=at, batch=batch_id, canonical_state=batch['state'], rc=batch['rc'], original_report=report,
    current_main=base, current_live_read_only=git('rev-parse', 'HEAD', cwd=root / '.worktrees/live').decode().strip(),
    native=native, original_pinned_live=audit['live_read_only_snapshot'],
    source_references_verified=73, unique_source_paths=51,
    source_base_shas_and_ancestors_verified=True,
    pinned_live_existing_leaf_shas_verified=True,
    pinned_live_absent_paths=sorted({row['path'] for row in sources if not row['live_leaf_present']}),
    pinned_live_different_paths=sorted({row['path'] for row in sources if row['live_leaf_present'] and not row['same_source_in_live']}),
    source_ancestry_is_not_leaf_equality_or_current_deployment=True,
    queue_unchecked=41, queue_prefix_preserved=True, queue_concurrent_append=audit['queue_appended_text'],
    audit_attachment_correction=dict(previous=old_0481[0], current=new_0481[0],
        scope='Only the current audit attachment classification is corrected. The prior report body already retained this unresolved issue; old files remain unchanged. No new game claim, implementation, notice ACK or learning task.'),
    original_checks=report['tests'], checks_reexecuted=False, full_suite_claim=False,
    original_check_log_shas={name: sha((scratch / name).read_bytes()) for name in ['tsc.log', 'tsc.exit', 'vitest.log', 'vitest.exit', 'gitleaks.log', 'gitleaks.exit', 'gitleaks.json']},
    no_new_source_commit_or_blocked_merge=True,
    canonical_failed_rc0_preserved_not_product_failure_claim=True,
    original_startup_and_nine_resource_failure_rows_verified=True,
    preparation_failures_preserved=['Pinned live worktree_storage.py absent: original first audit failure retained.', 'Concurrent original0332 queue append: failed byte-identical assumption retained; prior prefix verified.'],
    unresolved='Original0332 resources/steps remain truncated and mechanism root cause unknown. Empty startup lease does not identify refusal branch, registration timing or directory deleter. Other original strategy, performance and architecture parents remain open under their existing owners.',
    no_ledger_lesson_queue_source_release_dataset_or_runtime_mutation=True,
)
write(public / 'fix-readback.json', receipt)
archive_manifest = []
originals = sorted([path for path in scratch.iterdir() if path.is_file()] + [root / 'ops/codex-ops/learner' / (batch_id + extension) for extension in ['.out', '.err']])
with tarfile.open(public / 'original-artifacts.tar.gz', 'w:gz') as archive:
    for path in originals:
        raw = path.read_bytes()
        relative = str(path.relative_to(root))
        copy = stage / 'archive-scan' / relative
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        archive.add(path, arcname=relative)
        archive_manifest.append(dict(path=relative, bytes=len(raw), sha256=sha(raw)))
write(public / 'original-artifact-manifest.json', archive_manifest)
decision = f'\n- {at} 运维codex：2124原211145-fix回报核，canonical failed/rc0/mergednull原态保持；f328干净WT无新增源码提交、纯bug或合入阻塞，不空合/发号。73项既有修复/窄子项51源码叶与base逐SHA、来源main/原live祖先核；旧livefe646265仅核实际存在叶，11叶差及worktree_storage缺失原样保留，不将祖先冒当前部署。41未勾选项逐处置核，旧1336行前缀与21:14原0332补链追加保持；0481前批附件误关联刀舞66c22已由本批附件纠正为原686d策略待办，前批正文原已列未修、旧附件不改，不当新知识或新修复。原tsc0/7文件59定向0/无重跑/gitleaks0仅原覆盖，实际native Sol6.1/xhigh/input/lease及workspace-write/no-network核，原high文字与材料审计两次失败留史；原缺叶、队列并行追加误断言已按实修正，非产品失败。RQ F40/F48九条原决策及启动空租约字节SHA核，完整resources/steps仍截断、0332根因未知，C1出口不当根因修复；f4e/5aa及其他原策略/架构owner继续，不复派或手动重放。无ledger/复盘/队列/论文刷新、源码发布或对局/账号home模型预算prompt操作；仅提交本轮回执与记录，保并行脏记录、不等待后续事件。证据paper/materials/20261015-2124-ops/。\n'
inbox = f'\n- {at} [ops 修复批次处置] 原211145无新增修复或提交/合入阻塞，原7文件59项定向检查通过已核；0481旧审计附件误关联已在本批更正，仍沿原策略提案待办。0332与启动生命周期根因缺证保持，不重派、重测、空合或发行为号。回执paper/materials/20261015-2124-ops/。\n'
appends = {'paper/materials/decision-log.md': decision, 'ops/inbox-dev.md': inbox}
write(stage / 'own-appends.json', appends)
for path, text in appends.items():
    with (root / path).open('ab') as handle:
        handle.write(text.encode())

helper_manifest = []
with tarfile.open(public / 'ops-helper-sources.tar.gz', 'w:gz') as archive:
    for path in [stage / 'prepare-records.py', stage / 'seal-records.py', root / 'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
        raw = path.read_bytes()
        copy = stage / 'helper-scan' / path.name
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(raw)
        archive.add(path, arcname=path.name)
        helper_manifest.append(dict(path=str(path.relative_to(root)), bytes=len(raw), sha256=sha(raw)))
write(public / 'ops-helper-manifest.json', helper_manifest)
values = {path: git('show', base + ':' + path) + text.encode() for path, text in appends.items()}
for path in public.iterdir():
    if path.is_file():
        values[str(path.relative_to(root))] = path.read_bytes()
entries = []
for path, raw in values.items():
    copy = stage / 'final-files' / path
    copy.parent.mkdir(parents=True, exist_ok=True)
    copy.write_bytes(raw)
    entries.append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
write(stage / 'record-manifest.json', dict(base=base, paths=entries))
print(json.dumps(dict(batch=batch_id, new_fix=False, sources_verified=73, original_targeted_tests=59, runtime_verified=True, old_attachment_correction_verified=True, paths=len(entries))))

## 修 bug 回报

- 合并基线：main → f32876369a61ee7ead8193a53dcd652837060c6a（开工工作区干净，先合并main，Already up to date.）
- 修复（每条一行）：无新增修复；当前队列纯bug已由既有提交覆盖，其他未闭合项属策略类、证据不足或独立功能。没有源码变更、新提交或适用的撤修复验证。
- 已被别人修掉的：silent-0254：无动作死亡战斗归因 — 已修，提交 3b48088dec5fc6eafe576a1296bbdadde43432ee（当前 ops/report.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：codex-usage-credit-baseline-recovery：额度窗口恢复基线 — 已修，提交 5b56a452bb9be14d620b368ec46974c1b57901ca（当前 agent/src/brain/engines/codex-usage.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ascension-up：请求进阶误报为实际进阶 — 已修，提交 8045d9fbf0a12523b1dbe39bbed8af06c7497b09（当前 ops/codex-ops-learn.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：infra-target-options-fixed-fixture-timeout — 已修，提交 bae9c45ccffefb284a1c6634526c8768a9f5f7a8（当前 agent/tests/target-option-fixture.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：infra-ledger-status-prefix-git-divergence — 已修，提交 dd478f0b3e5a0f234f082972d21b203dbf8229d7（当前 learner/ledger.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：infra-legacy-continuation-notice-ack-identity — 已修，提交 368fccabd42eb72ffcea9a2fe6cbbb7c149326be（当前 ops/learning_requests.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：infra-paper-krane-recorded-line-timeout — 已修，提交 befc39e5ca0105f8ff96d47f817df44f0b2760f1（当前 agent/tests/silent-paper-krane.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：infra-learner-event-log-second-collision — 已修，提交 b6ee3f8c29cc10d4652a67d14f0e0e394aa6ce6f（当前 learner/lib/launcher.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：strategy-proposal：报告 scratch 归属 — 已修，提交 5f04139cefe5c651dd5bf62f7e164014dbf5f23b（当前 learner/lib/launcher.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0459：独立 run-plan 请求成本漏计 — 已修，提交 799a5cd0caf9329b43c32376079218a9bd0c3e9e（当前 ops/report.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：run-plan 证据提取未识别 run 字段 — 已修，提交 78e9b05929366d097a728761d693d790ff16ac87（当前 learner/extract_evidence.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：postmortem-capacity-failure-proposal-repair-20261013 — 已修，提交 3fdcd77927f01b35c20c6c5c1fcfd790676032d2（当前 ops/codex-ops-learn.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：blocked-experience-proposal-repair-dispatch — 已修，提交 84366ad06ee4f978394c1b9489a82c83ea12bd36（当前 ops/proposal_dispatch.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：普通 ACK — 已修，提交 672e198a4730012330f599068a0ef1efadb02002（当前 ops/learning_requests.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：前阶段回执校验 — 已修，提交 1594def2e1b65b665d3b345f31444194eb4d09e6（当前 ops/learning_requests.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：learning-notice-ordinary-ack-registry-20261013：第二策略槽批号 — 已修，提交 15eb85e2934e428c5e299fc4a1aba456d92fd685（当前 ops/learning_requests.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：feature 通知来源身份校验 — 已修，提交 38b2f572d90b3b97a23f9eae983f583287492f9a（当前 ops/learning_requests.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：feature/B4 通知来源桥接 — 已修，提交 1dd4d434aef67f1d065dbdba23a875ae82741a88（当前 ops/learning_requests.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：batch-f：包装/参数化测试超时静态解析 — 已修，提交 56c256dad0d33b231b82b53113d3bdd84f9bfa20（当前 agent/tests/batch-f.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：unassigned-strategy-proposal-resolution — 已修，提交 3a98e213a826e94f9708af4b1a265e1892659f4e（当前 ops/proposal_dispatch.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-fixed-test-timeouts-010547：eval 固定历史输入 — 已修，提交 d9881ba593b0b8d701ebbe1c95626c0ebdd554c7（当前 agent/tests/eval.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-fixed-test-timeouts-010547：Apotheosis 有界夹具 — 已修，提交 9e8c93555131c3347f9e809d9722a848a75c2692（当前 agent/tests/silent-apotheosis-reference.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：compute-memo-worker-data-signature — 已修，提交 8fbb441eb61eef226eb7366f9612003480c83988（当前 agent/tests/compute-memo.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：rollout-live-best-test-determinism — 已修，提交 bbc5b993a7524bbb8e80a975f204f8d193657b46（当前 agent/tests/rollout-live.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-targeted-check-continuation：已过覆盖的精确续验入口 — 已修，提交 24c2e3a75b5db6bac76d6c924f86b7fcd9438316（当前 ops/learner_check_continuation.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：sandbox-glob-startup-race：会话前有界恢复 — 已修，提交 bc2c40e313cc36682196277c53c50e30744b88c5（当前 learner/lib/startup-recovery.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：sandbox-glob-startup-race：复盘租约绑定 — 已修，提交 d9983263ffecea1bed4e29d65e7f854a3d2e33d7（当前 learner/lib/startup-recovery.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：core-cycle-implementation-binding-entry — 已修，提交 fc95760d4ff8a9cbd45577efdd79b1215bd2cb92（当前 ops/strategy_implementation_jobs.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-20261012-quantitative-continuation — 已修，提交 b408252f87a77ee5389c4d90e52a9831c0873348（当前 ops/strategy_implementation_continuation.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：named-card-facts-transport：已批准的事件入口子项 — 已修，提交 42c920f34d9dc1c783ce894659849ab37ed6fd1b（当前 agent/src/hand/screens/event.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：core-build-notify-222802-rc2：保留原生失败诊断子项 — 已修，提交 5c92f2aaf0b758a1a5e7d591745694004664f83a（当前 ops/core_build_jobs.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：paper-dataset-git-consistency-race — 已修，提交 16bfe0bd6ecaa91d04a91c01edc94cecc781f71f（当前 ops/paper_dataset.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：boss-sim-codex-home-preflight — 已修，提交 5921f8cd045853182c867a6430e75c3fcde00a87（当前 ops/report.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：shared-experience-fixed-filesystem-snapshot-20261013 — 已修，提交 8390c62d76fc8c7d7b6b7292121a621f4666d39c（当前 agent/tests/historical-knowledge-fs.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-deck-cap-consumer-fixture-isolation-20261013（原 c0999eaa 补丁的实际重放集成） — 已修，提交 ec8c578b66bf5498372f1b779ae58a766dff8112（当前 agent/tests/silent-tail-resource.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：首项异步夹具 — 已修，提交 95e7f050ef2abe5c85a0367555392652ad73fbfe（当前 agent/tests/ops-stall-recovery.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-stall-recovery-test-subprocess-timeout：固定失败诊断 — 已修，提交 9b6459fd99f26b17689134e33aa85d6190e71d7d（当前 agent/tests/ops-stall-recovery.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：batch-c-fixed-fixture-timeout — 已修，提交 5dd8a20c9d2dd4ed43120b1684e5577b993ac2ff（当前 agent/tests/batch-c.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：晚写复盘误计为上线后重犯 — 已修，提交 2610945b6a2f9ea02cf3a7cd4b5980d24814ac39（当前 learner/ledger.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：学习账本 first_run/asc/prior_note 追加更正 — 已修，提交 87c89b7aea90c7275e0fbb04b1e4148a4209630c（当前 learner/ledger.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：subscription-usage：未设置 TMPDIR — 已修，提交 6bfbe3d2e2aa6e5e8c1969d5ee1cca08671ae02a（当前 agent/tests/subscription-usage.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：deepseek-prompt-dump：状态日志反向流式扫描 — 已修，提交 6ee8e2a2c1edc31492962137b96af8c6e1d12093（当前 agent/tools/deepseek-prompt-dump.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：固定药水测试隔离 — 已修，提交 e78352f784d39cf25671446348daaada6ef2060b（当前 agent/tests/potion-cost.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：单次 mod 超时 stall 误报 — 已修，提交 a4f4ec868d122dc92af510862c6240cf2eaff2b6（当前 ops/stall-check.sh；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：学习状态锁被完整检查阻塞 — 已修，提交 233ede56047274ba53a4e1191a245fac816c37a8（当前 ops/codex-ops-learn.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：学习者受阻后兜底完整检查入口 — 已修，提交 f670884a188a047bbd3f7f007c260ade62fae36a（当前 ops/learner_checks.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：策略任务及自动派发入口 — 已修，提交 afd652a3f75df6e7403439f01c565220327884da（当前 ops/proposal_dispatch.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：旧事件选项重复问大脑 — 已修，提交 25ce09bee5576b1adff8baf196fbe8b197a5ef11（当前 agent/src/hand/loop.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0153：普通隐秘匕首生成分支 — 已修，提交 b7f081fcc26da4506cb775739bb118cb6cbe4ecc（当前 agent/src/reflex/card-model.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0256：已观察的狡诈药水容量子项（实际源码提交） — 已修，提交 6403fdcdadc803a092beb5165a068e22bf51c412（当前 agent/src/reflex/card-model.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0260：普通紧勒逐牌失血 — 已修，提交 5c7105ff0294466da8319f2934beda05c6040794（当前 agent/src/reflex/card-model.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0263：已观察的碾碎爪转向取整子项 — 已修，提交 ec29ea34b919344b707e57ba472ea210f9c39d62（当前 agent/src/reflex/silent-crusher-facing.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0266：SL 首牌身份 — 已修，提交 e784dd9f043bf87c29109573f48975f9903280d3（当前 agent/src/sl/explore.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0272：商店移除预览与真实选牌页核对 — 已修，提交 db20ec3cc6cd0e47ac014d0c523dd4ed1c781d26（当前 agent/src/hand/screens/shop.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0324：普通刀舞生成小刀 — 已修，提交 66c22ba7d87b8748690a4183fff838acd346bd3e（当前 agent/src/reflex/card-model.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0338：回合末防御事实来源注记 — 已修，提交 c1d84804956bedbd29a7f0e81294114e18415b9d（当前 agent/src/reflex/turn-solver.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：silent-0367：已用蜥蜴尾巴事实接线 — 已修，提交 5baf663d7e6678efa3690e5a48329c4f8baee109（当前 agent/src/brain/build-facts.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：infra-learner-launch-shared-main-config-race — 已修，提交 22efae55484bc2bdcc54e847a8dc40bb4888c4e2（当前 ops/learner_entry.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：固定时间夹具 — 已修，提交 b3c6dd700b00d0d8b17d5d2efe6fe9aa353618fa（当前 agent/tests/loop.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-loop-time-cap-wall-clock-061301：续验拒绝诊断 — 已修，提交 63f656fb07a21a7496353234269901a832eae497（当前 ops/codex-ops-learn.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-worktree-history-disk-pressure：broker容量/回执失败隔离 — 已修，提交 a136ddc4b5b0a8696f10b2fae3073322d57e724c（当前 ops/codex/main.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-worktree-history-disk-pressure：无终态标记退出 — 已修，提交 db072ddab47ba94efb46dce2913927f936ecb97e（当前 ops/autoplay.sh；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-worktree-history-disk-pressure：JSONL追加边界 — 已修，提交 9b07240b18f862efdbe630889ade04e8976eaace（当前 agent/src/brain/engines/codex.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：ops-worktree-history-disk-pressure：历史副本/按需恢复 — 已修，提交 c7a6efb1e15ed6c5f31a35ae3ee9833863340393（当前 ops/worktree_storage.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：tracked-source Python缓存回收认定 — 已修，提交 1e8af775f6b90f100f20ff7c4a08dfddaba893a9（当前 ops/learner_retention.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：完成报告裸JSON兼容 — 已修，提交 6f86ff6b6b971fb38b96308ebdd34dec574e5b13（当前 ops/learner_checks.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：autoplay安全热交接动作 — 已修，提交 71b835a3150704548fab2ad46e74bde240ccf1f9（当前 ops/autoplay-reload.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：历史测试入口漏传日志回调 — 已修，提交 ccd8bb8e017da9c30b408138d04e6d2bc985836d（当前 agent/tests/legacy-brain.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：额度警告固定测试契约 — 已修，提交 1cf0490492bd8a430b85f95f3fdee91eba251191（当前 agent/tests/brain-codex-usage.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：有限结束报告与补验交接 — 已修，提交 2c4ce406c9ae598835f22292e52cfd936ac10b14（当前 ops/learner_checks.py；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-checks-broker-push-registration — 已修，提交 c519952b31e3a0bb3acdd2115883ae8671b8a090（当前 ops/codex-ops-actions.sh；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：host-checks-session-exit-fixture — 已修，提交 874ae603b3927173f805e0b2fe789330bab710c7（当前 agent/tests/brain-codex-session.test.ts；仅确认既有窄范围，宽父保持）。
- 已被别人修掉的：v5-dpr-health：明确不支持的候选被误计为DPR交付失败（仅分类子项） — 已修，提交 9e6dd82a34fb8c14e012be68fd0b632544f1459f（当前 ops/module_health.py；仅确认既有窄范围，宽父保持）。
- 没修的：silent-0481：技能药水选牌生命周期措辞 — 策略类/题面知识：selection.ts 两处旧措辞仍在；已有 silent-proposal-686d4e759478eebb，按独立 strategy-proposal 实现，本普通批不重复登记。
- 没修的：silent-0311：库存后继血量预算 — 策略类/模型：现有 enemyDown 仍按旧 maxHp 恢复；已有 silent-proposal-d2f24919ee64b90b。2LZHP9BYFTHE 正确定位为 A10 F37 T1/4/10，保留原策略链，不加固定倍率。
- 没修的：silent-0332：成功首战资源 nonpositive-hp — 证据不足：RQCHNN0W72KF F40/F48 九条原决策及三组 pending/pending/degraded 已逐原offset/bytes/SHA核验，完整resources/steps仍截断、机制根因未知。队列21:14追加复盘明确非新bug；沿原5aa2672及f4e0f382dd79714b策略链，不改变正HP契约。
- 没修的：silent-0469：聚合体纸鹤组合 — 策略类：HLAWCGM3KHVB F49T3 多击/玩家易伤/突然一拳超出已发布骑士窄范围；沿 silent-proposal-0cce435d0d61ac93，不关闭宽父。
- 没修的：rest-timeout-accepted-route-not-committed / silent-0446 — 策略类/结构：hand/loop.ts 仍在 dispatch 成功后 applyResolved；沿 silent-proposal-2d3aa8dfb27dbe3f 验证动作确认与路线提交，不无条件提交未确认动作。
- 没修的：其余出牌、机制、药水、SL、终局、路线、休息未闭合范围 — 策略类：沿各条原账本与strategy-proposal；41条未勾选项逐行见queue-dispositions.json。只确认已发布窄子项，不关闭宽父。本批未新增规则或提案。
- 没修的：codex 大脑缓存命中偏低 — 证据不足：缺当前原生请求的受控同题比较；本离线任务不调用真实 LLM 或网络，不凭历史命中率判断源码缺陷。
- 没修的：调度公平性核查 — 证据不足：原观察未证明永久饥饿，沿原框架任务核 dispatch/seen_runs，不改变并发、优先级或队列状态。
- 没修的：sandbox-glob-startup-race：上游生命周期/租约未绑定 — 证据不足：已核原191301事件流 attempt1/exit1/retryable=true/batch与lease均null；既有恢复及时间戳复盘租约修复已在main/live。无法据null区分拒绝分支、注册时序或目录删除者，不越租约重放或扩大沙箱。
- 没修的：core-build-notify-222802-rc2：历史发送事实 — 证据不足：后续原生失败诊断已有5c92f2aaf；原rc2无stderr，无法事后还原是否发送，保留原回执，不重发。
- 没修的：named-card-facts-transport：事件入口之外的范围 — 太大/独立功能：事件入口42c920f34已实现，其他入口/跨局及P1/P2范围沿原架构owner，不混入普通修复。
- 没修的：boss模拟样本/性能、v5-dpr-health宽范围 — 太大/独立专项：保持原冻结输入和验收链；固定回归不代替校准，不减样本、扩预算或删候选。
- 没修的：arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression — 策略类/独立架构与归因研究：沿既有批准任务，不在普通批改变资源价值、玩法或派发规则。
- 没修的：框架外层总时限收尾 — 太大/独立框架：精确分段续验入口24c2e3a75已实现；剩余包装器与宿主收尾沿原owner，保留历史失败和覆盖。
- 测试：tsc退出码0；Vitest定向7文件/59用例/退出码0，无重跑。使用固定夹具，无真实LLM或网络调用。未改代码或提交，因此未运行提交前完整test-sandbox；定向结果不等于完整套件。
- 合入：未合入（无新源码/提交，merged=null）。73个既有来源提交均为本基线及只读live fe6462651b593b9831581c088deface9957a404f 祖先；这不表示当前live的全部叶与本分支相同。
- 需要 Roy 定的事（没有写「无」）：无。

附件和核验边界：

- audit.json：73项既有来源、51个当前源码路径SHA及main/live祖先关系逐项核验；与前批相比，agent/learner/ops无代码变化。source.diff为空，工作区干净。
- queue-snapshot.md及queue-change.diff：原1336行完整前缀保持，仅追加21:14的silent-0332复盘补链，现1338行；追加内容明确非新bug。queue-dispositions.json覆盖41条未勾选项。
- 前批queue-dispositions附件曾将silent-0481错误关联刀舞66c22ba7，但前批报告正文已列其未修。本次附件按selection.ts:311/:333实际旧措辞更正分类；未改写前批原件，也未将刀舞修复当生命周期修复。
- live叶比较：11个唯一源码路径存在既有差异，ops/worktree_storage.py在所读live提交中缺失；均保留在audit.json，不覆盖live、不据源祖先关系宣称叶相等或新部署验收。
- evidence-readback.json：复核原191301会话前启动失败，以及RQCHNN0W72KF F40/F48九条原decisions的offset/bytes/SHA、run/floor与控制分支；资源/steps尾部仍缺失，不推断根因、模型收益或策略结果。
- 本轮仅写指定scratch，未改修复队列、账本状态、代码提案队列、eval版本或运行中任务；没有新修复提交可追加账本或合live。
- 审计辅助脚本首轮错误假定live有全部源码路径，遇ops/worktree_storage.py缺叶停止；次轮错误假定队列与前批字节全同，遇并行追加停止（audit-attempt2.log）。修正为逐叶记录缺失及核原前缀/追加内容后通过；两次仅为材料审计准备失败，非产品测试失败。
- tsc.log/tsc.exit与vitest.log/vitest.exit为本次实际结果；测试文件为learner-startup-recovery、learner-strategy-scratch、learner-entry、ledger-publication-baseline、continuation-diagnostics、legacy-continuation-notice-ack、target-options。
- 运行会话未独立读取原生模型请求元数据，未宣称切换模型或把历史启动telemetry当本会话实际模型请求。

```json
{
  "task": "fix-batch",
  "base": "f32876369a61ee7ead8193a53dcd652837060c6a",
  "fixes": [],
  "skipped": [
    {
      "item": "silent-0481：技能药水选牌生命周期措辞",
      "reason": "策略类/题面知识：selection.ts 两处旧措辞仍在；已有 silent-proposal-686d4e759478eebb，按独立 strategy-proposal 实现，本普通批不重复登记。"
    },
    {
      "item": "silent-0311：库存后继血量预算",
      "reason": "策略类/模型：现有 enemyDown 仍按旧 maxHp 恢复；已有 silent-proposal-d2f24919ee64b90b。2LZHP9BYFTHE 正确定位为 A10 F37 T1/4/10，保留原策略链，不加固定倍率。"
    },
    {
      "item": "silent-0332：成功首战资源 nonpositive-hp",
      "reason": "证据不足：RQCHNN0W72KF F40/F48 九条原决策及三组 pending/pending/degraded 已逐原offset/bytes/SHA核验，完整resources/steps仍截断、机制根因未知。队列21:14追加复盘明确非新bug；沿原5aa2672及f4e0f382dd79714b策略链，不改变正HP契约。"
    },
    {
      "item": "silent-0469：聚合体纸鹤组合",
      "reason": "策略类：HLAWCGM3KHVB F49T3 多击/玩家易伤/突然一拳超出已发布骑士窄范围；沿 silent-proposal-0cce435d0d61ac93，不关闭宽父。"
    },
    {
      "item": "rest-timeout-accepted-route-not-committed / silent-0446",
      "reason": "策略类/结构：hand/loop.ts 仍在 dispatch 成功后 applyResolved；沿 silent-proposal-2d3aa8dfb27dbe3f 验证动作确认与路线提交，不无条件提交未确认动作。"
    },
    {
      "item": "其余出牌、机制、药水、SL、终局、路线、休息未闭合范围",
      "reason": "策略类：沿各条原账本与strategy-proposal；41条未勾选项逐行见queue-dispositions.json。只确认已发布窄子项，不关闭宽父。本批未新增规则或提案。"
    },
    {
      "item": "codex 大脑缓存命中偏低",
      "reason": "证据不足：缺当前原生请求的受控同题比较；本离线任务不调用真实 LLM 或网络，不凭历史命中率判断源码缺陷。"
    },
    {
      "item": "调度公平性核查",
      "reason": "证据不足：原观察未证明永久饥饿，沿原框架任务核 dispatch/seen_runs，不改变并发、优先级或队列状态。"
    },
    {
      "item": "sandbox-glob-startup-race：上游生命周期/租约未绑定",
      "reason": "证据不足：已核原191301事件流 attempt1/exit1/retryable=true/batch与lease均null；既有恢复及时间戳复盘租约修复已在main/live。无法据null区分拒绝分支、注册时序或目录删除者，不越租约重放或扩大沙箱。"
    },
    {
      "item": "core-build-notify-222802-rc2：历史发送事实",
      "reason": "证据不足：后续原生失败诊断已有5c92f2aaf；原rc2无stderr，无法事后还原是否发送，保留原回执，不重发。"
    },
    {
      "item": "named-card-facts-transport：事件入口之外的范围",
      "reason": "太大/独立功能：事件入口42c920f34已实现，其他入口/跨局及P1/P2范围沿原架构owner，不混入普通修复。"
    },
    {
      "item": "boss模拟样本/性能、v5-dpr-health宽范围",
      "reason": "太大/独立专项：保持原冻结输入和验收链；固定回归不代替校准，不减样本、扩预算或删候选。"
    },
    {
      "item": "arch-funnel-guard / arch-learning-priority / arch-unified-resource-value / inv-f33-regression",
      "reason": "策略类/独立架构与归因研究：沿既有批准任务，不在普通批改变资源价值、玩法或派发规则。"
    },
    {
      "item": "框架外层总时限收尾",
      "reason": "太大/独立框架：精确分段续验入口24c2e3a75已实现；剩余包装器与宿主收尾沿原owner，保留历史失败和覆盖。"
    }
  ],
  "merged": null,
  "tests": {
    "tsc": 0,
    "vitest": 0,
    "cases": 59,
    "files": 7,
    "scope": "targeted",
    "reruns": []
  },
  "code_proposals": [],
  "implementation_domains": [],
  "report": "/home/dw/Projects/agent-sts2/learner/runs/20261015-211151-2f7c7a4e-e7f3-4eb6-8da1-8ab3627f4ee2-fix-batch/report.md"
}
```

import json
from pathlib import Path

OUT = Path('/home/dw/Projects/agent-sts2/learner/runs/20261015-211151-2f7c7a4e-e7f3-4eb6-8da1-8ab3627f4ee2-fix-batch')
PRIOR = OUT.parent / '20261015-194306-bcf68a34-5915-46a0-a2ce-8d21b36a27e1-fix-batch'
audit = json.loads((OUT / 'audit.json').read_bytes())
previous = json.loads((PRIOR / 'report.json').read_bytes())
skipped = previous['skipped']
for item in skipped:
    if item['item'].startswith('silent-0332'):
        item['reason'] = '证据不足：RQCHNN0W72KF F40/F48 九条原决策及三组 pending/pending/degraded 已逐原offset/bytes/SHA核验，完整resources/steps仍截断、机制根因未知。队列21:14追加复盘明确非新bug；沿原5aa2672及f4e0f382dd79714b策略链，不改变正HP契约。'
    if item['item'].startswith('其余出牌'):
        item['reason'] = '策略类：沿各条原账本与strategy-proposal；41条未勾选项逐行见queue-dispositions.json。只确认已发布窄子项，不关闭宽父。本批未新增规则或提案。'

tests = {
    'tsc': int((OUT / 'tsc.exit').read_text()),
    'vitest': int((OUT / 'vitest.exit').read_text()),
    'cases': 59, 'files': 7, 'scope': 'targeted', 'reruns': [],
}
assert tests['tsc'] == tests['vitest'] == 0
assert 'Tests  59 passed (59)' in (OUT / 'vitest.log').read_text()
result = {
    'task': 'fix-batch', 'base': audit['base'], 'fixes': [], 'skipped': skipped,
    'merged': None, 'tests': tests, 'code_proposals': [], 'implementation_domains': [],
    'report': str(OUT / 'report.md'),
}
(OUT / 'report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
lines = [
    '## 修 bug 回报', '',
    f"- 合并基线：main → {audit['base']}（开工工作区干净，先合并main，Already up to date.）",
    '- 修复（每条一行）：无新增修复；当前队列纯bug已由既有提交覆盖，其他未闭合项属策略类、证据不足或独立功能。没有源码变更、新提交或适用的撤修复验证。',
]
for item in audit['existing_fixes']:
    lines.append(f"- 已被别人修掉的：{item['item']} — 已修，提交 {item['source_commit']}（当前 {item['path']}；仅确认既有窄范围，宽父保持）。")
for item in skipped:
    lines.append(f"- 没修的：{item['item']} — {item['reason']}")
lines.extend([
    '- 测试：tsc退出码0；Vitest定向7文件/59用例/退出码0，无重跑。使用固定夹具，无真实LLM或网络调用。未改代码或提交，因此未运行提交前完整test-sandbox；定向结果不等于完整套件。',
    f"- 合入：未合入（无新源码/提交，merged=null）。73个既有来源提交均为本基线及只读live {audit['live_read_only_snapshot']} 祖先；这不表示当前live的全部叶与本分支相同。",
    '- 需要 Roy 定的事（没有写「无」）：无。', '',
    '附件和核验边界：', '',
    '- audit.json：73项既有来源、51个当前源码路径SHA及main/live祖先关系逐项核验；与前批相比，agent/learner/ops无代码变化。source.diff为空，工作区干净。',
    '- queue-snapshot.md及queue-change.diff：原1336行完整前缀保持，仅追加21:14的silent-0332复盘补链，现1338行；追加内容明确非新bug。queue-dispositions.json覆盖41条未勾选项。',
    '- 前批queue-dispositions附件曾将silent-0481错误关联刀舞66c22ba7，但前批报告正文已列其未修。本次附件按selection.ts:311/:333实际旧措辞更正分类；未改写前批原件，也未将刀舞修复当生命周期修复。',
    '- live叶比较：11个唯一源码路径存在既有差异，ops/worktree_storage.py在所读live提交中缺失；均保留在audit.json，不覆盖live、不据源祖先关系宣称叶相等或新部署验收。',
    '- evidence-readback.json：复核原191301会话前启动失败，以及RQCHNN0W72KF F40/F48九条原decisions的offset/bytes/SHA、run/floor与控制分支；资源/steps尾部仍缺失，不推断根因、模型收益或策略结果。',
    '- 本轮仅写指定scratch，未改修复队列、账本状态、代码提案队列、eval版本或运行中任务；没有新修复提交可追加账本或合live。',
    '- 审计辅助脚本首轮错误假定live有全部源码路径，遇ops/worktree_storage.py缺叶停止；次轮错误假定队列与前批字节全同，遇并行追加停止（audit-attempt2.log）。修正为逐叶记录缺失及核原前缀/追加内容后通过；两次仅为材料审计准备失败，非产品测试失败。',
    '- tsc.log/tsc.exit与vitest.log/vitest.exit为本次实际结果；测试文件为learner-startup-recovery、learner-strategy-scratch、learner-entry、ledger-publication-baseline、continuation-diagnostics、legacy-continuation-notice-ack、target-options。',
    '- 运行会话未独立读取原生模型请求元数据，未宣称切换模型或把历史启动telemetry当本会话实际模型请求。',
    '', '```json', json.dumps(result, ensure_ascii=False, indent=2), '```',
])
(OUT / 'report.md').write_text('\n'.join(lines) + '\n')
(OUT / 'audit-attempt1.md').write_text('材料审计首轮失败：git show fe6462651b593b9831581c088deface9957a404f:ops/worktree_storage.py 返回128，提示该路径存在于磁盘但不在该live提交；脚本CalledProcessError停止。随后加入git ls-tree逐叶缺失检查，保留live真实差异，不将祖先等同当前叶。\n')
print(json.dumps({'report': result['report'], 'fixes': 0, 'existing_fixes': len(audit['existing_fixes']), 'tests': tests}, ensure_ascii=False))

import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/dw/Projects/agent-sts2')
WORK = ROOT / '.worktrees/codex-fix-silent-20261015-211145'
OUT = ROOT / 'learner/runs/20261015-211151-2f7c7a4e-e7f3-4eb6-8da1-8ab3627f4ee2-fix-batch'
PRIOR = ROOT / 'learner/runs/20261015-194306-bcf68a34-5915-46a0-a2ce-8d21b36a27e1-fix-batch'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'live').decode().strip()
prior_bytes = (PRIOR / 'audit.json').read_bytes()
prior = json.loads(prior_bytes)
queue = (ROOT / 'notes/fix-queue-v4.md').read_bytes()
(OUT / 'queue-snapshot.md').write_bytes(queue)
(OUT / 'queue-change.diff').write_text(''.join(difflib.unified_diff(
    (PRIOR / 'queue-snapshot.md').read_text().splitlines(True),
    queue.decode().splitlines(True), fromfile='previous-queue', tofile='current-queue')))
entries = []
for item in prior['existing_fixes']:
    commit, path = item['source_commit'], item['path']
    current = (WORK / path).read_bytes()
    entry = {
        'item': item['item'], 'source_commit': commit, 'path': path,
        'current_source_sha256': sha(current),
        'same_as_prior_audit': sha(current) == item['current_source_sha256'],
        'same_as_committed_base': current == git('show', f'{base}:{path}'),
        'ancestor_in_base': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, base]).returncode == 0,
        'ancestor_in_live_snapshot': subprocess.run(['git', '-C', str(WORK), 'merge-base', '--is-ancestor', commit, live]).returncode == 0,
    }
    entry['live_leaf_present'] = bool(git('ls-tree', live, '--', path))
    if entry['live_leaf_present']:
        live_bytes = git('show', f'{live}:{path}')
        entry['live_source_sha256'] = sha(live_bytes)
        entry['same_source_in_live'] = current == live_bytes
    assert all(entry[k] for k in ['same_as_prior_audit', 'same_as_committed_base', 'ancestor_in_base', 'ancestor_in_live_snapshot']), entry
    entries.append(entry)

dispositions = json.loads((PRIOR / 'queue-dispositions.json').read_bytes())
for item in dispositions:
    if item['line'] == 1294:
        item['disposition'] = '策略类/题面知识：技能药水生命周期措辞仍在，沿 silent-proposal-686d4e759478eebb；刀舞窄修复不覆盖本项'
        item.pop('commit', None)
        item['prior_scratch_inventory_correction'] = '前批报告正文已正确列为未修，但其附件误关联刀舞提交；本附件按当前源码更正，不回写历史'
    assert queue.decode().splitlines()[item['line'] - 1] == item['item']

prior_queue = (PRIOR / 'queue-snapshot.md').read_bytes()
assert queue.startswith(prior_queue)
queue_addition = queue[len(prior_queue):].decode()
assert not any(line.startswith('- [ ]') for line in queue_addition.splitlines())
changed = git('diff', '--name-only', prior['base'], base, '--', 'agent', 'learner', 'ops').decode().splitlines()
changed_code = [p for p in changed if Path(p).suffix in {'.ts', '.js', '.py', '.sh', '.json'}]
assert not changed_code, changed_code
audit = {
    'base': base, 'live_read_only_snapshot': live,
    'queue_sha256': sha(queue), 'queue_lines': len(queue.splitlines()),
    'queue_identical_to_prior': queue == prior_queue,
    'queue_appended_text': queue_addition,
    'prior_audit': str(PRIOR / 'audit.json'), 'prior_audit_sha256': sha(prior_bytes),
    'existing_fixes': entries,
    'unchecked_queue_entries': [{'line': n, 'item': line} for n, line in enumerate(queue.decode().splitlines(), 1) if line.startswith('- [ ]')],
    'changed_code_since_prior': changed_code,
    'no_new_source_changes': not git('diff', '--binary', 'HEAD'),
    'no_new_commits_since_merged_main': not git('rev-list', 'main..HEAD'),
    'limits': '既有来源提交和当前源码核验不将已发布窄子项当成宽父完成；未修改账本状态、队列或既有失败回执。',
}
(OUT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
(OUT / 'queue-dispositions.json').write_text(json.dumps(dispositions, ensure_ascii=False, indent=2) + '\n')
(OUT / 'source.diff').write_bytes(git('diff', '--binary', 'HEAD'))
(OUT / 'baseline-code-change.diff').write_bytes(git('diff', '--binary', prior['base'], base, '--', 'agent', 'learner', 'ops'))
print(json.dumps({'base': base, 'live': live, 'existing_fixes_verified': len(entries), 'unique_paths': len({e['path'] for e in entries}), 'unchecked_entries': len(audit['unchecked_queue_entries']), 'queue_identical': audit['queue_identical_to_prior'], 'queue_appended_lines': len(queue_addition.splitlines()), 'changed_code_since_prior': changed_code}, ensure_ascii=False))

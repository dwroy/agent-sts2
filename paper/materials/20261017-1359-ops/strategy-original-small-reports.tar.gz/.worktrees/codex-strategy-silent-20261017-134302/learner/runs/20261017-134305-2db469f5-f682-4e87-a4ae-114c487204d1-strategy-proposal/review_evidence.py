"""只读核验本批封套，准备有界离线消费者输入；不推导策略参数。"""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
TREE = OUT.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


dispatch = json.loads((OUT / 'dispatch.json').read_text())
runs = dispatch['runs']
verified_runs = json.loads((OUT / 'verified-runs.json').read_text())
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
streams = {}
checks = []
for entry in manifest:
    path = OUT / 'evidence' / (entry['stream'] + '.evidence.jsonl')
    digest = hashlib.sha256()
    rows = []
    counts = collections.Counter()
    handles = {}
    try:
        for raw in path.open('rb'):
            digest.update(raw)
            envelope = json.loads(raw)
            source = envelope['source']
            handle = handles.setdefault(source, open(source, 'rb')) if source not in handles else handles[source]
            handle.seek(envelope['offset'])
            original = handle.read(envelope['bytes'])
            assert hashlib.sha256(original).hexdigest() == envelope['sha256']
            assert json.loads(original) == envelope['row']
            row = envelope['row']
            identities = [row.get('run_id'), row.get('run')]
            state = row.get('state')
            if isinstance(state, dict):
                identities.append(state.get('run_id'))
            fingerprint = row.get('fingerprint')
            if isinstance(fingerprint, str):
                try:
                    fingerprint = json.loads(fingerprint)
                except ValueError:
                    fingerprint = None
            if isinstance(fingerprint, dict):
                identities.append(fingerprint.get('run'))
            identities = {v for v in identities if isinstance(v, str) and v and v != 'run_unknown'}
            assert identities == {envelope['run_id']} and envelope['run_id'] in runs
            counts[envelope['run_id']] += 1
            rows.append(envelope)
    finally:
        for handle in handles.values():
            handle.close()
    assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
    assert digest.hexdigest() == entry['output_sha256']
    streams[entry['stream']] = rows
    checks.append({'stream': entry['stream'], 'source_size': entry['source_size'], 'verified_rows': len(rows),
                   'counts': entry['counts'], 'output_sha256': digest.hexdigest()})
save('envelope-verification.json', checks)


def annotated(envelope):
    row = dict(envelope['row'])
    assert '_line' not in row and '_source_sha256' not in row
    row.update(_line=envelope['line'], _source_sha256=envelope['sha256'])
    return row


floors = {'751FN9QM9MHQ': [11, 13, 17], 'KV0JHNJCKXLS': [28, 29, 32, 33],
          'YQL8RZ8BWN1E': [17], 'L9SGRBB5R698': [17], 'PU80F84P6HPN': [17],
          'KEN58SH9SLZ6': [3, 4, 5, 11, 15, 17]}
consumers = []
for run in runs:
    decisions = [e for e in streams['decisions'] if e['run_id'] == run and e['row'].get('floor') in floors[run]]
    invalid = [e for e in decisions if not e['row'].get('decision_id')]
    # Preserve exclusions explicitly. Source row numbers retain any gaps across metadata.
    save(run + '.consumer-exclusions.json', invalid)
    source = {'run': verified_runs[run][-1], 'decisions': [annotated(e) for e in decisions if e not in invalid],
              'states': [annotated(e) for e in streams['states'] if e['run_id'] == run
                         and e['row']['state']['run']['floor'] in floors[run]]}
    input_path = OUT / (run + '.consumer-input.json')
    save(input_path.name, source)
    output_path, error_path = OUT / (run + '.consumer-output.json'), OUT / (run + '.consumer.err')
    with output_path.open('w') as stdout, error_path.open('w') as stderr:
        result = subprocess.run(['nice', '-n', '19', 'node', '--import', './agent/node_modules/tsx/dist/loader.mjs',
                                 'learner/audit-selection.ts', str(input_path)], cwd=TREE, stdout=stdout, stderr=stderr,
                                env=dict(os.environ, TMPDIR=str(OUT)))
    item = {'run': run, 'floors': floors[run], 'decisions': len(source['decisions']),
            'states': len(source['states']), 'excluded_metadata': len(invalid), 'exit_code': result.returncode,
            'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
            'output_sha256': hashlib.sha256(output_path.read_bytes()).hexdigest()}
    if result.returncode == 0:
        audit = json.loads(output_path.read_text())
        item.update(segments=len(audit['segments']), intervals=len(audit['observed_intervals']),
                    interval_reasons=dict(collections.Counter(r['reason'] for r in audit['observed_intervals'])),
                    turn_statuses=dict(collections.Counter(r['status'] for r in audit['observed_turns'])),
                    turn_reasons=dict(collections.Counter(r['reason'] for r in audit['observed_turns'] if r['reason'])),
                    full_candidate_certifications=sum(r['actual_full_candidate_result'] is not None for r in audit['segments']))
        observed_turns = [{k: r[k] for k in ['floor', 'turn', 'attempt', 'reloads', 'status', 'reason']} | {
            'decision_lines': [d['source_line'] for d in r['decisions']],
            'player_hp_delta': r['facts']['player_hp_delta'] if r['facts'] else None,
            'enemy_hp_changes': r['facts']['enemy_hp_changes'] if r['facts'] else None,
            'state_path_status': r['facts']['state_path_status'] if r['facts'] else None,
            'before': r['facts']['before'] if r['facts'] else None,
            'after': r['facts']['after'] if r['facts'] else None,
        } for r in audit['observed_turns']]
        save(run + '.turn-summary.json', observed_turns)
    consumers.append(item)
    save('consumer-results.json', consumers)
    print(json.dumps(item, ensure_ascii=False), flush=True)

attempts = []
for envelope in streams['sl-attempts']:
    r = envelope['row']
    attempts.append({'source_line': envelope['line'], 'source_sha256': envelope['sha256'],
                     **{k: r.get(k) for k in ['run_id', 'floor', 'attempt', 'result', 'turns', 'end_hp', 'started_at', 'ended_at']},
                     'anchor': (r.get('explore') or {}).get('anchor')})
save('attempt-summary.json', attempts)

targets = {272434, 272575, 272531, 272652, 272483, 272820, 272361, 272362,
           274087, 274131, 274156, 274185, 274235, 274237, 274267, 274272,
           274505, 274568, 274484, 274601, 274354}
save('target-decisions.json', [e for e in streams['decisions'] if e['line'] in targets])
save('review-summary.json', {'runs': runs, 'verified_envelopes': sum(c['verified_rows'] for c in checks),
                             'consumers': consumers, 'target_decisions': len([e for e in streams['decisions'] if e['line'] in targets])})

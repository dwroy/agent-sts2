"""读回根CLI追加原行，并核对本批完成契约。"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
pre = json.loads((OUT / 'ledger-pre-update.json').read_text())
post_all = ledger.fold(ledger.read_rows(str(ROOT / 'paper/materials/learning/ledger.jsonl')))
post = {key: post_all[key] for key in pre}
prefix = json.loads((OUT / 'ledger-prefix-before.json').read_text())
requests = [json.loads(line) for line in (OUT / 'ledger-update-input.jsonl').open()]
expected = copy.deepcopy(pre)
digest = hashlib.sha256()
prefix_rows = []
own = []
with open(prefix['source'], 'rb') as handle:
    remaining = prefix['source_size']
    while remaining:
        raw = handle.readline(remaining)
        assert raw and raw.endswith(b'\n')
        remaining -= len(raw)
        digest.update(raw)
        row = json.loads(raw)
        if row.get('id') in pre:
            prefix_rows.append((len(prefix_rows) + 1, row))
    assert digest.hexdigest() == prefix['sha256']
    assert ledger.fold(prefix_rows) == pre
    offset = prefix['source_size']
    for raw in handle:
        row = json.loads(raw)
        if row.get('by') == 'learner:strategy-proposal' and str(row.get('note', '')).startswith('20261017-134302-strategy-proposal逐项复核；'):
            request = next(r for r in requests if r['id'] == row['id'])
            assert all(row.get(key) == value for key, value in request.items())
            assert set(row) == set(request) | {'op', 'ts'}
            assert row['op'] == 'update'
            ledger.apply(expected, row)
            own.append({'id': row['id'], 'offset': offset, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest()})
        offset += len(raw)
assert len(own) == 16 and len({row['id'] for row in own}) == 16
# Fold appends notes/history for every trace update. Compare the full expected transition, including them.
assert expected == post
protected = ['claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'status', 'evidence',
             'version', 'shipped_at', 'effect', 'repeat_count', 'n_support', 'n_contradict']
checks = {}
for ident in pre:
    assert all(pre[ident].get(field) == post[ident].get(field) for field in protected)
    assert post[ident]['history'][:len(pre[ident]['history'])] == pre[ident]['history']
    assert post[ident]['notes'][:len(pre[ident]['notes'])] == pre[ident]['notes']
    links = post[ident].get('where', {}).get('proposal', [])
    assert str(OUT / 'proposal.md') in links and str(OUT / 'report.md') in links
    checks[ident] = {'protected_fields_unchanged': True, 'history_and_notes_prefix_preserved': True,
                     'full_fold_expected_update_matches': True, 'status': post[ident]['status']}
(OUT / 'ledger-readback.json').write_text(json.dumps({'prefix_preserved': True, 'protected_checks': checks,
                                                    'appended_rows': own}, ensure_ascii=False, indent=2) + '\n')
(OUT / 'ledger-after.json').write_text(json.dumps(post, ensure_ascii=False, indent=2) + '\n')

run_count = 0
for line in (OUT / 'evidence-runs/runs.evidence.jsonl').open():
    envelope = json.loads(line)
    with open(envelope['source'], 'rb') as handle:
        handle.seek(envelope['offset'])
        raw = handle.read(envelope['bytes'])
    assert hashlib.sha256(raw).hexdigest() == envelope['sha256'] and json.loads(raw) == envelope['row']
    assert envelope['row']['character'] == 'SILENT' and envelope['row']['ascension'] == 10
    run_count += 1
assert run_count == 6
result = json.loads((OUT / 'result.json').read_text())
dispatch = json.loads((OUT / 'dispatch.json').read_text())
current = json.loads((ROOT / 'ops/codex-ops/learn.json').read_text())['batches']['20261017-134302-strategy-proposal']
assert current['proposal_ids'] == dispatch['proposal_ids'] and current['runs'] == dispatch['runs']
assert current['worktree'] == str(OUT.parents[2])
assert 'research_request' not in current and 'implementation_request' not in current
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], text=True)
diff = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'])
assert not status and not diff and head == result['base']
assert {row['id'] for row in result['proposal_results']} == set(dispatch['proposal_ids'])
assert len(result['proposal_results']) == 10
assert all(row['state'] == 'waiting' and row['reason'] for row in result['proposal_results'])
assert result['tests'] == {'tsc': None, 'vitest': None, 'cases': None}
assert result['fixes'] == [] and result['merged'] is None and result['implementation_domains'] == []
for proposal in json.loads((OUT / 'selected-proposals.json').read_text()):
    assert hashlib.sha256(Path(proposal['proposal']).read_bytes()).hexdigest() == proposal['proposal_sha256']
material_checks = json.loads((OUT / 'material-checks.json').read_text())
assert len(material_checks) == 39 and all(row['passed'] for row in material_checks)
snapshot = json.loads((OUT / 'source-snapshot.json').read_text())
assert all(hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['physical_sha256']
           for row in snapshot['paths'])
validation = {'base': head, 'tracked_index_untracked_clean': not status, 'binary_diff_bytes': len(diff),
              'dispatch_still_bound': True, 'proposal_results': 10, 'ledger_cli_exit_code': 0,
              'ledger_protected_items': 16, 'ledger_prefix_preserved': True,
              'ledger_full_fold_replay_matches': True, 'runs_envelopes_verified': run_count,
              'material_checks': 39,
              'consumer_exit_codes': [row['exit_code'] for row in json.loads((OUT / 'consumer-results.json').read_text())],
              'source_leaves_unchanged': 20, 'new_source_commits': [], 'merged': None, 'tests': result['tests']}
(OUT / 'final-validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(validation, ensure_ascii=False))

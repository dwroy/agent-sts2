"""保存本批逐项处置及账本追溯请求，不产生游戏代码或新提案。"""
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
stamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'selected-proposals.json').read_text())
source = json.loads((OUT / 'source-snapshot.json').read_text())
reasons = [
    '751 F17 T2/T7/T13三组同指纹及端点已复核；已有候选、B2和持牌预测诊断，仍缺抽弃续问后的完整候选执行归属、逐来源实际结算及受控整战后继，不能拟合5/10血准入门槛。',
    '751 F13 T3用药和真正无药plan5的模型损血均8；plan3后续仍7/8用药。缺实际无药完整分支、留药后战对照及未决弃牌逐来源实际收益，不能将缺表成本0当持有价0或改变弃牌规则。',
    '与366288801d9150d9共享751同一局六试，不能新增独立样本；候选审计和单动作回执未认证完整执行，缺真实持牌成本归属、受控整战后继及独立后期验证。',
    '751敏捷、毒、荆棘及持牌失血局部端点可核，现有单项诊断不是联合逐来源实际校准；仍缺完整候选归属、无药及留药跨战对照，不能关闭整项或新增持有价。',
    'KV F33第4/5试T5原帧净扣36/29、同零净损、次轮毒20/13；严格消费者对T5整轮保持unknown。缺毛伤/回血逐来源完整归属、受控整战比较及路线休息替代后继，不能定探索或资源门槛。',
    '巨兽阶段和残壳毒药事实已有live诊断，旧原始占位血仍保留作参考路径平局排序；YQL毒2→8而血26/挡13/来袭41不变。缺改变排序、提前喝、不喝和留药的受控完整后继，PU胜线未隔离因素。',
    '与e18d3f18e6cac2a0共享巨兽三局；已有阶段提示不能证明阶段估值或参考路径排序收益。缺新旧排序和用药时点的受控整战比较，不能以PU过爆余2关闭宽提案。',
    'KEN七次用药请求及逐槽由有药变空的端点已核，三次随机药回执仍为pending；缺随机选牌/重问后的完整收益归属、同题未饮用和留至Boss对照，不能拟合持有价。',
    'KEN F17 T10换线多付6血仅多2实扣、T5省2血却使步法延至T9已复核；缺逐来源能力兑现、完整候选认证、受控整战后继和独立验证，保留现排序及HP护栏。',
    '与86a7db08d1a31976共享KEN同一局六试；只有局部配对和已有预测，缺完整执行归属、受控整战后继及独立后期验证，不能拟合6血/2伤固定门槛或关闭探索。',
]
evidence = [
    '751FN9QM9MHQ A10 F17：T2第1/3试；T7第2/4试；T13第1/6试。decisions 272434/272575、272531/272652、272483/272820。',
    '751FN9QM9MHQ A10 F13 T3：decisions 272361/272362；F17 T7/T13的未决弃牌边界。',
    '751FN9QM9MHQ A10 F17，同366288801d9150d9；同一局六试。',
    '751FN9QM9MHQ A10 F13 T3；F17 T3/T5/T7/T13/T17，机制各自分账。',
    'KV0JHNJCKXLS A10 F33 T5第4/5试，decisions 273400/273450/273451；states 279460—279465、279511—279515；末试T4 states 279559/279560。',
    'YQL8RZ8BWN1E A10 F17末试T10，decision 274087、states 280160/280161；L9SGRBB5R698 F17 T14及PU80F84P6HPN F17 T17原占位血锚点。',
    '巨兽三局同e18d3f18e6cac2a0；PU80F84P6HPN F17第5试T15实际胜余2。',
    'KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1/T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272及14个槽位前后原帧。',
    'KEN58SH9SLZ6 A10 F17 T10第4/5试274505/274568；T5第4/6试274484/274601；第2试T2护栏274354；末试T8/T9/T10/T12。',
    'KEN58SH9SLZ6 A10 F17，同86a7db08d1a31976；同一局六试。',
]
results = [{'id': p['id'], 'state': 'waiting', 'reason': reason} for p, reason in zip(proposals, reasons)]
assert [r['id'] for r in results] == dispatch['proposal_ids']
report = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261017-134302-strategy-proposal',
          'base': source['base'], 'runs': dispatch['runs'], 'fixes': [],
          'skipped': dispatch['proposal_ids'], 'merged': None,
          'tests': {'tsc': None, 'vitest': None, 'cases': None},
          'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
          'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

intro = f'''# 静默猎手策略队列逐项复核

记录时间：{stamp}。批次：20261017-134302-strategy-proposal。
本批为普通已领取队列，无 research_request、implementation_request、proposal_repair；根专题请求绑定另一批，不适用本批。
开工 tracked/index 干净，执行 git merge --no-edit main 返回 Already up to date；完整基线为 `{source['base']}`。
只消费 dispatch.json 内十个原ID，没有另领取、复制登记新ID或扩展其他角色研究。

结论：十项均 waiting。已存在的窄诊断不重新实现；未执行分支、完整候选收益及整战因果不足时保留现行策略。
本次不改源码、knowledge、规则、排序、参数或原提案，不产生提交、live合入、发布版本或shipped。
没有代码变更，源码撤销失败/恢复通过不适用；tsc/vitest/cases均为null。
离线消费者和材料核验另行报告，不能写成生产套件通过或策略收益验证。

## 证据边界

六个派发局均从 runs.jsonl 核为 SILENT/A10。所有对局在历史上均为失败；PU的F17第5试胜余2是房间结果，不是整局胜利。
每局多次SL属于一个独立局，不拆训练/验证，不与原经验的已有证据重复计数。本批没有拟合任何权重、血价、药价或SL门槛。
历史记录含dirty源码标记，未恢复当时完整dirty树；当前源码与实际live祖先核对只用于识别当前已有功能，不证明历史运行等于当前版本。
候选推演、接口回执、原帧净HP、逐来源因果、完整候选执行、受控整战胜负分别保留；缺失项不填零。

## 逐项处置
'''
sections = []
for p, reason, ev in zip(proposals, reasons, evidence):
    sections.append(f'''### {p['id']}

- 来源任务：{p['source_task']} → strategy-proposal；原件 `{p['proposal']}`。
- 原Markdown SHA256：`{p['proposal_sha256']}`；已逐字读回并保留 `{p['id']}.original.md`。
- 账本：{', '.join(p['ledger'])}。领域：{', '.join(p['domains'])}。
- 本批核对：{ev}
- 处置：waiting；{reason}
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。
''')
proposal_text = intro + '\n'.join(sections)
proposal_text += '''
## 反例、未知与结论变化

751 F17 T7多6实扣须多付10血，而T13省6血又少6实扣；KEN T10多2实扣多付6血，T5省2血却未建立当时步法。这些双向取舍排除仅按即时伤害或最少失血确定整战优劣。
751 F13真正整战无药参考是plan5；plan3只表示当轮不喝，其后7/8样本仍喝。两者均不是实际未饮用分支，缺表0不证明持有价值为0。
YQL残壳毒2→8不改变已显示41自爆或26血13挡；不推定更早饮用、留药或重排SL必胜。PU余2胜线同时改变其他动作与时点，不能作单因反事实。
KV第4/5试T5净扣36/29和下一轮20/13毒保留；严格消费者没有给这两轮完整端点认证，原帧局部比较不能填补整轮执行归属。
没有发现需要新增游戏规则的独立反证或与原账本结论相反的新事实；本次没有新增support/repeat/contradict，不重写旧经验或关闭量化父要求。
'''
(OUT / 'proposal.md').write_text(proposal_text)

checks = json.loads((OUT / 'envelope-verification.json').read_text())
audits = json.loads((OUT / 'consumer-results.json').read_text())
body = intro + '''
## 材料与消费者核验

原日志统一经 learner/extract_evidence.py 提取。各流先冻结source_size，封套保存source/line/offset/bytes/SHA256及显式run身份；本批又按原物理字节逐行读回全部封套并核SHA/JSON和身份一致。run-plans按run字段接收，不用正文提及归属；未覆盖全历史。
'''
body += '\n| 流 | 冻结source_size | 本批封套数 |\n|---|---:|---:|\n'
for c in checks:
    body += f"| {c['stream']} | {c['source_size']} | {c['verified_rows']} |\n"
body += f"\n合计{sum(c['verified_rows'] for c in checks)}个封套全部核回；额外runs流六条保留于evidence-runs。原提取stdout/stderr及manifest均保留，不覆盖旧截点报告。\n"
body += '''
离线消费者为当前基线learner/audit-selection.ts及其lib，只读本批固定JSON，不加载知识库、不调模型/网络/模拟器。输入保留真实原始_line和_source_sha256。按报告表中房间有界准备六份输入；两条缺decision_id的map/route-change元数据单独原样保留（KV decisions273191、KEN274207），未重编号或删除原封套。不是六局全部房间的消费者覆盖。

| 局号 | 层范围 | 输入决策 | 状态 | 片段 | 可核回合端点 | 退出码 |
|---|---|---:|---:|---:|---:|---:|
'''
for a in audits:
    body += f"| {a['run']} | {','.join(map(str,a['floors']))} | {a['decisions']} | {a['states']} | {a['segments']} | {a['turn_statuses'].get('observed_turn_endpoints',0)} | {a['exit_code']} |\n"
body += '''
六次消费者均exit0，575个选线片段、379个可核回合端点；所有actual_full_candidate_result仍为null，只表示工具未认证，不断言从未执行或完整执行。开场、跨尝试、缺行、非结束请求的跨轮等unknown保持原拒绝条件；KV T5保留该边界。
verify_materials.py对六组同指纹、14个回合端点、KV局部状态、巨兽残壳及七次槽位变化等完成39项材料检查，exit0；这不是生产测试、完整模型校准或新策略红绿。

## 关键数值读回

| 局号/层/回合 | 原端点 | 换线端点 | 限制 |
|---|---|---|---|
| 751 F17 T2 第1/3试 | 损13，敌净扣9 | 损18，敌净扣18 | 同指纹；不单归整战因果 |
| 751 F17 T7 第2/4试 | 损13，敌净扣12 | 损23，敌净扣18 | 原预测损19/29，各多计6；差额仍10 |
| 751 F17 T13 第1/6试 | 损8，敌净扣17 | 损2，敌净扣11 | 保血同时少输出 |
| KEN F17 T10 第4/5试 | 损15，敌净扣2 | 损21，敌净扣4 | B2 .385/.127、配对差−.2583/SE .0132仅模型 |
| KEN F17 T5 第4/6试 | 损7，敌净扣1、随后有2敏捷 | 损5，敌净扣2、随后无敏捷 | 末试T9才建立2敏捷；后继改变 |
| KV F33 T5 第4/5试 | 原帧玩家30→30，敌334→298，次轮毒20 | 玩家30→30，敌334→305，次轮毒13 | 严格整轮消费者unknown，保留原帧局部值 |
| YQL F17 末试T10毒药前/后 | 毒2，血26挡13，来袭41 | 毒8，血26挡13，来袭41 | 不记作减伤6或本体进度 |

七次KEN耗药原请求、槽位前后及随机药pending回执逐项见material-checks.json及target-decisions.json。末次异鱼死亡帧零HP不恢复未截断伤害。所有数字只覆盖上述实际证据，不外推其他角色或进阶。

## 当前已有源码与live祖先

source-snapshot.json冻结20个有关源码叶的基线、物理文件和live SHA及最近源码提交的祖先检查。live快照为 `'''+source['live']+'''`；20项最近源码提交均为该live祖先，16叶字节相同，4叶差异仅英文注释历史署名Roy/Dai（base-live-source.patch逐项保留）。只核这20叶，不据此认证整个live工作树、知识或旧dirty运行。

| 已有窄功能 | 本批核到的源码提交（实际live祖先） | 仍未覆盖的宽项 |
|---|---|---|
| 持牌保守预测 | 9d8278702dbc581b5015ba7ec9a70dc0fb94cccb | 实际逐来源完整候选收益 |
| 缺持有价与无药参考 | c4670f4f416c7d93e192e889c5080e7e4e0e733f | 实际无药/留药跨战对照 |
| SL资源比较 | 1698adc96ba434a46942321e0237b70657e625b2 | 受控整战后继与规则收益 |
| 单动作接口回执 | fdaf787a372880b0438e73bcac7e6d2168b038ed | 完整执行及归因 |
| 巨兽当前阶段和用药事实 | 40168f4a903ae1d8c48bd03006f8fea19fd3aa3c | 参考路径排序/用药时点受控验证 |
| 离线整轮观测 | e75438488df159b2e8e9d3458cf219b39aadd933 | 单卡因果、完整候选与模型校准 |

这些窄提交不是本批新增修复，也不能合称十个宽提案全部duplicate/implemented。enemyHpLeft仍明确读取原始显示HP作旧平局排序；本体/残壳分列不等于修改排序收益已经验证。当前代码将actual_turn/whole_plan_executed等留未知，不把未知填成新参数或胜率。

## 逐项处置、追溯与交付
'''
body += '\n'.join(sections)
body += '''
保留原账本状态（包括既有shipped），不追加相同support/repeat或改claim、首证、进阶、版本和effect。只经根learner/ledger.py update追加本报告/提案追溯；实际请求、退出码和保护字段读回见ledger-update-input.jsonl、ledger-update.out/.err、ledger-readback.json。没有新游戏经验，故不另建重复代码提案ID，不修改经验库；code_proposals沿用十个原CLI ID。

没有源码提交和待合入补丁，fixes=[]、merged=null、implementation_domains=[]；未进行源码撤销/恢复、tsc、vitest或live合后测试，不冒造成功/版本/shipped。工作树tracked/index和可见未跟踪保持干净，最终核验见final-validation.json。提案路径为本目录proposal.md，报告路径为本文件，最终机器回报为result.json。

过程探索中对不存在的候选文件名进行只读查询，已依据rg定位实际路径；未改生产文件。旧Markdown/原日志/封套/初稿、stdout/stderr和两个元数据排除记录均保留。没有新的科学异议或机制反证需要重复通知；原未知、宽父要求与现行策略保持。
'''
(OUT / 'report.md').write_text(body)

ledger = json.loads((OUT / 'ledger-before.json').read_text())
rows = []
for ident in sorted(ledger):
    linked = [p['id'] for p in proposals if ident in p['ledger']]
    rows.append({'id': ident, 'by': 'learner:strategy-proposal',
                 'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
                 'note': '20261017-134302-strategy-proposal逐项复核；'+','.join(linked)+
                 '均waiting。封套和有界消费者已核，完整候选收益/受控整战及留药后继不足；仅追溯，不增加证据或重复计数，不改状态/规则/版本。'})
(OUT / 'ledger-update-input.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows))
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal': str(OUT / 'proposal.md'),
                  'waiting': len(results), 'ledger_trace_rows': len(rows)}, ensure_ascii=False))

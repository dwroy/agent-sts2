"""核对已冻结材料中的具体数值；这是材料检查，不是生产测试。"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
checks = []


def check(name, actual, expected, refs=None):
    item = {'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected,
            'references': refs or []}
    checks.append(item)
    (OUT / 'material-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    assert item['passed'], name


decisions = {e['line']: e for e in json.loads((OUT / 'target-decisions.json').read_text())}
kv = json.loads((OUT / 'KV0JHNJCKXLS.consumer-input.json').read_text())
for row in kv['decisions']:
    if row['_line'] in (273400, 273450):
        decisions[row['_line']] = {'row': row}
for left, right in [(272434, 272575), (272531, 272652), (272483, 272820),
                    (274505, 274568), (274484, 274601), (273400, 273450)]:
    check(f'同题指纹 {left}/{right}', decisions[left]['row']['fingerprint'],
          decisions[right]['row']['fingerprint'], [left, right])

for run, values in {
    '751FN9QM9MHQ': [(1, 2, -13, -9), (3, 2, -18, -18), (2, 7, -13, -12),
                     (4, 7, -23, -18), (1, 13, -8, -17), (6, 13, -2, -11)],
    'KEN58SH9SLZ6': [(4, 10, -15, -2), (5, 10, -21, -4), (4, 5, -7, -1),
                     (6, 5, -5, -2), (6, 8, -2, -14), (6, 9, 0, -19),
                     (6, 10, -14, -1), (6, 12, -13, -7)],
}.items():
    rows = json.loads((OUT / (run + '.turn-summary.json')).read_text())
    for attempt, turn, hp, enemy in values:
        row = next(r for r in rows if r['floor'] == 17 and r['attempt'] == attempt and r['turn'] == turn)
        check(f'{run} 第{attempt}试 T{turn}端点',
              [row['status'], row['player_hp_delta'], row['enemy_hp_changes'][0]['hp_delta']],
              ['observed_turn_endpoints', hp, enemy], [row['before']['source_line'], row['after']['source_line']])

selected_lines = {279460, 279465, 279511, 279515, 279559, 279560, 280160, 280161,
                  280206, 280207, 280232, 280233, 280262, 280263, 280313, 280314,
                  280315, 280316, 280348, 280349, 280354, 280355}
states = {}
for line in (OUT / 'evidence/states.evidence.jsonl').open():
    envelope = json.loads(line)
    if envelope['line'] in selected_lines:
        states[envelope['line']] = envelope


def raw(line):
    return states[line]['row']['state']


def enemy(line):
    return raw(line)['combat']['enemies'][0]


def power(line, ident):
    return next(p['amount'] for p in enemy(line)['powers'] if p['power_id'] == ident)


check('KV第4试T5局部状态端点',
      [raw(279460)['combat']['player']['current_hp'], raw(279465)['combat']['player']['current_hp'],
       enemy(279460)['current_hp'], enemy(279465)['current_hp'], power(279465, 'POISON_POWER')],
      [30, 30, 334, 298, 20], [279460, 279465])
check('KV第5试T5局部状态端点',
      [raw(279511)['combat']['player']['current_hp'], raw(279515)['combat']['player']['current_hp'],
       enemy(279511)['current_hp'], enemy(279515)['current_hp'], power(279515, 'POISON_POWER')],
      [30, 30, 334, 305, 13], [279511, 279515])
check('KV末试T4结束前及T5开场',
      [enemy(279559)['current_hp'], power(279559, 'POISON_POWER'),
       enemy(279560)['current_hp'], power(279560, 'POISON_POWER')], [327, 15, 342, 14], [279559, 279560])
for line, poison in [(280160, 2), (280161, 8)]:
    state = raw(line)
    check(f'巨兽残壳原帧{line}',
          [state['run']['character_id'], state['run']['ascension'], state['turn'],
           state['combat']['player']['current_hp'], state['combat']['player']['block'],
           enemy(line)['enemy_id'], enemy(line)['max_hp'], enemy(line)['move_id'],
           enemy(line)['intents'][0]['damage'], power(line, 'POISON_POWER')],
          ['SILENT', 10, 10, 26, 13, 'WATERFALL_GIANT', 999999999, 'EXPLODE_MOVE', 41, poison], [line])

drinks = [(274131, 280206, 280207, 0, 'ATTACK_POTION'),
          (274156, 280232, 280233, 0, 'STABLE_SERUM'),
          (274185, 280262, 280263, 0, 'SPEED_POTION'),
          (274235, 280313, 280314, 1, 'WEAK_POTION'),
          (274237, 280315, 280316, 0, 'ATTACK_POTION'),
          (274267, 280348, 280349, 1, 'GLOWWATER_POTION'),
          (274272, 280354, 280355, 0, 'SKILL_POTION')]
for decision, before, after, slot, ident in drinks:
    a = next(p for p in raw(before)['run']['potions'] if p['index'] == slot)
    b = next(p for p in raw(after)['run']['potions'] if p['index'] == slot)
    check(f'KEN药槽端点{decision}',
          [decisions[decision]['row']['chosen']['action'], decisions[decision]['row']['chosen']['option_index'],
           a['potion_id'], a['occupied'], b['potion_id'], b['occupied']],
          ['use_potion', slot, ident, True, None, False], [decision, before, after])
check('KEN随机药回执仍为pending', [decisions[n]['row']['result'].startswith('pending')
                                  for n in [274131, 274237, 274272]], [True, True, True])

audits = json.loads((OUT / 'consumer-results.json').read_text())
check('六份离线消费者退出码', [r['exit_code'] for r in audits], [0] * 6)
check('有界候选片段数', sum(r['segments'] for r in audits), 575)
check('可核回合端点数', sum(r['turn_statuses'].get('observed_turn_endpoints', 0) for r in audits), 379)
check('缺decision_id的元数据逐行保留', sum(r['excluded_metadata'] for r in audits), 2)
check('不认证完整候选收益', sum(r['full_candidate_certifications'] for r in audits), 0)
check('二十源码叶最近提交均为live祖先',
      all(r['last_source_is_live_ancestor'] for r in json.loads((OUT / 'source-snapshot.json').read_text())['paths']), True)
print(json.dumps({'material_checks': len(checks), 'passed': True}, ensure_ascii=False))

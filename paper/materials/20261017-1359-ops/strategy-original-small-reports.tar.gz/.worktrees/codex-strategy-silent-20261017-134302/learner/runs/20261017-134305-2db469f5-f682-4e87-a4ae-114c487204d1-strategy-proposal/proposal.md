# 静默猎手策略队列逐项复核

记录时间：2026-10-17 13:53:16 CST。批次：20261017-134302-strategy-proposal。
本批为普通已领取队列，无 research_request、implementation_request、proposal_repair；根专题请求绑定另一批，不适用本批。
开工 tracked/index 干净，执行 git merge --no-edit main 返回 Already up to date；完整基线为 `5127c879e446c54b7d268f2cbcda199657fd548b`。
只消费 dispatch.json 内十个原ID，没有另领取、复制登记新ID或扩展其他角色研究。

结论：十项均 waiting。已存在的窄诊断不重新实现；未执行分支、完整候选收益及整战因果不足时保留现行策略。
本次不改源码、knowledge、规则、排序、参数或原提案，不产生提交、live合入、发布版本或shipped。
没有代码变更，源码撤销失败/恢复通过不适用；tsc/vitest/cases均为null。
离线消费者和材料核验另行报告，不能写成生产套件通过或策略收益验证。

## 证据边界

六个派发局均从 runs.jsonl 核为 SILENT/A10。所有对局在历史上均为失败；PU的F17第5试胜余2是房间结果，不是整局胜利。
每局多次SL属于一个独立局，不拆训练/验证，不与原经验的已有证据重复计数。本批没有拟合任何权重、血价、药价或SL门槛。
历史记录含dirty源码标记，未恢复当时完整dirty树；当前源码与实际live祖先核对只用于识别当前已有功能，不证明历史运行等于当前版本。
候选推演、接口回执、原帧净HP、逐来源因果、完整候选执行、受控整战胜负分别保留；缺失项不填零。

## 逐项处置
### silent-proposal-366288801d9150d9

- 来源任务：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-sl-cost.md`。
- 原Markdown SHA256：`0ba601d50f1341977ec60627d24994e0755ef1cf396a60832000400c5805c524`；已逐字读回并保留 `silent-proposal-366288801d9150d9.original.md`。
- 账本：silent-0079, silent-0176。领域：sl, combat。
- 本批核对：751FN9QM9MHQ A10 F17：T2第1/3试；T7第2/4试；T13第1/6试。decisions 272434/272575、272531/272652、272483/272820。
- 处置：waiting；751 F17 T2/T7/T13三组同指纹及端点已复核；已有候选、B2和持牌预测诊断，仍缺抽弃续问后的完整候选执行归属、逐来源实际结算及受控整战后继，不能拟合5/10血准入门槛。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-85929bdfc8a3fc1b

- 来源任务：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-191301-postmortem/proposal-combat-potion-facts.md`。
- 原Markdown SHA256：`d42d3f29d0d36b262352160a104dd8b97831ef9d8ecbbd4bce3dba367f9c8d68`；已逐字读回并保留 `silent-proposal-85929bdfc8a3fc1b.original.md`。
- 账本：silent-0019, silent-0021, silent-0005, silent-0007, silent-0129, silent-0176。领域：combat, potion。
- 本批核对：751FN9QM9MHQ A10 F13 T3：decisions 272361/272362；F17 T7/T13的未决弃牌边界。
- 处置：waiting；751 F13 T3用药和真正无药plan5的模型损血均8；plan3后续仍7/8用药。缺实际无药完整分支、留药后战对照及未决弃牌逐来源实际收益，不能将缺表成本0当持有价0或改变弃牌规则。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-efd9f83ee9e1a6dc

- 来源任务：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-sl-cost.md`。
- 原Markdown SHA256：`0065ae0291ac4675d0a895128c71c68b35602c3eb6b5887b92fca11891c29006`；已逐字读回并保留 `silent-proposal-efd9f83ee9e1a6dc.original.md`。
- 账本：silent-0079, silent-0176。领域：sl, combat。
- 本批核对：751FN9QM9MHQ A10 F17，同366288801d9150d9；同一局六试。
- 处置：waiting；与366288801d9150d9共享751同一局六试，不能新增独立样本；候选审计和单动作回执未认证完整执行，缺真实持牌成本归属、受控整战后继及独立后期验证。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-131042659448ae74

- 来源任务：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-193251-experience-update/proposal-combat-potion-facts.md`。
- 原Markdown SHA256：`b1ff1ca1e5d3da182f25af9b0040780e288a77e627b08c2fee262a17f8f49951`；已逐字读回并保留 `silent-proposal-131042659448ae74.original.md`。
- 账本：silent-0019, silent-0020, silent-0021, silent-0005, silent-0006, silent-0007, silent-0046, silent-0129, silent-0176。领域：combat, potion。
- 本批核对：751FN9QM9MHQ A10 F13 T3；F17 T3/T5/T7/T13/T17，机制各自分账。
- 处置：waiting；751敏捷、毒、荆棘及持牌失血局部端点可核，现有单项诊断不是联合逐来源实际校准；仍缺完整候选归属、无药及留药跨战对照，不能关闭整项或新增持有价。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-990f054036609447

- 来源任务：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-200255-experience-update/proposal-sl-accounting.md`。
- 原Markdown SHA256：`c7fa0a97eea334f338e208a6bae8e709dce021cd3157dd32cb3ca1a45900e053`；已逐字读回并保留 `silent-proposal-990f054036609447.original.md`。
- 账本：silent-0102, silent-0019, silent-0020。领域：combat, sl。
- 本批核对：KV0JHNJCKXLS A10 F33 T5第4/5试，decisions 273400/273450/273451；states 279460—279465、279511—279515；末试T4 states 279559/279560。
- 处置：waiting；KV F33第4/5试T5原帧净扣36/29、同零净损、次轮毒20/13；严格消费者对T5整轮保持unknown。缺毛伤/回血逐来源完整归属、受控整战比较及路线休息替代后继，不能定探索或资源门槛。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-e18d3f18e6cac2a0

- 来源任务：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-201301-postmortem/phase-sl-proposal.md`。
- 原Markdown SHA256：`3cc66ab0b4fb05a0d6d4e62b514b13caf9e157eba4d781f5a60f76276047c821`；已逐字读回并保留 `silent-proposal-e18d3f18e6cac2a0.original.md`。
- 账本：silent-0017, silent-0250, silent-0011, silent-0027, silent-0046。领域：combat, potion, sl, terminal。
- 本批核对：YQL8RZ8BWN1E A10 F17末试T10，decision 274087、states 280160/280161；L9SGRBB5R698 F17 T14及PU80F84P6HPN F17 T17原占位血锚点。
- 处置：waiting；巨兽阶段和残壳毒药事实已有live诊断，旧原始占位血仍保留作参考路径平局排序；YQL毒2→8而血26/挡13/来袭41不变。缺改变排序、提前喝、不喝和留药的受控完整后继，PU胜线未隔离因素。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-9733bb80f445aeae

- 来源任务：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-203654-experience-update/proposal-giant-phase.md`。
- 原Markdown SHA256：`c0da0af7803a73b361bb98e358c2a5c12b8056a68c28614a592138e7cdd88382`；已逐字读回并保留 `silent-proposal-9733bb80f445aeae.original.md`。
- 账本：silent-0017, silent-0019, silent-0020, silent-0250。领域：combat, potion, sl, terminal。
- 本批核对：巨兽三局同e18d3f18e6cac2a0；PU80F84P6HPN F17第5试T15实际胜余2。
- 处置：waiting；与e18d3f18e6cac2a0共享巨兽三局；已有阶段提示不能证明阶段估值或参考路径排序收益。缺新旧排序和用药时点的受控整战比较，不能以PU过爆余2关闭宽提案。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-c51468c5e8ba6668

- 来源任务：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-resources.md`。
- 原Markdown SHA256：`168cc03750525c56cace3915f22ef4dd1cf768f87b17e70f5228964a168c8469`；已逐字读回并保留 `silent-proposal-c51468c5e8ba6668.original.md`。
- 账本：silent-0019。领域：potion。
- 本批核对：KEN58SH9SLZ6 A10 F3T2/F4T1/F5T2/F11T1/T2/F15T1；decisions 274131/274156/274185/274235/274237/274267/274272及14个槽位前后原帧。
- 处置：waiting；KEN七次用药请求及逐槽由有药变空的端点已核，三次随机药回执仍为pending；缺随机选牌/重问后的完整收益归属、同题未饮用和留至Boss对照，不能拟合持有价。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-86a7db08d1a31976

- 来源任务：postmortem → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/learner/runs/20261007-204301-postmortem/proposal-combat-sl.md`。
- 原Markdown SHA256：`10de295b469f48281050aeb04a8ad6ccb2906e007d48386a6c8f769cc7600ac6`；已逐字读回并保留 `silent-proposal-86a7db08d1a31976.original.md`。
- 账本：silent-0079, silent-0021, silent-0125, silent-0005, silent-0176。领域：combat, sl。
- 本批核对：KEN58SH9SLZ6 A10 F17 T10第4/5试274505/274568；T5第4/6试274484/274601；第2试T2护栏274354；末试T8/T9/T10/T12。
- 处置：waiting；KEN F17 T10换线多付6血仅多2实扣、T5省2血却使步法延至T9已复核；缺逐来源能力兑现、完整候选认证、受控整战后继和独立验证，保留现排序及HP护栏。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

### silent-proposal-e282a9131b99129a

- 来源任务：experience-update → strategy-proposal；原件 `/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261007-214301-experience-update/proposal-sl-cost.md`。
- 原Markdown SHA256：`a88a2a95875b8fa04d80376a10a3ed59ede080db13ccb2a7e14c3ebfc1c34872`；已逐字读回并保留 `silent-proposal-e282a9131b99129a.original.md`。
- 账本：silent-0021, silent-0079, silent-0125, silent-0176。领域：combat, sl。
- 本批核对：KEN58SH9SLZ6 A10 F17，同86a7db08d1a31976；同一局六试。
- 处置：waiting；与86a7db08d1a31976共享KEN同一局六试；只有局部配对和已有预测，缺完整执行归属、受控整战后继及独立后期验证，不能拟合6血/2伤固定门槛或关闭探索。
- 旧行为保持：现行候选预测、HP护栏、SL探索与参考路径、药水持有价及必死判断不变。
- 可验证的后续：冻结同题原答/最终替线，保留全部选择与重问，核对逐来源结算与完整后继；规则收益需同角色独立局按时间留出验证。已有局部预测或相关SL次数不能替代。
- 预期与回退：本批只增加追溯材料，未宣称提高胜率；无新代码可回退，保留全部原件与未决项。

## 反例、未知与结论变化

751 F17 T7多6实扣须多付10血，而T13省6血又少6实扣；KEN T10多2实扣多付6血，T5省2血却未建立当时步法。这些双向取舍排除仅按即时伤害或最少失血确定整战优劣。
751 F13真正整战无药参考是plan5；plan3只表示当轮不喝，其后7/8样本仍喝。两者均不是实际未饮用分支，缺表0不证明持有价值为0。
YQL残壳毒2→8不改变已显示41自爆或26血13挡；不推定更早饮用、留药或重排SL必胜。PU余2胜线同时改变其他动作与时点，不能作单因反事实。
KV第4/5试T5净扣36/29和下一轮20/13毒保留；严格消费者没有给这两轮完整端点认证，原帧局部比较不能填补整轮执行归属。
没有发现需要新增游戏规则的独立反证或与原账本结论相反的新事实；本次没有新增support/repeat/contradict，不重写旧经验或关闭量化父要求。

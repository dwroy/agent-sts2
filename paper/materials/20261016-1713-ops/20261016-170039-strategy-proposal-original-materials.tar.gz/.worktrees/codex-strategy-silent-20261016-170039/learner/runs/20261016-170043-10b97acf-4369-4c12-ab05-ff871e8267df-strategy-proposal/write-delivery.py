from pathlib import Path
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())
source = json.loads((OUT / 'source-audit.json').read_text())
verified = json.loads((OUT / 'evidence-verification.json').read_text())
assert verified['all_verified'] and all(p['sha_matches'] for p in proposals)

rows = [
    ('366288801d9150d9', '751 F17同指纹血价已核；缺抽弃重问后的完整候选身份、逐来源结算及受控整战后继，不能拟SL血价门槛。',
     '751FN9QM9MHQ F17 T2/T7/T13；decisions272434/272575、272531/272652，states278479→278483、278620→278623、278576→278581、278697→278702、278528→278532、278865→278869。T2换线多9敌净损付5血；T7多6敌净损付10血；T13省6血同时少6敌净损。',
     '现有1698adc、a8b1f8b及选择/派发审计保留原/替线模型快照和单步回执，actual_turn、whole_plan_executed仍为空；explore.ts在非notWorseOnly且所有未试线更差时仍可探索。待补完整执行身份与结算，而非重复增加预测字段。',
     'T13有相反的省血少伤取舍；六次SL属于同一局且全败，不能固定5/10血门槛或断言原线必胜。',
     '按原/替线指纹逐段连抽牌、弃牌与重问，核真实手持惩罚、直伤/毒/荆棘及配对B2差；缺帧保留unknown。规则收益另需同条件完整后继和独立局验证。'),
    ('85929bdfc8a3fc1b', '已有保守持牌损血和持药未知/无药预测参照；缺751 F13无药整战、留药后战和完整执行收益对照。',
     '751FN9QM9MHQ F13 T3 decisions272361/272362；F17 T7/T13/T17及states278500—278505、278884—278888。F13有/无药均即时损8、五轮8/8胜，用药牌伤26/无药16；F17 T7实弃一呼唤后仍留一，全挡27仍损6。',
     '05cd292已展示保守持牌损血与弃牌未决；c4670f4已展示holdHp=null、成本0来源及同题无药参考。现行求解保守边界和药水排序保留，不能把null补成持有价值0。',
     '无药参考为模型抽样，并未实打无药整战或留药Boss；不能从空药栏失败倒推这次饮用错误，或从未决弃牌的绝对误差推换线差额错误。',
     '冻结F13题与执行后的槽位/力量/出牌，另需无药完整分支及留药后战；F17弃牌前后逐帧核手持项。仅提示不拟合权重；价值规则需时间留出独立局。'),
    ('efd9f83ee9e1a6dc', '与原复盘共用751六试无胜线证据；缺同条件完整后继及独立局验证，不能用局部成本禁止探索。',
     '751FN9QM9MHQ F17 T2/T7/T13；与366288801d9150d9共用原始证据，非第二独立样本。T7原/替题面保守各多计6血，实损13/23差10仍成立。',
     '现有资源比较只属current_turn_prediction，execution=unverified；需要原线、最终替换、续问的完整结算归属。规则仍保留失败原线下的未试线探索。',
     '同一局六试均败，不能用相关尝试拟合通用血价或将较低B2胜率等同真实反事实死亡。T13同时少伤少失血，反对单指标判断。',
     '沿原0176/0079账本和366288801d9150d9链补完整实盘/重放归属，不重复登记新id或把经验提案当新支持局。独立验证不得把同局SL拆入训练和留出集。'),
    ('131042659448ae74', '751分项机制已有窄实现；缺联合逐来源实结算、完整候选执行和跨战留药对照。',
     '751FN9QM9MHQ F13 T3、F17 T3/T5/T7/T13/T17；F17普通步法建立2敏捷；T5无实体下攻击/毒/荆棘各只1；末T17毒3+反伤3使敌28→22，玩家仍死。',
     '已有held_loss_prediction、potion_value_reference、SL预测比较和单步回执；这些不提供联合逐来源已兑现累计。需要分别核实际出牌、毒结算、反伤、未决弃牌和药水效果，当前不添加联合规则。',
     '敏捷已建立但无格挡牌时没有挡量兑现；毒层不等于已扣血。原经验的各子机制支持分母不同，不能合并成统一样本或把本批再次核验当新增support。',
     '以F13/F17固定帧核每一来源和完整候选归属，再核跨战留药。其余进阶及其他角色保持等价，缺来源字段不以模型预测填实盘账。'),
    ('990f054036609447', 'KV F33T5零净损、敌净扣36/29端点已核；缺毛伤回血归属、完整候选认证及路线休息替代后继。',
     'KV0JHNJCKXLS F33第4/5试T5 decisions273400/273450同指纹，states279460→279465与279511→279515，30血均不变、敌334→298/305。F28休37→58、F29入58出23、F32休23→44另开场补2。',
     '现有审计列候选预测与端点，严格整轮消费者仍unknown；SL去掉毒药后还阻止补打，不能把直接端点差归单卡因果。需要敌回血与毛伤逐来源，路线只记实际回复。',
     '多7敌净损没有伴随当轮保血差；二线都T10判死而后轮动作不同。未走的路线与休息替代收益未知，不能据此改变探索/路线门槛。',
     '核同指纹T5全部续问、选择及敌回合，分毛伤、回血、毒层和实际净扣；休息与SL恢复分开。新规则需完整可重放后继及时间更晚独立局。'),
    ('e18d3f18e6cac2a0', '巨兽阶段和毒水局部事实已实现；参考排序仍用原始占位HP，缺新旧改序完整后继和受控药水分支。',
     'YQL8RZ8BWN1E F17六试本体T12/12/11/12/12/9结束；末T10 states280160→280161毒2→8，HP26/挡13/来袭41不变，280162实死。L9SGRBB5R698 F17 sl-attempts681及PU80F84P6HPN F17 sl-attempts717的anchor仍含近十亿占位血；YQL sl-attempts960同样。',
     'a83d9ab已有本体0/自爆待结算诊断，d5e20aa已有毒水实盘限制，0d092f6有另一个窄末态预算，均为实际live祖先；enemyHpLeft/anchorRank保留原始HP同轮排序。原始日志、body_hp与未胜阶段不能互相改写。',
     '将占位血直接统一为0会改变同轮参考路径；原提案指出可能选到自爆缺口更大线，非纯显示改动。PU第5试余2血胜，不允许把占位阶段统一标必死。',
     '当前已实现的提示无需重写。若改排序，必须保存原/新选中的完整后继、本体结束时点、实际自爆、净HP和药水；未知summary与非本角色保持等价。'),
    ('9733bb80f445aeae', 'YQL末轮毒2→8而血挡/41来袭不变，PU余2血胜反例保留；缺提前喝、不喝、留药及改序对照。',
     'YQL8RZ8BWN1E F17末T10同上述280160/280161；26+13−41=−2为未截断预计剩血，实死帧HP0。PU80F84P6HPN F17第5试T15胜余2；L9/PU/YQL的旧占位HP参考同e18d3f18e6cac2a0。',
     '已区分本体、自爆和残壳施毒局部事实；本体结束不等于获胜。未来药水/SL估值还需完整收益，当前保留合法药水选项、原排名与持有价。',
     '一次残壳饮毒无即时血挡收益不能推广为提前喝/不喝/留药更好；PU胜线也不是新排序的受控证明。−2不是只损2血或必须补2血可活的通用规则。',
     '核药水前后同一帧、固定自爆与实际净血；新旧完整分支分别验证，SL恢复不计实际回血。不据相关六试拟合参数。'),
    ('c51468c5e8ba6668', 'KEN七次用药都有槽位消失后帧，三次接口pending保留；缺随机选牌、重问后完整收益及留药Boss对照。',
     'KEN58SH9SLZ6 F3T2/F4T1/F5T2/F11T1/F11T2/F15T1；decisions274131/274156/274185/274235/274237/274267/274272；对应states280206→280207、280232→280233、280262→280263、280313→280314、280315→280316、280348→280349、280354→280355。',
     '七次饮用动作的槽位消失可核，攻击药两次与技能药共三次回执pending，不能改写completed。现有预测/单步审计不证明随机药选牌、发光水重问后的完整方案收益。保持药水持有价和饮用规则。',
     'F15零净损同时耗尽两瓶不证明无药也零损；六次F17 75/86空药栏，不证明留任一瓶便能赢。未用分支没有实盘。',
     '冻结七组槽位/HP/增益/牌与全部续问，对照选项到实际动作及实际结算；药水价值需要同入口未用/保留到Boss完整分支及后期独立局，不用同局六试拟合。'),
    ('86a7db08d1a31976', 'KEN T10多2敌净损付6血，T5省2血同时延迟能力；缺逐来源完整兑现、相同后轮及独立验证。',
     'KEN58SH9SLZ6 F17第4/5试T10 decisions274505/274568同指纹，states280588→280592为失15/敌净损2，280651→280655为失21/敌净损4；第4/6试T5 decisions274484/274601同指纹，states280567→280572为失7/敌净损1，280684→280689为失5/敌净损2。',
     '现有SL资源拆项与B2比较为预测，并不认证整线。无实体下新增两段各1的实际端点与呼唤血价分开，能力建立晚不能倒填已有挡。探索规则暂保留。',
     '末试省血T5同时步法延至T9，并有追加小刀续问；反对只按最少损血排名。原/替后轮动作不同，T15/T13判死时点差不能单归T10。',
     '逐段连原/替T10和T5的选择、持牌、能力与后轮；固定再核T6留呼唤、T10攻击加自损、T12清空与T13实死。无同条件完整对照不拟6血/2伤准入门槛。'),
    ('e282a9131b99129a', 'KEN同指纹双向取舍和既有预测拆项已核；缺完整候选认证及受控后继，不拟通用6血/2伤门槛。',
     'KEN58SH9SLZ6 F17 T10/T5同86a7db08d1a31976原帧；末试T8/T9开头敏捷0，T10开头已2（states280697/280701/280705）；T2原迷雾护栏替换没有完整原线实打。',
     '资源比较、候选预测、单步派发和离线端点消费者已有窄实现；完整候选结果仍null。需连续问、无实体实伤、呼唤失血和能力窗口，保持原探索与HP护栏。',
     '不把经验更新与复盘的同源证据计两局；无完整原T2/后轮分支，不认定HP护栏纯bug或更改后必胜。更少失血和更多当轮输出都不是单独胜利证明。',
     '共用KEN固定验证而不重复跑未变消费者；规则验证需更早独立局调参和更晚留出局，完整反事实不足则继续waiting。'),
]
assert [p['add']['id'] for p in proposals] == ['silent-proposal-' + row[0] for row in rows]

proposal = [
    '# 静默猎手十项策略提案逐项核验',
    '',
    '本批只消费20261016-170039-strategy-proposal的十个原CLI提案id；六局均核为Silent A10。无research_request、implementation_request或proposal_repair；普通专题请求属于其他批次，不承接。初始工作树干净，git merge --no-edit main为Already up to date。',
    '',
    '完整base：`' + source['base'] + '`；核验live快照：`' + source['live_snapshot'] + '`。十原Markdown实际SHA均匹配队列，原文副本为本目录各id.original.md，原路径/SHA见dispatched-proposals.json。全部waiting，不新建id、不改提案原文、不登记implemented/shipped。',
    '',
    '证据由共用extract_evidence.py读取显式身份并拒收冲突；八流各自冻结source_size、原行offset/bytes/SHA和计数。8,444行逐字节复核及30项事实检查通过；七非空流选中封套与前批完全相同。fight-plans在2233957字节截点选到0行，只说明该截点未选到，不称原日志不存在。全流无效行states2/decisions2/brain1未获本批归属，保持未知。',
    '',
    '本批依据：原证据、原提案、原账本、本角色12条关联经验和源码。当前经验库中其他局及原提案引用的历史统计只作背景，未把未重新核的支持数或整战因果作为本批结论。未读取其他角色知识、游戏二进制或联网。',
]

for p, row in zip(proposals, rows):
    suffix, reason, evidence, behavior, counterexample, validation = row
    item = p['add']
    proposal.extend([
        '', '## ' + item['id'], '',
        '处置：**waiting**。' + reason, '',
        '来源任务：' + item['source_task'] + '；本次实现任务：strategy-proposal；已观察范围：silent/A10；领域：' + '、'.join(item['domains']) + '。账本：' + '、'.join(item['ledger']) + '。', '',
        '证据局/层/回合：' + evidence, '',
        '既有行为及待实现边界：' + behavior, '',
        '反例与限制：' + counterexample, '',
        '预期行为与验证：' + validation,
    ])

proposal.extend([
    '', '## 共同验证、拟合及回退边界', '',
    '不拟合新参数。六局作为已观察冻结核验输入；同局各SL尝试留在同一分组。后续若有充分数据拟合，先登记更早同角色独立局/开始时间切点作训练，再用更晚独立局留出验证；不得同时用本批调阈值并报告泛化胜率。', '',
    '实际消费者读回：核旧六份输入/输出SHA、逐输入行对应本批原日志、六个消费者源文件逐字节一致，复用原结果，未重跑消费者或模拟。861题段、4065动作、415可核整轮、362未知窗口，完整候选结果未认证；六条无decision_id的非战斗改线记录只从战斗消费者排除，完整原证据保留。工具unknown不等于实盘未执行。旧失败/修正/初稿留在原目录，不以原成功码冒本批生产测试。', '',
    '21个相关源码叶与前160244基线相同；17个与实际live相同，另4个仅历史Roy/Dai注释署名不同，原patch保留。七个窄实现源码commit实际为base/live祖先，见source-audit.json。祖先关系只证明上述窄功能，不关闭宽提案或量化/学习入库父要求。', '',
    '预期影响：只提升本批追溯与缺口说明，尚无新策略收益结论。无源码/知识/模板改动，无撤源码失败/恢复试验、tsc、vitest或生产case；tests三个字段均null。没有源码提交、live合入、版本或规则通知；无合入受阻。原角色行为等价。', '',
    '回退：本批无生产改动可回退。未来实际实现必须独立提交、固定场景验证及沙箱自测/live核验后登记；保留所有原数据和历史，不以回退清掉失败。现有Roy授权不需重新审批，但也不提供缺失的游戏证据。', '',
    '本批没有新增机制反证或与旧经验冲突；已有双向取舍和未知明确保留。将本报告和proposal.md交原运维链；没有用工具向其他人发送消息，没有代watcher/Roy确认。',
])
(OUT / 'proposal.md').write_text('\n'.join(proposal) + '\n')

proposal_results = [{'id': 'silent-proposal-' + row[0], 'state': 'waiting', 'reason': row[1]} for row in rows]
result = {
    'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261016-170039-strategy-proposal',
    'base': source['base'], 'runs': dispatch['runs'], 'fixes': [], 'skipped': [], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': [],
    'proposal_results': proposal_results, 'report': str(OUT / 'report.md'),
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

report = [
    '# 策略提案核验回报', '',
    '十项派发原提案全部waiting。六局原证据和现有源码已逐项核验；缺完整执行归属、逐来源结算或受控后继，证据不足以改变SL排序/准入、药水持有价或终局规则。具体证据、反例、预期行为和验证方法见[proposal.md](proposal.md)。', '',
    '- 批次：20261016-170039-strategy-proposal；角色silent，六来源局均A10。',
    '- 完整base：`' + source['base'] + '`；初始git status干净，合main为Already up to date。',
    '- 实核live快照：`' + source['live_snapshot'] + '`；无新提交、合入、版本或shipped，无合入受阻。',
    '- 原十Markdown SHA均匹配；未领取其他队列项、未修改根请求或提案原文。', '',
    '## 证据与现有实现', '',
    '共用入口提取states4167、decisions4071、sl-attempts43、run-config6、run-plans21、brain130、runs6，另fight-plans在2233957字节截点0行。8,444行原offset/bytes/SHA、JSON、显式身份、角色/进阶及计数复核通过；30项固定事实检查通过。每流独立截点/无效行/输出SHA见evidence/evidence-manifest.json，逐项核验见evidence-verification.json。0行不证明原日志不存在，全流无效行不归本批。', '',
    '七非空流选中字节与前批完全一致。核旧六份消费者输入/输出SHA及六个关联源文件相同，并将输入逐行绑定本批原字节后复用旧结果，未重跑消费者或模拟。历史861题段/4065动作/415可核整轮/362未知窗口，完整候选仍未认证；六条非战斗缺decision_id排除及旧失败原件保留。旧成功码不冒本批生产测试或策略收益。', '',
    '21个相关源码叶与前160244基线相同；17个和live相同，4个只有历史Roy/Dai注释差（base-live.patch）。持牌失血05cd292、持药未知c4670f4、候选/派发a8b1f8b、SL资源比较1698adc、巨兽阶段a83d9ab、毒水事实d5e20aa和窄末态0d092f6均核为base/live实际祖先，完整40位见source-audit.json。现有actual_turn/whole_plan_executed或完整来源仍未认证；anchorRank仍按原始占位HP作同轮排序。窄覆盖不等于宽提案完成，直接占位归零会改变路径，需完整受控后继。', '',
    '## 本角色观察与限制', '',
    '- 751 F17T2多9敌净损付5血、T7多6敌净损付10血；T13省6血同时少6敌净损。六试相关且全败，不拟固定门槛。F13有/无药抽样不能代无药实盘或留药后战。',
    '- KV F33T5同指纹30血不变、敌334→298/305，仍含续问及阻止补打；端点净扣不认证毛伤、回血归属或单步因果。路线/休息只记实际资源，替代后继未知。',
    '- YQL F17T10毒2→8，HP26/挡13/来袭41不变，之后实死。−2是未截断预计剩血；PU F17第5试T15胜余2反例保留。不能把残壳毒、占位血或本体结束当存活收益。',
    '- KEN F17T10多6自身失血只多2敌净损；T5省2血同时步法延迟，并有追加小刀重问。七次饮药槽位消失均核，三次回执pending不改completed；随机选牌、完整收益与留药Boss反事实缺失。', '',
    '## 逐项处置', '',
]
for p, item in zip(proposals, proposal_results):
    report.append('- `' + item['id'] + '`：waiting；账本' + '、'.join(p['add']['ledger']) + '。' + item['reason'])
report.extend([
    '', '## 验证与记录', '',
    '无生产源码、知识、验证输入或任务模板修改；没有撤源码/恢复试验、tsc、vitest、生产case或沙箱套件，tests固定为null/null/null。证据检查及旧消费者读回不计生产case。无提交所以没有提交前gitleaks或新增Co-Authored-By；未运行play、联网、安装依赖、推送或改其他角色行为。', '',
    '账本追溯只经根learner/ledger.py update追加既有16项的proposal/report/note，by=learner:strategy-proposal；不追加重复support、重复发现或新提案id，不改claim、首证、prior、evidence、status或version，已有shipped不降为proposed。CLI实际结果及物理前缀/受保护字段核验以ledger-cli-receipt.json为准。', '',
    '本批没有新规则上线，不制造decision-log上线记录、eval版本或Roy双通知；没有新增机制异议，原反向取舍与未知均明确保存。父学习入库/量化请求不因本报告关闭，未宣称经验新入库或大脑已采用。运维交付提案路径：`' + str(OUT / 'proposal.md') + '`。', '',
    '初次只读身份脚本白名单遗漏大写SILENT的断言错误留存identity-first-check-error.txt，已按lower()==silent核六局；若干不存在源码名的只读探针后用rg定位实际文件，不认产品错误。抽取与核验退出码见completion-verification.json；tracked/index最终干净，HEAD保持base。机器回报见result.json。',
])
(OUT / 'report.md').write_text('\n'.join(report) + '\n')
print(json.dumps({'proposal': str(OUT / 'proposal.md'), 'report': str(OUT / 'report.md'), 'proposal_results': len(proposal_results)}, ensure_ascii=False))

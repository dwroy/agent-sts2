from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('ledger', ROOT / 'learner/ledger.py')
ledger = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ledger)
proposals = json.loads((OUT / 'dispatched-proposals.json').read_text())
results = {r['id']: r for r in json.loads((OUT / 'result.json').read_text())['proposal_results']}
by_ledger = {}
for p in proposals:
    for id in p['add']['ledger']:
        by_ledger.setdefault(id, []).append(p['add']['id'])

updates = []
for id, proposal_ids in sorted(by_ledger.items()):
    updates.append({
        'id': id, 'by': 'learner:strategy-proposal',
        'where': {'proposal': [str(OUT / 'proposal.md') + '#' + p for p in proposal_ids] + [str(OUT / 'report.md')]},
        'note': '20261016-170039-strategy-proposal独立核验：原提案SHA、六局8444原行/30事实及21关联源码叶已核；七窄实现为实际live祖先。' +
                '；'.join(p + ' waiting：' + results[p]['reason'] for p in proposal_ids) +
                '。仅追加本批追溯，未新增证据support/规则/源码/合入/版本；已有claim/首证/prior/evidence/status/version保持。',
    })
assert len(updates) == 16 and all(set(row) == {'id', 'by', 'where', 'note'} for row in updates)
input_path = OUT / 'ledger-updates.jsonl'
input_path.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in updates))
path = ROOT / 'paper/materials/learning/ledger.jsonl'
before = path.read_bytes()
before_items = ledger.fold(ledger.read_rows(str(path)))
assert all(before_items[id]['character'] == 'silent' for id in by_ledger)
protected = ['character', 'kind', 'claim', 'first_run', 'asc', 'prior', 'prior_note', 'prior_runs', 'evidence', 'status', 'version', 'effect']
semantic_before = {id: {k: before_items[id].get(k) for k in protected} for id in by_ledger}
(OUT / 'ledger-semantic-before.json').write_text(json.dumps(semantic_before, ensure_ascii=False, indent=2) + '\n')
date = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
process = subprocess.run(['python3', str(ROOT / 'learner/ledger.py'), 'update'], input=input_path.read_bytes(), capture_output=True)
(OUT / 'ledger-cli.stdout.txt').write_bytes(process.stdout)
(OUT / 'ledger-cli.stderr.txt').write_bytes(process.stderr)
assert process.returncode == 0, (process.returncode, 'see ledger-cli.stderr.txt')
after = path.read_bytes()
h = lambda raw: hashlib.sha256(raw).hexdigest()
assert after[:len(before)] == before
after_items = ledger.fold(ledger.read_rows(str(path)))
semantic_after = {id: {k: after_items[id].get(k) for k in protected} for id in by_ledger}
assert semantic_before == semantic_after
new_rows, offset = [], len(before)
for raw in after[len(before):].splitlines(keepends=True):
    row = json.loads(raw)
    if row.get('by') == 'learner:strategy-proposal' and str(OUT / 'report.md') in row.get('where', {}).get('proposal', []):
        expected = next(r for r in updates if r['id'] == row['id'])
        assert {k: v for k, v in row.items() if k not in ['op', 'ts']} == expected and row['op'] == 'update'
        new_rows.append({'offset': offset, 'bytes': len(raw), 'sha256': h(raw), 'row': row})
    offset += len(raw)
assert len(new_rows) == len(updates) and {row['row']['id'] for row in new_rows} == set(by_ledger)
receipt = {
    'date_before_cli': date, 'command': ['python3', str(ROOT / 'learner/ledger.py'), 'update'], 'exit_code': process.returncode,
    'input': str(input_path), 'input_sha256': h(input_path.read_bytes()), 'stdout_sha256': h(process.stdout), 'stderr_sha256': h(process.stderr),
    'before_bytes': len(before), 'before_sha256': h(before), 'after_bytes': len(after), 'old_physical_prefix_preserved': True,
    'protected_fields_unchanged': protected, 'only_where_note_appended': True, 'rows': new_rows,
}
(OUT / 'ledger-cli-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': process.returncode, 'appended': len(new_rows), 'old_prefix_preserved': True, 'protected_fields_unchanged': True}, ensure_ascii=False))

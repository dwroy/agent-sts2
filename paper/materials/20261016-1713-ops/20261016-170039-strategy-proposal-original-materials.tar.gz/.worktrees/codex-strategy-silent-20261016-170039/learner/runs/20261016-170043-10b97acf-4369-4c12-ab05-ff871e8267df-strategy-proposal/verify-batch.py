import collections
import hashlib
import json
from pathlib import Path
import runpy
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/dw/Projects/agent-sts2')
PREVIOUS = ROOT / '.worktrees/codex-strategy-silent-20261016-160244/learner/runs/20261016-160247-99a1eb33-debd-434e-ad04-6e0d108cc4d8-strategy-proposal'
CONSUMERS = ROOT / '.worktrees/codex-strategy-silent-20261016-140405/learner/runs/20261016-140409-754d630c-9f35-48d6-94ca-60975d9aaf5b-strategy-proposal'
identity = runpy.run_path(str(Path.cwd() / 'learner/extract_evidence.py'))['run_identity']
runs = json.loads((OUT / 'dispatch.json').read_text())['runs']
digest = lambda raw: hashlib.sha256(raw).hexdigest()
canonical = lambda obj: digest(json.dumps(obj, ensure_ascii=False, sort_keys=True).encode())
old_manifests = {}
for directory in ['evidence', 'evidence-runs']:
    for entry in json.loads((PREVIOUS / directory / 'evidence-manifest.json').read_text()):
        old_manifests[entry['stream']] = entry
indexes, states, decisions, attempts, stream_checks = {}, {}, {}, [], []

for entry in json.loads((OUT / 'evidence/evidence-manifest.json').read_text()):
    stream = entry['stream']
    path = OUT / 'evidence' / (stream + '.evidence.jsonl')
    assert digest(path.read_bytes()) == entry['output_sha256']
    counts, index = collections.Counter(), {}
    with (ROOT / 'logs' / (stream + '.jsonl')).open('rb') as source:
        for line in path.open():
            item = json.loads(line)
            run, row = item['run_id'], item['row']
            assert run in runs and identity(row) == run
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert raw.endswith(b'\n') and digest(raw) == item['sha256'] and json.loads(raw) == row
            assert item['offset'] + item['bytes'] <= entry['source_size']
            assert item['line'] not in index
            counts[run] += 1
            index[item['line']] = (run, canonical(row))
            if stream == 'states':
                state = row['state']
                assert state['run']['character_id'].lower() == 'silent' and state['run']['ascension'] == 10
                combat = state.get('combat') or {}
                player = combat.get('player') or {}
                states[item['line']] = {
                    'run': run, 'floor': state['run']['floor'], 'turn': state.get('turn'), 'screen': state.get('screen'),
                    'hp': player.get('current_hp', state['run'].get('current_hp')), 'block': player.get('block'),
                    'potions': state['run'].get('potions'), 'powers': player.get('powers'),
                    'enemies': combat.get('enemies', []),
                }
            elif stream == 'decisions':
                decisions[item['line']] = row
            elif stream == 'sl-attempts':
                attempts.append({'line': item['line'], 'row': row})
    assert dict(counts) == {k: v for k, v in entry['counts'].items() if v}
    same = entry['output_sha256'] == old_manifests[stream]['output_sha256'] if stream in old_manifests else None
    if same is not None:
        assert same
    indexes[stream] = index
    stream_checks.append({**entry, 'verified_rows': sum(counts.values()), 'same_selected_bytes_as_previous': same})

facts = []
for a, b in [(272434, 272575), (272531, 272652), (273400, 273450), (274505, 274568), (274484, 274601)]:
    assert decisions[a]['fingerprint'] == decisions[b]['fingerprint']
    facts.append({'kind': 'same_fingerprint', 'run': decisions[a]['run_id'], 'floor': decisions[a]['floor'],
                  'turn': decisions[a]['turn'], 'decision_lines': [a, b], 'sl': decisions[b].get('sl_explore')})

for a, b, loss, damage in [(278479, 278483, 13, 9), (278620, 278623, 18, 18),
        (278576, 278581, 13, 12), (278697, 278702, 23, 18),
        (278528, 278532, 8, 17), (278865, 278869, 2, 11),
        (280588, 280592, 15, 2), (280651, 280655, 21, 4),
        (280567, 280572, 7, 1), (280684, 280689, 5, 2),
        (279460, 279465, 0, 36), (279511, 279515, 0, 29)]:
    before, after = states[a], states[b]
    assert before['run'] == after['run'] and before['floor'] == after['floor'] and after['turn'] == before['turn'] + 1
    assert before['hp'] - after['hp'] == loss
    assert before['enemies'][0]['current_hp'] - after['enemies'][0]['current_hp'] == damage
    facts.append({'kind': 'observed_endpoints', 'run': before['run'], 'floor': before['floor'], 'turn': before['turn'],
                  'state_lines': [a, b], 'player_net_hp_loss': loss, 'enemy_net_hp_loss': damage,
                  'scope': '本轮全部实际动作及结算的端点差，不认证单卡或完整候选因果'})

for decision, a, b, potion in [(274131, 280206, 280207, 'ATTACK_POTION'), (274156, 280232, 280233, 'STABLE_SERUM'),
        (274185, 280262, 280263, 'SPEED_POTION'), (274235, 280313, 280314, 'WEAK_POTION'),
        (274237, 280315, 280316, 'ATTACK_POTION'), (274267, 280348, 280349, 'GLOWWATER_POTION'),
        (274272, 280354, 280355, 'SKILL_POTION')]:
    request = decisions[decision]
    slot = request['chosen']['option_index']
    before = next(p for p in states[a]['potions'] if p['index'] == slot)
    after = next(p for p in states[b]['potions'] if p['index'] == slot)
    assert request['run_id'] == states[a]['run'] == states[b]['run'] == 'KEN58SH9SLZ6'
    assert request['chosen']['action'] == 'use_potion' and before['potion_id'] == potion and before['occupied'] and not after['occupied']
    facts.append({'kind': 'potion_consumed_endpoints', 'run': request['run_id'], 'floor': request['floor'], 'turn': request['turn'],
                  'decision_line': decision, 'state_lines': [a, b], 'potion': potion, 'slot': slot, 'response': request.get('result'),
                  'scope': '槽位消失已核，pending回执原样保留；完整候选收益与留药后继仍未知'})

poison = lambda s: next(p['amount'] for p in s['enemies'][0]['powers'] if p['power_id'] == 'POISON_POWER')
assert [poison(states[n]) for n in (280160, 280161)] == [2, 8]
assert [(states[n]['hp'], states[n]['block'], states[n]['enemies'][0]['intents'][0]['total_damage']) for n in (280160, 280161)] == [(26, 13, 41), (26, 13, 41)]
assert states[280162]['screen'] == 'GAME_OVER' and states[280162]['hp'] == 0
facts.append({'kind': 'giant_potion_observation', 'run': 'YQL8RZ8BWN1E', 'floor': 17, 'turn': 10,
              'state_lines': [280160, 280161, 280162], 'poison': [2, 8], 'hp': [26, 26, 0], 'block': [13, 13],
              'incoming': [41, 41], 'uncapped_hp_after_blast': -2})
pu = [e for e in attempts if e['row'].get('run_id') == 'PU80F84P6HPN' and e['row'].get('floor') == 17 and e['row'].get('attempt') == 5]
assert len(pu) == 1 and pu[0]['row']['result'] == 'won' and pu[0]['row']['end_hp'] == 2
facts.append({'kind': 'counterexample_giant_win', 'run': 'PU80F84P6HPN', 'floor': 17, 'turn': pu[0]['row']['turns'],
              'attempt': 5, 'sl_attempts_line': pu[0]['line'], 'result': 'won', 'end_hp': 2})
for number, expected in [(681, [999999999, 58]), (717, [999999981, 999999989]), (960, [999999990, 999999999])]:
    entry = next(e for e in attempts if e['line'] == number)
    anchor = entry['row']['explore']['target']['anchor']
    assert [e['enemyHp'] for e in anchor['ranked']] == expected
    facts.append({'kind': 'legacy_anchor_husk_hp', 'run': entry['row']['run_id'], 'floor': 17,
                  'sl_attempts_line': number, 'anchor': anchor})
dex = lambda n: next((p['amount'] for p in states[n]['powers'] if p['power_id'] == 'DEXTERITY_POWER'), 0)
assert [dex(n) for n in (280697, 280701, 280705)] == [0, 0, 2]
facts.append({'kind': 'delayed_dexterity', 'run': 'KEN58SH9SLZ6', 'floor': 17, 'attempt': 6,
              'state_lines': [280697, 280701, 280705], 'turns': [8, 9, 10], 'dexterity': [0, 0, 2]})

receipt_path = CONSUMERS / 'consumer-readback-r3.json'
receipt = json.loads(receipt_path.read_text())
excluded = {(e['run'], e['source_line']) for e in receipt['excluded_from_battle_consumer']}
reuse = []
for result in receipt['results']:
    input_path, output_path = Path(result['command'][-1]), Path(result['output'])
    assert digest(input_path.read_bytes()) == result['input_sha256']
    assert digest(output_path.read_bytes()) == result['output_sha256']
    data = json.loads(input_path.read_text())
    assert data['run'] == json.loads((OUT / 'run-identities.json').read_text())[result['run']]['row']
    for stream in ('states', 'decisions'):
        seen = set()
        for row in data[stream]:
            number = row['_line']
            original = {k: v for k, v in row.items() if k != '_line'}
            assert indexes[stream][number] == (result['run'], canonical(original))
            assert number not in seen
            seen.add(number)
        expected = {n for n, (run, _) in indexes[stream].items() if run == result['run'] and (stream != 'decisions' or (run, n) not in excluded)}
        assert seen == expected
    reuse.append({k: result[k] for k in ('run', 'input_sha256', 'output_sha256', 'segments', 'actions', 'observed_turns', 'unknown_turns', 'actual_full_candidate_results')})
sources = []
for path in ['learner/audit-selection.ts', 'learner/lib/selection-execution.ts', 'learner/lib/selection-observation.ts', 'learner/lib/selection-terminal.ts', 'learner/lib/selection-turn.ts', 'agent/src/core/util/json.ts']:
    before = subprocess.check_output(['git', 'show', '2554cfa65131163fc7fd4e469594e2b91f12ff5f:' + path])
    now = Path(path).read_bytes()
    assert before == now
    sources.append({'path': path, 'sha256': digest(now), 'same_as_historical_consumer_source': True})

result = {'all_verified': True, 'streams': stream_checks, 'total_rows': sum(e['verified_rows'] for e in stream_checks),
          'facts': facts, 'fact_checks': len(facts), 'prior_consumer_reuse': {'new_execution': False,
              'receipt': str(receipt_path), 'receipt_sha256': digest(receipt_path.read_bytes()),
              'input_rows_bound_to_current_verified_evidence': True, 'sources': sources, 'results': reuse,
              'excluded_rows': receipt['excluded_from_battle_consumer']},
          'limitations': ['同局SL不计独立局', '净血差不是单来源毛伤害', '候选预测、单步回执、端点和完整因果分开',
                         '仅复用原消费者产物，不是本批新运行或生产测试；历史失败原件保持']}
(OUT / 'evidence-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'all_verified': True, 'rows': result['total_rows'], 'fact_checks': len(facts), 'prior_consumers_bound': len(reuse)}, ensure_ascii=False))

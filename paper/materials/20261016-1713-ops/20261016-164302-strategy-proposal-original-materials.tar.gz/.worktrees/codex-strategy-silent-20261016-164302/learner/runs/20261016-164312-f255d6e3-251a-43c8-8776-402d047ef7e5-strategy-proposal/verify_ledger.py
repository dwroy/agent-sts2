import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
before = json.loads((HERE / "ledger-before.json").read_text())
raw = Path(before["source"]).read_bytes()
assert hashlib.sha256(raw[:before["source_size"]]).hexdigest() == before["source_sha256"]
inputs = [json.loads(line) for line in (HERE / "ledger-updates.jsonl").read_text().splitlines()]
assert (HERE / "ledger-update.stdout.txt").read_text().split() == [row["id"] for row in inputs]
assert not (HERE / "ledger-update.stderr.txt").read_bytes()
appends = []
offset = before["source_size"]
expected = {row["id"]: row for row in inputs}
for line in raw[before["source_size"]:].splitlines(keepends=True):
    row = json.loads(line)
    item = expected.get(row.get("id"))
    if item and row.get("note") == item["note"] and row.get("by") == item["by"]:
        assert {key: value for key, value in row.items() if key not in ["op", "ts"]} == item
        assert set(row) == {"op", "id", "ts", "by", "where", "note"}
        appends.append({"source": before["source"], "offset": offset, "bytes": len(line),
                        "sha256": hashlib.sha256(line).hexdigest(), "row": row})
    offset += len(line)
assert len(appends) == len(inputs) == 26
module = runpy.run_path("/home/dw/Projects/agent-sts2/learner/ledger.py")
folded = module["fold"]([(i + 1, json.loads(line)) for i, line in enumerate(raw.splitlines()) if line.strip()])
checks = []
for key, update in expected.items():
    item = folded[key]
    core = {field: value for field, value in item.items() if field not in ["where", "history", "notes"]}
    assert hashlib.sha256(json.dumps(core, ensure_ascii=False, sort_keys=True).encode()).hexdigest() == before["items"][key]["core_sha256"]
    for field, values in before["items"][key]["where"].items():
        assert item["where"][field][:len(values)] == values
    assert all(value in item["where"]["proposal"] for value in update["where"]["proposal"])
    checks.append({"id": key, "core_evidence_claim_status_version_unchanged": True,
                   "where_prefix_preserved": True, "new_links_read_back": True})
(HERE / "ledger-appends.json").write_text(json.dumps(appends, ensure_ascii=False, indent=2) + "\n")
(HERE / "ledger-verification.json").write_text(json.dumps({
    "cli_exit_code": 0, "prefix_size": before["source_size"], "prefix_sha256": before["source_sha256"],
    "physical_prefix_unchanged": True, "matched_own_append_rows": len(appends),
    "fields_only": ["by", "where", "note"], "items": checks,
}, ensure_ascii=False, indent=2) + "\n")
print("26条CLI追加与原证据、状态、版本保持均已核实")

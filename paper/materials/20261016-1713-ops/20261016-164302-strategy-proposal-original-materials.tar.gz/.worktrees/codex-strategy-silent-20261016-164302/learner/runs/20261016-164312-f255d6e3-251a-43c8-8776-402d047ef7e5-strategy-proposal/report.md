# 本批静默猎手策略提案核验

记录时间：2026-10-16T17:00:43+08:00。task=strategy-proposal，character=silent，batch=20261016-164302-strategy-proposal。

本批仅处理已领取的10个原提案，全部waiting。没有新源码、知识、策略参数或测试改动，没有提交、合入、eval版本或shipped登记。代码提案ID沿原CLI记录，不新建重复项。提案领域是原combat/potion/sl/structure，本批implementation_domains=[]表示没有实际实现领域。

基线：`92a01b76f72ddc7f623ef86c9dde5bf028bd5034`。开工git status干净；只读本批learn.json行，task/角色/工作树/runs匹配、reason=proposal，proposal_ids完整10项，无proposal_repair/research_request/implementation_request。普通专题文件绑定的是20261010-150327及另一工作树，条件不匹配，因此没有承接专题、读取另一专题或借用纯研究口径。正常执行git merge --no-edit main，返回Already up to date，HEAD仍为上述完整基线。

证据边界：六局runs.jsonl均为SILENT、A10，各自代码标识带dirty；当前源码或提交存在不能复原当时整棵dirty源码/移动表/知识输入。只分析本角色原帧、对应复盘和knowledge/characters/silent；不使用其他角色知识，也不补预训练机制。六局不是十个独立实验，SL尝试不扩大独立局分母。

原提案的10份Markdown逐一读取、实际SHA256全部匹配队列登记，见proposal-source-checks.json；原文和原经验保持。对应六段历史复盘及勘误存scoped-postmortems.json，本批没有重写或追加历史复盘。

## 原日志与独立核验

使用本工作树learner/extract_evidence.py共用入口，nice19单进程，输出evidence/，含states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流。各流在打开时冻结自己的source_size，不能视为八流共同原子时刻；本批六个已结束局的选中记录边界均可复现。每行保留source/line/offset/bytes/SHA256/显式run身份，拒绝身份冲突和正文提及。随后逐条seek原日志复核：6995条offset、字节数、SHA、JSON、身份与计数一致，八份提取文件SHA一致。原流有states/decisions各2条、brain1条JSON异常，未将其分配给任何本批局；不声称原流无异常。fight-plans本截点0条仅表示未选到，不据此断言历史日志缺失。

列顺序为本批派发局号：VLZ6CCT8AQ0A、8JRE1C4H4Z2W、CA5KE8GFJ9X2、5PM6JAQG6FNQ、61E2QS63Y9WU、DUZUBAJ3A8GP。

| 流 | source_size字节 | VLZ | 8JRE | CA5 | 5PM | 61E | DUZ |
|---|---:|---:|---:|---:|---:|---:|---:|
| states | 13567814233 | 729 | 676 | 282 | 660 | 462 | 623 |
| decisions | 1992528550 | 699 | 659 | 265 | 638 | 443 | 602 |
| sl-attempts | 43568278 | 2 | 7 | 0 | 7 | 7 | 6 |
| run-config | 1878431 | 1 | 1 | 1 | 1 | 1 | 1 |
| run-plans | 8563976 | 8 | 6 | 2 | 7 | 4 | 6 |
| brain | 677113929 | 46 | 31 | 11 | 39 | 27 | 29 |
| runs | 349739 | 1 | 1 | 1 | 1 | 1 | 1 |
| fight-plans | 2233957 | 0 | 0 | 0 | 0 | 0 | 0 |

18项发现样本内事实检查全部通过，详见evidence-verification.json；它们核实原帧与原候选语义，不是生产tsc/Vitest或策略收益实验。state-facts.json、decision-facts.json保存目标战斗的结构化摘录，mechanism-transitions.json保存52条去重状态转换观测；该去重只为展示，不代表52独立样本。bubble-prefix-facts.json再次确认末试F39空打冒泡时玩家HP是29，35是失落敌血，采用既有更正，不重复登记机制或support/repeat。

## 逐项处置

1. **silent-proposal-89354805ee4d7e77 — waiting**。账本：silent-0237, silent-0238。证据：VLZ6CCT8AQ0A F35 T1、F43 T1—5、F45 T1；s275564/275565、s275679/275680、d269706/269707、s275731/275732。 已核实神化局部升级传播，但actual_cast_this_fight仍为null；缺跨抽牌、选择、药水、重规划、SL及换战的已施放持续身份与剩余升级交互校准，不能以局部源码关闭整项。

2. **silent-proposal-f2bfceddb1898dca — waiting**。账本：silent-0106, silent-0019, silent-0201。证据：VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；d269748/269754/269770。前战F43获胜90→33，F44实回34至67/104，仍须保留资源链。 首问MC为707毫秒/1比12，第二问12比12但观测指纹不同；缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性曲线与留药后继，不改预算、药价或目标顺序。

3. **silent-proposal-283a164780d11e69 — waiting**。账本：silent-0237, silent-0238。证据：同第一项；原经验silent-apotheosis-combat-upgrades，原两来源提案不合并或重建ID。 与89354805ee4d7e77共用神化证据，经验来源链独立保留；实际施放持续身份和剩余升级交互尚未闭环，已有局部live提交不足以将整项标duplicate。

4. **silent-proposal-ebbfe3b97548756d — waiting**。账本：silent-0005, silent-0016, silent-0049, silent-0071, silent-0143, silent-0046, silent-0053, silent-0027, silent-0011, silent-0021, silent-0106, silent-0204, silent-0020, silent-0019。证据：VLZ6CCT8AQ0A F43 T1—5、F44、F45 T1—5；具体十五子项见mechanism-coverage.md。 十五个机制与资源子项已有部分模型和展示，仍缺属性/升级组合、期限恢复及战斗、路线、休息消费者的同次冻结逐源联合校准；不以一个子项的源码替代全部验收。

5. **silent-proposal-e5b87be50f28f311 — waiting**。账本：silent-0079, silent-0021, silent-0125, silent-0018。证据：8JRE1C4H4Z2W F33首/第三试T2 d270216/270282；第二试T5 d270264；末试T11 s276429/276433/276434。 同指纹SL替换的12血换7伤已核实；现有选择阶段、资源比较和单动作回执不证明整方案执行，缺跨重规划持续候选身份、完整执行认证及能力成长归属，不改SL血价或护栏。

6. **silent-proposal-49632bc4878fb597 — waiting**。账本：silent-0005, silent-0231。证据：CA5KE8GFJ9X2 F13 T1/T3/T5；s273237、273252、273254、273263、273268。 CA5 F13可核力量0到4到8及喷水11到15到19、虚弱后11/14；该战无正敏捷实测，缺逐击力量、正负敏捷、虚弱与独立成长四路径同次冻结生产校准，不拟合统一权重。

7. **silent-proposal-66532328a585941f — waiting**。账本：silent-0021, silent-0009。证据：5PM6JAQG6FNQ F33 T1—2与F39末试T2；d268455、s274379/274380。 5PM末试F39 T2无毒冒泡实付1能、玩家仍29血且两敌HP与毒不变；缺同HP、牌组、药水和完整抽序下启动顺序的受控整战比较及收益函数，不据持有能力拟合启动权重。

8. **silent-proposal-43a76a31ba7bdcfa — waiting**。账本：silent-0030, silent-0027。证据：61E2QS63Y9WU F17 T5—7；s273502/273504/273508，敌67→34对应17+16已结算毒，玩家力2→0、敏0→−2、敌力0→2。 61E F17吸取、负敏捷及17加16毒结算可核，首试胜利仍不是SL对照；缺同起始HP、构筑和完整抽序的SL整战配对与另一条已核后继，不改SL范围或阈值。

9. **silent-proposal-5264153a4a4b0e5c — waiting**。账本：silent-0039, silent-0209。证据：61E2QS63Y9WU F23 T4—5；s273593/273596，玩家25→10、幻象14→2、本体76→41，两敌力量3→6；采用已有勘误：T5先触媒，再打击杀幻象，再飞镖打本体。 61E F23 T4本体线47伤/损15与幻象余2可核，39伤/零损候选未实打；缺A10召唤、航行增力、退场及复现全链生产校准和另一focus完整后继，不规定固定杀序。

10. **silent-proposal-bddfa690a84e03d0 — waiting**。账本：silent-0128, silent-0079。证据：DUZUBAJ3A8GP F30 T1—6；s274906/274914/274919/274923/274929/274934；SL尝试相关，不扩大独立局分母。 DUZ F30睡层3/2/1、T4醒、T5力量2、T6力量4可核；四次相关失败不提供获胜反事实，缺伤害唤醒/眩晕接续/当前进阶成长的全链生产校准和同抽换序后继。

## 已有live局部实现与范围

实际读取live HEAD=`a9e687d9f0acccccddbfa92895d7966b58900658`。19个相关生产源码文件中14个逐字相同，另外5个文件只含已核对的Roy/Dai历史注释署名差，保存source-live.diff.patch与逐文件SHA，不修改这些并行历史。以下8个局部来源提交均实际为该live祖先：

- `772b839f8ada31664cb764ea9ad3bdb03da27f64`：live祖先=true。
- `f516592fff557ef02c8ece43433706358c3f7fe6`：live祖先=true。
- `b2805be4ba44b7375c7908d873889372cc3cfe6c`：live祖先=true。
- `ba23ca693151fa8c6f7fe035e640dc30f05ccd75`：live祖先=true。
- `45161a51c2c6b7e4a499b13cf749c4108193bbf5`：live祖先=true。
- `fdaf787a372880b0438e73bcac7e6d2168b038ed`：live祖先=true。
- `1698adc96ba434a46942321e0237b70657e625b2`：live祖先=true。
- `0fa15f5e06d60a6caa95b8f49675ee6222b4b276`：live祖先=true。

这些提交分别覆盖已观察神化升级/后抽传播、触媒与萎靡/致命毒药升级增量、模拟范围展示、单动作回执和SL资源比较等局部环节。源码定位：silent-apotheosis.ts、turn-solver.ts的apotheosis路径、rollout.ts的后续牌堆升级、silent-simulation-reference.ts、silent-selection-audit.ts、silent-selection-dispatch.ts、silent-hp-guard-audit.ts、silent-sl-resource-comparison.ts。实际施放字段仍为null、whole_plan_executed仍为null，不能因提交存在将原整项标implemented/duplicate，也不能将候选资源差登记为实际保血。

当前已有summonsAt胧光怪召唤入口，但原A10航行/复现/替focus全链未据此验收；有关怪物HP与伤害须继续用当前进阶数据库实际输入，缺项不补常量，房间代价5样本门槛不改。十五复合子项的边界见mechanism-coverage.md。

## 登记、验证与交付

仅经根目录learner/ledger.py update追加本批提案/报告链接和缺口说明，by=learner:strategy-proposal；不重复追加既有证据，不改claim、首证、prior、status、version或shipped历史。新学条目/源码提交均无，不用proposed覆盖旧shipped状态；CLI输入和真实返回另存ledger-updates.jsonl、ledger-update.stdout.txt、ledger-update.stderr.txt，并核验追加字段。没有新提案需要code_proposals.py add；最终code_proposals沿这10个真实已有CLI ID。

生产源码、测试及知识均未修改，所以tsc/vitest/cases均为null；未运行生产测试，未做撤源码红绿，不借用旧批成功或上述18项材料检查填0。没有提交，未进入live合并流程，merged=null，未加版本，未登记shipped，无实际上线规则需要双通知。工作树应维持干净，最终HEAD仍为base；报告和过程材料均在本批被忽略的learner/runs目录。根账本只追加授权追溯记录，由ops按原流程接收；不把报告交付当经验入库或消费者已采用。

本批无新机制异议或足以推翻旧经验的新反证；报告保留原有反例、候选与实际执行的差别。初期一次只读结构探查因空手牌IndexError失败、一次rg猜测不存在路径的诊断保留于diagnostic-notes.md，随后修正读取方法；均不是产品故障或源码测试失败。无网络/模型/游戏调用、无推送、无下级agent。

运维交付提案：`/home/dw/Projects/agent-sts2/.worktrees/codex-strategy-silent-20261016-164302/learner/runs/20261016-164312-f255d6e3-251a-43c8-8776-402d047ef7e5-strategy-proposal/proposal.md`。最终机读处置：result.json；每个派发ID都有具体waiting理由，等待相应新增证据，不关闭父要求。


## 2026-10-16T17:05:06+08:00 最终读回

补充scope-verification.json的12项跨局事实检查全部通过，与原18项合计30项材料检查；二者均不作为生产测试。26条账本CLI真实返回、原物理前缀SHA、逐追加offset/bytes/SHA/JSON及字段均已核实，只追加by/where/note，原证据/claim/首证/prior/status/version保持，详见ledger-verification.json与ledger-appends.json。10个原提案SHA再次全部匹配，最终工作树/index/跟踪差异均干净，HEAD仍为完整base。未提交、未合入、未新建版本。材料快照首轮gitleaks实际rc0/未发现泄露；最终新增读回材料另做收尾扫描并保留独立日志，不混同生产测试。

import collections
import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
identity = runpy.run_path(str(ROOT / "learner/extract_evidence.py"))["run_identity"]
dispatch = json.loads((HERE / "dispatch-proposals.json").read_text())
RUNS = dispatch["batch"]["runs"]
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
streams = {}
verification = []
for entry in manifest:
    name = entry["stream"]
    path = HERE / "evidence" / (name + ".evidence.jsonl")
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry["output_sha256"]
    rows = []
    counts = collections.Counter()
    with (Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl")).open("rb") as source:
        for line in path.open():
            item = json.loads(line)
            assert item["source"] == str(Path("/home/dw/Projects/agent-sts2/logs") / (name + ".jsonl"))
            assert item["run_id"] in RUNS and identity(item["row"]) == item["run_id"]
            assert item["offset"] + item["bytes"] <= entry["source_size"]
            source.seek(item["offset"])
            raw = source.read(item["bytes"])
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            assert json.loads(raw) == item["row"]
            counts[item["run_id"]] += 1
            rows.append(item)
    assert {run: counts[run] for run in RUNS} == entry["counts"]
    streams[name] = rows
    verification.append({"stream": name, "verified_rows": len(rows), "source_size": entry["source_size"],
                         "output_sha256": entry["output_sha256"], "raw_offset_bytes_sha_json_identity": True})

for item in streams["runs"]:
    assert item["row"]["character"] == "SILENT" and item["row"]["ascension"] == 10
assert len(streams["runs"]) == len(RUNS)
for item in streams["states"]:
    run = item["row"]["state"].get("run")
    if run:
        assert run["character_id"] == "SILENT" and run["ascension"] == 10

states = {item["line"]: item for item in streams["states"]}
decisions = {item["line"]: item for item in streams["decisions"]}
checks = []


def check(name, value):
    checks.append({"name": name, "passed": bool(value)})


def st(line):
    return states[line]["row"]["state"]


def player(state):
    return (state.get("combat") or {}).get("player") or {}


def powers(obj):
    return {p["power_id"]: p["amount"] for p in obj.get("powers", [])}


def card(state, card_id):
    return next(c for c in state["combat"]["hand"] if c["card_id"] == card_id)


def value(c, key):
    return next(d["current_value"] for d in c["dynamic_values"] if d["name"] == key)


def criteria(line):
    raw = decisions[line]["row"].get("questions", {}).get("plan", {}).get("criteria", {})
    result = {}
    for key, obj in raw.items():
        try:
            result[key] = json.loads(obj) if isinstance(obj, str) else obj
        except ValueError:
            pass
    return result


check("F35神化实付2能", player(st(275564))["energy"] - player(st(275565))["energy"] == 2)
for cid, field, before, after in [("DEFEND_SILENT", "Block", 5, 8), ("STRIKE_SILENT", "Damage", 7, 10),
                                  ("DAGGER_SPRAY", "Damage", 5, 7)]:
    check("F35神化升级" + cid, value(card(st(275564), cid), field) == before and value(card(st(275565), cid), field) == after)
check("F35必备工具费用1变0", card(st(275564), "TOOLS_OF_THE_TRADE")["energy_cost"] == 1 and card(st(275565), "TOOLS_OF_THE_TRADE")["energy_cost"] == 0)
check("F43重问前后43伤14损与51伤13损", [(criteria(n)["plan1"]["damage_dealt"], criteria(n)["plan1"]["hp_lost"]) for n in [269706, 269707]] == [(43, 14), (51, 13)])
check("F43同轮实扣51血净损13", st(275679)["combat"]["enemies"][0]["current_hp"] - st(275687)["combat"]["enemies"][0]["current_hp"] == 51 and player(st(275679))["current_hp"] - player(st(275687))["current_hp"] == 13)
mc = decisions[269748]["row"]["potions"]["random"][0]
check("F45首问MC707毫秒1比12", (mc["ms"], mc["samples"], mc["requested"]) == (707, 1, 12))
r = decisions[269748]["row"]["rollout"]
check("F45首问退化没有最佳线", r["horizon"] == 1 and r["samples"] == 1 and r["best"] is None)
check("F45第二问MC完成12样本但状态不同", decisions[269754]["row"]["potions"]["random"][0]["samples"] == 12 and decisions[269748]["row"]["fingerprint"] != decisions[269754]["row"]["fingerprint"])
check("F45神化未施放仍普通且被弃", card(st(275731), "APOTHEOSIS")["upgraded"] is False and not st(275732)["combat"]["hand"])
check("F45普通勒紧与触媒没有预支升级", powers(player(st(275732))).get("FASTEN_POWER") == 4 and powers(player(st(275732))).get("ACCELERANT_POWER") == 1)
c = criteria(269770)
check("F45T4候选31损32伤与13损24伤", any(x.get("hp_lost") == 31 and x.get("damage_dealt") == 32 for x in c.values()) and any(x.get("hp_lost") == 13 and x.get("damage_dealt") == 24 for x in c.values()))
check("8J首试第三试T2观测指纹完全相同", decisions[270216]["row"]["fingerprint"] == decisions[270282]["row"]["fingerprint"])
explore = decisions[270282]["row"]["sl_explore"]
check("8J换线血价及死亡数分别保存", "hp -3, dmg 10" in explore["numbers"]["original"] and "hp -15, dmg 17" in explore["numbers"]["replacement"] and "dead 0/24" in explore["numbers"]["original"] and "dead 5/24" in explore["numbers"]["replacement"])
c = criteria(270264)
check("8J护栏前后候选16损43伤与4损25伤", (c["plan4"]["hp_lost"], c["plan4"]["damage_dealt"], c["plan6"]["hp_lost"], c["plan6"]["damage_dealt"]) == (16, 43, 4, 25))
check("8J末轮完整需损15而实际只扣5", player(st(276433))["current_hp"] == 5 and player(st(276433))["block"] == 22 and st(276433)["combat"]["enemies"][0]["intents"][0]["total_damage"] == 37 and player(st(276434))["current_hp"] == 0)
check("8J末轮沙坑仍有余量而非归零", powers(st(276433)["combat"]["enemies"][0]).get("SANDPIT_POWER") == 2 and powers(st(276434)["combat"]["enemies"][0]).get("SANDPIT_POWER") == 1)


def compact(item):
    s = item["row"]["state"]
    p = player(s)
    return {"line": item["line"], "offset": item["offset"], "bytes": item["bytes"], "sha256": item["sha256"],
            "run_id": item["run_id"], "observed_ts": item["row"].get("observed_ts"),
            "floor": (s.get("run") or {}).get("floor"), "turn": s.get("turn"), "in_combat": s.get("in_combat"),
            "hp": p.get("current_hp"), "block": p.get("block"), "energy": p.get("energy"), "powers": powers(p),
            "deck_upgrades": sum(bool(c.get("upgraded")) for c in (s.get("run") or {}).get("deck", [])),
            "hand": [{"index": c.get("index"), "card_id": c.get("card_id"), "upgraded": c.get("upgraded"),
                      "cost": c.get("energy_cost"), "values": {d["name"]: d["current_value"] for d in c.get("dynamic_values", [])}}
                     for c in (s.get("combat") or {}).get("hand", [])],
            "enemies": [{"index": e.get("index"), "id": e.get("enemy_id"), "hp": e.get("current_hp"), "block": e.get("block"),
                         "move": e.get("move_id"), "alive": e.get("is_alive"), "powers": powers(e), "intents": e.get("intents")}
                        for e in (s.get("combat") or {}).get("enemies", [])]}


targets = {"CA5KE8GFJ9X2": {13}, "61E2QS63Y9WU": {17, 23}, "5PM6JAQG6FNQ": {33, 39},
           "DUZUBAJ3A8GP": {30}, "VLZ6CCT8AQ0A": {35, 43, 44, 45}, "8JRE1C4H4Z2W": {17, 33}}
facts = [compact(item) for item in streams["states"] if (item["row"]["state"].get("run") or {}).get("floor") in targets[item["run_id"]]]
(HERE / "state-facts.json").write_text(json.dumps(facts, ensure_ascii=False, indent=2) + "\n")
selected = []
for item in streams["decisions"]:
    r = item["row"]
    if r.get("floor") not in targets[item["run_id"]]:
        continue
    selected.append({"line": item["line"], "offset": item["offset"], "bytes": item["bytes"], "sha256": item["sha256"],
                     **{key: r.get(key) for key in ["run_id", "observed_ts", "floor", "turn", "chosen", "sl_attempt", "sl_reloads", "sl_explore", "rollout", "potions", "answers"]},
                     "criteria": criteria(item["line"])})
(HERE / "decision-facts.json").write_text(json.dumps(selected, ensure_ascii=False, indent=2) + "\n")
result = {"streams": verification, "total_verified_rows": sum(len(v) for v in streams.values()),
          "mechanical_checks": checks, "all_checks_passed": all(c["passed"] for c in checks),
          "selected_state_facts": len(facts), "selected_decision_facts": len(selected),
          "limitation": "逐字节核验和发现样本内事实检查，不等于生产测试、全链校准、完整候选执行或未选线路实盘胜负。"}
(HERE / "evidence-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"verified_rows": result["total_verified_rows"], "checks": len(checks), "failed": [c for c in checks if not c["passed"]]}, ensure_ascii=False))
assert result["all_checks_passed"]

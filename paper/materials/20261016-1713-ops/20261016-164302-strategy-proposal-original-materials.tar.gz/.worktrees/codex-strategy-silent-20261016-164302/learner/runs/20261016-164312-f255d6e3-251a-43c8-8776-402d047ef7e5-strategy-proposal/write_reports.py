import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
dispatch = json.loads((HERE / "dispatch-proposals.json").read_text())
sources = json.loads((HERE / "source-live-checks.json").read_text())
verification = json.loads((HERE / "evidence-verification.json").read_text())
manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
stamp = (HERE / "recorded-at.txt").read_text().strip()
batch = "20261016-164302-strategy-proposal"
reasons = [
    "已核实神化局部升级传播，但actual_cast_this_fight仍为null；缺跨抽牌、选择、药水、重规划、SL及换战的已施放持续身份与剩余升级交互校准，不能以局部源码关闭整项。",
    "首问MC为707毫秒/1比12，第二问12比12但观测指纹不同；缺完整模型下同起点、同随机池、同总预算的配对实验、候选稳定性曲线与留药后继，不改预算、药价或目标顺序。",
    "与89354805ee4d7e77共用神化证据，经验来源链独立保留；实际施放持续身份和剩余升级交互尚未闭环，已有局部live提交不足以将整项标duplicate。",
    "十五个机制与资源子项已有部分模型和展示，仍缺属性/升级组合、期限恢复及战斗、路线、休息消费者的同次冻结逐源联合校准；不以一个子项的源码替代全部验收。",
    "同指纹SL替换的12血换7伤已核实；现有选择阶段、资源比较和单动作回执不证明整方案执行，缺跨重规划持续候选身份、完整执行认证及能力成长归属，不改SL血价或护栏。",
    "CA5 F13可核力量0到4到8及喷水11到15到19、虚弱后11/14；该战无正敏捷实测，缺逐击力量、正负敏捷、虚弱与独立成长四路径同次冻结生产校准，不拟合统一权重。",
    "5PM末试F39 T2无毒冒泡实付1能、玩家仍29血且两敌HP与毒不变；缺同HP、牌组、药水和完整抽序下启动顺序的受控整战比较及收益函数，不据持有能力拟合启动权重。",
    "61E F17吸取、负敏捷及17加16毒结算可核，首试胜利仍不是SL对照；缺同起始HP、构筑和完整抽序的SL整战配对与另一条已核后继，不改SL范围或阈值。",
    "61E F23 T4本体线47伤/损15与幻象余2可核，39伤/零损候选未实打；缺A10召唤、航行增力、退场及复现全链生产校准和另一focus完整后继，不规定固定杀序。",
    "DUZ F30睡层3/2/1、T4醒、T5力量2、T6力量4可核；四次相关失败不提供获胜反事实，缺伤害唤醒/眩晕接续/当前进阶成长的全链生产校准和同抽换序后继。",
]
evidence = [
    "VLZ6CCT8AQ0A F35 T1、F43 T1—5、F45 T1；s275564/275565、s275679/275680、d269706/269707、s275731/275732。",
    "VLZ6CCT8AQ0A F43、F44、F45 T1/T4/T5；d269748/269754/269770。前战F43获胜90→33，F44实回34至67/104，仍须保留资源链。",
    "同第一项；原经验silent-apotheosis-combat-upgrades，原两来源提案不合并或重建ID。",
    "VLZ6CCT8AQ0A F43 T1—5、F44、F45 T1—5；具体十五子项见mechanism-coverage.md。",
    "8JRE1C4H4Z2W F33首/第三试T2 d270216/270282；第二试T5 d270264；末试T11 s276429/276433/276434。",
    "CA5KE8GFJ9X2 F13 T1/T3/T5；s273237、273252、273254、273263、273268。",
    "5PM6JAQG6FNQ F33 T1—2与F39末试T2；d268455、s274379/274380。",
    "61E2QS63Y9WU F17 T5—7；s273502/273504/273508，敌67→34对应17+16已结算毒，玩家力2→0、敏0→−2、敌力0→2。",
    "61E2QS63Y9WU F23 T4—5；s273593/273596，玩家25→10、幻象14→2、本体76→41，两敌力量3→6；采用已有勘误：T5先触媒，再打击杀幻象，再飞镖打本体。",
    "DUZUBAJ3A8GP F30 T1—6；s274906/274914/274919/274923/274929/274934；SL尝试相关，不扩大独立局分母。",
]
counterexamples = [
    "F43已施放仍损57；F45未施放而败，两战敌人和资源不同，不证明必打神化或补齐即可获胜。",
    "本局F17/F33均首试获胜；F45不同指纹的12样本题不能充作同盘预算实验，未实打高伤线。",
    "同第一项；牌组拥有神化不等于战内已建立，也不等于未知升级已覆盖。",
    "F43赢而损57、F44实补34后F45仍败；能力/临减/覆甲/毒的独立分母不同，不设固定安全血线。",
    "末试T2改防御省3血少10伤，延至T11仍败；不把所有防御替换统一判错。0/24与5/24死亡数不可说相同。",
    "临时虚弱未取消下一次加压；未获得计划中的步法，不能借计划补正敏捷证据。",
    "F33雾3/触媒1/群蛇4建立并赢，F39资源和敌人同时改变，不能把差异全归启动顺序。",
    "本局族母首试赢；不能借其他局失败或同抽重打猜本局SL禁令。",
    "另一focus仅为候选预测；不能把当轮零损线升级为整战胜线，敌index重排后仍按ID核对。",
    "末试T4较首试多扣3敌血也多损2玩家血；不能只用敌剩血改全死排序。",
]
results = [{"id": q["original"]["id"], "state": "waiting", "reason": reason}
           for q, reason in zip(dispatch["proposals"], reasons)]
result = {"task": "strategy-proposal", "character": "silent", "batch": batch, "base": sources["base"],
          "runs": dispatch["batch"]["runs"], "fixes": [], "skipped": [], "merged": None,
          "tests": {"tsc": None, "vitest": None, "cases": None},
          "code_proposals": dispatch["batch"]["proposal_ids"], "implementation_domains": [],
          "proposal_results": results, "report": str(HERE / "report.md")}
(HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
head = f"""# 本批静默猎手策略提案核验

记录时间：{stamp}。task=strategy-proposal，character=silent，batch={batch}。

本批仅处理已领取的10个原提案，全部waiting。没有新源码、知识、策略参数或测试改动，没有提交、合入、eval版本或shipped登记。代码提案ID沿原CLI记录，不新建重复项。提案领域是原combat/potion/sl/structure，本批implementation_domains=[]表示没有实际实现领域。

基线：`{sources['base']}`。开工git status干净；只读本批learn.json行，task/角色/工作树/runs匹配、reason=proposal，proposal_ids完整10项，无proposal_repair/research_request/implementation_request。普通专题文件绑定的是20261010-150327及另一工作树，条件不匹配，因此没有承接专题、读取另一专题或借用纯研究口径。正常执行git merge --no-edit main，返回Already up to date，HEAD仍为上述完整基线。

证据边界：六局runs.jsonl均为SILENT、A10，各自代码标识带dirty；当前源码或提交存在不能复原当时整棵dirty源码/移动表/知识输入。只分析本角色原帧、对应复盘和knowledge/characters/silent；不使用其他角色知识，也不补预训练机制。六局不是十个独立实验，SL尝试不扩大独立局分母。

原提案的10份Markdown逐一读取、实际SHA256全部匹配队列登记，见proposal-source-checks.json；原文和原经验保持。对应六段历史复盘及勘误存scoped-postmortems.json，本批没有重写或追加历史复盘。

"""
parts = [head]
for index, (proposal, outcome) in enumerate(zip(dispatch["proposals"], results), 1):
    original = proposal["original"]
    parts.append(f"""## {index}. {outcome['id']}

原任务：{original['source_task']} → strategy-proposal。账本：{', '.join(original['ledger'])}。

提案：{original['summary']}

本批核实证据：{evidence[index-1]}

反例/限制：{counterexamples[index-1]}

现行为与本次处置：{outcome['reason']} 原有模型、全部合法选项、并列语义和选择权保持；本批不增加固定优先级、统一权重或必胜结论。

后续验证：先按原提案冻结相应盘面、原知识/当前进阶移动表和完整执行前缀；局部机制用逐状态差核，收益规则用同起点、同抽序或同随机池配对。发现样本只作发现/回归，不冒称盲测；整战收益与泛化需要后置独立silent局。若有新源码，必须执行撤源码失败/恢复通过及原沙箱检查后再考虑live。缺口具体如上，不能以增加同局候选或局部绿测试代替缺数据。

预期影响与回退：本批只保留可追溯待办，不宣称策略效果；没有生产变更可回退，原规则保持。后续实现在自己的源码提交上回退并保留原证据。

""")
(HERE / "proposal.md").write_text("".join(parts))
table = "\n".join("| " + e["stream"] + " | " + str(e["source_size"]) + " | " + " | ".join(str(e["counts"][r]) for r in dispatch["batch"]["runs"]) + " |" for e in manifest)
partial = "\n".join(f"- `{q['commit']}`：live祖先={str(q['is_live_ancestor']).lower()}。" for q in sources["partial_commits"])
report = head + f"""## 原日志与独立核验

使用本工作树learner/extract_evidence.py共用入口，nice19单进程，输出evidence/，含states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans八流。各流在打开时冻结自己的source_size，不能视为八流共同原子时刻；本批六个已结束局的选中记录边界均可复现。每行保留source/line/offset/bytes/SHA256/显式run身份，拒绝身份冲突和正文提及。随后逐条seek原日志复核：{verification['total_verified_rows']}条offset、字节数、SHA、JSON、身份与计数一致，八份提取文件SHA一致。原流有states/decisions各2条、brain1条JSON异常，未将其分配给任何本批局；不声称原流无异常。fight-plans本截点0条仅表示未选到，不据此断言历史日志缺失。

列顺序为本批派发局号：VLZ6CCT8AQ0A、8JRE1C4H4Z2W、CA5KE8GFJ9X2、5PM6JAQG6FNQ、61E2QS63Y9WU、DUZUBAJ3A8GP。

| 流 | source_size字节 | VLZ | 8JRE | CA5 | 5PM | 61E | DUZ |
|---|---:|---:|---:|---:|---:|---:|---:|
{table}

18项发现样本内事实检查全部通过，详见evidence-verification.json；它们核实原帧与原候选语义，不是生产tsc/Vitest或策略收益实验。state-facts.json、decision-facts.json保存目标战斗的结构化摘录，mechanism-transitions.json保存52条去重状态转换观测；该去重只为展示，不代表52独立样本。bubble-prefix-facts.json再次确认末试F39空打冒泡时玩家HP是29，35是失落敌血，采用既有更正，不重复登记机制或support/repeat。

## 逐项处置

"""
for i, (q, out) in enumerate(zip(dispatch["proposals"], results), 1):
    report += f"{i}. **{out['id']} — waiting**。账本：{', '.join(q['original']['ledger'])}。证据：{evidence[i-1]} {out['reason']}\n\n"
report += f"""## 已有live局部实现与范围

实际读取live HEAD=`{sources['live']}`。19个相关生产源码文件中14个逐字相同，另外5个文件只含已核对的Roy/Dai历史注释署名差，保存source-live.diff.patch与逐文件SHA，不修改这些并行历史。以下8个局部来源提交均实际为该live祖先：

{partial}

这些提交分别覆盖已观察神化升级/后抽传播、触媒与萎靡/致命毒药升级增量、模拟范围展示、单动作回执和SL资源比较等局部环节。源码定位：silent-apotheosis.ts、turn-solver.ts的apotheosis路径、rollout.ts的后续牌堆升级、silent-simulation-reference.ts、silent-selection-audit.ts、silent-selection-dispatch.ts、silent-hp-guard-audit.ts、silent-sl-resource-comparison.ts。实际施放字段仍为null、whole_plan_executed仍为null，不能因提交存在将原整项标implemented/duplicate，也不能将候选资源差登记为实际保血。

当前已有summonsAt胧光怪召唤入口，但原A10航行/复现/替focus全链未据此验收；有关怪物HP与伤害须继续用当前进阶数据库实际输入，缺项不补常量，房间代价5样本门槛不改。十五复合子项的边界见mechanism-coverage.md。

## 登记、验证与交付

仅经根目录learner/ledger.py update追加本批提案/报告链接和缺口说明，by=learner:strategy-proposal；不重复追加既有证据，不改claim、首证、prior、status、version或shipped历史。新学条目/源码提交均无，不用proposed覆盖旧shipped状态；CLI输入和真实返回另存ledger-updates.jsonl、ledger-update.stdout.txt、ledger-update.stderr.txt，并核验追加字段。没有新提案需要code_proposals.py add；最终code_proposals沿这10个真实已有CLI ID。

生产源码、测试及知识均未修改，所以tsc/vitest/cases均为null；未运行生产测试，未做撤源码红绿，不借用旧批成功或上述18项材料检查填0。没有提交，未进入live合并流程，merged=null，未加版本，未登记shipped，无实际上线规则需要双通知。工作树应维持干净，最终HEAD仍为base；报告和过程材料均在本批被忽略的learner/runs目录。根账本只追加授权追溯记录，由ops按原流程接收；不把报告交付当经验入库或消费者已采用。

本批无新机制异议或足以推翻旧经验的新反证；报告保留原有反例、候选与实际执行的差别。初期一次只读结构探查因空手牌IndexError失败、一次rg猜测不存在路径的诊断保留于diagnostic-notes.md，随后修正读取方法；均不是产品故障或源码测试失败。无网络/模型/游戏调用、无推送、无下级agent。

运维交付提案：`{HERE / 'proposal.md'}`。最终机读处置：result.json；每个派发ID都有具体waiting理由，等待相应新增证据，不关闭父要求。
"""
(HERE / "report.md").write_text(report)
mechanisms = [
    ("silent-strength-weak-observation", "silent-0005", "VLZ F45 T3/T5；力量逐击、弱、取整与毒分源", "当前属性/升级/取整组合全链"),
    ("silent-footwork-block", "silent-0005", "VLZ F43 T3与F45 T5；敏捷和基础挡分列", "敏捷/升级/其他增挡联合输入"),
    ("silent-gorget-plating", "silent-0016", "VLZ F45开场4、T5为0", "覆甲减层完整条件及期限"),
    ("silent-vajra-opening-strength", "silent-0049", "VLZ F45开场力量1", "同其他力量来源逐源归属"),
    ("silent-sparkling-rouge-turn-three", "silent-0071", "VLZ F45 T3新增1力1敏", "期限/独立属性组合"),
    ("silent-fasten-defend-extra-block", "silent-0143", "VLZ F45 T5后空翻8、防御12", "普通/升级、敏捷/脆弱交互"),
    ("silent-piercing-wail-temporary-strength", "silent-0046", "VLZ F45 T5四段各减6，83→59", "临减恢复与后轮成长全链"),
    ("silent-malaise-x-debuff", "silent-0053", "VLZ F43 T2升级萎靡X2给3减力/3弱", "X费/升级/制品等组合校准"),
    ("silent-accelerant-triggers", "silent-0027", "VLZ F43 T4/T5毒33/45；F45末残毒2+1", "逐次结算/截断/升级组合"),
    ("silent-noxious-fumes-growth", "silent-0011", "VLZ F43实建3、F45未建立", "实际建立身份及跨轮归属"),
    ("silent-deck-burst-observation", "silent-0021", "VLZ神化持有与未出分账", "同资源/抽序下启动收益"),
    ("silent-three-knights-output-buffer-observation", "silent-0106", "VLZ F45 T4 13损24伤对未打31损32伤", "替focus整战后继"),
    ("silent-stone-humidifier-rest-growth", "silent-0204", "VLZ F44 33/99→67/104", "即时回复与后续投影联合读回"),
    ("silent-rest-buffer-observation", "silent-0020", "VLZ F44实回34而下一战仍败", "同起点休息/锻造受控整战"),
    ("silent-route-hp-observation", "silent-0019", "VLZ F35—F43胜战消耗及休息资源链", "路线/构筑变化后的完整联合消费者"),
]
(HERE / "mechanism-coverage.md").write_text("# 十五子项的证据与未闭环范围\n\n本表是原提案逐项覆盖索引，不是十五项已完成或新游戏知识。VLZ均指本批VLZ6CCT8AQ0A A10；数值来自原提案和已核原流。\n\n| 原经验 | 账本 | 证据/已观察边界 | 本批未验收范围 |\n|---|---|---|---|\n" + "\n".join("| " + " | ".join(row) + " |" for row in mechanisms) + "\n")
(HERE / "diagnostic-notes.md").write_text("# 只读诊断失败保留\n\n首次探查states结构时将非空combat误当成非空hand，读取空hand的第0项引发IndexError: list index out of range；未修改原日志或生产文件。随后改为只探查非空hand，成功读到真实字段。另一次rg查找不存在的agent/src/sl/silent-resource-audit.ts返回No such file or directory；随后用rg --files找到实际agent/src/reflex/silent-sl-resource-comparison.ts。工具输出原记录保留在本会话；本文件只说明原因，不冒造原始输出文件或把诊断失败当产品bug。\n")
ledgers = sorted({ledger for q in dispatch["proposals"] for ledger in q["original"]["ledger"]})
updates = []
for ledger in ledgers:
    linked = [out for q, out in zip(dispatch["proposals"], results) if ledger in q["original"]["ledger"]]
    updates.append({"id": ledger, "by": "learner:strategy-proposal", "where": {"proposal": [str(HERE / "proposal.md"), str(HERE / "report.md")]},
                    "note": batch + "仅追加提案处置追溯；" + "；".join(out["id"] + ":waiting，" + out["reason"] for out in linked) + " 不改旧claim/证据/首证/prior/status/version；无源码/合入/版本，不新增support或repeat。"})
(HERE / "ledger-updates.jsonl").write_text("".join(json.dumps(q, ensure_ascii=False) + "\n" for q in updates))
print(json.dumps({"report": str(HERE / "report.md"), "proposal_results": len(results), "ledger_update_rows": len(updates), "base": sources["base"]}, ensure_ascii=False))

# 只读诊断失败保留

首次探查states结构时将非空combat误当成非空hand，读取空hand的第0项引发IndexError: list index out of range；未修改原日志或生产文件。随后改为只探查非空hand，成功读到真实字段。另一次rg查找不存在的agent/src/sl/silent-resource-audit.ts返回No such file or directory；随后用rg --files找到实际agent/src/reflex/silent-sl-resource-comparison.ts。工具输出原记录保留在本会话；本文件只说明原因，不冒造原始输出文件或把诊断失败当产品bug。

账本CLI已经成功后，首次只读验收脚本误用json.load读取其空格分隔的26个ID，报JSONDecodeError: Expecting value: line 1 column 1 (char 0)。失败发生在校验脚本写入前，未重执行CLI或追加第二遍账本。后续verify_ledger.py改用split()并同时核对原物理前缀与26条实际追加，真实rc0，完整证据核心/状态/版本保持。首次错误的工具原输出保留在本会话，不伪造成生产失败。

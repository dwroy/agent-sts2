# 十五子项的证据与未闭环范围

本表是原提案逐项覆盖索引，不是十五项已完成或新游戏知识。VLZ均指本批VLZ6CCT8AQ0A A10；数值来自原提案和已核原流。

| 原经验 | 账本 | 证据/已观察边界 | 本批未验收范围 |
|---|---|---|---|
| silent-strength-weak-observation | silent-0005 | VLZ F45 T3/T5；力量逐击、弱、取整与毒分源 | 当前属性/升级/取整组合全链 |
| silent-footwork-block | silent-0005 | VLZ F43 T3与F45 T5；敏捷和基础挡分列 | 敏捷/升级/其他增挡联合输入 |
| silent-gorget-plating | silent-0016 | VLZ F45开场4、T5为0 | 覆甲减层完整条件及期限 |
| silent-vajra-opening-strength | silent-0049 | VLZ F45开场力量1 | 同其他力量来源逐源归属 |
| silent-sparkling-rouge-turn-three | silent-0071 | VLZ F45 T3新增1力1敏 | 期限/独立属性组合 |
| silent-fasten-defend-extra-block | silent-0143 | VLZ F45 T5后空翻8、防御12 | 普通/升级、敏捷/脆弱交互 |
| silent-piercing-wail-temporary-strength | silent-0046 | VLZ F45 T5四段各减6，83→59 | 临减恢复与后轮成长全链 |
| silent-malaise-x-debuff | silent-0053 | VLZ F43 T2升级萎靡X2给3减力/3弱 | X费/升级/制品等组合校准 |
| silent-accelerant-triggers | silent-0027 | VLZ F43 T4/T5毒33/45；F45末残毒2+1 | 逐次结算/截断/升级组合 |
| silent-noxious-fumes-growth | silent-0011 | VLZ F43实建3、F45未建立 | 实际建立身份及跨轮归属 |
| silent-deck-burst-observation | silent-0021 | VLZ神化持有与未出分账 | 同资源/抽序下启动收益 |
| silent-three-knights-output-buffer-observation | silent-0106 | VLZ F45 T4 13损24伤对未打31损32伤 | 替focus整战后继 |
| silent-stone-humidifier-rest-growth | silent-0204 | VLZ F44 33/99→67/104 | 即时回复与后续投影联合读回 |
| silent-rest-buffer-observation | silent-0020 | VLZ F44实回34而下一战仍败 | 同起点休息/锻造受控整战 |
| silent-route-hp-observation | silent-0019 | VLZ F35—F43胜战消耗及休息资源链 | 路线/构筑变化后的完整联合消费者 |

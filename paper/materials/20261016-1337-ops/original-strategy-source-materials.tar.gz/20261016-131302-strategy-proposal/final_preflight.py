import fcntl
import hashlib
import json
import subprocess
import time
from pathlib import Path

out = Path(__file__).resolve().parent
workspace = out.parents[2]
root = Path('/home/dw/Projects/agent-sts2')
live = root / '.worktrees/live'

def git(cwd, *args):
    return subprocess.run(['git', '-C', str(cwd), *args], text=True, capture_output=True, check=True).stdout.strip()

source = git(workspace, 'rev-parse', 'HEAD')
parent = git(workspace, 'rev-parse', 'HEAD^')
paths = git(workspace, 'diff-tree', '--no-commit-id', '--name-only', '-r', source).splitlines()
assert parent == 'ca9f61f7396ebdf181843f7099c177d3ca865fae'
assert set(paths) == {'agent/src/hand/screens/selection.ts', 'agent/src/hand/screens/silent-sandpit-discard.ts',
                      'agent/tests/silent-survivor-sandpit-discard.test.ts', 'agent/tests/silent-survivor-sandpit-evidence.json'}
assert not git(workspace, 'status', '--porcelain=v1')
receipt = {'source': source, 'source_parent': parent, 'source_paths': paths,
           'source_sha256': {p: hashlib.sha256((workspace / p).read_bytes()).hexdigest() for p in paths}}
(out / 'source.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')

with (root / 'ops/live-merge.lock').open('a') as lock:
    deadline = time.monotonic() + 10
    while True:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic() > deadline:
                raise SystemExit('合入锁繁忙；未改live，保留旧预检与源码提交')
            time.sleep(.5)
    observed = git(live, 'rev-parse', 'HEAD')
    dirty = git(live, 'status', '--porcelain=v1').splitlines()
    result = subprocess.run(['git', '-C', str(workspace), 'merge-tree', '--write-tree', '--name-only', observed, source],
                            capture_output=True, text=True)
    (out / 'merge-preflight-final.txt').write_text(result.stdout + result.stderr)
    lines = result.stdout.splitlines()
    conflicts = lines[1:lines.index('')] if result.returncode == 1 and '' in lines else []
    ancestor = subprocess.run(['git', '-C', str(live), 'merge-base', '--is-ancestor', source, observed]).returncode == 0
    assert git(live, 'rev-parse', 'HEAD') == observed
    assert git(live, 'status', '--porcelain=v1').splitlines() == dirty
    receipt = {'source': source, 'source_parent': parent, 'observed_live': observed,
               'live_dirty_preserved': dirty, 'merge_tree_exit': result.returncode,
               'conflict_count': len(conflicts), 'conflicts': conflicts,
               'source_is_live_ancestor': ancestor, 'live_unchanged': True,
               'merged': None, 'version': None}
    (out / 'merge-preflight.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in {'conflicts'}}, ensure_ascii=False))

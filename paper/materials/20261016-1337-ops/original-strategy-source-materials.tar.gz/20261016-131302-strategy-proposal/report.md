# 静默猎手策略批次回报

本批20261016-131302-strategy-proposal已核十项原提案，实现并提交一个有固定帧支持的窄子项：生存者单弃牌时显示沙坑及逃离资源快照。源码 **39a3bdb948c13f4d84e2c644c9a08a9a3543c16b**；原提案silent-proposal-2ae7436286228166，原账本silent-0117/0018，实施提案账本silent-0495（proposed）。完整十项原范围均waiting。

**未合入live**。持ops/live-merge.lock核实际live=1ddaba4bca8350969bb2e8dda1265095cc86b61d，只读merge-tree返回1，25个历史冲突，包括版本表、账本、decision-log和历史记录目录迁移。按任务“有冲突就停下回报”停止部署；无实际git merge、无MERGE_HEAD、未提交live知识刷新、未跑合后测试、无版本、无shipped或自然消费声称。live原有五项刷新/记录dirty全部保留。冲突清单见merge-preflight.json及merge-preflight-final.txt。运维可按既有兜底流程核本四路径来源提交；本报告不授权覆盖历史冲突或并行知识。

## 基线与身份

初始干净，HEAD=ca9f61f7396ebdf181843f7099c177d3ca865fae，合main为Already up to date；普通提案批次，无research_request/implementation_request。最终分支HEAD=39a3bdb948c13f4d84e2c644c9a08a9a3543c16b，父提交仍为完整base，仅四路径变更，工作树干净（本批材料在忽略的learner/runs内保留）。最终复核learn.json任务/角色/三锚点/工作树/十proposal_ids与开工时相同。没有子agent、网络、play或其他角色知识学习；不修改账号、模型、运维prompt、key或.env。原生会话turn_context实际model=gpt-6.1-sol、effort=xhigh，见native-model.json；并非只核配置默认值。

## 修改与证据

H1T1F8ML9FUE A10 F33 首试T6的s298405是生存者单弃牌、沙坑2、余1能量，手中唯一普通逃离当前费用1；d291285实际选择弃逃离，s298406确认离手，s298412下轮沙坑1且无逃离、28HP/15挡。新增题面只展示本次弃掉各副本后剩余逃离与当前能量可支付数量，费用未知为null；由模型选择，三个选项全部保留且能resolve，原评分不改。

本局SL第二试多轮均变，保牌整战因果未知；不强制保牌，不预报下轮，不以24/24推演死亡当真必死，不修改SL、药水或终局权重。新增范围仅Silent A10、当前来源/同战/同回合、单个活沙虫/唯一沙坑2、明确单弃及槽位/属性相符。原Prepared沙坑1双弃输出保持。原三帧逐原offset/bytes/SHA/JSON核，原始字节哈希及完整固定状态在提交夹具中。

变更路径：

- agent/src/hand/screens/selection.ts
- agent/src/hand/screens/silent-sandpit-discard.ts
- agent/tests/silent-survivor-sandpit-discard.test.ts
- agent/tests/silent-survivor-sandpit-evidence.json

## 验证

- 生产planSelection到choice.resolve的真实消费者定向：新增生存者及原Prepared共2文件21例，退出0。
- 原两处源码完整原字节保存为.before.txt。撤源后同一固定测试退出1，2例失败/19例通过；finally恢复原补丁后退出0，21例通过。见ablation-results.json、targeted-without-source.log、targeted-restored.log。
- 本分支agent/运行SANDBOX_WORKERS=2 bash tools/test-sandbox.sh：整体exit0，内含生产tsc0；主线程批441文件4123例＋paths批1文件11例，共442文件4134例通过，见sandbox-source.log/.exit。没有超时或重跑；沙箱固定排除项由原脚本保留，未宣称沙箱外完整套件成功。JSON tests.cases=0为定向恢复检查退出码，用例数另列test_counts。
- 提交前gitleaks git --staged --redact：exit0，扫描244859字节、无泄漏；原报告gitleaks-source.json/.log。git diff --check通过。源码提交使用全局身份及实际Codex gpt-6.1-sol署名，无推送。
- 锁内只读预检以最终实际source commit绑定，source非live祖先、live HEAD及dirty读回一致；不是一次失败的真实合入，不需要回退或覆盖刷新。

## 原始证据与资源链

三锚点runs.jsonl均SILENT/A10，code分别d61bf0ec+dirty、5925a43d+dirty、1a0adbaa+dirty；完整当时dirty源码未知，当前核查不冒充当时逐字重放。共用learner/extract_evidence.py提取8流，4324封套逐原offset/bytes/SHA/JSON/身份验证成功；十份原Markdown SHA全部匹配。只核显式run/run_id/state.run_id/fingerprint.run，不把正文提及当所属局。

计数顺序为G8NHLL09DLBX / LYBHQ1X230ZB / H1T1F8ML9FUE：

|流|冻结source_size字节|本批行数|全源坏JSON行|
|---|---:|---|---:|
|states|13496291539|747/478/930|2|
|decisions|1889916865|726/455/844|2|
|sl-attempts|43105164|6/5/9|0|
|run-config|1850737|1/1/1|0|
|run-plans|8498804|3/4/9|0|
|brain|666036610|25/28/49|1|
|runs|346458|1/1/1|0|
|fight-plans|2233957|0/0/0|0|

fight-plans的0行只说明本次截点未选到，不据此说原日志缺失。坏JSON计数属于整条源流，不把坏行当本批样本。各流截点独立冻结，后续追加不进入本次结论；本批没有用旧0行初稿作缺失结论。

当前资源工具在冻结输入重算三局17/17/28战斗窗口，原出口缺失保持未知。G8四次巨兽进76、前三末见4/2/15，末试赢剩1；二幕后胜61→54→52→22，再以22空药死F24。LYB F22/F23胜65→36→6、F29胜42→4、F30前三仅截断、末试实死；T6损12候选未执行。H1 F33两试、F48六试，末战前各赢战保留；F35 max70→64，末休52而F48未过，F49未知。HP净损不等毛伤，SL恢复不等回血或新药。每个资源变动及敌体新增/退场限制见三份*-resource-chain.json。

## 十个原ID的处置

|ID|状态|具体限制或未实现原因|
|---|---|---|
|silent-proposal-1481fe327a22ddeb|waiting|G8 F23耗两药后52→22、F24败；缺保药、替代路线及后置营火实到对照，不能拟留药价格或安全血线。|
|silent-proposal-8e9beeee55eac364|waiting|LYB F29T6损12留10候选未实际执行接续；已选损18留4线虽T7赢而F30死，6血差不足拟终局权重。|
|silent-proposal-ce75cb821e8f2610|waiting|LYB首次挡/暗影/敏捷/Tender局部路径已有；缺全修正组合、首次消费和次轮复原的完整同帧消费者回放。|
|silent-proposal-6ba977a3f01df016|waiting|LYB F30前三尝试截断、末试结15毒仍两敌活；缺替代目标/抽序完整执行与召唤重放SL整线校准。|
|silent-proposal-2097f02b69dacfff|waiting|LYB F29石虫眩晕及甲虫弱后15/16/18可核；缺双敌成长、弱化、眩晕接续的完整消费者误差校准。|
|silent-proposal-49bb659734d555e3|waiting|LYB少损6HP候选未实打，F28锻造/羽毛与未到后火无受控结局；缺同盘后场资源和整场对照。|
|silent-proposal-2ae7436286228166|waiting|生存者沙坑事实子项源码39a3bdb948c13f4d84e2c644c9a08a9a3543c16b已自测提交，但25个历史冲突阻止live合入；原饱和SL候选后继/未来能力收益与整战对照仍缺。|
|silent-proposal-de26499e8385f25b|waiting|H1 F48未赢、F49未到；缺受控留药/换饮时点/另一休息的完整结局及消费者误差归因。|
|silent-proposal-c888545b80180da7|waiting|群蛇蜃景重放窄子项已有live祖先be9577c81a003aff0e69968c928e264f5173da7c；其他修正组合与临时层撤回消费未核齐，不能整体关闭。|
|silent-proposal-3b37b520b22f0eaf|waiting|H1末T4建毒雾/触媒时0毒且下轮未到；基础制品/毒路径存在，但缺匹配后继及后期误差验证。|

各项层/回合、原账本、反例、预期行为及验证方法见proposal.md完整逐项表及assigned-proposals.json；不忽略任何派来ID。实际live祖先局部实现1698adc96ba434a46942321e0237b70657e625b2、608478393b0491c9d77441d06b7a402994987f42、be9577c81a003aff0e69968c928e264f5173da7c已核，仅作局部追溯，不据此整体duplicate/implemented。没有重新登记代码提案或改写原Markdown；code_proposals保留原十个真实CLI ID。

## 账本与运维交接

仅用根learner/ledger.py：新增消费者实施提案silent-0495，status=proposed、by=learner:strategy-proposal；27个原账本仅追加本批proposal/report和waiting追溯；再向0495追加实际源码commit，仍proposed。总29条CLI记录，原claim/首证/先验/evidence/status/version/effect均保持，不重复支持/重复样本或历史复盘。ledger-audit.json验证旧前缀/原字段和27条逐字CLI，ledger-commit.audit.json验证最后实际提交链接。

请运维读取本目录proposal.md、report.md、result.json、source.patch和merge-preflight.json；最终源码39a3bdb948c13f4d84e2c644c9a08a9a3543c16b仅四路径，当前非live祖先。待实际合入后再依原流程补合后检查、唯一发布号、规则双通知及shipped；本批未上线所以未写双通知、eval版本或decision-log上线记录。工作树与失败/撤源/原稿/冻结证据全部保留，不自行回收；原十项的完整等待范围不随本地窄实现关闭。

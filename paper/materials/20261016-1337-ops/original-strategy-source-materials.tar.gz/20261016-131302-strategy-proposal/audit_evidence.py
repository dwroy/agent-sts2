import hashlib
import importlib.util
import json
from pathlib import Path

workspace = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
root = Path('/home/dw/Projects/agent-sts2')
spec = importlib.util.spec_from_file_location('evidence', workspace / 'learner/extract_evidence.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
spec = importlib.util.spec_from_file_location('resources', workspace / 'learner/resource_chain.py')
resources = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resources)

dispatch = json.loads((out / 'dispatch.json').read_text())
runs = dispatch['runs']
manifest = json.loads((out / 'evidence/evidence-manifest.json').read_text())
streams = {}
verified = []
for stream in manifest:
    name = stream['stream']
    path = out / 'evidence' / (name + '.evidence.jsonl')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stream['output_sha256']
    rows = [json.loads(line) for line in path.open()]
    counts = dict.fromkeys(runs, 0)
    with (root / 'logs' / (name + '.jsonl')).open('rb') as source:
        for item in rows:
            assert item['offset'] + item['bytes'] <= stream['source_size']
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert json.loads(raw) == item['row']
            assert extractor.run_identity(item['row']) == item['run_id']
            counts[item['run_id']] += 1
    assert counts == stream['counts']
    streams[name] = rows
    verified.append({'stream': name, 'source_size': stream['source_size'], 'counts': counts,
                     'verified_rows': len(rows), 'invalid_lines': stream['invalid_lines']})
for item in streams['runs']:
    assert item['row']['character'] == 'SILENT'
    assert item['row']['ascension'] == 10

proposals = json.loads((out / 'assigned-proposals.json').read_text())
assert [p['id'] for p in proposals] == dispatch['proposal_ids']
proposal_hashes = []
for p in proposals:
    assert p['character'] == 'silent'
    actual = hashlib.sha256(Path(p['proposal']).read_bytes()).hexdigest()
    assert actual == p['proposal_sha256']
    proposal_hashes.append({'id': p['id'], 'proposal': p['proposal'], 'sha256': actual})
fixture = json.loads((workspace / 'agent/tests/silent-survivor-sandpit-evidence.json').read_text())
by_line = {item['line']: item for item in streams['states']}
for item in fixture:
    actual = by_line[item['line']]
    assert all(item[key] == actual[key] for key in ['line', 'offset', 'bytes', 'sha256', 'run_id', 'row'])

chains = {}
for run in runs:
    starts = {}
    for item in streams['sl-attempts']:
        row = item['row']
        if item['run_id'] == run and row.get('attempt', 1) > 1 and row.get('started_at'):
            starts.setdefault(row.get('floor'), []).append(row['started_at'])
    entries = [{**i['row'], '_line': i['line']} for i in streams['states'] if i['run_id'] == run]
    chain = resources.resource_chain(entries, run, 'silent', starts)
    (out / (run + '-resource-chain.json')).write_text(json.dumps(chain, ensure_ascii=False, indent=2) + '\n')
    chains[run] = [{'sequence': c['sequence'], 'floor': c['floor'], 'entry': c['entry'],
                    'last': c['last'], 'exit': c['exit'], 'end': c['end'],
                    'observed_net_hp_loss': c['observed_net_hp_loss']} for c in chain['combats']]

selected = {}
for item in streams['decisions']:
    row = item['row']
    if item['line'] in {290765, 291285, 291596, 291646}:
        selected[str(item['line'])] = {k: row.get(k) for k in
            ['run_id', 'floor', 'turn', 'chosen', 'expect', 'sl_explore', 'answers']}
        criteria = (row.get('questions', {}).get('plan') or {}).get('criteria', {})
        selected[str(item['line'])]['plans'] = {key: json.loads(value) for key, value in criteria.items()}

result = {'streams': verified, 'total_verified_rows': sum(s['verified_rows'] for s in verified),
          'proposal_hashes': proposal_hashes, 'fixture_frames': [i['line'] for i in fixture],
          'resource_chains': chains, 'decisions': selected}
(out / 'evidence-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_rows': result['total_verified_rows'], 'proposal_hashes': len(proposal_hashes),
                  'fixture_frames': result['fixture_frames'],
                  'combat_windows': {r: len(c) for r, c in chains.items()}}, ensure_ascii=False))

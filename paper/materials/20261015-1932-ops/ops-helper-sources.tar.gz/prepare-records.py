from pathlib import Path
import subprocess,json,hashlib,re,os,tarfile,importlib.util
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-1932';pub=r/'paper/materials/20261015-1932-ops'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
batches=load(r/'ops/codex-ops/learn.json')['batches'];base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
ledger=(r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True);parsed=[(raw,json.loads(raw)) for raw in ledger];all_owned=[];receipts=[];archive_files=[]
for suffix,count,rows,checks in [('-s2',30,8274,35),('',26,6995,41)]:
 bid='20261015-191301'+suffix+'-strategy-proposal';b=batches[bid];report=b['report'];s=Path(report['report']).parent
 assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[]
 assert b['no_change_proposals']['dispositions']==report['proposal_results']
 assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
 assert report['fixes']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
 assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
 native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
 completion=load(s/'completion-check.json');assert completion['base']==report['base'] and completion['git_status']=='' and completion['all_waiting'] and completion['new_source_commits']==[]
 mf=load(s/('delivery-manifest.json' if suffix else 'artifact-manifest.json'))
 for path,ref in mf.items():
  raw=(s/path).read_bytes();assert len(raw)==ref['bytes'] and sha(raw)==ref['sha256'],path
 ev=load(s/'verified-evidence.json');assert ev['total_rows']==rows and sum(sum(x['counts'].values()) for x in ev['streams'])==rows
 runrows=list(ev['runs'].values()) if suffix else [x['row'] for x in ev['runs']]
 assert len(runrows)==6 and all(x['character']=='SILENT' and x['ascension']==10 for x in runrows)
 materials=load(s/('material-checks.json' if suffix else 'observation-checks.json'));assert len(materials['checks'])==checks and all(x['actual']==x['expected'] for x in materials['checks'])
 source=load(s/('source-readback.json' if suffix else 'source-audit.json'));leaves=source['files'] if suffix else source['leaves'];assert len(leaves)==(18 if suffix else 16) and source['base']==report['base'];equal=0
 for x in leaves:
  a=git('show',report['base']+':'+x['path']);z=git('show',source['live']+':'+x['path'])
  assert sha(a)==x['local_sha256' if suffix else 'base_sha256'] and sha(z)==x['live_sha256' if suffix else 'live_commit_sha256']
  if a==z:equal+=1
  else:assert a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai'),x['path']
  if suffix:
   assert x['source_is_live_ancestor'];git('merge-base','--is-ancestor',x['live_leaf_source_commit'],source['live'])
  else:assert x['live_worktree_equals_commit'] and x['live_worktree_sha256']==sha(z)
 assert equal==14
 if not suffix:
  for x in source['ancestry']:
   for target in [report['base'],source['live']]:git('merge-base','--is-ancestor',x['commit'],target)
  consumer=load(s/'selection-consumer-summary.json');assert consumer['segments']==113 and consumer['observed_actions']==659 and consumer['full_candidate_certified']==0 and consumer['F33_statuses']=={'unknown':11,'observed_turn_endpoints':39}
  assert completion['existing_offline_consumer_exit']==0 and completion['ledger_new_rows']==count
 else:
  consumer={'original_existing_audits':[{'run':'8JRE1C4H4Z2W','segments':66,'actions':277},{'run':'YF0LXT1QSTGG','segments':52,'actions':343},{'run':'XP2SL33HT0D9','segments':58,'actions':244}],'scope':'Original report readback only; full candidate results and rollout best remain null.'}
  unavailable=load(s/'comment-equivalence-unavailable.json');assert unavailable['exit_code']==1 and unavailable['equivalence_claim'] is None and not unavailable['dependencies_installed']
  assert completion['ledger_metadata_updates']==count and not completion['ledger_protected_fields_written']
 inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];owned=[raw for raw,row in parsed if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs)]
 assert len(inputs)==len(owned)==count and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
 ids=(s/('ledger-update.out' if suffix else 'ledger-update.log')).read_text().split();assert len(ids)==count and set(ids)=={json.loads(x)['id'] for x in owned};all_owned.extend(owned)
 if not suffix:
  for x in load(s/'ledger-readback.json')['appended_rows']:
   with (r/'paper/materials/learning/ledger.jsonl').open('rb') as f:f.seek(x['offset']);raw=f.read(x['bytes'])
   assert sha(raw)==x['sha256'] and raw in owned
 receipt={'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_completion':completion,'original_manifest_entries_verified':len(mf),'source_leaf_sha_and_live_ancestors_verified':True,'source_leaf_count':len(leaves),'equal_leaves':equal,'historical_name_comment_differences':len(leaves)-equal,'source_text_comparison_only_no_transpile_claim':True,'original_evidence_rows':rows,'original_material_assertions':checks,'material_or_consumer_probes_reexecuted':False,'original_consumer_readback':consumer,'owned_trace_only_ledger_rows':count,'native_gap':'Original learner only checked launcher; ops verified actual native Sol6.1/xhigh, fixed input/lease and workspace-write/no-network without changing or restarting it.','no_source_merge_version_tests_or_game_action':True}
 receipts.append(receipt);write(pub/('s2-batch-readback.json' if suffix else 'batch-readback.json'),receipt)
 files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<350000 and f.suffix in ['.json','.jsonl','.md','.py','.txt','.patch','.log','.out','.err'] and not f.name.startswith('ledger-before')]
 files+=list((s/'original-proposals').glob('*.md'));files+=[s/'evidence/evidence-manifest.json'];files+=[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']];archive_files.extend(files)
assert len(all_owned)==56 and len(set(all_owned))==56
(p/'owned-ledger.jsonl').write_bytes(b''.join(all_owned));old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(x for x in all_owned if x.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 for k in ['claim','first_run','asc','prior','prior_note','prior_runs','evidence','status','version','shipped_at','effect']:assert before[ident].get(k)==after[ident].get(k),(ident,k)
manifest=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted(set(archive_files)):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);manifest.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',manifest)
write(pub/'completion.json',{'batches':[x['batch'] for x in receipts],'waiting_proposals':20,'trace_only_ledger_rows':56,'new_to_HEAD_ledger_rows':len(added.splitlines()),'protected_fold_preserved':True,'original_rows_by_batch':[8274,6995],'overlapping_runs_not_independent_or_unique_samples':True,'original_material_checks_by_batch':[35,41],'no_source_tests_merge_release_dataset_or_game_changes':True,'limits':['All four original offline audit products remain limited to observed endpoints; full candidate attribution/result and actual rollout best uncertified.','S2 original null-terminal AttributeError and missing TypeScript module exit1 retained; final35 material checks do not imply product tests or transpiled equivalence.','Other batch original missing-path/output-truncation/bytecode-placement and material-check-name corrections retained; same-board budget experiment and actual_cast_this_fight remain unknown.','Existing narrow source functions do not close broad proposals, calibration or original learning parents.']})
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
line=f'\n- {at} 运维codex：1932原191301两策略rc0/done/no-source门禁核，各十项共20项waiting；1627干净WT无新源码提交、testsnull/mergednull，不重合/发号/补测。原s2保combat/sl/structure域元数据及skipped原值，不据此冒称实现；两批分别6个Silent A10锚点8274/6995原行、35/41材料断言及三个/一个离线端点审计为原学习者读回，重叠局不合计独立样本，不重跑或当全候选/生产全检/策略收益。18/16源码叶与旧livefe646265逐SHA及真实祖先核，各14同与4/2历史Roy-Dai注释差保持；s2缺typescript模块的转译失败仍unavailable，不称转译等价/tsc通过。56原CLI仅where/note且逐原输入/ID核，claim/首证/prior/evidence/status/version等保护字段不变，不重复CLI；实际native Sol6.1/xhigh/input/lease与原workspace-write/no-network核，旧launcher读取边界/任务high文字保持。原null终态材料脚本首失败、路径/截断/缓存位置准备错误及后修正回执留史；原完整候选结果/成长分源/施放身份/同盘同预算/受控抽序及留药后继未知保持，不据窄功能关闭宽父或新派研究。无新反证/经验/复盘，不刷新论文、不改当前局/账号home模型预算队列prompt，不等待未来事件。证据paper/materials/20261015-1932-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原191301两策略批次各十项继续waiting，共56条CLI仅追溯，未改原知识/状态/版本。原材料核验与有限离线端点覆盖、准备失败及修正均归档；实际原生Sol6.1/xhigh与隔离身份核实，无源码/合入/编号/补测/重复研究或对局操作。回执paper/materials/20261015-1932-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers)
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
dest=p/'final-files';entries=[]
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':entries})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
print(json.dumps({'waiting':20,'ledger_rows':56,'ledger_rows_added_to_HEAD':len(added.splitlines()),'ledger_check':0,'archive_files':len(manifest),'native_verified':True,'paths':len(entries)}))

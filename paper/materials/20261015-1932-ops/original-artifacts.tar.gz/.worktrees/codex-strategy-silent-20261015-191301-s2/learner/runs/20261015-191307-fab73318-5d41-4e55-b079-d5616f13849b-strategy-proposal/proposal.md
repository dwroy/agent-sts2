# 本批静默猎手十项既有提案核验

记录时间：2026-10-15 19:26:00 CST。角色silent，只从本角色日志、原提案和本角色经验核对。
基线：16271871beb0ed3df1a6c997596e5e57faab027a；git merge --no-edit main返回Already up to date；初始工作树干净。
本批是已领取十项提案的普通消费任务，reason=proposal；没有research_request/implementation_request，不承接其他手动专题，也不领取别的队列条目。

以下十项均未发现足够理由新增策略源码，保留waiting。已有子项的真实live祖先只证明各自窄功能，不把整项冒记implemented/duplicate或shipped。
游戏事实只由本批六个静默A10来源局支持，未用其他角色经验或预训练机制补齐。未调整铁甲或任何角色行为。

## silent-proposal-c20b5139dd0dff71：棱柱技能污染与跨轮成长

- 证据：DUZUBAJ3A8GP F27 T4—T5。账本：silent-0168。
- 原始核实：states 274830—274838：T4污染0→3→3→6，能力勒紧不另加；T5火花6、污染0→6→12→18。T5生存者先进入选牌态，不能把中间帧未列污染误认作最终未触发。
- 当前处置：**waiting**。当前 turn-solver 已按技能叠污染并按攻击段计价，rollout 接线包含火花增长；这些局部功能已有。缺原 dirty 运行实际消费的 A10 移动表及毒/挡/污染跨轮联合冻结回放，未定位新的确定性源码差异。
- 旧规则/预期行为及验证：补齐实际移动表和逐轮输入后比较毒、挡、污染、玩家血和敌本体血；保留技能的收益及所有候选，不从9血成本导出强制少打技能。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：experience-update；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-ae9e692d680e3819：抢夺/返还必须保留来源

- 证据：5PM6JAQG6FNQ F39 T4—T6。账本：silent-0183、silent-0005。
- 原始核实：states 274351/274391两试T4玩家均−4力/−4敏；274358失落退场后现场力量不再为负，274362遗忘再次抢夺后敏捷−2。单步法与两步法改变敏捷的幅度不能混用。
- 当前处置：**waiting**。负属性参与当前伤害/挡计算的路径已有；现帧总力量/敏捷不等于逐来源被夺累计量。缺带来源归属、其他属性来源及死亡/退场关联的完整冻结模型输入，不能安全补一个返还总负属性的规则；另一杀序后继也未知。
- 旧规则/预期行为及验证：先保留逐来源累计量及生命周期证据，再冻结同轮毒杀、返还和下一轮重抢；不得从当前总负值反推被夺量，不规定固定杀序。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：experience-update；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-52f1e1bd2e7db0ed：下水道蚌当前进阶与成长

- 证据：CA5KE8GFJ9X2 F13 T1—T5。账本：silent-0231。
- 原始核实：states 273238/273252/273263：同喷水力量0/4/8、攻击11/15/19；273254/273268弱后11/14。末轮2HP、10挡对14，缺2的算式与死亡截断实扣分列。覆甲9/9/8/7/6仅是观察序列。
- 当前处置：**waiting**。monsterHpAt/moveDamageAt 当前精确进阶路径无五样本门槛，房间成本 ROOM_COST_MIN_N=5 已分开。缺原 dirty 实际移动表及覆甲减层条件的独立完整输入；没有证据要求重写现有当轮公式。
- 旧规则/预期行为及验证：使用固定A10移动表核加压与弱，补覆甲条件隔离样本；怪物事实首样本可用、房间成本五样本要求保持，不把本局资源损失硬编码为房间代价。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：experience-update；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-6dd8bbff876be528：电击机器人逐实体成长

- 证据：5PM6JAQG6FNQ F38 T3—T4。账本：silent-0233、silent-0209。
- 原始核实：states 274308/274313：最大血23的电击力量2→4、攻击17→19，高电压均2，索引4→3。T3后玩家61→31；另一杀序只是未执行候选。
- 当前处置：**waiting**。rollout 已读取 HIGH_VOLTAGE_POWER 并在敌方轮末增长，通用固定测试也覆盖该增长路径。类型ID与索引不能认证召唤代际；仍缺新同类替换与累计量归属的冻结输入、当时实际A10移动表，不能将局部growth路径当作整项完成。
- 旧规则/预期行为及验证：冻结新同类召唤/退场连续帧并证明新实体不继承旧计数；固定实盘当前攻击，不能将未执行先杀线的候选少损27称为后场必胜。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：experience-update；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-578e415a259e6835：沙虫原答/护栏/SL与实际资源分账

- 证据：8JRE1C4H4Z2W F33 T2/T5/T11；F17 T6。账本：silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016。
- 原始核实：decisions 270216/270282完整指纹相同；现有审计读回T2首/三试实损3/15、净扣10/17。末试T11终态端点净扣玩家5，37−22=15仅是显示意图差；整轮敌净扣36与最后结束回合敌净扣24是不同区间。
- 当前处置：**waiting**。候选快照、护栏差值、单动作回执、相邻观测与终态/整轮端点已由真实live祖先实现。缺抽弃牌/护栏/SL切断后的完整候选归属及逐来源毒挡兑现联合校准，原线整战反事实未知，不把这些窄子项登记为整提案duplicate。
- 旧规则/预期行为及验证：复用已有离线审计，新增证据须同时保留重问边界、完整候选未知及独立后移局验证；不拟能力优先级、血价系数或SL禁令。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：experience-update；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-c0767768bf6a7ab1：实验体全败探索的资源代价

- 证据：YF0LXT1QSTGG F48 第二/三试 T1；F33反例。账本：silent-0079。
- 原始核实：decisions 271309/271348同指纹；states 277327→277337与277366→277373实损0/9、敌净扣45/38。271354在后续问题中结束回合，不能把首题候选与整轮当同一执行。F33实际SL胜利反对否定所有探索。
- 当前处置：**waiting**。原答/替换预测与分段执行追溯已有，当前三局消费者仍不认证整条候选。缺未执行续步及完整替代线资源/胜负对照与跨重问归属，不能据同轮劣化设SL惩罚或禁止探索。
- 旧规则/预期行为及验证：以冻结端点对齐原答/替换/覆盖重放，后移独立A10整战比较；保留F33成功探索及F48恢复防御仍失败的反例。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：postmortem；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-a46bdb7fe711d79a：实验体阶段、零毒与已建能力

- 证据：YF0LXT1QSTGG F48 末试 T3—T5。账本：silent-0021、silent-0027、silent-0028、silent-0085。
- 原始核实：states 277512/277513：111血相末4HP/4毒→212血新相/零毒；277519触媒2已建但零毒。277523→277526敏捷5→6而既有挡仍23；197→160净扣37，18HP面对44−23=21，缺3。
- 当前处置：**waiting**。当前阶段快照实际live源码8698c581已覆盖本帧HP/毒/已建与持有；离线区间也能保留阶段变化。缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准，不将快照功能当整个提案完成。
- 旧规则/预期行为及验证：保留已建毒雾仍败、能力后取得不倒补既有挡的反例；补来源与下一轮事实之前保持排序，不强制先手能力或未来必抽毒牌。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：postmortem；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-1044224808015e5c：双蟹零胜并列的SL血价

- 证据：XP2SL33HT0D9 F33 首/二试 T3、首/末试 T1。账本：silent-0079。
- 原始核实：decisions 271992/272040同指纹；审计T3实损9/14、敌净扣24/27。271982/272195同指纹；T1端点实损2/10、净扣25/34，同时手里剑增加力量。272076的21/24→23/24是同题预测，不能报作实打差。
- 当前处置：**waiting**。B2全败与当轮成本已在原日志并列，现有审计保留预测/观测区别。缺原线与换线的独立完整后继、受控随机池和整战结果，无法验证低当轮损失优先的新排序；当轮配对不替代胜率校准。
- 旧规则/预期行为及验证：未来按独立局而非六次SL分组，保留成长收益并比较可活窗口/输出；无新增支持时沿用现有探索门槛，不填全局HP惩罚常数。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：postmortem；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-7cbc6005db712ba9：双蟹朝向、临时减力与兑现窗口

- 证据：XP2SL33HT0D9 F33 末试 T2—T5。账本：silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242。
- 原始核实：states 278236/278237/278242爪力量0→−9→0；T2轮初14挡、斗篷后20且零损。278249/278252/278253火箭57→38→28；四敏脆弱下偏折/防御各6挡，末轮毒实扣3+7=10。
- 当前处置：**waiting**。朝向、弱、临时减力恢复、T2赠挡及敏捷时点的现有模型与观察参考已覆盖若干子项。缺逐候选贡献拆分、完整执行绑定及条件联合校准，不能因公式已有就把整提案duplicate。
- 旧规则/预期行为及验证：逐来源对齐现场已有挡/新增挡、朝向/弱、已结毒/尚存毒、敏捷获得顺序；本批只核A10当前帧，不额外宣称早期两局或升级条件已重新验证。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：postmortem；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

## silent-proposal-c59f592f1427a67e：综合机制、SL与跨房资源宽提案

- 证据：YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5。账本：silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242。
- 原始核实：上述同指纹端点、实验体零毒触媒/敏捷时点、双蟹14挡/临减/朝向均逐帧核；沙虫终态同时保留净损5与意图差15。全部来源局是6个独立A10局，不能充作原101局机制分母。
- 当前处置：**waiting**。已有在线候选/回执与离线端点工具能消费本批局部材料。六锚点不覆盖原101局历史；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准，宽项继续waiting。
- 旧规则/预期行为及验证：沿原提案拆分已有子项与未验证范围；不重做全历史、不给路线/休息/留药设置阈值，不把报告完成称经验入库或大脑采用。
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：experience-update；实现任务：strategy-proposal；本批 code-proposals:silent-proposal-c20b5139dd0dff71,silent-proposal-ae9e692d680e3819,silent-proposal-52f1e1bd2e7db0ed,silent-proposal-6dd8bbff876be528,silent-proposal-578e415a259e6835,silent-proposal-c0767768bf6a7ab1,silent-proposal-a46bdb7fe711d79a,silent-proposal-1044224808015e5c,silent-proposal-7cbc6005db712ba9,silent-proposal-c59f592f1427a67e:306。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。

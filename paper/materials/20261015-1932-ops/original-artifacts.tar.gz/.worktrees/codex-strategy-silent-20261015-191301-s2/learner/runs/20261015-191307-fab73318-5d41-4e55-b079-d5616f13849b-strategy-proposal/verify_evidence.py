import collections
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract', Path.cwd() / 'learner/extract_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
dispatch = json.loads((OUT / 'dispatch.json').read_text())
allowed = set(dispatch['runs'])
manifest = json.loads((OUT / 'evidence/evidence-manifest.json').read_text())
verified = []
states = {}
decisions = {}
runs = {}
for stream in manifest:
    name = stream['stream']
    count = collections.Counter()
    digest = hashlib.sha256()
    with (OUT / 'evidence' / (name + '.evidence.jsonl')).open('rb') as handle, \
            (Path('/home/dw/Projects/agent-sts2/logs') / (name + '.jsonl')).open('rb') as source:
        for encoded in handle:
            digest.update(encoded)
            item = json.loads(encoded)
            source.seek(item['offset'])
            raw = source.read(item['bytes'])
            assert len(raw) == item['bytes']
            assert hashlib.sha256(raw).hexdigest() == item['sha256']
            assert item['offset'] + item['bytes'] <= stream['source_size']
            row = json.loads(raw)
            assert row == item['row']
            run = module.run_identity(row)
            assert run in allowed and item['run_id'] == run
            count[run] += 1
            if name == 'states':
                state = row['state']
                assert state['run']['character_id'].lower() == 'silent'
                assert state['run']['ascension'] == 10
                states[item['line']] = item
            elif name == 'decisions':
                decisions[item['line']] = item
            elif name == 'runs':
                assert row['character'].lower() == 'silent' and row['ascension'] == 10
                runs[run] = row
    assert digest.hexdigest() == stream['output_sha256']
    assert {run: count[run] for run in allowed} == stream['counts']
    verified.append({'stream': name, 'rows': sum(count.values()), 'counts': dict(count),
        'source_size': stream['source_size'], 'sha_offset_identity_verified': True})

def powers(holder):
    return {p['power_id']: p['amount'] for p in holder.get('powers', [])}

def compact(item):
    state = item['row']['state']
    combat = state.get('combat') or {}
    player = combat.get('player') or {}
    return {'line': item['line'], 'offset': item['offset'], 'bytes': item['bytes'],
        'sha256': item['sha256'], 'run_id': item['run_id'],
        'floor': state['run']['floor'], 'turn': state['turn'], 'screen': state['screen'],
        'hp': player.get('current_hp', state['run'].get('current_hp')), 'block': player.get('block'),
        'cards_played': player.get('cards_played_this_turn'), 'powers': powers(player),
        'enemies': [{'id': e['enemy_id'], 'index': e['index'], 'hp': e['current_hp'],
            'max_hp': e['max_hp'], 'block': e['block'], 'powers': powers(e), 'move': e.get('move_id'),
            'attack': sum((i.get('damage') or 0) * (i.get('hits') or 1) for i in e.get('intents', []))}
            for e in combat.get('enemies', [])]}

floors = {'DUZUBAJ3A8GP': {27}, 'CA5KE8GFJ9X2': {13}, '5PM6JAQG6FNQ': {38, 39},
    '8JRE1C4H4Z2W': {17, 33}, 'YF0LXT1QSTGG': {33, 48}, 'XP2SL33HT0D9': {33}}
with (OUT / 'state-facts.jsonl').open('w') as handle:
    for item in states.values():
        if item['row']['state']['run']['floor'] in floors[item['run_id']]:
            handle.write(json.dumps(compact(item), ensure_ascii=False) + '\n')

excluded = []
for run in ['8JRE1C4H4Z2W', 'YF0LXT1QSTGG', 'XP2SL33HT0D9']:
    selected = []
    for item in decisions.values():
        row = item['row']
        if item['run_id'] != run or row.get('floor') not in floors[run]:
            continue
        if not row.get('decision_id') or not row.get('observed_ts'):
            excluded.append({'run_id': run, 'line': item['line'], 'reason': '无 decision_id 或 observed_ts 的元数据行'})
            continue
        selected.append({**row, '_line': item['line'], '_source_sha256': item['sha256']})
    selected.sort(key=lambda row: row['observed_ts'])
    ss = [{**item['row'], '_line': item['line'], '_source_sha256': item['sha256']}
        for item in states.values() if item['run_id'] == run and item['row']['state']['run']['floor'] in floors[run]]
    (OUT / (run + '-audit-input.json')).write_text(json.dumps({
        'run': runs[run], 'decisions': selected, 'states': ss}, ensure_ascii=False) + '\n')
(OUT / 'audit-input-exclusions.json').write_text(json.dumps(excluded, ensure_ascii=False, indent=2) + '\n')
(OUT / 'verified-evidence.json').write_text(json.dumps({'streams': verified, 'total_rows': sum(x['rows'] for x in verified),
    'runs': runs, 'semantic_scope': '逐行字节/身份校验；游戏语义仅核本批指定局面'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'streams': verified, 'total_rows': sum(x['rows'] for x in verified),
    'audit_metadata_exclusions': len(excluded)}, ensure_ascii=False))

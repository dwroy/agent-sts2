# 静默猎手策略消费报告

记录时间：2026-10-15 19:26:00 CST。批次20261015-191301-s2-strategy-proposal。

本批十项均waiting：已复核现有局部实现与原实盘端点，未发现证据充分、尚未实现的新源码改动。没有提交、合入、版本或新经验入库；不冒报shipped或模型自然采用。

## 身份与基线

learn.json仅读取本批行，task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配，十个proposal_ids完整处理，proposal_repair/research_request/implementation_request均不存在。普通研究请求文件仍绑定另一批20261010-150327，不替代本批身份；未读其他专题正文。
初始git status --short为空；main合并返回Already up to date。base=16271871beb0ed3df1a6c997596e5e57faab027a。本批没有改变HEAD或源码/知识。
来源局：DUZUBAJ3A8GP,5PM6JAQG6FNQ,CA5KE8GFJ9X2,8JRE1C4H4Z2W,YF0LXT1QSTGG,XP2SL33HT0D9；runs.jsonl与所有抽取state均核角色silent/A10，六局失败结果不作为策略因果结论。run-config六条都带dirty，列有刷新的知识文件，现存Git树不能冒称当时实际读取的知识快照。
本会话不派下级agent，不联网、不运行play、不读凭据、游戏二进制或其他角色知识，不修改调度身份。任务文字要求high，原生请求的实际模型/推理强度未由本任务独立读回，未据文字宣称完成运行切换。

## 冻结证据与校验范围

使用指定extract_evidence.py入口，八流共8274条。每条offset/bytes/SHA已重新向只读源文件读取校验，row原值与显式所属身份一致；states另核角色及进阶。逐行字节校验不等于对全部行做游戏语义审计，语义范围是proposal.md列明的局面。

| 流 | 所属行数 | 冻结source_size字节 |
| --- | ---: | ---: |
| states | 4062 | 13110025139 |
| decisions | 3941 | 1640288975 |
| sl-attempts | 38 | 40791204 |
| run-config | 6 | 1774491 |
| run-plans | 33 | 8127041 |
| brain | 188 | 593928982 |
| runs | 6 | 336816 |
| fight-plans | 0 | 2233957 |

evidence/evidence-manifest.json保存各局计数、源截点、输出SHA与非法/不完整行数；verified-evidence.json保存独立核验。fight-plans本截点0条，只说明此截点未选中所属行，不推断原日志缺失；run-plans由run字段识别，实际33条，未重写或覆盖任何旧零行报告。
原提案十份Markdown均存在且字节SHA与专用队列一致；proposal-history.json和proposals-folded.json保留原始历史/本批视图；没有读取其他提案队列范围。账本原值保存在ledger-before.json。

## 实际消费者与源码现状

固定单局原始输入通过现有learner/audit-selection.ts消费，三个命令退出码均0。输入保留原始_line、SHA与observed_ts/fingerprint，按原行号而非过滤后重编号关联；无decision_id/observed_ts的元数据排除另存audit-input-exclusions.json。
8JRE分析F17/F33，66个候选段、277个动作；YF分析F33/F48，52段、343动作；XP分析F33，58段、244动作。它们是离线证据读回，非在线自然消费、整线完整执行、生产全套或收益验证。
现有工具读回沙虫T2首/三试实损3/15、净扣10/17；双蟹T3首/二试实损9/14、净扣24/27。T1的原帧端点另核YF损0/9与净扣45/38，XP损2/10与净扣25/34，不把首个输入动作当作已经认证的完整回合开场。所有段actual_full_candidate_result/actual_rollout_best仍null。
实验体换相4HP/4毒→212HP/零毒、触媒2/零毒、敏捷5→6时挡仍23均核；末T5本体197→160净扣37，18HP不足44−23，仅得缺3算式。沙虫终态实际5→0与显示37−22=15分列，整轮净扣36与结束动作净扣24不可混作一个窗口。

核对18个源码叶及各自实际live祖先，live读回fe6462651b593b9831581c088deface9957a404f。14叶字节相同，4叶仅历史Roy/Dai注释文字差异，完整diff保存在live-source.diff.patch；没有覆盖这些并行差异。尝试调用本地typescript转译比较时缺包，未安装依赖，未宣称转译等价或类型检查通过；本结论限于保存的文本diff。

| 已有窄功能源码 | 实际live祖先commit |
| --- | --- |
| agent/src/reflex/silent-selection-audit.ts | 05cd292c6f01bb31e406473d3a9843e659d62b93 |
| agent/src/reflex/silent-selection-dispatch.ts | bade647f9fe4c9103b40e2f26b26296692ad24b7 |
| agent/src/reflex/silent-hp-guard-audit.ts | a8b1f8be153fe4f3a34146117546c2178f2e446b |
| agent/src/reflex/silent-phase-current.ts | 8698c581dac6c7e957f50a381586960a6d0c9b57 |
| learner/lib/selection-execution.ts | cf72bd21148059f111f760cc98a727369e34a47e |
| learner/lib/selection-observation.ts | cf72bd21148059f111f760cc98a727369e34a47e |
| learner/lib/selection-terminal.ts | 04921bd785ac6838066522f91ea0bb6ab95cb6a1 |
| learner/lib/selection-turn.ts | 9b87d54f097d84521152e6cca8d6072af8140394 |

完整18叶SHA、Git blob与祖先检验见source-readback.json。已有快照、单动作回执、相邻/终态/整轮端点工具不等于逐来源贡献、整候选归属或联合校准已完成。现有DB精确进阶HP/攻击首样本路径与房间成本五样本门槛分别存在，本批没有新建硬编码怪物数值。

## 十项处置

| 提案ID | 状态 | 账本ID |
| --- | --- | --- |
| silent-proposal-c20b5139dd0dff71 | waiting | silent-0168 |
| silent-proposal-ae9e692d680e3819 | waiting | silent-0183、silent-0005 |
| silent-proposal-52f1e1bd2e7db0ed | waiting | silent-0231 |
| silent-proposal-6dd8bbff876be528 | waiting | silent-0233、silent-0209 |
| silent-proposal-578e415a259e6835 | waiting | silent-0005、silent-0006、silent-0018、silent-0079、silent-0019、silent-0020、silent-0021、silent-0125、silent-0023、silent-0027、silent-0046、silent-0016 |
| silent-proposal-c0767768bf6a7ab1 | waiting | silent-0079 |
| silent-proposal-a46bdb7fe711d79a | waiting | silent-0021、silent-0027、silent-0028、silent-0085 |
| silent-proposal-1044224808015e5c | waiting | silent-0079 |
| silent-proposal-7cbc6005db712ba9 | waiting | silent-0021、silent-0005、silent-0007、silent-0063、silent-0065、silent-0241、silent-0242 |
| silent-proposal-c59f592f1427a67e | waiting | silent-0005、silent-0006、silent-0019、silent-0020、silent-0021、silent-0028、silent-0027、silent-0079、silent-0046、silent-0085、silent-0060、silent-0063、silent-0065、silent-0062、silent-0039、silent-0013、silent-0011、silent-0023、silent-0018、silent-0087、silent-0241、silent-0242 |

逐项证据层/回合、反例、现状、缺数据、预期行为、验证及回退全部见同目录proposal.md。具体理由亦在result.json的proposal_results。没有把宽提案缩成局部功能后标duplicate；没有新增CLI提案ID或改原提案文档。
现有经验里支持总数/跨进阶范围只作为原记录，本批未重新验证原101局历史、未覆盖全部历史分母。未来如要改SL或价值排序，需按独立局分训练/后移验证，不能把同局六次SL当六个独立样本。本批没有新发现必须推翻现有经验的反证；原反例与未知不删除。

## 核验、失败与记录

本次35项材料一致性核验通过，material-checks.json及material-checks-v3.out留据。它们核固定原帧/既有消费者输出，不是tsc/vitest或新增策略的撤源码红绿。
初次材料脚本访问null终态字段时AttributeError，原check_materials.initial.txt、material-checks.err/out完整保留；只修临时分析脚本的空值读取，31项版通过后，补四项T1端点核验到35项，未降低原断言。几次源码路径猜测未命中，随后按rg --files定位到learner/lib；未将路径准备错误称产品缺陷。typescript模块缺失的转译准备失败另存comment-equivalence-unavailable.json，不作生产检查失败或成功声明。
没有源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null。未运行沙箱生产测试、未提交、未执行live合并、未新增eval版本或双通知；gitleaks提交前扫描不适用，因为没有提交。工作树应保持干净，最终自检见completion-check.json。
只经根目录ledger.py update给原账本追加本报告/提案追溯链接及说明，by=learner:strategy-proposal；不修改claim/首证/证据/既有status/version，不把既有shipped降级或自行再标shipped。追加回执见ledger-update.out。专用队列处置交最终JSON由原调度器消费，不直接改队列/learn.json。

本批fixes=[]、merged=null、HEAD不变；原提案与宽父要求继续开放。后续experience-update或独立策略实现及自然消费者读回不由这份报告代替。

import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
dispatch = json.loads((OUT / 'dispatch.json').read_text())
proposals = json.loads((OUT / 'proposals-folded.json').read_text())
source = json.loads((OUT / 'source-readback.json').read_text())
verified = json.loads((OUT / 'verified-evidence.json').read_text())
checks = json.loads((OUT / 'material-checks.json').read_text())
assert checks['count'] == 35
timestamp = subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S %Z'], text=True).strip()
print(timestamp)
details = [
    ('c20b5139dd0dff71', '棱柱技能污染与跨轮成长', 'DUZUBAJ3A8GP F27 T4—T5',
     'states 274830—274838：T4污染0→3→3→6，能力勒紧不另加；T5火花6、污染0→6→12→18。T5生存者先进入选牌态，不能把中间帧未列污染误认作最终未触发。',
     '当前 turn-solver 已按技能叠污染并按攻击段计价，rollout 接线包含火花增长；这些局部功能已有。缺原 dirty 运行实际消费的 A10 移动表及毒/挡/污染跨轮联合冻结回放，未定位新的确定性源码差异。',
     '补齐实际移动表和逐轮输入后比较毒、挡、污染、玩家血和敌本体血；保留技能的收益及所有候选，不从9血成本导出强制少打技能。'),
    ('ae9e692d680e3819', '抢夺/返还必须保留来源', '5PM6JAQG6FNQ F39 T4—T6',
     'states 274351/274391两试T4玩家均−4力/−4敏；274358失落退场后现场力量不再为负，274362遗忘再次抢夺后敏捷−2。单步法与两步法改变敏捷的幅度不能混用。',
     '负属性参与当前伤害/挡计算的路径已有；现帧总力量/敏捷不等于逐来源被夺累计量。缺带来源归属、其他属性来源及死亡/退场关联的完整冻结模型输入，不能安全补一个返还总负属性的规则；另一杀序后继也未知。',
     '先保留逐来源累计量及生命周期证据，再冻结同轮毒杀、返还和下一轮重抢；不得从当前总负值反推被夺量，不规定固定杀序。'),
    ('52f1e1bd2e7db0ed', '下水道蚌当前进阶与成长', 'CA5KE8GFJ9X2 F13 T1—T5',
     'states 273238/273252/273263：同喷水力量0/4/8、攻击11/15/19；273254/273268弱后11/14。末轮2HP、10挡对14，缺2的算式与死亡截断实扣分列。覆甲9/9/8/7/6仅是观察序列。',
     'monsterHpAt/moveDamageAt 当前精确进阶路径无五样本门槛，房间成本 ROOM_COST_MIN_N=5 已分开。缺原 dirty 实际移动表及覆甲减层条件的独立完整输入；没有证据要求重写现有当轮公式。',
     '使用固定A10移动表核加压与弱，补覆甲条件隔离样本；怪物事实首样本可用、房间成本五样本要求保持，不把本局资源损失硬编码为房间代价。'),
    ('6dd8bbff876be528', '电击机器人逐实体成长', '5PM6JAQG6FNQ F38 T3—T4',
     'states 274308/274313：最大血23的电击力量2→4、攻击17→19，高电压均2，索引4→3。T3后玩家61→31；另一杀序只是未执行候选。',
     'rollout 已读取 HIGH_VOLTAGE_POWER 并在敌方轮末增长，通用固定测试也覆盖该增长路径。类型ID与索引不能认证召唤代际；仍缺新同类替换与累计量归属的冻结输入、当时实际A10移动表，不能将局部growth路径当作整项完成。',
     '冻结新同类召唤/退场连续帧并证明新实体不继承旧计数；固定实盘当前攻击，不能将未执行先杀线的候选少损27称为后场必胜。'),
    ('578e415a259e6835', '沙虫原答/护栏/SL与实际资源分账', '8JRE1C4H4Z2W F33 T2/T5/T11；F17 T6',
     'decisions 270216/270282完整指纹相同；现有审计读回T2首/三试实损3/15、净扣10/17。末试T11终态端点净扣玩家5，37−22=15仅是显示意图差；整轮敌净扣36与最后结束回合敌净扣24是不同区间。',
     '候选快照、护栏差值、单动作回执、相邻观测与终态/整轮端点已由真实live祖先实现。缺抽弃牌/护栏/SL切断后的完整候选归属及逐来源毒挡兑现联合校准，原线整战反事实未知，不把这些窄子项登记为整提案duplicate。',
     '复用已有离线审计，新增证据须同时保留重问边界、完整候选未知及独立后移局验证；不拟能力优先级、血价系数或SL禁令。'),
    ('c0767768bf6a7ab1', '实验体全败探索的资源代价', 'YF0LXT1QSTGG F48 第二/三试 T1；F33反例',
     'decisions 271309/271348同指纹；states 277327→277337与277366→277373实损0/9、敌净扣45/38。271354在后续问题中结束回合，不能把首题候选与整轮当同一执行。F33实际SL胜利反对否定所有探索。',
     '原答/替换预测与分段执行追溯已有，当前三局消费者仍不认证整条候选。缺未执行续步及完整替代线资源/胜负对照与跨重问归属，不能据同轮劣化设SL惩罚或禁止探索。',
     '以冻结端点对齐原答/替换/覆盖重放，后移独立A10整战比较；保留F33成功探索及F48恢复防御仍失败的反例。'),
    ('a46bdb7fe711d79a', '实验体阶段、零毒与已建能力', 'YF0LXT1QSTGG F48 末试 T3—T5',
     'states 277512/277513：111血相末4HP/4毒→212血新相/零毒；277519触媒2已建但零毒。277523→277526敏捷5→6而既有挡仍23；197→160净扣37，18HP面对44−23=21，缺3。',
     '当前阶段快照实际live源码8698c581已覆盖本帧HP/毒/已建与持有；离线区间也能保留阶段变化。缺下一轮增段、逐阶段逐来源收益与完整候选执行的联合校准，不将快照功能当整个提案完成。',
     '保留已建毒雾仍败、能力后取得不倒补既有挡的反例；补来源与下一轮事实之前保持排序，不强制先手能力或未来必抽毒牌。'),
    ('1044224808015e5c', '双蟹零胜并列的SL血价', 'XP2SL33HT0D9 F33 首/二试 T3、首/末试 T1',
     'decisions 271992/272040同指纹；审计T3实损9/14、敌净扣24/27。271982/272195同指纹；T1端点实损2/10、净扣25/34，同时手里剑增加力量。272076的21/24→23/24是同题预测，不能报作实打差。',
     'B2全败与当轮成本已在原日志并列，现有审计保留预测/观测区别。缺原线与换线的独立完整后继、受控随机池和整战结果，无法验证低当轮损失优先的新排序；当轮配对不替代胜率校准。',
     '未来按独立局而非六次SL分组，保留成长收益并比较可活窗口/输出；无新增支持时沿用现有探索门槛，不填全局HP惩罚常数。'),
    ('7cbc6005db712ba9', '双蟹朝向、临时减力与兑现窗口', 'XP2SL33HT0D9 F33 末试 T2—T5',
     'states 278236/278237/278242爪力量0→−9→0；T2轮初14挡、斗篷后20且零损。278249/278252/278253火箭57→38→28；四敏脆弱下偏折/防御各6挡，末轮毒实扣3+7=10。',
     '朝向、弱、临时减力恢复、T2赠挡及敏捷时点的现有模型与观察参考已覆盖若干子项。缺逐候选贡献拆分、完整执行绑定及条件联合校准，不能因公式已有就把整提案duplicate。',
     '逐来源对齐现场已有挡/新增挡、朝向/弱、已结毒/尚存毒、敏捷获得顺序；本批只核A10当前帧，不额外宣称早期两局或升级条件已重新验证。'),
    ('c59f592f1427a67e', '综合机制、SL与跨房资源宽提案', 'YF0LXT1QSTGG F48 T1/T3—T5；XP2SL33HT0D9 F33 T1—T5',
     '上述同指纹端点、实验体零毒触媒/敏捷时点、双蟹14挡/临减/朝向均逐帧核；沙虫终态同时保留净损5与意图差15。全部来源局是6个独立A10局，不能充作原101局机制分母。',
     '已有在线候选/回执与离线端点工具能消费本批局部材料。六锚点不覆盖原101局历史；缺逐来源资源、完整候选归属、受控路线/留药后继及独立联合校准，宽项继续waiting。',
     '沿原提案拆分已有子项与未验证范围；不重做全历史、不给路线/休息/留药设置阈值，不把报告完成称经验入库或大脑采用。'),
]
assert {f'silent-proposal-{x[0]}' for x in details} == set(dispatch['proposal_ids'])
results = []
sections = []
for suffix, title, location, evidence, reason, validation in details:
    ident = 'silent-proposal-' + suffix
    item = proposals[ident]
    results.append({'id': ident, 'state': 'waiting', 'reason': reason})
    sections.append(f'''## {ident}：{title}

- 证据：{location}。账本：{'、'.join(item['ledger'])}。
- 原始核实：{evidence}
- 当前处置：**waiting**。{reason}
- 旧规则/预期行为及验证：{validation}
- 反例与限制：只认可上述观测与原提案保存的反例；未选线、跨候选因果及未观察条件保持未知。同存档SL不是独立局，不拟新参数。
- 来源任务：{item['source_task']}；实现任务：strategy-proposal；本批 {dispatch.get('key')}。原Markdown路径/SHA见proposal-inputs.json；不重写原文或另造提案ID。
- 回退：本批无源码/知识/规则修改；没有可回退的生产提交。后续实现按独立提交、撤源码红/恢复绿及沙箱入口验证，再按实际live流程登记。
''')

proposal_text = f'''# 本批静默猎手十项既有提案核验

记录时间：{timestamp}。角色silent，只从本角色日志、原提案和本角色经验核对。
基线：{source['base']}；git merge --no-edit main返回Already up to date；初始工作树干净。
本批是已领取十项提案的普通消费任务，reason=proposal；没有research_request/implementation_request，不承接其他手动专题，也不领取别的队列条目。

以下十项均未发现足够理由新增策略源码，保留waiting。已有子项的真实live祖先只证明各自窄功能，不把整项冒记implemented/duplicate或shipped。
游戏事实只由本批六个静默A10来源局支持，未用其他角色经验或预训练机制补齐。未调整铁甲或任何角色行为。

''' + '\n'.join(sections)
(OUT / 'proposal.md').write_text(proposal_text)

stream_table = '\n'.join(f"| {x['stream']} | {x['rows']} | {x['source_size']} |" for x in verified['streams'])
source_table = '\n'.join(f"| {x['path']} | {x['live_leaf_source_commit']} |" for x in source['files'] if any(s in x['path'] for s in ['selection-', 'phase-current', 'hp-guard']))
result_table = '\n'.join(f"| {ident} | waiting | {'、'.join(proposals[ident]['ledger'])} |" for ident in dispatch['proposal_ids'])
report = f'''# 静默猎手策略消费报告

记录时间：{timestamp}。批次20261015-191301-s2-strategy-proposal。

本批十项均waiting：已复核现有局部实现与原实盘端点，未发现证据充分、尚未实现的新源码改动。没有提交、合入、版本或新经验入库；不冒报shipped或模型自然采用。

## 身份与基线

learn.json仅读取本批行，task=strategy-proposal、character=silent、reason=proposal、工作树精确匹配，十个proposal_ids完整处理，proposal_repair/research_request/implementation_request均不存在。普通研究请求文件仍绑定另一批20261010-150327，不替代本批身份；未读其他专题正文。
初始git status --short为空；main合并返回Already up to date。base={source['base']}。本批没有改变HEAD或源码/知识。
来源局：{','.join(dispatch['runs'])}；runs.jsonl与所有抽取state均核角色silent/A10，六局失败结果不作为策略因果结论。run-config六条都带dirty，列有刷新的知识文件，现存Git树不能冒称当时实际读取的知识快照。
本会话不派下级agent，不联网、不运行play、不读凭据、游戏二进制或其他角色知识，不修改调度身份。任务文字要求high，原生请求的实际模型/推理强度未由本任务独立读回，未据文字宣称完成运行切换。

## 冻结证据与校验范围

使用指定extract_evidence.py入口，八流共{verified['total_rows']}条。每条offset/bytes/SHA已重新向只读源文件读取校验，row原值与显式所属身份一致；states另核角色及进阶。逐行字节校验不等于对全部行做游戏语义审计，语义范围是proposal.md列明的局面。

| 流 | 所属行数 | 冻结source_size字节 |
| --- | ---: | ---: |
{stream_table}

evidence/evidence-manifest.json保存各局计数、源截点、输出SHA与非法/不完整行数；verified-evidence.json保存独立核验。fight-plans本截点0条，只说明此截点未选中所属行，不推断原日志缺失；run-plans由run字段识别，实际33条，未重写或覆盖任何旧零行报告。
原提案十份Markdown均存在且字节SHA与专用队列一致；proposal-history.json和proposals-folded.json保留原始历史/本批视图；没有读取其他提案队列范围。账本原值保存在ledger-before.json。

## 实际消费者与源码现状

固定单局原始输入通过现有learner/audit-selection.ts消费，三个命令退出码均0。输入保留原始_line、SHA与observed_ts/fingerprint，按原行号而非过滤后重编号关联；无decision_id/observed_ts的元数据排除另存audit-input-exclusions.json。
8JRE分析F17/F33，66个候选段、277个动作；YF分析F33/F48，52段、343动作；XP分析F33，58段、244动作。它们是离线证据读回，非在线自然消费、整线完整执行、生产全套或收益验证。
现有工具读回沙虫T2首/三试实损3/15、净扣10/17；双蟹T3首/二试实损9/14、净扣24/27。T1的原帧端点另核YF损0/9与净扣45/38，XP损2/10与净扣25/34，不把首个输入动作当作已经认证的完整回合开场。所有段actual_full_candidate_result/actual_rollout_best仍null。
实验体换相4HP/4毒→212HP/零毒、触媒2/零毒、敏捷5→6时挡仍23均核；末T5本体197→160净扣37，18HP不足44−23，仅得缺3算式。沙虫终态实际5→0与显示37−22=15分列，整轮净扣36与结束动作净扣24不可混作一个窗口。

核对18个源码叶及各自实际live祖先，live读回{source['live']}。14叶字节相同，4叶仅历史Roy/Dai注释文字差异，完整diff保存在live-source.diff.patch；没有覆盖这些并行差异。尝试调用本地typescript转译比较时缺包，未安装依赖，未宣称转译等价或类型检查通过；本结论限于保存的文本diff。

| 已有窄功能源码 | 实际live祖先commit |
| --- | --- |
{source_table}

完整18叶SHA、Git blob与祖先检验见source-readback.json。已有快照、单动作回执、相邻/终态/整轮端点工具不等于逐来源贡献、整候选归属或联合校准已完成。现有DB精确进阶HP/攻击首样本路径与房间成本五样本门槛分别存在，本批没有新建硬编码怪物数值。

## 十项处置

| 提案ID | 状态 | 账本ID |
| --- | --- | --- |
{result_table}

逐项证据层/回合、反例、现状、缺数据、预期行为、验证及回退全部见同目录proposal.md。具体理由亦在result.json的proposal_results。没有把宽提案缩成局部功能后标duplicate；没有新增CLI提案ID或改原提案文档。
现有经验里支持总数/跨进阶范围只作为原记录，本批未重新验证原101局历史、未覆盖全部历史分母。未来如要改SL或价值排序，需按独立局分训练/后移验证，不能把同局六次SL当六个独立样本。本批没有新发现必须推翻现有经验的反证；原反例与未知不删除。

## 核验、失败与记录

本次35项材料一致性核验通过，material-checks.json及material-checks-v3.out留据。它们核固定原帧/既有消费者输出，不是tsc/vitest或新增策略的撤源码红绿。
初次材料脚本访问null终态字段时AttributeError，原check_materials.initial.txt、material-checks.err/out完整保留；只修临时分析脚本的空值读取，31项版通过后，补四项T1端点核验到35项，未降低原断言。几次源码路径猜测未命中，随后按rg --files定位到learner/lib；未将路径准备错误称产品缺陷。typescript模块缺失的转译准备失败另存comment-equivalence-unavailable.json，不作生产检查失败或成功声明。
没有源码改动，撤源码失败/恢复通过不适用；tsc/vitest/cases均null。未运行沙箱生产测试、未提交、未执行live合并、未新增eval版本或双通知；gitleaks提交前扫描不适用，因为没有提交。工作树应保持干净，最终自检见completion-check.json。
只经根目录ledger.py update给原账本追加本报告/提案追溯链接及说明，by=learner:strategy-proposal；不修改claim/首证/证据/既有status/version，不把既有shipped降级或自行再标shipped。追加回执见ledger-update.out。专用队列处置交最终JSON由原调度器消费，不直接改队列/learn.json。

本批fixes=[]、merged=null、HEAD不变；原提案与宽父要求继续开放。后续experience-update或独立策略实现及自然消费者读回不由这份报告代替。
'''
(OUT / 'report.md').write_text(report)
result = {'task': 'strategy-proposal', 'character': 'silent', 'batch': '20261015-191301-s2-strategy-proposal',
    'base': source['base'], 'runs': dispatch['runs'], 'fixes': [],
    'skipped': dispatch['proposal_ids'], 'merged': None,
    'tests': {'tsc': None, 'vitest': None, 'cases': None},
    'code_proposals': dispatch['proposal_ids'], 'implementation_domains': ['combat', 'sl', 'structure'],
    'proposal_results': results, 'report': str(OUT / 'report.md')}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
ids = sorted({i for p in proposals.values() for i in p['ledger']})
with (OUT / 'ledger-updates.jsonl').open('w') as handle:
    for ident in ids:
        linked = [r['id'] for r in results if ident in proposals[r['id']]['ledger']]
        handle.write(json.dumps({'id': ident, 'by': 'learner:strategy-proposal',
            'where': {'proposal': [str(OUT / 'proposal.md'), str(OUT / 'report.md')]},
            'note': '20261015-191301-s2原提案消费核验：' + ','.join(linked) +
                '均waiting。六静默A10局8274原行逐字节/身份核；三个既有离线审计读回及35项材料校验。窄功能真实live祖先见报告，未新增源码/经验/提交/合入/版本，不当整候选因果或策略收益；原claim/证据/首证/status/version保持。'}, ensure_ascii=False) + '\n')
print(json.dumps({'report': str(OUT / 'report.md'), 'proposal_results': len(results), 'ledger_links': len(ids)}, ensure_ascii=False))

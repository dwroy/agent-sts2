import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path.cwd()
LIVE = Path('/home/dw/Projects/agent-sts2/.worktrees/live')

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd).decode().strip()

paths = [
    'agent/src/reflex/combat-plan.ts', 'agent/src/reflex/turn-solver.ts',
    'agent/src/reflex/rollout.ts', 'agent/src/reflex/rollout-live.ts',
    'agent/src/knowledge/monster-db.ts', 'agent/src/reflex/passive-pieces.ts',
    'agent/src/reflex/card-model.ts', 'agent/src/sl/explore.ts',
    'agent/src/reflex/silent-selection-audit.ts',
    'agent/src/reflex/silent-selection-dispatch.ts',
    'agent/src/reflex/silent-hp-guard-audit.ts',
    'agent/src/reflex/silent-phase-current.ts',
    'agent/src/hand/loop.ts', 'learner/lib/selection-execution.ts',
    'learner/lib/selection-observation.ts', 'learner/lib/selection-terminal.ts',
    'learner/lib/selection-turn.ts', 'learner/audit-selection.ts',
]
base = git('rev-parse', 'HEAD')
live = git('rev-parse', 'HEAD', cwd=LIVE)
result = []
for name in paths:
    local = (ROOT / name).read_bytes()
    deployed = subprocess.check_output(['git', 'show', f'{live}:{name}'], cwd=LIVE)
    source = git('log', '-1', '--format=%H', live, '--', name, cwd=LIVE)
    result.append({
        'path': name, 'base_blob': git('rev-parse', f'{base}:{name}'),
        'local_sha256': hashlib.sha256(local).hexdigest(),
        'live_sha256': hashlib.sha256(deployed).hexdigest(),
        'equal': local == deployed, 'live_leaf_source_commit': source,
        'source_is_live_ancestor': subprocess.run(
            ['git', 'merge-base', '--is-ancestor', source, live], cwd=LIVE).returncode == 0,
    })
(OUT / 'source-readback.json').write_text(json.dumps({
    'base': base, 'live': live, 'files': result,
}, ensure_ascii=False, indent=2) + '\n')
with (OUT / 'baseline.diff.patch').open('wb') as handle:
    subprocess.run(['git', 'diff', '--binary', 'HEAD'], stdout=handle, check=True)
print(json.dumps({'base': base, 'live': live, 'files': len(result),
    'different': [x['path'] for x in result if not x['equal']]}, ensure_ascii=False))

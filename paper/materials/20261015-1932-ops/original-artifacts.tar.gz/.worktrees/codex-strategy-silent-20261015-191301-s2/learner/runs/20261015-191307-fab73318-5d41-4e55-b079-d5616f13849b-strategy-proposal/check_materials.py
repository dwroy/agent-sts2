import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
states = {x['line']: x for x in map(json.loads, (OUT / 'state-facts.jsonl').open())}
decisions = {x['line']: x['row'] for x in map(json.loads, (OUT / 'evidence/decisions.evidence.jsonl').open())}
checks = []

def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected})

def enemy(line, id=None):
    enemies = states[line]['enemies']
    return enemies[0] if id is None else next(x for x in enemies if x['id'] == id)

check('蚌喷水/成长', [(enemy(n)['powers'].get('STRENGTH_POWER', 0), enemy(n)['attack'])
    for n in [273238, 273252, 273263]], [(0, 11), (4, 15), (8, 19)])
check('蚌虚弱后喷水', [enemy(n)['attack'] for n in [273254, 273268]], [11, 14])
check('蚌末轮HP/挡/意图', [states[273268]['hp'], states[273268]['block'], enemy(273268)['attack']], [2, 10, 14])
check('棱柱T4技能/能力/技能污染', [states[n]['powers'].get('TAINTED_POWER', 0) for n in [274830, 274831, 274832, 274833]], [0, 3, 3, 6])
check('棱柱T5火花与污染', [enemy(274834)['powers']['VITAL_SPARK_POWER'], *[states[n]['powers'].get('TAINTED_POWER', 0) for n in [274834, 274836, 274837, 274838]]], [6, 0, 6, 12, 18])
check('电击跨轮现场', [[enemy(n, 'ZAPBOT')['max_hp'], enemy(n, 'ZAPBOT')['powers']['STRENGTH_POWER'], enemy(n, 'ZAPBOT')['attack']] for n in [274308, 274313]], [[23, 2, 17], [23, 4, 19]])
check('电击索引重排', [enemy(n, 'ZAPBOT')['index'] for n in [274308, 274313]], [4, 3])
check('抢夺T4两试均负属性', [[states[n]['powers']['STRENGTH_POWER'], states[n]['powers']['DEXTERITY_POWER']] for n in [274351, 274391]], [[-4, -4], [-4, -4]])
check('失落退场后力返还现场', states[274358]['powers'].get('STRENGTH_POWER', 0), 0)
check('遗忘再夺敏现场', states[274362]['powers']['DEXTERITY_POWER'], -2)
for a, b in [(270216, 270282), (271309, 271348), (271992, 272040), (271982, 272195)]:
    check(f'同盘指纹{a}/{b}', decisions[a]['fingerprint'] == decisions[b]['fingerprint'], True)
check('实验体换相HP/毒', [[enemy(n)['hp'], enemy(n)['max_hp'], enemy(n)['powers'].get('POISON_POWER', 0)] for n in [277512, 277513]], [[4, 111, 4], [212, 212, 0]])
check('实验体T5触媒已建而零毒', [states[277519]['powers']['ACCELERANT_POWER'], enemy(277519)['powers'].get('POISON_POWER', 0)], [2, 0])
check('实验体后来敏捷不倒补挡', [[states[n]['powers']['DEXTERITY_POWER'], states[n]['block']] for n in [277523, 277526]], [[5, 23], [6, 23]])
check('实验体T5敌本体净差', enemy(277519)['hp'] - enemy(277527)['hp'], 37)
check('实验体终局差量仅算式', enemy(277527)['attack'] - states[277527]['block'] - states[277527]['hp'], 3)
check('双蟹T2轮初挡', states[278236]['block'], 14)
check('镣铐当轮减力/下轮恢复', [enemy(n, 'CRUSHER')['powers'].get('STRENGTH_POWER', 0) for n in [278236, 278237, 278242]], [0, -9, 0])
check('双蟹末试T2挡14到20', [states[n]['block'] for n in [278236, 278240]], [14, 20])
check('双蟹背向/朝向/弱', [enemy(n, 'ROCKET')['attack'] for n in [278249, 278252, 278253]], [57, 38, 28])
check('双蟹末次脆弱四敏挡', [states[n]['block'] for n in [278255, 278258]], [6, 6])
check('双蟹末轮毒实扣', sum(enemy(278260, id)['hp'] - enemy(278261, id)['hp'] for id in ['CRUSHER', 'ROCKET']), 10)

audits = {r: json.loads((OUT / (r + '-audit.json')).read_text()) for r in ['8JRE1C4H4Z2W', 'YF0LXT1QSTGG', 'XP2SL33HT0D9']}
def turn(run, attempt, n):
    return next(x['facts'] for x in audits[run]['observed_turns'] if x['floor'] == 33 and x['attempt'] == attempt and x['turn'] == n)
check('沙虫同盘T2实损/实扣', [[-turn('8JRE1C4H4Z2W', a, 2)['player_hp_delta'], -sum(x['hp_delta'] for x in turn('8JRE1C4H4Z2W', a, 2)['enemy_hp_changes'])] for a in [1, 3]], [[3, 10], [15, 17]])
check('双蟹同盘T3实损/实扣', [[-turn('XP2SL33HT0D9', a, 3)['player_hp_delta'], -sum(x['hp_delta'] for x in turn('XP2SL33HT0D9', a, 3)['enemy_hp_changes'])] for a in [1, 2]], [[9, 24], [14, 27]])
endpoint_pairs = []
for run, expected in [('YF0LXT1QSTGG', {271309: [0, 45], 271348: [9, 38]}),
        ('XP2SL33HT0D9', {271982: [2, 25], 272195: [10, 34]})]:
    supplied = json.loads((OUT / (run + '-audit-input.json')).read_text())['decisions']
    actions = {x['source_line']: x for x in audits[run]['observed_actions']}
    for line, values in expected.items():
        index = next(i for i, row in enumerate(supplied) if row['_line'] == line)
        first = supplied[index]
        next_turn = next(row for row in supplied[index + 1:] if row['turn'] == 2 and
            row['sl_attempt'] == first['sl_attempt'] and row['floor'] == first['floor'])
        left, right = actions[line]['before'], actions[next_turn['_line']]['before']
        actual = [left['hp'] - right['hp'], sum(x['hp'] for x in left['enemies']) - sum(x['hp'] for x in right['enemies'])]
        check(f'{run}T1观测端点{line}', actual, values)
        endpoint_pairs.append({'run_id': run, 'decision_line': line,
            'before_state_line': left['source_line'], 'after_state_line': right['source_line'],
            'net_hp_loss': actual[0], 'net_enemy_hp_reduction': actual[1],
            'whole_candidate_execution': None, 'causal_effect': None})
(OUT / 'opening-endpoint-pairs.json').write_text(json.dumps(endpoint_pairs, ensure_ascii=False, indent=2) + '\n')
for run, audit in audits.items():
    check(f'{run}完整候选因果未认证', all(x['actual_full_candidate_result'] is None and x['actual_rollout_best'] is None for x in audit['segments']), True)
terminal = next(x['terminal_observation']['facts'] for x in audits['8JRE1C4H4Z2W']['observed_actions'] if (x.get('terminal_observation') or {}).get('status') == 'observed_terminal_endpoints')
check('沙虫终态净损与意图差分列', [terminal['player_hp_delta'], terminal['displayed_attack_reference']['attack_minus_block'], terminal['actual_uncapped_damage']], [-5, 15, None])
(OUT / 'material-checks.json').write_text(json.dumps({'kind': '材料一致性核验，非生产测试或策略收益验证', 'checks': checks, 'count': len(checks)}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_checks': len(checks), 'status': 'passed'}, ensure_ascii=False))

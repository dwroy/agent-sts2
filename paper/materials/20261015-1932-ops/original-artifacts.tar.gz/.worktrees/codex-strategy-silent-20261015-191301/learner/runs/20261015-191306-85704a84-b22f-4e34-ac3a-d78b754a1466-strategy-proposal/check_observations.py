"""Material checks on observed log frames; not production tests or model calibration."""
import collections
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
boards = json.loads((HERE / 'observed-boards.json').read_text())
b = {row['line']: row for row in boards}
decisions = {item['line']: item['row'] for item in map(json.loads, (HERE / 'evidence/decisions.evidence.jsonl').open())}
sl = [item for item in map(json.loads, (HERE / 'evidence/sl-attempts.evidence.jsonl').open())]
audit = json.loads((HERE / '8JRE-selection-audit.json').read_text())
checks = []


def check(name, actual, expected, lines):
    assert actual == expected, (name, actual, expected)
    checks.append({'name': name, 'actual': actual, 'expected': expected, 'lines': lines})


def enemy(line, ident):
    return next(e for e in b[line]['enemies'] if e['enemy_id'] == ident)


def hand(line, ident):
    return next(c for c in b[line]['hand'] if c['card_id'] == ident)


def attack(line):
    return sum(i['total_damage'] or 0 for e in b[line]['enemies'] for i in e['intents'])


check('神化实际费用', b[275564]['player']['energy'] - b[275565]['player']['energy'], 2, [275564, 275565])
for ident, before, after in [('DEFEND_SILENT', '获得5点格挡。', '获得8点格挡。'),
                             ('STRIKE_SILENT', '造成7点伤害。', '造成10点伤害。'),
                             ('DAGGER_SPRAY', '对所有敌人造成5点伤害两次。', '对所有敌人造成7点伤害两次。')]:
    check(ident + '神化前后文本', [hand(275564, ident)['resolved_rules_text'], hand(275565, ident)['resolved_rules_text']], [before, after], [275564, 275565])
check('必备工具费用', [hand(n, 'TOOLS_OF_THE_TRADE')['energy_cost'] for n in [275564, 275565]], [1, 0], [275564, 275565])
check('场外升级数不随战内神化改变', [b[n]['deck_upgraded'] for n in [275679, 275680, 275687]], [4, 4, 4], [275679, 275680, 275687])
check('F43T1净敌血差', enemy(275679, 'SOUL_NEXUS')['current_hp'] - enemy(275687, 'SOUL_NEXUS')['current_hp'], 51, [275679, 275687])
check('F43T1净玩家血差', b[275679]['player']['current_hp'] - b[275687]['player']['current_hp'], 13, [275679, 275687])
check('后续抽到升级毒雾', hand(275687, 'NOXIOUS_FUMES')['upgraded'], True, [275687])
check('F45药水后血量不变', [b[n]['player']['current_hp'] for n in [275728, 275729]], [67, 67], [275728, 275729])
check('F45药水后多一能量两张手牌', [b[275729]['player']['energy'] - b[275728]['player']['energy'], len(b[275729]['hand']) - len(b[275728]['hand'])], [1, 2], [275728, 275729])
check('MC退化实值', [decisions[269748]['timing']['mc_ms'], decisions[269748]['rollout']['horizon'], decisions[269748]['rollout']['samples'], decisions[269748]['rollout']['best']], [707, 1, 1, None], [269748])
check('重问题不是同一状态的预算实验', decisions[269748]['fingerprint'] == decisions[269754]['fingerprint'], False, [269748, 269754])
check('F45T5现场挡', b[275754]['player']['block'], 20, [275754])
check('F45T5逐段减力前后显示攻击', [attack(275752), attack(275753)], [83, 59], [275752, 275753])
check('F45T5显示完整需损及零血截断分列', [attack(275754) - b[275754]['player']['block'], b[275754]['player']['current_hp'] - b[275755]['player']['current_hp']], [39, 32], [275754, 275755])
check('F45T5最后三敌仍有血', sorted(e['current_hp'] for e in b[275755]['enemies']), [21, 77, 80], [275755])
check('SL首三试T2指纹相同', decisions[270216]['fingerprint'] == decisions[270282]['fingerprint'], True, [270216, 270282])
segments = {s['source_line']: s for s in audit['segments']}
pred = segments[270282]['predictions']
check('SL第三试同题候选血价伤差', [pred['final_candidate']['facts']['hp_lost'] - pred['answer']['facts']['hp_lost'], pred['final_candidate']['facts']['damage_dealt'] - pred['answer']['facts']['damage_dealt']], [12, 7], [270282])
check('护栏候选省血少伤', [segments[270264]['predictions']['answer']['facts']['hp_lost'] - segments[270264]['predictions']['final_candidate']['facts']['hp_lost'], segments[270264]['predictions']['answer']['facts']['damage_dealt'] - segments[270264]['predictions']['final_candidate']['facts']['damage_dealt']], [12, 18], [270264])
windows = [s for s in audit['observed_turns'] if s['floor'] == 33]
check('F33整轮端点窗口可核和未知分列', dict(collections.Counter(s['status'] for s in windows)), {'observed_turn_endpoints': 39, 'unknown': 11}, [270216, 270442])
check('完整候选仍未认证', all(s['actual_full_candidate_result'] is None and s['actual_rollout_best'] is None for s in audit['segments']), True, [])
for attempt, hp_after, enemy_after in [(1, 44, 316), (3, 32, 309)]:
    facts = next(s['facts'] for s in windows if s['turn'] == 2 and s['attempt'] == attempt)
    check('T2第' + str(attempt) + '试实际端点', [facts['before']['hp'], facts['after']['hp'], facts['before']['enemies'][0]['hp'], facts['after']['enemies'][0]['hp']], [47, hp_after, 326, enemy_after], [270216 if attempt == 1 else 270282])
check('末试显示需损与实际零血截断', [attack(276433) - b[276433]['player']['block'], b[276433]['player']['current_hp'] - b[276434]['player']['current_hp']], [15, 5], [276433, 276434])
check('下水道蚌力量与同招攻击', [[enemy(n, 'SEWER_CLAM')['powers'].get('STRENGTH_POWER', 0), attack(n)] for n in [273237, 273252, 273263]], [[0, 11], [4, 15], [8, 19]], [273237, 273252, 273263])
check('虚弱未阻止独立成长', [[enemy(n, 'SEWER_CLAM')['powers']['STRENGTH_POWER'], attack(n)] for n in [273254, 273268]], [[4, 11], [8, 14]], [273254, 273268])
check('本来源局已选F13状态未实见正敏捷', any(r['run_id'] == 'CA5KE8GFJ9X2' and (r['powers'].get('DEXTERITY_POWER') or 0) > 0 for r in boards), False, [])
check('无毒冒泡耗一能', b[274379]['player']['energy'] - b[274380]['player']['energy'], 1, [274379, 274380])
check('无毒冒泡前后目标血和能力不变', [enemy(274379, 'THE_LOST')['current_hp'], enemy(274379, 'THE_LOST')['powers']], [enemy(274380, 'THE_LOST')['current_hp'], enemy(274380, 'THE_LOST')['powers']], [274379, 274380])
check('末试T2未建立毒雾', 'NOXIOUS_FUMES_POWER' in b[274379]['powers'], False, [274379])
check('吸取前后玩家力敏分列', [b[273502]['powers'].get('STRENGTH_POWER', 0), b[273504]['powers'].get('STRENGTH_POWER', 0), b[273504]['powers']['DEXTERITY_POWER']], [2, 0, -2], [273502, 273504])
check('负敏捷两防御各3挡', [b[273505]['player']['block'] - b[273504]['player']['block'], b[273507]['player']['block'] - b[273506]['player']['block']], [3, 3], [273504, 273505, 273506, 273507])
check('负敏捷不消除当前已建毒的实际净扣', enemy(273504, 'LAGAVULIN_MATRIARCH')['current_hp'] - enemy(273508, 'LAGAVULIN_MATRIARCH')['current_hp'], 33, [273504, 273508])
lag = [s['row'] for s in sl if s['run_id'] == '61E2QS63Y9WU' and s['row']['floor'] == 17]
check('族母本局首试胜不是六个独立SL样本', [[r['attempt'], r['result'], r['turns'], r['end_hp']] for r in lag], [[1, 'won', 7, 48]], [898])
check('胧光本体和召唤物成长', [[enemy(n, 'THE_OBSCURA')['powers'].get('STRENGTH_POWER', 0), enemy(n, 'PARAFRIGHT')['powers'].get('STRENGTH_POWER', 0)] for n in [273583, 273589, 273596]], [[0, 0], [3, 3], [6, 6]], [273583, 273589, 273596])
check('本体线后幻象余2未退场', enemy(273596, 'PARAFRIGHT')['current_hp'], 2, [273596])
check('幻象T5才到0且保留复现意图', [enemy(273598, 'PARAFRIGHT')['current_hp'], enemy(273598, 'PARAFRIGHT')['move_id']], [0, 'REVIVE_MOVE'], [273598])
check('熟睡甲虫睡层序列', [enemy(n, 'SLUMBERING_BEETLE')['powers'].get('SLUMBER_POWER', 0) for n in [274906, 274914, 274919, 274923]], [3, 2, 1, 0], [274906, 274914, 274919, 274923])
check('熟睡甲虫醒后力与攻击', [[enemy(n, 'SLUMBERING_BEETLE')['powers'].get('STRENGTH_POWER', 0), next(i['total_damage'] for i in enemy(n, 'SLUMBERING_BEETLE')['intents'] if i['total_damage'] is not None)] for n in [274923, 274929, 274934]], [[0, 18], [2, 20], [4, 22]], [274923, 274929, 274934])
beetle = [s['row'] for s in sl if s['run_id'] == 'DUZUBAJ3A8GP' and s['row']['floor'] == 30]
check('同局四试前三预测死亡末试实死', [[r['attempt'], r['result']] for r in beetle], [[1, 'predicted_death'], [2, 'predicted_death'], [3, 'predicted_death'], [4, 'died']], [914, 915, 916, 917])
(HERE / 'observation-checks.json').write_text(json.dumps({'kind': 'material_assertions_not_production_tests', 'count': len(checks), 'checks': checks}, ensure_ascii=False, indent=2) + '\n')
(HERE / 'selection-consumer-summary.json').write_text(json.dumps({'source': '8JRE-selection-audit.json', 'segments': len(audit['segments']), 'observed_actions': len(audit['observed_actions']), 'F33_turn_windows': len(windows), 'F33_statuses': dict(collections.Counter(s['status'] for s in windows)), 'full_candidate_certified': 0, 'limits': audit['limitations']}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'material_assertions_passed': len(checks), 'production_tests_run': False}, ensure_ascii=False))

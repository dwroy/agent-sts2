# 静默策略批次回报：十项均保留 waiting

批次：20261015-191301-strategy-proposal。本批无新增源码或知识改动，无提交、合入、行为版本或规则通知。基线完整提交为 `16271871beb0ed3df1a6c997596e5e57faab027a`；HEAD 保持该提交，工作树保持干净。fixes=[]，merged=null。各项证据、账本、反例、旧行为/预期行为、验证及回退见 [proposal.md](proposal.md)，逐项机器处置见 [proposal-results.json](proposal-results.json)。

## 派发与范围

先读 README、最新 STATE-2026-10-15、decision-log 末尾、学习协议与代码提案闭环。初始 git status 干净；普通批次执行 `git merge --no-edit main`，结果 Already up to date。本批 learn.json 对应行的 task、character、工作树与六局集合匹配，只有十个 proposal_ids，无 proposal_repair、research_request 或 implementation_request，reason=proposal。普通专题条件不成立，未承接其他请求、未领取其他队列项。身份回执保存 dispatch-identity.json。

十个原提案角色均 silent，原 Markdown 全部 SHA 匹配；原文副本及 manifest 保存在 original-proposals/ 和 original-proposals-manifest.json。只读原六局与本角色账本/提案、通用实现源码，没有读取或搬用其他角色知识；没有启动游戏、模型/API、子 agent 或联网任务。

启动器记录请求 `gpt-6.1-sol`、`model_reasoning_effort="xhigh"`、`service_tier="default"`；题面写 high，两者差异保留。本批未更改启动配置、切换线程或重启会话，仅从启动器命令读回这些值，未将其冒称原生请求核验或已切换为 high。

## 原始证据及材料核验

使用本树 learner/extract_evidence.py，按显式身份提取 states、decisions、sl-attempts、run-config、run-plans、brain、runs、fight-plans 八流。每流保留 source_size、逐行 offset/bytes/SHA 和计数，run-plans 用 run，其他流用 run_id/state.run_id/fingerprint.run；不按正文提及归属。随后 verify_evidence.py 对全部 6,995 所属行重新 seek 原日志、逐字节 SHA 与 JSON 比较，核显式身份及 runs/state 角色与进阶，全部通过。

| 局号 | 角色/进阶 | 状态 | 决策 | 八流所属总行 |
|---|---|---:|---:|---:|
| VLZ6CCT8AQ0A | SILENT A10 | 729 | 699 | 1486 |
| 8JRE1C4H4Z2W | SILENT A10 | 676 | 659 | 1381 |
| CA5KE8GFJ9X2 | SILENT A10 | 282 | 265 | 562 |
| 5PM6JAQG6FNQ | SILENT A10 | 660 | 638 | 1353 |
| 61E2QS63Y9WU | SILENT A10 | 462 | 443 | 945 |
| DUZUBAJ3A8GP | SILENT A10 | 623 | 602 | 1268 |

流总数：states 3432、decisions 3306、SL 29、config 6、plans 33、brain 183、runs 6、fight-plans 0。fight-plans 的 0 只表示该冻结截点 2,233,957 字节中没有选到这六局，不能证明全历史缺失。扫描中 states/decisions 各有 2 条无效 JSON、brain 1 条无效 JSON，未能建立合法身份，未纳入；不能保证这些坏行绝不属于本批。incomplete_lines 均 0。原局 code 都有 dirty 标记，完整当时源码/知识快照不足，不把当前源码读回等同原局模型重建。

产物：evidence/evidence-manifest.json、verified-evidence.json、verify-evidence.log。抽取只保存所属行并保留原字节索引，没有归档整个仓库或全量日志。712 个选定战斗状态的紧凑视图在 observed-boards.json，范围见 board-overview.json，不声称逐行游戏语义全审计。

41 项固定帧材料断言全部通过，见 check_observations.py、observation-checks.json、check-observations.log。包括神化升级/场外升级数不变、药水真实资源变化、83→59 显示攻击与零血截断、下水道蚌成长与虚弱、无毒冒泡、负敏捷与毒、召唤物剩血/成长、熟睡甲虫睡层/成长及 SL 结果。它们是材料核对，不是生产测试或独立泛化样本。

## 现有消费者与源码读回

用这次冻结的 8JRE 原 run、659 个决策、676 个状态生成输入；决策均有原 decision_id，排除表为空，保留原行号与 SHA。以 `nice -n 19 node --import ./agent/node_modules/tsx/dist/loader.mjs learner/audit-selection.ts <固定输入>` 运行现有工具，退出 0。113 个选线 segment、659 个动作观察；F33 有 50 个整轮窗口，39 observed_turn_endpoints、11 unknown。全部 actual_full_candidate_result / actual_rollout_best 仍 null。完整输入/输出/空错误日志及摘要在 8JRE-selection-*、selection-consumer-summary.json。

该读回支持现有离线工具能区分原答、换线、单动作回执与观测端点，不认证完整候选执行。第三试 T2 同题预测的损 3/伤 10 与损 15/伤 17、实际首/三试下一轮 44/32 血和敌 316/309 分别保留；不把原答中的成长或后续计划当作实收。末试 T11 玩家 5→0 的实扣与显示 37−22=15 分列。

只读 live 冻结提交为 `fe6462651b593b9831581c088deface9957a404f`。核 16 个相关源码叶：全部与该 live 提交一致，14 个与本树逐字节相等，card-model.ts 与 rollout-live.ts 的差异为原有 Roy/Dai 注释文字，未覆盖。源码 SHA、真实祖先检查在 source-audit.json；有限源码差异在 base-live-source.patch，本树源码差异 worktree-source.patch 为空。未将源码存在或注释差异冒称新测试通过。

以下源码提交全部实际是本基线及冻结 live 的祖先，只用于已覆盖子项追溯，不关闭十项宽提案：

| 实际源码 commit | 已有子项 |
|---|---|
| ba23ca693151fa8c6f7fe035e640dc30f05ccd75 | 普通神化的已观察致命毒药升级对 |
| b2805be4ba44b7375c7908d873889372cc3cfe6c | 普通神化的已观察萎靡升级对 |
| 30ec2425012eea75f41226b31d8180b1abb837bc | 已部署神化候选事实同步；实际施放字段仍未知 |
| f1542578594462e9f9f4e175488795fc480a8a13 | HP 护栏候选预测快照 |
| be69855995737d6f381adb10bf248964832da24b | SL 前后候选预测审计 |
| 66283dd9982bdd7f480da7a4d9bfefea0572a9ac | 已修复旧接线与持续执行适配的集成源 |
| fdaf787a372880b0438e73bcac7e6d2168b038ed | 单动作派发回执 |
| dc0e6080cb20c508d94c006648cc3edf0188d306 | 离线动作观测端点 |
| 83512ddcd2c70fd9b983dc38524ff25c8970c1d3 | 离线结束回合的终态 HP 端点 |
| e75438488df159b2e8e9d3458cf219b39aadd933 | 离线整轮端点审计集成源 |
| 1e076b173c6874cef4bf90fd13cd3eb33355827a | 既有胧光活体召唤与后轮威胁子项 |

## 十项处置与未实现原因

| 原派发 id（silent-proposal- 后缀） | 证据锚点 | 剩余缺口；均为 waiting |
|---|---|---|
| 89354805ee4d7e77 | VLZ F35/F43/F45 | 持续实际施放身份、未知后继及属性交互校准；不重复普通升级对 |
| f2bfceddb1898dca | VLZ F45 T1/T4/T5 | 同盘同随机池同总预算的 MC 配对、稳定性曲线和完整模型覆盖 |
| 283a164780d11e69 | 同源 VLZ 神化经验 | 原经验链接已在，宽神化范围仍未完整实现，不能冒标 duplicate |
| ebbfe3b97548756d | VLZ F43/F45、F44 | 十五经验的组合/期限/战斗与路线休息消费者联合校准 |
| e5b87be50f28f311 | 8JRE F33 T2/T5/T11 | 跨重规划候选持续身份、完整执行和成长逐源归属 |
| 49632bc4878fb597 | CA5 F13 T1—T5 | 力、正负敏、弱与独立成长四路径冻结联合调用；本战无正敏实测 |
| 66532328a585941f | 5PM F39 末试 T2 | 同资源同抽序的启动顺序整战配对与可复现收益函数 |
| 43a76a31ba7bdcfa | 61E F17 T5—T7 | 另一可核完整同盘 SL 线路；首试胜不支持扩大 SL |
| 5264153a4a4b0e5c | 61E F23 T2—T5 | A10 逐实体生命周期/成长校准及另一 focus 整战后继 |
| bddfa690a84e03d0 | DUZ F30 T1—T6 | 伤害唤醒/眩晕/恢复成长全链与同抽换序完整后继 |

本批未发现推翻原经验的新反证，保留原提案和双向取舍；未添加必须支持原假设的结论。原经验存在和源码子项上线，不等同宽提案完成、量化父请求完成、知识已重新入库或大脑实际采用。十个 CLI id 沿用，不新建重复提案，不直接修改专用队列、learn.json 或根请求。

## 账本、验证与交付边界

仅经根目录 learner/ledger.py update 为相关 26 个原账本追加本批路径与逐项 waiting 理由，by=learner:strategy-proposal；不重复加历史 evidence，不改 claim、first_run、prior、status、version，不标 shipped。输入、CLI 输出及读回保护检查分别保存 ledger-updates.jsonl、ledger-update.log、ledger-readback.json。已有 shipped 子经验不倒退为 proposed；本批没有新账本条目。

没有源码实现，撤源码失败/恢复通过不适用；tsc、vitest、cases 均未运行，固定为 null。现有离线工具退出 0 和 41 条材料断言不计入这些测试字段。没有 git commit，因此没有新源码提交、合入提交、eval 版本、Roy 规则变更双通知；不伪造 shipped 或沿用旧成功测试。代码和知识行为保持本基线，不声称后续收益。

回退：本批没有生产变更可回退；追加的账本追溯不改旧历史。后续沿这十个原 id 等待能补足具体缺口的新证据。所有原报告、失败/未知和证据保留，不等待未来事件或擅自清理本树。

材料准备中曾查询不存在的 tools/、core/loop.ts、silent-temporary-strength.ts，分别改查现有 hand/loop.ts 和实际相关模块；未据此认定产品缺陷。工具输出截断的原命令留在会话记录，所需原提案与 ledger-before 的完整数据均已落盘；全部字节核验及材料断言的成功结果独立保存。

运维交付入口为本目录 proposal.md、report.md 和 result.json；逐项结果与 task/character/batch/base、真实报告绝对路径以 result.json 为准。最终工作树/HEAD、产物扫描与账本读回验收记录在 completion-check.json。

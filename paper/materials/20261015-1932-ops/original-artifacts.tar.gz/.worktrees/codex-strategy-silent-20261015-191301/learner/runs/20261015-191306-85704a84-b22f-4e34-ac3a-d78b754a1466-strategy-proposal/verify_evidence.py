"""Verify frozen evidence bytes and retain compact observed boards, without game inference."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
RUNS = "VLZ6CCT8AQ0A 8JRE1C4H4Z2W CA5KE8GFJ9X2 5PM6JAQG6FNQ 61E2QS63Y9WU DUZUBAJ3A8GP".split()
spec = importlib.util.spec_from_file_location("extract_evidence", WORKTREE / "learner/extract_evidence.py")
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)


def write(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def powers(entries):
    return {entry["power_id"]: entry.get("amount") for entry in entries or []}


def card(entry):
    return {key: entry.get(key) for key in ("index", "card_id", "upgraded", "energy_cost", "resolved_rules_text", "dynamic_values")}


def board(item):
    row = item["row"]
    state = row["state"]
    run = state.get("run") or {}
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    return {
        "line": item["line"], "offset": item["offset"], "bytes": item["bytes"], "sha256": item["sha256"],
        "run_id": item["run_id"], "observed_ts": row.get("observed_ts"),
        "floor": run.get("floor"), "turn": state.get("turn"), "screen": state.get("screen"),
        "player": {key: player.get(key) for key in ("current_hp", "max_hp", "block", "energy")},
        "powers": powers(player.get("powers")), "deck_upgraded": sum(bool(c.get("upgraded")) for c in run.get("deck", [])),
        "hand": [card(c) for c in combat.get("hand", [])],
        "enemies": [{**{key: e.get(key) for key in ("index", "enemy_id", "name", "current_hp", "max_hp", "block", "is_alive", "move_id", "intents")},
                     "powers": powers(e.get("powers"))} for e in combat.get("enemies", [])],
    }


def main():
    manifest = json.loads((HERE / "evidence/evidence-manifest.json").read_text())
    result = []
    compact = []
    run_rows = []
    selected_floors = {"VLZ6CCT8AQ0A": {35, 43, 44, 45}, "8JRE1C4H4Z2W": {17, 33},
                       "CA5KE8GFJ9X2": {13}, "5PM6JAQG6FNQ": {33, 39}, "61E2QS63Y9WU": {17, 23}, "DUZUBAJ3A8GP": {30}}
    for stream in manifest:
        path = HERE / "evidence" / (stream["stream"] + ".evidence.jsonl")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == stream["output_sha256"]
        counts = dict.fromkeys(RUNS, 0)
        with Path("/home/dw/Projects/agent-sts2/logs", stream["stream"] + ".jsonl").open("rb") as source, path.open() as evidence:
            for line in evidence:
                item = json.loads(line)
                assert extractor.run_identity(item["row"]) == item["run_id"] in counts
                assert item["offset"] + item["bytes"] <= stream["source_size"]
                source.seek(item["offset"])
                raw = source.read(item["bytes"])
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
                assert json.loads(raw) == item["row"]
                counts[item["run_id"]] += 1
                if stream["stream"] == "states":
                    state = item["row"]["state"]
                    run = state.get("run") or {}
                    if run:
                        assert run.get("character_id") == "SILENT" and run.get("ascension") == 10
                    if state.get("combat") and run.get("floor") in selected_floors[item["run_id"]]:
                        compact.append(board(item))
                elif stream["stream"] == "runs":
                    assert item["row"]["character"] == "SILENT" and item["row"]["ascension"] == 10
                    run_rows.append(item)
        assert counts == stream["counts"]
        result.append({"stream": stream["stream"], "source_size": stream["source_size"], "verified_rows": sum(counts.values()), "counts": counts})
    assert len(run_rows) == 6 and {item["run_id"] for item in run_rows} == set(RUNS)
    write("verified-evidence.json", {"all_bytes_and_explicit_identities_verified": True, "streams": result,
                                     "total_rows": sum(s["verified_rows"] for s in result), "runs": run_rows})
    write("observed-boards.json", compact)
    groups = collections.defaultdict(list)
    for b in compact:
        groups[(b["run_id"], b["floor"], b["turn"])].append(b)
    overview = []
    for (run, floor, turn), entries in groups.items():
        overview.append({"run": run, "floor": floor, "turn": turn, "rows": len(entries),
                         "first": entries[0]["line"], "last": entries[-1]["line"],
                         "player_hp": [entries[0]["player"]["current_hp"], entries[-1]["player"]["current_hp"]],
                         "enemy_hp": [[e["current_hp"] for e in b["enemies"]] for b in (entries[0], entries[-1])]})
    write("board-overview.json", overview)
    print(json.dumps({"verified": result, "compact_boards": len(compact)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

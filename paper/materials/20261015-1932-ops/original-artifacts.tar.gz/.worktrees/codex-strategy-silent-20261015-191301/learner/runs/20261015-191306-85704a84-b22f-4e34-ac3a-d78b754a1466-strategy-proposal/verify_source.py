"""Freeze exact source leaves and ancestry; this does not certify game model coverage."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[2]
ROOT = Path('/home/dw/Projects/agent-sts2')
LIVE = ROOT / '.worktrees/live'


def git(*args, cwd=WORKTREE):
    return subprocess.check_output(['git', *args], cwd=cwd)


base = git('rev-parse', 'HEAD').decode().strip()
live = git('rev-parse', 'HEAD', cwd=LIVE).decode().strip()
paths = [
    'agent/src/reflex/silent-apotheosis.ts', 'agent/src/reflex/silent-apotheosis-reference.ts',
    'agent/src/reflex/card-model.ts', 'agent/src/reflex/turn-solver.ts',
    'agent/src/reflex/rollout-live.ts', 'agent/src/reflex/rollout.ts',
    'agent/src/reflex/silent-selection-audit.ts', 'agent/src/reflex/silent-hp-guard-audit.ts',
    'agent/src/reflex/silent-selection-dispatch.ts', 'agent/src/reflex/combat-plan.ts',
    'agent/src/hand/loop.ts', 'learner/audit-selection.ts',
    'learner/lib/selection-execution.ts', 'learner/lib/selection-observation.ts',
    'learner/lib/selection-turn.ts', 'learner/lib/selection-terminal.ts',
]
leaves = []
for path in paths:
    local = (WORKTREE / path).read_bytes()
    deployed = (LIVE / path).read_bytes()
    committed = git('show', live + ':' + path)
    leaves.append({'path': path, 'base_sha256': hashlib.sha256(local).hexdigest(),
                   'live_worktree_sha256': hashlib.sha256(deployed).hexdigest(),
                   'live_commit_sha256': hashlib.sha256(committed).hexdigest(),
                   'live_worktree_equals_commit': deployed == committed,
                   'base_equals_live': local == deployed})

commits = [
    'ba23ca693151fa8c6f7fe035e640dc30f05ccd75',
    'b2805be4ba44b7375c7908d873889372cc3cfe6c',
    '30ec2425012eea75f41226b31d8180b1abb837bc',
    'f1542578594462e9f9f4e175488795fc480a8a13',
    'be69855995737d6f381adb10bf248964832da24b',
    '66283dd9982bdd7f480da7a4d9bfefea0572a9ac',
    'fdaf787a372880b0438e73bcac7e6d2168b038ed',
    'dc0e6080cb20c508d94c006648cc3edf0188d306',
    '83512ddcd2c70fd9b983dc38524ff25c8970c1d3',
    'e75438488df159b2e8e9d3458cf219b39aadd933',
    '1e076b173c6874cef4bf90fd13cd3eb33355827a',
]
ancestry = []
for commit in commits:
    checks = {name: subprocess.run(['git', 'merge-base', '--is-ancestor', commit, target], cwd=WORKTREE).returncode == 0
              for name, target in [('base', base), ('live', live)]}
    ancestry.append({'commit': commit, 'subject': git('show', '-s', '--format=%s', commit).decode().strip(),
                     'ancestor_of': checks,
                     'relevant_paths': git('diff-tree', '--no-commit-id', '--name-only', '-r', commit, '--', *paths).decode().splitlines()})
(HERE / 'source-audit.json').write_text(json.dumps({'base': base, 'live': live, 'leaves': leaves, 'ancestry': ancestry}, ensure_ascii=False, indent=2) + '\n')
(HERE / 'base-live-source.patch').write_bytes(git('diff', '--binary', base, live, '--', *paths))
(HERE / 'worktree-source.patch').write_bytes(git('diff', '--binary', 'HEAD', '--', *paths))
print(json.dumps({'base': base, 'live': live, 'equal_leaves': sum(x['base_equals_live'] for x in leaves),
                  'total_leaves': len(leaves), 'live_clean_leaves': sum(x['live_worktree_equals_commit'] for x in leaves),
                  'ancestry': ancestry}, ensure_ascii=False))

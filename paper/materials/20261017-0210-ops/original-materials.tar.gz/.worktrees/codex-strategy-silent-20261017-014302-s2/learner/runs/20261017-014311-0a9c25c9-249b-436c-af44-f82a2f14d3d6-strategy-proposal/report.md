# Silent 策略批次回报

计算下注窄补丁已写好，尚未提交或上线；提交门槛与整支合入分别受阻。不是纯报告/无源码完成，不申请回收。请ops沿原批/原owner接续，保留全部失败，核三文件冻结字节后兜底提交与窄合，实际live后再登记implemented/shipped、发布编号及Roy双通知。

批次：20261017-014302-s2-strategy-proposal；base/当前HEAD：`a0e2fff7b979314585252a095ae0e20c8045a6ba`；暂存tree：`b825d9a35d6c502e7639aecd1ab94833f992a2da`。原10项全部处置：1项窄源码待集成、1项duplicate、8项缺数据waiting。源码commit=null、merged=null、release_id=null。

## 实现与证据

唯一源码变更为combat-plan.ts。普通计算下注只在Silent A10、无禁抽且既有直接抽牌优先未选中时尝试全弃重抽；使用既有transition核实际剩余手牌，保留强制先出牌与沙坑支付，计划停在重抽处并读取实际新手牌。其他角色/未观察进阶/升级形态维持旧入口，不改SL门槛或权重。

证据：silent-0300／原silent-proposal-1cb36e182078a20e；Y5H4CFAQ2WTG A10 F33T10 states301111—301114、decision293850；L704TLETMZBM A10 F48末试T6 states256459—256462、decision251114。当前旧源码在Y5零能量结束/沙坑计划可复现；L704当前固定模型已选重抽，不称该历史症状当前仍复现。未来真实抽序、重抽后胜负与完整dirty运行树均未知，不宣称原局能转胜。

原提案和逐项完整缺口见[proposal.md](proposal.md)，原Markdown复制/指纹在proposals.json。五来源局全部核为Silent：G403 A9胜局；其余A10败局，不混阶、不把SL作为独立样本。八流共6894原行已逐条复核offset/bytes/SHA/JSON/显式身份；各自source_size见evidence/evidence-manifest.json，fight-plans在本次截点0行只说明未选到。4个新增固定帧与公共提取原帧逐值相等。资源/幽灵原帧核验另见resource-and-ghost-observations.json。

## 验证与提交阻塞

- 生产tsc：exit0。
- 固定新增7项通过；撤生产源码2项失败/5项通过，恢复后7项通过，完整源检查也覆盖这7项。
- 原沙箱入口：exit1，454文件/4210项通过，唯一旧global-build-health封套spawnSync /usr/bin/python3 EPERM；耗时787.45秒。原日志sandbox-source.log保留。
- 同一未变封套单补：仍exit1/同EPERM；直接运行其原Python文件：exit0/4项通过、stdout空；脚本未走到的paths：exit0/11项通过。测试、断言、时限和排除名单零修改，未因非超时的沙箱故障重复整套。
- 初版新增测试的2个错误旧行为假设已改为原leastLossPlan对照，失败日志保留；生产补丁之后未改动。
- gitleaks暂存补丁扫描exit0，无泄漏；git diff --check通过。

本任务要求每次代码提交前bash tools/test-sandbox.sh退出0，原入口未0，所以没有自行源码提交，也未把直接Python/paths组合改写成原入口通过。现有沙箱限制不归为新游戏/产品bug。源码、固定输入、staged tree和二进制净补丁均冻结，source-freeze.json记录三个SHA。source.patch为三文件净补丁，不含历史记录或知识。

## 合入预检

实际只读预检base/live5e70fa3dd1c5f8f1e5b00b9ac70083a68d93b922返回1，共23处冲突，涉及交接、decision-log、账本、论文数据/材料与docs；不是这三文件的源码冲突。详细merge-preflight-base.log/json原件保留。尚无源码commit，故预检对象明确是base，不能称最终源码提交已做整支merge。三文件净补丁对该live的git apply --check为0，未实际应用、未改live/index、未提交知识刷新或触及并行历史。

提交与合入由ops按既有受阻兜底流程处理；当前不造eval行为号、不写实际上线双通知、不标shipped、不申请删除本树。实际live祖先源码尚不存在于本补丁，计算下注原项保持waiting并明确技术阻塞。

## 逐项处置

- silent-proposal-b49c2e6f5d25e8ba：waiting。BJL F42 T2同盘12血，首试下轮5血、末试2血，相差3血可核；目标、触媒和后续抽牌同变，缺原24/24候选完整实打及末轮损6/实需8的根因，不拟SL血价或护栏新权重。
- silent-proposal-a25e259862a1fd3e：waiting。BJL F33→42赢战和药槽消耗可追，F42空药12血、F43火未到；缺保药/旧路线/提前休息受控后继及实际路线与终局消费者配对，不能量化持药价或安全血线。
- silent-proposal-1cb36e182078a20e：waiting。已完成Silent A10普通计算下注的窄源码/固定回归，撤源码2失败、恢复7通过；source tsc0、沙箱454文件/4210项通过，仅旧global-build-health封套spawnSync Python EPERM导致入口exit1，单补封套仍EPERM/直接Python4过/paths11过。提交前入口须0，故保留三文件暂存tree b825d9a35d6c502e7639aecd1ab94833f992a2da 和source.patch，未提交/未live；base/live另有23处历史冲突，净补丁只读apply-check0。请ops沿原批兜底提交/窄合；这是实施阻塞，不是待新局证据不足。
- silent-proposal-fab06d987903ee52：waiting。Y5 F33前三轮无毒、T4启毒、T10延长沙坑仍28挡对30攻/1血死亡可核；缺首轮保留启毒与原爆发在同抽序/药时点下的完整比较，不改换手、毒权重或药水时点。
- silent-proposal-54f7ee6b632cab26：waiting。Y5 F27预测含F29回血，实际F29锻造/回血0，F28餐券+15、F31问号战净损6；当前源码已有休息假设说明，但缺逐投影版本到实际路线/休息消费者的完整追溯，不能把部分文字说明登记整项完成。
- silent-proposal-00a6a10b15a62b38：waiting。两来源局的力敏/毒/制品/铜钹等局部事实不等于全部13经验联合模型校准；现有蜃景/幽灵等窄模型不覆盖完整组合、弃牌随机分配和结算全序。缺同资源完整联合回放及消费者核验，不重复实现已覆盖窄子项。
- silent-proposal-b643d5b644ec7c64：waiting。BJL F42换目标与触媒同变、多损3血；Y5 F17残壳自爆与F33沙坑独立于HP已观察。缺未知抽序、原候选完整执行和整战匹配，不能从三试零胜/超集存活修改SL必死或探索权重。
- silent-proposal-dce02af8d115b477：waiting。两局资源事实与未到营火边界可核，现有投影也声明未来营火按回血；缺保药、提前休息、替代路线到后战的受控资源结果和联合终局消费者，不用局部净HP变化重拟终局或持有价值。
- silent-proposal-85db96918f609b1e：duplicate。实际live祖先已有Silent A10/无已有无实体时的幽灵模型、生产门控及Jev保留选择；新层仅当轮参与推演，后轮从真实玩家层数重建。普通T4无攻击轮收益0、下一轮无旧层，不引入固定用药时点/持有价，A9只是原先验参考。 实际live祖先commit=66283dd9982bdd7f480da7a4d9bfefea0572a9ac。
- silent-proposal-6ce31508b40aa87f：waiting。SY0 F9 T2护栏预计省10血少12伤、抽牌后实损2并扣12；F33末试T3重问后实损8不同于换线预测21。已有护栏诊断只是候选预测，缺跨抽牌重问的完整候选身份认证与原线整战对照，原阈值保持。

## 账本与运行身份

只经根ledger.py登记本角色：silent-0300 status=proposed，by=learner:strategy-proposal；原队列ID沿用，无新重复提案。其余账本仅补where/note追溯，原首证/prior/claim/evidence/已发布状态保持，不重复support/repeat。最终CLI回执见ledger-final.*。

原实际启动命令请求gpt-6.1-sol/xhigh/service_tier=default，原thread01a145cf-9dbf-7bb3-9ec0-8529747520a9；任务模板文字high差异原样保留，未在模型内更改运行配置。只核到本次真实启动请求，未独立核服务档实际结算或原生回复型号。没有下级agent、网络/LLM调用、play或其他角色私有知识读取。

所有材料保留在本批scratch。恢复补丁只用source.patch及三个源文件SHA；不归档整仓、不删除现场。

账本最终回执：首次26项补链因重复携带silent-0300的proposed状态触发physical/committed状态保护，exit2且nothing written；原输入/stdout/stderr保留。r2只where/note追加，exit0/26项，原首次0300 proposed登记保留；ledger check exit0。未修改任何历史发布状态。初版材料自检将CLI空格分隔回执按行计数而失败，已按实际回执核26个ID，未重放CLI。

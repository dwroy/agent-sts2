# 本批策略提案逐项处置（最终处置）

基线：`a0e2fff7b979314585252a095ae0e20c8045a6ba`。普通队列任务，无research_request/implementation_request；仅处理原10个id，不增领、不新增重复id。

五局均已从runs.jsonl核为silent：G403VCZ3BH1B为A9胜局，另四局A10败局。历史code均带dirty，不能把当前源码倒填成完整运行快照。八流提取已完成，各流独立source_size/逐行offset、bytes、SHA保存在evidence/；fight-plans在本次截点0行仅表示未选到。

## 实现：普通计算下注的致死回合重抽入口

原提案silent-proposal-1cb36e182078a20e，账本silent-0300；来源postmortem/20261008-164302，当前实现任务strategy-proposal/20261017-014302-s2。证据L704TLETMZBM A10 F48末试T6（states256459—256462/decision251114）及Y5H4CFAQ2WTG A10 F33T10（states301111—301115/decision293850）。

旧行为：drawsCards只认固定抽牌和drawsUntil，least-loss在没有这两类抽牌可选时可结束，尽管普通计算下注仍可打。当前冻结Y5 s301114会复现结束回合；当前L704固定模型已经会选计算下注，不能把该旧症状冒称当前仍复现。

新行为：只在Silent A10、未禁抽、既有抽牌优先没有找到直接抽牌时，使用既有solver transition验证普通计算下注实际剩余弃牌/重抽数量。保留强制先出牌及沙坑到期前的逃离支付；支付后停止在计算下注，丢弃旧手牌后不能继续提交旧牌，下一状态重新规划。无牌可弃、抽牌封锁、升级形态、其他角色和未观察进阶保持旧入口。现有出牌/药水/SL权重、预算与必死门槛不改。

验证：4份原始固定状态与本批公共提取逐值相等；初稿有2项跨角色测试错误地假定旧代码总结束回合，已改为与原leastLossPlan结果比较，初稿失败保留。最终7项通过；撤生产源码后Y5零能量与沙坑支付两项失败，其余5项通过。恢复后的完整沙箱检查：tsc0，454文件/4210项通过，旧global-build-health封套EPERM使总exit1；原封套补验仍EPERM，直接Python4项及paths11项通过。原失败保留，不据此伪报完整通过。

反例/限制：此改动不宣称随机重抽可赢；未知真实抽序、没有实打的重抽后继与整个dirty运行树均保持未知。L704在当前固定输入上已会重抽，支持兼容性而非新修复收益。沙坑不是靠抽牌就保证延长，先支付逃离仅限原枚举中已有可延长线。无参数拟合，不将同局SL/回合算独立样本。

回退：仅逆向本次combat-plan.ts净补丁及对应固定验证文件，保留日志、账本和失败稿。若实际上线，由ops核实发布并登记shipped，不由学习者代填。

## 逐项处置

### silent-proposal-b49c2e6f5d25e8ba

账本：silent-0079, silent-0021, silent-0030, silent-0011, silent-0005, silent-0006, silent-0025, silent-0027, silent-0208, silent-0037, silent-0162, silent-0122；证据局：BJLTVSYXCSGS。

当前处置：waiting。BJL F42 T2同盘12血，首试下轮5血、末试2血，相差3血可核；目标、触媒和后续抽牌同变，缺原24/24候选完整实打及末轮损6/实需8的根因，不拟SL血价或护栏新权重。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-161301-postmortem/proposal-combat-sl.md；原Markdown SHA256：b49d01627e4777c52b5771927c5783bce83f27167a590bacf8efa046d181cd20。

### silent-proposal-a25e259862a1fd3e

账本：silent-0019, silent-0243；证据局：BJLTVSYXCSGS。

当前处置：waiting。BJL F33→42赢战和药槽消耗可追，F42空药12血、F43火未到；缺保药/旧路线/提前休息受控后继及实际路线与终局消费者配对，不能量化持药价或安全血线。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-161301-postmortem/proposal-resources.md；原Markdown SHA256：f22d3b8986c2dff8a5ebd27156303c72d926f34dbcf1e05ee9858cfae50ae2f2。

### silent-proposal-1cb36e182078a20e

账本：silent-0300；证据局：Y5H4CFAQ2WTG, L704TLETMZBM。

当前处置：waiting。已完成Silent A10普通计算下注的窄源码/固定回归，撤源码2失败、恢复7通过；source tsc0、沙箱454文件/4210项通过，仅旧global-build-health封套spawnSync Python EPERM导致入口exit1，单补封套仍EPERM/直接Python4过/paths11过。提交前入口须0，故保留三文件暂存tree b825d9a35d6c502e7639aecd1ab94833f992a2da 和source.patch，未提交/未live；base/live另有23处历史冲突，净补丁只读apply-check0。请ops沿原批兜底提交/窄合；这是实施阻塞，不是待新局证据不足。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-164302-postmortem/proposal-draw-entry.md；原Markdown SHA256：746fbd47b244549dc3a7be5c2f610513e187426ac754d9c544fded8c635925a0。

### silent-proposal-fab06d987903ee52

账本：silent-0021, silent-0018, silent-0006, silent-0046, silent-0276, silent-0284；证据局：Y5H4CFAQ2WTG。

当前处置：waiting。Y5 F33前三轮无毒、T4启毒、T10延长沙坑仍28挡对30攻/1血死亡可核；缺首轮保留启毒与原爆发在同抽序/药时点下的完整比较，不改换手、毒权重或药水时点。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-164302-postmortem/proposal-poison-survival.md；原Markdown SHA256：d16614a7a121be971786cdc6f8d3a2775f640f430ab6da711ef98fb26d57d769。

### silent-proposal-54f7ee6b632cab26

账本：silent-0019, silent-0021, silent-0243, silent-0017；证据局：Y5H4CFAQ2WTG。

当前处置：waiting。Y5 F27预测含F29回血，实际F29锻造/回血0，F28餐券+15、F31问号战净损6；当前源码已有休息假设说明，但缺逐投影版本到实际路线/休息消费者的完整追溯，不能把部分文字说明登记整项完成。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-164302-postmortem/proposal-resource-conditions.md；原Markdown SHA256：3a0ec67bc1d3a24d76538babccc14b0cd619a85f314e37e3dbfb39c70a787a99。

### silent-proposal-00a6a10b15a62b38

账本：silent-0012, silent-0005, silent-0011, silent-0027, silent-0037, silent-0208, silent-0122, silent-0162, silent-0276, silent-0010, silent-0046, silent-0284；证据局：BJLTVSYXCSGS, Y5H4CFAQ2WTG。

当前处置：waiting。两来源局的力敏/毒/制品/铜钹等局部事实不等于全部13经验联合模型校准；现有蜃景/幽灵等窄模型不覆盖完整组合、弃牌随机分配和结算全序。缺同资源完整联合回放及消费者核验，不重复实现已覆盖窄子项。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-170939-experience-update/proposal-mechanisms.md；原Markdown SHA256：98c740c77c13c39f26ef8e0b93c53384437cc8a2a3b84c6add7ed8f3c868b032。

### silent-proposal-b643d5b644ec7c64

账本：silent-0025, silent-0079, silent-0030, silent-0018, silent-0017, silent-0021；证据局：BJLTVSYXCSGS, Y5H4CFAQ2WTG。

当前处置：waiting。BJL F42换目标与触媒同变、多损3血；Y5 F17残壳自爆与F33沙坑独立于HP已观察。缺未知抽序、原候选完整执行和整战匹配，不能从三试零胜/超集存活修改SL必死或探索权重。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-170939-experience-update/proposal-boss-sl.md；原Markdown SHA256：8cf040d327e86e385fce45b1a0fbf8d5ba1aaeaa8d86fbb8193612c14d7bd1a8。

### silent-proposal-dce02af8d115b477

账本：silent-0243, silent-0020, silent-0019, silent-0021；证据局：BJLTVSYXCSGS, Y5H4CFAQ2WTG。

当前处置：waiting。两局资源事实与未到营火边界可核，现有投影也声明未来营火按回血；缺保药、提前休息、替代路线到后战的受控资源结果和联合终局消费者，不用局部净HP变化重拟终局或持有价值。

原提案：/home/dw/Projects/agent-sts2/.worktrees/exp/learner/runs/20261008-170939-experience-update/proposal-resources.md；原Markdown SHA256：b6fdaf8b5dbf03db45bd4e452c85e96e7ffa046a0f3eb48a7ba43984ba00ee6e。

### silent-proposal-85db96918f609b1e

账本：silent-0301, silent-0206；证据局：G403VCZ3BH1B, SY0WMJNNVRLM。

当前处置：duplicate。实际live祖先已有Silent A10/无已有无实体时的幽灵模型、生产门控及Jev保留选择；新层仅当轮参与推演，后轮从真实玩家层数重建。普通T4无攻击轮收益0、下一轮无旧层，不引入固定用药时点/持有价，A9只是原先验参考。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-171302-postmortem/proposal-ghost-window.md；原Markdown SHA256：765b4347f54fa3932235020fb50bc920b3b70145ac37d95db6437898c509d4fe。

### silent-proposal-6ce31508b40aa87f

账本：silent-0125, silent-0079；证据局：SY0WMJNNVRLM。

当前处置：waiting。SY0 F9 T2护栏预计省10血少12伤、抽牌后实损2并扣12；F33末试T3重问后实损8不同于换线预测21。已有护栏诊断只是候选预测，缺跨抽牌重问的完整候选身份认证与原线整战对照，原阈值保持。

原提案：/home/dw/Projects/agent-sts2/learner/runs/20261008-171302-postmortem/proposal-guard-replan.md；原Markdown SHA256：5b9900481c3c139ccaa0ea4ca49ae364307f96991dd6be02118db924601fcc67。

## 共同限制

原提案正文和原经验反例保持；本批不新增支持/重犯，不重写复盘，不将数据发布/日志诊断当作游戏源码实现。后续若需拟合按整局及结束时间切分，不把本批固定重现称盲测；未知抽序和未执行完整候选不填造结果。无新机制异议；仅缩小为可复现的入口缺口。

原源码before/after以.txt保存，失败日志和公共提取保留。源码保持三文件暂存，未提交/合入/发布；完整结果和兜底材料见report.md、report.json及validation.json。

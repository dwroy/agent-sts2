from pathlib import Path
import json,hashlib,subprocess,tarfile,re,os,importlib.util,collections
root=Path.cwd();r=root;p=r/'ops/codex-ops/record-staging/20261015-1958';pub=r/'paper/materials/20261015-1958-ops';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],stderr=subprocess.PIPE)
def load(f):return json.loads(f.read_text())
def write(f,x):f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base=git('rev-parse','HEAD').decode().strip();assert not git('diff','--cached','--name-only').strip()
bid='20261015-194301-s2-strategy-proposal';b=load(r/'ops/codex-ops/learn.json')['batches'][bid];report=b['report'];s=Path(report['report']).parent
assert b['state']=='done' and b['rc']==0 and b['proposal_audit_errors']==[] and b['no_change_proposals']['dispositions']==report['proposal_results']
assert len(report['proposal_results'])==10 and all(x['state']=='waiting' for x in report['proposal_results'])
assert report['fixes']==report['implementation_domains']==report['skipped']==[] and report['merged'] is None and all(x is None for x in report['tests'].values())
assert git('rev-parse','HEAD',cwd=b['worktree']).decode().strip()==report['base'] and not git('status','--porcelain','--untracked-files=no',cwd=b['worktree']).strip()
exec((r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py').read_text())
native=runtime(bid,report,(r/'ops/codex-ops/learner'/(bid+'.out')).read_text(),b['worktree'])
final=load(s/'final-gate.json');assert final['base']==report['base'] and final['status_porcelain']=='' and final['dispatch_unchanged'] and final['all_waiting'] and final['ledger_owned_rows']==31 and final['protected_fields_untouched'] and final['production_diff_empty']
assert (s/'source-baseline.diff.patch').read_bytes()==b''
markdown=load(s/'proposal-markdown-checks.json');assert len(markdown)==10
for x in markdown:assert x['sha_matches'] and sha((s/(x['id']+'.original.md')).read_bytes())==x['expected_sha256']
evidence=load(s/'byte-audit.json');assert len(evidence)==8 and sum(x['rows'] for x in evidence)==19929 and all(x['verified'] and sum(x['counts'].values())==x['rows'] for x in evidence)
identities=load(s/'run-identities.json');assert len(identities)==15 and all(x['character']=='SILENT' for x in identities.values());assert collections.Counter(x['ascension'] for x in identities.values())=={1:1,7:1,9:1,10:12}
materials=load(s/'material-checks.json');conclusions=load(s/'conclusion-checks.json');assert len(materials)==13 and len(conclusions)==25 and all(x['passed'] and x['observed']==x['expected'] for x in materials+conclusions)
source=load(s/'source-audit.json');assert source['base']==report['base'] and len(source['files'])==14;equal=0
for x in source['files']:
 a=git('show',report['base']+':'+x['path']);z=git('show',source['live_head']+':'+x['path']);assert sha(a)==x['sha256'] and sha(z)==x['live_head_sha256']==x['live_disk_sha256']
 if a==z:equal+=1
 else:assert x['comment_attribution_only'] and a.replace(b'Roy',b'Dai')==z.replace(b'Roy',b'Dai')
 assert x['ancestor'];git('merge-base','--is-ancestor',x['last_live_source_commit'],source['live_head'])
assert equal==9
ancestry=[]
for x in source['narrow_source_ancestors']:
 q=subprocess.run(['git','merge-base','--is-ancestor',x['commit'],source['live_head']],capture_output=True);assert q.returncode in [0,1] and (q.returncode==0)==x['actual_live_ancestor'];ancestry.append({'commit':x['commit'],'actual_live_ancestor':q.returncode==0})
for x in source['checked_historical_references']:git('merge-base','--is-ancestor',x['commit'],source['live_head'])
inputs=[json.loads(x) for x in (s/'ledger-updates.jsonl').read_text().splitlines()];owned=[]
for raw in (r/'paper/materials/learning/ledger.jsonl').read_bytes().splitlines(keepends=True):
 row=json.loads(raw)
 if row.get('op')=='update' and any(all(row.get(k)==v for k,v in x.items()) for x in inputs):owned.append(raw)
assert len(inputs)==len(owned)==31 and all(set(json.loads(x))<={'op','id','ts','by','where','note'} for x in owned)
receipt=load(s/'ledger-cli-receipt.json');assert len(receipt['owned_rows'])==31 and receipt['protected_fields_untouched']
for x in receipt['owned_rows']:
 with (r/'paper/materials/learning/ledger.jsonl').open('rb') as f:f.seek(x['offset']);raw=f.read(x['bytes'])
 assert sha(raw)==x['sha256'] and raw in owned
ids=(s/'ledger-cli.stdout.txt').read_text().split();assert len(ids)==31 and set(ids)=={json.loads(x)['id'] for x in owned}
(p/'owned-ledger.jsonl').write_bytes(b''.join(owned));old=git('show',base+':paper/materials/learning/ledger.jsonl');seen=set(old.splitlines());added=b''.join(x for x in owned if x.rstrip(b'\n') not in seen)
spec=importlib.util.spec_from_file_location('owned_ledger',r/'learner/ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fold=lambda raw:m.fold([(i,json.loads(x)) for i,x in enumerate(raw.splitlines(),1) if x]);before=fold(old);after=fold(old+added);assert set(before)==set(after)
for ident in before:
 for k in ['claim','first_run','asc','prior','prior_note','prior_runs','evidence','status','version','shipped_at','effect']:assert before[ident].get(k)==after[ident].get(k),(ident,k)
assert load(s/'gitleaks.json')==[]
write(pub/'batch-readback.json',{'batch':bid,'original_report':report,'native':native,'canonical_no_change_gate':b['no_change_proposals'],'original_final_gate':final,'ten_original_proposal_markdowns_sha_verified':True,'source14_sha_and_actual_ancestors_verified':True,'source9_equal5_historical_name_comments_preserved':True,'narrow_source_ancestry':ancestry,'original_evidence_rows':19929,'original_material_assertions':[13,25],'material_probes_reexecuted':False,'original_character_ascension_cohort':{'silent_A1':1,'silent_A7':1,'silent_A9':1,'silent_A10':12},'owned_trace_only_ledger_rows':31,'protected_fold_preserved':True,'CLI_stdout_correction':'Report final paragraph calls stdout one JSON result. Actual original stdout contains 31 space-separated IDs; verified receipt offsets, bytes, SHA and exact inputs. No CLI repeated.','original_material_failure':'Initial audit_conclusions expected next-turn Sandpit5 but observed4; original failed v1 kept, corrected audit separates after-play5 from next-turn4, no product/test assertion or game rule changed.','native_gap':'Original learner did not provide native request readback; ops verified original Sol6.1/xhigh/input/lease/workspace-write/no-network, keeping original task high wording.','limits':['Byte verification is not all-row game semantics or complete candidate/calibration certification.','166 potion transitions and42 Cunning observations are original bounded readbacks; hand capacity/first consumption/source attribution/cross-fight retention and SL full successors remain conditional or missing.','A1/A7/A9/A10 remain separate, repeated SL not independent runs; source invalid JSON and selected fight-plans0 retained.','Two original source commits are not live ancestors; actual replay sources, not record-only commits, support narrow implementation. Wide proposal/learning parents remain open.'],'no_source_tests_merge_release_dataset_or_game_actions':True})
files=[f for f in s.iterdir() if f.is_file() and f.stat().st_size<350000 and f.suffix in ['.json','.jsonl','.md','.py','.patch','.txt']];files+=[s/'evidence/evidence-manifest.json']+list((s/'source').glob('*.patch'))+[r/'ops/codex-ops/learner'/(bid+ext) for ext in ['.out','.err']];refs=[]
with tarfile.open(pub/'original-artifacts.tar.gz','w:gz') as tar:
 for f in sorted(files):
  raw=f.read_bytes();rel=str(f.relative_to(r));dest=p/'archive-scan'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);tar.add(f,arcname=rel);refs.append({'path':rel,'bytes':len(raw),'sha256':sha(raw)})
write(pub/'original-artifact-manifest.json',refs)
at=subprocess.check_output(['date','+%Y-%m-%d %H:%M:%S %Z'],text=True).strip()
line=f'\n- {at} 运维codex：1958原194301-s2策略rc0/done/no-source门禁核，十项waiting；f8ca干净WT无新源码，testsnull/mergednull/域空，不重合/发号/补测或重复派题。15Silent关联局19929行原字节核及13+25材料断言为原学习者读回，A1/A7/A9各1与A10十二分列，同局SL不增独立样本、无效JSON/截点fight-plans0不改；166饮药/42狡诈生成37×3/2×2/3×0为局部观察，不冒联合模型/全候选或自然收益。14叶旧livefe646265逐SHA及真实祖先核，9同/5Roy-Dai历史注释差保持；两原源非祖先与实际重放源分列，不冒记录commit为源码或窄功能为宽项闭合。31原CLI仅where/note、逐offset/bytes/SHA及输入同验，原claim/首证/prior/evidence/status/version保护不变；报告称stdout一行JSON而原件为31空格ID，按原receipt核条数，不重复CLI，原文保留。原材料v1误把出牌后沙坑5当次轮5，实4的首失败与v2分别读取5/4通过保留，不当撤源码负控或生产测试。ops补核实际native Sol6.1/xhigh/input/lease、workspace-write/no-network，原任务high与未独立读native边界不改。完整资源/留药/油灯消费/跨弃牌重规划/SL联合后继及受控整战仍缺，原宽父/各owner保持；无新知识/反证/复盘/源码，不刷新论文、不改当前局/账号home模型预算队列prompt，不等待未来事件。证据paper/materials/20261015-1958-ops/。\n'
note=f'\n- {at} [ops 策略处置] 原194301-s2十项继续waiting，无源码/合入/版本；31条CLI仅追溯且保护旧知识/状态。原19929行及13+25材料检查、沙坑窗口标签首失败/修正和CLI输出格式差异均保留，未重派或补测。回执paper/materials/20261015-1958-ops/。\n'
appends={'paper/materials/decision-log.md':line,'ops/inbox-dev.md':note};write(p/'own-appends.json',appends)
for path,text in appends.items():
 with (r/path).open('ab') as f:f.write(text.encode())
helpers=[];hs=p/'helper-scan';hs.mkdir(exist_ok=True)
with tarfile.open(pub/'ops-helper-sources.tar.gz','w:gz') as tar:
 for f in [p/'prepare-records.py',p/'seal-records.py',r/'ops/codex-ops/record-staging/20261015-0654/readonly-runtime.py']:
  raw=f.read_bytes();(hs/f.name).write_bytes(raw);tar.add(f,arcname=f.name);helpers.append({'path':str(f.relative_to(r)),'bytes':len(raw),'sha256':sha(raw)})
write(pub/'ops-helper-manifest.json',helpers);write(pub/'completion.json',{'at':at,'batch':bid,'waiting':10,'own_ledger_rows':31,'new_to_HEAD_rows':len(added.splitlines()),'protected_ledger_fields_preserved':True,'no_source_tests_merge_release_or_dataset':True,'native_model_and_original_sandbox_verified':True,'parallel_records_preserved':True})
values={path:git('show',base+':'+path)+text.encode() for path,text in appends.items()};values['paper/materials/learning/ledger.jsonl']=old+added
for f in pub.iterdir():
 if f.is_file():values[str(f.relative_to(r))]=f.read_bytes()
entries=[];dest=p/'final-files'
for path,raw in values.items():
 f=dest/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);entries.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
write(p/'record-manifest.json',{'base':base,'paths':entries})
q=subprocess.run(['nice','-n','19','python3','learner/ledger.py','check'],env={**os.environ,'LEDGER_FILE':str(dest/'paper/materials/learning/ledger.jsonl')},capture_output=True);(pub/'final-ledger-check.log').write_bytes(q.stdout+q.stderr);assert q.returncode==0
print(json.dumps({'waiting':10,'owned_ledger_rows':31,'native_verified':True,'ledger_check':0,'paths':len(entries)}))

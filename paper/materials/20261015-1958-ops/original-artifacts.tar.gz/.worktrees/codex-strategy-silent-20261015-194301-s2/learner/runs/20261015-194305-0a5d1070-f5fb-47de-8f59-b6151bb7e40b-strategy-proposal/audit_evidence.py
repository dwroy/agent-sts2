"""Read frozen own-character evidence; never run gameplay or change production inputs."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extract_evidence", BASE.parents[1] / "extract_evidence.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def write(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def powers(raw):
    return {x["power_id"]: x["amount"] for x in raw or []}


def compact(item):
    row = item["row"]
    state = row["state"]
    combat = state.get("combat") or {}
    player = combat.get("player") or {}
    run = state.get("run") or {}
    return {
        "line": item["line"], "offset": item["offset"], "sha256": item["sha256"],
        "run_id": item["run_id"], "ts": row.get("ts"), "observed_ts": row.get("observed_ts"),
        "floor": run.get("floor"), "turn": state.get("turn"), "screen": state.get("screen"),
        "hp": run.get("current_hp"), "max_hp": run.get("max_hp"),
        "combat_hp": player.get("current_hp"), "block": player.get("block"), "energy": player.get("energy"),
        "played": player.get("cards_played_this_turn"), "powers": powers(player.get("powers")),
        "ready": (combat.get("action_readiness") or {}).get("can_use_combat_actions"),
        "hand": [{"id": c.get("card_id"), "upgraded": c.get("upgraded"),
                  "values": {v["name"]: v.get("current_value") for v in c.get("dynamic_values", [])}}
                 for c in combat.get("hand", [])],
        "potions": [{"slot": p.get("slot_index", p.get("index")), "id": p.get("potion_id"),
                     "occupied": p.get("occupied")} for p in run.get("potions", [])],
        "enemies": [{"id": e.get("enemy_id"), "hp": e.get("current_hp"), "block": e.get("block"),
                     "powers": powers(e.get("powers")), "intent": e.get("intents", e.get("intent"))}
                    for e in combat.get("enemies", [])],
    }


manifest = json.loads((BASE / "evidence/evidence-manifest.json").read_text())
verified = []
state_items = []
decision_items = []
for stream in manifest:
    counts = collections.Counter()
    digest = hashlib.sha256()
    source = Path("/home/dw/Projects/agent-sts2/logs") / (stream["stream"] + ".jsonl")
    with source.open("rb") as original, (BASE / "evidence" / (stream["stream"] + ".evidence.jsonl")).open("rb") as frozen:
        for encoded in frozen:
            digest.update(encoded)
            item = json.loads(encoded)
            original.seek(item["offset"])
            raw = original.read(item["bytes"])
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            assert json.loads(raw) == item["row"]
            assert module.run_identity(item["row"]) == item["run_id"]
            assert item["offset"] + item["bytes"] <= stream["source_size"]
            counts[item["run_id"]] += 1
            if stream["stream"] == "states":
                state_items.append(item)
            elif stream["stream"] == "decisions":
                decision_items.append(item)
    assert digest.hexdigest() == stream["output_sha256"]
    assert all(counts[r] == n for r, n in stream["counts"].items())
    verified.append({"stream": stream["stream"], "source_size": stream["source_size"],
                     "rows": sum(counts.values()), "counts": dict(counts), "verified": True})
write("byte-audit.json", verified)

windows = [(281312, 281313), (281338, 281339), (281367, 281368), (281399, 281400),
           (281563, 281566), (282075, 282083), (282144, 282153), (282330, 282337),
           (282804, 282809), (282887, 282893), (283391, 283407), (283478, 283487),
           (283502, 283511), (283146, 283149)]
selected = [compact(x) for x in state_items if any(a <= x["line"] <= b for a, b in windows)]
write("fixed-windows.json", selected)
index = {x["line"]: x for x in selected}
checks = []


def check(name, value, expected):
    assert value == expected, (name, value, expected)
    checks.append({"name": name, "observed": value, "expected": expected, "passed": True})


for a, b in [(281312, 281313), (281338, 281339), (281367, 281368), (281399, 281400)]:
    check("TXZ开场净失4:" + str(a), index[a]["hp"] - index[b]["hp"], 4)
check("TXZ F49开场4至0", [index[281565]["hp"], index[281566]["hp"]], [4, 0])
check("TXZ F49尚未出牌", index[281566]["played"], 0)
check("Q6紧勒实际逐步敌血", [index[n]["enemies"][0]["hp"] for n in [282887, 282888, 282889, 282891, 282892]], [103, 95, 85, 83, 80])
check("Q6建立紧勒2", index[282888]["enemies"][0]["powers"]["STRANGLE_POWER"], 2)
check("Q6次轮紧勒已消失", "STRANGLE_POWER" in index[282893]["enemies"][0]["powers"], False)
check("Q6敏捷药建立2", index[282806]["powers"]["DEXTERITY_POWER"], 2)
check("Q6双防御14挡", [index[n]["block"] for n in [282806, 282807, 282808]], [0, 7, 14])
check("Q6该轮44血不变", [index[n]["hp"] for n in [282806, 282807, 282808, 282809]], [44, 44, 44, 44])
check("NHA首毒5实际10", [index[n]["enemies"][0]["powers"].get("POISON_POWER", 0) for n in [283146, 283147]], [0, 10])
write("material-checks.json", checks)

by_run = collections.defaultdict(list)
for item in state_items:
    by_run[item["run_id"]].append(item)
chains = {}
for run, items in by_run.items():
    rooms = collections.OrderedDict()
    for item in items:
        state = item["row"]["state"]
        floor = (state.get("run") or {}).get("floor")
        if floor is None:
            continue
        room = rooms.setdefault(floor, {"first": compact(item), "last": compact(item), "first_combat": None, "last_combat": None})
        room["last"] = compact(item)
        if state.get("in_combat"):
            room["first_combat"] = room["first_combat"] or compact(item)
            room["last_combat"] = compact(item)
    chains[run] = rooms
write("room-resource-chains.json", chains)

print(json.dumps({"verified_rows": sum(x["rows"] for x in verified),
                  "streams": [{"stream": x["stream"], "rows": x["rows"]} for x in verified],
                  "material_checks": len(checks), "runs": len(chains)}, ensure_ascii=False))

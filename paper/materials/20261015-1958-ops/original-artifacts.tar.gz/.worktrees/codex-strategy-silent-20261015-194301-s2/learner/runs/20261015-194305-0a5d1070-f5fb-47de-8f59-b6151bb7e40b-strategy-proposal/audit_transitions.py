"""Audit actual potion transitions and bounded SL windows without estimating counterfactual wins."""
import bisect
import collections
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def rows(stream):
    with (BASE / "evidence" / (stream + ".evidence.jsonl")).open() as handle:
        return [json.loads(line) for line in handle]


states = rows("states")
decisions = rows("decisions")
by_run = collections.defaultdict(list)
for item in states:
    by_run[item["run_id"]].append(item)
observed = {r: {s["row"].get("observed_ts"): n for n, s in enumerate(ss)} for r, ss in by_run.items()}


def summary(item):
    s = item["row"]["state"]
    c = s.get("combat") or {}
    p = c.get("player") or {}
    return {"line": item["line"], "hp": (s.get("run") or {}).get("current_hp"),
            "turn": s.get("turn"), "energy": p.get("energy"), "block": p.get("block"),
            "hand": len(c.get("hand", [])),
            "shivs": sum(c.get("card_id") == "SHIV" for c in c.get("hand", [])),
            "enemy_hp": sum(e["current_hp"] for e in c.get("enemies", [])),
            "powers": {v["power_id"]: v["amount"] for v in p.get("powers", [])}}


transitions = []
for d in decisions:
    row = d["row"]
    action = row.get("chosen") or {}
    if action.get("action") != "use_potion":
        continue
    run = d["run_id"]
    n = observed[run].get(row.get("observed_ts"))
    if n is None:
        transitions.append({"run_id": run, "decision_line": d["line"], "missing_before": True})
        continue
    before = by_run[run][n]
    state = before["row"]["state"]
    occupied = [(p.get("potion_id"), p.get("occupied")) for p in (state.get("run") or {}).get("potions", [])]
    after = None
    for candidate in by_run[run][n + 1:n + 8]:
        cs = candidate["row"]["state"]
        cp = [(p.get("potion_id"), p.get("occupied")) for p in (cs.get("run") or {}).get("potions", [])]
        if (cs.get("run") or {}).get("floor") != row.get("floor") or cs.get("turn") != row.get("turn"):
            break
        if cp != occupied and (cs.get("combat") or {}).get("action_readiness", {}).get("can_use_combat_actions"):
            after = candidate
            break
    entry = {"run_id": run, "decision_line": d["line"], "floor": row.get("floor"), "turn": row.get("turn"),
             "expect": row.get("expect"), "action": action, "result": row.get("result"), "before": summary(before)}
    if after:
        entry["after"] = summary(after)
        bp = (state.get("run") or {}).get("potions", [])
        ap = (after["row"]["state"].get("run") or {}).get("potions", [])
        entry["removed_ids"] = [p.get("potion_id") for p, q in zip(bp, ap) if p.get("occupied") and not q.get("occupied")]
        if entry["removed_ids"] == ["CUNNING_POTION"]:
            bh = (state.get("combat") or {}).get("hand", [])
            ah = (after["row"]["state"].get("combat") or {}).get("hand", [])
            entry["added"] = len(ah) - len(bh)
            entry["new_shivs"] = [{"upgraded": c.get("upgraded"), "damage_base": next((v.get("base_value") for v in c.get("dynamic_values", []) if v.get("name") == "Damage"), None)}
                                  for c in ah[len(bh):]]
    else:
        entry["missing_settled_after"] = True
    transitions.append(entry)
(BASE / "potion-transitions.json").write_text(json.dumps(transitions, ensure_ascii=False, indent=2) + "\n")

windows = {}
for a, b in [(281475, 281488), (281510, 281525), (282075, 282083), (282144, 282153), (282330, 282337),
             (283391, 283407), (283478, 283487), (283502, 283511)]:
    windows[str(a)] = [summary(s) for s in states if a <= s["line"] <= b]
(BASE / "sl-window-summaries.json").write_text(json.dumps(windows, ensure_ascii=False, indent=2) + "\n")

selected = []
for d in decisions:
    if d["line"] in [275383, 275894, 275960, 276139, 277248, 277250, 277272, 277274]:
        r = d["row"]
        criteria = (r.get("questions", {}).get("plan") or {}).get("criteria", {})
        facts = {}
        for k, v in criteria.items():
            try:
                f = json.loads(v) if isinstance(v, str) else v
            except ValueError:
                continue
            if isinstance(f, dict):
                facts[k] = {key: f.get(key) for key in ["plays", "hp_lost", "damage_dealt", "lethal_now", "sandpit_after_enemy_turn"]}
        selected.append({"line": d["line"], "run_id": d["run_id"], "floor": r.get("floor"), "turn": r.get("turn"),
                         "observed_ts": r.get("observed_ts"), "fingerprint": r.get("fingerprint"),
                         "answer": (r.get("answers", {}).get("plan") or {}).get("choice"),
                         "action": r.get("chosen"), "expect": r.get("expect"), "result": r.get("result"),
                         "sl_explore": r.get("sl_explore"), "candidate_local_facts": facts})
(BASE / "sl-decisions.json").write_text(json.dumps(selected, ensure_ascii=False, indent=2) + "\n")

cunning = [x for x in transitions if x.get("removed_ids") == ["CUNNING_POTION"]]
ken = [x for x in transitions if x["run_id"] == "KEN58SH9SLZ6"]
print(json.dumps({"drinks": len(transitions), "missing_before": sum(x.get("missing_before", False) for x in transitions),
                  "missing_after": sum(x.get("missing_settled_after", False) for x in transitions),
                  "cunning": len(cunning), "cunning_added": dict(collections.Counter(x["added"] for x in cunning)),
                  "ken_drinks": [{"line": x["decision_line"], "floor": x["floor"], "turn": x["turn"], "ids": x.get("removed_ids")} for x in ken],
                  "sl_decisions": len(selected)}, ensure_ascii=False))

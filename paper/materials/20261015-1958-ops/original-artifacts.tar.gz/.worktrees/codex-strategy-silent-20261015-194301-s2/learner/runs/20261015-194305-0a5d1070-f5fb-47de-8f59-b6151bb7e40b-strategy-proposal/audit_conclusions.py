"""Check bounded observed claims, separate from production tests and strategy calibration."""
import collections
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
states = {x["line"]: x for x in map(json.loads, (BASE / "evidence/states.evidence.jsonl").open())}
decisions = {x["line"]: x for x in map(json.loads, (BASE / "evidence/decisions.evidence.jsonl").open())}
potions = json.loads((BASE / "potion-transitions.json").read_text())
checks = []


def check(name, observed, expected):
    assert observed == expected, (name, observed, expected)
    checks.append({"name": name, "observed": observed, "expected": expected, "passed": True})


def state(n):
    return states[n]["row"]["state"]


def hp(n):
    return state(n)["run"]["current_hp"]


def enemy_hp(n):
    return sum(e["current_hp"] for e in state(n)["combat"]["enemies"])


def net(a, b):
    return [hp(a) - hp(b), enemy_hp(a) - enemy_hp(b)]


check("所有状态属于静默猎手", sorted({state(n)["run"]["character_id"] for n in states}), ["SILENT"])
check("TXZ T6原线实际损血与伤害", net(281479, 281484), [3, 36])
check("TXZ T6替线实际损血与伤害", net(281535, 281539), [0, 27])
check("TXZ T6同指纹", decisions[275342]["row"]["fingerprint"] == decisions[275383]["row"]["fingerprint"], True)
check("WQ T9原线实际损血与伤害", net(282075, 282079), [13, 24])
check("WQ T9替线实际损血与伤害", net(282144, 282148), [22, 39])
check("WQ T9同指纹", decisions[275894]["row"]["fingerprint"] == decisions[275960]["row"]["fingerprint"], True)
check("WQ T7延时替线实际损血与伤害", net(282330, 282336), [4, 24])
check("WQ T7出逃离后沙坑5", next(p["amount"] for p in state(282331)["combat"]["enemies"][0]["powers"] if p["power_id"] == "SANDPIT_POWER"), 5)
check("WQ T8两线沙坑3与4", [next(p["amount"] for p in state(n)["combat"]["enemies"][0]["powers"] if p["power_id"] == "SANDPIT_POWER") for n in [282072, 282336]], [3, 4])
check("NHA T1原线实际损血与跨轮净扣", net(283391, 283397), [1, 8])
check("NHA T1替线实际损血与跨轮净扣", net(283478, 283483), [7, 24])
check("NHA T1重放实际损血与跨轮净扣", net(283502, 283507), [7, 24])
check("NHA原线含抱抱先生前的卡牌扣血", enemy_hp(283391) - enemy_hp(283396), 4)
check("NHA替线含抱抱先生前的卡牌扣血", enemy_hp(283478) - enemy_hp(283482), 20)
check("NHA次轮自动扣血分别4", [enemy_hp(283396) - enemy_hp(283397), enemy_hp(283482) - enemy_hp(283483)], [4, 4])
check("KEN七次饮药", len([p for p in potions if p["run_id"] == "KEN58SH9SLZ6"]), 7)
check("KEN F5赢战仍损37", hp(280255) - hp(280285), 37)
check("KEN两次实际回复", [hp(280338) - hp(280336), hp(280384) - hp(280382)], [27, 29])
cunning = [p for p in potions if p.get("removed_ids") == ["CUNNING_POTION"]]
check("狡诈实际饮用42次", len(cunning), 42)
check("狡诈生成数分布", dict(collections.Counter(str(p["added"]) for p in cunning)), {"3": 37, "2": 2, "0": 3})
check("新生成刀均升级且基础6", all(c["upgraded"] is True and c["damage_base"] == 6 for p in cunning for c in p["new_shivs"]), True)
check("WQ末两试容量截断", [p["added"] for p in cunning if p["run_id"] == "WQZVENQ7DTRP"][-6:], [2, 0, 0, 3, 2, 0])
check("1913资源链", [hp(n) for n in [282600, 282638, 282639, 282666, 282705, 282709, 282722, 282750, 282755, 282783]], [58, 14, 58, 44, 40, 40, 61, 46, 46, 0])
check("Q6资源链", [hp(n) for n in [282793, 282817, 282820, 282846, 282868, 282871, 282872, 282912, 282913, 282921]], [56, 44, 36, 36, 36, 57, 57, 2, 2, 0])

(BASE / "conclusion-checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"material_claim_checks": len(checks), "passed": True}, ensure_ascii=False))
